
/home/david/Documents/Codex/2026-11-19/profile-and-improve-buster-compilation-speed/work/width-evidence/vm/default.o:     file format elf64-x86-64


Disassembly of section .text:

000000000004f4a0 <sqlite3VdbeExec>:
   4f4a0:	push   rbx
   4f4a1:	push   rbp
   4f4a2:	push   r12
   4f4a4:	push   r13
   4f4a6:	push   r14
   4f4a8:	push   r15
   4f4aa:	sub    rsp,0x378
   4f4b1:	lea    rbp,[rsp+0x218]
   4f4b9:	mov    r13,QWORD PTR [rdi+0x88]
   4f4c0:	mov    r14,QWORD PTR [rdi]
   4f4c3:	movzx  r15d,BYTE PTR [r14+0x64]
   4f4c8:	mov    r12,QWORD PTR [rdi+0x68]
   4f4cc:	xor    ebx,ebx
   4f4ce:	cmp    DWORD PTR [rdi+0xd0],0x0
   4f4d5:	je     4f531 <sqlite3VdbeExec+0x91>
   4f4d7:	cmp    DWORD PTR [rdi+0xd0],0x0
   4f4de:	je     4f531 <sqlite3VdbeExec+0x91>
   4f4e0:	mov    rax,QWORD PTR [rdi]
   4f4e3:	mov    rdx,QWORD PTR [rax+0x20]
   4f4e7:	mov    eax,DWORD PTR [rax+0x28]
   4f4ea:	xor    ecx,ecx
   4f4ec:	jmp    4f52d <sqlite3VdbeExec+0x8d>
   4f4ee:	cmp    ecx,0x1
   4f4f1:	je     4f52a <sqlite3VdbeExec+0x8a>
   4f4f3:	mov    esi,0x1
   4f4f8:	shl    esi,cl
   4f4fa:	and    esi,DWORD PTR [rdi+0xd0]
   4f500:	test   esi,esi
   4f502:	je     4f52a <sqlite3VdbeExec+0x8a>
   4f504:	mov    rsi,rcx
   4f507:	shl    rsi,0x5
   4f50b:	cmp    QWORD PTR [rdx+rsi*1+0x8],0x0
   4f511:	je     4f52a <sqlite3VdbeExec+0x8a>
   4f513:	mov    rsi,rcx
   4f516:	shl    rsi,0x5
   4f51a:	mov    rsi,QWORD PTR [rdx+rsi*1+0x8]
   4f51f:	mov    r8,QWORD PTR [rsi+0x8]
   4f523:	mov    rsi,QWORD PTR [rsi]
   4f526:	mov    QWORD PTR [r8+0x8],rsi
   4f52a:	add    ecx,0x1
   4f52d:	cmp    ecx,eax
   4f52f:	jl     4f4ee <sqlite3VdbeExec+0x4e>
   4f531:	cmp    QWORD PTR [r14+0x208],0x0
   4f539:	je     4f55c <sqlite3VdbeExec+0xbc>
   4f53b:	mov    eax,DWORD PTR [rdi+0xe4]
   4f541:	mov    ecx,DWORD PTR [r14+0x218]
   4f548:	mov    esi,DWORD PTR [r14+0x218]
   4f54f:	xor    edx,edx
   4f551:	div    esi
   4f553:	mov    eax,edx
   4f555:	sub    ecx,eax
   4f557:	mov    rbp,rcx
   4f55a:	jmp    4f563 <sqlite3VdbeExec+0xc3>
   4f55c:	mov    rbp,0xffffffffffffffff
   4f563:	cmp    DWORD PTR [rdi+0x34],0x7
   4f567:	jne    4f5dc <sqlite3VdbeExec+0x13c>
   4f569:	mov    rbx,r13
   4f56c:	xor    r11d,r11d
   4f56f:	mov    DWORD PTR [rsp+0x320],r11d
   4f577:	xor    r11d,r11d
   4f57a:	mov    QWORD PTR [rsp+0xd0],r11
   4f582:	mov    QWORD PTR [rsp+0xb0],rdi
   4f58a:	mov    rdi,r14
   4f58d:	call   4f592 <sqlite3VdbeExec+0xf2>
   4f592:	lea    rax,[rip+0x0]        # 4f599 <sqlite3VdbeExec+0xf9>
   4f599:	mov    rdi,QWORD PTR [rsp+0xb0]
   4f5a1:	mov    rsi,rax
   4f5a4:	xor    eax,eax
   4f5a6:	call   4f5ab <sqlite3VdbeExec+0x10b>
   4f5ab:	mov    r12d,0x7
   4f5b1:	mov    rdi,QWORD PTR [rsp+0xb0]
   4f5b9:	mov    QWORD PTR [rsp+0xf0],r13
   4f5c1:	mov    QWORD PTR [rsp+0xe8],rbx
   4f5c9:	mov    r13,QWORD PTR [rsp+0xd0]
   4f5d1:	mov    rbx,rbp
   4f5d4:	mov    rbp,r12
   4f5d7:	jmp    4f712 <sqlite3VdbeExec+0x272>
   4f5dc:	mov    DWORD PTR [rdi+0x34],0x0
   4f5e3:	mov    QWORD PTR [rdi+0x48],0x0
   4f5eb:	mov    DWORD PTR [r14+0x290],0x0
   4f5f6:	mov    eax,DWORD PTR [r14+0x190]
   4f5fd:	test   eax,eax
   4f5ff:	je     4f643 <sqlite3VdbeExec+0x1a3>
   4f601:	mov    rbx,r13
   4f604:	xor    r11d,r11d
   4f607:	mov    DWORD PTR [rsp+0x320],r11d
   4f60f:	xor    r11d,r11d
   4f612:	mov    QWORD PTR [rsp+0xd0],r11
   4f61a:	mov    r12d,0x9
   4f620:	mov    QWORD PTR [rsp+0xf0],r13
   4f628:	mov    QWORD PTR [rsp+0xe8],rbx
   4f630:	mov    r13,QWORD PTR [rsp+0xd0]
   4f638:	mov    rbx,rbp
   4f63b:	mov    rbp,r12
   4f63e:	jmp    4f712 <sqlite3VdbeExec+0x272>
   4f643:	movsxd rax,DWORD PTR [rdi+0x30]
   4f647:	imul   rax,rax,0x18
   4f64b:	lea    rbx,[r13+rax*1+0x0]
   4f650:	mov    DWORD PTR [rsp+0x31c],r15d
   4f658:	mov    QWORD PTR [rsp+0xf0],r13
   4f660:	mov    QWORD PTR [rsp+0xf8],rbp
   4f668:	mov    rbp,rbx
   4f66b:	mov    rbx,r12
   4f66e:	xor    r11d,r11d
   4f671:	mov    DWORD PTR [rsp+0x32c],r11d
   4f679:	xor    r11d,r11d
   4f67c:	mov    DWORD PTR [rsp+0x320],r11d
   4f684:	xor    r11d,r11d
   4f687:	mov    DWORD PTR [rsp+0x330],r11d
   4f68f:	xor    r12d,r12d
   4f692:	xor    r11d,r11d
   4f695:	mov    DWORD PTR [rsp+0x334],r11d
   4f69d:	jmp    655fe <sqlite3VdbeExec+0x1615e>
   4f6a2:	mov    QWORD PTR [rsp+0xd0],r13
   4f6aa:	mov    r13,QWORD PTR [rsp+0xf0]
   4f6b2:	mov    QWORD PTR [rsp+0xf0],r13
   4f6ba:	mov    r13,QWORD PTR [rsp+0xd0]
   4f6c2:	cmp    r13,rbp
   4f6c5:	jb     4f727 <sqlite3VdbeExec+0x287>
   4f6c7:	cmp    QWORD PTR [r14+0x208],0x0
   4f6cf:	je     4f727 <sqlite3VdbeExec+0x287>
   4f6d1:	mov    eax,DWORD PTR [r14+0x218]
   4f6d8:	add    rbp,rax
   4f6db:	mov    rax,QWORD PTR [r14+0x208]
   4f6e2:	mov    rcx,QWORD PTR [r14+0x210]
   4f6e9:	mov    QWORD PTR [rsp+0xb0],rdi
   4f6f1:	mov    rdi,rcx
   4f6f4:	mov    r10,rax
   4f6f7:	call   r10
   4f6fa:	mov    rdi,QWORD PTR [rsp+0xb0]
   4f702:	test   eax,eax
   4f704:	je     4f6a2 <sqlite3VdbeExec+0x202>
   4f706:	mov    rbx,0xffffffffffffffff
   4f70d:	mov    ebp,0x9
   4f712:	cmp    BYTE PTR [r14+0x67],0x0
   4f717:	je     65722 <sqlite3VdbeExec+0x16282>
   4f71d:	mov    ebp,0x7
   4f722:	jmp    65758 <sqlite3VdbeExec+0x162b8>
   4f727:	mov    DWORD PTR [rsp+0x31c],r15d
   4f72f:	mov    QWORD PTR [rsp+0xd0],r13
   4f737:	mov    DWORD PTR [rsp+0x330],ebx
   4f73e:	mov    QWORD PTR [rsp+0xf8],rbp
   4f746:	mov    rbp,QWORD PTR [rsp+0xe8]
   4f74e:	mov    rbx,QWORD PTR [rsp+0x100]
   4f756:	mov    DWORD PTR [rsp+0x334],r12d
   4f75e:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   4f763:	mov    r15d,DWORD PTR [rsp+0x31c]
   4f76b:	mov    r13,QWORD PTR [rsp+0xf0]
   4f773:	mov    QWORD PTR [rsp+0xd0],r12
   4f77b:	mov    r12d,DWORD PTR [rsp+0x334]
   4f783:	movsxd rax,DWORD PTR [rbp+0x4]
   4f787:	imul   rcx,rax,0x38
   4f78b:	mov    WORD PTR [rbx+rcx*1+0x14],0x4
   4f792:	mov    rax,rbp
   4f795:	sub    rax,r13
   4f798:	movabs rdx,0x2aaaaaaaaaaaaaab
   4f7a2:	imul   rdx
   4f7a5:	sar    rdx,0x2
   4f7a9:	mov    rax,rdx
   4f7ac:	shr    rax,0x3f
   4f7b0:	add    rdx,rax
   4f7b3:	mov    rax,rdx
   4f7b6:	movsxd rax,eax
   4f7b9:	mov    QWORD PTR [rbx+rcx*1],rax
   4f7bd:	mov    eax,DWORD PTR [rbp+0x8]
   4f7c0:	sub    eax,0x1
   4f7c3:	movsxd rax,eax
   4f7c6:	imul   rax,rax,0x18
   4f7ca:	lea    rbp,[r13+rax*1+0x0]
   4f7cf:	mov    QWORD PTR [rsp+0xe8],rbp
   4f7d7:	mov    QWORD PTR [rsp+0x100],rbx
   4f7df:	mov    ebx,DWORD PTR [rsp+0x330]
   4f7e6:	mov    eax,DWORD PTR [r14+0x190]
   4f7ed:	test   eax,eax
   4f7ef:	jne    4f7fe <sqlite3VdbeExec+0x35e>
   4f7f1:	mov    rbp,QWORD PTR [rsp+0xf8]
   4f7f9:	jmp    4f6b2 <sqlite3VdbeExec+0x212>
   4f7fe:	mov    rbx,QWORD PTR [rsp+0xe8]
   4f806:	mov    rbp,QWORD PTR [rsp+0xf8]
   4f80e:	jmp    4f61a <sqlite3VdbeExec+0x17a>
   4f813:	mov    r15d,DWORD PTR [rsp+0x31c]
   4f81b:	mov    r13,QWORD PTR [rsp+0xf0]
   4f823:	mov    QWORD PTR [rsp+0xd0],r12
   4f82b:	mov    r12d,DWORD PTR [rsp+0x334]
   4f833:	movsxd rax,DWORD PTR [rbp+0x4]
   4f837:	imul   rax,rax,0x38
   4f83b:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   4f840:	and    ecx,0x4
   4f843:	test   ecx,ecx
   4f845:	je     4f859 <sqlite3VdbeExec+0x3b9>
   4f847:	mov    ecx,DWORD PTR [rbp+0xc]
   4f84a:	mov    rax,QWORD PTR [rbx+rax*1]
   4f84e:	imul   rax,rax,0x18
   4f852:	lea    rbp,[r13+rax*1+0x0]
   4f857:	jmp    4f85c <sqlite3VdbeExec+0x3bc>
   4f859:	mov    eax,DWORD PTR [rbp+0xc]
   4f85c:	mov    DWORD PTR [rsp+0x31c],r15d
   4f864:	mov    QWORD PTR [rsp+0xf0],r13
   4f86c:	mov    DWORD PTR [rsp+0x334],r12d
   4f874:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   4f879:	mov    r15d,DWORD PTR [rsp+0x31c]
   4f881:	mov    r13,QWORD PTR [rsp+0xf0]
   4f889:	mov    QWORD PTR [rsp+0xd0],r12
   4f891:	mov    r12d,DWORD PTR [rsp+0x334]
   4f899:	movsxd rax,DWORD PTR [rbp+0x4]
   4f89d:	imul   rax,rax,0x38
   4f8a1:	mov    ecx,DWORD PTR [rbp+0xc]
   4f8a4:	sub    ecx,0x1
   4f8a7:	movsxd rcx,ecx
   4f8aa:	mov    QWORD PTR [rbx+rax*1],rcx
   4f8ae:	mov    WORD PTR [rbx+rax*1+0x14],0x4
   4f8b5:	cmp    DWORD PTR [rbp+0x8],0x0
   4f8b9:	je     4f8d3 <sqlite3VdbeExec+0x433>
   4f8bb:	mov    QWORD PTR [rsp+0xf0],r13
   4f8c3:	mov    DWORD PTR [rsp+0x334],r12d
   4f8cb:	mov    r12,r14
   4f8ce:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   4f8d3:	mov    DWORD PTR [rsp+0x31c],r15d
   4f8db:	mov    QWORD PTR [rsp+0xf0],r13
   4f8e3:	mov    DWORD PTR [rsp+0x334],r12d
   4f8eb:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   4f8f0:	mov    r15d,DWORD PTR [rsp+0x31c]
   4f8f8:	mov    r13,QWORD PTR [rsp+0xf0]
   4f900:	mov    QWORD PTR [rsp+0xd0],r12
   4f908:	mov    r12d,DWORD PTR [rsp+0x334]
   4f910:	movsxd rax,DWORD PTR [rbp+0x4]
   4f914:	imul   rcx,rax,0x38
   4f918:	mov    rax,QWORD PTR [rbx+rcx*1]
   4f91c:	imul   rsi,rax,0x18
   4f920:	mov    rax,rbp
   4f923:	sub    rax,QWORD PTR [rdi+0x88]
   4f92a:	movabs rdx,0x2aaaaaaaaaaaaaab
   4f934:	imul   rdx
   4f937:	sar    rdx,0x2
   4f93b:	mov    rax,rdx
   4f93e:	shr    rax,0x3f
   4f942:	add    rdx,rax
   4f945:	mov    rax,rdx
   4f948:	sub    eax,0x1
   4f94b:	movsxd rax,eax
   4f94e:	mov    QWORD PTR [rbx+rcx*1],rax
   4f952:	mov    eax,DWORD PTR [r13+rsi*1+0x8]
   4f957:	sub    eax,0x1
   4f95a:	movsxd rax,eax
   4f95d:	imul   rax,rax,0x18
   4f961:	lea    rbp,[r13+rax*1+0x0]
   4f966:	mov    DWORD PTR [rsp+0x31c],r15d
   4f96e:	mov    QWORD PTR [rsp+0xf0],r13
   4f976:	mov    DWORD PTR [rsp+0x334],r12d
   4f97e:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   4f983:	mov    r15d,DWORD PTR [rsp+0x31c]
   4f98b:	mov    r13,QWORD PTR [rsp+0xf0]
   4f993:	mov    QWORD PTR [rsp+0xd0],r12
   4f99b:	mov    r12d,DWORD PTR [rsp+0x334]
   4f9a3:	movsxd rax,DWORD PTR [rbp+0x4]
   4f9a7:	imul   rcx,rax,0x38
   4f9ab:	mov    WORD PTR [rbx+rcx*1+0x14],0x4
   4f9b2:	mov    rsi,QWORD PTR [rbx+rcx*1]
   4f9b6:	mov    rax,rbp
   4f9b9:	sub    rax,r13
   4f9bc:	movabs rdx,0x2aaaaaaaaaaaaaab
   4f9c6:	imul   rdx
   4f9c9:	sar    rdx,0x2
   4f9cd:	mov    rax,rdx
   4f9d0:	shr    rax,0x3f
   4f9d4:	add    rdx,rax
   4f9d7:	mov    rax,rdx
   4f9da:	movsxd rax,eax
   4f9dd:	mov    QWORD PTR [rbx+rcx*1],rax
   4f9e1:	movsxd rax,esi
   4f9e4:	imul   rax,rax,0x18
   4f9e8:	lea    rbp,[r13+rax*1+0x0]
   4f9ed:	mov    DWORD PTR [rsp+0x31c],r15d
   4f9f5:	mov    QWORD PTR [rsp+0xf0],r13
   4f9fd:	mov    DWORD PTR [rsp+0x334],r12d
   4fa05:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   4fa0a:	mov    r15d,DWORD PTR [rsp+0x31c]
   4fa12:	mov    r13,QWORD PTR [rsp+0xf0]
   4fa1a:	mov    QWORD PTR [rsp+0xd0],r12
   4fa22:	mov    r12d,DWORD PTR [rsp+0x334]
   4fa2a:	movsxd rax,DWORD PTR [rbp+0xc]
   4fa2e:	imul   rax,rax,0x38
   4fa32:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   4fa37:	and    eax,0x1
   4fa3a:	test   eax,eax
   4fa3c:	jne    4fa5b <sqlite3VdbeExec+0x5bb>
   4fa3e:	mov    DWORD PTR [rsp+0x31c],r15d
   4fa46:	mov    QWORD PTR [rsp+0xf0],r13
   4fa4e:	mov    DWORD PTR [rsp+0x334],r12d
   4fa56:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   4fa5b:	cmp    QWORD PTR [rdi+0x108],0x0
   4fa63:	je     4fb14 <sqlite3VdbeExec+0x674>
   4fa69:	cmp    DWORD PTR [rbp+0x4],0x0
   4fa6d:	jne    4fb14 <sqlite3VdbeExec+0x674>
   4fa73:	mov    rax,QWORD PTR [rdi+0x108]
   4fa7a:	mov    rcx,QWORD PTR [rax+0x8]
   4fa7e:	mov    QWORD PTR [rdi+0x108],rcx
   4fa85:	mov    ecx,DWORD PTR [rdi+0x118]
   4fa8b:	sub    ecx,0x1
   4fa8e:	mov    DWORD PTR [rdi+0x118],ecx
   4fa94:	mov    rcx,QWORD PTR [rdi+0x38]
   4fa98:	mov    QWORD PTR [r14+0x78],rcx
   4fa9c:	mov    rdx,QWORD PTR [r14+0x80]
   4faa3:	add    rcx,rdx
   4faa6:	mov    QWORD PTR [r14+0x80],rcx
   4faad:	mov    QWORD PTR [rsp+0xb0],rdi
   4fab5:	mov    rdi,rax
   4fab8:	call   4fabd <sqlite3VdbeExec+0x61d>
   4fabd:	mov    rdi,QWORD PTR [rsp+0xb0]
   4fac5:	cmp    DWORD PTR [rbp+0x8],0x4
   4fac9:	jne    4fae0 <sqlite3VdbeExec+0x640>
   4facb:	mov    rcx,QWORD PTR [rdi+0x88]
   4fad2:	movsxd rax,eax
   4fad5:	imul   rax,rax,0x18
   4fad9:	mov    eax,DWORD PTR [rcx+rax*1+0x8]
   4fadd:	sub    eax,0x1
   4fae0:	mov    r13,QWORD PTR [rdi+0x88]
   4fae7:	mov    rbx,QWORD PTR [rdi+0x68]
   4faeb:	movsxd rax,eax
   4faee:	imul   rax,rax,0x18
   4faf2:	lea    rbp,[r13+rax*1+0x0]
   4faf7:	mov    DWORD PTR [rsp+0x31c],r15d
   4faff:	mov    QWORD PTR [rsp+0xf0],r13
   4fb07:	mov    DWORD PTR [rsp+0x334],r12d
   4fb0f:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   4fb14:	mov    eax,DWORD PTR [rbp+0x4]
   4fb17:	mov    DWORD PTR [rdi+0x34],eax
   4fb1a:	mov    eax,DWORD PTR [rbp+0x8]
   4fb1d:	mov    BYTE PTR [rdi+0xc4],al
   4fb23:	cmp    DWORD PTR [rdi+0x34],0x0
   4fb27:	je     4fc92 <sqlite3VdbeExec+0x7f2>
   4fb2d:	cmp    DWORD PTR [rbp+0xc],0x0
   4fb31:	jle    4fbcb <sqlite3VdbeExec+0x72b>
   4fb37:	cmp    BYTE PTR [rbp+0x1],0x0
   4fb3b:	jne    4fbcb <sqlite3VdbeExec+0x72b>
   4fb41:	movsxd rax,DWORD PTR [rbp+0xc]
   4fb45:	imul   rax,rax,0x38
   4fb49:	add    rax,rbx
   4fb4c:	test   rax,rax
   4fb4f:	jne    4fb55 <sqlite3VdbeExec+0x6b5>
   4fb51:	xor    eax,eax
   4fb53:	jmp    4fba2 <sqlite3VdbeExec+0x702>
   4fb55:	movzx  ecx,WORD PTR [rax+0x14]
   4fb59:	and    ecx,0x202
   4fb5f:	cmp    ecx,0x202
   4fb65:	jne    4fb73 <sqlite3VdbeExec+0x6d3>
   4fb67:	cmp    BYTE PTR [rax+0x16],0x1
   4fb6b:	jne    4fb73 <sqlite3VdbeExec+0x6d3>
   4fb6d:	mov    rax,QWORD PTR [rax+0x8]
   4fb71:	jmp    4fba2 <sqlite3VdbeExec+0x702>
   4fb73:	movzx  ecx,WORD PTR [rax+0x14]
   4fb77:	and    ecx,0x1
   4fb7a:	test   ecx,ecx
   4fb7c:	je     4fb82 <sqlite3VdbeExec+0x6e2>
   4fb7e:	xor    eax,eax
   4fb80:	jmp    4fba2 <sqlite3VdbeExec+0x702>
   4fb82:	mov    ecx,0x1
   4fb87:	mov    QWORD PTR [rsp+0xb0],rdi
   4fb8f:	mov    rdi,rax
   4fb92:	mov    rsi,rcx
   4fb95:	call   4fb9a <sqlite3VdbeExec+0x6fa>
   4fb9a:	mov    rdi,QWORD PTR [rsp+0xb0]
   4fba2:	lea    rcx,[rip+0x0]        # 4fba9 <sqlite3VdbeExec+0x709>
   4fba9:	mov    QWORD PTR [rsp+0xb0],rdi
   4fbb1:	mov    rsi,rcx
   4fbb4:	mov    rdx,rax
   4fbb7:	xor    eax,eax
   4fbb9:	call   4fbbe <sqlite3VdbeExec+0x71e>
   4fbbe:	mov    rdi,QWORD PTR [rsp+0xb0]
   4fbc6:	jmp    4fc71 <sqlite3VdbeExec+0x7d1>
   4fbcb:	cmp    WORD PTR [rbp+0x2],0x0
   4fbd0:	je     4fc49 <sqlite3VdbeExec+0x7a9>
   4fbd2:	lea    rax,[rip+0x0]        # 4fbd9 <sqlite3VdbeExec+0x739>
   4fbd9:	lea    rcx,[rip+0x0]        # 4fbe0 <sqlite3VdbeExec+0x740>
   4fbe0:	movzx  edx,WORD PTR [rbp+0x2]
   4fbe4:	add    rdx,0xffffffffffffffff
   4fbe8:	mov    rcx,QWORD PTR [rcx+rdx*8]
   4fbec:	mov    QWORD PTR [rsp+0xb0],rdi
   4fbf4:	mov    rsi,rax
   4fbf7:	mov    rdx,rcx
   4fbfa:	xor    eax,eax
   4fbfc:	call   4fc01 <sqlite3VdbeExec+0x761>
   4fc01:	mov    rdi,QWORD PTR [rsp+0xb0]
   4fc09:	cmp    QWORD PTR [rbp+0x10],0x0
   4fc0e:	je     4fc71 <sqlite3VdbeExec+0x7d1>
   4fc10:	lea    rax,[rip+0x0]        # 4fc17 <sqlite3VdbeExec+0x777>
   4fc17:	mov    rcx,QWORD PTR [rdi+0xa8]
   4fc1e:	mov    rdx,QWORD PTR [rbp+0x10]
   4fc22:	mov    rdi,r14
   4fc25:	mov    rsi,rax
   4fc28:	mov    r11,rdx
   4fc2b:	mov    rdx,rcx
   4fc2e:	mov    rcx,r11
   4fc31:	xor    eax,eax
   4fc33:	call   4fc38 <sqlite3VdbeExec+0x798>
   4fc38:	mov    rdi,QWORD PTR [rsp+0xb0]
   4fc40:	mov    QWORD PTR [rdi+0xa8],rax
   4fc47:	jmp    4fc71 <sqlite3VdbeExec+0x7d1>
   4fc49:	lea    rax,[rip+0x0]        # 4fc50 <sqlite3VdbeExec+0x7b0>
   4fc50:	mov    rcx,QWORD PTR [rbp+0x10]
   4fc54:	mov    QWORD PTR [rsp+0xb0],rdi
   4fc5c:	mov    rsi,rax
   4fc5f:	mov    rdx,rcx
   4fc62:	xor    eax,eax
   4fc64:	call   4fc69 <sqlite3VdbeExec+0x7c9>
   4fc69:	mov    rdi,QWORD PTR [rsp+0xb0]
   4fc71:	mov    eax,DWORD PTR [rbp+0x4]
   4fc74:	mov    QWORD PTR [rsp+0xb0],rdi
   4fc7c:	mov    rsi,rax
   4fc7f:	mov    rdx,rbp
   4fc82:	mov    rcx,r13
   4fc85:	call   4fc8a <sqlite3VdbeExec+0x7ea>
   4fc8a:	mov    rdi,QWORD PTR [rsp+0xb0]
   4fc92:	mov    QWORD PTR [rsp+0xb0],rdi
   4fc9a:	call   4fc9f <sqlite3VdbeExec+0x7ff>
   4fc9f:	mov    ebx,eax
   4fca1:	mov    rdi,QWORD PTR [rsp+0xb0]
   4fca9:	cmp    ebx,0x5
   4fcac:	jne    4fcb7 <sqlite3VdbeExec+0x817>
   4fcae:	mov    DWORD PTR [rdi+0x34],0x5
   4fcb5:	jmp    4fcc9 <sqlite3VdbeExec+0x829>
   4fcb7:	cmp    DWORD PTR [rdi+0x34],0x0
   4fcbb:	je     4fcc4 <sqlite3VdbeExec+0x824>
   4fcbd:	mov    ebx,0x1
   4fcc2:	jmp    4fcc9 <sqlite3VdbeExec+0x829>
   4fcc4:	mov    ebx,0x65
   4fcc9:	mov    QWORD PTR [rsp+0xf0],r13
   4fcd1:	mov    r12,rbx
   4fcd4:	mov    r13d,DWORD PTR [rsp+0x320]
   4fcdc:	mov    r15,QWORD PTR [rsp+0xd0]
   4fce4:	mov    rbx,QWORD PTR [rsp+0xf8]
   4fcec:	jmp    659c6 <sqlite3VdbeExec+0x16526>
   4fcf1:	mov    r15d,DWORD PTR [rsp+0x31c]
   4fcf9:	mov    r13,QWORD PTR [rsp+0xf0]
   4fd01:	mov    QWORD PTR [rsp+0xd0],r12
   4fd09:	mov    r12d,DWORD PTR [rsp+0x334]
   4fd11:	mov    rax,QWORD PTR [rdi+0x68]
   4fd15:	movsxd rcx,DWORD PTR [rbp+0x8]
   4fd19:	imul   rcx,rcx,0x38
   4fd1d:	lea    rdx,[rax+rcx*1]
   4fd21:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4fd26:	and    eax,0x9000
   4fd2b:	test   eax,eax
   4fd2d:	je     4fd4c <sqlite3VdbeExec+0x8ac>
   4fd2f:	mov    QWORD PTR [rsp+0xb0],rdi
   4fd37:	mov    rdi,rdx
   4fd3a:	call   4fd3f <sqlite3VdbeExec+0x89f>
   4fd3f:	mov    rdi,QWORD PTR [rsp+0xb0]
   4fd47:	mov    rdx,rax
   4fd4a:	jmp    4fd52 <sqlite3VdbeExec+0x8b2>
   4fd4c:	mov    WORD PTR [rdx+0x14],0x4
   4fd52:	movsxd rax,DWORD PTR [rbp+0x4]
   4fd56:	mov    QWORD PTR [rdx],rax
   4fd59:	mov    DWORD PTR [rsp+0x31c],r15d
   4fd61:	mov    QWORD PTR [rsp+0xf0],r13
   4fd69:	mov    DWORD PTR [rsp+0x334],r12d
   4fd71:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   4fd76:	mov    r15d,DWORD PTR [rsp+0x31c]
   4fd7e:	mov    r13,QWORD PTR [rsp+0xf0]
   4fd86:	mov    QWORD PTR [rsp+0xd0],r12
   4fd8e:	mov    r12d,DWORD PTR [rsp+0x334]
   4fd96:	mov    rax,QWORD PTR [rdi+0x68]
   4fd9a:	movsxd rcx,DWORD PTR [rbp+0x8]
   4fd9e:	imul   rcx,rcx,0x38
   4fda2:	lea    rdx,[rax+rcx*1]
   4fda6:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4fdab:	and    eax,0x9000
   4fdb0:	test   eax,eax
   4fdb2:	je     4fdd1 <sqlite3VdbeExec+0x931>
   4fdb4:	mov    QWORD PTR [rsp+0xb0],rdi
   4fdbc:	mov    rdi,rdx
   4fdbf:	call   4fdc4 <sqlite3VdbeExec+0x924>
   4fdc4:	mov    rdi,QWORD PTR [rsp+0xb0]
   4fdcc:	mov    rdx,rax
   4fdcf:	jmp    4fdd7 <sqlite3VdbeExec+0x937>
   4fdd1:	mov    WORD PTR [rdx+0x14],0x4
   4fdd7:	mov    rax,QWORD PTR [rbp+0x10]
   4fddb:	mov    rax,QWORD PTR [rax]
   4fdde:	mov    QWORD PTR [rdx],rax
   4fde1:	mov    DWORD PTR [rsp+0x31c],r15d
   4fde9:	mov    QWORD PTR [rsp+0xf0],r13
   4fdf1:	mov    DWORD PTR [rsp+0x334],r12d
   4fdf9:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   4fdfe:	mov    r15d,DWORD PTR [rsp+0x31c]
   4fe06:	mov    r13,QWORD PTR [rsp+0xf0]
   4fe0e:	mov    QWORD PTR [rsp+0xd0],r12
   4fe16:	mov    r12d,DWORD PTR [rsp+0x334]
   4fe1e:	mov    rax,QWORD PTR [rdi+0x68]
   4fe22:	movsxd rcx,DWORD PTR [rbp+0x8]
   4fe26:	imul   rcx,rcx,0x38
   4fe2a:	lea    rdx,[rax+rcx*1]
   4fe2e:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4fe33:	and    eax,0x9000
   4fe38:	test   eax,eax
   4fe3a:	je     4fe59 <sqlite3VdbeExec+0x9b9>
   4fe3c:	mov    QWORD PTR [rsp+0xb0],rdi
   4fe44:	mov    rdi,rdx
   4fe47:	call   4fe4c <sqlite3VdbeExec+0x9ac>
   4fe4c:	mov    rdi,QWORD PTR [rsp+0xb0]
   4fe54:	mov    rdx,rax
   4fe57:	jmp    4fe5f <sqlite3VdbeExec+0x9bf>
   4fe59:	mov    WORD PTR [rdx+0x14],0x4
   4fe5f:	mov    WORD PTR [rdx+0x14],0x8
   4fe65:	mov    rax,QWORD PTR [rbp+0x10]
   4fe69:	movsd  xmm0,QWORD PTR [rax]
   4fe6d:	movsd  QWORD PTR [rdx],xmm0
   4fe71:	mov    DWORD PTR [rsp+0x31c],r15d
   4fe79:	mov    QWORD PTR [rsp+0xf0],r13
   4fe81:	mov    DWORD PTR [rsp+0x334],r12d
   4fe89:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   4fe8e:	mov    r15d,DWORD PTR [rsp+0x31c]
   4fe96:	mov    r13,QWORD PTR [rsp+0xf0]
   4fe9e:	mov    QWORD PTR [rsp+0xd0],r12
   4fea6:	mov    r12d,DWORD PTR [rsp+0x334]
   4feae:	mov    rax,QWORD PTR [rdi+0x68]
   4feb2:	movsxd rcx,DWORD PTR [rbp+0x8]
   4feb6:	imul   rcx,rcx,0x38
   4feba:	mov    DWORD PTR [rsp+0x334],r12d
   4fec2:	lea    r12,[rax+rcx*1]
   4fec6:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4fecb:	and    eax,0x9000
   4fed0:	test   eax,eax
   4fed2:	je     4fef1 <sqlite3VdbeExec+0xa51>
   4fed4:	mov    QWORD PTR [rsp+0xb0],rdi
   4fedc:	mov    rdi,r12
   4fedf:	call   4fee4 <sqlite3VdbeExec+0xa44>
   4fee4:	mov    r12,rax
   4fee7:	mov    rdi,QWORD PTR [rsp+0xb0]
   4feef:	jmp    4fef9 <sqlite3VdbeExec+0xa59>
   4fef1:	mov    WORD PTR [r12+0x14],0x4
   4fef9:	mov    rax,QWORD PTR [rbp+0x10]
   4fefd:	test   rax,rax
   4ff00:	jne    4ff06 <sqlite3VdbeExec+0xa66>
   4ff02:	xor    eax,eax
   4ff04:	jmp    4ff23 <sqlite3VdbeExec+0xa83>
   4ff06:	mov    QWORD PTR [rsp+0xb0],rdi
   4ff0e:	mov    rdi,rax
   4ff11:	call   4ff16 <sqlite3VdbeExec+0xa76>
   4ff16:	and    eax,0x3fffffff
   4ff1b:	mov    rdi,QWORD PTR [rsp+0xb0]
   4ff23:	mov    DWORD PTR [rbp+0x4],eax
   4ff26:	mov    eax,r15d
   4ff29:	cmp    eax,0x1
   4ff2c:	jne    4ff3b <sqlite3VdbeExec+0xa9b>
   4ff2e:	mov    QWORD PTR [rsp+0xf0],r13
   4ff36:	jmp    5000b <sqlite3VdbeExec+0xb6b>
   4ff3b:	mov    rax,QWORD PTR [rbp+0x10]
   4ff3f:	mov    rcx,0xffffffffffffffff
   4ff46:	xor    edx,edx
   4ff48:	mov    esi,0x1
   4ff4d:	mov    QWORD PTR [rsp+0xf0],r13
   4ff55:	mov    QWORD PTR [rsp+0xb0],rdi
   4ff5d:	mov    rdi,r12
   4ff60:	mov    r8,rdx
   4ff63:	mov    rdx,rcx
   4ff66:	mov    rcx,rsi
   4ff69:	mov    rsi,rax
   4ff6c:	call   4ff71 <sqlite3VdbeExec+0xad1>
   4ff71:	mov    r13d,eax
   4ff74:	mov    rdi,QWORD PTR [rsp+0xb0]
   4ff7c:	test   r13d,r13d
   4ff7f:	je     4ff91 <sqlite3VdbeExec+0xaf1>
   4ff81:	mov    QWORD PTR [rsp+0xe8],rbp
   4ff89:	mov    rbp,r14
   4ff8c:	jmp    53cb6 <sqlite3VdbeExec+0x4816>
   4ff91:	mov    eax,r15d
   4ff94:	movzx  ecx,WORD PTR [r12+0x14]
   4ff9a:	and    ecx,0x2
   4ff9d:	test   ecx,ecx
   4ff9f:	jne    50066 <sqlite3VdbeExec+0xbc6>
   4ffa5:	mov    BYTE PTR [r12+0x16],al
   4ffaa:	mov    DWORD PTR [r12+0x20],0x0
   4ffb3:	movzx  eax,WORD PTR [r12+0x14]
   4ffb9:	or     eax,0x2000
   4ffbe:	mov    WORD PTR [r12+0x14],ax
   4ffc4:	cmp    BYTE PTR [rbp+0x1],0xf9
   4ffc8:	jne    4ffee <sqlite3VdbeExec+0xb4e>
   4ffca:	mov    rax,QWORD PTR [rbp+0x10]
   4ffce:	test   rax,rax
   4ffd1:	je     4ffee <sqlite3VdbeExec+0xb4e>
   4ffd3:	mov    QWORD PTR [rsp+0xb0],rdi
   4ffdb:	mov    rdi,r14
   4ffde:	mov    rsi,rax
   4ffe1:	call   4ffe6 <sqlite3VdbeExec+0xb46>
   4ffe6:	mov    rdi,QWORD PTR [rsp+0xb0]
   4ffee:	mov    BYTE PTR [rbp+0x1],0xf9
   4fff2:	mov    rax,QWORD PTR [r12+0x8]
   4fff7:	mov    QWORD PTR [rbp+0x10],rax
   4fffb:	mov    eax,DWORD PTR [r12+0x10]
   50000:	mov    DWORD PTR [rbp+0x4],eax
   50003:	mov    DWORD PTR [rsp+0x32c],r13d
   5000b:	mov    eax,DWORD PTR [rbp+0x4]
   5000e:	cmp    eax,DWORD PTR [r14+0x88]
   50015:	jle    50027 <sqlite3VdbeExec+0xb87>
   50017:	mov    QWORD PTR [rsp+0xe8],rbp
   5001f:	mov    rbp,r14
   50022:	jmp    53cb6 <sqlite3VdbeExec+0x4816>
   50027:	mov    BYTE PTR [rbp+0x0],0x4b
   5002b:	mov    rax,QWORD PTR [rdi+0x68]
   5002f:	movsxd rcx,DWORD PTR [rbp+0x8]
   50033:	imul   rcx,rcx,0x38
   50037:	lea    rdx,[rax+rcx*1]
   5003b:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   50040:	and    eax,0x9000
   50045:	test   eax,eax
   50047:	je     500c4 <sqlite3VdbeExec+0xc24>
   50049:	mov    QWORD PTR [rsp+0xb0],rdi
   50051:	mov    rdi,rdx
   50054:	call   50059 <sqlite3VdbeExec+0xbb9>
   50059:	mov    rdi,QWORD PTR [rsp+0xb0]
   50061:	mov    rdx,rax
   50064:	jmp    500ca <sqlite3VdbeExec+0xc2a>
   50066:	movzx  ecx,BYTE PTR [r12+0x16]
   5006c:	cmp    ecx,eax
   5006e:	je     4ffaa <sqlite3VdbeExec+0xb0a>
   50074:	mov    rdi,r12
   50077:	mov    rsi,rax
   5007a:	call   5007f <sqlite3VdbeExec+0xbdf>
   5007f:	mov    rdi,QWORD PTR [rsp+0xb0]
   50087:	mov    QWORD PTR [rsp+0xc8],r14
   5008f:	xor    r14d,r14d
   50092:	cmp    r14d,eax
   50095:	jne    500a4 <sqlite3VdbeExec+0xc04>
   50097:	mov    r14,QWORD PTR [rsp+0xc8]
   5009f:	jmp    4ffaa <sqlite3VdbeExec+0xb0a>
   500a4:	mov    r14,QWORD PTR [rsp+0xc8]
   500ac:	mov    r13,QWORD PTR [rsp+0xf0]
   500b4:	mov    rbx,rbp
   500b7:	mov    rbp,QWORD PTR [rsp+0xf8]
   500bf:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   500c4:	mov    WORD PTR [rdx+0x14],0x4
   500ca:	mov    WORD PTR [rdx+0x14],0x2202
   500d0:	mov    rax,QWORD PTR [rbp+0x10]
   500d4:	mov    QWORD PTR [rdx+0x8],rax
   500d8:	mov    eax,DWORD PTR [rbp+0x4]
   500db:	mov    DWORD PTR [rdx+0x10],eax
   500de:	mov    BYTE PTR [rdx+0x16],r15b
   500e2:	cmp    DWORD PTR [rbp+0xc],0x0
   500e6:	jle    50103 <sqlite3VdbeExec+0xc63>
   500e8:	movsxd rax,DWORD PTR [rbp+0xc]
   500ec:	imul   rax,rax,0x38
   500f0:	mov    rax,QWORD PTR [rbx+rax*1]
   500f4:	movzx  ecx,WORD PTR [rbp+0x2]
   500f8:	cmp    rax,rcx
   500fb:	jne    50103 <sqlite3VdbeExec+0xc63>
   500fd:	mov    WORD PTR [rdx+0x14],0x2210
   50103:	mov    DWORD PTR [rsp+0x31c],r15d
   5010b:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   50110:	mov    r15d,DWORD PTR [rsp+0x31c]
   50118:	mov    r13,QWORD PTR [rsp+0xf0]
   50120:	mov    QWORD PTR [rsp+0xd0],r12
   50128:	mov    r12d,DWORD PTR [rsp+0x334]
   50130:	mov    rax,QWORD PTR [rdi+0x68]
   50134:	movsxd rcx,DWORD PTR [rbp+0x8]
   50138:	imul   rcx,rcx,0x38
   5013c:	mov    DWORD PTR [rsp+0x334],r12d
   50144:	lea    r12,[rax+rcx*1]
   50148:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5014d:	and    eax,0x9000
   50152:	test   eax,eax
   50154:	je     50173 <sqlite3VdbeExec+0xcd3>
   50156:	mov    QWORD PTR [rsp+0xb0],rdi
   5015e:	mov    rdi,r12
   50161:	call   50166 <sqlite3VdbeExec+0xcc6>
   50166:	mov    r12,rax
   50169:	mov    rdi,QWORD PTR [rsp+0xb0]
   50171:	jmp    5017b <sqlite3VdbeExec+0xcdb>
   50173:	mov    WORD PTR [r12+0x14],0x4
   5017b:	mov    eax,DWORD PTR [rbp+0xc]
   5017e:	mov    QWORD PTR [rsp+0x108],r12
   50186:	mov    r12d,eax
   50189:	sub    r12d,DWORD PTR [rbp+0x8]
   5018d:	cmp    DWORD PTR [rbp+0x4],0x0
   50191:	je     501a3 <sqlite3VdbeExec+0xd03>
   50193:	mov    DWORD PTR [rsp+0x338],r12d
   5019b:	mov    r12d,0x101
   501a1:	jmp    501b1 <sqlite3VdbeExec+0xd11>
   501a3:	mov    DWORD PTR [rsp+0x338],r12d
   501ab:	mov    r12d,0x1
   501b1:	mov    QWORD PTR [rsp+0xf0],r13
   501b9:	mov    r13,QWORD PTR [rsp+0x108]
   501c1:	mov    WORD PTR [r13+0x14],r12w
   501c6:	mov    DWORD PTR [r13+0x10],0x0
   501ce:	mov    DWORD PTR [rsp+0x31c],r15d
   501d6:	mov    r15,r13
   501d9:	mov    r13d,DWORD PTR [rsp+0x338]
   501e1:	jmp    50206 <sqlite3VdbeExec+0xd66>
   501e3:	mov    r15,r14
   501e6:	mov    r14,QWORD PTR [rsp+0xc8]
   501ee:	mov    WORD PTR [r15+0x14],0x1
   501f5:	mov    WORD PTR [r15+0x14],r12w
   501fa:	mov    DWORD PTR [r15+0x10],0x0
   50202:	sub    r13d,0x1
   50206:	test   r13d,r13d
   50209:	jle    5024a <sqlite3VdbeExec+0xdaa>
   5020b:	mov    QWORD PTR [rsp+0xc8],r14
   50213:	lea    r14,[r15+0x38]
   50217:	movzx  eax,WORD PTR [r15+0x4c]
   5021c:	and    eax,0x9000
   50221:	test   eax,eax
   50223:	je     501e3 <sqlite3VdbeExec+0xd43>
   50225:	mov    QWORD PTR [rsp+0xb0],rdi
   5022d:	mov    rdi,r14
   50230:	call   50235 <sqlite3VdbeExec+0xd95>
   50235:	mov    rdi,QWORD PTR [rsp+0xb0]
   5023d:	mov    r15,r14
   50240:	mov    r14,QWORD PTR [rsp+0xc8]
   50248:	jmp    501f5 <sqlite3VdbeExec+0xd55>
   5024a:	mov    QWORD PTR [rsp+0xc8],r14
   50252:	mov    r14,QWORD PTR [rsp+0xc8]
   5025a:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5025f:	mov    QWORD PTR [rsp+0xc8],r14
   50267:	mov    QWORD PTR [rsp+0xd0],r12
   5026f:	movsxd rax,DWORD PTR [rbp+0x4]
   50273:	imul   rax,rax,0x38
   50277:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   5027c:	and    ecx,0xffffffc0
   5027f:	or     ecx,0x1
   50282:	mov    WORD PTR [rbx+rax*1+0x14],cx
   50287:	mov    r14,QWORD PTR [rsp+0xc8]
   5028f:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   50294:	mov    QWORD PTR [rsp+0xc8],r14
   5029c:	mov    QWORD PTR [rsp+0xd0],r12
   502a4:	mov    rax,QWORD PTR [rdi+0x68]
   502a8:	movsxd rcx,DWORD PTR [rbp+0x8]
   502ac:	imul   rcx,rcx,0x38
   502b0:	lea    r12,[rax+rcx*1]
   502b4:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   502b9:	and    eax,0x9000
   502be:	test   eax,eax
   502c0:	je     502df <sqlite3VdbeExec+0xe3f>
   502c2:	mov    QWORD PTR [rsp+0xb0],rdi
   502ca:	mov    rdi,r12
   502cd:	call   502d2 <sqlite3VdbeExec+0xe32>
   502d2:	mov    r12,rax
   502d5:	mov    rdi,QWORD PTR [rsp+0xb0]
   502dd:	jmp    502e7 <sqlite3VdbeExec+0xe47>
   502df:	mov    WORD PTR [r12+0x14],0x4
   502e7:	cmp    QWORD PTR [rbp+0x10],0x0
   502ec:	jne    50414 <sqlite3VdbeExec+0xf74>
   502f2:	mov    r13d,DWORD PTR [rbp+0x4]
   502f6:	movzx  eax,WORD PTR [r12+0x14]
   502fc:	and    eax,0x9000
   50301:	test   eax,eax
   50303:	jne    5030d <sqlite3VdbeExec+0xe6d>
   50305:	cmp    DWORD PTR [r12+0x20],0x0
   5030b:	je     50325 <sqlite3VdbeExec+0xe85>
   5030d:	mov    QWORD PTR [rsp+0xb0],rdi
   50315:	mov    rdi,r12
   50318:	call   5031d <sqlite3VdbeExec+0xe7d>
   5031d:	mov    rdi,QWORD PTR [rsp+0xb0]
   50325:	mov    WORD PTR [r12+0x14],0x410
   5032d:	mov    DWORD PTR [r12+0x10],0x0
   50336:	xor    eax,eax
   50338:	test   r13d,r13d
   5033b:	cmovge eax,r13d
   5033f:	mov    DWORD PTR [r12],eax
   50343:	mov    BYTE PTR [r12+0x16],0x1
   50349:	mov    QWORD PTR [r12+0x8],0x0
   50352:	mov    eax,DWORD PTR [r12+0x10]
   50357:	add    eax,DWORD PTR [r12]
   5035b:	test   eax,eax
   5035d:	jg     5037e <sqlite3VdbeExec+0xede>
   5035f:	movzx  eax,WORD PTR [r12+0x14]
   50365:	and    eax,0x10
   50368:	test   eax,eax
   5036a:	jne    50379 <sqlite3VdbeExec+0xed9>
   5036c:	mov    r15d,DWORD PTR [rsp+0x31c]
   50374:	jmp    5044c <sqlite3VdbeExec+0xfac>
   50379:	mov    eax,0x1
   5037e:	mov    ecx,0x1
   50383:	mov    QWORD PTR [rsp+0xb0],rdi
   5038b:	mov    rdi,r12
   5038e:	mov    rsi,rax
   50391:	mov    rdx,rcx
   50394:	call   50399 <sqlite3VdbeExec+0xef9>
   50399:	mov    rdi,QWORD PTR [rsp+0xb0]
   503a1:	test   eax,eax
   503a3:	jne    503f4 <sqlite3VdbeExec+0xf54>
   503a5:	mov    rax,QWORD PTR [r12+0x8]
   503aa:	movsxd rcx,DWORD PTR [r12+0x10]
   503af:	add    rax,rcx
   503b2:	xor    ecx,ecx
   503b4:	movsxd rdx,DWORD PTR [r12]
   503b8:	mov    rdi,rax
   503bb:	mov    rsi,rcx
   503be:	call   503c3 <sqlite3VdbeExec+0xf23>
   503c3:	mov    eax,DWORD PTR [r12+0x10]
   503c8:	add    eax,DWORD PTR [r12]
   503cc:	mov    DWORD PTR [r12+0x10],eax
   503d1:	movzx  eax,WORD PTR [r12+0x14]
   503d7:	and    eax,0xfffff9ff
   503dc:	mov    WORD PTR [r12+0x14],ax
   503e2:	mov    rdi,QWORD PTR [rsp+0xb0]
   503ea:	mov    r15d,DWORD PTR [rsp+0x31c]
   503f2:	jmp    5044c <sqlite3VdbeExec+0xfac>
   503f4:	mov    r14,QWORD PTR [rsp+0xc8]
   503fc:	mov    r13,QWORD PTR [rsp+0xf0]
   50404:	mov    rbx,rbp
   50407:	mov    rbp,QWORD PTR [rsp+0xf8]
   5040f:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50414:	mov    r15d,DWORD PTR [rsp+0x31c]
   5041c:	mov    rax,QWORD PTR [rbp+0x10]
   50420:	movsxd rcx,DWORD PTR [rbp+0x4]
   50424:	xor    edx,edx
   50426:	xor    esi,esi
   50428:	mov    QWORD PTR [rsp+0xb0],rdi
   50430:	mov    rdi,r12
   50433:	mov    r8,rdx
   50436:	mov    rdx,rcx
   50439:	mov    rcx,rsi
   5043c:	mov    rsi,rax
   5043f:	call   50444 <sqlite3VdbeExec+0xfa4>
   50444:	mov    rdi,QWORD PTR [rsp+0xb0]
   5044c:	mov    BYTE PTR [r12+0x16],r15b
   50451:	mov    r14,QWORD PTR [rsp+0xc8]
   50459:	mov    DWORD PTR [rsp+0x31c],r15d
   50461:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   50466:	mov    QWORD PTR [rsp+0xc8],r14
   5046e:	mov    r15d,DWORD PTR [rsp+0x31c]
   50476:	mov    QWORD PTR [rsp+0xd0],r12
   5047e:	mov    r12,QWORD PTR [rdi+0x80]
   50485:	mov    eax,DWORD PTR [rbp+0x4]
   50488:	sub    eax,0x1
   5048b:	movsxd rax,eax
   5048e:	imul   r13,rax,0x38
   50492:	movzx  eax,WORD PTR [r12+r13*1+0x14]
   50498:	and    eax,0x12
   5049b:	test   eax,eax
   5049d:	je     504da <sqlite3VdbeExec+0x103a>
   5049f:	mov    eax,DWORD PTR [r12+r13*1+0x10]
   504a4:	movzx  ecx,WORD PTR [r12+r13*1+0x14]
   504aa:	and    ecx,0x400
   504b0:	test   ecx,ecx
   504b2:	je     504b8 <sqlite3VdbeExec+0x1018>
   504b4:	add    eax,DWORD PTR [r12+r13*1]
   504b8:	mov    rcx,QWORD PTR [r12+r13*1+0x18]
   504bd:	cmp    eax,DWORD PTR [rcx+0x88]
   504c3:	jle    504da <sqlite3VdbeExec+0x103a>
   504c5:	mov    QWORD PTR [rsp+0xe8],rbp
   504cd:	mov    rbp,QWORD PTR [rsp+0xc8]
   504d5:	jmp    53cb6 <sqlite3VdbeExec+0x4816>
   504da:	movsxd rax,DWORD PTR [rbp+0x8]
   504de:	imul   rax,rax,0x38
   504e2:	lea    r14,[rbx+rax*1]
   504e6:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   504eb:	and    eax,0x9000
   504f0:	test   eax,eax
   504f2:	je     50523 <sqlite3VdbeExec+0x1083>
   504f4:	movzx  eax,WORD PTR [r14+0x14]
   504f9:	and    eax,0x9000
   504fe:	test   eax,eax
   50500:	je     5051c <sqlite3VdbeExec+0x107c>
   50502:	mov    QWORD PTR [rsp+0xb0],rdi
   5050a:	mov    rdi,r14
   5050d:	call   50512 <sqlite3VdbeExec+0x1072>
   50512:	mov    rdi,QWORD PTR [rsp+0xb0]
   5051a:	jmp    50523 <sqlite3VdbeExec+0x1083>
   5051c:	mov    WORD PTR [r14+0x14],0x1
   50523:	mov    rax,QWORD PTR [r12+r13*1]
   50527:	mov    QWORD PTR [r14],rax
   5052a:	mov    rax,QWORD PTR [r12+r13*1+0x8]
   5052f:	mov    QWORD PTR [r14+0x8],rax
   50533:	mov    rax,QWORD PTR [r12+r13*1+0x10]
   50538:	mov    QWORD PTR [r14+0x10],rax
   5053c:	movzx  eax,WORD PTR [r14+0x14]
   50541:	and    eax,0xffffafff
   50546:	mov    WORD PTR [r14+0x14],ax
   5054b:	movzx  eax,WORD PTR [r14+0x14]
   50550:	or     eax,0x2040
   50555:	mov    WORD PTR [r14+0x14],ax
   5055a:	mov    r14,QWORD PTR [rsp+0xc8]
   50562:	mov    DWORD PTR [rsp+0x31c],r15d
   5056a:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5056f:	mov    QWORD PTR [rsp+0xc8],r14
   50577:	mov    r15d,DWORD PTR [rsp+0x31c]
   5057f:	mov    QWORD PTR [rsp+0xd0],r12
   50587:	mov    r12d,DWORD PTR [rbp+0xc]
   5058b:	movsxd rax,DWORD PTR [rbp+0x4]
   5058f:	imul   rax,rax,0x38
   50593:	lea    r13,[rbx+rax*1]
   50597:	movsxd rax,DWORD PTR [rbp+0x8]
   5059b:	imul   rax,rax,0x38
   5059f:	lea    r14,[rbx+rax*1]
   505a3:	movzx  eax,WORD PTR [r14+0x14]
   505a8:	and    eax,0x9000
   505ad:	test   eax,eax
   505af:	jne    505b8 <sqlite3VdbeExec+0x1118>
   505b1:	cmp    DWORD PTR [r14+0x20],0x0
   505b6:	je     505d0 <sqlite3VdbeExec+0x1130>
   505b8:	mov    QWORD PTR [rsp+0xb0],rdi
   505c0:	mov    rdi,r14
   505c3:	call   505c8 <sqlite3VdbeExec+0x1128>
   505c8:	mov    rdi,QWORD PTR [rsp+0xb0]
   505d0:	mov    eax,0x38
   505d5:	mov    QWORD PTR [rsp+0xb0],rdi
   505dd:	mov    rdi,r14
   505e0:	mov    rsi,r13
   505e3:	mov    rdx,rax
   505e6:	call   505eb <sqlite3VdbeExec+0x114b>
   505eb:	mov    WORD PTR [r13+0x14],0x1
   505f2:	mov    DWORD PTR [r13+0x20],0x0
   505fa:	movzx  eax,WORD PTR [r14+0x14]
   505ff:	and    eax,0x4000
   50604:	mov    rdi,QWORD PTR [rsp+0xb0]
   5060c:	test   eax,eax
   5060e:	je     50716 <sqlite3VdbeExec+0x1276>
   50614:	movzx  eax,WORD PTR [r14+0x14]
   50619:	and    eax,0x12
   5061c:	test   eax,eax
   5061e:	je     50707 <sqlite3VdbeExec+0x1267>
   50624:	movzx  eax,WORD PTR [r14+0x14]
   50629:	and    eax,0x400
   5062e:	test   eax,eax
   50630:	je     506b6 <sqlite3VdbeExec+0x1216>
   50636:	mov    eax,DWORD PTR [r14+0x10]
   5063a:	add    eax,DWORD PTR [r14]
   5063d:	test   eax,eax
   5063f:	jg     50652 <sqlite3VdbeExec+0x11b2>
   50641:	movzx  eax,WORD PTR [r14+0x14]
   50646:	and    eax,0x10
   50649:	test   eax,eax
   5064b:	je     506b6 <sqlite3VdbeExec+0x1216>
   5064d:	mov    eax,0x1
   50652:	mov    ecx,0x1
   50657:	mov    QWORD PTR [rsp+0xb0],rdi
   5065f:	mov    rdi,r14
   50662:	mov    rsi,rax
   50665:	mov    rdx,rcx
   50668:	call   5066d <sqlite3VdbeExec+0x11cd>
   5066d:	mov    rdi,QWORD PTR [rsp+0xb0]
   50675:	test   eax,eax
   50677:	jne    506e7 <sqlite3VdbeExec+0x1247>
   50679:	mov    rax,QWORD PTR [r14+0x8]
   5067d:	movsxd rcx,DWORD PTR [r14+0x10]
   50681:	add    rax,rcx
   50684:	xor    ecx,ecx
   50686:	movsxd rdx,DWORD PTR [r14]
   50689:	mov    rdi,rax
   5068c:	mov    rsi,rcx
   5068f:	call   50694 <sqlite3VdbeExec+0x11f4>
   50694:	mov    eax,DWORD PTR [r14+0x10]
   50698:	add    eax,DWORD PTR [r14]
   5069b:	mov    DWORD PTR [r14+0x10],eax
   5069f:	movzx  eax,WORD PTR [r14+0x14]
   506a4:	and    eax,0xfffff9ff
   506a9:	mov    WORD PTR [r14+0x14],ax
   506ae:	mov    rdi,QWORD PTR [rsp+0xb0]
   506b6:	cmp    DWORD PTR [r14+0x20],0x0
   506bb:	je     506c7 <sqlite3VdbeExec+0x1227>
   506bd:	mov    rax,QWORD PTR [r14+0x8]
   506c1:	cmp    rax,QWORD PTR [r14+0x28]
   506c5:	je     50707 <sqlite3VdbeExec+0x1267>
   506c7:	mov    QWORD PTR [rsp+0xb0],rdi
   506cf:	mov    rdi,r14
   506d2:	call   506d7 <sqlite3VdbeExec+0x1237>
   506d7:	mov    rdi,QWORD PTR [rsp+0xb0]
   506df:	test   eax,eax
   506e1:	je     50707 <sqlite3VdbeExec+0x1267>
   506e3:	test   eax,eax
   506e5:	je     50716 <sqlite3VdbeExec+0x1276>
   506e7:	mov    r14,QWORD PTR [rsp+0xc8]
   506ef:	mov    r13,QWORD PTR [rsp+0xf0]
   506f7:	mov    rbx,rbp
   506fa:	mov    rbp,QWORD PTR [rsp+0xf8]
   50702:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50707:	movzx  eax,WORD PTR [r14+0x14]
   5070c:	and    eax,0xffffbfff
   50711:	mov    WORD PTR [r14+0x14],ax
   50716:	add    r13,0x38
   5071a:	add    r14,0x38
   5071e:	sub    r12d,0x1
   50722:	test   r12d,r12d
   50725:	jne    505a3 <sqlite3VdbeExec+0x1103>
   5072b:	mov    r14,QWORD PTR [rsp+0xc8]
   50733:	mov    DWORD PTR [rsp+0x31c],r15d
   5073b:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   50740:	mov    QWORD PTR [rsp+0xc8],r14
   50748:	mov    r15d,DWORD PTR [rsp+0x31c]
   50750:	mov    QWORD PTR [rsp+0xd0],r12
   50758:	mov    r12d,DWORD PTR [rbp+0xc]
   5075c:	movsxd rax,DWORD PTR [rbp+0x4]
   50760:	imul   rax,rax,0x38
   50764:	lea    r13,[rbx+rax*1]
   50768:	movsxd rax,DWORD PTR [rbp+0x8]
   5076c:	imul   rax,rax,0x38
   50770:	lea    r14,[rbx+rax*1]
   50774:	mov    r11,r12
   50777:	mov    r12,r13
   5077a:	mov    r13,r11
   5077d:	jmp    5092a <sqlite3VdbeExec+0x148a>
   50782:	mov    rcx,QWORD PTR [r12]
   50786:	mov    QWORD PTR [r14],rcx
   50789:	mov    rcx,QWORD PTR [r12+0x8]
   5078e:	mov    QWORD PTR [r14+0x8],rcx
   50792:	mov    rcx,QWORD PTR [r12+0x10]
   50797:	mov    QWORD PTR [r14+0x10],rcx
   5079b:	movzx  ecx,WORD PTR [r12+0x14]
   507a1:	and    ecx,0x2000
   507a7:	test   ecx,ecx
   507a9:	jne    507c7 <sqlite3VdbeExec+0x1327>
   507ab:	movzx  ecx,WORD PTR [r14+0x14]
   507b0:	and    ecx,0xffff8fff
   507b6:	mov    WORD PTR [r14+0x14],cx
   507bb:	movzx  ecx,WORD PTR [r14+0x14]
   507c0:	or     ecx,eax
   507c2:	mov    WORD PTR [r14+0x14],cx
   507c7:	movzx  eax,WORD PTR [r14+0x14]
   507cc:	and    eax,0x4000
   507d1:	test   eax,eax
   507d3:	je     508db <sqlite3VdbeExec+0x143b>
   507d9:	movzx  eax,WORD PTR [r14+0x14]
   507de:	and    eax,0x12
   507e1:	test   eax,eax
   507e3:	je     508cc <sqlite3VdbeExec+0x142c>
   507e9:	movzx  eax,WORD PTR [r14+0x14]
   507ee:	and    eax,0x400
   507f3:	test   eax,eax
   507f5:	je     5087b <sqlite3VdbeExec+0x13db>
   507fb:	mov    eax,DWORD PTR [r14+0x10]
   507ff:	add    eax,DWORD PTR [r14]
   50802:	test   eax,eax
   50804:	jg     50817 <sqlite3VdbeExec+0x1377>
   50806:	movzx  eax,WORD PTR [r14+0x14]
   5080b:	and    eax,0x10
   5080e:	test   eax,eax
   50810:	je     5087b <sqlite3VdbeExec+0x13db>
   50812:	mov    eax,0x1
   50817:	mov    ecx,0x1
   5081c:	mov    QWORD PTR [rsp+0xb0],rdi
   50824:	mov    rdi,r14
   50827:	mov    rsi,rax
   5082a:	mov    rdx,rcx
   5082d:	call   50832 <sqlite3VdbeExec+0x1392>
   50832:	mov    rdi,QWORD PTR [rsp+0xb0]
   5083a:	test   eax,eax
   5083c:	jne    508ac <sqlite3VdbeExec+0x140c>
   5083e:	mov    rax,QWORD PTR [r14+0x8]
   50842:	movsxd rcx,DWORD PTR [r14+0x10]
   50846:	add    rax,rcx
   50849:	xor    ecx,ecx
   5084b:	movsxd rdx,DWORD PTR [r14]
   5084e:	mov    rdi,rax
   50851:	mov    rsi,rcx
   50854:	call   50859 <sqlite3VdbeExec+0x13b9>
   50859:	mov    eax,DWORD PTR [r14+0x10]
   5085d:	add    eax,DWORD PTR [r14]
   50860:	mov    DWORD PTR [r14+0x10],eax
   50864:	movzx  eax,WORD PTR [r14+0x14]
   50869:	and    eax,0xfffff9ff
   5086e:	mov    WORD PTR [r14+0x14],ax
   50873:	mov    rdi,QWORD PTR [rsp+0xb0]
   5087b:	cmp    DWORD PTR [r14+0x20],0x0
   50880:	je     5088c <sqlite3VdbeExec+0x13ec>
   50882:	mov    rax,QWORD PTR [r14+0x8]
   50886:	cmp    rax,QWORD PTR [r14+0x28]
   5088a:	je     508cc <sqlite3VdbeExec+0x142c>
   5088c:	mov    QWORD PTR [rsp+0xb0],rdi
   50894:	mov    rdi,r14
   50897:	call   5089c <sqlite3VdbeExec+0x13fc>
   5089c:	mov    rdi,QWORD PTR [rsp+0xb0]
   508a4:	test   eax,eax
   508a6:	je     508cc <sqlite3VdbeExec+0x142c>
   508a8:	test   eax,eax
   508aa:	je     508db <sqlite3VdbeExec+0x143b>
   508ac:	mov    r14,QWORD PTR [rsp+0xc8]
   508b4:	mov    r13,QWORD PTR [rsp+0xf0]
   508bc:	mov    rbx,rbp
   508bf:	mov    rbp,QWORD PTR [rsp+0xf8]
   508c7:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   508cc:	movzx  eax,WORD PTR [r14+0x14]
   508d1:	and    eax,0xffffbfff
   508d6:	mov    WORD PTR [r14+0x14],ax
   508db:	movzx  eax,WORD PTR [r14+0x14]
   508e0:	and    eax,0x800
   508e5:	test   eax,eax
   508e7:	je     50903 <sqlite3VdbeExec+0x1463>
   508e9:	movzx  eax,WORD PTR [rbp+0x2]
   508ed:	and    eax,0x2
   508f0:	test   eax,eax
   508f2:	je     50903 <sqlite3VdbeExec+0x1463>
   508f4:	movzx  eax,WORD PTR [r14+0x14]
   508f9:	and    eax,0xfffff7ff
   508fe:	mov    WORD PTR [r14+0x14],ax
   50903:	mov    DWORD PTR [rsp+0x31c],r15d
   5090b:	mov    r15d,r13d
   5090e:	sub    r15d,0x1
   50912:	test   r13d,r13d
   50915:	je     50965 <sqlite3VdbeExec+0x14c5>
   50917:	add    r14,0x38
   5091b:	add    r12,0x38
   5091f:	mov    r13,r15
   50922:	mov    r15d,DWORD PTR [rsp+0x31c]
   5092a:	mov    eax,0x4000
   5092f:	movzx  ecx,WORD PTR [r14+0x14]
   50934:	and    ecx,0x9000
   5093a:	test   ecx,ecx
   5093c:	je     50782 <sqlite3VdbeExec+0x12e2>
   50942:	mov    QWORD PTR [rsp+0xb0],rdi
   5094a:	mov    rdi,r14
   5094d:	mov    rsi,r12
   50950:	mov    rdx,rax
   50953:	call   50958 <sqlite3VdbeExec+0x14b8>
   50958:	mov    rdi,QWORD PTR [rsp+0xb0]
   50960:	jmp    507c7 <sqlite3VdbeExec+0x1327>
   50965:	mov    r15d,DWORD PTR [rsp+0x31c]
   5096d:	mov    r14,QWORD PTR [rsp+0xc8]
   50975:	mov    DWORD PTR [rsp+0x31c],r15d
   5097d:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   50982:	mov    QWORD PTR [rsp+0xc8],r14
   5098a:	mov    r15d,DWORD PTR [rsp+0x31c]
   50992:	mov    QWORD PTR [rsp+0xd0],r12
   5099a:	movsxd rax,DWORD PTR [rbp+0x4]
   5099e:	imul   rax,rax,0x38
   509a2:	add    rax,rbx
   509a5:	movsxd rcx,DWORD PTR [rbp+0x8]
   509a9:	imul   rcx,rcx,0x38
   509ad:	lea    rdx,[rbx+rcx*1]
   509b1:	mov    esi,0x4000
   509b6:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   509bb:	and    ecx,0x9000
   509c1:	test   ecx,ecx
   509c3:	je     509e5 <sqlite3VdbeExec+0x1545>
   509c5:	mov    QWORD PTR [rsp+0xb0],rdi
   509cd:	mov    rdi,rdx
   509d0:	mov    rdx,rsi
   509d3:	mov    rsi,rax
   509d6:	call   509db <sqlite3VdbeExec+0x153b>
   509db:	mov    rdi,QWORD PTR [rsp+0xb0]
   509e3:	jmp    50a22 <sqlite3VdbeExec+0x1582>
   509e5:	mov    rcx,QWORD PTR [rax]
   509e8:	mov    QWORD PTR [rdx],rcx
   509eb:	mov    rcx,QWORD PTR [rax+0x8]
   509ef:	mov    QWORD PTR [rdx+0x8],rcx
   509f3:	mov    rcx,QWORD PTR [rax+0x10]
   509f7:	mov    QWORD PTR [rdx+0x10],rcx
   509fb:	movzx  eax,WORD PTR [rax+0x14]
   509ff:	and    eax,0x2000
   50a04:	test   eax,eax
   50a06:	jne    50a22 <sqlite3VdbeExec+0x1582>
   50a08:	movzx  eax,WORD PTR [rdx+0x14]
   50a0c:	and    eax,0xffff8fff
   50a11:	mov    WORD PTR [rdx+0x14],ax
   50a15:	movzx  eax,WORD PTR [rdx+0x14]
   50a19:	or     eax,0x4000
   50a1e:	mov    WORD PTR [rdx+0x14],ax
   50a22:	mov    r14,QWORD PTR [rsp+0xc8]
   50a2a:	mov    DWORD PTR [rsp+0x31c],r15d
   50a32:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   50a37:	mov    QWORD PTR [rsp+0xc8],r14
   50a3f:	mov    r15d,DWORD PTR [rsp+0x31c]
   50a47:	mov    QWORD PTR [rsp+0xd0],r12
   50a4f:	movsxd rax,DWORD PTR [rbp+0x4]
   50a53:	imul   rax,rax,0x38
   50a57:	movsxd rcx,DWORD PTR [rbp+0x8]
   50a5b:	imul   rcx,rcx,0x38
   50a5f:	lea    rdx,[rbx+rcx*1]
   50a63:	mov    rax,QWORD PTR [rbx+rax*1]
   50a67:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   50a6c:	and    ecx,0x9000
   50a72:	test   ecx,ecx
   50a74:	je     50a93 <sqlite3VdbeExec+0x15f3>
   50a76:	mov    QWORD PTR [rsp+0xb0],rdi
   50a7e:	mov    rdi,rdx
   50a81:	mov    rsi,rax
   50a84:	call   50a89 <sqlite3VdbeExec+0x15e9>
   50a89:	mov    rdi,QWORD PTR [rsp+0xb0]
   50a91:	jmp    50a9c <sqlite3VdbeExec+0x15fc>
   50a93:	mov    QWORD PTR [rdx],rax
   50a96:	mov    WORD PTR [rdx+0x14],0x4
   50a9c:	mov    r14,QWORD PTR [rsp+0xc8]
   50aa4:	mov    DWORD PTR [rsp+0x31c],r15d
   50aac:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   50ab1:	mov    QWORD PTR [rsp+0xc8],r14
   50ab9:	mov    r15d,DWORD PTR [rsp+0x31c]
   50ac1:	mov    QWORD PTR [rsp+0xd0],r12
   50ac9:	cmp    QWORD PTR [rdi+0x50],0x0
   50ace:	jne    50ad5 <sqlite3VdbeExec+0x1635>
   50ad0:	xor    r12d,r12d
   50ad3:	jmp    50aed <sqlite3VdbeExec+0x164d>
   50ad5:	mov    QWORD PTR [rsp+0xb0],rdi
   50add:	call   50ae2 <sqlite3VdbeExec+0x1642>
   50ae2:	mov    r12d,eax
   50ae5:	mov    rdi,QWORD PTR [rsp+0xb0]
   50aed:	test   r12d,r12d
   50af0:	je     50b1a <sqlite3VdbeExec+0x167a>
   50af2:	mov    r14,QWORD PTR [rsp+0xc8]
   50afa:	mov    QWORD PTR [rsp+0xe8],rbp
   50b02:	mov    rbp,r12
   50b05:	mov    r13,QWORD PTR [rsp+0xd0]
   50b0d:	mov    rbx,QWORD PTR [rsp+0xf8]
   50b15:	jmp    4f712 <sqlite3VdbeExec+0x272>
   50b1a:	mov    r14,QWORD PTR [rsp+0xc8]
   50b22:	mov    r13,QWORD PTR [rsp+0xf0]
   50b2a:	mov    DWORD PTR [rsp+0x31c],r15d
   50b32:	mov    QWORD PTR [rsp+0xf0],r13
   50b3a:	mov    DWORD PTR [rsp+0x32c],r12d
   50b42:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   50b47:	mov    r13,QWORD PTR [rsp+0xf0]
   50b4f:	mov    QWORD PTR [rsp+0xd0],r12
   50b57:	mov    eax,DWORD PTR [rdi+0x2c]
   50b5a:	add    eax,0x2
   50b5d:	or     eax,0x1
   50b60:	mov    DWORD PTR [rdi+0x2c],eax
   50b63:	movsxd rax,DWORD PTR [rbp+0x4]
   50b67:	imul   rax,rax,0x38
   50b6b:	add    rax,rbx
   50b6e:	mov    QWORD PTR [rdi+0xa0],rax
   50b75:	cmp    BYTE PTR [r14+0x67],0x0
   50b7a:	je     50b8c <sqlite3VdbeExec+0x16ec>
   50b7c:	mov    rbx,rbp
   50b7f:	mov    rbp,QWORD PTR [rsp+0xf8]
   50b87:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50b8c:	movzx  eax,BYTE PTR [r14+0x6e]
   50b91:	and    eax,0x4
   50b94:	test   eax,eax
   50b96:	je     50bd2 <sqlite3VdbeExec+0x1732>
   50b98:	mov    rax,QWORD PTR [r14+0xf0]
   50b9f:	mov    ecx,0x4
   50ba4:	mov    rdx,QWORD PTR [r14+0xf8]
   50bab:	xor    esi,esi
   50bad:	mov    QWORD PTR [rsp+0xb0],rdi
   50bb5:	mov    r10,rax
   50bb8:	mov    r11,rdi
   50bbb:	mov    rdi,rcx
   50bbe:	mov    rcx,rsi
   50bc1:	mov    rsi,rdx
   50bc4:	mov    rdx,r11
   50bc7:	call   r10
   50bca:	mov    rdi,QWORD PTR [rsp+0xb0]
   50bd2:	mov    rax,rbp
   50bd5:	sub    rax,r13
   50bd8:	movabs rdx,0x2aaaaaaaaaaaaaab
   50be2:	imul   rdx
   50be5:	sar    rdx,0x2
   50be9:	mov    rax,rdx
   50bec:	shr    rax,0x3f
   50bf0:	add    rdx,rax
   50bf3:	mov    rax,rdx
   50bf6:	add    eax,0x1
   50bf9:	mov    DWORD PTR [rdi+0x30],eax
   50bfc:	mov    ebx,0x64
   50c01:	mov    QWORD PTR [rsp+0xf0],r13
   50c09:	mov    r12,rbx
   50c0c:	mov    r13d,DWORD PTR [rsp+0x320]
   50c14:	mov    r15,QWORD PTR [rsp+0xd0]
   50c1c:	mov    rbx,QWORD PTR [rsp+0xf8]
   50c24:	jmp    659c6 <sqlite3VdbeExec+0x16526>
   50c29:	mov    r15d,DWORD PTR [rsp+0x31c]
   50c31:	mov    r13,QWORD PTR [rsp+0xf0]
   50c39:	mov    QWORD PTR [rsp+0xd0],r12
   50c41:	mov    r12d,DWORD PTR [rsp+0x334]
   50c49:	movsxd rax,DWORD PTR [rbp+0x4]
   50c4d:	imul   rax,rax,0x38
   50c51:	mov    DWORD PTR [rsp+0x334],r12d
   50c59:	lea    r12,[rbx+rax*1]
   50c5d:	movsxd rcx,DWORD PTR [rbp+0x8]
   50c61:	imul   rcx,rcx,0x38
   50c65:	mov    QWORD PTR [rsp+0xf0],r13
   50c6d:	lea    r13,[rbx+rcx*1]
   50c71:	movsxd rdx,DWORD PTR [rbp+0xc]
   50c75:	imul   rdx,rdx,0x38
   50c79:	mov    DWORD PTR [rsp+0x31c],r15d
   50c81:	lea    r15,[rbx+rdx*1]
   50c85:	mov    QWORD PTR [rsp+0xc8],r14
   50c8d:	movzx  r14d,WORD PTR [rbx+rax*1+0x14]
   50c93:	mov    eax,r14d
   50c96:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   50c9b:	or     eax,ecx
   50c9d:	and    eax,0x1
   50ca0:	test   eax,eax
   50ca2:	je     50ce0 <sqlite3VdbeExec+0x1840>
   50ca4:	movzx  eax,WORD PTR [r15+0x14]
   50ca9:	and    eax,0x9000
   50cae:	test   eax,eax
   50cb0:	je     50ccc <sqlite3VdbeExec+0x182c>
   50cb2:	mov    QWORD PTR [rsp+0xb0],rdi
   50cba:	mov    rdi,r15
   50cbd:	call   50cc2 <sqlite3VdbeExec+0x1822>
   50cc2:	mov    rdi,QWORD PTR [rsp+0xb0]
   50cca:	jmp    50cd3 <sqlite3VdbeExec+0x1833>
   50ccc:	mov    WORD PTR [r15+0x14],0x1
   50cd3:	mov    r14,QWORD PTR [rsp+0xc8]
   50cdb:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   50ce0:	mov    eax,r14d
   50ce3:	and    eax,0x12
   50ce6:	test   eax,eax
   50ce8:	jne    50d68 <sqlite3VdbeExec+0x18c8>
   50cea:	mov    r14d,DWORD PTR [rsp+0x31c]
   50cf2:	mov    eax,r14d
   50cf5:	xor    ecx,ecx
   50cf7:	mov    QWORD PTR [rsp+0xb0],rdi
   50cff:	mov    rdi,r12
   50d02:	mov    rsi,rax
   50d05:	mov    rdx,rcx
   50d08:	call   50d0d <sqlite3VdbeExec+0x186d>
   50d0d:	mov    rdi,QWORD PTR [rsp+0xb0]
   50d15:	test   eax,eax
   50d17:	je     50d39 <sqlite3VdbeExec+0x1899>
   50d19:	mov    r14,QWORD PTR [rsp+0xc8]
   50d21:	mov    r13,QWORD PTR [rsp+0xf0]
   50d29:	mov    rbx,rbp
   50d2c:	mov    rbp,QWORD PTR [rsp+0xf8]
   50d34:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50d39:	movzx  eax,WORD PTR [r12+0x14]
   50d3f:	and    eax,0xfffffffd
   50d42:	mov    QWORD PTR [rsp+0x110],r15
   50d4a:	mov    r15d,eax
   50d4d:	mov    QWORD PTR [rsp+0xe8],rbp
   50d55:	mov    rbp,rbx
   50d58:	mov    rbx,r15
   50d5b:	mov    r15,QWORD PTR [rsp+0x110]
   50d63:	jmp    50e4e <sqlite3VdbeExec+0x19ae>
   50d68:	mov    QWORD PTR [rsp+0x110],r15
   50d70:	mov    r15,rbx
   50d73:	mov    rbx,r14
   50d76:	mov    r14d,DWORD PTR [rsp+0x31c]
   50d7e:	mov    eax,ebx
   50d80:	and    eax,0x400
   50d85:	test   eax,eax
   50d87:	jne    50da1 <sqlite3VdbeExec+0x1901>
   50d89:	mov    QWORD PTR [rsp+0xe8],rbp
   50d91:	mov    rbp,r15
   50d94:	mov    r15,QWORD PTR [rsp+0x110]
   50d9c:	jmp    50e4e <sqlite3VdbeExec+0x19ae>
   50da1:	mov    eax,DWORD PTR [r12+0x10]
   50da6:	add    eax,DWORD PTR [r12]
   50daa:	test   eax,eax
   50dac:	jg     50dc0 <sqlite3VdbeExec+0x1920>
   50dae:	movzx  eax,WORD PTR [r12+0x14]
   50db4:	and    eax,0x10
   50db7:	test   eax,eax
   50db9:	je     50e30 <sqlite3VdbeExec+0x1990>
   50dbb:	mov    eax,0x1
   50dc0:	mov    ecx,0x1
   50dc5:	mov    QWORD PTR [rsp+0xb0],rdi
   50dcd:	mov    rdi,r12
   50dd0:	mov    rsi,rax
   50dd3:	mov    rdx,rcx
   50dd6:	call   50ddb <sqlite3VdbeExec+0x193b>
   50ddb:	mov    rdi,QWORD PTR [rsp+0xb0]
   50de3:	test   eax,eax
   50de5:	jne    50eb3 <sqlite3VdbeExec+0x1a13>
   50deb:	mov    rax,QWORD PTR [r12+0x8]
   50df0:	movsxd rcx,DWORD PTR [r12+0x10]
   50df5:	add    rax,rcx
   50df8:	xor    ecx,ecx
   50dfa:	movsxd rdx,DWORD PTR [r12]
   50dfe:	mov    rdi,rax
   50e01:	mov    rsi,rcx
   50e04:	call   50e09 <sqlite3VdbeExec+0x1969>
   50e09:	mov    eax,DWORD PTR [r12+0x10]
   50e0e:	add    eax,DWORD PTR [r12]
   50e12:	mov    DWORD PTR [r12+0x10],eax
   50e17:	movzx  eax,WORD PTR [r12+0x14]
   50e1d:	and    eax,0xfffff9ff
   50e22:	mov    WORD PTR [r12+0x14],ax
   50e28:	mov    rdi,QWORD PTR [rsp+0xb0]
   50e30:	movzx  eax,WORD PTR [r12+0x14]
   50e36:	and    eax,0xfffffffd
   50e39:	mov    ebx,eax
   50e3b:	mov    QWORD PTR [rsp+0xe8],rbp
   50e43:	mov    rbp,r15
   50e46:	mov    r15,QWORD PTR [rsp+0x110]
   50e4e:	mov    DWORD PTR [rsp+0x338],ebx
   50e55:	movzx  ebx,WORD PTR [r13+0x14]
   50e5a:	mov    eax,ebx
   50e5c:	and    eax,0x12
   50e5f:	test   eax,eax
   50e61:	jne    50eef <sqlite3VdbeExec+0x1a4f>
   50e67:	mov    eax,r14d
   50e6a:	xor    ecx,ecx
   50e6c:	mov    QWORD PTR [rsp+0xb0],rdi
   50e74:	mov    rdi,r13
   50e77:	mov    rsi,rax
   50e7a:	mov    rdx,rcx
   50e7d:	call   50e82 <sqlite3VdbeExec+0x19e2>
   50e82:	mov    rdi,QWORD PTR [rsp+0xb0]
   50e8a:	test   eax,eax
   50e8c:	je     50ee0 <sqlite3VdbeExec+0x1a40>
   50e8e:	mov    r14,QWORD PTR [rsp+0xc8]
   50e96:	mov    r13,QWORD PTR [rsp+0xf0]
   50e9e:	mov    rbx,QWORD PTR [rsp+0xe8]
   50ea6:	mov    rbp,QWORD PTR [rsp+0xf8]
   50eae:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50eb3:	mov    QWORD PTR [rsp+0xe8],rbp
   50ebb:	mov    r14,QWORD PTR [rsp+0xc8]
   50ec3:	mov    r13,QWORD PTR [rsp+0xf0]
   50ecb:	mov    rbx,QWORD PTR [rsp+0xe8]
   50ed3:	mov    rbp,QWORD PTR [rsp+0xf8]
   50edb:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50ee0:	movzx  eax,WORD PTR [r13+0x14]
   50ee5:	and    eax,0xfffffffd
   50ee8:	mov    ebx,eax
   50eea:	jmp    50f8f <sqlite3VdbeExec+0x1aef>
   50eef:	mov    eax,ebx
   50ef1:	and    eax,0x400
   50ef6:	test   eax,eax
   50ef8:	je     50f8f <sqlite3VdbeExec+0x1aef>
   50efe:	mov    eax,DWORD PTR [r13+0x10]
   50f02:	add    eax,DWORD PTR [r13+0x0]
   50f06:	test   eax,eax
   50f08:	jg     50f1b <sqlite3VdbeExec+0x1a7b>
   50f0a:	movzx  eax,WORD PTR [r13+0x14]
   50f0f:	and    eax,0x10
   50f12:	test   eax,eax
   50f14:	je     50f85 <sqlite3VdbeExec+0x1ae5>
   50f16:	mov    eax,0x1
   50f1b:	mov    ecx,0x1
   50f20:	mov    QWORD PTR [rsp+0xb0],rdi
   50f28:	mov    rdi,r13
   50f2b:	mov    rsi,rax
   50f2e:	mov    rdx,rcx
   50f31:	call   50f36 <sqlite3VdbeExec+0x1a96>
   50f36:	mov    rdi,QWORD PTR [rsp+0xb0]
   50f3e:	test   eax,eax
   50f40:	jne    51017 <sqlite3VdbeExec+0x1b77>
   50f46:	mov    rax,QWORD PTR [r13+0x8]
   50f4a:	movsxd rcx,DWORD PTR [r13+0x10]
   50f4e:	add    rax,rcx
   50f51:	xor    ecx,ecx
   50f53:	movsxd rdx,DWORD PTR [r13+0x0]
   50f57:	mov    rdi,rax
   50f5a:	mov    rsi,rcx
   50f5d:	call   50f62 <sqlite3VdbeExec+0x1ac2>
   50f62:	mov    eax,DWORD PTR [r13+0x10]
   50f66:	add    eax,DWORD PTR [r13+0x0]
   50f6a:	mov    DWORD PTR [r13+0x10],eax
   50f6e:	movzx  eax,WORD PTR [r13+0x14]
   50f73:	and    eax,0xfffff9ff
   50f78:	mov    WORD PTR [r13+0x14],ax
   50f7d:	mov    rdi,QWORD PTR [rsp+0xb0]
   50f85:	movzx  eax,WORD PTR [r13+0x14]
   50f8a:	and    eax,0xfffffffd
   50f8d:	mov    ebx,eax
   50f8f:	movsxd rax,DWORD PTR [r12+0x10]
   50f94:	movsxd rcx,DWORD PTR [r13+0x10]
   50f98:	mov    DWORD PTR [rsp+0x33c],ebx
   50f9f:	lea    rbx,[rax+rcx*1]
   50fa3:	mov    QWORD PTR [rsp+0x108],r12
   50fab:	mov    r12,QWORD PTR [rsp+0xc8]
   50fb3:	movsxd rax,DWORD PTR [r12+0x88]
   50fbb:	cmp    rbx,rax
   50fbe:	jle    50fc8 <sqlite3VdbeExec+0x1b28>
   50fc0:	mov    rbp,r12
   50fc3:	jmp    53cb6 <sqlite3VdbeExec+0x4816>
   50fc8:	mov    eax,ebx
   50fca:	add    eax,0x2
   50fcd:	xor    ecx,ecx
   50fcf:	cmp    r15,r13
   50fd2:	sete   cl
   50fd5:	mov    QWORD PTR [rsp+0xb0],rdi
   50fdd:	mov    rdi,r15
   50fe0:	mov    rsi,rax
   50fe3:	mov    rdx,rcx
   50fe6:	call   50feb <sqlite3VdbeExec+0x1b4b>
   50feb:	mov    rdi,QWORD PTR [rsp+0xb0]
   50ff3:	test   eax,eax
   50ff5:	je     5103f <sqlite3VdbeExec+0x1b9f>
   50ff7:	mov    r14,r12
   50ffa:	mov    r13,QWORD PTR [rsp+0xf0]
   51002:	mov    rbx,QWORD PTR [rsp+0xe8]
   5100a:	mov    rbp,QWORD PTR [rsp+0xf8]
   51012:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   51017:	mov    r12,QWORD PTR [rsp+0xc8]
   5101f:	mov    r14,r12
   51022:	mov    r13,QWORD PTR [rsp+0xf0]
   5102a:	mov    rbx,QWORD PTR [rsp+0xe8]
   51032:	mov    rbp,QWORD PTR [rsp+0xf8]
   5103a:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5103f:	movzx  eax,WORD PTR [r15+0x14]
   51044:	and    eax,0xfffff240
   51049:	or     eax,0x2
   5104c:	mov    WORD PTR [r15+0x14],ax
   51051:	cmp    r15,r13
   51054:	jne    51060 <sqlite3VdbeExec+0x1bc0>
   51056:	mov    QWORD PTR [rsp+0x100],rbp
   5105e:	jmp    51093 <sqlite3VdbeExec+0x1bf3>
   51060:	mov    rax,QWORD PTR [r15+0x8]
   51064:	mov    rcx,QWORD PTR [r13+0x8]
   51068:	movsxd rdx,DWORD PTR [r13+0x10]
   5106c:	mov    rdi,rax
   5106f:	mov    rsi,rcx
   51072:	call   51077 <sqlite3VdbeExec+0x1bd7>
   51077:	mov    QWORD PTR [rsp+0x100],rbp
   5107f:	mov    ebp,DWORD PTR [rsp+0x33c]
   51086:	mov    WORD PTR [r13+0x14],bp
   5108b:	mov    rdi,QWORD PTR [rsp+0xb0]
   51093:	mov    rax,QWORD PTR [r15+0x8]
   51097:	movsxd rcx,DWORD PTR [r13+0x10]
   5109b:	add    rax,rcx
   5109e:	mov    rbp,QWORD PTR [rsp+0x108]
   510a6:	mov    rcx,QWORD PTR [rbp+0x8]
   510aa:	movsxd rdx,DWORD PTR [rbp+0x10]
   510ae:	mov    QWORD PTR [rsp+0xb0],rdi
   510b6:	mov    rdi,rax
   510b9:	mov    rsi,rcx
   510bc:	call   510c1 <sqlite3VdbeExec+0x1c21>
   510c1:	mov    r13d,DWORD PTR [rsp+0x338]
   510c9:	mov    WORD PTR [rbp+0x14],r13w
   510ce:	mov    eax,r14d
   510d1:	mov    rdi,QWORD PTR [rsp+0xb0]
   510d9:	cmp    eax,0x1
   510dc:	jg     510e8 <sqlite3VdbeExec+0x1c48>
   510de:	mov    rbp,QWORD PTR [rsp+0xe8]
   510e6:	jmp    510f4 <sqlite3VdbeExec+0x1c54>
   510e8:	and    rbx,0xfffffffffffffffe
   510ec:	mov    rbp,QWORD PTR [rsp+0xe8]
   510f4:	mov    rax,QWORD PTR [r15+0x8]
   510f8:	mov    BYTE PTR [rax+rbx*1],0x0
   510fc:	mov    rax,QWORD PTR [r15+0x8]
   51100:	mov    BYTE PTR [rax+rbx*1+0x1],0x0
   51105:	movzx  eax,WORD PTR [r15+0x14]
   5110a:	or     eax,0x200
   5110f:	mov    WORD PTR [r15+0x14],ax
   51114:	mov    DWORD PTR [r15+0x10],ebx
   51118:	mov    BYTE PTR [r15+0x16],r14b
   5111c:	mov    DWORD PTR [rsp+0x31c],r14d
   51124:	mov    r14,r12
   51127:	mov    rbx,QWORD PTR [rsp+0x100]
   5112f:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   51134:	mov    QWORD PTR [rsp+0x100],rbx
   5113c:	mov    QWORD PTR [rsp+0xd0],r12
   51144:	mov    r12,r14
   51147:	mov    r14d,DWORD PTR [rsp+0x31c]
   5114f:	movsxd rax,DWORD PTR [rbp+0x4]
   51153:	imul   rax,rax,0x38
   51157:	mov    rbx,QWORD PTR [rsp+0x100]
   5115f:	lea    r13,[rbx+rax*1]
   51163:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51168:	movsxd rcx,DWORD PTR [rbp+0x8]
   5116c:	imul   rcx,rcx,0x38
   51170:	lea    r15,[rbx+rcx*1]
   51174:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   51179:	movsxd rdx,DWORD PTR [rbp+0xc]
   5117d:	imul   rdx,rdx,0x38
   51181:	mov    DWORD PTR [rsp+0x31c],r14d
   51189:	lea    r14,[rbx+rdx*1]
   5118d:	mov    edx,eax
   5118f:	mov    esi,ecx
   51191:	and    edx,esi
   51193:	and    edx,0x4
   51196:	test   edx,edx
   51198:	je     51449 <sqlite3VdbeExec+0x1fa9>
   5119e:	mov    rcx,QWORD PTR [r13+0x0]
   511a2:	mov    rax,QWORD PTR [r15]
   511a5:	mov    QWORD PTR [rsp+0x110],rax
   511ad:	movzx  eax,BYTE PTR [rbp+0x0]
   511b1:	mov    edx,eax
   511b3:	sub    edx,0x6b
   511b6:	cmp    edx,0x3
   511b9:	jbe    511c8 <sqlite3VdbeExec+0x1d28>
   511bb:	mov    QWORD PTR [rsp+0x108],r14
   511c3:	jmp    513f2 <sqlite3VdbeExec+0x1f52>
   511c8:	sub    eax,0x6b
   511cb:	mov    QWORD PTR [rsp+0x108],r14
   511d3:	lea    r14,[rip+0x0]        # 511da <sqlite3VdbeExec+0x1d3a>
   511da:	movsxd rax,DWORD PTR [r14+rax*4]
   511de:	add    rax,r14
   511e1:	jmp    rax
   511e3:	mov    rax,QWORD PTR [rsp+0x110]
   511eb:	test   rcx,rcx
   511ee:	jl     51222 <sqlite3VdbeExec+0x1d82>
   511f0:	test   rax,rax
   511f3:	jle    51240 <sqlite3VdbeExec+0x1da0>
   511f5:	movabs rdx,0x7fffffffffffffff
   511ff:	sub    rdx,rax
   51202:	cmp    rdx,rcx
   51205:	jge    51240 <sqlite3VdbeExec+0x1da0>
   51207:	movzx  eax,WORD PTR [r13+0x14]
   5120c:	and    eax,0x8
   5120f:	test   eax,eax
   51211:	je     5152e <sqlite3VdbeExec+0x208e>
   51217:	movsd  xmm0,QWORD PTR [r13+0x0]
   5121d:	jmp    515b1 <sqlite3VdbeExec+0x2111>
   51222:	test   rax,rax
   51225:	jge    51240 <sqlite3VdbeExec+0x1da0>
   51227:	movabs rdx,0x7fffffffffffffff
   51231:	add    rax,rdx
   51234:	neg    rax
   51237:	lea    rdx,[rcx+0x1]
   5123b:	cmp    rax,rdx
   5123e:	jg     51207 <sqlite3VdbeExec+0x1d67>
   51240:	mov    rax,QWORD PTR [rsp+0x110]
   51248:	add    rax,rcx
   5124b:	mov    QWORD PTR [rsp+0x110],rax
   51253:	jmp    5141e <sqlite3VdbeExec+0x1f7e>
   51258:	movabs rax,0x8000000000000000
   51262:	cmp    rcx,rax
   51265:	jne    5128a <sqlite3VdbeExec+0x1dea>
   51267:	cmp    QWORD PTR [rsp+0x110],0x0
   51270:	jge    51207 <sqlite3VdbeExec+0x1d67>
   51272:	mov    rax,QWORD PTR [rsp+0x110]
   5127a:	sub    rax,rcx
   5127d:	mov    QWORD PTR [rsp+0x110],rax
   51285:	jmp    5141e <sqlite3VdbeExec+0x1f7e>
   5128a:	neg    rcx
   5128d:	mov    rax,QWORD PTR [rsp+0x110]
   51295:	test   rcx,rcx
   51298:	jl     512ca <sqlite3VdbeExec+0x1e2a>
   5129a:	test   rax,rax
   5129d:	jle    512b5 <sqlite3VdbeExec+0x1e15>
   5129f:	movabs rdx,0x7fffffffffffffff
   512a9:	sub    rdx,rax
   512ac:	cmp    rdx,rcx
   512af:	jl     51207 <sqlite3VdbeExec+0x1d67>
   512b5:	add    rcx,QWORD PTR [rsp+0x110]
   512bd:	mov    QWORD PTR [rsp+0x110],rcx
   512c5:	jmp    5141e <sqlite3VdbeExec+0x1f7e>
   512ca:	test   rax,rax
   512cd:	jge    512b5 <sqlite3VdbeExec+0x1e15>
   512cf:	movabs rdx,0x7fffffffffffffff
   512d9:	add    rax,rdx
   512dc:	neg    rax
   512df:	lea    rdx,[rcx+0x1]
   512e3:	cmp    rax,rdx
   512e6:	jg     51207 <sqlite3VdbeExec+0x1d67>
   512ec:	jmp    512b5 <sqlite3VdbeExec+0x1e15>
   512ee:	mov    rsi,QWORD PTR [rsp+0x110]
   512f6:	test   rcx,rcx
   512f9:	jle    5133c <sqlite3VdbeExec+0x1e9c>
   512fb:	movabs rax,0x7fffffffffffffff
   51305:	cqo
   51307:	idiv   rcx
   5130a:	cmp    rsi,rax
   5130d:	jg     51207 <sqlite3VdbeExec+0x1d67>
   51313:	movabs rax,0x8000000000000000
   5131d:	cqo
   5131f:	idiv   rcx
   51322:	cmp    rsi,rax
   51325:	jl     51207 <sqlite3VdbeExec+0x1d67>
   5132b:	imul   rsi,rcx
   5132f:	mov    QWORD PTR [rsp+0x110],rsi
   51337:	jmp    5141e <sqlite3VdbeExec+0x1f7e>
   5133c:	test   rcx,rcx
   5133f:	jge    5132b <sqlite3VdbeExec+0x1e8b>
   51341:	test   rsi,rsi
   51344:	jle    51360 <sqlite3VdbeExec+0x1ec0>
   51346:	movabs rax,0x8000000000000000
   51350:	cqo
   51352:	idiv   rsi
   51355:	cmp    rcx,rax
   51358:	jl     51207 <sqlite3VdbeExec+0x1d67>
   5135e:	jmp    5132b <sqlite3VdbeExec+0x1e8b>
   51360:	test   rsi,rsi
   51363:	jge    5132b <sqlite3VdbeExec+0x1e8b>
   51365:	movabs rax,0x8000000000000000
   5136f:	cmp    rcx,rax
   51372:	je     51207 <sqlite3VdbeExec+0x1d67>
   51378:	movabs rax,0x8000000000000000
   51382:	cmp    rsi,rax
   51385:	je     51207 <sqlite3VdbeExec+0x1d67>
   5138b:	mov    r8,rsi
   5138e:	neg    r8
   51391:	movabs rax,0x7fffffffffffffff
   5139b:	mov    r9,rcx
   5139e:	neg    r9
   513a1:	cqo
   513a3:	idiv   r9
   513a6:	cmp    r8,rax
   513a9:	jg     51207 <sqlite3VdbeExec+0x1d67>
   513af:	jmp    5132b <sqlite3VdbeExec+0x1e8b>
   513b4:	test   rcx,rcx
   513b7:	je     51870 <sqlite3VdbeExec+0x23d0>
   513bd:	cmp    rcx,0xffffffffffffffff
   513c1:	jne    513db <sqlite3VdbeExec+0x1f3b>
   513c3:	movabs rax,0x8000000000000000
   513cd:	cmp    rax,QWORD PTR [rsp+0x110]
   513d5:	je     51207 <sqlite3VdbeExec+0x1d67>
   513db:	mov    rax,QWORD PTR [rsp+0x110]
   513e3:	cqo
   513e5:	idiv   rcx
   513e8:	mov    QWORD PTR [rsp+0x110],rax
   513f0:	jmp    5141e <sqlite3VdbeExec+0x1f7e>
   513f2:	test   rcx,rcx
   513f5:	je     51870 <sqlite3VdbeExec+0x23d0>
   513fb:	cmp    rcx,0xffffffffffffffff
   513ff:	jne    51406 <sqlite3VdbeExec+0x1f66>
   51401:	mov    ecx,0x1
   51406:	mov    rax,QWORD PTR [rsp+0x110]
   5140e:	cqo
   51410:	idiv   rcx
   51413:	mov    rax,rdx
   51416:	mov    QWORD PTR [rsp+0x110],rax
   5141e:	mov    rax,QWORD PTR [rsp+0x110]
   51426:	mov    r13,QWORD PTR [rsp+0x108]
   5142e:	mov    QWORD PTR [r13+0x0],rax
   51432:	movzx  eax,WORD PTR [r13+0x14]
   51437:	and    eax,0xfffff240
   5143c:	or     eax,0x4
   5143f:	mov    WORD PTR [r13+0x14],ax
   51444:	jmp    51868 <sqlite3VdbeExec+0x23c8>
   51449:	mov    QWORD PTR [rsp+0x108],r14
   51451:	or     eax,ecx
   51453:	and    eax,0x1
   51456:	test   eax,eax
   51458:	jne    51870 <sqlite3VdbeExec+0x23d0>
   5145e:	movzx  eax,WORD PTR [r13+0x14]
   51463:	and    eax,0x2d
   51466:	test   eax,eax
   51468:	je     51477 <sqlite3VdbeExec+0x1fd7>
   5146a:	movzx  eax,WORD PTR [r13+0x14]
   5146f:	and    eax,0x2d
   51472:	mov    r14d,eax
   51475:	jmp    51493 <sqlite3VdbeExec+0x1ff3>
   51477:	mov    QWORD PTR [rsp+0xb0],rdi
   5147f:	mov    rdi,r13
   51482:	call   51487 <sqlite3VdbeExec+0x1fe7>
   51487:	movzx  r14d,ax
   5148b:	mov    rdi,QWORD PTR [rsp+0xb0]
   51493:	movzx  eax,WORD PTR [r15+0x14]
   51498:	and    eax,0x2d
   5149b:	test   eax,eax
   5149d:	je     514bc <sqlite3VdbeExec+0x201c>
   5149f:	movzx  eax,WORD PTR [r15+0x14]
   514a4:	and    eax,0x2d
   514a7:	mov    QWORD PTR [rsp+0x100],rbx
   514af:	mov    rbx,r14
   514b2:	mov    r14d,DWORD PTR [rsp+0x31c]
   514ba:	jmp    514ea <sqlite3VdbeExec+0x204a>
   514bc:	mov    QWORD PTR [rsp+0xb0],rdi
   514c4:	mov    rdi,r15
   514c7:	call   514cc <sqlite3VdbeExec+0x202c>
   514cc:	movzx  eax,ax
   514cf:	mov    rdi,QWORD PTR [rsp+0xb0]
   514d7:	mov    QWORD PTR [rsp+0x100],rbx
   514df:	mov    rbx,r14
   514e2:	mov    r14d,DWORD PTR [rsp+0x31c]
   514ea:	mov    ecx,ebx
   514ec:	and    ecx,eax
   514ee:	and    ecx,0x4
   514f1:	test   ecx,ecx
   514f3:	jne    51511 <sqlite3VdbeExec+0x2071>
   514f5:	mov    DWORD PTR [rsp+0x31c],r14d
   514fd:	mov    rbx,QWORD PTR [rsp+0x100]
   51505:	lea    r14,[rip+0x0]        # 5150c <sqlite3VdbeExec+0x206c>
   5150c:	jmp    51207 <sqlite3VdbeExec+0x1d67>
   51511:	mov    DWORD PTR [rsp+0x31c],r14d
   51519:	mov    r14,QWORD PTR [rsp+0x108]
   51521:	mov    rbx,QWORD PTR [rsp+0x100]
   51529:	jmp    5119e <sqlite3VdbeExec+0x1cfe>
   5152e:	mov    r14d,DWORD PTR [rsp+0x31c]
   51536:	mov    QWORD PTR [rsp+0x100],rbx
   5153e:	movzx  eax,WORD PTR [r13+0x14]
   51543:	and    eax,0x24
   51546:	test   eax,eax
   51548:	je     51568 <sqlite3VdbeExec+0x20c8>
   5154a:	mov    rax,QWORD PTR [r13+0x0]
   5154e:	xorps  xmm0,xmm0
   51551:	cvtsi2sd xmm0,rax
   51556:	mov    DWORD PTR [rsp+0x31c],r14d
   5155e:	mov    rbx,QWORD PTR [rsp+0x100]
   51566:	jmp    515b1 <sqlite3VdbeExec+0x2111>
   51568:	movzx  eax,WORD PTR [r13+0x14]
   5156d:	and    eax,0x12
   51570:	test   eax,eax
   51572:	je     5159e <sqlite3VdbeExec+0x20fe>
   51574:	mov    QWORD PTR [rsp+0xb0],rdi
   5157c:	mov    rdi,r13
   5157f:	call   51584 <sqlite3VdbeExec+0x20e4>
   51584:	mov    rdi,QWORD PTR [rsp+0xb0]
   5158c:	mov    DWORD PTR [rsp+0x31c],r14d
   51594:	mov    rbx,QWORD PTR [rsp+0x100]
   5159c:	jmp    515b1 <sqlite3VdbeExec+0x2111>
   5159e:	xorps  xmm0,xmm0
   515a1:	mov    DWORD PTR [rsp+0x31c],r14d
   515a9:	mov    rbx,QWORD PTR [rsp+0x100]
   515b1:	movzx  eax,WORD PTR [r15+0x14]
   515b6:	and    eax,0x8
   515b9:	test   eax,eax
   515bb:	je     515c4 <sqlite3VdbeExec+0x2124>
   515bd:	movsd  xmm1,QWORD PTR [r15]
   515c2:	jmp    51619 <sqlite3VdbeExec+0x2179>
   515c4:	movzx  eax,WORD PTR [r15+0x14]
   515c9:	and    eax,0x24
   515cc:	test   eax,eax
   515ce:	je     515dd <sqlite3VdbeExec+0x213d>
   515d0:	mov    rax,QWORD PTR [r15]
   515d3:	xorps  xmm1,xmm1
   515d6:	cvtsi2sd xmm1,rax
   515db:	jmp    51619 <sqlite3VdbeExec+0x2179>
   515dd:	movzx  eax,WORD PTR [r15+0x14]
   515e2:	and    eax,0x12
   515e5:	test   eax,eax
   515e7:	je     51616 <sqlite3VdbeExec+0x2176>
   515e9:	vmovdqu32 XMMWORD PTR [rsp+0x10],xmm0
   515f1:	mov    QWORD PTR [rsp+0xb0],rdi
   515f9:	mov    rdi,r15
   515fc:	call   51601 <sqlite3VdbeExec+0x2161>
   51601:	movaps xmm1,xmm0
   51604:	vmovdqu32 xmm0,XMMWORD PTR [rsp+0x10]
   5160c:	mov    rdi,QWORD PTR [rsp+0xb0]
   51614:	jmp    51619 <sqlite3VdbeExec+0x2179>
   51616:	xorps  xmm1,xmm1
   51619:	movzx  eax,BYTE PTR [rbp+0x0]
   5161d:	mov    ecx,eax
   5161f:	sub    ecx,0x6b
   51622:	cmp    ecx,0x3
   51625:	ja     51683 <sqlite3VdbeExec+0x21e3>
   51627:	sub    eax,0x6b
   5162a:	lea    r14,[rip+0x0]        # 51631 <sqlite3VdbeExec+0x2191>
   51631:	movsxd rax,DWORD PTR [r14+rax*4]
   51635:	add    rax,r14
   51638:	jmp    rax
   5163a:	addsd  xmm1,xmm0
   5163e:	jmp    517ec <sqlite3VdbeExec+0x234c>
   51643:	subsd  xmm1,xmm0
   51647:	jmp    517ec <sqlite3VdbeExec+0x234c>
   5164c:	mulsd  xmm1,xmm0
   51650:	jmp    517ec <sqlite3VdbeExec+0x234c>
   51655:	xorps  xmm2,xmm2
   51658:	xor    eax,eax
   5165a:	ucomisd xmm0,xmm2
   5165e:	sete   al
   51661:	setnp  r11b
   51665:	and    al,r11b
   51668:	test   eax,eax
   5166a:	mov    eax,0x0
   5166f:	setne  al
   51672:	test   eax,eax
   51674:	jne    51870 <sqlite3VdbeExec+0x23d0>
   5167a:	divsd  xmm1,xmm0
   5167e:	jmp    517ec <sqlite3VdbeExec+0x234c>
   51683:	movzx  eax,WORD PTR [r13+0x14]
   51688:	mov    ecx,eax
   5168a:	and    ecx,0x24
   5168d:	test   ecx,ecx
   5168f:	je     5169a <sqlite3VdbeExec+0x21fa>
   51691:	mov    r13,QWORD PTR [r13+0x0]
   51695:	jmp    51720 <sqlite3VdbeExec+0x2280>
   5169a:	mov    ecx,eax
   5169c:	and    ecx,0x8
   5169f:	test   ecx,ecx
   516a1:	je     516f2 <sqlite3VdbeExec+0x2252>
   516a3:	movsd  xmm1,QWORD PTR [r13+0x0]
   516a9:	movabs r11,0xc3dfffffffffffff
   516b3:	movq   xmm0,r11
   516b8:	ucomisd xmm0,xmm1
   516bc:	jbe    516ca <sqlite3VdbeExec+0x222a>
   516be:	movabs r13,0x8000000000000000
   516c8:	jmp    516f0 <sqlite3VdbeExec+0x2250>
   516ca:	movabs r11,0x43dfffffffffffff
   516d4:	movq   xmm0,r11
   516d9:	ucomisd xmm1,xmm0
   516dd:	jbe    516eb <sqlite3VdbeExec+0x224b>
   516df:	movabs r13,0x7fffffffffffffff
   516e9:	jmp    516f0 <sqlite3VdbeExec+0x2250>
   516eb:	cvttsd2si r13,xmm1
   516f0:	jmp    51720 <sqlite3VdbeExec+0x2280>
   516f2:	and    eax,0x12
   516f5:	test   eax,eax
   516f7:	je     5171d <sqlite3VdbeExec+0x227d>
   516f9:	cmp    QWORD PTR [r13+0x8],0x0
   516fe:	je     5171d <sqlite3VdbeExec+0x227d>
   51700:	mov    QWORD PTR [rsp+0xb0],rdi
   51708:	mov    rdi,r13
   5170b:	call   51710 <sqlite3VdbeExec+0x2270>
   51710:	mov    r13,rax
   51713:	mov    rdi,QWORD PTR [rsp+0xb0]
   5171b:	jmp    51720 <sqlite3VdbeExec+0x2280>
   5171d:	xor    r13d,r13d
   51720:	movzx  eax,WORD PTR [r15+0x14]
   51725:	mov    ecx,eax
   51727:	and    ecx,0x24
   5172a:	test   ecx,ecx
   5172c:	je     51736 <sqlite3VdbeExec+0x2296>
   5172e:	mov    rax,QWORD PTR [r15]
   51731:	jmp    517b7 <sqlite3VdbeExec+0x2317>
   51736:	mov    ecx,eax
   51738:	and    ecx,0x8
   5173b:	test   ecx,ecx
   5173d:	je     5178d <sqlite3VdbeExec+0x22ed>
   5173f:	movsd  xmm1,QWORD PTR [r15]
   51744:	movabs r11,0xc3dfffffffffffff
   5174e:	movq   xmm0,r11
   51753:	ucomisd xmm0,xmm1
   51757:	jbe    51765 <sqlite3VdbeExec+0x22c5>
   51759:	movabs rax,0x8000000000000000
   51763:	jmp    5178b <sqlite3VdbeExec+0x22eb>
   51765:	movabs r11,0x43dfffffffffffff
   5176f:	movq   xmm0,r11
   51774:	ucomisd xmm1,xmm0
   51778:	jbe    51786 <sqlite3VdbeExec+0x22e6>
   5177a:	movabs rax,0x7fffffffffffffff
   51784:	jmp    5178b <sqlite3VdbeExec+0x22eb>
   51786:	cvttsd2si rax,xmm1
   5178b:	jmp    517b7 <sqlite3VdbeExec+0x2317>
   5178d:	and    eax,0x12
   51790:	test   eax,eax
   51792:	je     517b5 <sqlite3VdbeExec+0x2315>
   51794:	cmp    QWORD PTR [r15+0x8],0x0
   51799:	je     517b5 <sqlite3VdbeExec+0x2315>
   5179b:	mov    QWORD PTR [rsp+0xb0],rdi
   517a3:	mov    rdi,r15
   517a6:	call   517ab <sqlite3VdbeExec+0x230b>
   517ab:	mov    rdi,QWORD PTR [rsp+0xb0]
   517b3:	jmp    517b7 <sqlite3VdbeExec+0x2317>
   517b5:	xor    eax,eax
   517b7:	mov    QWORD PTR [rsp+0x110],rax
   517bf:	test   r13,r13
   517c2:	je     51870 <sqlite3VdbeExec+0x23d0>
   517c8:	cmp    r13,0xffffffffffffffff
   517cc:	jne    517d4 <sqlite3VdbeExec+0x2334>
   517ce:	mov    r13d,0x1
   517d4:	mov    rax,QWORD PTR [rsp+0x110]
   517dc:	cqo
   517de:	idiv   r13
   517e1:	mov    rax,rdx
   517e4:	xorps  xmm1,xmm1
   517e7:	cvtsi2sd xmm1,rax
   517ec:	movsd  QWORD PTR [rsp+0xb8],xmm1
   517f5:	mov    rax,QWORD PTR [rsp+0xb8]
   517fd:	mov    QWORD PTR [rsp+0xc0],rax
   51805:	mov    rax,QWORD PTR [rsp+0xc0]
   5180d:	movabs rcx,0x7ff0000000000000
   51817:	and    rcx,rax
   5181a:	movabs rdx,0x7ff0000000000000
   51824:	movabs rsi,0xfffffffffffff
   5182e:	and    rax,rsi
   51831:	test   rax,rax
   51834:	mov    eax,0x0
   51839:	setne  al
   5183c:	xor    esi,esi
   5183e:	cmp    rcx,rdx
   51841:	cmove  esi,eax
   51844:	test   esi,esi
   51846:	jne    51870 <sqlite3VdbeExec+0x23d0>
   51848:	mov    r13,QWORD PTR [rsp+0x108]
   51850:	movsd  QWORD PTR [r13+0x0],xmm1
   51856:	movzx  eax,WORD PTR [r13+0x14]
   5185b:	and    eax,0xfffff240
   51860:	or     eax,0x8
   51863:	mov    WORD PTR [r13+0x14],ax
   51868:	mov    r14,r12
   5186b:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   51870:	mov    r13,QWORD PTR [rsp+0x108]
   51878:	movzx  eax,WORD PTR [r13+0x14]
   5187d:	and    eax,0x9000
   51882:	test   eax,eax
   51884:	je     518a0 <sqlite3VdbeExec+0x2400>
   51886:	mov    QWORD PTR [rsp+0xb0],rdi
   5188e:	mov    rdi,r13
   51891:	call   51896 <sqlite3VdbeExec+0x23f6>
   51896:	mov    rdi,QWORD PTR [rsp+0xb0]
   5189e:	jmp    518a7 <sqlite3VdbeExec+0x2407>
   518a0:	mov    WORD PTR [r13+0x14],0x1
   518a7:	mov    r14,r12
   518aa:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   518af:	mov    QWORD PTR [rsp+0xd0],r12
   518b7:	mov    r12,r14
   518ba:	cmp    DWORD PTR [rbp+0x4],0x0
   518be:	je     51906 <sqlite3VdbeExec+0x2466>
   518c0:	movsxd rax,DWORD PTR [rbp+0x4]
   518c4:	imul   rax,rax,0x38
   518c8:	lea    rcx,[rbx+rax*1]
   518cc:	xor    edx,edx
   518ce:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   518d3:	and    eax,0x9000
   518d8:	test   eax,eax
   518da:	je     518f9 <sqlite3VdbeExec+0x2459>
   518dc:	mov    QWORD PTR [rsp+0xb0],rdi
   518e4:	mov    rdi,rcx
   518e7:	mov    rsi,rdx
   518ea:	call   518ef <sqlite3VdbeExec+0x244f>
   518ef:	mov    rdi,QWORD PTR [rsp+0xb0]
   518f7:	jmp    51906 <sqlite3VdbeExec+0x2466>
   518f9:	mov    QWORD PTR [rcx],0x0
   51900:	mov    WORD PTR [rcx+0x14],0x4
   51906:	mov    r14,r12
   51909:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5190e:	mov    QWORD PTR [rsp+0xd0],r12
   51916:	mov    r12,r14
   51919:	movsxd rax,DWORD PTR [rbp+0x4]
   5191d:	imul   rax,rax,0x38
   51921:	lea    r13,[rbx+rax*1]
   51925:	movsxd rcx,DWORD PTR [rbp+0x8]
   51929:	imul   rcx,rcx,0x38
   5192d:	lea    rdx,[rbx+rcx*1]
   51931:	movsxd rsi,DWORD PTR [rbp+0xc]
   51935:	imul   rsi,rsi,0x38
   51939:	lea    r15,[rbx+rsi*1]
   5193d:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51942:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   51947:	or     eax,ecx
   51949:	and    eax,0x1
   5194c:	test   eax,eax
   5194e:	je     51987 <sqlite3VdbeExec+0x24e7>
   51950:	movzx  eax,WORD PTR [r15+0x14]
   51955:	and    eax,0x9000
   5195a:	test   eax,eax
   5195c:	je     51978 <sqlite3VdbeExec+0x24d8>
   5195e:	mov    QWORD PTR [rsp+0xb0],rdi
   51966:	mov    rdi,r15
   51969:	call   5196e <sqlite3VdbeExec+0x24ce>
   5196e:	mov    rdi,QWORD PTR [rsp+0xb0]
   51976:	jmp    5197f <sqlite3VdbeExec+0x24df>
   51978:	mov    WORD PTR [r15+0x14],0x1
   5197f:	mov    r14,r12
   51982:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   51987:	movzx  eax,WORD PTR [rdx+0x14]
   5198b:	mov    ecx,eax
   5198d:	and    ecx,0x24
   51990:	test   ecx,ecx
   51992:	je     5199c <sqlite3VdbeExec+0x24fc>
   51994:	mov    rax,QWORD PTR [rdx]
   51997:	jmp    51a1c <sqlite3VdbeExec+0x257c>
   5199c:	mov    ecx,eax
   5199e:	and    ecx,0x8
   519a1:	test   ecx,ecx
   519a3:	je     519f2 <sqlite3VdbeExec+0x2552>
   519a5:	movsd  xmm1,QWORD PTR [rdx]
   519a9:	movabs r11,0xc3dfffffffffffff
   519b3:	movq   xmm0,r11
   519b8:	ucomisd xmm0,xmm1
   519bc:	jbe    519ca <sqlite3VdbeExec+0x252a>
   519be:	movabs rax,0x8000000000000000
   519c8:	jmp    519f0 <sqlite3VdbeExec+0x2550>
   519ca:	movabs r11,0x43dfffffffffffff
   519d4:	movq   xmm0,r11
   519d9:	ucomisd xmm1,xmm0
   519dd:	jbe    519eb <sqlite3VdbeExec+0x254b>
   519df:	movabs rax,0x7fffffffffffffff
   519e9:	jmp    519f0 <sqlite3VdbeExec+0x2550>
   519eb:	cvttsd2si rax,xmm1
   519f0:	jmp    51a1c <sqlite3VdbeExec+0x257c>
   519f2:	and    eax,0x12
   519f5:	test   eax,eax
   519f7:	je     51a1a <sqlite3VdbeExec+0x257a>
   519f9:	cmp    QWORD PTR [rdx+0x8],0x0
   519fe:	je     51a1a <sqlite3VdbeExec+0x257a>
   51a00:	mov    QWORD PTR [rsp+0xb0],rdi
   51a08:	mov    rdi,rdx
   51a0b:	call   51a10 <sqlite3VdbeExec+0x2570>
   51a10:	mov    rdi,QWORD PTR [rsp+0xb0]
   51a18:	jmp    51a1c <sqlite3VdbeExec+0x257c>
   51a1a:	xor    eax,eax
   51a1c:	mov    QWORD PTR [rsp+0x110],rax
   51a24:	movzx  eax,WORD PTR [r13+0x14]
   51a29:	mov    ecx,eax
   51a2b:	and    ecx,0x24
   51a2e:	test   ecx,ecx
   51a30:	je     51a3b <sqlite3VdbeExec+0x259b>
   51a32:	mov    rax,QWORD PTR [r13+0x0]
   51a36:	jmp    51abd <sqlite3VdbeExec+0x261d>
   51a3b:	mov    ecx,eax
   51a3d:	and    ecx,0x8
   51a40:	test   ecx,ecx
   51a42:	je     51a93 <sqlite3VdbeExec+0x25f3>
   51a44:	movsd  xmm1,QWORD PTR [r13+0x0]
   51a4a:	movabs r11,0xc3dfffffffffffff
   51a54:	movq   xmm0,r11
   51a59:	ucomisd xmm0,xmm1
   51a5d:	jbe    51a6b <sqlite3VdbeExec+0x25cb>
   51a5f:	movabs rax,0x8000000000000000
   51a69:	jmp    51a91 <sqlite3VdbeExec+0x25f1>
   51a6b:	movabs r11,0x43dfffffffffffff
   51a75:	movq   xmm0,r11
   51a7a:	ucomisd xmm1,xmm0
   51a7e:	jbe    51a8c <sqlite3VdbeExec+0x25ec>
   51a80:	movabs rax,0x7fffffffffffffff
   51a8a:	jmp    51a91 <sqlite3VdbeExec+0x25f1>
   51a8c:	cvttsd2si rax,xmm1
   51a91:	jmp    51abd <sqlite3VdbeExec+0x261d>
   51a93:	and    eax,0x12
   51a96:	test   eax,eax
   51a98:	je     51abb <sqlite3VdbeExec+0x261b>
   51a9a:	cmp    QWORD PTR [r13+0x8],0x0
   51a9f:	je     51abb <sqlite3VdbeExec+0x261b>
   51aa1:	mov    QWORD PTR [rsp+0xb0],rdi
   51aa9:	mov    rdi,r13
   51aac:	call   51ab1 <sqlite3VdbeExec+0x2611>
   51ab1:	mov    rdi,QWORD PTR [rsp+0xb0]
   51ab9:	jmp    51abd <sqlite3VdbeExec+0x261d>
   51abb:	xor    eax,eax
   51abd:	movzx  ecx,BYTE PTR [rbp+0x0]
   51ac1:	mov    edx,ecx
   51ac3:	cmp    edx,0x67
   51ac6:	jne    51add <sqlite3VdbeExec+0x263d>
   51ac8:	and    rax,QWORD PTR [rsp+0x110]
   51ad0:	mov    QWORD PTR [rsp+0x110],rax
   51ad8:	jmp    51bd6 <sqlite3VdbeExec+0x2736>
   51add:	mov    edx,ecx
   51adf:	cmp    edx,0x68
   51ae2:	jne    51af9 <sqlite3VdbeExec+0x2659>
   51ae4:	or     rax,QWORD PTR [rsp+0x110]
   51aec:	mov    QWORD PTR [rsp+0x110],rax
   51af4:	jmp    51bd6 <sqlite3VdbeExec+0x2736>
   51af9:	test   rax,rax
   51afc:	je     51bd6 <sqlite3VdbeExec+0x2736>
   51b02:	test   rax,rax
   51b05:	jge    51b24 <sqlite3VdbeExec+0x2684>
   51b07:	mov    edx,0xd3
   51b0c:	mov    r11d,ecx
   51b0f:	mov    ecx,edx
   51b11:	sub    cl,r11b
   51b14:	cmp    rax,0xffffffffffffffc0
   51b18:	jle    51b1f <sqlite3VdbeExec+0x267f>
   51b1a:	neg    rax
   51b1d:	jmp    51b24 <sqlite3VdbeExec+0x2684>
   51b1f:	mov    eax,0x40
   51b24:	cmp    rax,0x40
   51b28:	jl     51b52 <sqlite3VdbeExec+0x26b2>
   51b2a:	cmp    QWORD PTR [rsp+0x110],0x0
   51b33:	jge    51b3a <sqlite3VdbeExec+0x269a>
   51b35:	cmp    ecx,0x69
   51b38:	jne    51b3e <sqlite3VdbeExec+0x269e>
   51b3a:	xor    eax,eax
   51b3c:	jmp    51b45 <sqlite3VdbeExec+0x26a5>
   51b3e:	mov    rax,0xffffffffffffffff
   51b45:	mov    QWORD PTR [rsp+0x110],rax
   51b4d:	jmp    51bd6 <sqlite3VdbeExec+0x2736>
   51b52:	mov    rdx,QWORD PTR [rsp+0x110]
   51b5a:	mov    QWORD PTR [rsp+0x108],rdx
   51b62:	cmp    ecx,0x69
   51b65:	jne    51b81 <sqlite3VdbeExec+0x26e1>
   51b67:	mov    rdx,QWORD PTR [rsp+0x108]
   51b6f:	mov    ecx,eax
   51b71:	mov    rax,rdx
   51b74:	shl    rax,cl
   51b77:	mov    QWORD PTR [rsp+0x108],rax
   51b7f:	jmp    51bc6 <sqlite3VdbeExec+0x2726>
   51b81:	mov    rdx,QWORD PTR [rsp+0x108]
   51b89:	mov    ecx,eax
   51b8b:	shr    rdx,cl
   51b8e:	mov    QWORD PTR [rsp+0x108],rdx
   51b96:	cmp    QWORD PTR [rsp+0x110],0x0
   51b9f:	jge    51bc6 <sqlite3VdbeExec+0x2726>
   51ba1:	mov    rdx,0xffffffffffffffff
   51ba8:	mov    ecx,0x40
   51bad:	sub    rcx,rax
   51bb0:	mov    rax,rdx
   51bb3:	shl    rax,cl
   51bb6:	or     rax,QWORD PTR [rsp+0x108]
   51bbe:	mov    QWORD PTR [rsp+0x108],rax
   51bc6:	mov    rax,QWORD PTR [rsp+0x108]
   51bce:	mov    QWORD PTR [rsp+0x110],rax
   51bd6:	mov    rax,QWORD PTR [rsp+0x110]
   51bde:	mov    QWORD PTR [r15],rax
   51be1:	movzx  eax,WORD PTR [r15+0x14]
   51be6:	and    eax,0xfffff240
   51beb:	or     eax,0x4
   51bee:	mov    WORD PTR [r15+0x14],ax
   51bf3:	mov    r14,r12
   51bf6:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   51bfb:	mov    QWORD PTR [rsp+0xd0],r12
   51c03:	mov    r12,r14
   51c06:	movsxd rax,DWORD PTR [rbp+0x4]
   51c0a:	imul   rax,rax,0x38
   51c0e:	lea    r13,[rbx+rax*1]
   51c12:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51c17:	mov    ecx,eax
   51c19:	and    ecx,0x24
   51c1c:	test   ecx,ecx
   51c1e:	je     51c31 <sqlite3VdbeExec+0x2791>
   51c20:	mov    rax,QWORD PTR [r13+0x0]
   51c24:	mov    r15d,DWORD PTR [rsp+0x31c]
   51c2c:	jmp    51ccb <sqlite3VdbeExec+0x282b>
   51c31:	mov    ecx,eax
   51c33:	and    ecx,0x8
   51c36:	test   ecx,ecx
   51c38:	je     51c91 <sqlite3VdbeExec+0x27f1>
   51c3a:	movsd  xmm1,QWORD PTR [r13+0x0]
   51c40:	movabs r11,0xc3dfffffffffffff
   51c4a:	movq   xmm0,r11
   51c4f:	ucomisd xmm0,xmm1
   51c53:	jbe    51c61 <sqlite3VdbeExec+0x27c1>
   51c55:	movabs rax,0x8000000000000000
   51c5f:	jmp    51c87 <sqlite3VdbeExec+0x27e7>
   51c61:	movabs r11,0x43dfffffffffffff
   51c6b:	movq   xmm0,r11
   51c70:	ucomisd xmm1,xmm0
   51c74:	jbe    51c82 <sqlite3VdbeExec+0x27e2>
   51c76:	movabs rax,0x7fffffffffffffff
   51c80:	jmp    51c87 <sqlite3VdbeExec+0x27e7>
   51c82:	cvttsd2si rax,xmm1
   51c87:	mov    r15d,DWORD PTR [rsp+0x31c]
   51c8f:	jmp    51ccb <sqlite3VdbeExec+0x282b>
   51c91:	and    eax,0x12
   51c94:	test   eax,eax
   51c96:	je     51cc1 <sqlite3VdbeExec+0x2821>
   51c98:	cmp    QWORD PTR [r13+0x8],0x0
   51c9d:	je     51cc1 <sqlite3VdbeExec+0x2821>
   51c9f:	mov    QWORD PTR [rsp+0xb0],rdi
   51ca7:	mov    rdi,r13
   51caa:	call   51caf <sqlite3VdbeExec+0x280f>
   51caf:	mov    rdi,QWORD PTR [rsp+0xb0]
   51cb7:	mov    r15d,DWORD PTR [rsp+0x31c]
   51cbf:	jmp    51ccb <sqlite3VdbeExec+0x282b>
   51cc1:	xor    eax,eax
   51cc3:	mov    r15d,DWORD PTR [rsp+0x31c]
   51ccb:	mov    QWORD PTR [r13+0x0],rax
   51ccf:	movzx  eax,WORD PTR [r13+0x14]
   51cd4:	and    eax,0xfffff240
   51cd9:	or     eax,0x4
   51cdc:	mov    WORD PTR [r13+0x14],ax
   51ce1:	mov    rax,QWORD PTR [r13+0x0]
   51ce5:	movsxd rcx,DWORD PTR [rbp+0x8]
   51ce9:	add    rax,rcx
   51cec:	mov    QWORD PTR [r13+0x0],rax
   51cf0:	mov    r14,r12
   51cf3:	mov    DWORD PTR [rsp+0x31c],r15d
   51cfb:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   51d00:	mov    r15d,DWORD PTR [rsp+0x31c]
   51d08:	mov    QWORD PTR [rsp+0xd0],r12
   51d10:	mov    r12,r14
   51d13:	movsxd rax,DWORD PTR [rbp+0x4]
   51d17:	imul   rax,rax,0x38
   51d1b:	lea    r13,[rbx+rax*1]
   51d1f:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51d24:	and    eax,0x4
   51d27:	test   eax,eax
   51d29:	jne    51dc4 <sqlite3VdbeExec+0x2924>
   51d2f:	mov    eax,0x43
   51d34:	mov    ecx,r15d
   51d37:	mov    QWORD PTR [rsp+0xb0],rdi
   51d3f:	mov    rdi,r13
   51d42:	mov    rsi,rax
   51d45:	mov    rdx,rcx
   51d48:	call   51d4d <sqlite3VdbeExec+0x28ad>
   51d4d:	movzx  eax,WORD PTR [r13+0x14]
   51d52:	and    eax,0x4
   51d55:	mov    rdi,QWORD PTR [rsp+0xb0]
   51d5d:	test   eax,eax
   51d5f:	jne    51dc4 <sqlite3VdbeExec+0x2924>
   51d61:	cmp    DWORD PTR [rbp+0x8],0x0
   51d65:	jne    51d8f <sqlite3VdbeExec+0x28ef>
   51d67:	mov    ebx,0x14
   51d6c:	mov    r14,r12
   51d6f:	mov    QWORD PTR [rsp+0xe8],rbp
   51d77:	mov    rbp,rbx
   51d7a:	mov    r13,QWORD PTR [rsp+0xd0]
   51d82:	mov    rbx,QWORD PTR [rsp+0xf8]
   51d8a:	jmp    4f712 <sqlite3VdbeExec+0x272>
   51d8f:	mov    eax,DWORD PTR [rbp+0x8]
   51d92:	sub    eax,0x1
   51d95:	movsxd rax,eax
   51d98:	imul   rax,rax,0x18
   51d9c:	mov    rbp,QWORD PTR [rsp+0xf0]
   51da4:	lea    r14,[rbp+rax*1+0x0]
   51da9:	mov    DWORD PTR [rsp+0x31c],r15d
   51db1:	mov    QWORD PTR [rsp+0xf0],rbp
   51db9:	mov    rbp,r14
   51dbc:	mov    r14,r12
   51dbf:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   51dc4:	movzx  eax,WORD PTR [r13+0x14]
   51dc9:	and    eax,0xfffff240
   51dce:	or     eax,0x4
   51dd1:	mov    WORD PTR [r13+0x14],ax
   51dd6:	mov    r14,r12
   51dd9:	mov    DWORD PTR [rsp+0x31c],r15d
   51de1:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   51de6:	mov    r15d,DWORD PTR [rsp+0x31c]
   51dee:	mov    QWORD PTR [rsp+0xd0],r12
   51df6:	mov    r12,r14
   51df9:	movsxd rax,DWORD PTR [rbp+0x4]
   51dfd:	imul   rax,rax,0x38
   51e01:	lea    r13,[rbx+rax*1]
   51e05:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51e0a:	and    eax,0x24
   51e0d:	test   eax,eax
   51e0f:	je     51e83 <sqlite3VdbeExec+0x29e3>
   51e11:	movzx  eax,WORD PTR [r13+0x14]
   51e16:	and    eax,0x8
   51e19:	test   eax,eax
   51e1b:	je     51e25 <sqlite3VdbeExec+0x2985>
   51e1d:	movsd  xmm1,QWORD PTR [r13+0x0]
   51e23:	jmp    51e6b <sqlite3VdbeExec+0x29cb>
   51e25:	movzx  eax,WORD PTR [r13+0x14]
   51e2a:	and    eax,0x24
   51e2d:	test   eax,eax
   51e2f:	je     51e3f <sqlite3VdbeExec+0x299f>
   51e31:	mov    rax,QWORD PTR [r13+0x0]
   51e35:	xorps  xmm1,xmm1
   51e38:	cvtsi2sd xmm1,rax
   51e3d:	jmp    51e6b <sqlite3VdbeExec+0x29cb>
   51e3f:	movzx  eax,WORD PTR [r13+0x14]
   51e44:	and    eax,0x12
   51e47:	test   eax,eax
   51e49:	je     51e68 <sqlite3VdbeExec+0x29c8>
   51e4b:	mov    QWORD PTR [rsp+0xb0],rdi
   51e53:	mov    rdi,r13
   51e56:	call   51e5b <sqlite3VdbeExec+0x29bb>
   51e5b:	movaps xmm1,xmm0
   51e5e:	mov    rdi,QWORD PTR [rsp+0xb0]
   51e66:	jmp    51e6b <sqlite3VdbeExec+0x29cb>
   51e68:	xorps  xmm1,xmm1
   51e6b:	movsd  QWORD PTR [r13+0x0],xmm1
   51e71:	movzx  eax,WORD PTR [r13+0x14]
   51e76:	and    eax,0xfffff240
   51e7b:	or     eax,0x8
   51e7e:	mov    WORD PTR [r13+0x14],ax
   51e83:	mov    r14,r12
   51e86:	mov    DWORD PTR [rsp+0x31c],r15d
   51e8e:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   51e93:	mov    r15d,DWORD PTR [rsp+0x31c]
   51e9b:	mov    QWORD PTR [rsp+0xd0],r12
   51ea3:	mov    r12,r14
   51ea6:	movsxd rax,DWORD PTR [rbp+0x4]
   51eaa:	imul   rax,rax,0x38
   51eae:	lea    r13,[rbx+rax*1]
   51eb2:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51eb7:	and    eax,0x400
   51ebc:	test   eax,eax
   51ebe:	je     51f59 <sqlite3VdbeExec+0x2ab9>
   51ec4:	mov    eax,DWORD PTR [r13+0x10]
   51ec8:	add    eax,DWORD PTR [r13+0x0]
   51ecc:	test   eax,eax
   51ece:	jg     51ee6 <sqlite3VdbeExec+0x2a46>
   51ed0:	movzx  eax,WORD PTR [r13+0x14]
   51ed5:	and    eax,0x10
   51ed8:	test   eax,eax
   51eda:	jne    51ee1 <sqlite3VdbeExec+0x2a41>
   51edc:	xor    r14d,r14d
   51edf:	jmp    51f57 <sqlite3VdbeExec+0x2ab7>
   51ee1:	mov    eax,0x1
   51ee6:	mov    ecx,0x1
   51eeb:	mov    QWORD PTR [rsp+0xb0],rdi
   51ef3:	mov    rdi,r13
   51ef6:	mov    rsi,rax
   51ef9:	mov    rdx,rcx
   51efc:	call   51f01 <sqlite3VdbeExec+0x2a61>
   51f01:	mov    rdi,QWORD PTR [rsp+0xb0]
   51f09:	test   eax,eax
   51f0b:	je     51f15 <sqlite3VdbeExec+0x2a75>
   51f0d:	mov    r14d,0x7
   51f13:	jmp    51f57 <sqlite3VdbeExec+0x2ab7>
   51f15:	mov    rax,QWORD PTR [r13+0x8]
   51f19:	movsxd rcx,DWORD PTR [r13+0x10]
   51f1d:	add    rax,rcx
   51f20:	xor    ecx,ecx
   51f22:	movsxd rdx,DWORD PTR [r13+0x0]
   51f26:	mov    rdi,rax
   51f29:	mov    rsi,rcx
   51f2c:	call   51f31 <sqlite3VdbeExec+0x2a91>
   51f31:	mov    eax,DWORD PTR [r13+0x10]
   51f35:	add    eax,DWORD PTR [r13+0x0]
   51f39:	mov    DWORD PTR [r13+0x10],eax
   51f3d:	movzx  eax,WORD PTR [r13+0x14]
   51f42:	and    eax,0xfffff9ff
   51f47:	mov    WORD PTR [r13+0x14],ax
   51f4c:	xor    r14d,r14d
   51f4f:	mov    rdi,QWORD PTR [rsp+0xb0]
   51f57:	jmp    51f5c <sqlite3VdbeExec+0x2abc>
   51f59:	xor    r14d,r14d
   51f5c:	test   r14d,r14d
   51f5f:	je     51f84 <sqlite3VdbeExec+0x2ae4>
   51f61:	mov    QWORD PTR [rsp+0xe8],rbp
   51f69:	mov    rbp,r14
   51f6c:	mov    r14,r12
   51f6f:	mov    r13,QWORD PTR [rsp+0xd0]
   51f77:	mov    rbx,QWORD PTR [rsp+0xf8]
   51f7f:	jmp    4f712 <sqlite3VdbeExec+0x272>
   51f84:	mov    eax,DWORD PTR [rbp+0x8]
   51f87:	movzx  eax,al
   51f8a:	mov    ecx,r15d
   51f8d:	mov    QWORD PTR [rsp+0xb0],rdi
   51f95:	mov    rdi,r13
   51f98:	mov    rsi,rax
   51f9b:	mov    rdx,rcx
   51f9e:	call   51fa3 <sqlite3VdbeExec+0x2b03>
   51fa3:	mov    r13d,eax
   51fa6:	mov    rdi,QWORD PTR [rsp+0xb0]
   51fae:	test   r13d,r13d
   51fb1:	je     51fd6 <sqlite3VdbeExec+0x2b36>
   51fb3:	mov    r14,r12
   51fb6:	mov    QWORD PTR [rsp+0xe8],rbp
   51fbe:	mov    rbp,r13
   51fc1:	mov    r13,QWORD PTR [rsp+0xd0]
   51fc9:	mov    rbx,QWORD PTR [rsp+0xf8]
   51fd1:	jmp    4f712 <sqlite3VdbeExec+0x272>
   51fd6:	mov    r14,r12
   51fd9:	mov    DWORD PTR [rsp+0x31c],r15d
   51fe1:	mov    DWORD PTR [rsp+0x32c],r13d
   51fe9:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   51fee:	mov    r15d,DWORD PTR [rsp+0x31c]
   51ff6:	mov    r13,QWORD PTR [rsp+0xf0]
   51ffe:	mov    QWORD PTR [rsp+0xd0],r12
   52006:	mov    r12d,DWORD PTR [rsp+0x334]
   5200e:	movsxd rax,DWORD PTR [rbp+0x4]
   52012:	imul   rax,rax,0x38
   52016:	mov    DWORD PTR [rsp+0x334],r12d
   5201e:	lea    r12,[rbx+rax*1]
   52022:	movsxd rcx,DWORD PTR [rbp+0xc]
   52026:	imul   rcx,rcx,0x38
   5202a:	mov    QWORD PTR [rsp+0xf0],r13
   52032:	lea    r13,[rbx+rcx*1]
   52036:	mov    DWORD PTR [rsp+0x31c],r15d
   5203e:	movzx  r15d,WORD PTR [rbx+rax*1+0x14]
   52044:	mov    QWORD PTR [rsp+0x100],rbx
   5204c:	movzx  ebx,WORD PTR [rbx+rcx*1+0x14]
   52051:	mov    eax,r15d
   52054:	mov    ecx,ebx
   52056:	and    eax,ecx
   52058:	and    eax,0x4
   5205b:	test   eax,eax
   5205d:	je     52116 <sqlite3VdbeExec+0x2c76>
   52063:	mov    rax,QWORD PTR [r13+0x0]
   52067:	cmp    rax,QWORD PTR [r12]
   5206b:	jle    5209d <sqlite3VdbeExec+0x2bfd>
   5206d:	mov    rax,QWORD PTR [rip+0x0]        # 52074 <sqlite3VdbeExec+0x2bd4>
   52074:	movzx  ecx,BYTE PTR [rbp+0x0]
   52078:	cmp    BYTE PTR [rax+rcx*1],0x0
   5207c:	je     52096 <sqlite3VdbeExec+0x2bf6>
   5207e:	mov    r12,r14
   52081:	mov    r15d,DWORD PTR [rsp+0x31c]
   52089:	mov    rbx,QWORD PTR [rsp+0x100]
   52091:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   52096:	mov    ebx,0x1
   5209b:	jmp    52102 <sqlite3VdbeExec+0x2c62>
   5209d:	mov    rax,QWORD PTR [r13+0x0]
   520a1:	cmp    rax,QWORD PTR [r12]
   520a5:	jge    520d7 <sqlite3VdbeExec+0x2c37>
   520a7:	mov    rax,QWORD PTR [rip+0x0]        # 520ae <sqlite3VdbeExec+0x2c0e>
   520ae:	movzx  ecx,BYTE PTR [rbp+0x0]
   520b2:	cmp    BYTE PTR [rax+rcx*1],0x0
   520b6:	je     520d0 <sqlite3VdbeExec+0x2c30>
   520b8:	mov    r12,r14
   520bb:	mov    r15d,DWORD PTR [rsp+0x31c]
   520c3:	mov    rbx,QWORD PTR [rsp+0x100]
   520cb:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   520d0:	mov    ebx,0xffffffff
   520d5:	jmp    52102 <sqlite3VdbeExec+0x2c62>
   520d7:	mov    rax,QWORD PTR [rip+0x0]        # 520de <sqlite3VdbeExec+0x2c3e>
   520de:	movzx  ecx,BYTE PTR [rbp+0x0]
   520e2:	cmp    BYTE PTR [rax+rcx*1],0x0
   520e6:	je     52100 <sqlite3VdbeExec+0x2c60>
   520e8:	mov    r12,r14
   520eb:	mov    r15d,DWORD PTR [rsp+0x31c]
   520f3:	mov    rbx,QWORD PTR [rsp+0x100]
   520fb:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   52100:	xor    ebx,ebx
   52102:	mov    DWORD PTR [rsp+0x330],ebx
   52109:	mov    rbx,QWORD PTR [rsp+0x100]
   52111:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   52116:	mov    eax,r15d
   52119:	mov    ecx,ebx
   5211b:	or     eax,ecx
   5211d:	and    eax,0x1
   52120:	test   eax,eax
   52122:	je     521d1 <sqlite3VdbeExec+0x2d31>
   52128:	movzx  eax,WORD PTR [rbp+0x2]
   5212c:	and    eax,0x80
   52131:	test   eax,eax
   52133:	je     52195 <sqlite3VdbeExec+0x2cf5>
   52135:	mov    eax,r15d
   52138:	mov    ecx,ebx
   5213a:	and    eax,ecx
   5213c:	and    eax,0x1
   5213f:	test   eax,eax
   52141:	je     5215b <sqlite3VdbeExec+0x2cbb>
   52143:	mov    eax,ebx
   52145:	and    eax,0x100
   5214a:	test   eax,eax
   5214c:	jne    5215b <sqlite3VdbeExec+0x2cbb>
   5214e:	xor    r11d,r11d
   52151:	mov    DWORD PTR [rsp+0x330],r11d
   52159:	jmp    52182 <sqlite3VdbeExec+0x2ce2>
   5215b:	mov    eax,ebx
   5215d:	and    eax,0x1
   52160:	test   eax,eax
   52162:	je     52174 <sqlite3VdbeExec+0x2cd4>
   52164:	mov    r11d,0xffffffff
   5216a:	mov    DWORD PTR [rsp+0x330],r11d
   52172:	jmp    52182 <sqlite3VdbeExec+0x2ce2>
   52174:	mov    r11d,0x1
   5217a:	mov    DWORD PTR [rsp+0x330],r11d
   52182:	mov    DWORD PTR [rsp+0x338],ebx
   52189:	mov    ebx,DWORD PTR [rsp+0x330]
   52190:	jmp    523be <sqlite3VdbeExec+0x2f1e>
   52195:	movzx  eax,WORD PTR [rbp+0x2]
   52199:	and    eax,0x10
   5219c:	test   eax,eax
   5219e:	je     521b8 <sqlite3VdbeExec+0x2d18>
   521a0:	mov    r12,r14
   521a3:	mov    r15d,DWORD PTR [rsp+0x31c]
   521ab:	mov    rbx,QWORD PTR [rsp+0x100]
   521b3:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   521b8:	mov    ebx,0x1
   521bd:	mov    DWORD PTR [rsp+0x330],ebx
   521c4:	mov    rbx,QWORD PTR [rsp+0x100]
   521cc:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   521d1:	movzx  eax,WORD PTR [rbp+0x2]
   521d5:	and    eax,0x47
   521d8:	mov    ecx,eax
   521da:	cmp    ecx,0x43
   521dd:	jl     52246 <sqlite3VdbeExec+0x2da6>
   521df:	mov    eax,r15d
   521e2:	mov    ecx,ebx
   521e4:	or     eax,ecx
   521e6:	and    eax,0x2
   521e9:	test   eax,eax
   521eb:	je     52241 <sqlite3VdbeExec+0x2da1>
   521ed:	mov    eax,r15d
   521f0:	and    eax,0x2e
   521f3:	cmp    eax,0x2
   521f6:	jne    5221a <sqlite3VdbeExec+0x2d7a>
   521f8:	xor    eax,eax
   521fa:	mov    QWORD PTR [rsp+0xb0],rdi
   52202:	mov    rdi,r12
   52205:	mov    rsi,rax
   52208:	call   5220d <sqlite3VdbeExec+0x2d6d>
   5220d:	movzx  ebx,WORD PTR [r13+0x14]
   52212:	mov    rdi,QWORD PTR [rsp+0xb0]
   5221a:	mov    eax,ebx
   5221c:	and    eax,0x2e
   5221f:	cmp    eax,0x2
   52222:	jne    52241 <sqlite3VdbeExec+0x2da1>
   52224:	xor    eax,eax
   52226:	mov    QWORD PTR [rsp+0xb0],rdi
   5222e:	mov    rdi,r13
   52231:	mov    rsi,rax
   52234:	call   52239 <sqlite3VdbeExec+0x2d99>
   52239:	mov    rdi,QWORD PTR [rsp+0xb0]
   52241:	jmp    52393 <sqlite3VdbeExec+0x2ef3>
   52246:	cmp    eax,0x42
   52249:	jne    52393 <sqlite3VdbeExec+0x2ef3>
   5224f:	mov    eax,r15d
   52252:	mov    ecx,ebx
   52254:	or     eax,ecx
   52256:	and    eax,0x2
   52259:	test   eax,eax
   5225b:	je     52393 <sqlite3VdbeExec+0x2ef3>
   52261:	mov    eax,r15d
   52264:	and    eax,0x2
   52267:	test   eax,eax
   52269:	je     5228c <sqlite3VdbeExec+0x2dec>
   5226b:	movzx  eax,WORD PTR [r12+0x14]
   52271:	and    eax,0xffffffd3
   52274:	mov    WORD PTR [r12+0x14],ax
   5227a:	mov    QWORD PTR [rsp+0xc8],r14
   52282:	mov    r14d,DWORD PTR [rsp+0x31c]
   5228a:	jmp    52304 <sqlite3VdbeExec+0x2e64>
   5228c:	mov    eax,r15d
   5228f:	and    eax,0x2c
   52292:	test   eax,eax
   52294:	jne    522a8 <sqlite3VdbeExec+0x2e08>
   52296:	mov    QWORD PTR [rsp+0xc8],r14
   5229e:	mov    r14d,DWORD PTR [rsp+0x31c]
   522a6:	jmp    52304 <sqlite3VdbeExec+0x2e64>
   522a8:	mov    QWORD PTR [rsp+0xc8],r14
   522b0:	mov    r14d,DWORD PTR [rsp+0x31c]
   522b8:	mov    eax,r14d
   522bb:	mov    ecx,0x1
   522c0:	mov    QWORD PTR [rsp+0xb0],rdi
   522c8:	mov    rdi,r12
   522cb:	mov    rsi,rax
   522ce:	mov    rdx,rcx
   522d1:	call   522d6 <sqlite3VdbeExec+0x2e36>
   522d6:	movzx  eax,WORD PTR [r12+0x14]
   522dc:	and    eax,0xfffff240
   522e1:	mov    ecx,r15d
   522e4:	and    ecx,0xdbf
   522ea:	or     eax,ecx
   522ec:	mov    r15d,eax
   522ef:	mov    rdi,QWORD PTR [rsp+0xb0]
   522f7:	cmp    r12,r13
   522fa:	jne    52304 <sqlite3VdbeExec+0x2e64>
   522fc:	mov    eax,r15d
   522ff:	or     eax,0x2
   52302:	mov    ebx,eax
   52304:	mov    eax,ebx
   52306:	and    eax,0x2
   52309:	test   eax,eax
   5230b:	je     5232c <sqlite3VdbeExec+0x2e8c>
   5230d:	movzx  eax,WORD PTR [r13+0x14]
   52312:	and    eax,0xffffffd3
   52315:	mov    WORD PTR [r13+0x14],ax
   5231a:	mov    DWORD PTR [rsp+0x31c],r14d
   52322:	mov    r14,QWORD PTR [rsp+0xc8]
   5232a:	jmp    52393 <sqlite3VdbeExec+0x2ef3>
   5232c:	mov    eax,ebx
   5232e:	and    eax,0x2c
   52331:	test   eax,eax
   52333:	jne    52347 <sqlite3VdbeExec+0x2ea7>
   52335:	mov    DWORD PTR [rsp+0x31c],r14d
   5233d:	mov    r14,QWORD PTR [rsp+0xc8]
   52345:	jmp    52393 <sqlite3VdbeExec+0x2ef3>
   52347:	mov    eax,r14d
   5234a:	mov    ecx,0x1
   5234f:	mov    QWORD PTR [rsp+0xb0],rdi
   52357:	mov    rdi,r13
   5235a:	mov    rsi,rax
   5235d:	mov    rdx,rcx
   52360:	call   52365 <sqlite3VdbeExec+0x2ec5>
   52365:	movzx  eax,WORD PTR [r13+0x14]
   5236a:	and    eax,0xfffff240
   5236f:	mov    ecx,ebx
   52371:	and    ecx,0xdbf
   52377:	or     eax,ecx
   52379:	mov    ebx,eax
   5237b:	mov    rdi,QWORD PTR [rsp+0xb0]
   52383:	mov    DWORD PTR [rsp+0x31c],r14d
   5238b:	mov    r14,QWORD PTR [rsp+0xc8]
   52393:	mov    rax,QWORD PTR [rbp+0x10]
   52397:	mov    DWORD PTR [rsp+0x338],ebx
   5239e:	mov    QWORD PTR [rsp+0xb0],rdi
   523a6:	mov    rdi,r13
   523a9:	mov    rsi,r12
   523ac:	mov    rdx,rax
   523af:	call   523b4 <sqlite3VdbeExec+0x2f14>
   523b4:	mov    ebx,eax
   523b6:	mov    rdi,QWORD PTR [rsp+0xb0]
   523be:	test   ebx,ebx
   523c0:	jge    523d3 <sqlite3VdbeExec+0x2f33>
   523c2:	mov    rax,QWORD PTR [rip+0x0]        # 523c9 <sqlite3VdbeExec+0x2f29>
   523c9:	movzx  ecx,BYTE PTR [rbp+0x0]
   523cd:	movzx  eax,BYTE PTR [rax+rcx*1]
   523d1:	jmp    523f7 <sqlite3VdbeExec+0x2f57>
   523d3:	test   ebx,ebx
   523d5:	jne    523e8 <sqlite3VdbeExec+0x2f48>
   523d7:	mov    rax,QWORD PTR [rip+0x0]        # 523de <sqlite3VdbeExec+0x2f3e>
   523de:	movzx  ecx,BYTE PTR [rbp+0x0]
   523e2:	movzx  eax,BYTE PTR [rax+rcx*1]
   523e6:	jmp    523f7 <sqlite3VdbeExec+0x2f57>
   523e8:	mov    rax,QWORD PTR [rip+0x0]        # 523ef <sqlite3VdbeExec+0x2f4f>
   523ef:	movzx  ecx,BYTE PTR [rbp+0x0]
   523f3:	movzx  eax,BYTE PTR [rax+rcx*1]
   523f7:	mov    DWORD PTR [rsp+0x330],ebx
   523fe:	mov    ebx,DWORD PTR [rsp+0x338]
   52405:	mov    WORD PTR [r13+0x14],bx
   5240a:	mov    WORD PTR [r12+0x14],r15w
   52410:	test   eax,eax
   52412:	je     5242c <sqlite3VdbeExec+0x2f8c>
   52414:	mov    r12,r14
   52417:	mov    r15d,DWORD PTR [rsp+0x31c]
   5241f:	mov    rbx,QWORD PTR [rsp+0x100]
   52427:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5242c:	mov    rbx,QWORD PTR [rsp+0x100]
   52434:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   52439:	mov    r15d,DWORD PTR [rsp+0x31c]
   52441:	mov    r13,QWORD PTR [rsp+0xf0]
   52449:	mov    QWORD PTR [rsp+0xd0],r12
   52451:	mov    r12d,DWORD PTR [rsp+0x334]
   52459:	mov    DWORD PTR [rsp+0x334],r12d
   52461:	mov    r12d,DWORD PTR [rsp+0x330]
   52469:	test   r12d,r12d
   5246c:	jne    52486 <sqlite3VdbeExec+0x2fe6>
   5246e:	mov    QWORD PTR [rsp+0xf0],r13
   52476:	mov    DWORD PTR [rsp+0x330],r12d
   5247e:	mov    r12,r14
   52481:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   52486:	mov    DWORD PTR [rsp+0x31c],r15d
   5248e:	mov    QWORD PTR [rsp+0xf0],r13
   52496:	mov    DWORD PTR [rsp+0x330],r12d
   5249e:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   524a3:	mov    r15d,DWORD PTR [rsp+0x31c]
   524ab:	mov    r13,QWORD PTR [rsp+0xf0]
   524b3:	mov    QWORD PTR [rsp+0xd0],r12
   524bb:	mov    r12d,DWORD PTR [rsp+0x330]
   524c3:	mov    DWORD PTR [rsp+0x31c],r15d
   524cb:	mov    QWORD PTR [rsp+0xf0],r13
   524d3:	mov    DWORD PTR [rsp+0x330],r12d
   524db:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   524e0:	mov    r15d,DWORD PTR [rsp+0x31c]
   524e8:	mov    r13,QWORD PTR [rsp+0xf0]
   524f0:	mov    QWORD PTR [rsp+0xd0],r12
   524f8:	mov    r12d,DWORD PTR [rsp+0x330]
   52500:	movzx  eax,WORD PTR [rbp+0x2]
   52504:	and    eax,0x1
   52507:	test   eax,eax
   52509:	jne    52518 <sqlite3VdbeExec+0x3078>
   5250b:	mov    QWORD PTR [rsp+0xf0],r13
   52513:	xor    r13d,r13d
   52516:	jmp    52528 <sqlite3VdbeExec+0x3088>
   52518:	mov    QWORD PTR [rsp+0xf0],r13
   52520:	mov    rax,QWORD PTR [rbp-0x8]
   52524:	lea    r13,[rax+0x4]
   52528:	mov    QWORD PTR [rsp+0x108],r13
   52530:	mov    r13d,DWORD PTR [rbp+0xc]
   52534:	mov    DWORD PTR [rsp+0x338],r13d
   5253c:	mov    r13,QWORD PTR [rbp+0x10]
   52540:	mov    DWORD PTR [rsp+0x330],r12d
   52548:	mov    r12d,DWORD PTR [rbp+0x4]
   5254c:	mov    DWORD PTR [rsp+0x33c],r12d
   52554:	mov    r12d,DWORD PTR [rbp+0x8]
   52558:	mov    QWORD PTR [rsp+0xc8],r14
   52560:	mov    DWORD PTR [rsp+0x31c],r15d
   52568:	mov    r14d,DWORD PTR [rsp+0x33c]
   52570:	mov    QWORD PTR [rsp+0xe8],rbp
   52578:	mov    ebp,DWORD PTR [rsp+0x330]
   5257f:	xor    r15d,r15d
   52582:	jmp    526ca <sqlite3VdbeExec+0x322a>
   52587:	mov    DWORD PTR [rsp+0x338],r12d
   5258f:	mov    DWORD PTR [rsp+0x33c],r14d
   52597:	mov    r14,QWORD PTR [rsp+0xc8]
   5259f:	mov    r12,r15
   525a2:	mov    r15d,DWORD PTR [rsp+0x31c]
   525aa:	mov    rbp,QWORD PTR [rsp+0xe8]
   525b2:	mov    DWORD PTR [rsp+0x31c],r15d
   525ba:	mov    r15,r12
   525bd:	mov    rax,r15
   525c0:	mov    rcx,QWORD PTR [r13+rax*8+0x20]
   525c5:	mov    rdx,QWORD PTR [r13+0x18]
   525c9:	movzx  eax,BYTE PTR [rdx+rax*1]
   525cd:	mov    QWORD PTR [rsp+0xc8],r14
   525d5:	mov    r14d,eax
   525d8:	and    r14d,0x1
   525dc:	mov    DWORD PTR [rsp+0x344],r14d
   525e4:	mov    r14d,DWORD PTR [rsp+0x33c]
   525ec:	lea    eax,[r14+r12*1]
   525f0:	imul   rax,rax,0x38
   525f4:	add    rax,rbx
   525f7:	mov    QWORD PTR [rsp+0xe8],rbp
   525ff:	mov    ebp,DWORD PTR [rsp+0x340]
   52606:	lea    edx,[rbp+r12*1+0x0]
   5260b:	imul   rdx,rdx,0x38
   5260f:	add    rdx,rbx
   52612:	mov    QWORD PTR [rsp+0xb0],rdi
   5261a:	mov    rdi,rax
   5261d:	mov    rsi,rdx
   52620:	mov    rdx,rcx
   52623:	call   52628 <sqlite3VdbeExec+0x3188>
   52628:	mov    ebp,eax
   5262a:	mov    rdi,QWORD PTR [rsp+0xb0]
   52632:	test   ebp,ebp
   52634:	je     526be <sqlite3VdbeExec+0x321e>
   5263a:	mov    rax,QWORD PTR [r13+0x18]
   5263e:	mov    rcx,r15
   52641:	movzx  eax,BYTE PTR [rax+rcx*1]
   52645:	and    eax,0x2
   52648:	test   eax,eax
   5264a:	jne    52656 <sqlite3VdbeExec+0x31b6>
   5264c:	mov    r14d,DWORD PTR [rsp+0x344]
   52654:	jmp    5269b <sqlite3VdbeExec+0x31fb>
   52656:	lea    eax,[r14+r12*1]
   5265a:	imul   rax,rax,0x38
   5265e:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52663:	and    eax,0x1
   52666:	test   eax,eax
   52668:	jne    52691 <sqlite3VdbeExec+0x31f1>
   5266a:	mov    r13d,DWORD PTR [rsp+0x340]
   52672:	lea    eax,[r13+r12*1+0x0]
   52677:	imul   rax,rax,0x38
   5267b:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52680:	and    eax,0x1
   52683:	test   eax,eax
   52685:	jne    52691 <sqlite3VdbeExec+0x31f1>
   52687:	mov    r14d,DWORD PTR [rsp+0x344]
   5268f:	jmp    5269b <sqlite3VdbeExec+0x31fb>
   52691:	neg    ebp
   52693:	mov    r14d,DWORD PTR [rsp+0x344]
   5269b:	test   r14d,r14d
   5269e:	je     526a2 <sqlite3VdbeExec+0x3202>
   526a0:	neg    ebp
   526a2:	mov    r14,QWORD PTR [rsp+0xc8]
   526aa:	mov    DWORD PTR [rsp+0x330],ebp
   526b1:	mov    rbp,QWORD PTR [rsp+0xe8]
   526b9:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   526be:	mov    r12d,DWORD PTR [rsp+0x340]
   526c6:	add    r15d,0x1
   526ca:	mov    DWORD PTR [rsp+0x340],r12d
   526d2:	mov    r12d,DWORD PTR [rsp+0x338]
   526da:	cmp    r15d,r12d
   526dd:	jge    526a2 <sqlite3VdbeExec+0x3202>
   526df:	mov    rbp,QWORD PTR [rsp+0x108]
   526e7:	test   rbp,rbp
   526ea:	je     52587 <sqlite3VdbeExec+0x30e7>
   526f0:	mov    rax,r15
   526f3:	mov    ebp,DWORD PTR [rbp+rax*4+0x0]
   526f7:	mov    DWORD PTR [rsp+0x338],r12d
   526ff:	mov    DWORD PTR [rsp+0x33c],r14d
   52707:	mov    r14,QWORD PTR [rsp+0xc8]
   5270f:	mov    r12,rbp
   52712:	mov    rbp,QWORD PTR [rsp+0xe8]
   5271a:	jmp    525bd <sqlite3VdbeExec+0x311d>
   5271f:	mov    r15d,DWORD PTR [rsp+0x31c]
   52727:	mov    r13,QWORD PTR [rsp+0xf0]
   5272f:	mov    QWORD PTR [rsp+0xd0],r12
   52737:	mov    r12d,DWORD PTR [rsp+0x334]
   5273f:	mov    DWORD PTR [rsp+0x334],r12d
   52747:	mov    r12d,DWORD PTR [rsp+0x330]
   5274f:	test   r12d,r12d
   52752:	jge    52768 <sqlite3VdbeExec+0x32c8>
   52754:	mov    eax,DWORD PTR [rbp+0x4]
   52757:	sub    eax,0x1
   5275a:	movsxd rax,eax
   5275d:	imul   rax,rax,0x18
   52761:	lea    rbp,[r13+rax*1+0x0]
   52766:	jmp    52793 <sqlite3VdbeExec+0x32f3>
   52768:	test   r12d,r12d
   5276b:	jne    52781 <sqlite3VdbeExec+0x32e1>
   5276d:	mov    eax,DWORD PTR [rbp+0x8]
   52770:	sub    eax,0x1
   52773:	movsxd rax,eax
   52776:	imul   rax,rax,0x18
   5277a:	lea    rbp,[r13+rax*1+0x0]
   5277f:	jmp    52793 <sqlite3VdbeExec+0x32f3>
   52781:	mov    eax,DWORD PTR [rbp+0xc]
   52784:	sub    eax,0x1
   52787:	movsxd rax,eax
   5278a:	imul   rax,rax,0x18
   5278e:	lea    rbp,[r13+rax*1+0x0]
   52793:	mov    DWORD PTR [rsp+0x31c],r15d
   5279b:	mov    QWORD PTR [rsp+0xf0],r13
   527a3:	mov    DWORD PTR [rsp+0x330],r12d
   527ab:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   527b0:	mov    r15d,DWORD PTR [rsp+0x31c]
   527b8:	mov    r13,QWORD PTR [rsp+0xf0]
   527c0:	mov    QWORD PTR [rsp+0xd0],r12
   527c8:	mov    r12d,DWORD PTR [rsp+0x334]
   527d0:	movsxd rax,DWORD PTR [rbp+0x4]
   527d4:	imul   rax,rax,0x38
   527d8:	lea    rcx,[rbx+rax*1]
   527dc:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   527e1:	and    eax,0x24
   527e4:	test   eax,eax
   527e6:	je     52800 <sqlite3VdbeExec+0x3360>
   527e8:	mov    DWORD PTR [rsp+0x334],r12d
   527f0:	xor    r12d,r12d
   527f3:	cmp    QWORD PTR [rcx],0x0
   527f7:	setne  r12b
   527fb:	jmp    52885 <sqlite3VdbeExec+0x33e5>
   52800:	mov    DWORD PTR [rsp+0x334],r12d
   52808:	movzx  eax,WORD PTR [rcx+0x14]
   5280c:	and    eax,0x1
   5280f:	test   eax,eax
   52811:	je     5281b <sqlite3VdbeExec+0x337b>
   52813:	mov    r12d,0x2
   52819:	jmp    52885 <sqlite3VdbeExec+0x33e5>
   5281b:	movzx  eax,WORD PTR [rcx+0x14]
   5281f:	and    eax,0x8
   52822:	test   eax,eax
   52824:	je     5282c <sqlite3VdbeExec+0x338c>
   52826:	movsd  xmm1,QWORD PTR [rcx]
   5282a:	jmp    5286f <sqlite3VdbeExec+0x33cf>
   5282c:	movzx  eax,WORD PTR [rcx+0x14]
   52830:	and    eax,0x24
   52833:	test   eax,eax
   52835:	je     52844 <sqlite3VdbeExec+0x33a4>
   52837:	mov    rax,QWORD PTR [rcx]
   5283a:	xorps  xmm1,xmm1
   5283d:	cvtsi2sd xmm1,rax
   52842:	jmp    5286f <sqlite3VdbeExec+0x33cf>
   52844:	movzx  eax,WORD PTR [rcx+0x14]
   52848:	and    eax,0x12
   5284b:	test   eax,eax
   5284d:	je     5286c <sqlite3VdbeExec+0x33cc>
   5284f:	mov    QWORD PTR [rsp+0xb0],rdi
   52857:	mov    rdi,rcx
   5285a:	call   5285f <sqlite3VdbeExec+0x33bf>
   5285f:	movaps xmm1,xmm0
   52862:	mov    rdi,QWORD PTR [rsp+0xb0]
   5286a:	jmp    5286f <sqlite3VdbeExec+0x33cf>
   5286c:	xorps  xmm1,xmm1
   5286f:	xorps  xmm0,xmm0
   52872:	xor    eax,eax
   52874:	ucomisd xmm1,xmm0
   52878:	setne  al
   5287b:	setp   r11b
   5287f:	or     al,r11b
   52882:	mov    r12d,eax
   52885:	movsxd rax,DWORD PTR [rbp+0x8]
   52889:	imul   rax,rax,0x38
   5288d:	lea    rcx,[rbx+rax*1]
   52891:	mov    edx,0x2
   52896:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5289b:	and    eax,0x24
   5289e:	test   eax,eax
   528a0:	je     528ad <sqlite3VdbeExec+0x340d>
   528a2:	xor    eax,eax
   528a4:	cmp    QWORD PTR [rcx],0x0
   528a8:	setne  al
   528ab:	jmp    52921 <sqlite3VdbeExec+0x3481>
   528ad:	movzx  eax,WORD PTR [rcx+0x14]
   528b1:	and    eax,0x1
   528b4:	test   eax,eax
   528b6:	je     528bd <sqlite3VdbeExec+0x341d>
   528b8:	mov    rax,rdx
   528bb:	jmp    52921 <sqlite3VdbeExec+0x3481>
   528bd:	movzx  eax,WORD PTR [rcx+0x14]
   528c1:	and    eax,0x8
   528c4:	test   eax,eax
   528c6:	je     528ce <sqlite3VdbeExec+0x342e>
   528c8:	movsd  xmm0,QWORD PTR [rcx]
   528cc:	jmp    5290e <sqlite3VdbeExec+0x346e>
   528ce:	movzx  eax,WORD PTR [rcx+0x14]
   528d2:	and    eax,0x24
   528d5:	test   eax,eax
   528d7:	je     528e6 <sqlite3VdbeExec+0x3446>
   528d9:	mov    rax,QWORD PTR [rcx]
   528dc:	xorps  xmm0,xmm0
   528df:	cvtsi2sd xmm0,rax
   528e4:	jmp    5290e <sqlite3VdbeExec+0x346e>
   528e6:	movzx  eax,WORD PTR [rcx+0x14]
   528ea:	and    eax,0x12
   528ed:	test   eax,eax
   528ef:	je     5290b <sqlite3VdbeExec+0x346b>
   528f1:	mov    QWORD PTR [rsp+0xb0],rdi
   528f9:	mov    rdi,rcx
   528fc:	call   52901 <sqlite3VdbeExec+0x3461>
   52901:	mov    rdi,QWORD PTR [rsp+0xb0]
   52909:	jmp    5290e <sqlite3VdbeExec+0x346e>
   5290b:	xorps  xmm0,xmm0
   5290e:	xorps  xmm1,xmm1
   52911:	xor    eax,eax
   52913:	ucomisd xmm0,xmm1
   52917:	setne  al
   5291a:	setp   r11b
   5291e:	or     al,r11b
   52921:	cmp    BYTE PTR [rbp+0x0],0x2c
   52925:	jne    5293a <sqlite3VdbeExec+0x349a>
   52927:	lea    rcx,[rip+0x0]        # 5292e <sqlite3VdbeExec+0x348e>
   5292e:	lea    edx,[r12+r12*2]
   52932:	add    eax,edx
   52934:	movzx  eax,BYTE PTR [rcx+rax*1]
   52938:	jmp    5294b <sqlite3VdbeExec+0x34ab>
   5293a:	lea    rcx,[rip+0x0]        # 52941 <sqlite3VdbeExec+0x34a1>
   52941:	lea    edx,[r12+r12*2]
   52945:	add    eax,edx
   52947:	movzx  eax,BYTE PTR [rcx+rax*1]
   5294b:	movsxd rcx,DWORD PTR [rbp+0xc]
   5294f:	imul   rcx,rcx,0x38
   52953:	cmp    eax,0x2
   52956:	jne    5296c <sqlite3VdbeExec+0x34cc>
   52958:	movzx  eax,WORD PTR [rbx+rcx*1+0x14]
   5295d:	and    eax,0xfffff240
   52962:	or     eax,0x1
   52965:	mov    WORD PTR [rbx+rcx*1+0x14],ax
   5296a:	jmp    52982 <sqlite3VdbeExec+0x34e2>
   5296c:	mov    QWORD PTR [rbx+rcx*1],rax
   52970:	movzx  eax,WORD PTR [rbx+rcx*1+0x14]
   52975:	and    eax,0xfffff240
   5297a:	or     eax,0x4
   5297d:	mov    WORD PTR [rbx+rcx*1+0x14],ax
   52982:	mov    DWORD PTR [rsp+0x31c],r15d
   5298a:	mov    QWORD PTR [rsp+0xf0],r13
   52992:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   52997:	mov    r15d,DWORD PTR [rsp+0x31c]
   5299f:	mov    r13,QWORD PTR [rsp+0xf0]
   529a7:	mov    QWORD PTR [rsp+0xd0],r12
   529af:	movsxd rax,DWORD PTR [rbp+0x8]
   529b3:	imul   rax,rax,0x38
   529b7:	lea    r12,[rbx+rax*1]
   529bb:	movsxd rax,DWORD PTR [rbp+0x4]
   529bf:	imul   rax,rax,0x38
   529c3:	lea    rcx,[rbx+rax*1]
   529c7:	movsxd rdx,DWORD PTR [rbp+0xc]
   529cb:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   529d0:	and    eax,0x24
   529d3:	test   eax,eax
   529d5:	je     529e2 <sqlite3VdbeExec+0x3542>
   529d7:	xor    eax,eax
   529d9:	cmp    QWORD PTR [rcx],0x0
   529dd:	setne  al
   529e0:	jmp    52a59 <sqlite3VdbeExec+0x35b9>
   529e2:	movzx  eax,WORD PTR [rcx+0x14]
   529e6:	and    eax,0x1
   529e9:	test   eax,eax
   529eb:	je     529f2 <sqlite3VdbeExec+0x3552>
   529ed:	mov    rax,rdx
   529f0:	jmp    52a59 <sqlite3VdbeExec+0x35b9>
   529f2:	movzx  eax,WORD PTR [rcx+0x14]
   529f6:	and    eax,0x8
   529f9:	test   eax,eax
   529fb:	je     52a03 <sqlite3VdbeExec+0x3563>
   529fd:	movsd  xmm1,QWORD PTR [rcx]
   52a01:	jmp    52a46 <sqlite3VdbeExec+0x35a6>
   52a03:	movzx  eax,WORD PTR [rcx+0x14]
   52a07:	and    eax,0x24
   52a0a:	test   eax,eax
   52a0c:	je     52a1b <sqlite3VdbeExec+0x357b>
   52a0e:	mov    rax,QWORD PTR [rcx]
   52a11:	xorps  xmm1,xmm1
   52a14:	cvtsi2sd xmm1,rax
   52a19:	jmp    52a46 <sqlite3VdbeExec+0x35a6>
   52a1b:	movzx  eax,WORD PTR [rcx+0x14]
   52a1f:	and    eax,0x12
   52a22:	test   eax,eax
   52a24:	je     52a43 <sqlite3VdbeExec+0x35a3>
   52a26:	mov    QWORD PTR [rsp+0xb0],rdi
   52a2e:	mov    rdi,rcx
   52a31:	call   52a36 <sqlite3VdbeExec+0x3596>
   52a36:	movaps xmm1,xmm0
   52a39:	mov    rdi,QWORD PTR [rsp+0xb0]
   52a41:	jmp    52a46 <sqlite3VdbeExec+0x35a6>
   52a43:	xorps  xmm1,xmm1
   52a46:	xorps  xmm0,xmm0
   52a49:	xor    eax,eax
   52a4b:	ucomisd xmm1,xmm0
   52a4f:	setne  al
   52a52:	setp   r11b
   52a56:	or     al,r11b
   52a59:	movsxd rcx,DWORD PTR [rbp+0x10]
   52a5d:	xor    rax,rcx
   52a60:	movzx  ecx,WORD PTR [r12+0x14]
   52a66:	and    ecx,0x9000
   52a6c:	test   ecx,ecx
   52a6e:	je     52a8d <sqlite3VdbeExec+0x35ed>
   52a70:	mov    QWORD PTR [rsp+0xb0],rdi
   52a78:	mov    rdi,r12
   52a7b:	mov    rsi,rax
   52a7e:	call   52a83 <sqlite3VdbeExec+0x35e3>
   52a83:	mov    rdi,QWORD PTR [rsp+0xb0]
   52a8b:	jmp    52a99 <sqlite3VdbeExec+0x35f9>
   52a8d:	mov    QWORD PTR [r12],rax
   52a91:	mov    WORD PTR [r12+0x14],0x4
   52a99:	mov    DWORD PTR [rsp+0x31c],r15d
   52aa1:	mov    QWORD PTR [rsp+0xf0],r13
   52aa9:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   52aae:	mov    r15d,DWORD PTR [rsp+0x31c]
   52ab6:	mov    r13,QWORD PTR [rsp+0xf0]
   52abe:	mov    QWORD PTR [rsp+0xd0],r12
   52ac6:	movsxd rax,DWORD PTR [rbp+0x4]
   52aca:	imul   rax,rax,0x38
   52ace:	lea    rcx,[rbx+rax*1]
   52ad2:	movsxd rdx,DWORD PTR [rbp+0x8]
   52ad6:	imul   rdx,rdx,0x38
   52ada:	lea    r12,[rbx+rdx*1]
   52ade:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52ae3:	and    eax,0x1
   52ae6:	test   eax,eax
   52ae8:	jne    52bbc <sqlite3VdbeExec+0x371c>
   52aee:	xor    eax,eax
   52af0:	movzx  edx,WORD PTR [rcx+0x14]
   52af4:	and    edx,0x24
   52af7:	test   edx,edx
   52af9:	je     52b06 <sqlite3VdbeExec+0x3666>
   52afb:	xor    eax,eax
   52afd:	cmp    QWORD PTR [rcx],0x0
   52b01:	setne  al
   52b04:	jmp    52b77 <sqlite3VdbeExec+0x36d7>
   52b06:	movzx  edx,WORD PTR [rcx+0x14]
   52b0a:	and    edx,0x1
   52b0d:	test   edx,edx
   52b0f:	je     52b13 <sqlite3VdbeExec+0x3673>
   52b11:	jmp    52b77 <sqlite3VdbeExec+0x36d7>
   52b13:	movzx  eax,WORD PTR [rcx+0x14]
   52b17:	and    eax,0x8
   52b1a:	test   eax,eax
   52b1c:	je     52b24 <sqlite3VdbeExec+0x3684>
   52b1e:	movsd  xmm0,QWORD PTR [rcx]
   52b22:	jmp    52b64 <sqlite3VdbeExec+0x36c4>
   52b24:	movzx  eax,WORD PTR [rcx+0x14]
   52b28:	and    eax,0x24
   52b2b:	test   eax,eax
   52b2d:	je     52b3c <sqlite3VdbeExec+0x369c>
   52b2f:	mov    rax,QWORD PTR [rcx]
   52b32:	xorps  xmm0,xmm0
   52b35:	cvtsi2sd xmm0,rax
   52b3a:	jmp    52b64 <sqlite3VdbeExec+0x36c4>
   52b3c:	movzx  eax,WORD PTR [rcx+0x14]
   52b40:	and    eax,0x12
   52b43:	test   eax,eax
   52b45:	je     52b61 <sqlite3VdbeExec+0x36c1>
   52b47:	mov    QWORD PTR [rsp+0xb0],rdi
   52b4f:	mov    rdi,rcx
   52b52:	call   52b57 <sqlite3VdbeExec+0x36b7>
   52b57:	mov    rdi,QWORD PTR [rsp+0xb0]
   52b5f:	jmp    52b64 <sqlite3VdbeExec+0x36c4>
   52b61:	xorps  xmm0,xmm0
   52b64:	xorps  xmm1,xmm1
   52b67:	xor    eax,eax
   52b69:	ucomisd xmm0,xmm1
   52b6d:	setne  al
   52b70:	setp   r11b
   52b74:	or     al,r11b
   52b77:	test   eax,eax
   52b79:	mov    eax,0x0
   52b7e:	sete   al
   52b81:	movzx  ecx,WORD PTR [r12+0x14]
   52b87:	and    ecx,0x9000
   52b8d:	test   ecx,ecx
   52b8f:	je     52bae <sqlite3VdbeExec+0x370e>
   52b91:	mov    QWORD PTR [rsp+0xb0],rdi
   52b99:	mov    rdi,r12
   52b9c:	mov    rsi,rax
   52b9f:	call   52ba4 <sqlite3VdbeExec+0x3704>
   52ba4:	mov    rdi,QWORD PTR [rsp+0xb0]
   52bac:	jmp    52bed <sqlite3VdbeExec+0x374d>
   52bae:	mov    QWORD PTR [r12],rax
   52bb2:	mov    WORD PTR [r12+0x14],0x4
   52bba:	jmp    52bed <sqlite3VdbeExec+0x374d>
   52bbc:	movzx  eax,WORD PTR [r12+0x14]
   52bc2:	and    eax,0x9000
   52bc7:	test   eax,eax
   52bc9:	je     52be5 <sqlite3VdbeExec+0x3745>
   52bcb:	mov    QWORD PTR [rsp+0xb0],rdi
   52bd3:	mov    rdi,r12
   52bd6:	call   52bdb <sqlite3VdbeExec+0x373b>
   52bdb:	mov    rdi,QWORD PTR [rsp+0xb0]
   52be3:	jmp    52bed <sqlite3VdbeExec+0x374d>
   52be5:	mov    WORD PTR [r12+0x14],0x1
   52bed:	mov    DWORD PTR [rsp+0x31c],r15d
   52bf5:	mov    QWORD PTR [rsp+0xf0],r13
   52bfd:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   52c02:	mov    r15d,DWORD PTR [rsp+0x31c]
   52c0a:	mov    r13,QWORD PTR [rsp+0xf0]
   52c12:	mov    QWORD PTR [rsp+0xd0],r12
   52c1a:	movsxd rax,DWORD PTR [rbp+0x4]
   52c1e:	imul   rax,rax,0x38
   52c22:	lea    r12,[rbx+rax*1]
   52c26:	movsxd rax,DWORD PTR [rbp+0x8]
   52c2a:	imul   rax,rax,0x38
   52c2e:	mov    QWORD PTR [rsp+0xf0],r13
   52c36:	lea    r13,[rbx+rax*1]
   52c3a:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52c3f:	and    eax,0x9000
   52c44:	test   eax,eax
   52c46:	je     52c62 <sqlite3VdbeExec+0x37c2>
   52c48:	mov    QWORD PTR [rsp+0xb0],rdi
   52c50:	mov    rdi,r13
   52c53:	call   52c58 <sqlite3VdbeExec+0x37b8>
   52c58:	mov    rdi,QWORD PTR [rsp+0xb0]
   52c60:	jmp    52c69 <sqlite3VdbeExec+0x37c9>
   52c62:	mov    WORD PTR [r13+0x14],0x1
   52c69:	movzx  eax,WORD PTR [r12+0x14]
   52c6f:	and    eax,0x1
   52c72:	test   eax,eax
   52c74:	jne    52d23 <sqlite3VdbeExec+0x3883>
   52c7a:	mov    WORD PTR [r13+0x14],0x4
   52c81:	movzx  eax,WORD PTR [r12+0x14]
   52c87:	mov    ecx,eax
   52c89:	and    ecx,0x24
   52c8c:	test   ecx,ecx
   52c8e:	je     52c99 <sqlite3VdbeExec+0x37f9>
   52c90:	mov    rax,QWORD PTR [r12]
   52c94:	jmp    52d1c <sqlite3VdbeExec+0x387c>
   52c99:	mov    ecx,eax
   52c9b:	and    ecx,0x8
   52c9e:	test   ecx,ecx
   52ca0:	je     52cf1 <sqlite3VdbeExec+0x3851>
   52ca2:	movsd  xmm1,QWORD PTR [r12]
   52ca8:	movabs r11,0xc3dfffffffffffff
   52cb2:	movq   xmm0,r11
   52cb7:	ucomisd xmm0,xmm1
   52cbb:	jbe    52cc9 <sqlite3VdbeExec+0x3829>
   52cbd:	movabs rax,0x8000000000000000
   52cc7:	jmp    52cef <sqlite3VdbeExec+0x384f>
   52cc9:	movabs r11,0x43dfffffffffffff
   52cd3:	movq   xmm0,r11
   52cd8:	ucomisd xmm1,xmm0
   52cdc:	jbe    52cea <sqlite3VdbeExec+0x384a>
   52cde:	movabs rax,0x7fffffffffffffff
   52ce8:	jmp    52cef <sqlite3VdbeExec+0x384f>
   52cea:	cvttsd2si rax,xmm1
   52cef:	jmp    52d1c <sqlite3VdbeExec+0x387c>
   52cf1:	and    eax,0x12
   52cf4:	test   eax,eax
   52cf6:	je     52d1a <sqlite3VdbeExec+0x387a>
   52cf8:	cmp    QWORD PTR [r12+0x8],0x0
   52cfe:	je     52d1a <sqlite3VdbeExec+0x387a>
   52d00:	mov    QWORD PTR [rsp+0xb0],rdi
   52d08:	mov    rdi,r12
   52d0b:	call   52d10 <sqlite3VdbeExec+0x3870>
   52d10:	mov    rdi,QWORD PTR [rsp+0xb0]
   52d18:	jmp    52d1c <sqlite3VdbeExec+0x387c>
   52d1a:	xor    eax,eax
   52d1c:	not    rax
   52d1f:	mov    QWORD PTR [r13+0x0],rax
   52d23:	mov    DWORD PTR [rsp+0x31c],r15d
   52d2b:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   52d30:	mov    r15d,DWORD PTR [rsp+0x31c]
   52d38:	mov    QWORD PTR [rsp+0xd0],r12
   52d40:	cmp    QWORD PTR [rdi+0x108],0x0
   52d48:	je     52df1 <sqlite3VdbeExec+0x3951>
   52d4e:	mov    rax,rbp
   52d51:	sub    rax,QWORD PTR [rdi+0x88]
   52d58:	movabs rdx,0x2aaaaaaaaaaaaaab
   52d62:	imul   rdx
   52d65:	sar    rdx,0x2
   52d69:	mov    rax,rdx
   52d6c:	shr    rax,0x3f
   52d70:	add    rdx,rax
   52d73:	mov    rax,rdx
   52d76:	mov    rcx,QWORD PTR [rdi+0x108]
   52d7d:	mov    rcx,QWORD PTR [rcx+0x28]
   52d81:	mov    edx,eax
   52d83:	shr    edx,0x3
   52d86:	movzx  ecx,BYTE PTR [rcx+rdx*1]
   52d8a:	mov    edx,ecx
   52d8c:	mov    esi,0x1
   52d91:	mov    ecx,eax
   52d93:	and    ecx,0x7
   52d96:	shl    esi,cl
   52d98:	and    edx,esi
   52d9a:	test   edx,edx
   52d9c:	je     52da6 <sqlite3VdbeExec+0x3906>
   52d9e:	mov    r12,r14
   52da1:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   52da6:	mov    rcx,QWORD PTR [rdi+0x108]
   52dad:	mov    rdx,QWORD PTR [rcx+0x28]
   52db1:	mov    ecx,eax
   52db3:	shr    ecx,0x3
   52db6:	mov    rsi,rcx
   52db9:	movzx  ecx,BYTE PTR [rdx+rsi*1]
   52dbd:	mov    r8d,ecx
   52dc0:	mov    r9d,0x1
   52dc6:	and    eax,0x7
   52dc9:	mov    ecx,eax
   52dcb:	mov    rax,r9
   52dce:	shl    eax,cl
   52dd0:	or     r8d,eax
   52dd3:	mov    BYTE PTR [rdx+rsi*1],r8b
   52dd7:	mov    rax,QWORD PTR [rdi+0x88]
   52dde:	mov    eax,DWORD PTR [rax+0x4]
   52de1:	mov    DWORD PTR [rbp+0x4],eax
   52de4:	mov    DWORD PTR [rsp+0x31c],r15d
   52dec:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   52df1:	mov    rax,QWORD PTR [rdi+0x88]
   52df8:	mov    eax,DWORD PTR [rax+0x4]
   52dfb:	cmp    eax,DWORD PTR [rbp+0x4]
   52dfe:	jne    52dd7 <sqlite3VdbeExec+0x3937>
   52e00:	mov    r12,r14
   52e03:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   52e08:	mov    r15d,DWORD PTR [rsp+0x31c]
   52e10:	mov    QWORD PTR [rsp+0xd0],r12
   52e18:	movsxd rax,DWORD PTR [rbp+0x4]
   52e1c:	imul   rax,rax,0x38
   52e20:	lea    rcx,[rbx+rax*1]
   52e24:	mov    edx,DWORD PTR [rbp+0xc]
   52e27:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52e2c:	and    eax,0x24
   52e2f:	test   eax,eax
   52e31:	je     52e41 <sqlite3VdbeExec+0x39a1>
   52e33:	cmp    QWORD PTR [rcx],0x0
   52e37:	je     52e50 <sqlite3VdbeExec+0x39b0>
   52e39:	mov    r12,r14
   52e3c:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   52e41:	movzx  eax,WORD PTR [rcx+0x14]
   52e45:	and    eax,0x1
   52e48:	test   eax,eax
   52e4a:	je     52e5d <sqlite3VdbeExec+0x39bd>
   52e4c:	test   edx,edx
   52e4e:	jne    52e39 <sqlite3VdbeExec+0x3999>
   52e50:	mov    DWORD PTR [rsp+0x31c],r15d
   52e58:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   52e5d:	movzx  eax,WORD PTR [rcx+0x14]
   52e61:	and    eax,0x8
   52e64:	test   eax,eax
   52e66:	je     52e6e <sqlite3VdbeExec+0x39ce>
   52e68:	movsd  xmm1,QWORD PTR [rcx]
   52e6c:	jmp    52eb1 <sqlite3VdbeExec+0x3a11>
   52e6e:	movzx  eax,WORD PTR [rcx+0x14]
   52e72:	and    eax,0x24
   52e75:	test   eax,eax
   52e77:	je     52e86 <sqlite3VdbeExec+0x39e6>
   52e79:	mov    rax,QWORD PTR [rcx]
   52e7c:	xorps  xmm1,xmm1
   52e7f:	cvtsi2sd xmm1,rax
   52e84:	jmp    52eb1 <sqlite3VdbeExec+0x3a11>
   52e86:	movzx  eax,WORD PTR [rcx+0x14]
   52e8a:	and    eax,0x12
   52e8d:	test   eax,eax
   52e8f:	je     52eae <sqlite3VdbeExec+0x3a0e>
   52e91:	mov    QWORD PTR [rsp+0xb0],rdi
   52e99:	mov    rdi,rcx
   52e9c:	call   52ea1 <sqlite3VdbeExec+0x3a01>
   52ea1:	movaps xmm1,xmm0
   52ea4:	mov    rdi,QWORD PTR [rsp+0xb0]
   52eac:	jmp    52eb1 <sqlite3VdbeExec+0x3a11>
   52eae:	xorps  xmm1,xmm1
   52eb1:	xorps  xmm0,xmm0
   52eb4:	xor    eax,eax
   52eb6:	ucomisd xmm1,xmm0
   52eba:	setne  al
   52ebd:	setp   r11b
   52ec1:	or     al,r11b
   52ec4:	test   eax,eax
   52ec6:	mov    eax,0x0
   52ecb:	setne  al
   52ece:	test   eax,eax
   52ed0:	jne    52e39 <sqlite3VdbeExec+0x3999>
   52ed6:	jmp    52e50 <sqlite3VdbeExec+0x39b0>
   52edb:	mov    r15d,DWORD PTR [rsp+0x31c]
   52ee3:	mov    QWORD PTR [rsp+0xd0],r12
   52eeb:	movsxd rax,DWORD PTR [rbp+0x4]
   52eef:	imul   rax,rax,0x38
   52ef3:	lea    rcx,[rbx+rax*1]
   52ef7:	mov    edx,DWORD PTR [rbp+0xc]
   52efa:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52eff:	and    eax,0x24
   52f02:	test   eax,eax
   52f04:	je     52f14 <sqlite3VdbeExec+0x3a74>
   52f06:	cmp    QWORD PTR [rcx],0x0
   52f0a:	jne    52f23 <sqlite3VdbeExec+0x3a83>
   52f0c:	mov    r12,r14
   52f0f:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   52f14:	movzx  eax,WORD PTR [rcx+0x14]
   52f18:	and    eax,0x1
   52f1b:	test   eax,eax
   52f1d:	je     52f30 <sqlite3VdbeExec+0x3a90>
   52f1f:	test   edx,edx
   52f21:	jne    52f0c <sqlite3VdbeExec+0x3a6c>
   52f23:	mov    DWORD PTR [rsp+0x31c],r15d
   52f2b:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   52f30:	movzx  eax,WORD PTR [rcx+0x14]
   52f34:	and    eax,0x8
   52f37:	test   eax,eax
   52f39:	je     52f41 <sqlite3VdbeExec+0x3aa1>
   52f3b:	movsd  xmm0,QWORD PTR [rcx]
   52f3f:	jmp    52f81 <sqlite3VdbeExec+0x3ae1>
   52f41:	movzx  eax,WORD PTR [rcx+0x14]
   52f45:	and    eax,0x24
   52f48:	test   eax,eax
   52f4a:	je     52f59 <sqlite3VdbeExec+0x3ab9>
   52f4c:	mov    rax,QWORD PTR [rcx]
   52f4f:	xorps  xmm0,xmm0
   52f52:	cvtsi2sd xmm0,rax
   52f57:	jmp    52f81 <sqlite3VdbeExec+0x3ae1>
   52f59:	movzx  eax,WORD PTR [rcx+0x14]
   52f5d:	and    eax,0x12
   52f60:	test   eax,eax
   52f62:	je     52f7e <sqlite3VdbeExec+0x3ade>
   52f64:	mov    QWORD PTR [rsp+0xb0],rdi
   52f6c:	mov    rdi,rcx
   52f6f:	call   52f74 <sqlite3VdbeExec+0x3ad4>
   52f74:	mov    rdi,QWORD PTR [rsp+0xb0]
   52f7c:	jmp    52f81 <sqlite3VdbeExec+0x3ae1>
   52f7e:	xorps  xmm0,xmm0
   52f81:	xorps  xmm1,xmm1
   52f84:	xor    eax,eax
   52f86:	ucomisd xmm0,xmm1
   52f8a:	setne  al
   52f8d:	setp   r11b
   52f91:	or     al,r11b
   52f94:	test   eax,eax
   52f96:	mov    eax,0x0
   52f9b:	sete   al
   52f9e:	test   eax,eax
   52fa0:	jne    52f0c <sqlite3VdbeExec+0x3a6c>
   52fa6:	jmp    52f23 <sqlite3VdbeExec+0x3a83>
   52fab:	mov    r15d,DWORD PTR [rsp+0x31c]
   52fb3:	mov    QWORD PTR [rsp+0xd0],r12
   52fbb:	movsxd rax,DWORD PTR [rbp+0x4]
   52fbf:	imul   rax,rax,0x38
   52fc3:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52fc8:	and    eax,0x1
   52fcb:	test   eax,eax
   52fcd:	je     52fd7 <sqlite3VdbeExec+0x3b37>
   52fcf:	mov    r12,r14
   52fd2:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   52fd7:	mov    DWORD PTR [rsp+0x31c],r15d
   52fdf:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   52fe4:	mov    r15d,DWORD PTR [rsp+0x31c]
   52fec:	mov    QWORD PTR [rsp+0xd0],r12
   52ff4:	cmp    DWORD PTR [rbp+0x4],0x0
   52ff8:	jl     53052 <sqlite3VdbeExec+0x3bb2>
   52ffa:	mov    rax,QWORD PTR [rdi+0x78]
   52ffe:	movsxd rcx,DWORD PTR [rbp+0x4]
   53002:	mov    rax,QWORD PTR [rax+rcx*8]
   53006:	mov    ecx,DWORD PTR [rbp+0xc]
   53009:	movzx  edx,WORD PTR [rax+0x42]
   5300d:	cmp    ecx,edx
   5300f:	jge    53040 <sqlite3VdbeExec+0x3ba0>
   53011:	movsxd rcx,DWORD PTR [rbp+0xc]
   53015:	mov    eax,DWORD PTR [rax+rcx*4+0x70]
   53019:	cmp    eax,0xc
   5301c:	jb     53033 <sqlite3VdbeExec+0x3b93>
   5301e:	and    eax,0x1
   53021:	test   eax,eax
   53023:	je     5302c <sqlite3VdbeExec+0x3b8c>
   53025:	mov    eax,0x4
   5302a:	jmp    53031 <sqlite3VdbeExec+0x3b91>
   5302c:	mov    eax,0x8
   53031:	jmp    5303e <sqlite3VdbeExec+0x3b9e>
   53033:	lea    rcx,[rip+0x0]        # 5303a <sqlite3VdbeExec+0x3b9a>
   5303a:	movzx  eax,BYTE PTR [rcx+rax*1]
   5303e:	jmp    53050 <sqlite3VdbeExec+0x3bb0>
   53040:	mov    eax,0x1
   53045:	mov    ecx,DWORD PTR [rbp+0x10]
   53048:	sub    ecx,0x1
   5304b:	shl    eax,cl
   5304d:	movzx  eax,ax
   53050:	jmp    5307a <sqlite3VdbeExec+0x3bda>
   53052:	mov    eax,0x1
   53057:	movsxd rcx,DWORD PTR [rbp+0xc]
   5305b:	imul   rcx,rcx,0x38
   5305f:	lea    rdx,[rip+0x0]        # 53066 <sqlite3VdbeExec+0x3bc6>
   53066:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   5306b:	and    ecx,0x3f
   5306e:	movzx  ecx,BYTE PTR [rdx+rcx*1]
   53072:	sub    ecx,0x1
   53075:	shl    eax,cl
   53077:	movzx  eax,ax
   5307a:	movzx  ecx,WORD PTR [rbp+0x2]
   5307e:	and    eax,ecx
   53080:	test   eax,eax
   53082:	je     5308c <sqlite3VdbeExec+0x3bec>
   53084:	mov    r12,r14
   53087:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5308c:	mov    DWORD PTR [rsp+0x31c],r15d
   53094:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   53099:	mov    r15d,DWORD PTR [rsp+0x31c]
   530a1:	mov    QWORD PTR [rsp+0xd0],r12
   530a9:	movsxd rax,DWORD PTR [rbp+0x4]
   530ad:	imul   rax,rax,0x38
   530b1:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   530b6:	and    eax,0x1
   530b9:	test   eax,eax
   530bb:	jne    530d1 <sqlite3VdbeExec+0x3c31>
   530bd:	movsxd rax,DWORD PTR [rbp+0xc]
   530c1:	imul   rax,rax,0x38
   530c5:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   530ca:	and    eax,0x1
   530cd:	test   eax,eax
   530cf:	je     5310d <sqlite3VdbeExec+0x3c6d>
   530d1:	movsxd rax,DWORD PTR [rbp+0x8]
   530d5:	imul   rax,rax,0x38
   530d9:	lea    rcx,[rbx+rax*1]
   530dd:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   530e2:	and    eax,0x9000
   530e7:	test   eax,eax
   530e9:	je     53105 <sqlite3VdbeExec+0x3c65>
   530eb:	mov    QWORD PTR [rsp+0xb0],rdi
   530f3:	mov    rdi,rcx
   530f6:	call   530fb <sqlite3VdbeExec+0x3c5b>
   530fb:	mov    rdi,QWORD PTR [rsp+0xb0]
   53103:	jmp    53153 <sqlite3VdbeExec+0x3cb3>
   53105:	mov    WORD PTR [rcx+0x14],0x1
   5310b:	jmp    53153 <sqlite3VdbeExec+0x3cb3>
   5310d:	movsxd rax,DWORD PTR [rbp+0x8]
   53111:	imul   rax,rax,0x38
   53115:	lea    rcx,[rbx+rax*1]
   53119:	xor    edx,edx
   5311b:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53120:	and    eax,0x9000
   53125:	test   eax,eax
   53127:	je     53146 <sqlite3VdbeExec+0x3ca6>
   53129:	mov    QWORD PTR [rsp+0xb0],rdi
   53131:	mov    rdi,rcx
   53134:	mov    rsi,rdx
   53137:	call   5313c <sqlite3VdbeExec+0x3c9c>
   5313c:	mov    rdi,QWORD PTR [rsp+0xb0]
   53144:	jmp    53153 <sqlite3VdbeExec+0x3cb3>
   53146:	mov    QWORD PTR [rcx],0x0
   5314d:	mov    WORD PTR [rcx+0x14],0x4
   53153:	mov    DWORD PTR [rsp+0x31c],r15d
   5315b:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   53160:	mov    r15d,DWORD PTR [rsp+0x31c]
   53168:	mov    QWORD PTR [rsp+0xd0],r12
   53170:	movsxd rax,DWORD PTR [rbp+0x4]
   53174:	imul   rax,rax,0x38
   53178:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5317d:	and    eax,0x1
   53180:	test   eax,eax
   53182:	jne    5318c <sqlite3VdbeExec+0x3cec>
   53184:	mov    r12,r14
   53187:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5318c:	mov    DWORD PTR [rsp+0x31c],r15d
   53194:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   53199:	mov    r15d,DWORD PTR [rsp+0x31c]
   531a1:	mov    QWORD PTR [rsp+0xd0],r12
   531a9:	mov    rax,QWORD PTR [rdi+0x78]
   531ad:	movsxd rcx,DWORD PTR [rbp+0x4]
   531b1:	mov    rax,QWORD PTR [rax+rcx*8]
   531b5:	test   rax,rax
   531b8:	je     53202 <sqlite3VdbeExec+0x3d62>
   531ba:	cmp    BYTE PTR [rax+0x2],0x0
   531be:	je     53202 <sqlite3VdbeExec+0x3d62>
   531c0:	movsxd rax,DWORD PTR [rbp+0xc]
   531c4:	imul   rax,rax,0x38
   531c8:	lea    rcx,[rbx+rax*1]
   531cc:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   531d1:	and    eax,0x9000
   531d6:	test   eax,eax
   531d8:	je     531f4 <sqlite3VdbeExec+0x3d54>
   531da:	mov    QWORD PTR [rsp+0xb0],rdi
   531e2:	mov    rdi,rcx
   531e5:	call   531ea <sqlite3VdbeExec+0x3d4a>
   531ea:	mov    rdi,QWORD PTR [rsp+0xb0]
   531f2:	jmp    531fa <sqlite3VdbeExec+0x3d5a>
   531f4:	mov    WORD PTR [rcx+0x14],0x1
   531fa:	mov    r12,r14
   531fd:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   53202:	mov    DWORD PTR [rsp+0x31c],r15d
   5320a:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5320f:	mov    r15d,DWORD PTR [rsp+0x31c]
   53217:	mov    QWORD PTR [rsp+0xd0],r12
   5321f:	mov    rax,QWORD PTR [rdi+0x78]
   53223:	movsxd rcx,DWORD PTR [rbp+0x4]
   53227:	mov    r12,QWORD PTR [rax+rcx*8]
   5322b:	mov    r13d,DWORD PTR [rbp+0x8]
   5322f:	mov    DWORD PTR [rsp+0x31c],r15d
   53237:	jmp    532d8 <sqlite3VdbeExec+0x3e38>
   5323c:	movsxd rax,DWORD PTR [rbp+0xc]
   53240:	imul   rax,rax,0x38
   53244:	lea    rcx,[rbx+rax*1]
   53248:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5324d:	and    eax,0x9000
   53252:	test   eax,eax
   53254:	je     53270 <sqlite3VdbeExec+0x3dd0>
   53256:	mov    QWORD PTR [rsp+0xb0],rdi
   5325e:	mov    rdi,rcx
   53261:	call   53266 <sqlite3VdbeExec+0x3dc6>
   53266:	mov    rdi,QWORD PTR [rsp+0xb0]
   5326e:	jmp    53276 <sqlite3VdbeExec+0x3dd6>
   53270:	mov    WORD PTR [rcx+0x14],0x1
   53276:	mov    DWORD PTR [rsp+0x31c],r15d
   5327e:	mov    DWORD PTR [rsp+0x32c],r12d
   53286:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5328b:	mov    QWORD PTR [rsp+0x100],rbx
   53293:	mov    rbx,QWORD PTR [r12+0x28]
   53298:	cmp    BYTE PTR [r12+0x3],0x0
   5329e:	je     53406 <sqlite3VdbeExec+0x3f66>
   532a4:	cmp    QWORD PTR [r12+0x8],0x0
   532aa:	je     53352 <sqlite3VdbeExec+0x3eb2>
   532b0:	mov    rax,QWORD PTR [r12+0x8]
   532b5:	lea    ecx,[r13+0x1]
   532b9:	mov    eax,DWORD PTR [rax+rcx*4]
   532bc:	test   eax,eax
   532be:	jbe    53352 <sqlite3VdbeExec+0x3eb2>
   532c4:	mov    r12,QWORD PTR [r12+0x20]
   532c9:	mov    r13d,eax
   532cc:	sub    r13d,0x1
   532d0:	mov    rbx,QWORD PTR [rsp+0x100]
   532d8:	mov    r15,QWORD PTR [r12+0x50]
   532dd:	mov    eax,DWORD PTR [r12+0x18]
   532e2:	cmp    eax,DWORD PTR [rdi+0x2c]
   532e5:	je     536a7 <sqlite3VdbeExec+0x4207>
   532eb:	cmp    BYTE PTR [r12+0x2],0x0
   532f1:	je     5328b <sqlite3VdbeExec+0x3deb>
   532f3:	cmp    BYTE PTR [r12],0x3
   532f8:	je     5330f <sqlite3VdbeExec+0x3e6f>
   532fa:	mov    r15d,DWORD PTR [rsp+0x31c]
   53302:	mov    r12d,DWORD PTR [rsp+0x32c]
   5330a:	jmp    5323c <sqlite3VdbeExec+0x3d9c>
   5330f:	cmp    DWORD PTR [r12+0x1c],0x0
   53315:	jg     5332c <sqlite3VdbeExec+0x3e8c>
   53317:	mov    r15d,DWORD PTR [rsp+0x31c]
   5331f:	mov    r12d,DWORD PTR [rsp+0x32c]
   53327:	jmp    5323c <sqlite3VdbeExec+0x3d9c>
   5332c:	movsxd rax,DWORD PTR [r12+0x1c]
   53331:	imul   rax,rax,0x38
   53335:	mov    ecx,DWORD PTR [rbx+rax*1+0x10]
   53339:	mov    DWORD PTR [r12+0x64],ecx
   5333e:	mov    DWORD PTR [r12+0x60],ecx
   53343:	mov    rax,QWORD PTR [rbx+rax*1+0x8]
   53348:	mov    QWORD PTR [r12+0x58],rax
   5334d:	jmp    53489 <sqlite3VdbeExec+0x3fe9>
   53352:	mov    QWORD PTR [rsp+0xc8],r14
   5335a:	mov    QWORD PTR [rsp+0xb0],rdi
   53362:	mov    rdi,r12
   53365:	call   5336a <sqlite3VdbeExec+0x3eca>
   5336a:	mov    r14d,eax
   5336d:	mov    rdi,QWORD PTR [rsp+0xb0]
   53375:	test   r14d,r14d
   53378:	je     533a2 <sqlite3VdbeExec+0x3f02>
   5337a:	mov    QWORD PTR [rsp+0xe8],rbp
   53382:	mov    rbp,r14
   53385:	mov    r14,QWORD PTR [rsp+0xc8]
   5338d:	mov    r13,QWORD PTR [rsp+0xd0]
   53395:	mov    rbx,QWORD PTR [rsp+0xf8]
   5339d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   533a2:	mov    DWORD PTR [rsp+0x32c],r14d
   533aa:	mov    r14,QWORD PTR [rsp+0xc8]
   533b2:	mov    QWORD PTR [rsp+0xb0],rdi
   533ba:	mov    rdi,rbx
   533bd:	call   533c2 <sqlite3VdbeExec+0x3f22>
   533c2:	mov    eax,DWORD PTR [rbx+0x40]
   533c5:	mov    DWORD PTR [r12+0x60],eax
   533ca:	movzx  eax,WORD PTR [rbx+0x44]
   533ce:	mov    rcx,QWORD PTR [rbx+0x88]
   533d5:	mov    rcx,QWORD PTR [rcx+0x58]
   533d9:	sub    rcx,QWORD PTR [rbx+0x38]
   533dd:	mov    rdi,QWORD PTR [rsp+0xb0]
   533e5:	cmp    eax,ecx
   533e7:	jle    53473 <sqlite3VdbeExec+0x3fd3>
   533ed:	xor    eax,eax
   533ef:	mov    rcx,QWORD PTR [rbx+0x88]
   533f6:	mov    rcx,QWORD PTR [rcx+0x58]
   533fa:	sub    rcx,QWORD PTR [rbx+0x38]
   533fe:	cmp    eax,ecx
   53400:	jle    53464 <sqlite3VdbeExec+0x3fc4>
   53402:	xor    eax,eax
   53404:	jmp    53473 <sqlite3VdbeExec+0x3fd3>
   53406:	xor    eax,eax
   53408:	movzx  ecx,BYTE PTR [rbx]
   5340b:	cmp    eax,ecx
   5340d:	je     533b2 <sqlite3VdbeExec+0x3f12>
   5340f:	mov    QWORD PTR [rsp+0xb0],rdi
   53417:	mov    rdi,r12
   5341a:	call   5341f <sqlite3VdbeExec+0x3f7f>
   5341f:	mov    ebx,eax
   53421:	mov    rdi,QWORD PTR [rsp+0xb0]
   53429:	test   ebx,ebx
   5342b:	je     5344d <sqlite3VdbeExec+0x3fad>
   5342d:	mov    QWORD PTR [rsp+0xe8],rbp
   53435:	mov    rbp,rbx
   53438:	mov    r13,QWORD PTR [rsp+0xd0]
   53440:	mov    rbx,QWORD PTR [rsp+0xf8]
   53448:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5344d:	mov    r15,QWORD PTR [rsp+0x100]
   53455:	mov    DWORD PTR [rsp+0x32c],ebx
   5345c:	mov    rbx,r15
   5345f:	jmp    532d8 <sqlite3VdbeExec+0x3e38>
   53464:	mov    rax,QWORD PTR [rbx+0x88]
   5346b:	mov    rax,QWORD PTR [rax+0x58]
   5346f:	sub    rax,QWORD PTR [rbx+0x38]
   53473:	mov    DWORD PTR [r12+0x64],eax
   53478:	mov    rax,QWORD PTR [rbx+0x38]
   5347c:	mov    QWORD PTR [r12+0x58],rax
   53481:	mov    rbx,QWORD PTR [rsp+0x100]
   53489:	mov    eax,DWORD PTR [rdi+0x2c]
   5348c:	mov    DWORD PTR [r12+0x18],eax
   53491:	mov    rax,QWORD PTR [r12+0x58]
   53496:	movzx  eax,BYTE PTR [rax]
   53499:	mov    DWORD PTR [r15],eax
   5349c:	cmp    eax,0x80
   534a1:	jae    534b1 <sqlite3VdbeExec+0x4011>
   534a3:	mov    DWORD PTR [r12+0x38],0x1
   534ac:	jmp    53573 <sqlite3VdbeExec+0x40d3>
   534b1:	mov    rax,QWORD PTR [r12+0x58]
   534b6:	movzx  ecx,BYTE PTR [rax+0x1]
   534ba:	and    ecx,0x80
   534c0:	test   ecx,ecx
   534c2:	jne    534e0 <sqlite3VdbeExec+0x4040>
   534c4:	movzx  ecx,BYTE PTR [rax]
   534c7:	and    ecx,0x7f
   534ca:	shl    ecx,0x7
   534cd:	movzx  eax,BYTE PTR [rax+0x1]
   534d1:	or     ecx,eax
   534d3:	mov    DWORD PTR [r15],ecx
   534d6:	mov    eax,0x2
   534db:	jmp    5356e <sqlite3VdbeExec+0x40ce>
   534e0:	movzx  ecx,BYTE PTR [rax+0x2]
   534e4:	and    ecx,0x80
   534ea:	test   ecx,ecx
   534ec:	jne    53513 <sqlite3VdbeExec+0x4073>
   534ee:	movzx  ecx,BYTE PTR [rax]
   534f1:	and    ecx,0x7f
   534f4:	shl    ecx,0xe
   534f7:	movzx  edx,BYTE PTR [rax+0x1]
   534fb:	and    edx,0x7f
   534fe:	shl    edx,0x7
   53501:	or     ecx,edx
   53503:	movzx  eax,BYTE PTR [rax+0x2]
   53507:	or     ecx,eax
   53509:	mov    DWORD PTR [r15],ecx
   5350c:	mov    eax,0x3
   53511:	jmp    5356e <sqlite3VdbeExec+0x40ce>
   53513:	mov    DWORD PTR [rsp+0x33c],r13d
   5351b:	mov    r13,rbx
   5351e:	lea    rbx,[rsp+0x110]
   53526:	mov    rcx,rbx
   53529:	mov    QWORD PTR [rsp+0xb0],rdi
   53531:	mov    rdi,rax
   53534:	mov    rsi,rcx
   53537:	call   5353c <sqlite3VdbeExec+0x409c>
   5353c:	movzx  eax,al
   5353f:	mov    ecx,0xffffffff
   53544:	and    rcx,QWORD PTR [rbx]
   53547:	mov    rdi,QWORD PTR [rsp+0xb0]
   5354f:	cmp    rcx,QWORD PTR [rbx]
   53552:	je     5355d <sqlite3VdbeExec+0x40bd>
   53554:	mov    DWORD PTR [r15],0xffffffff
   5355b:	jmp    53563 <sqlite3VdbeExec+0x40c3>
   5355d:	mov    rcx,QWORD PTR [rbx]
   53560:	mov    DWORD PTR [r15],ecx
   53563:	mov    rbx,r13
   53566:	mov    r13d,DWORD PTR [rsp+0x33c]
   5356e:	mov    DWORD PTR [r12+0x38],eax
   53573:	mov    WORD PTR [r12+0x42],0x0
   5357b:	mov    eax,DWORD PTR [r12+0x64]
   53580:	cmp    eax,DWORD PTR [r15]
   53583:	jae    535dd <sqlite3VdbeExec+0x413d>
   53585:	mov    QWORD PTR [r12+0x58],0x0
   5358e:	mov    DWORD PTR [r12+0x64],0x0
   53597:	cmp    DWORD PTR [r15],0x18003
   5359e:	ja     535aa <sqlite3VdbeExec+0x410a>
   535a0:	mov    eax,DWORD PTR [r15]
   535a3:	cmp    eax,DWORD PTR [r12+0x60]
   535a8:	jbe    535ef <sqlite3VdbeExec+0x414f>
   535aa:	mov    r13,QWORD PTR [rsp+0xf0]
   535b2:	cmp    DWORD PTR [r13+0xc],0x0
   535b7:	jle    53f90 <sqlite3VdbeExec+0x4af0>
   535bd:	mov    eax,DWORD PTR [r13+0xc]
   535c1:	sub    eax,0x1
   535c4:	movsxd rax,eax
   535c7:	imul   rax,rax,0x18
   535cb:	lea    rbp,[r13+rax*1+0x0]
   535d0:	mov    QWORD PTR [rsp+0xf0],r13
   535d8:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   535dd:	mov    DWORD PTR [rsp+0x33c],r13d
   535e5:	mov    r13,QWORD PTR [r12+0x58]
   535ea:	jmp    5375b <sqlite3VdbeExec+0x42bb>
   535ef:	mov    DWORD PTR [rsp+0x33c],r13d
   535f7:	mov    r13d,DWORD PTR [rsp+0x33c]
   535ff:	movzx  eax,WORD PTR [r12+0x42]
   53605:	cmp    eax,r13d
   53608:	ja     53b98 <sqlite3VdbeExec+0x46f8>
   5360e:	mov    eax,DWORD PTR [r12+0x38]
   53613:	cmp    eax,DWORD PTR [r15]
   53616:	jae    53aa2 <sqlite3VdbeExec+0x4602>
   5361c:	cmp    QWORD PTR [r12+0x58],0x0
   53622:	jne    5373b <sqlite3VdbeExec+0x429b>
   53628:	mov    QWORD PTR [rsp+0xc8],r14
   53630:	lea    r14,[rsp+0x1e0]
   53638:	mov    rax,r14
   5363b:	xor    ecx,ecx
   5363d:	mov    edx,0x38
   53642:	mov    QWORD PTR [rsp+0xb0],rdi
   5364a:	mov    rdi,rax
   5364d:	mov    rsi,rcx
   53650:	call   53655 <sqlite3VdbeExec+0x41b5>
   53655:	mov    rax,QWORD PTR [r12+0x28]
   5365a:	mov    ecx,DWORD PTR [r15]
   5365d:	mov    rdx,r14
   53660:	mov    rdi,rax
   53663:	mov    rsi,rcx
   53666:	call   5366b <sqlite3VdbeExec+0x41cb>
   5366b:	mov    r14d,eax
   5366e:	mov    rdi,QWORD PTR [rsp+0xb0]
   53676:	test   r14d,r14d
   53679:	je     53706 <sqlite3VdbeExec+0x4266>
   5367f:	mov    QWORD PTR [rsp+0xe8],rbp
   53687:	mov    rbp,r14
   5368a:	mov    r14,QWORD PTR [rsp+0xc8]
   53692:	mov    r13,QWORD PTR [rsp+0xd0]
   5369a:	mov    rbx,QWORD PTR [rsp+0xf8]
   536a2:	jmp    4f712 <sqlite3VdbeExec+0x272>
   536a7:	mov    rax,QWORD PTR [r12+0x28]
   536ac:	xor    ecx,ecx
   536ae:	movzx  eax,BYTE PTR [rax]
   536b1:	cmp    ecx,eax
   536b3:	je     535ff <sqlite3VdbeExec+0x415f>
   536b9:	mov    QWORD PTR [rsp+0xb0],rdi
   536c1:	mov    rdi,r12
   536c4:	call   536c9 <sqlite3VdbeExec+0x4229>
   536c9:	mov    r15d,eax
   536cc:	mov    rdi,QWORD PTR [rsp+0xb0]
   536d4:	test   r15d,r15d
   536d7:	je     536f9 <sqlite3VdbeExec+0x4259>
   536d9:	mov    QWORD PTR [rsp+0xe8],rbp
   536e1:	mov    rbp,r15
   536e4:	mov    r13,QWORD PTR [rsp+0xd0]
   536ec:	mov    rbx,QWORD PTR [rsp+0xf8]
   536f4:	jmp    4f712 <sqlite3VdbeExec+0x272>
   536f9:	mov    DWORD PTR [rsp+0x32c],r15d
   53701:	jmp    532d8 <sqlite3VdbeExec+0x3e38>
   53706:	mov    DWORD PTR [rsp+0x338],r14d
   5370e:	mov    r14,QWORD PTR [rsp+0x1e8]
   53716:	mov    DWORD PTR [rsp+0x33c],r13d
   5371e:	mov    r11d,DWORD PTR [rsp+0x338]
   53726:	mov    DWORD PTR [rsp+0x32c],r11d
   5372e:	mov    r13,r14
   53731:	mov    r14,QWORD PTR [rsp+0xc8]
   53739:	jmp    5375b <sqlite3VdbeExec+0x42bb>
   5373b:	mov    QWORD PTR [rsp+0xc8],r14
   53743:	mov    r14,QWORD PTR [r12+0x58]
   53748:	mov    DWORD PTR [rsp+0x33c],r13d
   53750:	mov    r13,r14
   53753:	mov    r14,QWORD PTR [rsp+0xc8]
   5375b:	movzx  eax,WORD PTR [r12+0x42]
   53761:	mov    QWORD PTR [rsp+0x100],rbx
   53769:	mov    ebx,eax
   5376b:	mov    rax,rbx
   5376e:	mov    eax,DWORD PTR [r15+rax*4]
   53772:	mov    DWORD PTR [rsp+0x338],ebx
   53779:	mov    rbx,rax
   5377c:	mov    eax,DWORD PTR [r12+0x38]
   53781:	mov    QWORD PTR [rsp+0x118],rbx
   53789:	lea    rbx,[r13+rax*1+0x0]
   5378e:	mov    eax,DWORD PTR [r15]
   53791:	mov    QWORD PTR [rsp+0x120],rbx
   53799:	lea    rbx,[r13+rax*1+0x0]
   5379e:	mov    QWORD PTR [rsp+0x108],r15
   537a6:	mov    QWORD PTR [rsp+0x110],r13
   537ae:	mov    QWORD PTR [rsp+0x128],rbx
   537b6:	mov    r13d,DWORD PTR [rsp+0x338]
   537be:	mov    rbx,QWORD PTR [rsp+0x120]
   537c6:	mov    r15,QWORD PTR [rsp+0x118]
   537ce:	movsxd rax,r13d
   537d1:	movzx  ecx,BYTE PTR [rbx]
   537d4:	mov    DWORD PTR [rsp+0x340],ecx
   537db:	mov    DWORD PTR [r12+rax*4+0x70],ecx
   537e0:	cmp    ecx,0x80
   537e6:	jae    53809 <sqlite3VdbeExec+0x4369>
   537e8:	add    rbx,0x1
   537ec:	mov    eax,DWORD PTR [rsp+0x340]
   537f3:	movzx  eax,al
   537f6:	lea    rcx,[rip+0x0]        # 537fd <sqlite3VdbeExec+0x435d>
   537fd:	movzx  eax,BYTE PTR [rcx+rax*1]
   53801:	add    r15,rax
   53804:	jmp    53907 <sqlite3VdbeExec+0x4467>
   53809:	movzx  eax,BYTE PTR [rbx+0x1]
   5380d:	and    eax,0x80
   53812:	test   eax,eax
   53814:	jne    53836 <sqlite3VdbeExec+0x4396>
   53816:	movzx  eax,BYTE PTR [rbx]
   53819:	and    eax,0x7f
   5381c:	shl    eax,0x7
   5381f:	movzx  ecx,BYTE PTR [rbx+0x1]
   53823:	or     eax,ecx
   53825:	mov    DWORD PTR [rsp+0x340],eax
   5382c:	mov    eax,0x2
   53831:	jmp    538d2 <sqlite3VdbeExec+0x4432>
   53836:	movzx  eax,BYTE PTR [rbx+0x2]
   5383a:	and    eax,0x80
   5383f:	test   eax,eax
   53841:	jne    5386c <sqlite3VdbeExec+0x43cc>
   53843:	movzx  eax,BYTE PTR [rbx]
   53846:	and    eax,0x7f
   53849:	shl    eax,0xe
   5384c:	movzx  ecx,BYTE PTR [rbx+0x1]
   53850:	and    ecx,0x7f
   53853:	shl    ecx,0x7
   53856:	or     eax,ecx
   53858:	movzx  ecx,BYTE PTR [rbx+0x2]
   5385c:	or     eax,ecx
   5385e:	mov    DWORD PTR [rsp+0x340],eax
   53865:	mov    eax,0x3
   5386a:	jmp    538d2 <sqlite3VdbeExec+0x4432>
   5386c:	mov    QWORD PTR [rsp+0x118],r15
   53874:	mov    r15,rbp
   53877:	lea    rbp,[rsp+0x120]
   5387f:	mov    rax,rbp
   53882:	mov    QWORD PTR [rsp+0xb0],rdi
   5388a:	mov    rdi,rbx
   5388d:	mov    rsi,rax
   53890:	call   53895 <sqlite3VdbeExec+0x43f5>
   53895:	movzx  eax,al
   53898:	mov    ecx,0xffffffff
   5389d:	and    rcx,QWORD PTR [rbp+0x0]
   538a1:	mov    rdi,QWORD PTR [rsp+0xb0]
   538a9:	cmp    rcx,QWORD PTR [rbp+0x0]
   538ad:	je     538bc <sqlite3VdbeExec+0x441c>
   538af:	mov    DWORD PTR [rsp+0x340],0xffffffff
   538ba:	jmp    538c7 <sqlite3VdbeExec+0x4427>
   538bc:	mov    rcx,QWORD PTR [rbp+0x0]
   538c0:	mov    DWORD PTR [rsp+0x340],ecx
   538c7:	mov    rbp,r15
   538ca:	mov    r15,QWORD PTR [rsp+0x118]
   538d2:	add    rbx,rax
   538d5:	movsxd rax,r13d
   538d8:	mov    ecx,DWORD PTR [rsp+0x340]
   538df:	mov    DWORD PTR [r12+rax*4+0x70],ecx
   538e4:	mov    eax,DWORD PTR [rsp+0x340]
   538eb:	cmp    eax,0x80
   538f0:	jb     538f9 <sqlite3VdbeExec+0x4459>
   538f2:	sub    eax,0xc
   538f5:	shr    eax,1
   538f7:	jmp    53904 <sqlite3VdbeExec+0x4464>
   538f9:	lea    rcx,[rip+0x0]        # 53900 <sqlite3VdbeExec+0x4460>
   53900:	movzx  eax,BYTE PTR [rcx+rax*1]
   53904:	add    r15,rax
   53907:	add    r13d,0x1
   5390b:	movsxd rax,r13d
   5390e:	mov    ecx,0xffffffff
   53913:	and    rcx,r15
   53916:	mov    QWORD PTR [rsp+0xc8],r14
   5391e:	mov    r14,QWORD PTR [rsp+0x108]
   53926:	mov    DWORD PTR [r14+rax*4],ecx
   5392a:	mov    QWORD PTR [rsp+0xe8],rbp
   53932:	mov    ebp,DWORD PTR [rsp+0x33c]
   53939:	cmp    r13d,ebp
   5393c:	jbe    53948 <sqlite3VdbeExec+0x44a8>
   5393e:	mov    rbp,QWORD PTR [rsp+0x128]
   53946:	jmp    53972 <sqlite3VdbeExec+0x44d2>
   53948:	mov    rbp,QWORD PTR [rsp+0x128]
   53950:	cmp    rbx,rbp
   53953:	jae    53972 <sqlite3VdbeExec+0x44d2>
   53955:	mov    QWORD PTR [rsp+0x108],r14
   5395d:	mov    r14,QWORD PTR [rsp+0xc8]
   53965:	mov    rbp,QWORD PTR [rsp+0xe8]
   5396d:	jmp    537ce <sqlite3VdbeExec+0x432e>
   53972:	cmp    rbx,rbp
   53975:	jb     53986 <sqlite3VdbeExec+0x44e6>
   53977:	cmp    rbx,rbp
   5397a:	ja     539a0 <sqlite3VdbeExec+0x4500>
   5397c:	mov    eax,DWORD PTR [r12+0x60]
   53981:	cmp    r15,rax
   53984:	jne    539a0 <sqlite3VdbeExec+0x4500>
   53986:	mov    eax,DWORD PTR [r12+0x60]
   5398b:	cmp    r15,rax
   5398e:	ja     539a0 <sqlite3VdbeExec+0x4500>
   53990:	mov    rbp,rbx
   53993:	mov    rbx,r13
   53996:	mov    r13,QWORD PTR [rsp+0x110]
   5399e:	jmp    539b4 <sqlite3VdbeExec+0x4514>
   539a0:	cmp    DWORD PTR [r14],0x0
   539a4:	jne    53a3a <sqlite3VdbeExec+0x459a>
   539aa:	xor    ebx,ebx
   539ac:	mov    r13,QWORD PTR [rsp+0x110]
   539b4:	mov    WORD PTR [r12+0x42],bx
   539ba:	mov    rax,rbp
   539bd:	sub    rax,r13
   539c0:	mov    DWORD PTR [r12+0x38],eax
   539c5:	cmp    QWORD PTR [r12+0x58],0x0
   539cb:	je     539d7 <sqlite3VdbeExec+0x4537>
   539cd:	lea    rbx,[rsp+0x1e0]
   539d5:	jmp    53a12 <sqlite3VdbeExec+0x4572>
   539d7:	lea    rbx,[rsp+0x1e0]
   539df:	mov    rax,rbx
   539e2:	movzx  ecx,WORD PTR [rsp+0x1f4]
   539ea:	and    ecx,0x9000
   539f0:	test   ecx,ecx
   539f2:	jne    539fa <sqlite3VdbeExec+0x455a>
   539f4:	cmp    DWORD PTR [rax+0x20],0x0
   539f8:	je     53a12 <sqlite3VdbeExec+0x4572>
   539fa:	mov    QWORD PTR [rsp+0xb0],rdi
   53a02:	mov    rdi,rax
   53a05:	call   53a0a <sqlite3VdbeExec+0x456a>
   53a0a:	mov    rdi,QWORD PTR [rsp+0xb0]
   53a12:	mov    r13d,DWORD PTR [rsp+0x33c]
   53a1a:	mov    r15,r14
   53a1d:	mov    r14,QWORD PTR [rsp+0xc8]
   53a25:	mov    rbp,QWORD PTR [rsp+0xe8]
   53a2d:	mov    rbx,QWORD PTR [rsp+0x100]
   53a35:	jmp    53abd <sqlite3VdbeExec+0x461d>
   53a3a:	lea    rbx,[rsp+0x1e0]
   53a42:	cmp    QWORD PTR [r12+0x58],0x0
   53a48:	jne    53a7d <sqlite3VdbeExec+0x45dd>
   53a4a:	mov    rax,rbx
   53a4d:	movzx  ecx,WORD PTR [rsp+0x1f4]
   53a55:	and    ecx,0x9000
   53a5b:	test   ecx,ecx
   53a5d:	jne    53a65 <sqlite3VdbeExec+0x45c5>
   53a5f:	cmp    DWORD PTR [rax+0x20],0x0
   53a63:	je     53a7d <sqlite3VdbeExec+0x45dd>
   53a65:	mov    QWORD PTR [rsp+0xb0],rdi
   53a6d:	mov    rdi,rax
   53a70:	call   53a75 <sqlite3VdbeExec+0x45d5>
   53a75:	mov    rdi,QWORD PTR [rsp+0xb0]
   53a7d:	mov    r14,QWORD PTR [rsp+0xc8]
   53a85:	mov    r13,QWORD PTR [rsp+0xf0]
   53a8d:	mov    rbp,QWORD PTR [rsp+0xe8]
   53a95:	mov    rbx,QWORD PTR [rsp+0x100]
   53a9d:	jmp    535b2 <sqlite3VdbeExec+0x4112>
   53aa2:	mov    QWORD PTR [rsp+0xc8],r14
   53aaa:	mov    DWORD PTR [rsp+0x340],0x0
   53ab5:	mov    r14,QWORD PTR [rsp+0xc8]
   53abd:	movzx  eax,WORD PTR [r12+0x42]
   53ac3:	cmp    eax,r13d
   53ac6:	ja     53b96 <sqlite3VdbeExec+0x46f6>
   53acc:	movsxd rax,DWORD PTR [rbp+0xc]
   53ad0:	imul   rax,rax,0x38
   53ad4:	add    rax,rbx
   53ad7:	cmp    BYTE PTR [rbp+0x1],0xf5
   53adb:	jne    53b53 <sqlite3VdbeExec+0x46b3>
   53add:	mov    rcx,QWORD PTR [rbp+0x10]
   53ae1:	mov    edx,0x2000
   53ae6:	movzx  esi,WORD PTR [rax+0x14]
   53aea:	and    esi,0x9000
   53af0:	test   esi,esi
   53af2:	je     53b11 <sqlite3VdbeExec+0x4671>
   53af4:	mov    QWORD PTR [rsp+0xb0],rdi
   53afc:	mov    rdi,rax
   53aff:	mov    rsi,rcx
   53b02:	call   53b07 <sqlite3VdbeExec+0x4667>
   53b07:	mov    rdi,QWORD PTR [rsp+0xb0]
   53b0f:	jmp    53b81 <sqlite3VdbeExec+0x46e1>
   53b11:	mov    rdx,QWORD PTR [rcx]
   53b14:	mov    QWORD PTR [rax],rdx
   53b17:	mov    rdx,QWORD PTR [rcx+0x8]
   53b1b:	mov    QWORD PTR [rax+0x8],rdx
   53b1f:	mov    rdx,QWORD PTR [rcx+0x10]
   53b23:	mov    QWORD PTR [rax+0x10],rdx
   53b27:	movzx  ecx,WORD PTR [rcx+0x14]
   53b2b:	and    ecx,0x2000
   53b31:	test   ecx,ecx
   53b33:	jne    53b81 <sqlite3VdbeExec+0x46e1>
   53b35:	movzx  ecx,WORD PTR [rax+0x14]
   53b39:	and    ecx,0xffff8fff
   53b3f:	mov    WORD PTR [rax+0x14],cx
   53b43:	movzx  ecx,WORD PTR [rax+0x14]
   53b47:	or     ecx,0x2000
   53b4d:	mov    WORD PTR [rax+0x14],cx
   53b51:	jmp    53b81 <sqlite3VdbeExec+0x46e1>
   53b53:	movzx  ecx,WORD PTR [rax+0x14]
   53b57:	and    ecx,0x9000
   53b5d:	test   ecx,ecx
   53b5f:	je     53b7b <sqlite3VdbeExec+0x46db>
   53b61:	mov    QWORD PTR [rsp+0xb0],rdi
   53b69:	mov    rdi,rax
   53b6c:	call   53b71 <sqlite3VdbeExec+0x46d1>
   53b71:	mov    rdi,QWORD PTR [rsp+0xb0]
   53b79:	jmp    53b81 <sqlite3VdbeExec+0x46e1>
   53b7b:	mov    WORD PTR [rax+0x14],0x1
   53b81:	mov    r15d,DWORD PTR [rsp+0x31c]
   53b89:	mov    r12d,DWORD PTR [rsp+0x32c]
   53b91:	jmp    53276 <sqlite3VdbeExec+0x3dd6>
   53b96:	jmp    53bb7 <sqlite3VdbeExec+0x4717>
   53b98:	mov    QWORD PTR [rsp+0xc8],r14
   53ba0:	mov    eax,r13d
   53ba3:	mov    eax,DWORD PTR [r12+rax*4+0x70]
   53ba8:	mov    DWORD PTR [rsp+0x340],eax
   53baf:	mov    r14,QWORD PTR [rsp+0xc8]
   53bb7:	movsxd rax,DWORD PTR [rbp+0xc]
   53bbb:	imul   rax,rax,0x38
   53bbf:	mov    QWORD PTR [rsp+0xc8],r14
   53bc7:	lea    r14,[rbx+rax*1]
   53bcb:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53bd0:	and    eax,0x9000
   53bd5:	test   eax,eax
   53bd7:	je     53c08 <sqlite3VdbeExec+0x4768>
   53bd9:	movzx  eax,WORD PTR [r14+0x14]
   53bde:	and    eax,0x9000
   53be3:	test   eax,eax
   53be5:	je     53c01 <sqlite3VdbeExec+0x4761>
   53be7:	mov    QWORD PTR [rsp+0xb0],rdi
   53bef:	mov    rdi,r14
   53bf2:	call   53bf7 <sqlite3VdbeExec+0x4757>
   53bf7:	mov    rdi,QWORD PTR [rsp+0xb0]
   53bff:	jmp    53c08 <sqlite3VdbeExec+0x4768>
   53c01:	mov    WORD PTR [r14+0x14],0x1
   53c08:	mov    eax,DWORD PTR [r12+0x64]
   53c0d:	lea    ecx,[r13+0x1]
   53c11:	cmp    eax,DWORD PTR [r15+rcx*4]
   53c15:	jb     53ddd <sqlite3VdbeExec+0x493d>
   53c1b:	mov    rax,QWORD PTR [r12+0x58]
   53c20:	mov    ecx,r13d
   53c23:	mov    ecx,DWORD PTR [r15+rcx*4]
   53c27:	lea    r12,[rax+rcx*1]
   53c2b:	cmp    DWORD PTR [rsp+0x340],0xc
   53c33:	jae    53c6f <sqlite3VdbeExec+0x47cf>
   53c35:	mov    eax,DWORD PTR [rsp+0x340]
   53c3c:	mov    QWORD PTR [rsp+0xb0],rdi
   53c44:	mov    rdi,r12
   53c47:	mov    rsi,rax
   53c4a:	mov    rdx,r14
   53c4d:	call   53c52 <sqlite3VdbeExec+0x47b2>
   53c52:	mov    rdi,QWORD PTR [rsp+0xb0]
   53c5a:	mov    QWORD PTR [rsp+0xe8],rbp
   53c62:	mov    rbp,QWORD PTR [rsp+0xc8]
   53c6a:	jmp    53dbd <sqlite3VdbeExec+0x491d>
   53c6f:	mov    r15d,DWORD PTR [rsp+0x31c]
   53c77:	mov    eax,DWORD PTR [rsp+0x340]
   53c7e:	sub    eax,0xc
   53c81:	mov    r13d,eax
   53c84:	shr    r13d,1
   53c87:	mov    DWORD PTR [r14+0x10],r13d
   53c8b:	mov    BYTE PTR [r14+0x16],r15b
   53c8f:	lea    eax,[r13+0x2]
   53c93:	cmp    eax,DWORD PTR [r14+0x20]
   53c97:	jle    53d46 <sqlite3VdbeExec+0x48a6>
   53c9d:	mov    QWORD PTR [rsp+0xe8],rbp
   53ca5:	mov    rbp,QWORD PTR [rsp+0xc8]
   53cad:	cmp    r13d,DWORD PTR [rbp+0x88]
   53cb4:	jle    53cf7 <sqlite3VdbeExec+0x4857>
   53cb6:	lea    rax,[rip+0x0]        # 53cbd <sqlite3VdbeExec+0x481d>
   53cbd:	mov    QWORD PTR [rsp+0xb0],rdi
   53cc5:	mov    rsi,rax
   53cc8:	xor    eax,eax
   53cca:	call   53ccf <sqlite3VdbeExec+0x482f>
   53ccf:	mov    ebx,0x12
   53cd4:	mov    rdi,QWORD PTR [rsp+0xb0]
   53cdc:	mov    r14,rbp
   53cdf:	mov    rbp,rbx
   53ce2:	mov    r13,QWORD PTR [rsp+0xd0]
   53cea:	mov    rbx,QWORD PTR [rsp+0xf8]
   53cf2:	jmp    4f712 <sqlite3VdbeExec+0x272>
   53cf7:	mov    WORD PTR [r14+0x14],0x1
   53cfe:	lea    eax,[r13+0x2]
   53d02:	xor    ecx,ecx
   53d04:	mov    QWORD PTR [rsp+0xb0],rdi
   53d0c:	mov    rdi,r14
   53d0f:	mov    rsi,rax
   53d12:	mov    rdx,rcx
   53d15:	call   53d1a <sqlite3VdbeExec+0x487a>
   53d1a:	mov    rdi,QWORD PTR [rsp+0xb0]
   53d22:	test   eax,eax
   53d24:	je     53d5e <sqlite3VdbeExec+0x48be>
   53d26:	mov    r14,rbp
   53d29:	mov    r13,QWORD PTR [rsp+0xf0]
   53d31:	mov    rbx,QWORD PTR [rsp+0xe8]
   53d39:	mov    rbp,QWORD PTR [rsp+0xf8]
   53d41:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   53d46:	mov    QWORD PTR [rsp+0xe8],rbp
   53d4e:	mov    rbp,QWORD PTR [rsp+0xc8]
   53d56:	mov    rax,QWORD PTR [r14+0x28]
   53d5a:	mov    QWORD PTR [r14+0x8],rax
   53d5e:	mov    rax,QWORD PTR [r14+0x8]
   53d62:	mov    DWORD PTR [rsp+0x31c],r15d
   53d6a:	mov    r15,r13
   53d6d:	mov    QWORD PTR [rsp+0xb0],rdi
   53d75:	mov    rdi,rax
   53d78:	mov    rsi,r12
   53d7b:	mov    rdx,r15
   53d7e:	call   53d83 <sqlite3VdbeExec+0x48e3>
   53d83:	mov    rax,QWORD PTR [r14+0x8]
   53d87:	mov    BYTE PTR [rax+r15*1],0x0
   53d8c:	mov    rax,QWORD PTR [r14+0x8]
   53d90:	lea    ecx,[r13+0x1]
   53d94:	movsxd rcx,ecx
   53d97:	mov    BYTE PTR [rax+rcx*1],0x0
   53d9b:	lea    rax,[rip+0x0]        # 53da2 <sqlite3VdbeExec+0x4902>
   53da2:	mov    ecx,DWORD PTR [rsp+0x340]
   53da9:	and    ecx,0x1
   53dac:	movzx  eax,WORD PTR [rax+rcx*2]
   53db0:	mov    WORD PTR [r14+0x14],ax
   53db5:	mov    rdi,QWORD PTR [rsp+0xb0]
   53dbd:	mov    r14,rbp
   53dc0:	mov    r15d,DWORD PTR [rsp+0x31c]
   53dc8:	mov    rbp,QWORD PTR [rsp+0xe8]
   53dd0:	mov    r12d,DWORD PTR [rsp+0x32c]
   53dd8:	jmp    53276 <sqlite3VdbeExec+0x3dd6>
   53ddd:	mov    QWORD PTR [rsp+0x100],rbx
   53de5:	mov    ebx,DWORD PTR [rsp+0x31c]
   53dec:	mov    BYTE PTR [r14+0x16],bl
   53df0:	movzx  eax,WORD PTR [rbp+0x2]
   53df4:	and    eax,0xc0
   53df9:	mov    ecx,eax
   53dfb:	test   ecx,ecx
   53dfd:	je     53e28 <sqlite3VdbeExec+0x4988>
   53dff:	mov    ecx,eax
   53e01:	cmp    ecx,0x80
   53e07:	je     53e50 <sqlite3VdbeExec+0x49b0>
   53e09:	cmp    DWORD PTR [rsp+0x340],0xc
   53e11:	jb     53e28 <sqlite3VdbeExec+0x4988>
   53e13:	mov    ecx,DWORD PTR [rsp+0x340]
   53e1a:	and    ecx,0x1
   53e1d:	test   ecx,ecx
   53e1f:	je     53e50 <sqlite3VdbeExec+0x49b0>
   53e21:	cmp    eax,0xc0
   53e26:	je     53e50 <sqlite3VdbeExec+0x49b0>
   53e28:	mov    eax,DWORD PTR [rsp+0x340]
   53e2f:	cmp    eax,0x80
   53e34:	jb     53e9c <sqlite3VdbeExec+0x49fc>
   53e36:	sub    eax,0xc
   53e39:	shr    eax,1
   53e3b:	test   eax,eax
   53e3d:	je     53e50 <sqlite3VdbeExec+0x49b0>
   53e3f:	mov    DWORD PTR [rsp+0x31c],ebx
   53e46:	mov    rbx,QWORD PTR [rsp+0x100]
   53e4e:	jmp    53ec9 <sqlite3VdbeExec+0x4a29>
   53e50:	lea    rax,[rip+0x0]        # 53e57 <sqlite3VdbeExec+0x49b7>
   53e57:	mov    ecx,DWORD PTR [rsp+0x340]
   53e5e:	mov    QWORD PTR [rsp+0xb0],rdi
   53e66:	mov    rdi,rax
   53e69:	mov    rsi,rcx
   53e6c:	mov    rdx,r14
   53e6f:	call   53e74 <sqlite3VdbeExec+0x49d4>
   53e74:	mov    rdi,QWORD PTR [rsp+0xb0]
   53e7c:	mov    r14,QWORD PTR [rsp+0xc8]
   53e84:	mov    r15,rbx
   53e87:	mov    rbx,QWORD PTR [rsp+0x100]
   53e8f:	mov    r12d,DWORD PTR [rsp+0x32c]
   53e97:	jmp    53276 <sqlite3VdbeExec+0x3dd6>
   53e9c:	mov    DWORD PTR [rsp+0x31c],ebx
   53ea3:	mov    rbx,QWORD PTR [rsp+0x100]
   53eab:	lea    rcx,[rip+0x0]        # 53eb2 <sqlite3VdbeExec+0x4a12>
   53eb2:	cmp    BYTE PTR [rcx+rax*1],0x0
   53eb6:	jne    53ec9 <sqlite3VdbeExec+0x4a29>
   53eb8:	mov    QWORD PTR [rsp+0x100],rbx
   53ec0:	mov    ebx,DWORD PTR [rsp+0x31c]
   53ec7:	jmp    53e50 <sqlite3VdbeExec+0x49b0>
   53ec9:	mov    eax,DWORD PTR [rsp+0x340]
   53ed0:	mov    ecx,r13d
   53ed3:	mov    ecx,DWORD PTR [r15+rcx*4]
   53ed7:	mov    edx,DWORD PTR [rdi+0x2c]
   53eda:	mov    r15d,DWORD PTR [rsp+0x334]
   53ee2:	mov    QWORD PTR [rsp],r14
   53ee6:	mov    QWORD PTR [rsp+0xb0],rdi
   53eee:	mov    rdi,r12
   53ef1:	mov    rsi,r13
   53ef4:	mov    r8,rdx
   53ef7:	mov    rdx,rax
   53efa:	mov    r9,r15
   53efd:	call   53f02 <sqlite3VdbeExec+0x4a62>
   53f02:	mov    r12d,eax
   53f05:	mov    rdi,QWORD PTR [rsp+0xb0]
   53f0d:	test   r12d,r12d
   53f10:	jne    53f27 <sqlite3VdbeExec+0x4a87>
   53f12:	mov    r14,QWORD PTR [rsp+0xc8]
   53f1a:	mov    r15d,DWORD PTR [rsp+0x31c]
   53f22:	jmp    53276 <sqlite3VdbeExec+0x3dd6>
   53f27:	cmp    r12d,0x7
   53f2b:	jne    53f4d <sqlite3VdbeExec+0x4aad>
   53f2d:	mov    r14,QWORD PTR [rsp+0xc8]
   53f35:	mov    r13,QWORD PTR [rsp+0xf0]
   53f3d:	mov    rbx,rbp
   53f40:	mov    rbp,QWORD PTR [rsp+0xf8]
   53f48:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   53f4d:	cmp    r12d,0x12
   53f51:	jne    53f68 <sqlite3VdbeExec+0x4ac8>
   53f53:	mov    QWORD PTR [rsp+0xe8],rbp
   53f5b:	mov    rbp,QWORD PTR [rsp+0xc8]
   53f63:	jmp    53cb6 <sqlite3VdbeExec+0x4816>
   53f68:	mov    r14,QWORD PTR [rsp+0xc8]
   53f70:	mov    QWORD PTR [rsp+0xe8],rbp
   53f78:	mov    rbp,r12
   53f7b:	mov    r13,QWORD PTR [rsp+0xd0]
   53f83:	mov    rbx,QWORD PTR [rsp+0xf8]
   53f8b:	jmp    4f712 <sqlite3VdbeExec+0x272>
   53f90:	mov    QWORD PTR [rsp+0xf0],r13
   53f98:	mov    eax,0x1859c
   53f9d:	mov    ecx,0xb
   53fa2:	lea    rdx,[rip+0x0]        # 53fa9 <sqlite3VdbeExec+0x4b09>
   53fa9:	mov    QWORD PTR [rsp+0xb0],rdi
   53fb1:	mov    rdi,rcx
   53fb4:	mov    rsi,rax
   53fb7:	call   53fbc <sqlite3VdbeExec+0x4b1c>
   53fbc:	mov    ebx,eax
   53fbe:	mov    rdi,QWORD PTR [rsp+0xb0]
   53fc6:	mov    QWORD PTR [rsp+0xe8],rbp
   53fce:	mov    rbp,rbx
   53fd1:	mov    r13,QWORD PTR [rsp+0xd0]
   53fd9:	mov    rbx,QWORD PTR [rsp+0xf8]
   53fe1:	jmp    4f712 <sqlite3VdbeExec+0x272>
   53fe6:	mov    r15d,DWORD PTR [rsp+0x31c]
   53fee:	mov    r13,QWORD PTR [rsp+0xf0]
   53ff6:	mov    QWORD PTR [rsp+0xd0],r12
   53ffe:	mov    r12d,DWORD PTR [rsp+0x334]
   54006:	mov    DWORD PTR [rsp+0x334],r12d
   5400e:	mov    r12,QWORD PTR [rbp+0x10]
   54012:	mov    QWORD PTR [rsp+0xf0],r13
   5401a:	mov    r13,QWORD PTR [r12+0x8]
   5401f:	movsxd rax,DWORD PTR [rbp+0x4]
   54023:	imul   rax,rax,0x38
   54027:	mov    QWORD PTR [rsp+0x110],r13
   5402f:	lea    r13,[rbx+rax*1]
   54033:	cmp    DWORD PTR [rbp+0xc],0x2
   54037:	jge    54067 <sqlite3VdbeExec+0x4bc7>
   54039:	mov    QWORD PTR [rsp+0x128],r13
   54041:	movsx  r13d,WORD PTR [r12+0x36]
   54047:	mov    QWORD PTR [rsp+0x108],r12
   5404f:	mov    DWORD PTR [rsp+0x340],r13d
   54057:	mov    r13,QWORD PTR [rsp+0x128]
   5405f:	xor    r12d,r12d
   54062:	jmp    54380 <sqlite3VdbeExec+0x4ee0>
   54067:	mov    QWORD PTR [rsp+0x128],r13
   5406f:	mov    eax,DWORD PTR [rbp+0xc]
   54072:	mov    r13d,eax
   54075:	sub    r13d,0x2
   54079:	mov    DWORD PTR [rsp+0x33c],r13d
   54081:	add    r13d,0x1
   54085:	mov    QWORD PTR [rsp+0x108],r12
   5408d:	mov    r12d,DWORD PTR [rsp+0x33c]
   54095:	mov    DWORD PTR [rsp+0x340],r13d
   5409d:	mov    r13,QWORD PTR [rsp+0x128]
   540a5:	jmp    54380 <sqlite3VdbeExec+0x4ee0>
   540aa:	mov    QWORD PTR [rsp+0x110],r15
   540b2:	mov    r15d,DWORD PTR [rsp+0x31c]
   540ba:	cmp    DWORD PTR [rbp+0xc],0x0
   540be:	je     540c9 <sqlite3VdbeExec+0x4c29>
   540c0:	add    r13,0x38
   540c4:	jmp    5437c <sqlite3VdbeExec+0x4edc>
   540c9:	movsxd rax,r12d
   540cc:	shl    rax,0x4
   540d0:	mov    QWORD PTR [rsp+0xc8],r14
   540d8:	mov    r14,QWORD PTR [rsp+0x110]
   540e0:	movsx  eax,BYTE PTR [r14+rax*1+0x9]
   540e6:	mov    ecx,r15d
   540e9:	mov    QWORD PTR [rsp+0xb0],rdi
   540f1:	mov    rdi,r13
   540f4:	mov    rsi,rax
   540f7:	mov    rdx,rcx
   540fa:	call   540ff <sqlite3VdbeExec+0x4c5f>
   540ff:	movzx  eax,WORD PTR [r13+0x14]
   54104:	and    eax,0x1
   54107:	mov    rdi,QWORD PTR [rsp+0xb0]
   5410f:	test   eax,eax
   54111:	je     54120 <sqlite3VdbeExec+0x4c80>
   54113:	mov    r14,QWORD PTR [rsp+0xc8]
   5411b:	jmp    54378 <sqlite3VdbeExec+0x4ed8>
   54120:	movsxd rax,r12d
   54123:	shl    rax,0x4
   54127:	movzx  eax,BYTE PTR [r14+rax*1+0x8]
   5412d:	shl    rax,0x38
   54131:	shr    rax,0x3c
   54135:	mov    ecx,eax
   54137:	sub    ecx,0x2
   5413a:	cmp    ecx,0x4
   5413d:	jbe    54154 <sqlite3VdbeExec+0x4cb4>
   5413f:	mov    QWORD PTR [rsp+0x110],r14
   54147:	mov    r14,QWORD PTR [rsp+0xc8]
   5414f:	jmp    54378 <sqlite3VdbeExec+0x4ed8>
   54154:	sub    eax,0x2
   54157:	mov    QWORD PTR [rsp+0xe8],rbp
   5415f:	lea    rbp,[rip+0x0]        # 54166 <sqlite3VdbeExec+0x4cc6>
   54166:	movsxd rax,DWORD PTR [rbp+rax*4+0x0]
   5416b:	add    rax,rbp
   5416e:	jmp    rax
   54170:	mov    QWORD PTR [rsp+0x110],r14
   54178:	mov    r14,QWORD PTR [rsp+0xc8]
   54180:	mov    rbp,QWORD PTR [rsp+0xe8]
   54188:	jmp    54378 <sqlite3VdbeExec+0x4ed8>
   5418d:	movzx  eax,WORD PTR [r13+0x14]
   54192:	and    eax,0x10
   54195:	test   eax,eax
   54197:	je     541b6 <sqlite3VdbeExec+0x4d16>
   54199:	mov    QWORD PTR [rsp+0x110],r14
   541a1:	mov    r14,QWORD PTR [rsp+0xc8]
   541a9:	mov    rbp,QWORD PTR [rsp+0xe8]
   541b1:	jmp    54378 <sqlite3VdbeExec+0x4ed8>
   541b6:	lea    rax,[rip+0x0]        # 541bd <sqlite3VdbeExec+0x4d1d>
   541bd:	lea    rcx,[rip+0x0]        # 541c4 <sqlite3VdbeExec+0x4d24>
   541c4:	lea    rdx,[rip+0x0]        # 541cb <sqlite3VdbeExec+0x4d2b>
   541cb:	movzx  esi,WORD PTR [r13+0x14]
   541d0:	and    esi,0x3f
   541d3:	movzx  edx,BYTE PTR [rdx+rsi*1]
   541d7:	add    rdx,0xffffffffffffffff
   541db:	mov    rcx,QWORD PTR [rcx+rdx*8]
   541df:	lea    rdx,[rip+0x0]        # 541e6 <sqlite3VdbeExec+0x4d46>
   541e6:	movsxd rsi,r12d
   541e9:	mov    r8,rsi
   541ec:	shl    r8,0x4
   541f0:	movzx  r8d,BYTE PTR [r14+r8*1+0x8]
   541f6:	shl    r8,0x38
   541fa:	shr    r8,0x3c
   541fe:	add    r8,0xffffffffffffffff
   54202:	mov    rdx,QWORD PTR [rdx+r8*8]
   54206:	mov    r12,QWORD PTR [rsp+0x108]
   5420e:	mov    r8,QWORD PTR [r12]
   54212:	shl    rsi,0x4
   54216:	mov    rsi,QWORD PTR [r14+rsi*1]
   5421a:	mov    QWORD PTR [rsp+0xb0],rdi
   54222:	mov    r9,rsi
   54225:	mov    rsi,rax
   54228:	mov    r11,rdx
   5422b:	mov    rdx,rcx
   5422e:	mov    rcx,r11
   54231:	xor    eax,eax
   54233:	call   54238 <sqlite3VdbeExec+0x4d98>
   54238:	mov    ebp,0xc13
   5423d:	mov    rdi,QWORD PTR [rsp+0xb0]
   54245:	mov    r14,QWORD PTR [rsp+0xc8]
   5424d:	mov    r13,QWORD PTR [rsp+0xd0]
   54255:	mov    rbx,QWORD PTR [rsp+0xf8]
   5425d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   54262:	mov    QWORD PTR [rsp+0x110],r14
   5426a:	mov    r14,QWORD PTR [rsp+0xc8]
   54272:	mov    rbp,QWORD PTR [rsp+0xe8]
   5427a:	movzx  eax,WORD PTR [r13+0x14]
   5427f:	and    eax,0x4
   54282:	test   eax,eax
   54284:	jne    54378 <sqlite3VdbeExec+0x4ed8>
   5428a:	mov    QWORD PTR [rsp+0xc8],r14
   54292:	mov    r14,QWORD PTR [rsp+0x110]
   5429a:	mov    QWORD PTR [rsp+0xe8],rbp
   542a2:	jmp    541b6 <sqlite3VdbeExec+0x4d16>
   542a7:	mov    QWORD PTR [rsp+0x110],r14
   542af:	mov    r14,QWORD PTR [rsp+0xc8]
   542b7:	mov    rbp,QWORD PTR [rsp+0xe8]
   542bf:	movzx  eax,WORD PTR [r13+0x14]
   542c4:	and    eax,0x2
   542c7:	test   eax,eax
   542c9:	jne    54378 <sqlite3VdbeExec+0x4ed8>
   542cf:	mov    QWORD PTR [rsp+0xc8],r14
   542d7:	mov    r14,QWORD PTR [rsp+0x110]
   542df:	mov    QWORD PTR [rsp+0xe8],rbp
   542e7:	jmp    541b6 <sqlite3VdbeExec+0x4d16>
   542ec:	mov    QWORD PTR [rsp+0x110],r14
   542f4:	mov    r14,QWORD PTR [rsp+0xc8]
   542fc:	mov    rbp,QWORD PTR [rsp+0xe8]
   54304:	movzx  eax,WORD PTR [r13+0x14]
   54309:	and    eax,0x4
   5430c:	test   eax,eax
   5430e:	je     5444b <sqlite3VdbeExec+0x4fab>
   54314:	movabs rax,0x7fffffffffff
   5431e:	cmp    rax,QWORD PTR [r13+0x0]
   54322:	jge    54339 <sqlite3VdbeExec+0x4e99>
   54324:	mov    DWORD PTR [rsp+0x31c],r15d
   5432c:	mov    r15,QWORD PTR [rsp+0x110]
   54334:	jmp    5440a <sqlite3VdbeExec+0x4f6a>
   54339:	movabs rax,0xffff800000000000
   54343:	cmp    rax,QWORD PTR [r13+0x0]
   54347:	jle    5435e <sqlite3VdbeExec+0x4ebe>
   54349:	mov    DWORD PTR [rsp+0x31c],r15d
   54351:	mov    r15,QWORD PTR [rsp+0x110]
   54359:	jmp    5440a <sqlite3VdbeExec+0x4f6a>
   5435e:	movzx  eax,WORD PTR [r13+0x14]
   54363:	or     eax,0x20
   54366:	mov    WORD PTR [r13+0x14],ax
   5436b:	movzx  eax,WORD PTR [r13+0x14]
   54370:	and    eax,0xfffffffb
   54373:	mov    WORD PTR [r13+0x14],ax
   54378:	add    r13,0x38
   5437c:	add    r12d,0x1
   54380:	mov    DWORD PTR [rsp+0x31c],r15d
   54388:	mov    r15d,DWORD PTR [rsp+0x340]
   54390:	cmp    r12d,r15d
   54393:	jge    54494 <sqlite3VdbeExec+0x4ff4>
   54399:	movsxd rax,r12d
   5439c:	shl    rax,0x4
   543a0:	mov    r15,QWORD PTR [rsp+0x110]
   543a8:	movzx  eax,WORD PTR [r15+rax*1+0xe]
   543ae:	and    eax,0x60
   543b1:	test   eax,eax
   543b3:	jne    543c2 <sqlite3VdbeExec+0x4f22>
   543b5:	mov    r15d,DWORD PTR [rsp+0x31c]
   543bd:	jmp    540c9 <sqlite3VdbeExec+0x4c29>
   543c2:	cmp    DWORD PTR [rbp+0xc],0x2
   543c6:	jl     543dd <sqlite3VdbeExec+0x4f3d>
   543c8:	mov    QWORD PTR [rsp+0x110],r15
   543d0:	mov    r15d,DWORD PTR [rsp+0x31c]
   543d8:	jmp    540c9 <sqlite3VdbeExec+0x4c29>
   543dd:	movsxd rax,r12d
   543e0:	shl    rax,0x4
   543e4:	movzx  eax,WORD PTR [r15+rax*1+0xe]
   543ea:	and    eax,0x20
   543ed:	test   eax,eax
   543ef:	je     540aa <sqlite3VdbeExec+0x4c0a>
   543f5:	mov    QWORD PTR [rsp+0x110],r15
   543fd:	mov    r15d,DWORD PTR [rsp+0x31c]
   54405:	jmp    5437c <sqlite3VdbeExec+0x4edc>
   5440a:	mov    rax,QWORD PTR [r13+0x0]
   5440e:	xorps  xmm1,xmm1
   54411:	cvtsi2sd xmm1,rax
   54416:	movsd  QWORD PTR [r13+0x0],xmm1
   5441c:	movzx  eax,WORD PTR [r13+0x14]
   54421:	or     eax,0x8
   54424:	mov    WORD PTR [r13+0x14],ax
   54429:	movzx  eax,WORD PTR [r13+0x14]
   5442e:	and    eax,0xfffffffb
   54431:	mov    WORD PTR [r13+0x14],ax
   54436:	mov    QWORD PTR [rsp+0x110],r15
   5443e:	mov    r15d,DWORD PTR [rsp+0x31c]
   54446:	jmp    54378 <sqlite3VdbeExec+0x4ed8>
   5444b:	mov    DWORD PTR [rsp+0x31c],r15d
   54453:	mov    r15,QWORD PTR [rsp+0x110]
   5445b:	movzx  eax,WORD PTR [r13+0x14]
   54460:	and    eax,0x28
   54463:	test   eax,eax
   54465:	je     5447c <sqlite3VdbeExec+0x4fdc>
   54467:	mov    QWORD PTR [rsp+0x110],r15
   5446f:	mov    r15d,DWORD PTR [rsp+0x31c]
   54477:	jmp    54378 <sqlite3VdbeExec+0x4ed8>
   5447c:	mov    QWORD PTR [rsp+0xc8],r14
   54484:	mov    r14,r15
   54487:	mov    QWORD PTR [rsp+0xe8],rbp
   5448f:	jmp    541b6 <sqlite3VdbeExec+0x4d16>
   54494:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   54499:	mov    QWORD PTR [rsp+0xd0],r12
   544a1:	mov    r12,QWORD PTR [rbp+0x10]
   544a5:	movsxd rax,DWORD PTR [rbp+0x4]
   544a9:	imul   rax,rax,0x38
   544ad:	lea    r13,[rbx+rax*1]
   544b1:	mov    r15,r12
   544b4:	mov    r12,r13
   544b7:	jmp    544ff <sqlite3VdbeExec+0x505f>
   544b9:	mov    rax,QWORD PTR [r12]
   544bd:	xorps  xmm1,xmm1
   544c0:	cvtsi2sd xmm1,rax
   544c5:	movsd  QWORD PTR [r12],xmm1
   544cb:	movzx  eax,WORD PTR [r12+0x14]
   544d1:	or     eax,0x8
   544d4:	mov    WORD PTR [r12+0x14],ax
   544da:	movzx  eax,WORD PTR [r12+0x14]
   544e0:	and    eax,0xfffffff9
   544e3:	mov    WORD PTR [r12+0x14],ax
   544e9:	lea    r13,[r15+0x1]
   544ed:	cmp    BYTE PTR [r15+0x1],0x0
   544f2:	je     545ae <sqlite3VdbeExec+0x510e>
   544f8:	add    r12,0x38
   544fc:	mov    r15,r13
   544ff:	movsx  eax,BYTE PTR [r15]
   54503:	mov    r13d,DWORD PTR [rsp+0x31c]
   5450b:	mov    ecx,r13d
   5450e:	mov    QWORD PTR [rsp+0xb0],rdi
   54516:	mov    rdi,r12
   54519:	mov    rsi,rax
   5451c:	mov    rdx,rcx
   5451f:	call   54524 <sqlite3VdbeExec+0x5084>
   54524:	mov    rdi,QWORD PTR [rsp+0xb0]
   5452c:	cmp    BYTE PTR [r15],0x45
   54530:	jne    544e9 <sqlite3VdbeExec+0x5049>
   54532:	movzx  eax,WORD PTR [r12+0x14]
   54538:	and    eax,0x4
   5453b:	test   eax,eax
   5453d:	jne    54549 <sqlite3VdbeExec+0x50a9>
   5453f:	mov    DWORD PTR [rsp+0x31c],r13d
   54547:	jmp    544e9 <sqlite3VdbeExec+0x5049>
   54549:	movabs rax,0x7fffffffffff
   54553:	cmp    rax,QWORD PTR [r12]
   54557:	jge    54566 <sqlite3VdbeExec+0x50c6>
   54559:	mov    DWORD PTR [rsp+0x31c],r13d
   54561:	jmp    544b9 <sqlite3VdbeExec+0x5019>
   54566:	movabs rax,0xffff800000000000
   54570:	cmp    rax,QWORD PTR [r12]
   54574:	jle    54583 <sqlite3VdbeExec+0x50e3>
   54576:	mov    DWORD PTR [rsp+0x31c],r13d
   5457e:	jmp    544b9 <sqlite3VdbeExec+0x5019>
   54583:	movzx  eax,WORD PTR [r12+0x14]
   54589:	or     eax,0x20
   5458c:	mov    WORD PTR [r12+0x14],ax
   54592:	movzx  eax,WORD PTR [r12+0x14]
   54598:	and    eax,0xfffffffb
   5459b:	mov    WORD PTR [r12+0x14],ax
   545a1:	mov    DWORD PTR [rsp+0x31c],r13d
   545a9:	jmp    544e9 <sqlite3VdbeExec+0x5049>
   545ae:	mov    r13d,DWORD PTR [rsp+0x31c]
   545b6:	mov    DWORD PTR [rsp+0x31c],r13d
   545be:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   545c3:	mov    r13d,DWORD PTR [rsp+0x31c]
   545cb:	mov    QWORD PTR [rsp+0xd0],r12
   545d3:	mov    DWORD PTR [rsp+0x31c],r13d
   545db:	movsxd rax,DWORD PTR [rbp+0x4]
   545df:	mov    r12,QWORD PTR [rbp+0x10]
   545e3:	imul   rax,rax,0x38
   545e7:	lea    r13,[rbx+rax*1]
   545eb:	mov    eax,DWORD PTR [rbp+0x8]
   545ee:	sub    eax,0x1
   545f1:	movsxd rax,eax
   545f4:	imul   rax,rax,0x38
   545f8:	lea    r15,[r13+rax*1+0x0]
   545fd:	movsxd rax,DWORD PTR [rbp+0xc]
   54601:	imul   rax,rax,0x38
   54605:	mov    QWORD PTR [rsp+0x108],r15
   5460d:	lea    r15,[rbx+rax*1]
   54611:	test   r12,r12
   54614:	jne    5462b <sqlite3VdbeExec+0x518b>
   54616:	mov    QWORD PTR [rsp+0x110],r13
   5461e:	mov    QWORD PTR [rsp+0x128],r15
   54626:	jmp    546bf <sqlite3VdbeExec+0x521f>
   5462b:	mov    QWORD PTR [rsp+0x110],r13
   54633:	movsx  eax,BYTE PTR [r12]
   54638:	mov    QWORD PTR [rsp+0x128],r15
   54640:	mov    r15d,DWORD PTR [rsp+0x31c]
   54648:	mov    ecx,r15d
   5464b:	mov    QWORD PTR [rsp+0xb0],rdi
   54653:	mov    rdi,r13
   54656:	mov    rsi,rax
   54659:	mov    rdx,rcx
   5465c:	call   54661 <sqlite3VdbeExec+0x51c1>
   54661:	mov    rdi,QWORD PTR [rsp+0xb0]
   54669:	cmp    BYTE PTR [r12],0x45
   5466e:	jne    54696 <sqlite3VdbeExec+0x51f6>
   54670:	movzx  eax,WORD PTR [r13+0x14]
   54675:	and    eax,0x4
   54678:	test   eax,eax
   5467a:	je     54696 <sqlite3VdbeExec+0x51f6>
   5467c:	movzx  eax,WORD PTR [r13+0x14]
   54681:	or     eax,0x20
   54684:	mov    WORD PTR [r13+0x14],ax
   54689:	movzx  eax,WORD PTR [r13+0x14]
   5468e:	and    eax,0xfffffffb
   54691:	mov    WORD PTR [r13+0x14],ax
   54696:	mov    DWORD PTR [rsp+0x31c],r15d
   5469e:	lea    r15,[r12+0x1]
   546a3:	add    r13,0x38
   546a7:	cmp    BYTE PTR [r12+0x1],0x0
   546ad:	je     546bf <sqlite3VdbeExec+0x521f>
   546af:	mov    r12,r15
   546b2:	mov    r15,QWORD PTR [rsp+0x128]
   546ba:	jmp    54633 <sqlite3VdbeExec+0x5193>
   546bf:	mov    r12,QWORD PTR [rsp+0x108]
   546c7:	xor    r15d,r15d
   546ca:	xor    r13d,r13d
   546cd:	xor    r11d,r11d
   546d0:	mov    QWORD PTR [rsp+0x118],r11
   546d8:	jmp    54a1c <sqlite3VdbeExec+0x557c>
   546dd:	mov    DWORD PTR [r12+0x24],0x0
   546e6:	add    r13d,0x1
   546ea:	mov    QWORD PTR [rsp+0xc8],r14
   546f2:	mov    r14,r13
   546f5:	jmp    549f8 <sqlite3VdbeExec+0x5558>
   546fa:	movzx  eax,WORD PTR [r12+0x14]
   54700:	and    eax,0x24
   54703:	test   eax,eax
   54705:	je     5482b <sqlite3VdbeExec+0x538b>
   5470b:	mov    rax,QWORD PTR [r12]
   5470f:	test   rax,rax
   54712:	jge    5471c <sqlite3VdbeExec+0x527c>
   54714:	mov    rcx,rax
   54717:	not    rcx
   5471a:	jmp    5471f <sqlite3VdbeExec+0x527f>
   5471c:	mov    rcx,rax
   5471f:	add    r13d,0x1
   54723:	cmp    rcx,0x7f
   54727:	ja     5475a <sqlite3VdbeExec+0x52ba>
   54729:	mov    rdx,rax
   5472c:	and    rdx,0x1
   54730:	cmp    rdx,rax
   54733:	jne    54748 <sqlite3VdbeExec+0x52a8>
   54735:	cmp    BYTE PTR [rdi+0xc5],0x4
   5473c:	jb     54748 <sqlite3VdbeExec+0x52a8>
   5473e:	lea    eax,[rcx+0x8]
   54741:	mov    DWORD PTR [r12+0x24],eax
   54746:	jmp    54755 <sqlite3VdbeExec+0x52b5>
   54748:	add    r15,0x1
   5474c:	mov    DWORD PTR [r12+0x24],0x1
   54755:	jmp    5481b <sqlite3VdbeExec+0x537b>
   5475a:	cmp    rcx,0x7fff
   54761:	ja     54775 <sqlite3VdbeExec+0x52d5>
   54763:	add    r15,0x2
   54767:	mov    DWORD PTR [r12+0x24],0x2
   54770:	jmp    5481b <sqlite3VdbeExec+0x537b>
   54775:	cmp    rcx,0x7fffff
   5477c:	ja     54790 <sqlite3VdbeExec+0x52f0>
   5477e:	add    r15,0x3
   54782:	mov    DWORD PTR [r12+0x24],0x3
   5478b:	jmp    5481b <sqlite3VdbeExec+0x537b>
   54790:	cmp    rcx,0x7fffffff
   54797:	ja     547a8 <sqlite3VdbeExec+0x5308>
   54799:	add    r15,0x4
   5479d:	mov    DWORD PTR [r12+0x24],0x4
   547a6:	jmp    5481b <sqlite3VdbeExec+0x537b>
   547a8:	movabs rax,0x7fffffffffff
   547b2:	cmp    rcx,rax
   547b5:	ja     547c6 <sqlite3VdbeExec+0x5326>
   547b7:	add    r15,0x6
   547bb:	mov    DWORD PTR [r12+0x24],0x5
   547c4:	jmp    5481b <sqlite3VdbeExec+0x537b>
   547c6:	add    r15,0x8
   547ca:	movzx  eax,WORD PTR [r12+0x14]
   547d0:	and    eax,0x20
   547d3:	test   eax,eax
   547d5:	je     54812 <sqlite3VdbeExec+0x5372>
   547d7:	mov    rax,QWORD PTR [r12]
   547db:	xorps  xmm1,xmm1
   547de:	cvtsi2sd xmm1,rax
   547e3:	movsd  QWORD PTR [r12],xmm1
   547e9:	movzx  eax,WORD PTR [r12+0x14]
   547ef:	and    eax,0xffffffdf
   547f2:	mov    WORD PTR [r12+0x14],ax
   547f8:	movzx  eax,WORD PTR [r12+0x14]
   547fe:	or     eax,0x8
   54801:	mov    WORD PTR [r12+0x14],ax
   54807:	mov    DWORD PTR [r12+0x24],0x7
   54810:	jmp    5481b <sqlite3VdbeExec+0x537b>
   54812:	mov    DWORD PTR [r12+0x24],0x6
   5481b:	mov    QWORD PTR [rsp+0xc8],r14
   54823:	mov    r14,r13
   54826:	jmp    549f8 <sqlite3VdbeExec+0x5558>
   5482b:	movzx  eax,WORD PTR [r12+0x14]
   54831:	and    eax,0x8
   54834:	test   eax,eax
   54836:	je     54859 <sqlite3VdbeExec+0x53b9>
   54838:	add    r13d,0x1
   5483c:	add    r15,0x8
   54840:	mov    DWORD PTR [r12+0x24],0x7
   54849:	mov    QWORD PTR [rsp+0xc8],r14
   54851:	mov    r14,r13
   54854:	jmp    549f8 <sqlite3VdbeExec+0x5558>
   54859:	mov    DWORD PTR [rsp+0x340],r13d
   54861:	mov    r13d,DWORD PTR [r12+0x10]
   54866:	mov    eax,r13d
   54869:	shl    eax,1
   5486b:	add    eax,0xc
   5486e:	movzx  ecx,WORD PTR [r12+0x14]
   54874:	and    ecx,0x2
   54877:	test   ecx,ecx
   54879:	mov    ecx,0x0
   5487e:	setne  cl
   54881:	mov    DWORD PTR [rsp+0x33c],r13d
   54889:	lea    r13d,[rax+rcx*1]
   5488d:	movzx  eax,WORD PTR [r12+0x14]
   54893:	and    eax,0x400
   54898:	test   eax,eax
   5489a:	jne    548b1 <sqlite3VdbeExec+0x5411>
   5489c:	mov    QWORD PTR [rsp+0xc8],r14
   548a4:	mov    r14d,DWORD PTR [rsp+0x33c]
   548ac:	jmp    549c3 <sqlite3VdbeExec+0x5523>
   548b1:	mov    eax,DWORD PTR [r12]
   548b5:	shl    eax,1
   548b7:	add    r13d,eax
   548ba:	test   r15,r15
   548bd:	je     5498c <sqlite3VdbeExec+0x54ec>
   548c3:	mov    eax,DWORD PTR [r12+0x10]
   548c8:	add    eax,DWORD PTR [r12]
   548cc:	test   eax,eax
   548ce:	jg     548e2 <sqlite3VdbeExec+0x5442>
   548d0:	movzx  eax,WORD PTR [r12+0x14]
   548d6:	and    eax,0x10
   548d9:	test   eax,eax
   548db:	je     5494e <sqlite3VdbeExec+0x54ae>
   548dd:	mov    eax,0x1
   548e2:	mov    ecx,0x1
   548e7:	mov    QWORD PTR [rsp+0xb0],rdi
   548ef:	mov    rdi,r12
   548f2:	mov    rsi,rax
   548f5:	mov    rdx,rcx
   548f8:	call   548fd <sqlite3VdbeExec+0x545d>
   548fd:	mov    rdi,QWORD PTR [rsp+0xb0]
   54905:	test   eax,eax
   54907:	jne    54964 <sqlite3VdbeExec+0x54c4>
   54909:	mov    rax,QWORD PTR [r12+0x8]
   5490e:	movsxd rcx,DWORD PTR [r12+0x10]
   54913:	add    rax,rcx
   54916:	xor    ecx,ecx
   54918:	movsxd rdx,DWORD PTR [r12]
   5491c:	mov    rdi,rax
   5491f:	mov    rsi,rcx
   54922:	call   54927 <sqlite3VdbeExec+0x5487>
   54927:	mov    eax,DWORD PTR [r12+0x10]
   5492c:	add    eax,DWORD PTR [r12]
   54930:	mov    DWORD PTR [r12+0x10],eax
   54935:	movzx  eax,WORD PTR [r12+0x14]
   5493b:	and    eax,0xfffff9ff
   54940:	mov    WORD PTR [r12+0x14],ax
   54946:	mov    rdi,QWORD PTR [rsp+0xb0]
   5494e:	mov    QWORD PTR [rsp+0xc8],r14
   54956:	mov    r14d,DWORD PTR [rsp+0x33c]
   5495e:	add    r14d,DWORD PTR [r12]
   54962:	jmp    549c3 <sqlite3VdbeExec+0x5523>
   54964:	mov    QWORD PTR [rsp+0xc8],r14
   5496c:	mov    r14,QWORD PTR [rsp+0xc8]
   54974:	mov    r13,QWORD PTR [rsp+0xf0]
   5497c:	mov    rbx,rbp
   5497f:	mov    rbp,QWORD PTR [rsp+0xf8]
   54987:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5498c:	movsxd rax,DWORD PTR [r12]
   54990:	mov    DWORD PTR [rsp+0x338],r13d
   54998:	mov    r13,QWORD PTR [rsp+0x118]
   549a0:	add    r13,rax
   549a3:	mov    QWORD PTR [rsp+0xc8],r14
   549ab:	mov    QWORD PTR [rsp+0x118],r13
   549b3:	mov    r13d,DWORD PTR [rsp+0x338]
   549bb:	mov    r14d,DWORD PTR [rsp+0x33c]
   549c3:	mov    rax,r14
   549c6:	add    r15,rax
   549c9:	mov    rax,r13
   549cc:	mov    ecx,0x1
   549d1:	mov    r11,rcx
   549d4:	mov    rcx,rax
   549d7:	mov    rax,r11
   549da:	jmp    549df <sqlite3VdbeExec+0x553f>
   549dc:	add    eax,0x1
   549df:	shr    rcx,0x7
   549e3:	test   rcx,rcx
   549e6:	jne    549dc <sqlite3VdbeExec+0x553c>
   549e8:	mov    r14d,DWORD PTR [rsp+0x340]
   549f0:	add    r14d,eax
   549f3:	mov    DWORD PTR [r12+0x24],r13d
   549f8:	mov    r13,QWORD PTR [rsp+0x110]
   54a00:	cmp    r12,r13
   54a03:	je     54a4e <sqlite3VdbeExec+0x55ae>
   54a05:	add    r12,0xffffffffffffffc8
   54a09:	mov    QWORD PTR [rsp+0x110],r13
   54a11:	mov    r13,r14
   54a14:	mov    r14,QWORD PTR [rsp+0xc8]
   54a1c:	movzx  eax,WORD PTR [r12+0x14]
   54a22:	and    eax,0x1
   54a25:	test   eax,eax
   54a27:	je     546fa <sqlite3VdbeExec+0x525a>
   54a2d:	movzx  eax,WORD PTR [r12+0x14]
   54a33:	and    eax,0x400
   54a38:	test   eax,eax
   54a3a:	je     546dd <sqlite3VdbeExec+0x523d>
   54a40:	mov    DWORD PTR [r12+0x24],0xa
   54a49:	jmp    546e6 <sqlite3VdbeExec+0x5246>
   54a4e:	cmp    r14d,0x7e
   54a52:	jg     54a5d <sqlite3VdbeExec+0x55bd>
   54a54:	lea    r12d,[r14+0x1]
   54a58:	mov    r14,r12
   54a5b:	jmp    54aa6 <sqlite3VdbeExec+0x5606>
   54a5d:	mov    rax,r14
   54a60:	mov    ecx,0x1
   54a65:	mov    r11,rcx
   54a68:	mov    rcx,rax
   54a6b:	mov    rax,r11
   54a6e:	jmp    54a73 <sqlite3VdbeExec+0x55d3>
   54a70:	add    eax,0x1
   54a73:	shr    rcx,0x7
   54a77:	test   rcx,rcx
   54a7a:	jne    54a70 <sqlite3VdbeExec+0x55d0>
   54a7c:	add    r14d,eax
   54a7f:	movsxd rcx,r14d
   54a82:	mov    edx,0x1
   54a87:	mov    r11,rdx
   54a8a:	mov    rdx,rcx
   54a8d:	mov    rcx,r11
   54a90:	jmp    54a95 <sqlite3VdbeExec+0x55f5>
   54a92:	add    ecx,0x1
   54a95:	shr    rdx,0x7
   54a99:	test   rdx,rdx
   54a9c:	jne    54a92 <sqlite3VdbeExec+0x55f2>
   54a9e:	cmp    eax,ecx
   54aa0:	jge    54aa6 <sqlite3VdbeExec+0x5606>
   54aa2:	add    r14d,0x1
   54aa6:	movsxd rax,r14d
   54aa9:	lea    r12,[rax+r15*1]
   54aad:	mov    r15,QWORD PTR [rsp+0x118]
   54ab5:	lea    rax,[r12+r15*1]
   54ab9:	mov    QWORD PTR [rsp+0x110],r13
   54ac1:	mov    r13,QWORD PTR [rsp+0x128]
   54ac9:	movsxd rcx,DWORD PTR [r13+0x20]
   54acd:	cmp    rax,rcx
   54ad0:	jg     54b26 <sqlite3VdbeExec+0x5686>
   54ad2:	mov    rax,QWORD PTR [r13+0x28]
   54ad6:	mov    QWORD PTR [r13+0x8],rax
   54ada:	mov    DWORD PTR [r13+0x10],r12d
   54ade:	mov    WORD PTR [r13+0x14],0x10
   54ae5:	test   r15,r15
   54ae8:	je     54afd <sqlite3VdbeExec+0x565d>
   54aea:	mov    DWORD PTR [r13+0x0],r15d
   54aee:	movzx  eax,WORD PTR [r13+0x14]
   54af3:	or     eax,0x400
   54af8:	mov    WORD PTR [r13+0x14],ax
   54afd:	mov    r12,QWORD PTR [r13+0x8]
   54b01:	movsxd rax,r14d
   54b04:	lea    r13,[r12+rax*1]
   54b08:	cmp    r14d,0x80
   54b0f:	jge    54bfc <sqlite3VdbeExec+0x575c>
   54b15:	lea    r15,[r12+0x1]
   54b1a:	mov    BYTE PTR [r12],r14b
   54b1e:	mov    r12,r15
   54b21:	jmp    54c63 <sqlite3VdbeExec+0x57c3>
   54b26:	lea    rax,[r12+r15*1]
   54b2a:	mov    QWORD PTR [rsp+0xe8],rbp
   54b32:	mov    rbp,QWORD PTR [rsp+0xc8]
   54b3a:	movsxd rcx,DWORD PTR [rbp+0x88]
   54b41:	cmp    rax,rcx
   54b44:	jg     53cb6 <sqlite3VdbeExec+0x4816>
   54b4a:	mov    eax,r12d
   54b4d:	cmp    eax,DWORD PTR [r13+0x20]
   54b51:	jle    54bac <sqlite3VdbeExec+0x570c>
   54b53:	xor    ecx,ecx
   54b55:	mov    QWORD PTR [rsp+0xb0],rdi
   54b5d:	mov    rdi,r13
   54b60:	mov    rsi,rax
   54b63:	mov    rdx,rcx
   54b66:	call   54b6b <sqlite3VdbeExec+0x56cb>
   54b6b:	mov    rdi,QWORD PTR [rsp+0xb0]
   54b73:	test   eax,eax
   54b75:	jne    54b8c <sqlite3VdbeExec+0x56ec>
   54b77:	mov    QWORD PTR [rsp+0xc8],rbp
   54b7f:	mov    rbp,QWORD PTR [rsp+0xe8]
   54b87:	jmp    54ada <sqlite3VdbeExec+0x563a>
   54b8c:	mov    r14,rbp
   54b8f:	mov    r13,QWORD PTR [rsp+0xf0]
   54b97:	mov    rbx,QWORD PTR [rsp+0xe8]
   54b9f:	mov    rbp,QWORD PTR [rsp+0xf8]
   54ba7:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   54bac:	mov    QWORD PTR [rsp+0xc8],rbp
   54bb4:	mov    QWORD PTR [rsp+0x118],r15
   54bbc:	mov    r15,r13
   54bbf:	mov    r13,QWORD PTR [rsp+0x110]
   54bc7:	mov    rbp,QWORD PTR [rsp+0xe8]
   54bcf:	mov    rax,QWORD PTR [r15+0x28]
   54bd3:	mov    QWORD PTR [r15+0x8],rax
   54bd7:	movzx  eax,WORD PTR [r15+0x14]
   54bdc:	and    eax,0x2d
   54bdf:	mov    WORD PTR [r15+0x14],ax
   54be4:	mov    QWORD PTR [rsp+0x110],r13
   54bec:	mov    r13,r15
   54bef:	mov    r15,QWORD PTR [rsp+0x118]
   54bf7:	jmp    54ada <sqlite3VdbeExec+0x563a>
   54bfc:	mov    rax,r14
   54bff:	cmp    rax,0x7f
   54c03:	ja     54c14 <sqlite3VdbeExec+0x5774>
   54c05:	and    rax,0x7f
   54c09:	mov    BYTE PTR [r12],al
   54c0d:	mov    eax,0x1
   54c12:	jmp    54c5d <sqlite3VdbeExec+0x57bd>
   54c14:	cmp    rax,0x3fff
   54c1a:	ja     54c42 <sqlite3VdbeExec+0x57a2>
   54c1c:	mov    rcx,rax
   54c1f:	shr    rcx,0x7
   54c23:	and    rcx,0x7f
   54c27:	or     rcx,0x80
   54c2e:	mov    BYTE PTR [r12],cl
   54c32:	and    rax,0x7f
   54c36:	mov    BYTE PTR [r12+0x1],al
   54c3b:	mov    eax,0x2
   54c40:	jmp    54c5d <sqlite3VdbeExec+0x57bd>
   54c42:	mov    QWORD PTR [rsp+0xb0],rdi
   54c4a:	mov    rdi,r12
   54c4d:	mov    rsi,rax
   54c50:	call   54c55 <sqlite3VdbeExec+0x57b5>
   54c55:	mov    rdi,QWORD PTR [rsp+0xb0]
   54c5d:	movsxd rax,eax
   54c60:	add    r12,rax
   54c63:	mov    r14,QWORD PTR [rsp+0x110]
   54c6b:	mov    r15,r13
   54c6e:	jmp    54ee4 <sqlite3VdbeExec+0x5a44>
   54c73:	lea    r13,[rip+0x0]        # 54c7a <sqlite3VdbeExec+0x57da>
   54c7a:	cmp    eax,0x7
   54c7d:	jne    54c8c <sqlite3VdbeExec+0x57ec>
   54c7f:	mov    rcx,QWORD PTR [r14]
   54c82:	mov    QWORD PTR [rsp+0x110],rcx
   54c8a:	jmp    54c97 <sqlite3VdbeExec+0x57f7>
   54c8c:	mov    rcx,QWORD PTR [r14]
   54c8f:	mov    QWORD PTR [rsp+0x110],rcx
   54c97:	lea    rcx,[rip+0x0]        # 54c9e <sqlite3VdbeExec+0x57fe>
   54c9e:	movzx  eax,BYTE PTR [rcx+rax*1]
   54ca2:	mov    ecx,eax
   54ca4:	sub    ecx,0x1
   54ca7:	cmp    ecx,0x5
   54caa:	ja     54cbb <sqlite3VdbeExec+0x581b>
   54cac:	mov    ecx,eax
   54cae:	sub    ecx,0x1
   54cb1:	movsxd rcx,DWORD PTR [r13+rcx*4+0x0]
   54cb6:	add    rcx,r13
   54cb9:	jmp    rcx
   54cbb:	mov    rcx,QWORD PTR [rsp+0x110]
   54cc3:	and    rcx,0xff
   54cca:	mov    BYTE PTR [r15+0x7],cl
   54cce:	mov    rcx,QWORD PTR [rsp+0x110]
   54cd6:	shr    rcx,0x8
   54cda:	mov    QWORD PTR [rsp+0x110],rcx
   54ce2:	mov    rcx,QWORD PTR [rsp+0x110]
   54cea:	and    rcx,0xff
   54cf1:	mov    BYTE PTR [r15+0x6],cl
   54cf5:	mov    rcx,QWORD PTR [rsp+0x110]
   54cfd:	shr    rcx,0x8
   54d01:	mov    QWORD PTR [rsp+0x110],rcx
   54d09:	mov    rcx,QWORD PTR [rsp+0x110]
   54d11:	and    rcx,0xff
   54d18:	mov    BYTE PTR [r15+0x5],cl
   54d1c:	mov    rcx,QWORD PTR [rsp+0x110]
   54d24:	shr    rcx,0x8
   54d28:	mov    QWORD PTR [rsp+0x110],rcx
   54d30:	mov    rcx,QWORD PTR [rsp+0x110]
   54d38:	and    rcx,0xff
   54d3f:	mov    BYTE PTR [r15+0x4],cl
   54d43:	mov    rcx,QWORD PTR [rsp+0x110]
   54d4b:	shr    rcx,0x8
   54d4f:	mov    QWORD PTR [rsp+0x110],rcx
   54d57:	mov    rcx,QWORD PTR [rsp+0x110]
   54d5f:	and    rcx,0xff
   54d66:	mov    BYTE PTR [r15+0x3],cl
   54d6a:	mov    rcx,QWORD PTR [rsp+0x110]
   54d72:	shr    rcx,0x8
   54d76:	mov    QWORD PTR [rsp+0x110],rcx
   54d7e:	mov    rcx,QWORD PTR [rsp+0x110]
   54d86:	and    rcx,0xff
   54d8d:	mov    BYTE PTR [r15+0x2],cl
   54d91:	mov    rcx,QWORD PTR [rsp+0x110]
   54d99:	shr    rcx,0x8
   54d9d:	mov    QWORD PTR [rsp+0x110],rcx
   54da5:	mov    rcx,QWORD PTR [rsp+0x110]
   54dad:	and    rcx,0xff
   54db4:	mov    BYTE PTR [r15+0x1],cl
   54db8:	mov    rcx,QWORD PTR [rsp+0x110]
   54dc0:	shr    rcx,0x8
   54dc4:	mov    QWORD PTR [rsp+0x110],rcx
   54dcc:	mov    rcx,QWORD PTR [rsp+0x110]
   54dd4:	and    rcx,0xff
   54ddb:	mov    BYTE PTR [r15],cl
   54dde:	add    r15,rax
   54de1:	jmp    54ecb <sqlite3VdbeExec+0x5a2b>
   54de6:	cmp    eax,0x80
   54deb:	jae    54e33 <sqlite3VdbeExec+0x5993>
   54ded:	mov    BYTE PTR [r12],al
   54df1:	add    r12,0x1
   54df5:	cmp    eax,0xe
   54df8:	jb     54e2e <sqlite3VdbeExec+0x598e>
   54dfa:	cmp    DWORD PTR [r14+0x10],0x0
   54dff:	jle    54e2e <sqlite3VdbeExec+0x598e>
   54e01:	mov    rax,QWORD PTR [r14+0x8]
   54e05:	movsxd rcx,DWORD PTR [r14+0x10]
   54e09:	mov    QWORD PTR [rsp+0xb0],rdi
   54e11:	mov    rdi,r15
   54e14:	mov    rsi,rax
   54e17:	mov    rdx,rcx
   54e1a:	call   54e1f <sqlite3VdbeExec+0x597f>
   54e1f:	movsxd rax,DWORD PTR [r14+0x10]
   54e23:	add    r15,rax
   54e26:	mov    rdi,QWORD PTR [rsp+0xb0]
   54e2e:	jmp    54ecb <sqlite3VdbeExec+0x5a2b>
   54e33:	cmp    rax,0x7f
   54e37:	ja     54e48 <sqlite3VdbeExec+0x59a8>
   54e39:	and    rax,0x7f
   54e3d:	mov    BYTE PTR [r12],al
   54e41:	mov    eax,0x1
   54e46:	jmp    54e91 <sqlite3VdbeExec+0x59f1>
   54e48:	cmp    rax,0x3fff
   54e4e:	ja     54e76 <sqlite3VdbeExec+0x59d6>
   54e50:	mov    rcx,rax
   54e53:	shr    rcx,0x7
   54e57:	and    rcx,0x7f
   54e5b:	or     rcx,0x80
   54e62:	mov    BYTE PTR [r12],cl
   54e66:	and    rax,0x7f
   54e6a:	mov    BYTE PTR [r12+0x1],al
   54e6f:	mov    eax,0x2
   54e74:	jmp    54e91 <sqlite3VdbeExec+0x59f1>
   54e76:	mov    QWORD PTR [rsp+0xb0],rdi
   54e7e:	mov    rdi,r12
   54e81:	mov    rsi,rax
   54e84:	call   54e89 <sqlite3VdbeExec+0x59e9>
   54e89:	mov    rdi,QWORD PTR [rsp+0xb0]
   54e91:	movsxd rax,eax
   54e94:	add    r12,rax
   54e97:	cmp    DWORD PTR [r14+0x10],0x0
   54e9c:	je     54ecb <sqlite3VdbeExec+0x5a2b>
   54e9e:	mov    rax,QWORD PTR [r14+0x8]
   54ea2:	movsxd rcx,DWORD PTR [r14+0x10]
   54ea6:	mov    QWORD PTR [rsp+0xb0],rdi
   54eae:	mov    rdi,r15
   54eb1:	mov    rsi,rax
   54eb4:	mov    rdx,rcx
   54eb7:	call   54ebc <sqlite3VdbeExec+0x5a1c>
   54ebc:	movsxd rax,DWORD PTR [r14+0x10]
   54ec0:	add    r15,rax
   54ec3:	mov    rdi,QWORD PTR [rsp+0xb0]
   54ecb:	mov    r13,QWORD PTR [rsp+0x108]
   54ed3:	cmp    r14,r13
   54ed6:	je     54f06 <sqlite3VdbeExec+0x5a66>
   54ed8:	add    r14,0x38
   54edc:	mov    QWORD PTR [rsp+0x108],r13
   54ee4:	mov    eax,DWORD PTR [r14+0x24]
   54ee8:	cmp    eax,0x7
   54eeb:	ja     54de6 <sqlite3VdbeExec+0x5946>
   54ef1:	mov    BYTE PTR [r12],al
   54ef5:	add    r12,0x1
   54ef9:	test   eax,eax
   54efb:	jne    54c73 <sqlite3VdbeExec+0x57d3>
   54f01:	jmp    54de1 <sqlite3VdbeExec+0x5941>
   54f06:	mov    r14,QWORD PTR [rsp+0xc8]
   54f0e:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   54f13:	mov    QWORD PTR [rsp+0xc8],r14
   54f1b:	mov    QWORD PTR [rsp+0xd0],r12
   54f23:	mov    rax,QWORD PTR [rdi+0x78]
   54f27:	movsxd rcx,DWORD PTR [rbp+0x4]
   54f2b:	mov    rax,QWORD PTR [rax+rcx*8]
   54f2f:	mov    r12,QWORD PTR [rax+0x28]
   54f33:	cmp    DWORD PTR [rbp+0xc],0x0
   54f37:	je     55004 <sqlite3VdbeExec+0x5b64>
   54f3d:	cmp    BYTE PTR [r12],0x0
   54f42:	je     54f48 <sqlite3VdbeExec+0x5aa8>
   54f44:	xor    eax,eax
   54f46:	jmp    54f98 <sqlite3VdbeExec+0x5af8>
   54f48:	mov    rax,QWORD PTR [r12+0x88]
   54f50:	cmp    BYTE PTR [rax+0x8],0x0
   54f54:	jne    54f5f <sqlite3VdbeExec+0x5abf>
   54f56:	mov    rax,0xffffffffffffffff
   54f5d:	jmp    54f98 <sqlite3VdbeExec+0x5af8>
   54f5f:	mov    rax,QWORD PTR [r12+0x88]
   54f67:	movzx  eax,WORD PTR [rax+0x18]
   54f6b:	xor    ecx,ecx
   54f6d:	jmp    54f8c <sqlite3VdbeExec+0x5aec>
   54f6f:	mov    rdx,rcx
   54f72:	mov    rdx,QWORD PTR [r12+rdx*8+0x90]
   54f7a:	movzx  edx,WORD PTR [rdx+0x18]
   54f7e:	add    edx,0x1
   54f81:	imul   rax,rdx
   54f85:	mov    edx,0x1
   54f8a:	add    cl,dl
   54f8c:	mov    edx,ecx
   54f8e:	movsx  esi,BYTE PTR [r12+0x54]
   54f94:	cmp    edx,esi
   54f96:	jl     54f6f <sqlite3VdbeExec+0x5acf>
   54f98:	mov    QWORD PTR [rsp+0x108],rax
   54fa0:	mov    rax,QWORD PTR [rdi+0x68]
   54fa4:	movsxd rcx,DWORD PTR [rbp+0x8]
   54fa8:	imul   rcx,rcx,0x38
   54fac:	lea    rdx,[rax+rcx*1]
   54fb0:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   54fb5:	and    eax,0x9000
   54fba:	test   eax,eax
   54fbc:	je     552f9 <sqlite3VdbeExec+0x5e59>
   54fc2:	mov    QWORD PTR [rsp+0xb0],rdi
   54fca:	mov    rdi,rdx
   54fcd:	call   54fd2 <sqlite3VdbeExec+0x5b32>
   54fd2:	mov    rdi,QWORD PTR [rsp+0xb0]
   54fda:	mov    r14,QWORD PTR [rsp+0xc8]
   54fe2:	mov    r15d,DWORD PTR [rsp+0x31c]
   54fea:	mov    r13,rbx
   54fed:	mov    ebx,DWORD PTR [rsp+0x330]
   54ff4:	mov    r12d,DWORD PTR [rsp+0x334]
   54ffc:	mov    rdx,rax
   54fff:	jmp    55321 <sqlite3VdbeExec+0x5e81>
   55004:	mov    QWORD PTR [rsp+0x108],0x0
   55010:	xor    r14d,r14d
   55013:	mov    QWORD PTR [rsp+0xb0],rdi
   5501b:	mov    rdi,r12
   5501e:	call   55023 <sqlite3VdbeExec+0x5b83>
   55023:	mov    r15d,eax
   55026:	mov    rdi,QWORD PTR [rsp+0xb0]
   5502e:	cmp    r15d,0x10
   55032:	jne    5522a <sqlite3VdbeExec+0x5d8a>
   55038:	mov    QWORD PTR [rsp+0x108],0x0
   55044:	xor    r12d,r12d
   55047:	mov    r15,r12
   5504a:	jmp    552bf <sqlite3VdbeExec+0x5e1f>
   5504f:	mov    WORD PTR [r12+0x46],0x0
   55057:	movzx  eax,BYTE PTR [r12+0x1]
   5505d:	and    eax,0xfffffff9
   55060:	mov    BYTE PTR [r12+0x1],al
   55065:	movsx  rax,BYTE PTR [r12+0x54]
   5506b:	add    rax,0xffffffffffffffff
   5506f:	movzx  eax,WORD PTR [r12+rax*2+0x58]
   55075:	mov    WORD PTR [r12+0x56],ax
   5507b:	mov    rax,QWORD PTR [r12+0x88]
   55083:	movsx  ecx,BYTE PTR [r12+0x54]
   55089:	sub    ecx,0x1
   5508c:	movzx  ecx,cl
   5508f:	mov    BYTE PTR [r12+0x54],cl
   55094:	movsx  rcx,cl
   55098:	mov    rcx,QWORD PTR [r12+rcx*8+0x90]
   550a0:	mov    QWORD PTR [r12+0x88],rcx
   550a8:	mov    rax,QWORD PTR [rax+0x70]
   550ac:	movzx  ecx,WORD PTR [rax+0x34]
   550b0:	and    ecx,0x20
   550b3:	test   ecx,ecx
   550b5:	je     5511a <sqlite3VdbeExec+0x5c7a>
   550b7:	mov    rcx,QWORD PTR [rax+0x28]
   550bb:	mov    edx,DWORD PTR [rcx+0x98]
   550c1:	sub    edx,0x1
   550c4:	mov    DWORD PTR [rcx+0x98],edx
   550ca:	mov    rdx,QWORD PTR [rcx+0xa8]
   550d1:	mov    QWORD PTR [rax+0x20],rdx
   550d5:	mov    QWORD PTR [rcx+0xa8],rax
   550dc:	mov    rdx,QWORD PTR [rcx+0x48]
   550e0:	mov    esi,DWORD PTR [rax+0x30]
   550e3:	sub    esi,0x1
   550e6:	imul   rsi,QWORD PTR [rcx+0xc8]
   550ee:	mov    rax,QWORD PTR [rax+0x8]
   550f2:	mov    rcx,QWORD PTR [rdx]
   550f5:	mov    rcx,QWORD PTR [rcx+0x90]
   550fc:	mov    QWORD PTR [rsp+0xb0],rdi
   55104:	mov    rdi,rdx
   55107:	mov    rdx,rax
   5510a:	mov    r10,rcx
   5510d:	call   r10
   55110:	mov    rdi,QWORD PTR [rsp+0xb0]
   55118:	jmp    55132 <sqlite3VdbeExec+0x5c92>
   5511a:	mov    QWORD PTR [rsp+0xb0],rdi
   55122:	mov    rdi,rax
   55125:	call   5512a <sqlite3VdbeExec+0x5c8a>
   5512a:	mov    rdi,QWORD PTR [rsp+0xb0]
   55132:	movzx  eax,WORD PTR [r12+0x56]
   55138:	mov    rcx,QWORD PTR [r12+0x88]
   55140:	movzx  ecx,WORD PTR [rcx+0x18]
   55144:	cmp    eax,ecx
   55146:	jge    55283 <sqlite3VdbeExec+0x5de3>
   5514c:	movzx  eax,WORD PTR [r12+0x56]
   55152:	add    eax,0x1
   55155:	mov    WORD PTR [r12+0x56],ax
   5515b:	mov    rax,QWORD PTR [r12+0x88]
   55163:	movzx  ecx,WORD PTR [r12+0x56]
   55169:	movzx  edx,WORD PTR [rax+0x18]
   5516d:	cmp    ecx,edx
   5516f:	jne    551be <sqlite3VdbeExec+0x5d1e>
   55171:	mov    rcx,QWORD PTR [rax+0x50]
   55175:	movzx  eax,BYTE PTR [rax+0x9]
   55179:	add    eax,0x8
   5517c:	movzx  edx,BYTE PTR [rcx+rax*1]
   55180:	shl    edx,0x18
   55183:	movzx  esi,BYTE PTR [rcx+rax*1+0x1]
   55188:	shl    esi,0x10
   5518b:	or     edx,esi
   5518d:	movzx  esi,BYTE PTR [rcx+rax*1+0x2]
   55192:	shl    esi,0x8
   55195:	or     edx,esi
   55197:	movzx  eax,BYTE PTR [rcx+rax*1+0x3]
   5519c:	or     edx,eax
   5519e:	mov    QWORD PTR [rsp+0xb0],rdi
   551a6:	mov    rdi,r12
   551a9:	mov    rsi,rdx
   551ac:	call   551b1 <sqlite3VdbeExec+0x5d11>
   551b1:	mov    r15d,eax
   551b4:	mov    rdi,QWORD PTR [rsp+0xb0]
   551bc:	jmp    5522a <sqlite3VdbeExec+0x5d8a>
   551be:	mov    rdx,QWORD PTR [rax+0x50]
   551c2:	movzx  esi,WORD PTR [rax+0x1a]
   551c6:	mov    r8,QWORD PTR [rax+0x60]
   551ca:	mov    r9d,ecx
   551cd:	shl    r9d,1
   551d0:	movzx  r8d,BYTE PTR [r8+r9*1]
   551d5:	shl    r8d,0x8
   551d9:	mov    rax,QWORD PTR [rax+0x60]
   551dd:	shl    ecx,1
   551df:	movzx  eax,BYTE PTR [rax+rcx*1+0x1]
   551e4:	or     r8d,eax
   551e7:	and    esi,r8d
   551ea:	movzx  eax,BYTE PTR [rdx+rsi*1]
   551ee:	shl    eax,0x18
   551f1:	movzx  ecx,BYTE PTR [rdx+rsi*1+0x1]
   551f6:	shl    ecx,0x10
   551f9:	or     eax,ecx
   551fb:	movzx  ecx,BYTE PTR [rdx+rsi*1+0x2]
   55200:	shl    ecx,0x8
   55203:	or     eax,ecx
   55205:	movzx  ecx,BYTE PTR [rdx+rsi*1+0x3]
   5520a:	or     eax,ecx
   5520c:	mov    QWORD PTR [rsp+0xb0],rdi
   55214:	mov    rdi,r12
   55217:	mov    rsi,rax
   5521a:	call   5521f <sqlite3VdbeExec+0x5d7f>
   5521f:	mov    r15d,eax
   55222:	mov    rdi,QWORD PTR [rsp+0xb0]
   5522a:	test   r15d,r15d
   5522d:	je     55239 <sqlite3VdbeExec+0x5d99>
   5522f:	mov    r13,QWORD PTR [rsp+0xc8]
   55237:	jmp    552b7 <sqlite3VdbeExec+0x5e17>
   55239:	mov    r13,QWORD PTR [rsp+0xc8]
   55241:	mov    eax,DWORD PTR [r13+0x190]
   55248:	test   eax,eax
   5524a:	jne    552b7 <sqlite3VdbeExec+0x5e17>
   5524c:	mov    rax,QWORD PTR [r12+0x88]
   55254:	cmp    BYTE PTR [rax+0x8],0x0
   55258:	jne    5526a <sqlite3VdbeExec+0x5dca>
   5525a:	cmp    BYTE PTR [rax+0x1],0x0
   5525e:	je     5526a <sqlite3VdbeExec+0x5dca>
   55260:	mov    QWORD PTR [rsp+0xc8],r13
   55268:	jmp    55279 <sqlite3VdbeExec+0x5dd9>
   5526a:	movzx  ecx,WORD PTR [rax+0x18]
   5526e:	add    r14,rcx
   55271:	mov    QWORD PTR [rsp+0xc8],r13
   55279:	cmp    BYTE PTR [rax+0x8],0x0
   5527d:	je     55163 <sqlite3VdbeExec+0x5cc3>
   55283:	cmp    BYTE PTR [r12+0x54],0x0
   55289:	jne    5504f <sqlite3VdbeExec+0x5baf>
   5528f:	mov    QWORD PTR [rsp+0x108],r14
   55297:	mov    QWORD PTR [rsp+0xb0],rdi
   5529f:	mov    rdi,r12
   552a2:	call   552a7 <sqlite3VdbeExec+0x5e07>
   552a7:	mov    r12d,eax
   552aa:	mov    rdi,QWORD PTR [rsp+0xb0]
   552b2:	mov    r15,r12
   552b5:	jmp    552bf <sqlite3VdbeExec+0x5e1f>
   552b7:	mov    QWORD PTR [rsp+0xc8],r13
   552bf:	test   r15d,r15d
   552c2:	jne    552d1 <sqlite3VdbeExec+0x5e31>
   552c4:	mov    DWORD PTR [rsp+0x32c],r15d
   552cc:	jmp    54fa0 <sqlite3VdbeExec+0x5b00>
   552d1:	mov    r14,QWORD PTR [rsp+0xc8]
   552d9:	mov    QWORD PTR [rsp+0xe8],rbp
   552e1:	mov    rbp,r15
   552e4:	mov    r13,QWORD PTR [rsp+0xd0]
   552ec:	mov    rbx,QWORD PTR [rsp+0xf8]
   552f4:	jmp    4f712 <sqlite3VdbeExec+0x272>
   552f9:	mov    WORD PTR [rdx+0x14],0x4
   552ff:	mov    r14,QWORD PTR [rsp+0xc8]
   55307:	mov    r15d,DWORD PTR [rsp+0x31c]
   5530f:	mov    r13,rbx
   55312:	mov    ebx,DWORD PTR [rsp+0x330]
   55319:	mov    r12d,DWORD PTR [rsp+0x334]
   55321:	mov    rax,QWORD PTR [rsp+0x108]
   55329:	mov    QWORD PTR [rdx],rax
   5532c:	mov    QWORD PTR [rsp+0xe8],rbp
   55334:	mov    QWORD PTR [rsp+0x100],r13
   5533c:	mov    r13,QWORD PTR [rsp+0xf0]
   55344:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   55349:	mov    r15d,DWORD PTR [rsp+0x31c]
   55351:	mov    r13,QWORD PTR [rsp+0xf0]
   55359:	mov    QWORD PTR [rsp+0xd0],r12
   55361:	mov    r12d,DWORD PTR [rsp+0x334]
   55369:	mov    DWORD PTR [rsp+0x334],r12d
   55371:	mov    r12d,DWORD PTR [rbp+0x4]
   55375:	mov    QWORD PTR [rsp+0xf0],r13
   5537d:	mov    r13,QWORD PTR [rbp+0x10]
   55381:	test   r12d,r12d
   55384:	jne    55543 <sqlite3VdbeExec+0x60a3>
   5538a:	cmp    DWORD PTR [r14+0xd8],0x0
   55392:	jle    553c8 <sqlite3VdbeExec+0x5f28>
   55394:	lea    rax,[rip+0x0]        # 5539b <sqlite3VdbeExec+0x5efb>
   5539b:	mov    QWORD PTR [rsp+0xb0],rdi
   553a3:	mov    rsi,rax
   553a6:	xor    eax,eax
   553a8:	call   553ad <sqlite3VdbeExec+0x5f0d>
   553ad:	mov    r12d,0x5
   553b3:	mov    rdi,QWORD PTR [rsp+0xb0]
   553bb:	mov    DWORD PTR [rsp+0x338],r12d
   553c3:	jmp    55512 <sqlite3VdbeExec+0x6072>
   553c8:	test   r13,r13
   553cb:	jne    553d2 <sqlite3VdbeExec+0x5f32>
   553cd:	xor    r12d,r12d
   553d0:	jmp    553f4 <sqlite3VdbeExec+0x5f54>
   553d2:	mov    QWORD PTR [rsp+0xb0],rdi
   553da:	mov    rdi,r13
   553dd:	call   553e2 <sqlite3VdbeExec+0x5f42>
   553e2:	mov    r12d,eax
   553e5:	and    r12d,0x3fffffff
   553ec:	mov    rdi,QWORD PTR [rsp+0xb0]
   553f4:	xor    eax,eax
   553f6:	mov    ecx,DWORD PTR [r14+0x2ec]
   553fd:	add    ecx,DWORD PTR [r14+0x2e8]
   55404:	mov    QWORD PTR [rsp+0xc8],r14
   5540c:	mov    QWORD PTR [rsp+0xb0],rdi
   55414:	mov    rdi,r14
   55417:	mov    rsi,rax
   5541a:	mov    rdx,rcx
   5541d:	call   55422 <sqlite3VdbeExec+0x5f82>
   55422:	mov    r14d,eax
   55425:	mov    rdi,QWORD PTR [rsp+0xb0]
   5542d:	test   r14d,r14d
   55430:	je     5545a <sqlite3VdbeExec+0x5fba>
   55432:	mov    QWORD PTR [rsp+0xe8],rbp
   5543a:	mov    rbp,r14
   5543d:	mov    r14,QWORD PTR [rsp+0xc8]
   55445:	mov    r13,QWORD PTR [rsp+0xd0]
   5544d:	mov    rbx,QWORD PTR [rsp+0xf8]
   55455:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5545a:	mov    rax,r12
   5545d:	add    rax,0x20
   55461:	add    rax,0x1
   55465:	mov    DWORD PTR [rsp+0x338],r14d
   5546d:	mov    r14,QWORD PTR [rsp+0xc8]
   55475:	mov    rdi,r14
   55478:	mov    rsi,rax
   5547b:	call   55480 <sqlite3VdbeExec+0x5fe0>
   55480:	mov    rdi,QWORD PTR [rsp+0xb0]
   55488:	test   rax,rax
   5548b:	je     55512 <sqlite3VdbeExec+0x6072>
   55491:	lea    rcx,[rax+0x20]
   55495:	mov    QWORD PTR [rax],rcx
   55498:	mov    rcx,QWORD PTR [rax]
   5549b:	lea    edx,[r12+0x1]
   554a0:	mov    QWORD PTR [rsp+0xa8],rax
   554a8:	mov    rdi,rcx
   554ab:	mov    rsi,r13
   554ae:	call   554b3 <sqlite3VdbeExec+0x6013>
   554b3:	mov    rcx,rax
   554b6:	mov    rax,QWORD PTR [rsp+0xa8]
   554be:	mov    rdi,QWORD PTR [rsp+0xb0]
   554c6:	cmp    BYTE PTR [r14+0x65],0x0
   554cb:	je     554d9 <sqlite3VdbeExec+0x6039>
   554cd:	mov    BYTE PTR [r14+0x65],0x0
   554d2:	mov    BYTE PTR [r14+0x6d],0x1
   554d7:	jmp    554ea <sqlite3VdbeExec+0x604a>
   554d9:	mov    ecx,DWORD PTR [r14+0x2e8]
   554e0:	add    ecx,0x1
   554e3:	mov    DWORD PTR [r14+0x2e8],ecx
   554ea:	mov    rcx,QWORD PTR [r14+0x2d8]
   554f1:	mov    QWORD PTR [rax+0x18],rcx
   554f5:	mov    QWORD PTR [r14+0x2d8],rax
   554fc:	mov    rcx,QWORD PTR [r14+0x2f0]
   55503:	mov    QWORD PTR [rax+0x8],rcx
   55507:	mov    rcx,QWORD PTR [r14+0x2f8]
   5550e:	mov    QWORD PTR [rax+0x10],rcx
   55512:	mov    r12d,DWORD PTR [rsp+0x338]
   5551a:	test   r12d,r12d
   5551d:	je     55b9d <sqlite3VdbeExec+0x66fd>
   55523:	mov    QWORD PTR [rsp+0xe8],rbp
   5552b:	mov    rbp,r12
   5552e:	mov    r13,QWORD PTR [rsp+0xd0]
   55536:	mov    rbx,QWORD PTR [rsp+0xf8]
   5553e:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55543:	mov    QWORD PTR [rsp+0x108],r13
   5554b:	mov    r13,QWORD PTR [r14+0x2d8]
   55552:	mov    DWORD PTR [rsp+0x340],r12d
   5555a:	mov    r12,r13
   5555d:	xor    r13d,r13d
   55560:	jmp    555b0 <sqlite3VdbeExec+0x6110>
   55562:	lea    rsi,[rip+0x0]        # 55569 <sqlite3VdbeExec+0x60c9>
   55569:	movzx  ecx,BYTE PTR [rsi+rcx*1]
   5556d:	movzx  edx,BYTE PTR [rsi+rdx*1]
   55571:	sub    ecx,edx
   55573:	test   ecx,ecx
   55575:	je     55579 <sqlite3VdbeExec+0x60d9>
   55577:	jmp    55591 <sqlite3VdbeExec+0x60f1>
   55579:	add    rax,0x1
   5557d:	add    r13,0x1
   55581:	movzx  ecx,BYTE PTR [rax]
   55584:	movzx  edx,BYTE PTR [r13+0x0]
   55589:	cmp    ecx,edx
   5558b:	jne    55562 <sqlite3VdbeExec+0x60c2>
   5558d:	test   ecx,ecx
   5558f:	jne    55579 <sqlite3VdbeExec+0x60d9>
   55591:	test   ecx,ecx
   55593:	jne    5559f <sqlite3VdbeExec+0x60ff>
   55595:	mov    r13d,DWORD PTR [rsp+0x338]
   5559d:	jmp    555cb <sqlite3VdbeExec+0x612b>
   5559f:	mov    r13d,DWORD PTR [rsp+0x338]
   555a7:	add    r13d,0x1
   555ab:	mov    r12,QWORD PTR [r12+0x18]
   555b0:	test   r12,r12
   555b3:	je     555cb <sqlite3VdbeExec+0x612b>
   555b5:	mov    rax,QWORD PTR [r12]
   555b9:	mov    DWORD PTR [rsp+0x338],r13d
   555c1:	mov    r13,QWORD PTR [rsp+0x108]
   555c9:	jmp    55581 <sqlite3VdbeExec+0x60e1>
   555cb:	test   r12,r12
   555ce:	jne    55607 <sqlite3VdbeExec+0x6167>
   555d0:	lea    rax,[rip+0x0]        # 555d7 <sqlite3VdbeExec+0x6137>
   555d7:	mov    r13,QWORD PTR [rsp+0x108]
   555df:	mov    QWORD PTR [rsp+0xb0],rdi
   555e7:	mov    rsi,rax
   555ea:	mov    rdx,r13
   555ed:	xor    eax,eax
   555ef:	call   555f4 <sqlite3VdbeExec+0x6154>
   555f4:	mov    r12d,0x1
   555fa:	mov    rdi,QWORD PTR [rsp+0xb0]
   55602:	jmp    5551a <sqlite3VdbeExec+0x607a>
   55607:	cmp    DWORD PTR [r14+0xd8],0x0
   5560f:	jg     55623 <sqlite3VdbeExec+0x6183>
   55611:	mov    DWORD PTR [rsp+0x31c],r15d
   55619:	mov    r15d,DWORD PTR [rsp+0x340]
   55621:	jmp    5566d <sqlite3VdbeExec+0x61cd>
   55623:	mov    DWORD PTR [rsp+0x31c],r15d
   5562b:	mov    r15d,DWORD PTR [rsp+0x340]
   55633:	cmp    r15d,0x1
   55637:	jne    5566d <sqlite3VdbeExec+0x61cd>
   55639:	lea    rax,[rip+0x0]        # 55640 <sqlite3VdbeExec+0x61a0>
   55640:	mov    QWORD PTR [rsp+0xb0],rdi
   55648:	mov    rsi,rax
   5564b:	xor    eax,eax
   5564d:	call   55652 <sqlite3VdbeExec+0x61b2>
   55652:	mov    r12d,0x5
   55658:	mov    rdi,QWORD PTR [rsp+0xb0]
   55660:	mov    r15d,DWORD PTR [rsp+0x31c]
   55668:	jmp    5551a <sqlite3VdbeExec+0x607a>
   5566d:	cmp    QWORD PTR [r12+0x18],0x0
   55673:	jne    5568b <sqlite3VdbeExec+0x61eb>
   55675:	mov    DWORD PTR [rsp+0x338],r13d
   5567d:	xor    r13d,r13d
   55680:	cmp    BYTE PTR [r14+0x6d],0x0
   55685:	setne  r13b
   55689:	jmp    55696 <sqlite3VdbeExec+0x61f6>
   5568b:	mov    DWORD PTR [rsp+0x338],r13d
   55693:	xor    r13d,r13d
   55696:	test   r13d,r13d
   55699:	jne    556b0 <sqlite3VdbeExec+0x6210>
   5569b:	mov    DWORD PTR [rsp+0x33c],r13d
   556a3:	mov    r13d,DWORD PTR [rsp+0x338]
   556ab:	jmp    557ef <sqlite3VdbeExec+0x634f>
   556b0:	cmp    r15d,0x1
   556b4:	je     556cb <sqlite3VdbeExec+0x622b>
   556b6:	mov    DWORD PTR [rsp+0x33c],r13d
   556be:	mov    r13d,DWORD PTR [rsp+0x338]
   556c6:	jmp    557ef <sqlite3VdbeExec+0x634f>
   556cb:	mov    rax,QWORD PTR [rdi]
   556ce:	mov    rcx,QWORD PTR [rax+0x2f0]
   556d5:	add    rcx,QWORD PTR [rax+0x2f8]
   556dc:	test   rcx,rcx
   556df:	jne    556ee <sqlite3VdbeExec+0x624e>
   556e1:	mov    DWORD PTR [rsp+0x33c],r13d
   556e9:	xor    r13d,r13d
   556ec:	jmp    5570e <sqlite3VdbeExec+0x626e>
   556ee:	mov    DWORD PTR [rsp+0x33c],r13d
   556f6:	mov    QWORD PTR [rsp+0xb0],rdi
   556fe:	call   55703 <sqlite3VdbeExec+0x6263>
   55703:	mov    r13d,eax
   55706:	mov    rdi,QWORD PTR [rsp+0xb0]
   5570e:	test   r13d,r13d
   55711:	je     55733 <sqlite3VdbeExec+0x6293>
   55713:	mov    r12,r13
   55716:	mov    r13d,DWORD PTR [rsp+0x320]
   5571e:	mov    r15,QWORD PTR [rsp+0xd0]
   55726:	mov    rbx,QWORD PTR [rsp+0xf8]
   5572e:	jmp    659c6 <sqlite3VdbeExec+0x16526>
   55733:	mov    r13,QWORD PTR [rsp+0xf0]
   5573b:	mov    BYTE PTR [r14+0x65],0x1
   55740:	mov    QWORD PTR [rsp+0xb0],rdi
   55748:	call   5574d <sqlite3VdbeExec+0x62ad>
   5574d:	mov    rdi,QWORD PTR [rsp+0xb0]
   55755:	cmp    eax,0x5
   55758:	jne    557ba <sqlite3VdbeExec+0x631a>
   5575a:	mov    rax,rbp
   5575d:	sub    rax,r13
   55760:	movabs rdx,0x2aaaaaaaaaaaaaab
   5576a:	imul   rdx
   5576d:	sar    rdx,0x2
   55771:	mov    rax,rdx
   55774:	shr    rax,0x3f
   55778:	add    rdx,rax
   5577b:	mov    rax,rdx
   5577e:	mov    DWORD PTR [rdi+0x30],eax
   55781:	mov    BYTE PTR [r14+0x65],0x0
   55786:	mov    ebx,0x5
   5578b:	mov    DWORD PTR [rdi+0x34],0x5
   55792:	mov    QWORD PTR [rsp+0xf0],r13
   5579a:	mov    r12,rbx
   5579d:	mov    r13d,DWORD PTR [rsp+0x320]
   557a5:	mov    r15,QWORD PTR [rsp+0xd0]
   557ad:	mov    rbx,QWORD PTR [rsp+0xf8]
   557b5:	jmp    659c6 <sqlite3VdbeExec+0x16526>
   557ba:	mov    DWORD PTR [rsp+0x340],r15d
   557c2:	mov    r15d,DWORD PTR [rdi+0x34]
   557c6:	test   r15d,r15d
   557c9:	je     557d2 <sqlite3VdbeExec+0x6332>
   557cb:	mov    BYTE PTR [r14+0x65],0x0
   557d0:	jmp    557d7 <sqlite3VdbeExec+0x6337>
   557d2:	mov    BYTE PTR [r14+0x6d],0x0
   557d7:	mov    QWORD PTR [rsp+0xf0],r13
   557df:	mov    r13,r15
   557e2:	mov    r15d,DWORD PTR [rsp+0x340]
   557ea:	jmp    55a12 <sqlite3VdbeExec+0x6572>
   557ef:	mov    eax,DWORD PTR [r14+0x2e8]
   557f6:	sub    eax,r13d
   557f9:	mov    r13d,eax
   557fc:	sub    r13d,0x1
   55800:	cmp    r15d,0x2
   55804:	jne    558fb <sqlite3VdbeExec+0x645b>
   5580a:	mov    eax,DWORD PTR [r14+0x2c]
   5580e:	mov    DWORD PTR [rsp+0x338],r13d
   55816:	mov    r13d,eax
   55819:	and    r13d,0x1
   5581d:	mov    DWORD PTR [rsp+0x344],r13d
   55825:	test   r13d,r13d
   55828:	mov    r13d,0x0
   5582e:	setne  r13b
   55832:	mov    DWORD PTR [rsp+0x348],r13d
   5583a:	xor    r13d,r13d
   5583d:	jmp    55863 <sqlite3VdbeExec+0x63c3>
   5583f:	mov    DWORD PTR [rsp+0x34c],r14d
   55847:	mov    r14,QWORD PTR [rsp+0xc8]
   5584f:	add    r13d,0x1
   55853:	mov    r11d,DWORD PTR [rsp+0x34c]
   5585b:	mov    DWORD PTR [rsp+0x32c],r11d
   55863:	cmp    r13d,DWORD PTR [r14+0x28]
   55867:	jge    558e1 <sqlite3VdbeExec+0x6441>
   55869:	mov    rax,QWORD PTR [r14+0x20]
   5586d:	mov    rcx,r13
   55870:	shl    rcx,0x5
   55874:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   55879:	mov    ecx,0x204
   5587e:	mov    QWORD PTR [rsp+0xc8],r14
   55886:	mov    r14d,DWORD PTR [rsp+0x344]
   5588e:	xor    edx,edx
   55890:	test   r14d,r14d
   55893:	sete   dl
   55896:	mov    QWORD PTR [rsp+0xb0],rdi
   5589e:	mov    rdi,rax
   558a1:	mov    rsi,rcx
   558a4:	call   558a9 <sqlite3VdbeExec+0x6409>
   558a9:	mov    r14d,eax
   558ac:	mov    rdi,QWORD PTR [rsp+0xb0]
   558b4:	test   r14d,r14d
   558b7:	je     5583f <sqlite3VdbeExec+0x639f>
   558b9:	mov    QWORD PTR [rsp+0xe8],rbp
   558c1:	mov    rbp,r14
   558c4:	mov    r14,QWORD PTR [rsp+0xc8]
   558cc:	mov    r13,QWORD PTR [rsp+0xd0]
   558d4:	mov    rbx,QWORD PTR [rsp+0xf8]
   558dc:	jmp    4f712 <sqlite3VdbeExec+0x272>
   558e1:	mov    QWORD PTR [rsp+0xc8],r14
   558e9:	mov    r14,QWORD PTR [rsp+0xc8]
   558f1:	mov    r13d,DWORD PTR [rsp+0x348]
   558f9:	jmp    55906 <sqlite3VdbeExec+0x6466>
   558fb:	mov    DWORD PTR [rsp+0x338],r13d
   55903:	xor    r13d,r13d
   55906:	mov    DWORD PTR [rsp+0x348],r13d
   5590e:	xor    r13d,r13d
   55911:	jmp    55937 <sqlite3VdbeExec+0x6497>
   55913:	mov    DWORD PTR [rsp+0x34c],r14d
   5591b:	mov    r14,QWORD PTR [rsp+0xc8]
   55923:	add    r13d,0x1
   55927:	mov    r11d,DWORD PTR [rsp+0x34c]
   5592f:	mov    DWORD PTR [rsp+0x32c],r11d
   55937:	cmp    r13d,DWORD PTR [r14+0x28]
   5593b:	jge    559ab <sqlite3VdbeExec+0x650b>
   5593d:	mov    rax,QWORD PTR [r14+0x20]
   55941:	mov    rcx,r13
   55944:	shl    rcx,0x5
   55948:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   5594d:	mov    QWORD PTR [rsp+0xc8],r14
   55955:	mov    r14d,DWORD PTR [rsp+0x338]
   5595d:	mov    QWORD PTR [rsp+0xb0],rdi
   55965:	mov    rdi,rax
   55968:	mov    rsi,r15
   5596b:	mov    rdx,r14
   5596e:	call   55973 <sqlite3VdbeExec+0x64d3>
   55973:	mov    r14d,eax
   55976:	mov    rdi,QWORD PTR [rsp+0xb0]
   5597e:	test   r14d,r14d
   55981:	je     55913 <sqlite3VdbeExec+0x6473>
   55983:	mov    QWORD PTR [rsp+0xe8],rbp
   5598b:	mov    rbp,r14
   5598e:	mov    r14,QWORD PTR [rsp+0xc8]
   55996:	mov    r13,QWORD PTR [rsp+0xd0]
   5599e:	mov    rbx,QWORD PTR [rsp+0xf8]
   559a6:	jmp    4f712 <sqlite3VdbeExec+0x272>
   559ab:	mov    r13d,DWORD PTR [rsp+0x348]
   559b3:	test   r13d,r13d
   559b6:	jne    559c2 <sqlite3VdbeExec+0x6522>
   559b8:	mov    r13d,DWORD PTR [rsp+0x32c]
   559c0:	jmp    55a12 <sqlite3VdbeExec+0x6572>
   559c2:	mov    rax,QWORD PTR [r14+0x8]
   559c6:	jmp    559e2 <sqlite3VdbeExec+0x6542>
   559c8:	movzx  ecx,WORD PTR [rax+0xc8]
   559cf:	and    rcx,0xfffffffffffffffc
   559d3:	or     rcx,0x1
   559d7:	mov    WORD PTR [rax+0xc8],cx
   559de:	mov    rax,QWORD PTR [rax+0x10]
   559e2:	test   rax,rax
   559e5:	jne    559c8 <sqlite3VdbeExec+0x6528>
   559e7:	mov    QWORD PTR [rsp+0xb0],rdi
   559ef:	mov    rdi,r14
   559f2:	call   559f7 <sqlite3VdbeExec+0x6557>
   559f7:	mov    eax,DWORD PTR [r14+0x2c]
   559fb:	or     eax,0x1
   559fe:	mov    DWORD PTR [r14+0x2c],eax
   55a02:	mov    rdi,QWORD PTR [rsp+0xb0]
   55a0a:	mov    r13d,DWORD PTR [rsp+0x32c]
   55a12:	test   r13d,r13d
   55a15:	je     55a7a <sqlite3VdbeExec+0x65da>
   55a17:	mov    QWORD PTR [rsp+0xe8],rbp
   55a1f:	mov    rbp,r13
   55a22:	mov    r13,QWORD PTR [rsp+0xd0]
   55a2a:	mov    rbx,QWORD PTR [rsp+0xf8]
   55a32:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55a37:	mov    rax,QWORD PTR [r14+0x2d8]
   55a3e:	mov    rcx,QWORD PTR [rax+0x18]
   55a42:	mov    QWORD PTR [r14+0x2d8],rcx
   55a49:	test   rax,rax
   55a4c:	je     55a69 <sqlite3VdbeExec+0x65c9>
   55a4e:	mov    QWORD PTR [rsp+0xb0],rdi
   55a56:	mov    rdi,r14
   55a59:	mov    rsi,rax
   55a5c:	call   55a61 <sqlite3VdbeExec+0x65c1>
   55a61:	mov    rdi,QWORD PTR [rsp+0xb0]
   55a69:	mov    eax,DWORD PTR [r14+0x2e8]
   55a70:	sub    eax,0x1
   55a73:	mov    DWORD PTR [r14+0x2e8],eax
   55a7a:	cmp    r12,QWORD PTR [r14+0x2d8]
   55a81:	jne    55a37 <sqlite3VdbeExec+0x6597>
   55a83:	cmp    r15d,0x1
   55a87:	jne    55aed <sqlite3VdbeExec+0x664d>
   55a89:	mov    rax,QWORD PTR [r12+0x18]
   55a8e:	mov    QWORD PTR [r14+0x2d8],rax
   55a95:	test   r12,r12
   55a98:	je     55ab5 <sqlite3VdbeExec+0x6615>
   55a9a:	mov    QWORD PTR [rsp+0xb0],rdi
   55aa2:	mov    rdi,r14
   55aa5:	mov    rsi,r12
   55aa8:	call   55aad <sqlite3VdbeExec+0x660d>
   55aad:	mov    rdi,QWORD PTR [rsp+0xb0]
   55ab5:	mov    r12d,DWORD PTR [rsp+0x33c]
   55abd:	test   r12d,r12d
   55ac0:	je     55acf <sqlite3VdbeExec+0x662f>
   55ac2:	mov    DWORD PTR [rsp+0x340],r15d
   55aca:	mov    r15,r12
   55acd:	jmp    55b15 <sqlite3VdbeExec+0x6675>
   55acf:	mov    eax,DWORD PTR [r14+0x2e8]
   55ad6:	sub    eax,0x1
   55ad9:	mov    DWORD PTR [r14+0x2e8],eax
   55ae0:	mov    DWORD PTR [rsp+0x340],r15d
   55ae8:	mov    r15,r12
   55aeb:	jmp    55b15 <sqlite3VdbeExec+0x6675>
   55aed:	mov    DWORD PTR [rsp+0x340],r15d
   55af5:	mov    r15d,DWORD PTR [rsp+0x33c]
   55afd:	mov    rax,QWORD PTR [r12+0x8]
   55b02:	mov    QWORD PTR [r14+0x2f0],rax
   55b09:	mov    rax,QWORD PTR [r12+0x10]
   55b0e:	mov    QWORD PTR [r14+0x2f8],rax
   55b15:	test   r15d,r15d
   55b18:	jne    55b24 <sqlite3VdbeExec+0x6684>
   55b1a:	mov    r15d,DWORD PTR [rsp+0x340]
   55b22:	jmp    55b42 <sqlite3VdbeExec+0x66a2>
   55b24:	mov    r15d,DWORD PTR [rsp+0x340]
   55b2c:	cmp    r15d,0x2
   55b30:	je     55b42 <sqlite3VdbeExec+0x66a2>
   55b32:	mov    r15d,DWORD PTR [rsp+0x31c]
   55b3a:	mov    r12,r13
   55b3d:	jmp    5551a <sqlite3VdbeExec+0x607a>
   55b42:	mov    r12d,DWORD PTR [rsp+0x338]
   55b4a:	mov    QWORD PTR [rsp+0xb0],rdi
   55b52:	mov    rdi,r14
   55b55:	mov    rsi,r15
   55b58:	mov    rdx,r12
   55b5b:	call   55b60 <sqlite3VdbeExec+0x66c0>
   55b60:	mov    r12d,eax
   55b63:	mov    rdi,QWORD PTR [rsp+0xb0]
   55b6b:	test   r12d,r12d
   55b6e:	jne    55b7d <sqlite3VdbeExec+0x66dd>
   55b70:	mov    r15d,DWORD PTR [rsp+0x31c]
   55b78:	jmp    5551a <sqlite3VdbeExec+0x607a>
   55b7d:	mov    QWORD PTR [rsp+0xe8],rbp
   55b85:	mov    rbp,r12
   55b88:	mov    r13,QWORD PTR [rsp+0xd0]
   55b90:	mov    rbx,QWORD PTR [rsp+0xf8]
   55b98:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55b9d:	cmp    BYTE PTR [rdi+0xc7],0x3
   55ba4:	jne    55bcb <sqlite3VdbeExec+0x672b>
   55ba6:	mov    ebx,0x65
   55bab:	mov    r12,rbx
   55bae:	mov    r13d,DWORD PTR [rsp+0x320]
   55bb6:	mov    r15,QWORD PTR [rsp+0xd0]
   55bbe:	mov    rbx,QWORD PTR [rsp+0xf8]
   55bc6:	jmp    659c6 <sqlite3VdbeExec+0x16526>
   55bcb:	mov    DWORD PTR [rsp+0x31c],r15d
   55bd3:	mov    DWORD PTR [rsp+0x32c],r12d
   55bdb:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   55be0:	mov    QWORD PTR [rsp+0xd0],r12
   55be8:	mov    ebx,DWORD PTR [rbp+0x4]
   55beb:	mov    eax,DWORD PTR [rbp+0x8]
   55bee:	movzx  ecx,BYTE PTR [r14+0x65]
   55bf3:	cmp    ebx,ecx
   55bf5:	je     55dfb <sqlite3VdbeExec+0x695b>
   55bfb:	test   eax,eax
   55bfd:	je     55c31 <sqlite3VdbeExec+0x6791>
   55bff:	mov    eax,0x204
   55c04:	mov    QWORD PTR [rsp+0xb0],rdi
   55c0c:	mov    rdi,r14
   55c0f:	mov    rsi,rax
   55c12:	call   55c17 <sqlite3VdbeExec+0x6777>
   55c17:	mov    BYTE PTR [r14+0x65],0x1
   55c1c:	mov    rdi,QWORD PTR [rsp+0xb0]
   55c24:	mov    r13,QWORD PTR [rsp+0xf0]
   55c2c:	jmp    55ce6 <sqlite3VdbeExec+0x6846>
   55c31:	test   ebx,ebx
   55c33:	je     55c85 <sqlite3VdbeExec+0x67e5>
   55c35:	cmp    DWORD PTR [r14+0xd8],0x0
   55c3d:	jle    55c85 <sqlite3VdbeExec+0x67e5>
   55c3f:	lea    rax,[rip+0x0]        # 55c46 <sqlite3VdbeExec+0x67a6>
   55c46:	mov    QWORD PTR [rsp+0xb0],rdi
   55c4e:	mov    rsi,rax
   55c51:	xor    eax,eax
   55c53:	call   55c58 <sqlite3VdbeExec+0x67b8>
   55c58:	mov    ebx,0x5
   55c5d:	mov    rdi,QWORD PTR [rsp+0xb0]
   55c65:	mov    QWORD PTR [rsp+0xe8],rbp
   55c6d:	mov    rbp,rbx
   55c70:	mov    r13,QWORD PTR [rsp+0xd0]
   55c78:	mov    rbx,QWORD PTR [rsp+0xf8]
   55c80:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55c85:	mov    rax,QWORD PTR [rdi]
   55c88:	mov    rcx,QWORD PTR [rax+0x2f0]
   55c8f:	add    rcx,QWORD PTR [rax+0x2f8]
   55c96:	test   rcx,rcx
   55c99:	jne    55ca0 <sqlite3VdbeExec+0x6800>
   55c9b:	xor    r12d,r12d
   55c9e:	jmp    55cb8 <sqlite3VdbeExec+0x6818>
   55ca0:	mov    QWORD PTR [rsp+0xb0],rdi
   55ca8:	call   55cad <sqlite3VdbeExec+0x680d>
   55cad:	mov    r12d,eax
   55cb0:	mov    rdi,QWORD PTR [rsp+0xb0]
   55cb8:	test   r12d,r12d
   55cbb:	je     55cda <sqlite3VdbeExec+0x683a>
   55cbd:	mov    r13d,DWORD PTR [rsp+0x320]
   55cc5:	mov    r15,QWORD PTR [rsp+0xd0]
   55ccd:	mov    rbx,QWORD PTR [rsp+0xf8]
   55cd5:	jmp    659c6 <sqlite3VdbeExec+0x16526>
   55cda:	mov    r13,QWORD PTR [rsp+0xf0]
   55ce2:	mov    BYTE PTR [r14+0x65],bl
   55ce6:	mov    QWORD PTR [rsp+0xb0],rdi
   55cee:	call   55cf3 <sqlite3VdbeExec+0x6853>
   55cf3:	mov    rdi,QWORD PTR [rsp+0xb0]
   55cfb:	cmp    eax,0x5
   55cfe:	jne    55d9c <sqlite3VdbeExec+0x68fc>
   55d04:	mov    rax,rbp
   55d07:	sub    rax,r13
   55d0a:	movabs rdx,0x2aaaaaaaaaaaaaab
   55d14:	imul   rdx
   55d17:	sar    rdx,0x2
   55d1b:	mov    rax,rdx
   55d1e:	shr    rax,0x3f
   55d22:	add    rdx,rax
   55d25:	mov    rax,rdx
   55d28:	mov    DWORD PTR [rdi+0x30],eax
   55d2b:	mov    eax,0x1
   55d30:	sub    eax,ebx
   55d32:	mov    BYTE PTR [r14+0x65],al
   55d36:	mov    ebx,0x5
   55d3b:	mov    DWORD PTR [rdi+0x34],0x5
   55d42:	mov    QWORD PTR [rsp+0xf0],r13
   55d4a:	mov    r12,rbx
   55d4d:	mov    r13d,DWORD PTR [rsp+0x320]
   55d55:	mov    r15,QWORD PTR [rsp+0xd0]
   55d5d:	mov    rbx,QWORD PTR [rsp+0xf8]
   55d65:	jmp    659c6 <sqlite3VdbeExec+0x16526>
   55d6a:	mov    rax,QWORD PTR [r14+0x2d8]
   55d71:	mov    rcx,QWORD PTR [rax+0x18]
   55d75:	mov    QWORD PTR [r14+0x2d8],rcx
   55d7c:	test   rax,rax
   55d7f:	je     55d9c <sqlite3VdbeExec+0x68fc>
   55d81:	mov    QWORD PTR [rsp+0xb0],rdi
   55d89:	mov    rdi,r14
   55d8c:	mov    rsi,rax
   55d8f:	call   55d94 <sqlite3VdbeExec+0x68f4>
   55d94:	mov    rdi,QWORD PTR [rsp+0xb0]
   55d9c:	cmp    QWORD PTR [r14+0x2d8],0x0
   55da4:	jne    55d6a <sqlite3VdbeExec+0x68ca>
   55da6:	mov    DWORD PTR [r14+0x2e8],0x0
   55db1:	mov    DWORD PTR [r14+0x2ec],0x0
   55dbc:	mov    BYTE PTR [r14+0x6d],0x0
   55dc1:	cmp    DWORD PTR [rdi+0x34],0x0
   55dc5:	jne    55dce <sqlite3VdbeExec+0x692e>
   55dc7:	mov    ebx,0x65
   55dcc:	jmp    55dd3 <sqlite3VdbeExec+0x6933>
   55dce:	mov    ebx,0x1
   55dd3:	mov    QWORD PTR [rsp+0xf0],r13
   55ddb:	mov    r12,rbx
   55dde:	mov    r13d,DWORD PTR [rsp+0x320]
   55de6:	mov    r15,QWORD PTR [rsp+0xd0]
   55dee:	mov    rbx,QWORD PTR [rsp+0xf8]
   55df6:	jmp    659c6 <sqlite3VdbeExec+0x16526>
   55dfb:	test   ebx,ebx
   55dfd:	jne    55e08 <sqlite3VdbeExec+0x6968>
   55dff:	lea    rax,[rip+0x0]        # 55e06 <sqlite3VdbeExec+0x6966>
   55e06:	jmp    55e1c <sqlite3VdbeExec+0x697c>
   55e08:	test   eax,eax
   55e0a:	je     55e15 <sqlite3VdbeExec+0x6975>
   55e0c:	lea    rax,[rip+0x0]        # 55e13 <sqlite3VdbeExec+0x6973>
   55e13:	jmp    55e1c <sqlite3VdbeExec+0x697c>
   55e15:	lea    rax,[rip+0x0]        # 55e1c <sqlite3VdbeExec+0x697c>
   55e1c:	mov    QWORD PTR [rsp+0xb0],rdi
   55e24:	mov    rsi,rax
   55e27:	xor    eax,eax
   55e29:	call   55e2e <sqlite3VdbeExec+0x698e>
   55e2e:	mov    ebx,0x1
   55e33:	mov    rdi,QWORD PTR [rsp+0xb0]
   55e3b:	mov    QWORD PTR [rsp+0xe8],rbp
   55e43:	mov    rbp,rbx
   55e46:	mov    r13,QWORD PTR [rsp+0xd0]
   55e4e:	mov    rbx,QWORD PTR [rsp+0xf8]
   55e56:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55e5b:	mov    r15d,DWORD PTR [rsp+0x31c]
   55e63:	mov    r13,QWORD PTR [rsp+0xf0]
   55e6b:	mov    QWORD PTR [rsp+0xd0],r12
   55e73:	mov    r12d,DWORD PTR [rsp+0x334]
   55e7b:	mov    DWORD PTR [rsp+0x338],0x0
   55e86:	cmp    DWORD PTR [rbp+0x8],0x0
   55e8a:	je     55ef1 <sqlite3VdbeExec+0x6a51>
   55e8c:	movabs rax,0x200100000
   55e96:	and    rax,QWORD PTR [r14+0x30]
   55e9a:	test   rax,rax
   55e9d:	je     55ef1 <sqlite3VdbeExec+0x6a51>
   55e9f:	mov    rax,QWORD PTR [r14+0x30]
   55ea3:	and    rax,0x100000
   55ea9:	test   rax,rax
   55eac:	je     55ebe <sqlite3VdbeExec+0x6a1e>
   55eae:	mov    ebx,0x8
   55eb3:	mov    r11,rbx
   55eb6:	mov    rbx,rbp
   55eb9:	mov    rbp,r11
   55ebc:	jmp    55ecc <sqlite3VdbeExec+0x6a2c>
   55ebe:	mov    ebx,0xb
   55ec3:	mov    r11,rbx
   55ec6:	mov    rbx,rbp
   55ec9:	mov    rbp,r11
   55ecc:	mov    QWORD PTR [rsp+0xf0],r13
   55ed4:	mov    QWORD PTR [rsp+0xe8],rbx
   55edc:	mov    r13,QWORD PTR [rsp+0xd0]
   55ee4:	mov    rbx,QWORD PTR [rsp+0xf8]
   55eec:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55ef1:	mov    DWORD PTR [rsp+0x334],r12d
   55ef9:	mov    r12,QWORD PTR [r14+0x20]
   55efd:	movsxd rax,DWORD PTR [rbp+0x4]
   55f01:	mov    QWORD PTR [rsp+0xf0],r13
   55f09:	mov    r13,rax
   55f0c:	shl    r13,0x5
   55f10:	mov    QWORD PTR [rsp+0x108],r12
   55f18:	mov    r12,QWORD PTR [r12+r13*1+0x8]
   55f1d:	test   r12,r12
   55f20:	jne    55f3f <sqlite3VdbeExec+0x6a9f>
   55f22:	mov    DWORD PTR [rsp+0x31c],r15d
   55f2a:	mov    r12,QWORD PTR [rsp+0x108]
   55f32:	mov    r15d,DWORD PTR [rsp+0x32c]
   55f3a:	jmp    56210 <sqlite3VdbeExec+0x6d70>
   55f3f:	mov    eax,DWORD PTR [rbp+0x8]
   55f42:	mov    QWORD PTR [rsp+0x110],r13
   55f4a:	lea    r13,[rsp+0x338]
   55f52:	mov    rcx,r13
   55f55:	cmp    BYTE PTR [r12+0x11],0x0
   55f5b:	jne    55f71 <sqlite3VdbeExec+0x6ad1>
   55f5d:	cmp    BYTE PTR [r12+0x10],0x0
   55f63:	je     55f71 <sqlite3VdbeExec+0x6ad1>
   55f65:	cmp    BYTE PTR [r12+0x10],0x1
   55f6b:	jne    55f97 <sqlite3VdbeExec+0x6af7>
   55f6d:	test   eax,eax
   55f6f:	je     55f97 <sqlite3VdbeExec+0x6af7>
   55f71:	mov    QWORD PTR [rsp+0xb0],rdi
   55f79:	mov    rdi,r12
   55f7c:	mov    rsi,rax
   55f7f:	mov    rdx,rcx
   55f82:	call   55f87 <sqlite3VdbeExec+0x6ae7>
   55f87:	mov    r13d,eax
   55f8a:	mov    rdi,QWORD PTR [rsp+0xb0]
   55f92:	jmp    5601b <sqlite3VdbeExec+0x6b7b>
   55f97:	mov    rdx,QWORD PTR [r12+0x8]
   55f9c:	test   rcx,rcx
   55f9f:	je     55fd4 <sqlite3VdbeExec+0x6b34>
   55fa1:	mov    rsi,QWORD PTR [rdx+0x18]
   55fa5:	mov    rsi,QWORD PTR [rsi+0x50]
   55fa9:	movzx  r8d,BYTE PTR [rsi+0x28]
   55fae:	shl    r8d,0x18
   55fb2:	movzx  r9d,BYTE PTR [rsi+0x29]
   55fb7:	shl    r9d,0x10
   55fbb:	or     r8d,r9d
   55fbe:	movzx  r9d,BYTE PTR [rsi+0x2a]
   55fc3:	shl    r9d,0x8
   55fc7:	or     r8d,r9d
   55fca:	movzx  esi,BYTE PTR [rsi+0x2b]
   55fce:	or     r8d,esi
   55fd1:	mov    DWORD PTR [rcx],r8d
   55fd4:	test   eax,eax
   55fd6:	je     56018 <sqlite3VdbeExec+0x6b78>
   55fd8:	mov    rax,QWORD PTR [rdx]
   55fdb:	mov    rcx,QWORD PTR [r12]
   55fdf:	mov    ecx,DWORD PTR [rcx+0x2e8]
   55fe5:	cmp    ecx,DWORD PTR [rax+0x80]
   55feb:	jle    56013 <sqlite3VdbeExec+0x6b73>
   55fed:	cmp    BYTE PTR [rax+0xa],0x0
   55ff1:	je     56013 <sqlite3VdbeExec+0x6b73>
   55ff3:	mov    QWORD PTR [rsp+0xb0],rdi
   55ffb:	mov    rdi,rax
   55ffe:	mov    rsi,rcx
   56001:	call   56006 <sqlite3VdbeExec+0x6b66>
   56006:	mov    r13d,eax
   56009:	mov    rdi,QWORD PTR [rsp+0xb0]
   56011:	jmp    56016 <sqlite3VdbeExec+0x6b76>
   56013:	xor    r13d,r13d
   56016:	jmp    5601b <sqlite3VdbeExec+0x6b7b>
   56018:	xor    r13d,r13d
   5601b:	test   r13d,r13d
   5601e:	je     560bc <sqlite3VdbeExec+0x6c1c>
   56024:	mov    eax,r13d
   56027:	and    eax,0xff
   5602c:	cmp    eax,0x5
   5602f:	jne    5608c <sqlite3VdbeExec+0x6bec>
   56031:	mov    rbx,QWORD PTR [rsp+0xf0]
   56039:	mov    rax,rbp
   5603c:	sub    rax,rbx
   5603f:	movabs rdx,0x2aaaaaaaaaaaaaab
   56049:	imul   rdx
   5604c:	sar    rdx,0x2
   56050:	mov    rax,rdx
   56053:	shr    rax,0x3f
   56057:	add    rdx,rax
   5605a:	mov    rax,rdx
   5605d:	mov    DWORD PTR [rdi+0x30],eax
   56060:	mov    DWORD PTR [rdi+0x34],r13d
   56064:	mov    QWORD PTR [rsp+0xf0],rbx
   5606c:	mov    r12,r13
   5606f:	mov    r13d,DWORD PTR [rsp+0x320]
   56077:	mov    r15,QWORD PTR [rsp+0xd0]
   5607f:	mov    rbx,QWORD PTR [rsp+0xf8]
   56087:	jmp    659c6 <sqlite3VdbeExec+0x16526>
   5608c:	mov    rbx,QWORD PTR [rsp+0xf0]
   56094:	mov    QWORD PTR [rsp+0xf0],rbx
   5609c:	mov    QWORD PTR [rsp+0xe8],rbp
   560a4:	mov    rbp,r13
   560a7:	mov    r13,QWORD PTR [rsp+0xd0]
   560af:	mov    rbx,QWORD PTR [rsp+0xf8]
   560b7:	jmp    4f712 <sqlite3VdbeExec+0x272>
   560bc:	movzx  eax,WORD PTR [rdi+0xc8]
   560c3:	shl    rax,0x3a
   560c7:	shr    rax,0x3f
   560cb:	test   eax,eax
   560cd:	jne    560ef <sqlite3VdbeExec+0x6c4f>
   560cf:	mov    DWORD PTR [rsp+0x31c],r15d
   560d7:	mov    r12,QWORD PTR [rsp+0x108]
   560df:	mov    r15,r13
   560e2:	mov    r13,QWORD PTR [rsp+0x110]
   560ea:	jmp    56210 <sqlite3VdbeExec+0x6d70>
   560ef:	cmp    DWORD PTR [rbp+0x8],0x0
   560f3:	jne    56115 <sqlite3VdbeExec+0x6c75>
   560f5:	mov    DWORD PTR [rsp+0x31c],r15d
   560fd:	mov    r12,QWORD PTR [rsp+0x108]
   56105:	mov    r15,r13
   56108:	mov    r13,QWORD PTR [rsp+0x110]
   56110:	jmp    56210 <sqlite3VdbeExec+0x6d70>
   56115:	cmp    BYTE PTR [r14+0x65],0x0
   5611a:	je     56146 <sqlite3VdbeExec+0x6ca6>
   5611c:	cmp    DWORD PTR [r14+0xd4],0x1
   56124:	jg     56146 <sqlite3VdbeExec+0x6ca6>
   56126:	mov    DWORD PTR [rsp+0x31c],r15d
   5612e:	mov    r12,QWORD PTR [rsp+0x108]
   56136:	mov    r15,r13
   56139:	mov    r13,QWORD PTR [rsp+0x110]
   56141:	jmp    56210 <sqlite3VdbeExec+0x6d70>
   56146:	cmp    DWORD PTR [rdi+0x40],0x0
   5614a:	jne    5616e <sqlite3VdbeExec+0x6cce>
   5614c:	mov    eax,DWORD PTR [r14+0x2ec]
   56153:	add    eax,0x1
   56156:	mov    DWORD PTR [r14+0x2ec],eax
   5615d:	mov    eax,DWORD PTR [r14+0x2e8]
   56164:	add    eax,DWORD PTR [r14+0x2ec]
   5616b:	mov    DWORD PTR [rdi+0x40],eax
   5616e:	xor    eax,eax
   56170:	mov    ecx,DWORD PTR [rdi+0x40]
   56173:	sub    ecx,0x1
   56176:	mov    QWORD PTR [rsp+0xb0],rdi
   5617e:	mov    rdi,r14
   56181:	mov    rsi,rax
   56184:	mov    rdx,rcx
   56187:	call   5618c <sqlite3VdbeExec+0x6cec>
   5618c:	mov    r13d,eax
   5618f:	mov    rdi,QWORD PTR [rsp+0xb0]
   56197:	test   r13d,r13d
   5619a:	jne    561df <sqlite3VdbeExec+0x6d3f>
   5619c:	mov    eax,DWORD PTR [rdi+0x40]
   5619f:	mov    rcx,QWORD PTR [r12+0x8]
   561a4:	mov    rdx,QWORD PTR [r12+0x8]
   561a9:	mov    rsi,QWORD PTR [r12]
   561ad:	mov    QWORD PTR [rdx+0x8],rsi
   561b1:	mov    rcx,QWORD PTR [rcx]
   561b4:	cmp    eax,DWORD PTR [rcx+0x80]
   561ba:	jle    561d7 <sqlite3VdbeExec+0x6d37>
   561bc:	cmp    BYTE PTR [rcx+0xa],0x0
   561c0:	je     561d7 <sqlite3VdbeExec+0x6d37>
   561c2:	mov    rdi,rcx
   561c5:	mov    rsi,rax
   561c8:	call   561cd <sqlite3VdbeExec+0x6d2d>
   561cd:	mov    rdi,QWORD PTR [rsp+0xb0]
   561d5:	jmp    561d9 <sqlite3VdbeExec+0x6d39>
   561d7:	xor    eax,eax
   561d9:	mov    r12d,eax
   561dc:	mov    r13,r12
   561df:	mov    rax,QWORD PTR [r14+0x2f0]
   561e6:	mov    QWORD PTR [rdi+0x58],rax
   561ea:	mov    rax,QWORD PTR [r14+0x2f8]
   561f1:	mov    QWORD PTR [rdi+0x60],rax
   561f5:	mov    DWORD PTR [rsp+0x31c],r15d
   561fd:	mov    r12,QWORD PTR [rsp+0x108]
   56205:	mov    r15,r13
   56208:	mov    r13,QWORD PTR [rsp+0x110]
   56210:	test   r15d,r15d
   56213:	jne    563db <sqlite3VdbeExec+0x6f3b>
   56219:	cmp    WORD PTR [rbp+0x2],0x0
   5621e:	je     563db <sqlite3VdbeExec+0x6f3b>
   56224:	mov    eax,DWORD PTR [rsp+0x338]
   5622b:	cmp    eax,DWORD PTR [rbp+0xc]
   5622e:	jne    56241 <sqlite3VdbeExec+0x6da1>
   56230:	mov    rax,QWORD PTR [r12+r13*1+0x18]
   56235:	mov    eax,DWORD PTR [rax+0x4]
   56238:	cmp    eax,DWORD PTR [rbp+0x10]
   5623b:	je     563db <sqlite3VdbeExec+0x6f3b>
   56241:	mov    rax,QWORD PTR [rdi+0xa8]
   56248:	test   rax,rax
   5624b:	je     56268 <sqlite3VdbeExec+0x6dc8>
   5624d:	mov    QWORD PTR [rsp+0xb0],rdi
   56255:	mov    rdi,r14
   56258:	mov    rsi,rax
   5625b:	call   56260 <sqlite3VdbeExec+0x6dc0>
   56260:	mov    rdi,QWORD PTR [rsp+0xb0]
   56268:	lea    r12,[rip+0x0]        # 5626f <sqlite3VdbeExec+0x6dcf>
   5626f:	test   r12,r12
   56272:	jne    5627c <sqlite3VdbeExec+0x6ddc>
   56274:	xor    r12d,r12d
   56277:	mov    r15,r12
   5627a:	jmp    562eb <sqlite3VdbeExec+0x6e4b>
   5627c:	mov    QWORD PTR [rsp+0xb0],rdi
   56284:	mov    rdi,r12
   56287:	call   5628c <sqlite3VdbeExec+0x6dec>
   5628c:	lea    r13,[rax+0x1]
   56290:	mov    rdi,QWORD PTR [rsp+0xb0]
   56298:	test   r14,r14
   5629b:	je     562b5 <sqlite3VdbeExec+0x6e15>
   5629d:	mov    rdi,r14
   562a0:	mov    rsi,r13
   562a3:	call   562a8 <sqlite3VdbeExec+0x6e08>
   562a8:	mov    r15,rax
   562ab:	mov    rdi,QWORD PTR [rsp+0xb0]
   562b3:	jmp    562c8 <sqlite3VdbeExec+0x6e28>
   562b5:	mov    rdi,r13
   562b8:	call   562bd <sqlite3VdbeExec+0x6e1d>
   562bd:	mov    r15,rax
   562c0:	mov    rdi,QWORD PTR [rsp+0xb0]
   562c8:	test   r15,r15
   562cb:	je     562eb <sqlite3VdbeExec+0x6e4b>
   562cd:	mov    QWORD PTR [rsp+0xb0],rdi
   562d5:	mov    rdi,r15
   562d8:	mov    rsi,r12
   562db:	mov    rdx,r13
   562de:	call   562e3 <sqlite3VdbeExec+0x6e43>
   562e3:	mov    rdi,QWORD PTR [rsp+0xb0]
   562eb:	mov    QWORD PTR [rdi+0xa8],r15
   562f2:	mov    rax,QWORD PTR [r14+0x20]
   562f6:	movsxd rcx,DWORD PTR [rbp+0x4]
   562fa:	shl    rcx,0x5
   562fe:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   56303:	mov    eax,DWORD PTR [rax]
   56305:	cmp    eax,DWORD PTR [rsp+0x338]
   5630c:	je     563aa <sqlite3VdbeExec+0x6f0a>
   56312:	movsxd rax,DWORD PTR [rbp+0x4]
   56316:	test   eax,eax
   56318:	jl     56350 <sqlite3VdbeExec+0x6eb0>
   5631a:	mov    rcx,QWORD PTR [r14+0x20]
   5631e:	shl    rax,0x5
   56322:	mov    rax,QWORD PTR [rcx+rax*1+0x18]
   56327:	movzx  ecx,WORD PTR [rax+0x72]
   5632b:	or     ecx,0x8
   5632e:	mov    WORD PTR [rax+0x72],cx
   56332:	mov    rax,QWORD PTR [r14+0x20]
   56336:	mov    rax,QWORD PTR [rax+0x38]
   5633a:	movzx  ecx,WORD PTR [rax+0x72]
   5633e:	or     ecx,0x8
   56341:	mov    WORD PTR [rax+0x72],cx
   56345:	mov    eax,DWORD PTR [r14+0x2c]
   56349:	and    eax,0xffffffef
   5634c:	mov    DWORD PTR [r14+0x2c],eax
   56350:	cmp    DWORD PTR [r14+0x48],0x0
   56355:	jne    563aa <sqlite3VdbeExec+0x6f0a>
   56357:	xor    r12d,r12d
   5635a:	jmp    563a4 <sqlite3VdbeExec+0x6f04>
   5635c:	mov    rax,QWORD PTR [r14+0x20]
   56360:	mov    rcx,r12
   56363:	shl    rcx,0x5
   56367:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   5636c:	movzx  eax,WORD PTR [rax+0x72]
   56370:	and    eax,0x8
   56373:	cmp    eax,0x8
   56376:	jne    563a0 <sqlite3VdbeExec+0x6f00>
   56378:	mov    rax,QWORD PTR [r14+0x20]
   5637c:	mov    rcx,r12
   5637f:	shl    rcx,0x5
   56383:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   56388:	mov    QWORD PTR [rsp+0xb0],rdi
   56390:	mov    rdi,rax
   56393:	call   56398 <sqlite3VdbeExec+0x6ef8>
   56398:	mov    rdi,QWORD PTR [rsp+0xb0]
   563a0:	add    r12d,0x1
   563a4:	cmp    r12d,DWORD PTR [r14+0x28]
   563a8:	jl     5635c <sqlite3VdbeExec+0x6ebc>
   563aa:	movzx  eax,WORD PTR [rdi+0xc8]
   563b1:	and    rax,0xfffffffffffffffc
   563b5:	or     rax,0x1
   563b9:	mov    WORD PTR [rdi+0xc8],ax
   563c0:	mov    r12d,0x11
   563c6:	movzx  eax,WORD PTR [rdi+0xc8]
   563cd:	and    rax,0xffffffffffffffef
   563d1:	mov    WORD PTR [rdi+0xc8],ax
   563d8:	mov    r15,r12
   563db:	test   r15d,r15d
   563de:	je     56400 <sqlite3VdbeExec+0x6f60>
   563e0:	mov    QWORD PTR [rsp+0xe8],rbp
   563e8:	mov    rbp,r15
   563eb:	mov    r13,QWORD PTR [rsp+0xd0]
   563f3:	mov    rbx,QWORD PTR [rsp+0xf8]
   563fb:	jmp    4f712 <sqlite3VdbeExec+0x272>
   56400:	mov    DWORD PTR [rsp+0x32c],r15d
   56408:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5640d:	mov    r15d,DWORD PTR [rsp+0x31c]
   56415:	mov    r13,QWORD PTR [rsp+0xf0]
   5641d:	mov    QWORD PTR [rsp+0xd0],r12
   56425:	mov    r12d,DWORD PTR [rsp+0x334]
   5642d:	movsxd rax,DWORD PTR [rbp+0x4]
   56431:	mov    ecx,DWORD PTR [rbp+0xc]
   56434:	mov    rdx,QWORD PTR [r14+0x20]
   56438:	shl    rax,0x5
   5643c:	mov    rax,QWORD PTR [rdx+rax*1+0x8]
   56441:	mov    rdx,QWORD PTR [rax+0x8]
   56445:	mov    rsi,QWORD PTR [rax+0x8]
   56449:	mov    r8,QWORD PTR [rax]
   5644c:	mov    QWORD PTR [rsi+0x8],r8
   56450:	cmp    ecx,0xf
   56453:	jne    5646a <sqlite3VdbeExec+0x6fca>
   56455:	mov    rcx,QWORD PTR [rdx]
   56458:	mov    ecx,DWORD PTR [rcx+0x84]
   5645e:	add    ecx,DWORD PTR [rax+0x1c]
   56461:	mov    DWORD PTR [rsp+0x338],ecx
   56468:	jmp    564a4 <sqlite3VdbeExec+0x7004>
   5646a:	mov    rax,QWORD PTR [rdx+0x18]
   5646e:	mov    rax,QWORD PTR [rax+0x50]
   56472:	shl    ecx,0x2
   56475:	add    ecx,0x24
   56478:	movsxd rcx,ecx
   5647b:	movzx  edx,BYTE PTR [rax+rcx*1]
   5647f:	shl    edx,0x18
   56482:	movzx  esi,BYTE PTR [rax+rcx*1+0x1]
   56487:	shl    esi,0x10
   5648a:	or     edx,esi
   5648c:	movzx  esi,BYTE PTR [rax+rcx*1+0x2]
   56491:	shl    esi,0x8
   56494:	or     edx,esi
   56496:	movzx  eax,BYTE PTR [rax+rcx*1+0x3]
   5649b:	or     edx,eax
   5649d:	mov    DWORD PTR [rsp+0x338],edx
   564a4:	mov    rax,QWORD PTR [rdi+0x68]
   564a8:	movsxd rcx,DWORD PTR [rbp+0x8]
   564ac:	imul   rcx,rcx,0x38
   564b0:	lea    rdx,[rax+rcx*1]
   564b4:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   564b9:	and    eax,0x9000
   564be:	test   eax,eax
   564c0:	je     564df <sqlite3VdbeExec+0x703f>
   564c2:	mov    QWORD PTR [rsp+0xb0],rdi
   564ca:	mov    rdi,rdx
   564cd:	call   564d2 <sqlite3VdbeExec+0x7032>
   564d2:	mov    rdi,QWORD PTR [rsp+0xb0]
   564da:	mov    rdx,rax
   564dd:	jmp    564e5 <sqlite3VdbeExec+0x7045>
   564df:	mov    WORD PTR [rdx+0x14],0x4
   564e5:	movsxd rax,DWORD PTR [rsp+0x338]
   564ed:	mov    QWORD PTR [rdx],rax
   564f0:	mov    DWORD PTR [rsp+0x31c],r15d
   564f8:	mov    QWORD PTR [rsp+0xf0],r13
   56500:	mov    DWORD PTR [rsp+0x334],r12d
   56508:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5650d:	mov    r15d,DWORD PTR [rsp+0x31c]
   56515:	mov    r13,QWORD PTR [rsp+0xf0]
   5651d:	mov    QWORD PTR [rsp+0xd0],r12
   56525:	mov    r12d,DWORD PTR [rsp+0x334]
   5652d:	mov    DWORD PTR [rsp+0x334],r12d
   56535:	mov    r12,QWORD PTR [r14+0x20]
   56539:	movsxd rax,DWORD PTR [rbp+0x4]
   5653d:	mov    QWORD PTR [rsp+0xf0],r13
   56545:	mov    r13,rax
   56548:	shl    r13,0x5
   5654c:	mov    rax,QWORD PTR [r12+r13*1+0x8]
   56551:	mov    ecx,DWORD PTR [rbp+0x8]
   56554:	mov    edx,DWORD PTR [rbp+0xc]
   56557:	mov    DWORD PTR [rsp+0x31c],r15d
   5655f:	mov    QWORD PTR [rsp+0xb0],rdi
   56567:	mov    rdi,rax
   5656a:	mov    rsi,rcx
   5656d:	call   56572 <sqlite3VdbeExec+0x70d2>
   56572:	mov    r15d,eax
   56575:	mov    rdi,QWORD PTR [rsp+0xb0]
   5657d:	cmp    DWORD PTR [rbp+0x8],0x1
   56581:	jne    567b9 <sqlite3VdbeExec+0x7319>
   56587:	mov    rax,QWORD PTR [r12+r13*1+0x18]
   5658c:	mov    ecx,DWORD PTR [rbp+0xc]
   5658f:	movzx  edx,WORD PTR [rbp+0x2]
   56593:	sub    ecx,edx
   56595:	mov    DWORD PTR [rax],ecx
   56597:	mov    eax,DWORD PTR [r14+0x2c]
   5659b:	or     eax,0x1
   5659e:	mov    DWORD PTR [r14+0x2c],eax
   565a2:	movsxd rax,DWORD PTR [rbp+0x4]
   565a6:	mov    rcx,QWORD PTR [r14+0x20]
   565aa:	shl    rax,0x5
   565ae:	mov    rax,QWORD PTR [rcx+rax*1+0x18]
   565b3:	mov    r12,QWORD PTR [rax+0x10]
   565b7:	mov    r13,r12
   565ba:	jmp    567a4 <sqlite3VdbeExec+0x7304>
   565bf:	mov    DWORD PTR [rsp+0x338],r15d
   565c7:	mov    r15,QWORD PTR [r12+0x30]
   565cc:	test   r15,r15
   565cf:	jne    565de <sqlite3VdbeExec+0x713e>
   565d1:	mov    QWORD PTR [rsp+0x110],r13
   565d9:	jmp    566a4 <sqlite3VdbeExec+0x7204>
   565de:	mov    QWORD PTR [rsp+0x110],r13
   565e6:	mov    r13,QWORD PTR [r15+0x38]
   565ea:	mov    rax,QWORD PTR [r13+0x18]
   565ee:	mov    QWORD PTR [rsp+0xb0],rdi
   565f6:	mov    rdi,r14
   565f9:	mov    rsi,rax
   565fc:	call   56601 <sqlite3VdbeExec+0x7161>
   56601:	mov    rax,QWORD PTR [r13+0x20]
   56605:	mov    rdi,QWORD PTR [rsp+0xb0]
   5660d:	test   rax,rax
   56610:	je     56625 <sqlite3VdbeExec+0x7185>
   56612:	mov    rdi,r14
   56615:	mov    rsi,rax
   56618:	call   5661d <sqlite3VdbeExec+0x717d>
   5661d:	mov    rdi,QWORD PTR [rsp+0xb0]
   56625:	mov    rax,QWORD PTR [r13+0x28]
   56629:	test   rax,rax
   5662c:	je     56649 <sqlite3VdbeExec+0x71a9>
   5662e:	mov    QWORD PTR [rsp+0xb0],rdi
   56636:	mov    rdi,r14
   56639:	mov    rsi,rax
   5663c:	call   56641 <sqlite3VdbeExec+0x71a1>
   56641:	mov    rdi,QWORD PTR [rsp+0xb0]
   56649:	mov    rax,QWORD PTR [r13+0x10]
   5664d:	mov    QWORD PTR [rsp+0xb0],rdi
   56655:	mov    rdi,r14
   56658:	mov    rsi,rax
   5665b:	call   56660 <sqlite3VdbeExec+0x71c0>
   56660:	mov    rax,QWORD PTR [r15+0x18]
   56664:	mov    rdi,QWORD PTR [rsp+0xb0]
   5666c:	test   rax,rax
   5666f:	je     56684 <sqlite3VdbeExec+0x71e4>
   56671:	mov    rdi,r14
   56674:	mov    rsi,rax
   56677:	call   5667c <sqlite3VdbeExec+0x71dc>
   5667c:	mov    rdi,QWORD PTR [rsp+0xb0]
   56684:	test   r15,r15
   56687:	je     566a4 <sqlite3VdbeExec+0x7204>
   56689:	mov    QWORD PTR [rsp+0xb0],rdi
   56691:	mov    rdi,r14
   56694:	mov    rsi,r15
   56697:	call   5669c <sqlite3VdbeExec+0x71fc>
   5669c:	mov    rdi,QWORD PTR [rsp+0xb0]
   566a4:	mov    QWORD PTR [r12+0x30],0x0
   566ad:	mov    r13,QWORD PTR [r12+0x38]
   566b2:	test   r13,r13
   566b5:	je     56779 <sqlite3VdbeExec+0x72d9>
   566bb:	mov    r15,QWORD PTR [r13+0x38]
   566bf:	mov    rax,QWORD PTR [r15+0x18]
   566c3:	mov    QWORD PTR [rsp+0xb0],rdi
   566cb:	mov    rdi,r14
   566ce:	mov    rsi,rax
   566d1:	call   566d6 <sqlite3VdbeExec+0x7236>
   566d6:	mov    rax,QWORD PTR [r15+0x20]
   566da:	mov    rdi,QWORD PTR [rsp+0xb0]
   566e2:	test   rax,rax
   566e5:	je     566fa <sqlite3VdbeExec+0x725a>
   566e7:	mov    rdi,r14
   566ea:	mov    rsi,rax
   566ed:	call   566f2 <sqlite3VdbeExec+0x7252>
   566f2:	mov    rdi,QWORD PTR [rsp+0xb0]
   566fa:	mov    rax,QWORD PTR [r15+0x28]
   566fe:	test   rax,rax
   56701:	je     5671e <sqlite3VdbeExec+0x727e>
   56703:	mov    QWORD PTR [rsp+0xb0],rdi
   5670b:	mov    rdi,r14
   5670e:	mov    rsi,rax
   56711:	call   56716 <sqlite3VdbeExec+0x7276>
   56716:	mov    rdi,QWORD PTR [rsp+0xb0]
   5671e:	mov    rax,QWORD PTR [r15+0x10]
   56722:	mov    QWORD PTR [rsp+0xb0],rdi
   5672a:	mov    rdi,r14
   5672d:	mov    rsi,rax
   56730:	call   56735 <sqlite3VdbeExec+0x7295>
   56735:	mov    rax,QWORD PTR [r13+0x18]
   56739:	mov    rdi,QWORD PTR [rsp+0xb0]
   56741:	test   rax,rax
   56744:	je     56759 <sqlite3VdbeExec+0x72b9>
   56746:	mov    rdi,r14
   56749:	mov    rsi,rax
   5674c:	call   56751 <sqlite3VdbeExec+0x72b1>
   56751:	mov    rdi,QWORD PTR [rsp+0xb0]
   56759:	test   r13,r13
   5675c:	je     56779 <sqlite3VdbeExec+0x72d9>
   5675e:	mov    QWORD PTR [rsp+0xb0],rdi
   56766:	mov    rdi,r14
   56769:	mov    rsi,r13
   5676c:	call   56771 <sqlite3VdbeExec+0x72d1>
   56771:	mov    rdi,QWORD PTR [rsp+0xb0]
   56779:	mov    QWORD PTR [r12+0x38],0x0
   56782:	mov    r12,QWORD PTR [r12+0x8]
   56787:	mov    r15d,DWORD PTR [rsp+0x338]
   5678f:	mov    r13,QWORD PTR [rsp+0x110]
   56797:	test   r12,r12
   5679a:	jne    565bf <sqlite3VdbeExec+0x711f>
   567a0:	mov    r13,QWORD PTR [r13+0x0]
   567a4:	test   r13,r13
   567a7:	je     567ca <sqlite3VdbeExec+0x732a>
   567a9:	mov    rax,QWORD PTR [r13+0x10]
   567ad:	cmp    BYTE PTR [rax+0x3f],0x0
   567b1:	jne    567a0 <sqlite3VdbeExec+0x7300>
   567b3:	mov    r12,QWORD PTR [rax+0x48]
   567b7:	jmp    56797 <sqlite3VdbeExec+0x72f7>
   567b9:	cmp    DWORD PTR [rbp+0x8],0x2
   567bd:	jne    567ca <sqlite3VdbeExec+0x732a>
   567bf:	mov    rax,QWORD PTR [r12+r13*1+0x18]
   567c4:	mov    ecx,DWORD PTR [rbp+0xc]
   567c7:	mov    BYTE PTR [rax+0x70],cl
   567ca:	cmp    DWORD PTR [rbp+0x4],0x1
   567ce:	jne    56807 <sqlite3VdbeExec+0x7367>
   567d0:	mov    rax,QWORD PTR [r14+0x8]
   567d4:	jmp    567f0 <sqlite3VdbeExec+0x7350>
   567d6:	movzx  ecx,WORD PTR [rax+0xc8]
   567dd:	and    rcx,0xfffffffffffffffc
   567e1:	or     rcx,0x1
   567e5:	mov    WORD PTR [rax+0xc8],cx
   567ec:	mov    rax,QWORD PTR [rax+0x10]
   567f0:	test   rax,rax
   567f3:	jne    567d6 <sqlite3VdbeExec+0x7336>
   567f5:	movzx  eax,WORD PTR [rdi+0xc8]
   567fc:	and    rax,0xfffffffffffffffc
   56800:	mov    WORD PTR [rdi+0xc8],ax
   56807:	test   r15d,r15d
   5680a:	je     5682c <sqlite3VdbeExec+0x738c>
   5680c:	mov    QWORD PTR [rsp+0xe8],rbp
   56814:	mov    rbp,r15
   56817:	mov    r13,QWORD PTR [rsp+0xd0]
   5681f:	mov    rbx,QWORD PTR [rsp+0xf8]
   56827:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5682c:	mov    DWORD PTR [rsp+0x32c],r15d
   56834:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   56839:	mov    r15d,DWORD PTR [rsp+0x31c]
   56841:	mov    r13,QWORD PTR [rsp+0xf0]
   56849:	mov    QWORD PTR [rsp+0xd0],r12
   56851:	mov    r12d,DWORD PTR [rsp+0x334]
   56859:	mov    rax,QWORD PTR [rdi+0x78]
   5685d:	movsxd rcx,DWORD PTR [rbp+0x4]
   56861:	mov    DWORD PTR [rsp+0x334],r12d
   56869:	mov    r12,QWORD PTR [rax+rcx*8]
   5686d:	test   r12,r12
   56870:	je     5696b <sqlite3VdbeExec+0x74cb>
   56876:	mov    eax,DWORD PTR [r12+0x3c]
   5687b:	cmp    eax,DWORD PTR [rbp+0x8]
   5687e:	jne    5696b <sqlite3VdbeExec+0x74cb>
   56884:	mov    QWORD PTR [rsp+0x110],r12
   5688c:	mov    r12,QWORD PTR [r12+0x28]
   56891:	mov    QWORD PTR [rsp+0x108],r12
   56899:	mov    r12,QWORD PTR [r12+0x18]
   5689e:	test   r12,r12
   568a1:	je     56928 <sqlite3VdbeExec+0x7488>
   568a7:	cmp    DWORD PTR [rip+0x0],0x0        # 568ae <sqlite3VdbeExec+0x740e>
   568ae:	je     56908 <sqlite3VdbeExec+0x7468>
   568b0:	mov    rax,QWORD PTR [rip+0x0]        # 568b7 <sqlite3VdbeExec+0x7417>
   568b7:	mov    QWORD PTR [rsp+0xb0],rdi
   568bf:	mov    rdi,r12
   568c2:	mov    r10,rax
   568c5:	call   r10
   568c8:	mov    rcx,QWORD PTR [rip+0x0]        # 568cf <sqlite3VdbeExec+0x742f>
   568cf:	movsxd rax,eax
   568d2:	sub    rcx,rax
   568d5:	mov    QWORD PTR [rip+0x0],rcx        # 568dc <sqlite3VdbeExec+0x743c>
   568dc:	mov    rax,QWORD PTR [rip+0x0]        # 568e3 <sqlite3VdbeExec+0x7443>
   568e3:	sub    rax,0x1
   568e7:	mov    QWORD PTR [rip+0x0],rax        # 568ee <sqlite3VdbeExec+0x744e>
   568ee:	mov    rax,QWORD PTR [rip+0x0]        # 568f5 <sqlite3VdbeExec+0x7455>
   568f5:	mov    rdi,r12
   568f8:	mov    r10,rax
   568fb:	call   r10
   568fe:	mov    rdi,QWORD PTR [rsp+0xb0]
   56906:	jmp    56928 <sqlite3VdbeExec+0x7488>
   56908:	mov    rax,QWORD PTR [rip+0x0]        # 5690f <sqlite3VdbeExec+0x746f>
   5690f:	mov    QWORD PTR [rsp+0xb0],rdi
   56917:	mov    rdi,r12
   5691a:	mov    r10,rax
   5691d:	call   r10
   56920:	mov    rdi,QWORD PTR [rsp+0xb0]
   56928:	mov    r12,QWORD PTR [rsp+0x108]
   56930:	mov    QWORD PTR [r12+0x18],0x0
   56939:	mov    BYTE PTR [r12],0x1
   5693e:	mov    DWORD PTR [rsp+0x31c],r15d
   56946:	mov    QWORD PTR [rsp+0xf0],r13
   5694e:	mov    QWORD PTR [rsp+0x100],rbx
   56956:	mov    r12d,DWORD PTR [rsp+0x32c]
   5695e:	mov    r13,QWORD PTR [rsp+0x110]
   56966:	jmp    56c75 <sqlite3VdbeExec+0x77d5>
   5696b:	movzx  eax,WORD PTR [rdi+0xc8]
   56972:	shl    rax,0x3e
   56976:	shr    rax,0x3e
   5697a:	cmp    eax,0x1
   5697d:	jne    569ac <sqlite3VdbeExec+0x750c>
   5697f:	mov    ebx,0x204
   56984:	mov    QWORD PTR [rsp+0xf0],r13
   5698c:	mov    QWORD PTR [rsp+0xe8],rbp
   56994:	mov    rbp,rbx
   56997:	mov    r13,QWORD PTR [rsp+0xd0]
   5699f:	mov    rbx,QWORD PTR [rsp+0xf8]
   569a7:	jmp    4f712 <sqlite3VdbeExec+0x272>
   569ac:	mov    r12d,DWORD PTR [rbp+0x8]
   569b0:	mov    QWORD PTR [rsp+0xf0],r13
   569b8:	movsxd r13,DWORD PTR [rbp+0xc]
   569bc:	mov    rax,QWORD PTR [r14+0x20]
   569c0:	mov    rcx,r13
   569c3:	shl    rcx,0x5
   569c7:	mov    QWORD PTR [rsp+0x110],r13
   569cf:	mov    r13,QWORD PTR [rax+rcx*1+0x8]
   569d4:	cmp    BYTE PTR [rbp+0x0],0x74
   569d8:	jne    56aec <sqlite3VdbeExec+0x764c>
   569de:	movzx  edx,WORD PTR [rbp+0x2]
   569e2:	and    edx,0x8
   569e5:	mov    QWORD PTR [rsp+0x108],r13
   569ed:	mov    r13d,edx
   569f0:	or     r13d,0x4
   569f4:	mov    rdx,QWORD PTR [rax+rcx*1+0x18]
   569f9:	movzx  edx,BYTE PTR [rdx+0x70]
   569fd:	movzx  esi,BYTE PTR [rdi+0xc5]
   56a04:	cmp    edx,esi
   56a06:	jge    56a17 <sqlite3VdbeExec+0x7577>
   56a08:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   56a0d:	movzx  eax,BYTE PTR [rax+0x70]
   56a11:	mov    BYTE PTR [rdi+0xc5],al
   56a17:	movzx  eax,WORD PTR [rbp+0x2]
   56a1b:	and    eax,0x10
   56a1e:	test   eax,eax
   56a20:	je     56aea <sqlite3VdbeExec+0x764a>
   56a26:	mov    rax,r12
   56a29:	imul   rax,rax,0x38
   56a2d:	lea    r12,[rbx+rax*1]
   56a31:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   56a36:	mov    ecx,eax
   56a38:	and    ecx,0x24
   56a3b:	test   ecx,ecx
   56a3d:	je     56a48 <sqlite3VdbeExec+0x75a8>
   56a3f:	mov    rax,QWORD PTR [r12]
   56a43:	jmp    56acb <sqlite3VdbeExec+0x762b>
   56a48:	mov    ecx,eax
   56a4a:	and    ecx,0x8
   56a4d:	test   ecx,ecx
   56a4f:	je     56aa0 <sqlite3VdbeExec+0x7600>
   56a51:	movsd  xmm1,QWORD PTR [r12]
   56a57:	movabs r11,0xc3dfffffffffffff
   56a61:	movq   xmm0,r11
   56a66:	ucomisd xmm0,xmm1
   56a6a:	jbe    56a78 <sqlite3VdbeExec+0x75d8>
   56a6c:	movabs rax,0x8000000000000000
   56a76:	jmp    56a9e <sqlite3VdbeExec+0x75fe>
   56a78:	movabs r11,0x43dfffffffffffff
   56a82:	movq   xmm0,r11
   56a87:	ucomisd xmm1,xmm0
   56a8b:	jbe    56a99 <sqlite3VdbeExec+0x75f9>
   56a8d:	movabs rax,0x7fffffffffffffff
   56a97:	jmp    56a9e <sqlite3VdbeExec+0x75fe>
   56a99:	cvttsd2si rax,xmm1
   56a9e:	jmp    56acb <sqlite3VdbeExec+0x762b>
   56aa0:	and    eax,0x12
   56aa3:	test   eax,eax
   56aa5:	je     56ac9 <sqlite3VdbeExec+0x7629>
   56aa7:	cmp    QWORD PTR [r12+0x8],0x0
   56aad:	je     56ac9 <sqlite3VdbeExec+0x7629>
   56aaf:	mov    QWORD PTR [rsp+0xb0],rdi
   56ab7:	mov    rdi,r12
   56aba:	call   56abf <sqlite3VdbeExec+0x761f>
   56abf:	mov    rdi,QWORD PTR [rsp+0xb0]
   56ac7:	jmp    56acb <sqlite3VdbeExec+0x762b>
   56ac9:	xor    eax,eax
   56acb:	mov    QWORD PTR [r12],rax
   56acf:	movzx  eax,WORD PTR [r12+0x14]
   56ad5:	and    eax,0xfffff240
   56ada:	or     eax,0x4
   56add:	mov    WORD PTR [r12+0x14],ax
   56ae3:	mov    rax,QWORD PTR [r12]
   56ae7:	mov    r12d,eax
   56aea:	jmp    56af7 <sqlite3VdbeExec+0x7657>
   56aec:	mov    QWORD PTR [rsp+0x108],r13
   56af4:	xor    r13d,r13d
   56af7:	cmp    BYTE PTR [rbp+0x1],0xf7
   56afb:	jne    56b1b <sqlite3VdbeExec+0x767b>
   56afd:	mov    DWORD PTR [rsp+0x338],r13d
   56b05:	mov    r13,QWORD PTR [rbp+0x10]
   56b09:	movzx  eax,WORD PTR [r13+0x8]
   56b0e:	mov    QWORD PTR [rsp+0x118],r13
   56b16:	mov    r13d,eax
   56b19:	jmp    56b48 <sqlite3VdbeExec+0x76a8>
   56b1b:	mov    DWORD PTR [rsp+0x338],r13d
   56b23:	cmp    BYTE PTR [rbp+0x1],0xfd
   56b27:	je     56b39 <sqlite3VdbeExec+0x7699>
   56b29:	xor    r13d,r13d
   56b2c:	xor    r11d,r11d
   56b2f:	mov    QWORD PTR [rsp+0x118],r11
   56b37:	jmp    56b48 <sqlite3VdbeExec+0x76a8>
   56b39:	mov    r13d,DWORD PTR [rbp+0x10]
   56b3d:	xor    r11d,r11d
   56b40:	mov    QWORD PTR [rsp+0x118],r11
   56b48:	mov    eax,DWORD PTR [rbp+0x4]
   56b4b:	xor    ecx,ecx
   56b4d:	mov    QWORD PTR [rsp+0xb0],rdi
   56b55:	mov    rsi,rax
   56b58:	mov    rdx,r13
   56b5b:	call   56b60 <sqlite3VdbeExec+0x76c0>
   56b60:	mov    r13,rax
   56b63:	mov    rdi,QWORD PTR [rsp+0xb0]
   56b6b:	test   r13,r13
   56b6e:	jne    56b88 <sqlite3VdbeExec+0x76e8>
   56b70:	mov    r13,QWORD PTR [rsp+0xf0]
   56b78:	mov    rbx,rbp
   56b7b:	mov    rbp,QWORD PTR [rsp+0xf8]
   56b83:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   56b88:	mov    DWORD PTR [rsp+0x31c],r15d
   56b90:	mov    r15,QWORD PTR [rsp+0x110]
   56b98:	mov    BYTE PTR [r13+0x1],r15b
   56b9c:	mov    BYTE PTR [r13+0x2],0x1
   56ba1:	movzx  eax,BYTE PTR [r13+0x5]
   56ba6:	and    rax,0xfffffffffffffffb
   56baa:	or     rax,0x4
   56bae:	mov    BYTE PTR [r13+0x5],al
   56bb2:	mov    DWORD PTR [r13+0x3c],r12d
   56bb6:	mov    rax,QWORD PTR [r13+0x28]
   56bba:	mov    r15,QWORD PTR [rsp+0x108]
   56bc2:	cmp    BYTE PTR [r15+0x11],0x0
   56bc7:	je     56c1d <sqlite3VdbeExec+0x777d>
   56bc9:	mov    rcx,QWORD PTR [r15+0x8]
   56bcd:	mov    rdx,QWORD PTR [r15]
   56bd0:	mov    QWORD PTR [rcx+0x8],rdx
   56bd4:	mov    QWORD PTR [rsp+0x128],r13
   56bdc:	mov    QWORD PTR [rsp+0x100],rbx
   56be4:	mov    r13d,DWORD PTR [rsp+0x338]
   56bec:	mov    rbx,QWORD PTR [rsp+0x118]
   56bf4:	mov    rdi,r15
   56bf7:	mov    rsi,r12
   56bfa:	mov    rdx,r13
   56bfd:	mov    rcx,rbx
   56c00:	mov    r8,rax
   56c03:	call   56c08 <sqlite3VdbeExec+0x7768>
   56c08:	mov    r12d,eax
   56c0b:	mov    rdi,QWORD PTR [rsp+0xb0]
   56c13:	mov    r13,QWORD PTR [rsp+0x128]
   56c1b:	jmp    56c64 <sqlite3VdbeExec+0x77c4>
   56c1d:	mov    QWORD PTR [rsp+0x128],r13
   56c25:	mov    r13d,DWORD PTR [rsp+0x338]
   56c2d:	mov    QWORD PTR [rsp+0x100],rbx
   56c35:	mov    rbx,QWORD PTR [rsp+0x118]
   56c3d:	mov    rdi,r15
   56c40:	mov    rsi,r12
   56c43:	mov    rdx,r13
   56c46:	mov    rcx,rbx
   56c49:	mov    r8,rax
   56c4c:	call   56c51 <sqlite3VdbeExec+0x77b1>
   56c51:	mov    r12d,eax
   56c54:	mov    rdi,QWORD PTR [rsp+0xb0]
   56c5c:	mov    r13,QWORD PTR [rsp+0x128]
   56c64:	mov    QWORD PTR [r13+0x30],rbx
   56c68:	xor    eax,eax
   56c6a:	cmp    BYTE PTR [rbp+0x1],0xf7
   56c6e:	setne  al
   56c71:	mov    BYTE PTR [r13+0x4],al
   56c75:	mov    rax,QWORD PTR [r13+0x28]
   56c79:	movzx  ecx,WORD PTR [rbp+0x2]
   56c7d:	and    ecx,0x3
   56c80:	mov    BYTE PTR [rax+0x3],cl
   56c83:	test   r12d,r12d
   56c86:	je     56ca8 <sqlite3VdbeExec+0x7808>
   56c88:	mov    QWORD PTR [rsp+0xe8],rbp
   56c90:	mov    rbp,r12
   56c93:	mov    r13,QWORD PTR [rsp+0xd0]
   56c9b:	mov    rbx,QWORD PTR [rsp+0xf8]
   56ca3:	jmp    4f712 <sqlite3VdbeExec+0x272>
   56ca8:	mov    DWORD PTR [rsp+0x32c],r12d
   56cb0:	mov    rbx,QWORD PTR [rsp+0x100]
   56cb8:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   56cbd:	mov    QWORD PTR [rsp+0x100],rbx
   56cc5:	mov    QWORD PTR [rsp+0xd0],r12
   56ccd:	mov    rax,QWORD PTR [rdi+0x78]
   56cd1:	movsxd rcx,DWORD PTR [rbp+0x8]
   56cd5:	mov    r12,QWORD PTR [rax+rcx*8]
   56cd9:	mov    eax,DWORD PTR [rbp+0x4]
   56cdc:	movsx  ecx,WORD PTR [r12+0x40]
   56ce2:	xor    edx,edx
   56ce4:	mov    QWORD PTR [rsp+0xb0],rdi
   56cec:	mov    rsi,rax
   56cef:	mov    r11,rdx
   56cf2:	mov    rdx,rcx
   56cf5:	mov    rcx,r11
   56cf8:	call   56cfd <sqlite3VdbeExec+0x785d>
   56cfd:	mov    rdi,QWORD PTR [rsp+0xb0]
   56d05:	test   rax,rax
   56d08:	jne    56d22 <sqlite3VdbeExec+0x7882>
   56d0a:	mov    r13,QWORD PTR [rsp+0xf0]
   56d12:	mov    rbx,rbp
   56d15:	mov    rbp,QWORD PTR [rsp+0xf8]
   56d1d:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   56d22:	mov    BYTE PTR [rax+0x2],0x1
   56d26:	movzx  ecx,BYTE PTR [rax+0x5]
   56d2a:	and    rcx,0xfffffffffffffffe
   56d2e:	or     rcx,0x1
   56d32:	mov    BYTE PTR [rax+0x5],cl
   56d35:	mov    rcx,QWORD PTR [r12+0x30]
   56d3a:	mov    QWORD PTR [rax+0x30],rcx
   56d3e:	movzx  ecx,BYTE PTR [r12+0x4]
   56d44:	mov    BYTE PTR [rax+0x4],cl
   56d47:	mov    ecx,DWORD PTR [r12+0x3c]
   56d4c:	mov    DWORD PTR [rax+0x3c],ecx
   56d4f:	movzx  ecx,BYTE PTR [r12+0x5]
   56d55:	shl    rcx,0x3d
   56d59:	shr    rcx,0x3f
   56d5d:	and    rcx,0x1
   56d61:	movzx  edx,BYTE PTR [rax+0x5]
   56d65:	and    rdx,0xfffffffffffffffb
   56d69:	shl    rcx,0x2
   56d6d:	or     rdx,rcx
   56d70:	mov    BYTE PTR [rax+0x5],dl
   56d73:	mov    rcx,QWORD PTR [r12+0x8]
   56d78:	mov    QWORD PTR [rax+0x8],rcx
   56d7c:	movzx  ecx,BYTE PTR [rax+0x5]
   56d80:	and    rcx,0xfffffffffffffff7
   56d84:	or     rcx,0x8
   56d88:	mov    BYTE PTR [rax+0x5],cl
   56d8b:	movzx  ecx,BYTE PTR [r12+0x5]
   56d91:	and    rcx,0xfffffffffffffff7
   56d95:	or     rcx,0x8
   56d99:	mov    BYTE PTR [r12+0x5],cl
   56d9e:	mov    rcx,QWORD PTR [rax+0x8]
   56da2:	mov    edx,DWORD PTR [rax+0x3c]
   56da5:	mov    esi,0x4
   56daa:	mov    r8,QWORD PTR [rax+0x30]
   56dae:	mov    rax,QWORD PTR [rax+0x28]
   56db2:	cmp    BYTE PTR [rcx+0x11],0x0
   56db6:	je     56de7 <sqlite3VdbeExec+0x7947>
   56db8:	mov    r9,QWORD PTR [rcx+0x8]
   56dbc:	mov    r10,QWORD PTR [rcx]
   56dbf:	mov    QWORD PTR [r9+0x8],r10
   56dc3:	mov    rdi,rcx
   56dc6:	mov    rcx,r8
   56dc9:	mov    r8,rax
   56dcc:	mov    r11,rsi
   56dcf:	mov    rsi,rdx
   56dd2:	mov    rdx,r11
   56dd5:	call   56dda <sqlite3VdbeExec+0x793a>
   56dda:	mov    r12d,eax
   56ddd:	mov    rdi,QWORD PTR [rsp+0xb0]
   56de5:	jmp    56e09 <sqlite3VdbeExec+0x7969>
   56de7:	mov    rdi,rcx
   56dea:	mov    rcx,r8
   56ded:	mov    r8,rax
   56df0:	mov    r11,rsi
   56df3:	mov    rsi,rdx
   56df6:	mov    rdx,r11
   56df9:	call   56dfe <sqlite3VdbeExec+0x795e>
   56dfe:	mov    r12d,eax
   56e01:	mov    rdi,QWORD PTR [rsp+0xb0]
   56e09:	mov    DWORD PTR [rsp+0x32c],r12d
   56e11:	mov    rbx,QWORD PTR [rsp+0x100]
   56e19:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   56e1e:	mov    QWORD PTR [rsp+0x100],rbx
   56e26:	mov    QWORD PTR [rsp+0xd0],r12
   56e2e:	cmp    DWORD PTR [rbp+0xc],0x0
   56e32:	jg     56e3e <sqlite3VdbeExec+0x799e>
   56e34:	mov    r12,QWORD PTR [rsp+0x100]
   56e3c:	jmp    56e6b <sqlite3VdbeExec+0x79cb>
   56e3e:	movsxd rax,DWORD PTR [rbp+0xc]
   56e42:	imul   rax,rax,0x38
   56e46:	mov    r12,QWORD PTR [rsp+0x100]
   56e4e:	mov    DWORD PTR [r12+rax*1+0x10],0x0
   56e57:	movsxd rax,DWORD PTR [rbp+0xc]
   56e5b:	imul   rax,rax,0x38
   56e5f:	lea    rcx,[rip+0x0]        # 56e66 <sqlite3VdbeExec+0x79c6>
   56e66:	mov    QWORD PTR [r12+rax*1+0x8],rcx
   56e6b:	mov    rax,QWORD PTR [rdi+0x78]
   56e6f:	movsxd rcx,DWORD PTR [rbp+0x4]
   56e73:	mov    r13,QWORD PTR [rax+rcx*8]
   56e77:	test   r13,r13
   56e7a:	je     5700c <sqlite3VdbeExec+0x7b6c>
   56e80:	movzx  eax,BYTE PTR [r13+0x5]
   56e85:	shl    rax,0x3c
   56e89:	shr    rax,0x3f
   56e8d:	test   eax,eax
   56e8f:	jne    5700c <sqlite3VdbeExec+0x7b6c>
   56e95:	mov    eax,DWORD PTR [rbp+0x8]
   56e98:	movsx  ecx,WORD PTR [r13+0x40]
   56e9d:	cmp    eax,ecx
   56e9f:	jg     5700c <sqlite3VdbeExec+0x7b6c>
   56ea5:	mov    QWORD PTR [r13+0x10],0x0
   56ead:	mov    DWORD PTR [r13+0x18],0x0
   56eb5:	mov    r15,QWORD PTR [r13+0x8]
   56eb9:	mov    ebx,DWORD PTR [r13+0x3c]
   56ebd:	mov    DWORD PTR [rsp+0x338],ebx
   56ec4:	mov    rbx,QWORD PTR [r15+0x8]
   56ec8:	mov    rax,QWORD PTR [r15+0x8]
   56ecc:	mov    rcx,QWORD PTR [r15]
   56ecf:	mov    QWORD PTR [rax+0x8],rcx
   56ed3:	xor    eax,eax
   56ed5:	mov    rcx,QWORD PTR [rbx+0x10]
   56ed9:	jmp    56f39 <sqlite3VdbeExec+0x7a99>
   56edb:	test   rcx,rcx
   56ede:	jne    56ef1 <sqlite3VdbeExec+0x7a51>
   56ee0:	mov    QWORD PTR [rsp+0x118],rbx
   56ee8:	mov    ebx,DWORD PTR [rsp+0x338]
   56eef:	jmp    56f26 <sqlite3VdbeExec+0x7a86>
   56ef1:	xor    edx,edx
   56ef3:	mov    QWORD PTR [rsp+0x118],rbx
   56efb:	mov    ebx,DWORD PTR [rsp+0x338]
   56f02:	cmp    edx,ebx
   56f04:	jne    56f10 <sqlite3VdbeExec+0x7a70>
   56f06:	mov    rbx,QWORD PTR [rsp+0x118]
   56f0e:	jmp    56f3e <sqlite3VdbeExec+0x7a9e>
   56f10:	cmp    ebx,DWORD PTR [rcx+0x50]
   56f13:	jne    56f26 <sqlite3VdbeExec+0x7a86>
   56f15:	mov    DWORD PTR [rsp+0x338],ebx
   56f1c:	mov    rbx,QWORD PTR [rsp+0x118]
   56f24:	jmp    56f3e <sqlite3VdbeExec+0x7a9e>
   56f26:	mov    rcx,QWORD PTR [rcx+0x28]
   56f2a:	mov    DWORD PTR [rsp+0x338],ebx
   56f31:	mov    rbx,QWORD PTR [rsp+0x118]
   56f39:	test   rcx,rcx
   56f3c:	jne    56edb <sqlite3VdbeExec+0x7a3b>
   56f3e:	test   rcx,rcx
   56f41:	jne    56f54 <sqlite3VdbeExec+0x7ab4>
   56f43:	mov    QWORD PTR [rsp+0x118],rbx
   56f4b:	mov    ebx,DWORD PTR [rsp+0x338]
   56f52:	jmp    56f87 <sqlite3VdbeExec+0x7ae7>
   56f54:	mov    QWORD PTR [rsp+0x118],rbx
   56f5c:	mov    ebx,DWORD PTR [rsp+0x338]
   56f63:	mov    QWORD PTR [rsp+0xb0],rdi
   56f6b:	mov    rdi,rcx
   56f6e:	mov    rsi,rbx
   56f71:	mov    rdx,rax
   56f74:	call   56f79 <sqlite3VdbeExec+0x7ad9>
   56f79:	xor    ecx,ecx
   56f7b:	mov    rdi,QWORD PTR [rsp+0xb0]
   56f83:	cmp    ecx,eax
   56f85:	jne    56ffc <sqlite3VdbeExec+0x7b5c>
   56f87:	cmp    BYTE PTR [r15+0x13],0x0
   56f8c:	je     56fbe <sqlite3VdbeExec+0x7b1e>
   56f8e:	mov    BYTE PTR [r15+0x13],0x0
   56f93:	mov    rax,QWORD PTR [r15+0x8]
   56f97:	mov    rax,QWORD PTR [rax+0x10]
   56f9b:	jmp    56fb9 <sqlite3VdbeExec+0x7b19>
   56f9d:	movzx  ecx,BYTE PTR [rax+0x1]
   56fa1:	and    ecx,0x10
   56fa4:	test   ecx,ecx
   56fa6:	je     56fb5 <sqlite3VdbeExec+0x7b15>
   56fa8:	mov    BYTE PTR [r15+0x13],0x1
   56fad:	cmp    ebx,DWORD PTR [rax+0x50]
   56fb0:	jne    56fb5 <sqlite3VdbeExec+0x7b15>
   56fb2:	mov    BYTE PTR [rax],0x1
   56fb5:	mov    rax,QWORD PTR [rax+0x28]
   56fb9:	test   rax,rax
   56fbc:	jne    56f9d <sqlite3VdbeExec+0x7afd>
   56fbe:	xor    eax,eax
   56fc0:	mov    QWORD PTR [rsp+0x128],r13
   56fc8:	xor    r15d,r15d
   56fcb:	mov    r13,QWORD PTR [rsp+0x118]
   56fd3:	mov    QWORD PTR [rsp+0xb0],rdi
   56fdb:	mov    rdi,r13
   56fde:	mov    rsi,rbx
   56fe1:	mov    rdx,rax
   56fe4:	mov    rcx,r15
   56fe7:	call   56fec <sqlite3VdbeExec+0x7b4c>
   56fec:	mov    rdi,QWORD PTR [rsp+0xb0]
   56ff4:	mov    r13,QWORD PTR [rsp+0x128]
   56ffc:	mov    ebx,eax
   56ffe:	mov    r11,r13
   57001:	mov    r13,rbx
   57004:	mov    rbx,r11
   57007:	jmp    572b3 <sqlite3VdbeExec+0x7e13>
   5700c:	mov    eax,DWORD PTR [rbp+0x4]
   5700f:	mov    ecx,DWORD PTR [rbp+0x8]
   57012:	xor    edx,edx
   57014:	mov    QWORD PTR [rsp+0xb0],rdi
   5701c:	mov    rsi,rax
   5701f:	mov    r11,rdx
   57022:	mov    rdx,rcx
   57025:	mov    rcx,r11
   57028:	call   5702d <sqlite3VdbeExec+0x7b8d>
   5702d:	mov    rbx,rax
   57030:	mov    rdi,QWORD PTR [rsp+0xb0]
   57038:	test   rbx,rbx
   5703b:	jne    57055 <sqlite3VdbeExec+0x7bb5>
   5703d:	mov    r13,QWORD PTR [rsp+0xf0]
   57045:	mov    rbx,rbp
   57048:	mov    rbp,QWORD PTR [rsp+0xf8]
   57050:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   57055:	movzx  eax,BYTE PTR [rbx+0x5]
   57059:	and    rax,0xfffffffffffffffe
   5705d:	or     rax,0x1
   57061:	mov    BYTE PTR [rbx+0x5],al
   57064:	mov    rax,QWORD PTR [r14]
   57067:	xor    ecx,ecx
   57069:	lea    rdx,[rbx+0x8]
   5706d:	movzx  esi,WORD PTR [rbp+0x2]
   57071:	or     esi,0x5
   57074:	mov    r8d,DWORD PTR [rip+0x0]        # 5707b <sqlite3VdbeExec+0x7bdb>
   5707b:	mov    rdi,rax
   5707e:	mov    r9,r8
   57081:	mov    r8,rsi
   57084:	mov    rsi,rcx
   57087:	mov    rcx,rdx
   5708a:	mov    rdx,r14
   5708d:	call   57092 <sqlite3VdbeExec+0x7bf2>
   57092:	mov    r13d,eax
   57095:	mov    rdi,QWORD PTR [rsp+0xb0]
   5709d:	test   r13d,r13d
   570a0:	jne    572b3 <sqlite3VdbeExec+0x7e13>
   570a6:	mov    rax,QWORD PTR [rbx+0x8]
   570aa:	mov    ecx,0x1
   570af:	xor    edx,edx
   570b1:	cmp    BYTE PTR [rax+0x11],0x0
   570b5:	jne    570c7 <sqlite3VdbeExec+0x7c27>
   570b7:	cmp    BYTE PTR [rax+0x10],0x0
   570bb:	je     570c7 <sqlite3VdbeExec+0x7c27>
   570bd:	cmp    BYTE PTR [rax+0x10],0x1
   570c1:	jne    57174 <sqlite3VdbeExec+0x7cd4>
   570c7:	mov    QWORD PTR [rsp+0xb0],rdi
   570cf:	mov    rdi,rax
   570d2:	mov    rsi,rcx
   570d5:	call   570da <sqlite3VdbeExec+0x7c3a>
   570da:	mov    r13d,eax
   570dd:	mov    rdi,QWORD PTR [rsp+0xb0]
   570e5:	test   r13d,r13d
   570e8:	jne    57260 <sqlite3VdbeExec+0x7dc0>
   570ee:	mov    r13,QWORD PTR [rbp+0x10]
   570f2:	mov    QWORD PTR [rbx+0x30],r13
   570f6:	test   r13,r13
   570f9:	je     571e6 <sqlite3VdbeExec+0x7d46>
   570ff:	mov    rax,QWORD PTR [rbx+0x8]
   57103:	lea    rcx,[rbx+0x3c]
   57107:	movzx  edx,WORD PTR [rbp+0x2]
   5710b:	or     edx,0x2
   5710e:	mov    QWORD PTR [rsp+0xb0],rdi
   57116:	mov    rdi,rax
   57119:	mov    rsi,rcx
   5711c:	call   57121 <sqlite3VdbeExec+0x7c81>
   57121:	mov    r15d,eax
   57124:	mov    rdi,QWORD PTR [rsp+0xb0]
   5712c:	test   r15d,r15d
   5712f:	jne    571dd <sqlite3VdbeExec+0x7d3d>
   57135:	mov    rax,QWORD PTR [rbx+0x8]
   57139:	mov    ecx,DWORD PTR [rbx+0x3c]
   5713c:	mov    edx,0x4
   57141:	mov    rsi,QWORD PTR [rbx+0x28]
   57145:	cmp    BYTE PTR [rax+0x11],0x0
   57149:	je     571be <sqlite3VdbeExec+0x7d1e>
   5714b:	mov    r8,QWORD PTR [rax+0x8]
   5714f:	mov    r9,QWORD PTR [rax]
   57152:	mov    QWORD PTR [r8+0x8],r9
   57156:	mov    rdi,rax
   57159:	mov    r8,rsi
   5715c:	mov    rsi,rcx
   5715f:	mov    rcx,r13
   57162:	call   57167 <sqlite3VdbeExec+0x7cc7>
   57167:	mov    r13d,eax
   5716a:	mov    rdi,QWORD PTR [rsp+0xb0]
   57172:	jmp    571da <sqlite3VdbeExec+0x7d3a>
   57174:	mov    rcx,QWORD PTR [rax+0x8]
   57178:	mov    rcx,QWORD PTR [rcx]
   5717b:	mov    rax,QWORD PTR [rax]
   5717e:	mov    eax,DWORD PTR [rax+0x2e8]
   57184:	cmp    eax,DWORD PTR [rcx+0x80]
   5718a:	jle    570ee <sqlite3VdbeExec+0x7c4e>
   57190:	cmp    BYTE PTR [rcx+0xa],0x0
   57194:	je     570ee <sqlite3VdbeExec+0x7c4e>
   5719a:	mov    rdi,rcx
   5719d:	mov    rsi,rax
   571a0:	call   571a5 <sqlite3VdbeExec+0x7d05>
   571a5:	mov    r13d,eax
   571a8:	mov    rdi,QWORD PTR [rsp+0xb0]
   571b0:	test   r13d,r13d
   571b3:	je     570ee <sqlite3VdbeExec+0x7c4e>
   571b9:	jmp    57260 <sqlite3VdbeExec+0x7dc0>
   571be:	mov    rdi,rax
   571c1:	mov    r8,rsi
   571c4:	mov    rsi,rcx
   571c7:	mov    rcx,r13
   571ca:	call   571cf <sqlite3VdbeExec+0x7d2f>
   571cf:	mov    r13d,eax
   571d2:	mov    rdi,QWORD PTR [rsp+0xb0]
   571da:	mov    r15,r13
   571dd:	mov    BYTE PTR [rbx+0x4],0x0
   571e1:	mov    r13,r15
   571e4:	jmp    57260 <sqlite3VdbeExec+0x7dc0>
   571e6:	mov    DWORD PTR [rbx+0x3c],0x1
   571ed:	mov    rax,QWORD PTR [rbx+0x8]
   571f1:	mov    ecx,0x1
   571f6:	mov    edx,0x4
   571fb:	xor    esi,esi
   571fd:	mov    r8,QWORD PTR [rbx+0x28]
   57201:	cmp    BYTE PTR [rax+0x11],0x0
   57205:	je     57238 <sqlite3VdbeExec+0x7d98>
   57207:	mov    r9,QWORD PTR [rax+0x8]
   5720b:	mov    r10,QWORD PTR [rax]
   5720e:	mov    QWORD PTR [r9+0x8],r10
   57212:	mov    QWORD PTR [rsp+0xb0],rdi
   5721a:	mov    rdi,rax
   5721d:	mov    r11,rsi
   57220:	mov    rsi,rcx
   57223:	mov    rcx,r11
   57226:	call   5722b <sqlite3VdbeExec+0x7d8b>
   5722b:	mov    r13d,eax
   5722e:	mov    rdi,QWORD PTR [rsp+0xb0]
   57236:	jmp    5725c <sqlite3VdbeExec+0x7dbc>
   57238:	mov    QWORD PTR [rsp+0xb0],rdi
   57240:	mov    rdi,rax
   57243:	mov    r11,rsi
   57246:	mov    rsi,rcx
   57249:	mov    rcx,r11
   5724c:	call   57251 <sqlite3VdbeExec+0x7db1>
   57251:	mov    r13d,eax
   57254:	mov    rdi,QWORD PTR [rsp+0xb0]
   5725c:	mov    BYTE PTR [rbx+0x4],0x1
   57260:	xor    eax,eax
   57262:	cmp    WORD PTR [rbp+0x2],0x8
   57267:	setne  al
   5726a:	and    rax,0x1
   5726e:	movzx  ecx,BYTE PTR [rbx+0x5]
   57272:	and    rcx,0xfffffffffffffffb
   57276:	shl    rax,0x2
   5727a:	or     rcx,rax
   5727d:	mov    BYTE PTR [rbx+0x5],cl
   57280:	test   r13d,r13d
   57283:	je     572b3 <sqlite3VdbeExec+0x7e13>
   57285:	mov    rax,QWORD PTR [rbx+0x8]
   57289:	mov    QWORD PTR [rsp+0xb0],rdi
   57291:	mov    rdi,rax
   57294:	call   57299 <sqlite3VdbeExec+0x7df9>
   57299:	mov    rdi,QWORD PTR [rsp+0xb0]
   572a1:	mov    rax,QWORD PTR [rdi+0x78]
   572a5:	movsxd rcx,DWORD PTR [rbp+0x4]
   572a9:	mov    QWORD PTR [rax+rcx*8],0x0
   572b1:	jmp    572b3 <sqlite3VdbeExec+0x7e13>
   572b3:	test   r13d,r13d
   572b6:	je     572d8 <sqlite3VdbeExec+0x7e38>
   572b8:	mov    QWORD PTR [rsp+0xe8],rbp
   572c0:	mov    rbp,r13
   572c3:	mov    r13,QWORD PTR [rsp+0xd0]
   572cb:	mov    rbx,QWORD PTR [rsp+0xf8]
   572d3:	jmp    4f712 <sqlite3VdbeExec+0x272>
   572d8:	mov    BYTE PTR [rbx+0x2],0x1
   572dc:	mov    DWORD PTR [rsp+0x32c],r13d
   572e4:	mov    rbx,r12
   572e7:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   572ec:	mov    QWORD PTR [rsp+0xd0],r12
   572f4:	mov    r12,rbx
   572f7:	mov    eax,DWORD PTR [rbp+0x4]
   572fa:	mov    ecx,DWORD PTR [rbp+0x8]
   572fd:	mov    edx,0x1
   57302:	mov    QWORD PTR [rsp+0xb0],rdi
   5730a:	mov    rsi,rax
   5730d:	mov    r11,rdx
   57310:	mov    rdx,rcx
   57313:	mov    rcx,r11
   57316:	call   5731b <sqlite3VdbeExec+0x7e7b>
   5731b:	mov    rbx,rax
   5731e:	mov    rdi,QWORD PTR [rsp+0xb0]
   57326:	test   rbx,rbx
   57329:	jne    57343 <sqlite3VdbeExec+0x7ea3>
   5732b:	mov    r13,QWORD PTR [rsp+0xf0]
   57333:	mov    rbx,rbp
   57336:	mov    rbp,QWORD PTR [rsp+0xf8]
   5733e:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   57343:	mov    rax,QWORD PTR [rbp+0x10]
   57347:	mov    QWORD PTR [rbx+0x30],rax
   5734b:	mov    r13d,DWORD PTR [rbp+0xc]
   5734f:	mov    rax,QWORD PTR [rbx+0x30]
   57353:	movzx  eax,WORD PTR [rax+0x8]
   57357:	shl    rax,0x3
   5735b:	add    rax,0x20
   5735f:	mov    r15d,eax
   57362:	mov    rax,r15
   57365:	mov    DWORD PTR [rsp+0x338],r13d
   5736d:	lea    r13,[rax+0xc8]
   57374:	test   r14,r14
   57377:	je     57399 <sqlite3VdbeExec+0x7ef9>
   57379:	mov    DWORD PTR [rsp+0x340],r15d
   57381:	mov    rdi,r14
   57384:	mov    rsi,r13
   57387:	call   5738c <sqlite3VdbeExec+0x7eec>
   5738c:	mov    r15,rax
   5738f:	mov    rdi,QWORD PTR [rsp+0xb0]
   57397:	jmp    573b4 <sqlite3VdbeExec+0x7f14>
   57399:	mov    DWORD PTR [rsp+0x340],r15d
   573a1:	mov    rdi,r13
   573a4:	call   573a9 <sqlite3VdbeExec+0x7f09>
   573a9:	mov    r15,rax
   573ac:	mov    rdi,QWORD PTR [rsp+0xb0]
   573b4:	test   r15,r15
   573b7:	je     573d9 <sqlite3VdbeExec+0x7f39>
   573b9:	xor    eax,eax
   573bb:	mov    QWORD PTR [rsp+0xb0],rdi
   573c3:	mov    rdi,r15
   573c6:	mov    rsi,rax
   573c9:	mov    rdx,r13
   573cc:	call   573d1 <sqlite3VdbeExec+0x7f31>
   573d1:	mov    rdi,QWORD PTR [rsp+0xb0]
   573d9:	mov    QWORD PTR [rbx+0x28],r15
   573dd:	test   r15,r15
   573e0:	jne    573ec <sqlite3VdbeExec+0x7f4c>
   573e2:	mov    ebx,0x7
   573e7:	jmp    575ea <sqlite3VdbeExec+0x814a>
   573ec:	mov    r13d,DWORD PTR [rsp+0x338]
   573f4:	mov    rax,QWORD PTR [r14+0x20]
   573f8:	mov    QWORD PTR [rsp+0x100],r12
   57400:	mov    r12,QWORD PTR [rax+0x8]
   57404:	mov    QWORD PTR [rsp+0xe8],rbp
   5740c:	lea    rbp,[r15+0xc8]
   57413:	mov    QWORD PTR [r15+0x28],rbp
   57417:	mov    rax,QWORD PTR [rbx+0x30]
   5741b:	mov    ebx,DWORD PTR [rsp+0x340]
   57422:	mov    rcx,rbx
   57425:	mov    QWORD PTR [rsp+0xb0],rdi
   5742d:	mov    rdi,rbp
   57430:	mov    rsi,rax
   57433:	mov    rdx,rcx
   57436:	call   5743b <sqlite3VdbeExec+0x7f9b>
   5743b:	mov    QWORD PTR [r15+0xd8],0x0
   57446:	mov    rdi,QWORD PTR [rsp+0xb0]
   5744e:	test   r13d,r13d
   57451:	je     57458 <sqlite3VdbeExec+0x7fb8>
   57453:	mov    WORD PTR [rbp+0x6],r13w
   57458:	mov    rax,QWORD PTR [r12+0x8]
   5745d:	mov    rcx,QWORD PTR [r12]
   57461:	mov    QWORD PTR [rax+0x8],rcx
   57465:	mov    rax,QWORD PTR [r12+0x8]
   5746a:	movsxd rax,DWORD PTR [rax+0x34]
   5746e:	mov    DWORD PTR [r15+0xc],eax
   57472:	mov    BYTE PTR [r15+0x5b],0x1
   57477:	mov    BYTE PTR [r15+0x5a],0xff
   5747c:	xor    ecx,ecx
   5747e:	cmp    BYTE PTR [r15+0x5b],0x1
   57483:	seta   cl
   57486:	mov    BYTE PTR [r15+0x59],cl
   5748a:	mov    QWORD PTR [r15+0x20],r14
   5748e:	xor    ecx,ecx
   57490:	jmp    574a5 <sqlite3VdbeExec+0x8005>
   57492:	lea    rdx,[r15+0x60]
   57496:	mov    rsi,rcx
   57499:	imul   rsi,rsi,0x68
   5749d:	mov    QWORD PTR [rdx+rsi*1+0x10],r15
   574a2:	add    ecx,0x1
   574a5:	movzx  edx,BYTE PTR [r15+0x5b]
   574aa:	cmp    ecx,edx
   574ac:	jl     57492 <sqlite3VdbeExec+0x7ff2>
   574ae:	cmp    BYTE PTR [r14+0x66],0x2
   574b3:	jne    574c5 <sqlite3VdbeExec+0x8025>
   574b5:	xor    r11d,r11d
   574b8:	mov    DWORD PTR [rsp+0x338],r11d
   574c0:	jmp    5755d <sqlite3VdbeExec+0x80bd>
   574c5:	mov    ecx,eax
   574c7:	imul   ecx,DWORD PTR [rip+0x0]        # 574ce <sqlite3VdbeExec+0x802e>
   574ce:	mov    DWORD PTR [r15],ecx
   574d1:	mov    rcx,QWORD PTR [r14+0x20]
   574d5:	mov    rcx,QWORD PTR [rcx+0x18]
   574d9:	movsxd rcx,DWORD PTR [rcx+0x74]
   574dd:	test   rcx,rcx
   574e0:	jge    574eb <sqlite3VdbeExec+0x804b>
   574e2:	imul   rcx,rcx,0xfffffffffffffc00
   574e9:	jmp    574f2 <sqlite3VdbeExec+0x8052>
   574eb:	mov    rdx,rax
   574ee:	imul   rcx,rdx
   574f2:	mov    edx,0x20000000
   574f7:	cmp    rcx,0x20000000
   574fe:	cmovl  rdx,rcx
   57502:	mov    ecx,DWORD PTR [r15]
   57505:	cmp    ecx,edx
   57507:	cmovg  edx,ecx
   5750a:	mov    DWORD PTR [r15+0x4],edx
   5750e:	cmp    BYTE PTR [rip+0x0],0x0        # 57515 <sqlite3VdbeExec+0x8075>
   57515:	je     57524 <sqlite3VdbeExec+0x8084>
   57517:	xor    r11d,r11d
   5751a:	mov    DWORD PTR [rsp+0x338],r11d
   57522:	jmp    5755d <sqlite3VdbeExec+0x80bd>
   57524:	mov    DWORD PTR [r15+0x54],eax
   57528:	mov    QWORD PTR [rsp+0xb0],rdi
   57530:	mov    rdi,rax
   57533:	call   57538 <sqlite3VdbeExec+0x8098>
   57538:	mov    QWORD PTR [r15+0x40],rax
   5753c:	mov    eax,0x7
   57541:	xor    r12d,r12d
   57544:	cmp    QWORD PTR [r15+0x40],0x0
   57549:	cmove  r12d,eax
   5754d:	mov    rdi,QWORD PTR [rsp+0xb0]
   57555:	mov    DWORD PTR [rsp+0x338],r12d
   5755d:	cmp    WORD PTR [rbp+0x8],0xd
   57562:	jb     5757d <sqlite3VdbeExec+0x80dd>
   57564:	mov    rbp,QWORD PTR [rsp+0xe8]
   5756c:	mov    r12,QWORD PTR [rsp+0x100]
   57574:	mov    ebx,DWORD PTR [rsp+0x338]
   5757b:	jmp    575ea <sqlite3VdbeExec+0x814a>
   5757d:	cmp    QWORD PTR [rbp+0x20],0x0
   57582:	je     575a7 <sqlite3VdbeExec+0x8107>
   57584:	mov    rax,QWORD PTR [rbp+0x20]
   57588:	cmp    rax,QWORD PTR [r14+0x10]
   5758c:	je     575a7 <sqlite3VdbeExec+0x8107>
   5758e:	mov    rbp,QWORD PTR [rsp+0xe8]
   57596:	mov    r12,QWORD PTR [rsp+0x100]
   5759e:	mov    ebx,DWORD PTR [rsp+0x338]
   575a5:	jmp    575ea <sqlite3VdbeExec+0x814a>
   575a7:	mov    rax,QWORD PTR [rbp+0x18]
   575ab:	movzx  eax,BYTE PTR [rax]
   575ae:	and    eax,0x2
   575b1:	test   eax,eax
   575b3:	je     575ce <sqlite3VdbeExec+0x812e>
   575b5:	mov    rbp,QWORD PTR [rsp+0xe8]
   575bd:	mov    r12,QWORD PTR [rsp+0x100]
   575c5:	mov    ebx,DWORD PTR [rsp+0x338]
   575cc:	jmp    575ea <sqlite3VdbeExec+0x814a>
   575ce:	mov    BYTE PTR [r15+0x5c],0x3
   575d3:	mov    rbp,QWORD PTR [rsp+0xe8]
   575db:	mov    r12,QWORD PTR [rsp+0x100]
   575e3:	mov    ebx,DWORD PTR [rsp+0x338]
   575ea:	test   ebx,ebx
   575ec:	je     5760e <sqlite3VdbeExec+0x816e>
   575ee:	mov    QWORD PTR [rsp+0xe8],rbp
   575f6:	mov    rbp,rbx
   575f9:	mov    r13,QWORD PTR [rsp+0xd0]
   57601:	mov    rbx,QWORD PTR [rsp+0xf8]
   57609:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5760e:	mov    DWORD PTR [rsp+0x32c],ebx
   57615:	mov    rbx,r12
   57618:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5761d:	mov    r15d,DWORD PTR [rsp+0x31c]
   57625:	mov    r13,QWORD PTR [rsp+0xf0]
   5762d:	mov    QWORD PTR [rsp+0xd0],r12
   57635:	mov    r12d,DWORD PTR [rsp+0x334]
   5763d:	mov    rax,QWORD PTR [rdi+0x78]
   57641:	movsxd rcx,DWORD PTR [rbp+0x4]
   57645:	mov    rax,QWORD PTR [rax+rcx*8]
   57649:	mov    rcx,QWORD PTR [rax+0x10]
   5764d:	lea    rdx,[rcx+0x1]
   57651:	mov    QWORD PTR [rax+0x10],rdx
   57655:	test   rcx,rcx
   57658:	jne    57672 <sqlite3VdbeExec+0x81d2>
   5765a:	mov    QWORD PTR [rsp+0xf0],r13
   57662:	mov    DWORD PTR [rsp+0x334],r12d
   5766a:	mov    r12,r14
   5766d:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   57672:	mov    DWORD PTR [rsp+0x31c],r15d
   5767a:	mov    QWORD PTR [rsp+0xf0],r13
   57682:	mov    DWORD PTR [rsp+0x334],r12d
   5768a:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5768f:	mov    r15d,DWORD PTR [rsp+0x31c]
   57697:	mov    r13,QWORD PTR [rsp+0xf0]
   5769f:	mov    QWORD PTR [rsp+0xd0],r12
   576a7:	mov    r12d,DWORD PTR [rsp+0x334]
   576af:	mov    eax,DWORD PTR [rbp+0x4]
   576b2:	mov    ecx,DWORD PTR [rbp+0xc]
   576b5:	mov    edx,0x3
   576ba:	mov    QWORD PTR [rsp+0xb0],rdi
   576c2:	mov    rsi,rax
   576c5:	mov    r11,rdx
   576c8:	mov    rdx,rcx
   576cb:	mov    rcx,r11
   576ce:	call   576d3 <sqlite3VdbeExec+0x8233>
   576d3:	mov    rdi,QWORD PTR [rsp+0xb0]
   576db:	test   rax,rax
   576de:	jne    576f0 <sqlite3VdbeExec+0x8250>
   576e0:	mov    rbx,rbp
   576e3:	mov    rbp,QWORD PTR [rsp+0xf8]
   576eb:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   576f0:	mov    BYTE PTR [rax+0x2],0x1
   576f4:	mov    ecx,DWORD PTR [rbp+0x8]
   576f7:	mov    DWORD PTR [rax+0x1c],ecx
   576fa:	mov    BYTE PTR [rax+0x4],0x1
   576fe:	lea    rcx,[rip+0x0]        # 57705 <sqlite3VdbeExec+0x8265>
   57705:	mov    QWORD PTR [rax+0x28],rcx
   57709:	mov    DWORD PTR [rsp+0x31c],r15d
   57711:	mov    QWORD PTR [rsp+0xf0],r13
   57719:	mov    DWORD PTR [rsp+0x334],r12d
   57721:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   57726:	mov    r15d,DWORD PTR [rsp+0x31c]
   5772e:	mov    r13,QWORD PTR [rsp+0xf0]
   57736:	mov    QWORD PTR [rsp+0xd0],r12
   5773e:	mov    r12d,DWORD PTR [rsp+0x334]
   57746:	mov    rax,QWORD PTR [rdi+0x78]
   5774a:	movsxd rcx,DWORD PTR [rbp+0x4]
   5774e:	mov    rax,QWORD PTR [rax+rcx*8]
   57752:	test   rax,rax
   57755:	je     5776f <sqlite3VdbeExec+0x82cf>
   57757:	mov    QWORD PTR [rsp+0xb0],rdi
   5775f:	mov    rsi,rax
   57762:	call   57767 <sqlite3VdbeExec+0x82c7>
   57767:	mov    rdi,QWORD PTR [rsp+0xb0]
   5776f:	mov    rax,QWORD PTR [rdi+0x78]
   57773:	movsxd rcx,DWORD PTR [rbp+0x4]
   57777:	mov    QWORD PTR [rax+rcx*8],0x0
   5777f:	mov    DWORD PTR [rsp+0x31c],r15d
   57787:	mov    QWORD PTR [rsp+0xf0],r13
   5778f:	mov    DWORD PTR [rsp+0x334],r12d
   57797:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5779c:	mov    r15d,DWORD PTR [rsp+0x31c]
   577a4:	mov    r13,QWORD PTR [rsp+0xf0]
   577ac:	mov    QWORD PTR [rsp+0xd0],r12
   577b4:	mov    r12d,DWORD PTR [rsp+0x334]
   577bc:	mov    rax,QWORD PTR [rdi+0x78]
   577c0:	movsxd rcx,DWORD PTR [rbp+0x4]
   577c4:	mov    DWORD PTR [rsp+0x334],r12d
   577cc:	mov    r12,QWORD PTR [rax+rcx*8]
   577d0:	movzx  eax,BYTE PTR [rbp+0x0]
   577d4:	mov    QWORD PTR [rsp+0xf0],r13
   577dc:	mov    r13d,eax
   577df:	mov    BYTE PTR [r12+0x2],0x0
   577e5:	mov    BYTE PTR [r12+0x3],0x0
   577eb:	mov    DWORD PTR [r12+0x18],0x0
   577f4:	cmp    BYTE PTR [r12+0x4],0x0
   577fa:	je     57c16 <sqlite3VdbeExec+0x8776>
   57800:	movsxd rax,DWORD PTR [rbp+0xc]
   57804:	imul   rax,rax,0x38
   57808:	mov    DWORD PTR [rsp+0x340],r13d
   57810:	lea    r13,[rbx+rax*1]
   57814:	mov    QWORD PTR [rsp+0x128],r12
   5781c:	movzx  r12d,WORD PTR [rbx+rax*1+0x14]
   57822:	mov    eax,r12d
   57825:	and    eax,0x2e
   57828:	cmp    eax,0x2
   5782b:	jne    5784a <sqlite3VdbeExec+0x83aa>
   5782d:	xor    eax,eax
   5782f:	mov    QWORD PTR [rsp+0xb0],rdi
   57837:	mov    rdi,r13
   5783a:	mov    rsi,rax
   5783d:	call   57842 <sqlite3VdbeExec+0x83a2>
   57842:	mov    rdi,QWORD PTR [rsp+0xb0]
   5784a:	movzx  eax,WORD PTR [r13+0x14]
   5784f:	mov    ecx,eax
   57851:	and    ecx,0x24
   57854:	test   ecx,ecx
   57856:	je     57869 <sqlite3VdbeExec+0x83c9>
   57858:	mov    DWORD PTR [rsp+0x33c],r12d
   57860:	mov    r12,QWORD PTR [r13+0x0]
   57864:	jmp    578f7 <sqlite3VdbeExec+0x8457>
   57869:	mov    DWORD PTR [rsp+0x33c],r12d
   57871:	mov    ecx,eax
   57873:	and    ecx,0x8
   57876:	test   ecx,ecx
   57878:	je     578c9 <sqlite3VdbeExec+0x8429>
   5787a:	movsd  xmm1,QWORD PTR [r13+0x0]
   57880:	movabs r11,0xc3dfffffffffffff
   5788a:	movq   xmm0,r11
   5788f:	ucomisd xmm0,xmm1
   57893:	jbe    578a1 <sqlite3VdbeExec+0x8401>
   57895:	movabs r12,0x8000000000000000
   5789f:	jmp    578c7 <sqlite3VdbeExec+0x8427>
   578a1:	movabs r11,0x43dfffffffffffff
   578ab:	movq   xmm0,r11
   578b0:	ucomisd xmm1,xmm0
   578b4:	jbe    578c2 <sqlite3VdbeExec+0x8422>
   578b6:	movabs r12,0x7fffffffffffffff
   578c0:	jmp    578c7 <sqlite3VdbeExec+0x8427>
   578c2:	cvttsd2si r12,xmm1
   578c7:	jmp    578f7 <sqlite3VdbeExec+0x8457>
   578c9:	and    eax,0x12
   578cc:	test   eax,eax
   578ce:	je     578f4 <sqlite3VdbeExec+0x8454>
   578d0:	cmp    QWORD PTR [r13+0x8],0x0
   578d5:	je     578f4 <sqlite3VdbeExec+0x8454>
   578d7:	mov    QWORD PTR [rsp+0xb0],rdi
   578df:	mov    rdi,r13
   578e2:	call   578e7 <sqlite3VdbeExec+0x8447>
   578e7:	mov    r12,rax
   578ea:	mov    rdi,QWORD PTR [rsp+0xb0]
   578f2:	jmp    578f7 <sqlite3VdbeExec+0x8457>
   578f4:	xor    r12d,r12d
   578f7:	movzx  eax,WORD PTR [r13+0x14]
   578fc:	mov    DWORD PTR [rsp+0x31c],r15d
   57904:	mov    r15d,DWORD PTR [rsp+0x33c]
   5790c:	mov    WORD PTR [r13+0x14],r15w
   57911:	mov    ecx,eax
   57913:	and    ecx,0x24
   57916:	test   ecx,ecx
   57918:	je     57927 <sqlite3VdbeExec+0x8487>
   5791a:	mov    r13d,DWORD PTR [rsp+0x340]
   57922:	jmp    57b03 <sqlite3VdbeExec+0x8663>
   57927:	mov    ecx,eax
   57929:	and    ecx,0x8
   5792c:	test   ecx,ecx
   5792e:	jne    579ee <sqlite3VdbeExec+0x854e>
   57934:	and    eax,0x1
   57937:	test   eax,eax
   57939:	jne    57949 <sqlite3VdbeExec+0x84a9>
   5793b:	mov    r13d,DWORD PTR [rsp+0x340]
   57943:	cmp    r13d,0x17
   57947:	jl     57959 <sqlite3VdbeExec+0x84b9>
   57949:	mov    r12,r14
   5794c:	mov    r15d,DWORD PTR [rsp+0x31c]
   57954:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   57959:	mov    r12,QWORD PTR [rsp+0x128]
   57961:	mov    rax,QWORD PTR [r12+0x28]
   57966:	lea    r12,[rsp+0x338]
   5796e:	mov    rcx,r12
   57971:	xor    edx,edx
   57973:	movzx  esi,BYTE PTR [rax]
   57976:	cmp    edx,esi
   57978:	jne    57990 <sqlite3VdbeExec+0x84f0>
   5797a:	movzx  edx,BYTE PTR [rax+0x1]
   5797e:	and    edx,0x8
   57981:	test   edx,edx
   57983:	je     57990 <sqlite3VdbeExec+0x84f0>
   57985:	mov    DWORD PTR [rcx],0x0
   5798b:	xor    r13d,r13d
   5798e:	jmp    579ae <sqlite3VdbeExec+0x850e>
   57990:	mov    QWORD PTR [rsp+0xb0],rdi
   57998:	mov    rdi,rax
   5799b:	mov    rsi,rcx
   5799e:	call   579a3 <sqlite3VdbeExec+0x8503>
   579a3:	mov    r13d,eax
   579a6:	mov    rdi,QWORD PTR [rsp+0xb0]
   579ae:	test   r13d,r13d
   579b1:	je     579d3 <sqlite3VdbeExec+0x8533>
   579b3:	mov    QWORD PTR [rsp+0xe8],rbp
   579bb:	mov    rbp,r13
   579be:	mov    r13,QWORD PTR [rsp+0xd0]
   579c6:	mov    rbx,QWORD PTR [rsp+0xf8]
   579ce:	jmp    4f712 <sqlite3VdbeExec+0x272>
   579d3:	mov    r15d,DWORD PTR [rsp+0x31c]
   579db:	mov    r12,r13
   579de:	xor    r11d,r11d
   579e1:	mov    DWORD PTR [rsp+0x33c],r11d
   579e9:	jmp    57ebd <sqlite3VdbeExec+0x8a1d>
   579ee:	mov    r15,r13
   579f1:	mov    r13d,DWORD PTR [rsp+0x340]
   579f9:	movsd  xmm1,QWORD PTR [r15]
   579fe:	movsd  QWORD PTR [rsp+0x118],xmm1
   57a07:	mov    rax,QWORD PTR [rsp+0x118]
   57a0f:	mov    QWORD PTR [rsp+0x108],rax
   57a17:	mov    rax,QWORD PTR [rsp+0x108]
   57a1f:	movabs rcx,0x7ff0000000000000
   57a29:	and    rcx,rax
   57a2c:	movabs rdx,0x7ff0000000000000
   57a36:	movabs rsi,0xfffffffffffff
   57a40:	and    rax,rsi
   57a43:	test   rax,rax
   57a46:	mov    eax,0x0
   57a4b:	setne  al
   57a4e:	xor    esi,esi
   57a50:	cmp    rcx,rdx
   57a53:	cmove  esi,eax
   57a56:	test   esi,esi
   57a58:	je     57a61 <sqlite3VdbeExec+0x85c1>
   57a5a:	mov    eax,0x1
   57a5f:	jmp    57adc <sqlite3VdbeExec+0x863c>
   57a61:	movabs r11,0xc3e0000000000000
   57a6b:	movq   xmm0,r11
   57a70:	ucomisd xmm0,xmm1
   57a74:	jbe    57a7d <sqlite3VdbeExec+0x85dd>
   57a76:	mov    eax,0x1
   57a7b:	jmp    57adc <sqlite3VdbeExec+0x863c>
   57a7d:	movabs r11,0x43e0000000000000
   57a87:	movq   xmm0,r11
   57a8c:	ucomisd xmm1,xmm0
   57a90:	jb     57a99 <sqlite3VdbeExec+0x85f9>
   57a92:	mov    eax,0xffffffff
   57a97:	jmp    57adc <sqlite3VdbeExec+0x863c>
   57a99:	cvttsd2si rax,xmm1
   57a9e:	cmp    r12,rax
   57aa1:	jge    57aaa <sqlite3VdbeExec+0x860a>
   57aa3:	mov    eax,0xffffffff
   57aa8:	jmp    57adc <sqlite3VdbeExec+0x863c>
   57aaa:	cmp    r12,rax
   57aad:	jle    57ab6 <sqlite3VdbeExec+0x8616>
   57aaf:	mov    eax,0x1
   57ab4:	jmp    57adc <sqlite3VdbeExec+0x863c>
   57ab6:	xorps  xmm0,xmm0
   57ab9:	cvtsi2sd xmm0,r12
   57abe:	ucomisd xmm1,xmm0
   57ac2:	jbe    57acb <sqlite3VdbeExec+0x862b>
   57ac4:	mov    eax,0xffffffff
   57ac9:	jmp    57adc <sqlite3VdbeExec+0x863c>
   57acb:	xorps  xmm0,xmm0
   57ace:	cvtsi2sd xmm0,r12
   57ad3:	xor    eax,eax
   57ad5:	ucomisd xmm0,xmm1
   57ad9:	seta   al
   57adc:	test   eax,eax
   57ade:	jle    57af0 <sqlite3VdbeExec+0x8650>
   57ae0:	mov    eax,r13d
   57ae3:	and    eax,0x1
   57ae6:	test   eax,eax
   57ae8:	jne    57aee <sqlite3VdbeExec+0x864e>
   57aea:	sub    r13d,0x1
   57aee:	jmp    57b03 <sqlite3VdbeExec+0x8663>
   57af0:	test   eax,eax
   57af2:	jge    57b03 <sqlite3VdbeExec+0x8663>
   57af4:	mov    eax,r13d
   57af7:	and    eax,0x1
   57afa:	cmp    eax,0x1
   57afd:	jne    57b03 <sqlite3VdbeExec+0x8663>
   57aff:	add    r13d,0x1
   57b03:	mov    r15,QWORD PTR [rsp+0x128]
   57b0b:	mov    rax,QWORD PTR [r15+0x28]
   57b0f:	xor    ecx,ecx
   57b11:	mov    QWORD PTR [rsp+0xc8],r14
   57b19:	lea    r14,[rsp+0x338]
   57b21:	mov    rdx,r14
   57b24:	mov    QWORD PTR [rsp+0xb0],rdi
   57b2c:	mov    rdi,rax
   57b2f:	mov    rsi,r12
   57b32:	mov    r11,rdx
   57b35:	mov    rdx,rcx
   57b38:	mov    rcx,r11
   57b3b:	call   57b40 <sqlite3VdbeExec+0x86a0>
   57b40:	mov    r14d,eax
   57b43:	mov    QWORD PTR [r15+0x48],r12
   57b47:	mov    rdi,QWORD PTR [rsp+0xb0]
   57b4f:	test   r14d,r14d
   57b52:	je     57b7c <sqlite3VdbeExec+0x86dc>
   57b54:	mov    QWORD PTR [rsp+0xe8],rbp
   57b5c:	mov    rbp,r14
   57b5f:	mov    r14,QWORD PTR [rsp+0xc8]
   57b67:	mov    r13,QWORD PTR [rsp+0xd0]
   57b6f:	mov    rbx,QWORD PTR [rsp+0xf8]
   57b77:	jmp    4f712 <sqlite3VdbeExec+0x272>
   57b7c:	mov    r12,r15
   57b7f:	mov    r15,r14
   57b82:	mov    r14,QWORD PTR [rsp+0xc8]
   57b8a:	xor    r11d,r11d
   57b8d:	mov    DWORD PTR [rsp+0x33c],r11d
   57b95:	cmp    r13d,0x17
   57b99:	jl     57dce <sqlite3VdbeExec+0x892e>
   57b9f:	cmp    DWORD PTR [rsp+0x338],0x0
   57ba7:	jl     57bc1 <sqlite3VdbeExec+0x8721>
   57ba9:	cmp    DWORD PTR [rsp+0x338],0x0
   57bb1:	jne    57db3 <sqlite3VdbeExec+0x8913>
   57bb7:	cmp    r13d,0x18
   57bbb:	jne    57db3 <sqlite3VdbeExec+0x8913>
   57bc1:	mov    DWORD PTR [rsp+0x338],0x0
   57bcc:	mov    rax,QWORD PTR [r12+0x28]
   57bd1:	xor    ecx,ecx
   57bd3:	mov    QWORD PTR [rsp+0xb0],rdi
   57bdb:	mov    rdi,rax
   57bde:	mov    rsi,rcx
   57be1:	call   57be6 <sqlite3VdbeExec+0x8746>
   57be6:	mov    r12d,eax
   57be9:	mov    rdi,QWORD PTR [rsp+0xb0]
   57bf1:	test   r12d,r12d
   57bf4:	je     57c0e <sqlite3VdbeExec+0x876e>
   57bf6:	cmp    r12d,0x65
   57bfa:	jne    57d93 <sqlite3VdbeExec+0x88f3>
   57c00:	mov    DWORD PTR [rsp+0x338],0x1
   57c0b:	xor    r12d,r12d
   57c0e:	mov    r15,r12
   57c11:	jmp    57dbe <sqlite3VdbeExec+0x891e>
   57c16:	mov    DWORD PTR [rsp+0x340],r13d
   57c1e:	mov    rax,QWORD PTR [r12+0x28]
   57c23:	movzx  eax,BYTE PTR [rax+0x3]
   57c27:	and    eax,0x2
   57c2a:	test   eax,eax
   57c2c:	jne    57c43 <sqlite3VdbeExec+0x87a3>
   57c2e:	mov    r13d,DWORD PTR [rsp+0x340]
   57c36:	xor    r11d,r11d
   57c39:	mov    DWORD PTR [rsp+0x33c],r11d
   57c41:	jmp    57c59 <sqlite3VdbeExec+0x87b9>
   57c43:	mov    r13d,DWORD PTR [rsp+0x340]
   57c4b:	mov    r11d,0x1
   57c51:	mov    DWORD PTR [rsp+0x33c],r11d
   57c59:	mov    eax,DWORD PTR [rbp+0x10]
   57c5c:	mov    rcx,QWORD PTR [r12+0x30]
   57c61:	mov    QWORD PTR [rsp+0x188],rcx
   57c69:	mov    WORD PTR [rsp+0x1a4],ax
   57c71:	mov    eax,r13d
   57c74:	sub    eax,0x15
   57c77:	and    eax,0x1
   57c7a:	test   eax,eax
   57c7c:	je     57c85 <sqlite3VdbeExec+0x87e5>
   57c7e:	mov    eax,0xff
   57c83:	jmp    57c8a <sqlite3VdbeExec+0x87ea>
   57c85:	mov    eax,0x1
   57c8a:	mov    BYTE PTR [rsp+0x1a6],al
   57c91:	movsxd rax,DWORD PTR [rbp+0xc]
   57c95:	imul   rax,rax,0x38
   57c99:	add    rax,rbx
   57c9c:	mov    QWORD PTR [rsp+0x190],rax
   57ca4:	mov    BYTE PTR [rsp+0x1aa],0x0
   57cac:	mov    rax,QWORD PTR [r12+0x28]
   57cb1:	mov    QWORD PTR [rsp+0xc8],r14
   57cb9:	lea    r14,[rsp+0x188]
   57cc1:	mov    rcx,r14
   57cc4:	lea    r14,[rsp+0x338]
   57ccc:	mov    rdx,r14
   57ccf:	mov    QWORD PTR [rsp+0xb0],rdi
   57cd7:	mov    rdi,rax
   57cda:	mov    rsi,rcx
   57cdd:	call   57ce2 <sqlite3VdbeExec+0x8842>
   57ce2:	mov    r14d,eax
   57ce5:	mov    rdi,QWORD PTR [rsp+0xb0]
   57ced:	test   r14d,r14d
   57cf0:	je     57d1a <sqlite3VdbeExec+0x887a>
   57cf2:	mov    QWORD PTR [rsp+0xe8],rbp
   57cfa:	mov    rbp,r14
   57cfd:	mov    r14,QWORD PTR [rsp+0xc8]
   57d05:	mov    r13,QWORD PTR [rsp+0xd0]
   57d0d:	mov    rbx,QWORD PTR [rsp+0xf8]
   57d15:	jmp    4f712 <sqlite3VdbeExec+0x272>
   57d1a:	mov    DWORD PTR [rsp+0x31c],r15d
   57d22:	mov    r15,r14
   57d25:	mov    r14,QWORD PTR [rsp+0xc8]
   57d2d:	mov    DWORD PTR [rsp+0x348],r15d
   57d35:	mov    r15d,DWORD PTR [rsp+0x33c]
   57d3d:	test   r15d,r15d
   57d40:	jne    57d57 <sqlite3VdbeExec+0x88b7>
   57d42:	mov    DWORD PTR [rsp+0x33c],r15d
   57d4a:	mov    r15d,DWORD PTR [rsp+0x348]
   57d52:	jmp    57b95 <sqlite3VdbeExec+0x86f5>
   57d57:	cmp    BYTE PTR [rsp+0x1aa],0x0
   57d5f:	je     57d76 <sqlite3VdbeExec+0x88d6>
   57d61:	mov    DWORD PTR [rsp+0x33c],r15d
   57d69:	mov    r15d,DWORD PTR [rsp+0x348]
   57d71:	jmp    57b95 <sqlite3VdbeExec+0x86f5>
   57d76:	mov    r12d,DWORD PTR [rsp+0x348]
   57d7e:	mov    DWORD PTR [rsp+0x33c],r15d
   57d86:	mov    r15d,DWORD PTR [rsp+0x31c]
   57d8e:	jmp    57ebd <sqlite3VdbeExec+0x8a1d>
   57d93:	mov    QWORD PTR [rsp+0xe8],rbp
   57d9b:	mov    rbp,r12
   57d9e:	mov    r13,QWORD PTR [rsp+0xd0]
   57da6:	mov    rbx,QWORD PTR [rsp+0xf8]
   57dae:	jmp    4f712 <sqlite3VdbeExec+0x272>
   57db3:	mov    DWORD PTR [rsp+0x338],0x0
   57dbe:	mov    r12,r15
   57dc1:	mov    r15d,DWORD PTR [rsp+0x31c]
   57dc9:	jmp    57ebd <sqlite3VdbeExec+0x8a1d>
   57dce:	cmp    DWORD PTR [rsp+0x338],0x0
   57dd6:	jg     57df0 <sqlite3VdbeExec+0x8950>
   57dd8:	cmp    DWORD PTR [rsp+0x338],0x0
   57de0:	jne    57e97 <sqlite3VdbeExec+0x89f7>
   57de6:	cmp    r13d,0x15
   57dea:	jne    57e97 <sqlite3VdbeExec+0x89f7>
   57df0:	mov    DWORD PTR [rsp+0x338],0x0
   57dfb:	mov    rax,QWORD PTR [r12+0x28]
   57e00:	movzx  ecx,BYTE PTR [rax+0x1]
   57e04:	and    ecx,0xfffffff1
   57e07:	mov    BYTE PTR [rax+0x1],cl
   57e0a:	mov    WORD PTR [rax+0x46],0x0
   57e10:	cmp    BYTE PTR [rax],0x0
   57e13:	jne    57e29 <sqlite3VdbeExec+0x8989>
   57e15:	cmp    WORD PTR [rax+0x56],0x0
   57e1a:	je     57e29 <sqlite3VdbeExec+0x8989>
   57e1c:	mov    rcx,QWORD PTR [rax+0x88]
   57e23:	cmp    BYTE PTR [rcx+0x8],0x0
   57e27:	jne    57e46 <sqlite3VdbeExec+0x89a6>
   57e29:	mov    QWORD PTR [rsp+0xb0],rdi
   57e31:	mov    rdi,rax
   57e34:	call   57e39 <sqlite3VdbeExec+0x8999>
   57e39:	mov    r12d,eax
   57e3c:	mov    rdi,QWORD PTR [rsp+0xb0]
   57e44:	jmp    57e54 <sqlite3VdbeExec+0x89b4>
   57e46:	movzx  ecx,WORD PTR [rax+0x56]
   57e4a:	sub    ecx,0x1
   57e4d:	mov    WORD PTR [rax+0x56],cx
   57e51:	xor    r12d,r12d
   57e54:	test   r12d,r12d
   57e57:	je     57e6d <sqlite3VdbeExec+0x89cd>
   57e59:	cmp    r12d,0x65
   57e5d:	jne    57e77 <sqlite3VdbeExec+0x89d7>
   57e5f:	mov    DWORD PTR [rsp+0x338],0x1
   57e6a:	xor    r12d,r12d
   57e6d:	mov    r15d,DWORD PTR [rsp+0x31c]
   57e75:	jmp    57ebd <sqlite3VdbeExec+0x8a1d>
   57e77:	mov    QWORD PTR [rsp+0xe8],rbp
   57e7f:	mov    rbp,r12
   57e82:	mov    r13,QWORD PTR [rsp+0xd0]
   57e8a:	mov    rbx,QWORD PTR [rsp+0xf8]
   57e92:	jmp    4f712 <sqlite3VdbeExec+0x272>
   57e97:	mov    rax,QWORD PTR [r12+0x28]
   57e9c:	xor    ecx,ecx
   57e9e:	movzx  eax,BYTE PTR [rax]
   57ea1:	cmp    ecx,eax
   57ea3:	mov    eax,0x0
   57ea8:	setne  al
   57eab:	mov    DWORD PTR [rsp+0x338],eax
   57eb2:	mov    r12,r15
   57eb5:	mov    r15d,DWORD PTR [rsp+0x31c]
   57ebd:	cmp    DWORD PTR [rsp+0x338],0x0
   57ec5:	je     57ed7 <sqlite3VdbeExec+0x8a37>
   57ec7:	mov    DWORD PTR [rsp+0x32c],r12d
   57ecf:	mov    r12,r14
   57ed2:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   57ed7:	mov    r13d,DWORD PTR [rsp+0x33c]
   57edf:	test   r13d,r13d
   57ee2:	je     57ee8 <sqlite3VdbeExec+0x8a48>
   57ee4:	add    rbp,0x18
   57ee8:	mov    DWORD PTR [rsp+0x31c],r15d
   57ef0:	mov    DWORD PTR [rsp+0x32c],r12d
   57ef8:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   57efd:	mov    r15d,DWORD PTR [rsp+0x31c]
   57f05:	mov    r13,QWORD PTR [rsp+0xf0]
   57f0d:	mov    QWORD PTR [rsp+0xd0],r12
   57f15:	mov    r12d,DWORD PTR [rsp+0x334]
   57f1d:	mov    rax,QWORD PTR [rdi+0x78]
   57f21:	movsxd rcx,DWORD PTR [rbp+0x1c]
   57f25:	mov    DWORD PTR [rsp+0x334],r12d
   57f2d:	mov    r12,QWORD PTR [rax+rcx*8]
   57f31:	mov    rax,QWORD PTR [r12+0x28]
   57f36:	cmp    BYTE PTR [rax],0x0
   57f39:	je     57f50 <sqlite3VdbeExec+0x8ab0>
   57f3b:	mov    DWORD PTR [rsp+0x31c],r15d
   57f43:	mov    QWORD PTR [rsp+0xf0],r13
   57f4b:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   57f50:	mov    QWORD PTR [rsp+0xf0],r13
   57f58:	mov    r13d,DWORD PTR [rbp+0x4]
   57f5c:	mov    rax,QWORD PTR [r12+0x30]
   57f61:	mov    QWORD PTR [rsp+0x188],rax
   57f69:	mov    eax,DWORD PTR [rbp+0x28]
   57f6c:	mov    WORD PTR [rsp+0x1a4],ax
   57f74:	mov    BYTE PTR [rsp+0x1a6],0x0
   57f7c:	movsxd rax,DWORD PTR [rbp+0x24]
   57f80:	imul   rax,rax,0x38
   57f84:	add    rax,rbx
   57f87:	mov    QWORD PTR [rsp+0x190],rax
   57f8f:	mov    DWORD PTR [rsp+0x338],0x0
   57f9a:	mov    DWORD PTR [rsp+0x31c],r15d
   57fa2:	jmp    58173 <sqlite3VdbeExec+0x8cd3>
   57fa7:	mov    DWORD PTR [rsp+0x33c],r13d
   57faf:	mov    r13,r15
   57fb2:	mov    r15d,DWORD PTR [rsp+0x31c]
   57fba:	mov    QWORD PTR [rsp+0x128],r12
   57fc2:	lea    r12,[rsp+0x1e0]
   57fca:	mov    WORD PTR [r12+0x14],0x0
   57fd2:	mov    QWORD PTR [r12+0x18],r14
   57fd7:	mov    DWORD PTR [r12+0x20],0x0
   57fe0:	mov    rcx,r12
   57fe3:	mov    QWORD PTR [rsp+0xb0],rdi
   57feb:	mov    rdi,r13
   57fee:	mov    rsi,rax
   57ff1:	mov    rdx,rcx
   57ff4:	call   57ff9 <sqlite3VdbeExec+0x8b59>
   57ff9:	mov    r13d,eax
   57ffc:	mov    rdi,QWORD PTR [rsp+0xb0]
   58004:	test   r13d,r13d
   58007:	je     5800e <sqlite3VdbeExec+0x8b6e>
   58009:	mov    r12,r13
   5800c:	jmp    58065 <sqlite3VdbeExec+0x8bc5>
   5800e:	mov    eax,DWORD PTR [r12+0x10]
   58013:	mov    rcx,QWORD PTR [r12+0x8]
   58018:	xor    edx,edx
   5801a:	lea    r13,[rsp+0x188]
   58022:	mov    rdi,rax
   58025:	mov    rsi,rcx
   58028:	mov    rcx,rdx
   5802b:	mov    rdx,r13
   5802e:	call   58033 <sqlite3VdbeExec+0x8b93>
   58033:	lea    r13,[rsp+0x338]
   5803b:	mov    DWORD PTR [r13+0x0],eax
   5803f:	mov    rax,r12
   58042:	mov    rdi,QWORD PTR [rsp+0xb0]
   5804a:	cmp    DWORD PTR [r12+0x20],0x0
   58050:	je     58062 <sqlite3VdbeExec+0x8bc2>
   58052:	mov    rdi,rax
   58055:	call   5805a <sqlite3VdbeExec+0x8bba>
   5805a:	mov    rdi,QWORD PTR [rsp+0xb0]
   58062:	xor    r12d,r12d
   58065:	test   r12d,r12d
   58068:	je     5808a <sqlite3VdbeExec+0x8bea>
   5806a:	mov    QWORD PTR [rsp+0xe8],rbp
   58072:	mov    rbp,r12
   58075:	mov    r13,QWORD PTR [rsp+0xd0]
   5807d:	mov    rbx,QWORD PTR [rsp+0xf8]
   58085:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5808a:	cmp    DWORD PTR [rsp+0x338],0x0
   58092:	jle    580ab <sqlite3VdbeExec+0x8c0b>
   58094:	cmp    WORD PTR [rbp+0x2],0x0
   58099:	jne    580ab <sqlite3VdbeExec+0x8c0b>
   5809b:	mov    DWORD PTR [rsp+0x32c],r12d
   580a3:	mov    r12,r14
   580a6:	jmp    5814a <sqlite3VdbeExec+0x8caa>
   580ab:	cmp    DWORD PTR [rsp+0x338],0x0
   580b3:	jl     580c5 <sqlite3VdbeExec+0x8c25>
   580b5:	mov    DWORD PTR [rsp+0x32c],r12d
   580bd:	mov    r12,r14
   580c0:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   580c5:	mov    r13d,DWORD PTR [rsp+0x33c]
   580cd:	test   r13d,r13d
   580d0:	jg     580e7 <sqlite3VdbeExec+0x8c47>
   580d2:	mov    DWORD PTR [rsp+0x31c],r15d
   580da:	mov    DWORD PTR [rsp+0x32c],r12d
   580e2:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   580e7:	mov    r12,QWORD PTR [rsp+0x128]
   580ef:	sub    r13d,0x1
   580f3:	mov    DWORD PTR [r12+0x18],0x0
   580fc:	mov    rax,QWORD PTR [r12+0x28]
   58101:	xor    ecx,ecx
   58103:	mov    DWORD PTR [rsp+0x31c],r15d
   5810b:	mov    QWORD PTR [rsp+0xb0],rdi
   58113:	mov    rdi,rax
   58116:	mov    rsi,rcx
   58119:	call   5811e <sqlite3VdbeExec+0x8c7e>
   5811e:	mov    r15d,eax
   58121:	mov    rdi,QWORD PTR [rsp+0xb0]
   58129:	test   r15d,r15d
   5812c:	je     58173 <sqlite3VdbeExec+0x8cd3>
   5812e:	cmp    r15d,0x65
   58132:	jne    58153 <sqlite3VdbeExec+0x8cb3>
   58134:	mov    r12,r14
   58137:	mov    r15d,DWORD PTR [rsp+0x31c]
   5813f:	xor    r11d,r11d
   58142:	mov    DWORD PTR [rsp+0x32c],r11d
   5814a:	add    rbp,0x18
   5814e:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   58153:	mov    QWORD PTR [rsp+0xe8],rbp
   5815b:	mov    rbp,r15
   5815e:	mov    r13,QWORD PTR [rsp+0xd0]
   58166:	mov    rbx,QWORD PTR [rsp+0xf8]
   5816e:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58173:	lea    r15,[rsp+0x188]
   5817b:	lea    r15,[rsp+0x338]
   58183:	mov    r15,QWORD PTR [r12+0x28]
   58188:	mov    QWORD PTR [rsp+0xb0],rdi
   58190:	mov    rdi,r15
   58193:	call   58198 <sqlite3VdbeExec+0x8cf8>
   58198:	mov    eax,DWORD PTR [r15+0x40]
   5819c:	mov    rdi,QWORD PTR [rsp+0xb0]
   581a4:	test   rax,rax
   581a7:	jle    581b5 <sqlite3VdbeExec+0x8d15>
   581a9:	cmp    rax,0x7fffffff
   581af:	jle    57fa7 <sqlite3VdbeExec+0x8b07>
   581b5:	mov    DWORD PTR [rsp+0x338],0x0
   581c0:	mov    eax,0x16b6e
   581c5:	mov    ecx,0xb
   581ca:	lea    rdx,[rip+0x0]        # 581d1 <sqlite3VdbeExec+0x8d31>
   581d1:	mov    QWORD PTR [rsp+0xb0],rdi
   581d9:	mov    rdi,rcx
   581dc:	mov    rsi,rax
   581df:	call   581e4 <sqlite3VdbeExec+0x8d44>
   581e4:	mov    r15d,eax
   581e7:	mov    rdi,QWORD PTR [rsp+0xb0]
   581ef:	mov    QWORD PTR [rsp+0x128],r12
   581f7:	mov    DWORD PTR [rsp+0x33c],r13d
   581ff:	mov    r12,r15
   58202:	mov    r15d,DWORD PTR [rsp+0x31c]
   5820a:	jmp    58065 <sqlite3VdbeExec+0x8bc5>
   5820f:	mov    r15d,DWORD PTR [rsp+0x31c]
   58217:	mov    r13,QWORD PTR [rsp+0xf0]
   5821f:	mov    QWORD PTR [rsp+0xd0],r12
   58227:	mov    r12d,DWORD PTR [rsp+0x334]
   5822f:	mov    rax,QWORD PTR [rdi+0x78]
   58233:	movsxd rcx,DWORD PTR [rbp+0x4]
   58237:	mov    rax,QWORD PTR [rax+rcx*8]
   5823b:	movzx  ecx,WORD PTR [rax+0x6]
   5823f:	cmp    ecx,DWORD PTR [rbp+0x8]
   58242:	jge    5824d <sqlite3VdbeExec+0x8dad>
   58244:	mov    ecx,DWORD PTR [rbp+0x8]
   58247:	mov    WORD PTR [rax+0x6],cx
   5824b:	jmp    5825d <sqlite3VdbeExec+0x8dbd>
   5824d:	movzx  ecx,WORD PTR [rax+0x6]
   58251:	cmp    ecx,DWORD PTR [rbp+0xc]
   58254:	jle    5825d <sqlite3VdbeExec+0x8dbd>
   58256:	mov    ecx,DWORD PTR [rbp+0xc]
   58259:	mov    WORD PTR [rax+0x6],cx
   5825d:	mov    DWORD PTR [rsp+0x31c],r15d
   58265:	mov    QWORD PTR [rsp+0xf0],r13
   5826d:	mov    DWORD PTR [rsp+0x334],r12d
   58275:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5827a:	mov    r15d,DWORD PTR [rsp+0x31c]
   58282:	mov    r13,QWORD PTR [rsp+0xf0]
   5828a:	mov    QWORD PTR [rsp+0xd0],r12
   58292:	mov    r12d,DWORD PTR [rsp+0x334]
   5829a:	mov    rax,QWORD PTR [rdi+0x78]
   5829e:	movsxd rcx,DWORD PTR [rbp+0x4]
   582a2:	mov    rax,QWORD PTR [rax+rcx*8]
   582a6:	test   rax,rax
   582a9:	je     582b1 <sqlite3VdbeExec+0x8e11>
   582ab:	cmp    BYTE PTR [rax+0x2],0x0
   582af:	je     582b6 <sqlite3VdbeExec+0x8e16>
   582b1:	jmp    4f7bd <sqlite3VdbeExec+0x31d>
   582b6:	mov    DWORD PTR [rsp+0x31c],r15d
   582be:	mov    QWORD PTR [rsp+0xf0],r13
   582c6:	mov    DWORD PTR [rsp+0x334],r12d
   582ce:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   582d3:	mov    r15d,DWORD PTR [rsp+0x31c]
   582db:	mov    r13,QWORD PTR [rsp+0xf0]
   582e3:	mov    QWORD PTR [rsp+0xd0],r12
   582eb:	mov    r12d,DWORD PTR [rsp+0x334]
   582f3:	mov    rax,QWORD PTR [rdi+0x78]
   582f7:	movsxd rcx,DWORD PTR [rbp+0x4]
   582fb:	mov    rax,QWORD PTR [rax+rcx*8]
   582ff:	movzx  eax,WORD PTR [rax+0x6]
   58303:	cmp    eax,DWORD PTR [rbp+0x10]
   58306:	jl     58325 <sqlite3VdbeExec+0x8e85>
   58308:	mov    DWORD PTR [rsp+0x31c],r15d
   58310:	mov    QWORD PTR [rsp+0xf0],r13
   58318:	mov    DWORD PTR [rsp+0x334],r12d
   58320:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   58325:	mov    rax,QWORD PTR [rdi+0x78]
   58329:	movsxd rcx,DWORD PTR [rbp+0x4]
   5832d:	mov    DWORD PTR [rsp+0x334],r12d
   58335:	mov    r12,QWORD PTR [rax+rcx*8]
   58339:	movsxd rax,DWORD PTR [rbp+0xc]
   5833d:	imul   rax,rax,0x38
   58341:	add    rax,rbx
   58344:	mov    QWORD PTR [rsp+0x190],rax
   5834c:	mov    eax,DWORD PTR [rbp+0x10]
   5834f:	mov    WORD PTR [rsp+0x1a4],ax
   58357:	cmp    WORD PTR [rsp+0x1a4],0x0
   58360:	jbe    583b7 <sqlite3VdbeExec+0x8f17>
   58362:	mov    rax,QWORD PTR [r12+0x30]
   58367:	mov    QWORD PTR [rsp+0x188],rax
   5836f:	mov    BYTE PTR [rsp+0x1a6],0x0
   58377:	mov    rax,QWORD PTR [r12+0x28]
   5837c:	mov    QWORD PTR [rsp+0xf0],r13
   58384:	lea    r13,[rsp+0x188]
   5838c:	mov    rcx,r13
   5838f:	lea    rdx,[r12+0x1c]
   58394:	mov    QWORD PTR [rsp+0xb0],rdi
   5839c:	mov    rdi,rax
   5839f:	mov    rsi,rcx
   583a2:	call   583a7 <sqlite3VdbeExec+0x8f07>
   583a7:	mov    r13d,eax
   583aa:	mov    rdi,QWORD PTR [rsp+0xb0]
   583b2:	jmp    585bd <sqlite3VdbeExec+0x911d>
   583b7:	mov    QWORD PTR [rsp+0xf0],r13
   583bf:	mov    rax,QWORD PTR [rsp+0x190]
   583c7:	movzx  eax,WORD PTR [rax+0x14]
   583cb:	and    eax,0x400
   583d0:	test   eax,eax
   583d2:	je     58467 <sqlite3VdbeExec+0x8fc7>
   583d8:	mov    r13,QWORD PTR [rsp+0x190]
   583e0:	mov    eax,DWORD PTR [r13+0x10]
   583e4:	add    eax,DWORD PTR [r13+0x0]
   583e8:	test   eax,eax
   583ea:	jg     583fd <sqlite3VdbeExec+0x8f5d>
   583ec:	movzx  eax,WORD PTR [r13+0x14]
   583f1:	and    eax,0x10
   583f4:	test   eax,eax
   583f6:	je     58467 <sqlite3VdbeExec+0x8fc7>
   583f8:	mov    eax,0x1
   583fd:	mov    ecx,0x1
   58402:	mov    QWORD PTR [rsp+0xb0],rdi
   5840a:	mov    rdi,r13
   5840d:	mov    rsi,rax
   58410:	mov    rdx,rcx
   58413:	call   58418 <sqlite3VdbeExec+0x8f78>
   58418:	mov    rdi,QWORD PTR [rsp+0xb0]
   58420:	test   eax,eax
   58422:	jne    584ad <sqlite3VdbeExec+0x900d>
   58428:	mov    rax,QWORD PTR [r13+0x8]
   5842c:	movsxd rcx,DWORD PTR [r13+0x10]
   58430:	add    rax,rcx
   58433:	xor    ecx,ecx
   58435:	movsxd rdx,DWORD PTR [r13+0x0]
   58439:	mov    rdi,rax
   5843c:	mov    rsi,rcx
   5843f:	call   58444 <sqlite3VdbeExec+0x8fa4>
   58444:	mov    eax,DWORD PTR [r13+0x10]
   58448:	add    eax,DWORD PTR [r13+0x0]
   5844c:	mov    DWORD PTR [r13+0x10],eax
   58450:	movzx  eax,WORD PTR [r13+0x14]
   58455:	and    eax,0xfffff9ff
   5845a:	mov    WORD PTR [r13+0x14],ax
   5845f:	mov    rdi,QWORD PTR [rsp+0xb0]
   58467:	mov    r13,QWORD PTR [r12+0x30]
   5846c:	movzx  eax,WORD PTR [r13+0x6]
   58471:	add    eax,0x1
   58474:	imul   rax,rax,0x38
   58478:	add    rax,0x28
   5847c:	mov    rcx,QWORD PTR [r13+0x10]
   58480:	test   rcx,rcx
   58483:	je     584d5 <sqlite3VdbeExec+0x9035>
   58485:	mov    QWORD PTR [rsp+0xc8],r14
   5848d:	mov    QWORD PTR [rsp+0xb0],rdi
   58495:	mov    rdi,rcx
   58498:	mov    rsi,rax
   5849b:	call   584a0 <sqlite3VdbeExec+0x9000>
   584a0:	mov    r14,rax
   584a3:	mov    rdi,QWORD PTR [rsp+0xb0]
   584ab:	jmp    584f8 <sqlite3VdbeExec+0x9058>
   584ad:	mov    QWORD PTR [rsp+0xc8],r14
   584b5:	mov    r14,QWORD PTR [rsp+0xc8]
   584bd:	mov    r13,QWORD PTR [rsp+0xf0]
   584c5:	mov    rbx,rbp
   584c8:	mov    rbp,QWORD PTR [rsp+0xf8]
   584d0:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   584d5:	mov    QWORD PTR [rsp+0xc8],r14
   584dd:	mov    QWORD PTR [rsp+0xb0],rdi
   584e5:	mov    rdi,rax
   584e8:	call   584ed <sqlite3VdbeExec+0x904d>
   584ed:	mov    r14,rax
   584f0:	mov    rdi,QWORD PTR [rsp+0xb0]
   584f8:	test   r14,r14
   584fb:	jne    58505 <sqlite3VdbeExec+0x9065>
   584fd:	xor    r13d,r13d
   58500:	mov    r14,r13
   58503:	jmp    5851d <sqlite3VdbeExec+0x907d>
   58505:	lea    rax,[r14+0x28]
   58509:	mov    QWORD PTR [r14+0x8],rax
   5850d:	mov    QWORD PTR [r14],r13
   58510:	movzx  eax,WORD PTR [r13+0x6]
   58515:	add    eax,0x1
   58518:	mov    WORD PTR [r14+0x1c],ax
   5851d:	test   r14,r14
   58520:	jne    58542 <sqlite3VdbeExec+0x90a2>
   58522:	mov    r14,QWORD PTR [rsp+0xc8]
   5852a:	mov    r13,QWORD PTR [rsp+0xf0]
   58532:	mov    rbx,rbp
   58535:	mov    rbp,QWORD PTR [rsp+0xf8]
   5853d:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   58542:	mov    rax,QWORD PTR [rsp+0x190]
   5854a:	mov    eax,DWORD PTR [rax+0x10]
   5854d:	mov    rcx,QWORD PTR [rsp+0x190]
   58555:	mov    rcx,QWORD PTR [rcx+0x8]
   58559:	mov    QWORD PTR [rsp+0xb0],rdi
   58561:	mov    rdi,rax
   58564:	mov    rsi,rcx
   58567:	mov    rdx,r14
   5856a:	call   5856f <sqlite3VdbeExec+0x90cf>
   5856f:	mov    BYTE PTR [r14+0x1e],0x0
   58574:	mov    rax,QWORD PTR [r12+0x28]
   58579:	lea    rcx,[r12+0x1c]
   5857e:	mov    rdi,rax
   58581:	mov    rsi,r14
   58584:	mov    rdx,rcx
   58587:	call   5858c <sqlite3VdbeExec+0x90ec>
   5858c:	mov    r13d,eax
   5858f:	mov    DWORD PTR [rsp+0x338],r13d
   58597:	mov    r13,QWORD PTR [rsp+0xc8]
   5859f:	mov    rdi,r13
   585a2:	mov    rsi,r14
   585a5:	call   585aa <sqlite3VdbeExec+0x910a>
   585aa:	mov    rdi,QWORD PTR [rsp+0xb0]
   585b2:	mov    r14,r13
   585b5:	mov    r13d,DWORD PTR [rsp+0x338]
   585bd:	test   r13d,r13d
   585c0:	je     585e2 <sqlite3VdbeExec+0x9142>
   585c2:	mov    QWORD PTR [rsp+0xe8],rbp
   585ca:	mov    rbp,r13
   585cd:	mov    r13,QWORD PTR [rsp+0xd0]
   585d5:	mov    rbx,QWORD PTR [rsp+0xf8]
   585dd:	jmp    4f712 <sqlite3VdbeExec+0x272>
   585e2:	mov    eax,DWORD PTR [r12+0x1c]
   585e7:	xor    ecx,ecx
   585e9:	test   eax,eax
   585eb:	sete   cl
   585ee:	mov    edx,0x1
   585f3:	sub    edx,ecx
   585f5:	mov    BYTE PTR [r12+0x2],dl
   585fa:	mov    BYTE PTR [r12+0x3],0x0
   58600:	mov    DWORD PTR [r12+0x18],0x0
   58609:	cmp    BYTE PTR [rbp+0x0],0x1d
   5860d:	jne    58623 <sqlite3VdbeExec+0x9183>
   5860f:	test   eax,eax
   58611:	jne    5868a <sqlite3VdbeExec+0x91ea>
   58613:	mov    r12,r14
   58616:	mov    DWORD PTR [rsp+0x32c],r13d
   5861e:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   58623:	test   eax,eax
   58625:	je     58637 <sqlite3VdbeExec+0x9197>
   58627:	mov    r12,r14
   5862a:	mov    DWORD PTR [rsp+0x32c],r13d
   58632:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   58637:	cmp    BYTE PTR [rbp+0x0],0x1b
   5863b:	jne    5867b <sqlite3VdbeExec+0x91db>
   5863d:	xor    eax,eax
   5863f:	jmp    58644 <sqlite3VdbeExec+0x91a4>
   58641:	add    eax,0x1
   58644:	movzx  ecx,WORD PTR [rsp+0x1a4]
   5864c:	cmp    eax,ecx
   5864e:	jge    5867b <sqlite3VdbeExec+0x91db>
   58650:	mov    rcx,QWORD PTR [rsp+0x190]
   58658:	mov    rdx,rax
   5865b:	imul   rdx,rdx,0x38
   5865f:	movzx  ecx,WORD PTR [rcx+rdx*1+0x14]
   58664:	and    ecx,0x1
   58667:	test   ecx,ecx
   58669:	je     58641 <sqlite3VdbeExec+0x91a1>
   5866b:	mov    r12,r14
   5866e:	mov    DWORD PTR [rsp+0x32c],r13d
   58676:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5867b:	cmp    BYTE PTR [rbp+0x0],0x1a
   5867f:	jne    5868a <sqlite3VdbeExec+0x91ea>
   58681:	mov    eax,DWORD PTR [rbp+0x10]
   58684:	mov    WORD PTR [r12+0x6],ax
   5868a:	mov    DWORD PTR [rsp+0x31c],r15d
   58692:	mov    DWORD PTR [rsp+0x32c],r13d
   5869a:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5869f:	mov    r15d,DWORD PTR [rsp+0x31c]
   586a7:	mov    r13,QWORD PTR [rsp+0xf0]
   586af:	mov    QWORD PTR [rsp+0xd0],r12
   586b7:	mov    r12d,DWORD PTR [rsp+0x334]
   586bf:	movsxd rax,DWORD PTR [rbp+0xc]
   586c3:	imul   rax,rax,0x38
   586c7:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   586cc:	and    ecx,0x24
   586cf:	test   ecx,ecx
   586d1:	je     586e0 <sqlite3VdbeExec+0x9240>
   586d3:	mov    DWORD PTR [rsp+0x334],r12d
   586db:	jmp    58784 <sqlite3VdbeExec+0x92e4>
   586e0:	vmovdqu32 xmm0,XMMWORD PTR [rbx+rax*1]
   586e7:	vmovdqu32 XMMWORD PTR [rsp+0x1e0],xmm0
   586ef:	vmovdqu32 xmm0,XMMWORD PTR [rbx+rax*1+0x10]
   586f7:	vmovdqu32 XMMWORD PTR [rsp+0x1f0],xmm0
   586ff:	vmovdqu32 xmm0,XMMWORD PTR [rbx+rax*1+0x20]
   58707:	vmovdqu32 XMMWORD PTR [rsp+0x200],xmm0
   5870f:	vmovdqu32 xmm0,XMMWORD PTR [rbx+rax*1+0x28]
   5871a:	vmovdqu32 XMMWORD PTR [rsp+0x208],xmm0
   58725:	mov    DWORD PTR [rsp+0x334],r12d
   5872d:	lea    r12,[rsp+0x1e0]
   58735:	mov    rax,r12
   58738:	mov    ecx,0x43
   5873d:	mov    edx,r15d
   58740:	mov    QWORD PTR [rsp+0xb0],rdi
   58748:	mov    rdi,rax
   5874b:	mov    rsi,rcx
   5874e:	call   58753 <sqlite3VdbeExec+0x92b3>
   58753:	movzx  eax,WORD PTR [rsp+0x1f4]
   5875b:	and    eax,0x4
   5875e:	mov    rdi,QWORD PTR [rsp+0xb0]
   58766:	test   eax,eax
   58768:	jne    5877a <sqlite3VdbeExec+0x92da>
   5876a:	mov    r12,r14
   5876d:	mov    QWORD PTR [rsp+0xf0],r13
   58775:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5877a:	mov    r12,QWORD PTR [rsp+0x1e0]
   58782:	jmp    58790 <sqlite3VdbeExec+0x92f0>
   58784:	movsxd rax,DWORD PTR [rbp+0xc]
   58788:	imul   rax,rax,0x38
   5878c:	mov    r12,QWORD PTR [rbx+rax*1]
   58790:	mov    rax,QWORD PTR [rdi+0x78]
   58794:	movsxd rcx,DWORD PTR [rbp+0x4]
   58798:	mov    QWORD PTR [rsp+0xf0],r13
   587a0:	mov    r13,QWORD PTR [rax+rcx*8]
   587a4:	mov    rax,QWORD PTR [r13+0x28]
   587a8:	mov    DWORD PTR [rsp+0x318],0x0
   587b3:	xor    ecx,ecx
   587b5:	mov    DWORD PTR [rsp+0x31c],r15d
   587bd:	lea    r15,[rsp+0x318]
   587c5:	mov    rdx,r15
   587c8:	mov    QWORD PTR [rsp+0xb0],rdi
   587d0:	mov    rdi,rax
   587d3:	mov    rsi,r12
   587d6:	mov    r11,rdx
   587d9:	mov    rdx,rcx
   587dc:	mov    rcx,r11
   587df:	call   587e4 <sqlite3VdbeExec+0x9344>
   587e4:	mov    r15d,eax
   587e7:	mov    QWORD PTR [r13+0x48],r12
   587eb:	mov    BYTE PTR [r13+0x2],0x0
   587f0:	mov    DWORD PTR [r13+0x18],0x0
   587f8:	mov    BYTE PTR [r13+0x3],0x0
   587fd:	mov    eax,DWORD PTR [rsp+0x318]
   58804:	mov    DWORD PTR [r13+0x1c],eax
   58808:	mov    rdi,QWORD PTR [rsp+0xb0]
   58810:	cmp    DWORD PTR [rsp+0x318],0x0
   58818:	je     5884a <sqlite3VdbeExec+0x93aa>
   5881a:	cmp    DWORD PTR [rbp+0x8],0x0
   5881e:	jne    5886f <sqlite3VdbeExec+0x93cf>
   58820:	mov    eax,0x18e86
   58825:	mov    ecx,0xb
   5882a:	lea    rdx,[rip+0x0]        # 58831 <sqlite3VdbeExec+0x9391>
   58831:	mov    rdi,rcx
   58834:	mov    rsi,rax
   58837:	call   5883c <sqlite3VdbeExec+0x939c>
   5883c:	mov    r12d,eax
   5883f:	mov    rdi,QWORD PTR [rsp+0xb0]
   58847:	mov    r15,r12
   5884a:	test   r15d,r15d
   5884d:	je     5888a <sqlite3VdbeExec+0x93ea>
   5884f:	mov    QWORD PTR [rsp+0xe8],rbp
   58857:	mov    rbp,r15
   5885a:	mov    r13,QWORD PTR [rsp+0xd0]
   58862:	mov    rbx,QWORD PTR [rsp+0xf8]
   5886a:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5886f:	mov    r12,r14
   58872:	mov    r14,r15
   58875:	mov    r15d,DWORD PTR [rsp+0x31c]
   5887d:	mov    DWORD PTR [rsp+0x32c],r14d
   58885:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5888a:	mov    DWORD PTR [rsp+0x32c],r15d
   58892:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   58897:	mov    r15d,DWORD PTR [rsp+0x31c]
   5889f:	mov    r13,QWORD PTR [rsp+0xf0]
   588a7:	mov    QWORD PTR [rsp+0xd0],r12
   588af:	mov    r12d,DWORD PTR [rsp+0x334]
   588b7:	mov    rax,QWORD PTR [rdi+0x68]
   588bb:	movsxd rcx,DWORD PTR [rbp+0x8]
   588bf:	imul   rcx,rcx,0x38
   588c3:	lea    rdx,[rax+rcx*1]
   588c7:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   588cc:	and    eax,0x9000
   588d1:	test   eax,eax
   588d3:	je     588f2 <sqlite3VdbeExec+0x9452>
   588d5:	mov    QWORD PTR [rsp+0xb0],rdi
   588dd:	mov    rdi,rdx
   588e0:	call   588e5 <sqlite3VdbeExec+0x9445>
   588e5:	mov    rdi,QWORD PTR [rsp+0xb0]
   588ed:	mov    rdx,rax
   588f0:	jmp    588f8 <sqlite3VdbeExec+0x9458>
   588f2:	mov    WORD PTR [rdx+0x14],0x4
   588f8:	mov    rax,QWORD PTR [rdi+0x78]
   588fc:	movsxd rcx,DWORD PTR [rbp+0x4]
   58900:	mov    rax,QWORD PTR [rax+rcx*8]
   58904:	mov    rcx,QWORD PTR [rax+0x10]
   58908:	lea    rsi,[rcx+0x1]
   5890c:	mov    QWORD PTR [rax+0x10],rsi
   58910:	mov    QWORD PTR [rdx],rcx
   58913:	mov    DWORD PTR [rsp+0x31c],r15d
   5891b:	mov    QWORD PTR [rsp+0xf0],r13
   58923:	mov    DWORD PTR [rsp+0x334],r12d
   5892b:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   58930:	mov    r15d,DWORD PTR [rsp+0x31c]
   58938:	mov    r13,QWORD PTR [rsp+0xf0]
   58940:	mov    QWORD PTR [rsp+0xd0],r12
   58948:	mov    r12d,DWORD PTR [rsp+0x334]
   58950:	mov    QWORD PTR [rsp+0x128],0x0
   5895c:	mov    DWORD PTR [rsp+0x338],0x0
   58967:	mov    rax,QWORD PTR [rdi+0x68]
   5896b:	movsxd rcx,DWORD PTR [rbp+0x8]
   5896f:	imul   rcx,rcx,0x38
   58973:	mov    DWORD PTR [rsp+0x334],r12d
   5897b:	lea    r12,[rax+rcx*1]
   5897f:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   58984:	and    eax,0x9000
   58989:	test   eax,eax
   5898b:	je     589aa <sqlite3VdbeExec+0x950a>
   5898d:	mov    QWORD PTR [rsp+0xb0],rdi
   58995:	mov    rdi,r12
   58998:	call   5899d <sqlite3VdbeExec+0x94fd>
   5899d:	mov    r12,rax
   589a0:	mov    rdi,QWORD PTR [rsp+0xb0]
   589a8:	jmp    589b2 <sqlite3VdbeExec+0x9512>
   589aa:	mov    WORD PTR [r12+0x14],0x4
   589b2:	mov    rax,QWORD PTR [rdi+0x78]
   589b6:	movsxd rcx,DWORD PTR [rbp+0x4]
   589ba:	mov    QWORD PTR [rsp+0x108],r12
   589c2:	mov    r12,QWORD PTR [rax+rcx*8]
   589c6:	movzx  eax,BYTE PTR [r12+0x5]
   589cc:	shl    rax,0x3e
   589d0:	shr    rax,0x3f
   589d4:	test   eax,eax
   589d6:	je     589e5 <sqlite3VdbeExec+0x9545>
   589d8:	mov    QWORD PTR [rsp+0x118],r12
   589e0:	jmp    58b28 <sqlite3VdbeExec+0x9688>
   589e5:	mov    rax,QWORD PTR [r12+0x28]
   589ea:	mov    QWORD PTR [rsp+0x118],r12
   589f2:	lea    r12,[rsp+0x338]
   589fa:	mov    rcx,r12
   589fd:	xor    edx,edx
   589ff:	movzx  esi,BYTE PTR [rax]
   58a02:	cmp    edx,esi
   58a04:	jne    58a1c <sqlite3VdbeExec+0x957c>
   58a06:	movzx  edx,BYTE PTR [rax+0x1]
   58a0a:	and    edx,0x8
   58a0d:	test   edx,edx
   58a0f:	je     58a1c <sqlite3VdbeExec+0x957c>
   58a11:	mov    DWORD PTR [rcx],0x0
   58a17:	xor    r12d,r12d
   58a1a:	jmp    58a3a <sqlite3VdbeExec+0x959a>
   58a1c:	mov    QWORD PTR [rsp+0xb0],rdi
   58a24:	mov    rdi,rax
   58a27:	mov    rsi,rcx
   58a2a:	call   58a2f <sqlite3VdbeExec+0x958f>
   58a2f:	mov    r12d,eax
   58a32:	mov    rdi,QWORD PTR [rsp+0xb0]
   58a3a:	test   r12d,r12d
   58a3d:	je     58a67 <sqlite3VdbeExec+0x95c7>
   58a3f:	mov    QWORD PTR [rsp+0xf0],r13
   58a47:	mov    QWORD PTR [rsp+0xe8],rbp
   58a4f:	mov    rbp,r12
   58a52:	mov    r13,QWORD PTR [rsp+0xd0]
   58a5a:	mov    rbx,QWORD PTR [rsp+0xf8]
   58a62:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58a67:	cmp    DWORD PTR [rsp+0x338],0x0
   58a6f:	je     58a8a <sqlite3VdbeExec+0x95ea>
   58a71:	mov    QWORD PTR [rsp+0x128],0x1
   58a7d:	mov    DWORD PTR [rsp+0x32c],r12d
   58a85:	jmp    58b28 <sqlite3VdbeExec+0x9688>
   58a8a:	mov    DWORD PTR [rsp+0x32c],r12d
   58a92:	mov    r12,QWORD PTR [rsp+0x118]
   58a9a:	mov    QWORD PTR [rsp+0xf0],r13
   58aa2:	mov    r13,QWORD PTR [r12+0x28]
   58aa7:	mov    QWORD PTR [rsp+0xb0],rdi
   58aaf:	mov    rdi,r13
   58ab2:	call   58ab7 <sqlite3VdbeExec+0x9617>
   58ab7:	mov    rax,QWORD PTR [r13+0x30]
   58abb:	mov    QWORD PTR [rsp+0x128],rax
   58ac3:	movabs rax,0x7fffffffffffffff
   58acd:	mov    rdi,QWORD PTR [rsp+0xb0]
   58ad5:	cmp    rax,QWORD PTR [rsp+0x128]
   58add:	jg     58b04 <sqlite3VdbeExec+0x9664>
   58adf:	movzx  eax,BYTE PTR [r12+0x5]
   58ae5:	and    rax,0xfffffffffffffffd
   58ae9:	or     rax,0x2
   58aed:	mov    BYTE PTR [r12+0x5],al
   58af2:	mov    QWORD PTR [rsp+0x118],r12
   58afa:	mov    r13,QWORD PTR [rsp+0xf0]
   58b02:	jmp    58b28 <sqlite3VdbeExec+0x9688>
   58b04:	mov    rax,QWORD PTR [rsp+0x128]
   58b0c:	add    rax,0x1
   58b10:	mov    QWORD PTR [rsp+0x128],rax
   58b18:	mov    QWORD PTR [rsp+0x118],r12
   58b20:	mov    r13,QWORD PTR [rsp+0xf0]
   58b28:	cmp    DWORD PTR [rbp+0xc],0x0
   58b2c:	jne    58b43 <sqlite3VdbeExec+0x96a3>
   58b2e:	mov    QWORD PTR [rsp+0xf0],r13
   58b36:	mov    r13,QWORD PTR [rsp+0x118]
   58b3e:	jmp    58cc3 <sqlite3VdbeExec+0x9823>
   58b43:	cmp    QWORD PTR [rdi+0x108],0x0
   58b4b:	je     58b73 <sqlite3VdbeExec+0x96d3>
   58b4d:	mov    rax,QWORD PTR [rdi+0x108]
   58b54:	jmp    58b5a <sqlite3VdbeExec+0x96ba>
   58b56:	mov    rax,QWORD PTR [rax+0x8]
   58b5a:	cmp    QWORD PTR [rax+0x8],0x0
   58b5f:	jne    58b56 <sqlite3VdbeExec+0x96b6>
   58b61:	mov    rax,QWORD PTR [rax+0x18]
   58b65:	movsxd rcx,DWORD PTR [rbp+0xc]
   58b69:	imul   rcx,rcx,0x38
   58b6d:	lea    r12,[rax+rcx*1]
   58b71:	jmp    58b7f <sqlite3VdbeExec+0x96df>
   58b73:	movsxd rax,DWORD PTR [rbp+0xc]
   58b77:	imul   rax,rax,0x38
   58b7b:	lea    r12,[rbx+rax*1]
   58b7f:	movzx  eax,WORD PTR [r12+0x14]
   58b85:	mov    ecx,eax
   58b87:	and    ecx,0x24
   58b8a:	test   ecx,ecx
   58b8c:	je     58b97 <sqlite3VdbeExec+0x96f7>
   58b8e:	mov    rax,QWORD PTR [r12]
   58b92:	jmp    58c1a <sqlite3VdbeExec+0x977a>
   58b97:	mov    ecx,eax
   58b99:	and    ecx,0x8
   58b9c:	test   ecx,ecx
   58b9e:	je     58bef <sqlite3VdbeExec+0x974f>
   58ba0:	movsd  xmm0,QWORD PTR [r12]
   58ba6:	movabs r11,0xc3dfffffffffffff
   58bb0:	movq   xmm1,r11
   58bb5:	ucomisd xmm1,xmm0
   58bb9:	jbe    58bc7 <sqlite3VdbeExec+0x9727>
   58bbb:	movabs rax,0x8000000000000000
   58bc5:	jmp    58bed <sqlite3VdbeExec+0x974d>
   58bc7:	movabs r11,0x43dfffffffffffff
   58bd1:	movq   xmm1,r11
   58bd6:	ucomisd xmm0,xmm1
   58bda:	jbe    58be8 <sqlite3VdbeExec+0x9748>
   58bdc:	movabs rax,0x7fffffffffffffff
   58be6:	jmp    58bed <sqlite3VdbeExec+0x974d>
   58be8:	cvttsd2si rax,xmm0
   58bed:	jmp    58c1a <sqlite3VdbeExec+0x977a>
   58bef:	and    eax,0x12
   58bf2:	test   eax,eax
   58bf4:	je     58c18 <sqlite3VdbeExec+0x9778>
   58bf6:	cmp    QWORD PTR [r12+0x8],0x0
   58bfc:	je     58c18 <sqlite3VdbeExec+0x9778>
   58bfe:	mov    QWORD PTR [rsp+0xb0],rdi
   58c06:	mov    rdi,r12
   58c09:	call   58c0e <sqlite3VdbeExec+0x976e>
   58c0e:	mov    rdi,QWORD PTR [rsp+0xb0]
   58c16:	jmp    58c1a <sqlite3VdbeExec+0x977a>
   58c18:	xor    eax,eax
   58c1a:	mov    QWORD PTR [r12],rax
   58c1e:	movzx  eax,WORD PTR [r12+0x14]
   58c24:	and    eax,0xfffff240
   58c29:	or     eax,0x4
   58c2c:	mov    WORD PTR [r12+0x14],ax
   58c32:	movabs rax,0x7fffffffffffffff
   58c3c:	cmp    rax,QWORD PTR [r12]
   58c40:	jne    58c4c <sqlite3VdbeExec+0x97ac>
   58c42:	mov    QWORD PTR [rsp+0xf0],r13
   58c4a:	jmp    58c6d <sqlite3VdbeExec+0x97cd>
   58c4c:	mov    QWORD PTR [rsp+0xf0],r13
   58c54:	mov    r13,QWORD PTR [rsp+0x118]
   58c5c:	movzx  eax,BYTE PTR [r13+0x5]
   58c61:	shl    rax,0x3e
   58c65:	shr    rax,0x3f
   58c69:	test   eax,eax
   58c6b:	je     58c92 <sqlite3VdbeExec+0x97f2>
   58c6d:	mov    ebx,0xd
   58c72:	mov    QWORD PTR [rsp+0xe8],rbp
   58c7a:	mov    rbp,rbx
   58c7d:	mov    r13,QWORD PTR [rsp+0xd0]
   58c85:	mov    rbx,QWORD PTR [rsp+0xf8]
   58c8d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58c92:	mov    rax,QWORD PTR [rsp+0x128]
   58c9a:	mov    rcx,QWORD PTR [r12]
   58c9e:	add    rcx,0x1
   58ca2:	cmp    rax,rcx
   58ca5:	jge    58cb7 <sqlite3VdbeExec+0x9817>
   58ca7:	mov    rax,QWORD PTR [r12]
   58cab:	add    rax,0x1
   58caf:	mov    QWORD PTR [rsp+0x128],rax
   58cb7:	mov    rax,QWORD PTR [rsp+0x128]
   58cbf:	mov    QWORD PTR [r12],rax
   58cc3:	movzx  eax,BYTE PTR [r13+0x5]
   58cc8:	shl    rax,0x3e
   58ccc:	shr    rax,0x3f
   58cd0:	test   eax,eax
   58cd2:	jne    58ce1 <sqlite3VdbeExec+0x9841>
   58cd4:	mov    r12,QWORD PTR [rsp+0x108]
   58cdc:	jmp    58e14 <sqlite3VdbeExec+0x9974>
   58ce1:	xor    r12d,r12d
   58ce4:	mov    eax,0x8
   58ce9:	mov    QWORD PTR [rsp+0xc8],r14
   58cf1:	lea    r14,[rsp+0x128]
   58cf9:	mov    rcx,r14
   58cfc:	mov    QWORD PTR [rsp+0xb0],rdi
   58d04:	mov    rdi,rax
   58d07:	mov    rsi,rcx
   58d0a:	call   58d0f <sqlite3VdbeExec+0x986f>
   58d0f:	movabs rax,0x3fffffffffffffff
   58d19:	and    rax,QWORD PTR [rsp+0x128]
   58d21:	mov    QWORD PTR [rsp+0x128],rax
   58d29:	mov    rax,QWORD PTR [rsp+0x128]
   58d31:	add    rax,0x1
   58d35:	mov    QWORD PTR [rsp+0x128],rax
   58d3d:	mov    rax,QWORD PTR [r13+0x28]
   58d41:	mov    rcx,QWORD PTR [rsp+0x128]
   58d49:	xor    edx,edx
   58d4b:	lea    r14,[rsp+0x338]
   58d53:	mov    rsi,r14
   58d56:	mov    rdi,rax
   58d59:	mov    r11,rsi
   58d5c:	mov    rsi,rcx
   58d5f:	mov    rcx,r11
   58d62:	call   58d67 <sqlite3VdbeExec+0x98c7>
   58d67:	mov    r14d,eax
   58d6a:	mov    rdi,QWORD PTR [rsp+0xb0]
   58d72:	test   r14d,r14d
   58d75:	jne    58d98 <sqlite3VdbeExec+0x98f8>
   58d77:	cmp    DWORD PTR [rsp+0x338],0x0
   58d7f:	jne    58d98 <sqlite3VdbeExec+0x98f8>
   58d81:	add    r12d,0x1
   58d85:	cmp    r12d,0x64
   58d89:	jge    58d98 <sqlite3VdbeExec+0x98f8>
   58d8b:	mov    r14,QWORD PTR [rsp+0xc8]
   58d93:	jmp    58ce4 <sqlite3VdbeExec+0x9844>
   58d98:	test   r14d,r14d
   58d9b:	je     58dc5 <sqlite3VdbeExec+0x9925>
   58d9d:	mov    QWORD PTR [rsp+0xe8],rbp
   58da5:	mov    rbp,r14
   58da8:	mov    r14,QWORD PTR [rsp+0xc8]
   58db0:	mov    r13,QWORD PTR [rsp+0xd0]
   58db8:	mov    rbx,QWORD PTR [rsp+0xf8]
   58dc0:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58dc5:	cmp    DWORD PTR [rsp+0x338],0x0
   58dcd:	jne    58dfc <sqlite3VdbeExec+0x995c>
   58dcf:	mov    ebx,0xd
   58dd4:	mov    r14,QWORD PTR [rsp+0xc8]
   58ddc:	mov    QWORD PTR [rsp+0xe8],rbp
   58de4:	mov    rbp,rbx
   58de7:	mov    r13,QWORD PTR [rsp+0xd0]
   58def:	mov    rbx,QWORD PTR [rsp+0xf8]
   58df7:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58dfc:	mov    r12,QWORD PTR [rsp+0x108]
   58e04:	mov    DWORD PTR [rsp+0x32c],r14d
   58e0c:	mov    r14,QWORD PTR [rsp+0xc8]
   58e14:	mov    BYTE PTR [r13+0x3],0x0
   58e19:	mov    DWORD PTR [r13+0x18],0x0
   58e21:	mov    rax,QWORD PTR [rsp+0x128]
   58e29:	mov    QWORD PTR [r12],rax
   58e2d:	mov    DWORD PTR [rsp+0x31c],r15d
   58e35:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   58e3a:	mov    r15d,DWORD PTR [rsp+0x31c]
   58e42:	mov    QWORD PTR [rsp+0xd0],r12
   58e4a:	movsxd rax,DWORD PTR [rbp+0x8]
   58e4e:	imul   rax,rax,0x38
   58e52:	mov    rcx,QWORD PTR [rdi+0x78]
   58e56:	movsxd rdx,DWORD PTR [rbp+0x4]
   58e5a:	mov    r12,QWORD PTR [rcx+rdx*8]
   58e5e:	movsxd rcx,DWORD PTR [rbp+0xc]
   58e62:	imul   rcx,rcx,0x38
   58e66:	mov    rcx,QWORD PTR [rbx+rcx*1]
   58e6a:	mov    QWORD PTR [rsp+0x1b8],rcx
   58e72:	cmp    BYTE PTR [rbp+0x1],0xfb
   58e76:	je     58e82 <sqlite3VdbeExec+0x99e2>
   58e78:	mov    QWORD PTR [rsp+0x128],r12
   58e80:	jmp    58eb6 <sqlite3VdbeExec+0x9a16>
   58e82:	cmp    QWORD PTR [r14+0x138],0x0
   58e8a:	jne    58e96 <sqlite3VdbeExec+0x99f6>
   58e8c:	mov    QWORD PTR [rsp+0x128],r12
   58e94:	jmp    58eb6 <sqlite3VdbeExec+0x9a16>
   58e96:	mov    rcx,QWORD PTR [r14+0x20]
   58e9a:	movsx  rdx,BYTE PTR [r12+0x1]
   58ea0:	shl    rdx,0x5
   58ea4:	mov    r13,QWORD PTR [rcx+rdx*1]
   58ea8:	mov    QWORD PTR [rsp+0x128],r12
   58eb0:	mov    r12,QWORD PTR [rbp+0x10]
   58eb4:	jmp    58ebc <sqlite3VdbeExec+0x9a1c>
   58eb6:	xor    r12d,r12d
   58eb9:	xor    r13d,r13d
   58ebc:	movzx  ecx,WORD PTR [rbp+0x2]
   58ec0:	and    ecx,0x1
   58ec3:	test   ecx,ecx
   58ec5:	je     58eea <sqlite3VdbeExec+0x9a4a>
   58ec7:	mov    rcx,QWORD PTR [rdi+0x38]
   58ecb:	add    rcx,0x1
   58ecf:	mov    QWORD PTR [rdi+0x38],rcx
   58ed3:	movzx  ecx,WORD PTR [rbp+0x2]
   58ed7:	and    ecx,0x20
   58eda:	test   ecx,ecx
   58edc:	je     58eea <sqlite3VdbeExec+0x9a4a>
   58ede:	mov    rcx,QWORD PTR [rsp+0x1b8]
   58ee6:	mov    QWORD PTR [r14+0x38],rcx
   58eea:	mov    rcx,QWORD PTR [rbx+rax*1+0x8]
   58eef:	mov    QWORD PTR [rsp+0x1c0],rcx
   58ef7:	mov    ecx,DWORD PTR [rbx+rax*1+0x10]
   58efb:	mov    DWORD PTR [rsp+0x1d4],ecx
   58f02:	movzx  ecx,WORD PTR [rbp+0x2]
   58f06:	and    ecx,0x10
   58f09:	test   ecx,ecx
   58f0b:	je     58f23 <sqlite3VdbeExec+0x9a83>
   58f0d:	mov    QWORD PTR [rsp+0x108],r13
   58f15:	mov    r13,QWORD PTR [rsp+0x128]
   58f1d:	mov    ecx,DWORD PTR [r13+0x1c]
   58f21:	jmp    58f35 <sqlite3VdbeExec+0x9a95>
   58f23:	mov    QWORD PTR [rsp+0x108],r13
   58f2b:	mov    r13,QWORD PTR [rsp+0x128]
   58f33:	xor    ecx,ecx
   58f35:	movzx  edx,WORD PTR [rbx+rax*1+0x14]
   58f3a:	and    edx,0x400
   58f40:	test   edx,edx
   58f42:	je     58f50 <sqlite3VdbeExec+0x9ab0>
   58f44:	mov    eax,DWORD PTR [rbx+rax*1]
   58f47:	mov    DWORD PTR [rsp+0x1d8],eax
   58f4e:	jmp    58f5b <sqlite3VdbeExec+0x9abb>
   58f50:	mov    DWORD PTR [rsp+0x1d8],0x0
   58f5b:	mov    QWORD PTR [rsp+0x1b0],0x0
   58f67:	mov    rax,QWORD PTR [r13+0x28]
   58f6b:	mov    QWORD PTR [rsp+0xc8],r14
   58f73:	lea    r14,[rsp+0x1b0]
   58f7b:	mov    rdx,r14
   58f7e:	movzx  esi,WORD PTR [rbp+0x2]
   58f82:	and    esi,0x8a
   58f88:	mov    QWORD PTR [rsp+0xb0],rdi
   58f90:	mov    rdi,rax
   58f93:	mov    r11,rsi
   58f96:	mov    rsi,rdx
   58f99:	mov    rdx,r11
   58f9c:	call   58fa1 <sqlite3VdbeExec+0x9b01>
   58fa1:	mov    r14d,eax
   58fa4:	mov    BYTE PTR [r13+0x3],0x0
   58fa9:	mov    DWORD PTR [r13+0x18],0x0
   58fb1:	mov    r13d,DWORD PTR [rsp+0x334]
   58fb9:	add    r13d,0x1
   58fbd:	mov    rdi,QWORD PTR [rsp+0xb0]
   58fc5:	test   r14d,r14d
   58fc8:	je     58ff2 <sqlite3VdbeExec+0x9b52>
   58fca:	mov    QWORD PTR [rsp+0xe8],rbp
   58fd2:	mov    rbp,r14
   58fd5:	mov    r14,QWORD PTR [rsp+0xc8]
   58fdd:	mov    r13,QWORD PTR [rsp+0xd0]
   58fe5:	mov    rbx,QWORD PTR [rsp+0xf8]
   58fed:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58ff2:	test   r12,r12
   58ff5:	jne    59009 <sqlite3VdbeExec+0x9b69>
   58ff7:	mov    DWORD PTR [rsp+0x334],r13d
   58fff:	mov    r13,QWORD PTR [rsp+0xc8]
   59007:	jmp    59074 <sqlite3VdbeExec+0x9bd4>
   59009:	mov    DWORD PTR [rsp+0x334],r13d
   59011:	mov    r13,QWORD PTR [rsp+0xc8]
   59019:	mov    rax,QWORD PTR [r13+0x138]
   59020:	mov    rcx,QWORD PTR [r13+0x130]
   59027:	movzx  edx,WORD PTR [rbp+0x2]
   5902b:	and    edx,0x4
   5902e:	test   edx,edx
   59030:	je     59039 <sqlite3VdbeExec+0x9b99>
   59032:	mov    edx,0x17
   59037:	jmp    5903e <sqlite3VdbeExec+0x9b9e>
   59039:	mov    edx,0x12
   5903e:	mov    rsi,QWORD PTR [r12]
   59042:	mov    r8,QWORD PTR [rsp+0x1b8]
   5904a:	mov    r12,QWORD PTR [rsp+0x108]
   59052:	mov    QWORD PTR [rsp+0xb0],rdi
   5905a:	mov    rdi,rcx
   5905d:	mov    rcx,rsi
   59060:	mov    rsi,rdx
   59063:	mov    rdx,r12
   59066:	mov    r10,rax
   59069:	call   r10
   5906c:	mov    rdi,QWORD PTR [rsp+0xb0]
   59074:	mov    DWORD PTR [rsp+0x31c],r15d
   5907c:	mov    DWORD PTR [rsp+0x32c],r14d
   59084:	mov    r14,r13
   59087:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5908c:	mov    r15d,DWORD PTR [rsp+0x31c]
   59094:	mov    r13,QWORD PTR [rsp+0xf0]
   5909c:	mov    QWORD PTR [rsp+0xd0],r12
   590a4:	mov    r12d,DWORD PTR [rsp+0x334]
   590ac:	mov    rax,QWORD PTR [rdi+0x78]
   590b0:	movsxd rcx,DWORD PTR [rbp+0x4]
   590b4:	mov    rax,QWORD PTR [rax+rcx*8]
   590b8:	mov    rcx,QWORD PTR [rdi+0x78]
   590bc:	movsxd rdx,DWORD PTR [rbp+0x8]
   590c0:	mov    rcx,QWORD PTR [rcx+rdx*8]
   590c4:	cmp    DWORD PTR [rbp+0xc],0x0
   590c8:	je     590e0 <sqlite3VdbeExec+0x9c40>
   590ca:	movsxd rdx,DWORD PTR [rbp+0xc]
   590ce:	imul   rdx,rdx,0x38
   590d2:	mov    DWORD PTR [rsp+0x334],r12d
   590da:	mov    r12,QWORD PTR [rbx+rdx*1]
   590de:	jmp    590eb <sqlite3VdbeExec+0x9c4b>
   590e0:	mov    DWORD PTR [rsp+0x334],r12d
   590e8:	xor    r12d,r12d
   590eb:	mov    QWORD PTR [rsp+0x108],r12
   590f3:	mov    r12,QWORD PTR [rax+0x28]
   590f7:	mov    QWORD PTR [rsp+0xf0],r13
   590ff:	mov    r13,QWORD PTR [rcx+0x28]
   59103:	mov    QWORD PTR [rsp+0x128],r12
   5910b:	mov    r12,QWORD PTR [r12+0x20]
   59110:	mov    QWORD PTR [rsp+0x110],r12
   59118:	mov    r12,QWORD PTR [r12+0x88]
   59120:	mov    QWORD PTR [rsp+0xb0],rdi
   59128:	mov    rdi,r13
   5912b:	call   59130 <sqlite3VdbeExec+0x9c90>
   59130:	mov    rdi,QWORD PTR [rsp+0xb0]
   59138:	cmp    DWORD PTR [r13+0x40],0x80
   59140:	jae    59164 <sqlite3VdbeExec+0x9cc4>
   59142:	mov    DWORD PTR [rsp+0x31c],r15d
   5914a:	lea    r15,[r12+0x1]
   5914f:	mov    eax,DWORD PTR [r13+0x40]
   59153:	mov    BYTE PTR [r12],al
   59157:	mov    r12,r15
   5915a:	lea    r8,[rsp+0x324]
   59162:	jmp    591dc <sqlite3VdbeExec+0x9d3c>
   59164:	mov    DWORD PTR [rsp+0x31c],r15d
   5916c:	lea    r8,[rsp+0x324]
   59174:	mov    eax,DWORD PTR [r13+0x40]
   59178:	cmp    rax,0x7f
   5917c:	ja     5918d <sqlite3VdbeExec+0x9ced>
   5917e:	and    rax,0x7f
   59182:	mov    BYTE PTR [r12],al
   59186:	mov    eax,0x1
   5918b:	jmp    591d6 <sqlite3VdbeExec+0x9d36>
   5918d:	cmp    rax,0x3fff
   59193:	ja     591bb <sqlite3VdbeExec+0x9d1b>
   59195:	mov    rcx,rax
   59198:	shr    rcx,0x7
   5919c:	and    rcx,0x7f
   591a0:	or     rcx,0x80
   591a7:	mov    BYTE PTR [r12],cl
   591ab:	and    rax,0x7f
   591af:	mov    BYTE PTR [r12+0x1],al
   591b4:	mov    eax,0x2
   591b9:	jmp    591d6 <sqlite3VdbeExec+0x9d36>
   591bb:	mov    rdi,r12
   591be:	mov    rsi,rax
   591c1:	call   591c6 <sqlite3VdbeExec+0x9d26>
   591c6:	mov    rdi,QWORD PTR [rsp+0xb0]
   591ce:	lea    r8,[rsp+0x324]
   591d6:	movsxd rax,eax
   591d9:	add    r12,rax
   591dc:	mov    r15,QWORD PTR [rsp+0x128]
   591e4:	cmp    QWORD PTR [r15+0x80],0x0
   591ec:	jne    59268 <sqlite3VdbeExec+0x9dc8>
   591ee:	mov    r15,QWORD PTR [rsp+0x108]
   591f6:	cmp    r15,0x7f
   591fa:	ja     5920e <sqlite3VdbeExec+0x9d6e>
   591fc:	mov    rax,r15
   591ff:	and    rax,0x7f
   59203:	mov    BYTE PTR [r12],al
   59207:	mov    eax,0x1
   5920c:	jmp    59262 <sqlite3VdbeExec+0x9dc2>
   5920e:	cmp    r15,0x3fff
   59215:	ja     5923f <sqlite3VdbeExec+0x9d9f>
   59217:	mov    rax,r15
   5921a:	shr    rax,0x7
   5921e:	and    rax,0x7f
   59222:	or     rax,0x80
   59228:	mov    BYTE PTR [r12],al
   5922c:	mov    rax,r15
   5922f:	and    rax,0x7f
   59233:	mov    BYTE PTR [r12+0x1],al
   59238:	mov    eax,0x2
   5923d:	jmp    59262 <sqlite3VdbeExec+0x9dc2>
   5923f:	mov    QWORD PTR [rsp+0xb0],rdi
   59247:	mov    rdi,r12
   5924a:	mov    rsi,r15
   5924d:	call   59252 <sqlite3VdbeExec+0x9db2>
   59252:	mov    rdi,QWORD PTR [rsp+0xb0]
   5925a:	lea    r8,[rsp+0x324]
   59262:	movsxd rax,eax
   59265:	add    r12,rax
   59268:	movzx  eax,WORD PTR [r13+0x44]
   5926d:	mov    r15d,eax
   59270:	mov    QWORD PTR [rsp+0x100],rbx
   59278:	mov    rbx,QWORD PTR [r13+0x38]
   5927c:	mov    rax,r15
   5927f:	add    rax,rbx
   59282:	mov    rcx,QWORD PTR [r13+0x88]
   59289:	cmp    rax,QWORD PTR [rcx+0x58]
   5928d:	jbe    592cb <sqlite3VdbeExec+0x9e2b>
   5928f:	mov    eax,0x143bd
   59294:	mov    ecx,0xb
   59299:	lea    rdx,[rip+0x0]        # 592a0 <sqlite3VdbeExec+0x9e00>
   592a0:	mov    QWORD PTR [rsp+0xb0],rdi
   592a8:	mov    rdi,rcx
   592ab:	mov    rsi,rax
   592ae:	call   592b3 <sqlite3VdbeExec+0x9e13>
   592b3:	mov    ebx,eax
   592b5:	mov    rdi,QWORD PTR [rsp+0xb0]
   592bd:	mov    r11,rbx
   592c0:	mov    rbx,rbp
   592c3:	mov    rbp,r11
   592c6:	jmp    59ba1 <sqlite3VdbeExec+0xa701>
   592cb:	mov    QWORD PTR [rsp+0xc8],r14
   592d3:	mov    r14d,DWORD PTR [r13+0x40]
   592d7:	cmp    r15d,r14d
   592da:	je     59301 <sqlite3VdbeExec+0x9e61>
   592dc:	mov    QWORD PTR [rsp+0x108],rbx
   592e4:	mov    rbx,QWORD PTR [rsp+0x110]
   592ec:	mov    QWORD PTR [rsp+0xe8],rbp
   592f4:	mov    rbp,QWORD PTR [rsp+0x128]
   592fc:	jmp    59386 <sqlite3VdbeExec+0x9ee6>
   59301:	mov    QWORD PTR [rsp+0xe8],rbp
   59309:	mov    rbp,QWORD PTR [rsp+0x128]
   59311:	mov    rax,QWORD PTR [rbp+0x88]
   59318:	movzx  eax,WORD PTR [rax+0xe]
   5931c:	cmp    r15d,eax
   5931f:	jb     59333 <sqlite3VdbeExec+0x9e93>
   59321:	mov    QWORD PTR [rsp+0x108],rbx
   59329:	mov    rbx,QWORD PTR [rsp+0x110]
   59331:	jmp    59386 <sqlite3VdbeExec+0x9ee6>
   59333:	mov    rax,r15
   59336:	mov    QWORD PTR [rsp+0xb0],rdi
   5933e:	mov    rdi,r12
   59341:	mov    rsi,rbx
   59344:	mov    rdx,rax
   59347:	call   5934c <sqlite3VdbeExec+0x9eac>
   5934c:	mov    rbx,QWORD PTR [rsp+0x110]
   59354:	mov    rax,r12
   59357:	sub    rax,QWORD PTR [rbx+0x88]
   5935e:	add    eax,r15d
   59361:	mov    DWORD PTR [rbx+0x90],eax
   59367:	xor    ebp,ebp
   59369:	mov    rdi,QWORD PTR [rsp+0xb0]
   59371:	mov    r14,QWORD PTR [rsp+0xc8]
   59379:	mov    rbx,QWORD PTR [rsp+0xe8]
   59381:	jmp    59ba1 <sqlite3VdbeExec+0xa701>
   59386:	mov    DWORD PTR [r8],0x0
   5938d:	mov    rax,QWORD PTR [r13+0x20]
   59391:	mov    DWORD PTR [rsp+0x338],r14d
   59399:	mov    r14,QWORD PTR [rax]
   5939c:	mov    QWORD PTR [rsp+0x120],r14
   593a4:	lea    r14,[rsp+0xd8]
   593ac:	mov    QWORD PTR [r14],0x0
   593b3:	xor    r14d,r14d
   593b6:	mov    rax,QWORD PTR [rbp+0x88]
   593bd:	mov    ecx,DWORD PTR [r13+0x40]
   593c1:	mov    rdx,rcx
   593c4:	movzx  esi,WORD PTR [rax+0xe]
   593c8:	mov    r9,rsi
   593cb:	cmp    rdx,r9
   593ce:	jg     593d4 <sqlite3VdbeExec+0x9f34>
   593d0:	mov    ebp,ecx
   593d2:	jmp    59400 <sqlite3VdbeExec+0x9f60>
   593d4:	movzx  ecx,WORD PTR [rax+0x10]
   593d8:	mov    r9,rcx
   593db:	sub    rdx,r9
   593de:	mov    rax,QWORD PTR [rax+0x48]
   593e2:	mov    eax,DWORD PTR [rax+0x38]
   593e5:	sub    eax,0x4
   593e8:	mov    r10,rax
   593eb:	mov    rax,rdx
   593ee:	cqo
   593f0:	idiv   r10
   593f3:	mov    rax,rdx
   593f6:	add    rax,r9
   593f9:	cmp    eax,esi
   593fb:	mov    ebp,ecx
   593fd:	cmovle ebp,eax
   59400:	mov    rax,r12
   59403:	sub    rax,QWORD PTR [rbx+0x88]
   5940a:	add    eax,ebp
   5940c:	mov    DWORD PTR [rbx+0x90],eax
   59412:	cmp    ebp,DWORD PTR [r13+0x40]
   59416:	jb     5942d <sqlite3VdbeExec+0x9f8d>
   59418:	mov    r14d,DWORD PTR [rsp+0x338]
   59420:	xor    r11d,r11d
   59423:	mov    QWORD PTR [rsp+0x128],r11
   5942b:	jmp    59452 <sqlite3VdbeExec+0x9fb2>
   5942d:	mov    eax,ebp
   5942f:	lea    r14,[r12+rax*1]
   59433:	mov    eax,DWORD PTR [rbx+0x90]
   59439:	add    eax,0x4
   5943c:	mov    DWORD PTR [rbx+0x90],eax
   59442:	mov    QWORD PTR [rsp+0x128],r14
   5944a:	mov    r14d,DWORD PTR [rsp+0x338]
   59452:	cmp    r14d,r15d
   59455:	ja     59472 <sqlite3VdbeExec+0x9fd2>
   59457:	xor    r11d,r11d
   5945a:	mov    DWORD PTR [rsp+0x348],r11d
   59462:	xor    r11d,r11d
   59465:	mov    QWORD PTR [rsp+0x130],r11
   5946d:	jmp    59537 <sqlite3VdbeExec+0xa097>
   59472:	mov    rax,r15
   59475:	mov    DWORD PTR [rsp+0x33c],ebp
   5947c:	mov    rbp,QWORD PTR [rsp+0x108]
   59484:	lea    rax,[rbp+rax*1+0x4]
   59489:	mov    rcx,QWORD PTR [r13+0x88]
   59490:	cmp    rax,QWORD PTR [rcx+0x58]
   59494:	jbe    594d9 <sqlite3VdbeExec+0xa039>
   59496:	mov    eax,0x143d6
   5949b:	mov    ecx,0xb
   594a0:	lea    rdx,[rip+0x0]        # 594a7 <sqlite3VdbeExec+0xa007>
   594a7:	mov    QWORD PTR [rsp+0xb0],rdi
   594af:	mov    rdi,rcx
   594b2:	mov    rsi,rax
   594b5:	call   594ba <sqlite3VdbeExec+0xa01a>
   594ba:	mov    ebp,eax
   594bc:	mov    rdi,QWORD PTR [rsp+0xb0]
   594c4:	mov    r14,QWORD PTR [rsp+0xc8]
   594cc:	mov    rbx,QWORD PTR [rsp+0xe8]
   594d4:	jmp    59ba1 <sqlite3VdbeExec+0xa701>
   594d9:	mov    rax,QWORD PTR [r13+0x38]
   594dd:	mov    rcx,r15
   594e0:	movzx  edx,BYTE PTR [rax+rcx*1]
   594e4:	shl    edx,0x18
   594e7:	movzx  esi,BYTE PTR [rax+rcx*1+0x1]
   594ec:	shl    esi,0x10
   594ef:	or     edx,esi
   594f1:	movzx  esi,BYTE PTR [rax+rcx*1+0x2]
   594f6:	shl    esi,0x8
   594f9:	or     edx,esi
   594fb:	movzx  eax,BYTE PTR [rax+rcx*1+0x3]
   59500:	or     edx,eax
   59502:	mov    DWORD PTR [rsp+0x338],r14d
   5950a:	mov    r14d,edx
   5950d:	mov    QWORD PTR [rsp+0x108],rbp
   59515:	mov    DWORD PTR [rsp+0x348],r14d
   5951d:	mov    r14d,DWORD PTR [rsp+0x338]
   59525:	mov    ebp,DWORD PTR [rsp+0x33c]
   5952c:	xor    r11d,r11d
   5952f:	mov    QWORD PTR [rsp+0x130],r11
   59537:	sub    r14d,ebp
   5953a:	mov    DWORD PTR [rsp+0x33c],r14d
   59542:	mov    r14,QWORD PTR [rsp+0x108]
   5954a:	test   r15d,r15d
   5954d:	ja     59561 <sqlite3VdbeExec+0xa0c1>
   5954f:	mov    QWORD PTR [rsp+0x118],r13
   59557:	mov    QWORD PTR [rsp+0x110],rbx
   5955f:	jmp    595b2 <sqlite3VdbeExec+0xa112>
   59561:	mov    QWORD PTR [rsp+0x110],rbx
   59569:	cmp    ebp,r15d
   5956c:	mov    ebx,r15d
   5956f:	cmovb  ebx,ebp
   59572:	mov    QWORD PTR [rsp+0x118],r13
   5957a:	movsxd r13,ebx
   5957d:	mov    QWORD PTR [rsp+0xb0],rdi
   59585:	mov    rdi,r12
   59588:	mov    rsi,r14
   5958b:	mov    rdx,r13
   5958e:	call   59593 <sqlite3VdbeExec+0xa0f3>
   59593:	sub    ebp,ebx
   59595:	sub    r15d,ebx
   59598:	add    r12,r13
   5959b:	lea    rbx,[r14+r13*1]
   5959f:	mov    rdi,QWORD PTR [rsp+0xb0]
   595a7:	mov    r14,rbx
   595aa:	lea    r8,[rsp+0x324]
   595b2:	test   ebp,ebp
   595b4:	jbe    5974e <sqlite3VdbeExec+0xa2ae>
   595ba:	lea    rbx,[rsp+0xd8]
   595c2:	mov    rax,QWORD PTR [rbx]
   595c5:	test   rax,rax
   595c8:	jne    595d7 <sqlite3VdbeExec+0xa137>
   595ca:	mov    r13,QWORD PTR [rsp+0x118]
   595d2:	jmp    5966d <sqlite3VdbeExec+0xa1cd>
   595d7:	movzx  ecx,WORD PTR [rax+0x34]
   595db:	and    ecx,0x20
   595de:	test   ecx,ecx
   595e0:	je     5964d <sqlite3VdbeExec+0xa1ad>
   595e2:	mov    rcx,QWORD PTR [rax+0x28]
   595e6:	mov    edx,DWORD PTR [rcx+0x98]
   595ec:	sub    edx,0x1
   595ef:	mov    DWORD PTR [rcx+0x98],edx
   595f5:	mov    rdx,QWORD PTR [rcx+0xa8]
   595fc:	mov    QWORD PTR [rax+0x20],rdx
   59600:	mov    QWORD PTR [rcx+0xa8],rax
   59607:	mov    rdx,QWORD PTR [rcx+0x48]
   5960b:	mov    esi,DWORD PTR [rax+0x30]
   5960e:	sub    esi,0x1
   59611:	imul   rsi,QWORD PTR [rcx+0xc8]
   59619:	mov    rax,QWORD PTR [rax+0x8]
   5961d:	mov    rcx,QWORD PTR [rdx]
   59620:	mov    rcx,QWORD PTR [rcx+0x90]
   59627:	mov    QWORD PTR [rsp+0xb0],rdi
   5962f:	mov    rdi,rdx
   59632:	mov    rdx,rax
   59635:	mov    r10,rcx
   59638:	call   r10
   5963b:	mov    rdi,QWORD PTR [rsp+0xb0]
   59643:	mov    r13,QWORD PTR [rsp+0x118]
   5964b:	jmp    5966d <sqlite3VdbeExec+0xa1cd>
   5964d:	mov    r13,QWORD PTR [rsp+0x118]
   59655:	mov    QWORD PTR [rsp+0xb0],rdi
   5965d:	mov    rdi,rax
   59660:	call   59665 <sqlite3VdbeExec+0xa1c5>
   59665:	mov    rdi,QWORD PTR [rsp+0xb0]
   5966d:	mov    QWORD PTR [rbx],0x0
   59674:	mov    rax,rbx
   59677:	mov    ecx,0x2
   5967c:	mov    rbx,QWORD PTR [rsp+0x120]
   59684:	mov    rdx,QWORD PTR [rbx+0x110]
   5968b:	mov    QWORD PTR [rsp+0x138],r12
   59693:	mov    r12d,DWORD PTR [rsp+0x348]
   5969b:	mov    QWORD PTR [rsp+0xb0],rdi
   596a3:	mov    rdi,rbx
   596a6:	mov    rsi,r12
   596a9:	mov    r10,rdx
   596ac:	mov    rdx,rax
   596af:	call   r10
   596b2:	lea    r8,[rsp+0x324]
   596ba:	mov    DWORD PTR [r8],eax
   596bd:	mov    rdi,QWORD PTR [rsp+0xb0]
   596c5:	cmp    DWORD PTR [r8],0x0
   596c9:	je     596e5 <sqlite3VdbeExec+0xa245>
   596cb:	mov    QWORD PTR [rsp+0x118],r13
   596d3:	mov    DWORD PTR [rsp+0x348],r12d
   596db:	mov    r12,QWORD PTR [rsp+0x138]
   596e3:	jmp    5974e <sqlite3VdbeExec+0xa2ae>
   596e5:	lea    r12,[rsp+0xd8]
   596ed:	mov    rax,QWORD PTR [r12]
   596f1:	mov    rax,QWORD PTR [rax+0x8]
   596f5:	movzx  ecx,BYTE PTR [rax]
   596f8:	shl    ecx,0x18
   596fb:	movzx  edx,BYTE PTR [rax+0x1]
   596ff:	shl    edx,0x10
   59702:	or     ecx,edx
   59704:	movzx  edx,BYTE PTR [rax+0x2]
   59708:	shl    edx,0x8
   5970b:	or     ecx,edx
   5970d:	movzx  edx,BYTE PTR [rax+0x3]
   59711:	or     ecx,edx
   59713:	mov    r14d,ecx
   59716:	lea    r15,[rax+0x4]
   5971a:	mov    rax,QWORD PTR [r13+0x20]
   5971e:	mov    eax,DWORD PTR [rax+0x38]
   59721:	mov    r12d,eax
   59724:	sub    r12d,0x4
   59728:	mov    QWORD PTR [rsp+0x118],r13
   59730:	mov    QWORD PTR [rsp+0x120],rbx
   59738:	mov    DWORD PTR [rsp+0x348],r14d
   59740:	mov    r14,r15
   59743:	mov    r15,r12
   59746:	mov    r12,QWORD PTR [rsp+0x138]
   5974e:	cmp    DWORD PTR [r8],0x0
   59752:	jne    5976d <sqlite3VdbeExec+0xa2cd>
   59754:	test   ebp,ebp
   59756:	jbe    5976d <sqlite3VdbeExec+0xa2cd>
   59758:	mov    r13,QWORD PTR [rsp+0x118]
   59760:	mov    rbx,QWORD PTR [rsp+0x110]
   59768:	jmp    5954a <sqlite3VdbeExec+0xa0aa>
   5976d:	cmp    DWORD PTR [r8],0x0
   59771:	je     59790 <sqlite3VdbeExec+0xa2f0>
   59773:	mov    r13,QWORD PTR [rsp+0x110]
   5977b:	mov    QWORD PTR [rsp+0x138],r12
   59783:	mov    rbx,QWORD PTR [rsp+0x130]
   5978b:	jmp    59a1b <sqlite3VdbeExec+0xa57b>
   59790:	mov    r13d,DWORD PTR [rsp+0x33c]
   59798:	test   r13d,r13d
   5979b:	ja     597ba <sqlite3VdbeExec+0xa31a>
   5979d:	mov    r13,QWORD PTR [rsp+0x110]
   597a5:	mov    QWORD PTR [rsp+0x138],r12
   597ad:	mov    rbx,QWORD PTR [rsp+0x130]
   597b5:	jmp    59a1b <sqlite3VdbeExec+0xa57b>
   597ba:	mov    rbx,QWORD PTR [rsp+0x128]
   597c2:	test   rbx,rbx
   597c5:	jne    597f4 <sqlite3VdbeExec+0xa354>
   597c7:	mov    DWORD PTR [rsp+0x33c],r13d
   597cf:	mov    r13,QWORD PTR [rsp+0x110]
   597d7:	mov    QWORD PTR [rsp+0x138],r12
   597df:	mov    QWORD PTR [rsp+0x128],rbx
   597e7:	mov    rbx,QWORD PTR [rsp+0x130]
   597ef:	jmp    59a1b <sqlite3VdbeExec+0xa57b>
   597f4:	lea    r13,[rsp+0x340]
   597fc:	mov    DWORD PTR [r13+0x0],0x0
   59804:	lea    r13,[rsp+0x140]
   5980c:	mov    QWORD PTR [r13+0x0],0x0
   59814:	mov    rax,r13
   59817:	lea    r13,[rsp+0x340]
   5981f:	mov    rcx,r13
   59822:	xor    edx,edx
   59824:	xor    esi,esi
   59826:	mov    r13,QWORD PTR [rsp+0x110]
   5982e:	mov    QWORD PTR [rsp+0xb0],rdi
   59836:	mov    rdi,r13
   59839:	mov    r8,rsi
   5983c:	mov    rsi,rax
   5983f:	mov    r11,rdx
   59842:	mov    rdx,rcx
   59845:	mov    rcx,r11
   59848:	call   5984d <sqlite3VdbeExec+0xa3ad>
   5984d:	lea    r8,[rsp+0x324]
   59855:	mov    DWORD PTR [r8],eax
   59858:	mov    QWORD PTR [rsp+0x138],r12
   59860:	lea    r12,[rsp+0x340]
   59868:	mov    eax,DWORD PTR [r12]
   5986c:	mov    ecx,eax
   5986e:	shr    ecx,0x18
   59871:	mov    BYTE PTR [rbx],cl
   59873:	mov    ecx,eax
   59875:	shr    ecx,0x10
   59878:	mov    BYTE PTR [rbx+0x1],cl
   5987b:	mov    ecx,eax
   5987d:	shr    ecx,0x8
   59880:	mov    BYTE PTR [rbx+0x2],cl
   59883:	mov    BYTE PTR [rbx+0x3],al
   59886:	mov    rdi,QWORD PTR [rsp+0xb0]
   5988e:	cmp    BYTE PTR [r13+0x21],0x0
   59893:	jne    598a7 <sqlite3VdbeExec+0xa407>
   59895:	mov    QWORD PTR [rsp+0x128],rbx
   5989d:	mov    rbx,QWORD PTR [rsp+0x130]
   598a5:	jmp    598dc <sqlite3VdbeExec+0xa43c>
   598a7:	mov    rbx,QWORD PTR [rsp+0x130]
   598af:	test   rbx,rbx
   598b2:	je     598dc <sqlite3VdbeExec+0xa43c>
   598b4:	mov    eax,DWORD PTR [r12]
   598b8:	mov    ecx,DWORD PTR [rbx+0x4]
   598bb:	mov    rdx,r8
   598be:	mov    esi,0x4
   598c3:	mov    rdi,r13
   598c6:	mov    r8,rdx
   598c9:	mov    rdx,rsi
   598cc:	mov    rsi,rax
   598cf:	call   598d4 <sqlite3VdbeExec+0xa434>
   598d4:	mov    rdi,QWORD PTR [rsp+0xb0]
   598dc:	test   rbx,rbx
   598df:	je     5996f <sqlite3VdbeExec+0xa4cf>
   598e5:	mov    rax,QWORD PTR [rbx+0x70]
   598e9:	movzx  ecx,WORD PTR [rax+0x34]
   598ed:	and    ecx,0x20
   598f0:	test   ecx,ecx
   598f2:	je     59957 <sqlite3VdbeExec+0xa4b7>
   598f4:	mov    rcx,QWORD PTR [rax+0x28]
   598f8:	mov    edx,DWORD PTR [rcx+0x98]
   598fe:	sub    edx,0x1
   59901:	mov    DWORD PTR [rcx+0x98],edx
   59907:	mov    rdx,QWORD PTR [rcx+0xa8]
   5990e:	mov    QWORD PTR [rax+0x20],rdx
   59912:	mov    QWORD PTR [rcx+0xa8],rax
   59919:	mov    rdx,QWORD PTR [rcx+0x48]
   5991d:	mov    esi,DWORD PTR [rax+0x30]
   59920:	sub    esi,0x1
   59923:	imul   rsi,QWORD PTR [rcx+0xc8]
   5992b:	mov    rax,QWORD PTR [rax+0x8]
   5992f:	mov    rcx,QWORD PTR [rdx]
   59932:	mov    rcx,QWORD PTR [rcx+0x90]
   59939:	mov    QWORD PTR [rsp+0xb0],rdi
   59941:	mov    rdi,rdx
   59944:	mov    rdx,rax
   59947:	mov    r10,rcx
   5994a:	call   r10
   5994d:	mov    rdi,QWORD PTR [rsp+0xb0]
   59955:	jmp    5996f <sqlite3VdbeExec+0xa4cf>
   59957:	mov    QWORD PTR [rsp+0xb0],rdi
   5995f:	mov    rdi,rax
   59962:	call   59967 <sqlite3VdbeExec+0xa4c7>
   59967:	mov    rdi,QWORD PTR [rsp+0xb0]
   5996f:	lea    rbx,[rsp+0x140]
   59977:	mov    rbx,QWORD PTR [rbx]
   5997a:	test   rbx,rbx
   5997d:	jne    5998c <sqlite3VdbeExec+0xa4ec>
   5997f:	lea    r8,[rsp+0x324]
   59987:	jmp    59a1b <sqlite3VdbeExec+0xa57b>
   5998c:	mov    rbp,QWORD PTR [rbx+0x50]
   59990:	mov    BYTE PTR [rbp+0x0],0x0
   59994:	mov    BYTE PTR [rbp+0x1],0x0
   59998:	mov    BYTE PTR [rbp+0x2],0x0
   5999c:	mov    BYTE PTR [rbp+0x3],0x0
   599a0:	lea    r12,[rbp+0x4]
   599a4:	mov    eax,DWORD PTR [r13+0x38]
   599a8:	sub    eax,0x4
   599ab:	mov    QWORD PTR [rsp+0x108],r14
   599b3:	mov    r14d,DWORD PTR [rsp+0x33c]
   599bb:	cmp    eax,r14d
   599be:	jae    599dd <sqlite3VdbeExec+0xa53d>
   599c0:	mov    eax,DWORD PTR [r13+0x38]
   599c4:	mov    DWORD PTR [rsp+0x338],r15d
   599cc:	mov    r15d,eax
   599cf:	sub    r15d,0x4
   599d3:	lea    r8,[rsp+0x324]
   599db:	jmp    599f0 <sqlite3VdbeExec+0xa550>
   599dd:	mov    DWORD PTR [rsp+0x338],r15d
   599e5:	mov    r15,r14
   599e8:	lea    r8,[rsp+0x324]
   599f0:	mov    DWORD PTR [rsp+0x33c],r14d
   599f8:	mov    r14,QWORD PTR [rsp+0x108]
   59a00:	mov    QWORD PTR [rsp+0x138],r12
   59a08:	mov    QWORD PTR [rsp+0x128],rbp
   59a10:	mov    rbp,r15
   59a13:	mov    r15d,DWORD PTR [rsp+0x338]
   59a1b:	mov    r12d,DWORD PTR [rsp+0x33c]
   59a23:	test   r12d,r12d
   59a26:	jbe    59a59 <sqlite3VdbeExec+0xa5b9>
   59a28:	cmp    DWORD PTR [r8],0x0
   59a2c:	jne    59a59 <sqlite3VdbeExec+0xa5b9>
   59a2e:	mov    QWORD PTR [rsp+0x108],r14
   59a36:	mov    r14,r12
   59a39:	mov    r12,QWORD PTR [rsp+0x138]
   59a41:	mov    QWORD PTR [rsp+0x130],rbx
   59a49:	mov    rbx,r13
   59a4c:	mov    r13,QWORD PTR [rsp+0x118]
   59a54:	jmp    59537 <sqlite3VdbeExec+0xa097>
   59a59:	test   rbx,rbx
   59a5c:	je     59aec <sqlite3VdbeExec+0xa64c>
   59a62:	mov    rax,QWORD PTR [rbx+0x70]
   59a66:	movzx  ecx,WORD PTR [rax+0x34]
   59a6a:	and    ecx,0x20
   59a6d:	test   ecx,ecx
   59a6f:	je     59ad4 <sqlite3VdbeExec+0xa634>
   59a71:	mov    rcx,QWORD PTR [rax+0x28]
   59a75:	mov    edx,DWORD PTR [rcx+0x98]
   59a7b:	sub    edx,0x1
   59a7e:	mov    DWORD PTR [rcx+0x98],edx
   59a84:	mov    rdx,QWORD PTR [rcx+0xa8]
   59a8b:	mov    QWORD PTR [rax+0x20],rdx
   59a8f:	mov    QWORD PTR [rcx+0xa8],rax
   59a96:	mov    rdx,QWORD PTR [rcx+0x48]
   59a9a:	mov    esi,DWORD PTR [rax+0x30]
   59a9d:	sub    esi,0x1
   59aa0:	imul   rsi,QWORD PTR [rcx+0xc8]
   59aa8:	mov    rax,QWORD PTR [rax+0x8]
   59aac:	mov    rcx,QWORD PTR [rdx]
   59aaf:	mov    rcx,QWORD PTR [rcx+0x90]
   59ab6:	mov    QWORD PTR [rsp+0xb0],rdi
   59abe:	mov    rdi,rdx
   59ac1:	mov    rdx,rax
   59ac4:	mov    r10,rcx
   59ac7:	call   r10
   59aca:	mov    rdi,QWORD PTR [rsp+0xb0]
   59ad2:	jmp    59aec <sqlite3VdbeExec+0xa64c>
   59ad4:	mov    QWORD PTR [rsp+0xb0],rdi
   59adc:	mov    rdi,rax
   59adf:	call   59ae4 <sqlite3VdbeExec+0xa644>
   59ae4:	mov    rdi,QWORD PTR [rsp+0xb0]
   59aec:	lea    r14,[rsp+0xd8]
   59af4:	mov    rax,QWORD PTR [r14]
   59af7:	test   rax,rax
   59afa:	je     59b86 <sqlite3VdbeExec+0xa6e6>
   59b00:	movzx  ecx,WORD PTR [rax+0x34]
   59b04:	and    ecx,0x20
   59b07:	test   ecx,ecx
   59b09:	je     59b6e <sqlite3VdbeExec+0xa6ce>
   59b0b:	mov    rcx,QWORD PTR [rax+0x28]
   59b0f:	mov    edx,DWORD PTR [rcx+0x98]
   59b15:	sub    edx,0x1
   59b18:	mov    DWORD PTR [rcx+0x98],edx
   59b1e:	mov    rdx,QWORD PTR [rcx+0xa8]
   59b25:	mov    QWORD PTR [rax+0x20],rdx
   59b29:	mov    QWORD PTR [rcx+0xa8],rax
   59b30:	mov    rdx,QWORD PTR [rcx+0x48]
   59b34:	mov    esi,DWORD PTR [rax+0x30]
   59b37:	sub    esi,0x1
   59b3a:	imul   rsi,QWORD PTR [rcx+0xc8]
   59b42:	mov    rax,QWORD PTR [rax+0x8]
   59b46:	mov    rcx,QWORD PTR [rdx]
   59b49:	mov    rcx,QWORD PTR [rcx+0x90]
   59b50:	mov    QWORD PTR [rsp+0xb0],rdi
   59b58:	mov    rdi,rdx
   59b5b:	mov    rdx,rax
   59b5e:	mov    r10,rcx
   59b61:	call   r10
   59b64:	mov    rdi,QWORD PTR [rsp+0xb0]
   59b6c:	jmp    59b86 <sqlite3VdbeExec+0xa6e6>
   59b6e:	mov    QWORD PTR [rsp+0xb0],rdi
   59b76:	mov    rdi,rax
   59b79:	call   59b7e <sqlite3VdbeExec+0xa6de>
   59b7e:	mov    rdi,QWORD PTR [rsp+0xb0]
   59b86:	lea    r8,[rsp+0x324]
   59b8e:	mov    ebp,DWORD PTR [r8]
   59b91:	mov    r14,QWORD PTR [rsp+0xc8]
   59b99:	mov    rbx,QWORD PTR [rsp+0xe8]
   59ba1:	test   ebp,ebp
   59ba3:	je     59bc2 <sqlite3VdbeExec+0xa722>
   59ba5:	mov    QWORD PTR [rsp+0xe8],rbx
   59bad:	mov    r13,QWORD PTR [rsp+0xd0]
   59bb5:	mov    rbx,QWORD PTR [rsp+0xf8]
   59bbd:	jmp    4f712 <sqlite3VdbeExec+0x272>
   59bc2:	mov    DWORD PTR [rsp+0x32c],ebp
   59bc9:	mov    rbp,rbx
   59bcc:	mov    rbx,QWORD PTR [rsp+0x100]
   59bd4:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   59bd9:	mov    QWORD PTR [rsp+0x100],rbx
   59be1:	mov    rbx,rbp
   59be4:	mov    QWORD PTR [rsp+0xd0],r12
   59bec:	mov    ebp,DWORD PTR [rbx+0x8]
   59bef:	mov    rax,QWORD PTR [rdi+0x78]
   59bf3:	movsxd rcx,DWORD PTR [rbx+0x4]
   59bf7:	mov    r12,QWORD PTR [rax+rcx*8]
   59bfb:	cmp    BYTE PTR [rbx+0x1],0xfb
   59bff:	je     59c0d <sqlite3VdbeExec+0xa76d>
   59c01:	mov    DWORD PTR [rsp+0x338],ebp
   59c08:	jmp    59c90 <sqlite3VdbeExec+0xa7f0>
   59c0d:	cmp    QWORD PTR [r14+0x138],0x0
   59c15:	jne    59c20 <sqlite3VdbeExec+0xa780>
   59c17:	mov    DWORD PTR [rsp+0x338],ebp
   59c1e:	jmp    59c90 <sqlite3VdbeExec+0xa7f0>
   59c20:	mov    rax,QWORD PTR [r14+0x20]
   59c24:	movsx  rcx,BYTE PTR [r12+0x1]
   59c2a:	shl    rcx,0x5
   59c2e:	mov    r13,QWORD PTR [rax+rcx*1]
   59c32:	mov    r15,QWORD PTR [rbx+0x10]
   59c36:	movzx  eax,WORD PTR [rbx+0x2]
   59c3a:	and    eax,0x2
   59c3d:	test   eax,eax
   59c3f:	jne    59c4a <sqlite3VdbeExec+0xa7aa>
   59c41:	mov    DWORD PTR [rsp+0x338],ebp
   59c48:	jmp    59c88 <sqlite3VdbeExec+0xa7e8>
   59c4a:	cmp    BYTE PTR [r12+0x4],0x0
   59c50:	jne    59c5b <sqlite3VdbeExec+0xa7bb>
   59c52:	mov    DWORD PTR [rsp+0x338],ebp
   59c59:	jmp    59c88 <sqlite3VdbeExec+0xa7e8>
   59c5b:	mov    DWORD PTR [rsp+0x338],ebp
   59c62:	mov    rbp,QWORD PTR [r12+0x28]
   59c67:	mov    QWORD PTR [rsp+0xb0],rdi
   59c6f:	mov    rdi,rbp
   59c72:	call   59c77 <sqlite3VdbeExec+0xa7d7>
   59c77:	mov    rax,QWORD PTR [rbp+0x30]
   59c7b:	mov    QWORD PTR [r12+0x48],rax
   59c80:	mov    rdi,QWORD PTR [rsp+0xb0]
   59c88:	mov    rbp,r13
   59c8b:	mov    r13,r15
   59c8e:	jmp    59c95 <sqlite3VdbeExec+0xa7f5>
   59c90:	xor    ebp,ebp
   59c92:	xor    r13d,r13d
   59c95:	mov    rax,QWORD PTR [r12+0x28]
   59c9a:	movzx  ecx,WORD PTR [rbx+0x2]
   59c9e:	movzx  ecx,cl
   59ca1:	mov    QWORD PTR [rsp+0xb0],rdi
   59ca9:	mov    rdi,rax
   59cac:	mov    rsi,rcx
   59caf:	call   59cb4 <sqlite3VdbeExec+0xa814>
   59cb4:	mov    r15d,eax
   59cb7:	mov    DWORD PTR [r12+0x18],0x0
   59cc0:	mov    QWORD PTR [rsp+0xc8],r14
   59cc8:	mov    r14d,DWORD PTR [rsp+0x334]
   59cd0:	add    r14d,0x1
   59cd4:	mov    DWORD PTR [r12+0x1c],0x0
   59cdd:	mov    rdi,QWORD PTR [rsp+0xb0]
   59ce5:	test   r15d,r15d
   59ce8:	je     59d12 <sqlite3VdbeExec+0xa872>
   59cea:	mov    r14,QWORD PTR [rsp+0xc8]
   59cf2:	mov    QWORD PTR [rsp+0xe8],rbx
   59cfa:	mov    rbp,r15
   59cfd:	mov    r13,QWORD PTR [rsp+0xd0]
   59d05:	mov    rbx,QWORD PTR [rsp+0xf8]
   59d0d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   59d12:	mov    DWORD PTR [rsp+0x334],r14d
   59d1a:	mov    r14d,DWORD PTR [rsp+0x338]
   59d22:	mov    eax,r14d
   59d25:	and    eax,0x1
   59d28:	test   eax,eax
   59d2a:	jne    59d36 <sqlite3VdbeExec+0xa896>
   59d2c:	mov    r14,QWORD PTR [rsp+0xc8]
   59d34:	jmp    59d9c <sqlite3VdbeExec+0xa8fc>
   59d36:	mov    rax,QWORD PTR [rdi+0x38]
   59d3a:	add    rax,0x1
   59d3e:	mov    QWORD PTR [rdi+0x38],rax
   59d42:	mov    r14,QWORD PTR [rsp+0xc8]
   59d4a:	cmp    QWORD PTR [r14+0x138],0x0
   59d52:	je     59d9c <sqlite3VdbeExec+0xa8fc>
   59d54:	test   r13,r13
   59d57:	je     59d9c <sqlite3VdbeExec+0xa8fc>
   59d59:	mov    eax,DWORD PTR [r13+0x30]
   59d5d:	and    eax,0x80
   59d62:	test   eax,eax
   59d64:	jne    59d9c <sqlite3VdbeExec+0xa8fc>
   59d66:	mov    rax,QWORD PTR [r14+0x138]
   59d6d:	mov    rcx,QWORD PTR [r14+0x130]
   59d74:	mov    edx,0x9
   59d79:	mov    rsi,QWORD PTR [r13+0x0]
   59d7d:	mov    r8,QWORD PTR [r12+0x48]
   59d82:	mov    rdi,rcx
   59d85:	mov    rcx,rsi
   59d88:	mov    rsi,rdx
   59d8b:	mov    rdx,rbp
   59d8e:	mov    r10,rax
   59d91:	call   r10
   59d94:	mov    rdi,QWORD PTR [rsp+0xb0]
   59d9c:	mov    rbp,rbx
   59d9f:	mov    DWORD PTR [rsp+0x32c],r15d
   59da7:	mov    rbx,QWORD PTR [rsp+0x100]
   59daf:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   59db4:	mov    r15d,DWORD PTR [rsp+0x31c]
   59dbc:	mov    r13,QWORD PTR [rsp+0xf0]
   59dc4:	mov    QWORD PTR [rsp+0xd0],r12
   59dcc:	mov    r12d,DWORD PTR [rsp+0x334]
   59dd4:	mov    rax,QWORD PTR [rdi+0x38]
   59dd8:	mov    QWORD PTR [r14+0x78],rax
   59ddc:	mov    rcx,QWORD PTR [r14+0x80]
   59de3:	add    rax,rcx
   59de6:	mov    QWORD PTR [r14+0x80],rax
   59ded:	mov    QWORD PTR [rdi+0x38],0x0
   59df5:	mov    DWORD PTR [rsp+0x31c],r15d
   59dfd:	mov    QWORD PTR [rsp+0xf0],r13
   59e05:	mov    DWORD PTR [rsp+0x334],r12d
   59e0d:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   59e12:	mov    r15d,DWORD PTR [rsp+0x31c]
   59e1a:	mov    r13,QWORD PTR [rsp+0xf0]
   59e22:	mov    QWORD PTR [rsp+0xd0],r12
   59e2a:	mov    r12d,DWORD PTR [rsp+0x334]
   59e32:	mov    rax,QWORD PTR [rdi+0x78]
   59e36:	movsxd rcx,DWORD PTR [rbp+0x4]
   59e3a:	mov    rax,QWORD PTR [rax+rcx*8]
   59e3e:	movsxd rcx,DWORD PTR [rbp+0xc]
   59e42:	mov    DWORD PTR [rsp+0x334],r12d
   59e4a:	imul   r12,rcx,0x38
   59e4e:	mov    QWORD PTR [rsp+0x138],r12
   59e56:	mov    r12d,DWORD PTR [rbp+0x10]
   59e5a:	mov    DWORD PTR [rsp+0x338],0x0
   59e65:	mov    DWORD PTR [rsp+0x348],r12d
   59e6d:	mov    r12,QWORD PTR [rax+0x28]
   59e71:	mov    QWORD PTR [rsp+0x130],r12
   59e79:	mov    r12,QWORD PTR [r12+0x30]
   59e7e:	mov    QWORD PTR [rsp+0xf0],r13
   59e86:	mov    r13,QWORD PTR [rax+0x30]
   59e8a:	test   r12,r12
   59e8d:	jne    59f3f <sqlite3VdbeExec+0xaa9f>
   59e93:	movzx  eax,WORD PTR [r13+0x6]
   59e98:	add    eax,0x1
   59e9b:	imul   rax,rax,0x38
   59e9f:	add    rax,0x28
   59ea3:	mov    rcx,QWORD PTR [r13+0x10]
   59ea7:	test   rcx,rcx
   59eaa:	je     59ecc <sqlite3VdbeExec+0xaa2c>
   59eac:	mov    QWORD PTR [rsp+0xb0],rdi
   59eb4:	mov    rdi,rcx
   59eb7:	mov    rsi,rax
   59eba:	call   59ebf <sqlite3VdbeExec+0xaa1f>
   59ebf:	mov    r12,rax
   59ec2:	mov    rdi,QWORD PTR [rsp+0xb0]
   59eca:	jmp    59ee7 <sqlite3VdbeExec+0xaa47>
   59ecc:	mov    QWORD PTR [rsp+0xb0],rdi
   59ed4:	mov    rdi,rax
   59ed7:	call   59edc <sqlite3VdbeExec+0xaa3c>
   59edc:	mov    r12,rax
   59edf:	mov    rdi,QWORD PTR [rsp+0xb0]
   59ee7:	test   r12,r12
   59eea:	jne    59ef1 <sqlite3VdbeExec+0xaa51>
   59eec:	xor    r12d,r12d
   59eef:	jmp    59f0d <sqlite3VdbeExec+0xaa6d>
   59ef1:	lea    rax,[r12+0x28]
   59ef6:	mov    QWORD PTR [r12+0x8],rax
   59efb:	mov    QWORD PTR [r12],r13
   59eff:	movzx  eax,WORD PTR [r13+0x6]
   59f04:	add    eax,0x1
   59f07:	mov    WORD PTR [r12+0x1c],ax
   59f0d:	mov    r13,QWORD PTR [rsp+0x130]
   59f15:	mov    QWORD PTR [r13+0x30],r12
   59f19:	test   r12,r12
   59f1c:	jne    59f29 <sqlite3VdbeExec+0xaa89>
   59f1e:	mov    r12d,0x7
   59f24:	jmp    5a04f <sqlite3VdbeExec+0xabaf>
   59f29:	mov    QWORD PTR [rsp+0x130],r13
   59f31:	mov    r13d,DWORD PTR [rsp+0x348]
   59f39:	mov    WORD PTR [r12+0x1c],r13w
   59f3f:	mov    r13,QWORD PTR [rsp+0x130]
   59f47:	cmp    BYTE PTR [r13+0x58],0x0
   59f4c:	je     59f7d <sqlite3VdbeExec+0xaadd>
   59f4e:	mov    rax,QWORD PTR [r13+0x18]
   59f52:	mov    rax,QWORD PTR [rax+0x18]
   59f56:	mov    rcx,QWORD PTR [r13+0x18]
   59f5a:	mov    rcx,QWORD PTR [rcx+0x10]
   59f5e:	movsxd rcx,DWORD PTR [rcx+0x4]
   59f62:	imul   rcx,rcx,0x50
   59f66:	mov    edx,DWORD PTR [rax+rcx*1+0x14]
   59f6a:	lea    r13,[rsp+0x33c]
   59f72:	mov    DWORD PTR [r13+0x0],edx
   59f76:	mov    rax,QWORD PTR [rax+rcx*1+0x28]
   59f7b:	jmp    59faa <sqlite3VdbeExec+0xab0a>
   59f7d:	mov    rax,QWORD PTR [r13+0x38]
   59f81:	mov    eax,DWORD PTR [rax]
   59f83:	mov    QWORD PTR [rsp+0x128],r12
   59f8b:	lea    r12,[rsp+0x33c]
   59f93:	mov    DWORD PTR [r12],eax
   59f97:	mov    rax,QWORD PTR [r13+0x38]
   59f9b:	add    rax,0x10
   59f9f:	mov    r13,r12
   59fa2:	mov    r12,QWORD PTR [rsp+0x128]
   59faa:	mov    ecx,DWORD PTR [r13+0x0]
   59fae:	mov    QWORD PTR [rsp+0xb0],rdi
   59fb6:	mov    rdi,rcx
   59fb9:	mov    rsi,rax
   59fbc:	mov    rdx,r12
   59fbf:	call   59fc4 <sqlite3VdbeExec+0xab24>
   59fc4:	xor    eax,eax
   59fc6:	mov    rdi,QWORD PTR [rsp+0xb0]
   59fce:	jmp    59fdb <sqlite3VdbeExec+0xab3b>
   59fd0:	mov    DWORD PTR [rsp+0x348],r13d
   59fd8:	add    eax,0x1
   59fdb:	mov    r13d,DWORD PTR [rsp+0x348]
   59fe3:	cmp    eax,r13d
   59fe6:	jge    5a010 <sqlite3VdbeExec+0xab70>
   59fe8:	mov    rcx,QWORD PTR [r12+0x8]
   59fed:	mov    rdx,rax
   59ff0:	imul   rdx,rdx,0x38
   59ff4:	movzx  ecx,WORD PTR [rcx+rdx*1+0x14]
   59ff9:	and    ecx,0x1
   59ffc:	test   ecx,ecx
   59ffe:	je     59fd0 <sqlite3VdbeExec+0xab30>
   5a000:	mov    DWORD PTR [rsp+0x338],0xffffffff
   5a00b:	xor    r12d,r12d
   5a00e:	jmp    5a04f <sqlite3VdbeExec+0xabaf>
   5a010:	mov    r13,QWORD PTR [rsp+0x138]
   5a018:	mov    eax,DWORD PTR [rbx+r13*1+0x10]
   5a01d:	mov    rcx,QWORD PTR [rbx+r13*1+0x8]
   5a022:	xor    edx,edx
   5a024:	mov    QWORD PTR [rsp+0xb0],rdi
   5a02c:	mov    rdi,rax
   5a02f:	mov    rsi,rcx
   5a032:	mov    rcx,rdx
   5a035:	mov    rdx,r12
   5a038:	call   5a03d <sqlite3VdbeExec+0xab9d>
   5a03d:	mov    DWORD PTR [rsp+0x338],eax
   5a044:	xor    r12d,r12d
   5a047:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a04f:	test   r12d,r12d
   5a052:	je     5a074 <sqlite3VdbeExec+0xabd4>
   5a054:	mov    QWORD PTR [rsp+0xe8],rbp
   5a05c:	mov    rbp,r12
   5a05f:	mov    r13,QWORD PTR [rsp+0xd0]
   5a067:	mov    rbx,QWORD PTR [rsp+0xf8]
   5a06f:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5a074:	cmp    DWORD PTR [rsp+0x338],0x0
   5a07c:	je     5a08e <sqlite3VdbeExec+0xabee>
   5a07e:	mov    DWORD PTR [rsp+0x32c],r12d
   5a086:	mov    r12,r14
   5a089:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5a08e:	mov    DWORD PTR [rsp+0x31c],r15d
   5a096:	mov    DWORD PTR [rsp+0x32c],r12d
   5a09e:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5a0a3:	mov    r15d,DWORD PTR [rsp+0x31c]
   5a0ab:	mov    QWORD PTR [rsp+0xd0],r12
   5a0b3:	movsxd rax,DWORD PTR [rbp+0x8]
   5a0b7:	imul   rax,rax,0x38
   5a0bb:	lea    r12,[rbx+rax*1]
   5a0bf:	mov    rax,QWORD PTR [rdi+0x78]
   5a0c3:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a0c7:	mov    rax,QWORD PTR [rax+rcx*8]
   5a0cb:	lea    r13,[rsp+0x338]
   5a0d3:	mov    rax,QWORD PTR [rax+0x28]
   5a0d7:	cmp    BYTE PTR [rax+0x58],0x0
   5a0db:	je     5a104 <sqlite3VdbeExec+0xac64>
   5a0dd:	mov    rcx,QWORD PTR [rax+0x18]
   5a0e1:	mov    rcx,QWORD PTR [rcx+0x18]
   5a0e5:	mov    rax,QWORD PTR [rax+0x18]
   5a0e9:	mov    rax,QWORD PTR [rax+0x10]
   5a0ed:	movsxd rax,DWORD PTR [rax+0x4]
   5a0f1:	imul   rax,rax,0x50
   5a0f5:	mov    edx,DWORD PTR [rcx+rax*1+0x14]
   5a0f9:	mov    DWORD PTR [r13+0x0],edx
   5a0fd:	mov    rax,QWORD PTR [rcx+rax*1+0x28]
   5a102:	jmp    5a116 <sqlite3VdbeExec+0xac76>
   5a104:	mov    rcx,QWORD PTR [rax+0x38]
   5a108:	mov    ecx,DWORD PTR [rcx]
   5a10a:	mov    DWORD PTR [r13+0x0],ecx
   5a10e:	mov    rax,QWORD PTR [rax+0x38]
   5a112:	add    rax,0x10
   5a116:	mov    r13,rax
   5a119:	mov    DWORD PTR [rsp+0x31c],r15d
   5a121:	lea    r15,[rsp+0x338]
   5a129:	mov    eax,DWORD PTR [r15]
   5a12c:	cmp    eax,DWORD PTR [r12+0x20]
   5a131:	jle    5a15f <sqlite3VdbeExec+0xacbf>
   5a133:	xor    ecx,ecx
   5a135:	mov    QWORD PTR [rsp+0xb0],rdi
   5a13d:	mov    rdi,r12
   5a140:	mov    rsi,rax
   5a143:	mov    rdx,rcx
   5a146:	call   5a14b <sqlite3VdbeExec+0xacab>
   5a14b:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a153:	test   eax,eax
   5a155:	je     5a178 <sqlite3VdbeExec+0xacd8>
   5a157:	mov    r12d,0x7
   5a15d:	jmp    5a1bd <sqlite3VdbeExec+0xad1d>
   5a15f:	mov    rax,QWORD PTR [r12+0x28]
   5a164:	mov    QWORD PTR [r12+0x8],rax
   5a169:	movzx  eax,WORD PTR [r12+0x14]
   5a16f:	and    eax,0x2d
   5a172:	mov    WORD PTR [r12+0x14],ax
   5a178:	mov    eax,DWORD PTR [r15]
   5a17b:	mov    DWORD PTR [r12+0x10],eax
   5a180:	movzx  eax,WORD PTR [r12+0x14]
   5a186:	and    eax,0xfffff240
   5a18b:	or     eax,0x10
   5a18e:	mov    WORD PTR [r12+0x14],ax
   5a194:	mov    rax,QWORD PTR [r12+0x8]
   5a199:	movsxd rcx,DWORD PTR [r15]
   5a19c:	mov    QWORD PTR [rsp+0xb0],rdi
   5a1a4:	mov    rdi,rax
   5a1a7:	mov    rsi,r13
   5a1aa:	mov    rdx,rcx
   5a1ad:	call   5a1b2 <sqlite3VdbeExec+0xad12>
   5a1b2:	xor    r12d,r12d
   5a1b5:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a1bd:	test   r12d,r12d
   5a1c0:	je     5a1e2 <sqlite3VdbeExec+0xad42>
   5a1c2:	mov    QWORD PTR [rsp+0xe8],rbp
   5a1ca:	mov    rbp,r12
   5a1cd:	mov    r13,QWORD PTR [rsp+0xd0]
   5a1d5:	mov    rbx,QWORD PTR [rsp+0xf8]
   5a1dd:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5a1e2:	mov    rax,QWORD PTR [rdi+0x78]
   5a1e6:	movsxd rcx,DWORD PTR [rbp+0xc]
   5a1ea:	mov    rax,QWORD PTR [rax+rcx*8]
   5a1ee:	mov    DWORD PTR [rax+0x18],0x0
   5a1f5:	mov    DWORD PTR [rsp+0x32c],r12d
   5a1fd:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5a202:	mov    QWORD PTR [rsp+0xd0],r12
   5a20a:	mov    rax,QWORD PTR [rdi+0x68]
   5a20e:	movsxd rcx,DWORD PTR [rbp+0x8]
   5a212:	imul   rcx,rcx,0x38
   5a216:	lea    r12,[rax+rcx*1]
   5a21a:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5a21f:	and    eax,0x9000
   5a224:	test   eax,eax
   5a226:	je     5a245 <sqlite3VdbeExec+0xada5>
   5a228:	mov    QWORD PTR [rsp+0xb0],rdi
   5a230:	mov    rdi,r12
   5a233:	call   5a238 <sqlite3VdbeExec+0xad98>
   5a238:	mov    r12,rax
   5a23b:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a243:	jmp    5a24d <sqlite3VdbeExec+0xadad>
   5a245:	mov    WORD PTR [r12+0x14],0x4
   5a24d:	mov    rax,QWORD PTR [rdi+0x78]
   5a251:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a255:	mov    rax,QWORD PTR [rax+rcx*8]
   5a259:	mov    r13,QWORD PTR [rax+0x28]
   5a25d:	mov    QWORD PTR [rsp+0xb0],rdi
   5a265:	mov    rdi,r13
   5a268:	call   5a26d <sqlite3VdbeExec+0xadcd>
   5a26d:	mov    eax,DWORD PTR [r13+0x40]
   5a271:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a279:	cmp    eax,DWORD PTR [r14+0x88]
   5a280:	jbe    5a292 <sqlite3VdbeExec+0xadf2>
   5a282:	mov    QWORD PTR [rsp+0xe8],rbp
   5a28a:	mov    rbp,r14
   5a28d:	jmp    53cb6 <sqlite3VdbeExec+0x4816>
   5a292:	mov    rdi,r13
   5a295:	mov    rsi,rax
   5a298:	mov    rdx,r12
   5a29b:	call   5a2a0 <sqlite3VdbeExec+0xae00>
   5a2a0:	mov    r13d,eax
   5a2a3:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a2ab:	test   r13d,r13d
   5a2ae:	je     5a2d0 <sqlite3VdbeExec+0xae30>
   5a2b0:	mov    QWORD PTR [rsp+0xe8],rbp
   5a2b8:	mov    rbp,r13
   5a2bb:	mov    r13,QWORD PTR [rsp+0xd0]
   5a2c3:	mov    rbx,QWORD PTR [rsp+0xf8]
   5a2cb:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5a2d0:	cmp    DWORD PTR [rbp+0xc],0x0
   5a2d4:	jne    5a3f9 <sqlite3VdbeExec+0xaf59>
   5a2da:	movzx  eax,WORD PTR [r12+0x14]
   5a2e0:	and    eax,0x4000
   5a2e5:	test   eax,eax
   5a2e7:	je     5a3f9 <sqlite3VdbeExec+0xaf59>
   5a2ed:	movzx  eax,WORD PTR [r12+0x14]
   5a2f3:	and    eax,0x12
   5a2f6:	test   eax,eax
   5a2f8:	je     5a3e8 <sqlite3VdbeExec+0xaf48>
   5a2fe:	movzx  eax,WORD PTR [r12+0x14]
   5a304:	and    eax,0x400
   5a309:	test   eax,eax
   5a30b:	je     5a39c <sqlite3VdbeExec+0xaefc>
   5a311:	mov    eax,DWORD PTR [r12+0x10]
   5a316:	add    eax,DWORD PTR [r12]
   5a31a:	test   eax,eax
   5a31c:	jg     5a330 <sqlite3VdbeExec+0xae90>
   5a31e:	movzx  eax,WORD PTR [r12+0x14]
   5a324:	and    eax,0x10
   5a327:	test   eax,eax
   5a329:	je     5a39c <sqlite3VdbeExec+0xaefc>
   5a32b:	mov    eax,0x1
   5a330:	mov    ecx,0x1
   5a335:	mov    QWORD PTR [rsp+0xb0],rdi
   5a33d:	mov    rdi,r12
   5a340:	mov    rsi,rax
   5a343:	mov    rdx,rcx
   5a346:	call   5a34b <sqlite3VdbeExec+0xaeab>
   5a34b:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a353:	test   eax,eax
   5a355:	jne    5a3d0 <sqlite3VdbeExec+0xaf30>
   5a357:	mov    rax,QWORD PTR [r12+0x8]
   5a35c:	movsxd rcx,DWORD PTR [r12+0x10]
   5a361:	add    rax,rcx
   5a364:	xor    ecx,ecx
   5a366:	movsxd rdx,DWORD PTR [r12]
   5a36a:	mov    rdi,rax
   5a36d:	mov    rsi,rcx
   5a370:	call   5a375 <sqlite3VdbeExec+0xaed5>
   5a375:	mov    eax,DWORD PTR [r12+0x10]
   5a37a:	add    eax,DWORD PTR [r12]
   5a37e:	mov    DWORD PTR [r12+0x10],eax
   5a383:	movzx  eax,WORD PTR [r12+0x14]
   5a389:	and    eax,0xfffff9ff
   5a38e:	mov    WORD PTR [r12+0x14],ax
   5a394:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a39c:	cmp    DWORD PTR [r12+0x20],0x0
   5a3a2:	je     5a3b0 <sqlite3VdbeExec+0xaf10>
   5a3a4:	mov    rax,QWORD PTR [r12+0x8]
   5a3a9:	cmp    rax,QWORD PTR [r12+0x28]
   5a3ae:	je     5a3e8 <sqlite3VdbeExec+0xaf48>
   5a3b0:	mov    QWORD PTR [rsp+0xb0],rdi
   5a3b8:	mov    rdi,r12
   5a3bb:	call   5a3c0 <sqlite3VdbeExec+0xaf20>
   5a3c0:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a3c8:	test   eax,eax
   5a3ca:	je     5a3e8 <sqlite3VdbeExec+0xaf48>
   5a3cc:	test   eax,eax
   5a3ce:	je     5a3f9 <sqlite3VdbeExec+0xaf59>
   5a3d0:	mov    r13,QWORD PTR [rsp+0xf0]
   5a3d8:	mov    rbx,rbp
   5a3db:	mov    rbp,QWORD PTR [rsp+0xf8]
   5a3e3:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5a3e8:	movzx  eax,WORD PTR [r12+0x14]
   5a3ee:	and    eax,0xffffbfff
   5a3f3:	mov    WORD PTR [r12+0x14],ax
   5a3f9:	mov    DWORD PTR [rsp+0x32c],r13d
   5a401:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5a406:	mov    r15d,DWORD PTR [rsp+0x31c]
   5a40e:	mov    r13,QWORD PTR [rsp+0xf0]
   5a416:	mov    QWORD PTR [rsp+0xd0],r12
   5a41e:	mov    r12d,DWORD PTR [rsp+0x334]
   5a426:	mov    rax,QWORD PTR [rdi+0x68]
   5a42a:	movsxd rcx,DWORD PTR [rbp+0x8]
   5a42e:	imul   rcx,rcx,0x38
   5a432:	mov    DWORD PTR [rsp+0x334],r12d
   5a43a:	lea    r12,[rax+rcx*1]
   5a43e:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5a443:	and    eax,0x9000
   5a448:	test   eax,eax
   5a44a:	je     5a469 <sqlite3VdbeExec+0xafc9>
   5a44c:	mov    QWORD PTR [rsp+0xb0],rdi
   5a454:	mov    rdi,r12
   5a457:	call   5a45c <sqlite3VdbeExec+0xafbc>
   5a45c:	mov    r12,rax
   5a45f:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a467:	jmp    5a471 <sqlite3VdbeExec+0xafd1>
   5a469:	mov    WORD PTR [r12+0x14],0x4
   5a471:	mov    rax,QWORD PTR [rdi+0x78]
   5a475:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a479:	mov    QWORD PTR [rsp+0xf0],r13
   5a481:	mov    r13,QWORD PTR [rax+rcx*8]
   5a485:	cmp    BYTE PTR [r13+0x2],0x0
   5a48a:	je     5a4a1 <sqlite3VdbeExec+0xb001>
   5a48c:	mov    WORD PTR [r12+0x14],0x1
   5a494:	mov    DWORD PTR [rsp+0x31c],r15d
   5a49c:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5a4a1:	cmp    BYTE PTR [r13+0x3],0x0
   5a4a6:	je     5a4c1 <sqlite3VdbeExec+0xb021>
   5a4a8:	mov    rax,QWORD PTR [r13+0x48]
   5a4ac:	mov    QWORD PTR [rsp+0x128],rax
   5a4b4:	mov    r13d,DWORD PTR [rsp+0x32c]
   5a4bc:	jmp    5a7a7 <sqlite3VdbeExec+0xb307>
   5a4c1:	cmp    BYTE PTR [r13+0x0],0x2
   5a4c6:	jne    5a6ef <sqlite3VdbeExec+0xb24f>
   5a4cc:	mov    rax,QWORD PTR [r13+0x28]
   5a4d0:	mov    QWORD PTR [rsp+0x138],r12
   5a4d8:	mov    r12,QWORD PTR [rax]
   5a4db:	mov    rax,QWORD PTR [r12]
   5a4df:	mov    rax,QWORD PTR [rax+0x60]
   5a4e3:	mov    rcx,QWORD PTR [r13+0x28]
   5a4e7:	lea    r13,[rsp+0x128]
   5a4ef:	mov    rdx,r13
   5a4f2:	mov    QWORD PTR [rsp+0xb0],rdi
   5a4fa:	mov    rdi,rcx
   5a4fd:	mov    rsi,rdx
   5a500:	mov    r10,rax
   5a503:	call   r10
   5a506:	mov    r13d,eax
   5a509:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a511:	cmp    QWORD PTR [r12+0x10],0x0
   5a517:	jne    5a526 <sqlite3VdbeExec+0xb086>
   5a519:	mov    DWORD PTR [rsp+0x338],r13d
   5a521:	jmp    5a6b5 <sqlite3VdbeExec+0xb215>
   5a526:	mov    DWORD PTR [rsp+0x338],r13d
   5a52e:	mov    r13,QWORD PTR [rdi]
   5a531:	mov    rax,QWORD PTR [rdi+0xa8]
   5a538:	test   rax,rax
   5a53b:	je     5a550 <sqlite3VdbeExec+0xb0b0>
   5a53d:	mov    rdi,r13
   5a540:	mov    rsi,rax
   5a543:	call   5a548 <sqlite3VdbeExec+0xb0a8>
   5a548:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a550:	mov    QWORD PTR [rsp+0x130],r12
   5a558:	mov    r12,QWORD PTR [r12+0x10]
   5a55d:	test   r12,r12
   5a560:	jne    5a575 <sqlite3VdbeExec+0xb0d5>
   5a562:	xor    r12d,r12d
   5a565:	mov    r13,r12
   5a568:	mov    r12,QWORD PTR [rsp+0x130]
   5a570:	jmp    5a616 <sqlite3VdbeExec+0xb176>
   5a575:	mov    QWORD PTR [rsp+0xb0],rdi
   5a57d:	mov    rdi,r12
   5a580:	call   5a585 <sqlite3VdbeExec+0xb0e5>
   5a585:	mov    QWORD PTR [rsp+0x108],r12
   5a58d:	lea    r12,[rax+0x1]
   5a591:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a599:	test   r13,r13
   5a59c:	je     5a5b6 <sqlite3VdbeExec+0xb116>
   5a59e:	mov    rdi,r13
   5a5a1:	mov    rsi,r12
   5a5a4:	call   5a5a9 <sqlite3VdbeExec+0xb109>
   5a5a9:	mov    r13,rax
   5a5ac:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a5b4:	jmp    5a5c9 <sqlite3VdbeExec+0xb129>
   5a5b6:	mov    rdi,r12
   5a5b9:	call   5a5be <sqlite3VdbeExec+0xb11e>
   5a5be:	mov    r13,rax
   5a5c1:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a5c9:	test   r13,r13
   5a5cc:	jne    5a5d8 <sqlite3VdbeExec+0xb138>
   5a5ce:	mov    DWORD PTR [rsp+0x31c],r15d
   5a5d6:	jmp    5a606 <sqlite3VdbeExec+0xb166>
   5a5d8:	mov    DWORD PTR [rsp+0x31c],r15d
   5a5e0:	mov    r15,QWORD PTR [rsp+0x108]
   5a5e8:	mov    QWORD PTR [rsp+0xb0],rdi
   5a5f0:	mov    rdi,r13
   5a5f3:	mov    rsi,r15
   5a5f6:	mov    rdx,r12
   5a5f9:	call   5a5fe <sqlite3VdbeExec+0xb15e>
   5a5fe:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a606:	mov    r15d,DWORD PTR [rsp+0x31c]
   5a60e:	mov    r12,QWORD PTR [rsp+0x130]
   5a616:	mov    QWORD PTR [rdi+0xa8],r13
   5a61d:	mov    r13,QWORD PTR [r12+0x10]
   5a622:	test   r13,r13
   5a625:	je     5a6ac <sqlite3VdbeExec+0xb20c>
   5a62b:	cmp    DWORD PTR [rip+0x0],0x0        # 5a632 <sqlite3VdbeExec+0xb192>
   5a632:	je     5a68c <sqlite3VdbeExec+0xb1ec>
   5a634:	mov    rax,QWORD PTR [rip+0x0]        # 5a63b <sqlite3VdbeExec+0xb19b>
   5a63b:	mov    QWORD PTR [rsp+0xb0],rdi
   5a643:	mov    rdi,r13
   5a646:	mov    r10,rax
   5a649:	call   r10
   5a64c:	mov    rcx,QWORD PTR [rip+0x0]        # 5a653 <sqlite3VdbeExec+0xb1b3>
   5a653:	movsxd rax,eax
   5a656:	sub    rcx,rax
   5a659:	mov    QWORD PTR [rip+0x0],rcx        # 5a660 <sqlite3VdbeExec+0xb1c0>
   5a660:	mov    rax,QWORD PTR [rip+0x0]        # 5a667 <sqlite3VdbeExec+0xb1c7>
   5a667:	sub    rax,0x1
   5a66b:	mov    QWORD PTR [rip+0x0],rax        # 5a672 <sqlite3VdbeExec+0xb1d2>
   5a672:	mov    rax,QWORD PTR [rip+0x0]        # 5a679 <sqlite3VdbeExec+0xb1d9>
   5a679:	mov    rdi,r13
   5a67c:	mov    r10,rax
   5a67f:	call   r10
   5a682:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a68a:	jmp    5a6ac <sqlite3VdbeExec+0xb20c>
   5a68c:	mov    rax,QWORD PTR [rip+0x0]        # 5a693 <sqlite3VdbeExec+0xb1f3>
   5a693:	mov    QWORD PTR [rsp+0xb0],rdi
   5a69b:	mov    rdi,r13
   5a69e:	mov    r10,rax
   5a6a1:	call   r10
   5a6a4:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a6ac:	mov    QWORD PTR [r12+0x10],0x0
   5a6b5:	mov    r13d,DWORD PTR [rsp+0x338]
   5a6bd:	test   r13d,r13d
   5a6c0:	je     5a6e2 <sqlite3VdbeExec+0xb242>
   5a6c2:	mov    QWORD PTR [rsp+0xe8],rbp
   5a6ca:	mov    rbp,r13
   5a6cd:	mov    r13,QWORD PTR [rsp+0xd0]
   5a6d5:	mov    rbx,QWORD PTR [rsp+0xf8]
   5a6dd:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5a6e2:	mov    r12,QWORD PTR [rsp+0x138]
   5a6ea:	jmp    5a7a7 <sqlite3VdbeExec+0xb307>
   5a6ef:	mov    QWORD PTR [rsp+0x138],r12
   5a6f7:	mov    rax,QWORD PTR [r13+0x28]
   5a6fb:	xor    ecx,ecx
   5a6fd:	movzx  eax,BYTE PTR [rax]
   5a700:	cmp    ecx,eax
   5a702:	je     5a721 <sqlite3VdbeExec+0xb281>
   5a704:	mov    QWORD PTR [rsp+0xb0],rdi
   5a70c:	mov    rdi,r13
   5a70f:	call   5a714 <sqlite3VdbeExec+0xb274>
   5a714:	mov    r12d,eax
   5a717:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a71f:	jmp    5a724 <sqlite3VdbeExec+0xb284>
   5a721:	xor    r12d,r12d
   5a724:	test   r12d,r12d
   5a727:	je     5a749 <sqlite3VdbeExec+0xb2a9>
   5a729:	mov    QWORD PTR [rsp+0xe8],rbp
   5a731:	mov    rbp,r12
   5a734:	mov    r13,QWORD PTR [rsp+0xd0]
   5a73c:	mov    rbx,QWORD PTR [rsp+0xf8]
   5a744:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5a749:	cmp    BYTE PTR [r13+0x2],0x0
   5a74e:	je     5a774 <sqlite3VdbeExec+0xb2d4>
   5a750:	mov    r13,QWORD PTR [rsp+0x138]
   5a758:	mov    WORD PTR [r13+0x14],0x1
   5a75f:	mov    DWORD PTR [rsp+0x31c],r15d
   5a767:	mov    DWORD PTR [rsp+0x32c],r12d
   5a76f:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5a774:	mov    r13,QWORD PTR [r13+0x28]
   5a778:	mov    QWORD PTR [rsp+0xb0],rdi
   5a780:	mov    rdi,r13
   5a783:	call   5a788 <sqlite3VdbeExec+0xb2e8>
   5a788:	mov    rax,QWORD PTR [r13+0x30]
   5a78c:	mov    QWORD PTR [rsp+0x128],rax
   5a794:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a79c:	mov    r13,r12
   5a79f:	mov    r12,QWORD PTR [rsp+0x138]
   5a7a7:	mov    rax,QWORD PTR [rsp+0x128]
   5a7af:	mov    QWORD PTR [r12],rax
   5a7b3:	mov    DWORD PTR [rsp+0x31c],r15d
   5a7bb:	mov    DWORD PTR [rsp+0x32c],r13d
   5a7c3:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5a7c8:	mov    r15d,DWORD PTR [rsp+0x31c]
   5a7d0:	mov    r13,QWORD PTR [rsp+0xf0]
   5a7d8:	mov    QWORD PTR [rsp+0xd0],r12
   5a7e0:	mov    r12d,DWORD PTR [rsp+0x334]
   5a7e8:	mov    rax,QWORD PTR [rdi+0x78]
   5a7ec:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a7f0:	mov    rax,QWORD PTR [rax+rcx*8]
   5a7f4:	test   rax,rax
   5a7f7:	jne    5a861 <sqlite3VdbeExec+0xb3c1>
   5a7f9:	mov    eax,DWORD PTR [rbp+0x4]
   5a7fc:	mov    ecx,0x1
   5a801:	mov    edx,0x3
   5a806:	mov    QWORD PTR [rsp+0xb0],rdi
   5a80e:	mov    rsi,rax
   5a811:	mov    r11,rdx
   5a814:	mov    rdx,rcx
   5a817:	mov    rcx,r11
   5a81a:	call   5a81f <sqlite3VdbeExec+0xb37f>
   5a81f:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a827:	test   rax,rax
   5a82a:	jne    5a83c <sqlite3VdbeExec+0xb39c>
   5a82c:	mov    rbx,rbp
   5a82f:	mov    rbp,QWORD PTR [rsp+0xf8]
   5a837:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5a83c:	mov    DWORD PTR [rax+0x1c],0x0
   5a843:	mov    BYTE PTR [rax+0x4],0x1
   5a847:	movzx  ecx,BYTE PTR [rax+0x5]
   5a84b:	and    rcx,0xfffffffffffffff7
   5a84f:	or     rcx,0x8
   5a853:	mov    BYTE PTR [rax+0x5],cl
   5a856:	lea    rcx,[rip+0x0]        # 5a85d <sqlite3VdbeExec+0xb3bd>
   5a85d:	mov    QWORD PTR [rax+0x28],rcx
   5a861:	mov    BYTE PTR [rax+0x2],0x1
   5a865:	mov    DWORD PTR [rax+0x18],0x0
   5a86c:	cmp    BYTE PTR [rax],0x0
   5a86f:	je     5a87e <sqlite3VdbeExec+0xb3de>
   5a871:	mov    DWORD PTR [rsp+0x334],r12d
   5a879:	jmp    5a937 <sqlite3VdbeExec+0xb497>
   5a87e:	mov    DWORD PTR [rsp+0x334],r12d
   5a886:	mov    r12,QWORD PTR [rax+0x28]
   5a88a:	mov    QWORD PTR [rsp+0x128],r12
   5a892:	mov    r12,QWORD PTR [r12+0x18]
   5a897:	test   r12,r12
   5a89a:	je     5a921 <sqlite3VdbeExec+0xb481>
   5a8a0:	cmp    DWORD PTR [rip+0x0],0x0        # 5a8a7 <sqlite3VdbeExec+0xb407>
   5a8a7:	je     5a901 <sqlite3VdbeExec+0xb461>
   5a8a9:	mov    rax,QWORD PTR [rip+0x0]        # 5a8b0 <sqlite3VdbeExec+0xb410>
   5a8b0:	mov    QWORD PTR [rsp+0xb0],rdi
   5a8b8:	mov    rdi,r12
   5a8bb:	mov    r10,rax
   5a8be:	call   r10
   5a8c1:	mov    rcx,QWORD PTR [rip+0x0]        # 5a8c8 <sqlite3VdbeExec+0xb428>
   5a8c8:	movsxd rax,eax
   5a8cb:	sub    rcx,rax
   5a8ce:	mov    QWORD PTR [rip+0x0],rcx        # 5a8d5 <sqlite3VdbeExec+0xb435>
   5a8d5:	mov    rax,QWORD PTR [rip+0x0]        # 5a8dc <sqlite3VdbeExec+0xb43c>
   5a8dc:	sub    rax,0x1
   5a8e0:	mov    QWORD PTR [rip+0x0],rax        # 5a8e7 <sqlite3VdbeExec+0xb447>
   5a8e7:	mov    rax,QWORD PTR [rip+0x0]        # 5a8ee <sqlite3VdbeExec+0xb44e>
   5a8ee:	mov    rdi,r12
   5a8f1:	mov    r10,rax
   5a8f4:	call   r10
   5a8f7:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a8ff:	jmp    5a921 <sqlite3VdbeExec+0xb481>
   5a901:	mov    rax,QWORD PTR [rip+0x0]        # 5a908 <sqlite3VdbeExec+0xb468>
   5a908:	mov    QWORD PTR [rsp+0xb0],rdi
   5a910:	mov    rdi,r12
   5a913:	mov    r10,rax
   5a916:	call   r10
   5a919:	mov    rdi,QWORD PTR [rsp+0xb0]
   5a921:	mov    r12,QWORD PTR [rsp+0x128]
   5a929:	mov    QWORD PTR [r12+0x18],0x0
   5a932:	mov    BYTE PTR [r12],0x1
   5a937:	mov    DWORD PTR [rsp+0x31c],r15d
   5a93f:	mov    QWORD PTR [rsp+0xf0],r13
   5a947:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5a94c:	mov    r15d,DWORD PTR [rsp+0x31c]
   5a954:	mov    r13,QWORD PTR [rsp+0xf0]
   5a95c:	mov    QWORD PTR [rsp+0xd0],r12
   5a964:	mov    rax,QWORD PTR [rdi+0x78]
   5a968:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a96c:	mov    r12,QWORD PTR [rax+rcx*8]
   5a970:	mov    rax,QWORD PTR [r12+0x28]
   5a975:	mov    DWORD PTR [rsp+0x338],0x0
   5a980:	cmp    BYTE PTR [rbp+0x0],0x8b
   5a984:	je     5a99b <sqlite3VdbeExec+0xb4fb>
   5a986:	mov    QWORD PTR [rsp+0x128],r12
   5a98e:	mov    r12,r13
   5a991:	lea    r13,[rsp+0x338]
   5a999:	jmp    5a9d3 <sqlite3VdbeExec+0xb533>
   5a99b:	mov    DWORD PTR [r12+0x1c],0xffffffff
   5a9a4:	cmp    BYTE PTR [rax],0x0
   5a9a7:	je     5a9be <sqlite3VdbeExec+0xb51e>
   5a9a9:	mov    QWORD PTR [rsp+0x128],r12
   5a9b1:	mov    r12,r13
   5a9b4:	lea    r13,[rsp+0x338]
   5a9bc:	jmp    5a9d3 <sqlite3VdbeExec+0xb533>
   5a9be:	mov    DWORD PTR [rsp+0x31c],r15d
   5a9c6:	mov    QWORD PTR [rsp+0xf0],r13
   5a9ce:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5a9d3:	mov    rcx,r13
   5a9d6:	xor    edx,edx
   5a9d8:	movzx  esi,BYTE PTR [rax]
   5a9db:	cmp    edx,esi
   5a9dd:	jne    5a9f5 <sqlite3VdbeExec+0xb555>
   5a9df:	movzx  edx,BYTE PTR [rax+0x1]
   5a9e3:	and    edx,0x8
   5a9e6:	test   edx,edx
   5a9e8:	je     5a9f5 <sqlite3VdbeExec+0xb555>
   5a9ea:	mov    DWORD PTR [rcx],0x0
   5a9f0:	xor    r13d,r13d
   5a9f3:	jmp    5aa13 <sqlite3VdbeExec+0xb573>
   5a9f5:	mov    QWORD PTR [rsp+0xb0],rdi
   5a9fd:	mov    rdi,rax
   5aa00:	mov    rsi,rcx
   5aa03:	call   5aa08 <sqlite3VdbeExec+0xb568>
   5aa08:	mov    r13d,eax
   5aa0b:	mov    rdi,QWORD PTR [rsp+0xb0]
   5aa13:	mov    eax,DWORD PTR [rsp+0x338]
   5aa1a:	mov    QWORD PTR [rsp+0xf0],r12
   5aa22:	mov    r12,QWORD PTR [rsp+0x128]
   5aa2a:	mov    BYTE PTR [r12+0x2],al
   5aa2f:	mov    BYTE PTR [r12+0x3],0x0
   5aa35:	mov    DWORD PTR [r12+0x18],0x0
   5aa3e:	test   r13d,r13d
   5aa41:	je     5aa63 <sqlite3VdbeExec+0xb5c3>
   5aa43:	mov    QWORD PTR [rsp+0xe8],rbp
   5aa4b:	mov    rbp,r13
   5aa4e:	mov    r13,QWORD PTR [rsp+0xd0]
   5aa56:	mov    rbx,QWORD PTR [rsp+0xf8]
   5aa5e:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5aa63:	cmp    DWORD PTR [rbp+0x8],0x0
   5aa67:	jle    5aa83 <sqlite3VdbeExec+0xb5e3>
   5aa69:	cmp    DWORD PTR [rsp+0x338],0x0
   5aa71:	je     5aa83 <sqlite3VdbeExec+0xb5e3>
   5aa73:	mov    r12,r14
   5aa76:	mov    DWORD PTR [rsp+0x32c],r13d
   5aa7e:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5aa83:	mov    DWORD PTR [rsp+0x31c],r15d
   5aa8b:	mov    DWORD PTR [rsp+0x32c],r13d
   5aa93:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5aa98:	mov    r15d,DWORD PTR [rsp+0x31c]
   5aaa0:	mov    QWORD PTR [rsp+0xd0],r12
   5aaa8:	mov    rax,QWORD PTR [rdi+0x78]
   5aaac:	movsxd rcx,DWORD PTR [rbp+0x4]
   5aab0:	mov    rax,QWORD PTR [rax+rcx*8]
   5aab4:	mov    r12,QWORD PTR [rax+0x28]
   5aab8:	mov    QWORD PTR [rsp+0xb0],rdi
   5aac0:	mov    rdi,r12
   5aac3:	call   5aac8 <sqlite3VdbeExec+0xb628>
   5aac8:	mov    rdi,QWORD PTR [rsp+0xb0]
   5aad0:	test   eax,eax
   5aad2:	jne    5ab70 <sqlite3VdbeExec+0xb6d0>
   5aad8:	mov    DWORD PTR [rsp+0x338],0x0
   5aae3:	xor    eax,eax
   5aae5:	jmp    5ab66 <sqlite3VdbeExec+0xb6c6>
   5aae7:	mov    rcx,QWORD PTR [r12+0x88]
   5aaef:	cmp    BYTE PTR [rcx+0x8],0x0
   5aaf3:	jne    5ab6e <sqlite3VdbeExec+0xb6ce>
   5aaf5:	mov    rax,QWORD PTR [rcx+0x50]
   5aaf9:	movzx  edx,WORD PTR [rcx+0x1a]
   5aafd:	mov    rsi,QWORD PTR [rcx+0x60]
   5ab01:	movzx  r8d,WORD PTR [r12+0x56]
   5ab07:	shl    r8d,1
   5ab0a:	movzx  esi,BYTE PTR [rsi+r8*1]
   5ab0f:	shl    esi,0x8
   5ab12:	mov    rcx,QWORD PTR [rcx+0x60]
   5ab16:	movzx  r8d,WORD PTR [r12+0x56]
   5ab1c:	shl    r8d,1
   5ab1f:	movzx  ecx,BYTE PTR [rcx+r8*1+0x1]
   5ab25:	or     esi,ecx
   5ab27:	and    edx,esi
   5ab29:	movzx  ecx,BYTE PTR [rax+rdx*1]
   5ab2d:	shl    ecx,0x18
   5ab30:	movzx  esi,BYTE PTR [rax+rdx*1+0x1]
   5ab35:	shl    esi,0x10
   5ab38:	or     ecx,esi
   5ab3a:	movzx  esi,BYTE PTR [rax+rdx*1+0x2]
   5ab3f:	shl    esi,0x8
   5ab42:	or     ecx,esi
   5ab44:	movzx  eax,BYTE PTR [rax+rdx*1+0x3]
   5ab49:	or     ecx,eax
   5ab4b:	mov    QWORD PTR [rsp+0xb0],rdi
   5ab53:	mov    rdi,r12
   5ab56:	mov    rsi,rcx
   5ab59:	call   5ab5e <sqlite3VdbeExec+0xb6be>
   5ab5e:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ab66:	test   eax,eax
   5ab68:	je     5aae7 <sqlite3VdbeExec+0xb647>
   5ab6e:	jmp    5ab82 <sqlite3VdbeExec+0xb6e2>
   5ab70:	cmp    eax,0x10
   5ab73:	jne    5ab82 <sqlite3VdbeExec+0xb6e2>
   5ab75:	mov    DWORD PTR [rsp+0x338],0x1
   5ab80:	xor    eax,eax
   5ab82:	mov    r13d,eax
   5ab85:	test   r13d,r13d
   5ab88:	je     5abaa <sqlite3VdbeExec+0xb70a>
   5ab8a:	mov    QWORD PTR [rsp+0xe8],rbp
   5ab92:	mov    rbp,r13
   5ab95:	mov    r13,QWORD PTR [rsp+0xd0]
   5ab9d:	mov    rbx,QWORD PTR [rsp+0xf8]
   5aba5:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5abaa:	cmp    DWORD PTR [rsp+0x338],0x0
   5abb2:	je     5abbd <sqlite3VdbeExec+0xb71d>
   5abb4:	mov    rax,0xffffffffffffffff
   5abbb:	jmp    5ac2f <sqlite3VdbeExec+0xb78f>
   5abbd:	cmp    BYTE PTR [r12],0x0
   5abc2:	je     5abc8 <sqlite3VdbeExec+0xb728>
   5abc4:	xor    eax,eax
   5abc6:	jmp    5ac18 <sqlite3VdbeExec+0xb778>
   5abc8:	mov    rax,QWORD PTR [r12+0x88]
   5abd0:	cmp    BYTE PTR [rax+0x8],0x0
   5abd4:	jne    5abdf <sqlite3VdbeExec+0xb73f>
   5abd6:	mov    rax,0xffffffffffffffff
   5abdd:	jmp    5ac18 <sqlite3VdbeExec+0xb778>
   5abdf:	mov    rax,QWORD PTR [r12+0x88]
   5abe7:	movzx  eax,WORD PTR [rax+0x18]
   5abeb:	xor    ecx,ecx
   5abed:	jmp    5ac0c <sqlite3VdbeExec+0xb76c>
   5abef:	mov    rdx,rcx
   5abf2:	mov    rdx,QWORD PTR [r12+rdx*8+0x90]
   5abfa:	movzx  edx,WORD PTR [rdx+0x18]
   5abfe:	add    edx,0x1
   5ac01:	imul   rax,rdx
   5ac05:	mov    edx,0x1
   5ac0a:	add    cl,dl
   5ac0c:	mov    edx,ecx
   5ac0e:	movsx  esi,BYTE PTR [r12+0x54]
   5ac14:	cmp    edx,esi
   5ac16:	jl     5abef <sqlite3VdbeExec+0xb74f>
   5ac18:	mov    ecx,0x28
   5ac1d:	cmp    rax,0x8
   5ac21:	jae    5ac84 <sqlite3VdbeExec+0xb7e4>
   5ac23:	cmp    rax,0x2
   5ac27:	jae    5ac55 <sqlite3VdbeExec+0xb7b5>
   5ac29:	xor    eax,eax
   5ac2b:	movsx  rax,ax
   5ac2f:	movsxd rcx,DWORD PTR [rbp+0xc]
   5ac33:	cmp    rax,rcx
   5ac36:	jl     5aca2 <sqlite3VdbeExec+0xb802>
   5ac38:	movsxd rcx,DWORD PTR [rbp+0x10]
   5ac3c:	cmp    rax,rcx
   5ac3f:	mov    eax,0x0
   5ac44:	setle  al
   5ac47:	jmp    5aca4 <sqlite3VdbeExec+0xb804>
   5ac49:	movsx  ecx,cx
   5ac4c:	sub    ecx,0xa
   5ac4f:	movzx  ecx,cx
   5ac52:	shl    rax,1
   5ac55:	cmp    rax,0x8
   5ac59:	jb     5ac49 <sqlite3VdbeExec+0xb7a9>
   5ac5b:	lea    rdx,[rip+0x0]        # 5ac62 <sqlite3VdbeExec+0xb7c2>
   5ac62:	and    rax,0x7
   5ac66:	movsx  eax,WORD PTR [rdx+rax*2]
   5ac6a:	movsx  ecx,cx
   5ac6d:	add    eax,ecx
   5ac6f:	sub    eax,0xa
   5ac72:	movzx  eax,ax
   5ac75:	jmp    5ac2b <sqlite3VdbeExec+0xb78b>
   5ac77:	movsx  ecx,cx
   5ac7a:	add    ecx,0x28
   5ac7d:	movzx  ecx,cx
   5ac80:	shr    rax,0x4
   5ac84:	cmp    rax,0xff
   5ac8a:	ja     5ac77 <sqlite3VdbeExec+0xb7d7>
   5ac8c:	jmp    5ac9a <sqlite3VdbeExec+0xb7fa>
   5ac8e:	movsx  ecx,cx
   5ac91:	add    ecx,0xa
   5ac94:	movzx  ecx,cx
   5ac97:	shr    rax,1
   5ac9a:	cmp    rax,0xf
   5ac9e:	ja     5ac8e <sqlite3VdbeExec+0xb7ee>
   5aca0:	jmp    5ac5b <sqlite3VdbeExec+0xb7bb>
   5aca2:	xor    eax,eax
   5aca4:	mov    DWORD PTR [rsp+0x338],eax
   5acab:	cmp    DWORD PTR [rsp+0x338],0x0
   5acb3:	je     5acc5 <sqlite3VdbeExec+0xb825>
   5acb5:	mov    r12,r14
   5acb8:	mov    DWORD PTR [rsp+0x32c],r13d
   5acc0:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5acc5:	mov    DWORD PTR [rsp+0x31c],r15d
   5accd:	mov    DWORD PTR [rsp+0x32c],r13d
   5acd5:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5acda:	mov    r15d,DWORD PTR [rsp+0x31c]
   5ace2:	mov    QWORD PTR [rsp+0xd0],r12
   5acea:	mov    eax,DWORD PTR [rdi+0xdc]
   5acf0:	add    eax,0x1
   5acf3:	mov    DWORD PTR [rdi+0xdc],eax
   5acf9:	mov    rax,QWORD PTR [rdi+0x78]
   5acfd:	movsxd rcx,DWORD PTR [rbp+0x4]
   5ad01:	mov    r12,QWORD PTR [rax+rcx*8]
   5ad05:	mov    DWORD PTR [rsp+0x338],0x1
   5ad10:	cmp    BYTE PTR [r12],0x1
   5ad15:	jne    5b818 <sqlite3VdbeExec+0xc378>
   5ad1b:	mov    r13,QWORD PTR [r12+0x28]
   5ad20:	cmp    BYTE PTR [r13+0x58],0x0
   5ad25:	jne    5ad8c <sqlite3VdbeExec+0xb8ec>
   5ad27:	cmp    QWORD PTR [r13+0x38],0x0
   5ad2c:	je     5ad69 <sqlite3VdbeExec+0xb8c9>
   5ad2e:	mov    DWORD PTR [rsp+0x338],0x0
   5ad39:	lea    rax,[r13+0x60]
   5ad3d:	lea    rcx,[r13+0x38]
   5ad41:	mov    QWORD PTR [rsp+0xb0],rdi
   5ad49:	mov    rdi,rax
   5ad4c:	mov    rsi,rcx
   5ad4f:	call   5ad54 <sqlite3VdbeExec+0xb8b4>
   5ad54:	mov    r13d,eax
   5ad57:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ad5f:	mov    DWORD PTR [rsp+0x33c],r13d
   5ad67:	jmp    5ad7f <sqlite3VdbeExec+0xb8df>
   5ad69:	mov    DWORD PTR [rsp+0x338],0x1
   5ad74:	xor    r11d,r11d
   5ad77:	mov    DWORD PTR [rsp+0x33c],r11d
   5ad7f:	mov    r13d,DWORD PTR [rsp+0x33c]
   5ad87:	jmp    5b813 <sqlite3VdbeExec+0xc373>
   5ad8c:	mov    QWORD PTR [rsp+0x128],r12
   5ad94:	mov    QWORD PTR [rsp+0xb0],rdi
   5ad9c:	mov    rdi,r13
   5ad9f:	call   5ada4 <sqlite3VdbeExec+0xb904>
   5ada4:	mov    r12d,eax
   5ada7:	mov    rdi,QWORD PTR [rsp+0xb0]
   5adaf:	test   r12d,r12d
   5adb2:	jne    5b808 <sqlite3VdbeExec+0xc368>
   5adb8:	lea    r12,[r13+0x60]
   5adbc:	mov    QWORD PTR [rsp+0x130],0x0
   5adc8:	lea    r8,[rsp+0x118]
   5add0:	lea    r9,[rsp+0x140]
   5add8:	mov    DWORD PTR [rsp+0x31c],r15d
   5ade0:	mov    QWORD PTR [rsp+0x138],r13
   5ade8:	mov    QWORD PTR [rsp+0x108],r12
   5adf0:	xor    r15d,r15d
   5adf3:	xor    r12d,r12d
   5adf6:	xor    r13d,r13d
   5adf9:	jmp    5b6c1 <sqlite3VdbeExec+0xc221>
   5adfe:	shl    rcx,0x4
   5ae02:	add    eax,0x1
   5ae05:	mov    rsi,rdx
   5ae08:	cmp    rcx,rsi
   5ae0b:	jl     5adfe <sqlite3VdbeExec+0xb95e>
   5ae0d:	mov    QWORD PTR [rsp+0x138],r13
   5ae15:	mov    r13d,eax
   5ae18:	mov    QWORD PTR [r9],0x0
   5ae1f:	cmp    DWORD PTR [r12+0xc],0x10
   5ae25:	jg     5ae82 <sqlite3VdbeExec+0xb9e2>
   5ae27:	mov    eax,DWORD PTR [r12+0xc]
   5ae2c:	mov    rcx,r9
   5ae2f:	mov    rdx,r8
   5ae32:	mov    QWORD PTR [rsp+0xb0],rdi
   5ae3a:	mov    rdi,r12
   5ae3d:	mov    rsi,rax
   5ae40:	mov    r11,rdx
   5ae43:	mov    rdx,rcx
   5ae46:	mov    rcx,r11
   5ae49:	call   5ae4e <sqlite3VdbeExec+0xb9ae>
   5ae4e:	mov    r12d,eax
   5ae51:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ae59:	lea    r8,[rsp+0x118]
   5ae61:	lea    r9,[rsp+0x140]
   5ae69:	test   r12d,r12d
   5ae6c:	jne    5b67a <sqlite3VdbeExec+0xc1da>
   5ae72:	mov    r13,QWORD PTR [r8]
   5ae75:	mov    QWORD PTR [rsp+0x120],r13
   5ae7d:	jmp    5b6a5 <sqlite3VdbeExec+0xc205>
   5ae82:	mov    DWORD PTR [rsp+0x340],r13d
   5ae8a:	mov    r13,r12
   5ae8d:	mov    r12,rbx
   5ae90:	mov    ebx,0x2
   5ae95:	jmp    5ae99 <sqlite3VdbeExec+0xb9f9>
   5ae97:	add    ebx,ebx
   5ae99:	cmp    ebx,0x10
   5ae9c:	jl     5ae97 <sqlite3VdbeExec+0xb9f7>
   5ae9e:	mov    rax,rbx
   5aea1:	imul   rax,rax,0x54
   5aea5:	mov    DWORD PTR [rsp+0x34c],ebx
   5aeac:	lea    rbx,[rax+0x20]
   5aeb0:	mov    eax,0x64
   5aeb5:	mov    rcx,QWORD PTR [rip+0x0]        # 5aebc <sqlite3VdbeExec+0xba1c>
   5aebc:	test   rcx,rcx
   5aebf:	je     5aef9 <sqlite3VdbeExec+0xba59>
   5aec1:	mov    QWORD PTR [rsp+0xb0],rdi
   5aec9:	mov    rdi,rax
   5aecc:	mov    r10,rcx
   5aecf:	call   r10
   5aed2:	mov    rdi,QWORD PTR [rsp+0xb0]
   5aeda:	test   eax,eax
   5aedc:	je     5aef9 <sqlite3VdbeExec+0xba59>
   5aede:	xor    eax,eax
   5aee0:	mov    ebx,DWORD PTR [rsp+0x34c]
   5aee7:	lea    r8,[rsp+0x118]
   5aeef:	lea    r9,[rsp+0x140]
   5aef7:	jmp    5af58 <sqlite3VdbeExec+0xbab8>
   5aef9:	mov    QWORD PTR [rsp+0xb0],rdi
   5af01:	mov    rdi,rbx
   5af04:	call   5af09 <sqlite3VdbeExec+0xba69>
   5af09:	mov    rdi,QWORD PTR [rsp+0xb0]
   5af11:	test   rax,rax
   5af14:	je     5af41 <sqlite3VdbeExec+0xbaa1>
   5af16:	xor    ecx,ecx
   5af18:	mov    QWORD PTR [rsp+0xa8],rax
   5af20:	mov    rdi,rax
   5af23:	mov    rsi,rcx
   5af26:	mov    rdx,rbx
   5af29:	call   5af2e <sqlite3VdbeExec+0xba8e>
   5af2e:	mov    rcx,rax
   5af31:	mov    rax,QWORD PTR [rsp+0xa8]
   5af39:	mov    rdi,QWORD PTR [rsp+0xb0]
   5af41:	mov    ebx,DWORD PTR [rsp+0x34c]
   5af48:	lea    r8,[rsp+0x118]
   5af50:	lea    r9,[rsp+0x140]
   5af58:	test   rax,rax
   5af5b:	je     5af81 <sqlite3VdbeExec+0xbae1>
   5af5d:	mov    DWORD PTR [rax],ebx
   5af5f:	mov    QWORD PTR [rax+0x8],0x0
   5af67:	lea    rcx,[rax+0x20]
   5af6b:	mov    QWORD PTR [rax+0x18],rcx
   5af6f:	mov    rcx,QWORD PTR [rax+0x18]
   5af73:	mov    rdx,rbx
   5af76:	imul   rdx,rdx,0x50
   5af7a:	add    rcx,rdx
   5af7d:	mov    QWORD PTR [rax+0x10],rcx
   5af81:	mov    QWORD PTR [r8],rax
   5af84:	mov    eax,0x7
   5af89:	mov    ebx,DWORD PTR [rsp+0x33c]
   5af90:	cmp    QWORD PTR [r8],0x0
   5af94:	cmove  ebx,eax
   5af97:	mov    DWORD PTR [rsp+0x31c],r15d
   5af9f:	mov    r15,r12
   5afa2:	mov    r12,rbx
   5afa5:	xor    ebx,ebx
   5afa7:	xor    r11d,r11d
   5afaa:	mov    DWORD PTR [rsp+0x34c],r11d
   5afb2:	jmp    5b60c <sqlite3VdbeExec+0xc16c>
   5afb7:	mov    DWORD PTR [rsp+0x344],ebx
   5afbe:	mov    ebx,DWORD PTR [rsp+0x34c]
   5afc5:	mov    r12,r15
   5afc8:	mov    r15d,DWORD PTR [rsp+0x31c]
   5afd0:	mov    eax,0x10
   5afd5:	mov    rcx,r9
   5afd8:	mov    DWORD PTR [rsp+0x31c],r15d
   5afe0:	lea    r15,[rsp+0x148]
   5afe8:	mov    rdx,r15
   5afeb:	mov    QWORD PTR [rsp+0xb0],rdi
   5aff3:	mov    rdi,r13
   5aff6:	mov    rsi,rax
   5aff9:	mov    r11,rdx
   5affc:	mov    rdx,rcx
   5afff:	mov    rcx,r11
   5b002:	call   5b007 <sqlite3VdbeExec+0xbb67>
   5b007:	mov    r15d,eax
   5b00a:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b012:	test   r15d,r15d
   5b015:	je     5b02c <sqlite3VdbeExec+0xbb8c>
   5b017:	lea    r8,[rsp+0x118]
   5b01f:	lea    r9,[rsp+0x140]
   5b027:	jmp    5b5f2 <sqlite3VdbeExec+0xc152>
   5b02c:	lea    r15d,[rbx+0x1]
   5b030:	lea    r8,[rsp+0x118]
   5b038:	mov    DWORD PTR [rsp+0x350],r15d
   5b040:	mov    r15,QWORD PTR [r8]
   5b043:	mov    QWORD PTR [rsp+0x150],r15
   5b04b:	lea    r15,[rsp+0x148]
   5b053:	mov    r15,QWORD PTR [r15]
   5b056:	mov    eax,0x64
   5b05b:	mov    rcx,QWORD PTR [rip+0x0]        # 5b062 <sqlite3VdbeExec+0xbbc2>
   5b062:	test   rcx,rcx
   5b065:	je     5b090 <sqlite3VdbeExec+0xbbf0>
   5b067:	mov    rdi,rax
   5b06a:	mov    r10,rcx
   5b06d:	call   r10
   5b070:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b078:	test   eax,eax
   5b07a:	je     5b090 <sqlite3VdbeExec+0xbbf0>
   5b07c:	xor    eax,eax
   5b07e:	lea    r8,[rsp+0x118]
   5b086:	lea    r9,[rsp+0x140]
   5b08e:	jmp    5b0fe <sqlite3VdbeExec+0xbc5e>
   5b090:	mov    QWORD PTR [rsp+0x158],r15
   5b098:	mov    r15d,0x48
   5b09e:	mov    QWORD PTR [rsp+0xb0],rdi
   5b0a6:	mov    rdi,r15
   5b0a9:	call   5b0ae <sqlite3VdbeExec+0xbc0e>
   5b0ae:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b0b6:	test   rax,rax
   5b0b9:	je     5b0e6 <sqlite3VdbeExec+0xbc46>
   5b0bb:	xor    ecx,ecx
   5b0bd:	mov    QWORD PTR [rsp+0xa8],rax
   5b0c5:	mov    rdi,rax
   5b0c8:	mov    rsi,rcx
   5b0cb:	mov    rdx,r15
   5b0ce:	call   5b0d3 <sqlite3VdbeExec+0xbc33>
   5b0d3:	mov    rcx,rax
   5b0d6:	mov    rax,QWORD PTR [rsp+0xa8]
   5b0de:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b0e6:	mov    r15,QWORD PTR [rsp+0x158]
   5b0ee:	lea    r8,[rsp+0x118]
   5b0f6:	lea    r9,[rsp+0x140]
   5b0fe:	mov    DWORD PTR [rsp+0x34c],ebx
   5b105:	lea    rbx,[rsp+0x160]
   5b10d:	mov    QWORD PTR [rbx],rax
   5b110:	test   rax,rax
   5b113:	je     5b173 <sqlite3VdbeExec+0xbcd3>
   5b115:	mov    QWORD PTR [rax+0x8],r15
   5b119:	mov    QWORD PTR [rax],r13
   5b11c:	mov    rcx,QWORD PTR [r13+0x10]
   5b120:	mov    ecx,DWORD PTR [rcx+0x8]
   5b123:	add    ecx,0x9
   5b126:	mov    rdx,QWORD PTR [r13+0x10]
   5b12a:	mov    edx,DWORD PTR [rdx+0x4]
   5b12d:	mov    esi,edx
   5b12f:	sar    esi,0x1f
   5b132:	and    esi,0x1
   5b135:	add    edx,esi
   5b137:	sar    edx,1
   5b139:	cmp    ecx,edx
   5b13b:	jle    5b149 <sqlite3VdbeExec+0xbca9>
   5b13d:	mov    rcx,QWORD PTR [r13+0x10]
   5b141:	mov    ecx,DWORD PTR [rcx+0x8]
   5b144:	add    ecx,0x9
   5b147:	jmp    5b15c <sqlite3VdbeExec+0xbcbc>
   5b149:	mov    rcx,QWORD PTR [r13+0x10]
   5b14d:	mov    ecx,DWORD PTR [rcx+0x4]
   5b150:	mov    edx,ecx
   5b152:	sar    edx,0x1f
   5b155:	and    edx,0x1
   5b158:	add    ecx,edx
   5b15a:	sar    ecx,1
   5b15c:	mov    DWORD PTR [rax+0x18],ecx
   5b15f:	mov    rcx,QWORD PTR [r13+0x58]
   5b163:	movsxd rax,DWORD PTR [rax+0x18]
   5b167:	add    rax,rcx
   5b16a:	mov    QWORD PTR [r13+0x58],rax
   5b16e:	xor    r15d,r15d
   5b171:	jmp    5b1a1 <sqlite3VdbeExec+0xbd01>
   5b173:	mov    QWORD PTR [rsp+0xb0],rdi
   5b17b:	mov    rdi,r15
   5b17e:	call   5b183 <sqlite3VdbeExec+0xbce3>
   5b183:	mov    r15d,0x7
   5b189:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b191:	lea    r8,[rsp+0x118]
   5b199:	lea    r9,[rsp+0x140]
   5b1a1:	mov    eax,0x1
   5b1a6:	mov    ebx,0x1
   5b1ab:	jmp    5b1ba <sqlite3VdbeExec+0xbd1a>
   5b1ad:	mov    ebx,DWORD PTR [rsp+0x354]
   5b1b4:	shl    ebx,0x4
   5b1b7:	add    eax,0x1
   5b1ba:	mov    DWORD PTR [rsp+0x354],ebx
   5b1c1:	mov    ebx,DWORD PTR [rsp+0x340]
   5b1c8:	cmp    eax,ebx
   5b1ca:	jl     5b1ad <sqlite3VdbeExec+0xbd0d>
   5b1cc:	mov    ebx,0x1
   5b1d1:	mov    QWORD PTR [rsp+0xc8],r14
   5b1d9:	mov    r14,r15
   5b1dc:	mov    r15,rbx
   5b1df:	mov    rbx,rbp
   5b1e2:	mov    ebp,DWORD PTR [rsp+0x354]
   5b1e9:	jmp    5b480 <sqlite3VdbeExec+0xbfe0>
   5b1ee:	add    ebp,ebp
   5b1f0:	cmp    ebp,0x10
   5b1f3:	jl     5b1ee <sqlite3VdbeExec+0xbd4e>
   5b1f5:	mov    rax,rbp
   5b1f8:	imul   rax,rax,0x54
   5b1fc:	mov    DWORD PTR [rsp+0x354],r15d
   5b204:	lea    r15,[rax+0x20]
   5b208:	mov    eax,0x64
   5b20d:	mov    rcx,QWORD PTR [rip+0x0]        # 5b214 <sqlite3VdbeExec+0xbd74>
   5b214:	test   rcx,rcx
   5b217:	je     5b24a <sqlite3VdbeExec+0xbdaa>
   5b219:	mov    QWORD PTR [rsp+0xb0],rdi
   5b221:	mov    rdi,rax
   5b224:	mov    r10,rcx
   5b227:	call   r10
   5b22a:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b232:	test   eax,eax
   5b234:	je     5b24a <sqlite3VdbeExec+0xbdaa>
   5b236:	xor    eax,eax
   5b238:	lea    r8,[rsp+0x118]
   5b240:	lea    r9,[rsp+0x140]
   5b248:	jmp    5b2a2 <sqlite3VdbeExec+0xbe02>
   5b24a:	mov    QWORD PTR [rsp+0xb0],rdi
   5b252:	mov    rdi,r15
   5b255:	call   5b25a <sqlite3VdbeExec+0xbdba>
   5b25a:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b262:	test   rax,rax
   5b265:	je     5b292 <sqlite3VdbeExec+0xbdf2>
   5b267:	xor    ecx,ecx
   5b269:	mov    QWORD PTR [rsp+0xa8],rax
   5b271:	mov    rdi,rax
   5b274:	mov    rsi,rcx
   5b277:	mov    rdx,r15
   5b27a:	call   5b27f <sqlite3VdbeExec+0xbddf>
   5b27f:	mov    rcx,rax
   5b282:	mov    rax,QWORD PTR [rsp+0xa8]
   5b28a:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b292:	lea    r8,[rsp+0x118]
   5b29a:	lea    r9,[rsp+0x140]
   5b2a2:	test   rax,rax
   5b2a5:	je     5b2cb <sqlite3VdbeExec+0xbe2b>
   5b2a7:	mov    DWORD PTR [rax],ebp
   5b2a9:	mov    QWORD PTR [rax+0x8],0x0
   5b2b1:	lea    rcx,[rax+0x20]
   5b2b5:	mov    QWORD PTR [rax+0x18],rcx
   5b2b9:	mov    rcx,QWORD PTR [rax+0x18]
   5b2bd:	mov    rdx,rbp
   5b2c0:	imul   rdx,rdx,0x50
   5b2c4:	add    rcx,rdx
   5b2c7:	mov    QWORD PTR [rax+0x10],rcx
   5b2cb:	mov    rbp,rax
   5b2ce:	test   rbp,rbp
   5b2d1:	jne    5b2e5 <sqlite3VdbeExec+0xbe45>
   5b2d3:	mov    ebp,0x7
   5b2d8:	mov    r15,QWORD PTR [rsp+0x158]
   5b2e0:	jmp    5b423 <sqlite3VdbeExec+0xbf83>
   5b2e5:	xor    r15d,r15d
   5b2e8:	mov    eax,0x64
   5b2ed:	mov    rcx,QWORD PTR [rip+0x0]        # 5b2f4 <sqlite3VdbeExec+0xbe54>
   5b2f4:	test   rcx,rcx
   5b2f7:	je     5b32a <sqlite3VdbeExec+0xbe8a>
   5b2f9:	mov    QWORD PTR [rsp+0xb0],rdi
   5b301:	mov    rdi,rax
   5b304:	mov    r10,rcx
   5b307:	call   r10
   5b30a:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b312:	test   eax,eax
   5b314:	je     5b32a <sqlite3VdbeExec+0xbe8a>
   5b316:	xor    eax,eax
   5b318:	lea    r8,[rsp+0x118]
   5b320:	lea    r9,[rsp+0x140]
   5b328:	jmp    5b388 <sqlite3VdbeExec+0xbee8>
   5b32a:	mov    r15d,0x48
   5b330:	mov    QWORD PTR [rsp+0xb0],rdi
   5b338:	mov    rdi,r15
   5b33b:	call   5b340 <sqlite3VdbeExec+0xbea0>
   5b340:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b348:	test   rax,rax
   5b34b:	je     5b378 <sqlite3VdbeExec+0xbed8>
   5b34d:	xor    ecx,ecx
   5b34f:	mov    QWORD PTR [rsp+0xa8],rax
   5b357:	mov    rdi,rax
   5b35a:	mov    rsi,rcx
   5b35d:	mov    rdx,r15
   5b360:	call   5b365 <sqlite3VdbeExec+0xbec5>
   5b365:	mov    rcx,rax
   5b368:	mov    rax,QWORD PTR [rsp+0xa8]
   5b370:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b378:	lea    r8,[rsp+0x118]
   5b380:	lea    r9,[rsp+0x140]
   5b388:	mov    r15,QWORD PTR [rsp+0x158]
   5b390:	mov    QWORD PTR [r15+0x48],rax
   5b394:	test   rax,rax
   5b397:	je     5b3f6 <sqlite3VdbeExec+0xbf56>
   5b399:	mov    QWORD PTR [rax+0x8],rbp
   5b39d:	mov    QWORD PTR [rax],r13
   5b3a0:	mov    rcx,QWORD PTR [r13+0x10]
   5b3a4:	mov    ecx,DWORD PTR [rcx+0x8]
   5b3a7:	add    ecx,0x9
   5b3aa:	mov    rdx,QWORD PTR [r13+0x10]
   5b3ae:	mov    edx,DWORD PTR [rdx+0x4]
   5b3b1:	mov    esi,edx
   5b3b3:	sar    esi,0x1f
   5b3b6:	and    esi,0x1
   5b3b9:	add    edx,esi
   5b3bb:	sar    edx,1
   5b3bd:	cmp    ecx,edx
   5b3bf:	jle    5b3cd <sqlite3VdbeExec+0xbf2d>
   5b3c1:	mov    rcx,QWORD PTR [r13+0x10]
   5b3c5:	mov    ecx,DWORD PTR [rcx+0x8]
   5b3c8:	add    ecx,0x9
   5b3cb:	jmp    5b3e0 <sqlite3VdbeExec+0xbf40>
   5b3cd:	mov    rcx,QWORD PTR [r13+0x10]
   5b3d1:	mov    ecx,DWORD PTR [rcx+0x4]
   5b3d4:	mov    edx,ecx
   5b3d6:	sar    edx,0x1f
   5b3d9:	and    edx,0x1
   5b3dc:	add    ecx,edx
   5b3de:	sar    ecx,1
   5b3e0:	mov    DWORD PTR [rax+0x18],ecx
   5b3e3:	mov    rcx,QWORD PTR [r13+0x58]
   5b3e7:	movsxd rax,DWORD PTR [rax+0x18]
   5b3eb:	add    rax,rcx
   5b3ee:	mov    QWORD PTR [r13+0x58],rax
   5b3f2:	xor    ebp,ebp
   5b3f4:	jmp    5b423 <sqlite3VdbeExec+0xbf83>
   5b3f6:	mov    QWORD PTR [rsp+0xb0],rdi
   5b3fe:	mov    rdi,rbp
   5b401:	call   5b406 <sqlite3VdbeExec+0xbf66>
   5b406:	mov    ebp,0x7
   5b40b:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b413:	lea    r8,[rsp+0x118]
   5b41b:	lea    r9,[rsp+0x140]
   5b423:	test   ebp,ebp
   5b425:	je     5b437 <sqlite3VdbeExec+0xbf97>
   5b427:	mov    DWORD PTR [rsp+0x35c],ebp
   5b42e:	mov    ebp,DWORD PTR [rsp+0x354]
   5b435:	jmp    5b464 <sqlite3VdbeExec+0xbfc4>
   5b437:	mov    rax,QWORD PTR [r15+0x48]
   5b43b:	mov    r15,QWORD PTR [rax+0x8]
   5b43f:	mov    DWORD PTR [rsp+0x35c],ebp
   5b446:	mov    ebp,DWORD PTR [rsp+0x354]
   5b44d:	mov    eax,ebp
   5b44f:	sar    eax,0x1f
   5b452:	and    eax,0xf
   5b455:	add    eax,ebp
   5b457:	mov    ebp,eax
   5b459:	sar    ebp,0x4
   5b45c:	mov    QWORD PTR [rsp+0x150],r15
   5b464:	mov    r15d,DWORD PTR [rsp+0x358]
   5b46c:	add    r15d,0x1
   5b470:	mov    QWORD PTR [rsp+0xc8],r14
   5b478:	mov    r14d,DWORD PTR [rsp+0x35c]
   5b480:	mov    QWORD PTR [rsp+0x110],r13
   5b488:	mov    r13d,DWORD PTR [rsp+0x340]
   5b490:	cmp    r15d,r13d
   5b493:	jl     5b4aa <sqlite3VdbeExec+0xc00a>
   5b495:	mov    r13,QWORD PTR [rsp+0x150]
   5b49d:	mov    r15d,DWORD PTR [rsp+0x34c]
   5b4a5:	jmp    5b563 <sqlite3VdbeExec+0xc0c3>
   5b4aa:	test   r14d,r14d
   5b4ad:	je     5b4cc <sqlite3VdbeExec+0xc02c>
   5b4af:	mov    DWORD PTR [rsp+0x340],r13d
   5b4b7:	mov    r13,QWORD PTR [rsp+0x150]
   5b4bf:	mov    r15d,DWORD PTR [rsp+0x34c]
   5b4c7:	jmp    5b563 <sqlite3VdbeExec+0xc0c3>
   5b4cc:	mov    DWORD PTR [rsp+0x358],r15d
   5b4d4:	mov    r15d,DWORD PTR [rsp+0x34c]
   5b4dc:	mov    rax,r15
   5b4df:	cdq
   5b4e0:	idiv   ebp
   5b4e2:	mov    ecx,eax
   5b4e4:	sar    ecx,0x1f
   5b4e7:	and    ecx,0xf
   5b4ea:	add    ecx,eax
   5b4ec:	and    ecx,0xfffffff0
   5b4ef:	sub    eax,ecx
   5b4f1:	mov    r13,QWORD PTR [rsp+0x150]
   5b4f9:	mov    rcx,QWORD PTR [r13+0x18]
   5b4fd:	movsxd rax,eax
   5b500:	imul   rax,rax,0x50
   5b504:	lea    r13,[rcx+rax*1]
   5b508:	cmp    QWORD PTR [rcx+rax*1+0x48],0x0
   5b50e:	je     5b532 <sqlite3VdbeExec+0xc092>
   5b510:	mov    DWORD PTR [rsp+0x354],ebp
   5b517:	mov    r15,r13
   5b51a:	mov    r13,QWORD PTR [rsp+0x110]
   5b522:	mov    rbp,r14
   5b525:	mov    r14,QWORD PTR [rsp+0xc8]
   5b52d:	jmp    5b423 <sqlite3VdbeExec+0xbf83>
   5b532:	mov    r14d,0x2
   5b538:	mov    QWORD PTR [rsp+0x158],r13
   5b540:	mov    DWORD PTR [rsp+0x34c],r15d
   5b548:	mov    r15,rbp
   5b54b:	mov    r13,QWORD PTR [rsp+0x110]
   5b553:	mov    rbp,r14
   5b556:	mov    r14,QWORD PTR [rsp+0xc8]
   5b55e:	jmp    5b1f0 <sqlite3VdbeExec+0xbd50>
   5b563:	test   r14d,r14d
   5b566:	jne    5b59e <sqlite3VdbeExec+0xc0fe>
   5b568:	mov    rax,QWORD PTR [r13+0x18]
   5b56c:	mov    ecx,r15d
   5b56f:	sar    ecx,0x1f
   5b572:	and    ecx,0xf
   5b575:	add    ecx,r15d
   5b578:	and    ecx,0xfffffff0
   5b57b:	mov    r11d,ecx
   5b57e:	mov    ecx,r15d
   5b581:	sub    ecx,r11d
   5b584:	movsxd rcx,ecx
   5b587:	imul   rcx,rcx,0x50
   5b58b:	lea    rbp,[rsp+0x160]
   5b593:	mov    rdx,QWORD PTR [rbp+0x0]
   5b597:	mov    QWORD PTR [rax+rcx*1+0x48],rdx
   5b59c:	jmp    5b5c2 <sqlite3VdbeExec+0xc122>
   5b59e:	lea    rbp,[rsp+0x160]
   5b5a6:	mov    rax,QWORD PTR [rbp+0x0]
   5b5aa:	mov    QWORD PTR [rsp+0xb0],rdi
   5b5b2:	mov    rdi,rax
   5b5b5:	call   5b5ba <sqlite3VdbeExec+0xc11a>
   5b5ba:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b5c2:	mov    ebp,r14d
   5b5c5:	mov    r14,QWORD PTR [rsp+0xc8]
   5b5cd:	mov    r13,QWORD PTR [rsp+0x110]
   5b5d5:	mov    r15,rbp
   5b5d8:	mov    rbp,rbx
   5b5db:	mov    ebx,DWORD PTR [rsp+0x350]
   5b5e2:	lea    r8,[rsp+0x118]
   5b5ea:	lea    r9,[rsp+0x140]
   5b5f2:	mov    DWORD PTR [rsp+0x34c],ebx
   5b5f9:	mov    ebx,DWORD PTR [rsp+0x344]
   5b600:	add    ebx,0x10
   5b603:	mov    r11,r15
   5b606:	mov    r15,r12
   5b609:	mov    r12,r11
   5b60c:	cmp    ebx,DWORD PTR [r13+0xc]
   5b610:	jl     5b622 <sqlite3VdbeExec+0xc182>
   5b612:	mov    rbx,r15
   5b615:	mov    r15d,DWORD PTR [rsp+0x31c]
   5b61d:	jmp    5ae69 <sqlite3VdbeExec+0xb9c9>
   5b622:	test   r12d,r12d
   5b625:	je     5b637 <sqlite3VdbeExec+0xc197>
   5b627:	mov    rbx,r15
   5b62a:	mov    r15d,DWORD PTR [rsp+0x31c]
   5b632:	jmp    5ae69 <sqlite3VdbeExec+0xb9c9>
   5b637:	lea    r12,[rsp+0x148]
   5b63f:	mov    QWORD PTR [r12],0x0
   5b647:	mov    eax,DWORD PTR [r13+0xc]
   5b64b:	sub    eax,ebx
   5b64d:	cmp    eax,0x10
   5b650:	jge    5afb7 <sqlite3VdbeExec+0xbb17>
   5b656:	mov    eax,DWORD PTR [r13+0xc]
   5b65a:	sub    eax,ebx
   5b65c:	mov    DWORD PTR [rsp+0x344],ebx
   5b663:	mov    ebx,DWORD PTR [rsp+0x34c]
   5b66a:	mov    r12,r15
   5b66d:	mov    r15d,DWORD PTR [rsp+0x31c]
   5b675:	jmp    5afd5 <sqlite3VdbeExec+0xbb35>
   5b67a:	mov    rax,QWORD PTR [r8]
   5b67d:	mov    QWORD PTR [rsp+0xb0],rdi
   5b685:	mov    rdi,rax
   5b688:	call   5b68d <sqlite3VdbeExec+0xc1ed>
   5b68d:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b695:	lea    r8,[rsp+0x118]
   5b69d:	lea    r9,[rsp+0x140]
   5b6a5:	mov    r13d,DWORD PTR [rsp+0x348]
   5b6ad:	add    r13d,0x1
   5b6b1:	mov    DWORD PTR [rsp+0x31c],r15d
   5b6b9:	mov    r15,QWORD PTR [rsp+0x120]
   5b6c1:	test   r12d,r12d
   5b6c4:	je     5b6d8 <sqlite3VdbeExec+0xc238>
   5b6c6:	mov    QWORD PTR [rsp+0x100],rbx
   5b6ce:	mov    rbx,QWORD PTR [rsp+0x138]
   5b6d6:	jmp    5b753 <sqlite3VdbeExec+0xc2b3>
   5b6d8:	mov    QWORD PTR [rsp+0x100],rbx
   5b6e0:	mov    rbx,QWORD PTR [rsp+0x138]
   5b6e8:	movzx  eax,BYTE PTR [rbx+0x5b]
   5b6ec:	cmp    r13d,eax
   5b6ef:	jge    5b753 <sqlite3VdbeExec+0xc2b3>
   5b6f1:	lea    rax,[rbx+0x60]
   5b6f5:	movsxd rcx,r13d
   5b6f8:	imul   rcx,rcx,0x68
   5b6fc:	mov    DWORD PTR [rsp+0x348],r13d
   5b704:	lea    r13,[rbx+rcx*1+0x60]
   5b709:	mov    QWORD PTR [r8],0x0
   5b710:	movsxd rax,DWORD PTR [rax+rcx*1+0xc]
   5b715:	xor    ecx,ecx
   5b717:	mov    edx,0x10
   5b71c:	mov    QWORD PTR [rsp+0x120],r15
   5b724:	mov    r15d,DWORD PTR [rsp+0x31c]
   5b72c:	mov    DWORD PTR [rsp+0x33c],r12d
   5b734:	mov    r12,r13
   5b737:	mov    r13,rbx
   5b73a:	mov    rbx,QWORD PTR [rsp+0x100]
   5b742:	mov    r11,rdx
   5b745:	mov    rdx,rax
   5b748:	mov    rax,rcx
   5b74b:	mov    rcx,r11
   5b74e:	jmp    5ae05 <sqlite3VdbeExec+0xb965>
   5b753:	test   r12d,r12d
   5b756:	je     5b776 <sqlite3VdbeExec+0xc2d6>
   5b758:	mov    QWORD PTR [rsp+0xb0],rdi
   5b760:	mov    rdi,r15
   5b763:	call   5b768 <sqlite3VdbeExec+0xc2c8>
   5b768:	xor    r13d,r13d
   5b76b:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b773:	mov    r15,r13
   5b776:	lea    r13,[rsp+0x130]
   5b77e:	mov    QWORD PTR [r13+0x0],r15
   5b782:	test   r12d,r12d
   5b785:	jne    5b7c6 <sqlite3VdbeExec+0xc326>
   5b787:	mov    rax,QWORD PTR [r13+0x0]
   5b78b:	xor    ecx,ecx
   5b78d:	mov    r12,QWORD PTR [rsp+0x108]
   5b795:	mov    QWORD PTR [rsp+0xb0],rdi
   5b79d:	mov    rdi,r12
   5b7a0:	mov    rsi,rax
   5b7a3:	mov    rdx,rcx
   5b7a6:	call   5b7ab <sqlite3VdbeExec+0xc30b>
   5b7ab:	mov    r12d,eax
   5b7ae:	mov    rax,QWORD PTR [r13+0x0]
   5b7b2:	mov    QWORD PTR [rbx+0x18],rax
   5b7b6:	mov    QWORD PTR [r13+0x0],0x0
   5b7be:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b7c6:	test   r12d,r12d
   5b7c9:	je     5b7e7 <sqlite3VdbeExec+0xc347>
   5b7cb:	mov    rax,QWORD PTR [r13+0x0]
   5b7cf:	mov    QWORD PTR [rsp+0xb0],rdi
   5b7d7:	mov    rdi,rax
   5b7da:	call   5b7df <sqlite3VdbeExec+0xc33f>
   5b7df:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b7e7:	mov    ebx,r12d
   5b7ea:	mov    DWORD PTR [rsp+0x338],0x0
   5b7f5:	mov    r15d,DWORD PTR [rsp+0x31c]
   5b7fd:	mov    r12,rbx
   5b800:	mov    rbx,QWORD PTR [rsp+0x100]
   5b808:	mov    r13,r12
   5b80b:	mov    r12,QWORD PTR [rsp+0x128]
   5b813:	jmp    5b8f2 <sqlite3VdbeExec+0xc452>
   5b818:	mov    r13,QWORD PTR [r12+0x28]
   5b81d:	mov    QWORD PTR [rsp+0xb0],rdi
   5b825:	mov    rdi,r13
   5b828:	call   5b82d <sqlite3VdbeExec+0xc38d>
   5b82d:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b835:	test   eax,eax
   5b837:	jne    5b8ce <sqlite3VdbeExec+0xc42e>
   5b83d:	mov    DWORD PTR [rsp+0x338],0x0
   5b848:	xor    eax,eax
   5b84a:	jmp    5b8c8 <sqlite3VdbeExec+0xc428>
   5b84c:	mov    rcx,QWORD PTR [r13+0x88]
   5b853:	cmp    BYTE PTR [rcx+0x8],0x0
   5b857:	jne    5b8cc <sqlite3VdbeExec+0xc42c>
   5b859:	mov    rax,QWORD PTR [rcx+0x50]
   5b85d:	movzx  edx,WORD PTR [rcx+0x1a]
   5b861:	mov    rsi,QWORD PTR [rcx+0x60]
   5b865:	movzx  r8d,WORD PTR [r13+0x56]
   5b86a:	shl    r8d,1
   5b86d:	movzx  esi,BYTE PTR [rsi+r8*1]
   5b872:	shl    esi,0x8
   5b875:	mov    rcx,QWORD PTR [rcx+0x60]
   5b879:	movzx  r8d,WORD PTR [r13+0x56]
   5b87e:	shl    r8d,1
   5b881:	movzx  ecx,BYTE PTR [rcx+r8*1+0x1]
   5b887:	or     esi,ecx
   5b889:	and    edx,esi
   5b88b:	movzx  ecx,BYTE PTR [rax+rdx*1]
   5b88f:	shl    ecx,0x18
   5b892:	movzx  esi,BYTE PTR [rax+rdx*1+0x1]
   5b897:	shl    esi,0x10
   5b89a:	or     ecx,esi
   5b89c:	movzx  esi,BYTE PTR [rax+rdx*1+0x2]
   5b8a1:	shl    esi,0x8
   5b8a4:	or     ecx,esi
   5b8a6:	movzx  eax,BYTE PTR [rax+rdx*1+0x3]
   5b8ab:	or     ecx,eax
   5b8ad:	mov    QWORD PTR [rsp+0xb0],rdi
   5b8b5:	mov    rdi,r13
   5b8b8:	mov    rsi,rcx
   5b8bb:	call   5b8c0 <sqlite3VdbeExec+0xc420>
   5b8c0:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b8c8:	test   eax,eax
   5b8ca:	je     5b84c <sqlite3VdbeExec+0xc3ac>
   5b8cc:	jmp    5b8e0 <sqlite3VdbeExec+0xc440>
   5b8ce:	cmp    eax,0x10
   5b8d1:	jne    5b8e0 <sqlite3VdbeExec+0xc440>
   5b8d3:	mov    DWORD PTR [rsp+0x338],0x1
   5b8de:	xor    eax,eax
   5b8e0:	mov    r13d,eax
   5b8e3:	mov    BYTE PTR [r12+0x3],0x0
   5b8e9:	mov    DWORD PTR [r12+0x18],0x0
   5b8f2:	test   r13d,r13d
   5b8f5:	je     5b917 <sqlite3VdbeExec+0xc477>
   5b8f7:	mov    QWORD PTR [rsp+0xe8],rbp
   5b8ff:	mov    rbp,r13
   5b902:	mov    r13,QWORD PTR [rsp+0xd0]
   5b90a:	mov    rbx,QWORD PTR [rsp+0xf8]
   5b912:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5b917:	mov    eax,DWORD PTR [rsp+0x338]
   5b91e:	mov    BYTE PTR [r12+0x2],al
   5b923:	cmp    DWORD PTR [rbp+0x8],0x0
   5b927:	jle    5b943 <sqlite3VdbeExec+0xc4a3>
   5b929:	cmp    DWORD PTR [rsp+0x338],0x0
   5b931:	je     5b943 <sqlite3VdbeExec+0xc4a3>
   5b933:	mov    r12,r14
   5b936:	mov    DWORD PTR [rsp+0x32c],r13d
   5b93e:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5b943:	mov    DWORD PTR [rsp+0x31c],r15d
   5b94b:	mov    DWORD PTR [rsp+0x32c],r13d
   5b953:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5b958:	mov    r15d,DWORD PTR [rsp+0x31c]
   5b960:	mov    QWORD PTR [rsp+0xd0],r12
   5b968:	mov    rax,QWORD PTR [rdi+0x78]
   5b96c:	movsxd rcx,DWORD PTR [rbp+0x4]
   5b970:	mov    rax,QWORD PTR [rax+rcx*8]
   5b974:	mov    rax,QWORD PTR [rax+0x28]
   5b978:	cmp    BYTE PTR [rax],0x0
   5b97b:	jne    5b98d <sqlite3VdbeExec+0xc4ed>
   5b97d:	mov    DWORD PTR [rsp+0x338],0x0
   5b988:	xor    r12d,r12d
   5b98b:	jmp    5b9c9 <sqlite3VdbeExec+0xc529>
   5b98d:	mov    QWORD PTR [rsp+0xb0],rdi
   5b995:	mov    rdi,rax
   5b998:	call   5b99d <sqlite3VdbeExec+0xc4fd>
   5b99d:	mov    r12d,eax
   5b9a0:	mov    rdi,QWORD PTR [rsp+0xb0]
   5b9a8:	cmp    r12d,0x10
   5b9ac:	jne    5b9be <sqlite3VdbeExec+0xc51e>
   5b9ae:	mov    DWORD PTR [rsp+0x338],0x1
   5b9b9:	xor    r12d,r12d
   5b9bc:	jmp    5b9c9 <sqlite3VdbeExec+0xc529>
   5b9be:	mov    DWORD PTR [rsp+0x338],0x0
   5b9c9:	test   r12d,r12d
   5b9cc:	je     5b9ee <sqlite3VdbeExec+0xc54e>
   5b9ce:	mov    QWORD PTR [rsp+0xe8],rbp
   5b9d6:	mov    rbp,r12
   5b9d9:	mov    r13,QWORD PTR [rsp+0xd0]
   5b9e1:	mov    rbx,QWORD PTR [rsp+0xf8]
   5b9e9:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5b9ee:	cmp    DWORD PTR [rsp+0x338],0x0
   5b9f6:	je     5ba08 <sqlite3VdbeExec+0xc568>
   5b9f8:	mov    DWORD PTR [rsp+0x32c],r12d
   5ba00:	mov    r12,r14
   5ba03:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5ba08:	mov    DWORD PTR [rsp+0x31c],r15d
   5ba10:	mov    DWORD PTR [rsp+0x32c],r12d
   5ba18:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5ba1d:	mov    r15d,DWORD PTR [rsp+0x31c]
   5ba25:	mov    QWORD PTR [rsp+0xd0],r12
   5ba2d:	mov    rax,QWORD PTR [rdi+0x78]
   5ba31:	movsxd rcx,DWORD PTR [rbp+0x4]
   5ba35:	mov    r12,QWORD PTR [rax+rcx*8]
   5ba39:	mov    r13,QWORD PTR [r12+0x28]
   5ba3e:	cmp    BYTE PTR [r13+0x58],0x0
   5ba43:	je     5ba92 <sqlite3VdbeExec+0xc5f2>
   5ba45:	mov    QWORD PTR [rsp+0x128],r12
   5ba4d:	lea    r12,[rsp+0x338]
   5ba55:	mov    DWORD PTR [r12],0x0
   5ba5d:	mov    rax,QWORD PTR [r13+0x18]
   5ba61:	mov    rcx,r12
   5ba64:	mov    QWORD PTR [rsp+0xb0],rdi
   5ba6c:	mov    rdi,rax
   5ba6f:	mov    rsi,rcx
   5ba72:	call   5ba77 <sqlite3VdbeExec+0xc5d7>
   5ba77:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ba7f:	test   eax,eax
   5ba81:	jne    5ba90 <sqlite3VdbeExec+0xc5f0>
   5ba83:	mov    ecx,0x65
   5ba88:	cmp    DWORD PTR [r12],0x0
   5ba8d:	cmovne eax,ecx
   5ba90:	jmp    5bb05 <sqlite3VdbeExec+0xc665>
   5ba92:	mov    QWORD PTR [rsp+0x128],r12
   5ba9a:	mov    r12,QWORD PTR [r13+0x38]
   5ba9e:	mov    rax,QWORD PTR [r12+0x8]
   5baa3:	mov    QWORD PTR [r13+0x38],rax
   5baa7:	mov    QWORD PTR [r12+0x8],0x0
   5bab0:	cmp    QWORD PTR [r13+0x40],0x0
   5bab5:	jne    5baf6 <sqlite3VdbeExec+0xc656>
   5bab7:	jmp    5baf1 <sqlite3VdbeExec+0xc651>
   5bab9:	mov    QWORD PTR [rsp+0x130],r13
   5bac1:	mov    r13,QWORD PTR [r12+0x8]
   5bac6:	test   r12,r12
   5bac9:	je     5bae6 <sqlite3VdbeExec+0xc646>
   5bacb:	mov    QWORD PTR [rsp+0xb0],rdi
   5bad3:	mov    rdi,r14
   5bad6:	mov    rsi,r12
   5bad9:	call   5bade <sqlite3VdbeExec+0xc63e>
   5bade:	mov    rdi,QWORD PTR [rsp+0xb0]
   5bae6:	mov    r12,r13
   5bae9:	mov    r13,QWORD PTR [rsp+0x130]
   5baf1:	test   r12,r12
   5baf4:	jne    5bab9 <sqlite3VdbeExec+0xc619>
   5baf6:	xor    eax,eax
   5baf8:	mov    ecx,0x65
   5bafd:	cmp    QWORD PTR [r13+0x38],0x0
   5bb02:	cmove  eax,ecx
   5bb05:	mov    r12d,eax
   5bb08:	mov    r13,r12
   5bb0b:	mov    r12,QWORD PTR [rsp+0x128]
   5bb13:	jmp    5bbd4 <sqlite3VdbeExec+0xc734>
   5bb18:	mov    r15d,DWORD PTR [rsp+0x31c]
   5bb20:	mov    QWORD PTR [rsp+0xd0],r12
   5bb28:	mov    rax,QWORD PTR [rdi+0x78]
   5bb2c:	movsxd rcx,DWORD PTR [rbp+0x4]
   5bb30:	mov    r12,QWORD PTR [rax+rcx*8]
   5bb34:	mov    rax,QWORD PTR [r12+0x28]
   5bb39:	mov    ecx,DWORD PTR [rbp+0xc]
   5bb3c:	movzx  ecx,BYTE PTR [rax+0x1]
   5bb40:	and    ecx,0xfffffff1
   5bb43:	mov    BYTE PTR [rax+0x1],cl
   5bb46:	mov    WORD PTR [rax+0x46],0x0
   5bb4c:	cmp    BYTE PTR [rax],0x0
   5bb4f:	jne    5bb65 <sqlite3VdbeExec+0xc6c5>
   5bb51:	cmp    WORD PTR [rax+0x56],0x0
   5bb56:	je     5bb65 <sqlite3VdbeExec+0xc6c5>
   5bb58:	mov    rcx,QWORD PTR [rax+0x88]
   5bb5f:	cmp    BYTE PTR [rcx+0x8],0x0
   5bb63:	jne    5bb82 <sqlite3VdbeExec+0xc6e2>
   5bb65:	mov    QWORD PTR [rsp+0xb0],rdi
   5bb6d:	mov    rdi,rax
   5bb70:	call   5bb75 <sqlite3VdbeExec+0xc6d5>
   5bb75:	mov    r13d,eax
   5bb78:	mov    rdi,QWORD PTR [rsp+0xb0]
   5bb80:	jmp    5bb90 <sqlite3VdbeExec+0xc6f0>
   5bb82:	movzx  ecx,WORD PTR [rax+0x56]
   5bb86:	sub    ecx,0x1
   5bb89:	mov    WORD PTR [rax+0x56],cx
   5bb8d:	xor    r13d,r13d
   5bb90:	jmp    5bbd4 <sqlite3VdbeExec+0xc734>
   5bb92:	mov    r15d,DWORD PTR [rsp+0x31c]
   5bb9a:	mov    QWORD PTR [rsp+0xd0],r12
   5bba2:	mov    rax,QWORD PTR [rdi+0x78]
   5bba6:	movsxd rcx,DWORD PTR [rbp+0x4]
   5bbaa:	mov    r12,QWORD PTR [rax+rcx*8]
   5bbae:	mov    rax,QWORD PTR [r12+0x28]
   5bbb3:	mov    ecx,DWORD PTR [rbp+0xc]
   5bbb6:	mov    QWORD PTR [rsp+0xb0],rdi
   5bbbe:	mov    rdi,rax
   5bbc1:	mov    rsi,rcx
   5bbc4:	call   5bbc9 <sqlite3VdbeExec+0xc729>
   5bbc9:	mov    r13d,eax
   5bbcc:	mov    rdi,QWORD PTR [rsp+0xb0]
   5bbd4:	mov    DWORD PTR [r12+0x18],0x0
   5bbdd:	test   r13d,r13d
   5bbe0:	jne    5bc1a <sqlite3VdbeExec+0xc77a>
   5bbe2:	mov    BYTE PTR [r12+0x2],0x0
   5bbe8:	movzx  eax,WORD PTR [rbp+0x2]
   5bbec:	mov    ecx,DWORD PTR [rdi+rax*4+0xd4]
   5bbf3:	add    ecx,0x1
   5bbf6:	mov    DWORD PTR [rdi+rax*4+0xd4],ecx
   5bbfd:	mov    r12d,DWORD PTR [rsp+0x334]
   5bc05:	mov    DWORD PTR [rsp+0x32c],r13d
   5bc0d:	mov    r13,QWORD PTR [rsp+0xf0]
   5bc15:	jmp    4f7bd <sqlite3VdbeExec+0x31d>
   5bc1a:	cmp    r13d,0x65
   5bc1e:	je     5bc40 <sqlite3VdbeExec+0xc7a0>
   5bc20:	mov    QWORD PTR [rsp+0xe8],rbp
   5bc28:	mov    rbp,r13
   5bc2b:	mov    r13,QWORD PTR [rsp+0xd0]
   5bc33:	mov    rbx,QWORD PTR [rsp+0xf8]
   5bc3b:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5bc40:	mov    r13,rbx
   5bc43:	mov    ebx,DWORD PTR [rsp+0x330]
   5bc4a:	mov    BYTE PTR [r12+0x2],0x1
   5bc50:	mov    r12d,DWORD PTR [rsp+0x334]
   5bc58:	mov    QWORD PTR [rsp+0xe8],rbp
   5bc60:	mov    QWORD PTR [rsp+0x100],r13
   5bc68:	mov    r13,QWORD PTR [rsp+0xf0]
   5bc70:	xor    r11d,r11d
   5bc73:	mov    DWORD PTR [rsp+0x32c],r11d
   5bc7b:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   5bc80:	mov    r15d,DWORD PTR [rsp+0x31c]
   5bc88:	mov    r13,rbx
   5bc8b:	mov    ebx,DWORD PTR [rsp+0x330]
   5bc92:	mov    QWORD PTR [rsp+0xd0],r12
   5bc9a:	mov    rax,QWORD PTR [rdi+0x78]
   5bc9e:	movsxd rcx,DWORD PTR [rbp+0x4]
   5bca2:	mov    r12,QWORD PTR [rax+rcx*8]
   5bca6:	movsxd rax,DWORD PTR [rbp+0x8]
   5bcaa:	imul   rax,rax,0x38
   5bcae:	mov    DWORD PTR [rsp+0x330],ebx
   5bcb5:	lea    rbx,[r13+rax*1+0x0]
   5bcba:	movzx  eax,WORD PTR [rbp+0x2]
   5bcbe:	and    eax,0x1
   5bcc1:	test   eax,eax
   5bcc3:	je     5bcd1 <sqlite3VdbeExec+0xc831>
   5bcc5:	mov    rax,QWORD PTR [rdi+0x38]
   5bcc9:	add    rax,0x1
   5bccd:	mov    QWORD PTR [rdi+0x38],rax
   5bcd1:	movzx  eax,WORD PTR [rbx+0x14]
   5bcd5:	and    eax,0x400
   5bcda:	test   eax,eax
   5bcdc:	je     5bd94 <sqlite3VdbeExec+0xc8f4>
   5bce2:	mov    eax,DWORD PTR [rbx+0x10]
   5bce5:	add    eax,DWORD PTR [rbx]
   5bce7:	test   eax,eax
   5bce9:	jg     5bd08 <sqlite3VdbeExec+0xc868>
   5bceb:	movzx  eax,WORD PTR [rbx+0x14]
   5bcef:	and    eax,0x10
   5bcf2:	test   eax,eax
   5bcf4:	jne    5bd03 <sqlite3VdbeExec+0xc863>
   5bcf6:	xor    r11d,r11d
   5bcf9:	mov    DWORD PTR [rsp+0x338],r11d
   5bd01:	jmp    5bd82 <sqlite3VdbeExec+0xc8e2>
   5bd03:	mov    eax,0x1
   5bd08:	mov    ecx,0x1
   5bd0d:	mov    QWORD PTR [rsp+0xb0],rdi
   5bd15:	mov    rdi,rbx
   5bd18:	mov    rsi,rax
   5bd1b:	mov    rdx,rcx
   5bd1e:	call   5bd23 <sqlite3VdbeExec+0xc883>
   5bd23:	mov    rdi,QWORD PTR [rsp+0xb0]
   5bd2b:	test   eax,eax
   5bd2d:	je     5bd3f <sqlite3VdbeExec+0xc89f>
   5bd2f:	mov    r11d,0x7
   5bd35:	mov    DWORD PTR [rsp+0x338],r11d
   5bd3d:	jmp    5bd82 <sqlite3VdbeExec+0xc8e2>
   5bd3f:	mov    rax,QWORD PTR [rbx+0x8]
   5bd43:	movsxd rcx,DWORD PTR [rbx+0x10]
   5bd47:	add    rax,rcx
   5bd4a:	xor    ecx,ecx
   5bd4c:	movsxd rdx,DWORD PTR [rbx]
   5bd4f:	mov    rdi,rax
   5bd52:	mov    rsi,rcx
   5bd55:	call   5bd5a <sqlite3VdbeExec+0xc8ba>
   5bd5a:	mov    eax,DWORD PTR [rbx+0x10]
   5bd5d:	add    eax,DWORD PTR [rbx]
   5bd5f:	mov    DWORD PTR [rbx+0x10],eax
   5bd62:	movzx  eax,WORD PTR [rbx+0x14]
   5bd66:	and    eax,0xfffff9ff
   5bd6b:	mov    WORD PTR [rbx+0x14],ax
   5bd6f:	mov    rdi,QWORD PTR [rsp+0xb0]
   5bd77:	xor    r11d,r11d
   5bd7a:	mov    DWORD PTR [rsp+0x338],r11d
   5bd82:	mov    QWORD PTR [rsp+0xc8],r14
   5bd8a:	mov    r14d,DWORD PTR [rsp+0x338]
   5bd92:	jmp    5bd9f <sqlite3VdbeExec+0xc8ff>
   5bd94:	mov    QWORD PTR [rsp+0xc8],r14
   5bd9c:	xor    r14d,r14d
   5bd9f:	test   r14d,r14d
   5bda2:	je     5bdcc <sqlite3VdbeExec+0xc92c>
   5bda4:	mov    QWORD PTR [rsp+0xe8],rbp
   5bdac:	mov    rbp,r14
   5bdaf:	mov    r14,QWORD PTR [rsp+0xc8]
   5bdb7:	mov    r13,QWORD PTR [rsp+0xd0]
   5bdbf:	mov    rbx,QWORD PTR [rsp+0xf8]
   5bdc7:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5bdcc:	movsxd rax,DWORD PTR [rbx+0x10]
   5bdd0:	mov    QWORD PTR [rsp+0x1b8],rax
   5bdd8:	mov    rax,QWORD PTR [rbx+0x8]
   5bddc:	mov    QWORD PTR [rsp+0x1b0],rax
   5bde4:	movsxd rax,DWORD PTR [rbp+0xc]
   5bde8:	imul   rax,rax,0x38
   5bdec:	add    rax,r13
   5bdef:	mov    QWORD PTR [rsp+0x1c8],rax
   5bdf7:	mov    eax,DWORD PTR [rbp+0x10]
   5bdfa:	mov    WORD PTR [rsp+0x1d0],ax
   5be02:	mov    rax,QWORD PTR [r12+0x28]
   5be07:	lea    rbx,[rsp+0x1b0]
   5be0f:	mov    rcx,rbx
   5be12:	movzx  edx,WORD PTR [rbp+0x2]
   5be16:	and    edx,0x8a
   5be1c:	movzx  esi,WORD PTR [rbp+0x2]
   5be20:	and    esi,0x10
   5be23:	test   esi,esi
   5be25:	je     5be2e <sqlite3VdbeExec+0xc98e>
   5be27:	mov    esi,DWORD PTR [r12+0x1c]
   5be2c:	jmp    5be30 <sqlite3VdbeExec+0xc990>
   5be2e:	xor    esi,esi
   5be30:	mov    QWORD PTR [rsp+0xb0],rdi
   5be38:	mov    rdi,rax
   5be3b:	mov    r11,rsi
   5be3e:	mov    rsi,rcx
   5be41:	mov    rcx,r11
   5be44:	call   5be49 <sqlite3VdbeExec+0xc9a9>
   5be49:	mov    r14d,eax
   5be4c:	mov    DWORD PTR [r12+0x18],0x0
   5be55:	mov    rdi,QWORD PTR [rsp+0xb0]
   5be5d:	test   r14d,r14d
   5be60:	je     5be8a <sqlite3VdbeExec+0xc9ea>
   5be62:	mov    QWORD PTR [rsp+0xe8],rbp
   5be6a:	mov    rbp,r14
   5be6d:	mov    r14,QWORD PTR [rsp+0xc8]
   5be75:	mov    r13,QWORD PTR [rsp+0xd0]
   5be7d:	mov    rbx,QWORD PTR [rsp+0xf8]
   5be85:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5be8a:	mov    DWORD PTR [rsp+0x31c],r15d
   5be92:	mov    DWORD PTR [rsp+0x32c],r14d
   5be9a:	mov    r14,QWORD PTR [rsp+0xc8]
   5bea2:	mov    rbx,r13
   5bea5:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5beaa:	mov    QWORD PTR [rsp+0xc8],r14
   5beb2:	mov    r15d,DWORD PTR [rsp+0x31c]
   5beba:	mov    r13,rbx
   5bebd:	mov    QWORD PTR [rsp+0xd0],r12
   5bec5:	mov    rax,QWORD PTR [rdi+0x78]
   5bec9:	movsxd rcx,DWORD PTR [rbp+0x4]
   5becd:	mov    r12,QWORD PTR [rax+rcx*8]
   5bed1:	movsxd rax,DWORD PTR [rbp+0x8]
   5bed5:	imul   rax,rax,0x38
   5bed9:	lea    r14,[r13+rax*1+0x0]
   5bede:	movzx  eax,WORD PTR [r13+rax*1+0x14]
   5bee4:	and    eax,0x400
   5bee9:	test   eax,eax
   5beeb:	je     5bf80 <sqlite3VdbeExec+0xcae0>
   5bef1:	mov    eax,DWORD PTR [r14+0x10]
   5bef5:	add    eax,DWORD PTR [r14]
   5bef8:	test   eax,eax
   5befa:	jg     5bf11 <sqlite3VdbeExec+0xca71>
   5befc:	movzx  eax,WORD PTR [r14+0x14]
   5bf01:	and    eax,0x10
   5bf04:	test   eax,eax
   5bf06:	jne    5bf0c <sqlite3VdbeExec+0xca6c>
   5bf08:	xor    ebx,ebx
   5bf0a:	jmp    5bf7e <sqlite3VdbeExec+0xcade>
   5bf0c:	mov    eax,0x1
   5bf11:	mov    ecx,0x1
   5bf16:	mov    QWORD PTR [rsp+0xb0],rdi
   5bf1e:	mov    rdi,r14
   5bf21:	mov    rsi,rax
   5bf24:	mov    rdx,rcx
   5bf27:	call   5bf2c <sqlite3VdbeExec+0xca8c>
   5bf2c:	mov    rdi,QWORD PTR [rsp+0xb0]
   5bf34:	test   eax,eax
   5bf36:	je     5bf3f <sqlite3VdbeExec+0xca9f>
   5bf38:	mov    ebx,0x7
   5bf3d:	jmp    5bf7e <sqlite3VdbeExec+0xcade>
   5bf3f:	mov    rax,QWORD PTR [r14+0x8]
   5bf43:	movsxd rcx,DWORD PTR [r14+0x10]
   5bf47:	add    rax,rcx
   5bf4a:	xor    ecx,ecx
   5bf4c:	movsxd rdx,DWORD PTR [r14]
   5bf4f:	mov    rdi,rax
   5bf52:	mov    rsi,rcx
   5bf55:	call   5bf5a <sqlite3VdbeExec+0xcaba>
   5bf5a:	mov    eax,DWORD PTR [r14+0x10]
   5bf5e:	add    eax,DWORD PTR [r14]
   5bf61:	mov    DWORD PTR [r14+0x10],eax
   5bf65:	movzx  eax,WORD PTR [r14+0x14]
   5bf6a:	and    eax,0xfffff9ff
   5bf6f:	mov    WORD PTR [r14+0x14],ax
   5bf74:	xor    ebx,ebx
   5bf76:	mov    rdi,QWORD PTR [rsp+0xb0]
   5bf7e:	jmp    5bf82 <sqlite3VdbeExec+0xcae2>
   5bf80:	xor    ebx,ebx
   5bf82:	test   ebx,ebx
   5bf84:	je     5bfae <sqlite3VdbeExec+0xcb0e>
   5bf86:	mov    r14,QWORD PTR [rsp+0xc8]
   5bf8e:	mov    QWORD PTR [rsp+0xe8],rbp
   5bf96:	mov    rbp,rbx
   5bf99:	mov    r13,QWORD PTR [rsp+0xd0]
   5bfa1:	mov    rbx,QWORD PTR [rsp+0xf8]
   5bfa9:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5bfae:	xor    ebx,ebx
   5bfb0:	mov    r12,QWORD PTR [r12+0x28]
   5bfb5:	mov    rax,QWORD PTR [r14+0x8]
   5bfb9:	movzx  eax,BYTE PTR [rax+0x1]
   5bfbd:	mov    DWORD PTR [rsp+0x338],eax
   5bfc4:	cmp    DWORD PTR [rsp+0x338],0x80
   5bfcf:	jge    5bfde <sqlite3VdbeExec+0xcb3e>
   5bfd1:	lea    rbx,[rsp+0x338]
   5bfd9:	jmp    5c0b0 <sqlite3VdbeExec+0xcc10>
   5bfde:	mov    rax,QWORD PTR [r14+0x8]
   5bfe2:	lea    rcx,[rax+0x1]
   5bfe6:	movzx  eax,BYTE PTR [rax+0x2]
   5bfea:	and    eax,0x80
   5bfef:	test   eax,eax
   5bff1:	jne    5c011 <sqlite3VdbeExec+0xcb71>
   5bff3:	movzx  eax,BYTE PTR [rcx]
   5bff6:	and    eax,0x7f
   5bff9:	shl    eax,0x7
   5bffc:	movzx  ecx,BYTE PTR [rcx+0x1]
   5c000:	or     eax,ecx
   5c002:	lea    rbx,[rsp+0x338]
   5c00a:	mov    DWORD PTR [rbx],eax
   5c00c:	jmp    5c0b0 <sqlite3VdbeExec+0xcc10>
   5c011:	lea    rbx,[rsp+0x338]
   5c019:	movzx  eax,BYTE PTR [rcx+0x2]
   5c01d:	and    eax,0x80
   5c022:	test   eax,eax
   5c024:	jne    5c045 <sqlite3VdbeExec+0xcba5>
   5c026:	movzx  eax,BYTE PTR [rcx]
   5c029:	and    eax,0x7f
   5c02c:	shl    eax,0xe
   5c02f:	movzx  edx,BYTE PTR [rcx+0x1]
   5c033:	and    edx,0x7f
   5c036:	shl    edx,0x7
   5c039:	or     eax,edx
   5c03b:	movzx  ecx,BYTE PTR [rcx+0x2]
   5c03f:	or     eax,ecx
   5c041:	mov    DWORD PTR [rbx],eax
   5c043:	jmp    5c0b0 <sqlite3VdbeExec+0xcc10>
   5c045:	mov    rbx,rbp
   5c048:	lea    rbp,[rsp+0x130]
   5c050:	mov    rax,rbp
   5c053:	mov    QWORD PTR [rsp+0xb0],rdi
   5c05b:	mov    rdi,rcx
   5c05e:	mov    rsi,rax
   5c061:	call   5c066 <sqlite3VdbeExec+0xcbc6>
   5c066:	movzx  eax,al
   5c069:	mov    eax,0xffffffff
   5c06e:	and    rax,QWORD PTR [rbp+0x0]
   5c072:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c07a:	cmp    rax,QWORD PTR [rbp+0x0]
   5c07e:	je     5c09a <sqlite3VdbeExec+0xcbfa>
   5c080:	lea    rbp,[rsp+0x338]
   5c088:	mov    DWORD PTR [rbp+0x0],0xffffffff
   5c08f:	mov    r11,rbx
   5c092:	mov    rbx,rbp
   5c095:	mov    rbp,r11
   5c098:	jmp    5c0b0 <sqlite3VdbeExec+0xcc10>
   5c09a:	mov    r11,rbx
   5c09d:	mov    rbx,rbp
   5c0a0:	mov    rbp,r11
   5c0a3:	mov    rax,QWORD PTR [rbx]
   5c0a6:	lea    rbx,[rsp+0x338]
   5c0ae:	mov    DWORD PTR [rbx],eax
   5c0b0:	cmp    DWORD PTR [rbx],0x0
   5c0b3:	jle    5c0cf <sqlite3VdbeExec+0xcc2f>
   5c0b5:	cmp    DWORD PTR [rbx],0xa
   5c0b8:	jge    5c0cf <sqlite3VdbeExec+0xcc2f>
   5c0ba:	cmp    DWORD PTR [rbx],0x7
   5c0bd:	je     5c0cf <sqlite3VdbeExec+0xcc2f>
   5c0bf:	movzx  eax,BYTE PTR [r12+0x5c]
   5c0c5:	and    eax,0x1
   5c0c8:	mov    BYTE PTR [r12+0x5c],al
   5c0cd:	jmp    5c0f3 <sqlite3VdbeExec+0xcc53>
   5c0cf:	cmp    DWORD PTR [rbx],0xa
   5c0d2:	jle    5c0ed <sqlite3VdbeExec+0xcc4d>
   5c0d4:	mov    eax,DWORD PTR [rbx]
   5c0d6:	and    eax,0x1
   5c0d9:	test   eax,eax
   5c0db:	je     5c0ed <sqlite3VdbeExec+0xcc4d>
   5c0dd:	movzx  eax,BYTE PTR [r12+0x5c]
   5c0e3:	and    eax,0x2
   5c0e6:	mov    BYTE PTR [r12+0x5c],al
   5c0eb:	jmp    5c0f3 <sqlite3VdbeExec+0xcc53>
   5c0ed:	mov    BYTE PTR [r12+0x5c],0x0
   5c0f3:	movsxd rax,DWORD PTR [r14+0x10]
   5c0f7:	lea    rbx,[rax+0x10]
   5c0fb:	mov    eax,DWORD PTR [r14+0x10]
   5c0ff:	movsxd rcx,DWORD PTR [r14+0x10]
   5c103:	mov    edx,0x1
   5c108:	mov    r11,rdx
   5c10b:	mov    rdx,rcx
   5c10e:	mov    rcx,r11
   5c111:	jmp    5c116 <sqlite3VdbeExec+0xcc76>
   5c113:	add    ecx,0x1
   5c116:	shr    rdx,0x7
   5c11a:	test   rdx,rdx
   5c11d:	jne    5c113 <sqlite3VdbeExec+0xcc73>
   5c11f:	add    eax,ecx
   5c121:	mov    QWORD PTR [rsp+0x128],r14
   5c129:	movsxd r14,eax
   5c12c:	cmp    DWORD PTR [r12+0x4],0x0
   5c132:	jne    5c141 <sqlite3VdbeExec+0xcca1>
   5c134:	xor    r11d,r11d
   5c137:	mov    DWORD PTR [rsp+0x33c],r11d
   5c13f:	jmp    5c1bd <sqlite3VdbeExec+0xcd1d>
   5c141:	cmp    QWORD PTR [r12+0x40],0x0
   5c147:	je     5c284 <sqlite3VdbeExec+0xcde4>
   5c14d:	cmp    DWORD PTR [r12+0x50],0x0
   5c153:	je     5c274 <sqlite3VdbeExec+0xcdd4>
   5c159:	movsxd rax,DWORD PTR [r12+0x50]
   5c15e:	add    rax,rbx
   5c161:	movsxd rcx,DWORD PTR [r12+0x4]
   5c166:	cmp    rax,rcx
   5c169:	jg     5c178 <sqlite3VdbeExec+0xccd8>
   5c16b:	xor    r11d,r11d
   5c16e:	mov    DWORD PTR [rsp+0x33c],r11d
   5c176:	jmp    5c1bd <sqlite3VdbeExec+0xcd1d>
   5c178:	mov    QWORD PTR [rsp+0x138],r14
   5c180:	mov    QWORD PTR [rsp+0xb0],rdi
   5c188:	mov    rdi,r12
   5c18b:	call   5c190 <sqlite3VdbeExec+0xccf0>
   5c190:	mov    r14d,eax
   5c193:	mov    QWORD PTR [r12+0x48],0x0
   5c19c:	mov    DWORD PTR [r12+0x50],0x0
   5c1a5:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c1ad:	mov    DWORD PTR [rsp+0x33c],r14d
   5c1b5:	mov    r14,QWORD PTR [rsp+0x138]
   5c1bd:	mov    rax,r14
   5c1c0:	add    rax,QWORD PTR [r12+0x48]
   5c1c5:	mov    QWORD PTR [r12+0x48],rax
   5c1ca:	movsxd rax,DWORD PTR [r12+0x8]
   5c1cf:	cmp    r14,rax
   5c1d2:	jle    5c1d9 <sqlite3VdbeExec+0xcd39>
   5c1d4:	mov    DWORD PTR [r12+0x8],r14d
   5c1d9:	cmp    QWORD PTR [r12+0x40],0x0
   5c1df:	je     5c3e4 <sqlite3VdbeExec+0xcf44>
   5c1e5:	movsxd rax,DWORD PTR [r12+0x50]
   5c1ea:	add    rax,rbx
   5c1ed:	cmp    eax,DWORD PTR [r12+0x54]
   5c1f2:	jg     5c201 <sqlite3VdbeExec+0xcd61>
   5c1f4:	mov    QWORD PTR [rsp+0x130],rbx
   5c1fc:	jmp    5c39a <sqlite3VdbeExec+0xcefa>
   5c201:	movsxd rcx,DWORD PTR [r12+0x54]
   5c206:	mov    r14,rcx
   5c209:	shl    r14,1
   5c20c:	cmp    QWORD PTR [r12+0x38],0x0
   5c212:	jne    5c23a <sqlite3VdbeExec+0xcd9a>
   5c214:	mov    QWORD PTR [rsp+0x130],rbx
   5c21c:	mov    rbx,r14
   5c21f:	mov    r14,QWORD PTR [rsp+0x128]
   5c227:	mov    r11d,0xffffffff
   5c22d:	mov    DWORD PTR [rsp+0x348],r11d
   5c235:	jmp    5c315 <sqlite3VdbeExec+0xce75>
   5c23a:	mov    rcx,QWORD PTR [r12+0x38]
   5c23f:	sub    rcx,QWORD PTR [r12+0x40]
   5c244:	mov    QWORD PTR [rsp+0x108],r14
   5c24c:	mov    r14d,ecx
   5c24f:	mov    QWORD PTR [rsp+0x130],rbx
   5c257:	mov    rbx,QWORD PTR [rsp+0x108]
   5c25f:	mov    DWORD PTR [rsp+0x348],r14d
   5c267:	mov    r14,QWORD PTR [rsp+0x128]
   5c26f:	jmp    5c315 <sqlite3VdbeExec+0xce75>
   5c274:	xor    r11d,r11d
   5c277:	mov    DWORD PTR [rsp+0x33c],r11d
   5c27f:	jmp    5c1bd <sqlite3VdbeExec+0xcd1d>
   5c284:	mov    rax,QWORD PTR [r12+0x48]
   5c289:	movsxd rcx,DWORD PTR [r12+0x4]
   5c28e:	cmp    rax,rcx
   5c291:	jg     5c178 <sqlite3VdbeExec+0xccd8>
   5c297:	mov    rax,QWORD PTR [r12+0x48]
   5c29c:	movsxd rcx,DWORD PTR [r12]
   5c2a0:	cmp    rax,rcx
   5c2a3:	jle    5c2c7 <sqlite3VdbeExec+0xce27>
   5c2a5:	mov    eax,DWORD PTR [rip+0x0]        # 5c2ab <sqlite3VdbeExec+0xce0b>
   5c2ab:	test   eax,eax
   5c2ad:	mov    eax,0x0
   5c2b2:	setne  al
   5c2b5:	mov    QWORD PTR [rsp+0x138],r14
   5c2bd:	mov    r14,QWORD PTR [rsp+0x128]
   5c2c5:	jmp    5c2d9 <sqlite3VdbeExec+0xce39>
   5c2c7:	xor    eax,eax
   5c2c9:	mov    QWORD PTR [rsp+0x138],r14
   5c2d1:	mov    r14,QWORD PTR [rsp+0x128]
   5c2d9:	test   eax,eax
   5c2db:	jne    5c2fd <sqlite3VdbeExec+0xce5d>
   5c2dd:	mov    QWORD PTR [rsp+0x128],r14
   5c2e5:	mov    r14,QWORD PTR [rsp+0x138]
   5c2ed:	xor    r11d,r11d
   5c2f0:	mov    DWORD PTR [rsp+0x33c],r11d
   5c2f8:	jmp    5c1bd <sqlite3VdbeExec+0xcd1d>
   5c2fd:	mov    QWORD PTR [rsp+0x128],r14
   5c305:	mov    r14,QWORD PTR [rsp+0x138]
   5c30d:	jmp    5c178 <sqlite3VdbeExec+0xccd8>
   5c312:	shl    rbx,1
   5c315:	movsxd rcx,eax
   5c318:	cmp    rbx,rcx
   5c31b:	jl     5c312 <sqlite3VdbeExec+0xce72>
   5c31d:	movsxd rcx,DWORD PTR [r12+0x4]
   5c322:	cmp    rbx,rcx
   5c325:	jle    5c366 <sqlite3VdbeExec+0xcec6>
   5c327:	movsxd rbx,DWORD PTR [r12+0x4]
   5c32c:	movsxd rcx,eax
   5c32f:	cmp    rbx,rcx
   5c332:	jge    5c337 <sqlite3VdbeExec+0xce97>
   5c334:	movsxd rbx,eax
   5c337:	mov    rax,QWORD PTR [r12+0x40]
   5c33c:	mov    QWORD PTR [rsp+0xb0],rdi
   5c344:	mov    rdi,rax
   5c347:	mov    rsi,rbx
   5c34a:	call   5c34f <sqlite3VdbeExec+0xceaf>
   5c34f:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c357:	test   rax,rax
   5c35a:	jne    5c370 <sqlite3VdbeExec+0xced0>
   5c35c:	mov    ebx,0x7
   5c361:	jmp    5c455 <sqlite3VdbeExec+0xcfb5>
   5c366:	movsxd rcx,eax
   5c369:	cmp    rbx,rcx
   5c36c:	jl     5c334 <sqlite3VdbeExec+0xce94>
   5c36e:	jmp    5c337 <sqlite3VdbeExec+0xce97>
   5c370:	mov    QWORD PTR [rsp+0x128],r14
   5c378:	mov    r14d,DWORD PTR [rsp+0x348]
   5c380:	test   r14d,r14d
   5c383:	jl     5c390 <sqlite3VdbeExec+0xcef0>
   5c385:	movsxd rcx,r14d
   5c388:	add    rcx,rax
   5c38b:	mov    QWORD PTR [r12+0x38],rcx
   5c390:	mov    QWORD PTR [r12+0x40],rax
   5c395:	mov    DWORD PTR [r12+0x54],ebx
   5c39a:	mov    rax,QWORD PTR [r12+0x40]
   5c39f:	movsxd rcx,DWORD PTR [r12+0x50]
   5c3a4:	lea    rbx,[rax+rcx*1]
   5c3a8:	movsxd rax,DWORD PTR [r12+0x50]
   5c3ad:	mov    r14,QWORD PTR [rsp+0x130]
   5c3b5:	lea    rcx,[r14+0x7]
   5c3b9:	and    rcx,0xfffffffffffffff8
   5c3bd:	add    rax,rcx
   5c3c0:	mov    DWORD PTR [r12+0x50],eax
   5c3c5:	cmp    QWORD PTR [r12+0x38],0x0
   5c3cb:	je     5c3da <sqlite3VdbeExec+0xcf3a>
   5c3cd:	mov    rax,QWORD PTR [r12+0x38]
   5c3d2:	sub    rax,QWORD PTR [r12+0x40]
   5c3d7:	mov    DWORD PTR [rbx+0x8],eax
   5c3da:	mov    r14,QWORD PTR [rsp+0x128]
   5c3e2:	jmp    5c41c <sqlite3VdbeExec+0xcf7c>
   5c3e4:	mov    QWORD PTR [rsp+0xb0],rdi
   5c3ec:	mov    rdi,rbx
   5c3ef:	call   5c3f4 <sqlite3VdbeExec+0xcf54>
   5c3f4:	mov    rbx,rax
   5c3f7:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c3ff:	test   rbx,rbx
   5c402:	jne    5c40b <sqlite3VdbeExec+0xcf6b>
   5c404:	mov    ebx,0x7
   5c409:	jmp    5c455 <sqlite3VdbeExec+0xcfb5>
   5c40b:	mov    rax,QWORD PTR [r12+0x38]
   5c410:	mov    QWORD PTR [rbx+0x8],rax
   5c414:	mov    r14,QWORD PTR [rsp+0x128]
   5c41c:	lea    rax,[rbx+0x10]
   5c420:	mov    rcx,QWORD PTR [r14+0x8]
   5c424:	movsxd rdx,DWORD PTR [r14+0x10]
   5c428:	mov    QWORD PTR [rsp+0xb0],rdi
   5c430:	mov    rdi,rax
   5c433:	mov    rsi,rcx
   5c436:	call   5c43b <sqlite3VdbeExec+0xcf9b>
   5c43b:	mov    eax,DWORD PTR [r14+0x10]
   5c43f:	mov    DWORD PTR [rbx],eax
   5c441:	mov    QWORD PTR [r12+0x38],rbx
   5c446:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c44e:	mov    ebx,DWORD PTR [rsp+0x33c]
   5c455:	test   ebx,ebx
   5c457:	je     5c481 <sqlite3VdbeExec+0xcfe1>
   5c459:	mov    r14,QWORD PTR [rsp+0xc8]
   5c461:	mov    QWORD PTR [rsp+0xe8],rbp
   5c469:	mov    rbp,rbx
   5c46c:	mov    r13,QWORD PTR [rsp+0xd0]
   5c474:	mov    rbx,QWORD PTR [rsp+0xf8]
   5c47c:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c481:	mov    r14,QWORD PTR [rsp+0xc8]
   5c489:	mov    DWORD PTR [rsp+0x31c],r15d
   5c491:	mov    DWORD PTR [rsp+0x32c],ebx
   5c498:	mov    rbx,r13
   5c49b:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5c4a0:	mov    QWORD PTR [rsp+0xc8],r14
   5c4a8:	mov    r15d,DWORD PTR [rsp+0x31c]
   5c4b0:	mov    r13,rbx
   5c4b3:	mov    QWORD PTR [rsp+0xd0],r12
   5c4bb:	mov    rax,QWORD PTR [rdi+0x78]
   5c4bf:	movsxd rcx,DWORD PTR [rbp+0x4]
   5c4c3:	mov    rbx,QWORD PTR [rax+rcx*8]
   5c4c7:	mov    r12,QWORD PTR [rbx+0x28]
   5c4cb:	mov    rax,QWORD PTR [rbx+0x30]
   5c4cf:	mov    QWORD PTR [rsp+0x188],rax
   5c4d7:	mov    eax,DWORD PTR [rbp+0xc]
   5c4da:	mov    WORD PTR [rsp+0x1a4],ax
   5c4e2:	mov    BYTE PTR [rsp+0x1a6],0x0
   5c4ea:	movsxd rax,DWORD PTR [rbp+0x8]
   5c4ee:	imul   rax,rax,0x38
   5c4f2:	add    rax,r13
   5c4f5:	mov    QWORD PTR [rsp+0x190],rax
   5c4fd:	lea    r14,[rsp+0x188]
   5c505:	mov    rax,r14
   5c508:	lea    r14,[rsp+0x338]
   5c510:	mov    rcx,r14
   5c513:	mov    QWORD PTR [rsp+0xb0],rdi
   5c51b:	mov    rdi,r12
   5c51e:	mov    rsi,rax
   5c521:	mov    rdx,rcx
   5c524:	call   5c529 <sqlite3VdbeExec+0xd089>
   5c529:	mov    r14d,eax
   5c52c:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c534:	test   r14d,r14d
   5c537:	je     5c561 <sqlite3VdbeExec+0xd0c1>
   5c539:	mov    QWORD PTR [rsp+0xe8],rbp
   5c541:	mov    rbp,r14
   5c544:	mov    r14,QWORD PTR [rsp+0xc8]
   5c54c:	mov    r13,QWORD PTR [rsp+0xd0]
   5c554:	mov    rbx,QWORD PTR [rsp+0xf8]
   5c55c:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c561:	cmp    DWORD PTR [rsp+0x338],0x0
   5c569:	je     5c673 <sqlite3VdbeExec+0xd1d3>
   5c56f:	mov    rax,QWORD PTR [rbp+0x10]
   5c573:	lea    r14,[rsp+0x188]
   5c57b:	mov    rcx,r14
   5c57e:	lea    r14,[rsp+0x338]
   5c586:	mov    rdx,r14
   5c589:	xor    esi,esi
   5c58b:	mov    rdi,r12
   5c58e:	mov    r8,rsi
   5c591:	mov    rsi,rax
   5c594:	mov    r11,rdx
   5c597:	mov    rdx,rcx
   5c59a:	mov    rcx,r11
   5c59d:	call   5c5a2 <sqlite3VdbeExec+0xd102>
   5c5a2:	mov    r14d,eax
   5c5a5:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c5ad:	test   r14d,r14d
   5c5b0:	je     5c5da <sqlite3VdbeExec+0xd13a>
   5c5b2:	mov    QWORD PTR [rsp+0xe8],rbp
   5c5ba:	mov    rbp,r14
   5c5bd:	mov    r14,QWORD PTR [rsp+0xc8]
   5c5c5:	mov    r13,QWORD PTR [rsp+0xd0]
   5c5cd:	mov    rbx,QWORD PTR [rsp+0xf8]
   5c5d5:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c5da:	cmp    DWORD PTR [rsp+0x338],0x0
   5c5e2:	je     5c673 <sqlite3VdbeExec+0xd1d3>
   5c5e8:	mov    r12,QWORD PTR [rsp+0xc8]
   5c5f0:	mov    rax,QWORD PTR [r12+0x30]
   5c5f5:	and    rax,0x10000001
   5c5fb:	cmp    rax,0x1
   5c5ff:	je     5c64a <sqlite3VdbeExec+0xd1aa>
   5c601:	mov    eax,0x30b
   5c606:	mov    ecx,0x192e3
   5c60b:	lea    rdx,[rip+0x0]        # 5c612 <sqlite3VdbeExec+0xd172>
   5c612:	mov    rdi,rax
   5c615:	mov    rsi,rcx
   5c618:	call   5c61d <sqlite3VdbeExec+0xd17d>
   5c61d:	mov    ebx,eax
   5c61f:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c627:	mov    r14,r12
   5c62a:	mov    QWORD PTR [rsp+0xe8],rbp
   5c632:	mov    rbp,rbx
   5c635:	mov    r13,QWORD PTR [rsp+0xd0]
   5c63d:	mov    rbx,QWORD PTR [rsp+0xf8]
   5c645:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c64a:	mov    DWORD PTR [rbx+0x18],0x0
   5c651:	mov    DWORD PTR [rbx+0x1c],0x0
   5c658:	mov    DWORD PTR [rsp+0x31c],r15d
   5c660:	mov    DWORD PTR [rsp+0x32c],r14d
   5c668:	mov    r14,r12
   5c66b:	mov    rbx,r13
   5c66e:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5c673:	mov    eax,0x4
   5c678:	mov    QWORD PTR [rsp+0xb0],rdi
   5c680:	mov    rdi,r12
   5c683:	mov    rsi,rax
   5c686:	call   5c68b <sqlite3VdbeExec+0xd1eb>
   5c68b:	mov    r12d,eax
   5c68e:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c696:	test   r12d,r12d
   5c699:	je     5c6c3 <sqlite3VdbeExec+0xd223>
   5c69b:	mov    r14,QWORD PTR [rsp+0xc8]
   5c6a3:	mov    QWORD PTR [rsp+0xe8],rbp
   5c6ab:	mov    rbp,r12
   5c6ae:	mov    r13,QWORD PTR [rsp+0xd0]
   5c6b6:	mov    rbx,QWORD PTR [rsp+0xf8]
   5c6be:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c6c3:	mov    DWORD PTR [rbx+0x18],0x0
   5c6ca:	mov    DWORD PTR [rbx+0x1c],0x0
   5c6d1:	mov    r14,QWORD PTR [rsp+0xc8]
   5c6d9:	mov    DWORD PTR [rsp+0x31c],r15d
   5c6e1:	mov    DWORD PTR [rsp+0x32c],r12d
   5c6e9:	mov    rbx,r13
   5c6ec:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5c6f1:	mov    QWORD PTR [rsp+0xc8],r14
   5c6f9:	mov    r15d,DWORD PTR [rsp+0x31c]
   5c701:	mov    r13,rbx
   5c704:	mov    QWORD PTR [rsp+0xd0],r12
   5c70c:	mov    rax,QWORD PTR [rdi+0x78]
   5c710:	movsxd rcx,DWORD PTR [rbp+0x4]
   5c714:	mov    rbx,QWORD PTR [rax+rcx*8]
   5c718:	mov    rax,QWORD PTR [rbx+0x28]
   5c71c:	xor    ecx,ecx
   5c71e:	movzx  eax,BYTE PTR [rax]
   5c721:	cmp    ecx,eax
   5c723:	je     5c742 <sqlite3VdbeExec+0xd2a2>
   5c725:	mov    QWORD PTR [rsp+0xb0],rdi
   5c72d:	mov    rdi,rbx
   5c730:	call   5c735 <sqlite3VdbeExec+0xd295>
   5c735:	mov    r12d,eax
   5c738:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c740:	jmp    5c745 <sqlite3VdbeExec+0xd2a5>
   5c742:	xor    r12d,r12d
   5c745:	test   r12d,r12d
   5c748:	je     5c772 <sqlite3VdbeExec+0xd2d2>
   5c74a:	mov    r14,QWORD PTR [rsp+0xc8]
   5c752:	mov    QWORD PTR [rsp+0xe8],rbp
   5c75a:	mov    rbp,r12
   5c75d:	mov    r13,QWORD PTR [rsp+0xd0]
   5c765:	mov    rbx,QWORD PTR [rsp+0xf8]
   5c76d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c772:	mov    r14,QWORD PTR [rsp+0xc8]
   5c77a:	cmp    BYTE PTR [rbx+0x2],0x0
   5c77e:	jne    5cb8a <sqlite3VdbeExec+0xd6ea>
   5c784:	mov    QWORD PTR [rsp+0x128],0x0
   5c790:	mov    r12,QWORD PTR [rbx+0x28]
   5c794:	mov    QWORD PTR [rsp+0xb0],rdi
   5c79c:	mov    rdi,r12
   5c79f:	call   5c7a4 <sqlite3VdbeExec+0xd304>
   5c7a4:	mov    eax,DWORD PTR [r12+0x40]
   5c7a9:	mov    WORD PTR [rsp+0x1f4],0x0
   5c7b3:	mov    QWORD PTR [rsp+0x1f8],r14
   5c7bb:	mov    DWORD PTR [rsp+0x200],0x0
   5c7c6:	mov    QWORD PTR [rsp+0x130],rbx
   5c7ce:	lea    rbx,[rsp+0x1e0]
   5c7d6:	mov    rcx,rbx
   5c7d9:	mov    rdi,r12
   5c7dc:	mov    rsi,rax
   5c7df:	mov    rdx,rcx
   5c7e2:	call   5c7e7 <sqlite3VdbeExec+0xd347>
   5c7e7:	mov    r12d,eax
   5c7ea:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c7f2:	test   r12d,r12d
   5c7f5:	je     5c7ff <sqlite3VdbeExec+0xd35f>
   5c7f7:	mov    rbx,r12
   5c7fa:	jmp    5cad2 <sqlite3VdbeExec+0xd632>
   5c7ff:	mov    rax,QWORD PTR [rbx+0x8]
   5c803:	movzx  eax,BYTE PTR [rax]
   5c806:	lea    r12,[rsp+0x338]
   5c80e:	mov    DWORD PTR [r12],eax
   5c812:	cmp    DWORD PTR [r12],0x80
   5c81a:	jb     5c8b5 <sqlite3VdbeExec+0xd415>
   5c820:	mov    rax,QWORD PTR [rbx+0x8]
   5c824:	lea    rbx,[rsp+0x138]
   5c82c:	movzx  ecx,BYTE PTR [rax+0x1]
   5c830:	and    ecx,0x80
   5c836:	test   ecx,ecx
   5c838:	jne    5c84f <sqlite3VdbeExec+0xd3af>
   5c83a:	movzx  ecx,BYTE PTR [rax]
   5c83d:	and    ecx,0x7f
   5c840:	shl    ecx,0x7
   5c843:	movzx  eax,BYTE PTR [rax+0x1]
   5c847:	or     ecx,eax
   5c849:	mov    DWORD PTR [r12],ecx
   5c84d:	jmp    5c8b5 <sqlite3VdbeExec+0xd415>
   5c84f:	movzx  ecx,BYTE PTR [rax+0x2]
   5c853:	and    ecx,0x80
   5c859:	test   ecx,ecx
   5c85b:	jne    5c87e <sqlite3VdbeExec+0xd3de>
   5c85d:	movzx  ecx,BYTE PTR [rax]
   5c860:	and    ecx,0x7f
   5c863:	shl    ecx,0xe
   5c866:	movzx  edx,BYTE PTR [rax+0x1]
   5c86a:	and    edx,0x7f
   5c86d:	shl    edx,0x7
   5c870:	or     ecx,edx
   5c872:	movzx  eax,BYTE PTR [rax+0x2]
   5c876:	or     ecx,eax
   5c878:	mov    DWORD PTR [r12],ecx
   5c87c:	jmp    5c8b5 <sqlite3VdbeExec+0xd415>
   5c87e:	mov    rcx,rbx
   5c881:	mov    rdi,rax
   5c884:	mov    rsi,rcx
   5c887:	call   5c88c <sqlite3VdbeExec+0xd3ec>
   5c88c:	movzx  eax,al
   5c88f:	mov    eax,0xffffffff
   5c894:	and    rax,QWORD PTR [rbx]
   5c897:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c89f:	cmp    rax,QWORD PTR [rbx]
   5c8a2:	je     5c8ae <sqlite3VdbeExec+0xd40e>
   5c8a4:	mov    DWORD PTR [r12],0xffffffff
   5c8ac:	jmp    5c8b5 <sqlite3VdbeExec+0xd415>
   5c8ae:	mov    rax,QWORD PTR [rbx]
   5c8b1:	mov    DWORD PTR [r12],eax
   5c8b5:	cmp    DWORD PTR [r12],0x3
   5c8ba:	jae    5c8c9 <sqlite3VdbeExec+0xd429>
   5c8bc:	lea    rbx,[rsp+0x1e0]
   5c8c4:	jmp    5ca83 <sqlite3VdbeExec+0xd5e3>
   5c8c9:	mov    eax,DWORD PTR [r12]
   5c8cd:	lea    rbx,[rsp+0x1e0]
   5c8d5:	cmp    eax,DWORD PTR [rbx+0x10]
   5c8d8:	ja     5ca83 <sqlite3VdbeExec+0xd5e3>
   5c8de:	mov    rax,QWORD PTR [rbx+0x8]
   5c8e2:	mov    ecx,DWORD PTR [r12]
   5c8e6:	sub    ecx,0x1
   5c8e9:	movzx  eax,BYTE PTR [rax+rcx*1]
   5c8ed:	lea    r12,[rsp+0x33c]
   5c8f5:	mov    DWORD PTR [r12],eax
   5c8f9:	cmp    DWORD PTR [r12],0x80
   5c901:	jb     5c9b4 <sqlite3VdbeExec+0xd514>
   5c907:	mov    rax,QWORD PTR [rbx+0x8]
   5c90b:	lea    rbx,[rsp+0x338]
   5c913:	mov    ecx,DWORD PTR [rbx]
   5c915:	sub    ecx,0x1
   5c918:	lea    rdx,[rax+rcx*1]
   5c91c:	lea    rbx,[rsp+0x138]
   5c924:	movzx  eax,BYTE PTR [rax+rcx*1+0x1]
   5c929:	and    eax,0x80
   5c92e:	test   eax,eax
   5c930:	jne    5c947 <sqlite3VdbeExec+0xd4a7>
   5c932:	movzx  eax,BYTE PTR [rdx]
   5c935:	and    eax,0x7f
   5c938:	shl    eax,0x7
   5c93b:	movzx  ecx,BYTE PTR [rdx+0x1]
   5c93f:	or     eax,ecx
   5c941:	mov    DWORD PTR [r12],eax
   5c945:	jmp    5c9b4 <sqlite3VdbeExec+0xd514>
   5c947:	movzx  eax,BYTE PTR [rdx+0x2]
   5c94b:	and    eax,0x80
   5c950:	test   eax,eax
   5c952:	jne    5c975 <sqlite3VdbeExec+0xd4d5>
   5c954:	movzx  eax,BYTE PTR [rdx]
   5c957:	and    eax,0x7f
   5c95a:	shl    eax,0xe
   5c95d:	movzx  ecx,BYTE PTR [rdx+0x1]
   5c961:	and    ecx,0x7f
   5c964:	shl    ecx,0x7
   5c967:	or     eax,ecx
   5c969:	movzx  ecx,BYTE PTR [rdx+0x2]
   5c96d:	or     eax,ecx
   5c96f:	mov    DWORD PTR [r12],eax
   5c973:	jmp    5c9b4 <sqlite3VdbeExec+0xd514>
   5c975:	mov    rax,rbx
   5c978:	mov    QWORD PTR [rsp+0xb0],rdi
   5c980:	mov    rdi,rdx
   5c983:	mov    rsi,rax
   5c986:	call   5c98b <sqlite3VdbeExec+0xd4eb>
   5c98b:	movzx  eax,al
   5c98e:	mov    eax,0xffffffff
   5c993:	and    rax,QWORD PTR [rbx]
   5c996:	mov    rdi,QWORD PTR [rsp+0xb0]
   5c99e:	cmp    rax,QWORD PTR [rbx]
   5c9a1:	je     5c9ad <sqlite3VdbeExec+0xd50d>
   5c9a3:	mov    DWORD PTR [r12],0xffffffff
   5c9ab:	jmp    5c9b4 <sqlite3VdbeExec+0xd514>
   5c9ad:	mov    rax,QWORD PTR [rbx]
   5c9b0:	mov    DWORD PTR [r12],eax
   5c9b4:	cmp    DWORD PTR [r12],0x1
   5c9b9:	jae    5c9c8 <sqlite3VdbeExec+0xd528>
   5c9bb:	lea    rbx,[rsp+0x1e0]
   5c9c3:	jmp    5ca83 <sqlite3VdbeExec+0xd5e3>
   5c9c8:	cmp    DWORD PTR [r12],0x9
   5c9cd:	jbe    5c9dc <sqlite3VdbeExec+0xd53c>
   5c9cf:	lea    rbx,[rsp+0x1e0]
   5c9d7:	jmp    5ca83 <sqlite3VdbeExec+0xd5e3>
   5c9dc:	cmp    DWORD PTR [r12],0x7
   5c9e1:	jne    5c9f0 <sqlite3VdbeExec+0xd550>
   5c9e3:	lea    rbx,[rsp+0x1e0]
   5c9eb:	jmp    5ca83 <sqlite3VdbeExec+0xd5e3>
   5c9f0:	lea    rax,[rip+0x0]        # 5c9f7 <sqlite3VdbeExec+0xd557>
   5c9f7:	mov    ecx,DWORD PTR [r12]
   5c9fb:	movzx  eax,BYTE PTR [rax+rcx*1]
   5c9ff:	lea    rbx,[rsp+0x1e0]
   5ca07:	mov    ecx,DWORD PTR [rbx+0x10]
   5ca0a:	lea    r12,[rsp+0x338]
   5ca12:	mov    edx,eax
   5ca14:	add    edx,DWORD PTR [r12]
   5ca18:	cmp    ecx,edx
   5ca1a:	jb     5ca83 <sqlite3VdbeExec+0xd5e3>
   5ca1c:	mov    rcx,QWORD PTR [rbx+0x8]
   5ca20:	mov    edx,DWORD PTR [rbx+0x10]
   5ca23:	sub    edx,eax
   5ca25:	add    rcx,rdx
   5ca28:	lea    r12,[rsp+0x33c]
   5ca30:	mov    eax,DWORD PTR [r12]
   5ca34:	lea    r12,[rsp+0x218]
   5ca3c:	mov    rdx,r12
   5ca3f:	mov    QWORD PTR [rsp+0xb0],rdi
   5ca47:	mov    rdi,rcx
   5ca4a:	mov    rsi,rax
   5ca4d:	call   5ca52 <sqlite3VdbeExec+0xd5b2>
   5ca52:	mov    rax,QWORD PTR [r12]
   5ca56:	mov    QWORD PTR [rsp+0x128],rax
   5ca5e:	mov    rax,rbx
   5ca61:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ca69:	cmp    DWORD PTR [rbx+0x20],0x0
   5ca6d:	je     5ca7f <sqlite3VdbeExec+0xd5df>
   5ca6f:	mov    rdi,rax
   5ca72:	call   5ca77 <sqlite3VdbeExec+0xd5d7>
   5ca77:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ca7f:	xor    ebx,ebx
   5ca81:	jmp    5cad2 <sqlite3VdbeExec+0xd632>
   5ca83:	mov    rax,rbx
   5ca86:	cmp    DWORD PTR [rbx+0x20],0x0
   5ca8a:	je     5caa4 <sqlite3VdbeExec+0xd604>
   5ca8c:	mov    QWORD PTR [rsp+0xb0],rdi
   5ca94:	mov    rdi,rax
   5ca97:	call   5ca9c <sqlite3VdbeExec+0xd5fc>
   5ca9c:	mov    rdi,QWORD PTR [rsp+0xb0]
   5caa4:	mov    eax,0x16b4d
   5caa9:	mov    ecx,0xb
   5caae:	lea    rdx,[rip+0x0]        # 5cab5 <sqlite3VdbeExec+0xd615>
   5cab5:	mov    QWORD PTR [rsp+0xb0],rdi
   5cabd:	mov    rdi,rcx
   5cac0:	mov    rsi,rax
   5cac3:	call   5cac8 <sqlite3VdbeExec+0xd628>
   5cac8:	mov    ebx,eax
   5caca:	mov    rdi,QWORD PTR [rsp+0xb0]
   5cad2:	test   ebx,ebx
   5cad4:	je     5caf6 <sqlite3VdbeExec+0xd656>
   5cad6:	mov    QWORD PTR [rsp+0xe8],rbp
   5cade:	mov    rbp,rbx
   5cae1:	mov    r13,QWORD PTR [rsp+0xd0]
   5cae9:	mov    rbx,QWORD PTR [rsp+0xf8]
   5caf1:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5caf6:	cmp    BYTE PTR [rbp+0x0],0x8f
   5cafa:	jne    5cb39 <sqlite3VdbeExec+0xd699>
   5cafc:	mov    rax,QWORD PTR [rdi+0x78]
   5cb00:	movsxd rcx,DWORD PTR [rbp+0xc]
   5cb04:	mov    rax,QWORD PTR [rax+rcx*8]
   5cb08:	mov    BYTE PTR [rax+0x2],0x0
   5cb0c:	mov    rcx,QWORD PTR [rsp+0x128]
   5cb14:	mov    QWORD PTR [rax+0x48],rcx
   5cb18:	mov    BYTE PTR [rax+0x3],0x1
   5cb1c:	mov    DWORD PTR [rax+0x18],0x0
   5cb23:	mov    rcx,QWORD PTR [rbp+0x10]
   5cb27:	mov    QWORD PTR [rax+0x8],rcx
   5cb2b:	mov    r12,QWORD PTR [rsp+0x130]
   5cb33:	mov    QWORD PTR [rax+0x20],r12
   5cb37:	jmp    5cb85 <sqlite3VdbeExec+0xd6e5>
   5cb39:	mov    rax,QWORD PTR [rdi+0x68]
   5cb3d:	movsxd rcx,DWORD PTR [rbp+0x8]
   5cb41:	imul   rcx,rcx,0x38
   5cb45:	lea    rdx,[rax+rcx*1]
   5cb49:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5cb4e:	and    eax,0x9000
   5cb53:	test   eax,eax
   5cb55:	je     5cb74 <sqlite3VdbeExec+0xd6d4>
   5cb57:	mov    QWORD PTR [rsp+0xb0],rdi
   5cb5f:	mov    rdi,rdx
   5cb62:	call   5cb67 <sqlite3VdbeExec+0xd6c7>
   5cb67:	mov    rdi,QWORD PTR [rsp+0xb0]
   5cb6f:	mov    rdx,rax
   5cb72:	jmp    5cb7a <sqlite3VdbeExec+0xd6da>
   5cb74:	mov    WORD PTR [rdx+0x14],0x4
   5cb7a:	mov    rax,QWORD PTR [rsp+0x128]
   5cb82:	mov    QWORD PTR [rdx],rax
   5cb85:	mov    r12,rbx
   5cb88:	jmp    5cbc6 <sqlite3VdbeExec+0xd726>
   5cb8a:	movsxd rax,DWORD PTR [rbp+0x8]
   5cb8e:	imul   rax,rax,0x38
   5cb92:	lea    rcx,[r13+rax*1+0x0]
   5cb97:	movzx  eax,WORD PTR [r13+rax*1+0x14]
   5cb9d:	and    eax,0x9000
   5cba2:	test   eax,eax
   5cba4:	je     5cbc0 <sqlite3VdbeExec+0xd720>
   5cba6:	mov    QWORD PTR [rsp+0xb0],rdi
   5cbae:	mov    rdi,rcx
   5cbb1:	call   5cbb6 <sqlite3VdbeExec+0xd716>
   5cbb6:	mov    rdi,QWORD PTR [rsp+0xb0]
   5cbbe:	jmp    5cbc6 <sqlite3VdbeExec+0xd726>
   5cbc0:	mov    WORD PTR [rcx+0x14],0x1
   5cbc6:	mov    DWORD PTR [rsp+0x31c],r15d
   5cbce:	mov    DWORD PTR [rsp+0x32c],r12d
   5cbd6:	mov    rbx,r13
   5cbd9:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5cbde:	mov    r15d,DWORD PTR [rsp+0x31c]
   5cbe6:	mov    r13,QWORD PTR [rsp+0xf0]
   5cbee:	mov    QWORD PTR [rsp+0xd0],r12
   5cbf6:	mov    r12d,DWORD PTR [rsp+0x334]
   5cbfe:	mov    rax,QWORD PTR [rdi+0x78]
   5cc02:	movsxd rcx,DWORD PTR [rbp+0x4]
   5cc06:	mov    rax,QWORD PTR [rax+rcx*8]
   5cc0a:	cmp    BYTE PTR [rax+0x3],0x0
   5cc0e:	jne    5cc1a <sqlite3VdbeExec+0xd77a>
   5cc10:	mov    QWORD PTR [rsp+0xf0],r13
   5cc18:	jmp    5cc6c <sqlite3VdbeExec+0xd7cc>
   5cc1a:	mov    QWORD PTR [rsp+0xf0],r13
   5cc22:	mov    QWORD PTR [rsp+0xb0],rdi
   5cc2a:	mov    rdi,rax
   5cc2d:	call   5cc32 <sqlite3VdbeExec+0xd792>
   5cc32:	mov    r13d,eax
   5cc35:	mov    rdi,QWORD PTR [rsp+0xb0]
   5cc3d:	test   r13d,r13d
   5cc40:	jne    5cc4c <sqlite3VdbeExec+0xd7ac>
   5cc42:	mov    DWORD PTR [rsp+0x32c],r13d
   5cc4a:	jmp    5cc6c <sqlite3VdbeExec+0xd7cc>
   5cc4c:	mov    QWORD PTR [rsp+0xe8],rbp
   5cc54:	mov    rbp,r13
   5cc57:	mov    r13,QWORD PTR [rsp+0xd0]
   5cc5f:	mov    rbx,QWORD PTR [rsp+0xf8]
   5cc67:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5cc6c:	mov    DWORD PTR [rsp+0x31c],r15d
   5cc74:	mov    DWORD PTR [rsp+0x334],r12d
   5cc7c:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5cc81:	mov    r15d,DWORD PTR [rsp+0x31c]
   5cc89:	mov    QWORD PTR [rsp+0xd0],r12
   5cc91:	mov    r12d,DWORD PTR [rsp+0x334]
   5cc99:	mov    rax,QWORD PTR [rdi+0x78]
   5cc9d:	movsxd rcx,DWORD PTR [rbp+0x4]
   5cca1:	mov    rax,QWORD PTR [rax+rcx*8]
   5cca5:	mov    rcx,QWORD PTR [rax+0x30]
   5cca9:	mov    QWORD PTR [rsp+0x188],rcx
   5ccb1:	mov    ecx,DWORD PTR [rbp+0x10]
   5ccb4:	mov    WORD PTR [rsp+0x1a4],cx
   5ccbc:	cmp    BYTE PTR [rbp+0x0],0x2d
   5ccc0:	jae    5cccc <sqlite3VdbeExec+0xd82c>
   5ccc2:	mov    BYTE PTR [rsp+0x1a6],0xff
   5ccca:	jmp    5ccd4 <sqlite3VdbeExec+0xd834>
   5cccc:	mov    BYTE PTR [rsp+0x1a6],0x0
   5ccd4:	movsxd rcx,DWORD PTR [rbp+0xc]
   5ccd8:	imul   rcx,rcx,0x38
   5ccdc:	add    rcx,rbx
   5ccdf:	mov    QWORD PTR [rsp+0x190],rcx
   5cce7:	mov    r13,QWORD PTR [rax+0x28]
   5cceb:	mov    QWORD PTR [rsp+0xb0],rdi
   5ccf3:	mov    rdi,r13
   5ccf6:	call   5ccfb <sqlite3VdbeExec+0xd85b>
   5ccfb:	mov    eax,DWORD PTR [r13+0x40]
   5ccff:	mov    rdi,QWORD PTR [rsp+0xb0]
   5cd07:	test   rax,rax
   5cd0a:	jle    5cd14 <sqlite3VdbeExec+0xd874>
   5cd0c:	cmp    rax,0x7fffffff
   5cd12:	jle    5cd62 <sqlite3VdbeExec+0xd8c2>
   5cd14:	mov    eax,0x193b7
   5cd19:	mov    ecx,0xb
   5cd1e:	lea    rdx,[rip+0x0]        # 5cd25 <sqlite3VdbeExec+0xd885>
   5cd25:	mov    QWORD PTR [rsp+0xb0],rdi
   5cd2d:	mov    rdi,rcx
   5cd30:	mov    rsi,rax
   5cd33:	call   5cd38 <sqlite3VdbeExec+0xd898>
   5cd38:	mov    ebx,eax
   5cd3a:	mov    rdi,QWORD PTR [rsp+0xb0]
   5cd42:	mov    QWORD PTR [rsp+0xe8],rbp
   5cd4a:	mov    rbp,rbx
   5cd4d:	mov    r13,QWORD PTR [rsp+0xd0]
   5cd55:	mov    rbx,QWORD PTR [rsp+0xf8]
   5cd5d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5cd62:	mov    WORD PTR [rsp+0x22c],0x0
   5cd6c:	mov    QWORD PTR [rsp+0x230],r14
   5cd74:	mov    DWORD PTR [rsp+0x238],0x0
   5cd7f:	mov    QWORD PTR [rsp+0xc8],r14
   5cd87:	lea    r14,[rsp+0x218]
   5cd8f:	mov    rcx,r14
   5cd92:	mov    rdi,r13
   5cd95:	mov    rsi,rax
   5cd98:	mov    rdx,rcx
   5cd9b:	call   5cda0 <sqlite3VdbeExec+0xd900>
   5cda0:	mov    r13d,eax
   5cda3:	mov    rdi,QWORD PTR [rsp+0xb0]
   5cdab:	test   r13d,r13d
   5cdae:	je     5cdd8 <sqlite3VdbeExec+0xd938>
   5cdb0:	mov    r14,QWORD PTR [rsp+0xc8]
   5cdb8:	mov    QWORD PTR [rsp+0xe8],rbp
   5cdc0:	mov    rbp,r13
   5cdc3:	mov    r13,QWORD PTR [rsp+0xd0]
   5cdcb:	mov    rbx,QWORD PTR [rsp+0xf8]
   5cdd3:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5cdd8:	mov    eax,DWORD PTR [rsp+0x228]
   5cddf:	mov    rcx,QWORD PTR [rsp+0x220]
   5cde7:	mov    DWORD PTR [rsp+0x334],r12d
   5cdef:	lea    r12,[rsp+0x188]
   5cdf7:	mov    rdx,r12
   5cdfa:	xor    esi,esi
   5cdfc:	mov    rdi,rax
   5cdff:	mov    r11,rsi
   5ce02:	mov    rsi,rcx
   5ce05:	mov    rcx,r11
   5ce08:	call   5ce0d <sqlite3VdbeExec+0xd96d>
   5ce0d:	mov    rcx,r14
   5ce10:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ce18:	cmp    DWORD PTR [rsp+0x238],0x0
   5ce20:	je     5ce42 <sqlite3VdbeExec+0xd9a2>
   5ce22:	mov    QWORD PTR [rsp+0xa8],rax
   5ce2a:	mov    rdi,rcx
   5ce2d:	call   5ce32 <sqlite3VdbeExec+0xd992>
   5ce32:	mov    rax,QWORD PTR [rsp+0xa8]
   5ce3a:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ce42:	movzx  ecx,BYTE PTR [rbp+0x0]
   5ce46:	and    ecx,0x1
   5ce49:	cmp    ecx,0x1
   5ce4c:	jne    5ce73 <sqlite3VdbeExec+0xd9d3>
   5ce4e:	neg    eax
   5ce50:	test   eax,eax
   5ce52:	jg     5ce5e <sqlite3VdbeExec+0xd9be>
   5ce54:	mov    r12d,DWORD PTR [rsp+0x334]
   5ce5c:	jmp    5ce94 <sqlite3VdbeExec+0xd9f4>
   5ce5e:	mov    r12,QWORD PTR [rsp+0xc8]
   5ce66:	mov    DWORD PTR [rsp+0x32c],r13d
   5ce6e:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5ce73:	mov    r12d,DWORD PTR [rsp+0x334]
   5ce7b:	add    eax,0x1
   5ce7e:	test   eax,eax
   5ce80:	jle    5ce94 <sqlite3VdbeExec+0xd9f4>
   5ce82:	mov    DWORD PTR [rsp+0x334],r12d
   5ce8a:	lea    r12,[rsp+0x188]
   5ce92:	jmp    5ce5e <sqlite3VdbeExec+0xd9be>
   5ce94:	mov    r14,QWORD PTR [rsp+0xc8]
   5ce9c:	mov    DWORD PTR [rsp+0x31c],r15d
   5cea4:	mov    DWORD PTR [rsp+0x32c],r13d
   5ceac:	mov    DWORD PTR [rsp+0x334],r12d
   5ceb4:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5ceb9:	mov    QWORD PTR [rsp+0xc8],r14
   5cec1:	mov    r15d,DWORD PTR [rsp+0x31c]
   5cec9:	mov    QWORD PTR [rsp+0xd0],r12
   5ced1:	mov    r12d,DWORD PTR [rsp+0x334]
   5ced9:	lea    r14,[rsp+0x218]
   5cee1:	mov    rax,QWORD PTR [rdi+0x68]
   5cee5:	movsxd rcx,DWORD PTR [rbp+0x8]
   5cee9:	imul   rcx,rcx,0x38
   5ceed:	lea    r13,[rax+rcx*1]
   5cef1:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5cef6:	and    eax,0x9000
   5cefb:	test   eax,eax
   5cefd:	je     5cf1c <sqlite3VdbeExec+0xda7c>
   5ceff:	mov    QWORD PTR [rsp+0xb0],rdi
   5cf07:	mov    rdi,r13
   5cf0a:	call   5cf0f <sqlite3VdbeExec+0xda6f>
   5cf0f:	mov    r13,rax
   5cf12:	mov    rdi,QWORD PTR [rsp+0xb0]
   5cf1a:	jmp    5cf23 <sqlite3VdbeExec+0xda83>
   5cf1c:	mov    WORD PTR [r13+0x14],0x4
   5cf23:	mov    WORD PTR [r13+0x14],0x1
   5cf2a:	mov    r14,QWORD PTR [rsp+0xc8]
   5cf32:	mov    eax,DWORD PTR [r14+0xd4]
   5cf39:	mov    ecx,DWORD PTR [r14+0xe0]
   5cf40:	add    ecx,0x1
   5cf43:	cmp    eax,ecx
   5cf45:	jle    5cf73 <sqlite3VdbeExec+0xdad3>
   5cf47:	mov    ebx,0x6
   5cf4c:	mov    BYTE PTR [rdi+0xc4],0x2
   5cf53:	mov    QWORD PTR [rsp+0xe8],rbp
   5cf5b:	mov    rbp,rbx
   5cf5e:	mov    r13,QWORD PTR [rsp+0xd0]
   5cf66:	mov    rbx,QWORD PTR [rsp+0xf8]
   5cf6e:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5cf73:	mov    DWORD PTR [rsp+0x334],r12d
   5cf7b:	movsxd r12,DWORD PTR [rbp+0xc]
   5cf7f:	mov    DWORD PTR [rsp+0x33c],0x0
   5cf8a:	mov    rax,QWORD PTR [r14+0x20]
   5cf8e:	mov    rcx,r12
   5cf91:	shl    rcx,0x5
   5cf95:	mov    QWORD PTR [rsp+0x128],r13
   5cf9d:	mov    r13,QWORD PTR [rax+rcx*1+0x8]
   5cfa2:	mov    QWORD PTR [rsp+0x130],r12
   5cfaa:	mov    r12d,DWORD PTR [rbp+0x4]
   5cfae:	mov    rax,QWORD PTR [r13+0x8]
   5cfb2:	mov    rcx,QWORD PTR [r13+0x0]
   5cfb6:	mov    QWORD PTR [rax+0x8],rcx
   5cfba:	mov    QWORD PTR [rsp+0x108],0x0
   5cfc6:	mov    DWORD PTR [rsp+0x31c],r15d
   5cfce:	mov    r15,QWORD PTR [r13+0x8]
   5cfd2:	mov    eax,DWORD PTR [r15+0x40]
   5cfd6:	cmp    r12d,eax
   5cfd9:	jbe    5d014 <sqlite3VdbeExec+0xdb74>
   5cfdb:	mov    eax,0x1460e
   5cfe0:	mov    ecx,0xb
   5cfe5:	lea    rdx,[rip+0x0]        # 5cfec <sqlite3VdbeExec+0xdb4c>
   5cfec:	mov    QWORD PTR [rsp+0xb0],rdi
   5cff4:	mov    rdi,rcx
   5cff7:	mov    rsi,rax
   5cffa:	call   5cfff <sqlite3VdbeExec+0xdb5f>
   5cfff:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d007:	mov    r13,QWORD PTR [rsp+0x128]
   5d00f:	jmp    5d9e3 <sqlite3VdbeExec+0xe543>
   5d014:	mov    DWORD PTR [rsp+0x338],r12d
   5d01c:	mov    r12,QWORD PTR [r13+0x8]
   5d020:	mov    rax,QWORD PTR [r13+0x8]
   5d024:	mov    rcx,QWORD PTR [r13+0x0]
   5d028:	mov    QWORD PTR [rax+0x8],rcx
   5d02c:	xor    eax,eax
   5d02e:	mov    rcx,QWORD PTR [r12+0x10]
   5d033:	jmp    5d099 <sqlite3VdbeExec+0xdbf9>
   5d035:	test   rcx,rcx
   5d038:	jne    5d04c <sqlite3VdbeExec+0xdbac>
   5d03a:	mov    QWORD PTR [rsp+0x140],r12
   5d042:	mov    r12d,DWORD PTR [rsp+0x338]
   5d04a:	jmp    5d085 <sqlite3VdbeExec+0xdbe5>
   5d04c:	xor    edx,edx
   5d04e:	mov    QWORD PTR [rsp+0x140],r12
   5d056:	mov    r12d,DWORD PTR [rsp+0x338]
   5d05e:	cmp    edx,r12d
   5d061:	jne    5d06d <sqlite3VdbeExec+0xdbcd>
   5d063:	mov    r12,QWORD PTR [rsp+0x140]
   5d06b:	jmp    5d09e <sqlite3VdbeExec+0xdbfe>
   5d06d:	cmp    r12d,DWORD PTR [rcx+0x50]
   5d071:	jne    5d085 <sqlite3VdbeExec+0xdbe5>
   5d073:	mov    DWORD PTR [rsp+0x338],r12d
   5d07b:	mov    r12,QWORD PTR [rsp+0x140]
   5d083:	jmp    5d09e <sqlite3VdbeExec+0xdbfe>
   5d085:	mov    rcx,QWORD PTR [rcx+0x28]
   5d089:	mov    DWORD PTR [rsp+0x338],r12d
   5d091:	mov    r12,QWORD PTR [rsp+0x140]
   5d099:	test   rcx,rcx
   5d09c:	jne    5d035 <sqlite3VdbeExec+0xdb95>
   5d09e:	test   rcx,rcx
   5d0a1:	jne    5d0b5 <sqlite3VdbeExec+0xdc15>
   5d0a3:	mov    QWORD PTR [rsp+0x140],r12
   5d0ab:	mov    r12d,DWORD PTR [rsp+0x338]
   5d0b3:	jmp    5d0ed <sqlite3VdbeExec+0xdc4d>
   5d0b5:	mov    QWORD PTR [rsp+0x140],r12
   5d0bd:	mov    r12d,DWORD PTR [rsp+0x338]
   5d0c5:	mov    QWORD PTR [rsp+0xb0],rdi
   5d0cd:	mov    rdi,rcx
   5d0d0:	mov    rsi,r12
   5d0d3:	mov    rdx,rax
   5d0d6:	call   5d0db <sqlite3VdbeExec+0xdc3b>
   5d0db:	xor    ecx,ecx
   5d0dd:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d0e5:	cmp    ecx,eax
   5d0e7:	jne    5d173 <sqlite3VdbeExec+0xdcd3>
   5d0ed:	cmp    BYTE PTR [r13+0x13],0x0
   5d0f2:	je     5d125 <sqlite3VdbeExec+0xdc85>
   5d0f4:	mov    BYTE PTR [r13+0x13],0x0
   5d0f9:	mov    rax,QWORD PTR [r13+0x8]
   5d0fd:	mov    rax,QWORD PTR [rax+0x10]
   5d101:	jmp    5d120 <sqlite3VdbeExec+0xdc80>
   5d103:	movzx  ecx,BYTE PTR [rax+0x1]
   5d107:	and    ecx,0x10
   5d10a:	test   ecx,ecx
   5d10c:	je     5d11c <sqlite3VdbeExec+0xdc7c>
   5d10e:	mov    BYTE PTR [r13+0x13],0x1
   5d113:	cmp    r12d,DWORD PTR [rax+0x50]
   5d117:	jne    5d11c <sqlite3VdbeExec+0xdc7c>
   5d119:	mov    BYTE PTR [rax],0x1
   5d11c:	mov    rax,QWORD PTR [rax+0x28]
   5d120:	test   rax,rax
   5d123:	jne    5d103 <sqlite3VdbeExec+0xdc63>
   5d125:	xor    eax,eax
   5d127:	mov    QWORD PTR [rsp+0x138],r13
   5d12f:	mov    QWORD PTR [rsp+0x120],r15
   5d137:	xor    r15d,r15d
   5d13a:	mov    r13,QWORD PTR [rsp+0x140]
   5d142:	mov    QWORD PTR [rsp+0xb0],rdi
   5d14a:	mov    rdi,r13
   5d14d:	mov    rsi,r12
   5d150:	mov    rdx,rax
   5d153:	mov    rcx,r15
   5d156:	call   5d15b <sqlite3VdbeExec+0xdcbb>
   5d15b:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d163:	mov    r13,QWORD PTR [rsp+0x138]
   5d16b:	mov    r15,QWORD PTR [rsp+0x120]
   5d173:	mov    QWORD PTR [rsp+0x100],rbx
   5d17b:	lea    rbx,[rsp+0x348]
   5d183:	mov    DWORD PTR [rbx],eax
   5d185:	cmp    DWORD PTR [rbx],0x0
   5d188:	je     5d1a1 <sqlite3VdbeExec+0xdd01>
   5d18a:	mov    eax,DWORD PTR [rbx]
   5d18c:	mov    r13,QWORD PTR [rsp+0x128]
   5d194:	mov    rbx,QWORD PTR [rsp+0x100]
   5d19c:	jmp    5d9e3 <sqlite3VdbeExec+0xe543>
   5d1a1:	xor    eax,eax
   5d1a3:	lea    rbx,[rsp+0x140]
   5d1ab:	mov    rcx,QWORD PTR [r15]
   5d1ae:	mov    rdx,rbx
   5d1b1:	mov    rsi,QWORD PTR [rcx+0x110]
   5d1b8:	mov    QWORD PTR [rsp+0xb0],rdi
   5d1c0:	mov    rdi,rcx
   5d1c3:	mov    rcx,rax
   5d1c6:	mov    r10,rsi
   5d1c9:	mov    rsi,r12
   5d1cc:	call   r10
   5d1cf:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d1d7:	test   eax,eax
   5d1d9:	je     5d1dd <sqlite3VdbeExec+0xdd3d>
   5d1db:	jmp    5d21c <sqlite3VdbeExec+0xdd7c>
   5d1dd:	mov    rax,QWORD PTR [rbx]
   5d1e0:	mov    rcx,QWORD PTR [rax+0x10]
   5d1e4:	cmp    r12d,DWORD PTR [rcx+0x4]
   5d1e8:	je     5d20f <sqlite3VdbeExec+0xdd6f>
   5d1ea:	mov    rdx,QWORD PTR [rax+0x8]
   5d1ee:	mov    QWORD PTR [rcx+0x50],rdx
   5d1f2:	mov    QWORD PTR [rcx+0x70],rax
   5d1f6:	mov    QWORD PTR [rcx+0x48],r15
   5d1fa:	mov    DWORD PTR [rcx+0x4],r12d
   5d1fe:	mov    eax,0x64
   5d203:	xor    edx,edx
   5d205:	cmp    r12d,0x1
   5d209:	cmove  edx,eax
   5d20c:	mov    BYTE PTR [rcx+0x9],dl
   5d20f:	lea    rbx,[rsp+0x108]
   5d217:	mov    QWORD PTR [rbx],rcx
   5d21a:	xor    eax,eax
   5d21c:	lea    rbx,[rsp+0x348]
   5d224:	mov    DWORD PTR [rbx],eax
   5d226:	cmp    DWORD PTR [rbx],0x0
   5d229:	je     5d2e5 <sqlite3VdbeExec+0xde45>
   5d22f:	lea    r12,[rsp+0x108]
   5d237:	mov    rax,QWORD PTR [r12]
   5d23b:	test   rax,rax
   5d23e:	je     5d2ce <sqlite3VdbeExec+0xde2e>
   5d244:	mov    rax,QWORD PTR [rax+0x70]
   5d248:	movzx  ecx,WORD PTR [rax+0x34]
   5d24c:	and    ecx,0x20
   5d24f:	test   ecx,ecx
   5d251:	je     5d2b6 <sqlite3VdbeExec+0xde16>
   5d253:	mov    rcx,QWORD PTR [rax+0x28]
   5d257:	mov    edx,DWORD PTR [rcx+0x98]
   5d25d:	sub    edx,0x1
   5d260:	mov    DWORD PTR [rcx+0x98],edx
   5d266:	mov    rdx,QWORD PTR [rcx+0xa8]
   5d26d:	mov    QWORD PTR [rax+0x20],rdx
   5d271:	mov    QWORD PTR [rcx+0xa8],rax
   5d278:	mov    rdx,QWORD PTR [rcx+0x48]
   5d27c:	mov    esi,DWORD PTR [rax+0x30]
   5d27f:	sub    esi,0x1
   5d282:	imul   rsi,QWORD PTR [rcx+0xc8]
   5d28a:	mov    rax,QWORD PTR [rax+0x8]
   5d28e:	mov    rcx,QWORD PTR [rdx]
   5d291:	mov    rcx,QWORD PTR [rcx+0x90]
   5d298:	mov    QWORD PTR [rsp+0xb0],rdi
   5d2a0:	mov    rdi,rdx
   5d2a3:	mov    rdx,rax
   5d2a6:	mov    r10,rcx
   5d2a9:	call   r10
   5d2ac:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d2b4:	jmp    5d2ce <sqlite3VdbeExec+0xde2e>
   5d2b6:	mov    QWORD PTR [rsp+0xb0],rdi
   5d2be:	mov    rdi,rax
   5d2c1:	call   5d2c6 <sqlite3VdbeExec+0xde26>
   5d2c6:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d2ce:	mov    eax,DWORD PTR [rbx]
   5d2d0:	mov    r13,QWORD PTR [rsp+0x128]
   5d2d8:	mov    rbx,QWORD PTR [rsp+0x100]
   5d2e0:	jmp    5d9e3 <sqlite3VdbeExec+0xe543>
   5d2e5:	mov    DWORD PTR [rsp+0x33c],0x0
   5d2f0:	cmp    BYTE PTR [r15+0x21],0x0
   5d2f5:	je     5d8fd <sqlite3VdbeExec+0xe45d>
   5d2fb:	mov    rax,QWORD PTR [r13+0x8]
   5d2ff:	mov    rcx,QWORD PTR [r13+0x8]
   5d303:	mov    rdx,QWORD PTR [r13+0x0]
   5d307:	mov    QWORD PTR [rcx+0x8],rdx
   5d30b:	mov    rax,QWORD PTR [rax+0x18]
   5d30f:	mov    rax,QWORD PTR [rax+0x50]
   5d313:	movzx  ecx,BYTE PTR [rax+0x34]
   5d317:	shl    ecx,0x18
   5d31a:	movzx  edx,BYTE PTR [rax+0x35]
   5d31e:	shl    edx,0x10
   5d321:	or     ecx,edx
   5d323:	movzx  edx,BYTE PTR [rax+0x36]
   5d327:	shl    edx,0x8
   5d32a:	or     ecx,edx
   5d32c:	movzx  eax,BYTE PTR [rax+0x37]
   5d330:	or     ecx,eax
   5d332:	lea    rbx,[rsp+0x328]
   5d33a:	mov    DWORD PTR [rbx],ecx
   5d33c:	cmp    r12d,DWORD PTR [rbx]
   5d33f:	jne    5d44b <sqlite3VdbeExec+0xdfab>
   5d345:	lea    r12,[rsp+0x108]
   5d34d:	mov    rax,QWORD PTR [r12]
   5d351:	lea    rbx,[rsp+0x348]
   5d359:	cmp    DWORD PTR [rbx],0x0
   5d35c:	jne    5d382 <sqlite3VdbeExec+0xdee2>
   5d35e:	mov    rcx,QWORD PTR [rax+0x48]
   5d362:	mov    edx,DWORD PTR [rax+0x4]
   5d365:	mov    QWORD PTR [rsp+0xb0],rdi
   5d36d:	mov    rdi,rcx
   5d370:	mov    rsi,rax
   5d373:	call   5d378 <sqlite3VdbeExec+0xded8>
   5d378:	mov    DWORD PTR [rbx],eax
   5d37a:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d382:	mov    rax,QWORD PTR [r12]
   5d386:	test   rax,rax
   5d389:	je     5d419 <sqlite3VdbeExec+0xdf79>
   5d38f:	mov    rax,QWORD PTR [rax+0x70]
   5d393:	movzx  ecx,WORD PTR [rax+0x34]
   5d397:	and    ecx,0x20
   5d39a:	test   ecx,ecx
   5d39c:	je     5d401 <sqlite3VdbeExec+0xdf61>
   5d39e:	mov    rcx,QWORD PTR [rax+0x28]
   5d3a2:	mov    edx,DWORD PTR [rcx+0x98]
   5d3a8:	sub    edx,0x1
   5d3ab:	mov    DWORD PTR [rcx+0x98],edx
   5d3b1:	mov    rdx,QWORD PTR [rcx+0xa8]
   5d3b8:	mov    QWORD PTR [rax+0x20],rdx
   5d3bc:	mov    QWORD PTR [rcx+0xa8],rax
   5d3c3:	mov    rdx,QWORD PTR [rcx+0x48]
   5d3c7:	mov    esi,DWORD PTR [rax+0x30]
   5d3ca:	sub    esi,0x1
   5d3cd:	imul   rsi,QWORD PTR [rcx+0xc8]
   5d3d5:	mov    rax,QWORD PTR [rax+0x8]
   5d3d9:	mov    rcx,QWORD PTR [rdx]
   5d3dc:	mov    rcx,QWORD PTR [rcx+0x90]
   5d3e3:	mov    QWORD PTR [rsp+0xb0],rdi
   5d3eb:	mov    rdi,rdx
   5d3ee:	mov    rdx,rax
   5d3f1:	mov    r10,rcx
   5d3f4:	call   r10
   5d3f7:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d3ff:	jmp    5d419 <sqlite3VdbeExec+0xdf79>
   5d401:	mov    QWORD PTR [rsp+0xb0],rdi
   5d409:	mov    rdi,rax
   5d40c:	call   5d411 <sqlite3VdbeExec+0xdf71>
   5d411:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d419:	cmp    DWORD PTR [rbx],0x0
   5d41c:	jne    5d434 <sqlite3VdbeExec+0xdf94>
   5d41e:	mov    r11,rbp
   5d421:	mov    rbp,rbx
   5d424:	mov    rbx,r11
   5d427:	lea    r12,[rsp+0x328]
   5d42f:	jmp    5d82a <sqlite3VdbeExec+0xe38a>
   5d434:	mov    eax,DWORD PTR [rbx]
   5d436:	mov    r13,QWORD PTR [rsp+0x128]
   5d43e:	mov    rbx,QWORD PTR [rsp+0x100]
   5d446:	jmp    5d9e3 <sqlite3VdbeExec+0xe543>
   5d44b:	lea    rbx,[rsp+0x108]
   5d453:	mov    rax,QWORD PTR [rbx]
   5d456:	test   rax,rax
   5d459:	je     5d4e9 <sqlite3VdbeExec+0xe049>
   5d45f:	mov    rax,QWORD PTR [rax+0x70]
   5d463:	movzx  ecx,WORD PTR [rax+0x34]
   5d467:	and    ecx,0x20
   5d46a:	test   ecx,ecx
   5d46c:	je     5d4d1 <sqlite3VdbeExec+0xe031>
   5d46e:	mov    rcx,QWORD PTR [rax+0x28]
   5d472:	mov    edx,DWORD PTR [rcx+0x98]
   5d478:	sub    edx,0x1
   5d47b:	mov    DWORD PTR [rcx+0x98],edx
   5d481:	mov    rdx,QWORD PTR [rcx+0xa8]
   5d488:	mov    QWORD PTR [rax+0x20],rdx
   5d48c:	mov    QWORD PTR [rcx+0xa8],rax
   5d493:	mov    rdx,QWORD PTR [rcx+0x48]
   5d497:	mov    esi,DWORD PTR [rax+0x30]
   5d49a:	sub    esi,0x1
   5d49d:	imul   rsi,QWORD PTR [rcx+0xc8]
   5d4a5:	mov    rax,QWORD PTR [rax+0x8]
   5d4a9:	mov    rcx,QWORD PTR [rdx]
   5d4ac:	mov    rcx,QWORD PTR [rcx+0x90]
   5d4b3:	mov    QWORD PTR [rsp+0xb0],rdi
   5d4bb:	mov    rdi,rdx
   5d4be:	mov    rdx,rax
   5d4c1:	mov    r10,rcx
   5d4c4:	call   r10
   5d4c7:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d4cf:	jmp    5d4e9 <sqlite3VdbeExec+0xe049>
   5d4d1:	mov    QWORD PTR [rsp+0xb0],rdi
   5d4d9:	mov    rdi,rax
   5d4dc:	call   5d4e1 <sqlite3VdbeExec+0xe041>
   5d4e1:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d4e9:	lea    rbx,[rsp+0x328]
   5d4f1:	mov    ebx,DWORD PTR [rbx]
   5d4f3:	xor    eax,eax
   5d4f5:	mov    rcx,QWORD PTR [r15]
   5d4f8:	mov    DWORD PTR [rsp+0x338],r12d
   5d500:	lea    r12,[rsp+0x140]
   5d508:	mov    rdx,r12
   5d50b:	mov    rsi,QWORD PTR [rcx+0x110]
   5d512:	mov    QWORD PTR [rsp+0xb0],rdi
   5d51a:	mov    rdi,rcx
   5d51d:	mov    rcx,rax
   5d520:	mov    r10,rsi
   5d523:	mov    rsi,rbx
   5d526:	call   r10
   5d529:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d531:	test   eax,eax
   5d533:	je     5d537 <sqlite3VdbeExec+0xe097>
   5d535:	jmp    5d574 <sqlite3VdbeExec+0xe0d4>
   5d537:	mov    rax,QWORD PTR [r12]
   5d53b:	mov    rcx,QWORD PTR [rax+0x10]
   5d53f:	cmp    ebx,DWORD PTR [rcx+0x4]
   5d542:	je     5d567 <sqlite3VdbeExec+0xe0c7>
   5d544:	mov    rdx,QWORD PTR [rax+0x8]
   5d548:	mov    QWORD PTR [rcx+0x50],rdx
   5d54c:	mov    QWORD PTR [rcx+0x70],rax
   5d550:	mov    QWORD PTR [rcx+0x48],r15
   5d554:	mov    DWORD PTR [rcx+0x4],ebx
   5d557:	mov    eax,0x64
   5d55c:	xor    edx,edx
   5d55e:	cmp    ebx,0x1
   5d561:	cmove  edx,eax
   5d564:	mov    BYTE PTR [rcx+0x9],dl
   5d567:	lea    rbx,[rsp+0xe0]
   5d56f:	mov    QWORD PTR [rbx],rcx
   5d572:	xor    eax,eax
   5d574:	lea    rbx,[rsp+0x348]
   5d57c:	mov    DWORD PTR [rbx],eax
   5d57e:	cmp    DWORD PTR [rbx],0x0
   5d581:	je     5d59a <sqlite3VdbeExec+0xe0fa>
   5d583:	mov    eax,DWORD PTR [rbx]
   5d585:	mov    r13,QWORD PTR [rsp+0x128]
   5d58d:	mov    rbx,QWORD PTR [rsp+0x100]
   5d595:	jmp    5d9e3 <sqlite3VdbeExec+0xe543>
   5d59a:	mov    r12d,DWORD PTR [rsp+0x338]
   5d5a2:	mov    rbx,rbp
   5d5a5:	lea    rbp,[rsp+0xe0]
   5d5ad:	mov    rax,QWORD PTR [rbp+0x0]
   5d5b1:	xor    ecx,ecx
   5d5b3:	xor    edx,edx
   5d5b5:	mov    esi,0x1
   5d5ba:	mov    QWORD PTR [rsp+0xb0],rdi
   5d5c2:	mov    rdi,r15
   5d5c5:	mov    r8,r12
   5d5c8:	mov    r9,rdx
   5d5cb:	mov    rdx,rsi
   5d5ce:	mov    rsi,rax
   5d5d1:	call   5d5d6 <sqlite3VdbeExec+0xe136>
   5d5d6:	lea    r12,[rsp+0x348]
   5d5de:	mov    DWORD PTR [r12],eax
   5d5e2:	mov    rax,QWORD PTR [rbp+0x0]
   5d5e6:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d5ee:	test   rax,rax
   5d5f1:	je     5d66d <sqlite3VdbeExec+0xe1cd>
   5d5f3:	mov    rax,QWORD PTR [rax+0x70]
   5d5f7:	movzx  ecx,WORD PTR [rax+0x34]
   5d5fb:	and    ecx,0x20
   5d5fe:	test   ecx,ecx
   5d600:	je     5d65d <sqlite3VdbeExec+0xe1bd>
   5d602:	mov    rcx,QWORD PTR [rax+0x28]
   5d606:	mov    edx,DWORD PTR [rcx+0x98]
   5d60c:	sub    edx,0x1
   5d60f:	mov    DWORD PTR [rcx+0x98],edx
   5d615:	mov    rdx,QWORD PTR [rcx+0xa8]
   5d61c:	mov    QWORD PTR [rax+0x20],rdx
   5d620:	mov    QWORD PTR [rcx+0xa8],rax
   5d627:	mov    rdx,QWORD PTR [rcx+0x48]
   5d62b:	mov    esi,DWORD PTR [rax+0x30]
   5d62e:	sub    esi,0x1
   5d631:	imul   rsi,QWORD PTR [rcx+0xc8]
   5d639:	mov    rax,QWORD PTR [rax+0x8]
   5d63d:	mov    rcx,QWORD PTR [rdx]
   5d640:	mov    rcx,QWORD PTR [rcx+0x90]
   5d647:	mov    rdi,rdx
   5d64a:	mov    rdx,rax
   5d64d:	mov    r10,rcx
   5d650:	call   r10
   5d653:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d65b:	jmp    5d66d <sqlite3VdbeExec+0xe1cd>
   5d65d:	mov    rdi,rax
   5d660:	call   5d665 <sqlite3VdbeExec+0xe1c5>
   5d665:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d66d:	cmp    DWORD PTR [r12],0x0
   5d672:	je     5d690 <sqlite3VdbeExec+0xe1f0>
   5d674:	mov    eax,DWORD PTR [r12]
   5d678:	mov    r13,QWORD PTR [rsp+0x128]
   5d680:	mov    rbp,rbx
   5d683:	mov    rbx,QWORD PTR [rsp+0x100]
   5d68b:	jmp    5d9e3 <sqlite3VdbeExec+0xe543>
   5d690:	mov    QWORD PTR [rbp+0x0],0x0
   5d698:	lea    rbp,[rsp+0x328]
   5d6a0:	mov    ebp,DWORD PTR [rbp+0x0]
   5d6a3:	xor    eax,eax
   5d6a5:	lea    r12,[rsp+0x140]
   5d6ad:	mov    rcx,QWORD PTR [r15]
   5d6b0:	mov    rdx,r12
   5d6b3:	mov    rsi,QWORD PTR [rcx+0x110]
   5d6ba:	mov    QWORD PTR [rsp+0xb0],rdi
   5d6c2:	mov    rdi,rcx
   5d6c5:	mov    rcx,rax
   5d6c8:	mov    r10,rsi
   5d6cb:	mov    rsi,rbp
   5d6ce:	call   r10
   5d6d1:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d6d9:	test   eax,eax
   5d6db:	je     5d6df <sqlite3VdbeExec+0xe23f>
   5d6dd:	jmp    5d71d <sqlite3VdbeExec+0xe27d>
   5d6df:	mov    rax,QWORD PTR [r12]
   5d6e3:	mov    rcx,QWORD PTR [rax+0x10]
   5d6e7:	cmp    ebp,DWORD PTR [rcx+0x4]
   5d6ea:	je     5d70f <sqlite3VdbeExec+0xe26f>
   5d6ec:	mov    rdx,QWORD PTR [rax+0x8]
   5d6f0:	mov    QWORD PTR [rcx+0x50],rdx
   5d6f4:	mov    QWORD PTR [rcx+0x70],rax
   5d6f8:	mov    QWORD PTR [rcx+0x48],r15
   5d6fc:	mov    DWORD PTR [rcx+0x4],ebp
   5d6ff:	mov    eax,0x64
   5d704:	xor    edx,edx
   5d706:	cmp    ebp,0x1
   5d709:	cmove  edx,eax
   5d70c:	mov    BYTE PTR [rcx+0x9],dl
   5d70f:	lea    rbp,[rsp+0xe0]
   5d717:	mov    QWORD PTR [rbp+0x0],rcx
   5d71b:	xor    eax,eax
   5d71d:	lea    rbp,[rsp+0x348]
   5d725:	mov    DWORD PTR [rbp+0x0],eax
   5d728:	lea    r12,[rsp+0xe0]
   5d730:	mov    rax,QWORD PTR [r12]
   5d734:	cmp    DWORD PTR [rbp+0x0],0x0
   5d738:	jne    5d75f <sqlite3VdbeExec+0xe2bf>
   5d73a:	mov    rcx,QWORD PTR [rax+0x48]
   5d73e:	mov    edx,DWORD PTR [rax+0x4]
   5d741:	mov    QWORD PTR [rsp+0xb0],rdi
   5d749:	mov    rdi,rcx
   5d74c:	mov    rsi,rax
   5d74f:	call   5d754 <sqlite3VdbeExec+0xe2b4>
   5d754:	mov    DWORD PTR [rbp+0x0],eax
   5d757:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d75f:	mov    rax,QWORD PTR [r12]
   5d763:	test   rax,rax
   5d766:	je     5d7f6 <sqlite3VdbeExec+0xe356>
   5d76c:	mov    rax,QWORD PTR [rax+0x70]
   5d770:	movzx  ecx,WORD PTR [rax+0x34]
   5d774:	and    ecx,0x20
   5d777:	test   ecx,ecx
   5d779:	je     5d7de <sqlite3VdbeExec+0xe33e>
   5d77b:	mov    rcx,QWORD PTR [rax+0x28]
   5d77f:	mov    edx,DWORD PTR [rcx+0x98]
   5d785:	sub    edx,0x1
   5d788:	mov    DWORD PTR [rcx+0x98],edx
   5d78e:	mov    rdx,QWORD PTR [rcx+0xa8]
   5d795:	mov    QWORD PTR [rax+0x20],rdx
   5d799:	mov    QWORD PTR [rcx+0xa8],rax
   5d7a0:	mov    rdx,QWORD PTR [rcx+0x48]
   5d7a4:	mov    esi,DWORD PTR [rax+0x30]
   5d7a7:	sub    esi,0x1
   5d7aa:	imul   rsi,QWORD PTR [rcx+0xc8]
   5d7b2:	mov    rax,QWORD PTR [rax+0x8]
   5d7b6:	mov    rcx,QWORD PTR [rdx]
   5d7b9:	mov    rcx,QWORD PTR [rcx+0x90]
   5d7c0:	mov    QWORD PTR [rsp+0xb0],rdi
   5d7c8:	mov    rdi,rdx
   5d7cb:	mov    rdx,rax
   5d7ce:	mov    r10,rcx
   5d7d1:	call   r10
   5d7d4:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d7dc:	jmp    5d7f6 <sqlite3VdbeExec+0xe356>
   5d7de:	mov    QWORD PTR [rsp+0xb0],rdi
   5d7e6:	mov    rdi,rax
   5d7e9:	call   5d7ee <sqlite3VdbeExec+0xe34e>
   5d7ee:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d7f6:	cmp    DWORD PTR [rbp+0x0],0x0
   5d7fa:	je     5d817 <sqlite3VdbeExec+0xe377>
   5d7fc:	mov    eax,DWORD PTR [rbp+0x0]
   5d7ff:	mov    r13,QWORD PTR [rsp+0x128]
   5d807:	mov    rbp,rbx
   5d80a:	mov    rbx,QWORD PTR [rsp+0x100]
   5d812:	jmp    5d9e3 <sqlite3VdbeExec+0xe543>
   5d817:	lea    r12,[rsp+0x328]
   5d81f:	mov    eax,DWORD PTR [r12]
   5d823:	mov    DWORD PTR [rsp+0x33c],eax
   5d82a:	mov    eax,DWORD PTR [r12]
   5d82e:	sub    eax,0x1
   5d831:	mov    DWORD PTR [r12],eax
   5d835:	jmp    5d89b <sqlite3VdbeExec+0xe3fb>
   5d837:	mov    eax,DWORD PTR [r15+0x38]
   5d83b:	mov    edx,0xcccccccd
   5d840:	mul    edx
   5d842:	shr    edx,0x2
   5d845:	mov    eax,edx
   5d847:	lea    esi,[rax+0x1]
   5d84a:	sub    ecx,0x2
   5d84d:	mov    rax,rcx
   5d850:	xor    edx,edx
   5d852:	div    esi
   5d854:	imul   eax,esi
   5d857:	lea    ecx,[rax+0x2]
   5d85a:	mov    eax,DWORD PTR [rip+0x0]        # 5d860 <sqlite3VdbeExec+0xe3c0>
   5d860:	mov    esi,DWORD PTR [r15+0x34]
   5d864:	xor    edx,edx
   5d866:	div    esi
   5d868:	add    eax,0x1
   5d86b:	xor    edx,edx
   5d86d:	mov    esi,0x1
   5d872:	cmp    ecx,eax
   5d874:	cmove  edx,esi
   5d877:	lea    eax,[rcx+rdx*1]
   5d87a:	lea    rbp,[rsp+0x348]
   5d882:	lea    r12,[rsp+0x328]
   5d88a:	cmp    eax,DWORD PTR [r12]
   5d88e:	jne    5d8c5 <sqlite3VdbeExec+0xe425>
   5d890:	mov    eax,DWORD PTR [r12]
   5d894:	sub    eax,0x1
   5d897:	mov    DWORD PTR [r12],eax
   5d89b:	mov    ecx,DWORD PTR [r12]
   5d89f:	mov    eax,DWORD PTR [rip+0x0]        # 5d8a5 <sqlite3VdbeExec+0xe405>
   5d8a5:	mov    esi,DWORD PTR [r15+0x34]
   5d8a9:	xor    edx,edx
   5d8ab:	div    esi
   5d8ad:	add    eax,0x1
   5d8b0:	cmp    ecx,eax
   5d8b2:	je     5d890 <sqlite3VdbeExec+0xe3f0>
   5d8b4:	mov    ecx,DWORD PTR [r12]
   5d8b8:	cmp    ecx,0x2
   5d8bb:	jae    5d837 <sqlite3VdbeExec+0xe397>
   5d8c1:	xor    eax,eax
   5d8c3:	jmp    5d88a <sqlite3VdbeExec+0xe3ea>
   5d8c5:	mov    eax,0x4
   5d8ca:	mov    ecx,DWORD PTR [r12]
   5d8ce:	mov    QWORD PTR [rsp+0xb0],rdi
   5d8d6:	mov    rdi,r13
   5d8d9:	mov    rsi,rax
   5d8dc:	mov    rdx,rcx
   5d8df:	call   5d8e4 <sqlite3VdbeExec+0xe444>
   5d8e4:	mov    DWORD PTR [rbp+0x0],eax
   5d8e7:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d8ef:	mov    r11,rbx
   5d8f2:	mov    rbx,rbp
   5d8f5:	mov    rbp,r11
   5d8f8:	jmp    5d9d1 <sqlite3VdbeExec+0xe531>
   5d8fd:	lea    rbx,[rsp+0x348]
   5d905:	lea    r12,[rsp+0x108]
   5d90d:	mov    rax,QWORD PTR [r12]
   5d911:	cmp    DWORD PTR [rbx],0x0
   5d914:	jne    5d93a <sqlite3VdbeExec+0xe49a>
   5d916:	mov    rcx,QWORD PTR [rax+0x48]
   5d91a:	mov    edx,DWORD PTR [rax+0x4]
   5d91d:	mov    QWORD PTR [rsp+0xb0],rdi
   5d925:	mov    rdi,rcx
   5d928:	mov    rsi,rax
   5d92b:	call   5d930 <sqlite3VdbeExec+0xe490>
   5d930:	mov    DWORD PTR [rbx],eax
   5d932:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d93a:	mov    rax,QWORD PTR [r12]
   5d93e:	test   rax,rax
   5d941:	je     5d9d1 <sqlite3VdbeExec+0xe531>
   5d947:	mov    rax,QWORD PTR [rax+0x70]
   5d94b:	movzx  ecx,WORD PTR [rax+0x34]
   5d94f:	and    ecx,0x20
   5d952:	test   ecx,ecx
   5d954:	je     5d9b9 <sqlite3VdbeExec+0xe519>
   5d956:	mov    rcx,QWORD PTR [rax+0x28]
   5d95a:	mov    edx,DWORD PTR [rcx+0x98]
   5d960:	sub    edx,0x1
   5d963:	mov    DWORD PTR [rcx+0x98],edx
   5d969:	mov    rdx,QWORD PTR [rcx+0xa8]
   5d970:	mov    QWORD PTR [rax+0x20],rdx
   5d974:	mov    QWORD PTR [rcx+0xa8],rax
   5d97b:	mov    rdx,QWORD PTR [rcx+0x48]
   5d97f:	mov    esi,DWORD PTR [rax+0x30]
   5d982:	sub    esi,0x1
   5d985:	imul   rsi,QWORD PTR [rcx+0xc8]
   5d98d:	mov    rax,QWORD PTR [rax+0x8]
   5d991:	mov    rcx,QWORD PTR [rdx]
   5d994:	mov    rcx,QWORD PTR [rcx+0x90]
   5d99b:	mov    QWORD PTR [rsp+0xb0],rdi
   5d9a3:	mov    rdi,rdx
   5d9a6:	mov    rdx,rax
   5d9a9:	mov    r10,rcx
   5d9ac:	call   r10
   5d9af:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d9b7:	jmp    5d9d1 <sqlite3VdbeExec+0xe531>
   5d9b9:	mov    QWORD PTR [rsp+0xb0],rdi
   5d9c1:	mov    rdi,rax
   5d9c4:	call   5d9c9 <sqlite3VdbeExec+0xe529>
   5d9c9:	mov    rdi,QWORD PTR [rsp+0xb0]
   5d9d1:	mov    eax,DWORD PTR [rbx]
   5d9d3:	mov    r13,QWORD PTR [rsp+0x128]
   5d9db:	mov    rbx,QWORD PTR [rsp+0x100]
   5d9e3:	mov    r12d,eax
   5d9e6:	mov    WORD PTR [r13+0x14],0x4
   5d9ed:	movsxd rax,DWORD PTR [rsp+0x33c]
   5d9f5:	mov    QWORD PTR [r13+0x0],rax
   5d9f9:	test   r12d,r12d
   5d9fc:	je     5da1e <sqlite3VdbeExec+0xe57e>
   5d9fe:	mov    QWORD PTR [rsp+0xe8],rbp
   5da06:	mov    rbp,r12
   5da09:	mov    r13,QWORD PTR [rsp+0xd0]
   5da11:	mov    rbx,QWORD PTR [rsp+0xf8]
   5da19:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5da1e:	cmp    DWORD PTR [rsp+0x33c],0x0
   5da26:	je     5da95 <sqlite3VdbeExec+0xe5f5>
   5da28:	mov    eax,DWORD PTR [rsp+0x33c]
   5da2f:	mov    ecx,DWORD PTR [rbp+0x4]
   5da32:	mov    rdx,QWORD PTR [r14+0x20]
   5da36:	mov    r13,QWORD PTR [rsp+0x130]
   5da3e:	mov    rsi,r13
   5da41:	shl    rsi,0x5
   5da45:	mov    r8,QWORD PTR [rdx+rsi*1+0x18]
   5da4a:	mov    r8,QWORD PTR [r8+0x10]
   5da4e:	jmp    5da61 <sqlite3VdbeExec+0xe5c1>
   5da50:	mov    r9,QWORD PTR [r8+0x10]
   5da54:	cmp    eax,DWORD PTR [r9+0x28]
   5da58:	jne    5da5e <sqlite3VdbeExec+0xe5be>
   5da5a:	mov    DWORD PTR [r9+0x28],ecx
   5da5e:	mov    r8,QWORD PTR [r8]
   5da61:	test   r8,r8
   5da64:	jne    5da50 <sqlite3VdbeExec+0xe5b0>
   5da66:	mov    rdx,QWORD PTR [rdx+rsi*1+0x18]
   5da6b:	mov    rdx,QWORD PTR [rdx+0x28]
   5da6f:	jmp    5da80 <sqlite3VdbeExec+0xe5e0>
   5da71:	mov    rsi,QWORD PTR [rdx+0x10]
   5da75:	cmp    eax,DWORD PTR [rsi+0x58]
   5da78:	jne    5da7d <sqlite3VdbeExec+0xe5dd>
   5da7a:	mov    DWORD PTR [rsi+0x58],ecx
   5da7d:	mov    rdx,QWORD PTR [rdx]
   5da80:	test   rdx,rdx
   5da83:	jne    5da71 <sqlite3VdbeExec+0xe5d1>
   5da85:	lea    eax,[r13+0x1]
   5da89:	movzx  r13d,al
   5da8d:	mov    DWORD PTR [rsp+0x320],r13d
   5da95:	mov    DWORD PTR [rsp+0x32c],r12d
   5da9d:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5daa2:	mov    r15d,DWORD PTR [rsp+0x31c]
   5daaa:	mov    r13,QWORD PTR [rsp+0xf0]
   5dab2:	mov    QWORD PTR [rsp+0xd0],r12
   5daba:	mov    r12d,DWORD PTR [rsp+0x334]
   5dac2:	mov    QWORD PTR [rsp+0x130],0x0
   5dace:	mov    rax,QWORD PTR [r14+0x20]
   5dad2:	movsxd rcx,DWORD PTR [rbp+0x8]
   5dad6:	shl    rcx,0x5
   5dada:	mov    DWORD PTR [rsp+0x334],r12d
   5dae2:	mov    r12,QWORD PTR [rax+rcx*1+0x8]
   5dae7:	mov    QWORD PTR [rsp+0xf0],r13
   5daef:	mov    r13d,DWORD PTR [rbp+0x4]
   5daf3:	mov    DWORD PTR [rsp+0x33c],r13d
   5dafb:	lea    r13,[rsp+0x130]
   5db03:	mov    r13,QWORD PTR [r12+0x8]
   5db08:	mov    rax,QWORD PTR [r12+0x8]
   5db0d:	mov    rcx,QWORD PTR [r12]
   5db11:	mov    QWORD PTR [rax+0x8],rcx
   5db15:	xor    eax,eax
   5db17:	mov    rcx,QWORD PTR [r13+0x10]
   5db1b:	jmp    5db81 <sqlite3VdbeExec+0xe6e1>
   5db1d:	test   rcx,rcx
   5db20:	jne    5db34 <sqlite3VdbeExec+0xe694>
   5db22:	mov    QWORD PTR [rsp+0x128],r13
   5db2a:	mov    r13d,DWORD PTR [rsp+0x33c]
   5db32:	jmp    5db6d <sqlite3VdbeExec+0xe6cd>
   5db34:	xor    edx,edx
   5db36:	mov    QWORD PTR [rsp+0x128],r13
   5db3e:	mov    r13d,DWORD PTR [rsp+0x33c]
   5db46:	cmp    edx,r13d
   5db49:	jne    5db55 <sqlite3VdbeExec+0xe6b5>
   5db4b:	mov    r13,QWORD PTR [rsp+0x128]
   5db53:	jmp    5db86 <sqlite3VdbeExec+0xe6e6>
   5db55:	cmp    r13d,DWORD PTR [rcx+0x50]
   5db59:	jne    5db6d <sqlite3VdbeExec+0xe6cd>
   5db5b:	mov    DWORD PTR [rsp+0x33c],r13d
   5db63:	mov    r13,QWORD PTR [rsp+0x128]
   5db6b:	jmp    5db86 <sqlite3VdbeExec+0xe6e6>
   5db6d:	mov    rcx,QWORD PTR [rcx+0x28]
   5db71:	mov    DWORD PTR [rsp+0x33c],r13d
   5db79:	mov    r13,QWORD PTR [rsp+0x128]
   5db81:	test   rcx,rcx
   5db84:	jne    5db1d <sqlite3VdbeExec+0xe67d>
   5db86:	test   rcx,rcx
   5db89:	jne    5db9d <sqlite3VdbeExec+0xe6fd>
   5db8b:	mov    QWORD PTR [rsp+0x128],r13
   5db93:	mov    r13d,DWORD PTR [rsp+0x33c]
   5db9b:	jmp    5dbd1 <sqlite3VdbeExec+0xe731>
   5db9d:	mov    QWORD PTR [rsp+0x128],r13
   5dba5:	mov    r13d,DWORD PTR [rsp+0x33c]
   5dbad:	mov    QWORD PTR [rsp+0xb0],rdi
   5dbb5:	mov    rdi,rcx
   5dbb8:	mov    rsi,r13
   5dbbb:	mov    rdx,rax
   5dbbe:	call   5dbc3 <sqlite3VdbeExec+0xe723>
   5dbc3:	xor    ecx,ecx
   5dbc5:	mov    rdi,QWORD PTR [rsp+0xb0]
   5dbcd:	cmp    ecx,eax
   5dbcf:	jne    5dc50 <sqlite3VdbeExec+0xe7b0>
   5dbd1:	cmp    BYTE PTR [r12+0x13],0x0
   5dbd7:	je     5dc0d <sqlite3VdbeExec+0xe76d>
   5dbd9:	mov    BYTE PTR [r12+0x13],0x0
   5dbdf:	mov    rax,QWORD PTR [r12+0x8]
   5dbe4:	mov    rax,QWORD PTR [rax+0x10]
   5dbe8:	jmp    5dc08 <sqlite3VdbeExec+0xe768>
   5dbea:	movzx  ecx,BYTE PTR [rax+0x1]
   5dbee:	and    ecx,0x10
   5dbf1:	test   ecx,ecx
   5dbf3:	je     5dc04 <sqlite3VdbeExec+0xe764>
   5dbf5:	mov    BYTE PTR [r12+0x13],0x1
   5dbfb:	cmp    r13d,DWORD PTR [rax+0x50]
   5dbff:	jne    5dc04 <sqlite3VdbeExec+0xe764>
   5dc01:	mov    BYTE PTR [rax],0x1
   5dc04:	mov    rax,QWORD PTR [rax+0x28]
   5dc08:	test   rax,rax
   5dc0b:	jne    5dbea <sqlite3VdbeExec+0xe74a>
   5dc0d:	xor    eax,eax
   5dc0f:	mov    DWORD PTR [rsp+0x31c],r15d
   5dc17:	lea    r12,[rsp+0x130]
   5dc1f:	mov    r15,QWORD PTR [rsp+0x128]
   5dc27:	mov    QWORD PTR [rsp+0xb0],rdi
   5dc2f:	mov    rdi,r15
   5dc32:	mov    rsi,r13
   5dc35:	mov    rdx,rax
   5dc38:	mov    rcx,r12
   5dc3b:	call   5dc40 <sqlite3VdbeExec+0xe7a0>
   5dc40:	mov    rdi,QWORD PTR [rsp+0xb0]
   5dc48:	mov    r15d,DWORD PTR [rsp+0x31c]
   5dc50:	mov    r12d,eax
   5dc53:	cmp    DWORD PTR [rbp+0xc],0x0
   5dc57:	je     5dc87 <sqlite3VdbeExec+0xe7e7>
   5dc59:	mov    rax,QWORD PTR [rdi+0x38]
   5dc5d:	add    rax,QWORD PTR [rsp+0x130]
   5dc65:	mov    QWORD PTR [rdi+0x38],rax
   5dc69:	cmp    DWORD PTR [rbp+0xc],0x0
   5dc6d:	jle    5dc87 <sqlite3VdbeExec+0xe7e7>
   5dc6f:	movsxd rax,DWORD PTR [rbp+0xc]
   5dc73:	imul   rax,rax,0x38
   5dc77:	mov    rcx,QWORD PTR [rbx+rax*1]
   5dc7b:	add    rcx,QWORD PTR [rsp+0x130]
   5dc83:	mov    QWORD PTR [rbx+rax*1],rcx
   5dc87:	test   r12d,r12d
   5dc8a:	je     5dcac <sqlite3VdbeExec+0xe80c>
   5dc8c:	mov    QWORD PTR [rsp+0xe8],rbp
   5dc94:	mov    rbp,r12
   5dc97:	mov    r13,QWORD PTR [rsp+0xd0]
   5dc9f:	mov    rbx,QWORD PTR [rsp+0xf8]
   5dca7:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5dcac:	mov    DWORD PTR [rsp+0x31c],r15d
   5dcb4:	mov    DWORD PTR [rsp+0x32c],r12d
   5dcbc:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5dcc1:	mov    r15d,DWORD PTR [rsp+0x31c]
   5dcc9:	mov    r13,QWORD PTR [rsp+0xf0]
   5dcd1:	mov    QWORD PTR [rsp+0xd0],r12
   5dcd9:	mov    r12d,DWORD PTR [rsp+0x334]
   5dce1:	mov    rax,QWORD PTR [rdi+0x78]
   5dce5:	movsxd rcx,DWORD PTR [rbp+0x4]
   5dce9:	mov    rax,QWORD PTR [rax+rcx*8]
   5dced:	cmp    BYTE PTR [rax],0x1
   5dcf0:	jne    5dd2e <sqlite3VdbeExec+0xe88e>
   5dcf2:	mov    rax,QWORD PTR [rax+0x28]
   5dcf6:	mov    QWORD PTR [rsp+0xb0],rdi
   5dcfe:	mov    rdi,r14
   5dd01:	mov    rsi,rax
   5dd04:	call   5dd09 <sqlite3VdbeExec+0xe869>
   5dd09:	mov    rdi,QWORD PTR [rsp+0xb0]
   5dd11:	mov    DWORD PTR [rsp+0x31c],r15d
   5dd19:	mov    QWORD PTR [rsp+0xf0],r13
   5dd21:	mov    DWORD PTR [rsp+0x334],r12d
   5dd29:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5dd2e:	mov    rax,QWORD PTR [rax+0x28]
   5dd32:	mov    DWORD PTR [rsp+0x334],r12d
   5dd3a:	mov    r12,QWORD PTR [rax+0x8]
   5dd3e:	mov    QWORD PTR [rsp+0xf0],r13
   5dd46:	mov    r13d,DWORD PTR [rax+0x50]
   5dd4a:	mov    DWORD PTR [rsp+0x33c],r13d
   5dd52:	mov    r13,QWORD PTR [r12+0x8]
   5dd57:	mov    rax,QWORD PTR [r12+0x8]
   5dd5c:	mov    rcx,QWORD PTR [r12]
   5dd60:	mov    QWORD PTR [rax+0x8],rcx
   5dd64:	xor    eax,eax
   5dd66:	mov    rcx,QWORD PTR [r13+0x10]
   5dd6a:	jmp    5ddd0 <sqlite3VdbeExec+0xe930>
   5dd6c:	test   rcx,rcx
   5dd6f:	jne    5dd83 <sqlite3VdbeExec+0xe8e3>
   5dd71:	mov    QWORD PTR [rsp+0x130],r13
   5dd79:	mov    r13d,DWORD PTR [rsp+0x33c]
   5dd81:	jmp    5ddbc <sqlite3VdbeExec+0xe91c>
   5dd83:	xor    edx,edx
   5dd85:	mov    QWORD PTR [rsp+0x130],r13
   5dd8d:	mov    r13d,DWORD PTR [rsp+0x33c]
   5dd95:	cmp    edx,r13d
   5dd98:	jne    5dda4 <sqlite3VdbeExec+0xe904>
   5dd9a:	mov    r13,QWORD PTR [rsp+0x130]
   5dda2:	jmp    5ddd5 <sqlite3VdbeExec+0xe935>
   5dda4:	cmp    r13d,DWORD PTR [rcx+0x50]
   5dda8:	jne    5ddbc <sqlite3VdbeExec+0xe91c>
   5ddaa:	mov    DWORD PTR [rsp+0x33c],r13d
   5ddb2:	mov    r13,QWORD PTR [rsp+0x130]
   5ddba:	jmp    5ddd5 <sqlite3VdbeExec+0xe935>
   5ddbc:	mov    rcx,QWORD PTR [rcx+0x28]
   5ddc0:	mov    DWORD PTR [rsp+0x33c],r13d
   5ddc8:	mov    r13,QWORD PTR [rsp+0x130]
   5ddd0:	test   rcx,rcx
   5ddd3:	jne    5dd6c <sqlite3VdbeExec+0xe8cc>
   5ddd5:	test   rcx,rcx
   5ddd8:	jne    5ddec <sqlite3VdbeExec+0xe94c>
   5ddda:	mov    QWORD PTR [rsp+0x130],r13
   5dde2:	mov    r13d,DWORD PTR [rsp+0x33c]
   5ddea:	jmp    5de35 <sqlite3VdbeExec+0xe995>
   5ddec:	mov    QWORD PTR [rsp+0x130],r13
   5ddf4:	mov    r13d,DWORD PTR [rsp+0x33c]
   5ddfc:	mov    QWORD PTR [rsp+0xb0],rdi
   5de04:	mov    rdi,rcx
   5de07:	mov    rsi,r13
   5de0a:	mov    rdx,rax
   5de0d:	call   5de12 <sqlite3VdbeExec+0xe972>
   5de12:	xor    ecx,ecx
   5de14:	mov    rdi,QWORD PTR [rsp+0xb0]
   5de1c:	cmp    ecx,eax
   5de1e:	je     5de35 <sqlite3VdbeExec+0xe995>
   5de20:	mov    r13,QWORD PTR [rsp+0xf0]
   5de28:	mov    r12d,DWORD PTR [rsp+0x334]
   5de30:	jmp    5debf <sqlite3VdbeExec+0xea1f>
   5de35:	cmp    BYTE PTR [r12+0x13],0x0
   5de3b:	je     5de71 <sqlite3VdbeExec+0xe9d1>
   5de3d:	mov    BYTE PTR [r12+0x13],0x0
   5de43:	mov    rax,QWORD PTR [r12+0x8]
   5de48:	mov    rax,QWORD PTR [rax+0x10]
   5de4c:	jmp    5de6c <sqlite3VdbeExec+0xe9cc>
   5de4e:	movzx  ecx,BYTE PTR [rax+0x1]
   5de52:	and    ecx,0x10
   5de55:	test   ecx,ecx
   5de57:	je     5de68 <sqlite3VdbeExec+0xe9c8>
   5de59:	mov    BYTE PTR [r12+0x13],0x1
   5de5f:	cmp    r13d,DWORD PTR [rax+0x50]
   5de63:	jne    5de68 <sqlite3VdbeExec+0xe9c8>
   5de65:	mov    BYTE PTR [rax],0x1
   5de68:	mov    rax,QWORD PTR [rax+0x28]
   5de6c:	test   rax,rax
   5de6f:	jne    5de4e <sqlite3VdbeExec+0xe9ae>
   5de71:	xor    eax,eax
   5de73:	mov    DWORD PTR [rsp+0x31c],r15d
   5de7b:	xor    r12d,r12d
   5de7e:	mov    r15,QWORD PTR [rsp+0x130]
   5de86:	mov    QWORD PTR [rsp+0xb0],rdi
   5de8e:	mov    rdi,r15
   5de91:	mov    rsi,r13
   5de94:	mov    rdx,rax
   5de97:	mov    rcx,r12
   5de9a:	call   5de9f <sqlite3VdbeExec+0xe9ff>
   5de9f:	mov    rdi,QWORD PTR [rsp+0xb0]
   5dea7:	mov    r15d,DWORD PTR [rsp+0x31c]
   5deaf:	mov    r13,QWORD PTR [rsp+0xf0]
   5deb7:	mov    r12d,DWORD PTR [rsp+0x334]
   5debf:	mov    QWORD PTR [rsp+0xf0],r13
   5dec7:	mov    r13d,eax
   5deca:	test   r13d,r13d
   5decd:	jne    5dee4 <sqlite3VdbeExec+0xea44>
   5decf:	mov    DWORD PTR [rsp+0x32c],r13d
   5ded7:	mov    r13,QWORD PTR [rsp+0xf0]
   5dedf:	jmp    5dd11 <sqlite3VdbeExec+0xe871>
   5dee4:	mov    QWORD PTR [rsp+0xe8],rbp
   5deec:	mov    rbp,r13
   5deef:	mov    r13,QWORD PTR [rsp+0xd0]
   5def7:	mov    rbx,QWORD PTR [rsp+0xf8]
   5deff:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5df04:	mov    r15d,DWORD PTR [rsp+0x31c]
   5df0c:	mov    r13,QWORD PTR [rsp+0xf0]
   5df14:	mov    QWORD PTR [rsp+0xd0],r12
   5df1c:	mov    r12d,DWORD PTR [rsp+0x334]
   5df24:	mov    rax,QWORD PTR [rdi+0x68]
   5df28:	movsxd rcx,DWORD PTR [rbp+0x8]
   5df2c:	imul   rcx,rcx,0x38
   5df30:	mov    DWORD PTR [rsp+0x334],r12d
   5df38:	lea    r12,[rax+rcx*1]
   5df3c:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5df41:	and    eax,0x9000
   5df46:	test   eax,eax
   5df48:	je     5df67 <sqlite3VdbeExec+0xeac7>
   5df4a:	mov    QWORD PTR [rsp+0xb0],rdi
   5df52:	mov    rdi,r12
   5df55:	call   5df5a <sqlite3VdbeExec+0xeaba>
   5df5a:	mov    r12,rax
   5df5d:	mov    rdi,QWORD PTR [rsp+0xb0]
   5df65:	jmp    5df6f <sqlite3VdbeExec+0xeacf>
   5df67:	mov    WORD PTR [r12+0x14],0x4
   5df6f:	mov    DWORD PTR [rsp+0x33c],0x0
   5df7a:	mov    rax,QWORD PTR [r14+0x20]
   5df7e:	movsxd rcx,DWORD PTR [rbp+0x4]
   5df82:	shl    rcx,0x5
   5df86:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   5df8b:	mov    QWORD PTR [rsp+0xf0],r13
   5df93:	lea    r13,[rsp+0x33c]
   5df9b:	mov    rcx,r13
   5df9e:	mov    edx,DWORD PTR [rbp+0xc]
   5dfa1:	mov    QWORD PTR [rsp+0xb0],rdi
   5dfa9:	mov    rdi,rax
   5dfac:	mov    rsi,rcx
   5dfaf:	call   5dfb4 <sqlite3VdbeExec+0xeb14>
   5dfb4:	mov    r13d,eax
   5dfb7:	mov    rdi,QWORD PTR [rsp+0xb0]
   5dfbf:	test   r13d,r13d
   5dfc2:	je     5dfe4 <sqlite3VdbeExec+0xeb44>
   5dfc4:	mov    QWORD PTR [rsp+0xe8],rbp
   5dfcc:	mov    rbp,r13
   5dfcf:	mov    r13,QWORD PTR [rsp+0xd0]
   5dfd7:	mov    rbx,QWORD PTR [rsp+0xf8]
   5dfdf:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5dfe4:	mov    eax,DWORD PTR [rsp+0x33c]
   5dfeb:	mov    QWORD PTR [r12],rax
   5dfef:	mov    DWORD PTR [rsp+0x31c],r15d
   5dff7:	mov    DWORD PTR [rsp+0x32c],r13d
   5dfff:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5e004:	mov    r15d,DWORD PTR [rsp+0x31c]
   5e00c:	mov    QWORD PTR [rsp+0xd0],r12
   5e014:	movzx  eax,BYTE PTR [r14+0x70]
   5e019:	add    eax,0x1
   5e01c:	mov    BYTE PTR [r14+0x70],al
   5e020:	mov    QWORD PTR [rsp+0x130],0x0
   5e02c:	mov    r12,QWORD PTR [r14+0x1f8]
   5e033:	movzx  r13d,BYTE PTR [r14+0x6e]
   5e038:	mov    DWORD PTR [rsp+0x31c],r15d
   5e040:	mov    r15d,DWORD PTR [r14+0x2e0]
   5e047:	mov    eax,DWORD PTR [rbp+0x4]
   5e04a:	and    eax,0x1
   5e04d:	test   eax,eax
   5e04f:	je     5e061 <sqlite3VdbeExec+0xebc1>
   5e051:	mov    QWORD PTR [r14+0x1f8],0x0
   5e05c:	mov    BYTE PTR [r14+0x6e],0x0
   5e061:	mov    eax,DWORD PTR [rbp+0x4]
   5e064:	and    eax,0x2
   5e067:	test   eax,eax
   5e069:	je     5e075 <sqlite3VdbeExec+0xebd5>
   5e06b:	mov    eax,DWORD PTR [rbp+0x8]
   5e06e:	mov    DWORD PTR [r14+0x2e0],eax
   5e075:	mov    rax,QWORD PTR [rbp+0x10]
   5e079:	xor    ecx,ecx
   5e07b:	xor    edx,edx
   5e07d:	mov    QWORD PTR [rsp+0xe8],rbp
   5e085:	lea    rbp,[rsp+0x130]
   5e08d:	mov    rsi,rbp
   5e090:	mov    QWORD PTR [rsp+0xb0],rdi
   5e098:	mov    rdi,r14
   5e09b:	mov    r8,rsi
   5e09e:	mov    rsi,rax
   5e0a1:	mov    r11,rdx
   5e0a4:	mov    rdx,rcx
   5e0a7:	mov    rcx,r11
   5e0aa:	call   5e0af <sqlite3VdbeExec+0xec0f>
   5e0af:	mov    ebp,eax
   5e0b1:	movzx  eax,BYTE PTR [r14+0x70]
   5e0b6:	sub    eax,0x1
   5e0b9:	mov    BYTE PTR [r14+0x70],al
   5e0bd:	mov    QWORD PTR [r14+0x1f8],r12
   5e0c4:	mov    BYTE PTR [r14+0x6e],r13b
   5e0c8:	mov    DWORD PTR [r14+0x2e0],r15d
   5e0cf:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e0d7:	cmp    QWORD PTR [rsp+0x130],0x0
   5e0e0:	jne    5e0ea <sqlite3VdbeExec+0xec4a>
   5e0e2:	test   ebp,ebp
   5e0e4:	je     5e1cb <sqlite3VdbeExec+0xed2b>
   5e0ea:	lea    rax,[rip+0x0]        # 5e0f1 <sqlite3VdbeExec+0xec51>
   5e0f1:	mov    rcx,QWORD PTR [rsp+0x130]
   5e0f9:	mov    QWORD PTR [rsp+0xb0],rdi
   5e101:	mov    rsi,rax
   5e104:	mov    rdx,rcx
   5e107:	xor    eax,eax
   5e109:	call   5e10e <sqlite3VdbeExec+0xec6e>
   5e10e:	mov    rbx,QWORD PTR [rsp+0x130]
   5e116:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e11e:	test   rbx,rbx
   5e121:	je     5e194 <sqlite3VdbeExec+0xecf4>
   5e123:	cmp    DWORD PTR [rip+0x0],0x0        # 5e12a <sqlite3VdbeExec+0xec8a>
   5e12a:	je     5e17c <sqlite3VdbeExec+0xecdc>
   5e12c:	mov    rax,QWORD PTR [rip+0x0]        # 5e133 <sqlite3VdbeExec+0xec93>
   5e133:	mov    rdi,rbx
   5e136:	mov    r10,rax
   5e139:	call   r10
   5e13c:	mov    rcx,QWORD PTR [rip+0x0]        # 5e143 <sqlite3VdbeExec+0xeca3>
   5e143:	movsxd rax,eax
   5e146:	sub    rcx,rax
   5e149:	mov    QWORD PTR [rip+0x0],rcx        # 5e150 <sqlite3VdbeExec+0xecb0>
   5e150:	mov    rax,QWORD PTR [rip+0x0]        # 5e157 <sqlite3VdbeExec+0xecb7>
   5e157:	sub    rax,0x1
   5e15b:	mov    QWORD PTR [rip+0x0],rax        # 5e162 <sqlite3VdbeExec+0xecc2>
   5e162:	mov    rax,QWORD PTR [rip+0x0]        # 5e169 <sqlite3VdbeExec+0xecc9>
   5e169:	mov    rdi,rbx
   5e16c:	mov    r10,rax
   5e16f:	call   r10
   5e172:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e17a:	jmp    5e194 <sqlite3VdbeExec+0xecf4>
   5e17c:	mov    rax,QWORD PTR [rip+0x0]        # 5e183 <sqlite3VdbeExec+0xece3>
   5e183:	mov    rdi,rbx
   5e186:	mov    r10,rax
   5e189:	call   r10
   5e18c:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e194:	cmp    ebp,0x7
   5e197:	jne    5e1b6 <sqlite3VdbeExec+0xed16>
   5e199:	mov    r13,QWORD PTR [rsp+0xf0]
   5e1a1:	mov    rbx,QWORD PTR [rsp+0xe8]
   5e1a9:	mov    rbp,QWORD PTR [rsp+0xf8]
   5e1b1:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5e1b6:	mov    r13,QWORD PTR [rsp+0xd0]
   5e1be:	mov    rbx,QWORD PTR [rsp+0xf8]
   5e1c6:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5e1cb:	mov    DWORD PTR [rsp+0x32c],ebp
   5e1d2:	mov    rbp,QWORD PTR [rsp+0xe8]
   5e1da:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5e1df:	mov    QWORD PTR [rsp+0xe8],rbp
   5e1e7:	mov    QWORD PTR [rsp+0xd0],r12
   5e1ef:	mov    rbp,QWORD PTR [rsp+0xe8]
   5e1f7:	movsxd r12,DWORD PTR [rbp+0x4]
   5e1fb:	cmp    QWORD PTR [rbp+0x10],0x0
   5e200:	jne    5e27e <sqlite3VdbeExec+0xedde>
   5e202:	mov    rax,QWORD PTR [r14+0x20]
   5e206:	mov    rcx,r12
   5e209:	shl    rcx,0x5
   5e20d:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   5e212:	mov    QWORD PTR [rsp+0xb0],rdi
   5e21a:	mov    rdi,rax
   5e21d:	call   5e222 <sqlite3VdbeExec+0xed82>
   5e222:	mov    eax,DWORD PTR [r14+0x2c]
   5e226:	and    eax,0xffffffef
   5e229:	mov    DWORD PTR [r14+0x2c],eax
   5e22d:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e235:	lea    rax,[rdi+0xa8]
   5e23c:	movzx  ecx,WORD PTR [rbp+0x2]
   5e240:	mov    rdi,r14
   5e243:	mov    rsi,r12
   5e246:	mov    rdx,rax
   5e249:	call   5e24e <sqlite3VdbeExec+0xedae>
   5e24e:	mov    r12d,eax
   5e251:	mov    eax,DWORD PTR [r14+0x2c]
   5e255:	or     eax,0x1
   5e258:	mov    DWORD PTR [r14+0x2c],eax
   5e25c:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e264:	movzx  eax,WORD PTR [rdi+0xc8]
   5e26b:	and    rax,0xfffffffffffffffc
   5e26f:	mov    WORD PTR [rdi+0xc8],ax
   5e276:	mov    r15,r12
   5e279:	jmp    5e3dc <sqlite3VdbeExec+0xef3c>
   5e27e:	lea    rax,[rip+0x0]        # 5e285 <sqlite3VdbeExec+0xede5>
   5e285:	mov    QWORD PTR [rsp+0x188],r14
   5e28d:	mov    DWORD PTR [rsp+0x198],r12d
   5e295:	lea    rcx,[rdi+0xa8]
   5e29c:	mov    QWORD PTR [rsp+0x190],rcx
   5e2a4:	mov    DWORD PTR [rsp+0x1a0],0x0
   5e2af:	mov    rcx,QWORD PTR [r14+0x20]
   5e2b3:	mov    rdx,r12
   5e2b6:	mov    rsi,rdx
   5e2b9:	shl    rsi,0x5
   5e2bd:	mov    rcx,QWORD PTR [rcx+rsi*1+0x8]
   5e2c2:	mov    rcx,QWORD PTR [rcx+0x8]
   5e2c6:	mov    ecx,DWORD PTR [rcx+0x40]
   5e2c9:	mov    DWORD PTR [rsp+0x1a8],ecx
   5e2d0:	lea    rcx,[rip+0x0]        # 5e2d7 <sqlite3VdbeExec+0xee37>
   5e2d7:	mov    rsi,QWORD PTR [r14+0x20]
   5e2db:	shl    rdx,0x5
   5e2df:	mov    rdx,QWORD PTR [rsi+rdx*1]
   5e2e3:	mov    rsi,QWORD PTR [rbp+0x10]
   5e2e7:	mov    QWORD PTR [rsp+0xb0],rdi
   5e2ef:	mov    rdi,r14
   5e2f2:	mov    r8,rsi
   5e2f5:	mov    rsi,rcx
   5e2f8:	mov    rcx,rax
   5e2fb:	xor    eax,eax
   5e2fd:	call   5e302 <sqlite3VdbeExec+0xee62>
   5e302:	mov    r12,rax
   5e305:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e30d:	test   r12,r12
   5e310:	jne    5e320 <sqlite3VdbeExec+0xee80>
   5e312:	mov    r12d,0x7
   5e318:	mov    r15,r12
   5e31b:	jmp    5e3dc <sqlite3VdbeExec+0xef3c>
   5e320:	mov    BYTE PTR [r14+0xc5],0x1
   5e328:	mov    DWORD PTR [rsp+0x19c],0x0
   5e333:	mov    DWORD PTR [rsp+0x1a4],0x0
   5e33e:	lea    rax,[rip+0x0]        # 5e345 <sqlite3VdbeExec+0xeea5>
   5e345:	lea    r13,[rsp+0x188]
   5e34d:	mov    rcx,r13
   5e350:	xor    edx,edx
   5e352:	mov    rdi,r14
   5e355:	mov    rsi,r12
   5e358:	mov    r8,rdx
   5e35b:	mov    rdx,rax
   5e35e:	call   5e363 <sqlite3VdbeExec+0xeec3>
   5e363:	mov    r15d,eax
   5e366:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e36e:	test   r15d,r15d
   5e371:	jne    5e37b <sqlite3VdbeExec+0xeedb>
   5e373:	mov    r15d,DWORD PTR [rsp+0x19c]
   5e37b:	test   r15d,r15d
   5e37e:	jne    5e3b9 <sqlite3VdbeExec+0xef19>
   5e380:	cmp    DWORD PTR [rsp+0x1a4],0x0
   5e388:	jne    5e3b9 <sqlite3VdbeExec+0xef19>
   5e38a:	mov    eax,0x194dc
   5e38f:	mov    ecx,0xb
   5e394:	lea    rdx,[rip+0x0]        # 5e39b <sqlite3VdbeExec+0xeefb>
   5e39b:	mov    QWORD PTR [rsp+0xb0],rdi
   5e3a3:	mov    rdi,rcx
   5e3a6:	mov    rsi,rax
   5e3a9:	call   5e3ae <sqlite3VdbeExec+0xef0e>
   5e3ae:	mov    r15d,eax
   5e3b1:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e3b9:	mov    QWORD PTR [rsp+0xb0],rdi
   5e3c1:	mov    rdi,r14
   5e3c4:	mov    rsi,r12
   5e3c7:	call   5e3cc <sqlite3VdbeExec+0xef2c>
   5e3cc:	mov    BYTE PTR [r14+0xc5],0x0
   5e3d4:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e3dc:	test   r15d,r15d
   5e3df:	je     5e437 <sqlite3VdbeExec+0xef97>
   5e3e1:	mov    QWORD PTR [rsp+0xb0],rdi
   5e3e9:	mov    rdi,r14
   5e3ec:	call   5e3f1 <sqlite3VdbeExec+0xef51>
   5e3f1:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e3f9:	cmp    r15d,0x7
   5e3fd:	jne    5e417 <sqlite3VdbeExec+0xef77>
   5e3ff:	mov    r13,QWORD PTR [rsp+0xf0]
   5e407:	mov    rbx,rbp
   5e40a:	mov    rbp,QWORD PTR [rsp+0xf8]
   5e412:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5e417:	mov    QWORD PTR [rsp+0xe8],rbp
   5e41f:	mov    rbp,r15
   5e422:	mov    r13,QWORD PTR [rsp+0xd0]
   5e42a:	mov    rbx,QWORD PTR [rsp+0xf8]
   5e432:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5e437:	mov    DWORD PTR [rsp+0x32c],r15d
   5e43f:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5e444:	mov    QWORD PTR [rsp+0xd0],r12
   5e44c:	mov    eax,DWORD PTR [rbp+0x4]
   5e44f:	mov    QWORD PTR [rsp+0xb0],rdi
   5e457:	mov    rdi,r14
   5e45a:	mov    rsi,rax
   5e45d:	call   5e462 <sqlite3VdbeExec+0xefc2>
   5e462:	mov    r12d,eax
   5e465:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e46d:	test   r12d,r12d
   5e470:	je     5e492 <sqlite3VdbeExec+0xeff2>
   5e472:	mov    QWORD PTR [rsp+0xe8],rbp
   5e47a:	mov    rbp,r12
   5e47d:	mov    r13,QWORD PTR [rsp+0xd0]
   5e485:	mov    rbx,QWORD PTR [rsp+0xf8]
   5e48d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5e492:	mov    DWORD PTR [rsp+0x32c],r12d
   5e49a:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5e49f:	mov    r15d,DWORD PTR [rsp+0x31c]
   5e4a7:	mov    r13,QWORD PTR [rsp+0xf0]
   5e4af:	mov    QWORD PTR [rsp+0xd0],r12
   5e4b7:	mov    r12d,DWORD PTR [rsp+0x334]
   5e4bf:	movsxd rax,DWORD PTR [rbp+0x4]
   5e4c3:	mov    rcx,QWORD PTR [rbp+0x10]
   5e4c7:	mov    rdx,QWORD PTR [r14+0x20]
   5e4cb:	shl    rax,0x5
   5e4cf:	mov    rax,QWORD PTR [rdx+rax*1+0x18]
   5e4d4:	add    rax,0x8
   5e4d8:	xor    edx,edx
   5e4da:	mov    QWORD PTR [rsp+0xb0],rdi
   5e4e2:	mov    rdi,rax
   5e4e5:	mov    rsi,rcx
   5e4e8:	call   5e4ed <sqlite3VdbeExec+0xf04d>
   5e4ed:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e4f5:	test   rax,rax
   5e4f8:	je     5e52c <sqlite3VdbeExec+0xf08c>
   5e4fa:	cmp    QWORD PTR [r14+0x300],0x0
   5e502:	jne    5e511 <sqlite3VdbeExec+0xf071>
   5e504:	mov    ecx,DWORD PTR [rax+0x2c]
   5e507:	sub    ecx,0x1
   5e50a:	mov    DWORD PTR [rax+0x2c],ecx
   5e50d:	test   ecx,ecx
   5e50f:	ja     5e52c <sqlite3VdbeExec+0xf08c>
   5e511:	mov    QWORD PTR [rsp+0xb0],rdi
   5e519:	mov    rdi,r14
   5e51c:	mov    rsi,rax
   5e51f:	call   5e524 <sqlite3VdbeExec+0xf084>
   5e524:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e52c:	mov    eax,DWORD PTR [r14+0x2c]
   5e530:	or     eax,0x1
   5e533:	mov    DWORD PTR [r14+0x2c],eax
   5e537:	mov    DWORD PTR [rsp+0x31c],r15d
   5e53f:	mov    QWORD PTR [rsp+0xf0],r13
   5e547:	mov    DWORD PTR [rsp+0x334],r12d
   5e54f:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5e554:	mov    r15d,DWORD PTR [rsp+0x31c]
   5e55c:	mov    r13,QWORD PTR [rsp+0xf0]
   5e564:	mov    QWORD PTR [rsp+0xd0],r12
   5e56c:	mov    r12d,DWORD PTR [rsp+0x334]
   5e574:	movsxd rax,DWORD PTR [rbp+0x4]
   5e578:	mov    rcx,QWORD PTR [rbp+0x10]
   5e57c:	mov    rdx,QWORD PTR [r14+0x20]
   5e580:	shl    rax,0x5
   5e584:	mov    rax,QWORD PTR [rdx+rax*1+0x18]
   5e589:	add    rax,0x20
   5e58d:	xor    edx,edx
   5e58f:	mov    DWORD PTR [rsp+0x334],r12d
   5e597:	mov    QWORD PTR [rsp+0xb0],rdi
   5e59f:	mov    rdi,rax
   5e5a2:	mov    rsi,rcx
   5e5a5:	call   5e5aa <sqlite3VdbeExec+0xf10a>
   5e5aa:	mov    r12,rax
   5e5ad:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e5b5:	test   r12,r12
   5e5b8:	je     5e6cd <sqlite3VdbeExec+0xf22d>
   5e5be:	mov    rax,QWORD PTR [r12+0x18]
   5e5c3:	cmp    r12,QWORD PTR [rax+0x10]
   5e5c7:	jne    5e5d9 <sqlite3VdbeExec+0xf139>
   5e5c9:	mov    rax,QWORD PTR [r12+0x18]
   5e5ce:	mov    rcx,QWORD PTR [r12+0x28]
   5e5d3:	mov    QWORD PTR [rax+0x10],rcx
   5e5d7:	jmp    5e607 <sqlite3VdbeExec+0xf167>
   5e5d9:	mov    rax,QWORD PTR [r12+0x18]
   5e5de:	mov    rax,QWORD PTR [rax+0x10]
   5e5e2:	jmp    5e5ee <sqlite3VdbeExec+0xf14e>
   5e5e4:	cmp    r12,QWORD PTR [rax+0x28]
   5e5e8:	je     5e5f3 <sqlite3VdbeExec+0xf153>
   5e5ea:	mov    rax,QWORD PTR [rax+0x28]
   5e5ee:	test   rax,rax
   5e5f1:	jne    5e5e4 <sqlite3VdbeExec+0xf144>
   5e5f3:	test   rax,rax
   5e5f6:	je     5e607 <sqlite3VdbeExec+0xf167>
   5e5f8:	cmp    r12,QWORD PTR [rax+0x28]
   5e5fc:	jne    5e607 <sqlite3VdbeExec+0xf167>
   5e5fe:	mov    rcx,QWORD PTR [r12+0x28]
   5e603:	mov    QWORD PTR [rax+0x28],rcx
   5e607:	mov    rax,QWORD PTR [r12+0x48]
   5e60c:	test   rax,rax
   5e60f:	je     5e62c <sqlite3VdbeExec+0xf18c>
   5e611:	mov    QWORD PTR [rsp+0xb0],rdi
   5e619:	mov    rdi,r14
   5e61c:	mov    rsi,rax
   5e61f:	call   5e624 <sqlite3VdbeExec+0xf184>
   5e624:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e62c:	mov    rax,QWORD PTR [r12+0x50]
   5e631:	test   rax,rax
   5e634:	je     5e651 <sqlite3VdbeExec+0xf1b1>
   5e636:	mov    QWORD PTR [rsp+0xb0],rdi
   5e63e:	mov    rdi,r14
   5e641:	mov    rsi,rax
   5e644:	call   5e649 <sqlite3VdbeExec+0xf1a9>
   5e649:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e651:	mov    rax,QWORD PTR [r12+0x20]
   5e656:	test   rax,rax
   5e659:	je     5e676 <sqlite3VdbeExec+0xf1d6>
   5e65b:	mov    QWORD PTR [rsp+0xb0],rdi
   5e663:	mov    rdi,r14
   5e666:	mov    rsi,rax
   5e669:	call   5e66e <sqlite3VdbeExec+0xf1ce>
   5e66e:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e676:	movzx  eax,WORD PTR [r12+0x63]
   5e67c:	shl    rax,0x3b
   5e680:	shr    rax,0x3f
   5e684:	test   eax,eax
   5e686:	je     5e6ad <sqlite3VdbeExec+0xf20d>
   5e688:	mov    rax,QWORD PTR [r12+0x40]
   5e68d:	test   rax,rax
   5e690:	je     5e6ad <sqlite3VdbeExec+0xf20d>
   5e692:	mov    QWORD PTR [rsp+0xb0],rdi
   5e69a:	mov    rdi,r14
   5e69d:	mov    rsi,rax
   5e6a0:	call   5e6a5 <sqlite3VdbeExec+0xf205>
   5e6a5:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e6ad:	test   r12,r12
   5e6b0:	je     5e6cd <sqlite3VdbeExec+0xf22d>
   5e6b2:	mov    QWORD PTR [rsp+0xb0],rdi
   5e6ba:	mov    rdi,r14
   5e6bd:	mov    rsi,r12
   5e6c0:	call   5e6c5 <sqlite3VdbeExec+0xf225>
   5e6c5:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e6cd:	mov    eax,DWORD PTR [r14+0x2c]
   5e6d1:	or     eax,0x1
   5e6d4:	mov    DWORD PTR [r14+0x2c],eax
   5e6d8:	mov    DWORD PTR [rsp+0x31c],r15d
   5e6e0:	mov    QWORD PTR [rsp+0xf0],r13
   5e6e8:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5e6ed:	mov    r15d,DWORD PTR [rsp+0x31c]
   5e6f5:	mov    r13,QWORD PTR [rsp+0xf0]
   5e6fd:	mov    QWORD PTR [rsp+0xd0],r12
   5e705:	movsxd rax,DWORD PTR [rbp+0x4]
   5e709:	mov    rcx,QWORD PTR [rbp+0x10]
   5e70d:	mov    rdx,QWORD PTR [r14+0x20]
   5e711:	shl    rax,0x5
   5e715:	mov    rax,QWORD PTR [rdx+rax*1+0x18]
   5e71a:	add    rax,0x38
   5e71e:	xor    edx,edx
   5e720:	mov    QWORD PTR [rsp+0xb0],rdi
   5e728:	mov    rdi,rax
   5e72b:	mov    rsi,rcx
   5e72e:	call   5e733 <sqlite3VdbeExec+0xf293>
   5e733:	mov    r12,rax
   5e736:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e73e:	test   r12,r12
   5e741:	je     5ea95 <sqlite3VdbeExec+0xf5f5>
   5e747:	mov    rax,QWORD PTR [r12+0x28]
   5e74c:	cmp    rax,QWORD PTR [r12+0x30]
   5e751:	jne    5e8a0 <sqlite3VdbeExec+0xf400>
   5e757:	mov    rax,QWORD PTR [r12+0x30]
   5e75c:	mov    rcx,QWORD PTR [r12+0x8]
   5e761:	xor    edx,edx
   5e763:	mov    rsi,rcx
   5e766:	jmp    5e780 <sqlite3VdbeExec+0xf2e0>
   5e768:	movzx  r8d,BYTE PTR [rsi]
   5e76c:	add    rsi,0x1
   5e770:	and    r8d,0xdf
   5e777:	add    edx,r8d
   5e77a:	imul   edx,edx,0x9e3779b1
   5e780:	cmp    BYTE PTR [rsi],0x0
   5e783:	jne    5e768 <sqlite3VdbeExec+0xf2c8>
   5e785:	mov    esi,edx
   5e787:	cmp    QWORD PTR [rax+0x18],0x0
   5e78c:	je     5e7af <sqlite3VdbeExec+0xf30f>
   5e78e:	mov    r8,QWORD PTR [rax+0x18]
   5e792:	mov    r9d,DWORD PTR [rax+0x8]
   5e796:	mov    rax,rsi
   5e799:	xor    edx,edx
   5e79b:	div    r9d
   5e79e:	mov    eax,edx
   5e7a0:	shl    rax,0x4
   5e7a4:	mov    rdx,QWORD PTR [r8+rax*1+0x8]
   5e7a9:	mov    eax,DWORD PTR [r8+rax*1]
   5e7ad:	jmp    5e7b6 <sqlite3VdbeExec+0xf316>
   5e7af:	mov    rdx,QWORD PTR [rax+0x10]
   5e7b3:	mov    eax,DWORD PTR [rax+0xc]
   5e7b6:	mov    r10,rax
   5e7b9:	mov    rax,rdx
   5e7bc:	jmp    5e846 <sqlite3VdbeExec+0xf3a6>
   5e7c1:	mov    QWORD PTR [rsp+0xa0],rdi
   5e7c9:	lea    rdi,[rip+0x0]        # 5e7d0 <sqlite3VdbeExec+0xf330>
   5e7d0:	movzx  edx,BYTE PTR [rdi+rdx*1]
   5e7d4:	movzx  edi,BYTE PTR [rdi+r9*1]
   5e7d9:	sub    edx,edi
   5e7db:	test   edx,edx
   5e7dd:	je     5e7ff <sqlite3VdbeExec+0xf35f>
   5e7df:	test   edx,edx
   5e7e1:	je     5e7ed <sqlite3VdbeExec+0xf34d>
   5e7e3:	mov    rdi,QWORD PTR [rsp+0xa0]
   5e7eb:	jmp    5e837 <sqlite3VdbeExec+0xf397>
   5e7ed:	mov    rdi,QWORD PTR [rsp+0xa0]
   5e7f5:	mov    rax,QWORD PTR [rsp+0x128]
   5e7fd:	jmp    5e875 <sqlite3VdbeExec+0xf3d5>
   5e7ff:	add    rax,0x1
   5e803:	add    r8,0x1
   5e807:	mov    rdi,QWORD PTR [rsp+0xa0]
   5e80f:	movzx  edx,BYTE PTR [rax]
   5e812:	movzx  r9d,BYTE PTR [r8]
   5e816:	cmp    edx,r9d
   5e819:	jne    5e7c1 <sqlite3VdbeExec+0xf321>
   5e81b:	test   edx,edx
   5e81d:	je     5e829 <sqlite3VdbeExec+0xf389>
   5e81f:	mov    QWORD PTR [rsp+0xa0],rdi
   5e827:	jmp    5e7ff <sqlite3VdbeExec+0xf35f>
   5e829:	test   edx,edx
   5e82b:	jne    5e837 <sqlite3VdbeExec+0xf397>
   5e82d:	mov    QWORD PTR [rsp+0xa0],rdi
   5e835:	jmp    5e7ed <sqlite3VdbeExec+0xf34d>
   5e837:	mov    rax,QWORD PTR [rsp+0x128]
   5e83f:	mov    rax,QWORD PTR [rax]
   5e842:	sub    r10d,0x1
   5e846:	test   r10d,r10d
   5e849:	je     5e86e <sqlite3VdbeExec+0xf3ce>
   5e84b:	cmp    esi,DWORD PTR [rax+0x20]
   5e84e:	je     5e85a <sqlite3VdbeExec+0xf3ba>
   5e850:	mov    QWORD PTR [rsp+0x128],rax
   5e858:	jmp    5e837 <sqlite3VdbeExec+0xf397>
   5e85a:	mov    rdx,QWORD PTR [rax+0x18]
   5e85e:	mov    QWORD PTR [rsp+0x128],rax
   5e866:	mov    rax,rdx
   5e869:	mov    r8,rcx
   5e86c:	jmp    5e80f <sqlite3VdbeExec+0xf36f>
   5e86e:	lea    rax,[rip+0x0]        # 5e875 <sqlite3VdbeExec+0xf3d5>
   5e875:	mov    rax,QWORD PTR [rax+0x10]
   5e879:	test   rax,rax
   5e87c:	je     5e8a0 <sqlite3VdbeExec+0xf400>
   5e87e:	add    rax,0x58
   5e882:	jmp    5e88b <sqlite3VdbeExec+0xf3eb>
   5e884:	mov    rax,QWORD PTR [rax]
   5e887:	add    rax,0x40
   5e88b:	cmp    QWORD PTR [rax],0x0
   5e88f:	je     5e8a0 <sqlite3VdbeExec+0xf400>
   5e891:	cmp    r12,QWORD PTR [rax]
   5e894:	jne    5e884 <sqlite3VdbeExec+0xf3e4>
   5e896:	mov    rcx,QWORD PTR [rax]
   5e899:	mov    rcx,QWORD PTR [rcx+0x40]
   5e89d:	mov    QWORD PTR [rax],rcx
   5e8a0:	test   r12,r12
   5e8a3:	je     5ea8a <sqlite3VdbeExec+0xf5ea>
   5e8a9:	cmp    BYTE PTR [r12+0x12],0x0
   5e8af:	jne    5ea8a <sqlite3VdbeExec+0xf5ea>
   5e8b5:	mov    QWORD PTR [rsp+0x130],r12
   5e8bd:	mov    r12,QWORD PTR [r12+0x38]
   5e8c2:	jmp    5e9d3 <sqlite3VdbeExec+0xf533>
   5e8c7:	mov    QWORD PTR [rsp+0xf0],r13
   5e8cf:	mov    r13,QWORD PTR [r12+0x48]
   5e8d4:	mov    rax,QWORD PTR [r12+0x20]
   5e8d9:	test   rax,rax
   5e8dc:	je     5e8f9 <sqlite3VdbeExec+0xf459>
   5e8de:	mov    QWORD PTR [rsp+0xb0],rdi
   5e8e6:	mov    rdi,r14
   5e8e9:	mov    rsi,rax
   5e8ec:	call   5e8f1 <sqlite3VdbeExec+0xf451>
   5e8f1:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e8f9:	mov    rax,QWORD PTR [r12+0x28]
   5e8fe:	test   rax,rax
   5e901:	je     5e91e <sqlite3VdbeExec+0xf47e>
   5e903:	mov    QWORD PTR [rsp+0xb0],rdi
   5e90b:	mov    rdi,r14
   5e90e:	mov    rsi,rax
   5e911:	call   5e916 <sqlite3VdbeExec+0xf476>
   5e916:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e91e:	mov    rax,QWORD PTR [r12+0x10]
   5e923:	mov    QWORD PTR [rsp+0xb0],rdi
   5e92b:	mov    rdi,r14
   5e92e:	mov    rsi,rax
   5e931:	call   5e936 <sqlite3VdbeExec+0xf496>
   5e936:	mov    rax,QWORD PTR [r12+0x30]
   5e93b:	mov    rdi,r14
   5e93e:	mov    rsi,rax
   5e941:	call   5e946 <sqlite3VdbeExec+0xf4a6>
   5e946:	mov    rax,QWORD PTR [r12+0x38]
   5e94b:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e953:	test   rax,rax
   5e956:	je     5e96b <sqlite3VdbeExec+0xf4cb>
   5e958:	mov    rdi,r14
   5e95b:	mov    rsi,rax
   5e95e:	call   5e963 <sqlite3VdbeExec+0xf4c3>
   5e963:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e96b:	mov    rax,QWORD PTR [r12+0x18]
   5e970:	mov    QWORD PTR [rsp+0xb0],rdi
   5e978:	mov    rdi,r14
   5e97b:	mov    rsi,rax
   5e97e:	call   5e983 <sqlite3VdbeExec+0xf4e3>
   5e983:	mov    rax,QWORD PTR [r12+0x40]
   5e988:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e990:	test   rax,rax
   5e993:	je     5e9a8 <sqlite3VdbeExec+0xf508>
   5e995:	mov    rdi,r14
   5e998:	mov    rsi,rax
   5e99b:	call   5e9a0 <sqlite3VdbeExec+0xf500>
   5e9a0:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e9a8:	test   r12,r12
   5e9ab:	je     5e9c8 <sqlite3VdbeExec+0xf528>
   5e9ad:	mov    QWORD PTR [rsp+0xb0],rdi
   5e9b5:	mov    rdi,r14
   5e9b8:	mov    rsi,r12
   5e9bb:	call   5e9c0 <sqlite3VdbeExec+0xf520>
   5e9c0:	mov    rdi,QWORD PTR [rsp+0xb0]
   5e9c8:	mov    r12,r13
   5e9cb:	mov    r13,QWORD PTR [rsp+0xf0]
   5e9d3:	test   r12,r12
   5e9d6:	jne    5e8c7 <sqlite3VdbeExec+0xf427>
   5e9dc:	mov    r12,QWORD PTR [rsp+0x130]
   5e9e4:	mov    rax,QWORD PTR [r12]
   5e9e8:	test   rax,rax
   5e9eb:	je     5ea08 <sqlite3VdbeExec+0xf568>
   5e9ed:	mov    QWORD PTR [rsp+0xb0],rdi
   5e9f5:	mov    rdi,r14
   5e9f8:	mov    rsi,rax
   5e9fb:	call   5ea00 <sqlite3VdbeExec+0xf560>
   5ea00:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ea08:	mov    rax,QWORD PTR [r12+0x8]
   5ea0d:	test   rax,rax
   5ea10:	je     5ea2d <sqlite3VdbeExec+0xf58d>
   5ea12:	mov    QWORD PTR [rsp+0xb0],rdi
   5ea1a:	mov    rdi,r14
   5ea1d:	mov    rsi,rax
   5ea20:	call   5ea25 <sqlite3VdbeExec+0xf585>
   5ea25:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ea2d:	mov    rax,QWORD PTR [r12+0x18]
   5ea32:	test   rax,rax
   5ea35:	je     5ea52 <sqlite3VdbeExec+0xf5b2>
   5ea37:	mov    QWORD PTR [rsp+0xb0],rdi
   5ea3f:	mov    rdi,r14
   5ea42:	mov    rsi,rax
   5ea45:	call   5ea4a <sqlite3VdbeExec+0xf5aa>
   5ea4a:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ea52:	mov    rax,QWORD PTR [r12+0x20]
   5ea57:	mov    QWORD PTR [rsp+0xb0],rdi
   5ea5f:	mov    rdi,r14
   5ea62:	mov    rsi,rax
   5ea65:	call   5ea6a <sqlite3VdbeExec+0xf5ca>
   5ea6a:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ea72:	test   r12,r12
   5ea75:	je     5ea8a <sqlite3VdbeExec+0xf5ea>
   5ea77:	mov    rdi,r14
   5ea7a:	mov    rsi,r12
   5ea7d:	call   5ea82 <sqlite3VdbeExec+0xf5e2>
   5ea82:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ea8a:	mov    eax,DWORD PTR [r14+0x2c]
   5ea8e:	or     eax,0x1
   5ea91:	mov    DWORD PTR [r14+0x2c],eax
   5ea95:	mov    DWORD PTR [rsp+0x31c],r15d
   5ea9d:	mov    QWORD PTR [rsp+0xf0],r13
   5eaa5:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5eaaa:	mov    r15d,DWORD PTR [rsp+0x31c]
   5eab2:	mov    r13,QWORD PTR [rsp+0xf0]
   5eaba:	mov    QWORD PTR [rsp+0xd0],r12
   5eac2:	mov    r12d,DWORD PTR [rbp+0x8]
   5eac6:	mov    DWORD PTR [rsp+0x348],r12d
   5eace:	mov    r12,QWORD PTR [rbp+0x10]
   5ead2:	movsxd rax,DWORD PTR [rbp+0x4]
   5ead6:	mov    QWORD PTR [rsp+0xf0],r13
   5eade:	imul   r13,rax,0x38
   5eae2:	mov    eax,DWORD PTR [rbp+0x4]
   5eae5:	add    eax,0x1
   5eae8:	movsxd rax,eax
   5eaeb:	imul   rax,rax,0x38
   5eaef:	mov    DWORD PTR [rsp+0x31c],r15d
   5eaf7:	lea    r15,[rbx+rax*1]
   5eafb:	mov    rax,QWORD PTR [r14+0x20]
   5eaff:	movzx  ecx,WORD PTR [rbp+0x2]
   5eb03:	shl    rcx,0x5
   5eb07:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   5eb0c:	movsxd rcx,DWORD PTR [rbp+0xc]
   5eb10:	imul   rcx,rcx,0x38
   5eb14:	mov    QWORD PTR [rsp+0x108],r15
   5eb1c:	lea    r15,[rbx+rcx*1]
   5eb20:	mov    rcx,QWORD PTR [rbx+r13*1]
   5eb24:	mov    QWORD PTR [rsp+0x138],r15
   5eb2c:	lea    r15d,[rcx+0x1]
   5eb30:	mov    DWORD PTR [rsp+0x338],r15d
   5eb38:	mov    r15,QWORD PTR [rax+0x8]
   5eb3c:	mov    rcx,QWORD PTR [r15+0x8]
   5eb40:	mov    QWORD PTR [rsp+0x128],r13
   5eb48:	mov    r13,QWORD PTR [rcx+0x30]
   5eb4c:	cmp    DWORD PTR [r12+0x4],0x0
   5eb52:	je     5eb6f <sqlite3VdbeExec+0xf6cf>
   5eb54:	mov    QWORD PTR [rsp+0x140],r13
   5eb5c:	xor    r11d,r11d
   5eb5f:	mov    DWORD PTR [rsp+0x344],r11d
   5eb67:	mov    r13d,0x1
   5eb6d:	jmp    5eb97 <sqlite3VdbeExec+0xf6f7>
   5eb6f:	xor    ecx,ecx
   5eb71:	mov    QWORD PTR [rsp+0x140],r13
   5eb79:	mov    r13d,0x1
   5eb7f:	cmp    DWORD PTR [r12+0x8],0x1
   5eb85:	cmovne r13d,ecx
   5eb89:	mov    r11d,0x1
   5eb8f:	mov    DWORD PTR [rsp+0x344],r11d
   5eb97:	mov    rcx,QWORD PTR [rax+0x8]
   5eb9b:	mov    rax,QWORD PTR [rax]
   5eb9e:	mov    QWORD PTR [rcx+0x8],rax
   5eba2:	mov    QWORD PTR [rsp+0x100],rbx
   5ebaa:	lea    rbx,[rsp+0x298]
   5ebb2:	mov    rax,rbx
   5ebb5:	xor    ecx,ecx
   5ebb7:	mov    edx,0x80
   5ebbc:	mov    QWORD PTR [rsp+0xb0],rdi
   5ebc4:	mov    rdi,rax
   5ebc7:	mov    rsi,rcx
   5ebca:	call   5ebcf <sqlite3VdbeExec+0xf72f>
   5ebcf:	mov    QWORD PTR [rbx+0x70],r14
   5ebd3:	mov    QWORD PTR [rbx],r15
   5ebd6:	mov    rax,QWORD PTR [r15]
   5ebd9:	mov    QWORD PTR [rbx+0x8],rax
   5ebdd:	mov    rax,QWORD PTR [rbx]
   5ebe0:	mov    eax,DWORD PTR [rax+0x40]
   5ebe3:	mov    DWORD PTR [rbx+0x18],eax
   5ebe6:	mov    QWORD PTR [rsp+0xc8],r14
   5ebee:	mov    r14d,DWORD PTR [rsp+0x338]
   5ebf6:	mov    DWORD PTR [rbx+0x1c],r14d
   5ebfa:	lea    r14,[rsp+0x30]
   5ebff:	mov    rax,r14
   5ec02:	mov    QWORD PTR [rbx+0x50],rax
   5ec06:	mov    QWORD PTR [rbx+0x48],0x0
   5ec0e:	mov    DWORD PTR [rbx+0x58],0x64
   5ec15:	mov    DWORD PTR [rbx+0x5c],0x3b9aca00
   5ec1c:	mov    DWORD PTR [rbx+0x60],0x0
   5ec23:	mov    BYTE PTR [rbx+0x64],0x0
   5ec27:	mov    BYTE PTR [rbx+0x65],0x0
   5ec2b:	mov    BYTE PTR [rbx+0x65],0x1
   5ec2f:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ec37:	cmp    DWORD PTR [rbx+0x18],0x0
   5ec3b:	je     5ecb5 <sqlite3VdbeExec+0xf815>
   5ec3d:	mov    eax,DWORD PTR [rbx+0x18]
   5ec40:	shr    eax,0x3
   5ec43:	add    eax,0x1
   5ec46:	mov    r14,rax
   5ec49:	mov    rdi,r14
   5ec4c:	call   5ec51 <sqlite3VdbeExec+0xf7b1>
   5ec51:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ec59:	test   rax,rax
   5ec5c:	je     5ec89 <sqlite3VdbeExec+0xf7e9>
   5ec5e:	xor    ecx,ecx
   5ec60:	mov    QWORD PTR [rsp+0xa8],rax
   5ec68:	mov    rdi,rax
   5ec6b:	mov    rsi,rcx
   5ec6e:	mov    rdx,r14
   5ec71:	call   5ec76 <sqlite3VdbeExec+0xf7d6>
   5ec76:	mov    rcx,rax
   5ec79:	mov    rax,QWORD PTR [rsp+0xa8]
   5ec81:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ec89:	mov    QWORD PTR [rbx+0x10],rax
   5ec8d:	cmp    QWORD PTR [rbx+0x10],0x0
   5ec92:	jne    5ed3e <sqlite3VdbeExec+0xf89e>
   5ec98:	mov    DWORD PTR [rbx+0x24],0x7
   5ec9f:	mov    DWORD PTR [rbx+0x1c],0x0
   5eca6:	cmp    DWORD PTR [rbx+0x20],0x0
   5ecaa:	jne    5ecb5 <sqlite3VdbeExec+0xf815>
   5ecac:	mov    eax,DWORD PTR [rbx+0x20]
   5ecaf:	add    eax,0x1
   5ecb2:	mov    DWORD PTR [rbx+0x20],eax
   5ecb5:	mov    rax,QWORD PTR [rbx+0x68]
   5ecb9:	mov    QWORD PTR [rsp+0xb0],rdi
   5ecc1:	mov    rdi,rax
   5ecc4:	call   5ecc9 <sqlite3VdbeExec+0xf829>
   5ecc9:	mov    r12,QWORD PTR [rbx+0x10]
   5eccd:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ecd5:	test   r12,r12
   5ecd8:	je     5f5c3 <sqlite3VdbeExec+0x10123>
   5ecde:	cmp    DWORD PTR [rip+0x0],0x0        # 5ece5 <sqlite3VdbeExec+0xf845>
   5ece5:	je     5f5ab <sqlite3VdbeExec+0x1010b>
   5eceb:	mov    rax,QWORD PTR [rip+0x0]        # 5ecf2 <sqlite3VdbeExec+0xf852>
   5ecf2:	mov    rdi,r12
   5ecf5:	mov    r10,rax
   5ecf8:	call   r10
   5ecfb:	mov    rcx,QWORD PTR [rip+0x0]        # 5ed02 <sqlite3VdbeExec+0xf862>
   5ed02:	movsxd rax,eax
   5ed05:	sub    rcx,rax
   5ed08:	mov    QWORD PTR [rip+0x0],rcx        # 5ed0f <sqlite3VdbeExec+0xf86f>
   5ed0f:	mov    rax,QWORD PTR [rip+0x0]        # 5ed16 <sqlite3VdbeExec+0xf876>
   5ed16:	sub    rax,0x1
   5ed1a:	mov    QWORD PTR [rip+0x0],rax        # 5ed21 <sqlite3VdbeExec+0xf881>
   5ed21:	mov    rax,QWORD PTR [rip+0x0]        # 5ed28 <sqlite3VdbeExec+0xf888>
   5ed28:	mov    rdi,r12
   5ed2b:	mov    r10,rax
   5ed2e:	call   r10
   5ed31:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ed39:	jmp    5f5c3 <sqlite3VdbeExec+0x10123>
   5ed3e:	mov    eax,DWORD PTR [r15+0x34]
   5ed42:	mov    QWORD PTR [rsp+0xb0],rdi
   5ed4a:	mov    rdi,rax
   5ed4d:	call   5ed52 <sqlite3VdbeExec+0xf8b2>
   5ed52:	mov    QWORD PTR [rbx+0x68],rax
   5ed56:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ed5e:	cmp    QWORD PTR [rbx+0x68],0x0
   5ed63:	jne    5ed8b <sqlite3VdbeExec+0xf8eb>
   5ed65:	mov    DWORD PTR [rbx+0x24],0x7
   5ed6c:	mov    DWORD PTR [rbx+0x1c],0x0
   5ed73:	cmp    DWORD PTR [rbx+0x20],0x0
   5ed77:	jne    5ecb5 <sqlite3VdbeExec+0xf815>
   5ed7d:	mov    eax,DWORD PTR [rbx+0x20]
   5ed80:	add    eax,0x1
   5ed83:	mov    DWORD PTR [rbx+0x20],eax
   5ed86:	jmp    5ecb5 <sqlite3VdbeExec+0xf815>
   5ed8b:	mov    eax,DWORD PTR [rip+0x0]        # 5ed91 <sqlite3VdbeExec+0xf8f1>
   5ed91:	mov    ecx,DWORD PTR [r15+0x34]
   5ed95:	xor    edx,edx
   5ed97:	div    ecx
   5ed99:	add    eax,0x1
   5ed9c:	cmp    eax,DWORD PTR [rbx+0x18]
   5ed9f:	ja     5edcb <sqlite3VdbeExec+0xf92b>
   5eda1:	mov    rdx,QWORD PTR [rbx+0x10]
   5eda5:	mov    ecx,eax
   5eda7:	shr    ecx,0x3
   5edaa:	mov    rsi,rcx
   5edad:	movzx  ecx,BYTE PTR [rdx+rsi*1]
   5edb1:	mov    r8d,ecx
   5edb4:	mov    r9d,0x1
   5edba:	and    eax,0x7
   5edbd:	mov    ecx,eax
   5edbf:	mov    rax,r9
   5edc2:	shl    eax,cl
   5edc4:	or     r8d,eax
   5edc7:	mov    BYTE PTR [rdx+rsi*1],r8b
   5edcb:	test   r13d,r13d
   5edce:	je     5ee6d <sqlite3VdbeExec+0xf9cd>
   5edd4:	lea    rax,[rip+0x0]        # 5eddb <sqlite3VdbeExec+0xf93b>
   5eddb:	mov    QWORD PTR [rbx+0x30],rax
   5eddf:	mov    rax,rbx
   5ede2:	mov    ecx,0x1
   5ede7:	mov    rdx,QWORD PTR [r15+0x18]
   5edeb:	mov    rdx,QWORD PTR [rdx+0x50]
   5edef:	movzx  esi,BYTE PTR [rdx+0x20]
   5edf3:	shl    esi,0x18
   5edf6:	movzx  r8d,BYTE PTR [rdx+0x21]
   5edfb:	shl    r8d,0x10
   5edff:	or     esi,r8d
   5ee02:	movzx  r8d,BYTE PTR [rdx+0x22]
   5ee07:	shl    r8d,0x8
   5ee0b:	or     esi,r8d
   5ee0e:	movzx  edx,BYTE PTR [rdx+0x23]
   5ee12:	or     esi,edx
   5ee14:	mov    rdx,QWORD PTR [r15+0x18]
   5ee18:	mov    rdx,QWORD PTR [rdx+0x50]
   5ee1c:	movzx  r8d,BYTE PTR [rdx+0x24]
   5ee21:	shl    r8d,0x18
   5ee25:	movzx  r9d,BYTE PTR [rdx+0x25]
   5ee2a:	shl    r9d,0x10
   5ee2e:	or     r8d,r9d
   5ee31:	movzx  r9d,BYTE PTR [rdx+0x26]
   5ee36:	shl    r9d,0x8
   5ee3a:	or     r8d,r9d
   5ee3d:	movzx  edx,BYTE PTR [rdx+0x27]
   5ee41:	or     r8d,edx
   5ee44:	mov    QWORD PTR [rsp+0xb0],rdi
   5ee4c:	mov    rdi,rax
   5ee4f:	mov    rdx,rsi
   5ee52:	mov    rsi,rcx
   5ee55:	mov    rcx,r8
   5ee58:	call   5ee5d <sqlite3VdbeExec+0xf9bd>
   5ee5d:	mov    QWORD PTR [rbx+0x30],0x0
   5ee65:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ee6d:	mov    r13d,DWORD PTR [rsp+0x344]
   5ee75:	test   r13d,r13d
   5ee78:	jne    5ef7e <sqlite3VdbeExec+0xfade>
   5ee7e:	cmp    BYTE PTR [r15+0x21],0x0
   5ee83:	je     5ef29 <sqlite3VdbeExec+0xfa89>
   5ee89:	xor    eax,eax
   5ee8b:	xor    ecx,ecx
   5ee8d:	mov    r11,rax
   5ee90:	mov    rax,rcx
   5ee93:	mov    rcx,r11
   5ee96:	jmp    5eead <sqlite3VdbeExec+0xfa0d>
   5ee98:	mov    rdx,rax
   5ee9b:	cmp    ecx,DWORD PTR [r12+rdx*4+0x4]
   5eea0:	jae    5eeaa <sqlite3VdbeExec+0xfa0a>
   5eea2:	mov    rcx,rax
   5eea5:	mov    ecx,DWORD PTR [r12+rcx*4+0x4]
   5eeaa:	add    eax,0x1
   5eead:	mov    r14d,DWORD PTR [rsp+0x348]
   5eeb5:	cmp    eax,r14d
   5eeb8:	jl     5ee98 <sqlite3VdbeExec+0xf9f8>
   5eeba:	mov    rax,QWORD PTR [r15+0x18]
   5eebe:	mov    rax,QWORD PTR [rax+0x50]
   5eec2:	movzx  edx,BYTE PTR [rax+0x34]
   5eec6:	shl    edx,0x18
   5eec9:	movzx  esi,BYTE PTR [rax+0x35]
   5eecd:	shl    esi,0x10
   5eed0:	or     edx,esi
   5eed2:	movzx  esi,BYTE PTR [rax+0x36]
   5eed6:	shl    esi,0x8
   5eed9:	or     edx,esi
   5eedb:	movzx  eax,BYTE PTR [rax+0x37]
   5eedf:	or     edx,eax
   5eee1:	cmp    ecx,edx
   5eee3:	jne    5eef2 <sqlite3VdbeExec+0xfa52>
   5eee5:	mov    DWORD PTR [rsp+0x348],r14d
   5eeed:	jmp    5ef7e <sqlite3VdbeExec+0xfade>
   5eef2:	lea    r14,[rsp+0x298]
   5eefa:	mov    rax,r14
   5eefd:	lea    rsi,[rip+0x0]        # 5ef04 <sqlite3VdbeExec+0xfa64>
   5ef04:	mov    QWORD PTR [rsp+0xb0],rdi
   5ef0c:	mov    rdi,rax
   5ef0f:	mov    r11,rdx
   5ef12:	mov    rdx,rcx
   5ef15:	mov    rcx,r11
   5ef18:	xor    eax,eax
   5ef1a:	call   5ef1f <sqlite3VdbeExec+0xfa7f>
   5ef1f:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ef27:	jmp    5ef7e <sqlite3VdbeExec+0xfade>
   5ef29:	mov    r14,rbx
   5ef2c:	mov    rax,QWORD PTR [r15+0x18]
   5ef30:	mov    rax,QWORD PTR [rax+0x50]
   5ef34:	movzx  ecx,BYTE PTR [rax+0x40]
   5ef38:	shl    ecx,0x18
   5ef3b:	movzx  edx,BYTE PTR [rax+0x41]
   5ef3f:	shl    edx,0x10
   5ef42:	or     ecx,edx
   5ef44:	movzx  edx,BYTE PTR [rax+0x42]
   5ef48:	shl    edx,0x8
   5ef4b:	or     ecx,edx
   5ef4d:	movzx  eax,BYTE PTR [rax+0x43]
   5ef51:	or     ecx,eax
   5ef53:	test   ecx,ecx
   5ef55:	je     5ef7e <sqlite3VdbeExec+0xfade>
   5ef57:	mov    rax,r14
   5ef5a:	lea    rcx,[rip+0x0]        # 5ef61 <sqlite3VdbeExec+0xfac1>
   5ef61:	mov    QWORD PTR [rsp+0xb0],rdi
   5ef69:	mov    rdi,rax
   5ef6c:	mov    rsi,rcx
   5ef6f:	xor    eax,eax
   5ef71:	call   5ef76 <sqlite3VdbeExec+0xfad6>
   5ef76:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ef7e:	mov    rax,QWORD PTR [r15+0x8]
   5ef82:	mov    rcx,QWORD PTR [rax+0x30]
   5ef86:	and    rcx,0xffffffffffdfffff
   5ef8d:	mov    QWORD PTR [rax+0x30],rcx
   5ef91:	xor    r14d,r14d
   5ef94:	mov    QWORD PTR [rsp+0x120],r15
   5ef9c:	mov    r15,QWORD PTR [rsp+0x138]
   5efa4:	mov    DWORD PTR [rsp+0x344],r13d
   5efac:	mov    rbx,r14
   5efaf:	lea    r14,[rsp+0x298]
   5efb7:	jmp    5f0fe <sqlite3VdbeExec+0xfc5e>
   5efbc:	mov    rbp,QWORD PTR [rsp+0xe8]
   5efc4:	mov    r11,r15
   5efc7:	mov    r15,r13
   5efca:	mov    r13,r11
   5efcd:	mov    DWORD PTR [rsp+0x344],r13d
   5efd5:	lea    r13,[rsp+0x36c]
   5efdd:	cmp    BYTE PTR [r13+0x0],0x1
   5efe2:	jne    5effd <sqlite3VdbeExec+0xfb5d>
   5efe4:	lea    r13,[rsp+0x338]
   5efec:	cmp    DWORD PTR [r13+0x0],0x0
   5eff1:	jne    5effd <sqlite3VdbeExec+0xfb5d>
   5eff3:	mov    QWORD PTR [rsp+0x120],r15
   5effb:	jmp    5f05f <sqlite3VdbeExec+0xfbbf>
   5effd:	lea    rax,[rip+0x0]        # 5f004 <sqlite3VdbeExec+0xfb64>
   5f004:	mov    ecx,0x1
   5f009:	lea    r13,[rsp+0x36c]
   5f011:	movzx  edx,BYTE PTR [r13+0x0]
   5f016:	lea    r13,[rsp+0x338]
   5f01e:	mov    esi,DWORD PTR [r13+0x0]
   5f022:	mov    QWORD PTR [rsp+0x120],r15
   5f02a:	lea    r13,[rsp+0x298]
   5f032:	xor    r15d,r15d
   5f035:	mov    QWORD PTR [rsp],rsi
   5f039:	mov    QWORD PTR [rsp+0xb0],rdi
   5f041:	mov    rdi,r13
   5f044:	mov    rsi,rax
   5f047:	mov    r8,r15
   5f04a:	mov    r9,rdx
   5f04d:	mov    rdx,r14
   5f050:	xor    eax,eax
   5f052:	call   5f057 <sqlite3VdbeExec+0xfbb7>
   5f057:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f05f:	mov    rax,rbx
   5f062:	mov    ecx,DWORD PTR [r12+rax*4+0x4]
   5f067:	lea    r14,[rsp+0x298]
   5f06f:	mov    DWORD PTR [r14+0x38],ecx
   5f073:	mov    rcx,r14
   5f076:	mov    eax,DWORD PTR [r12+rax*4+0x4]
   5f07b:	lea    r13,[rsp+0x118]
   5f083:	mov    rdx,r13
   5f086:	movabs rsi,0x7fffffffffffffff
   5f090:	mov    QWORD PTR [rsp+0xb0],rdi
   5f098:	mov    rdi,rcx
   5f09b:	mov    rcx,rsi
   5f09e:	mov    rsi,rax
   5f0a1:	call   5f0a6 <sqlite3VdbeExec+0xfc06>
   5f0a6:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f0ae:	mov    rax,QWORD PTR [r14+0x78]
   5f0b2:	mov    rcx,rbx
   5f0b5:	imul   rcx,rcx,0x38
   5f0b9:	mov    r15,QWORD PTR [rsp+0x138]
   5f0c1:	lea    rdx,[r15+rcx*1]
   5f0c5:	movzx  ecx,WORD PTR [r15+rcx*1+0x14]
   5f0cb:	and    ecx,0x9000
   5f0d1:	test   ecx,ecx
   5f0d3:	je     5f0f2 <sqlite3VdbeExec+0xfc52>
   5f0d5:	mov    QWORD PTR [rsp+0xb0],rdi
   5f0dd:	mov    rdi,rdx
   5f0e0:	mov    rsi,rax
   5f0e3:	call   5f0e8 <sqlite3VdbeExec+0xfc48>
   5f0e8:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f0f0:	jmp    5f0fb <sqlite3VdbeExec+0xfc5b>
   5f0f2:	mov    QWORD PTR [rdx],rax
   5f0f5:	mov    WORD PTR [rdx+0x14],0x4
   5f0fb:	add    ebx,0x1
   5f0fe:	mov    r13d,DWORD PTR [rsp+0x348]
   5f106:	cmp    ebx,r13d
   5f109:	jl     5f128 <sqlite3VdbeExec+0xfc88>
   5f10b:	mov    r13,QWORD PTR [rsp+0x120]
   5f113:	mov    r15d,DWORD PTR [rsp+0x344]
   5f11b:	mov    QWORD PTR [rsp+0xe8],rbp
   5f123:	jmp    5f2b7 <sqlite3VdbeExec+0xfe17>
   5f128:	cmp    DWORD PTR [r14+0x1c],0x0
   5f12d:	jne    5f14c <sqlite3VdbeExec+0xfcac>
   5f12f:	mov    r13,QWORD PTR [rsp+0x120]
   5f137:	mov    r15d,DWORD PTR [rsp+0x344]
   5f13f:	mov    QWORD PTR [rsp+0xe8],rbp
   5f147:	jmp    5f2b7 <sqlite3VdbeExec+0xfe17>
   5f14c:	mov    QWORD PTR [r14+0x78],0x0
   5f154:	mov    rax,rbx
   5f157:	cmp    DWORD PTR [r12+rax*4+0x4],0x0
   5f15d:	jne    5f17c <sqlite3VdbeExec+0xfcdc>
   5f15f:	mov    DWORD PTR [rsp+0x348],r13d
   5f167:	mov    QWORD PTR [rsp+0x138],r15
   5f16f:	lea    r13,[rsp+0x118]
   5f177:	jmp    5f0ae <sqlite3VdbeExec+0xfc0e>
   5f17c:	mov    r13,QWORD PTR [rsp+0x120]
   5f184:	cmp    BYTE PTR [r13+0x21],0x0
   5f189:	jne    5f198 <sqlite3VdbeExec+0xfcf8>
   5f18b:	mov    QWORD PTR [rsp+0x138],r15
   5f193:	jmp    5f05f <sqlite3VdbeExec+0xfbbf>
   5f198:	mov    rax,rbx
   5f19b:	cmp    DWORD PTR [r12+rax*4+0x4],0x1
   5f1a1:	ja     5f1b8 <sqlite3VdbeExec+0xfd18>
   5f1a3:	mov    QWORD PTR [rsp+0x138],r15
   5f1ab:	mov    QWORD PTR [rsp+0x120],r13
   5f1b3:	jmp    5f05f <sqlite3VdbeExec+0xfbbf>
   5f1b8:	mov    QWORD PTR [rsp+0x138],r15
   5f1c0:	mov    r15d,DWORD PTR [rsp+0x344]
   5f1c8:	test   r15d,r15d
   5f1cb:	je     5f1da <sqlite3VdbeExec+0xfd3a>
   5f1cd:	mov    QWORD PTR [rsp+0x120],r13
   5f1d5:	jmp    5f05f <sqlite3VdbeExec+0xfbbf>
   5f1da:	mov    rax,rbx
   5f1dd:	mov    r14d,DWORD PTR [r12+rax*4+0x4]
   5f1e2:	mov    QWORD PTR [rsp+0xe8],rbp
   5f1ea:	lea    rbp,[rsp+0x298]
   5f1f2:	mov    rax,QWORD PTR [rbp+0x0]
   5f1f6:	lea    rbp,[rsp+0x36c]
   5f1fe:	mov    rcx,rbp
   5f201:	lea    rbp,[rsp+0x338]
   5f209:	mov    rdx,rbp
   5f20c:	mov    QWORD PTR [rsp+0xb0],rdi
   5f214:	mov    rdi,rax
   5f217:	mov    rsi,r14
   5f21a:	mov    r11,rdx
   5f21d:	mov    rdx,rcx
   5f220:	mov    rcx,r11
   5f223:	call   5f228 <sqlite3VdbeExec+0xfd88>
   5f228:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f230:	test   eax,eax
   5f232:	je     5efbc <sqlite3VdbeExec+0xfb1c>
   5f238:	cmp    eax,0x7
   5f23b:	je     5f24e <sqlite3VdbeExec+0xfdae>
   5f23d:	cmp    eax,0xc0a
   5f242:	je     5f24e <sqlite3VdbeExec+0xfdae>
   5f244:	lea    rbp,[rsp+0x298]
   5f24c:	jmp    5f273 <sqlite3VdbeExec+0xfdd3>
   5f24e:	lea    rbp,[rsp+0x298]
   5f256:	mov    DWORD PTR [rbp+0x24],0x7
   5f25d:	mov    DWORD PTR [rbp+0x1c],0x0
   5f264:	cmp    DWORD PTR [rbp+0x20],0x0
   5f268:	jne    5f273 <sqlite3VdbeExec+0xfdd3>
   5f26a:	mov    eax,DWORD PTR [rbp+0x20]
   5f26d:	add    eax,0x1
   5f270:	mov    DWORD PTR [rbp+0x20],eax
   5f273:	lea    rax,[rip+0x0]        # 5f27a <sqlite3VdbeExec+0xfdda>
   5f27a:	mov    QWORD PTR [rsp+0xb0],rdi
   5f282:	mov    rdi,rbp
   5f285:	mov    rsi,rax
   5f288:	mov    rdx,r14
   5f28b:	xor    eax,eax
   5f28d:	call   5f292 <sqlite3VdbeExec+0xfdf2>
   5f292:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f29a:	mov    QWORD PTR [rsp+0x120],r13
   5f2a2:	mov    DWORD PTR [rsp+0x344],r15d
   5f2aa:	mov    rbp,QWORD PTR [rsp+0xe8]
   5f2b2:	jmp    5f05f <sqlite3VdbeExec+0xfbbf>
   5f2b7:	mov    rax,QWORD PTR [r13+0x8]
   5f2bb:	mov    rbx,QWORD PTR [rsp+0x140]
   5f2c3:	mov    QWORD PTR [rax+0x30],rbx
   5f2c7:	test   r15d,r15d
   5f2ca:	je     5f2e1 <sqlite3VdbeExec+0xfe41>
   5f2cc:	mov    rbp,QWORD PTR [rsp+0xe8]
   5f2d4:	lea    rbx,[rsp+0x298]
   5f2dc:	jmp    5ecb5 <sqlite3VdbeExec+0xf815>
   5f2e1:	mov    ebx,0x1
   5f2e6:	mov    r14,QWORD PTR [rsp+0xc8]
   5f2ee:	mov    rbp,QWORD PTR [rsp+0xe8]
   5f2f6:	mov    r12,rbx
   5f2f9:	mov    rbx,QWORD PTR [rsp+0x100]
   5f301:	jmp    5f41f <sqlite3VdbeExec+0xff7f>
   5f306:	mov    QWORD PTR [rsp+0xc8],r14
   5f30e:	mov    r14,r12
   5f311:	mov    QWORD PTR [rsp+0xe8],rbp
   5f319:	mov    rbp,r15
   5f31c:	mov    QWORD PTR [rsp+0x100],rbx
   5f324:	mov    eax,DWORD PTR [r13+0x38]
   5f328:	mov    edx,0xcccccccd
   5f32d:	mul    edx
   5f32f:	shr    edx,0x2
   5f332:	mov    eax,edx
   5f334:	lea    ecx,[rax+0x1]
   5f337:	mov    eax,r14d
   5f33a:	sub    eax,0x2
   5f33d:	xor    edx,edx
   5f33f:	div    ecx
   5f341:	imul   eax,ecx
   5f344:	lea    ecx,[rax+0x2]
   5f347:	mov    eax,DWORD PTR [rip+0x0]        # 5f34d <sqlite3VdbeExec+0xfead>
   5f34d:	mov    esi,DWORD PTR [r13+0x34]
   5f351:	xor    edx,edx
   5f353:	div    esi
   5f355:	add    eax,0x1
   5f358:	xor    edx,edx
   5f35a:	mov    esi,0x1
   5f35f:	cmp    ecx,eax
   5f361:	cmove  edx,esi
   5f364:	lea    eax,[rcx+rdx*1]
   5f367:	cmp    eax,r14d
   5f36a:	jne    5f373 <sqlite3VdbeExec+0xfed3>
   5f36c:	cmp    BYTE PTR [r13+0x21],0x0
   5f371:	jne    5f39d <sqlite3VdbeExec+0xfefd>
   5f373:	mov    rax,rbp
   5f376:	lea    rcx,[rip+0x0]        # 5f37d <sqlite3VdbeExec+0xfedd>
   5f37d:	mov    QWORD PTR [rsp+0xb0],rdi
   5f385:	mov    rdi,rax
   5f388:	mov    rsi,rcx
   5f38b:	mov    rdx,r14
   5f38e:	xor    eax,eax
   5f390:	call   5f395 <sqlite3VdbeExec+0xfef5>
   5f395:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f39d:	mov    rax,QWORD PTR [rbp+0x10]
   5f3a1:	mov    ecx,r14d
   5f3a4:	shr    ecx,0x3
   5f3a7:	movzx  eax,BYTE PTR [rax+rcx*1]
   5f3ab:	mov    edx,0x1
   5f3b0:	mov    ecx,r14d
   5f3b3:	and    ecx,0x7
   5f3b6:	shl    edx,cl
   5f3b8:	and    eax,edx
   5f3ba:	test   eax,eax
   5f3bc:	je     5f400 <sqlite3VdbeExec+0xff60>
   5f3be:	cmp    r14d,0x2
   5f3c2:	jae    5f4ff <sqlite3VdbeExec+0x1005f>
   5f3c8:	xor    eax,eax
   5f3ca:	cmp    eax,r14d
   5f3cd:	jne    5f400 <sqlite3VdbeExec+0xff60>
   5f3cf:	cmp    BYTE PTR [r13+0x21],0x0
   5f3d4:	je     5f400 <sqlite3VdbeExec+0xff60>
   5f3d6:	mov    rax,rbp
   5f3d9:	lea    rcx,[rip+0x0]        # 5f3e0 <sqlite3VdbeExec+0xff40>
   5f3e0:	mov    QWORD PTR [rsp+0xb0],rdi
   5f3e8:	mov    rdi,rax
   5f3eb:	mov    rsi,rcx
   5f3ee:	mov    rdx,r14
   5f3f1:	xor    eax,eax
   5f3f3:	call   5f3f8 <sqlite3VdbeExec+0xff58>
   5f3f8:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f400:	add    r14d,0x1
   5f404:	mov    rbp,QWORD PTR [rsp+0xe8]
   5f40c:	mov    rbx,QWORD PTR [rsp+0x100]
   5f414:	mov    r12,r14
   5f417:	mov    r14,QWORD PTR [rsp+0xc8]
   5f41f:	lea    r15,[rsp+0x298]
   5f427:	cmp    r12d,DWORD PTR [r15+0x18]
   5f42b:	jbe    5f445 <sqlite3VdbeExec+0xffa5>
   5f42d:	mov    QWORD PTR [rsp+0xc8],r14
   5f435:	mov    QWORD PTR [rsp+0x100],rbx
   5f43d:	mov    rbx,r15
   5f440:	jmp    5ecb5 <sqlite3VdbeExec+0xf815>
   5f445:	cmp    DWORD PTR [r15+0x1c],0x0
   5f44a:	jne    5f464 <sqlite3VdbeExec+0xffc4>
   5f44c:	mov    QWORD PTR [rsp+0xc8],r14
   5f454:	mov    QWORD PTR [rsp+0x100],rbx
   5f45c:	mov    rbx,r15
   5f45f:	jmp    5ecb5 <sqlite3VdbeExec+0xf815>
   5f464:	mov    rax,QWORD PTR [r15+0x10]
   5f468:	mov    ecx,r12d
   5f46b:	shr    ecx,0x3
   5f46e:	movzx  eax,BYTE PTR [rax+rcx*1]
   5f472:	mov    edx,0x1
   5f477:	mov    ecx,r12d
   5f47a:	and    ecx,0x7
   5f47d:	shl    edx,cl
   5f47f:	and    eax,edx
   5f481:	test   eax,eax
   5f483:	je     5f4a8 <sqlite3VdbeExec+0x10008>
   5f485:	mov    QWORD PTR [rsp+0xc8],r14
   5f48d:	mov    r14,r12
   5f490:	mov    QWORD PTR [rsp+0xe8],rbp
   5f498:	mov    rbp,r15
   5f49b:	mov    QWORD PTR [rsp+0x100],rbx
   5f4a3:	jmp    5f39d <sqlite3VdbeExec+0xfefd>
   5f4a8:	cmp    r12d,0x2
   5f4ac:	jae    5f306 <sqlite3VdbeExec+0xfe66>
   5f4b2:	xor    eax,eax
   5f4b4:	cmp    eax,r12d
   5f4b7:	jne    5f4dc <sqlite3VdbeExec+0x1003c>
   5f4b9:	mov    QWORD PTR [rsp+0xc8],r14
   5f4c1:	mov    r14,r12
   5f4c4:	mov    QWORD PTR [rsp+0xe8],rbp
   5f4cc:	mov    rbp,r15
   5f4cf:	mov    QWORD PTR [rsp+0x100],rbx
   5f4d7:	jmp    5f36c <sqlite3VdbeExec+0xfecc>
   5f4dc:	mov    QWORD PTR [rsp+0xc8],r14
   5f4e4:	mov    r14,r12
   5f4e7:	mov    QWORD PTR [rsp+0xe8],rbp
   5f4ef:	mov    rbp,r15
   5f4f2:	mov    QWORD PTR [rsp+0x100],rbx
   5f4fa:	jmp    5f373 <sqlite3VdbeExec+0xfed3>
   5f4ff:	mov    r15,rbp
   5f502:	mov    r12,r14
   5f505:	mov    r14,QWORD PTR [rsp+0xc8]
   5f50d:	mov    rbp,QWORD PTR [rsp+0xe8]
   5f515:	mov    rbx,QWORD PTR [rsp+0x100]
   5f51d:	mov    eax,DWORD PTR [r13+0x38]
   5f521:	mov    edx,0xcccccccd
   5f526:	mul    edx
   5f528:	shr    edx,0x2
   5f52b:	mov    eax,edx
   5f52d:	lea    ecx,[rax+0x1]
   5f530:	mov    eax,r12d
   5f533:	sub    eax,0x2
   5f536:	xor    edx,edx
   5f538:	div    ecx
   5f53a:	imul   eax,ecx
   5f53d:	lea    ecx,[rax+0x2]
   5f540:	mov    eax,DWORD PTR [rip+0x0]        # 5f546 <sqlite3VdbeExec+0x100a6>
   5f546:	mov    esi,DWORD PTR [r13+0x34]
   5f54a:	xor    edx,edx
   5f54c:	div    esi
   5f54e:	add    eax,0x1
   5f551:	xor    edx,edx
   5f553:	mov    esi,0x1
   5f558:	cmp    ecx,eax
   5f55a:	cmove  edx,esi
   5f55d:	lea    eax,[rcx+rdx*1]
   5f560:	cmp    eax,r12d
   5f563:	je     5f588 <sqlite3VdbeExec+0x100e8>
   5f565:	mov    QWORD PTR [rsp+0xc8],r14
   5f56d:	mov    r14,r12
   5f570:	mov    QWORD PTR [rsp+0xe8],rbp
   5f578:	mov    rbp,r15
   5f57b:	mov    QWORD PTR [rsp+0x100],rbx
   5f583:	jmp    5f400 <sqlite3VdbeExec+0xff60>
   5f588:	mov    QWORD PTR [rsp+0xc8],r14
   5f590:	mov    r14,r12
   5f593:	mov    QWORD PTR [rsp+0xe8],rbp
   5f59b:	mov    rbp,r15
   5f59e:	mov    QWORD PTR [rsp+0x100],rbx
   5f5a6:	jmp    5f3cf <sqlite3VdbeExec+0xff2f>
   5f5ab:	mov    rax,QWORD PTR [rip+0x0]        # 5f5b2 <sqlite3VdbeExec+0x10112>
   5f5b2:	mov    rdi,r12
   5f5b5:	mov    r10,rax
   5f5b8:	call   r10
   5f5bb:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f5c3:	mov    eax,DWORD PTR [rbx+0x20]
   5f5c6:	mov    DWORD PTR [rsp+0x33c],eax
   5f5cd:	cmp    DWORD PTR [rbx+0x20],0x0
   5f5d1:	jne    5f63c <sqlite3VdbeExec+0x1019c>
   5f5d3:	movzx  eax,BYTE PTR [rbx+0x65]
   5f5d7:	and    eax,0x4
   5f5da:	test   eax,eax
   5f5dc:	je     5f610 <sqlite3VdbeExec+0x10170>
   5f5de:	mov    rax,QWORD PTR [rbx+0x48]
   5f5e2:	mov    rcx,QWORD PTR [rbx+0x50]
   5f5e6:	test   rcx,rcx
   5f5e9:	je     5f606 <sqlite3VdbeExec+0x10166>
   5f5eb:	mov    QWORD PTR [rsp+0xb0],rdi
   5f5f3:	mov    rdi,rax
   5f5f6:	mov    rsi,rcx
   5f5f9:	call   5f5fe <sqlite3VdbeExec+0x1015e>
   5f5fe:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f606:	movzx  eax,BYTE PTR [rbx+0x65]
   5f60a:	and    eax,0xfffffffb
   5f60d:	mov    BYTE PTR [rbx+0x65],al
   5f610:	mov    DWORD PTR [rbx+0x58],0x0
   5f617:	mov    DWORD PTR [rbx+0x60],0x0
   5f61e:	mov    QWORD PTR [rbx+0x50],0x0
   5f626:	mov    QWORD PTR [rsp+0x130],0x0
   5f632:	mov    r15,QWORD PTR [rsp+0x108]
   5f63a:	jmp    5f699 <sqlite3VdbeExec+0x101f9>
   5f63c:	lea    rax,[rbx+0x48]
   5f640:	cmp    QWORD PTR [rbx+0x50],0x0
   5f645:	je     5f685 <sqlite3VdbeExec+0x101e5>
   5f647:	mov    rcx,QWORD PTR [rax+0x8]
   5f64b:	mov    edx,DWORD PTR [rax+0x18]
   5f64e:	mov    BYTE PTR [rcx+rdx*1],0x0
   5f652:	cmp    DWORD PTR [rax+0x14],0x0
   5f656:	jbe    5f685 <sqlite3VdbeExec+0x101e5>
   5f658:	movzx  ecx,BYTE PTR [rax+0x1d]
   5f65c:	and    ecx,0x4
   5f65f:	test   ecx,ecx
   5f661:	jne    5f685 <sqlite3VdbeExec+0x101e5>
   5f663:	mov    QWORD PTR [rsp+0xb0],rdi
   5f66b:	mov    rdi,rax
   5f66e:	call   5f673 <sqlite3VdbeExec+0x101d3>
   5f673:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f67b:	mov    r15,QWORD PTR [rsp+0x108]
   5f683:	jmp    5f691 <sqlite3VdbeExec+0x101f1>
   5f685:	mov    rax,QWORD PTR [rax+0x8]
   5f689:	mov    r15,QWORD PTR [rsp+0x108]
   5f691:	mov    QWORD PTR [rsp+0x130],rax
   5f699:	mov    eax,DWORD PTR [rbx+0x24]
   5f69c:	mov    ebx,eax
   5f69e:	movzx  eax,WORD PTR [r15+0x14]
   5f6a3:	and    eax,0x9000
   5f6a8:	test   eax,eax
   5f6aa:	je     5f6c6 <sqlite3VdbeExec+0x10226>
   5f6ac:	mov    QWORD PTR [rsp+0xb0],rdi
   5f6b4:	mov    rdi,r15
   5f6b7:	call   5f6bc <sqlite3VdbeExec+0x1021c>
   5f6bc:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f6c4:	jmp    5f6cd <sqlite3VdbeExec+0x1022d>
   5f6c6:	mov    WORD PTR [r15+0x14],0x1
   5f6cd:	cmp    DWORD PTR [rsp+0x33c],0x0
   5f6d5:	jne    5f6e4 <sqlite3VdbeExec+0x10244>
   5f6d7:	mov    r12,QWORD PTR [rsp+0x100]
   5f6df:	jmp    5f80d <sqlite3VdbeExec+0x1036d>
   5f6e4:	test   ebx,ebx
   5f6e6:	je     5f7a6 <sqlite3VdbeExec+0x10306>
   5f6ec:	mov    r12,QWORD PTR [rsp+0x130]
   5f6f4:	test   r12,r12
   5f6f7:	je     5f77e <sqlite3VdbeExec+0x102de>
   5f6fd:	cmp    DWORD PTR [rip+0x0],0x0        # 5f704 <sqlite3VdbeExec+0x10264>
   5f704:	je     5f75e <sqlite3VdbeExec+0x102be>
   5f706:	mov    rax,QWORD PTR [rip+0x0]        # 5f70d <sqlite3VdbeExec+0x1026d>
   5f70d:	mov    QWORD PTR [rsp+0xb0],rdi
   5f715:	mov    rdi,r12
   5f718:	mov    r10,rax
   5f71b:	call   r10
   5f71e:	mov    rcx,QWORD PTR [rip+0x0]        # 5f725 <sqlite3VdbeExec+0x10285>
   5f725:	movsxd rax,eax
   5f728:	sub    rcx,rax
   5f72b:	mov    QWORD PTR [rip+0x0],rcx        # 5f732 <sqlite3VdbeExec+0x10292>
   5f732:	mov    rax,QWORD PTR [rip+0x0]        # 5f739 <sqlite3VdbeExec+0x10299>
   5f739:	sub    rax,0x1
   5f73d:	mov    QWORD PTR [rip+0x0],rax        # 5f744 <sqlite3VdbeExec+0x102a4>
   5f744:	mov    rax,QWORD PTR [rip+0x0]        # 5f74b <sqlite3VdbeExec+0x102ab>
   5f74b:	mov    rdi,r12
   5f74e:	mov    r10,rax
   5f751:	call   r10
   5f754:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f75c:	jmp    5f77e <sqlite3VdbeExec+0x102de>
   5f75e:	mov    rax,QWORD PTR [rip+0x0]        # 5f765 <sqlite3VdbeExec+0x102c5>
   5f765:	mov    QWORD PTR [rsp+0xb0],rdi
   5f76d:	mov    rdi,r12
   5f770:	mov    r10,rax
   5f773:	call   r10
   5f776:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f77e:	mov    r14,QWORD PTR [rsp+0xc8]
   5f786:	mov    QWORD PTR [rsp+0xe8],rbp
   5f78e:	mov    rbp,rbx
   5f791:	mov    r13,QWORD PTR [rsp+0xd0]
   5f799:	mov    rbx,QWORD PTR [rsp+0xf8]
   5f7a1:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5f7a6:	mov    r13,QWORD PTR [rsp+0x128]
   5f7ae:	mov    r12,QWORD PTR [rsp+0x100]
   5f7b6:	mov    rax,QWORD PTR [r12+r13*1]
   5f7ba:	mov    ecx,DWORD PTR [rsp+0x33c]
   5f7c1:	sub    ecx,0x1
   5f7c4:	movsxd rcx,ecx
   5f7c7:	sub    rax,rcx
   5f7ca:	mov    QWORD PTR [r12+r13*1],rax
   5f7ce:	mov    rax,QWORD PTR [rsp+0x130]
   5f7d6:	mov    rcx,0xffffffffffffffff
   5f7dd:	lea    rdx,[rip+0x0]        # 5f7e4 <sqlite3VdbeExec+0x10344>
   5f7e4:	mov    esi,0x1
   5f7e9:	mov    QWORD PTR [rsp+0xb0],rdi
   5f7f1:	mov    rdi,r15
   5f7f4:	mov    r8,rdx
   5f7f7:	mov    rdx,rcx
   5f7fa:	mov    rcx,rsi
   5f7fd:	mov    rsi,rax
   5f800:	call   5f805 <sqlite3VdbeExec+0x10365>
   5f805:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f80d:	mov    r13d,DWORD PTR [rsp+0x31c]
   5f815:	mov    eax,r13d
   5f818:	movzx  ecx,WORD PTR [r15+0x14]
   5f81d:	and    ecx,0x2
   5f820:	test   ecx,ecx
   5f822:	jne    5f82a <sqlite3VdbeExec+0x1038a>
   5f824:	mov    BYTE PTR [r15+0x16],al
   5f828:	jmp    5f850 <sqlite3VdbeExec+0x103b0>
   5f82a:	movzx  ecx,BYTE PTR [r15+0x16]
   5f82f:	cmp    ecx,eax
   5f831:	jne    5f835 <sqlite3VdbeExec+0x10395>
   5f833:	jmp    5f850 <sqlite3VdbeExec+0x103b0>
   5f835:	mov    QWORD PTR [rsp+0xb0],rdi
   5f83d:	mov    rdi,r15
   5f840:	mov    rsi,rax
   5f843:	call   5f848 <sqlite3VdbeExec+0x103a8>
   5f848:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f850:	mov    r14,QWORD PTR [rsp+0xc8]
   5f858:	mov    r15,r13
   5f85b:	mov    r13,QWORD PTR [rsp+0xf0]
   5f863:	mov    QWORD PTR [rsp+0xe8],rbp
   5f86b:	mov    DWORD PTR [rsp+0x32c],ebx
   5f872:	mov    ebx,DWORD PTR [rsp+0x330]
   5f879:	mov    QWORD PTR [rsp+0x100],r12
   5f881:	mov    r12d,DWORD PTR [rsp+0x334]
   5f889:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   5f88e:	mov    QWORD PTR [rsp+0xc8],r14
   5f896:	mov    r13d,DWORD PTR [rsp+0x31c]
   5f89e:	mov    QWORD PTR [rsp+0xd0],r12
   5f8a6:	mov    r12,rbx
   5f8a9:	mov    rax,QWORD PTR [rdi+0x78]
   5f8ad:	movsxd rcx,DWORD PTR [rbp+0x4]
   5f8b1:	mov    rbx,QWORD PTR [rax+rcx*8]
   5f8b5:	lea    r14,[rsp+0x188]
   5f8bd:	mov    rax,r14
   5f8c0:	xor    ecx,ecx
   5f8c2:	mov    edx,0x28
   5f8c7:	mov    QWORD PTR [rsp+0xb0],rdi
   5f8cf:	mov    rdi,rax
   5f8d2:	mov    rsi,rcx
   5f8d5:	call   5f8da <sqlite3VdbeExec+0x1043a>
   5f8da:	movsxd rax,DWORD PTR [rbp+0xc]
   5f8de:	imul   rax,rax,0x38
   5f8e2:	add    rax,r12
   5f8e5:	mov    QWORD PTR [rsp+0x190],rax
   5f8ed:	mov    rax,QWORD PTR [rbp+0x10]
   5f8f1:	movzx  eax,WORD PTR [rax+0x60]
   5f8f5:	mov    WORD PTR [rsp+0x1a4],ax
   5f8fd:	mov    rax,QWORD PTR [rbx+0x30]
   5f901:	mov    QWORD PTR [rsp+0x188],rax
   5f909:	mov    rax,QWORD PTR [rbx+0x28]
   5f90d:	mov    rcx,QWORD PTR [rbp+0x10]
   5f911:	mov    rdx,r14
   5f914:	lea    r15,[rsp+0x33c]
   5f91c:	mov    rsi,r15
   5f91f:	mov    r8d,0x1
   5f925:	mov    rdi,rax
   5f928:	mov    r11,rsi
   5f92b:	mov    rsi,rcx
   5f92e:	mov    rcx,r11
   5f931:	call   5f936 <sqlite3VdbeExec+0x10496>
   5f936:	mov    r15d,eax
   5f939:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f941:	test   r15d,r15d
   5f944:	jne    5f950 <sqlite3VdbeExec+0x104b0>
   5f946:	cmp    DWORD PTR [rsp+0x33c],0x0
   5f94e:	je     5f96e <sqlite3VdbeExec+0x104ce>
   5f950:	mov    r15,r13
   5f953:	mov    rbx,r12
   5f956:	mov    r12,QWORD PTR [rsp+0xc8]
   5f95e:	xor    r11d,r11d
   5f961:	mov    DWORD PTR [rsp+0x32c],r11d
   5f969:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   5f96e:	mov    BYTE PTR [rbx+0x2],0x0
   5f972:	mov    r14,QWORD PTR [rsp+0xc8]
   5f97a:	mov    DWORD PTR [rsp+0x31c],r13d
   5f982:	mov    DWORD PTR [rsp+0x32c],r15d
   5f98a:	mov    rbx,r12
   5f98d:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5f992:	mov    r15d,DWORD PTR [rsp+0x31c]
   5f99a:	mov    r13,QWORD PTR [rsp+0xf0]
   5f9a2:	mov    QWORD PTR [rsp+0xd0],r12
   5f9aa:	mov    r12d,DWORD PTR [rsp+0x334]
   5f9b2:	movsxd rax,DWORD PTR [rbp+0x4]
   5f9b6:	imul   rax,rax,0x38
   5f9ba:	mov    QWORD PTR [rsp+0xf0],r13
   5f9c2:	lea    r13,[rbx+rax*1]
   5f9c6:	movsxd rcx,DWORD PTR [rbp+0x8]
   5f9ca:	mov    QWORD PTR [rsp+0xc8],r14
   5f9d2:	imul   r14,rcx,0x38
   5f9d6:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5f9db:	and    eax,0x10
   5f9de:	test   eax,eax
   5f9e0:	jne    5fa1e <sqlite3VdbeExec+0x1057e>
   5f9e2:	mov    QWORD PTR [rsp+0xb0],rdi
   5f9ea:	mov    rdi,r13
   5f9ed:	call   5f9f2 <sqlite3VdbeExec+0x10552>
   5f9f2:	mov    rdi,QWORD PTR [rsp+0xb0]
   5f9fa:	test   eax,eax
   5f9fc:	je     5fa1e <sqlite3VdbeExec+0x1057e>
   5f9fe:	mov    r14,QWORD PTR [rsp+0xc8]
   5fa06:	mov    r13,QWORD PTR [rsp+0xf0]
   5fa0e:	mov    rbx,rbp
   5fa11:	mov    rbp,QWORD PTR [rsp+0xf8]
   5fa19:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5fa1e:	mov    r13,QWORD PTR [r13+0x8]
   5fa22:	mov    r14,QWORD PTR [rbx+r14*1]
   5fa26:	cmp    WORD PTR [r13+0x30],0x0
   5fa2c:	jne    5fa75 <sqlite3VdbeExec+0x105d5>
   5fa2e:	mov    rax,QWORD PTR [r13+0x8]
   5fa32:	mov    ecx,0x3f8
   5fa37:	mov    QWORD PTR [rsp+0xb0],rdi
   5fa3f:	mov    rdi,rax
   5fa42:	mov    rsi,rcx
   5fa45:	call   5fa4a <sqlite3VdbeExec+0x105aa>
   5fa4a:	mov    rdi,QWORD PTR [rsp+0xb0]
   5fa52:	test   rax,rax
   5fa55:	jne    5fa5b <sqlite3VdbeExec+0x105bb>
   5fa57:	xor    eax,eax
   5fa59:	jmp    5fa8e <sqlite3VdbeExec+0x105ee>
   5fa5b:	mov    rcx,QWORD PTR [r13+0x0]
   5fa5f:	mov    QWORD PTR [rax],rcx
   5fa62:	mov    QWORD PTR [r13+0x0],rax
   5fa66:	add    rax,0x8
   5fa6a:	mov    QWORD PTR [r13+0x20],rax
   5fa6e:	mov    WORD PTR [r13+0x30],0x2a
   5fa75:	movzx  eax,WORD PTR [r13+0x30]
   5fa7a:	sub    eax,0x1
   5fa7d:	mov    WORD PTR [r13+0x30],ax
   5fa82:	mov    rax,QWORD PTR [r13+0x20]
   5fa86:	lea    rcx,[rax+0x18]
   5fa8a:	mov    QWORD PTR [r13+0x20],rcx
   5fa8e:	test   rax,rax
   5fa91:	je     5fac7 <sqlite3VdbeExec+0x10627>
   5fa93:	mov    QWORD PTR [rax],r14
   5fa96:	mov    QWORD PTR [rax+0x8],0x0
   5fa9e:	mov    rcx,QWORD PTR [r13+0x18]
   5faa2:	test   rcx,rcx
   5faa5:	je     5fabf <sqlite3VdbeExec+0x1061f>
   5faa7:	cmp    r14,QWORD PTR [rcx]
   5faaa:	jg     5fab9 <sqlite3VdbeExec+0x10619>
   5faac:	movzx  edx,WORD PTR [r13+0x32]
   5fab1:	and    edx,0xfffffffe
   5fab4:	mov    WORD PTR [r13+0x32],dx
   5fab9:	mov    QWORD PTR [rcx+0x8],rax
   5fabd:	jmp    5fac3 <sqlite3VdbeExec+0x10623>
   5fabf:	mov    QWORD PTR [r13+0x10],rax
   5fac3:	mov    QWORD PTR [r13+0x18],rax
   5fac7:	mov    r14,QWORD PTR [rsp+0xc8]
   5facf:	mov    DWORD PTR [rsp+0x31c],r15d
   5fad7:	mov    DWORD PTR [rsp+0x334],r12d
   5fadf:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   5fae4:	mov    QWORD PTR [rsp+0xc8],r14
   5faec:	mov    r15d,DWORD PTR [rsp+0x31c]
   5faf4:	mov    QWORD PTR [rsp+0xd0],r12
   5fafc:	mov    r12d,DWORD PTR [rsp+0x334]
   5fb04:	movsxd rax,DWORD PTR [rbp+0x4]
   5fb08:	imul   rax,rax,0x38
   5fb0c:	lea    r13,[rbx+rax*1]
   5fb10:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5fb15:	and    eax,0x10
   5fb18:	test   eax,eax
   5fb1a:	je     5fc47 <sqlite3VdbeExec+0x107a7>
   5fb20:	mov    r14,QWORD PTR [r13+0x8]
   5fb24:	movzx  eax,WORD PTR [r14+0x32]
   5fb29:	and    eax,0x2
   5fb2c:	test   eax,eax
   5fb2e:	jne    5fb69 <sqlite3VdbeExec+0x106c9>
   5fb30:	movzx  eax,WORD PTR [r14+0x32]
   5fb35:	and    eax,0x1
   5fb38:	test   eax,eax
   5fb3a:	jne    5fb5c <sqlite3VdbeExec+0x106bc>
   5fb3c:	mov    rax,QWORD PTR [r14+0x10]
   5fb40:	mov    QWORD PTR [rsp+0xb0],rdi
   5fb48:	mov    rdi,rax
   5fb4b:	call   5fb50 <sqlite3VdbeExec+0x106b0>
   5fb50:	mov    QWORD PTR [r14+0x10],rax
   5fb54:	mov    rdi,QWORD PTR [rsp+0xb0]
   5fb5c:	movzx  eax,WORD PTR [r14+0x32]
   5fb61:	or     eax,0x3
   5fb64:	mov    WORD PTR [r14+0x32],ax
   5fb69:	cmp    QWORD PTR [r14+0x10],0x0
   5fb6e:	je     5fc47 <sqlite3VdbeExec+0x107a7>
   5fb74:	mov    rax,QWORD PTR [r14+0x10]
   5fb78:	mov    rax,QWORD PTR [rax]
   5fb7b:	mov    QWORD PTR [rsp+0x130],rax
   5fb83:	mov    rax,QWORD PTR [r14+0x10]
   5fb87:	mov    rax,QWORD PTR [rax+0x8]
   5fb8b:	mov    QWORD PTR [r14+0x10],rax
   5fb8f:	cmp    QWORD PTR [r14+0x10],0x0
   5fb94:	jne    5fc08 <sqlite3VdbeExec+0x10768>
   5fb96:	mov    r13,QWORD PTR [r14]
   5fb99:	jmp    5fbd6 <sqlite3VdbeExec+0x10736>
   5fb9b:	mov    DWORD PTR [rsp+0x334],r12d
   5fba3:	mov    r12,QWORD PTR [r13+0x0]
   5fba7:	mov    rax,QWORD PTR [r14+0x8]
   5fbab:	test   r13,r13
   5fbae:	je     5fbcb <sqlite3VdbeExec+0x1072b>
   5fbb0:	mov    QWORD PTR [rsp+0xb0],rdi
   5fbb8:	mov    rdi,rax
   5fbbb:	mov    rsi,r13
   5fbbe:	call   5fbc3 <sqlite3VdbeExec+0x10723>
   5fbc3:	mov    rdi,QWORD PTR [rsp+0xb0]
   5fbcb:	mov    r13,r12
   5fbce:	mov    r12d,DWORD PTR [rsp+0x334]
   5fbd6:	test   r13,r13
   5fbd9:	jne    5fb9b <sqlite3VdbeExec+0x106fb>
   5fbdb:	mov    QWORD PTR [r14],0x0
   5fbe2:	mov    WORD PTR [r14+0x30],0x0
   5fbe9:	mov    QWORD PTR [r14+0x10],0x0
   5fbf1:	mov    QWORD PTR [r14+0x18],0x0
   5fbf9:	mov    QWORD PTR [r14+0x28],0x0
   5fc01:	mov    WORD PTR [r14+0x32],0x1
   5fc08:	movsxd rax,DWORD PTR [rbp+0xc]
   5fc0c:	imul   rax,rax,0x38
   5fc10:	lea    rcx,[rbx+rax*1]
   5fc14:	mov    rdx,QWORD PTR [rsp+0x130]
   5fc1c:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5fc21:	and    eax,0x9000
   5fc26:	test   eax,eax
   5fc28:	je     5fc8b <sqlite3VdbeExec+0x107eb>
   5fc2a:	mov    QWORD PTR [rsp+0xb0],rdi
   5fc32:	mov    rdi,rcx
   5fc35:	mov    rsi,rdx
   5fc38:	call   5fc3d <sqlite3VdbeExec+0x1079d>
   5fc3d:	mov    rdi,QWORD PTR [rsp+0xb0]
   5fc45:	jmp    5fc94 <sqlite3VdbeExec+0x107f4>
   5fc47:	movzx  eax,WORD PTR [r13+0x14]
   5fc4c:	and    eax,0x9000
   5fc51:	test   eax,eax
   5fc53:	je     5fc6f <sqlite3VdbeExec+0x107cf>
   5fc55:	mov    QWORD PTR [rsp+0xb0],rdi
   5fc5d:	mov    rdi,r13
   5fc60:	call   5fc65 <sqlite3VdbeExec+0x107c5>
   5fc65:	mov    rdi,QWORD PTR [rsp+0xb0]
   5fc6d:	jmp    5fc76 <sqlite3VdbeExec+0x107d6>
   5fc6f:	mov    WORD PTR [r13+0x14],0x1
   5fc76:	mov    r14,QWORD PTR [rsp+0xc8]
   5fc7e:	mov    r13,QWORD PTR [rsp+0xf0]
   5fc86:	jmp    4f7bd <sqlite3VdbeExec+0x31d>
   5fc8b:	mov    QWORD PTR [rcx],rdx
   5fc8e:	mov    WORD PTR [rcx+0x14],0x4
   5fc94:	mov    r14,QWORD PTR [rsp+0xc8]
   5fc9c:	mov    r13,QWORD PTR [rsp+0xf0]
   5fca4:	mov    QWORD PTR [rsp+0xe8],rbp
   5fcac:	mov    QWORD PTR [rsp+0x100],rbx
   5fcb4:	mov    ebx,DWORD PTR [rsp+0x330]
   5fcbb:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   5fcc0:	mov    QWORD PTR [rsp+0xc8],r14
   5fcc8:	mov    r15d,DWORD PTR [rsp+0x31c]
   5fcd0:	mov    QWORD PTR [rsp+0xd0],r12
   5fcd8:	mov    r12d,DWORD PTR [rsp+0x334]
   5fce0:	movsxd rax,DWORD PTR [rbp+0x4]
   5fce4:	imul   rax,rax,0x38
   5fce8:	lea    r13,[rbx+rax*1]
   5fcec:	movsxd rcx,DWORD PTR [rbp+0xc]
   5fcf0:	imul   r14,rcx,0x38
   5fcf4:	mov    QWORD PTR [rsp+0xe8],rbp
   5fcfc:	mov    ebp,DWORD PTR [rbp+0x10]
   5fcff:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5fd04:	and    eax,0x10
   5fd07:	test   eax,eax
   5fd09:	jne    5fd4c <sqlite3VdbeExec+0x108ac>
   5fd0b:	mov    QWORD PTR [rsp+0xb0],rdi
   5fd13:	mov    rdi,r13
   5fd16:	call   5fd1b <sqlite3VdbeExec+0x1087b>
   5fd1b:	mov    rdi,QWORD PTR [rsp+0xb0]
   5fd23:	test   eax,eax
   5fd25:	je     5fd4c <sqlite3VdbeExec+0x108ac>
   5fd27:	mov    r14,QWORD PTR [rsp+0xc8]
   5fd2f:	mov    r13,QWORD PTR [rsp+0xf0]
   5fd37:	mov    rbx,QWORD PTR [rsp+0xe8]
   5fd3f:	mov    rbp,QWORD PTR [rsp+0xf8]
   5fd47:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5fd4c:	test   ebp,ebp
   5fd4e:	jne    5fd5d <sqlite3VdbeExec+0x108bd>
   5fd50:	mov    DWORD PTR [rsp+0x334],r12d
   5fd58:	jmp    6020d <sqlite3VdbeExec+0x10d6d>
   5fd5d:	mov    DWORD PTR [rsp+0x334],r12d
   5fd65:	mov    r12,QWORD PTR [r13+0x8]
   5fd69:	mov    QWORD PTR [rsp+0x108],r14
   5fd71:	mov    r14,QWORD PTR [rbx+r14*1]
   5fd75:	lea    r8,[rsp+0x150]
   5fd7d:	lea    r9,[rsp+0x158]
   5fd85:	cmp    ebp,DWORD PTR [r12+0x34]
   5fd8a:	jne    5fda1 <sqlite3VdbeExec+0x10901>
   5fd8c:	mov    QWORD PTR [rsp+0x130],r13
   5fd94:	mov    QWORD PTR [rsp+0x120],r14
   5fd9c:	jmp    6019a <sqlite3VdbeExec+0x10cfa>
   5fda1:	mov    QWORD PTR [rsp+0x120],r14
   5fda9:	mov    r14,QWORD PTR [r12+0x10]
   5fdae:	test   r14,r14
   5fdb1:	jne    5fdc7 <sqlite3VdbeExec+0x10927>
   5fdb3:	mov    QWORD PTR [rsp+0x130],r13
   5fdbb:	mov    DWORD PTR [rsp+0x33c],ebp
   5fdc2:	jmp    6018e <sqlite3VdbeExec+0x10cee>
   5fdc7:	mov    QWORD PTR [rsp+0x130],r13
   5fdcf:	lea    r13,[r12+0x28]
   5fdd4:	movzx  eax,WORD PTR [r12+0x32]
   5fdda:	and    eax,0x1
   5fddd:	test   eax,eax
   5fddf:	jne    5fe0c <sqlite3VdbeExec+0x1096c>
   5fde1:	mov    QWORD PTR [rsp+0xb0],rdi
   5fde9:	mov    rdi,r14
   5fdec:	call   5fdf1 <sqlite3VdbeExec+0x10951>
   5fdf1:	mov    r14,rax
   5fdf4:	mov    rdi,QWORD PTR [rsp+0xb0]
   5fdfc:	lea    r8,[rsp+0x150]
   5fe04:	lea    r9,[rsp+0x158]
   5fe0c:	mov    QWORD PTR [rsp+0x140],r14
   5fe14:	mov    r14,QWORD PTR [r12+0x28]
   5fe19:	mov    DWORD PTR [rsp+0x33c],ebp
   5fe20:	mov    rbp,r14
   5fe23:	mov    r14,QWORD PTR [rsp+0x140]
   5fe2b:	mov    QWORD PTR [rsp+0x118],r13
   5fe33:	jmp    5ffbc <sqlite3VdbeExec+0x10b1c>
   5fe38:	mov    QWORD PTR [rsp+0x138],rbp
   5fe40:	mov    rbp,QWORD PTR [r8]
   5fe43:	mov    rax,QWORD PTR [rbp+0x8]
   5fe47:	mov    QWORD PTR [r8],rax
   5fe4a:	mov    QWORD PTR [rbp+0x10],r13
   5fe4e:	mov    rax,r8
   5fe51:	mov    QWORD PTR [rsp+0xb0],rdi
   5fe59:	mov    rdi,rax
   5fe5c:	mov    rsi,r14
   5fe5f:	call   5fe64 <sqlite3VdbeExec+0x109c4>
   5fe64:	mov    QWORD PTR [rbp+0x8],rax
   5fe68:	add    r14d,0x1
   5fe6c:	mov    rdi,QWORD PTR [rsp+0xb0]
   5fe74:	mov    r13,rbp
   5fe77:	mov    rbp,QWORD PTR [rsp+0x138]
   5fe7f:	lea    r8,[rsp+0x148]
   5fe87:	cmp    QWORD PTR [r8],0x0
   5fe8b:	jne    5fe38 <sqlite3VdbeExec+0x10998>
   5fe8d:	mov    rax,r13
   5fe90:	mov    r13,QWORD PTR [rsp+0x110]
   5fe98:	mov    QWORD PTR [r13+0x0],rax
   5fe9c:	test   rbp,rbp
   5fe9f:	jne    6016d <sqlite3VdbeExec+0x10ccd>
   5fea5:	cmp    WORD PTR [r12+0x30],0x0
   5feac:	jne    60083 <sqlite3VdbeExec+0x10be3>
   5feb2:	mov    rax,QWORD PTR [r12+0x8]
   5feb7:	mov    ecx,0x3f8
   5febc:	mov    QWORD PTR [rsp+0xb0],rdi
   5fec4:	mov    rdi,rax
   5fec7:	mov    rsi,rcx
   5feca:	call   5fecf <sqlite3VdbeExec+0x10a2f>
   5fecf:	mov    rdi,QWORD PTR [rsp+0xb0]
   5fed7:	test   rax,rax
   5feda:	jne    60067 <sqlite3VdbeExec+0x10bc7>
   5fee0:	xor    ebp,ebp
   5fee2:	jmp    600a0 <sqlite3VdbeExec+0x10c00>
   5fee7:	mov    QWORD PTR [rsp+0x140],r14
   5feef:	mov    QWORD PTR [rsp+0x118],r13
   5fef7:	mov    rax,QWORD PTR [rbp+0x10]
   5fefb:	mov    rcx,r8
   5fefe:	mov    rdx,r9
   5ff01:	mov    QWORD PTR [rsp+0xb0],rdi
   5ff09:	mov    rdi,rax
   5ff0c:	mov    rsi,rcx
   5ff0f:	call   5ff14 <sqlite3VdbeExec+0x10a74>
   5ff14:	mov    QWORD PTR [rbp+0x10],0x0
   5ff1c:	lea    r8,[rsp+0x150]
   5ff24:	mov    r14,QWORD PTR [r8]
   5ff27:	lea    rax,[rsp+0x170]
   5ff2f:	mov    r13,rax
   5ff32:	mov    rdi,QWORD PTR [rsp+0xb0]
   5ff3a:	mov    QWORD PTR [rsp+0x128],r12
   5ff42:	mov    r12,r13
   5ff45:	mov    r13,r14
   5ff48:	mov    r14,QWORD PTR [rsp+0x140]
   5ff50:	lea    r9,[rsp+0x158]
   5ff58:	jmp    5ff7a <sqlite3VdbeExec+0x10ada>
   5ff5a:	mov    QWORD PTR [rsp+0x168],r12
   5ff62:	mov    r12,QWORD PTR [rsp+0x128]
   5ff6a:	mov    QWORD PTR [rsp+0x128],r12
   5ff72:	mov    r12,QWORD PTR [rsp+0x168]
   5ff7a:	mov    rcx,QWORD PTR [r13+0x0]
   5ff7e:	cmp    rcx,QWORD PTR [r14]
   5ff81:	jg     60038 <sqlite3VdbeExec+0x10b98>
   5ff87:	mov    rcx,QWORD PTR [r13+0x0]
   5ff8b:	cmp    rcx,QWORD PTR [r14]
   5ff8e:	jge    5ff98 <sqlite3VdbeExec+0x10af8>
   5ff90:	mov    QWORD PTR [r12+0x8],r13
   5ff95:	mov    r12,r13
   5ff98:	mov    r13,QWORD PTR [r13+0x8]
   5ff9c:	test   r13,r13
   5ff9f:	jne    5ff5a <sqlite3VdbeExec+0x10aba>
   5ffa1:	mov    QWORD PTR [r12+0x8],r14
   5ffa6:	mov    rax,QWORD PTR [rax+0x8]
   5ffaa:	mov    r12,rax
   5ffad:	mov    rbp,QWORD PTR [rbp+0x8]
   5ffb1:	mov    r14,r12
   5ffb4:	mov    r12,QWORD PTR [rsp+0x128]
   5ffbc:	test   rbp,rbp
   5ffbf:	jne    5ffce <sqlite3VdbeExec+0x10b2e>
   5ffc1:	mov    QWORD PTR [rsp+0x140],r14
   5ffc9:	jmp    5fe9c <sqlite3VdbeExec+0x109fc>
   5ffce:	lea    r13,[rbp+0x8]
   5ffd2:	cmp    QWORD PTR [rbp+0x10],0x0
   5ffd7:	jne    5fee7 <sqlite3VdbeExec+0x10a47>
   5ffdd:	mov    QWORD PTR [rsp+0x118],r13
   5ffe5:	lea    r13,[rbp+0x10]
   5ffe9:	lea    r8,[rsp+0x148]
   5fff1:	mov    QWORD PTR [rsp+0x148],r14
   5fff9:	mov    QWORD PTR [rsp+0x110],r13
   60001:	mov    r13,QWORD PTR [rsp+0x148]
   60009:	mov    rax,QWORD PTR [r13+0x8]
   6000d:	mov    QWORD PTR [rsp+0x148],rax
   60015:	mov    QWORD PTR [r13+0x8],0x0
   6001d:	mov    QWORD PTR [r13+0x10],0x0
   60025:	mov    QWORD PTR [rsp+0x140],r14
   6002d:	mov    r14d,0x1
   60033:	jmp    5fe87 <sqlite3VdbeExec+0x109e7>
   60038:	mov    QWORD PTR [r12+0x8],r14
   6003d:	mov    r12,QWORD PTR [r14+0x8]
   60041:	test   r12,r12
   60044:	je     6005e <sqlite3VdbeExec+0x10bbe>
   60046:	mov    QWORD PTR [rsp+0x168],r14
   6004e:	mov    r14,r12
   60051:	mov    r12,QWORD PTR [rsp+0x128]
   60059:	jmp    5ff6a <sqlite3VdbeExec+0x10aca>
   6005e:	mov    QWORD PTR [r14+0x8],r13
   60062:	jmp    5ffa6 <sqlite3VdbeExec+0x10b06>
   60067:	mov    rcx,QWORD PTR [r12]
   6006b:	mov    QWORD PTR [rax],rcx
   6006e:	mov    QWORD PTR [r12],rax
   60072:	add    rax,0x8
   60076:	mov    QWORD PTR [r12+0x20],rax
   6007b:	mov    WORD PTR [r12+0x30],0x2a
   60083:	movzx  eax,WORD PTR [r12+0x30]
   60089:	sub    eax,0x1
   6008c:	mov    WORD PTR [r12+0x30],ax
   60092:	mov    rbp,QWORD PTR [r12+0x20]
   60097:	lea    rax,[rbp+0x18]
   6009b:	mov    QWORD PTR [r12+0x20],rax
   600a0:	mov    r14,QWORD PTR [rsp+0x118]
   600a8:	mov    QWORD PTR [r14],rbp
   600ab:	test   rbp,rbp
   600ae:	je     6016d <sqlite3VdbeExec+0x10ccd>
   600b4:	mov    QWORD PTR [rbp+0x0],0x0
   600bc:	mov    QWORD PTR [rbp+0x8],0x0
   600c4:	lea    r8,[rsp+0x118]
   600cc:	mov    r14,QWORD PTR [rsp+0x140]
   600d4:	mov    QWORD PTR [rsp+0x118],r14
   600dc:	mov    r14,QWORD PTR [rsp+0x118]
   600e4:	mov    rax,QWORD PTR [r14+0x8]
   600e8:	mov    QWORD PTR [rsp+0x118],rax
   600f0:	mov    QWORD PTR [r14+0x8],0x0
   600f8:	mov    QWORD PTR [r14+0x10],0x0
   60100:	mov    r13d,0x1
   60106:	mov    r11,r14
   60109:	mov    r14,r13
   6010c:	mov    r13,r11
   6010f:	jmp    60160 <sqlite3VdbeExec+0x10cc0>
   60111:	mov    QWORD PTR [rsp+0x160],rbp
   60119:	mov    rbp,QWORD PTR [r8]
   6011c:	mov    rax,QWORD PTR [rbp+0x8]
   60120:	mov    QWORD PTR [r8],rax
   60123:	mov    QWORD PTR [rbp+0x10],r13
   60127:	mov    rax,r8
   6012a:	mov    QWORD PTR [rsp+0xb0],rdi
   60132:	mov    rdi,rax
   60135:	mov    rsi,r14
   60138:	call   6013d <sqlite3VdbeExec+0x10c9d>
   6013d:	mov    QWORD PTR [rbp+0x8],rax
   60141:	add    r14d,0x1
   60145:	mov    rdi,QWORD PTR [rsp+0xb0]
   6014d:	mov    r13,rbp
   60150:	mov    rbp,QWORD PTR [rsp+0x160]
   60158:	lea    r8,[rsp+0x118]
   60160:	cmp    QWORD PTR [r8],0x0
   60164:	jne    60111 <sqlite3VdbeExec+0x10c71>
   60166:	mov    rax,r13
   60169:	mov    QWORD PTR [rbp+0x10],rax
   6016d:	mov    QWORD PTR [r12+0x10],0x0
   60176:	mov    QWORD PTR [r12+0x18],0x0
   6017f:	movzx  eax,WORD PTR [r12+0x32]
   60185:	or     eax,0x1
   60188:	mov    WORD PTR [r12+0x32],ax
   6018e:	mov    ebp,DWORD PTR [rsp+0x33c]
   60195:	mov    DWORD PTR [r12+0x34],ebp
   6019a:	mov    rax,QWORD PTR [r12+0x28]
   6019f:	mov    r14,QWORD PTR [rsp+0x120]
   601a7:	mov    rcx,rax
   601aa:	jmp    601db <sqlite3VdbeExec+0x10d3b>
   601ac:	mov    QWORD PTR [rsp+0x120],r14
   601b4:	mov    r14,QWORD PTR [rsp+0x120]
   601bc:	cmp    r14,QWORD PTR [rax]
   601bf:	jle    601cc <sqlite3VdbeExec+0x10d2c>
   601c1:	mov    rax,QWORD PTR [rax+0x8]
   601c5:	test   rax,rax
   601c8:	jne    601ac <sqlite3VdbeExec+0x10d0c>
   601ca:	jmp    601d7 <sqlite3VdbeExec+0x10d37>
   601cc:	cmp    r14,QWORD PTR [rax]
   601cf:	jge    601f8 <sqlite3VdbeExec+0x10d58>
   601d1:	mov    rax,QWORD PTR [rax+0x10]
   601d5:	jmp    601c5 <sqlite3VdbeExec+0x10d25>
   601d7:	mov    rcx,QWORD PTR [rcx+0x8]
   601db:	test   rcx,rcx
   601de:	jne    601f2 <sqlite3VdbeExec+0x10d52>
   601e0:	mov    r13,QWORD PTR [rsp+0x130]
   601e8:	mov    r14,QWORD PTR [rsp+0x108]
   601f0:	jmp    6020d <sqlite3VdbeExec+0x10d6d>
   601f2:	mov    rax,QWORD PTR [rcx+0x10]
   601f6:	jmp    601c5 <sqlite3VdbeExec+0x10d25>
   601f8:	mov    r12,QWORD PTR [rsp+0xc8]
   60200:	mov    rbp,QWORD PTR [rsp+0xe8]
   60208:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   6020d:	test   ebp,ebp
   6020f:	jl     602b8 <sqlite3VdbeExec+0x10e18>
   60215:	mov    rbp,QWORD PTR [r13+0x8]
   60219:	mov    r12,QWORD PTR [rbx+r14*1]
   6021d:	cmp    WORD PTR [rbp+0x30],0x0
   60222:	jne    6026a <sqlite3VdbeExec+0x10dca>
   60224:	mov    rax,QWORD PTR [rbp+0x8]
   60228:	mov    ecx,0x3f8
   6022d:	mov    QWORD PTR [rsp+0xb0],rdi
   60235:	mov    rdi,rax
   60238:	mov    rsi,rcx
   6023b:	call   60240 <sqlite3VdbeExec+0x10da0>
   60240:	mov    rdi,QWORD PTR [rsp+0xb0]
   60248:	test   rax,rax
   6024b:	jne    60251 <sqlite3VdbeExec+0x10db1>
   6024d:	xor    eax,eax
   6024f:	jmp    60281 <sqlite3VdbeExec+0x10de1>
   60251:	mov    rcx,QWORD PTR [rbp+0x0]
   60255:	mov    QWORD PTR [rax],rcx
   60258:	mov    QWORD PTR [rbp+0x0],rax
   6025c:	add    rax,0x8
   60260:	mov    QWORD PTR [rbp+0x20],rax
   60264:	mov    WORD PTR [rbp+0x30],0x2a
   6026a:	movzx  eax,WORD PTR [rbp+0x30]
   6026e:	sub    eax,0x1
   60271:	mov    WORD PTR [rbp+0x30],ax
   60275:	mov    rax,QWORD PTR [rbp+0x20]
   60279:	lea    rcx,[rax+0x18]
   6027d:	mov    QWORD PTR [rbp+0x20],rcx
   60281:	test   rax,rax
   60284:	je     602b8 <sqlite3VdbeExec+0x10e18>
   60286:	mov    QWORD PTR [rax],r12
   60289:	mov    QWORD PTR [rax+0x8],0x0
   60291:	mov    rcx,QWORD PTR [rbp+0x18]
   60295:	test   rcx,rcx
   60298:	je     602b0 <sqlite3VdbeExec+0x10e10>
   6029a:	cmp    r12,QWORD PTR [rcx]
   6029d:	jg     602aa <sqlite3VdbeExec+0x10e0a>
   6029f:	movzx  edx,WORD PTR [rbp+0x32]
   602a3:	and    edx,0xfffffffe
   602a6:	mov    WORD PTR [rbp+0x32],dx
   602aa:	mov    QWORD PTR [rcx+0x8],rax
   602ae:	jmp    602b4 <sqlite3VdbeExec+0x10e14>
   602b0:	mov    QWORD PTR [rbp+0x10],rax
   602b4:	mov    QWORD PTR [rbp+0x18],rax
   602b8:	mov    r14,QWORD PTR [rsp+0xc8]
   602c0:	mov    DWORD PTR [rsp+0x31c],r15d
   602c8:	mov    rbp,QWORD PTR [rsp+0xe8]
   602d0:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   602d5:	mov    QWORD PTR [rsp+0xc8],r14
   602dd:	mov    r15d,DWORD PTR [rsp+0x31c]
   602e5:	mov    QWORD PTR [rsp+0xe8],rbp
   602ed:	mov    QWORD PTR [rsp+0xd0],r12
   602f5:	mov    rbp,QWORD PTR [rsp+0xe8]
   602fd:	mov    r12,QWORD PTR [rbp+0x10]
   60301:	movsxd rax,DWORD PTR [rbp+0xc]
   60305:	imul   rax,rax,0x38
   60309:	lea    r13,[rbx+rax*1]
   6030d:	cmp    WORD PTR [rbp+0x2],0x0
   60312:	jne    6031e <sqlite3VdbeExec+0x10e7e>
   60314:	mov    r14,QWORD PTR [rsp+0xc8]
   6031c:	jmp    6035f <sqlite3VdbeExec+0x10ebf>
   6031e:	mov    rax,QWORD PTR [r12+0x20]
   60323:	mov    rcx,QWORD PTR [rdi+0x108]
   6032a:	jmp    60336 <sqlite3VdbeExec+0x10e96>
   6032c:	cmp    rax,QWORD PTR [rcx+0x30]
   60330:	je     6033b <sqlite3VdbeExec+0x10e9b>
   60332:	mov    rcx,QWORD PTR [rcx+0x8]
   60336:	test   rcx,rcx
   60339:	jne    6032c <sqlite3VdbeExec+0x10e8c>
   6033b:	test   rcx,rcx
   6033e:	jne    6034a <sqlite3VdbeExec+0x10eaa>
   60340:	mov    r14,QWORD PTR [rsp+0xc8]
   60348:	jmp    6035f <sqlite3VdbeExec+0x10ebf>
   6034a:	mov    r14,QWORD PTR [rsp+0xc8]
   60352:	mov    DWORD PTR [rsp+0x31c],r15d
   6035a:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   6035f:	mov    eax,DWORD PTR [rdi+0x118]
   60365:	cmp    eax,DWORD PTR [r14+0xb0]
   6036c:	jl     603b4 <sqlite3VdbeExec+0x10f14>
   6036e:	mov    ebx,0x1
   60373:	lea    rax,[rip+0x0]        # 6037a <sqlite3VdbeExec+0x10eda>
   6037a:	mov    QWORD PTR [rsp+0xb0],rdi
   60382:	mov    rsi,rax
   60385:	xor    eax,eax
   60387:	call   6038c <sqlite3VdbeExec+0x10eec>
   6038c:	mov    rdi,QWORD PTR [rsp+0xb0]
   60394:	mov    QWORD PTR [rsp+0xe8],rbp
   6039c:	mov    rbp,rbx
   6039f:	mov    r13,QWORD PTR [rsp+0xd0]
   603a7:	mov    rbx,QWORD PTR [rsp+0xf8]
   603af:	jmp    4f712 <sqlite3VdbeExec+0x272>
   603b4:	movzx  eax,WORD PTR [r13+0x14]
   603b9:	and    eax,0x10
   603bc:	test   eax,eax
   603be:	jne    605c7 <sqlite3VdbeExec+0x11127>
   603c4:	mov    eax,DWORD PTR [r12+0xc]
   603c9:	mov    ebx,eax
   603cb:	add    ebx,DWORD PTR [r12+0x10]
   603d0:	cmp    DWORD PTR [r12+0x10],0x0
   603d6:	jne    603db <sqlite3VdbeExec+0x10f3b>
   603d8:	add    ebx,0x1
   603db:	movsxd rax,ebx
   603de:	imul   rax,rax,0x38
   603e2:	add    rax,0x70
   603e6:	movsxd rcx,DWORD PTR [r12+0x10]
   603eb:	shl    rcx,0x3
   603ef:	add    rax,rcx
   603f2:	movsxd rcx,DWORD PTR [r12+0x8]
   603f7:	add    rcx,0x7
   603fb:	mov    rdx,rcx
   603fe:	sar    rdx,0x3f
   60402:	and    rdx,0x7
   60406:	add    rcx,rdx
   60409:	sar    rcx,0x3
   6040d:	mov    DWORD PTR [rsp+0x33c],ebx
   60414:	lea    rbx,[rax+rcx*1]
   60418:	test   r14,r14
   6041b:	je     60445 <sqlite3VdbeExec+0x10fa5>
   6041d:	mov    QWORD PTR [rsp+0x108],r13
   60425:	mov    QWORD PTR [rsp+0xb0],rdi
   6042d:	mov    rdi,r14
   60430:	mov    rsi,rbx
   60433:	call   60438 <sqlite3VdbeExec+0x10f98>
   60438:	mov    r13,rax
   6043b:	mov    rdi,QWORD PTR [rsp+0xb0]
   60443:	jmp    60468 <sqlite3VdbeExec+0x10fc8>
   60445:	mov    QWORD PTR [rsp+0x108],r13
   6044d:	mov    QWORD PTR [rsp+0xb0],rdi
   60455:	mov    rdi,rbx
   60458:	call   6045d <sqlite3VdbeExec+0x10fbd>
   6045d:	mov    r13,rax
   60460:	mov    rdi,QWORD PTR [rsp+0xb0]
   60468:	test   r13,r13
   6046b:	je     6048d <sqlite3VdbeExec+0x10fed>
   6046d:	xor    eax,eax
   6046f:	mov    QWORD PTR [rsp+0xb0],rdi
   60477:	mov    rdi,r13
   6047a:	mov    rsi,rax
   6047d:	mov    rdx,rbx
   60480:	call   60485 <sqlite3VdbeExec+0x10fe5>
   60485:	mov    rdi,QWORD PTR [rsp+0xb0]
   6048d:	test   r13,r13
   60490:	jne    604aa <sqlite3VdbeExec+0x1100a>
   60492:	mov    r13,QWORD PTR [rsp+0xf0]
   6049a:	mov    rbx,rbp
   6049d:	mov    rbp,QWORD PTR [rsp+0xf8]
   604a5:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   604aa:	mov    DWORD PTR [rsp+0x31c],r15d
   604b2:	mov    r15,QWORD PTR [rsp+0x108]
   604ba:	movzx  eax,WORD PTR [r15+0x14]
   604bf:	and    eax,0x9000
   604c4:	test   eax,eax
   604c6:	jne    604cf <sqlite3VdbeExec+0x1102f>
   604c8:	cmp    DWORD PTR [r15+0x20],0x0
   604cd:	je     604e7 <sqlite3VdbeExec+0x11047>
   604cf:	mov    QWORD PTR [rsp+0xb0],rdi
   604d7:	mov    rdi,r15
   604da:	call   604df <sqlite3VdbeExec+0x1103f>
   604df:	mov    rdi,QWORD PTR [rsp+0xb0]
   604e7:	mov    WORD PTR [r15+0x14],0x1010
   604ee:	mov    QWORD PTR [r15+0x8],r13
   604f2:	mov    DWORD PTR [r15+0x10],ebx
   604f6:	lea    rax,[rip+0x0]        # 604fd <sqlite3VdbeExec+0x1105d>
   604fd:	mov    QWORD PTR [r15+0x30],rax
   60501:	mov    QWORD PTR [r13+0x0],rdi
   60505:	mov    ebx,DWORD PTR [rsp+0x33c]
   6050c:	mov    DWORD PTR [r13+0x58],ebx
   60510:	mov    eax,DWORD PTR [r12+0x10]
   60515:	mov    DWORD PTR [r13+0x5c],eax
   60519:	mov    rbx,QWORD PTR [rsp+0xf0]
   60521:	mov    rax,rbp
   60524:	sub    rax,rbx
   60527:	movabs rdx,0x2aaaaaaaaaaaaaab
   60531:	imul   rdx
   60534:	sar    rdx,0x2
   60538:	mov    rax,rdx
   6053b:	shr    rax,0x3f
   6053f:	add    rdx,rax
   60542:	mov    rax,rdx
   60545:	mov    DWORD PTR [r13+0x4c],eax
   60549:	mov    rax,QWORD PTR [rdi+0x68]
   6054d:	mov    QWORD PTR [r13+0x18],rax
   60551:	mov    eax,DWORD PTR [rdi+0x24]
   60554:	mov    DWORD PTR [r13+0x54],eax
   60558:	mov    rax,QWORD PTR [rdi+0x78]
   6055c:	mov    QWORD PTR [r13+0x20],rax
   60560:	mov    eax,DWORD PTR [rdi+0x28]
   60563:	mov    DWORD PTR [r13+0x48],eax
   60567:	mov    rax,QWORD PTR [rdi+0x88]
   6056e:	mov    QWORD PTR [r13+0x10],rax
   60572:	mov    eax,DWORD PTR [rdi+0x90]
   60578:	mov    DWORD PTR [r13+0x50],eax
   6057c:	mov    rax,QWORD PTR [r12+0x20]
   60581:	mov    QWORD PTR [r13+0x30],rax
   60585:	movsxd rax,DWORD PTR [r13+0x58]
   60589:	imul   rax,rax,0x38
   6058d:	lea    rax,[r13+rax*1+0x70]
   60592:	lea    rcx,[r13+0x70]
   60596:	jmp    605a6 <sqlite3VdbeExec+0x11106>
   60598:	mov    WORD PTR [rcx+0x14],0x0
   6059e:	mov    QWORD PTR [rcx+0x18],r14
   605a2:	add    rcx,0x38
   605a6:	cmp    rcx,rax
   605a9:	jne    60598 <sqlite3VdbeExec+0x110f8>
   605ab:	mov    r15d,DWORD PTR [rsp+0x31c]
   605b3:	mov    ebp,DWORD PTR [rsp+0x330]
   605ba:	mov    rbx,r13
   605bd:	mov    r13d,DWORD PTR [rsp+0x334]
   605c5:	jmp    605da <sqlite3VdbeExec+0x1113a>
   605c7:	mov    rbx,QWORD PTR [r13+0x8]
   605cb:	mov    ebp,DWORD PTR [rsp+0x330]
   605d2:	mov    r13d,DWORD PTR [rsp+0x334]
   605da:	mov    eax,DWORD PTR [rdi+0x118]
   605e0:	add    eax,0x1
   605e3:	mov    DWORD PTR [rdi+0x118],eax
   605e9:	mov    rax,QWORD PTR [rdi+0x108]
   605f0:	mov    QWORD PTR [rbx+0x8],rax
   605f4:	mov    rax,QWORD PTR [r14+0x38]
   605f8:	mov    QWORD PTR [rbx+0x38],rax
   605fc:	mov    rax,QWORD PTR [rdi+0x38]
   60600:	mov    QWORD PTR [rbx+0x60],rax
   60604:	mov    rax,QWORD PTR [rdi]
   60607:	mov    rax,QWORD PTR [rax+0x78]
   6060b:	mov    QWORD PTR [rbx+0x68],rax
   6060f:	mov    rax,QWORD PTR [rdi+0x128]
   60616:	mov    QWORD PTR [rbx+0x40],rax
   6061a:	mov    QWORD PTR [rdi+0x128],0x0
   60625:	mov    QWORD PTR [rdi+0x38],0x0
   6062d:	mov    QWORD PTR [rdi+0x108],rbx
   60634:	mov    DWORD PTR [rsp+0x330],ebp
   6063b:	lea    rbp,[rbx+0x70]
   6063f:	mov    QWORD PTR [rdi+0x68],rbp
   60643:	mov    eax,DWORD PTR [rbx+0x58]
   60646:	mov    DWORD PTR [rdi+0x24],eax
   60649:	mov    eax,DWORD PTR [rbx+0x5c]
   6064c:	movzx  eax,ax
   6064f:	mov    DWORD PTR [rdi+0x28],eax
   60652:	movsxd rax,DWORD PTR [rdi+0x24]
   60656:	imul   rax,rax,0x38
   6065a:	add    rax,rbp
   6065d:	mov    QWORD PTR [rdi+0x78],rax
   60661:	mov    rax,QWORD PTR [rdi+0x78]
   60665:	movsxd rcx,DWORD PTR [r12+0x10]
   6066a:	lea    rax,[rax+rcx*8]
   6066e:	mov    QWORD PTR [rbx+0x28],rax
   60672:	mov    rax,QWORD PTR [rbx+0x28]
   60676:	xor    ecx,ecx
   60678:	mov    edx,DWORD PTR [r12+0x8]
   6067d:	add    edx,0x7
   60680:	mov    esi,edx
   60682:	sar    esi,0x1f
   60685:	and    esi,0x7
   60688:	add    edx,esi
   6068a:	sar    edx,0x3
   6068d:	movsxd rdx,edx
   60690:	mov    QWORD PTR [rsp+0xb0],rdi
   60698:	mov    rdi,rax
   6069b:	mov    rsi,rcx
   6069e:	call   606a3 <sqlite3VdbeExec+0x11203>
   606a3:	mov    rbx,QWORD PTR [r12]
   606a7:	mov    rdi,QWORD PTR [rsp+0xb0]
   606af:	mov    QWORD PTR [rdi+0x88],rbx
   606b6:	mov    eax,DWORD PTR [r12+0x8]
   606bb:	mov    DWORD PTR [rdi+0x90],eax
   606c1:	lea    r12,[rbx-0x18]
   606c5:	mov    QWORD PTR [rsp+0xe8],r12
   606cd:	mov    r12,r13
   606d0:	mov    r13,rbx
   606d3:	mov    ebx,DWORD PTR [rsp+0x330]
   606da:	mov    QWORD PTR [rsp+0x100],rbp
   606e2:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   606e7:	mov    r15d,DWORD PTR [rsp+0x31c]
   606ef:	mov    r13,QWORD PTR [rsp+0xf0]
   606f7:	mov    QWORD PTR [rsp+0xd0],r12
   606ff:	mov    r12d,DWORD PTR [rsp+0x334]
   60707:	mov    rax,QWORD PTR [rdi+0x68]
   6070b:	movsxd rcx,DWORD PTR [rbp+0x8]
   6070f:	imul   rcx,rcx,0x38
   60713:	lea    rdx,[rax+rcx*1]
   60717:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   6071c:	and    eax,0x9000
   60721:	test   eax,eax
   60723:	je     60742 <sqlite3VdbeExec+0x112a2>
   60725:	mov    QWORD PTR [rsp+0xb0],rdi
   6072d:	mov    rdi,rdx
   60730:	call   60735 <sqlite3VdbeExec+0x11295>
   60735:	mov    rdi,QWORD PTR [rsp+0xb0]
   6073d:	mov    rdx,rax
   60740:	jmp    60748 <sqlite3VdbeExec+0x112a8>
   60742:	mov    WORD PTR [rdx+0x14],0x4
   60748:	mov    rax,QWORD PTR [rdi+0x108]
   6074f:	mov    rcx,QWORD PTR [rax+0x18]
   60753:	mov    esi,DWORD PTR [rbp+0x4]
   60756:	mov    r8,QWORD PTR [rax+0x10]
   6075a:	movsxd rax,DWORD PTR [rax+0x4c]
   6075e:	imul   rax,rax,0x18
   60762:	add    esi,DWORD PTR [r8+rax*1+0x4]
   60767:	movsxd rax,esi
   6076a:	imul   rax,rax,0x38
   6076e:	add    rcx,rax
   60771:	mov    eax,0x4000
   60776:	movzx  esi,WORD PTR [rdx+0x14]
   6077a:	and    esi,0x9000
   60780:	test   esi,esi
   60782:	je     607a4 <sqlite3VdbeExec+0x11304>
   60784:	mov    QWORD PTR [rsp+0xb0],rdi
   6078c:	mov    rdi,rdx
   6078f:	mov    rsi,rcx
   60792:	mov    rdx,rax
   60795:	call   6079a <sqlite3VdbeExec+0x112fa>
   6079a:	mov    rdi,QWORD PTR [rsp+0xb0]
   607a2:	jmp    607e1 <sqlite3VdbeExec+0x11341>
   607a4:	mov    rax,QWORD PTR [rcx]
   607a7:	mov    QWORD PTR [rdx],rax
   607aa:	mov    rax,QWORD PTR [rcx+0x8]
   607ae:	mov    QWORD PTR [rdx+0x8],rax
   607b2:	mov    rax,QWORD PTR [rcx+0x10]
   607b6:	mov    QWORD PTR [rdx+0x10],rax
   607ba:	movzx  eax,WORD PTR [rcx+0x14]
   607be:	and    eax,0x2000
   607c3:	test   eax,eax
   607c5:	jne    607e1 <sqlite3VdbeExec+0x11341>
   607c7:	movzx  eax,WORD PTR [rdx+0x14]
   607cb:	and    eax,0xffff8fff
   607d0:	mov    WORD PTR [rdx+0x14],ax
   607d4:	movzx  eax,WORD PTR [rdx+0x14]
   607d8:	or     eax,0x4000
   607dd:	mov    WORD PTR [rdx+0x14],ax
   607e1:	mov    DWORD PTR [rsp+0x31c],r15d
   607e9:	mov    QWORD PTR [rsp+0xf0],r13
   607f1:	mov    DWORD PTR [rsp+0x334],r12d
   607f9:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   607fe:	mov    r15d,DWORD PTR [rsp+0x31c]
   60806:	mov    r13,QWORD PTR [rsp+0xf0]
   6080e:	mov    QWORD PTR [rsp+0xd0],r12
   60816:	mov    r12d,DWORD PTR [rsp+0x334]
   6081e:	cmp    DWORD PTR [rbp+0x4],0x0
   60822:	je     6083b <sqlite3VdbeExec+0x1139b>
   60824:	mov    rax,QWORD PTR [r14+0x2f0]
   6082b:	movsxd rcx,DWORD PTR [rbp+0x8]
   6082f:	add    rax,rcx
   60832:	mov    QWORD PTR [r14+0x2f0],rax
   60839:	jmp    60870 <sqlite3VdbeExec+0x113d0>
   6083b:	mov    rax,QWORD PTR [r14+0x30]
   6083f:	and    rax,0x80000
   60845:	test   rax,rax
   60848:	je     60861 <sqlite3VdbeExec+0x113c1>
   6084a:	mov    rax,QWORD PTR [r14+0x2f8]
   60851:	movsxd rcx,DWORD PTR [rbp+0x8]
   60855:	add    rax,rcx
   60858:	mov    QWORD PTR [r14+0x2f8],rax
   6085f:	jmp    60870 <sqlite3VdbeExec+0x113d0>
   60861:	mov    rax,QWORD PTR [rdi+0x50]
   60865:	movsxd rcx,DWORD PTR [rbp+0x8]
   60869:	add    rax,rcx
   6086c:	mov    QWORD PTR [rdi+0x50],rax
   60870:	mov    DWORD PTR [rsp+0x31c],r15d
   60878:	mov    QWORD PTR [rsp+0xf0],r13
   60880:	mov    DWORD PTR [rsp+0x334],r12d
   60888:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   6088d:	mov    r15d,DWORD PTR [rsp+0x31c]
   60895:	mov    r13,QWORD PTR [rsp+0xf0]
   6089d:	mov    QWORD PTR [rsp+0xd0],r12
   608a5:	mov    r12d,DWORD PTR [rsp+0x334]
   608ad:	cmp    DWORD PTR [rbp+0x4],0x0
   608b1:	je     608df <sqlite3VdbeExec+0x1143f>
   608b3:	cmp    QWORD PTR [r14+0x2f0],0x0
   608bb:	jne    60908 <sqlite3VdbeExec+0x11468>
   608bd:	cmp    QWORD PTR [r14+0x2f8],0x0
   608c5:	jne    60908 <sqlite3VdbeExec+0x11468>
   608c7:	mov    QWORD PTR [rsp+0xf0],r13
   608cf:	mov    DWORD PTR [rsp+0x334],r12d
   608d7:	mov    r12,r14
   608da:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   608df:	cmp    QWORD PTR [rdi+0x50],0x0
   608e4:	jne    60908 <sqlite3VdbeExec+0x11468>
   608e6:	cmp    QWORD PTR [r14+0x2f8],0x0
   608ee:	jne    60908 <sqlite3VdbeExec+0x11468>
   608f0:	mov    QWORD PTR [rsp+0xf0],r13
   608f8:	mov    DWORD PTR [rsp+0x334],r12d
   60900:	mov    r12,r14
   60903:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   60908:	mov    DWORD PTR [rsp+0x31c],r15d
   60910:	mov    QWORD PTR [rsp+0xf0],r13
   60918:	mov    DWORD PTR [rsp+0x334],r12d
   60920:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   60925:	mov    r15d,DWORD PTR [rsp+0x31c]
   6092d:	mov    r13,QWORD PTR [rsp+0xf0]
   60935:	mov    QWORD PTR [rsp+0xd0],r12
   6093d:	mov    r12d,DWORD PTR [rsp+0x334]
   60945:	cmp    QWORD PTR [rdi+0x108],0x0
   6094d:	je     6097d <sqlite3VdbeExec+0x114dd>
   6094f:	mov    rax,QWORD PTR [rdi+0x108]
   60956:	jmp    6095c <sqlite3VdbeExec+0x114bc>
   60958:	mov    rax,QWORD PTR [rax+0x8]
   6095c:	cmp    QWORD PTR [rax+0x8],0x0
   60961:	jne    60958 <sqlite3VdbeExec+0x114b8>
   60963:	mov    rax,QWORD PTR [rax+0x18]
   60967:	movsxd rcx,DWORD PTR [rbp+0x4]
   6096b:	imul   rcx,rcx,0x38
   6096f:	mov    DWORD PTR [rsp+0x334],r12d
   60977:	lea    r12,[rax+rcx*1]
   6097b:	jmp    60991 <sqlite3VdbeExec+0x114f1>
   6097d:	mov    DWORD PTR [rsp+0x334],r12d
   60985:	movsxd rax,DWORD PTR [rbp+0x4]
   60989:	imul   rax,rax,0x38
   6098d:	lea    r12,[rbx+rax*1]
   60991:	movzx  eax,WORD PTR [r12+0x14]
   60997:	mov    ecx,eax
   60999:	and    ecx,0x24
   6099c:	test   ecx,ecx
   6099e:	je     609a9 <sqlite3VdbeExec+0x11509>
   609a0:	mov    rax,QWORD PTR [r12]
   609a4:	jmp    60a2c <sqlite3VdbeExec+0x1158c>
   609a9:	mov    ecx,eax
   609ab:	and    ecx,0x8
   609ae:	test   ecx,ecx
   609b0:	je     60a01 <sqlite3VdbeExec+0x11561>
   609b2:	movsd  xmm0,QWORD PTR [r12]
   609b8:	movabs r11,0xc3dfffffffffffff
   609c2:	movq   xmm1,r11
   609c7:	ucomisd xmm1,xmm0
   609cb:	jbe    609d9 <sqlite3VdbeExec+0x11539>
   609cd:	movabs rax,0x8000000000000000
   609d7:	jmp    609ff <sqlite3VdbeExec+0x1155f>
   609d9:	movabs r11,0x43dfffffffffffff
   609e3:	movq   xmm1,r11
   609e8:	ucomisd xmm0,xmm1
   609ec:	jbe    609fa <sqlite3VdbeExec+0x1155a>
   609ee:	movabs rax,0x7fffffffffffffff
   609f8:	jmp    609ff <sqlite3VdbeExec+0x1155f>
   609fa:	cvttsd2si rax,xmm0
   609ff:	jmp    60a2c <sqlite3VdbeExec+0x1158c>
   60a01:	and    eax,0x12
   60a04:	test   eax,eax
   60a06:	je     60a2a <sqlite3VdbeExec+0x1158a>
   60a08:	cmp    QWORD PTR [r12+0x8],0x0
   60a0e:	je     60a2a <sqlite3VdbeExec+0x1158a>
   60a10:	mov    QWORD PTR [rsp+0xb0],rdi
   60a18:	mov    rdi,r12
   60a1b:	call   60a20 <sqlite3VdbeExec+0x11580>
   60a20:	mov    rdi,QWORD PTR [rsp+0xb0]
   60a28:	jmp    60a2c <sqlite3VdbeExec+0x1158c>
   60a2a:	xor    eax,eax
   60a2c:	mov    QWORD PTR [r12],rax
   60a30:	movzx  eax,WORD PTR [r12+0x14]
   60a36:	and    eax,0xfffff240
   60a3b:	or     eax,0x4
   60a3e:	mov    WORD PTR [r12+0x14],ax
   60a44:	movsxd rax,DWORD PTR [rbp+0x8]
   60a48:	imul   rax,rax,0x38
   60a4c:	mov    QWORD PTR [rsp+0x108],r12
   60a54:	lea    r12,[rbx+rax*1]
   60a58:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   60a5d:	mov    ecx,eax
   60a5f:	and    ecx,0x24
   60a62:	test   ecx,ecx
   60a64:	je     60a6f <sqlite3VdbeExec+0x115cf>
   60a66:	mov    rax,QWORD PTR [r12]
   60a6a:	jmp    60af2 <sqlite3VdbeExec+0x11652>
   60a6f:	mov    ecx,eax
   60a71:	and    ecx,0x8
   60a74:	test   ecx,ecx
   60a76:	je     60ac7 <sqlite3VdbeExec+0x11627>
   60a78:	movsd  xmm0,QWORD PTR [r12]
   60a7e:	movabs r11,0xc3dfffffffffffff
   60a88:	movq   xmm1,r11
   60a8d:	ucomisd xmm1,xmm0
   60a91:	jbe    60a9f <sqlite3VdbeExec+0x115ff>
   60a93:	movabs rax,0x8000000000000000
   60a9d:	jmp    60ac5 <sqlite3VdbeExec+0x11625>
   60a9f:	movabs r11,0x43dfffffffffffff
   60aa9:	movq   xmm1,r11
   60aae:	ucomisd xmm0,xmm1
   60ab2:	jbe    60ac0 <sqlite3VdbeExec+0x11620>
   60ab4:	movabs rax,0x7fffffffffffffff
   60abe:	jmp    60ac5 <sqlite3VdbeExec+0x11625>
   60ac0:	cvttsd2si rax,xmm0
   60ac5:	jmp    60af2 <sqlite3VdbeExec+0x11652>
   60ac7:	and    eax,0x12
   60aca:	test   eax,eax
   60acc:	je     60af0 <sqlite3VdbeExec+0x11650>
   60ace:	cmp    QWORD PTR [r12+0x8],0x0
   60ad4:	je     60af0 <sqlite3VdbeExec+0x11650>
   60ad6:	mov    QWORD PTR [rsp+0xb0],rdi
   60ade:	mov    rdi,r12
   60ae1:	call   60ae6 <sqlite3VdbeExec+0x11646>
   60ae6:	mov    rdi,QWORD PTR [rsp+0xb0]
   60aee:	jmp    60af2 <sqlite3VdbeExec+0x11652>
   60af0:	xor    eax,eax
   60af2:	mov    QWORD PTR [r12],rax
   60af6:	movzx  eax,WORD PTR [r12+0x14]
   60afc:	and    eax,0xfffff240
   60b01:	or     eax,0x4
   60b04:	mov    WORD PTR [r12+0x14],ax
   60b0a:	mov    QWORD PTR [rsp+0xf0],r13
   60b12:	mov    r13,QWORD PTR [rsp+0x108]
   60b1a:	mov    rax,QWORD PTR [r13+0x0]
   60b1e:	cmp    rax,QWORD PTR [r12]
   60b22:	jge    60b2c <sqlite3VdbeExec+0x1168c>
   60b24:	mov    rax,QWORD PTR [r12]
   60b28:	mov    QWORD PTR [r13+0x0],rax
   60b2c:	mov    DWORD PTR [rsp+0x31c],r15d
   60b34:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   60b39:	mov    r15d,DWORD PTR [rsp+0x31c]
   60b41:	mov    QWORD PTR [rsp+0xd0],r12
   60b49:	movsxd rax,DWORD PTR [rbp+0x4]
   60b4d:	imul   rax,rax,0x38
   60b51:	cmp    QWORD PTR [rbx+rax*1],0x0
   60b56:	jle    60b6f <sqlite3VdbeExec+0x116cf>
   60b58:	mov    rcx,QWORD PTR [rbx+rax*1]
   60b5c:	movsxd rdx,DWORD PTR [rbp+0xc]
   60b60:	sub    rcx,rdx
   60b63:	mov    QWORD PTR [rbx+rax*1],rcx
   60b67:	mov    r12,r14
   60b6a:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   60b6f:	mov    DWORD PTR [rsp+0x31c],r15d
   60b77:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   60b7c:	mov    r15d,DWORD PTR [rsp+0x31c]
   60b84:	mov    QWORD PTR [rsp+0xd0],r12
   60b8c:	movsxd rax,DWORD PTR [rbp+0x4]
   60b90:	imul   r12,rax,0x38
   60b94:	movsxd rax,DWORD PTR [rbp+0xc]
   60b98:	imul   r13,rax,0x38
   60b9c:	mov    rax,QWORD PTR [rdi+0x68]
   60ba0:	movsxd rcx,DWORD PTR [rbp+0x8]
   60ba4:	imul   rcx,rcx,0x38
   60ba8:	lea    rdx,[rax+rcx*1]
   60bac:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   60bb1:	and    eax,0x9000
   60bb6:	test   eax,eax
   60bb8:	je     60bd7 <sqlite3VdbeExec+0x11737>
   60bba:	mov    QWORD PTR [rsp+0xb0],rdi
   60bc2:	mov    rdi,rdx
   60bc5:	call   60bca <sqlite3VdbeExec+0x1172a>
   60bca:	mov    rdi,QWORD PTR [rsp+0xb0]
   60bd2:	mov    rdx,rax
   60bd5:	jmp    60bdd <sqlite3VdbeExec+0x1173d>
   60bd7:	mov    WORD PTR [rdx+0x14],0x4
   60bdd:	mov    rax,QWORD PTR [rbx+r12*1]
   60be1:	mov    QWORD PTR [rsp+0x108],rax
   60be9:	cmp    QWORD PTR [rsp+0x108],0x0
   60bf2:	jle    60c27 <sqlite3VdbeExec+0x11787>
   60bf4:	cmp    QWORD PTR [rbx+r13*1],0x0
   60bf9:	jle    60c01 <sqlite3VdbeExec+0x11761>
   60bfb:	mov    rax,QWORD PTR [rbx+r13*1]
   60bff:	jmp    60c03 <sqlite3VdbeExec+0x11763>
   60c01:	xor    eax,eax
   60c03:	mov    rcx,QWORD PTR [rsp+0x108]
   60c0b:	test   rax,rax
   60c0e:	jl     60c30 <sqlite3VdbeExec+0x11790>
   60c10:	test   rcx,rcx
   60c13:	jle    60c4e <sqlite3VdbeExec+0x117ae>
   60c15:	movabs rsi,0x7fffffffffffffff
   60c1f:	sub    rsi,rcx
   60c22:	cmp    rsi,rax
   60c25:	jge    60c4e <sqlite3VdbeExec+0x117ae>
   60c27:	mov    QWORD PTR [rdx],0xffffffffffffffff
   60c2e:	jmp    60c69 <sqlite3VdbeExec+0x117c9>
   60c30:	test   rcx,rcx
   60c33:	jge    60c4e <sqlite3VdbeExec+0x117ae>
   60c35:	movabs rsi,0x7fffffffffffffff
   60c3f:	add    rcx,rsi
   60c42:	neg    rcx
   60c45:	lea    rsi,[rax+0x1]
   60c49:	cmp    rcx,rsi
   60c4c:	jg     60c27 <sqlite3VdbeExec+0x11787>
   60c4e:	add    rax,QWORD PTR [rsp+0x108]
   60c56:	mov    QWORD PTR [rsp+0x108],rax
   60c5e:	mov    rax,QWORD PTR [rsp+0x108]
   60c66:	mov    QWORD PTR [rdx],rax
   60c69:	mov    DWORD PTR [rsp+0x31c],r15d
   60c71:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   60c76:	mov    r15d,DWORD PTR [rsp+0x31c]
   60c7e:	mov    QWORD PTR [rsp+0xd0],r12
   60c86:	movsxd rax,DWORD PTR [rbp+0x4]
   60c8a:	imul   rax,rax,0x38
   60c8e:	cmp    QWORD PTR [rbx+rax*1],0x0
   60c93:	je     60cb0 <sqlite3VdbeExec+0x11810>
   60c95:	cmp    QWORD PTR [rbx+rax*1],0x0
   60c9a:	jle    60ca8 <sqlite3VdbeExec+0x11808>
   60c9c:	mov    rcx,QWORD PTR [rbx+rax*1]
   60ca0:	sub    rcx,0x1
   60ca4:	mov    QWORD PTR [rbx+rax*1],rcx
   60ca8:	mov    r12,r14
   60cab:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   60cb0:	mov    DWORD PTR [rsp+0x31c],r15d
   60cb8:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   60cbd:	mov    r15d,DWORD PTR [rsp+0x31c]
   60cc5:	mov    QWORD PTR [rsp+0xd0],r12
   60ccd:	movsxd rax,DWORD PTR [rbp+0x4]
   60cd1:	imul   rax,rax,0x38
   60cd5:	movabs rcx,0x8000000000000000
   60cdf:	cmp    rcx,QWORD PTR [rbx+rax*1]
   60ce3:	jge    60cf1 <sqlite3VdbeExec+0x11851>
   60ce5:	mov    rcx,QWORD PTR [rbx+rax*1]
   60ce9:	sub    rcx,0x1
   60ced:	mov    QWORD PTR [rbx+rax*1],rcx
   60cf1:	cmp    QWORD PTR [rbx+rax*1],0x0
   60cf6:	jne    60d00 <sqlite3VdbeExec+0x11860>
   60cf8:	mov    r12,r14
   60cfb:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   60d00:	mov    DWORD PTR [rsp+0x31c],r15d
   60d08:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   60d0d:	mov    r15d,DWORD PTR [rsp+0x31c]
   60d15:	mov    QWORD PTR [rsp+0xd0],r12
   60d1d:	movzx  eax,WORD PTR [rbp+0x2]
   60d21:	mov    r12d,eax
   60d24:	mov    rax,r12
   60d27:	shl    rax,0x3
   60d2b:	lea    r13,[rax+0x30]
   60d2f:	lea    rax,[r13+0x38]
   60d33:	mov    QWORD PTR [rsp+0xb0],rdi
   60d3b:	mov    rdi,r14
   60d3e:	mov    rsi,rax
   60d41:	call   60d46 <sqlite3VdbeExec+0x118a6>
   60d46:	mov    rcx,rax
   60d49:	mov    rdi,QWORD PTR [rsp+0xb0]
   60d51:	test   rcx,rcx
   60d54:	jne    60d6e <sqlite3VdbeExec+0x118ce>
   60d56:	mov    r13,QWORD PTR [rsp+0xf0]
   60d5e:	mov    rbx,rbp
   60d61:	mov    rbp,QWORD PTR [rsp+0xf8]
   60d69:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   60d6e:	lea    rax,[rcx+r13*1]
   60d72:	mov    QWORD PTR [rcx],rax
   60d75:	mov    rax,QWORD PTR [rcx]
   60d78:	mov    WORD PTR [rax+0x14],0x1
   60d7e:	mov    QWORD PTR [rax+0x18],r14
   60d82:	mov    DWORD PTR [rax+0x20],0x0
   60d89:	mov    QWORD PTR [rcx+0x10],0x0
   60d91:	mov    rax,QWORD PTR [rbp+0x10]
   60d95:	mov    QWORD PTR [rcx+0x8],rax
   60d99:	mov    r13,QWORD PTR [rsp+0xf0]
   60da1:	mov    rax,rbp
   60da4:	sub    rax,r13
   60da7:	movabs rdx,0x2aaaaaaaaaaaaaab
   60db1:	imul   rdx
   60db4:	sar    rdx,0x2
   60db8:	mov    rax,rdx
   60dbb:	shr    rax,0x3f
   60dbf:	add    rdx,rax
   60dc2:	mov    rax,rdx
   60dc5:	mov    DWORD PTR [rcx+0x20],eax
   60dc8:	mov    QWORD PTR [rcx+0x18],rdi
   60dcc:	mov    BYTE PTR [rcx+0x29],0x0
   60dd0:	mov    DWORD PTR [rcx+0x24],0x0
   60dd7:	mov    BYTE PTR [rcx+0x28],r15b
   60ddb:	mov    WORD PTR [rcx+0x2a],r12w
   60de0:	mov    BYTE PTR [rbp+0x1],0xf0
   60de4:	mov    QWORD PTR [rbp+0x10],rcx
   60de8:	mov    BYTE PTR [rbp+0x0],0xa5
   60dec:	mov    r12,QWORD PTR [rbp+0x10]
   60df0:	movsxd rax,DWORD PTR [rbp+0xc]
   60df4:	imul   rax,rax,0x38
   60df8:	add    rax,rbx
   60dfb:	cmp    rax,QWORD PTR [r12+0x10]
   60e00:	je     60e30 <sqlite3VdbeExec+0x11990>
   60e02:	mov    QWORD PTR [r12+0x10],rax
   60e07:	movzx  ecx,WORD PTR [r12+0x2a]
   60e0d:	sub    ecx,0x1
   60e10:	jmp    60e2c <sqlite3VdbeExec+0x1198c>
   60e12:	mov    rdx,rcx
   60e15:	mov    esi,ecx
   60e17:	add    esi,DWORD PTR [rbp+0x8]
   60e1a:	movsxd rsi,esi
   60e1d:	imul   rsi,rsi,0x38
   60e21:	add    rsi,rbx
   60e24:	mov    QWORD PTR [r12+rdx*8+0x30],rsi
   60e29:	sub    ecx,0x1
   60e2c:	test   ecx,ecx
   60e2e:	jge    60e12 <sqlite3VdbeExec+0x11972>
   60e30:	mov    ecx,DWORD PTR [rax+0x10]
   60e33:	add    ecx,0x1
   60e36:	mov    DWORD PTR [rax+0x10],ecx
   60e39:	cmp    DWORD PTR [rbp+0x4],0x0
   60e3d:	je     60e71 <sqlite3VdbeExec+0x119d1>
   60e3f:	mov    rax,QWORD PTR [r12+0x8]
   60e44:	mov    rax,QWORD PTR [rax+0x30]
   60e48:	movzx  ecx,WORD PTR [r12+0x2a]
   60e4e:	lea    rdx,[r12+0x30]
   60e53:	mov    QWORD PTR [rsp+0xb0],rdi
   60e5b:	mov    rdi,r12
   60e5e:	mov    rsi,rcx
   60e61:	mov    r10,rax
   60e64:	call   r10
   60e67:	mov    rdi,QWORD PTR [rsp+0xb0]
   60e6f:	jmp    60ea1 <sqlite3VdbeExec+0x11a01>
   60e71:	mov    rax,QWORD PTR [r12+0x8]
   60e76:	mov    rax,QWORD PTR [rax+0x18]
   60e7a:	movzx  ecx,WORD PTR [r12+0x2a]
   60e80:	lea    rdx,[r12+0x30]
   60e85:	mov    QWORD PTR [rsp+0xb0],rdi
   60e8d:	mov    rdi,r12
   60e90:	mov    rsi,rcx
   60e93:	mov    r10,rax
   60e96:	call   r10
   60e99:	mov    rdi,QWORD PTR [rsp+0xb0]
   60ea1:	cmp    DWORD PTR [r12+0x24],0x0
   60ea7:	je     61031 <sqlite3VdbeExec+0x11b91>
   60ead:	cmp    DWORD PTR [r12+0x24],0x0
   60eb3:	jle    60f54 <sqlite3VdbeExec+0x11ab4>
   60eb9:	mov    rax,QWORD PTR [r12]
   60ebd:	test   rax,rax
   60ec0:	jne    60ec6 <sqlite3VdbeExec+0x11a26>
   60ec2:	xor    eax,eax
   60ec4:	jmp    60f13 <sqlite3VdbeExec+0x11a73>
   60ec6:	movzx  ecx,WORD PTR [rax+0x14]
   60eca:	and    ecx,0x202
   60ed0:	cmp    ecx,0x202
   60ed6:	jne    60ee4 <sqlite3VdbeExec+0x11a44>
   60ed8:	cmp    BYTE PTR [rax+0x16],0x1
   60edc:	jne    60ee4 <sqlite3VdbeExec+0x11a44>
   60ede:	mov    rax,QWORD PTR [rax+0x8]
   60ee2:	jmp    60f13 <sqlite3VdbeExec+0x11a73>
   60ee4:	movzx  ecx,WORD PTR [rax+0x14]
   60ee8:	and    ecx,0x1
   60eeb:	test   ecx,ecx
   60eed:	je     60ef3 <sqlite3VdbeExec+0x11a53>
   60eef:	xor    eax,eax
   60ef1:	jmp    60f13 <sqlite3VdbeExec+0x11a73>
   60ef3:	mov    ecx,0x1
   60ef8:	mov    QWORD PTR [rsp+0xb0],rdi
   60f00:	mov    rdi,rax
   60f03:	mov    rsi,rcx
   60f06:	call   60f0b <sqlite3VdbeExec+0x11a6b>
   60f0b:	mov    rdi,QWORD PTR [rsp+0xb0]
   60f13:	mov    QWORD PTR [rsp+0xf0],r13
   60f1b:	lea    r13,[rip+0x0]        # 60f22 <sqlite3VdbeExec+0x11a82>
   60f22:	mov    QWORD PTR [rsp+0xb0],rdi
   60f2a:	mov    rsi,r13
   60f2d:	mov    rdx,rax
   60f30:	xor    eax,eax
   60f32:	call   60f37 <sqlite3VdbeExec+0x11a97>
   60f37:	mov    r13d,DWORD PTR [r12+0x24]
   60f3c:	mov    rdi,QWORD PTR [rsp+0xb0]
   60f44:	mov    DWORD PTR [rsp+0x32c],r13d
   60f4c:	mov    r13,QWORD PTR [rsp+0xf0]
   60f54:	cmp    BYTE PTR [r12+0x29],0x0
   60f5a:	je     60faf <sqlite3VdbeExec+0x11b0f>
   60f5c:	movsxd rax,DWORD PTR [rbp-0x14]
   60f60:	test   eax,eax
   60f62:	je     60fa9 <sqlite3VdbeExec+0x11b09>
   60f64:	imul   rax,rax,0x38
   60f68:	lea    rcx,[rbx+rax*1]
   60f6c:	mov    edx,0x1
   60f71:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   60f76:	and    eax,0x9000
   60f7b:	test   eax,eax
   60f7d:	je     60f9c <sqlite3VdbeExec+0x11afc>
   60f7f:	mov    QWORD PTR [rsp+0xb0],rdi
   60f87:	mov    rdi,rcx
   60f8a:	mov    rsi,rdx
   60f8d:	call   60f92 <sqlite3VdbeExec+0x11af2>
   60f92:	mov    rdi,QWORD PTR [rsp+0xb0]
   60f9a:	jmp    60fa9 <sqlite3VdbeExec+0x11b09>
   60f9c:	mov    QWORD PTR [rcx],0x1
   60fa3:	mov    WORD PTR [rcx+0x14],0x4
   60fa9:	mov    BYTE PTR [r12+0x29],0x0
   60faf:	mov    rax,QWORD PTR [r12]
   60fb3:	movzx  ecx,WORD PTR [rax+0x14]
   60fb7:	and    ecx,0x9000
   60fbd:	test   ecx,ecx
   60fbf:	jne    60fc7 <sqlite3VdbeExec+0x11b27>
   60fc1:	cmp    DWORD PTR [rax+0x20],0x0
   60fc5:	je     60fdf <sqlite3VdbeExec+0x11b3f>
   60fc7:	mov    QWORD PTR [rsp+0xb0],rdi
   60fcf:	mov    rdi,rax
   60fd2:	call   60fd7 <sqlite3VdbeExec+0x11b37>
   60fd7:	mov    rdi,QWORD PTR [rsp+0xb0]
   60fdf:	mov    rax,QWORD PTR [r12]
   60fe3:	mov    WORD PTR [rax+0x14],0x1
   60fe9:	mov    DWORD PTR [r12+0x24],0x0
   60ff2:	mov    r12d,DWORD PTR [rsp+0x32c]
   60ffa:	test   r12d,r12d
   60ffd:	jne    61009 <sqlite3VdbeExec+0x11b69>
   60fff:	mov    DWORD PTR [rsp+0x32c],r12d
   61007:	jmp    61031 <sqlite3VdbeExec+0x11b91>
   61009:	mov    QWORD PTR [rsp+0xf0],r13
   61011:	mov    QWORD PTR [rsp+0xe8],rbp
   61019:	mov    rbp,r12
   6101c:	mov    r13,QWORD PTR [rsp+0xd0]
   61024:	mov    rbx,QWORD PTR [rsp+0xf8]
   6102c:	jmp    4f712 <sqlite3VdbeExec+0x272>
   61031:	mov    DWORD PTR [rsp+0x31c],r15d
   61039:	mov    QWORD PTR [rsp+0xf0],r13
   61041:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   61046:	mov    r15d,DWORD PTR [rsp+0x31c]
   6104e:	mov    r13,QWORD PTR [rsp+0xf0]
   61056:	mov    QWORD PTR [rsp+0xd0],r12
   6105e:	movsxd rax,DWORD PTR [rbp+0x4]
   61062:	imul   rax,rax,0x38
   61066:	lea    r12,[rbx+rax*1]
   6106a:	cmp    DWORD PTR [rbp+0xc],0x0
   6106e:	je     6115c <sqlite3VdbeExec+0x11cbc>
   61074:	movsxd rax,DWORD PTR [rbp+0xc]
   61078:	mov    QWORD PTR [rsp+0xf0],r13
   61080:	imul   r13,rax,0x38
   61084:	mov    DWORD PTR [rsp+0x31c],r15d
   6108c:	lea    r15,[rbx+r13*1]
   61090:	mov    QWORD PTR [rsp+0xc8],r14
   61098:	mov    r14,QWORD PTR [rbp+0x10]
   6109c:	mov    QWORD PTR [rsp+0xe8],rbp
   610a4:	lea    rbp,[rsp+0x1b0]
   610ac:	mov    rax,rbp
   610af:	xor    ecx,ecx
   610b1:	mov    edx,0x30
   610b6:	mov    QWORD PTR [rsp+0xb0],rdi
   610be:	mov    rdi,rax
   610c1:	mov    rsi,rcx
   610c4:	call   610c9 <sqlite3VdbeExec+0x11c29>
   610c9:	movzx  eax,WORD PTR [rbx+r13*1+0x14]
   610cf:	and    eax,0x9000
   610d4:	mov    rdi,QWORD PTR [rsp+0xb0]
   610dc:	test   eax,eax
   610de:	je     610f2 <sqlite3VdbeExec+0x11c52>
   610e0:	mov    rdi,r15
   610e3:	call   610e8 <sqlite3VdbeExec+0x11c48>
   610e8:	mov    rdi,QWORD PTR [rsp+0xb0]
   610f0:	jmp    610f9 <sqlite3VdbeExec+0x11c59>
   610f2:	mov    WORD PTR [r15+0x14],0x1
   610f9:	mov    QWORD PTR [rbp+0x0],r15
   610fd:	mov    QWORD PTR [rbp+0x10],r12
   61101:	mov    QWORD PTR [rbp+0x8],r14
   61105:	mov    rax,QWORD PTR [r12+0x18]
   6110a:	movzx  eax,BYTE PTR [rax+0x64]
   6110e:	mov    BYTE PTR [rbp+0x28],al
   61111:	mov    rax,QWORD PTR [r14+0x28]
   61115:	mov    rcx,rbp
   61118:	mov    QWORD PTR [rsp+0xb0],rdi
   61120:	mov    rdi,rcx
   61123:	mov    r10,rax
   61126:	call   r10
   61129:	mov    eax,DWORD PTR [rbp+0x24]
   6112c:	mov    ebp,eax
   6112e:	mov    r12,QWORD PTR [rsp+0xe8]
   61136:	movsxd rax,DWORD PTR [r12+0xc]
   6113b:	imul   rax,rax,0x38
   6113f:	lea    r13,[rbx+rax*1]
   61143:	mov    rdi,QWORD PTR [rsp+0xb0]
   6114b:	mov    r11,rbp
   6114e:	mov    rbp,r12
   61151:	mov    r12,r13
   61154:	mov    r13,r11
   61157:	jmp    61269 <sqlite3VdbeExec+0x11dc9>
   6115c:	mov    QWORD PTR [rsp+0xc8],r14
   61164:	mov    DWORD PTR [rsp+0x31c],r15d
   6116c:	mov    QWORD PTR [rsp+0xf0],r13
   61174:	mov    r13,QWORD PTR [rbp+0x10]
   61178:	lea    r14,[rsp+0x1b0]
   61180:	lea    r15,[rsp+0x218]
   61188:	mov    rax,r14
   6118b:	xor    ecx,ecx
   6118d:	mov    edx,0x30
   61192:	mov    QWORD PTR [rsp+0xb0],rdi
   6119a:	mov    rdi,rax
   6119d:	mov    rsi,rcx
   611a0:	call   611a5 <sqlite3VdbeExec+0x11d05>
   611a5:	mov    rax,r15
   611a8:	xor    ecx,ecx
   611aa:	mov    edx,0x38
   611af:	mov    rdi,rax
   611b2:	mov    rsi,rcx
   611b5:	call   611ba <sqlite3VdbeExec+0x11d1a>
   611ba:	mov    WORD PTR [rsp+0x22c],0x1
   611c4:	mov    rax,QWORD PTR [r12+0x18]
   611c9:	mov    QWORD PTR [rsp+0x230],rax
   611d1:	mov    rax,r15
   611d4:	mov    QWORD PTR [rsp+0x1b0],rax
   611dc:	mov    QWORD PTR [rsp+0x1c0],r12
   611e4:	mov    QWORD PTR [rsp+0x1b8],r13
   611ec:	mov    rax,QWORD PTR [rsp+0x230]
   611f4:	movzx  eax,BYTE PTR [rax+0x64]
   611f8:	mov    BYTE PTR [rsp+0x1d8],al
   611ff:	mov    rax,QWORD PTR [r13+0x20]
   61203:	mov    rcx,r14
   61206:	mov    rdi,rcx
   61209:	mov    r10,rax
   6120c:	call   r10
   6120f:	mov    rdi,QWORD PTR [rsp+0xb0]
   61217:	cmp    DWORD PTR [r12+0x20],0x0
   6121d:	jle    6123c <sqlite3VdbeExec+0x11d9c>
   6121f:	mov    rax,QWORD PTR [r12+0x18]
   61224:	mov    rcx,QWORD PTR [r12+0x28]
   61229:	mov    rdi,rax
   6122c:	mov    rsi,rcx
   6122f:	call   61234 <sqlite3VdbeExec+0x11d94>
   61234:	mov    rdi,QWORD PTR [rsp+0xb0]
   6123c:	mov    rax,r15
   6123f:	mov    ecx,0x38
   61244:	mov    QWORD PTR [rsp+0xb0],rdi
   6124c:	mov    rdi,r12
   6124f:	mov    rsi,rax
   61252:	mov    rdx,rcx
   61255:	call   6125a <sqlite3VdbeExec+0x11dba>
   6125a:	mov    eax,DWORD PTR [r14+0x24]
   6125e:	mov    r13d,eax
   61261:	mov    rdi,QWORD PTR [rsp+0xb0]
   61269:	test   r13d,r13d
   6126c:	je     61331 <sqlite3VdbeExec+0x11e91>
   61272:	lea    rbx,[rip+0x0]        # 61279 <sqlite3VdbeExec+0x11dd9>
   61279:	test   r12,r12
   6127c:	jne    6128a <sqlite3VdbeExec+0x11dea>
   6127e:	xor    eax,eax
   61280:	mov    r14,QWORD PTR [rsp+0xc8]
   61288:	jmp    612f4 <sqlite3VdbeExec+0x11e54>
   6128a:	movzx  eax,WORD PTR [r12+0x14]
   61290:	and    eax,0x202
   61295:	cmp    eax,0x202
   6129a:	jne    612b3 <sqlite3VdbeExec+0x11e13>
   6129c:	cmp    BYTE PTR [r12+0x16],0x1
   612a2:	jne    612b3 <sqlite3VdbeExec+0x11e13>
   612a4:	mov    rax,QWORD PTR [r12+0x8]
   612a9:	mov    r14,QWORD PTR [rsp+0xc8]
   612b1:	jmp    612f4 <sqlite3VdbeExec+0x11e54>
   612b3:	movzx  eax,WORD PTR [r12+0x14]
   612b9:	and    eax,0x1
   612bc:	test   eax,eax
   612be:	je     612cc <sqlite3VdbeExec+0x11e2c>
   612c0:	xor    eax,eax
   612c2:	mov    r14,QWORD PTR [rsp+0xc8]
   612ca:	jmp    612f4 <sqlite3VdbeExec+0x11e54>
   612cc:	mov    eax,0x1
   612d1:	mov    QWORD PTR [rsp+0xb0],rdi
   612d9:	mov    rdi,r12
   612dc:	mov    rsi,rax
   612df:	call   612e4 <sqlite3VdbeExec+0x11e44>
   612e4:	mov    rdi,QWORD PTR [rsp+0xb0]
   612ec:	mov    r14,QWORD PTR [rsp+0xc8]
   612f4:	mov    QWORD PTR [rsp+0xb0],rdi
   612fc:	mov    rsi,rbx
   612ff:	mov    rdx,rax
   61302:	xor    eax,eax
   61304:	call   61309 <sqlite3VdbeExec+0x11e69>
   61309:	mov    rdi,QWORD PTR [rsp+0xb0]
   61311:	mov    QWORD PTR [rsp+0xe8],rbp
   61319:	mov    rbp,r13
   6131c:	mov    r13,QWORD PTR [rsp+0xd0]
   61324:	mov    rbx,QWORD PTR [rsp+0xf8]
   6132c:	jmp    4f712 <sqlite3VdbeExec+0x272>
   61331:	mov    r15d,DWORD PTR [rsp+0x31c]
   61339:	mov    eax,r15d
   6133c:	movzx  ecx,WORD PTR [r12+0x14]
   61342:	and    ecx,0x2
   61345:	test   ecx,ecx
   61347:	jne    61358 <sqlite3VdbeExec+0x11eb8>
   61349:	mov    BYTE PTR [r12+0x16],al
   6134e:	mov    r14,QWORD PTR [rsp+0xc8]
   61356:	jmp    6138f <sqlite3VdbeExec+0x11eef>
   61358:	movzx  ecx,BYTE PTR [r12+0x16]
   6135e:	cmp    ecx,eax
   61360:	jne    6136c <sqlite3VdbeExec+0x11ecc>
   61362:	mov    r14,QWORD PTR [rsp+0xc8]
   6136a:	jmp    6138f <sqlite3VdbeExec+0x11eef>
   6136c:	mov    r14,QWORD PTR [rsp+0xc8]
   61374:	mov    QWORD PTR [rsp+0xb0],rdi
   6137c:	mov    rdi,r12
   6137f:	mov    rsi,rax
   61382:	call   61387 <sqlite3VdbeExec+0x11ee7>
   61387:	mov    rdi,QWORD PTR [rsp+0xb0]
   6138f:	mov    DWORD PTR [rsp+0x31c],r15d
   61397:	mov    DWORD PTR [rsp+0x32c],r13d
   6139f:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   613a4:	mov    r15d,DWORD PTR [rsp+0x31c]
   613ac:	mov    QWORD PTR [rsp+0xd0],r12
   613b4:	mov    DWORD PTR [rsp+0x360],0x0
   613bf:	mov    DWORD PTR [rsp+0x368],0xffffffff
   613ca:	mov    DWORD PTR [rsp+0x364],0xffffffff
   613d5:	mov    eax,DWORD PTR [rbp+0x4]
   613d8:	mov    ecx,DWORD PTR [rbp+0x8]
   613db:	lea    r12,[rsp+0x360]
   613e3:	lea    rdx,[r12+0x4]
   613e8:	lea    rsi,[r12+0x8]
   613ed:	mov    QWORD PTR [rsp+0xb0],rdi
   613f5:	mov    rdi,r14
   613f8:	mov    r8,rsi
   613fb:	mov    rsi,rax
   613fe:	mov    r11,rdx
   61401:	mov    rdx,rcx
   61404:	mov    rcx,r11
   61407:	call   6140c <sqlite3VdbeExec+0x11f6c>
   6140c:	mov    r13d,eax
   6140f:	mov    rdi,QWORD PTR [rsp+0xb0]
   61417:	test   r13d,r13d
   6141a:	je     61450 <sqlite3VdbeExec+0x11fb0>
   6141c:	cmp    r13d,0x5
   61420:	je     61442 <sqlite3VdbeExec+0x11fa2>
   61422:	mov    QWORD PTR [rsp+0xe8],rbp
   6142a:	mov    rbp,r13
   6142d:	mov    r13,QWORD PTR [rsp+0xd0]
   61435:	mov    rbx,QWORD PTR [rsp+0xf8]
   6143d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   61442:	mov    DWORD PTR [rsp+0x360],0x1
   6144d:	xor    r13d,r13d
   61450:	movsxd rax,DWORD PTR [rbp+0xc]
   61454:	imul   rax,rax,0x38
   61458:	lea    r12,[rbx+rax*1]
   6145c:	mov    DWORD PTR [rsp+0x32c],r13d
   61464:	mov    r13,r12
   61467:	xor    r12d,r12d
   6146a:	jmp    6147f <sqlite3VdbeExec+0x11fdf>
   6146c:	mov    QWORD PTR [r13+0x0],rax
   61470:	mov    WORD PTR [r13+0x14],0x4
   61477:	add    r12d,0x1
   6147b:	add    r13,0x38
   6147f:	cmp    r12d,0x3
   61483:	jge    614bc <sqlite3VdbeExec+0x1201c>
   61485:	mov    rax,r12
   61488:	movsxd rax,DWORD PTR [rsp+rax*4+0x360]
   61490:	movzx  ecx,WORD PTR [r13+0x14]
   61495:	and    ecx,0x9000
   6149b:	test   ecx,ecx
   6149d:	je     6146c <sqlite3VdbeExec+0x11fcc>
   6149f:	mov    QWORD PTR [rsp+0xb0],rdi
   614a7:	mov    rdi,r13
   614aa:	mov    rsi,rax
   614ad:	call   614b2 <sqlite3VdbeExec+0x12012>
   614b2:	mov    rdi,QWORD PTR [rsp+0xb0]
   614ba:	jmp    61477 <sqlite3VdbeExec+0x11fd7>
   614bc:	mov    DWORD PTR [rsp+0x31c],r15d
   614c4:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   614c9:	mov    r15d,DWORD PTR [rsp+0x31c]
   614d1:	mov    r13,QWORD PTR [rsp+0xf0]
   614d9:	mov    QWORD PTR [rsp+0xd0],r12
   614e1:	mov    r12d,DWORD PTR [rsp+0x334]
   614e9:	mov    rax,QWORD PTR [rdi+0x68]
   614ed:	movsxd rcx,DWORD PTR [rbp+0x8]
   614f1:	imul   rcx,rcx,0x38
   614f5:	mov    DWORD PTR [rsp+0x334],r12d
   614fd:	lea    r12,[rax+rcx*1]
   61501:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   61506:	and    eax,0x9000
   6150b:	test   eax,eax
   6150d:	je     6152c <sqlite3VdbeExec+0x1208c>
   6150f:	mov    QWORD PTR [rsp+0xb0],rdi
   61517:	mov    rdi,r12
   6151a:	call   6151f <sqlite3VdbeExec+0x1207f>
   6151f:	mov    r12,rax
   61522:	mov    rdi,QWORD PTR [rsp+0xb0]
   6152a:	jmp    61534 <sqlite3VdbeExec+0x12094>
   6152c:	mov    WORD PTR [r12+0x14],0x4
   61534:	mov    QWORD PTR [rsp+0x108],r12
   6153c:	mov    r12d,DWORD PTR [rbp+0xc]
   61540:	mov    rax,QWORD PTR [r14+0x20]
   61544:	movsxd rcx,DWORD PTR [rbp+0x4]
   61548:	shl    rcx,0x5
   6154c:	mov    QWORD PTR [rsp+0xf0],r13
   61554:	mov    r13,QWORD PTR [rax+rcx*1+0x8]
   61559:	mov    rax,QWORD PTR [r13+0x8]
   6155d:	mov    rax,QWORD PTR [rax]
   61560:	mov    QWORD PTR [rsp+0x130],r13
   61568:	mov    r13,rax
   6156b:	movzx  eax,BYTE PTR [r13+0x9]
   61570:	mov    DWORD PTR [rsp+0x31c],r15d
   61578:	mov    r15d,eax
   6157b:	cmp    r12d,0xffffffff
   6157f:	jne    61584 <sqlite3VdbeExec+0x120e4>
   61581:	mov    r12,r15
   61584:	cmp    BYTE PTR [r13+0x15],0x3
   61589:	jae    6159e <sqlite3VdbeExec+0x120fe>
   6158b:	mov    rax,QWORD PTR [r13+0x50]
   6158f:	cmp    QWORD PTR [rax],0x0
   61593:	je     6159c <sqlite3VdbeExec+0x120fc>
   61595:	cmp    QWORD PTR [r13+0x60],0x0
   6159a:	jg     6159e <sqlite3VdbeExec+0x120fe>
   6159c:	jmp    615a1 <sqlite3VdbeExec+0x12101>
   6159e:	mov    r12,r15
   615a1:	cmp    BYTE PTR [r13+0x13],0x0
   615a6:	jne    615b5 <sqlite3VdbeExec+0x12115>
   615a8:	lea    rax,[rip+0x0]        # 615af <sqlite3VdbeExec+0x1210f>
   615af:	cmp    rax,QWORD PTR [r13+0x0]
   615b3:	jne    615be <sqlite3VdbeExec+0x1211e>
   615b5:	lea    rax,[rip+0x0]        # 615bc <sqlite3VdbeExec+0x1211c>
   615bc:	jmp    615c5 <sqlite3VdbeExec+0x12125>
   615be:	mov    rax,QWORD PTR [r13+0xd8]
   615c5:	cmp    r12d,0x5
   615c9:	jne    61627 <sqlite3VdbeExec+0x12187>
   615cb:	test   rax,rax
   615ce:	je     61624 <sqlite3VdbeExec+0x12184>
   615d0:	mov    QWORD PTR [rsp+0xb0],rdi
   615d8:	mov    rdi,rax
   615db:	call   615e0 <sqlite3VdbeExec+0x12140>
   615e0:	and    eax,0x3fffffff
   615e5:	mov    rdi,QWORD PTR [rsp+0xb0]
   615ed:	test   eax,eax
   615ef:	je     61624 <sqlite3VdbeExec+0x12184>
   615f1:	mov    rax,QWORD PTR [r13+0x48]
   615f5:	mov    rax,QWORD PTR [rax]
   615f8:	cmp    BYTE PTR [r13+0x11],0x0
   615fd:	jne    61624 <sqlite3VdbeExec+0x12184>
   615ff:	cmp    BYTE PTR [r13+0x8],0x0
   61604:	jne    6168e <sqlite3VdbeExec+0x121ee>
   6160a:	cmp    DWORD PTR [rax],0x2
   6160d:	jl     6161e <sqlite3VdbeExec+0x1217e>
   6160f:	cmp    QWORD PTR [rax+0x68],0x0
   61614:	mov    eax,0x0
   61619:	setne  al
   6161c:	jmp    61620 <sqlite3VdbeExec+0x12180>
   6161e:	xor    eax,eax
   61620:	test   eax,eax
   61622:	jne    61627 <sqlite3VdbeExec+0x12187>
   61624:	mov    r12,r15
   61627:	cmp    r12d,r15d
   6162a:	jne    61641 <sqlite3VdbeExec+0x121a1>
   6162c:	mov    DWORD PTR [rsp+0x33c],r15d
   61634:	mov    r15d,DWORD PTR [rsp+0x32c]
   6163c:	jmp    61bbc <sqlite3VdbeExec+0x1271c>
   61641:	cmp    r15d,0x5
   61645:	je     61662 <sqlite3VdbeExec+0x121c2>
   61647:	cmp    r12d,0x5
   6164b:	je     61662 <sqlite3VdbeExec+0x121c2>
   6164d:	mov    DWORD PTR [rsp+0x33c],r15d
   61655:	mov    r15d,DWORD PTR [rsp+0x32c]
   6165d:	jmp    61bbc <sqlite3VdbeExec+0x1271c>
   61662:	cmp    BYTE PTR [r14+0x65],0x0
   61667:	je     61673 <sqlite3VdbeExec+0x121d3>
   61669:	cmp    DWORD PTR [r14+0xd4],0x1
   61671:	jle    616d4 <sqlite3VdbeExec+0x12234>
   61673:	mov    ebx,0x1
   61678:	lea    rax,[rip+0x0]        # 6167f <sqlite3VdbeExec+0x121df>
   6167f:	cmp    r12d,0x5
   61683:	jne    61690 <sqlite3VdbeExec+0x121f0>
   61685:	lea    rcx,[rip+0x0]        # 6168c <sqlite3VdbeExec+0x121ec>
   6168c:	jmp    61697 <sqlite3VdbeExec+0x121f7>
   6168e:	jmp    61627 <sqlite3VdbeExec+0x12187>
   61690:	lea    rcx,[rip+0x0]        # 61697 <sqlite3VdbeExec+0x121f7>
   61697:	mov    QWORD PTR [rsp+0xb0],rdi
   6169f:	mov    rsi,rax
   616a2:	mov    rdx,rcx
   616a5:	xor    eax,eax
   616a7:	call   616ac <sqlite3VdbeExec+0x1220c>
   616ac:	mov    rdi,QWORD PTR [rsp+0xb0]
   616b4:	mov    QWORD PTR [rsp+0xe8],rbp
   616bc:	mov    rbp,rbx
   616bf:	mov    r13,QWORD PTR [rsp+0xd0]
   616c7:	mov    rbx,QWORD PTR [rsp+0xf8]
   616cf:	jmp    4f712 <sqlite3VdbeExec+0x272>
   616d4:	cmp    r15d,0x5
   616d8:	jne    61ad5 <sqlite3VdbeExec+0x12635>
   616de:	xor    eax,eax
   616e0:	cmp    QWORD PTR [r13+0x128],0x0
   616e8:	je     616f7 <sqlite3VdbeExec+0x12257>
   616ea:	mov    DWORD PTR [rsp+0x344],r12d
   616f2:	jmp    617c4 <sqlite3VdbeExec+0x12324>
   616f7:	mov    DWORD PTR [rsp+0x344],r12d
   616ff:	lea    r12,[rsp+0x338]
   61707:	mov    DWORD PTR [r12],0x0
   6170f:	mov    eax,0x1
   61714:	cmp    BYTE PTR [r13+0x16],0x1
   61719:	jb     61722 <sqlite3VdbeExec+0x12282>
   6171b:	cmp    BYTE PTR [r13+0x16],0x5
   61720:	jne    6176b <sqlite3VdbeExec+0x122cb>
   61722:	cmp    BYTE PTR [r13+0x11],0x0
   61727:	je     6172d <sqlite3VdbeExec+0x1228d>
   61729:	xor    eax,eax
   6172b:	jmp    61754 <sqlite3VdbeExec+0x122b4>
   6172d:	mov    rcx,QWORD PTR [r13+0x48]
   61731:	mov    rdx,QWORD PTR [rcx]
   61734:	mov    rdx,QWORD PTR [rdx+0x38]
   61738:	mov    QWORD PTR [rsp+0xb0],rdi
   61740:	mov    rdi,rcx
   61743:	mov    rsi,rax
   61746:	mov    r10,rdx
   61749:	call   r10
   6174c:	mov    rdi,QWORD PTR [rsp+0xb0]
   61754:	test   eax,eax
   61756:	jne    61828 <sqlite3VdbeExec+0x12388>
   6175c:	cmp    BYTE PTR [r13+0x16],0x5
   61761:	jne    61816 <sqlite3VdbeExec+0x12376>
   61767:	test   eax,eax
   61769:	jne    617a1 <sqlite3VdbeExec+0x12301>
   6176b:	mov    rax,QWORD PTR [r13+0x0]
   6176f:	mov    rcx,QWORD PTR [r13+0x130]
   61776:	xor    edx,edx
   61778:	mov    rsi,r12
   6177b:	mov    r8,QWORD PTR [rax+0x38]
   6177f:	mov    QWORD PTR [rsp+0xb0],rdi
   61787:	mov    rdi,rax
   6178a:	mov    r10,r8
   6178d:	mov    r11,rsi
   61790:	mov    rsi,rcx
   61793:	mov    rcx,r11
   61796:	call   r10
   61799:	mov    rdi,QWORD PTR [rsp+0xb0]
   617a1:	test   eax,eax
   617a3:	jne    617c4 <sqlite3VdbeExec+0x12324>
   617a5:	cmp    DWORD PTR [r12],0x0
   617aa:	je     617c4 <sqlite3VdbeExec+0x12324>
   617ac:	mov    QWORD PTR [rsp+0xb0],rdi
   617b4:	mov    rdi,r13
   617b7:	call   617bc <sqlite3VdbeExec+0x1231c>
   617bc:	mov    rdi,QWORD PTR [rsp+0xb0]
   617c4:	test   eax,eax
   617c6:	je     617d5 <sqlite3VdbeExec+0x12335>
   617c8:	mov    r12d,DWORD PTR [rsp+0x344]
   617d0:	jmp    61a8d <sqlite3VdbeExec+0x125ed>
   617d5:	cmp    QWORD PTR [r13+0x128],0x0
   617dd:	jne    617ec <sqlite3VdbeExec+0x1234c>
   617df:	mov    r12d,DWORD PTR [rsp+0x344]
   617e7:	jmp    61a8d <sqlite3VdbeExec+0x125ed>
   617ec:	movzx  r12d,BYTE PTR [r13+0x16]
   617f1:	mov    eax,0x4
   617f6:	xor    ecx,ecx
   617f8:	cmp    BYTE PTR [r13+0x16],0x4
   617fd:	jb     6180b <sqlite3VdbeExec+0x1236b>
   617ff:	cmp    BYTE PTR [r13+0x16],0x5
   61804:	je     6180b <sqlite3VdbeExec+0x1236b>
   61806:	mov    rax,rcx
   61809:	jmp    6186a <sqlite3VdbeExec+0x123ca>
   6180b:	cmp    BYTE PTR [r13+0x11],0x0
   61810:	je     61835 <sqlite3VdbeExec+0x12395>
   61812:	xor    eax,eax
   61814:	jmp    6185c <sqlite3VdbeExec+0x123bc>
   61816:	mov    BYTE PTR [r13+0x16],0x1
   6181b:	test   eax,eax
   6181d:	je     6176b <sqlite3VdbeExec+0x122cb>
   61823:	jmp    617a1 <sqlite3VdbeExec+0x12301>
   61828:	test   eax,eax
   6182a:	je     6176b <sqlite3VdbeExec+0x122cb>
   61830:	jmp    617a1 <sqlite3VdbeExec+0x12301>
   61835:	mov    rcx,QWORD PTR [r13+0x48]
   61839:	mov    rdx,QWORD PTR [rcx]
   6183c:	mov    rdx,QWORD PTR [rdx+0x38]
   61840:	mov    QWORD PTR [rsp+0xb0],rdi
   61848:	mov    rdi,rcx
   6184b:	mov    rsi,rax
   6184e:	mov    r10,rdx
   61851:	call   r10
   61854:	mov    rdi,QWORD PTR [rsp+0xb0]
   6185c:	test   eax,eax
   6185e:	jne    6186a <sqlite3VdbeExec+0x123ca>
   61860:	movzx  ecx,BYTE PTR [r13+0x16]
   61865:	mov    BYTE PTR [r13+0x16],0x4
   6186a:	mov    DWORD PTR [rsp+0x33c],r15d
   61872:	mov    r15d,eax
   61875:	test   r15d,r15d
   61878:	je     618c6 <sqlite3VdbeExec+0x12426>
   6187a:	mov    rax,QWORD PTR [r13+0x48]
   6187e:	cmp    QWORD PTR [rax],0x0
   61882:	je     618bd <sqlite3VdbeExec+0x1241d>
   61884:	cmp    BYTE PTR [r13+0x11],0x0
   61889:	jne    618b2 <sqlite3VdbeExec+0x12412>
   6188b:	mov    rax,QWORD PTR [r13+0x48]
   6188f:	mov    rcx,QWORD PTR [rax]
   61892:	mov    rcx,QWORD PTR [rcx+0x40]
   61896:	mov    QWORD PTR [rsp+0xb0],rdi
   6189e:	mov    rdi,rax
   618a1:	mov    rsi,r12
   618a4:	mov    r10,rcx
   618a7:	call   r10
   618aa:	mov    rdi,QWORD PTR [rsp+0xb0]
   618b2:	cmp    BYTE PTR [r13+0x16],0x5
   618b7:	je     618bd <sqlite3VdbeExec+0x1241d>
   618b9:	mov    BYTE PTR [r13+0x16],r12b
   618bd:	movzx  eax,BYTE PTR [r13+0x10]
   618c2:	mov    BYTE PTR [r13+0x17],al
   618c6:	mov    eax,r15d
   618c9:	test   eax,eax
   618cb:	je     618e2 <sqlite3VdbeExec+0x12442>
   618cd:	mov    r15d,DWORD PTR [rsp+0x33c]
   618d5:	mov    r12d,DWORD PTR [rsp+0x344]
   618dd:	jmp    61a8d <sqlite3VdbeExec+0x125ed>
   618e2:	mov    rax,QWORD PTR [r13+0x128]
   618e9:	movzx  ecx,BYTE PTR [r13+0xf]
   618ee:	mov    rdx,QWORD PTR [r13+0xc8]
   618f5:	mov    rsi,QWORD PTR [r13+0x118]
   618fc:	mov    QWORD PTR [rsp+0xb0],rdi
   61904:	mov    rdi,rax
   61907:	mov    r8,rsi
   6190a:	mov    rsi,r14
   6190d:	mov    r11,rdx
   61910:	mov    rdx,rcx
   61913:	mov    rcx,r11
   61916:	call   6191b <sqlite3VdbeExec+0x1247b>
   6191b:	mov    QWORD PTR [r13+0x128],0x0
   61926:	lea    rcx,[rsp+0x120]
   6192e:	mov    rdx,QWORD PTR [r13+0x48]
   61932:	mov    rdi,QWORD PTR [rsp+0xb0]
   6193a:	cmp    QWORD PTR [rdx],0x0
   6193e:	je     619e7 <sqlite3VdbeExec+0x12547>
   61944:	mov    rdx,QWORD PTR [rdx]
   61947:	cmp    DWORD PTR [rdx],0x3
   6194a:	jl     619e7 <sqlite3VdbeExec+0x12547>
   61950:	mov    rdx,QWORD PTR [r13+0xa0]
   61957:	mov    QWORD PTR [rcx],rdx
   6195a:	xor    edx,edx
   6195c:	cmp    QWORD PTR [rcx],0x0
   61960:	setg   dl
   61963:	mov    BYTE PTR [r13+0x1b],dl
   61967:	cmp    DWORD PTR [r13+0x30],0x0
   6196c:	je     6197e <sqlite3VdbeExec+0x124de>
   6196e:	lea    rdx,[rip+0x0]        # 61975 <sqlite3VdbeExec+0x124d5>
   61975:	mov    QWORD PTR [r13+0x110],rdx
   6197c:	jmp    619a3 <sqlite3VdbeExec+0x12503>
   6197e:	cmp    BYTE PTR [r13+0x1b],0x0
   61983:	je     61995 <sqlite3VdbeExec+0x124f5>
   61985:	lea    rdx,[rip+0x0]        # 6198c <sqlite3VdbeExec+0x124ec>
   6198c:	mov    QWORD PTR [r13+0x110],rdx
   61993:	jmp    619a3 <sqlite3VdbeExec+0x12503>
   61995:	lea    rdx,[rip+0x0]        # 6199c <sqlite3VdbeExec+0x124fc>
   6199c:	mov    QWORD PTR [r13+0x110],rdx
   619a3:	mov    rdx,QWORD PTR [r13+0x48]
   619a7:	mov    esi,0x12
   619ac:	cmp    QWORD PTR [rdx],0x0
   619b0:	je     619e7 <sqlite3VdbeExec+0x12547>
   619b2:	mov    r8,QWORD PTR [rdx]
   619b5:	mov    r8,QWORD PTR [r8+0x50]
   619b9:	mov    QWORD PTR [rsp+0xa8],rax
   619c1:	mov    QWORD PTR [rsp+0xb0],rdi
   619c9:	mov    rdi,rdx
   619cc:	mov    rdx,rcx
   619cf:	mov    r10,r8
   619d2:	call   r10
   619d5:	mov    ecx,eax
   619d7:	mov    rax,QWORD PTR [rsp+0xa8]
   619df:	mov    rdi,QWORD PTR [rsp+0xb0]
   619e7:	test   eax,eax
   619e9:	jne    61a00 <sqlite3VdbeExec+0x12560>
   619eb:	mov    r15d,DWORD PTR [rsp+0x33c]
   619f3:	mov    r12d,DWORD PTR [rsp+0x344]
   619fb:	jmp    61a8d <sqlite3VdbeExec+0x125ed>
   61a00:	cmp    BYTE PTR [r13+0x8],0x0
   61a05:	je     61a19 <sqlite3VdbeExec+0x12579>
   61a07:	mov    r15d,DWORD PTR [rsp+0x33c]
   61a0f:	mov    r12d,DWORD PTR [rsp+0x344]
   61a17:	jmp    61a8d <sqlite3VdbeExec+0x125ed>
   61a19:	mov    ecx,0x1
   61a1e:	mov    rdx,QWORD PTR [r13+0x48]
   61a22:	cmp    QWORD PTR [rdx],0x0
   61a26:	je     61a74 <sqlite3VdbeExec+0x125d4>
   61a28:	cmp    BYTE PTR [r13+0x11],0x0
   61a2d:	jne    61a68 <sqlite3VdbeExec+0x125c8>
   61a2f:	mov    rdx,QWORD PTR [r13+0x48]
   61a33:	mov    rsi,QWORD PTR [rdx]
   61a36:	mov    rsi,QWORD PTR [rsi+0x40]
   61a3a:	mov    QWORD PTR [rsp+0xa8],rax
   61a42:	mov    QWORD PTR [rsp+0xb0],rdi
   61a4a:	mov    rdi,rdx
   61a4d:	mov    r10,rsi
   61a50:	mov    rsi,rcx
   61a53:	call   r10
   61a56:	mov    ecx,eax
   61a58:	mov    rax,QWORD PTR [rsp+0xa8]
   61a60:	mov    rdi,QWORD PTR [rsp+0xb0]
   61a68:	cmp    BYTE PTR [r13+0x16],0x5
   61a6d:	je     61a74 <sqlite3VdbeExec+0x125d4>
   61a6f:	mov    BYTE PTR [r13+0x16],0x1
   61a74:	movzx  ecx,BYTE PTR [r13+0x10]
   61a79:	mov    BYTE PTR [r13+0x17],cl
   61a7d:	mov    r15d,DWORD PTR [rsp+0x33c]
   61a85:	mov    r12d,DWORD PTR [rsp+0x344]
   61a8d:	mov    DWORD PTR [rsp+0x33c],r15d
   61a95:	mov    r15d,eax
   61a98:	test   r15d,r15d
   61a9b:	jne    61ab8 <sqlite3VdbeExec+0x12618>
   61a9d:	mov    QWORD PTR [rsp+0xb0],rdi
   61aa5:	mov    rdi,r13
   61aa8:	mov    rsi,r12
   61aab:	call   61ab0 <sqlite3VdbeExec+0x12610>
   61ab0:	mov    rdi,QWORD PTR [rsp+0xb0]
   61ab8:	test   r15d,r15d
   61abb:	jne    61bbc <sqlite3VdbeExec+0x1271c>
   61ac1:	cmp    r12d,0x5
   61ac5:	jne    61b71 <sqlite3VdbeExec+0x126d1>
   61acb:	mov    eax,0x2
   61ad0:	jmp    61b96 <sqlite3VdbeExec+0x126f6>
   61ad5:	mov    DWORD PTR [rsp+0x344],r12d
   61add:	cmp    r15d,0x4
   61ae1:	jne    61b3a <sqlite3VdbeExec+0x1269a>
   61ae3:	mov    eax,0x2
   61ae8:	mov    QWORD PTR [rsp+0xb0],rdi
   61af0:	mov    rdi,r13
   61af3:	mov    rsi,rax
   61af6:	call   61afb <sqlite3VdbeExec+0x1265b>
   61afb:	mov    rdi,QWORD PTR [rsp+0xb0]
   61b03:	mov    r12d,DWORD PTR [rsp+0x32c]
   61b0b:	test   r12d,r12d
   61b0e:	je     61b28 <sqlite3VdbeExec+0x12688>
   61b10:	mov    DWORD PTR [rsp+0x33c],r15d
   61b18:	mov    r15,r12
   61b1b:	mov    r12d,DWORD PTR [rsp+0x344]
   61b23:	jmp    61bbc <sqlite3VdbeExec+0x1271c>
   61b28:	mov    DWORD PTR [rsp+0x33c],r15d
   61b30:	mov    r12d,DWORD PTR [rsp+0x344]
   61b38:	jmp    61ac1 <sqlite3VdbeExec+0x12621>
   61b3a:	mov    r12d,DWORD PTR [rsp+0x32c]
   61b42:	test   r12d,r12d
   61b45:	je     61b5c <sqlite3VdbeExec+0x126bc>
   61b47:	mov    DWORD PTR [rsp+0x33c],r15d
   61b4f:	mov    r15,r12
   61b52:	mov    r12d,DWORD PTR [rsp+0x344]
   61b5a:	jmp    61bbc <sqlite3VdbeExec+0x1271c>
   61b5c:	mov    DWORD PTR [rsp+0x33c],r15d
   61b64:	mov    r12d,DWORD PTR [rsp+0x344]
   61b6c:	jmp    61ac1 <sqlite3VdbeExec+0x12621>
   61b71:	mov    r15d,DWORD PTR [rsp+0x33c]
   61b79:	mov    DWORD PTR [rsp+0x344],r12d
   61b81:	mov    eax,0x1
   61b86:	mov    DWORD PTR [rsp+0x33c],r15d
   61b8e:	mov    r12d,DWORD PTR [rsp+0x344]
   61b96:	mov    r15,QWORD PTR [rsp+0x130]
   61b9e:	mov    QWORD PTR [rsp+0xb0],rdi
   61ba6:	mov    rdi,r15
   61ba9:	mov    rsi,rax
   61bac:	call   61bb1 <sqlite3VdbeExec+0x12711>
   61bb1:	mov    r15d,eax
   61bb4:	mov    rdi,QWORD PTR [rsp+0xb0]
   61bbc:	test   r15d,r15d
   61bbf:	je     61bc9 <sqlite3VdbeExec+0x12729>
   61bc1:	mov    r12d,DWORD PTR [rsp+0x33c]
   61bc9:	mov    QWORD PTR [rsp+0xb0],rdi
   61bd1:	mov    rdi,r13
   61bd4:	mov    rsi,r12
   61bd7:	call   61bdc <sqlite3VdbeExec+0x1273c>
   61bdc:	mov    r12,QWORD PTR [rsp+0x108]
   61be4:	mov    WORD PTR [r12+0x14],0x2202
   61bec:	mov    rdi,QWORD PTR [rsp+0xb0]
   61bf4:	cmp    eax,0x6
   61bf7:	jne    61bfd <sqlite3VdbeExec+0x1275d>
   61bf9:	xor    eax,eax
   61bfb:	jmp    61c0b <sqlite3VdbeExec+0x1276b>
   61bfd:	lea    rcx,[rip+0x0]        # 61c04 <sqlite3VdbeExec+0x12764>
   61c04:	movsxd rax,eax
   61c07:	mov    rax,QWORD PTR [rcx+rax*8]
   61c0b:	mov    QWORD PTR [r12+0x8],rax
   61c10:	mov    rax,QWORD PTR [r12+0x8]
   61c15:	test   rax,rax
   61c18:	jne    61c1e <sqlite3VdbeExec+0x1277e>
   61c1a:	xor    eax,eax
   61c1c:	jmp    61c3b <sqlite3VdbeExec+0x1279b>
   61c1e:	mov    QWORD PTR [rsp+0xb0],rdi
   61c26:	mov    rdi,rax
   61c29:	call   61c2e <sqlite3VdbeExec+0x1278e>
   61c2e:	and    eax,0x3fffffff
   61c33:	mov    rdi,QWORD PTR [rsp+0xb0]
   61c3b:	mov    DWORD PTR [r12+0x10],eax
   61c40:	mov    BYTE PTR [r12+0x16],0x1
   61c46:	mov    r13d,DWORD PTR [rsp+0x31c]
   61c4e:	mov    eax,r13d
   61c51:	movzx  ecx,WORD PTR [r12+0x14]
   61c57:	and    ecx,0x2
   61c5a:	test   ecx,ecx
   61c5c:	jne    61c88 <sqlite3VdbeExec+0x127e8>
   61c5e:	mov    BYTE PTR [r12+0x16],al
   61c63:	test   r15d,r15d
   61c66:	je     61c97 <sqlite3VdbeExec+0x127f7>
   61c68:	mov    QWORD PTR [rsp+0xe8],rbp
   61c70:	mov    rbp,r15
   61c73:	mov    r13,QWORD PTR [rsp+0xd0]
   61c7b:	mov    rbx,QWORD PTR [rsp+0xf8]
   61c83:	jmp    4f712 <sqlite3VdbeExec+0x272>
   61c88:	movzx  ecx,BYTE PTR [r12+0x16]
   61c8e:	cmp    ecx,eax
   61c90:	jne    61cac <sqlite3VdbeExec+0x1280c>
   61c92:	test   r15d,r15d
   61c95:	jne    61c68 <sqlite3VdbeExec+0x127c8>
   61c97:	mov    DWORD PTR [rsp+0x31c],r13d
   61c9f:	mov    DWORD PTR [rsp+0x32c],r15d
   61ca7:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   61cac:	mov    QWORD PTR [rsp+0xb0],rdi
   61cb4:	mov    rdi,r12
   61cb7:	mov    rsi,rax
   61cba:	call   61cbf <sqlite3VdbeExec+0x1281f>
   61cbf:	mov    rdi,QWORD PTR [rsp+0xb0]
   61cc7:	test   r15d,r15d
   61cca:	jne    61c68 <sqlite3VdbeExec+0x127c8>
   61ccc:	jmp    61c97 <sqlite3VdbeExec+0x127f7>
   61cce:	mov    r13d,DWORD PTR [rsp+0x31c]
   61cd6:	mov    QWORD PTR [rsp+0xd0],r12
   61cde:	lea    rax,[rdi+0xa8]
   61ce5:	mov    ecx,DWORD PTR [rbp+0x4]
   61ce8:	cmp    DWORD PTR [rbp+0x8],0x0
   61cec:	je     61cfb <sqlite3VdbeExec+0x1285b>
   61cee:	movsxd rdx,DWORD PTR [rbp+0x8]
   61cf2:	imul   rdx,rdx,0x38
   61cf6:	add    rdx,rbx
   61cf9:	jmp    61cfd <sqlite3VdbeExec+0x1285d>
   61cfb:	xor    edx,edx
   61cfd:	mov    QWORD PTR [rsp+0xb0],rdi
   61d05:	mov    rdi,rax
   61d08:	mov    rsi,r14
   61d0b:	mov    r11,rdx
   61d0e:	mov    rdx,rcx
   61d11:	mov    rcx,r11
   61d14:	call   61d19 <sqlite3VdbeExec+0x12879>
   61d19:	mov    r12d,eax
   61d1c:	mov    rdi,QWORD PTR [rsp+0xb0]
   61d24:	test   r12d,r12d
   61d27:	je     61d49 <sqlite3VdbeExec+0x128a9>
   61d29:	mov    QWORD PTR [rsp+0xe8],rbp
   61d31:	mov    rbp,r12
   61d34:	mov    r13,QWORD PTR [rsp+0xd0]
   61d3c:	mov    rbx,QWORD PTR [rsp+0xf8]
   61d44:	jmp    4f712 <sqlite3VdbeExec+0x272>
   61d49:	mov    DWORD PTR [rsp+0x31c],r13d
   61d51:	mov    DWORD PTR [rsp+0x32c],r12d
   61d59:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   61d5e:	mov    r13d,DWORD PTR [rsp+0x31c]
   61d66:	mov    QWORD PTR [rsp+0xd0],r12
   61d6e:	mov    rax,QWORD PTR [r14+0x20]
   61d72:	movsxd rcx,DWORD PTR [rbp+0x4]
   61d76:	shl    rcx,0x5
   61d7a:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   61d7f:	mov    r12,QWORD PTR [rax+0x8]
   61d83:	mov    rcx,QWORD PTR [rax+0x8]
   61d87:	mov    rax,QWORD PTR [rax]
   61d8a:	mov    QWORD PTR [rcx+0x8],rax
   61d8e:	cmp    BYTE PTR [r12+0x21],0x0
   61d94:	jne    61da0 <sqlite3VdbeExec+0x12900>
   61d96:	mov    eax,0x65
   61d9b:	jmp    620c1 <sqlite3VdbeExec+0x12c21>
   61da0:	mov    eax,DWORD PTR [r12+0x40]
   61da5:	mov    r15d,eax
   61da8:	mov    rax,QWORD PTR [r12+0x18]
   61dad:	mov    rax,QWORD PTR [rax+0x50]
   61db1:	movzx  ecx,BYTE PTR [rax+0x24]
   61db5:	shl    ecx,0x18
   61db8:	movzx  edx,BYTE PTR [rax+0x25]
   61dbc:	shl    edx,0x10
   61dbf:	or     ecx,edx
   61dc1:	movzx  edx,BYTE PTR [rax+0x26]
   61dc5:	shl    edx,0x8
   61dc8:	or     ecx,edx
   61dca:	movzx  eax,BYTE PTR [rax+0x27]
   61dce:	or     ecx,eax
   61dd0:	mov    eax,DWORD PTR [r12+0x38]
   61dd5:	mov    edx,0xcccccccd
   61dda:	mul    edx
   61ddc:	shr    edx,0x2
   61ddf:	mov    esi,edx
   61de1:	mov    r8d,ecx
   61de4:	sub    r8d,r15d
   61de7:	cmp    r15d,0x2
   61deb:	jae    61df1 <sqlite3VdbeExec+0x12951>
   61ded:	xor    eax,eax
   61def:	jmp    61e3f <sqlite3VdbeExec+0x1299f>
   61df1:	mov    eax,DWORD PTR [r12+0x38]
   61df6:	mov    edx,0xcccccccd
   61dfb:	mul    edx
   61dfd:	shr    edx,0x2
   61e00:	mov    eax,edx
   61e02:	lea    r9d,[rax+0x1]
   61e06:	mov    eax,r15d
   61e09:	sub    eax,0x2
   61e0c:	xor    edx,edx
   61e0e:	div    r9d
   61e11:	imul   eax,r9d
   61e15:	lea    r9d,[rax+0x2]
   61e19:	mov    eax,DWORD PTR [rip+0x0]        # 61e1f <sqlite3VdbeExec+0x1297f>
   61e1f:	mov    r10d,DWORD PTR [r12+0x34]
   61e24:	xor    edx,edx
   61e26:	div    r10d
   61e29:	add    eax,0x1
   61e2c:	xor    edx,edx
   61e2e:	mov    r10d,0x1
   61e34:	cmp    r9d,eax
   61e37:	cmove  edx,r10d
   61e3b:	lea    eax,[r9+rdx*1]
   61e3f:	add    eax,r8d
   61e42:	add    eax,esi
   61e44:	xor    edx,edx
   61e46:	div    esi
   61e48:	mov    edx,r15d
   61e4b:	sub    edx,ecx
   61e4d:	mov    esi,edx
   61e4f:	sub    esi,eax
   61e51:	mov    eax,DWORD PTR [rip+0x0]        # 61e57 <sqlite3VdbeExec+0x129b7>
   61e57:	mov    r8d,DWORD PTR [r12+0x34]
   61e5c:	xor    edx,edx
   61e5e:	div    r8d
   61e61:	add    eax,0x1
   61e64:	cmp    r15d,eax
   61e67:	jbe    61ef7 <sqlite3VdbeExec+0x12a57>
   61e6d:	mov    eax,DWORD PTR [rip+0x0]        # 61e73 <sqlite3VdbeExec+0x129d3>
   61e73:	mov    r8d,DWORD PTR [r12+0x34]
   61e78:	xor    edx,edx
   61e7a:	div    r8d
   61e7d:	add    eax,0x1
   61e80:	mov    edx,esi
   61e82:	sub    edx,0x1
   61e85:	cmp    esi,eax
   61e87:	cmovb  esi,edx
   61e8a:	jmp    61ef7 <sqlite3VdbeExec+0x12a57>
   61e8c:	mov    eax,DWORD PTR [r12+0x38]
   61e91:	mov    edx,0xcccccccd
   61e96:	mul    edx
   61e98:	shr    edx,0x2
   61e9b:	mov    eax,edx
   61e9d:	lea    r8d,[rax+0x1]
   61ea1:	mov    eax,esi
   61ea3:	sub    eax,0x2
   61ea6:	xor    edx,edx
   61ea8:	div    r8d
   61eab:	imul   eax,r8d
   61eaf:	lea    r8d,[rax+0x2]
   61eb3:	mov    eax,DWORD PTR [rip+0x0]        # 61eb9 <sqlite3VdbeExec+0x12a19>
   61eb9:	mov    r9d,DWORD PTR [r12+0x34]
   61ebe:	xor    edx,edx
   61ec0:	div    r9d
   61ec3:	add    eax,0x1
   61ec6:	xor    edx,edx
   61ec8:	mov    r9d,0x1
   61ece:	cmp    r8d,eax
   61ed1:	cmove  edx,r9d
   61ed5:	lea    eax,[r8+rdx*1]
   61ed9:	cmp    eax,esi
   61edb:	je     61ef4 <sqlite3VdbeExec+0x12a54>
   61edd:	mov    eax,DWORD PTR [rip+0x0]        # 61ee3 <sqlite3VdbeExec+0x12a43>
   61ee3:	mov    r8d,DWORD PTR [r12+0x34]
   61ee8:	xor    edx,edx
   61eea:	div    r8d
   61eed:	add    eax,0x1
   61ef0:	cmp    esi,eax
   61ef2:	jne    61f04 <sqlite3VdbeExec+0x12a64>
   61ef4:	sub    esi,0x1
   61ef7:	cmp    esi,0x2
   61efa:	jae    61e8c <sqlite3VdbeExec+0x129ec>
   61efc:	xor    eax,eax
   61efe:	cmp    eax,esi
   61f00:	je     61ef4 <sqlite3VdbeExec+0x12a54>
   61f02:	jmp    61edd <sqlite3VdbeExec+0x12a3d>
   61f04:	mov    DWORD PTR [rsp+0x31c],r13d
   61f0c:	mov    r13d,esi
   61f0f:	cmp    r15d,r13d
   61f12:	jb     61f19 <sqlite3VdbeExec+0x12a79>
   61f14:	cmp    ecx,r15d
   61f17:	jb     61f52 <sqlite3VdbeExec+0x12ab2>
   61f19:	mov    eax,0x12e03
   61f1e:	mov    ecx,0xb
   61f23:	lea    rdx,[rip+0x0]        # 61f2a <sqlite3VdbeExec+0x12a8a>
   61f2a:	mov    QWORD PTR [rsp+0xb0],rdi
   61f32:	mov    rdi,rcx
   61f35:	mov    rsi,rax
   61f38:	call   61f3d <sqlite3VdbeExec+0x12a9d>
   61f3d:	mov    rdi,QWORD PTR [rsp+0xb0]
   61f45:	mov    r13d,DWORD PTR [rsp+0x31c]
   61f4d:	jmp    620c1 <sqlite3VdbeExec+0x12c21>
   61f52:	test   ecx,ecx
   61f54:	jbe    620b4 <sqlite3VdbeExec+0x12c14>
   61f5a:	xor    eax,eax
   61f5c:	xor    ecx,ecx
   61f5e:	mov    rdx,QWORD PTR [r12+0x10]
   61f63:	jmp    61f6e <sqlite3VdbeExec+0x12ace>
   61f65:	test   rdx,rdx
   61f68:	jne    61f73 <sqlite3VdbeExec+0x12ad3>
   61f6a:	mov    rdx,QWORD PTR [rdx+0x28]
   61f6e:	test   rdx,rdx
   61f71:	jne    61f65 <sqlite3VdbeExec+0x12ac5>
   61f73:	test   rdx,rdx
   61f76:	je     61f9e <sqlite3VdbeExec+0x12afe>
   61f78:	mov    QWORD PTR [rsp+0xb0],rdi
   61f80:	mov    rdi,rdx
   61f83:	mov    rsi,rax
   61f86:	mov    rdx,rcx
   61f89:	call   61f8e <sqlite3VdbeExec+0x12aee>
   61f8e:	mov    rdi,QWORD PTR [rsp+0xb0]
   61f96:	test   eax,eax
   61f98:	jne    62026 <sqlite3VdbeExec+0x12b86>
   61f9e:	mov    rax,QWORD PTR [r12+0x10]
   61fa3:	jmp    61fb3 <sqlite3VdbeExec+0x12b13>
   61fa5:	movzx  ecx,BYTE PTR [rax+0x1]
   61fa9:	and    ecx,0xfffffffb
   61fac:	mov    BYTE PTR [rax+0x1],cl
   61faf:	mov    rax,QWORD PTR [rax+0x28]
   61fb3:	test   rax,rax
   61fb6:	jne    61fa5 <sqlite3VdbeExec+0x12b05>
   61fb8:	xor    eax,eax
   61fba:	mov    QWORD PTR [rsp+0xb0],rdi
   61fc2:	mov    rdi,r12
   61fc5:	mov    rsi,r13
   61fc8:	mov    rdx,r15
   61fcb:	mov    rcx,rax
   61fce:	call   61fd3 <sqlite3VdbeExec+0x12b33>
   61fd3:	mov    rdi,QWORD PTR [rsp+0xb0]
   61fdb:	test   eax,eax
   61fdd:	jne    620aa <sqlite3VdbeExec+0x12c0a>
   61fe3:	mov    rax,QWORD PTR [r12+0x18]
   61fe8:	mov    rax,QWORD PTR [rax+0x70]
   61fec:	mov    rcx,QWORD PTR [rax+0x28]
   61ff0:	movzx  edx,WORD PTR [rax+0x34]
   61ff4:	and    edx,0x4
   61ff7:	test   edx,edx
   61ff9:	je     62030 <sqlite3VdbeExec+0x12b90>
   61ffb:	mov    edx,DWORD PTR [rcx+0x20]
   61ffe:	cmp    edx,DWORD PTR [rax+0x30]
   62001:	jb     62030 <sqlite3VdbeExec+0x12b90>
   62003:	cmp    DWORD PTR [rcx+0x80],0x0
   6200a:	je     6202c <sqlite3VdbeExec+0x12b8c>
   6200c:	mov    QWORD PTR [rsp+0xb0],rdi
   62014:	mov    rdi,rax
   62017:	call   6201c <sqlite3VdbeExec+0x12b7c>
   6201c:	mov    rdi,QWORD PTR [rsp+0xb0]
   62024:	jmp    6207e <sqlite3VdbeExec+0x12bde>
   62026:	test   eax,eax
   62028:	je     61fe3 <sqlite3VdbeExec+0x12b43>
   6202a:	jmp    620aa <sqlite3VdbeExec+0x12c0a>
   6202c:	xor    eax,eax
   6202e:	jmp    6207e <sqlite3VdbeExec+0x12bde>
   62030:	cmp    DWORD PTR [rcx+0x30],0x0
   62034:	je     6203b <sqlite3VdbeExec+0x12b9b>
   62036:	mov    eax,DWORD PTR [rcx+0x30]
   62039:	jmp    6207e <sqlite3VdbeExec+0x12bde>
   6203b:	mov    edx,DWORD PTR [rcx+0xb8]
   62041:	mov    rcx,QWORD PTR [rcx+0xc8]
   62048:	cmp    edx,ecx
   6204a:	jbe    62066 <sqlite3VdbeExec+0x12bc6>
   6204c:	mov    QWORD PTR [rsp+0xb0],rdi
   62054:	mov    rdi,rax
   62057:	call   6205c <sqlite3VdbeExec+0x12bbc>
   6205c:	mov    rdi,QWORD PTR [rsp+0xb0]
   62064:	jmp    6207e <sqlite3VdbeExec+0x12bde>
   62066:	mov    QWORD PTR [rsp+0xb0],rdi
   6206e:	mov    rdi,rax
   62071:	call   62076 <sqlite3VdbeExec+0x12bd6>
   62076:	mov    rdi,QWORD PTR [rsp+0xb0]
   6207e:	mov    rcx,QWORD PTR [r12+0x18]
   62083:	mov    rcx,QWORD PTR [rcx+0x50]
   62087:	mov    edx,DWORD PTR [r12+0x40]
   6208c:	mov    esi,edx
   6208e:	shr    esi,0x18
   62091:	mov    BYTE PTR [rcx+0x1c],sil
   62095:	mov    esi,edx
   62097:	shr    esi,0x10
   6209a:	mov    BYTE PTR [rcx+0x1d],sil
   6209e:	mov    esi,edx
   620a0:	shr    esi,0x8
   620a3:	mov    BYTE PTR [rcx+0x1e],sil
   620a7:	mov    BYTE PTR [rcx+0x1f],dl
   620aa:	mov    r13d,DWORD PTR [rsp+0x31c]
   620b2:	jmp    620c1 <sqlite3VdbeExec+0x12c21>
   620b4:	mov    eax,0x65
   620b9:	mov    r13d,DWORD PTR [rsp+0x31c]
   620c1:	mov    r12d,eax
   620c4:	test   r12d,r12d
   620c7:	je     62105 <sqlite3VdbeExec+0x12c65>
   620c9:	cmp    r12d,0x65
   620cd:	je     620ef <sqlite3VdbeExec+0x12c4f>
   620cf:	mov    QWORD PTR [rsp+0xe8],rbp
   620d7:	mov    rbp,r12
   620da:	mov    r13,QWORD PTR [rsp+0xd0]
   620e2:	mov    rbx,QWORD PTR [rsp+0xf8]
   620ea:	jmp    4f712 <sqlite3VdbeExec+0x272>
   620ef:	mov    r12,r14
   620f2:	mov    r15,r13
   620f5:	xor    r11d,r11d
   620f8:	mov    DWORD PTR [rsp+0x32c],r11d
   62100:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   62105:	mov    DWORD PTR [rsp+0x31c],r13d
   6210d:	mov    DWORD PTR [rsp+0x32c],r12d
   62115:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   6211a:	mov    r15d,DWORD PTR [rsp+0x31c]
   62122:	mov    r13,QWORD PTR [rsp+0xf0]
   6212a:	mov    QWORD PTR [rsp+0xd0],r12
   62132:	mov    r12d,DWORD PTR [rsp+0x334]
   6213a:	cmp    DWORD PTR [rbp+0x4],0x0
   6213e:	jne    62170 <sqlite3VdbeExec+0x12cd0>
   62140:	mov    eax,DWORD PTR [rbp+0x8]
   62143:	mov    rcx,QWORD PTR [r14+0x8]
   62147:	jmp    62169 <sqlite3VdbeExec+0x12cc9>
   62149:	lea    edx,[rax+0x1]
   6214c:	and    rdx,0x3
   62150:	movzx  esi,WORD PTR [rcx+0xc8]
   62157:	and    rsi,0xfffffffffffffffc
   6215b:	or     rsi,rdx
   6215e:	mov    WORD PTR [rcx+0xc8],si
   62165:	mov    rcx,QWORD PTR [rcx+0x10]
   62169:	test   rcx,rcx
   6216c:	jne    62149 <sqlite3VdbeExec+0x12ca9>
   6216e:	jmp    6218f <sqlite3VdbeExec+0x12cef>
   62170:	mov    eax,DWORD PTR [rbp+0x8]
   62173:	add    eax,0x1
   62176:	and    rax,0x3
   6217a:	movzx  ecx,WORD PTR [rdi+0xc8]
   62181:	and    rcx,0xfffffffffffffffc
   62185:	or     rcx,rax
   62188:	mov    WORD PTR [rdi+0xc8],cx
   6218f:	mov    DWORD PTR [rsp+0x31c],r15d
   62197:	mov    QWORD PTR [rsp+0xf0],r13
   6219f:	mov    DWORD PTR [rsp+0x334],r12d
   621a7:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   621ac:	mov    r15d,DWORD PTR [rsp+0x31c]
   621b4:	mov    r13,QWORD PTR [rsp+0xf0]
   621bc:	mov    QWORD PTR [rsp+0xd0],r12
   621c4:	mov    r12d,DWORD PTR [rsp+0x334]
   621cc:	mov    rax,QWORD PTR [rdi+0x78]
   621d0:	movsxd rcx,DWORD PTR [rbp+0x4]
   621d4:	mov    rax,QWORD PTR [rax+rcx*8]
   621d8:	mov    rax,QWORD PTR [rax+0x28]
   621dc:	movzx  ecx,BYTE PTR [rax+0x1]
   621e0:	or     ecx,0x40
   621e3:	mov    BYTE PTR [rax+0x1],cl
   621e6:	mov    DWORD PTR [rsp+0x31c],r15d
   621ee:	mov    QWORD PTR [rsp+0xf0],r13
   621f6:	mov    DWORD PTR [rsp+0x334],r12d
   621fe:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   62203:	mov    r15d,DWORD PTR [rsp+0x31c]
   6220b:	mov    r13,QWORD PTR [rsp+0xf0]
   62213:	mov    QWORD PTR [rsp+0xd0],r12
   6221b:	mov    r12d,DWORD PTR [rsp+0x334]
   62223:	mov    rax,QWORD PTR [rdi+0x78]
   62227:	movsxd rcx,DWORD PTR [rbp+0x4]
   6222b:	mov    rax,QWORD PTR [rax+rcx*8]
   6222f:	mov    rax,QWORD PTR [rax+0x28]
   62233:	movzx  ecx,BYTE PTR [rax+0x1]
   62237:	and    ecx,0xffffffbf
   6223a:	mov    BYTE PTR [rax+0x1],cl
   6223d:	mov    DWORD PTR [rsp+0x31c],r15d
   62245:	mov    QWORD PTR [rsp+0xf0],r13
   6224d:	mov    DWORD PTR [rsp+0x334],r12d
   62255:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   6225a:	mov    r15d,DWORD PTR [rsp+0x31c]
   62262:	mov    r13,QWORD PTR [rsp+0xf0]
   6226a:	mov    QWORD PTR [rsp+0xd0],r12
   62272:	mov    r12d,DWORD PTR [rsp+0x334]
   6227a:	mov    eax,DWORD PTR [rbp+0xc]
   6227d:	movzx  eax,al
   62280:	mov    ecx,eax
   62282:	test   ecx,ecx
   62284:	jne    622b8 <sqlite3VdbeExec+0x12e18>
   62286:	xor    ecx,ecx
   62288:	movabs rdx,0x400000000
   62292:	and    rdx,QWORD PTR [r14+0x30]
   62296:	cmp    rcx,rdx
   62299:	je     622b8 <sqlite3VdbeExec+0x12e18>
   6229b:	mov    QWORD PTR [rsp+0xf0],r13
   622a3:	mov    DWORD PTR [rsp+0x334],r12d
   622ab:	mov    r12d,DWORD PTR [rsp+0x32c]
   622b3:	jmp    624f5 <sqlite3VdbeExec+0x13055>
   622b8:	movsxd rcx,DWORD PTR [rbp+0x4]
   622bc:	mov    rdx,QWORD PTR [r14+0x20]
   622c0:	shl    rcx,0x5
   622c4:	mov    DWORD PTR [rsp+0x334],r12d
   622cc:	mov    r12,QWORD PTR [rdx+rcx*1+0x8]
   622d1:	mov    QWORD PTR [rsp+0xf0],r13
   622d9:	mov    r13d,DWORD PTR [rbp+0x8]
   622dd:	xor    ecx,ecx
   622df:	cmp    BYTE PTR [r12+0x11],0x0
   622e5:	je     62498 <sqlite3VdbeExec+0x12ff8>
   622eb:	mov    ecx,0x1
   622f0:	add    cl,al
   622f2:	mov    rax,QWORD PTR [r12+0x8]
   622f7:	mov    rdx,QWORD PTR [r12]
   622fb:	mov    QWORD PTR [rax+0x8],rdx
   622ff:	mov    eax,ecx
   62301:	mov    rdx,QWORD PTR [r12+0x8]
   62306:	cmp    BYTE PTR [r12+0x11],0x0
   6230c:	je     62375 <sqlite3VdbeExec+0x12ed5>
   6230e:	cmp    r12,QWORD PTR [rdx+0x80]
   62315:	je     6232f <sqlite3VdbeExec+0x12e8f>
   62317:	movzx  esi,WORD PTR [rdx+0x28]
   6231b:	and    esi,0x40
   6231e:	test   esi,esi
   62320:	je     6232f <sqlite3VdbeExec+0x12e8f>
   62322:	mov    eax,0x106
   62327:	mov    rcx,rax
   6232a:	jmp    62498 <sqlite3VdbeExec+0x12ff8>
   6232f:	mov    rsi,QWORD PTR [rdx+0x78]
   62333:	jmp    62339 <sqlite3VdbeExec+0x12e99>
   62335:	mov    rsi,QWORD PTR [rsi+0x10]
   62339:	test   rsi,rsi
   6233c:	je     62375 <sqlite3VdbeExec+0x12ed5>
   6233e:	cmp    r12,QWORD PTR [rsi]
   62341:	je     62335 <sqlite3VdbeExec+0x12e95>
   62343:	cmp    r13d,DWORD PTR [rsi+0x8]
   62347:	jne    62335 <sqlite3VdbeExec+0x12e95>
   62349:	movzx  r8d,BYTE PTR [rsi+0xc]
   6234e:	mov    r9d,eax
   62351:	cmp    r8d,r9d
   62354:	je     62335 <sqlite3VdbeExec+0x12e95>
   62356:	cmp    eax,0x2
   62359:	jne    62368 <sqlite3VdbeExec+0x12ec8>
   6235b:	movzx  eax,WORD PTR [rdx+0x28]
   6235f:	or     eax,0x80
   62364:	mov    WORD PTR [rdx+0x28],ax
   62368:	mov    eax,0x106
   6236d:	mov    rcx,rax
   62370:	jmp    62498 <sqlite3VdbeExec+0x12ff8>
   62375:	mov    DWORD PTR [rsp+0x33c],r13d
   6237d:	mov    r13d,ecx
   62380:	mov    DWORD PTR [rsp+0x344],r13d
   62388:	mov    r13,QWORD PTR [r12+0x8]
   6238d:	mov    rax,QWORD PTR [r13+0x78]
   62391:	jmp    62397 <sqlite3VdbeExec+0x12ef7>
   62393:	mov    rax,QWORD PTR [rax+0x10]
   62397:	test   rax,rax
   6239a:	jne    623ae <sqlite3VdbeExec+0x12f0e>
   6239c:	mov    DWORD PTR [rsp+0x31c],r15d
   623a4:	mov    r15d,DWORD PTR [rsp+0x33c]
   623ac:	jmp    623f7 <sqlite3VdbeExec+0x12f57>
   623ae:	mov    DWORD PTR [rsp+0x31c],r15d
   623b6:	mov    r15d,DWORD PTR [rsp+0x33c]
   623be:	cmp    r15d,DWORD PTR [rax+0x8]
   623c2:	je     623ce <sqlite3VdbeExec+0x12f2e>
   623c4:	mov    r15d,DWORD PTR [rsp+0x31c]
   623cc:	jmp    62393 <sqlite3VdbeExec+0x12ef3>
   623ce:	cmp    r12,QWORD PTR [rax]
   623d1:	je     623e5 <sqlite3VdbeExec+0x12f45>
   623d3:	mov    DWORD PTR [rsp+0x33c],r15d
   623db:	mov    r15d,DWORD PTR [rsp+0x31c]
   623e3:	jmp    62393 <sqlite3VdbeExec+0x12ef3>
   623e5:	test   rax,rax
   623e8:	je     623f7 <sqlite3VdbeExec+0x12f57>
   623ea:	mov    r13d,DWORD PTR [rsp+0x344]
   623f2:	jmp    6247c <sqlite3VdbeExec+0x12fdc>
   623f7:	mov    DWORD PTR [rsp+0x33c],r15d
   623ff:	mov    r15d,0x18
   62405:	mov    QWORD PTR [rsp+0xb0],rdi
   6240d:	mov    rdi,r15
   62410:	call   62415 <sqlite3VdbeExec+0x12f75>
   62415:	mov    rdi,QWORD PTR [rsp+0xb0]
   6241d:	test   rax,rax
   62420:	je     6244d <sqlite3VdbeExec+0x12fad>
   62422:	xor    ecx,ecx
   62424:	mov    QWORD PTR [rsp+0xa8],rax
   6242c:	mov    rdi,rax
   6242f:	mov    rsi,rcx
   62432:	mov    rdx,r15
   62435:	call   6243a <sqlite3VdbeExec+0x12f9a>
   6243a:	mov    rcx,rax
   6243d:	mov    rax,QWORD PTR [rsp+0xa8]
   62445:	mov    rdi,QWORD PTR [rsp+0xb0]
   6244d:	test   rax,rax
   62450:	jne    62459 <sqlite3VdbeExec+0x12fb9>
   62452:	mov    eax,0x7
   62457:	jmp    6248d <sqlite3VdbeExec+0x12fed>
   62459:	mov    r15d,DWORD PTR [rsp+0x33c]
   62461:	mov    DWORD PTR [rax+0x8],r15d
   62465:	mov    QWORD PTR [rax],r12
   62468:	mov    rcx,QWORD PTR [r13+0x78]
   6246c:	mov    QWORD PTR [rax+0x10],rcx
   62470:	mov    QWORD PTR [r13+0x78],rax
   62474:	mov    r13d,DWORD PTR [rsp+0x344]
   6247c:	mov    ecx,r13d
   6247f:	movzx  edx,BYTE PTR [rax+0xc]
   62483:	cmp    ecx,edx
   62485:	jle    6248b <sqlite3VdbeExec+0x12feb>
   62487:	mov    BYTE PTR [rax+0xc],r13b
   6248b:	xor    eax,eax
   6248d:	mov    r15d,DWORD PTR [rsp+0x31c]
   62495:	mov    rcx,rax
   62498:	mov    r12d,ecx
   6249b:	test   r12d,r12d
   6249e:	je     624f5 <sqlite3VdbeExec+0x13055>
   624a0:	mov    eax,r12d
   624a3:	and    eax,0xff
   624a8:	cmp    eax,0x6
   624ab:	jne    624d5 <sqlite3VdbeExec+0x13035>
   624ad:	mov    rax,QWORD PTR [rbp+0x10]
   624b1:	lea    rcx,[rip+0x0]        # 624b8 <sqlite3VdbeExec+0x13018>
   624b8:	mov    QWORD PTR [rsp+0xb0],rdi
   624c0:	mov    rsi,rcx
   624c3:	mov    rdx,rax
   624c6:	xor    eax,eax
   624c8:	call   624cd <sqlite3VdbeExec+0x1302d>
   624cd:	mov    rdi,QWORD PTR [rsp+0xb0]
   624d5:	mov    QWORD PTR [rsp+0xe8],rbp
   624dd:	mov    rbp,r12
   624e0:	mov    r13,QWORD PTR [rsp+0xd0]
   624e8:	mov    rbx,QWORD PTR [rsp+0xf8]
   624f0:	jmp    4f712 <sqlite3VdbeExec+0x272>
   624f5:	mov    DWORD PTR [rsp+0x31c],r15d
   624fd:	mov    DWORD PTR [rsp+0x32c],r12d
   62505:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   6250a:	mov    r15d,DWORD PTR [rsp+0x31c]
   62512:	mov    QWORD PTR [rsp+0xd0],r12
   6251a:	mov    r12,QWORD PTR [rbp+0x10]
   6251e:	xor    r13d,r13d
   62521:	cmp    DWORD PTR [r14+0x21c],0x0
   62529:	jle    62548 <sqlite3VdbeExec+0x130a8>
   6252b:	cmp    QWORD PTR [r14+0x240],0x0
   62533:	jne    62548 <sqlite3VdbeExec+0x130a8>
   62535:	mov    r13d,0x6
   6253b:	mov    DWORD PTR [rsp+0x344],r13d
   62543:	jmp    627bb <sqlite3VdbeExec+0x1331b>
   62548:	test   r12,r12
   6254b:	jne    6255d <sqlite3VdbeExec+0x130bd>
   6254d:	xor    r13d,r13d
   62550:	mov    DWORD PTR [rsp+0x344],r13d
   62558:	jmp    627bb <sqlite3VdbeExec+0x1331b>
   6255d:	mov    rax,QWORD PTR [r12+0x10]
   62562:	mov    r13,QWORD PTR [rax]
   62565:	cmp    QWORD PTR [r13+0x70],0x0
   6256a:	jne    6257c <sqlite3VdbeExec+0x130dc>
   6256c:	xor    r11d,r11d
   6256f:	mov    DWORD PTR [rsp+0x344],r11d
   62577:	jmp    627bb <sqlite3VdbeExec+0x1331b>
   6257c:	xor    eax,eax
   6257e:	jmp    62583 <sqlite3VdbeExec+0x130e3>
   62580:	add    eax,0x1
   62583:	cmp    eax,DWORD PTR [r14+0x21c]
   6258a:	jge    625ac <sqlite3VdbeExec+0x1310c>
   6258c:	mov    rcx,QWORD PTR [r14+0x240]
   62593:	mov    rdx,rax
   62596:	cmp    r12,QWORD PTR [rcx+rdx*8]
   6259a:	jne    62580 <sqlite3VdbeExec+0x130e0>
   6259c:	xor    r13d,r13d
   6259f:	mov    DWORD PTR [rsp+0x344],r13d
   625a7:	jmp    627bb <sqlite3VdbeExec+0x1331b>
   625ac:	mov    eax,DWORD PTR [r14+0x21c]
   625b3:	mov    r11d,eax
   625b6:	mov    eax,0x66666667
   625bb:	imul   r11d
   625be:	sar    edx,0x1
   625c1:	mov    eax,edx
   625c3:	shr    eax,0x1f
   625c6:	add    edx,eax
   625c8:	imul   edx,edx,0x5
   625cb:	neg    edx
   625cd:	add    edx,r11d
   625d0:	mov    eax,edx
   625d2:	test   eax,eax
   625d4:	je     625e3 <sqlite3VdbeExec+0x13143>
   625d6:	mov    QWORD PTR [rsp+0x108],r13
   625de:	jmp    626c8 <sqlite3VdbeExec+0x13228>
   625e3:	movsxd rax,DWORD PTR [r14+0x21c]
   625ea:	add    rax,0x5
   625ee:	shl    rax,0x3
   625f2:	mov    QWORD PTR [rsp+0x108],r13
   625fa:	mov    r13,QWORD PTR [r14+0x240]
   62601:	test   r13,r13
   62604:	jne    62626 <sqlite3VdbeExec+0x13186>
   62606:	mov    QWORD PTR [rsp+0xb0],rdi
   6260e:	mov    rdi,r14
   62611:	mov    rsi,rax
   62614:	call   62619 <sqlite3VdbeExec+0x13179>
   62619:	mov    r13,rax
   6261c:	mov    rdi,QWORD PTR [rsp+0xb0]
   62624:	jmp    6267b <sqlite3VdbeExec+0x131db>
   62626:	cmp    r13,QWORD PTR [r14+0x1e8]
   6262d:	jae    6265a <sqlite3VdbeExec+0x131ba>
   6262f:	cmp    r13,QWORD PTR [r14+0x1d8]
   62636:	jb     62642 <sqlite3VdbeExec+0x131a2>
   62638:	cmp    rax,0x80
   6263e:	ja     6265a <sqlite3VdbeExec+0x131ba>
   62640:	jmp    6267b <sqlite3VdbeExec+0x131db>
   62642:	cmp    r13,QWORD PTR [r14+0x1e0]
   62649:	jb     6265a <sqlite3VdbeExec+0x131ba>
   6264b:	movzx  ecx,WORD PTR [r14+0x19e]
   62653:	cmp    rax,rcx
   62656:	ja     6265a <sqlite3VdbeExec+0x131ba>
   62658:	jmp    6267b <sqlite3VdbeExec+0x131db>
   6265a:	mov    QWORD PTR [rsp+0xb0],rdi
   62662:	mov    rdi,r14
   62665:	mov    rsi,r13
   62668:	mov    rdx,rax
   6266b:	call   62670 <sqlite3VdbeExec+0x131d0>
   62670:	mov    r13,rax
   62673:	mov    rdi,QWORD PTR [rsp+0xb0]
   6267b:	test   r13,r13
   6267e:	jne    62693 <sqlite3VdbeExec+0x131f3>
   62680:	mov    r13d,0x7
   62686:	mov    DWORD PTR [rsp+0x344],r13d
   6268e:	jmp    627bb <sqlite3VdbeExec+0x1331b>
   62693:	movsxd rax,DWORD PTR [r14+0x21c]
   6269a:	lea    rax,[r13+rax*8+0x0]
   6269f:	xor    ecx,ecx
   626a1:	mov    edx,0x28
   626a6:	mov    QWORD PTR [rsp+0xb0],rdi
   626ae:	mov    rdi,rax
   626b1:	mov    rsi,rcx
   626b4:	call   626b9 <sqlite3VdbeExec+0x13219>
   626b9:	mov    QWORD PTR [r14+0x240],r13
   626c0:	mov    rdi,QWORD PTR [rsp+0xb0]
   626c8:	mov    r13,QWORD PTR [rsp+0x108]
   626d0:	mov    rax,QWORD PTR [r13+0x70]
   626d4:	mov    rcx,QWORD PTR [r12+0x10]
   626d9:	mov    DWORD PTR [rsp+0x31c],r15d
   626e1:	mov    QWORD PTR [rsp+0xb0],rdi
   626e9:	mov    rdi,rcx
   626ec:	mov    r10,rax
   626ef:	call   r10
   626f2:	mov    r15d,eax
   626f5:	mov    rdi,QWORD PTR [rsp+0xb0]
   626fd:	test   r15d,r15d
   62700:	je     62717 <sqlite3VdbeExec+0x13277>
   62702:	mov    DWORD PTR [rsp+0x344],r15d
   6270a:	mov    r15d,DWORD PTR [rsp+0x31c]
   62712:	jmp    627bb <sqlite3VdbeExec+0x1331b>
   62717:	mov    eax,DWORD PTR [r14+0x2ec]
   6271e:	add    eax,DWORD PTR [r14+0x2e8]
   62725:	mov    rcx,QWORD PTR [r14+0x240]
   6272c:	movsxd rdx,DWORD PTR [r14+0x21c]
   62733:	lea    esi,[rdx+0x1]
   62736:	mov    DWORD PTR [r14+0x21c],esi
   6273d:	mov    QWORD PTR [rcx+rdx*8],r12
   62741:	mov    ecx,DWORD PTR [r12+0x18]
   62746:	add    ecx,0x1
   62749:	mov    DWORD PTR [r12+0x18],ecx
   6274e:	test   eax,eax
   62750:	jne    62764 <sqlite3VdbeExec+0x132c4>
   62752:	mov    DWORD PTR [rsp+0x344],r15d
   6275a:	mov    r15d,DWORD PTR [rsp+0x31c]
   62762:	jmp    627bb <sqlite3VdbeExec+0x1331b>
   62764:	cmp    QWORD PTR [r13+0xa0],0x0
   6276c:	jne    62780 <sqlite3VdbeExec+0x132e0>
   6276e:	mov    DWORD PTR [rsp+0x344],r15d
   62776:	mov    r15d,DWORD PTR [rsp+0x31c]
   6277e:	jmp    627bb <sqlite3VdbeExec+0x1331b>
   62780:	mov    DWORD PTR [r12+0x20],eax
   62785:	mov    rcx,QWORD PTR [r13+0xa0]
   6278c:	mov    rdx,QWORD PTR [r12+0x10]
   62791:	sub    eax,0x1
   62794:	mov    rdi,rdx
   62797:	mov    rsi,rax
   6279a:	mov    r10,rcx
   6279d:	call   r10
   627a0:	mov    r13d,eax
   627a3:	mov    rdi,QWORD PTR [rsp+0xb0]
   627ab:	mov    r15d,DWORD PTR [rsp+0x31c]
   627b3:	mov    DWORD PTR [rsp+0x344],r13d
   627bb:	test   r12,r12
   627be:	je     62964 <sqlite3VdbeExec+0x134c4>
   627c4:	mov    r12,QWORD PTR [r12+0x10]
   627c9:	cmp    QWORD PTR [r12+0x10],0x0
   627cf:	je     62964 <sqlite3VdbeExec+0x134c4>
   627d5:	mov    r13,QWORD PTR [rdi]
   627d8:	mov    rax,QWORD PTR [rdi+0xa8]
   627df:	test   rax,rax
   627e2:	je     627ff <sqlite3VdbeExec+0x1335f>
   627e4:	mov    QWORD PTR [rsp+0xb0],rdi
   627ec:	mov    rdi,r13
   627ef:	mov    rsi,rax
   627f2:	call   627f7 <sqlite3VdbeExec+0x13357>
   627f7:	mov    rdi,QWORD PTR [rsp+0xb0]
   627ff:	mov    QWORD PTR [rsp+0x108],r12
   62807:	mov    r12,QWORD PTR [r12+0x10]
   6280c:	test   r12,r12
   6280f:	jne    62824 <sqlite3VdbeExec+0x13384>
   62811:	xor    r12d,r12d
   62814:	mov    r13,r12
   62817:	mov    r12,QWORD PTR [rsp+0x108]
   6281f:	jmp    628c5 <sqlite3VdbeExec+0x13425>
   62824:	mov    QWORD PTR [rsp+0xb0],rdi
   6282c:	mov    rdi,r12
   6282f:	call   62834 <sqlite3VdbeExec+0x13394>
   62834:	mov    QWORD PTR [rsp+0x130],r12
   6283c:	lea    r12,[rax+0x1]
   62840:	mov    rdi,QWORD PTR [rsp+0xb0]
   62848:	test   r13,r13
   6284b:	je     62865 <sqlite3VdbeExec+0x133c5>
   6284d:	mov    rdi,r13
   62850:	mov    rsi,r12
   62853:	call   62858 <sqlite3VdbeExec+0x133b8>
   62858:	mov    r13,rax
   6285b:	mov    rdi,QWORD PTR [rsp+0xb0]
   62863:	jmp    62878 <sqlite3VdbeExec+0x133d8>
   62865:	mov    rdi,r12
   62868:	call   6286d <sqlite3VdbeExec+0x133cd>
   6286d:	mov    r13,rax
   62870:	mov    rdi,QWORD PTR [rsp+0xb0]
   62878:	test   r13,r13
   6287b:	jne    62887 <sqlite3VdbeExec+0x133e7>
   6287d:	mov    DWORD PTR [rsp+0x31c],r15d
   62885:	jmp    628b5 <sqlite3VdbeExec+0x13415>
   62887:	mov    DWORD PTR [rsp+0x31c],r15d
   6288f:	mov    r15,QWORD PTR [rsp+0x130]
   62897:	mov    QWORD PTR [rsp+0xb0],rdi
   6289f:	mov    rdi,r13
   628a2:	mov    rsi,r15
   628a5:	mov    rdx,r12
   628a8:	call   628ad <sqlite3VdbeExec+0x1340d>
   628ad:	mov    rdi,QWORD PTR [rsp+0xb0]
   628b5:	mov    r15d,DWORD PTR [rsp+0x31c]
   628bd:	mov    r12,QWORD PTR [rsp+0x108]
   628c5:	mov    QWORD PTR [rdi+0xa8],r13
   628cc:	mov    r13,QWORD PTR [r12+0x10]
   628d1:	test   r13,r13
   628d4:	je     6295b <sqlite3VdbeExec+0x134bb>
   628da:	cmp    DWORD PTR [rip+0x0],0x0        # 628e1 <sqlite3VdbeExec+0x13441>
   628e1:	je     6293b <sqlite3VdbeExec+0x1349b>
   628e3:	mov    rax,QWORD PTR [rip+0x0]        # 628ea <sqlite3VdbeExec+0x1344a>
   628ea:	mov    QWORD PTR [rsp+0xb0],rdi
   628f2:	mov    rdi,r13
   628f5:	mov    r10,rax
   628f8:	call   r10
   628fb:	mov    rcx,QWORD PTR [rip+0x0]        # 62902 <sqlite3VdbeExec+0x13462>
   62902:	movsxd rax,eax
   62905:	sub    rcx,rax
   62908:	mov    QWORD PTR [rip+0x0],rcx        # 6290f <sqlite3VdbeExec+0x1346f>
   6290f:	mov    rax,QWORD PTR [rip+0x0]        # 62916 <sqlite3VdbeExec+0x13476>
   62916:	sub    rax,0x1
   6291a:	mov    QWORD PTR [rip+0x0],rax        # 62921 <sqlite3VdbeExec+0x13481>
   62921:	mov    rax,QWORD PTR [rip+0x0]        # 62928 <sqlite3VdbeExec+0x13488>
   62928:	mov    rdi,r13
   6292b:	mov    r10,rax
   6292e:	call   r10
   62931:	mov    rdi,QWORD PTR [rsp+0xb0]
   62939:	jmp    6295b <sqlite3VdbeExec+0x134bb>
   6293b:	mov    rax,QWORD PTR [rip+0x0]        # 62942 <sqlite3VdbeExec+0x134a2>
   62942:	mov    QWORD PTR [rsp+0xb0],rdi
   6294a:	mov    rdi,r13
   6294d:	mov    r10,rax
   62950:	call   r10
   62953:	mov    rdi,QWORD PTR [rsp+0xb0]
   6295b:	mov    QWORD PTR [r12+0x10],0x0
   62964:	mov    r12d,DWORD PTR [rsp+0x344]
   6296c:	test   r12d,r12d
   6296f:	je     62991 <sqlite3VdbeExec+0x134f1>
   62971:	mov    QWORD PTR [rsp+0xe8],rbp
   62979:	mov    rbp,r12
   6297c:	mov    r13,QWORD PTR [rsp+0xd0]
   62984:	mov    rbx,QWORD PTR [rsp+0xf8]
   6298c:	jmp    4f712 <sqlite3VdbeExec+0x272>
   62991:	mov    DWORD PTR [rsp+0x31c],r15d
   62999:	mov    DWORD PTR [rsp+0x32c],r12d
   629a1:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   629a6:	mov    r15d,DWORD PTR [rsp+0x31c]
   629ae:	mov    QWORD PTR [rsp+0xd0],r12
   629b6:	lea    r12,[rsp+0x218]
   629be:	mov    rax,r12
   629c1:	xor    ecx,ecx
   629c3:	mov    edx,0x38
   629c8:	mov    QWORD PTR [rsp+0xb0],rdi
   629d0:	mov    rdi,rax
   629d3:	mov    rsi,rcx
   629d6:	call   629db <sqlite3VdbeExec+0x1353b>
   629db:	mov    QWORD PTR [rsp+0x230],r14
   629e3:	mov    rax,r12
   629e6:	movsxd rcx,DWORD PTR [rbp+0x8]
   629ea:	imul   rcx,rcx,0x38
   629ee:	add    rcx,rbx
   629f1:	mov    rdi,rax
   629f4:	mov    rsi,rcx
   629f7:	call   629fc <sqlite3VdbeExec+0x1355c>
   629fc:	mov    r13d,eax
   629ff:	mov    rax,r12
   62a02:	mov    rdi,QWORD PTR [rsp+0xb0]
   62a0a:	test   rax,rax
   62a0d:	jne    62a13 <sqlite3VdbeExec+0x13573>
   62a0f:	xor    eax,eax
   62a11:	jmp    62a60 <sqlite3VdbeExec+0x135c0>
   62a13:	movzx  ecx,WORD PTR [rax+0x14]
   62a17:	and    ecx,0x202
   62a1d:	cmp    ecx,0x202
   62a23:	jne    62a31 <sqlite3VdbeExec+0x13591>
   62a25:	cmp    BYTE PTR [rax+0x16],0x1
   62a29:	jne    62a31 <sqlite3VdbeExec+0x13591>
   62a2b:	mov    rax,QWORD PTR [rax+0x8]
   62a2f:	jmp    62a60 <sqlite3VdbeExec+0x135c0>
   62a31:	movzx  ecx,WORD PTR [rax+0x14]
   62a35:	and    ecx,0x1
   62a38:	test   ecx,ecx
   62a3a:	je     62a40 <sqlite3VdbeExec+0x135a0>
   62a3c:	xor    eax,eax
   62a3e:	jmp    62a60 <sqlite3VdbeExec+0x135c0>
   62a40:	mov    ecx,0x1
   62a45:	mov    QWORD PTR [rsp+0xb0],rdi
   62a4d:	mov    rdi,rax
   62a50:	mov    rsi,rcx
   62a53:	call   62a58 <sqlite3VdbeExec+0x135b8>
   62a58:	mov    rdi,QWORD PTR [rsp+0xb0]
   62a60:	test   rax,rax
   62a63:	je     62dac <sqlite3VdbeExec+0x1390c>
   62a69:	movsxd rcx,DWORD PTR [rbp+0x4]
   62a6d:	lea    r13,[rdi+0xa8]
   62a74:	mov    rdx,QWORD PTR [r14+0x20]
   62a78:	shl    rcx,0x5
   62a7c:	mov    rcx,QWORD PTR [rdx+rcx*1]
   62a80:	mov    QWORD PTR [rsp+0xb0],rdi
   62a88:	mov    rdi,r14
   62a8b:	mov    rsi,rax
   62a8e:	mov    rdx,rcx
   62a91:	call   62a96 <sqlite3VdbeExec+0x135f6>
   62a96:	mov    r12,rax
   62a99:	mov    rax,QWORD PTR [r12+0x48]
   62a9e:	mov    rcx,QWORD PTR [rax]
   62aa1:	xor    eax,eax
   62aa3:	mov    rdi,QWORD PTR [rsp+0xb0]
   62aab:	mov    rsi,rcx
   62aae:	jmp    62ac5 <sqlite3VdbeExec+0x13625>
   62ab0:	movzx  edx,BYTE PTR [rsi]
   62ab3:	add    rsi,0x1
   62ab7:	and    edx,0xdf
   62abd:	add    eax,edx
   62abf:	imul   eax,eax,0x9e3779b1
   62ac5:	cmp    BYTE PTR [rsi],0x0
   62ac8:	jne    62ab0 <sqlite3VdbeExec+0x13610>
   62aca:	mov    esi,eax
   62acc:	cmp    QWORD PTR [r14+0x230],0x0
   62ad4:	je     62b06 <sqlite3VdbeExec+0x13666>
   62ad6:	mov    r8,QWORD PTR [r14+0x230]
   62add:	mov    r9d,DWORD PTR [r14+0x220]
   62ae4:	mov    rax,rsi
   62ae7:	xor    edx,edx
   62ae9:	div    r9d
   62aec:	mov    eax,edx
   62aee:	shl    rax,0x4
   62af2:	mov    rdx,QWORD PTR [r8+rax*1+0x8]
   62af7:	mov    eax,DWORD PTR [r8+rax*1]
   62afb:	mov    r11,rax
   62afe:	mov    rax,rdx
   62b01:	mov    rdx,r11
   62b04:	jmp    62b14 <sqlite3VdbeExec+0x13674>
   62b06:	mov    rax,QWORD PTR [r14+0x228]
   62b0d:	mov    edx,DWORD PTR [r14+0x224]
   62b14:	mov    QWORD PTR [rsp+0x108],rcx
   62b1c:	mov    r10,rax
   62b1f:	mov    rcx,rdx
   62b22:	jmp    62ba2 <sqlite3VdbeExec+0x13702>
   62b24:	mov    QWORD PTR [rsp+0x130],r10
   62b2c:	lea    r10,[rip+0x0]        # 62b33 <sqlite3VdbeExec+0x13693>
   62b33:	movzx  edx,BYTE PTR [r10+rdx*1]
   62b38:	movzx  r9d,BYTE PTR [r10+r9*1]
   62b3d:	sub    edx,r9d
   62b40:	test   edx,edx
   62b42:	je     62b64 <sqlite3VdbeExec+0x136c4>
   62b44:	test   edx,edx
   62b46:	je     62b52 <sqlite3VdbeExec+0x136b2>
   62b48:	mov    r10,QWORD PTR [rsp+0x130]
   62b50:	jmp    62b9c <sqlite3VdbeExec+0x136fc>
   62b52:	mov    rcx,QWORD PTR [rsp+0x108]
   62b5a:	mov    rax,QWORD PTR [rsp+0x130]
   62b62:	jmp    62bc9 <sqlite3VdbeExec+0x13729>
   62b64:	add    rax,0x1
   62b68:	add    r8,0x1
   62b6c:	mov    r10,QWORD PTR [rsp+0x130]
   62b74:	movzx  edx,BYTE PTR [rax]
   62b77:	movzx  r9d,BYTE PTR [r8]
   62b7b:	cmp    edx,r9d
   62b7e:	jne    62b24 <sqlite3VdbeExec+0x13684>
   62b80:	test   edx,edx
   62b82:	je     62b8e <sqlite3VdbeExec+0x136ee>
   62b84:	mov    QWORD PTR [rsp+0x130],r10
   62b8c:	jmp    62b64 <sqlite3VdbeExec+0x136c4>
   62b8e:	test   edx,edx
   62b90:	jne    62b9c <sqlite3VdbeExec+0x136fc>
   62b92:	mov    QWORD PTR [rsp+0x130],r10
   62b9a:	jmp    62b52 <sqlite3VdbeExec+0x136b2>
   62b9c:	mov    r10,QWORD PTR [r10]
   62b9f:	sub    ecx,0x1
   62ba2:	test   ecx,ecx
   62ba4:	je     62bba <sqlite3VdbeExec+0x1371a>
   62ba6:	cmp    esi,DWORD PTR [r10+0x20]
   62baa:	jne    62b9c <sqlite3VdbeExec+0x136fc>
   62bac:	mov    rax,QWORD PTR [r10+0x18]
   62bb0:	mov    r8,QWORD PTR [rsp+0x108]
   62bb8:	jmp    62b74 <sqlite3VdbeExec+0x136d4>
   62bba:	lea    rax,[rip+0x0]        # 62bc1 <sqlite3VdbeExec+0x13721>
   62bc1:	mov    rcx,QWORD PTR [rsp+0x108]
   62bc9:	mov    rax,QWORD PTR [rax+0x10]
   62bcd:	test   rax,rax
   62bd0:	je     62be6 <sqlite3VdbeExec+0x13746>
   62bd2:	mov    rdx,QWORD PTR [rax]
   62bd5:	cmp    QWORD PTR [rdx+0x8],0x0
   62bda:	je     62be6 <sqlite3VdbeExec+0x13746>
   62bdc:	mov    rdx,QWORD PTR [rax]
   62bdf:	cmp    QWORD PTR [rdx+0x28],0x0
   62be4:	jne    62c18 <sqlite3VdbeExec+0x13778>
   62be6:	lea    rax,[rip+0x0]        # 62bed <sqlite3VdbeExec+0x1374d>
   62bed:	mov    QWORD PTR [rsp+0xb0],rdi
   62bf5:	mov    rdi,r14
   62bf8:	mov    rsi,rax
   62bfb:	mov    rdx,rcx
   62bfe:	xor    eax,eax
   62c00:	call   62c05 <sqlite3VdbeExec+0x13765>
   62c05:	mov    QWORD PTR [r13+0x0],rax
   62c09:	mov    eax,0x1
   62c0e:	mov    rdi,QWORD PTR [rsp+0xb0]
   62c16:	jmp    62c40 <sqlite3VdbeExec+0x137a0>
   62c18:	mov    rcx,QWORD PTR [rax]
   62c1b:	mov    rcx,QWORD PTR [rcx+0x8]
   62c1f:	mov    QWORD PTR [rsp+0xb0],rdi
   62c27:	mov    rdi,r14
   62c2a:	mov    rsi,r12
   62c2d:	mov    rdx,rax
   62c30:	mov    r8,r13
   62c33:	call   62c38 <sqlite3VdbeExec+0x13798>
   62c38:	mov    rdi,QWORD PTR [rsp+0xb0]
   62c40:	test   eax,eax
   62c42:	jne    62da6 <sqlite3VdbeExec+0x13906>
   62c48:	mov    rcx,QWORD PTR [r12+0x50]
   62c4d:	jmp    62c58 <sqlite3VdbeExec+0x137b8>
   62c4f:	cmp    r14,QWORD PTR [rcx]
   62c52:	je     62c5d <sqlite3VdbeExec+0x137bd>
   62c54:	mov    rcx,QWORD PTR [rcx+0x28]
   62c58:	test   rcx,rcx
   62c5b:	jne    62c4f <sqlite3VdbeExec+0x137af>
   62c5d:	test   rcx,rcx
   62c60:	je     62da6 <sqlite3VdbeExec+0x13906>
   62c66:	mov    eax,DWORD PTR [r14+0x21c]
   62c6d:	mov    r11d,eax
   62c70:	mov    eax,0x66666667
   62c75:	imul   r11d
   62c78:	sar    edx,0x1
   62c7b:	mov    eax,edx
   62c7d:	shr    eax,0x1f
   62c80:	add    edx,eax
   62c82:	imul   edx,edx,0x5
   62c85:	neg    edx
   62c87:	add    edx,r11d
   62c8a:	mov    eax,edx
   62c8c:	test   eax,eax
   62c8e:	jne    62d65 <sqlite3VdbeExec+0x138c5>
   62c94:	movsxd rax,DWORD PTR [r14+0x21c]
   62c9b:	add    rax,0x5
   62c9f:	shl    rax,0x3
   62ca3:	mov    r13,QWORD PTR [r14+0x240]
   62caa:	test   r13,r13
   62cad:	jne    62ccf <sqlite3VdbeExec+0x1382f>
   62caf:	mov    QWORD PTR [rsp+0xb0],rdi
   62cb7:	mov    rdi,r14
   62cba:	mov    rsi,rax
   62cbd:	call   62cc2 <sqlite3VdbeExec+0x13822>
   62cc2:	mov    r13,rax
   62cc5:	mov    rdi,QWORD PTR [rsp+0xb0]
   62ccd:	jmp    62d24 <sqlite3VdbeExec+0x13884>
   62ccf:	cmp    r13,QWORD PTR [r14+0x1e8]
   62cd6:	jae    62d03 <sqlite3VdbeExec+0x13863>
   62cd8:	cmp    r13,QWORD PTR [r14+0x1d8]
   62cdf:	jb     62ceb <sqlite3VdbeExec+0x1384b>
   62ce1:	cmp    rax,0x80
   62ce7:	ja     62d03 <sqlite3VdbeExec+0x13863>
   62ce9:	jmp    62d24 <sqlite3VdbeExec+0x13884>
   62ceb:	cmp    r13,QWORD PTR [r14+0x1e0]
   62cf2:	jb     62d03 <sqlite3VdbeExec+0x13863>
   62cf4:	movzx  ecx,WORD PTR [r14+0x19e]
   62cfc:	cmp    rax,rcx
   62cff:	ja     62d03 <sqlite3VdbeExec+0x13863>
   62d01:	jmp    62d24 <sqlite3VdbeExec+0x13884>
   62d03:	mov    QWORD PTR [rsp+0xb0],rdi
   62d0b:	mov    rdi,r14
   62d0e:	mov    rsi,r13
   62d11:	mov    rdx,rax
   62d14:	call   62d19 <sqlite3VdbeExec+0x13879>
   62d19:	mov    r13,rax
   62d1c:	mov    rdi,QWORD PTR [rsp+0xb0]
   62d24:	test   r13,r13
   62d27:	jne    62d30 <sqlite3VdbeExec+0x13890>
   62d29:	mov    eax,0x7
   62d2e:	jmp    62d67 <sqlite3VdbeExec+0x138c7>
   62d30:	movsxd rax,DWORD PTR [r14+0x21c]
   62d37:	lea    rax,[r13+rax*8+0x0]
   62d3c:	xor    ecx,ecx
   62d3e:	mov    edx,0x28
   62d43:	mov    QWORD PTR [rsp+0xb0],rdi
   62d4b:	mov    rdi,rax
   62d4e:	mov    rsi,rcx
   62d51:	call   62d56 <sqlite3VdbeExec+0x138b6>
   62d56:	mov    QWORD PTR [r14+0x240],r13
   62d5d:	mov    rdi,QWORD PTR [rsp+0xb0]
   62d65:	xor    eax,eax
   62d67:	test   eax,eax
   62d69:	jne    62da6 <sqlite3VdbeExec+0x13906>
   62d6b:	mov    rcx,QWORD PTR [r12+0x50]
   62d70:	jmp    62d7b <sqlite3VdbeExec+0x138db>
   62d72:	cmp    r14,QWORD PTR [rcx]
   62d75:	je     62d80 <sqlite3VdbeExec+0x138e0>
   62d77:	mov    rcx,QWORD PTR [rcx+0x28]
   62d7b:	test   rcx,rcx
   62d7e:	jne    62d72 <sqlite3VdbeExec+0x138d2>
   62d80:	mov    rdx,QWORD PTR [r14+0x240]
   62d87:	movsxd rsi,DWORD PTR [r14+0x21c]
   62d8e:	lea    r8d,[rsi+0x1]
   62d92:	mov    DWORD PTR [r14+0x21c],r8d
   62d99:	mov    QWORD PTR [rdx+rsi*8],rcx
   62d9d:	mov    edx,DWORD PTR [rcx+0x18]
   62da0:	add    edx,0x1
   62da3:	mov    DWORD PTR [rcx+0x18],edx
   62da6:	mov    r12d,eax
   62da9:	mov    r13,r12
   62dac:	lea    r12,[rsp+0x218]
   62db4:	mov    rax,r12
   62db7:	movzx  ecx,WORD PTR [rsp+0x22c]
   62dbf:	and    ecx,0x9000
   62dc5:	test   ecx,ecx
   62dc7:	jne    62dcf <sqlite3VdbeExec+0x1392f>
   62dc9:	cmp    DWORD PTR [rax+0x20],0x0
   62dcd:	je     62de7 <sqlite3VdbeExec+0x13947>
   62dcf:	mov    QWORD PTR [rsp+0xb0],rdi
   62dd7:	mov    rdi,rax
   62dda:	call   62ddf <sqlite3VdbeExec+0x1393f>
   62ddf:	mov    rdi,QWORD PTR [rsp+0xb0]
   62de7:	test   r13d,r13d
   62dea:	je     62e0c <sqlite3VdbeExec+0x1396c>
   62dec:	mov    QWORD PTR [rsp+0xe8],rbp
   62df4:	mov    rbp,r13
   62df7:	mov    r13,QWORD PTR [rsp+0xd0]
   62dff:	mov    rbx,QWORD PTR [rsp+0xf8]
   62e07:	jmp    4f712 <sqlite3VdbeExec+0x272>
   62e0c:	mov    DWORD PTR [rsp+0x31c],r15d
   62e14:	mov    DWORD PTR [rsp+0x32c],r13d
   62e1c:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   62e21:	mov    r15d,DWORD PTR [rsp+0x31c]
   62e29:	mov    QWORD PTR [rsp+0xd0],r12
   62e31:	mov    eax,DWORD PTR [r14+0xe0]
   62e38:	add    eax,0x1
   62e3b:	mov    DWORD PTR [r14+0xe0],eax
   62e42:	movsxd rax,DWORD PTR [rbp+0x4]
   62e46:	mov    rcx,QWORD PTR [rbp+0x10]
   62e4a:	xor    r13d,r13d
   62e4d:	mov    rdx,QWORD PTR [r14+0x20]
   62e51:	shl    rax,0x5
   62e55:	mov    rax,QWORD PTR [rdx+rax*1]
   62e59:	mov    QWORD PTR [rsp+0xb0],rdi
   62e61:	mov    rdi,r14
   62e64:	mov    rsi,rcx
   62e67:	mov    rdx,rax
   62e6a:	call   62e6f <sqlite3VdbeExec+0x139cf>
   62e6f:	mov    r12,rax
   62e72:	mov    rdi,QWORD PTR [rsp+0xb0]
   62e7a:	test   r12,r12
   62e7d:	je     630d4 <sqlite3VdbeExec+0x13c34>
   62e83:	cmp    BYTE PTR [r12+0x3f],0x1
   62e89:	jne    630d4 <sqlite3VdbeExec+0x13c34>
   62e8f:	cmp    QWORD PTR [r12+0x50],0x0
   62e95:	je     630d4 <sqlite3VdbeExec+0x13c34>
   62e9b:	mov    rax,QWORD PTR [r12+0x50]
   62ea0:	jmp    62ea6 <sqlite3VdbeExec+0x13a06>
   62ea2:	mov    rax,QWORD PTR [rax+0x28]
   62ea6:	test   rax,rax
   62ea9:	je     62ec3 <sqlite3VdbeExec+0x13a23>
   62eab:	mov    rcx,QWORD PTR [rax+0x10]
   62eaf:	cmp    DWORD PTR [rcx+0x8],0x0
   62eb3:	jle    62ea2 <sqlite3VdbeExec+0x13a02>
   62eb5:	mov    r12d,0x6
   62ebb:	mov    r13,r12
   62ebe:	jmp    630d4 <sqlite3VdbeExec+0x13c34>
   62ec3:	xor    eax,eax
   62ec5:	mov    rcx,QWORD PTR [r12+0x50]
   62eca:	mov    QWORD PTR [r12+0x50],0x0
   62ed3:	jmp    62eea <sqlite3VdbeExec+0x13a4a>
   62ed5:	mov    r8,QWORD PTR [rdx+0x248]
   62edc:	mov    QWORD PTR [rcx+0x28],r8
   62ee0:	mov    QWORD PTR [rdx+0x248],rcx
   62ee7:	mov    rcx,rsi
   62eea:	test   rcx,rcx
   62eed:	je     62f10 <sqlite3VdbeExec+0x13a70>
   62eef:	mov    rdx,QWORD PTR [rcx]
   62ef2:	mov    rsi,QWORD PTR [rcx+0x28]
   62ef6:	cmp    rdx,r14
   62ef9:	jne    62ed5 <sqlite3VdbeExec+0x13a35>
   62efb:	mov    QWORD PTR [r12+0x50],rcx
   62f00:	mov    QWORD PTR [rcx+0x28],0x0
   62f08:	mov    rax,rcx
   62f0b:	mov    rcx,rsi
   62f0e:	jmp    62eea <sqlite3VdbeExec+0x13a4a>
   62f10:	mov    r13,rax
   62f13:	mov    rax,QWORD PTR [r13+0x8]
   62f17:	mov    rax,QWORD PTR [rax]
   62f1a:	mov    rax,QWORD PTR [rax+0x28]
   62f1e:	test   rax,rax
   62f21:	jne    62f2e <sqlite3VdbeExec+0x13a8e>
   62f23:	mov    rax,QWORD PTR [r13+0x8]
   62f27:	mov    rax,QWORD PTR [rax]
   62f2a:	mov    rax,QWORD PTR [rax+0x20]
   62f2e:	mov    ecx,DWORD PTR [r12+0x2c]
   62f33:	add    ecx,0x1
   62f36:	mov    DWORD PTR [r12+0x2c],ecx
   62f3b:	mov    rcx,QWORD PTR [r13+0x10]
   62f3f:	mov    DWORD PTR [rsp+0x31c],r15d
   62f47:	mov    QWORD PTR [rsp+0xb0],rdi
   62f4f:	mov    rdi,rcx
   62f52:	mov    r10,rax
   62f55:	call   r10
   62f58:	mov    r15d,eax
   62f5b:	mov    rdi,QWORD PTR [rsp+0xb0]
   62f63:	test   r15d,r15d
   62f66:	je     62f85 <sqlite3VdbeExec+0x13ae5>
   62f68:	mov    DWORD PTR [rsp+0x344],r15d
   62f70:	mov    QWORD PTR [rsp+0xe8],rbp
   62f78:	mov    QWORD PTR [rsp+0x100],rbx
   62f80:	jmp    63079 <sqlite3VdbeExec+0x13bd9>
   62f85:	mov    QWORD PTR [r13+0x10],0x0
   62f8d:	mov    QWORD PTR [r12+0x50],0x0
   62f96:	mov    DWORD PTR [rsp+0x344],r15d
   62f9e:	mov    r15,QWORD PTR [r13+0x0]
   62fa2:	mov    eax,DWORD PTR [r13+0x18]
   62fa6:	sub    eax,0x1
   62fa9:	mov    DWORD PTR [r13+0x18],eax
   62fad:	cmp    DWORD PTR [r13+0x18],0x0
   62fb2:	je     62fc9 <sqlite3VdbeExec+0x13b29>
   62fb4:	mov    QWORD PTR [rsp+0xe8],rbp
   62fbc:	mov    QWORD PTR [rsp+0x100],rbx
   62fc4:	jmp    63079 <sqlite3VdbeExec+0x13bd9>
   62fc9:	mov    rax,QWORD PTR [r13+0x10]
   62fcd:	test   rax,rax
   62fd0:	je     62fea <sqlite3VdbeExec+0x13b4a>
   62fd2:	mov    rcx,QWORD PTR [rax]
   62fd5:	mov    rcx,QWORD PTR [rcx+0x20]
   62fd9:	mov    rdi,rax
   62fdc:	mov    r10,rcx
   62fdf:	call   r10
   62fe2:	mov    rdi,QWORD PTR [rsp+0xb0]
   62fea:	mov    QWORD PTR [rsp+0x100],rbx
   62ff2:	mov    rbx,QWORD PTR [r13+0x0]
   62ff6:	mov    QWORD PTR [rsp+0xe8],rbp
   62ffe:	mov    rbp,QWORD PTR [r13+0x8]
   63002:	mov    eax,DWORD PTR [rbp+0x10]
   63005:	sub    eax,0x1
   63008:	mov    DWORD PTR [rbp+0x10],eax
   6300b:	cmp    DWORD PTR [rbp+0x10],0x0
   6300f:	jne    63059 <sqlite3VdbeExec+0x13bb9>
   63011:	cmp    QWORD PTR [rbp+0x20],0x0
   63016:	je     63039 <sqlite3VdbeExec+0x13b99>
   63018:	mov    rax,QWORD PTR [rbp+0x20]
   6301c:	mov    rcx,QWORD PTR [rbp+0x18]
   63020:	mov    QWORD PTR [rsp+0xb0],rdi
   63028:	mov    rdi,rcx
   6302b:	mov    r10,rax
   6302e:	call   r10
   63031:	mov    rdi,QWORD PTR [rsp+0xb0]
   63039:	test   rbp,rbp
   6303c:	je     63059 <sqlite3VdbeExec+0x13bb9>
   6303e:	mov    QWORD PTR [rsp+0xb0],rdi
   63046:	mov    rdi,rbx
   63049:	mov    rsi,rbp
   6304c:	call   63051 <sqlite3VdbeExec+0x13bb1>
   63051:	mov    rdi,QWORD PTR [rsp+0xb0]
   63059:	test   r13,r13
   6305c:	je     63079 <sqlite3VdbeExec+0x13bd9>
   6305e:	mov    QWORD PTR [rsp+0xb0],rdi
   63066:	mov    rdi,r15
   63069:	mov    rsi,r13
   6306c:	call   63071 <sqlite3VdbeExec+0x13bd1>
   63071:	mov    rdi,QWORD PTR [rsp+0xb0]
   63079:	test   r12,r12
   6307c:	je     630b4 <sqlite3VdbeExec+0x13c14>
   6307e:	cmp    QWORD PTR [r14+0x300],0x0
   63086:	jne    63099 <sqlite3VdbeExec+0x13bf9>
   63088:	mov    eax,DWORD PTR [r12+0x2c]
   6308d:	sub    eax,0x1
   63090:	mov    DWORD PTR [r12+0x2c],eax
   63095:	test   eax,eax
   63097:	ja     630b4 <sqlite3VdbeExec+0x13c14>
   63099:	mov    QWORD PTR [rsp+0xb0],rdi
   630a1:	mov    rdi,r14
   630a4:	mov    rsi,r12
   630a7:	call   630ac <sqlite3VdbeExec+0x13c0c>
   630ac:	mov    rdi,QWORD PTR [rsp+0xb0]
   630b4:	mov    r15d,DWORD PTR [rsp+0x31c]
   630bc:	mov    rbp,QWORD PTR [rsp+0xe8]
   630c4:	mov    rbx,QWORD PTR [rsp+0x100]
   630cc:	mov    r13d,DWORD PTR [rsp+0x344]
   630d4:	mov    eax,DWORD PTR [r14+0xe0]
   630db:	sub    eax,0x1
   630de:	mov    DWORD PTR [r14+0xe0],eax
   630e5:	test   r13d,r13d
   630e8:	je     6310a <sqlite3VdbeExec+0x13c6a>
   630ea:	mov    QWORD PTR [rsp+0xe8],rbp
   630f2:	mov    rbp,r13
   630f5:	mov    r13,QWORD PTR [rsp+0xd0]
   630fd:	mov    rbx,QWORD PTR [rsp+0xf8]
   63105:	jmp    4f712 <sqlite3VdbeExec+0x272>
   6310a:	mov    DWORD PTR [rsp+0x31c],r15d
   63112:	mov    DWORD PTR [rsp+0x32c],r13d
   6311a:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   6311f:	mov    r15d,DWORD PTR [rsp+0x31c]
   63127:	mov    r13,QWORD PTR [rsp+0xf0]
   6312f:	mov    QWORD PTR [rsp+0xd0],r12
   63137:	mov    r12d,DWORD PTR [rsp+0x334]
   6313f:	mov    rax,QWORD PTR [rdi+0x78]
   63143:	movsxd rcx,DWORD PTR [rbp+0x4]
   63147:	mov    rax,QWORD PTR [rax+rcx*8]
   6314b:	test   rax,rax
   6314e:	je     63183 <sqlite3VdbeExec+0x13ce3>
   63150:	cmp    BYTE PTR [rax],0x2
   63153:	jne    63183 <sqlite3VdbeExec+0x13ce3>
   63155:	mov    rax,QWORD PTR [rax+0x28]
   63159:	mov    rax,QWORD PTR [rax]
   6315c:	mov    rcx,QWORD PTR [rbp+0x10]
   63160:	cmp    rax,QWORD PTR [rcx+0x10]
   63164:	jne    63183 <sqlite3VdbeExec+0x13ce3>
   63166:	mov    DWORD PTR [rsp+0x31c],r15d
   6316e:	mov    QWORD PTR [rsp+0xf0],r13
   63176:	mov    DWORD PTR [rsp+0x334],r12d
   6317e:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   63183:	mov    QWORD PTR [rsp+0x108],0x0
   6318f:	mov    rax,QWORD PTR [rbp+0x10]
   63193:	mov    QWORD PTR [rsp+0xf0],r13
   6319b:	mov    r13,QWORD PTR [rax+0x10]
   6319f:	test   r13,r13
   631a2:	je     631ab <sqlite3VdbeExec+0x13d0b>
   631a4:	cmp    QWORD PTR [r13+0x0],0x0
   631a9:	jne    631d0 <sqlite3VdbeExec+0x13d30>
   631ab:	mov    ebx,0x6
   631b0:	mov    QWORD PTR [rsp+0xe8],rbp
   631b8:	mov    rbp,rbx
   631bb:	mov    r13,QWORD PTR [rsp+0xd0]
   631c3:	mov    rbx,QWORD PTR [rsp+0xf8]
   631cb:	jmp    4f712 <sqlite3VdbeExec+0x272>
   631d0:	mov    DWORD PTR [rsp+0x334],r12d
   631d8:	mov    r12,QWORD PTR [r13+0x0]
   631dc:	mov    rax,QWORD PTR [r12+0x30]
   631e1:	mov    QWORD PTR [rsp+0x120],r12
   631e9:	lea    r12,[rsp+0x108]
   631f1:	mov    rcx,r12
   631f4:	mov    QWORD PTR [rsp+0xb0],rdi
   631fc:	mov    rdi,r13
   631ff:	mov    rsi,rcx
   63202:	mov    r10,rax
   63205:	call   r10
   63208:	mov    r12d,eax
   6320b:	mov    rdi,QWORD PTR [rsp+0xb0]
   63213:	cmp    QWORD PTR [r13+0x10],0x0
   63218:	jne    63227 <sqlite3VdbeExec+0x13d87>
   6321a:	mov    DWORD PTR [rsp+0x344],r12d
   63222:	jmp    633b0 <sqlite3VdbeExec+0x13f10>
   63227:	mov    DWORD PTR [rsp+0x344],r12d
   6322f:	mov    r12,QWORD PTR [rdi]
   63232:	mov    rax,QWORD PTR [rdi+0xa8]
   63239:	test   rax,rax
   6323c:	je     63251 <sqlite3VdbeExec+0x13db1>
   6323e:	mov    rdi,r12
   63241:	mov    rsi,rax
   63244:	call   63249 <sqlite3VdbeExec+0x13da9>
   63249:	mov    rdi,QWORD PTR [rsp+0xb0]
   63251:	mov    QWORD PTR [rsp+0x130],r13
   63259:	mov    r13,QWORD PTR [r13+0x10]
   6325d:	test   r13,r13
   63260:	jne    63272 <sqlite3VdbeExec+0x13dd2>
   63262:	xor    r12d,r12d
   63265:	mov    r13,QWORD PTR [rsp+0x130]
   6326d:	jmp    63313 <sqlite3VdbeExec+0x13e73>
   63272:	mov    QWORD PTR [rsp+0xb0],rdi
   6327a:	mov    rdi,r13
   6327d:	call   63282 <sqlite3VdbeExec+0x13de2>
   63282:	mov    QWORD PTR [rsp+0x128],r13
   6328a:	lea    r13,[rax+0x1]
   6328e:	mov    rdi,QWORD PTR [rsp+0xb0]
   63296:	test   r12,r12
   63299:	je     632b3 <sqlite3VdbeExec+0x13e13>
   6329b:	mov    rdi,r12
   6329e:	mov    rsi,r13
   632a1:	call   632a6 <sqlite3VdbeExec+0x13e06>
   632a6:	mov    r12,rax
   632a9:	mov    rdi,QWORD PTR [rsp+0xb0]
   632b1:	jmp    632c6 <sqlite3VdbeExec+0x13e26>
   632b3:	mov    rdi,r13
   632b6:	call   632bb <sqlite3VdbeExec+0x13e1b>
   632bb:	mov    r12,rax
   632be:	mov    rdi,QWORD PTR [rsp+0xb0]
   632c6:	test   r12,r12
   632c9:	jne    632d5 <sqlite3VdbeExec+0x13e35>
   632cb:	mov    DWORD PTR [rsp+0x31c],r15d
   632d3:	jmp    63303 <sqlite3VdbeExec+0x13e63>
   632d5:	mov    DWORD PTR [rsp+0x31c],r15d
   632dd:	mov    r15,QWORD PTR [rsp+0x128]
   632e5:	mov    QWORD PTR [rsp+0xb0],rdi
   632ed:	mov    rdi,r12
   632f0:	mov    rsi,r15
   632f3:	mov    rdx,r13
   632f6:	call   632fb <sqlite3VdbeExec+0x13e5b>
   632fb:	mov    rdi,QWORD PTR [rsp+0xb0]
   63303:	mov    r15d,DWORD PTR [rsp+0x31c]
   6330b:	mov    r13,QWORD PTR [rsp+0x130]
   63313:	mov    QWORD PTR [rdi+0xa8],r12
   6331a:	mov    r12,QWORD PTR [r13+0x10]
   6331e:	test   r12,r12
   63321:	je     633a8 <sqlite3VdbeExec+0x13f08>
   63327:	cmp    DWORD PTR [rip+0x0],0x0        # 6332e <sqlite3VdbeExec+0x13e8e>
   6332e:	je     63388 <sqlite3VdbeExec+0x13ee8>
   63330:	mov    rax,QWORD PTR [rip+0x0]        # 63337 <sqlite3VdbeExec+0x13e97>
   63337:	mov    QWORD PTR [rsp+0xb0],rdi
   6333f:	mov    rdi,r12
   63342:	mov    r10,rax
   63345:	call   r10
   63348:	mov    rcx,QWORD PTR [rip+0x0]        # 6334f <sqlite3VdbeExec+0x13eaf>
   6334f:	movsxd rax,eax
   63352:	sub    rcx,rax
   63355:	mov    QWORD PTR [rip+0x0],rcx        # 6335c <sqlite3VdbeExec+0x13ebc>
   6335c:	mov    rax,QWORD PTR [rip+0x0]        # 63363 <sqlite3VdbeExec+0x13ec3>
   63363:	sub    rax,0x1
   63367:	mov    QWORD PTR [rip+0x0],rax        # 6336e <sqlite3VdbeExec+0x13ece>
   6336e:	mov    rax,QWORD PTR [rip+0x0]        # 63375 <sqlite3VdbeExec+0x13ed5>
   63375:	mov    rdi,r12
   63378:	mov    r10,rax
   6337b:	call   r10
   6337e:	mov    rdi,QWORD PTR [rsp+0xb0]
   63386:	jmp    633a8 <sqlite3VdbeExec+0x13f08>
   63388:	mov    rax,QWORD PTR [rip+0x0]        # 6338f <sqlite3VdbeExec+0x13eef>
   6338f:	mov    QWORD PTR [rsp+0xb0],rdi
   63397:	mov    rdi,r12
   6339a:	mov    r10,rax
   6339d:	call   r10
   633a0:	mov    rdi,QWORD PTR [rsp+0xb0]
   633a8:	mov    QWORD PTR [r13+0x10],0x0
   633b0:	mov    r12d,DWORD PTR [rsp+0x344]
   633b8:	test   r12d,r12d
   633bb:	je     633dd <sqlite3VdbeExec+0x13f3d>
   633bd:	mov    QWORD PTR [rsp+0xe8],rbp
   633c5:	mov    rbp,r12
   633c8:	mov    r13,QWORD PTR [rsp+0xd0]
   633d0:	mov    rbx,QWORD PTR [rsp+0xf8]
   633d8:	jmp    4f712 <sqlite3VdbeExec+0x272>
   633dd:	mov    rax,QWORD PTR [rsp+0x108]
   633e5:	mov    QWORD PTR [rax],r13
   633e8:	mov    eax,DWORD PTR [rbp+0x4]
   633eb:	xor    ecx,ecx
   633ed:	mov    edx,0x2
   633f2:	mov    QWORD PTR [rsp+0xb0],rdi
   633fa:	mov    rsi,rax
   633fd:	mov    r11,rdx
   63400:	mov    rdx,rcx
   63403:	mov    rcx,r11
   63406:	call   6340b <sqlite3VdbeExec+0x13f6b>
   6340b:	mov    rdi,QWORD PTR [rsp+0xb0]
   63413:	test   rax,rax
   63416:	je     63444 <sqlite3VdbeExec+0x13fa4>
   63418:	mov    rcx,QWORD PTR [rsp+0x108]
   63420:	mov    QWORD PTR [rax+0x28],rcx
   63424:	mov    eax,DWORD PTR [r13+0x8]
   63428:	add    eax,0x1
   6342b:	mov    DWORD PTR [r13+0x8],eax
   6342f:	mov    DWORD PTR [rsp+0x31c],r15d
   63437:	mov    DWORD PTR [rsp+0x32c],r12d
   6343f:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   63444:	mov    r12,QWORD PTR [rsp+0x120]
   6344c:	mov    rax,QWORD PTR [r12+0x38]
   63451:	mov    rcx,QWORD PTR [rsp+0x108]
   63459:	mov    rdi,rcx
   6345c:	mov    r10,rax
   6345f:	call   r10
   63462:	mov    rdi,QWORD PTR [rsp+0xb0]
   6346a:	mov    r13,QWORD PTR [rsp+0xf0]
   63472:	mov    rbx,rbp
   63475:	mov    rbp,QWORD PTR [rsp+0xf8]
   6347d:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   63482:	mov    r15d,DWORD PTR [rsp+0x31c]
   6348a:	mov    r13,QWORD PTR [rsp+0xf0]
   63492:	mov    QWORD PTR [rsp+0xd0],r12
   6349a:	mov    r12d,DWORD PTR [rsp+0x334]
   634a2:	mov    QWORD PTR [rsp+0x108],0x0
   634ae:	movsxd rax,DWORD PTR [rbp+0x8]
   634b2:	imul   rax,rax,0x38
   634b6:	mov    DWORD PTR [rsp+0x334],r12d
   634be:	lea    r12,[rbx+rax*1]
   634c2:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   634c7:	and    eax,0x9000
   634cc:	test   eax,eax
   634ce:	je     634ea <sqlite3VdbeExec+0x1404a>
   634d0:	mov    QWORD PTR [rsp+0xb0],rdi
   634d8:	mov    rdi,r12
   634db:	call   634e0 <sqlite3VdbeExec+0x14040>
   634e0:	mov    rdi,QWORD PTR [rsp+0xb0]
   634e8:	jmp    634f2 <sqlite3VdbeExec+0x14052>
   634ea:	mov    WORD PTR [r12+0x14],0x1
   634f2:	mov    QWORD PTR [rsp+0xf0],r13
   634fa:	mov    r13,QWORD PTR [rbp+0x10]
   634fe:	cmp    QWORD PTR [r13+0x50],0x0
   63503:	jne    63512 <sqlite3VdbeExec+0x14072>
   63505:	mov    DWORD PTR [rsp+0x31c],r15d
   6350d:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   63512:	mov    rax,QWORD PTR [r13+0x50]
   63516:	mov    rax,QWORD PTR [rax+0x10]
   6351a:	mov    rcx,QWORD PTR [rax]
   6351d:	mov    rdx,QWORD PTR [r13+0x50]
   63521:	mov    esi,DWORD PTR [rdx+0x18]
   63524:	add    esi,0x1
   63527:	mov    DWORD PTR [rdx+0x18],esi
   6352a:	mov    rcx,QWORD PTR [rcx+0xc0]
   63531:	mov    rdx,QWORD PTR [r14+0x20]
   63535:	movsxd rsi,DWORD PTR [rbp+0x4]
   63539:	shl    rsi,0x5
   6353d:	mov    rdx,QWORD PTR [rdx+rsi*1]
   63541:	mov    rsi,QWORD PTR [r13+0x0]
   63545:	mov    r8d,DWORD PTR [rbp+0xc]
   63549:	mov    QWORD PTR [rsp+0xc8],r14
   63551:	lea    r14,[rsp+0x108]
   63559:	mov    r9,r14
   6355c:	mov    QWORD PTR [rsp+0xb0],rdi
   63564:	mov    rdi,rax
   63567:	mov    r10,rcx
   6356a:	mov    rcx,r8
   6356d:	mov    r8,r9
   63570:	mov    r11,rsi
   63573:	mov    rsi,rdx
   63576:	mov    rdx,r11
   63579:	call   r10
   6357c:	mov    r14d,eax
   6357f:	mov    r13,QWORD PTR [r13+0x50]
   63583:	mov    QWORD PTR [rsp+0xe8],rbp
   6358b:	mov    rbp,QWORD PTR [r13+0x0]
   6358f:	mov    eax,DWORD PTR [r13+0x18]
   63593:	sub    eax,0x1
   63596:	mov    DWORD PTR [r13+0x18],eax
   6359a:	mov    rdi,QWORD PTR [rsp+0xb0]
   635a2:	cmp    DWORD PTR [r13+0x18],0x0
   635a7:	je     635be <sqlite3VdbeExec+0x1411e>
   635a9:	mov    DWORD PTR [rsp+0x31c],r15d
   635b1:	mov    QWORD PTR [rsp+0x120],r12
   635b9:	jmp    63671 <sqlite3VdbeExec+0x141d1>
   635be:	mov    rax,QWORD PTR [r13+0x10]
   635c2:	test   rax,rax
   635c5:	je     635df <sqlite3VdbeExec+0x1413f>
   635c7:	mov    rcx,QWORD PTR [rax]
   635ca:	mov    rcx,QWORD PTR [rcx+0x20]
   635ce:	mov    rdi,rax
   635d1:	mov    r10,rcx
   635d4:	call   r10
   635d7:	mov    rdi,QWORD PTR [rsp+0xb0]
   635df:	mov    QWORD PTR [rsp+0x120],r12
   635e7:	mov    r12,QWORD PTR [r13+0x0]
   635eb:	mov    DWORD PTR [rsp+0x31c],r15d
   635f3:	mov    r15,QWORD PTR [r13+0x8]
   635f7:	mov    eax,DWORD PTR [r15+0x10]
   635fb:	sub    eax,0x1
   635fe:	mov    DWORD PTR [r15+0x10],eax
   63602:	cmp    DWORD PTR [r15+0x10],0x0
   63607:	jne    63651 <sqlite3VdbeExec+0x141b1>
   63609:	cmp    QWORD PTR [r15+0x20],0x0
   6360e:	je     63631 <sqlite3VdbeExec+0x14191>
   63610:	mov    rax,QWORD PTR [r15+0x20]
   63614:	mov    rcx,QWORD PTR [r15+0x18]
   63618:	mov    QWORD PTR [rsp+0xb0],rdi
   63620:	mov    rdi,rcx
   63623:	mov    r10,rax
   63626:	call   r10
   63629:	mov    rdi,QWORD PTR [rsp+0xb0]
   63631:	test   r15,r15
   63634:	je     63651 <sqlite3VdbeExec+0x141b1>
   63636:	mov    QWORD PTR [rsp+0xb0],rdi
   6363e:	mov    rdi,r12
   63641:	mov    rsi,r15
   63644:	call   63649 <sqlite3VdbeExec+0x141a9>
   63649:	mov    rdi,QWORD PTR [rsp+0xb0]
   63651:	test   r13,r13
   63654:	je     63671 <sqlite3VdbeExec+0x141d1>
   63656:	mov    QWORD PTR [rsp+0xb0],rdi
   6365e:	mov    rdi,rbp
   63661:	mov    rsi,r13
   63664:	call   63669 <sqlite3VdbeExec+0x141c9>
   63669:	mov    rdi,QWORD PTR [rsp+0xb0]
   63671:	test   r14d,r14d
   63674:	je     6372c <sqlite3VdbeExec+0x1428c>
   6367a:	mov    rbx,QWORD PTR [rsp+0x108]
   63682:	test   rbx,rbx
   63685:	je     6370c <sqlite3VdbeExec+0x1426c>
   6368b:	cmp    DWORD PTR [rip+0x0],0x0        # 63692 <sqlite3VdbeExec+0x141f2>
   63692:	je     636ec <sqlite3VdbeExec+0x1424c>
   63694:	mov    rax,QWORD PTR [rip+0x0]        # 6369b <sqlite3VdbeExec+0x141fb>
   6369b:	mov    QWORD PTR [rsp+0xb0],rdi
   636a3:	mov    rdi,rbx
   636a6:	mov    r10,rax
   636a9:	call   r10
   636ac:	mov    rcx,QWORD PTR [rip+0x0]        # 636b3 <sqlite3VdbeExec+0x14213>
   636b3:	movsxd rax,eax
   636b6:	sub    rcx,rax
   636b9:	mov    QWORD PTR [rip+0x0],rcx        # 636c0 <sqlite3VdbeExec+0x14220>
   636c0:	mov    rax,QWORD PTR [rip+0x0]        # 636c7 <sqlite3VdbeExec+0x14227>
   636c7:	sub    rax,0x1
   636cb:	mov    QWORD PTR [rip+0x0],rax        # 636d2 <sqlite3VdbeExec+0x14232>
   636d2:	mov    rax,QWORD PTR [rip+0x0]        # 636d9 <sqlite3VdbeExec+0x14239>
   636d9:	mov    rdi,rbx
   636dc:	mov    r10,rax
   636df:	call   r10
   636e2:	mov    rdi,QWORD PTR [rsp+0xb0]
   636ea:	jmp    6370c <sqlite3VdbeExec+0x1426c>
   636ec:	mov    rax,QWORD PTR [rip+0x0]        # 636f3 <sqlite3VdbeExec+0x14253>
   636f3:	mov    QWORD PTR [rsp+0xb0],rdi
   636fb:	mov    rdi,rbx
   636fe:	mov    r10,rax
   63701:	call   r10
   63704:	mov    rdi,QWORD PTR [rsp+0xb0]
   6370c:	mov    rbp,r14
   6370f:	mov    r14,QWORD PTR [rsp+0xc8]
   63717:	mov    r13,QWORD PTR [rsp+0xd0]
   6371f:	mov    rbx,QWORD PTR [rsp+0xf8]
   63727:	jmp    4f712 <sqlite3VdbeExec+0x272>
   6372c:	mov    r12,QWORD PTR [rsp+0x120]
   63734:	cmp    QWORD PTR [rsp+0x108],0x0
   6373d:	je     6377e <sqlite3VdbeExec+0x142de>
   6373f:	mov    rax,QWORD PTR [rsp+0x108]
   63747:	mov    rcx,0xffffffffffffffff
   6374e:	lea    rdx,[rip+0x0]        # 63755 <sqlite3VdbeExec+0x142b5>
   63755:	mov    esi,0x1
   6375a:	mov    QWORD PTR [rsp+0xb0],rdi
   63762:	mov    rdi,r12
   63765:	mov    r8,rdx
   63768:	mov    rdx,rcx
   6376b:	mov    rcx,rsi
   6376e:	mov    rsi,rax
   63771:	call   63776 <sqlite3VdbeExec+0x142d6>
   63776:	mov    rdi,QWORD PTR [rsp+0xb0]
   6377e:	mov    rbp,QWORD PTR [rsp+0xe8]
   63786:	mov    DWORD PTR [rsp+0x32c],r14d
   6378e:	mov    r14,QWORD PTR [rsp+0xc8]
   63796:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   6379b:	mov    r15d,DWORD PTR [rsp+0x31c]
   637a3:	mov    r13,QWORD PTR [rsp+0xf0]
   637ab:	mov    QWORD PTR [rsp+0xd0],r12
   637b3:	mov    r12d,DWORD PTR [rsp+0x334]
   637bb:	mov    rax,QWORD PTR [rdi+0x78]
   637bf:	movsxd rcx,DWORD PTR [rbp+0x4]
   637c3:	mov    DWORD PTR [rsp+0x334],r12d
   637cb:	mov    r12,QWORD PTR [rax+rcx*8]
   637cf:	mov    QWORD PTR [rsp+0xb0],rdi
   637d7:	call   637dc <sqlite3VdbeExec+0x1433c>
   637dc:	mov    rdi,QWORD PTR [rsp+0xb0]
   637e4:	test   eax,eax
   637e6:	je     637f7 <sqlite3VdbeExec+0x14357>
   637e8:	mov    QWORD PTR [rsp+0xf0],r13
   637f0:	mov    r13,rbx
   637f3:	xor    ebx,ebx
   637f5:	jmp    6382d <sqlite3VdbeExec+0x1438d>
   637f7:	mov    QWORD PTR [rsp+0x108],r12
   637ff:	mov    r12,rbx
   63802:	mov    ebx,0x10
   63807:	mov    rdi,rbx
   6380a:	call   6380f <sqlite3VdbeExec+0x1436f>
   6380f:	mov    rbx,rax
   63812:	mov    rdi,QWORD PTR [rsp+0xb0]
   6381a:	mov    QWORD PTR [rsp+0xf0],r13
   63822:	mov    r13,r12
   63825:	mov    r12,QWORD PTR [rsp+0x108]
   6382d:	test   rbx,rbx
   63830:	jne    6384a <sqlite3VdbeExec+0x143aa>
   63832:	mov    r13,QWORD PTR [rsp+0xf0]
   6383a:	mov    rbx,rbp
   6383d:	mov    rbp,QWORD PTR [rsp+0xf8]
   63845:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   6384a:	mov    rax,QWORD PTR [r12+0x28]
   6384f:	mov    QWORD PTR [rbx],rax
   63852:	movsxd rax,DWORD PTR [rbp+0xc]
   63856:	imul   rax,rax,0x38
   6385a:	add    rax,r13
   6385d:	mov    QWORD PTR [rbx+0x8],rax
   63861:	mov    rax,QWORD PTR [rdi+0x68]
   63865:	movsxd rcx,DWORD PTR [rbp+0x8]
   63869:	imul   rcx,rcx,0x38
   6386d:	lea    r12,[rax+rcx*1]
   63871:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   63876:	and    eax,0x9000
   6387b:	test   eax,eax
   6387d:	je     6389c <sqlite3VdbeExec+0x143fc>
   6387f:	mov    QWORD PTR [rsp+0xb0],rdi
   63887:	mov    rdi,r12
   6388a:	call   6388f <sqlite3VdbeExec+0x143ef>
   6388f:	mov    r12,rax
   63892:	mov    rdi,QWORD PTR [rsp+0xb0]
   6389a:	jmp    638a4 <sqlite3VdbeExec+0x14404>
   6389c:	mov    WORD PTR [r12+0x14],0x4
   638a4:	mov    WORD PTR [r12+0x14],0x1
   638ac:	mov    QWORD PTR [rsp+0xb0],rdi
   638b4:	mov    rdi,r12
   638b7:	call   638bc <sqlite3VdbeExec+0x1441c>
   638bc:	lea    rax,[rip+0x0]        # 638c3 <sqlite3VdbeExec+0x14423>
   638c3:	mov    DWORD PTR [rsp+0x31c],r15d
   638cb:	lea    r15,[rip+0x0]        # 638d2 <sqlite3VdbeExec+0x14432>
   638d2:	test   r15,r15
   638d5:	cmovne rax,r15
   638d9:	mov    QWORD PTR [r12],rax
   638dd:	mov    QWORD PTR [r12+0x8],rbx
   638e2:	mov    WORD PTR [r12+0x14],0x1a01
   638ea:	mov    BYTE PTR [r12+0x17],0x70
   638f0:	lea    rax,[rip+0x0]        # 638f7 <sqlite3VdbeExec+0x14457>
   638f7:	lea    rbx,[rip+0x0]        # 638fe <sqlite3VdbeExec+0x1445e>
   638fe:	test   rbx,rbx
   63901:	cmovne rax,rbx
   63905:	mov    QWORD PTR [r12+0x30],rax
   6390a:	mov    rdi,QWORD PTR [rsp+0xb0]
   63912:	mov    rbx,r13
   63915:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   6391a:	mov    r13,rbx
   6391d:	mov    QWORD PTR [rsp+0xd0],r12
   63925:	movsxd rax,DWORD PTR [rbp+0xc]
   63929:	imul   rax,rax,0x38
   6392d:	lea    rcx,[r13+rax*1+0x0]
   63932:	add    rcx,0x38
   63936:	mov    rdx,QWORD PTR [rdi+0x78]
   6393a:	movsxd rsi,DWORD PTR [rbp+0x4]
   6393e:	mov    rbx,QWORD PTR [rdx+rsi*8]
   63942:	mov    r12,QWORD PTR [rbx+0x28]
   63946:	mov    r15,QWORD PTR [r12]
   6394a:	mov    QWORD PTR [rsp+0x108],rbx
   63952:	mov    rbx,QWORD PTR [r15]
   63955:	mov    rdx,QWORD PTR [r13+rax*1+0x38]
   6395a:	mov    rax,QWORD PTR [r13+rax*1+0x0]
   6395f:	mov    rsi,QWORD PTR [rdi+0x70]
   63963:	xor    r8d,r8d
   63966:	jmp    63981 <sqlite3VdbeExec+0x144e1>
   63968:	mov    r9,r8
   6396b:	lea    r10d,[r8+0x1]
   6396f:	movsxd r10,r10d
   63972:	imul   r10,r10,0x38
   63976:	add    r10,rcx
   63979:	mov    QWORD PTR [rsi+r9*8],r10
   6397d:	add    r8d,0x1
   63981:	cmp    r8d,edx
   63984:	jl     63968 <sqlite3VdbeExec+0x144c8>
   63986:	mov    rcx,QWORD PTR [rbx+0x40]
   6398a:	mov    r8,QWORD PTR [rbp+0x10]
   6398e:	mov    QWORD PTR [rsp+0x128],rbx
   63996:	mov    QWORD PTR [rsp+0xb0],rdi
   6399e:	mov    rdi,r12
   639a1:	mov    r10,rcx
   639a4:	mov    rcx,rdx
   639a7:	mov    rdx,r8
   639aa:	mov    r8,rsi
   639ad:	mov    rsi,rax
   639b0:	call   r10
   639b3:	mov    ebx,eax
   639b5:	mov    rdi,QWORD PTR [rsp+0xb0]
   639bd:	cmp    QWORD PTR [r15+0x10],0x0
   639c2:	jne    639d8 <sqlite3VdbeExec+0x14538>
   639c4:	mov    QWORD PTR [rsp+0x120],r12
   639cc:	mov    DWORD PTR [rsp+0x344],ebx
   639d3:	jmp    63b4f <sqlite3VdbeExec+0x146af>
   639d8:	mov    DWORD PTR [rsp+0x344],ebx
   639df:	mov    rbx,QWORD PTR [rdi]
   639e2:	mov    rax,QWORD PTR [rdi+0xa8]
   639e9:	test   rax,rax
   639ec:	je     63a01 <sqlite3VdbeExec+0x14561>
   639ee:	mov    rdi,rbx
   639f1:	mov    rsi,rax
   639f4:	call   639f9 <sqlite3VdbeExec+0x14559>
   639f9:	mov    rdi,QWORD PTR [rsp+0xb0]
   63a01:	mov    QWORD PTR [rsp+0x120],r12
   63a09:	mov    r12,QWORD PTR [r15+0x10]
   63a0d:	test   r12,r12
   63a10:	jne    63a19 <sqlite3VdbeExec+0x14579>
   63a12:	xor    ebx,ebx
   63a14:	jmp    63ab2 <sqlite3VdbeExec+0x14612>
   63a19:	mov    QWORD PTR [rsp+0xb0],rdi
   63a21:	mov    rdi,r12
   63a24:	call   63a29 <sqlite3VdbeExec+0x14589>
   63a29:	mov    QWORD PTR [rsp+0x160],r12
   63a31:	lea    r12,[rax+0x1]
   63a35:	mov    rdi,QWORD PTR [rsp+0xb0]
   63a3d:	test   rbx,rbx
   63a40:	je     63a5a <sqlite3VdbeExec+0x145ba>
   63a42:	mov    rdi,rbx
   63a45:	mov    rsi,r12
   63a48:	call   63a4d <sqlite3VdbeExec+0x145ad>
   63a4d:	mov    rbx,rax
   63a50:	mov    rdi,QWORD PTR [rsp+0xb0]
   63a58:	jmp    63a6d <sqlite3VdbeExec+0x145cd>
   63a5a:	mov    rdi,r12
   63a5d:	call   63a62 <sqlite3VdbeExec+0x145c2>
   63a62:	mov    rbx,rax
   63a65:	mov    rdi,QWORD PTR [rsp+0xb0]
   63a6d:	test   rbx,rbx
   63a70:	jne    63a7c <sqlite3VdbeExec+0x145dc>
   63a72:	mov    QWORD PTR [rsp+0x130],r15
   63a7a:	jmp    63aaa <sqlite3VdbeExec+0x1460a>
   63a7c:	mov    QWORD PTR [rsp+0x130],r15
   63a84:	mov    r15,QWORD PTR [rsp+0x160]
   63a8c:	mov    QWORD PTR [rsp+0xb0],rdi
   63a94:	mov    rdi,rbx
   63a97:	mov    rsi,r15
   63a9a:	mov    rdx,r12
   63a9d:	call   63aa2 <sqlite3VdbeExec+0x14602>
   63aa2:	mov    rdi,QWORD PTR [rsp+0xb0]
   63aaa:	mov    r15,QWORD PTR [rsp+0x130]
   63ab2:	mov    QWORD PTR [rdi+0xa8],rbx
   63ab9:	mov    rbx,QWORD PTR [r15+0x10]
   63abd:	test   rbx,rbx
   63ac0:	je     63b47 <sqlite3VdbeExec+0x146a7>
   63ac6:	cmp    DWORD PTR [rip+0x0],0x0        # 63acd <sqlite3VdbeExec+0x1462d>
   63acd:	je     63b27 <sqlite3VdbeExec+0x14687>
   63acf:	mov    rax,QWORD PTR [rip+0x0]        # 63ad6 <sqlite3VdbeExec+0x14636>
   63ad6:	mov    QWORD PTR [rsp+0xb0],rdi
   63ade:	mov    rdi,rbx
   63ae1:	mov    r10,rax
   63ae4:	call   r10
   63ae7:	mov    rcx,QWORD PTR [rip+0x0]        # 63aee <sqlite3VdbeExec+0x1464e>
   63aee:	movsxd rax,eax
   63af1:	sub    rcx,rax
   63af4:	mov    QWORD PTR [rip+0x0],rcx        # 63afb <sqlite3VdbeExec+0x1465b>
   63afb:	mov    rax,QWORD PTR [rip+0x0]        # 63b02 <sqlite3VdbeExec+0x14662>
   63b02:	sub    rax,0x1
   63b06:	mov    QWORD PTR [rip+0x0],rax        # 63b0d <sqlite3VdbeExec+0x1466d>
   63b0d:	mov    rax,QWORD PTR [rip+0x0]        # 63b14 <sqlite3VdbeExec+0x14674>
   63b14:	mov    rdi,rbx
   63b17:	mov    r10,rax
   63b1a:	call   r10
   63b1d:	mov    rdi,QWORD PTR [rsp+0xb0]
   63b25:	jmp    63b47 <sqlite3VdbeExec+0x146a7>
   63b27:	mov    rax,QWORD PTR [rip+0x0]        # 63b2e <sqlite3VdbeExec+0x1468e>
   63b2e:	mov    QWORD PTR [rsp+0xb0],rdi
   63b36:	mov    rdi,rbx
   63b39:	mov    r10,rax
   63b3c:	call   r10
   63b3f:	mov    rdi,QWORD PTR [rsp+0xb0]
   63b47:	mov    QWORD PTR [r15+0x10],0x0
   63b4f:	mov    ebx,DWORD PTR [rsp+0x344]
   63b56:	test   ebx,ebx
   63b58:	je     63b7a <sqlite3VdbeExec+0x146da>
   63b5a:	mov    QWORD PTR [rsp+0xe8],rbp
   63b62:	mov    rbp,rbx
   63b65:	mov    r13,QWORD PTR [rsp+0xd0]
   63b6d:	mov    rbx,QWORD PTR [rsp+0xf8]
   63b75:	jmp    4f712 <sqlite3VdbeExec+0x272>
   63b7a:	mov    r12,QWORD PTR [rsp+0x120]
   63b82:	mov    r15,QWORD PTR [rsp+0x128]
   63b8a:	mov    rax,QWORD PTR [r15+0x50]
   63b8e:	mov    QWORD PTR [rsp+0xb0],rdi
   63b96:	mov    rdi,r12
   63b99:	mov    r10,rax
   63b9c:	call   r10
   63b9f:	mov    r12,QWORD PTR [rsp+0x108]
   63ba7:	mov    BYTE PTR [r12+0x2],0x0
   63bad:	mov    rdi,QWORD PTR [rsp+0xb0]
   63bb5:	test   eax,eax
   63bb7:	je     63bd3 <sqlite3VdbeExec+0x14733>
   63bb9:	mov    r12,r14
   63bbc:	mov    r15d,DWORD PTR [rsp+0x31c]
   63bc4:	mov    DWORD PTR [rsp+0x32c],ebx
   63bcb:	mov    rbx,r13
   63bce:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   63bd3:	mov    DWORD PTR [rsp+0x32c],ebx
   63bda:	mov    rbx,r13
   63bdd:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   63be2:	mov    r15d,DWORD PTR [rsp+0x31c]
   63bea:	mov    r13,QWORD PTR [rsp+0xf0]
   63bf2:	mov    QWORD PTR [rsp+0xd0],r12
   63bfa:	mov    r12d,DWORD PTR [rsp+0x334]
   63c02:	mov    rax,QWORD PTR [rdi+0x78]
   63c06:	movsxd rcx,DWORD PTR [rbp+0x4]
   63c0a:	mov    DWORD PTR [rsp+0x334],r12d
   63c12:	mov    r12,QWORD PTR [rax+rcx*8]
   63c16:	movsxd rax,DWORD PTR [rbp+0xc]
   63c1a:	imul   rax,rax,0x38
   63c1e:	mov    QWORD PTR [rsp+0xf0],r13
   63c26:	lea    r13,[rbx+rax*1]
   63c2a:	cmp    BYTE PTR [r12+0x2],0x0
   63c30:	je     63c6e <sqlite3VdbeExec+0x147ce>
   63c32:	movzx  eax,WORD PTR [r13+0x14]
   63c37:	and    eax,0x9000
   63c3c:	test   eax,eax
   63c3e:	je     63c5a <sqlite3VdbeExec+0x147ba>
   63c40:	mov    QWORD PTR [rsp+0xb0],rdi
   63c48:	mov    rdi,r13
   63c4b:	call   63c50 <sqlite3VdbeExec+0x147b0>
   63c50:	mov    rdi,QWORD PTR [rsp+0xb0]
   63c58:	jmp    63c61 <sqlite3VdbeExec+0x147c1>
   63c5a:	mov    WORD PTR [r13+0x14],0x1
   63c61:	mov    DWORD PTR [rsp+0x31c],r15d
   63c69:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   63c6e:	mov    rax,QWORD PTR [r12+0x28]
   63c73:	mov    QWORD PTR [rsp+0x100],rbx
   63c7b:	mov    rbx,QWORD PTR [rax]
   63c7e:	mov    QWORD PTR [rsp+0xc8],r14
   63c86:	mov    r14,QWORD PTR [rbx]
   63c89:	mov    QWORD PTR [rsp+0x108],rbx
   63c91:	lea    rbx,[rsp+0x1b0]
   63c99:	mov    rax,rbx
   63c9c:	xor    ecx,ecx
   63c9e:	mov    edx,0x30
   63ca3:	mov    QWORD PTR [rsp+0xb0],rdi
   63cab:	mov    rdi,rax
   63cae:	mov    rsi,rcx
   63cb1:	call   63cb6 <sqlite3VdbeExec+0x14816>
   63cb6:	mov    QWORD PTR [rsp+0x1b0],r13
   63cbe:	mov    BYTE PTR [rsp+0x1d8],r15b
   63cc6:	mov    QWORD PTR [rsp+0x258],0x0
   63cd2:	mov    DWORD PTR [rsp+0x254],0x1000000
   63cdd:	lea    rbx,[rsp+0x250]
   63ce5:	mov    rax,rbx
   63ce8:	mov    QWORD PTR [rsp+0x1b8],rax
   63cf0:	movzx  eax,WORD PTR [rbp+0x2]
   63cf4:	and    eax,0x1
   63cf7:	mov    rdi,QWORD PTR [rsp+0xb0]
   63cff:	test   eax,eax
   63d01:	je     63d3b <sqlite3VdbeExec+0x1489b>
   63d03:	movzx  eax,WORD PTR [r13+0x14]
   63d08:	and    eax,0x9000
   63d0d:	test   eax,eax
   63d0f:	je     63d23 <sqlite3VdbeExec+0x14883>
   63d11:	mov    rdi,r13
   63d14:	call   63d19 <sqlite3VdbeExec+0x14879>
   63d19:	mov    rdi,QWORD PTR [rsp+0xb0]
   63d21:	jmp    63d2a <sqlite3VdbeExec+0x1488a>
   63d23:	mov    WORD PTR [r13+0x14],0x1
   63d2a:	mov    WORD PTR [r13+0x14],0x401
   63d31:	mov    DWORD PTR [r13+0x0],0x0
   63d39:	jmp    63d4d <sqlite3VdbeExec+0x148ad>
   63d3b:	movzx  eax,WORD PTR [r13+0x14]
   63d40:	and    eax,0xfffff240
   63d45:	or     eax,0x1
   63d48:	mov    WORD PTR [r13+0x14],ax
   63d4d:	mov    rax,QWORD PTR [r14+0x58]
   63d51:	mov    rcx,QWORD PTR [r12+0x28]
   63d56:	lea    r12,[rsp+0x1b0]
   63d5e:	mov    rdx,r12
   63d61:	mov    esi,DWORD PTR [rbp+0x8]
   63d64:	mov    QWORD PTR [rsp+0xb0],rdi
   63d6c:	mov    rdi,rcx
   63d6f:	mov    r10,rax
   63d72:	mov    r11,rsi
   63d75:	mov    rsi,rdx
   63d78:	mov    rdx,r11
   63d7b:	call   r10
   63d7e:	mov    r14d,eax
   63d81:	mov    rdi,QWORD PTR [rsp+0xb0]
   63d89:	mov    rbx,QWORD PTR [rsp+0x108]
   63d91:	cmp    QWORD PTR [rbx+0x10],0x0
   63d96:	jne    63da5 <sqlite3VdbeExec+0x14905>
   63d98:	mov    DWORD PTR [rsp+0x344],r14d
   63da0:	jmp    63f16 <sqlite3VdbeExec+0x14a76>
   63da5:	mov    r12,QWORD PTR [rdi]
   63da8:	mov    rax,QWORD PTR [rdi+0xa8]
   63daf:	test   rax,rax
   63db2:	je     63dc7 <sqlite3VdbeExec+0x14927>
   63db4:	mov    rdi,r12
   63db7:	mov    rsi,rax
   63dba:	call   63dbf <sqlite3VdbeExec+0x1491f>
   63dbf:	mov    rdi,QWORD PTR [rsp+0xb0]
   63dc7:	mov    DWORD PTR [rsp+0x344],r14d
   63dcf:	mov    r14,QWORD PTR [rbx+0x10]
   63dd3:	test   r14,r14
   63dd6:	jne    63de0 <sqlite3VdbeExec+0x14940>
   63dd8:	xor    r12d,r12d
   63ddb:	jmp    63e79 <sqlite3VdbeExec+0x149d9>
   63de0:	mov    QWORD PTR [rsp+0xb0],rdi
   63de8:	mov    rdi,r14
   63deb:	call   63df0 <sqlite3VdbeExec+0x14950>
   63df0:	mov    QWORD PTR [rsp+0x120],r14
   63df8:	lea    r14,[rax+0x1]
   63dfc:	mov    rdi,QWORD PTR [rsp+0xb0]
   63e04:	test   r12,r12
   63e07:	je     63e21 <sqlite3VdbeExec+0x14981>
   63e09:	mov    rdi,r12
   63e0c:	mov    rsi,r14
   63e0f:	call   63e14 <sqlite3VdbeExec+0x14974>
   63e14:	mov    r12,rax
   63e17:	mov    rdi,QWORD PTR [rsp+0xb0]
   63e1f:	jmp    63e34 <sqlite3VdbeExec+0x14994>
   63e21:	mov    rdi,r14
   63e24:	call   63e29 <sqlite3VdbeExec+0x14989>
   63e29:	mov    r12,rax
   63e2c:	mov    rdi,QWORD PTR [rsp+0xb0]
   63e34:	test   r12,r12
   63e37:	jne    63e43 <sqlite3VdbeExec+0x149a3>
   63e39:	mov    QWORD PTR [rsp+0x108],rbx
   63e41:	jmp    63e71 <sqlite3VdbeExec+0x149d1>
   63e43:	mov    QWORD PTR [rsp+0x108],rbx
   63e4b:	mov    rbx,QWORD PTR [rsp+0x120]
   63e53:	mov    QWORD PTR [rsp+0xb0],rdi
   63e5b:	mov    rdi,r12
   63e5e:	mov    rsi,rbx
   63e61:	mov    rdx,r14
   63e64:	call   63e69 <sqlite3VdbeExec+0x149c9>
   63e69:	mov    rdi,QWORD PTR [rsp+0xb0]
   63e71:	mov    rbx,QWORD PTR [rsp+0x108]
   63e79:	mov    QWORD PTR [rdi+0xa8],r12
   63e80:	mov    r12,QWORD PTR [rbx+0x10]
   63e84:	test   r12,r12
   63e87:	je     63f0e <sqlite3VdbeExec+0x14a6e>
   63e8d:	cmp    DWORD PTR [rip+0x0],0x0        # 63e94 <sqlite3VdbeExec+0x149f4>
   63e94:	je     63eee <sqlite3VdbeExec+0x14a4e>
   63e96:	mov    rax,QWORD PTR [rip+0x0]        # 63e9d <sqlite3VdbeExec+0x149fd>
   63e9d:	mov    QWORD PTR [rsp+0xb0],rdi
   63ea5:	mov    rdi,r12
   63ea8:	mov    r10,rax
   63eab:	call   r10
   63eae:	mov    rcx,QWORD PTR [rip+0x0]        # 63eb5 <sqlite3VdbeExec+0x14a15>
   63eb5:	movsxd rax,eax
   63eb8:	sub    rcx,rax
   63ebb:	mov    QWORD PTR [rip+0x0],rcx        # 63ec2 <sqlite3VdbeExec+0x14a22>
   63ec2:	mov    rax,QWORD PTR [rip+0x0]        # 63ec9 <sqlite3VdbeExec+0x14a29>
   63ec9:	sub    rax,0x1
   63ecd:	mov    QWORD PTR [rip+0x0],rax        # 63ed4 <sqlite3VdbeExec+0x14a34>
   63ed4:	mov    rax,QWORD PTR [rip+0x0]        # 63edb <sqlite3VdbeExec+0x14a3b>
   63edb:	mov    rdi,r12
   63ede:	mov    r10,rax
   63ee1:	call   r10
   63ee4:	mov    rdi,QWORD PTR [rsp+0xb0]
   63eec:	jmp    63f0e <sqlite3VdbeExec+0x14a6e>
   63eee:	mov    rax,QWORD PTR [rip+0x0]        # 63ef5 <sqlite3VdbeExec+0x14a55>
   63ef5:	mov    QWORD PTR [rsp+0xb0],rdi
   63efd:	mov    rdi,r12
   63f00:	mov    r10,rax
   63f03:	call   r10
   63f06:	mov    rdi,QWORD PTR [rsp+0xb0]
   63f0e:	mov    QWORD PTR [rbx+0x10],0x0
   63f16:	cmp    DWORD PTR [rsp+0x1d4],0x0
   63f1e:	jg     63f2c <sqlite3VdbeExec+0x14a8c>
   63f20:	mov    ebx,DWORD PTR [rsp+0x344]
   63f27:	jmp    63fae <sqlite3VdbeExec+0x14b0e>
   63f2c:	lea    rbx,[rip+0x0]        # 63f33 <sqlite3VdbeExec+0x14a93>
   63f33:	test   r13,r13
   63f36:	jne    63f3c <sqlite3VdbeExec+0x14a9c>
   63f38:	xor    eax,eax
   63f3a:	jmp    63f8a <sqlite3VdbeExec+0x14aea>
   63f3c:	movzx  eax,WORD PTR [r13+0x14]
   63f41:	and    eax,0x202
   63f46:	cmp    eax,0x202
   63f4b:	jne    63f5a <sqlite3VdbeExec+0x14aba>
   63f4d:	cmp    BYTE PTR [r13+0x16],0x1
   63f52:	jne    63f5a <sqlite3VdbeExec+0x14aba>
   63f54:	mov    rax,QWORD PTR [r13+0x8]
   63f58:	jmp    63f8a <sqlite3VdbeExec+0x14aea>
   63f5a:	movzx  eax,WORD PTR [r13+0x14]
   63f5f:	and    eax,0x1
   63f62:	test   eax,eax
   63f64:	je     63f6a <sqlite3VdbeExec+0x14aca>
   63f66:	xor    eax,eax
   63f68:	jmp    63f8a <sqlite3VdbeExec+0x14aea>
   63f6a:	mov    eax,0x1
   63f6f:	mov    QWORD PTR [rsp+0xb0],rdi
   63f77:	mov    rdi,r13
   63f7a:	mov    rsi,rax
   63f7d:	call   63f82 <sqlite3VdbeExec+0x14ae2>
   63f82:	mov    rdi,QWORD PTR [rsp+0xb0]
   63f8a:	mov    QWORD PTR [rsp+0xb0],rdi
   63f92:	mov    rsi,rbx
   63f95:	mov    rdx,rax
   63f98:	xor    eax,eax
   63f9a:	call   63f9f <sqlite3VdbeExec+0x14aff>
   63f9f:	mov    ebx,DWORD PTR [rsp+0x1d4]
   63fa6:	mov    rdi,QWORD PTR [rsp+0xb0]
   63fae:	mov    eax,r15d
   63fb1:	movzx  ecx,WORD PTR [r13+0x14]
   63fb6:	and    ecx,0x2
   63fb9:	test   ecx,ecx
   63fbb:	jne    63fed <sqlite3VdbeExec+0x14b4d>
   63fbd:	mov    BYTE PTR [r13+0x16],al
   63fc1:	test   ebx,ebx
   63fc3:	je     63ffa <sqlite3VdbeExec+0x14b5a>
   63fc5:	mov    r14,QWORD PTR [rsp+0xc8]
   63fcd:	mov    QWORD PTR [rsp+0xe8],rbp
   63fd5:	mov    rbp,rbx
   63fd8:	mov    r13,QWORD PTR [rsp+0xd0]
   63fe0:	mov    rbx,QWORD PTR [rsp+0xf8]
   63fe8:	jmp    4f712 <sqlite3VdbeExec+0x272>
   63fed:	movzx  ecx,BYTE PTR [r13+0x16]
   63ff2:	cmp    ecx,eax
   63ff4:	jne    6401e <sqlite3VdbeExec+0x14b7e>
   63ff6:	test   ebx,ebx
   63ff8:	jne    63fc5 <sqlite3VdbeExec+0x14b25>
   63ffa:	mov    r14,QWORD PTR [rsp+0xc8]
   64002:	mov    DWORD PTR [rsp+0x31c],r15d
   6400a:	mov    DWORD PTR [rsp+0x32c],ebx
   64011:	mov    rbx,QWORD PTR [rsp+0x100]
   64019:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   6401e:	mov    QWORD PTR [rsp+0xb0],rdi
   64026:	mov    rdi,r13
   64029:	mov    rsi,rax
   6402c:	call   64031 <sqlite3VdbeExec+0x14b91>
   64031:	mov    rdi,QWORD PTR [rsp+0xb0]
   64039:	test   ebx,ebx
   6403b:	jne    63fc5 <sqlite3VdbeExec+0x14b25>
   6403d:	jmp    63ffa <sqlite3VdbeExec+0x14b5a>
   6403f:	mov    r15d,DWORD PTR [rsp+0x31c]
   64047:	mov    r13,QWORD PTR [rsp+0xf0]
   6404f:	mov    QWORD PTR [rsp+0xd0],r12
   64057:	mov    r12d,DWORD PTR [rsp+0x334]
   6405f:	mov    rax,QWORD PTR [rdi+0x78]
   64063:	movsxd rcx,DWORD PTR [rbp+0x4]
   64067:	mov    DWORD PTR [rsp+0x334],r12d
   6406f:	mov    r12,QWORD PTR [rax+rcx*8]
   64073:	cmp    BYTE PTR [r12+0x2],0x0
   64079:	je     64090 <sqlite3VdbeExec+0x14bf0>
   6407b:	mov    DWORD PTR [rsp+0x31c],r15d
   64083:	mov    QWORD PTR [rsp+0xf0],r13
   6408b:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   64090:	mov    rax,QWORD PTR [r12+0x28]
   64095:	mov    QWORD PTR [rsp+0xf0],r13
   6409d:	mov    r13,QWORD PTR [rax]
   640a0:	mov    DWORD PTR [rsp+0x31c],r15d
   640a8:	mov    r15,QWORD PTR [r13+0x0]
   640ac:	mov    rax,QWORD PTR [r15+0x48]
   640b0:	mov    rcx,QWORD PTR [r12+0x28]
   640b5:	mov    QWORD PTR [rsp+0x128],r15
   640bd:	mov    QWORD PTR [rsp+0xb0],rdi
   640c5:	mov    rdi,rcx
   640c8:	mov    r10,rax
   640cb:	call   r10
   640ce:	mov    r15d,eax
   640d1:	mov    rdi,QWORD PTR [rsp+0xb0]
   640d9:	cmp    QWORD PTR [r13+0x10],0x0
   640de:	jne    640ed <sqlite3VdbeExec+0x14c4d>
   640e0:	mov    QWORD PTR [rsp+0x108],r12
   640e8:	jmp    64282 <sqlite3VdbeExec+0x14de2>
   640ed:	mov    DWORD PTR [rsp+0x32c],r15d
   640f5:	mov    r15,QWORD PTR [rdi]
   640f8:	mov    rax,QWORD PTR [rdi+0xa8]
   640ff:	test   rax,rax
   64102:	je     64117 <sqlite3VdbeExec+0x14c77>
   64104:	mov    rdi,r15
   64107:	mov    rsi,rax
   6410a:	call   6410f <sqlite3VdbeExec+0x14c6f>
   6410f:	mov    rdi,QWORD PTR [rsp+0xb0]
   64117:	mov    QWORD PTR [rsp+0x108],r12
   6411f:	mov    r12,QWORD PTR [r13+0x10]
   64123:	test   r12,r12
   64126:	jne    64133 <sqlite3VdbeExec+0x14c93>
   64128:	xor    r12d,r12d
   6412b:	mov    r15,r12
   6412e:	jmp    641cc <sqlite3VdbeExec+0x14d2c>
   64133:	mov    QWORD PTR [rsp+0xb0],rdi
   6413b:	mov    rdi,r12
   6413e:	call   64143 <sqlite3VdbeExec+0x14ca3>
   64143:	mov    QWORD PTR [rsp+0x130],r12
   6414b:	lea    r12,[rax+0x1]
   6414f:	mov    rdi,QWORD PTR [rsp+0xb0]
   64157:	test   r15,r15
   6415a:	je     64174 <sqlite3VdbeExec+0x14cd4>
   6415c:	mov    rdi,r15
   6415f:	mov    rsi,r12
   64162:	call   64167 <sqlite3VdbeExec+0x14cc7>
   64167:	mov    r15,rax
   6416a:	mov    rdi,QWORD PTR [rsp+0xb0]
   64172:	jmp    64187 <sqlite3VdbeExec+0x14ce7>
   64174:	mov    rdi,r12
   64177:	call   6417c <sqlite3VdbeExec+0x14cdc>
   6417c:	mov    r15,rax
   6417f:	mov    rdi,QWORD PTR [rsp+0xb0]
   64187:	test   r15,r15
   6418a:	jne    64196 <sqlite3VdbeExec+0x14cf6>
   6418c:	mov    QWORD PTR [rsp+0x120],r13
   64194:	jmp    641c4 <sqlite3VdbeExec+0x14d24>
   64196:	mov    QWORD PTR [rsp+0x120],r13
   6419e:	mov    r13,QWORD PTR [rsp+0x130]
   641a6:	mov    QWORD PTR [rsp+0xb0],rdi
   641ae:	mov    rdi,r15
   641b1:	mov    rsi,r13
   641b4:	mov    rdx,r12
   641b7:	call   641bc <sqlite3VdbeExec+0x14d1c>
   641bc:	mov    rdi,QWORD PTR [rsp+0xb0]
   641c4:	mov    r13,QWORD PTR [rsp+0x120]
   641cc:	mov    QWORD PTR [rdi+0xa8],r15
   641d3:	mov    r12,QWORD PTR [r13+0x10]
   641d7:	test   r12,r12
   641da:	jne    641e9 <sqlite3VdbeExec+0x14d49>
   641dc:	mov    r15d,DWORD PTR [rsp+0x32c]
   641e4:	jmp    6427a <sqlite3VdbeExec+0x14dda>
   641e9:	cmp    DWORD PTR [rip+0x0],0x0        # 641f0 <sqlite3VdbeExec+0x14d50>
   641f0:	je     64252 <sqlite3VdbeExec+0x14db2>
   641f2:	mov    rax,QWORD PTR [rip+0x0]        # 641f9 <sqlite3VdbeExec+0x14d59>
   641f9:	mov    QWORD PTR [rsp+0xb0],rdi
   64201:	mov    rdi,r12
   64204:	mov    r10,rax
   64207:	call   r10
   6420a:	mov    rcx,QWORD PTR [rip+0x0]        # 64211 <sqlite3VdbeExec+0x14d71>
   64211:	movsxd rax,eax
   64214:	sub    rcx,rax
   64217:	mov    QWORD PTR [rip+0x0],rcx        # 6421e <sqlite3VdbeExec+0x14d7e>
   6421e:	mov    rax,QWORD PTR [rip+0x0]        # 64225 <sqlite3VdbeExec+0x14d85>
   64225:	sub    rax,0x1
   64229:	mov    QWORD PTR [rip+0x0],rax        # 64230 <sqlite3VdbeExec+0x14d90>
   64230:	mov    rax,QWORD PTR [rip+0x0]        # 64237 <sqlite3VdbeExec+0x14d97>
   64237:	mov    rdi,r12
   6423a:	mov    r10,rax
   6423d:	call   r10
   64240:	mov    rdi,QWORD PTR [rsp+0xb0]
   64248:	mov    r15d,DWORD PTR [rsp+0x32c]
   64250:	jmp    6427a <sqlite3VdbeExec+0x14dda>
   64252:	mov    r15d,DWORD PTR [rsp+0x32c]
   6425a:	mov    rax,QWORD PTR [rip+0x0]        # 64261 <sqlite3VdbeExec+0x14dc1>
   64261:	mov    QWORD PTR [rsp+0xb0],rdi
   64269:	mov    rdi,r12
   6426c:	mov    r10,rax
   6426f:	call   r10
   64272:	mov    rdi,QWORD PTR [rsp+0xb0]
   6427a:	mov    QWORD PTR [r13+0x10],0x0
   64282:	test   r15d,r15d
   64285:	je     642a7 <sqlite3VdbeExec+0x14e07>
   64287:	mov    QWORD PTR [rsp+0xe8],rbp
   6428f:	mov    rbp,r15
   64292:	mov    r13,QWORD PTR [rsp+0xd0]
   6429a:	mov    rbx,QWORD PTR [rsp+0xf8]
   642a2:	jmp    4f712 <sqlite3VdbeExec+0x272>
   642a7:	mov    r12,QWORD PTR [rsp+0x108]
   642af:	mov    r13,QWORD PTR [rsp+0x128]
   642b7:	mov    rax,QWORD PTR [r13+0x50]
   642bb:	mov    rcx,QWORD PTR [r12+0x28]
   642c0:	mov    QWORD PTR [rsp+0xb0],rdi
   642c8:	mov    rdi,rcx
   642cb:	mov    r10,rax
   642ce:	call   r10
   642d1:	mov    rdi,QWORD PTR [rsp+0xb0]
   642d9:	test   eax,eax
   642db:	jne    64302 <sqlite3VdbeExec+0x14e62>
   642dd:	mov    r13,QWORD PTR [rsp+0xf0]
   642e5:	mov    r12d,DWORD PTR [rsp+0x334]
   642ed:	mov    DWORD PTR [rsp+0x32c],r15d
   642f5:	mov    r15d,DWORD PTR [rsp+0x31c]
   642fd:	jmp    4f7bd <sqlite3VdbeExec+0x31d>
   64302:	mov    r12d,DWORD PTR [rsp+0x334]
   6430a:	mov    r13,QWORD PTR [rsp+0xf0]
   64312:	mov    QWORD PTR [rsp+0xe8],rbp
   6431a:	mov    DWORD PTR [rsp+0x32c],r15d
   64322:	mov    r15d,DWORD PTR [rsp+0x31c]
   6432a:	mov    QWORD PTR [rsp+0x100],rbx
   64332:	mov    ebx,DWORD PTR [rsp+0x330]
   64339:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   6433e:	mov    QWORD PTR [rsp+0xd0],r12
   64346:	mov    rax,QWORD PTR [r14+0x30]
   6434a:	and    rax,0x4000000
   64350:	mov    r12d,eax
   64353:	mov    rax,QWORD PTR [r14+0x30]
   64357:	or     rax,0x4000000
   6435d:	mov    QWORD PTR [r14+0x30],rax
   64361:	mov    rax,QWORD PTR [rbp+0x10]
   64365:	mov    r13,QWORD PTR [rax+0x10]
   64369:	movsxd rax,DWORD PTR [rbp+0x4]
   6436d:	imul   rax,rax,0x38
   64371:	lea    r15,[rbx+rax*1]
   64375:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   6437a:	and    eax,0x2
   6437d:	test   eax,eax
   6437f:	jne    64393 <sqlite3VdbeExec+0x14ef3>
   64381:	mov    BYTE PTR [r15+0x16],0x1
   64386:	mov    DWORD PTR [rsp+0x344],r12d
   6438e:	xor    r12d,r12d
   64391:	jmp    643d2 <sqlite3VdbeExec+0x14f32>
   64393:	cmp    BYTE PTR [r15+0x16],0x1
   64398:	jne    643a7 <sqlite3VdbeExec+0x14f07>
   6439a:	mov    DWORD PTR [rsp+0x344],r12d
   643a2:	xor    r12d,r12d
   643a5:	jmp    643d2 <sqlite3VdbeExec+0x14f32>
   643a7:	mov    eax,0x1
   643ac:	mov    DWORD PTR [rsp+0x344],r12d
   643b4:	mov    QWORD PTR [rsp+0xb0],rdi
   643bc:	mov    rdi,r15
   643bf:	mov    rsi,rax
   643c2:	call   643c7 <sqlite3VdbeExec+0x14f27>
   643c7:	mov    r12d,eax
   643ca:	mov    rdi,QWORD PTR [rsp+0xb0]
   643d2:	test   r12d,r12d
   643d5:	je     643f7 <sqlite3VdbeExec+0x14f57>
   643d7:	mov    QWORD PTR [rsp+0xe8],rbp
   643df:	mov    rbp,r12
   643e2:	mov    r13,QWORD PTR [rsp+0xd0]
   643ea:	mov    rbx,QWORD PTR [rsp+0xf8]
   643f2:	jmp    4f712 <sqlite3VdbeExec+0x272>
   643f7:	mov    r12d,DWORD PTR [rsp+0x344]
   643ff:	mov    rax,QWORD PTR [r13+0x0]
   64403:	mov    rax,QWORD PTR [rax+0x98]
   6440a:	mov    rcx,QWORD PTR [r15+0x8]
   6440e:	mov    QWORD PTR [rsp+0xb0],rdi
   64416:	mov    rdi,r13
   64419:	mov    rsi,rcx
   6441c:	mov    r10,rax
   6441f:	call   r10
   64422:	mov    r15d,eax
   64425:	mov    rdi,QWORD PTR [rsp+0xb0]
   6442d:	test   r12d,r12d
   64430:	jne    64440 <sqlite3VdbeExec+0x14fa0>
   64432:	mov    rax,QWORD PTR [r14+0x30]
   64436:	and    rax,0xfffffffffbffffff
   6443c:	mov    QWORD PTR [r14+0x30],rax
   64440:	cmp    QWORD PTR [r13+0x10],0x0
   64445:	je     645dd <sqlite3VdbeExec+0x1513d>
   6444b:	mov    r12,QWORD PTR [rdi]
   6444e:	mov    rax,QWORD PTR [rdi+0xa8]
   64455:	test   rax,rax
   64458:	je     64475 <sqlite3VdbeExec+0x14fd5>
   6445a:	mov    QWORD PTR [rsp+0xb0],rdi
   64462:	mov    rdi,r12
   64465:	mov    rsi,rax
   64468:	call   6446d <sqlite3VdbeExec+0x14fcd>
   6446d:	mov    rdi,QWORD PTR [rsp+0xb0]
   64475:	mov    DWORD PTR [rsp+0x33c],r15d
   6447d:	mov    r15,QWORD PTR [r13+0x10]
   64481:	test   r15,r15
   64484:	jne    6448e <sqlite3VdbeExec+0x14fee>
   64486:	xor    r12d,r12d
   64489:	jmp    64527 <sqlite3VdbeExec+0x15087>
   6448e:	mov    QWORD PTR [rsp+0xb0],rdi
   64496:	mov    rdi,r15
   64499:	call   6449e <sqlite3VdbeExec+0x14ffe>
   6449e:	mov    QWORD PTR [rsp+0x128],r15
   644a6:	lea    r15,[rax+0x1]
   644aa:	mov    rdi,QWORD PTR [rsp+0xb0]
   644b2:	test   r12,r12
   644b5:	je     644cf <sqlite3VdbeExec+0x1502f>
   644b7:	mov    rdi,r12
   644ba:	mov    rsi,r15
   644bd:	call   644c2 <sqlite3VdbeExec+0x15022>
   644c2:	mov    r12,rax
   644c5:	mov    rdi,QWORD PTR [rsp+0xb0]
   644cd:	jmp    644e2 <sqlite3VdbeExec+0x15042>
   644cf:	mov    rdi,r15
   644d2:	call   644d7 <sqlite3VdbeExec+0x15037>
   644d7:	mov    r12,rax
   644da:	mov    rdi,QWORD PTR [rsp+0xb0]
   644e2:	test   r12,r12
   644e5:	jne    644f1 <sqlite3VdbeExec+0x15051>
   644e7:	mov    QWORD PTR [rsp+0x108],r13
   644ef:	jmp    6451f <sqlite3VdbeExec+0x1507f>
   644f1:	mov    QWORD PTR [rsp+0x108],r13
   644f9:	mov    r13,QWORD PTR [rsp+0x128]
   64501:	mov    QWORD PTR [rsp+0xb0],rdi
   64509:	mov    rdi,r12
   6450c:	mov    rsi,r13
   6450f:	mov    rdx,r15
   64512:	call   64517 <sqlite3VdbeExec+0x15077>
   64517:	mov    rdi,QWORD PTR [rsp+0xb0]
   6451f:	mov    r13,QWORD PTR [rsp+0x108]
   64527:	mov    QWORD PTR [rdi+0xa8],r12
   6452e:	mov    r12,QWORD PTR [r13+0x10]
   64532:	test   r12,r12
   64535:	jne    64544 <sqlite3VdbeExec+0x150a4>
   64537:	mov    r15d,DWORD PTR [rsp+0x33c]
   6453f:	jmp    645d5 <sqlite3VdbeExec+0x15135>
   64544:	cmp    DWORD PTR [rip+0x0],0x0        # 6454b <sqlite3VdbeExec+0x150ab>
   6454b:	je     645ad <sqlite3VdbeExec+0x1510d>
   6454d:	mov    rax,QWORD PTR [rip+0x0]        # 64554 <sqlite3VdbeExec+0x150b4>
   64554:	mov    QWORD PTR [rsp+0xb0],rdi
   6455c:	mov    rdi,r12
   6455f:	mov    r10,rax
   64562:	call   r10
   64565:	mov    rcx,QWORD PTR [rip+0x0]        # 6456c <sqlite3VdbeExec+0x150cc>
   6456c:	movsxd rax,eax
   6456f:	sub    rcx,rax
   64572:	mov    QWORD PTR [rip+0x0],rcx        # 64579 <sqlite3VdbeExec+0x150d9>
   64579:	mov    rax,QWORD PTR [rip+0x0]        # 64580 <sqlite3VdbeExec+0x150e0>
   64580:	sub    rax,0x1
   64584:	mov    QWORD PTR [rip+0x0],rax        # 6458b <sqlite3VdbeExec+0x150eb>
   6458b:	mov    rax,QWORD PTR [rip+0x0]        # 64592 <sqlite3VdbeExec+0x150f2>
   64592:	mov    rdi,r12
   64595:	mov    r10,rax
   64598:	call   r10
   6459b:	mov    rdi,QWORD PTR [rsp+0xb0]
   645a3:	mov    r15d,DWORD PTR [rsp+0x33c]
   645ab:	jmp    645d5 <sqlite3VdbeExec+0x15135>
   645ad:	mov    r15d,DWORD PTR [rsp+0x33c]
   645b5:	mov    rax,QWORD PTR [rip+0x0]        # 645bc <sqlite3VdbeExec+0x1511c>
   645bc:	mov    QWORD PTR [rsp+0xb0],rdi
   645c4:	mov    rdi,r12
   645c7:	mov    r10,rax
   645ca:	call   r10
   645cd:	mov    rdi,QWORD PTR [rsp+0xb0]
   645d5:	mov    QWORD PTR [r13+0x10],0x0
   645dd:	movzx  eax,WORD PTR [rdi+0xc8]
   645e4:	and    rax,0xfffffffffffffffc
   645e8:	mov    WORD PTR [rdi+0xc8],ax
   645ef:	test   r15d,r15d
   645f2:	je     64614 <sqlite3VdbeExec+0x15174>
   645f4:	mov    QWORD PTR [rsp+0xe8],rbp
   645fc:	mov    rbp,r15
   645ff:	mov    r13,QWORD PTR [rsp+0xd0]
   64607:	mov    rbx,QWORD PTR [rsp+0xf8]
   6460f:	jmp    4f712 <sqlite3VdbeExec+0x272>
   64614:	mov    DWORD PTR [rsp+0x32c],r15d
   6461c:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   64621:	mov    r15d,DWORD PTR [rsp+0x31c]
   64629:	mov    r13,QWORD PTR [rsp+0xf0]
   64631:	mov    QWORD PTR [rsp+0xd0],r12
   64639:	mov    r12d,DWORD PTR [rsp+0x334]
   64641:	mov    QWORD PTR [rsp+0x108],0x0
   6464d:	cmp    BYTE PTR [r14+0x67],0x0
   64652:	je     64664 <sqlite3VdbeExec+0x151c4>
   64654:	mov    rbx,rbp
   64657:	mov    rbp,QWORD PTR [rsp+0xf8]
   6465f:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   64664:	mov    rax,QWORD PTR [rbp+0x10]
   64668:	mov    QWORD PTR [rsp+0xf0],r13
   64670:	mov    r13,QWORD PTR [rax+0x10]
   64674:	test   r13,r13
   64677:	je     64680 <sqlite3VdbeExec+0x151e0>
   64679:	cmp    QWORD PTR [r13+0x0],0x0
   6467e:	jne    646a5 <sqlite3VdbeExec+0x15205>
   64680:	mov    ebx,0x6
   64685:	mov    QWORD PTR [rsp+0xe8],rbp
   6468d:	mov    rbp,rbx
   64690:	mov    r13,QWORD PTR [rsp+0xd0]
   64698:	mov    rbx,QWORD PTR [rsp+0xf8]
   646a0:	jmp    4f712 <sqlite3VdbeExec+0x272>
   646a5:	mov    rax,QWORD PTR [r13+0x0]
   646a9:	mov    ecx,DWORD PTR [rbp+0x8]
   646ac:	cmp    QWORD PTR [rax+0x68],0x0
   646b1:	jne    646c0 <sqlite3VdbeExec+0x15220>
   646b3:	mov    DWORD PTR [rsp+0x334],r12d
   646bb:	jmp    64976 <sqlite3VdbeExec+0x154d6>
   646c0:	mov    DWORD PTR [rsp+0x334],r12d
   646c8:	movzx  r12d,BYTE PTR [r14+0x6c]
   646cd:	mov    rdx,QWORD PTR [rdi+0x70]
   646d1:	movsxd rsi,DWORD PTR [rbp+0xc]
   646d5:	imul   rsi,rsi,0x38
   646d9:	add    rsi,rbx
   646dc:	xor    r8d,r8d
   646df:	mov    r11,rsi
   646e2:	mov    rsi,r8
   646e5:	mov    r8,r11
   646e8:	jmp    646f8 <sqlite3VdbeExec+0x15258>
   646ea:	mov    r9,rsi
   646ed:	mov    QWORD PTR [rdx+r9*8],r8
   646f1:	add    r8,0x38
   646f5:	add    esi,0x1
   646f8:	cmp    esi,ecx
   646fa:	jl     646ea <sqlite3VdbeExec+0x1524a>
   646fc:	movzx  esi,WORD PTR [rbp+0x2]
   64700:	mov    BYTE PTR [r14+0x6c],sil
   64704:	mov    rax,QWORD PTR [rax+0x68]
   64708:	mov    DWORD PTR [rsp+0x31c],r15d
   64710:	lea    r15,[rsp+0x108]
   64718:	mov    rsi,r15
   6471b:	mov    QWORD PTR [rsp+0xb0],rdi
   64723:	mov    rdi,r13
   64726:	mov    r10,rax
   64729:	mov    r11,rsi
   6472c:	mov    rsi,rcx
   6472f:	mov    rcx,r11
   64732:	call   r10
   64735:	mov    r15d,eax
   64738:	mov    BYTE PTR [r14+0x6c],r12b
   6473c:	mov    rdi,QWORD PTR [rsp+0xb0]
   64744:	cmp    QWORD PTR [r13+0x10],0x0
   64749:	je     648d9 <sqlite3VdbeExec+0x15439>
   6474f:	mov    r12,QWORD PTR [rdi]
   64752:	mov    rax,QWORD PTR [rdi+0xa8]
   64759:	test   rax,rax
   6475c:	je     64771 <sqlite3VdbeExec+0x152d1>
   6475e:	mov    rdi,r12
   64761:	mov    rsi,rax
   64764:	call   64769 <sqlite3VdbeExec+0x152c9>
   64769:	mov    rdi,QWORD PTR [rsp+0xb0]
   64771:	mov    DWORD PTR [rsp+0x33c],r15d
   64779:	mov    r15,QWORD PTR [r13+0x10]
   6477d:	test   r15,r15
   64780:	jne    6478a <sqlite3VdbeExec+0x152ea>
   64782:	xor    r12d,r12d
   64785:	jmp    64823 <sqlite3VdbeExec+0x15383>
   6478a:	mov    QWORD PTR [rsp+0xb0],rdi
   64792:	mov    rdi,r15
   64795:	call   6479a <sqlite3VdbeExec+0x152fa>
   6479a:	mov    QWORD PTR [rsp+0x120],r15
   647a2:	lea    r15,[rax+0x1]
   647a6:	mov    rdi,QWORD PTR [rsp+0xb0]
   647ae:	test   r12,r12
   647b1:	je     647cb <sqlite3VdbeExec+0x1532b>
   647b3:	mov    rdi,r12
   647b6:	mov    rsi,r15
   647b9:	call   647be <sqlite3VdbeExec+0x1531e>
   647be:	mov    r12,rax
   647c1:	mov    rdi,QWORD PTR [rsp+0xb0]
   647c9:	jmp    647de <sqlite3VdbeExec+0x1533e>
   647cb:	mov    rdi,r15
   647ce:	call   647d3 <sqlite3VdbeExec+0x15333>
   647d3:	mov    r12,rax
   647d6:	mov    rdi,QWORD PTR [rsp+0xb0]
   647de:	test   r12,r12
   647e1:	jne    647ed <sqlite3VdbeExec+0x1534d>
   647e3:	mov    QWORD PTR [rsp+0x128],r13
   647eb:	jmp    6481b <sqlite3VdbeExec+0x1537b>
   647ed:	mov    QWORD PTR [rsp+0x128],r13
   647f5:	mov    r13,QWORD PTR [rsp+0x120]
   647fd:	mov    QWORD PTR [rsp+0xb0],rdi
   64805:	mov    rdi,r12
   64808:	mov    rsi,r13
   6480b:	mov    rdx,r15
   6480e:	call   64813 <sqlite3VdbeExec+0x15373>
   64813:	mov    rdi,QWORD PTR [rsp+0xb0]
   6481b:	mov    r13,QWORD PTR [rsp+0x128]
   64823:	mov    QWORD PTR [rdi+0xa8],r12
   6482a:	mov    r12,QWORD PTR [r13+0x10]
   6482e:	test   r12,r12
   64831:	jne    64840 <sqlite3VdbeExec+0x153a0>
   64833:	mov    r15d,DWORD PTR [rsp+0x33c]
   6483b:	jmp    648d1 <sqlite3VdbeExec+0x15431>
   64840:	cmp    DWORD PTR [rip+0x0],0x0        # 64847 <sqlite3VdbeExec+0x153a7>
   64847:	je     648a9 <sqlite3VdbeExec+0x15409>
   64849:	mov    rax,QWORD PTR [rip+0x0]        # 64850 <sqlite3VdbeExec+0x153b0>
   64850:	mov    QWORD PTR [rsp+0xb0],rdi
   64858:	mov    rdi,r12
   6485b:	mov    r10,rax
   6485e:	call   r10
   64861:	mov    rcx,QWORD PTR [rip+0x0]        # 64868 <sqlite3VdbeExec+0x153c8>
   64868:	movsxd rax,eax
   6486b:	sub    rcx,rax
   6486e:	mov    QWORD PTR [rip+0x0],rcx        # 64875 <sqlite3VdbeExec+0x153d5>
   64875:	mov    rax,QWORD PTR [rip+0x0]        # 6487c <sqlite3VdbeExec+0x153dc>
   6487c:	sub    rax,0x1
   64880:	mov    QWORD PTR [rip+0x0],rax        # 64887 <sqlite3VdbeExec+0x153e7>
   64887:	mov    rax,QWORD PTR [rip+0x0]        # 6488e <sqlite3VdbeExec+0x153ee>
   6488e:	mov    rdi,r12
   64891:	mov    r10,rax
   64894:	call   r10
   64897:	mov    rdi,QWORD PTR [rsp+0xb0]
   6489f:	mov    r15d,DWORD PTR [rsp+0x33c]
   648a7:	jmp    648d1 <sqlite3VdbeExec+0x15431>
   648a9:	mov    r15d,DWORD PTR [rsp+0x33c]
   648b1:	mov    rax,QWORD PTR [rip+0x0]        # 648b8 <sqlite3VdbeExec+0x15418>
   648b8:	mov    QWORD PTR [rsp+0xb0],rdi
   648c0:	mov    rdi,r12
   648c3:	mov    r10,rax
   648c6:	call   r10
   648c9:	mov    rdi,QWORD PTR [rsp+0xb0]
   648d1:	mov    QWORD PTR [r13+0x10],0x0
   648d9:	test   r15d,r15d
   648dc:	jne    648f0 <sqlite3VdbeExec+0x15450>
   648de:	cmp    DWORD PTR [rbp+0x4],0x0
   648e2:	je     648f0 <sqlite3VdbeExec+0x15450>
   648e4:	mov    rax,QWORD PTR [rsp+0x108]
   648ec:	mov    QWORD PTR [r14+0x38],rax
   648f0:	mov    eax,r15d
   648f3:	and    eax,0xff
   648f8:	cmp    eax,0x13
   648fb:	jne    64933 <sqlite3VdbeExec+0x15493>
   648fd:	mov    rax,QWORD PTR [rbp+0x10]
   64901:	cmp    BYTE PTR [rax+0x1c],0x0
   64905:	je     64933 <sqlite3VdbeExec+0x15493>
   64907:	cmp    WORD PTR [rbp+0x2],0x4
   6490c:	jne    64916 <sqlite3VdbeExec+0x15476>
   6490e:	xor    r12d,r12d
   64911:	mov    r15,r12
   64914:	jmp    64931 <sqlite3VdbeExec+0x15491>
   64916:	cmp    WORD PTR [rbp+0x2],0x5
   6491b:	jne    64924 <sqlite3VdbeExec+0x15484>
   6491d:	mov    eax,0x2
   64922:	jmp    6492b <sqlite3VdbeExec+0x1548b>
   64924:	movzx  eax,WORD PTR [rbp+0x2]
   64928:	movzx  eax,al
   6492b:	mov    BYTE PTR [rdi+0xc4],al
   64931:	jmp    6493f <sqlite3VdbeExec+0x1549f>
   64933:	mov    rax,QWORD PTR [rdi+0x38]
   64937:	add    rax,0x1
   6493b:	mov    QWORD PTR [rdi+0x38],rax
   6493f:	test   r15d,r15d
   64942:	jne    64956 <sqlite3VdbeExec+0x154b6>
   64944:	mov    DWORD PTR [rsp+0x32c],r15d
   6494c:	mov    r15d,DWORD PTR [rsp+0x31c]
   64954:	jmp    64976 <sqlite3VdbeExec+0x154d6>
   64956:	mov    QWORD PTR [rsp+0xe8],rbp
   6495e:	mov    rbp,r15
   64961:	mov    r13,QWORD PTR [rsp+0xd0]
   64969:	mov    rbx,QWORD PTR [rsp+0xf8]
   64971:	jmp    4f712 <sqlite3VdbeExec+0x272>
   64976:	mov    DWORD PTR [rsp+0x31c],r15d
   6497e:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   64983:	mov    r15d,DWORD PTR [rsp+0x31c]
   6498b:	mov    r13,QWORD PTR [rsp+0xf0]
   64993:	mov    QWORD PTR [rsp+0xd0],r12
   6499b:	mov    r12d,DWORD PTR [rsp+0x334]
   649a3:	mov    rax,QWORD PTR [rdi+0x68]
   649a7:	movsxd rcx,DWORD PTR [rbp+0x8]
   649ab:	imul   rcx,rcx,0x38
   649af:	lea    rdx,[rax+rcx*1]
   649b3:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   649b8:	and    eax,0x9000
   649bd:	test   eax,eax
   649bf:	je     649de <sqlite3VdbeExec+0x1553e>
   649c1:	mov    QWORD PTR [rsp+0xb0],rdi
   649c9:	mov    rdi,rdx
   649cc:	call   649d1 <sqlite3VdbeExec+0x15531>
   649d1:	mov    rdi,QWORD PTR [rsp+0xb0]
   649d9:	mov    rdx,rax
   649dc:	jmp    649e4 <sqlite3VdbeExec+0x15544>
   649de:	mov    WORD PTR [rdx+0x14],0x4
   649e4:	mov    rax,QWORD PTR [r14+0x20]
   649e8:	movsxd rcx,DWORD PTR [rbp+0x4]
   649ec:	shl    rcx,0x5
   649f0:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   649f5:	mov    rax,QWORD PTR [rax+0x8]
   649f9:	mov    eax,DWORD PTR [rax+0x40]
   649fc:	mov    QWORD PTR [rdx],rax
   649ff:	mov    DWORD PTR [rsp+0x31c],r15d
   64a07:	mov    QWORD PTR [rsp+0xf0],r13
   64a0f:	mov    DWORD PTR [rsp+0x334],r12d
   64a17:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   64a1c:	mov    r15d,DWORD PTR [rsp+0x31c]
   64a24:	mov    r13,QWORD PTR [rsp+0xf0]
   64a2c:	mov    QWORD PTR [rsp+0xd0],r12
   64a34:	mov    r12d,DWORD PTR [rsp+0x334]
   64a3c:	mov    rax,QWORD PTR [rdi+0x68]
   64a40:	movsxd rcx,DWORD PTR [rbp+0x8]
   64a44:	imul   rcx,rcx,0x38
   64a48:	lea    rdx,[rax+rcx*1]
   64a4c:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   64a51:	and    eax,0x9000
   64a56:	test   eax,eax
   64a58:	je     64a77 <sqlite3VdbeExec+0x155d7>
   64a5a:	mov    QWORD PTR [rsp+0xb0],rdi
   64a62:	mov    rdi,rdx
   64a65:	call   64a6a <sqlite3VdbeExec+0x155ca>
   64a6a:	mov    rdi,QWORD PTR [rsp+0xb0]
   64a72:	mov    rdx,rax
   64a75:	jmp    64a7d <sqlite3VdbeExec+0x155dd>
   64a77:	mov    WORD PTR [rdx+0x14],0x4
   64a7d:	mov    rax,QWORD PTR [r14+0x20]
   64a81:	movsxd rcx,DWORD PTR [rbp+0x4]
   64a85:	shl    rcx,0x5
   64a89:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   64a8e:	xor    ecx,ecx
   64a90:	cmp    DWORD PTR [rbp+0xc],0x0
   64a94:	je     64aa5 <sqlite3VdbeExec+0x15605>
   64a96:	mov    rcx,QWORD PTR [rax+0x8]
   64a9a:	mov    ecx,DWORD PTR [rcx+0x40]
   64a9d:	cmp    ecx,DWORD PTR [rbp+0xc]
   64aa0:	jae    64aa5 <sqlite3VdbeExec+0x15605>
   64aa2:	mov    ecx,DWORD PTR [rbp+0xc]
   64aa5:	mov    rsi,QWORD PTR [rax+0x8]
   64aa9:	mov    r8,QWORD PTR [rax]
   64aac:	mov    QWORD PTR [rsi+0x8],r8
   64ab0:	mov    rax,QWORD PTR [rax+0x8]
   64ab4:	mov    rax,QWORD PTR [rax]
   64ab7:	test   ecx,ecx
   64ab9:	jbe    64ac1 <sqlite3VdbeExec+0x15621>
   64abb:	mov    DWORD PTR [rax+0xbc],ecx
   64ac1:	mov    eax,DWORD PTR [rax+0xbc]
   64ac7:	mov    QWORD PTR [rdx],rax
   64aca:	mov    DWORD PTR [rsp+0x31c],r15d
   64ad2:	mov    QWORD PTR [rsp+0xf0],r13
   64ada:	mov    DWORD PTR [rsp+0x334],r12d
   64ae2:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   64ae7:	mov    r15d,DWORD PTR [rsp+0x31c]
   64aef:	mov    r13,QWORD PTR [rsp+0xf0]
   64af7:	mov    QWORD PTR [rsp+0xd0],r12
   64aff:	mov    r12d,DWORD PTR [rsp+0x334]
   64b07:	mov    DWORD PTR [rsp+0x334],r12d
   64b0f:	mov    r12,QWORD PTR [rbp+0x10]
   64b13:	movsxd rax,DWORD PTR [rbp+0xc]
   64b17:	imul   rax,rax,0x38
   64b1b:	mov    QWORD PTR [rsp+0xf0],r13
   64b23:	lea    r13,[rbx+rax*1]
   64b27:	cmp    r13,QWORD PTR [r12]
   64b2b:	je     64b64 <sqlite3VdbeExec+0x156c4>
   64b2d:	mov    QWORD PTR [r12+0x18],rdi
   64b32:	mov    QWORD PTR [r12],r13
   64b36:	mov    BYTE PTR [r12+0x28],r15b
   64b3b:	movzx  eax,WORD PTR [r12+0x2a]
   64b41:	sub    eax,0x1
   64b44:	jmp    64b60 <sqlite3VdbeExec+0x156c0>
   64b46:	mov    rcx,rax
   64b49:	mov    edx,eax
   64b4b:	add    edx,DWORD PTR [rbp+0x8]
   64b4e:	movsxd rdx,edx
   64b51:	imul   rdx,rdx,0x38
   64b55:	add    rdx,rbx
   64b58:	mov    QWORD PTR [r12+rcx*8+0x30],rdx
   64b5d:	sub    eax,0x1
   64b60:	test   eax,eax
   64b62:	jge    64b46 <sqlite3VdbeExec+0x156a6>
   64b64:	movzx  eax,WORD PTR [r13+0x14]
   64b69:	and    eax,0xfffff240
   64b6e:	or     eax,0x1
   64b71:	mov    WORD PTR [r13+0x14],ax
   64b76:	mov    rax,QWORD PTR [r12+0x8]
   64b7b:	mov    rax,QWORD PTR [rax+0x18]
   64b7f:	movzx  ecx,WORD PTR [r12+0x2a]
   64b85:	lea    rdx,[r12+0x30]
   64b8a:	mov    QWORD PTR [rsp+0xb0],rdi
   64b92:	mov    rdi,r12
   64b95:	mov    rsi,rcx
   64b98:	mov    r10,rax
   64b9b:	call   r10
   64b9e:	mov    rdi,QWORD PTR [rsp+0xb0]
   64ba6:	cmp    DWORD PTR [r12+0x24],0x0
   64bac:	je     64e06 <sqlite3VdbeExec+0x15966>
   64bb2:	cmp    DWORD PTR [r12+0x24],0x0
   64bb8:	jle    64c46 <sqlite3VdbeExec+0x157a6>
   64bbe:	test   r13,r13
   64bc1:	jne    64bc7 <sqlite3VdbeExec+0x15727>
   64bc3:	xor    eax,eax
   64bc5:	jmp    64c15 <sqlite3VdbeExec+0x15775>
   64bc7:	movzx  eax,WORD PTR [r13+0x14]
   64bcc:	and    eax,0x202
   64bd1:	cmp    eax,0x202
   64bd6:	jne    64be5 <sqlite3VdbeExec+0x15745>
   64bd8:	cmp    BYTE PTR [r13+0x16],0x1
   64bdd:	jne    64be5 <sqlite3VdbeExec+0x15745>
   64bdf:	mov    rax,QWORD PTR [r13+0x8]
   64be3:	jmp    64c15 <sqlite3VdbeExec+0x15775>
   64be5:	movzx  eax,WORD PTR [r13+0x14]
   64bea:	and    eax,0x1
   64bed:	test   eax,eax
   64bef:	je     64bf5 <sqlite3VdbeExec+0x15755>
   64bf1:	xor    eax,eax
   64bf3:	jmp    64c15 <sqlite3VdbeExec+0x15775>
   64bf5:	mov    eax,0x1
   64bfa:	mov    QWORD PTR [rsp+0xb0],rdi
   64c02:	mov    rdi,r13
   64c05:	mov    rsi,rax
   64c08:	call   64c0d <sqlite3VdbeExec+0x1576d>
   64c0d:	mov    rdi,QWORD PTR [rsp+0xb0]
   64c15:	lea    r13,[rip+0x0]        # 64c1c <sqlite3VdbeExec+0x1577c>
   64c1c:	mov    QWORD PTR [rsp+0xb0],rdi
   64c24:	mov    rsi,r13
   64c27:	mov    rdx,rax
   64c2a:	xor    eax,eax
   64c2c:	call   64c31 <sqlite3VdbeExec+0x15791>
   64c31:	mov    r13d,DWORD PTR [r12+0x24]
   64c36:	mov    rdi,QWORD PTR [rsp+0xb0]
   64c3e:	mov    DWORD PTR [rsp+0x32c],r13d
   64c46:	lea    r13,[rdi+0x128]
   64c4d:	mov    QWORD PTR [rsp+0x108],r13
   64c55:	mov    r13d,DWORD PTR [r12+0x20]
   64c5a:	mov    DWORD PTR [rsp+0x33c],r13d
   64c62:	mov    r13d,DWORD PTR [rbp+0x4]
   64c66:	mov    DWORD PTR [rsp+0x344],r13d
   64c6e:	mov    r13,QWORD PTR [rsp+0x108]
   64c76:	jmp    64c7c <sqlite3VdbeExec+0x157dc>
   64c78:	add    r13,0x18
   64c7c:	cmp    QWORD PTR [r13+0x0],0x0
   64c81:	je     64db4 <sqlite3VdbeExec+0x15914>
   64c87:	mov    QWORD PTR [rsp+0xe8],rbp
   64c8f:	mov    rbp,QWORD PTR [r13+0x0]
   64c93:	mov    DWORD PTR [rsp+0x31c],r15d
   64c9b:	mov    r15d,DWORD PTR [rsp+0x33c]
   64ca3:	test   r15d,r15d
   64ca6:	jge    64cb5 <sqlite3VdbeExec+0x15815>
   64ca8:	mov    r15d,DWORD PTR [rsp+0x344]
   64cb0:	jmp    64d47 <sqlite3VdbeExec+0x158a7>
   64cb5:	cmp    r15d,DWORD PTR [rbp+0x0]
   64cb9:	je     64cd8 <sqlite3VdbeExec+0x15838>
   64cbb:	mov    DWORD PTR [rsp+0x33c],r15d
   64cc3:	mov    r15d,DWORD PTR [rsp+0x31c]
   64ccb:	mov    r13,rbp
   64cce:	mov    rbp,QWORD PTR [rsp+0xe8]
   64cd6:	jmp    64c78 <sqlite3VdbeExec+0x157d8>
   64cd8:	cmp    DWORD PTR [rbp+0x4],0x0
   64cdc:	jge    64cfe <sqlite3VdbeExec+0x1585e>
   64cde:	mov    DWORD PTR [rsp+0x33c],r15d
   64ce6:	mov    r15d,DWORD PTR [rsp+0x31c]
   64cee:	mov    r13,rbp
   64cf1:	mov    rbp,QWORD PTR [rsp+0xe8]
   64cf9:	jmp    64c78 <sqlite3VdbeExec+0x157d8>
   64cfe:	cmp    DWORD PTR [rbp+0x4],0x1f
   64d02:	jle    64d16 <sqlite3VdbeExec+0x15876>
   64d04:	mov    DWORD PTR [rsp+0x33c],r15d
   64d0c:	mov    r15d,DWORD PTR [rsp+0x344]
   64d14:	jmp    64d47 <sqlite3VdbeExec+0x158a7>
   64d16:	mov    eax,0x1
   64d1b:	mov    ecx,DWORD PTR [rbp+0x4]
   64d1e:	shl    eax,cl
   64d20:	mov    r15d,DWORD PTR [rsp+0x344]
   64d28:	and    eax,r15d
   64d2b:	test   eax,eax
   64d2d:	je     64d47 <sqlite3VdbeExec+0x158a7>
   64d2f:	mov    r15d,DWORD PTR [rsp+0x31c]
   64d37:	mov    r13,rbp
   64d3a:	mov    rbp,QWORD PTR [rsp+0xe8]
   64d42:	jmp    64c78 <sqlite3VdbeExec+0x157d8>
   64d47:	cmp    QWORD PTR [rbp+0x10],0x0
   64d4c:	je     64d6f <sqlite3VdbeExec+0x158cf>
   64d4e:	mov    rax,QWORD PTR [rbp+0x10]
   64d52:	mov    rcx,QWORD PTR [rbp+0x8]
   64d56:	mov    QWORD PTR [rsp+0xb0],rdi
   64d5e:	mov    rdi,rcx
   64d61:	mov    r10,rax
   64d64:	call   r10
   64d67:	mov    rdi,QWORD PTR [rsp+0xb0]
   64d6f:	mov    rax,QWORD PTR [rbp+0x18]
   64d73:	mov    QWORD PTR [r13+0x0],rax
   64d77:	test   rbp,rbp
   64d7a:	je     64d97 <sqlite3VdbeExec+0x158f7>
   64d7c:	mov    QWORD PTR [rsp+0xb0],rdi
   64d84:	mov    rdi,r14
   64d87:	mov    rsi,rbp
   64d8a:	call   64d8f <sqlite3VdbeExec+0x158ef>
   64d8f:	mov    rdi,QWORD PTR [rsp+0xb0]
   64d97:	mov    DWORD PTR [rsp+0x344],r15d
   64d9f:	mov    r15d,DWORD PTR [rsp+0x31c]
   64da7:	mov    rbp,QWORD PTR [rsp+0xe8]
   64daf:	jmp    64c7c <sqlite3VdbeExec+0x157dc>
   64db4:	mov    DWORD PTR [rsp+0x31c],r15d
   64dbc:	mov    QWORD PTR [rsp+0xe8],rbp
   64dc4:	mov    DWORD PTR [r12+0x24],0x0
   64dcd:	mov    ebp,DWORD PTR [rsp+0x32c]
   64dd4:	test   ebp,ebp
   64dd6:	jne    64df1 <sqlite3VdbeExec+0x15951>
   64dd8:	mov    r15d,DWORD PTR [rsp+0x31c]
   64de0:	mov    DWORD PTR [rsp+0x32c],ebp
   64de7:	mov    rbp,QWORD PTR [rsp+0xe8]
   64def:	jmp    64e06 <sqlite3VdbeExec+0x15966>
   64df1:	mov    r13,QWORD PTR [rsp+0xd0]
   64df9:	mov    rbx,QWORD PTR [rsp+0xf8]
   64e01:	jmp    4f712 <sqlite3VdbeExec+0x272>
   64e06:	mov    DWORD PTR [rsp+0x31c],r15d
   64e0e:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   64e13:	mov    r15d,DWORD PTR [rsp+0x31c]
   64e1b:	mov    r13,QWORD PTR [rsp+0xf0]
   64e23:	mov    QWORD PTR [rsp+0xd0],r12
   64e2b:	mov    r12d,DWORD PTR [rsp+0x334]
   64e33:	movsxd rax,DWORD PTR [rbp+0x4]
   64e37:	imul   rax,rax,0x38
   64e3b:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   64e40:	and    ecx,0xfffff7ff
   64e46:	mov    WORD PTR [rbx+rax*1+0x14],cx
   64e4b:	mov    DWORD PTR [rsp+0x31c],r15d
   64e53:	mov    QWORD PTR [rsp+0xf0],r13
   64e5b:	mov    DWORD PTR [rsp+0x334],r12d
   64e63:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   64e68:	mov    r15d,DWORD PTR [rsp+0x31c]
   64e70:	mov    r13,QWORD PTR [rsp+0xf0]
   64e78:	mov    QWORD PTR [rsp+0xd0],r12
   64e80:	mov    r12d,DWORD PTR [rsp+0x334]
   64e88:	movsxd rax,DWORD PTR [rbp+0x4]
   64e8c:	imul   rax,rax,0x38
   64e90:	movsxd rcx,DWORD PTR [rbp+0x8]
   64e94:	imul   rcx,rcx,0x38
   64e98:	add    rcx,rbx
   64e9b:	movzx  edx,WORD PTR [rbx+rax*1+0x14]
   64ea0:	and    edx,0x800
   64ea6:	test   edx,edx
   64ea8:	je     64ee5 <sqlite3VdbeExec+0x15a45>
   64eaa:	movzx  eax,BYTE PTR [rbx+rax*1+0x17]
   64eaf:	movzx  edx,WORD PTR [rcx+0x14]
   64eb3:	and    edx,0x9000
   64eb9:	test   edx,edx
   64ebb:	je     64eda <sqlite3VdbeExec+0x15a3a>
   64ebd:	mov    QWORD PTR [rsp+0xb0],rdi
   64ec5:	mov    rdi,rcx
   64ec8:	mov    rsi,rax
   64ecb:	call   64ed0 <sqlite3VdbeExec+0x15a30>
   64ed0:	mov    rdi,QWORD PTR [rsp+0xb0]
   64ed8:	jmp    64f12 <sqlite3VdbeExec+0x15a72>
   64eda:	mov    QWORD PTR [rcx],rax
   64edd:	mov    WORD PTR [rcx+0x14],0x4
   64ee3:	jmp    64f12 <sqlite3VdbeExec+0x15a72>
   64ee5:	movzx  eax,WORD PTR [rcx+0x14]
   64ee9:	and    eax,0x9000
   64eee:	test   eax,eax
   64ef0:	je     64f0c <sqlite3VdbeExec+0x15a6c>
   64ef2:	mov    QWORD PTR [rsp+0xb0],rdi
   64efa:	mov    rdi,rcx
   64efd:	call   64f02 <sqlite3VdbeExec+0x15a62>
   64f02:	mov    rdi,QWORD PTR [rsp+0xb0]
   64f0a:	jmp    64f12 <sqlite3VdbeExec+0x15a72>
   64f0c:	mov    WORD PTR [rcx+0x14],0x1
   64f12:	mov    DWORD PTR [rsp+0x31c],r15d
   64f1a:	mov    QWORD PTR [rsp+0xf0],r13
   64f22:	mov    DWORD PTR [rsp+0x334],r12d
   64f2a:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   64f2f:	mov    r15d,DWORD PTR [rsp+0x31c]
   64f37:	mov    r13,QWORD PTR [rsp+0xf0]
   64f3f:	mov    QWORD PTR [rsp+0xd0],r12
   64f47:	mov    r12d,DWORD PTR [rsp+0x334]
   64f4f:	movsxd rax,DWORD PTR [rbp+0x4]
   64f53:	imul   rax,rax,0x38
   64f57:	movsxd rcx,DWORD PTR [rbp+0x8]
   64f5b:	imul   rcx,rcx,0x38
   64f5f:	movzx  edx,WORD PTR [rbx+rax*1+0x14]
   64f64:	and    edx,0x1
   64f67:	test   edx,edx
   64f69:	je     64f7c <sqlite3VdbeExec+0x15adc>
   64f6b:	movzx  eax,WORD PTR [rbx+rcx*1+0x14]
   64f70:	and    eax,0xfffff7ff
   64f75:	mov    WORD PTR [rbx+rcx*1+0x14],ax
   64f7a:	jmp    64f9a <sqlite3VdbeExec+0x15afa>
   64f7c:	movzx  edx,WORD PTR [rbx+rcx*1+0x14]
   64f81:	or     edx,0x800
   64f87:	mov    WORD PTR [rbx+rcx*1+0x14],dx
   64f8c:	mov    rax,QWORD PTR [rbx+rax*1]
   64f90:	and    rax,0xff
   64f96:	mov    BYTE PTR [rbx+rcx*1+0x17],al
   64f9a:	mov    DWORD PTR [rsp+0x31c],r15d
   64fa2:	mov    QWORD PTR [rsp+0xf0],r13
   64faa:	mov    DWORD PTR [rsp+0x334],r12d
   64fb2:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   64fb7:	mov    r15d,DWORD PTR [rsp+0x31c]
   64fbf:	mov    r13,QWORD PTR [rsp+0xf0]
   64fc7:	mov    QWORD PTR [rsp+0xd0],r12
   64fcf:	mov    r12d,DWORD PTR [rsp+0x334]
   64fd7:	movsxd rax,DWORD PTR [rbp+0x4]
   64fdb:	mov    DWORD PTR [rsp+0x334],r12d
   64fe3:	imul   r12,rax,0x38
   64fe7:	mov    QWORD PTR [rsp+0x108],r12
   64fef:	movsxd r12,DWORD PTR [rbp+0xc]
   64ff3:	mov    QWORD PTR [rsp+0x128],r12
   64ffb:	add    r12d,DWORD PTR [rbp+0x10]
   64fff:	mov    DWORD PTR [rsp+0x31c],r15d
   65007:	mov    DWORD PTR [rsp+0x344],r12d
   6500f:	mov    r12,QWORD PTR [rsp+0x128]
   65017:	xor    r15d,r15d
   6501a:	jmp    6512c <sqlite3VdbeExec+0x15c8c>
   6501f:	mov    DWORD PTR [rsp+0x344],r13d
   65027:	mov    QWORD PTR [rsp+0x128],r12
   6502f:	mov    r12,r15
   65032:	mov    r15d,DWORD PTR [rsp+0x31c]
   6503a:	mov    rax,rcx
   6503d:	mov    r13,QWORD PTR [rsp+0xf0]
   65045:	movzx  ecx,WORD PTR [rax+0x14]
   65049:	and    ecx,0x8
   6504c:	test   ecx,ecx
   6504e:	je     650ee <sqlite3VdbeExec+0x15c4e>
   65054:	movzx  ecx,WORD PTR [rax+0x14]
   65058:	mov    edx,ecx
   6505a:	and    edx,0x24
   6505d:	test   edx,edx
   6505f:	je     65069 <sqlite3VdbeExec+0x15bc9>
   65061:	mov    rax,QWORD PTR [rax]
   65064:	jmp    650e9 <sqlite3VdbeExec+0x15c49>
   65069:	mov    edx,ecx
   6506b:	and    edx,0x8
   6506e:	test   edx,edx
   65070:	je     650bf <sqlite3VdbeExec+0x15c1f>
   65072:	movsd  xmm0,QWORD PTR [rax]
   65076:	movabs r11,0xc3dfffffffffffff
   65080:	movq   xmm1,r11
   65085:	ucomisd xmm1,xmm0
   65089:	jbe    65097 <sqlite3VdbeExec+0x15bf7>
   6508b:	movabs rax,0x8000000000000000
   65095:	jmp    650bd <sqlite3VdbeExec+0x15c1d>
   65097:	movabs r11,0x43dfffffffffffff
   650a1:	movq   xmm1,r11
   650a6:	ucomisd xmm0,xmm1
   650aa:	jbe    650b8 <sqlite3VdbeExec+0x15c18>
   650ac:	movabs rax,0x7fffffffffffffff
   650b6:	jmp    650bd <sqlite3VdbeExec+0x15c1d>
   650b8:	cvttsd2si rax,xmm0
   650bd:	jmp    650e9 <sqlite3VdbeExec+0x15c49>
   650bf:	and    ecx,0x12
   650c2:	test   ecx,ecx
   650c4:	je     650e7 <sqlite3VdbeExec+0x15c47>
   650c6:	cmp    QWORD PTR [rax+0x8],0x0
   650cb:	je     650e7 <sqlite3VdbeExec+0x15c47>
   650cd:	mov    QWORD PTR [rsp+0xb0],rdi
   650d5:	mov    rdi,rax
   650d8:	call   650dd <sqlite3VdbeExec+0x15c3d>
   650dd:	mov    rdi,QWORD PTR [rsp+0xb0]
   650e5:	jmp    650e9 <sqlite3VdbeExec+0x15c49>
   650e7:	xor    eax,eax
   650e9:	add    r12,rax
   650ec:	jmp    65108 <sqlite3VdbeExec+0x15c68>
   650ee:	movzx  ecx,WORD PTR [rax+0x14]
   650f2:	and    ecx,0x12
   650f5:	test   ecx,ecx
   650f7:	je     65108 <sqlite3VdbeExec+0x15c68>
   650f9:	movzx  eax,WORD PTR [rax+0x14]
   650fd:	and    eax,0x12
   65100:	add    eax,0xffd
   65105:	add    r12,rax
   65108:	mov    QWORD PTR [rsp+0x120],r12
   65110:	mov    r12,QWORD PTR [rsp+0x128]
   65118:	add    r12d,0x1
   6511c:	mov    DWORD PTR [rsp+0x31c],r15d
   65124:	mov    r15,QWORD PTR [rsp+0x120]
   6512c:	mov    QWORD PTR [rsp+0xf0],r13
   65134:	mov    r13d,DWORD PTR [rsp+0x344]
   6513c:	cmp    r12d,r13d
   6513f:	jge    65184 <sqlite3VdbeExec+0x15ce4>
   65141:	movsxd rax,r12d
   65144:	imul   rax,rax,0x38
   65148:	lea    rcx,[rbx+rax*1]
   6514c:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   65151:	and    eax,0x24
   65154:	test   eax,eax
   65156:	je     6501f <sqlite3VdbeExec+0x15b7f>
   6515c:	add    r15,QWORD PTR [rcx]
   6515f:	mov    DWORD PTR [rsp+0x344],r13d
   65167:	mov    QWORD PTR [rsp+0x128],r12
   6516f:	mov    r13,QWORD PTR [rsp+0xf0]
   65177:	mov    r12,r15
   6517a:	mov    r15d,DWORD PTR [rsp+0x31c]
   65182:	jmp    65108 <sqlite3VdbeExec+0x15c68>
   65184:	mov    r12,QWORD PTR [rsp+0x108]
   6518c:	mov    rax,r15
   6518f:	mov    ecx,DWORD PTR [rbx+r12*1+0x10]
   65194:	shl    ecx,0x3
   65197:	movsxd rcx,ecx
   6519a:	xor    edx,edx
   6519c:	div    rcx
   6519f:	mov    rax,rdx
   651a2:	mov    rdx,QWORD PTR [rbx+r12*1+0x8]
   651a7:	mov    rsi,rax
   651aa:	shr    rsi,0x3
   651ae:	movsx  r8d,BYTE PTR [rdx+rsi*1]
   651b3:	mov    r9d,0x1
   651b9:	and    rax,0x7
   651bd:	mov    ecx,eax
   651bf:	mov    rax,r9
   651c2:	shl    eax,cl
   651c4:	or     r8d,eax
   651c7:	mov    BYTE PTR [rdx+rsi*1],r8b
   651cb:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   651d0:	mov    QWORD PTR [rsp+0xd0],r12
   651d8:	movsxd rax,DWORD PTR [rbp+0x4]
   651dc:	imul   r12,rax,0x38
   651e0:	movsxd r15,DWORD PTR [rbp+0xc]
   651e4:	mov    r13d,r15d
   651e7:	add    r13d,DWORD PTR [rbp+0x10]
   651eb:	mov    DWORD PTR [rsp+0x344],r13d
   651f3:	xor    r13d,r13d
   651f6:	jmp    652d5 <sqlite3VdbeExec+0x15e35>
   651fb:	mov    DWORD PTR [rsp+0x344],r12d
   65203:	mov    r12,QWORD PTR [rsp+0x108]
   6520b:	mov    rax,rcx
   6520e:	movzx  ecx,WORD PTR [rax+0x14]
   65212:	and    ecx,0x8
   65215:	test   ecx,ecx
   65217:	je     652b7 <sqlite3VdbeExec+0x15e17>
   6521d:	movzx  ecx,WORD PTR [rax+0x14]
   65221:	mov    edx,ecx
   65223:	and    edx,0x24
   65226:	test   edx,edx
   65228:	je     65232 <sqlite3VdbeExec+0x15d92>
   6522a:	mov    rax,QWORD PTR [rax]
   6522d:	jmp    652b2 <sqlite3VdbeExec+0x15e12>
   65232:	mov    edx,ecx
   65234:	and    edx,0x8
   65237:	test   edx,edx
   65239:	je     65288 <sqlite3VdbeExec+0x15de8>
   6523b:	movsd  xmm0,QWORD PTR [rax]
   6523f:	movabs r11,0xc3dfffffffffffff
   65249:	movq   xmm1,r11
   6524e:	ucomisd xmm1,xmm0
   65252:	jbe    65260 <sqlite3VdbeExec+0x15dc0>
   65254:	movabs rax,0x8000000000000000
   6525e:	jmp    65286 <sqlite3VdbeExec+0x15de6>
   65260:	movabs r11,0x43dfffffffffffff
   6526a:	movq   xmm1,r11
   6526f:	ucomisd xmm0,xmm1
   65273:	jbe    65281 <sqlite3VdbeExec+0x15de1>
   65275:	movabs rax,0x7fffffffffffffff
   6527f:	jmp    65286 <sqlite3VdbeExec+0x15de6>
   65281:	cvttsd2si rax,xmm0
   65286:	jmp    652b2 <sqlite3VdbeExec+0x15e12>
   65288:	and    ecx,0x12
   6528b:	test   ecx,ecx
   6528d:	je     652b0 <sqlite3VdbeExec+0x15e10>
   6528f:	cmp    QWORD PTR [rax+0x8],0x0
   65294:	je     652b0 <sqlite3VdbeExec+0x15e10>
   65296:	mov    QWORD PTR [rsp+0xb0],rdi
   6529e:	mov    rdi,rax
   652a1:	call   652a6 <sqlite3VdbeExec+0x15e06>
   652a6:	mov    rdi,QWORD PTR [rsp+0xb0]
   652ae:	jmp    652b2 <sqlite3VdbeExec+0x15e12>
   652b0:	xor    eax,eax
   652b2:	add    r13,rax
   652b5:	jmp    652d1 <sqlite3VdbeExec+0x15e31>
   652b7:	movzx  ecx,WORD PTR [rax+0x14]
   652bb:	and    ecx,0x12
   652be:	test   ecx,ecx
   652c0:	je     652d1 <sqlite3VdbeExec+0x15e31>
   652c2:	movzx  eax,WORD PTR [rax+0x14]
   652c6:	and    eax,0x12
   652c9:	add    eax,0xffd
   652ce:	add    r13,rax
   652d1:	add    r15d,0x1
   652d5:	mov    QWORD PTR [rsp+0x108],r12
   652dd:	mov    r12d,DWORD PTR [rsp+0x344]
   652e5:	cmp    r15d,r12d
   652e8:	jge    6531a <sqlite3VdbeExec+0x15e7a>
   652ea:	movsxd rax,r15d
   652ed:	imul   rax,rax,0x38
   652f1:	lea    rcx,[rbx+rax*1]
   652f5:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   652fa:	and    eax,0x24
   652fd:	test   eax,eax
   652ff:	je     651fb <sqlite3VdbeExec+0x15d5b>
   65305:	add    r13,QWORD PTR [rcx]
   65308:	mov    DWORD PTR [rsp+0x344],r12d
   65310:	mov    r12,QWORD PTR [rsp+0x108]
   65318:	jmp    652d1 <sqlite3VdbeExec+0x15e31>
   6531a:	mov    r12,QWORD PTR [rsp+0x108]
   65322:	mov    rax,r13
   65325:	mov    ecx,DWORD PTR [rbx+r12*1+0x10]
   6532a:	shl    ecx,0x3
   6532d:	movsxd rcx,ecx
   65330:	xor    edx,edx
   65332:	div    rcx
   65335:	mov    rax,rdx
   65338:	mov    rcx,QWORD PTR [rbx+r12*1+0x8]
   6533d:	mov    rdx,rax
   65340:	shr    rdx,0x3
   65344:	movsx  edx,BYTE PTR [rcx+rdx*1]
   65348:	mov    esi,0x1
   6534d:	and    rax,0x7
   65351:	mov    ecx,eax
   65353:	mov    rax,rsi
   65356:	shl    eax,cl
   65358:	and    edx,eax
   6535a:	test   edx,edx
   6535c:	jne    6537d <sqlite3VdbeExec+0x15edd>
   6535e:	mov    eax,DWORD PTR [rdi+0xf4]
   65364:	add    eax,0x1
   65367:	mov    DWORD PTR [rdi+0xf4],eax
   6536d:	mov    r12,r14
   65370:	mov    r15d,DWORD PTR [rsp+0x31c]
   65378:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   6537d:	mov    eax,DWORD PTR [rdi+0xf0]
   65383:	add    eax,0x1
   65386:	mov    DWORD PTR [rdi+0xf0],eax
   6538c:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   65391:	mov    QWORD PTR [rsp+0xd0],r12
   65399:	movzx  eax,BYTE PTR [r14+0x6e]
   6539e:	and    eax,0x41
   653a1:	test   eax,eax
   653a3:	je     65574 <sqlite3VdbeExec+0x160d4>
   653a9:	cmp    BYTE PTR [rdi+0xc5],0xfe
   653b0:	je     65574 <sqlite3VdbeExec+0x160d4>
   653b6:	cmp    QWORD PTR [rbp+0x10],0x0
   653bb:	je     653c3 <sqlite3VdbeExec+0x15f23>
   653bd:	mov    rax,QWORD PTR [rbp+0x10]
   653c1:	jmp    653ca <sqlite3VdbeExec+0x15f2a>
   653c3:	mov    rax,QWORD PTR [rdi+0xf8]
   653ca:	test   rax,rax
   653cd:	je     65574 <sqlite3VdbeExec+0x160d4>
   653d3:	movzx  ecx,BYTE PTR [r14+0x6e]
   653d8:	and    ecx,0x40
   653db:	test   ecx,ecx
   653dd:	je     654b1 <sqlite3VdbeExec+0x16011>
   653e3:	mov    QWORD PTR [rsp+0xb0],rdi
   653eb:	mov    rsi,rax
   653ee:	call   653f3 <sqlite3VdbeExec+0x15f53>
   653f3:	mov    rcx,QWORD PTR [r14+0xf0]
   653fa:	mov    rdx,QWORD PTR [r14+0xf8]
   65401:	mov    QWORD PTR [rsp+0xa8],rax
   65409:	mov    rdi,rdx
   6540c:	mov    rsi,rax
   6540f:	mov    r10,rcx
   65412:	call   r10
   65415:	mov    rax,QWORD PTR [rsp+0xa8]
   6541d:	mov    rdi,QWORD PTR [rsp+0xb0]
   65425:	test   rax,rax
   65428:	je     65574 <sqlite3VdbeExec+0x160d4>
   6542e:	cmp    DWORD PTR [rip+0x0],0x0        # 65435 <sqlite3VdbeExec+0x15f95>
   65435:	je     65494 <sqlite3VdbeExec+0x15ff4>
   65437:	mov    rcx,QWORD PTR [rip+0x0]        # 6543e <sqlite3VdbeExec+0x15f9e>
   6543e:	mov    rdi,rax
   65441:	mov    r10,rcx
   65444:	call   r10
   65447:	mov    ecx,eax
   65449:	mov    rdx,QWORD PTR [rip+0x0]        # 65450 <sqlite3VdbeExec+0x15fb0>
   65450:	movsxd rcx,ecx
   65453:	sub    rdx,rcx
   65456:	mov    QWORD PTR [rip+0x0],rdx        # 6545d <sqlite3VdbeExec+0x15fbd>
   6545d:	mov    rcx,QWORD PTR [rip+0x0]        # 65464 <sqlite3VdbeExec+0x15fc4>
   65464:	sub    rcx,0x1
   65468:	mov    QWORD PTR [rip+0x0],rcx        # 6546f <sqlite3VdbeExec+0x15fcf>
   6546f:	mov    rcx,QWORD PTR [rip+0x0]        # 65476 <sqlite3VdbeExec+0x15fd6>
   65476:	mov    rax,QWORD PTR [rsp+0xa8]
   6547e:	mov    rdi,rax
   65481:	mov    r10,rcx
   65484:	call   r10
   65487:	mov    rdi,QWORD PTR [rsp+0xb0]
   6548f:	jmp    65574 <sqlite3VdbeExec+0x160d4>
   65494:	mov    rcx,QWORD PTR [rip+0x0]        # 6549b <sqlite3VdbeExec+0x15ffb>
   6549b:	mov    rdi,rax
   6549e:	mov    r10,rcx
   654a1:	call   r10
   654a4:	mov    rdi,QWORD PTR [rsp+0xb0]
   654ac:	jmp    65574 <sqlite3VdbeExec+0x160d4>
   654b1:	cmp    DWORD PTR [r14+0xdc],0x1
   654b9:	jle    6553f <sqlite3VdbeExec+0x1609f>
   654bf:	lea    rcx,[rip+0x0]        # 654c6 <sqlite3VdbeExec+0x16026>
   654c6:	mov    QWORD PTR [rsp+0xb0],rdi
   654ce:	mov    rdi,r14
   654d1:	mov    rsi,rcx
   654d4:	mov    rdx,rax
   654d7:	xor    eax,eax
   654d9:	call   654de <sqlite3VdbeExec+0x1603e>
   654de:	mov    rcx,QWORD PTR [r14+0xf0]
   654e5:	mov    edx,0x1
   654ea:	mov    rsi,QWORD PTR [r14+0xf8]
   654f1:	mov    rdi,QWORD PTR [rsp+0xb0]
   654f9:	mov    QWORD PTR [rsp+0xa8],rax
   65501:	mov    r10,rcx
   65504:	mov    rcx,rax
   65507:	mov    r11,rdi
   6550a:	mov    rdi,rdx
   6550d:	mov    rdx,r11
   65510:	call   r10
   65513:	mov    ecx,eax
   65515:	mov    rax,QWORD PTR [rsp+0xa8]
   6551d:	mov    rdi,QWORD PTR [rsp+0xb0]
   65525:	test   rax,rax
   65528:	je     65574 <sqlite3VdbeExec+0x160d4>
   6552a:	mov    rdi,r14
   6552d:	mov    rsi,rax
   65530:	call   65535 <sqlite3VdbeExec+0x16095>
   65535:	mov    rdi,QWORD PTR [rsp+0xb0]
   6553d:	jmp    65574 <sqlite3VdbeExec+0x160d4>
   6553f:	mov    rcx,QWORD PTR [r14+0xf0]
   65546:	mov    edx,0x1
   6554b:	mov    rsi,QWORD PTR [r14+0xf8]
   65552:	mov    QWORD PTR [rsp+0xb0],rdi
   6555a:	mov    r10,rcx
   6555d:	mov    rcx,rax
   65560:	mov    r11,rdi
   65563:	mov    rdi,rdx
   65566:	mov    rdx,r11
   65569:	call   r10
   6556c:	mov    rdi,QWORD PTR [rsp+0xb0]
   65574:	mov    eax,DWORD PTR [rbp+0x4]
   65577:	cmp    eax,DWORD PTR [rip+0x0]        # 6557d <sqlite3VdbeExec+0x160dd>
   6557d:	jl     655ca <sqlite3VdbeExec+0x1612a>
   6557f:	cmp    BYTE PTR [rbp+0x0],0xba
   65583:	jne    65587 <sqlite3VdbeExec+0x160e7>
   65585:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   65587:	mov    eax,0x1
   6558c:	jmp    655bb <sqlite3VdbeExec+0x1611b>
   6558e:	mov    rcx,QWORD PTR [rdi+0x88]
   65595:	mov    rdx,rax
   65598:	imul   rdx,rdx,0x18
   6559c:	cmp    BYTE PTR [rcx+rdx*1],0xf
   655a0:	jne    655b8 <sqlite3VdbeExec+0x16118>
   655a2:	mov    rcx,QWORD PTR [rdi+0x88]
   655a9:	mov    rdx,rax
   655ac:	imul   rdx,rdx,0x18
   655b0:	mov    DWORD PTR [rcx+rdx*1+0x4],0x0
   655b8:	add    eax,0x1
   655bb:	cmp    eax,DWORD PTR [rdi+0x90]
   655c1:	jl     6558e <sqlite3VdbeExec+0x160ee>
   655c3:	mov    DWORD PTR [rbp+0x4],0x0
   655ca:	mov    eax,DWORD PTR [rbp+0x4]
   655cd:	add    eax,0x1
   655d0:	mov    DWORD PTR [rbp+0x4],eax
   655d3:	mov    eax,DWORD PTR [rdi+0xec]
   655d9:	add    eax,0x1
   655dc:	mov    DWORD PTR [rdi+0xec],eax
   655e2:	mov    r12,r14
   655e5:	mov    r15d,DWORD PTR [rsp+0x31c]
   655ed:	jmp    51d8f <sqlite3VdbeExec+0x28ef>
   655f2:	add    rbp,0x18
   655f6:	mov    r12,QWORD PTR [rsp+0xd0]
   655fe:	add    r12,0x1
   65602:	movzx  eax,BYTE PTR [rbp+0x0]
   65606:	cmp    eax,0xba
   6560b:	jbe    65617 <sqlite3VdbeExec+0x16177>
   6560d:	mov    QWORD PTR [rsp+0xd0],r12
   65615:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   65617:	lea    r13,[rip+0x0]        # 6561e <sqlite3VdbeExec+0x1617e>
   6561e:	movsxd rax,DWORD PTR [r13+rax*4+0x0]
   65623:	add    rax,r13
   65626:	jmp    rax
   65628:	mov    QWORD PTR [rsp+0xd0],r12
   65630:	jmp    655f2 <sqlite3VdbeExec+0x16152>
   65632:	mov    r15d,DWORD PTR [rsp+0x31c]
   6563a:	mov    r13,QWORD PTR [rsp+0xf0]
   65642:	mov    QWORD PTR [rsp+0xd0],r12
   6564a:	mov    r12d,DWORD PTR [rsp+0x334]
   65652:	jmp    4f7bd <sqlite3VdbeExec+0x31d>
   65657:	mov    r15d,DWORD PTR [rsp+0x31c]
   6565f:	mov    r13,QWORD PTR [rsp+0xf0]
   65667:	mov    QWORD PTR [rsp+0xd0],r12
   6566f:	mov    r12d,DWORD PTR [rsp+0x334]
   65677:	jmp    58325 <sqlite3VdbeExec+0x8e85>
   6567c:	mov    r15d,DWORD PTR [rsp+0x31c]
   65684:	mov    r13,QWORD PTR [rsp+0xf0]
   6568c:	mov    QWORD PTR [rsp+0xd0],r12
   65694:	jmp    58784 <sqlite3VdbeExec+0x92e4>
   65699:	mov    r15d,DWORD PTR [rsp+0x31c]
   656a1:	mov    QWORD PTR [rsp+0xd0],r12
   656a9:	jmp    5acf9 <sqlite3VdbeExec+0xb859>
   656ae:	mov    r15d,DWORD PTR [rsp+0x31c]
   656b6:	mov    r13,QWORD PTR [rsp+0xf0]
   656be:	mov    QWORD PTR [rsp+0xd0],r12
   656c6:	mov    r12d,DWORD PTR [rsp+0x334]
   656ce:	jmp    4fa5b <sqlite3VdbeExec+0x5bb>
   656d3:	mov    r15d,DWORD PTR [rsp+0x31c]
   656db:	mov    QWORD PTR [rsp+0xd0],r12
   656e3:	jmp    5002b <sqlite3VdbeExec+0xb8b>
   656e8:	mov    r15d,DWORD PTR [rsp+0x31c]
   656f0:	mov    r13,QWORD PTR [rsp+0xf0]
   656f8:	mov    QWORD PTR [rsp+0xd0],r12
   65700:	jmp    5696b <sqlite3VdbeExec+0x74cb>
   65705:	mov    r15d,DWORD PTR [rsp+0x31c]
   6570d:	mov    r13,QWORD PTR [rsp+0xf0]
   65715:	mov    QWORD PTR [rsp+0xd0],r12
   6571d:	jmp    60dec <sqlite3VdbeExec+0x1194c>
   65722:	cmp    ebp,0x210a
   65728:	jne    65758 <sqlite3VdbeExec+0x162b8>
   6572a:	mov    eax,0x19d26
   6572f:	mov    ecx,0xb
   65734:	lea    rdx,[rip+0x0]        # 6573b <sqlite3VdbeExec+0x1629b>
   6573b:	mov    QWORD PTR [rsp+0xb0],rdi
   65743:	mov    rdi,rcx
   65746:	mov    rsi,rax
   65749:	call   6574e <sqlite3VdbeExec+0x162ae>
   6574e:	mov    ebp,eax
   65750:	mov    rdi,QWORD PTR [rsp+0xb0]
   65758:	cmp    QWORD PTR [rdi+0xa8],0x0
   65760:	jne    657e9 <sqlite3VdbeExec+0x16349>
   65766:	cmp    ebp,0xc0a
   6576c:	je     657e9 <sqlite3VdbeExec+0x16349>
   6576e:	lea    rax,[rip+0x0]        # 65775 <sqlite3VdbeExec+0x162d5>
   65775:	lea    rcx,[rip+0x0]        # 6577c <sqlite3VdbeExec+0x162dc>
   6577c:	cmp    ebp,0x204
   65782:	je     65797 <sqlite3VdbeExec+0x162f7>
   65784:	cmp    ebp,0x64
   65787:	je     657a0 <sqlite3VdbeExec+0x16300>
   65789:	cmp    ebp,0x65
   6578c:	jne    657a9 <sqlite3VdbeExec+0x16309>
   6578e:	lea    rcx,[rip+0x0]        # 65795 <sqlite3VdbeExec+0x162f5>
   65795:	jmp    657cc <sqlite3VdbeExec+0x1632c>
   65797:	lea    rcx,[rip+0x0]        # 6579e <sqlite3VdbeExec+0x162fe>
   6579e:	jmp    657cc <sqlite3VdbeExec+0x1632c>
   657a0:	lea    rcx,[rip+0x0]        # 657a7 <sqlite3VdbeExec+0x16307>
   657a7:	jmp    657cc <sqlite3VdbeExec+0x1632c>
   657a9:	mov    edx,ebp
   657ab:	and    edx,0xff
   657b1:	test   edx,edx
   657b3:	jl     657cc <sqlite3VdbeExec+0x1632c>
   657b5:	cmp    edx,0x1d
   657b8:	jge    657cc <sqlite3VdbeExec+0x1632c>
   657ba:	lea    rsi,[rip+0x0]        # 657c1 <sqlite3VdbeExec+0x16321>
   657c1:	mov    rdx,QWORD PTR [rsi+rdx*8]
   657c5:	test   rdx,rdx
   657c8:	cmovne rcx,rdx
   657cc:	mov    QWORD PTR [rsp+0xb0],rdi
   657d4:	mov    rsi,rax
   657d7:	mov    rdx,rcx
   657da:	xor    eax,eax
   657dc:	call   657e1 <sqlite3VdbeExec+0x16341>
   657e1:	mov    rdi,QWORD PTR [rsp+0xb0]
   657e9:	mov    DWORD PTR [rdi+0x34],ebp
   657ec:	cmp    ebp,0xc0a
   657f2:	je     65847 <sqlite3VdbeExec+0x163a7>
   657f4:	mov    eax,ebp
   657f6:	and    eax,0xff
   657fb:	cmp    eax,0xe
   657fe:	je     65805 <sqlite3VdbeExec+0x16365>
   65800:	cmp    eax,0xa
   65803:	jne    65847 <sqlite3VdbeExec+0x163a7>
   65805:	mov    rax,QWORD PTR [r14]
   65808:	cmp    QWORD PTR [rax+0x80],0x0
   65810:	je     65841 <sqlite3VdbeExec+0x163a1>
   65812:	mov    rcx,QWORD PTR [rax+0x80]
   65819:	xor    edx,edx
   6581b:	xor    esi,esi
   6581d:	mov    QWORD PTR [rsp+0xb0],rdi
   65825:	mov    rdi,rax
   65828:	mov    r10,rcx
   6582b:	mov    r11,rsi
   6582e:	mov    rsi,rdx
   65831:	mov    rdx,r11
   65834:	call   r10
   65837:	mov    rdi,QWORD PTR [rsp+0xb0]
   6583f:	jmp    65843 <sqlite3VdbeExec+0x163a3>
   65841:	xor    eax,eax
   65843:	mov    DWORD PTR [r14+0x5c],eax
   65847:	mov    r12,QWORD PTR [rsp+0xf0]
   6584f:	mov    r15,QWORD PTR [rsp+0xe8]
   65857:	mov    QWORD PTR [rsp+0xb0],rdi
   6585f:	mov    rsi,rbp
   65862:	mov    rdx,r15
   65865:	mov    rcx,r12
   65868:	call   6586d <sqlite3VdbeExec+0x163cd>
   6586d:	mov    rdi,QWORD PTR [rsp+0xb0]
   65875:	cmp    BYTE PTR [rdi+0xc7],0x2
   6587c:	jne    6588b <sqlite3VdbeExec+0x163eb>
   6587e:	call   65883 <sqlite3VdbeExec+0x163e3>
   65883:	mov    rdi,QWORD PTR [rsp+0xb0]
   6588b:	cmp    ebp,0xc0a
   65891:	jne    658ab <sqlite3VdbeExec+0x1640b>
   65893:	mov    QWORD PTR [rsp+0xb0],rdi
   6589b:	mov    rdi,r14
   6589e:	call   658a3 <sqlite3VdbeExec+0x16403>
   658a3:	mov    rdi,QWORD PTR [rsp+0xb0]
   658ab:	cmp    ebp,0xb
   658ae:	jne    658c9 <sqlite3VdbeExec+0x16429>
   658b0:	cmp    BYTE PTR [r14+0x65],0x0
   658b5:	jne    658c9 <sqlite3VdbeExec+0x16429>
   658b7:	movabs rax,0x200000000
   658c1:	or     rax,QWORD PTR [r14+0x30]
   658c5:	mov    QWORD PTR [r14+0x30],rax
   658c9:	mov    ebp,DWORD PTR [rsp+0x320]
   658d0:	movzx  eax,bpl
   658d4:	test   eax,eax
   658d6:	jg     658f7 <sqlite3VdbeExec+0x16457>
   658d8:	mov    QWORD PTR [rsp+0xf0],r12
   658e0:	mov    r11,rbp
   658e3:	mov    rbp,r15
   658e6:	mov    r15,r13
   658e9:	mov    r13,r11
   658ec:	mov    r12d,0x1
   658f2:	jmp    659c6 <sqlite3VdbeExec+0x16526>
   658f7:	movzx  eax,bpl
   658fb:	sub    eax,0x1
   658fe:	test   eax,eax
   65900:	jl     65938 <sqlite3VdbeExec+0x16498>
   65902:	mov    rcx,QWORD PTR [r14+0x20]
   65906:	shl    rax,0x5
   6590a:	mov    rax,QWORD PTR [rcx+rax*1+0x18]
   6590f:	movzx  ecx,WORD PTR [rax+0x72]
   65913:	or     ecx,0x8
   65916:	mov    WORD PTR [rax+0x72],cx
   6591a:	mov    rax,QWORD PTR [r14+0x20]
   6591e:	mov    rax,QWORD PTR [rax+0x38]
   65922:	movzx  ecx,WORD PTR [rax+0x72]
   65926:	or     ecx,0x8
   65929:	mov    WORD PTR [rax+0x72],cx
   6592d:	mov    eax,DWORD PTR [r14+0x2c]
   65931:	and    eax,0xffffffef
   65934:	mov    DWORD PTR [r14+0x2c],eax
   65938:	cmp    DWORD PTR [r14+0x48],0x0
   6593d:	je     65949 <sqlite3VdbeExec+0x164a9>
   6593f:	mov    QWORD PTR [rsp+0xf8],rbx
   65947:	jmp    659a2 <sqlite3VdbeExec+0x16502>
   65949:	mov    QWORD PTR [rsp+0xf8],rbx
   65951:	xor    ebx,ebx
   65953:	jmp    6599c <sqlite3VdbeExec+0x164fc>
   65955:	mov    rax,QWORD PTR [r14+0x20]
   65959:	mov    rcx,rbx
   6595c:	shl    rcx,0x5
   65960:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   65965:	movzx  eax,WORD PTR [rax+0x72]
   65969:	and    eax,0x8
   6596c:	cmp    eax,0x8
   6596f:	jne    65999 <sqlite3VdbeExec+0x164f9>
   65971:	mov    rax,QWORD PTR [r14+0x20]
   65975:	mov    rcx,rbx
   65978:	shl    rcx,0x5
   6597c:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   65981:	mov    QWORD PTR [rsp+0xb0],rdi
   65989:	mov    rdi,rax
   6598c:	call   65991 <sqlite3VdbeExec+0x164f1>
   65991:	mov    rdi,QWORD PTR [rsp+0xb0]
   65999:	add    ebx,0x1
   6599c:	cmp    ebx,DWORD PTR [r14+0x28]
   659a0:	jl     65955 <sqlite3VdbeExec+0x164b5>
   659a2:	mov    QWORD PTR [rsp+0xf0],r12
   659aa:	mov    rbx,QWORD PTR [rsp+0xf8]
   659b2:	mov    r11,rbp
   659b5:	mov    rbp,r15
   659b8:	mov    r15,r13
   659bb:	mov    r13,r11
   659be:	mov    r12d,0x1
   659c4:	jmp    659c6 <sqlite3VdbeExec+0x16526>
   659c6:	cmp    r15,rbx
   659c9:	jb     65a32 <sqlite3VdbeExec+0x16592>
   659cb:	cmp    QWORD PTR [r14+0x208],0x0
   659d3:	je     65a32 <sqlite3VdbeExec+0x16592>
   659d5:	mov    eax,DWORD PTR [r14+0x218]
   659dc:	add    rbx,rax
   659df:	mov    rax,QWORD PTR [r14+0x208]
   659e6:	mov    rcx,QWORD PTR [r14+0x210]
   659ed:	mov    QWORD PTR [rsp+0xb0],rdi
   659f5:	mov    rdi,rcx
   659f8:	mov    r10,rax
   659fb:	call   r10
   659fe:	mov    rdi,QWORD PTR [rsp+0xb0]
   65a06:	test   eax,eax
   65a08:	je     659c6 <sqlite3VdbeExec+0x16526>
   65a0a:	mov    rbx,0xffffffffffffffff
   65a11:	mov    r12d,0x9
   65a17:	mov    QWORD PTR [rsp+0xe8],rbp
   65a1f:	mov    rbp,r12
   65a22:	mov    DWORD PTR [rsp+0x320],r13d
   65a2a:	mov    r13,r15
   65a2d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   65a32:	mov    eax,r15d
   65a35:	add    eax,DWORD PTR [rdi+0xe4]
   65a3b:	mov    DWORD PTR [rdi+0xe4],eax
   65a41:	mov    eax,DWORD PTR [rdi+0xd0]
   65a47:	mov    eax,r12d
   65a4a:	add    rsp,0x378
   65a51:	pop    r15
   65a53:	pop    r14
   65a55:	pop    r13
   65a57:	pop    r12
   65a59:	pop    rbp
   65a5a:	pop    rbx
   65a5b:	ret
