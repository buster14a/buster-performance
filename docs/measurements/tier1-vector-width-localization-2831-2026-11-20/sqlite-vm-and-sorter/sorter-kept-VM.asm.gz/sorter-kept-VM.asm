
/home/david/Documents/Codex/2026-11-19/profile-and-improve-buster-compilation-speed/work/width-evidence/vm/sorter-kept.o:     file format elf64-x86-64


Disassembly of section .text:

000000000004f4a0 <sqlite3VdbeExec>:
   4f4a0:	push   rbx
   4f4a1:	push   rbp
   4f4a2:	push   r12
   4f4a4:	push   r13
   4f4a6:	push   r14
   4f4a8:	push   r15
   4f4aa:	sub    rsp,0x3d8
   4f4b1:	lea    rbp,[rsp+0x278]
   4f4b9:	mov    r13,QWORD PTR [rdi+0x88]
   4f4c0:	mov    r14,QWORD PTR [rdi]
   4f4c3:	movzx  r15d,BYTE PTR [r14+0x64]
   4f4c8:	mov    r12,QWORD PTR [rdi+0x68]
   4f4cc:	xor    ebx,ebx
   4f4ce:	cmp    DWORD PTR [rdi+0xd0],0x0
   4f4d5:	je     4f531 <sqlite3VdbeExec+0x91>
   4f4d7:	cmp    DWORD PTR [rdi+0xd0],0x0
   4f4de:	je     4f531 <sqlite3VdbeExec+0x91>
   4f4e0:	mov    rax,QWORD PTR [rdi]
   4f4e3:	mov    rdx,QWORD PTR [rax+0x20]
   4f4e7:	mov    eax,DWORD PTR [rax+0x28]
   4f4ea:	xor    ecx,ecx
   4f4ec:	jmp    4f52d <sqlite3VdbeExec+0x8d>
   4f4ee:	cmp    ecx,0x1
   4f4f1:	je     4f52a <sqlite3VdbeExec+0x8a>
   4f4f3:	mov    esi,0x1
   4f4f8:	shl    esi,cl
   4f4fa:	and    esi,DWORD PTR [rdi+0xd0]
   4f500:	test   esi,esi
   4f502:	je     4f52a <sqlite3VdbeExec+0x8a>
   4f504:	mov    rsi,rcx
   4f507:	shl    rsi,0x5
   4f50b:	cmp    QWORD PTR [rdx+rsi*1+0x8],0x0
   4f511:	je     4f52a <sqlite3VdbeExec+0x8a>
   4f513:	mov    rsi,rcx
   4f516:	shl    rsi,0x5
   4f51a:	mov    rsi,QWORD PTR [rdx+rsi*1+0x8]
   4f51f:	mov    r8,QWORD PTR [rsi+0x8]
   4f523:	mov    rsi,QWORD PTR [rsi]
   4f526:	mov    QWORD PTR [r8+0x8],rsi
   4f52a:	add    ecx,0x1
   4f52d:	cmp    ecx,eax
   4f52f:	jl     4f4ee <sqlite3VdbeExec+0x4e>
   4f531:	cmp    QWORD PTR [r14+0x208],0x0
   4f539:	je     4f55c <sqlite3VdbeExec+0xbc>
   4f53b:	mov    eax,DWORD PTR [rdi+0xe4]
   4f541:	mov    ecx,DWORD PTR [r14+0x218]
   4f548:	mov    esi,DWORD PTR [r14+0x218]
   4f54f:	xor    edx,edx
   4f551:	div    esi
   4f553:	mov    eax,edx
   4f555:	sub    ecx,eax
   4f557:	mov    rbp,rcx
   4f55a:	jmp    4f563 <sqlite3VdbeExec+0xc3>
   4f55c:	mov    rbp,0xffffffffffffffff
   4f563:	cmp    DWORD PTR [rdi+0x34],0x7
   4f567:	jne    4f5dc <sqlite3VdbeExec+0x13c>
   4f569:	mov    rbx,r13
   4f56c:	xor    r11d,r11d
   4f56f:	mov    DWORD PTR [rsp+0x380],r11d
   4f577:	xor    r11d,r11d
   4f57a:	mov    QWORD PTR [rsp+0x130],r11
   4f582:	mov    QWORD PTR [rsp+0x110],rdi
   4f58a:	mov    rdi,r14
   4f58d:	call   4f592 <sqlite3VdbeExec+0xf2>
   4f592:	lea    rax,[rip+0x0]        # 4f599 <sqlite3VdbeExec+0xf9>
   4f599:	mov    rdi,QWORD PTR [rsp+0x110]
   4f5a1:	mov    rsi,rax
   4f5a4:	xor    eax,eax
   4f5a6:	call   4f5ab <sqlite3VdbeExec+0x10b>
   4f5ab:	mov    r12d,0x7
   4f5b1:	mov    rdi,QWORD PTR [rsp+0x110]
   4f5b9:	mov    QWORD PTR [rsp+0x150],r13
   4f5c1:	mov    QWORD PTR [rsp+0x148],rbx
   4f5c9:	mov    r13,QWORD PTR [rsp+0x130]
   4f5d1:	mov    rbx,rbp
   4f5d4:	mov    rbp,r12
   4f5d7:	jmp    4f712 <sqlite3VdbeExec+0x272>
   4f5dc:	mov    DWORD PTR [rdi+0x34],0x0
   4f5e3:	mov    QWORD PTR [rdi+0x48],0x0
   4f5eb:	mov    DWORD PTR [r14+0x290],0x0
   4f5f6:	mov    eax,DWORD PTR [r14+0x190]
   4f5fd:	test   eax,eax
   4f5ff:	je     4f643 <sqlite3VdbeExec+0x1a3>
   4f601:	mov    rbx,r13
   4f604:	xor    r11d,r11d
   4f607:	mov    DWORD PTR [rsp+0x380],r11d
   4f60f:	xor    r11d,r11d
   4f612:	mov    QWORD PTR [rsp+0x130],r11
   4f61a:	mov    r12d,0x9
   4f620:	mov    QWORD PTR [rsp+0x150],r13
   4f628:	mov    QWORD PTR [rsp+0x148],rbx
   4f630:	mov    r13,QWORD PTR [rsp+0x130]
   4f638:	mov    rbx,rbp
   4f63b:	mov    rbp,r12
   4f63e:	jmp    4f712 <sqlite3VdbeExec+0x272>
   4f643:	movsxd rax,DWORD PTR [rdi+0x30]
   4f647:	imul   rax,rax,0x18
   4f64b:	lea    rbx,[r13+rax*1+0x0]
   4f650:	mov    DWORD PTR [rsp+0x37c],r15d
   4f658:	mov    QWORD PTR [rsp+0x150],r13
   4f660:	mov    QWORD PTR [rsp+0x158],rbp
   4f668:	mov    rbp,rbx
   4f66b:	mov    rbx,r12
   4f66e:	xor    r11d,r11d
   4f671:	mov    DWORD PTR [rsp+0x38c],r11d
   4f679:	xor    r11d,r11d
   4f67c:	mov    DWORD PTR [rsp+0x380],r11d
   4f684:	xor    r11d,r11d
   4f687:	mov    DWORD PTR [rsp+0x390],r11d
   4f68f:	xor    r12d,r12d
   4f692:	xor    r11d,r11d
   4f695:	mov    DWORD PTR [rsp+0x394],r11d
   4f69d:	jmp    659cb <sqlite3VdbeExec+0x1652b>
   4f6a2:	mov    QWORD PTR [rsp+0x130],r13
   4f6aa:	mov    r13,QWORD PTR [rsp+0x150]
   4f6b2:	mov    QWORD PTR [rsp+0x150],r13
   4f6ba:	mov    r13,QWORD PTR [rsp+0x130]
   4f6c2:	cmp    r13,rbp
   4f6c5:	jb     4f727 <sqlite3VdbeExec+0x287>
   4f6c7:	cmp    QWORD PTR [r14+0x208],0x0
   4f6cf:	je     4f727 <sqlite3VdbeExec+0x287>
   4f6d1:	mov    eax,DWORD PTR [r14+0x218]
   4f6d8:	add    rbp,rax
   4f6db:	mov    rax,QWORD PTR [r14+0x208]
   4f6e2:	mov    rcx,QWORD PTR [r14+0x210]
   4f6e9:	mov    QWORD PTR [rsp+0x110],rdi
   4f6f1:	mov    rdi,rcx
   4f6f4:	mov    r10,rax
   4f6f7:	call   r10
   4f6fa:	mov    rdi,QWORD PTR [rsp+0x110]
   4f702:	test   eax,eax
   4f704:	je     4f6a2 <sqlite3VdbeExec+0x202>
   4f706:	mov    rbx,0xffffffffffffffff
   4f70d:	mov    ebp,0x9
   4f712:	cmp    BYTE PTR [r14+0x67],0x0
   4f717:	je     65aef <sqlite3VdbeExec+0x1664f>
   4f71d:	mov    ebp,0x7
   4f722:	jmp    65b25 <sqlite3VdbeExec+0x16685>
   4f727:	mov    DWORD PTR [rsp+0x37c],r15d
   4f72f:	mov    QWORD PTR [rsp+0x130],r13
   4f737:	mov    DWORD PTR [rsp+0x390],ebx
   4f73e:	mov    QWORD PTR [rsp+0x158],rbp
   4f746:	mov    rbp,QWORD PTR [rsp+0x148]
   4f74e:	mov    rbx,QWORD PTR [rsp+0x160]
   4f756:	mov    DWORD PTR [rsp+0x394],r12d
   4f75e:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   4f763:	mov    r15d,DWORD PTR [rsp+0x37c]
   4f76b:	mov    r13,QWORD PTR [rsp+0x150]
   4f773:	mov    QWORD PTR [rsp+0x130],r12
   4f77b:	mov    r12d,DWORD PTR [rsp+0x394]
   4f783:	movsxd rax,DWORD PTR [rbp+0x4]
   4f787:	imul   rcx,rax,0x38
   4f78b:	mov    WORD PTR [rbx+rcx*1+0x14],0x4
   4f792:	mov    rax,rbp
   4f795:	sub    rax,r13
   4f798:	movabs rdx,0x2aaaaaaaaaaaaaab
   4f7a2:	imul   rdx
   4f7a5:	sar    rdx,0x2
   4f7a9:	mov    rax,rdx
   4f7ac:	shr    rax,0x3f
   4f7b0:	add    rdx,rax
   4f7b3:	mov    rax,rdx
   4f7b6:	movsxd rax,eax
   4f7b9:	mov    QWORD PTR [rbx+rcx*1],rax
   4f7bd:	mov    eax,DWORD PTR [rbp+0x8]
   4f7c0:	sub    eax,0x1
   4f7c3:	movsxd rax,eax
   4f7c6:	imul   rax,rax,0x18
   4f7ca:	lea    rbp,[r13+rax*1+0x0]
   4f7cf:	mov    QWORD PTR [rsp+0x148],rbp
   4f7d7:	mov    QWORD PTR [rsp+0x160],rbx
   4f7df:	mov    ebx,DWORD PTR [rsp+0x390]
   4f7e6:	mov    eax,DWORD PTR [r14+0x190]
   4f7ed:	test   eax,eax
   4f7ef:	jne    4f7fe <sqlite3VdbeExec+0x35e>
   4f7f1:	mov    rbp,QWORD PTR [rsp+0x158]
   4f7f9:	jmp    4f6b2 <sqlite3VdbeExec+0x212>
   4f7fe:	mov    rbx,QWORD PTR [rsp+0x148]
   4f806:	mov    rbp,QWORD PTR [rsp+0x158]
   4f80e:	jmp    4f61a <sqlite3VdbeExec+0x17a>
   4f813:	mov    r15d,DWORD PTR [rsp+0x37c]
   4f81b:	mov    r13,QWORD PTR [rsp+0x150]
   4f823:	mov    QWORD PTR [rsp+0x130],r12
   4f82b:	mov    r12d,DWORD PTR [rsp+0x394]
   4f833:	movsxd rax,DWORD PTR [rbp+0x4]
   4f837:	imul   rax,rax,0x38
   4f83b:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   4f840:	and    ecx,0x4
   4f843:	test   ecx,ecx
   4f845:	je     4f859 <sqlite3VdbeExec+0x3b9>
   4f847:	mov    ecx,DWORD PTR [rbp+0xc]
   4f84a:	mov    rax,QWORD PTR [rbx+rax*1]
   4f84e:	imul   rax,rax,0x18
   4f852:	lea    rbp,[r13+rax*1+0x0]
   4f857:	jmp    4f85c <sqlite3VdbeExec+0x3bc>
   4f859:	mov    eax,DWORD PTR [rbp+0xc]
   4f85c:	mov    DWORD PTR [rsp+0x37c],r15d
   4f864:	mov    QWORD PTR [rsp+0x150],r13
   4f86c:	mov    DWORD PTR [rsp+0x394],r12d
   4f874:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   4f879:	mov    r15d,DWORD PTR [rsp+0x37c]
   4f881:	mov    r13,QWORD PTR [rsp+0x150]
   4f889:	mov    QWORD PTR [rsp+0x130],r12
   4f891:	mov    r12d,DWORD PTR [rsp+0x394]
   4f899:	movsxd rax,DWORD PTR [rbp+0x4]
   4f89d:	imul   rax,rax,0x38
   4f8a1:	mov    ecx,DWORD PTR [rbp+0xc]
   4f8a4:	sub    ecx,0x1
   4f8a7:	movsxd rcx,ecx
   4f8aa:	mov    QWORD PTR [rbx+rax*1],rcx
   4f8ae:	mov    WORD PTR [rbx+rax*1+0x14],0x4
   4f8b5:	cmp    DWORD PTR [rbp+0x8],0x0
   4f8b9:	je     4f8d3 <sqlite3VdbeExec+0x433>
   4f8bb:	mov    QWORD PTR [rsp+0x150],r13
   4f8c3:	mov    DWORD PTR [rsp+0x394],r12d
   4f8cb:	mov    r12,r14
   4f8ce:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   4f8d3:	mov    DWORD PTR [rsp+0x37c],r15d
   4f8db:	mov    QWORD PTR [rsp+0x150],r13
   4f8e3:	mov    DWORD PTR [rsp+0x394],r12d
   4f8eb:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   4f8f0:	mov    r15d,DWORD PTR [rsp+0x37c]
   4f8f8:	mov    r13,QWORD PTR [rsp+0x150]
   4f900:	mov    QWORD PTR [rsp+0x130],r12
   4f908:	mov    r12d,DWORD PTR [rsp+0x394]
   4f910:	movsxd rax,DWORD PTR [rbp+0x4]
   4f914:	imul   rcx,rax,0x38
   4f918:	mov    rax,QWORD PTR [rbx+rcx*1]
   4f91c:	imul   rsi,rax,0x18
   4f920:	mov    rax,rbp
   4f923:	sub    rax,QWORD PTR [rdi+0x88]
   4f92a:	movabs rdx,0x2aaaaaaaaaaaaaab
   4f934:	imul   rdx
   4f937:	sar    rdx,0x2
   4f93b:	mov    rax,rdx
   4f93e:	shr    rax,0x3f
   4f942:	add    rdx,rax
   4f945:	mov    rax,rdx
   4f948:	sub    eax,0x1
   4f94b:	movsxd rax,eax
   4f94e:	mov    QWORD PTR [rbx+rcx*1],rax
   4f952:	mov    eax,DWORD PTR [r13+rsi*1+0x8]
   4f957:	sub    eax,0x1
   4f95a:	movsxd rax,eax
   4f95d:	imul   rax,rax,0x18
   4f961:	lea    rbp,[r13+rax*1+0x0]
   4f966:	mov    DWORD PTR [rsp+0x37c],r15d
   4f96e:	mov    QWORD PTR [rsp+0x150],r13
   4f976:	mov    DWORD PTR [rsp+0x394],r12d
   4f97e:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   4f983:	mov    r15d,DWORD PTR [rsp+0x37c]
   4f98b:	mov    r13,QWORD PTR [rsp+0x150]
   4f993:	mov    QWORD PTR [rsp+0x130],r12
   4f99b:	mov    r12d,DWORD PTR [rsp+0x394]
   4f9a3:	movsxd rax,DWORD PTR [rbp+0x4]
   4f9a7:	imul   rcx,rax,0x38
   4f9ab:	mov    WORD PTR [rbx+rcx*1+0x14],0x4
   4f9b2:	mov    rsi,QWORD PTR [rbx+rcx*1]
   4f9b6:	mov    rax,rbp
   4f9b9:	sub    rax,r13
   4f9bc:	movabs rdx,0x2aaaaaaaaaaaaaab
   4f9c6:	imul   rdx
   4f9c9:	sar    rdx,0x2
   4f9cd:	mov    rax,rdx
   4f9d0:	shr    rax,0x3f
   4f9d4:	add    rdx,rax
   4f9d7:	mov    rax,rdx
   4f9da:	movsxd rax,eax
   4f9dd:	mov    QWORD PTR [rbx+rcx*1],rax
   4f9e1:	movsxd rax,esi
   4f9e4:	imul   rax,rax,0x18
   4f9e8:	lea    rbp,[r13+rax*1+0x0]
   4f9ed:	mov    DWORD PTR [rsp+0x37c],r15d
   4f9f5:	mov    QWORD PTR [rsp+0x150],r13
   4f9fd:	mov    DWORD PTR [rsp+0x394],r12d
   4fa05:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   4fa0a:	mov    r15d,DWORD PTR [rsp+0x37c]
   4fa12:	mov    r13,QWORD PTR [rsp+0x150]
   4fa1a:	mov    QWORD PTR [rsp+0x130],r12
   4fa22:	mov    r12d,DWORD PTR [rsp+0x394]
   4fa2a:	movsxd rax,DWORD PTR [rbp+0xc]
   4fa2e:	imul   rax,rax,0x38
   4fa32:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   4fa37:	and    eax,0x1
   4fa3a:	test   eax,eax
   4fa3c:	jne    4fa5b <sqlite3VdbeExec+0x5bb>
   4fa3e:	mov    DWORD PTR [rsp+0x37c],r15d
   4fa46:	mov    QWORD PTR [rsp+0x150],r13
   4fa4e:	mov    DWORD PTR [rsp+0x394],r12d
   4fa56:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   4fa5b:	cmp    QWORD PTR [rdi+0x108],0x0
   4fa63:	je     4fb14 <sqlite3VdbeExec+0x674>
   4fa69:	cmp    DWORD PTR [rbp+0x4],0x0
   4fa6d:	jne    4fb14 <sqlite3VdbeExec+0x674>
   4fa73:	mov    rax,QWORD PTR [rdi+0x108]
   4fa7a:	mov    rcx,QWORD PTR [rax+0x8]
   4fa7e:	mov    QWORD PTR [rdi+0x108],rcx
   4fa85:	mov    ecx,DWORD PTR [rdi+0x118]
   4fa8b:	sub    ecx,0x1
   4fa8e:	mov    DWORD PTR [rdi+0x118],ecx
   4fa94:	mov    rcx,QWORD PTR [rdi+0x38]
   4fa98:	mov    QWORD PTR [r14+0x78],rcx
   4fa9c:	mov    rdx,QWORD PTR [r14+0x80]
   4faa3:	add    rcx,rdx
   4faa6:	mov    QWORD PTR [r14+0x80],rcx
   4faad:	mov    QWORD PTR [rsp+0x110],rdi
   4fab5:	mov    rdi,rax
   4fab8:	call   4fabd <sqlite3VdbeExec+0x61d>
   4fabd:	mov    rdi,QWORD PTR [rsp+0x110]
   4fac5:	cmp    DWORD PTR [rbp+0x8],0x4
   4fac9:	jne    4fae0 <sqlite3VdbeExec+0x640>
   4facb:	mov    rcx,QWORD PTR [rdi+0x88]
   4fad2:	movsxd rax,eax
   4fad5:	imul   rax,rax,0x18
   4fad9:	mov    eax,DWORD PTR [rcx+rax*1+0x8]
   4fadd:	sub    eax,0x1
   4fae0:	mov    r13,QWORD PTR [rdi+0x88]
   4fae7:	mov    rbx,QWORD PTR [rdi+0x68]
   4faeb:	movsxd rax,eax
   4faee:	imul   rax,rax,0x18
   4faf2:	lea    rbp,[r13+rax*1+0x0]
   4faf7:	mov    DWORD PTR [rsp+0x37c],r15d
   4faff:	mov    QWORD PTR [rsp+0x150],r13
   4fb07:	mov    DWORD PTR [rsp+0x394],r12d
   4fb0f:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   4fb14:	mov    eax,DWORD PTR [rbp+0x4]
   4fb17:	mov    DWORD PTR [rdi+0x34],eax
   4fb1a:	mov    eax,DWORD PTR [rbp+0x8]
   4fb1d:	mov    BYTE PTR [rdi+0xc4],al
   4fb23:	cmp    DWORD PTR [rdi+0x34],0x0
   4fb27:	je     4fc92 <sqlite3VdbeExec+0x7f2>
   4fb2d:	cmp    DWORD PTR [rbp+0xc],0x0
   4fb31:	jle    4fbcb <sqlite3VdbeExec+0x72b>
   4fb37:	cmp    BYTE PTR [rbp+0x1],0x0
   4fb3b:	jne    4fbcb <sqlite3VdbeExec+0x72b>
   4fb41:	movsxd rax,DWORD PTR [rbp+0xc]
   4fb45:	imul   rax,rax,0x38
   4fb49:	add    rax,rbx
   4fb4c:	test   rax,rax
   4fb4f:	jne    4fb55 <sqlite3VdbeExec+0x6b5>
   4fb51:	xor    eax,eax
   4fb53:	jmp    4fba2 <sqlite3VdbeExec+0x702>
   4fb55:	movzx  ecx,WORD PTR [rax+0x14]
   4fb59:	and    ecx,0x202
   4fb5f:	cmp    ecx,0x202
   4fb65:	jne    4fb73 <sqlite3VdbeExec+0x6d3>
   4fb67:	cmp    BYTE PTR [rax+0x16],0x1
   4fb6b:	jne    4fb73 <sqlite3VdbeExec+0x6d3>
   4fb6d:	mov    rax,QWORD PTR [rax+0x8]
   4fb71:	jmp    4fba2 <sqlite3VdbeExec+0x702>
   4fb73:	movzx  ecx,WORD PTR [rax+0x14]
   4fb77:	and    ecx,0x1
   4fb7a:	test   ecx,ecx
   4fb7c:	je     4fb82 <sqlite3VdbeExec+0x6e2>
   4fb7e:	xor    eax,eax
   4fb80:	jmp    4fba2 <sqlite3VdbeExec+0x702>
   4fb82:	mov    ecx,0x1
   4fb87:	mov    QWORD PTR [rsp+0x110],rdi
   4fb8f:	mov    rdi,rax
   4fb92:	mov    rsi,rcx
   4fb95:	call   4fb9a <sqlite3VdbeExec+0x6fa>
   4fb9a:	mov    rdi,QWORD PTR [rsp+0x110]
   4fba2:	lea    rcx,[rip+0x0]        # 4fba9 <sqlite3VdbeExec+0x709>
   4fba9:	mov    QWORD PTR [rsp+0x110],rdi
   4fbb1:	mov    rsi,rcx
   4fbb4:	mov    rdx,rax
   4fbb7:	xor    eax,eax
   4fbb9:	call   4fbbe <sqlite3VdbeExec+0x71e>
   4fbbe:	mov    rdi,QWORD PTR [rsp+0x110]
   4fbc6:	jmp    4fc71 <sqlite3VdbeExec+0x7d1>
   4fbcb:	cmp    WORD PTR [rbp+0x2],0x0
   4fbd0:	je     4fc49 <sqlite3VdbeExec+0x7a9>
   4fbd2:	lea    rax,[rip+0x0]        # 4fbd9 <sqlite3VdbeExec+0x739>
   4fbd9:	lea    rcx,[rip+0x0]        # 4fbe0 <sqlite3VdbeExec+0x740>
   4fbe0:	movzx  edx,WORD PTR [rbp+0x2]
   4fbe4:	add    rdx,0xffffffffffffffff
   4fbe8:	mov    rcx,QWORD PTR [rcx+rdx*8]
   4fbec:	mov    QWORD PTR [rsp+0x110],rdi
   4fbf4:	mov    rsi,rax
   4fbf7:	mov    rdx,rcx
   4fbfa:	xor    eax,eax
   4fbfc:	call   4fc01 <sqlite3VdbeExec+0x761>
   4fc01:	mov    rdi,QWORD PTR [rsp+0x110]
   4fc09:	cmp    QWORD PTR [rbp+0x10],0x0
   4fc0e:	je     4fc71 <sqlite3VdbeExec+0x7d1>
   4fc10:	lea    rax,[rip+0x0]        # 4fc17 <sqlite3VdbeExec+0x777>
   4fc17:	mov    rcx,QWORD PTR [rdi+0xa8]
   4fc1e:	mov    rdx,QWORD PTR [rbp+0x10]
   4fc22:	mov    rdi,r14
   4fc25:	mov    rsi,rax
   4fc28:	mov    r11,rdx
   4fc2b:	mov    rdx,rcx
   4fc2e:	mov    rcx,r11
   4fc31:	xor    eax,eax
   4fc33:	call   4fc38 <sqlite3VdbeExec+0x798>
   4fc38:	mov    rdi,QWORD PTR [rsp+0x110]
   4fc40:	mov    QWORD PTR [rdi+0xa8],rax
   4fc47:	jmp    4fc71 <sqlite3VdbeExec+0x7d1>
   4fc49:	lea    rax,[rip+0x0]        # 4fc50 <sqlite3VdbeExec+0x7b0>
   4fc50:	mov    rcx,QWORD PTR [rbp+0x10]
   4fc54:	mov    QWORD PTR [rsp+0x110],rdi
   4fc5c:	mov    rsi,rax
   4fc5f:	mov    rdx,rcx
   4fc62:	xor    eax,eax
   4fc64:	call   4fc69 <sqlite3VdbeExec+0x7c9>
   4fc69:	mov    rdi,QWORD PTR [rsp+0x110]
   4fc71:	mov    eax,DWORD PTR [rbp+0x4]
   4fc74:	mov    QWORD PTR [rsp+0x110],rdi
   4fc7c:	mov    rsi,rax
   4fc7f:	mov    rdx,rbp
   4fc82:	mov    rcx,r13
   4fc85:	call   4fc8a <sqlite3VdbeExec+0x7ea>
   4fc8a:	mov    rdi,QWORD PTR [rsp+0x110]
   4fc92:	mov    QWORD PTR [rsp+0x110],rdi
   4fc9a:	call   4fc9f <sqlite3VdbeExec+0x7ff>
   4fc9f:	mov    ebx,eax
   4fca1:	mov    rdi,QWORD PTR [rsp+0x110]
   4fca9:	cmp    ebx,0x5
   4fcac:	jne    4fcb7 <sqlite3VdbeExec+0x817>
   4fcae:	mov    DWORD PTR [rdi+0x34],0x5
   4fcb5:	jmp    4fcc9 <sqlite3VdbeExec+0x829>
   4fcb7:	cmp    DWORD PTR [rdi+0x34],0x0
   4fcbb:	je     4fcc4 <sqlite3VdbeExec+0x824>
   4fcbd:	mov    ebx,0x1
   4fcc2:	jmp    4fcc9 <sqlite3VdbeExec+0x829>
   4fcc4:	mov    ebx,0x65
   4fcc9:	mov    QWORD PTR [rsp+0x150],r13
   4fcd1:	mov    r12,rbx
   4fcd4:	mov    r13d,DWORD PTR [rsp+0x380]
   4fcdc:	mov    r15,QWORD PTR [rsp+0x130]
   4fce4:	mov    rbx,QWORD PTR [rsp+0x158]
   4fcec:	jmp    65d93 <sqlite3VdbeExec+0x168f3>
   4fcf1:	mov    r15d,DWORD PTR [rsp+0x37c]
   4fcf9:	mov    r13,QWORD PTR [rsp+0x150]
   4fd01:	mov    QWORD PTR [rsp+0x130],r12
   4fd09:	mov    r12d,DWORD PTR [rsp+0x394]
   4fd11:	mov    rax,QWORD PTR [rdi+0x68]
   4fd15:	movsxd rcx,DWORD PTR [rbp+0x8]
   4fd19:	imul   rcx,rcx,0x38
   4fd1d:	lea    rdx,[rax+rcx*1]
   4fd21:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4fd26:	and    eax,0x9000
   4fd2b:	test   eax,eax
   4fd2d:	je     4fd4c <sqlite3VdbeExec+0x8ac>
   4fd2f:	mov    QWORD PTR [rsp+0x110],rdi
   4fd37:	mov    rdi,rdx
   4fd3a:	call   4fd3f <sqlite3VdbeExec+0x89f>
   4fd3f:	mov    rdi,QWORD PTR [rsp+0x110]
   4fd47:	mov    rdx,rax
   4fd4a:	jmp    4fd52 <sqlite3VdbeExec+0x8b2>
   4fd4c:	mov    WORD PTR [rdx+0x14],0x4
   4fd52:	movsxd rax,DWORD PTR [rbp+0x4]
   4fd56:	mov    QWORD PTR [rdx],rax
   4fd59:	mov    DWORD PTR [rsp+0x37c],r15d
   4fd61:	mov    QWORD PTR [rsp+0x150],r13
   4fd69:	mov    DWORD PTR [rsp+0x394],r12d
   4fd71:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   4fd76:	mov    r15d,DWORD PTR [rsp+0x37c]
   4fd7e:	mov    r13,QWORD PTR [rsp+0x150]
   4fd86:	mov    QWORD PTR [rsp+0x130],r12
   4fd8e:	mov    r12d,DWORD PTR [rsp+0x394]
   4fd96:	mov    rax,QWORD PTR [rdi+0x68]
   4fd9a:	movsxd rcx,DWORD PTR [rbp+0x8]
   4fd9e:	imul   rcx,rcx,0x38
   4fda2:	lea    rdx,[rax+rcx*1]
   4fda6:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4fdab:	and    eax,0x9000
   4fdb0:	test   eax,eax
   4fdb2:	je     4fdd1 <sqlite3VdbeExec+0x931>
   4fdb4:	mov    QWORD PTR [rsp+0x110],rdi
   4fdbc:	mov    rdi,rdx
   4fdbf:	call   4fdc4 <sqlite3VdbeExec+0x924>
   4fdc4:	mov    rdi,QWORD PTR [rsp+0x110]
   4fdcc:	mov    rdx,rax
   4fdcf:	jmp    4fdd7 <sqlite3VdbeExec+0x937>
   4fdd1:	mov    WORD PTR [rdx+0x14],0x4
   4fdd7:	mov    rax,QWORD PTR [rbp+0x10]
   4fddb:	mov    rax,QWORD PTR [rax]
   4fdde:	mov    QWORD PTR [rdx],rax
   4fde1:	mov    DWORD PTR [rsp+0x37c],r15d
   4fde9:	mov    QWORD PTR [rsp+0x150],r13
   4fdf1:	mov    DWORD PTR [rsp+0x394],r12d
   4fdf9:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   4fdfe:	mov    r15d,DWORD PTR [rsp+0x37c]
   4fe06:	mov    r13,QWORD PTR [rsp+0x150]
   4fe0e:	mov    QWORD PTR [rsp+0x130],r12
   4fe16:	mov    r12d,DWORD PTR [rsp+0x394]
   4fe1e:	mov    rax,QWORD PTR [rdi+0x68]
   4fe22:	movsxd rcx,DWORD PTR [rbp+0x8]
   4fe26:	imul   rcx,rcx,0x38
   4fe2a:	lea    rdx,[rax+rcx*1]
   4fe2e:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4fe33:	and    eax,0x9000
   4fe38:	test   eax,eax
   4fe3a:	je     4fe59 <sqlite3VdbeExec+0x9b9>
   4fe3c:	mov    QWORD PTR [rsp+0x110],rdi
   4fe44:	mov    rdi,rdx
   4fe47:	call   4fe4c <sqlite3VdbeExec+0x9ac>
   4fe4c:	mov    rdi,QWORD PTR [rsp+0x110]
   4fe54:	mov    rdx,rax
   4fe57:	jmp    4fe5f <sqlite3VdbeExec+0x9bf>
   4fe59:	mov    WORD PTR [rdx+0x14],0x4
   4fe5f:	mov    WORD PTR [rdx+0x14],0x8
   4fe65:	mov    rax,QWORD PTR [rbp+0x10]
   4fe69:	movsd  xmm0,QWORD PTR [rax]
   4fe6d:	movsd  QWORD PTR [rdx],xmm0
   4fe71:	mov    DWORD PTR [rsp+0x37c],r15d
   4fe79:	mov    QWORD PTR [rsp+0x150],r13
   4fe81:	mov    DWORD PTR [rsp+0x394],r12d
   4fe89:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   4fe8e:	mov    r15d,DWORD PTR [rsp+0x37c]
   4fe96:	mov    r13,QWORD PTR [rsp+0x150]
   4fe9e:	mov    QWORD PTR [rsp+0x130],r12
   4fea6:	mov    r12d,DWORD PTR [rsp+0x394]
   4feae:	mov    rax,QWORD PTR [rdi+0x68]
   4feb2:	movsxd rcx,DWORD PTR [rbp+0x8]
   4feb6:	imul   rcx,rcx,0x38
   4feba:	mov    DWORD PTR [rsp+0x394],r12d
   4fec2:	lea    r12,[rax+rcx*1]
   4fec6:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4fecb:	and    eax,0x9000
   4fed0:	test   eax,eax
   4fed2:	je     4fef1 <sqlite3VdbeExec+0xa51>
   4fed4:	mov    QWORD PTR [rsp+0x110],rdi
   4fedc:	mov    rdi,r12
   4fedf:	call   4fee4 <sqlite3VdbeExec+0xa44>
   4fee4:	mov    r12,rax
   4fee7:	mov    rdi,QWORD PTR [rsp+0x110]
   4feef:	jmp    4fef9 <sqlite3VdbeExec+0xa59>
   4fef1:	mov    WORD PTR [r12+0x14],0x4
   4fef9:	mov    rax,QWORD PTR [rbp+0x10]
   4fefd:	test   rax,rax
   4ff00:	jne    4ff06 <sqlite3VdbeExec+0xa66>
   4ff02:	xor    eax,eax
   4ff04:	jmp    4ff23 <sqlite3VdbeExec+0xa83>
   4ff06:	mov    QWORD PTR [rsp+0x110],rdi
   4ff0e:	mov    rdi,rax
   4ff11:	call   4ff16 <sqlite3VdbeExec+0xa76>
   4ff16:	and    eax,0x3fffffff
   4ff1b:	mov    rdi,QWORD PTR [rsp+0x110]
   4ff23:	mov    DWORD PTR [rbp+0x4],eax
   4ff26:	mov    eax,r15d
   4ff29:	cmp    eax,0x1
   4ff2c:	jne    4ff3b <sqlite3VdbeExec+0xa9b>
   4ff2e:	mov    QWORD PTR [rsp+0x150],r13
   4ff36:	jmp    5000b <sqlite3VdbeExec+0xb6b>
   4ff3b:	mov    rax,QWORD PTR [rbp+0x10]
   4ff3f:	mov    rcx,0xffffffffffffffff
   4ff46:	xor    edx,edx
   4ff48:	mov    esi,0x1
   4ff4d:	mov    QWORD PTR [rsp+0x150],r13
   4ff55:	mov    QWORD PTR [rsp+0x110],rdi
   4ff5d:	mov    rdi,r12
   4ff60:	mov    r8,rdx
   4ff63:	mov    rdx,rcx
   4ff66:	mov    rcx,rsi
   4ff69:	mov    rsi,rax
   4ff6c:	call   4ff71 <sqlite3VdbeExec+0xad1>
   4ff71:	mov    r13d,eax
   4ff74:	mov    rdi,QWORD PTR [rsp+0x110]
   4ff7c:	test   r13d,r13d
   4ff7f:	je     4ff91 <sqlite3VdbeExec+0xaf1>
   4ff81:	mov    QWORD PTR [rsp+0x148],rbp
   4ff89:	mov    rbp,r14
   4ff8c:	jmp    53cbc <sqlite3VdbeExec+0x481c>
   4ff91:	mov    eax,r15d
   4ff94:	movzx  ecx,WORD PTR [r12+0x14]
   4ff9a:	and    ecx,0x2
   4ff9d:	test   ecx,ecx
   4ff9f:	jne    50066 <sqlite3VdbeExec+0xbc6>
   4ffa5:	mov    BYTE PTR [r12+0x16],al
   4ffaa:	mov    DWORD PTR [r12+0x20],0x0
   4ffb3:	movzx  eax,WORD PTR [r12+0x14]
   4ffb9:	or     eax,0x2000
   4ffbe:	mov    WORD PTR [r12+0x14],ax
   4ffc4:	cmp    BYTE PTR [rbp+0x1],0xf9
   4ffc8:	jne    4ffee <sqlite3VdbeExec+0xb4e>
   4ffca:	mov    rax,QWORD PTR [rbp+0x10]
   4ffce:	test   rax,rax
   4ffd1:	je     4ffee <sqlite3VdbeExec+0xb4e>
   4ffd3:	mov    QWORD PTR [rsp+0x110],rdi
   4ffdb:	mov    rdi,r14
   4ffde:	mov    rsi,rax
   4ffe1:	call   4ffe6 <sqlite3VdbeExec+0xb46>
   4ffe6:	mov    rdi,QWORD PTR [rsp+0x110]
   4ffee:	mov    BYTE PTR [rbp+0x1],0xf9
   4fff2:	mov    rax,QWORD PTR [r12+0x8]
   4fff7:	mov    QWORD PTR [rbp+0x10],rax
   4fffb:	mov    eax,DWORD PTR [r12+0x10]
   50000:	mov    DWORD PTR [rbp+0x4],eax
   50003:	mov    DWORD PTR [rsp+0x38c],r13d
   5000b:	mov    eax,DWORD PTR [rbp+0x4]
   5000e:	cmp    eax,DWORD PTR [r14+0x88]
   50015:	jle    50027 <sqlite3VdbeExec+0xb87>
   50017:	mov    QWORD PTR [rsp+0x148],rbp
   5001f:	mov    rbp,r14
   50022:	jmp    53cbc <sqlite3VdbeExec+0x481c>
   50027:	mov    BYTE PTR [rbp+0x0],0x4b
   5002b:	mov    rax,QWORD PTR [rdi+0x68]
   5002f:	movsxd rcx,DWORD PTR [rbp+0x8]
   50033:	imul   rcx,rcx,0x38
   50037:	lea    rdx,[rax+rcx*1]
   5003b:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   50040:	and    eax,0x9000
   50045:	test   eax,eax
   50047:	je     500c4 <sqlite3VdbeExec+0xc24>
   50049:	mov    QWORD PTR [rsp+0x110],rdi
   50051:	mov    rdi,rdx
   50054:	call   50059 <sqlite3VdbeExec+0xbb9>
   50059:	mov    rdi,QWORD PTR [rsp+0x110]
   50061:	mov    rdx,rax
   50064:	jmp    500ca <sqlite3VdbeExec+0xc2a>
   50066:	movzx  ecx,BYTE PTR [r12+0x16]
   5006c:	cmp    ecx,eax
   5006e:	je     4ffaa <sqlite3VdbeExec+0xb0a>
   50074:	mov    rdi,r12
   50077:	mov    rsi,rax
   5007a:	call   5007f <sqlite3VdbeExec+0xbdf>
   5007f:	mov    rdi,QWORD PTR [rsp+0x110]
   50087:	mov    QWORD PTR [rsp+0x128],r14
   5008f:	xor    r14d,r14d
   50092:	cmp    r14d,eax
   50095:	jne    500a4 <sqlite3VdbeExec+0xc04>
   50097:	mov    r14,QWORD PTR [rsp+0x128]
   5009f:	jmp    4ffaa <sqlite3VdbeExec+0xb0a>
   500a4:	mov    r14,QWORD PTR [rsp+0x128]
   500ac:	mov    r13,QWORD PTR [rsp+0x150]
   500b4:	mov    rbx,rbp
   500b7:	mov    rbp,QWORD PTR [rsp+0x158]
   500bf:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   500c4:	mov    WORD PTR [rdx+0x14],0x4
   500ca:	mov    WORD PTR [rdx+0x14],0x2202
   500d0:	mov    rax,QWORD PTR [rbp+0x10]
   500d4:	mov    QWORD PTR [rdx+0x8],rax
   500d8:	mov    eax,DWORD PTR [rbp+0x4]
   500db:	mov    DWORD PTR [rdx+0x10],eax
   500de:	mov    BYTE PTR [rdx+0x16],r15b
   500e2:	cmp    DWORD PTR [rbp+0xc],0x0
   500e6:	jle    50103 <sqlite3VdbeExec+0xc63>
   500e8:	movsxd rax,DWORD PTR [rbp+0xc]
   500ec:	imul   rax,rax,0x38
   500f0:	mov    rax,QWORD PTR [rbx+rax*1]
   500f4:	movzx  ecx,WORD PTR [rbp+0x2]
   500f8:	cmp    rax,rcx
   500fb:	jne    50103 <sqlite3VdbeExec+0xc63>
   500fd:	mov    WORD PTR [rdx+0x14],0x2210
   50103:	mov    DWORD PTR [rsp+0x37c],r15d
   5010b:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   50110:	mov    r15d,DWORD PTR [rsp+0x37c]
   50118:	mov    r13,QWORD PTR [rsp+0x150]
   50120:	mov    QWORD PTR [rsp+0x130],r12
   50128:	mov    r12d,DWORD PTR [rsp+0x394]
   50130:	mov    rax,QWORD PTR [rdi+0x68]
   50134:	movsxd rcx,DWORD PTR [rbp+0x8]
   50138:	imul   rcx,rcx,0x38
   5013c:	mov    DWORD PTR [rsp+0x394],r12d
   50144:	lea    r12,[rax+rcx*1]
   50148:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5014d:	and    eax,0x9000
   50152:	test   eax,eax
   50154:	je     50173 <sqlite3VdbeExec+0xcd3>
   50156:	mov    QWORD PTR [rsp+0x110],rdi
   5015e:	mov    rdi,r12
   50161:	call   50166 <sqlite3VdbeExec+0xcc6>
   50166:	mov    r12,rax
   50169:	mov    rdi,QWORD PTR [rsp+0x110]
   50171:	jmp    5017b <sqlite3VdbeExec+0xcdb>
   50173:	mov    WORD PTR [r12+0x14],0x4
   5017b:	mov    eax,DWORD PTR [rbp+0xc]
   5017e:	mov    QWORD PTR [rsp+0x168],r12
   50186:	mov    r12d,eax
   50189:	sub    r12d,DWORD PTR [rbp+0x8]
   5018d:	cmp    DWORD PTR [rbp+0x4],0x0
   50191:	je     501a3 <sqlite3VdbeExec+0xd03>
   50193:	mov    DWORD PTR [rsp+0x398],r12d
   5019b:	mov    r12d,0x101
   501a1:	jmp    501b1 <sqlite3VdbeExec+0xd11>
   501a3:	mov    DWORD PTR [rsp+0x398],r12d
   501ab:	mov    r12d,0x1
   501b1:	mov    QWORD PTR [rsp+0x150],r13
   501b9:	mov    r13,QWORD PTR [rsp+0x168]
   501c1:	mov    WORD PTR [r13+0x14],r12w
   501c6:	mov    DWORD PTR [r13+0x10],0x0
   501ce:	mov    DWORD PTR [rsp+0x37c],r15d
   501d6:	mov    r15,r13
   501d9:	mov    r13d,DWORD PTR [rsp+0x398]
   501e1:	jmp    50206 <sqlite3VdbeExec+0xd66>
   501e3:	mov    r15,r14
   501e6:	mov    r14,QWORD PTR [rsp+0x128]
   501ee:	mov    WORD PTR [r15+0x14],0x1
   501f5:	mov    WORD PTR [r15+0x14],r12w
   501fa:	mov    DWORD PTR [r15+0x10],0x0
   50202:	sub    r13d,0x1
   50206:	test   r13d,r13d
   50209:	jle    5024a <sqlite3VdbeExec+0xdaa>
   5020b:	mov    QWORD PTR [rsp+0x128],r14
   50213:	lea    r14,[r15+0x38]
   50217:	movzx  eax,WORD PTR [r15+0x4c]
   5021c:	and    eax,0x9000
   50221:	test   eax,eax
   50223:	je     501e3 <sqlite3VdbeExec+0xd43>
   50225:	mov    QWORD PTR [rsp+0x110],rdi
   5022d:	mov    rdi,r14
   50230:	call   50235 <sqlite3VdbeExec+0xd95>
   50235:	mov    rdi,QWORD PTR [rsp+0x110]
   5023d:	mov    r15,r14
   50240:	mov    r14,QWORD PTR [rsp+0x128]
   50248:	jmp    501f5 <sqlite3VdbeExec+0xd55>
   5024a:	mov    QWORD PTR [rsp+0x128],r14
   50252:	mov    r14,QWORD PTR [rsp+0x128]
   5025a:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5025f:	mov    QWORD PTR [rsp+0x128],r14
   50267:	mov    QWORD PTR [rsp+0x130],r12
   5026f:	movsxd rax,DWORD PTR [rbp+0x4]
   50273:	imul   rax,rax,0x38
   50277:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   5027c:	and    ecx,0xffffffc0
   5027f:	or     ecx,0x1
   50282:	mov    WORD PTR [rbx+rax*1+0x14],cx
   50287:	mov    r14,QWORD PTR [rsp+0x128]
   5028f:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   50294:	mov    QWORD PTR [rsp+0x128],r14
   5029c:	mov    QWORD PTR [rsp+0x130],r12
   502a4:	mov    rax,QWORD PTR [rdi+0x68]
   502a8:	movsxd rcx,DWORD PTR [rbp+0x8]
   502ac:	imul   rcx,rcx,0x38
   502b0:	lea    r12,[rax+rcx*1]
   502b4:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   502b9:	and    eax,0x9000
   502be:	test   eax,eax
   502c0:	je     502df <sqlite3VdbeExec+0xe3f>
   502c2:	mov    QWORD PTR [rsp+0x110],rdi
   502ca:	mov    rdi,r12
   502cd:	call   502d2 <sqlite3VdbeExec+0xe32>
   502d2:	mov    r12,rax
   502d5:	mov    rdi,QWORD PTR [rsp+0x110]
   502dd:	jmp    502e7 <sqlite3VdbeExec+0xe47>
   502df:	mov    WORD PTR [r12+0x14],0x4
   502e7:	cmp    QWORD PTR [rbp+0x10],0x0
   502ec:	jne    50414 <sqlite3VdbeExec+0xf74>
   502f2:	mov    r13d,DWORD PTR [rbp+0x4]
   502f6:	movzx  eax,WORD PTR [r12+0x14]
   502fc:	and    eax,0x9000
   50301:	test   eax,eax
   50303:	jne    5030d <sqlite3VdbeExec+0xe6d>
   50305:	cmp    DWORD PTR [r12+0x20],0x0
   5030b:	je     50325 <sqlite3VdbeExec+0xe85>
   5030d:	mov    QWORD PTR [rsp+0x110],rdi
   50315:	mov    rdi,r12
   50318:	call   5031d <sqlite3VdbeExec+0xe7d>
   5031d:	mov    rdi,QWORD PTR [rsp+0x110]
   50325:	mov    WORD PTR [r12+0x14],0x410
   5032d:	mov    DWORD PTR [r12+0x10],0x0
   50336:	xor    eax,eax
   50338:	test   r13d,r13d
   5033b:	cmovge eax,r13d
   5033f:	mov    DWORD PTR [r12],eax
   50343:	mov    BYTE PTR [r12+0x16],0x1
   50349:	mov    QWORD PTR [r12+0x8],0x0
   50352:	mov    eax,DWORD PTR [r12+0x10]
   50357:	add    eax,DWORD PTR [r12]
   5035b:	test   eax,eax
   5035d:	jg     5037e <sqlite3VdbeExec+0xede>
   5035f:	movzx  eax,WORD PTR [r12+0x14]
   50365:	and    eax,0x10
   50368:	test   eax,eax
   5036a:	jne    50379 <sqlite3VdbeExec+0xed9>
   5036c:	mov    r15d,DWORD PTR [rsp+0x37c]
   50374:	jmp    5044c <sqlite3VdbeExec+0xfac>
   50379:	mov    eax,0x1
   5037e:	mov    ecx,0x1
   50383:	mov    QWORD PTR [rsp+0x110],rdi
   5038b:	mov    rdi,r12
   5038e:	mov    rsi,rax
   50391:	mov    rdx,rcx
   50394:	call   50399 <sqlite3VdbeExec+0xef9>
   50399:	mov    rdi,QWORD PTR [rsp+0x110]
   503a1:	test   eax,eax
   503a3:	jne    503f4 <sqlite3VdbeExec+0xf54>
   503a5:	mov    rax,QWORD PTR [r12+0x8]
   503aa:	movsxd rcx,DWORD PTR [r12+0x10]
   503af:	add    rax,rcx
   503b2:	xor    ecx,ecx
   503b4:	movsxd rdx,DWORD PTR [r12]
   503b8:	mov    rdi,rax
   503bb:	mov    rsi,rcx
   503be:	call   503c3 <sqlite3VdbeExec+0xf23>
   503c3:	mov    eax,DWORD PTR [r12+0x10]
   503c8:	add    eax,DWORD PTR [r12]
   503cc:	mov    DWORD PTR [r12+0x10],eax
   503d1:	movzx  eax,WORD PTR [r12+0x14]
   503d7:	and    eax,0xfffff9ff
   503dc:	mov    WORD PTR [r12+0x14],ax
   503e2:	mov    rdi,QWORD PTR [rsp+0x110]
   503ea:	mov    r15d,DWORD PTR [rsp+0x37c]
   503f2:	jmp    5044c <sqlite3VdbeExec+0xfac>
   503f4:	mov    r14,QWORD PTR [rsp+0x128]
   503fc:	mov    r13,QWORD PTR [rsp+0x150]
   50404:	mov    rbx,rbp
   50407:	mov    rbp,QWORD PTR [rsp+0x158]
   5040f:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50414:	mov    r15d,DWORD PTR [rsp+0x37c]
   5041c:	mov    rax,QWORD PTR [rbp+0x10]
   50420:	movsxd rcx,DWORD PTR [rbp+0x4]
   50424:	xor    edx,edx
   50426:	xor    esi,esi
   50428:	mov    QWORD PTR [rsp+0x110],rdi
   50430:	mov    rdi,r12
   50433:	mov    r8,rdx
   50436:	mov    rdx,rcx
   50439:	mov    rcx,rsi
   5043c:	mov    rsi,rax
   5043f:	call   50444 <sqlite3VdbeExec+0xfa4>
   50444:	mov    rdi,QWORD PTR [rsp+0x110]
   5044c:	mov    BYTE PTR [r12+0x16],r15b
   50451:	mov    r14,QWORD PTR [rsp+0x128]
   50459:	mov    DWORD PTR [rsp+0x37c],r15d
   50461:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   50466:	mov    QWORD PTR [rsp+0x128],r14
   5046e:	mov    r15d,DWORD PTR [rsp+0x37c]
   50476:	mov    QWORD PTR [rsp+0x130],r12
   5047e:	mov    r12,QWORD PTR [rdi+0x80]
   50485:	mov    eax,DWORD PTR [rbp+0x4]
   50488:	sub    eax,0x1
   5048b:	movsxd rax,eax
   5048e:	imul   r13,rax,0x38
   50492:	movzx  eax,WORD PTR [r12+r13*1+0x14]
   50498:	and    eax,0x12
   5049b:	test   eax,eax
   5049d:	je     504da <sqlite3VdbeExec+0x103a>
   5049f:	mov    eax,DWORD PTR [r12+r13*1+0x10]
   504a4:	movzx  ecx,WORD PTR [r12+r13*1+0x14]
   504aa:	and    ecx,0x400
   504b0:	test   ecx,ecx
   504b2:	je     504b8 <sqlite3VdbeExec+0x1018>
   504b4:	add    eax,DWORD PTR [r12+r13*1]
   504b8:	mov    rcx,QWORD PTR [r12+r13*1+0x18]
   504bd:	cmp    eax,DWORD PTR [rcx+0x88]
   504c3:	jle    504da <sqlite3VdbeExec+0x103a>
   504c5:	mov    QWORD PTR [rsp+0x148],rbp
   504cd:	mov    rbp,QWORD PTR [rsp+0x128]
   504d5:	jmp    53cbc <sqlite3VdbeExec+0x481c>
   504da:	movsxd rax,DWORD PTR [rbp+0x8]
   504de:	imul   rax,rax,0x38
   504e2:	lea    r14,[rbx+rax*1]
   504e6:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   504eb:	and    eax,0x9000
   504f0:	test   eax,eax
   504f2:	je     50523 <sqlite3VdbeExec+0x1083>
   504f4:	movzx  eax,WORD PTR [r14+0x14]
   504f9:	and    eax,0x9000
   504fe:	test   eax,eax
   50500:	je     5051c <sqlite3VdbeExec+0x107c>
   50502:	mov    QWORD PTR [rsp+0x110],rdi
   5050a:	mov    rdi,r14
   5050d:	call   50512 <sqlite3VdbeExec+0x1072>
   50512:	mov    rdi,QWORD PTR [rsp+0x110]
   5051a:	jmp    50523 <sqlite3VdbeExec+0x1083>
   5051c:	mov    WORD PTR [r14+0x14],0x1
   50523:	mov    rax,QWORD PTR [r12+r13*1]
   50527:	mov    QWORD PTR [r14],rax
   5052a:	mov    rax,QWORD PTR [r12+r13*1+0x8]
   5052f:	mov    QWORD PTR [r14+0x8],rax
   50533:	mov    rax,QWORD PTR [r12+r13*1+0x10]
   50538:	mov    QWORD PTR [r14+0x10],rax
   5053c:	movzx  eax,WORD PTR [r14+0x14]
   50541:	and    eax,0xffffafff
   50546:	mov    WORD PTR [r14+0x14],ax
   5054b:	movzx  eax,WORD PTR [r14+0x14]
   50550:	or     eax,0x2040
   50555:	mov    WORD PTR [r14+0x14],ax
   5055a:	mov    r14,QWORD PTR [rsp+0x128]
   50562:	mov    DWORD PTR [rsp+0x37c],r15d
   5056a:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5056f:	mov    QWORD PTR [rsp+0x128],r14
   50577:	mov    r15d,DWORD PTR [rsp+0x37c]
   5057f:	mov    QWORD PTR [rsp+0x130],r12
   50587:	mov    r12d,DWORD PTR [rbp+0xc]
   5058b:	movsxd rax,DWORD PTR [rbp+0x4]
   5058f:	imul   rax,rax,0x38
   50593:	lea    r13,[rbx+rax*1]
   50597:	movsxd rax,DWORD PTR [rbp+0x8]
   5059b:	imul   rax,rax,0x38
   5059f:	lea    r14,[rbx+rax*1]
   505a3:	movzx  eax,WORD PTR [r14+0x14]
   505a8:	and    eax,0x9000
   505ad:	test   eax,eax
   505af:	jne    505b8 <sqlite3VdbeExec+0x1118>
   505b1:	cmp    DWORD PTR [r14+0x20],0x0
   505b6:	je     505d0 <sqlite3VdbeExec+0x1130>
   505b8:	mov    QWORD PTR [rsp+0x110],rdi
   505c0:	mov    rdi,r14
   505c3:	call   505c8 <sqlite3VdbeExec+0x1128>
   505c8:	mov    rdi,QWORD PTR [rsp+0x110]
   505d0:	mov    eax,0x38
   505d5:	mov    QWORD PTR [rsp+0x110],rdi
   505dd:	mov    rdi,r14
   505e0:	mov    rsi,r13
   505e3:	mov    rdx,rax
   505e6:	call   505eb <sqlite3VdbeExec+0x114b>
   505eb:	mov    WORD PTR [r13+0x14],0x1
   505f2:	mov    DWORD PTR [r13+0x20],0x0
   505fa:	movzx  eax,WORD PTR [r14+0x14]
   505ff:	and    eax,0x4000
   50604:	mov    rdi,QWORD PTR [rsp+0x110]
   5060c:	test   eax,eax
   5060e:	je     50716 <sqlite3VdbeExec+0x1276>
   50614:	movzx  eax,WORD PTR [r14+0x14]
   50619:	and    eax,0x12
   5061c:	test   eax,eax
   5061e:	je     50707 <sqlite3VdbeExec+0x1267>
   50624:	movzx  eax,WORD PTR [r14+0x14]
   50629:	and    eax,0x400
   5062e:	test   eax,eax
   50630:	je     506b6 <sqlite3VdbeExec+0x1216>
   50636:	mov    eax,DWORD PTR [r14+0x10]
   5063a:	add    eax,DWORD PTR [r14]
   5063d:	test   eax,eax
   5063f:	jg     50652 <sqlite3VdbeExec+0x11b2>
   50641:	movzx  eax,WORD PTR [r14+0x14]
   50646:	and    eax,0x10
   50649:	test   eax,eax
   5064b:	je     506b6 <sqlite3VdbeExec+0x1216>
   5064d:	mov    eax,0x1
   50652:	mov    ecx,0x1
   50657:	mov    QWORD PTR [rsp+0x110],rdi
   5065f:	mov    rdi,r14
   50662:	mov    rsi,rax
   50665:	mov    rdx,rcx
   50668:	call   5066d <sqlite3VdbeExec+0x11cd>
   5066d:	mov    rdi,QWORD PTR [rsp+0x110]
   50675:	test   eax,eax
   50677:	jne    506e7 <sqlite3VdbeExec+0x1247>
   50679:	mov    rax,QWORD PTR [r14+0x8]
   5067d:	movsxd rcx,DWORD PTR [r14+0x10]
   50681:	add    rax,rcx
   50684:	xor    ecx,ecx
   50686:	movsxd rdx,DWORD PTR [r14]
   50689:	mov    rdi,rax
   5068c:	mov    rsi,rcx
   5068f:	call   50694 <sqlite3VdbeExec+0x11f4>
   50694:	mov    eax,DWORD PTR [r14+0x10]
   50698:	add    eax,DWORD PTR [r14]
   5069b:	mov    DWORD PTR [r14+0x10],eax
   5069f:	movzx  eax,WORD PTR [r14+0x14]
   506a4:	and    eax,0xfffff9ff
   506a9:	mov    WORD PTR [r14+0x14],ax
   506ae:	mov    rdi,QWORD PTR [rsp+0x110]
   506b6:	cmp    DWORD PTR [r14+0x20],0x0
   506bb:	je     506c7 <sqlite3VdbeExec+0x1227>
   506bd:	mov    rax,QWORD PTR [r14+0x8]
   506c1:	cmp    rax,QWORD PTR [r14+0x28]
   506c5:	je     50707 <sqlite3VdbeExec+0x1267>
   506c7:	mov    QWORD PTR [rsp+0x110],rdi
   506cf:	mov    rdi,r14
   506d2:	call   506d7 <sqlite3VdbeExec+0x1237>
   506d7:	mov    rdi,QWORD PTR [rsp+0x110]
   506df:	test   eax,eax
   506e1:	je     50707 <sqlite3VdbeExec+0x1267>
   506e3:	test   eax,eax
   506e5:	je     50716 <sqlite3VdbeExec+0x1276>
   506e7:	mov    r14,QWORD PTR [rsp+0x128]
   506ef:	mov    r13,QWORD PTR [rsp+0x150]
   506f7:	mov    rbx,rbp
   506fa:	mov    rbp,QWORD PTR [rsp+0x158]
   50702:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50707:	movzx  eax,WORD PTR [r14+0x14]
   5070c:	and    eax,0xffffbfff
   50711:	mov    WORD PTR [r14+0x14],ax
   50716:	add    r13,0x38
   5071a:	add    r14,0x38
   5071e:	sub    r12d,0x1
   50722:	test   r12d,r12d
   50725:	jne    505a3 <sqlite3VdbeExec+0x1103>
   5072b:	mov    r14,QWORD PTR [rsp+0x128]
   50733:	mov    DWORD PTR [rsp+0x37c],r15d
   5073b:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   50740:	mov    QWORD PTR [rsp+0x128],r14
   50748:	mov    r15d,DWORD PTR [rsp+0x37c]
   50750:	mov    QWORD PTR [rsp+0x130],r12
   50758:	mov    r12d,DWORD PTR [rbp+0xc]
   5075c:	movsxd rax,DWORD PTR [rbp+0x4]
   50760:	imul   rax,rax,0x38
   50764:	lea    r13,[rbx+rax*1]
   50768:	movsxd rax,DWORD PTR [rbp+0x8]
   5076c:	imul   rax,rax,0x38
   50770:	lea    r14,[rbx+rax*1]
   50774:	mov    r11,r12
   50777:	mov    r12,r13
   5077a:	mov    r13,r11
   5077d:	jmp    5092a <sqlite3VdbeExec+0x148a>
   50782:	mov    rcx,QWORD PTR [r12]
   50786:	mov    QWORD PTR [r14],rcx
   50789:	mov    rcx,QWORD PTR [r12+0x8]
   5078e:	mov    QWORD PTR [r14+0x8],rcx
   50792:	mov    rcx,QWORD PTR [r12+0x10]
   50797:	mov    QWORD PTR [r14+0x10],rcx
   5079b:	movzx  ecx,WORD PTR [r12+0x14]
   507a1:	and    ecx,0x2000
   507a7:	test   ecx,ecx
   507a9:	jne    507c7 <sqlite3VdbeExec+0x1327>
   507ab:	movzx  ecx,WORD PTR [r14+0x14]
   507b0:	and    ecx,0xffff8fff
   507b6:	mov    WORD PTR [r14+0x14],cx
   507bb:	movzx  ecx,WORD PTR [r14+0x14]
   507c0:	or     ecx,eax
   507c2:	mov    WORD PTR [r14+0x14],cx
   507c7:	movzx  eax,WORD PTR [r14+0x14]
   507cc:	and    eax,0x4000
   507d1:	test   eax,eax
   507d3:	je     508db <sqlite3VdbeExec+0x143b>
   507d9:	movzx  eax,WORD PTR [r14+0x14]
   507de:	and    eax,0x12
   507e1:	test   eax,eax
   507e3:	je     508cc <sqlite3VdbeExec+0x142c>
   507e9:	movzx  eax,WORD PTR [r14+0x14]
   507ee:	and    eax,0x400
   507f3:	test   eax,eax
   507f5:	je     5087b <sqlite3VdbeExec+0x13db>
   507fb:	mov    eax,DWORD PTR [r14+0x10]
   507ff:	add    eax,DWORD PTR [r14]
   50802:	test   eax,eax
   50804:	jg     50817 <sqlite3VdbeExec+0x1377>
   50806:	movzx  eax,WORD PTR [r14+0x14]
   5080b:	and    eax,0x10
   5080e:	test   eax,eax
   50810:	je     5087b <sqlite3VdbeExec+0x13db>
   50812:	mov    eax,0x1
   50817:	mov    ecx,0x1
   5081c:	mov    QWORD PTR [rsp+0x110],rdi
   50824:	mov    rdi,r14
   50827:	mov    rsi,rax
   5082a:	mov    rdx,rcx
   5082d:	call   50832 <sqlite3VdbeExec+0x1392>
   50832:	mov    rdi,QWORD PTR [rsp+0x110]
   5083a:	test   eax,eax
   5083c:	jne    508ac <sqlite3VdbeExec+0x140c>
   5083e:	mov    rax,QWORD PTR [r14+0x8]
   50842:	movsxd rcx,DWORD PTR [r14+0x10]
   50846:	add    rax,rcx
   50849:	xor    ecx,ecx
   5084b:	movsxd rdx,DWORD PTR [r14]
   5084e:	mov    rdi,rax
   50851:	mov    rsi,rcx
   50854:	call   50859 <sqlite3VdbeExec+0x13b9>
   50859:	mov    eax,DWORD PTR [r14+0x10]
   5085d:	add    eax,DWORD PTR [r14]
   50860:	mov    DWORD PTR [r14+0x10],eax
   50864:	movzx  eax,WORD PTR [r14+0x14]
   50869:	and    eax,0xfffff9ff
   5086e:	mov    WORD PTR [r14+0x14],ax
   50873:	mov    rdi,QWORD PTR [rsp+0x110]
   5087b:	cmp    DWORD PTR [r14+0x20],0x0
   50880:	je     5088c <sqlite3VdbeExec+0x13ec>
   50882:	mov    rax,QWORD PTR [r14+0x8]
   50886:	cmp    rax,QWORD PTR [r14+0x28]
   5088a:	je     508cc <sqlite3VdbeExec+0x142c>
   5088c:	mov    QWORD PTR [rsp+0x110],rdi
   50894:	mov    rdi,r14
   50897:	call   5089c <sqlite3VdbeExec+0x13fc>
   5089c:	mov    rdi,QWORD PTR [rsp+0x110]
   508a4:	test   eax,eax
   508a6:	je     508cc <sqlite3VdbeExec+0x142c>
   508a8:	test   eax,eax
   508aa:	je     508db <sqlite3VdbeExec+0x143b>
   508ac:	mov    r14,QWORD PTR [rsp+0x128]
   508b4:	mov    r13,QWORD PTR [rsp+0x150]
   508bc:	mov    rbx,rbp
   508bf:	mov    rbp,QWORD PTR [rsp+0x158]
   508c7:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   508cc:	movzx  eax,WORD PTR [r14+0x14]
   508d1:	and    eax,0xffffbfff
   508d6:	mov    WORD PTR [r14+0x14],ax
   508db:	movzx  eax,WORD PTR [r14+0x14]
   508e0:	and    eax,0x800
   508e5:	test   eax,eax
   508e7:	je     50903 <sqlite3VdbeExec+0x1463>
   508e9:	movzx  eax,WORD PTR [rbp+0x2]
   508ed:	and    eax,0x2
   508f0:	test   eax,eax
   508f2:	je     50903 <sqlite3VdbeExec+0x1463>
   508f4:	movzx  eax,WORD PTR [r14+0x14]
   508f9:	and    eax,0xfffff7ff
   508fe:	mov    WORD PTR [r14+0x14],ax
   50903:	mov    DWORD PTR [rsp+0x37c],r15d
   5090b:	mov    r15d,r13d
   5090e:	sub    r15d,0x1
   50912:	test   r13d,r13d
   50915:	je     50965 <sqlite3VdbeExec+0x14c5>
   50917:	add    r14,0x38
   5091b:	add    r12,0x38
   5091f:	mov    r13,r15
   50922:	mov    r15d,DWORD PTR [rsp+0x37c]
   5092a:	mov    eax,0x4000
   5092f:	movzx  ecx,WORD PTR [r14+0x14]
   50934:	and    ecx,0x9000
   5093a:	test   ecx,ecx
   5093c:	je     50782 <sqlite3VdbeExec+0x12e2>
   50942:	mov    QWORD PTR [rsp+0x110],rdi
   5094a:	mov    rdi,r14
   5094d:	mov    rsi,r12
   50950:	mov    rdx,rax
   50953:	call   50958 <sqlite3VdbeExec+0x14b8>
   50958:	mov    rdi,QWORD PTR [rsp+0x110]
   50960:	jmp    507c7 <sqlite3VdbeExec+0x1327>
   50965:	mov    r15d,DWORD PTR [rsp+0x37c]
   5096d:	mov    r14,QWORD PTR [rsp+0x128]
   50975:	mov    DWORD PTR [rsp+0x37c],r15d
   5097d:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   50982:	mov    QWORD PTR [rsp+0x128],r14
   5098a:	mov    r15d,DWORD PTR [rsp+0x37c]
   50992:	mov    QWORD PTR [rsp+0x130],r12
   5099a:	movsxd rax,DWORD PTR [rbp+0x4]
   5099e:	imul   rax,rax,0x38
   509a2:	add    rax,rbx
   509a5:	movsxd rcx,DWORD PTR [rbp+0x8]
   509a9:	imul   rcx,rcx,0x38
   509ad:	lea    rdx,[rbx+rcx*1]
   509b1:	mov    esi,0x4000
   509b6:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   509bb:	and    ecx,0x9000
   509c1:	test   ecx,ecx
   509c3:	je     509e5 <sqlite3VdbeExec+0x1545>
   509c5:	mov    QWORD PTR [rsp+0x110],rdi
   509cd:	mov    rdi,rdx
   509d0:	mov    rdx,rsi
   509d3:	mov    rsi,rax
   509d6:	call   509db <sqlite3VdbeExec+0x153b>
   509db:	mov    rdi,QWORD PTR [rsp+0x110]
   509e3:	jmp    50a22 <sqlite3VdbeExec+0x1582>
   509e5:	mov    rcx,QWORD PTR [rax]
   509e8:	mov    QWORD PTR [rdx],rcx
   509eb:	mov    rcx,QWORD PTR [rax+0x8]
   509ef:	mov    QWORD PTR [rdx+0x8],rcx
   509f3:	mov    rcx,QWORD PTR [rax+0x10]
   509f7:	mov    QWORD PTR [rdx+0x10],rcx
   509fb:	movzx  eax,WORD PTR [rax+0x14]
   509ff:	and    eax,0x2000
   50a04:	test   eax,eax
   50a06:	jne    50a22 <sqlite3VdbeExec+0x1582>
   50a08:	movzx  eax,WORD PTR [rdx+0x14]
   50a0c:	and    eax,0xffff8fff
   50a11:	mov    WORD PTR [rdx+0x14],ax
   50a15:	movzx  eax,WORD PTR [rdx+0x14]
   50a19:	or     eax,0x4000
   50a1e:	mov    WORD PTR [rdx+0x14],ax
   50a22:	mov    r14,QWORD PTR [rsp+0x128]
   50a2a:	mov    DWORD PTR [rsp+0x37c],r15d
   50a32:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   50a37:	mov    QWORD PTR [rsp+0x128],r14
   50a3f:	mov    r15d,DWORD PTR [rsp+0x37c]
   50a47:	mov    QWORD PTR [rsp+0x130],r12
   50a4f:	movsxd rax,DWORD PTR [rbp+0x4]
   50a53:	imul   rax,rax,0x38
   50a57:	movsxd rcx,DWORD PTR [rbp+0x8]
   50a5b:	imul   rcx,rcx,0x38
   50a5f:	lea    rdx,[rbx+rcx*1]
   50a63:	mov    rax,QWORD PTR [rbx+rax*1]
   50a67:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   50a6c:	and    ecx,0x9000
   50a72:	test   ecx,ecx
   50a74:	je     50a93 <sqlite3VdbeExec+0x15f3>
   50a76:	mov    QWORD PTR [rsp+0x110],rdi
   50a7e:	mov    rdi,rdx
   50a81:	mov    rsi,rax
   50a84:	call   50a89 <sqlite3VdbeExec+0x15e9>
   50a89:	mov    rdi,QWORD PTR [rsp+0x110]
   50a91:	jmp    50a9c <sqlite3VdbeExec+0x15fc>
   50a93:	mov    QWORD PTR [rdx],rax
   50a96:	mov    WORD PTR [rdx+0x14],0x4
   50a9c:	mov    r14,QWORD PTR [rsp+0x128]
   50aa4:	mov    DWORD PTR [rsp+0x37c],r15d
   50aac:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   50ab1:	mov    QWORD PTR [rsp+0x128],r14
   50ab9:	mov    r15d,DWORD PTR [rsp+0x37c]
   50ac1:	mov    QWORD PTR [rsp+0x130],r12
   50ac9:	cmp    QWORD PTR [rdi+0x50],0x0
   50ace:	jne    50ad5 <sqlite3VdbeExec+0x1635>
   50ad0:	xor    r12d,r12d
   50ad3:	jmp    50aed <sqlite3VdbeExec+0x164d>
   50ad5:	mov    QWORD PTR [rsp+0x110],rdi
   50add:	call   50ae2 <sqlite3VdbeExec+0x1642>
   50ae2:	mov    r12d,eax
   50ae5:	mov    rdi,QWORD PTR [rsp+0x110]
   50aed:	test   r12d,r12d
   50af0:	je     50b1a <sqlite3VdbeExec+0x167a>
   50af2:	mov    r14,QWORD PTR [rsp+0x128]
   50afa:	mov    QWORD PTR [rsp+0x148],rbp
   50b02:	mov    rbp,r12
   50b05:	mov    r13,QWORD PTR [rsp+0x130]
   50b0d:	mov    rbx,QWORD PTR [rsp+0x158]
   50b15:	jmp    4f712 <sqlite3VdbeExec+0x272>
   50b1a:	mov    r14,QWORD PTR [rsp+0x128]
   50b22:	mov    r13,QWORD PTR [rsp+0x150]
   50b2a:	mov    DWORD PTR [rsp+0x37c],r15d
   50b32:	mov    QWORD PTR [rsp+0x150],r13
   50b3a:	mov    DWORD PTR [rsp+0x38c],r12d
   50b42:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   50b47:	mov    r13,QWORD PTR [rsp+0x150]
   50b4f:	mov    QWORD PTR [rsp+0x130],r12
   50b57:	mov    eax,DWORD PTR [rdi+0x2c]
   50b5a:	add    eax,0x2
   50b5d:	or     eax,0x1
   50b60:	mov    DWORD PTR [rdi+0x2c],eax
   50b63:	movsxd rax,DWORD PTR [rbp+0x4]
   50b67:	imul   rax,rax,0x38
   50b6b:	add    rax,rbx
   50b6e:	mov    QWORD PTR [rdi+0xa0],rax
   50b75:	cmp    BYTE PTR [r14+0x67],0x0
   50b7a:	je     50b8c <sqlite3VdbeExec+0x16ec>
   50b7c:	mov    rbx,rbp
   50b7f:	mov    rbp,QWORD PTR [rsp+0x158]
   50b87:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50b8c:	movzx  eax,BYTE PTR [r14+0x6e]
   50b91:	and    eax,0x4
   50b94:	test   eax,eax
   50b96:	je     50bd2 <sqlite3VdbeExec+0x1732>
   50b98:	mov    rax,QWORD PTR [r14+0xf0]
   50b9f:	mov    ecx,0x4
   50ba4:	mov    rdx,QWORD PTR [r14+0xf8]
   50bab:	xor    esi,esi
   50bad:	mov    QWORD PTR [rsp+0x110],rdi
   50bb5:	mov    r10,rax
   50bb8:	mov    r11,rdi
   50bbb:	mov    rdi,rcx
   50bbe:	mov    rcx,rsi
   50bc1:	mov    rsi,rdx
   50bc4:	mov    rdx,r11
   50bc7:	call   r10
   50bca:	mov    rdi,QWORD PTR [rsp+0x110]
   50bd2:	mov    rax,rbp
   50bd5:	sub    rax,r13
   50bd8:	movabs rdx,0x2aaaaaaaaaaaaaab
   50be2:	imul   rdx
   50be5:	sar    rdx,0x2
   50be9:	mov    rax,rdx
   50bec:	shr    rax,0x3f
   50bf0:	add    rdx,rax
   50bf3:	mov    rax,rdx
   50bf6:	add    eax,0x1
   50bf9:	mov    DWORD PTR [rdi+0x30],eax
   50bfc:	mov    ebx,0x64
   50c01:	mov    QWORD PTR [rsp+0x150],r13
   50c09:	mov    r12,rbx
   50c0c:	mov    r13d,DWORD PTR [rsp+0x380]
   50c14:	mov    r15,QWORD PTR [rsp+0x130]
   50c1c:	mov    rbx,QWORD PTR [rsp+0x158]
   50c24:	jmp    65d93 <sqlite3VdbeExec+0x168f3>
   50c29:	mov    r15d,DWORD PTR [rsp+0x37c]
   50c31:	mov    r13,QWORD PTR [rsp+0x150]
   50c39:	mov    QWORD PTR [rsp+0x130],r12
   50c41:	mov    r12d,DWORD PTR [rsp+0x394]
   50c49:	movsxd rax,DWORD PTR [rbp+0x4]
   50c4d:	imul   rax,rax,0x38
   50c51:	mov    DWORD PTR [rsp+0x394],r12d
   50c59:	lea    r12,[rbx+rax*1]
   50c5d:	movsxd rcx,DWORD PTR [rbp+0x8]
   50c61:	imul   rcx,rcx,0x38
   50c65:	mov    QWORD PTR [rsp+0x150],r13
   50c6d:	lea    r13,[rbx+rcx*1]
   50c71:	movsxd rdx,DWORD PTR [rbp+0xc]
   50c75:	imul   rdx,rdx,0x38
   50c79:	mov    DWORD PTR [rsp+0x37c],r15d
   50c81:	lea    r15,[rbx+rdx*1]
   50c85:	mov    QWORD PTR [rsp+0x128],r14
   50c8d:	movzx  r14d,WORD PTR [rbx+rax*1+0x14]
   50c93:	mov    eax,r14d
   50c96:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   50c9b:	or     eax,ecx
   50c9d:	and    eax,0x1
   50ca0:	test   eax,eax
   50ca2:	je     50ce0 <sqlite3VdbeExec+0x1840>
   50ca4:	movzx  eax,WORD PTR [r15+0x14]
   50ca9:	and    eax,0x9000
   50cae:	test   eax,eax
   50cb0:	je     50ccc <sqlite3VdbeExec+0x182c>
   50cb2:	mov    QWORD PTR [rsp+0x110],rdi
   50cba:	mov    rdi,r15
   50cbd:	call   50cc2 <sqlite3VdbeExec+0x1822>
   50cc2:	mov    rdi,QWORD PTR [rsp+0x110]
   50cca:	jmp    50cd3 <sqlite3VdbeExec+0x1833>
   50ccc:	mov    WORD PTR [r15+0x14],0x1
   50cd3:	mov    r14,QWORD PTR [rsp+0x128]
   50cdb:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   50ce0:	mov    eax,r14d
   50ce3:	and    eax,0x12
   50ce6:	test   eax,eax
   50ce8:	jne    50d68 <sqlite3VdbeExec+0x18c8>
   50cea:	mov    r14d,DWORD PTR [rsp+0x37c]
   50cf2:	mov    eax,r14d
   50cf5:	xor    ecx,ecx
   50cf7:	mov    QWORD PTR [rsp+0x110],rdi
   50cff:	mov    rdi,r12
   50d02:	mov    rsi,rax
   50d05:	mov    rdx,rcx
   50d08:	call   50d0d <sqlite3VdbeExec+0x186d>
   50d0d:	mov    rdi,QWORD PTR [rsp+0x110]
   50d15:	test   eax,eax
   50d17:	je     50d39 <sqlite3VdbeExec+0x1899>
   50d19:	mov    r14,QWORD PTR [rsp+0x128]
   50d21:	mov    r13,QWORD PTR [rsp+0x150]
   50d29:	mov    rbx,rbp
   50d2c:	mov    rbp,QWORD PTR [rsp+0x158]
   50d34:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50d39:	movzx  eax,WORD PTR [r12+0x14]
   50d3f:	and    eax,0xfffffffd
   50d42:	mov    QWORD PTR [rsp+0x170],r15
   50d4a:	mov    r15d,eax
   50d4d:	mov    QWORD PTR [rsp+0x148],rbp
   50d55:	mov    rbp,rbx
   50d58:	mov    rbx,r15
   50d5b:	mov    r15,QWORD PTR [rsp+0x170]
   50d63:	jmp    50e4e <sqlite3VdbeExec+0x19ae>
   50d68:	mov    QWORD PTR [rsp+0x170],r15
   50d70:	mov    r15,rbx
   50d73:	mov    rbx,r14
   50d76:	mov    r14d,DWORD PTR [rsp+0x37c]
   50d7e:	mov    eax,ebx
   50d80:	and    eax,0x400
   50d85:	test   eax,eax
   50d87:	jne    50da1 <sqlite3VdbeExec+0x1901>
   50d89:	mov    QWORD PTR [rsp+0x148],rbp
   50d91:	mov    rbp,r15
   50d94:	mov    r15,QWORD PTR [rsp+0x170]
   50d9c:	jmp    50e4e <sqlite3VdbeExec+0x19ae>
   50da1:	mov    eax,DWORD PTR [r12+0x10]
   50da6:	add    eax,DWORD PTR [r12]
   50daa:	test   eax,eax
   50dac:	jg     50dc0 <sqlite3VdbeExec+0x1920>
   50dae:	movzx  eax,WORD PTR [r12+0x14]
   50db4:	and    eax,0x10
   50db7:	test   eax,eax
   50db9:	je     50e30 <sqlite3VdbeExec+0x1990>
   50dbb:	mov    eax,0x1
   50dc0:	mov    ecx,0x1
   50dc5:	mov    QWORD PTR [rsp+0x110],rdi
   50dcd:	mov    rdi,r12
   50dd0:	mov    rsi,rax
   50dd3:	mov    rdx,rcx
   50dd6:	call   50ddb <sqlite3VdbeExec+0x193b>
   50ddb:	mov    rdi,QWORD PTR [rsp+0x110]
   50de3:	test   eax,eax
   50de5:	jne    50eb3 <sqlite3VdbeExec+0x1a13>
   50deb:	mov    rax,QWORD PTR [r12+0x8]
   50df0:	movsxd rcx,DWORD PTR [r12+0x10]
   50df5:	add    rax,rcx
   50df8:	xor    ecx,ecx
   50dfa:	movsxd rdx,DWORD PTR [r12]
   50dfe:	mov    rdi,rax
   50e01:	mov    rsi,rcx
   50e04:	call   50e09 <sqlite3VdbeExec+0x1969>
   50e09:	mov    eax,DWORD PTR [r12+0x10]
   50e0e:	add    eax,DWORD PTR [r12]
   50e12:	mov    DWORD PTR [r12+0x10],eax
   50e17:	movzx  eax,WORD PTR [r12+0x14]
   50e1d:	and    eax,0xfffff9ff
   50e22:	mov    WORD PTR [r12+0x14],ax
   50e28:	mov    rdi,QWORD PTR [rsp+0x110]
   50e30:	movzx  eax,WORD PTR [r12+0x14]
   50e36:	and    eax,0xfffffffd
   50e39:	mov    ebx,eax
   50e3b:	mov    QWORD PTR [rsp+0x148],rbp
   50e43:	mov    rbp,r15
   50e46:	mov    r15,QWORD PTR [rsp+0x170]
   50e4e:	mov    DWORD PTR [rsp+0x398],ebx
   50e55:	movzx  ebx,WORD PTR [r13+0x14]
   50e5a:	mov    eax,ebx
   50e5c:	and    eax,0x12
   50e5f:	test   eax,eax
   50e61:	jne    50eef <sqlite3VdbeExec+0x1a4f>
   50e67:	mov    eax,r14d
   50e6a:	xor    ecx,ecx
   50e6c:	mov    QWORD PTR [rsp+0x110],rdi
   50e74:	mov    rdi,r13
   50e77:	mov    rsi,rax
   50e7a:	mov    rdx,rcx
   50e7d:	call   50e82 <sqlite3VdbeExec+0x19e2>
   50e82:	mov    rdi,QWORD PTR [rsp+0x110]
   50e8a:	test   eax,eax
   50e8c:	je     50ee0 <sqlite3VdbeExec+0x1a40>
   50e8e:	mov    r14,QWORD PTR [rsp+0x128]
   50e96:	mov    r13,QWORD PTR [rsp+0x150]
   50e9e:	mov    rbx,QWORD PTR [rsp+0x148]
   50ea6:	mov    rbp,QWORD PTR [rsp+0x158]
   50eae:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50eb3:	mov    QWORD PTR [rsp+0x148],rbp
   50ebb:	mov    r14,QWORD PTR [rsp+0x128]
   50ec3:	mov    r13,QWORD PTR [rsp+0x150]
   50ecb:	mov    rbx,QWORD PTR [rsp+0x148]
   50ed3:	mov    rbp,QWORD PTR [rsp+0x158]
   50edb:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50ee0:	movzx  eax,WORD PTR [r13+0x14]
   50ee5:	and    eax,0xfffffffd
   50ee8:	mov    ebx,eax
   50eea:	jmp    50f8f <sqlite3VdbeExec+0x1aef>
   50eef:	mov    eax,ebx
   50ef1:	and    eax,0x400
   50ef6:	test   eax,eax
   50ef8:	je     50f8f <sqlite3VdbeExec+0x1aef>
   50efe:	mov    eax,DWORD PTR [r13+0x10]
   50f02:	add    eax,DWORD PTR [r13+0x0]
   50f06:	test   eax,eax
   50f08:	jg     50f1b <sqlite3VdbeExec+0x1a7b>
   50f0a:	movzx  eax,WORD PTR [r13+0x14]
   50f0f:	and    eax,0x10
   50f12:	test   eax,eax
   50f14:	je     50f85 <sqlite3VdbeExec+0x1ae5>
   50f16:	mov    eax,0x1
   50f1b:	mov    ecx,0x1
   50f20:	mov    QWORD PTR [rsp+0x110],rdi
   50f28:	mov    rdi,r13
   50f2b:	mov    rsi,rax
   50f2e:	mov    rdx,rcx
   50f31:	call   50f36 <sqlite3VdbeExec+0x1a96>
   50f36:	mov    rdi,QWORD PTR [rsp+0x110]
   50f3e:	test   eax,eax
   50f40:	jne    51017 <sqlite3VdbeExec+0x1b77>
   50f46:	mov    rax,QWORD PTR [r13+0x8]
   50f4a:	movsxd rcx,DWORD PTR [r13+0x10]
   50f4e:	add    rax,rcx
   50f51:	xor    ecx,ecx
   50f53:	movsxd rdx,DWORD PTR [r13+0x0]
   50f57:	mov    rdi,rax
   50f5a:	mov    rsi,rcx
   50f5d:	call   50f62 <sqlite3VdbeExec+0x1ac2>
   50f62:	mov    eax,DWORD PTR [r13+0x10]
   50f66:	add    eax,DWORD PTR [r13+0x0]
   50f6a:	mov    DWORD PTR [r13+0x10],eax
   50f6e:	movzx  eax,WORD PTR [r13+0x14]
   50f73:	and    eax,0xfffff9ff
   50f78:	mov    WORD PTR [r13+0x14],ax
   50f7d:	mov    rdi,QWORD PTR [rsp+0x110]
   50f85:	movzx  eax,WORD PTR [r13+0x14]
   50f8a:	and    eax,0xfffffffd
   50f8d:	mov    ebx,eax
   50f8f:	movsxd rax,DWORD PTR [r12+0x10]
   50f94:	movsxd rcx,DWORD PTR [r13+0x10]
   50f98:	mov    DWORD PTR [rsp+0x39c],ebx
   50f9f:	lea    rbx,[rax+rcx*1]
   50fa3:	mov    QWORD PTR [rsp+0x168],r12
   50fab:	mov    r12,QWORD PTR [rsp+0x128]
   50fb3:	movsxd rax,DWORD PTR [r12+0x88]
   50fbb:	cmp    rbx,rax
   50fbe:	jle    50fc8 <sqlite3VdbeExec+0x1b28>
   50fc0:	mov    rbp,r12
   50fc3:	jmp    53cbc <sqlite3VdbeExec+0x481c>
   50fc8:	mov    eax,ebx
   50fca:	add    eax,0x2
   50fcd:	xor    ecx,ecx
   50fcf:	cmp    r15,r13
   50fd2:	sete   cl
   50fd5:	mov    QWORD PTR [rsp+0x110],rdi
   50fdd:	mov    rdi,r15
   50fe0:	mov    rsi,rax
   50fe3:	mov    rdx,rcx
   50fe6:	call   50feb <sqlite3VdbeExec+0x1b4b>
   50feb:	mov    rdi,QWORD PTR [rsp+0x110]
   50ff3:	test   eax,eax
   50ff5:	je     5103f <sqlite3VdbeExec+0x1b9f>
   50ff7:	mov    r14,r12
   50ffa:	mov    r13,QWORD PTR [rsp+0x150]
   51002:	mov    rbx,QWORD PTR [rsp+0x148]
   5100a:	mov    rbp,QWORD PTR [rsp+0x158]
   51012:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   51017:	mov    r12,QWORD PTR [rsp+0x128]
   5101f:	mov    r14,r12
   51022:	mov    r13,QWORD PTR [rsp+0x150]
   5102a:	mov    rbx,QWORD PTR [rsp+0x148]
   51032:	mov    rbp,QWORD PTR [rsp+0x158]
   5103a:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5103f:	movzx  eax,WORD PTR [r15+0x14]
   51044:	and    eax,0xfffff240
   51049:	or     eax,0x2
   5104c:	mov    WORD PTR [r15+0x14],ax
   51051:	cmp    r15,r13
   51054:	jne    51060 <sqlite3VdbeExec+0x1bc0>
   51056:	mov    QWORD PTR [rsp+0x160],rbp
   5105e:	jmp    51093 <sqlite3VdbeExec+0x1bf3>
   51060:	mov    rax,QWORD PTR [r15+0x8]
   51064:	mov    rcx,QWORD PTR [r13+0x8]
   51068:	movsxd rdx,DWORD PTR [r13+0x10]
   5106c:	mov    rdi,rax
   5106f:	mov    rsi,rcx
   51072:	call   51077 <sqlite3VdbeExec+0x1bd7>
   51077:	mov    QWORD PTR [rsp+0x160],rbp
   5107f:	mov    ebp,DWORD PTR [rsp+0x39c]
   51086:	mov    WORD PTR [r13+0x14],bp
   5108b:	mov    rdi,QWORD PTR [rsp+0x110]
   51093:	mov    rax,QWORD PTR [r15+0x8]
   51097:	movsxd rcx,DWORD PTR [r13+0x10]
   5109b:	add    rax,rcx
   5109e:	mov    rbp,QWORD PTR [rsp+0x168]
   510a6:	mov    rcx,QWORD PTR [rbp+0x8]
   510aa:	movsxd rdx,DWORD PTR [rbp+0x10]
   510ae:	mov    QWORD PTR [rsp+0x110],rdi
   510b6:	mov    rdi,rax
   510b9:	mov    rsi,rcx
   510bc:	call   510c1 <sqlite3VdbeExec+0x1c21>
   510c1:	mov    r13d,DWORD PTR [rsp+0x398]
   510c9:	mov    WORD PTR [rbp+0x14],r13w
   510ce:	mov    eax,r14d
   510d1:	mov    rdi,QWORD PTR [rsp+0x110]
   510d9:	cmp    eax,0x1
   510dc:	jg     510e8 <sqlite3VdbeExec+0x1c48>
   510de:	mov    rbp,QWORD PTR [rsp+0x148]
   510e6:	jmp    510f4 <sqlite3VdbeExec+0x1c54>
   510e8:	and    rbx,0xfffffffffffffffe
   510ec:	mov    rbp,QWORD PTR [rsp+0x148]
   510f4:	mov    rax,QWORD PTR [r15+0x8]
   510f8:	mov    BYTE PTR [rax+rbx*1],0x0
   510fc:	mov    rax,QWORD PTR [r15+0x8]
   51100:	mov    BYTE PTR [rax+rbx*1+0x1],0x0
   51105:	movzx  eax,WORD PTR [r15+0x14]
   5110a:	or     eax,0x200
   5110f:	mov    WORD PTR [r15+0x14],ax
   51114:	mov    DWORD PTR [r15+0x10],ebx
   51118:	mov    BYTE PTR [r15+0x16],r14b
   5111c:	mov    DWORD PTR [rsp+0x37c],r14d
   51124:	mov    r14,r12
   51127:	mov    rbx,QWORD PTR [rsp+0x160]
   5112f:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   51134:	mov    QWORD PTR [rsp+0x160],rbx
   5113c:	mov    QWORD PTR [rsp+0x130],r12
   51144:	mov    r12,r14
   51147:	mov    r14d,DWORD PTR [rsp+0x37c]
   5114f:	movsxd rax,DWORD PTR [rbp+0x4]
   51153:	imul   rax,rax,0x38
   51157:	mov    rbx,QWORD PTR [rsp+0x160]
   5115f:	lea    r13,[rbx+rax*1]
   51163:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51168:	movsxd rcx,DWORD PTR [rbp+0x8]
   5116c:	imul   rcx,rcx,0x38
   51170:	lea    r15,[rbx+rcx*1]
   51174:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   51179:	movsxd rdx,DWORD PTR [rbp+0xc]
   5117d:	imul   rdx,rdx,0x38
   51181:	mov    DWORD PTR [rsp+0x37c],r14d
   51189:	lea    r14,[rbx+rdx*1]
   5118d:	mov    edx,eax
   5118f:	mov    esi,ecx
   51191:	and    edx,esi
   51193:	and    edx,0x4
   51196:	test   edx,edx
   51198:	je     51449 <sqlite3VdbeExec+0x1fa9>
   5119e:	mov    rcx,QWORD PTR [r13+0x0]
   511a2:	mov    rax,QWORD PTR [r15]
   511a5:	mov    QWORD PTR [rsp+0x170],rax
   511ad:	movzx  eax,BYTE PTR [rbp+0x0]
   511b1:	mov    edx,eax
   511b3:	sub    edx,0x6b
   511b6:	cmp    edx,0x3
   511b9:	jbe    511c8 <sqlite3VdbeExec+0x1d28>
   511bb:	mov    QWORD PTR [rsp+0x168],r14
   511c3:	jmp    513f2 <sqlite3VdbeExec+0x1f52>
   511c8:	sub    eax,0x6b
   511cb:	mov    QWORD PTR [rsp+0x168],r14
   511d3:	lea    r14,[rip+0x0]        # 511da <sqlite3VdbeExec+0x1d3a>
   511da:	movsxd rax,DWORD PTR [r14+rax*4]
   511de:	add    rax,r14
   511e1:	jmp    rax
   511e3:	mov    rax,QWORD PTR [rsp+0x170]
   511eb:	test   rcx,rcx
   511ee:	jl     51222 <sqlite3VdbeExec+0x1d82>
   511f0:	test   rax,rax
   511f3:	jle    51240 <sqlite3VdbeExec+0x1da0>
   511f5:	movabs rdx,0x7fffffffffffffff
   511ff:	sub    rdx,rax
   51202:	cmp    rdx,rcx
   51205:	jge    51240 <sqlite3VdbeExec+0x1da0>
   51207:	movzx  eax,WORD PTR [r13+0x14]
   5120c:	and    eax,0x8
   5120f:	test   eax,eax
   51211:	je     5152e <sqlite3VdbeExec+0x208e>
   51217:	movsd  xmm0,QWORD PTR [r13+0x0]
   5121d:	jmp    515b1 <sqlite3VdbeExec+0x2111>
   51222:	test   rax,rax
   51225:	jge    51240 <sqlite3VdbeExec+0x1da0>
   51227:	movabs rdx,0x7fffffffffffffff
   51231:	add    rax,rdx
   51234:	neg    rax
   51237:	lea    rdx,[rcx+0x1]
   5123b:	cmp    rax,rdx
   5123e:	jg     51207 <sqlite3VdbeExec+0x1d67>
   51240:	mov    rax,QWORD PTR [rsp+0x170]
   51248:	add    rax,rcx
   5124b:	mov    QWORD PTR [rsp+0x170],rax
   51253:	jmp    5141e <sqlite3VdbeExec+0x1f7e>
   51258:	movabs rax,0x8000000000000000
   51262:	cmp    rcx,rax
   51265:	jne    5128a <sqlite3VdbeExec+0x1dea>
   51267:	cmp    QWORD PTR [rsp+0x170],0x0
   51270:	jge    51207 <sqlite3VdbeExec+0x1d67>
   51272:	mov    rax,QWORD PTR [rsp+0x170]
   5127a:	sub    rax,rcx
   5127d:	mov    QWORD PTR [rsp+0x170],rax
   51285:	jmp    5141e <sqlite3VdbeExec+0x1f7e>
   5128a:	neg    rcx
   5128d:	mov    rax,QWORD PTR [rsp+0x170]
   51295:	test   rcx,rcx
   51298:	jl     512ca <sqlite3VdbeExec+0x1e2a>
   5129a:	test   rax,rax
   5129d:	jle    512b5 <sqlite3VdbeExec+0x1e15>
   5129f:	movabs rdx,0x7fffffffffffffff
   512a9:	sub    rdx,rax
   512ac:	cmp    rdx,rcx
   512af:	jl     51207 <sqlite3VdbeExec+0x1d67>
   512b5:	add    rcx,QWORD PTR [rsp+0x170]
   512bd:	mov    QWORD PTR [rsp+0x170],rcx
   512c5:	jmp    5141e <sqlite3VdbeExec+0x1f7e>
   512ca:	test   rax,rax
   512cd:	jge    512b5 <sqlite3VdbeExec+0x1e15>
   512cf:	movabs rdx,0x7fffffffffffffff
   512d9:	add    rax,rdx
   512dc:	neg    rax
   512df:	lea    rdx,[rcx+0x1]
   512e3:	cmp    rax,rdx
   512e6:	jg     51207 <sqlite3VdbeExec+0x1d67>
   512ec:	jmp    512b5 <sqlite3VdbeExec+0x1e15>
   512ee:	mov    rsi,QWORD PTR [rsp+0x170]
   512f6:	test   rcx,rcx
   512f9:	jle    5133c <sqlite3VdbeExec+0x1e9c>
   512fb:	movabs rax,0x7fffffffffffffff
   51305:	cqo
   51307:	idiv   rcx
   5130a:	cmp    rsi,rax
   5130d:	jg     51207 <sqlite3VdbeExec+0x1d67>
   51313:	movabs rax,0x8000000000000000
   5131d:	cqo
   5131f:	idiv   rcx
   51322:	cmp    rsi,rax
   51325:	jl     51207 <sqlite3VdbeExec+0x1d67>
   5132b:	imul   rsi,rcx
   5132f:	mov    QWORD PTR [rsp+0x170],rsi
   51337:	jmp    5141e <sqlite3VdbeExec+0x1f7e>
   5133c:	test   rcx,rcx
   5133f:	jge    5132b <sqlite3VdbeExec+0x1e8b>
   51341:	test   rsi,rsi
   51344:	jle    51360 <sqlite3VdbeExec+0x1ec0>
   51346:	movabs rax,0x8000000000000000
   51350:	cqo
   51352:	idiv   rsi
   51355:	cmp    rcx,rax
   51358:	jl     51207 <sqlite3VdbeExec+0x1d67>
   5135e:	jmp    5132b <sqlite3VdbeExec+0x1e8b>
   51360:	test   rsi,rsi
   51363:	jge    5132b <sqlite3VdbeExec+0x1e8b>
   51365:	movabs rax,0x8000000000000000
   5136f:	cmp    rcx,rax
   51372:	je     51207 <sqlite3VdbeExec+0x1d67>
   51378:	movabs rax,0x8000000000000000
   51382:	cmp    rsi,rax
   51385:	je     51207 <sqlite3VdbeExec+0x1d67>
   5138b:	mov    r8,rsi
   5138e:	neg    r8
   51391:	movabs rax,0x7fffffffffffffff
   5139b:	mov    r9,rcx
   5139e:	neg    r9
   513a1:	cqo
   513a3:	idiv   r9
   513a6:	cmp    r8,rax
   513a9:	jg     51207 <sqlite3VdbeExec+0x1d67>
   513af:	jmp    5132b <sqlite3VdbeExec+0x1e8b>
   513b4:	test   rcx,rcx
   513b7:	je     51876 <sqlite3VdbeExec+0x23d6>
   513bd:	cmp    rcx,0xffffffffffffffff
   513c1:	jne    513db <sqlite3VdbeExec+0x1f3b>
   513c3:	movabs rax,0x8000000000000000
   513cd:	cmp    rax,QWORD PTR [rsp+0x170]
   513d5:	je     51207 <sqlite3VdbeExec+0x1d67>
   513db:	mov    rax,QWORD PTR [rsp+0x170]
   513e3:	cqo
   513e5:	idiv   rcx
   513e8:	mov    QWORD PTR [rsp+0x170],rax
   513f0:	jmp    5141e <sqlite3VdbeExec+0x1f7e>
   513f2:	test   rcx,rcx
   513f5:	je     51876 <sqlite3VdbeExec+0x23d6>
   513fb:	cmp    rcx,0xffffffffffffffff
   513ff:	jne    51406 <sqlite3VdbeExec+0x1f66>
   51401:	mov    ecx,0x1
   51406:	mov    rax,QWORD PTR [rsp+0x170]
   5140e:	cqo
   51410:	idiv   rcx
   51413:	mov    rax,rdx
   51416:	mov    QWORD PTR [rsp+0x170],rax
   5141e:	mov    rax,QWORD PTR [rsp+0x170]
   51426:	mov    r13,QWORD PTR [rsp+0x168]
   5142e:	mov    QWORD PTR [r13+0x0],rax
   51432:	movzx  eax,WORD PTR [r13+0x14]
   51437:	and    eax,0xfffff240
   5143c:	or     eax,0x4
   5143f:	mov    WORD PTR [r13+0x14],ax
   51444:	jmp    5186e <sqlite3VdbeExec+0x23ce>
   51449:	mov    QWORD PTR [rsp+0x168],r14
   51451:	or     eax,ecx
   51453:	and    eax,0x1
   51456:	test   eax,eax
   51458:	jne    51876 <sqlite3VdbeExec+0x23d6>
   5145e:	movzx  eax,WORD PTR [r13+0x14]
   51463:	and    eax,0x2d
   51466:	test   eax,eax
   51468:	je     51477 <sqlite3VdbeExec+0x1fd7>
   5146a:	movzx  eax,WORD PTR [r13+0x14]
   5146f:	and    eax,0x2d
   51472:	mov    r14d,eax
   51475:	jmp    51493 <sqlite3VdbeExec+0x1ff3>
   51477:	mov    QWORD PTR [rsp+0x110],rdi
   5147f:	mov    rdi,r13
   51482:	call   51487 <sqlite3VdbeExec+0x1fe7>
   51487:	movzx  r14d,ax
   5148b:	mov    rdi,QWORD PTR [rsp+0x110]
   51493:	movzx  eax,WORD PTR [r15+0x14]
   51498:	and    eax,0x2d
   5149b:	test   eax,eax
   5149d:	je     514bc <sqlite3VdbeExec+0x201c>
   5149f:	movzx  eax,WORD PTR [r15+0x14]
   514a4:	and    eax,0x2d
   514a7:	mov    QWORD PTR [rsp+0x160],rbx
   514af:	mov    rbx,r14
   514b2:	mov    r14d,DWORD PTR [rsp+0x37c]
   514ba:	jmp    514ea <sqlite3VdbeExec+0x204a>
   514bc:	mov    QWORD PTR [rsp+0x110],rdi
   514c4:	mov    rdi,r15
   514c7:	call   514cc <sqlite3VdbeExec+0x202c>
   514cc:	movzx  eax,ax
   514cf:	mov    rdi,QWORD PTR [rsp+0x110]
   514d7:	mov    QWORD PTR [rsp+0x160],rbx
   514df:	mov    rbx,r14
   514e2:	mov    r14d,DWORD PTR [rsp+0x37c]
   514ea:	mov    ecx,ebx
   514ec:	and    ecx,eax
   514ee:	and    ecx,0x4
   514f1:	test   ecx,ecx
   514f3:	jne    51511 <sqlite3VdbeExec+0x2071>
   514f5:	mov    DWORD PTR [rsp+0x37c],r14d
   514fd:	mov    rbx,QWORD PTR [rsp+0x160]
   51505:	lea    r14,[rip+0x0]        # 5150c <sqlite3VdbeExec+0x206c>
   5150c:	jmp    51207 <sqlite3VdbeExec+0x1d67>
   51511:	mov    DWORD PTR [rsp+0x37c],r14d
   51519:	mov    r14,QWORD PTR [rsp+0x168]
   51521:	mov    rbx,QWORD PTR [rsp+0x160]
   51529:	jmp    5119e <sqlite3VdbeExec+0x1cfe>
   5152e:	mov    r14d,DWORD PTR [rsp+0x37c]
   51536:	mov    QWORD PTR [rsp+0x160],rbx
   5153e:	movzx  eax,WORD PTR [r13+0x14]
   51543:	and    eax,0x24
   51546:	test   eax,eax
   51548:	je     51568 <sqlite3VdbeExec+0x20c8>
   5154a:	mov    rax,QWORD PTR [r13+0x0]
   5154e:	xorps  xmm0,xmm0
   51551:	cvtsi2sd xmm0,rax
   51556:	mov    DWORD PTR [rsp+0x37c],r14d
   5155e:	mov    rbx,QWORD PTR [rsp+0x160]
   51566:	jmp    515b1 <sqlite3VdbeExec+0x2111>
   51568:	movzx  eax,WORD PTR [r13+0x14]
   5156d:	and    eax,0x12
   51570:	test   eax,eax
   51572:	je     5159e <sqlite3VdbeExec+0x20fe>
   51574:	mov    QWORD PTR [rsp+0x110],rdi
   5157c:	mov    rdi,r13
   5157f:	call   51584 <sqlite3VdbeExec+0x20e4>
   51584:	mov    rdi,QWORD PTR [rsp+0x110]
   5158c:	mov    DWORD PTR [rsp+0x37c],r14d
   51594:	mov    rbx,QWORD PTR [rsp+0x160]
   5159c:	jmp    515b1 <sqlite3VdbeExec+0x2111>
   5159e:	xorps  xmm0,xmm0
   515a1:	mov    DWORD PTR [rsp+0x37c],r14d
   515a9:	mov    rbx,QWORD PTR [rsp+0x160]
   515b1:	movzx  eax,WORD PTR [r15+0x14]
   515b6:	and    eax,0x8
   515b9:	test   eax,eax
   515bb:	je     515c4 <sqlite3VdbeExec+0x2124>
   515bd:	movsd  xmm1,QWORD PTR [r15]
   515c2:	jmp    5161f <sqlite3VdbeExec+0x217f>
   515c4:	movzx  eax,WORD PTR [r15+0x14]
   515c9:	and    eax,0x24
   515cc:	test   eax,eax
   515ce:	je     515dd <sqlite3VdbeExec+0x213d>
   515d0:	mov    rax,QWORD PTR [r15]
   515d3:	xorps  xmm1,xmm1
   515d6:	cvtsi2sd xmm1,rax
   515db:	jmp    5161f <sqlite3VdbeExec+0x217f>
   515dd:	movzx  eax,WORD PTR [r15+0x14]
   515e2:	and    eax,0x12
   515e5:	test   eax,eax
   515e7:	je     5161c <sqlite3VdbeExec+0x217c>
   515e9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   515f4:	mov    QWORD PTR [rsp+0x110],rdi
   515fc:	mov    rdi,r15
   515ff:	call   51604 <sqlite3VdbeExec+0x2164>
   51604:	movaps xmm1,xmm0
   51607:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   51612:	mov    rdi,QWORD PTR [rsp+0x110]
   5161a:	jmp    5161f <sqlite3VdbeExec+0x217f>
   5161c:	xorps  xmm1,xmm1
   5161f:	movzx  eax,BYTE PTR [rbp+0x0]
   51623:	mov    ecx,eax
   51625:	sub    ecx,0x6b
   51628:	cmp    ecx,0x3
   5162b:	ja     51689 <sqlite3VdbeExec+0x21e9>
   5162d:	sub    eax,0x6b
   51630:	lea    r14,[rip+0x0]        # 51637 <sqlite3VdbeExec+0x2197>
   51637:	movsxd rax,DWORD PTR [r14+rax*4]
   5163b:	add    rax,r14
   5163e:	jmp    rax
   51640:	addsd  xmm1,xmm0
   51644:	jmp    517f2 <sqlite3VdbeExec+0x2352>
   51649:	subsd  xmm1,xmm0
   5164d:	jmp    517f2 <sqlite3VdbeExec+0x2352>
   51652:	mulsd  xmm1,xmm0
   51656:	jmp    517f2 <sqlite3VdbeExec+0x2352>
   5165b:	xorps  xmm2,xmm2
   5165e:	xor    eax,eax
   51660:	ucomisd xmm0,xmm2
   51664:	sete   al
   51667:	setnp  r11b
   5166b:	and    al,r11b
   5166e:	test   eax,eax
   51670:	mov    eax,0x0
   51675:	setne  al
   51678:	test   eax,eax
   5167a:	jne    51876 <sqlite3VdbeExec+0x23d6>
   51680:	divsd  xmm1,xmm0
   51684:	jmp    517f2 <sqlite3VdbeExec+0x2352>
   51689:	movzx  eax,WORD PTR [r13+0x14]
   5168e:	mov    ecx,eax
   51690:	and    ecx,0x24
   51693:	test   ecx,ecx
   51695:	je     516a0 <sqlite3VdbeExec+0x2200>
   51697:	mov    r13,QWORD PTR [r13+0x0]
   5169b:	jmp    51726 <sqlite3VdbeExec+0x2286>
   516a0:	mov    ecx,eax
   516a2:	and    ecx,0x8
   516a5:	test   ecx,ecx
   516a7:	je     516f8 <sqlite3VdbeExec+0x2258>
   516a9:	movsd  xmm1,QWORD PTR [r13+0x0]
   516af:	movabs r11,0xc3dfffffffffffff
   516b9:	movq   xmm0,r11
   516be:	ucomisd xmm0,xmm1
   516c2:	jbe    516d0 <sqlite3VdbeExec+0x2230>
   516c4:	movabs r13,0x8000000000000000
   516ce:	jmp    516f6 <sqlite3VdbeExec+0x2256>
   516d0:	movabs r11,0x43dfffffffffffff
   516da:	movq   xmm0,r11
   516df:	ucomisd xmm1,xmm0
   516e3:	jbe    516f1 <sqlite3VdbeExec+0x2251>
   516e5:	movabs r13,0x7fffffffffffffff
   516ef:	jmp    516f6 <sqlite3VdbeExec+0x2256>
   516f1:	cvttsd2si r13,xmm1
   516f6:	jmp    51726 <sqlite3VdbeExec+0x2286>
   516f8:	and    eax,0x12
   516fb:	test   eax,eax
   516fd:	je     51723 <sqlite3VdbeExec+0x2283>
   516ff:	cmp    QWORD PTR [r13+0x8],0x0
   51704:	je     51723 <sqlite3VdbeExec+0x2283>
   51706:	mov    QWORD PTR [rsp+0x110],rdi
   5170e:	mov    rdi,r13
   51711:	call   51716 <sqlite3VdbeExec+0x2276>
   51716:	mov    r13,rax
   51719:	mov    rdi,QWORD PTR [rsp+0x110]
   51721:	jmp    51726 <sqlite3VdbeExec+0x2286>
   51723:	xor    r13d,r13d
   51726:	movzx  eax,WORD PTR [r15+0x14]
   5172b:	mov    ecx,eax
   5172d:	and    ecx,0x24
   51730:	test   ecx,ecx
   51732:	je     5173c <sqlite3VdbeExec+0x229c>
   51734:	mov    rax,QWORD PTR [r15]
   51737:	jmp    517bd <sqlite3VdbeExec+0x231d>
   5173c:	mov    ecx,eax
   5173e:	and    ecx,0x8
   51741:	test   ecx,ecx
   51743:	je     51793 <sqlite3VdbeExec+0x22f3>
   51745:	movsd  xmm1,QWORD PTR [r15]
   5174a:	movabs r11,0xc3dfffffffffffff
   51754:	movq   xmm0,r11
   51759:	ucomisd xmm0,xmm1
   5175d:	jbe    5176b <sqlite3VdbeExec+0x22cb>
   5175f:	movabs rax,0x8000000000000000
   51769:	jmp    51791 <sqlite3VdbeExec+0x22f1>
   5176b:	movabs r11,0x43dfffffffffffff
   51775:	movq   xmm0,r11
   5177a:	ucomisd xmm1,xmm0
   5177e:	jbe    5178c <sqlite3VdbeExec+0x22ec>
   51780:	movabs rax,0x7fffffffffffffff
   5178a:	jmp    51791 <sqlite3VdbeExec+0x22f1>
   5178c:	cvttsd2si rax,xmm1
   51791:	jmp    517bd <sqlite3VdbeExec+0x231d>
   51793:	and    eax,0x12
   51796:	test   eax,eax
   51798:	je     517bb <sqlite3VdbeExec+0x231b>
   5179a:	cmp    QWORD PTR [r15+0x8],0x0
   5179f:	je     517bb <sqlite3VdbeExec+0x231b>
   517a1:	mov    QWORD PTR [rsp+0x110],rdi
   517a9:	mov    rdi,r15
   517ac:	call   517b1 <sqlite3VdbeExec+0x2311>
   517b1:	mov    rdi,QWORD PTR [rsp+0x110]
   517b9:	jmp    517bd <sqlite3VdbeExec+0x231d>
   517bb:	xor    eax,eax
   517bd:	mov    QWORD PTR [rsp+0x170],rax
   517c5:	test   r13,r13
   517c8:	je     51876 <sqlite3VdbeExec+0x23d6>
   517ce:	cmp    r13,0xffffffffffffffff
   517d2:	jne    517da <sqlite3VdbeExec+0x233a>
   517d4:	mov    r13d,0x1
   517da:	mov    rax,QWORD PTR [rsp+0x170]
   517e2:	cqo
   517e4:	idiv   r13
   517e7:	mov    rax,rdx
   517ea:	xorps  xmm1,xmm1
   517ed:	cvtsi2sd xmm1,rax
   517f2:	movsd  QWORD PTR [rsp+0x118],xmm1
   517fb:	mov    rax,QWORD PTR [rsp+0x118]
   51803:	mov    QWORD PTR [rsp+0x120],rax
   5180b:	mov    rax,QWORD PTR [rsp+0x120]
   51813:	movabs rcx,0x7ff0000000000000
   5181d:	and    rcx,rax
   51820:	movabs rdx,0x7ff0000000000000
   5182a:	movabs rsi,0xfffffffffffff
   51834:	and    rax,rsi
   51837:	test   rax,rax
   5183a:	mov    eax,0x0
   5183f:	setne  al
   51842:	xor    esi,esi
   51844:	cmp    rcx,rdx
   51847:	cmove  esi,eax
   5184a:	test   esi,esi
   5184c:	jne    51876 <sqlite3VdbeExec+0x23d6>
   5184e:	mov    r13,QWORD PTR [rsp+0x168]
   51856:	movsd  QWORD PTR [r13+0x0],xmm1
   5185c:	movzx  eax,WORD PTR [r13+0x14]
   51861:	and    eax,0xfffff240
   51866:	or     eax,0x8
   51869:	mov    WORD PTR [r13+0x14],ax
   5186e:	mov    r14,r12
   51871:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   51876:	mov    r13,QWORD PTR [rsp+0x168]
   5187e:	movzx  eax,WORD PTR [r13+0x14]
   51883:	and    eax,0x9000
   51888:	test   eax,eax
   5188a:	je     518a6 <sqlite3VdbeExec+0x2406>
   5188c:	mov    QWORD PTR [rsp+0x110],rdi
   51894:	mov    rdi,r13
   51897:	call   5189c <sqlite3VdbeExec+0x23fc>
   5189c:	mov    rdi,QWORD PTR [rsp+0x110]
   518a4:	jmp    518ad <sqlite3VdbeExec+0x240d>
   518a6:	mov    WORD PTR [r13+0x14],0x1
   518ad:	mov    r14,r12
   518b0:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   518b5:	mov    QWORD PTR [rsp+0x130],r12
   518bd:	mov    r12,r14
   518c0:	cmp    DWORD PTR [rbp+0x4],0x0
   518c4:	je     5190c <sqlite3VdbeExec+0x246c>
   518c6:	movsxd rax,DWORD PTR [rbp+0x4]
   518ca:	imul   rax,rax,0x38
   518ce:	lea    rcx,[rbx+rax*1]
   518d2:	xor    edx,edx
   518d4:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   518d9:	and    eax,0x9000
   518de:	test   eax,eax
   518e0:	je     518ff <sqlite3VdbeExec+0x245f>
   518e2:	mov    QWORD PTR [rsp+0x110],rdi
   518ea:	mov    rdi,rcx
   518ed:	mov    rsi,rdx
   518f0:	call   518f5 <sqlite3VdbeExec+0x2455>
   518f5:	mov    rdi,QWORD PTR [rsp+0x110]
   518fd:	jmp    5190c <sqlite3VdbeExec+0x246c>
   518ff:	mov    QWORD PTR [rcx],0x0
   51906:	mov    WORD PTR [rcx+0x14],0x4
   5190c:	mov    r14,r12
   5190f:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   51914:	mov    QWORD PTR [rsp+0x130],r12
   5191c:	mov    r12,r14
   5191f:	movsxd rax,DWORD PTR [rbp+0x4]
   51923:	imul   rax,rax,0x38
   51927:	lea    r13,[rbx+rax*1]
   5192b:	movsxd rcx,DWORD PTR [rbp+0x8]
   5192f:	imul   rcx,rcx,0x38
   51933:	lea    rdx,[rbx+rcx*1]
   51937:	movsxd rsi,DWORD PTR [rbp+0xc]
   5193b:	imul   rsi,rsi,0x38
   5193f:	lea    r15,[rbx+rsi*1]
   51943:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51948:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   5194d:	or     eax,ecx
   5194f:	and    eax,0x1
   51952:	test   eax,eax
   51954:	je     5198d <sqlite3VdbeExec+0x24ed>
   51956:	movzx  eax,WORD PTR [r15+0x14]
   5195b:	and    eax,0x9000
   51960:	test   eax,eax
   51962:	je     5197e <sqlite3VdbeExec+0x24de>
   51964:	mov    QWORD PTR [rsp+0x110],rdi
   5196c:	mov    rdi,r15
   5196f:	call   51974 <sqlite3VdbeExec+0x24d4>
   51974:	mov    rdi,QWORD PTR [rsp+0x110]
   5197c:	jmp    51985 <sqlite3VdbeExec+0x24e5>
   5197e:	mov    WORD PTR [r15+0x14],0x1
   51985:	mov    r14,r12
   51988:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5198d:	movzx  eax,WORD PTR [rdx+0x14]
   51991:	mov    ecx,eax
   51993:	and    ecx,0x24
   51996:	test   ecx,ecx
   51998:	je     519a2 <sqlite3VdbeExec+0x2502>
   5199a:	mov    rax,QWORD PTR [rdx]
   5199d:	jmp    51a22 <sqlite3VdbeExec+0x2582>
   519a2:	mov    ecx,eax
   519a4:	and    ecx,0x8
   519a7:	test   ecx,ecx
   519a9:	je     519f8 <sqlite3VdbeExec+0x2558>
   519ab:	movsd  xmm1,QWORD PTR [rdx]
   519af:	movabs r11,0xc3dfffffffffffff
   519b9:	movq   xmm0,r11
   519be:	ucomisd xmm0,xmm1
   519c2:	jbe    519d0 <sqlite3VdbeExec+0x2530>
   519c4:	movabs rax,0x8000000000000000
   519ce:	jmp    519f6 <sqlite3VdbeExec+0x2556>
   519d0:	movabs r11,0x43dfffffffffffff
   519da:	movq   xmm0,r11
   519df:	ucomisd xmm1,xmm0
   519e3:	jbe    519f1 <sqlite3VdbeExec+0x2551>
   519e5:	movabs rax,0x7fffffffffffffff
   519ef:	jmp    519f6 <sqlite3VdbeExec+0x2556>
   519f1:	cvttsd2si rax,xmm1
   519f6:	jmp    51a22 <sqlite3VdbeExec+0x2582>
   519f8:	and    eax,0x12
   519fb:	test   eax,eax
   519fd:	je     51a20 <sqlite3VdbeExec+0x2580>
   519ff:	cmp    QWORD PTR [rdx+0x8],0x0
   51a04:	je     51a20 <sqlite3VdbeExec+0x2580>
   51a06:	mov    QWORD PTR [rsp+0x110],rdi
   51a0e:	mov    rdi,rdx
   51a11:	call   51a16 <sqlite3VdbeExec+0x2576>
   51a16:	mov    rdi,QWORD PTR [rsp+0x110]
   51a1e:	jmp    51a22 <sqlite3VdbeExec+0x2582>
   51a20:	xor    eax,eax
   51a22:	mov    QWORD PTR [rsp+0x170],rax
   51a2a:	movzx  eax,WORD PTR [r13+0x14]
   51a2f:	mov    ecx,eax
   51a31:	and    ecx,0x24
   51a34:	test   ecx,ecx
   51a36:	je     51a41 <sqlite3VdbeExec+0x25a1>
   51a38:	mov    rax,QWORD PTR [r13+0x0]
   51a3c:	jmp    51ac3 <sqlite3VdbeExec+0x2623>
   51a41:	mov    ecx,eax
   51a43:	and    ecx,0x8
   51a46:	test   ecx,ecx
   51a48:	je     51a99 <sqlite3VdbeExec+0x25f9>
   51a4a:	movsd  xmm1,QWORD PTR [r13+0x0]
   51a50:	movabs r11,0xc3dfffffffffffff
   51a5a:	movq   xmm0,r11
   51a5f:	ucomisd xmm0,xmm1
   51a63:	jbe    51a71 <sqlite3VdbeExec+0x25d1>
   51a65:	movabs rax,0x8000000000000000
   51a6f:	jmp    51a97 <sqlite3VdbeExec+0x25f7>
   51a71:	movabs r11,0x43dfffffffffffff
   51a7b:	movq   xmm0,r11
   51a80:	ucomisd xmm1,xmm0
   51a84:	jbe    51a92 <sqlite3VdbeExec+0x25f2>
   51a86:	movabs rax,0x7fffffffffffffff
   51a90:	jmp    51a97 <sqlite3VdbeExec+0x25f7>
   51a92:	cvttsd2si rax,xmm1
   51a97:	jmp    51ac3 <sqlite3VdbeExec+0x2623>
   51a99:	and    eax,0x12
   51a9c:	test   eax,eax
   51a9e:	je     51ac1 <sqlite3VdbeExec+0x2621>
   51aa0:	cmp    QWORD PTR [r13+0x8],0x0
   51aa5:	je     51ac1 <sqlite3VdbeExec+0x2621>
   51aa7:	mov    QWORD PTR [rsp+0x110],rdi
   51aaf:	mov    rdi,r13
   51ab2:	call   51ab7 <sqlite3VdbeExec+0x2617>
   51ab7:	mov    rdi,QWORD PTR [rsp+0x110]
   51abf:	jmp    51ac3 <sqlite3VdbeExec+0x2623>
   51ac1:	xor    eax,eax
   51ac3:	movzx  ecx,BYTE PTR [rbp+0x0]
   51ac7:	mov    edx,ecx
   51ac9:	cmp    edx,0x67
   51acc:	jne    51ae3 <sqlite3VdbeExec+0x2643>
   51ace:	and    rax,QWORD PTR [rsp+0x170]
   51ad6:	mov    QWORD PTR [rsp+0x170],rax
   51ade:	jmp    51bdc <sqlite3VdbeExec+0x273c>
   51ae3:	mov    edx,ecx
   51ae5:	cmp    edx,0x68
   51ae8:	jne    51aff <sqlite3VdbeExec+0x265f>
   51aea:	or     rax,QWORD PTR [rsp+0x170]
   51af2:	mov    QWORD PTR [rsp+0x170],rax
   51afa:	jmp    51bdc <sqlite3VdbeExec+0x273c>
   51aff:	test   rax,rax
   51b02:	je     51bdc <sqlite3VdbeExec+0x273c>
   51b08:	test   rax,rax
   51b0b:	jge    51b2a <sqlite3VdbeExec+0x268a>
   51b0d:	mov    edx,0xd3
   51b12:	mov    r11d,ecx
   51b15:	mov    ecx,edx
   51b17:	sub    cl,r11b
   51b1a:	cmp    rax,0xffffffffffffffc0
   51b1e:	jle    51b25 <sqlite3VdbeExec+0x2685>
   51b20:	neg    rax
   51b23:	jmp    51b2a <sqlite3VdbeExec+0x268a>
   51b25:	mov    eax,0x40
   51b2a:	cmp    rax,0x40
   51b2e:	jl     51b58 <sqlite3VdbeExec+0x26b8>
   51b30:	cmp    QWORD PTR [rsp+0x170],0x0
   51b39:	jge    51b40 <sqlite3VdbeExec+0x26a0>
   51b3b:	cmp    ecx,0x69
   51b3e:	jne    51b44 <sqlite3VdbeExec+0x26a4>
   51b40:	xor    eax,eax
   51b42:	jmp    51b4b <sqlite3VdbeExec+0x26ab>
   51b44:	mov    rax,0xffffffffffffffff
   51b4b:	mov    QWORD PTR [rsp+0x170],rax
   51b53:	jmp    51bdc <sqlite3VdbeExec+0x273c>
   51b58:	mov    rdx,QWORD PTR [rsp+0x170]
   51b60:	mov    QWORD PTR [rsp+0x168],rdx
   51b68:	cmp    ecx,0x69
   51b6b:	jne    51b87 <sqlite3VdbeExec+0x26e7>
   51b6d:	mov    rdx,QWORD PTR [rsp+0x168]
   51b75:	mov    ecx,eax
   51b77:	mov    rax,rdx
   51b7a:	shl    rax,cl
   51b7d:	mov    QWORD PTR [rsp+0x168],rax
   51b85:	jmp    51bcc <sqlite3VdbeExec+0x272c>
   51b87:	mov    rdx,QWORD PTR [rsp+0x168]
   51b8f:	mov    ecx,eax
   51b91:	shr    rdx,cl
   51b94:	mov    QWORD PTR [rsp+0x168],rdx
   51b9c:	cmp    QWORD PTR [rsp+0x170],0x0
   51ba5:	jge    51bcc <sqlite3VdbeExec+0x272c>
   51ba7:	mov    rdx,0xffffffffffffffff
   51bae:	mov    ecx,0x40
   51bb3:	sub    rcx,rax
   51bb6:	mov    rax,rdx
   51bb9:	shl    rax,cl
   51bbc:	or     rax,QWORD PTR [rsp+0x168]
   51bc4:	mov    QWORD PTR [rsp+0x168],rax
   51bcc:	mov    rax,QWORD PTR [rsp+0x168]
   51bd4:	mov    QWORD PTR [rsp+0x170],rax
   51bdc:	mov    rax,QWORD PTR [rsp+0x170]
   51be4:	mov    QWORD PTR [r15],rax
   51be7:	movzx  eax,WORD PTR [r15+0x14]
   51bec:	and    eax,0xfffff240
   51bf1:	or     eax,0x4
   51bf4:	mov    WORD PTR [r15+0x14],ax
   51bf9:	mov    r14,r12
   51bfc:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   51c01:	mov    QWORD PTR [rsp+0x130],r12
   51c09:	mov    r12,r14
   51c0c:	movsxd rax,DWORD PTR [rbp+0x4]
   51c10:	imul   rax,rax,0x38
   51c14:	lea    r13,[rbx+rax*1]
   51c18:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51c1d:	mov    ecx,eax
   51c1f:	and    ecx,0x24
   51c22:	test   ecx,ecx
   51c24:	je     51c37 <sqlite3VdbeExec+0x2797>
   51c26:	mov    rax,QWORD PTR [r13+0x0]
   51c2a:	mov    r15d,DWORD PTR [rsp+0x37c]
   51c32:	jmp    51cd1 <sqlite3VdbeExec+0x2831>
   51c37:	mov    ecx,eax
   51c39:	and    ecx,0x8
   51c3c:	test   ecx,ecx
   51c3e:	je     51c97 <sqlite3VdbeExec+0x27f7>
   51c40:	movsd  xmm1,QWORD PTR [r13+0x0]
   51c46:	movabs r11,0xc3dfffffffffffff
   51c50:	movq   xmm0,r11
   51c55:	ucomisd xmm0,xmm1
   51c59:	jbe    51c67 <sqlite3VdbeExec+0x27c7>
   51c5b:	movabs rax,0x8000000000000000
   51c65:	jmp    51c8d <sqlite3VdbeExec+0x27ed>
   51c67:	movabs r11,0x43dfffffffffffff
   51c71:	movq   xmm0,r11
   51c76:	ucomisd xmm1,xmm0
   51c7a:	jbe    51c88 <sqlite3VdbeExec+0x27e8>
   51c7c:	movabs rax,0x7fffffffffffffff
   51c86:	jmp    51c8d <sqlite3VdbeExec+0x27ed>
   51c88:	cvttsd2si rax,xmm1
   51c8d:	mov    r15d,DWORD PTR [rsp+0x37c]
   51c95:	jmp    51cd1 <sqlite3VdbeExec+0x2831>
   51c97:	and    eax,0x12
   51c9a:	test   eax,eax
   51c9c:	je     51cc7 <sqlite3VdbeExec+0x2827>
   51c9e:	cmp    QWORD PTR [r13+0x8],0x0
   51ca3:	je     51cc7 <sqlite3VdbeExec+0x2827>
   51ca5:	mov    QWORD PTR [rsp+0x110],rdi
   51cad:	mov    rdi,r13
   51cb0:	call   51cb5 <sqlite3VdbeExec+0x2815>
   51cb5:	mov    rdi,QWORD PTR [rsp+0x110]
   51cbd:	mov    r15d,DWORD PTR [rsp+0x37c]
   51cc5:	jmp    51cd1 <sqlite3VdbeExec+0x2831>
   51cc7:	xor    eax,eax
   51cc9:	mov    r15d,DWORD PTR [rsp+0x37c]
   51cd1:	mov    QWORD PTR [r13+0x0],rax
   51cd5:	movzx  eax,WORD PTR [r13+0x14]
   51cda:	and    eax,0xfffff240
   51cdf:	or     eax,0x4
   51ce2:	mov    WORD PTR [r13+0x14],ax
   51ce7:	mov    rax,QWORD PTR [r13+0x0]
   51ceb:	movsxd rcx,DWORD PTR [rbp+0x8]
   51cef:	add    rax,rcx
   51cf2:	mov    QWORD PTR [r13+0x0],rax
   51cf6:	mov    r14,r12
   51cf9:	mov    DWORD PTR [rsp+0x37c],r15d
   51d01:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   51d06:	mov    r15d,DWORD PTR [rsp+0x37c]
   51d0e:	mov    QWORD PTR [rsp+0x130],r12
   51d16:	mov    r12,r14
   51d19:	movsxd rax,DWORD PTR [rbp+0x4]
   51d1d:	imul   rax,rax,0x38
   51d21:	lea    r13,[rbx+rax*1]
   51d25:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51d2a:	and    eax,0x4
   51d2d:	test   eax,eax
   51d2f:	jne    51dca <sqlite3VdbeExec+0x292a>
   51d35:	mov    eax,0x43
   51d3a:	mov    ecx,r15d
   51d3d:	mov    QWORD PTR [rsp+0x110],rdi
   51d45:	mov    rdi,r13
   51d48:	mov    rsi,rax
   51d4b:	mov    rdx,rcx
   51d4e:	call   51d53 <sqlite3VdbeExec+0x28b3>
   51d53:	movzx  eax,WORD PTR [r13+0x14]
   51d58:	and    eax,0x4
   51d5b:	mov    rdi,QWORD PTR [rsp+0x110]
   51d63:	test   eax,eax
   51d65:	jne    51dca <sqlite3VdbeExec+0x292a>
   51d67:	cmp    DWORD PTR [rbp+0x8],0x0
   51d6b:	jne    51d95 <sqlite3VdbeExec+0x28f5>
   51d6d:	mov    ebx,0x14
   51d72:	mov    r14,r12
   51d75:	mov    QWORD PTR [rsp+0x148],rbp
   51d7d:	mov    rbp,rbx
   51d80:	mov    r13,QWORD PTR [rsp+0x130]
   51d88:	mov    rbx,QWORD PTR [rsp+0x158]
   51d90:	jmp    4f712 <sqlite3VdbeExec+0x272>
   51d95:	mov    eax,DWORD PTR [rbp+0x8]
   51d98:	sub    eax,0x1
   51d9b:	movsxd rax,eax
   51d9e:	imul   rax,rax,0x18
   51da2:	mov    rbp,QWORD PTR [rsp+0x150]
   51daa:	lea    r14,[rbp+rax*1+0x0]
   51daf:	mov    DWORD PTR [rsp+0x37c],r15d
   51db7:	mov    QWORD PTR [rsp+0x150],rbp
   51dbf:	mov    rbp,r14
   51dc2:	mov    r14,r12
   51dc5:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   51dca:	movzx  eax,WORD PTR [r13+0x14]
   51dcf:	and    eax,0xfffff240
   51dd4:	or     eax,0x4
   51dd7:	mov    WORD PTR [r13+0x14],ax
   51ddc:	mov    r14,r12
   51ddf:	mov    DWORD PTR [rsp+0x37c],r15d
   51de7:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   51dec:	mov    r15d,DWORD PTR [rsp+0x37c]
   51df4:	mov    QWORD PTR [rsp+0x130],r12
   51dfc:	mov    r12,r14
   51dff:	movsxd rax,DWORD PTR [rbp+0x4]
   51e03:	imul   rax,rax,0x38
   51e07:	lea    r13,[rbx+rax*1]
   51e0b:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51e10:	and    eax,0x24
   51e13:	test   eax,eax
   51e15:	je     51e89 <sqlite3VdbeExec+0x29e9>
   51e17:	movzx  eax,WORD PTR [r13+0x14]
   51e1c:	and    eax,0x8
   51e1f:	test   eax,eax
   51e21:	je     51e2b <sqlite3VdbeExec+0x298b>
   51e23:	movsd  xmm1,QWORD PTR [r13+0x0]
   51e29:	jmp    51e71 <sqlite3VdbeExec+0x29d1>
   51e2b:	movzx  eax,WORD PTR [r13+0x14]
   51e30:	and    eax,0x24
   51e33:	test   eax,eax
   51e35:	je     51e45 <sqlite3VdbeExec+0x29a5>
   51e37:	mov    rax,QWORD PTR [r13+0x0]
   51e3b:	xorps  xmm1,xmm1
   51e3e:	cvtsi2sd xmm1,rax
   51e43:	jmp    51e71 <sqlite3VdbeExec+0x29d1>
   51e45:	movzx  eax,WORD PTR [r13+0x14]
   51e4a:	and    eax,0x12
   51e4d:	test   eax,eax
   51e4f:	je     51e6e <sqlite3VdbeExec+0x29ce>
   51e51:	mov    QWORD PTR [rsp+0x110],rdi
   51e59:	mov    rdi,r13
   51e5c:	call   51e61 <sqlite3VdbeExec+0x29c1>
   51e61:	movaps xmm1,xmm0
   51e64:	mov    rdi,QWORD PTR [rsp+0x110]
   51e6c:	jmp    51e71 <sqlite3VdbeExec+0x29d1>
   51e6e:	xorps  xmm1,xmm1
   51e71:	movsd  QWORD PTR [r13+0x0],xmm1
   51e77:	movzx  eax,WORD PTR [r13+0x14]
   51e7c:	and    eax,0xfffff240
   51e81:	or     eax,0x8
   51e84:	mov    WORD PTR [r13+0x14],ax
   51e89:	mov    r14,r12
   51e8c:	mov    DWORD PTR [rsp+0x37c],r15d
   51e94:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   51e99:	mov    r15d,DWORD PTR [rsp+0x37c]
   51ea1:	mov    QWORD PTR [rsp+0x130],r12
   51ea9:	mov    r12,r14
   51eac:	movsxd rax,DWORD PTR [rbp+0x4]
   51eb0:	imul   rax,rax,0x38
   51eb4:	lea    r13,[rbx+rax*1]
   51eb8:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   51ebd:	and    eax,0x400
   51ec2:	test   eax,eax
   51ec4:	je     51f5f <sqlite3VdbeExec+0x2abf>
   51eca:	mov    eax,DWORD PTR [r13+0x10]
   51ece:	add    eax,DWORD PTR [r13+0x0]
   51ed2:	test   eax,eax
   51ed4:	jg     51eec <sqlite3VdbeExec+0x2a4c>
   51ed6:	movzx  eax,WORD PTR [r13+0x14]
   51edb:	and    eax,0x10
   51ede:	test   eax,eax
   51ee0:	jne    51ee7 <sqlite3VdbeExec+0x2a47>
   51ee2:	xor    r14d,r14d
   51ee5:	jmp    51f5d <sqlite3VdbeExec+0x2abd>
   51ee7:	mov    eax,0x1
   51eec:	mov    ecx,0x1
   51ef1:	mov    QWORD PTR [rsp+0x110],rdi
   51ef9:	mov    rdi,r13
   51efc:	mov    rsi,rax
   51eff:	mov    rdx,rcx
   51f02:	call   51f07 <sqlite3VdbeExec+0x2a67>
   51f07:	mov    rdi,QWORD PTR [rsp+0x110]
   51f0f:	test   eax,eax
   51f11:	je     51f1b <sqlite3VdbeExec+0x2a7b>
   51f13:	mov    r14d,0x7
   51f19:	jmp    51f5d <sqlite3VdbeExec+0x2abd>
   51f1b:	mov    rax,QWORD PTR [r13+0x8]
   51f1f:	movsxd rcx,DWORD PTR [r13+0x10]
   51f23:	add    rax,rcx
   51f26:	xor    ecx,ecx
   51f28:	movsxd rdx,DWORD PTR [r13+0x0]
   51f2c:	mov    rdi,rax
   51f2f:	mov    rsi,rcx
   51f32:	call   51f37 <sqlite3VdbeExec+0x2a97>
   51f37:	mov    eax,DWORD PTR [r13+0x10]
   51f3b:	add    eax,DWORD PTR [r13+0x0]
   51f3f:	mov    DWORD PTR [r13+0x10],eax
   51f43:	movzx  eax,WORD PTR [r13+0x14]
   51f48:	and    eax,0xfffff9ff
   51f4d:	mov    WORD PTR [r13+0x14],ax
   51f52:	xor    r14d,r14d
   51f55:	mov    rdi,QWORD PTR [rsp+0x110]
   51f5d:	jmp    51f62 <sqlite3VdbeExec+0x2ac2>
   51f5f:	xor    r14d,r14d
   51f62:	test   r14d,r14d
   51f65:	je     51f8a <sqlite3VdbeExec+0x2aea>
   51f67:	mov    QWORD PTR [rsp+0x148],rbp
   51f6f:	mov    rbp,r14
   51f72:	mov    r14,r12
   51f75:	mov    r13,QWORD PTR [rsp+0x130]
   51f7d:	mov    rbx,QWORD PTR [rsp+0x158]
   51f85:	jmp    4f712 <sqlite3VdbeExec+0x272>
   51f8a:	mov    eax,DWORD PTR [rbp+0x8]
   51f8d:	movzx  eax,al
   51f90:	mov    ecx,r15d
   51f93:	mov    QWORD PTR [rsp+0x110],rdi
   51f9b:	mov    rdi,r13
   51f9e:	mov    rsi,rax
   51fa1:	mov    rdx,rcx
   51fa4:	call   51fa9 <sqlite3VdbeExec+0x2b09>
   51fa9:	mov    r13d,eax
   51fac:	mov    rdi,QWORD PTR [rsp+0x110]
   51fb4:	test   r13d,r13d
   51fb7:	je     51fdc <sqlite3VdbeExec+0x2b3c>
   51fb9:	mov    r14,r12
   51fbc:	mov    QWORD PTR [rsp+0x148],rbp
   51fc4:	mov    rbp,r13
   51fc7:	mov    r13,QWORD PTR [rsp+0x130]
   51fcf:	mov    rbx,QWORD PTR [rsp+0x158]
   51fd7:	jmp    4f712 <sqlite3VdbeExec+0x272>
   51fdc:	mov    r14,r12
   51fdf:	mov    DWORD PTR [rsp+0x37c],r15d
   51fe7:	mov    DWORD PTR [rsp+0x38c],r13d
   51fef:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   51ff4:	mov    r15d,DWORD PTR [rsp+0x37c]
   51ffc:	mov    r13,QWORD PTR [rsp+0x150]
   52004:	mov    QWORD PTR [rsp+0x130],r12
   5200c:	mov    r12d,DWORD PTR [rsp+0x394]
   52014:	movsxd rax,DWORD PTR [rbp+0x4]
   52018:	imul   rax,rax,0x38
   5201c:	mov    DWORD PTR [rsp+0x394],r12d
   52024:	lea    r12,[rbx+rax*1]
   52028:	movsxd rcx,DWORD PTR [rbp+0xc]
   5202c:	imul   rcx,rcx,0x38
   52030:	mov    QWORD PTR [rsp+0x150],r13
   52038:	lea    r13,[rbx+rcx*1]
   5203c:	mov    DWORD PTR [rsp+0x37c],r15d
   52044:	movzx  r15d,WORD PTR [rbx+rax*1+0x14]
   5204a:	mov    QWORD PTR [rsp+0x160],rbx
   52052:	movzx  ebx,WORD PTR [rbx+rcx*1+0x14]
   52057:	mov    eax,r15d
   5205a:	mov    ecx,ebx
   5205c:	and    eax,ecx
   5205e:	and    eax,0x4
   52061:	test   eax,eax
   52063:	je     5211c <sqlite3VdbeExec+0x2c7c>
   52069:	mov    rax,QWORD PTR [r13+0x0]
   5206d:	cmp    rax,QWORD PTR [r12]
   52071:	jle    520a3 <sqlite3VdbeExec+0x2c03>
   52073:	mov    rax,QWORD PTR [rip+0x0]        # 5207a <sqlite3VdbeExec+0x2bda>
   5207a:	movzx  ecx,BYTE PTR [rbp+0x0]
   5207e:	cmp    BYTE PTR [rax+rcx*1],0x0
   52082:	je     5209c <sqlite3VdbeExec+0x2bfc>
   52084:	mov    r12,r14
   52087:	mov    r15d,DWORD PTR [rsp+0x37c]
   5208f:	mov    rbx,QWORD PTR [rsp+0x160]
   52097:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   5209c:	mov    ebx,0x1
   520a1:	jmp    52108 <sqlite3VdbeExec+0x2c68>
   520a3:	mov    rax,QWORD PTR [r13+0x0]
   520a7:	cmp    rax,QWORD PTR [r12]
   520ab:	jge    520dd <sqlite3VdbeExec+0x2c3d>
   520ad:	mov    rax,QWORD PTR [rip+0x0]        # 520b4 <sqlite3VdbeExec+0x2c14>
   520b4:	movzx  ecx,BYTE PTR [rbp+0x0]
   520b8:	cmp    BYTE PTR [rax+rcx*1],0x0
   520bc:	je     520d6 <sqlite3VdbeExec+0x2c36>
   520be:	mov    r12,r14
   520c1:	mov    r15d,DWORD PTR [rsp+0x37c]
   520c9:	mov    rbx,QWORD PTR [rsp+0x160]
   520d1:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   520d6:	mov    ebx,0xffffffff
   520db:	jmp    52108 <sqlite3VdbeExec+0x2c68>
   520dd:	mov    rax,QWORD PTR [rip+0x0]        # 520e4 <sqlite3VdbeExec+0x2c44>
   520e4:	movzx  ecx,BYTE PTR [rbp+0x0]
   520e8:	cmp    BYTE PTR [rax+rcx*1],0x0
   520ec:	je     52106 <sqlite3VdbeExec+0x2c66>
   520ee:	mov    r12,r14
   520f1:	mov    r15d,DWORD PTR [rsp+0x37c]
   520f9:	mov    rbx,QWORD PTR [rsp+0x160]
   52101:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   52106:	xor    ebx,ebx
   52108:	mov    DWORD PTR [rsp+0x390],ebx
   5210f:	mov    rbx,QWORD PTR [rsp+0x160]
   52117:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5211c:	mov    eax,r15d
   5211f:	mov    ecx,ebx
   52121:	or     eax,ecx
   52123:	and    eax,0x1
   52126:	test   eax,eax
   52128:	je     521d7 <sqlite3VdbeExec+0x2d37>
   5212e:	movzx  eax,WORD PTR [rbp+0x2]
   52132:	and    eax,0x80
   52137:	test   eax,eax
   52139:	je     5219b <sqlite3VdbeExec+0x2cfb>
   5213b:	mov    eax,r15d
   5213e:	mov    ecx,ebx
   52140:	and    eax,ecx
   52142:	and    eax,0x1
   52145:	test   eax,eax
   52147:	je     52161 <sqlite3VdbeExec+0x2cc1>
   52149:	mov    eax,ebx
   5214b:	and    eax,0x100
   52150:	test   eax,eax
   52152:	jne    52161 <sqlite3VdbeExec+0x2cc1>
   52154:	xor    r11d,r11d
   52157:	mov    DWORD PTR [rsp+0x390],r11d
   5215f:	jmp    52188 <sqlite3VdbeExec+0x2ce8>
   52161:	mov    eax,ebx
   52163:	and    eax,0x1
   52166:	test   eax,eax
   52168:	je     5217a <sqlite3VdbeExec+0x2cda>
   5216a:	mov    r11d,0xffffffff
   52170:	mov    DWORD PTR [rsp+0x390],r11d
   52178:	jmp    52188 <sqlite3VdbeExec+0x2ce8>
   5217a:	mov    r11d,0x1
   52180:	mov    DWORD PTR [rsp+0x390],r11d
   52188:	mov    DWORD PTR [rsp+0x398],ebx
   5218f:	mov    ebx,DWORD PTR [rsp+0x390]
   52196:	jmp    523c4 <sqlite3VdbeExec+0x2f24>
   5219b:	movzx  eax,WORD PTR [rbp+0x2]
   5219f:	and    eax,0x10
   521a2:	test   eax,eax
   521a4:	je     521be <sqlite3VdbeExec+0x2d1e>
   521a6:	mov    r12,r14
   521a9:	mov    r15d,DWORD PTR [rsp+0x37c]
   521b1:	mov    rbx,QWORD PTR [rsp+0x160]
   521b9:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   521be:	mov    ebx,0x1
   521c3:	mov    DWORD PTR [rsp+0x390],ebx
   521ca:	mov    rbx,QWORD PTR [rsp+0x160]
   521d2:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   521d7:	movzx  eax,WORD PTR [rbp+0x2]
   521db:	and    eax,0x47
   521de:	mov    ecx,eax
   521e0:	cmp    ecx,0x43
   521e3:	jl     5224c <sqlite3VdbeExec+0x2dac>
   521e5:	mov    eax,r15d
   521e8:	mov    ecx,ebx
   521ea:	or     eax,ecx
   521ec:	and    eax,0x2
   521ef:	test   eax,eax
   521f1:	je     52247 <sqlite3VdbeExec+0x2da7>
   521f3:	mov    eax,r15d
   521f6:	and    eax,0x2e
   521f9:	cmp    eax,0x2
   521fc:	jne    52220 <sqlite3VdbeExec+0x2d80>
   521fe:	xor    eax,eax
   52200:	mov    QWORD PTR [rsp+0x110],rdi
   52208:	mov    rdi,r12
   5220b:	mov    rsi,rax
   5220e:	call   52213 <sqlite3VdbeExec+0x2d73>
   52213:	movzx  ebx,WORD PTR [r13+0x14]
   52218:	mov    rdi,QWORD PTR [rsp+0x110]
   52220:	mov    eax,ebx
   52222:	and    eax,0x2e
   52225:	cmp    eax,0x2
   52228:	jne    52247 <sqlite3VdbeExec+0x2da7>
   5222a:	xor    eax,eax
   5222c:	mov    QWORD PTR [rsp+0x110],rdi
   52234:	mov    rdi,r13
   52237:	mov    rsi,rax
   5223a:	call   5223f <sqlite3VdbeExec+0x2d9f>
   5223f:	mov    rdi,QWORD PTR [rsp+0x110]
   52247:	jmp    52399 <sqlite3VdbeExec+0x2ef9>
   5224c:	cmp    eax,0x42
   5224f:	jne    52399 <sqlite3VdbeExec+0x2ef9>
   52255:	mov    eax,r15d
   52258:	mov    ecx,ebx
   5225a:	or     eax,ecx
   5225c:	and    eax,0x2
   5225f:	test   eax,eax
   52261:	je     52399 <sqlite3VdbeExec+0x2ef9>
   52267:	mov    eax,r15d
   5226a:	and    eax,0x2
   5226d:	test   eax,eax
   5226f:	je     52292 <sqlite3VdbeExec+0x2df2>
   52271:	movzx  eax,WORD PTR [r12+0x14]
   52277:	and    eax,0xffffffd3
   5227a:	mov    WORD PTR [r12+0x14],ax
   52280:	mov    QWORD PTR [rsp+0x128],r14
   52288:	mov    r14d,DWORD PTR [rsp+0x37c]
   52290:	jmp    5230a <sqlite3VdbeExec+0x2e6a>
   52292:	mov    eax,r15d
   52295:	and    eax,0x2c
   52298:	test   eax,eax
   5229a:	jne    522ae <sqlite3VdbeExec+0x2e0e>
   5229c:	mov    QWORD PTR [rsp+0x128],r14
   522a4:	mov    r14d,DWORD PTR [rsp+0x37c]
   522ac:	jmp    5230a <sqlite3VdbeExec+0x2e6a>
   522ae:	mov    QWORD PTR [rsp+0x128],r14
   522b6:	mov    r14d,DWORD PTR [rsp+0x37c]
   522be:	mov    eax,r14d
   522c1:	mov    ecx,0x1
   522c6:	mov    QWORD PTR [rsp+0x110],rdi
   522ce:	mov    rdi,r12
   522d1:	mov    rsi,rax
   522d4:	mov    rdx,rcx
   522d7:	call   522dc <sqlite3VdbeExec+0x2e3c>
   522dc:	movzx  eax,WORD PTR [r12+0x14]
   522e2:	and    eax,0xfffff240
   522e7:	mov    ecx,r15d
   522ea:	and    ecx,0xdbf
   522f0:	or     eax,ecx
   522f2:	mov    r15d,eax
   522f5:	mov    rdi,QWORD PTR [rsp+0x110]
   522fd:	cmp    r12,r13
   52300:	jne    5230a <sqlite3VdbeExec+0x2e6a>
   52302:	mov    eax,r15d
   52305:	or     eax,0x2
   52308:	mov    ebx,eax
   5230a:	mov    eax,ebx
   5230c:	and    eax,0x2
   5230f:	test   eax,eax
   52311:	je     52332 <sqlite3VdbeExec+0x2e92>
   52313:	movzx  eax,WORD PTR [r13+0x14]
   52318:	and    eax,0xffffffd3
   5231b:	mov    WORD PTR [r13+0x14],ax
   52320:	mov    DWORD PTR [rsp+0x37c],r14d
   52328:	mov    r14,QWORD PTR [rsp+0x128]
   52330:	jmp    52399 <sqlite3VdbeExec+0x2ef9>
   52332:	mov    eax,ebx
   52334:	and    eax,0x2c
   52337:	test   eax,eax
   52339:	jne    5234d <sqlite3VdbeExec+0x2ead>
   5233b:	mov    DWORD PTR [rsp+0x37c],r14d
   52343:	mov    r14,QWORD PTR [rsp+0x128]
   5234b:	jmp    52399 <sqlite3VdbeExec+0x2ef9>
   5234d:	mov    eax,r14d
   52350:	mov    ecx,0x1
   52355:	mov    QWORD PTR [rsp+0x110],rdi
   5235d:	mov    rdi,r13
   52360:	mov    rsi,rax
   52363:	mov    rdx,rcx
   52366:	call   5236b <sqlite3VdbeExec+0x2ecb>
   5236b:	movzx  eax,WORD PTR [r13+0x14]
   52370:	and    eax,0xfffff240
   52375:	mov    ecx,ebx
   52377:	and    ecx,0xdbf
   5237d:	or     eax,ecx
   5237f:	mov    ebx,eax
   52381:	mov    rdi,QWORD PTR [rsp+0x110]
   52389:	mov    DWORD PTR [rsp+0x37c],r14d
   52391:	mov    r14,QWORD PTR [rsp+0x128]
   52399:	mov    rax,QWORD PTR [rbp+0x10]
   5239d:	mov    DWORD PTR [rsp+0x398],ebx
   523a4:	mov    QWORD PTR [rsp+0x110],rdi
   523ac:	mov    rdi,r13
   523af:	mov    rsi,r12
   523b2:	mov    rdx,rax
   523b5:	call   523ba <sqlite3VdbeExec+0x2f1a>
   523ba:	mov    ebx,eax
   523bc:	mov    rdi,QWORD PTR [rsp+0x110]
   523c4:	test   ebx,ebx
   523c6:	jge    523d9 <sqlite3VdbeExec+0x2f39>
   523c8:	mov    rax,QWORD PTR [rip+0x0]        # 523cf <sqlite3VdbeExec+0x2f2f>
   523cf:	movzx  ecx,BYTE PTR [rbp+0x0]
   523d3:	movzx  eax,BYTE PTR [rax+rcx*1]
   523d7:	jmp    523fd <sqlite3VdbeExec+0x2f5d>
   523d9:	test   ebx,ebx
   523db:	jne    523ee <sqlite3VdbeExec+0x2f4e>
   523dd:	mov    rax,QWORD PTR [rip+0x0]        # 523e4 <sqlite3VdbeExec+0x2f44>
   523e4:	movzx  ecx,BYTE PTR [rbp+0x0]
   523e8:	movzx  eax,BYTE PTR [rax+rcx*1]
   523ec:	jmp    523fd <sqlite3VdbeExec+0x2f5d>
   523ee:	mov    rax,QWORD PTR [rip+0x0]        # 523f5 <sqlite3VdbeExec+0x2f55>
   523f5:	movzx  ecx,BYTE PTR [rbp+0x0]
   523f9:	movzx  eax,BYTE PTR [rax+rcx*1]
   523fd:	mov    DWORD PTR [rsp+0x390],ebx
   52404:	mov    ebx,DWORD PTR [rsp+0x398]
   5240b:	mov    WORD PTR [r13+0x14],bx
   52410:	mov    WORD PTR [r12+0x14],r15w
   52416:	test   eax,eax
   52418:	je     52432 <sqlite3VdbeExec+0x2f92>
   5241a:	mov    r12,r14
   5241d:	mov    r15d,DWORD PTR [rsp+0x37c]
   52425:	mov    rbx,QWORD PTR [rsp+0x160]
   5242d:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   52432:	mov    rbx,QWORD PTR [rsp+0x160]
   5243a:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5243f:	mov    r15d,DWORD PTR [rsp+0x37c]
   52447:	mov    r13,QWORD PTR [rsp+0x150]
   5244f:	mov    QWORD PTR [rsp+0x130],r12
   52457:	mov    r12d,DWORD PTR [rsp+0x394]
   5245f:	mov    DWORD PTR [rsp+0x394],r12d
   52467:	mov    r12d,DWORD PTR [rsp+0x390]
   5246f:	test   r12d,r12d
   52472:	jne    5248c <sqlite3VdbeExec+0x2fec>
   52474:	mov    QWORD PTR [rsp+0x150],r13
   5247c:	mov    DWORD PTR [rsp+0x390],r12d
   52484:	mov    r12,r14
   52487:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   5248c:	mov    DWORD PTR [rsp+0x37c],r15d
   52494:	mov    QWORD PTR [rsp+0x150],r13
   5249c:	mov    DWORD PTR [rsp+0x390],r12d
   524a4:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   524a9:	mov    r15d,DWORD PTR [rsp+0x37c]
   524b1:	mov    r13,QWORD PTR [rsp+0x150]
   524b9:	mov    QWORD PTR [rsp+0x130],r12
   524c1:	mov    r12d,DWORD PTR [rsp+0x390]
   524c9:	mov    DWORD PTR [rsp+0x37c],r15d
   524d1:	mov    QWORD PTR [rsp+0x150],r13
   524d9:	mov    DWORD PTR [rsp+0x390],r12d
   524e1:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   524e6:	mov    r15d,DWORD PTR [rsp+0x37c]
   524ee:	mov    r13,QWORD PTR [rsp+0x150]
   524f6:	mov    QWORD PTR [rsp+0x130],r12
   524fe:	mov    r12d,DWORD PTR [rsp+0x390]
   52506:	movzx  eax,WORD PTR [rbp+0x2]
   5250a:	and    eax,0x1
   5250d:	test   eax,eax
   5250f:	jne    5251e <sqlite3VdbeExec+0x307e>
   52511:	mov    QWORD PTR [rsp+0x150],r13
   52519:	xor    r13d,r13d
   5251c:	jmp    5252e <sqlite3VdbeExec+0x308e>
   5251e:	mov    QWORD PTR [rsp+0x150],r13
   52526:	mov    rax,QWORD PTR [rbp-0x8]
   5252a:	lea    r13,[rax+0x4]
   5252e:	mov    QWORD PTR [rsp+0x168],r13
   52536:	mov    r13d,DWORD PTR [rbp+0xc]
   5253a:	mov    DWORD PTR [rsp+0x398],r13d
   52542:	mov    r13,QWORD PTR [rbp+0x10]
   52546:	mov    DWORD PTR [rsp+0x390],r12d
   5254e:	mov    r12d,DWORD PTR [rbp+0x4]
   52552:	mov    DWORD PTR [rsp+0x39c],r12d
   5255a:	mov    r12d,DWORD PTR [rbp+0x8]
   5255e:	mov    QWORD PTR [rsp+0x128],r14
   52566:	mov    DWORD PTR [rsp+0x37c],r15d
   5256e:	mov    r14d,DWORD PTR [rsp+0x39c]
   52576:	mov    QWORD PTR [rsp+0x148],rbp
   5257e:	mov    ebp,DWORD PTR [rsp+0x390]
   52585:	xor    r15d,r15d
   52588:	jmp    526d0 <sqlite3VdbeExec+0x3230>
   5258d:	mov    DWORD PTR [rsp+0x398],r12d
   52595:	mov    DWORD PTR [rsp+0x39c],r14d
   5259d:	mov    r14,QWORD PTR [rsp+0x128]
   525a5:	mov    r12,r15
   525a8:	mov    r15d,DWORD PTR [rsp+0x37c]
   525b0:	mov    rbp,QWORD PTR [rsp+0x148]
   525b8:	mov    DWORD PTR [rsp+0x37c],r15d
   525c0:	mov    r15,r12
   525c3:	mov    rax,r15
   525c6:	mov    rcx,QWORD PTR [r13+rax*8+0x20]
   525cb:	mov    rdx,QWORD PTR [r13+0x18]
   525cf:	movzx  eax,BYTE PTR [rdx+rax*1]
   525d3:	mov    QWORD PTR [rsp+0x128],r14
   525db:	mov    r14d,eax
   525de:	and    r14d,0x1
   525e2:	mov    DWORD PTR [rsp+0x3a4],r14d
   525ea:	mov    r14d,DWORD PTR [rsp+0x39c]
   525f2:	lea    eax,[r14+r12*1]
   525f6:	imul   rax,rax,0x38
   525fa:	add    rax,rbx
   525fd:	mov    QWORD PTR [rsp+0x148],rbp
   52605:	mov    ebp,DWORD PTR [rsp+0x3a0]
   5260c:	lea    edx,[rbp+r12*1+0x0]
   52611:	imul   rdx,rdx,0x38
   52615:	add    rdx,rbx
   52618:	mov    QWORD PTR [rsp+0x110],rdi
   52620:	mov    rdi,rax
   52623:	mov    rsi,rdx
   52626:	mov    rdx,rcx
   52629:	call   5262e <sqlite3VdbeExec+0x318e>
   5262e:	mov    ebp,eax
   52630:	mov    rdi,QWORD PTR [rsp+0x110]
   52638:	test   ebp,ebp
   5263a:	je     526c4 <sqlite3VdbeExec+0x3224>
   52640:	mov    rax,QWORD PTR [r13+0x18]
   52644:	mov    rcx,r15
   52647:	movzx  eax,BYTE PTR [rax+rcx*1]
   5264b:	and    eax,0x2
   5264e:	test   eax,eax
   52650:	jne    5265c <sqlite3VdbeExec+0x31bc>
   52652:	mov    r14d,DWORD PTR [rsp+0x3a4]
   5265a:	jmp    526a1 <sqlite3VdbeExec+0x3201>
   5265c:	lea    eax,[r14+r12*1]
   52660:	imul   rax,rax,0x38
   52664:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52669:	and    eax,0x1
   5266c:	test   eax,eax
   5266e:	jne    52697 <sqlite3VdbeExec+0x31f7>
   52670:	mov    r13d,DWORD PTR [rsp+0x3a0]
   52678:	lea    eax,[r13+r12*1+0x0]
   5267d:	imul   rax,rax,0x38
   52681:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52686:	and    eax,0x1
   52689:	test   eax,eax
   5268b:	jne    52697 <sqlite3VdbeExec+0x31f7>
   5268d:	mov    r14d,DWORD PTR [rsp+0x3a4]
   52695:	jmp    526a1 <sqlite3VdbeExec+0x3201>
   52697:	neg    ebp
   52699:	mov    r14d,DWORD PTR [rsp+0x3a4]
   526a1:	test   r14d,r14d
   526a4:	je     526a8 <sqlite3VdbeExec+0x3208>
   526a6:	neg    ebp
   526a8:	mov    r14,QWORD PTR [rsp+0x128]
   526b0:	mov    DWORD PTR [rsp+0x390],ebp
   526b7:	mov    rbp,QWORD PTR [rsp+0x148]
   526bf:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   526c4:	mov    r12d,DWORD PTR [rsp+0x3a0]
   526cc:	add    r15d,0x1
   526d0:	mov    DWORD PTR [rsp+0x3a0],r12d
   526d8:	mov    r12d,DWORD PTR [rsp+0x398]
   526e0:	cmp    r15d,r12d
   526e3:	jge    526a8 <sqlite3VdbeExec+0x3208>
   526e5:	mov    rbp,QWORD PTR [rsp+0x168]
   526ed:	test   rbp,rbp
   526f0:	je     5258d <sqlite3VdbeExec+0x30ed>
   526f6:	mov    rax,r15
   526f9:	mov    ebp,DWORD PTR [rbp+rax*4+0x0]
   526fd:	mov    DWORD PTR [rsp+0x398],r12d
   52705:	mov    DWORD PTR [rsp+0x39c],r14d
   5270d:	mov    r14,QWORD PTR [rsp+0x128]
   52715:	mov    r12,rbp
   52718:	mov    rbp,QWORD PTR [rsp+0x148]
   52720:	jmp    525c3 <sqlite3VdbeExec+0x3123>
   52725:	mov    r15d,DWORD PTR [rsp+0x37c]
   5272d:	mov    r13,QWORD PTR [rsp+0x150]
   52735:	mov    QWORD PTR [rsp+0x130],r12
   5273d:	mov    r12d,DWORD PTR [rsp+0x394]
   52745:	mov    DWORD PTR [rsp+0x394],r12d
   5274d:	mov    r12d,DWORD PTR [rsp+0x390]
   52755:	test   r12d,r12d
   52758:	jge    5276e <sqlite3VdbeExec+0x32ce>
   5275a:	mov    eax,DWORD PTR [rbp+0x4]
   5275d:	sub    eax,0x1
   52760:	movsxd rax,eax
   52763:	imul   rax,rax,0x18
   52767:	lea    rbp,[r13+rax*1+0x0]
   5276c:	jmp    52799 <sqlite3VdbeExec+0x32f9>
   5276e:	test   r12d,r12d
   52771:	jne    52787 <sqlite3VdbeExec+0x32e7>
   52773:	mov    eax,DWORD PTR [rbp+0x8]
   52776:	sub    eax,0x1
   52779:	movsxd rax,eax
   5277c:	imul   rax,rax,0x18
   52780:	lea    rbp,[r13+rax*1+0x0]
   52785:	jmp    52799 <sqlite3VdbeExec+0x32f9>
   52787:	mov    eax,DWORD PTR [rbp+0xc]
   5278a:	sub    eax,0x1
   5278d:	movsxd rax,eax
   52790:	imul   rax,rax,0x18
   52794:	lea    rbp,[r13+rax*1+0x0]
   52799:	mov    DWORD PTR [rsp+0x37c],r15d
   527a1:	mov    QWORD PTR [rsp+0x150],r13
   527a9:	mov    DWORD PTR [rsp+0x390],r12d
   527b1:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   527b6:	mov    r15d,DWORD PTR [rsp+0x37c]
   527be:	mov    r13,QWORD PTR [rsp+0x150]
   527c6:	mov    QWORD PTR [rsp+0x130],r12
   527ce:	mov    r12d,DWORD PTR [rsp+0x394]
   527d6:	movsxd rax,DWORD PTR [rbp+0x4]
   527da:	imul   rax,rax,0x38
   527de:	lea    rcx,[rbx+rax*1]
   527e2:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   527e7:	and    eax,0x24
   527ea:	test   eax,eax
   527ec:	je     52806 <sqlite3VdbeExec+0x3366>
   527ee:	mov    DWORD PTR [rsp+0x394],r12d
   527f6:	xor    r12d,r12d
   527f9:	cmp    QWORD PTR [rcx],0x0
   527fd:	setne  r12b
   52801:	jmp    5288b <sqlite3VdbeExec+0x33eb>
   52806:	mov    DWORD PTR [rsp+0x394],r12d
   5280e:	movzx  eax,WORD PTR [rcx+0x14]
   52812:	and    eax,0x1
   52815:	test   eax,eax
   52817:	je     52821 <sqlite3VdbeExec+0x3381>
   52819:	mov    r12d,0x2
   5281f:	jmp    5288b <sqlite3VdbeExec+0x33eb>
   52821:	movzx  eax,WORD PTR [rcx+0x14]
   52825:	and    eax,0x8
   52828:	test   eax,eax
   5282a:	je     52832 <sqlite3VdbeExec+0x3392>
   5282c:	movsd  xmm1,QWORD PTR [rcx]
   52830:	jmp    52875 <sqlite3VdbeExec+0x33d5>
   52832:	movzx  eax,WORD PTR [rcx+0x14]
   52836:	and    eax,0x24
   52839:	test   eax,eax
   5283b:	je     5284a <sqlite3VdbeExec+0x33aa>
   5283d:	mov    rax,QWORD PTR [rcx]
   52840:	xorps  xmm1,xmm1
   52843:	cvtsi2sd xmm1,rax
   52848:	jmp    52875 <sqlite3VdbeExec+0x33d5>
   5284a:	movzx  eax,WORD PTR [rcx+0x14]
   5284e:	and    eax,0x12
   52851:	test   eax,eax
   52853:	je     52872 <sqlite3VdbeExec+0x33d2>
   52855:	mov    QWORD PTR [rsp+0x110],rdi
   5285d:	mov    rdi,rcx
   52860:	call   52865 <sqlite3VdbeExec+0x33c5>
   52865:	movaps xmm1,xmm0
   52868:	mov    rdi,QWORD PTR [rsp+0x110]
   52870:	jmp    52875 <sqlite3VdbeExec+0x33d5>
   52872:	xorps  xmm1,xmm1
   52875:	xorps  xmm0,xmm0
   52878:	xor    eax,eax
   5287a:	ucomisd xmm1,xmm0
   5287e:	setne  al
   52881:	setp   r11b
   52885:	or     al,r11b
   52888:	mov    r12d,eax
   5288b:	movsxd rax,DWORD PTR [rbp+0x8]
   5288f:	imul   rax,rax,0x38
   52893:	lea    rcx,[rbx+rax*1]
   52897:	mov    edx,0x2
   5289c:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   528a1:	and    eax,0x24
   528a4:	test   eax,eax
   528a6:	je     528b3 <sqlite3VdbeExec+0x3413>
   528a8:	xor    eax,eax
   528aa:	cmp    QWORD PTR [rcx],0x0
   528ae:	setne  al
   528b1:	jmp    52927 <sqlite3VdbeExec+0x3487>
   528b3:	movzx  eax,WORD PTR [rcx+0x14]
   528b7:	and    eax,0x1
   528ba:	test   eax,eax
   528bc:	je     528c3 <sqlite3VdbeExec+0x3423>
   528be:	mov    rax,rdx
   528c1:	jmp    52927 <sqlite3VdbeExec+0x3487>
   528c3:	movzx  eax,WORD PTR [rcx+0x14]
   528c7:	and    eax,0x8
   528ca:	test   eax,eax
   528cc:	je     528d4 <sqlite3VdbeExec+0x3434>
   528ce:	movsd  xmm0,QWORD PTR [rcx]
   528d2:	jmp    52914 <sqlite3VdbeExec+0x3474>
   528d4:	movzx  eax,WORD PTR [rcx+0x14]
   528d8:	and    eax,0x24
   528db:	test   eax,eax
   528dd:	je     528ec <sqlite3VdbeExec+0x344c>
   528df:	mov    rax,QWORD PTR [rcx]
   528e2:	xorps  xmm0,xmm0
   528e5:	cvtsi2sd xmm0,rax
   528ea:	jmp    52914 <sqlite3VdbeExec+0x3474>
   528ec:	movzx  eax,WORD PTR [rcx+0x14]
   528f0:	and    eax,0x12
   528f3:	test   eax,eax
   528f5:	je     52911 <sqlite3VdbeExec+0x3471>
   528f7:	mov    QWORD PTR [rsp+0x110],rdi
   528ff:	mov    rdi,rcx
   52902:	call   52907 <sqlite3VdbeExec+0x3467>
   52907:	mov    rdi,QWORD PTR [rsp+0x110]
   5290f:	jmp    52914 <sqlite3VdbeExec+0x3474>
   52911:	xorps  xmm0,xmm0
   52914:	xorps  xmm1,xmm1
   52917:	xor    eax,eax
   52919:	ucomisd xmm0,xmm1
   5291d:	setne  al
   52920:	setp   r11b
   52924:	or     al,r11b
   52927:	cmp    BYTE PTR [rbp+0x0],0x2c
   5292b:	jne    52940 <sqlite3VdbeExec+0x34a0>
   5292d:	lea    rcx,[rip+0x0]        # 52934 <sqlite3VdbeExec+0x3494>
   52934:	lea    edx,[r12+r12*2]
   52938:	add    eax,edx
   5293a:	movzx  eax,BYTE PTR [rcx+rax*1]
   5293e:	jmp    52951 <sqlite3VdbeExec+0x34b1>
   52940:	lea    rcx,[rip+0x0]        # 52947 <sqlite3VdbeExec+0x34a7>
   52947:	lea    edx,[r12+r12*2]
   5294b:	add    eax,edx
   5294d:	movzx  eax,BYTE PTR [rcx+rax*1]
   52951:	movsxd rcx,DWORD PTR [rbp+0xc]
   52955:	imul   rcx,rcx,0x38
   52959:	cmp    eax,0x2
   5295c:	jne    52972 <sqlite3VdbeExec+0x34d2>
   5295e:	movzx  eax,WORD PTR [rbx+rcx*1+0x14]
   52963:	and    eax,0xfffff240
   52968:	or     eax,0x1
   5296b:	mov    WORD PTR [rbx+rcx*1+0x14],ax
   52970:	jmp    52988 <sqlite3VdbeExec+0x34e8>
   52972:	mov    QWORD PTR [rbx+rcx*1],rax
   52976:	movzx  eax,WORD PTR [rbx+rcx*1+0x14]
   5297b:	and    eax,0xfffff240
   52980:	or     eax,0x4
   52983:	mov    WORD PTR [rbx+rcx*1+0x14],ax
   52988:	mov    DWORD PTR [rsp+0x37c],r15d
   52990:	mov    QWORD PTR [rsp+0x150],r13
   52998:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5299d:	mov    r15d,DWORD PTR [rsp+0x37c]
   529a5:	mov    r13,QWORD PTR [rsp+0x150]
   529ad:	mov    QWORD PTR [rsp+0x130],r12
   529b5:	movsxd rax,DWORD PTR [rbp+0x8]
   529b9:	imul   rax,rax,0x38
   529bd:	lea    r12,[rbx+rax*1]
   529c1:	movsxd rax,DWORD PTR [rbp+0x4]
   529c5:	imul   rax,rax,0x38
   529c9:	lea    rcx,[rbx+rax*1]
   529cd:	movsxd rdx,DWORD PTR [rbp+0xc]
   529d1:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   529d6:	and    eax,0x24
   529d9:	test   eax,eax
   529db:	je     529e8 <sqlite3VdbeExec+0x3548>
   529dd:	xor    eax,eax
   529df:	cmp    QWORD PTR [rcx],0x0
   529e3:	setne  al
   529e6:	jmp    52a5f <sqlite3VdbeExec+0x35bf>
   529e8:	movzx  eax,WORD PTR [rcx+0x14]
   529ec:	and    eax,0x1
   529ef:	test   eax,eax
   529f1:	je     529f8 <sqlite3VdbeExec+0x3558>
   529f3:	mov    rax,rdx
   529f6:	jmp    52a5f <sqlite3VdbeExec+0x35bf>
   529f8:	movzx  eax,WORD PTR [rcx+0x14]
   529fc:	and    eax,0x8
   529ff:	test   eax,eax
   52a01:	je     52a09 <sqlite3VdbeExec+0x3569>
   52a03:	movsd  xmm1,QWORD PTR [rcx]
   52a07:	jmp    52a4c <sqlite3VdbeExec+0x35ac>
   52a09:	movzx  eax,WORD PTR [rcx+0x14]
   52a0d:	and    eax,0x24
   52a10:	test   eax,eax
   52a12:	je     52a21 <sqlite3VdbeExec+0x3581>
   52a14:	mov    rax,QWORD PTR [rcx]
   52a17:	xorps  xmm1,xmm1
   52a1a:	cvtsi2sd xmm1,rax
   52a1f:	jmp    52a4c <sqlite3VdbeExec+0x35ac>
   52a21:	movzx  eax,WORD PTR [rcx+0x14]
   52a25:	and    eax,0x12
   52a28:	test   eax,eax
   52a2a:	je     52a49 <sqlite3VdbeExec+0x35a9>
   52a2c:	mov    QWORD PTR [rsp+0x110],rdi
   52a34:	mov    rdi,rcx
   52a37:	call   52a3c <sqlite3VdbeExec+0x359c>
   52a3c:	movaps xmm1,xmm0
   52a3f:	mov    rdi,QWORD PTR [rsp+0x110]
   52a47:	jmp    52a4c <sqlite3VdbeExec+0x35ac>
   52a49:	xorps  xmm1,xmm1
   52a4c:	xorps  xmm0,xmm0
   52a4f:	xor    eax,eax
   52a51:	ucomisd xmm1,xmm0
   52a55:	setne  al
   52a58:	setp   r11b
   52a5c:	or     al,r11b
   52a5f:	movsxd rcx,DWORD PTR [rbp+0x10]
   52a63:	xor    rax,rcx
   52a66:	movzx  ecx,WORD PTR [r12+0x14]
   52a6c:	and    ecx,0x9000
   52a72:	test   ecx,ecx
   52a74:	je     52a93 <sqlite3VdbeExec+0x35f3>
   52a76:	mov    QWORD PTR [rsp+0x110],rdi
   52a7e:	mov    rdi,r12
   52a81:	mov    rsi,rax
   52a84:	call   52a89 <sqlite3VdbeExec+0x35e9>
   52a89:	mov    rdi,QWORD PTR [rsp+0x110]
   52a91:	jmp    52a9f <sqlite3VdbeExec+0x35ff>
   52a93:	mov    QWORD PTR [r12],rax
   52a97:	mov    WORD PTR [r12+0x14],0x4
   52a9f:	mov    DWORD PTR [rsp+0x37c],r15d
   52aa7:	mov    QWORD PTR [rsp+0x150],r13
   52aaf:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   52ab4:	mov    r15d,DWORD PTR [rsp+0x37c]
   52abc:	mov    r13,QWORD PTR [rsp+0x150]
   52ac4:	mov    QWORD PTR [rsp+0x130],r12
   52acc:	movsxd rax,DWORD PTR [rbp+0x4]
   52ad0:	imul   rax,rax,0x38
   52ad4:	lea    rcx,[rbx+rax*1]
   52ad8:	movsxd rdx,DWORD PTR [rbp+0x8]
   52adc:	imul   rdx,rdx,0x38
   52ae0:	lea    r12,[rbx+rdx*1]
   52ae4:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52ae9:	and    eax,0x1
   52aec:	test   eax,eax
   52aee:	jne    52bc2 <sqlite3VdbeExec+0x3722>
   52af4:	xor    eax,eax
   52af6:	movzx  edx,WORD PTR [rcx+0x14]
   52afa:	and    edx,0x24
   52afd:	test   edx,edx
   52aff:	je     52b0c <sqlite3VdbeExec+0x366c>
   52b01:	xor    eax,eax
   52b03:	cmp    QWORD PTR [rcx],0x0
   52b07:	setne  al
   52b0a:	jmp    52b7d <sqlite3VdbeExec+0x36dd>
   52b0c:	movzx  edx,WORD PTR [rcx+0x14]
   52b10:	and    edx,0x1
   52b13:	test   edx,edx
   52b15:	je     52b19 <sqlite3VdbeExec+0x3679>
   52b17:	jmp    52b7d <sqlite3VdbeExec+0x36dd>
   52b19:	movzx  eax,WORD PTR [rcx+0x14]
   52b1d:	and    eax,0x8
   52b20:	test   eax,eax
   52b22:	je     52b2a <sqlite3VdbeExec+0x368a>
   52b24:	movsd  xmm0,QWORD PTR [rcx]
   52b28:	jmp    52b6a <sqlite3VdbeExec+0x36ca>
   52b2a:	movzx  eax,WORD PTR [rcx+0x14]
   52b2e:	and    eax,0x24
   52b31:	test   eax,eax
   52b33:	je     52b42 <sqlite3VdbeExec+0x36a2>
   52b35:	mov    rax,QWORD PTR [rcx]
   52b38:	xorps  xmm0,xmm0
   52b3b:	cvtsi2sd xmm0,rax
   52b40:	jmp    52b6a <sqlite3VdbeExec+0x36ca>
   52b42:	movzx  eax,WORD PTR [rcx+0x14]
   52b46:	and    eax,0x12
   52b49:	test   eax,eax
   52b4b:	je     52b67 <sqlite3VdbeExec+0x36c7>
   52b4d:	mov    QWORD PTR [rsp+0x110],rdi
   52b55:	mov    rdi,rcx
   52b58:	call   52b5d <sqlite3VdbeExec+0x36bd>
   52b5d:	mov    rdi,QWORD PTR [rsp+0x110]
   52b65:	jmp    52b6a <sqlite3VdbeExec+0x36ca>
   52b67:	xorps  xmm0,xmm0
   52b6a:	xorps  xmm1,xmm1
   52b6d:	xor    eax,eax
   52b6f:	ucomisd xmm0,xmm1
   52b73:	setne  al
   52b76:	setp   r11b
   52b7a:	or     al,r11b
   52b7d:	test   eax,eax
   52b7f:	mov    eax,0x0
   52b84:	sete   al
   52b87:	movzx  ecx,WORD PTR [r12+0x14]
   52b8d:	and    ecx,0x9000
   52b93:	test   ecx,ecx
   52b95:	je     52bb4 <sqlite3VdbeExec+0x3714>
   52b97:	mov    QWORD PTR [rsp+0x110],rdi
   52b9f:	mov    rdi,r12
   52ba2:	mov    rsi,rax
   52ba5:	call   52baa <sqlite3VdbeExec+0x370a>
   52baa:	mov    rdi,QWORD PTR [rsp+0x110]
   52bb2:	jmp    52bf3 <sqlite3VdbeExec+0x3753>
   52bb4:	mov    QWORD PTR [r12],rax
   52bb8:	mov    WORD PTR [r12+0x14],0x4
   52bc0:	jmp    52bf3 <sqlite3VdbeExec+0x3753>
   52bc2:	movzx  eax,WORD PTR [r12+0x14]
   52bc8:	and    eax,0x9000
   52bcd:	test   eax,eax
   52bcf:	je     52beb <sqlite3VdbeExec+0x374b>
   52bd1:	mov    QWORD PTR [rsp+0x110],rdi
   52bd9:	mov    rdi,r12
   52bdc:	call   52be1 <sqlite3VdbeExec+0x3741>
   52be1:	mov    rdi,QWORD PTR [rsp+0x110]
   52be9:	jmp    52bf3 <sqlite3VdbeExec+0x3753>
   52beb:	mov    WORD PTR [r12+0x14],0x1
   52bf3:	mov    DWORD PTR [rsp+0x37c],r15d
   52bfb:	mov    QWORD PTR [rsp+0x150],r13
   52c03:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   52c08:	mov    r15d,DWORD PTR [rsp+0x37c]
   52c10:	mov    r13,QWORD PTR [rsp+0x150]
   52c18:	mov    QWORD PTR [rsp+0x130],r12
   52c20:	movsxd rax,DWORD PTR [rbp+0x4]
   52c24:	imul   rax,rax,0x38
   52c28:	lea    r12,[rbx+rax*1]
   52c2c:	movsxd rax,DWORD PTR [rbp+0x8]
   52c30:	imul   rax,rax,0x38
   52c34:	mov    QWORD PTR [rsp+0x150],r13
   52c3c:	lea    r13,[rbx+rax*1]
   52c40:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52c45:	and    eax,0x9000
   52c4a:	test   eax,eax
   52c4c:	je     52c68 <sqlite3VdbeExec+0x37c8>
   52c4e:	mov    QWORD PTR [rsp+0x110],rdi
   52c56:	mov    rdi,r13
   52c59:	call   52c5e <sqlite3VdbeExec+0x37be>
   52c5e:	mov    rdi,QWORD PTR [rsp+0x110]
   52c66:	jmp    52c6f <sqlite3VdbeExec+0x37cf>
   52c68:	mov    WORD PTR [r13+0x14],0x1
   52c6f:	movzx  eax,WORD PTR [r12+0x14]
   52c75:	and    eax,0x1
   52c78:	test   eax,eax
   52c7a:	jne    52d29 <sqlite3VdbeExec+0x3889>
   52c80:	mov    WORD PTR [r13+0x14],0x4
   52c87:	movzx  eax,WORD PTR [r12+0x14]
   52c8d:	mov    ecx,eax
   52c8f:	and    ecx,0x24
   52c92:	test   ecx,ecx
   52c94:	je     52c9f <sqlite3VdbeExec+0x37ff>
   52c96:	mov    rax,QWORD PTR [r12]
   52c9a:	jmp    52d22 <sqlite3VdbeExec+0x3882>
   52c9f:	mov    ecx,eax
   52ca1:	and    ecx,0x8
   52ca4:	test   ecx,ecx
   52ca6:	je     52cf7 <sqlite3VdbeExec+0x3857>
   52ca8:	movsd  xmm1,QWORD PTR [r12]
   52cae:	movabs r11,0xc3dfffffffffffff
   52cb8:	movq   xmm0,r11
   52cbd:	ucomisd xmm0,xmm1
   52cc1:	jbe    52ccf <sqlite3VdbeExec+0x382f>
   52cc3:	movabs rax,0x8000000000000000
   52ccd:	jmp    52cf5 <sqlite3VdbeExec+0x3855>
   52ccf:	movabs r11,0x43dfffffffffffff
   52cd9:	movq   xmm0,r11
   52cde:	ucomisd xmm1,xmm0
   52ce2:	jbe    52cf0 <sqlite3VdbeExec+0x3850>
   52ce4:	movabs rax,0x7fffffffffffffff
   52cee:	jmp    52cf5 <sqlite3VdbeExec+0x3855>
   52cf0:	cvttsd2si rax,xmm1
   52cf5:	jmp    52d22 <sqlite3VdbeExec+0x3882>
   52cf7:	and    eax,0x12
   52cfa:	test   eax,eax
   52cfc:	je     52d20 <sqlite3VdbeExec+0x3880>
   52cfe:	cmp    QWORD PTR [r12+0x8],0x0
   52d04:	je     52d20 <sqlite3VdbeExec+0x3880>
   52d06:	mov    QWORD PTR [rsp+0x110],rdi
   52d0e:	mov    rdi,r12
   52d11:	call   52d16 <sqlite3VdbeExec+0x3876>
   52d16:	mov    rdi,QWORD PTR [rsp+0x110]
   52d1e:	jmp    52d22 <sqlite3VdbeExec+0x3882>
   52d20:	xor    eax,eax
   52d22:	not    rax
   52d25:	mov    QWORD PTR [r13+0x0],rax
   52d29:	mov    DWORD PTR [rsp+0x37c],r15d
   52d31:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   52d36:	mov    r15d,DWORD PTR [rsp+0x37c]
   52d3e:	mov    QWORD PTR [rsp+0x130],r12
   52d46:	cmp    QWORD PTR [rdi+0x108],0x0
   52d4e:	je     52df7 <sqlite3VdbeExec+0x3957>
   52d54:	mov    rax,rbp
   52d57:	sub    rax,QWORD PTR [rdi+0x88]
   52d5e:	movabs rdx,0x2aaaaaaaaaaaaaab
   52d68:	imul   rdx
   52d6b:	sar    rdx,0x2
   52d6f:	mov    rax,rdx
   52d72:	shr    rax,0x3f
   52d76:	add    rdx,rax
   52d79:	mov    rax,rdx
   52d7c:	mov    rcx,QWORD PTR [rdi+0x108]
   52d83:	mov    rcx,QWORD PTR [rcx+0x28]
   52d87:	mov    edx,eax
   52d89:	shr    edx,0x3
   52d8c:	movzx  ecx,BYTE PTR [rcx+rdx*1]
   52d90:	mov    edx,ecx
   52d92:	mov    esi,0x1
   52d97:	mov    ecx,eax
   52d99:	and    ecx,0x7
   52d9c:	shl    esi,cl
   52d9e:	and    edx,esi
   52da0:	test   edx,edx
   52da2:	je     52dac <sqlite3VdbeExec+0x390c>
   52da4:	mov    r12,r14
   52da7:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   52dac:	mov    rcx,QWORD PTR [rdi+0x108]
   52db3:	mov    rdx,QWORD PTR [rcx+0x28]
   52db7:	mov    ecx,eax
   52db9:	shr    ecx,0x3
   52dbc:	mov    rsi,rcx
   52dbf:	movzx  ecx,BYTE PTR [rdx+rsi*1]
   52dc3:	mov    r8d,ecx
   52dc6:	mov    r9d,0x1
   52dcc:	and    eax,0x7
   52dcf:	mov    ecx,eax
   52dd1:	mov    rax,r9
   52dd4:	shl    eax,cl
   52dd6:	or     r8d,eax
   52dd9:	mov    BYTE PTR [rdx+rsi*1],r8b
   52ddd:	mov    rax,QWORD PTR [rdi+0x88]
   52de4:	mov    eax,DWORD PTR [rax+0x4]
   52de7:	mov    DWORD PTR [rbp+0x4],eax
   52dea:	mov    DWORD PTR [rsp+0x37c],r15d
   52df2:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   52df7:	mov    rax,QWORD PTR [rdi+0x88]
   52dfe:	mov    eax,DWORD PTR [rax+0x4]
   52e01:	cmp    eax,DWORD PTR [rbp+0x4]
   52e04:	jne    52ddd <sqlite3VdbeExec+0x393d>
   52e06:	mov    r12,r14
   52e09:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   52e0e:	mov    r15d,DWORD PTR [rsp+0x37c]
   52e16:	mov    QWORD PTR [rsp+0x130],r12
   52e1e:	movsxd rax,DWORD PTR [rbp+0x4]
   52e22:	imul   rax,rax,0x38
   52e26:	lea    rcx,[rbx+rax*1]
   52e2a:	mov    edx,DWORD PTR [rbp+0xc]
   52e2d:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52e32:	and    eax,0x24
   52e35:	test   eax,eax
   52e37:	je     52e47 <sqlite3VdbeExec+0x39a7>
   52e39:	cmp    QWORD PTR [rcx],0x0
   52e3d:	je     52e56 <sqlite3VdbeExec+0x39b6>
   52e3f:	mov    r12,r14
   52e42:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   52e47:	movzx  eax,WORD PTR [rcx+0x14]
   52e4b:	and    eax,0x1
   52e4e:	test   eax,eax
   52e50:	je     52e63 <sqlite3VdbeExec+0x39c3>
   52e52:	test   edx,edx
   52e54:	jne    52e3f <sqlite3VdbeExec+0x399f>
   52e56:	mov    DWORD PTR [rsp+0x37c],r15d
   52e5e:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   52e63:	movzx  eax,WORD PTR [rcx+0x14]
   52e67:	and    eax,0x8
   52e6a:	test   eax,eax
   52e6c:	je     52e74 <sqlite3VdbeExec+0x39d4>
   52e6e:	movsd  xmm1,QWORD PTR [rcx]
   52e72:	jmp    52eb7 <sqlite3VdbeExec+0x3a17>
   52e74:	movzx  eax,WORD PTR [rcx+0x14]
   52e78:	and    eax,0x24
   52e7b:	test   eax,eax
   52e7d:	je     52e8c <sqlite3VdbeExec+0x39ec>
   52e7f:	mov    rax,QWORD PTR [rcx]
   52e82:	xorps  xmm1,xmm1
   52e85:	cvtsi2sd xmm1,rax
   52e8a:	jmp    52eb7 <sqlite3VdbeExec+0x3a17>
   52e8c:	movzx  eax,WORD PTR [rcx+0x14]
   52e90:	and    eax,0x12
   52e93:	test   eax,eax
   52e95:	je     52eb4 <sqlite3VdbeExec+0x3a14>
   52e97:	mov    QWORD PTR [rsp+0x110],rdi
   52e9f:	mov    rdi,rcx
   52ea2:	call   52ea7 <sqlite3VdbeExec+0x3a07>
   52ea7:	movaps xmm1,xmm0
   52eaa:	mov    rdi,QWORD PTR [rsp+0x110]
   52eb2:	jmp    52eb7 <sqlite3VdbeExec+0x3a17>
   52eb4:	xorps  xmm1,xmm1
   52eb7:	xorps  xmm0,xmm0
   52eba:	xor    eax,eax
   52ebc:	ucomisd xmm1,xmm0
   52ec0:	setne  al
   52ec3:	setp   r11b
   52ec7:	or     al,r11b
   52eca:	test   eax,eax
   52ecc:	mov    eax,0x0
   52ed1:	setne  al
   52ed4:	test   eax,eax
   52ed6:	jne    52e3f <sqlite3VdbeExec+0x399f>
   52edc:	jmp    52e56 <sqlite3VdbeExec+0x39b6>
   52ee1:	mov    r15d,DWORD PTR [rsp+0x37c]
   52ee9:	mov    QWORD PTR [rsp+0x130],r12
   52ef1:	movsxd rax,DWORD PTR [rbp+0x4]
   52ef5:	imul   rax,rax,0x38
   52ef9:	lea    rcx,[rbx+rax*1]
   52efd:	mov    edx,DWORD PTR [rbp+0xc]
   52f00:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52f05:	and    eax,0x24
   52f08:	test   eax,eax
   52f0a:	je     52f1a <sqlite3VdbeExec+0x3a7a>
   52f0c:	cmp    QWORD PTR [rcx],0x0
   52f10:	jne    52f29 <sqlite3VdbeExec+0x3a89>
   52f12:	mov    r12,r14
   52f15:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   52f1a:	movzx  eax,WORD PTR [rcx+0x14]
   52f1e:	and    eax,0x1
   52f21:	test   eax,eax
   52f23:	je     52f36 <sqlite3VdbeExec+0x3a96>
   52f25:	test   edx,edx
   52f27:	jne    52f12 <sqlite3VdbeExec+0x3a72>
   52f29:	mov    DWORD PTR [rsp+0x37c],r15d
   52f31:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   52f36:	movzx  eax,WORD PTR [rcx+0x14]
   52f3a:	and    eax,0x8
   52f3d:	test   eax,eax
   52f3f:	je     52f47 <sqlite3VdbeExec+0x3aa7>
   52f41:	movsd  xmm0,QWORD PTR [rcx]
   52f45:	jmp    52f87 <sqlite3VdbeExec+0x3ae7>
   52f47:	movzx  eax,WORD PTR [rcx+0x14]
   52f4b:	and    eax,0x24
   52f4e:	test   eax,eax
   52f50:	je     52f5f <sqlite3VdbeExec+0x3abf>
   52f52:	mov    rax,QWORD PTR [rcx]
   52f55:	xorps  xmm0,xmm0
   52f58:	cvtsi2sd xmm0,rax
   52f5d:	jmp    52f87 <sqlite3VdbeExec+0x3ae7>
   52f5f:	movzx  eax,WORD PTR [rcx+0x14]
   52f63:	and    eax,0x12
   52f66:	test   eax,eax
   52f68:	je     52f84 <sqlite3VdbeExec+0x3ae4>
   52f6a:	mov    QWORD PTR [rsp+0x110],rdi
   52f72:	mov    rdi,rcx
   52f75:	call   52f7a <sqlite3VdbeExec+0x3ada>
   52f7a:	mov    rdi,QWORD PTR [rsp+0x110]
   52f82:	jmp    52f87 <sqlite3VdbeExec+0x3ae7>
   52f84:	xorps  xmm0,xmm0
   52f87:	xorps  xmm1,xmm1
   52f8a:	xor    eax,eax
   52f8c:	ucomisd xmm0,xmm1
   52f90:	setne  al
   52f93:	setp   r11b
   52f97:	or     al,r11b
   52f9a:	test   eax,eax
   52f9c:	mov    eax,0x0
   52fa1:	sete   al
   52fa4:	test   eax,eax
   52fa6:	jne    52f12 <sqlite3VdbeExec+0x3a72>
   52fac:	jmp    52f29 <sqlite3VdbeExec+0x3a89>
   52fb1:	mov    r15d,DWORD PTR [rsp+0x37c]
   52fb9:	mov    QWORD PTR [rsp+0x130],r12
   52fc1:	movsxd rax,DWORD PTR [rbp+0x4]
   52fc5:	imul   rax,rax,0x38
   52fc9:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52fce:	and    eax,0x1
   52fd1:	test   eax,eax
   52fd3:	je     52fdd <sqlite3VdbeExec+0x3b3d>
   52fd5:	mov    r12,r14
   52fd8:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   52fdd:	mov    DWORD PTR [rsp+0x37c],r15d
   52fe5:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   52fea:	mov    r15d,DWORD PTR [rsp+0x37c]
   52ff2:	mov    QWORD PTR [rsp+0x130],r12
   52ffa:	cmp    DWORD PTR [rbp+0x4],0x0
   52ffe:	jl     53058 <sqlite3VdbeExec+0x3bb8>
   53000:	mov    rax,QWORD PTR [rdi+0x78]
   53004:	movsxd rcx,DWORD PTR [rbp+0x4]
   53008:	mov    rax,QWORD PTR [rax+rcx*8]
   5300c:	mov    ecx,DWORD PTR [rbp+0xc]
   5300f:	movzx  edx,WORD PTR [rax+0x42]
   53013:	cmp    ecx,edx
   53015:	jge    53046 <sqlite3VdbeExec+0x3ba6>
   53017:	movsxd rcx,DWORD PTR [rbp+0xc]
   5301b:	mov    eax,DWORD PTR [rax+rcx*4+0x70]
   5301f:	cmp    eax,0xc
   53022:	jb     53039 <sqlite3VdbeExec+0x3b99>
   53024:	and    eax,0x1
   53027:	test   eax,eax
   53029:	je     53032 <sqlite3VdbeExec+0x3b92>
   5302b:	mov    eax,0x4
   53030:	jmp    53037 <sqlite3VdbeExec+0x3b97>
   53032:	mov    eax,0x8
   53037:	jmp    53044 <sqlite3VdbeExec+0x3ba4>
   53039:	lea    rcx,[rip+0x0]        # 53040 <sqlite3VdbeExec+0x3ba0>
   53040:	movzx  eax,BYTE PTR [rcx+rax*1]
   53044:	jmp    53056 <sqlite3VdbeExec+0x3bb6>
   53046:	mov    eax,0x1
   5304b:	mov    ecx,DWORD PTR [rbp+0x10]
   5304e:	sub    ecx,0x1
   53051:	shl    eax,cl
   53053:	movzx  eax,ax
   53056:	jmp    53080 <sqlite3VdbeExec+0x3be0>
   53058:	mov    eax,0x1
   5305d:	movsxd rcx,DWORD PTR [rbp+0xc]
   53061:	imul   rcx,rcx,0x38
   53065:	lea    rdx,[rip+0x0]        # 5306c <sqlite3VdbeExec+0x3bcc>
   5306c:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   53071:	and    ecx,0x3f
   53074:	movzx  ecx,BYTE PTR [rdx+rcx*1]
   53078:	sub    ecx,0x1
   5307b:	shl    eax,cl
   5307d:	movzx  eax,ax
   53080:	movzx  ecx,WORD PTR [rbp+0x2]
   53084:	and    eax,ecx
   53086:	test   eax,eax
   53088:	je     53092 <sqlite3VdbeExec+0x3bf2>
   5308a:	mov    r12,r14
   5308d:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   53092:	mov    DWORD PTR [rsp+0x37c],r15d
   5309a:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5309f:	mov    r15d,DWORD PTR [rsp+0x37c]
   530a7:	mov    QWORD PTR [rsp+0x130],r12
   530af:	movsxd rax,DWORD PTR [rbp+0x4]
   530b3:	imul   rax,rax,0x38
   530b7:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   530bc:	and    eax,0x1
   530bf:	test   eax,eax
   530c1:	jne    530d7 <sqlite3VdbeExec+0x3c37>
   530c3:	movsxd rax,DWORD PTR [rbp+0xc]
   530c7:	imul   rax,rax,0x38
   530cb:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   530d0:	and    eax,0x1
   530d3:	test   eax,eax
   530d5:	je     53113 <sqlite3VdbeExec+0x3c73>
   530d7:	movsxd rax,DWORD PTR [rbp+0x8]
   530db:	imul   rax,rax,0x38
   530df:	lea    rcx,[rbx+rax*1]
   530e3:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   530e8:	and    eax,0x9000
   530ed:	test   eax,eax
   530ef:	je     5310b <sqlite3VdbeExec+0x3c6b>
   530f1:	mov    QWORD PTR [rsp+0x110],rdi
   530f9:	mov    rdi,rcx
   530fc:	call   53101 <sqlite3VdbeExec+0x3c61>
   53101:	mov    rdi,QWORD PTR [rsp+0x110]
   53109:	jmp    53159 <sqlite3VdbeExec+0x3cb9>
   5310b:	mov    WORD PTR [rcx+0x14],0x1
   53111:	jmp    53159 <sqlite3VdbeExec+0x3cb9>
   53113:	movsxd rax,DWORD PTR [rbp+0x8]
   53117:	imul   rax,rax,0x38
   5311b:	lea    rcx,[rbx+rax*1]
   5311f:	xor    edx,edx
   53121:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53126:	and    eax,0x9000
   5312b:	test   eax,eax
   5312d:	je     5314c <sqlite3VdbeExec+0x3cac>
   5312f:	mov    QWORD PTR [rsp+0x110],rdi
   53137:	mov    rdi,rcx
   5313a:	mov    rsi,rdx
   5313d:	call   53142 <sqlite3VdbeExec+0x3ca2>
   53142:	mov    rdi,QWORD PTR [rsp+0x110]
   5314a:	jmp    53159 <sqlite3VdbeExec+0x3cb9>
   5314c:	mov    QWORD PTR [rcx],0x0
   53153:	mov    WORD PTR [rcx+0x14],0x4
   53159:	mov    DWORD PTR [rsp+0x37c],r15d
   53161:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   53166:	mov    r15d,DWORD PTR [rsp+0x37c]
   5316e:	mov    QWORD PTR [rsp+0x130],r12
   53176:	movsxd rax,DWORD PTR [rbp+0x4]
   5317a:	imul   rax,rax,0x38
   5317e:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53183:	and    eax,0x1
   53186:	test   eax,eax
   53188:	jne    53192 <sqlite3VdbeExec+0x3cf2>
   5318a:	mov    r12,r14
   5318d:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   53192:	mov    DWORD PTR [rsp+0x37c],r15d
   5319a:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5319f:	mov    r15d,DWORD PTR [rsp+0x37c]
   531a7:	mov    QWORD PTR [rsp+0x130],r12
   531af:	mov    rax,QWORD PTR [rdi+0x78]
   531b3:	movsxd rcx,DWORD PTR [rbp+0x4]
   531b7:	mov    rax,QWORD PTR [rax+rcx*8]
   531bb:	test   rax,rax
   531be:	je     53208 <sqlite3VdbeExec+0x3d68>
   531c0:	cmp    BYTE PTR [rax+0x2],0x0
   531c4:	je     53208 <sqlite3VdbeExec+0x3d68>
   531c6:	movsxd rax,DWORD PTR [rbp+0xc]
   531ca:	imul   rax,rax,0x38
   531ce:	lea    rcx,[rbx+rax*1]
   531d2:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   531d7:	and    eax,0x9000
   531dc:	test   eax,eax
   531de:	je     531fa <sqlite3VdbeExec+0x3d5a>
   531e0:	mov    QWORD PTR [rsp+0x110],rdi
   531e8:	mov    rdi,rcx
   531eb:	call   531f0 <sqlite3VdbeExec+0x3d50>
   531f0:	mov    rdi,QWORD PTR [rsp+0x110]
   531f8:	jmp    53200 <sqlite3VdbeExec+0x3d60>
   531fa:	mov    WORD PTR [rcx+0x14],0x1
   53200:	mov    r12,r14
   53203:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   53208:	mov    DWORD PTR [rsp+0x37c],r15d
   53210:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   53215:	mov    r15d,DWORD PTR [rsp+0x37c]
   5321d:	mov    QWORD PTR [rsp+0x130],r12
   53225:	mov    rax,QWORD PTR [rdi+0x78]
   53229:	movsxd rcx,DWORD PTR [rbp+0x4]
   5322d:	mov    r12,QWORD PTR [rax+rcx*8]
   53231:	mov    r13d,DWORD PTR [rbp+0x8]
   53235:	mov    DWORD PTR [rsp+0x37c],r15d
   5323d:	jmp    532de <sqlite3VdbeExec+0x3e3e>
   53242:	movsxd rax,DWORD PTR [rbp+0xc]
   53246:	imul   rax,rax,0x38
   5324a:	lea    rcx,[rbx+rax*1]
   5324e:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53253:	and    eax,0x9000
   53258:	test   eax,eax
   5325a:	je     53276 <sqlite3VdbeExec+0x3dd6>
   5325c:	mov    QWORD PTR [rsp+0x110],rdi
   53264:	mov    rdi,rcx
   53267:	call   5326c <sqlite3VdbeExec+0x3dcc>
   5326c:	mov    rdi,QWORD PTR [rsp+0x110]
   53274:	jmp    5327c <sqlite3VdbeExec+0x3ddc>
   53276:	mov    WORD PTR [rcx+0x14],0x1
   5327c:	mov    DWORD PTR [rsp+0x37c],r15d
   53284:	mov    DWORD PTR [rsp+0x38c],r12d
   5328c:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   53291:	mov    QWORD PTR [rsp+0x160],rbx
   53299:	mov    rbx,QWORD PTR [r12+0x28]
   5329e:	cmp    BYTE PTR [r12+0x3],0x0
   532a4:	je     5340c <sqlite3VdbeExec+0x3f6c>
   532aa:	cmp    QWORD PTR [r12+0x8],0x0
   532b0:	je     53358 <sqlite3VdbeExec+0x3eb8>
   532b6:	mov    rax,QWORD PTR [r12+0x8]
   532bb:	lea    ecx,[r13+0x1]
   532bf:	mov    eax,DWORD PTR [rax+rcx*4]
   532c2:	test   eax,eax
   532c4:	jbe    53358 <sqlite3VdbeExec+0x3eb8>
   532ca:	mov    r12,QWORD PTR [r12+0x20]
   532cf:	mov    r13d,eax
   532d2:	sub    r13d,0x1
   532d6:	mov    rbx,QWORD PTR [rsp+0x160]
   532de:	mov    r15,QWORD PTR [r12+0x50]
   532e3:	mov    eax,DWORD PTR [r12+0x18]
   532e8:	cmp    eax,DWORD PTR [rdi+0x2c]
   532eb:	je     536ad <sqlite3VdbeExec+0x420d>
   532f1:	cmp    BYTE PTR [r12+0x2],0x0
   532f7:	je     53291 <sqlite3VdbeExec+0x3df1>
   532f9:	cmp    BYTE PTR [r12],0x3
   532fe:	je     53315 <sqlite3VdbeExec+0x3e75>
   53300:	mov    r15d,DWORD PTR [rsp+0x37c]
   53308:	mov    r12d,DWORD PTR [rsp+0x38c]
   53310:	jmp    53242 <sqlite3VdbeExec+0x3da2>
   53315:	cmp    DWORD PTR [r12+0x1c],0x0
   5331b:	jg     53332 <sqlite3VdbeExec+0x3e92>
   5331d:	mov    r15d,DWORD PTR [rsp+0x37c]
   53325:	mov    r12d,DWORD PTR [rsp+0x38c]
   5332d:	jmp    53242 <sqlite3VdbeExec+0x3da2>
   53332:	movsxd rax,DWORD PTR [r12+0x1c]
   53337:	imul   rax,rax,0x38
   5333b:	mov    ecx,DWORD PTR [rbx+rax*1+0x10]
   5333f:	mov    DWORD PTR [r12+0x64],ecx
   53344:	mov    DWORD PTR [r12+0x60],ecx
   53349:	mov    rax,QWORD PTR [rbx+rax*1+0x8]
   5334e:	mov    QWORD PTR [r12+0x58],rax
   53353:	jmp    5348f <sqlite3VdbeExec+0x3fef>
   53358:	mov    QWORD PTR [rsp+0x128],r14
   53360:	mov    QWORD PTR [rsp+0x110],rdi
   53368:	mov    rdi,r12
   5336b:	call   53370 <sqlite3VdbeExec+0x3ed0>
   53370:	mov    r14d,eax
   53373:	mov    rdi,QWORD PTR [rsp+0x110]
   5337b:	test   r14d,r14d
   5337e:	je     533a8 <sqlite3VdbeExec+0x3f08>
   53380:	mov    QWORD PTR [rsp+0x148],rbp
   53388:	mov    rbp,r14
   5338b:	mov    r14,QWORD PTR [rsp+0x128]
   53393:	mov    r13,QWORD PTR [rsp+0x130]
   5339b:	mov    rbx,QWORD PTR [rsp+0x158]
   533a3:	jmp    4f712 <sqlite3VdbeExec+0x272>
   533a8:	mov    DWORD PTR [rsp+0x38c],r14d
   533b0:	mov    r14,QWORD PTR [rsp+0x128]
   533b8:	mov    QWORD PTR [rsp+0x110],rdi
   533c0:	mov    rdi,rbx
   533c3:	call   533c8 <sqlite3VdbeExec+0x3f28>
   533c8:	mov    eax,DWORD PTR [rbx+0x40]
   533cb:	mov    DWORD PTR [r12+0x60],eax
   533d0:	movzx  eax,WORD PTR [rbx+0x44]
   533d4:	mov    rcx,QWORD PTR [rbx+0x88]
   533db:	mov    rcx,QWORD PTR [rcx+0x58]
   533df:	sub    rcx,QWORD PTR [rbx+0x38]
   533e3:	mov    rdi,QWORD PTR [rsp+0x110]
   533eb:	cmp    eax,ecx
   533ed:	jle    53479 <sqlite3VdbeExec+0x3fd9>
   533f3:	xor    eax,eax
   533f5:	mov    rcx,QWORD PTR [rbx+0x88]
   533fc:	mov    rcx,QWORD PTR [rcx+0x58]
   53400:	sub    rcx,QWORD PTR [rbx+0x38]
   53404:	cmp    eax,ecx
   53406:	jle    5346a <sqlite3VdbeExec+0x3fca>
   53408:	xor    eax,eax
   5340a:	jmp    53479 <sqlite3VdbeExec+0x3fd9>
   5340c:	xor    eax,eax
   5340e:	movzx  ecx,BYTE PTR [rbx]
   53411:	cmp    eax,ecx
   53413:	je     533b8 <sqlite3VdbeExec+0x3f18>
   53415:	mov    QWORD PTR [rsp+0x110],rdi
   5341d:	mov    rdi,r12
   53420:	call   53425 <sqlite3VdbeExec+0x3f85>
   53425:	mov    ebx,eax
   53427:	mov    rdi,QWORD PTR [rsp+0x110]
   5342f:	test   ebx,ebx
   53431:	je     53453 <sqlite3VdbeExec+0x3fb3>
   53433:	mov    QWORD PTR [rsp+0x148],rbp
   5343b:	mov    rbp,rbx
   5343e:	mov    r13,QWORD PTR [rsp+0x130]
   53446:	mov    rbx,QWORD PTR [rsp+0x158]
   5344e:	jmp    4f712 <sqlite3VdbeExec+0x272>
   53453:	mov    r15,QWORD PTR [rsp+0x160]
   5345b:	mov    DWORD PTR [rsp+0x38c],ebx
   53462:	mov    rbx,r15
   53465:	jmp    532de <sqlite3VdbeExec+0x3e3e>
   5346a:	mov    rax,QWORD PTR [rbx+0x88]
   53471:	mov    rax,QWORD PTR [rax+0x58]
   53475:	sub    rax,QWORD PTR [rbx+0x38]
   53479:	mov    DWORD PTR [r12+0x64],eax
   5347e:	mov    rax,QWORD PTR [rbx+0x38]
   53482:	mov    QWORD PTR [r12+0x58],rax
   53487:	mov    rbx,QWORD PTR [rsp+0x160]
   5348f:	mov    eax,DWORD PTR [rdi+0x2c]
   53492:	mov    DWORD PTR [r12+0x18],eax
   53497:	mov    rax,QWORD PTR [r12+0x58]
   5349c:	movzx  eax,BYTE PTR [rax]
   5349f:	mov    DWORD PTR [r15],eax
   534a2:	cmp    eax,0x80
   534a7:	jae    534b7 <sqlite3VdbeExec+0x4017>
   534a9:	mov    DWORD PTR [r12+0x38],0x1
   534b2:	jmp    53579 <sqlite3VdbeExec+0x40d9>
   534b7:	mov    rax,QWORD PTR [r12+0x58]
   534bc:	movzx  ecx,BYTE PTR [rax+0x1]
   534c0:	and    ecx,0x80
   534c6:	test   ecx,ecx
   534c8:	jne    534e6 <sqlite3VdbeExec+0x4046>
   534ca:	movzx  ecx,BYTE PTR [rax]
   534cd:	and    ecx,0x7f
   534d0:	shl    ecx,0x7
   534d3:	movzx  eax,BYTE PTR [rax+0x1]
   534d7:	or     ecx,eax
   534d9:	mov    DWORD PTR [r15],ecx
   534dc:	mov    eax,0x2
   534e1:	jmp    53574 <sqlite3VdbeExec+0x40d4>
   534e6:	movzx  ecx,BYTE PTR [rax+0x2]
   534ea:	and    ecx,0x80
   534f0:	test   ecx,ecx
   534f2:	jne    53519 <sqlite3VdbeExec+0x4079>
   534f4:	movzx  ecx,BYTE PTR [rax]
   534f7:	and    ecx,0x7f
   534fa:	shl    ecx,0xe
   534fd:	movzx  edx,BYTE PTR [rax+0x1]
   53501:	and    edx,0x7f
   53504:	shl    edx,0x7
   53507:	or     ecx,edx
   53509:	movzx  eax,BYTE PTR [rax+0x2]
   5350d:	or     ecx,eax
   5350f:	mov    DWORD PTR [r15],ecx
   53512:	mov    eax,0x3
   53517:	jmp    53574 <sqlite3VdbeExec+0x40d4>
   53519:	mov    DWORD PTR [rsp+0x39c],r13d
   53521:	mov    r13,rbx
   53524:	lea    rbx,[rsp+0x170]
   5352c:	mov    rcx,rbx
   5352f:	mov    QWORD PTR [rsp+0x110],rdi
   53537:	mov    rdi,rax
   5353a:	mov    rsi,rcx
   5353d:	call   53542 <sqlite3VdbeExec+0x40a2>
   53542:	movzx  eax,al
   53545:	mov    ecx,0xffffffff
   5354a:	and    rcx,QWORD PTR [rbx]
   5354d:	mov    rdi,QWORD PTR [rsp+0x110]
   53555:	cmp    rcx,QWORD PTR [rbx]
   53558:	je     53563 <sqlite3VdbeExec+0x40c3>
   5355a:	mov    DWORD PTR [r15],0xffffffff
   53561:	jmp    53569 <sqlite3VdbeExec+0x40c9>
   53563:	mov    rcx,QWORD PTR [rbx]
   53566:	mov    DWORD PTR [r15],ecx
   53569:	mov    rbx,r13
   5356c:	mov    r13d,DWORD PTR [rsp+0x39c]
   53574:	mov    DWORD PTR [r12+0x38],eax
   53579:	mov    WORD PTR [r12+0x42],0x0
   53581:	mov    eax,DWORD PTR [r12+0x64]
   53586:	cmp    eax,DWORD PTR [r15]
   53589:	jae    535e3 <sqlite3VdbeExec+0x4143>
   5358b:	mov    QWORD PTR [r12+0x58],0x0
   53594:	mov    DWORD PTR [r12+0x64],0x0
   5359d:	cmp    DWORD PTR [r15],0x18003
   535a4:	ja     535b0 <sqlite3VdbeExec+0x4110>
   535a6:	mov    eax,DWORD PTR [r15]
   535a9:	cmp    eax,DWORD PTR [r12+0x60]
   535ae:	jbe    535f5 <sqlite3VdbeExec+0x4155>
   535b0:	mov    r13,QWORD PTR [rsp+0x150]
   535b8:	cmp    DWORD PTR [r13+0xc],0x0
   535bd:	jle    53f96 <sqlite3VdbeExec+0x4af6>
   535c3:	mov    eax,DWORD PTR [r13+0xc]
   535c7:	sub    eax,0x1
   535ca:	movsxd rax,eax
   535cd:	imul   rax,rax,0x18
   535d1:	lea    rbp,[r13+rax*1+0x0]
   535d6:	mov    QWORD PTR [rsp+0x150],r13
   535de:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   535e3:	mov    DWORD PTR [rsp+0x39c],r13d
   535eb:	mov    r13,QWORD PTR [r12+0x58]
   535f0:	jmp    53761 <sqlite3VdbeExec+0x42c1>
   535f5:	mov    DWORD PTR [rsp+0x39c],r13d
   535fd:	mov    r13d,DWORD PTR [rsp+0x39c]
   53605:	movzx  eax,WORD PTR [r12+0x42]
   5360b:	cmp    eax,r13d
   5360e:	ja     53b9e <sqlite3VdbeExec+0x46fe>
   53614:	mov    eax,DWORD PTR [r12+0x38]
   53619:	cmp    eax,DWORD PTR [r15]
   5361c:	jae    53aa8 <sqlite3VdbeExec+0x4608>
   53622:	cmp    QWORD PTR [r12+0x58],0x0
   53628:	jne    53741 <sqlite3VdbeExec+0x42a1>
   5362e:	mov    QWORD PTR [rsp+0x128],r14
   53636:	lea    r14,[rsp+0x240]
   5363e:	mov    rax,r14
   53641:	xor    ecx,ecx
   53643:	mov    edx,0x38
   53648:	mov    QWORD PTR [rsp+0x110],rdi
   53650:	mov    rdi,rax
   53653:	mov    rsi,rcx
   53656:	call   5365b <sqlite3VdbeExec+0x41bb>
   5365b:	mov    rax,QWORD PTR [r12+0x28]
   53660:	mov    ecx,DWORD PTR [r15]
   53663:	mov    rdx,r14
   53666:	mov    rdi,rax
   53669:	mov    rsi,rcx
   5366c:	call   53671 <sqlite3VdbeExec+0x41d1>
   53671:	mov    r14d,eax
   53674:	mov    rdi,QWORD PTR [rsp+0x110]
   5367c:	test   r14d,r14d
   5367f:	je     5370c <sqlite3VdbeExec+0x426c>
   53685:	mov    QWORD PTR [rsp+0x148],rbp
   5368d:	mov    rbp,r14
   53690:	mov    r14,QWORD PTR [rsp+0x128]
   53698:	mov    r13,QWORD PTR [rsp+0x130]
   536a0:	mov    rbx,QWORD PTR [rsp+0x158]
   536a8:	jmp    4f712 <sqlite3VdbeExec+0x272>
   536ad:	mov    rax,QWORD PTR [r12+0x28]
   536b2:	xor    ecx,ecx
   536b4:	movzx  eax,BYTE PTR [rax]
   536b7:	cmp    ecx,eax
   536b9:	je     53605 <sqlite3VdbeExec+0x4165>
   536bf:	mov    QWORD PTR [rsp+0x110],rdi
   536c7:	mov    rdi,r12
   536ca:	call   536cf <sqlite3VdbeExec+0x422f>
   536cf:	mov    r15d,eax
   536d2:	mov    rdi,QWORD PTR [rsp+0x110]
   536da:	test   r15d,r15d
   536dd:	je     536ff <sqlite3VdbeExec+0x425f>
   536df:	mov    QWORD PTR [rsp+0x148],rbp
   536e7:	mov    rbp,r15
   536ea:	mov    r13,QWORD PTR [rsp+0x130]
   536f2:	mov    rbx,QWORD PTR [rsp+0x158]
   536fa:	jmp    4f712 <sqlite3VdbeExec+0x272>
   536ff:	mov    DWORD PTR [rsp+0x38c],r15d
   53707:	jmp    532de <sqlite3VdbeExec+0x3e3e>
   5370c:	mov    DWORD PTR [rsp+0x398],r14d
   53714:	mov    r14,QWORD PTR [rsp+0x248]
   5371c:	mov    DWORD PTR [rsp+0x39c],r13d
   53724:	mov    r11d,DWORD PTR [rsp+0x398]
   5372c:	mov    DWORD PTR [rsp+0x38c],r11d
   53734:	mov    r13,r14
   53737:	mov    r14,QWORD PTR [rsp+0x128]
   5373f:	jmp    53761 <sqlite3VdbeExec+0x42c1>
   53741:	mov    QWORD PTR [rsp+0x128],r14
   53749:	mov    r14,QWORD PTR [r12+0x58]
   5374e:	mov    DWORD PTR [rsp+0x39c],r13d
   53756:	mov    r13,r14
   53759:	mov    r14,QWORD PTR [rsp+0x128]
   53761:	movzx  eax,WORD PTR [r12+0x42]
   53767:	mov    QWORD PTR [rsp+0x160],rbx
   5376f:	mov    ebx,eax
   53771:	mov    rax,rbx
   53774:	mov    eax,DWORD PTR [r15+rax*4]
   53778:	mov    DWORD PTR [rsp+0x398],ebx
   5377f:	mov    rbx,rax
   53782:	mov    eax,DWORD PTR [r12+0x38]
   53787:	mov    QWORD PTR [rsp+0x178],rbx
   5378f:	lea    rbx,[r13+rax*1+0x0]
   53794:	mov    eax,DWORD PTR [r15]
   53797:	mov    QWORD PTR [rsp+0x180],rbx
   5379f:	lea    rbx,[r13+rax*1+0x0]
   537a4:	mov    QWORD PTR [rsp+0x168],r15
   537ac:	mov    QWORD PTR [rsp+0x170],r13
   537b4:	mov    QWORD PTR [rsp+0x188],rbx
   537bc:	mov    r13d,DWORD PTR [rsp+0x398]
   537c4:	mov    rbx,QWORD PTR [rsp+0x180]
   537cc:	mov    r15,QWORD PTR [rsp+0x178]
   537d4:	movsxd rax,r13d
   537d7:	movzx  ecx,BYTE PTR [rbx]
   537da:	mov    DWORD PTR [rsp+0x3a0],ecx
   537e1:	mov    DWORD PTR [r12+rax*4+0x70],ecx
   537e6:	cmp    ecx,0x80
   537ec:	jae    5380f <sqlite3VdbeExec+0x436f>
   537ee:	add    rbx,0x1
   537f2:	mov    eax,DWORD PTR [rsp+0x3a0]
   537f9:	movzx  eax,al
   537fc:	lea    rcx,[rip+0x0]        # 53803 <sqlite3VdbeExec+0x4363>
   53803:	movzx  eax,BYTE PTR [rcx+rax*1]
   53807:	add    r15,rax
   5380a:	jmp    5390d <sqlite3VdbeExec+0x446d>
   5380f:	movzx  eax,BYTE PTR [rbx+0x1]
   53813:	and    eax,0x80
   53818:	test   eax,eax
   5381a:	jne    5383c <sqlite3VdbeExec+0x439c>
   5381c:	movzx  eax,BYTE PTR [rbx]
   5381f:	and    eax,0x7f
   53822:	shl    eax,0x7
   53825:	movzx  ecx,BYTE PTR [rbx+0x1]
   53829:	or     eax,ecx
   5382b:	mov    DWORD PTR [rsp+0x3a0],eax
   53832:	mov    eax,0x2
   53837:	jmp    538d8 <sqlite3VdbeExec+0x4438>
   5383c:	movzx  eax,BYTE PTR [rbx+0x2]
   53840:	and    eax,0x80
   53845:	test   eax,eax
   53847:	jne    53872 <sqlite3VdbeExec+0x43d2>
   53849:	movzx  eax,BYTE PTR [rbx]
   5384c:	and    eax,0x7f
   5384f:	shl    eax,0xe
   53852:	movzx  ecx,BYTE PTR [rbx+0x1]
   53856:	and    ecx,0x7f
   53859:	shl    ecx,0x7
   5385c:	or     eax,ecx
   5385e:	movzx  ecx,BYTE PTR [rbx+0x2]
   53862:	or     eax,ecx
   53864:	mov    DWORD PTR [rsp+0x3a0],eax
   5386b:	mov    eax,0x3
   53870:	jmp    538d8 <sqlite3VdbeExec+0x4438>
   53872:	mov    QWORD PTR [rsp+0x178],r15
   5387a:	mov    r15,rbp
   5387d:	lea    rbp,[rsp+0x180]
   53885:	mov    rax,rbp
   53888:	mov    QWORD PTR [rsp+0x110],rdi
   53890:	mov    rdi,rbx
   53893:	mov    rsi,rax
   53896:	call   5389b <sqlite3VdbeExec+0x43fb>
   5389b:	movzx  eax,al
   5389e:	mov    ecx,0xffffffff
   538a3:	and    rcx,QWORD PTR [rbp+0x0]
   538a7:	mov    rdi,QWORD PTR [rsp+0x110]
   538af:	cmp    rcx,QWORD PTR [rbp+0x0]
   538b3:	je     538c2 <sqlite3VdbeExec+0x4422>
   538b5:	mov    DWORD PTR [rsp+0x3a0],0xffffffff
   538c0:	jmp    538cd <sqlite3VdbeExec+0x442d>
   538c2:	mov    rcx,QWORD PTR [rbp+0x0]
   538c6:	mov    DWORD PTR [rsp+0x3a0],ecx
   538cd:	mov    rbp,r15
   538d0:	mov    r15,QWORD PTR [rsp+0x178]
   538d8:	add    rbx,rax
   538db:	movsxd rax,r13d
   538de:	mov    ecx,DWORD PTR [rsp+0x3a0]
   538e5:	mov    DWORD PTR [r12+rax*4+0x70],ecx
   538ea:	mov    eax,DWORD PTR [rsp+0x3a0]
   538f1:	cmp    eax,0x80
   538f6:	jb     538ff <sqlite3VdbeExec+0x445f>
   538f8:	sub    eax,0xc
   538fb:	shr    eax,1
   538fd:	jmp    5390a <sqlite3VdbeExec+0x446a>
   538ff:	lea    rcx,[rip+0x0]        # 53906 <sqlite3VdbeExec+0x4466>
   53906:	movzx  eax,BYTE PTR [rcx+rax*1]
   5390a:	add    r15,rax
   5390d:	add    r13d,0x1
   53911:	movsxd rax,r13d
   53914:	mov    ecx,0xffffffff
   53919:	and    rcx,r15
   5391c:	mov    QWORD PTR [rsp+0x128],r14
   53924:	mov    r14,QWORD PTR [rsp+0x168]
   5392c:	mov    DWORD PTR [r14+rax*4],ecx
   53930:	mov    QWORD PTR [rsp+0x148],rbp
   53938:	mov    ebp,DWORD PTR [rsp+0x39c]
   5393f:	cmp    r13d,ebp
   53942:	jbe    5394e <sqlite3VdbeExec+0x44ae>
   53944:	mov    rbp,QWORD PTR [rsp+0x188]
   5394c:	jmp    53978 <sqlite3VdbeExec+0x44d8>
   5394e:	mov    rbp,QWORD PTR [rsp+0x188]
   53956:	cmp    rbx,rbp
   53959:	jae    53978 <sqlite3VdbeExec+0x44d8>
   5395b:	mov    QWORD PTR [rsp+0x168],r14
   53963:	mov    r14,QWORD PTR [rsp+0x128]
   5396b:	mov    rbp,QWORD PTR [rsp+0x148]
   53973:	jmp    537d4 <sqlite3VdbeExec+0x4334>
   53978:	cmp    rbx,rbp
   5397b:	jb     5398c <sqlite3VdbeExec+0x44ec>
   5397d:	cmp    rbx,rbp
   53980:	ja     539a6 <sqlite3VdbeExec+0x4506>
   53982:	mov    eax,DWORD PTR [r12+0x60]
   53987:	cmp    r15,rax
   5398a:	jne    539a6 <sqlite3VdbeExec+0x4506>
   5398c:	mov    eax,DWORD PTR [r12+0x60]
   53991:	cmp    r15,rax
   53994:	ja     539a6 <sqlite3VdbeExec+0x4506>
   53996:	mov    rbp,rbx
   53999:	mov    rbx,r13
   5399c:	mov    r13,QWORD PTR [rsp+0x170]
   539a4:	jmp    539ba <sqlite3VdbeExec+0x451a>
   539a6:	cmp    DWORD PTR [r14],0x0
   539aa:	jne    53a40 <sqlite3VdbeExec+0x45a0>
   539b0:	xor    ebx,ebx
   539b2:	mov    r13,QWORD PTR [rsp+0x170]
   539ba:	mov    WORD PTR [r12+0x42],bx
   539c0:	mov    rax,rbp
   539c3:	sub    rax,r13
   539c6:	mov    DWORD PTR [r12+0x38],eax
   539cb:	cmp    QWORD PTR [r12+0x58],0x0
   539d1:	je     539dd <sqlite3VdbeExec+0x453d>
   539d3:	lea    rbx,[rsp+0x240]
   539db:	jmp    53a18 <sqlite3VdbeExec+0x4578>
   539dd:	lea    rbx,[rsp+0x240]
   539e5:	mov    rax,rbx
   539e8:	movzx  ecx,WORD PTR [rsp+0x254]
   539f0:	and    ecx,0x9000
   539f6:	test   ecx,ecx
   539f8:	jne    53a00 <sqlite3VdbeExec+0x4560>
   539fa:	cmp    DWORD PTR [rax+0x20],0x0
   539fe:	je     53a18 <sqlite3VdbeExec+0x4578>
   53a00:	mov    QWORD PTR [rsp+0x110],rdi
   53a08:	mov    rdi,rax
   53a0b:	call   53a10 <sqlite3VdbeExec+0x4570>
   53a10:	mov    rdi,QWORD PTR [rsp+0x110]
   53a18:	mov    r13d,DWORD PTR [rsp+0x39c]
   53a20:	mov    r15,r14
   53a23:	mov    r14,QWORD PTR [rsp+0x128]
   53a2b:	mov    rbp,QWORD PTR [rsp+0x148]
   53a33:	mov    rbx,QWORD PTR [rsp+0x160]
   53a3b:	jmp    53ac3 <sqlite3VdbeExec+0x4623>
   53a40:	lea    rbx,[rsp+0x240]
   53a48:	cmp    QWORD PTR [r12+0x58],0x0
   53a4e:	jne    53a83 <sqlite3VdbeExec+0x45e3>
   53a50:	mov    rax,rbx
   53a53:	movzx  ecx,WORD PTR [rsp+0x254]
   53a5b:	and    ecx,0x9000
   53a61:	test   ecx,ecx
   53a63:	jne    53a6b <sqlite3VdbeExec+0x45cb>
   53a65:	cmp    DWORD PTR [rax+0x20],0x0
   53a69:	je     53a83 <sqlite3VdbeExec+0x45e3>
   53a6b:	mov    QWORD PTR [rsp+0x110],rdi
   53a73:	mov    rdi,rax
   53a76:	call   53a7b <sqlite3VdbeExec+0x45db>
   53a7b:	mov    rdi,QWORD PTR [rsp+0x110]
   53a83:	mov    r14,QWORD PTR [rsp+0x128]
   53a8b:	mov    r13,QWORD PTR [rsp+0x150]
   53a93:	mov    rbp,QWORD PTR [rsp+0x148]
   53a9b:	mov    rbx,QWORD PTR [rsp+0x160]
   53aa3:	jmp    535b8 <sqlite3VdbeExec+0x4118>
   53aa8:	mov    QWORD PTR [rsp+0x128],r14
   53ab0:	mov    DWORD PTR [rsp+0x3a0],0x0
   53abb:	mov    r14,QWORD PTR [rsp+0x128]
   53ac3:	movzx  eax,WORD PTR [r12+0x42]
   53ac9:	cmp    eax,r13d
   53acc:	ja     53b9c <sqlite3VdbeExec+0x46fc>
   53ad2:	movsxd rax,DWORD PTR [rbp+0xc]
   53ad6:	imul   rax,rax,0x38
   53ada:	add    rax,rbx
   53add:	cmp    BYTE PTR [rbp+0x1],0xf5
   53ae1:	jne    53b59 <sqlite3VdbeExec+0x46b9>
   53ae3:	mov    rcx,QWORD PTR [rbp+0x10]
   53ae7:	mov    edx,0x2000
   53aec:	movzx  esi,WORD PTR [rax+0x14]
   53af0:	and    esi,0x9000
   53af6:	test   esi,esi
   53af8:	je     53b17 <sqlite3VdbeExec+0x4677>
   53afa:	mov    QWORD PTR [rsp+0x110],rdi
   53b02:	mov    rdi,rax
   53b05:	mov    rsi,rcx
   53b08:	call   53b0d <sqlite3VdbeExec+0x466d>
   53b0d:	mov    rdi,QWORD PTR [rsp+0x110]
   53b15:	jmp    53b87 <sqlite3VdbeExec+0x46e7>
   53b17:	mov    rdx,QWORD PTR [rcx]
   53b1a:	mov    QWORD PTR [rax],rdx
   53b1d:	mov    rdx,QWORD PTR [rcx+0x8]
   53b21:	mov    QWORD PTR [rax+0x8],rdx
   53b25:	mov    rdx,QWORD PTR [rcx+0x10]
   53b29:	mov    QWORD PTR [rax+0x10],rdx
   53b2d:	movzx  ecx,WORD PTR [rcx+0x14]
   53b31:	and    ecx,0x2000
   53b37:	test   ecx,ecx
   53b39:	jne    53b87 <sqlite3VdbeExec+0x46e7>
   53b3b:	movzx  ecx,WORD PTR [rax+0x14]
   53b3f:	and    ecx,0xffff8fff
   53b45:	mov    WORD PTR [rax+0x14],cx
   53b49:	movzx  ecx,WORD PTR [rax+0x14]
   53b4d:	or     ecx,0x2000
   53b53:	mov    WORD PTR [rax+0x14],cx
   53b57:	jmp    53b87 <sqlite3VdbeExec+0x46e7>
   53b59:	movzx  ecx,WORD PTR [rax+0x14]
   53b5d:	and    ecx,0x9000
   53b63:	test   ecx,ecx
   53b65:	je     53b81 <sqlite3VdbeExec+0x46e1>
   53b67:	mov    QWORD PTR [rsp+0x110],rdi
   53b6f:	mov    rdi,rax
   53b72:	call   53b77 <sqlite3VdbeExec+0x46d7>
   53b77:	mov    rdi,QWORD PTR [rsp+0x110]
   53b7f:	jmp    53b87 <sqlite3VdbeExec+0x46e7>
   53b81:	mov    WORD PTR [rax+0x14],0x1
   53b87:	mov    r15d,DWORD PTR [rsp+0x37c]
   53b8f:	mov    r12d,DWORD PTR [rsp+0x38c]
   53b97:	jmp    5327c <sqlite3VdbeExec+0x3ddc>
   53b9c:	jmp    53bbd <sqlite3VdbeExec+0x471d>
   53b9e:	mov    QWORD PTR [rsp+0x128],r14
   53ba6:	mov    eax,r13d
   53ba9:	mov    eax,DWORD PTR [r12+rax*4+0x70]
   53bae:	mov    DWORD PTR [rsp+0x3a0],eax
   53bb5:	mov    r14,QWORD PTR [rsp+0x128]
   53bbd:	movsxd rax,DWORD PTR [rbp+0xc]
   53bc1:	imul   rax,rax,0x38
   53bc5:	mov    QWORD PTR [rsp+0x128],r14
   53bcd:	lea    r14,[rbx+rax*1]
   53bd1:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53bd6:	and    eax,0x9000
   53bdb:	test   eax,eax
   53bdd:	je     53c0e <sqlite3VdbeExec+0x476e>
   53bdf:	movzx  eax,WORD PTR [r14+0x14]
   53be4:	and    eax,0x9000
   53be9:	test   eax,eax
   53beb:	je     53c07 <sqlite3VdbeExec+0x4767>
   53bed:	mov    QWORD PTR [rsp+0x110],rdi
   53bf5:	mov    rdi,r14
   53bf8:	call   53bfd <sqlite3VdbeExec+0x475d>
   53bfd:	mov    rdi,QWORD PTR [rsp+0x110]
   53c05:	jmp    53c0e <sqlite3VdbeExec+0x476e>
   53c07:	mov    WORD PTR [r14+0x14],0x1
   53c0e:	mov    eax,DWORD PTR [r12+0x64]
   53c13:	lea    ecx,[r13+0x1]
   53c17:	cmp    eax,DWORD PTR [r15+rcx*4]
   53c1b:	jb     53de3 <sqlite3VdbeExec+0x4943>
   53c21:	mov    rax,QWORD PTR [r12+0x58]
   53c26:	mov    ecx,r13d
   53c29:	mov    ecx,DWORD PTR [r15+rcx*4]
   53c2d:	lea    r12,[rax+rcx*1]
   53c31:	cmp    DWORD PTR [rsp+0x3a0],0xc
   53c39:	jae    53c75 <sqlite3VdbeExec+0x47d5>
   53c3b:	mov    eax,DWORD PTR [rsp+0x3a0]
   53c42:	mov    QWORD PTR [rsp+0x110],rdi
   53c4a:	mov    rdi,r12
   53c4d:	mov    rsi,rax
   53c50:	mov    rdx,r14
   53c53:	call   53c58 <sqlite3VdbeExec+0x47b8>
   53c58:	mov    rdi,QWORD PTR [rsp+0x110]
   53c60:	mov    QWORD PTR [rsp+0x148],rbp
   53c68:	mov    rbp,QWORD PTR [rsp+0x128]
   53c70:	jmp    53dc3 <sqlite3VdbeExec+0x4923>
   53c75:	mov    r15d,DWORD PTR [rsp+0x37c]
   53c7d:	mov    eax,DWORD PTR [rsp+0x3a0]
   53c84:	sub    eax,0xc
   53c87:	mov    r13d,eax
   53c8a:	shr    r13d,1
   53c8d:	mov    DWORD PTR [r14+0x10],r13d
   53c91:	mov    BYTE PTR [r14+0x16],r15b
   53c95:	lea    eax,[r13+0x2]
   53c99:	cmp    eax,DWORD PTR [r14+0x20]
   53c9d:	jle    53d4c <sqlite3VdbeExec+0x48ac>
   53ca3:	mov    QWORD PTR [rsp+0x148],rbp
   53cab:	mov    rbp,QWORD PTR [rsp+0x128]
   53cb3:	cmp    r13d,DWORD PTR [rbp+0x88]
   53cba:	jle    53cfd <sqlite3VdbeExec+0x485d>
   53cbc:	lea    rax,[rip+0x0]        # 53cc3 <sqlite3VdbeExec+0x4823>
   53cc3:	mov    QWORD PTR [rsp+0x110],rdi
   53ccb:	mov    rsi,rax
   53cce:	xor    eax,eax
   53cd0:	call   53cd5 <sqlite3VdbeExec+0x4835>
   53cd5:	mov    ebx,0x12
   53cda:	mov    rdi,QWORD PTR [rsp+0x110]
   53ce2:	mov    r14,rbp
   53ce5:	mov    rbp,rbx
   53ce8:	mov    r13,QWORD PTR [rsp+0x130]
   53cf0:	mov    rbx,QWORD PTR [rsp+0x158]
   53cf8:	jmp    4f712 <sqlite3VdbeExec+0x272>
   53cfd:	mov    WORD PTR [r14+0x14],0x1
   53d04:	lea    eax,[r13+0x2]
   53d08:	xor    ecx,ecx
   53d0a:	mov    QWORD PTR [rsp+0x110],rdi
   53d12:	mov    rdi,r14
   53d15:	mov    rsi,rax
   53d18:	mov    rdx,rcx
   53d1b:	call   53d20 <sqlite3VdbeExec+0x4880>
   53d20:	mov    rdi,QWORD PTR [rsp+0x110]
   53d28:	test   eax,eax
   53d2a:	je     53d64 <sqlite3VdbeExec+0x48c4>
   53d2c:	mov    r14,rbp
   53d2f:	mov    r13,QWORD PTR [rsp+0x150]
   53d37:	mov    rbx,QWORD PTR [rsp+0x148]
   53d3f:	mov    rbp,QWORD PTR [rsp+0x158]
   53d47:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   53d4c:	mov    QWORD PTR [rsp+0x148],rbp
   53d54:	mov    rbp,QWORD PTR [rsp+0x128]
   53d5c:	mov    rax,QWORD PTR [r14+0x28]
   53d60:	mov    QWORD PTR [r14+0x8],rax
   53d64:	mov    rax,QWORD PTR [r14+0x8]
   53d68:	mov    DWORD PTR [rsp+0x37c],r15d
   53d70:	mov    r15,r13
   53d73:	mov    QWORD PTR [rsp+0x110],rdi
   53d7b:	mov    rdi,rax
   53d7e:	mov    rsi,r12
   53d81:	mov    rdx,r15
   53d84:	call   53d89 <sqlite3VdbeExec+0x48e9>
   53d89:	mov    rax,QWORD PTR [r14+0x8]
   53d8d:	mov    BYTE PTR [rax+r15*1],0x0
   53d92:	mov    rax,QWORD PTR [r14+0x8]
   53d96:	lea    ecx,[r13+0x1]
   53d9a:	movsxd rcx,ecx
   53d9d:	mov    BYTE PTR [rax+rcx*1],0x0
   53da1:	lea    rax,[rip+0x0]        # 53da8 <sqlite3VdbeExec+0x4908>
   53da8:	mov    ecx,DWORD PTR [rsp+0x3a0]
   53daf:	and    ecx,0x1
   53db2:	movzx  eax,WORD PTR [rax+rcx*2]
   53db6:	mov    WORD PTR [r14+0x14],ax
   53dbb:	mov    rdi,QWORD PTR [rsp+0x110]
   53dc3:	mov    r14,rbp
   53dc6:	mov    r15d,DWORD PTR [rsp+0x37c]
   53dce:	mov    rbp,QWORD PTR [rsp+0x148]
   53dd6:	mov    r12d,DWORD PTR [rsp+0x38c]
   53dde:	jmp    5327c <sqlite3VdbeExec+0x3ddc>
   53de3:	mov    QWORD PTR [rsp+0x160],rbx
   53deb:	mov    ebx,DWORD PTR [rsp+0x37c]
   53df2:	mov    BYTE PTR [r14+0x16],bl
   53df6:	movzx  eax,WORD PTR [rbp+0x2]
   53dfa:	and    eax,0xc0
   53dff:	mov    ecx,eax
   53e01:	test   ecx,ecx
   53e03:	je     53e2e <sqlite3VdbeExec+0x498e>
   53e05:	mov    ecx,eax
   53e07:	cmp    ecx,0x80
   53e0d:	je     53e56 <sqlite3VdbeExec+0x49b6>
   53e0f:	cmp    DWORD PTR [rsp+0x3a0],0xc
   53e17:	jb     53e2e <sqlite3VdbeExec+0x498e>
   53e19:	mov    ecx,DWORD PTR [rsp+0x3a0]
   53e20:	and    ecx,0x1
   53e23:	test   ecx,ecx
   53e25:	je     53e56 <sqlite3VdbeExec+0x49b6>
   53e27:	cmp    eax,0xc0
   53e2c:	je     53e56 <sqlite3VdbeExec+0x49b6>
   53e2e:	mov    eax,DWORD PTR [rsp+0x3a0]
   53e35:	cmp    eax,0x80
   53e3a:	jb     53ea2 <sqlite3VdbeExec+0x4a02>
   53e3c:	sub    eax,0xc
   53e3f:	shr    eax,1
   53e41:	test   eax,eax
   53e43:	je     53e56 <sqlite3VdbeExec+0x49b6>
   53e45:	mov    DWORD PTR [rsp+0x37c],ebx
   53e4c:	mov    rbx,QWORD PTR [rsp+0x160]
   53e54:	jmp    53ecf <sqlite3VdbeExec+0x4a2f>
   53e56:	lea    rax,[rip+0x0]        # 53e5d <sqlite3VdbeExec+0x49bd>
   53e5d:	mov    ecx,DWORD PTR [rsp+0x3a0]
   53e64:	mov    QWORD PTR [rsp+0x110],rdi
   53e6c:	mov    rdi,rax
   53e6f:	mov    rsi,rcx
   53e72:	mov    rdx,r14
   53e75:	call   53e7a <sqlite3VdbeExec+0x49da>
   53e7a:	mov    rdi,QWORD PTR [rsp+0x110]
   53e82:	mov    r14,QWORD PTR [rsp+0x128]
   53e8a:	mov    r15,rbx
   53e8d:	mov    rbx,QWORD PTR [rsp+0x160]
   53e95:	mov    r12d,DWORD PTR [rsp+0x38c]
   53e9d:	jmp    5327c <sqlite3VdbeExec+0x3ddc>
   53ea2:	mov    DWORD PTR [rsp+0x37c],ebx
   53ea9:	mov    rbx,QWORD PTR [rsp+0x160]
   53eb1:	lea    rcx,[rip+0x0]        # 53eb8 <sqlite3VdbeExec+0x4a18>
   53eb8:	cmp    BYTE PTR [rcx+rax*1],0x0
   53ebc:	jne    53ecf <sqlite3VdbeExec+0x4a2f>
   53ebe:	mov    QWORD PTR [rsp+0x160],rbx
   53ec6:	mov    ebx,DWORD PTR [rsp+0x37c]
   53ecd:	jmp    53e56 <sqlite3VdbeExec+0x49b6>
   53ecf:	mov    eax,DWORD PTR [rsp+0x3a0]
   53ed6:	mov    ecx,r13d
   53ed9:	mov    ecx,DWORD PTR [r15+rcx*4]
   53edd:	mov    edx,DWORD PTR [rdi+0x2c]
   53ee0:	mov    r15d,DWORD PTR [rsp+0x394]
   53ee8:	mov    QWORD PTR [rsp],r14
   53eec:	mov    QWORD PTR [rsp+0x110],rdi
   53ef4:	mov    rdi,r12
   53ef7:	mov    rsi,r13
   53efa:	mov    r8,rdx
   53efd:	mov    rdx,rax
   53f00:	mov    r9,r15
   53f03:	call   53f08 <sqlite3VdbeExec+0x4a68>
   53f08:	mov    r12d,eax
   53f0b:	mov    rdi,QWORD PTR [rsp+0x110]
   53f13:	test   r12d,r12d
   53f16:	jne    53f2d <sqlite3VdbeExec+0x4a8d>
   53f18:	mov    r14,QWORD PTR [rsp+0x128]
   53f20:	mov    r15d,DWORD PTR [rsp+0x37c]
   53f28:	jmp    5327c <sqlite3VdbeExec+0x3ddc>
   53f2d:	cmp    r12d,0x7
   53f31:	jne    53f53 <sqlite3VdbeExec+0x4ab3>
   53f33:	mov    r14,QWORD PTR [rsp+0x128]
   53f3b:	mov    r13,QWORD PTR [rsp+0x150]
   53f43:	mov    rbx,rbp
   53f46:	mov    rbp,QWORD PTR [rsp+0x158]
   53f4e:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   53f53:	cmp    r12d,0x12
   53f57:	jne    53f6e <sqlite3VdbeExec+0x4ace>
   53f59:	mov    QWORD PTR [rsp+0x148],rbp
   53f61:	mov    rbp,QWORD PTR [rsp+0x128]
   53f69:	jmp    53cbc <sqlite3VdbeExec+0x481c>
   53f6e:	mov    r14,QWORD PTR [rsp+0x128]
   53f76:	mov    QWORD PTR [rsp+0x148],rbp
   53f7e:	mov    rbp,r12
   53f81:	mov    r13,QWORD PTR [rsp+0x130]
   53f89:	mov    rbx,QWORD PTR [rsp+0x158]
   53f91:	jmp    4f712 <sqlite3VdbeExec+0x272>
   53f96:	mov    QWORD PTR [rsp+0x150],r13
   53f9e:	mov    eax,0x1859c
   53fa3:	mov    ecx,0xb
   53fa8:	lea    rdx,[rip+0x0]        # 53faf <sqlite3VdbeExec+0x4b0f>
   53faf:	mov    QWORD PTR [rsp+0x110],rdi
   53fb7:	mov    rdi,rcx
   53fba:	mov    rsi,rax
   53fbd:	call   53fc2 <sqlite3VdbeExec+0x4b22>
   53fc2:	mov    ebx,eax
   53fc4:	mov    rdi,QWORD PTR [rsp+0x110]
   53fcc:	mov    QWORD PTR [rsp+0x148],rbp
   53fd4:	mov    rbp,rbx
   53fd7:	mov    r13,QWORD PTR [rsp+0x130]
   53fdf:	mov    rbx,QWORD PTR [rsp+0x158]
   53fe7:	jmp    4f712 <sqlite3VdbeExec+0x272>
   53fec:	mov    r15d,DWORD PTR [rsp+0x37c]
   53ff4:	mov    r13,QWORD PTR [rsp+0x150]
   53ffc:	mov    QWORD PTR [rsp+0x130],r12
   54004:	mov    r12d,DWORD PTR [rsp+0x394]
   5400c:	mov    DWORD PTR [rsp+0x394],r12d
   54014:	mov    r12,QWORD PTR [rbp+0x10]
   54018:	mov    QWORD PTR [rsp+0x150],r13
   54020:	mov    r13,QWORD PTR [r12+0x8]
   54025:	movsxd rax,DWORD PTR [rbp+0x4]
   54029:	imul   rax,rax,0x38
   5402d:	mov    QWORD PTR [rsp+0x170],r13
   54035:	lea    r13,[rbx+rax*1]
   54039:	cmp    DWORD PTR [rbp+0xc],0x2
   5403d:	jge    5406d <sqlite3VdbeExec+0x4bcd>
   5403f:	mov    QWORD PTR [rsp+0x188],r13
   54047:	movsx  r13d,WORD PTR [r12+0x36]
   5404d:	mov    QWORD PTR [rsp+0x168],r12
   54055:	mov    DWORD PTR [rsp+0x3a0],r13d
   5405d:	mov    r13,QWORD PTR [rsp+0x188]
   54065:	xor    r12d,r12d
   54068:	jmp    54386 <sqlite3VdbeExec+0x4ee6>
   5406d:	mov    QWORD PTR [rsp+0x188],r13
   54075:	mov    eax,DWORD PTR [rbp+0xc]
   54078:	mov    r13d,eax
   5407b:	sub    r13d,0x2
   5407f:	mov    DWORD PTR [rsp+0x39c],r13d
   54087:	add    r13d,0x1
   5408b:	mov    QWORD PTR [rsp+0x168],r12
   54093:	mov    r12d,DWORD PTR [rsp+0x39c]
   5409b:	mov    DWORD PTR [rsp+0x3a0],r13d
   540a3:	mov    r13,QWORD PTR [rsp+0x188]
   540ab:	jmp    54386 <sqlite3VdbeExec+0x4ee6>
   540b0:	mov    QWORD PTR [rsp+0x170],r15
   540b8:	mov    r15d,DWORD PTR [rsp+0x37c]
   540c0:	cmp    DWORD PTR [rbp+0xc],0x0
   540c4:	je     540cf <sqlite3VdbeExec+0x4c2f>
   540c6:	add    r13,0x38
   540ca:	jmp    54382 <sqlite3VdbeExec+0x4ee2>
   540cf:	movsxd rax,r12d
   540d2:	shl    rax,0x4
   540d6:	mov    QWORD PTR [rsp+0x128],r14
   540de:	mov    r14,QWORD PTR [rsp+0x170]
   540e6:	movsx  eax,BYTE PTR [r14+rax*1+0x9]
   540ec:	mov    ecx,r15d
   540ef:	mov    QWORD PTR [rsp+0x110],rdi
   540f7:	mov    rdi,r13
   540fa:	mov    rsi,rax
   540fd:	mov    rdx,rcx
   54100:	call   54105 <sqlite3VdbeExec+0x4c65>
   54105:	movzx  eax,WORD PTR [r13+0x14]
   5410a:	and    eax,0x1
   5410d:	mov    rdi,QWORD PTR [rsp+0x110]
   54115:	test   eax,eax
   54117:	je     54126 <sqlite3VdbeExec+0x4c86>
   54119:	mov    r14,QWORD PTR [rsp+0x128]
   54121:	jmp    5437e <sqlite3VdbeExec+0x4ede>
   54126:	movsxd rax,r12d
   54129:	shl    rax,0x4
   5412d:	movzx  eax,BYTE PTR [r14+rax*1+0x8]
   54133:	shl    rax,0x38
   54137:	shr    rax,0x3c
   5413b:	mov    ecx,eax
   5413d:	sub    ecx,0x2
   54140:	cmp    ecx,0x4
   54143:	jbe    5415a <sqlite3VdbeExec+0x4cba>
   54145:	mov    QWORD PTR [rsp+0x170],r14
   5414d:	mov    r14,QWORD PTR [rsp+0x128]
   54155:	jmp    5437e <sqlite3VdbeExec+0x4ede>
   5415a:	sub    eax,0x2
   5415d:	mov    QWORD PTR [rsp+0x148],rbp
   54165:	lea    rbp,[rip+0x0]        # 5416c <sqlite3VdbeExec+0x4ccc>
   5416c:	movsxd rax,DWORD PTR [rbp+rax*4+0x0]
   54171:	add    rax,rbp
   54174:	jmp    rax
   54176:	mov    QWORD PTR [rsp+0x170],r14
   5417e:	mov    r14,QWORD PTR [rsp+0x128]
   54186:	mov    rbp,QWORD PTR [rsp+0x148]
   5418e:	jmp    5437e <sqlite3VdbeExec+0x4ede>
   54193:	movzx  eax,WORD PTR [r13+0x14]
   54198:	and    eax,0x10
   5419b:	test   eax,eax
   5419d:	je     541bc <sqlite3VdbeExec+0x4d1c>
   5419f:	mov    QWORD PTR [rsp+0x170],r14
   541a7:	mov    r14,QWORD PTR [rsp+0x128]
   541af:	mov    rbp,QWORD PTR [rsp+0x148]
   541b7:	jmp    5437e <sqlite3VdbeExec+0x4ede>
   541bc:	lea    rax,[rip+0x0]        # 541c3 <sqlite3VdbeExec+0x4d23>
   541c3:	lea    rcx,[rip+0x0]        # 541ca <sqlite3VdbeExec+0x4d2a>
   541ca:	lea    rdx,[rip+0x0]        # 541d1 <sqlite3VdbeExec+0x4d31>
   541d1:	movzx  esi,WORD PTR [r13+0x14]
   541d6:	and    esi,0x3f
   541d9:	movzx  edx,BYTE PTR [rdx+rsi*1]
   541dd:	add    rdx,0xffffffffffffffff
   541e1:	mov    rcx,QWORD PTR [rcx+rdx*8]
   541e5:	lea    rdx,[rip+0x0]        # 541ec <sqlite3VdbeExec+0x4d4c>
   541ec:	movsxd rsi,r12d
   541ef:	mov    r8,rsi
   541f2:	shl    r8,0x4
   541f6:	movzx  r8d,BYTE PTR [r14+r8*1+0x8]
   541fc:	shl    r8,0x38
   54200:	shr    r8,0x3c
   54204:	add    r8,0xffffffffffffffff
   54208:	mov    rdx,QWORD PTR [rdx+r8*8]
   5420c:	mov    r12,QWORD PTR [rsp+0x168]
   54214:	mov    r8,QWORD PTR [r12]
   54218:	shl    rsi,0x4
   5421c:	mov    rsi,QWORD PTR [r14+rsi*1]
   54220:	mov    QWORD PTR [rsp+0x110],rdi
   54228:	mov    r9,rsi
   5422b:	mov    rsi,rax
   5422e:	mov    r11,rdx
   54231:	mov    rdx,rcx
   54234:	mov    rcx,r11
   54237:	xor    eax,eax
   54239:	call   5423e <sqlite3VdbeExec+0x4d9e>
   5423e:	mov    ebp,0xc13
   54243:	mov    rdi,QWORD PTR [rsp+0x110]
   5424b:	mov    r14,QWORD PTR [rsp+0x128]
   54253:	mov    r13,QWORD PTR [rsp+0x130]
   5425b:	mov    rbx,QWORD PTR [rsp+0x158]
   54263:	jmp    4f712 <sqlite3VdbeExec+0x272>
   54268:	mov    QWORD PTR [rsp+0x170],r14
   54270:	mov    r14,QWORD PTR [rsp+0x128]
   54278:	mov    rbp,QWORD PTR [rsp+0x148]
   54280:	movzx  eax,WORD PTR [r13+0x14]
   54285:	and    eax,0x4
   54288:	test   eax,eax
   5428a:	jne    5437e <sqlite3VdbeExec+0x4ede>
   54290:	mov    QWORD PTR [rsp+0x128],r14
   54298:	mov    r14,QWORD PTR [rsp+0x170]
   542a0:	mov    QWORD PTR [rsp+0x148],rbp
   542a8:	jmp    541bc <sqlite3VdbeExec+0x4d1c>
   542ad:	mov    QWORD PTR [rsp+0x170],r14
   542b5:	mov    r14,QWORD PTR [rsp+0x128]
   542bd:	mov    rbp,QWORD PTR [rsp+0x148]
   542c5:	movzx  eax,WORD PTR [r13+0x14]
   542ca:	and    eax,0x2
   542cd:	test   eax,eax
   542cf:	jne    5437e <sqlite3VdbeExec+0x4ede>
   542d5:	mov    QWORD PTR [rsp+0x128],r14
   542dd:	mov    r14,QWORD PTR [rsp+0x170]
   542e5:	mov    QWORD PTR [rsp+0x148],rbp
   542ed:	jmp    541bc <sqlite3VdbeExec+0x4d1c>
   542f2:	mov    QWORD PTR [rsp+0x170],r14
   542fa:	mov    r14,QWORD PTR [rsp+0x128]
   54302:	mov    rbp,QWORD PTR [rsp+0x148]
   5430a:	movzx  eax,WORD PTR [r13+0x14]
   5430f:	and    eax,0x4
   54312:	test   eax,eax
   54314:	je     54451 <sqlite3VdbeExec+0x4fb1>
   5431a:	movabs rax,0x7fffffffffff
   54324:	cmp    rax,QWORD PTR [r13+0x0]
   54328:	jge    5433f <sqlite3VdbeExec+0x4e9f>
   5432a:	mov    DWORD PTR [rsp+0x37c],r15d
   54332:	mov    r15,QWORD PTR [rsp+0x170]
   5433a:	jmp    54410 <sqlite3VdbeExec+0x4f70>
   5433f:	movabs rax,0xffff800000000000
   54349:	cmp    rax,QWORD PTR [r13+0x0]
   5434d:	jle    54364 <sqlite3VdbeExec+0x4ec4>
   5434f:	mov    DWORD PTR [rsp+0x37c],r15d
   54357:	mov    r15,QWORD PTR [rsp+0x170]
   5435f:	jmp    54410 <sqlite3VdbeExec+0x4f70>
   54364:	movzx  eax,WORD PTR [r13+0x14]
   54369:	or     eax,0x20
   5436c:	mov    WORD PTR [r13+0x14],ax
   54371:	movzx  eax,WORD PTR [r13+0x14]
   54376:	and    eax,0xfffffffb
   54379:	mov    WORD PTR [r13+0x14],ax
   5437e:	add    r13,0x38
   54382:	add    r12d,0x1
   54386:	mov    DWORD PTR [rsp+0x37c],r15d
   5438e:	mov    r15d,DWORD PTR [rsp+0x3a0]
   54396:	cmp    r12d,r15d
   54399:	jge    5449a <sqlite3VdbeExec+0x4ffa>
   5439f:	movsxd rax,r12d
   543a2:	shl    rax,0x4
   543a6:	mov    r15,QWORD PTR [rsp+0x170]
   543ae:	movzx  eax,WORD PTR [r15+rax*1+0xe]
   543b4:	and    eax,0x60
   543b7:	test   eax,eax
   543b9:	jne    543c8 <sqlite3VdbeExec+0x4f28>
   543bb:	mov    r15d,DWORD PTR [rsp+0x37c]
   543c3:	jmp    540cf <sqlite3VdbeExec+0x4c2f>
   543c8:	cmp    DWORD PTR [rbp+0xc],0x2
   543cc:	jl     543e3 <sqlite3VdbeExec+0x4f43>
   543ce:	mov    QWORD PTR [rsp+0x170],r15
   543d6:	mov    r15d,DWORD PTR [rsp+0x37c]
   543de:	jmp    540cf <sqlite3VdbeExec+0x4c2f>
   543e3:	movsxd rax,r12d
   543e6:	shl    rax,0x4
   543ea:	movzx  eax,WORD PTR [r15+rax*1+0xe]
   543f0:	and    eax,0x20
   543f3:	test   eax,eax
   543f5:	je     540b0 <sqlite3VdbeExec+0x4c10>
   543fb:	mov    QWORD PTR [rsp+0x170],r15
   54403:	mov    r15d,DWORD PTR [rsp+0x37c]
   5440b:	jmp    54382 <sqlite3VdbeExec+0x4ee2>
   54410:	mov    rax,QWORD PTR [r13+0x0]
   54414:	xorps  xmm1,xmm1
   54417:	cvtsi2sd xmm1,rax
   5441c:	movsd  QWORD PTR [r13+0x0],xmm1
   54422:	movzx  eax,WORD PTR [r13+0x14]
   54427:	or     eax,0x8
   5442a:	mov    WORD PTR [r13+0x14],ax
   5442f:	movzx  eax,WORD PTR [r13+0x14]
   54434:	and    eax,0xfffffffb
   54437:	mov    WORD PTR [r13+0x14],ax
   5443c:	mov    QWORD PTR [rsp+0x170],r15
   54444:	mov    r15d,DWORD PTR [rsp+0x37c]
   5444c:	jmp    5437e <sqlite3VdbeExec+0x4ede>
   54451:	mov    DWORD PTR [rsp+0x37c],r15d
   54459:	mov    r15,QWORD PTR [rsp+0x170]
   54461:	movzx  eax,WORD PTR [r13+0x14]
   54466:	and    eax,0x28
   54469:	test   eax,eax
   5446b:	je     54482 <sqlite3VdbeExec+0x4fe2>
   5446d:	mov    QWORD PTR [rsp+0x170],r15
   54475:	mov    r15d,DWORD PTR [rsp+0x37c]
   5447d:	jmp    5437e <sqlite3VdbeExec+0x4ede>
   54482:	mov    QWORD PTR [rsp+0x128],r14
   5448a:	mov    r14,r15
   5448d:	mov    QWORD PTR [rsp+0x148],rbp
   54495:	jmp    541bc <sqlite3VdbeExec+0x4d1c>
   5449a:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5449f:	mov    QWORD PTR [rsp+0x130],r12
   544a7:	mov    r12,QWORD PTR [rbp+0x10]
   544ab:	movsxd rax,DWORD PTR [rbp+0x4]
   544af:	imul   rax,rax,0x38
   544b3:	lea    r13,[rbx+rax*1]
   544b7:	mov    r15,r12
   544ba:	mov    r12,r13
   544bd:	jmp    54505 <sqlite3VdbeExec+0x5065>
   544bf:	mov    rax,QWORD PTR [r12]
   544c3:	xorps  xmm1,xmm1
   544c6:	cvtsi2sd xmm1,rax
   544cb:	movsd  QWORD PTR [r12],xmm1
   544d1:	movzx  eax,WORD PTR [r12+0x14]
   544d7:	or     eax,0x8
   544da:	mov    WORD PTR [r12+0x14],ax
   544e0:	movzx  eax,WORD PTR [r12+0x14]
   544e6:	and    eax,0xfffffff9
   544e9:	mov    WORD PTR [r12+0x14],ax
   544ef:	lea    r13,[r15+0x1]
   544f3:	cmp    BYTE PTR [r15+0x1],0x0
   544f8:	je     545b4 <sqlite3VdbeExec+0x5114>
   544fe:	add    r12,0x38
   54502:	mov    r15,r13
   54505:	movsx  eax,BYTE PTR [r15]
   54509:	mov    r13d,DWORD PTR [rsp+0x37c]
   54511:	mov    ecx,r13d
   54514:	mov    QWORD PTR [rsp+0x110],rdi
   5451c:	mov    rdi,r12
   5451f:	mov    rsi,rax
   54522:	mov    rdx,rcx
   54525:	call   5452a <sqlite3VdbeExec+0x508a>
   5452a:	mov    rdi,QWORD PTR [rsp+0x110]
   54532:	cmp    BYTE PTR [r15],0x45
   54536:	jne    544ef <sqlite3VdbeExec+0x504f>
   54538:	movzx  eax,WORD PTR [r12+0x14]
   5453e:	and    eax,0x4
   54541:	test   eax,eax
   54543:	jne    5454f <sqlite3VdbeExec+0x50af>
   54545:	mov    DWORD PTR [rsp+0x37c],r13d
   5454d:	jmp    544ef <sqlite3VdbeExec+0x504f>
   5454f:	movabs rax,0x7fffffffffff
   54559:	cmp    rax,QWORD PTR [r12]
   5455d:	jge    5456c <sqlite3VdbeExec+0x50cc>
   5455f:	mov    DWORD PTR [rsp+0x37c],r13d
   54567:	jmp    544bf <sqlite3VdbeExec+0x501f>
   5456c:	movabs rax,0xffff800000000000
   54576:	cmp    rax,QWORD PTR [r12]
   5457a:	jle    54589 <sqlite3VdbeExec+0x50e9>
   5457c:	mov    DWORD PTR [rsp+0x37c],r13d
   54584:	jmp    544bf <sqlite3VdbeExec+0x501f>
   54589:	movzx  eax,WORD PTR [r12+0x14]
   5458f:	or     eax,0x20
   54592:	mov    WORD PTR [r12+0x14],ax
   54598:	movzx  eax,WORD PTR [r12+0x14]
   5459e:	and    eax,0xfffffffb
   545a1:	mov    WORD PTR [r12+0x14],ax
   545a7:	mov    DWORD PTR [rsp+0x37c],r13d
   545af:	jmp    544ef <sqlite3VdbeExec+0x504f>
   545b4:	mov    r13d,DWORD PTR [rsp+0x37c]
   545bc:	mov    DWORD PTR [rsp+0x37c],r13d
   545c4:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   545c9:	mov    r13d,DWORD PTR [rsp+0x37c]
   545d1:	mov    QWORD PTR [rsp+0x130],r12
   545d9:	mov    DWORD PTR [rsp+0x37c],r13d
   545e1:	movsxd rax,DWORD PTR [rbp+0x4]
   545e5:	mov    r12,QWORD PTR [rbp+0x10]
   545e9:	imul   rax,rax,0x38
   545ed:	lea    r13,[rbx+rax*1]
   545f1:	mov    eax,DWORD PTR [rbp+0x8]
   545f4:	sub    eax,0x1
   545f7:	movsxd rax,eax
   545fa:	imul   rax,rax,0x38
   545fe:	lea    r15,[r13+rax*1+0x0]
   54603:	movsxd rax,DWORD PTR [rbp+0xc]
   54607:	imul   rax,rax,0x38
   5460b:	mov    QWORD PTR [rsp+0x168],r15
   54613:	lea    r15,[rbx+rax*1]
   54617:	test   r12,r12
   5461a:	jne    54631 <sqlite3VdbeExec+0x5191>
   5461c:	mov    QWORD PTR [rsp+0x170],r13
   54624:	mov    QWORD PTR [rsp+0x188],r15
   5462c:	jmp    546c5 <sqlite3VdbeExec+0x5225>
   54631:	mov    QWORD PTR [rsp+0x170],r13
   54639:	movsx  eax,BYTE PTR [r12]
   5463e:	mov    QWORD PTR [rsp+0x188],r15
   54646:	mov    r15d,DWORD PTR [rsp+0x37c]
   5464e:	mov    ecx,r15d
   54651:	mov    QWORD PTR [rsp+0x110],rdi
   54659:	mov    rdi,r13
   5465c:	mov    rsi,rax
   5465f:	mov    rdx,rcx
   54662:	call   54667 <sqlite3VdbeExec+0x51c7>
   54667:	mov    rdi,QWORD PTR [rsp+0x110]
   5466f:	cmp    BYTE PTR [r12],0x45
   54674:	jne    5469c <sqlite3VdbeExec+0x51fc>
   54676:	movzx  eax,WORD PTR [r13+0x14]
   5467b:	and    eax,0x4
   5467e:	test   eax,eax
   54680:	je     5469c <sqlite3VdbeExec+0x51fc>
   54682:	movzx  eax,WORD PTR [r13+0x14]
   54687:	or     eax,0x20
   5468a:	mov    WORD PTR [r13+0x14],ax
   5468f:	movzx  eax,WORD PTR [r13+0x14]
   54694:	and    eax,0xfffffffb
   54697:	mov    WORD PTR [r13+0x14],ax
   5469c:	mov    DWORD PTR [rsp+0x37c],r15d
   546a4:	lea    r15,[r12+0x1]
   546a9:	add    r13,0x38
   546ad:	cmp    BYTE PTR [r12+0x1],0x0
   546b3:	je     546c5 <sqlite3VdbeExec+0x5225>
   546b5:	mov    r12,r15
   546b8:	mov    r15,QWORD PTR [rsp+0x188]
   546c0:	jmp    54639 <sqlite3VdbeExec+0x5199>
   546c5:	mov    r12,QWORD PTR [rsp+0x168]
   546cd:	xor    r15d,r15d
   546d0:	xor    r13d,r13d
   546d3:	xor    r11d,r11d
   546d6:	mov    QWORD PTR [rsp+0x178],r11
   546de:	jmp    54a22 <sqlite3VdbeExec+0x5582>
   546e3:	mov    DWORD PTR [r12+0x24],0x0
   546ec:	add    r13d,0x1
   546f0:	mov    QWORD PTR [rsp+0x128],r14
   546f8:	mov    r14,r13
   546fb:	jmp    549fe <sqlite3VdbeExec+0x555e>
   54700:	movzx  eax,WORD PTR [r12+0x14]
   54706:	and    eax,0x24
   54709:	test   eax,eax
   5470b:	je     54831 <sqlite3VdbeExec+0x5391>
   54711:	mov    rax,QWORD PTR [r12]
   54715:	test   rax,rax
   54718:	jge    54722 <sqlite3VdbeExec+0x5282>
   5471a:	mov    rcx,rax
   5471d:	not    rcx
   54720:	jmp    54725 <sqlite3VdbeExec+0x5285>
   54722:	mov    rcx,rax
   54725:	add    r13d,0x1
   54729:	cmp    rcx,0x7f
   5472d:	ja     54760 <sqlite3VdbeExec+0x52c0>
   5472f:	mov    rdx,rax
   54732:	and    rdx,0x1
   54736:	cmp    rdx,rax
   54739:	jne    5474e <sqlite3VdbeExec+0x52ae>
   5473b:	cmp    BYTE PTR [rdi+0xc5],0x4
   54742:	jb     5474e <sqlite3VdbeExec+0x52ae>
   54744:	lea    eax,[rcx+0x8]
   54747:	mov    DWORD PTR [r12+0x24],eax
   5474c:	jmp    5475b <sqlite3VdbeExec+0x52bb>
   5474e:	add    r15,0x1
   54752:	mov    DWORD PTR [r12+0x24],0x1
   5475b:	jmp    54821 <sqlite3VdbeExec+0x5381>
   54760:	cmp    rcx,0x7fff
   54767:	ja     5477b <sqlite3VdbeExec+0x52db>
   54769:	add    r15,0x2
   5476d:	mov    DWORD PTR [r12+0x24],0x2
   54776:	jmp    54821 <sqlite3VdbeExec+0x5381>
   5477b:	cmp    rcx,0x7fffff
   54782:	ja     54796 <sqlite3VdbeExec+0x52f6>
   54784:	add    r15,0x3
   54788:	mov    DWORD PTR [r12+0x24],0x3
   54791:	jmp    54821 <sqlite3VdbeExec+0x5381>
   54796:	cmp    rcx,0x7fffffff
   5479d:	ja     547ae <sqlite3VdbeExec+0x530e>
   5479f:	add    r15,0x4
   547a3:	mov    DWORD PTR [r12+0x24],0x4
   547ac:	jmp    54821 <sqlite3VdbeExec+0x5381>
   547ae:	movabs rax,0x7fffffffffff
   547b8:	cmp    rcx,rax
   547bb:	ja     547cc <sqlite3VdbeExec+0x532c>
   547bd:	add    r15,0x6
   547c1:	mov    DWORD PTR [r12+0x24],0x5
   547ca:	jmp    54821 <sqlite3VdbeExec+0x5381>
   547cc:	add    r15,0x8
   547d0:	movzx  eax,WORD PTR [r12+0x14]
   547d6:	and    eax,0x20
   547d9:	test   eax,eax
   547db:	je     54818 <sqlite3VdbeExec+0x5378>
   547dd:	mov    rax,QWORD PTR [r12]
   547e1:	xorps  xmm1,xmm1
   547e4:	cvtsi2sd xmm1,rax
   547e9:	movsd  QWORD PTR [r12],xmm1
   547ef:	movzx  eax,WORD PTR [r12+0x14]
   547f5:	and    eax,0xffffffdf
   547f8:	mov    WORD PTR [r12+0x14],ax
   547fe:	movzx  eax,WORD PTR [r12+0x14]
   54804:	or     eax,0x8
   54807:	mov    WORD PTR [r12+0x14],ax
   5480d:	mov    DWORD PTR [r12+0x24],0x7
   54816:	jmp    54821 <sqlite3VdbeExec+0x5381>
   54818:	mov    DWORD PTR [r12+0x24],0x6
   54821:	mov    QWORD PTR [rsp+0x128],r14
   54829:	mov    r14,r13
   5482c:	jmp    549fe <sqlite3VdbeExec+0x555e>
   54831:	movzx  eax,WORD PTR [r12+0x14]
   54837:	and    eax,0x8
   5483a:	test   eax,eax
   5483c:	je     5485f <sqlite3VdbeExec+0x53bf>
   5483e:	add    r13d,0x1
   54842:	add    r15,0x8
   54846:	mov    DWORD PTR [r12+0x24],0x7
   5484f:	mov    QWORD PTR [rsp+0x128],r14
   54857:	mov    r14,r13
   5485a:	jmp    549fe <sqlite3VdbeExec+0x555e>
   5485f:	mov    DWORD PTR [rsp+0x3a0],r13d
   54867:	mov    r13d,DWORD PTR [r12+0x10]
   5486c:	mov    eax,r13d
   5486f:	shl    eax,1
   54871:	add    eax,0xc
   54874:	movzx  ecx,WORD PTR [r12+0x14]
   5487a:	and    ecx,0x2
   5487d:	test   ecx,ecx
   5487f:	mov    ecx,0x0
   54884:	setne  cl
   54887:	mov    DWORD PTR [rsp+0x39c],r13d
   5488f:	lea    r13d,[rax+rcx*1]
   54893:	movzx  eax,WORD PTR [r12+0x14]
   54899:	and    eax,0x400
   5489e:	test   eax,eax
   548a0:	jne    548b7 <sqlite3VdbeExec+0x5417>
   548a2:	mov    QWORD PTR [rsp+0x128],r14
   548aa:	mov    r14d,DWORD PTR [rsp+0x39c]
   548b2:	jmp    549c9 <sqlite3VdbeExec+0x5529>
   548b7:	mov    eax,DWORD PTR [r12]
   548bb:	shl    eax,1
   548bd:	add    r13d,eax
   548c0:	test   r15,r15
   548c3:	je     54992 <sqlite3VdbeExec+0x54f2>
   548c9:	mov    eax,DWORD PTR [r12+0x10]
   548ce:	add    eax,DWORD PTR [r12]
   548d2:	test   eax,eax
   548d4:	jg     548e8 <sqlite3VdbeExec+0x5448>
   548d6:	movzx  eax,WORD PTR [r12+0x14]
   548dc:	and    eax,0x10
   548df:	test   eax,eax
   548e1:	je     54954 <sqlite3VdbeExec+0x54b4>
   548e3:	mov    eax,0x1
   548e8:	mov    ecx,0x1
   548ed:	mov    QWORD PTR [rsp+0x110],rdi
   548f5:	mov    rdi,r12
   548f8:	mov    rsi,rax
   548fb:	mov    rdx,rcx
   548fe:	call   54903 <sqlite3VdbeExec+0x5463>
   54903:	mov    rdi,QWORD PTR [rsp+0x110]
   5490b:	test   eax,eax
   5490d:	jne    5496a <sqlite3VdbeExec+0x54ca>
   5490f:	mov    rax,QWORD PTR [r12+0x8]
   54914:	movsxd rcx,DWORD PTR [r12+0x10]
   54919:	add    rax,rcx
   5491c:	xor    ecx,ecx
   5491e:	movsxd rdx,DWORD PTR [r12]
   54922:	mov    rdi,rax
   54925:	mov    rsi,rcx
   54928:	call   5492d <sqlite3VdbeExec+0x548d>
   5492d:	mov    eax,DWORD PTR [r12+0x10]
   54932:	add    eax,DWORD PTR [r12]
   54936:	mov    DWORD PTR [r12+0x10],eax
   5493b:	movzx  eax,WORD PTR [r12+0x14]
   54941:	and    eax,0xfffff9ff
   54946:	mov    WORD PTR [r12+0x14],ax
   5494c:	mov    rdi,QWORD PTR [rsp+0x110]
   54954:	mov    QWORD PTR [rsp+0x128],r14
   5495c:	mov    r14d,DWORD PTR [rsp+0x39c]
   54964:	add    r14d,DWORD PTR [r12]
   54968:	jmp    549c9 <sqlite3VdbeExec+0x5529>
   5496a:	mov    QWORD PTR [rsp+0x128],r14
   54972:	mov    r14,QWORD PTR [rsp+0x128]
   5497a:	mov    r13,QWORD PTR [rsp+0x150]
   54982:	mov    rbx,rbp
   54985:	mov    rbp,QWORD PTR [rsp+0x158]
   5498d:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   54992:	movsxd rax,DWORD PTR [r12]
   54996:	mov    DWORD PTR [rsp+0x398],r13d
   5499e:	mov    r13,QWORD PTR [rsp+0x178]
   549a6:	add    r13,rax
   549a9:	mov    QWORD PTR [rsp+0x128],r14
   549b1:	mov    QWORD PTR [rsp+0x178],r13
   549b9:	mov    r13d,DWORD PTR [rsp+0x398]
   549c1:	mov    r14d,DWORD PTR [rsp+0x39c]
   549c9:	mov    rax,r14
   549cc:	add    r15,rax
   549cf:	mov    rax,r13
   549d2:	mov    ecx,0x1
   549d7:	mov    r11,rcx
   549da:	mov    rcx,rax
   549dd:	mov    rax,r11
   549e0:	jmp    549e5 <sqlite3VdbeExec+0x5545>
   549e2:	add    eax,0x1
   549e5:	shr    rcx,0x7
   549e9:	test   rcx,rcx
   549ec:	jne    549e2 <sqlite3VdbeExec+0x5542>
   549ee:	mov    r14d,DWORD PTR [rsp+0x3a0]
   549f6:	add    r14d,eax
   549f9:	mov    DWORD PTR [r12+0x24],r13d
   549fe:	mov    r13,QWORD PTR [rsp+0x170]
   54a06:	cmp    r12,r13
   54a09:	je     54a54 <sqlite3VdbeExec+0x55b4>
   54a0b:	add    r12,0xffffffffffffffc8
   54a0f:	mov    QWORD PTR [rsp+0x170],r13
   54a17:	mov    r13,r14
   54a1a:	mov    r14,QWORD PTR [rsp+0x128]
   54a22:	movzx  eax,WORD PTR [r12+0x14]
   54a28:	and    eax,0x1
   54a2b:	test   eax,eax
   54a2d:	je     54700 <sqlite3VdbeExec+0x5260>
   54a33:	movzx  eax,WORD PTR [r12+0x14]
   54a39:	and    eax,0x400
   54a3e:	test   eax,eax
   54a40:	je     546e3 <sqlite3VdbeExec+0x5243>
   54a46:	mov    DWORD PTR [r12+0x24],0xa
   54a4f:	jmp    546ec <sqlite3VdbeExec+0x524c>
   54a54:	cmp    r14d,0x7e
   54a58:	jg     54a63 <sqlite3VdbeExec+0x55c3>
   54a5a:	lea    r12d,[r14+0x1]
   54a5e:	mov    r14,r12
   54a61:	jmp    54aac <sqlite3VdbeExec+0x560c>
   54a63:	mov    rax,r14
   54a66:	mov    ecx,0x1
   54a6b:	mov    r11,rcx
   54a6e:	mov    rcx,rax
   54a71:	mov    rax,r11
   54a74:	jmp    54a79 <sqlite3VdbeExec+0x55d9>
   54a76:	add    eax,0x1
   54a79:	shr    rcx,0x7
   54a7d:	test   rcx,rcx
   54a80:	jne    54a76 <sqlite3VdbeExec+0x55d6>
   54a82:	add    r14d,eax
   54a85:	movsxd rcx,r14d
   54a88:	mov    edx,0x1
   54a8d:	mov    r11,rdx
   54a90:	mov    rdx,rcx
   54a93:	mov    rcx,r11
   54a96:	jmp    54a9b <sqlite3VdbeExec+0x55fb>
   54a98:	add    ecx,0x1
   54a9b:	shr    rdx,0x7
   54a9f:	test   rdx,rdx
   54aa2:	jne    54a98 <sqlite3VdbeExec+0x55f8>
   54aa4:	cmp    eax,ecx
   54aa6:	jge    54aac <sqlite3VdbeExec+0x560c>
   54aa8:	add    r14d,0x1
   54aac:	movsxd rax,r14d
   54aaf:	lea    r12,[rax+r15*1]
   54ab3:	mov    r15,QWORD PTR [rsp+0x178]
   54abb:	lea    rax,[r12+r15*1]
   54abf:	mov    QWORD PTR [rsp+0x170],r13
   54ac7:	mov    r13,QWORD PTR [rsp+0x188]
   54acf:	movsxd rcx,DWORD PTR [r13+0x20]
   54ad3:	cmp    rax,rcx
   54ad6:	jg     54b2c <sqlite3VdbeExec+0x568c>
   54ad8:	mov    rax,QWORD PTR [r13+0x28]
   54adc:	mov    QWORD PTR [r13+0x8],rax
   54ae0:	mov    DWORD PTR [r13+0x10],r12d
   54ae4:	mov    WORD PTR [r13+0x14],0x10
   54aeb:	test   r15,r15
   54aee:	je     54b03 <sqlite3VdbeExec+0x5663>
   54af0:	mov    DWORD PTR [r13+0x0],r15d
   54af4:	movzx  eax,WORD PTR [r13+0x14]
   54af9:	or     eax,0x400
   54afe:	mov    WORD PTR [r13+0x14],ax
   54b03:	mov    r12,QWORD PTR [r13+0x8]
   54b07:	movsxd rax,r14d
   54b0a:	lea    r13,[r12+rax*1]
   54b0e:	cmp    r14d,0x80
   54b15:	jge    54c02 <sqlite3VdbeExec+0x5762>
   54b1b:	lea    r15,[r12+0x1]
   54b20:	mov    BYTE PTR [r12],r14b
   54b24:	mov    r12,r15
   54b27:	jmp    54c69 <sqlite3VdbeExec+0x57c9>
   54b2c:	lea    rax,[r12+r15*1]
   54b30:	mov    QWORD PTR [rsp+0x148],rbp
   54b38:	mov    rbp,QWORD PTR [rsp+0x128]
   54b40:	movsxd rcx,DWORD PTR [rbp+0x88]
   54b47:	cmp    rax,rcx
   54b4a:	jg     53cbc <sqlite3VdbeExec+0x481c>
   54b50:	mov    eax,r12d
   54b53:	cmp    eax,DWORD PTR [r13+0x20]
   54b57:	jle    54bb2 <sqlite3VdbeExec+0x5712>
   54b59:	xor    ecx,ecx
   54b5b:	mov    QWORD PTR [rsp+0x110],rdi
   54b63:	mov    rdi,r13
   54b66:	mov    rsi,rax
   54b69:	mov    rdx,rcx
   54b6c:	call   54b71 <sqlite3VdbeExec+0x56d1>
   54b71:	mov    rdi,QWORD PTR [rsp+0x110]
   54b79:	test   eax,eax
   54b7b:	jne    54b92 <sqlite3VdbeExec+0x56f2>
   54b7d:	mov    QWORD PTR [rsp+0x128],rbp
   54b85:	mov    rbp,QWORD PTR [rsp+0x148]
   54b8d:	jmp    54ae0 <sqlite3VdbeExec+0x5640>
   54b92:	mov    r14,rbp
   54b95:	mov    r13,QWORD PTR [rsp+0x150]
   54b9d:	mov    rbx,QWORD PTR [rsp+0x148]
   54ba5:	mov    rbp,QWORD PTR [rsp+0x158]
   54bad:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   54bb2:	mov    QWORD PTR [rsp+0x128],rbp
   54bba:	mov    QWORD PTR [rsp+0x178],r15
   54bc2:	mov    r15,r13
   54bc5:	mov    r13,QWORD PTR [rsp+0x170]
   54bcd:	mov    rbp,QWORD PTR [rsp+0x148]
   54bd5:	mov    rax,QWORD PTR [r15+0x28]
   54bd9:	mov    QWORD PTR [r15+0x8],rax
   54bdd:	movzx  eax,WORD PTR [r15+0x14]
   54be2:	and    eax,0x2d
   54be5:	mov    WORD PTR [r15+0x14],ax
   54bea:	mov    QWORD PTR [rsp+0x170],r13
   54bf2:	mov    r13,r15
   54bf5:	mov    r15,QWORD PTR [rsp+0x178]
   54bfd:	jmp    54ae0 <sqlite3VdbeExec+0x5640>
   54c02:	mov    rax,r14
   54c05:	cmp    rax,0x7f
   54c09:	ja     54c1a <sqlite3VdbeExec+0x577a>
   54c0b:	and    rax,0x7f
   54c0f:	mov    BYTE PTR [r12],al
   54c13:	mov    eax,0x1
   54c18:	jmp    54c63 <sqlite3VdbeExec+0x57c3>
   54c1a:	cmp    rax,0x3fff
   54c20:	ja     54c48 <sqlite3VdbeExec+0x57a8>
   54c22:	mov    rcx,rax
   54c25:	shr    rcx,0x7
   54c29:	and    rcx,0x7f
   54c2d:	or     rcx,0x80
   54c34:	mov    BYTE PTR [r12],cl
   54c38:	and    rax,0x7f
   54c3c:	mov    BYTE PTR [r12+0x1],al
   54c41:	mov    eax,0x2
   54c46:	jmp    54c63 <sqlite3VdbeExec+0x57c3>
   54c48:	mov    QWORD PTR [rsp+0x110],rdi
   54c50:	mov    rdi,r12
   54c53:	mov    rsi,rax
   54c56:	call   54c5b <sqlite3VdbeExec+0x57bb>
   54c5b:	mov    rdi,QWORD PTR [rsp+0x110]
   54c63:	movsxd rax,eax
   54c66:	add    r12,rax
   54c69:	mov    r14,QWORD PTR [rsp+0x170]
   54c71:	mov    r15,r13
   54c74:	jmp    54eea <sqlite3VdbeExec+0x5a4a>
   54c79:	lea    r13,[rip+0x0]        # 54c80 <sqlite3VdbeExec+0x57e0>
   54c80:	cmp    eax,0x7
   54c83:	jne    54c92 <sqlite3VdbeExec+0x57f2>
   54c85:	mov    rcx,QWORD PTR [r14]
   54c88:	mov    QWORD PTR [rsp+0x170],rcx
   54c90:	jmp    54c9d <sqlite3VdbeExec+0x57fd>
   54c92:	mov    rcx,QWORD PTR [r14]
   54c95:	mov    QWORD PTR [rsp+0x170],rcx
   54c9d:	lea    rcx,[rip+0x0]        # 54ca4 <sqlite3VdbeExec+0x5804>
   54ca4:	movzx  eax,BYTE PTR [rcx+rax*1]
   54ca8:	mov    ecx,eax
   54caa:	sub    ecx,0x1
   54cad:	cmp    ecx,0x5
   54cb0:	ja     54cc1 <sqlite3VdbeExec+0x5821>
   54cb2:	mov    ecx,eax
   54cb4:	sub    ecx,0x1
   54cb7:	movsxd rcx,DWORD PTR [r13+rcx*4+0x0]
   54cbc:	add    rcx,r13
   54cbf:	jmp    rcx
   54cc1:	mov    rcx,QWORD PTR [rsp+0x170]
   54cc9:	and    rcx,0xff
   54cd0:	mov    BYTE PTR [r15+0x7],cl
   54cd4:	mov    rcx,QWORD PTR [rsp+0x170]
   54cdc:	shr    rcx,0x8
   54ce0:	mov    QWORD PTR [rsp+0x170],rcx
   54ce8:	mov    rcx,QWORD PTR [rsp+0x170]
   54cf0:	and    rcx,0xff
   54cf7:	mov    BYTE PTR [r15+0x6],cl
   54cfb:	mov    rcx,QWORD PTR [rsp+0x170]
   54d03:	shr    rcx,0x8
   54d07:	mov    QWORD PTR [rsp+0x170],rcx
   54d0f:	mov    rcx,QWORD PTR [rsp+0x170]
   54d17:	and    rcx,0xff
   54d1e:	mov    BYTE PTR [r15+0x5],cl
   54d22:	mov    rcx,QWORD PTR [rsp+0x170]
   54d2a:	shr    rcx,0x8
   54d2e:	mov    QWORD PTR [rsp+0x170],rcx
   54d36:	mov    rcx,QWORD PTR [rsp+0x170]
   54d3e:	and    rcx,0xff
   54d45:	mov    BYTE PTR [r15+0x4],cl
   54d49:	mov    rcx,QWORD PTR [rsp+0x170]
   54d51:	shr    rcx,0x8
   54d55:	mov    QWORD PTR [rsp+0x170],rcx
   54d5d:	mov    rcx,QWORD PTR [rsp+0x170]
   54d65:	and    rcx,0xff
   54d6c:	mov    BYTE PTR [r15+0x3],cl
   54d70:	mov    rcx,QWORD PTR [rsp+0x170]
   54d78:	shr    rcx,0x8
   54d7c:	mov    QWORD PTR [rsp+0x170],rcx
   54d84:	mov    rcx,QWORD PTR [rsp+0x170]
   54d8c:	and    rcx,0xff
   54d93:	mov    BYTE PTR [r15+0x2],cl
   54d97:	mov    rcx,QWORD PTR [rsp+0x170]
   54d9f:	shr    rcx,0x8
   54da3:	mov    QWORD PTR [rsp+0x170],rcx
   54dab:	mov    rcx,QWORD PTR [rsp+0x170]
   54db3:	and    rcx,0xff
   54dba:	mov    BYTE PTR [r15+0x1],cl
   54dbe:	mov    rcx,QWORD PTR [rsp+0x170]
   54dc6:	shr    rcx,0x8
   54dca:	mov    QWORD PTR [rsp+0x170],rcx
   54dd2:	mov    rcx,QWORD PTR [rsp+0x170]
   54dda:	and    rcx,0xff
   54de1:	mov    BYTE PTR [r15],cl
   54de4:	add    r15,rax
   54de7:	jmp    54ed1 <sqlite3VdbeExec+0x5a31>
   54dec:	cmp    eax,0x80
   54df1:	jae    54e39 <sqlite3VdbeExec+0x5999>
   54df3:	mov    BYTE PTR [r12],al
   54df7:	add    r12,0x1
   54dfb:	cmp    eax,0xe
   54dfe:	jb     54e34 <sqlite3VdbeExec+0x5994>
   54e00:	cmp    DWORD PTR [r14+0x10],0x0
   54e05:	jle    54e34 <sqlite3VdbeExec+0x5994>
   54e07:	mov    rax,QWORD PTR [r14+0x8]
   54e0b:	movsxd rcx,DWORD PTR [r14+0x10]
   54e0f:	mov    QWORD PTR [rsp+0x110],rdi
   54e17:	mov    rdi,r15
   54e1a:	mov    rsi,rax
   54e1d:	mov    rdx,rcx
   54e20:	call   54e25 <sqlite3VdbeExec+0x5985>
   54e25:	movsxd rax,DWORD PTR [r14+0x10]
   54e29:	add    r15,rax
   54e2c:	mov    rdi,QWORD PTR [rsp+0x110]
   54e34:	jmp    54ed1 <sqlite3VdbeExec+0x5a31>
   54e39:	cmp    rax,0x7f
   54e3d:	ja     54e4e <sqlite3VdbeExec+0x59ae>
   54e3f:	and    rax,0x7f
   54e43:	mov    BYTE PTR [r12],al
   54e47:	mov    eax,0x1
   54e4c:	jmp    54e97 <sqlite3VdbeExec+0x59f7>
   54e4e:	cmp    rax,0x3fff
   54e54:	ja     54e7c <sqlite3VdbeExec+0x59dc>
   54e56:	mov    rcx,rax
   54e59:	shr    rcx,0x7
   54e5d:	and    rcx,0x7f
   54e61:	or     rcx,0x80
   54e68:	mov    BYTE PTR [r12],cl
   54e6c:	and    rax,0x7f
   54e70:	mov    BYTE PTR [r12+0x1],al
   54e75:	mov    eax,0x2
   54e7a:	jmp    54e97 <sqlite3VdbeExec+0x59f7>
   54e7c:	mov    QWORD PTR [rsp+0x110],rdi
   54e84:	mov    rdi,r12
   54e87:	mov    rsi,rax
   54e8a:	call   54e8f <sqlite3VdbeExec+0x59ef>
   54e8f:	mov    rdi,QWORD PTR [rsp+0x110]
   54e97:	movsxd rax,eax
   54e9a:	add    r12,rax
   54e9d:	cmp    DWORD PTR [r14+0x10],0x0
   54ea2:	je     54ed1 <sqlite3VdbeExec+0x5a31>
   54ea4:	mov    rax,QWORD PTR [r14+0x8]
   54ea8:	movsxd rcx,DWORD PTR [r14+0x10]
   54eac:	mov    QWORD PTR [rsp+0x110],rdi
   54eb4:	mov    rdi,r15
   54eb7:	mov    rsi,rax
   54eba:	mov    rdx,rcx
   54ebd:	call   54ec2 <sqlite3VdbeExec+0x5a22>
   54ec2:	movsxd rax,DWORD PTR [r14+0x10]
   54ec6:	add    r15,rax
   54ec9:	mov    rdi,QWORD PTR [rsp+0x110]
   54ed1:	mov    r13,QWORD PTR [rsp+0x168]
   54ed9:	cmp    r14,r13
   54edc:	je     54f0c <sqlite3VdbeExec+0x5a6c>
   54ede:	add    r14,0x38
   54ee2:	mov    QWORD PTR [rsp+0x168],r13
   54eea:	mov    eax,DWORD PTR [r14+0x24]
   54eee:	cmp    eax,0x7
   54ef1:	ja     54dec <sqlite3VdbeExec+0x594c>
   54ef7:	mov    BYTE PTR [r12],al
   54efb:	add    r12,0x1
   54eff:	test   eax,eax
   54f01:	jne    54c79 <sqlite3VdbeExec+0x57d9>
   54f07:	jmp    54de7 <sqlite3VdbeExec+0x5947>
   54f0c:	mov    r14,QWORD PTR [rsp+0x128]
   54f14:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   54f19:	mov    QWORD PTR [rsp+0x128],r14
   54f21:	mov    QWORD PTR [rsp+0x130],r12
   54f29:	mov    rax,QWORD PTR [rdi+0x78]
   54f2d:	movsxd rcx,DWORD PTR [rbp+0x4]
   54f31:	mov    rax,QWORD PTR [rax+rcx*8]
   54f35:	mov    r12,QWORD PTR [rax+0x28]
   54f39:	cmp    DWORD PTR [rbp+0xc],0x0
   54f3d:	je     5500a <sqlite3VdbeExec+0x5b6a>
   54f43:	cmp    BYTE PTR [r12],0x0
   54f48:	je     54f4e <sqlite3VdbeExec+0x5aae>
   54f4a:	xor    eax,eax
   54f4c:	jmp    54f9e <sqlite3VdbeExec+0x5afe>
   54f4e:	mov    rax,QWORD PTR [r12+0x88]
   54f56:	cmp    BYTE PTR [rax+0x8],0x0
   54f5a:	jne    54f65 <sqlite3VdbeExec+0x5ac5>
   54f5c:	mov    rax,0xffffffffffffffff
   54f63:	jmp    54f9e <sqlite3VdbeExec+0x5afe>
   54f65:	mov    rax,QWORD PTR [r12+0x88]
   54f6d:	movzx  eax,WORD PTR [rax+0x18]
   54f71:	xor    ecx,ecx
   54f73:	jmp    54f92 <sqlite3VdbeExec+0x5af2>
   54f75:	mov    rdx,rcx
   54f78:	mov    rdx,QWORD PTR [r12+rdx*8+0x90]
   54f80:	movzx  edx,WORD PTR [rdx+0x18]
   54f84:	add    edx,0x1
   54f87:	imul   rax,rdx
   54f8b:	mov    edx,0x1
   54f90:	add    cl,dl
   54f92:	mov    edx,ecx
   54f94:	movsx  esi,BYTE PTR [r12+0x54]
   54f9a:	cmp    edx,esi
   54f9c:	jl     54f75 <sqlite3VdbeExec+0x5ad5>
   54f9e:	mov    QWORD PTR [rsp+0x168],rax
   54fa6:	mov    rax,QWORD PTR [rdi+0x68]
   54faa:	movsxd rcx,DWORD PTR [rbp+0x8]
   54fae:	imul   rcx,rcx,0x38
   54fb2:	lea    rdx,[rax+rcx*1]
   54fb6:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   54fbb:	and    eax,0x9000
   54fc0:	test   eax,eax
   54fc2:	je     552ff <sqlite3VdbeExec+0x5e5f>
   54fc8:	mov    QWORD PTR [rsp+0x110],rdi
   54fd0:	mov    rdi,rdx
   54fd3:	call   54fd8 <sqlite3VdbeExec+0x5b38>
   54fd8:	mov    rdi,QWORD PTR [rsp+0x110]
   54fe0:	mov    r14,QWORD PTR [rsp+0x128]
   54fe8:	mov    r15d,DWORD PTR [rsp+0x37c]
   54ff0:	mov    r13,rbx
   54ff3:	mov    ebx,DWORD PTR [rsp+0x390]
   54ffa:	mov    r12d,DWORD PTR [rsp+0x394]
   55002:	mov    rdx,rax
   55005:	jmp    55327 <sqlite3VdbeExec+0x5e87>
   5500a:	mov    QWORD PTR [rsp+0x168],0x0
   55016:	xor    r14d,r14d
   55019:	mov    QWORD PTR [rsp+0x110],rdi
   55021:	mov    rdi,r12
   55024:	call   55029 <sqlite3VdbeExec+0x5b89>
   55029:	mov    r15d,eax
   5502c:	mov    rdi,QWORD PTR [rsp+0x110]
   55034:	cmp    r15d,0x10
   55038:	jne    55230 <sqlite3VdbeExec+0x5d90>
   5503e:	mov    QWORD PTR [rsp+0x168],0x0
   5504a:	xor    r12d,r12d
   5504d:	mov    r15,r12
   55050:	jmp    552c5 <sqlite3VdbeExec+0x5e25>
   55055:	mov    WORD PTR [r12+0x46],0x0
   5505d:	movzx  eax,BYTE PTR [r12+0x1]
   55063:	and    eax,0xfffffff9
   55066:	mov    BYTE PTR [r12+0x1],al
   5506b:	movsx  rax,BYTE PTR [r12+0x54]
   55071:	add    rax,0xffffffffffffffff
   55075:	movzx  eax,WORD PTR [r12+rax*2+0x58]
   5507b:	mov    WORD PTR [r12+0x56],ax
   55081:	mov    rax,QWORD PTR [r12+0x88]
   55089:	movsx  ecx,BYTE PTR [r12+0x54]
   5508f:	sub    ecx,0x1
   55092:	movzx  ecx,cl
   55095:	mov    BYTE PTR [r12+0x54],cl
   5509a:	movsx  rcx,cl
   5509e:	mov    rcx,QWORD PTR [r12+rcx*8+0x90]
   550a6:	mov    QWORD PTR [r12+0x88],rcx
   550ae:	mov    rax,QWORD PTR [rax+0x70]
   550b2:	movzx  ecx,WORD PTR [rax+0x34]
   550b6:	and    ecx,0x20
   550b9:	test   ecx,ecx
   550bb:	je     55120 <sqlite3VdbeExec+0x5c80>
   550bd:	mov    rcx,QWORD PTR [rax+0x28]
   550c1:	mov    edx,DWORD PTR [rcx+0x98]
   550c7:	sub    edx,0x1
   550ca:	mov    DWORD PTR [rcx+0x98],edx
   550d0:	mov    rdx,QWORD PTR [rcx+0xa8]
   550d7:	mov    QWORD PTR [rax+0x20],rdx
   550db:	mov    QWORD PTR [rcx+0xa8],rax
   550e2:	mov    rdx,QWORD PTR [rcx+0x48]
   550e6:	mov    esi,DWORD PTR [rax+0x30]
   550e9:	sub    esi,0x1
   550ec:	imul   rsi,QWORD PTR [rcx+0xc8]
   550f4:	mov    rax,QWORD PTR [rax+0x8]
   550f8:	mov    rcx,QWORD PTR [rdx]
   550fb:	mov    rcx,QWORD PTR [rcx+0x90]
   55102:	mov    QWORD PTR [rsp+0x110],rdi
   5510a:	mov    rdi,rdx
   5510d:	mov    rdx,rax
   55110:	mov    r10,rcx
   55113:	call   r10
   55116:	mov    rdi,QWORD PTR [rsp+0x110]
   5511e:	jmp    55138 <sqlite3VdbeExec+0x5c98>
   55120:	mov    QWORD PTR [rsp+0x110],rdi
   55128:	mov    rdi,rax
   5512b:	call   55130 <sqlite3VdbeExec+0x5c90>
   55130:	mov    rdi,QWORD PTR [rsp+0x110]
   55138:	movzx  eax,WORD PTR [r12+0x56]
   5513e:	mov    rcx,QWORD PTR [r12+0x88]
   55146:	movzx  ecx,WORD PTR [rcx+0x18]
   5514a:	cmp    eax,ecx
   5514c:	jge    55289 <sqlite3VdbeExec+0x5de9>
   55152:	movzx  eax,WORD PTR [r12+0x56]
   55158:	add    eax,0x1
   5515b:	mov    WORD PTR [r12+0x56],ax
   55161:	mov    rax,QWORD PTR [r12+0x88]
   55169:	movzx  ecx,WORD PTR [r12+0x56]
   5516f:	movzx  edx,WORD PTR [rax+0x18]
   55173:	cmp    ecx,edx
   55175:	jne    551c4 <sqlite3VdbeExec+0x5d24>
   55177:	mov    rcx,QWORD PTR [rax+0x50]
   5517b:	movzx  eax,BYTE PTR [rax+0x9]
   5517f:	add    eax,0x8
   55182:	movzx  edx,BYTE PTR [rcx+rax*1]
   55186:	shl    edx,0x18
   55189:	movzx  esi,BYTE PTR [rcx+rax*1+0x1]
   5518e:	shl    esi,0x10
   55191:	or     edx,esi
   55193:	movzx  esi,BYTE PTR [rcx+rax*1+0x2]
   55198:	shl    esi,0x8
   5519b:	or     edx,esi
   5519d:	movzx  eax,BYTE PTR [rcx+rax*1+0x3]
   551a2:	or     edx,eax
   551a4:	mov    QWORD PTR [rsp+0x110],rdi
   551ac:	mov    rdi,r12
   551af:	mov    rsi,rdx
   551b2:	call   551b7 <sqlite3VdbeExec+0x5d17>
   551b7:	mov    r15d,eax
   551ba:	mov    rdi,QWORD PTR [rsp+0x110]
   551c2:	jmp    55230 <sqlite3VdbeExec+0x5d90>
   551c4:	mov    rdx,QWORD PTR [rax+0x50]
   551c8:	movzx  esi,WORD PTR [rax+0x1a]
   551cc:	mov    r8,QWORD PTR [rax+0x60]
   551d0:	mov    r9d,ecx
   551d3:	shl    r9d,1
   551d6:	movzx  r8d,BYTE PTR [r8+r9*1]
   551db:	shl    r8d,0x8
   551df:	mov    rax,QWORD PTR [rax+0x60]
   551e3:	shl    ecx,1
   551e5:	movzx  eax,BYTE PTR [rax+rcx*1+0x1]
   551ea:	or     r8d,eax
   551ed:	and    esi,r8d
   551f0:	movzx  eax,BYTE PTR [rdx+rsi*1]
   551f4:	shl    eax,0x18
   551f7:	movzx  ecx,BYTE PTR [rdx+rsi*1+0x1]
   551fc:	shl    ecx,0x10
   551ff:	or     eax,ecx
   55201:	movzx  ecx,BYTE PTR [rdx+rsi*1+0x2]
   55206:	shl    ecx,0x8
   55209:	or     eax,ecx
   5520b:	movzx  ecx,BYTE PTR [rdx+rsi*1+0x3]
   55210:	or     eax,ecx
   55212:	mov    QWORD PTR [rsp+0x110],rdi
   5521a:	mov    rdi,r12
   5521d:	mov    rsi,rax
   55220:	call   55225 <sqlite3VdbeExec+0x5d85>
   55225:	mov    r15d,eax
   55228:	mov    rdi,QWORD PTR [rsp+0x110]
   55230:	test   r15d,r15d
   55233:	je     5523f <sqlite3VdbeExec+0x5d9f>
   55235:	mov    r13,QWORD PTR [rsp+0x128]
   5523d:	jmp    552bd <sqlite3VdbeExec+0x5e1d>
   5523f:	mov    r13,QWORD PTR [rsp+0x128]
   55247:	mov    eax,DWORD PTR [r13+0x190]
   5524e:	test   eax,eax
   55250:	jne    552bd <sqlite3VdbeExec+0x5e1d>
   55252:	mov    rax,QWORD PTR [r12+0x88]
   5525a:	cmp    BYTE PTR [rax+0x8],0x0
   5525e:	jne    55270 <sqlite3VdbeExec+0x5dd0>
   55260:	cmp    BYTE PTR [rax+0x1],0x0
   55264:	je     55270 <sqlite3VdbeExec+0x5dd0>
   55266:	mov    QWORD PTR [rsp+0x128],r13
   5526e:	jmp    5527f <sqlite3VdbeExec+0x5ddf>
   55270:	movzx  ecx,WORD PTR [rax+0x18]
   55274:	add    r14,rcx
   55277:	mov    QWORD PTR [rsp+0x128],r13
   5527f:	cmp    BYTE PTR [rax+0x8],0x0
   55283:	je     55169 <sqlite3VdbeExec+0x5cc9>
   55289:	cmp    BYTE PTR [r12+0x54],0x0
   5528f:	jne    55055 <sqlite3VdbeExec+0x5bb5>
   55295:	mov    QWORD PTR [rsp+0x168],r14
   5529d:	mov    QWORD PTR [rsp+0x110],rdi
   552a5:	mov    rdi,r12
   552a8:	call   552ad <sqlite3VdbeExec+0x5e0d>
   552ad:	mov    r12d,eax
   552b0:	mov    rdi,QWORD PTR [rsp+0x110]
   552b8:	mov    r15,r12
   552bb:	jmp    552c5 <sqlite3VdbeExec+0x5e25>
   552bd:	mov    QWORD PTR [rsp+0x128],r13
   552c5:	test   r15d,r15d
   552c8:	jne    552d7 <sqlite3VdbeExec+0x5e37>
   552ca:	mov    DWORD PTR [rsp+0x38c],r15d
   552d2:	jmp    54fa6 <sqlite3VdbeExec+0x5b06>
   552d7:	mov    r14,QWORD PTR [rsp+0x128]
   552df:	mov    QWORD PTR [rsp+0x148],rbp
   552e7:	mov    rbp,r15
   552ea:	mov    r13,QWORD PTR [rsp+0x130]
   552f2:	mov    rbx,QWORD PTR [rsp+0x158]
   552fa:	jmp    4f712 <sqlite3VdbeExec+0x272>
   552ff:	mov    WORD PTR [rdx+0x14],0x4
   55305:	mov    r14,QWORD PTR [rsp+0x128]
   5530d:	mov    r15d,DWORD PTR [rsp+0x37c]
   55315:	mov    r13,rbx
   55318:	mov    ebx,DWORD PTR [rsp+0x390]
   5531f:	mov    r12d,DWORD PTR [rsp+0x394]
   55327:	mov    rax,QWORD PTR [rsp+0x168]
   5532f:	mov    QWORD PTR [rdx],rax
   55332:	mov    QWORD PTR [rsp+0x148],rbp
   5533a:	mov    QWORD PTR [rsp+0x160],r13
   55342:	mov    r13,QWORD PTR [rsp+0x150]
   5534a:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   5534f:	mov    r15d,DWORD PTR [rsp+0x37c]
   55357:	mov    r13,QWORD PTR [rsp+0x150]
   5535f:	mov    QWORD PTR [rsp+0x130],r12
   55367:	mov    r12d,DWORD PTR [rsp+0x394]
   5536f:	mov    DWORD PTR [rsp+0x394],r12d
   55377:	mov    r12d,DWORD PTR [rbp+0x4]
   5537b:	mov    QWORD PTR [rsp+0x150],r13
   55383:	mov    r13,QWORD PTR [rbp+0x10]
   55387:	test   r12d,r12d
   5538a:	jne    55549 <sqlite3VdbeExec+0x60a9>
   55390:	cmp    DWORD PTR [r14+0xd8],0x0
   55398:	jle    553ce <sqlite3VdbeExec+0x5f2e>
   5539a:	lea    rax,[rip+0x0]        # 553a1 <sqlite3VdbeExec+0x5f01>
   553a1:	mov    QWORD PTR [rsp+0x110],rdi
   553a9:	mov    rsi,rax
   553ac:	xor    eax,eax
   553ae:	call   553b3 <sqlite3VdbeExec+0x5f13>
   553b3:	mov    r12d,0x5
   553b9:	mov    rdi,QWORD PTR [rsp+0x110]
   553c1:	mov    DWORD PTR [rsp+0x398],r12d
   553c9:	jmp    55518 <sqlite3VdbeExec+0x6078>
   553ce:	test   r13,r13
   553d1:	jne    553d8 <sqlite3VdbeExec+0x5f38>
   553d3:	xor    r12d,r12d
   553d6:	jmp    553fa <sqlite3VdbeExec+0x5f5a>
   553d8:	mov    QWORD PTR [rsp+0x110],rdi
   553e0:	mov    rdi,r13
   553e3:	call   553e8 <sqlite3VdbeExec+0x5f48>
   553e8:	mov    r12d,eax
   553eb:	and    r12d,0x3fffffff
   553f2:	mov    rdi,QWORD PTR [rsp+0x110]
   553fa:	xor    eax,eax
   553fc:	mov    ecx,DWORD PTR [r14+0x2ec]
   55403:	add    ecx,DWORD PTR [r14+0x2e8]
   5540a:	mov    QWORD PTR [rsp+0x128],r14
   55412:	mov    QWORD PTR [rsp+0x110],rdi
   5541a:	mov    rdi,r14
   5541d:	mov    rsi,rax
   55420:	mov    rdx,rcx
   55423:	call   55428 <sqlite3VdbeExec+0x5f88>
   55428:	mov    r14d,eax
   5542b:	mov    rdi,QWORD PTR [rsp+0x110]
   55433:	test   r14d,r14d
   55436:	je     55460 <sqlite3VdbeExec+0x5fc0>
   55438:	mov    QWORD PTR [rsp+0x148],rbp
   55440:	mov    rbp,r14
   55443:	mov    r14,QWORD PTR [rsp+0x128]
   5544b:	mov    r13,QWORD PTR [rsp+0x130]
   55453:	mov    rbx,QWORD PTR [rsp+0x158]
   5545b:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55460:	mov    rax,r12
   55463:	add    rax,0x20
   55467:	add    rax,0x1
   5546b:	mov    DWORD PTR [rsp+0x398],r14d
   55473:	mov    r14,QWORD PTR [rsp+0x128]
   5547b:	mov    rdi,r14
   5547e:	mov    rsi,rax
   55481:	call   55486 <sqlite3VdbeExec+0x5fe6>
   55486:	mov    rdi,QWORD PTR [rsp+0x110]
   5548e:	test   rax,rax
   55491:	je     55518 <sqlite3VdbeExec+0x6078>
   55497:	lea    rcx,[rax+0x20]
   5549b:	mov    QWORD PTR [rax],rcx
   5549e:	mov    rcx,QWORD PTR [rax]
   554a1:	lea    edx,[r12+0x1]
   554a6:	mov    QWORD PTR [rsp+0x108],rax
   554ae:	mov    rdi,rcx
   554b1:	mov    rsi,r13
   554b4:	call   554b9 <sqlite3VdbeExec+0x6019>
   554b9:	mov    rcx,rax
   554bc:	mov    rax,QWORD PTR [rsp+0x108]
   554c4:	mov    rdi,QWORD PTR [rsp+0x110]
   554cc:	cmp    BYTE PTR [r14+0x65],0x0
   554d1:	je     554df <sqlite3VdbeExec+0x603f>
   554d3:	mov    BYTE PTR [r14+0x65],0x0
   554d8:	mov    BYTE PTR [r14+0x6d],0x1
   554dd:	jmp    554f0 <sqlite3VdbeExec+0x6050>
   554df:	mov    ecx,DWORD PTR [r14+0x2e8]
   554e6:	add    ecx,0x1
   554e9:	mov    DWORD PTR [r14+0x2e8],ecx
   554f0:	mov    rcx,QWORD PTR [r14+0x2d8]
   554f7:	mov    QWORD PTR [rax+0x18],rcx
   554fb:	mov    QWORD PTR [r14+0x2d8],rax
   55502:	mov    rcx,QWORD PTR [r14+0x2f0]
   55509:	mov    QWORD PTR [rax+0x8],rcx
   5550d:	mov    rcx,QWORD PTR [r14+0x2f8]
   55514:	mov    QWORD PTR [rax+0x10],rcx
   55518:	mov    r12d,DWORD PTR [rsp+0x398]
   55520:	test   r12d,r12d
   55523:	je     55ba3 <sqlite3VdbeExec+0x6703>
   55529:	mov    QWORD PTR [rsp+0x148],rbp
   55531:	mov    rbp,r12
   55534:	mov    r13,QWORD PTR [rsp+0x130]
   5553c:	mov    rbx,QWORD PTR [rsp+0x158]
   55544:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55549:	mov    QWORD PTR [rsp+0x168],r13
   55551:	mov    r13,QWORD PTR [r14+0x2d8]
   55558:	mov    DWORD PTR [rsp+0x3a0],r12d
   55560:	mov    r12,r13
   55563:	xor    r13d,r13d
   55566:	jmp    555b6 <sqlite3VdbeExec+0x6116>
   55568:	lea    rsi,[rip+0x0]        # 5556f <sqlite3VdbeExec+0x60cf>
   5556f:	movzx  ecx,BYTE PTR [rsi+rcx*1]
   55573:	movzx  edx,BYTE PTR [rsi+rdx*1]
   55577:	sub    ecx,edx
   55579:	test   ecx,ecx
   5557b:	je     5557f <sqlite3VdbeExec+0x60df>
   5557d:	jmp    55597 <sqlite3VdbeExec+0x60f7>
   5557f:	add    rax,0x1
   55583:	add    r13,0x1
   55587:	movzx  ecx,BYTE PTR [rax]
   5558a:	movzx  edx,BYTE PTR [r13+0x0]
   5558f:	cmp    ecx,edx
   55591:	jne    55568 <sqlite3VdbeExec+0x60c8>
   55593:	test   ecx,ecx
   55595:	jne    5557f <sqlite3VdbeExec+0x60df>
   55597:	test   ecx,ecx
   55599:	jne    555a5 <sqlite3VdbeExec+0x6105>
   5559b:	mov    r13d,DWORD PTR [rsp+0x398]
   555a3:	jmp    555d1 <sqlite3VdbeExec+0x6131>
   555a5:	mov    r13d,DWORD PTR [rsp+0x398]
   555ad:	add    r13d,0x1
   555b1:	mov    r12,QWORD PTR [r12+0x18]
   555b6:	test   r12,r12
   555b9:	je     555d1 <sqlite3VdbeExec+0x6131>
   555bb:	mov    rax,QWORD PTR [r12]
   555bf:	mov    DWORD PTR [rsp+0x398],r13d
   555c7:	mov    r13,QWORD PTR [rsp+0x168]
   555cf:	jmp    55587 <sqlite3VdbeExec+0x60e7>
   555d1:	test   r12,r12
   555d4:	jne    5560d <sqlite3VdbeExec+0x616d>
   555d6:	lea    rax,[rip+0x0]        # 555dd <sqlite3VdbeExec+0x613d>
   555dd:	mov    r13,QWORD PTR [rsp+0x168]
   555e5:	mov    QWORD PTR [rsp+0x110],rdi
   555ed:	mov    rsi,rax
   555f0:	mov    rdx,r13
   555f3:	xor    eax,eax
   555f5:	call   555fa <sqlite3VdbeExec+0x615a>
   555fa:	mov    r12d,0x1
   55600:	mov    rdi,QWORD PTR [rsp+0x110]
   55608:	jmp    55520 <sqlite3VdbeExec+0x6080>
   5560d:	cmp    DWORD PTR [r14+0xd8],0x0
   55615:	jg     55629 <sqlite3VdbeExec+0x6189>
   55617:	mov    DWORD PTR [rsp+0x37c],r15d
   5561f:	mov    r15d,DWORD PTR [rsp+0x3a0]
   55627:	jmp    55673 <sqlite3VdbeExec+0x61d3>
   55629:	mov    DWORD PTR [rsp+0x37c],r15d
   55631:	mov    r15d,DWORD PTR [rsp+0x3a0]
   55639:	cmp    r15d,0x1
   5563d:	jne    55673 <sqlite3VdbeExec+0x61d3>
   5563f:	lea    rax,[rip+0x0]        # 55646 <sqlite3VdbeExec+0x61a6>
   55646:	mov    QWORD PTR [rsp+0x110],rdi
   5564e:	mov    rsi,rax
   55651:	xor    eax,eax
   55653:	call   55658 <sqlite3VdbeExec+0x61b8>
   55658:	mov    r12d,0x5
   5565e:	mov    rdi,QWORD PTR [rsp+0x110]
   55666:	mov    r15d,DWORD PTR [rsp+0x37c]
   5566e:	jmp    55520 <sqlite3VdbeExec+0x6080>
   55673:	cmp    QWORD PTR [r12+0x18],0x0
   55679:	jne    55691 <sqlite3VdbeExec+0x61f1>
   5567b:	mov    DWORD PTR [rsp+0x398],r13d
   55683:	xor    r13d,r13d
   55686:	cmp    BYTE PTR [r14+0x6d],0x0
   5568b:	setne  r13b
   5568f:	jmp    5569c <sqlite3VdbeExec+0x61fc>
   55691:	mov    DWORD PTR [rsp+0x398],r13d
   55699:	xor    r13d,r13d
   5569c:	test   r13d,r13d
   5569f:	jne    556b6 <sqlite3VdbeExec+0x6216>
   556a1:	mov    DWORD PTR [rsp+0x39c],r13d
   556a9:	mov    r13d,DWORD PTR [rsp+0x398]
   556b1:	jmp    557f5 <sqlite3VdbeExec+0x6355>
   556b6:	cmp    r15d,0x1
   556ba:	je     556d1 <sqlite3VdbeExec+0x6231>
   556bc:	mov    DWORD PTR [rsp+0x39c],r13d
   556c4:	mov    r13d,DWORD PTR [rsp+0x398]
   556cc:	jmp    557f5 <sqlite3VdbeExec+0x6355>
   556d1:	mov    rax,QWORD PTR [rdi]
   556d4:	mov    rcx,QWORD PTR [rax+0x2f0]
   556db:	add    rcx,QWORD PTR [rax+0x2f8]
   556e2:	test   rcx,rcx
   556e5:	jne    556f4 <sqlite3VdbeExec+0x6254>
   556e7:	mov    DWORD PTR [rsp+0x39c],r13d
   556ef:	xor    r13d,r13d
   556f2:	jmp    55714 <sqlite3VdbeExec+0x6274>
   556f4:	mov    DWORD PTR [rsp+0x39c],r13d
   556fc:	mov    QWORD PTR [rsp+0x110],rdi
   55704:	call   55709 <sqlite3VdbeExec+0x6269>
   55709:	mov    r13d,eax
   5570c:	mov    rdi,QWORD PTR [rsp+0x110]
   55714:	test   r13d,r13d
   55717:	je     55739 <sqlite3VdbeExec+0x6299>
   55719:	mov    r12,r13
   5571c:	mov    r13d,DWORD PTR [rsp+0x380]
   55724:	mov    r15,QWORD PTR [rsp+0x130]
   5572c:	mov    rbx,QWORD PTR [rsp+0x158]
   55734:	jmp    65d93 <sqlite3VdbeExec+0x168f3>
   55739:	mov    r13,QWORD PTR [rsp+0x150]
   55741:	mov    BYTE PTR [r14+0x65],0x1
   55746:	mov    QWORD PTR [rsp+0x110],rdi
   5574e:	call   55753 <sqlite3VdbeExec+0x62b3>
   55753:	mov    rdi,QWORD PTR [rsp+0x110]
   5575b:	cmp    eax,0x5
   5575e:	jne    557c0 <sqlite3VdbeExec+0x6320>
   55760:	mov    rax,rbp
   55763:	sub    rax,r13
   55766:	movabs rdx,0x2aaaaaaaaaaaaaab
   55770:	imul   rdx
   55773:	sar    rdx,0x2
   55777:	mov    rax,rdx
   5577a:	shr    rax,0x3f
   5577e:	add    rdx,rax
   55781:	mov    rax,rdx
   55784:	mov    DWORD PTR [rdi+0x30],eax
   55787:	mov    BYTE PTR [r14+0x65],0x0
   5578c:	mov    ebx,0x5
   55791:	mov    DWORD PTR [rdi+0x34],0x5
   55798:	mov    QWORD PTR [rsp+0x150],r13
   557a0:	mov    r12,rbx
   557a3:	mov    r13d,DWORD PTR [rsp+0x380]
   557ab:	mov    r15,QWORD PTR [rsp+0x130]
   557b3:	mov    rbx,QWORD PTR [rsp+0x158]
   557bb:	jmp    65d93 <sqlite3VdbeExec+0x168f3>
   557c0:	mov    DWORD PTR [rsp+0x3a0],r15d
   557c8:	mov    r15d,DWORD PTR [rdi+0x34]
   557cc:	test   r15d,r15d
   557cf:	je     557d8 <sqlite3VdbeExec+0x6338>
   557d1:	mov    BYTE PTR [r14+0x65],0x0
   557d6:	jmp    557dd <sqlite3VdbeExec+0x633d>
   557d8:	mov    BYTE PTR [r14+0x6d],0x0
   557dd:	mov    QWORD PTR [rsp+0x150],r13
   557e5:	mov    r13,r15
   557e8:	mov    r15d,DWORD PTR [rsp+0x3a0]
   557f0:	jmp    55a18 <sqlite3VdbeExec+0x6578>
   557f5:	mov    eax,DWORD PTR [r14+0x2e8]
   557fc:	sub    eax,r13d
   557ff:	mov    r13d,eax
   55802:	sub    r13d,0x1
   55806:	cmp    r15d,0x2
   5580a:	jne    55901 <sqlite3VdbeExec+0x6461>
   55810:	mov    eax,DWORD PTR [r14+0x2c]
   55814:	mov    DWORD PTR [rsp+0x398],r13d
   5581c:	mov    r13d,eax
   5581f:	and    r13d,0x1
   55823:	mov    DWORD PTR [rsp+0x3a4],r13d
   5582b:	test   r13d,r13d
   5582e:	mov    r13d,0x0
   55834:	setne  r13b
   55838:	mov    DWORD PTR [rsp+0x3a8],r13d
   55840:	xor    r13d,r13d
   55843:	jmp    55869 <sqlite3VdbeExec+0x63c9>
   55845:	mov    DWORD PTR [rsp+0x3ac],r14d
   5584d:	mov    r14,QWORD PTR [rsp+0x128]
   55855:	add    r13d,0x1
   55859:	mov    r11d,DWORD PTR [rsp+0x3ac]
   55861:	mov    DWORD PTR [rsp+0x38c],r11d
   55869:	cmp    r13d,DWORD PTR [r14+0x28]
   5586d:	jge    558e7 <sqlite3VdbeExec+0x6447>
   5586f:	mov    rax,QWORD PTR [r14+0x20]
   55873:	mov    rcx,r13
   55876:	shl    rcx,0x5
   5587a:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   5587f:	mov    ecx,0x204
   55884:	mov    QWORD PTR [rsp+0x128],r14
   5588c:	mov    r14d,DWORD PTR [rsp+0x3a4]
   55894:	xor    edx,edx
   55896:	test   r14d,r14d
   55899:	sete   dl
   5589c:	mov    QWORD PTR [rsp+0x110],rdi
   558a4:	mov    rdi,rax
   558a7:	mov    rsi,rcx
   558aa:	call   558af <sqlite3VdbeExec+0x640f>
   558af:	mov    r14d,eax
   558b2:	mov    rdi,QWORD PTR [rsp+0x110]
   558ba:	test   r14d,r14d
   558bd:	je     55845 <sqlite3VdbeExec+0x63a5>
   558bf:	mov    QWORD PTR [rsp+0x148],rbp
   558c7:	mov    rbp,r14
   558ca:	mov    r14,QWORD PTR [rsp+0x128]
   558d2:	mov    r13,QWORD PTR [rsp+0x130]
   558da:	mov    rbx,QWORD PTR [rsp+0x158]
   558e2:	jmp    4f712 <sqlite3VdbeExec+0x272>
   558e7:	mov    QWORD PTR [rsp+0x128],r14
   558ef:	mov    r14,QWORD PTR [rsp+0x128]
   558f7:	mov    r13d,DWORD PTR [rsp+0x3a8]
   558ff:	jmp    5590c <sqlite3VdbeExec+0x646c>
   55901:	mov    DWORD PTR [rsp+0x398],r13d
   55909:	xor    r13d,r13d
   5590c:	mov    DWORD PTR [rsp+0x3a8],r13d
   55914:	xor    r13d,r13d
   55917:	jmp    5593d <sqlite3VdbeExec+0x649d>
   55919:	mov    DWORD PTR [rsp+0x3ac],r14d
   55921:	mov    r14,QWORD PTR [rsp+0x128]
   55929:	add    r13d,0x1
   5592d:	mov    r11d,DWORD PTR [rsp+0x3ac]
   55935:	mov    DWORD PTR [rsp+0x38c],r11d
   5593d:	cmp    r13d,DWORD PTR [r14+0x28]
   55941:	jge    559b1 <sqlite3VdbeExec+0x6511>
   55943:	mov    rax,QWORD PTR [r14+0x20]
   55947:	mov    rcx,r13
   5594a:	shl    rcx,0x5
   5594e:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   55953:	mov    QWORD PTR [rsp+0x128],r14
   5595b:	mov    r14d,DWORD PTR [rsp+0x398]
   55963:	mov    QWORD PTR [rsp+0x110],rdi
   5596b:	mov    rdi,rax
   5596e:	mov    rsi,r15
   55971:	mov    rdx,r14
   55974:	call   55979 <sqlite3VdbeExec+0x64d9>
   55979:	mov    r14d,eax
   5597c:	mov    rdi,QWORD PTR [rsp+0x110]
   55984:	test   r14d,r14d
   55987:	je     55919 <sqlite3VdbeExec+0x6479>
   55989:	mov    QWORD PTR [rsp+0x148],rbp
   55991:	mov    rbp,r14
   55994:	mov    r14,QWORD PTR [rsp+0x128]
   5599c:	mov    r13,QWORD PTR [rsp+0x130]
   559a4:	mov    rbx,QWORD PTR [rsp+0x158]
   559ac:	jmp    4f712 <sqlite3VdbeExec+0x272>
   559b1:	mov    r13d,DWORD PTR [rsp+0x3a8]
   559b9:	test   r13d,r13d
   559bc:	jne    559c8 <sqlite3VdbeExec+0x6528>
   559be:	mov    r13d,DWORD PTR [rsp+0x38c]
   559c6:	jmp    55a18 <sqlite3VdbeExec+0x6578>
   559c8:	mov    rax,QWORD PTR [r14+0x8]
   559cc:	jmp    559e8 <sqlite3VdbeExec+0x6548>
   559ce:	movzx  ecx,WORD PTR [rax+0xc8]
   559d5:	and    rcx,0xfffffffffffffffc
   559d9:	or     rcx,0x1
   559dd:	mov    WORD PTR [rax+0xc8],cx
   559e4:	mov    rax,QWORD PTR [rax+0x10]
   559e8:	test   rax,rax
   559eb:	jne    559ce <sqlite3VdbeExec+0x652e>
   559ed:	mov    QWORD PTR [rsp+0x110],rdi
   559f5:	mov    rdi,r14
   559f8:	call   559fd <sqlite3VdbeExec+0x655d>
   559fd:	mov    eax,DWORD PTR [r14+0x2c]
   55a01:	or     eax,0x1
   55a04:	mov    DWORD PTR [r14+0x2c],eax
   55a08:	mov    rdi,QWORD PTR [rsp+0x110]
   55a10:	mov    r13d,DWORD PTR [rsp+0x38c]
   55a18:	test   r13d,r13d
   55a1b:	je     55a80 <sqlite3VdbeExec+0x65e0>
   55a1d:	mov    QWORD PTR [rsp+0x148],rbp
   55a25:	mov    rbp,r13
   55a28:	mov    r13,QWORD PTR [rsp+0x130]
   55a30:	mov    rbx,QWORD PTR [rsp+0x158]
   55a38:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55a3d:	mov    rax,QWORD PTR [r14+0x2d8]
   55a44:	mov    rcx,QWORD PTR [rax+0x18]
   55a48:	mov    QWORD PTR [r14+0x2d8],rcx
   55a4f:	test   rax,rax
   55a52:	je     55a6f <sqlite3VdbeExec+0x65cf>
   55a54:	mov    QWORD PTR [rsp+0x110],rdi
   55a5c:	mov    rdi,r14
   55a5f:	mov    rsi,rax
   55a62:	call   55a67 <sqlite3VdbeExec+0x65c7>
   55a67:	mov    rdi,QWORD PTR [rsp+0x110]
   55a6f:	mov    eax,DWORD PTR [r14+0x2e8]
   55a76:	sub    eax,0x1
   55a79:	mov    DWORD PTR [r14+0x2e8],eax
   55a80:	cmp    r12,QWORD PTR [r14+0x2d8]
   55a87:	jne    55a3d <sqlite3VdbeExec+0x659d>
   55a89:	cmp    r15d,0x1
   55a8d:	jne    55af3 <sqlite3VdbeExec+0x6653>
   55a8f:	mov    rax,QWORD PTR [r12+0x18]
   55a94:	mov    QWORD PTR [r14+0x2d8],rax
   55a9b:	test   r12,r12
   55a9e:	je     55abb <sqlite3VdbeExec+0x661b>
   55aa0:	mov    QWORD PTR [rsp+0x110],rdi
   55aa8:	mov    rdi,r14
   55aab:	mov    rsi,r12
   55aae:	call   55ab3 <sqlite3VdbeExec+0x6613>
   55ab3:	mov    rdi,QWORD PTR [rsp+0x110]
   55abb:	mov    r12d,DWORD PTR [rsp+0x39c]
   55ac3:	test   r12d,r12d
   55ac6:	je     55ad5 <sqlite3VdbeExec+0x6635>
   55ac8:	mov    DWORD PTR [rsp+0x3a0],r15d
   55ad0:	mov    r15,r12
   55ad3:	jmp    55b1b <sqlite3VdbeExec+0x667b>
   55ad5:	mov    eax,DWORD PTR [r14+0x2e8]
   55adc:	sub    eax,0x1
   55adf:	mov    DWORD PTR [r14+0x2e8],eax
   55ae6:	mov    DWORD PTR [rsp+0x3a0],r15d
   55aee:	mov    r15,r12
   55af1:	jmp    55b1b <sqlite3VdbeExec+0x667b>
   55af3:	mov    DWORD PTR [rsp+0x3a0],r15d
   55afb:	mov    r15d,DWORD PTR [rsp+0x39c]
   55b03:	mov    rax,QWORD PTR [r12+0x8]
   55b08:	mov    QWORD PTR [r14+0x2f0],rax
   55b0f:	mov    rax,QWORD PTR [r12+0x10]
   55b14:	mov    QWORD PTR [r14+0x2f8],rax
   55b1b:	test   r15d,r15d
   55b1e:	jne    55b2a <sqlite3VdbeExec+0x668a>
   55b20:	mov    r15d,DWORD PTR [rsp+0x3a0]
   55b28:	jmp    55b48 <sqlite3VdbeExec+0x66a8>
   55b2a:	mov    r15d,DWORD PTR [rsp+0x3a0]
   55b32:	cmp    r15d,0x2
   55b36:	je     55b48 <sqlite3VdbeExec+0x66a8>
   55b38:	mov    r15d,DWORD PTR [rsp+0x37c]
   55b40:	mov    r12,r13
   55b43:	jmp    55520 <sqlite3VdbeExec+0x6080>
   55b48:	mov    r12d,DWORD PTR [rsp+0x398]
   55b50:	mov    QWORD PTR [rsp+0x110],rdi
   55b58:	mov    rdi,r14
   55b5b:	mov    rsi,r15
   55b5e:	mov    rdx,r12
   55b61:	call   55b66 <sqlite3VdbeExec+0x66c6>
   55b66:	mov    r12d,eax
   55b69:	mov    rdi,QWORD PTR [rsp+0x110]
   55b71:	test   r12d,r12d
   55b74:	jne    55b83 <sqlite3VdbeExec+0x66e3>
   55b76:	mov    r15d,DWORD PTR [rsp+0x37c]
   55b7e:	jmp    55520 <sqlite3VdbeExec+0x6080>
   55b83:	mov    QWORD PTR [rsp+0x148],rbp
   55b8b:	mov    rbp,r12
   55b8e:	mov    r13,QWORD PTR [rsp+0x130]
   55b96:	mov    rbx,QWORD PTR [rsp+0x158]
   55b9e:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55ba3:	cmp    BYTE PTR [rdi+0xc7],0x3
   55baa:	jne    55bd1 <sqlite3VdbeExec+0x6731>
   55bac:	mov    ebx,0x65
   55bb1:	mov    r12,rbx
   55bb4:	mov    r13d,DWORD PTR [rsp+0x380]
   55bbc:	mov    r15,QWORD PTR [rsp+0x130]
   55bc4:	mov    rbx,QWORD PTR [rsp+0x158]
   55bcc:	jmp    65d93 <sqlite3VdbeExec+0x168f3>
   55bd1:	mov    DWORD PTR [rsp+0x37c],r15d
   55bd9:	mov    DWORD PTR [rsp+0x38c],r12d
   55be1:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   55be6:	mov    QWORD PTR [rsp+0x130],r12
   55bee:	mov    ebx,DWORD PTR [rbp+0x4]
   55bf1:	mov    eax,DWORD PTR [rbp+0x8]
   55bf4:	movzx  ecx,BYTE PTR [r14+0x65]
   55bf9:	cmp    ebx,ecx
   55bfb:	je     55e01 <sqlite3VdbeExec+0x6961>
   55c01:	test   eax,eax
   55c03:	je     55c37 <sqlite3VdbeExec+0x6797>
   55c05:	mov    eax,0x204
   55c0a:	mov    QWORD PTR [rsp+0x110],rdi
   55c12:	mov    rdi,r14
   55c15:	mov    rsi,rax
   55c18:	call   55c1d <sqlite3VdbeExec+0x677d>
   55c1d:	mov    BYTE PTR [r14+0x65],0x1
   55c22:	mov    rdi,QWORD PTR [rsp+0x110]
   55c2a:	mov    r13,QWORD PTR [rsp+0x150]
   55c32:	jmp    55cec <sqlite3VdbeExec+0x684c>
   55c37:	test   ebx,ebx
   55c39:	je     55c8b <sqlite3VdbeExec+0x67eb>
   55c3b:	cmp    DWORD PTR [r14+0xd8],0x0
   55c43:	jle    55c8b <sqlite3VdbeExec+0x67eb>
   55c45:	lea    rax,[rip+0x0]        # 55c4c <sqlite3VdbeExec+0x67ac>
   55c4c:	mov    QWORD PTR [rsp+0x110],rdi
   55c54:	mov    rsi,rax
   55c57:	xor    eax,eax
   55c59:	call   55c5e <sqlite3VdbeExec+0x67be>
   55c5e:	mov    ebx,0x5
   55c63:	mov    rdi,QWORD PTR [rsp+0x110]
   55c6b:	mov    QWORD PTR [rsp+0x148],rbp
   55c73:	mov    rbp,rbx
   55c76:	mov    r13,QWORD PTR [rsp+0x130]
   55c7e:	mov    rbx,QWORD PTR [rsp+0x158]
   55c86:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55c8b:	mov    rax,QWORD PTR [rdi]
   55c8e:	mov    rcx,QWORD PTR [rax+0x2f0]
   55c95:	add    rcx,QWORD PTR [rax+0x2f8]
   55c9c:	test   rcx,rcx
   55c9f:	jne    55ca6 <sqlite3VdbeExec+0x6806>
   55ca1:	xor    r12d,r12d
   55ca4:	jmp    55cbe <sqlite3VdbeExec+0x681e>
   55ca6:	mov    QWORD PTR [rsp+0x110],rdi
   55cae:	call   55cb3 <sqlite3VdbeExec+0x6813>
   55cb3:	mov    r12d,eax
   55cb6:	mov    rdi,QWORD PTR [rsp+0x110]
   55cbe:	test   r12d,r12d
   55cc1:	je     55ce0 <sqlite3VdbeExec+0x6840>
   55cc3:	mov    r13d,DWORD PTR [rsp+0x380]
   55ccb:	mov    r15,QWORD PTR [rsp+0x130]
   55cd3:	mov    rbx,QWORD PTR [rsp+0x158]
   55cdb:	jmp    65d93 <sqlite3VdbeExec+0x168f3>
   55ce0:	mov    r13,QWORD PTR [rsp+0x150]
   55ce8:	mov    BYTE PTR [r14+0x65],bl
   55cec:	mov    QWORD PTR [rsp+0x110],rdi
   55cf4:	call   55cf9 <sqlite3VdbeExec+0x6859>
   55cf9:	mov    rdi,QWORD PTR [rsp+0x110]
   55d01:	cmp    eax,0x5
   55d04:	jne    55da2 <sqlite3VdbeExec+0x6902>
   55d0a:	mov    rax,rbp
   55d0d:	sub    rax,r13
   55d10:	movabs rdx,0x2aaaaaaaaaaaaaab
   55d1a:	imul   rdx
   55d1d:	sar    rdx,0x2
   55d21:	mov    rax,rdx
   55d24:	shr    rax,0x3f
   55d28:	add    rdx,rax
   55d2b:	mov    rax,rdx
   55d2e:	mov    DWORD PTR [rdi+0x30],eax
   55d31:	mov    eax,0x1
   55d36:	sub    eax,ebx
   55d38:	mov    BYTE PTR [r14+0x65],al
   55d3c:	mov    ebx,0x5
   55d41:	mov    DWORD PTR [rdi+0x34],0x5
   55d48:	mov    QWORD PTR [rsp+0x150],r13
   55d50:	mov    r12,rbx
   55d53:	mov    r13d,DWORD PTR [rsp+0x380]
   55d5b:	mov    r15,QWORD PTR [rsp+0x130]
   55d63:	mov    rbx,QWORD PTR [rsp+0x158]
   55d6b:	jmp    65d93 <sqlite3VdbeExec+0x168f3>
   55d70:	mov    rax,QWORD PTR [r14+0x2d8]
   55d77:	mov    rcx,QWORD PTR [rax+0x18]
   55d7b:	mov    QWORD PTR [r14+0x2d8],rcx
   55d82:	test   rax,rax
   55d85:	je     55da2 <sqlite3VdbeExec+0x6902>
   55d87:	mov    QWORD PTR [rsp+0x110],rdi
   55d8f:	mov    rdi,r14
   55d92:	mov    rsi,rax
   55d95:	call   55d9a <sqlite3VdbeExec+0x68fa>
   55d9a:	mov    rdi,QWORD PTR [rsp+0x110]
   55da2:	cmp    QWORD PTR [r14+0x2d8],0x0
   55daa:	jne    55d70 <sqlite3VdbeExec+0x68d0>
   55dac:	mov    DWORD PTR [r14+0x2e8],0x0
   55db7:	mov    DWORD PTR [r14+0x2ec],0x0
   55dc2:	mov    BYTE PTR [r14+0x6d],0x0
   55dc7:	cmp    DWORD PTR [rdi+0x34],0x0
   55dcb:	jne    55dd4 <sqlite3VdbeExec+0x6934>
   55dcd:	mov    ebx,0x65
   55dd2:	jmp    55dd9 <sqlite3VdbeExec+0x6939>
   55dd4:	mov    ebx,0x1
   55dd9:	mov    QWORD PTR [rsp+0x150],r13
   55de1:	mov    r12,rbx
   55de4:	mov    r13d,DWORD PTR [rsp+0x380]
   55dec:	mov    r15,QWORD PTR [rsp+0x130]
   55df4:	mov    rbx,QWORD PTR [rsp+0x158]
   55dfc:	jmp    65d93 <sqlite3VdbeExec+0x168f3>
   55e01:	test   ebx,ebx
   55e03:	jne    55e0e <sqlite3VdbeExec+0x696e>
   55e05:	lea    rax,[rip+0x0]        # 55e0c <sqlite3VdbeExec+0x696c>
   55e0c:	jmp    55e22 <sqlite3VdbeExec+0x6982>
   55e0e:	test   eax,eax
   55e10:	je     55e1b <sqlite3VdbeExec+0x697b>
   55e12:	lea    rax,[rip+0x0]        # 55e19 <sqlite3VdbeExec+0x6979>
   55e19:	jmp    55e22 <sqlite3VdbeExec+0x6982>
   55e1b:	lea    rax,[rip+0x0]        # 55e22 <sqlite3VdbeExec+0x6982>
   55e22:	mov    QWORD PTR [rsp+0x110],rdi
   55e2a:	mov    rsi,rax
   55e2d:	xor    eax,eax
   55e2f:	call   55e34 <sqlite3VdbeExec+0x6994>
   55e34:	mov    ebx,0x1
   55e39:	mov    rdi,QWORD PTR [rsp+0x110]
   55e41:	mov    QWORD PTR [rsp+0x148],rbp
   55e49:	mov    rbp,rbx
   55e4c:	mov    r13,QWORD PTR [rsp+0x130]
   55e54:	mov    rbx,QWORD PTR [rsp+0x158]
   55e5c:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55e61:	mov    r15d,DWORD PTR [rsp+0x37c]
   55e69:	mov    r13,QWORD PTR [rsp+0x150]
   55e71:	mov    QWORD PTR [rsp+0x130],r12
   55e79:	mov    r12d,DWORD PTR [rsp+0x394]
   55e81:	mov    DWORD PTR [rsp+0x398],0x0
   55e8c:	cmp    DWORD PTR [rbp+0x8],0x0
   55e90:	je     55ef7 <sqlite3VdbeExec+0x6a57>
   55e92:	movabs rax,0x200100000
   55e9c:	and    rax,QWORD PTR [r14+0x30]
   55ea0:	test   rax,rax
   55ea3:	je     55ef7 <sqlite3VdbeExec+0x6a57>
   55ea5:	mov    rax,QWORD PTR [r14+0x30]
   55ea9:	and    rax,0x100000
   55eaf:	test   rax,rax
   55eb2:	je     55ec4 <sqlite3VdbeExec+0x6a24>
   55eb4:	mov    ebx,0x8
   55eb9:	mov    r11,rbx
   55ebc:	mov    rbx,rbp
   55ebf:	mov    rbp,r11
   55ec2:	jmp    55ed2 <sqlite3VdbeExec+0x6a32>
   55ec4:	mov    ebx,0xb
   55ec9:	mov    r11,rbx
   55ecc:	mov    rbx,rbp
   55ecf:	mov    rbp,r11
   55ed2:	mov    QWORD PTR [rsp+0x150],r13
   55eda:	mov    QWORD PTR [rsp+0x148],rbx
   55ee2:	mov    r13,QWORD PTR [rsp+0x130]
   55eea:	mov    rbx,QWORD PTR [rsp+0x158]
   55ef2:	jmp    4f712 <sqlite3VdbeExec+0x272>
   55ef7:	mov    DWORD PTR [rsp+0x394],r12d
   55eff:	mov    r12,QWORD PTR [r14+0x20]
   55f03:	movsxd rax,DWORD PTR [rbp+0x4]
   55f07:	mov    QWORD PTR [rsp+0x150],r13
   55f0f:	mov    r13,rax
   55f12:	shl    r13,0x5
   55f16:	mov    QWORD PTR [rsp+0x168],r12
   55f1e:	mov    r12,QWORD PTR [r12+r13*1+0x8]
   55f23:	test   r12,r12
   55f26:	jne    55f45 <sqlite3VdbeExec+0x6aa5>
   55f28:	mov    DWORD PTR [rsp+0x37c],r15d
   55f30:	mov    r12,QWORD PTR [rsp+0x168]
   55f38:	mov    r15d,DWORD PTR [rsp+0x38c]
   55f40:	jmp    56216 <sqlite3VdbeExec+0x6d76>
   55f45:	mov    eax,DWORD PTR [rbp+0x8]
   55f48:	mov    QWORD PTR [rsp+0x170],r13
   55f50:	lea    r13,[rsp+0x398]
   55f58:	mov    rcx,r13
   55f5b:	cmp    BYTE PTR [r12+0x11],0x0
   55f61:	jne    55f77 <sqlite3VdbeExec+0x6ad7>
   55f63:	cmp    BYTE PTR [r12+0x10],0x0
   55f69:	je     55f77 <sqlite3VdbeExec+0x6ad7>
   55f6b:	cmp    BYTE PTR [r12+0x10],0x1
   55f71:	jne    55f9d <sqlite3VdbeExec+0x6afd>
   55f73:	test   eax,eax
   55f75:	je     55f9d <sqlite3VdbeExec+0x6afd>
   55f77:	mov    QWORD PTR [rsp+0x110],rdi
   55f7f:	mov    rdi,r12
   55f82:	mov    rsi,rax
   55f85:	mov    rdx,rcx
   55f88:	call   55f8d <sqlite3VdbeExec+0x6aed>
   55f8d:	mov    r13d,eax
   55f90:	mov    rdi,QWORD PTR [rsp+0x110]
   55f98:	jmp    56021 <sqlite3VdbeExec+0x6b81>
   55f9d:	mov    rdx,QWORD PTR [r12+0x8]
   55fa2:	test   rcx,rcx
   55fa5:	je     55fda <sqlite3VdbeExec+0x6b3a>
   55fa7:	mov    rsi,QWORD PTR [rdx+0x18]
   55fab:	mov    rsi,QWORD PTR [rsi+0x50]
   55faf:	movzx  r8d,BYTE PTR [rsi+0x28]
   55fb4:	shl    r8d,0x18
   55fb8:	movzx  r9d,BYTE PTR [rsi+0x29]
   55fbd:	shl    r9d,0x10
   55fc1:	or     r8d,r9d
   55fc4:	movzx  r9d,BYTE PTR [rsi+0x2a]
   55fc9:	shl    r9d,0x8
   55fcd:	or     r8d,r9d
   55fd0:	movzx  esi,BYTE PTR [rsi+0x2b]
   55fd4:	or     r8d,esi
   55fd7:	mov    DWORD PTR [rcx],r8d
   55fda:	test   eax,eax
   55fdc:	je     5601e <sqlite3VdbeExec+0x6b7e>
   55fde:	mov    rax,QWORD PTR [rdx]
   55fe1:	mov    rcx,QWORD PTR [r12]
   55fe5:	mov    ecx,DWORD PTR [rcx+0x2e8]
   55feb:	cmp    ecx,DWORD PTR [rax+0x80]
   55ff1:	jle    56019 <sqlite3VdbeExec+0x6b79>
   55ff3:	cmp    BYTE PTR [rax+0xa],0x0
   55ff7:	je     56019 <sqlite3VdbeExec+0x6b79>
   55ff9:	mov    QWORD PTR [rsp+0x110],rdi
   56001:	mov    rdi,rax
   56004:	mov    rsi,rcx
   56007:	call   5600c <sqlite3VdbeExec+0x6b6c>
   5600c:	mov    r13d,eax
   5600f:	mov    rdi,QWORD PTR [rsp+0x110]
   56017:	jmp    5601c <sqlite3VdbeExec+0x6b7c>
   56019:	xor    r13d,r13d
   5601c:	jmp    56021 <sqlite3VdbeExec+0x6b81>
   5601e:	xor    r13d,r13d
   56021:	test   r13d,r13d
   56024:	je     560c2 <sqlite3VdbeExec+0x6c22>
   5602a:	mov    eax,r13d
   5602d:	and    eax,0xff
   56032:	cmp    eax,0x5
   56035:	jne    56092 <sqlite3VdbeExec+0x6bf2>
   56037:	mov    rbx,QWORD PTR [rsp+0x150]
   5603f:	mov    rax,rbp
   56042:	sub    rax,rbx
   56045:	movabs rdx,0x2aaaaaaaaaaaaaab
   5604f:	imul   rdx
   56052:	sar    rdx,0x2
   56056:	mov    rax,rdx
   56059:	shr    rax,0x3f
   5605d:	add    rdx,rax
   56060:	mov    rax,rdx
   56063:	mov    DWORD PTR [rdi+0x30],eax
   56066:	mov    DWORD PTR [rdi+0x34],r13d
   5606a:	mov    QWORD PTR [rsp+0x150],rbx
   56072:	mov    r12,r13
   56075:	mov    r13d,DWORD PTR [rsp+0x380]
   5607d:	mov    r15,QWORD PTR [rsp+0x130]
   56085:	mov    rbx,QWORD PTR [rsp+0x158]
   5608d:	jmp    65d93 <sqlite3VdbeExec+0x168f3>
   56092:	mov    rbx,QWORD PTR [rsp+0x150]
   5609a:	mov    QWORD PTR [rsp+0x150],rbx
   560a2:	mov    QWORD PTR [rsp+0x148],rbp
   560aa:	mov    rbp,r13
   560ad:	mov    r13,QWORD PTR [rsp+0x130]
   560b5:	mov    rbx,QWORD PTR [rsp+0x158]
   560bd:	jmp    4f712 <sqlite3VdbeExec+0x272>
   560c2:	movzx  eax,WORD PTR [rdi+0xc8]
   560c9:	shl    rax,0x3a
   560cd:	shr    rax,0x3f
   560d1:	test   eax,eax
   560d3:	jne    560f5 <sqlite3VdbeExec+0x6c55>
   560d5:	mov    DWORD PTR [rsp+0x37c],r15d
   560dd:	mov    r12,QWORD PTR [rsp+0x168]
   560e5:	mov    r15,r13
   560e8:	mov    r13,QWORD PTR [rsp+0x170]
   560f0:	jmp    56216 <sqlite3VdbeExec+0x6d76>
   560f5:	cmp    DWORD PTR [rbp+0x8],0x0
   560f9:	jne    5611b <sqlite3VdbeExec+0x6c7b>
   560fb:	mov    DWORD PTR [rsp+0x37c],r15d
   56103:	mov    r12,QWORD PTR [rsp+0x168]
   5610b:	mov    r15,r13
   5610e:	mov    r13,QWORD PTR [rsp+0x170]
   56116:	jmp    56216 <sqlite3VdbeExec+0x6d76>
   5611b:	cmp    BYTE PTR [r14+0x65],0x0
   56120:	je     5614c <sqlite3VdbeExec+0x6cac>
   56122:	cmp    DWORD PTR [r14+0xd4],0x1
   5612a:	jg     5614c <sqlite3VdbeExec+0x6cac>
   5612c:	mov    DWORD PTR [rsp+0x37c],r15d
   56134:	mov    r12,QWORD PTR [rsp+0x168]
   5613c:	mov    r15,r13
   5613f:	mov    r13,QWORD PTR [rsp+0x170]
   56147:	jmp    56216 <sqlite3VdbeExec+0x6d76>
   5614c:	cmp    DWORD PTR [rdi+0x40],0x0
   56150:	jne    56174 <sqlite3VdbeExec+0x6cd4>
   56152:	mov    eax,DWORD PTR [r14+0x2ec]
   56159:	add    eax,0x1
   5615c:	mov    DWORD PTR [r14+0x2ec],eax
   56163:	mov    eax,DWORD PTR [r14+0x2e8]
   5616a:	add    eax,DWORD PTR [r14+0x2ec]
   56171:	mov    DWORD PTR [rdi+0x40],eax
   56174:	xor    eax,eax
   56176:	mov    ecx,DWORD PTR [rdi+0x40]
   56179:	sub    ecx,0x1
   5617c:	mov    QWORD PTR [rsp+0x110],rdi
   56184:	mov    rdi,r14
   56187:	mov    rsi,rax
   5618a:	mov    rdx,rcx
   5618d:	call   56192 <sqlite3VdbeExec+0x6cf2>
   56192:	mov    r13d,eax
   56195:	mov    rdi,QWORD PTR [rsp+0x110]
   5619d:	test   r13d,r13d
   561a0:	jne    561e5 <sqlite3VdbeExec+0x6d45>
   561a2:	mov    eax,DWORD PTR [rdi+0x40]
   561a5:	mov    rcx,QWORD PTR [r12+0x8]
   561aa:	mov    rdx,QWORD PTR [r12+0x8]
   561af:	mov    rsi,QWORD PTR [r12]
   561b3:	mov    QWORD PTR [rdx+0x8],rsi
   561b7:	mov    rcx,QWORD PTR [rcx]
   561ba:	cmp    eax,DWORD PTR [rcx+0x80]
   561c0:	jle    561dd <sqlite3VdbeExec+0x6d3d>
   561c2:	cmp    BYTE PTR [rcx+0xa],0x0
   561c6:	je     561dd <sqlite3VdbeExec+0x6d3d>
   561c8:	mov    rdi,rcx
   561cb:	mov    rsi,rax
   561ce:	call   561d3 <sqlite3VdbeExec+0x6d33>
   561d3:	mov    rdi,QWORD PTR [rsp+0x110]
   561db:	jmp    561df <sqlite3VdbeExec+0x6d3f>
   561dd:	xor    eax,eax
   561df:	mov    r12d,eax
   561e2:	mov    r13,r12
   561e5:	mov    rax,QWORD PTR [r14+0x2f0]
   561ec:	mov    QWORD PTR [rdi+0x58],rax
   561f0:	mov    rax,QWORD PTR [r14+0x2f8]
   561f7:	mov    QWORD PTR [rdi+0x60],rax
   561fb:	mov    DWORD PTR [rsp+0x37c],r15d
   56203:	mov    r12,QWORD PTR [rsp+0x168]
   5620b:	mov    r15,r13
   5620e:	mov    r13,QWORD PTR [rsp+0x170]
   56216:	test   r15d,r15d
   56219:	jne    563e1 <sqlite3VdbeExec+0x6f41>
   5621f:	cmp    WORD PTR [rbp+0x2],0x0
   56224:	je     563e1 <sqlite3VdbeExec+0x6f41>
   5622a:	mov    eax,DWORD PTR [rsp+0x398]
   56231:	cmp    eax,DWORD PTR [rbp+0xc]
   56234:	jne    56247 <sqlite3VdbeExec+0x6da7>
   56236:	mov    rax,QWORD PTR [r12+r13*1+0x18]
   5623b:	mov    eax,DWORD PTR [rax+0x4]
   5623e:	cmp    eax,DWORD PTR [rbp+0x10]
   56241:	je     563e1 <sqlite3VdbeExec+0x6f41>
   56247:	mov    rax,QWORD PTR [rdi+0xa8]
   5624e:	test   rax,rax
   56251:	je     5626e <sqlite3VdbeExec+0x6dce>
   56253:	mov    QWORD PTR [rsp+0x110],rdi
   5625b:	mov    rdi,r14
   5625e:	mov    rsi,rax
   56261:	call   56266 <sqlite3VdbeExec+0x6dc6>
   56266:	mov    rdi,QWORD PTR [rsp+0x110]
   5626e:	lea    r12,[rip+0x0]        # 56275 <sqlite3VdbeExec+0x6dd5>
   56275:	test   r12,r12
   56278:	jne    56282 <sqlite3VdbeExec+0x6de2>
   5627a:	xor    r12d,r12d
   5627d:	mov    r15,r12
   56280:	jmp    562f1 <sqlite3VdbeExec+0x6e51>
   56282:	mov    QWORD PTR [rsp+0x110],rdi
   5628a:	mov    rdi,r12
   5628d:	call   56292 <sqlite3VdbeExec+0x6df2>
   56292:	lea    r13,[rax+0x1]
   56296:	mov    rdi,QWORD PTR [rsp+0x110]
   5629e:	test   r14,r14
   562a1:	je     562bb <sqlite3VdbeExec+0x6e1b>
   562a3:	mov    rdi,r14
   562a6:	mov    rsi,r13
   562a9:	call   562ae <sqlite3VdbeExec+0x6e0e>
   562ae:	mov    r15,rax
   562b1:	mov    rdi,QWORD PTR [rsp+0x110]
   562b9:	jmp    562ce <sqlite3VdbeExec+0x6e2e>
   562bb:	mov    rdi,r13
   562be:	call   562c3 <sqlite3VdbeExec+0x6e23>
   562c3:	mov    r15,rax
   562c6:	mov    rdi,QWORD PTR [rsp+0x110]
   562ce:	test   r15,r15
   562d1:	je     562f1 <sqlite3VdbeExec+0x6e51>
   562d3:	mov    QWORD PTR [rsp+0x110],rdi
   562db:	mov    rdi,r15
   562de:	mov    rsi,r12
   562e1:	mov    rdx,r13
   562e4:	call   562e9 <sqlite3VdbeExec+0x6e49>
   562e9:	mov    rdi,QWORD PTR [rsp+0x110]
   562f1:	mov    QWORD PTR [rdi+0xa8],r15
   562f8:	mov    rax,QWORD PTR [r14+0x20]
   562fc:	movsxd rcx,DWORD PTR [rbp+0x4]
   56300:	shl    rcx,0x5
   56304:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   56309:	mov    eax,DWORD PTR [rax]
   5630b:	cmp    eax,DWORD PTR [rsp+0x398]
   56312:	je     563b0 <sqlite3VdbeExec+0x6f10>
   56318:	movsxd rax,DWORD PTR [rbp+0x4]
   5631c:	test   eax,eax
   5631e:	jl     56356 <sqlite3VdbeExec+0x6eb6>
   56320:	mov    rcx,QWORD PTR [r14+0x20]
   56324:	shl    rax,0x5
   56328:	mov    rax,QWORD PTR [rcx+rax*1+0x18]
   5632d:	movzx  ecx,WORD PTR [rax+0x72]
   56331:	or     ecx,0x8
   56334:	mov    WORD PTR [rax+0x72],cx
   56338:	mov    rax,QWORD PTR [r14+0x20]
   5633c:	mov    rax,QWORD PTR [rax+0x38]
   56340:	movzx  ecx,WORD PTR [rax+0x72]
   56344:	or     ecx,0x8
   56347:	mov    WORD PTR [rax+0x72],cx
   5634b:	mov    eax,DWORD PTR [r14+0x2c]
   5634f:	and    eax,0xffffffef
   56352:	mov    DWORD PTR [r14+0x2c],eax
   56356:	cmp    DWORD PTR [r14+0x48],0x0
   5635b:	jne    563b0 <sqlite3VdbeExec+0x6f10>
   5635d:	xor    r12d,r12d
   56360:	jmp    563aa <sqlite3VdbeExec+0x6f0a>
   56362:	mov    rax,QWORD PTR [r14+0x20]
   56366:	mov    rcx,r12
   56369:	shl    rcx,0x5
   5636d:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   56372:	movzx  eax,WORD PTR [rax+0x72]
   56376:	and    eax,0x8
   56379:	cmp    eax,0x8
   5637c:	jne    563a6 <sqlite3VdbeExec+0x6f06>
   5637e:	mov    rax,QWORD PTR [r14+0x20]
   56382:	mov    rcx,r12
   56385:	shl    rcx,0x5
   56389:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   5638e:	mov    QWORD PTR [rsp+0x110],rdi
   56396:	mov    rdi,rax
   56399:	call   5639e <sqlite3VdbeExec+0x6efe>
   5639e:	mov    rdi,QWORD PTR [rsp+0x110]
   563a6:	add    r12d,0x1
   563aa:	cmp    r12d,DWORD PTR [r14+0x28]
   563ae:	jl     56362 <sqlite3VdbeExec+0x6ec2>
   563b0:	movzx  eax,WORD PTR [rdi+0xc8]
   563b7:	and    rax,0xfffffffffffffffc
   563bb:	or     rax,0x1
   563bf:	mov    WORD PTR [rdi+0xc8],ax
   563c6:	mov    r12d,0x11
   563cc:	movzx  eax,WORD PTR [rdi+0xc8]
   563d3:	and    rax,0xffffffffffffffef
   563d7:	mov    WORD PTR [rdi+0xc8],ax
   563de:	mov    r15,r12
   563e1:	test   r15d,r15d
   563e4:	je     56406 <sqlite3VdbeExec+0x6f66>
   563e6:	mov    QWORD PTR [rsp+0x148],rbp
   563ee:	mov    rbp,r15
   563f1:	mov    r13,QWORD PTR [rsp+0x130]
   563f9:	mov    rbx,QWORD PTR [rsp+0x158]
   56401:	jmp    4f712 <sqlite3VdbeExec+0x272>
   56406:	mov    DWORD PTR [rsp+0x38c],r15d
   5640e:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   56413:	mov    r15d,DWORD PTR [rsp+0x37c]
   5641b:	mov    r13,QWORD PTR [rsp+0x150]
   56423:	mov    QWORD PTR [rsp+0x130],r12
   5642b:	mov    r12d,DWORD PTR [rsp+0x394]
   56433:	movsxd rax,DWORD PTR [rbp+0x4]
   56437:	mov    ecx,DWORD PTR [rbp+0xc]
   5643a:	mov    rdx,QWORD PTR [r14+0x20]
   5643e:	shl    rax,0x5
   56442:	mov    rax,QWORD PTR [rdx+rax*1+0x8]
   56447:	mov    rdx,QWORD PTR [rax+0x8]
   5644b:	mov    rsi,QWORD PTR [rax+0x8]
   5644f:	mov    r8,QWORD PTR [rax]
   56452:	mov    QWORD PTR [rsi+0x8],r8
   56456:	cmp    ecx,0xf
   56459:	jne    56470 <sqlite3VdbeExec+0x6fd0>
   5645b:	mov    rcx,QWORD PTR [rdx]
   5645e:	mov    ecx,DWORD PTR [rcx+0x84]
   56464:	add    ecx,DWORD PTR [rax+0x1c]
   56467:	mov    DWORD PTR [rsp+0x398],ecx
   5646e:	jmp    564aa <sqlite3VdbeExec+0x700a>
   56470:	mov    rax,QWORD PTR [rdx+0x18]
   56474:	mov    rax,QWORD PTR [rax+0x50]
   56478:	shl    ecx,0x2
   5647b:	add    ecx,0x24
   5647e:	movsxd rcx,ecx
   56481:	movzx  edx,BYTE PTR [rax+rcx*1]
   56485:	shl    edx,0x18
   56488:	movzx  esi,BYTE PTR [rax+rcx*1+0x1]
   5648d:	shl    esi,0x10
   56490:	or     edx,esi
   56492:	movzx  esi,BYTE PTR [rax+rcx*1+0x2]
   56497:	shl    esi,0x8
   5649a:	or     edx,esi
   5649c:	movzx  eax,BYTE PTR [rax+rcx*1+0x3]
   564a1:	or     edx,eax
   564a3:	mov    DWORD PTR [rsp+0x398],edx
   564aa:	mov    rax,QWORD PTR [rdi+0x68]
   564ae:	movsxd rcx,DWORD PTR [rbp+0x8]
   564b2:	imul   rcx,rcx,0x38
   564b6:	lea    rdx,[rax+rcx*1]
   564ba:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   564bf:	and    eax,0x9000
   564c4:	test   eax,eax
   564c6:	je     564e5 <sqlite3VdbeExec+0x7045>
   564c8:	mov    QWORD PTR [rsp+0x110],rdi
   564d0:	mov    rdi,rdx
   564d3:	call   564d8 <sqlite3VdbeExec+0x7038>
   564d8:	mov    rdi,QWORD PTR [rsp+0x110]
   564e0:	mov    rdx,rax
   564e3:	jmp    564eb <sqlite3VdbeExec+0x704b>
   564e5:	mov    WORD PTR [rdx+0x14],0x4
   564eb:	movsxd rax,DWORD PTR [rsp+0x398]
   564f3:	mov    QWORD PTR [rdx],rax
   564f6:	mov    DWORD PTR [rsp+0x37c],r15d
   564fe:	mov    QWORD PTR [rsp+0x150],r13
   56506:	mov    DWORD PTR [rsp+0x394],r12d
   5650e:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   56513:	mov    r15d,DWORD PTR [rsp+0x37c]
   5651b:	mov    r13,QWORD PTR [rsp+0x150]
   56523:	mov    QWORD PTR [rsp+0x130],r12
   5652b:	mov    r12d,DWORD PTR [rsp+0x394]
   56533:	mov    DWORD PTR [rsp+0x394],r12d
   5653b:	mov    r12,QWORD PTR [r14+0x20]
   5653f:	movsxd rax,DWORD PTR [rbp+0x4]
   56543:	mov    QWORD PTR [rsp+0x150],r13
   5654b:	mov    r13,rax
   5654e:	shl    r13,0x5
   56552:	mov    rax,QWORD PTR [r12+r13*1+0x8]
   56557:	mov    ecx,DWORD PTR [rbp+0x8]
   5655a:	mov    edx,DWORD PTR [rbp+0xc]
   5655d:	mov    DWORD PTR [rsp+0x37c],r15d
   56565:	mov    QWORD PTR [rsp+0x110],rdi
   5656d:	mov    rdi,rax
   56570:	mov    rsi,rcx
   56573:	call   56578 <sqlite3VdbeExec+0x70d8>
   56578:	mov    r15d,eax
   5657b:	mov    rdi,QWORD PTR [rsp+0x110]
   56583:	cmp    DWORD PTR [rbp+0x8],0x1
   56587:	jne    567bf <sqlite3VdbeExec+0x731f>
   5658d:	mov    rax,QWORD PTR [r12+r13*1+0x18]
   56592:	mov    ecx,DWORD PTR [rbp+0xc]
   56595:	movzx  edx,WORD PTR [rbp+0x2]
   56599:	sub    ecx,edx
   5659b:	mov    DWORD PTR [rax],ecx
   5659d:	mov    eax,DWORD PTR [r14+0x2c]
   565a1:	or     eax,0x1
   565a4:	mov    DWORD PTR [r14+0x2c],eax
   565a8:	movsxd rax,DWORD PTR [rbp+0x4]
   565ac:	mov    rcx,QWORD PTR [r14+0x20]
   565b0:	shl    rax,0x5
   565b4:	mov    rax,QWORD PTR [rcx+rax*1+0x18]
   565b9:	mov    r12,QWORD PTR [rax+0x10]
   565bd:	mov    r13,r12
   565c0:	jmp    567aa <sqlite3VdbeExec+0x730a>
   565c5:	mov    DWORD PTR [rsp+0x398],r15d
   565cd:	mov    r15,QWORD PTR [r12+0x30]
   565d2:	test   r15,r15
   565d5:	jne    565e4 <sqlite3VdbeExec+0x7144>
   565d7:	mov    QWORD PTR [rsp+0x170],r13
   565df:	jmp    566aa <sqlite3VdbeExec+0x720a>
   565e4:	mov    QWORD PTR [rsp+0x170],r13
   565ec:	mov    r13,QWORD PTR [r15+0x38]
   565f0:	mov    rax,QWORD PTR [r13+0x18]
   565f4:	mov    QWORD PTR [rsp+0x110],rdi
   565fc:	mov    rdi,r14
   565ff:	mov    rsi,rax
   56602:	call   56607 <sqlite3VdbeExec+0x7167>
   56607:	mov    rax,QWORD PTR [r13+0x20]
   5660b:	mov    rdi,QWORD PTR [rsp+0x110]
   56613:	test   rax,rax
   56616:	je     5662b <sqlite3VdbeExec+0x718b>
   56618:	mov    rdi,r14
   5661b:	mov    rsi,rax
   5661e:	call   56623 <sqlite3VdbeExec+0x7183>
   56623:	mov    rdi,QWORD PTR [rsp+0x110]
   5662b:	mov    rax,QWORD PTR [r13+0x28]
   5662f:	test   rax,rax
   56632:	je     5664f <sqlite3VdbeExec+0x71af>
   56634:	mov    QWORD PTR [rsp+0x110],rdi
   5663c:	mov    rdi,r14
   5663f:	mov    rsi,rax
   56642:	call   56647 <sqlite3VdbeExec+0x71a7>
   56647:	mov    rdi,QWORD PTR [rsp+0x110]
   5664f:	mov    rax,QWORD PTR [r13+0x10]
   56653:	mov    QWORD PTR [rsp+0x110],rdi
   5665b:	mov    rdi,r14
   5665e:	mov    rsi,rax
   56661:	call   56666 <sqlite3VdbeExec+0x71c6>
   56666:	mov    rax,QWORD PTR [r15+0x18]
   5666a:	mov    rdi,QWORD PTR [rsp+0x110]
   56672:	test   rax,rax
   56675:	je     5668a <sqlite3VdbeExec+0x71ea>
   56677:	mov    rdi,r14
   5667a:	mov    rsi,rax
   5667d:	call   56682 <sqlite3VdbeExec+0x71e2>
   56682:	mov    rdi,QWORD PTR [rsp+0x110]
   5668a:	test   r15,r15
   5668d:	je     566aa <sqlite3VdbeExec+0x720a>
   5668f:	mov    QWORD PTR [rsp+0x110],rdi
   56697:	mov    rdi,r14
   5669a:	mov    rsi,r15
   5669d:	call   566a2 <sqlite3VdbeExec+0x7202>
   566a2:	mov    rdi,QWORD PTR [rsp+0x110]
   566aa:	mov    QWORD PTR [r12+0x30],0x0
   566b3:	mov    r13,QWORD PTR [r12+0x38]
   566b8:	test   r13,r13
   566bb:	je     5677f <sqlite3VdbeExec+0x72df>
   566c1:	mov    r15,QWORD PTR [r13+0x38]
   566c5:	mov    rax,QWORD PTR [r15+0x18]
   566c9:	mov    QWORD PTR [rsp+0x110],rdi
   566d1:	mov    rdi,r14
   566d4:	mov    rsi,rax
   566d7:	call   566dc <sqlite3VdbeExec+0x723c>
   566dc:	mov    rax,QWORD PTR [r15+0x20]
   566e0:	mov    rdi,QWORD PTR [rsp+0x110]
   566e8:	test   rax,rax
   566eb:	je     56700 <sqlite3VdbeExec+0x7260>
   566ed:	mov    rdi,r14
   566f0:	mov    rsi,rax
   566f3:	call   566f8 <sqlite3VdbeExec+0x7258>
   566f8:	mov    rdi,QWORD PTR [rsp+0x110]
   56700:	mov    rax,QWORD PTR [r15+0x28]
   56704:	test   rax,rax
   56707:	je     56724 <sqlite3VdbeExec+0x7284>
   56709:	mov    QWORD PTR [rsp+0x110],rdi
   56711:	mov    rdi,r14
   56714:	mov    rsi,rax
   56717:	call   5671c <sqlite3VdbeExec+0x727c>
   5671c:	mov    rdi,QWORD PTR [rsp+0x110]
   56724:	mov    rax,QWORD PTR [r15+0x10]
   56728:	mov    QWORD PTR [rsp+0x110],rdi
   56730:	mov    rdi,r14
   56733:	mov    rsi,rax
   56736:	call   5673b <sqlite3VdbeExec+0x729b>
   5673b:	mov    rax,QWORD PTR [r13+0x18]
   5673f:	mov    rdi,QWORD PTR [rsp+0x110]
   56747:	test   rax,rax
   5674a:	je     5675f <sqlite3VdbeExec+0x72bf>
   5674c:	mov    rdi,r14
   5674f:	mov    rsi,rax
   56752:	call   56757 <sqlite3VdbeExec+0x72b7>
   56757:	mov    rdi,QWORD PTR [rsp+0x110]
   5675f:	test   r13,r13
   56762:	je     5677f <sqlite3VdbeExec+0x72df>
   56764:	mov    QWORD PTR [rsp+0x110],rdi
   5676c:	mov    rdi,r14
   5676f:	mov    rsi,r13
   56772:	call   56777 <sqlite3VdbeExec+0x72d7>
   56777:	mov    rdi,QWORD PTR [rsp+0x110]
   5677f:	mov    QWORD PTR [r12+0x38],0x0
   56788:	mov    r12,QWORD PTR [r12+0x8]
   5678d:	mov    r15d,DWORD PTR [rsp+0x398]
   56795:	mov    r13,QWORD PTR [rsp+0x170]
   5679d:	test   r12,r12
   567a0:	jne    565c5 <sqlite3VdbeExec+0x7125>
   567a6:	mov    r13,QWORD PTR [r13+0x0]
   567aa:	test   r13,r13
   567ad:	je     567d0 <sqlite3VdbeExec+0x7330>
   567af:	mov    rax,QWORD PTR [r13+0x10]
   567b3:	cmp    BYTE PTR [rax+0x3f],0x0
   567b7:	jne    567a6 <sqlite3VdbeExec+0x7306>
   567b9:	mov    r12,QWORD PTR [rax+0x48]
   567bd:	jmp    5679d <sqlite3VdbeExec+0x72fd>
   567bf:	cmp    DWORD PTR [rbp+0x8],0x2
   567c3:	jne    567d0 <sqlite3VdbeExec+0x7330>
   567c5:	mov    rax,QWORD PTR [r12+r13*1+0x18]
   567ca:	mov    ecx,DWORD PTR [rbp+0xc]
   567cd:	mov    BYTE PTR [rax+0x70],cl
   567d0:	cmp    DWORD PTR [rbp+0x4],0x1
   567d4:	jne    5680d <sqlite3VdbeExec+0x736d>
   567d6:	mov    rax,QWORD PTR [r14+0x8]
   567da:	jmp    567f6 <sqlite3VdbeExec+0x7356>
   567dc:	movzx  ecx,WORD PTR [rax+0xc8]
   567e3:	and    rcx,0xfffffffffffffffc
   567e7:	or     rcx,0x1
   567eb:	mov    WORD PTR [rax+0xc8],cx
   567f2:	mov    rax,QWORD PTR [rax+0x10]
   567f6:	test   rax,rax
   567f9:	jne    567dc <sqlite3VdbeExec+0x733c>
   567fb:	movzx  eax,WORD PTR [rdi+0xc8]
   56802:	and    rax,0xfffffffffffffffc
   56806:	mov    WORD PTR [rdi+0xc8],ax
   5680d:	test   r15d,r15d
   56810:	je     56832 <sqlite3VdbeExec+0x7392>
   56812:	mov    QWORD PTR [rsp+0x148],rbp
   5681a:	mov    rbp,r15
   5681d:	mov    r13,QWORD PTR [rsp+0x130]
   56825:	mov    rbx,QWORD PTR [rsp+0x158]
   5682d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   56832:	mov    DWORD PTR [rsp+0x38c],r15d
   5683a:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5683f:	mov    r15d,DWORD PTR [rsp+0x37c]
   56847:	mov    r13,QWORD PTR [rsp+0x150]
   5684f:	mov    QWORD PTR [rsp+0x130],r12
   56857:	mov    r12d,DWORD PTR [rsp+0x394]
   5685f:	mov    rax,QWORD PTR [rdi+0x78]
   56863:	movsxd rcx,DWORD PTR [rbp+0x4]
   56867:	mov    DWORD PTR [rsp+0x394],r12d
   5686f:	mov    r12,QWORD PTR [rax+rcx*8]
   56873:	test   r12,r12
   56876:	je     56971 <sqlite3VdbeExec+0x74d1>
   5687c:	mov    eax,DWORD PTR [r12+0x3c]
   56881:	cmp    eax,DWORD PTR [rbp+0x8]
   56884:	jne    56971 <sqlite3VdbeExec+0x74d1>
   5688a:	mov    QWORD PTR [rsp+0x170],r12
   56892:	mov    r12,QWORD PTR [r12+0x28]
   56897:	mov    QWORD PTR [rsp+0x168],r12
   5689f:	mov    r12,QWORD PTR [r12+0x18]
   568a4:	test   r12,r12
   568a7:	je     5692e <sqlite3VdbeExec+0x748e>
   568ad:	cmp    DWORD PTR [rip+0x0],0x0        # 568b4 <sqlite3VdbeExec+0x7414>
   568b4:	je     5690e <sqlite3VdbeExec+0x746e>
   568b6:	mov    rax,QWORD PTR [rip+0x0]        # 568bd <sqlite3VdbeExec+0x741d>
   568bd:	mov    QWORD PTR [rsp+0x110],rdi
   568c5:	mov    rdi,r12
   568c8:	mov    r10,rax
   568cb:	call   r10
   568ce:	mov    rcx,QWORD PTR [rip+0x0]        # 568d5 <sqlite3VdbeExec+0x7435>
   568d5:	movsxd rax,eax
   568d8:	sub    rcx,rax
   568db:	mov    QWORD PTR [rip+0x0],rcx        # 568e2 <sqlite3VdbeExec+0x7442>
   568e2:	mov    rax,QWORD PTR [rip+0x0]        # 568e9 <sqlite3VdbeExec+0x7449>
   568e9:	sub    rax,0x1
   568ed:	mov    QWORD PTR [rip+0x0],rax        # 568f4 <sqlite3VdbeExec+0x7454>
   568f4:	mov    rax,QWORD PTR [rip+0x0]        # 568fb <sqlite3VdbeExec+0x745b>
   568fb:	mov    rdi,r12
   568fe:	mov    r10,rax
   56901:	call   r10
   56904:	mov    rdi,QWORD PTR [rsp+0x110]
   5690c:	jmp    5692e <sqlite3VdbeExec+0x748e>
   5690e:	mov    rax,QWORD PTR [rip+0x0]        # 56915 <sqlite3VdbeExec+0x7475>
   56915:	mov    QWORD PTR [rsp+0x110],rdi
   5691d:	mov    rdi,r12
   56920:	mov    r10,rax
   56923:	call   r10
   56926:	mov    rdi,QWORD PTR [rsp+0x110]
   5692e:	mov    r12,QWORD PTR [rsp+0x168]
   56936:	mov    QWORD PTR [r12+0x18],0x0
   5693f:	mov    BYTE PTR [r12],0x1
   56944:	mov    DWORD PTR [rsp+0x37c],r15d
   5694c:	mov    QWORD PTR [rsp+0x150],r13
   56954:	mov    QWORD PTR [rsp+0x160],rbx
   5695c:	mov    r12d,DWORD PTR [rsp+0x38c]
   56964:	mov    r13,QWORD PTR [rsp+0x170]
   5696c:	jmp    56c7b <sqlite3VdbeExec+0x77db>
   56971:	movzx  eax,WORD PTR [rdi+0xc8]
   56978:	shl    rax,0x3e
   5697c:	shr    rax,0x3e
   56980:	cmp    eax,0x1
   56983:	jne    569b2 <sqlite3VdbeExec+0x7512>
   56985:	mov    ebx,0x204
   5698a:	mov    QWORD PTR [rsp+0x150],r13
   56992:	mov    QWORD PTR [rsp+0x148],rbp
   5699a:	mov    rbp,rbx
   5699d:	mov    r13,QWORD PTR [rsp+0x130]
   569a5:	mov    rbx,QWORD PTR [rsp+0x158]
   569ad:	jmp    4f712 <sqlite3VdbeExec+0x272>
   569b2:	mov    r12d,DWORD PTR [rbp+0x8]
   569b6:	mov    QWORD PTR [rsp+0x150],r13
   569be:	movsxd r13,DWORD PTR [rbp+0xc]
   569c2:	mov    rax,QWORD PTR [r14+0x20]
   569c6:	mov    rcx,r13
   569c9:	shl    rcx,0x5
   569cd:	mov    QWORD PTR [rsp+0x170],r13
   569d5:	mov    r13,QWORD PTR [rax+rcx*1+0x8]
   569da:	cmp    BYTE PTR [rbp+0x0],0x74
   569de:	jne    56af2 <sqlite3VdbeExec+0x7652>
   569e4:	movzx  edx,WORD PTR [rbp+0x2]
   569e8:	and    edx,0x8
   569eb:	mov    QWORD PTR [rsp+0x168],r13
   569f3:	mov    r13d,edx
   569f6:	or     r13d,0x4
   569fa:	mov    rdx,QWORD PTR [rax+rcx*1+0x18]
   569ff:	movzx  edx,BYTE PTR [rdx+0x70]
   56a03:	movzx  esi,BYTE PTR [rdi+0xc5]
   56a0a:	cmp    edx,esi
   56a0c:	jge    56a1d <sqlite3VdbeExec+0x757d>
   56a0e:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   56a13:	movzx  eax,BYTE PTR [rax+0x70]
   56a17:	mov    BYTE PTR [rdi+0xc5],al
   56a1d:	movzx  eax,WORD PTR [rbp+0x2]
   56a21:	and    eax,0x10
   56a24:	test   eax,eax
   56a26:	je     56af0 <sqlite3VdbeExec+0x7650>
   56a2c:	mov    rax,r12
   56a2f:	imul   rax,rax,0x38
   56a33:	lea    r12,[rbx+rax*1]
   56a37:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   56a3c:	mov    ecx,eax
   56a3e:	and    ecx,0x24
   56a41:	test   ecx,ecx
   56a43:	je     56a4e <sqlite3VdbeExec+0x75ae>
   56a45:	mov    rax,QWORD PTR [r12]
   56a49:	jmp    56ad1 <sqlite3VdbeExec+0x7631>
   56a4e:	mov    ecx,eax
   56a50:	and    ecx,0x8
   56a53:	test   ecx,ecx
   56a55:	je     56aa6 <sqlite3VdbeExec+0x7606>
   56a57:	movsd  xmm1,QWORD PTR [r12]
   56a5d:	movabs r11,0xc3dfffffffffffff
   56a67:	movq   xmm0,r11
   56a6c:	ucomisd xmm0,xmm1
   56a70:	jbe    56a7e <sqlite3VdbeExec+0x75de>
   56a72:	movabs rax,0x8000000000000000
   56a7c:	jmp    56aa4 <sqlite3VdbeExec+0x7604>
   56a7e:	movabs r11,0x43dfffffffffffff
   56a88:	movq   xmm0,r11
   56a8d:	ucomisd xmm1,xmm0
   56a91:	jbe    56a9f <sqlite3VdbeExec+0x75ff>
   56a93:	movabs rax,0x7fffffffffffffff
   56a9d:	jmp    56aa4 <sqlite3VdbeExec+0x7604>
   56a9f:	cvttsd2si rax,xmm1
   56aa4:	jmp    56ad1 <sqlite3VdbeExec+0x7631>
   56aa6:	and    eax,0x12
   56aa9:	test   eax,eax
   56aab:	je     56acf <sqlite3VdbeExec+0x762f>
   56aad:	cmp    QWORD PTR [r12+0x8],0x0
   56ab3:	je     56acf <sqlite3VdbeExec+0x762f>
   56ab5:	mov    QWORD PTR [rsp+0x110],rdi
   56abd:	mov    rdi,r12
   56ac0:	call   56ac5 <sqlite3VdbeExec+0x7625>
   56ac5:	mov    rdi,QWORD PTR [rsp+0x110]
   56acd:	jmp    56ad1 <sqlite3VdbeExec+0x7631>
   56acf:	xor    eax,eax
   56ad1:	mov    QWORD PTR [r12],rax
   56ad5:	movzx  eax,WORD PTR [r12+0x14]
   56adb:	and    eax,0xfffff240
   56ae0:	or     eax,0x4
   56ae3:	mov    WORD PTR [r12+0x14],ax
   56ae9:	mov    rax,QWORD PTR [r12]
   56aed:	mov    r12d,eax
   56af0:	jmp    56afd <sqlite3VdbeExec+0x765d>
   56af2:	mov    QWORD PTR [rsp+0x168],r13
   56afa:	xor    r13d,r13d
   56afd:	cmp    BYTE PTR [rbp+0x1],0xf7
   56b01:	jne    56b21 <sqlite3VdbeExec+0x7681>
   56b03:	mov    DWORD PTR [rsp+0x398],r13d
   56b0b:	mov    r13,QWORD PTR [rbp+0x10]
   56b0f:	movzx  eax,WORD PTR [r13+0x8]
   56b14:	mov    QWORD PTR [rsp+0x178],r13
   56b1c:	mov    r13d,eax
   56b1f:	jmp    56b4e <sqlite3VdbeExec+0x76ae>
   56b21:	mov    DWORD PTR [rsp+0x398],r13d
   56b29:	cmp    BYTE PTR [rbp+0x1],0xfd
   56b2d:	je     56b3f <sqlite3VdbeExec+0x769f>
   56b2f:	xor    r13d,r13d
   56b32:	xor    r11d,r11d
   56b35:	mov    QWORD PTR [rsp+0x178],r11
   56b3d:	jmp    56b4e <sqlite3VdbeExec+0x76ae>
   56b3f:	mov    r13d,DWORD PTR [rbp+0x10]
   56b43:	xor    r11d,r11d
   56b46:	mov    QWORD PTR [rsp+0x178],r11
   56b4e:	mov    eax,DWORD PTR [rbp+0x4]
   56b51:	xor    ecx,ecx
   56b53:	mov    QWORD PTR [rsp+0x110],rdi
   56b5b:	mov    rsi,rax
   56b5e:	mov    rdx,r13
   56b61:	call   56b66 <sqlite3VdbeExec+0x76c6>
   56b66:	mov    r13,rax
   56b69:	mov    rdi,QWORD PTR [rsp+0x110]
   56b71:	test   r13,r13
   56b74:	jne    56b8e <sqlite3VdbeExec+0x76ee>
   56b76:	mov    r13,QWORD PTR [rsp+0x150]
   56b7e:	mov    rbx,rbp
   56b81:	mov    rbp,QWORD PTR [rsp+0x158]
   56b89:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   56b8e:	mov    DWORD PTR [rsp+0x37c],r15d
   56b96:	mov    r15,QWORD PTR [rsp+0x170]
   56b9e:	mov    BYTE PTR [r13+0x1],r15b
   56ba2:	mov    BYTE PTR [r13+0x2],0x1
   56ba7:	movzx  eax,BYTE PTR [r13+0x5]
   56bac:	and    rax,0xfffffffffffffffb
   56bb0:	or     rax,0x4
   56bb4:	mov    BYTE PTR [r13+0x5],al
   56bb8:	mov    DWORD PTR [r13+0x3c],r12d
   56bbc:	mov    rax,QWORD PTR [r13+0x28]
   56bc0:	mov    r15,QWORD PTR [rsp+0x168]
   56bc8:	cmp    BYTE PTR [r15+0x11],0x0
   56bcd:	je     56c23 <sqlite3VdbeExec+0x7783>
   56bcf:	mov    rcx,QWORD PTR [r15+0x8]
   56bd3:	mov    rdx,QWORD PTR [r15]
   56bd6:	mov    QWORD PTR [rcx+0x8],rdx
   56bda:	mov    QWORD PTR [rsp+0x188],r13
   56be2:	mov    QWORD PTR [rsp+0x160],rbx
   56bea:	mov    r13d,DWORD PTR [rsp+0x398]
   56bf2:	mov    rbx,QWORD PTR [rsp+0x178]
   56bfa:	mov    rdi,r15
   56bfd:	mov    rsi,r12
   56c00:	mov    rdx,r13
   56c03:	mov    rcx,rbx
   56c06:	mov    r8,rax
   56c09:	call   56c0e <sqlite3VdbeExec+0x776e>
   56c0e:	mov    r12d,eax
   56c11:	mov    rdi,QWORD PTR [rsp+0x110]
   56c19:	mov    r13,QWORD PTR [rsp+0x188]
   56c21:	jmp    56c6a <sqlite3VdbeExec+0x77ca>
   56c23:	mov    QWORD PTR [rsp+0x188],r13
   56c2b:	mov    r13d,DWORD PTR [rsp+0x398]
   56c33:	mov    QWORD PTR [rsp+0x160],rbx
   56c3b:	mov    rbx,QWORD PTR [rsp+0x178]
   56c43:	mov    rdi,r15
   56c46:	mov    rsi,r12
   56c49:	mov    rdx,r13
   56c4c:	mov    rcx,rbx
   56c4f:	mov    r8,rax
   56c52:	call   56c57 <sqlite3VdbeExec+0x77b7>
   56c57:	mov    r12d,eax
   56c5a:	mov    rdi,QWORD PTR [rsp+0x110]
   56c62:	mov    r13,QWORD PTR [rsp+0x188]
   56c6a:	mov    QWORD PTR [r13+0x30],rbx
   56c6e:	xor    eax,eax
   56c70:	cmp    BYTE PTR [rbp+0x1],0xf7
   56c74:	setne  al
   56c77:	mov    BYTE PTR [r13+0x4],al
   56c7b:	mov    rax,QWORD PTR [r13+0x28]
   56c7f:	movzx  ecx,WORD PTR [rbp+0x2]
   56c83:	and    ecx,0x3
   56c86:	mov    BYTE PTR [rax+0x3],cl
   56c89:	test   r12d,r12d
   56c8c:	je     56cae <sqlite3VdbeExec+0x780e>
   56c8e:	mov    QWORD PTR [rsp+0x148],rbp
   56c96:	mov    rbp,r12
   56c99:	mov    r13,QWORD PTR [rsp+0x130]
   56ca1:	mov    rbx,QWORD PTR [rsp+0x158]
   56ca9:	jmp    4f712 <sqlite3VdbeExec+0x272>
   56cae:	mov    DWORD PTR [rsp+0x38c],r12d
   56cb6:	mov    rbx,QWORD PTR [rsp+0x160]
   56cbe:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   56cc3:	mov    QWORD PTR [rsp+0x160],rbx
   56ccb:	mov    QWORD PTR [rsp+0x130],r12
   56cd3:	mov    rax,QWORD PTR [rdi+0x78]
   56cd7:	movsxd rcx,DWORD PTR [rbp+0x8]
   56cdb:	mov    r12,QWORD PTR [rax+rcx*8]
   56cdf:	mov    eax,DWORD PTR [rbp+0x4]
   56ce2:	movsx  ecx,WORD PTR [r12+0x40]
   56ce8:	xor    edx,edx
   56cea:	mov    QWORD PTR [rsp+0x110],rdi
   56cf2:	mov    rsi,rax
   56cf5:	mov    r11,rdx
   56cf8:	mov    rdx,rcx
   56cfb:	mov    rcx,r11
   56cfe:	call   56d03 <sqlite3VdbeExec+0x7863>
   56d03:	mov    rdi,QWORD PTR [rsp+0x110]
   56d0b:	test   rax,rax
   56d0e:	jne    56d28 <sqlite3VdbeExec+0x7888>
   56d10:	mov    r13,QWORD PTR [rsp+0x150]
   56d18:	mov    rbx,rbp
   56d1b:	mov    rbp,QWORD PTR [rsp+0x158]
   56d23:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   56d28:	mov    BYTE PTR [rax+0x2],0x1
   56d2c:	movzx  ecx,BYTE PTR [rax+0x5]
   56d30:	and    rcx,0xfffffffffffffffe
   56d34:	or     rcx,0x1
   56d38:	mov    BYTE PTR [rax+0x5],cl
   56d3b:	mov    rcx,QWORD PTR [r12+0x30]
   56d40:	mov    QWORD PTR [rax+0x30],rcx
   56d44:	movzx  ecx,BYTE PTR [r12+0x4]
   56d4a:	mov    BYTE PTR [rax+0x4],cl
   56d4d:	mov    ecx,DWORD PTR [r12+0x3c]
   56d52:	mov    DWORD PTR [rax+0x3c],ecx
   56d55:	movzx  ecx,BYTE PTR [r12+0x5]
   56d5b:	shl    rcx,0x3d
   56d5f:	shr    rcx,0x3f
   56d63:	and    rcx,0x1
   56d67:	movzx  edx,BYTE PTR [rax+0x5]
   56d6b:	and    rdx,0xfffffffffffffffb
   56d6f:	shl    rcx,0x2
   56d73:	or     rdx,rcx
   56d76:	mov    BYTE PTR [rax+0x5],dl
   56d79:	mov    rcx,QWORD PTR [r12+0x8]
   56d7e:	mov    QWORD PTR [rax+0x8],rcx
   56d82:	movzx  ecx,BYTE PTR [rax+0x5]
   56d86:	and    rcx,0xfffffffffffffff7
   56d8a:	or     rcx,0x8
   56d8e:	mov    BYTE PTR [rax+0x5],cl
   56d91:	movzx  ecx,BYTE PTR [r12+0x5]
   56d97:	and    rcx,0xfffffffffffffff7
   56d9b:	or     rcx,0x8
   56d9f:	mov    BYTE PTR [r12+0x5],cl
   56da4:	mov    rcx,QWORD PTR [rax+0x8]
   56da8:	mov    edx,DWORD PTR [rax+0x3c]
   56dab:	mov    esi,0x4
   56db0:	mov    r8,QWORD PTR [rax+0x30]
   56db4:	mov    rax,QWORD PTR [rax+0x28]
   56db8:	cmp    BYTE PTR [rcx+0x11],0x0
   56dbc:	je     56ded <sqlite3VdbeExec+0x794d>
   56dbe:	mov    r9,QWORD PTR [rcx+0x8]
   56dc2:	mov    r10,QWORD PTR [rcx]
   56dc5:	mov    QWORD PTR [r9+0x8],r10
   56dc9:	mov    rdi,rcx
   56dcc:	mov    rcx,r8
   56dcf:	mov    r8,rax
   56dd2:	mov    r11,rsi
   56dd5:	mov    rsi,rdx
   56dd8:	mov    rdx,r11
   56ddb:	call   56de0 <sqlite3VdbeExec+0x7940>
   56de0:	mov    r12d,eax
   56de3:	mov    rdi,QWORD PTR [rsp+0x110]
   56deb:	jmp    56e0f <sqlite3VdbeExec+0x796f>
   56ded:	mov    rdi,rcx
   56df0:	mov    rcx,r8
   56df3:	mov    r8,rax
   56df6:	mov    r11,rsi
   56df9:	mov    rsi,rdx
   56dfc:	mov    rdx,r11
   56dff:	call   56e04 <sqlite3VdbeExec+0x7964>
   56e04:	mov    r12d,eax
   56e07:	mov    rdi,QWORD PTR [rsp+0x110]
   56e0f:	mov    DWORD PTR [rsp+0x38c],r12d
   56e17:	mov    rbx,QWORD PTR [rsp+0x160]
   56e1f:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   56e24:	mov    QWORD PTR [rsp+0x160],rbx
   56e2c:	mov    QWORD PTR [rsp+0x130],r12
   56e34:	cmp    DWORD PTR [rbp+0xc],0x0
   56e38:	jg     56e44 <sqlite3VdbeExec+0x79a4>
   56e3a:	mov    r12,QWORD PTR [rsp+0x160]
   56e42:	jmp    56e71 <sqlite3VdbeExec+0x79d1>
   56e44:	movsxd rax,DWORD PTR [rbp+0xc]
   56e48:	imul   rax,rax,0x38
   56e4c:	mov    r12,QWORD PTR [rsp+0x160]
   56e54:	mov    DWORD PTR [r12+rax*1+0x10],0x0
   56e5d:	movsxd rax,DWORD PTR [rbp+0xc]
   56e61:	imul   rax,rax,0x38
   56e65:	lea    rcx,[rip+0x0]        # 56e6c <sqlite3VdbeExec+0x79cc>
   56e6c:	mov    QWORD PTR [r12+rax*1+0x8],rcx
   56e71:	mov    rax,QWORD PTR [rdi+0x78]
   56e75:	movsxd rcx,DWORD PTR [rbp+0x4]
   56e79:	mov    r13,QWORD PTR [rax+rcx*8]
   56e7d:	test   r13,r13
   56e80:	je     57012 <sqlite3VdbeExec+0x7b72>
   56e86:	movzx  eax,BYTE PTR [r13+0x5]
   56e8b:	shl    rax,0x3c
   56e8f:	shr    rax,0x3f
   56e93:	test   eax,eax
   56e95:	jne    57012 <sqlite3VdbeExec+0x7b72>
   56e9b:	mov    eax,DWORD PTR [rbp+0x8]
   56e9e:	movsx  ecx,WORD PTR [r13+0x40]
   56ea3:	cmp    eax,ecx
   56ea5:	jg     57012 <sqlite3VdbeExec+0x7b72>
   56eab:	mov    QWORD PTR [r13+0x10],0x0
   56eb3:	mov    DWORD PTR [r13+0x18],0x0
   56ebb:	mov    r15,QWORD PTR [r13+0x8]
   56ebf:	mov    ebx,DWORD PTR [r13+0x3c]
   56ec3:	mov    DWORD PTR [rsp+0x398],ebx
   56eca:	mov    rbx,QWORD PTR [r15+0x8]
   56ece:	mov    rax,QWORD PTR [r15+0x8]
   56ed2:	mov    rcx,QWORD PTR [r15]
   56ed5:	mov    QWORD PTR [rax+0x8],rcx
   56ed9:	xor    eax,eax
   56edb:	mov    rcx,QWORD PTR [rbx+0x10]
   56edf:	jmp    56f3f <sqlite3VdbeExec+0x7a9f>
   56ee1:	test   rcx,rcx
   56ee4:	jne    56ef7 <sqlite3VdbeExec+0x7a57>
   56ee6:	mov    QWORD PTR [rsp+0x178],rbx
   56eee:	mov    ebx,DWORD PTR [rsp+0x398]
   56ef5:	jmp    56f2c <sqlite3VdbeExec+0x7a8c>
   56ef7:	xor    edx,edx
   56ef9:	mov    QWORD PTR [rsp+0x178],rbx
   56f01:	mov    ebx,DWORD PTR [rsp+0x398]
   56f08:	cmp    edx,ebx
   56f0a:	jne    56f16 <sqlite3VdbeExec+0x7a76>
   56f0c:	mov    rbx,QWORD PTR [rsp+0x178]
   56f14:	jmp    56f44 <sqlite3VdbeExec+0x7aa4>
   56f16:	cmp    ebx,DWORD PTR [rcx+0x50]
   56f19:	jne    56f2c <sqlite3VdbeExec+0x7a8c>
   56f1b:	mov    DWORD PTR [rsp+0x398],ebx
   56f22:	mov    rbx,QWORD PTR [rsp+0x178]
   56f2a:	jmp    56f44 <sqlite3VdbeExec+0x7aa4>
   56f2c:	mov    rcx,QWORD PTR [rcx+0x28]
   56f30:	mov    DWORD PTR [rsp+0x398],ebx
   56f37:	mov    rbx,QWORD PTR [rsp+0x178]
   56f3f:	test   rcx,rcx
   56f42:	jne    56ee1 <sqlite3VdbeExec+0x7a41>
   56f44:	test   rcx,rcx
   56f47:	jne    56f5a <sqlite3VdbeExec+0x7aba>
   56f49:	mov    QWORD PTR [rsp+0x178],rbx
   56f51:	mov    ebx,DWORD PTR [rsp+0x398]
   56f58:	jmp    56f8d <sqlite3VdbeExec+0x7aed>
   56f5a:	mov    QWORD PTR [rsp+0x178],rbx
   56f62:	mov    ebx,DWORD PTR [rsp+0x398]
   56f69:	mov    QWORD PTR [rsp+0x110],rdi
   56f71:	mov    rdi,rcx
   56f74:	mov    rsi,rbx
   56f77:	mov    rdx,rax
   56f7a:	call   56f7f <sqlite3VdbeExec+0x7adf>
   56f7f:	xor    ecx,ecx
   56f81:	mov    rdi,QWORD PTR [rsp+0x110]
   56f89:	cmp    ecx,eax
   56f8b:	jne    57002 <sqlite3VdbeExec+0x7b62>
   56f8d:	cmp    BYTE PTR [r15+0x13],0x0
   56f92:	je     56fc4 <sqlite3VdbeExec+0x7b24>
   56f94:	mov    BYTE PTR [r15+0x13],0x0
   56f99:	mov    rax,QWORD PTR [r15+0x8]
   56f9d:	mov    rax,QWORD PTR [rax+0x10]
   56fa1:	jmp    56fbf <sqlite3VdbeExec+0x7b1f>
   56fa3:	movzx  ecx,BYTE PTR [rax+0x1]
   56fa7:	and    ecx,0x10
   56faa:	test   ecx,ecx
   56fac:	je     56fbb <sqlite3VdbeExec+0x7b1b>
   56fae:	mov    BYTE PTR [r15+0x13],0x1
   56fb3:	cmp    ebx,DWORD PTR [rax+0x50]
   56fb6:	jne    56fbb <sqlite3VdbeExec+0x7b1b>
   56fb8:	mov    BYTE PTR [rax],0x1
   56fbb:	mov    rax,QWORD PTR [rax+0x28]
   56fbf:	test   rax,rax
   56fc2:	jne    56fa3 <sqlite3VdbeExec+0x7b03>
   56fc4:	xor    eax,eax
   56fc6:	mov    QWORD PTR [rsp+0x188],r13
   56fce:	xor    r15d,r15d
   56fd1:	mov    r13,QWORD PTR [rsp+0x178]
   56fd9:	mov    QWORD PTR [rsp+0x110],rdi
   56fe1:	mov    rdi,r13
   56fe4:	mov    rsi,rbx
   56fe7:	mov    rdx,rax
   56fea:	mov    rcx,r15
   56fed:	call   56ff2 <sqlite3VdbeExec+0x7b52>
   56ff2:	mov    rdi,QWORD PTR [rsp+0x110]
   56ffa:	mov    r13,QWORD PTR [rsp+0x188]
   57002:	mov    ebx,eax
   57004:	mov    r11,r13
   57007:	mov    r13,rbx
   5700a:	mov    rbx,r11
   5700d:	jmp    572b9 <sqlite3VdbeExec+0x7e19>
   57012:	mov    eax,DWORD PTR [rbp+0x4]
   57015:	mov    ecx,DWORD PTR [rbp+0x8]
   57018:	xor    edx,edx
   5701a:	mov    QWORD PTR [rsp+0x110],rdi
   57022:	mov    rsi,rax
   57025:	mov    r11,rdx
   57028:	mov    rdx,rcx
   5702b:	mov    rcx,r11
   5702e:	call   57033 <sqlite3VdbeExec+0x7b93>
   57033:	mov    rbx,rax
   57036:	mov    rdi,QWORD PTR [rsp+0x110]
   5703e:	test   rbx,rbx
   57041:	jne    5705b <sqlite3VdbeExec+0x7bbb>
   57043:	mov    r13,QWORD PTR [rsp+0x150]
   5704b:	mov    rbx,rbp
   5704e:	mov    rbp,QWORD PTR [rsp+0x158]
   57056:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5705b:	movzx  eax,BYTE PTR [rbx+0x5]
   5705f:	and    rax,0xfffffffffffffffe
   57063:	or     rax,0x1
   57067:	mov    BYTE PTR [rbx+0x5],al
   5706a:	mov    rax,QWORD PTR [r14]
   5706d:	xor    ecx,ecx
   5706f:	lea    rdx,[rbx+0x8]
   57073:	movzx  esi,WORD PTR [rbp+0x2]
   57077:	or     esi,0x5
   5707a:	mov    r8d,DWORD PTR [rip+0x0]        # 57081 <sqlite3VdbeExec+0x7be1>
   57081:	mov    rdi,rax
   57084:	mov    r9,r8
   57087:	mov    r8,rsi
   5708a:	mov    rsi,rcx
   5708d:	mov    rcx,rdx
   57090:	mov    rdx,r14
   57093:	call   57098 <sqlite3VdbeExec+0x7bf8>
   57098:	mov    r13d,eax
   5709b:	mov    rdi,QWORD PTR [rsp+0x110]
   570a3:	test   r13d,r13d
   570a6:	jne    572b9 <sqlite3VdbeExec+0x7e19>
   570ac:	mov    rax,QWORD PTR [rbx+0x8]
   570b0:	mov    ecx,0x1
   570b5:	xor    edx,edx
   570b7:	cmp    BYTE PTR [rax+0x11],0x0
   570bb:	jne    570cd <sqlite3VdbeExec+0x7c2d>
   570bd:	cmp    BYTE PTR [rax+0x10],0x0
   570c1:	je     570cd <sqlite3VdbeExec+0x7c2d>
   570c3:	cmp    BYTE PTR [rax+0x10],0x1
   570c7:	jne    5717a <sqlite3VdbeExec+0x7cda>
   570cd:	mov    QWORD PTR [rsp+0x110],rdi
   570d5:	mov    rdi,rax
   570d8:	mov    rsi,rcx
   570db:	call   570e0 <sqlite3VdbeExec+0x7c40>
   570e0:	mov    r13d,eax
   570e3:	mov    rdi,QWORD PTR [rsp+0x110]
   570eb:	test   r13d,r13d
   570ee:	jne    57266 <sqlite3VdbeExec+0x7dc6>
   570f4:	mov    r13,QWORD PTR [rbp+0x10]
   570f8:	mov    QWORD PTR [rbx+0x30],r13
   570fc:	test   r13,r13
   570ff:	je     571ec <sqlite3VdbeExec+0x7d4c>
   57105:	mov    rax,QWORD PTR [rbx+0x8]
   57109:	lea    rcx,[rbx+0x3c]
   5710d:	movzx  edx,WORD PTR [rbp+0x2]
   57111:	or     edx,0x2
   57114:	mov    QWORD PTR [rsp+0x110],rdi
   5711c:	mov    rdi,rax
   5711f:	mov    rsi,rcx
   57122:	call   57127 <sqlite3VdbeExec+0x7c87>
   57127:	mov    r15d,eax
   5712a:	mov    rdi,QWORD PTR [rsp+0x110]
   57132:	test   r15d,r15d
   57135:	jne    571e3 <sqlite3VdbeExec+0x7d43>
   5713b:	mov    rax,QWORD PTR [rbx+0x8]
   5713f:	mov    ecx,DWORD PTR [rbx+0x3c]
   57142:	mov    edx,0x4
   57147:	mov    rsi,QWORD PTR [rbx+0x28]
   5714b:	cmp    BYTE PTR [rax+0x11],0x0
   5714f:	je     571c4 <sqlite3VdbeExec+0x7d24>
   57151:	mov    r8,QWORD PTR [rax+0x8]
   57155:	mov    r9,QWORD PTR [rax]
   57158:	mov    QWORD PTR [r8+0x8],r9
   5715c:	mov    rdi,rax
   5715f:	mov    r8,rsi
   57162:	mov    rsi,rcx
   57165:	mov    rcx,r13
   57168:	call   5716d <sqlite3VdbeExec+0x7ccd>
   5716d:	mov    r13d,eax
   57170:	mov    rdi,QWORD PTR [rsp+0x110]
   57178:	jmp    571e0 <sqlite3VdbeExec+0x7d40>
   5717a:	mov    rcx,QWORD PTR [rax+0x8]
   5717e:	mov    rcx,QWORD PTR [rcx]
   57181:	mov    rax,QWORD PTR [rax]
   57184:	mov    eax,DWORD PTR [rax+0x2e8]
   5718a:	cmp    eax,DWORD PTR [rcx+0x80]
   57190:	jle    570f4 <sqlite3VdbeExec+0x7c54>
   57196:	cmp    BYTE PTR [rcx+0xa],0x0
   5719a:	je     570f4 <sqlite3VdbeExec+0x7c54>
   571a0:	mov    rdi,rcx
   571a3:	mov    rsi,rax
   571a6:	call   571ab <sqlite3VdbeExec+0x7d0b>
   571ab:	mov    r13d,eax
   571ae:	mov    rdi,QWORD PTR [rsp+0x110]
   571b6:	test   r13d,r13d
   571b9:	je     570f4 <sqlite3VdbeExec+0x7c54>
   571bf:	jmp    57266 <sqlite3VdbeExec+0x7dc6>
   571c4:	mov    rdi,rax
   571c7:	mov    r8,rsi
   571ca:	mov    rsi,rcx
   571cd:	mov    rcx,r13
   571d0:	call   571d5 <sqlite3VdbeExec+0x7d35>
   571d5:	mov    r13d,eax
   571d8:	mov    rdi,QWORD PTR [rsp+0x110]
   571e0:	mov    r15,r13
   571e3:	mov    BYTE PTR [rbx+0x4],0x0
   571e7:	mov    r13,r15
   571ea:	jmp    57266 <sqlite3VdbeExec+0x7dc6>
   571ec:	mov    DWORD PTR [rbx+0x3c],0x1
   571f3:	mov    rax,QWORD PTR [rbx+0x8]
   571f7:	mov    ecx,0x1
   571fc:	mov    edx,0x4
   57201:	xor    esi,esi
   57203:	mov    r8,QWORD PTR [rbx+0x28]
   57207:	cmp    BYTE PTR [rax+0x11],0x0
   5720b:	je     5723e <sqlite3VdbeExec+0x7d9e>
   5720d:	mov    r9,QWORD PTR [rax+0x8]
   57211:	mov    r10,QWORD PTR [rax]
   57214:	mov    QWORD PTR [r9+0x8],r10
   57218:	mov    QWORD PTR [rsp+0x110],rdi
   57220:	mov    rdi,rax
   57223:	mov    r11,rsi
   57226:	mov    rsi,rcx
   57229:	mov    rcx,r11
   5722c:	call   57231 <sqlite3VdbeExec+0x7d91>
   57231:	mov    r13d,eax
   57234:	mov    rdi,QWORD PTR [rsp+0x110]
   5723c:	jmp    57262 <sqlite3VdbeExec+0x7dc2>
   5723e:	mov    QWORD PTR [rsp+0x110],rdi
   57246:	mov    rdi,rax
   57249:	mov    r11,rsi
   5724c:	mov    rsi,rcx
   5724f:	mov    rcx,r11
   57252:	call   57257 <sqlite3VdbeExec+0x7db7>
   57257:	mov    r13d,eax
   5725a:	mov    rdi,QWORD PTR [rsp+0x110]
   57262:	mov    BYTE PTR [rbx+0x4],0x1
   57266:	xor    eax,eax
   57268:	cmp    WORD PTR [rbp+0x2],0x8
   5726d:	setne  al
   57270:	and    rax,0x1
   57274:	movzx  ecx,BYTE PTR [rbx+0x5]
   57278:	and    rcx,0xfffffffffffffffb
   5727c:	shl    rax,0x2
   57280:	or     rcx,rax
   57283:	mov    BYTE PTR [rbx+0x5],cl
   57286:	test   r13d,r13d
   57289:	je     572b9 <sqlite3VdbeExec+0x7e19>
   5728b:	mov    rax,QWORD PTR [rbx+0x8]
   5728f:	mov    QWORD PTR [rsp+0x110],rdi
   57297:	mov    rdi,rax
   5729a:	call   5729f <sqlite3VdbeExec+0x7dff>
   5729f:	mov    rdi,QWORD PTR [rsp+0x110]
   572a7:	mov    rax,QWORD PTR [rdi+0x78]
   572ab:	movsxd rcx,DWORD PTR [rbp+0x4]
   572af:	mov    QWORD PTR [rax+rcx*8],0x0
   572b7:	jmp    572b9 <sqlite3VdbeExec+0x7e19>
   572b9:	test   r13d,r13d
   572bc:	je     572de <sqlite3VdbeExec+0x7e3e>
   572be:	mov    QWORD PTR [rsp+0x148],rbp
   572c6:	mov    rbp,r13
   572c9:	mov    r13,QWORD PTR [rsp+0x130]
   572d1:	mov    rbx,QWORD PTR [rsp+0x158]
   572d9:	jmp    4f712 <sqlite3VdbeExec+0x272>
   572de:	mov    BYTE PTR [rbx+0x2],0x1
   572e2:	mov    DWORD PTR [rsp+0x38c],r13d
   572ea:	mov    rbx,r12
   572ed:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   572f2:	mov    QWORD PTR [rsp+0x130],r12
   572fa:	mov    r12,rbx
   572fd:	mov    eax,DWORD PTR [rbp+0x4]
   57300:	mov    ecx,DWORD PTR [rbp+0x8]
   57303:	mov    edx,0x1
   57308:	mov    QWORD PTR [rsp+0x110],rdi
   57310:	mov    rsi,rax
   57313:	mov    r11,rdx
   57316:	mov    rdx,rcx
   57319:	mov    rcx,r11
   5731c:	call   57321 <sqlite3VdbeExec+0x7e81>
   57321:	mov    rbx,rax
   57324:	mov    rdi,QWORD PTR [rsp+0x110]
   5732c:	test   rbx,rbx
   5732f:	jne    57349 <sqlite3VdbeExec+0x7ea9>
   57331:	mov    r13,QWORD PTR [rsp+0x150]
   57339:	mov    rbx,rbp
   5733c:	mov    rbp,QWORD PTR [rsp+0x158]
   57344:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   57349:	mov    rax,QWORD PTR [rbp+0x10]
   5734d:	mov    QWORD PTR [rbx+0x30],rax
   57351:	mov    r13d,DWORD PTR [rbp+0xc]
   57355:	mov    rax,QWORD PTR [rbx+0x30]
   57359:	movzx  eax,WORD PTR [rax+0x8]
   5735d:	shl    rax,0x3
   57361:	add    rax,0x20
   57365:	mov    r15d,eax
   57368:	mov    rax,r15
   5736b:	mov    DWORD PTR [rsp+0x398],r13d
   57373:	lea    r13,[rax+0xc8]
   5737a:	test   r14,r14
   5737d:	je     5739f <sqlite3VdbeExec+0x7eff>
   5737f:	mov    DWORD PTR [rsp+0x3a0],r15d
   57387:	mov    rdi,r14
   5738a:	mov    rsi,r13
   5738d:	call   57392 <sqlite3VdbeExec+0x7ef2>
   57392:	mov    r15,rax
   57395:	mov    rdi,QWORD PTR [rsp+0x110]
   5739d:	jmp    573ba <sqlite3VdbeExec+0x7f1a>
   5739f:	mov    DWORD PTR [rsp+0x3a0],r15d
   573a7:	mov    rdi,r13
   573aa:	call   573af <sqlite3VdbeExec+0x7f0f>
   573af:	mov    r15,rax
   573b2:	mov    rdi,QWORD PTR [rsp+0x110]
   573ba:	test   r15,r15
   573bd:	je     573df <sqlite3VdbeExec+0x7f3f>
   573bf:	xor    eax,eax
   573c1:	mov    QWORD PTR [rsp+0x110],rdi
   573c9:	mov    rdi,r15
   573cc:	mov    rsi,rax
   573cf:	mov    rdx,r13
   573d2:	call   573d7 <sqlite3VdbeExec+0x7f37>
   573d7:	mov    rdi,QWORD PTR [rsp+0x110]
   573df:	mov    QWORD PTR [rbx+0x28],r15
   573e3:	test   r15,r15
   573e6:	jne    573f2 <sqlite3VdbeExec+0x7f52>
   573e8:	mov    ebx,0x7
   573ed:	jmp    575f0 <sqlite3VdbeExec+0x8150>
   573f2:	mov    r13d,DWORD PTR [rsp+0x398]
   573fa:	mov    rax,QWORD PTR [r14+0x20]
   573fe:	mov    QWORD PTR [rsp+0x160],r12
   57406:	mov    r12,QWORD PTR [rax+0x8]
   5740a:	mov    QWORD PTR [rsp+0x148],rbp
   57412:	lea    rbp,[r15+0xc8]
   57419:	mov    QWORD PTR [r15+0x28],rbp
   5741d:	mov    rax,QWORD PTR [rbx+0x30]
   57421:	mov    ebx,DWORD PTR [rsp+0x3a0]
   57428:	mov    rcx,rbx
   5742b:	mov    QWORD PTR [rsp+0x110],rdi
   57433:	mov    rdi,rbp
   57436:	mov    rsi,rax
   57439:	mov    rdx,rcx
   5743c:	call   57441 <sqlite3VdbeExec+0x7fa1>
   57441:	mov    QWORD PTR [r15+0xd8],0x0
   5744c:	mov    rdi,QWORD PTR [rsp+0x110]
   57454:	test   r13d,r13d
   57457:	je     5745e <sqlite3VdbeExec+0x7fbe>
   57459:	mov    WORD PTR [rbp+0x6],r13w
   5745e:	mov    rax,QWORD PTR [r12+0x8]
   57463:	mov    rcx,QWORD PTR [r12]
   57467:	mov    QWORD PTR [rax+0x8],rcx
   5746b:	mov    rax,QWORD PTR [r12+0x8]
   57470:	movsxd rax,DWORD PTR [rax+0x34]
   57474:	mov    DWORD PTR [r15+0xc],eax
   57478:	mov    BYTE PTR [r15+0x5b],0x1
   5747d:	mov    BYTE PTR [r15+0x5a],0xff
   57482:	xor    ecx,ecx
   57484:	cmp    BYTE PTR [r15+0x5b],0x1
   57489:	seta   cl
   5748c:	mov    BYTE PTR [r15+0x59],cl
   57490:	mov    QWORD PTR [r15+0x20],r14
   57494:	xor    ecx,ecx
   57496:	jmp    574ab <sqlite3VdbeExec+0x800b>
   57498:	lea    rdx,[r15+0x60]
   5749c:	mov    rsi,rcx
   5749f:	imul   rsi,rsi,0x68
   574a3:	mov    QWORD PTR [rdx+rsi*1+0x10],r15
   574a8:	add    ecx,0x1
   574ab:	movzx  edx,BYTE PTR [r15+0x5b]
   574b0:	cmp    ecx,edx
   574b2:	jl     57498 <sqlite3VdbeExec+0x7ff8>
   574b4:	cmp    BYTE PTR [r14+0x66],0x2
   574b9:	jne    574cb <sqlite3VdbeExec+0x802b>
   574bb:	xor    r11d,r11d
   574be:	mov    DWORD PTR [rsp+0x398],r11d
   574c6:	jmp    57563 <sqlite3VdbeExec+0x80c3>
   574cb:	mov    ecx,eax
   574cd:	imul   ecx,DWORD PTR [rip+0x0]        # 574d4 <sqlite3VdbeExec+0x8034>
   574d4:	mov    DWORD PTR [r15],ecx
   574d7:	mov    rcx,QWORD PTR [r14+0x20]
   574db:	mov    rcx,QWORD PTR [rcx+0x18]
   574df:	movsxd rcx,DWORD PTR [rcx+0x74]
   574e3:	test   rcx,rcx
   574e6:	jge    574f1 <sqlite3VdbeExec+0x8051>
   574e8:	imul   rcx,rcx,0xfffffffffffffc00
   574ef:	jmp    574f8 <sqlite3VdbeExec+0x8058>
   574f1:	mov    rdx,rax
   574f4:	imul   rcx,rdx
   574f8:	mov    edx,0x20000000
   574fd:	cmp    rcx,0x20000000
   57504:	cmovl  rdx,rcx
   57508:	mov    ecx,DWORD PTR [r15]
   5750b:	cmp    ecx,edx
   5750d:	cmovg  edx,ecx
   57510:	mov    DWORD PTR [r15+0x4],edx
   57514:	cmp    BYTE PTR [rip+0x0],0x0        # 5751b <sqlite3VdbeExec+0x807b>
   5751b:	je     5752a <sqlite3VdbeExec+0x808a>
   5751d:	xor    r11d,r11d
   57520:	mov    DWORD PTR [rsp+0x398],r11d
   57528:	jmp    57563 <sqlite3VdbeExec+0x80c3>
   5752a:	mov    DWORD PTR [r15+0x54],eax
   5752e:	mov    QWORD PTR [rsp+0x110],rdi
   57536:	mov    rdi,rax
   57539:	call   5753e <sqlite3VdbeExec+0x809e>
   5753e:	mov    QWORD PTR [r15+0x40],rax
   57542:	mov    eax,0x7
   57547:	xor    r12d,r12d
   5754a:	cmp    QWORD PTR [r15+0x40],0x0
   5754f:	cmove  r12d,eax
   57553:	mov    rdi,QWORD PTR [rsp+0x110]
   5755b:	mov    DWORD PTR [rsp+0x398],r12d
   57563:	cmp    WORD PTR [rbp+0x8],0xd
   57568:	jb     57583 <sqlite3VdbeExec+0x80e3>
   5756a:	mov    rbp,QWORD PTR [rsp+0x148]
   57572:	mov    r12,QWORD PTR [rsp+0x160]
   5757a:	mov    ebx,DWORD PTR [rsp+0x398]
   57581:	jmp    575f0 <sqlite3VdbeExec+0x8150>
   57583:	cmp    QWORD PTR [rbp+0x20],0x0
   57588:	je     575ad <sqlite3VdbeExec+0x810d>
   5758a:	mov    rax,QWORD PTR [rbp+0x20]
   5758e:	cmp    rax,QWORD PTR [r14+0x10]
   57592:	je     575ad <sqlite3VdbeExec+0x810d>
   57594:	mov    rbp,QWORD PTR [rsp+0x148]
   5759c:	mov    r12,QWORD PTR [rsp+0x160]
   575a4:	mov    ebx,DWORD PTR [rsp+0x398]
   575ab:	jmp    575f0 <sqlite3VdbeExec+0x8150>
   575ad:	mov    rax,QWORD PTR [rbp+0x18]
   575b1:	movzx  eax,BYTE PTR [rax]
   575b4:	and    eax,0x2
   575b7:	test   eax,eax
   575b9:	je     575d4 <sqlite3VdbeExec+0x8134>
   575bb:	mov    rbp,QWORD PTR [rsp+0x148]
   575c3:	mov    r12,QWORD PTR [rsp+0x160]
   575cb:	mov    ebx,DWORD PTR [rsp+0x398]
   575d2:	jmp    575f0 <sqlite3VdbeExec+0x8150>
   575d4:	mov    BYTE PTR [r15+0x5c],0x3
   575d9:	mov    rbp,QWORD PTR [rsp+0x148]
   575e1:	mov    r12,QWORD PTR [rsp+0x160]
   575e9:	mov    ebx,DWORD PTR [rsp+0x398]
   575f0:	test   ebx,ebx
   575f2:	je     57614 <sqlite3VdbeExec+0x8174>
   575f4:	mov    QWORD PTR [rsp+0x148],rbp
   575fc:	mov    rbp,rbx
   575ff:	mov    r13,QWORD PTR [rsp+0x130]
   57607:	mov    rbx,QWORD PTR [rsp+0x158]
   5760f:	jmp    4f712 <sqlite3VdbeExec+0x272>
   57614:	mov    DWORD PTR [rsp+0x38c],ebx
   5761b:	mov    rbx,r12
   5761e:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   57623:	mov    r15d,DWORD PTR [rsp+0x37c]
   5762b:	mov    r13,QWORD PTR [rsp+0x150]
   57633:	mov    QWORD PTR [rsp+0x130],r12
   5763b:	mov    r12d,DWORD PTR [rsp+0x394]
   57643:	mov    rax,QWORD PTR [rdi+0x78]
   57647:	movsxd rcx,DWORD PTR [rbp+0x4]
   5764b:	mov    rax,QWORD PTR [rax+rcx*8]
   5764f:	mov    rcx,QWORD PTR [rax+0x10]
   57653:	lea    rdx,[rcx+0x1]
   57657:	mov    QWORD PTR [rax+0x10],rdx
   5765b:	test   rcx,rcx
   5765e:	jne    57678 <sqlite3VdbeExec+0x81d8>
   57660:	mov    QWORD PTR [rsp+0x150],r13
   57668:	mov    DWORD PTR [rsp+0x394],r12d
   57670:	mov    r12,r14
   57673:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   57678:	mov    DWORD PTR [rsp+0x37c],r15d
   57680:	mov    QWORD PTR [rsp+0x150],r13
   57688:	mov    DWORD PTR [rsp+0x394],r12d
   57690:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   57695:	mov    r15d,DWORD PTR [rsp+0x37c]
   5769d:	mov    r13,QWORD PTR [rsp+0x150]
   576a5:	mov    QWORD PTR [rsp+0x130],r12
   576ad:	mov    r12d,DWORD PTR [rsp+0x394]
   576b5:	mov    eax,DWORD PTR [rbp+0x4]
   576b8:	mov    ecx,DWORD PTR [rbp+0xc]
   576bb:	mov    edx,0x3
   576c0:	mov    QWORD PTR [rsp+0x110],rdi
   576c8:	mov    rsi,rax
   576cb:	mov    r11,rdx
   576ce:	mov    rdx,rcx
   576d1:	mov    rcx,r11
   576d4:	call   576d9 <sqlite3VdbeExec+0x8239>
   576d9:	mov    rdi,QWORD PTR [rsp+0x110]
   576e1:	test   rax,rax
   576e4:	jne    576f6 <sqlite3VdbeExec+0x8256>
   576e6:	mov    rbx,rbp
   576e9:	mov    rbp,QWORD PTR [rsp+0x158]
   576f1:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   576f6:	mov    BYTE PTR [rax+0x2],0x1
   576fa:	mov    ecx,DWORD PTR [rbp+0x8]
   576fd:	mov    DWORD PTR [rax+0x1c],ecx
   57700:	mov    BYTE PTR [rax+0x4],0x1
   57704:	lea    rcx,[rip+0x0]        # 5770b <sqlite3VdbeExec+0x826b>
   5770b:	mov    QWORD PTR [rax+0x28],rcx
   5770f:	mov    DWORD PTR [rsp+0x37c],r15d
   57717:	mov    QWORD PTR [rsp+0x150],r13
   5771f:	mov    DWORD PTR [rsp+0x394],r12d
   57727:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5772c:	mov    r15d,DWORD PTR [rsp+0x37c]
   57734:	mov    r13,QWORD PTR [rsp+0x150]
   5773c:	mov    QWORD PTR [rsp+0x130],r12
   57744:	mov    r12d,DWORD PTR [rsp+0x394]
   5774c:	mov    rax,QWORD PTR [rdi+0x78]
   57750:	movsxd rcx,DWORD PTR [rbp+0x4]
   57754:	mov    rax,QWORD PTR [rax+rcx*8]
   57758:	test   rax,rax
   5775b:	je     57775 <sqlite3VdbeExec+0x82d5>
   5775d:	mov    QWORD PTR [rsp+0x110],rdi
   57765:	mov    rsi,rax
   57768:	call   5776d <sqlite3VdbeExec+0x82cd>
   5776d:	mov    rdi,QWORD PTR [rsp+0x110]
   57775:	mov    rax,QWORD PTR [rdi+0x78]
   57779:	movsxd rcx,DWORD PTR [rbp+0x4]
   5777d:	mov    QWORD PTR [rax+rcx*8],0x0
   57785:	mov    DWORD PTR [rsp+0x37c],r15d
   5778d:	mov    QWORD PTR [rsp+0x150],r13
   57795:	mov    DWORD PTR [rsp+0x394],r12d
   5779d:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   577a2:	mov    r15d,DWORD PTR [rsp+0x37c]
   577aa:	mov    r13,QWORD PTR [rsp+0x150]
   577b2:	mov    QWORD PTR [rsp+0x130],r12
   577ba:	mov    r12d,DWORD PTR [rsp+0x394]
   577c2:	mov    rax,QWORD PTR [rdi+0x78]
   577c6:	movsxd rcx,DWORD PTR [rbp+0x4]
   577ca:	mov    DWORD PTR [rsp+0x394],r12d
   577d2:	mov    r12,QWORD PTR [rax+rcx*8]
   577d6:	movzx  eax,BYTE PTR [rbp+0x0]
   577da:	mov    QWORD PTR [rsp+0x150],r13
   577e2:	mov    r13d,eax
   577e5:	mov    BYTE PTR [r12+0x2],0x0
   577eb:	mov    BYTE PTR [r12+0x3],0x0
   577f1:	mov    DWORD PTR [r12+0x18],0x0
   577fa:	cmp    BYTE PTR [r12+0x4],0x0
   57800:	je     57c1c <sqlite3VdbeExec+0x877c>
   57806:	movsxd rax,DWORD PTR [rbp+0xc]
   5780a:	imul   rax,rax,0x38
   5780e:	mov    DWORD PTR [rsp+0x3a0],r13d
   57816:	lea    r13,[rbx+rax*1]
   5781a:	mov    QWORD PTR [rsp+0x188],r12
   57822:	movzx  r12d,WORD PTR [rbx+rax*1+0x14]
   57828:	mov    eax,r12d
   5782b:	and    eax,0x2e
   5782e:	cmp    eax,0x2
   57831:	jne    57850 <sqlite3VdbeExec+0x83b0>
   57833:	xor    eax,eax
   57835:	mov    QWORD PTR [rsp+0x110],rdi
   5783d:	mov    rdi,r13
   57840:	mov    rsi,rax
   57843:	call   57848 <sqlite3VdbeExec+0x83a8>
   57848:	mov    rdi,QWORD PTR [rsp+0x110]
   57850:	movzx  eax,WORD PTR [r13+0x14]
   57855:	mov    ecx,eax
   57857:	and    ecx,0x24
   5785a:	test   ecx,ecx
   5785c:	je     5786f <sqlite3VdbeExec+0x83cf>
   5785e:	mov    DWORD PTR [rsp+0x39c],r12d
   57866:	mov    r12,QWORD PTR [r13+0x0]
   5786a:	jmp    578fd <sqlite3VdbeExec+0x845d>
   5786f:	mov    DWORD PTR [rsp+0x39c],r12d
   57877:	mov    ecx,eax
   57879:	and    ecx,0x8
   5787c:	test   ecx,ecx
   5787e:	je     578cf <sqlite3VdbeExec+0x842f>
   57880:	movsd  xmm1,QWORD PTR [r13+0x0]
   57886:	movabs r11,0xc3dfffffffffffff
   57890:	movq   xmm0,r11
   57895:	ucomisd xmm0,xmm1
   57899:	jbe    578a7 <sqlite3VdbeExec+0x8407>
   5789b:	movabs r12,0x8000000000000000
   578a5:	jmp    578cd <sqlite3VdbeExec+0x842d>
   578a7:	movabs r11,0x43dfffffffffffff
   578b1:	movq   xmm0,r11
   578b6:	ucomisd xmm1,xmm0
   578ba:	jbe    578c8 <sqlite3VdbeExec+0x8428>
   578bc:	movabs r12,0x7fffffffffffffff
   578c6:	jmp    578cd <sqlite3VdbeExec+0x842d>
   578c8:	cvttsd2si r12,xmm1
   578cd:	jmp    578fd <sqlite3VdbeExec+0x845d>
   578cf:	and    eax,0x12
   578d2:	test   eax,eax
   578d4:	je     578fa <sqlite3VdbeExec+0x845a>
   578d6:	cmp    QWORD PTR [r13+0x8],0x0
   578db:	je     578fa <sqlite3VdbeExec+0x845a>
   578dd:	mov    QWORD PTR [rsp+0x110],rdi
   578e5:	mov    rdi,r13
   578e8:	call   578ed <sqlite3VdbeExec+0x844d>
   578ed:	mov    r12,rax
   578f0:	mov    rdi,QWORD PTR [rsp+0x110]
   578f8:	jmp    578fd <sqlite3VdbeExec+0x845d>
   578fa:	xor    r12d,r12d
   578fd:	movzx  eax,WORD PTR [r13+0x14]
   57902:	mov    DWORD PTR [rsp+0x37c],r15d
   5790a:	mov    r15d,DWORD PTR [rsp+0x39c]
   57912:	mov    WORD PTR [r13+0x14],r15w
   57917:	mov    ecx,eax
   57919:	and    ecx,0x24
   5791c:	test   ecx,ecx
   5791e:	je     5792d <sqlite3VdbeExec+0x848d>
   57920:	mov    r13d,DWORD PTR [rsp+0x3a0]
   57928:	jmp    57b09 <sqlite3VdbeExec+0x8669>
   5792d:	mov    ecx,eax
   5792f:	and    ecx,0x8
   57932:	test   ecx,ecx
   57934:	jne    579f4 <sqlite3VdbeExec+0x8554>
   5793a:	and    eax,0x1
   5793d:	test   eax,eax
   5793f:	jne    5794f <sqlite3VdbeExec+0x84af>
   57941:	mov    r13d,DWORD PTR [rsp+0x3a0]
   57949:	cmp    r13d,0x17
   5794d:	jl     5795f <sqlite3VdbeExec+0x84bf>
   5794f:	mov    r12,r14
   57952:	mov    r15d,DWORD PTR [rsp+0x37c]
   5795a:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   5795f:	mov    r12,QWORD PTR [rsp+0x188]
   57967:	mov    rax,QWORD PTR [r12+0x28]
   5796c:	lea    r12,[rsp+0x398]
   57974:	mov    rcx,r12
   57977:	xor    edx,edx
   57979:	movzx  esi,BYTE PTR [rax]
   5797c:	cmp    edx,esi
   5797e:	jne    57996 <sqlite3VdbeExec+0x84f6>
   57980:	movzx  edx,BYTE PTR [rax+0x1]
   57984:	and    edx,0x8
   57987:	test   edx,edx
   57989:	je     57996 <sqlite3VdbeExec+0x84f6>
   5798b:	mov    DWORD PTR [rcx],0x0
   57991:	xor    r13d,r13d
   57994:	jmp    579b4 <sqlite3VdbeExec+0x8514>
   57996:	mov    QWORD PTR [rsp+0x110],rdi
   5799e:	mov    rdi,rax
   579a1:	mov    rsi,rcx
   579a4:	call   579a9 <sqlite3VdbeExec+0x8509>
   579a9:	mov    r13d,eax
   579ac:	mov    rdi,QWORD PTR [rsp+0x110]
   579b4:	test   r13d,r13d
   579b7:	je     579d9 <sqlite3VdbeExec+0x8539>
   579b9:	mov    QWORD PTR [rsp+0x148],rbp
   579c1:	mov    rbp,r13
   579c4:	mov    r13,QWORD PTR [rsp+0x130]
   579cc:	mov    rbx,QWORD PTR [rsp+0x158]
   579d4:	jmp    4f712 <sqlite3VdbeExec+0x272>
   579d9:	mov    r15d,DWORD PTR [rsp+0x37c]
   579e1:	mov    r12,r13
   579e4:	xor    r11d,r11d
   579e7:	mov    DWORD PTR [rsp+0x39c],r11d
   579ef:	jmp    57ec3 <sqlite3VdbeExec+0x8a23>
   579f4:	mov    r15,r13
   579f7:	mov    r13d,DWORD PTR [rsp+0x3a0]
   579ff:	movsd  xmm1,QWORD PTR [r15]
   57a04:	movsd  QWORD PTR [rsp+0x178],xmm1
   57a0d:	mov    rax,QWORD PTR [rsp+0x178]
   57a15:	mov    QWORD PTR [rsp+0x168],rax
   57a1d:	mov    rax,QWORD PTR [rsp+0x168]
   57a25:	movabs rcx,0x7ff0000000000000
   57a2f:	and    rcx,rax
   57a32:	movabs rdx,0x7ff0000000000000
   57a3c:	movabs rsi,0xfffffffffffff
   57a46:	and    rax,rsi
   57a49:	test   rax,rax
   57a4c:	mov    eax,0x0
   57a51:	setne  al
   57a54:	xor    esi,esi
   57a56:	cmp    rcx,rdx
   57a59:	cmove  esi,eax
   57a5c:	test   esi,esi
   57a5e:	je     57a67 <sqlite3VdbeExec+0x85c7>
   57a60:	mov    eax,0x1
   57a65:	jmp    57ae2 <sqlite3VdbeExec+0x8642>
   57a67:	movabs r11,0xc3e0000000000000
   57a71:	movq   xmm0,r11
   57a76:	ucomisd xmm0,xmm1
   57a7a:	jbe    57a83 <sqlite3VdbeExec+0x85e3>
   57a7c:	mov    eax,0x1
   57a81:	jmp    57ae2 <sqlite3VdbeExec+0x8642>
   57a83:	movabs r11,0x43e0000000000000
   57a8d:	movq   xmm0,r11
   57a92:	ucomisd xmm1,xmm0
   57a96:	jb     57a9f <sqlite3VdbeExec+0x85ff>
   57a98:	mov    eax,0xffffffff
   57a9d:	jmp    57ae2 <sqlite3VdbeExec+0x8642>
   57a9f:	cvttsd2si rax,xmm1
   57aa4:	cmp    r12,rax
   57aa7:	jge    57ab0 <sqlite3VdbeExec+0x8610>
   57aa9:	mov    eax,0xffffffff
   57aae:	jmp    57ae2 <sqlite3VdbeExec+0x8642>
   57ab0:	cmp    r12,rax
   57ab3:	jle    57abc <sqlite3VdbeExec+0x861c>
   57ab5:	mov    eax,0x1
   57aba:	jmp    57ae2 <sqlite3VdbeExec+0x8642>
   57abc:	xorps  xmm0,xmm0
   57abf:	cvtsi2sd xmm0,r12
   57ac4:	ucomisd xmm1,xmm0
   57ac8:	jbe    57ad1 <sqlite3VdbeExec+0x8631>
   57aca:	mov    eax,0xffffffff
   57acf:	jmp    57ae2 <sqlite3VdbeExec+0x8642>
   57ad1:	xorps  xmm0,xmm0
   57ad4:	cvtsi2sd xmm0,r12
   57ad9:	xor    eax,eax
   57adb:	ucomisd xmm0,xmm1
   57adf:	seta   al
   57ae2:	test   eax,eax
   57ae4:	jle    57af6 <sqlite3VdbeExec+0x8656>
   57ae6:	mov    eax,r13d
   57ae9:	and    eax,0x1
   57aec:	test   eax,eax
   57aee:	jne    57af4 <sqlite3VdbeExec+0x8654>
   57af0:	sub    r13d,0x1
   57af4:	jmp    57b09 <sqlite3VdbeExec+0x8669>
   57af6:	test   eax,eax
   57af8:	jge    57b09 <sqlite3VdbeExec+0x8669>
   57afa:	mov    eax,r13d
   57afd:	and    eax,0x1
   57b00:	cmp    eax,0x1
   57b03:	jne    57b09 <sqlite3VdbeExec+0x8669>
   57b05:	add    r13d,0x1
   57b09:	mov    r15,QWORD PTR [rsp+0x188]
   57b11:	mov    rax,QWORD PTR [r15+0x28]
   57b15:	xor    ecx,ecx
   57b17:	mov    QWORD PTR [rsp+0x128],r14
   57b1f:	lea    r14,[rsp+0x398]
   57b27:	mov    rdx,r14
   57b2a:	mov    QWORD PTR [rsp+0x110],rdi
   57b32:	mov    rdi,rax
   57b35:	mov    rsi,r12
   57b38:	mov    r11,rdx
   57b3b:	mov    rdx,rcx
   57b3e:	mov    rcx,r11
   57b41:	call   57b46 <sqlite3VdbeExec+0x86a6>
   57b46:	mov    r14d,eax
   57b49:	mov    QWORD PTR [r15+0x48],r12
   57b4d:	mov    rdi,QWORD PTR [rsp+0x110]
   57b55:	test   r14d,r14d
   57b58:	je     57b82 <sqlite3VdbeExec+0x86e2>
   57b5a:	mov    QWORD PTR [rsp+0x148],rbp
   57b62:	mov    rbp,r14
   57b65:	mov    r14,QWORD PTR [rsp+0x128]
   57b6d:	mov    r13,QWORD PTR [rsp+0x130]
   57b75:	mov    rbx,QWORD PTR [rsp+0x158]
   57b7d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   57b82:	mov    r12,r15
   57b85:	mov    r15,r14
   57b88:	mov    r14,QWORD PTR [rsp+0x128]
   57b90:	xor    r11d,r11d
   57b93:	mov    DWORD PTR [rsp+0x39c],r11d
   57b9b:	cmp    r13d,0x17
   57b9f:	jl     57dd4 <sqlite3VdbeExec+0x8934>
   57ba5:	cmp    DWORD PTR [rsp+0x398],0x0
   57bad:	jl     57bc7 <sqlite3VdbeExec+0x8727>
   57baf:	cmp    DWORD PTR [rsp+0x398],0x0
   57bb7:	jne    57db9 <sqlite3VdbeExec+0x8919>
   57bbd:	cmp    r13d,0x18
   57bc1:	jne    57db9 <sqlite3VdbeExec+0x8919>
   57bc7:	mov    DWORD PTR [rsp+0x398],0x0
   57bd2:	mov    rax,QWORD PTR [r12+0x28]
   57bd7:	xor    ecx,ecx
   57bd9:	mov    QWORD PTR [rsp+0x110],rdi
   57be1:	mov    rdi,rax
   57be4:	mov    rsi,rcx
   57be7:	call   57bec <sqlite3VdbeExec+0x874c>
   57bec:	mov    r12d,eax
   57bef:	mov    rdi,QWORD PTR [rsp+0x110]
   57bf7:	test   r12d,r12d
   57bfa:	je     57c14 <sqlite3VdbeExec+0x8774>
   57bfc:	cmp    r12d,0x65
   57c00:	jne    57d99 <sqlite3VdbeExec+0x88f9>
   57c06:	mov    DWORD PTR [rsp+0x398],0x1
   57c11:	xor    r12d,r12d
   57c14:	mov    r15,r12
   57c17:	jmp    57dc4 <sqlite3VdbeExec+0x8924>
   57c1c:	mov    DWORD PTR [rsp+0x3a0],r13d
   57c24:	mov    rax,QWORD PTR [r12+0x28]
   57c29:	movzx  eax,BYTE PTR [rax+0x3]
   57c2d:	and    eax,0x2
   57c30:	test   eax,eax
   57c32:	jne    57c49 <sqlite3VdbeExec+0x87a9>
   57c34:	mov    r13d,DWORD PTR [rsp+0x3a0]
   57c3c:	xor    r11d,r11d
   57c3f:	mov    DWORD PTR [rsp+0x39c],r11d
   57c47:	jmp    57c5f <sqlite3VdbeExec+0x87bf>
   57c49:	mov    r13d,DWORD PTR [rsp+0x3a0]
   57c51:	mov    r11d,0x1
   57c57:	mov    DWORD PTR [rsp+0x39c],r11d
   57c5f:	mov    eax,DWORD PTR [rbp+0x10]
   57c62:	mov    rcx,QWORD PTR [r12+0x30]
   57c67:	mov    QWORD PTR [rsp+0x1e8],rcx
   57c6f:	mov    WORD PTR [rsp+0x204],ax
   57c77:	mov    eax,r13d
   57c7a:	sub    eax,0x15
   57c7d:	and    eax,0x1
   57c80:	test   eax,eax
   57c82:	je     57c8b <sqlite3VdbeExec+0x87eb>
   57c84:	mov    eax,0xff
   57c89:	jmp    57c90 <sqlite3VdbeExec+0x87f0>
   57c8b:	mov    eax,0x1
   57c90:	mov    BYTE PTR [rsp+0x206],al
   57c97:	movsxd rax,DWORD PTR [rbp+0xc]
   57c9b:	imul   rax,rax,0x38
   57c9f:	add    rax,rbx
   57ca2:	mov    QWORD PTR [rsp+0x1f0],rax
   57caa:	mov    BYTE PTR [rsp+0x20a],0x0
   57cb2:	mov    rax,QWORD PTR [r12+0x28]
   57cb7:	mov    QWORD PTR [rsp+0x128],r14
   57cbf:	lea    r14,[rsp+0x1e8]
   57cc7:	mov    rcx,r14
   57cca:	lea    r14,[rsp+0x398]
   57cd2:	mov    rdx,r14
   57cd5:	mov    QWORD PTR [rsp+0x110],rdi
   57cdd:	mov    rdi,rax
   57ce0:	mov    rsi,rcx
   57ce3:	call   57ce8 <sqlite3VdbeExec+0x8848>
   57ce8:	mov    r14d,eax
   57ceb:	mov    rdi,QWORD PTR [rsp+0x110]
   57cf3:	test   r14d,r14d
   57cf6:	je     57d20 <sqlite3VdbeExec+0x8880>
   57cf8:	mov    QWORD PTR [rsp+0x148],rbp
   57d00:	mov    rbp,r14
   57d03:	mov    r14,QWORD PTR [rsp+0x128]
   57d0b:	mov    r13,QWORD PTR [rsp+0x130]
   57d13:	mov    rbx,QWORD PTR [rsp+0x158]
   57d1b:	jmp    4f712 <sqlite3VdbeExec+0x272>
   57d20:	mov    DWORD PTR [rsp+0x37c],r15d
   57d28:	mov    r15,r14
   57d2b:	mov    r14,QWORD PTR [rsp+0x128]
   57d33:	mov    DWORD PTR [rsp+0x3a8],r15d
   57d3b:	mov    r15d,DWORD PTR [rsp+0x39c]
   57d43:	test   r15d,r15d
   57d46:	jne    57d5d <sqlite3VdbeExec+0x88bd>
   57d48:	mov    DWORD PTR [rsp+0x39c],r15d
   57d50:	mov    r15d,DWORD PTR [rsp+0x3a8]
   57d58:	jmp    57b9b <sqlite3VdbeExec+0x86fb>
   57d5d:	cmp    BYTE PTR [rsp+0x20a],0x0
   57d65:	je     57d7c <sqlite3VdbeExec+0x88dc>
   57d67:	mov    DWORD PTR [rsp+0x39c],r15d
   57d6f:	mov    r15d,DWORD PTR [rsp+0x3a8]
   57d77:	jmp    57b9b <sqlite3VdbeExec+0x86fb>
   57d7c:	mov    r12d,DWORD PTR [rsp+0x3a8]
   57d84:	mov    DWORD PTR [rsp+0x39c],r15d
   57d8c:	mov    r15d,DWORD PTR [rsp+0x37c]
   57d94:	jmp    57ec3 <sqlite3VdbeExec+0x8a23>
   57d99:	mov    QWORD PTR [rsp+0x148],rbp
   57da1:	mov    rbp,r12
   57da4:	mov    r13,QWORD PTR [rsp+0x130]
   57dac:	mov    rbx,QWORD PTR [rsp+0x158]
   57db4:	jmp    4f712 <sqlite3VdbeExec+0x272>
   57db9:	mov    DWORD PTR [rsp+0x398],0x0
   57dc4:	mov    r12,r15
   57dc7:	mov    r15d,DWORD PTR [rsp+0x37c]
   57dcf:	jmp    57ec3 <sqlite3VdbeExec+0x8a23>
   57dd4:	cmp    DWORD PTR [rsp+0x398],0x0
   57ddc:	jg     57df6 <sqlite3VdbeExec+0x8956>
   57dde:	cmp    DWORD PTR [rsp+0x398],0x0
   57de6:	jne    57e9d <sqlite3VdbeExec+0x89fd>
   57dec:	cmp    r13d,0x15
   57df0:	jne    57e9d <sqlite3VdbeExec+0x89fd>
   57df6:	mov    DWORD PTR [rsp+0x398],0x0
   57e01:	mov    rax,QWORD PTR [r12+0x28]
   57e06:	movzx  ecx,BYTE PTR [rax+0x1]
   57e0a:	and    ecx,0xfffffff1
   57e0d:	mov    BYTE PTR [rax+0x1],cl
   57e10:	mov    WORD PTR [rax+0x46],0x0
   57e16:	cmp    BYTE PTR [rax],0x0
   57e19:	jne    57e2f <sqlite3VdbeExec+0x898f>
   57e1b:	cmp    WORD PTR [rax+0x56],0x0
   57e20:	je     57e2f <sqlite3VdbeExec+0x898f>
   57e22:	mov    rcx,QWORD PTR [rax+0x88]
   57e29:	cmp    BYTE PTR [rcx+0x8],0x0
   57e2d:	jne    57e4c <sqlite3VdbeExec+0x89ac>
   57e2f:	mov    QWORD PTR [rsp+0x110],rdi
   57e37:	mov    rdi,rax
   57e3a:	call   57e3f <sqlite3VdbeExec+0x899f>
   57e3f:	mov    r12d,eax
   57e42:	mov    rdi,QWORD PTR [rsp+0x110]
   57e4a:	jmp    57e5a <sqlite3VdbeExec+0x89ba>
   57e4c:	movzx  ecx,WORD PTR [rax+0x56]
   57e50:	sub    ecx,0x1
   57e53:	mov    WORD PTR [rax+0x56],cx
   57e57:	xor    r12d,r12d
   57e5a:	test   r12d,r12d
   57e5d:	je     57e73 <sqlite3VdbeExec+0x89d3>
   57e5f:	cmp    r12d,0x65
   57e63:	jne    57e7d <sqlite3VdbeExec+0x89dd>
   57e65:	mov    DWORD PTR [rsp+0x398],0x1
   57e70:	xor    r12d,r12d
   57e73:	mov    r15d,DWORD PTR [rsp+0x37c]
   57e7b:	jmp    57ec3 <sqlite3VdbeExec+0x8a23>
   57e7d:	mov    QWORD PTR [rsp+0x148],rbp
   57e85:	mov    rbp,r12
   57e88:	mov    r13,QWORD PTR [rsp+0x130]
   57e90:	mov    rbx,QWORD PTR [rsp+0x158]
   57e98:	jmp    4f712 <sqlite3VdbeExec+0x272>
   57e9d:	mov    rax,QWORD PTR [r12+0x28]
   57ea2:	xor    ecx,ecx
   57ea4:	movzx  eax,BYTE PTR [rax]
   57ea7:	cmp    ecx,eax
   57ea9:	mov    eax,0x0
   57eae:	setne  al
   57eb1:	mov    DWORD PTR [rsp+0x398],eax
   57eb8:	mov    r12,r15
   57ebb:	mov    r15d,DWORD PTR [rsp+0x37c]
   57ec3:	cmp    DWORD PTR [rsp+0x398],0x0
   57ecb:	je     57edd <sqlite3VdbeExec+0x8a3d>
   57ecd:	mov    DWORD PTR [rsp+0x38c],r12d
   57ed5:	mov    r12,r14
   57ed8:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   57edd:	mov    r13d,DWORD PTR [rsp+0x39c]
   57ee5:	test   r13d,r13d
   57ee8:	je     57eee <sqlite3VdbeExec+0x8a4e>
   57eea:	add    rbp,0x18
   57eee:	mov    DWORD PTR [rsp+0x37c],r15d
   57ef6:	mov    DWORD PTR [rsp+0x38c],r12d
   57efe:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   57f03:	mov    r15d,DWORD PTR [rsp+0x37c]
   57f0b:	mov    r13,QWORD PTR [rsp+0x150]
   57f13:	mov    QWORD PTR [rsp+0x130],r12
   57f1b:	mov    r12d,DWORD PTR [rsp+0x394]
   57f23:	mov    rax,QWORD PTR [rdi+0x78]
   57f27:	movsxd rcx,DWORD PTR [rbp+0x1c]
   57f2b:	mov    DWORD PTR [rsp+0x394],r12d
   57f33:	mov    r12,QWORD PTR [rax+rcx*8]
   57f37:	mov    rax,QWORD PTR [r12+0x28]
   57f3c:	cmp    BYTE PTR [rax],0x0
   57f3f:	je     57f56 <sqlite3VdbeExec+0x8ab6>
   57f41:	mov    DWORD PTR [rsp+0x37c],r15d
   57f49:	mov    QWORD PTR [rsp+0x150],r13
   57f51:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   57f56:	mov    QWORD PTR [rsp+0x150],r13
   57f5e:	mov    r13d,DWORD PTR [rbp+0x4]
   57f62:	mov    rax,QWORD PTR [r12+0x30]
   57f67:	mov    QWORD PTR [rsp+0x1e8],rax
   57f6f:	mov    eax,DWORD PTR [rbp+0x28]
   57f72:	mov    WORD PTR [rsp+0x204],ax
   57f7a:	mov    BYTE PTR [rsp+0x206],0x0
   57f82:	movsxd rax,DWORD PTR [rbp+0x24]
   57f86:	imul   rax,rax,0x38
   57f8a:	add    rax,rbx
   57f8d:	mov    QWORD PTR [rsp+0x1f0],rax
   57f95:	mov    DWORD PTR [rsp+0x398],0x0
   57fa0:	mov    DWORD PTR [rsp+0x37c],r15d
   57fa8:	jmp    58179 <sqlite3VdbeExec+0x8cd9>
   57fad:	mov    DWORD PTR [rsp+0x39c],r13d
   57fb5:	mov    r13,r15
   57fb8:	mov    r15d,DWORD PTR [rsp+0x37c]
   57fc0:	mov    QWORD PTR [rsp+0x188],r12
   57fc8:	lea    r12,[rsp+0x240]
   57fd0:	mov    WORD PTR [r12+0x14],0x0
   57fd8:	mov    QWORD PTR [r12+0x18],r14
   57fdd:	mov    DWORD PTR [r12+0x20],0x0
   57fe6:	mov    rcx,r12
   57fe9:	mov    QWORD PTR [rsp+0x110],rdi
   57ff1:	mov    rdi,r13
   57ff4:	mov    rsi,rax
   57ff7:	mov    rdx,rcx
   57ffa:	call   57fff <sqlite3VdbeExec+0x8b5f>
   57fff:	mov    r13d,eax
   58002:	mov    rdi,QWORD PTR [rsp+0x110]
   5800a:	test   r13d,r13d
   5800d:	je     58014 <sqlite3VdbeExec+0x8b74>
   5800f:	mov    r12,r13
   58012:	jmp    5806b <sqlite3VdbeExec+0x8bcb>
   58014:	mov    eax,DWORD PTR [r12+0x10]
   58019:	mov    rcx,QWORD PTR [r12+0x8]
   5801e:	xor    edx,edx
   58020:	lea    r13,[rsp+0x1e8]
   58028:	mov    rdi,rax
   5802b:	mov    rsi,rcx
   5802e:	mov    rcx,rdx
   58031:	mov    rdx,r13
   58034:	call   58039 <sqlite3VdbeExec+0x8b99>
   58039:	lea    r13,[rsp+0x398]
   58041:	mov    DWORD PTR [r13+0x0],eax
   58045:	mov    rax,r12
   58048:	mov    rdi,QWORD PTR [rsp+0x110]
   58050:	cmp    DWORD PTR [r12+0x20],0x0
   58056:	je     58068 <sqlite3VdbeExec+0x8bc8>
   58058:	mov    rdi,rax
   5805b:	call   58060 <sqlite3VdbeExec+0x8bc0>
   58060:	mov    rdi,QWORD PTR [rsp+0x110]
   58068:	xor    r12d,r12d
   5806b:	test   r12d,r12d
   5806e:	je     58090 <sqlite3VdbeExec+0x8bf0>
   58070:	mov    QWORD PTR [rsp+0x148],rbp
   58078:	mov    rbp,r12
   5807b:	mov    r13,QWORD PTR [rsp+0x130]
   58083:	mov    rbx,QWORD PTR [rsp+0x158]
   5808b:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58090:	cmp    DWORD PTR [rsp+0x398],0x0
   58098:	jle    580b1 <sqlite3VdbeExec+0x8c11>
   5809a:	cmp    WORD PTR [rbp+0x2],0x0
   5809f:	jne    580b1 <sqlite3VdbeExec+0x8c11>
   580a1:	mov    DWORD PTR [rsp+0x38c],r12d
   580a9:	mov    r12,r14
   580ac:	jmp    58150 <sqlite3VdbeExec+0x8cb0>
   580b1:	cmp    DWORD PTR [rsp+0x398],0x0
   580b9:	jl     580cb <sqlite3VdbeExec+0x8c2b>
   580bb:	mov    DWORD PTR [rsp+0x38c],r12d
   580c3:	mov    r12,r14
   580c6:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   580cb:	mov    r13d,DWORD PTR [rsp+0x39c]
   580d3:	test   r13d,r13d
   580d6:	jg     580ed <sqlite3VdbeExec+0x8c4d>
   580d8:	mov    DWORD PTR [rsp+0x37c],r15d
   580e0:	mov    DWORD PTR [rsp+0x38c],r12d
   580e8:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   580ed:	mov    r12,QWORD PTR [rsp+0x188]
   580f5:	sub    r13d,0x1
   580f9:	mov    DWORD PTR [r12+0x18],0x0
   58102:	mov    rax,QWORD PTR [r12+0x28]
   58107:	xor    ecx,ecx
   58109:	mov    DWORD PTR [rsp+0x37c],r15d
   58111:	mov    QWORD PTR [rsp+0x110],rdi
   58119:	mov    rdi,rax
   5811c:	mov    rsi,rcx
   5811f:	call   58124 <sqlite3VdbeExec+0x8c84>
   58124:	mov    r15d,eax
   58127:	mov    rdi,QWORD PTR [rsp+0x110]
   5812f:	test   r15d,r15d
   58132:	je     58179 <sqlite3VdbeExec+0x8cd9>
   58134:	cmp    r15d,0x65
   58138:	jne    58159 <sqlite3VdbeExec+0x8cb9>
   5813a:	mov    r12,r14
   5813d:	mov    r15d,DWORD PTR [rsp+0x37c]
   58145:	xor    r11d,r11d
   58148:	mov    DWORD PTR [rsp+0x38c],r11d
   58150:	add    rbp,0x18
   58154:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   58159:	mov    QWORD PTR [rsp+0x148],rbp
   58161:	mov    rbp,r15
   58164:	mov    r13,QWORD PTR [rsp+0x130]
   5816c:	mov    rbx,QWORD PTR [rsp+0x158]
   58174:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58179:	lea    r15,[rsp+0x1e8]
   58181:	lea    r15,[rsp+0x398]
   58189:	mov    r15,QWORD PTR [r12+0x28]
   5818e:	mov    QWORD PTR [rsp+0x110],rdi
   58196:	mov    rdi,r15
   58199:	call   5819e <sqlite3VdbeExec+0x8cfe>
   5819e:	mov    eax,DWORD PTR [r15+0x40]
   581a2:	mov    rdi,QWORD PTR [rsp+0x110]
   581aa:	test   rax,rax
   581ad:	jle    581bb <sqlite3VdbeExec+0x8d1b>
   581af:	cmp    rax,0x7fffffff
   581b5:	jle    57fad <sqlite3VdbeExec+0x8b0d>
   581bb:	mov    DWORD PTR [rsp+0x398],0x0
   581c6:	mov    eax,0x16b6e
   581cb:	mov    ecx,0xb
   581d0:	lea    rdx,[rip+0x0]        # 581d7 <sqlite3VdbeExec+0x8d37>
   581d7:	mov    QWORD PTR [rsp+0x110],rdi
   581df:	mov    rdi,rcx
   581e2:	mov    rsi,rax
   581e5:	call   581ea <sqlite3VdbeExec+0x8d4a>
   581ea:	mov    r15d,eax
   581ed:	mov    rdi,QWORD PTR [rsp+0x110]
   581f5:	mov    QWORD PTR [rsp+0x188],r12
   581fd:	mov    DWORD PTR [rsp+0x39c],r13d
   58205:	mov    r12,r15
   58208:	mov    r15d,DWORD PTR [rsp+0x37c]
   58210:	jmp    5806b <sqlite3VdbeExec+0x8bcb>
   58215:	mov    r15d,DWORD PTR [rsp+0x37c]
   5821d:	mov    r13,QWORD PTR [rsp+0x150]
   58225:	mov    QWORD PTR [rsp+0x130],r12
   5822d:	mov    r12d,DWORD PTR [rsp+0x394]
   58235:	mov    rax,QWORD PTR [rdi+0x78]
   58239:	movsxd rcx,DWORD PTR [rbp+0x4]
   5823d:	mov    rax,QWORD PTR [rax+rcx*8]
   58241:	movzx  ecx,WORD PTR [rax+0x6]
   58245:	cmp    ecx,DWORD PTR [rbp+0x8]
   58248:	jge    58253 <sqlite3VdbeExec+0x8db3>
   5824a:	mov    ecx,DWORD PTR [rbp+0x8]
   5824d:	mov    WORD PTR [rax+0x6],cx
   58251:	jmp    58263 <sqlite3VdbeExec+0x8dc3>
   58253:	movzx  ecx,WORD PTR [rax+0x6]
   58257:	cmp    ecx,DWORD PTR [rbp+0xc]
   5825a:	jle    58263 <sqlite3VdbeExec+0x8dc3>
   5825c:	mov    ecx,DWORD PTR [rbp+0xc]
   5825f:	mov    WORD PTR [rax+0x6],cx
   58263:	mov    DWORD PTR [rsp+0x37c],r15d
   5826b:	mov    QWORD PTR [rsp+0x150],r13
   58273:	mov    DWORD PTR [rsp+0x394],r12d
   5827b:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   58280:	mov    r15d,DWORD PTR [rsp+0x37c]
   58288:	mov    r13,QWORD PTR [rsp+0x150]
   58290:	mov    QWORD PTR [rsp+0x130],r12
   58298:	mov    r12d,DWORD PTR [rsp+0x394]
   582a0:	mov    rax,QWORD PTR [rdi+0x78]
   582a4:	movsxd rcx,DWORD PTR [rbp+0x4]
   582a8:	mov    rax,QWORD PTR [rax+rcx*8]
   582ac:	test   rax,rax
   582af:	je     582b7 <sqlite3VdbeExec+0x8e17>
   582b1:	cmp    BYTE PTR [rax+0x2],0x0
   582b5:	je     582bc <sqlite3VdbeExec+0x8e1c>
   582b7:	jmp    4f7bd <sqlite3VdbeExec+0x31d>
   582bc:	mov    DWORD PTR [rsp+0x37c],r15d
   582c4:	mov    QWORD PTR [rsp+0x150],r13
   582cc:	mov    DWORD PTR [rsp+0x394],r12d
   582d4:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   582d9:	mov    r15d,DWORD PTR [rsp+0x37c]
   582e1:	mov    r13,QWORD PTR [rsp+0x150]
   582e9:	mov    QWORD PTR [rsp+0x130],r12
   582f1:	mov    r12d,DWORD PTR [rsp+0x394]
   582f9:	mov    rax,QWORD PTR [rdi+0x78]
   582fd:	movsxd rcx,DWORD PTR [rbp+0x4]
   58301:	mov    rax,QWORD PTR [rax+rcx*8]
   58305:	movzx  eax,WORD PTR [rax+0x6]
   58309:	cmp    eax,DWORD PTR [rbp+0x10]
   5830c:	jl     5832b <sqlite3VdbeExec+0x8e8b>
   5830e:	mov    DWORD PTR [rsp+0x37c],r15d
   58316:	mov    QWORD PTR [rsp+0x150],r13
   5831e:	mov    DWORD PTR [rsp+0x394],r12d
   58326:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5832b:	mov    rax,QWORD PTR [rdi+0x78]
   5832f:	movsxd rcx,DWORD PTR [rbp+0x4]
   58333:	mov    DWORD PTR [rsp+0x394],r12d
   5833b:	mov    r12,QWORD PTR [rax+rcx*8]
   5833f:	movsxd rax,DWORD PTR [rbp+0xc]
   58343:	imul   rax,rax,0x38
   58347:	add    rax,rbx
   5834a:	mov    QWORD PTR [rsp+0x1f0],rax
   58352:	mov    eax,DWORD PTR [rbp+0x10]
   58355:	mov    WORD PTR [rsp+0x204],ax
   5835d:	cmp    WORD PTR [rsp+0x204],0x0
   58366:	jbe    583bd <sqlite3VdbeExec+0x8f1d>
   58368:	mov    rax,QWORD PTR [r12+0x30]
   5836d:	mov    QWORD PTR [rsp+0x1e8],rax
   58375:	mov    BYTE PTR [rsp+0x206],0x0
   5837d:	mov    rax,QWORD PTR [r12+0x28]
   58382:	mov    QWORD PTR [rsp+0x150],r13
   5838a:	lea    r13,[rsp+0x1e8]
   58392:	mov    rcx,r13
   58395:	lea    rdx,[r12+0x1c]
   5839a:	mov    QWORD PTR [rsp+0x110],rdi
   583a2:	mov    rdi,rax
   583a5:	mov    rsi,rcx
   583a8:	call   583ad <sqlite3VdbeExec+0x8f0d>
   583ad:	mov    r13d,eax
   583b0:	mov    rdi,QWORD PTR [rsp+0x110]
   583b8:	jmp    585c3 <sqlite3VdbeExec+0x9123>
   583bd:	mov    QWORD PTR [rsp+0x150],r13
   583c5:	mov    rax,QWORD PTR [rsp+0x1f0]
   583cd:	movzx  eax,WORD PTR [rax+0x14]
   583d1:	and    eax,0x400
   583d6:	test   eax,eax
   583d8:	je     5846d <sqlite3VdbeExec+0x8fcd>
   583de:	mov    r13,QWORD PTR [rsp+0x1f0]
   583e6:	mov    eax,DWORD PTR [r13+0x10]
   583ea:	add    eax,DWORD PTR [r13+0x0]
   583ee:	test   eax,eax
   583f0:	jg     58403 <sqlite3VdbeExec+0x8f63>
   583f2:	movzx  eax,WORD PTR [r13+0x14]
   583f7:	and    eax,0x10
   583fa:	test   eax,eax
   583fc:	je     5846d <sqlite3VdbeExec+0x8fcd>
   583fe:	mov    eax,0x1
   58403:	mov    ecx,0x1
   58408:	mov    QWORD PTR [rsp+0x110],rdi
   58410:	mov    rdi,r13
   58413:	mov    rsi,rax
   58416:	mov    rdx,rcx
   58419:	call   5841e <sqlite3VdbeExec+0x8f7e>
   5841e:	mov    rdi,QWORD PTR [rsp+0x110]
   58426:	test   eax,eax
   58428:	jne    584b3 <sqlite3VdbeExec+0x9013>
   5842e:	mov    rax,QWORD PTR [r13+0x8]
   58432:	movsxd rcx,DWORD PTR [r13+0x10]
   58436:	add    rax,rcx
   58439:	xor    ecx,ecx
   5843b:	movsxd rdx,DWORD PTR [r13+0x0]
   5843f:	mov    rdi,rax
   58442:	mov    rsi,rcx
   58445:	call   5844a <sqlite3VdbeExec+0x8faa>
   5844a:	mov    eax,DWORD PTR [r13+0x10]
   5844e:	add    eax,DWORD PTR [r13+0x0]
   58452:	mov    DWORD PTR [r13+0x10],eax
   58456:	movzx  eax,WORD PTR [r13+0x14]
   5845b:	and    eax,0xfffff9ff
   58460:	mov    WORD PTR [r13+0x14],ax
   58465:	mov    rdi,QWORD PTR [rsp+0x110]
   5846d:	mov    r13,QWORD PTR [r12+0x30]
   58472:	movzx  eax,WORD PTR [r13+0x6]
   58477:	add    eax,0x1
   5847a:	imul   rax,rax,0x38
   5847e:	add    rax,0x28
   58482:	mov    rcx,QWORD PTR [r13+0x10]
   58486:	test   rcx,rcx
   58489:	je     584db <sqlite3VdbeExec+0x903b>
   5848b:	mov    QWORD PTR [rsp+0x128],r14
   58493:	mov    QWORD PTR [rsp+0x110],rdi
   5849b:	mov    rdi,rcx
   5849e:	mov    rsi,rax
   584a1:	call   584a6 <sqlite3VdbeExec+0x9006>
   584a6:	mov    r14,rax
   584a9:	mov    rdi,QWORD PTR [rsp+0x110]
   584b1:	jmp    584fe <sqlite3VdbeExec+0x905e>
   584b3:	mov    QWORD PTR [rsp+0x128],r14
   584bb:	mov    r14,QWORD PTR [rsp+0x128]
   584c3:	mov    r13,QWORD PTR [rsp+0x150]
   584cb:	mov    rbx,rbp
   584ce:	mov    rbp,QWORD PTR [rsp+0x158]
   584d6:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   584db:	mov    QWORD PTR [rsp+0x128],r14
   584e3:	mov    QWORD PTR [rsp+0x110],rdi
   584eb:	mov    rdi,rax
   584ee:	call   584f3 <sqlite3VdbeExec+0x9053>
   584f3:	mov    r14,rax
   584f6:	mov    rdi,QWORD PTR [rsp+0x110]
   584fe:	test   r14,r14
   58501:	jne    5850b <sqlite3VdbeExec+0x906b>
   58503:	xor    r13d,r13d
   58506:	mov    r14,r13
   58509:	jmp    58523 <sqlite3VdbeExec+0x9083>
   5850b:	lea    rax,[r14+0x28]
   5850f:	mov    QWORD PTR [r14+0x8],rax
   58513:	mov    QWORD PTR [r14],r13
   58516:	movzx  eax,WORD PTR [r13+0x6]
   5851b:	add    eax,0x1
   5851e:	mov    WORD PTR [r14+0x1c],ax
   58523:	test   r14,r14
   58526:	jne    58548 <sqlite3VdbeExec+0x90a8>
   58528:	mov    r14,QWORD PTR [rsp+0x128]
   58530:	mov    r13,QWORD PTR [rsp+0x150]
   58538:	mov    rbx,rbp
   5853b:	mov    rbp,QWORD PTR [rsp+0x158]
   58543:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   58548:	mov    rax,QWORD PTR [rsp+0x1f0]
   58550:	mov    eax,DWORD PTR [rax+0x10]
   58553:	mov    rcx,QWORD PTR [rsp+0x1f0]
   5855b:	mov    rcx,QWORD PTR [rcx+0x8]
   5855f:	mov    QWORD PTR [rsp+0x110],rdi
   58567:	mov    rdi,rax
   5856a:	mov    rsi,rcx
   5856d:	mov    rdx,r14
   58570:	call   58575 <sqlite3VdbeExec+0x90d5>
   58575:	mov    BYTE PTR [r14+0x1e],0x0
   5857a:	mov    rax,QWORD PTR [r12+0x28]
   5857f:	lea    rcx,[r12+0x1c]
   58584:	mov    rdi,rax
   58587:	mov    rsi,r14
   5858a:	mov    rdx,rcx
   5858d:	call   58592 <sqlite3VdbeExec+0x90f2>
   58592:	mov    r13d,eax
   58595:	mov    DWORD PTR [rsp+0x398],r13d
   5859d:	mov    r13,QWORD PTR [rsp+0x128]
   585a5:	mov    rdi,r13
   585a8:	mov    rsi,r14
   585ab:	call   585b0 <sqlite3VdbeExec+0x9110>
   585b0:	mov    rdi,QWORD PTR [rsp+0x110]
   585b8:	mov    r14,r13
   585bb:	mov    r13d,DWORD PTR [rsp+0x398]
   585c3:	test   r13d,r13d
   585c6:	je     585e8 <sqlite3VdbeExec+0x9148>
   585c8:	mov    QWORD PTR [rsp+0x148],rbp
   585d0:	mov    rbp,r13
   585d3:	mov    r13,QWORD PTR [rsp+0x130]
   585db:	mov    rbx,QWORD PTR [rsp+0x158]
   585e3:	jmp    4f712 <sqlite3VdbeExec+0x272>
   585e8:	mov    eax,DWORD PTR [r12+0x1c]
   585ed:	xor    ecx,ecx
   585ef:	test   eax,eax
   585f1:	sete   cl
   585f4:	mov    edx,0x1
   585f9:	sub    edx,ecx
   585fb:	mov    BYTE PTR [r12+0x2],dl
   58600:	mov    BYTE PTR [r12+0x3],0x0
   58606:	mov    DWORD PTR [r12+0x18],0x0
   5860f:	cmp    BYTE PTR [rbp+0x0],0x1d
   58613:	jne    58629 <sqlite3VdbeExec+0x9189>
   58615:	test   eax,eax
   58617:	jne    58690 <sqlite3VdbeExec+0x91f0>
   58619:	mov    r12,r14
   5861c:	mov    DWORD PTR [rsp+0x38c],r13d
   58624:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   58629:	test   eax,eax
   5862b:	je     5863d <sqlite3VdbeExec+0x919d>
   5862d:	mov    r12,r14
   58630:	mov    DWORD PTR [rsp+0x38c],r13d
   58638:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   5863d:	cmp    BYTE PTR [rbp+0x0],0x1b
   58641:	jne    58681 <sqlite3VdbeExec+0x91e1>
   58643:	xor    eax,eax
   58645:	jmp    5864a <sqlite3VdbeExec+0x91aa>
   58647:	add    eax,0x1
   5864a:	movzx  ecx,WORD PTR [rsp+0x204]
   58652:	cmp    eax,ecx
   58654:	jge    58681 <sqlite3VdbeExec+0x91e1>
   58656:	mov    rcx,QWORD PTR [rsp+0x1f0]
   5865e:	mov    rdx,rax
   58661:	imul   rdx,rdx,0x38
   58665:	movzx  ecx,WORD PTR [rcx+rdx*1+0x14]
   5866a:	and    ecx,0x1
   5866d:	test   ecx,ecx
   5866f:	je     58647 <sqlite3VdbeExec+0x91a7>
   58671:	mov    r12,r14
   58674:	mov    DWORD PTR [rsp+0x38c],r13d
   5867c:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   58681:	cmp    BYTE PTR [rbp+0x0],0x1a
   58685:	jne    58690 <sqlite3VdbeExec+0x91f0>
   58687:	mov    eax,DWORD PTR [rbp+0x10]
   5868a:	mov    WORD PTR [r12+0x6],ax
   58690:	mov    DWORD PTR [rsp+0x37c],r15d
   58698:	mov    DWORD PTR [rsp+0x38c],r13d
   586a0:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   586a5:	mov    r15d,DWORD PTR [rsp+0x37c]
   586ad:	mov    r13,QWORD PTR [rsp+0x150]
   586b5:	mov    QWORD PTR [rsp+0x130],r12
   586bd:	mov    r12d,DWORD PTR [rsp+0x394]
   586c5:	movsxd rax,DWORD PTR [rbp+0xc]
   586c9:	imul   rax,rax,0x38
   586cd:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   586d2:	and    ecx,0x24
   586d5:	test   ecx,ecx
   586d7:	je     586e6 <sqlite3VdbeExec+0x9246>
   586d9:	mov    DWORD PTR [rsp+0x394],r12d
   586e1:	jmp    5878a <sqlite3VdbeExec+0x92ea>
   586e6:	vmovdqu32 xmm0,XMMWORD PTR [rbx+rax*1]
   586ed:	vmovdqu32 XMMWORD PTR [rsp+0x240],xmm0
   586f5:	vmovdqu32 xmm0,XMMWORD PTR [rbx+rax*1+0x10]
   586fd:	vmovdqu32 XMMWORD PTR [rsp+0x250],xmm0
   58705:	vmovdqu32 xmm0,XMMWORD PTR [rbx+rax*1+0x20]
   5870d:	vmovdqu32 XMMWORD PTR [rsp+0x260],xmm0
   58715:	vmovdqu32 xmm0,XMMWORD PTR [rbx+rax*1+0x28]
   58720:	vmovdqu32 XMMWORD PTR [rsp+0x268],xmm0
   5872b:	mov    DWORD PTR [rsp+0x394],r12d
   58733:	lea    r12,[rsp+0x240]
   5873b:	mov    rax,r12
   5873e:	mov    ecx,0x43
   58743:	mov    edx,r15d
   58746:	mov    QWORD PTR [rsp+0x110],rdi
   5874e:	mov    rdi,rax
   58751:	mov    rsi,rcx
   58754:	call   58759 <sqlite3VdbeExec+0x92b9>
   58759:	movzx  eax,WORD PTR [rsp+0x254]
   58761:	and    eax,0x4
   58764:	mov    rdi,QWORD PTR [rsp+0x110]
   5876c:	test   eax,eax
   5876e:	jne    58780 <sqlite3VdbeExec+0x92e0>
   58770:	mov    r12,r14
   58773:	mov    QWORD PTR [rsp+0x150],r13
   5877b:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   58780:	mov    r12,QWORD PTR [rsp+0x240]
   58788:	jmp    58796 <sqlite3VdbeExec+0x92f6>
   5878a:	movsxd rax,DWORD PTR [rbp+0xc]
   5878e:	imul   rax,rax,0x38
   58792:	mov    r12,QWORD PTR [rbx+rax*1]
   58796:	mov    rax,QWORD PTR [rdi+0x78]
   5879a:	movsxd rcx,DWORD PTR [rbp+0x4]
   5879e:	mov    QWORD PTR [rsp+0x150],r13
   587a6:	mov    r13,QWORD PTR [rax+rcx*8]
   587aa:	mov    rax,QWORD PTR [r13+0x28]
   587ae:	mov    DWORD PTR [rsp+0x378],0x0
   587b9:	xor    ecx,ecx
   587bb:	mov    DWORD PTR [rsp+0x37c],r15d
   587c3:	lea    r15,[rsp+0x378]
   587cb:	mov    rdx,r15
   587ce:	mov    QWORD PTR [rsp+0x110],rdi
   587d6:	mov    rdi,rax
   587d9:	mov    rsi,r12
   587dc:	mov    r11,rdx
   587df:	mov    rdx,rcx
   587e2:	mov    rcx,r11
   587e5:	call   587ea <sqlite3VdbeExec+0x934a>
   587ea:	mov    r15d,eax
   587ed:	mov    QWORD PTR [r13+0x48],r12
   587f1:	mov    BYTE PTR [r13+0x2],0x0
   587f6:	mov    DWORD PTR [r13+0x18],0x0
   587fe:	mov    BYTE PTR [r13+0x3],0x0
   58803:	mov    eax,DWORD PTR [rsp+0x378]
   5880a:	mov    DWORD PTR [r13+0x1c],eax
   5880e:	mov    rdi,QWORD PTR [rsp+0x110]
   58816:	cmp    DWORD PTR [rsp+0x378],0x0
   5881e:	je     58850 <sqlite3VdbeExec+0x93b0>
   58820:	cmp    DWORD PTR [rbp+0x8],0x0
   58824:	jne    58875 <sqlite3VdbeExec+0x93d5>
   58826:	mov    eax,0x18e86
   5882b:	mov    ecx,0xb
   58830:	lea    rdx,[rip+0x0]        # 58837 <sqlite3VdbeExec+0x9397>
   58837:	mov    rdi,rcx
   5883a:	mov    rsi,rax
   5883d:	call   58842 <sqlite3VdbeExec+0x93a2>
   58842:	mov    r12d,eax
   58845:	mov    rdi,QWORD PTR [rsp+0x110]
   5884d:	mov    r15,r12
   58850:	test   r15d,r15d
   58853:	je     58890 <sqlite3VdbeExec+0x93f0>
   58855:	mov    QWORD PTR [rsp+0x148],rbp
   5885d:	mov    rbp,r15
   58860:	mov    r13,QWORD PTR [rsp+0x130]
   58868:	mov    rbx,QWORD PTR [rsp+0x158]
   58870:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58875:	mov    r12,r14
   58878:	mov    r14,r15
   5887b:	mov    r15d,DWORD PTR [rsp+0x37c]
   58883:	mov    DWORD PTR [rsp+0x38c],r14d
   5888b:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   58890:	mov    DWORD PTR [rsp+0x38c],r15d
   58898:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5889d:	mov    r15d,DWORD PTR [rsp+0x37c]
   588a5:	mov    r13,QWORD PTR [rsp+0x150]
   588ad:	mov    QWORD PTR [rsp+0x130],r12
   588b5:	mov    r12d,DWORD PTR [rsp+0x394]
   588bd:	mov    rax,QWORD PTR [rdi+0x68]
   588c1:	movsxd rcx,DWORD PTR [rbp+0x8]
   588c5:	imul   rcx,rcx,0x38
   588c9:	lea    rdx,[rax+rcx*1]
   588cd:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   588d2:	and    eax,0x9000
   588d7:	test   eax,eax
   588d9:	je     588f8 <sqlite3VdbeExec+0x9458>
   588db:	mov    QWORD PTR [rsp+0x110],rdi
   588e3:	mov    rdi,rdx
   588e6:	call   588eb <sqlite3VdbeExec+0x944b>
   588eb:	mov    rdi,QWORD PTR [rsp+0x110]
   588f3:	mov    rdx,rax
   588f6:	jmp    588fe <sqlite3VdbeExec+0x945e>
   588f8:	mov    WORD PTR [rdx+0x14],0x4
   588fe:	mov    rax,QWORD PTR [rdi+0x78]
   58902:	movsxd rcx,DWORD PTR [rbp+0x4]
   58906:	mov    rax,QWORD PTR [rax+rcx*8]
   5890a:	mov    rcx,QWORD PTR [rax+0x10]
   5890e:	lea    rsi,[rcx+0x1]
   58912:	mov    QWORD PTR [rax+0x10],rsi
   58916:	mov    QWORD PTR [rdx],rcx
   58919:	mov    DWORD PTR [rsp+0x37c],r15d
   58921:	mov    QWORD PTR [rsp+0x150],r13
   58929:	mov    DWORD PTR [rsp+0x394],r12d
   58931:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   58936:	mov    r15d,DWORD PTR [rsp+0x37c]
   5893e:	mov    r13,QWORD PTR [rsp+0x150]
   58946:	mov    QWORD PTR [rsp+0x130],r12
   5894e:	mov    r12d,DWORD PTR [rsp+0x394]
   58956:	mov    QWORD PTR [rsp+0x188],0x0
   58962:	mov    DWORD PTR [rsp+0x398],0x0
   5896d:	mov    rax,QWORD PTR [rdi+0x68]
   58971:	movsxd rcx,DWORD PTR [rbp+0x8]
   58975:	imul   rcx,rcx,0x38
   58979:	mov    DWORD PTR [rsp+0x394],r12d
   58981:	lea    r12,[rax+rcx*1]
   58985:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5898a:	and    eax,0x9000
   5898f:	test   eax,eax
   58991:	je     589b0 <sqlite3VdbeExec+0x9510>
   58993:	mov    QWORD PTR [rsp+0x110],rdi
   5899b:	mov    rdi,r12
   5899e:	call   589a3 <sqlite3VdbeExec+0x9503>
   589a3:	mov    r12,rax
   589a6:	mov    rdi,QWORD PTR [rsp+0x110]
   589ae:	jmp    589b8 <sqlite3VdbeExec+0x9518>
   589b0:	mov    WORD PTR [r12+0x14],0x4
   589b8:	mov    rax,QWORD PTR [rdi+0x78]
   589bc:	movsxd rcx,DWORD PTR [rbp+0x4]
   589c0:	mov    QWORD PTR [rsp+0x168],r12
   589c8:	mov    r12,QWORD PTR [rax+rcx*8]
   589cc:	movzx  eax,BYTE PTR [r12+0x5]
   589d2:	shl    rax,0x3e
   589d6:	shr    rax,0x3f
   589da:	test   eax,eax
   589dc:	je     589eb <sqlite3VdbeExec+0x954b>
   589de:	mov    QWORD PTR [rsp+0x178],r12
   589e6:	jmp    58b2e <sqlite3VdbeExec+0x968e>
   589eb:	mov    rax,QWORD PTR [r12+0x28]
   589f0:	mov    QWORD PTR [rsp+0x178],r12
   589f8:	lea    r12,[rsp+0x398]
   58a00:	mov    rcx,r12
   58a03:	xor    edx,edx
   58a05:	movzx  esi,BYTE PTR [rax]
   58a08:	cmp    edx,esi
   58a0a:	jne    58a22 <sqlite3VdbeExec+0x9582>
   58a0c:	movzx  edx,BYTE PTR [rax+0x1]
   58a10:	and    edx,0x8
   58a13:	test   edx,edx
   58a15:	je     58a22 <sqlite3VdbeExec+0x9582>
   58a17:	mov    DWORD PTR [rcx],0x0
   58a1d:	xor    r12d,r12d
   58a20:	jmp    58a40 <sqlite3VdbeExec+0x95a0>
   58a22:	mov    QWORD PTR [rsp+0x110],rdi
   58a2a:	mov    rdi,rax
   58a2d:	mov    rsi,rcx
   58a30:	call   58a35 <sqlite3VdbeExec+0x9595>
   58a35:	mov    r12d,eax
   58a38:	mov    rdi,QWORD PTR [rsp+0x110]
   58a40:	test   r12d,r12d
   58a43:	je     58a6d <sqlite3VdbeExec+0x95cd>
   58a45:	mov    QWORD PTR [rsp+0x150],r13
   58a4d:	mov    QWORD PTR [rsp+0x148],rbp
   58a55:	mov    rbp,r12
   58a58:	mov    r13,QWORD PTR [rsp+0x130]
   58a60:	mov    rbx,QWORD PTR [rsp+0x158]
   58a68:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58a6d:	cmp    DWORD PTR [rsp+0x398],0x0
   58a75:	je     58a90 <sqlite3VdbeExec+0x95f0>
   58a77:	mov    QWORD PTR [rsp+0x188],0x1
   58a83:	mov    DWORD PTR [rsp+0x38c],r12d
   58a8b:	jmp    58b2e <sqlite3VdbeExec+0x968e>
   58a90:	mov    DWORD PTR [rsp+0x38c],r12d
   58a98:	mov    r12,QWORD PTR [rsp+0x178]
   58aa0:	mov    QWORD PTR [rsp+0x150],r13
   58aa8:	mov    r13,QWORD PTR [r12+0x28]
   58aad:	mov    QWORD PTR [rsp+0x110],rdi
   58ab5:	mov    rdi,r13
   58ab8:	call   58abd <sqlite3VdbeExec+0x961d>
   58abd:	mov    rax,QWORD PTR [r13+0x30]
   58ac1:	mov    QWORD PTR [rsp+0x188],rax
   58ac9:	movabs rax,0x7fffffffffffffff
   58ad3:	mov    rdi,QWORD PTR [rsp+0x110]
   58adb:	cmp    rax,QWORD PTR [rsp+0x188]
   58ae3:	jg     58b0a <sqlite3VdbeExec+0x966a>
   58ae5:	movzx  eax,BYTE PTR [r12+0x5]
   58aeb:	and    rax,0xfffffffffffffffd
   58aef:	or     rax,0x2
   58af3:	mov    BYTE PTR [r12+0x5],al
   58af8:	mov    QWORD PTR [rsp+0x178],r12
   58b00:	mov    r13,QWORD PTR [rsp+0x150]
   58b08:	jmp    58b2e <sqlite3VdbeExec+0x968e>
   58b0a:	mov    rax,QWORD PTR [rsp+0x188]
   58b12:	add    rax,0x1
   58b16:	mov    QWORD PTR [rsp+0x188],rax
   58b1e:	mov    QWORD PTR [rsp+0x178],r12
   58b26:	mov    r13,QWORD PTR [rsp+0x150]
   58b2e:	cmp    DWORD PTR [rbp+0xc],0x0
   58b32:	jne    58b49 <sqlite3VdbeExec+0x96a9>
   58b34:	mov    QWORD PTR [rsp+0x150],r13
   58b3c:	mov    r13,QWORD PTR [rsp+0x178]
   58b44:	jmp    58cc9 <sqlite3VdbeExec+0x9829>
   58b49:	cmp    QWORD PTR [rdi+0x108],0x0
   58b51:	je     58b79 <sqlite3VdbeExec+0x96d9>
   58b53:	mov    rax,QWORD PTR [rdi+0x108]
   58b5a:	jmp    58b60 <sqlite3VdbeExec+0x96c0>
   58b5c:	mov    rax,QWORD PTR [rax+0x8]
   58b60:	cmp    QWORD PTR [rax+0x8],0x0
   58b65:	jne    58b5c <sqlite3VdbeExec+0x96bc>
   58b67:	mov    rax,QWORD PTR [rax+0x18]
   58b6b:	movsxd rcx,DWORD PTR [rbp+0xc]
   58b6f:	imul   rcx,rcx,0x38
   58b73:	lea    r12,[rax+rcx*1]
   58b77:	jmp    58b85 <sqlite3VdbeExec+0x96e5>
   58b79:	movsxd rax,DWORD PTR [rbp+0xc]
   58b7d:	imul   rax,rax,0x38
   58b81:	lea    r12,[rbx+rax*1]
   58b85:	movzx  eax,WORD PTR [r12+0x14]
   58b8b:	mov    ecx,eax
   58b8d:	and    ecx,0x24
   58b90:	test   ecx,ecx
   58b92:	je     58b9d <sqlite3VdbeExec+0x96fd>
   58b94:	mov    rax,QWORD PTR [r12]
   58b98:	jmp    58c20 <sqlite3VdbeExec+0x9780>
   58b9d:	mov    ecx,eax
   58b9f:	and    ecx,0x8
   58ba2:	test   ecx,ecx
   58ba4:	je     58bf5 <sqlite3VdbeExec+0x9755>
   58ba6:	movsd  xmm0,QWORD PTR [r12]
   58bac:	movabs r11,0xc3dfffffffffffff
   58bb6:	movq   xmm1,r11
   58bbb:	ucomisd xmm1,xmm0
   58bbf:	jbe    58bcd <sqlite3VdbeExec+0x972d>
   58bc1:	movabs rax,0x8000000000000000
   58bcb:	jmp    58bf3 <sqlite3VdbeExec+0x9753>
   58bcd:	movabs r11,0x43dfffffffffffff
   58bd7:	movq   xmm1,r11
   58bdc:	ucomisd xmm0,xmm1
   58be0:	jbe    58bee <sqlite3VdbeExec+0x974e>
   58be2:	movabs rax,0x7fffffffffffffff
   58bec:	jmp    58bf3 <sqlite3VdbeExec+0x9753>
   58bee:	cvttsd2si rax,xmm0
   58bf3:	jmp    58c20 <sqlite3VdbeExec+0x9780>
   58bf5:	and    eax,0x12
   58bf8:	test   eax,eax
   58bfa:	je     58c1e <sqlite3VdbeExec+0x977e>
   58bfc:	cmp    QWORD PTR [r12+0x8],0x0
   58c02:	je     58c1e <sqlite3VdbeExec+0x977e>
   58c04:	mov    QWORD PTR [rsp+0x110],rdi
   58c0c:	mov    rdi,r12
   58c0f:	call   58c14 <sqlite3VdbeExec+0x9774>
   58c14:	mov    rdi,QWORD PTR [rsp+0x110]
   58c1c:	jmp    58c20 <sqlite3VdbeExec+0x9780>
   58c1e:	xor    eax,eax
   58c20:	mov    QWORD PTR [r12],rax
   58c24:	movzx  eax,WORD PTR [r12+0x14]
   58c2a:	and    eax,0xfffff240
   58c2f:	or     eax,0x4
   58c32:	mov    WORD PTR [r12+0x14],ax
   58c38:	movabs rax,0x7fffffffffffffff
   58c42:	cmp    rax,QWORD PTR [r12]
   58c46:	jne    58c52 <sqlite3VdbeExec+0x97b2>
   58c48:	mov    QWORD PTR [rsp+0x150],r13
   58c50:	jmp    58c73 <sqlite3VdbeExec+0x97d3>
   58c52:	mov    QWORD PTR [rsp+0x150],r13
   58c5a:	mov    r13,QWORD PTR [rsp+0x178]
   58c62:	movzx  eax,BYTE PTR [r13+0x5]
   58c67:	shl    rax,0x3e
   58c6b:	shr    rax,0x3f
   58c6f:	test   eax,eax
   58c71:	je     58c98 <sqlite3VdbeExec+0x97f8>
   58c73:	mov    ebx,0xd
   58c78:	mov    QWORD PTR [rsp+0x148],rbp
   58c80:	mov    rbp,rbx
   58c83:	mov    r13,QWORD PTR [rsp+0x130]
   58c8b:	mov    rbx,QWORD PTR [rsp+0x158]
   58c93:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58c98:	mov    rax,QWORD PTR [rsp+0x188]
   58ca0:	mov    rcx,QWORD PTR [r12]
   58ca4:	add    rcx,0x1
   58ca8:	cmp    rax,rcx
   58cab:	jge    58cbd <sqlite3VdbeExec+0x981d>
   58cad:	mov    rax,QWORD PTR [r12]
   58cb1:	add    rax,0x1
   58cb5:	mov    QWORD PTR [rsp+0x188],rax
   58cbd:	mov    rax,QWORD PTR [rsp+0x188]
   58cc5:	mov    QWORD PTR [r12],rax
   58cc9:	movzx  eax,BYTE PTR [r13+0x5]
   58cce:	shl    rax,0x3e
   58cd2:	shr    rax,0x3f
   58cd6:	test   eax,eax
   58cd8:	jne    58ce7 <sqlite3VdbeExec+0x9847>
   58cda:	mov    r12,QWORD PTR [rsp+0x168]
   58ce2:	jmp    58e1a <sqlite3VdbeExec+0x997a>
   58ce7:	xor    r12d,r12d
   58cea:	mov    eax,0x8
   58cef:	mov    QWORD PTR [rsp+0x128],r14
   58cf7:	lea    r14,[rsp+0x188]
   58cff:	mov    rcx,r14
   58d02:	mov    QWORD PTR [rsp+0x110],rdi
   58d0a:	mov    rdi,rax
   58d0d:	mov    rsi,rcx
   58d10:	call   58d15 <sqlite3VdbeExec+0x9875>
   58d15:	movabs rax,0x3fffffffffffffff
   58d1f:	and    rax,QWORD PTR [rsp+0x188]
   58d27:	mov    QWORD PTR [rsp+0x188],rax
   58d2f:	mov    rax,QWORD PTR [rsp+0x188]
   58d37:	add    rax,0x1
   58d3b:	mov    QWORD PTR [rsp+0x188],rax
   58d43:	mov    rax,QWORD PTR [r13+0x28]
   58d47:	mov    rcx,QWORD PTR [rsp+0x188]
   58d4f:	xor    edx,edx
   58d51:	lea    r14,[rsp+0x398]
   58d59:	mov    rsi,r14
   58d5c:	mov    rdi,rax
   58d5f:	mov    r11,rsi
   58d62:	mov    rsi,rcx
   58d65:	mov    rcx,r11
   58d68:	call   58d6d <sqlite3VdbeExec+0x98cd>
   58d6d:	mov    r14d,eax
   58d70:	mov    rdi,QWORD PTR [rsp+0x110]
   58d78:	test   r14d,r14d
   58d7b:	jne    58d9e <sqlite3VdbeExec+0x98fe>
   58d7d:	cmp    DWORD PTR [rsp+0x398],0x0
   58d85:	jne    58d9e <sqlite3VdbeExec+0x98fe>
   58d87:	add    r12d,0x1
   58d8b:	cmp    r12d,0x64
   58d8f:	jge    58d9e <sqlite3VdbeExec+0x98fe>
   58d91:	mov    r14,QWORD PTR [rsp+0x128]
   58d99:	jmp    58cea <sqlite3VdbeExec+0x984a>
   58d9e:	test   r14d,r14d
   58da1:	je     58dcb <sqlite3VdbeExec+0x992b>
   58da3:	mov    QWORD PTR [rsp+0x148],rbp
   58dab:	mov    rbp,r14
   58dae:	mov    r14,QWORD PTR [rsp+0x128]
   58db6:	mov    r13,QWORD PTR [rsp+0x130]
   58dbe:	mov    rbx,QWORD PTR [rsp+0x158]
   58dc6:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58dcb:	cmp    DWORD PTR [rsp+0x398],0x0
   58dd3:	jne    58e02 <sqlite3VdbeExec+0x9962>
   58dd5:	mov    ebx,0xd
   58dda:	mov    r14,QWORD PTR [rsp+0x128]
   58de2:	mov    QWORD PTR [rsp+0x148],rbp
   58dea:	mov    rbp,rbx
   58ded:	mov    r13,QWORD PTR [rsp+0x130]
   58df5:	mov    rbx,QWORD PTR [rsp+0x158]
   58dfd:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58e02:	mov    r12,QWORD PTR [rsp+0x168]
   58e0a:	mov    DWORD PTR [rsp+0x38c],r14d
   58e12:	mov    r14,QWORD PTR [rsp+0x128]
   58e1a:	mov    BYTE PTR [r13+0x3],0x0
   58e1f:	mov    DWORD PTR [r13+0x18],0x0
   58e27:	mov    rax,QWORD PTR [rsp+0x188]
   58e2f:	mov    QWORD PTR [r12],rax
   58e33:	mov    DWORD PTR [rsp+0x37c],r15d
   58e3b:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   58e40:	mov    r15d,DWORD PTR [rsp+0x37c]
   58e48:	mov    QWORD PTR [rsp+0x130],r12
   58e50:	movsxd rax,DWORD PTR [rbp+0x8]
   58e54:	imul   rax,rax,0x38
   58e58:	mov    rcx,QWORD PTR [rdi+0x78]
   58e5c:	movsxd rdx,DWORD PTR [rbp+0x4]
   58e60:	mov    r12,QWORD PTR [rcx+rdx*8]
   58e64:	movsxd rcx,DWORD PTR [rbp+0xc]
   58e68:	imul   rcx,rcx,0x38
   58e6c:	mov    rcx,QWORD PTR [rbx+rcx*1]
   58e70:	mov    QWORD PTR [rsp+0x218],rcx
   58e78:	cmp    BYTE PTR [rbp+0x1],0xfb
   58e7c:	je     58e88 <sqlite3VdbeExec+0x99e8>
   58e7e:	mov    QWORD PTR [rsp+0x188],r12
   58e86:	jmp    58ebc <sqlite3VdbeExec+0x9a1c>
   58e88:	cmp    QWORD PTR [r14+0x138],0x0
   58e90:	jne    58e9c <sqlite3VdbeExec+0x99fc>
   58e92:	mov    QWORD PTR [rsp+0x188],r12
   58e9a:	jmp    58ebc <sqlite3VdbeExec+0x9a1c>
   58e9c:	mov    rcx,QWORD PTR [r14+0x20]
   58ea0:	movsx  rdx,BYTE PTR [r12+0x1]
   58ea6:	shl    rdx,0x5
   58eaa:	mov    r13,QWORD PTR [rcx+rdx*1]
   58eae:	mov    QWORD PTR [rsp+0x188],r12
   58eb6:	mov    r12,QWORD PTR [rbp+0x10]
   58eba:	jmp    58ec2 <sqlite3VdbeExec+0x9a22>
   58ebc:	xor    r12d,r12d
   58ebf:	xor    r13d,r13d
   58ec2:	movzx  ecx,WORD PTR [rbp+0x2]
   58ec6:	and    ecx,0x1
   58ec9:	test   ecx,ecx
   58ecb:	je     58ef0 <sqlite3VdbeExec+0x9a50>
   58ecd:	mov    rcx,QWORD PTR [rdi+0x38]
   58ed1:	add    rcx,0x1
   58ed5:	mov    QWORD PTR [rdi+0x38],rcx
   58ed9:	movzx  ecx,WORD PTR [rbp+0x2]
   58edd:	and    ecx,0x20
   58ee0:	test   ecx,ecx
   58ee2:	je     58ef0 <sqlite3VdbeExec+0x9a50>
   58ee4:	mov    rcx,QWORD PTR [rsp+0x218]
   58eec:	mov    QWORD PTR [r14+0x38],rcx
   58ef0:	mov    rcx,QWORD PTR [rbx+rax*1+0x8]
   58ef5:	mov    QWORD PTR [rsp+0x220],rcx
   58efd:	mov    ecx,DWORD PTR [rbx+rax*1+0x10]
   58f01:	mov    DWORD PTR [rsp+0x234],ecx
   58f08:	movzx  ecx,WORD PTR [rbp+0x2]
   58f0c:	and    ecx,0x10
   58f0f:	test   ecx,ecx
   58f11:	je     58f29 <sqlite3VdbeExec+0x9a89>
   58f13:	mov    QWORD PTR [rsp+0x168],r13
   58f1b:	mov    r13,QWORD PTR [rsp+0x188]
   58f23:	mov    ecx,DWORD PTR [r13+0x1c]
   58f27:	jmp    58f3b <sqlite3VdbeExec+0x9a9b>
   58f29:	mov    QWORD PTR [rsp+0x168],r13
   58f31:	mov    r13,QWORD PTR [rsp+0x188]
   58f39:	xor    ecx,ecx
   58f3b:	movzx  edx,WORD PTR [rbx+rax*1+0x14]
   58f40:	and    edx,0x400
   58f46:	test   edx,edx
   58f48:	je     58f56 <sqlite3VdbeExec+0x9ab6>
   58f4a:	mov    eax,DWORD PTR [rbx+rax*1]
   58f4d:	mov    DWORD PTR [rsp+0x238],eax
   58f54:	jmp    58f61 <sqlite3VdbeExec+0x9ac1>
   58f56:	mov    DWORD PTR [rsp+0x238],0x0
   58f61:	mov    QWORD PTR [rsp+0x210],0x0
   58f6d:	mov    rax,QWORD PTR [r13+0x28]
   58f71:	mov    QWORD PTR [rsp+0x128],r14
   58f79:	lea    r14,[rsp+0x210]
   58f81:	mov    rdx,r14
   58f84:	movzx  esi,WORD PTR [rbp+0x2]
   58f88:	and    esi,0x8a
   58f8e:	mov    QWORD PTR [rsp+0x110],rdi
   58f96:	mov    rdi,rax
   58f99:	mov    r11,rsi
   58f9c:	mov    rsi,rdx
   58f9f:	mov    rdx,r11
   58fa2:	call   58fa7 <sqlite3VdbeExec+0x9b07>
   58fa7:	mov    r14d,eax
   58faa:	mov    BYTE PTR [r13+0x3],0x0
   58faf:	mov    DWORD PTR [r13+0x18],0x0
   58fb7:	mov    r13d,DWORD PTR [rsp+0x394]
   58fbf:	add    r13d,0x1
   58fc3:	mov    rdi,QWORD PTR [rsp+0x110]
   58fcb:	test   r14d,r14d
   58fce:	je     58ff8 <sqlite3VdbeExec+0x9b58>
   58fd0:	mov    QWORD PTR [rsp+0x148],rbp
   58fd8:	mov    rbp,r14
   58fdb:	mov    r14,QWORD PTR [rsp+0x128]
   58fe3:	mov    r13,QWORD PTR [rsp+0x130]
   58feb:	mov    rbx,QWORD PTR [rsp+0x158]
   58ff3:	jmp    4f712 <sqlite3VdbeExec+0x272>
   58ff8:	test   r12,r12
   58ffb:	jne    5900f <sqlite3VdbeExec+0x9b6f>
   58ffd:	mov    DWORD PTR [rsp+0x394],r13d
   59005:	mov    r13,QWORD PTR [rsp+0x128]
   5900d:	jmp    5907a <sqlite3VdbeExec+0x9bda>
   5900f:	mov    DWORD PTR [rsp+0x394],r13d
   59017:	mov    r13,QWORD PTR [rsp+0x128]
   5901f:	mov    rax,QWORD PTR [r13+0x138]
   59026:	mov    rcx,QWORD PTR [r13+0x130]
   5902d:	movzx  edx,WORD PTR [rbp+0x2]
   59031:	and    edx,0x4
   59034:	test   edx,edx
   59036:	je     5903f <sqlite3VdbeExec+0x9b9f>
   59038:	mov    edx,0x17
   5903d:	jmp    59044 <sqlite3VdbeExec+0x9ba4>
   5903f:	mov    edx,0x12
   59044:	mov    rsi,QWORD PTR [r12]
   59048:	mov    r8,QWORD PTR [rsp+0x218]
   59050:	mov    r12,QWORD PTR [rsp+0x168]
   59058:	mov    QWORD PTR [rsp+0x110],rdi
   59060:	mov    rdi,rcx
   59063:	mov    rcx,rsi
   59066:	mov    rsi,rdx
   59069:	mov    rdx,r12
   5906c:	mov    r10,rax
   5906f:	call   r10
   59072:	mov    rdi,QWORD PTR [rsp+0x110]
   5907a:	mov    DWORD PTR [rsp+0x37c],r15d
   59082:	mov    DWORD PTR [rsp+0x38c],r14d
   5908a:	mov    r14,r13
   5908d:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   59092:	mov    r15d,DWORD PTR [rsp+0x37c]
   5909a:	mov    r13,QWORD PTR [rsp+0x150]
   590a2:	mov    QWORD PTR [rsp+0x130],r12
   590aa:	mov    r12d,DWORD PTR [rsp+0x394]
   590b2:	mov    rax,QWORD PTR [rdi+0x78]
   590b6:	movsxd rcx,DWORD PTR [rbp+0x4]
   590ba:	mov    rax,QWORD PTR [rax+rcx*8]
   590be:	mov    rcx,QWORD PTR [rdi+0x78]
   590c2:	movsxd rdx,DWORD PTR [rbp+0x8]
   590c6:	mov    rcx,QWORD PTR [rcx+rdx*8]
   590ca:	cmp    DWORD PTR [rbp+0xc],0x0
   590ce:	je     590e6 <sqlite3VdbeExec+0x9c46>
   590d0:	movsxd rdx,DWORD PTR [rbp+0xc]
   590d4:	imul   rdx,rdx,0x38
   590d8:	mov    DWORD PTR [rsp+0x394],r12d
   590e0:	mov    r12,QWORD PTR [rbx+rdx*1]
   590e4:	jmp    590f1 <sqlite3VdbeExec+0x9c51>
   590e6:	mov    DWORD PTR [rsp+0x394],r12d
   590ee:	xor    r12d,r12d
   590f1:	mov    QWORD PTR [rsp+0x168],r12
   590f9:	mov    r12,QWORD PTR [rax+0x28]
   590fd:	mov    QWORD PTR [rsp+0x150],r13
   59105:	mov    r13,QWORD PTR [rcx+0x28]
   59109:	mov    QWORD PTR [rsp+0x188],r12
   59111:	mov    r12,QWORD PTR [r12+0x20]
   59116:	mov    QWORD PTR [rsp+0x170],r12
   5911e:	mov    r12,QWORD PTR [r12+0x88]
   59126:	mov    QWORD PTR [rsp+0x110],rdi
   5912e:	mov    rdi,r13
   59131:	call   59136 <sqlite3VdbeExec+0x9c96>
   59136:	mov    rdi,QWORD PTR [rsp+0x110]
   5913e:	cmp    DWORD PTR [r13+0x40],0x80
   59146:	jae    5916a <sqlite3VdbeExec+0x9cca>
   59148:	mov    DWORD PTR [rsp+0x37c],r15d
   59150:	lea    r15,[r12+0x1]
   59155:	mov    eax,DWORD PTR [r13+0x40]
   59159:	mov    BYTE PTR [r12],al
   5915d:	mov    r12,r15
   59160:	lea    r8,[rsp+0x384]
   59168:	jmp    591e2 <sqlite3VdbeExec+0x9d42>
   5916a:	mov    DWORD PTR [rsp+0x37c],r15d
   59172:	lea    r8,[rsp+0x384]
   5917a:	mov    eax,DWORD PTR [r13+0x40]
   5917e:	cmp    rax,0x7f
   59182:	ja     59193 <sqlite3VdbeExec+0x9cf3>
   59184:	and    rax,0x7f
   59188:	mov    BYTE PTR [r12],al
   5918c:	mov    eax,0x1
   59191:	jmp    591dc <sqlite3VdbeExec+0x9d3c>
   59193:	cmp    rax,0x3fff
   59199:	ja     591c1 <sqlite3VdbeExec+0x9d21>
   5919b:	mov    rcx,rax
   5919e:	shr    rcx,0x7
   591a2:	and    rcx,0x7f
   591a6:	or     rcx,0x80
   591ad:	mov    BYTE PTR [r12],cl
   591b1:	and    rax,0x7f
   591b5:	mov    BYTE PTR [r12+0x1],al
   591ba:	mov    eax,0x2
   591bf:	jmp    591dc <sqlite3VdbeExec+0x9d3c>
   591c1:	mov    rdi,r12
   591c4:	mov    rsi,rax
   591c7:	call   591cc <sqlite3VdbeExec+0x9d2c>
   591cc:	mov    rdi,QWORD PTR [rsp+0x110]
   591d4:	lea    r8,[rsp+0x384]
   591dc:	movsxd rax,eax
   591df:	add    r12,rax
   591e2:	mov    r15,QWORD PTR [rsp+0x188]
   591ea:	cmp    QWORD PTR [r15+0x80],0x0
   591f2:	jne    5926e <sqlite3VdbeExec+0x9dce>
   591f4:	mov    r15,QWORD PTR [rsp+0x168]
   591fc:	cmp    r15,0x7f
   59200:	ja     59214 <sqlite3VdbeExec+0x9d74>
   59202:	mov    rax,r15
   59205:	and    rax,0x7f
   59209:	mov    BYTE PTR [r12],al
   5920d:	mov    eax,0x1
   59212:	jmp    59268 <sqlite3VdbeExec+0x9dc8>
   59214:	cmp    r15,0x3fff
   5921b:	ja     59245 <sqlite3VdbeExec+0x9da5>
   5921d:	mov    rax,r15
   59220:	shr    rax,0x7
   59224:	and    rax,0x7f
   59228:	or     rax,0x80
   5922e:	mov    BYTE PTR [r12],al
   59232:	mov    rax,r15
   59235:	and    rax,0x7f
   59239:	mov    BYTE PTR [r12+0x1],al
   5923e:	mov    eax,0x2
   59243:	jmp    59268 <sqlite3VdbeExec+0x9dc8>
   59245:	mov    QWORD PTR [rsp+0x110],rdi
   5924d:	mov    rdi,r12
   59250:	mov    rsi,r15
   59253:	call   59258 <sqlite3VdbeExec+0x9db8>
   59258:	mov    rdi,QWORD PTR [rsp+0x110]
   59260:	lea    r8,[rsp+0x384]
   59268:	movsxd rax,eax
   5926b:	add    r12,rax
   5926e:	movzx  eax,WORD PTR [r13+0x44]
   59273:	mov    r15d,eax
   59276:	mov    QWORD PTR [rsp+0x160],rbx
   5927e:	mov    rbx,QWORD PTR [r13+0x38]
   59282:	mov    rax,r15
   59285:	add    rax,rbx
   59288:	mov    rcx,QWORD PTR [r13+0x88]
   5928f:	cmp    rax,QWORD PTR [rcx+0x58]
   59293:	jbe    592d1 <sqlite3VdbeExec+0x9e31>
   59295:	mov    eax,0x143bd
   5929a:	mov    ecx,0xb
   5929f:	lea    rdx,[rip+0x0]        # 592a6 <sqlite3VdbeExec+0x9e06>
   592a6:	mov    QWORD PTR [rsp+0x110],rdi
   592ae:	mov    rdi,rcx
   592b1:	mov    rsi,rax
   592b4:	call   592b9 <sqlite3VdbeExec+0x9e19>
   592b9:	mov    ebx,eax
   592bb:	mov    rdi,QWORD PTR [rsp+0x110]
   592c3:	mov    r11,rbx
   592c6:	mov    rbx,rbp
   592c9:	mov    rbp,r11
   592cc:	jmp    59ba7 <sqlite3VdbeExec+0xa707>
   592d1:	mov    QWORD PTR [rsp+0x128],r14
   592d9:	mov    r14d,DWORD PTR [r13+0x40]
   592dd:	cmp    r15d,r14d
   592e0:	je     59307 <sqlite3VdbeExec+0x9e67>
   592e2:	mov    QWORD PTR [rsp+0x168],rbx
   592ea:	mov    rbx,QWORD PTR [rsp+0x170]
   592f2:	mov    QWORD PTR [rsp+0x148],rbp
   592fa:	mov    rbp,QWORD PTR [rsp+0x188]
   59302:	jmp    5938c <sqlite3VdbeExec+0x9eec>
   59307:	mov    QWORD PTR [rsp+0x148],rbp
   5930f:	mov    rbp,QWORD PTR [rsp+0x188]
   59317:	mov    rax,QWORD PTR [rbp+0x88]
   5931e:	movzx  eax,WORD PTR [rax+0xe]
   59322:	cmp    r15d,eax
   59325:	jb     59339 <sqlite3VdbeExec+0x9e99>
   59327:	mov    QWORD PTR [rsp+0x168],rbx
   5932f:	mov    rbx,QWORD PTR [rsp+0x170]
   59337:	jmp    5938c <sqlite3VdbeExec+0x9eec>
   59339:	mov    rax,r15
   5933c:	mov    QWORD PTR [rsp+0x110],rdi
   59344:	mov    rdi,r12
   59347:	mov    rsi,rbx
   5934a:	mov    rdx,rax
   5934d:	call   59352 <sqlite3VdbeExec+0x9eb2>
   59352:	mov    rbx,QWORD PTR [rsp+0x170]
   5935a:	mov    rax,r12
   5935d:	sub    rax,QWORD PTR [rbx+0x88]
   59364:	add    eax,r15d
   59367:	mov    DWORD PTR [rbx+0x90],eax
   5936d:	xor    ebp,ebp
   5936f:	mov    rdi,QWORD PTR [rsp+0x110]
   59377:	mov    r14,QWORD PTR [rsp+0x128]
   5937f:	mov    rbx,QWORD PTR [rsp+0x148]
   59387:	jmp    59ba7 <sqlite3VdbeExec+0xa707>
   5938c:	mov    DWORD PTR [r8],0x0
   59393:	mov    rax,QWORD PTR [r13+0x20]
   59397:	mov    DWORD PTR [rsp+0x398],r14d
   5939f:	mov    r14,QWORD PTR [rax]
   593a2:	mov    QWORD PTR [rsp+0x180],r14
   593aa:	lea    r14,[rsp+0x138]
   593b2:	mov    QWORD PTR [r14],0x0
   593b9:	xor    r14d,r14d
   593bc:	mov    rax,QWORD PTR [rbp+0x88]
   593c3:	mov    ecx,DWORD PTR [r13+0x40]
   593c7:	mov    rdx,rcx
   593ca:	movzx  esi,WORD PTR [rax+0xe]
   593ce:	mov    r9,rsi
   593d1:	cmp    rdx,r9
   593d4:	jg     593da <sqlite3VdbeExec+0x9f3a>
   593d6:	mov    ebp,ecx
   593d8:	jmp    59406 <sqlite3VdbeExec+0x9f66>
   593da:	movzx  ecx,WORD PTR [rax+0x10]
   593de:	mov    r9,rcx
   593e1:	sub    rdx,r9
   593e4:	mov    rax,QWORD PTR [rax+0x48]
   593e8:	mov    eax,DWORD PTR [rax+0x38]
   593eb:	sub    eax,0x4
   593ee:	mov    r10,rax
   593f1:	mov    rax,rdx
   593f4:	cqo
   593f6:	idiv   r10
   593f9:	mov    rax,rdx
   593fc:	add    rax,r9
   593ff:	cmp    eax,esi
   59401:	mov    ebp,ecx
   59403:	cmovle ebp,eax
   59406:	mov    rax,r12
   59409:	sub    rax,QWORD PTR [rbx+0x88]
   59410:	add    eax,ebp
   59412:	mov    DWORD PTR [rbx+0x90],eax
   59418:	cmp    ebp,DWORD PTR [r13+0x40]
   5941c:	jb     59433 <sqlite3VdbeExec+0x9f93>
   5941e:	mov    r14d,DWORD PTR [rsp+0x398]
   59426:	xor    r11d,r11d
   59429:	mov    QWORD PTR [rsp+0x188],r11
   59431:	jmp    59458 <sqlite3VdbeExec+0x9fb8>
   59433:	mov    eax,ebp
   59435:	lea    r14,[r12+rax*1]
   59439:	mov    eax,DWORD PTR [rbx+0x90]
   5943f:	add    eax,0x4
   59442:	mov    DWORD PTR [rbx+0x90],eax
   59448:	mov    QWORD PTR [rsp+0x188],r14
   59450:	mov    r14d,DWORD PTR [rsp+0x398]
   59458:	cmp    r14d,r15d
   5945b:	ja     59478 <sqlite3VdbeExec+0x9fd8>
   5945d:	xor    r11d,r11d
   59460:	mov    DWORD PTR [rsp+0x3a8],r11d
   59468:	xor    r11d,r11d
   5946b:	mov    QWORD PTR [rsp+0x190],r11
   59473:	jmp    5953d <sqlite3VdbeExec+0xa09d>
   59478:	mov    rax,r15
   5947b:	mov    DWORD PTR [rsp+0x39c],ebp
   59482:	mov    rbp,QWORD PTR [rsp+0x168]
   5948a:	lea    rax,[rbp+rax*1+0x4]
   5948f:	mov    rcx,QWORD PTR [r13+0x88]
   59496:	cmp    rax,QWORD PTR [rcx+0x58]
   5949a:	jbe    594df <sqlite3VdbeExec+0xa03f>
   5949c:	mov    eax,0x143d6
   594a1:	mov    ecx,0xb
   594a6:	lea    rdx,[rip+0x0]        # 594ad <sqlite3VdbeExec+0xa00d>
   594ad:	mov    QWORD PTR [rsp+0x110],rdi
   594b5:	mov    rdi,rcx
   594b8:	mov    rsi,rax
   594bb:	call   594c0 <sqlite3VdbeExec+0xa020>
   594c0:	mov    ebp,eax
   594c2:	mov    rdi,QWORD PTR [rsp+0x110]
   594ca:	mov    r14,QWORD PTR [rsp+0x128]
   594d2:	mov    rbx,QWORD PTR [rsp+0x148]
   594da:	jmp    59ba7 <sqlite3VdbeExec+0xa707>
   594df:	mov    rax,QWORD PTR [r13+0x38]
   594e3:	mov    rcx,r15
   594e6:	movzx  edx,BYTE PTR [rax+rcx*1]
   594ea:	shl    edx,0x18
   594ed:	movzx  esi,BYTE PTR [rax+rcx*1+0x1]
   594f2:	shl    esi,0x10
   594f5:	or     edx,esi
   594f7:	movzx  esi,BYTE PTR [rax+rcx*1+0x2]
   594fc:	shl    esi,0x8
   594ff:	or     edx,esi
   59501:	movzx  eax,BYTE PTR [rax+rcx*1+0x3]
   59506:	or     edx,eax
   59508:	mov    DWORD PTR [rsp+0x398],r14d
   59510:	mov    r14d,edx
   59513:	mov    QWORD PTR [rsp+0x168],rbp
   5951b:	mov    DWORD PTR [rsp+0x3a8],r14d
   59523:	mov    r14d,DWORD PTR [rsp+0x398]
   5952b:	mov    ebp,DWORD PTR [rsp+0x39c]
   59532:	xor    r11d,r11d
   59535:	mov    QWORD PTR [rsp+0x190],r11
   5953d:	sub    r14d,ebp
   59540:	mov    DWORD PTR [rsp+0x39c],r14d
   59548:	mov    r14,QWORD PTR [rsp+0x168]
   59550:	test   r15d,r15d
   59553:	ja     59567 <sqlite3VdbeExec+0xa0c7>
   59555:	mov    QWORD PTR [rsp+0x178],r13
   5955d:	mov    QWORD PTR [rsp+0x170],rbx
   59565:	jmp    595b8 <sqlite3VdbeExec+0xa118>
   59567:	mov    QWORD PTR [rsp+0x170],rbx
   5956f:	cmp    ebp,r15d
   59572:	mov    ebx,r15d
   59575:	cmovb  ebx,ebp
   59578:	mov    QWORD PTR [rsp+0x178],r13
   59580:	movsxd r13,ebx
   59583:	mov    QWORD PTR [rsp+0x110],rdi
   5958b:	mov    rdi,r12
   5958e:	mov    rsi,r14
   59591:	mov    rdx,r13
   59594:	call   59599 <sqlite3VdbeExec+0xa0f9>
   59599:	sub    ebp,ebx
   5959b:	sub    r15d,ebx
   5959e:	add    r12,r13
   595a1:	lea    rbx,[r14+r13*1]
   595a5:	mov    rdi,QWORD PTR [rsp+0x110]
   595ad:	mov    r14,rbx
   595b0:	lea    r8,[rsp+0x384]
   595b8:	test   ebp,ebp
   595ba:	jbe    59754 <sqlite3VdbeExec+0xa2b4>
   595c0:	lea    rbx,[rsp+0x138]
   595c8:	mov    rax,QWORD PTR [rbx]
   595cb:	test   rax,rax
   595ce:	jne    595dd <sqlite3VdbeExec+0xa13d>
   595d0:	mov    r13,QWORD PTR [rsp+0x178]
   595d8:	jmp    59673 <sqlite3VdbeExec+0xa1d3>
   595dd:	movzx  ecx,WORD PTR [rax+0x34]
   595e1:	and    ecx,0x20
   595e4:	test   ecx,ecx
   595e6:	je     59653 <sqlite3VdbeExec+0xa1b3>
   595e8:	mov    rcx,QWORD PTR [rax+0x28]
   595ec:	mov    edx,DWORD PTR [rcx+0x98]
   595f2:	sub    edx,0x1
   595f5:	mov    DWORD PTR [rcx+0x98],edx
   595fb:	mov    rdx,QWORD PTR [rcx+0xa8]
   59602:	mov    QWORD PTR [rax+0x20],rdx
   59606:	mov    QWORD PTR [rcx+0xa8],rax
   5960d:	mov    rdx,QWORD PTR [rcx+0x48]
   59611:	mov    esi,DWORD PTR [rax+0x30]
   59614:	sub    esi,0x1
   59617:	imul   rsi,QWORD PTR [rcx+0xc8]
   5961f:	mov    rax,QWORD PTR [rax+0x8]
   59623:	mov    rcx,QWORD PTR [rdx]
   59626:	mov    rcx,QWORD PTR [rcx+0x90]
   5962d:	mov    QWORD PTR [rsp+0x110],rdi
   59635:	mov    rdi,rdx
   59638:	mov    rdx,rax
   5963b:	mov    r10,rcx
   5963e:	call   r10
   59641:	mov    rdi,QWORD PTR [rsp+0x110]
   59649:	mov    r13,QWORD PTR [rsp+0x178]
   59651:	jmp    59673 <sqlite3VdbeExec+0xa1d3>
   59653:	mov    r13,QWORD PTR [rsp+0x178]
   5965b:	mov    QWORD PTR [rsp+0x110],rdi
   59663:	mov    rdi,rax
   59666:	call   5966b <sqlite3VdbeExec+0xa1cb>
   5966b:	mov    rdi,QWORD PTR [rsp+0x110]
   59673:	mov    QWORD PTR [rbx],0x0
   5967a:	mov    rax,rbx
   5967d:	mov    ecx,0x2
   59682:	mov    rbx,QWORD PTR [rsp+0x180]
   5968a:	mov    rdx,QWORD PTR [rbx+0x110]
   59691:	mov    QWORD PTR [rsp+0x198],r12
   59699:	mov    r12d,DWORD PTR [rsp+0x3a8]
   596a1:	mov    QWORD PTR [rsp+0x110],rdi
   596a9:	mov    rdi,rbx
   596ac:	mov    rsi,r12
   596af:	mov    r10,rdx
   596b2:	mov    rdx,rax
   596b5:	call   r10
   596b8:	lea    r8,[rsp+0x384]
   596c0:	mov    DWORD PTR [r8],eax
   596c3:	mov    rdi,QWORD PTR [rsp+0x110]
   596cb:	cmp    DWORD PTR [r8],0x0
   596cf:	je     596eb <sqlite3VdbeExec+0xa24b>
   596d1:	mov    QWORD PTR [rsp+0x178],r13
   596d9:	mov    DWORD PTR [rsp+0x3a8],r12d
   596e1:	mov    r12,QWORD PTR [rsp+0x198]
   596e9:	jmp    59754 <sqlite3VdbeExec+0xa2b4>
   596eb:	lea    r12,[rsp+0x138]
   596f3:	mov    rax,QWORD PTR [r12]
   596f7:	mov    rax,QWORD PTR [rax+0x8]
   596fb:	movzx  ecx,BYTE PTR [rax]
   596fe:	shl    ecx,0x18
   59701:	movzx  edx,BYTE PTR [rax+0x1]
   59705:	shl    edx,0x10
   59708:	or     ecx,edx
   5970a:	movzx  edx,BYTE PTR [rax+0x2]
   5970e:	shl    edx,0x8
   59711:	or     ecx,edx
   59713:	movzx  edx,BYTE PTR [rax+0x3]
   59717:	or     ecx,edx
   59719:	mov    r14d,ecx
   5971c:	lea    r15,[rax+0x4]
   59720:	mov    rax,QWORD PTR [r13+0x20]
   59724:	mov    eax,DWORD PTR [rax+0x38]
   59727:	mov    r12d,eax
   5972a:	sub    r12d,0x4
   5972e:	mov    QWORD PTR [rsp+0x178],r13
   59736:	mov    QWORD PTR [rsp+0x180],rbx
   5973e:	mov    DWORD PTR [rsp+0x3a8],r14d
   59746:	mov    r14,r15
   59749:	mov    r15,r12
   5974c:	mov    r12,QWORD PTR [rsp+0x198]
   59754:	cmp    DWORD PTR [r8],0x0
   59758:	jne    59773 <sqlite3VdbeExec+0xa2d3>
   5975a:	test   ebp,ebp
   5975c:	jbe    59773 <sqlite3VdbeExec+0xa2d3>
   5975e:	mov    r13,QWORD PTR [rsp+0x178]
   59766:	mov    rbx,QWORD PTR [rsp+0x170]
   5976e:	jmp    59550 <sqlite3VdbeExec+0xa0b0>
   59773:	cmp    DWORD PTR [r8],0x0
   59777:	je     59796 <sqlite3VdbeExec+0xa2f6>
   59779:	mov    r13,QWORD PTR [rsp+0x170]
   59781:	mov    QWORD PTR [rsp+0x198],r12
   59789:	mov    rbx,QWORD PTR [rsp+0x190]
   59791:	jmp    59a21 <sqlite3VdbeExec+0xa581>
   59796:	mov    r13d,DWORD PTR [rsp+0x39c]
   5979e:	test   r13d,r13d
   597a1:	ja     597c0 <sqlite3VdbeExec+0xa320>
   597a3:	mov    r13,QWORD PTR [rsp+0x170]
   597ab:	mov    QWORD PTR [rsp+0x198],r12
   597b3:	mov    rbx,QWORD PTR [rsp+0x190]
   597bb:	jmp    59a21 <sqlite3VdbeExec+0xa581>
   597c0:	mov    rbx,QWORD PTR [rsp+0x188]
   597c8:	test   rbx,rbx
   597cb:	jne    597fa <sqlite3VdbeExec+0xa35a>
   597cd:	mov    DWORD PTR [rsp+0x39c],r13d
   597d5:	mov    r13,QWORD PTR [rsp+0x170]
   597dd:	mov    QWORD PTR [rsp+0x198],r12
   597e5:	mov    QWORD PTR [rsp+0x188],rbx
   597ed:	mov    rbx,QWORD PTR [rsp+0x190]
   597f5:	jmp    59a21 <sqlite3VdbeExec+0xa581>
   597fa:	lea    r13,[rsp+0x3a0]
   59802:	mov    DWORD PTR [r13+0x0],0x0
   5980a:	lea    r13,[rsp+0x1a0]
   59812:	mov    QWORD PTR [r13+0x0],0x0
   5981a:	mov    rax,r13
   5981d:	lea    r13,[rsp+0x3a0]
   59825:	mov    rcx,r13
   59828:	xor    edx,edx
   5982a:	xor    esi,esi
   5982c:	mov    r13,QWORD PTR [rsp+0x170]
   59834:	mov    QWORD PTR [rsp+0x110],rdi
   5983c:	mov    rdi,r13
   5983f:	mov    r8,rsi
   59842:	mov    rsi,rax
   59845:	mov    r11,rdx
   59848:	mov    rdx,rcx
   5984b:	mov    rcx,r11
   5984e:	call   59853 <sqlite3VdbeExec+0xa3b3>
   59853:	lea    r8,[rsp+0x384]
   5985b:	mov    DWORD PTR [r8],eax
   5985e:	mov    QWORD PTR [rsp+0x198],r12
   59866:	lea    r12,[rsp+0x3a0]
   5986e:	mov    eax,DWORD PTR [r12]
   59872:	mov    ecx,eax
   59874:	shr    ecx,0x18
   59877:	mov    BYTE PTR [rbx],cl
   59879:	mov    ecx,eax
   5987b:	shr    ecx,0x10
   5987e:	mov    BYTE PTR [rbx+0x1],cl
   59881:	mov    ecx,eax
   59883:	shr    ecx,0x8
   59886:	mov    BYTE PTR [rbx+0x2],cl
   59889:	mov    BYTE PTR [rbx+0x3],al
   5988c:	mov    rdi,QWORD PTR [rsp+0x110]
   59894:	cmp    BYTE PTR [r13+0x21],0x0
   59899:	jne    598ad <sqlite3VdbeExec+0xa40d>
   5989b:	mov    QWORD PTR [rsp+0x188],rbx
   598a3:	mov    rbx,QWORD PTR [rsp+0x190]
   598ab:	jmp    598e2 <sqlite3VdbeExec+0xa442>
   598ad:	mov    rbx,QWORD PTR [rsp+0x190]
   598b5:	test   rbx,rbx
   598b8:	je     598e2 <sqlite3VdbeExec+0xa442>
   598ba:	mov    eax,DWORD PTR [r12]
   598be:	mov    ecx,DWORD PTR [rbx+0x4]
   598c1:	mov    rdx,r8
   598c4:	mov    esi,0x4
   598c9:	mov    rdi,r13
   598cc:	mov    r8,rdx
   598cf:	mov    rdx,rsi
   598d2:	mov    rsi,rax
   598d5:	call   598da <sqlite3VdbeExec+0xa43a>
   598da:	mov    rdi,QWORD PTR [rsp+0x110]
   598e2:	test   rbx,rbx
   598e5:	je     59975 <sqlite3VdbeExec+0xa4d5>
   598eb:	mov    rax,QWORD PTR [rbx+0x70]
   598ef:	movzx  ecx,WORD PTR [rax+0x34]
   598f3:	and    ecx,0x20
   598f6:	test   ecx,ecx
   598f8:	je     5995d <sqlite3VdbeExec+0xa4bd>
   598fa:	mov    rcx,QWORD PTR [rax+0x28]
   598fe:	mov    edx,DWORD PTR [rcx+0x98]
   59904:	sub    edx,0x1
   59907:	mov    DWORD PTR [rcx+0x98],edx
   5990d:	mov    rdx,QWORD PTR [rcx+0xa8]
   59914:	mov    QWORD PTR [rax+0x20],rdx
   59918:	mov    QWORD PTR [rcx+0xa8],rax
   5991f:	mov    rdx,QWORD PTR [rcx+0x48]
   59923:	mov    esi,DWORD PTR [rax+0x30]
   59926:	sub    esi,0x1
   59929:	imul   rsi,QWORD PTR [rcx+0xc8]
   59931:	mov    rax,QWORD PTR [rax+0x8]
   59935:	mov    rcx,QWORD PTR [rdx]
   59938:	mov    rcx,QWORD PTR [rcx+0x90]
   5993f:	mov    QWORD PTR [rsp+0x110],rdi
   59947:	mov    rdi,rdx
   5994a:	mov    rdx,rax
   5994d:	mov    r10,rcx
   59950:	call   r10
   59953:	mov    rdi,QWORD PTR [rsp+0x110]
   5995b:	jmp    59975 <sqlite3VdbeExec+0xa4d5>
   5995d:	mov    QWORD PTR [rsp+0x110],rdi
   59965:	mov    rdi,rax
   59968:	call   5996d <sqlite3VdbeExec+0xa4cd>
   5996d:	mov    rdi,QWORD PTR [rsp+0x110]
   59975:	lea    rbx,[rsp+0x1a0]
   5997d:	mov    rbx,QWORD PTR [rbx]
   59980:	test   rbx,rbx
   59983:	jne    59992 <sqlite3VdbeExec+0xa4f2>
   59985:	lea    r8,[rsp+0x384]
   5998d:	jmp    59a21 <sqlite3VdbeExec+0xa581>
   59992:	mov    rbp,QWORD PTR [rbx+0x50]
   59996:	mov    BYTE PTR [rbp+0x0],0x0
   5999a:	mov    BYTE PTR [rbp+0x1],0x0
   5999e:	mov    BYTE PTR [rbp+0x2],0x0
   599a2:	mov    BYTE PTR [rbp+0x3],0x0
   599a6:	lea    r12,[rbp+0x4]
   599aa:	mov    eax,DWORD PTR [r13+0x38]
   599ae:	sub    eax,0x4
   599b1:	mov    QWORD PTR [rsp+0x168],r14
   599b9:	mov    r14d,DWORD PTR [rsp+0x39c]
   599c1:	cmp    eax,r14d
   599c4:	jae    599e3 <sqlite3VdbeExec+0xa543>
   599c6:	mov    eax,DWORD PTR [r13+0x38]
   599ca:	mov    DWORD PTR [rsp+0x398],r15d
   599d2:	mov    r15d,eax
   599d5:	sub    r15d,0x4
   599d9:	lea    r8,[rsp+0x384]
   599e1:	jmp    599f6 <sqlite3VdbeExec+0xa556>
   599e3:	mov    DWORD PTR [rsp+0x398],r15d
   599eb:	mov    r15,r14
   599ee:	lea    r8,[rsp+0x384]
   599f6:	mov    DWORD PTR [rsp+0x39c],r14d
   599fe:	mov    r14,QWORD PTR [rsp+0x168]
   59a06:	mov    QWORD PTR [rsp+0x198],r12
   59a0e:	mov    QWORD PTR [rsp+0x188],rbp
   59a16:	mov    rbp,r15
   59a19:	mov    r15d,DWORD PTR [rsp+0x398]
   59a21:	mov    r12d,DWORD PTR [rsp+0x39c]
   59a29:	test   r12d,r12d
   59a2c:	jbe    59a5f <sqlite3VdbeExec+0xa5bf>
   59a2e:	cmp    DWORD PTR [r8],0x0
   59a32:	jne    59a5f <sqlite3VdbeExec+0xa5bf>
   59a34:	mov    QWORD PTR [rsp+0x168],r14
   59a3c:	mov    r14,r12
   59a3f:	mov    r12,QWORD PTR [rsp+0x198]
   59a47:	mov    QWORD PTR [rsp+0x190],rbx
   59a4f:	mov    rbx,r13
   59a52:	mov    r13,QWORD PTR [rsp+0x178]
   59a5a:	jmp    5953d <sqlite3VdbeExec+0xa09d>
   59a5f:	test   rbx,rbx
   59a62:	je     59af2 <sqlite3VdbeExec+0xa652>
   59a68:	mov    rax,QWORD PTR [rbx+0x70]
   59a6c:	movzx  ecx,WORD PTR [rax+0x34]
   59a70:	and    ecx,0x20
   59a73:	test   ecx,ecx
   59a75:	je     59ada <sqlite3VdbeExec+0xa63a>
   59a77:	mov    rcx,QWORD PTR [rax+0x28]
   59a7b:	mov    edx,DWORD PTR [rcx+0x98]
   59a81:	sub    edx,0x1
   59a84:	mov    DWORD PTR [rcx+0x98],edx
   59a8a:	mov    rdx,QWORD PTR [rcx+0xa8]
   59a91:	mov    QWORD PTR [rax+0x20],rdx
   59a95:	mov    QWORD PTR [rcx+0xa8],rax
   59a9c:	mov    rdx,QWORD PTR [rcx+0x48]
   59aa0:	mov    esi,DWORD PTR [rax+0x30]
   59aa3:	sub    esi,0x1
   59aa6:	imul   rsi,QWORD PTR [rcx+0xc8]
   59aae:	mov    rax,QWORD PTR [rax+0x8]
   59ab2:	mov    rcx,QWORD PTR [rdx]
   59ab5:	mov    rcx,QWORD PTR [rcx+0x90]
   59abc:	mov    QWORD PTR [rsp+0x110],rdi
   59ac4:	mov    rdi,rdx
   59ac7:	mov    rdx,rax
   59aca:	mov    r10,rcx
   59acd:	call   r10
   59ad0:	mov    rdi,QWORD PTR [rsp+0x110]
   59ad8:	jmp    59af2 <sqlite3VdbeExec+0xa652>
   59ada:	mov    QWORD PTR [rsp+0x110],rdi
   59ae2:	mov    rdi,rax
   59ae5:	call   59aea <sqlite3VdbeExec+0xa64a>
   59aea:	mov    rdi,QWORD PTR [rsp+0x110]
   59af2:	lea    r14,[rsp+0x138]
   59afa:	mov    rax,QWORD PTR [r14]
   59afd:	test   rax,rax
   59b00:	je     59b8c <sqlite3VdbeExec+0xa6ec>
   59b06:	movzx  ecx,WORD PTR [rax+0x34]
   59b0a:	and    ecx,0x20
   59b0d:	test   ecx,ecx
   59b0f:	je     59b74 <sqlite3VdbeExec+0xa6d4>
   59b11:	mov    rcx,QWORD PTR [rax+0x28]
   59b15:	mov    edx,DWORD PTR [rcx+0x98]
   59b1b:	sub    edx,0x1
   59b1e:	mov    DWORD PTR [rcx+0x98],edx
   59b24:	mov    rdx,QWORD PTR [rcx+0xa8]
   59b2b:	mov    QWORD PTR [rax+0x20],rdx
   59b2f:	mov    QWORD PTR [rcx+0xa8],rax
   59b36:	mov    rdx,QWORD PTR [rcx+0x48]
   59b3a:	mov    esi,DWORD PTR [rax+0x30]
   59b3d:	sub    esi,0x1
   59b40:	imul   rsi,QWORD PTR [rcx+0xc8]
   59b48:	mov    rax,QWORD PTR [rax+0x8]
   59b4c:	mov    rcx,QWORD PTR [rdx]
   59b4f:	mov    rcx,QWORD PTR [rcx+0x90]
   59b56:	mov    QWORD PTR [rsp+0x110],rdi
   59b5e:	mov    rdi,rdx
   59b61:	mov    rdx,rax
   59b64:	mov    r10,rcx
   59b67:	call   r10
   59b6a:	mov    rdi,QWORD PTR [rsp+0x110]
   59b72:	jmp    59b8c <sqlite3VdbeExec+0xa6ec>
   59b74:	mov    QWORD PTR [rsp+0x110],rdi
   59b7c:	mov    rdi,rax
   59b7f:	call   59b84 <sqlite3VdbeExec+0xa6e4>
   59b84:	mov    rdi,QWORD PTR [rsp+0x110]
   59b8c:	lea    r8,[rsp+0x384]
   59b94:	mov    ebp,DWORD PTR [r8]
   59b97:	mov    r14,QWORD PTR [rsp+0x128]
   59b9f:	mov    rbx,QWORD PTR [rsp+0x148]
   59ba7:	test   ebp,ebp
   59ba9:	je     59bc8 <sqlite3VdbeExec+0xa728>
   59bab:	mov    QWORD PTR [rsp+0x148],rbx
   59bb3:	mov    r13,QWORD PTR [rsp+0x130]
   59bbb:	mov    rbx,QWORD PTR [rsp+0x158]
   59bc3:	jmp    4f712 <sqlite3VdbeExec+0x272>
   59bc8:	mov    DWORD PTR [rsp+0x38c],ebp
   59bcf:	mov    rbp,rbx
   59bd2:	mov    rbx,QWORD PTR [rsp+0x160]
   59bda:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   59bdf:	mov    QWORD PTR [rsp+0x160],rbx
   59be7:	mov    rbx,rbp
   59bea:	mov    QWORD PTR [rsp+0x130],r12
   59bf2:	mov    ebp,DWORD PTR [rbx+0x8]
   59bf5:	mov    rax,QWORD PTR [rdi+0x78]
   59bf9:	movsxd rcx,DWORD PTR [rbx+0x4]
   59bfd:	mov    r12,QWORD PTR [rax+rcx*8]
   59c01:	cmp    BYTE PTR [rbx+0x1],0xfb
   59c05:	je     59c13 <sqlite3VdbeExec+0xa773>
   59c07:	mov    DWORD PTR [rsp+0x398],ebp
   59c0e:	jmp    59c96 <sqlite3VdbeExec+0xa7f6>
   59c13:	cmp    QWORD PTR [r14+0x138],0x0
   59c1b:	jne    59c26 <sqlite3VdbeExec+0xa786>
   59c1d:	mov    DWORD PTR [rsp+0x398],ebp
   59c24:	jmp    59c96 <sqlite3VdbeExec+0xa7f6>
   59c26:	mov    rax,QWORD PTR [r14+0x20]
   59c2a:	movsx  rcx,BYTE PTR [r12+0x1]
   59c30:	shl    rcx,0x5
   59c34:	mov    r13,QWORD PTR [rax+rcx*1]
   59c38:	mov    r15,QWORD PTR [rbx+0x10]
   59c3c:	movzx  eax,WORD PTR [rbx+0x2]
   59c40:	and    eax,0x2
   59c43:	test   eax,eax
   59c45:	jne    59c50 <sqlite3VdbeExec+0xa7b0>
   59c47:	mov    DWORD PTR [rsp+0x398],ebp
   59c4e:	jmp    59c8e <sqlite3VdbeExec+0xa7ee>
   59c50:	cmp    BYTE PTR [r12+0x4],0x0
   59c56:	jne    59c61 <sqlite3VdbeExec+0xa7c1>
   59c58:	mov    DWORD PTR [rsp+0x398],ebp
   59c5f:	jmp    59c8e <sqlite3VdbeExec+0xa7ee>
   59c61:	mov    DWORD PTR [rsp+0x398],ebp
   59c68:	mov    rbp,QWORD PTR [r12+0x28]
   59c6d:	mov    QWORD PTR [rsp+0x110],rdi
   59c75:	mov    rdi,rbp
   59c78:	call   59c7d <sqlite3VdbeExec+0xa7dd>
   59c7d:	mov    rax,QWORD PTR [rbp+0x30]
   59c81:	mov    QWORD PTR [r12+0x48],rax
   59c86:	mov    rdi,QWORD PTR [rsp+0x110]
   59c8e:	mov    rbp,r13
   59c91:	mov    r13,r15
   59c94:	jmp    59c9b <sqlite3VdbeExec+0xa7fb>
   59c96:	xor    ebp,ebp
   59c98:	xor    r13d,r13d
   59c9b:	mov    rax,QWORD PTR [r12+0x28]
   59ca0:	movzx  ecx,WORD PTR [rbx+0x2]
   59ca4:	movzx  ecx,cl
   59ca7:	mov    QWORD PTR [rsp+0x110],rdi
   59caf:	mov    rdi,rax
   59cb2:	mov    rsi,rcx
   59cb5:	call   59cba <sqlite3VdbeExec+0xa81a>
   59cba:	mov    r15d,eax
   59cbd:	mov    DWORD PTR [r12+0x18],0x0
   59cc6:	mov    QWORD PTR [rsp+0x128],r14
   59cce:	mov    r14d,DWORD PTR [rsp+0x394]
   59cd6:	add    r14d,0x1
   59cda:	mov    DWORD PTR [r12+0x1c],0x0
   59ce3:	mov    rdi,QWORD PTR [rsp+0x110]
   59ceb:	test   r15d,r15d
   59cee:	je     59d18 <sqlite3VdbeExec+0xa878>
   59cf0:	mov    r14,QWORD PTR [rsp+0x128]
   59cf8:	mov    QWORD PTR [rsp+0x148],rbx
   59d00:	mov    rbp,r15
   59d03:	mov    r13,QWORD PTR [rsp+0x130]
   59d0b:	mov    rbx,QWORD PTR [rsp+0x158]
   59d13:	jmp    4f712 <sqlite3VdbeExec+0x272>
   59d18:	mov    DWORD PTR [rsp+0x394],r14d
   59d20:	mov    r14d,DWORD PTR [rsp+0x398]
   59d28:	mov    eax,r14d
   59d2b:	and    eax,0x1
   59d2e:	test   eax,eax
   59d30:	jne    59d3c <sqlite3VdbeExec+0xa89c>
   59d32:	mov    r14,QWORD PTR [rsp+0x128]
   59d3a:	jmp    59da2 <sqlite3VdbeExec+0xa902>
   59d3c:	mov    rax,QWORD PTR [rdi+0x38]
   59d40:	add    rax,0x1
   59d44:	mov    QWORD PTR [rdi+0x38],rax
   59d48:	mov    r14,QWORD PTR [rsp+0x128]
   59d50:	cmp    QWORD PTR [r14+0x138],0x0
   59d58:	je     59da2 <sqlite3VdbeExec+0xa902>
   59d5a:	test   r13,r13
   59d5d:	je     59da2 <sqlite3VdbeExec+0xa902>
   59d5f:	mov    eax,DWORD PTR [r13+0x30]
   59d63:	and    eax,0x80
   59d68:	test   eax,eax
   59d6a:	jne    59da2 <sqlite3VdbeExec+0xa902>
   59d6c:	mov    rax,QWORD PTR [r14+0x138]
   59d73:	mov    rcx,QWORD PTR [r14+0x130]
   59d7a:	mov    edx,0x9
   59d7f:	mov    rsi,QWORD PTR [r13+0x0]
   59d83:	mov    r8,QWORD PTR [r12+0x48]
   59d88:	mov    rdi,rcx
   59d8b:	mov    rcx,rsi
   59d8e:	mov    rsi,rdx
   59d91:	mov    rdx,rbp
   59d94:	mov    r10,rax
   59d97:	call   r10
   59d9a:	mov    rdi,QWORD PTR [rsp+0x110]
   59da2:	mov    rbp,rbx
   59da5:	mov    DWORD PTR [rsp+0x38c],r15d
   59dad:	mov    rbx,QWORD PTR [rsp+0x160]
   59db5:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   59dba:	mov    r15d,DWORD PTR [rsp+0x37c]
   59dc2:	mov    r13,QWORD PTR [rsp+0x150]
   59dca:	mov    QWORD PTR [rsp+0x130],r12
   59dd2:	mov    r12d,DWORD PTR [rsp+0x394]
   59dda:	mov    rax,QWORD PTR [rdi+0x38]
   59dde:	mov    QWORD PTR [r14+0x78],rax
   59de2:	mov    rcx,QWORD PTR [r14+0x80]
   59de9:	add    rax,rcx
   59dec:	mov    QWORD PTR [r14+0x80],rax
   59df3:	mov    QWORD PTR [rdi+0x38],0x0
   59dfb:	mov    DWORD PTR [rsp+0x37c],r15d
   59e03:	mov    QWORD PTR [rsp+0x150],r13
   59e0b:	mov    DWORD PTR [rsp+0x394],r12d
   59e13:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   59e18:	mov    r15d,DWORD PTR [rsp+0x37c]
   59e20:	mov    r13,QWORD PTR [rsp+0x150]
   59e28:	mov    QWORD PTR [rsp+0x130],r12
   59e30:	mov    r12d,DWORD PTR [rsp+0x394]
   59e38:	mov    rax,QWORD PTR [rdi+0x78]
   59e3c:	movsxd rcx,DWORD PTR [rbp+0x4]
   59e40:	mov    rax,QWORD PTR [rax+rcx*8]
   59e44:	movsxd rcx,DWORD PTR [rbp+0xc]
   59e48:	mov    DWORD PTR [rsp+0x394],r12d
   59e50:	imul   r12,rcx,0x38
   59e54:	mov    QWORD PTR [rsp+0x198],r12
   59e5c:	mov    r12d,DWORD PTR [rbp+0x10]
   59e60:	mov    DWORD PTR [rsp+0x398],0x0
   59e6b:	mov    DWORD PTR [rsp+0x3a8],r12d
   59e73:	mov    r12,QWORD PTR [rax+0x28]
   59e77:	mov    QWORD PTR [rsp+0x190],r12
   59e7f:	mov    r12,QWORD PTR [r12+0x30]
   59e84:	mov    QWORD PTR [rsp+0x150],r13
   59e8c:	mov    r13,QWORD PTR [rax+0x30]
   59e90:	test   r12,r12
   59e93:	jne    59f45 <sqlite3VdbeExec+0xaaa5>
   59e99:	movzx  eax,WORD PTR [r13+0x6]
   59e9e:	add    eax,0x1
   59ea1:	imul   rax,rax,0x38
   59ea5:	add    rax,0x28
   59ea9:	mov    rcx,QWORD PTR [r13+0x10]
   59ead:	test   rcx,rcx
   59eb0:	je     59ed2 <sqlite3VdbeExec+0xaa32>
   59eb2:	mov    QWORD PTR [rsp+0x110],rdi
   59eba:	mov    rdi,rcx
   59ebd:	mov    rsi,rax
   59ec0:	call   59ec5 <sqlite3VdbeExec+0xaa25>
   59ec5:	mov    r12,rax
   59ec8:	mov    rdi,QWORD PTR [rsp+0x110]
   59ed0:	jmp    59eed <sqlite3VdbeExec+0xaa4d>
   59ed2:	mov    QWORD PTR [rsp+0x110],rdi
   59eda:	mov    rdi,rax
   59edd:	call   59ee2 <sqlite3VdbeExec+0xaa42>
   59ee2:	mov    r12,rax
   59ee5:	mov    rdi,QWORD PTR [rsp+0x110]
   59eed:	test   r12,r12
   59ef0:	jne    59ef7 <sqlite3VdbeExec+0xaa57>
   59ef2:	xor    r12d,r12d
   59ef5:	jmp    59f13 <sqlite3VdbeExec+0xaa73>
   59ef7:	lea    rax,[r12+0x28]
   59efc:	mov    QWORD PTR [r12+0x8],rax
   59f01:	mov    QWORD PTR [r12],r13
   59f05:	movzx  eax,WORD PTR [r13+0x6]
   59f0a:	add    eax,0x1
   59f0d:	mov    WORD PTR [r12+0x1c],ax
   59f13:	mov    r13,QWORD PTR [rsp+0x190]
   59f1b:	mov    QWORD PTR [r13+0x30],r12
   59f1f:	test   r12,r12
   59f22:	jne    59f2f <sqlite3VdbeExec+0xaa8f>
   59f24:	mov    r12d,0x7
   59f2a:	jmp    5a055 <sqlite3VdbeExec+0xabb5>
   59f2f:	mov    QWORD PTR [rsp+0x190],r13
   59f37:	mov    r13d,DWORD PTR [rsp+0x3a8]
   59f3f:	mov    WORD PTR [r12+0x1c],r13w
   59f45:	mov    r13,QWORD PTR [rsp+0x190]
   59f4d:	cmp    BYTE PTR [r13+0x58],0x0
   59f52:	je     59f83 <sqlite3VdbeExec+0xaae3>
   59f54:	mov    rax,QWORD PTR [r13+0x18]
   59f58:	mov    rax,QWORD PTR [rax+0x18]
   59f5c:	mov    rcx,QWORD PTR [r13+0x18]
   59f60:	mov    rcx,QWORD PTR [rcx+0x10]
   59f64:	movsxd rcx,DWORD PTR [rcx+0x4]
   59f68:	imul   rcx,rcx,0x50
   59f6c:	mov    edx,DWORD PTR [rax+rcx*1+0x14]
   59f70:	lea    r13,[rsp+0x39c]
   59f78:	mov    DWORD PTR [r13+0x0],edx
   59f7c:	mov    rax,QWORD PTR [rax+rcx*1+0x28]
   59f81:	jmp    59fb0 <sqlite3VdbeExec+0xab10>
   59f83:	mov    rax,QWORD PTR [r13+0x38]
   59f87:	mov    eax,DWORD PTR [rax]
   59f89:	mov    QWORD PTR [rsp+0x188],r12
   59f91:	lea    r12,[rsp+0x39c]
   59f99:	mov    DWORD PTR [r12],eax
   59f9d:	mov    rax,QWORD PTR [r13+0x38]
   59fa1:	add    rax,0x10
   59fa5:	mov    r13,r12
   59fa8:	mov    r12,QWORD PTR [rsp+0x188]
   59fb0:	mov    ecx,DWORD PTR [r13+0x0]
   59fb4:	mov    QWORD PTR [rsp+0x110],rdi
   59fbc:	mov    rdi,rcx
   59fbf:	mov    rsi,rax
   59fc2:	mov    rdx,r12
   59fc5:	call   59fca <sqlite3VdbeExec+0xab2a>
   59fca:	xor    eax,eax
   59fcc:	mov    rdi,QWORD PTR [rsp+0x110]
   59fd4:	jmp    59fe1 <sqlite3VdbeExec+0xab41>
   59fd6:	mov    DWORD PTR [rsp+0x3a8],r13d
   59fde:	add    eax,0x1
   59fe1:	mov    r13d,DWORD PTR [rsp+0x3a8]
   59fe9:	cmp    eax,r13d
   59fec:	jge    5a016 <sqlite3VdbeExec+0xab76>
   59fee:	mov    rcx,QWORD PTR [r12+0x8]
   59ff3:	mov    rdx,rax
   59ff6:	imul   rdx,rdx,0x38
   59ffa:	movzx  ecx,WORD PTR [rcx+rdx*1+0x14]
   59fff:	and    ecx,0x1
   5a002:	test   ecx,ecx
   5a004:	je     59fd6 <sqlite3VdbeExec+0xab36>
   5a006:	mov    DWORD PTR [rsp+0x398],0xffffffff
   5a011:	xor    r12d,r12d
   5a014:	jmp    5a055 <sqlite3VdbeExec+0xabb5>
   5a016:	mov    r13,QWORD PTR [rsp+0x198]
   5a01e:	mov    eax,DWORD PTR [rbx+r13*1+0x10]
   5a023:	mov    rcx,QWORD PTR [rbx+r13*1+0x8]
   5a028:	xor    edx,edx
   5a02a:	mov    QWORD PTR [rsp+0x110],rdi
   5a032:	mov    rdi,rax
   5a035:	mov    rsi,rcx
   5a038:	mov    rcx,rdx
   5a03b:	mov    rdx,r12
   5a03e:	call   5a043 <sqlite3VdbeExec+0xaba3>
   5a043:	mov    DWORD PTR [rsp+0x398],eax
   5a04a:	xor    r12d,r12d
   5a04d:	mov    rdi,QWORD PTR [rsp+0x110]
   5a055:	test   r12d,r12d
   5a058:	je     5a07a <sqlite3VdbeExec+0xabda>
   5a05a:	mov    QWORD PTR [rsp+0x148],rbp
   5a062:	mov    rbp,r12
   5a065:	mov    r13,QWORD PTR [rsp+0x130]
   5a06d:	mov    rbx,QWORD PTR [rsp+0x158]
   5a075:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5a07a:	cmp    DWORD PTR [rsp+0x398],0x0
   5a082:	je     5a094 <sqlite3VdbeExec+0xabf4>
   5a084:	mov    DWORD PTR [rsp+0x38c],r12d
   5a08c:	mov    r12,r14
   5a08f:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   5a094:	mov    DWORD PTR [rsp+0x37c],r15d
   5a09c:	mov    DWORD PTR [rsp+0x38c],r12d
   5a0a4:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5a0a9:	mov    r15d,DWORD PTR [rsp+0x37c]
   5a0b1:	mov    QWORD PTR [rsp+0x130],r12
   5a0b9:	movsxd rax,DWORD PTR [rbp+0x8]
   5a0bd:	imul   rax,rax,0x38
   5a0c1:	lea    r12,[rbx+rax*1]
   5a0c5:	mov    rax,QWORD PTR [rdi+0x78]
   5a0c9:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a0cd:	mov    rax,QWORD PTR [rax+rcx*8]
   5a0d1:	lea    r13,[rsp+0x398]
   5a0d9:	mov    rax,QWORD PTR [rax+0x28]
   5a0dd:	cmp    BYTE PTR [rax+0x58],0x0
   5a0e1:	je     5a10a <sqlite3VdbeExec+0xac6a>
   5a0e3:	mov    rcx,QWORD PTR [rax+0x18]
   5a0e7:	mov    rcx,QWORD PTR [rcx+0x18]
   5a0eb:	mov    rax,QWORD PTR [rax+0x18]
   5a0ef:	mov    rax,QWORD PTR [rax+0x10]
   5a0f3:	movsxd rax,DWORD PTR [rax+0x4]
   5a0f7:	imul   rax,rax,0x50
   5a0fb:	mov    edx,DWORD PTR [rcx+rax*1+0x14]
   5a0ff:	mov    DWORD PTR [r13+0x0],edx
   5a103:	mov    rax,QWORD PTR [rcx+rax*1+0x28]
   5a108:	jmp    5a11c <sqlite3VdbeExec+0xac7c>
   5a10a:	mov    rcx,QWORD PTR [rax+0x38]
   5a10e:	mov    ecx,DWORD PTR [rcx]
   5a110:	mov    DWORD PTR [r13+0x0],ecx
   5a114:	mov    rax,QWORD PTR [rax+0x38]
   5a118:	add    rax,0x10
   5a11c:	mov    r13,rax
   5a11f:	mov    DWORD PTR [rsp+0x37c],r15d
   5a127:	lea    r15,[rsp+0x398]
   5a12f:	mov    eax,DWORD PTR [r15]
   5a132:	cmp    eax,DWORD PTR [r12+0x20]
   5a137:	jle    5a165 <sqlite3VdbeExec+0xacc5>
   5a139:	xor    ecx,ecx
   5a13b:	mov    QWORD PTR [rsp+0x110],rdi
   5a143:	mov    rdi,r12
   5a146:	mov    rsi,rax
   5a149:	mov    rdx,rcx
   5a14c:	call   5a151 <sqlite3VdbeExec+0xacb1>
   5a151:	mov    rdi,QWORD PTR [rsp+0x110]
   5a159:	test   eax,eax
   5a15b:	je     5a17e <sqlite3VdbeExec+0xacde>
   5a15d:	mov    r12d,0x7
   5a163:	jmp    5a1c3 <sqlite3VdbeExec+0xad23>
   5a165:	mov    rax,QWORD PTR [r12+0x28]
   5a16a:	mov    QWORD PTR [r12+0x8],rax
   5a16f:	movzx  eax,WORD PTR [r12+0x14]
   5a175:	and    eax,0x2d
   5a178:	mov    WORD PTR [r12+0x14],ax
   5a17e:	mov    eax,DWORD PTR [r15]
   5a181:	mov    DWORD PTR [r12+0x10],eax
   5a186:	movzx  eax,WORD PTR [r12+0x14]
   5a18c:	and    eax,0xfffff240
   5a191:	or     eax,0x10
   5a194:	mov    WORD PTR [r12+0x14],ax
   5a19a:	mov    rax,QWORD PTR [r12+0x8]
   5a19f:	movsxd rcx,DWORD PTR [r15]
   5a1a2:	mov    QWORD PTR [rsp+0x110],rdi
   5a1aa:	mov    rdi,rax
   5a1ad:	mov    rsi,r13
   5a1b0:	mov    rdx,rcx
   5a1b3:	call   5a1b8 <sqlite3VdbeExec+0xad18>
   5a1b8:	xor    r12d,r12d
   5a1bb:	mov    rdi,QWORD PTR [rsp+0x110]
   5a1c3:	test   r12d,r12d
   5a1c6:	je     5a1e8 <sqlite3VdbeExec+0xad48>
   5a1c8:	mov    QWORD PTR [rsp+0x148],rbp
   5a1d0:	mov    rbp,r12
   5a1d3:	mov    r13,QWORD PTR [rsp+0x130]
   5a1db:	mov    rbx,QWORD PTR [rsp+0x158]
   5a1e3:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5a1e8:	mov    rax,QWORD PTR [rdi+0x78]
   5a1ec:	movsxd rcx,DWORD PTR [rbp+0xc]
   5a1f0:	mov    rax,QWORD PTR [rax+rcx*8]
   5a1f4:	mov    DWORD PTR [rax+0x18],0x0
   5a1fb:	mov    DWORD PTR [rsp+0x38c],r12d
   5a203:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5a208:	mov    QWORD PTR [rsp+0x130],r12
   5a210:	mov    rax,QWORD PTR [rdi+0x68]
   5a214:	movsxd rcx,DWORD PTR [rbp+0x8]
   5a218:	imul   rcx,rcx,0x38
   5a21c:	lea    r12,[rax+rcx*1]
   5a220:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5a225:	and    eax,0x9000
   5a22a:	test   eax,eax
   5a22c:	je     5a24b <sqlite3VdbeExec+0xadab>
   5a22e:	mov    QWORD PTR [rsp+0x110],rdi
   5a236:	mov    rdi,r12
   5a239:	call   5a23e <sqlite3VdbeExec+0xad9e>
   5a23e:	mov    r12,rax
   5a241:	mov    rdi,QWORD PTR [rsp+0x110]
   5a249:	jmp    5a253 <sqlite3VdbeExec+0xadb3>
   5a24b:	mov    WORD PTR [r12+0x14],0x4
   5a253:	mov    rax,QWORD PTR [rdi+0x78]
   5a257:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a25b:	mov    rax,QWORD PTR [rax+rcx*8]
   5a25f:	mov    r13,QWORD PTR [rax+0x28]
   5a263:	mov    QWORD PTR [rsp+0x110],rdi
   5a26b:	mov    rdi,r13
   5a26e:	call   5a273 <sqlite3VdbeExec+0xadd3>
   5a273:	mov    eax,DWORD PTR [r13+0x40]
   5a277:	mov    rdi,QWORD PTR [rsp+0x110]
   5a27f:	cmp    eax,DWORD PTR [r14+0x88]
   5a286:	jbe    5a298 <sqlite3VdbeExec+0xadf8>
   5a288:	mov    QWORD PTR [rsp+0x148],rbp
   5a290:	mov    rbp,r14
   5a293:	jmp    53cbc <sqlite3VdbeExec+0x481c>
   5a298:	mov    rdi,r13
   5a29b:	mov    rsi,rax
   5a29e:	mov    rdx,r12
   5a2a1:	call   5a2a6 <sqlite3VdbeExec+0xae06>
   5a2a6:	mov    r13d,eax
   5a2a9:	mov    rdi,QWORD PTR [rsp+0x110]
   5a2b1:	test   r13d,r13d
   5a2b4:	je     5a2d6 <sqlite3VdbeExec+0xae36>
   5a2b6:	mov    QWORD PTR [rsp+0x148],rbp
   5a2be:	mov    rbp,r13
   5a2c1:	mov    r13,QWORD PTR [rsp+0x130]
   5a2c9:	mov    rbx,QWORD PTR [rsp+0x158]
   5a2d1:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5a2d6:	cmp    DWORD PTR [rbp+0xc],0x0
   5a2da:	jne    5a3ff <sqlite3VdbeExec+0xaf5f>
   5a2e0:	movzx  eax,WORD PTR [r12+0x14]
   5a2e6:	and    eax,0x4000
   5a2eb:	test   eax,eax
   5a2ed:	je     5a3ff <sqlite3VdbeExec+0xaf5f>
   5a2f3:	movzx  eax,WORD PTR [r12+0x14]
   5a2f9:	and    eax,0x12
   5a2fc:	test   eax,eax
   5a2fe:	je     5a3ee <sqlite3VdbeExec+0xaf4e>
   5a304:	movzx  eax,WORD PTR [r12+0x14]
   5a30a:	and    eax,0x400
   5a30f:	test   eax,eax
   5a311:	je     5a3a2 <sqlite3VdbeExec+0xaf02>
   5a317:	mov    eax,DWORD PTR [r12+0x10]
   5a31c:	add    eax,DWORD PTR [r12]
   5a320:	test   eax,eax
   5a322:	jg     5a336 <sqlite3VdbeExec+0xae96>
   5a324:	movzx  eax,WORD PTR [r12+0x14]
   5a32a:	and    eax,0x10
   5a32d:	test   eax,eax
   5a32f:	je     5a3a2 <sqlite3VdbeExec+0xaf02>
   5a331:	mov    eax,0x1
   5a336:	mov    ecx,0x1
   5a33b:	mov    QWORD PTR [rsp+0x110],rdi
   5a343:	mov    rdi,r12
   5a346:	mov    rsi,rax
   5a349:	mov    rdx,rcx
   5a34c:	call   5a351 <sqlite3VdbeExec+0xaeb1>
   5a351:	mov    rdi,QWORD PTR [rsp+0x110]
   5a359:	test   eax,eax
   5a35b:	jne    5a3d6 <sqlite3VdbeExec+0xaf36>
   5a35d:	mov    rax,QWORD PTR [r12+0x8]
   5a362:	movsxd rcx,DWORD PTR [r12+0x10]
   5a367:	add    rax,rcx
   5a36a:	xor    ecx,ecx
   5a36c:	movsxd rdx,DWORD PTR [r12]
   5a370:	mov    rdi,rax
   5a373:	mov    rsi,rcx
   5a376:	call   5a37b <sqlite3VdbeExec+0xaedb>
   5a37b:	mov    eax,DWORD PTR [r12+0x10]
   5a380:	add    eax,DWORD PTR [r12]
   5a384:	mov    DWORD PTR [r12+0x10],eax
   5a389:	movzx  eax,WORD PTR [r12+0x14]
   5a38f:	and    eax,0xfffff9ff
   5a394:	mov    WORD PTR [r12+0x14],ax
   5a39a:	mov    rdi,QWORD PTR [rsp+0x110]
   5a3a2:	cmp    DWORD PTR [r12+0x20],0x0
   5a3a8:	je     5a3b6 <sqlite3VdbeExec+0xaf16>
   5a3aa:	mov    rax,QWORD PTR [r12+0x8]
   5a3af:	cmp    rax,QWORD PTR [r12+0x28]
   5a3b4:	je     5a3ee <sqlite3VdbeExec+0xaf4e>
   5a3b6:	mov    QWORD PTR [rsp+0x110],rdi
   5a3be:	mov    rdi,r12
   5a3c1:	call   5a3c6 <sqlite3VdbeExec+0xaf26>
   5a3c6:	mov    rdi,QWORD PTR [rsp+0x110]
   5a3ce:	test   eax,eax
   5a3d0:	je     5a3ee <sqlite3VdbeExec+0xaf4e>
   5a3d2:	test   eax,eax
   5a3d4:	je     5a3ff <sqlite3VdbeExec+0xaf5f>
   5a3d6:	mov    r13,QWORD PTR [rsp+0x150]
   5a3de:	mov    rbx,rbp
   5a3e1:	mov    rbp,QWORD PTR [rsp+0x158]
   5a3e9:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5a3ee:	movzx  eax,WORD PTR [r12+0x14]
   5a3f4:	and    eax,0xffffbfff
   5a3f9:	mov    WORD PTR [r12+0x14],ax
   5a3ff:	mov    DWORD PTR [rsp+0x38c],r13d
   5a407:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5a40c:	mov    r15d,DWORD PTR [rsp+0x37c]
   5a414:	mov    r13,QWORD PTR [rsp+0x150]
   5a41c:	mov    QWORD PTR [rsp+0x130],r12
   5a424:	mov    r12d,DWORD PTR [rsp+0x394]
   5a42c:	mov    rax,QWORD PTR [rdi+0x68]
   5a430:	movsxd rcx,DWORD PTR [rbp+0x8]
   5a434:	imul   rcx,rcx,0x38
   5a438:	mov    DWORD PTR [rsp+0x394],r12d
   5a440:	lea    r12,[rax+rcx*1]
   5a444:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5a449:	and    eax,0x9000
   5a44e:	test   eax,eax
   5a450:	je     5a46f <sqlite3VdbeExec+0xafcf>
   5a452:	mov    QWORD PTR [rsp+0x110],rdi
   5a45a:	mov    rdi,r12
   5a45d:	call   5a462 <sqlite3VdbeExec+0xafc2>
   5a462:	mov    r12,rax
   5a465:	mov    rdi,QWORD PTR [rsp+0x110]
   5a46d:	jmp    5a477 <sqlite3VdbeExec+0xafd7>
   5a46f:	mov    WORD PTR [r12+0x14],0x4
   5a477:	mov    rax,QWORD PTR [rdi+0x78]
   5a47b:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a47f:	mov    QWORD PTR [rsp+0x150],r13
   5a487:	mov    r13,QWORD PTR [rax+rcx*8]
   5a48b:	cmp    BYTE PTR [r13+0x2],0x0
   5a490:	je     5a4a7 <sqlite3VdbeExec+0xb007>
   5a492:	mov    WORD PTR [r12+0x14],0x1
   5a49a:	mov    DWORD PTR [rsp+0x37c],r15d
   5a4a2:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5a4a7:	cmp    BYTE PTR [r13+0x3],0x0
   5a4ac:	je     5a4c7 <sqlite3VdbeExec+0xb027>
   5a4ae:	mov    rax,QWORD PTR [r13+0x48]
   5a4b2:	mov    QWORD PTR [rsp+0x188],rax
   5a4ba:	mov    r13d,DWORD PTR [rsp+0x38c]
   5a4c2:	jmp    5a7ad <sqlite3VdbeExec+0xb30d>
   5a4c7:	cmp    BYTE PTR [r13+0x0],0x2
   5a4cc:	jne    5a6f5 <sqlite3VdbeExec+0xb255>
   5a4d2:	mov    rax,QWORD PTR [r13+0x28]
   5a4d6:	mov    QWORD PTR [rsp+0x198],r12
   5a4de:	mov    r12,QWORD PTR [rax]
   5a4e1:	mov    rax,QWORD PTR [r12]
   5a4e5:	mov    rax,QWORD PTR [rax+0x60]
   5a4e9:	mov    rcx,QWORD PTR [r13+0x28]
   5a4ed:	lea    r13,[rsp+0x188]
   5a4f5:	mov    rdx,r13
   5a4f8:	mov    QWORD PTR [rsp+0x110],rdi
   5a500:	mov    rdi,rcx
   5a503:	mov    rsi,rdx
   5a506:	mov    r10,rax
   5a509:	call   r10
   5a50c:	mov    r13d,eax
   5a50f:	mov    rdi,QWORD PTR [rsp+0x110]
   5a517:	cmp    QWORD PTR [r12+0x10],0x0
   5a51d:	jne    5a52c <sqlite3VdbeExec+0xb08c>
   5a51f:	mov    DWORD PTR [rsp+0x398],r13d
   5a527:	jmp    5a6bb <sqlite3VdbeExec+0xb21b>
   5a52c:	mov    DWORD PTR [rsp+0x398],r13d
   5a534:	mov    r13,QWORD PTR [rdi]
   5a537:	mov    rax,QWORD PTR [rdi+0xa8]
   5a53e:	test   rax,rax
   5a541:	je     5a556 <sqlite3VdbeExec+0xb0b6>
   5a543:	mov    rdi,r13
   5a546:	mov    rsi,rax
   5a549:	call   5a54e <sqlite3VdbeExec+0xb0ae>
   5a54e:	mov    rdi,QWORD PTR [rsp+0x110]
   5a556:	mov    QWORD PTR [rsp+0x190],r12
   5a55e:	mov    r12,QWORD PTR [r12+0x10]
   5a563:	test   r12,r12
   5a566:	jne    5a57b <sqlite3VdbeExec+0xb0db>
   5a568:	xor    r12d,r12d
   5a56b:	mov    r13,r12
   5a56e:	mov    r12,QWORD PTR [rsp+0x190]
   5a576:	jmp    5a61c <sqlite3VdbeExec+0xb17c>
   5a57b:	mov    QWORD PTR [rsp+0x110],rdi
   5a583:	mov    rdi,r12
   5a586:	call   5a58b <sqlite3VdbeExec+0xb0eb>
   5a58b:	mov    QWORD PTR [rsp+0x168],r12
   5a593:	lea    r12,[rax+0x1]
   5a597:	mov    rdi,QWORD PTR [rsp+0x110]
   5a59f:	test   r13,r13
   5a5a2:	je     5a5bc <sqlite3VdbeExec+0xb11c>
   5a5a4:	mov    rdi,r13
   5a5a7:	mov    rsi,r12
   5a5aa:	call   5a5af <sqlite3VdbeExec+0xb10f>
   5a5af:	mov    r13,rax
   5a5b2:	mov    rdi,QWORD PTR [rsp+0x110]
   5a5ba:	jmp    5a5cf <sqlite3VdbeExec+0xb12f>
   5a5bc:	mov    rdi,r12
   5a5bf:	call   5a5c4 <sqlite3VdbeExec+0xb124>
   5a5c4:	mov    r13,rax
   5a5c7:	mov    rdi,QWORD PTR [rsp+0x110]
   5a5cf:	test   r13,r13
   5a5d2:	jne    5a5de <sqlite3VdbeExec+0xb13e>
   5a5d4:	mov    DWORD PTR [rsp+0x37c],r15d
   5a5dc:	jmp    5a60c <sqlite3VdbeExec+0xb16c>
   5a5de:	mov    DWORD PTR [rsp+0x37c],r15d
   5a5e6:	mov    r15,QWORD PTR [rsp+0x168]
   5a5ee:	mov    QWORD PTR [rsp+0x110],rdi
   5a5f6:	mov    rdi,r13
   5a5f9:	mov    rsi,r15
   5a5fc:	mov    rdx,r12
   5a5ff:	call   5a604 <sqlite3VdbeExec+0xb164>
   5a604:	mov    rdi,QWORD PTR [rsp+0x110]
   5a60c:	mov    r15d,DWORD PTR [rsp+0x37c]
   5a614:	mov    r12,QWORD PTR [rsp+0x190]
   5a61c:	mov    QWORD PTR [rdi+0xa8],r13
   5a623:	mov    r13,QWORD PTR [r12+0x10]
   5a628:	test   r13,r13
   5a62b:	je     5a6b2 <sqlite3VdbeExec+0xb212>
   5a631:	cmp    DWORD PTR [rip+0x0],0x0        # 5a638 <sqlite3VdbeExec+0xb198>
   5a638:	je     5a692 <sqlite3VdbeExec+0xb1f2>
   5a63a:	mov    rax,QWORD PTR [rip+0x0]        # 5a641 <sqlite3VdbeExec+0xb1a1>
   5a641:	mov    QWORD PTR [rsp+0x110],rdi
   5a649:	mov    rdi,r13
   5a64c:	mov    r10,rax
   5a64f:	call   r10
   5a652:	mov    rcx,QWORD PTR [rip+0x0]        # 5a659 <sqlite3VdbeExec+0xb1b9>
   5a659:	movsxd rax,eax
   5a65c:	sub    rcx,rax
   5a65f:	mov    QWORD PTR [rip+0x0],rcx        # 5a666 <sqlite3VdbeExec+0xb1c6>
   5a666:	mov    rax,QWORD PTR [rip+0x0]        # 5a66d <sqlite3VdbeExec+0xb1cd>
   5a66d:	sub    rax,0x1
   5a671:	mov    QWORD PTR [rip+0x0],rax        # 5a678 <sqlite3VdbeExec+0xb1d8>
   5a678:	mov    rax,QWORD PTR [rip+0x0]        # 5a67f <sqlite3VdbeExec+0xb1df>
   5a67f:	mov    rdi,r13
   5a682:	mov    r10,rax
   5a685:	call   r10
   5a688:	mov    rdi,QWORD PTR [rsp+0x110]
   5a690:	jmp    5a6b2 <sqlite3VdbeExec+0xb212>
   5a692:	mov    rax,QWORD PTR [rip+0x0]        # 5a699 <sqlite3VdbeExec+0xb1f9>
   5a699:	mov    QWORD PTR [rsp+0x110],rdi
   5a6a1:	mov    rdi,r13
   5a6a4:	mov    r10,rax
   5a6a7:	call   r10
   5a6aa:	mov    rdi,QWORD PTR [rsp+0x110]
   5a6b2:	mov    QWORD PTR [r12+0x10],0x0
   5a6bb:	mov    r13d,DWORD PTR [rsp+0x398]
   5a6c3:	test   r13d,r13d
   5a6c6:	je     5a6e8 <sqlite3VdbeExec+0xb248>
   5a6c8:	mov    QWORD PTR [rsp+0x148],rbp
   5a6d0:	mov    rbp,r13
   5a6d3:	mov    r13,QWORD PTR [rsp+0x130]
   5a6db:	mov    rbx,QWORD PTR [rsp+0x158]
   5a6e3:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5a6e8:	mov    r12,QWORD PTR [rsp+0x198]
   5a6f0:	jmp    5a7ad <sqlite3VdbeExec+0xb30d>
   5a6f5:	mov    QWORD PTR [rsp+0x198],r12
   5a6fd:	mov    rax,QWORD PTR [r13+0x28]
   5a701:	xor    ecx,ecx
   5a703:	movzx  eax,BYTE PTR [rax]
   5a706:	cmp    ecx,eax
   5a708:	je     5a727 <sqlite3VdbeExec+0xb287>
   5a70a:	mov    QWORD PTR [rsp+0x110],rdi
   5a712:	mov    rdi,r13
   5a715:	call   5a71a <sqlite3VdbeExec+0xb27a>
   5a71a:	mov    r12d,eax
   5a71d:	mov    rdi,QWORD PTR [rsp+0x110]
   5a725:	jmp    5a72a <sqlite3VdbeExec+0xb28a>
   5a727:	xor    r12d,r12d
   5a72a:	test   r12d,r12d
   5a72d:	je     5a74f <sqlite3VdbeExec+0xb2af>
   5a72f:	mov    QWORD PTR [rsp+0x148],rbp
   5a737:	mov    rbp,r12
   5a73a:	mov    r13,QWORD PTR [rsp+0x130]
   5a742:	mov    rbx,QWORD PTR [rsp+0x158]
   5a74a:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5a74f:	cmp    BYTE PTR [r13+0x2],0x0
   5a754:	je     5a77a <sqlite3VdbeExec+0xb2da>
   5a756:	mov    r13,QWORD PTR [rsp+0x198]
   5a75e:	mov    WORD PTR [r13+0x14],0x1
   5a765:	mov    DWORD PTR [rsp+0x37c],r15d
   5a76d:	mov    DWORD PTR [rsp+0x38c],r12d
   5a775:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5a77a:	mov    r13,QWORD PTR [r13+0x28]
   5a77e:	mov    QWORD PTR [rsp+0x110],rdi
   5a786:	mov    rdi,r13
   5a789:	call   5a78e <sqlite3VdbeExec+0xb2ee>
   5a78e:	mov    rax,QWORD PTR [r13+0x30]
   5a792:	mov    QWORD PTR [rsp+0x188],rax
   5a79a:	mov    rdi,QWORD PTR [rsp+0x110]
   5a7a2:	mov    r13,r12
   5a7a5:	mov    r12,QWORD PTR [rsp+0x198]
   5a7ad:	mov    rax,QWORD PTR [rsp+0x188]
   5a7b5:	mov    QWORD PTR [r12],rax
   5a7b9:	mov    DWORD PTR [rsp+0x37c],r15d
   5a7c1:	mov    DWORD PTR [rsp+0x38c],r13d
   5a7c9:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5a7ce:	mov    r15d,DWORD PTR [rsp+0x37c]
   5a7d6:	mov    r13,QWORD PTR [rsp+0x150]
   5a7de:	mov    QWORD PTR [rsp+0x130],r12
   5a7e6:	mov    r12d,DWORD PTR [rsp+0x394]
   5a7ee:	mov    rax,QWORD PTR [rdi+0x78]
   5a7f2:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a7f6:	mov    rax,QWORD PTR [rax+rcx*8]
   5a7fa:	test   rax,rax
   5a7fd:	jne    5a867 <sqlite3VdbeExec+0xb3c7>
   5a7ff:	mov    eax,DWORD PTR [rbp+0x4]
   5a802:	mov    ecx,0x1
   5a807:	mov    edx,0x3
   5a80c:	mov    QWORD PTR [rsp+0x110],rdi
   5a814:	mov    rsi,rax
   5a817:	mov    r11,rdx
   5a81a:	mov    rdx,rcx
   5a81d:	mov    rcx,r11
   5a820:	call   5a825 <sqlite3VdbeExec+0xb385>
   5a825:	mov    rdi,QWORD PTR [rsp+0x110]
   5a82d:	test   rax,rax
   5a830:	jne    5a842 <sqlite3VdbeExec+0xb3a2>
   5a832:	mov    rbx,rbp
   5a835:	mov    rbp,QWORD PTR [rsp+0x158]
   5a83d:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5a842:	mov    DWORD PTR [rax+0x1c],0x0
   5a849:	mov    BYTE PTR [rax+0x4],0x1
   5a84d:	movzx  ecx,BYTE PTR [rax+0x5]
   5a851:	and    rcx,0xfffffffffffffff7
   5a855:	or     rcx,0x8
   5a859:	mov    BYTE PTR [rax+0x5],cl
   5a85c:	lea    rcx,[rip+0x0]        # 5a863 <sqlite3VdbeExec+0xb3c3>
   5a863:	mov    QWORD PTR [rax+0x28],rcx
   5a867:	mov    BYTE PTR [rax+0x2],0x1
   5a86b:	mov    DWORD PTR [rax+0x18],0x0
   5a872:	cmp    BYTE PTR [rax],0x0
   5a875:	je     5a884 <sqlite3VdbeExec+0xb3e4>
   5a877:	mov    DWORD PTR [rsp+0x394],r12d
   5a87f:	jmp    5a93d <sqlite3VdbeExec+0xb49d>
   5a884:	mov    DWORD PTR [rsp+0x394],r12d
   5a88c:	mov    r12,QWORD PTR [rax+0x28]
   5a890:	mov    QWORD PTR [rsp+0x188],r12
   5a898:	mov    r12,QWORD PTR [r12+0x18]
   5a89d:	test   r12,r12
   5a8a0:	je     5a927 <sqlite3VdbeExec+0xb487>
   5a8a6:	cmp    DWORD PTR [rip+0x0],0x0        # 5a8ad <sqlite3VdbeExec+0xb40d>
   5a8ad:	je     5a907 <sqlite3VdbeExec+0xb467>
   5a8af:	mov    rax,QWORD PTR [rip+0x0]        # 5a8b6 <sqlite3VdbeExec+0xb416>
   5a8b6:	mov    QWORD PTR [rsp+0x110],rdi
   5a8be:	mov    rdi,r12
   5a8c1:	mov    r10,rax
   5a8c4:	call   r10
   5a8c7:	mov    rcx,QWORD PTR [rip+0x0]        # 5a8ce <sqlite3VdbeExec+0xb42e>
   5a8ce:	movsxd rax,eax
   5a8d1:	sub    rcx,rax
   5a8d4:	mov    QWORD PTR [rip+0x0],rcx        # 5a8db <sqlite3VdbeExec+0xb43b>
   5a8db:	mov    rax,QWORD PTR [rip+0x0]        # 5a8e2 <sqlite3VdbeExec+0xb442>
   5a8e2:	sub    rax,0x1
   5a8e6:	mov    QWORD PTR [rip+0x0],rax        # 5a8ed <sqlite3VdbeExec+0xb44d>
   5a8ed:	mov    rax,QWORD PTR [rip+0x0]        # 5a8f4 <sqlite3VdbeExec+0xb454>
   5a8f4:	mov    rdi,r12
   5a8f7:	mov    r10,rax
   5a8fa:	call   r10
   5a8fd:	mov    rdi,QWORD PTR [rsp+0x110]
   5a905:	jmp    5a927 <sqlite3VdbeExec+0xb487>
   5a907:	mov    rax,QWORD PTR [rip+0x0]        # 5a90e <sqlite3VdbeExec+0xb46e>
   5a90e:	mov    QWORD PTR [rsp+0x110],rdi
   5a916:	mov    rdi,r12
   5a919:	mov    r10,rax
   5a91c:	call   r10
   5a91f:	mov    rdi,QWORD PTR [rsp+0x110]
   5a927:	mov    r12,QWORD PTR [rsp+0x188]
   5a92f:	mov    QWORD PTR [r12+0x18],0x0
   5a938:	mov    BYTE PTR [r12],0x1
   5a93d:	mov    DWORD PTR [rsp+0x37c],r15d
   5a945:	mov    QWORD PTR [rsp+0x150],r13
   5a94d:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5a952:	mov    r15d,DWORD PTR [rsp+0x37c]
   5a95a:	mov    r13,QWORD PTR [rsp+0x150]
   5a962:	mov    QWORD PTR [rsp+0x130],r12
   5a96a:	mov    rax,QWORD PTR [rdi+0x78]
   5a96e:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a972:	mov    r12,QWORD PTR [rax+rcx*8]
   5a976:	mov    rax,QWORD PTR [r12+0x28]
   5a97b:	mov    DWORD PTR [rsp+0x398],0x0
   5a986:	cmp    BYTE PTR [rbp+0x0],0x8b
   5a98a:	je     5a9a1 <sqlite3VdbeExec+0xb501>
   5a98c:	mov    QWORD PTR [rsp+0x188],r12
   5a994:	mov    r12,r13
   5a997:	lea    r13,[rsp+0x398]
   5a99f:	jmp    5a9d9 <sqlite3VdbeExec+0xb539>
   5a9a1:	mov    DWORD PTR [r12+0x1c],0xffffffff
   5a9aa:	cmp    BYTE PTR [rax],0x0
   5a9ad:	je     5a9c4 <sqlite3VdbeExec+0xb524>
   5a9af:	mov    QWORD PTR [rsp+0x188],r12
   5a9b7:	mov    r12,r13
   5a9ba:	lea    r13,[rsp+0x398]
   5a9c2:	jmp    5a9d9 <sqlite3VdbeExec+0xb539>
   5a9c4:	mov    DWORD PTR [rsp+0x37c],r15d
   5a9cc:	mov    QWORD PTR [rsp+0x150],r13
   5a9d4:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5a9d9:	mov    rcx,r13
   5a9dc:	xor    edx,edx
   5a9de:	movzx  esi,BYTE PTR [rax]
   5a9e1:	cmp    edx,esi
   5a9e3:	jne    5a9fb <sqlite3VdbeExec+0xb55b>
   5a9e5:	movzx  edx,BYTE PTR [rax+0x1]
   5a9e9:	and    edx,0x8
   5a9ec:	test   edx,edx
   5a9ee:	je     5a9fb <sqlite3VdbeExec+0xb55b>
   5a9f0:	mov    DWORD PTR [rcx],0x0
   5a9f6:	xor    r13d,r13d
   5a9f9:	jmp    5aa19 <sqlite3VdbeExec+0xb579>
   5a9fb:	mov    QWORD PTR [rsp+0x110],rdi
   5aa03:	mov    rdi,rax
   5aa06:	mov    rsi,rcx
   5aa09:	call   5aa0e <sqlite3VdbeExec+0xb56e>
   5aa0e:	mov    r13d,eax
   5aa11:	mov    rdi,QWORD PTR [rsp+0x110]
   5aa19:	mov    eax,DWORD PTR [rsp+0x398]
   5aa20:	mov    QWORD PTR [rsp+0x150],r12
   5aa28:	mov    r12,QWORD PTR [rsp+0x188]
   5aa30:	mov    BYTE PTR [r12+0x2],al
   5aa35:	mov    BYTE PTR [r12+0x3],0x0
   5aa3b:	mov    DWORD PTR [r12+0x18],0x0
   5aa44:	test   r13d,r13d
   5aa47:	je     5aa69 <sqlite3VdbeExec+0xb5c9>
   5aa49:	mov    QWORD PTR [rsp+0x148],rbp
   5aa51:	mov    rbp,r13
   5aa54:	mov    r13,QWORD PTR [rsp+0x130]
   5aa5c:	mov    rbx,QWORD PTR [rsp+0x158]
   5aa64:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5aa69:	cmp    DWORD PTR [rbp+0x8],0x0
   5aa6d:	jle    5aa89 <sqlite3VdbeExec+0xb5e9>
   5aa6f:	cmp    DWORD PTR [rsp+0x398],0x0
   5aa77:	je     5aa89 <sqlite3VdbeExec+0xb5e9>
   5aa79:	mov    r12,r14
   5aa7c:	mov    DWORD PTR [rsp+0x38c],r13d
   5aa84:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   5aa89:	mov    DWORD PTR [rsp+0x37c],r15d
   5aa91:	mov    DWORD PTR [rsp+0x38c],r13d
   5aa99:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5aa9e:	mov    r15d,DWORD PTR [rsp+0x37c]
   5aaa6:	mov    QWORD PTR [rsp+0x130],r12
   5aaae:	mov    rax,QWORD PTR [rdi+0x78]
   5aab2:	movsxd rcx,DWORD PTR [rbp+0x4]
   5aab6:	mov    rax,QWORD PTR [rax+rcx*8]
   5aaba:	mov    r12,QWORD PTR [rax+0x28]
   5aabe:	mov    QWORD PTR [rsp+0x110],rdi
   5aac6:	mov    rdi,r12
   5aac9:	call   5aace <sqlite3VdbeExec+0xb62e>
   5aace:	mov    rdi,QWORD PTR [rsp+0x110]
   5aad6:	test   eax,eax
   5aad8:	jne    5ab76 <sqlite3VdbeExec+0xb6d6>
   5aade:	mov    DWORD PTR [rsp+0x398],0x0
   5aae9:	xor    eax,eax
   5aaeb:	jmp    5ab6c <sqlite3VdbeExec+0xb6cc>
   5aaed:	mov    rcx,QWORD PTR [r12+0x88]
   5aaf5:	cmp    BYTE PTR [rcx+0x8],0x0
   5aaf9:	jne    5ab74 <sqlite3VdbeExec+0xb6d4>
   5aafb:	mov    rax,QWORD PTR [rcx+0x50]
   5aaff:	movzx  edx,WORD PTR [rcx+0x1a]
   5ab03:	mov    rsi,QWORD PTR [rcx+0x60]
   5ab07:	movzx  r8d,WORD PTR [r12+0x56]
   5ab0d:	shl    r8d,1
   5ab10:	movzx  esi,BYTE PTR [rsi+r8*1]
   5ab15:	shl    esi,0x8
   5ab18:	mov    rcx,QWORD PTR [rcx+0x60]
   5ab1c:	movzx  r8d,WORD PTR [r12+0x56]
   5ab22:	shl    r8d,1
   5ab25:	movzx  ecx,BYTE PTR [rcx+r8*1+0x1]
   5ab2b:	or     esi,ecx
   5ab2d:	and    edx,esi
   5ab2f:	movzx  ecx,BYTE PTR [rax+rdx*1]
   5ab33:	shl    ecx,0x18
   5ab36:	movzx  esi,BYTE PTR [rax+rdx*1+0x1]
   5ab3b:	shl    esi,0x10
   5ab3e:	or     ecx,esi
   5ab40:	movzx  esi,BYTE PTR [rax+rdx*1+0x2]
   5ab45:	shl    esi,0x8
   5ab48:	or     ecx,esi
   5ab4a:	movzx  eax,BYTE PTR [rax+rdx*1+0x3]
   5ab4f:	or     ecx,eax
   5ab51:	mov    QWORD PTR [rsp+0x110],rdi
   5ab59:	mov    rdi,r12
   5ab5c:	mov    rsi,rcx
   5ab5f:	call   5ab64 <sqlite3VdbeExec+0xb6c4>
   5ab64:	mov    rdi,QWORD PTR [rsp+0x110]
   5ab6c:	test   eax,eax
   5ab6e:	je     5aaed <sqlite3VdbeExec+0xb64d>
   5ab74:	jmp    5ab88 <sqlite3VdbeExec+0xb6e8>
   5ab76:	cmp    eax,0x10
   5ab79:	jne    5ab88 <sqlite3VdbeExec+0xb6e8>
   5ab7b:	mov    DWORD PTR [rsp+0x398],0x1
   5ab86:	xor    eax,eax
   5ab88:	mov    r13d,eax
   5ab8b:	test   r13d,r13d
   5ab8e:	je     5abb0 <sqlite3VdbeExec+0xb710>
   5ab90:	mov    QWORD PTR [rsp+0x148],rbp
   5ab98:	mov    rbp,r13
   5ab9b:	mov    r13,QWORD PTR [rsp+0x130]
   5aba3:	mov    rbx,QWORD PTR [rsp+0x158]
   5abab:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5abb0:	cmp    DWORD PTR [rsp+0x398],0x0
   5abb8:	je     5abc3 <sqlite3VdbeExec+0xb723>
   5abba:	mov    rax,0xffffffffffffffff
   5abc1:	jmp    5ac35 <sqlite3VdbeExec+0xb795>
   5abc3:	cmp    BYTE PTR [r12],0x0
   5abc8:	je     5abce <sqlite3VdbeExec+0xb72e>
   5abca:	xor    eax,eax
   5abcc:	jmp    5ac1e <sqlite3VdbeExec+0xb77e>
   5abce:	mov    rax,QWORD PTR [r12+0x88]
   5abd6:	cmp    BYTE PTR [rax+0x8],0x0
   5abda:	jne    5abe5 <sqlite3VdbeExec+0xb745>
   5abdc:	mov    rax,0xffffffffffffffff
   5abe3:	jmp    5ac1e <sqlite3VdbeExec+0xb77e>
   5abe5:	mov    rax,QWORD PTR [r12+0x88]
   5abed:	movzx  eax,WORD PTR [rax+0x18]
   5abf1:	xor    ecx,ecx
   5abf3:	jmp    5ac12 <sqlite3VdbeExec+0xb772>
   5abf5:	mov    rdx,rcx
   5abf8:	mov    rdx,QWORD PTR [r12+rdx*8+0x90]
   5ac00:	movzx  edx,WORD PTR [rdx+0x18]
   5ac04:	add    edx,0x1
   5ac07:	imul   rax,rdx
   5ac0b:	mov    edx,0x1
   5ac10:	add    cl,dl
   5ac12:	mov    edx,ecx
   5ac14:	movsx  esi,BYTE PTR [r12+0x54]
   5ac1a:	cmp    edx,esi
   5ac1c:	jl     5abf5 <sqlite3VdbeExec+0xb755>
   5ac1e:	mov    ecx,0x28
   5ac23:	cmp    rax,0x8
   5ac27:	jae    5ac8a <sqlite3VdbeExec+0xb7ea>
   5ac29:	cmp    rax,0x2
   5ac2d:	jae    5ac5b <sqlite3VdbeExec+0xb7bb>
   5ac2f:	xor    eax,eax
   5ac31:	movsx  rax,ax
   5ac35:	movsxd rcx,DWORD PTR [rbp+0xc]
   5ac39:	cmp    rax,rcx
   5ac3c:	jl     5aca8 <sqlite3VdbeExec+0xb808>
   5ac3e:	movsxd rcx,DWORD PTR [rbp+0x10]
   5ac42:	cmp    rax,rcx
   5ac45:	mov    eax,0x0
   5ac4a:	setle  al
   5ac4d:	jmp    5acaa <sqlite3VdbeExec+0xb80a>
   5ac4f:	movsx  ecx,cx
   5ac52:	sub    ecx,0xa
   5ac55:	movzx  ecx,cx
   5ac58:	shl    rax,1
   5ac5b:	cmp    rax,0x8
   5ac5f:	jb     5ac4f <sqlite3VdbeExec+0xb7af>
   5ac61:	lea    rdx,[rip+0x0]        # 5ac68 <sqlite3VdbeExec+0xb7c8>
   5ac68:	and    rax,0x7
   5ac6c:	movsx  eax,WORD PTR [rdx+rax*2]
   5ac70:	movsx  ecx,cx
   5ac73:	add    eax,ecx
   5ac75:	sub    eax,0xa
   5ac78:	movzx  eax,ax
   5ac7b:	jmp    5ac31 <sqlite3VdbeExec+0xb791>
   5ac7d:	movsx  ecx,cx
   5ac80:	add    ecx,0x28
   5ac83:	movzx  ecx,cx
   5ac86:	shr    rax,0x4
   5ac8a:	cmp    rax,0xff
   5ac90:	ja     5ac7d <sqlite3VdbeExec+0xb7dd>
   5ac92:	jmp    5aca0 <sqlite3VdbeExec+0xb800>
   5ac94:	movsx  ecx,cx
   5ac97:	add    ecx,0xa
   5ac9a:	movzx  ecx,cx
   5ac9d:	shr    rax,1
   5aca0:	cmp    rax,0xf
   5aca4:	ja     5ac94 <sqlite3VdbeExec+0xb7f4>
   5aca6:	jmp    5ac61 <sqlite3VdbeExec+0xb7c1>
   5aca8:	xor    eax,eax
   5acaa:	mov    DWORD PTR [rsp+0x398],eax
   5acb1:	cmp    DWORD PTR [rsp+0x398],0x0
   5acb9:	je     5accb <sqlite3VdbeExec+0xb82b>
   5acbb:	mov    r12,r14
   5acbe:	mov    DWORD PTR [rsp+0x38c],r13d
   5acc6:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   5accb:	mov    DWORD PTR [rsp+0x37c],r15d
   5acd3:	mov    DWORD PTR [rsp+0x38c],r13d
   5acdb:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5ace0:	mov    r15d,DWORD PTR [rsp+0x37c]
   5ace8:	mov    QWORD PTR [rsp+0x130],r12
   5acf0:	mov    eax,DWORD PTR [rdi+0xdc]
   5acf6:	add    eax,0x1
   5acf9:	mov    DWORD PTR [rdi+0xdc],eax
   5acff:	mov    rax,QWORD PTR [rdi+0x78]
   5ad03:	movsxd rcx,DWORD PTR [rbp+0x4]
   5ad07:	mov    r12,QWORD PTR [rax+rcx*8]
   5ad0b:	mov    DWORD PTR [rsp+0x398],0x1
   5ad16:	cmp    BYTE PTR [r12],0x1
   5ad1b:	jne    5bbe2 <sqlite3VdbeExec+0xc742>
   5ad21:	mov    r13,QWORD PTR [r12+0x28]
   5ad26:	cmp    BYTE PTR [r13+0x58],0x0
   5ad2b:	jne    5ad92 <sqlite3VdbeExec+0xb8f2>
   5ad2d:	cmp    QWORD PTR [r13+0x38],0x0
   5ad32:	je     5ad6f <sqlite3VdbeExec+0xb8cf>
   5ad34:	mov    DWORD PTR [rsp+0x398],0x0
   5ad3f:	lea    rax,[r13+0x60]
   5ad43:	lea    rcx,[r13+0x38]
   5ad47:	mov    QWORD PTR [rsp+0x110],rdi
   5ad4f:	mov    rdi,rax
   5ad52:	mov    rsi,rcx
   5ad55:	call   5ad5a <sqlite3VdbeExec+0xb8ba>
   5ad5a:	mov    r13d,eax
   5ad5d:	mov    rdi,QWORD PTR [rsp+0x110]
   5ad65:	mov    DWORD PTR [rsp+0x39c],r13d
   5ad6d:	jmp    5ad85 <sqlite3VdbeExec+0xb8e5>
   5ad6f:	mov    DWORD PTR [rsp+0x398],0x1
   5ad7a:	xor    r11d,r11d
   5ad7d:	mov    DWORD PTR [rsp+0x39c],r11d
   5ad85:	mov    r13d,DWORD PTR [rsp+0x39c]
   5ad8d:	jmp    5bbdd <sqlite3VdbeExec+0xc73d>
   5ad92:	mov    QWORD PTR [rsp+0x188],r12
   5ad9a:	mov    QWORD PTR [rsp+0x110],rdi
   5ada2:	mov    rdi,r13
   5ada5:	call   5adaa <sqlite3VdbeExec+0xb90a>
   5adaa:	mov    r12d,eax
   5adad:	mov    rdi,QWORD PTR [rsp+0x110]
   5adb5:	test   r12d,r12d
   5adb8:	jne    5bbd2 <sqlite3VdbeExec+0xc732>
   5adbe:	lea    r12,[r13+0x60]
   5adc2:	mov    QWORD PTR [rsp+0x190],0x0
   5adce:	lea    r8,[rsp+0x178]
   5add6:	lea    r9,[rsp+0x1a0]
   5adde:	mov    r11d,0x10
   5ade4:	vpbroadcastd zmm0,r11d
   5adea:	mov    r11d,0x1
   5adf0:	vpbroadcastd zmm1,r11d
   5adf6:	mov    DWORD PTR [rsp+0x37c],r15d
   5adfe:	mov    QWORD PTR [rsp+0x198],r13
   5ae06:	mov    QWORD PTR [rsp+0x168],r12
   5ae0e:	xor    r15d,r15d
   5ae11:	xor    r12d,r12d
   5ae14:	xor    r13d,r13d
   5ae17:	jmp    5ba8b <sqlite3VdbeExec+0xc5eb>
   5ae1c:	shl    rcx,0x4
   5ae20:	add    eax,0x1
   5ae23:	mov    rsi,rdx
   5ae26:	cmp    rcx,rsi
   5ae29:	jl     5ae1c <sqlite3VdbeExec+0xb97c>
   5ae2b:	mov    QWORD PTR [rsp+0x198],r13
   5ae33:	mov    r13d,eax
   5ae36:	mov    QWORD PTR [r9],0x0
   5ae3d:	cmp    DWORD PTR [r12+0xc],0x10
   5ae43:	jg     5aed0 <sqlite3VdbeExec+0xba30>
   5ae49:	mov    eax,DWORD PTR [r12+0xc]
   5ae4e:	mov    rcx,r9
   5ae51:	mov    rdx,r8
   5ae54:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ae5f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ae6a:	mov    QWORD PTR [rsp+0x110],rdi
   5ae72:	mov    rdi,r12
   5ae75:	mov    rsi,rax
   5ae78:	mov    r11,rdx
   5ae7b:	mov    rdx,rcx
   5ae7e:	mov    rcx,r11
   5ae81:	call   5ae86 <sqlite3VdbeExec+0xb9e6>
   5ae86:	mov    r12d,eax
   5ae89:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ae94:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ae9f:	mov    rdi,QWORD PTR [rsp+0x110]
   5aea7:	lea    r8,[rsp+0x178]
   5aeaf:	lea    r9,[rsp+0x1a0]
   5aeb7:	test   r12d,r12d
   5aeba:	jne    5ba18 <sqlite3VdbeExec+0xc578>
   5aec0:	mov    r13,QWORD PTR [r8]
   5aec3:	mov    QWORD PTR [rsp+0x180],r13
   5aecb:	jmp    5ba6f <sqlite3VdbeExec+0xc5cf>
   5aed0:	mov    DWORD PTR [rsp+0x3a0],r13d
   5aed8:	mov    r13,rbx
   5aedb:	mov    ebx,0x2
   5aee0:	jmp    5aee4 <sqlite3VdbeExec+0xba44>
   5aee2:	add    ebx,ebx
   5aee4:	cmp    ebx,0x10
   5aee7:	jl     5aee2 <sqlite3VdbeExec+0xba42>
   5aee9:	mov    rax,rbx
   5aeec:	imul   rax,rax,0x54
   5aef0:	mov    DWORD PTR [rsp+0x3ac],ebx
   5aef7:	lea    rbx,[rax+0x20]
   5aefb:	mov    eax,0x64
   5af00:	mov    rcx,QWORD PTR [rip+0x0]        # 5af07 <sqlite3VdbeExec+0xba67>
   5af07:	test   rcx,rcx
   5af0a:	je     5af73 <sqlite3VdbeExec+0xbad3>
   5af0c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5af17:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5af22:	mov    QWORD PTR [rsp+0x110],rdi
   5af2a:	mov    rdi,rax
   5af2d:	mov    r10,rcx
   5af30:	call   r10
   5af33:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5af3e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5af49:	mov    rdi,QWORD PTR [rsp+0x110]
   5af51:	test   eax,eax
   5af53:	je     5af73 <sqlite3VdbeExec+0xbad3>
   5af55:	xor    eax,eax
   5af57:	mov    ebx,DWORD PTR [rsp+0x3ac]
   5af5e:	lea    r8,[rsp+0x178]
   5af66:	lea    r9,[rsp+0x1a0]
   5af6e:	jmp    5b02a <sqlite3VdbeExec+0xbb8a>
   5af73:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5af7e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5af89:	mov    QWORD PTR [rsp+0x110],rdi
   5af91:	mov    rdi,rbx
   5af94:	call   5af99 <sqlite3VdbeExec+0xbaf9>
   5af99:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5afa4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5afaf:	mov    rdi,QWORD PTR [rsp+0x110]
   5afb7:	test   rax,rax
   5afba:	je     5b013 <sqlite3VdbeExec+0xbb73>
   5afbc:	xor    ecx,ecx
   5afbe:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5afc9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5afd4:	mov    QWORD PTR [rsp+0x108],rax
   5afdc:	mov    rdi,rax
   5afdf:	mov    rsi,rcx
   5afe2:	mov    rdx,rbx
   5afe5:	call   5afea <sqlite3VdbeExec+0xbb4a>
   5afea:	mov    rcx,rax
   5afed:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5aff8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b003:	mov    rax,QWORD PTR [rsp+0x108]
   5b00b:	mov    rdi,QWORD PTR [rsp+0x110]
   5b013:	mov    ebx,DWORD PTR [rsp+0x3ac]
   5b01a:	lea    r8,[rsp+0x178]
   5b022:	lea    r9,[rsp+0x1a0]
   5b02a:	test   rax,rax
   5b02d:	je     5b053 <sqlite3VdbeExec+0xbbb3>
   5b02f:	mov    DWORD PTR [rax],ebx
   5b031:	mov    QWORD PTR [rax+0x8],0x0
   5b039:	lea    rcx,[rax+0x20]
   5b03d:	mov    QWORD PTR [rax+0x18],rcx
   5b041:	mov    rcx,QWORD PTR [rax+0x18]
   5b045:	mov    rdx,rbx
   5b048:	imul   rdx,rdx,0x50
   5b04c:	add    rcx,rdx
   5b04f:	mov    QWORD PTR [rax+0x10],rcx
   5b053:	mov    QWORD PTR [r8],rax
   5b056:	mov    eax,0x7
   5b05b:	mov    ebx,DWORD PTR [rsp+0x39c]
   5b062:	cmp    QWORD PTR [r8],0x0
   5b066:	cmove  ebx,eax
   5b069:	mov    DWORD PTR [rsp+0x37c],r15d
   5b071:	mov    r15,r13
   5b074:	mov    r13,rbx
   5b077:	xor    ebx,ebx
   5b079:	xor    r11d,r11d
   5b07c:	mov    DWORD PTR [rsp+0x3ac],r11d
   5b084:	jmp    5b9a1 <sqlite3VdbeExec+0xc501>
   5b089:	mov    DWORD PTR [rsp+0x3a4],ebx
   5b090:	mov    ebx,DWORD PTR [rsp+0x3ac]
   5b097:	mov    r13,r15
   5b09a:	mov    r15d,DWORD PTR [rsp+0x37c]
   5b0a2:	mov    eax,0x10
   5b0a7:	mov    rcx,r9
   5b0aa:	mov    DWORD PTR [rsp+0x37c],r15d
   5b0b2:	lea    r15,[rsp+0x1a8]
   5b0ba:	mov    rdx,r15
   5b0bd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b0c8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b0d3:	mov    QWORD PTR [rsp+0x110],rdi
   5b0db:	mov    rdi,r12
   5b0de:	mov    rsi,rax
   5b0e1:	mov    r11,rdx
   5b0e4:	mov    rdx,rcx
   5b0e7:	mov    rcx,r11
   5b0ea:	call   5b0ef <sqlite3VdbeExec+0xbc4f>
   5b0ef:	mov    r15d,eax
   5b0f2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b0fd:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b108:	mov    rdi,QWORD PTR [rsp+0x110]
   5b110:	test   r15d,r15d
   5b113:	je     5b12a <sqlite3VdbeExec+0xbc8a>
   5b115:	lea    r8,[rsp+0x178]
   5b11d:	lea    r9,[rsp+0x1a0]
   5b125:	jmp    5b987 <sqlite3VdbeExec+0xc4e7>
   5b12a:	lea    r15d,[rbx+0x1]
   5b12e:	lea    r8,[rsp+0x178]
   5b136:	mov    DWORD PTR [rsp+0x3b0],r15d
   5b13e:	mov    r15,QWORD PTR [r8]
   5b141:	mov    QWORD PTR [rsp+0x1b0],r15
   5b149:	lea    r15,[rsp+0x1a8]
   5b151:	mov    r15,QWORD PTR [r15]
   5b154:	mov    eax,0x64
   5b159:	mov    rcx,QWORD PTR [rip+0x0]        # 5b160 <sqlite3VdbeExec+0xbcc0>
   5b160:	test   rcx,rcx
   5b163:	je     5b1bd <sqlite3VdbeExec+0xbd1d>
   5b165:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b170:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b17b:	mov    rdi,rax
   5b17e:	mov    r10,rcx
   5b181:	call   r10
   5b184:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b18f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b19a:	mov    rdi,QWORD PTR [rsp+0x110]
   5b1a2:	test   eax,eax
   5b1a4:	je     5b1bd <sqlite3VdbeExec+0xbd1d>
   5b1a6:	xor    eax,eax
   5b1a8:	lea    r8,[rsp+0x178]
   5b1b0:	lea    r9,[rsp+0x1a0]
   5b1b8:	jmp    5b283 <sqlite3VdbeExec+0xbde3>
   5b1bd:	mov    QWORD PTR [rsp+0x1b8],r15
   5b1c5:	mov    r15d,0x48
   5b1cb:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b1d6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b1e1:	mov    QWORD PTR [rsp+0x110],rdi
   5b1e9:	mov    rdi,r15
   5b1ec:	call   5b1f1 <sqlite3VdbeExec+0xbd51>
   5b1f1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b1fc:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b207:	mov    rdi,QWORD PTR [rsp+0x110]
   5b20f:	test   rax,rax
   5b212:	je     5b26b <sqlite3VdbeExec+0xbdcb>
   5b214:	xor    ecx,ecx
   5b216:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b221:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b22c:	mov    QWORD PTR [rsp+0x108],rax
   5b234:	mov    rdi,rax
   5b237:	mov    rsi,rcx
   5b23a:	mov    rdx,r15
   5b23d:	call   5b242 <sqlite3VdbeExec+0xbda2>
   5b242:	mov    rcx,rax
   5b245:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b250:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b25b:	mov    rax,QWORD PTR [rsp+0x108]
   5b263:	mov    rdi,QWORD PTR [rsp+0x110]
   5b26b:	mov    r15,QWORD PTR [rsp+0x1b8]
   5b273:	lea    r8,[rsp+0x178]
   5b27b:	lea    r9,[rsp+0x1a0]
   5b283:	mov    DWORD PTR [rsp+0x3ac],ebx
   5b28a:	lea    rbx,[rsp+0x1c0]
   5b292:	mov    QWORD PTR [rbx],rax
   5b295:	test   rax,rax
   5b298:	je     5b2fe <sqlite3VdbeExec+0xbe5e>
   5b29a:	mov    QWORD PTR [rax+0x8],r15
   5b29e:	mov    QWORD PTR [rax],r12
   5b2a1:	mov    rcx,QWORD PTR [r12+0x10]
   5b2a6:	mov    ecx,DWORD PTR [rcx+0x8]
   5b2a9:	add    ecx,0x9
   5b2ac:	mov    rdx,QWORD PTR [r12+0x10]
   5b2b1:	mov    edx,DWORD PTR [rdx+0x4]
   5b2b4:	mov    esi,edx
   5b2b6:	sar    esi,0x1f
   5b2b9:	and    esi,0x1
   5b2bc:	add    edx,esi
   5b2be:	sar    edx,1
   5b2c0:	cmp    ecx,edx
   5b2c2:	jle    5b2d1 <sqlite3VdbeExec+0xbe31>
   5b2c4:	mov    rcx,QWORD PTR [r12+0x10]
   5b2c9:	mov    ecx,DWORD PTR [rcx+0x8]
   5b2cc:	add    ecx,0x9
   5b2cf:	jmp    5b2e5 <sqlite3VdbeExec+0xbe45>
   5b2d1:	mov    rcx,QWORD PTR [r12+0x10]
   5b2d6:	mov    ecx,DWORD PTR [rcx+0x4]
   5b2d9:	mov    edx,ecx
   5b2db:	sar    edx,0x1f
   5b2de:	and    edx,0x1
   5b2e1:	add    ecx,edx
   5b2e3:	sar    ecx,1
   5b2e5:	mov    DWORD PTR [rax+0x18],ecx
   5b2e8:	mov    rcx,QWORD PTR [r12+0x58]
   5b2ed:	movsxd rax,DWORD PTR [rax+0x18]
   5b2f1:	add    rax,rcx
   5b2f4:	mov    QWORD PTR [r12+0x58],rax
   5b2f9:	xor    r15d,r15d
   5b2fc:	jmp    5b358 <sqlite3VdbeExec+0xbeb8>
   5b2fe:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b309:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b314:	mov    QWORD PTR [rsp+0x110],rdi
   5b31c:	mov    rdi,r15
   5b31f:	call   5b324 <sqlite3VdbeExec+0xbe84>
   5b324:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b32f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b33a:	mov    r15d,0x7
   5b340:	mov    rdi,QWORD PTR [rsp+0x110]
   5b348:	lea    r8,[rsp+0x178]
   5b350:	lea    r9,[rsp+0x1a0]
   5b358:	mov    eax,0x1
   5b35d:	xor    ecx,ecx
   5b35f:	mov    ebx,DWORD PTR [rsp+0x3a0]
   5b366:	movsxd rdx,ebx
   5b369:	sub    rdx,0x1
   5b36d:	cmp    ebx,0x1
   5b370:	cmovg  rcx,rdx
   5b374:	and    rcx,0xfffffffffffffff0
   5b378:	mov    edx,ecx
   5b37a:	add    edx,0x1
   5b37d:	test   rcx,rcx
   5b380:	jne    5b392 <sqlite3VdbeExec+0xbef2>
   5b382:	mov    DWORD PTR [rsp+0x3b4],r15d
   5b38a:	mov    r15d,0x1
   5b390:	jmp    5b3f3 <sqlite3VdbeExec+0xbf53>
   5b392:	vmovdqa64 zmm2,zmm1
   5b398:	vpmulld zmm2,zmm2,zmm0
   5b39e:	add    eax,0x10
   5b3a1:	cmp    eax,edx
   5b3a3:	jl     5b398 <sqlite3VdbeExec+0xbef8>
   5b3a5:	vextracti64x4 ymm15,zmm2,0x1
   5b3ac:	{evex} vpmulld ymm2,ymm2,ymm15
   5b3b2:	vextracti32x4 xmm15,ymm2,0x1
   5b3b9:	{evex} vpmulld xmm2,xmm2,xmm15
   5b3bf:	{evex} vpshufd xmm15,xmm2,0x4e
   5b3c6:	{evex} vpmulld xmm2,xmm2,xmm15
   5b3cc:	{evex} vpshufd xmm15,xmm2,0xb1
   5b3d3:	{evex} vpmulld xmm2,xmm2,xmm15
   5b3d9:	mov    DWORD PTR [rsp+0x3b4],r15d
   5b3e1:	{evex} vmovd r15d,xmm2
   5b3e7:	mov    rax,rdx
   5b3ea:	jmp    5b3f3 <sqlite3VdbeExec+0xbf53>
   5b3ec:	shl    r15d,0x4
   5b3f0:	add    eax,0x1
   5b3f3:	cmp    eax,ebx
   5b3f5:	jl     5b3ec <sqlite3VdbeExec+0xbf4c>
   5b3f7:	mov    QWORD PTR [rsp+0x128],r14
   5b3ff:	mov    DWORD PTR [rsp+0x3a0],ebx
   5b406:	mov    r14d,DWORD PTR [rsp+0x3b4]
   5b40e:	mov    rbx,r15
   5b411:	mov    r15,rbp
   5b414:	mov    ebp,0x1
   5b419:	jmp    5b7eb <sqlite3VdbeExec+0xc34b>
   5b41e:	add    ebp,ebp
   5b420:	cmp    ebp,0x10
   5b423:	jl     5b41e <sqlite3VdbeExec+0xbf7e>
   5b425:	mov    rax,rbp
   5b428:	imul   rax,rax,0x54
   5b42c:	mov    DWORD PTR [rsp+0x3a0],ebx
   5b433:	lea    rbx,[rax+0x20]
   5b437:	mov    eax,0x64
   5b43c:	mov    rcx,QWORD PTR [rip+0x0]        # 5b443 <sqlite3VdbeExec+0xbfa3>
   5b443:	test   rcx,rcx
   5b446:	je     5b4a8 <sqlite3VdbeExec+0xc008>
   5b448:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b453:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b45e:	mov    QWORD PTR [rsp+0x110],rdi
   5b466:	mov    rdi,rax
   5b469:	mov    r10,rcx
   5b46c:	call   r10
   5b46f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b47a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b485:	mov    rdi,QWORD PTR [rsp+0x110]
   5b48d:	test   eax,eax
   5b48f:	je     5b4a8 <sqlite3VdbeExec+0xc008>
   5b491:	xor    eax,eax
   5b493:	lea    r8,[rsp+0x178]
   5b49b:	lea    r9,[rsp+0x1a0]
   5b4a3:	jmp    5b558 <sqlite3VdbeExec+0xc0b8>
   5b4a8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b4b3:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b4be:	mov    QWORD PTR [rsp+0x110],rdi
   5b4c6:	mov    rdi,rbx
   5b4c9:	call   5b4ce <sqlite3VdbeExec+0xc02e>
   5b4ce:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b4d9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b4e4:	mov    rdi,QWORD PTR [rsp+0x110]
   5b4ec:	test   rax,rax
   5b4ef:	je     5b548 <sqlite3VdbeExec+0xc0a8>
   5b4f1:	xor    ecx,ecx
   5b4f3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b4fe:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b509:	mov    QWORD PTR [rsp+0x108],rax
   5b511:	mov    rdi,rax
   5b514:	mov    rsi,rcx
   5b517:	mov    rdx,rbx
   5b51a:	call   5b51f <sqlite3VdbeExec+0xc07f>
   5b51f:	mov    rcx,rax
   5b522:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b52d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b538:	mov    rax,QWORD PTR [rsp+0x108]
   5b540:	mov    rdi,QWORD PTR [rsp+0x110]
   5b548:	lea    r8,[rsp+0x178]
   5b550:	lea    r9,[rsp+0x1a0]
   5b558:	test   rax,rax
   5b55b:	je     5b581 <sqlite3VdbeExec+0xc0e1>
   5b55d:	mov    DWORD PTR [rax],ebp
   5b55f:	mov    QWORD PTR [rax+0x8],0x0
   5b567:	lea    rcx,[rax+0x20]
   5b56b:	mov    QWORD PTR [rax+0x18],rcx
   5b56f:	mov    rcx,QWORD PTR [rax+0x18]
   5b573:	mov    rdx,rbp
   5b576:	imul   rdx,rdx,0x50
   5b57a:	add    rcx,rdx
   5b57d:	mov    QWORD PTR [rax+0x10],rcx
   5b581:	mov    rbx,rax
   5b584:	test   rbx,rbx
   5b587:	jne    5b59b <sqlite3VdbeExec+0xc0fb>
   5b589:	mov    ebx,0x7
   5b58e:	mov    rbp,QWORD PTR [rsp+0x1b8]
   5b596:	jmp    5b790 <sqlite3VdbeExec+0xc2f0>
   5b59b:	xor    ebp,ebp
   5b59d:	mov    eax,0x64
   5b5a2:	mov    rcx,QWORD PTR [rip+0x0]        # 5b5a9 <sqlite3VdbeExec+0xc109>
   5b5a9:	test   rcx,rcx
   5b5ac:	je     5b60e <sqlite3VdbeExec+0xc16e>
   5b5ae:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b5b9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b5c4:	mov    QWORD PTR [rsp+0x110],rdi
   5b5cc:	mov    rdi,rax
   5b5cf:	mov    r10,rcx
   5b5d2:	call   r10
   5b5d5:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b5e0:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b5eb:	mov    rdi,QWORD PTR [rsp+0x110]
   5b5f3:	test   eax,eax
   5b5f5:	je     5b60e <sqlite3VdbeExec+0xc16e>
   5b5f7:	xor    eax,eax
   5b5f9:	lea    r8,[rsp+0x178]
   5b601:	lea    r9,[rsp+0x1a0]
   5b609:	jmp    5b6c3 <sqlite3VdbeExec+0xc223>
   5b60e:	mov    ebp,0x48
   5b613:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b61e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b629:	mov    QWORD PTR [rsp+0x110],rdi
   5b631:	mov    rdi,rbp
   5b634:	call   5b639 <sqlite3VdbeExec+0xc199>
   5b639:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b644:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b64f:	mov    rdi,QWORD PTR [rsp+0x110]
   5b657:	test   rax,rax
   5b65a:	je     5b6b3 <sqlite3VdbeExec+0xc213>
   5b65c:	xor    ecx,ecx
   5b65e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b669:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b674:	mov    QWORD PTR [rsp+0x108],rax
   5b67c:	mov    rdi,rax
   5b67f:	mov    rsi,rcx
   5b682:	mov    rdx,rbp
   5b685:	call   5b68a <sqlite3VdbeExec+0xc1ea>
   5b68a:	mov    rcx,rax
   5b68d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b698:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b6a3:	mov    rax,QWORD PTR [rsp+0x108]
   5b6ab:	mov    rdi,QWORD PTR [rsp+0x110]
   5b6b3:	lea    r8,[rsp+0x178]
   5b6bb:	lea    r9,[rsp+0x1a0]
   5b6c3:	mov    rbp,QWORD PTR [rsp+0x1b8]
   5b6cb:	mov    QWORD PTR [rbp+0x48],rax
   5b6cf:	test   rax,rax
   5b6d2:	je     5b737 <sqlite3VdbeExec+0xc297>
   5b6d4:	mov    QWORD PTR [rax+0x8],rbx
   5b6d8:	mov    QWORD PTR [rax],r12
   5b6db:	mov    rcx,QWORD PTR [r12+0x10]
   5b6e0:	mov    ecx,DWORD PTR [rcx+0x8]
   5b6e3:	add    ecx,0x9
   5b6e6:	mov    rdx,QWORD PTR [r12+0x10]
   5b6eb:	mov    edx,DWORD PTR [rdx+0x4]
   5b6ee:	mov    esi,edx
   5b6f0:	sar    esi,0x1f
   5b6f3:	and    esi,0x1
   5b6f6:	add    edx,esi
   5b6f8:	sar    edx,1
   5b6fa:	cmp    ecx,edx
   5b6fc:	jle    5b70b <sqlite3VdbeExec+0xc26b>
   5b6fe:	mov    rcx,QWORD PTR [r12+0x10]
   5b703:	mov    ecx,DWORD PTR [rcx+0x8]
   5b706:	add    ecx,0x9
   5b709:	jmp    5b71f <sqlite3VdbeExec+0xc27f>
   5b70b:	mov    rcx,QWORD PTR [r12+0x10]
   5b710:	mov    ecx,DWORD PTR [rcx+0x4]
   5b713:	mov    edx,ecx
   5b715:	sar    edx,0x1f
   5b718:	and    edx,0x1
   5b71b:	add    ecx,edx
   5b71d:	sar    ecx,1
   5b71f:	mov    DWORD PTR [rax+0x18],ecx
   5b722:	mov    rcx,QWORD PTR [r12+0x58]
   5b727:	movsxd rax,DWORD PTR [rax+0x18]
   5b72b:	add    rax,rcx
   5b72e:	mov    QWORD PTR [r12+0x58],rax
   5b733:	xor    ebx,ebx
   5b735:	jmp    5b790 <sqlite3VdbeExec+0xc2f0>
   5b737:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b742:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b74d:	mov    QWORD PTR [rsp+0x110],rdi
   5b755:	mov    rdi,rbx
   5b758:	call   5b75d <sqlite3VdbeExec+0xc2bd>
   5b75d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b768:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b773:	mov    ebx,0x7
   5b778:	mov    rdi,QWORD PTR [rsp+0x110]
   5b780:	lea    r8,[rsp+0x178]
   5b788:	lea    r9,[rsp+0x1a0]
   5b790:	test   ebx,ebx
   5b792:	je     5b7a4 <sqlite3VdbeExec+0xc304>
   5b794:	mov    DWORD PTR [rsp+0x3b4],ebx
   5b79b:	mov    ebx,DWORD PTR [rsp+0x3b8]
   5b7a2:	jmp    5b7d1 <sqlite3VdbeExec+0xc331>
   5b7a4:	mov    rax,QWORD PTR [rbp+0x48]
   5b7a8:	mov    rbp,QWORD PTR [rax+0x8]
   5b7ac:	mov    DWORD PTR [rsp+0x3b4],ebx
   5b7b3:	mov    ebx,DWORD PTR [rsp+0x3b8]
   5b7ba:	mov    eax,ebx
   5b7bc:	sar    eax,0x1f
   5b7bf:	and    eax,0xf
   5b7c2:	add    eax,ebx
   5b7c4:	mov    ebx,eax
   5b7c6:	sar    ebx,0x4
   5b7c9:	mov    QWORD PTR [rsp+0x1b0],rbp
   5b7d1:	mov    ebp,DWORD PTR [rsp+0x3bc]
   5b7d8:	add    ebp,0x1
   5b7db:	mov    QWORD PTR [rsp+0x128],r14
   5b7e3:	mov    r14d,DWORD PTR [rsp+0x3b4]
   5b7eb:	mov    QWORD PTR [rsp+0x170],r12
   5b7f3:	mov    r12d,DWORD PTR [rsp+0x3a0]
   5b7fb:	cmp    ebp,r12d
   5b7fe:	jl     5b814 <sqlite3VdbeExec+0xc374>
   5b800:	mov    rbx,QWORD PTR [rsp+0x1b0]
   5b808:	mov    ebp,DWORD PTR [rsp+0x3ac]
   5b80f:	jmp    5b8c9 <sqlite3VdbeExec+0xc429>
   5b814:	test   r14d,r14d
   5b817:	je     5b82d <sqlite3VdbeExec+0xc38d>
   5b819:	mov    rbx,QWORD PTR [rsp+0x1b0]
   5b821:	mov    ebp,DWORD PTR [rsp+0x3ac]
   5b828:	jmp    5b8c9 <sqlite3VdbeExec+0xc429>
   5b82d:	mov    DWORD PTR [rsp+0x3bc],ebp
   5b834:	mov    ebp,DWORD PTR [rsp+0x3ac]
   5b83b:	mov    rax,rbp
   5b83e:	cdq
   5b83f:	idiv   ebx
   5b841:	mov    ecx,eax
   5b843:	sar    ecx,0x1f
   5b846:	and    ecx,0xf
   5b849:	add    ecx,eax
   5b84b:	and    ecx,0xfffffff0
   5b84e:	sub    eax,ecx
   5b850:	mov    DWORD PTR [rsp+0x3b8],ebx
   5b857:	mov    rbx,QWORD PTR [rsp+0x1b0]
   5b85f:	mov    rcx,QWORD PTR [rbx+0x18]
   5b863:	movsxd rax,eax
   5b866:	imul   rax,rax,0x50
   5b86a:	lea    rbx,[rcx+rax*1]
   5b86e:	cmp    QWORD PTR [rcx+rax*1+0x48],0x0
   5b874:	je     5b899 <sqlite3VdbeExec+0xc3f9>
   5b876:	mov    DWORD PTR [rsp+0x3a0],r12d
   5b87e:	mov    rbp,rbx
   5b881:	mov    r12,QWORD PTR [rsp+0x170]
   5b889:	mov    rbx,r14
   5b88c:	mov    r14,QWORD PTR [rsp+0x128]
   5b894:	jmp    5b790 <sqlite3VdbeExec+0xc2f0>
   5b899:	mov    r14d,0x2
   5b89f:	mov    QWORD PTR [rsp+0x1b8],rbx
   5b8a7:	mov    rbx,r12
   5b8aa:	mov    DWORD PTR [rsp+0x3ac],ebp
   5b8b1:	mov    r12,QWORD PTR [rsp+0x170]
   5b8b9:	mov    rbp,r14
   5b8bc:	mov    r14,QWORD PTR [rsp+0x128]
   5b8c4:	jmp    5b420 <sqlite3VdbeExec+0xbf80>
   5b8c9:	test   r14d,r14d
   5b8cc:	jne    5b900 <sqlite3VdbeExec+0xc460>
   5b8ce:	mov    rax,QWORD PTR [rbx+0x18]
   5b8d2:	mov    ecx,ebp
   5b8d4:	sar    ecx,0x1f
   5b8d7:	and    ecx,0xf
   5b8da:	add    ecx,ebp
   5b8dc:	and    ecx,0xfffffff0
   5b8df:	mov    r11d,ecx
   5b8e2:	mov    ecx,ebp
   5b8e4:	sub    ecx,r11d
   5b8e7:	movsxd rcx,ecx
   5b8ea:	imul   rcx,rcx,0x50
   5b8ee:	lea    rbx,[rsp+0x1c0]
   5b8f6:	mov    rdx,QWORD PTR [rbx]
   5b8f9:	mov    QWORD PTR [rax+rcx*1+0x48],rdx
   5b8fe:	jmp    5b94f <sqlite3VdbeExec+0xc4af>
   5b900:	lea    rbx,[rsp+0x1c0]
   5b908:	mov    rax,QWORD PTR [rbx]
   5b90b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b916:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b921:	mov    QWORD PTR [rsp+0x110],rdi
   5b929:	mov    rdi,rax
   5b92c:	call   5b931 <sqlite3VdbeExec+0xc491>
   5b931:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b93c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b947:	mov    rdi,QWORD PTR [rsp+0x110]
   5b94f:	mov    ebx,r14d
   5b952:	mov    r14,QWORD PTR [rsp+0x128]
   5b95a:	mov    DWORD PTR [rsp+0x3a0],r12d
   5b962:	mov    r12,QWORD PTR [rsp+0x170]
   5b96a:	mov    rbp,r15
   5b96d:	mov    r15,rbx
   5b970:	mov    ebx,DWORD PTR [rsp+0x3b0]
   5b977:	lea    r8,[rsp+0x178]
   5b97f:	lea    r9,[rsp+0x1a0]
   5b987:	mov    DWORD PTR [rsp+0x3ac],ebx
   5b98e:	mov    ebx,DWORD PTR [rsp+0x3a4]
   5b995:	add    ebx,0x10
   5b998:	mov    r11,r15
   5b99b:	mov    r15,r13
   5b99e:	mov    r13,r11
   5b9a1:	cmp    ebx,DWORD PTR [r12+0xc]
   5b9a6:	jl     5b9bb <sqlite3VdbeExec+0xc51b>
   5b9a8:	mov    rbx,r15
   5b9ab:	mov    r15d,DWORD PTR [rsp+0x37c]
   5b9b3:	mov    r12,r13
   5b9b6:	jmp    5aeb7 <sqlite3VdbeExec+0xba17>
   5b9bb:	test   r13d,r13d
   5b9be:	je     5b9d3 <sqlite3VdbeExec+0xc533>
   5b9c0:	mov    rbx,r15
   5b9c3:	mov    r15d,DWORD PTR [rsp+0x37c]
   5b9cb:	mov    r12,r13
   5b9ce:	jmp    5aeb7 <sqlite3VdbeExec+0xba17>
   5b9d3:	lea    r13,[rsp+0x1a8]
   5b9db:	mov    QWORD PTR [r13+0x0],0x0
   5b9e3:	mov    eax,DWORD PTR [r12+0xc]
   5b9e8:	sub    eax,ebx
   5b9ea:	cmp    eax,0x10
   5b9ed:	jge    5b089 <sqlite3VdbeExec+0xbbe9>
   5b9f3:	mov    eax,DWORD PTR [r12+0xc]
   5b9f8:	sub    eax,ebx
   5b9fa:	mov    DWORD PTR [rsp+0x3a4],ebx
   5ba01:	mov    ebx,DWORD PTR [rsp+0x3ac]
   5ba08:	mov    r13,r15
   5ba0b:	mov    r15d,DWORD PTR [rsp+0x37c]
   5ba13:	jmp    5b0a7 <sqlite3VdbeExec+0xbc07>
   5ba18:	mov    rax,QWORD PTR [r8]
   5ba1b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ba26:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ba31:	mov    QWORD PTR [rsp+0x110],rdi
   5ba39:	mov    rdi,rax
   5ba3c:	call   5ba41 <sqlite3VdbeExec+0xc5a1>
   5ba41:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ba4c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ba57:	mov    rdi,QWORD PTR [rsp+0x110]
   5ba5f:	lea    r8,[rsp+0x178]
   5ba67:	lea    r9,[rsp+0x1a0]
   5ba6f:	mov    r13d,DWORD PTR [rsp+0x3a8]
   5ba77:	add    r13d,0x1
   5ba7b:	mov    DWORD PTR [rsp+0x37c],r15d
   5ba83:	mov    r15,QWORD PTR [rsp+0x180]
   5ba8b:	test   r12d,r12d
   5ba8e:	je     5baa2 <sqlite3VdbeExec+0xc602>
   5ba90:	mov    QWORD PTR [rsp+0x160],rbx
   5ba98:	mov    rbx,QWORD PTR [rsp+0x198]
   5baa0:	jmp    5bb1d <sqlite3VdbeExec+0xc67d>
   5baa2:	mov    QWORD PTR [rsp+0x160],rbx
   5baaa:	mov    rbx,QWORD PTR [rsp+0x198]
   5bab2:	movzx  eax,BYTE PTR [rbx+0x5b]
   5bab6:	cmp    r13d,eax
   5bab9:	jge    5bb1d <sqlite3VdbeExec+0xc67d>
   5babb:	lea    rax,[rbx+0x60]
   5babf:	movsxd rcx,r13d
   5bac2:	imul   rcx,rcx,0x68
   5bac6:	mov    DWORD PTR [rsp+0x3a8],r13d
   5bace:	lea    r13,[rbx+rcx*1+0x60]
   5bad3:	mov    QWORD PTR [r8],0x0
   5bada:	movsxd rax,DWORD PTR [rax+rcx*1+0xc]
   5badf:	xor    ecx,ecx
   5bae1:	mov    edx,0x10
   5bae6:	mov    QWORD PTR [rsp+0x180],r15
   5baee:	mov    r15d,DWORD PTR [rsp+0x37c]
   5baf6:	mov    DWORD PTR [rsp+0x39c],r12d
   5bafe:	mov    r12,r13
   5bb01:	mov    r13,rbx
   5bb04:	mov    rbx,QWORD PTR [rsp+0x160]
   5bb0c:	mov    r11,rdx
   5bb0f:	mov    rdx,rax
   5bb12:	mov    rax,rcx
   5bb15:	mov    rcx,r11
   5bb18:	jmp    5ae23 <sqlite3VdbeExec+0xb983>
   5bb1d:	test   r12d,r12d
   5bb20:	je     5bb40 <sqlite3VdbeExec+0xc6a0>
   5bb22:	mov    QWORD PTR [rsp+0x110],rdi
   5bb2a:	mov    rdi,r15
   5bb2d:	call   5bb32 <sqlite3VdbeExec+0xc692>
   5bb32:	xor    r13d,r13d
   5bb35:	mov    rdi,QWORD PTR [rsp+0x110]
   5bb3d:	mov    r15,r13
   5bb40:	lea    r13,[rsp+0x190]
   5bb48:	mov    QWORD PTR [r13+0x0],r15
   5bb4c:	test   r12d,r12d
   5bb4f:	jne    5bb90 <sqlite3VdbeExec+0xc6f0>
   5bb51:	mov    rax,QWORD PTR [r13+0x0]
   5bb55:	xor    ecx,ecx
   5bb57:	mov    r12,QWORD PTR [rsp+0x168]
   5bb5f:	mov    QWORD PTR [rsp+0x110],rdi
   5bb67:	mov    rdi,r12
   5bb6a:	mov    rsi,rax
   5bb6d:	mov    rdx,rcx
   5bb70:	call   5bb75 <sqlite3VdbeExec+0xc6d5>
   5bb75:	mov    r12d,eax
   5bb78:	mov    rax,QWORD PTR [r13+0x0]
   5bb7c:	mov    QWORD PTR [rbx+0x18],rax
   5bb80:	mov    QWORD PTR [r13+0x0],0x0
   5bb88:	mov    rdi,QWORD PTR [rsp+0x110]
   5bb90:	test   r12d,r12d
   5bb93:	je     5bbb1 <sqlite3VdbeExec+0xc711>
   5bb95:	mov    rax,QWORD PTR [r13+0x0]
   5bb99:	mov    QWORD PTR [rsp+0x110],rdi
   5bba1:	mov    rdi,rax
   5bba4:	call   5bba9 <sqlite3VdbeExec+0xc709>
   5bba9:	mov    rdi,QWORD PTR [rsp+0x110]
   5bbb1:	mov    ebx,r12d
   5bbb4:	mov    DWORD PTR [rsp+0x398],0x0
   5bbbf:	mov    r15d,DWORD PTR [rsp+0x37c]
   5bbc7:	mov    r12,rbx
   5bbca:	mov    rbx,QWORD PTR [rsp+0x160]
   5bbd2:	mov    r13,r12
   5bbd5:	mov    r12,QWORD PTR [rsp+0x188]
   5bbdd:	jmp    5bcbc <sqlite3VdbeExec+0xc81c>
   5bbe2:	mov    r13,QWORD PTR [r12+0x28]
   5bbe7:	mov    QWORD PTR [rsp+0x110],rdi
   5bbef:	mov    rdi,r13
   5bbf2:	call   5bbf7 <sqlite3VdbeExec+0xc757>
   5bbf7:	mov    rdi,QWORD PTR [rsp+0x110]
   5bbff:	test   eax,eax
   5bc01:	jne    5bc98 <sqlite3VdbeExec+0xc7f8>
   5bc07:	mov    DWORD PTR [rsp+0x398],0x0
   5bc12:	xor    eax,eax
   5bc14:	jmp    5bc92 <sqlite3VdbeExec+0xc7f2>
   5bc16:	mov    rcx,QWORD PTR [r13+0x88]
   5bc1d:	cmp    BYTE PTR [rcx+0x8],0x0
   5bc21:	jne    5bc96 <sqlite3VdbeExec+0xc7f6>
   5bc23:	mov    rax,QWORD PTR [rcx+0x50]
   5bc27:	movzx  edx,WORD PTR [rcx+0x1a]
   5bc2b:	mov    rsi,QWORD PTR [rcx+0x60]
   5bc2f:	movzx  r8d,WORD PTR [r13+0x56]
   5bc34:	shl    r8d,1
   5bc37:	movzx  esi,BYTE PTR [rsi+r8*1]
   5bc3c:	shl    esi,0x8
   5bc3f:	mov    rcx,QWORD PTR [rcx+0x60]
   5bc43:	movzx  r8d,WORD PTR [r13+0x56]
   5bc48:	shl    r8d,1
   5bc4b:	movzx  ecx,BYTE PTR [rcx+r8*1+0x1]
   5bc51:	or     esi,ecx
   5bc53:	and    edx,esi
   5bc55:	movzx  ecx,BYTE PTR [rax+rdx*1]
   5bc59:	shl    ecx,0x18
   5bc5c:	movzx  esi,BYTE PTR [rax+rdx*1+0x1]
   5bc61:	shl    esi,0x10
   5bc64:	or     ecx,esi
   5bc66:	movzx  esi,BYTE PTR [rax+rdx*1+0x2]
   5bc6b:	shl    esi,0x8
   5bc6e:	or     ecx,esi
   5bc70:	movzx  eax,BYTE PTR [rax+rdx*1+0x3]
   5bc75:	or     ecx,eax
   5bc77:	mov    QWORD PTR [rsp+0x110],rdi
   5bc7f:	mov    rdi,r13
   5bc82:	mov    rsi,rcx
   5bc85:	call   5bc8a <sqlite3VdbeExec+0xc7ea>
   5bc8a:	mov    rdi,QWORD PTR [rsp+0x110]
   5bc92:	test   eax,eax
   5bc94:	je     5bc16 <sqlite3VdbeExec+0xc776>
   5bc96:	jmp    5bcaa <sqlite3VdbeExec+0xc80a>
   5bc98:	cmp    eax,0x10
   5bc9b:	jne    5bcaa <sqlite3VdbeExec+0xc80a>
   5bc9d:	mov    DWORD PTR [rsp+0x398],0x1
   5bca8:	xor    eax,eax
   5bcaa:	mov    r13d,eax
   5bcad:	mov    BYTE PTR [r12+0x3],0x0
   5bcb3:	mov    DWORD PTR [r12+0x18],0x0
   5bcbc:	test   r13d,r13d
   5bcbf:	je     5bce1 <sqlite3VdbeExec+0xc841>
   5bcc1:	mov    QWORD PTR [rsp+0x148],rbp
   5bcc9:	mov    rbp,r13
   5bccc:	mov    r13,QWORD PTR [rsp+0x130]
   5bcd4:	mov    rbx,QWORD PTR [rsp+0x158]
   5bcdc:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5bce1:	mov    eax,DWORD PTR [rsp+0x398]
   5bce8:	mov    BYTE PTR [r12+0x2],al
   5bced:	cmp    DWORD PTR [rbp+0x8],0x0
   5bcf1:	jle    5bd0d <sqlite3VdbeExec+0xc86d>
   5bcf3:	cmp    DWORD PTR [rsp+0x398],0x0
   5bcfb:	je     5bd0d <sqlite3VdbeExec+0xc86d>
   5bcfd:	mov    r12,r14
   5bd00:	mov    DWORD PTR [rsp+0x38c],r13d
   5bd08:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   5bd0d:	mov    DWORD PTR [rsp+0x37c],r15d
   5bd15:	mov    DWORD PTR [rsp+0x38c],r13d
   5bd1d:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5bd22:	mov    r15d,DWORD PTR [rsp+0x37c]
   5bd2a:	mov    QWORD PTR [rsp+0x130],r12
   5bd32:	mov    rax,QWORD PTR [rdi+0x78]
   5bd36:	movsxd rcx,DWORD PTR [rbp+0x4]
   5bd3a:	mov    rax,QWORD PTR [rax+rcx*8]
   5bd3e:	mov    rax,QWORD PTR [rax+0x28]
   5bd42:	cmp    BYTE PTR [rax],0x0
   5bd45:	jne    5bd57 <sqlite3VdbeExec+0xc8b7>
   5bd47:	mov    DWORD PTR [rsp+0x398],0x0
   5bd52:	xor    r12d,r12d
   5bd55:	jmp    5bd93 <sqlite3VdbeExec+0xc8f3>
   5bd57:	mov    QWORD PTR [rsp+0x110],rdi
   5bd5f:	mov    rdi,rax
   5bd62:	call   5bd67 <sqlite3VdbeExec+0xc8c7>
   5bd67:	mov    r12d,eax
   5bd6a:	mov    rdi,QWORD PTR [rsp+0x110]
   5bd72:	cmp    r12d,0x10
   5bd76:	jne    5bd88 <sqlite3VdbeExec+0xc8e8>
   5bd78:	mov    DWORD PTR [rsp+0x398],0x1
   5bd83:	xor    r12d,r12d
   5bd86:	jmp    5bd93 <sqlite3VdbeExec+0xc8f3>
   5bd88:	mov    DWORD PTR [rsp+0x398],0x0
   5bd93:	test   r12d,r12d
   5bd96:	je     5bdb8 <sqlite3VdbeExec+0xc918>
   5bd98:	mov    QWORD PTR [rsp+0x148],rbp
   5bda0:	mov    rbp,r12
   5bda3:	mov    r13,QWORD PTR [rsp+0x130]
   5bdab:	mov    rbx,QWORD PTR [rsp+0x158]
   5bdb3:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5bdb8:	cmp    DWORD PTR [rsp+0x398],0x0
   5bdc0:	je     5bdd2 <sqlite3VdbeExec+0xc932>
   5bdc2:	mov    DWORD PTR [rsp+0x38c],r12d
   5bdca:	mov    r12,r14
   5bdcd:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   5bdd2:	mov    DWORD PTR [rsp+0x37c],r15d
   5bdda:	mov    DWORD PTR [rsp+0x38c],r12d
   5bde2:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5bde7:	mov    r15d,DWORD PTR [rsp+0x37c]
   5bdef:	mov    QWORD PTR [rsp+0x130],r12
   5bdf7:	mov    rax,QWORD PTR [rdi+0x78]
   5bdfb:	movsxd rcx,DWORD PTR [rbp+0x4]
   5bdff:	mov    r12,QWORD PTR [rax+rcx*8]
   5be03:	mov    r13,QWORD PTR [r12+0x28]
   5be08:	cmp    BYTE PTR [r13+0x58],0x0
   5be0d:	je     5be5c <sqlite3VdbeExec+0xc9bc>
   5be0f:	mov    QWORD PTR [rsp+0x188],r12
   5be17:	lea    r12,[rsp+0x398]
   5be1f:	mov    DWORD PTR [r12],0x0
   5be27:	mov    rax,QWORD PTR [r13+0x18]
   5be2b:	mov    rcx,r12
   5be2e:	mov    QWORD PTR [rsp+0x110],rdi
   5be36:	mov    rdi,rax
   5be39:	mov    rsi,rcx
   5be3c:	call   5be41 <sqlite3VdbeExec+0xc9a1>
   5be41:	mov    rdi,QWORD PTR [rsp+0x110]
   5be49:	test   eax,eax
   5be4b:	jne    5be5a <sqlite3VdbeExec+0xc9ba>
   5be4d:	mov    ecx,0x65
   5be52:	cmp    DWORD PTR [r12],0x0
   5be57:	cmovne eax,ecx
   5be5a:	jmp    5becf <sqlite3VdbeExec+0xca2f>
   5be5c:	mov    QWORD PTR [rsp+0x188],r12
   5be64:	mov    r12,QWORD PTR [r13+0x38]
   5be68:	mov    rax,QWORD PTR [r12+0x8]
   5be6d:	mov    QWORD PTR [r13+0x38],rax
   5be71:	mov    QWORD PTR [r12+0x8],0x0
   5be7a:	cmp    QWORD PTR [r13+0x40],0x0
   5be7f:	jne    5bec0 <sqlite3VdbeExec+0xca20>
   5be81:	jmp    5bebb <sqlite3VdbeExec+0xca1b>
   5be83:	mov    QWORD PTR [rsp+0x190],r13
   5be8b:	mov    r13,QWORD PTR [r12+0x8]
   5be90:	test   r12,r12
   5be93:	je     5beb0 <sqlite3VdbeExec+0xca10>
   5be95:	mov    QWORD PTR [rsp+0x110],rdi
   5be9d:	mov    rdi,r14
   5bea0:	mov    rsi,r12
   5bea3:	call   5bea8 <sqlite3VdbeExec+0xca08>
   5bea8:	mov    rdi,QWORD PTR [rsp+0x110]
   5beb0:	mov    r12,r13
   5beb3:	mov    r13,QWORD PTR [rsp+0x190]
   5bebb:	test   r12,r12
   5bebe:	jne    5be83 <sqlite3VdbeExec+0xc9e3>
   5bec0:	xor    eax,eax
   5bec2:	mov    ecx,0x65
   5bec7:	cmp    QWORD PTR [r13+0x38],0x0
   5becc:	cmove  eax,ecx
   5becf:	mov    r12d,eax
   5bed2:	mov    r13,r12
   5bed5:	mov    r12,QWORD PTR [rsp+0x188]
   5bedd:	jmp    5bf9e <sqlite3VdbeExec+0xcafe>
   5bee2:	mov    r15d,DWORD PTR [rsp+0x37c]
   5beea:	mov    QWORD PTR [rsp+0x130],r12
   5bef2:	mov    rax,QWORD PTR [rdi+0x78]
   5bef6:	movsxd rcx,DWORD PTR [rbp+0x4]
   5befa:	mov    r12,QWORD PTR [rax+rcx*8]
   5befe:	mov    rax,QWORD PTR [r12+0x28]
   5bf03:	mov    ecx,DWORD PTR [rbp+0xc]
   5bf06:	movzx  ecx,BYTE PTR [rax+0x1]
   5bf0a:	and    ecx,0xfffffff1
   5bf0d:	mov    BYTE PTR [rax+0x1],cl
   5bf10:	mov    WORD PTR [rax+0x46],0x0
   5bf16:	cmp    BYTE PTR [rax],0x0
   5bf19:	jne    5bf2f <sqlite3VdbeExec+0xca8f>
   5bf1b:	cmp    WORD PTR [rax+0x56],0x0
   5bf20:	je     5bf2f <sqlite3VdbeExec+0xca8f>
   5bf22:	mov    rcx,QWORD PTR [rax+0x88]
   5bf29:	cmp    BYTE PTR [rcx+0x8],0x0
   5bf2d:	jne    5bf4c <sqlite3VdbeExec+0xcaac>
   5bf2f:	mov    QWORD PTR [rsp+0x110],rdi
   5bf37:	mov    rdi,rax
   5bf3a:	call   5bf3f <sqlite3VdbeExec+0xca9f>
   5bf3f:	mov    r13d,eax
   5bf42:	mov    rdi,QWORD PTR [rsp+0x110]
   5bf4a:	jmp    5bf5a <sqlite3VdbeExec+0xcaba>
   5bf4c:	movzx  ecx,WORD PTR [rax+0x56]
   5bf50:	sub    ecx,0x1
   5bf53:	mov    WORD PTR [rax+0x56],cx
   5bf57:	xor    r13d,r13d
   5bf5a:	jmp    5bf9e <sqlite3VdbeExec+0xcafe>
   5bf5c:	mov    r15d,DWORD PTR [rsp+0x37c]
   5bf64:	mov    QWORD PTR [rsp+0x130],r12
   5bf6c:	mov    rax,QWORD PTR [rdi+0x78]
   5bf70:	movsxd rcx,DWORD PTR [rbp+0x4]
   5bf74:	mov    r12,QWORD PTR [rax+rcx*8]
   5bf78:	mov    rax,QWORD PTR [r12+0x28]
   5bf7d:	mov    ecx,DWORD PTR [rbp+0xc]
   5bf80:	mov    QWORD PTR [rsp+0x110],rdi
   5bf88:	mov    rdi,rax
   5bf8b:	mov    rsi,rcx
   5bf8e:	call   5bf93 <sqlite3VdbeExec+0xcaf3>
   5bf93:	mov    r13d,eax
   5bf96:	mov    rdi,QWORD PTR [rsp+0x110]
   5bf9e:	mov    DWORD PTR [r12+0x18],0x0
   5bfa7:	test   r13d,r13d
   5bfaa:	jne    5bfe4 <sqlite3VdbeExec+0xcb44>
   5bfac:	mov    BYTE PTR [r12+0x2],0x0
   5bfb2:	movzx  eax,WORD PTR [rbp+0x2]
   5bfb6:	mov    ecx,DWORD PTR [rdi+rax*4+0xd4]
   5bfbd:	add    ecx,0x1
   5bfc0:	mov    DWORD PTR [rdi+rax*4+0xd4],ecx
   5bfc7:	mov    r12d,DWORD PTR [rsp+0x394]
   5bfcf:	mov    DWORD PTR [rsp+0x38c],r13d
   5bfd7:	mov    r13,QWORD PTR [rsp+0x150]
   5bfdf:	jmp    4f7bd <sqlite3VdbeExec+0x31d>
   5bfe4:	cmp    r13d,0x65
   5bfe8:	je     5c00a <sqlite3VdbeExec+0xcb6a>
   5bfea:	mov    QWORD PTR [rsp+0x148],rbp
   5bff2:	mov    rbp,r13
   5bff5:	mov    r13,QWORD PTR [rsp+0x130]
   5bffd:	mov    rbx,QWORD PTR [rsp+0x158]
   5c005:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c00a:	mov    r13,rbx
   5c00d:	mov    ebx,DWORD PTR [rsp+0x390]
   5c014:	mov    BYTE PTR [r12+0x2],0x1
   5c01a:	mov    r12d,DWORD PTR [rsp+0x394]
   5c022:	mov    QWORD PTR [rsp+0x148],rbp
   5c02a:	mov    QWORD PTR [rsp+0x160],r13
   5c032:	mov    r13,QWORD PTR [rsp+0x150]
   5c03a:	xor    r11d,r11d
   5c03d:	mov    DWORD PTR [rsp+0x38c],r11d
   5c045:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   5c04a:	mov    r15d,DWORD PTR [rsp+0x37c]
   5c052:	mov    r13,rbx
   5c055:	mov    ebx,DWORD PTR [rsp+0x390]
   5c05c:	mov    QWORD PTR [rsp+0x130],r12
   5c064:	mov    rax,QWORD PTR [rdi+0x78]
   5c068:	movsxd rcx,DWORD PTR [rbp+0x4]
   5c06c:	mov    r12,QWORD PTR [rax+rcx*8]
   5c070:	movsxd rax,DWORD PTR [rbp+0x8]
   5c074:	imul   rax,rax,0x38
   5c078:	mov    DWORD PTR [rsp+0x390],ebx
   5c07f:	lea    rbx,[r13+rax*1+0x0]
   5c084:	movzx  eax,WORD PTR [rbp+0x2]
   5c088:	and    eax,0x1
   5c08b:	test   eax,eax
   5c08d:	je     5c09b <sqlite3VdbeExec+0xcbfb>
   5c08f:	mov    rax,QWORD PTR [rdi+0x38]
   5c093:	add    rax,0x1
   5c097:	mov    QWORD PTR [rdi+0x38],rax
   5c09b:	movzx  eax,WORD PTR [rbx+0x14]
   5c09f:	and    eax,0x400
   5c0a4:	test   eax,eax
   5c0a6:	je     5c15e <sqlite3VdbeExec+0xccbe>
   5c0ac:	mov    eax,DWORD PTR [rbx+0x10]
   5c0af:	add    eax,DWORD PTR [rbx]
   5c0b1:	test   eax,eax
   5c0b3:	jg     5c0d2 <sqlite3VdbeExec+0xcc32>
   5c0b5:	movzx  eax,WORD PTR [rbx+0x14]
   5c0b9:	and    eax,0x10
   5c0bc:	test   eax,eax
   5c0be:	jne    5c0cd <sqlite3VdbeExec+0xcc2d>
   5c0c0:	xor    r11d,r11d
   5c0c3:	mov    DWORD PTR [rsp+0x398],r11d
   5c0cb:	jmp    5c14c <sqlite3VdbeExec+0xccac>
   5c0cd:	mov    eax,0x1
   5c0d2:	mov    ecx,0x1
   5c0d7:	mov    QWORD PTR [rsp+0x110],rdi
   5c0df:	mov    rdi,rbx
   5c0e2:	mov    rsi,rax
   5c0e5:	mov    rdx,rcx
   5c0e8:	call   5c0ed <sqlite3VdbeExec+0xcc4d>
   5c0ed:	mov    rdi,QWORD PTR [rsp+0x110]
   5c0f5:	test   eax,eax
   5c0f7:	je     5c109 <sqlite3VdbeExec+0xcc69>
   5c0f9:	mov    r11d,0x7
   5c0ff:	mov    DWORD PTR [rsp+0x398],r11d
   5c107:	jmp    5c14c <sqlite3VdbeExec+0xccac>
   5c109:	mov    rax,QWORD PTR [rbx+0x8]
   5c10d:	movsxd rcx,DWORD PTR [rbx+0x10]
   5c111:	add    rax,rcx
   5c114:	xor    ecx,ecx
   5c116:	movsxd rdx,DWORD PTR [rbx]
   5c119:	mov    rdi,rax
   5c11c:	mov    rsi,rcx
   5c11f:	call   5c124 <sqlite3VdbeExec+0xcc84>
   5c124:	mov    eax,DWORD PTR [rbx+0x10]
   5c127:	add    eax,DWORD PTR [rbx]
   5c129:	mov    DWORD PTR [rbx+0x10],eax
   5c12c:	movzx  eax,WORD PTR [rbx+0x14]
   5c130:	and    eax,0xfffff9ff
   5c135:	mov    WORD PTR [rbx+0x14],ax
   5c139:	mov    rdi,QWORD PTR [rsp+0x110]
   5c141:	xor    r11d,r11d
   5c144:	mov    DWORD PTR [rsp+0x398],r11d
   5c14c:	mov    QWORD PTR [rsp+0x128],r14
   5c154:	mov    r14d,DWORD PTR [rsp+0x398]
   5c15c:	jmp    5c169 <sqlite3VdbeExec+0xccc9>
   5c15e:	mov    QWORD PTR [rsp+0x128],r14
   5c166:	xor    r14d,r14d
   5c169:	test   r14d,r14d
   5c16c:	je     5c196 <sqlite3VdbeExec+0xccf6>
   5c16e:	mov    QWORD PTR [rsp+0x148],rbp
   5c176:	mov    rbp,r14
   5c179:	mov    r14,QWORD PTR [rsp+0x128]
   5c181:	mov    r13,QWORD PTR [rsp+0x130]
   5c189:	mov    rbx,QWORD PTR [rsp+0x158]
   5c191:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c196:	movsxd rax,DWORD PTR [rbx+0x10]
   5c19a:	mov    QWORD PTR [rsp+0x218],rax
   5c1a2:	mov    rax,QWORD PTR [rbx+0x8]
   5c1a6:	mov    QWORD PTR [rsp+0x210],rax
   5c1ae:	movsxd rax,DWORD PTR [rbp+0xc]
   5c1b2:	imul   rax,rax,0x38
   5c1b6:	add    rax,r13
   5c1b9:	mov    QWORD PTR [rsp+0x228],rax
   5c1c1:	mov    eax,DWORD PTR [rbp+0x10]
   5c1c4:	mov    WORD PTR [rsp+0x230],ax
   5c1cc:	mov    rax,QWORD PTR [r12+0x28]
   5c1d1:	lea    rbx,[rsp+0x210]
   5c1d9:	mov    rcx,rbx
   5c1dc:	movzx  edx,WORD PTR [rbp+0x2]
   5c1e0:	and    edx,0x8a
   5c1e6:	movzx  esi,WORD PTR [rbp+0x2]
   5c1ea:	and    esi,0x10
   5c1ed:	test   esi,esi
   5c1ef:	je     5c1f8 <sqlite3VdbeExec+0xcd58>
   5c1f1:	mov    esi,DWORD PTR [r12+0x1c]
   5c1f6:	jmp    5c1fa <sqlite3VdbeExec+0xcd5a>
   5c1f8:	xor    esi,esi
   5c1fa:	mov    QWORD PTR [rsp+0x110],rdi
   5c202:	mov    rdi,rax
   5c205:	mov    r11,rsi
   5c208:	mov    rsi,rcx
   5c20b:	mov    rcx,r11
   5c20e:	call   5c213 <sqlite3VdbeExec+0xcd73>
   5c213:	mov    r14d,eax
   5c216:	mov    DWORD PTR [r12+0x18],0x0
   5c21f:	mov    rdi,QWORD PTR [rsp+0x110]
   5c227:	test   r14d,r14d
   5c22a:	je     5c254 <sqlite3VdbeExec+0xcdb4>
   5c22c:	mov    QWORD PTR [rsp+0x148],rbp
   5c234:	mov    rbp,r14
   5c237:	mov    r14,QWORD PTR [rsp+0x128]
   5c23f:	mov    r13,QWORD PTR [rsp+0x130]
   5c247:	mov    rbx,QWORD PTR [rsp+0x158]
   5c24f:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c254:	mov    DWORD PTR [rsp+0x37c],r15d
   5c25c:	mov    DWORD PTR [rsp+0x38c],r14d
   5c264:	mov    r14,QWORD PTR [rsp+0x128]
   5c26c:	mov    rbx,r13
   5c26f:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5c274:	mov    QWORD PTR [rsp+0x128],r14
   5c27c:	mov    r15d,DWORD PTR [rsp+0x37c]
   5c284:	mov    r13,rbx
   5c287:	mov    QWORD PTR [rsp+0x130],r12
   5c28f:	mov    rax,QWORD PTR [rdi+0x78]
   5c293:	movsxd rcx,DWORD PTR [rbp+0x4]
   5c297:	mov    r12,QWORD PTR [rax+rcx*8]
   5c29b:	movsxd rax,DWORD PTR [rbp+0x8]
   5c29f:	imul   rax,rax,0x38
   5c2a3:	lea    r14,[r13+rax*1+0x0]
   5c2a8:	movzx  eax,WORD PTR [r13+rax*1+0x14]
   5c2ae:	and    eax,0x400
   5c2b3:	test   eax,eax
   5c2b5:	je     5c34a <sqlite3VdbeExec+0xceaa>
   5c2bb:	mov    eax,DWORD PTR [r14+0x10]
   5c2bf:	add    eax,DWORD PTR [r14]
   5c2c2:	test   eax,eax
   5c2c4:	jg     5c2db <sqlite3VdbeExec+0xce3b>
   5c2c6:	movzx  eax,WORD PTR [r14+0x14]
   5c2cb:	and    eax,0x10
   5c2ce:	test   eax,eax
   5c2d0:	jne    5c2d6 <sqlite3VdbeExec+0xce36>
   5c2d2:	xor    ebx,ebx
   5c2d4:	jmp    5c348 <sqlite3VdbeExec+0xcea8>
   5c2d6:	mov    eax,0x1
   5c2db:	mov    ecx,0x1
   5c2e0:	mov    QWORD PTR [rsp+0x110],rdi
   5c2e8:	mov    rdi,r14
   5c2eb:	mov    rsi,rax
   5c2ee:	mov    rdx,rcx
   5c2f1:	call   5c2f6 <sqlite3VdbeExec+0xce56>
   5c2f6:	mov    rdi,QWORD PTR [rsp+0x110]
   5c2fe:	test   eax,eax
   5c300:	je     5c309 <sqlite3VdbeExec+0xce69>
   5c302:	mov    ebx,0x7
   5c307:	jmp    5c348 <sqlite3VdbeExec+0xcea8>
   5c309:	mov    rax,QWORD PTR [r14+0x8]
   5c30d:	movsxd rcx,DWORD PTR [r14+0x10]
   5c311:	add    rax,rcx
   5c314:	xor    ecx,ecx
   5c316:	movsxd rdx,DWORD PTR [r14]
   5c319:	mov    rdi,rax
   5c31c:	mov    rsi,rcx
   5c31f:	call   5c324 <sqlite3VdbeExec+0xce84>
   5c324:	mov    eax,DWORD PTR [r14+0x10]
   5c328:	add    eax,DWORD PTR [r14]
   5c32b:	mov    DWORD PTR [r14+0x10],eax
   5c32f:	movzx  eax,WORD PTR [r14+0x14]
   5c334:	and    eax,0xfffff9ff
   5c339:	mov    WORD PTR [r14+0x14],ax
   5c33e:	xor    ebx,ebx
   5c340:	mov    rdi,QWORD PTR [rsp+0x110]
   5c348:	jmp    5c34c <sqlite3VdbeExec+0xceac>
   5c34a:	xor    ebx,ebx
   5c34c:	test   ebx,ebx
   5c34e:	je     5c378 <sqlite3VdbeExec+0xced8>
   5c350:	mov    r14,QWORD PTR [rsp+0x128]
   5c358:	mov    QWORD PTR [rsp+0x148],rbp
   5c360:	mov    rbp,rbx
   5c363:	mov    r13,QWORD PTR [rsp+0x130]
   5c36b:	mov    rbx,QWORD PTR [rsp+0x158]
   5c373:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c378:	xor    ebx,ebx
   5c37a:	mov    r12,QWORD PTR [r12+0x28]
   5c37f:	mov    rax,QWORD PTR [r14+0x8]
   5c383:	movzx  eax,BYTE PTR [rax+0x1]
   5c387:	mov    DWORD PTR [rsp+0x398],eax
   5c38e:	cmp    DWORD PTR [rsp+0x398],0x80
   5c399:	jge    5c3a8 <sqlite3VdbeExec+0xcf08>
   5c39b:	lea    rbx,[rsp+0x398]
   5c3a3:	jmp    5c47a <sqlite3VdbeExec+0xcfda>
   5c3a8:	mov    rax,QWORD PTR [r14+0x8]
   5c3ac:	lea    rcx,[rax+0x1]
   5c3b0:	movzx  eax,BYTE PTR [rax+0x2]
   5c3b4:	and    eax,0x80
   5c3b9:	test   eax,eax
   5c3bb:	jne    5c3db <sqlite3VdbeExec+0xcf3b>
   5c3bd:	movzx  eax,BYTE PTR [rcx]
   5c3c0:	and    eax,0x7f
   5c3c3:	shl    eax,0x7
   5c3c6:	movzx  ecx,BYTE PTR [rcx+0x1]
   5c3ca:	or     eax,ecx
   5c3cc:	lea    rbx,[rsp+0x398]
   5c3d4:	mov    DWORD PTR [rbx],eax
   5c3d6:	jmp    5c47a <sqlite3VdbeExec+0xcfda>
   5c3db:	lea    rbx,[rsp+0x398]
   5c3e3:	movzx  eax,BYTE PTR [rcx+0x2]
   5c3e7:	and    eax,0x80
   5c3ec:	test   eax,eax
   5c3ee:	jne    5c40f <sqlite3VdbeExec+0xcf6f>
   5c3f0:	movzx  eax,BYTE PTR [rcx]
   5c3f3:	and    eax,0x7f
   5c3f6:	shl    eax,0xe
   5c3f9:	movzx  edx,BYTE PTR [rcx+0x1]
   5c3fd:	and    edx,0x7f
   5c400:	shl    edx,0x7
   5c403:	or     eax,edx
   5c405:	movzx  ecx,BYTE PTR [rcx+0x2]
   5c409:	or     eax,ecx
   5c40b:	mov    DWORD PTR [rbx],eax
   5c40d:	jmp    5c47a <sqlite3VdbeExec+0xcfda>
   5c40f:	mov    rbx,rbp
   5c412:	lea    rbp,[rsp+0x190]
   5c41a:	mov    rax,rbp
   5c41d:	mov    QWORD PTR [rsp+0x110],rdi
   5c425:	mov    rdi,rcx
   5c428:	mov    rsi,rax
   5c42b:	call   5c430 <sqlite3VdbeExec+0xcf90>
   5c430:	movzx  eax,al
   5c433:	mov    eax,0xffffffff
   5c438:	and    rax,QWORD PTR [rbp+0x0]
   5c43c:	mov    rdi,QWORD PTR [rsp+0x110]
   5c444:	cmp    rax,QWORD PTR [rbp+0x0]
   5c448:	je     5c464 <sqlite3VdbeExec+0xcfc4>
   5c44a:	lea    rbp,[rsp+0x398]
   5c452:	mov    DWORD PTR [rbp+0x0],0xffffffff
   5c459:	mov    r11,rbx
   5c45c:	mov    rbx,rbp
   5c45f:	mov    rbp,r11
   5c462:	jmp    5c47a <sqlite3VdbeExec+0xcfda>
   5c464:	mov    r11,rbx
   5c467:	mov    rbx,rbp
   5c46a:	mov    rbp,r11
   5c46d:	mov    rax,QWORD PTR [rbx]
   5c470:	lea    rbx,[rsp+0x398]
   5c478:	mov    DWORD PTR [rbx],eax
   5c47a:	cmp    DWORD PTR [rbx],0x0
   5c47d:	jle    5c499 <sqlite3VdbeExec+0xcff9>
   5c47f:	cmp    DWORD PTR [rbx],0xa
   5c482:	jge    5c499 <sqlite3VdbeExec+0xcff9>
   5c484:	cmp    DWORD PTR [rbx],0x7
   5c487:	je     5c499 <sqlite3VdbeExec+0xcff9>
   5c489:	movzx  eax,BYTE PTR [r12+0x5c]
   5c48f:	and    eax,0x1
   5c492:	mov    BYTE PTR [r12+0x5c],al
   5c497:	jmp    5c4bd <sqlite3VdbeExec+0xd01d>
   5c499:	cmp    DWORD PTR [rbx],0xa
   5c49c:	jle    5c4b7 <sqlite3VdbeExec+0xd017>
   5c49e:	mov    eax,DWORD PTR [rbx]
   5c4a0:	and    eax,0x1
   5c4a3:	test   eax,eax
   5c4a5:	je     5c4b7 <sqlite3VdbeExec+0xd017>
   5c4a7:	movzx  eax,BYTE PTR [r12+0x5c]
   5c4ad:	and    eax,0x2
   5c4b0:	mov    BYTE PTR [r12+0x5c],al
   5c4b5:	jmp    5c4bd <sqlite3VdbeExec+0xd01d>
   5c4b7:	mov    BYTE PTR [r12+0x5c],0x0
   5c4bd:	movsxd rax,DWORD PTR [r14+0x10]
   5c4c1:	lea    rbx,[rax+0x10]
   5c4c5:	mov    eax,DWORD PTR [r14+0x10]
   5c4c9:	movsxd rcx,DWORD PTR [r14+0x10]
   5c4cd:	mov    edx,0x1
   5c4d2:	mov    r11,rdx
   5c4d5:	mov    rdx,rcx
   5c4d8:	mov    rcx,r11
   5c4db:	jmp    5c4e0 <sqlite3VdbeExec+0xd040>
   5c4dd:	add    ecx,0x1
   5c4e0:	shr    rdx,0x7
   5c4e4:	test   rdx,rdx
   5c4e7:	jne    5c4dd <sqlite3VdbeExec+0xd03d>
   5c4e9:	add    eax,ecx
   5c4eb:	mov    QWORD PTR [rsp+0x188],r14
   5c4f3:	movsxd r14,eax
   5c4f6:	cmp    DWORD PTR [r12+0x4],0x0
   5c4fc:	jne    5c50b <sqlite3VdbeExec+0xd06b>
   5c4fe:	xor    r11d,r11d
   5c501:	mov    DWORD PTR [rsp+0x39c],r11d
   5c509:	jmp    5c587 <sqlite3VdbeExec+0xd0e7>
   5c50b:	cmp    QWORD PTR [r12+0x40],0x0
   5c511:	je     5c64e <sqlite3VdbeExec+0xd1ae>
   5c517:	cmp    DWORD PTR [r12+0x50],0x0
   5c51d:	je     5c63e <sqlite3VdbeExec+0xd19e>
   5c523:	movsxd rax,DWORD PTR [r12+0x50]
   5c528:	add    rax,rbx
   5c52b:	movsxd rcx,DWORD PTR [r12+0x4]
   5c530:	cmp    rax,rcx
   5c533:	jg     5c542 <sqlite3VdbeExec+0xd0a2>
   5c535:	xor    r11d,r11d
   5c538:	mov    DWORD PTR [rsp+0x39c],r11d
   5c540:	jmp    5c587 <sqlite3VdbeExec+0xd0e7>
   5c542:	mov    QWORD PTR [rsp+0x198],r14
   5c54a:	mov    QWORD PTR [rsp+0x110],rdi
   5c552:	mov    rdi,r12
   5c555:	call   5c55a <sqlite3VdbeExec+0xd0ba>
   5c55a:	mov    r14d,eax
   5c55d:	mov    QWORD PTR [r12+0x48],0x0
   5c566:	mov    DWORD PTR [r12+0x50],0x0
   5c56f:	mov    rdi,QWORD PTR [rsp+0x110]
   5c577:	mov    DWORD PTR [rsp+0x39c],r14d
   5c57f:	mov    r14,QWORD PTR [rsp+0x198]
   5c587:	mov    rax,r14
   5c58a:	add    rax,QWORD PTR [r12+0x48]
   5c58f:	mov    QWORD PTR [r12+0x48],rax
   5c594:	movsxd rax,DWORD PTR [r12+0x8]
   5c599:	cmp    r14,rax
   5c59c:	jle    5c5a3 <sqlite3VdbeExec+0xd103>
   5c59e:	mov    DWORD PTR [r12+0x8],r14d
   5c5a3:	cmp    QWORD PTR [r12+0x40],0x0
   5c5a9:	je     5c7ae <sqlite3VdbeExec+0xd30e>
   5c5af:	movsxd rax,DWORD PTR [r12+0x50]
   5c5b4:	add    rax,rbx
   5c5b7:	cmp    eax,DWORD PTR [r12+0x54]
   5c5bc:	jg     5c5cb <sqlite3VdbeExec+0xd12b>
   5c5be:	mov    QWORD PTR [rsp+0x190],rbx
   5c5c6:	jmp    5c764 <sqlite3VdbeExec+0xd2c4>
   5c5cb:	movsxd rcx,DWORD PTR [r12+0x54]
   5c5d0:	mov    r14,rcx
   5c5d3:	shl    r14,1
   5c5d6:	cmp    QWORD PTR [r12+0x38],0x0
   5c5dc:	jne    5c604 <sqlite3VdbeExec+0xd164>
   5c5de:	mov    QWORD PTR [rsp+0x190],rbx
   5c5e6:	mov    rbx,r14
   5c5e9:	mov    r14,QWORD PTR [rsp+0x188]
   5c5f1:	mov    r11d,0xffffffff
   5c5f7:	mov    DWORD PTR [rsp+0x3a8],r11d
   5c5ff:	jmp    5c6df <sqlite3VdbeExec+0xd23f>
   5c604:	mov    rcx,QWORD PTR [r12+0x38]
   5c609:	sub    rcx,QWORD PTR [r12+0x40]
   5c60e:	mov    QWORD PTR [rsp+0x168],r14
   5c616:	mov    r14d,ecx
   5c619:	mov    QWORD PTR [rsp+0x190],rbx
   5c621:	mov    rbx,QWORD PTR [rsp+0x168]
   5c629:	mov    DWORD PTR [rsp+0x3a8],r14d
   5c631:	mov    r14,QWORD PTR [rsp+0x188]
   5c639:	jmp    5c6df <sqlite3VdbeExec+0xd23f>
   5c63e:	xor    r11d,r11d
   5c641:	mov    DWORD PTR [rsp+0x39c],r11d
   5c649:	jmp    5c587 <sqlite3VdbeExec+0xd0e7>
   5c64e:	mov    rax,QWORD PTR [r12+0x48]
   5c653:	movsxd rcx,DWORD PTR [r12+0x4]
   5c658:	cmp    rax,rcx
   5c65b:	jg     5c542 <sqlite3VdbeExec+0xd0a2>
   5c661:	mov    rax,QWORD PTR [r12+0x48]
   5c666:	movsxd rcx,DWORD PTR [r12]
   5c66a:	cmp    rax,rcx
   5c66d:	jle    5c691 <sqlite3VdbeExec+0xd1f1>
   5c66f:	mov    eax,DWORD PTR [rip+0x0]        # 5c675 <sqlite3VdbeExec+0xd1d5>
   5c675:	test   eax,eax
   5c677:	mov    eax,0x0
   5c67c:	setne  al
   5c67f:	mov    QWORD PTR [rsp+0x198],r14
   5c687:	mov    r14,QWORD PTR [rsp+0x188]
   5c68f:	jmp    5c6a3 <sqlite3VdbeExec+0xd203>
   5c691:	xor    eax,eax
   5c693:	mov    QWORD PTR [rsp+0x198],r14
   5c69b:	mov    r14,QWORD PTR [rsp+0x188]
   5c6a3:	test   eax,eax
   5c6a5:	jne    5c6c7 <sqlite3VdbeExec+0xd227>
   5c6a7:	mov    QWORD PTR [rsp+0x188],r14
   5c6af:	mov    r14,QWORD PTR [rsp+0x198]
   5c6b7:	xor    r11d,r11d
   5c6ba:	mov    DWORD PTR [rsp+0x39c],r11d
   5c6c2:	jmp    5c587 <sqlite3VdbeExec+0xd0e7>
   5c6c7:	mov    QWORD PTR [rsp+0x188],r14
   5c6cf:	mov    r14,QWORD PTR [rsp+0x198]
   5c6d7:	jmp    5c542 <sqlite3VdbeExec+0xd0a2>
   5c6dc:	shl    rbx,1
   5c6df:	movsxd rcx,eax
   5c6e2:	cmp    rbx,rcx
   5c6e5:	jl     5c6dc <sqlite3VdbeExec+0xd23c>
   5c6e7:	movsxd rcx,DWORD PTR [r12+0x4]
   5c6ec:	cmp    rbx,rcx
   5c6ef:	jle    5c730 <sqlite3VdbeExec+0xd290>
   5c6f1:	movsxd rbx,DWORD PTR [r12+0x4]
   5c6f6:	movsxd rcx,eax
   5c6f9:	cmp    rbx,rcx
   5c6fc:	jge    5c701 <sqlite3VdbeExec+0xd261>
   5c6fe:	movsxd rbx,eax
   5c701:	mov    rax,QWORD PTR [r12+0x40]
   5c706:	mov    QWORD PTR [rsp+0x110],rdi
   5c70e:	mov    rdi,rax
   5c711:	mov    rsi,rbx
   5c714:	call   5c719 <sqlite3VdbeExec+0xd279>
   5c719:	mov    rdi,QWORD PTR [rsp+0x110]
   5c721:	test   rax,rax
   5c724:	jne    5c73a <sqlite3VdbeExec+0xd29a>
   5c726:	mov    ebx,0x7
   5c72b:	jmp    5c81f <sqlite3VdbeExec+0xd37f>
   5c730:	movsxd rcx,eax
   5c733:	cmp    rbx,rcx
   5c736:	jl     5c6fe <sqlite3VdbeExec+0xd25e>
   5c738:	jmp    5c701 <sqlite3VdbeExec+0xd261>
   5c73a:	mov    QWORD PTR [rsp+0x188],r14
   5c742:	mov    r14d,DWORD PTR [rsp+0x3a8]
   5c74a:	test   r14d,r14d
   5c74d:	jl     5c75a <sqlite3VdbeExec+0xd2ba>
   5c74f:	movsxd rcx,r14d
   5c752:	add    rcx,rax
   5c755:	mov    QWORD PTR [r12+0x38],rcx
   5c75a:	mov    QWORD PTR [r12+0x40],rax
   5c75f:	mov    DWORD PTR [r12+0x54],ebx
   5c764:	mov    rax,QWORD PTR [r12+0x40]
   5c769:	movsxd rcx,DWORD PTR [r12+0x50]
   5c76e:	lea    rbx,[rax+rcx*1]
   5c772:	movsxd rax,DWORD PTR [r12+0x50]
   5c777:	mov    r14,QWORD PTR [rsp+0x190]
   5c77f:	lea    rcx,[r14+0x7]
   5c783:	and    rcx,0xfffffffffffffff8
   5c787:	add    rax,rcx
   5c78a:	mov    DWORD PTR [r12+0x50],eax
   5c78f:	cmp    QWORD PTR [r12+0x38],0x0
   5c795:	je     5c7a4 <sqlite3VdbeExec+0xd304>
   5c797:	mov    rax,QWORD PTR [r12+0x38]
   5c79c:	sub    rax,QWORD PTR [r12+0x40]
   5c7a1:	mov    DWORD PTR [rbx+0x8],eax
   5c7a4:	mov    r14,QWORD PTR [rsp+0x188]
   5c7ac:	jmp    5c7e6 <sqlite3VdbeExec+0xd346>
   5c7ae:	mov    QWORD PTR [rsp+0x110],rdi
   5c7b6:	mov    rdi,rbx
   5c7b9:	call   5c7be <sqlite3VdbeExec+0xd31e>
   5c7be:	mov    rbx,rax
   5c7c1:	mov    rdi,QWORD PTR [rsp+0x110]
   5c7c9:	test   rbx,rbx
   5c7cc:	jne    5c7d5 <sqlite3VdbeExec+0xd335>
   5c7ce:	mov    ebx,0x7
   5c7d3:	jmp    5c81f <sqlite3VdbeExec+0xd37f>
   5c7d5:	mov    rax,QWORD PTR [r12+0x38]
   5c7da:	mov    QWORD PTR [rbx+0x8],rax
   5c7de:	mov    r14,QWORD PTR [rsp+0x188]
   5c7e6:	lea    rax,[rbx+0x10]
   5c7ea:	mov    rcx,QWORD PTR [r14+0x8]
   5c7ee:	movsxd rdx,DWORD PTR [r14+0x10]
   5c7f2:	mov    QWORD PTR [rsp+0x110],rdi
   5c7fa:	mov    rdi,rax
   5c7fd:	mov    rsi,rcx
   5c800:	call   5c805 <sqlite3VdbeExec+0xd365>
   5c805:	mov    eax,DWORD PTR [r14+0x10]
   5c809:	mov    DWORD PTR [rbx],eax
   5c80b:	mov    QWORD PTR [r12+0x38],rbx
   5c810:	mov    rdi,QWORD PTR [rsp+0x110]
   5c818:	mov    ebx,DWORD PTR [rsp+0x39c]
   5c81f:	test   ebx,ebx
   5c821:	je     5c84b <sqlite3VdbeExec+0xd3ab>
   5c823:	mov    r14,QWORD PTR [rsp+0x128]
   5c82b:	mov    QWORD PTR [rsp+0x148],rbp
   5c833:	mov    rbp,rbx
   5c836:	mov    r13,QWORD PTR [rsp+0x130]
   5c83e:	mov    rbx,QWORD PTR [rsp+0x158]
   5c846:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c84b:	mov    r14,QWORD PTR [rsp+0x128]
   5c853:	mov    DWORD PTR [rsp+0x37c],r15d
   5c85b:	mov    DWORD PTR [rsp+0x38c],ebx
   5c862:	mov    rbx,r13
   5c865:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5c86a:	mov    QWORD PTR [rsp+0x128],r14
   5c872:	mov    r15d,DWORD PTR [rsp+0x37c]
   5c87a:	mov    r13,rbx
   5c87d:	mov    QWORD PTR [rsp+0x130],r12
   5c885:	mov    rax,QWORD PTR [rdi+0x78]
   5c889:	movsxd rcx,DWORD PTR [rbp+0x4]
   5c88d:	mov    rbx,QWORD PTR [rax+rcx*8]
   5c891:	mov    r12,QWORD PTR [rbx+0x28]
   5c895:	mov    rax,QWORD PTR [rbx+0x30]
   5c899:	mov    QWORD PTR [rsp+0x1e8],rax
   5c8a1:	mov    eax,DWORD PTR [rbp+0xc]
   5c8a4:	mov    WORD PTR [rsp+0x204],ax
   5c8ac:	mov    BYTE PTR [rsp+0x206],0x0
   5c8b4:	movsxd rax,DWORD PTR [rbp+0x8]
   5c8b8:	imul   rax,rax,0x38
   5c8bc:	add    rax,r13
   5c8bf:	mov    QWORD PTR [rsp+0x1f0],rax
   5c8c7:	lea    r14,[rsp+0x1e8]
   5c8cf:	mov    rax,r14
   5c8d2:	lea    r14,[rsp+0x398]
   5c8da:	mov    rcx,r14
   5c8dd:	mov    QWORD PTR [rsp+0x110],rdi
   5c8e5:	mov    rdi,r12
   5c8e8:	mov    rsi,rax
   5c8eb:	mov    rdx,rcx
   5c8ee:	call   5c8f3 <sqlite3VdbeExec+0xd453>
   5c8f3:	mov    r14d,eax
   5c8f6:	mov    rdi,QWORD PTR [rsp+0x110]
   5c8fe:	test   r14d,r14d
   5c901:	je     5c92b <sqlite3VdbeExec+0xd48b>
   5c903:	mov    QWORD PTR [rsp+0x148],rbp
   5c90b:	mov    rbp,r14
   5c90e:	mov    r14,QWORD PTR [rsp+0x128]
   5c916:	mov    r13,QWORD PTR [rsp+0x130]
   5c91e:	mov    rbx,QWORD PTR [rsp+0x158]
   5c926:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c92b:	cmp    DWORD PTR [rsp+0x398],0x0
   5c933:	je     5ca3d <sqlite3VdbeExec+0xd59d>
   5c939:	mov    rax,QWORD PTR [rbp+0x10]
   5c93d:	lea    r14,[rsp+0x1e8]
   5c945:	mov    rcx,r14
   5c948:	lea    r14,[rsp+0x398]
   5c950:	mov    rdx,r14
   5c953:	xor    esi,esi
   5c955:	mov    rdi,r12
   5c958:	mov    r8,rsi
   5c95b:	mov    rsi,rax
   5c95e:	mov    r11,rdx
   5c961:	mov    rdx,rcx
   5c964:	mov    rcx,r11
   5c967:	call   5c96c <sqlite3VdbeExec+0xd4cc>
   5c96c:	mov    r14d,eax
   5c96f:	mov    rdi,QWORD PTR [rsp+0x110]
   5c977:	test   r14d,r14d
   5c97a:	je     5c9a4 <sqlite3VdbeExec+0xd504>
   5c97c:	mov    QWORD PTR [rsp+0x148],rbp
   5c984:	mov    rbp,r14
   5c987:	mov    r14,QWORD PTR [rsp+0x128]
   5c98f:	mov    r13,QWORD PTR [rsp+0x130]
   5c997:	mov    rbx,QWORD PTR [rsp+0x158]
   5c99f:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5c9a4:	cmp    DWORD PTR [rsp+0x398],0x0
   5c9ac:	je     5ca3d <sqlite3VdbeExec+0xd59d>
   5c9b2:	mov    r12,QWORD PTR [rsp+0x128]
   5c9ba:	mov    rax,QWORD PTR [r12+0x30]
   5c9bf:	and    rax,0x10000001
   5c9c5:	cmp    rax,0x1
   5c9c9:	je     5ca14 <sqlite3VdbeExec+0xd574>
   5c9cb:	mov    eax,0x30b
   5c9d0:	mov    ecx,0x192e3
   5c9d5:	lea    rdx,[rip+0x0]        # 5c9dc <sqlite3VdbeExec+0xd53c>
   5c9dc:	mov    rdi,rax
   5c9df:	mov    rsi,rcx
   5c9e2:	call   5c9e7 <sqlite3VdbeExec+0xd547>
   5c9e7:	mov    ebx,eax
   5c9e9:	mov    rdi,QWORD PTR [rsp+0x110]
   5c9f1:	mov    r14,r12
   5c9f4:	mov    QWORD PTR [rsp+0x148],rbp
   5c9fc:	mov    rbp,rbx
   5c9ff:	mov    r13,QWORD PTR [rsp+0x130]
   5ca07:	mov    rbx,QWORD PTR [rsp+0x158]
   5ca0f:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5ca14:	mov    DWORD PTR [rbx+0x18],0x0
   5ca1b:	mov    DWORD PTR [rbx+0x1c],0x0
   5ca22:	mov    DWORD PTR [rsp+0x37c],r15d
   5ca2a:	mov    DWORD PTR [rsp+0x38c],r14d
   5ca32:	mov    r14,r12
   5ca35:	mov    rbx,r13
   5ca38:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5ca3d:	mov    eax,0x4
   5ca42:	mov    QWORD PTR [rsp+0x110],rdi
   5ca4a:	mov    rdi,r12
   5ca4d:	mov    rsi,rax
   5ca50:	call   5ca55 <sqlite3VdbeExec+0xd5b5>
   5ca55:	mov    r12d,eax
   5ca58:	mov    rdi,QWORD PTR [rsp+0x110]
   5ca60:	test   r12d,r12d
   5ca63:	je     5ca8d <sqlite3VdbeExec+0xd5ed>
   5ca65:	mov    r14,QWORD PTR [rsp+0x128]
   5ca6d:	mov    QWORD PTR [rsp+0x148],rbp
   5ca75:	mov    rbp,r12
   5ca78:	mov    r13,QWORD PTR [rsp+0x130]
   5ca80:	mov    rbx,QWORD PTR [rsp+0x158]
   5ca88:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5ca8d:	mov    DWORD PTR [rbx+0x18],0x0
   5ca94:	mov    DWORD PTR [rbx+0x1c],0x0
   5ca9b:	mov    r14,QWORD PTR [rsp+0x128]
   5caa3:	mov    DWORD PTR [rsp+0x37c],r15d
   5caab:	mov    DWORD PTR [rsp+0x38c],r12d
   5cab3:	mov    rbx,r13
   5cab6:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5cabb:	mov    QWORD PTR [rsp+0x128],r14
   5cac3:	mov    r15d,DWORD PTR [rsp+0x37c]
   5cacb:	mov    r13,rbx
   5cace:	mov    QWORD PTR [rsp+0x130],r12
   5cad6:	mov    rax,QWORD PTR [rdi+0x78]
   5cada:	movsxd rcx,DWORD PTR [rbp+0x4]
   5cade:	mov    rbx,QWORD PTR [rax+rcx*8]
   5cae2:	mov    rax,QWORD PTR [rbx+0x28]
   5cae6:	xor    ecx,ecx
   5cae8:	movzx  eax,BYTE PTR [rax]
   5caeb:	cmp    ecx,eax
   5caed:	je     5cb0c <sqlite3VdbeExec+0xd66c>
   5caef:	mov    QWORD PTR [rsp+0x110],rdi
   5caf7:	mov    rdi,rbx
   5cafa:	call   5caff <sqlite3VdbeExec+0xd65f>
   5caff:	mov    r12d,eax
   5cb02:	mov    rdi,QWORD PTR [rsp+0x110]
   5cb0a:	jmp    5cb0f <sqlite3VdbeExec+0xd66f>
   5cb0c:	xor    r12d,r12d
   5cb0f:	test   r12d,r12d
   5cb12:	je     5cb3c <sqlite3VdbeExec+0xd69c>
   5cb14:	mov    r14,QWORD PTR [rsp+0x128]
   5cb1c:	mov    QWORD PTR [rsp+0x148],rbp
   5cb24:	mov    rbp,r12
   5cb27:	mov    r13,QWORD PTR [rsp+0x130]
   5cb2f:	mov    rbx,QWORD PTR [rsp+0x158]
   5cb37:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5cb3c:	mov    r14,QWORD PTR [rsp+0x128]
   5cb44:	cmp    BYTE PTR [rbx+0x2],0x0
   5cb48:	jne    5cf54 <sqlite3VdbeExec+0xdab4>
   5cb4e:	mov    QWORD PTR [rsp+0x188],0x0
   5cb5a:	mov    r12,QWORD PTR [rbx+0x28]
   5cb5e:	mov    QWORD PTR [rsp+0x110],rdi
   5cb66:	mov    rdi,r12
   5cb69:	call   5cb6e <sqlite3VdbeExec+0xd6ce>
   5cb6e:	mov    eax,DWORD PTR [r12+0x40]
   5cb73:	mov    WORD PTR [rsp+0x254],0x0
   5cb7d:	mov    QWORD PTR [rsp+0x258],r14
   5cb85:	mov    DWORD PTR [rsp+0x260],0x0
   5cb90:	mov    QWORD PTR [rsp+0x190],rbx
   5cb98:	lea    rbx,[rsp+0x240]
   5cba0:	mov    rcx,rbx
   5cba3:	mov    rdi,r12
   5cba6:	mov    rsi,rax
   5cba9:	mov    rdx,rcx
   5cbac:	call   5cbb1 <sqlite3VdbeExec+0xd711>
   5cbb1:	mov    r12d,eax
   5cbb4:	mov    rdi,QWORD PTR [rsp+0x110]
   5cbbc:	test   r12d,r12d
   5cbbf:	je     5cbc9 <sqlite3VdbeExec+0xd729>
   5cbc1:	mov    rbx,r12
   5cbc4:	jmp    5ce9c <sqlite3VdbeExec+0xd9fc>
   5cbc9:	mov    rax,QWORD PTR [rbx+0x8]
   5cbcd:	movzx  eax,BYTE PTR [rax]
   5cbd0:	lea    r12,[rsp+0x398]
   5cbd8:	mov    DWORD PTR [r12],eax
   5cbdc:	cmp    DWORD PTR [r12],0x80
   5cbe4:	jb     5cc7f <sqlite3VdbeExec+0xd7df>
   5cbea:	mov    rax,QWORD PTR [rbx+0x8]
   5cbee:	lea    rbx,[rsp+0x198]
   5cbf6:	movzx  ecx,BYTE PTR [rax+0x1]
   5cbfa:	and    ecx,0x80
   5cc00:	test   ecx,ecx
   5cc02:	jne    5cc19 <sqlite3VdbeExec+0xd779>
   5cc04:	movzx  ecx,BYTE PTR [rax]
   5cc07:	and    ecx,0x7f
   5cc0a:	shl    ecx,0x7
   5cc0d:	movzx  eax,BYTE PTR [rax+0x1]
   5cc11:	or     ecx,eax
   5cc13:	mov    DWORD PTR [r12],ecx
   5cc17:	jmp    5cc7f <sqlite3VdbeExec+0xd7df>
   5cc19:	movzx  ecx,BYTE PTR [rax+0x2]
   5cc1d:	and    ecx,0x80
   5cc23:	test   ecx,ecx
   5cc25:	jne    5cc48 <sqlite3VdbeExec+0xd7a8>
   5cc27:	movzx  ecx,BYTE PTR [rax]
   5cc2a:	and    ecx,0x7f
   5cc2d:	shl    ecx,0xe
   5cc30:	movzx  edx,BYTE PTR [rax+0x1]
   5cc34:	and    edx,0x7f
   5cc37:	shl    edx,0x7
   5cc3a:	or     ecx,edx
   5cc3c:	movzx  eax,BYTE PTR [rax+0x2]
   5cc40:	or     ecx,eax
   5cc42:	mov    DWORD PTR [r12],ecx
   5cc46:	jmp    5cc7f <sqlite3VdbeExec+0xd7df>
   5cc48:	mov    rcx,rbx
   5cc4b:	mov    rdi,rax
   5cc4e:	mov    rsi,rcx
   5cc51:	call   5cc56 <sqlite3VdbeExec+0xd7b6>
   5cc56:	movzx  eax,al
   5cc59:	mov    eax,0xffffffff
   5cc5e:	and    rax,QWORD PTR [rbx]
   5cc61:	mov    rdi,QWORD PTR [rsp+0x110]
   5cc69:	cmp    rax,QWORD PTR [rbx]
   5cc6c:	je     5cc78 <sqlite3VdbeExec+0xd7d8>
   5cc6e:	mov    DWORD PTR [r12],0xffffffff
   5cc76:	jmp    5cc7f <sqlite3VdbeExec+0xd7df>
   5cc78:	mov    rax,QWORD PTR [rbx]
   5cc7b:	mov    DWORD PTR [r12],eax
   5cc7f:	cmp    DWORD PTR [r12],0x3
   5cc84:	jae    5cc93 <sqlite3VdbeExec+0xd7f3>
   5cc86:	lea    rbx,[rsp+0x240]
   5cc8e:	jmp    5ce4d <sqlite3VdbeExec+0xd9ad>
   5cc93:	mov    eax,DWORD PTR [r12]
   5cc97:	lea    rbx,[rsp+0x240]
   5cc9f:	cmp    eax,DWORD PTR [rbx+0x10]
   5cca2:	ja     5ce4d <sqlite3VdbeExec+0xd9ad>
   5cca8:	mov    rax,QWORD PTR [rbx+0x8]
   5ccac:	mov    ecx,DWORD PTR [r12]
   5ccb0:	sub    ecx,0x1
   5ccb3:	movzx  eax,BYTE PTR [rax+rcx*1]
   5ccb7:	lea    r12,[rsp+0x39c]
   5ccbf:	mov    DWORD PTR [r12],eax
   5ccc3:	cmp    DWORD PTR [r12],0x80
   5cccb:	jb     5cd7e <sqlite3VdbeExec+0xd8de>
   5ccd1:	mov    rax,QWORD PTR [rbx+0x8]
   5ccd5:	lea    rbx,[rsp+0x398]
   5ccdd:	mov    ecx,DWORD PTR [rbx]
   5ccdf:	sub    ecx,0x1
   5cce2:	lea    rdx,[rax+rcx*1]
   5cce6:	lea    rbx,[rsp+0x198]
   5ccee:	movzx  eax,BYTE PTR [rax+rcx*1+0x1]
   5ccf3:	and    eax,0x80
   5ccf8:	test   eax,eax
   5ccfa:	jne    5cd11 <sqlite3VdbeExec+0xd871>
   5ccfc:	movzx  eax,BYTE PTR [rdx]
   5ccff:	and    eax,0x7f
   5cd02:	shl    eax,0x7
   5cd05:	movzx  ecx,BYTE PTR [rdx+0x1]
   5cd09:	or     eax,ecx
   5cd0b:	mov    DWORD PTR [r12],eax
   5cd0f:	jmp    5cd7e <sqlite3VdbeExec+0xd8de>
   5cd11:	movzx  eax,BYTE PTR [rdx+0x2]
   5cd15:	and    eax,0x80
   5cd1a:	test   eax,eax
   5cd1c:	jne    5cd3f <sqlite3VdbeExec+0xd89f>
   5cd1e:	movzx  eax,BYTE PTR [rdx]
   5cd21:	and    eax,0x7f
   5cd24:	shl    eax,0xe
   5cd27:	movzx  ecx,BYTE PTR [rdx+0x1]
   5cd2b:	and    ecx,0x7f
   5cd2e:	shl    ecx,0x7
   5cd31:	or     eax,ecx
   5cd33:	movzx  ecx,BYTE PTR [rdx+0x2]
   5cd37:	or     eax,ecx
   5cd39:	mov    DWORD PTR [r12],eax
   5cd3d:	jmp    5cd7e <sqlite3VdbeExec+0xd8de>
   5cd3f:	mov    rax,rbx
   5cd42:	mov    QWORD PTR [rsp+0x110],rdi
   5cd4a:	mov    rdi,rdx
   5cd4d:	mov    rsi,rax
   5cd50:	call   5cd55 <sqlite3VdbeExec+0xd8b5>
   5cd55:	movzx  eax,al
   5cd58:	mov    eax,0xffffffff
   5cd5d:	and    rax,QWORD PTR [rbx]
   5cd60:	mov    rdi,QWORD PTR [rsp+0x110]
   5cd68:	cmp    rax,QWORD PTR [rbx]
   5cd6b:	je     5cd77 <sqlite3VdbeExec+0xd8d7>
   5cd6d:	mov    DWORD PTR [r12],0xffffffff
   5cd75:	jmp    5cd7e <sqlite3VdbeExec+0xd8de>
   5cd77:	mov    rax,QWORD PTR [rbx]
   5cd7a:	mov    DWORD PTR [r12],eax
   5cd7e:	cmp    DWORD PTR [r12],0x1
   5cd83:	jae    5cd92 <sqlite3VdbeExec+0xd8f2>
   5cd85:	lea    rbx,[rsp+0x240]
   5cd8d:	jmp    5ce4d <sqlite3VdbeExec+0xd9ad>
   5cd92:	cmp    DWORD PTR [r12],0x9
   5cd97:	jbe    5cda6 <sqlite3VdbeExec+0xd906>
   5cd99:	lea    rbx,[rsp+0x240]
   5cda1:	jmp    5ce4d <sqlite3VdbeExec+0xd9ad>
   5cda6:	cmp    DWORD PTR [r12],0x7
   5cdab:	jne    5cdba <sqlite3VdbeExec+0xd91a>
   5cdad:	lea    rbx,[rsp+0x240]
   5cdb5:	jmp    5ce4d <sqlite3VdbeExec+0xd9ad>
   5cdba:	lea    rax,[rip+0x0]        # 5cdc1 <sqlite3VdbeExec+0xd921>
   5cdc1:	mov    ecx,DWORD PTR [r12]
   5cdc5:	movzx  eax,BYTE PTR [rax+rcx*1]
   5cdc9:	lea    rbx,[rsp+0x240]
   5cdd1:	mov    ecx,DWORD PTR [rbx+0x10]
   5cdd4:	lea    r12,[rsp+0x398]
   5cddc:	mov    edx,eax
   5cdde:	add    edx,DWORD PTR [r12]
   5cde2:	cmp    ecx,edx
   5cde4:	jb     5ce4d <sqlite3VdbeExec+0xd9ad>
   5cde6:	mov    rcx,QWORD PTR [rbx+0x8]
   5cdea:	mov    edx,DWORD PTR [rbx+0x10]
   5cded:	sub    edx,eax
   5cdef:	add    rcx,rdx
   5cdf2:	lea    r12,[rsp+0x39c]
   5cdfa:	mov    eax,DWORD PTR [r12]
   5cdfe:	lea    r12,[rsp+0x278]
   5ce06:	mov    rdx,r12
   5ce09:	mov    QWORD PTR [rsp+0x110],rdi
   5ce11:	mov    rdi,rcx
   5ce14:	mov    rsi,rax
   5ce17:	call   5ce1c <sqlite3VdbeExec+0xd97c>
   5ce1c:	mov    rax,QWORD PTR [r12]
   5ce20:	mov    QWORD PTR [rsp+0x188],rax
   5ce28:	mov    rax,rbx
   5ce2b:	mov    rdi,QWORD PTR [rsp+0x110]
   5ce33:	cmp    DWORD PTR [rbx+0x20],0x0
   5ce37:	je     5ce49 <sqlite3VdbeExec+0xd9a9>
   5ce39:	mov    rdi,rax
   5ce3c:	call   5ce41 <sqlite3VdbeExec+0xd9a1>
   5ce41:	mov    rdi,QWORD PTR [rsp+0x110]
   5ce49:	xor    ebx,ebx
   5ce4b:	jmp    5ce9c <sqlite3VdbeExec+0xd9fc>
   5ce4d:	mov    rax,rbx
   5ce50:	cmp    DWORD PTR [rbx+0x20],0x0
   5ce54:	je     5ce6e <sqlite3VdbeExec+0xd9ce>
   5ce56:	mov    QWORD PTR [rsp+0x110],rdi
   5ce5e:	mov    rdi,rax
   5ce61:	call   5ce66 <sqlite3VdbeExec+0xd9c6>
   5ce66:	mov    rdi,QWORD PTR [rsp+0x110]
   5ce6e:	mov    eax,0x16b4d
   5ce73:	mov    ecx,0xb
   5ce78:	lea    rdx,[rip+0x0]        # 5ce7f <sqlite3VdbeExec+0xd9df>
   5ce7f:	mov    QWORD PTR [rsp+0x110],rdi
   5ce87:	mov    rdi,rcx
   5ce8a:	mov    rsi,rax
   5ce8d:	call   5ce92 <sqlite3VdbeExec+0xd9f2>
   5ce92:	mov    ebx,eax
   5ce94:	mov    rdi,QWORD PTR [rsp+0x110]
   5ce9c:	test   ebx,ebx
   5ce9e:	je     5cec0 <sqlite3VdbeExec+0xda20>
   5cea0:	mov    QWORD PTR [rsp+0x148],rbp
   5cea8:	mov    rbp,rbx
   5ceab:	mov    r13,QWORD PTR [rsp+0x130]
   5ceb3:	mov    rbx,QWORD PTR [rsp+0x158]
   5cebb:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5cec0:	cmp    BYTE PTR [rbp+0x0],0x8f
   5cec4:	jne    5cf03 <sqlite3VdbeExec+0xda63>
   5cec6:	mov    rax,QWORD PTR [rdi+0x78]
   5ceca:	movsxd rcx,DWORD PTR [rbp+0xc]
   5cece:	mov    rax,QWORD PTR [rax+rcx*8]
   5ced2:	mov    BYTE PTR [rax+0x2],0x0
   5ced6:	mov    rcx,QWORD PTR [rsp+0x188]
   5cede:	mov    QWORD PTR [rax+0x48],rcx
   5cee2:	mov    BYTE PTR [rax+0x3],0x1
   5cee6:	mov    DWORD PTR [rax+0x18],0x0
   5ceed:	mov    rcx,QWORD PTR [rbp+0x10]
   5cef1:	mov    QWORD PTR [rax+0x8],rcx
   5cef5:	mov    r12,QWORD PTR [rsp+0x190]
   5cefd:	mov    QWORD PTR [rax+0x20],r12
   5cf01:	jmp    5cf4f <sqlite3VdbeExec+0xdaaf>
   5cf03:	mov    rax,QWORD PTR [rdi+0x68]
   5cf07:	movsxd rcx,DWORD PTR [rbp+0x8]
   5cf0b:	imul   rcx,rcx,0x38
   5cf0f:	lea    rdx,[rax+rcx*1]
   5cf13:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5cf18:	and    eax,0x9000
   5cf1d:	test   eax,eax
   5cf1f:	je     5cf3e <sqlite3VdbeExec+0xda9e>
   5cf21:	mov    QWORD PTR [rsp+0x110],rdi
   5cf29:	mov    rdi,rdx
   5cf2c:	call   5cf31 <sqlite3VdbeExec+0xda91>
   5cf31:	mov    rdi,QWORD PTR [rsp+0x110]
   5cf39:	mov    rdx,rax
   5cf3c:	jmp    5cf44 <sqlite3VdbeExec+0xdaa4>
   5cf3e:	mov    WORD PTR [rdx+0x14],0x4
   5cf44:	mov    rax,QWORD PTR [rsp+0x188]
   5cf4c:	mov    QWORD PTR [rdx],rax
   5cf4f:	mov    r12,rbx
   5cf52:	jmp    5cf90 <sqlite3VdbeExec+0xdaf0>
   5cf54:	movsxd rax,DWORD PTR [rbp+0x8]
   5cf58:	imul   rax,rax,0x38
   5cf5c:	lea    rcx,[r13+rax*1+0x0]
   5cf61:	movzx  eax,WORD PTR [r13+rax*1+0x14]
   5cf67:	and    eax,0x9000
   5cf6c:	test   eax,eax
   5cf6e:	je     5cf8a <sqlite3VdbeExec+0xdaea>
   5cf70:	mov    QWORD PTR [rsp+0x110],rdi
   5cf78:	mov    rdi,rcx
   5cf7b:	call   5cf80 <sqlite3VdbeExec+0xdae0>
   5cf80:	mov    rdi,QWORD PTR [rsp+0x110]
   5cf88:	jmp    5cf90 <sqlite3VdbeExec+0xdaf0>
   5cf8a:	mov    WORD PTR [rcx+0x14],0x1
   5cf90:	mov    DWORD PTR [rsp+0x37c],r15d
   5cf98:	mov    DWORD PTR [rsp+0x38c],r12d
   5cfa0:	mov    rbx,r13
   5cfa3:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5cfa8:	mov    r15d,DWORD PTR [rsp+0x37c]
   5cfb0:	mov    r13,QWORD PTR [rsp+0x150]
   5cfb8:	mov    QWORD PTR [rsp+0x130],r12
   5cfc0:	mov    r12d,DWORD PTR [rsp+0x394]
   5cfc8:	mov    rax,QWORD PTR [rdi+0x78]
   5cfcc:	movsxd rcx,DWORD PTR [rbp+0x4]
   5cfd0:	mov    rax,QWORD PTR [rax+rcx*8]
   5cfd4:	cmp    BYTE PTR [rax+0x3],0x0
   5cfd8:	jne    5cfe4 <sqlite3VdbeExec+0xdb44>
   5cfda:	mov    QWORD PTR [rsp+0x150],r13
   5cfe2:	jmp    5d036 <sqlite3VdbeExec+0xdb96>
   5cfe4:	mov    QWORD PTR [rsp+0x150],r13
   5cfec:	mov    QWORD PTR [rsp+0x110],rdi
   5cff4:	mov    rdi,rax
   5cff7:	call   5cffc <sqlite3VdbeExec+0xdb5c>
   5cffc:	mov    r13d,eax
   5cfff:	mov    rdi,QWORD PTR [rsp+0x110]
   5d007:	test   r13d,r13d
   5d00a:	jne    5d016 <sqlite3VdbeExec+0xdb76>
   5d00c:	mov    DWORD PTR [rsp+0x38c],r13d
   5d014:	jmp    5d036 <sqlite3VdbeExec+0xdb96>
   5d016:	mov    QWORD PTR [rsp+0x148],rbp
   5d01e:	mov    rbp,r13
   5d021:	mov    r13,QWORD PTR [rsp+0x130]
   5d029:	mov    rbx,QWORD PTR [rsp+0x158]
   5d031:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5d036:	mov    DWORD PTR [rsp+0x37c],r15d
   5d03e:	mov    DWORD PTR [rsp+0x394],r12d
   5d046:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5d04b:	mov    r15d,DWORD PTR [rsp+0x37c]
   5d053:	mov    QWORD PTR [rsp+0x130],r12
   5d05b:	mov    r12d,DWORD PTR [rsp+0x394]
   5d063:	mov    rax,QWORD PTR [rdi+0x78]
   5d067:	movsxd rcx,DWORD PTR [rbp+0x4]
   5d06b:	mov    rax,QWORD PTR [rax+rcx*8]
   5d06f:	mov    rcx,QWORD PTR [rax+0x30]
   5d073:	mov    QWORD PTR [rsp+0x1e8],rcx
   5d07b:	mov    ecx,DWORD PTR [rbp+0x10]
   5d07e:	mov    WORD PTR [rsp+0x204],cx
   5d086:	cmp    BYTE PTR [rbp+0x0],0x2d
   5d08a:	jae    5d096 <sqlite3VdbeExec+0xdbf6>
   5d08c:	mov    BYTE PTR [rsp+0x206],0xff
   5d094:	jmp    5d09e <sqlite3VdbeExec+0xdbfe>
   5d096:	mov    BYTE PTR [rsp+0x206],0x0
   5d09e:	movsxd rcx,DWORD PTR [rbp+0xc]
   5d0a2:	imul   rcx,rcx,0x38
   5d0a6:	add    rcx,rbx
   5d0a9:	mov    QWORD PTR [rsp+0x1f0],rcx
   5d0b1:	mov    r13,QWORD PTR [rax+0x28]
   5d0b5:	mov    QWORD PTR [rsp+0x110],rdi
   5d0bd:	mov    rdi,r13
   5d0c0:	call   5d0c5 <sqlite3VdbeExec+0xdc25>
   5d0c5:	mov    eax,DWORD PTR [r13+0x40]
   5d0c9:	mov    rdi,QWORD PTR [rsp+0x110]
   5d0d1:	test   rax,rax
   5d0d4:	jle    5d0de <sqlite3VdbeExec+0xdc3e>
   5d0d6:	cmp    rax,0x7fffffff
   5d0dc:	jle    5d12c <sqlite3VdbeExec+0xdc8c>
   5d0de:	mov    eax,0x193b7
   5d0e3:	mov    ecx,0xb
   5d0e8:	lea    rdx,[rip+0x0]        # 5d0ef <sqlite3VdbeExec+0xdc4f>
   5d0ef:	mov    QWORD PTR [rsp+0x110],rdi
   5d0f7:	mov    rdi,rcx
   5d0fa:	mov    rsi,rax
   5d0fd:	call   5d102 <sqlite3VdbeExec+0xdc62>
   5d102:	mov    ebx,eax
   5d104:	mov    rdi,QWORD PTR [rsp+0x110]
   5d10c:	mov    QWORD PTR [rsp+0x148],rbp
   5d114:	mov    rbp,rbx
   5d117:	mov    r13,QWORD PTR [rsp+0x130]
   5d11f:	mov    rbx,QWORD PTR [rsp+0x158]
   5d127:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5d12c:	mov    WORD PTR [rsp+0x28c],0x0
   5d136:	mov    QWORD PTR [rsp+0x290],r14
   5d13e:	mov    DWORD PTR [rsp+0x298],0x0
   5d149:	mov    QWORD PTR [rsp+0x128],r14
   5d151:	lea    r14,[rsp+0x278]
   5d159:	mov    rcx,r14
   5d15c:	mov    rdi,r13
   5d15f:	mov    rsi,rax
   5d162:	mov    rdx,rcx
   5d165:	call   5d16a <sqlite3VdbeExec+0xdcca>
   5d16a:	mov    r13d,eax
   5d16d:	mov    rdi,QWORD PTR [rsp+0x110]
   5d175:	test   r13d,r13d
   5d178:	je     5d1a2 <sqlite3VdbeExec+0xdd02>
   5d17a:	mov    r14,QWORD PTR [rsp+0x128]
   5d182:	mov    QWORD PTR [rsp+0x148],rbp
   5d18a:	mov    rbp,r13
   5d18d:	mov    r13,QWORD PTR [rsp+0x130]
   5d195:	mov    rbx,QWORD PTR [rsp+0x158]
   5d19d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5d1a2:	mov    eax,DWORD PTR [rsp+0x288]
   5d1a9:	mov    rcx,QWORD PTR [rsp+0x280]
   5d1b1:	mov    DWORD PTR [rsp+0x394],r12d
   5d1b9:	lea    r12,[rsp+0x1e8]
   5d1c1:	mov    rdx,r12
   5d1c4:	xor    esi,esi
   5d1c6:	mov    rdi,rax
   5d1c9:	mov    r11,rsi
   5d1cc:	mov    rsi,rcx
   5d1cf:	mov    rcx,r11
   5d1d2:	call   5d1d7 <sqlite3VdbeExec+0xdd37>
   5d1d7:	mov    rcx,r14
   5d1da:	mov    rdi,QWORD PTR [rsp+0x110]
   5d1e2:	cmp    DWORD PTR [rsp+0x298],0x0
   5d1ea:	je     5d20c <sqlite3VdbeExec+0xdd6c>
   5d1ec:	mov    QWORD PTR [rsp+0x108],rax
   5d1f4:	mov    rdi,rcx
   5d1f7:	call   5d1fc <sqlite3VdbeExec+0xdd5c>
   5d1fc:	mov    rax,QWORD PTR [rsp+0x108]
   5d204:	mov    rdi,QWORD PTR [rsp+0x110]
   5d20c:	movzx  ecx,BYTE PTR [rbp+0x0]
   5d210:	and    ecx,0x1
   5d213:	cmp    ecx,0x1
   5d216:	jne    5d23d <sqlite3VdbeExec+0xdd9d>
   5d218:	neg    eax
   5d21a:	test   eax,eax
   5d21c:	jg     5d228 <sqlite3VdbeExec+0xdd88>
   5d21e:	mov    r12d,DWORD PTR [rsp+0x394]
   5d226:	jmp    5d25e <sqlite3VdbeExec+0xddbe>
   5d228:	mov    r12,QWORD PTR [rsp+0x128]
   5d230:	mov    DWORD PTR [rsp+0x38c],r13d
   5d238:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   5d23d:	mov    r12d,DWORD PTR [rsp+0x394]
   5d245:	add    eax,0x1
   5d248:	test   eax,eax
   5d24a:	jle    5d25e <sqlite3VdbeExec+0xddbe>
   5d24c:	mov    DWORD PTR [rsp+0x394],r12d
   5d254:	lea    r12,[rsp+0x1e8]
   5d25c:	jmp    5d228 <sqlite3VdbeExec+0xdd88>
   5d25e:	mov    r14,QWORD PTR [rsp+0x128]
   5d266:	mov    DWORD PTR [rsp+0x37c],r15d
   5d26e:	mov    DWORD PTR [rsp+0x38c],r13d
   5d276:	mov    DWORD PTR [rsp+0x394],r12d
   5d27e:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5d283:	mov    QWORD PTR [rsp+0x128],r14
   5d28b:	mov    r15d,DWORD PTR [rsp+0x37c]
   5d293:	mov    QWORD PTR [rsp+0x130],r12
   5d29b:	mov    r12d,DWORD PTR [rsp+0x394]
   5d2a3:	lea    r14,[rsp+0x278]
   5d2ab:	mov    rax,QWORD PTR [rdi+0x68]
   5d2af:	movsxd rcx,DWORD PTR [rbp+0x8]
   5d2b3:	imul   rcx,rcx,0x38
   5d2b7:	lea    r13,[rax+rcx*1]
   5d2bb:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5d2c0:	and    eax,0x9000
   5d2c5:	test   eax,eax
   5d2c7:	je     5d2e6 <sqlite3VdbeExec+0xde46>
   5d2c9:	mov    QWORD PTR [rsp+0x110],rdi
   5d2d1:	mov    rdi,r13
   5d2d4:	call   5d2d9 <sqlite3VdbeExec+0xde39>
   5d2d9:	mov    r13,rax
   5d2dc:	mov    rdi,QWORD PTR [rsp+0x110]
   5d2e4:	jmp    5d2ed <sqlite3VdbeExec+0xde4d>
   5d2e6:	mov    WORD PTR [r13+0x14],0x4
   5d2ed:	mov    WORD PTR [r13+0x14],0x1
   5d2f4:	mov    r14,QWORD PTR [rsp+0x128]
   5d2fc:	mov    eax,DWORD PTR [r14+0xd4]
   5d303:	mov    ecx,DWORD PTR [r14+0xe0]
   5d30a:	add    ecx,0x1
   5d30d:	cmp    eax,ecx
   5d30f:	jle    5d33d <sqlite3VdbeExec+0xde9d>
   5d311:	mov    ebx,0x6
   5d316:	mov    BYTE PTR [rdi+0xc4],0x2
   5d31d:	mov    QWORD PTR [rsp+0x148],rbp
   5d325:	mov    rbp,rbx
   5d328:	mov    r13,QWORD PTR [rsp+0x130]
   5d330:	mov    rbx,QWORD PTR [rsp+0x158]
   5d338:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5d33d:	mov    DWORD PTR [rsp+0x394],r12d
   5d345:	movsxd r12,DWORD PTR [rbp+0xc]
   5d349:	mov    DWORD PTR [rsp+0x39c],0x0
   5d354:	mov    rax,QWORD PTR [r14+0x20]
   5d358:	mov    rcx,r12
   5d35b:	shl    rcx,0x5
   5d35f:	mov    QWORD PTR [rsp+0x188],r13
   5d367:	mov    r13,QWORD PTR [rax+rcx*1+0x8]
   5d36c:	mov    QWORD PTR [rsp+0x190],r12
   5d374:	mov    r12d,DWORD PTR [rbp+0x4]
   5d378:	mov    rax,QWORD PTR [r13+0x8]
   5d37c:	mov    rcx,QWORD PTR [r13+0x0]
   5d380:	mov    QWORD PTR [rax+0x8],rcx
   5d384:	mov    QWORD PTR [rsp+0x168],0x0
   5d390:	mov    DWORD PTR [rsp+0x37c],r15d
   5d398:	mov    r15,QWORD PTR [r13+0x8]
   5d39c:	mov    eax,DWORD PTR [r15+0x40]
   5d3a0:	cmp    r12d,eax
   5d3a3:	jbe    5d3de <sqlite3VdbeExec+0xdf3e>
   5d3a5:	mov    eax,0x1460e
   5d3aa:	mov    ecx,0xb
   5d3af:	lea    rdx,[rip+0x0]        # 5d3b6 <sqlite3VdbeExec+0xdf16>
   5d3b6:	mov    QWORD PTR [rsp+0x110],rdi
   5d3be:	mov    rdi,rcx
   5d3c1:	mov    rsi,rax
   5d3c4:	call   5d3c9 <sqlite3VdbeExec+0xdf29>
   5d3c9:	mov    rdi,QWORD PTR [rsp+0x110]
   5d3d1:	mov    r13,QWORD PTR [rsp+0x188]
   5d3d9:	jmp    5ddad <sqlite3VdbeExec+0xe90d>
   5d3de:	mov    DWORD PTR [rsp+0x398],r12d
   5d3e6:	mov    r12,QWORD PTR [r13+0x8]
   5d3ea:	mov    rax,QWORD PTR [r13+0x8]
   5d3ee:	mov    rcx,QWORD PTR [r13+0x0]
   5d3f2:	mov    QWORD PTR [rax+0x8],rcx
   5d3f6:	xor    eax,eax
   5d3f8:	mov    rcx,QWORD PTR [r12+0x10]
   5d3fd:	jmp    5d463 <sqlite3VdbeExec+0xdfc3>
   5d3ff:	test   rcx,rcx
   5d402:	jne    5d416 <sqlite3VdbeExec+0xdf76>
   5d404:	mov    QWORD PTR [rsp+0x1a0],r12
   5d40c:	mov    r12d,DWORD PTR [rsp+0x398]
   5d414:	jmp    5d44f <sqlite3VdbeExec+0xdfaf>
   5d416:	xor    edx,edx
   5d418:	mov    QWORD PTR [rsp+0x1a0],r12
   5d420:	mov    r12d,DWORD PTR [rsp+0x398]
   5d428:	cmp    edx,r12d
   5d42b:	jne    5d437 <sqlite3VdbeExec+0xdf97>
   5d42d:	mov    r12,QWORD PTR [rsp+0x1a0]
   5d435:	jmp    5d468 <sqlite3VdbeExec+0xdfc8>
   5d437:	cmp    r12d,DWORD PTR [rcx+0x50]
   5d43b:	jne    5d44f <sqlite3VdbeExec+0xdfaf>
   5d43d:	mov    DWORD PTR [rsp+0x398],r12d
   5d445:	mov    r12,QWORD PTR [rsp+0x1a0]
   5d44d:	jmp    5d468 <sqlite3VdbeExec+0xdfc8>
   5d44f:	mov    rcx,QWORD PTR [rcx+0x28]
   5d453:	mov    DWORD PTR [rsp+0x398],r12d
   5d45b:	mov    r12,QWORD PTR [rsp+0x1a0]
   5d463:	test   rcx,rcx
   5d466:	jne    5d3ff <sqlite3VdbeExec+0xdf5f>
   5d468:	test   rcx,rcx
   5d46b:	jne    5d47f <sqlite3VdbeExec+0xdfdf>
   5d46d:	mov    QWORD PTR [rsp+0x1a0],r12
   5d475:	mov    r12d,DWORD PTR [rsp+0x398]
   5d47d:	jmp    5d4b7 <sqlite3VdbeExec+0xe017>
   5d47f:	mov    QWORD PTR [rsp+0x1a0],r12
   5d487:	mov    r12d,DWORD PTR [rsp+0x398]
   5d48f:	mov    QWORD PTR [rsp+0x110],rdi
   5d497:	mov    rdi,rcx
   5d49a:	mov    rsi,r12
   5d49d:	mov    rdx,rax
   5d4a0:	call   5d4a5 <sqlite3VdbeExec+0xe005>
   5d4a5:	xor    ecx,ecx
   5d4a7:	mov    rdi,QWORD PTR [rsp+0x110]
   5d4af:	cmp    ecx,eax
   5d4b1:	jne    5d53d <sqlite3VdbeExec+0xe09d>
   5d4b7:	cmp    BYTE PTR [r13+0x13],0x0
   5d4bc:	je     5d4ef <sqlite3VdbeExec+0xe04f>
   5d4be:	mov    BYTE PTR [r13+0x13],0x0
   5d4c3:	mov    rax,QWORD PTR [r13+0x8]
   5d4c7:	mov    rax,QWORD PTR [rax+0x10]
   5d4cb:	jmp    5d4ea <sqlite3VdbeExec+0xe04a>
   5d4cd:	movzx  ecx,BYTE PTR [rax+0x1]
   5d4d1:	and    ecx,0x10
   5d4d4:	test   ecx,ecx
   5d4d6:	je     5d4e6 <sqlite3VdbeExec+0xe046>
   5d4d8:	mov    BYTE PTR [r13+0x13],0x1
   5d4dd:	cmp    r12d,DWORD PTR [rax+0x50]
   5d4e1:	jne    5d4e6 <sqlite3VdbeExec+0xe046>
   5d4e3:	mov    BYTE PTR [rax],0x1
   5d4e6:	mov    rax,QWORD PTR [rax+0x28]
   5d4ea:	test   rax,rax
   5d4ed:	jne    5d4cd <sqlite3VdbeExec+0xe02d>
   5d4ef:	xor    eax,eax
   5d4f1:	mov    QWORD PTR [rsp+0x198],r13
   5d4f9:	mov    QWORD PTR [rsp+0x180],r15
   5d501:	xor    r15d,r15d
   5d504:	mov    r13,QWORD PTR [rsp+0x1a0]
   5d50c:	mov    QWORD PTR [rsp+0x110],rdi
   5d514:	mov    rdi,r13
   5d517:	mov    rsi,r12
   5d51a:	mov    rdx,rax
   5d51d:	mov    rcx,r15
   5d520:	call   5d525 <sqlite3VdbeExec+0xe085>
   5d525:	mov    rdi,QWORD PTR [rsp+0x110]
   5d52d:	mov    r13,QWORD PTR [rsp+0x198]
   5d535:	mov    r15,QWORD PTR [rsp+0x180]
   5d53d:	mov    QWORD PTR [rsp+0x160],rbx
   5d545:	lea    rbx,[rsp+0x3a8]
   5d54d:	mov    DWORD PTR [rbx],eax
   5d54f:	cmp    DWORD PTR [rbx],0x0
   5d552:	je     5d56b <sqlite3VdbeExec+0xe0cb>
   5d554:	mov    eax,DWORD PTR [rbx]
   5d556:	mov    r13,QWORD PTR [rsp+0x188]
   5d55e:	mov    rbx,QWORD PTR [rsp+0x160]
   5d566:	jmp    5ddad <sqlite3VdbeExec+0xe90d>
   5d56b:	xor    eax,eax
   5d56d:	lea    rbx,[rsp+0x1a0]
   5d575:	mov    rcx,QWORD PTR [r15]
   5d578:	mov    rdx,rbx
   5d57b:	mov    rsi,QWORD PTR [rcx+0x110]
   5d582:	mov    QWORD PTR [rsp+0x110],rdi
   5d58a:	mov    rdi,rcx
   5d58d:	mov    rcx,rax
   5d590:	mov    r10,rsi
   5d593:	mov    rsi,r12
   5d596:	call   r10
   5d599:	mov    rdi,QWORD PTR [rsp+0x110]
   5d5a1:	test   eax,eax
   5d5a3:	je     5d5a7 <sqlite3VdbeExec+0xe107>
   5d5a5:	jmp    5d5e6 <sqlite3VdbeExec+0xe146>
   5d5a7:	mov    rax,QWORD PTR [rbx]
   5d5aa:	mov    rcx,QWORD PTR [rax+0x10]
   5d5ae:	cmp    r12d,DWORD PTR [rcx+0x4]
   5d5b2:	je     5d5d9 <sqlite3VdbeExec+0xe139>
   5d5b4:	mov    rdx,QWORD PTR [rax+0x8]
   5d5b8:	mov    QWORD PTR [rcx+0x50],rdx
   5d5bc:	mov    QWORD PTR [rcx+0x70],rax
   5d5c0:	mov    QWORD PTR [rcx+0x48],r15
   5d5c4:	mov    DWORD PTR [rcx+0x4],r12d
   5d5c8:	mov    eax,0x64
   5d5cd:	xor    edx,edx
   5d5cf:	cmp    r12d,0x1
   5d5d3:	cmove  edx,eax
   5d5d6:	mov    BYTE PTR [rcx+0x9],dl
   5d5d9:	lea    rbx,[rsp+0x168]
   5d5e1:	mov    QWORD PTR [rbx],rcx
   5d5e4:	xor    eax,eax
   5d5e6:	lea    rbx,[rsp+0x3a8]
   5d5ee:	mov    DWORD PTR [rbx],eax
   5d5f0:	cmp    DWORD PTR [rbx],0x0
   5d5f3:	je     5d6af <sqlite3VdbeExec+0xe20f>
   5d5f9:	lea    r12,[rsp+0x168]
   5d601:	mov    rax,QWORD PTR [r12]
   5d605:	test   rax,rax
   5d608:	je     5d698 <sqlite3VdbeExec+0xe1f8>
   5d60e:	mov    rax,QWORD PTR [rax+0x70]
   5d612:	movzx  ecx,WORD PTR [rax+0x34]
   5d616:	and    ecx,0x20
   5d619:	test   ecx,ecx
   5d61b:	je     5d680 <sqlite3VdbeExec+0xe1e0>
   5d61d:	mov    rcx,QWORD PTR [rax+0x28]
   5d621:	mov    edx,DWORD PTR [rcx+0x98]
   5d627:	sub    edx,0x1
   5d62a:	mov    DWORD PTR [rcx+0x98],edx
   5d630:	mov    rdx,QWORD PTR [rcx+0xa8]
   5d637:	mov    QWORD PTR [rax+0x20],rdx
   5d63b:	mov    QWORD PTR [rcx+0xa8],rax
   5d642:	mov    rdx,QWORD PTR [rcx+0x48]
   5d646:	mov    esi,DWORD PTR [rax+0x30]
   5d649:	sub    esi,0x1
   5d64c:	imul   rsi,QWORD PTR [rcx+0xc8]
   5d654:	mov    rax,QWORD PTR [rax+0x8]
   5d658:	mov    rcx,QWORD PTR [rdx]
   5d65b:	mov    rcx,QWORD PTR [rcx+0x90]
   5d662:	mov    QWORD PTR [rsp+0x110],rdi
   5d66a:	mov    rdi,rdx
   5d66d:	mov    rdx,rax
   5d670:	mov    r10,rcx
   5d673:	call   r10
   5d676:	mov    rdi,QWORD PTR [rsp+0x110]
   5d67e:	jmp    5d698 <sqlite3VdbeExec+0xe1f8>
   5d680:	mov    QWORD PTR [rsp+0x110],rdi
   5d688:	mov    rdi,rax
   5d68b:	call   5d690 <sqlite3VdbeExec+0xe1f0>
   5d690:	mov    rdi,QWORD PTR [rsp+0x110]
   5d698:	mov    eax,DWORD PTR [rbx]
   5d69a:	mov    r13,QWORD PTR [rsp+0x188]
   5d6a2:	mov    rbx,QWORD PTR [rsp+0x160]
   5d6aa:	jmp    5ddad <sqlite3VdbeExec+0xe90d>
   5d6af:	mov    DWORD PTR [rsp+0x39c],0x0
   5d6ba:	cmp    BYTE PTR [r15+0x21],0x0
   5d6bf:	je     5dcc7 <sqlite3VdbeExec+0xe827>
   5d6c5:	mov    rax,QWORD PTR [r13+0x8]
   5d6c9:	mov    rcx,QWORD PTR [r13+0x8]
   5d6cd:	mov    rdx,QWORD PTR [r13+0x0]
   5d6d1:	mov    QWORD PTR [rcx+0x8],rdx
   5d6d5:	mov    rax,QWORD PTR [rax+0x18]
   5d6d9:	mov    rax,QWORD PTR [rax+0x50]
   5d6dd:	movzx  ecx,BYTE PTR [rax+0x34]
   5d6e1:	shl    ecx,0x18
   5d6e4:	movzx  edx,BYTE PTR [rax+0x35]
   5d6e8:	shl    edx,0x10
   5d6eb:	or     ecx,edx
   5d6ed:	movzx  edx,BYTE PTR [rax+0x36]
   5d6f1:	shl    edx,0x8
   5d6f4:	or     ecx,edx
   5d6f6:	movzx  eax,BYTE PTR [rax+0x37]
   5d6fa:	or     ecx,eax
   5d6fc:	lea    rbx,[rsp+0x388]
   5d704:	mov    DWORD PTR [rbx],ecx
   5d706:	cmp    r12d,DWORD PTR [rbx]
   5d709:	jne    5d815 <sqlite3VdbeExec+0xe375>
   5d70f:	lea    r12,[rsp+0x168]
   5d717:	mov    rax,QWORD PTR [r12]
   5d71b:	lea    rbx,[rsp+0x3a8]
   5d723:	cmp    DWORD PTR [rbx],0x0
   5d726:	jne    5d74c <sqlite3VdbeExec+0xe2ac>
   5d728:	mov    rcx,QWORD PTR [rax+0x48]
   5d72c:	mov    edx,DWORD PTR [rax+0x4]
   5d72f:	mov    QWORD PTR [rsp+0x110],rdi
   5d737:	mov    rdi,rcx
   5d73a:	mov    rsi,rax
   5d73d:	call   5d742 <sqlite3VdbeExec+0xe2a2>
   5d742:	mov    DWORD PTR [rbx],eax
   5d744:	mov    rdi,QWORD PTR [rsp+0x110]
   5d74c:	mov    rax,QWORD PTR [r12]
   5d750:	test   rax,rax
   5d753:	je     5d7e3 <sqlite3VdbeExec+0xe343>
   5d759:	mov    rax,QWORD PTR [rax+0x70]
   5d75d:	movzx  ecx,WORD PTR [rax+0x34]
   5d761:	and    ecx,0x20
   5d764:	test   ecx,ecx
   5d766:	je     5d7cb <sqlite3VdbeExec+0xe32b>
   5d768:	mov    rcx,QWORD PTR [rax+0x28]
   5d76c:	mov    edx,DWORD PTR [rcx+0x98]
   5d772:	sub    edx,0x1
   5d775:	mov    DWORD PTR [rcx+0x98],edx
   5d77b:	mov    rdx,QWORD PTR [rcx+0xa8]
   5d782:	mov    QWORD PTR [rax+0x20],rdx
   5d786:	mov    QWORD PTR [rcx+0xa8],rax
   5d78d:	mov    rdx,QWORD PTR [rcx+0x48]
   5d791:	mov    esi,DWORD PTR [rax+0x30]
   5d794:	sub    esi,0x1
   5d797:	imul   rsi,QWORD PTR [rcx+0xc8]
   5d79f:	mov    rax,QWORD PTR [rax+0x8]
   5d7a3:	mov    rcx,QWORD PTR [rdx]
   5d7a6:	mov    rcx,QWORD PTR [rcx+0x90]
   5d7ad:	mov    QWORD PTR [rsp+0x110],rdi
   5d7b5:	mov    rdi,rdx
   5d7b8:	mov    rdx,rax
   5d7bb:	mov    r10,rcx
   5d7be:	call   r10
   5d7c1:	mov    rdi,QWORD PTR [rsp+0x110]
   5d7c9:	jmp    5d7e3 <sqlite3VdbeExec+0xe343>
   5d7cb:	mov    QWORD PTR [rsp+0x110],rdi
   5d7d3:	mov    rdi,rax
   5d7d6:	call   5d7db <sqlite3VdbeExec+0xe33b>
   5d7db:	mov    rdi,QWORD PTR [rsp+0x110]
   5d7e3:	cmp    DWORD PTR [rbx],0x0
   5d7e6:	jne    5d7fe <sqlite3VdbeExec+0xe35e>
   5d7e8:	mov    r11,rbp
   5d7eb:	mov    rbp,rbx
   5d7ee:	mov    rbx,r11
   5d7f1:	lea    r12,[rsp+0x388]
   5d7f9:	jmp    5dbf4 <sqlite3VdbeExec+0xe754>
   5d7fe:	mov    eax,DWORD PTR [rbx]
   5d800:	mov    r13,QWORD PTR [rsp+0x188]
   5d808:	mov    rbx,QWORD PTR [rsp+0x160]
   5d810:	jmp    5ddad <sqlite3VdbeExec+0xe90d>
   5d815:	lea    rbx,[rsp+0x168]
   5d81d:	mov    rax,QWORD PTR [rbx]
   5d820:	test   rax,rax
   5d823:	je     5d8b3 <sqlite3VdbeExec+0xe413>
   5d829:	mov    rax,QWORD PTR [rax+0x70]
   5d82d:	movzx  ecx,WORD PTR [rax+0x34]
   5d831:	and    ecx,0x20
   5d834:	test   ecx,ecx
   5d836:	je     5d89b <sqlite3VdbeExec+0xe3fb>
   5d838:	mov    rcx,QWORD PTR [rax+0x28]
   5d83c:	mov    edx,DWORD PTR [rcx+0x98]
   5d842:	sub    edx,0x1
   5d845:	mov    DWORD PTR [rcx+0x98],edx
   5d84b:	mov    rdx,QWORD PTR [rcx+0xa8]
   5d852:	mov    QWORD PTR [rax+0x20],rdx
   5d856:	mov    QWORD PTR [rcx+0xa8],rax
   5d85d:	mov    rdx,QWORD PTR [rcx+0x48]
   5d861:	mov    esi,DWORD PTR [rax+0x30]
   5d864:	sub    esi,0x1
   5d867:	imul   rsi,QWORD PTR [rcx+0xc8]
   5d86f:	mov    rax,QWORD PTR [rax+0x8]
   5d873:	mov    rcx,QWORD PTR [rdx]
   5d876:	mov    rcx,QWORD PTR [rcx+0x90]
   5d87d:	mov    QWORD PTR [rsp+0x110],rdi
   5d885:	mov    rdi,rdx
   5d888:	mov    rdx,rax
   5d88b:	mov    r10,rcx
   5d88e:	call   r10
   5d891:	mov    rdi,QWORD PTR [rsp+0x110]
   5d899:	jmp    5d8b3 <sqlite3VdbeExec+0xe413>
   5d89b:	mov    QWORD PTR [rsp+0x110],rdi
   5d8a3:	mov    rdi,rax
   5d8a6:	call   5d8ab <sqlite3VdbeExec+0xe40b>
   5d8ab:	mov    rdi,QWORD PTR [rsp+0x110]
   5d8b3:	lea    rbx,[rsp+0x388]
   5d8bb:	mov    ebx,DWORD PTR [rbx]
   5d8bd:	xor    eax,eax
   5d8bf:	mov    rcx,QWORD PTR [r15]
   5d8c2:	mov    DWORD PTR [rsp+0x398],r12d
   5d8ca:	lea    r12,[rsp+0x1a0]
   5d8d2:	mov    rdx,r12
   5d8d5:	mov    rsi,QWORD PTR [rcx+0x110]
   5d8dc:	mov    QWORD PTR [rsp+0x110],rdi
   5d8e4:	mov    rdi,rcx
   5d8e7:	mov    rcx,rax
   5d8ea:	mov    r10,rsi
   5d8ed:	mov    rsi,rbx
   5d8f0:	call   r10
   5d8f3:	mov    rdi,QWORD PTR [rsp+0x110]
   5d8fb:	test   eax,eax
   5d8fd:	je     5d901 <sqlite3VdbeExec+0xe461>
   5d8ff:	jmp    5d93e <sqlite3VdbeExec+0xe49e>
   5d901:	mov    rax,QWORD PTR [r12]
   5d905:	mov    rcx,QWORD PTR [rax+0x10]
   5d909:	cmp    ebx,DWORD PTR [rcx+0x4]
   5d90c:	je     5d931 <sqlite3VdbeExec+0xe491>
   5d90e:	mov    rdx,QWORD PTR [rax+0x8]
   5d912:	mov    QWORD PTR [rcx+0x50],rdx
   5d916:	mov    QWORD PTR [rcx+0x70],rax
   5d91a:	mov    QWORD PTR [rcx+0x48],r15
   5d91e:	mov    DWORD PTR [rcx+0x4],ebx
   5d921:	mov    eax,0x64
   5d926:	xor    edx,edx
   5d928:	cmp    ebx,0x1
   5d92b:	cmove  edx,eax
   5d92e:	mov    BYTE PTR [rcx+0x9],dl
   5d931:	lea    rbx,[rsp+0x140]
   5d939:	mov    QWORD PTR [rbx],rcx
   5d93c:	xor    eax,eax
   5d93e:	lea    rbx,[rsp+0x3a8]
   5d946:	mov    DWORD PTR [rbx],eax
   5d948:	cmp    DWORD PTR [rbx],0x0
   5d94b:	je     5d964 <sqlite3VdbeExec+0xe4c4>
   5d94d:	mov    eax,DWORD PTR [rbx]
   5d94f:	mov    r13,QWORD PTR [rsp+0x188]
   5d957:	mov    rbx,QWORD PTR [rsp+0x160]
   5d95f:	jmp    5ddad <sqlite3VdbeExec+0xe90d>
   5d964:	mov    r12d,DWORD PTR [rsp+0x398]
   5d96c:	mov    rbx,rbp
   5d96f:	lea    rbp,[rsp+0x140]
   5d977:	mov    rax,QWORD PTR [rbp+0x0]
   5d97b:	xor    ecx,ecx
   5d97d:	xor    edx,edx
   5d97f:	mov    esi,0x1
   5d984:	mov    QWORD PTR [rsp+0x110],rdi
   5d98c:	mov    rdi,r15
   5d98f:	mov    r8,r12
   5d992:	mov    r9,rdx
   5d995:	mov    rdx,rsi
   5d998:	mov    rsi,rax
   5d99b:	call   5d9a0 <sqlite3VdbeExec+0xe500>
   5d9a0:	lea    r12,[rsp+0x3a8]
   5d9a8:	mov    DWORD PTR [r12],eax
   5d9ac:	mov    rax,QWORD PTR [rbp+0x0]
   5d9b0:	mov    rdi,QWORD PTR [rsp+0x110]
   5d9b8:	test   rax,rax
   5d9bb:	je     5da37 <sqlite3VdbeExec+0xe597>
   5d9bd:	mov    rax,QWORD PTR [rax+0x70]
   5d9c1:	movzx  ecx,WORD PTR [rax+0x34]
   5d9c5:	and    ecx,0x20
   5d9c8:	test   ecx,ecx
   5d9ca:	je     5da27 <sqlite3VdbeExec+0xe587>
   5d9cc:	mov    rcx,QWORD PTR [rax+0x28]
   5d9d0:	mov    edx,DWORD PTR [rcx+0x98]
   5d9d6:	sub    edx,0x1
   5d9d9:	mov    DWORD PTR [rcx+0x98],edx
   5d9df:	mov    rdx,QWORD PTR [rcx+0xa8]
   5d9e6:	mov    QWORD PTR [rax+0x20],rdx
   5d9ea:	mov    QWORD PTR [rcx+0xa8],rax
   5d9f1:	mov    rdx,QWORD PTR [rcx+0x48]
   5d9f5:	mov    esi,DWORD PTR [rax+0x30]
   5d9f8:	sub    esi,0x1
   5d9fb:	imul   rsi,QWORD PTR [rcx+0xc8]
   5da03:	mov    rax,QWORD PTR [rax+0x8]
   5da07:	mov    rcx,QWORD PTR [rdx]
   5da0a:	mov    rcx,QWORD PTR [rcx+0x90]
   5da11:	mov    rdi,rdx
   5da14:	mov    rdx,rax
   5da17:	mov    r10,rcx
   5da1a:	call   r10
   5da1d:	mov    rdi,QWORD PTR [rsp+0x110]
   5da25:	jmp    5da37 <sqlite3VdbeExec+0xe597>
   5da27:	mov    rdi,rax
   5da2a:	call   5da2f <sqlite3VdbeExec+0xe58f>
   5da2f:	mov    rdi,QWORD PTR [rsp+0x110]
   5da37:	cmp    DWORD PTR [r12],0x0
   5da3c:	je     5da5a <sqlite3VdbeExec+0xe5ba>
   5da3e:	mov    eax,DWORD PTR [r12]
   5da42:	mov    r13,QWORD PTR [rsp+0x188]
   5da4a:	mov    rbp,rbx
   5da4d:	mov    rbx,QWORD PTR [rsp+0x160]
   5da55:	jmp    5ddad <sqlite3VdbeExec+0xe90d>
   5da5a:	mov    QWORD PTR [rbp+0x0],0x0
   5da62:	lea    rbp,[rsp+0x388]
   5da6a:	mov    ebp,DWORD PTR [rbp+0x0]
   5da6d:	xor    eax,eax
   5da6f:	lea    r12,[rsp+0x1a0]
   5da77:	mov    rcx,QWORD PTR [r15]
   5da7a:	mov    rdx,r12
   5da7d:	mov    rsi,QWORD PTR [rcx+0x110]
   5da84:	mov    QWORD PTR [rsp+0x110],rdi
   5da8c:	mov    rdi,rcx
   5da8f:	mov    rcx,rax
   5da92:	mov    r10,rsi
   5da95:	mov    rsi,rbp
   5da98:	call   r10
   5da9b:	mov    rdi,QWORD PTR [rsp+0x110]
   5daa3:	test   eax,eax
   5daa5:	je     5daa9 <sqlite3VdbeExec+0xe609>
   5daa7:	jmp    5dae7 <sqlite3VdbeExec+0xe647>
   5daa9:	mov    rax,QWORD PTR [r12]
   5daad:	mov    rcx,QWORD PTR [rax+0x10]
   5dab1:	cmp    ebp,DWORD PTR [rcx+0x4]
   5dab4:	je     5dad9 <sqlite3VdbeExec+0xe639>
   5dab6:	mov    rdx,QWORD PTR [rax+0x8]
   5daba:	mov    QWORD PTR [rcx+0x50],rdx
   5dabe:	mov    QWORD PTR [rcx+0x70],rax
   5dac2:	mov    QWORD PTR [rcx+0x48],r15
   5dac6:	mov    DWORD PTR [rcx+0x4],ebp
   5dac9:	mov    eax,0x64
   5dace:	xor    edx,edx
   5dad0:	cmp    ebp,0x1
   5dad3:	cmove  edx,eax
   5dad6:	mov    BYTE PTR [rcx+0x9],dl
   5dad9:	lea    rbp,[rsp+0x140]
   5dae1:	mov    QWORD PTR [rbp+0x0],rcx
   5dae5:	xor    eax,eax
   5dae7:	lea    rbp,[rsp+0x3a8]
   5daef:	mov    DWORD PTR [rbp+0x0],eax
   5daf2:	lea    r12,[rsp+0x140]
   5dafa:	mov    rax,QWORD PTR [r12]
   5dafe:	cmp    DWORD PTR [rbp+0x0],0x0
   5db02:	jne    5db29 <sqlite3VdbeExec+0xe689>
   5db04:	mov    rcx,QWORD PTR [rax+0x48]
   5db08:	mov    edx,DWORD PTR [rax+0x4]
   5db0b:	mov    QWORD PTR [rsp+0x110],rdi
   5db13:	mov    rdi,rcx
   5db16:	mov    rsi,rax
   5db19:	call   5db1e <sqlite3VdbeExec+0xe67e>
   5db1e:	mov    DWORD PTR [rbp+0x0],eax
   5db21:	mov    rdi,QWORD PTR [rsp+0x110]
   5db29:	mov    rax,QWORD PTR [r12]
   5db2d:	test   rax,rax
   5db30:	je     5dbc0 <sqlite3VdbeExec+0xe720>
   5db36:	mov    rax,QWORD PTR [rax+0x70]
   5db3a:	movzx  ecx,WORD PTR [rax+0x34]
   5db3e:	and    ecx,0x20
   5db41:	test   ecx,ecx
   5db43:	je     5dba8 <sqlite3VdbeExec+0xe708>
   5db45:	mov    rcx,QWORD PTR [rax+0x28]
   5db49:	mov    edx,DWORD PTR [rcx+0x98]
   5db4f:	sub    edx,0x1
   5db52:	mov    DWORD PTR [rcx+0x98],edx
   5db58:	mov    rdx,QWORD PTR [rcx+0xa8]
   5db5f:	mov    QWORD PTR [rax+0x20],rdx
   5db63:	mov    QWORD PTR [rcx+0xa8],rax
   5db6a:	mov    rdx,QWORD PTR [rcx+0x48]
   5db6e:	mov    esi,DWORD PTR [rax+0x30]
   5db71:	sub    esi,0x1
   5db74:	imul   rsi,QWORD PTR [rcx+0xc8]
   5db7c:	mov    rax,QWORD PTR [rax+0x8]
   5db80:	mov    rcx,QWORD PTR [rdx]
   5db83:	mov    rcx,QWORD PTR [rcx+0x90]
   5db8a:	mov    QWORD PTR [rsp+0x110],rdi
   5db92:	mov    rdi,rdx
   5db95:	mov    rdx,rax
   5db98:	mov    r10,rcx
   5db9b:	call   r10
   5db9e:	mov    rdi,QWORD PTR [rsp+0x110]
   5dba6:	jmp    5dbc0 <sqlite3VdbeExec+0xe720>
   5dba8:	mov    QWORD PTR [rsp+0x110],rdi
   5dbb0:	mov    rdi,rax
   5dbb3:	call   5dbb8 <sqlite3VdbeExec+0xe718>
   5dbb8:	mov    rdi,QWORD PTR [rsp+0x110]
   5dbc0:	cmp    DWORD PTR [rbp+0x0],0x0
   5dbc4:	je     5dbe1 <sqlite3VdbeExec+0xe741>
   5dbc6:	mov    eax,DWORD PTR [rbp+0x0]
   5dbc9:	mov    r13,QWORD PTR [rsp+0x188]
   5dbd1:	mov    rbp,rbx
   5dbd4:	mov    rbx,QWORD PTR [rsp+0x160]
   5dbdc:	jmp    5ddad <sqlite3VdbeExec+0xe90d>
   5dbe1:	lea    r12,[rsp+0x388]
   5dbe9:	mov    eax,DWORD PTR [r12]
   5dbed:	mov    DWORD PTR [rsp+0x39c],eax
   5dbf4:	mov    eax,DWORD PTR [r12]
   5dbf8:	sub    eax,0x1
   5dbfb:	mov    DWORD PTR [r12],eax
   5dbff:	jmp    5dc65 <sqlite3VdbeExec+0xe7c5>
   5dc01:	mov    eax,DWORD PTR [r15+0x38]
   5dc05:	mov    edx,0xcccccccd
   5dc0a:	mul    edx
   5dc0c:	shr    edx,0x2
   5dc0f:	mov    eax,edx
   5dc11:	lea    esi,[rax+0x1]
   5dc14:	sub    ecx,0x2
   5dc17:	mov    rax,rcx
   5dc1a:	xor    edx,edx
   5dc1c:	div    esi
   5dc1e:	imul   eax,esi
   5dc21:	lea    ecx,[rax+0x2]
   5dc24:	mov    eax,DWORD PTR [rip+0x0]        # 5dc2a <sqlite3VdbeExec+0xe78a>
   5dc2a:	mov    esi,DWORD PTR [r15+0x34]
   5dc2e:	xor    edx,edx
   5dc30:	div    esi
   5dc32:	add    eax,0x1
   5dc35:	xor    edx,edx
   5dc37:	mov    esi,0x1
   5dc3c:	cmp    ecx,eax
   5dc3e:	cmove  edx,esi
   5dc41:	lea    eax,[rcx+rdx*1]
   5dc44:	lea    rbp,[rsp+0x3a8]
   5dc4c:	lea    r12,[rsp+0x388]
   5dc54:	cmp    eax,DWORD PTR [r12]
   5dc58:	jne    5dc8f <sqlite3VdbeExec+0xe7ef>
   5dc5a:	mov    eax,DWORD PTR [r12]
   5dc5e:	sub    eax,0x1
   5dc61:	mov    DWORD PTR [r12],eax
   5dc65:	mov    ecx,DWORD PTR [r12]
   5dc69:	mov    eax,DWORD PTR [rip+0x0]        # 5dc6f <sqlite3VdbeExec+0xe7cf>
   5dc6f:	mov    esi,DWORD PTR [r15+0x34]
   5dc73:	xor    edx,edx
   5dc75:	div    esi
   5dc77:	add    eax,0x1
   5dc7a:	cmp    ecx,eax
   5dc7c:	je     5dc5a <sqlite3VdbeExec+0xe7ba>
   5dc7e:	mov    ecx,DWORD PTR [r12]
   5dc82:	cmp    ecx,0x2
   5dc85:	jae    5dc01 <sqlite3VdbeExec+0xe761>
   5dc8b:	xor    eax,eax
   5dc8d:	jmp    5dc54 <sqlite3VdbeExec+0xe7b4>
   5dc8f:	mov    eax,0x4
   5dc94:	mov    ecx,DWORD PTR [r12]
   5dc98:	mov    QWORD PTR [rsp+0x110],rdi
   5dca0:	mov    rdi,r13
   5dca3:	mov    rsi,rax
   5dca6:	mov    rdx,rcx
   5dca9:	call   5dcae <sqlite3VdbeExec+0xe80e>
   5dcae:	mov    DWORD PTR [rbp+0x0],eax
   5dcb1:	mov    rdi,QWORD PTR [rsp+0x110]
   5dcb9:	mov    r11,rbx
   5dcbc:	mov    rbx,rbp
   5dcbf:	mov    rbp,r11
   5dcc2:	jmp    5dd9b <sqlite3VdbeExec+0xe8fb>
   5dcc7:	lea    rbx,[rsp+0x3a8]
   5dccf:	lea    r12,[rsp+0x168]
   5dcd7:	mov    rax,QWORD PTR [r12]
   5dcdb:	cmp    DWORD PTR [rbx],0x0
   5dcde:	jne    5dd04 <sqlite3VdbeExec+0xe864>
   5dce0:	mov    rcx,QWORD PTR [rax+0x48]
   5dce4:	mov    edx,DWORD PTR [rax+0x4]
   5dce7:	mov    QWORD PTR [rsp+0x110],rdi
   5dcef:	mov    rdi,rcx
   5dcf2:	mov    rsi,rax
   5dcf5:	call   5dcfa <sqlite3VdbeExec+0xe85a>
   5dcfa:	mov    DWORD PTR [rbx],eax
   5dcfc:	mov    rdi,QWORD PTR [rsp+0x110]
   5dd04:	mov    rax,QWORD PTR [r12]
   5dd08:	test   rax,rax
   5dd0b:	je     5dd9b <sqlite3VdbeExec+0xe8fb>
   5dd11:	mov    rax,QWORD PTR [rax+0x70]
   5dd15:	movzx  ecx,WORD PTR [rax+0x34]
   5dd19:	and    ecx,0x20
   5dd1c:	test   ecx,ecx
   5dd1e:	je     5dd83 <sqlite3VdbeExec+0xe8e3>
   5dd20:	mov    rcx,QWORD PTR [rax+0x28]
   5dd24:	mov    edx,DWORD PTR [rcx+0x98]
   5dd2a:	sub    edx,0x1
   5dd2d:	mov    DWORD PTR [rcx+0x98],edx
   5dd33:	mov    rdx,QWORD PTR [rcx+0xa8]
   5dd3a:	mov    QWORD PTR [rax+0x20],rdx
   5dd3e:	mov    QWORD PTR [rcx+0xa8],rax
   5dd45:	mov    rdx,QWORD PTR [rcx+0x48]
   5dd49:	mov    esi,DWORD PTR [rax+0x30]
   5dd4c:	sub    esi,0x1
   5dd4f:	imul   rsi,QWORD PTR [rcx+0xc8]
   5dd57:	mov    rax,QWORD PTR [rax+0x8]
   5dd5b:	mov    rcx,QWORD PTR [rdx]
   5dd5e:	mov    rcx,QWORD PTR [rcx+0x90]
   5dd65:	mov    QWORD PTR [rsp+0x110],rdi
   5dd6d:	mov    rdi,rdx
   5dd70:	mov    rdx,rax
   5dd73:	mov    r10,rcx
   5dd76:	call   r10
   5dd79:	mov    rdi,QWORD PTR [rsp+0x110]
   5dd81:	jmp    5dd9b <sqlite3VdbeExec+0xe8fb>
   5dd83:	mov    QWORD PTR [rsp+0x110],rdi
   5dd8b:	mov    rdi,rax
   5dd8e:	call   5dd93 <sqlite3VdbeExec+0xe8f3>
   5dd93:	mov    rdi,QWORD PTR [rsp+0x110]
   5dd9b:	mov    eax,DWORD PTR [rbx]
   5dd9d:	mov    r13,QWORD PTR [rsp+0x188]
   5dda5:	mov    rbx,QWORD PTR [rsp+0x160]
   5ddad:	mov    r12d,eax
   5ddb0:	mov    WORD PTR [r13+0x14],0x4
   5ddb7:	movsxd rax,DWORD PTR [rsp+0x39c]
   5ddbf:	mov    QWORD PTR [r13+0x0],rax
   5ddc3:	test   r12d,r12d
   5ddc6:	je     5dde8 <sqlite3VdbeExec+0xe948>
   5ddc8:	mov    QWORD PTR [rsp+0x148],rbp
   5ddd0:	mov    rbp,r12
   5ddd3:	mov    r13,QWORD PTR [rsp+0x130]
   5dddb:	mov    rbx,QWORD PTR [rsp+0x158]
   5dde3:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5dde8:	cmp    DWORD PTR [rsp+0x39c],0x0
   5ddf0:	je     5de5f <sqlite3VdbeExec+0xe9bf>
   5ddf2:	mov    eax,DWORD PTR [rsp+0x39c]
   5ddf9:	mov    ecx,DWORD PTR [rbp+0x4]
   5ddfc:	mov    rdx,QWORD PTR [r14+0x20]
   5de00:	mov    r13,QWORD PTR [rsp+0x190]
   5de08:	mov    rsi,r13
   5de0b:	shl    rsi,0x5
   5de0f:	mov    r8,QWORD PTR [rdx+rsi*1+0x18]
   5de14:	mov    r8,QWORD PTR [r8+0x10]
   5de18:	jmp    5de2b <sqlite3VdbeExec+0xe98b>
   5de1a:	mov    r9,QWORD PTR [r8+0x10]
   5de1e:	cmp    eax,DWORD PTR [r9+0x28]
   5de22:	jne    5de28 <sqlite3VdbeExec+0xe988>
   5de24:	mov    DWORD PTR [r9+0x28],ecx
   5de28:	mov    r8,QWORD PTR [r8]
   5de2b:	test   r8,r8
   5de2e:	jne    5de1a <sqlite3VdbeExec+0xe97a>
   5de30:	mov    rdx,QWORD PTR [rdx+rsi*1+0x18]
   5de35:	mov    rdx,QWORD PTR [rdx+0x28]
   5de39:	jmp    5de4a <sqlite3VdbeExec+0xe9aa>
   5de3b:	mov    rsi,QWORD PTR [rdx+0x10]
   5de3f:	cmp    eax,DWORD PTR [rsi+0x58]
   5de42:	jne    5de47 <sqlite3VdbeExec+0xe9a7>
   5de44:	mov    DWORD PTR [rsi+0x58],ecx
   5de47:	mov    rdx,QWORD PTR [rdx]
   5de4a:	test   rdx,rdx
   5de4d:	jne    5de3b <sqlite3VdbeExec+0xe99b>
   5de4f:	lea    eax,[r13+0x1]
   5de53:	movzx  r13d,al
   5de57:	mov    DWORD PTR [rsp+0x380],r13d
   5de5f:	mov    DWORD PTR [rsp+0x38c],r12d
   5de67:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5de6c:	mov    r15d,DWORD PTR [rsp+0x37c]
   5de74:	mov    r13,QWORD PTR [rsp+0x150]
   5de7c:	mov    QWORD PTR [rsp+0x130],r12
   5de84:	mov    r12d,DWORD PTR [rsp+0x394]
   5de8c:	mov    QWORD PTR [rsp+0x190],0x0
   5de98:	mov    rax,QWORD PTR [r14+0x20]
   5de9c:	movsxd rcx,DWORD PTR [rbp+0x8]
   5dea0:	shl    rcx,0x5
   5dea4:	mov    DWORD PTR [rsp+0x394],r12d
   5deac:	mov    r12,QWORD PTR [rax+rcx*1+0x8]
   5deb1:	mov    QWORD PTR [rsp+0x150],r13
   5deb9:	mov    r13d,DWORD PTR [rbp+0x4]
   5debd:	mov    DWORD PTR [rsp+0x39c],r13d
   5dec5:	lea    r13,[rsp+0x190]
   5decd:	mov    r13,QWORD PTR [r12+0x8]
   5ded2:	mov    rax,QWORD PTR [r12+0x8]
   5ded7:	mov    rcx,QWORD PTR [r12]
   5dedb:	mov    QWORD PTR [rax+0x8],rcx
   5dedf:	xor    eax,eax
   5dee1:	mov    rcx,QWORD PTR [r13+0x10]
   5dee5:	jmp    5df4b <sqlite3VdbeExec+0xeaab>
   5dee7:	test   rcx,rcx
   5deea:	jne    5defe <sqlite3VdbeExec+0xea5e>
   5deec:	mov    QWORD PTR [rsp+0x188],r13
   5def4:	mov    r13d,DWORD PTR [rsp+0x39c]
   5defc:	jmp    5df37 <sqlite3VdbeExec+0xea97>
   5defe:	xor    edx,edx
   5df00:	mov    QWORD PTR [rsp+0x188],r13
   5df08:	mov    r13d,DWORD PTR [rsp+0x39c]
   5df10:	cmp    edx,r13d
   5df13:	jne    5df1f <sqlite3VdbeExec+0xea7f>
   5df15:	mov    r13,QWORD PTR [rsp+0x188]
   5df1d:	jmp    5df50 <sqlite3VdbeExec+0xeab0>
   5df1f:	cmp    r13d,DWORD PTR [rcx+0x50]
   5df23:	jne    5df37 <sqlite3VdbeExec+0xea97>
   5df25:	mov    DWORD PTR [rsp+0x39c],r13d
   5df2d:	mov    r13,QWORD PTR [rsp+0x188]
   5df35:	jmp    5df50 <sqlite3VdbeExec+0xeab0>
   5df37:	mov    rcx,QWORD PTR [rcx+0x28]
   5df3b:	mov    DWORD PTR [rsp+0x39c],r13d
   5df43:	mov    r13,QWORD PTR [rsp+0x188]
   5df4b:	test   rcx,rcx
   5df4e:	jne    5dee7 <sqlite3VdbeExec+0xea47>
   5df50:	test   rcx,rcx
   5df53:	jne    5df67 <sqlite3VdbeExec+0xeac7>
   5df55:	mov    QWORD PTR [rsp+0x188],r13
   5df5d:	mov    r13d,DWORD PTR [rsp+0x39c]
   5df65:	jmp    5df9b <sqlite3VdbeExec+0xeafb>
   5df67:	mov    QWORD PTR [rsp+0x188],r13
   5df6f:	mov    r13d,DWORD PTR [rsp+0x39c]
   5df77:	mov    QWORD PTR [rsp+0x110],rdi
   5df7f:	mov    rdi,rcx
   5df82:	mov    rsi,r13
   5df85:	mov    rdx,rax
   5df88:	call   5df8d <sqlite3VdbeExec+0xeaed>
   5df8d:	xor    ecx,ecx
   5df8f:	mov    rdi,QWORD PTR [rsp+0x110]
   5df97:	cmp    ecx,eax
   5df99:	jne    5e01a <sqlite3VdbeExec+0xeb7a>
   5df9b:	cmp    BYTE PTR [r12+0x13],0x0
   5dfa1:	je     5dfd7 <sqlite3VdbeExec+0xeb37>
   5dfa3:	mov    BYTE PTR [r12+0x13],0x0
   5dfa9:	mov    rax,QWORD PTR [r12+0x8]
   5dfae:	mov    rax,QWORD PTR [rax+0x10]
   5dfb2:	jmp    5dfd2 <sqlite3VdbeExec+0xeb32>
   5dfb4:	movzx  ecx,BYTE PTR [rax+0x1]
   5dfb8:	and    ecx,0x10
   5dfbb:	test   ecx,ecx
   5dfbd:	je     5dfce <sqlite3VdbeExec+0xeb2e>
   5dfbf:	mov    BYTE PTR [r12+0x13],0x1
   5dfc5:	cmp    r13d,DWORD PTR [rax+0x50]
   5dfc9:	jne    5dfce <sqlite3VdbeExec+0xeb2e>
   5dfcb:	mov    BYTE PTR [rax],0x1
   5dfce:	mov    rax,QWORD PTR [rax+0x28]
   5dfd2:	test   rax,rax
   5dfd5:	jne    5dfb4 <sqlite3VdbeExec+0xeb14>
   5dfd7:	xor    eax,eax
   5dfd9:	mov    DWORD PTR [rsp+0x37c],r15d
   5dfe1:	lea    r12,[rsp+0x190]
   5dfe9:	mov    r15,QWORD PTR [rsp+0x188]
   5dff1:	mov    QWORD PTR [rsp+0x110],rdi
   5dff9:	mov    rdi,r15
   5dffc:	mov    rsi,r13
   5dfff:	mov    rdx,rax
   5e002:	mov    rcx,r12
   5e005:	call   5e00a <sqlite3VdbeExec+0xeb6a>
   5e00a:	mov    rdi,QWORD PTR [rsp+0x110]
   5e012:	mov    r15d,DWORD PTR [rsp+0x37c]
   5e01a:	mov    r12d,eax
   5e01d:	cmp    DWORD PTR [rbp+0xc],0x0
   5e021:	je     5e051 <sqlite3VdbeExec+0xebb1>
   5e023:	mov    rax,QWORD PTR [rdi+0x38]
   5e027:	add    rax,QWORD PTR [rsp+0x190]
   5e02f:	mov    QWORD PTR [rdi+0x38],rax
   5e033:	cmp    DWORD PTR [rbp+0xc],0x0
   5e037:	jle    5e051 <sqlite3VdbeExec+0xebb1>
   5e039:	movsxd rax,DWORD PTR [rbp+0xc]
   5e03d:	imul   rax,rax,0x38
   5e041:	mov    rcx,QWORD PTR [rbx+rax*1]
   5e045:	add    rcx,QWORD PTR [rsp+0x190]
   5e04d:	mov    QWORD PTR [rbx+rax*1],rcx
   5e051:	test   r12d,r12d
   5e054:	je     5e076 <sqlite3VdbeExec+0xebd6>
   5e056:	mov    QWORD PTR [rsp+0x148],rbp
   5e05e:	mov    rbp,r12
   5e061:	mov    r13,QWORD PTR [rsp+0x130]
   5e069:	mov    rbx,QWORD PTR [rsp+0x158]
   5e071:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5e076:	mov    DWORD PTR [rsp+0x37c],r15d
   5e07e:	mov    DWORD PTR [rsp+0x38c],r12d
   5e086:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5e08b:	mov    r15d,DWORD PTR [rsp+0x37c]
   5e093:	mov    r13,QWORD PTR [rsp+0x150]
   5e09b:	mov    QWORD PTR [rsp+0x130],r12
   5e0a3:	mov    r12d,DWORD PTR [rsp+0x394]
   5e0ab:	mov    rax,QWORD PTR [rdi+0x78]
   5e0af:	movsxd rcx,DWORD PTR [rbp+0x4]
   5e0b3:	mov    rax,QWORD PTR [rax+rcx*8]
   5e0b7:	cmp    BYTE PTR [rax],0x1
   5e0ba:	jne    5e0f8 <sqlite3VdbeExec+0xec58>
   5e0bc:	mov    rax,QWORD PTR [rax+0x28]
   5e0c0:	mov    QWORD PTR [rsp+0x110],rdi
   5e0c8:	mov    rdi,r14
   5e0cb:	mov    rsi,rax
   5e0ce:	call   5e0d3 <sqlite3VdbeExec+0xec33>
   5e0d3:	mov    rdi,QWORD PTR [rsp+0x110]
   5e0db:	mov    DWORD PTR [rsp+0x37c],r15d
   5e0e3:	mov    QWORD PTR [rsp+0x150],r13
   5e0eb:	mov    DWORD PTR [rsp+0x394],r12d
   5e0f3:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5e0f8:	mov    rax,QWORD PTR [rax+0x28]
   5e0fc:	mov    DWORD PTR [rsp+0x394],r12d
   5e104:	mov    r12,QWORD PTR [rax+0x8]
   5e108:	mov    QWORD PTR [rsp+0x150],r13
   5e110:	mov    r13d,DWORD PTR [rax+0x50]
   5e114:	mov    DWORD PTR [rsp+0x39c],r13d
   5e11c:	mov    r13,QWORD PTR [r12+0x8]
   5e121:	mov    rax,QWORD PTR [r12+0x8]
   5e126:	mov    rcx,QWORD PTR [r12]
   5e12a:	mov    QWORD PTR [rax+0x8],rcx
   5e12e:	xor    eax,eax
   5e130:	mov    rcx,QWORD PTR [r13+0x10]
   5e134:	jmp    5e19a <sqlite3VdbeExec+0xecfa>
   5e136:	test   rcx,rcx
   5e139:	jne    5e14d <sqlite3VdbeExec+0xecad>
   5e13b:	mov    QWORD PTR [rsp+0x190],r13
   5e143:	mov    r13d,DWORD PTR [rsp+0x39c]
   5e14b:	jmp    5e186 <sqlite3VdbeExec+0xece6>
   5e14d:	xor    edx,edx
   5e14f:	mov    QWORD PTR [rsp+0x190],r13
   5e157:	mov    r13d,DWORD PTR [rsp+0x39c]
   5e15f:	cmp    edx,r13d
   5e162:	jne    5e16e <sqlite3VdbeExec+0xecce>
   5e164:	mov    r13,QWORD PTR [rsp+0x190]
   5e16c:	jmp    5e19f <sqlite3VdbeExec+0xecff>
   5e16e:	cmp    r13d,DWORD PTR [rcx+0x50]
   5e172:	jne    5e186 <sqlite3VdbeExec+0xece6>
   5e174:	mov    DWORD PTR [rsp+0x39c],r13d
   5e17c:	mov    r13,QWORD PTR [rsp+0x190]
   5e184:	jmp    5e19f <sqlite3VdbeExec+0xecff>
   5e186:	mov    rcx,QWORD PTR [rcx+0x28]
   5e18a:	mov    DWORD PTR [rsp+0x39c],r13d
   5e192:	mov    r13,QWORD PTR [rsp+0x190]
   5e19a:	test   rcx,rcx
   5e19d:	jne    5e136 <sqlite3VdbeExec+0xec96>
   5e19f:	test   rcx,rcx
   5e1a2:	jne    5e1b6 <sqlite3VdbeExec+0xed16>
   5e1a4:	mov    QWORD PTR [rsp+0x190],r13
   5e1ac:	mov    r13d,DWORD PTR [rsp+0x39c]
   5e1b4:	jmp    5e1ff <sqlite3VdbeExec+0xed5f>
   5e1b6:	mov    QWORD PTR [rsp+0x190],r13
   5e1be:	mov    r13d,DWORD PTR [rsp+0x39c]
   5e1c6:	mov    QWORD PTR [rsp+0x110],rdi
   5e1ce:	mov    rdi,rcx
   5e1d1:	mov    rsi,r13
   5e1d4:	mov    rdx,rax
   5e1d7:	call   5e1dc <sqlite3VdbeExec+0xed3c>
   5e1dc:	xor    ecx,ecx
   5e1de:	mov    rdi,QWORD PTR [rsp+0x110]
   5e1e6:	cmp    ecx,eax
   5e1e8:	je     5e1ff <sqlite3VdbeExec+0xed5f>
   5e1ea:	mov    r13,QWORD PTR [rsp+0x150]
   5e1f2:	mov    r12d,DWORD PTR [rsp+0x394]
   5e1fa:	jmp    5e289 <sqlite3VdbeExec+0xede9>
   5e1ff:	cmp    BYTE PTR [r12+0x13],0x0
   5e205:	je     5e23b <sqlite3VdbeExec+0xed9b>
   5e207:	mov    BYTE PTR [r12+0x13],0x0
   5e20d:	mov    rax,QWORD PTR [r12+0x8]
   5e212:	mov    rax,QWORD PTR [rax+0x10]
   5e216:	jmp    5e236 <sqlite3VdbeExec+0xed96>
   5e218:	movzx  ecx,BYTE PTR [rax+0x1]
   5e21c:	and    ecx,0x10
   5e21f:	test   ecx,ecx
   5e221:	je     5e232 <sqlite3VdbeExec+0xed92>
   5e223:	mov    BYTE PTR [r12+0x13],0x1
   5e229:	cmp    r13d,DWORD PTR [rax+0x50]
   5e22d:	jne    5e232 <sqlite3VdbeExec+0xed92>
   5e22f:	mov    BYTE PTR [rax],0x1
   5e232:	mov    rax,QWORD PTR [rax+0x28]
   5e236:	test   rax,rax
   5e239:	jne    5e218 <sqlite3VdbeExec+0xed78>
   5e23b:	xor    eax,eax
   5e23d:	mov    DWORD PTR [rsp+0x37c],r15d
   5e245:	xor    r12d,r12d
   5e248:	mov    r15,QWORD PTR [rsp+0x190]
   5e250:	mov    QWORD PTR [rsp+0x110],rdi
   5e258:	mov    rdi,r15
   5e25b:	mov    rsi,r13
   5e25e:	mov    rdx,rax
   5e261:	mov    rcx,r12
   5e264:	call   5e269 <sqlite3VdbeExec+0xedc9>
   5e269:	mov    rdi,QWORD PTR [rsp+0x110]
   5e271:	mov    r15d,DWORD PTR [rsp+0x37c]
   5e279:	mov    r13,QWORD PTR [rsp+0x150]
   5e281:	mov    r12d,DWORD PTR [rsp+0x394]
   5e289:	mov    QWORD PTR [rsp+0x150],r13
   5e291:	mov    r13d,eax
   5e294:	test   r13d,r13d
   5e297:	jne    5e2ae <sqlite3VdbeExec+0xee0e>
   5e299:	mov    DWORD PTR [rsp+0x38c],r13d
   5e2a1:	mov    r13,QWORD PTR [rsp+0x150]
   5e2a9:	jmp    5e0db <sqlite3VdbeExec+0xec3b>
   5e2ae:	mov    QWORD PTR [rsp+0x148],rbp
   5e2b6:	mov    rbp,r13
   5e2b9:	mov    r13,QWORD PTR [rsp+0x130]
   5e2c1:	mov    rbx,QWORD PTR [rsp+0x158]
   5e2c9:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5e2ce:	mov    r15d,DWORD PTR [rsp+0x37c]
   5e2d6:	mov    r13,QWORD PTR [rsp+0x150]
   5e2de:	mov    QWORD PTR [rsp+0x130],r12
   5e2e6:	mov    r12d,DWORD PTR [rsp+0x394]
   5e2ee:	mov    rax,QWORD PTR [rdi+0x68]
   5e2f2:	movsxd rcx,DWORD PTR [rbp+0x8]
   5e2f6:	imul   rcx,rcx,0x38
   5e2fa:	mov    DWORD PTR [rsp+0x394],r12d
   5e302:	lea    r12,[rax+rcx*1]
   5e306:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5e30b:	and    eax,0x9000
   5e310:	test   eax,eax
   5e312:	je     5e331 <sqlite3VdbeExec+0xee91>
   5e314:	mov    QWORD PTR [rsp+0x110],rdi
   5e31c:	mov    rdi,r12
   5e31f:	call   5e324 <sqlite3VdbeExec+0xee84>
   5e324:	mov    r12,rax
   5e327:	mov    rdi,QWORD PTR [rsp+0x110]
   5e32f:	jmp    5e339 <sqlite3VdbeExec+0xee99>
   5e331:	mov    WORD PTR [r12+0x14],0x4
   5e339:	mov    DWORD PTR [rsp+0x39c],0x0
   5e344:	mov    rax,QWORD PTR [r14+0x20]
   5e348:	movsxd rcx,DWORD PTR [rbp+0x4]
   5e34c:	shl    rcx,0x5
   5e350:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   5e355:	mov    QWORD PTR [rsp+0x150],r13
   5e35d:	lea    r13,[rsp+0x39c]
   5e365:	mov    rcx,r13
   5e368:	mov    edx,DWORD PTR [rbp+0xc]
   5e36b:	mov    QWORD PTR [rsp+0x110],rdi
   5e373:	mov    rdi,rax
   5e376:	mov    rsi,rcx
   5e379:	call   5e37e <sqlite3VdbeExec+0xeede>
   5e37e:	mov    r13d,eax
   5e381:	mov    rdi,QWORD PTR [rsp+0x110]
   5e389:	test   r13d,r13d
   5e38c:	je     5e3ae <sqlite3VdbeExec+0xef0e>
   5e38e:	mov    QWORD PTR [rsp+0x148],rbp
   5e396:	mov    rbp,r13
   5e399:	mov    r13,QWORD PTR [rsp+0x130]
   5e3a1:	mov    rbx,QWORD PTR [rsp+0x158]
   5e3a9:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5e3ae:	mov    eax,DWORD PTR [rsp+0x39c]
   5e3b5:	mov    QWORD PTR [r12],rax
   5e3b9:	mov    DWORD PTR [rsp+0x37c],r15d
   5e3c1:	mov    DWORD PTR [rsp+0x38c],r13d
   5e3c9:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5e3ce:	mov    r15d,DWORD PTR [rsp+0x37c]
   5e3d6:	mov    QWORD PTR [rsp+0x130],r12
   5e3de:	movzx  eax,BYTE PTR [r14+0x70]
   5e3e3:	add    eax,0x1
   5e3e6:	mov    BYTE PTR [r14+0x70],al
   5e3ea:	mov    QWORD PTR [rsp+0x190],0x0
   5e3f6:	mov    r12,QWORD PTR [r14+0x1f8]
   5e3fd:	movzx  r13d,BYTE PTR [r14+0x6e]
   5e402:	mov    DWORD PTR [rsp+0x37c],r15d
   5e40a:	mov    r15d,DWORD PTR [r14+0x2e0]
   5e411:	mov    eax,DWORD PTR [rbp+0x4]
   5e414:	and    eax,0x1
   5e417:	test   eax,eax
   5e419:	je     5e42b <sqlite3VdbeExec+0xef8b>
   5e41b:	mov    QWORD PTR [r14+0x1f8],0x0
   5e426:	mov    BYTE PTR [r14+0x6e],0x0
   5e42b:	mov    eax,DWORD PTR [rbp+0x4]
   5e42e:	and    eax,0x2
   5e431:	test   eax,eax
   5e433:	je     5e43f <sqlite3VdbeExec+0xef9f>
   5e435:	mov    eax,DWORD PTR [rbp+0x8]
   5e438:	mov    DWORD PTR [r14+0x2e0],eax
   5e43f:	mov    rax,QWORD PTR [rbp+0x10]
   5e443:	xor    ecx,ecx
   5e445:	xor    edx,edx
   5e447:	mov    QWORD PTR [rsp+0x148],rbp
   5e44f:	lea    rbp,[rsp+0x190]
   5e457:	mov    rsi,rbp
   5e45a:	mov    QWORD PTR [rsp+0x110],rdi
   5e462:	mov    rdi,r14
   5e465:	mov    r8,rsi
   5e468:	mov    rsi,rax
   5e46b:	mov    r11,rdx
   5e46e:	mov    rdx,rcx
   5e471:	mov    rcx,r11
   5e474:	call   5e479 <sqlite3VdbeExec+0xefd9>
   5e479:	mov    ebp,eax
   5e47b:	movzx  eax,BYTE PTR [r14+0x70]
   5e480:	sub    eax,0x1
   5e483:	mov    BYTE PTR [r14+0x70],al
   5e487:	mov    QWORD PTR [r14+0x1f8],r12
   5e48e:	mov    BYTE PTR [r14+0x6e],r13b
   5e492:	mov    DWORD PTR [r14+0x2e0],r15d
   5e499:	mov    rdi,QWORD PTR [rsp+0x110]
   5e4a1:	cmp    QWORD PTR [rsp+0x190],0x0
   5e4aa:	jne    5e4b4 <sqlite3VdbeExec+0xf014>
   5e4ac:	test   ebp,ebp
   5e4ae:	je     5e595 <sqlite3VdbeExec+0xf0f5>
   5e4b4:	lea    rax,[rip+0x0]        # 5e4bb <sqlite3VdbeExec+0xf01b>
   5e4bb:	mov    rcx,QWORD PTR [rsp+0x190]
   5e4c3:	mov    QWORD PTR [rsp+0x110],rdi
   5e4cb:	mov    rsi,rax
   5e4ce:	mov    rdx,rcx
   5e4d1:	xor    eax,eax
   5e4d3:	call   5e4d8 <sqlite3VdbeExec+0xf038>
   5e4d8:	mov    rbx,QWORD PTR [rsp+0x190]
   5e4e0:	mov    rdi,QWORD PTR [rsp+0x110]
   5e4e8:	test   rbx,rbx
   5e4eb:	je     5e55e <sqlite3VdbeExec+0xf0be>
   5e4ed:	cmp    DWORD PTR [rip+0x0],0x0        # 5e4f4 <sqlite3VdbeExec+0xf054>
   5e4f4:	je     5e546 <sqlite3VdbeExec+0xf0a6>
   5e4f6:	mov    rax,QWORD PTR [rip+0x0]        # 5e4fd <sqlite3VdbeExec+0xf05d>
   5e4fd:	mov    rdi,rbx
   5e500:	mov    r10,rax
   5e503:	call   r10
   5e506:	mov    rcx,QWORD PTR [rip+0x0]        # 5e50d <sqlite3VdbeExec+0xf06d>
   5e50d:	movsxd rax,eax
   5e510:	sub    rcx,rax
   5e513:	mov    QWORD PTR [rip+0x0],rcx        # 5e51a <sqlite3VdbeExec+0xf07a>
   5e51a:	mov    rax,QWORD PTR [rip+0x0]        # 5e521 <sqlite3VdbeExec+0xf081>
   5e521:	sub    rax,0x1
   5e525:	mov    QWORD PTR [rip+0x0],rax        # 5e52c <sqlite3VdbeExec+0xf08c>
   5e52c:	mov    rax,QWORD PTR [rip+0x0]        # 5e533 <sqlite3VdbeExec+0xf093>
   5e533:	mov    rdi,rbx
   5e536:	mov    r10,rax
   5e539:	call   r10
   5e53c:	mov    rdi,QWORD PTR [rsp+0x110]
   5e544:	jmp    5e55e <sqlite3VdbeExec+0xf0be>
   5e546:	mov    rax,QWORD PTR [rip+0x0]        # 5e54d <sqlite3VdbeExec+0xf0ad>
   5e54d:	mov    rdi,rbx
   5e550:	mov    r10,rax
   5e553:	call   r10
   5e556:	mov    rdi,QWORD PTR [rsp+0x110]
   5e55e:	cmp    ebp,0x7
   5e561:	jne    5e580 <sqlite3VdbeExec+0xf0e0>
   5e563:	mov    r13,QWORD PTR [rsp+0x150]
   5e56b:	mov    rbx,QWORD PTR [rsp+0x148]
   5e573:	mov    rbp,QWORD PTR [rsp+0x158]
   5e57b:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5e580:	mov    r13,QWORD PTR [rsp+0x130]
   5e588:	mov    rbx,QWORD PTR [rsp+0x158]
   5e590:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5e595:	mov    DWORD PTR [rsp+0x38c],ebp
   5e59c:	mov    rbp,QWORD PTR [rsp+0x148]
   5e5a4:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5e5a9:	mov    QWORD PTR [rsp+0x148],rbp
   5e5b1:	mov    QWORD PTR [rsp+0x130],r12
   5e5b9:	mov    rbp,QWORD PTR [rsp+0x148]
   5e5c1:	movsxd r12,DWORD PTR [rbp+0x4]
   5e5c5:	cmp    QWORD PTR [rbp+0x10],0x0
   5e5ca:	jne    5e648 <sqlite3VdbeExec+0xf1a8>
   5e5cc:	mov    rax,QWORD PTR [r14+0x20]
   5e5d0:	mov    rcx,r12
   5e5d3:	shl    rcx,0x5
   5e5d7:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   5e5dc:	mov    QWORD PTR [rsp+0x110],rdi
   5e5e4:	mov    rdi,rax
   5e5e7:	call   5e5ec <sqlite3VdbeExec+0xf14c>
   5e5ec:	mov    eax,DWORD PTR [r14+0x2c]
   5e5f0:	and    eax,0xffffffef
   5e5f3:	mov    DWORD PTR [r14+0x2c],eax
   5e5f7:	mov    rdi,QWORD PTR [rsp+0x110]
   5e5ff:	lea    rax,[rdi+0xa8]
   5e606:	movzx  ecx,WORD PTR [rbp+0x2]
   5e60a:	mov    rdi,r14
   5e60d:	mov    rsi,r12
   5e610:	mov    rdx,rax
   5e613:	call   5e618 <sqlite3VdbeExec+0xf178>
   5e618:	mov    r12d,eax
   5e61b:	mov    eax,DWORD PTR [r14+0x2c]
   5e61f:	or     eax,0x1
   5e622:	mov    DWORD PTR [r14+0x2c],eax
   5e626:	mov    rdi,QWORD PTR [rsp+0x110]
   5e62e:	movzx  eax,WORD PTR [rdi+0xc8]
   5e635:	and    rax,0xfffffffffffffffc
   5e639:	mov    WORD PTR [rdi+0xc8],ax
   5e640:	mov    r15,r12
   5e643:	jmp    5e7a6 <sqlite3VdbeExec+0xf306>
   5e648:	lea    rax,[rip+0x0]        # 5e64f <sqlite3VdbeExec+0xf1af>
   5e64f:	mov    QWORD PTR [rsp+0x1e8],r14
   5e657:	mov    DWORD PTR [rsp+0x1f8],r12d
   5e65f:	lea    rcx,[rdi+0xa8]
   5e666:	mov    QWORD PTR [rsp+0x1f0],rcx
   5e66e:	mov    DWORD PTR [rsp+0x200],0x0
   5e679:	mov    rcx,QWORD PTR [r14+0x20]
   5e67d:	mov    rdx,r12
   5e680:	mov    rsi,rdx
   5e683:	shl    rsi,0x5
   5e687:	mov    rcx,QWORD PTR [rcx+rsi*1+0x8]
   5e68c:	mov    rcx,QWORD PTR [rcx+0x8]
   5e690:	mov    ecx,DWORD PTR [rcx+0x40]
   5e693:	mov    DWORD PTR [rsp+0x208],ecx
   5e69a:	lea    rcx,[rip+0x0]        # 5e6a1 <sqlite3VdbeExec+0xf201>
   5e6a1:	mov    rsi,QWORD PTR [r14+0x20]
   5e6a5:	shl    rdx,0x5
   5e6a9:	mov    rdx,QWORD PTR [rsi+rdx*1]
   5e6ad:	mov    rsi,QWORD PTR [rbp+0x10]
   5e6b1:	mov    QWORD PTR [rsp+0x110],rdi
   5e6b9:	mov    rdi,r14
   5e6bc:	mov    r8,rsi
   5e6bf:	mov    rsi,rcx
   5e6c2:	mov    rcx,rax
   5e6c5:	xor    eax,eax
   5e6c7:	call   5e6cc <sqlite3VdbeExec+0xf22c>
   5e6cc:	mov    r12,rax
   5e6cf:	mov    rdi,QWORD PTR [rsp+0x110]
   5e6d7:	test   r12,r12
   5e6da:	jne    5e6ea <sqlite3VdbeExec+0xf24a>
   5e6dc:	mov    r12d,0x7
   5e6e2:	mov    r15,r12
   5e6e5:	jmp    5e7a6 <sqlite3VdbeExec+0xf306>
   5e6ea:	mov    BYTE PTR [r14+0xc5],0x1
   5e6f2:	mov    DWORD PTR [rsp+0x1fc],0x0
   5e6fd:	mov    DWORD PTR [rsp+0x204],0x0
   5e708:	lea    rax,[rip+0x0]        # 5e70f <sqlite3VdbeExec+0xf26f>
   5e70f:	lea    r13,[rsp+0x1e8]
   5e717:	mov    rcx,r13
   5e71a:	xor    edx,edx
   5e71c:	mov    rdi,r14
   5e71f:	mov    rsi,r12
   5e722:	mov    r8,rdx
   5e725:	mov    rdx,rax
   5e728:	call   5e72d <sqlite3VdbeExec+0xf28d>
   5e72d:	mov    r15d,eax
   5e730:	mov    rdi,QWORD PTR [rsp+0x110]
   5e738:	test   r15d,r15d
   5e73b:	jne    5e745 <sqlite3VdbeExec+0xf2a5>
   5e73d:	mov    r15d,DWORD PTR [rsp+0x1fc]
   5e745:	test   r15d,r15d
   5e748:	jne    5e783 <sqlite3VdbeExec+0xf2e3>
   5e74a:	cmp    DWORD PTR [rsp+0x204],0x0
   5e752:	jne    5e783 <sqlite3VdbeExec+0xf2e3>
   5e754:	mov    eax,0x194dc
   5e759:	mov    ecx,0xb
   5e75e:	lea    rdx,[rip+0x0]        # 5e765 <sqlite3VdbeExec+0xf2c5>
   5e765:	mov    QWORD PTR [rsp+0x110],rdi
   5e76d:	mov    rdi,rcx
   5e770:	mov    rsi,rax
   5e773:	call   5e778 <sqlite3VdbeExec+0xf2d8>
   5e778:	mov    r15d,eax
   5e77b:	mov    rdi,QWORD PTR [rsp+0x110]
   5e783:	mov    QWORD PTR [rsp+0x110],rdi
   5e78b:	mov    rdi,r14
   5e78e:	mov    rsi,r12
   5e791:	call   5e796 <sqlite3VdbeExec+0xf2f6>
   5e796:	mov    BYTE PTR [r14+0xc5],0x0
   5e79e:	mov    rdi,QWORD PTR [rsp+0x110]
   5e7a6:	test   r15d,r15d
   5e7a9:	je     5e801 <sqlite3VdbeExec+0xf361>
   5e7ab:	mov    QWORD PTR [rsp+0x110],rdi
   5e7b3:	mov    rdi,r14
   5e7b6:	call   5e7bb <sqlite3VdbeExec+0xf31b>
   5e7bb:	mov    rdi,QWORD PTR [rsp+0x110]
   5e7c3:	cmp    r15d,0x7
   5e7c7:	jne    5e7e1 <sqlite3VdbeExec+0xf341>
   5e7c9:	mov    r13,QWORD PTR [rsp+0x150]
   5e7d1:	mov    rbx,rbp
   5e7d4:	mov    rbp,QWORD PTR [rsp+0x158]
   5e7dc:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5e7e1:	mov    QWORD PTR [rsp+0x148],rbp
   5e7e9:	mov    rbp,r15
   5e7ec:	mov    r13,QWORD PTR [rsp+0x130]
   5e7f4:	mov    rbx,QWORD PTR [rsp+0x158]
   5e7fc:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5e801:	mov    DWORD PTR [rsp+0x38c],r15d
   5e809:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5e80e:	mov    QWORD PTR [rsp+0x130],r12
   5e816:	mov    eax,DWORD PTR [rbp+0x4]
   5e819:	mov    QWORD PTR [rsp+0x110],rdi
   5e821:	mov    rdi,r14
   5e824:	mov    rsi,rax
   5e827:	call   5e82c <sqlite3VdbeExec+0xf38c>
   5e82c:	mov    r12d,eax
   5e82f:	mov    rdi,QWORD PTR [rsp+0x110]
   5e837:	test   r12d,r12d
   5e83a:	je     5e85c <sqlite3VdbeExec+0xf3bc>
   5e83c:	mov    QWORD PTR [rsp+0x148],rbp
   5e844:	mov    rbp,r12
   5e847:	mov    r13,QWORD PTR [rsp+0x130]
   5e84f:	mov    rbx,QWORD PTR [rsp+0x158]
   5e857:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5e85c:	mov    DWORD PTR [rsp+0x38c],r12d
   5e864:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5e869:	mov    r15d,DWORD PTR [rsp+0x37c]
   5e871:	mov    r13,QWORD PTR [rsp+0x150]
   5e879:	mov    QWORD PTR [rsp+0x130],r12
   5e881:	mov    r12d,DWORD PTR [rsp+0x394]
   5e889:	movsxd rax,DWORD PTR [rbp+0x4]
   5e88d:	mov    rcx,QWORD PTR [rbp+0x10]
   5e891:	mov    rdx,QWORD PTR [r14+0x20]
   5e895:	shl    rax,0x5
   5e899:	mov    rax,QWORD PTR [rdx+rax*1+0x18]
   5e89e:	add    rax,0x8
   5e8a2:	xor    edx,edx
   5e8a4:	mov    QWORD PTR [rsp+0x110],rdi
   5e8ac:	mov    rdi,rax
   5e8af:	mov    rsi,rcx
   5e8b2:	call   5e8b7 <sqlite3VdbeExec+0xf417>
   5e8b7:	mov    rdi,QWORD PTR [rsp+0x110]
   5e8bf:	test   rax,rax
   5e8c2:	je     5e8f6 <sqlite3VdbeExec+0xf456>
   5e8c4:	cmp    QWORD PTR [r14+0x300],0x0
   5e8cc:	jne    5e8db <sqlite3VdbeExec+0xf43b>
   5e8ce:	mov    ecx,DWORD PTR [rax+0x2c]
   5e8d1:	sub    ecx,0x1
   5e8d4:	mov    DWORD PTR [rax+0x2c],ecx
   5e8d7:	test   ecx,ecx
   5e8d9:	ja     5e8f6 <sqlite3VdbeExec+0xf456>
   5e8db:	mov    QWORD PTR [rsp+0x110],rdi
   5e8e3:	mov    rdi,r14
   5e8e6:	mov    rsi,rax
   5e8e9:	call   5e8ee <sqlite3VdbeExec+0xf44e>
   5e8ee:	mov    rdi,QWORD PTR [rsp+0x110]
   5e8f6:	mov    eax,DWORD PTR [r14+0x2c]
   5e8fa:	or     eax,0x1
   5e8fd:	mov    DWORD PTR [r14+0x2c],eax
   5e901:	mov    DWORD PTR [rsp+0x37c],r15d
   5e909:	mov    QWORD PTR [rsp+0x150],r13
   5e911:	mov    DWORD PTR [rsp+0x394],r12d
   5e919:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5e91e:	mov    r15d,DWORD PTR [rsp+0x37c]
   5e926:	mov    r13,QWORD PTR [rsp+0x150]
   5e92e:	mov    QWORD PTR [rsp+0x130],r12
   5e936:	mov    r12d,DWORD PTR [rsp+0x394]
   5e93e:	movsxd rax,DWORD PTR [rbp+0x4]
   5e942:	mov    rcx,QWORD PTR [rbp+0x10]
   5e946:	mov    rdx,QWORD PTR [r14+0x20]
   5e94a:	shl    rax,0x5
   5e94e:	mov    rax,QWORD PTR [rdx+rax*1+0x18]
   5e953:	add    rax,0x20
   5e957:	xor    edx,edx
   5e959:	mov    DWORD PTR [rsp+0x394],r12d
   5e961:	mov    QWORD PTR [rsp+0x110],rdi
   5e969:	mov    rdi,rax
   5e96c:	mov    rsi,rcx
   5e96f:	call   5e974 <sqlite3VdbeExec+0xf4d4>
   5e974:	mov    r12,rax
   5e977:	mov    rdi,QWORD PTR [rsp+0x110]
   5e97f:	test   r12,r12
   5e982:	je     5ea97 <sqlite3VdbeExec+0xf5f7>
   5e988:	mov    rax,QWORD PTR [r12+0x18]
   5e98d:	cmp    r12,QWORD PTR [rax+0x10]
   5e991:	jne    5e9a3 <sqlite3VdbeExec+0xf503>
   5e993:	mov    rax,QWORD PTR [r12+0x18]
   5e998:	mov    rcx,QWORD PTR [r12+0x28]
   5e99d:	mov    QWORD PTR [rax+0x10],rcx
   5e9a1:	jmp    5e9d1 <sqlite3VdbeExec+0xf531>
   5e9a3:	mov    rax,QWORD PTR [r12+0x18]
   5e9a8:	mov    rax,QWORD PTR [rax+0x10]
   5e9ac:	jmp    5e9b8 <sqlite3VdbeExec+0xf518>
   5e9ae:	cmp    r12,QWORD PTR [rax+0x28]
   5e9b2:	je     5e9bd <sqlite3VdbeExec+0xf51d>
   5e9b4:	mov    rax,QWORD PTR [rax+0x28]
   5e9b8:	test   rax,rax
   5e9bb:	jne    5e9ae <sqlite3VdbeExec+0xf50e>
   5e9bd:	test   rax,rax
   5e9c0:	je     5e9d1 <sqlite3VdbeExec+0xf531>
   5e9c2:	cmp    r12,QWORD PTR [rax+0x28]
   5e9c6:	jne    5e9d1 <sqlite3VdbeExec+0xf531>
   5e9c8:	mov    rcx,QWORD PTR [r12+0x28]
   5e9cd:	mov    QWORD PTR [rax+0x28],rcx
   5e9d1:	mov    rax,QWORD PTR [r12+0x48]
   5e9d6:	test   rax,rax
   5e9d9:	je     5e9f6 <sqlite3VdbeExec+0xf556>
   5e9db:	mov    QWORD PTR [rsp+0x110],rdi
   5e9e3:	mov    rdi,r14
   5e9e6:	mov    rsi,rax
   5e9e9:	call   5e9ee <sqlite3VdbeExec+0xf54e>
   5e9ee:	mov    rdi,QWORD PTR [rsp+0x110]
   5e9f6:	mov    rax,QWORD PTR [r12+0x50]
   5e9fb:	test   rax,rax
   5e9fe:	je     5ea1b <sqlite3VdbeExec+0xf57b>
   5ea00:	mov    QWORD PTR [rsp+0x110],rdi
   5ea08:	mov    rdi,r14
   5ea0b:	mov    rsi,rax
   5ea0e:	call   5ea13 <sqlite3VdbeExec+0xf573>
   5ea13:	mov    rdi,QWORD PTR [rsp+0x110]
   5ea1b:	mov    rax,QWORD PTR [r12+0x20]
   5ea20:	test   rax,rax
   5ea23:	je     5ea40 <sqlite3VdbeExec+0xf5a0>
   5ea25:	mov    QWORD PTR [rsp+0x110],rdi
   5ea2d:	mov    rdi,r14
   5ea30:	mov    rsi,rax
   5ea33:	call   5ea38 <sqlite3VdbeExec+0xf598>
   5ea38:	mov    rdi,QWORD PTR [rsp+0x110]
   5ea40:	movzx  eax,WORD PTR [r12+0x63]
   5ea46:	shl    rax,0x3b
   5ea4a:	shr    rax,0x3f
   5ea4e:	test   eax,eax
   5ea50:	je     5ea77 <sqlite3VdbeExec+0xf5d7>
   5ea52:	mov    rax,QWORD PTR [r12+0x40]
   5ea57:	test   rax,rax
   5ea5a:	je     5ea77 <sqlite3VdbeExec+0xf5d7>
   5ea5c:	mov    QWORD PTR [rsp+0x110],rdi
   5ea64:	mov    rdi,r14
   5ea67:	mov    rsi,rax
   5ea6a:	call   5ea6f <sqlite3VdbeExec+0xf5cf>
   5ea6f:	mov    rdi,QWORD PTR [rsp+0x110]
   5ea77:	test   r12,r12
   5ea7a:	je     5ea97 <sqlite3VdbeExec+0xf5f7>
   5ea7c:	mov    QWORD PTR [rsp+0x110],rdi
   5ea84:	mov    rdi,r14
   5ea87:	mov    rsi,r12
   5ea8a:	call   5ea8f <sqlite3VdbeExec+0xf5ef>
   5ea8f:	mov    rdi,QWORD PTR [rsp+0x110]
   5ea97:	mov    eax,DWORD PTR [r14+0x2c]
   5ea9b:	or     eax,0x1
   5ea9e:	mov    DWORD PTR [r14+0x2c],eax
   5eaa2:	mov    DWORD PTR [rsp+0x37c],r15d
   5eaaa:	mov    QWORD PTR [rsp+0x150],r13
   5eab2:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5eab7:	mov    r15d,DWORD PTR [rsp+0x37c]
   5eabf:	mov    r13,QWORD PTR [rsp+0x150]
   5eac7:	mov    QWORD PTR [rsp+0x130],r12
   5eacf:	movsxd rax,DWORD PTR [rbp+0x4]
   5ead3:	mov    rcx,QWORD PTR [rbp+0x10]
   5ead7:	mov    rdx,QWORD PTR [r14+0x20]
   5eadb:	shl    rax,0x5
   5eadf:	mov    rax,QWORD PTR [rdx+rax*1+0x18]
   5eae4:	add    rax,0x38
   5eae8:	xor    edx,edx
   5eaea:	mov    QWORD PTR [rsp+0x110],rdi
   5eaf2:	mov    rdi,rax
   5eaf5:	mov    rsi,rcx
   5eaf8:	call   5eafd <sqlite3VdbeExec+0xf65d>
   5eafd:	mov    r12,rax
   5eb00:	mov    rdi,QWORD PTR [rsp+0x110]
   5eb08:	test   r12,r12
   5eb0b:	je     5ee5f <sqlite3VdbeExec+0xf9bf>
   5eb11:	mov    rax,QWORD PTR [r12+0x28]
   5eb16:	cmp    rax,QWORD PTR [r12+0x30]
   5eb1b:	jne    5ec6a <sqlite3VdbeExec+0xf7ca>
   5eb21:	mov    rax,QWORD PTR [r12+0x30]
   5eb26:	mov    rcx,QWORD PTR [r12+0x8]
   5eb2b:	xor    edx,edx
   5eb2d:	mov    rsi,rcx
   5eb30:	jmp    5eb4a <sqlite3VdbeExec+0xf6aa>
   5eb32:	movzx  r8d,BYTE PTR [rsi]
   5eb36:	add    rsi,0x1
   5eb3a:	and    r8d,0xdf
   5eb41:	add    edx,r8d
   5eb44:	imul   edx,edx,0x9e3779b1
   5eb4a:	cmp    BYTE PTR [rsi],0x0
   5eb4d:	jne    5eb32 <sqlite3VdbeExec+0xf692>
   5eb4f:	mov    esi,edx
   5eb51:	cmp    QWORD PTR [rax+0x18],0x0
   5eb56:	je     5eb79 <sqlite3VdbeExec+0xf6d9>
   5eb58:	mov    r8,QWORD PTR [rax+0x18]
   5eb5c:	mov    r9d,DWORD PTR [rax+0x8]
   5eb60:	mov    rax,rsi
   5eb63:	xor    edx,edx
   5eb65:	div    r9d
   5eb68:	mov    eax,edx
   5eb6a:	shl    rax,0x4
   5eb6e:	mov    rdx,QWORD PTR [r8+rax*1+0x8]
   5eb73:	mov    eax,DWORD PTR [r8+rax*1]
   5eb77:	jmp    5eb80 <sqlite3VdbeExec+0xf6e0>
   5eb79:	mov    rdx,QWORD PTR [rax+0x10]
   5eb7d:	mov    eax,DWORD PTR [rax+0xc]
   5eb80:	mov    r10,rax
   5eb83:	mov    rax,rdx
   5eb86:	jmp    5ec10 <sqlite3VdbeExec+0xf770>
   5eb8b:	mov    QWORD PTR [rsp+0x100],rdi
   5eb93:	lea    rdi,[rip+0x0]        # 5eb9a <sqlite3VdbeExec+0xf6fa>
   5eb9a:	movzx  edx,BYTE PTR [rdi+rdx*1]
   5eb9e:	movzx  edi,BYTE PTR [rdi+r9*1]
   5eba3:	sub    edx,edi
   5eba5:	test   edx,edx
   5eba7:	je     5ebc9 <sqlite3VdbeExec+0xf729>
   5eba9:	test   edx,edx
   5ebab:	je     5ebb7 <sqlite3VdbeExec+0xf717>
   5ebad:	mov    rdi,QWORD PTR [rsp+0x100]
   5ebb5:	jmp    5ec01 <sqlite3VdbeExec+0xf761>
   5ebb7:	mov    rdi,QWORD PTR [rsp+0x100]
   5ebbf:	mov    rax,QWORD PTR [rsp+0x188]
   5ebc7:	jmp    5ec3f <sqlite3VdbeExec+0xf79f>
   5ebc9:	add    rax,0x1
   5ebcd:	add    r8,0x1
   5ebd1:	mov    rdi,QWORD PTR [rsp+0x100]
   5ebd9:	movzx  edx,BYTE PTR [rax]
   5ebdc:	movzx  r9d,BYTE PTR [r8]
   5ebe0:	cmp    edx,r9d
   5ebe3:	jne    5eb8b <sqlite3VdbeExec+0xf6eb>
   5ebe5:	test   edx,edx
   5ebe7:	je     5ebf3 <sqlite3VdbeExec+0xf753>
   5ebe9:	mov    QWORD PTR [rsp+0x100],rdi
   5ebf1:	jmp    5ebc9 <sqlite3VdbeExec+0xf729>
   5ebf3:	test   edx,edx
   5ebf5:	jne    5ec01 <sqlite3VdbeExec+0xf761>
   5ebf7:	mov    QWORD PTR [rsp+0x100],rdi
   5ebff:	jmp    5ebb7 <sqlite3VdbeExec+0xf717>
   5ec01:	mov    rax,QWORD PTR [rsp+0x188]
   5ec09:	mov    rax,QWORD PTR [rax]
   5ec0c:	sub    r10d,0x1
   5ec10:	test   r10d,r10d
   5ec13:	je     5ec38 <sqlite3VdbeExec+0xf798>
   5ec15:	cmp    esi,DWORD PTR [rax+0x20]
   5ec18:	je     5ec24 <sqlite3VdbeExec+0xf784>
   5ec1a:	mov    QWORD PTR [rsp+0x188],rax
   5ec22:	jmp    5ec01 <sqlite3VdbeExec+0xf761>
   5ec24:	mov    rdx,QWORD PTR [rax+0x18]
   5ec28:	mov    QWORD PTR [rsp+0x188],rax
   5ec30:	mov    rax,rdx
   5ec33:	mov    r8,rcx
   5ec36:	jmp    5ebd9 <sqlite3VdbeExec+0xf739>
   5ec38:	lea    rax,[rip+0x0]        # 5ec3f <sqlite3VdbeExec+0xf79f>
   5ec3f:	mov    rax,QWORD PTR [rax+0x10]
   5ec43:	test   rax,rax
   5ec46:	je     5ec6a <sqlite3VdbeExec+0xf7ca>
   5ec48:	add    rax,0x58
   5ec4c:	jmp    5ec55 <sqlite3VdbeExec+0xf7b5>
   5ec4e:	mov    rax,QWORD PTR [rax]
   5ec51:	add    rax,0x40
   5ec55:	cmp    QWORD PTR [rax],0x0
   5ec59:	je     5ec6a <sqlite3VdbeExec+0xf7ca>
   5ec5b:	cmp    r12,QWORD PTR [rax]
   5ec5e:	jne    5ec4e <sqlite3VdbeExec+0xf7ae>
   5ec60:	mov    rcx,QWORD PTR [rax]
   5ec63:	mov    rcx,QWORD PTR [rcx+0x40]
   5ec67:	mov    QWORD PTR [rax],rcx
   5ec6a:	test   r12,r12
   5ec6d:	je     5ee54 <sqlite3VdbeExec+0xf9b4>
   5ec73:	cmp    BYTE PTR [r12+0x12],0x0
   5ec79:	jne    5ee54 <sqlite3VdbeExec+0xf9b4>
   5ec7f:	mov    QWORD PTR [rsp+0x190],r12
   5ec87:	mov    r12,QWORD PTR [r12+0x38]
   5ec8c:	jmp    5ed9d <sqlite3VdbeExec+0xf8fd>
   5ec91:	mov    QWORD PTR [rsp+0x150],r13
   5ec99:	mov    r13,QWORD PTR [r12+0x48]
   5ec9e:	mov    rax,QWORD PTR [r12+0x20]
   5eca3:	test   rax,rax
   5eca6:	je     5ecc3 <sqlite3VdbeExec+0xf823>
   5eca8:	mov    QWORD PTR [rsp+0x110],rdi
   5ecb0:	mov    rdi,r14
   5ecb3:	mov    rsi,rax
   5ecb6:	call   5ecbb <sqlite3VdbeExec+0xf81b>
   5ecbb:	mov    rdi,QWORD PTR [rsp+0x110]
   5ecc3:	mov    rax,QWORD PTR [r12+0x28]
   5ecc8:	test   rax,rax
   5eccb:	je     5ece8 <sqlite3VdbeExec+0xf848>
   5eccd:	mov    QWORD PTR [rsp+0x110],rdi
   5ecd5:	mov    rdi,r14
   5ecd8:	mov    rsi,rax
   5ecdb:	call   5ece0 <sqlite3VdbeExec+0xf840>
   5ece0:	mov    rdi,QWORD PTR [rsp+0x110]
   5ece8:	mov    rax,QWORD PTR [r12+0x10]
   5eced:	mov    QWORD PTR [rsp+0x110],rdi
   5ecf5:	mov    rdi,r14
   5ecf8:	mov    rsi,rax
   5ecfb:	call   5ed00 <sqlite3VdbeExec+0xf860>
   5ed00:	mov    rax,QWORD PTR [r12+0x30]
   5ed05:	mov    rdi,r14
   5ed08:	mov    rsi,rax
   5ed0b:	call   5ed10 <sqlite3VdbeExec+0xf870>
   5ed10:	mov    rax,QWORD PTR [r12+0x38]
   5ed15:	mov    rdi,QWORD PTR [rsp+0x110]
   5ed1d:	test   rax,rax
   5ed20:	je     5ed35 <sqlite3VdbeExec+0xf895>
   5ed22:	mov    rdi,r14
   5ed25:	mov    rsi,rax
   5ed28:	call   5ed2d <sqlite3VdbeExec+0xf88d>
   5ed2d:	mov    rdi,QWORD PTR [rsp+0x110]
   5ed35:	mov    rax,QWORD PTR [r12+0x18]
   5ed3a:	mov    QWORD PTR [rsp+0x110],rdi
   5ed42:	mov    rdi,r14
   5ed45:	mov    rsi,rax
   5ed48:	call   5ed4d <sqlite3VdbeExec+0xf8ad>
   5ed4d:	mov    rax,QWORD PTR [r12+0x40]
   5ed52:	mov    rdi,QWORD PTR [rsp+0x110]
   5ed5a:	test   rax,rax
   5ed5d:	je     5ed72 <sqlite3VdbeExec+0xf8d2>
   5ed5f:	mov    rdi,r14
   5ed62:	mov    rsi,rax
   5ed65:	call   5ed6a <sqlite3VdbeExec+0xf8ca>
   5ed6a:	mov    rdi,QWORD PTR [rsp+0x110]
   5ed72:	test   r12,r12
   5ed75:	je     5ed92 <sqlite3VdbeExec+0xf8f2>
   5ed77:	mov    QWORD PTR [rsp+0x110],rdi
   5ed7f:	mov    rdi,r14
   5ed82:	mov    rsi,r12
   5ed85:	call   5ed8a <sqlite3VdbeExec+0xf8ea>
   5ed8a:	mov    rdi,QWORD PTR [rsp+0x110]
   5ed92:	mov    r12,r13
   5ed95:	mov    r13,QWORD PTR [rsp+0x150]
   5ed9d:	test   r12,r12
   5eda0:	jne    5ec91 <sqlite3VdbeExec+0xf7f1>
   5eda6:	mov    r12,QWORD PTR [rsp+0x190]
   5edae:	mov    rax,QWORD PTR [r12]
   5edb2:	test   rax,rax
   5edb5:	je     5edd2 <sqlite3VdbeExec+0xf932>
   5edb7:	mov    QWORD PTR [rsp+0x110],rdi
   5edbf:	mov    rdi,r14
   5edc2:	mov    rsi,rax
   5edc5:	call   5edca <sqlite3VdbeExec+0xf92a>
   5edca:	mov    rdi,QWORD PTR [rsp+0x110]
   5edd2:	mov    rax,QWORD PTR [r12+0x8]
   5edd7:	test   rax,rax
   5edda:	je     5edf7 <sqlite3VdbeExec+0xf957>
   5eddc:	mov    QWORD PTR [rsp+0x110],rdi
   5ede4:	mov    rdi,r14
   5ede7:	mov    rsi,rax
   5edea:	call   5edef <sqlite3VdbeExec+0xf94f>
   5edef:	mov    rdi,QWORD PTR [rsp+0x110]
   5edf7:	mov    rax,QWORD PTR [r12+0x18]
   5edfc:	test   rax,rax
   5edff:	je     5ee1c <sqlite3VdbeExec+0xf97c>
   5ee01:	mov    QWORD PTR [rsp+0x110],rdi
   5ee09:	mov    rdi,r14
   5ee0c:	mov    rsi,rax
   5ee0f:	call   5ee14 <sqlite3VdbeExec+0xf974>
   5ee14:	mov    rdi,QWORD PTR [rsp+0x110]
   5ee1c:	mov    rax,QWORD PTR [r12+0x20]
   5ee21:	mov    QWORD PTR [rsp+0x110],rdi
   5ee29:	mov    rdi,r14
   5ee2c:	mov    rsi,rax
   5ee2f:	call   5ee34 <sqlite3VdbeExec+0xf994>
   5ee34:	mov    rdi,QWORD PTR [rsp+0x110]
   5ee3c:	test   r12,r12
   5ee3f:	je     5ee54 <sqlite3VdbeExec+0xf9b4>
   5ee41:	mov    rdi,r14
   5ee44:	mov    rsi,r12
   5ee47:	call   5ee4c <sqlite3VdbeExec+0xf9ac>
   5ee4c:	mov    rdi,QWORD PTR [rsp+0x110]
   5ee54:	mov    eax,DWORD PTR [r14+0x2c]
   5ee58:	or     eax,0x1
   5ee5b:	mov    DWORD PTR [r14+0x2c],eax
   5ee5f:	mov    DWORD PTR [rsp+0x37c],r15d
   5ee67:	mov    QWORD PTR [rsp+0x150],r13
   5ee6f:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5ee74:	mov    r15d,DWORD PTR [rsp+0x37c]
   5ee7c:	mov    r13,QWORD PTR [rsp+0x150]
   5ee84:	mov    QWORD PTR [rsp+0x130],r12
   5ee8c:	mov    r12d,DWORD PTR [rbp+0x8]
   5ee90:	mov    DWORD PTR [rsp+0x3a8],r12d
   5ee98:	mov    r12,QWORD PTR [rbp+0x10]
   5ee9c:	movsxd rax,DWORD PTR [rbp+0x4]
   5eea0:	mov    QWORD PTR [rsp+0x150],r13
   5eea8:	imul   r13,rax,0x38
   5eeac:	mov    eax,DWORD PTR [rbp+0x4]
   5eeaf:	add    eax,0x1
   5eeb2:	movsxd rax,eax
   5eeb5:	imul   rax,rax,0x38
   5eeb9:	mov    DWORD PTR [rsp+0x37c],r15d
   5eec1:	lea    r15,[rbx+rax*1]
   5eec5:	mov    rax,QWORD PTR [r14+0x20]
   5eec9:	movzx  ecx,WORD PTR [rbp+0x2]
   5eecd:	shl    rcx,0x5
   5eed1:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   5eed6:	movsxd rcx,DWORD PTR [rbp+0xc]
   5eeda:	imul   rcx,rcx,0x38
   5eede:	mov    QWORD PTR [rsp+0x168],r15
   5eee6:	lea    r15,[rbx+rcx*1]
   5eeea:	mov    rcx,QWORD PTR [rbx+r13*1]
   5eeee:	mov    QWORD PTR [rsp+0x198],r15
   5eef6:	lea    r15d,[rcx+0x1]
   5eefa:	mov    DWORD PTR [rsp+0x398],r15d
   5ef02:	mov    r15,QWORD PTR [rax+0x8]
   5ef06:	mov    rcx,QWORD PTR [r15+0x8]
   5ef0a:	mov    QWORD PTR [rsp+0x188],r13
   5ef12:	mov    r13,QWORD PTR [rcx+0x30]
   5ef16:	cmp    DWORD PTR [r12+0x4],0x0
   5ef1c:	je     5ef39 <sqlite3VdbeExec+0xfa99>
   5ef1e:	mov    QWORD PTR [rsp+0x1a0],r13
   5ef26:	xor    r11d,r11d
   5ef29:	mov    DWORD PTR [rsp+0x3a4],r11d
   5ef31:	mov    r13d,0x1
   5ef37:	jmp    5ef61 <sqlite3VdbeExec+0xfac1>
   5ef39:	xor    ecx,ecx
   5ef3b:	mov    QWORD PTR [rsp+0x1a0],r13
   5ef43:	mov    r13d,0x1
   5ef49:	cmp    DWORD PTR [r12+0x8],0x1
   5ef4f:	cmovne r13d,ecx
   5ef53:	mov    r11d,0x1
   5ef59:	mov    DWORD PTR [rsp+0x3a4],r11d
   5ef61:	mov    rcx,QWORD PTR [rax+0x8]
   5ef65:	mov    rax,QWORD PTR [rax]
   5ef68:	mov    QWORD PTR [rcx+0x8],rax
   5ef6c:	mov    QWORD PTR [rsp+0x160],rbx
   5ef74:	lea    rbx,[rsp+0x2f8]
   5ef7c:	mov    rax,rbx
   5ef7f:	xor    ecx,ecx
   5ef81:	mov    edx,0x80
   5ef86:	mov    QWORD PTR [rsp+0x110],rdi
   5ef8e:	mov    rdi,rax
   5ef91:	mov    rsi,rcx
   5ef94:	call   5ef99 <sqlite3VdbeExec+0xfaf9>
   5ef99:	mov    QWORD PTR [rbx+0x70],r14
   5ef9d:	mov    QWORD PTR [rbx],r15
   5efa0:	mov    rax,QWORD PTR [r15]
   5efa3:	mov    QWORD PTR [rbx+0x8],rax
   5efa7:	mov    rax,QWORD PTR [rbx]
   5efaa:	mov    eax,DWORD PTR [rax+0x40]
   5efad:	mov    DWORD PTR [rbx+0x18],eax
   5efb0:	mov    QWORD PTR [rsp+0x128],r14
   5efb8:	mov    r14d,DWORD PTR [rsp+0x398]
   5efc0:	mov    DWORD PTR [rbx+0x1c],r14d
   5efc4:	lea    r14,[rsp+0x90]
   5efcc:	mov    rax,r14
   5efcf:	mov    QWORD PTR [rbx+0x50],rax
   5efd3:	mov    QWORD PTR [rbx+0x48],0x0
   5efdb:	mov    DWORD PTR [rbx+0x58],0x64
   5efe2:	mov    DWORD PTR [rbx+0x5c],0x3b9aca00
   5efe9:	mov    DWORD PTR [rbx+0x60],0x0
   5eff0:	mov    BYTE PTR [rbx+0x64],0x0
   5eff4:	mov    BYTE PTR [rbx+0x65],0x0
   5eff8:	mov    BYTE PTR [rbx+0x65],0x1
   5effc:	mov    rdi,QWORD PTR [rsp+0x110]
   5f004:	cmp    DWORD PTR [rbx+0x18],0x0
   5f008:	je     5f082 <sqlite3VdbeExec+0xfbe2>
   5f00a:	mov    eax,DWORD PTR [rbx+0x18]
   5f00d:	shr    eax,0x3
   5f010:	add    eax,0x1
   5f013:	mov    r14,rax
   5f016:	mov    rdi,r14
   5f019:	call   5f01e <sqlite3VdbeExec+0xfb7e>
   5f01e:	mov    rdi,QWORD PTR [rsp+0x110]
   5f026:	test   rax,rax
   5f029:	je     5f056 <sqlite3VdbeExec+0xfbb6>
   5f02b:	xor    ecx,ecx
   5f02d:	mov    QWORD PTR [rsp+0x108],rax
   5f035:	mov    rdi,rax
   5f038:	mov    rsi,rcx
   5f03b:	mov    rdx,r14
   5f03e:	call   5f043 <sqlite3VdbeExec+0xfba3>
   5f043:	mov    rcx,rax
   5f046:	mov    rax,QWORD PTR [rsp+0x108]
   5f04e:	mov    rdi,QWORD PTR [rsp+0x110]
   5f056:	mov    QWORD PTR [rbx+0x10],rax
   5f05a:	cmp    QWORD PTR [rbx+0x10],0x0
   5f05f:	jne    5f10b <sqlite3VdbeExec+0xfc6b>
   5f065:	mov    DWORD PTR [rbx+0x24],0x7
   5f06c:	mov    DWORD PTR [rbx+0x1c],0x0
   5f073:	cmp    DWORD PTR [rbx+0x20],0x0
   5f077:	jne    5f082 <sqlite3VdbeExec+0xfbe2>
   5f079:	mov    eax,DWORD PTR [rbx+0x20]
   5f07c:	add    eax,0x1
   5f07f:	mov    DWORD PTR [rbx+0x20],eax
   5f082:	mov    rax,QWORD PTR [rbx+0x68]
   5f086:	mov    QWORD PTR [rsp+0x110],rdi
   5f08e:	mov    rdi,rax
   5f091:	call   5f096 <sqlite3VdbeExec+0xfbf6>
   5f096:	mov    r12,QWORD PTR [rbx+0x10]
   5f09a:	mov    rdi,QWORD PTR [rsp+0x110]
   5f0a2:	test   r12,r12
   5f0a5:	je     5f990 <sqlite3VdbeExec+0x104f0>
   5f0ab:	cmp    DWORD PTR [rip+0x0],0x0        # 5f0b2 <sqlite3VdbeExec+0xfc12>
   5f0b2:	je     5f978 <sqlite3VdbeExec+0x104d8>
   5f0b8:	mov    rax,QWORD PTR [rip+0x0]        # 5f0bf <sqlite3VdbeExec+0xfc1f>
   5f0bf:	mov    rdi,r12
   5f0c2:	mov    r10,rax
   5f0c5:	call   r10
   5f0c8:	mov    rcx,QWORD PTR [rip+0x0]        # 5f0cf <sqlite3VdbeExec+0xfc2f>
   5f0cf:	movsxd rax,eax
   5f0d2:	sub    rcx,rax
   5f0d5:	mov    QWORD PTR [rip+0x0],rcx        # 5f0dc <sqlite3VdbeExec+0xfc3c>
   5f0dc:	mov    rax,QWORD PTR [rip+0x0]        # 5f0e3 <sqlite3VdbeExec+0xfc43>
   5f0e3:	sub    rax,0x1
   5f0e7:	mov    QWORD PTR [rip+0x0],rax        # 5f0ee <sqlite3VdbeExec+0xfc4e>
   5f0ee:	mov    rax,QWORD PTR [rip+0x0]        # 5f0f5 <sqlite3VdbeExec+0xfc55>
   5f0f5:	mov    rdi,r12
   5f0f8:	mov    r10,rax
   5f0fb:	call   r10
   5f0fe:	mov    rdi,QWORD PTR [rsp+0x110]
   5f106:	jmp    5f990 <sqlite3VdbeExec+0x104f0>
   5f10b:	mov    eax,DWORD PTR [r15+0x34]
   5f10f:	mov    QWORD PTR [rsp+0x110],rdi
   5f117:	mov    rdi,rax
   5f11a:	call   5f11f <sqlite3VdbeExec+0xfc7f>
   5f11f:	mov    QWORD PTR [rbx+0x68],rax
   5f123:	mov    rdi,QWORD PTR [rsp+0x110]
   5f12b:	cmp    QWORD PTR [rbx+0x68],0x0
   5f130:	jne    5f158 <sqlite3VdbeExec+0xfcb8>
   5f132:	mov    DWORD PTR [rbx+0x24],0x7
   5f139:	mov    DWORD PTR [rbx+0x1c],0x0
   5f140:	cmp    DWORD PTR [rbx+0x20],0x0
   5f144:	jne    5f082 <sqlite3VdbeExec+0xfbe2>
   5f14a:	mov    eax,DWORD PTR [rbx+0x20]
   5f14d:	add    eax,0x1
   5f150:	mov    DWORD PTR [rbx+0x20],eax
   5f153:	jmp    5f082 <sqlite3VdbeExec+0xfbe2>
   5f158:	mov    eax,DWORD PTR [rip+0x0]        # 5f15e <sqlite3VdbeExec+0xfcbe>
   5f15e:	mov    ecx,DWORD PTR [r15+0x34]
   5f162:	xor    edx,edx
   5f164:	div    ecx
   5f166:	add    eax,0x1
   5f169:	cmp    eax,DWORD PTR [rbx+0x18]
   5f16c:	ja     5f198 <sqlite3VdbeExec+0xfcf8>
   5f16e:	mov    rdx,QWORD PTR [rbx+0x10]
   5f172:	mov    ecx,eax
   5f174:	shr    ecx,0x3
   5f177:	mov    rsi,rcx
   5f17a:	movzx  ecx,BYTE PTR [rdx+rsi*1]
   5f17e:	mov    r8d,ecx
   5f181:	mov    r9d,0x1
   5f187:	and    eax,0x7
   5f18a:	mov    ecx,eax
   5f18c:	mov    rax,r9
   5f18f:	shl    eax,cl
   5f191:	or     r8d,eax
   5f194:	mov    BYTE PTR [rdx+rsi*1],r8b
   5f198:	test   r13d,r13d
   5f19b:	je     5f23a <sqlite3VdbeExec+0xfd9a>
   5f1a1:	lea    rax,[rip+0x0]        # 5f1a8 <sqlite3VdbeExec+0xfd08>
   5f1a8:	mov    QWORD PTR [rbx+0x30],rax
   5f1ac:	mov    rax,rbx
   5f1af:	mov    ecx,0x1
   5f1b4:	mov    rdx,QWORD PTR [r15+0x18]
   5f1b8:	mov    rdx,QWORD PTR [rdx+0x50]
   5f1bc:	movzx  esi,BYTE PTR [rdx+0x20]
   5f1c0:	shl    esi,0x18
   5f1c3:	movzx  r8d,BYTE PTR [rdx+0x21]
   5f1c8:	shl    r8d,0x10
   5f1cc:	or     esi,r8d
   5f1cf:	movzx  r8d,BYTE PTR [rdx+0x22]
   5f1d4:	shl    r8d,0x8
   5f1d8:	or     esi,r8d
   5f1db:	movzx  edx,BYTE PTR [rdx+0x23]
   5f1df:	or     esi,edx
   5f1e1:	mov    rdx,QWORD PTR [r15+0x18]
   5f1e5:	mov    rdx,QWORD PTR [rdx+0x50]
   5f1e9:	movzx  r8d,BYTE PTR [rdx+0x24]
   5f1ee:	shl    r8d,0x18
   5f1f2:	movzx  r9d,BYTE PTR [rdx+0x25]
   5f1f7:	shl    r9d,0x10
   5f1fb:	or     r8d,r9d
   5f1fe:	movzx  r9d,BYTE PTR [rdx+0x26]
   5f203:	shl    r9d,0x8
   5f207:	or     r8d,r9d
   5f20a:	movzx  edx,BYTE PTR [rdx+0x27]
   5f20e:	or     r8d,edx
   5f211:	mov    QWORD PTR [rsp+0x110],rdi
   5f219:	mov    rdi,rax
   5f21c:	mov    rdx,rsi
   5f21f:	mov    rsi,rcx
   5f222:	mov    rcx,r8
   5f225:	call   5f22a <sqlite3VdbeExec+0xfd8a>
   5f22a:	mov    QWORD PTR [rbx+0x30],0x0
   5f232:	mov    rdi,QWORD PTR [rsp+0x110]
   5f23a:	mov    r13d,DWORD PTR [rsp+0x3a4]
   5f242:	test   r13d,r13d
   5f245:	jne    5f34b <sqlite3VdbeExec+0xfeab>
   5f24b:	cmp    BYTE PTR [r15+0x21],0x0
   5f250:	je     5f2f6 <sqlite3VdbeExec+0xfe56>
   5f256:	xor    eax,eax
   5f258:	xor    ecx,ecx
   5f25a:	mov    r11,rax
   5f25d:	mov    rax,rcx
   5f260:	mov    rcx,r11
   5f263:	jmp    5f27a <sqlite3VdbeExec+0xfdda>
   5f265:	mov    rdx,rax
   5f268:	cmp    ecx,DWORD PTR [r12+rdx*4+0x4]
   5f26d:	jae    5f277 <sqlite3VdbeExec+0xfdd7>
   5f26f:	mov    rcx,rax
   5f272:	mov    ecx,DWORD PTR [r12+rcx*4+0x4]
   5f277:	add    eax,0x1
   5f27a:	mov    r14d,DWORD PTR [rsp+0x3a8]
   5f282:	cmp    eax,r14d
   5f285:	jl     5f265 <sqlite3VdbeExec+0xfdc5>
   5f287:	mov    rax,QWORD PTR [r15+0x18]
   5f28b:	mov    rax,QWORD PTR [rax+0x50]
   5f28f:	movzx  edx,BYTE PTR [rax+0x34]
   5f293:	shl    edx,0x18
   5f296:	movzx  esi,BYTE PTR [rax+0x35]
   5f29a:	shl    esi,0x10
   5f29d:	or     edx,esi
   5f29f:	movzx  esi,BYTE PTR [rax+0x36]
   5f2a3:	shl    esi,0x8
   5f2a6:	or     edx,esi
   5f2a8:	movzx  eax,BYTE PTR [rax+0x37]
   5f2ac:	or     edx,eax
   5f2ae:	cmp    ecx,edx
   5f2b0:	jne    5f2bf <sqlite3VdbeExec+0xfe1f>
   5f2b2:	mov    DWORD PTR [rsp+0x3a8],r14d
   5f2ba:	jmp    5f34b <sqlite3VdbeExec+0xfeab>
   5f2bf:	lea    r14,[rsp+0x2f8]
   5f2c7:	mov    rax,r14
   5f2ca:	lea    rsi,[rip+0x0]        # 5f2d1 <sqlite3VdbeExec+0xfe31>
   5f2d1:	mov    QWORD PTR [rsp+0x110],rdi
   5f2d9:	mov    rdi,rax
   5f2dc:	mov    r11,rdx
   5f2df:	mov    rdx,rcx
   5f2e2:	mov    rcx,r11
   5f2e5:	xor    eax,eax
   5f2e7:	call   5f2ec <sqlite3VdbeExec+0xfe4c>
   5f2ec:	mov    rdi,QWORD PTR [rsp+0x110]
   5f2f4:	jmp    5f34b <sqlite3VdbeExec+0xfeab>
   5f2f6:	mov    r14,rbx
   5f2f9:	mov    rax,QWORD PTR [r15+0x18]
   5f2fd:	mov    rax,QWORD PTR [rax+0x50]
   5f301:	movzx  ecx,BYTE PTR [rax+0x40]
   5f305:	shl    ecx,0x18
   5f308:	movzx  edx,BYTE PTR [rax+0x41]
   5f30c:	shl    edx,0x10
   5f30f:	or     ecx,edx
   5f311:	movzx  edx,BYTE PTR [rax+0x42]
   5f315:	shl    edx,0x8
   5f318:	or     ecx,edx
   5f31a:	movzx  eax,BYTE PTR [rax+0x43]
   5f31e:	or     ecx,eax
   5f320:	test   ecx,ecx
   5f322:	je     5f34b <sqlite3VdbeExec+0xfeab>
   5f324:	mov    rax,r14
   5f327:	lea    rcx,[rip+0x0]        # 5f32e <sqlite3VdbeExec+0xfe8e>
   5f32e:	mov    QWORD PTR [rsp+0x110],rdi
   5f336:	mov    rdi,rax
   5f339:	mov    rsi,rcx
   5f33c:	xor    eax,eax
   5f33e:	call   5f343 <sqlite3VdbeExec+0xfea3>
   5f343:	mov    rdi,QWORD PTR [rsp+0x110]
   5f34b:	mov    rax,QWORD PTR [r15+0x8]
   5f34f:	mov    rcx,QWORD PTR [rax+0x30]
   5f353:	and    rcx,0xffffffffffdfffff
   5f35a:	mov    QWORD PTR [rax+0x30],rcx
   5f35e:	xor    r14d,r14d
   5f361:	mov    QWORD PTR [rsp+0x180],r15
   5f369:	mov    r15,QWORD PTR [rsp+0x198]
   5f371:	mov    DWORD PTR [rsp+0x3a4],r13d
   5f379:	mov    rbx,r14
   5f37c:	lea    r14,[rsp+0x2f8]
   5f384:	jmp    5f4cb <sqlite3VdbeExec+0x1002b>
   5f389:	mov    rbp,QWORD PTR [rsp+0x148]
   5f391:	mov    r11,r15
   5f394:	mov    r15,r13
   5f397:	mov    r13,r11
   5f39a:	mov    DWORD PTR [rsp+0x3a4],r13d
   5f3a2:	lea    r13,[rsp+0x3cc]
   5f3aa:	cmp    BYTE PTR [r13+0x0],0x1
   5f3af:	jne    5f3ca <sqlite3VdbeExec+0xff2a>
   5f3b1:	lea    r13,[rsp+0x398]
   5f3b9:	cmp    DWORD PTR [r13+0x0],0x0
   5f3be:	jne    5f3ca <sqlite3VdbeExec+0xff2a>
   5f3c0:	mov    QWORD PTR [rsp+0x180],r15
   5f3c8:	jmp    5f42c <sqlite3VdbeExec+0xff8c>
   5f3ca:	lea    rax,[rip+0x0]        # 5f3d1 <sqlite3VdbeExec+0xff31>
   5f3d1:	mov    ecx,0x1
   5f3d6:	lea    r13,[rsp+0x3cc]
   5f3de:	movzx  edx,BYTE PTR [r13+0x0]
   5f3e3:	lea    r13,[rsp+0x398]
   5f3eb:	mov    esi,DWORD PTR [r13+0x0]
   5f3ef:	mov    QWORD PTR [rsp+0x180],r15
   5f3f7:	lea    r13,[rsp+0x2f8]
   5f3ff:	xor    r15d,r15d
   5f402:	mov    QWORD PTR [rsp],rsi
   5f406:	mov    QWORD PTR [rsp+0x110],rdi
   5f40e:	mov    rdi,r13
   5f411:	mov    rsi,rax
   5f414:	mov    r8,r15
   5f417:	mov    r9,rdx
   5f41a:	mov    rdx,r14
   5f41d:	xor    eax,eax
   5f41f:	call   5f424 <sqlite3VdbeExec+0xff84>
   5f424:	mov    rdi,QWORD PTR [rsp+0x110]
   5f42c:	mov    rax,rbx
   5f42f:	mov    ecx,DWORD PTR [r12+rax*4+0x4]
   5f434:	lea    r14,[rsp+0x2f8]
   5f43c:	mov    DWORD PTR [r14+0x38],ecx
   5f440:	mov    rcx,r14
   5f443:	mov    eax,DWORD PTR [r12+rax*4+0x4]
   5f448:	lea    r13,[rsp+0x178]
   5f450:	mov    rdx,r13
   5f453:	movabs rsi,0x7fffffffffffffff
   5f45d:	mov    QWORD PTR [rsp+0x110],rdi
   5f465:	mov    rdi,rcx
   5f468:	mov    rcx,rsi
   5f46b:	mov    rsi,rax
   5f46e:	call   5f473 <sqlite3VdbeExec+0xffd3>
   5f473:	mov    rdi,QWORD PTR [rsp+0x110]
   5f47b:	mov    rax,QWORD PTR [r14+0x78]
   5f47f:	mov    rcx,rbx
   5f482:	imul   rcx,rcx,0x38
   5f486:	mov    r15,QWORD PTR [rsp+0x198]
   5f48e:	lea    rdx,[r15+rcx*1]
   5f492:	movzx  ecx,WORD PTR [r15+rcx*1+0x14]
   5f498:	and    ecx,0x9000
   5f49e:	test   ecx,ecx
   5f4a0:	je     5f4bf <sqlite3VdbeExec+0x1001f>
   5f4a2:	mov    QWORD PTR [rsp+0x110],rdi
   5f4aa:	mov    rdi,rdx
   5f4ad:	mov    rsi,rax
   5f4b0:	call   5f4b5 <sqlite3VdbeExec+0x10015>
   5f4b5:	mov    rdi,QWORD PTR [rsp+0x110]
   5f4bd:	jmp    5f4c8 <sqlite3VdbeExec+0x10028>
   5f4bf:	mov    QWORD PTR [rdx],rax
   5f4c2:	mov    WORD PTR [rdx+0x14],0x4
   5f4c8:	add    ebx,0x1
   5f4cb:	mov    r13d,DWORD PTR [rsp+0x3a8]
   5f4d3:	cmp    ebx,r13d
   5f4d6:	jl     5f4f5 <sqlite3VdbeExec+0x10055>
   5f4d8:	mov    r13,QWORD PTR [rsp+0x180]
   5f4e0:	mov    r15d,DWORD PTR [rsp+0x3a4]
   5f4e8:	mov    QWORD PTR [rsp+0x148],rbp
   5f4f0:	jmp    5f684 <sqlite3VdbeExec+0x101e4>
   5f4f5:	cmp    DWORD PTR [r14+0x1c],0x0
   5f4fa:	jne    5f519 <sqlite3VdbeExec+0x10079>
   5f4fc:	mov    r13,QWORD PTR [rsp+0x180]
   5f504:	mov    r15d,DWORD PTR [rsp+0x3a4]
   5f50c:	mov    QWORD PTR [rsp+0x148],rbp
   5f514:	jmp    5f684 <sqlite3VdbeExec+0x101e4>
   5f519:	mov    QWORD PTR [r14+0x78],0x0
   5f521:	mov    rax,rbx
   5f524:	cmp    DWORD PTR [r12+rax*4+0x4],0x0
   5f52a:	jne    5f549 <sqlite3VdbeExec+0x100a9>
   5f52c:	mov    DWORD PTR [rsp+0x3a8],r13d
   5f534:	mov    QWORD PTR [rsp+0x198],r15
   5f53c:	lea    r13,[rsp+0x178]
   5f544:	jmp    5f47b <sqlite3VdbeExec+0xffdb>
   5f549:	mov    r13,QWORD PTR [rsp+0x180]
   5f551:	cmp    BYTE PTR [r13+0x21],0x0
   5f556:	jne    5f565 <sqlite3VdbeExec+0x100c5>
   5f558:	mov    QWORD PTR [rsp+0x198],r15
   5f560:	jmp    5f42c <sqlite3VdbeExec+0xff8c>
   5f565:	mov    rax,rbx
   5f568:	cmp    DWORD PTR [r12+rax*4+0x4],0x1
   5f56e:	ja     5f585 <sqlite3VdbeExec+0x100e5>
   5f570:	mov    QWORD PTR [rsp+0x198],r15
   5f578:	mov    QWORD PTR [rsp+0x180],r13
   5f580:	jmp    5f42c <sqlite3VdbeExec+0xff8c>
   5f585:	mov    QWORD PTR [rsp+0x198],r15
   5f58d:	mov    r15d,DWORD PTR [rsp+0x3a4]
   5f595:	test   r15d,r15d
   5f598:	je     5f5a7 <sqlite3VdbeExec+0x10107>
   5f59a:	mov    QWORD PTR [rsp+0x180],r13
   5f5a2:	jmp    5f42c <sqlite3VdbeExec+0xff8c>
   5f5a7:	mov    rax,rbx
   5f5aa:	mov    r14d,DWORD PTR [r12+rax*4+0x4]
   5f5af:	mov    QWORD PTR [rsp+0x148],rbp
   5f5b7:	lea    rbp,[rsp+0x2f8]
   5f5bf:	mov    rax,QWORD PTR [rbp+0x0]
   5f5c3:	lea    rbp,[rsp+0x3cc]
   5f5cb:	mov    rcx,rbp
   5f5ce:	lea    rbp,[rsp+0x398]
   5f5d6:	mov    rdx,rbp
   5f5d9:	mov    QWORD PTR [rsp+0x110],rdi
   5f5e1:	mov    rdi,rax
   5f5e4:	mov    rsi,r14
   5f5e7:	mov    r11,rdx
   5f5ea:	mov    rdx,rcx
   5f5ed:	mov    rcx,r11
   5f5f0:	call   5f5f5 <sqlite3VdbeExec+0x10155>
   5f5f5:	mov    rdi,QWORD PTR [rsp+0x110]
   5f5fd:	test   eax,eax
   5f5ff:	je     5f389 <sqlite3VdbeExec+0xfee9>
   5f605:	cmp    eax,0x7
   5f608:	je     5f61b <sqlite3VdbeExec+0x1017b>
   5f60a:	cmp    eax,0xc0a
   5f60f:	je     5f61b <sqlite3VdbeExec+0x1017b>
   5f611:	lea    rbp,[rsp+0x2f8]
   5f619:	jmp    5f640 <sqlite3VdbeExec+0x101a0>
   5f61b:	lea    rbp,[rsp+0x2f8]
   5f623:	mov    DWORD PTR [rbp+0x24],0x7
   5f62a:	mov    DWORD PTR [rbp+0x1c],0x0
   5f631:	cmp    DWORD PTR [rbp+0x20],0x0
   5f635:	jne    5f640 <sqlite3VdbeExec+0x101a0>
   5f637:	mov    eax,DWORD PTR [rbp+0x20]
   5f63a:	add    eax,0x1
   5f63d:	mov    DWORD PTR [rbp+0x20],eax
   5f640:	lea    rax,[rip+0x0]        # 5f647 <sqlite3VdbeExec+0x101a7>
   5f647:	mov    QWORD PTR [rsp+0x110],rdi
   5f64f:	mov    rdi,rbp
   5f652:	mov    rsi,rax
   5f655:	mov    rdx,r14
   5f658:	xor    eax,eax
   5f65a:	call   5f65f <sqlite3VdbeExec+0x101bf>
   5f65f:	mov    rdi,QWORD PTR [rsp+0x110]
   5f667:	mov    QWORD PTR [rsp+0x180],r13
   5f66f:	mov    DWORD PTR [rsp+0x3a4],r15d
   5f677:	mov    rbp,QWORD PTR [rsp+0x148]
   5f67f:	jmp    5f42c <sqlite3VdbeExec+0xff8c>
   5f684:	mov    rax,QWORD PTR [r13+0x8]
   5f688:	mov    rbx,QWORD PTR [rsp+0x1a0]
   5f690:	mov    QWORD PTR [rax+0x30],rbx
   5f694:	test   r15d,r15d
   5f697:	je     5f6ae <sqlite3VdbeExec+0x1020e>
   5f699:	mov    rbp,QWORD PTR [rsp+0x148]
   5f6a1:	lea    rbx,[rsp+0x2f8]
   5f6a9:	jmp    5f082 <sqlite3VdbeExec+0xfbe2>
   5f6ae:	mov    ebx,0x1
   5f6b3:	mov    r14,QWORD PTR [rsp+0x128]
   5f6bb:	mov    rbp,QWORD PTR [rsp+0x148]
   5f6c3:	mov    r12,rbx
   5f6c6:	mov    rbx,QWORD PTR [rsp+0x160]
   5f6ce:	jmp    5f7ec <sqlite3VdbeExec+0x1034c>
   5f6d3:	mov    QWORD PTR [rsp+0x128],r14
   5f6db:	mov    r14,r12
   5f6de:	mov    QWORD PTR [rsp+0x148],rbp
   5f6e6:	mov    rbp,r15
   5f6e9:	mov    QWORD PTR [rsp+0x160],rbx
   5f6f1:	mov    eax,DWORD PTR [r13+0x38]
   5f6f5:	mov    edx,0xcccccccd
   5f6fa:	mul    edx
   5f6fc:	shr    edx,0x2
   5f6ff:	mov    eax,edx
   5f701:	lea    ecx,[rax+0x1]
   5f704:	mov    eax,r14d
   5f707:	sub    eax,0x2
   5f70a:	xor    edx,edx
   5f70c:	div    ecx
   5f70e:	imul   eax,ecx
   5f711:	lea    ecx,[rax+0x2]
   5f714:	mov    eax,DWORD PTR [rip+0x0]        # 5f71a <sqlite3VdbeExec+0x1027a>
   5f71a:	mov    esi,DWORD PTR [r13+0x34]
   5f71e:	xor    edx,edx
   5f720:	div    esi
   5f722:	add    eax,0x1
   5f725:	xor    edx,edx
   5f727:	mov    esi,0x1
   5f72c:	cmp    ecx,eax
   5f72e:	cmove  edx,esi
   5f731:	lea    eax,[rcx+rdx*1]
   5f734:	cmp    eax,r14d
   5f737:	jne    5f740 <sqlite3VdbeExec+0x102a0>
   5f739:	cmp    BYTE PTR [r13+0x21],0x0
   5f73e:	jne    5f76a <sqlite3VdbeExec+0x102ca>
   5f740:	mov    rax,rbp
   5f743:	lea    rcx,[rip+0x0]        # 5f74a <sqlite3VdbeExec+0x102aa>
   5f74a:	mov    QWORD PTR [rsp+0x110],rdi
   5f752:	mov    rdi,rax
   5f755:	mov    rsi,rcx
   5f758:	mov    rdx,r14
   5f75b:	xor    eax,eax
   5f75d:	call   5f762 <sqlite3VdbeExec+0x102c2>
   5f762:	mov    rdi,QWORD PTR [rsp+0x110]
   5f76a:	mov    rax,QWORD PTR [rbp+0x10]
   5f76e:	mov    ecx,r14d
   5f771:	shr    ecx,0x3
   5f774:	movzx  eax,BYTE PTR [rax+rcx*1]
   5f778:	mov    edx,0x1
   5f77d:	mov    ecx,r14d
   5f780:	and    ecx,0x7
   5f783:	shl    edx,cl
   5f785:	and    eax,edx
   5f787:	test   eax,eax
   5f789:	je     5f7cd <sqlite3VdbeExec+0x1032d>
   5f78b:	cmp    r14d,0x2
   5f78f:	jae    5f8cc <sqlite3VdbeExec+0x1042c>
   5f795:	xor    eax,eax
   5f797:	cmp    eax,r14d
   5f79a:	jne    5f7cd <sqlite3VdbeExec+0x1032d>
   5f79c:	cmp    BYTE PTR [r13+0x21],0x0
   5f7a1:	je     5f7cd <sqlite3VdbeExec+0x1032d>
   5f7a3:	mov    rax,rbp
   5f7a6:	lea    rcx,[rip+0x0]        # 5f7ad <sqlite3VdbeExec+0x1030d>
   5f7ad:	mov    QWORD PTR [rsp+0x110],rdi
   5f7b5:	mov    rdi,rax
   5f7b8:	mov    rsi,rcx
   5f7bb:	mov    rdx,r14
   5f7be:	xor    eax,eax
   5f7c0:	call   5f7c5 <sqlite3VdbeExec+0x10325>
   5f7c5:	mov    rdi,QWORD PTR [rsp+0x110]
   5f7cd:	add    r14d,0x1
   5f7d1:	mov    rbp,QWORD PTR [rsp+0x148]
   5f7d9:	mov    rbx,QWORD PTR [rsp+0x160]
   5f7e1:	mov    r12,r14
   5f7e4:	mov    r14,QWORD PTR [rsp+0x128]
   5f7ec:	lea    r15,[rsp+0x2f8]
   5f7f4:	cmp    r12d,DWORD PTR [r15+0x18]
   5f7f8:	jbe    5f812 <sqlite3VdbeExec+0x10372>
   5f7fa:	mov    QWORD PTR [rsp+0x128],r14
   5f802:	mov    QWORD PTR [rsp+0x160],rbx
   5f80a:	mov    rbx,r15
   5f80d:	jmp    5f082 <sqlite3VdbeExec+0xfbe2>
   5f812:	cmp    DWORD PTR [r15+0x1c],0x0
   5f817:	jne    5f831 <sqlite3VdbeExec+0x10391>
   5f819:	mov    QWORD PTR [rsp+0x128],r14
   5f821:	mov    QWORD PTR [rsp+0x160],rbx
   5f829:	mov    rbx,r15
   5f82c:	jmp    5f082 <sqlite3VdbeExec+0xfbe2>
   5f831:	mov    rax,QWORD PTR [r15+0x10]
   5f835:	mov    ecx,r12d
   5f838:	shr    ecx,0x3
   5f83b:	movzx  eax,BYTE PTR [rax+rcx*1]
   5f83f:	mov    edx,0x1
   5f844:	mov    ecx,r12d
   5f847:	and    ecx,0x7
   5f84a:	shl    edx,cl
   5f84c:	and    eax,edx
   5f84e:	test   eax,eax
   5f850:	je     5f875 <sqlite3VdbeExec+0x103d5>
   5f852:	mov    QWORD PTR [rsp+0x128],r14
   5f85a:	mov    r14,r12
   5f85d:	mov    QWORD PTR [rsp+0x148],rbp
   5f865:	mov    rbp,r15
   5f868:	mov    QWORD PTR [rsp+0x160],rbx
   5f870:	jmp    5f76a <sqlite3VdbeExec+0x102ca>
   5f875:	cmp    r12d,0x2
   5f879:	jae    5f6d3 <sqlite3VdbeExec+0x10233>
   5f87f:	xor    eax,eax
   5f881:	cmp    eax,r12d
   5f884:	jne    5f8a9 <sqlite3VdbeExec+0x10409>
   5f886:	mov    QWORD PTR [rsp+0x128],r14
   5f88e:	mov    r14,r12
   5f891:	mov    QWORD PTR [rsp+0x148],rbp
   5f899:	mov    rbp,r15
   5f89c:	mov    QWORD PTR [rsp+0x160],rbx
   5f8a4:	jmp    5f739 <sqlite3VdbeExec+0x10299>
   5f8a9:	mov    QWORD PTR [rsp+0x128],r14
   5f8b1:	mov    r14,r12
   5f8b4:	mov    QWORD PTR [rsp+0x148],rbp
   5f8bc:	mov    rbp,r15
   5f8bf:	mov    QWORD PTR [rsp+0x160],rbx
   5f8c7:	jmp    5f740 <sqlite3VdbeExec+0x102a0>
   5f8cc:	mov    r15,rbp
   5f8cf:	mov    r12,r14
   5f8d2:	mov    r14,QWORD PTR [rsp+0x128]
   5f8da:	mov    rbp,QWORD PTR [rsp+0x148]
   5f8e2:	mov    rbx,QWORD PTR [rsp+0x160]
   5f8ea:	mov    eax,DWORD PTR [r13+0x38]
   5f8ee:	mov    edx,0xcccccccd
   5f8f3:	mul    edx
   5f8f5:	shr    edx,0x2
   5f8f8:	mov    eax,edx
   5f8fa:	lea    ecx,[rax+0x1]
   5f8fd:	mov    eax,r12d
   5f900:	sub    eax,0x2
   5f903:	xor    edx,edx
   5f905:	div    ecx
   5f907:	imul   eax,ecx
   5f90a:	lea    ecx,[rax+0x2]
   5f90d:	mov    eax,DWORD PTR [rip+0x0]        # 5f913 <sqlite3VdbeExec+0x10473>
   5f913:	mov    esi,DWORD PTR [r13+0x34]
   5f917:	xor    edx,edx
   5f919:	div    esi
   5f91b:	add    eax,0x1
   5f91e:	xor    edx,edx
   5f920:	mov    esi,0x1
   5f925:	cmp    ecx,eax
   5f927:	cmove  edx,esi
   5f92a:	lea    eax,[rcx+rdx*1]
   5f92d:	cmp    eax,r12d
   5f930:	je     5f955 <sqlite3VdbeExec+0x104b5>
   5f932:	mov    QWORD PTR [rsp+0x128],r14
   5f93a:	mov    r14,r12
   5f93d:	mov    QWORD PTR [rsp+0x148],rbp
   5f945:	mov    rbp,r15
   5f948:	mov    QWORD PTR [rsp+0x160],rbx
   5f950:	jmp    5f7cd <sqlite3VdbeExec+0x1032d>
   5f955:	mov    QWORD PTR [rsp+0x128],r14
   5f95d:	mov    r14,r12
   5f960:	mov    QWORD PTR [rsp+0x148],rbp
   5f968:	mov    rbp,r15
   5f96b:	mov    QWORD PTR [rsp+0x160],rbx
   5f973:	jmp    5f79c <sqlite3VdbeExec+0x102fc>
   5f978:	mov    rax,QWORD PTR [rip+0x0]        # 5f97f <sqlite3VdbeExec+0x104df>
   5f97f:	mov    rdi,r12
   5f982:	mov    r10,rax
   5f985:	call   r10
   5f988:	mov    rdi,QWORD PTR [rsp+0x110]
   5f990:	mov    eax,DWORD PTR [rbx+0x20]
   5f993:	mov    DWORD PTR [rsp+0x39c],eax
   5f99a:	cmp    DWORD PTR [rbx+0x20],0x0
   5f99e:	jne    5fa09 <sqlite3VdbeExec+0x10569>
   5f9a0:	movzx  eax,BYTE PTR [rbx+0x65]
   5f9a4:	and    eax,0x4
   5f9a7:	test   eax,eax
   5f9a9:	je     5f9dd <sqlite3VdbeExec+0x1053d>
   5f9ab:	mov    rax,QWORD PTR [rbx+0x48]
   5f9af:	mov    rcx,QWORD PTR [rbx+0x50]
   5f9b3:	test   rcx,rcx
   5f9b6:	je     5f9d3 <sqlite3VdbeExec+0x10533>
   5f9b8:	mov    QWORD PTR [rsp+0x110],rdi
   5f9c0:	mov    rdi,rax
   5f9c3:	mov    rsi,rcx
   5f9c6:	call   5f9cb <sqlite3VdbeExec+0x1052b>
   5f9cb:	mov    rdi,QWORD PTR [rsp+0x110]
   5f9d3:	movzx  eax,BYTE PTR [rbx+0x65]
   5f9d7:	and    eax,0xfffffffb
   5f9da:	mov    BYTE PTR [rbx+0x65],al
   5f9dd:	mov    DWORD PTR [rbx+0x58],0x0
   5f9e4:	mov    DWORD PTR [rbx+0x60],0x0
   5f9eb:	mov    QWORD PTR [rbx+0x50],0x0
   5f9f3:	mov    QWORD PTR [rsp+0x190],0x0
   5f9ff:	mov    r15,QWORD PTR [rsp+0x168]
   5fa07:	jmp    5fa66 <sqlite3VdbeExec+0x105c6>
   5fa09:	lea    rax,[rbx+0x48]
   5fa0d:	cmp    QWORD PTR [rbx+0x50],0x0
   5fa12:	je     5fa52 <sqlite3VdbeExec+0x105b2>
   5fa14:	mov    rcx,QWORD PTR [rax+0x8]
   5fa18:	mov    edx,DWORD PTR [rax+0x18]
   5fa1b:	mov    BYTE PTR [rcx+rdx*1],0x0
   5fa1f:	cmp    DWORD PTR [rax+0x14],0x0
   5fa23:	jbe    5fa52 <sqlite3VdbeExec+0x105b2>
   5fa25:	movzx  ecx,BYTE PTR [rax+0x1d]
   5fa29:	and    ecx,0x4
   5fa2c:	test   ecx,ecx
   5fa2e:	jne    5fa52 <sqlite3VdbeExec+0x105b2>
   5fa30:	mov    QWORD PTR [rsp+0x110],rdi
   5fa38:	mov    rdi,rax
   5fa3b:	call   5fa40 <sqlite3VdbeExec+0x105a0>
   5fa40:	mov    rdi,QWORD PTR [rsp+0x110]
   5fa48:	mov    r15,QWORD PTR [rsp+0x168]
   5fa50:	jmp    5fa5e <sqlite3VdbeExec+0x105be>
   5fa52:	mov    rax,QWORD PTR [rax+0x8]
   5fa56:	mov    r15,QWORD PTR [rsp+0x168]
   5fa5e:	mov    QWORD PTR [rsp+0x190],rax
   5fa66:	mov    eax,DWORD PTR [rbx+0x24]
   5fa69:	mov    ebx,eax
   5fa6b:	movzx  eax,WORD PTR [r15+0x14]
   5fa70:	and    eax,0x9000
   5fa75:	test   eax,eax
   5fa77:	je     5fa93 <sqlite3VdbeExec+0x105f3>
   5fa79:	mov    QWORD PTR [rsp+0x110],rdi
   5fa81:	mov    rdi,r15
   5fa84:	call   5fa89 <sqlite3VdbeExec+0x105e9>
   5fa89:	mov    rdi,QWORD PTR [rsp+0x110]
   5fa91:	jmp    5fa9a <sqlite3VdbeExec+0x105fa>
   5fa93:	mov    WORD PTR [r15+0x14],0x1
   5fa9a:	cmp    DWORD PTR [rsp+0x39c],0x0
   5faa2:	jne    5fab1 <sqlite3VdbeExec+0x10611>
   5faa4:	mov    r12,QWORD PTR [rsp+0x160]
   5faac:	jmp    5fbda <sqlite3VdbeExec+0x1073a>
   5fab1:	test   ebx,ebx
   5fab3:	je     5fb73 <sqlite3VdbeExec+0x106d3>
   5fab9:	mov    r12,QWORD PTR [rsp+0x190]
   5fac1:	test   r12,r12
   5fac4:	je     5fb4b <sqlite3VdbeExec+0x106ab>
   5faca:	cmp    DWORD PTR [rip+0x0],0x0        # 5fad1 <sqlite3VdbeExec+0x10631>
   5fad1:	je     5fb2b <sqlite3VdbeExec+0x1068b>
   5fad3:	mov    rax,QWORD PTR [rip+0x0]        # 5fada <sqlite3VdbeExec+0x1063a>
   5fada:	mov    QWORD PTR [rsp+0x110],rdi
   5fae2:	mov    rdi,r12
   5fae5:	mov    r10,rax
   5fae8:	call   r10
   5faeb:	mov    rcx,QWORD PTR [rip+0x0]        # 5faf2 <sqlite3VdbeExec+0x10652>
   5faf2:	movsxd rax,eax
   5faf5:	sub    rcx,rax
   5faf8:	mov    QWORD PTR [rip+0x0],rcx        # 5faff <sqlite3VdbeExec+0x1065f>
   5faff:	mov    rax,QWORD PTR [rip+0x0]        # 5fb06 <sqlite3VdbeExec+0x10666>
   5fb06:	sub    rax,0x1
   5fb0a:	mov    QWORD PTR [rip+0x0],rax        # 5fb11 <sqlite3VdbeExec+0x10671>
   5fb11:	mov    rax,QWORD PTR [rip+0x0]        # 5fb18 <sqlite3VdbeExec+0x10678>
   5fb18:	mov    rdi,r12
   5fb1b:	mov    r10,rax
   5fb1e:	call   r10
   5fb21:	mov    rdi,QWORD PTR [rsp+0x110]
   5fb29:	jmp    5fb4b <sqlite3VdbeExec+0x106ab>
   5fb2b:	mov    rax,QWORD PTR [rip+0x0]        # 5fb32 <sqlite3VdbeExec+0x10692>
   5fb32:	mov    QWORD PTR [rsp+0x110],rdi
   5fb3a:	mov    rdi,r12
   5fb3d:	mov    r10,rax
   5fb40:	call   r10
   5fb43:	mov    rdi,QWORD PTR [rsp+0x110]
   5fb4b:	mov    r14,QWORD PTR [rsp+0x128]
   5fb53:	mov    QWORD PTR [rsp+0x148],rbp
   5fb5b:	mov    rbp,rbx
   5fb5e:	mov    r13,QWORD PTR [rsp+0x130]
   5fb66:	mov    rbx,QWORD PTR [rsp+0x158]
   5fb6e:	jmp    4f712 <sqlite3VdbeExec+0x272>
   5fb73:	mov    r13,QWORD PTR [rsp+0x188]
   5fb7b:	mov    r12,QWORD PTR [rsp+0x160]
   5fb83:	mov    rax,QWORD PTR [r12+r13*1]
   5fb87:	mov    ecx,DWORD PTR [rsp+0x39c]
   5fb8e:	sub    ecx,0x1
   5fb91:	movsxd rcx,ecx
   5fb94:	sub    rax,rcx
   5fb97:	mov    QWORD PTR [r12+r13*1],rax
   5fb9b:	mov    rax,QWORD PTR [rsp+0x190]
   5fba3:	mov    rcx,0xffffffffffffffff
   5fbaa:	lea    rdx,[rip+0x0]        # 5fbb1 <sqlite3VdbeExec+0x10711>
   5fbb1:	mov    esi,0x1
   5fbb6:	mov    QWORD PTR [rsp+0x110],rdi
   5fbbe:	mov    rdi,r15
   5fbc1:	mov    r8,rdx
   5fbc4:	mov    rdx,rcx
   5fbc7:	mov    rcx,rsi
   5fbca:	mov    rsi,rax
   5fbcd:	call   5fbd2 <sqlite3VdbeExec+0x10732>
   5fbd2:	mov    rdi,QWORD PTR [rsp+0x110]
   5fbda:	mov    r13d,DWORD PTR [rsp+0x37c]
   5fbe2:	mov    eax,r13d
   5fbe5:	movzx  ecx,WORD PTR [r15+0x14]
   5fbea:	and    ecx,0x2
   5fbed:	test   ecx,ecx
   5fbef:	jne    5fbf7 <sqlite3VdbeExec+0x10757>
   5fbf1:	mov    BYTE PTR [r15+0x16],al
   5fbf5:	jmp    5fc1d <sqlite3VdbeExec+0x1077d>
   5fbf7:	movzx  ecx,BYTE PTR [r15+0x16]
   5fbfc:	cmp    ecx,eax
   5fbfe:	jne    5fc02 <sqlite3VdbeExec+0x10762>
   5fc00:	jmp    5fc1d <sqlite3VdbeExec+0x1077d>
   5fc02:	mov    QWORD PTR [rsp+0x110],rdi
   5fc0a:	mov    rdi,r15
   5fc0d:	mov    rsi,rax
   5fc10:	call   5fc15 <sqlite3VdbeExec+0x10775>
   5fc15:	mov    rdi,QWORD PTR [rsp+0x110]
   5fc1d:	mov    r14,QWORD PTR [rsp+0x128]
   5fc25:	mov    r15,r13
   5fc28:	mov    r13,QWORD PTR [rsp+0x150]
   5fc30:	mov    QWORD PTR [rsp+0x148],rbp
   5fc38:	mov    DWORD PTR [rsp+0x38c],ebx
   5fc3f:	mov    ebx,DWORD PTR [rsp+0x390]
   5fc46:	mov    QWORD PTR [rsp+0x160],r12
   5fc4e:	mov    r12d,DWORD PTR [rsp+0x394]
   5fc56:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   5fc5b:	mov    QWORD PTR [rsp+0x128],r14
   5fc63:	mov    r13d,DWORD PTR [rsp+0x37c]
   5fc6b:	mov    QWORD PTR [rsp+0x130],r12
   5fc73:	mov    r12,rbx
   5fc76:	mov    rax,QWORD PTR [rdi+0x78]
   5fc7a:	movsxd rcx,DWORD PTR [rbp+0x4]
   5fc7e:	mov    rbx,QWORD PTR [rax+rcx*8]
   5fc82:	lea    r14,[rsp+0x1e8]
   5fc8a:	mov    rax,r14
   5fc8d:	xor    ecx,ecx
   5fc8f:	mov    edx,0x28
   5fc94:	mov    QWORD PTR [rsp+0x110],rdi
   5fc9c:	mov    rdi,rax
   5fc9f:	mov    rsi,rcx
   5fca2:	call   5fca7 <sqlite3VdbeExec+0x10807>
   5fca7:	movsxd rax,DWORD PTR [rbp+0xc]
   5fcab:	imul   rax,rax,0x38
   5fcaf:	add    rax,r12
   5fcb2:	mov    QWORD PTR [rsp+0x1f0],rax
   5fcba:	mov    rax,QWORD PTR [rbp+0x10]
   5fcbe:	movzx  eax,WORD PTR [rax+0x60]
   5fcc2:	mov    WORD PTR [rsp+0x204],ax
   5fcca:	mov    rax,QWORD PTR [rbx+0x30]
   5fcce:	mov    QWORD PTR [rsp+0x1e8],rax
   5fcd6:	mov    rax,QWORD PTR [rbx+0x28]
   5fcda:	mov    rcx,QWORD PTR [rbp+0x10]
   5fcde:	mov    rdx,r14
   5fce1:	lea    r15,[rsp+0x39c]
   5fce9:	mov    rsi,r15
   5fcec:	mov    r8d,0x1
   5fcf2:	mov    rdi,rax
   5fcf5:	mov    r11,rsi
   5fcf8:	mov    rsi,rcx
   5fcfb:	mov    rcx,r11
   5fcfe:	call   5fd03 <sqlite3VdbeExec+0x10863>
   5fd03:	mov    r15d,eax
   5fd06:	mov    rdi,QWORD PTR [rsp+0x110]
   5fd0e:	test   r15d,r15d
   5fd11:	jne    5fd1d <sqlite3VdbeExec+0x1087d>
   5fd13:	cmp    DWORD PTR [rsp+0x39c],0x0
   5fd1b:	je     5fd3b <sqlite3VdbeExec+0x1089b>
   5fd1d:	mov    r15,r13
   5fd20:	mov    rbx,r12
   5fd23:	mov    r12,QWORD PTR [rsp+0x128]
   5fd2b:	xor    r11d,r11d
   5fd2e:	mov    DWORD PTR [rsp+0x38c],r11d
   5fd36:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   5fd3b:	mov    BYTE PTR [rbx+0x2],0x0
   5fd3f:	mov    r14,QWORD PTR [rsp+0x128]
   5fd47:	mov    DWORD PTR [rsp+0x37c],r13d
   5fd4f:	mov    DWORD PTR [rsp+0x38c],r15d
   5fd57:	mov    rbx,r12
   5fd5a:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5fd5f:	mov    r15d,DWORD PTR [rsp+0x37c]
   5fd67:	mov    r13,QWORD PTR [rsp+0x150]
   5fd6f:	mov    QWORD PTR [rsp+0x130],r12
   5fd77:	mov    r12d,DWORD PTR [rsp+0x394]
   5fd7f:	movsxd rax,DWORD PTR [rbp+0x4]
   5fd83:	imul   rax,rax,0x38
   5fd87:	mov    QWORD PTR [rsp+0x150],r13
   5fd8f:	lea    r13,[rbx+rax*1]
   5fd93:	movsxd rcx,DWORD PTR [rbp+0x8]
   5fd97:	mov    QWORD PTR [rsp+0x128],r14
   5fd9f:	imul   r14,rcx,0x38
   5fda3:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5fda8:	and    eax,0x10
   5fdab:	test   eax,eax
   5fdad:	jne    5fdeb <sqlite3VdbeExec+0x1094b>
   5fdaf:	mov    QWORD PTR [rsp+0x110],rdi
   5fdb7:	mov    rdi,r13
   5fdba:	call   5fdbf <sqlite3VdbeExec+0x1091f>
   5fdbf:	mov    rdi,QWORD PTR [rsp+0x110]
   5fdc7:	test   eax,eax
   5fdc9:	je     5fdeb <sqlite3VdbeExec+0x1094b>
   5fdcb:	mov    r14,QWORD PTR [rsp+0x128]
   5fdd3:	mov    r13,QWORD PTR [rsp+0x150]
   5fddb:	mov    rbx,rbp
   5fdde:	mov    rbp,QWORD PTR [rsp+0x158]
   5fde6:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5fdeb:	mov    r13,QWORD PTR [r13+0x8]
   5fdef:	mov    r14,QWORD PTR [rbx+r14*1]
   5fdf3:	cmp    WORD PTR [r13+0x30],0x0
   5fdf9:	jne    5fe42 <sqlite3VdbeExec+0x109a2>
   5fdfb:	mov    rax,QWORD PTR [r13+0x8]
   5fdff:	mov    ecx,0x3f8
   5fe04:	mov    QWORD PTR [rsp+0x110],rdi
   5fe0c:	mov    rdi,rax
   5fe0f:	mov    rsi,rcx
   5fe12:	call   5fe17 <sqlite3VdbeExec+0x10977>
   5fe17:	mov    rdi,QWORD PTR [rsp+0x110]
   5fe1f:	test   rax,rax
   5fe22:	jne    5fe28 <sqlite3VdbeExec+0x10988>
   5fe24:	xor    eax,eax
   5fe26:	jmp    5fe5b <sqlite3VdbeExec+0x109bb>
   5fe28:	mov    rcx,QWORD PTR [r13+0x0]
   5fe2c:	mov    QWORD PTR [rax],rcx
   5fe2f:	mov    QWORD PTR [r13+0x0],rax
   5fe33:	add    rax,0x8
   5fe37:	mov    QWORD PTR [r13+0x20],rax
   5fe3b:	mov    WORD PTR [r13+0x30],0x2a
   5fe42:	movzx  eax,WORD PTR [r13+0x30]
   5fe47:	sub    eax,0x1
   5fe4a:	mov    WORD PTR [r13+0x30],ax
   5fe4f:	mov    rax,QWORD PTR [r13+0x20]
   5fe53:	lea    rcx,[rax+0x18]
   5fe57:	mov    QWORD PTR [r13+0x20],rcx
   5fe5b:	test   rax,rax
   5fe5e:	je     5fe94 <sqlite3VdbeExec+0x109f4>
   5fe60:	mov    QWORD PTR [rax],r14
   5fe63:	mov    QWORD PTR [rax+0x8],0x0
   5fe6b:	mov    rcx,QWORD PTR [r13+0x18]
   5fe6f:	test   rcx,rcx
   5fe72:	je     5fe8c <sqlite3VdbeExec+0x109ec>
   5fe74:	cmp    r14,QWORD PTR [rcx]
   5fe77:	jg     5fe86 <sqlite3VdbeExec+0x109e6>
   5fe79:	movzx  edx,WORD PTR [r13+0x32]
   5fe7e:	and    edx,0xfffffffe
   5fe81:	mov    WORD PTR [r13+0x32],dx
   5fe86:	mov    QWORD PTR [rcx+0x8],rax
   5fe8a:	jmp    5fe90 <sqlite3VdbeExec+0x109f0>
   5fe8c:	mov    QWORD PTR [r13+0x10],rax
   5fe90:	mov    QWORD PTR [r13+0x18],rax
   5fe94:	mov    r14,QWORD PTR [rsp+0x128]
   5fe9c:	mov    DWORD PTR [rsp+0x37c],r15d
   5fea4:	mov    DWORD PTR [rsp+0x394],r12d
   5feac:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   5feb1:	mov    QWORD PTR [rsp+0x128],r14
   5feb9:	mov    r15d,DWORD PTR [rsp+0x37c]
   5fec1:	mov    QWORD PTR [rsp+0x130],r12
   5fec9:	mov    r12d,DWORD PTR [rsp+0x394]
   5fed1:	movsxd rax,DWORD PTR [rbp+0x4]
   5fed5:	imul   rax,rax,0x38
   5fed9:	lea    r13,[rbx+rax*1]
   5fedd:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5fee2:	and    eax,0x10
   5fee5:	test   eax,eax
   5fee7:	je     60014 <sqlite3VdbeExec+0x10b74>
   5feed:	mov    r14,QWORD PTR [r13+0x8]
   5fef1:	movzx  eax,WORD PTR [r14+0x32]
   5fef6:	and    eax,0x2
   5fef9:	test   eax,eax
   5fefb:	jne    5ff36 <sqlite3VdbeExec+0x10a96>
   5fefd:	movzx  eax,WORD PTR [r14+0x32]
   5ff02:	and    eax,0x1
   5ff05:	test   eax,eax
   5ff07:	jne    5ff29 <sqlite3VdbeExec+0x10a89>
   5ff09:	mov    rax,QWORD PTR [r14+0x10]
   5ff0d:	mov    QWORD PTR [rsp+0x110],rdi
   5ff15:	mov    rdi,rax
   5ff18:	call   5ff1d <sqlite3VdbeExec+0x10a7d>
   5ff1d:	mov    QWORD PTR [r14+0x10],rax
   5ff21:	mov    rdi,QWORD PTR [rsp+0x110]
   5ff29:	movzx  eax,WORD PTR [r14+0x32]
   5ff2e:	or     eax,0x3
   5ff31:	mov    WORD PTR [r14+0x32],ax
   5ff36:	cmp    QWORD PTR [r14+0x10],0x0
   5ff3b:	je     60014 <sqlite3VdbeExec+0x10b74>
   5ff41:	mov    rax,QWORD PTR [r14+0x10]
   5ff45:	mov    rax,QWORD PTR [rax]
   5ff48:	mov    QWORD PTR [rsp+0x190],rax
   5ff50:	mov    rax,QWORD PTR [r14+0x10]
   5ff54:	mov    rax,QWORD PTR [rax+0x8]
   5ff58:	mov    QWORD PTR [r14+0x10],rax
   5ff5c:	cmp    QWORD PTR [r14+0x10],0x0
   5ff61:	jne    5ffd5 <sqlite3VdbeExec+0x10b35>
   5ff63:	mov    r13,QWORD PTR [r14]
   5ff66:	jmp    5ffa3 <sqlite3VdbeExec+0x10b03>
   5ff68:	mov    DWORD PTR [rsp+0x394],r12d
   5ff70:	mov    r12,QWORD PTR [r13+0x0]
   5ff74:	mov    rax,QWORD PTR [r14+0x8]
   5ff78:	test   r13,r13
   5ff7b:	je     5ff98 <sqlite3VdbeExec+0x10af8>
   5ff7d:	mov    QWORD PTR [rsp+0x110],rdi
   5ff85:	mov    rdi,rax
   5ff88:	mov    rsi,r13
   5ff8b:	call   5ff90 <sqlite3VdbeExec+0x10af0>
   5ff90:	mov    rdi,QWORD PTR [rsp+0x110]
   5ff98:	mov    r13,r12
   5ff9b:	mov    r12d,DWORD PTR [rsp+0x394]
   5ffa3:	test   r13,r13
   5ffa6:	jne    5ff68 <sqlite3VdbeExec+0x10ac8>
   5ffa8:	mov    QWORD PTR [r14],0x0
   5ffaf:	mov    WORD PTR [r14+0x30],0x0
   5ffb6:	mov    QWORD PTR [r14+0x10],0x0
   5ffbe:	mov    QWORD PTR [r14+0x18],0x0
   5ffc6:	mov    QWORD PTR [r14+0x28],0x0
   5ffce:	mov    WORD PTR [r14+0x32],0x1
   5ffd5:	movsxd rax,DWORD PTR [rbp+0xc]
   5ffd9:	imul   rax,rax,0x38
   5ffdd:	lea    rcx,[rbx+rax*1]
   5ffe1:	mov    rdx,QWORD PTR [rsp+0x190]
   5ffe9:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5ffee:	and    eax,0x9000
   5fff3:	test   eax,eax
   5fff5:	je     60058 <sqlite3VdbeExec+0x10bb8>
   5fff7:	mov    QWORD PTR [rsp+0x110],rdi
   5ffff:	mov    rdi,rcx
   60002:	mov    rsi,rdx
   60005:	call   6000a <sqlite3VdbeExec+0x10b6a>
   6000a:	mov    rdi,QWORD PTR [rsp+0x110]
   60012:	jmp    60061 <sqlite3VdbeExec+0x10bc1>
   60014:	movzx  eax,WORD PTR [r13+0x14]
   60019:	and    eax,0x9000
   6001e:	test   eax,eax
   60020:	je     6003c <sqlite3VdbeExec+0x10b9c>
   60022:	mov    QWORD PTR [rsp+0x110],rdi
   6002a:	mov    rdi,r13
   6002d:	call   60032 <sqlite3VdbeExec+0x10b92>
   60032:	mov    rdi,QWORD PTR [rsp+0x110]
   6003a:	jmp    60043 <sqlite3VdbeExec+0x10ba3>
   6003c:	mov    WORD PTR [r13+0x14],0x1
   60043:	mov    r14,QWORD PTR [rsp+0x128]
   6004b:	mov    r13,QWORD PTR [rsp+0x150]
   60053:	jmp    4f7bd <sqlite3VdbeExec+0x31d>
   60058:	mov    QWORD PTR [rcx],rdx
   6005b:	mov    WORD PTR [rcx+0x14],0x4
   60061:	mov    r14,QWORD PTR [rsp+0x128]
   60069:	mov    r13,QWORD PTR [rsp+0x150]
   60071:	mov    QWORD PTR [rsp+0x148],rbp
   60079:	mov    QWORD PTR [rsp+0x160],rbx
   60081:	mov    ebx,DWORD PTR [rsp+0x390]
   60088:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   6008d:	mov    QWORD PTR [rsp+0x128],r14
   60095:	mov    r15d,DWORD PTR [rsp+0x37c]
   6009d:	mov    QWORD PTR [rsp+0x130],r12
   600a5:	mov    r12d,DWORD PTR [rsp+0x394]
   600ad:	movsxd rax,DWORD PTR [rbp+0x4]
   600b1:	imul   rax,rax,0x38
   600b5:	lea    r13,[rbx+rax*1]
   600b9:	movsxd rcx,DWORD PTR [rbp+0xc]
   600bd:	imul   r14,rcx,0x38
   600c1:	mov    QWORD PTR [rsp+0x148],rbp
   600c9:	mov    ebp,DWORD PTR [rbp+0x10]
   600cc:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   600d1:	and    eax,0x10
   600d4:	test   eax,eax
   600d6:	jne    60119 <sqlite3VdbeExec+0x10c79>
   600d8:	mov    QWORD PTR [rsp+0x110],rdi
   600e0:	mov    rdi,r13
   600e3:	call   600e8 <sqlite3VdbeExec+0x10c48>
   600e8:	mov    rdi,QWORD PTR [rsp+0x110]
   600f0:	test   eax,eax
   600f2:	je     60119 <sqlite3VdbeExec+0x10c79>
   600f4:	mov    r14,QWORD PTR [rsp+0x128]
   600fc:	mov    r13,QWORD PTR [rsp+0x150]
   60104:	mov    rbx,QWORD PTR [rsp+0x148]
   6010c:	mov    rbp,QWORD PTR [rsp+0x158]
   60114:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   60119:	test   ebp,ebp
   6011b:	jne    6012a <sqlite3VdbeExec+0x10c8a>
   6011d:	mov    DWORD PTR [rsp+0x394],r12d
   60125:	jmp    605da <sqlite3VdbeExec+0x1113a>
   6012a:	mov    DWORD PTR [rsp+0x394],r12d
   60132:	mov    r12,QWORD PTR [r13+0x8]
   60136:	mov    QWORD PTR [rsp+0x168],r14
   6013e:	mov    r14,QWORD PTR [rbx+r14*1]
   60142:	lea    r8,[rsp+0x1b0]
   6014a:	lea    r9,[rsp+0x1b8]
   60152:	cmp    ebp,DWORD PTR [r12+0x34]
   60157:	jne    6016e <sqlite3VdbeExec+0x10cce>
   60159:	mov    QWORD PTR [rsp+0x190],r13
   60161:	mov    QWORD PTR [rsp+0x180],r14
   60169:	jmp    60567 <sqlite3VdbeExec+0x110c7>
   6016e:	mov    QWORD PTR [rsp+0x180],r14
   60176:	mov    r14,QWORD PTR [r12+0x10]
   6017b:	test   r14,r14
   6017e:	jne    60194 <sqlite3VdbeExec+0x10cf4>
   60180:	mov    QWORD PTR [rsp+0x190],r13
   60188:	mov    DWORD PTR [rsp+0x39c],ebp
   6018f:	jmp    6055b <sqlite3VdbeExec+0x110bb>
   60194:	mov    QWORD PTR [rsp+0x190],r13
   6019c:	lea    r13,[r12+0x28]
   601a1:	movzx  eax,WORD PTR [r12+0x32]
   601a7:	and    eax,0x1
   601aa:	test   eax,eax
   601ac:	jne    601d9 <sqlite3VdbeExec+0x10d39>
   601ae:	mov    QWORD PTR [rsp+0x110],rdi
   601b6:	mov    rdi,r14
   601b9:	call   601be <sqlite3VdbeExec+0x10d1e>
   601be:	mov    r14,rax
   601c1:	mov    rdi,QWORD PTR [rsp+0x110]
   601c9:	lea    r8,[rsp+0x1b0]
   601d1:	lea    r9,[rsp+0x1b8]
   601d9:	mov    QWORD PTR [rsp+0x1a0],r14
   601e1:	mov    r14,QWORD PTR [r12+0x28]
   601e6:	mov    DWORD PTR [rsp+0x39c],ebp
   601ed:	mov    rbp,r14
   601f0:	mov    r14,QWORD PTR [rsp+0x1a0]
   601f8:	mov    QWORD PTR [rsp+0x178],r13
   60200:	jmp    60389 <sqlite3VdbeExec+0x10ee9>
   60205:	mov    QWORD PTR [rsp+0x198],rbp
   6020d:	mov    rbp,QWORD PTR [r8]
   60210:	mov    rax,QWORD PTR [rbp+0x8]
   60214:	mov    QWORD PTR [r8],rax
   60217:	mov    QWORD PTR [rbp+0x10],r13
   6021b:	mov    rax,r8
   6021e:	mov    QWORD PTR [rsp+0x110],rdi
   60226:	mov    rdi,rax
   60229:	mov    rsi,r14
   6022c:	call   60231 <sqlite3VdbeExec+0x10d91>
   60231:	mov    QWORD PTR [rbp+0x8],rax
   60235:	add    r14d,0x1
   60239:	mov    rdi,QWORD PTR [rsp+0x110]
   60241:	mov    r13,rbp
   60244:	mov    rbp,QWORD PTR [rsp+0x198]
   6024c:	lea    r8,[rsp+0x1a8]
   60254:	cmp    QWORD PTR [r8],0x0
   60258:	jne    60205 <sqlite3VdbeExec+0x10d65>
   6025a:	mov    rax,r13
   6025d:	mov    r13,QWORD PTR [rsp+0x170]
   60265:	mov    QWORD PTR [r13+0x0],rax
   60269:	test   rbp,rbp
   6026c:	jne    6053a <sqlite3VdbeExec+0x1109a>
   60272:	cmp    WORD PTR [r12+0x30],0x0
   60279:	jne    60450 <sqlite3VdbeExec+0x10fb0>
   6027f:	mov    rax,QWORD PTR [r12+0x8]
   60284:	mov    ecx,0x3f8
   60289:	mov    QWORD PTR [rsp+0x110],rdi
   60291:	mov    rdi,rax
   60294:	mov    rsi,rcx
   60297:	call   6029c <sqlite3VdbeExec+0x10dfc>
   6029c:	mov    rdi,QWORD PTR [rsp+0x110]
   602a4:	test   rax,rax
   602a7:	jne    60434 <sqlite3VdbeExec+0x10f94>
   602ad:	xor    ebp,ebp
   602af:	jmp    6046d <sqlite3VdbeExec+0x10fcd>
   602b4:	mov    QWORD PTR [rsp+0x1a0],r14
   602bc:	mov    QWORD PTR [rsp+0x178],r13
   602c4:	mov    rax,QWORD PTR [rbp+0x10]
   602c8:	mov    rcx,r8
   602cb:	mov    rdx,r9
   602ce:	mov    QWORD PTR [rsp+0x110],rdi
   602d6:	mov    rdi,rax
   602d9:	mov    rsi,rcx
   602dc:	call   602e1 <sqlite3VdbeExec+0x10e41>
   602e1:	mov    QWORD PTR [rbp+0x10],0x0
   602e9:	lea    r8,[rsp+0x1b0]
   602f1:	mov    r14,QWORD PTR [r8]
   602f4:	lea    rax,[rsp+0x1d0]
   602fc:	mov    r13,rax
   602ff:	mov    rdi,QWORD PTR [rsp+0x110]
   60307:	mov    QWORD PTR [rsp+0x188],r12
   6030f:	mov    r12,r13
   60312:	mov    r13,r14
   60315:	mov    r14,QWORD PTR [rsp+0x1a0]
   6031d:	lea    r9,[rsp+0x1b8]
   60325:	jmp    60347 <sqlite3VdbeExec+0x10ea7>
   60327:	mov    QWORD PTR [rsp+0x1c8],r12
   6032f:	mov    r12,QWORD PTR [rsp+0x188]
   60337:	mov    QWORD PTR [rsp+0x188],r12
   6033f:	mov    r12,QWORD PTR [rsp+0x1c8]
   60347:	mov    rcx,QWORD PTR [r13+0x0]
   6034b:	cmp    rcx,QWORD PTR [r14]
   6034e:	jg     60405 <sqlite3VdbeExec+0x10f65>
   60354:	mov    rcx,QWORD PTR [r13+0x0]
   60358:	cmp    rcx,QWORD PTR [r14]
   6035b:	jge    60365 <sqlite3VdbeExec+0x10ec5>
   6035d:	mov    QWORD PTR [r12+0x8],r13
   60362:	mov    r12,r13
   60365:	mov    r13,QWORD PTR [r13+0x8]
   60369:	test   r13,r13
   6036c:	jne    60327 <sqlite3VdbeExec+0x10e87>
   6036e:	mov    QWORD PTR [r12+0x8],r14
   60373:	mov    rax,QWORD PTR [rax+0x8]
   60377:	mov    r12,rax
   6037a:	mov    rbp,QWORD PTR [rbp+0x8]
   6037e:	mov    r14,r12
   60381:	mov    r12,QWORD PTR [rsp+0x188]
   60389:	test   rbp,rbp
   6038c:	jne    6039b <sqlite3VdbeExec+0x10efb>
   6038e:	mov    QWORD PTR [rsp+0x1a0],r14
   60396:	jmp    60269 <sqlite3VdbeExec+0x10dc9>
   6039b:	lea    r13,[rbp+0x8]
   6039f:	cmp    QWORD PTR [rbp+0x10],0x0
   603a4:	jne    602b4 <sqlite3VdbeExec+0x10e14>
   603aa:	mov    QWORD PTR [rsp+0x178],r13
   603b2:	lea    r13,[rbp+0x10]
   603b6:	lea    r8,[rsp+0x1a8]
   603be:	mov    QWORD PTR [rsp+0x1a8],r14
   603c6:	mov    QWORD PTR [rsp+0x170],r13
   603ce:	mov    r13,QWORD PTR [rsp+0x1a8]
   603d6:	mov    rax,QWORD PTR [r13+0x8]
   603da:	mov    QWORD PTR [rsp+0x1a8],rax
   603e2:	mov    QWORD PTR [r13+0x8],0x0
   603ea:	mov    QWORD PTR [r13+0x10],0x0
   603f2:	mov    QWORD PTR [rsp+0x1a0],r14
   603fa:	mov    r14d,0x1
   60400:	jmp    60254 <sqlite3VdbeExec+0x10db4>
   60405:	mov    QWORD PTR [r12+0x8],r14
   6040a:	mov    r12,QWORD PTR [r14+0x8]
   6040e:	test   r12,r12
   60411:	je     6042b <sqlite3VdbeExec+0x10f8b>
   60413:	mov    QWORD PTR [rsp+0x1c8],r14
   6041b:	mov    r14,r12
   6041e:	mov    r12,QWORD PTR [rsp+0x188]
   60426:	jmp    60337 <sqlite3VdbeExec+0x10e97>
   6042b:	mov    QWORD PTR [r14+0x8],r13
   6042f:	jmp    60373 <sqlite3VdbeExec+0x10ed3>
   60434:	mov    rcx,QWORD PTR [r12]
   60438:	mov    QWORD PTR [rax],rcx
   6043b:	mov    QWORD PTR [r12],rax
   6043f:	add    rax,0x8
   60443:	mov    QWORD PTR [r12+0x20],rax
   60448:	mov    WORD PTR [r12+0x30],0x2a
   60450:	movzx  eax,WORD PTR [r12+0x30]
   60456:	sub    eax,0x1
   60459:	mov    WORD PTR [r12+0x30],ax
   6045f:	mov    rbp,QWORD PTR [r12+0x20]
   60464:	lea    rax,[rbp+0x18]
   60468:	mov    QWORD PTR [r12+0x20],rax
   6046d:	mov    r14,QWORD PTR [rsp+0x178]
   60475:	mov    QWORD PTR [r14],rbp
   60478:	test   rbp,rbp
   6047b:	je     6053a <sqlite3VdbeExec+0x1109a>
   60481:	mov    QWORD PTR [rbp+0x0],0x0
   60489:	mov    QWORD PTR [rbp+0x8],0x0
   60491:	lea    r8,[rsp+0x178]
   60499:	mov    r14,QWORD PTR [rsp+0x1a0]
   604a1:	mov    QWORD PTR [rsp+0x178],r14
   604a9:	mov    r14,QWORD PTR [rsp+0x178]
   604b1:	mov    rax,QWORD PTR [r14+0x8]
   604b5:	mov    QWORD PTR [rsp+0x178],rax
   604bd:	mov    QWORD PTR [r14+0x8],0x0
   604c5:	mov    QWORD PTR [r14+0x10],0x0
   604cd:	mov    r13d,0x1
   604d3:	mov    r11,r14
   604d6:	mov    r14,r13
   604d9:	mov    r13,r11
   604dc:	jmp    6052d <sqlite3VdbeExec+0x1108d>
   604de:	mov    QWORD PTR [rsp+0x1c0],rbp
   604e6:	mov    rbp,QWORD PTR [r8]
   604e9:	mov    rax,QWORD PTR [rbp+0x8]
   604ed:	mov    QWORD PTR [r8],rax
   604f0:	mov    QWORD PTR [rbp+0x10],r13
   604f4:	mov    rax,r8
   604f7:	mov    QWORD PTR [rsp+0x110],rdi
   604ff:	mov    rdi,rax
   60502:	mov    rsi,r14
   60505:	call   6050a <sqlite3VdbeExec+0x1106a>
   6050a:	mov    QWORD PTR [rbp+0x8],rax
   6050e:	add    r14d,0x1
   60512:	mov    rdi,QWORD PTR [rsp+0x110]
   6051a:	mov    r13,rbp
   6051d:	mov    rbp,QWORD PTR [rsp+0x1c0]
   60525:	lea    r8,[rsp+0x178]
   6052d:	cmp    QWORD PTR [r8],0x0
   60531:	jne    604de <sqlite3VdbeExec+0x1103e>
   60533:	mov    rax,r13
   60536:	mov    QWORD PTR [rbp+0x10],rax
   6053a:	mov    QWORD PTR [r12+0x10],0x0
   60543:	mov    QWORD PTR [r12+0x18],0x0
   6054c:	movzx  eax,WORD PTR [r12+0x32]
   60552:	or     eax,0x1
   60555:	mov    WORD PTR [r12+0x32],ax
   6055b:	mov    ebp,DWORD PTR [rsp+0x39c]
   60562:	mov    DWORD PTR [r12+0x34],ebp
   60567:	mov    rax,QWORD PTR [r12+0x28]
   6056c:	mov    r14,QWORD PTR [rsp+0x180]
   60574:	mov    rcx,rax
   60577:	jmp    605a8 <sqlite3VdbeExec+0x11108>
   60579:	mov    QWORD PTR [rsp+0x180],r14
   60581:	mov    r14,QWORD PTR [rsp+0x180]
   60589:	cmp    r14,QWORD PTR [rax]
   6058c:	jle    60599 <sqlite3VdbeExec+0x110f9>
   6058e:	mov    rax,QWORD PTR [rax+0x8]
   60592:	test   rax,rax
   60595:	jne    60579 <sqlite3VdbeExec+0x110d9>
   60597:	jmp    605a4 <sqlite3VdbeExec+0x11104>
   60599:	cmp    r14,QWORD PTR [rax]
   6059c:	jge    605c5 <sqlite3VdbeExec+0x11125>
   6059e:	mov    rax,QWORD PTR [rax+0x10]
   605a2:	jmp    60592 <sqlite3VdbeExec+0x110f2>
   605a4:	mov    rcx,QWORD PTR [rcx+0x8]
   605a8:	test   rcx,rcx
   605ab:	jne    605bf <sqlite3VdbeExec+0x1111f>
   605ad:	mov    r13,QWORD PTR [rsp+0x190]
   605b5:	mov    r14,QWORD PTR [rsp+0x168]
   605bd:	jmp    605da <sqlite3VdbeExec+0x1113a>
   605bf:	mov    rax,QWORD PTR [rcx+0x10]
   605c3:	jmp    60592 <sqlite3VdbeExec+0x110f2>
   605c5:	mov    r12,QWORD PTR [rsp+0x128]
   605cd:	mov    rbp,QWORD PTR [rsp+0x148]
   605d5:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   605da:	test   ebp,ebp
   605dc:	jl     60685 <sqlite3VdbeExec+0x111e5>
   605e2:	mov    rbp,QWORD PTR [r13+0x8]
   605e6:	mov    r12,QWORD PTR [rbx+r14*1]
   605ea:	cmp    WORD PTR [rbp+0x30],0x0
   605ef:	jne    60637 <sqlite3VdbeExec+0x11197>
   605f1:	mov    rax,QWORD PTR [rbp+0x8]
   605f5:	mov    ecx,0x3f8
   605fa:	mov    QWORD PTR [rsp+0x110],rdi
   60602:	mov    rdi,rax
   60605:	mov    rsi,rcx
   60608:	call   6060d <sqlite3VdbeExec+0x1116d>
   6060d:	mov    rdi,QWORD PTR [rsp+0x110]
   60615:	test   rax,rax
   60618:	jne    6061e <sqlite3VdbeExec+0x1117e>
   6061a:	xor    eax,eax
   6061c:	jmp    6064e <sqlite3VdbeExec+0x111ae>
   6061e:	mov    rcx,QWORD PTR [rbp+0x0]
   60622:	mov    QWORD PTR [rax],rcx
   60625:	mov    QWORD PTR [rbp+0x0],rax
   60629:	add    rax,0x8
   6062d:	mov    QWORD PTR [rbp+0x20],rax
   60631:	mov    WORD PTR [rbp+0x30],0x2a
   60637:	movzx  eax,WORD PTR [rbp+0x30]
   6063b:	sub    eax,0x1
   6063e:	mov    WORD PTR [rbp+0x30],ax
   60642:	mov    rax,QWORD PTR [rbp+0x20]
   60646:	lea    rcx,[rax+0x18]
   6064a:	mov    QWORD PTR [rbp+0x20],rcx
   6064e:	test   rax,rax
   60651:	je     60685 <sqlite3VdbeExec+0x111e5>
   60653:	mov    QWORD PTR [rax],r12
   60656:	mov    QWORD PTR [rax+0x8],0x0
   6065e:	mov    rcx,QWORD PTR [rbp+0x18]
   60662:	test   rcx,rcx
   60665:	je     6067d <sqlite3VdbeExec+0x111dd>
   60667:	cmp    r12,QWORD PTR [rcx]
   6066a:	jg     60677 <sqlite3VdbeExec+0x111d7>
   6066c:	movzx  edx,WORD PTR [rbp+0x32]
   60670:	and    edx,0xfffffffe
   60673:	mov    WORD PTR [rbp+0x32],dx
   60677:	mov    QWORD PTR [rcx+0x8],rax
   6067b:	jmp    60681 <sqlite3VdbeExec+0x111e1>
   6067d:	mov    QWORD PTR [rbp+0x10],rax
   60681:	mov    QWORD PTR [rbp+0x18],rax
   60685:	mov    r14,QWORD PTR [rsp+0x128]
   6068d:	mov    DWORD PTR [rsp+0x37c],r15d
   60695:	mov    rbp,QWORD PTR [rsp+0x148]
   6069d:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   606a2:	mov    QWORD PTR [rsp+0x128],r14
   606aa:	mov    r15d,DWORD PTR [rsp+0x37c]
   606b2:	mov    QWORD PTR [rsp+0x148],rbp
   606ba:	mov    QWORD PTR [rsp+0x130],r12
   606c2:	mov    rbp,QWORD PTR [rsp+0x148]
   606ca:	mov    r12,QWORD PTR [rbp+0x10]
   606ce:	movsxd rax,DWORD PTR [rbp+0xc]
   606d2:	imul   rax,rax,0x38
   606d6:	lea    r13,[rbx+rax*1]
   606da:	cmp    WORD PTR [rbp+0x2],0x0
   606df:	jne    606eb <sqlite3VdbeExec+0x1124b>
   606e1:	mov    r14,QWORD PTR [rsp+0x128]
   606e9:	jmp    6072c <sqlite3VdbeExec+0x1128c>
   606eb:	mov    rax,QWORD PTR [r12+0x20]
   606f0:	mov    rcx,QWORD PTR [rdi+0x108]
   606f7:	jmp    60703 <sqlite3VdbeExec+0x11263>
   606f9:	cmp    rax,QWORD PTR [rcx+0x30]
   606fd:	je     60708 <sqlite3VdbeExec+0x11268>
   606ff:	mov    rcx,QWORD PTR [rcx+0x8]
   60703:	test   rcx,rcx
   60706:	jne    606f9 <sqlite3VdbeExec+0x11259>
   60708:	test   rcx,rcx
   6070b:	jne    60717 <sqlite3VdbeExec+0x11277>
   6070d:	mov    r14,QWORD PTR [rsp+0x128]
   60715:	jmp    6072c <sqlite3VdbeExec+0x1128c>
   60717:	mov    r14,QWORD PTR [rsp+0x128]
   6071f:	mov    DWORD PTR [rsp+0x37c],r15d
   60727:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   6072c:	mov    eax,DWORD PTR [rdi+0x118]
   60732:	cmp    eax,DWORD PTR [r14+0xb0]
   60739:	jl     60781 <sqlite3VdbeExec+0x112e1>
   6073b:	mov    ebx,0x1
   60740:	lea    rax,[rip+0x0]        # 60747 <sqlite3VdbeExec+0x112a7>
   60747:	mov    QWORD PTR [rsp+0x110],rdi
   6074f:	mov    rsi,rax
   60752:	xor    eax,eax
   60754:	call   60759 <sqlite3VdbeExec+0x112b9>
   60759:	mov    rdi,QWORD PTR [rsp+0x110]
   60761:	mov    QWORD PTR [rsp+0x148],rbp
   60769:	mov    rbp,rbx
   6076c:	mov    r13,QWORD PTR [rsp+0x130]
   60774:	mov    rbx,QWORD PTR [rsp+0x158]
   6077c:	jmp    4f712 <sqlite3VdbeExec+0x272>
   60781:	movzx  eax,WORD PTR [r13+0x14]
   60786:	and    eax,0x10
   60789:	test   eax,eax
   6078b:	jne    60994 <sqlite3VdbeExec+0x114f4>
   60791:	mov    eax,DWORD PTR [r12+0xc]
   60796:	mov    ebx,eax
   60798:	add    ebx,DWORD PTR [r12+0x10]
   6079d:	cmp    DWORD PTR [r12+0x10],0x0
   607a3:	jne    607a8 <sqlite3VdbeExec+0x11308>
   607a5:	add    ebx,0x1
   607a8:	movsxd rax,ebx
   607ab:	imul   rax,rax,0x38
   607af:	add    rax,0x70
   607b3:	movsxd rcx,DWORD PTR [r12+0x10]
   607b8:	shl    rcx,0x3
   607bc:	add    rax,rcx
   607bf:	movsxd rcx,DWORD PTR [r12+0x8]
   607c4:	add    rcx,0x7
   607c8:	mov    rdx,rcx
   607cb:	sar    rdx,0x3f
   607cf:	and    rdx,0x7
   607d3:	add    rcx,rdx
   607d6:	sar    rcx,0x3
   607da:	mov    DWORD PTR [rsp+0x39c],ebx
   607e1:	lea    rbx,[rax+rcx*1]
   607e5:	test   r14,r14
   607e8:	je     60812 <sqlite3VdbeExec+0x11372>
   607ea:	mov    QWORD PTR [rsp+0x168],r13
   607f2:	mov    QWORD PTR [rsp+0x110],rdi
   607fa:	mov    rdi,r14
   607fd:	mov    rsi,rbx
   60800:	call   60805 <sqlite3VdbeExec+0x11365>
   60805:	mov    r13,rax
   60808:	mov    rdi,QWORD PTR [rsp+0x110]
   60810:	jmp    60835 <sqlite3VdbeExec+0x11395>
   60812:	mov    QWORD PTR [rsp+0x168],r13
   6081a:	mov    QWORD PTR [rsp+0x110],rdi
   60822:	mov    rdi,rbx
   60825:	call   6082a <sqlite3VdbeExec+0x1138a>
   6082a:	mov    r13,rax
   6082d:	mov    rdi,QWORD PTR [rsp+0x110]
   60835:	test   r13,r13
   60838:	je     6085a <sqlite3VdbeExec+0x113ba>
   6083a:	xor    eax,eax
   6083c:	mov    QWORD PTR [rsp+0x110],rdi
   60844:	mov    rdi,r13
   60847:	mov    rsi,rax
   6084a:	mov    rdx,rbx
   6084d:	call   60852 <sqlite3VdbeExec+0x113b2>
   60852:	mov    rdi,QWORD PTR [rsp+0x110]
   6085a:	test   r13,r13
   6085d:	jne    60877 <sqlite3VdbeExec+0x113d7>
   6085f:	mov    r13,QWORD PTR [rsp+0x150]
   60867:	mov    rbx,rbp
   6086a:	mov    rbp,QWORD PTR [rsp+0x158]
   60872:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   60877:	mov    DWORD PTR [rsp+0x37c],r15d
   6087f:	mov    r15,QWORD PTR [rsp+0x168]
   60887:	movzx  eax,WORD PTR [r15+0x14]
   6088c:	and    eax,0x9000
   60891:	test   eax,eax
   60893:	jne    6089c <sqlite3VdbeExec+0x113fc>
   60895:	cmp    DWORD PTR [r15+0x20],0x0
   6089a:	je     608b4 <sqlite3VdbeExec+0x11414>
   6089c:	mov    QWORD PTR [rsp+0x110],rdi
   608a4:	mov    rdi,r15
   608a7:	call   608ac <sqlite3VdbeExec+0x1140c>
   608ac:	mov    rdi,QWORD PTR [rsp+0x110]
   608b4:	mov    WORD PTR [r15+0x14],0x1010
   608bb:	mov    QWORD PTR [r15+0x8],r13
   608bf:	mov    DWORD PTR [r15+0x10],ebx
   608c3:	lea    rax,[rip+0x0]        # 608ca <sqlite3VdbeExec+0x1142a>
   608ca:	mov    QWORD PTR [r15+0x30],rax
   608ce:	mov    QWORD PTR [r13+0x0],rdi
   608d2:	mov    ebx,DWORD PTR [rsp+0x39c]
   608d9:	mov    DWORD PTR [r13+0x58],ebx
   608dd:	mov    eax,DWORD PTR [r12+0x10]
   608e2:	mov    DWORD PTR [r13+0x5c],eax
   608e6:	mov    rbx,QWORD PTR [rsp+0x150]
   608ee:	mov    rax,rbp
   608f1:	sub    rax,rbx
   608f4:	movabs rdx,0x2aaaaaaaaaaaaaab
   608fe:	imul   rdx
   60901:	sar    rdx,0x2
   60905:	mov    rax,rdx
   60908:	shr    rax,0x3f
   6090c:	add    rdx,rax
   6090f:	mov    rax,rdx
   60912:	mov    DWORD PTR [r13+0x4c],eax
   60916:	mov    rax,QWORD PTR [rdi+0x68]
   6091a:	mov    QWORD PTR [r13+0x18],rax
   6091e:	mov    eax,DWORD PTR [rdi+0x24]
   60921:	mov    DWORD PTR [r13+0x54],eax
   60925:	mov    rax,QWORD PTR [rdi+0x78]
   60929:	mov    QWORD PTR [r13+0x20],rax
   6092d:	mov    eax,DWORD PTR [rdi+0x28]
   60930:	mov    DWORD PTR [r13+0x48],eax
   60934:	mov    rax,QWORD PTR [rdi+0x88]
   6093b:	mov    QWORD PTR [r13+0x10],rax
   6093f:	mov    eax,DWORD PTR [rdi+0x90]
   60945:	mov    DWORD PTR [r13+0x50],eax
   60949:	mov    rax,QWORD PTR [r12+0x20]
   6094e:	mov    QWORD PTR [r13+0x30],rax
   60952:	movsxd rax,DWORD PTR [r13+0x58]
   60956:	imul   rax,rax,0x38
   6095a:	lea    rax,[r13+rax*1+0x70]
   6095f:	lea    rcx,[r13+0x70]
   60963:	jmp    60973 <sqlite3VdbeExec+0x114d3>
   60965:	mov    WORD PTR [rcx+0x14],0x0
   6096b:	mov    QWORD PTR [rcx+0x18],r14
   6096f:	add    rcx,0x38
   60973:	cmp    rcx,rax
   60976:	jne    60965 <sqlite3VdbeExec+0x114c5>
   60978:	mov    r15d,DWORD PTR [rsp+0x37c]
   60980:	mov    ebp,DWORD PTR [rsp+0x390]
   60987:	mov    rbx,r13
   6098a:	mov    r13d,DWORD PTR [rsp+0x394]
   60992:	jmp    609a7 <sqlite3VdbeExec+0x11507>
   60994:	mov    rbx,QWORD PTR [r13+0x8]
   60998:	mov    ebp,DWORD PTR [rsp+0x390]
   6099f:	mov    r13d,DWORD PTR [rsp+0x394]
   609a7:	mov    eax,DWORD PTR [rdi+0x118]
   609ad:	add    eax,0x1
   609b0:	mov    DWORD PTR [rdi+0x118],eax
   609b6:	mov    rax,QWORD PTR [rdi+0x108]
   609bd:	mov    QWORD PTR [rbx+0x8],rax
   609c1:	mov    rax,QWORD PTR [r14+0x38]
   609c5:	mov    QWORD PTR [rbx+0x38],rax
   609c9:	mov    rax,QWORD PTR [rdi+0x38]
   609cd:	mov    QWORD PTR [rbx+0x60],rax
   609d1:	mov    rax,QWORD PTR [rdi]
   609d4:	mov    rax,QWORD PTR [rax+0x78]
   609d8:	mov    QWORD PTR [rbx+0x68],rax
   609dc:	mov    rax,QWORD PTR [rdi+0x128]
   609e3:	mov    QWORD PTR [rbx+0x40],rax
   609e7:	mov    QWORD PTR [rdi+0x128],0x0
   609f2:	mov    QWORD PTR [rdi+0x38],0x0
   609fa:	mov    QWORD PTR [rdi+0x108],rbx
   60a01:	mov    DWORD PTR [rsp+0x390],ebp
   60a08:	lea    rbp,[rbx+0x70]
   60a0c:	mov    QWORD PTR [rdi+0x68],rbp
   60a10:	mov    eax,DWORD PTR [rbx+0x58]
   60a13:	mov    DWORD PTR [rdi+0x24],eax
   60a16:	mov    eax,DWORD PTR [rbx+0x5c]
   60a19:	movzx  eax,ax
   60a1c:	mov    DWORD PTR [rdi+0x28],eax
   60a1f:	movsxd rax,DWORD PTR [rdi+0x24]
   60a23:	imul   rax,rax,0x38
   60a27:	add    rax,rbp
   60a2a:	mov    QWORD PTR [rdi+0x78],rax
   60a2e:	mov    rax,QWORD PTR [rdi+0x78]
   60a32:	movsxd rcx,DWORD PTR [r12+0x10]
   60a37:	lea    rax,[rax+rcx*8]
   60a3b:	mov    QWORD PTR [rbx+0x28],rax
   60a3f:	mov    rax,QWORD PTR [rbx+0x28]
   60a43:	xor    ecx,ecx
   60a45:	mov    edx,DWORD PTR [r12+0x8]
   60a4a:	add    edx,0x7
   60a4d:	mov    esi,edx
   60a4f:	sar    esi,0x1f
   60a52:	and    esi,0x7
   60a55:	add    edx,esi
   60a57:	sar    edx,0x3
   60a5a:	movsxd rdx,edx
   60a5d:	mov    QWORD PTR [rsp+0x110],rdi
   60a65:	mov    rdi,rax
   60a68:	mov    rsi,rcx
   60a6b:	call   60a70 <sqlite3VdbeExec+0x115d0>
   60a70:	mov    rbx,QWORD PTR [r12]
   60a74:	mov    rdi,QWORD PTR [rsp+0x110]
   60a7c:	mov    QWORD PTR [rdi+0x88],rbx
   60a83:	mov    eax,DWORD PTR [r12+0x8]
   60a88:	mov    DWORD PTR [rdi+0x90],eax
   60a8e:	lea    r12,[rbx-0x18]
   60a92:	mov    QWORD PTR [rsp+0x148],r12
   60a9a:	mov    r12,r13
   60a9d:	mov    r13,rbx
   60aa0:	mov    ebx,DWORD PTR [rsp+0x390]
   60aa7:	mov    QWORD PTR [rsp+0x160],rbp
   60aaf:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   60ab4:	mov    r15d,DWORD PTR [rsp+0x37c]
   60abc:	mov    r13,QWORD PTR [rsp+0x150]
   60ac4:	mov    QWORD PTR [rsp+0x130],r12
   60acc:	mov    r12d,DWORD PTR [rsp+0x394]
   60ad4:	mov    rax,QWORD PTR [rdi+0x68]
   60ad8:	movsxd rcx,DWORD PTR [rbp+0x8]
   60adc:	imul   rcx,rcx,0x38
   60ae0:	lea    rdx,[rax+rcx*1]
   60ae4:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   60ae9:	and    eax,0x9000
   60aee:	test   eax,eax
   60af0:	je     60b0f <sqlite3VdbeExec+0x1166f>
   60af2:	mov    QWORD PTR [rsp+0x110],rdi
   60afa:	mov    rdi,rdx
   60afd:	call   60b02 <sqlite3VdbeExec+0x11662>
   60b02:	mov    rdi,QWORD PTR [rsp+0x110]
   60b0a:	mov    rdx,rax
   60b0d:	jmp    60b15 <sqlite3VdbeExec+0x11675>
   60b0f:	mov    WORD PTR [rdx+0x14],0x4
   60b15:	mov    rax,QWORD PTR [rdi+0x108]
   60b1c:	mov    rcx,QWORD PTR [rax+0x18]
   60b20:	mov    esi,DWORD PTR [rbp+0x4]
   60b23:	mov    r8,QWORD PTR [rax+0x10]
   60b27:	movsxd rax,DWORD PTR [rax+0x4c]
   60b2b:	imul   rax,rax,0x18
   60b2f:	add    esi,DWORD PTR [r8+rax*1+0x4]
   60b34:	movsxd rax,esi
   60b37:	imul   rax,rax,0x38
   60b3b:	add    rcx,rax
   60b3e:	mov    eax,0x4000
   60b43:	movzx  esi,WORD PTR [rdx+0x14]
   60b47:	and    esi,0x9000
   60b4d:	test   esi,esi
   60b4f:	je     60b71 <sqlite3VdbeExec+0x116d1>
   60b51:	mov    QWORD PTR [rsp+0x110],rdi
   60b59:	mov    rdi,rdx
   60b5c:	mov    rsi,rcx
   60b5f:	mov    rdx,rax
   60b62:	call   60b67 <sqlite3VdbeExec+0x116c7>
   60b67:	mov    rdi,QWORD PTR [rsp+0x110]
   60b6f:	jmp    60bae <sqlite3VdbeExec+0x1170e>
   60b71:	mov    rax,QWORD PTR [rcx]
   60b74:	mov    QWORD PTR [rdx],rax
   60b77:	mov    rax,QWORD PTR [rcx+0x8]
   60b7b:	mov    QWORD PTR [rdx+0x8],rax
   60b7f:	mov    rax,QWORD PTR [rcx+0x10]
   60b83:	mov    QWORD PTR [rdx+0x10],rax
   60b87:	movzx  eax,WORD PTR [rcx+0x14]
   60b8b:	and    eax,0x2000
   60b90:	test   eax,eax
   60b92:	jne    60bae <sqlite3VdbeExec+0x1170e>
   60b94:	movzx  eax,WORD PTR [rdx+0x14]
   60b98:	and    eax,0xffff8fff
   60b9d:	mov    WORD PTR [rdx+0x14],ax
   60ba1:	movzx  eax,WORD PTR [rdx+0x14]
   60ba5:	or     eax,0x4000
   60baa:	mov    WORD PTR [rdx+0x14],ax
   60bae:	mov    DWORD PTR [rsp+0x37c],r15d
   60bb6:	mov    QWORD PTR [rsp+0x150],r13
   60bbe:	mov    DWORD PTR [rsp+0x394],r12d
   60bc6:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   60bcb:	mov    r15d,DWORD PTR [rsp+0x37c]
   60bd3:	mov    r13,QWORD PTR [rsp+0x150]
   60bdb:	mov    QWORD PTR [rsp+0x130],r12
   60be3:	mov    r12d,DWORD PTR [rsp+0x394]
   60beb:	cmp    DWORD PTR [rbp+0x4],0x0
   60bef:	je     60c08 <sqlite3VdbeExec+0x11768>
   60bf1:	mov    rax,QWORD PTR [r14+0x2f0]
   60bf8:	movsxd rcx,DWORD PTR [rbp+0x8]
   60bfc:	add    rax,rcx
   60bff:	mov    QWORD PTR [r14+0x2f0],rax
   60c06:	jmp    60c3d <sqlite3VdbeExec+0x1179d>
   60c08:	mov    rax,QWORD PTR [r14+0x30]
   60c0c:	and    rax,0x80000
   60c12:	test   rax,rax
   60c15:	je     60c2e <sqlite3VdbeExec+0x1178e>
   60c17:	mov    rax,QWORD PTR [r14+0x2f8]
   60c1e:	movsxd rcx,DWORD PTR [rbp+0x8]
   60c22:	add    rax,rcx
   60c25:	mov    QWORD PTR [r14+0x2f8],rax
   60c2c:	jmp    60c3d <sqlite3VdbeExec+0x1179d>
   60c2e:	mov    rax,QWORD PTR [rdi+0x50]
   60c32:	movsxd rcx,DWORD PTR [rbp+0x8]
   60c36:	add    rax,rcx
   60c39:	mov    QWORD PTR [rdi+0x50],rax
   60c3d:	mov    DWORD PTR [rsp+0x37c],r15d
   60c45:	mov    QWORD PTR [rsp+0x150],r13
   60c4d:	mov    DWORD PTR [rsp+0x394],r12d
   60c55:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   60c5a:	mov    r15d,DWORD PTR [rsp+0x37c]
   60c62:	mov    r13,QWORD PTR [rsp+0x150]
   60c6a:	mov    QWORD PTR [rsp+0x130],r12
   60c72:	mov    r12d,DWORD PTR [rsp+0x394]
   60c7a:	cmp    DWORD PTR [rbp+0x4],0x0
   60c7e:	je     60cac <sqlite3VdbeExec+0x1180c>
   60c80:	cmp    QWORD PTR [r14+0x2f0],0x0
   60c88:	jne    60cd5 <sqlite3VdbeExec+0x11835>
   60c8a:	cmp    QWORD PTR [r14+0x2f8],0x0
   60c92:	jne    60cd5 <sqlite3VdbeExec+0x11835>
   60c94:	mov    QWORD PTR [rsp+0x150],r13
   60c9c:	mov    DWORD PTR [rsp+0x394],r12d
   60ca4:	mov    r12,r14
   60ca7:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   60cac:	cmp    QWORD PTR [rdi+0x50],0x0
   60cb1:	jne    60cd5 <sqlite3VdbeExec+0x11835>
   60cb3:	cmp    QWORD PTR [r14+0x2f8],0x0
   60cbb:	jne    60cd5 <sqlite3VdbeExec+0x11835>
   60cbd:	mov    QWORD PTR [rsp+0x150],r13
   60cc5:	mov    DWORD PTR [rsp+0x394],r12d
   60ccd:	mov    r12,r14
   60cd0:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   60cd5:	mov    DWORD PTR [rsp+0x37c],r15d
   60cdd:	mov    QWORD PTR [rsp+0x150],r13
   60ce5:	mov    DWORD PTR [rsp+0x394],r12d
   60ced:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   60cf2:	mov    r15d,DWORD PTR [rsp+0x37c]
   60cfa:	mov    r13,QWORD PTR [rsp+0x150]
   60d02:	mov    QWORD PTR [rsp+0x130],r12
   60d0a:	mov    r12d,DWORD PTR [rsp+0x394]
   60d12:	cmp    QWORD PTR [rdi+0x108],0x0
   60d1a:	je     60d4a <sqlite3VdbeExec+0x118aa>
   60d1c:	mov    rax,QWORD PTR [rdi+0x108]
   60d23:	jmp    60d29 <sqlite3VdbeExec+0x11889>
   60d25:	mov    rax,QWORD PTR [rax+0x8]
   60d29:	cmp    QWORD PTR [rax+0x8],0x0
   60d2e:	jne    60d25 <sqlite3VdbeExec+0x11885>
   60d30:	mov    rax,QWORD PTR [rax+0x18]
   60d34:	movsxd rcx,DWORD PTR [rbp+0x4]
   60d38:	imul   rcx,rcx,0x38
   60d3c:	mov    DWORD PTR [rsp+0x394],r12d
   60d44:	lea    r12,[rax+rcx*1]
   60d48:	jmp    60d5e <sqlite3VdbeExec+0x118be>
   60d4a:	mov    DWORD PTR [rsp+0x394],r12d
   60d52:	movsxd rax,DWORD PTR [rbp+0x4]
   60d56:	imul   rax,rax,0x38
   60d5a:	lea    r12,[rbx+rax*1]
   60d5e:	movzx  eax,WORD PTR [r12+0x14]
   60d64:	mov    ecx,eax
   60d66:	and    ecx,0x24
   60d69:	test   ecx,ecx
   60d6b:	je     60d76 <sqlite3VdbeExec+0x118d6>
   60d6d:	mov    rax,QWORD PTR [r12]
   60d71:	jmp    60df9 <sqlite3VdbeExec+0x11959>
   60d76:	mov    ecx,eax
   60d78:	and    ecx,0x8
   60d7b:	test   ecx,ecx
   60d7d:	je     60dce <sqlite3VdbeExec+0x1192e>
   60d7f:	movsd  xmm1,QWORD PTR [r12]
   60d85:	movabs r11,0xc3dfffffffffffff
   60d8f:	movq   xmm0,r11
   60d94:	ucomisd xmm0,xmm1
   60d98:	jbe    60da6 <sqlite3VdbeExec+0x11906>
   60d9a:	movabs rax,0x8000000000000000
   60da4:	jmp    60dcc <sqlite3VdbeExec+0x1192c>
   60da6:	movabs r11,0x43dfffffffffffff
   60db0:	movq   xmm0,r11
   60db5:	ucomisd xmm1,xmm0
   60db9:	jbe    60dc7 <sqlite3VdbeExec+0x11927>
   60dbb:	movabs rax,0x7fffffffffffffff
   60dc5:	jmp    60dcc <sqlite3VdbeExec+0x1192c>
   60dc7:	cvttsd2si rax,xmm1
   60dcc:	jmp    60df9 <sqlite3VdbeExec+0x11959>
   60dce:	and    eax,0x12
   60dd1:	test   eax,eax
   60dd3:	je     60df7 <sqlite3VdbeExec+0x11957>
   60dd5:	cmp    QWORD PTR [r12+0x8],0x0
   60ddb:	je     60df7 <sqlite3VdbeExec+0x11957>
   60ddd:	mov    QWORD PTR [rsp+0x110],rdi
   60de5:	mov    rdi,r12
   60de8:	call   60ded <sqlite3VdbeExec+0x1194d>
   60ded:	mov    rdi,QWORD PTR [rsp+0x110]
   60df5:	jmp    60df9 <sqlite3VdbeExec+0x11959>
   60df7:	xor    eax,eax
   60df9:	mov    QWORD PTR [r12],rax
   60dfd:	movzx  eax,WORD PTR [r12+0x14]
   60e03:	and    eax,0xfffff240
   60e08:	or     eax,0x4
   60e0b:	mov    WORD PTR [r12+0x14],ax
   60e11:	movsxd rax,DWORD PTR [rbp+0x8]
   60e15:	imul   rax,rax,0x38
   60e19:	mov    QWORD PTR [rsp+0x168],r12
   60e21:	lea    r12,[rbx+rax*1]
   60e25:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   60e2a:	mov    ecx,eax
   60e2c:	and    ecx,0x24
   60e2f:	test   ecx,ecx
   60e31:	je     60e3c <sqlite3VdbeExec+0x1199c>
   60e33:	mov    rax,QWORD PTR [r12]
   60e37:	jmp    60ebf <sqlite3VdbeExec+0x11a1f>
   60e3c:	mov    ecx,eax
   60e3e:	and    ecx,0x8
   60e41:	test   ecx,ecx
   60e43:	je     60e94 <sqlite3VdbeExec+0x119f4>
   60e45:	movsd  xmm1,QWORD PTR [r12]
   60e4b:	movabs r11,0xc3dfffffffffffff
   60e55:	movq   xmm0,r11
   60e5a:	ucomisd xmm0,xmm1
   60e5e:	jbe    60e6c <sqlite3VdbeExec+0x119cc>
   60e60:	movabs rax,0x8000000000000000
   60e6a:	jmp    60e92 <sqlite3VdbeExec+0x119f2>
   60e6c:	movabs r11,0x43dfffffffffffff
   60e76:	movq   xmm0,r11
   60e7b:	ucomisd xmm1,xmm0
   60e7f:	jbe    60e8d <sqlite3VdbeExec+0x119ed>
   60e81:	movabs rax,0x7fffffffffffffff
   60e8b:	jmp    60e92 <sqlite3VdbeExec+0x119f2>
   60e8d:	cvttsd2si rax,xmm1
   60e92:	jmp    60ebf <sqlite3VdbeExec+0x11a1f>
   60e94:	and    eax,0x12
   60e97:	test   eax,eax
   60e99:	je     60ebd <sqlite3VdbeExec+0x11a1d>
   60e9b:	cmp    QWORD PTR [r12+0x8],0x0
   60ea1:	je     60ebd <sqlite3VdbeExec+0x11a1d>
   60ea3:	mov    QWORD PTR [rsp+0x110],rdi
   60eab:	mov    rdi,r12
   60eae:	call   60eb3 <sqlite3VdbeExec+0x11a13>
   60eb3:	mov    rdi,QWORD PTR [rsp+0x110]
   60ebb:	jmp    60ebf <sqlite3VdbeExec+0x11a1f>
   60ebd:	xor    eax,eax
   60ebf:	mov    QWORD PTR [r12],rax
   60ec3:	movzx  eax,WORD PTR [r12+0x14]
   60ec9:	and    eax,0xfffff240
   60ece:	or     eax,0x4
   60ed1:	mov    WORD PTR [r12+0x14],ax
   60ed7:	mov    QWORD PTR [rsp+0x150],r13
   60edf:	mov    r13,QWORD PTR [rsp+0x168]
   60ee7:	mov    rax,QWORD PTR [r13+0x0]
   60eeb:	cmp    rax,QWORD PTR [r12]
   60eef:	jge    60ef9 <sqlite3VdbeExec+0x11a59>
   60ef1:	mov    rax,QWORD PTR [r12]
   60ef5:	mov    QWORD PTR [r13+0x0],rax
   60ef9:	mov    DWORD PTR [rsp+0x37c],r15d
   60f01:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   60f06:	mov    r15d,DWORD PTR [rsp+0x37c]
   60f0e:	mov    QWORD PTR [rsp+0x130],r12
   60f16:	movsxd rax,DWORD PTR [rbp+0x4]
   60f1a:	imul   rax,rax,0x38
   60f1e:	cmp    QWORD PTR [rbx+rax*1],0x0
   60f23:	jle    60f3c <sqlite3VdbeExec+0x11a9c>
   60f25:	mov    rcx,QWORD PTR [rbx+rax*1]
   60f29:	movsxd rdx,DWORD PTR [rbp+0xc]
   60f2d:	sub    rcx,rdx
   60f30:	mov    QWORD PTR [rbx+rax*1],rcx
   60f34:	mov    r12,r14
   60f37:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   60f3c:	mov    DWORD PTR [rsp+0x37c],r15d
   60f44:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   60f49:	mov    r15d,DWORD PTR [rsp+0x37c]
   60f51:	mov    QWORD PTR [rsp+0x130],r12
   60f59:	movsxd rax,DWORD PTR [rbp+0x4]
   60f5d:	imul   r12,rax,0x38
   60f61:	movsxd rax,DWORD PTR [rbp+0xc]
   60f65:	imul   r13,rax,0x38
   60f69:	mov    rax,QWORD PTR [rdi+0x68]
   60f6d:	movsxd rcx,DWORD PTR [rbp+0x8]
   60f71:	imul   rcx,rcx,0x38
   60f75:	lea    rdx,[rax+rcx*1]
   60f79:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   60f7e:	and    eax,0x9000
   60f83:	test   eax,eax
   60f85:	je     60fa4 <sqlite3VdbeExec+0x11b04>
   60f87:	mov    QWORD PTR [rsp+0x110],rdi
   60f8f:	mov    rdi,rdx
   60f92:	call   60f97 <sqlite3VdbeExec+0x11af7>
   60f97:	mov    rdi,QWORD PTR [rsp+0x110]
   60f9f:	mov    rdx,rax
   60fa2:	jmp    60faa <sqlite3VdbeExec+0x11b0a>
   60fa4:	mov    WORD PTR [rdx+0x14],0x4
   60faa:	mov    rax,QWORD PTR [rbx+r12*1]
   60fae:	mov    QWORD PTR [rsp+0x168],rax
   60fb6:	cmp    QWORD PTR [rsp+0x168],0x0
   60fbf:	jle    60ff4 <sqlite3VdbeExec+0x11b54>
   60fc1:	cmp    QWORD PTR [rbx+r13*1],0x0
   60fc6:	jle    60fce <sqlite3VdbeExec+0x11b2e>
   60fc8:	mov    rax,QWORD PTR [rbx+r13*1]
   60fcc:	jmp    60fd0 <sqlite3VdbeExec+0x11b30>
   60fce:	xor    eax,eax
   60fd0:	mov    rcx,QWORD PTR [rsp+0x168]
   60fd8:	test   rax,rax
   60fdb:	jl     60ffd <sqlite3VdbeExec+0x11b5d>
   60fdd:	test   rcx,rcx
   60fe0:	jle    6101b <sqlite3VdbeExec+0x11b7b>
   60fe2:	movabs rsi,0x7fffffffffffffff
   60fec:	sub    rsi,rcx
   60fef:	cmp    rsi,rax
   60ff2:	jge    6101b <sqlite3VdbeExec+0x11b7b>
   60ff4:	mov    QWORD PTR [rdx],0xffffffffffffffff
   60ffb:	jmp    61036 <sqlite3VdbeExec+0x11b96>
   60ffd:	test   rcx,rcx
   61000:	jge    6101b <sqlite3VdbeExec+0x11b7b>
   61002:	movabs rsi,0x7fffffffffffffff
   6100c:	add    rcx,rsi
   6100f:	neg    rcx
   61012:	lea    rsi,[rax+0x1]
   61016:	cmp    rcx,rsi
   61019:	jg     60ff4 <sqlite3VdbeExec+0x11b54>
   6101b:	add    rax,QWORD PTR [rsp+0x168]
   61023:	mov    QWORD PTR [rsp+0x168],rax
   6102b:	mov    rax,QWORD PTR [rsp+0x168]
   61033:	mov    QWORD PTR [rdx],rax
   61036:	mov    DWORD PTR [rsp+0x37c],r15d
   6103e:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   61043:	mov    r15d,DWORD PTR [rsp+0x37c]
   6104b:	mov    QWORD PTR [rsp+0x130],r12
   61053:	movsxd rax,DWORD PTR [rbp+0x4]
   61057:	imul   rax,rax,0x38
   6105b:	cmp    QWORD PTR [rbx+rax*1],0x0
   61060:	je     6107d <sqlite3VdbeExec+0x11bdd>
   61062:	cmp    QWORD PTR [rbx+rax*1],0x0
   61067:	jle    61075 <sqlite3VdbeExec+0x11bd5>
   61069:	mov    rcx,QWORD PTR [rbx+rax*1]
   6106d:	sub    rcx,0x1
   61071:	mov    QWORD PTR [rbx+rax*1],rcx
   61075:	mov    r12,r14
   61078:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   6107d:	mov    DWORD PTR [rsp+0x37c],r15d
   61085:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   6108a:	mov    r15d,DWORD PTR [rsp+0x37c]
   61092:	mov    QWORD PTR [rsp+0x130],r12
   6109a:	movsxd rax,DWORD PTR [rbp+0x4]
   6109e:	imul   rax,rax,0x38
   610a2:	movabs rcx,0x8000000000000000
   610ac:	cmp    rcx,QWORD PTR [rbx+rax*1]
   610b0:	jge    610be <sqlite3VdbeExec+0x11c1e>
   610b2:	mov    rcx,QWORD PTR [rbx+rax*1]
   610b6:	sub    rcx,0x1
   610ba:	mov    QWORD PTR [rbx+rax*1],rcx
   610be:	cmp    QWORD PTR [rbx+rax*1],0x0
   610c3:	jne    610cd <sqlite3VdbeExec+0x11c2d>
   610c5:	mov    r12,r14
   610c8:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   610cd:	mov    DWORD PTR [rsp+0x37c],r15d
   610d5:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   610da:	mov    r15d,DWORD PTR [rsp+0x37c]
   610e2:	mov    QWORD PTR [rsp+0x130],r12
   610ea:	movzx  eax,WORD PTR [rbp+0x2]
   610ee:	mov    r12d,eax
   610f1:	mov    rax,r12
   610f4:	shl    rax,0x3
   610f8:	lea    r13,[rax+0x30]
   610fc:	lea    rax,[r13+0x38]
   61100:	mov    QWORD PTR [rsp+0x110],rdi
   61108:	mov    rdi,r14
   6110b:	mov    rsi,rax
   6110e:	call   61113 <sqlite3VdbeExec+0x11c73>
   61113:	mov    rcx,rax
   61116:	mov    rdi,QWORD PTR [rsp+0x110]
   6111e:	test   rcx,rcx
   61121:	jne    6113b <sqlite3VdbeExec+0x11c9b>
   61123:	mov    r13,QWORD PTR [rsp+0x150]
   6112b:	mov    rbx,rbp
   6112e:	mov    rbp,QWORD PTR [rsp+0x158]
   61136:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   6113b:	lea    rax,[rcx+r13*1]
   6113f:	mov    QWORD PTR [rcx],rax
   61142:	mov    rax,QWORD PTR [rcx]
   61145:	mov    WORD PTR [rax+0x14],0x1
   6114b:	mov    QWORD PTR [rax+0x18],r14
   6114f:	mov    DWORD PTR [rax+0x20],0x0
   61156:	mov    QWORD PTR [rcx+0x10],0x0
   6115e:	mov    rax,QWORD PTR [rbp+0x10]
   61162:	mov    QWORD PTR [rcx+0x8],rax
   61166:	mov    r13,QWORD PTR [rsp+0x150]
   6116e:	mov    rax,rbp
   61171:	sub    rax,r13
   61174:	movabs rdx,0x2aaaaaaaaaaaaaab
   6117e:	imul   rdx
   61181:	sar    rdx,0x2
   61185:	mov    rax,rdx
   61188:	shr    rax,0x3f
   6118c:	add    rdx,rax
   6118f:	mov    rax,rdx
   61192:	mov    DWORD PTR [rcx+0x20],eax
   61195:	mov    QWORD PTR [rcx+0x18],rdi
   61199:	mov    BYTE PTR [rcx+0x29],0x0
   6119d:	mov    DWORD PTR [rcx+0x24],0x0
   611a4:	mov    BYTE PTR [rcx+0x28],r15b
   611a8:	mov    WORD PTR [rcx+0x2a],r12w
   611ad:	mov    BYTE PTR [rbp+0x1],0xf0
   611b1:	mov    QWORD PTR [rbp+0x10],rcx
   611b5:	mov    BYTE PTR [rbp+0x0],0xa5
   611b9:	mov    r12,QWORD PTR [rbp+0x10]
   611bd:	movsxd rax,DWORD PTR [rbp+0xc]
   611c1:	imul   rax,rax,0x38
   611c5:	add    rax,rbx
   611c8:	cmp    rax,QWORD PTR [r12+0x10]
   611cd:	je     611fd <sqlite3VdbeExec+0x11d5d>
   611cf:	mov    QWORD PTR [r12+0x10],rax
   611d4:	movzx  ecx,WORD PTR [r12+0x2a]
   611da:	sub    ecx,0x1
   611dd:	jmp    611f9 <sqlite3VdbeExec+0x11d59>
   611df:	mov    rdx,rcx
   611e2:	mov    esi,ecx
   611e4:	add    esi,DWORD PTR [rbp+0x8]
   611e7:	movsxd rsi,esi
   611ea:	imul   rsi,rsi,0x38
   611ee:	add    rsi,rbx
   611f1:	mov    QWORD PTR [r12+rdx*8+0x30],rsi
   611f6:	sub    ecx,0x1
   611f9:	test   ecx,ecx
   611fb:	jge    611df <sqlite3VdbeExec+0x11d3f>
   611fd:	mov    ecx,DWORD PTR [rax+0x10]
   61200:	add    ecx,0x1
   61203:	mov    DWORD PTR [rax+0x10],ecx
   61206:	cmp    DWORD PTR [rbp+0x4],0x0
   6120a:	je     6123e <sqlite3VdbeExec+0x11d9e>
   6120c:	mov    rax,QWORD PTR [r12+0x8]
   61211:	mov    rax,QWORD PTR [rax+0x30]
   61215:	movzx  ecx,WORD PTR [r12+0x2a]
   6121b:	lea    rdx,[r12+0x30]
   61220:	mov    QWORD PTR [rsp+0x110],rdi
   61228:	mov    rdi,r12
   6122b:	mov    rsi,rcx
   6122e:	mov    r10,rax
   61231:	call   r10
   61234:	mov    rdi,QWORD PTR [rsp+0x110]
   6123c:	jmp    6126e <sqlite3VdbeExec+0x11dce>
   6123e:	mov    rax,QWORD PTR [r12+0x8]
   61243:	mov    rax,QWORD PTR [rax+0x18]
   61247:	movzx  ecx,WORD PTR [r12+0x2a]
   6124d:	lea    rdx,[r12+0x30]
   61252:	mov    QWORD PTR [rsp+0x110],rdi
   6125a:	mov    rdi,r12
   6125d:	mov    rsi,rcx
   61260:	mov    r10,rax
   61263:	call   r10
   61266:	mov    rdi,QWORD PTR [rsp+0x110]
   6126e:	cmp    DWORD PTR [r12+0x24],0x0
   61274:	je     613fe <sqlite3VdbeExec+0x11f5e>
   6127a:	cmp    DWORD PTR [r12+0x24],0x0
   61280:	jle    61321 <sqlite3VdbeExec+0x11e81>
   61286:	mov    rax,QWORD PTR [r12]
   6128a:	test   rax,rax
   6128d:	jne    61293 <sqlite3VdbeExec+0x11df3>
   6128f:	xor    eax,eax
   61291:	jmp    612e0 <sqlite3VdbeExec+0x11e40>
   61293:	movzx  ecx,WORD PTR [rax+0x14]
   61297:	and    ecx,0x202
   6129d:	cmp    ecx,0x202
   612a3:	jne    612b1 <sqlite3VdbeExec+0x11e11>
   612a5:	cmp    BYTE PTR [rax+0x16],0x1
   612a9:	jne    612b1 <sqlite3VdbeExec+0x11e11>
   612ab:	mov    rax,QWORD PTR [rax+0x8]
   612af:	jmp    612e0 <sqlite3VdbeExec+0x11e40>
   612b1:	movzx  ecx,WORD PTR [rax+0x14]
   612b5:	and    ecx,0x1
   612b8:	test   ecx,ecx
   612ba:	je     612c0 <sqlite3VdbeExec+0x11e20>
   612bc:	xor    eax,eax
   612be:	jmp    612e0 <sqlite3VdbeExec+0x11e40>
   612c0:	mov    ecx,0x1
   612c5:	mov    QWORD PTR [rsp+0x110],rdi
   612cd:	mov    rdi,rax
   612d0:	mov    rsi,rcx
   612d3:	call   612d8 <sqlite3VdbeExec+0x11e38>
   612d8:	mov    rdi,QWORD PTR [rsp+0x110]
   612e0:	mov    QWORD PTR [rsp+0x150],r13
   612e8:	lea    r13,[rip+0x0]        # 612ef <sqlite3VdbeExec+0x11e4f>
   612ef:	mov    QWORD PTR [rsp+0x110],rdi
   612f7:	mov    rsi,r13
   612fa:	mov    rdx,rax
   612fd:	xor    eax,eax
   612ff:	call   61304 <sqlite3VdbeExec+0x11e64>
   61304:	mov    r13d,DWORD PTR [r12+0x24]
   61309:	mov    rdi,QWORD PTR [rsp+0x110]
   61311:	mov    DWORD PTR [rsp+0x38c],r13d
   61319:	mov    r13,QWORD PTR [rsp+0x150]
   61321:	cmp    BYTE PTR [r12+0x29],0x0
   61327:	je     6137c <sqlite3VdbeExec+0x11edc>
   61329:	movsxd rax,DWORD PTR [rbp-0x14]
   6132d:	test   eax,eax
   6132f:	je     61376 <sqlite3VdbeExec+0x11ed6>
   61331:	imul   rax,rax,0x38
   61335:	lea    rcx,[rbx+rax*1]
   61339:	mov    edx,0x1
   6133e:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   61343:	and    eax,0x9000
   61348:	test   eax,eax
   6134a:	je     61369 <sqlite3VdbeExec+0x11ec9>
   6134c:	mov    QWORD PTR [rsp+0x110],rdi
   61354:	mov    rdi,rcx
   61357:	mov    rsi,rdx
   6135a:	call   6135f <sqlite3VdbeExec+0x11ebf>
   6135f:	mov    rdi,QWORD PTR [rsp+0x110]
   61367:	jmp    61376 <sqlite3VdbeExec+0x11ed6>
   61369:	mov    QWORD PTR [rcx],0x1
   61370:	mov    WORD PTR [rcx+0x14],0x4
   61376:	mov    BYTE PTR [r12+0x29],0x0
   6137c:	mov    rax,QWORD PTR [r12]
   61380:	movzx  ecx,WORD PTR [rax+0x14]
   61384:	and    ecx,0x9000
   6138a:	test   ecx,ecx
   6138c:	jne    61394 <sqlite3VdbeExec+0x11ef4>
   6138e:	cmp    DWORD PTR [rax+0x20],0x0
   61392:	je     613ac <sqlite3VdbeExec+0x11f0c>
   61394:	mov    QWORD PTR [rsp+0x110],rdi
   6139c:	mov    rdi,rax
   6139f:	call   613a4 <sqlite3VdbeExec+0x11f04>
   613a4:	mov    rdi,QWORD PTR [rsp+0x110]
   613ac:	mov    rax,QWORD PTR [r12]
   613b0:	mov    WORD PTR [rax+0x14],0x1
   613b6:	mov    DWORD PTR [r12+0x24],0x0
   613bf:	mov    r12d,DWORD PTR [rsp+0x38c]
   613c7:	test   r12d,r12d
   613ca:	jne    613d6 <sqlite3VdbeExec+0x11f36>
   613cc:	mov    DWORD PTR [rsp+0x38c],r12d
   613d4:	jmp    613fe <sqlite3VdbeExec+0x11f5e>
   613d6:	mov    QWORD PTR [rsp+0x150],r13
   613de:	mov    QWORD PTR [rsp+0x148],rbp
   613e6:	mov    rbp,r12
   613e9:	mov    r13,QWORD PTR [rsp+0x130]
   613f1:	mov    rbx,QWORD PTR [rsp+0x158]
   613f9:	jmp    4f712 <sqlite3VdbeExec+0x272>
   613fe:	mov    DWORD PTR [rsp+0x37c],r15d
   61406:	mov    QWORD PTR [rsp+0x150],r13
   6140e:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   61413:	mov    r15d,DWORD PTR [rsp+0x37c]
   6141b:	mov    r13,QWORD PTR [rsp+0x150]
   61423:	mov    QWORD PTR [rsp+0x130],r12
   6142b:	movsxd rax,DWORD PTR [rbp+0x4]
   6142f:	imul   rax,rax,0x38
   61433:	lea    r12,[rbx+rax*1]
   61437:	cmp    DWORD PTR [rbp+0xc],0x0
   6143b:	je     61529 <sqlite3VdbeExec+0x12089>
   61441:	movsxd rax,DWORD PTR [rbp+0xc]
   61445:	mov    QWORD PTR [rsp+0x150],r13
   6144d:	imul   r13,rax,0x38
   61451:	mov    DWORD PTR [rsp+0x37c],r15d
   61459:	lea    r15,[rbx+r13*1]
   6145d:	mov    QWORD PTR [rsp+0x128],r14
   61465:	mov    r14,QWORD PTR [rbp+0x10]
   61469:	mov    QWORD PTR [rsp+0x148],rbp
   61471:	lea    rbp,[rsp+0x210]
   61479:	mov    rax,rbp
   6147c:	xor    ecx,ecx
   6147e:	mov    edx,0x30
   61483:	mov    QWORD PTR [rsp+0x110],rdi
   6148b:	mov    rdi,rax
   6148e:	mov    rsi,rcx
   61491:	call   61496 <sqlite3VdbeExec+0x11ff6>
   61496:	movzx  eax,WORD PTR [rbx+r13*1+0x14]
   6149c:	and    eax,0x9000
   614a1:	mov    rdi,QWORD PTR [rsp+0x110]
   614a9:	test   eax,eax
   614ab:	je     614bf <sqlite3VdbeExec+0x1201f>
   614ad:	mov    rdi,r15
   614b0:	call   614b5 <sqlite3VdbeExec+0x12015>
   614b5:	mov    rdi,QWORD PTR [rsp+0x110]
   614bd:	jmp    614c6 <sqlite3VdbeExec+0x12026>
   614bf:	mov    WORD PTR [r15+0x14],0x1
   614c6:	mov    QWORD PTR [rbp+0x0],r15
   614ca:	mov    QWORD PTR [rbp+0x10],r12
   614ce:	mov    QWORD PTR [rbp+0x8],r14
   614d2:	mov    rax,QWORD PTR [r12+0x18]
   614d7:	movzx  eax,BYTE PTR [rax+0x64]
   614db:	mov    BYTE PTR [rbp+0x28],al
   614de:	mov    rax,QWORD PTR [r14+0x28]
   614e2:	mov    rcx,rbp
   614e5:	mov    QWORD PTR [rsp+0x110],rdi
   614ed:	mov    rdi,rcx
   614f0:	mov    r10,rax
   614f3:	call   r10
   614f6:	mov    eax,DWORD PTR [rbp+0x24]
   614f9:	mov    ebp,eax
   614fb:	mov    r12,QWORD PTR [rsp+0x148]
   61503:	movsxd rax,DWORD PTR [r12+0xc]
   61508:	imul   rax,rax,0x38
   6150c:	lea    r13,[rbx+rax*1]
   61510:	mov    rdi,QWORD PTR [rsp+0x110]
   61518:	mov    r11,rbp
   6151b:	mov    rbp,r12
   6151e:	mov    r12,r13
   61521:	mov    r13,r11
   61524:	jmp    61636 <sqlite3VdbeExec+0x12196>
   61529:	mov    QWORD PTR [rsp+0x128],r14
   61531:	mov    DWORD PTR [rsp+0x37c],r15d
   61539:	mov    QWORD PTR [rsp+0x150],r13
   61541:	mov    r13,QWORD PTR [rbp+0x10]
   61545:	lea    r14,[rsp+0x210]
   6154d:	lea    r15,[rsp+0x278]
   61555:	mov    rax,r14
   61558:	xor    ecx,ecx
   6155a:	mov    edx,0x30
   6155f:	mov    QWORD PTR [rsp+0x110],rdi
   61567:	mov    rdi,rax
   6156a:	mov    rsi,rcx
   6156d:	call   61572 <sqlite3VdbeExec+0x120d2>
   61572:	mov    rax,r15
   61575:	xor    ecx,ecx
   61577:	mov    edx,0x38
   6157c:	mov    rdi,rax
   6157f:	mov    rsi,rcx
   61582:	call   61587 <sqlite3VdbeExec+0x120e7>
   61587:	mov    WORD PTR [rsp+0x28c],0x1
   61591:	mov    rax,QWORD PTR [r12+0x18]
   61596:	mov    QWORD PTR [rsp+0x290],rax
   6159e:	mov    rax,r15
   615a1:	mov    QWORD PTR [rsp+0x210],rax
   615a9:	mov    QWORD PTR [rsp+0x220],r12
   615b1:	mov    QWORD PTR [rsp+0x218],r13
   615b9:	mov    rax,QWORD PTR [rsp+0x290]
   615c1:	movzx  eax,BYTE PTR [rax+0x64]
   615c5:	mov    BYTE PTR [rsp+0x238],al
   615cc:	mov    rax,QWORD PTR [r13+0x20]
   615d0:	mov    rcx,r14
   615d3:	mov    rdi,rcx
   615d6:	mov    r10,rax
   615d9:	call   r10
   615dc:	mov    rdi,QWORD PTR [rsp+0x110]
   615e4:	cmp    DWORD PTR [r12+0x20],0x0
   615ea:	jle    61609 <sqlite3VdbeExec+0x12169>
   615ec:	mov    rax,QWORD PTR [r12+0x18]
   615f1:	mov    rcx,QWORD PTR [r12+0x28]
   615f6:	mov    rdi,rax
   615f9:	mov    rsi,rcx
   615fc:	call   61601 <sqlite3VdbeExec+0x12161>
   61601:	mov    rdi,QWORD PTR [rsp+0x110]
   61609:	mov    rax,r15
   6160c:	mov    ecx,0x38
   61611:	mov    QWORD PTR [rsp+0x110],rdi
   61619:	mov    rdi,r12
   6161c:	mov    rsi,rax
   6161f:	mov    rdx,rcx
   61622:	call   61627 <sqlite3VdbeExec+0x12187>
   61627:	mov    eax,DWORD PTR [r14+0x24]
   6162b:	mov    r13d,eax
   6162e:	mov    rdi,QWORD PTR [rsp+0x110]
   61636:	test   r13d,r13d
   61639:	je     616fe <sqlite3VdbeExec+0x1225e>
   6163f:	lea    rbx,[rip+0x0]        # 61646 <sqlite3VdbeExec+0x121a6>
   61646:	test   r12,r12
   61649:	jne    61657 <sqlite3VdbeExec+0x121b7>
   6164b:	xor    eax,eax
   6164d:	mov    r14,QWORD PTR [rsp+0x128]
   61655:	jmp    616c1 <sqlite3VdbeExec+0x12221>
   61657:	movzx  eax,WORD PTR [r12+0x14]
   6165d:	and    eax,0x202
   61662:	cmp    eax,0x202
   61667:	jne    61680 <sqlite3VdbeExec+0x121e0>
   61669:	cmp    BYTE PTR [r12+0x16],0x1
   6166f:	jne    61680 <sqlite3VdbeExec+0x121e0>
   61671:	mov    rax,QWORD PTR [r12+0x8]
   61676:	mov    r14,QWORD PTR [rsp+0x128]
   6167e:	jmp    616c1 <sqlite3VdbeExec+0x12221>
   61680:	movzx  eax,WORD PTR [r12+0x14]
   61686:	and    eax,0x1
   61689:	test   eax,eax
   6168b:	je     61699 <sqlite3VdbeExec+0x121f9>
   6168d:	xor    eax,eax
   6168f:	mov    r14,QWORD PTR [rsp+0x128]
   61697:	jmp    616c1 <sqlite3VdbeExec+0x12221>
   61699:	mov    eax,0x1
   6169e:	mov    QWORD PTR [rsp+0x110],rdi
   616a6:	mov    rdi,r12
   616a9:	mov    rsi,rax
   616ac:	call   616b1 <sqlite3VdbeExec+0x12211>
   616b1:	mov    rdi,QWORD PTR [rsp+0x110]
   616b9:	mov    r14,QWORD PTR [rsp+0x128]
   616c1:	mov    QWORD PTR [rsp+0x110],rdi
   616c9:	mov    rsi,rbx
   616cc:	mov    rdx,rax
   616cf:	xor    eax,eax
   616d1:	call   616d6 <sqlite3VdbeExec+0x12236>
   616d6:	mov    rdi,QWORD PTR [rsp+0x110]
   616de:	mov    QWORD PTR [rsp+0x148],rbp
   616e6:	mov    rbp,r13
   616e9:	mov    r13,QWORD PTR [rsp+0x130]
   616f1:	mov    rbx,QWORD PTR [rsp+0x158]
   616f9:	jmp    4f712 <sqlite3VdbeExec+0x272>
   616fe:	mov    r15d,DWORD PTR [rsp+0x37c]
   61706:	mov    eax,r15d
   61709:	movzx  ecx,WORD PTR [r12+0x14]
   6170f:	and    ecx,0x2
   61712:	test   ecx,ecx
   61714:	jne    61725 <sqlite3VdbeExec+0x12285>
   61716:	mov    BYTE PTR [r12+0x16],al
   6171b:	mov    r14,QWORD PTR [rsp+0x128]
   61723:	jmp    6175c <sqlite3VdbeExec+0x122bc>
   61725:	movzx  ecx,BYTE PTR [r12+0x16]
   6172b:	cmp    ecx,eax
   6172d:	jne    61739 <sqlite3VdbeExec+0x12299>
   6172f:	mov    r14,QWORD PTR [rsp+0x128]
   61737:	jmp    6175c <sqlite3VdbeExec+0x122bc>
   61739:	mov    r14,QWORD PTR [rsp+0x128]
   61741:	mov    QWORD PTR [rsp+0x110],rdi
   61749:	mov    rdi,r12
   6174c:	mov    rsi,rax
   6174f:	call   61754 <sqlite3VdbeExec+0x122b4>
   61754:	mov    rdi,QWORD PTR [rsp+0x110]
   6175c:	mov    DWORD PTR [rsp+0x37c],r15d
   61764:	mov    DWORD PTR [rsp+0x38c],r13d
   6176c:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   61771:	mov    r15d,DWORD PTR [rsp+0x37c]
   61779:	mov    QWORD PTR [rsp+0x130],r12
   61781:	mov    DWORD PTR [rsp+0x3c0],0x0
   6178c:	mov    DWORD PTR [rsp+0x3c8],0xffffffff
   61797:	mov    DWORD PTR [rsp+0x3c4],0xffffffff
   617a2:	mov    eax,DWORD PTR [rbp+0x4]
   617a5:	mov    ecx,DWORD PTR [rbp+0x8]
   617a8:	lea    r12,[rsp+0x3c0]
   617b0:	lea    rdx,[r12+0x4]
   617b5:	lea    rsi,[r12+0x8]
   617ba:	mov    QWORD PTR [rsp+0x110],rdi
   617c2:	mov    rdi,r14
   617c5:	mov    r8,rsi
   617c8:	mov    rsi,rax
   617cb:	mov    r11,rdx
   617ce:	mov    rdx,rcx
   617d1:	mov    rcx,r11
   617d4:	call   617d9 <sqlite3VdbeExec+0x12339>
   617d9:	mov    r13d,eax
   617dc:	mov    rdi,QWORD PTR [rsp+0x110]
   617e4:	test   r13d,r13d
   617e7:	je     6181d <sqlite3VdbeExec+0x1237d>
   617e9:	cmp    r13d,0x5
   617ed:	je     6180f <sqlite3VdbeExec+0x1236f>
   617ef:	mov    QWORD PTR [rsp+0x148],rbp
   617f7:	mov    rbp,r13
   617fa:	mov    r13,QWORD PTR [rsp+0x130]
   61802:	mov    rbx,QWORD PTR [rsp+0x158]
   6180a:	jmp    4f712 <sqlite3VdbeExec+0x272>
   6180f:	mov    DWORD PTR [rsp+0x3c0],0x1
   6181a:	xor    r13d,r13d
   6181d:	movsxd rax,DWORD PTR [rbp+0xc]
   61821:	imul   rax,rax,0x38
   61825:	lea    r12,[rbx+rax*1]
   61829:	mov    DWORD PTR [rsp+0x38c],r13d
   61831:	mov    r13,r12
   61834:	xor    r12d,r12d
   61837:	jmp    6184c <sqlite3VdbeExec+0x123ac>
   61839:	mov    QWORD PTR [r13+0x0],rax
   6183d:	mov    WORD PTR [r13+0x14],0x4
   61844:	add    r12d,0x1
   61848:	add    r13,0x38
   6184c:	cmp    r12d,0x3
   61850:	jge    61889 <sqlite3VdbeExec+0x123e9>
   61852:	mov    rax,r12
   61855:	movsxd rax,DWORD PTR [rsp+rax*4+0x3c0]
   6185d:	movzx  ecx,WORD PTR [r13+0x14]
   61862:	and    ecx,0x9000
   61868:	test   ecx,ecx
   6186a:	je     61839 <sqlite3VdbeExec+0x12399>
   6186c:	mov    QWORD PTR [rsp+0x110],rdi
   61874:	mov    rdi,r13
   61877:	mov    rsi,rax
   6187a:	call   6187f <sqlite3VdbeExec+0x123df>
   6187f:	mov    rdi,QWORD PTR [rsp+0x110]
   61887:	jmp    61844 <sqlite3VdbeExec+0x123a4>
   61889:	mov    DWORD PTR [rsp+0x37c],r15d
   61891:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   61896:	mov    r15d,DWORD PTR [rsp+0x37c]
   6189e:	mov    r13,QWORD PTR [rsp+0x150]
   618a6:	mov    QWORD PTR [rsp+0x130],r12
   618ae:	mov    r12d,DWORD PTR [rsp+0x394]
   618b6:	mov    rax,QWORD PTR [rdi+0x68]
   618ba:	movsxd rcx,DWORD PTR [rbp+0x8]
   618be:	imul   rcx,rcx,0x38
   618c2:	mov    DWORD PTR [rsp+0x394],r12d
   618ca:	lea    r12,[rax+rcx*1]
   618ce:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   618d3:	and    eax,0x9000
   618d8:	test   eax,eax
   618da:	je     618f9 <sqlite3VdbeExec+0x12459>
   618dc:	mov    QWORD PTR [rsp+0x110],rdi
   618e4:	mov    rdi,r12
   618e7:	call   618ec <sqlite3VdbeExec+0x1244c>
   618ec:	mov    r12,rax
   618ef:	mov    rdi,QWORD PTR [rsp+0x110]
   618f7:	jmp    61901 <sqlite3VdbeExec+0x12461>
   618f9:	mov    WORD PTR [r12+0x14],0x4
   61901:	mov    QWORD PTR [rsp+0x168],r12
   61909:	mov    r12d,DWORD PTR [rbp+0xc]
   6190d:	mov    rax,QWORD PTR [r14+0x20]
   61911:	movsxd rcx,DWORD PTR [rbp+0x4]
   61915:	shl    rcx,0x5
   61919:	mov    QWORD PTR [rsp+0x150],r13
   61921:	mov    r13,QWORD PTR [rax+rcx*1+0x8]
   61926:	mov    rax,QWORD PTR [r13+0x8]
   6192a:	mov    rax,QWORD PTR [rax]
   6192d:	mov    QWORD PTR [rsp+0x190],r13
   61935:	mov    r13,rax
   61938:	movzx  eax,BYTE PTR [r13+0x9]
   6193d:	mov    DWORD PTR [rsp+0x37c],r15d
   61945:	mov    r15d,eax
   61948:	cmp    r12d,0xffffffff
   6194c:	jne    61951 <sqlite3VdbeExec+0x124b1>
   6194e:	mov    r12,r15
   61951:	cmp    BYTE PTR [r13+0x15],0x3
   61956:	jae    6196b <sqlite3VdbeExec+0x124cb>
   61958:	mov    rax,QWORD PTR [r13+0x50]
   6195c:	cmp    QWORD PTR [rax],0x0
   61960:	je     61969 <sqlite3VdbeExec+0x124c9>
   61962:	cmp    QWORD PTR [r13+0x60],0x0
   61967:	jg     6196b <sqlite3VdbeExec+0x124cb>
   61969:	jmp    6196e <sqlite3VdbeExec+0x124ce>
   6196b:	mov    r12,r15
   6196e:	cmp    BYTE PTR [r13+0x13],0x0
   61973:	jne    61982 <sqlite3VdbeExec+0x124e2>
   61975:	lea    rax,[rip+0x0]        # 6197c <sqlite3VdbeExec+0x124dc>
   6197c:	cmp    rax,QWORD PTR [r13+0x0]
   61980:	jne    6198b <sqlite3VdbeExec+0x124eb>
   61982:	lea    rax,[rip+0x0]        # 61989 <sqlite3VdbeExec+0x124e9>
   61989:	jmp    61992 <sqlite3VdbeExec+0x124f2>
   6198b:	mov    rax,QWORD PTR [r13+0xd8]
   61992:	cmp    r12d,0x5
   61996:	jne    619f4 <sqlite3VdbeExec+0x12554>
   61998:	test   rax,rax
   6199b:	je     619f1 <sqlite3VdbeExec+0x12551>
   6199d:	mov    QWORD PTR [rsp+0x110],rdi
   619a5:	mov    rdi,rax
   619a8:	call   619ad <sqlite3VdbeExec+0x1250d>
   619ad:	and    eax,0x3fffffff
   619b2:	mov    rdi,QWORD PTR [rsp+0x110]
   619ba:	test   eax,eax
   619bc:	je     619f1 <sqlite3VdbeExec+0x12551>
   619be:	mov    rax,QWORD PTR [r13+0x48]
   619c2:	mov    rax,QWORD PTR [rax]
   619c5:	cmp    BYTE PTR [r13+0x11],0x0
   619ca:	jne    619f1 <sqlite3VdbeExec+0x12551>
   619cc:	cmp    BYTE PTR [r13+0x8],0x0
   619d1:	jne    61a5b <sqlite3VdbeExec+0x125bb>
   619d7:	cmp    DWORD PTR [rax],0x2
   619da:	jl     619eb <sqlite3VdbeExec+0x1254b>
   619dc:	cmp    QWORD PTR [rax+0x68],0x0
   619e1:	mov    eax,0x0
   619e6:	setne  al
   619e9:	jmp    619ed <sqlite3VdbeExec+0x1254d>
   619eb:	xor    eax,eax
   619ed:	test   eax,eax
   619ef:	jne    619f4 <sqlite3VdbeExec+0x12554>
   619f1:	mov    r12,r15
   619f4:	cmp    r12d,r15d
   619f7:	jne    61a0e <sqlite3VdbeExec+0x1256e>
   619f9:	mov    DWORD PTR [rsp+0x39c],r15d
   61a01:	mov    r15d,DWORD PTR [rsp+0x38c]
   61a09:	jmp    61f89 <sqlite3VdbeExec+0x12ae9>
   61a0e:	cmp    r15d,0x5
   61a12:	je     61a2f <sqlite3VdbeExec+0x1258f>
   61a14:	cmp    r12d,0x5
   61a18:	je     61a2f <sqlite3VdbeExec+0x1258f>
   61a1a:	mov    DWORD PTR [rsp+0x39c],r15d
   61a22:	mov    r15d,DWORD PTR [rsp+0x38c]
   61a2a:	jmp    61f89 <sqlite3VdbeExec+0x12ae9>
   61a2f:	cmp    BYTE PTR [r14+0x65],0x0
   61a34:	je     61a40 <sqlite3VdbeExec+0x125a0>
   61a36:	cmp    DWORD PTR [r14+0xd4],0x1
   61a3e:	jle    61aa1 <sqlite3VdbeExec+0x12601>
   61a40:	mov    ebx,0x1
   61a45:	lea    rax,[rip+0x0]        # 61a4c <sqlite3VdbeExec+0x125ac>
   61a4c:	cmp    r12d,0x5
   61a50:	jne    61a5d <sqlite3VdbeExec+0x125bd>
   61a52:	lea    rcx,[rip+0x0]        # 61a59 <sqlite3VdbeExec+0x125b9>
   61a59:	jmp    61a64 <sqlite3VdbeExec+0x125c4>
   61a5b:	jmp    619f4 <sqlite3VdbeExec+0x12554>
   61a5d:	lea    rcx,[rip+0x0]        # 61a64 <sqlite3VdbeExec+0x125c4>
   61a64:	mov    QWORD PTR [rsp+0x110],rdi
   61a6c:	mov    rsi,rax
   61a6f:	mov    rdx,rcx
   61a72:	xor    eax,eax
   61a74:	call   61a79 <sqlite3VdbeExec+0x125d9>
   61a79:	mov    rdi,QWORD PTR [rsp+0x110]
   61a81:	mov    QWORD PTR [rsp+0x148],rbp
   61a89:	mov    rbp,rbx
   61a8c:	mov    r13,QWORD PTR [rsp+0x130]
   61a94:	mov    rbx,QWORD PTR [rsp+0x158]
   61a9c:	jmp    4f712 <sqlite3VdbeExec+0x272>
   61aa1:	cmp    r15d,0x5
   61aa5:	jne    61ea2 <sqlite3VdbeExec+0x12a02>
   61aab:	xor    eax,eax
   61aad:	cmp    QWORD PTR [r13+0x128],0x0
   61ab5:	je     61ac4 <sqlite3VdbeExec+0x12624>
   61ab7:	mov    DWORD PTR [rsp+0x3a4],r12d
   61abf:	jmp    61b91 <sqlite3VdbeExec+0x126f1>
   61ac4:	mov    DWORD PTR [rsp+0x3a4],r12d
   61acc:	lea    r12,[rsp+0x398]
   61ad4:	mov    DWORD PTR [r12],0x0
   61adc:	mov    eax,0x1
   61ae1:	cmp    BYTE PTR [r13+0x16],0x1
   61ae6:	jb     61aef <sqlite3VdbeExec+0x1264f>
   61ae8:	cmp    BYTE PTR [r13+0x16],0x5
   61aed:	jne    61b38 <sqlite3VdbeExec+0x12698>
   61aef:	cmp    BYTE PTR [r13+0x11],0x0
   61af4:	je     61afa <sqlite3VdbeExec+0x1265a>
   61af6:	xor    eax,eax
   61af8:	jmp    61b21 <sqlite3VdbeExec+0x12681>
   61afa:	mov    rcx,QWORD PTR [r13+0x48]
   61afe:	mov    rdx,QWORD PTR [rcx]
   61b01:	mov    rdx,QWORD PTR [rdx+0x38]
   61b05:	mov    QWORD PTR [rsp+0x110],rdi
   61b0d:	mov    rdi,rcx
   61b10:	mov    rsi,rax
   61b13:	mov    r10,rdx
   61b16:	call   r10
   61b19:	mov    rdi,QWORD PTR [rsp+0x110]
   61b21:	test   eax,eax
   61b23:	jne    61bf5 <sqlite3VdbeExec+0x12755>
   61b29:	cmp    BYTE PTR [r13+0x16],0x5
   61b2e:	jne    61be3 <sqlite3VdbeExec+0x12743>
   61b34:	test   eax,eax
   61b36:	jne    61b6e <sqlite3VdbeExec+0x126ce>
   61b38:	mov    rax,QWORD PTR [r13+0x0]
   61b3c:	mov    rcx,QWORD PTR [r13+0x130]
   61b43:	xor    edx,edx
   61b45:	mov    rsi,r12
   61b48:	mov    r8,QWORD PTR [rax+0x38]
   61b4c:	mov    QWORD PTR [rsp+0x110],rdi
   61b54:	mov    rdi,rax
   61b57:	mov    r10,r8
   61b5a:	mov    r11,rsi
   61b5d:	mov    rsi,rcx
   61b60:	mov    rcx,r11
   61b63:	call   r10
   61b66:	mov    rdi,QWORD PTR [rsp+0x110]
   61b6e:	test   eax,eax
   61b70:	jne    61b91 <sqlite3VdbeExec+0x126f1>
   61b72:	cmp    DWORD PTR [r12],0x0
   61b77:	je     61b91 <sqlite3VdbeExec+0x126f1>
   61b79:	mov    QWORD PTR [rsp+0x110],rdi
   61b81:	mov    rdi,r13
   61b84:	call   61b89 <sqlite3VdbeExec+0x126e9>
   61b89:	mov    rdi,QWORD PTR [rsp+0x110]
   61b91:	test   eax,eax
   61b93:	je     61ba2 <sqlite3VdbeExec+0x12702>
   61b95:	mov    r12d,DWORD PTR [rsp+0x3a4]
   61b9d:	jmp    61e5a <sqlite3VdbeExec+0x129ba>
   61ba2:	cmp    QWORD PTR [r13+0x128],0x0
   61baa:	jne    61bb9 <sqlite3VdbeExec+0x12719>
   61bac:	mov    r12d,DWORD PTR [rsp+0x3a4]
   61bb4:	jmp    61e5a <sqlite3VdbeExec+0x129ba>
   61bb9:	movzx  r12d,BYTE PTR [r13+0x16]
   61bbe:	mov    eax,0x4
   61bc3:	xor    ecx,ecx
   61bc5:	cmp    BYTE PTR [r13+0x16],0x4
   61bca:	jb     61bd8 <sqlite3VdbeExec+0x12738>
   61bcc:	cmp    BYTE PTR [r13+0x16],0x5
   61bd1:	je     61bd8 <sqlite3VdbeExec+0x12738>
   61bd3:	mov    rax,rcx
   61bd6:	jmp    61c37 <sqlite3VdbeExec+0x12797>
   61bd8:	cmp    BYTE PTR [r13+0x11],0x0
   61bdd:	je     61c02 <sqlite3VdbeExec+0x12762>
   61bdf:	xor    eax,eax
   61be1:	jmp    61c29 <sqlite3VdbeExec+0x12789>
   61be3:	mov    BYTE PTR [r13+0x16],0x1
   61be8:	test   eax,eax
   61bea:	je     61b38 <sqlite3VdbeExec+0x12698>
   61bf0:	jmp    61b6e <sqlite3VdbeExec+0x126ce>
   61bf5:	test   eax,eax
   61bf7:	je     61b38 <sqlite3VdbeExec+0x12698>
   61bfd:	jmp    61b6e <sqlite3VdbeExec+0x126ce>
   61c02:	mov    rcx,QWORD PTR [r13+0x48]
   61c06:	mov    rdx,QWORD PTR [rcx]
   61c09:	mov    rdx,QWORD PTR [rdx+0x38]
   61c0d:	mov    QWORD PTR [rsp+0x110],rdi
   61c15:	mov    rdi,rcx
   61c18:	mov    rsi,rax
   61c1b:	mov    r10,rdx
   61c1e:	call   r10
   61c21:	mov    rdi,QWORD PTR [rsp+0x110]
   61c29:	test   eax,eax
   61c2b:	jne    61c37 <sqlite3VdbeExec+0x12797>
   61c2d:	movzx  ecx,BYTE PTR [r13+0x16]
   61c32:	mov    BYTE PTR [r13+0x16],0x4
   61c37:	mov    DWORD PTR [rsp+0x39c],r15d
   61c3f:	mov    r15d,eax
   61c42:	test   r15d,r15d
   61c45:	je     61c93 <sqlite3VdbeExec+0x127f3>
   61c47:	mov    rax,QWORD PTR [r13+0x48]
   61c4b:	cmp    QWORD PTR [rax],0x0
   61c4f:	je     61c8a <sqlite3VdbeExec+0x127ea>
   61c51:	cmp    BYTE PTR [r13+0x11],0x0
   61c56:	jne    61c7f <sqlite3VdbeExec+0x127df>
   61c58:	mov    rax,QWORD PTR [r13+0x48]
   61c5c:	mov    rcx,QWORD PTR [rax]
   61c5f:	mov    rcx,QWORD PTR [rcx+0x40]
   61c63:	mov    QWORD PTR [rsp+0x110],rdi
   61c6b:	mov    rdi,rax
   61c6e:	mov    rsi,r12
   61c71:	mov    r10,rcx
   61c74:	call   r10
   61c77:	mov    rdi,QWORD PTR [rsp+0x110]
   61c7f:	cmp    BYTE PTR [r13+0x16],0x5
   61c84:	je     61c8a <sqlite3VdbeExec+0x127ea>
   61c86:	mov    BYTE PTR [r13+0x16],r12b
   61c8a:	movzx  eax,BYTE PTR [r13+0x10]
   61c8f:	mov    BYTE PTR [r13+0x17],al
   61c93:	mov    eax,r15d
   61c96:	test   eax,eax
   61c98:	je     61caf <sqlite3VdbeExec+0x1280f>
   61c9a:	mov    r15d,DWORD PTR [rsp+0x39c]
   61ca2:	mov    r12d,DWORD PTR [rsp+0x3a4]
   61caa:	jmp    61e5a <sqlite3VdbeExec+0x129ba>
   61caf:	mov    rax,QWORD PTR [r13+0x128]
   61cb6:	movzx  ecx,BYTE PTR [r13+0xf]
   61cbb:	mov    rdx,QWORD PTR [r13+0xc8]
   61cc2:	mov    rsi,QWORD PTR [r13+0x118]
   61cc9:	mov    QWORD PTR [rsp+0x110],rdi
   61cd1:	mov    rdi,rax
   61cd4:	mov    r8,rsi
   61cd7:	mov    rsi,r14
   61cda:	mov    r11,rdx
   61cdd:	mov    rdx,rcx
   61ce0:	mov    rcx,r11
   61ce3:	call   61ce8 <sqlite3VdbeExec+0x12848>
   61ce8:	mov    QWORD PTR [r13+0x128],0x0
   61cf3:	lea    rcx,[rsp+0x180]
   61cfb:	mov    rdx,QWORD PTR [r13+0x48]
   61cff:	mov    rdi,QWORD PTR [rsp+0x110]
   61d07:	cmp    QWORD PTR [rdx],0x0
   61d0b:	je     61db4 <sqlite3VdbeExec+0x12914>
   61d11:	mov    rdx,QWORD PTR [rdx]
   61d14:	cmp    DWORD PTR [rdx],0x3
   61d17:	jl     61db4 <sqlite3VdbeExec+0x12914>
   61d1d:	mov    rdx,QWORD PTR [r13+0xa0]
   61d24:	mov    QWORD PTR [rcx],rdx
   61d27:	xor    edx,edx
   61d29:	cmp    QWORD PTR [rcx],0x0
   61d2d:	setg   dl
   61d30:	mov    BYTE PTR [r13+0x1b],dl
   61d34:	cmp    DWORD PTR [r13+0x30],0x0
   61d39:	je     61d4b <sqlite3VdbeExec+0x128ab>
   61d3b:	lea    rdx,[rip+0x0]        # 61d42 <sqlite3VdbeExec+0x128a2>
   61d42:	mov    QWORD PTR [r13+0x110],rdx
   61d49:	jmp    61d70 <sqlite3VdbeExec+0x128d0>
   61d4b:	cmp    BYTE PTR [r13+0x1b],0x0
   61d50:	je     61d62 <sqlite3VdbeExec+0x128c2>
   61d52:	lea    rdx,[rip+0x0]        # 61d59 <sqlite3VdbeExec+0x128b9>
   61d59:	mov    QWORD PTR [r13+0x110],rdx
   61d60:	jmp    61d70 <sqlite3VdbeExec+0x128d0>
   61d62:	lea    rdx,[rip+0x0]        # 61d69 <sqlite3VdbeExec+0x128c9>
   61d69:	mov    QWORD PTR [r13+0x110],rdx
   61d70:	mov    rdx,QWORD PTR [r13+0x48]
   61d74:	mov    esi,0x12
   61d79:	cmp    QWORD PTR [rdx],0x0
   61d7d:	je     61db4 <sqlite3VdbeExec+0x12914>
   61d7f:	mov    r8,QWORD PTR [rdx]
   61d82:	mov    r8,QWORD PTR [r8+0x50]
   61d86:	mov    QWORD PTR [rsp+0x108],rax
   61d8e:	mov    QWORD PTR [rsp+0x110],rdi
   61d96:	mov    rdi,rdx
   61d99:	mov    rdx,rcx
   61d9c:	mov    r10,r8
   61d9f:	call   r10
   61da2:	mov    ecx,eax
   61da4:	mov    rax,QWORD PTR [rsp+0x108]
   61dac:	mov    rdi,QWORD PTR [rsp+0x110]
   61db4:	test   eax,eax
   61db6:	jne    61dcd <sqlite3VdbeExec+0x1292d>
   61db8:	mov    r15d,DWORD PTR [rsp+0x39c]
   61dc0:	mov    r12d,DWORD PTR [rsp+0x3a4]
   61dc8:	jmp    61e5a <sqlite3VdbeExec+0x129ba>
   61dcd:	cmp    BYTE PTR [r13+0x8],0x0
   61dd2:	je     61de6 <sqlite3VdbeExec+0x12946>
   61dd4:	mov    r15d,DWORD PTR [rsp+0x39c]
   61ddc:	mov    r12d,DWORD PTR [rsp+0x3a4]
   61de4:	jmp    61e5a <sqlite3VdbeExec+0x129ba>
   61de6:	mov    ecx,0x1
   61deb:	mov    rdx,QWORD PTR [r13+0x48]
   61def:	cmp    QWORD PTR [rdx],0x0
   61df3:	je     61e41 <sqlite3VdbeExec+0x129a1>
   61df5:	cmp    BYTE PTR [r13+0x11],0x0
   61dfa:	jne    61e35 <sqlite3VdbeExec+0x12995>
   61dfc:	mov    rdx,QWORD PTR [r13+0x48]
   61e00:	mov    rsi,QWORD PTR [rdx]
   61e03:	mov    rsi,QWORD PTR [rsi+0x40]
   61e07:	mov    QWORD PTR [rsp+0x108],rax
   61e0f:	mov    QWORD PTR [rsp+0x110],rdi
   61e17:	mov    rdi,rdx
   61e1a:	mov    r10,rsi
   61e1d:	mov    rsi,rcx
   61e20:	call   r10
   61e23:	mov    ecx,eax
   61e25:	mov    rax,QWORD PTR [rsp+0x108]
   61e2d:	mov    rdi,QWORD PTR [rsp+0x110]
   61e35:	cmp    BYTE PTR [r13+0x16],0x5
   61e3a:	je     61e41 <sqlite3VdbeExec+0x129a1>
   61e3c:	mov    BYTE PTR [r13+0x16],0x1
   61e41:	movzx  ecx,BYTE PTR [r13+0x10]
   61e46:	mov    BYTE PTR [r13+0x17],cl
   61e4a:	mov    r15d,DWORD PTR [rsp+0x39c]
   61e52:	mov    r12d,DWORD PTR [rsp+0x3a4]
   61e5a:	mov    DWORD PTR [rsp+0x39c],r15d
   61e62:	mov    r15d,eax
   61e65:	test   r15d,r15d
   61e68:	jne    61e85 <sqlite3VdbeExec+0x129e5>
   61e6a:	mov    QWORD PTR [rsp+0x110],rdi
   61e72:	mov    rdi,r13
   61e75:	mov    rsi,r12
   61e78:	call   61e7d <sqlite3VdbeExec+0x129dd>
   61e7d:	mov    rdi,QWORD PTR [rsp+0x110]
   61e85:	test   r15d,r15d
   61e88:	jne    61f89 <sqlite3VdbeExec+0x12ae9>
   61e8e:	cmp    r12d,0x5
   61e92:	jne    61f3e <sqlite3VdbeExec+0x12a9e>
   61e98:	mov    eax,0x2
   61e9d:	jmp    61f63 <sqlite3VdbeExec+0x12ac3>
   61ea2:	mov    DWORD PTR [rsp+0x3a4],r12d
   61eaa:	cmp    r15d,0x4
   61eae:	jne    61f07 <sqlite3VdbeExec+0x12a67>
   61eb0:	mov    eax,0x2
   61eb5:	mov    QWORD PTR [rsp+0x110],rdi
   61ebd:	mov    rdi,r13
   61ec0:	mov    rsi,rax
   61ec3:	call   61ec8 <sqlite3VdbeExec+0x12a28>
   61ec8:	mov    rdi,QWORD PTR [rsp+0x110]
   61ed0:	mov    r12d,DWORD PTR [rsp+0x38c]
   61ed8:	test   r12d,r12d
   61edb:	je     61ef5 <sqlite3VdbeExec+0x12a55>
   61edd:	mov    DWORD PTR [rsp+0x39c],r15d
   61ee5:	mov    r15,r12
   61ee8:	mov    r12d,DWORD PTR [rsp+0x3a4]
   61ef0:	jmp    61f89 <sqlite3VdbeExec+0x12ae9>
   61ef5:	mov    DWORD PTR [rsp+0x39c],r15d
   61efd:	mov    r12d,DWORD PTR [rsp+0x3a4]
   61f05:	jmp    61e8e <sqlite3VdbeExec+0x129ee>
   61f07:	mov    r12d,DWORD PTR [rsp+0x38c]
   61f0f:	test   r12d,r12d
   61f12:	je     61f29 <sqlite3VdbeExec+0x12a89>
   61f14:	mov    DWORD PTR [rsp+0x39c],r15d
   61f1c:	mov    r15,r12
   61f1f:	mov    r12d,DWORD PTR [rsp+0x3a4]
   61f27:	jmp    61f89 <sqlite3VdbeExec+0x12ae9>
   61f29:	mov    DWORD PTR [rsp+0x39c],r15d
   61f31:	mov    r12d,DWORD PTR [rsp+0x3a4]
   61f39:	jmp    61e8e <sqlite3VdbeExec+0x129ee>
   61f3e:	mov    r15d,DWORD PTR [rsp+0x39c]
   61f46:	mov    DWORD PTR [rsp+0x3a4],r12d
   61f4e:	mov    eax,0x1
   61f53:	mov    DWORD PTR [rsp+0x39c],r15d
   61f5b:	mov    r12d,DWORD PTR [rsp+0x3a4]
   61f63:	mov    r15,QWORD PTR [rsp+0x190]
   61f6b:	mov    QWORD PTR [rsp+0x110],rdi
   61f73:	mov    rdi,r15
   61f76:	mov    rsi,rax
   61f79:	call   61f7e <sqlite3VdbeExec+0x12ade>
   61f7e:	mov    r15d,eax
   61f81:	mov    rdi,QWORD PTR [rsp+0x110]
   61f89:	test   r15d,r15d
   61f8c:	je     61f96 <sqlite3VdbeExec+0x12af6>
   61f8e:	mov    r12d,DWORD PTR [rsp+0x39c]
   61f96:	mov    QWORD PTR [rsp+0x110],rdi
   61f9e:	mov    rdi,r13
   61fa1:	mov    rsi,r12
   61fa4:	call   61fa9 <sqlite3VdbeExec+0x12b09>
   61fa9:	mov    r12,QWORD PTR [rsp+0x168]
   61fb1:	mov    WORD PTR [r12+0x14],0x2202
   61fb9:	mov    rdi,QWORD PTR [rsp+0x110]
   61fc1:	cmp    eax,0x6
   61fc4:	jne    61fca <sqlite3VdbeExec+0x12b2a>
   61fc6:	xor    eax,eax
   61fc8:	jmp    61fd8 <sqlite3VdbeExec+0x12b38>
   61fca:	lea    rcx,[rip+0x0]        # 61fd1 <sqlite3VdbeExec+0x12b31>
   61fd1:	movsxd rax,eax
   61fd4:	mov    rax,QWORD PTR [rcx+rax*8]
   61fd8:	mov    QWORD PTR [r12+0x8],rax
   61fdd:	mov    rax,QWORD PTR [r12+0x8]
   61fe2:	test   rax,rax
   61fe5:	jne    61feb <sqlite3VdbeExec+0x12b4b>
   61fe7:	xor    eax,eax
   61fe9:	jmp    62008 <sqlite3VdbeExec+0x12b68>
   61feb:	mov    QWORD PTR [rsp+0x110],rdi
   61ff3:	mov    rdi,rax
   61ff6:	call   61ffb <sqlite3VdbeExec+0x12b5b>
   61ffb:	and    eax,0x3fffffff
   62000:	mov    rdi,QWORD PTR [rsp+0x110]
   62008:	mov    DWORD PTR [r12+0x10],eax
   6200d:	mov    BYTE PTR [r12+0x16],0x1
   62013:	mov    r13d,DWORD PTR [rsp+0x37c]
   6201b:	mov    eax,r13d
   6201e:	movzx  ecx,WORD PTR [r12+0x14]
   62024:	and    ecx,0x2
   62027:	test   ecx,ecx
   62029:	jne    62055 <sqlite3VdbeExec+0x12bb5>
   6202b:	mov    BYTE PTR [r12+0x16],al
   62030:	test   r15d,r15d
   62033:	je     62064 <sqlite3VdbeExec+0x12bc4>
   62035:	mov    QWORD PTR [rsp+0x148],rbp
   6203d:	mov    rbp,r15
   62040:	mov    r13,QWORD PTR [rsp+0x130]
   62048:	mov    rbx,QWORD PTR [rsp+0x158]
   62050:	jmp    4f712 <sqlite3VdbeExec+0x272>
   62055:	movzx  ecx,BYTE PTR [r12+0x16]
   6205b:	cmp    ecx,eax
   6205d:	jne    62079 <sqlite3VdbeExec+0x12bd9>
   6205f:	test   r15d,r15d
   62062:	jne    62035 <sqlite3VdbeExec+0x12b95>
   62064:	mov    DWORD PTR [rsp+0x37c],r13d
   6206c:	mov    DWORD PTR [rsp+0x38c],r15d
   62074:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   62079:	mov    QWORD PTR [rsp+0x110],rdi
   62081:	mov    rdi,r12
   62084:	mov    rsi,rax
   62087:	call   6208c <sqlite3VdbeExec+0x12bec>
   6208c:	mov    rdi,QWORD PTR [rsp+0x110]
   62094:	test   r15d,r15d
   62097:	jne    62035 <sqlite3VdbeExec+0x12b95>
   62099:	jmp    62064 <sqlite3VdbeExec+0x12bc4>
   6209b:	mov    r13d,DWORD PTR [rsp+0x37c]
   620a3:	mov    QWORD PTR [rsp+0x130],r12
   620ab:	lea    rax,[rdi+0xa8]
   620b2:	mov    ecx,DWORD PTR [rbp+0x4]
   620b5:	cmp    DWORD PTR [rbp+0x8],0x0
   620b9:	je     620c8 <sqlite3VdbeExec+0x12c28>
   620bb:	movsxd rdx,DWORD PTR [rbp+0x8]
   620bf:	imul   rdx,rdx,0x38
   620c3:	add    rdx,rbx
   620c6:	jmp    620ca <sqlite3VdbeExec+0x12c2a>
   620c8:	xor    edx,edx
   620ca:	mov    QWORD PTR [rsp+0x110],rdi
   620d2:	mov    rdi,rax
   620d5:	mov    rsi,r14
   620d8:	mov    r11,rdx
   620db:	mov    rdx,rcx
   620de:	mov    rcx,r11
   620e1:	call   620e6 <sqlite3VdbeExec+0x12c46>
   620e6:	mov    r12d,eax
   620e9:	mov    rdi,QWORD PTR [rsp+0x110]
   620f1:	test   r12d,r12d
   620f4:	je     62116 <sqlite3VdbeExec+0x12c76>
   620f6:	mov    QWORD PTR [rsp+0x148],rbp
   620fe:	mov    rbp,r12
   62101:	mov    r13,QWORD PTR [rsp+0x130]
   62109:	mov    rbx,QWORD PTR [rsp+0x158]
   62111:	jmp    4f712 <sqlite3VdbeExec+0x272>
   62116:	mov    DWORD PTR [rsp+0x37c],r13d
   6211e:	mov    DWORD PTR [rsp+0x38c],r12d
   62126:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   6212b:	mov    r13d,DWORD PTR [rsp+0x37c]
   62133:	mov    QWORD PTR [rsp+0x130],r12
   6213b:	mov    rax,QWORD PTR [r14+0x20]
   6213f:	movsxd rcx,DWORD PTR [rbp+0x4]
   62143:	shl    rcx,0x5
   62147:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   6214c:	mov    r12,QWORD PTR [rax+0x8]
   62150:	mov    rcx,QWORD PTR [rax+0x8]
   62154:	mov    rax,QWORD PTR [rax]
   62157:	mov    QWORD PTR [rcx+0x8],rax
   6215b:	cmp    BYTE PTR [r12+0x21],0x0
   62161:	jne    6216d <sqlite3VdbeExec+0x12ccd>
   62163:	mov    eax,0x65
   62168:	jmp    6248e <sqlite3VdbeExec+0x12fee>
   6216d:	mov    eax,DWORD PTR [r12+0x40]
   62172:	mov    r15d,eax
   62175:	mov    rax,QWORD PTR [r12+0x18]
   6217a:	mov    rax,QWORD PTR [rax+0x50]
   6217e:	movzx  ecx,BYTE PTR [rax+0x24]
   62182:	shl    ecx,0x18
   62185:	movzx  edx,BYTE PTR [rax+0x25]
   62189:	shl    edx,0x10
   6218c:	or     ecx,edx
   6218e:	movzx  edx,BYTE PTR [rax+0x26]
   62192:	shl    edx,0x8
   62195:	or     ecx,edx
   62197:	movzx  eax,BYTE PTR [rax+0x27]
   6219b:	or     ecx,eax
   6219d:	mov    eax,DWORD PTR [r12+0x38]
   621a2:	mov    edx,0xcccccccd
   621a7:	mul    edx
   621a9:	shr    edx,0x2
   621ac:	mov    esi,edx
   621ae:	mov    r8d,ecx
   621b1:	sub    r8d,r15d
   621b4:	cmp    r15d,0x2
   621b8:	jae    621be <sqlite3VdbeExec+0x12d1e>
   621ba:	xor    eax,eax
   621bc:	jmp    6220c <sqlite3VdbeExec+0x12d6c>
   621be:	mov    eax,DWORD PTR [r12+0x38]
   621c3:	mov    edx,0xcccccccd
   621c8:	mul    edx
   621ca:	shr    edx,0x2
   621cd:	mov    eax,edx
   621cf:	lea    r9d,[rax+0x1]
   621d3:	mov    eax,r15d
   621d6:	sub    eax,0x2
   621d9:	xor    edx,edx
   621db:	div    r9d
   621de:	imul   eax,r9d
   621e2:	lea    r9d,[rax+0x2]
   621e6:	mov    eax,DWORD PTR [rip+0x0]        # 621ec <sqlite3VdbeExec+0x12d4c>
   621ec:	mov    r10d,DWORD PTR [r12+0x34]
   621f1:	xor    edx,edx
   621f3:	div    r10d
   621f6:	add    eax,0x1
   621f9:	xor    edx,edx
   621fb:	mov    r10d,0x1
   62201:	cmp    r9d,eax
   62204:	cmove  edx,r10d
   62208:	lea    eax,[r9+rdx*1]
   6220c:	add    eax,r8d
   6220f:	add    eax,esi
   62211:	xor    edx,edx
   62213:	div    esi
   62215:	mov    edx,r15d
   62218:	sub    edx,ecx
   6221a:	mov    esi,edx
   6221c:	sub    esi,eax
   6221e:	mov    eax,DWORD PTR [rip+0x0]        # 62224 <sqlite3VdbeExec+0x12d84>
   62224:	mov    r8d,DWORD PTR [r12+0x34]
   62229:	xor    edx,edx
   6222b:	div    r8d
   6222e:	add    eax,0x1
   62231:	cmp    r15d,eax
   62234:	jbe    622c4 <sqlite3VdbeExec+0x12e24>
   6223a:	mov    eax,DWORD PTR [rip+0x0]        # 62240 <sqlite3VdbeExec+0x12da0>
   62240:	mov    r8d,DWORD PTR [r12+0x34]
   62245:	xor    edx,edx
   62247:	div    r8d
   6224a:	add    eax,0x1
   6224d:	mov    edx,esi
   6224f:	sub    edx,0x1
   62252:	cmp    esi,eax
   62254:	cmovb  esi,edx
   62257:	jmp    622c4 <sqlite3VdbeExec+0x12e24>
   62259:	mov    eax,DWORD PTR [r12+0x38]
   6225e:	mov    edx,0xcccccccd
   62263:	mul    edx
   62265:	shr    edx,0x2
   62268:	mov    eax,edx
   6226a:	lea    r8d,[rax+0x1]
   6226e:	mov    eax,esi
   62270:	sub    eax,0x2
   62273:	xor    edx,edx
   62275:	div    r8d
   62278:	imul   eax,r8d
   6227c:	lea    r8d,[rax+0x2]
   62280:	mov    eax,DWORD PTR [rip+0x0]        # 62286 <sqlite3VdbeExec+0x12de6>
   62286:	mov    r9d,DWORD PTR [r12+0x34]
   6228b:	xor    edx,edx
   6228d:	div    r9d
   62290:	add    eax,0x1
   62293:	xor    edx,edx
   62295:	mov    r9d,0x1
   6229b:	cmp    r8d,eax
   6229e:	cmove  edx,r9d
   622a2:	lea    eax,[r8+rdx*1]
   622a6:	cmp    eax,esi
   622a8:	je     622c1 <sqlite3VdbeExec+0x12e21>
   622aa:	mov    eax,DWORD PTR [rip+0x0]        # 622b0 <sqlite3VdbeExec+0x12e10>
   622b0:	mov    r8d,DWORD PTR [r12+0x34]
   622b5:	xor    edx,edx
   622b7:	div    r8d
   622ba:	add    eax,0x1
   622bd:	cmp    esi,eax
   622bf:	jne    622d1 <sqlite3VdbeExec+0x12e31>
   622c1:	sub    esi,0x1
   622c4:	cmp    esi,0x2
   622c7:	jae    62259 <sqlite3VdbeExec+0x12db9>
   622c9:	xor    eax,eax
   622cb:	cmp    eax,esi
   622cd:	je     622c1 <sqlite3VdbeExec+0x12e21>
   622cf:	jmp    622aa <sqlite3VdbeExec+0x12e0a>
   622d1:	mov    DWORD PTR [rsp+0x37c],r13d
   622d9:	mov    r13d,esi
   622dc:	cmp    r15d,r13d
   622df:	jb     622e6 <sqlite3VdbeExec+0x12e46>
   622e1:	cmp    ecx,r15d
   622e4:	jb     6231f <sqlite3VdbeExec+0x12e7f>
   622e6:	mov    eax,0x12e03
   622eb:	mov    ecx,0xb
   622f0:	lea    rdx,[rip+0x0]        # 622f7 <sqlite3VdbeExec+0x12e57>
   622f7:	mov    QWORD PTR [rsp+0x110],rdi
   622ff:	mov    rdi,rcx
   62302:	mov    rsi,rax
   62305:	call   6230a <sqlite3VdbeExec+0x12e6a>
   6230a:	mov    rdi,QWORD PTR [rsp+0x110]
   62312:	mov    r13d,DWORD PTR [rsp+0x37c]
   6231a:	jmp    6248e <sqlite3VdbeExec+0x12fee>
   6231f:	test   ecx,ecx
   62321:	jbe    62481 <sqlite3VdbeExec+0x12fe1>
   62327:	xor    eax,eax
   62329:	xor    ecx,ecx
   6232b:	mov    rdx,QWORD PTR [r12+0x10]
   62330:	jmp    6233b <sqlite3VdbeExec+0x12e9b>
   62332:	test   rdx,rdx
   62335:	jne    62340 <sqlite3VdbeExec+0x12ea0>
   62337:	mov    rdx,QWORD PTR [rdx+0x28]
   6233b:	test   rdx,rdx
   6233e:	jne    62332 <sqlite3VdbeExec+0x12e92>
   62340:	test   rdx,rdx
   62343:	je     6236b <sqlite3VdbeExec+0x12ecb>
   62345:	mov    QWORD PTR [rsp+0x110],rdi
   6234d:	mov    rdi,rdx
   62350:	mov    rsi,rax
   62353:	mov    rdx,rcx
   62356:	call   6235b <sqlite3VdbeExec+0x12ebb>
   6235b:	mov    rdi,QWORD PTR [rsp+0x110]
   62363:	test   eax,eax
   62365:	jne    623f3 <sqlite3VdbeExec+0x12f53>
   6236b:	mov    rax,QWORD PTR [r12+0x10]
   62370:	jmp    62380 <sqlite3VdbeExec+0x12ee0>
   62372:	movzx  ecx,BYTE PTR [rax+0x1]
   62376:	and    ecx,0xfffffffb
   62379:	mov    BYTE PTR [rax+0x1],cl
   6237c:	mov    rax,QWORD PTR [rax+0x28]
   62380:	test   rax,rax
   62383:	jne    62372 <sqlite3VdbeExec+0x12ed2>
   62385:	xor    eax,eax
   62387:	mov    QWORD PTR [rsp+0x110],rdi
   6238f:	mov    rdi,r12
   62392:	mov    rsi,r13
   62395:	mov    rdx,r15
   62398:	mov    rcx,rax
   6239b:	call   623a0 <sqlite3VdbeExec+0x12f00>
   623a0:	mov    rdi,QWORD PTR [rsp+0x110]
   623a8:	test   eax,eax
   623aa:	jne    62477 <sqlite3VdbeExec+0x12fd7>
   623b0:	mov    rax,QWORD PTR [r12+0x18]
   623b5:	mov    rax,QWORD PTR [rax+0x70]
   623b9:	mov    rcx,QWORD PTR [rax+0x28]
   623bd:	movzx  edx,WORD PTR [rax+0x34]
   623c1:	and    edx,0x4
   623c4:	test   edx,edx
   623c6:	je     623fd <sqlite3VdbeExec+0x12f5d>
   623c8:	mov    edx,DWORD PTR [rcx+0x20]
   623cb:	cmp    edx,DWORD PTR [rax+0x30]
   623ce:	jb     623fd <sqlite3VdbeExec+0x12f5d>
   623d0:	cmp    DWORD PTR [rcx+0x80],0x0
   623d7:	je     623f9 <sqlite3VdbeExec+0x12f59>
   623d9:	mov    QWORD PTR [rsp+0x110],rdi
   623e1:	mov    rdi,rax
   623e4:	call   623e9 <sqlite3VdbeExec+0x12f49>
   623e9:	mov    rdi,QWORD PTR [rsp+0x110]
   623f1:	jmp    6244b <sqlite3VdbeExec+0x12fab>
   623f3:	test   eax,eax
   623f5:	je     623b0 <sqlite3VdbeExec+0x12f10>
   623f7:	jmp    62477 <sqlite3VdbeExec+0x12fd7>
   623f9:	xor    eax,eax
   623fb:	jmp    6244b <sqlite3VdbeExec+0x12fab>
   623fd:	cmp    DWORD PTR [rcx+0x30],0x0
   62401:	je     62408 <sqlite3VdbeExec+0x12f68>
   62403:	mov    eax,DWORD PTR [rcx+0x30]
   62406:	jmp    6244b <sqlite3VdbeExec+0x12fab>
   62408:	mov    edx,DWORD PTR [rcx+0xb8]
   6240e:	mov    rcx,QWORD PTR [rcx+0xc8]
   62415:	cmp    edx,ecx
   62417:	jbe    62433 <sqlite3VdbeExec+0x12f93>
   62419:	mov    QWORD PTR [rsp+0x110],rdi
   62421:	mov    rdi,rax
   62424:	call   62429 <sqlite3VdbeExec+0x12f89>
   62429:	mov    rdi,QWORD PTR [rsp+0x110]
   62431:	jmp    6244b <sqlite3VdbeExec+0x12fab>
   62433:	mov    QWORD PTR [rsp+0x110],rdi
   6243b:	mov    rdi,rax
   6243e:	call   62443 <sqlite3VdbeExec+0x12fa3>
   62443:	mov    rdi,QWORD PTR [rsp+0x110]
   6244b:	mov    rcx,QWORD PTR [r12+0x18]
   62450:	mov    rcx,QWORD PTR [rcx+0x50]
   62454:	mov    edx,DWORD PTR [r12+0x40]
   62459:	mov    esi,edx
   6245b:	shr    esi,0x18
   6245e:	mov    BYTE PTR [rcx+0x1c],sil
   62462:	mov    esi,edx
   62464:	shr    esi,0x10
   62467:	mov    BYTE PTR [rcx+0x1d],sil
   6246b:	mov    esi,edx
   6246d:	shr    esi,0x8
   62470:	mov    BYTE PTR [rcx+0x1e],sil
   62474:	mov    BYTE PTR [rcx+0x1f],dl
   62477:	mov    r13d,DWORD PTR [rsp+0x37c]
   6247f:	jmp    6248e <sqlite3VdbeExec+0x12fee>
   62481:	mov    eax,0x65
   62486:	mov    r13d,DWORD PTR [rsp+0x37c]
   6248e:	mov    r12d,eax
   62491:	test   r12d,r12d
   62494:	je     624d2 <sqlite3VdbeExec+0x13032>
   62496:	cmp    r12d,0x65
   6249a:	je     624bc <sqlite3VdbeExec+0x1301c>
   6249c:	mov    QWORD PTR [rsp+0x148],rbp
   624a4:	mov    rbp,r12
   624a7:	mov    r13,QWORD PTR [rsp+0x130]
   624af:	mov    rbx,QWORD PTR [rsp+0x158]
   624b7:	jmp    4f712 <sqlite3VdbeExec+0x272>
   624bc:	mov    r12,r14
   624bf:	mov    r15,r13
   624c2:	xor    r11d,r11d
   624c5:	mov    DWORD PTR [rsp+0x38c],r11d
   624cd:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   624d2:	mov    DWORD PTR [rsp+0x37c],r13d
   624da:	mov    DWORD PTR [rsp+0x38c],r12d
   624e2:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   624e7:	mov    r15d,DWORD PTR [rsp+0x37c]
   624ef:	mov    r13,QWORD PTR [rsp+0x150]
   624f7:	mov    QWORD PTR [rsp+0x130],r12
   624ff:	mov    r12d,DWORD PTR [rsp+0x394]
   62507:	cmp    DWORD PTR [rbp+0x4],0x0
   6250b:	jne    6253d <sqlite3VdbeExec+0x1309d>
   6250d:	mov    eax,DWORD PTR [rbp+0x8]
   62510:	mov    rcx,QWORD PTR [r14+0x8]
   62514:	jmp    62536 <sqlite3VdbeExec+0x13096>
   62516:	lea    edx,[rax+0x1]
   62519:	and    rdx,0x3
   6251d:	movzx  esi,WORD PTR [rcx+0xc8]
   62524:	and    rsi,0xfffffffffffffffc
   62528:	or     rsi,rdx
   6252b:	mov    WORD PTR [rcx+0xc8],si
   62532:	mov    rcx,QWORD PTR [rcx+0x10]
   62536:	test   rcx,rcx
   62539:	jne    62516 <sqlite3VdbeExec+0x13076>
   6253b:	jmp    6255c <sqlite3VdbeExec+0x130bc>
   6253d:	mov    eax,DWORD PTR [rbp+0x8]
   62540:	add    eax,0x1
   62543:	and    rax,0x3
   62547:	movzx  ecx,WORD PTR [rdi+0xc8]
   6254e:	and    rcx,0xfffffffffffffffc
   62552:	or     rcx,rax
   62555:	mov    WORD PTR [rdi+0xc8],cx
   6255c:	mov    DWORD PTR [rsp+0x37c],r15d
   62564:	mov    QWORD PTR [rsp+0x150],r13
   6256c:	mov    DWORD PTR [rsp+0x394],r12d
   62574:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   62579:	mov    r15d,DWORD PTR [rsp+0x37c]
   62581:	mov    r13,QWORD PTR [rsp+0x150]
   62589:	mov    QWORD PTR [rsp+0x130],r12
   62591:	mov    r12d,DWORD PTR [rsp+0x394]
   62599:	mov    rax,QWORD PTR [rdi+0x78]
   6259d:	movsxd rcx,DWORD PTR [rbp+0x4]
   625a1:	mov    rax,QWORD PTR [rax+rcx*8]
   625a5:	mov    rax,QWORD PTR [rax+0x28]
   625a9:	movzx  ecx,BYTE PTR [rax+0x1]
   625ad:	or     ecx,0x40
   625b0:	mov    BYTE PTR [rax+0x1],cl
   625b3:	mov    DWORD PTR [rsp+0x37c],r15d
   625bb:	mov    QWORD PTR [rsp+0x150],r13
   625c3:	mov    DWORD PTR [rsp+0x394],r12d
   625cb:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   625d0:	mov    r15d,DWORD PTR [rsp+0x37c]
   625d8:	mov    r13,QWORD PTR [rsp+0x150]
   625e0:	mov    QWORD PTR [rsp+0x130],r12
   625e8:	mov    r12d,DWORD PTR [rsp+0x394]
   625f0:	mov    rax,QWORD PTR [rdi+0x78]
   625f4:	movsxd rcx,DWORD PTR [rbp+0x4]
   625f8:	mov    rax,QWORD PTR [rax+rcx*8]
   625fc:	mov    rax,QWORD PTR [rax+0x28]
   62600:	movzx  ecx,BYTE PTR [rax+0x1]
   62604:	and    ecx,0xffffffbf
   62607:	mov    BYTE PTR [rax+0x1],cl
   6260a:	mov    DWORD PTR [rsp+0x37c],r15d
   62612:	mov    QWORD PTR [rsp+0x150],r13
   6261a:	mov    DWORD PTR [rsp+0x394],r12d
   62622:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   62627:	mov    r15d,DWORD PTR [rsp+0x37c]
   6262f:	mov    r13,QWORD PTR [rsp+0x150]
   62637:	mov    QWORD PTR [rsp+0x130],r12
   6263f:	mov    r12d,DWORD PTR [rsp+0x394]
   62647:	mov    eax,DWORD PTR [rbp+0xc]
   6264a:	movzx  eax,al
   6264d:	mov    ecx,eax
   6264f:	test   ecx,ecx
   62651:	jne    62685 <sqlite3VdbeExec+0x131e5>
   62653:	xor    ecx,ecx
   62655:	movabs rdx,0x400000000
   6265f:	and    rdx,QWORD PTR [r14+0x30]
   62663:	cmp    rcx,rdx
   62666:	je     62685 <sqlite3VdbeExec+0x131e5>
   62668:	mov    QWORD PTR [rsp+0x150],r13
   62670:	mov    DWORD PTR [rsp+0x394],r12d
   62678:	mov    r12d,DWORD PTR [rsp+0x38c]
   62680:	jmp    628c2 <sqlite3VdbeExec+0x13422>
   62685:	movsxd rcx,DWORD PTR [rbp+0x4]
   62689:	mov    rdx,QWORD PTR [r14+0x20]
   6268d:	shl    rcx,0x5
   62691:	mov    DWORD PTR [rsp+0x394],r12d
   62699:	mov    r12,QWORD PTR [rdx+rcx*1+0x8]
   6269e:	mov    QWORD PTR [rsp+0x150],r13
   626a6:	mov    r13d,DWORD PTR [rbp+0x8]
   626aa:	xor    ecx,ecx
   626ac:	cmp    BYTE PTR [r12+0x11],0x0
   626b2:	je     62865 <sqlite3VdbeExec+0x133c5>
   626b8:	mov    ecx,0x1
   626bd:	add    cl,al
   626bf:	mov    rax,QWORD PTR [r12+0x8]
   626c4:	mov    rdx,QWORD PTR [r12]
   626c8:	mov    QWORD PTR [rax+0x8],rdx
   626cc:	mov    eax,ecx
   626ce:	mov    rdx,QWORD PTR [r12+0x8]
   626d3:	cmp    BYTE PTR [r12+0x11],0x0
   626d9:	je     62742 <sqlite3VdbeExec+0x132a2>
   626db:	cmp    r12,QWORD PTR [rdx+0x80]
   626e2:	je     626fc <sqlite3VdbeExec+0x1325c>
   626e4:	movzx  esi,WORD PTR [rdx+0x28]
   626e8:	and    esi,0x40
   626eb:	test   esi,esi
   626ed:	je     626fc <sqlite3VdbeExec+0x1325c>
   626ef:	mov    eax,0x106
   626f4:	mov    rcx,rax
   626f7:	jmp    62865 <sqlite3VdbeExec+0x133c5>
   626fc:	mov    rsi,QWORD PTR [rdx+0x78]
   62700:	jmp    62706 <sqlite3VdbeExec+0x13266>
   62702:	mov    rsi,QWORD PTR [rsi+0x10]
   62706:	test   rsi,rsi
   62709:	je     62742 <sqlite3VdbeExec+0x132a2>
   6270b:	cmp    r12,QWORD PTR [rsi]
   6270e:	je     62702 <sqlite3VdbeExec+0x13262>
   62710:	cmp    r13d,DWORD PTR [rsi+0x8]
   62714:	jne    62702 <sqlite3VdbeExec+0x13262>
   62716:	movzx  r8d,BYTE PTR [rsi+0xc]
   6271b:	mov    r9d,eax
   6271e:	cmp    r8d,r9d
   62721:	je     62702 <sqlite3VdbeExec+0x13262>
   62723:	cmp    eax,0x2
   62726:	jne    62735 <sqlite3VdbeExec+0x13295>
   62728:	movzx  eax,WORD PTR [rdx+0x28]
   6272c:	or     eax,0x80
   62731:	mov    WORD PTR [rdx+0x28],ax
   62735:	mov    eax,0x106
   6273a:	mov    rcx,rax
   6273d:	jmp    62865 <sqlite3VdbeExec+0x133c5>
   62742:	mov    DWORD PTR [rsp+0x39c],r13d
   6274a:	mov    r13d,ecx
   6274d:	mov    DWORD PTR [rsp+0x3a4],r13d
   62755:	mov    r13,QWORD PTR [r12+0x8]
   6275a:	mov    rax,QWORD PTR [r13+0x78]
   6275e:	jmp    62764 <sqlite3VdbeExec+0x132c4>
   62760:	mov    rax,QWORD PTR [rax+0x10]
   62764:	test   rax,rax
   62767:	jne    6277b <sqlite3VdbeExec+0x132db>
   62769:	mov    DWORD PTR [rsp+0x37c],r15d
   62771:	mov    r15d,DWORD PTR [rsp+0x39c]
   62779:	jmp    627c4 <sqlite3VdbeExec+0x13324>
   6277b:	mov    DWORD PTR [rsp+0x37c],r15d
   62783:	mov    r15d,DWORD PTR [rsp+0x39c]
   6278b:	cmp    r15d,DWORD PTR [rax+0x8]
   6278f:	je     6279b <sqlite3VdbeExec+0x132fb>
   62791:	mov    r15d,DWORD PTR [rsp+0x37c]
   62799:	jmp    62760 <sqlite3VdbeExec+0x132c0>
   6279b:	cmp    r12,QWORD PTR [rax]
   6279e:	je     627b2 <sqlite3VdbeExec+0x13312>
   627a0:	mov    DWORD PTR [rsp+0x39c],r15d
   627a8:	mov    r15d,DWORD PTR [rsp+0x37c]
   627b0:	jmp    62760 <sqlite3VdbeExec+0x132c0>
   627b2:	test   rax,rax
   627b5:	je     627c4 <sqlite3VdbeExec+0x13324>
   627b7:	mov    r13d,DWORD PTR [rsp+0x3a4]
   627bf:	jmp    62849 <sqlite3VdbeExec+0x133a9>
   627c4:	mov    DWORD PTR [rsp+0x39c],r15d
   627cc:	mov    r15d,0x18
   627d2:	mov    QWORD PTR [rsp+0x110],rdi
   627da:	mov    rdi,r15
   627dd:	call   627e2 <sqlite3VdbeExec+0x13342>
   627e2:	mov    rdi,QWORD PTR [rsp+0x110]
   627ea:	test   rax,rax
   627ed:	je     6281a <sqlite3VdbeExec+0x1337a>
   627ef:	xor    ecx,ecx
   627f1:	mov    QWORD PTR [rsp+0x108],rax
   627f9:	mov    rdi,rax
   627fc:	mov    rsi,rcx
   627ff:	mov    rdx,r15
   62802:	call   62807 <sqlite3VdbeExec+0x13367>
   62807:	mov    rcx,rax
   6280a:	mov    rax,QWORD PTR [rsp+0x108]
   62812:	mov    rdi,QWORD PTR [rsp+0x110]
   6281a:	test   rax,rax
   6281d:	jne    62826 <sqlite3VdbeExec+0x13386>
   6281f:	mov    eax,0x7
   62824:	jmp    6285a <sqlite3VdbeExec+0x133ba>
   62826:	mov    r15d,DWORD PTR [rsp+0x39c]
   6282e:	mov    DWORD PTR [rax+0x8],r15d
   62832:	mov    QWORD PTR [rax],r12
   62835:	mov    rcx,QWORD PTR [r13+0x78]
   62839:	mov    QWORD PTR [rax+0x10],rcx
   6283d:	mov    QWORD PTR [r13+0x78],rax
   62841:	mov    r13d,DWORD PTR [rsp+0x3a4]
   62849:	mov    ecx,r13d
   6284c:	movzx  edx,BYTE PTR [rax+0xc]
   62850:	cmp    ecx,edx
   62852:	jle    62858 <sqlite3VdbeExec+0x133b8>
   62854:	mov    BYTE PTR [rax+0xc],r13b
   62858:	xor    eax,eax
   6285a:	mov    r15d,DWORD PTR [rsp+0x37c]
   62862:	mov    rcx,rax
   62865:	mov    r12d,ecx
   62868:	test   r12d,r12d
   6286b:	je     628c2 <sqlite3VdbeExec+0x13422>
   6286d:	mov    eax,r12d
   62870:	and    eax,0xff
   62875:	cmp    eax,0x6
   62878:	jne    628a2 <sqlite3VdbeExec+0x13402>
   6287a:	mov    rax,QWORD PTR [rbp+0x10]
   6287e:	lea    rcx,[rip+0x0]        # 62885 <sqlite3VdbeExec+0x133e5>
   62885:	mov    QWORD PTR [rsp+0x110],rdi
   6288d:	mov    rsi,rcx
   62890:	mov    rdx,rax
   62893:	xor    eax,eax
   62895:	call   6289a <sqlite3VdbeExec+0x133fa>
   6289a:	mov    rdi,QWORD PTR [rsp+0x110]
   628a2:	mov    QWORD PTR [rsp+0x148],rbp
   628aa:	mov    rbp,r12
   628ad:	mov    r13,QWORD PTR [rsp+0x130]
   628b5:	mov    rbx,QWORD PTR [rsp+0x158]
   628bd:	jmp    4f712 <sqlite3VdbeExec+0x272>
   628c2:	mov    DWORD PTR [rsp+0x37c],r15d
   628ca:	mov    DWORD PTR [rsp+0x38c],r12d
   628d2:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   628d7:	mov    r15d,DWORD PTR [rsp+0x37c]
   628df:	mov    QWORD PTR [rsp+0x130],r12
   628e7:	mov    r12,QWORD PTR [rbp+0x10]
   628eb:	xor    r13d,r13d
   628ee:	cmp    DWORD PTR [r14+0x21c],0x0
   628f6:	jle    62915 <sqlite3VdbeExec+0x13475>
   628f8:	cmp    QWORD PTR [r14+0x240],0x0
   62900:	jne    62915 <sqlite3VdbeExec+0x13475>
   62902:	mov    r13d,0x6
   62908:	mov    DWORD PTR [rsp+0x3a4],r13d
   62910:	jmp    62b88 <sqlite3VdbeExec+0x136e8>
   62915:	test   r12,r12
   62918:	jne    6292a <sqlite3VdbeExec+0x1348a>
   6291a:	xor    r13d,r13d
   6291d:	mov    DWORD PTR [rsp+0x3a4],r13d
   62925:	jmp    62b88 <sqlite3VdbeExec+0x136e8>
   6292a:	mov    rax,QWORD PTR [r12+0x10]
   6292f:	mov    r13,QWORD PTR [rax]
   62932:	cmp    QWORD PTR [r13+0x70],0x0
   62937:	jne    62949 <sqlite3VdbeExec+0x134a9>
   62939:	xor    r11d,r11d
   6293c:	mov    DWORD PTR [rsp+0x3a4],r11d
   62944:	jmp    62b88 <sqlite3VdbeExec+0x136e8>
   62949:	xor    eax,eax
   6294b:	jmp    62950 <sqlite3VdbeExec+0x134b0>
   6294d:	add    eax,0x1
   62950:	cmp    eax,DWORD PTR [r14+0x21c]
   62957:	jge    62979 <sqlite3VdbeExec+0x134d9>
   62959:	mov    rcx,QWORD PTR [r14+0x240]
   62960:	mov    rdx,rax
   62963:	cmp    r12,QWORD PTR [rcx+rdx*8]
   62967:	jne    6294d <sqlite3VdbeExec+0x134ad>
   62969:	xor    r13d,r13d
   6296c:	mov    DWORD PTR [rsp+0x3a4],r13d
   62974:	jmp    62b88 <sqlite3VdbeExec+0x136e8>
   62979:	mov    eax,DWORD PTR [r14+0x21c]
   62980:	mov    r11d,eax
   62983:	mov    eax,0x66666667
   62988:	imul   r11d
   6298b:	sar    edx,0x1
   6298e:	mov    eax,edx
   62990:	shr    eax,0x1f
   62993:	add    edx,eax
   62995:	imul   edx,edx,0x5
   62998:	neg    edx
   6299a:	add    edx,r11d
   6299d:	mov    eax,edx
   6299f:	test   eax,eax
   629a1:	je     629b0 <sqlite3VdbeExec+0x13510>
   629a3:	mov    QWORD PTR [rsp+0x168],r13
   629ab:	jmp    62a95 <sqlite3VdbeExec+0x135f5>
   629b0:	movsxd rax,DWORD PTR [r14+0x21c]
   629b7:	add    rax,0x5
   629bb:	shl    rax,0x3
   629bf:	mov    QWORD PTR [rsp+0x168],r13
   629c7:	mov    r13,QWORD PTR [r14+0x240]
   629ce:	test   r13,r13
   629d1:	jne    629f3 <sqlite3VdbeExec+0x13553>
   629d3:	mov    QWORD PTR [rsp+0x110],rdi
   629db:	mov    rdi,r14
   629de:	mov    rsi,rax
   629e1:	call   629e6 <sqlite3VdbeExec+0x13546>
   629e6:	mov    r13,rax
   629e9:	mov    rdi,QWORD PTR [rsp+0x110]
   629f1:	jmp    62a48 <sqlite3VdbeExec+0x135a8>
   629f3:	cmp    r13,QWORD PTR [r14+0x1e8]
   629fa:	jae    62a27 <sqlite3VdbeExec+0x13587>
   629fc:	cmp    r13,QWORD PTR [r14+0x1d8]
   62a03:	jb     62a0f <sqlite3VdbeExec+0x1356f>
   62a05:	cmp    rax,0x80
   62a0b:	ja     62a27 <sqlite3VdbeExec+0x13587>
   62a0d:	jmp    62a48 <sqlite3VdbeExec+0x135a8>
   62a0f:	cmp    r13,QWORD PTR [r14+0x1e0]
   62a16:	jb     62a27 <sqlite3VdbeExec+0x13587>
   62a18:	movzx  ecx,WORD PTR [r14+0x19e]
   62a20:	cmp    rax,rcx
   62a23:	ja     62a27 <sqlite3VdbeExec+0x13587>
   62a25:	jmp    62a48 <sqlite3VdbeExec+0x135a8>
   62a27:	mov    QWORD PTR [rsp+0x110],rdi
   62a2f:	mov    rdi,r14
   62a32:	mov    rsi,r13
   62a35:	mov    rdx,rax
   62a38:	call   62a3d <sqlite3VdbeExec+0x1359d>
   62a3d:	mov    r13,rax
   62a40:	mov    rdi,QWORD PTR [rsp+0x110]
   62a48:	test   r13,r13
   62a4b:	jne    62a60 <sqlite3VdbeExec+0x135c0>
   62a4d:	mov    r13d,0x7
   62a53:	mov    DWORD PTR [rsp+0x3a4],r13d
   62a5b:	jmp    62b88 <sqlite3VdbeExec+0x136e8>
   62a60:	movsxd rax,DWORD PTR [r14+0x21c]
   62a67:	lea    rax,[r13+rax*8+0x0]
   62a6c:	xor    ecx,ecx
   62a6e:	mov    edx,0x28
   62a73:	mov    QWORD PTR [rsp+0x110],rdi
   62a7b:	mov    rdi,rax
   62a7e:	mov    rsi,rcx
   62a81:	call   62a86 <sqlite3VdbeExec+0x135e6>
   62a86:	mov    QWORD PTR [r14+0x240],r13
   62a8d:	mov    rdi,QWORD PTR [rsp+0x110]
   62a95:	mov    r13,QWORD PTR [rsp+0x168]
   62a9d:	mov    rax,QWORD PTR [r13+0x70]
   62aa1:	mov    rcx,QWORD PTR [r12+0x10]
   62aa6:	mov    DWORD PTR [rsp+0x37c],r15d
   62aae:	mov    QWORD PTR [rsp+0x110],rdi
   62ab6:	mov    rdi,rcx
   62ab9:	mov    r10,rax
   62abc:	call   r10
   62abf:	mov    r15d,eax
   62ac2:	mov    rdi,QWORD PTR [rsp+0x110]
   62aca:	test   r15d,r15d
   62acd:	je     62ae4 <sqlite3VdbeExec+0x13644>
   62acf:	mov    DWORD PTR [rsp+0x3a4],r15d
   62ad7:	mov    r15d,DWORD PTR [rsp+0x37c]
   62adf:	jmp    62b88 <sqlite3VdbeExec+0x136e8>
   62ae4:	mov    eax,DWORD PTR [r14+0x2ec]
   62aeb:	add    eax,DWORD PTR [r14+0x2e8]
   62af2:	mov    rcx,QWORD PTR [r14+0x240]
   62af9:	movsxd rdx,DWORD PTR [r14+0x21c]
   62b00:	lea    esi,[rdx+0x1]
   62b03:	mov    DWORD PTR [r14+0x21c],esi
   62b0a:	mov    QWORD PTR [rcx+rdx*8],r12
   62b0e:	mov    ecx,DWORD PTR [r12+0x18]
   62b13:	add    ecx,0x1
   62b16:	mov    DWORD PTR [r12+0x18],ecx
   62b1b:	test   eax,eax
   62b1d:	jne    62b31 <sqlite3VdbeExec+0x13691>
   62b1f:	mov    DWORD PTR [rsp+0x3a4],r15d
   62b27:	mov    r15d,DWORD PTR [rsp+0x37c]
   62b2f:	jmp    62b88 <sqlite3VdbeExec+0x136e8>
   62b31:	cmp    QWORD PTR [r13+0xa0],0x0
   62b39:	jne    62b4d <sqlite3VdbeExec+0x136ad>
   62b3b:	mov    DWORD PTR [rsp+0x3a4],r15d
   62b43:	mov    r15d,DWORD PTR [rsp+0x37c]
   62b4b:	jmp    62b88 <sqlite3VdbeExec+0x136e8>
   62b4d:	mov    DWORD PTR [r12+0x20],eax
   62b52:	mov    rcx,QWORD PTR [r13+0xa0]
   62b59:	mov    rdx,QWORD PTR [r12+0x10]
   62b5e:	sub    eax,0x1
   62b61:	mov    rdi,rdx
   62b64:	mov    rsi,rax
   62b67:	mov    r10,rcx
   62b6a:	call   r10
   62b6d:	mov    r13d,eax
   62b70:	mov    rdi,QWORD PTR [rsp+0x110]
   62b78:	mov    r15d,DWORD PTR [rsp+0x37c]
   62b80:	mov    DWORD PTR [rsp+0x3a4],r13d
   62b88:	test   r12,r12
   62b8b:	je     62d31 <sqlite3VdbeExec+0x13891>
   62b91:	mov    r12,QWORD PTR [r12+0x10]
   62b96:	cmp    QWORD PTR [r12+0x10],0x0
   62b9c:	je     62d31 <sqlite3VdbeExec+0x13891>
   62ba2:	mov    r13,QWORD PTR [rdi]
   62ba5:	mov    rax,QWORD PTR [rdi+0xa8]
   62bac:	test   rax,rax
   62baf:	je     62bcc <sqlite3VdbeExec+0x1372c>
   62bb1:	mov    QWORD PTR [rsp+0x110],rdi
   62bb9:	mov    rdi,r13
   62bbc:	mov    rsi,rax
   62bbf:	call   62bc4 <sqlite3VdbeExec+0x13724>
   62bc4:	mov    rdi,QWORD PTR [rsp+0x110]
   62bcc:	mov    QWORD PTR [rsp+0x168],r12
   62bd4:	mov    r12,QWORD PTR [r12+0x10]
   62bd9:	test   r12,r12
   62bdc:	jne    62bf1 <sqlite3VdbeExec+0x13751>
   62bde:	xor    r12d,r12d
   62be1:	mov    r13,r12
   62be4:	mov    r12,QWORD PTR [rsp+0x168]
   62bec:	jmp    62c92 <sqlite3VdbeExec+0x137f2>
   62bf1:	mov    QWORD PTR [rsp+0x110],rdi
   62bf9:	mov    rdi,r12
   62bfc:	call   62c01 <sqlite3VdbeExec+0x13761>
   62c01:	mov    QWORD PTR [rsp+0x190],r12
   62c09:	lea    r12,[rax+0x1]
   62c0d:	mov    rdi,QWORD PTR [rsp+0x110]
   62c15:	test   r13,r13
   62c18:	je     62c32 <sqlite3VdbeExec+0x13792>
   62c1a:	mov    rdi,r13
   62c1d:	mov    rsi,r12
   62c20:	call   62c25 <sqlite3VdbeExec+0x13785>
   62c25:	mov    r13,rax
   62c28:	mov    rdi,QWORD PTR [rsp+0x110]
   62c30:	jmp    62c45 <sqlite3VdbeExec+0x137a5>
   62c32:	mov    rdi,r12
   62c35:	call   62c3a <sqlite3VdbeExec+0x1379a>
   62c3a:	mov    r13,rax
   62c3d:	mov    rdi,QWORD PTR [rsp+0x110]
   62c45:	test   r13,r13
   62c48:	jne    62c54 <sqlite3VdbeExec+0x137b4>
   62c4a:	mov    DWORD PTR [rsp+0x37c],r15d
   62c52:	jmp    62c82 <sqlite3VdbeExec+0x137e2>
   62c54:	mov    DWORD PTR [rsp+0x37c],r15d
   62c5c:	mov    r15,QWORD PTR [rsp+0x190]
   62c64:	mov    QWORD PTR [rsp+0x110],rdi
   62c6c:	mov    rdi,r13
   62c6f:	mov    rsi,r15
   62c72:	mov    rdx,r12
   62c75:	call   62c7a <sqlite3VdbeExec+0x137da>
   62c7a:	mov    rdi,QWORD PTR [rsp+0x110]
   62c82:	mov    r15d,DWORD PTR [rsp+0x37c]
   62c8a:	mov    r12,QWORD PTR [rsp+0x168]
   62c92:	mov    QWORD PTR [rdi+0xa8],r13
   62c99:	mov    r13,QWORD PTR [r12+0x10]
   62c9e:	test   r13,r13
   62ca1:	je     62d28 <sqlite3VdbeExec+0x13888>
   62ca7:	cmp    DWORD PTR [rip+0x0],0x0        # 62cae <sqlite3VdbeExec+0x1380e>
   62cae:	je     62d08 <sqlite3VdbeExec+0x13868>
   62cb0:	mov    rax,QWORD PTR [rip+0x0]        # 62cb7 <sqlite3VdbeExec+0x13817>
   62cb7:	mov    QWORD PTR [rsp+0x110],rdi
   62cbf:	mov    rdi,r13
   62cc2:	mov    r10,rax
   62cc5:	call   r10
   62cc8:	mov    rcx,QWORD PTR [rip+0x0]        # 62ccf <sqlite3VdbeExec+0x1382f>
   62ccf:	movsxd rax,eax
   62cd2:	sub    rcx,rax
   62cd5:	mov    QWORD PTR [rip+0x0],rcx        # 62cdc <sqlite3VdbeExec+0x1383c>
   62cdc:	mov    rax,QWORD PTR [rip+0x0]        # 62ce3 <sqlite3VdbeExec+0x13843>
   62ce3:	sub    rax,0x1
   62ce7:	mov    QWORD PTR [rip+0x0],rax        # 62cee <sqlite3VdbeExec+0x1384e>
   62cee:	mov    rax,QWORD PTR [rip+0x0]        # 62cf5 <sqlite3VdbeExec+0x13855>
   62cf5:	mov    rdi,r13
   62cf8:	mov    r10,rax
   62cfb:	call   r10
   62cfe:	mov    rdi,QWORD PTR [rsp+0x110]
   62d06:	jmp    62d28 <sqlite3VdbeExec+0x13888>
   62d08:	mov    rax,QWORD PTR [rip+0x0]        # 62d0f <sqlite3VdbeExec+0x1386f>
   62d0f:	mov    QWORD PTR [rsp+0x110],rdi
   62d17:	mov    rdi,r13
   62d1a:	mov    r10,rax
   62d1d:	call   r10
   62d20:	mov    rdi,QWORD PTR [rsp+0x110]
   62d28:	mov    QWORD PTR [r12+0x10],0x0
   62d31:	mov    r12d,DWORD PTR [rsp+0x3a4]
   62d39:	test   r12d,r12d
   62d3c:	je     62d5e <sqlite3VdbeExec+0x138be>
   62d3e:	mov    QWORD PTR [rsp+0x148],rbp
   62d46:	mov    rbp,r12
   62d49:	mov    r13,QWORD PTR [rsp+0x130]
   62d51:	mov    rbx,QWORD PTR [rsp+0x158]
   62d59:	jmp    4f712 <sqlite3VdbeExec+0x272>
   62d5e:	mov    DWORD PTR [rsp+0x37c],r15d
   62d66:	mov    DWORD PTR [rsp+0x38c],r12d
   62d6e:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   62d73:	mov    r15d,DWORD PTR [rsp+0x37c]
   62d7b:	mov    QWORD PTR [rsp+0x130],r12
   62d83:	lea    r12,[rsp+0x278]
   62d8b:	mov    rax,r12
   62d8e:	xor    ecx,ecx
   62d90:	mov    edx,0x38
   62d95:	mov    QWORD PTR [rsp+0x110],rdi
   62d9d:	mov    rdi,rax
   62da0:	mov    rsi,rcx
   62da3:	call   62da8 <sqlite3VdbeExec+0x13908>
   62da8:	mov    QWORD PTR [rsp+0x290],r14
   62db0:	mov    rax,r12
   62db3:	movsxd rcx,DWORD PTR [rbp+0x8]
   62db7:	imul   rcx,rcx,0x38
   62dbb:	add    rcx,rbx
   62dbe:	mov    rdi,rax
   62dc1:	mov    rsi,rcx
   62dc4:	call   62dc9 <sqlite3VdbeExec+0x13929>
   62dc9:	mov    r13d,eax
   62dcc:	mov    rax,r12
   62dcf:	mov    rdi,QWORD PTR [rsp+0x110]
   62dd7:	test   rax,rax
   62dda:	jne    62de0 <sqlite3VdbeExec+0x13940>
   62ddc:	xor    eax,eax
   62dde:	jmp    62e2d <sqlite3VdbeExec+0x1398d>
   62de0:	movzx  ecx,WORD PTR [rax+0x14]
   62de4:	and    ecx,0x202
   62dea:	cmp    ecx,0x202
   62df0:	jne    62dfe <sqlite3VdbeExec+0x1395e>
   62df2:	cmp    BYTE PTR [rax+0x16],0x1
   62df6:	jne    62dfe <sqlite3VdbeExec+0x1395e>
   62df8:	mov    rax,QWORD PTR [rax+0x8]
   62dfc:	jmp    62e2d <sqlite3VdbeExec+0x1398d>
   62dfe:	movzx  ecx,WORD PTR [rax+0x14]
   62e02:	and    ecx,0x1
   62e05:	test   ecx,ecx
   62e07:	je     62e0d <sqlite3VdbeExec+0x1396d>
   62e09:	xor    eax,eax
   62e0b:	jmp    62e2d <sqlite3VdbeExec+0x1398d>
   62e0d:	mov    ecx,0x1
   62e12:	mov    QWORD PTR [rsp+0x110],rdi
   62e1a:	mov    rdi,rax
   62e1d:	mov    rsi,rcx
   62e20:	call   62e25 <sqlite3VdbeExec+0x13985>
   62e25:	mov    rdi,QWORD PTR [rsp+0x110]
   62e2d:	test   rax,rax
   62e30:	je     63179 <sqlite3VdbeExec+0x13cd9>
   62e36:	movsxd rcx,DWORD PTR [rbp+0x4]
   62e3a:	lea    r13,[rdi+0xa8]
   62e41:	mov    rdx,QWORD PTR [r14+0x20]
   62e45:	shl    rcx,0x5
   62e49:	mov    rcx,QWORD PTR [rdx+rcx*1]
   62e4d:	mov    QWORD PTR [rsp+0x110],rdi
   62e55:	mov    rdi,r14
   62e58:	mov    rsi,rax
   62e5b:	mov    rdx,rcx
   62e5e:	call   62e63 <sqlite3VdbeExec+0x139c3>
   62e63:	mov    r12,rax
   62e66:	mov    rax,QWORD PTR [r12+0x48]
   62e6b:	mov    rcx,QWORD PTR [rax]
   62e6e:	xor    eax,eax
   62e70:	mov    rdi,QWORD PTR [rsp+0x110]
   62e78:	mov    rsi,rcx
   62e7b:	jmp    62e92 <sqlite3VdbeExec+0x139f2>
   62e7d:	movzx  edx,BYTE PTR [rsi]
   62e80:	add    rsi,0x1
   62e84:	and    edx,0xdf
   62e8a:	add    eax,edx
   62e8c:	imul   eax,eax,0x9e3779b1
   62e92:	cmp    BYTE PTR [rsi],0x0
   62e95:	jne    62e7d <sqlite3VdbeExec+0x139dd>
   62e97:	mov    esi,eax
   62e99:	cmp    QWORD PTR [r14+0x230],0x0
   62ea1:	je     62ed3 <sqlite3VdbeExec+0x13a33>
   62ea3:	mov    r8,QWORD PTR [r14+0x230]
   62eaa:	mov    r9d,DWORD PTR [r14+0x220]
   62eb1:	mov    rax,rsi
   62eb4:	xor    edx,edx
   62eb6:	div    r9d
   62eb9:	mov    eax,edx
   62ebb:	shl    rax,0x4
   62ebf:	mov    rdx,QWORD PTR [r8+rax*1+0x8]
   62ec4:	mov    eax,DWORD PTR [r8+rax*1]
   62ec8:	mov    r11,rax
   62ecb:	mov    rax,rdx
   62ece:	mov    rdx,r11
   62ed1:	jmp    62ee1 <sqlite3VdbeExec+0x13a41>
   62ed3:	mov    rax,QWORD PTR [r14+0x228]
   62eda:	mov    edx,DWORD PTR [r14+0x224]
   62ee1:	mov    QWORD PTR [rsp+0x168],rcx
   62ee9:	mov    r10,rax
   62eec:	mov    rcx,rdx
   62eef:	jmp    62f6f <sqlite3VdbeExec+0x13acf>
   62ef1:	mov    QWORD PTR [rsp+0x190],r10
   62ef9:	lea    r10,[rip+0x0]        # 62f00 <sqlite3VdbeExec+0x13a60>
   62f00:	movzx  edx,BYTE PTR [r10+rdx*1]
   62f05:	movzx  r9d,BYTE PTR [r10+r9*1]
   62f0a:	sub    edx,r9d
   62f0d:	test   edx,edx
   62f0f:	je     62f31 <sqlite3VdbeExec+0x13a91>
   62f11:	test   edx,edx
   62f13:	je     62f1f <sqlite3VdbeExec+0x13a7f>
   62f15:	mov    r10,QWORD PTR [rsp+0x190]
   62f1d:	jmp    62f69 <sqlite3VdbeExec+0x13ac9>
   62f1f:	mov    rcx,QWORD PTR [rsp+0x168]
   62f27:	mov    rax,QWORD PTR [rsp+0x190]
   62f2f:	jmp    62f96 <sqlite3VdbeExec+0x13af6>
   62f31:	add    rax,0x1
   62f35:	add    r8,0x1
   62f39:	mov    r10,QWORD PTR [rsp+0x190]
   62f41:	movzx  edx,BYTE PTR [rax]
   62f44:	movzx  r9d,BYTE PTR [r8]
   62f48:	cmp    edx,r9d
   62f4b:	jne    62ef1 <sqlite3VdbeExec+0x13a51>
   62f4d:	test   edx,edx
   62f4f:	je     62f5b <sqlite3VdbeExec+0x13abb>
   62f51:	mov    QWORD PTR [rsp+0x190],r10
   62f59:	jmp    62f31 <sqlite3VdbeExec+0x13a91>
   62f5b:	test   edx,edx
   62f5d:	jne    62f69 <sqlite3VdbeExec+0x13ac9>
   62f5f:	mov    QWORD PTR [rsp+0x190],r10
   62f67:	jmp    62f1f <sqlite3VdbeExec+0x13a7f>
   62f69:	mov    r10,QWORD PTR [r10]
   62f6c:	sub    ecx,0x1
   62f6f:	test   ecx,ecx
   62f71:	je     62f87 <sqlite3VdbeExec+0x13ae7>
   62f73:	cmp    esi,DWORD PTR [r10+0x20]
   62f77:	jne    62f69 <sqlite3VdbeExec+0x13ac9>
   62f79:	mov    rax,QWORD PTR [r10+0x18]
   62f7d:	mov    r8,QWORD PTR [rsp+0x168]
   62f85:	jmp    62f41 <sqlite3VdbeExec+0x13aa1>
   62f87:	lea    rax,[rip+0x0]        # 62f8e <sqlite3VdbeExec+0x13aee>
   62f8e:	mov    rcx,QWORD PTR [rsp+0x168]
   62f96:	mov    rax,QWORD PTR [rax+0x10]
   62f9a:	test   rax,rax
   62f9d:	je     62fb3 <sqlite3VdbeExec+0x13b13>
   62f9f:	mov    rdx,QWORD PTR [rax]
   62fa2:	cmp    QWORD PTR [rdx+0x8],0x0
   62fa7:	je     62fb3 <sqlite3VdbeExec+0x13b13>
   62fa9:	mov    rdx,QWORD PTR [rax]
   62fac:	cmp    QWORD PTR [rdx+0x28],0x0
   62fb1:	jne    62fe5 <sqlite3VdbeExec+0x13b45>
   62fb3:	lea    rax,[rip+0x0]        # 62fba <sqlite3VdbeExec+0x13b1a>
   62fba:	mov    QWORD PTR [rsp+0x110],rdi
   62fc2:	mov    rdi,r14
   62fc5:	mov    rsi,rax
   62fc8:	mov    rdx,rcx
   62fcb:	xor    eax,eax
   62fcd:	call   62fd2 <sqlite3VdbeExec+0x13b32>
   62fd2:	mov    QWORD PTR [r13+0x0],rax
   62fd6:	mov    eax,0x1
   62fdb:	mov    rdi,QWORD PTR [rsp+0x110]
   62fe3:	jmp    6300d <sqlite3VdbeExec+0x13b6d>
   62fe5:	mov    rcx,QWORD PTR [rax]
   62fe8:	mov    rcx,QWORD PTR [rcx+0x8]
   62fec:	mov    QWORD PTR [rsp+0x110],rdi
   62ff4:	mov    rdi,r14
   62ff7:	mov    rsi,r12
   62ffa:	mov    rdx,rax
   62ffd:	mov    r8,r13
   63000:	call   63005 <sqlite3VdbeExec+0x13b65>
   63005:	mov    rdi,QWORD PTR [rsp+0x110]
   6300d:	test   eax,eax
   6300f:	jne    63173 <sqlite3VdbeExec+0x13cd3>
   63015:	mov    rcx,QWORD PTR [r12+0x50]
   6301a:	jmp    63025 <sqlite3VdbeExec+0x13b85>
   6301c:	cmp    r14,QWORD PTR [rcx]
   6301f:	je     6302a <sqlite3VdbeExec+0x13b8a>
   63021:	mov    rcx,QWORD PTR [rcx+0x28]
   63025:	test   rcx,rcx
   63028:	jne    6301c <sqlite3VdbeExec+0x13b7c>
   6302a:	test   rcx,rcx
   6302d:	je     63173 <sqlite3VdbeExec+0x13cd3>
   63033:	mov    eax,DWORD PTR [r14+0x21c]
   6303a:	mov    r11d,eax
   6303d:	mov    eax,0x66666667
   63042:	imul   r11d
   63045:	sar    edx,0x1
   63048:	mov    eax,edx
   6304a:	shr    eax,0x1f
   6304d:	add    edx,eax
   6304f:	imul   edx,edx,0x5
   63052:	neg    edx
   63054:	add    edx,r11d
   63057:	mov    eax,edx
   63059:	test   eax,eax
   6305b:	jne    63132 <sqlite3VdbeExec+0x13c92>
   63061:	movsxd rax,DWORD PTR [r14+0x21c]
   63068:	add    rax,0x5
   6306c:	shl    rax,0x3
   63070:	mov    r13,QWORD PTR [r14+0x240]
   63077:	test   r13,r13
   6307a:	jne    6309c <sqlite3VdbeExec+0x13bfc>
   6307c:	mov    QWORD PTR [rsp+0x110],rdi
   63084:	mov    rdi,r14
   63087:	mov    rsi,rax
   6308a:	call   6308f <sqlite3VdbeExec+0x13bef>
   6308f:	mov    r13,rax
   63092:	mov    rdi,QWORD PTR [rsp+0x110]
   6309a:	jmp    630f1 <sqlite3VdbeExec+0x13c51>
   6309c:	cmp    r13,QWORD PTR [r14+0x1e8]
   630a3:	jae    630d0 <sqlite3VdbeExec+0x13c30>
   630a5:	cmp    r13,QWORD PTR [r14+0x1d8]
   630ac:	jb     630b8 <sqlite3VdbeExec+0x13c18>
   630ae:	cmp    rax,0x80
   630b4:	ja     630d0 <sqlite3VdbeExec+0x13c30>
   630b6:	jmp    630f1 <sqlite3VdbeExec+0x13c51>
   630b8:	cmp    r13,QWORD PTR [r14+0x1e0]
   630bf:	jb     630d0 <sqlite3VdbeExec+0x13c30>
   630c1:	movzx  ecx,WORD PTR [r14+0x19e]
   630c9:	cmp    rax,rcx
   630cc:	ja     630d0 <sqlite3VdbeExec+0x13c30>
   630ce:	jmp    630f1 <sqlite3VdbeExec+0x13c51>
   630d0:	mov    QWORD PTR [rsp+0x110],rdi
   630d8:	mov    rdi,r14
   630db:	mov    rsi,r13
   630de:	mov    rdx,rax
   630e1:	call   630e6 <sqlite3VdbeExec+0x13c46>
   630e6:	mov    r13,rax
   630e9:	mov    rdi,QWORD PTR [rsp+0x110]
   630f1:	test   r13,r13
   630f4:	jne    630fd <sqlite3VdbeExec+0x13c5d>
   630f6:	mov    eax,0x7
   630fb:	jmp    63134 <sqlite3VdbeExec+0x13c94>
   630fd:	movsxd rax,DWORD PTR [r14+0x21c]
   63104:	lea    rax,[r13+rax*8+0x0]
   63109:	xor    ecx,ecx
   6310b:	mov    edx,0x28
   63110:	mov    QWORD PTR [rsp+0x110],rdi
   63118:	mov    rdi,rax
   6311b:	mov    rsi,rcx
   6311e:	call   63123 <sqlite3VdbeExec+0x13c83>
   63123:	mov    QWORD PTR [r14+0x240],r13
   6312a:	mov    rdi,QWORD PTR [rsp+0x110]
   63132:	xor    eax,eax
   63134:	test   eax,eax
   63136:	jne    63173 <sqlite3VdbeExec+0x13cd3>
   63138:	mov    rcx,QWORD PTR [r12+0x50]
   6313d:	jmp    63148 <sqlite3VdbeExec+0x13ca8>
   6313f:	cmp    r14,QWORD PTR [rcx]
   63142:	je     6314d <sqlite3VdbeExec+0x13cad>
   63144:	mov    rcx,QWORD PTR [rcx+0x28]
   63148:	test   rcx,rcx
   6314b:	jne    6313f <sqlite3VdbeExec+0x13c9f>
   6314d:	mov    rdx,QWORD PTR [r14+0x240]
   63154:	movsxd rsi,DWORD PTR [r14+0x21c]
   6315b:	lea    r8d,[rsi+0x1]
   6315f:	mov    DWORD PTR [r14+0x21c],r8d
   63166:	mov    QWORD PTR [rdx+rsi*8],rcx
   6316a:	mov    edx,DWORD PTR [rcx+0x18]
   6316d:	add    edx,0x1
   63170:	mov    DWORD PTR [rcx+0x18],edx
   63173:	mov    r12d,eax
   63176:	mov    r13,r12
   63179:	lea    r12,[rsp+0x278]
   63181:	mov    rax,r12
   63184:	movzx  ecx,WORD PTR [rsp+0x28c]
   6318c:	and    ecx,0x9000
   63192:	test   ecx,ecx
   63194:	jne    6319c <sqlite3VdbeExec+0x13cfc>
   63196:	cmp    DWORD PTR [rax+0x20],0x0
   6319a:	je     631b4 <sqlite3VdbeExec+0x13d14>
   6319c:	mov    QWORD PTR [rsp+0x110],rdi
   631a4:	mov    rdi,rax
   631a7:	call   631ac <sqlite3VdbeExec+0x13d0c>
   631ac:	mov    rdi,QWORD PTR [rsp+0x110]
   631b4:	test   r13d,r13d
   631b7:	je     631d9 <sqlite3VdbeExec+0x13d39>
   631b9:	mov    QWORD PTR [rsp+0x148],rbp
   631c1:	mov    rbp,r13
   631c4:	mov    r13,QWORD PTR [rsp+0x130]
   631cc:	mov    rbx,QWORD PTR [rsp+0x158]
   631d4:	jmp    4f712 <sqlite3VdbeExec+0x272>
   631d9:	mov    DWORD PTR [rsp+0x37c],r15d
   631e1:	mov    DWORD PTR [rsp+0x38c],r13d
   631e9:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   631ee:	mov    r15d,DWORD PTR [rsp+0x37c]
   631f6:	mov    QWORD PTR [rsp+0x130],r12
   631fe:	mov    eax,DWORD PTR [r14+0xe0]
   63205:	add    eax,0x1
   63208:	mov    DWORD PTR [r14+0xe0],eax
   6320f:	movsxd rax,DWORD PTR [rbp+0x4]
   63213:	mov    rcx,QWORD PTR [rbp+0x10]
   63217:	xor    r13d,r13d
   6321a:	mov    rdx,QWORD PTR [r14+0x20]
   6321e:	shl    rax,0x5
   63222:	mov    rax,QWORD PTR [rdx+rax*1]
   63226:	mov    QWORD PTR [rsp+0x110],rdi
   6322e:	mov    rdi,r14
   63231:	mov    rsi,rcx
   63234:	mov    rdx,rax
   63237:	call   6323c <sqlite3VdbeExec+0x13d9c>
   6323c:	mov    r12,rax
   6323f:	mov    rdi,QWORD PTR [rsp+0x110]
   63247:	test   r12,r12
   6324a:	je     634a1 <sqlite3VdbeExec+0x14001>
   63250:	cmp    BYTE PTR [r12+0x3f],0x1
   63256:	jne    634a1 <sqlite3VdbeExec+0x14001>
   6325c:	cmp    QWORD PTR [r12+0x50],0x0
   63262:	je     634a1 <sqlite3VdbeExec+0x14001>
   63268:	mov    rax,QWORD PTR [r12+0x50]
   6326d:	jmp    63273 <sqlite3VdbeExec+0x13dd3>
   6326f:	mov    rax,QWORD PTR [rax+0x28]
   63273:	test   rax,rax
   63276:	je     63290 <sqlite3VdbeExec+0x13df0>
   63278:	mov    rcx,QWORD PTR [rax+0x10]
   6327c:	cmp    DWORD PTR [rcx+0x8],0x0
   63280:	jle    6326f <sqlite3VdbeExec+0x13dcf>
   63282:	mov    r12d,0x6
   63288:	mov    r13,r12
   6328b:	jmp    634a1 <sqlite3VdbeExec+0x14001>
   63290:	xor    eax,eax
   63292:	mov    rcx,QWORD PTR [r12+0x50]
   63297:	mov    QWORD PTR [r12+0x50],0x0
   632a0:	jmp    632b7 <sqlite3VdbeExec+0x13e17>
   632a2:	mov    r8,QWORD PTR [rdx+0x248]
   632a9:	mov    QWORD PTR [rcx+0x28],r8
   632ad:	mov    QWORD PTR [rdx+0x248],rcx
   632b4:	mov    rcx,rsi
   632b7:	test   rcx,rcx
   632ba:	je     632dd <sqlite3VdbeExec+0x13e3d>
   632bc:	mov    rdx,QWORD PTR [rcx]
   632bf:	mov    rsi,QWORD PTR [rcx+0x28]
   632c3:	cmp    rdx,r14
   632c6:	jne    632a2 <sqlite3VdbeExec+0x13e02>
   632c8:	mov    QWORD PTR [r12+0x50],rcx
   632cd:	mov    QWORD PTR [rcx+0x28],0x0
   632d5:	mov    rax,rcx
   632d8:	mov    rcx,rsi
   632db:	jmp    632b7 <sqlite3VdbeExec+0x13e17>
   632dd:	mov    r13,rax
   632e0:	mov    rax,QWORD PTR [r13+0x8]
   632e4:	mov    rax,QWORD PTR [rax]
   632e7:	mov    rax,QWORD PTR [rax+0x28]
   632eb:	test   rax,rax
   632ee:	jne    632fb <sqlite3VdbeExec+0x13e5b>
   632f0:	mov    rax,QWORD PTR [r13+0x8]
   632f4:	mov    rax,QWORD PTR [rax]
   632f7:	mov    rax,QWORD PTR [rax+0x20]
   632fb:	mov    ecx,DWORD PTR [r12+0x2c]
   63300:	add    ecx,0x1
   63303:	mov    DWORD PTR [r12+0x2c],ecx
   63308:	mov    rcx,QWORD PTR [r13+0x10]
   6330c:	mov    DWORD PTR [rsp+0x37c],r15d
   63314:	mov    QWORD PTR [rsp+0x110],rdi
   6331c:	mov    rdi,rcx
   6331f:	mov    r10,rax
   63322:	call   r10
   63325:	mov    r15d,eax
   63328:	mov    rdi,QWORD PTR [rsp+0x110]
   63330:	test   r15d,r15d
   63333:	je     63352 <sqlite3VdbeExec+0x13eb2>
   63335:	mov    DWORD PTR [rsp+0x3a4],r15d
   6333d:	mov    QWORD PTR [rsp+0x148],rbp
   63345:	mov    QWORD PTR [rsp+0x160],rbx
   6334d:	jmp    63446 <sqlite3VdbeExec+0x13fa6>
   63352:	mov    QWORD PTR [r13+0x10],0x0
   6335a:	mov    QWORD PTR [r12+0x50],0x0
   63363:	mov    DWORD PTR [rsp+0x3a4],r15d
   6336b:	mov    r15,QWORD PTR [r13+0x0]
   6336f:	mov    eax,DWORD PTR [r13+0x18]
   63373:	sub    eax,0x1
   63376:	mov    DWORD PTR [r13+0x18],eax
   6337a:	cmp    DWORD PTR [r13+0x18],0x0
   6337f:	je     63396 <sqlite3VdbeExec+0x13ef6>
   63381:	mov    QWORD PTR [rsp+0x148],rbp
   63389:	mov    QWORD PTR [rsp+0x160],rbx
   63391:	jmp    63446 <sqlite3VdbeExec+0x13fa6>
   63396:	mov    rax,QWORD PTR [r13+0x10]
   6339a:	test   rax,rax
   6339d:	je     633b7 <sqlite3VdbeExec+0x13f17>
   6339f:	mov    rcx,QWORD PTR [rax]
   633a2:	mov    rcx,QWORD PTR [rcx+0x20]
   633a6:	mov    rdi,rax
   633a9:	mov    r10,rcx
   633ac:	call   r10
   633af:	mov    rdi,QWORD PTR [rsp+0x110]
   633b7:	mov    QWORD PTR [rsp+0x160],rbx
   633bf:	mov    rbx,QWORD PTR [r13+0x0]
   633c3:	mov    QWORD PTR [rsp+0x148],rbp
   633cb:	mov    rbp,QWORD PTR [r13+0x8]
   633cf:	mov    eax,DWORD PTR [rbp+0x10]
   633d2:	sub    eax,0x1
   633d5:	mov    DWORD PTR [rbp+0x10],eax
   633d8:	cmp    DWORD PTR [rbp+0x10],0x0
   633dc:	jne    63426 <sqlite3VdbeExec+0x13f86>
   633de:	cmp    QWORD PTR [rbp+0x20],0x0
   633e3:	je     63406 <sqlite3VdbeExec+0x13f66>
   633e5:	mov    rax,QWORD PTR [rbp+0x20]
   633e9:	mov    rcx,QWORD PTR [rbp+0x18]
   633ed:	mov    QWORD PTR [rsp+0x110],rdi
   633f5:	mov    rdi,rcx
   633f8:	mov    r10,rax
   633fb:	call   r10
   633fe:	mov    rdi,QWORD PTR [rsp+0x110]
   63406:	test   rbp,rbp
   63409:	je     63426 <sqlite3VdbeExec+0x13f86>
   6340b:	mov    QWORD PTR [rsp+0x110],rdi
   63413:	mov    rdi,rbx
   63416:	mov    rsi,rbp
   63419:	call   6341e <sqlite3VdbeExec+0x13f7e>
   6341e:	mov    rdi,QWORD PTR [rsp+0x110]
   63426:	test   r13,r13
   63429:	je     63446 <sqlite3VdbeExec+0x13fa6>
   6342b:	mov    QWORD PTR [rsp+0x110],rdi
   63433:	mov    rdi,r15
   63436:	mov    rsi,r13
   63439:	call   6343e <sqlite3VdbeExec+0x13f9e>
   6343e:	mov    rdi,QWORD PTR [rsp+0x110]
   63446:	test   r12,r12
   63449:	je     63481 <sqlite3VdbeExec+0x13fe1>
   6344b:	cmp    QWORD PTR [r14+0x300],0x0
   63453:	jne    63466 <sqlite3VdbeExec+0x13fc6>
   63455:	mov    eax,DWORD PTR [r12+0x2c]
   6345a:	sub    eax,0x1
   6345d:	mov    DWORD PTR [r12+0x2c],eax
   63462:	test   eax,eax
   63464:	ja     63481 <sqlite3VdbeExec+0x13fe1>
   63466:	mov    QWORD PTR [rsp+0x110],rdi
   6346e:	mov    rdi,r14
   63471:	mov    rsi,r12
   63474:	call   63479 <sqlite3VdbeExec+0x13fd9>
   63479:	mov    rdi,QWORD PTR [rsp+0x110]
   63481:	mov    r15d,DWORD PTR [rsp+0x37c]
   63489:	mov    rbp,QWORD PTR [rsp+0x148]
   63491:	mov    rbx,QWORD PTR [rsp+0x160]
   63499:	mov    r13d,DWORD PTR [rsp+0x3a4]
   634a1:	mov    eax,DWORD PTR [r14+0xe0]
   634a8:	sub    eax,0x1
   634ab:	mov    DWORD PTR [r14+0xe0],eax
   634b2:	test   r13d,r13d
   634b5:	je     634d7 <sqlite3VdbeExec+0x14037>
   634b7:	mov    QWORD PTR [rsp+0x148],rbp
   634bf:	mov    rbp,r13
   634c2:	mov    r13,QWORD PTR [rsp+0x130]
   634ca:	mov    rbx,QWORD PTR [rsp+0x158]
   634d2:	jmp    4f712 <sqlite3VdbeExec+0x272>
   634d7:	mov    DWORD PTR [rsp+0x37c],r15d
   634df:	mov    DWORD PTR [rsp+0x38c],r13d
   634e7:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   634ec:	mov    r15d,DWORD PTR [rsp+0x37c]
   634f4:	mov    r13,QWORD PTR [rsp+0x150]
   634fc:	mov    QWORD PTR [rsp+0x130],r12
   63504:	mov    r12d,DWORD PTR [rsp+0x394]
   6350c:	mov    rax,QWORD PTR [rdi+0x78]
   63510:	movsxd rcx,DWORD PTR [rbp+0x4]
   63514:	mov    rax,QWORD PTR [rax+rcx*8]
   63518:	test   rax,rax
   6351b:	je     63550 <sqlite3VdbeExec+0x140b0>
   6351d:	cmp    BYTE PTR [rax],0x2
   63520:	jne    63550 <sqlite3VdbeExec+0x140b0>
   63522:	mov    rax,QWORD PTR [rax+0x28]
   63526:	mov    rax,QWORD PTR [rax]
   63529:	mov    rcx,QWORD PTR [rbp+0x10]
   6352d:	cmp    rax,QWORD PTR [rcx+0x10]
   63531:	jne    63550 <sqlite3VdbeExec+0x140b0>
   63533:	mov    DWORD PTR [rsp+0x37c],r15d
   6353b:	mov    QWORD PTR [rsp+0x150],r13
   63543:	mov    DWORD PTR [rsp+0x394],r12d
   6354b:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   63550:	mov    QWORD PTR [rsp+0x168],0x0
   6355c:	mov    rax,QWORD PTR [rbp+0x10]
   63560:	mov    QWORD PTR [rsp+0x150],r13
   63568:	mov    r13,QWORD PTR [rax+0x10]
   6356c:	test   r13,r13
   6356f:	je     63578 <sqlite3VdbeExec+0x140d8>
   63571:	cmp    QWORD PTR [r13+0x0],0x0
   63576:	jne    6359d <sqlite3VdbeExec+0x140fd>
   63578:	mov    ebx,0x6
   6357d:	mov    QWORD PTR [rsp+0x148],rbp
   63585:	mov    rbp,rbx
   63588:	mov    r13,QWORD PTR [rsp+0x130]
   63590:	mov    rbx,QWORD PTR [rsp+0x158]
   63598:	jmp    4f712 <sqlite3VdbeExec+0x272>
   6359d:	mov    DWORD PTR [rsp+0x394],r12d
   635a5:	mov    r12,QWORD PTR [r13+0x0]
   635a9:	mov    rax,QWORD PTR [r12+0x30]
   635ae:	mov    QWORD PTR [rsp+0x180],r12
   635b6:	lea    r12,[rsp+0x168]
   635be:	mov    rcx,r12
   635c1:	mov    QWORD PTR [rsp+0x110],rdi
   635c9:	mov    rdi,r13
   635cc:	mov    rsi,rcx
   635cf:	mov    r10,rax
   635d2:	call   r10
   635d5:	mov    r12d,eax
   635d8:	mov    rdi,QWORD PTR [rsp+0x110]
   635e0:	cmp    QWORD PTR [r13+0x10],0x0
   635e5:	jne    635f4 <sqlite3VdbeExec+0x14154>
   635e7:	mov    DWORD PTR [rsp+0x3a4],r12d
   635ef:	jmp    6377d <sqlite3VdbeExec+0x142dd>
   635f4:	mov    DWORD PTR [rsp+0x3a4],r12d
   635fc:	mov    r12,QWORD PTR [rdi]
   635ff:	mov    rax,QWORD PTR [rdi+0xa8]
   63606:	test   rax,rax
   63609:	je     6361e <sqlite3VdbeExec+0x1417e>
   6360b:	mov    rdi,r12
   6360e:	mov    rsi,rax
   63611:	call   63616 <sqlite3VdbeExec+0x14176>
   63616:	mov    rdi,QWORD PTR [rsp+0x110]
   6361e:	mov    QWORD PTR [rsp+0x190],r13
   63626:	mov    r13,QWORD PTR [r13+0x10]
   6362a:	test   r13,r13
   6362d:	jne    6363f <sqlite3VdbeExec+0x1419f>
   6362f:	xor    r12d,r12d
   63632:	mov    r13,QWORD PTR [rsp+0x190]
   6363a:	jmp    636e0 <sqlite3VdbeExec+0x14240>
   6363f:	mov    QWORD PTR [rsp+0x110],rdi
   63647:	mov    rdi,r13
   6364a:	call   6364f <sqlite3VdbeExec+0x141af>
   6364f:	mov    QWORD PTR [rsp+0x188],r13
   63657:	lea    r13,[rax+0x1]
   6365b:	mov    rdi,QWORD PTR [rsp+0x110]
   63663:	test   r12,r12
   63666:	je     63680 <sqlite3VdbeExec+0x141e0>
   63668:	mov    rdi,r12
   6366b:	mov    rsi,r13
   6366e:	call   63673 <sqlite3VdbeExec+0x141d3>
   63673:	mov    r12,rax
   63676:	mov    rdi,QWORD PTR [rsp+0x110]
   6367e:	jmp    63693 <sqlite3VdbeExec+0x141f3>
   63680:	mov    rdi,r13
   63683:	call   63688 <sqlite3VdbeExec+0x141e8>
   63688:	mov    r12,rax
   6368b:	mov    rdi,QWORD PTR [rsp+0x110]
   63693:	test   r12,r12
   63696:	jne    636a2 <sqlite3VdbeExec+0x14202>
   63698:	mov    DWORD PTR [rsp+0x37c],r15d
   636a0:	jmp    636d0 <sqlite3VdbeExec+0x14230>
   636a2:	mov    DWORD PTR [rsp+0x37c],r15d
   636aa:	mov    r15,QWORD PTR [rsp+0x188]
   636b2:	mov    QWORD PTR [rsp+0x110],rdi
   636ba:	mov    rdi,r12
   636bd:	mov    rsi,r15
   636c0:	mov    rdx,r13
   636c3:	call   636c8 <sqlite3VdbeExec+0x14228>
   636c8:	mov    rdi,QWORD PTR [rsp+0x110]
   636d0:	mov    r15d,DWORD PTR [rsp+0x37c]
   636d8:	mov    r13,QWORD PTR [rsp+0x190]
   636e0:	mov    QWORD PTR [rdi+0xa8],r12
   636e7:	mov    r12,QWORD PTR [r13+0x10]
   636eb:	test   r12,r12
   636ee:	je     63775 <sqlite3VdbeExec+0x142d5>
   636f4:	cmp    DWORD PTR [rip+0x0],0x0        # 636fb <sqlite3VdbeExec+0x1425b>
   636fb:	je     63755 <sqlite3VdbeExec+0x142b5>
   636fd:	mov    rax,QWORD PTR [rip+0x0]        # 63704 <sqlite3VdbeExec+0x14264>
   63704:	mov    QWORD PTR [rsp+0x110],rdi
   6370c:	mov    rdi,r12
   6370f:	mov    r10,rax
   63712:	call   r10
   63715:	mov    rcx,QWORD PTR [rip+0x0]        # 6371c <sqlite3VdbeExec+0x1427c>
   6371c:	movsxd rax,eax
   6371f:	sub    rcx,rax
   63722:	mov    QWORD PTR [rip+0x0],rcx        # 63729 <sqlite3VdbeExec+0x14289>
   63729:	mov    rax,QWORD PTR [rip+0x0]        # 63730 <sqlite3VdbeExec+0x14290>
   63730:	sub    rax,0x1
   63734:	mov    QWORD PTR [rip+0x0],rax        # 6373b <sqlite3VdbeExec+0x1429b>
   6373b:	mov    rax,QWORD PTR [rip+0x0]        # 63742 <sqlite3VdbeExec+0x142a2>
   63742:	mov    rdi,r12
   63745:	mov    r10,rax
   63748:	call   r10
   6374b:	mov    rdi,QWORD PTR [rsp+0x110]
   63753:	jmp    63775 <sqlite3VdbeExec+0x142d5>
   63755:	mov    rax,QWORD PTR [rip+0x0]        # 6375c <sqlite3VdbeExec+0x142bc>
   6375c:	mov    QWORD PTR [rsp+0x110],rdi
   63764:	mov    rdi,r12
   63767:	mov    r10,rax
   6376a:	call   r10
   6376d:	mov    rdi,QWORD PTR [rsp+0x110]
   63775:	mov    QWORD PTR [r13+0x10],0x0
   6377d:	mov    r12d,DWORD PTR [rsp+0x3a4]
   63785:	test   r12d,r12d
   63788:	je     637aa <sqlite3VdbeExec+0x1430a>
   6378a:	mov    QWORD PTR [rsp+0x148],rbp
   63792:	mov    rbp,r12
   63795:	mov    r13,QWORD PTR [rsp+0x130]
   6379d:	mov    rbx,QWORD PTR [rsp+0x158]
   637a5:	jmp    4f712 <sqlite3VdbeExec+0x272>
   637aa:	mov    rax,QWORD PTR [rsp+0x168]
   637b2:	mov    QWORD PTR [rax],r13
   637b5:	mov    eax,DWORD PTR [rbp+0x4]
   637b8:	xor    ecx,ecx
   637ba:	mov    edx,0x2
   637bf:	mov    QWORD PTR [rsp+0x110],rdi
   637c7:	mov    rsi,rax
   637ca:	mov    r11,rdx
   637cd:	mov    rdx,rcx
   637d0:	mov    rcx,r11
   637d3:	call   637d8 <sqlite3VdbeExec+0x14338>
   637d8:	mov    rdi,QWORD PTR [rsp+0x110]
   637e0:	test   rax,rax
   637e3:	je     63811 <sqlite3VdbeExec+0x14371>
   637e5:	mov    rcx,QWORD PTR [rsp+0x168]
   637ed:	mov    QWORD PTR [rax+0x28],rcx
   637f1:	mov    eax,DWORD PTR [r13+0x8]
   637f5:	add    eax,0x1
   637f8:	mov    DWORD PTR [r13+0x8],eax
   637fc:	mov    DWORD PTR [rsp+0x37c],r15d
   63804:	mov    DWORD PTR [rsp+0x38c],r12d
   6380c:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   63811:	mov    r12,QWORD PTR [rsp+0x180]
   63819:	mov    rax,QWORD PTR [r12+0x38]
   6381e:	mov    rcx,QWORD PTR [rsp+0x168]
   63826:	mov    rdi,rcx
   63829:	mov    r10,rax
   6382c:	call   r10
   6382f:	mov    rdi,QWORD PTR [rsp+0x110]
   63837:	mov    r13,QWORD PTR [rsp+0x150]
   6383f:	mov    rbx,rbp
   63842:	mov    rbp,QWORD PTR [rsp+0x158]
   6384a:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   6384f:	mov    r15d,DWORD PTR [rsp+0x37c]
   63857:	mov    r13,QWORD PTR [rsp+0x150]
   6385f:	mov    QWORD PTR [rsp+0x130],r12
   63867:	mov    r12d,DWORD PTR [rsp+0x394]
   6386f:	mov    QWORD PTR [rsp+0x168],0x0
   6387b:	movsxd rax,DWORD PTR [rbp+0x8]
   6387f:	imul   rax,rax,0x38
   63883:	mov    DWORD PTR [rsp+0x394],r12d
   6388b:	lea    r12,[rbx+rax*1]
   6388f:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   63894:	and    eax,0x9000
   63899:	test   eax,eax
   6389b:	je     638b7 <sqlite3VdbeExec+0x14417>
   6389d:	mov    QWORD PTR [rsp+0x110],rdi
   638a5:	mov    rdi,r12
   638a8:	call   638ad <sqlite3VdbeExec+0x1440d>
   638ad:	mov    rdi,QWORD PTR [rsp+0x110]
   638b5:	jmp    638bf <sqlite3VdbeExec+0x1441f>
   638b7:	mov    WORD PTR [r12+0x14],0x1
   638bf:	mov    QWORD PTR [rsp+0x150],r13
   638c7:	mov    r13,QWORD PTR [rbp+0x10]
   638cb:	cmp    QWORD PTR [r13+0x50],0x0
   638d0:	jne    638df <sqlite3VdbeExec+0x1443f>
   638d2:	mov    DWORD PTR [rsp+0x37c],r15d
   638da:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   638df:	mov    rax,QWORD PTR [r13+0x50]
   638e3:	mov    rax,QWORD PTR [rax+0x10]
   638e7:	mov    rcx,QWORD PTR [rax]
   638ea:	mov    rdx,QWORD PTR [r13+0x50]
   638ee:	mov    esi,DWORD PTR [rdx+0x18]
   638f1:	add    esi,0x1
   638f4:	mov    DWORD PTR [rdx+0x18],esi
   638f7:	mov    rcx,QWORD PTR [rcx+0xc0]
   638fe:	mov    rdx,QWORD PTR [r14+0x20]
   63902:	movsxd rsi,DWORD PTR [rbp+0x4]
   63906:	shl    rsi,0x5
   6390a:	mov    rdx,QWORD PTR [rdx+rsi*1]
   6390e:	mov    rsi,QWORD PTR [r13+0x0]
   63912:	mov    r8d,DWORD PTR [rbp+0xc]
   63916:	mov    QWORD PTR [rsp+0x128],r14
   6391e:	lea    r14,[rsp+0x168]
   63926:	mov    r9,r14
   63929:	mov    QWORD PTR [rsp+0x110],rdi
   63931:	mov    rdi,rax
   63934:	mov    r10,rcx
   63937:	mov    rcx,r8
   6393a:	mov    r8,r9
   6393d:	mov    r11,rsi
   63940:	mov    rsi,rdx
   63943:	mov    rdx,r11
   63946:	call   r10
   63949:	mov    r14d,eax
   6394c:	mov    r13,QWORD PTR [r13+0x50]
   63950:	mov    QWORD PTR [rsp+0x148],rbp
   63958:	mov    rbp,QWORD PTR [r13+0x0]
   6395c:	mov    eax,DWORD PTR [r13+0x18]
   63960:	sub    eax,0x1
   63963:	mov    DWORD PTR [r13+0x18],eax
   63967:	mov    rdi,QWORD PTR [rsp+0x110]
   6396f:	cmp    DWORD PTR [r13+0x18],0x0
   63974:	je     6398b <sqlite3VdbeExec+0x144eb>
   63976:	mov    DWORD PTR [rsp+0x37c],r15d
   6397e:	mov    QWORD PTR [rsp+0x180],r12
   63986:	jmp    63a3e <sqlite3VdbeExec+0x1459e>
   6398b:	mov    rax,QWORD PTR [r13+0x10]
   6398f:	test   rax,rax
   63992:	je     639ac <sqlite3VdbeExec+0x1450c>
   63994:	mov    rcx,QWORD PTR [rax]
   63997:	mov    rcx,QWORD PTR [rcx+0x20]
   6399b:	mov    rdi,rax
   6399e:	mov    r10,rcx
   639a1:	call   r10
   639a4:	mov    rdi,QWORD PTR [rsp+0x110]
   639ac:	mov    QWORD PTR [rsp+0x180],r12
   639b4:	mov    r12,QWORD PTR [r13+0x0]
   639b8:	mov    DWORD PTR [rsp+0x37c],r15d
   639c0:	mov    r15,QWORD PTR [r13+0x8]
   639c4:	mov    eax,DWORD PTR [r15+0x10]
   639c8:	sub    eax,0x1
   639cb:	mov    DWORD PTR [r15+0x10],eax
   639cf:	cmp    DWORD PTR [r15+0x10],0x0
   639d4:	jne    63a1e <sqlite3VdbeExec+0x1457e>
   639d6:	cmp    QWORD PTR [r15+0x20],0x0
   639db:	je     639fe <sqlite3VdbeExec+0x1455e>
   639dd:	mov    rax,QWORD PTR [r15+0x20]
   639e1:	mov    rcx,QWORD PTR [r15+0x18]
   639e5:	mov    QWORD PTR [rsp+0x110],rdi
   639ed:	mov    rdi,rcx
   639f0:	mov    r10,rax
   639f3:	call   r10
   639f6:	mov    rdi,QWORD PTR [rsp+0x110]
   639fe:	test   r15,r15
   63a01:	je     63a1e <sqlite3VdbeExec+0x1457e>
   63a03:	mov    QWORD PTR [rsp+0x110],rdi
   63a0b:	mov    rdi,r12
   63a0e:	mov    rsi,r15
   63a11:	call   63a16 <sqlite3VdbeExec+0x14576>
   63a16:	mov    rdi,QWORD PTR [rsp+0x110]
   63a1e:	test   r13,r13
   63a21:	je     63a3e <sqlite3VdbeExec+0x1459e>
   63a23:	mov    QWORD PTR [rsp+0x110],rdi
   63a2b:	mov    rdi,rbp
   63a2e:	mov    rsi,r13
   63a31:	call   63a36 <sqlite3VdbeExec+0x14596>
   63a36:	mov    rdi,QWORD PTR [rsp+0x110]
   63a3e:	test   r14d,r14d
   63a41:	je     63af9 <sqlite3VdbeExec+0x14659>
   63a47:	mov    rbx,QWORD PTR [rsp+0x168]
   63a4f:	test   rbx,rbx
   63a52:	je     63ad9 <sqlite3VdbeExec+0x14639>
   63a58:	cmp    DWORD PTR [rip+0x0],0x0        # 63a5f <sqlite3VdbeExec+0x145bf>
   63a5f:	je     63ab9 <sqlite3VdbeExec+0x14619>
   63a61:	mov    rax,QWORD PTR [rip+0x0]        # 63a68 <sqlite3VdbeExec+0x145c8>
   63a68:	mov    QWORD PTR [rsp+0x110],rdi
   63a70:	mov    rdi,rbx
   63a73:	mov    r10,rax
   63a76:	call   r10
   63a79:	mov    rcx,QWORD PTR [rip+0x0]        # 63a80 <sqlite3VdbeExec+0x145e0>
   63a80:	movsxd rax,eax
   63a83:	sub    rcx,rax
   63a86:	mov    QWORD PTR [rip+0x0],rcx        # 63a8d <sqlite3VdbeExec+0x145ed>
   63a8d:	mov    rax,QWORD PTR [rip+0x0]        # 63a94 <sqlite3VdbeExec+0x145f4>
   63a94:	sub    rax,0x1
   63a98:	mov    QWORD PTR [rip+0x0],rax        # 63a9f <sqlite3VdbeExec+0x145ff>
   63a9f:	mov    rax,QWORD PTR [rip+0x0]        # 63aa6 <sqlite3VdbeExec+0x14606>
   63aa6:	mov    rdi,rbx
   63aa9:	mov    r10,rax
   63aac:	call   r10
   63aaf:	mov    rdi,QWORD PTR [rsp+0x110]
   63ab7:	jmp    63ad9 <sqlite3VdbeExec+0x14639>
   63ab9:	mov    rax,QWORD PTR [rip+0x0]        # 63ac0 <sqlite3VdbeExec+0x14620>
   63ac0:	mov    QWORD PTR [rsp+0x110],rdi
   63ac8:	mov    rdi,rbx
   63acb:	mov    r10,rax
   63ace:	call   r10
   63ad1:	mov    rdi,QWORD PTR [rsp+0x110]
   63ad9:	mov    rbp,r14
   63adc:	mov    r14,QWORD PTR [rsp+0x128]
   63ae4:	mov    r13,QWORD PTR [rsp+0x130]
   63aec:	mov    rbx,QWORD PTR [rsp+0x158]
   63af4:	jmp    4f712 <sqlite3VdbeExec+0x272>
   63af9:	mov    r12,QWORD PTR [rsp+0x180]
   63b01:	cmp    QWORD PTR [rsp+0x168],0x0
   63b0a:	je     63b4b <sqlite3VdbeExec+0x146ab>
   63b0c:	mov    rax,QWORD PTR [rsp+0x168]
   63b14:	mov    rcx,0xffffffffffffffff
   63b1b:	lea    rdx,[rip+0x0]        # 63b22 <sqlite3VdbeExec+0x14682>
   63b22:	mov    esi,0x1
   63b27:	mov    QWORD PTR [rsp+0x110],rdi
   63b2f:	mov    rdi,r12
   63b32:	mov    r8,rdx
   63b35:	mov    rdx,rcx
   63b38:	mov    rcx,rsi
   63b3b:	mov    rsi,rax
   63b3e:	call   63b43 <sqlite3VdbeExec+0x146a3>
   63b43:	mov    rdi,QWORD PTR [rsp+0x110]
   63b4b:	mov    rbp,QWORD PTR [rsp+0x148]
   63b53:	mov    DWORD PTR [rsp+0x38c],r14d
   63b5b:	mov    r14,QWORD PTR [rsp+0x128]
   63b63:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   63b68:	mov    r15d,DWORD PTR [rsp+0x37c]
   63b70:	mov    r13,QWORD PTR [rsp+0x150]
   63b78:	mov    QWORD PTR [rsp+0x130],r12
   63b80:	mov    r12d,DWORD PTR [rsp+0x394]
   63b88:	mov    rax,QWORD PTR [rdi+0x78]
   63b8c:	movsxd rcx,DWORD PTR [rbp+0x4]
   63b90:	mov    DWORD PTR [rsp+0x394],r12d
   63b98:	mov    r12,QWORD PTR [rax+rcx*8]
   63b9c:	mov    QWORD PTR [rsp+0x110],rdi
   63ba4:	call   63ba9 <sqlite3VdbeExec+0x14709>
   63ba9:	mov    rdi,QWORD PTR [rsp+0x110]
   63bb1:	test   eax,eax
   63bb3:	je     63bc4 <sqlite3VdbeExec+0x14724>
   63bb5:	mov    QWORD PTR [rsp+0x150],r13
   63bbd:	mov    r13,rbx
   63bc0:	xor    ebx,ebx
   63bc2:	jmp    63bfa <sqlite3VdbeExec+0x1475a>
   63bc4:	mov    QWORD PTR [rsp+0x168],r12
   63bcc:	mov    r12,rbx
   63bcf:	mov    ebx,0x10
   63bd4:	mov    rdi,rbx
   63bd7:	call   63bdc <sqlite3VdbeExec+0x1473c>
   63bdc:	mov    rbx,rax
   63bdf:	mov    rdi,QWORD PTR [rsp+0x110]
   63be7:	mov    QWORD PTR [rsp+0x150],r13
   63bef:	mov    r13,r12
   63bf2:	mov    r12,QWORD PTR [rsp+0x168]
   63bfa:	test   rbx,rbx
   63bfd:	jne    63c17 <sqlite3VdbeExec+0x14777>
   63bff:	mov    r13,QWORD PTR [rsp+0x150]
   63c07:	mov    rbx,rbp
   63c0a:	mov    rbp,QWORD PTR [rsp+0x158]
   63c12:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   63c17:	mov    rax,QWORD PTR [r12+0x28]
   63c1c:	mov    QWORD PTR [rbx],rax
   63c1f:	movsxd rax,DWORD PTR [rbp+0xc]
   63c23:	imul   rax,rax,0x38
   63c27:	add    rax,r13
   63c2a:	mov    QWORD PTR [rbx+0x8],rax
   63c2e:	mov    rax,QWORD PTR [rdi+0x68]
   63c32:	movsxd rcx,DWORD PTR [rbp+0x8]
   63c36:	imul   rcx,rcx,0x38
   63c3a:	lea    r12,[rax+rcx*1]
   63c3e:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   63c43:	and    eax,0x9000
   63c48:	test   eax,eax
   63c4a:	je     63c69 <sqlite3VdbeExec+0x147c9>
   63c4c:	mov    QWORD PTR [rsp+0x110],rdi
   63c54:	mov    rdi,r12
   63c57:	call   63c5c <sqlite3VdbeExec+0x147bc>
   63c5c:	mov    r12,rax
   63c5f:	mov    rdi,QWORD PTR [rsp+0x110]
   63c67:	jmp    63c71 <sqlite3VdbeExec+0x147d1>
   63c69:	mov    WORD PTR [r12+0x14],0x4
   63c71:	mov    WORD PTR [r12+0x14],0x1
   63c79:	mov    QWORD PTR [rsp+0x110],rdi
   63c81:	mov    rdi,r12
   63c84:	call   63c89 <sqlite3VdbeExec+0x147e9>
   63c89:	lea    rax,[rip+0x0]        # 63c90 <sqlite3VdbeExec+0x147f0>
   63c90:	mov    DWORD PTR [rsp+0x37c],r15d
   63c98:	lea    r15,[rip+0x0]        # 63c9f <sqlite3VdbeExec+0x147ff>
   63c9f:	test   r15,r15
   63ca2:	cmovne rax,r15
   63ca6:	mov    QWORD PTR [r12],rax
   63caa:	mov    QWORD PTR [r12+0x8],rbx
   63caf:	mov    WORD PTR [r12+0x14],0x1a01
   63cb7:	mov    BYTE PTR [r12+0x17],0x70
   63cbd:	lea    rax,[rip+0x0]        # 63cc4 <sqlite3VdbeExec+0x14824>
   63cc4:	lea    rbx,[rip+0x0]        # 63ccb <sqlite3VdbeExec+0x1482b>
   63ccb:	test   rbx,rbx
   63cce:	cmovne rax,rbx
   63cd2:	mov    QWORD PTR [r12+0x30],rax
   63cd7:	mov    rdi,QWORD PTR [rsp+0x110]
   63cdf:	mov    rbx,r13
   63ce2:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   63ce7:	mov    r13,rbx
   63cea:	mov    QWORD PTR [rsp+0x130],r12
   63cf2:	movsxd rax,DWORD PTR [rbp+0xc]
   63cf6:	imul   rax,rax,0x38
   63cfa:	lea    rcx,[r13+rax*1+0x0]
   63cff:	add    rcx,0x38
   63d03:	mov    rdx,QWORD PTR [rdi+0x78]
   63d07:	movsxd rsi,DWORD PTR [rbp+0x4]
   63d0b:	mov    rbx,QWORD PTR [rdx+rsi*8]
   63d0f:	mov    r12,QWORD PTR [rbx+0x28]
   63d13:	mov    r15,QWORD PTR [r12]
   63d17:	mov    QWORD PTR [rsp+0x168],rbx
   63d1f:	mov    rbx,QWORD PTR [r15]
   63d22:	mov    rdx,QWORD PTR [r13+rax*1+0x38]
   63d27:	mov    rax,QWORD PTR [r13+rax*1+0x0]
   63d2c:	mov    rsi,QWORD PTR [rdi+0x70]
   63d30:	xor    r8d,r8d
   63d33:	jmp    63d4e <sqlite3VdbeExec+0x148ae>
   63d35:	mov    r9,r8
   63d38:	lea    r10d,[r8+0x1]
   63d3c:	movsxd r10,r10d
   63d3f:	imul   r10,r10,0x38
   63d43:	add    r10,rcx
   63d46:	mov    QWORD PTR [rsi+r9*8],r10
   63d4a:	add    r8d,0x1
   63d4e:	cmp    r8d,edx
   63d51:	jl     63d35 <sqlite3VdbeExec+0x14895>
   63d53:	mov    rcx,QWORD PTR [rbx+0x40]
   63d57:	mov    r8,QWORD PTR [rbp+0x10]
   63d5b:	mov    QWORD PTR [rsp+0x188],rbx
   63d63:	mov    QWORD PTR [rsp+0x110],rdi
   63d6b:	mov    rdi,r12
   63d6e:	mov    r10,rcx
   63d71:	mov    rcx,rdx
   63d74:	mov    rdx,r8
   63d77:	mov    r8,rsi
   63d7a:	mov    rsi,rax
   63d7d:	call   r10
   63d80:	mov    ebx,eax
   63d82:	mov    rdi,QWORD PTR [rsp+0x110]
   63d8a:	cmp    QWORD PTR [r15+0x10],0x0
   63d8f:	jne    63da5 <sqlite3VdbeExec+0x14905>
   63d91:	mov    QWORD PTR [rsp+0x180],r12
   63d99:	mov    DWORD PTR [rsp+0x3a4],ebx
   63da0:	jmp    63f1c <sqlite3VdbeExec+0x14a7c>
   63da5:	mov    DWORD PTR [rsp+0x3a4],ebx
   63dac:	mov    rbx,QWORD PTR [rdi]
   63daf:	mov    rax,QWORD PTR [rdi+0xa8]
   63db6:	test   rax,rax
   63db9:	je     63dce <sqlite3VdbeExec+0x1492e>
   63dbb:	mov    rdi,rbx
   63dbe:	mov    rsi,rax
   63dc1:	call   63dc6 <sqlite3VdbeExec+0x14926>
   63dc6:	mov    rdi,QWORD PTR [rsp+0x110]
   63dce:	mov    QWORD PTR [rsp+0x180],r12
   63dd6:	mov    r12,QWORD PTR [r15+0x10]
   63dda:	test   r12,r12
   63ddd:	jne    63de6 <sqlite3VdbeExec+0x14946>
   63ddf:	xor    ebx,ebx
   63de1:	jmp    63e7f <sqlite3VdbeExec+0x149df>
   63de6:	mov    QWORD PTR [rsp+0x110],rdi
   63dee:	mov    rdi,r12
   63df1:	call   63df6 <sqlite3VdbeExec+0x14956>
   63df6:	mov    QWORD PTR [rsp+0x1c0],r12
   63dfe:	lea    r12,[rax+0x1]
   63e02:	mov    rdi,QWORD PTR [rsp+0x110]
   63e0a:	test   rbx,rbx
   63e0d:	je     63e27 <sqlite3VdbeExec+0x14987>
   63e0f:	mov    rdi,rbx
   63e12:	mov    rsi,r12
   63e15:	call   63e1a <sqlite3VdbeExec+0x1497a>
   63e1a:	mov    rbx,rax
   63e1d:	mov    rdi,QWORD PTR [rsp+0x110]
   63e25:	jmp    63e3a <sqlite3VdbeExec+0x1499a>
   63e27:	mov    rdi,r12
   63e2a:	call   63e2f <sqlite3VdbeExec+0x1498f>
   63e2f:	mov    rbx,rax
   63e32:	mov    rdi,QWORD PTR [rsp+0x110]
   63e3a:	test   rbx,rbx
   63e3d:	jne    63e49 <sqlite3VdbeExec+0x149a9>
   63e3f:	mov    QWORD PTR [rsp+0x190],r15
   63e47:	jmp    63e77 <sqlite3VdbeExec+0x149d7>
   63e49:	mov    QWORD PTR [rsp+0x190],r15
   63e51:	mov    r15,QWORD PTR [rsp+0x1c0]
   63e59:	mov    QWORD PTR [rsp+0x110],rdi
   63e61:	mov    rdi,rbx
   63e64:	mov    rsi,r15
   63e67:	mov    rdx,r12
   63e6a:	call   63e6f <sqlite3VdbeExec+0x149cf>
   63e6f:	mov    rdi,QWORD PTR [rsp+0x110]
   63e77:	mov    r15,QWORD PTR [rsp+0x190]
   63e7f:	mov    QWORD PTR [rdi+0xa8],rbx
   63e86:	mov    rbx,QWORD PTR [r15+0x10]
   63e8a:	test   rbx,rbx
   63e8d:	je     63f14 <sqlite3VdbeExec+0x14a74>
   63e93:	cmp    DWORD PTR [rip+0x0],0x0        # 63e9a <sqlite3VdbeExec+0x149fa>
   63e9a:	je     63ef4 <sqlite3VdbeExec+0x14a54>
   63e9c:	mov    rax,QWORD PTR [rip+0x0]        # 63ea3 <sqlite3VdbeExec+0x14a03>
   63ea3:	mov    QWORD PTR [rsp+0x110],rdi
   63eab:	mov    rdi,rbx
   63eae:	mov    r10,rax
   63eb1:	call   r10
   63eb4:	mov    rcx,QWORD PTR [rip+0x0]        # 63ebb <sqlite3VdbeExec+0x14a1b>
   63ebb:	movsxd rax,eax
   63ebe:	sub    rcx,rax
   63ec1:	mov    QWORD PTR [rip+0x0],rcx        # 63ec8 <sqlite3VdbeExec+0x14a28>
   63ec8:	mov    rax,QWORD PTR [rip+0x0]        # 63ecf <sqlite3VdbeExec+0x14a2f>
   63ecf:	sub    rax,0x1
   63ed3:	mov    QWORD PTR [rip+0x0],rax        # 63eda <sqlite3VdbeExec+0x14a3a>
   63eda:	mov    rax,QWORD PTR [rip+0x0]        # 63ee1 <sqlite3VdbeExec+0x14a41>
   63ee1:	mov    rdi,rbx
   63ee4:	mov    r10,rax
   63ee7:	call   r10
   63eea:	mov    rdi,QWORD PTR [rsp+0x110]
   63ef2:	jmp    63f14 <sqlite3VdbeExec+0x14a74>
   63ef4:	mov    rax,QWORD PTR [rip+0x0]        # 63efb <sqlite3VdbeExec+0x14a5b>
   63efb:	mov    QWORD PTR [rsp+0x110],rdi
   63f03:	mov    rdi,rbx
   63f06:	mov    r10,rax
   63f09:	call   r10
   63f0c:	mov    rdi,QWORD PTR [rsp+0x110]
   63f14:	mov    QWORD PTR [r15+0x10],0x0
   63f1c:	mov    ebx,DWORD PTR [rsp+0x3a4]
   63f23:	test   ebx,ebx
   63f25:	je     63f47 <sqlite3VdbeExec+0x14aa7>
   63f27:	mov    QWORD PTR [rsp+0x148],rbp
   63f2f:	mov    rbp,rbx
   63f32:	mov    r13,QWORD PTR [rsp+0x130]
   63f3a:	mov    rbx,QWORD PTR [rsp+0x158]
   63f42:	jmp    4f712 <sqlite3VdbeExec+0x272>
   63f47:	mov    r12,QWORD PTR [rsp+0x180]
   63f4f:	mov    r15,QWORD PTR [rsp+0x188]
   63f57:	mov    rax,QWORD PTR [r15+0x50]
   63f5b:	mov    QWORD PTR [rsp+0x110],rdi
   63f63:	mov    rdi,r12
   63f66:	mov    r10,rax
   63f69:	call   r10
   63f6c:	mov    r12,QWORD PTR [rsp+0x168]
   63f74:	mov    BYTE PTR [r12+0x2],0x0
   63f7a:	mov    rdi,QWORD PTR [rsp+0x110]
   63f82:	test   eax,eax
   63f84:	je     63fa0 <sqlite3VdbeExec+0x14b00>
   63f86:	mov    r12,r14
   63f89:	mov    r15d,DWORD PTR [rsp+0x37c]
   63f91:	mov    DWORD PTR [rsp+0x38c],ebx
   63f98:	mov    rbx,r13
   63f9b:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   63fa0:	mov    DWORD PTR [rsp+0x38c],ebx
   63fa7:	mov    rbx,r13
   63faa:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   63faf:	mov    r15d,DWORD PTR [rsp+0x37c]
   63fb7:	mov    r13,QWORD PTR [rsp+0x150]
   63fbf:	mov    QWORD PTR [rsp+0x130],r12
   63fc7:	mov    r12d,DWORD PTR [rsp+0x394]
   63fcf:	mov    rax,QWORD PTR [rdi+0x78]
   63fd3:	movsxd rcx,DWORD PTR [rbp+0x4]
   63fd7:	mov    DWORD PTR [rsp+0x394],r12d
   63fdf:	mov    r12,QWORD PTR [rax+rcx*8]
   63fe3:	movsxd rax,DWORD PTR [rbp+0xc]
   63fe7:	imul   rax,rax,0x38
   63feb:	mov    QWORD PTR [rsp+0x150],r13
   63ff3:	lea    r13,[rbx+rax*1]
   63ff7:	cmp    BYTE PTR [r12+0x2],0x0
   63ffd:	je     6403b <sqlite3VdbeExec+0x14b9b>
   63fff:	movzx  eax,WORD PTR [r13+0x14]
   64004:	and    eax,0x9000
   64009:	test   eax,eax
   6400b:	je     64027 <sqlite3VdbeExec+0x14b87>
   6400d:	mov    QWORD PTR [rsp+0x110],rdi
   64015:	mov    rdi,r13
   64018:	call   6401d <sqlite3VdbeExec+0x14b7d>
   6401d:	mov    rdi,QWORD PTR [rsp+0x110]
   64025:	jmp    6402e <sqlite3VdbeExec+0x14b8e>
   64027:	mov    WORD PTR [r13+0x14],0x1
   6402e:	mov    DWORD PTR [rsp+0x37c],r15d
   64036:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   6403b:	mov    rax,QWORD PTR [r12+0x28]
   64040:	mov    QWORD PTR [rsp+0x160],rbx
   64048:	mov    rbx,QWORD PTR [rax]
   6404b:	mov    QWORD PTR [rsp+0x128],r14
   64053:	mov    r14,QWORD PTR [rbx]
   64056:	mov    QWORD PTR [rsp+0x168],rbx
   6405e:	lea    rbx,[rsp+0x210]
   64066:	mov    rax,rbx
   64069:	xor    ecx,ecx
   6406b:	mov    edx,0x30
   64070:	mov    QWORD PTR [rsp+0x110],rdi
   64078:	mov    rdi,rax
   6407b:	mov    rsi,rcx
   6407e:	call   64083 <sqlite3VdbeExec+0x14be3>
   64083:	mov    QWORD PTR [rsp+0x210],r13
   6408b:	mov    BYTE PTR [rsp+0x238],r15b
   64093:	mov    QWORD PTR [rsp+0x2b8],0x0
   6409f:	mov    DWORD PTR [rsp+0x2b4],0x1000000
   640aa:	lea    rbx,[rsp+0x2b0]
   640b2:	mov    rax,rbx
   640b5:	mov    QWORD PTR [rsp+0x218],rax
   640bd:	movzx  eax,WORD PTR [rbp+0x2]
   640c1:	and    eax,0x1
   640c4:	mov    rdi,QWORD PTR [rsp+0x110]
   640cc:	test   eax,eax
   640ce:	je     64108 <sqlite3VdbeExec+0x14c68>
   640d0:	movzx  eax,WORD PTR [r13+0x14]
   640d5:	and    eax,0x9000
   640da:	test   eax,eax
   640dc:	je     640f0 <sqlite3VdbeExec+0x14c50>
   640de:	mov    rdi,r13
   640e1:	call   640e6 <sqlite3VdbeExec+0x14c46>
   640e6:	mov    rdi,QWORD PTR [rsp+0x110]
   640ee:	jmp    640f7 <sqlite3VdbeExec+0x14c57>
   640f0:	mov    WORD PTR [r13+0x14],0x1
   640f7:	mov    WORD PTR [r13+0x14],0x401
   640fe:	mov    DWORD PTR [r13+0x0],0x0
   64106:	jmp    6411a <sqlite3VdbeExec+0x14c7a>
   64108:	movzx  eax,WORD PTR [r13+0x14]
   6410d:	and    eax,0xfffff240
   64112:	or     eax,0x1
   64115:	mov    WORD PTR [r13+0x14],ax
   6411a:	mov    rax,QWORD PTR [r14+0x58]
   6411e:	mov    rcx,QWORD PTR [r12+0x28]
   64123:	lea    r12,[rsp+0x210]
   6412b:	mov    rdx,r12
   6412e:	mov    esi,DWORD PTR [rbp+0x8]
   64131:	mov    QWORD PTR [rsp+0x110],rdi
   64139:	mov    rdi,rcx
   6413c:	mov    r10,rax
   6413f:	mov    r11,rsi
   64142:	mov    rsi,rdx
   64145:	mov    rdx,r11
   64148:	call   r10
   6414b:	mov    r14d,eax
   6414e:	mov    rdi,QWORD PTR [rsp+0x110]
   64156:	mov    rbx,QWORD PTR [rsp+0x168]
   6415e:	cmp    QWORD PTR [rbx+0x10],0x0
   64163:	jne    64172 <sqlite3VdbeExec+0x14cd2>
   64165:	mov    DWORD PTR [rsp+0x3a4],r14d
   6416d:	jmp    642e3 <sqlite3VdbeExec+0x14e43>
   64172:	mov    r12,QWORD PTR [rdi]
   64175:	mov    rax,QWORD PTR [rdi+0xa8]
   6417c:	test   rax,rax
   6417f:	je     64194 <sqlite3VdbeExec+0x14cf4>
   64181:	mov    rdi,r12
   64184:	mov    rsi,rax
   64187:	call   6418c <sqlite3VdbeExec+0x14cec>
   6418c:	mov    rdi,QWORD PTR [rsp+0x110]
   64194:	mov    DWORD PTR [rsp+0x3a4],r14d
   6419c:	mov    r14,QWORD PTR [rbx+0x10]
   641a0:	test   r14,r14
   641a3:	jne    641ad <sqlite3VdbeExec+0x14d0d>
   641a5:	xor    r12d,r12d
   641a8:	jmp    64246 <sqlite3VdbeExec+0x14da6>
   641ad:	mov    QWORD PTR [rsp+0x110],rdi
   641b5:	mov    rdi,r14
   641b8:	call   641bd <sqlite3VdbeExec+0x14d1d>
   641bd:	mov    QWORD PTR [rsp+0x180],r14
   641c5:	lea    r14,[rax+0x1]
   641c9:	mov    rdi,QWORD PTR [rsp+0x110]
   641d1:	test   r12,r12
   641d4:	je     641ee <sqlite3VdbeExec+0x14d4e>
   641d6:	mov    rdi,r12
   641d9:	mov    rsi,r14
   641dc:	call   641e1 <sqlite3VdbeExec+0x14d41>
   641e1:	mov    r12,rax
   641e4:	mov    rdi,QWORD PTR [rsp+0x110]
   641ec:	jmp    64201 <sqlite3VdbeExec+0x14d61>
   641ee:	mov    rdi,r14
   641f1:	call   641f6 <sqlite3VdbeExec+0x14d56>
   641f6:	mov    r12,rax
   641f9:	mov    rdi,QWORD PTR [rsp+0x110]
   64201:	test   r12,r12
   64204:	jne    64210 <sqlite3VdbeExec+0x14d70>
   64206:	mov    QWORD PTR [rsp+0x168],rbx
   6420e:	jmp    6423e <sqlite3VdbeExec+0x14d9e>
   64210:	mov    QWORD PTR [rsp+0x168],rbx
   64218:	mov    rbx,QWORD PTR [rsp+0x180]
   64220:	mov    QWORD PTR [rsp+0x110],rdi
   64228:	mov    rdi,r12
   6422b:	mov    rsi,rbx
   6422e:	mov    rdx,r14
   64231:	call   64236 <sqlite3VdbeExec+0x14d96>
   64236:	mov    rdi,QWORD PTR [rsp+0x110]
   6423e:	mov    rbx,QWORD PTR [rsp+0x168]
   64246:	mov    QWORD PTR [rdi+0xa8],r12
   6424d:	mov    r12,QWORD PTR [rbx+0x10]
   64251:	test   r12,r12
   64254:	je     642db <sqlite3VdbeExec+0x14e3b>
   6425a:	cmp    DWORD PTR [rip+0x0],0x0        # 64261 <sqlite3VdbeExec+0x14dc1>
   64261:	je     642bb <sqlite3VdbeExec+0x14e1b>
   64263:	mov    rax,QWORD PTR [rip+0x0]        # 6426a <sqlite3VdbeExec+0x14dca>
   6426a:	mov    QWORD PTR [rsp+0x110],rdi
   64272:	mov    rdi,r12
   64275:	mov    r10,rax
   64278:	call   r10
   6427b:	mov    rcx,QWORD PTR [rip+0x0]        # 64282 <sqlite3VdbeExec+0x14de2>
   64282:	movsxd rax,eax
   64285:	sub    rcx,rax
   64288:	mov    QWORD PTR [rip+0x0],rcx        # 6428f <sqlite3VdbeExec+0x14def>
   6428f:	mov    rax,QWORD PTR [rip+0x0]        # 64296 <sqlite3VdbeExec+0x14df6>
   64296:	sub    rax,0x1
   6429a:	mov    QWORD PTR [rip+0x0],rax        # 642a1 <sqlite3VdbeExec+0x14e01>
   642a1:	mov    rax,QWORD PTR [rip+0x0]        # 642a8 <sqlite3VdbeExec+0x14e08>
   642a8:	mov    rdi,r12
   642ab:	mov    r10,rax
   642ae:	call   r10
   642b1:	mov    rdi,QWORD PTR [rsp+0x110]
   642b9:	jmp    642db <sqlite3VdbeExec+0x14e3b>
   642bb:	mov    rax,QWORD PTR [rip+0x0]        # 642c2 <sqlite3VdbeExec+0x14e22>
   642c2:	mov    QWORD PTR [rsp+0x110],rdi
   642ca:	mov    rdi,r12
   642cd:	mov    r10,rax
   642d0:	call   r10
   642d3:	mov    rdi,QWORD PTR [rsp+0x110]
   642db:	mov    QWORD PTR [rbx+0x10],0x0
   642e3:	cmp    DWORD PTR [rsp+0x234],0x0
   642eb:	jg     642f9 <sqlite3VdbeExec+0x14e59>
   642ed:	mov    ebx,DWORD PTR [rsp+0x3a4]
   642f4:	jmp    6437b <sqlite3VdbeExec+0x14edb>
   642f9:	lea    rbx,[rip+0x0]        # 64300 <sqlite3VdbeExec+0x14e60>
   64300:	test   r13,r13
   64303:	jne    64309 <sqlite3VdbeExec+0x14e69>
   64305:	xor    eax,eax
   64307:	jmp    64357 <sqlite3VdbeExec+0x14eb7>
   64309:	movzx  eax,WORD PTR [r13+0x14]
   6430e:	and    eax,0x202
   64313:	cmp    eax,0x202
   64318:	jne    64327 <sqlite3VdbeExec+0x14e87>
   6431a:	cmp    BYTE PTR [r13+0x16],0x1
   6431f:	jne    64327 <sqlite3VdbeExec+0x14e87>
   64321:	mov    rax,QWORD PTR [r13+0x8]
   64325:	jmp    64357 <sqlite3VdbeExec+0x14eb7>
   64327:	movzx  eax,WORD PTR [r13+0x14]
   6432c:	and    eax,0x1
   6432f:	test   eax,eax
   64331:	je     64337 <sqlite3VdbeExec+0x14e97>
   64333:	xor    eax,eax
   64335:	jmp    64357 <sqlite3VdbeExec+0x14eb7>
   64337:	mov    eax,0x1
   6433c:	mov    QWORD PTR [rsp+0x110],rdi
   64344:	mov    rdi,r13
   64347:	mov    rsi,rax
   6434a:	call   6434f <sqlite3VdbeExec+0x14eaf>
   6434f:	mov    rdi,QWORD PTR [rsp+0x110]
   64357:	mov    QWORD PTR [rsp+0x110],rdi
   6435f:	mov    rsi,rbx
   64362:	mov    rdx,rax
   64365:	xor    eax,eax
   64367:	call   6436c <sqlite3VdbeExec+0x14ecc>
   6436c:	mov    ebx,DWORD PTR [rsp+0x234]
   64373:	mov    rdi,QWORD PTR [rsp+0x110]
   6437b:	mov    eax,r15d
   6437e:	movzx  ecx,WORD PTR [r13+0x14]
   64383:	and    ecx,0x2
   64386:	test   ecx,ecx
   64388:	jne    643ba <sqlite3VdbeExec+0x14f1a>
   6438a:	mov    BYTE PTR [r13+0x16],al
   6438e:	test   ebx,ebx
   64390:	je     643c7 <sqlite3VdbeExec+0x14f27>
   64392:	mov    r14,QWORD PTR [rsp+0x128]
   6439a:	mov    QWORD PTR [rsp+0x148],rbp
   643a2:	mov    rbp,rbx
   643a5:	mov    r13,QWORD PTR [rsp+0x130]
   643ad:	mov    rbx,QWORD PTR [rsp+0x158]
   643b5:	jmp    4f712 <sqlite3VdbeExec+0x272>
   643ba:	movzx  ecx,BYTE PTR [r13+0x16]
   643bf:	cmp    ecx,eax
   643c1:	jne    643eb <sqlite3VdbeExec+0x14f4b>
   643c3:	test   ebx,ebx
   643c5:	jne    64392 <sqlite3VdbeExec+0x14ef2>
   643c7:	mov    r14,QWORD PTR [rsp+0x128]
   643cf:	mov    DWORD PTR [rsp+0x37c],r15d
   643d7:	mov    DWORD PTR [rsp+0x38c],ebx
   643de:	mov    rbx,QWORD PTR [rsp+0x160]
   643e6:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   643eb:	mov    QWORD PTR [rsp+0x110],rdi
   643f3:	mov    rdi,r13
   643f6:	mov    rsi,rax
   643f9:	call   643fe <sqlite3VdbeExec+0x14f5e>
   643fe:	mov    rdi,QWORD PTR [rsp+0x110]
   64406:	test   ebx,ebx
   64408:	jne    64392 <sqlite3VdbeExec+0x14ef2>
   6440a:	jmp    643c7 <sqlite3VdbeExec+0x14f27>
   6440c:	mov    r15d,DWORD PTR [rsp+0x37c]
   64414:	mov    r13,QWORD PTR [rsp+0x150]
   6441c:	mov    QWORD PTR [rsp+0x130],r12
   64424:	mov    r12d,DWORD PTR [rsp+0x394]
   6442c:	mov    rax,QWORD PTR [rdi+0x78]
   64430:	movsxd rcx,DWORD PTR [rbp+0x4]
   64434:	mov    DWORD PTR [rsp+0x394],r12d
   6443c:	mov    r12,QWORD PTR [rax+rcx*8]
   64440:	cmp    BYTE PTR [r12+0x2],0x0
   64446:	je     6445d <sqlite3VdbeExec+0x14fbd>
   64448:	mov    DWORD PTR [rsp+0x37c],r15d
   64450:	mov    QWORD PTR [rsp+0x150],r13
   64458:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   6445d:	mov    rax,QWORD PTR [r12+0x28]
   64462:	mov    QWORD PTR [rsp+0x150],r13
   6446a:	mov    r13,QWORD PTR [rax]
   6446d:	mov    DWORD PTR [rsp+0x37c],r15d
   64475:	mov    r15,QWORD PTR [r13+0x0]
   64479:	mov    rax,QWORD PTR [r15+0x48]
   6447d:	mov    rcx,QWORD PTR [r12+0x28]
   64482:	mov    QWORD PTR [rsp+0x188],r15
   6448a:	mov    QWORD PTR [rsp+0x110],rdi
   64492:	mov    rdi,rcx
   64495:	mov    r10,rax
   64498:	call   r10
   6449b:	mov    r15d,eax
   6449e:	mov    rdi,QWORD PTR [rsp+0x110]
   644a6:	cmp    QWORD PTR [r13+0x10],0x0
   644ab:	jne    644ba <sqlite3VdbeExec+0x1501a>
   644ad:	mov    QWORD PTR [rsp+0x168],r12
   644b5:	jmp    6464f <sqlite3VdbeExec+0x151af>
   644ba:	mov    DWORD PTR [rsp+0x38c],r15d
   644c2:	mov    r15,QWORD PTR [rdi]
   644c5:	mov    rax,QWORD PTR [rdi+0xa8]
   644cc:	test   rax,rax
   644cf:	je     644e4 <sqlite3VdbeExec+0x15044>
   644d1:	mov    rdi,r15
   644d4:	mov    rsi,rax
   644d7:	call   644dc <sqlite3VdbeExec+0x1503c>
   644dc:	mov    rdi,QWORD PTR [rsp+0x110]
   644e4:	mov    QWORD PTR [rsp+0x168],r12
   644ec:	mov    r12,QWORD PTR [r13+0x10]
   644f0:	test   r12,r12
   644f3:	jne    64500 <sqlite3VdbeExec+0x15060>
   644f5:	xor    r12d,r12d
   644f8:	mov    r15,r12
   644fb:	jmp    64599 <sqlite3VdbeExec+0x150f9>
   64500:	mov    QWORD PTR [rsp+0x110],rdi
   64508:	mov    rdi,r12
   6450b:	call   64510 <sqlite3VdbeExec+0x15070>
   64510:	mov    QWORD PTR [rsp+0x190],r12
   64518:	lea    r12,[rax+0x1]
   6451c:	mov    rdi,QWORD PTR [rsp+0x110]
   64524:	test   r15,r15
   64527:	je     64541 <sqlite3VdbeExec+0x150a1>
   64529:	mov    rdi,r15
   6452c:	mov    rsi,r12
   6452f:	call   64534 <sqlite3VdbeExec+0x15094>
   64534:	mov    r15,rax
   64537:	mov    rdi,QWORD PTR [rsp+0x110]
   6453f:	jmp    64554 <sqlite3VdbeExec+0x150b4>
   64541:	mov    rdi,r12
   64544:	call   64549 <sqlite3VdbeExec+0x150a9>
   64549:	mov    r15,rax
   6454c:	mov    rdi,QWORD PTR [rsp+0x110]
   64554:	test   r15,r15
   64557:	jne    64563 <sqlite3VdbeExec+0x150c3>
   64559:	mov    QWORD PTR [rsp+0x180],r13
   64561:	jmp    64591 <sqlite3VdbeExec+0x150f1>
   64563:	mov    QWORD PTR [rsp+0x180],r13
   6456b:	mov    r13,QWORD PTR [rsp+0x190]
   64573:	mov    QWORD PTR [rsp+0x110],rdi
   6457b:	mov    rdi,r15
   6457e:	mov    rsi,r13
   64581:	mov    rdx,r12
   64584:	call   64589 <sqlite3VdbeExec+0x150e9>
   64589:	mov    rdi,QWORD PTR [rsp+0x110]
   64591:	mov    r13,QWORD PTR [rsp+0x180]
   64599:	mov    QWORD PTR [rdi+0xa8],r15
   645a0:	mov    r12,QWORD PTR [r13+0x10]
   645a4:	test   r12,r12
   645a7:	jne    645b6 <sqlite3VdbeExec+0x15116>
   645a9:	mov    r15d,DWORD PTR [rsp+0x38c]
   645b1:	jmp    64647 <sqlite3VdbeExec+0x151a7>
   645b6:	cmp    DWORD PTR [rip+0x0],0x0        # 645bd <sqlite3VdbeExec+0x1511d>
   645bd:	je     6461f <sqlite3VdbeExec+0x1517f>
   645bf:	mov    rax,QWORD PTR [rip+0x0]        # 645c6 <sqlite3VdbeExec+0x15126>
   645c6:	mov    QWORD PTR [rsp+0x110],rdi
   645ce:	mov    rdi,r12
   645d1:	mov    r10,rax
   645d4:	call   r10
   645d7:	mov    rcx,QWORD PTR [rip+0x0]        # 645de <sqlite3VdbeExec+0x1513e>
   645de:	movsxd rax,eax
   645e1:	sub    rcx,rax
   645e4:	mov    QWORD PTR [rip+0x0],rcx        # 645eb <sqlite3VdbeExec+0x1514b>
   645eb:	mov    rax,QWORD PTR [rip+0x0]        # 645f2 <sqlite3VdbeExec+0x15152>
   645f2:	sub    rax,0x1
   645f6:	mov    QWORD PTR [rip+0x0],rax        # 645fd <sqlite3VdbeExec+0x1515d>
   645fd:	mov    rax,QWORD PTR [rip+0x0]        # 64604 <sqlite3VdbeExec+0x15164>
   64604:	mov    rdi,r12
   64607:	mov    r10,rax
   6460a:	call   r10
   6460d:	mov    rdi,QWORD PTR [rsp+0x110]
   64615:	mov    r15d,DWORD PTR [rsp+0x38c]
   6461d:	jmp    64647 <sqlite3VdbeExec+0x151a7>
   6461f:	mov    r15d,DWORD PTR [rsp+0x38c]
   64627:	mov    rax,QWORD PTR [rip+0x0]        # 6462e <sqlite3VdbeExec+0x1518e>
   6462e:	mov    QWORD PTR [rsp+0x110],rdi
   64636:	mov    rdi,r12
   64639:	mov    r10,rax
   6463c:	call   r10
   6463f:	mov    rdi,QWORD PTR [rsp+0x110]
   64647:	mov    QWORD PTR [r13+0x10],0x0
   6464f:	test   r15d,r15d
   64652:	je     64674 <sqlite3VdbeExec+0x151d4>
   64654:	mov    QWORD PTR [rsp+0x148],rbp
   6465c:	mov    rbp,r15
   6465f:	mov    r13,QWORD PTR [rsp+0x130]
   64667:	mov    rbx,QWORD PTR [rsp+0x158]
   6466f:	jmp    4f712 <sqlite3VdbeExec+0x272>
   64674:	mov    r12,QWORD PTR [rsp+0x168]
   6467c:	mov    r13,QWORD PTR [rsp+0x188]
   64684:	mov    rax,QWORD PTR [r13+0x50]
   64688:	mov    rcx,QWORD PTR [r12+0x28]
   6468d:	mov    QWORD PTR [rsp+0x110],rdi
   64695:	mov    rdi,rcx
   64698:	mov    r10,rax
   6469b:	call   r10
   6469e:	mov    rdi,QWORD PTR [rsp+0x110]
   646a6:	test   eax,eax
   646a8:	jne    646cf <sqlite3VdbeExec+0x1522f>
   646aa:	mov    r13,QWORD PTR [rsp+0x150]
   646b2:	mov    r12d,DWORD PTR [rsp+0x394]
   646ba:	mov    DWORD PTR [rsp+0x38c],r15d
   646c2:	mov    r15d,DWORD PTR [rsp+0x37c]
   646ca:	jmp    4f7bd <sqlite3VdbeExec+0x31d>
   646cf:	mov    r12d,DWORD PTR [rsp+0x394]
   646d7:	mov    r13,QWORD PTR [rsp+0x150]
   646df:	mov    QWORD PTR [rsp+0x148],rbp
   646e7:	mov    DWORD PTR [rsp+0x38c],r15d
   646ef:	mov    r15d,DWORD PTR [rsp+0x37c]
   646f7:	mov    QWORD PTR [rsp+0x160],rbx
   646ff:	mov    ebx,DWORD PTR [rsp+0x390]
   64706:	jmp    4f7e6 <sqlite3VdbeExec+0x346>
   6470b:	mov    QWORD PTR [rsp+0x130],r12
   64713:	mov    rax,QWORD PTR [r14+0x30]
   64717:	and    rax,0x4000000
   6471d:	mov    r12d,eax
   64720:	mov    rax,QWORD PTR [r14+0x30]
   64724:	or     rax,0x4000000
   6472a:	mov    QWORD PTR [r14+0x30],rax
   6472e:	mov    rax,QWORD PTR [rbp+0x10]
   64732:	mov    r13,QWORD PTR [rax+0x10]
   64736:	movsxd rax,DWORD PTR [rbp+0x4]
   6473a:	imul   rax,rax,0x38
   6473e:	lea    r15,[rbx+rax*1]
   64742:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   64747:	and    eax,0x2
   6474a:	test   eax,eax
   6474c:	jne    64760 <sqlite3VdbeExec+0x152c0>
   6474e:	mov    BYTE PTR [r15+0x16],0x1
   64753:	mov    DWORD PTR [rsp+0x3a4],r12d
   6475b:	xor    r12d,r12d
   6475e:	jmp    6479f <sqlite3VdbeExec+0x152ff>
   64760:	cmp    BYTE PTR [r15+0x16],0x1
   64765:	jne    64774 <sqlite3VdbeExec+0x152d4>
   64767:	mov    DWORD PTR [rsp+0x3a4],r12d
   6476f:	xor    r12d,r12d
   64772:	jmp    6479f <sqlite3VdbeExec+0x152ff>
   64774:	mov    eax,0x1
   64779:	mov    DWORD PTR [rsp+0x3a4],r12d
   64781:	mov    QWORD PTR [rsp+0x110],rdi
   64789:	mov    rdi,r15
   6478c:	mov    rsi,rax
   6478f:	call   64794 <sqlite3VdbeExec+0x152f4>
   64794:	mov    r12d,eax
   64797:	mov    rdi,QWORD PTR [rsp+0x110]
   6479f:	test   r12d,r12d
   647a2:	je     647c4 <sqlite3VdbeExec+0x15324>
   647a4:	mov    QWORD PTR [rsp+0x148],rbp
   647ac:	mov    rbp,r12
   647af:	mov    r13,QWORD PTR [rsp+0x130]
   647b7:	mov    rbx,QWORD PTR [rsp+0x158]
   647bf:	jmp    4f712 <sqlite3VdbeExec+0x272>
   647c4:	mov    r12d,DWORD PTR [rsp+0x3a4]
   647cc:	mov    rax,QWORD PTR [r13+0x0]
   647d0:	mov    rax,QWORD PTR [rax+0x98]
   647d7:	mov    rcx,QWORD PTR [r15+0x8]
   647db:	mov    QWORD PTR [rsp+0x110],rdi
   647e3:	mov    rdi,r13
   647e6:	mov    rsi,rcx
   647e9:	mov    r10,rax
   647ec:	call   r10
   647ef:	mov    r15d,eax
   647f2:	mov    rdi,QWORD PTR [rsp+0x110]
   647fa:	test   r12d,r12d
   647fd:	jne    6480d <sqlite3VdbeExec+0x1536d>
   647ff:	mov    rax,QWORD PTR [r14+0x30]
   64803:	and    rax,0xfffffffffbffffff
   64809:	mov    QWORD PTR [r14+0x30],rax
   6480d:	cmp    QWORD PTR [r13+0x10],0x0
   64812:	je     649aa <sqlite3VdbeExec+0x1550a>
   64818:	mov    r12,QWORD PTR [rdi]
   6481b:	mov    rax,QWORD PTR [rdi+0xa8]
   64822:	test   rax,rax
   64825:	je     64842 <sqlite3VdbeExec+0x153a2>
   64827:	mov    QWORD PTR [rsp+0x110],rdi
   6482f:	mov    rdi,r12
   64832:	mov    rsi,rax
   64835:	call   6483a <sqlite3VdbeExec+0x1539a>
   6483a:	mov    rdi,QWORD PTR [rsp+0x110]
   64842:	mov    DWORD PTR [rsp+0x39c],r15d
   6484a:	mov    r15,QWORD PTR [r13+0x10]
   6484e:	test   r15,r15
   64851:	jne    6485b <sqlite3VdbeExec+0x153bb>
   64853:	xor    r12d,r12d
   64856:	jmp    648f4 <sqlite3VdbeExec+0x15454>
   6485b:	mov    QWORD PTR [rsp+0x110],rdi
   64863:	mov    rdi,r15
   64866:	call   6486b <sqlite3VdbeExec+0x153cb>
   6486b:	mov    QWORD PTR [rsp+0x188],r15
   64873:	lea    r15,[rax+0x1]
   64877:	mov    rdi,QWORD PTR [rsp+0x110]
   6487f:	test   r12,r12
   64882:	je     6489c <sqlite3VdbeExec+0x153fc>
   64884:	mov    rdi,r12
   64887:	mov    rsi,r15
   6488a:	call   6488f <sqlite3VdbeExec+0x153ef>
   6488f:	mov    r12,rax
   64892:	mov    rdi,QWORD PTR [rsp+0x110]
   6489a:	jmp    648af <sqlite3VdbeExec+0x1540f>
   6489c:	mov    rdi,r15
   6489f:	call   648a4 <sqlite3VdbeExec+0x15404>
   648a4:	mov    r12,rax
   648a7:	mov    rdi,QWORD PTR [rsp+0x110]
   648af:	test   r12,r12
   648b2:	jne    648be <sqlite3VdbeExec+0x1541e>
   648b4:	mov    QWORD PTR [rsp+0x168],r13
   648bc:	jmp    648ec <sqlite3VdbeExec+0x1544c>
   648be:	mov    QWORD PTR [rsp+0x168],r13
   648c6:	mov    r13,QWORD PTR [rsp+0x188]
   648ce:	mov    QWORD PTR [rsp+0x110],rdi
   648d6:	mov    rdi,r12
   648d9:	mov    rsi,r13
   648dc:	mov    rdx,r15
   648df:	call   648e4 <sqlite3VdbeExec+0x15444>
   648e4:	mov    rdi,QWORD PTR [rsp+0x110]
   648ec:	mov    r13,QWORD PTR [rsp+0x168]
   648f4:	mov    QWORD PTR [rdi+0xa8],r12
   648fb:	mov    r12,QWORD PTR [r13+0x10]
   648ff:	test   r12,r12
   64902:	jne    64911 <sqlite3VdbeExec+0x15471>
   64904:	mov    r15d,DWORD PTR [rsp+0x39c]
   6490c:	jmp    649a2 <sqlite3VdbeExec+0x15502>
   64911:	cmp    DWORD PTR [rip+0x0],0x0        # 64918 <sqlite3VdbeExec+0x15478>
   64918:	je     6497a <sqlite3VdbeExec+0x154da>
   6491a:	mov    rax,QWORD PTR [rip+0x0]        # 64921 <sqlite3VdbeExec+0x15481>
   64921:	mov    QWORD PTR [rsp+0x110],rdi
   64929:	mov    rdi,r12
   6492c:	mov    r10,rax
   6492f:	call   r10
   64932:	mov    rcx,QWORD PTR [rip+0x0]        # 64939 <sqlite3VdbeExec+0x15499>
   64939:	movsxd rax,eax
   6493c:	sub    rcx,rax
   6493f:	mov    QWORD PTR [rip+0x0],rcx        # 64946 <sqlite3VdbeExec+0x154a6>
   64946:	mov    rax,QWORD PTR [rip+0x0]        # 6494d <sqlite3VdbeExec+0x154ad>
   6494d:	sub    rax,0x1
   64951:	mov    QWORD PTR [rip+0x0],rax        # 64958 <sqlite3VdbeExec+0x154b8>
   64958:	mov    rax,QWORD PTR [rip+0x0]        # 6495f <sqlite3VdbeExec+0x154bf>
   6495f:	mov    rdi,r12
   64962:	mov    r10,rax
   64965:	call   r10
   64968:	mov    rdi,QWORD PTR [rsp+0x110]
   64970:	mov    r15d,DWORD PTR [rsp+0x39c]
   64978:	jmp    649a2 <sqlite3VdbeExec+0x15502>
   6497a:	mov    r15d,DWORD PTR [rsp+0x39c]
   64982:	mov    rax,QWORD PTR [rip+0x0]        # 64989 <sqlite3VdbeExec+0x154e9>
   64989:	mov    QWORD PTR [rsp+0x110],rdi
   64991:	mov    rdi,r12
   64994:	mov    r10,rax
   64997:	call   r10
   6499a:	mov    rdi,QWORD PTR [rsp+0x110]
   649a2:	mov    QWORD PTR [r13+0x10],0x0
   649aa:	movzx  eax,WORD PTR [rdi+0xc8]
   649b1:	and    rax,0xfffffffffffffffc
   649b5:	mov    WORD PTR [rdi+0xc8],ax
   649bc:	test   r15d,r15d
   649bf:	je     649e1 <sqlite3VdbeExec+0x15541>
   649c1:	mov    QWORD PTR [rsp+0x148],rbp
   649c9:	mov    rbp,r15
   649cc:	mov    r13,QWORD PTR [rsp+0x130]
   649d4:	mov    rbx,QWORD PTR [rsp+0x158]
   649dc:	jmp    4f712 <sqlite3VdbeExec+0x272>
   649e1:	mov    DWORD PTR [rsp+0x38c],r15d
   649e9:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   649ee:	mov    r15d,DWORD PTR [rsp+0x37c]
   649f6:	mov    r13,QWORD PTR [rsp+0x150]
   649fe:	mov    QWORD PTR [rsp+0x130],r12
   64a06:	mov    r12d,DWORD PTR [rsp+0x394]
   64a0e:	mov    QWORD PTR [rsp+0x168],0x0
   64a1a:	cmp    BYTE PTR [r14+0x67],0x0
   64a1f:	je     64a31 <sqlite3VdbeExec+0x15591>
   64a21:	mov    rbx,rbp
   64a24:	mov    rbp,QWORD PTR [rsp+0x158]
   64a2c:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   64a31:	mov    rax,QWORD PTR [rbp+0x10]
   64a35:	mov    QWORD PTR [rsp+0x150],r13
   64a3d:	mov    r13,QWORD PTR [rax+0x10]
   64a41:	test   r13,r13
   64a44:	je     64a4d <sqlite3VdbeExec+0x155ad>
   64a46:	cmp    QWORD PTR [r13+0x0],0x0
   64a4b:	jne    64a72 <sqlite3VdbeExec+0x155d2>
   64a4d:	mov    ebx,0x6
   64a52:	mov    QWORD PTR [rsp+0x148],rbp
   64a5a:	mov    rbp,rbx
   64a5d:	mov    r13,QWORD PTR [rsp+0x130]
   64a65:	mov    rbx,QWORD PTR [rsp+0x158]
   64a6d:	jmp    4f712 <sqlite3VdbeExec+0x272>
   64a72:	mov    rax,QWORD PTR [r13+0x0]
   64a76:	mov    ecx,DWORD PTR [rbp+0x8]
   64a79:	cmp    QWORD PTR [rax+0x68],0x0
   64a7e:	jne    64a8d <sqlite3VdbeExec+0x155ed>
   64a80:	mov    DWORD PTR [rsp+0x394],r12d
   64a88:	jmp    64d43 <sqlite3VdbeExec+0x158a3>
   64a8d:	mov    DWORD PTR [rsp+0x394],r12d
   64a95:	movzx  r12d,BYTE PTR [r14+0x6c]
   64a9a:	mov    rdx,QWORD PTR [rdi+0x70]
   64a9e:	movsxd rsi,DWORD PTR [rbp+0xc]
   64aa2:	imul   rsi,rsi,0x38
   64aa6:	add    rsi,rbx
   64aa9:	xor    r8d,r8d
   64aac:	mov    r11,rsi
   64aaf:	mov    rsi,r8
   64ab2:	mov    r8,r11
   64ab5:	jmp    64ac5 <sqlite3VdbeExec+0x15625>
   64ab7:	mov    r9,rsi
   64aba:	mov    QWORD PTR [rdx+r9*8],r8
   64abe:	add    r8,0x38
   64ac2:	add    esi,0x1
   64ac5:	cmp    esi,ecx
   64ac7:	jl     64ab7 <sqlite3VdbeExec+0x15617>
   64ac9:	movzx  esi,WORD PTR [rbp+0x2]
   64acd:	mov    BYTE PTR [r14+0x6c],sil
   64ad1:	mov    rax,QWORD PTR [rax+0x68]
   64ad5:	mov    DWORD PTR [rsp+0x37c],r15d
   64add:	lea    r15,[rsp+0x168]
   64ae5:	mov    rsi,r15
   64ae8:	mov    QWORD PTR [rsp+0x110],rdi
   64af0:	mov    rdi,r13
   64af3:	mov    r10,rax
   64af6:	mov    r11,rsi
   64af9:	mov    rsi,rcx
   64afc:	mov    rcx,r11
   64aff:	call   r10
   64b02:	mov    r15d,eax
   64b05:	mov    BYTE PTR [r14+0x6c],r12b
   64b09:	mov    rdi,QWORD PTR [rsp+0x110]
   64b11:	cmp    QWORD PTR [r13+0x10],0x0
   64b16:	je     64ca6 <sqlite3VdbeExec+0x15806>
   64b1c:	mov    r12,QWORD PTR [rdi]
   64b1f:	mov    rax,QWORD PTR [rdi+0xa8]
   64b26:	test   rax,rax
   64b29:	je     64b3e <sqlite3VdbeExec+0x1569e>
   64b2b:	mov    rdi,r12
   64b2e:	mov    rsi,rax
   64b31:	call   64b36 <sqlite3VdbeExec+0x15696>
   64b36:	mov    rdi,QWORD PTR [rsp+0x110]
   64b3e:	mov    DWORD PTR [rsp+0x39c],r15d
   64b46:	mov    r15,QWORD PTR [r13+0x10]
   64b4a:	test   r15,r15
   64b4d:	jne    64b57 <sqlite3VdbeExec+0x156b7>
   64b4f:	xor    r12d,r12d
   64b52:	jmp    64bf0 <sqlite3VdbeExec+0x15750>
   64b57:	mov    QWORD PTR [rsp+0x110],rdi
   64b5f:	mov    rdi,r15
   64b62:	call   64b67 <sqlite3VdbeExec+0x156c7>
   64b67:	mov    QWORD PTR [rsp+0x180],r15
   64b6f:	lea    r15,[rax+0x1]
   64b73:	mov    rdi,QWORD PTR [rsp+0x110]
   64b7b:	test   r12,r12
   64b7e:	je     64b98 <sqlite3VdbeExec+0x156f8>
   64b80:	mov    rdi,r12
   64b83:	mov    rsi,r15
   64b86:	call   64b8b <sqlite3VdbeExec+0x156eb>
   64b8b:	mov    r12,rax
   64b8e:	mov    rdi,QWORD PTR [rsp+0x110]
   64b96:	jmp    64bab <sqlite3VdbeExec+0x1570b>
   64b98:	mov    rdi,r15
   64b9b:	call   64ba0 <sqlite3VdbeExec+0x15700>
   64ba0:	mov    r12,rax
   64ba3:	mov    rdi,QWORD PTR [rsp+0x110]
   64bab:	test   r12,r12
   64bae:	jne    64bba <sqlite3VdbeExec+0x1571a>
   64bb0:	mov    QWORD PTR [rsp+0x188],r13
   64bb8:	jmp    64be8 <sqlite3VdbeExec+0x15748>
   64bba:	mov    QWORD PTR [rsp+0x188],r13
   64bc2:	mov    r13,QWORD PTR [rsp+0x180]
   64bca:	mov    QWORD PTR [rsp+0x110],rdi
   64bd2:	mov    rdi,r12
   64bd5:	mov    rsi,r13
   64bd8:	mov    rdx,r15
   64bdb:	call   64be0 <sqlite3VdbeExec+0x15740>
   64be0:	mov    rdi,QWORD PTR [rsp+0x110]
   64be8:	mov    r13,QWORD PTR [rsp+0x188]
   64bf0:	mov    QWORD PTR [rdi+0xa8],r12
   64bf7:	mov    r12,QWORD PTR [r13+0x10]
   64bfb:	test   r12,r12
   64bfe:	jne    64c0d <sqlite3VdbeExec+0x1576d>
   64c00:	mov    r15d,DWORD PTR [rsp+0x39c]
   64c08:	jmp    64c9e <sqlite3VdbeExec+0x157fe>
   64c0d:	cmp    DWORD PTR [rip+0x0],0x0        # 64c14 <sqlite3VdbeExec+0x15774>
   64c14:	je     64c76 <sqlite3VdbeExec+0x157d6>
   64c16:	mov    rax,QWORD PTR [rip+0x0]        # 64c1d <sqlite3VdbeExec+0x1577d>
   64c1d:	mov    QWORD PTR [rsp+0x110],rdi
   64c25:	mov    rdi,r12
   64c28:	mov    r10,rax
   64c2b:	call   r10
   64c2e:	mov    rcx,QWORD PTR [rip+0x0]        # 64c35 <sqlite3VdbeExec+0x15795>
   64c35:	movsxd rax,eax
   64c38:	sub    rcx,rax
   64c3b:	mov    QWORD PTR [rip+0x0],rcx        # 64c42 <sqlite3VdbeExec+0x157a2>
   64c42:	mov    rax,QWORD PTR [rip+0x0]        # 64c49 <sqlite3VdbeExec+0x157a9>
   64c49:	sub    rax,0x1
   64c4d:	mov    QWORD PTR [rip+0x0],rax        # 64c54 <sqlite3VdbeExec+0x157b4>
   64c54:	mov    rax,QWORD PTR [rip+0x0]        # 64c5b <sqlite3VdbeExec+0x157bb>
   64c5b:	mov    rdi,r12
   64c5e:	mov    r10,rax
   64c61:	call   r10
   64c64:	mov    rdi,QWORD PTR [rsp+0x110]
   64c6c:	mov    r15d,DWORD PTR [rsp+0x39c]
   64c74:	jmp    64c9e <sqlite3VdbeExec+0x157fe>
   64c76:	mov    r15d,DWORD PTR [rsp+0x39c]
   64c7e:	mov    rax,QWORD PTR [rip+0x0]        # 64c85 <sqlite3VdbeExec+0x157e5>
   64c85:	mov    QWORD PTR [rsp+0x110],rdi
   64c8d:	mov    rdi,r12
   64c90:	mov    r10,rax
   64c93:	call   r10
   64c96:	mov    rdi,QWORD PTR [rsp+0x110]
   64c9e:	mov    QWORD PTR [r13+0x10],0x0
   64ca6:	test   r15d,r15d
   64ca9:	jne    64cbd <sqlite3VdbeExec+0x1581d>
   64cab:	cmp    DWORD PTR [rbp+0x4],0x0
   64caf:	je     64cbd <sqlite3VdbeExec+0x1581d>
   64cb1:	mov    rax,QWORD PTR [rsp+0x168]
   64cb9:	mov    QWORD PTR [r14+0x38],rax
   64cbd:	mov    eax,r15d
   64cc0:	and    eax,0xff
   64cc5:	cmp    eax,0x13
   64cc8:	jne    64d00 <sqlite3VdbeExec+0x15860>
   64cca:	mov    rax,QWORD PTR [rbp+0x10]
   64cce:	cmp    BYTE PTR [rax+0x1c],0x0
   64cd2:	je     64d00 <sqlite3VdbeExec+0x15860>
   64cd4:	cmp    WORD PTR [rbp+0x2],0x4
   64cd9:	jne    64ce3 <sqlite3VdbeExec+0x15843>
   64cdb:	xor    r12d,r12d
   64cde:	mov    r15,r12
   64ce1:	jmp    64cfe <sqlite3VdbeExec+0x1585e>
   64ce3:	cmp    WORD PTR [rbp+0x2],0x5
   64ce8:	jne    64cf1 <sqlite3VdbeExec+0x15851>
   64cea:	mov    eax,0x2
   64cef:	jmp    64cf8 <sqlite3VdbeExec+0x15858>
   64cf1:	movzx  eax,WORD PTR [rbp+0x2]
   64cf5:	movzx  eax,al
   64cf8:	mov    BYTE PTR [rdi+0xc4],al
   64cfe:	jmp    64d0c <sqlite3VdbeExec+0x1586c>
   64d00:	mov    rax,QWORD PTR [rdi+0x38]
   64d04:	add    rax,0x1
   64d08:	mov    QWORD PTR [rdi+0x38],rax
   64d0c:	test   r15d,r15d
   64d0f:	jne    64d23 <sqlite3VdbeExec+0x15883>
   64d11:	mov    DWORD PTR [rsp+0x38c],r15d
   64d19:	mov    r15d,DWORD PTR [rsp+0x37c]
   64d21:	jmp    64d43 <sqlite3VdbeExec+0x158a3>
   64d23:	mov    QWORD PTR [rsp+0x148],rbp
   64d2b:	mov    rbp,r15
   64d2e:	mov    r13,QWORD PTR [rsp+0x130]
   64d36:	mov    rbx,QWORD PTR [rsp+0x158]
   64d3e:	jmp    4f712 <sqlite3VdbeExec+0x272>
   64d43:	mov    DWORD PTR [rsp+0x37c],r15d
   64d4b:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   64d50:	mov    r15d,DWORD PTR [rsp+0x37c]
   64d58:	mov    r13,QWORD PTR [rsp+0x150]
   64d60:	mov    QWORD PTR [rsp+0x130],r12
   64d68:	mov    r12d,DWORD PTR [rsp+0x394]
   64d70:	mov    rax,QWORD PTR [rdi+0x68]
   64d74:	movsxd rcx,DWORD PTR [rbp+0x8]
   64d78:	imul   rcx,rcx,0x38
   64d7c:	lea    rdx,[rax+rcx*1]
   64d80:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   64d85:	and    eax,0x9000
   64d8a:	test   eax,eax
   64d8c:	je     64dab <sqlite3VdbeExec+0x1590b>
   64d8e:	mov    QWORD PTR [rsp+0x110],rdi
   64d96:	mov    rdi,rdx
   64d99:	call   64d9e <sqlite3VdbeExec+0x158fe>
   64d9e:	mov    rdi,QWORD PTR [rsp+0x110]
   64da6:	mov    rdx,rax
   64da9:	jmp    64db1 <sqlite3VdbeExec+0x15911>
   64dab:	mov    WORD PTR [rdx+0x14],0x4
   64db1:	mov    rax,QWORD PTR [r14+0x20]
   64db5:	movsxd rcx,DWORD PTR [rbp+0x4]
   64db9:	shl    rcx,0x5
   64dbd:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   64dc2:	mov    rax,QWORD PTR [rax+0x8]
   64dc6:	mov    eax,DWORD PTR [rax+0x40]
   64dc9:	mov    QWORD PTR [rdx],rax
   64dcc:	mov    DWORD PTR [rsp+0x37c],r15d
   64dd4:	mov    QWORD PTR [rsp+0x150],r13
   64ddc:	mov    DWORD PTR [rsp+0x394],r12d
   64de4:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   64de9:	mov    r15d,DWORD PTR [rsp+0x37c]
   64df1:	mov    r13,QWORD PTR [rsp+0x150]
   64df9:	mov    QWORD PTR [rsp+0x130],r12
   64e01:	mov    r12d,DWORD PTR [rsp+0x394]
   64e09:	mov    rax,QWORD PTR [rdi+0x68]
   64e0d:	movsxd rcx,DWORD PTR [rbp+0x8]
   64e11:	imul   rcx,rcx,0x38
   64e15:	lea    rdx,[rax+rcx*1]
   64e19:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   64e1e:	and    eax,0x9000
   64e23:	test   eax,eax
   64e25:	je     64e44 <sqlite3VdbeExec+0x159a4>
   64e27:	mov    QWORD PTR [rsp+0x110],rdi
   64e2f:	mov    rdi,rdx
   64e32:	call   64e37 <sqlite3VdbeExec+0x15997>
   64e37:	mov    rdi,QWORD PTR [rsp+0x110]
   64e3f:	mov    rdx,rax
   64e42:	jmp    64e4a <sqlite3VdbeExec+0x159aa>
   64e44:	mov    WORD PTR [rdx+0x14],0x4
   64e4a:	mov    rax,QWORD PTR [r14+0x20]
   64e4e:	movsxd rcx,DWORD PTR [rbp+0x4]
   64e52:	shl    rcx,0x5
   64e56:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   64e5b:	xor    ecx,ecx
   64e5d:	cmp    DWORD PTR [rbp+0xc],0x0
   64e61:	je     64e72 <sqlite3VdbeExec+0x159d2>
   64e63:	mov    rcx,QWORD PTR [rax+0x8]
   64e67:	mov    ecx,DWORD PTR [rcx+0x40]
   64e6a:	cmp    ecx,DWORD PTR [rbp+0xc]
   64e6d:	jae    64e72 <sqlite3VdbeExec+0x159d2>
   64e6f:	mov    ecx,DWORD PTR [rbp+0xc]
   64e72:	mov    rsi,QWORD PTR [rax+0x8]
   64e76:	mov    r8,QWORD PTR [rax]
   64e79:	mov    QWORD PTR [rsi+0x8],r8
   64e7d:	mov    rax,QWORD PTR [rax+0x8]
   64e81:	mov    rax,QWORD PTR [rax]
   64e84:	test   ecx,ecx
   64e86:	jbe    64e8e <sqlite3VdbeExec+0x159ee>
   64e88:	mov    DWORD PTR [rax+0xbc],ecx
   64e8e:	mov    eax,DWORD PTR [rax+0xbc]
   64e94:	mov    QWORD PTR [rdx],rax
   64e97:	mov    DWORD PTR [rsp+0x37c],r15d
   64e9f:	mov    QWORD PTR [rsp+0x150],r13
   64ea7:	mov    DWORD PTR [rsp+0x394],r12d
   64eaf:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   64eb4:	mov    r15d,DWORD PTR [rsp+0x37c]
   64ebc:	mov    r13,QWORD PTR [rsp+0x150]
   64ec4:	mov    QWORD PTR [rsp+0x130],r12
   64ecc:	mov    r12d,DWORD PTR [rsp+0x394]
   64ed4:	mov    DWORD PTR [rsp+0x394],r12d
   64edc:	mov    r12,QWORD PTR [rbp+0x10]
   64ee0:	movsxd rax,DWORD PTR [rbp+0xc]
   64ee4:	imul   rax,rax,0x38
   64ee8:	mov    QWORD PTR [rsp+0x150],r13
   64ef0:	lea    r13,[rbx+rax*1]
   64ef4:	cmp    r13,QWORD PTR [r12]
   64ef8:	je     64f31 <sqlite3VdbeExec+0x15a91>
   64efa:	mov    QWORD PTR [r12+0x18],rdi
   64eff:	mov    QWORD PTR [r12],r13
   64f03:	mov    BYTE PTR [r12+0x28],r15b
   64f08:	movzx  eax,WORD PTR [r12+0x2a]
   64f0e:	sub    eax,0x1
   64f11:	jmp    64f2d <sqlite3VdbeExec+0x15a8d>
   64f13:	mov    rcx,rax
   64f16:	mov    edx,eax
   64f18:	add    edx,DWORD PTR [rbp+0x8]
   64f1b:	movsxd rdx,edx
   64f1e:	imul   rdx,rdx,0x38
   64f22:	add    rdx,rbx
   64f25:	mov    QWORD PTR [r12+rcx*8+0x30],rdx
   64f2a:	sub    eax,0x1
   64f2d:	test   eax,eax
   64f2f:	jge    64f13 <sqlite3VdbeExec+0x15a73>
   64f31:	movzx  eax,WORD PTR [r13+0x14]
   64f36:	and    eax,0xfffff240
   64f3b:	or     eax,0x1
   64f3e:	mov    WORD PTR [r13+0x14],ax
   64f43:	mov    rax,QWORD PTR [r12+0x8]
   64f48:	mov    rax,QWORD PTR [rax+0x18]
   64f4c:	movzx  ecx,WORD PTR [r12+0x2a]
   64f52:	lea    rdx,[r12+0x30]
   64f57:	mov    QWORD PTR [rsp+0x110],rdi
   64f5f:	mov    rdi,r12
   64f62:	mov    rsi,rcx
   64f65:	mov    r10,rax
   64f68:	call   r10
   64f6b:	mov    rdi,QWORD PTR [rsp+0x110]
   64f73:	cmp    DWORD PTR [r12+0x24],0x0
   64f79:	je     651d3 <sqlite3VdbeExec+0x15d33>
   64f7f:	cmp    DWORD PTR [r12+0x24],0x0
   64f85:	jle    65013 <sqlite3VdbeExec+0x15b73>
   64f8b:	test   r13,r13
   64f8e:	jne    64f94 <sqlite3VdbeExec+0x15af4>
   64f90:	xor    eax,eax
   64f92:	jmp    64fe2 <sqlite3VdbeExec+0x15b42>
   64f94:	movzx  eax,WORD PTR [r13+0x14]
   64f99:	and    eax,0x202
   64f9e:	cmp    eax,0x202
   64fa3:	jne    64fb2 <sqlite3VdbeExec+0x15b12>
   64fa5:	cmp    BYTE PTR [r13+0x16],0x1
   64faa:	jne    64fb2 <sqlite3VdbeExec+0x15b12>
   64fac:	mov    rax,QWORD PTR [r13+0x8]
   64fb0:	jmp    64fe2 <sqlite3VdbeExec+0x15b42>
   64fb2:	movzx  eax,WORD PTR [r13+0x14]
   64fb7:	and    eax,0x1
   64fba:	test   eax,eax
   64fbc:	je     64fc2 <sqlite3VdbeExec+0x15b22>
   64fbe:	xor    eax,eax
   64fc0:	jmp    64fe2 <sqlite3VdbeExec+0x15b42>
   64fc2:	mov    eax,0x1
   64fc7:	mov    QWORD PTR [rsp+0x110],rdi
   64fcf:	mov    rdi,r13
   64fd2:	mov    rsi,rax
   64fd5:	call   64fda <sqlite3VdbeExec+0x15b3a>
   64fda:	mov    rdi,QWORD PTR [rsp+0x110]
   64fe2:	lea    r13,[rip+0x0]        # 64fe9 <sqlite3VdbeExec+0x15b49>
   64fe9:	mov    QWORD PTR [rsp+0x110],rdi
   64ff1:	mov    rsi,r13
   64ff4:	mov    rdx,rax
   64ff7:	xor    eax,eax
   64ff9:	call   64ffe <sqlite3VdbeExec+0x15b5e>
   64ffe:	mov    r13d,DWORD PTR [r12+0x24]
   65003:	mov    rdi,QWORD PTR [rsp+0x110]
   6500b:	mov    DWORD PTR [rsp+0x38c],r13d
   65013:	lea    r13,[rdi+0x128]
   6501a:	mov    QWORD PTR [rsp+0x168],r13
   65022:	mov    r13d,DWORD PTR [r12+0x20]
   65027:	mov    DWORD PTR [rsp+0x39c],r13d
   6502f:	mov    r13d,DWORD PTR [rbp+0x4]
   65033:	mov    DWORD PTR [rsp+0x3a4],r13d
   6503b:	mov    r13,QWORD PTR [rsp+0x168]
   65043:	jmp    65049 <sqlite3VdbeExec+0x15ba9>
   65045:	add    r13,0x18
   65049:	cmp    QWORD PTR [r13+0x0],0x0
   6504e:	je     65181 <sqlite3VdbeExec+0x15ce1>
   65054:	mov    QWORD PTR [rsp+0x148],rbp
   6505c:	mov    rbp,QWORD PTR [r13+0x0]
   65060:	mov    DWORD PTR [rsp+0x37c],r15d
   65068:	mov    r15d,DWORD PTR [rsp+0x39c]
   65070:	test   r15d,r15d
   65073:	jge    65082 <sqlite3VdbeExec+0x15be2>
   65075:	mov    r15d,DWORD PTR [rsp+0x3a4]
   6507d:	jmp    65114 <sqlite3VdbeExec+0x15c74>
   65082:	cmp    r15d,DWORD PTR [rbp+0x0]
   65086:	je     650a5 <sqlite3VdbeExec+0x15c05>
   65088:	mov    DWORD PTR [rsp+0x39c],r15d
   65090:	mov    r15d,DWORD PTR [rsp+0x37c]
   65098:	mov    r13,rbp
   6509b:	mov    rbp,QWORD PTR [rsp+0x148]
   650a3:	jmp    65045 <sqlite3VdbeExec+0x15ba5>
   650a5:	cmp    DWORD PTR [rbp+0x4],0x0
   650a9:	jge    650cb <sqlite3VdbeExec+0x15c2b>
   650ab:	mov    DWORD PTR [rsp+0x39c],r15d
   650b3:	mov    r15d,DWORD PTR [rsp+0x37c]
   650bb:	mov    r13,rbp
   650be:	mov    rbp,QWORD PTR [rsp+0x148]
   650c6:	jmp    65045 <sqlite3VdbeExec+0x15ba5>
   650cb:	cmp    DWORD PTR [rbp+0x4],0x1f
   650cf:	jle    650e3 <sqlite3VdbeExec+0x15c43>
   650d1:	mov    DWORD PTR [rsp+0x39c],r15d
   650d9:	mov    r15d,DWORD PTR [rsp+0x3a4]
   650e1:	jmp    65114 <sqlite3VdbeExec+0x15c74>
   650e3:	mov    eax,0x1
   650e8:	mov    ecx,DWORD PTR [rbp+0x4]
   650eb:	shl    eax,cl
   650ed:	mov    r15d,DWORD PTR [rsp+0x3a4]
   650f5:	and    eax,r15d
   650f8:	test   eax,eax
   650fa:	je     65114 <sqlite3VdbeExec+0x15c74>
   650fc:	mov    r15d,DWORD PTR [rsp+0x37c]
   65104:	mov    r13,rbp
   65107:	mov    rbp,QWORD PTR [rsp+0x148]
   6510f:	jmp    65045 <sqlite3VdbeExec+0x15ba5>
   65114:	cmp    QWORD PTR [rbp+0x10],0x0
   65119:	je     6513c <sqlite3VdbeExec+0x15c9c>
   6511b:	mov    rax,QWORD PTR [rbp+0x10]
   6511f:	mov    rcx,QWORD PTR [rbp+0x8]
   65123:	mov    QWORD PTR [rsp+0x110],rdi
   6512b:	mov    rdi,rcx
   6512e:	mov    r10,rax
   65131:	call   r10
   65134:	mov    rdi,QWORD PTR [rsp+0x110]
   6513c:	mov    rax,QWORD PTR [rbp+0x18]
   65140:	mov    QWORD PTR [r13+0x0],rax
   65144:	test   rbp,rbp
   65147:	je     65164 <sqlite3VdbeExec+0x15cc4>
   65149:	mov    QWORD PTR [rsp+0x110],rdi
   65151:	mov    rdi,r14
   65154:	mov    rsi,rbp
   65157:	call   6515c <sqlite3VdbeExec+0x15cbc>
   6515c:	mov    rdi,QWORD PTR [rsp+0x110]
   65164:	mov    DWORD PTR [rsp+0x3a4],r15d
   6516c:	mov    r15d,DWORD PTR [rsp+0x37c]
   65174:	mov    rbp,QWORD PTR [rsp+0x148]
   6517c:	jmp    65049 <sqlite3VdbeExec+0x15ba9>
   65181:	mov    DWORD PTR [rsp+0x37c],r15d
   65189:	mov    QWORD PTR [rsp+0x148],rbp
   65191:	mov    DWORD PTR [r12+0x24],0x0
   6519a:	mov    ebp,DWORD PTR [rsp+0x38c]
   651a1:	test   ebp,ebp
   651a3:	jne    651be <sqlite3VdbeExec+0x15d1e>
   651a5:	mov    r15d,DWORD PTR [rsp+0x37c]
   651ad:	mov    DWORD PTR [rsp+0x38c],ebp
   651b4:	mov    rbp,QWORD PTR [rsp+0x148]
   651bc:	jmp    651d3 <sqlite3VdbeExec+0x15d33>
   651be:	mov    r13,QWORD PTR [rsp+0x130]
   651c6:	mov    rbx,QWORD PTR [rsp+0x158]
   651ce:	jmp    4f712 <sqlite3VdbeExec+0x272>
   651d3:	mov    DWORD PTR [rsp+0x37c],r15d
   651db:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   651e0:	mov    r15d,DWORD PTR [rsp+0x37c]
   651e8:	mov    r13,QWORD PTR [rsp+0x150]
   651f0:	mov    QWORD PTR [rsp+0x130],r12
   651f8:	mov    r12d,DWORD PTR [rsp+0x394]
   65200:	movsxd rax,DWORD PTR [rbp+0x4]
   65204:	imul   rax,rax,0x38
   65208:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   6520d:	and    ecx,0xfffff7ff
   65213:	mov    WORD PTR [rbx+rax*1+0x14],cx
   65218:	mov    DWORD PTR [rsp+0x37c],r15d
   65220:	mov    QWORD PTR [rsp+0x150],r13
   65228:	mov    DWORD PTR [rsp+0x394],r12d
   65230:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   65235:	mov    r15d,DWORD PTR [rsp+0x37c]
   6523d:	mov    r13,QWORD PTR [rsp+0x150]
   65245:	mov    QWORD PTR [rsp+0x130],r12
   6524d:	mov    r12d,DWORD PTR [rsp+0x394]
   65255:	movsxd rax,DWORD PTR [rbp+0x4]
   65259:	imul   rax,rax,0x38
   6525d:	movsxd rcx,DWORD PTR [rbp+0x8]
   65261:	imul   rcx,rcx,0x38
   65265:	add    rcx,rbx
   65268:	movzx  edx,WORD PTR [rbx+rax*1+0x14]
   6526d:	and    edx,0x800
   65273:	test   edx,edx
   65275:	je     652b2 <sqlite3VdbeExec+0x15e12>
   65277:	movzx  eax,BYTE PTR [rbx+rax*1+0x17]
   6527c:	movzx  edx,WORD PTR [rcx+0x14]
   65280:	and    edx,0x9000
   65286:	test   edx,edx
   65288:	je     652a7 <sqlite3VdbeExec+0x15e07>
   6528a:	mov    QWORD PTR [rsp+0x110],rdi
   65292:	mov    rdi,rcx
   65295:	mov    rsi,rax
   65298:	call   6529d <sqlite3VdbeExec+0x15dfd>
   6529d:	mov    rdi,QWORD PTR [rsp+0x110]
   652a5:	jmp    652df <sqlite3VdbeExec+0x15e3f>
   652a7:	mov    QWORD PTR [rcx],rax
   652aa:	mov    WORD PTR [rcx+0x14],0x4
   652b0:	jmp    652df <sqlite3VdbeExec+0x15e3f>
   652b2:	movzx  eax,WORD PTR [rcx+0x14]
   652b6:	and    eax,0x9000
   652bb:	test   eax,eax
   652bd:	je     652d9 <sqlite3VdbeExec+0x15e39>
   652bf:	mov    QWORD PTR [rsp+0x110],rdi
   652c7:	mov    rdi,rcx
   652ca:	call   652cf <sqlite3VdbeExec+0x15e2f>
   652cf:	mov    rdi,QWORD PTR [rsp+0x110]
   652d7:	jmp    652df <sqlite3VdbeExec+0x15e3f>
   652d9:	mov    WORD PTR [rcx+0x14],0x1
   652df:	mov    DWORD PTR [rsp+0x37c],r15d
   652e7:	mov    QWORD PTR [rsp+0x150],r13
   652ef:	mov    DWORD PTR [rsp+0x394],r12d
   652f7:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   652fc:	mov    r15d,DWORD PTR [rsp+0x37c]
   65304:	mov    r13,QWORD PTR [rsp+0x150]
   6530c:	mov    QWORD PTR [rsp+0x130],r12
   65314:	mov    r12d,DWORD PTR [rsp+0x394]
   6531c:	movsxd rax,DWORD PTR [rbp+0x4]
   65320:	imul   rax,rax,0x38
   65324:	movsxd rcx,DWORD PTR [rbp+0x8]
   65328:	imul   rcx,rcx,0x38
   6532c:	movzx  edx,WORD PTR [rbx+rax*1+0x14]
   65331:	and    edx,0x1
   65334:	test   edx,edx
   65336:	je     65349 <sqlite3VdbeExec+0x15ea9>
   65338:	movzx  eax,WORD PTR [rbx+rcx*1+0x14]
   6533d:	and    eax,0xfffff7ff
   65342:	mov    WORD PTR [rbx+rcx*1+0x14],ax
   65347:	jmp    65367 <sqlite3VdbeExec+0x15ec7>
   65349:	movzx  edx,WORD PTR [rbx+rcx*1+0x14]
   6534e:	or     edx,0x800
   65354:	mov    WORD PTR [rbx+rcx*1+0x14],dx
   65359:	mov    rax,QWORD PTR [rbx+rax*1]
   6535d:	and    rax,0xff
   65363:	mov    BYTE PTR [rbx+rcx*1+0x17],al
   65367:	mov    DWORD PTR [rsp+0x37c],r15d
   6536f:	mov    QWORD PTR [rsp+0x150],r13
   65377:	mov    DWORD PTR [rsp+0x394],r12d
   6537f:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   65384:	mov    r15d,DWORD PTR [rsp+0x37c]
   6538c:	mov    r13,QWORD PTR [rsp+0x150]
   65394:	mov    QWORD PTR [rsp+0x130],r12
   6539c:	mov    r12d,DWORD PTR [rsp+0x394]
   653a4:	movsxd rax,DWORD PTR [rbp+0x4]
   653a8:	mov    DWORD PTR [rsp+0x394],r12d
   653b0:	imul   r12,rax,0x38
   653b4:	mov    QWORD PTR [rsp+0x168],r12
   653bc:	movsxd r12,DWORD PTR [rbp+0xc]
   653c0:	mov    QWORD PTR [rsp+0x188],r12
   653c8:	add    r12d,DWORD PTR [rbp+0x10]
   653cc:	mov    DWORD PTR [rsp+0x37c],r15d
   653d4:	mov    DWORD PTR [rsp+0x3a4],r12d
   653dc:	mov    r12,QWORD PTR [rsp+0x188]
   653e4:	xor    r15d,r15d
   653e7:	jmp    654f9 <sqlite3VdbeExec+0x16059>
   653ec:	mov    DWORD PTR [rsp+0x3a4],r13d
   653f4:	mov    QWORD PTR [rsp+0x188],r12
   653fc:	mov    r12,r15
   653ff:	mov    r15d,DWORD PTR [rsp+0x37c]
   65407:	mov    rax,rcx
   6540a:	mov    r13,QWORD PTR [rsp+0x150]
   65412:	movzx  ecx,WORD PTR [rax+0x14]
   65416:	and    ecx,0x8
   65419:	test   ecx,ecx
   6541b:	je     654bb <sqlite3VdbeExec+0x1601b>
   65421:	movzx  ecx,WORD PTR [rax+0x14]
   65425:	mov    edx,ecx
   65427:	and    edx,0x24
   6542a:	test   edx,edx
   6542c:	je     65436 <sqlite3VdbeExec+0x15f96>
   6542e:	mov    rax,QWORD PTR [rax]
   65431:	jmp    654b6 <sqlite3VdbeExec+0x16016>
   65436:	mov    edx,ecx
   65438:	and    edx,0x8
   6543b:	test   edx,edx
   6543d:	je     6548c <sqlite3VdbeExec+0x15fec>
   6543f:	movsd  xmm1,QWORD PTR [rax]
   65443:	movabs r11,0xc3dfffffffffffff
   6544d:	movq   xmm0,r11
   65452:	ucomisd xmm0,xmm1
   65456:	jbe    65464 <sqlite3VdbeExec+0x15fc4>
   65458:	movabs rax,0x8000000000000000
   65462:	jmp    6548a <sqlite3VdbeExec+0x15fea>
   65464:	movabs r11,0x43dfffffffffffff
   6546e:	movq   xmm0,r11
   65473:	ucomisd xmm1,xmm0
   65477:	jbe    65485 <sqlite3VdbeExec+0x15fe5>
   65479:	movabs rax,0x7fffffffffffffff
   65483:	jmp    6548a <sqlite3VdbeExec+0x15fea>
   65485:	cvttsd2si rax,xmm1
   6548a:	jmp    654b6 <sqlite3VdbeExec+0x16016>
   6548c:	and    ecx,0x12
   6548f:	test   ecx,ecx
   65491:	je     654b4 <sqlite3VdbeExec+0x16014>
   65493:	cmp    QWORD PTR [rax+0x8],0x0
   65498:	je     654b4 <sqlite3VdbeExec+0x16014>
   6549a:	mov    QWORD PTR [rsp+0x110],rdi
   654a2:	mov    rdi,rax
   654a5:	call   654aa <sqlite3VdbeExec+0x1600a>
   654aa:	mov    rdi,QWORD PTR [rsp+0x110]
   654b2:	jmp    654b6 <sqlite3VdbeExec+0x16016>
   654b4:	xor    eax,eax
   654b6:	add    r12,rax
   654b9:	jmp    654d5 <sqlite3VdbeExec+0x16035>
   654bb:	movzx  ecx,WORD PTR [rax+0x14]
   654bf:	and    ecx,0x12
   654c2:	test   ecx,ecx
   654c4:	je     654d5 <sqlite3VdbeExec+0x16035>
   654c6:	movzx  eax,WORD PTR [rax+0x14]
   654ca:	and    eax,0x12
   654cd:	add    eax,0xffd
   654d2:	add    r12,rax
   654d5:	mov    QWORD PTR [rsp+0x180],r12
   654dd:	mov    r12,QWORD PTR [rsp+0x188]
   654e5:	add    r12d,0x1
   654e9:	mov    DWORD PTR [rsp+0x37c],r15d
   654f1:	mov    r15,QWORD PTR [rsp+0x180]
   654f9:	mov    QWORD PTR [rsp+0x150],r13
   65501:	mov    r13d,DWORD PTR [rsp+0x3a4]
   65509:	cmp    r12d,r13d
   6550c:	jge    65551 <sqlite3VdbeExec+0x160b1>
   6550e:	movsxd rax,r12d
   65511:	imul   rax,rax,0x38
   65515:	lea    rcx,[rbx+rax*1]
   65519:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   6551e:	and    eax,0x24
   65521:	test   eax,eax
   65523:	je     653ec <sqlite3VdbeExec+0x15f4c>
   65529:	add    r15,QWORD PTR [rcx]
   6552c:	mov    DWORD PTR [rsp+0x3a4],r13d
   65534:	mov    QWORD PTR [rsp+0x188],r12
   6553c:	mov    r13,QWORD PTR [rsp+0x150]
   65544:	mov    r12,r15
   65547:	mov    r15d,DWORD PTR [rsp+0x37c]
   6554f:	jmp    654d5 <sqlite3VdbeExec+0x16035>
   65551:	mov    r12,QWORD PTR [rsp+0x168]
   65559:	mov    rax,r15
   6555c:	mov    ecx,DWORD PTR [rbx+r12*1+0x10]
   65561:	shl    ecx,0x3
   65564:	movsxd rcx,ecx
   65567:	xor    edx,edx
   65569:	div    rcx
   6556c:	mov    rax,rdx
   6556f:	mov    rdx,QWORD PTR [rbx+r12*1+0x8]
   65574:	mov    rsi,rax
   65577:	shr    rsi,0x3
   6557b:	movsx  r8d,BYTE PTR [rdx+rsi*1]
   65580:	mov    r9d,0x1
   65586:	and    rax,0x7
   6558a:	mov    ecx,eax
   6558c:	mov    rax,r9
   6558f:	shl    eax,cl
   65591:	or     r8d,eax
   65594:	mov    BYTE PTR [rdx+rsi*1],r8b
   65598:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   6559d:	mov    QWORD PTR [rsp+0x130],r12
   655a5:	movsxd rax,DWORD PTR [rbp+0x4]
   655a9:	imul   r12,rax,0x38
   655ad:	movsxd r15,DWORD PTR [rbp+0xc]
   655b1:	mov    r13d,r15d
   655b4:	add    r13d,DWORD PTR [rbp+0x10]
   655b8:	mov    DWORD PTR [rsp+0x3a4],r13d
   655c0:	xor    r13d,r13d
   655c3:	jmp    656a2 <sqlite3VdbeExec+0x16202>
   655c8:	mov    DWORD PTR [rsp+0x3a4],r12d
   655d0:	mov    r12,QWORD PTR [rsp+0x168]
   655d8:	mov    rax,rcx
   655db:	movzx  ecx,WORD PTR [rax+0x14]
   655df:	and    ecx,0x8
   655e2:	test   ecx,ecx
   655e4:	je     65684 <sqlite3VdbeExec+0x161e4>
   655ea:	movzx  ecx,WORD PTR [rax+0x14]
   655ee:	mov    edx,ecx
   655f0:	and    edx,0x24
   655f3:	test   edx,edx
   655f5:	je     655ff <sqlite3VdbeExec+0x1615f>
   655f7:	mov    rax,QWORD PTR [rax]
   655fa:	jmp    6567f <sqlite3VdbeExec+0x161df>
   655ff:	mov    edx,ecx
   65601:	and    edx,0x8
   65604:	test   edx,edx
   65606:	je     65655 <sqlite3VdbeExec+0x161b5>
   65608:	movsd  xmm1,QWORD PTR [rax]
   6560c:	movabs r11,0xc3dfffffffffffff
   65616:	movq   xmm0,r11
   6561b:	ucomisd xmm0,xmm1
   6561f:	jbe    6562d <sqlite3VdbeExec+0x1618d>
   65621:	movabs rax,0x8000000000000000
   6562b:	jmp    65653 <sqlite3VdbeExec+0x161b3>
   6562d:	movabs r11,0x43dfffffffffffff
   65637:	movq   xmm0,r11
   6563c:	ucomisd xmm1,xmm0
   65640:	jbe    6564e <sqlite3VdbeExec+0x161ae>
   65642:	movabs rax,0x7fffffffffffffff
   6564c:	jmp    65653 <sqlite3VdbeExec+0x161b3>
   6564e:	cvttsd2si rax,xmm1
   65653:	jmp    6567f <sqlite3VdbeExec+0x161df>
   65655:	and    ecx,0x12
   65658:	test   ecx,ecx
   6565a:	je     6567d <sqlite3VdbeExec+0x161dd>
   6565c:	cmp    QWORD PTR [rax+0x8],0x0
   65661:	je     6567d <sqlite3VdbeExec+0x161dd>
   65663:	mov    QWORD PTR [rsp+0x110],rdi
   6566b:	mov    rdi,rax
   6566e:	call   65673 <sqlite3VdbeExec+0x161d3>
   65673:	mov    rdi,QWORD PTR [rsp+0x110]
   6567b:	jmp    6567f <sqlite3VdbeExec+0x161df>
   6567d:	xor    eax,eax
   6567f:	add    r13,rax
   65682:	jmp    6569e <sqlite3VdbeExec+0x161fe>
   65684:	movzx  ecx,WORD PTR [rax+0x14]
   65688:	and    ecx,0x12
   6568b:	test   ecx,ecx
   6568d:	je     6569e <sqlite3VdbeExec+0x161fe>
   6568f:	movzx  eax,WORD PTR [rax+0x14]
   65693:	and    eax,0x12
   65696:	add    eax,0xffd
   6569b:	add    r13,rax
   6569e:	add    r15d,0x1
   656a2:	mov    QWORD PTR [rsp+0x168],r12
   656aa:	mov    r12d,DWORD PTR [rsp+0x3a4]
   656b2:	cmp    r15d,r12d
   656b5:	jge    656e7 <sqlite3VdbeExec+0x16247>
   656b7:	movsxd rax,r15d
   656ba:	imul   rax,rax,0x38
   656be:	lea    rcx,[rbx+rax*1]
   656c2:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   656c7:	and    eax,0x24
   656ca:	test   eax,eax
   656cc:	je     655c8 <sqlite3VdbeExec+0x16128>
   656d2:	add    r13,QWORD PTR [rcx]
   656d5:	mov    DWORD PTR [rsp+0x3a4],r12d
   656dd:	mov    r12,QWORD PTR [rsp+0x168]
   656e5:	jmp    6569e <sqlite3VdbeExec+0x161fe>
   656e7:	mov    r12,QWORD PTR [rsp+0x168]
   656ef:	mov    rax,r13
   656f2:	mov    ecx,DWORD PTR [rbx+r12*1+0x10]
   656f7:	shl    ecx,0x3
   656fa:	movsxd rcx,ecx
   656fd:	xor    edx,edx
   656ff:	div    rcx
   65702:	mov    rax,rdx
   65705:	mov    rcx,QWORD PTR [rbx+r12*1+0x8]
   6570a:	mov    rdx,rax
   6570d:	shr    rdx,0x3
   65711:	movsx  edx,BYTE PTR [rcx+rdx*1]
   65715:	mov    esi,0x1
   6571a:	and    rax,0x7
   6571e:	mov    ecx,eax
   65720:	mov    rax,rsi
   65723:	shl    eax,cl
   65725:	and    edx,eax
   65727:	test   edx,edx
   65729:	jne    6574a <sqlite3VdbeExec+0x162aa>
   6572b:	mov    eax,DWORD PTR [rdi+0xf4]
   65731:	add    eax,0x1
   65734:	mov    DWORD PTR [rdi+0xf4],eax
   6573a:	mov    r12,r14
   6573d:	mov    r15d,DWORD PTR [rsp+0x37c]
   65745:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   6574a:	mov    eax,DWORD PTR [rdi+0xf0]
   65750:	add    eax,0x1
   65753:	mov    DWORD PTR [rdi+0xf0],eax
   65759:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   6575e:	mov    QWORD PTR [rsp+0x130],r12
   65766:	movzx  eax,BYTE PTR [r14+0x6e]
   6576b:	and    eax,0x41
   6576e:	test   eax,eax
   65770:	je     65941 <sqlite3VdbeExec+0x164a1>
   65776:	cmp    BYTE PTR [rdi+0xc5],0xfe
   6577d:	je     65941 <sqlite3VdbeExec+0x164a1>
   65783:	cmp    QWORD PTR [rbp+0x10],0x0
   65788:	je     65790 <sqlite3VdbeExec+0x162f0>
   6578a:	mov    rax,QWORD PTR [rbp+0x10]
   6578e:	jmp    65797 <sqlite3VdbeExec+0x162f7>
   65790:	mov    rax,QWORD PTR [rdi+0xf8]
   65797:	test   rax,rax
   6579a:	je     65941 <sqlite3VdbeExec+0x164a1>
   657a0:	movzx  ecx,BYTE PTR [r14+0x6e]
   657a5:	and    ecx,0x40
   657a8:	test   ecx,ecx
   657aa:	je     6587e <sqlite3VdbeExec+0x163de>
   657b0:	mov    QWORD PTR [rsp+0x110],rdi
   657b8:	mov    rsi,rax
   657bb:	call   657c0 <sqlite3VdbeExec+0x16320>
   657c0:	mov    rcx,QWORD PTR [r14+0xf0]
   657c7:	mov    rdx,QWORD PTR [r14+0xf8]
   657ce:	mov    QWORD PTR [rsp+0x108],rax
   657d6:	mov    rdi,rdx
   657d9:	mov    rsi,rax
   657dc:	mov    r10,rcx
   657df:	call   r10
   657e2:	mov    rax,QWORD PTR [rsp+0x108]
   657ea:	mov    rdi,QWORD PTR [rsp+0x110]
   657f2:	test   rax,rax
   657f5:	je     65941 <sqlite3VdbeExec+0x164a1>
   657fb:	cmp    DWORD PTR [rip+0x0],0x0        # 65802 <sqlite3VdbeExec+0x16362>
   65802:	je     65861 <sqlite3VdbeExec+0x163c1>
   65804:	mov    rcx,QWORD PTR [rip+0x0]        # 6580b <sqlite3VdbeExec+0x1636b>
   6580b:	mov    rdi,rax
   6580e:	mov    r10,rcx
   65811:	call   r10
   65814:	mov    ecx,eax
   65816:	mov    rdx,QWORD PTR [rip+0x0]        # 6581d <sqlite3VdbeExec+0x1637d>
   6581d:	movsxd rcx,ecx
   65820:	sub    rdx,rcx
   65823:	mov    QWORD PTR [rip+0x0],rdx        # 6582a <sqlite3VdbeExec+0x1638a>
   6582a:	mov    rcx,QWORD PTR [rip+0x0]        # 65831 <sqlite3VdbeExec+0x16391>
   65831:	sub    rcx,0x1
   65835:	mov    QWORD PTR [rip+0x0],rcx        # 6583c <sqlite3VdbeExec+0x1639c>
   6583c:	mov    rcx,QWORD PTR [rip+0x0]        # 65843 <sqlite3VdbeExec+0x163a3>
   65843:	mov    rax,QWORD PTR [rsp+0x108]
   6584b:	mov    rdi,rax
   6584e:	mov    r10,rcx
   65851:	call   r10
   65854:	mov    rdi,QWORD PTR [rsp+0x110]
   6585c:	jmp    65941 <sqlite3VdbeExec+0x164a1>
   65861:	mov    rcx,QWORD PTR [rip+0x0]        # 65868 <sqlite3VdbeExec+0x163c8>
   65868:	mov    rdi,rax
   6586b:	mov    r10,rcx
   6586e:	call   r10
   65871:	mov    rdi,QWORD PTR [rsp+0x110]
   65879:	jmp    65941 <sqlite3VdbeExec+0x164a1>
   6587e:	cmp    DWORD PTR [r14+0xdc],0x1
   65886:	jle    6590c <sqlite3VdbeExec+0x1646c>
   6588c:	lea    rcx,[rip+0x0]        # 65893 <sqlite3VdbeExec+0x163f3>
   65893:	mov    QWORD PTR [rsp+0x110],rdi
   6589b:	mov    rdi,r14
   6589e:	mov    rsi,rcx
   658a1:	mov    rdx,rax
   658a4:	xor    eax,eax
   658a6:	call   658ab <sqlite3VdbeExec+0x1640b>
   658ab:	mov    rcx,QWORD PTR [r14+0xf0]
   658b2:	mov    edx,0x1
   658b7:	mov    rsi,QWORD PTR [r14+0xf8]
   658be:	mov    rdi,QWORD PTR [rsp+0x110]
   658c6:	mov    QWORD PTR [rsp+0x108],rax
   658ce:	mov    r10,rcx
   658d1:	mov    rcx,rax
   658d4:	mov    r11,rdi
   658d7:	mov    rdi,rdx
   658da:	mov    rdx,r11
   658dd:	call   r10
   658e0:	mov    ecx,eax
   658e2:	mov    rax,QWORD PTR [rsp+0x108]
   658ea:	mov    rdi,QWORD PTR [rsp+0x110]
   658f2:	test   rax,rax
   658f5:	je     65941 <sqlite3VdbeExec+0x164a1>
   658f7:	mov    rdi,r14
   658fa:	mov    rsi,rax
   658fd:	call   65902 <sqlite3VdbeExec+0x16462>
   65902:	mov    rdi,QWORD PTR [rsp+0x110]
   6590a:	jmp    65941 <sqlite3VdbeExec+0x164a1>
   6590c:	mov    rcx,QWORD PTR [r14+0xf0]
   65913:	mov    edx,0x1
   65918:	mov    rsi,QWORD PTR [r14+0xf8]
   6591f:	mov    QWORD PTR [rsp+0x110],rdi
   65927:	mov    r10,rcx
   6592a:	mov    rcx,rax
   6592d:	mov    r11,rdi
   65930:	mov    rdi,rdx
   65933:	mov    rdx,r11
   65936:	call   r10
   65939:	mov    rdi,QWORD PTR [rsp+0x110]
   65941:	mov    eax,DWORD PTR [rbp+0x4]
   65944:	cmp    eax,DWORD PTR [rip+0x0]        # 6594a <sqlite3VdbeExec+0x164aa>
   6594a:	jl     65997 <sqlite3VdbeExec+0x164f7>
   6594c:	cmp    BYTE PTR [rbp+0x0],0xba
   65950:	jne    65954 <sqlite3VdbeExec+0x164b4>
   65952:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   65954:	mov    eax,0x1
   65959:	jmp    65988 <sqlite3VdbeExec+0x164e8>
   6595b:	mov    rcx,QWORD PTR [rdi+0x88]
   65962:	mov    rdx,rax
   65965:	imul   rdx,rdx,0x18
   65969:	cmp    BYTE PTR [rcx+rdx*1],0xf
   6596d:	jne    65985 <sqlite3VdbeExec+0x164e5>
   6596f:	mov    rcx,QWORD PTR [rdi+0x88]
   65976:	mov    rdx,rax
   65979:	imul   rdx,rdx,0x18
   6597d:	mov    DWORD PTR [rcx+rdx*1+0x4],0x0
   65985:	add    eax,0x1
   65988:	cmp    eax,DWORD PTR [rdi+0x90]
   6598e:	jl     6595b <sqlite3VdbeExec+0x164bb>
   65990:	mov    DWORD PTR [rbp+0x4],0x0
   65997:	mov    eax,DWORD PTR [rbp+0x4]
   6599a:	add    eax,0x1
   6599d:	mov    DWORD PTR [rbp+0x4],eax
   659a0:	mov    eax,DWORD PTR [rdi+0xec]
   659a6:	add    eax,0x1
   659a9:	mov    DWORD PTR [rdi+0xec],eax
   659af:	mov    r12,r14
   659b2:	mov    r15d,DWORD PTR [rsp+0x37c]
   659ba:	jmp    51d95 <sqlite3VdbeExec+0x28f5>
   659bf:	add    rbp,0x18
   659c3:	mov    r12,QWORD PTR [rsp+0x130]
   659cb:	add    r12,0x1
   659cf:	movzx  eax,BYTE PTR [rbp+0x0]
   659d3:	cmp    eax,0xba
   659d8:	jbe    659e4 <sqlite3VdbeExec+0x16544>
   659da:	mov    QWORD PTR [rsp+0x130],r12
   659e2:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   659e4:	lea    r13,[rip+0x0]        # 659eb <sqlite3VdbeExec+0x1654b>
   659eb:	movsxd rax,DWORD PTR [r13+rax*4+0x0]
   659f0:	add    rax,r13
   659f3:	jmp    rax
   659f5:	mov    QWORD PTR [rsp+0x130],r12
   659fd:	jmp    659bf <sqlite3VdbeExec+0x1651f>
   659ff:	mov    r15d,DWORD PTR [rsp+0x37c]
   65a07:	mov    r13,QWORD PTR [rsp+0x150]
   65a0f:	mov    QWORD PTR [rsp+0x130],r12
   65a17:	mov    r12d,DWORD PTR [rsp+0x394]
   65a1f:	jmp    4f7bd <sqlite3VdbeExec+0x31d>
   65a24:	mov    r15d,DWORD PTR [rsp+0x37c]
   65a2c:	mov    r13,QWORD PTR [rsp+0x150]
   65a34:	mov    QWORD PTR [rsp+0x130],r12
   65a3c:	mov    r12d,DWORD PTR [rsp+0x394]
   65a44:	jmp    5832b <sqlite3VdbeExec+0x8e8b>
   65a49:	mov    r15d,DWORD PTR [rsp+0x37c]
   65a51:	mov    r13,QWORD PTR [rsp+0x150]
   65a59:	mov    QWORD PTR [rsp+0x130],r12
   65a61:	jmp    5878a <sqlite3VdbeExec+0x92ea>
   65a66:	mov    r15d,DWORD PTR [rsp+0x37c]
   65a6e:	mov    QWORD PTR [rsp+0x130],r12
   65a76:	jmp    5acff <sqlite3VdbeExec+0xb85f>
   65a7b:	mov    r15d,DWORD PTR [rsp+0x37c]
   65a83:	mov    r13,QWORD PTR [rsp+0x150]
   65a8b:	mov    QWORD PTR [rsp+0x130],r12
   65a93:	mov    r12d,DWORD PTR [rsp+0x394]
   65a9b:	jmp    4fa5b <sqlite3VdbeExec+0x5bb>
   65aa0:	mov    r15d,DWORD PTR [rsp+0x37c]
   65aa8:	mov    QWORD PTR [rsp+0x130],r12
   65ab0:	jmp    5002b <sqlite3VdbeExec+0xb8b>
   65ab5:	mov    r15d,DWORD PTR [rsp+0x37c]
   65abd:	mov    r13,QWORD PTR [rsp+0x150]
   65ac5:	mov    QWORD PTR [rsp+0x130],r12
   65acd:	jmp    56971 <sqlite3VdbeExec+0x74d1>
   65ad2:	mov    r15d,DWORD PTR [rsp+0x37c]
   65ada:	mov    r13,QWORD PTR [rsp+0x150]
   65ae2:	mov    QWORD PTR [rsp+0x130],r12
   65aea:	jmp    611b9 <sqlite3VdbeExec+0x11d19>
   65aef:	cmp    ebp,0x210a
   65af5:	jne    65b25 <sqlite3VdbeExec+0x16685>
   65af7:	mov    eax,0x19d26
   65afc:	mov    ecx,0xb
   65b01:	lea    rdx,[rip+0x0]        # 65b08 <sqlite3VdbeExec+0x16668>
   65b08:	mov    QWORD PTR [rsp+0x110],rdi
   65b10:	mov    rdi,rcx
   65b13:	mov    rsi,rax
   65b16:	call   65b1b <sqlite3VdbeExec+0x1667b>
   65b1b:	mov    ebp,eax
   65b1d:	mov    rdi,QWORD PTR [rsp+0x110]
   65b25:	cmp    QWORD PTR [rdi+0xa8],0x0
   65b2d:	jne    65bb6 <sqlite3VdbeExec+0x16716>
   65b33:	cmp    ebp,0xc0a
   65b39:	je     65bb6 <sqlite3VdbeExec+0x16716>
   65b3b:	lea    rax,[rip+0x0]        # 65b42 <sqlite3VdbeExec+0x166a2>
   65b42:	lea    rcx,[rip+0x0]        # 65b49 <sqlite3VdbeExec+0x166a9>
   65b49:	cmp    ebp,0x204
   65b4f:	je     65b64 <sqlite3VdbeExec+0x166c4>
   65b51:	cmp    ebp,0x64
   65b54:	je     65b6d <sqlite3VdbeExec+0x166cd>
   65b56:	cmp    ebp,0x65
   65b59:	jne    65b76 <sqlite3VdbeExec+0x166d6>
   65b5b:	lea    rcx,[rip+0x0]        # 65b62 <sqlite3VdbeExec+0x166c2>
   65b62:	jmp    65b99 <sqlite3VdbeExec+0x166f9>
   65b64:	lea    rcx,[rip+0x0]        # 65b6b <sqlite3VdbeExec+0x166cb>
   65b6b:	jmp    65b99 <sqlite3VdbeExec+0x166f9>
   65b6d:	lea    rcx,[rip+0x0]        # 65b74 <sqlite3VdbeExec+0x166d4>
   65b74:	jmp    65b99 <sqlite3VdbeExec+0x166f9>
   65b76:	mov    edx,ebp
   65b78:	and    edx,0xff
   65b7e:	test   edx,edx
   65b80:	jl     65b99 <sqlite3VdbeExec+0x166f9>
   65b82:	cmp    edx,0x1d
   65b85:	jge    65b99 <sqlite3VdbeExec+0x166f9>
   65b87:	lea    rsi,[rip+0x0]        # 65b8e <sqlite3VdbeExec+0x166ee>
   65b8e:	mov    rdx,QWORD PTR [rsi+rdx*8]
   65b92:	test   rdx,rdx
   65b95:	cmovne rcx,rdx
   65b99:	mov    QWORD PTR [rsp+0x110],rdi
   65ba1:	mov    rsi,rax
   65ba4:	mov    rdx,rcx
   65ba7:	xor    eax,eax
   65ba9:	call   65bae <sqlite3VdbeExec+0x1670e>
   65bae:	mov    rdi,QWORD PTR [rsp+0x110]
   65bb6:	mov    DWORD PTR [rdi+0x34],ebp
   65bb9:	cmp    ebp,0xc0a
   65bbf:	je     65c14 <sqlite3VdbeExec+0x16774>
   65bc1:	mov    eax,ebp
   65bc3:	and    eax,0xff
   65bc8:	cmp    eax,0xe
   65bcb:	je     65bd2 <sqlite3VdbeExec+0x16732>
   65bcd:	cmp    eax,0xa
   65bd0:	jne    65c14 <sqlite3VdbeExec+0x16774>
   65bd2:	mov    rax,QWORD PTR [r14]
   65bd5:	cmp    QWORD PTR [rax+0x80],0x0
   65bdd:	je     65c0e <sqlite3VdbeExec+0x1676e>
   65bdf:	mov    rcx,QWORD PTR [rax+0x80]
   65be6:	xor    edx,edx
   65be8:	xor    esi,esi
   65bea:	mov    QWORD PTR [rsp+0x110],rdi
   65bf2:	mov    rdi,rax
   65bf5:	mov    r10,rcx
   65bf8:	mov    r11,rsi
   65bfb:	mov    rsi,rdx
   65bfe:	mov    rdx,r11
   65c01:	call   r10
   65c04:	mov    rdi,QWORD PTR [rsp+0x110]
   65c0c:	jmp    65c10 <sqlite3VdbeExec+0x16770>
   65c0e:	xor    eax,eax
   65c10:	mov    DWORD PTR [r14+0x5c],eax
   65c14:	mov    r12,QWORD PTR [rsp+0x150]
   65c1c:	mov    r15,QWORD PTR [rsp+0x148]
   65c24:	mov    QWORD PTR [rsp+0x110],rdi
   65c2c:	mov    rsi,rbp
   65c2f:	mov    rdx,r15
   65c32:	mov    rcx,r12
   65c35:	call   65c3a <sqlite3VdbeExec+0x1679a>
   65c3a:	mov    rdi,QWORD PTR [rsp+0x110]
   65c42:	cmp    BYTE PTR [rdi+0xc7],0x2
   65c49:	jne    65c58 <sqlite3VdbeExec+0x167b8>
   65c4b:	call   65c50 <sqlite3VdbeExec+0x167b0>
   65c50:	mov    rdi,QWORD PTR [rsp+0x110]
   65c58:	cmp    ebp,0xc0a
   65c5e:	jne    65c78 <sqlite3VdbeExec+0x167d8>
   65c60:	mov    QWORD PTR [rsp+0x110],rdi
   65c68:	mov    rdi,r14
   65c6b:	call   65c70 <sqlite3VdbeExec+0x167d0>
   65c70:	mov    rdi,QWORD PTR [rsp+0x110]
   65c78:	cmp    ebp,0xb
   65c7b:	jne    65c96 <sqlite3VdbeExec+0x167f6>
   65c7d:	cmp    BYTE PTR [r14+0x65],0x0
   65c82:	jne    65c96 <sqlite3VdbeExec+0x167f6>
   65c84:	movabs rax,0x200000000
   65c8e:	or     rax,QWORD PTR [r14+0x30]
   65c92:	mov    QWORD PTR [r14+0x30],rax
   65c96:	mov    ebp,DWORD PTR [rsp+0x380]
   65c9d:	movzx  eax,bpl
   65ca1:	test   eax,eax
   65ca3:	jg     65cc4 <sqlite3VdbeExec+0x16824>
   65ca5:	mov    QWORD PTR [rsp+0x150],r12
   65cad:	mov    r11,rbp
   65cb0:	mov    rbp,r15
   65cb3:	mov    r15,r13
   65cb6:	mov    r13,r11
   65cb9:	mov    r12d,0x1
   65cbf:	jmp    65d93 <sqlite3VdbeExec+0x168f3>
   65cc4:	movzx  eax,bpl
   65cc8:	sub    eax,0x1
   65ccb:	test   eax,eax
   65ccd:	jl     65d05 <sqlite3VdbeExec+0x16865>
   65ccf:	mov    rcx,QWORD PTR [r14+0x20]
   65cd3:	shl    rax,0x5
   65cd7:	mov    rax,QWORD PTR [rcx+rax*1+0x18]
   65cdc:	movzx  ecx,WORD PTR [rax+0x72]
   65ce0:	or     ecx,0x8
   65ce3:	mov    WORD PTR [rax+0x72],cx
   65ce7:	mov    rax,QWORD PTR [r14+0x20]
   65ceb:	mov    rax,QWORD PTR [rax+0x38]
   65cef:	movzx  ecx,WORD PTR [rax+0x72]
   65cf3:	or     ecx,0x8
   65cf6:	mov    WORD PTR [rax+0x72],cx
   65cfa:	mov    eax,DWORD PTR [r14+0x2c]
   65cfe:	and    eax,0xffffffef
   65d01:	mov    DWORD PTR [r14+0x2c],eax
   65d05:	cmp    DWORD PTR [r14+0x48],0x0
   65d0a:	je     65d16 <sqlite3VdbeExec+0x16876>
   65d0c:	mov    QWORD PTR [rsp+0x158],rbx
   65d14:	jmp    65d6f <sqlite3VdbeExec+0x168cf>
   65d16:	mov    QWORD PTR [rsp+0x158],rbx
   65d1e:	xor    ebx,ebx
   65d20:	jmp    65d69 <sqlite3VdbeExec+0x168c9>
   65d22:	mov    rax,QWORD PTR [r14+0x20]
   65d26:	mov    rcx,rbx
   65d29:	shl    rcx,0x5
   65d2d:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   65d32:	movzx  eax,WORD PTR [rax+0x72]
   65d36:	and    eax,0x8
   65d39:	cmp    eax,0x8
   65d3c:	jne    65d66 <sqlite3VdbeExec+0x168c6>
   65d3e:	mov    rax,QWORD PTR [r14+0x20]
   65d42:	mov    rcx,rbx
   65d45:	shl    rcx,0x5
   65d49:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   65d4e:	mov    QWORD PTR [rsp+0x110],rdi
   65d56:	mov    rdi,rax
   65d59:	call   65d5e <sqlite3VdbeExec+0x168be>
   65d5e:	mov    rdi,QWORD PTR [rsp+0x110]
   65d66:	add    ebx,0x1
   65d69:	cmp    ebx,DWORD PTR [r14+0x28]
   65d6d:	jl     65d22 <sqlite3VdbeExec+0x16882>
   65d6f:	mov    QWORD PTR [rsp+0x150],r12
   65d77:	mov    rbx,QWORD PTR [rsp+0x158]
   65d7f:	mov    r11,rbp
   65d82:	mov    rbp,r15
   65d85:	mov    r15,r13
   65d88:	mov    r13,r11
   65d8b:	mov    r12d,0x1
   65d91:	jmp    65d93 <sqlite3VdbeExec+0x168f3>
   65d93:	cmp    r15,rbx
   65d96:	jb     65dff <sqlite3VdbeExec+0x1695f>
   65d98:	cmp    QWORD PTR [r14+0x208],0x0
   65da0:	je     65dff <sqlite3VdbeExec+0x1695f>
   65da2:	mov    eax,DWORD PTR [r14+0x218]
   65da9:	add    rbx,rax
   65dac:	mov    rax,QWORD PTR [r14+0x208]
   65db3:	mov    rcx,QWORD PTR [r14+0x210]
   65dba:	mov    QWORD PTR [rsp+0x110],rdi
   65dc2:	mov    rdi,rcx
   65dc5:	mov    r10,rax
   65dc8:	call   r10
   65dcb:	mov    rdi,QWORD PTR [rsp+0x110]
   65dd3:	test   eax,eax
   65dd5:	je     65d93 <sqlite3VdbeExec+0x168f3>
   65dd7:	mov    rbx,0xffffffffffffffff
   65dde:	mov    r12d,0x9
   65de4:	mov    QWORD PTR [rsp+0x148],rbp
   65dec:	mov    rbp,r12
   65def:	mov    DWORD PTR [rsp+0x380],r13d
   65df7:	mov    r13,r15
   65dfa:	jmp    4f712 <sqlite3VdbeExec+0x272>
   65dff:	mov    eax,r15d
   65e02:	add    eax,DWORD PTR [rdi+0xe4]
   65e08:	mov    DWORD PTR [rdi+0xe4],eax
   65e0e:	mov    eax,DWORD PTR [rdi+0xd0]
   65e14:	mov    eax,r12d
   65e17:	add    rsp,0x3d8
   65e1e:	pop    r15
   65e20:	pop    r14
   65e22:	pop    r13
   65e24:	pop    r12
   65e26:	pop    rbp
   65e27:	pop    rbx
   65e28:	ret
