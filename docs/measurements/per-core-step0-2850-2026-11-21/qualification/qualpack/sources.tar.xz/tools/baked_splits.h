// Partition the first context answer by dependence on the parent context.
#if BAKED_c_PRINT == UINT64_C(0xdeae6b63b99a4877)
static inline __m512i baked_c_static(const LanesBlock* block, __m512i value, __mmask64 lanes, const __m512i* inputs)
 {
    value = _mm512_mask_mov_epi8(value, block->copy_lanes[0] & lanes, inputs[28]);
    value = _mm512_mask_mov_epi8(value, block->copy_lanes[1] & lanes, inputs[32]);
    {
        __m512i index = block->index[0];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[30], _mm512_load_si512(baked_c_recodes_0_0[1])));
        const __m512i answer = _mm512_permutexvar_epi8(index, _mm512_load_si512(baked_c_table_0_0));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[0] & lanes, answer);
    }
    {
        __m512i index = block->index[2];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[16], _mm512_load_si512(baked_c_recodes_0_2[1])));
        const __m512i answer = _mm512_permutexvar_epi8(index, _mm512_load_si512(baked_c_table_0_2));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[2] & lanes, answer);
    }
    {
        __m512i index = block->index[4];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[0], _mm512_load_si512(baked_c_recodes_0_4[1])));
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[2], _mm512_load_si512(baked_c_recodes_0_4[2])));
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[23], _mm512_load_si512(baked_c_recodes_0_4[3])));
        const __m512i answer = _mm512_permutexvar_epi8(index, _mm512_load_si512(baked_c_table_0_4));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[4] & lanes, answer);
    }
    {
        __m512i index = block->index[5];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[3], _mm512_load_si512(baked_c_recodes_0_5[1])));
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[26], _mm512_load_si512(baked_c_recodes_0_5[2])));
        const __m512i answer = _mm512_permutexvar_epi8(index, _mm512_load_si512(baked_c_table_0_5));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[5] & lanes, answer);
    }
    {
        __m512i index = block->index[6];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[0], _mm512_load_si512(baked_c_recodes_0_6[1])));
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[2], _mm512_load_si512(baked_c_recodes_0_6[2])));
        const __m512i answer = _mm512_permutexvar_epi8(index, _mm512_load_si512(baked_c_table_0_6));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[6] & lanes, answer);
    }
    {
        __m512i index = block->index[7];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[25], _mm512_load_si512(baked_c_recodes_0_7[1])));
        const __m512i answer = _mm512_permutexvar_epi8(index, _mm512_load_si512(baked_c_table_0_7));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[7] & lanes, answer);
    }
    {
        __m512i index = block->index[8];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[3], _mm512_load_si512(baked_c_recodes_0_8[1])));
        const __m512i answer = _mm512_permutexvar_epi8(index, _mm512_load_si512(baked_c_table_0_8));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[8] & lanes, answer);
    }

    return value;
}
static inline __m512i baked_c_inherited(const LanesBlock* block, __m512i value, __mmask64 lanes, const __m512i* inputs)
 {
    {
        __m512i index = block->index[1];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[1], _mm512_load_si512(baked_c_recodes_0_1[1])));
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[3], _mm512_load_si512(baked_c_recodes_0_1[2])));
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[12], _mm512_load_si512(baked_c_recodes_0_1[3])));
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[13], _mm512_load_si512(baked_c_recodes_0_1[4])));
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[15], _mm512_load_si512(baked_c_recodes_0_1[5])));
        __m512i answer = _mm512_permutex2var_epi8(_mm512_load_si512(baked_c_table_0_1), index, _mm512_load_si512(baked_c_table_0_1 + 64));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[1] & lanes, answer);
    }
    {
        __m512i index = block->index[3];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[1], _mm512_load_si512(baked_c_recodes_0_3[1])));
        const __m512i answer = _mm512_permutexvar_epi8(index, _mm512_load_si512(baked_c_table_0_3));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[3] & lanes, answer);
    }

    return value;
}
static inline __mmask64 baked_c_inherits(const LanesBlock* block){return block->step_lanes[1] | block->step_lanes[3];}
#elif BAKED_c_PRINT == UINT64_C(0x45764e444f0577e1)
static inline __m512i baked_c_static(const LanesBlock* block, __m512i value, __mmask64 lanes, const __m512i* inputs)
 {
    value = _mm512_mask_mov_epi8(value, block->copy_lanes[0] & lanes, inputs[31]);
    {
        __m512i index = block->index[0];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[3], _mm512_load_si512(baked_c_recodes_0_0[1])));
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[12], _mm512_load_si512(baked_c_recodes_0_0[2])));
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[15], _mm512_load_si512(baked_c_recodes_0_0[3])));
        const __m512i answer = _mm512_permutexvar_epi8(index, _mm512_load_si512(baked_c_table_0_0));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[0] & lanes, answer);
    }
    {
        __m512i index = block->index[1];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[0], _mm512_load_si512(baked_c_recodes_0_1[1])));
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[2], _mm512_load_si512(baked_c_recodes_0_1[2])));
        const __m512i answer = _mm512_permutexvar_epi8(index, _mm512_load_si512(baked_c_table_0_1));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[1] & lanes, answer);
    }
    {
        __m512i index = block->index[2];
        index = _mm512_or_si512(index, _mm512_permutexvar_epi8(inputs[3], _mm512_load_si512(baked_c_recodes_0_2[1])));
        const __m512i answer = _mm512_permutexvar_epi8(index, _mm512_load_si512(baked_c_table_0_2));
        value = _mm512_mask_mov_epi8(value, block->step_lanes[2] & lanes, answer);
    }

    return value;
}
static inline __m512i baked_c_inherited(const LanesBlock* block, __m512i value, __mmask64 lanes, const __m512i* inputs)
 {

    return value;
}
static inline __mmask64 baked_c_inherits(const LanesBlock* block){return UINT64_C(0);}
#else
#error unexpected frozen baked rules
#endif
