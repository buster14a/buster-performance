#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
lock=../../2850-codex-step2/lock.sh; dumps=../../672-st-claude/scratch
for g in musl sqlite3;do
 for m in qualpackedrepair;do
  "$lock" clang -O3 -g -march=native -Wall -Wextra "-DLANES_BAKED=\"$PWD/baked-$g.h\"" -o "$m-$g" "tools/$m.c" >"$m-$g.build" 2>&1
 done
done
for g in musl sqlite3;do
 for cache in warm cold;do
  extra=();[[ $cache != cold ]] || extra=(--after-scalar 200)
  for n in 1 2 3;do
   case $n in
    1) modes=(w4096 w2048 w1024 w1024 w2048 w4096);;
    2) modes=(w2048 w1024 w4096 w4096 w1024 w2048);;
    3) modes=(w1024 w4096 w2048 w2048 w4096 w1024);;
   esac
   j=0;for m in "${modes[@]}";do
    "$lock" taskset -c 2 "./qualpackedrepair-$g" "$dumps/$g.dump" --window "${m#w}" --passes 7 --first-passes 2 "${extra[@]}" >"$g-$cache-$n-$j-$m.txt" 2>&1
    j=$((j+1))
   done
  done
 done
done
