// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
#define BUSTER_TIER1_EXCHANGE_EPOCH_PROOF
#include "tier1_emit_exchange_epochs.c"

typedef Tier1EmitExchangeEpoch ExchangeEpoch;

// Keep expected columns in the test's output arena across a later controlled allocation map. The production API
// itself owns only scratch; the alias path below calls it directly and proves its success/failure lifetime contract.
static Tier1EmitError exchange_epoch_build(const Tier1SelectPlan* plan, const Tier1EmitResult* emitted,
                                           const Tier1CfgInput* input, const Tier1CfgAllocation* cfg,
                                           Arena* output, Arena* scratch, ExchangeEpoch* result)
{
    const uint64_t mark = scratch->length;
    const uint64_t output_mark = output->length;
    ExchangeEpoch built = { 0 };
    Tier1EmitError error = tier1_emit_exchange_epochs(plan, emitted, input, cfg, scratch, &built);
    if (error == TIER1_EMIT_OK && output != scratch)
    {
        const ExchangeEpoch source = built;
        bool ok = true;
        built.stores = ir_allocate(output, (uint64_t)built.blocks * 16, 4, &ok);
        built.loads = ok ? ir_allocate(output, (uint64_t)built.blocks * 16, 4, &ok) : 0;
        built.node_stores = ok ? ir_allocate(output, (uint64_t)built.nodes + 1, 2, &ok) : 0;
        built.node_loads = ok ? ir_allocate(output, (uint64_t)built.nodes + 1, 2, &ok) : 0;
        error = ok ? error : TIER1_EMIT_MEMORY;
        if (ok)
        {
            memcpy(built.stores, source.stores, (uint64_t)built.blocks * 16 * 4);
            memcpy(built.loads, source.loads, (uint64_t)built.blocks * 16 * 4);
            memcpy(built.node_stores, source.node_stores, ((uint64_t)built.nodes + 1) * 2);
            memcpy(built.node_loads, source.node_loads, ((uint64_t)built.nodes + 1) * 2);
        }
    }
    if (output != scratch)
    {
        arena_pop_to(scratch, mark);
    }
    if (error == TIER1_EMIT_OK)
    {
        *result = built;
    }
    else
    {
        arena_pop_to(output, output_mark);
    }
    return error;
}

static uint64_t epoch_test_compiles;
static uint64_t epoch_test_transitions;
static uint64_t epoch_test_dropped;
static uint64_t epoch_test_covered;
static uint64_t epoch_test_carried;
static uint64_t epoch_test_actual_stores;
static uint64_t epoch_test_actual_loads;

static void epoch_test_oracle(Tier1EmitTest* test, const Tier1SelectPlan* plan, const Tier1EmitResult* emitted, const char* name)
{
    const uint64_t mark = test->scratch.length;
    ExchangeEpoch epoch = { 0 };
    const Tier1EmitError error = exchange_epoch_build(plan, emitted, &emitted->cfg_input, &emitted->cfg, &test->output, &test->scratch, &epoch);
    tier1_emit_test_expect(test, error == TIER1_EMIT_OK && test->scratch.length == mark, "exact epoch state reconstruction succeeds and restores scratch");
    if (error == TIER1_EMIT_OK)
    {
        uint32_t fixed = 0;
        for (uint32_t n = 0; n < plan->function->instruction_count; n += 1)
        {
            fixed |= !plan->covered[n] ? tier1_select_node_fixed(plan->function, &plan->patterns[n]) : 0;
        }
        const uint32_t compared = 0xffffu & ~emitted->callee_registers & ~fixed;
        uint16_t* node_stores = calloc((uint64_t)epoch.nodes + 1, 2);
        uint16_t* node_loads = calloc((uint64_t)epoch.nodes + 1, 2);
        tier1_emit_test_expect(test, node_stores != 0 && node_loads != 0, "allocate independent node-origin accounting");
        uint64_t stores = 0;
        uint64_t loads = 0;
        for (uint32_t b = 0; b < epoch.blocks; b += 1)
        {
            uint32_t actual_stores[16] = { 0 };
            uint32_t actual_loads[16] = { 0 };
            for (uint32_t r = emitted->block_records[b]; r < emitted->block_records[b + 1]; r += 1)
            {
                const X86Instruction* record = &emitted->code.records[r];
                const uint32_t reg = record->reg;
                const bool general = reg < 16 && ((compared >> reg) & 1) != 0;
                const bool store = general && emitted->measure_kinds[r] == 'C' && record->form == X86_FORM_MOV_RM64_R64;
                const bool load = general && emitted->measure_kinds[r] == 'R' && record->form == X86_FORM_MOV_R64_RM64;
                if (store || load)
                {
                    actual_stores[reg] += store;
                    actual_loads[reg] += load;
                    const uint32_t origin = emitted->origins[r];
                    const uint32_t base = 2 * (emitted->cfg_input.block_count - plan->function->block_count);
                    const uint32_t position = origin & BUSTER_TIER1_ORIGIN_PAYLOAD;
                    const uint32_t node = (position - base) / 2;
                    const bool located = (origin >> BUSTER_TIER1_ORIGIN_SHIFT) == TIER1_ORIGIN_MOVE && position >= base && node < epoch.nodes;
                    tier1_emit_test_expect(test, located, "a counted C/R record has the emitter's exact node-phase origin");
                    if (located && node_stores != 0 && node_loads != 0)
                    {
                        node_stores[node] |= store ? (uint16_t)(1u << reg) : 0;
                        node_loads[node] |= load ? (uint16_t)(1u << reg) : 0;
                    }
                }
            }
            for (uint32_t reg = 0; reg < 16; reg += 1)
            {
                if (((compared >> reg) & 1) != 0)
                {
                    const uint64_t index = (uint64_t)b * 16 + reg;
                    const bool matched = actual_stores[reg] == epoch.stores[index] && actual_loads[reg] == epoch.loads[index];
                    tier1_emit_test_expect(test, matched, "per-block/register epochs exactly match actual emitted C/R origin records");
                    if (!matched)
                    {
                        fprintf(stderr, "%s block=%u reg=%u actual=%u/%u predicted=%u/%u\n", name, b, reg, actual_stores[reg], actual_loads[reg], epoch.stores[index], epoch.loads[index]);
                    }
                    stores += actual_stores[reg];
                    loads += actual_loads[reg];
                }
            }
        }
        for (uint32_t node = 0; node_stores != 0 && node_loads != 0 && node < epoch.nodes; node += 1)
        {
            const bool matched = node_stores[node] == (epoch.node_stores[node] & compared) && node_loads[node] == (epoch.node_loads[node] & compared);
            tier1_emit_test_expect(test, matched, "epochs match exact emitted C/R masks at every node, including covered and dropped nodes");
            if (!matched)
            {
                fprintf(stderr, "%s node=%u actual masks=%x/%x predicted=%x/%x compared=%x\n", name, node, node_stores[node], node_loads[node], epoch.node_stores[node], epoch.node_loads[node], compared);
            }
        }
        free(node_stores);
        free(node_loads);
        tier1_emit_test_expect(test, epoch.dropped_definitions == emitted->dropped_definitions, "the state walk reconstructs exactly the emitted dropped definitions");
        epoch_test_compiles += 1;
        epoch_test_transitions += epoch.transitions;
        epoch_test_dropped += epoch.dropped_definitions;
        epoch_test_covered += epoch.covered_nodes;
        epoch_test_carried += epoch.carried_blocks;
        epoch_test_actual_stores += stores;
        epoch_test_actual_loads += loads;
        printf("epoch %s: blocks=%u nodes=%u actual C/R=%" PRIu64 "/%" PRIu64 " transitions=%u dropped=%u covered=%u carried=%u\n",
               name, epoch.blocks, epoch.nodes, stores, loads, epoch.transitions, epoch.dropped_definitions, epoch.covered_nodes, epoch.carried_blocks);
        // The optional analysis is transactional even after a complete valid allocation already exists.
        for (uint32_t arena = 0; arena < 2; arena += 1)
        {
            const uint64_t output_mark = test->output.length;
            const uint64_t output_capacity = test->output.capacity;
            const uint64_t scratch_capacity = test->scratch.capacity;
            test->output.capacity = arena == 0 ? output_mark : output_capacity;
            test->scratch.capacity = arena == 1 ? mark : scratch_capacity;
            ExchangeEpoch untouched;
            memset(&untouched, 0xa5, sizeof(untouched));
            ExchangeEpoch original = untouched;
            const Tier1EmitError refused = exchange_epoch_build(plan, emitted, &emitted->cfg_input, &emitted->cfg, &test->output, &test->scratch, &untouched);
            tier1_emit_test_expect(test, refused == TIER1_EMIT_MEMORY && test->output.length == output_mark && test->scratch.length == mark &&
                                       memcmp(&untouched, &original, sizeof(original)) == 0, "epoch analysis exhaustion preserves both arenas and the caller's result");
            test->output.capacity = output_capacity;
            test->scratch.capacity = scratch_capacity;
        }
        ExchangeEpoch scratch_only = { 0 };
        const Tier1EmitError alias = exchange_epoch_build(plan, emitted, &emitted->cfg_input, &emitted->cfg, &test->scratch, &test->scratch, &scratch_only);
        tier1_emit_test_expect(test, alias == TIER1_EMIT_OK && test->scratch.length > mark &&
                                   memcmp(scratch_only.stores, epoch.stores, (uint64_t)epoch.blocks * 16 * 4) == 0 &&
                                   memcmp(scratch_only.loads, epoch.loads, (uint64_t)epoch.blocks * 16 * 4) == 0,
                               "one scratch arena retains only identical epoch columns after temporary metadata is discarded");
        const uint64_t retained = test->scratch.length - mark;
        arena_pop_to(&test->scratch, mark);
        for (uint32_t phase = 0; phase < 2; phase += 1)
        {
            const uint64_t capacity = test->scratch.capacity;
            test->scratch.capacity = mark + (phase != 0 ? retained : 0);
            ExchangeEpoch untouched;
            memset(&untouched, 0xa5, sizeof(untouched));
            const ExchangeEpoch original = untouched;
            const Tier1EmitError refused = exchange_epoch_build(plan, emitted, &emitted->cfg_input, &emitted->cfg, &test->scratch, &test->scratch, &untouched);
            tier1_emit_test_expect(test, refused == TIER1_EMIT_MEMORY && test->scratch.length == mark && memcmp(&untouched, &original, sizeof(original)) == 0,
                                   "one-arena exhaustion during columns or metadata restores the optional analysis completely");
            test->scratch.capacity = capacity;
        }
    }
}

static void epoch_test_compile(Tier1EmitTest* test, IrFunction* function, const char* name, bool rematerialize, uint32_t registers, uint32_t flags)
{
    IrDominance dominance = { 0 };
    const bool dominated = tier1_terminal_dominance(test, function, &dominance);
    Tier1SelectPlan plan = { 0 };
    uint32_t node = BUSTER_IR_NONE;
    const Tier1SelectError selected = dominated ? tier1_select_plan(function, &dominance, &test->output, &test->scratch, &plan, &node) : TIER1_SELECT_ERROR_INVALID;
    tier1_emit_test_expect(test, selected == TIER1_SELECT_OK, "epoch fixture selects using the actual backend");
    if (selected == TIER1_SELECT_OK)
    {
        const Tier1EmitOptions options = {
            .register_mask = registers,
            .rematerialize = rematerialize,
            .certify = true,
            .measure_kinds = true,
            .frame_flags = flags,
        };
        Tier1EmitResult emitted = { 0 };
        const Tier1EmitError error = tier1_emit_function(&plan, &options, test->allowed, &test->output, &test->scratch, &emitted, &node);
        tier1_emit_test_expect(test, error == TIER1_EMIT_OK && emitted.general && emitted.certified, "epoch fixture emits a certified CFG allocation with real origin tags");
        if (error == TIER1_EMIT_OK && emitted.general)
        {
            epoch_test_oracle(test, &plan, &emitted, name);
        }
        else
        {
            fprintf(stderr, "%s emission=%u node=%u general=%u\n", name, error, node, emitted.general);
        }
    }
    else
    {
        fprintf(stderr, "%s selection=%u node=%u\n", name, selected, node);
    }
    arena_pop_to(&test->output, 0);
    arena_pop_to(&test->input, 0);
}

static bool epoch_test_recipe_function(Tier1EmitTest* test, IrFunction* function)
{
    const uint32_t values = 14;
    const IrSizes sizes = {
        .instruction_count = 2 + 2 * values + 4,
        .block_count = 1,
        .parameter_count = 2,
        .constant_count = values,
        .call_count = 3,
    };
    const bool ready = ir_create(&test->input, &sizes, function) == IR_OK;
    if (ready)
    {
        function->result_type = IR_I64;
        function->parameter_types[0] = IR_PTR;
        function->parameter_types[1] = IR_I64;
        tier1_emit_test_node(function, 0, IR_PARAM, IR_PTR, 0, BUSTER_IR_NONE);
        tier1_emit_test_node(function, 1, IR_PARAM, IR_I64, 1, BUSTER_IR_NONE);
        for (uint32_t k = 0; k < values; k += 1)
        {
            function->constants[k].low = UINT64_C(0xdeadbeef01345679) + 3 * k;
            tier1_emit_test_node(function, 2 + k, IR_CONST, IR_I64, k, BUSTER_IR_NONE);
        }
        uint32_t next = 2 + values;
        for (uint32_t call = 0; call < 2; call += 1)
        {
            function->calls[call] = (IrCall){ .result_type = IR_VOID };
            tier1_emit_test_node(function, next++, IR_CALL_INDIRECT, IR_VOID, 0, call);
        }
        uint32_t sum = 1;
        for (uint32_t k = 0; k < values; k += 1)
        {
            tier1_emit_test_node(function, next, IR_ADD, IR_I64, sum, 2 + k);
            sum = next++;
            if (k == values / 2)
            {
                function->calls[2] = (IrCall){ .result_type = IR_VOID };
                tier1_emit_test_node(function, next++, IR_CALL_INDIRECT, IR_VOID, 0, 2);
            }
        }
        tier1_emit_test_node(function, next++, IR_RET, IR_VOID, sum, BUSTER_IR_NONE);
        function->instruction_count = next;
        function->block_offsets[1] = next;
    }
    return ready;
}

static bool epoch_test_fixed_function(Tier1EmitTest* test, IrFunction* function)
{
    const IrSizes sizes = { .instruction_count = 8, .block_count = 1, .parameter_count = 3, .call_count = 2 };
    const bool ready = ir_create(&test->input, &sizes, function) == IR_OK;
    if (ready)
    {
        function->result_type = IR_I64;
        function->parameter_types[0] = IR_PTR;
        function->parameter_types[1] = IR_I64;
        function->parameter_types[2] = IR_I64;
        function->block_offsets[1] = 8;
        tier1_emit_test_node(function, 0, IR_PARAM, IR_PTR, 0, BUSTER_IR_NONE);
        tier1_emit_test_node(function, 1, IR_PARAM, IR_I64, 1, BUSTER_IR_NONE);
        tier1_emit_test_node(function, 2, IR_PARAM, IR_I64, 2, BUSTER_IR_NONE);
        tier1_emit_test_node(function, 3, IR_CALL_INDIRECT, IR_VOID, 0, 0);
        tier1_emit_test_node(function, 4, IR_SHL, IR_I64, 1, 2);
        tier1_emit_test_node(function, 5, IR_CALL_INDIRECT, IR_VOID, 0, 1);
        tier1_emit_test_node(function, 6, IR_ADD, IR_I64, 4, 1);
        tier1_emit_test_node(function, 7, IR_RET, IR_VOID, 6, BUSTER_IR_NONE);
        function->calls[0].result_type = IR_VOID;
        function->calls[1].result_type = IR_VOID;
    }
    return ready;
}

static void epoch_test_existing(Tier1EmitTest* test)
{
    for (uint32_t remat = 0; remat < 2; remat += 1)
    {
        for (uint32_t pointer = 0; pointer < 2; pointer += 1)
        {
            const uint32_t flags = pointer != 0 ? BUSTER_TIER1_FRAME_KEEP_POINTER : 0;
            Tier1CallFixture fixture = { 0 };
            if (tier1_call_run_fixture(test, &fixture))
            {
                epoch_test_compile(test, &fixture.function, "retained-two-call", remat != 0, tier1_liveness_register_mask(), flags);
            }
            for (uint32_t carry = TIER1_CALL_CARRY; carry <= TIER1_CALL_CARRY_LATER; carry += 1)
            {
                memset(&fixture, 0, sizeof(fixture));
                if (tier1_call_carry_fixture(test, &fixture, carry))
                {
                    epoch_test_compile(test, &fixture.function, carry == TIER1_CALL_CARRY ? "earlier-predecessor" : carry == TIER1_CALL_CARRY_JOIN ? "join" : "later-predecessor",
                                       remat != 0, tier1_liveness_register_mask(), flags);
                }
            }
            memset(&fixture, 0, sizeof(fixture));
            if (tier1_call_callee_fixture(test, &fixture, pointer ? 5 : 6))
            {
                epoch_test_compile(test, &fixture.function, "callee-columns", remat != 0, tier1_liveness_register_mask(), flags);
            }
            IrFunction recipe = { 0 };
            if (epoch_test_recipe_function(test, &recipe))
            {
                epoch_test_compile(test, &recipe, "pressure-recipes", remat != 0, tier1_liveness_register_mask(), flags);
            }
        }
    }
    for (uint32_t shape = 0; shape < 3; shape += 1)
    {
        IrFunction function = { 0 };
        const bool ready = shape == 0 ? tier1_dropped_function(&test->input, &function) : shape == 1 ? tier1_bare_function(&test->input, &function) : tier1_rest_function(&test->input, &function);
        if (ready)
        {
            epoch_test_compile(test, &function, shape == 0 ? "dropped-edge" : shape == 1 ? "bare-definition" : "resting-loop", true,
                               (1u << X86_REGISTER_RDI) | (1u << X86_REGISTER_RSI) | (1u << X86_REGISTER_RAX), 0);
        }
    }
    IrFunction fixed = { 0 };
    if (epoch_test_fixed_function(test, &fixed))
    {
        epoch_test_compile(test, &fixed, "fixed-sequence-barrier", true, tier1_liveness_register_mask(), 0);
    }
}

static bool epoch_test_lazy_function(Tier1EmitTest* test, IrFunction* function, bool carry)
{
    const IrSizes sizes = {
        .instruction_count = carry ? 12 : 10,
        .block_count = carry ? 3 : 1,
        .parameter_count = 1,
        .constant_count = 2,
        .call_count = 3,
    };
    const bool ready = ir_create(&test->input, &sizes, function) == IR_OK;
    if (ready)
    {
        function->result_type = IR_I64;
        function->parameter_types[0] = IR_I64;
        function->symbol_count = 5;
        function->block_offsets[1] = carry ? 6 : 10;
        function->constants[0].low = UINT64_C(0x123456789abcdef1);
        function->constants[1].low = UINT64_C(0x223456789abcdef3);
        tier1_emit_test_node(function, 0, IR_PARAM, IR_I64, 0, BUSTER_IR_NONE);
        tier1_emit_test_node(function, 1, IR_SYMBOL_ADDR, IR_PTR, 4, BUSTER_IR_NONE);
        tier1_emit_test_node(function, 2, IR_CONST, IR_I64, 0, BUSTER_IR_NONE);
        tier1_emit_test_node(function, 3, IR_CALL, IR_VOID, 1, 0);
        tier1_emit_test_node(function, 4, IR_STORE, IR_VOID, 1, 2);
        if (carry)
        {
            tier1_emit_test_node(function, 5, IR_BR, IR_VOID, 1, BUSTER_IR_NONE);
            tier1_emit_test_node(function, 9, IR_BR, IR_VOID, 2, BUSTER_IR_NONE);
            function->block_offsets[2] = 10;
            function->block_offsets[3] = 12;
        }
        const uint32_t second = carry ? 6 : 5;
        const uint32_t last = carry ? 10 : 8;
        tier1_emit_test_node(function, second, IR_CONST, IR_I64, 1, BUSTER_IR_NONE);
        tier1_emit_test_node(function, second + 1, IR_CALL, IR_VOID, 2, 1);
        tier1_emit_test_node(function, second + 2, IR_STORE, IR_VOID, 1, second);
        tier1_emit_test_node(function, last, IR_CALL, IR_VOID, 3, 2);
        tier1_emit_test_node(function, last + 1, IR_RET, IR_VOID, 0, BUSTER_IR_NONE);
        for (uint32_t call = 0; call < 3; call += 1)
        {
            function->calls[call].result_type = IR_VOID;
        }
    }
    return ready;
}

// Call the real CFG stages with one test-controlled bijection between allocation and frame planning. This is the
// actual emitted counterfactual, not a hand-derived oracle. Both allocation and machine code are independently
// certified after the controlled map. No compiler source or experimental selector is changed by this harness.
static Tier1EmitError epoch_test_mapped_emit(Tier1EmitTest* test, const Tier1SelectPlan* plan, const Tier1EmitOptions* options,
                                             bool swap, Tier1EmitResult* emitted, ExchangeEpoch* before)
{
    *emitted = (Tier1EmitResult){ .general = true, .measure_kinds_enabled = true };
    emitted->prepared.vex = !x86_target_form_allowed(test->allowed, X86_FORM_VMOVDQA64_X_XM128);
    emitted->prepared.unsigned_dword_memory_forms = tier1_emit_unsigned_dword_memory_forms(test->allowed);
    emitted->prepared.unsigned_i64_float_forms = tier1_emit_unsigned_i64_float_forms(test->allowed);
    emitted->prepared.avx2 = x86_target_form_allowed(test->allowed, X86_FORM_VPCMPEQD_Y_Y_YM256);
    emitted->prepared.sse = !x86_target_form_allowed(test->allowed, X86_FORM_VMOVDQU_X_XM128);
    emitted->prepared.zmm = x86_target_form_allowed(test->allowed, X86_FORM_VMOVDQA64_Z_ZM512);
    Tier1EmitError error = tier1_emit_cfg_problem(plan, 0, options, &test->output, &test->scratch, emitted);
    if (error == TIER1_EMIT_OK)
    {
        error = tier1_emit_cfg_one_call(plan, options, emitted, &test->output, &test->scratch, &emitted->cfg_input, &emitted->cfg, &emitted->crossing_values);
    }
    if (error == TIER1_EMIT_OK)
    {
        error = exchange_epoch_build(plan, emitted, &emitted->cfg_input, &emitted->cfg, &test->output, &test->scratch, before);
    }
    if (error == TIER1_EMIT_OK && swap)
    {
        uint8_t permutation[16];
        for (uint32_t reg = 0; reg < 16; reg += 1)
        {
            permutation[reg] = (uint8_t)reg;
        }
        permutation[X86_REGISTER_RDI] = X86_REGISTER_RBX;
        permutation[X86_REGISTER_RBX] = X86_REGISTER_RDI;
        error = tier1_emit_cfg_exchange_map(permutation, &test->output, &emitted->cfg_input, &emitted->cfg);
    }
    if (error == TIER1_EMIT_OK)
    {
        emitted->callee_used = tier1_emit_cfg_callee_used(&emitted->cfg, emitted->callee_registers);
        Tier1CertReport report = { 0 };
        Tier1CertCfgStats stats = { 0 };
        const Tier1CertError certified = tier1_certificate_cfg_check(&emitted->cfg_input, &emitted->cfg, &test->output, &test->scratch, &report, &stats);
        error = certified == TIER1_CERT_OK ? error : TIER1_EMIT_CERTIFICATE;
        emitted->certified = error == TIER1_EMIT_OK;
    }
    if (error == TIER1_EMIT_OK)
    {
        error = tier1_emit_cfg_saves(plan, &test->scratch, emitted);
    }
    if (error == TIER1_EMIT_OK)
    {
        emitted->allocation = emitted->cfg.allocation;
        error = tier1_emit_cfg_frame(plan, options, &test->output, &test->scratch, emitted);
    }
    if (error == TIER1_EMIT_OK)
    {
        uint32_t failed = BUSTER_IR_NONE;
        error = tier1_emit_cfg_records(plan, test->allowed, true, false, &test->output, &test->scratch, emitted, &failed);
    }
    if (error == TIER1_EMIT_OK)
    {
        Tier1CertReport report = { 0 };
        Tier1CertEmittedStats stats = { 0 };
        emitted->code_reason = tier1_certificate_emitted_check_debug(plan, emitted, &test->output, &test->scratch, 0, 0, &report, &stats);
        emitted->code_checked = true;
        error = emitted->code_reason == TIER1_CERT_EMITTED_OK ? error : TIER1_EMIT_CERTIFICATE;
    }
    return error;
}

static void epoch_test_lazy(Tier1EmitTest* test)
{
    for (uint32_t variant = 0; variant < 4; variant += 1)
    {
        const uint32_t swap = variant & 1;
        const bool carry = variant >= 2;
        IrFunction function = { 0 };
        const bool ready = epoch_test_lazy_function(test, &function, carry);
        Tier1SelectPlan plan = { 0 };
        uint32_t node = BUSTER_IR_NONE;
        IrDominance dominance = { 0 };
        const bool dominated = ready && tier1_terminal_dominance(test, &function, &dominance);
        const Tier1SelectError selected = dominated ? tier1_select_plan(&function, &dominance, &test->output, &test->scratch, &plan, &node) : TIER1_SELECT_ERROR_INVALID;
        tier1_emit_test_expect(test, selected == TIER1_SELECT_OK, "lazy-owner witness selects");
        if (selected != TIER1_SELECT_OK)
        {
            const IrCheck check = ir_verify(&function, &test->scratch, 0);
            fprintf(stderr, "lazy selection=%u node=%u IR=%u\n", selected, node, check.error);
        }
        if (selected == TIER1_SELECT_OK)
        {
            const Tier1EmitOptions options = { .register_mask = tier1_liveness_register_mask(), .certify = true, .measure_kinds = true };
            Tier1EmitResult emitted = { 0 };
            ExchangeEpoch before = { 0 };
            const Tier1EmitError error = epoch_test_mapped_emit(test, &plan, &options, swap != 0, &emitted, &before);
            tier1_emit_test_expect(test, error == TIER1_EMIT_OK && emitted.certified && emitted.code_checked && emitted.code_reason == TIER1_CERT_EMITTED_OK,
                                   "lazy-owner baseline and controlled exchange both receive allocation and emitted-code certificates");
            if (error == TIER1_EMIT_OK)
            {
                uint32_t stores = 0;
                uint32_t loads = 0;
                uint32_t entries = 0;
                for (uint32_t r = 0; r < emitted.code.count; r += 1)
                {
                    stores += emitted.measure_kinds[r] == 'C';
                    loads += emitted.measure_kinds[r] == 'R';
                    entries += emitted.measure_kinds[r] == 'p';
                }
                uint32_t caller_stores = 0;
                uint32_t caller_loads = 0;
                uint32_t callee_stores = 0;
                uint32_t callee_loads = 0;
                for (uint32_t block = 0; block < before.blocks; block += 1)
                {
                    caller_stores += before.stores[(uint64_t)block * 16 + X86_REGISTER_RDI];
                    caller_loads += before.loads[(uint64_t)block * 16 + X86_REGISTER_RDI];
                    callee_stores += before.stores[(uint64_t)block * 16 + X86_REGISTER_RBX];
                    callee_loads += before.loads[(uint64_t)block * 16 + X86_REGISTER_RBX];
                }
                tier1_emit_test_expect(test, before.blocks == (carry ? 3u : 1u) && caller_stores == 1 && caller_loads == (carry ? 3u : 1u) &&
                                           callee_stores == 2 && callee_loads == 2,
                                       "one retained caller epoch and two distinct callee-owner epochs are reconstructed before mapping");
                tier1_emit_test_expect(test, stores == (swap != 0 ? callee_stores : caller_stores) && loads == (swap != 0 ? callee_loads : caller_loads) &&
                                           stores == 1 + swap && loads == (swap != 0 ? 2u : carry ? 3u : 1u) && entries == swap,
                                       "the selected abstract column predicts the actual mapped C/R records and separate entry tax exactly");
                printf("lazy witness %s carry=%u: emitted C=%u R=%u entry=%u; original abstract RDI=%u/%u RBX=%u/%u\n",
                       swap != 0 ? "swapped" : "baseline", carry, stores, loads, entries, caller_stores, caller_loads, callee_stores, callee_loads);
                epoch_test_oracle(test, &plan, &emitted, swap != 0 ? "lazy-swapped" : "lazy-baseline");
            }
            else
            {
                fprintf(stderr, "lazy witness swap=%u emission=%u certificate=%u\n", swap, error, emitted.code_reason);
            }
        }
        arena_pop_to(&test->output, 0);
        arena_pop_to(&test->input, 0);
    }
}

static void epoch_test_projection(Tier1EmitTest* test)
{
    for (uint32_t flags = 0; flags < 4; flags += 1)
    {
        IrFunction function = { 0 };
        const bool ready = epoch_test_recipe_function(test, &function);
        Tier1SelectPlan plan = { 0 };
        uint32_t node = BUSTER_IR_NONE;
        const Tier1SelectError selected = ready ? tier1_select_plan(&function, 0, &test->output, &test->scratch, &plan, &node) : TIER1_SELECT_ERROR_INVALID;
        tier1_emit_test_expect(test, selected == TIER1_SELECT_OK, "projection pressure fixture selects");
        if (selected == TIER1_SELECT_OK)
        {
            const Tier1EmitOptions options = {
                .register_mask = tier1_liveness_register_mask(),
                .certify = true,
                .measure_kinds = true,
                .rematerialize = (flags & 1) != 0,
                .frame_flags = (flags & 2) != 0 ? BUSTER_TIER1_FRAME_KEEP_POINTER : 0,
            };
            Tier1EmitResult emitted = { 0 };
            ExchangeEpoch before = { 0 };
            const Tier1EmitError error = epoch_test_mapped_emit(test, &plan, &options, true, &emitted, &before);
            tier1_emit_test_expect(test, error == TIER1_EMIT_OK, "controlled recipe/pressure mapping receives actual allocation and code certificates");
            if (error == TIER1_EMIT_OK)
            {
                ExchangeEpoch after = { 0 };
                const Tier1EmitError counted = exchange_epoch_build(&plan, &emitted, &emitted.cfg_input, &emitted.cfg, &test->output, &test->scratch, &after);
                tier1_emit_test_expect(test, counted == TIER1_EMIT_OK && before.blocks == after.blocks, "count the mapped state for the full abstract-column projection proof");
                if (counted == TIER1_EMIT_OK)
                {
                    for (uint32_t b = 0; b < before.blocks; b += 1)
                    {
                        for (uint32_t reg = 0; reg < 16; reg += 1)
                        {
                            const uint32_t mapped = reg == X86_REGISTER_RDI ? X86_REGISTER_RBX : reg == X86_REGISTER_RBX ? X86_REGISTER_RDI : reg;
                            const uint64_t old = (uint64_t)b * 16 + reg;
                            const uint64_t next = (uint64_t)b * 16 + mapped;
                            tier1_emit_test_expect(test, before.stores[old] == after.stores[next] && before.loads[old] == after.loads[next],
                                                   "every abstract GPR's per-block C/R epoch column commutes with the physical permutation");
                        }
                    }
                }
                epoch_test_oracle(test, &plan, &emitted, "mapped-pressure-recipes");
            }
            else
            {
                fprintf(stderr, "mapped pressure flags=%u error=%u certificate=%u\n", flags, error, emitted.code_reason);
            }
        }
        arena_pop_to(&test->output, 0);
        arena_pop_to(&test->input, 0);
    }
}
