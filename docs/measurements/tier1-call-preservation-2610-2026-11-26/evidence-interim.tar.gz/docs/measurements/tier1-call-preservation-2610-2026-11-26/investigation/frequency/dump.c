// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Read one uniquely sized CFG from the frozen text dump. Preserve its original successor/predecessor order;
// independently sort edge identities to check that the views match before calling the frequency helper.

#define _GNU_SOURCE
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include "frequency.c"

#define BUSTER_FREQUENCY_DUMP_EDGES (1u << 20)

static int frequency_dump_compare(const void* a, const void* b)
{
    const uint64_t left = *(const uint64_t*)a;
    const uint64_t right = *(const uint64_t*)b;
    return (left > right) - (left < right);
}

static bool frequency_dump_row(char* begin, const char* end, uint32_t* targets, uint32_t* count, uint32_t blocks)
{
    bool ok = true;
    while (ok && begin < end)
    {
        while (begin < end && *begin == ' ')
        {
            begin += 1;
        }
        if (begin < end)
        {
            char* next = 0;
            errno = 0;
            const unsigned long id = strtoul(begin, &next, 10);
            ok = errno == 0 && next > begin && next <= end && id < blocks && *count < BUSTER_FREQUENCY_DUMP_EDGES;
            if (ok)
            {
                targets[(*count)++] = (uint32_t)id;
                begin = next;
            }
        }
    }
    return ok;
}

int main(int argc, char** argv)
{
    int result = 1;
    const uint32_t blocks = argc == 4 ? (uint32_t)strtoul(argv[1], 0, 10) : 0;
    const uint32_t rounds = argc == 4 ? (uint32_t)strtoul(argv[2], 0, 10) : 0;
    bool ok = blocks != 0 && blocks <= 1000000 && rounds != 0;
    uint32_t* const so = ok ? calloc((size_t)blocks + 1, sizeof(uint32_t)) : 0;
    uint32_t* const po = ok ? calloc((size_t)blocks + 1, sizeof(uint32_t)) : 0;
    uint32_t* const ss = ok ? malloc(BUSTER_FREQUENCY_DUMP_EDGES * sizeof(uint32_t)) : 0;
    uint32_t* const pp = ok ? malloc(BUSTER_FREQUENCY_DUMP_EDGES * sizeof(uint32_t)) : 0;
    uint32_t sn = 0;
    uint32_t pn = 0;
    uint32_t rows = 0;
    uint32_t matches = 0;
    uint32_t instructions = 0;
    bool selected = false;
    char* line = 0;
    size_t capacity = 0;
    ok = ok && so != 0 && po != 0 && ss != 0 && pp != 0;
    while (ok && getline(&line, &capacity, stdin) >= 0)
    {
        uint32_t header_instructions = 0;
        uint32_t header_blocks = 0;
        if (sscanf(line, "DUMP function instructions=%u blocks=%u", &header_instructions, &header_blocks) == 2)
        {
            selected = header_blocks == blocks;
            if (selected)
            {
                matches += 1;
                instructions = header_instructions;
                ok = matches == 1;
            }
        }
        else if (selected && line[0] == 'B' && line[1] == ' ')
        {
            uint32_t block = UINT32_MAX;
            char* const preds = strstr(line, " preds");
            char* const succs = strstr(line, " succs");
            char* const phis = strstr(line, " phis");
            ok = sscanf(line, "B %u", &block) == 1 && block == rows && rows < blocks && preds != 0 && succs != 0 && phis != 0 && preds < succs && succs < phis;
            if (ok)
            {
                so[block] = sn;
                po[block] = pn;
                ok = frequency_dump_row(preds + 6, succs, pp, &pn, blocks) && frequency_dump_row(succs + 6, phis, ss, &sn, blocks);
                rows += 1;
            }
        }
    }
    ok = ok && !ferror(stdin) && rows == blocks && matches == 1 && sn == pn;
    uint64_t* const source_edges = ok ? malloc((size_t)sn * sizeof(uint64_t)) : 0;
    uint64_t* const target_edges = ok ? malloc((size_t)sn * sizeof(uint64_t)) : 0;
    ok = ok && source_edges != 0 && target_edges != 0;
    if (ok)
    {
        so[blocks] = sn;
        po[blocks] = pn;
        for (uint32_t b = 0; b < blocks; b += 1)
        {
            for (uint32_t e = so[b]; e < so[b + 1]; e += 1)
            {
                source_edges[e] = ((uint64_t)b << 32) | ss[e];
            }
            for (uint32_t e = po[b]; e < po[b + 1]; e += 1)
            {
                target_edges[e] = ((uint64_t)pp[e] << 32) | b;
            }
        }
        qsort(source_edges, sn, sizeof(uint64_t), frequency_dump_compare);
        qsort(target_edges, sn, sizeof(uint64_t), frequency_dump_compare);
        ok = memcmp(source_edges, target_edges, (size_t)sn * sizeof(uint64_t)) == 0;
        for (uint32_t e = 1; ok && e < sn; e += 1)
        {
            ok = source_edges[e] != source_edges[e - 1];
        }
    }
    const uint64_t workspace_bytes = tier1_frequency_workspace_bytes(blocks);
    void* const workspace = ok ? malloc((size_t)workspace_bytes) : 0;
    uint64_t* const weights = ok ? calloc(blocks, sizeof(uint64_t)) : 0;
    ok = ok && workspace != 0 && weights != 0;
    if (ok)
    {
        const Tier1FrequencyGraph graph = {
            .successor_offsets = so,
            .successors = ss,
            .predecessor_offsets = po,
            .predecessors = pp,
            .block_count = blocks,
            .edge_count = sn,
            .entry = 0,
        };
        const Tier1FrequencyLimits limits = {
            .rounds = rounds,
            .work = BUSTER_TIER1_FREQUENCY_WORK,
        };
        Tier1FrequencyStats stats = { 0 };
        const Tier1FrequencyStatus status = tier1_frequency_estimate(&graph, &limits, workspace, workspace_bytes, weights, blocks, &stats);
        printf("blocks=%u edges=%u instructions=%u matching_views=yes status=%u rounds=%u work=%" PRIu64 " reached=%u absorbed=%" PRIu64 " pending=%" PRIu64 "\n",
               blocks, sn, instructions, status, stats.rounds, stats.work, stats.reachable_blocks, stats.absorbed_mass, stats.pending_mass);
        result = status == TIER1_FREQUENCY_OK ? 0 : 2;
        if (status == TIER1_FREQUENCY_OK)
        {
            FILE* const output = fopen(argv[3], "w");
            if (output != 0)
            {
                fprintf(output, "block\tvisits_q32\tsuccessors\tpredecessors\n");
                for (uint32_t b = 0; b < blocks; b += 1)
                {
                    fprintf(output, "%u\t%" PRIu64 "\t%u\t%u\n", b, weights[b], so[b + 1] - so[b], po[b + 1] - po[b]);
                }
                result = fclose(output) != 0 ? 1 : result;
            }
            else
            {
                result = 1;
            }
        }
    }
    else
    {
        fprintf(stderr, "usage: dump-frequency BLOCK_COUNT ROUNDS WEIGHTS_TSV < frozen.cfg.dump; requires one uniquely sized, matching-view CFG\n");
    }
    free(line);
    free(weights);
    free(workspace);
    free(source_edges);
    free(target_edges);
    free(so);
    free(po);
    free(ss);
    free(pp);
    return result;
}
