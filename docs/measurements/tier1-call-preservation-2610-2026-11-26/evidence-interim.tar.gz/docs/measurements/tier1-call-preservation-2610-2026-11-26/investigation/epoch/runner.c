// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
#include "tests.c"

int main(void)
{
    int result = 1;
    arena_page_policy("0");
    setenv("BUSTER_TIER1_EXPERIMENT", "0", 1);
    if (x86_encoder_initialize() && x86_semantics_initialize() && x86_zen5_initialize())
    {
        Tier1EmitTest test = {
            .input = arena_reserve(32u << 20),
            .output = arena_reserve(64u << 20),
            .scratch = arena_reserve(32u << 20),
            .allowed = malloc(X86_FORM_COUNT),
        };
        if (test.input.base != 0 && test.output.base != 0 && test.scratch.base != 0 && test.allowed != 0)
        {
            const X86Target target = { .architecture = X86_ARCH_BASELINE };
            x86_target_forms(&target, test.allowed);
            epoch_test_existing(&test);
            epoch_test_lazy(&test);
            epoch_test_projection(&test);
            tier1_emit_test_expect(&test, epoch_test_transitions != 0 && epoch_test_dropped != 0 && epoch_test_covered != 0 && epoch_test_carried != 0,
                                   "the epoch oracle reaches actual transitions, dropped/covered nodes and inherited rows");
            tier1_emit_test_expect(&test, epoch_test_actual_stores != 0 && epoch_test_actual_loads != 0, "the epoch oracle reaches actual emitted C/R records");
            printf("epoch oracle: %" PRIu64 " checks, %" PRIu64 " failures; %" PRIu64 " compiles, %" PRIu64 " C/%" PRIu64 " R, %" PRIu64 " transitions, %" PRIu64 " dropped, %" PRIu64 " covered, %" PRIu64 " carried blocks\n",
                   test.checks, test.failures, epoch_test_compiles, epoch_test_actual_stores, epoch_test_actual_loads, epoch_test_transitions, epoch_test_dropped, epoch_test_covered, epoch_test_carried);
            result = test.failures != 0;
        }
        free(test.allowed);
        arena_release(&test.input);
        arena_release(&test.output);
        arena_release(&test.scratch);
    }
    return result;
}
