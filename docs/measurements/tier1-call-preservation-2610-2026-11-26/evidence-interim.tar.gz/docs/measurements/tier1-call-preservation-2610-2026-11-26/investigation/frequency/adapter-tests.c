// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Test the adapter with the actual repository arena implementation. The small CFG descriptor below projects only
// the six fields the adapter reads; full backend type integration remains a separate compile check owned by root.

#define _GNU_SOURCE
#include <inttypes.h>
#include <stdlib.h>
#include "../../buster-exchange/src/buster/compiler/lane.c"
#include "frequency.c"

typedef struct Tier1CfgInput Tier1CfgInput;
struct Tier1CfgInput
{
    const uint32_t* successor_offsets;
    const uint32_t* successors;
    const uint32_t* predecessor_offsets;
    const uint32_t* predecessors;
    uint32_t block_count;
    uint32_t edge_count;
};

#include "adapter.c"

int main(void)
{
    uint32_t checks = 0;
    uint32_t failures = 0;
    uint8_t storage[8192] __attribute__((aligned(64)));
    const uint32_t so[] = { 0, 2, 3, 4, 4 };
    const uint32_t ss[] = { 1, 2, 3, 3 };
    const uint32_t po[] = { 0, 0, 1, 2, 4 };
    const uint32_t pp[] = { 0, 0, 1, 2 };
    const Tier1CfgInput input = {
        .successor_offsets = so,
        .successors = ss,
        .predecessor_offsets = po,
        .predecessors = pp,
        .block_count = 4,
        .edge_count = 4,
    };
    const uint64_t expected[] = {
        BUSTER_TIER1_FREQUENCY_ONE,
        BUSTER_TIER1_FREQUENCY_ONE / 2,
        BUSTER_TIER1_FREQUENCY_ONE / 2,
        BUSTER_TIER1_FREQUENCY_ONE,
    };
    for (uint32_t trial = 0; trial < 4; trial += 1)
    {
        memset(storage, 0x93, sizeof(storage));
        Arena scratch = {
            .base = storage,
            .length = 3,
            .capacity = trial == 0 ? sizeof(storage) : trial == 1 ? 39 : trial == 2 ? 151 : sizeof(storage),
            .peak = 3,
        };
        uint64_t old = 91;
        uint64_t* weights = &old;
        Tier1CfgInput probe = input;
        probe.block_count = trial == 3 ? 0 : probe.block_count;
        const bool ok = tier1_emit_exchange_frequency(&probe, &scratch, &weights);
        const bool success = trial == 0;
        const bool valid = ok == success && scratch.length == (success ? 40 : 3) &&
                           (success ? weights == (uint64_t*)(storage + 8) && memcmp(weights, expected, sizeof(expected)) == 0 : weights == &old && old == 91);
        checks += 1;
        failures += !valid;
        for (uint32_t j = 0; j < 3; j += 1)
        {
            checks += 1;
            failures += storage[j] != 0x93;
        }
        printf("adapter trial=%u success=%u length=%" PRIu64 " peak=%" PRIu64 " valid=%u\n", trial, ok, scratch.length, scratch.peak, valid);
    }
    // A long backward-layout DAG is terminating but exceeds the adapter's fixed sweep limit. Only entry is block0;
    // 0 -> 129 -> 128 -> ... -> 1 makes the refusal independent of an infinite-cycle diagnosis.
    uint32_t reverse_so[131];
    uint32_t reverse_po[131];
    uint32_t reverse_ss[129];
    uint32_t reverse_pp[129];
    uint32_t sn = 0;
    uint32_t pn = 0;
    for (uint32_t b = 0; b < 130; b += 1)
    {
        reverse_so[b] = sn;
        reverse_po[b] = pn;
        if (b == 0 || b > 1)
        {
            reverse_ss[sn++] = b == 0 ? 129 : b - 1;
        }
        if (b != 0)
        {
            reverse_pp[pn++] = b == 129 ? 0 : b + 1;
        }
    }
    reverse_so[130] = sn;
    reverse_po[130] = pn;
    const Tier1CfgInput reverse = {
        .successor_offsets = reverse_so,
        .successors = reverse_ss,
        .predecessor_offsets = reverse_po,
        .predecessors = reverse_pp,
        .block_count = 130,
        .edge_count = 129,
    };
    Arena scratch = {
        .base = storage,
        .length = 3,
        .capacity = sizeof(storage),
    };
    uint64_t old = 93;
    uint64_t* weights = &old;
    const bool ok = tier1_emit_exchange_frequency(&reverse, &scratch, &weights);
    checks += 1;
    failures += ok || scratch.length != 3 || weights != &old || old != 93;
    printf("adapter checks=%u failures=%u\n", checks, failures);
    return failures == 0 ? 0 : 1;
}
