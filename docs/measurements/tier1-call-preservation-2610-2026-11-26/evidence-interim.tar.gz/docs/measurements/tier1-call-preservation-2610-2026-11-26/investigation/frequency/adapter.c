// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Include after frequency.c and the existing Arena/Tier1CfgInput definitions. The CFG has already passed the
// normal tier1_cfg_input_valid transpose check. Input storage, scratch and weights' pointer cell are disjoint.
// Success retains only the weight column; refusal preserves both the prior arena length and pointer cell.
static bool tier1_emit_exchange_frequency(const Tier1CfgInput* input, Arena* scratch, uint64_t** weights)
{
    const uint64_t mark = scratch->length;
    const uint32_t blocks = input->block_count;
    const Tier1FrequencyGraph graph = {
        .successor_offsets = input->successor_offsets,
        .successors = input->successors,
        .predecessor_offsets = input->predecessor_offsets,
        .predecessors = input->predecessors,
        .block_count = blocks,
        .edge_count = input->edge_count,
        .entry = 0,
    };
    const Tier1FrequencyLimits limits = {
        .rounds = BUSTER_TIER1_FREQUENCY_ROUNDS,
        .work = BUSTER_TIER1_FREQUENCY_WORK,
    };
    uint64_t* result = arena_push_array(scratch, blocks, sizeof(uint64_t), _Alignof(uint64_t));
    const uint64_t retained = scratch->length;
    const uint64_t bytes = tier1_frequency_workspace_bytes(blocks);
    void* workspace = result != 0 ? arena_push_array(scratch, bytes, 1, _Alignof(uint64_t)) : 0;
    const bool ok = workspace != 0 && tier1_frequency_estimate(&graph, &limits, workspace, bytes, result, blocks, 0) == TIER1_FREQUENCY_OK;
    if (ok)
    {
        arena_pop_to(scratch, retained);
        *weights = result;
    }
    else
    {
        arena_pop_to(scratch, mark);
    }
    return ok;
}
