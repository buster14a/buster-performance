// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Make one explicit private mutant; neither the original helper nor its tests are changed.
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv)
{
    int result = 1;
    const char* before = argc == 4 && strcmp(argv[3], "rotor") == 0 ?
                         "rotors[b] = remainder < room ? start + remainder : remainder - room;" :
                         "const uint32_t remainder = (uint32_t)(mass % degree);";
    const char* after = argc == 4 && strcmp(argv[3], "rotor") == 0 ?
                        "rotors[b] = room != 0 ? start : 0;" :
                        "const uint32_t remainder = 0u * (uint32_t)(mass % degree);";
    FILE* const input = argc == 4 ? fopen(argv[1], "rb") : 0;
    char* bytes = 0;
    long length = 0;
    bool ok = input != 0 && fseek(input, 0, SEEK_END) == 0;
    if (ok)
    {
        length = ftell(input);
        ok = length > 0 && length < 1048576 && fseek(input, 0, SEEK_SET) == 0;
        bytes = ok ? malloc((size_t)length + 1) : 0;
        ok = ok && bytes != 0 && fread(bytes, 1, (size_t)length, input) == (size_t)length;
    }
    if (input != 0)
    {
        ok = fclose(input) == 0 && ok;
    }
    if (ok)
    {
        bytes[length] = 0;
        const char* const found = strstr(bytes, before);
        ok = found != 0 && strstr(found + strlen(before), before) == 0;
        FILE* const output = ok ? fopen(argv[2], "wb") : 0;
        if (output != 0)
        {
            const size_t prefix = (size_t)(found - bytes);
            const size_t suffix = (size_t)length - prefix - strlen(before);
            ok = fwrite(bytes, 1, prefix, output) == prefix && fputs(after, output) >= 0 &&
                 fwrite(found + strlen(before), 1, suffix, output) == suffix;
            ok = fclose(output) == 0 && ok;
            result = ok ? 0 : 1;
        }
    }
    free(bytes);
    return result;
}
