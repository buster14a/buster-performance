# Provisional investigation snapshot

Frozen after the executor restart, before the production-shaped epoch API and frequency arena adapter could be rebuilt.
The recorded epoch 838/0 run precedes the API reshaping. The frequency 1,100/0 run and yy_reduce convergence receipt
cover the isolated core, not a complete new compiler. Generated focused unity files are temporary test harnesses.
No source in this directory is accepted or dynamically qualified for production.
