#include <stdio.h>
static long calls;
static long* first;
__attribute__((noinline)) void tier1_take(long* p)
{
    calls += 1;
    first = first == 0 ? p : first;
    *p = (p - first) * 100 + calls;
}
long tier1_frame_rbx(long x)
{
    long a[8];
    long *p0 = &a[0], *p1 = &a[1], *p2 = &a[2], *p3 = &a[3], *p4 = &a[4], *p5 = &a[5], *p6 = &a[6];
    *p0 = x;
    tier1_take(p0); tier1_take(p1); tier1_take(p2); tier1_take(p3); tier1_take(p4); tier1_take(p5); tier1_take(p6);
    tier1_take(p6); tier1_take(p5); tier1_take(p4); tier1_take(p3); tier1_take(p2); tier1_take(p1); tier1_take(p0);
    return x + *p0 + *p1 * 3 + *p2 * 5 + *p3 * 7 + *p4 * 11 + *p5 * 13 + *p6 * 17;
}
long tier1_frame_rbp(long x)
{
    long a[8];
    long *p0 = &a[0], *p1 = &a[1], *p2 = &a[2], *p3 = &a[3], *p4 = &a[4], *p5 = &a[5], *p6 = &a[6];
    *p0 = x;
    tier1_take(p1); tier1_take(p2); tier1_take(p3); tier1_take(p4); tier1_take(p5); tier1_take(p6); tier1_take(p0);
    tier1_take(p0); tier1_take(p6); tier1_take(p5); tier1_take(p4); tier1_take(p3); tier1_take(p2); tier1_take(p1);
    return x + *p0 + *p1 * 3 + *p2 * 5 + *p3 * 7 + *p4 * 11 + *p5 * 13 + *p6 * 17;
}
long tier1_frame_r12(long x)
{
    long a[8];
    long *p0 = &a[0], *p1 = &a[1], *p2 = &a[2], *p3 = &a[3], *p4 = &a[4], *p5 = &a[5], *p6 = &a[6];
    *p0 = x;
    tier1_take(p5); tier1_take(p2); tier1_take(p3); tier1_take(p1); tier1_take(p4); tier1_take(p0); tier1_take(p6);
    tier1_take(p1); tier1_take(p6); tier1_take(p4); tier1_take(p5); tier1_take(p3); tier1_take(p2); tier1_take(p0);
    return x + *p0 + *p1 * 3 + *p2 * 5 + *p3 * 7 + *p4 * 11 + *p5 * 13 + *p6 * 17;
}
long tier1_frame_r13(long x)
{
    long a[8];
    long *p0 = &a[0], *p1 = &a[1], *p2 = &a[2], *p3 = &a[3], *p4 = &a[4], *p5 = &a[5], *p6 = &a[6];
    *p0 = x;
    tier1_take(p1); tier1_take(p2); tier1_take(p3); tier1_take(p4); tier1_take(p5); tier1_take(p0); tier1_take(p6);
    tier1_take(p1); tier1_take(p6); tier1_take(p4); tier1_take(p5); tier1_take(p2); tier1_take(p3); tier1_take(p0);
    return x + *p0 + *p1 * 3 + *p2 * 5 + *p3 * 7 + *p4 * 11 + *p5 * 13 + *p6 * 17;
}
int main(void)
{
    long (*const functions[4])(long) = { tier1_frame_rbx, tier1_frame_rbp, tier1_frame_r12, tier1_frame_r13 };
    for (long x = 0; x < 3; x += 1)
    {
        for (int f = 0; f < 4; f += 1)
        {
            calls = x;
            first = 0;
            printf("%ld ", functions[f](x));
        }
    }
    printf("\n");
    return 0;
}
