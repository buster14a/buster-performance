#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
set -euo pipefail
unset BUSTER_TIER1_DUMP_BLOCKS BUSTER_TIER1_DUMP_FILE
task=/workspace/scratch/f0b04b7641b0
export PATH=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
compiler=$task/trace-ci/product/bin/compiler
inputs=$task/buster/build/2610-inputs
resource=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/lib/clang/23/include
out=$task/trace-artifacts
cd "$task"
if [ -e "$out/speedtest1" ] || [ -e "$out/speedtest1.kinds" ]; then
    printf 'Refusing to overwrite an existing trace executable or sidecar.\n' >&2
    exit 1
fi
BUSTER_TIER1_EXPERIMENT=128 BUSTER_TIER1_EXCHANGE_TRACE=26310 BUSTER_TIER1_KINDS="$out/speedtest1.kinds" "$compiler" --tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --tier1-report -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$inputs/sqlite" "-I$inputs" -o "$out/speedtest1" "$task/baseline-artifacts/speedtest1-unity.c" -lm > "$out/st-build.txt" 2>&1
sha256sum "$compiler" "$task/exchange-artifacts/128/speedtest1" "$out/speedtest1" "$task/exchange-artifacts/128/speedtest1.kinds" "$out/speedtest1.kinds" > "$out/parity.sha256"
cmp "$task/exchange-artifacts/128/speedtest1" "$out/speedtest1"
cmp "$task/exchange-artifacts/128/speedtest1.kinds" "$out/speedtest1.kinds"
printf 'Trace-only SQLite: whole-ELF and instruction-sidecar parity exact.\n'
