# Deliberate omissions

- Generated compiler, corpus, oracle and native-fixture executables. Their recorded hashes remain in the receipts.
- Compiler artifact ZIP/tar payloads, after checksum verification and selective extraction. GitHub run/artifact IDs
  and the compiler/product-manifest digests identify the external artifacts.
- Complete SQLite/Lua source archives and system headers/libraries. Immutable input locations and per-file hashes
  are retained; only the small existing frame fixture and three-line unity source are incorporated.
- Huge raw full-corpus CFG dumps. Selected RunParser, yy_reduce and luaV_execute values/blocks/edges plus hashes of the source
  dumps are included. The streaming RunParser capture helper avoids materializing a full threshold-1 dump.
- Raw Callgrind captures and complete disassembly accounting. The measurement owner retains and validates those
  separately before final stable-path summaries are merged. Filtered diagnostic rows retain their original audit
  headers; they are not full-program accounting files.
- Failed local full-build intermediates and the private checker-dispatch trim, which never produced a measurement
  compiler. Their failure status is recorded in the baseline command receipt; no result depends on them.

Archived compiler and focused-validation manifests may name these omitted binaries. They are historical external
identity records. Use the packet-root SHA256SUMS to verify the files actually included here.
