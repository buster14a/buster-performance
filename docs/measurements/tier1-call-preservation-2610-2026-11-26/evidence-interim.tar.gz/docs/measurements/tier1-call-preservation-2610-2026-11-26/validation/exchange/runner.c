// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
#include "tests.c"

int main(void)
{
    int result = 1;
    arena_page_policy("0");
    if (x86_encoder_initialize() && x86_semantics_initialize() && x86_zen5_initialize())
    {
        Tier1EmitTest native = {
            .input = arena_reserve(32u << 20),
            .output = arena_reserve(64u << 20),
            .scratch = arena_reserve(32u << 20),
            .allowed = malloc(X86_FORM_COUNT),
        };
        uint8_t* host_forms = malloc(X86_FORM_COUNT);
        if (native.input.base != 0 && native.output.base != 0 && native.scratch.base != 0 && native.allowed != 0 && host_forms != 0)
        {
            const X86Target baseline = { .architecture = X86_ARCH_BASELINE };
            const X86Target host = x86_target_native();
            x86_target_forms(&baseline, native.allowed);
            x86_target_forms(&host, host_forms);
            native.native_allowed = host_forms;
            Tier1CfgTestTally tally = { .oracle = true };
            exchange_test_shapes(&tally, &native.output, &native.scratch);
            printf("exchange map: %" PRIu64 " checks, %" PRIu64 " failures; %" PRIu64 " complete CFGs, %" PRIu64 " moves, %" PRIu64 " scratch moves, %" PRIu64 " spill fragments, %" PRIu64 " remat fragments, %" PRIu64 " certificates\n",
                   tally.checks, tally.failures, tally.allocations, tally.moves, tally.scratch_moves, tally.spills, tally.unread_entries, tally.certificates);
            exchange_test_native(&native);
            printf("exchange native: %" PRIu64 " checks, %" PRIu64 " failures, %" PRIu64 " skips\n", native.checks, native.failures, native.native_skipped);
            result = tally.failures != 0 || native.failures != 0 || native.native_skipped != 0;
        }
        free(host_forms);
        free(native.allowed);
        arena_release(&native.input);
        arena_release(&native.output);
        arena_release(&native.scratch);
    }
    return result;
}
