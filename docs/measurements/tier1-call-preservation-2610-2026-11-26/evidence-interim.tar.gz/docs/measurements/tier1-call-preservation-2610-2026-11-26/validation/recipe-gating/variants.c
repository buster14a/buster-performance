#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <limits.h>
#define BUSTER_IR_NONE UINT32_MAX
#define BUSTER_IR_SLOT_OVERFLOW_AREA 1
#define BUSTER_TIER1_EMIT_CFG_RECIPE_DEPTH 8
#define BUSTER_TIER1_ALLOCATE_GPR 0
#define BUSTER_TIER1_ALLOCATE_MASK 2
#define BUSTER_TIER1_REMAT_NONE 0
#define BUSTER_TIER1_REMAT_INTEGER 1
#define BUSTER_TIER1_REMAT_SYMBOL 2
#define BUSTER_TIER1_REMAT_STACK 3
#define BUSTER_TIER1_REMAT_STABLE 1
#define BUSTER_TIER1_REMAT_GOT 2
#define BUSTER_TIER1_ACCESS_DIRECT 0
#define BUSTER_TIER1_ACCESS_GOT 1
#define BUSTER_ABI_LOCATION_STACK 2
#define BUSTER_ABI_FLAG_HIGH 1
#define BUSTER_ABI_FLAG_LOW 2
#define BUSTER_ABI_FLAG_PAYLOAD 4
#define BUSTER_ABI_FLAG_FIRST 8
enum { TIER1_RULE_NONE, TIER1_RULE_CONSTANT, TIER1_RULE_SYMBOL_ADDRESS, TIER1_RULE_STACK_ADDRESS, TIER1_RULE_COPY, TIER1_RULE_ADDRESS };
typedef struct { uint32_t flags, size, alignment; } IrSlot;
typedef struct { uint32_t kind, flags; uint64_t stack_offset; } AbiLocation;
typedef struct { AbiLocation location; uint32_t size; } IrPassed;
typedef struct { uint32_t instruction_count, slot_count; IrSlot* slots; uint32_t parameter_count, parameter_passed; IrPassed* passed; struct { uint64_t stack_bytes; } incoming; } IrFunction;
typedef struct { uint8_t rule; uint32_t values[3], stack_object; int32_t displacement; uint64_t immediate; bool rip; } Tier1SelectPattern;
typedef struct { const IrFunction* function; const Tier1SelectPattern* patterns; const uint8_t* covered; } Tier1SelectPlan;
typedef struct { const uint8_t* classes; } Tier1EmitPrepared;
typedef struct { Tier1EmitPrepared prepared; uint32_t symbol_access_count; const uint8_t* symbol_access; } Tier1EmitResult;
typedef struct { uint32_t checks, failures; } Tier1EmitTest;
static void tier1_emit_test_expect(Tier1EmitTest* test, bool pass, const char* message)
{
    test->checks += 1;
    test->failures += !pass;
    if (!pass) fprintf(stderr, "check %u failed: %s\n", test->checks, message);
}
static const IrPassed* tier1_select_parameter_record(const IrFunction* function, uint32_t parameter)
{
    return function->parameter_passed != 0 && parameter < function->parameter_count ? &function->passed[function->parameter_passed - 1 + parameter] : 0;
}
static bool tier1_select_location_whole(AbiLocation location)
{
    return location.kind == BUSTER_ABI_LOCATION_STACK && (location.flags & (BUSTER_ABI_FLAG_HIGH | BUSTER_ABI_FLAG_LOW | BUSTER_ABI_FLAG_PAYLOAD | BUSTER_ABI_FLAG_FIRST)) == 0;
}
static bool tier1_emit_cfg_overflow_area(const IrFunction* function, uint32_t slot)
{
    return slot < function->slot_count && (function->slots[slot].flags & BUSTER_IR_SLOT_OVERFLOW_AREA) != 0;
}
static bool tier1_emit_cfg_incoming_object(const IrFunction* function, uint32_t object, uint64_t* past)
{
    const uint32_t parameter = object - function->slot_count;
    const IrPassed* record = object >= function->slot_count && parameter < function->parameter_count ? tier1_select_parameter_record(function, parameter) : 0;
    const bool stacked = record != 0 && record->size != 0 && tier1_select_location_whole(record->location);
    const bool overflow = tier1_emit_cfg_overflow_area(function, object);
    *past = overflow ? function->incoming.stack_bytes : stacked ? record->location.stack_offset : 0;
    return overflow || stacked;
}
static uint32_t tier1_emit_class(const Tier1EmitPrepared* prepared, uint32_t value)
{
    return prepared->classes != 0 ? prepared->classes[value] : BUSTER_TIER1_ALLOCATE_GPR;
}
#include <stdlib.h>
static __attribute__((unused)) uint32_t tier1_measure_experiment(void)
{
    const char* const value = getenv("BUSTER_TIER1_EXPERIMENT");
    return value != 0 ? (uint32_t)strtoul(value, 0, 0) & 15u : 0;
}
static void tier1_emit_cfg_recipes(const Tier1SelectPlan* plan, const Tier1EmitResult* emitted, uint8_t* operations, uint8_t* flags, uint64_t* values, int64_t* addends)
{
    const bool frame_recipes = (tier1_measure_experiment() & 1u) != 0;
    const uint32_t count = plan->function->instruction_count;
    for (uint32_t node = 0; node < count; node += 1)
    {
        // The chain's root, through copies and constant displacements, each of them a value of its own (uncovered).
        uint32_t root = node;
        int64_t displacement = 0;
        bool walking = !plan->covered[node];
        for (uint32_t depth = 0; walking && depth < BUSTER_TIER1_EMIT_CFG_RECIPE_DEPTH; depth += 1)
        {
            const Tier1SelectPattern* pattern = &plan->patterns[root];
            const bool copy = pattern->rule == TIER1_RULE_COPY;
            const bool offset = pattern->rule == TIER1_RULE_ADDRESS && pattern->values[1] == BUSTER_IR_NONE &&
                                (!frame_recipes || (pattern->stack_object == BUSTER_IR_NONE && !pattern->rip));
            const uint32_t next = copy || offset ? pattern->values[0] : BUSTER_IR_NONE;
            walking = next < count && !plan->covered[next];
            displacement += walking && offset ? pattern->displacement : 0;
            root = walking ? next : root;
        }
        const Tier1SelectPattern* pattern = &plan->patterns[root];
        // No mask has a recipe (#179): a general register's copy can't recompute an opmask register's value, whose
        // recipe would need kxor, kxnor or kmov forms of its own. The masks' rules are none of those below, and neither
        // a mask nor a chain through one takes them.
        const bool mask = tier1_emit_class(&emitted->prepared, node) == BUSTER_TIER1_ALLOCATE_MASK || tier1_emit_class(&emitted->prepared, root) == BUSTER_TIER1_ALLOCATE_MASK;
        const uint8_t rule = plan->covered[root] || mask ? TIER1_RULE_NONE : pattern->rule;
        // A folded symbol's lea (#2573): the symbol, at its own displacement past the chain's.
        const bool folded = rule == TIER1_RULE_ADDRESS && pattern->stack_object != BUSTER_IR_NONE && pattern->values[1] == BUSTER_IR_NONE &&
                            (frame_recipes ? pattern->values[0] == BUSTER_IR_NONE : pattern->rip);
        const bool symbol_address = rule == TIER1_RULE_SYMBOL_ADDRESS || (folded && (!frame_recipes || pattern->rip));
        const uint32_t object = folded ? pattern->stack_object : (uint32_t)pattern->immediate;
        const uint8_t access = symbol_address && object < emitted->symbol_access_count ? emitted->symbol_access[object] : BUSTER_TIER1_ACCESS_DIRECT;
        displacement += folded ? pattern->displacement : 0;
        const bool displaced = displacement != 0;
        const bool fits = displacement >= INT32_MIN && displacement <= INT32_MAX;
        uint64_t past = 0;
        if (rule == TIER1_RULE_CONSTANT && !displaced)
        {
            operations[node] = BUSTER_TIER1_REMAT_INTEGER;
            values[node] = pattern->immediate;
        }
        else if (symbol_address && fits && (access == BUSTER_TIER1_ACCESS_DIRECT || (access == BUSTER_TIER1_ACCESS_GOT && !displaced && !folded)))
        {
            operations[node] = BUSTER_TIER1_REMAT_SYMBOL;
            values[node] = object;
            addends[node] = displacement;
            flags[node] = BUSTER_TIER1_REMAT_STABLE | (access == BUSTER_TIER1_ACCESS_GOT ? BUSTER_TIER1_REMAT_GOT : 0);
        }
        else if ((rule == TIER1_RULE_STACK_ADDRESS || (frame_recipes && folded && !pattern->rip)) && fits && !tier1_emit_cfg_incoming_object(plan->function, object, &past))
        {
            operations[node] = BUSTER_TIER1_REMAT_STACK;
            values[node] = frame_recipes ? object : pattern->immediate;
            addends[node] = displacement;
            flags[node] = BUSTER_TIER1_REMAT_STABLE;
        }
    }
}
static void tier1_frame_recipe_shapes(Tier1EmitTest* test)
{
    IrSlot slots[2] = {
        {
            .size = 64,
            .alignment = 8,
        },
        { .flags = BUSTER_IR_SLOT_OVERFLOW_AREA },
    };
    IrPassed passed = {
        .location = { .kind = BUSTER_ABI_LOCATION_STACK },
        .size = 24,
    };
    const IrFunction function = {
        .instruction_count = 3,
        .slot_count = 2,
        .slots = slots,
        .parameter_count = 1,
        .parameter_passed = 1,
        .passed = &passed,
    };
    for (uint32_t variant = 0; variant < 12; variant += 1)
    {
        Tier1SelectPattern patterns[3] = {
            {
                .rule = TIER1_RULE_ADDRESS,
                .stack_object = 0,
                .values = { BUSTER_IR_NONE, BUSTER_IR_NONE },
                .displacement = 16,
            },
            {
                .rule = TIER1_RULE_COPY,
                .stack_object = BUSTER_IR_NONE,
                .values = { 0, BUSTER_IR_NONE },
            },
            {
                .rule = TIER1_RULE_ADDRESS,
                .stack_object = BUSTER_IR_NONE,
                .values = { 1, BUSTER_IR_NONE },
                .displacement = 24,
            },
        };
        uint8_t covered[3] = { 0 };
        uint8_t classes[3] = { 0 };
        patterns[0].rip = variant == 1;
        patterns[0].values[1] = variant == 2 ? 1 : BUSTER_IR_NONE;
        patterns[0].values[0] = variant == 3 ? 1 : BUSTER_IR_NONE;
        classes[0] = variant == 4 ? BUSTER_TIER1_ALLOCATE_MASK : BUSTER_TIER1_ALLOCATE_GPR;
        covered[0] = variant == 5;
        patterns[0].stack_object = variant == 6 ? 1 : variant == 7 ? 2 : 0;
        patterns[0].displacement = variant == 8 ? INT32_MAX : variant == 9 ? INT32_MIN : 16;
        patterns[2].displacement = variant == 8 ? 1 : variant == 9 ? -1 : 24;
        patterns[0].rule = variant == 10 ? TIER1_RULE_STACK_ADDRESS : TIER1_RULE_ADDRESS;
        covered[2] = variant == 11;
        const Tier1SelectPlan plan = {
            .function = &function,
            .patterns = patterns,
            .covered = covered,
        };
        const Tier1EmitResult emitted = { .prepared = { .classes = classes } };
        uint8_t operations[3] = { 0 };
        uint8_t flags[3] = { 0 };
        uint64_t values[3] = { 0 };
        int64_t addends[3] = { 0 };
        tier1_emit_cfg_recipes(&plan, &emitted, operations, flags, values, addends);
        for (uint32_t node = 0; node < 3; node += 1)
        {
            const bool root = variant < 2 || variant >= 8;
            const bool eligible = root && !(node == 2 && (variant == 8 || variant == 9 || variant == 11));
            const uint8_t operation = eligible ? (variant == 1 ? BUSTER_TIER1_REMAT_SYMBOL : BUSTER_TIER1_REMAT_STACK) : BUSTER_TIER1_REMAT_NONE;
            const int64_t first = variant == 10 ? 0 : patterns[0].displacement;
            const int64_t displacement = eligible ? first + (node == 2 ? patterns[2].displacement : 0) : 0;
            tier1_emit_test_expect(test, operations[node] == operation && values[node] == 0 && addends[node] == displacement &&
                                   flags[node] == (eligible ? BUSTER_TIER1_REMAT_STABLE : 0),
                                   "folded frame recipes keep constant offsets, reject indexed, covered, mask and incoming addresses, and preserve folded symbols");
        }
    }
}
int main(void)
{
    Tier1EmitTest test = { 0 };
    tier1_frame_recipe_shapes(&test);
    printf("recipe-shapes: %u checks, %u failures\n", test.checks, test.failures);
    return test.failures != 0;
}
