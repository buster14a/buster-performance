# Issue 2610: complete CFG register permutation and ABI entry

This scratch harness compiles the actual backend from `buster-exchange`, based
on `8e4d32879e17b7d9548cad54257a2f8461328366`, with the proposed register
exchange. It changes no repository source. `generate.c` takes the production
backend include prefix, uses the modules' normal standalone table ownership,
and replaces only the unrelated command dispatcher with `runner.c`.

## Results

The final passing run has **81 map checks and 62 native checks, zero failures,
and zero native skips**. Three complete CFG fixtures contain all three register
classes, phi swaps, memory pressure and recipes. They retain 42 resolved moves,
including six scratch-register moves, 66 spill fragments and 27 rematerialized
fragments. All six before/after CFG certificates pass both the normal checker
and the independent dense oracle.

The map check snapshots every preexisting byte in the output arena. After a
swap, those bytes must equal the prescribed register rename alone. This checks
all fragment bounds and kinds, spill IDs and inverse maps, edge placement,
resolved move ordering and counts, split metadata, lookup maps, slot tables,
rematerialization markers and other-class registers. Copied value/interval
masks must match the exchange, and only affected general-register incoming
bindings may become zero. ABI use-register hints remain physical. Identity
must allocate nothing and change nothing. Duplicate/out-of-range mappings,
scratch movement, an absent pool member, fixed/sequence registers and static
interval hints are refused transactionally. Three bounded-capacity views fail
each of the mask-copy allocations and must preserve all old bytes and columns.

Two native IR fixtures pass 32 executions against independent C arithmetic.
Each has four separately assembled hostile callees which overwrite caller-save
GPR/vector state, overwrite their red zones and record entry alignment. The
incoming parameter is actually moved from RDI to the already-used RBX, its
binding becomes zero, and no additional callee register is activated. The
displaced RBX value is a frame-address integer needed across the first call;
its computed zero difference is stored and included in the result, so its
preservation affects the semantic oracle. One fixture returns a full I64
parameter; the other returns a signed I8 parameter after canonicalization,
with deliberately dirty upper input bits. Both full emitted-code certificates
and the allocation verifier pass. Each fixture reports one call store and one
call load, with no ordinary spills or CFG edge moves.

## Mutation proof

`mutate.c` copies the emitter include chain locally and changes one expression:
the map retains affected incoming definition masks instead of clearing them.
There are no behavior stubs and no other semantic changes. The mutation build
succeeds, but execution exits **1** with **9 map failures and 2 native emission
failures**. The final CFG certificate rejects the renamed parameter still
bound to its old incoming register before machine code can execute. The source
column assertion, independent allocation verifier and certificate all detect
the bad binding. `mutant-run.log` is the complete failure receipt.

## Reproduction

Use the pinned Clang 23.1.4 toolchain, commit above, archived `cfg.patch`, and
the two archived new source files (`source-map.c` and `source-cost.c`, copied
to their original names under `src/buster/compiler`). From this directory:

```sh
cc -Wall -Wextra -Werror generate.c -o generate
./generate ../buster-exchange/src/buster/compiler/main.c focused.c
clang -O0 -g0 -march=native \
  -I../buster-exchange/src -I../buster-exchange/src/buster/compiler \
  -fwrapv -funsigned-char -fno-strict-aliasing -Wall -Werror \
  -Wno-unused-function -fno-stack-protector \
  -DBUSTER_HOST_SSP_DEFAULT=BUSTER_PREDEFINES_SSP_OFF \
  '-DBUSTER_CLANG_DEFAULT_TARGET="x86_64-unknown-linux-gnu"' \
  -DBUSTER_EXECUTABLE_UNIT -DBUSTER_HOST_STATIC=1 \
  -ffunction-sections -fdata-sections -Wl,--gc-sections \
  focused.c -pthread -ldl -o exchange
./exchange
cc -Wall -Wextra -Werror mutate.c -o mutate
./mutate ../buster-exchange/src/buster/compiler
# Repeat the Clang command with mutant-focused.c and output name mutant.
./mutant
```

The successful build logs are empty. Compiler identity, exact source hashes
and all execution logs are included. This proves the mapping and the tested ABI
semantics. It is not a performance measurement or a proof that static call-live
occupancy predicts actual lazy call-save traffic; the separate cost harness
records that model's counterexample. No full compiler or 9700X build is part of
this local evidence.
