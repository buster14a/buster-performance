# Issue 2610: internal-join avoidance guard

This is scratch-only validation of the guard in the isolated `buster-policy`
worktree. It changes no file in the production `buster` worktree. The base
commit is `96fd0284f8f8173fd191b21c5365ad46ae4b917d`; `soft.patch` is the prior
experimental policy and `guard.patch` is this incremental guard. Exact hashes
are in `source-sha256.txt`.

## Results

| Execution | Checks | Failures | Exit |
| --- | ---: | ---: | ---: |
| Guarded focused fixtures | 168 | 0 | 0 |
| Identical fixtures with exact pre-guard tier1_cfg.c | 168 | 15 | 1 |
| Existing CFG suite, seed140/count32 | 6,184 | 0 | 0 |

The 168 focused checks include the previous 134 checks unchanged. Those retain
bound definitions (including a merged definition range crossing calls), cold
siblings, pressure fallback, recipes, loop phis, strict clobber boundaries,
partial SIMD tails, one/two-call ordering parity, and both wrapper rollbacks.
Thirteen new frozen lanes and one overlay check cover strict internal joins,
join boundaries exactly at the interval start/end, ordinary single-predecessor
boundaries, multiple crossed joins, and clobber endpoint exclusion.

The new CFG fixture is a diamond. The entry defines a parameter in r0 and
branches to a call-free arm or a final handler. A value used only by the
handler prevents its interval from merging with the bound entry range. The
handler and common return do share a single interval. The handler later needs
the only callee-saved register, creating pressure after unguarded promotion.
The common return reads the parameter. The test is run with one and two calls.

Guarded, both runs have five intervals, zero spills, zero edge moves, and r0
at every block entry. With the exact pre-guard helper, both have one spill and
two edge moves: promotion into the handler and a store from the call-free arm
into the common return's new spill convention. Five boundary checks and five
checks per CFG fixture fail, while the independent verifier still accepts the
semantically valid allocation. This distinguishes the code-quality regression
from correctness. The guard does not widen any incoming-register bound.

The existing CFG suite also passes its certificates and mutation oracles;
291 one/two-allocation cases agree (260 preferences taken,31 refused,8 freed
of definition registers). Full workload measurement remains necessary: the
guard blocks direct promotion over a merged internal join, but does not prove
that hints inherited from earlier promoted ranges cannot affect other joins.

## Build and mutation

`generate.c` preserves the production backend unity include list and bodies,
selects their normal local table ownership, and replaces only the unrelated
command dispatcher with `runner.c`. `focused.c` includes the actual guarded
file from `buster-policy`; `guarded_cfg.c` is an exact snapshot of that file.
`unguarded-focused.c` changes just that include to the exact `unguarded_cfg.c`
snapshot. The same tests and all other production bodies are used for both.
No behavior stubs, production test edits, benchmark-machine resources, or
full local compiler builds were involved.

The compiler was `/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang`.
Flags (from this directory) were:

```sh
-O0 -g0 -march=native
-I../buster-policy/src -I../buster-policy/src/buster/compiler
-fwrapv -funsigned-char -fno-strict-aliasing -Wall -Werror
-Wno-unused-function -fno-stack-protector
-DBUSTER_HOST_SSP_DEFAULT=BUSTER_PREDEFINES_SSP_OFF
'-DBUSTER_CLANG_DEFAULT_TARGET="x86_64-unknown-linux-gnu"'
-DBUSTER_EXECUTABLE_UNIT -DBUSTER_HOST_STATIC=1
-ffunction-sections -fdata-sections -Wl,--gc-sections
focused.c -pthread -ldl -o policy
```

The mutation build substitutes `unguarded-focused.c` and `unguarded-policy`.
Commands were `timeout 60 ./policy`, `timeout 60 ./unguarded-policy`, and
`timeout 60 ./policy existing-cfg`; the three run logs are included. Empty
build logs mean no compiler warnings or errors; both builds exited zero.
`-Wno-unused-function` covers private entry points whose dispatcher was removed.

The evidence archive deliberately omits reproducible executables and full
compiler trees. Source snapshots and all focused test logs are included.
