# Issue 2610: focused native frame-recipe regression

This harness executes the repository's actual `tier1_frame_recipe_tests`, with
the actual selector, allocator, frame builder, emitted-code certificate, encoder,
target eligibility checks, and hostile native call helper. It contains no
behavior stubs or replacement implementation of a production algorithm.

## Result

| Production source | Checks | Failures | Native skips | Exit |
| --- | ---: | ---: | ---: | ---: |
| Base `8e4d32879e17b7d9548cad54257a2f8461328366` | 153 | 12 | 0 | 1 |
| Recipe change plus the corrected fixture | 153 | 0 | 0 | 0 |

The base failures are nine recipe-discovery expectations and the three
rematerialization-enabled frame modes. Native result, hostile-call count, and
call-alignment assertions pass on both versions. The head additionally verifies
that pressure causes rematerialization in each of the three frame modes.

The native fixture covers stable RSP, dynamic RBP, and realigned dynamic R15
frame bases, each with rematerialization disabled and enabled. Each generated
function is called on eight inputs, for 48 native executions. The helper clobbers
caller-saved state and its own red zone. Every emitted allocation is independently
verified, and emission requests the emitted-code certificate.

The 36 shape checks cover folded frame addresses, copies and constant offsets,
folded RIP symbols, rejection of allocated base/index operands, mask values,
covered roots/consumers, incoming overflow and aggregate argument areas,
displacement overflow in both directions, and existing raw stack-address rules.

These are correctness and regression results. Build durations in the logs are
not compiler performance measurements. No 9700X or benchpress resource was used.

## Exact inputs

The head was commit `96fd0284f8f8173fd191b21c5365ad46ae4b917d` plus this
one-line fixture correction:

```diff
-        if (mode == 2)
+        if (mode != 0)
```

`KEEP_POINTER` alone retains a frame pointer but leaves the frame object's
base at RSP. Creating a dynamic allocation in mode 1 is necessary to exercise
the intended RBP base. The original fixture expectation produced two failures;
`head-initial-run.log` records that result. No production logic changed when
correcting the fixture.

`production.patch` contains the complete head change relative to the base,
including the fixture correction. `fixture.c` is the exact test included by
the baseline harness. Relevant SHA-256 values:

```text
0742c5a8a2269b35a2fb9906a31c8451fbe4829ffbce3e82226d420563643715  tier1_emit_cfg.c
7e263f31f154bdd6bfd6eadf2d19f00cd51b7f5454640df782af581e6520572b  tier1_frame_recipe_test.c
```

The baseline source was exported from Git, independently of the other worktree's
measurement instrumentation:

```sh
mkdir -p baseline-src
git -C ../buster archive 8e4d32879e17b7d9548cad54257a2f8461328366 src |
    tar -x -C baseline-src
```

## Harness construction

`generate.c` copies the backend's production `main.c` include prefix up to the
command dispatcher. It substitutes the small `runner.c` entry point for the
unrelated commands. Unreachable static functions are therefore not emitted.
The generator selects the production modules' ordinary standalone storage
paths for encoder, BURS, and arena state, and makes the immutable target tables
local. It does not edit the bodies of the production routines or test helpers.

`runner.c` initializes production tables, reserves the same arena sizes used by
`run_tier1_emit_tests`, sets baseline output target forms and the current host's
native eligibility table, then calls the real fixture. Native skips fail this
focused harness; neither run skipped any execution.

The generator refuses to succeed unless it finds the exact expected include
boundaries and storage declarations. `focused.c` and `baseline-focused.c` are
the actual generated translation units. The baseline includes the new fixture
at the end because the old `tier1_emit_test.c` predates that private include.

```sh
cc -Wall -Wextra -Werror generate.c -o generate
./generate ../buster/src/buster/compiler/main.c focused.c
./generate baseline-src/src/buster/compiler/main.c baseline-focused.c
```

The following is the exact head compiler command, without the surrounding
shell `time` and log redirection. `compiler-version.log` records the toolchain;
`host.log` records the native CPU properties. `-Wno-unused-function` is necessary
because the harness omits unrelated command callers, while retaining their
production include declarations. All other warnings remain errors.

```sh
/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang \
    -O0 -g0 -march=native -I../buster/src -I../buster/src/buster/compiler \
    -fwrapv -funsigned-char -fno-strict-aliasing -Wall -Werror \
    -Wno-unused-function -fno-stack-protector \
    -DBUSTER_HOST_SSP_DEFAULT=BUSTER_PREDEFINES_SSP_OFF \
    '-DBUSTER_CLANG_DEFAULT_TARGET="x86_64-unknown-linux-gnu"' \
    -DBUSTER_EXECUTABLE_UNIT -DBUSTER_HOST_STATIC=1 \
    -ffunction-sections -fdata-sections -Wl,--gc-sections \
    focused.c -pthread -ldl -o head
timeout 60 ./head >head-run.log 2>&1
```

The baseline uses the same command with these substitutions:

```text
-I../buster/src                          -> -Ibaseline-src/src
-I../buster/src/buster/compiler          -> -Ibaseline-src/src/buster/compiler
focused.c                               -> baseline-focused.c
-o head                                 -> -o baseline
```

It adds the exact fixture include used during the recorded run:

```sh
'-DBUSTER_FRAME_RECIPE_TEST_INCLUDE="../buster/src/buster/compiler/tier1_frame_recipe_test.c"'
```

For a replay from this artifact, the equivalent include is
`'-DBUSTER_FRAME_RECIPE_TEST_INCLUDE="fixture.c"'`; the archived file is byte
identical to the recorded run's fixture. The baseline invocation was:

```sh
timeout 60 ./baseline >baseline-run.log 2>&1
```

## Review notes

The stricter folded-symbol eligibility is consistent with the selector's
contract: assigning a frame object or RIP symbol removes the allocated base,
and RIP symbols also exclude an index. Constant-offset walks stop at these
roots and add the terminal displacement once. Eight signed 32-bit walk offsets
plus one terminal offset fit within the 64-bit accumulator, and the final
signed 32-bit bounds reject overflowing recipes. Integer recipes still require
zero accumulated displacement; GOT and TLS restrictions are preserved. The
existing incoming-object exclusion handles overflow areas and aggregates.

The fixture correction is the only tracked edit made while running this
focused native validation. The production recipe change remains unchanged.
