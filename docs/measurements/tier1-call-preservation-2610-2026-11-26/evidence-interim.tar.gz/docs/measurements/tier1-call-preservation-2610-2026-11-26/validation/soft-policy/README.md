# Issue 2610: focused experimental soft-clobber policy validation

This scratch-only harness compiles the actual production backend bodies from
`buster-policy`, with a small entry point replacing the unrelated command
dispatcher. The experiment is based on commit
`96fd0284f8f8173fd191b21c5365ad46ae4b917d` and the archived `experiment.patch`.
The patch SHA-256 is:

```text
666868bff3f6040314550958bdaeb40222e42246eea1b09ce3eb31f9691a775c
```

No production file was edited by this validation. `production-source-sha256.log`
records the exact source hashes. The patch includes rollback in both assignment
wrappers when allocation fails after the avoidance overlay has been allocated.

## Results

| Check | Result |
| --- | --- |
| Focused policy fixtures | 134 checks, zero failures |
| Existing interval allocator suite, seed 140, generated count 32 | 77,257 checks, zero failures |
| Existing certificate suite | 2,147 checks, zero failures |
| Existing interval certificate suite | 17 checks, zero failures |
| Allocation certificates | 52,227 successful allocations checked, zero failures |
| Existing CFG suite, seed 140, generated count 32 | 6,184 checks, zero failures |
| Existing CFG one/two allocation order comparison | 291 cases; 260 preferences taken, 31 refused, 8 definitions freed |

All commands exited zero. The existing allocation suite includes native tests
and existing rematerialization, clobber, fixed-register, and avoided-register
cases. CFG checks include independent allocation verification, certificates,
the independent certificate oracle, and deliberately broken allocations.

The focused tests cover:

- Nineteen frozen eligibility lanes, including a partial SIMD tail, strict
  clobber boundaries, one or multiple interior clobbers, recipe exclusion,
  singleton/caller-only/preserved-only choices, and all three register classes.
- Preservation of existing avoidance and its shared source column; no allocation
  when nothing changes; absent optional recipe and avoidance columns.
- Incoming bound definitions, later non-definition intervals, cold sibling
  blocks, pressure fallback, recipes, and a loop phi.
- One and two call sites; the same allocation through two independent calls,
  a shared preparation without the fast verdict, and a shared preparation with
  the verdict. The preferred problem alone has clobbers.
- Both assignment wrappers' capacity failures after room for the overlay but
  insufficient room for allocation, checking arena rollback and unchanged result.

The tests exposed and now explicitly preserve an intended boundary: CFG
preparation can merge a bound definition with the next laid-out block. That
whole interval remains restricted to its incoming register even if it crosses
a call. Soft avoidance does not widen that restriction. A later separate
interval with both choices takes the preserved register when available and
keeps the caller register under pressure. The cold sibling retains its incoming
hint. The original scratch expectation incorrectly demanded promotion of the
merged bound interval; correcting that expectation changed no production code.

## Construction and reproduction

`generate.c` is the same low-memory native harness generator used for the folded
frame-recipe validation. It preserves `main.c`'s backend include list and all
production bodies, selecting normal standalone storage ownership for encoder,
BURS, arenas, and target tables. It removes only the unrelated command dispatcher.
`runner.c` calls the actual test entry points, or `tests.c` for the scratch-only
targeted cases. No behavior stubs are used.

```sh
cc -Wall -Wextra -Werror generate.c -o generate
./generate ../buster-policy/src/buster/compiler/main.c focused.c
/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang \
    -O0 -g0 -march=native \
    -I../buster-policy/src -I../buster-policy/src/buster/compiler \
    -fwrapv -funsigned-char -fno-strict-aliasing -Wall -Werror \
    -Wno-unused-function -fno-stack-protector \
    -DBUSTER_HOST_SSP_DEFAULT=BUSTER_PREDEFINES_SSP_OFF \
    '-DBUSTER_CLANG_DEFAULT_TARGET="x86_64-unknown-linux-gnu"' \
    -DBUSTER_EXECUTABLE_UNIT -DBUSTER_HOST_STATIC=1 \
    -ffunction-sections -fdata-sections -Wl,--gc-sections \
    focused.c -pthread -ldl -o policy
timeout 60 ./policy >focused-run.log 2>&1
timeout 60 ./policy existing-allocation >existing-allocation-run.log 2>&1
timeout 60 ./policy existing-cfg >existing-cfg-run.log 2>&1
```

The existing suites ran before the scratch fixture's final expectation
correction; the production source and compiler flags were identical throughout.
`-Wno-unused-function` accounts for the unused private command entry points left
by dispatcher removal. All other warnings remain errors. `build.log` records
the final focused executable build. Build durations are not performance results.

The host and exact Clang version are recorded in the companion folded-recipe
native evidence archive. No benchmark host or benchpress resource was used.
