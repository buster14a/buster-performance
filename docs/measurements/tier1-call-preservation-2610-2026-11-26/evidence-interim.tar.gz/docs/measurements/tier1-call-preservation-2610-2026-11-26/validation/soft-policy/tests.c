// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Included after the actual production backend and existing CFG test helpers.

static void policy_shapes(Tier1CfgTestTally* tally, Arena* output)
{
    const uint64_t mark = output->length;
    // Frozen cases: strict interior clobbers, boundaries, recipes, one-sided
    // choices, three classes, and a 19-lane input exercising a partial SIMD tail.
    const uint32_t starts[19] = { 0, 4, 4, 10, 20, 0, 0, 0, 0, 0, 0, 0, 0, 4, 9, 9, 9, 9, 19 };
    const uint32_t ends[19] = { 4, 10, 11, 20, 25, 5, 21, 21, 21, 21, 21, 21, 21, 5, 10, 11, 11, 11, 21 };
    const uint32_t allowed[19] = { 7, 7, 7, 7, 7, 7, 7, 7, 1, 4, 0, 0x13, 0xfe, 7, 7, 7, 7, 0x10, 7 };
    const uint8_t classes[19] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 0, 1, 0 };
    uint8_t recipes[19] = { [7] = 1, [16] = 1 };
    const uint32_t expected[19] = { 0x80, 0x80, 0x83, 0x80, 0x80, 0x83, 0x83, 0x80, 0x80, 0x80, 0x80, 0x8f, 0x80, 0x80, 0x80, 0x83, 0x80, 0x80, 0x83 };
    uint32_t original[19];
    for (uint32_t i = 0; i < 19; i += 1)
    {
        original[i] = 0x80;
    }
    const uint32_t clobbers[] = { 4, 10, 20 };
    Tier1CfgInput input = {
        .clobbers = clobbers,
        .clobber_count = 3,
        .clobber_registers = { 3, 15, 0xfe },
    };
    Tier1AllocationInput intervals = {
        .starts = starts,
        .ends = ends,
        .allowed_registers = allowed,
        .avoided_registers = original,
        .classes = classes,
        .rematerializable = recipes,
        .count = 19,
    };
    const bool ready = tier1_cfg_clobber_avoidance(&input, output, &intervals);
    tier1_cfg_test_expect(tally, ready && intervals.avoided_registers != original, "soft shapes: allocate an independent avoidance overlay");
    for (uint32_t i = 0; ready && i < 19; i += 1)
    {
        const bool correct = intervals.avoided_registers[i] == expected[i] && original[i] == 0x80;
        if (!correct)
        {
            printf("soft shapes: lane=%u expected=%x actual=%x original=%x\n", i, expected[i], intervals.avoided_registers[i], original[i]);
        }
        tier1_cfg_test_expect(tally, correct, "soft shapes: frozen eligibility and existing avoidance are preserved");
    }
    arena_pop_to(output, mark);
    intervals.avoided_registers = original;
    input.clobber_count = 0;
    tier1_cfg_test_expect(tally, tier1_cfg_clobber_avoidance(&input, output, &intervals) && output->length == mark && intervals.avoided_registers == original,
                         "soft shapes: no clobbers means no allocation or mutation");
    input.clobber_count = 3;
    memset(recipes, 1, sizeof(recipes));
    tier1_cfg_test_expect(tally, tier1_cfg_clobber_avoidance(&input, output, &intervals) && output->length == mark && intervals.avoided_registers == original,
                         "soft shapes: recipes retain their existing policy without an overlay");
    memset(recipes, 0, sizeof(recipes));
    intervals.rematerializable = 0;
    intervals.avoided_registers = 0;
    tier1_cfg_test_expect(tally, tier1_cfg_clobber_avoidance(&input, output, &intervals) && intervals.avoided_registers != 0 && intervals.avoided_registers[2] == 3 &&
                         intervals.avoided_registers[0] == 0 && intervals.avoided_registers[7] == 3 && intervals.avoided_registers[16] == 3,
                         "soft shapes: absent optional columns behave as no recipes and no prior avoidance");
    arena_pop_to(output, mark);
}

static bool policy_fixture(Arena* output, uint32_t variant, Tier1CfgInput* input, uint32_t* defined, uint32_t* chosen, uint32_t* parameter)
{
    Tier1CfgTestBuilder builder = {
        .block_count = 3,
        .instructions = { 3, 4, 4 },
        .registers = { variant == 1 ? 7 : 3, 15, 0xfe },
        .scratch = { 11, 15, 0 },
    };
    tier1_cfg_test_edge(&builder, 0, 1);
    if (variant == 3)
    {
        tier1_cfg_test_edge(&builder, 1, 1);
        tier1_cfg_test_edge(&builder, 1, 2);
    }
    else
    {
        tier1_cfg_test_edge(&builder, 0, 2);
    }
    if (variant == 1)
    {
        const uint32_t held = tier1_cfg_test_value(&builder, 0, 0, BUSTER_TIER1_ALLOCATE_GPR, 4);
        defined[held] = 4;
        chosen[held] = 4;
        tier1_cfg_test_definition_use(&builder, held);
        tier1_cfg_test_use(&builder, held, 1, 3, true);
        tier1_cfg_test_use(&builder, held, 2, 3, true);
    }
    const uint32_t p = tier1_cfg_test_value(&builder, 0, 1, BUSTER_TIER1_ALLOCATE_GPR, 3);
    defined[p] = 1;
    chosen[p] = 4;
    builder.remat[p] = variant == 2;
    tier1_cfg_test_definition_use(&builder, p);
    tier1_cfg_test_use(&builder, p, 1, 3, true);
    tier1_cfg_test_use(&builder, p, 2, 3, true);
    if (variant == 3)
    {
        const uint32_t phi = builder.value_count;
        const uint32_t operands[2] = { p, phi };
        const uint32_t w = tier1_cfg_test_phi(&builder, 1, BUSTER_TIER1_ALLOCATE_GPR, operands);
        chosen[w] = 7;
        tier1_cfg_test_use(&builder, w, 1, 3, true);
        tier1_cfg_test_use(&builder, w, 2, 3, true);
    }
    const bool built = tier1_cfg_test_build(&builder, output, input);
    input->definition_registers = defined;
    *parameter = p;
    return built;
}

static void policy_orders(Tier1CfgTestTally* tally, Arena* output, Arena* scratch, uint32_t variant, uint32_t calls)
{
    const uint64_t mark = output->length;
    uint32_t defined[BUSTER_TIER1_CFG_TEST_VALUES] = { 0 };
    uint32_t chosen[BUSTER_TIER1_CFG_TEST_VALUES] = { 0 };
    uint32_t parameter = 0;
    Tier1CfgInput plain = { 0 };
    const bool built = policy_fixture(output, variant, &plain, defined, chosen, &parameter);
    tier1_cfg_test_expect(tally, built, "soft orders: construct CFG");
    if (built)
    {
        const uint32_t call_block = variant >= 3 ? 1 : 2;
        const uint32_t cold_block = 3 - call_block;
        const uint32_t clobbers[2] = { plain.block_starts[call_block] + 3, plain.block_starts[call_block] + 5 };
        Tier1CfgPreference preference = {
            .sets = chosen,
            .registers = { 7, 15, 0xfe },
            .clobbers = clobbers,
            .clobber_count = calls,
            .clobber_registers = { 3, 0, 0 },
        };
        Tier1CfgInput two = plain;
        Tier1CfgAllocation first = { 0 };
        Tier1CfgError first_error = tier1_cfg_allocate(&two, output, scratch, &first);
        if (first_error == TIER1_CFG_CONSTRAINT)
        {
            two.definition_registers = 0;
            first_error = tier1_cfg_allocate(&two, output, scratch, &first);
        }
        Tier1CfgInput preferred_two;
        const bool preferred = tier1_cfg_preferred(&two, &preference, output, &preferred_two);
        Tier1CfgAllocation second = { 0 };
        const Tier1CfgError second_error = first_error == TIER1_CFG_OK && preferred ? tier1_cfg_allocate(&preferred_two, output, scratch, &second) : TIER1_CFG_INVALID;
        const bool taken_two = first_error == TIER1_CFG_OK && tier1_cfg_taken(second_error, &second);
        tier1_cfg_test_expect(tally, first_error == TIER1_CFG_OK && second_error == TIER1_CFG_OK, "soft orders: independent plain and preferred problems allocate");
        Tier1CfgCheck check = { 0 };
        tier1_cfg_test_expect(tally, second_error == TIER1_CFG_OK && tier1_cfg_verify(&preferred_two, &second, scratch, &check), "soft orders: preferred allocation verifies");
        if (second_error == TIER1_CFG_OK)
        {
            uint32_t location = 0;
            uint8_t kind = 0;
            const bool bound = tier1_cfg_location(&second, parameter, plain.definitions[parameter], &location, &kind);
            tier1_cfg_test_expect(tally, bound && kind == BUSTER_TIER1_ALLOCATE_REGISTER && location == 0, "soft orders: parameter definition keeps its incoming register");
            const bool body = tier1_cfg_location(&second, parameter, plain.block_starts[call_block] + 6, &location, &kind);
            if (variant < 2 || variant == 4)
            {
                const uint32_t expected = variant == 0 ? 2 : 0;
                if (!body || kind != BUSTER_TIER1_ALLOCATE_REGISTER || location != expected)
                {
                    printf("soft location: variant=%u calls=%u found=%u kind=%u location=%u\n", variant, calls, body, kind, location);
                    for (uint32_t i = 0; i < second.intervals.count; i += 1)
                    {
                        if (second.intervals.values[i] == parameter)
                        {
                            printf("  interval=%u range=%u:%u allowed=%x avoided=%x\n", i, second.intervals.starts[i], second.intervals.ends[i], second.intervals.allowed_registers[i],
                                   second.intervals.avoided_registers != 0 ? second.intervals.avoided_registers[i] : 0);
                        }
                    }
                }
                tier1_cfg_test_expect(tally, body && kind == BUSTER_TIER1_ALLOCATE_REGISTER && location == expected,
                                     "soft orders: crossing range prefers a free preserved register and falls back under pressure");
                const bool cold = tier1_cfg_location(&second, parameter, plain.block_starts[cold_block] + 6, &location, &kind);
                tier1_cfg_test_expect(tally, cold && kind == BUSTER_TIER1_ALLOCATE_REGISTER && location == 0, "soft orders: cold sibling retains its incoming hint");
                tier1_cfg_test_expect(tally, second.allocation.spill_count == first.allocation.spill_count, "soft orders: soft preference creates no spill in the pressure fixture");
            }
            for (uint32_t i = 0; i < second.intervals.count; i += 1)
            {
                if (second.intervals.values[i] == parameter && second.intervals.starts[i] == plain.block_starts[call_block])
                {
                    const uint32_t avoided = second.intervals.avoided_registers != 0 ? second.intervals.avoided_registers[i] : 0;
                    tier1_cfg_test_expect(tally, (avoided & 3) == (variant == 2 ? 0u : 3u), "soft orders: call-crossing nonrecipe alone adds caller avoidance");
                }
                if (variant == 4 && second.intervals.values[i] == parameter && second.intervals.starts[i] <= clobbers[0] && clobbers[0] < second.intervals.ends[i])
                {
                    const uint32_t avoided = second.intervals.avoided_registers != 0 ? second.intervals.avoided_registers[i] : 0;
                    tier1_cfg_test_expect(tally, second.intervals.allowed_registers[i] == 1 && avoided == 0,
                                         "soft orders: a merged definition interval remains bound across its calls");
                }
            }
        }
        for (uint32_t verdict = 0; verdict < 2; verdict += 1)
        {
            const uint64_t order_mark = output->length;
            Tier1CfgInput one = plain;
            preference.verdict = verdict != 0;
            Tier1CfgOrder order;
            Tier1CfgAllocation result = { 0 };
            const uint32_t* allowed = 0;
            Tier1CfgError preferred_error = TIER1_CFG_OK;
            bool taken = false;
            Tier1CfgError error = tier1_cfg_order_prepare(&one, output, scratch, &order);
            error = error == TIER1_CFG_OK ? tier1_cfg_order_run(&one, &preference, output, scratch, &order, &result, &allowed, &preferred_error, &taken) : error;
            const uint32_t differs = error == TIER1_CFG_OK ? tier1_cfg_differs(&plain, &result, taken_two ? &second : &first) : UINT32_MAX;
            const bool same = error == first_error && taken == taken_two && preferred_error == second_error && differs == 0 &&
                              (one.definition_registers == 0) == (two.definition_registers == 0);
            if (!same)
            {
                printf("soft orders: variant=%u calls=%u verdict=%u first=%u second=%u one=%u preferred=%u taken=%u/%u differs=%u\n",
                       variant, calls, verdict, first_error, second_error, error, preferred_error, taken, taken_two, differs);
            }
            tier1_cfg_test_expect(tally, same, "soft orders: single preparation and verdict agree with two independent allocations");
            const Tier1CfgInput* standing = taken ? &preferred_two : &one;
            tier1_cfg_test_expect(tally, error == TIER1_CFG_OK && tier1_cfg_verify(standing, &result, scratch, &check), "soft orders: the allocation selected by either order verifies");
            arena_pop_to(output, order_mark);
        }
    }
    arena_pop_to(output, mark);
}

static void policy_capacity(Tier1CfgTestTally* tally, Arena* output, Arena* scratch)
{
    const uint64_t mark = output->length;
    uint32_t defined[BUSTER_TIER1_CFG_TEST_VALUES] = { 0 };
    uint32_t chosen[BUSTER_TIER1_CFG_TEST_VALUES] = { 0 };
    uint32_t parameter = 0;
    Tier1CfgInput input = { 0 };
    const bool built = policy_fixture(output, 0, &input, defined, chosen, &parameter);
    input.definition_registers = 0;
    const uint32_t clobber = built ? input.block_starts[1] + 3 : 0;
    input.clobbers = &clobber;
    input.clobber_count = 1;
    input.clobber_registers[0] = 1;
    Tier1CfgPrepared prepared;
    const Tier1CfgError error = built ? tier1_cfg_prepare(&input, output, scratch, &prepared) : TIER1_CFG_INVALID;
    tier1_cfg_test_expect(tally, error == TIER1_CFG_OK, "soft capacity: prepare a crossing range with two choices");
    if (error == TIER1_CFG_OK)
    {
        const uint64_t saved = output->length;
        for (uint32_t verdict = 0; verdict < 2; verdict += 1)
        {
            Arena bounded = *output;
            bounded.capacity = saved + 4 * (prepared.candidate.intervals.count + 1) + 16;
            Tier1CfgAllocation result;
            memset(&result, 0x5a, sizeof(result));
            const Tier1CfgAllocation unchanged = result;
            bool taken = false;
            bool constraint = false;
            const Tier1CfgError failed = verdict != 0 ? tier1_cfg_assign_verdict(&input, &prepared, 0, &input, 0, &bounded, &result, &taken, &constraint) :
                                                       tier1_cfg_assign(&input, &prepared, 0, &bounded, &result);
            if (failed != TIER1_CFG_CAPACITY || bounded.length != saved)
            {
                printf("soft capacity: verdict=%u error=%u before=%" PRIu64 " after=%" PRIu64 "\n", verdict, failed, saved, bounded.length);
            }
            tier1_cfg_test_expect(tally, failed == TIER1_CFG_CAPACITY && bounded.length == saved && memcmp(&result, &unchanged, sizeof(result)) == 0,
                                 "soft capacity: failed assignment restores avoidance overlay and leaves result unchanged");
        }
        tier1_cfg_release(&prepared, scratch);
    }
    arena_pop_to(output, mark);
}
