// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Copy the production include chain locally and change only the ABI binding clear.
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

static bool copy_replace(const char* source, const char* destination, const char* before, const char* after)
{
    FILE* input = fopen(source, "r");
    FILE* output = input != 0 ? fopen(destination, "w") : 0;
    bool ok = input != 0 && output != 0;
    unsigned replaced = 0;
    char line[16384];
    while (ok && fgets(line, sizeof(line), input) != 0)
    {
        const char* at = strstr(line, before);
        if (at != 0)
        {
            ok = fwrite(line, 1, (size_t)(at - line), output) == (size_t)(at - line) && fputs(after, output) >= 0 && fputs(at + strlen(before), output) >= 0;
            replaced += 1;
        }
        else
        {
            ok = fputs(line, output) >= 0;
        }
    }
    ok = ok && replaced == 1 && !ferror(input) && !ferror(output);
    if (input != 0)
    {
        ok &= fclose(input) == 0;
    }
    if (output != 0)
    {
        ok &= fclose(output) == 0;
    }
    return ok;
}

int main(int argc, char** argv)
{
    char source[1024];
    bool ok = argc == 2;
    if (ok)
    {
        snprintf(source, sizeof(source), "%s/tier1_emit.c", argv[1]);
        ok = copy_replace(source, "mutant-emit.c", "#include \"tier1_emit_cfg.c\"", "#include \"mutant-cfg.c\"");
        snprintf(source, sizeof(source), "%s/tier1_emit_cfg.c", argv[1]);
        ok = ok && copy_replace(source, "mutant-cfg.c", "#include \"tier1_emit_exchange.c\"", "#include \"mutant-map.c\"");
        snprintf(source, sizeof(source), "%s/tier1_emit_exchange.c", argv[1]);
        ok = ok && copy_replace(source, "mutant-map.c", "_mm512_mask_mov_epi32(original, renamed, _mm512_setzero_si512())", "_mm512_mask_mov_epi32(original, renamed, original)");
        ok = ok && copy_replace("focused.c", "mutant-focused.c", "#include \"buster/compiler/tier1_emit.c\"", "#include \"mutant-emit.c\"");
    }
    return !ok;
}
