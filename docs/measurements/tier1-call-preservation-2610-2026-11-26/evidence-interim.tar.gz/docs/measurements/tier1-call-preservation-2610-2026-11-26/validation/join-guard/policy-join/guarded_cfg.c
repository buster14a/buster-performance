// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
//
// Tier 1's register allocation over a CFG (#140). Include after lane.c, dataflow.c, dominators.c and tier1_allocate.c.
//
// tier1_cfg_allocate takes a machine CFG in layout order. Block b occupies positions [block_starts[b],
// block_starts[b + 1]); block 0 is the entry, without predecessors or phis. Every value is defined once: a phi at its
// block's start, by the moves on the block's incoming edges, any other value at its definition position, before its
// uses in that block (SSA). A phi has one operand per predecessor, in the predecessor CSR's order. A use of a value
// other than a phi at its own definition position is the definition's requirement: a required one asks that the
// definition write a register, as an instruction's destination does (tier1_emit_cfg.c's).
//
// 1. Liveness is dataflow.c's, on values used in another block or passed by a phi edge from another block. A phi
//    operand passed only from its home needs its home interval's tail, not a dense bit (#1384). For global values,
//    each phi operand is a use on its edge: USE[b] = U[b] | (P[b] & ~D[b]), then OUT[b] |= P[b] after the solve.
//    Each value's phi occurrences supply P directly, without another blocks-by-values matrix. The global values are
//    solved 512 at a time, one vector row per block, and each block's live-in and live-out values kept as ascending
//    lists (tier1_cfg_live_sets), so that the rows take blocks * 256 bytes however many values are global (#1384).
//    Where the groups' dense solves would sweep more than BUSTER_TIER1_CFG_SPARSE_ROWS block rows, each group is solved
//    instead by a worklist over the blocks its values touch alone (tier1_cfg_live_group_sparse), into the same lists.
// 2. A value gets an interval per block it is defined in or live into, from its definition or the block's start to its
//    last use or the block's end, and an unused definition one position. A block continues its layout predecessor's
//    ranges when it has no phis and every value live into it leaves that predecessor live: then every value of its
//    entry state continues, so that a fragment transition at its start, which runs inside the block, never meets a
//    value an edge brought there. A range is cut around each fixed range of its class that blocks every register the
//    value may take (a call's clobbers for a double): the allocator takes a fixed range's registers from every
//    interval it overlaps, so the piece over it goes to memory and the pieces around it keep their registers, where
//    the whole range couldn't have one for a use that needs it. Intervals are numbered by value, then position, so
//    that each one's uses are a slice of the value's: the allocator borrows the input's use columns. Each value's
//    blocks come from the live-in lists block by block, counted and then filled, so the cost is the live pairs', not
//    values times blocks. Each range a value enters a block with is hinted to the register the value has at the exit of
//    the block's anchor (#2553, tier1_cfg_anchors): its immediate dominator, or a latch laid out before it, of which
//    every such value is live out at once; each phi to its operand's at the exit of a chosen predecessor; and a value
//    that a phi takes, to the first register of the phi, or of the next phi along, that has one before it. A range of a
//    loop's body laid out before its header, with no anchor, takes the hint of its phi's at the header, back to the first
//    range of another value before it (tier1_cfg_body_hints, #2784), and a phi's first range there that the chain leaves
//    unhinted takes an operand's register at the loop's entry (#2834). Each value then stays where control from its
//    definition brings it, and an edge moves what its own source block changed. A range live out of its block names the
//    range whose opening is the value's place at its first successor's entry, where that one comes first (#2774): a
//    value whose place there is its slot is the first the allocator evicts.
//    A general range live across a fixed register's sequence (sequences, #2767: a division's rax and rdx, a shift's rcx)
//    avoids the registers it writes (tier1_cfg_crossed): it takes one only where no other register is free, so that the
//    sequence's consumer saves no value around it.
// 3. tier1_allocate assigns the intervals.
// 4. Each edge moves its successor's live-in values and phis from their locations at the predecessor's last position
//    to their entry locations (tier1_cfg_entry_location). A store of a value to its own slot is omitted where the slot
//    already holds it at the predecessor's exit: the predecessor block establishes it (tier1_cfg_slot_current, #1216),
//    or every path to the block's start stored it and the block keeps it (tier1_cfg_current_slots, #2553, a forward
//    must-analysis that the allocation publishes per block as assertions, for its checkers and the emitter). An operand
//    of a phi whose slot it shares counts as the value: the slot is its own. A changed phi operand still writes it.
//    Those boundary locations are one forward sweep of each value's intervals (#1399), not a binary search per live
//    value per edge. Emission resolves a position from the first interval that overlaps its block, when that
//    column fits. tier1_resolve_moves orders each class's moves, breaking a
//    cycle with the class's scratch register or, where one of the class's moves goes slot to slot, with the class's
//    temporary slot; a slot-to-slot move then goes through the scratch register, which holds nothing from one move to
//    the next. Recomputing a rematerializable value comes last. The moves go at the predecessor's end when it has one
//    successor (after its last instruction: a jump there must read no allocated value), at the successor's start when
//    it has one predecessor, and otherwise on the split edge.
// 5. Each split, a position inside a block where pieces of values' ranges meet, moves each of those values from its
//    location just before the position to its new piece's, resolved as an edge's moves are (a value keeps one slot,
//    so none goes slot to slot). They run at the position after its stores and before its reloads.
//
// With slot_widths, a phi web's spilled values share a slot where no two of them are live at once
// (tier1_cfg_share_slots, #1216), after the allocation and before the moves: an edge then moves nothing for an
// operand already in its phi's slot.
//
// Location ids: class * 32 + register for registers, BUSTER_TIER1_CFG_SPILL + the value's spill id for its slot, and
// BUSTER_TIER1_CFG_SPILL + spill_count + class for the class's temporary slot, which temp_slots marks where a move
// uses it. A move whose source is BUSTER_TIER1_CFG_REMATERIALIZE recomputes move_values[m] into its destination.
//
// The classes are tier1_allocate.c's: general, vector and opmask registers (#179). A mask value takes one of k1 to k7
// (BUSTER_TIER1_ALLOCATE_MASK_REGISTERS: k0 can't be a write mask, and validation refuses a class or a value that
// allows it), and the class's scratch register is a k register outside its `registers`: k0 for the producers here,
// which leaves the seven others to the values. A consumer moves, spills and reloads a mask at its width; calls clobber
// every opmask register (the System V convention passes none and preserves none), which the producer's fixed ranges say.
//
// tier1_cfg_verify is an independent oracle for tests and qualification, not the production path. It computes
// liveness its own way (each use walked back to its definition), simulates every block's locations as the emitter
// would run the fragments and splits (stores, then a split's moves, then loads and rematerializations, at each
// position; fixed ranges clobber their registers), checks that every use finds its value, that each piece of a range
// cut inside a block finds its value where the piece keeps it once the split's moves have run (whether or not a use
// reads it there), and that no write lands on another value the allocation still keeps there, and applies each edge's
// moves in order to the predecessor's final state, which must then hold every live-in value and each phi's operand
// where the successor expects them. The slots the allocation asserts current at a block's start (current_slots, #2553)
// it takes as more of the block's entry state, and checks each on every edge into the block, as it checks the places.
//
// Interval construction, move resolution and the verifier's search stay scalar, around the vector liveness solver and
// the vector allocator. The boundary sweep is scalar too: each value's intervals are a variable-length run, and one
// forward pass removes the dependent searches that were the measured cost. A vectorized search would still do every
// lookup. The position-to-block column is a sequential fill. Measure a vector path for these on the 9700X before adding one.
// Inputs are borrowed and immutable. Output and scratch are distinct arenas; failure restores both lengths and leaves
// the result unchanged.

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define BUSTER_TIER1_CFG_SPILL (32u * BUSTER_TIER1_ALLOCATE_CLASSES)
#define BUSTER_TIER1_CFG_REMATERIALIZE 0x80000000u
#define BUSTER_TIER1_CFG_NONE UINT32_MAX
// In a block's continuation word (#2774, tier1_cfg_prepare): the block named is its first successor's model, not that successor.
#define BUSTER_TIER1_CFG_LATER 0x80000000u
// Retained position-to-block column, four bytes each, at or below this many positions.
#define BUSTER_TIER1_CFG_POSITION_BLOCKS (1u << 20)
// First interval of a value overlapping each block (#1399). Sixteen mebibytes of entries at most.
#define BUSTER_TIER1_CFG_BLOCK_INTERVALS (1u << 22)
// Below this many intervals a binary search is at most three steps, so a partial column spends its budget on wider values.
#define BUSTER_TIER1_CFG_LOOKUP_WIDE 8u
// At most this many values share one slot (tier1_cfg_share_slots): each merge checks every pair of the two slots' values.
#define BUSTER_TIER1_CFG_SLOT_WEB 32u

typedef enum Tier1CfgPlacement
{
    TIER1_CFG_EDGE_EMPTY,
    TIER1_CFG_EDGE_PREDECESSOR,
    TIER1_CFG_EDGE_SUCCESSOR,
    TIER1_CFG_EDGE_SPLIT,
} Tier1CfgPlacement;

typedef struct Tier1CfgInput Tier1CfgInput;
struct Tier1CfgInput
{
    // block_count + 1 entries: block b is [block_starts[b], block_starts[b + 1]); the last entry is position_count.
    const uint32_t* block_starts;
    // Both CSR views of the edges, without duplicates. Phi operands follow the predecessor view's order.
    const uint32_t* successor_offsets;
    const uint32_t* successors;
    const uint32_t* predecessor_offsets;
    const uint32_t* predecessors;
    // Per value.
    const uint8_t* classes;
    const uint32_t* allowed_registers;
    const uint32_t* definitions;
    // Optional: the registers each value's definition must be in (a parameter's incoming one), a subset of its allowed
    // ones, on the interval that holds the definition alone; allowed_registers holds on the others, and on every interval
    // of a value whose entry is 0.
    const uint32_t* definition_registers;
    // Optional: a value that may be recomputed rather than spilled.
    const uint8_t* rematerializable;
    // Ordinary uses, sorted per value: not phi operands. use_required is optional, as tier1_allocate takes it.
    const uint32_t* use_offsets;
    const uint32_t* use_positions;
    const uint8_t* use_required;
    // Optional, per use (#2646): the register of its value's class that the use reads it in, or UINT8_MAX: a call's
    // register argument's. An interval whose last use names one takes it where no value hint names another and it is
    // free (Tier1AllocationInput.register_hints).
    const uint8_t* use_registers;
    // Block b's phis are phi_values[phi_offsets[b] .. phi_offsets[b + 1]); phi k's operand from its block's j-th
    // predecessor is phi_operands[phi_operand_offsets[k] + j], or BUSTER_TIER1_CFG_NONE for an undefined one (the IR's
    // undef): any value is the phi's along that edge, so the edge moves nothing for it and nothing is live for it there.
    const uint32_t* phi_offsets;
    const uint32_t* phi_values;
    const uint32_t* phi_operand_offsets;
    const uint32_t* phi_operands;
    // Optional, per edge: whether its consumer copies something along it that the allocation doesn't see (Tier 1's long
    // doubles' phis, #141): it is placed as an edge with moves, at its predecessor's end, its successor's start or a
    // split's, though it has none of the allocation's.
    const uint8_t* edge_copies;
    // Optional, per value: its slot's width. A phi and an operand of its class and width then share a slot where
    // neither is live at the other's definition (tier1_cfg_share_slots, #1216); without it each value has its own.
    const uint8_t* slot_widths;
    // Optional (#2574): the allocator's clobbers (Tier1AllocationInput.clobbers), nondecreasing positions where
    // clobber_registers lose their values, as at a call: a recomputable value there leaves its register, to be recomputed
    // where a required use next needs it. The consumer saves every other value around them.
    const uint32_t* clobbers;
    uint32_t clobber_count;
    uint32_t clobber_registers[BUSTER_TIER1_ALLOCATE_CLASSES];
    // Optional (#2685), two per value: the values whose registers its definition may take, in preference order, or
    // BUSTER_TIER1_CFG_NONE: a two-address instruction's first operand, which its destination is otherwise a copy of. The
    // definition's interval takes one where that operand's interval ends at the definition, and nothing else hints it.
    const uint32_t* ties;
    // Optional (#2767): increasing positions where a fixed register's sequence writes general registers (a division's
    // rax and rdx, a shift by cl's rcx), and the general registers each writes. Its consumer saves a value that lives
    // past one in such a register around it (tier1_emit_cfg_fixed), so a general range live across one, from before it
    // to after it, avoids them (tier1_cfg_crossed, Tier1AllocationInput.avoided_registers): it takes one only where no
    // other register is free, and evicts no value for one. The sequence's own value, which starts there, and an operand
    // that ends there don't avoid them. Optional with them, sequence_readers names per sequence a value it reads in its
    // registers and leaves there (a shift's count in cl), whose range doesn't avoid them across it, or
    // BUSTER_TIER1_CFG_NONE. Optional with them too, sequence_operands and sequence_results name per sequence an operand
    // and its own value, or BUSTER_TIER1_CFG_NONE, that avoid its registers though they don't live across it: values its
    // records would move out of them through the scratch register (a division's divisor; a shift's other operand, and
    // the shift's destination, which takes that operand's register where it dies).
    const uint32_t* sequences;
    const uint32_t* sequence_registers;
    const uint32_t* sequence_readers;
    const uint32_t* sequence_operands;
    const uint32_t* sequence_results;
    uint32_t sequence_count;
    // Optional (#2819): general registers every general range avoids, as one avoids a sequence's above: a leaf function's
    // callee-saved registers, which a range takes only where no caller-saved one is free.
    uint32_t avoided_general;
    // Optional (#2611): the dominator tree of this CFG but its first `dominator_shift` blocks (0, or 1 where an entry was
    // added before the tree's entry, which then dominates every block), block b's node b - dominator_shift, with its idom,
    // preorder and subtree_end; tier1_cfg_anchors reads it rather than analyzing the CFG. Null analyzes it.
    const Dominators* dominators;
    uint32_t dominator_shift;
    uint32_t block_count;
    uint32_t edge_count;
    uint32_t value_count;
    uint32_t use_count;
    uint32_t phi_count;
    uint32_t position_count;
    uint32_t registers[BUSTER_TIER1_ALLOCATE_CLASSES];
    // Each class's register for move cycles and memory-to-memory moves: outside `registers`, never allocated.
    uint8_t scratch_registers[BUSTER_TIER1_ALLOCATE_CLASSES];
    Tier1FixedIntervals fixed;
};

typedef struct Tier1CfgAllocation Tier1CfgAllocation;
struct Tier1CfgAllocation
{
    // The allocator's input, which borrows the CFG input's use columns, and its result.
    Tier1AllocationInput intervals;
    Tier1Allocation allocation;
    // Value v's intervals, in position order, are [value_interval_offsets[v], value_interval_offsets[v + 1]).
    uint32_t* value_interval_offsets;
    // Edge e (a successor CSR index) has moves [edge_move_offsets[e], edge_move_offsets[e + 1]), in their order.
    uint8_t* edge_placements;
    uint32_t* edge_move_offsets;
    uint32_t* move_sources;
    uint32_t* move_destinations;
    uint32_t* move_values;
    uint32_t move_count;
    // Positions inside blocks where a value's range is cut around a fixed range that blocks it: split k, at
    // split_positions[k], has moves [split_move_offsets[k], split_move_offsets[k + 1]), after every edge's, which run
    // at that position after its stores and before its reloads.
    uint32_t* split_positions;
    uint32_t* split_move_offsets;
    uint32_t split_count;
    uint32_t split_edges;
    uint32_t cross_block_values;
    uint32_t edge_local_values;
    // Bit c: a move uses class c's temporary slot, which the frame must then reserve.
    uint8_t temp_slots;
    // dataflow_liveness's sweeps, over every group of global values (tier1_cfg_live_sets), or with sparse_liveness the
    // worklist's block visits.
    uint64_t liveness_iterations;
    // The four liveness matrices of one group, at most 256 bytes a block, or with sparse_liveness the most rows one
    // group touched, 256 bytes each; excluding CFG columns and the allocator's other working state.
    uint64_t liveness_bytes;
    // Whether the groups were solved by the worklist over their touched blocks (tier1_cfg_live_group_sparse, #1384).
    uint8_t sparse_liveness;
    // The entries of the blocks' live-in and live-out lists, which hold the liveness the groups' matrices leave.
    uint64_t live_entries;
    uint64_t retained_bytes;
    uint64_t scratch_bytes;
    // Position q's block, length position_count, or null when the column is not retained. The verifier does not read it.
    uint32_t* position_blocks;
    // Value v's first interval overlapping block b is value_block_intervals[value_block_base[v] + b], or
    // BUSTER_TIER1_CFG_NONE when the value misses the block. A base of BUSTER_TIER1_CFG_NONE keeps the binary search.
    // Null columns keep it for every value. Emission uses these; the verifier and the certificate do not.
    uint32_t* value_block_base;
    uint32_t* value_block_intervals;
    // The input's blocks, borrowed as `intervals` borrows its uses (tier1_cfg_entry_unread), or null for none.
    const uint32_t* block_starts;
    uint32_t block_count;
    // Per interval, 1 where it enters its block as its recipe because no block it carries the value to reads its
    // register (tier1_cfg_carried_unread, #2734), or null for none.
    uint8_t* unread_entries;
    // Per block, the values live into it whose slot holds them at its start whatever place their range enters it in
    // (tier1_cfg_current_slots, #2553): block b's are current_slots[current_slot_offsets[b] .. current_slot_offsets[b + 1]).
    // Null where no value has a slot, and in an allocation without them.
    uint32_t* current_slot_offsets;
    uint32_t* current_slots;
};

typedef enum Tier1CfgError
{
    TIER1_CFG_OK,
    TIER1_CFG_INVALID,
    TIER1_CFG_CAPACITY,
    TIER1_CFG_CONSTRAINT,
} Tier1CfgError;

static uint32_t tier1_cfg_block_of(const Tier1CfgInput* input, uint32_t position)
{
    uint32_t low = 0;
    uint32_t high = input->block_count;
    while (high - low > 1)
    {
        const uint32_t middle = low + (high - low) / 2;
        if (input->block_starts[middle] <= position)
        {
            low = middle;
        }
        else
        {
            high = middle;
        }
    }
    return low;
}

// Position q's block, from the allocation's retained column when it has one, else by binary search: emission's reads
// (#1399). Positions past the column search too, as tier1_cfg_block_of answers them.
static uint32_t tier1_cfg_block_at(const Tier1CfgInput* input, const Tier1CfgAllocation* result, uint32_t position)
{
    return result->position_blocks != 0 && position < input->position_count ? result->position_blocks[position] : tier1_cfg_block_of(input, position);
}

// Whether `input` is one the allocator takes. With `position_blocks`, a column of position_count entries, it also labels
// each position with its block once the blocks are known to be in order, and checks each value's uses against its
// definition's block from that column, with no search (#1399): a use at p is in the block [s, t) that holds the
// definition d only if s <= p < t, and since d < t, "elsewhere or at or after d" is p < s or p >= d. Without it (the
// verifier, and the column's oracle in test-tier1-cfg) each definition and use searches block_starts.
static bool tier1_cfg_input_valid_into(const Tier1CfgInput* input, Arena* scratch, uint32_t* position_blocks)
{
    const uint64_t saved = scratch->length;
    bool valid = input->block_count != 0 && input->block_count <= BUSTER_TIER1_ALLOCATE_MAX_INTERVALS && input->value_count <= BUSTER_TIER1_ALLOCATE_MAX_INTERVALS && input->position_count <= BUSTER_TIER1_ALLOCATE_MAX_POSITIONS && input->use_count <= BUSTER_TIER1_ALLOCATE_MAX_USES && input->edge_count <= BUSTER_TIER1_ALLOCATE_MAX_USES;
    valid = valid && input->phi_count <= input->value_count && input->block_starts != 0 && input->successor_offsets != 0 && input->predecessor_offsets != 0 && input->phi_offsets != 0 && input->phi_operand_offsets != 0;
    valid = valid && (input->edge_count == 0 || (input->successors != 0 && input->predecessors != 0));
    valid = valid && (input->value_count == 0 || (input->classes != 0 && input->allowed_registers != 0 && input->definitions != 0 && input->use_offsets != 0));
    valid = valid && (input->use_count == 0 || input->use_positions != 0) && (input->phi_count == 0 || (input->phi_values != 0 && input->phi_operands != 0));
    for (uint32_t c = 0; valid && c < BUSTER_TIER1_ALLOCATE_CLASSES; c += 1)
    {
        valid = input->scratch_registers[c] < 32 && ((input->registers[c] >> input->scratch_registers[c]) & 1) == 0;
    }
    valid = valid && (input->registers[BUSTER_TIER1_ALLOCATE_GPR] & 0xffff0000u) == 0 && input->scratch_registers[BUSTER_TIER1_ALLOCATE_GPR] < 16;
    valid = valid && (input->registers[BUSTER_TIER1_ALLOCATE_MASK] & ~BUSTER_TIER1_ALLOCATE_MASK_REGISTERS) == 0 && input->scratch_registers[BUSTER_TIER1_ALLOCATE_MASK] < 8;
    valid = valid && input->block_starts[0] == 0 && input->block_starts[input->block_count] == input->position_count;
    valid = valid && input->fixed.count <= BUSTER_TIER1_ALLOCATE_MAX_INTERVALS && (input->fixed.count == 0 || (input->fixed.starts != 0 && input->fixed.ends != 0 && input->fixed.classes != 0 && input->fixed.registers != 0));
    for (uint32_t r = 0; valid && r < input->fixed.count; r += 1)
    {
        valid = input->fixed.starts[r] < input->fixed.ends[r] && input->fixed.ends[r] <= input->position_count && input->fixed.classes[r] < BUSTER_TIER1_ALLOCATE_CLASSES;
    }
    valid = valid && input->sequence_count <= input->position_count && (input->sequence_count == 0 || (input->sequences != 0 && input->sequence_registers != 0));
    for (uint32_t k = 0; valid && k < input->sequence_count; k += 1)
    {
        valid = input->sequences[k] < input->position_count && (k == 0 || input->sequences[k - 1] < input->sequences[k]) && (input->sequence_registers[k] & 0xffff0000u) == 0;
        valid = valid && (input->sequence_readers == 0 || input->sequence_readers[k] == BUSTER_TIER1_CFG_NONE || input->sequence_readers[k] < input->value_count);
        valid = valid && (input->sequence_operands == 0 || input->sequence_operands[k] == BUSTER_TIER1_CFG_NONE || input->sequence_operands[k] < input->value_count);
        valid = valid && (input->sequence_results == 0 || input->sequence_results[k] == BUSTER_TIER1_CFG_NONE || input->sequence_results[k] < input->value_count);
    }
    for (uint32_t b = 0; valid && b < input->block_count; b += 1)
    {
        valid = input->block_starts[b] < input->block_starts[b + 1];
    }
    // The blocks are in order from 0 to position_count: every position gets one label. Each block's bounds are read
    // before its stores, which could alias block_starts as far as the compiler knows.
    for (uint32_t b = 0; valid && position_blocks != 0 && b < input->block_count; b += 1)
    {
        const uint32_t from = input->block_starts[b];
        const uint32_t to = input->block_starts[b + 1];
        for (uint32_t q = from; q < to; q += 1)
        {
            position_blocks[q] = b;
        }
    }
    valid = valid && input->successor_offsets[0] == 0 && input->successor_offsets[input->block_count] == input->edge_count;
    valid = valid && input->predecessor_offsets[0] == 0 && input->predecessor_offsets[input->block_count] == input->edge_count;
    valid = valid && input->predecessor_offsets[1] == 0;
    // Transpose the successor view into the predecessor ranges, then consume each source once. Neither CSR view
    // needs sorted rows; the caller's predecessor order (and therefore its phi operands) stays unchanged. Check all
    // offsets before indexing either edge array, including intermediate offsets beyond the declared edge count.
    const uint32_t blocks = input->block_count;
    const uint32_t edges = input->edge_count;
    const uint32_t* const successor_offsets = input->successor_offsets;
    const uint32_t* const predecessor_offsets = input->predecessor_offsets;
    const uint32_t* const successors = input->successors;
    const uint32_t* const predecessor_sources = input->predecessors;
    for (uint32_t b = 0; valid && b < blocks; b += 1)
    {
        valid = successor_offsets[b] <= successor_offsets[b + 1] && successor_offsets[b + 1] <= edges && predecessor_offsets[b] <= predecessor_offsets[b + 1] && predecessor_offsets[b + 1] <= edges;
    }
    uint32_t* cursors = valid ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* marks = valid ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* incoming = valid ? arena_push_array(scratch, (uint64_t)edges + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    valid = valid && cursors != 0 && marks != 0 && incoming != 0;
    if (valid)
    {
        memcpy(cursors, predecessor_offsets, (uint64_t)blocks * sizeof(uint32_t));
        memset(marks, 0, (uint64_t)blocks * sizeof(uint32_t));
    }
    for (uint32_t b = 0; valid && b < blocks; b += 1)
    {
        const uint32_t end = successor_offsets[b + 1];
        for (uint32_t e = successor_offsets[b]; valid && e < end; e += 1)
        {
            const uint32_t target = successors[e];
            valid = target < blocks && cursors[target] < predecessor_offsets[target + 1];
            if (valid)
            {
                incoming[cursors[target]] = b;
                cursors[target] += 1;
            }
        }
    }
    for (uint32_t b = 0; valid && b < blocks; b += 1)
    {
        const uint32_t first = predecessor_offsets[b];
        const uint32_t end = predecessor_offsets[b + 1];
        const uint32_t stamp = b + 1;
        valid = cursors[b] == end;
        for (uint32_t e = first; valid && e < end; e += 1)
        {
            const uint32_t source = incoming[e];
            valid = marks[source] != stamp;
            marks[source] = stamp;
        }
        for (uint32_t e = first; valid && e < end; e += 1)
        {
            const uint32_t source = predecessor_sources[e];
            valid = source < blocks && marks[source] == stamp;
            if (valid)
            {
                marks[source] = 0;
            }
        }
    }
    // Phis: none in the entry; each value at most once, defined at its block's start, one operand of its class per
    // predecessor.
    valid = valid && input->phi_offsets[0] == 0 && input->phi_offsets[1] == 0 && input->phi_offsets[input->block_count] == input->phi_count && input->phi_operand_offsets[0] == 0;
    uint8_t* phi = valid ? arena_push(scratch, (uint64_t)input->value_count + 1, 1) : 0;
    valid = valid && phi != 0;
    if (valid)
    {
        memset(phi, 0, (uint64_t)input->value_count + 1);
    }
    for (uint32_t b = 0; valid && b < input->block_count; b += 1)
    {
        valid = input->phi_offsets[b] <= input->phi_offsets[b + 1];
        const uint32_t predecessors = input->predecessor_offsets[b + 1] - input->predecessor_offsets[b];
        for (uint32_t k = input->phi_offsets[b]; valid && k < input->phi_offsets[b + 1]; k += 1)
        {
            const uint32_t v = input->phi_values[k];
            // A phi has no recipe: its edges define it.
            valid = v < input->value_count && phi[v] == 0 && input->classes[v] < BUSTER_TIER1_ALLOCATE_CLASSES && input->definitions[v] == input->block_starts[b] && (input->rematerializable == 0 || input->rematerializable[v] == 0);
            valid = valid && input->phi_operand_offsets[k] + predecessors == input->phi_operand_offsets[k + 1];
            for (uint32_t j = 0; valid && j < predecessors; j += 1)
            {
                const uint32_t operand = input->phi_operands[input->phi_operand_offsets[k] + j];
                valid = operand == BUSTER_TIER1_CFG_NONE || (operand < input->value_count && input->classes[operand] == input->classes[v]);
            }
            if (valid)
            {
                phi[v] = 1;
            }
        }
    }
    // Every value: its class, registers and definition; its uses sorted, none before a definition in its own block (a
    // phi's definition precedes its block's first position, which may use it; another value's use at its own definition
    // is the definition's: required, the definition writes a register).
    valid = valid && (input->value_count == 0 || input->use_offsets[0] == 0) && (input->value_count == 0 || input->use_offsets[input->value_count] == input->use_count);
    for (uint32_t v = 0; valid && v < input->value_count; v += 1)
    {
        valid = input->classes[v] < BUSTER_TIER1_ALLOCATE_CLASSES && (input->allowed_registers[v] & ~input->registers[input->classes[v]]) == 0 && input->definitions[v] < input->position_count &&
                (input->definition_registers == 0 || (input->definition_registers[v] & ~input->allowed_registers[v]) == 0);
        valid = valid && (input->rematerializable == 0 || input->rematerializable[v] <= 1) && input->use_offsets[v] <= input->use_offsets[v + 1];
        const uint32_t definition = valid ? input->definitions[v] : 0;
        const uint32_t block = valid ? (position_blocks != 0 ? position_blocks[definition] : tier1_cfg_block_of(input, definition)) : 0;
        const uint32_t entry = valid ? input->block_starts[block] : 0;
        for (uint32_t u = input->use_offsets[v]; valid && u < input->use_offsets[v + 1]; u += 1)
        {
            const uint32_t position = input->use_positions[u];
            valid = position < input->position_count && (u == input->use_offsets[v] || position >= input->use_positions[u - 1]);
            valid = valid && (position_blocks != 0 ? position < entry || position >= definition : tier1_cfg_block_of(input, position) != block || position >= definition);
            valid = valid && (input->use_required == 0 || input->use_required[u] <= 1);
        }
    }
    arena_pop_to(scratch, saved);
    return valid;
}

static bool tier1_cfg_input_valid(const Tier1CfgInput* input, Arena* scratch)
{
    return tier1_cfg_input_valid_into(input, scratch, 0);
}

// For a validated input, publish the sole incoming edge's successor-CSR index per block, or NONE. The emitter owns
// `edges`, a disjoint block_count-entry scratch column. One edge sweep replaces a search per single-predecessor block.
static void tier1_cfg_single_predecessor_edges(const Tier1CfgInput* input, uint32_t* edges)
{
    const uint32_t blocks = input->block_count;
    const uint32_t count = input->edge_count;
    const uint32_t* const successors = input->successors;
    const uint32_t* const offsets = input->predecessor_offsets;
    memset(edges, 0xff, (uint64_t)blocks * sizeof(uint32_t));
    for (uint32_t e = 0; e < count; e += 1)
    {
        const uint32_t target = successors[e];
        if (offsets[target + 1] - offsets[target] == 1)
        {
            edges[target] = e;
        }
    }
}

// Each successor edge's ordinal in its target's original predecessor row (#1384). Input is validated and immutable:
// both views have the same duplicate-free edges. Transpose edge ids with their sources, then map each target's records
// through its original row. This preserves shuffled phi operands without a predecessor search on every edge.
// Only the ordinal column is retained. Failure restores scratch and leaves *result unchanged.
static bool tier1_cfg_edge_ordinals(const Tier1CfgInput* input, Arena* scratch, uint32_t** result)
{
    const uint64_t saved = scratch->length;
    const uint32_t blocks = input->block_count;
    const uint32_t edges = input->edge_count;
    const uint32_t* const successor_offsets = input->successor_offsets;
    const uint32_t* const successors = input->successors;
    const uint32_t* const predecessor_offsets = input->predecessor_offsets;
    const uint32_t* const predecessors = input->predecessors;
    uint32_t* ordinals = arena_push_array(scratch, (uint64_t)edges + 1, sizeof(uint32_t), _Alignof(uint32_t));
    const uint64_t retained = scratch->length;
    uint32_t* positions = ordinals != 0 ? arena_push_array(scratch, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint64_t* incoming = positions != 0 ? arena_push_array(scratch, (uint64_t)edges + 1, sizeof(uint64_t), _Alignof(uint64_t)) : 0;
    const bool ready = ordinals != 0 && positions != 0 && incoming != 0;
    if (ready)
    {
        memcpy(positions, predecessor_offsets, (uint64_t)blocks * sizeof(uint32_t));
        for (uint32_t b = 0; b < blocks; b += 1)
        {
            const uint32_t end = successor_offsets[b + 1];
            for (uint32_t e = successor_offsets[b]; e < end; e += 1)
            {
                const uint32_t target = successors[e];
                incoming[positions[target]] = ((uint64_t)b << 32) | e;
                positions[target] += 1;
            }
        }
        // Every incoming source is in this target's original row. Each position is written before being read for
        // that target, so reusing the cursor column needs neither initialization nor generation stamps.
        for (uint32_t b = 0; b < blocks; b += 1)
        {
            const uint32_t first = predecessor_offsets[b];
            const uint32_t end = predecessor_offsets[b + 1];
            for (uint32_t p = first; p < end; p += 1)
            {
                positions[predecessors[p]] = p - first;
            }
            for (uint32_t p = first; p < end; p += 1)
            {
                const uint64_t record = incoming[p];
                ordinals[(uint32_t)record] = positions[(uint32_t)(record >> 32)];
            }
        }
    }
    arena_pop_to(scratch, ready ? retained : saved);
    if (ready)
    {
        *result = ordinals;
    }
    return ready;
}

// Value v's interval that covers `position`, by binary search, or BUSTER_TIER1_CFG_NONE. The verifier and the
// certificate use this. Emission uses tier1_cfg_interval_at, which reads the block column when it is present.
static uint32_t tier1_cfg_interval_oracle(const Tier1CfgAllocation* result, uint32_t value, uint32_t position)
{
    const uint32_t last = result->value_interval_offsets[value + 1];
    uint32_t low = result->value_interval_offsets[value];
    uint32_t high = last;
    // The first interval that ends after `position`: the only one that may cover it.
    while (low < high)
    {
        const uint32_t middle = low + (high - low) / 2;
        if (result->intervals.ends[middle] <= position)
        {
            low = middle + 1;
        }
        else
        {
            high = middle;
        }
    }
    return low < last && result->intervals.starts[low] <= position ? low : BUSTER_TIER1_CFG_NONE;
}

// The same answer from the block column: the stored interval is the first that overlaps the position's block, and the
// value's later pieces in that block are the only ones that can still cover the position.
static uint32_t tier1_cfg_interval_at(const Tier1CfgAllocation* result, uint32_t value, uint32_t position)
{
    const uint32_t* bases = result->value_block_base;
    const uint32_t* blocks = result->position_blocks;
    const uint32_t* slots = result->value_block_intervals;
    const bool mapped = bases != 0 && blocks != 0 && slots != 0 && position < result->intervals.position_count && bases[value] != BUSTER_TIER1_CFG_NONE;
    uint32_t found = BUSTER_TIER1_CFG_NONE;
    if (mapped)
    {
        const uint32_t last = result->value_interval_offsets[value + 1];
        uint32_t interval = slots[bases[value] + blocks[position]];
        while (interval != BUSTER_TIER1_CFG_NONE && interval < last && result->intervals.ends[interval] <= position)
        {
            interval += 1;
        }
        if (interval != BUSTER_TIER1_CFG_NONE && interval < last && result->intervals.starts[interval] <= position)
        {
            found = interval;
        }
    }
    else
    {
        found = tier1_cfg_interval_oracle(result, value, position);
    }
    return found;
}

// The fragment of `interval` that covers `position`, encoded as a location id.
static bool tier1_cfg_interval_location(const Tier1CfgAllocation* result, uint32_t value, uint32_t interval, uint32_t position, uint32_t* location, uint8_t* kind)
{
    const Tier1Allocation* allocation = &result->allocation;
    const uint32_t last = allocation->fragment_offsets[interval + 1];
    uint32_t low = allocation->fragment_offsets[interval];
    uint32_t high = last;
    while (low < high)
    {
        const uint32_t middle = low + (high - low) / 2;
        if (allocation->ends[middle] <= position)
        {
            low = middle + 1;
        }
        else
        {
            high = middle;
        }
    }
    const bool found = low < last && allocation->starts[low] <= position;
    if (found)
    {
        const uint8_t fragment_kind = allocation->kinds[low];
        *kind = fragment_kind;
        *location = fragment_kind == BUSTER_TIER1_ALLOCATE_REGISTER ? (uint32_t)result->intervals.classes[interval] * 32 + allocation->registers[low] : fragment_kind == BUSTER_TIER1_ALLOCATE_SPILL ? BUSTER_TIER1_CFG_SPILL + allocation->spill_ids[value] : BUSTER_TIER1_CFG_REMATERIALIZE;
    }
    return found;
}

// Whether a recomputed value's (#178) register fragment `fragment` of `interval` reads nothing from block entry `entry`
// on: it serves no use from there to its end, where the interval's next fragment is the recipe's, before the block's
// last position, so no later fragment takes the register's contents (a transition into a recipe moves nothing; the next
// register fragment recomputes) and no edge leaving the block reads it (an interval may continue into the layout
// successor, and edges' reads aren't uses). An edge into the block then needn't recompute the value into that register:
// control enters with the value's recipe (#1217), as tier1_emit_cfg_dead_definition leaves out a definition's. Without
// it every edge into a loop's dispatch block recomputed a table's or a frame object's address that the block overwrote
// before any use. Without use or block columns nothing is proven. Uses are sorted per interval's slice. The caller has
// checked the cheap part (tier1_cfg_interval_entry): this is the rare proof, out of the hot path, as
// tier1_cfg_slot_current is (#1217's compile-time measurement: inlined whole, every entry paid for it).
static __attribute__((noinline)) bool tier1_cfg_entry_unread(const Tier1CfgAllocation* result, uint32_t interval, uint32_t fragment, uint32_t entry)
{
    const Tier1Allocation* allocation = &result->allocation;
    const Tier1AllocationInput* intervals = &result->intervals;
    bool unread = intervals->use_offsets != 0 && intervals->use_positions != 0 && result->block_starts != 0 && result->block_count != 0;
    if (unread)
    {
        // The block that holds `entry`: the last whose start is at or before it.
        uint32_t low = 0;
        uint32_t high = result->block_count;
        while (low + 1 < high)
        {
            const uint32_t middle = low + (high - low) / 2;
            if (result->block_starts[middle] <= entry)
            {
                low = middle;
            }
            else
            {
                high = middle;
            }
        }
        // Only where control enters a block: a split's piece starts inside one (tier1_cfg_verify refuses one at a block's
        // start), and the verifier checks each piece holds its value whether or not a use reads it there.
        unread = result->block_starts[low] == entry && allocation->ends[fragment] < result->block_starts[low + 1];
    }
    if (unread)
    {
        const uint32_t last = intervals->use_offsets[interval + 1];
        uint32_t low = intervals->use_offsets[interval];
        uint32_t high = last;
        while (low < high)
        {
            const uint32_t middle = low + (high - low) / 2;
            if (intervals->use_positions[middle] < entry)
            {
                low = middle + 1;
            }
            else
            {
                high = middle;
            }
        }
        unread = low == last || intervals->use_positions[low] >= allocation->ends[fragment];
    }
    return unread;
}

// The fragment of `interval` that covers `position`, BUSTER_TIER1_CFG_NONE for none.
static uint32_t tier1_cfg_interval_fragment(const Tier1CfgAllocation* result, uint32_t interval, uint32_t position)
{
    const Tier1Allocation* allocation = &result->allocation;
    const uint32_t last = allocation->fragment_offsets[interval + 1];
    uint32_t low = allocation->fragment_offsets[interval];
    uint32_t high = last;
    while (low < high)
    {
        const uint32_t middle = low + (high - low) / 2;
        if (allocation->ends[middle] <= position)
        {
            low = middle + 1;
        }
        else
        {
            high = middle;
        }
    }
    return low < last && allocation->starts[low] <= position ? low : BUSTER_TIER1_CFG_NONE;
}

// A value's location where control enters its block at `entry`, from `interval`, which covers it: its fragment at
// `position` (entry, or entry - 1 for an interval that continues from the layout predecessor), found once and encoded
// as tier1_cfg_interval_location encodes it, or the recipe where that register fragment reads nothing from the entry on
// (tier1_cfg_entry_unread): a register fragment of a recomputed value with a recipe's fragment after it, or one that
// tier1_cfg_carried_unread proved.
static inline __attribute__((always_inline)) bool tier1_cfg_interval_entry(const Tier1CfgAllocation* result, uint32_t value, uint32_t interval, uint32_t position, uint32_t entry, uint32_t* location, uint8_t* kind)
{
    const Tier1Allocation* allocation = &result->allocation;
    const uint32_t fragment = tier1_cfg_interval_fragment(result, interval, position);
    const bool found = fragment != BUSTER_TIER1_CFG_NONE;
    if (found)
    {
        const uint8_t fragment_kind = allocation->kinds[fragment];
        const bool recomputed = fragment_kind == BUSTER_TIER1_ALLOCATE_REGISTER && result->intervals.rematerializable != 0 && result->intervals.rematerializable[interval] != 0;
        const bool candidate = recomputed && fragment + 1 < allocation->fragment_offsets[interval + 1] && allocation->kinds[fragment + 1] == BUSTER_TIER1_ALLOCATE_REMATERIALIZE;
        const bool carried = recomputed && result->unread_entries != 0 && result->unread_entries[interval] != 0;
        const bool recipe = carried || (candidate && tier1_cfg_entry_unread(result, interval, fragment, entry));
        *kind = recipe ? (uint8_t)BUSTER_TIER1_ALLOCATE_REMATERIALIZE : fragment_kind;
        *location = recipe || fragment_kind == BUSTER_TIER1_ALLOCATE_REMATERIALIZE ? BUSTER_TIER1_CFG_REMATERIALIZE :
                    fragment_kind == BUSTER_TIER1_ALLOCATE_REGISTER                  ? (uint32_t)result->intervals.classes[interval] * 32 + allocation->registers[fragment] :
                                                                                       BUSTER_TIER1_CFG_SPILL + allocation->spill_ids[value];
    }
    return found;
}

static bool tier1_cfg_location_mode(const Tier1CfgAllocation* result, uint32_t value, uint32_t position, uint32_t* location, uint8_t* kind, bool oracle)
{
    const uint32_t interval = oracle ? tier1_cfg_interval_oracle(result, value, position) : tier1_cfg_interval_at(result, value, position);
    return interval != BUSTER_TIER1_CFG_NONE && tier1_cfg_interval_location(result, value, interval, position, location, kind);
}

// The location of value v at position q: its interval's fragment there. Returns false if no interval of v covers q.
static bool tier1_cfg_location(const Tier1CfgAllocation* result, uint32_t value, uint32_t position, uint32_t* location, uint8_t* kind)
{
    return tier1_cfg_location_mode(result, value, position, location, kind, false);
}

static bool tier1_cfg_location_oracle(const Tier1CfgAllocation* result, uint32_t value, uint32_t position, uint32_t* location, uint8_t* kind)
{
    return tier1_cfg_location_mode(result, value, position, location, kind, true);
}

// Where a value must be when control enters its block at `entry`: for an interval that continues from the block's
// layout predecessor, where it was there, since a fragment transition at `entry` runs inside the block; otherwise its
// location at `entry`. The interval that covers `entry` also covers `entry - 1` when it continues. A recomputed value
// whose register there reads nothing from the entry on enters as its recipe (tier1_cfg_entry_unread).
static bool tier1_cfg_entry_location_mode(const Tier1CfgAllocation* result, uint32_t value, uint32_t entry, uint32_t* location, uint8_t* kind, bool oracle)
{
    const uint32_t interval = oracle ? tier1_cfg_interval_oracle(result, value, entry) : tier1_cfg_interval_at(result, value, entry);
    const uint32_t position = interval != BUSTER_TIER1_CFG_NONE && result->intervals.starts[interval] < entry ? entry - 1 : entry;
    return interval != BUSTER_TIER1_CFG_NONE && tier1_cfg_interval_entry(result, value, interval, position, entry, location, kind);
}

static bool tier1_cfg_entry_location(const Tier1CfgAllocation* result, uint32_t value, uint32_t entry, uint32_t* location, uint8_t* kind)
{
    return tier1_cfg_entry_location_mode(result, value, entry, location, kind, false);
}

static bool tier1_cfg_entry_location_oracle(const Tier1CfgAllocation* result, uint32_t value, uint32_t entry, uint32_t* location, uint8_t* kind)
{
    return tier1_cfg_entry_location_mode(result, value, entry, location, kind, true);
}

// #2734: a recomputed value's interval that covers whole blocks, from one's start to the end of the last that continues
// it in layout, which it enters in a register that no use there reads, may carry the value only to blocks that take it
// as their recipe: each successor's interval of the value enters with a recipe's fragment, or with a register that
// reads nothing (tier1_cfg_entry_unread, or this proof in turn), and the value is no phi's operand, which an edge would
// move. Then it enters as its recipe too (tier1_cfg_interval_entry), and no edge into its block recomputes the value
// into a register that the code it reaches overwrites unread: Lua's OP_CALL recomputed five frame addresses into the
// registers that `startfunc` and `returning` load `ci`'s state into. Every interval that qualifies on its own block is
// marked, then a worklist unmarks each with a successor that reads its register, putting back on the list its value's
// marked intervals in the block's predecessors, which may have relied on it: the greatest such set, so that a loop
// carrying a recipe it nowhere reads is proven too. The verifier's walk checks it: an edge that read such a register
// would move nothing into its destination. On no room, no proof.
static void tier1_cfg_carried_unread(const Tier1CfgInput* input, Tier1CfgAllocation* result, Arena* output, Arena* scratch)
{
    const Tier1Allocation* allocation = &result->allocation;
    const Tier1AllocationInput* intervals = &result->intervals;
    const uint32_t count = intervals->count;
    const uint64_t mark = scratch->length;
    const bool possible = intervals->rematerializable != 0 && intervals->use_offsets != 0 && count != 0 && input->block_count != 0;
    uint8_t* marked = possible ? arena_push(output, (uint64_t)count + 1, 1) : 0;
    uint8_t* operands = marked != 0 ? arena_push(scratch, (uint64_t)input->value_count + 1, 1) : 0;
    uint32_t* list = operands != 0 ? arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t listed = 0;
    if (list != 0)
    {
        memset(marked, 0, (uint64_t)count + 1);
        memset(operands, 0, (uint64_t)input->value_count + 1);
        for (uint32_t o = 0; o < input->phi_operand_offsets[input->phi_count]; o += 1)
        {
            const uint32_t operand = input->phi_operands[o];
            if (operand != BUSTER_TIER1_CFG_NONE)
            {
                operands[operand] = 1;
            }
        }
        for (uint32_t i = 0; i < count; i += 1)
        {
            const uint32_t v = intervals->values[i];
            const uint32_t f = allocation->fragment_offsets[i];
            const bool single = intervals->rematerializable[i] != 0 && allocation->fragment_offsets[i + 1] - f == 1 && allocation->kinds[f] == BUSTER_TIER1_ALLOCATE_REGISTER &&
                                intervals->use_offsets[i] == intervals->use_offsets[i + 1] && operands[v] == 0 && input->definitions[v] != intervals->starts[i];
            const uint32_t b = single ? tier1_cfg_block_of(input, intervals->starts[i]) : 0;
            const uint32_t last = single ? tier1_cfg_block_of(input, intervals->ends[i] - 1) : 0;
            if (single && input->block_starts[b] == intervals->starts[i] && input->block_starts[last + 1] == intervals->ends[i])
            {
                marked[i] = 2;
                list[listed] = i;
                listed += 1;
            }
        }
        // Marks: 0 none, 1 proven so far, 2 proven so far and on the list.
        result->unread_entries = marked;
    }
    while (listed != 0)
    {
        listed -= 1;
        const uint32_t i = list[listed];
        const uint32_t v = intervals->values[i];
        const uint32_t first = tier1_cfg_block_of(input, intervals->starts[i]);
        const uint32_t last = tier1_cfg_block_of(input, intervals->ends[i] - 1);
        marked[i] = 1;
        bool read = false;
        // The blocks' edges: an edge to the next of them, which the interval continues into, enters it as the interval.
        for (uint32_t e = input->successor_offsets[first]; !read && e < input->successor_offsets[last + 1]; e += 1)
        {
            const uint32_t entry = input->block_starts[input->successors[e]];
            const uint32_t j = tier1_cfg_interval_at(result, v, entry);
            uint32_t location = 0;
            uint8_t kind = 0;
            const uint32_t position = j != BUSTER_TIER1_CFG_NONE && intervals->starts[j] < entry ? entry - 1 : entry;
            read = j != BUSTER_TIER1_CFG_NONE && (!tier1_cfg_interval_entry(result, v, j, position, entry, &location, &kind) || kind != BUSTER_TIER1_ALLOCATE_REMATERIALIZE);
        }
        if (read)
        {
            marked[i] = 0;
            for (uint32_t k = input->predecessor_offsets[first]; k < input->predecessor_offsets[last + 1]; k += 1)
            {
                const uint32_t p = input->predecessors[k];
                const uint32_t h = tier1_cfg_interval_at(result, v, input->block_starts[p + 1] - 1);
                if (h != BUSTER_TIER1_CFG_NONE && h != i && marked[h] == 1)
                {
                    marked[h] = 2;
                    list[listed] = h;
                    listed += 1;
                }
            }
        }
    }
    arena_pop_to(scratch, mark);
}

// Last spill end at each fragment, by value and layout position. The prefix includes earlier pieces of the
// value's range, so a reload after a fixed-register split keeps the proof. Zero means no spill. This is a linear
// pass over spilled values and their fragments; edge queries must not rescan fragments for each successor of a
// dispatch block. A queried unchanged value has a spill destination, so it has a spill id, which values sharing a slot
// (tier1_cfg_share_slots) each have. Register-only values need no prefix. Column pointers stay local under
// -fno-strict-aliasing.
static void tier1_cfg_spill_prefix(const Tier1CfgAllocation* result, uint32_t* spill_ends)
{
    const uint32_t values = result->intervals.value_count;
    const uint32_t* spill_ids = result->allocation.spill_ids;
    const uint32_t* value_offsets = result->value_interval_offsets;
    const uint32_t* fragment_offsets = result->allocation.fragment_offsets;
    const uint32_t* ends = result->allocation.ends;
    const uint8_t* kinds = result->allocation.kinds;
    for (uint32_t v = 0; v < values; v += 1)
    {
        uint32_t end = 0;
        const uint32_t first = spill_ids[v] != UINT32_MAX ? fragment_offsets[value_offsets[v]] : 0;
        const uint32_t last = spill_ids[v] != UINT32_MAX ? fragment_offsets[value_offsets[v + 1]] : 0;
        for (uint32_t f = first; f < last; f += 1)
        {
            end = kinds[f] == BUSTER_TIER1_ALLOCATE_SPILL ? ends[f] : end;
            spill_ends[f] = end;
        }
    }
}

// Whether this block already establishes value's own slot before position. A spill in the block, including its
// incoming slot state, remains current after reloads: an SSA value cannot change inside its block. A spill from an
// earlier layout block proves nothing. The equality case is a reload at the block's first position in a continuing
// interval: tier1_cfg_entry_location requires the preceding spill location on every incoming edge. A new interval
// at that same position has no such contract. The prefix query is logarithmic, like tier1_cfg_location's.
// Keep this rare proof out of the hot edge helper so the common edge path can be inlined.
static __attribute__((noinline)) bool tier1_cfg_slot_current(const Tier1CfgAllocation* result, const uint32_t* spill_ends, uint32_t value, uint32_t position, uint32_t block_start)
{
    const uint32_t interval = tier1_cfg_interval_at(result, value, position);
    bool current = false;
    if (interval != BUSTER_TIER1_CFG_NONE)
    {
        const uint32_t* offsets = result->allocation.fragment_offsets;
        const uint32_t* ends = result->allocation.ends;
        uint32_t low = offsets[interval];
        uint32_t high = offsets[interval + 1];
        while (low < high)
        {
            const uint32_t middle = low + (high - low) / 2;
            if (ends[middle] <= position)
            {
                low = middle + 1;
            }
            else
            {
                high = middle;
            }
        }
        if (low < offsets[interval + 1])
        {
            const uint32_t end = spill_ends[low];
            current = end > block_start || (end == block_start && result->intervals.starts[interval] < block_start);
        }
    }
    return current;
}

// A location's class: a register's, a slot's value's, a temporary slot's; BUSTER_TIER1_CFG_NONE for no location.
static uint32_t tier1_cfg_location_class(const Tier1CfgInput* input, const Tier1CfgAllocation* result, uint32_t location)
{
    const uint32_t spills = result->allocation.spill_count;
    uint32_t class = BUSTER_TIER1_CFG_NONE;
    if (location < BUSTER_TIER1_CFG_SPILL)
    {
        class = location / 32;
    }
    else if (location - BUSTER_TIER1_CFG_SPILL < spills)
    {
        class = input->classes[result->allocation.spill_values[location - BUSTER_TIER1_CFG_SPILL]];
    }
    else if (location - BUSTER_TIER1_CFG_SPILL - spills < BUSTER_TIER1_ALLOCATE_CLASSES)
    {
        class = location - BUSTER_TIER1_CFG_SPILL - spills;
    }
    return class;
}

static bool tier1_cfg_bit(const uint64_t* row, uint32_t bit)
{
    return ((row[bit >> 6] >> (bit & 63)) & 1) != 0;
}

static void tier1_cfg_set(uint64_t* row, uint32_t bit)
{
    row[bit >> 6] |= UINT64_C(1) << (bit & 63);
}

// One edge's moves while they are gathered and resolved. Each class's pending moves are triples (from, to, carried
// value); carried_at gives the value a location holds at the current step of the edge, valid where its stamp is the
// edge's.
typedef struct Tier1CfgEdge Tier1CfgEdge;
struct Tier1CfgEdge
{
    uint32_t* pending[BUSTER_TIER1_ALLOCATE_CLASSES];
    uint32_t pending_count[BUSTER_TIER1_ALLOCATE_CLASSES];
    bool memory_pair[BUSTER_TIER1_ALLOCATE_CLASSES];
    uint32_t* recompute;
    uint32_t recompute_count;
    uint32_t* carried_at;
    uint32_t* carried_stamps;
    uint32_t stamp;
    // Ordinary CFG edges only: each fragment's last spill end, and the predecessor's first position.
    const uint32_t* spill_ends;
    uint32_t block_start;
    // Ordinary CFG edges only: the values whose slots hold them at the predecessor's start besides their places
    // (tier1_cfg_current_slots), current[current_begin .. current_end), ascending; null for none.
    const uint32_t* current;
    uint32_t current_begin;
    uint32_t current_end;
};

static uint8_t tier1_cfg_kind_of_location(uint32_t location)
{
    uint8_t kind = BUSTER_TIER1_ALLOCATE_REGISTER;
    if (location == BUSTER_TIER1_CFG_REMATERIALIZE)
    {
        kind = BUSTER_TIER1_ALLOCATE_REMATERIALIZE;
    }
    else if (location >= BUSTER_TIER1_CFG_SPILL)
    {
        kind = BUSTER_TIER1_ALLOCATE_SPILL;
    }
    return kind;
}

static bool tier1_cfg_listed(const uint32_t* list, uint32_t begin, uint32_t end, uint32_t block);

// Adds the move `carried` needs to take `value`'s place, when the two locations differ and the destination is not a
// recomputation. A matching pair, a rematerialized destination, or a slot the predecessor already holds, adds nothing.
static void tier1_cfg_edge_place(const Tier1CfgInput* input, const Tier1CfgAllocation* result, Tier1CfgEdge* edge, uint32_t value, uint32_t carried, uint32_t from, uint8_t from_kind, uint32_t to, uint8_t to_kind, uint32_t exit)
{
    // A self-phi, an unchanged live-through value, or an operand of a phi whose slot it shares, need not store a register
    // back to its own slot where that slot already holds it at the predecessor's exit: current at its start and live
    // through it (the predecessor's list, tier1_cfg_current_slots), or stored in it, which is the rest of the analysis'
    // OUT for a value in a register there. A different phi operand must still write it, even when the phi's old value is
    // present there.
    const bool own_slot = from_kind == BUSTER_TIER1_ALLOCATE_REGISTER && to_kind == BUSTER_TIER1_ALLOCATE_SPILL && edge->spill_ends != 0 && result->allocation.spill_ids[carried] != UINT32_MAX &&
                          to == BUSTER_TIER1_CFG_SPILL + result->allocation.spill_ids[carried];
    const bool current_slot = own_slot && ((edge->current != 0 && tier1_cfg_listed(edge->current, edge->current_begin, edge->current_end, carried)) || tier1_cfg_slot_current(result, edge->spill_ends, carried, exit, edge->block_start));
    if (to_kind != BUSTER_TIER1_ALLOCATE_REMATERIALIZE && from != to && !current_slot)
    {
        if (from_kind == BUSTER_TIER1_ALLOCATE_REMATERIALIZE)
        {
            uint32_t* move = edge->recompute + (uint64_t)edge->recompute_count * 3;
            move[0] = BUSTER_TIER1_CFG_REMATERIALIZE;
            move[1] = to;
            move[2] = carried;
            edge->recompute_count += 1;
        }
        else
        {
            const uint32_t class = input->classes[value];
            uint32_t* move = edge->pending[class] + (uint64_t)edge->pending_count[class] * 3;
            move[0] = from;
            move[1] = to;
            move[2] = carried;
            edge->pending_count[class] += 1;
            edge->memory_pair[class] = edge->memory_pair[class] || (from >= BUSTER_TIER1_CFG_SPILL && to >= BUSTER_TIER1_CFG_SPILL);
            edge->carried_at[from] = carried;
            edge->carried_stamps[from] = edge->stamp;
        }
    }
}

// One value of an edge successor's entry state whose locations were already resolved. Returns false where either side
// has no location.
static bool tier1_cfg_edge_known(const Tier1CfgInput* input, const Tier1CfgAllocation* result, Tier1CfgEdge* edge, uint32_t value, uint32_t carried, uint32_t from, uint32_t to, uint32_t exit)
{
    const bool found = from != BUSTER_TIER1_CFG_NONE && to != BUSTER_TIER1_CFG_NONE;
    if (found)
    {
        tier1_cfg_edge_place(input, result, edge, value, carried, from, tier1_cfg_kind_of_location(from), to, tier1_cfg_kind_of_location(to), exit);
    }
    return found;
}

// One value of an edge successor's entry state: `value` there, `carried` (the value itself, or a phi's operand) from
// the predecessor's exit. Adds its move, if it needs one, to its class's pending moves or to the recomputations.
// Returns false where either side has no location. Splits use this; edges use the swept locations.
static bool tier1_cfg_edge_value(const Tier1CfgInput* input, const Tier1CfgAllocation* result, Tier1CfgEdge* edge, uint32_t value, uint32_t carried, uint32_t exit, uint32_t entry)
{
    uint32_t from = 0;
    uint32_t to = 0;
    uint8_t from_kind = 0;
    uint8_t to_kind = 0;
    const bool found = tier1_cfg_location(result, carried, exit, &from, &from_kind) && tier1_cfg_entry_location(result, value, entry, &to, &to_kind);
    if (found)
    {
        tier1_cfg_edge_place(input, result, edge, value, carried, from, from_kind, to, to_kind, exit);
    }
    return found;
}

// Stages one edge's moves after `staged_count`: each class's pending moves in tier1_resolve_moves' order, a
// slot-to-slot one through the class's scratch register, then the recomputations. Returns false on a resolution
// failure or a move past `capacity`, which a valid allocation never reaches.
static bool tier1_cfg_edge_stage(const Tier1CfgInput* input, uint32_t spills, Tier1CfgEdge* edge, Arena* scratch, uint32_t* sources, uint32_t* destinations, uint32_t* staged, uint64_t capacity, uint32_t* staged_count, uint8_t* temp_slots)
{
    const uint32_t locations = BUSTER_TIER1_CFG_SPILL + spills + BUSTER_TIER1_ALLOCATE_CLASSES;
    bool valid = true;
    uint32_t count = *staged_count;
    for (uint32_t c = 0; valid && c < BUSTER_TIER1_ALLOCATE_CLASSES; c += 1)
    {
        const uint32_t pending = edge->pending_count[c];
        const uint32_t conduit = c * 32 + input->scratch_registers[c];
        const uint32_t temporary = BUSTER_TIER1_CFG_SPILL + spills + c;
        for (uint32_t m = 0; m < pending; m += 1)
        {
            sources[m] = edge->pending[c][m * 3];
            destinations[m] = edge->pending[c][m * 3 + 1];
        }
        const Tier1ParallelMoves parallel = {
            .sources = sources,
            .destinations = destinations,
            .count = pending,
            .scratch = edge->memory_pair[c] ? temporary : conduit,
        };
        const uint64_t mark = scratch->length;
        Tier1ResolvedMoves resolved = { 0 };
        valid = pending == 0 || tier1_resolve_moves(&parallel, scratch, &resolved) == TIER1_ALLOCATION_OK;
        for (uint32_t m = 0; valid && pending != 0 && m < resolved.count; m += 1)
        {
            const uint32_t from = resolved.sources[m];
            const uint32_t to = resolved.destinations[m];
            valid = from < locations && to < locations && edge->carried_stamps[from] == edge->stamp && (uint64_t)count + 2 <= capacity;
            if (valid)
            {
                const uint32_t carried = edge->carried_at[from];
                const bool memory = from >= BUSTER_TIER1_CFG_SPILL && to >= BUSTER_TIER1_CFG_SPILL;
                uint32_t* move = staged + (uint64_t)count * 3;
                move[0] = from;
                move[1] = memory ? conduit : to;
                move[2] = carried;
                move[3] = conduit;
                move[4] = to;
                move[5] = carried;
                count += memory ? 2 : 1;
                edge->carried_at[to] = carried;
                edge->carried_stamps[to] = edge->stamp;
                *temp_slots |= (uint8_t)((from == temporary || to == temporary) << c);
            }
        }
        arena_pop_to(scratch, mark);
    }
    for (uint32_t m = 0; valid && m < edge->recompute_count; m += 1)
    {
        valid = (uint64_t)count + 1 <= capacity;
        if (valid)
        {
            memcpy(staged + (uint64_t)count * 3, edge->recompute + (uint64_t)m * 3, 3 * sizeof(uint32_t));
            count += 1;
        }
    }
    *staged_count = count;
    return valid;
}

// The intervals being built: counted, or with `fill` filled, by value and position, with the splits among them.
typedef struct Tier1CfgPieces Tier1CfgPieces;
struct Tier1CfgPieces
{
    uint32_t* starts;
    uint32_t* ends;
    uint32_t* values;
    uint32_t* allowed;
    uint8_t* classes;
    uint8_t* remat;
    uint32_t* hints;
    uint32_t* hint_intervals;
    uint32_t* alternates;
    uint32_t* continuations;
    uint32_t* split_positions;
    uint32_t* split_values;
    uint64_t count;
    uint64_t splits;
    bool fill;
};

// A new interval of value v over [start, end), hinted to `hint`'s register, or first to the one interval `earlier`
// started in; a split where it continues v's range in its block.
static void tier1_cfg_piece(Tier1CfgPieces* pieces, const Tier1CfgInput* input, uint32_t v, uint32_t start, uint32_t end, uint32_t hint, uint32_t earlier, bool split)
{
    if (pieces->fill)
    {
        const uint64_t i = pieces->count;
        pieces->starts[i] = start;
        pieces->ends[i] = end;
        pieces->values[i] = v;
        const uint32_t defined = input->definition_registers != 0 ? input->definition_registers[v] : 0;
        pieces->allowed[i] = defined != 0 && start <= input->definitions[v] && input->definitions[v] < end ? defined : input->allowed_registers[v];
        pieces->classes[i] = input->classes[v];
        pieces->remat[i] = input->rematerializable != 0 ? input->rematerializable[v] : 0;
        pieces->hints[i] = hint;
        pieces->hint_intervals[i] = earlier;
        pieces->alternates[i] = BUSTER_TIER1_CFG_NONE;
        pieces->continuations[i] = BUSTER_TIER1_CFG_NONE;
        if (split)
        {
            pieces->split_positions[pieces->splits] = start;
            pieces->split_values[pieces->splits] = v;
        }
    }
    pieces->count += 1;
    pieces->splits += split;
}

// Block b's immediate dominator in a CFG whose blocks from `shift` on are `tree`'s, block b its node b - shift (#2611): an
// added entry (shift 1) dominates the tree's entry, and its own is none. BUSTER_TIER1_CFG_NONE for an unreachable block.
static uint32_t tier1_cfg_dominator(const Dominators* tree, uint32_t shift, uint32_t b)
{
    const uint32_t node = b - shift;
    const uint32_t idom = b >= shift ? tree->idom[node] : BUSTER_DOMINATOR_NONE;
    const bool entry = b >= shift && node == tree->entry && shift != 0;
    return entry ? 0 : b < shift || idom == BUSTER_DOMINATOR_NONE || node == tree->entry ? BUSTER_TIER1_CFG_NONE : idom + shift;
}

// Whether block `dominator` dominates block `block` in tier1_cfg_dominator's CFG, for a dominator past the added entry (the
// anchors ask whether a block dominates a predecessor laid out before it, so never of block 0): no such block dominates the
// added entry.
static bool tier1_cfg_dominates(const Dominators* tree, uint32_t shift, uint32_t dominator, uint32_t block)
{
    return dominator >= shift && block >= shift && dominators_dominates(tree, dominator - shift, block - shift);
}

// Each block's anchor and chosen predecessor (#2553), from dominators.c's tree, which `scratch` holds until they are read,
// with its temporaries on `output`; both arenas end as they began, but for the caller's two columns. False where the
// analysis fails.
// - The chosen predecessor, by its index among the block's, is the one whose exit its phis take their operands' places
//   from: one laid out before the block that the block dominates (a loop's latch, whose back edge runs every
//   iteration: the nearest in layout of them), else the immediate dominator where it is a predecessor laid out before
//   the block (its edge then moves no value the block takes from before it), else the nearest predecessor before the
//   block in layout, which the allocator has most likely placed last; none where every predecessor follows the block.
// - The anchor is the block whose exit the block takes its other values' places from: such a latch, as for the phis,
//   since the loop's body, laid out before its header, has placed them; else the immediate dominator where that is laid
//   out before the block; else none: the entry, an unreachable block, or one whose dominator follows it, as a dispatch
//   loop's handlers' join does, whose own conventions (`siblings`, `firsts`) take them. A value live into a block is live
//   out of each of its predecessors, and out of its immediate dominator, unless the block is its definition's: the values
//   a block takes from its anchor's exit are there at once, each in its own place.
static bool tier1_cfg_anchors(const Tier1CfgInput* input, Arena* output, Arena* scratch, uint32_t* anchors, uint32_t* chosen)
{
    const uint64_t mark = scratch->length;
    const DominatorCfg graph = {
        .block_count = input->block_count,
        .edge_count = input->edge_count,
        .entry = 0,
        .successor_offsets = input->successor_offsets,
        .successors = input->successors,
        .predecessor_offsets = input->predecessor_offsets,
        .predecessors = input->predecessors,
    };
    DominatorOptions options = dominators_options();
    options.outputs = 0;
    Dominators analysis = { 0 };
    // The tree the input gives (#2611), where it covers the CFG but its added entry, or the CFG's own.
    const Dominators* given = input->dominators;
    const uint32_t shift = input->dominator_shift;
    const bool reused = given != 0 && shift <= 1 && given->block_count + shift == input->block_count && given->idom != 0 && given->preorder != 0 && given->subtree_end != 0;
    const bool analyzed = reused || dominators_analyze(scratch, output, &graph, options, &analysis) == DOMINATOR_OK;
    const Dominators* tree = reused ? given : &analysis;
    for (uint32_t b = 0; analyzed && b < input->block_count; b += 1)
    {
        const uint32_t dominator = b != 0 ? tier1_cfg_dominator(tree, reused ? shift : 0, b) : BUSTER_TIER1_CFG_NONE;
        anchors[b] = dominator < b ? dominator : BUSTER_TIER1_CFG_NONE;
        uint32_t latch = BUSTER_TIER1_CFG_NONE;
        uint32_t anchored = BUSTER_TIER1_CFG_NONE;
        uint32_t nearest = BUSTER_TIER1_CFG_NONE;
        for (uint32_t j = 0; j < input->predecessor_offsets[b + 1] - input->predecessor_offsets[b]; j += 1)
        {
            const uint32_t p = input->predecessors[input->predecessor_offsets[b] + j];
            const bool earlier = p < b;
            const bool closer = nearest == BUSTER_TIER1_CFG_NONE || p > input->predecessors[input->predecessor_offsets[b] + nearest];
            const bool back = earlier && tier1_cfg_dominates(tree, reused ? shift : 0, b, p);
            latch = back && (latch == BUSTER_TIER1_CFG_NONE || p > input->predecessors[input->predecessor_offsets[b] + latch]) ? j : latch;
            anchored = earlier && p == anchors[b] ? j : anchored;
            nearest = earlier && closer ? j : nearest;
        }
        chosen[b] = latch != BUSTER_TIER1_CFG_NONE ? latch : anchored != BUSTER_TIER1_CFG_NONE ? anchored : nearest;
        anchors[b] = latch != BUSTER_TIER1_CFG_NONE ? input->predecessors[input->predecessor_offsets[b] + latch] : anchors[b];
    }
    arena_pop_to(scratch, mark);
    return analyzed;
}

// The interval of value v's run [first, end) that holds `position`, or BUSTER_TIER1_CFG_NONE: the runs are in position
// order and don't overlap.
static uint32_t tier1_cfg_piece_at(const Tier1CfgPieces* pieces, uint32_t first, uint32_t end, uint32_t position)
{
    uint32_t low = first;
    uint32_t high = end;
    while (low < high)
    {
        const uint32_t middle = low + (high - low) / 2;
        if (pieces->starts[middle] <= position)
        {
            low = middle + 1;
        }
        else
        {
            high = middle;
        }
    }
    return low > first && pieces->ends[low - 1] > position ? low - 1 : BUSTER_TIER1_CFG_NONE;
}

// A phi's interval that no sibling convention models (#1216) takes its operand's register at the exit of its block's
// chosen predecessor (#2553, tier1_cfg_anchors). Every value's intervals must be filled: an operand's may follow its
// phi's.
//
// But a block with one successor runs its edge to it each time it runs, at least as often as all the edges into it
// together. A phi there that a phi of that successor takes (`ups`, its first) takes first the register that phi's first
// interval opened with, its convention, where that phi still holds it last and it is free at the block's start (the
// allocator's alternate_intervals): the edges into the block then move its operands where they must, rather than the
// one edge after it moving it every time, in a cycle with the values the block defines for the successor's other phis.
// Lua's `startfunc` (#2592, #2734), between OP_CALL's new `ci` and the loop's `returning`, swapped `ci` with `trap`
// through the scratch register on every call. Otherwise the operand's register stays the hint. Following that phi's
// latest register instead gave Lua's handlers swaps of their own, where it had moved in one; following its first
// interval without the check spilled phis in sqlite3VdbeExec, whose phi there had moved to memory.
//
// A block that an earlier block and a dispatch's multiway branch both enter (`dispatchers`, the branch's index among
// its predecessors) takes the dispatch's convention for its phis too: each takes its operand along the branch's edge
// where that operand enters the block's sibling (`siblings`, the branch's first successor), the register every handler
// takes it in, so that the dispatch's edge moves nothing (#2782: Lua's OP_TFORCALL took OP_TFORPREP's registers).
static void tier1_cfg_phi_exits(const Tier1CfgInput* input, const uint32_t* chosen, const uint32_t* ups, const uint32_t* firsts, const uint32_t* dispatchers, const uint32_t* offsets, Tier1CfgPieces* pieces)
{
    for (uint32_t b = 0; b < input->block_count; b += 1)
    {
        const uint32_t sibling = dispatchers[b] != BUSTER_TIER1_CFG_NONE ? firsts[input->predecessors[input->predecessor_offsets[b] + dispatchers[b]]] : BUSTER_TIER1_CFG_NONE;
        const uint32_t j = chosen[b];
        const uint32_t predecessor = j != BUSTER_TIER1_CFG_NONE ? input->predecessors[input->predecessor_offsets[b] + j] : BUSTER_TIER1_CFG_NONE;
        const uint32_t exit = predecessor != BUSTER_TIER1_CFG_NONE ? input->block_starts[predecessor + 1] - 1 : 0;
        const bool single = input->successor_offsets[b + 1] - input->successor_offsets[b] == 1;
        const uint32_t next = single ? input->successors[input->successor_offsets[b]] : BUSTER_TIER1_CFG_NONE;
        for (uint32_t k = input->phi_offsets[b]; k < input->phi_offsets[b + 1]; k += 1)
        {
            const uint32_t v = input->phi_values[k];
            const uint32_t own = tier1_cfg_piece_at(pieces, offsets[v], offsets[v + 1], input->block_starts[b]);
            const uint32_t up = next != BUSTER_TIER1_CFG_NONE ? ups[v] : BUSTER_TIER1_CFG_NONE;
            const bool along = own != BUSTER_TIER1_CFG_NONE && up != BUSTER_TIER1_CFG_NONE && input->definitions[up] == input->block_starts[next] && input->classes[up] == input->classes[v];
            const uint32_t first = along && offsets[up] != offsets[up + 1] ? offsets[up] : BUSTER_TIER1_CFG_NONE;
            if (first != BUSTER_TIER1_CFG_NONE && pieces->starts[first] < pieces->starts[own])
            {
                pieces->alternates[own] = first;
            }
            const uint32_t dispatched = sibling != BUSTER_TIER1_CFG_NONE ? input->phi_operands[input->phi_operand_offsets[k] + dispatchers[b]] : BUSTER_TIER1_CFG_NONE;
            const uint32_t convention = dispatched != BUSTER_TIER1_CFG_NONE ? tier1_cfg_piece_at(pieces, offsets[dispatched], offsets[dispatched + 1], input->block_starts[sibling]) : BUSTER_TIER1_CFG_NONE;
            if (own != BUSTER_TIER1_CFG_NONE && convention != BUSTER_TIER1_CFG_NONE && pieces->hint_intervals[own] == BUSTER_TIER1_CFG_NONE && pieces->classes[convention] == pieces->classes[own] &&
                pieces->starts[convention] == input->block_starts[sibling] && pieces->starts[convention] < pieces->starts[own])
            {
                pieces->hints[own] = dispatched;
                pieces->hint_intervals[own] = convention;
            }
            const uint32_t operand = predecessor != BUSTER_TIER1_CFG_NONE ? input->phi_operands[input->phi_operand_offsets[k] + j] : BUSTER_TIER1_CFG_NONE;
            const uint32_t taken = operand != BUSTER_TIER1_CFG_NONE ? tier1_cfg_piece_at(pieces, offsets[operand], offsets[operand + 1], exit) : BUSTER_TIER1_CFG_NONE;
            if (own != BUSTER_TIER1_CFG_NONE && taken != BUSTER_TIER1_CFG_NONE && pieces->hint_intervals[own] == BUSTER_TIER1_CFG_NONE && pieces->classes[taken] == pieces->classes[own] &&
                pieces->ends[taken] <= pieces->starts[own])
            {
                pieces->hint_intervals[own] = taken | BUSTER_TIER1_ALLOCATE_HINT_EXIT;
            }
        }
    }
}

// The furthest a phi operand's definition looks along its phis for a register (tier1_cfg_operand_targets).
// A branch with at least this many successors is a dispatch's (a switch's table or an indirect jump), whose
// successors share one entry convention (#2782).
#define BUSTER_TIER1_CFG_MULTIWAY 3u

#define BUSTER_TIER1_CFG_TARGET_STEPS 8u

// A value that a phi takes along an edge, and that nothing else hints, is hinted to that phi (`targets`, from the phi
// hints). Where the phi has no interval before the value's definition, no register of it is known there: the hint goes on
// along the phis that take the phi in turn (`ups`, each value's first such phi), to the first with an interval before
// the definition (#2553), whose first interval the definition's interval takes its opening register from: a phi's own,
// or a dispatch loop's join's phi's in its first handler, the register every handler takes it in. A handler passes a
// value on through phis of its own joins to the loop's join: the value is defined in that register, so that none of
// those edges move it, though the phi may have left it in the handler since.
static void tier1_cfg_operand_targets(const Tier1CfgInput* input, const uint32_t* targets, const uint32_t* ups, const uint8_t* phis, const uint32_t* offsets, Tier1CfgPieces* pieces)
{
    for (uint32_t v = 0; v < input->value_count; v += 1)
    {
        uint32_t target = phis[v] == 0 ? targets[v] : BUSTER_TIER1_CFG_NONE;
        const uint32_t definition = input->definitions[v];
        bool unknown = target != BUSTER_TIER1_CFG_NONE && (offsets[target] == offsets[target + 1] || pieces->starts[offsets[target]] > definition);
        for (uint32_t step = 0; unknown && step < BUSTER_TIER1_CFG_TARGET_STEPS && ups[target] != BUSTER_TIER1_CFG_NONE && ups[target] != v && input->classes[ups[target]] == input->classes[v]; step += 1)
        {
            target = ups[target];
            unknown = offsets[target] == offsets[target + 1] || pieces->starts[offsets[target]] > definition;
        }
        const uint32_t own = target != BUSTER_TIER1_CFG_NONE && !unknown ? tier1_cfg_piece_at(pieces, offsets[v], offsets[v + 1], definition) : BUSTER_TIER1_CFG_NONE;
        if (own != BUSTER_TIER1_CFG_NONE)
        {
            const uint32_t first = offsets[target];
            pieces->hints[own] = target;
            pieces->hint_intervals[own] = pieces->hint_intervals[own] == BUSTER_TIER1_CFG_NONE && pieces->starts[first] < pieces->starts[own] ? first : pieces->hint_intervals[own];
        }
    }
}

// A definition that nothing else hints, of a value tied to an operand whose interval ends there (#2685), takes that
// interval's closing register: a two-address instruction's result in its dying first operand's register, which leaves
// out the copy into the destination. An operand live past the definition holds its register, so no hint names it.
static void tier1_cfg_ties(const Tier1CfgInput* input, const uint32_t* offsets, Tier1CfgPieces* pieces)
{
    for (uint32_t v = 0; input->ties != 0 && v < input->value_count; v += 1)
    {
        const uint32_t definition = input->definitions[v];
        const uint32_t own = input->ties[2 * (uint64_t)v] != BUSTER_TIER1_CFG_NONE && definition != 0 ? tier1_cfg_piece_at(pieces, offsets[v], offsets[v + 1], definition) : BUSTER_TIER1_CFG_NONE;
        const bool open = own != BUSTER_TIER1_CFG_NONE && pieces->starts[own] == definition && pieces->hints[own] == BUSTER_TIER1_CFG_NONE && pieces->hint_intervals[own] == BUSTER_TIER1_CFG_NONE;
        for (uint32_t k = 0; open && k < 2; k += 1)
        {
            const uint32_t tied = input->ties[2 * (uint64_t)v + k];
            const uint32_t taken = tied != BUSTER_TIER1_CFG_NONE && tied != v ? tier1_cfg_piece_at(pieces, offsets[tied], offsets[tied + 1], definition - 1) : BUSTER_TIER1_CFG_NONE;
            if (taken != BUSTER_TIER1_CFG_NONE && pieces->ends[taken] == definition && pieces->classes[taken] == pieces->classes[own] && pieces->hints[own] == BUSTER_TIER1_CFG_NONE)
            {
                pieces->hints[own] = tied;
                pieces->hint_intervals[own] = taken | BUSTER_TIER1_ALLOCATE_HINT_EXIT;
            }
        }
    }
}

// A range laid out before its value's definition that nothing hints (#2784): a loop's body laid out before its header,
// none of whose predecessors precede it, so that it has no anchor. It takes its value's defining interval's hint,
// followed back along the hint intervals to the first that another value's range gives before it: the register the
// header's phi takes from its latch's operand, which the blocks before the body placed. Its value's own last register,
// which it took otherwise, was whatever another block of the body had left free, and where the two differed each
// iteration moved the phi into the body's register and its operand back: Lua's str_gsub, whose two phis crossed, swapped
// them through the scratch register twice on its loop's path for a plain character. A hint back to the value's own
// earlier range adds nothing to the register it follows anyway; and one to an exit in a slot never makes the range wait
// in its own (tier1_allocate_scan_uses).
//
// Where the chain reaches no such range (#2834), a phi's first range in layout takes an operand's register at the exit
// of a predecessor of the phi's block, the nearest in layout that ends before the range: the loop's entry, where the
// value comes in. patterns_gsub's latch, whose join's ranges are their values' first, is laid out between the body and
// the header, so that the chain led back to the body's own range, which then took the lowest free register and swapped
// two values with the header's on every iteration. The value's later ranges keep its own last place: a phi of
// sqlite3VdbeExec's opcode loop that rested in its slot through the handlers took its entry's register in each of them
// instead, and the dispatch, short of one, stored the step counter on every opcode. A recipe's exit without a register
// names no place (tier1_allocation_valued_hint).
static void tier1_cfg_body_hints(const Tier1CfgInput* input, const uint32_t* offsets, Tier1CfgPieces* pieces)
{
    for (uint32_t v = 0; v < input->value_count; v += 1)
    {
        const uint32_t defining = offsets[v] != offsets[v + 1] ? tier1_cfg_piece_at(pieces, offsets[v], offsets[v + 1], input->definitions[v]) : BUSTER_TIER1_CFG_NONE;
        for (uint32_t i = offsets[v]; defining != BUSTER_TIER1_CFG_NONE && i < defining; i += 1)
        {
            uint32_t named = pieces->hint_intervals[i] == BUSTER_TIER1_CFG_NONE && pieces->hints[i] == v ? pieces->hint_intervals[defining] : BUSTER_TIER1_CFG_NONE;
            bool before = false;
            for (uint32_t step = 0; named != BUSTER_TIER1_CFG_NONE && !before && step < BUSTER_TIER1_CFG_TARGET_STEPS; step += 1)
            {
                const uint32_t earlier = named & ~BUSTER_TIER1_ALLOCATE_HINT_EXIT;
                // An exit's register is noted as its interval ends, an opening's as it starts: either before i starts.
                before = (named & BUSTER_TIER1_ALLOCATE_HINT_EXIT) != 0 ? pieces->ends[earlier] <= pieces->starts[i] : pieces->starts[earlier] < pieces->starts[i];
                named = before ? named : pieces->hint_intervals[earlier];
            }
            const uint32_t earlier = named & ~BUSTER_TIER1_ALLOCATE_HINT_EXIT;
            if (before && pieces->values[earlier] != v && pieces->classes[earlier] == pieces->classes[i])
            {
                pieces->hint_intervals[i] = named;
            }
        }
    }
    for (uint32_t b = 0; b < input->block_count; b += 1)
    {
        const uint32_t degree = input->predecessor_offsets[b + 1] - input->predecessor_offsets[b];
        for (uint32_t k = input->phi_offsets[b]; k < input->phi_offsets[b + 1]; k += 1)
        {
            const uint32_t v = input->phi_values[k];
            const uint32_t first = offsets[v];
            const bool open = first != offsets[v + 1] && pieces->starts[first] < input->definitions[v] && pieces->hint_intervals[first] == BUSTER_TIER1_CFG_NONE && pieces->hints[first] == v;
            uint32_t nearest = BUSTER_TIER1_CFG_NONE;
            for (uint32_t j = 0; open && j < degree; j += 1)
            {
                const uint32_t predecessor = input->predecessors[input->predecessor_offsets[b] + j];
                const uint32_t operand = input->phi_operands[input->phi_operand_offsets[k] + j];
                const uint32_t exit = input->block_starts[predecessor + 1] - 1;
                const uint32_t taken = operand != BUSTER_TIER1_CFG_NONE && operand != v ? tier1_cfg_piece_at(pieces, offsets[operand], offsets[operand + 1], exit) : BUSTER_TIER1_CFG_NONE;
                const bool fits = taken != BUSTER_TIER1_CFG_NONE && pieces->ends[taken] <= pieces->starts[first] && pieces->classes[taken] == pieces->classes[first];
                nearest = fits && (nearest == BUSTER_TIER1_CFG_NONE || pieces->ends[taken] > pieces->ends[nearest]) ? taken : nearest;
            }
            if (nearest != BUSTER_TIER1_CFG_NONE)
            {
                pieces->hint_intervals[first] = nearest | BUSTER_TIER1_ALLOCATE_HINT_EXIT;
            }
        }
    }
}

// Wider values first, so a partial block column keeps the ones whose binary search is deepest (#1399). Descending:
// narrow values' zero keys sort last, where the install loop's `keys[i] != 0` stops.
static int tier1_cfg_lookup_order(const void* left, const void* right)
{
    const uint64_t a = *(const uint64_t*)left;
    const uint64_t b = *(const uint64_t*)right;
    return (a > b) - (a < b);
}

static uint32_t tier1_cfg_interval_count(const Tier1CfgAllocation* result, uint32_t value)
{
    return result->value_interval_offsets[value + 1] - result->value_interval_offsets[value];
}

// The first interval of each value that overlaps a block, for emission's position lookups. A function whose values
// and blocks fit gets every value; a larger one keeps the widest values that fit in the budget. Failure leaves the
// columns null and the binary search in place, and restores the output length.
static void tier1_cfg_install_lookup(const Tier1CfgInput* input, Arena* output, Arena* scratch, Tier1CfgAllocation* result)
{
    const uint32_t values = input->value_count;
    const uint32_t blocks = input->block_count;
    const uint64_t mark = output->length;
    const uint64_t scratch_mark = scratch->length;
    const bool mapped = result->position_blocks != 0 && values != 0 && blocks != 0 && blocks <= BUSTER_TIER1_CFG_BLOCK_INTERVALS;
    const uint32_t room = mapped ? (uint32_t)(BUSTER_TIER1_CFG_BLOCK_INTERVALS / blocks) : 0;
    uint32_t* base = mapped && room != 0 ? arena_push_array(output, values, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    bool placed = false;
    if (base != 0)
    {
        memset(base, 0xff, (uint64_t)values * sizeof(uint32_t));
        uint32_t chosen = 0;
        if (values <= room)
        {
            for (uint32_t v = 0; v < values; v += 1)
            {
                base[v] = chosen;
                chosen += blocks;
            }
            placed = true;
        }
        else
        {
            uint64_t* keys = arena_push_array(scratch, values, sizeof(uint64_t), _Alignof(uint64_t));
            if (keys != 0)
            {
                for (uint32_t v = 0; v < values; v += 1)
                {
                    const uint32_t n = tier1_cfg_interval_count(result, v);
                    keys[v] = n >= BUSTER_TIER1_CFG_LOOKUP_WIDE ? ((uint64_t)n << 32) | (uint64_t)(UINT32_MAX - v) : 0;
                }
                qsort(keys, values, sizeof(uint64_t), tier1_cfg_lookup_order);
                for (uint32_t i = 0; i < values && chosen / blocks < room && keys[i] != 0; i += 1)
                {
                    const uint32_t v = UINT32_MAX - (uint32_t)keys[i];
                    base[v] = chosen;
                    chosen += blocks;
                }
                placed = chosen != 0;
            }
        }
        uint32_t* slots = placed ? arena_push_array(output, (uint64_t)(chosen / blocks) * blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        if (placed && slots != 0)
        {
            memset(slots, 0xff, (uint64_t)(chosen / blocks) * blocks * sizeof(uint32_t));
            const uint32_t* blocks_of = result->position_blocks;
            for (uint32_t v = 0; v < values; v += 1)
            {
                if (base[v] != BUSTER_TIER1_CFG_NONE)
                {
                    for (uint32_t i = result->value_interval_offsets[v]; i < result->value_interval_offsets[v + 1]; i += 1)
                    {
                        const uint32_t end = result->intervals.ends[i];
                        for (uint32_t b = blocks_of[result->intervals.starts[i]]; b < blocks && input->block_starts[b] < end; b += 1)
                        {
                            uint32_t* slot = slots + base[v] + b;
                            if (*slot == BUSTER_TIER1_CFG_NONE)
                            {
                                *slot = i;
                            }
                        }
                    }
                }
            }
            result->value_block_base = base;
            result->value_block_intervals = slots;
        }
        else
        {
            arena_pop_to(output, mark);
        }
    }
    arena_pop_to(scratch, scratch_mark);
}

static uint32_t tier1_cfg_slot_root(uint32_t* roots, uint32_t slot)
{
    while (roots[slot] != slot)
    {
        roots[slot] = roots[roots[slot]];
        slot = roots[slot];
    }
    return slot;
}

// Phi webs' slots (#1216): with slot_widths, a phi and each operand of its class and width, both spilled somewhere, take
// one slot where no value already sharing either one's is live at another's definition, up to
// BUSTER_TIER1_CFG_SLOT_WEB values a slot. In SSA two values' ranges overlap exactly where one is live at the other's
// definition, so those pairs are a shared slot's whole interference. A phi's slot is written by its edges' moves, which
// read its operands in the same parallel move; a value live out of the predecessor and not into the phi's block is dead
// along that edge, whose moves then run on it alone. A dispatch loop's values that rest in memory then keep one slot
// around the loop, where each edge copied them from one value's slot to the next's. Operands that are phis themselves join
// first (#2553), then the others: a web of phis that pass a value on around a loop keeps one slot, which an entering
// operand, joined first, could have split by being live at one of their definitions. Slots are renumbered in order, each
// keeping its first value in spill_values. False where scratch is short.
static bool tier1_cfg_share_slots(const Tier1CfgInput* input, Tier1CfgAllocation* result, Arena* scratch)
{
    Tier1Allocation* allocation = &result->allocation;
    const uint32_t spills = allocation->spill_count;
    uint32_t* ids = allocation->spill_ids;
    const uint64_t mark = scratch->length;
    uint32_t* roots = arena_push_array(scratch, (uint64_t)spills + 1, sizeof(uint32_t), _Alignof(uint32_t));
    uint32_t* sizes = arena_push_array(scratch, (uint64_t)spills + 1, sizeof(uint32_t), _Alignof(uint32_t));
    uint32_t* heads = arena_push_array(scratch, (uint64_t)spills + 1, sizeof(uint32_t), _Alignof(uint32_t));
    uint32_t* tails = arena_push_array(scratch, (uint64_t)spills + 1, sizeof(uint32_t), _Alignof(uint32_t));
    // Each value's next in its slot's list, and whether it is a phi.
    uint32_t* nexts = arena_push_array(scratch, (uint64_t)input->value_count + 1, sizeof(uint32_t), _Alignof(uint32_t));
    uint8_t* phis = arena_push(scratch, (uint64_t)input->value_count + 1, 1);
    const bool ready = roots != 0 && sizes != 0 && heads != 0 && tails != 0 && nexts != 0 && phis != 0;
    if (ready)
    {
        memset(phis, 0, (uint64_t)input->value_count + 1);
        for (uint32_t k = 0; k < input->phi_count; k += 1)
        {
            phis[input->phi_values[k]] = 1;
        }
    }
    for (uint32_t s = 0; ready && s < spills; s += 1)
    {
        const uint32_t v = allocation->spill_values[s];
        roots[s] = s;
        sizes[s] = 1;
        heads[s] = v;
        tails[s] = v;
        nexts[v] = BUSTER_TIER1_CFG_NONE;
    }
    for (uint32_t pass = 0; pass < 2; pass += 1)
    {
        for (uint32_t k = 0; ready && k < input->phi_count; k += 1)
        {
            const uint32_t phi = input->phi_values[k];
            for (uint32_t o = input->phi_operand_offsets[k]; ids[phi] != UINT32_MAX && o < input->phi_operand_offsets[k + 1]; o += 1)
            {
                const uint32_t operand = input->phi_operands[o];
                const bool paired = operand != BUSTER_TIER1_CFG_NONE && ids[operand] != UINT32_MAX && input->classes[operand] == input->classes[phi] && input->slot_widths[operand] == input->slot_widths[phi] &&
                                    (phis[operand] != 0) == (pass == 0);
                const uint32_t into = paired ? tier1_cfg_slot_root(roots, ids[phi]) : 0;
                const uint32_t from = paired ? tier1_cfg_slot_root(roots, ids[operand]) : 0;
                bool apart = paired && into != from && sizes[into] + sizes[from] <= BUSTER_TIER1_CFG_SLOT_WEB;
                for (uint32_t m = apart ? heads[into] : BUSTER_TIER1_CFG_NONE; apart && m != BUSTER_TIER1_CFG_NONE; m = nexts[m])
                {
                    for (uint32_t n = heads[from]; apart && n != BUSTER_TIER1_CFG_NONE; n = nexts[n])
                    {
                        apart = tier1_cfg_interval_at(result, m, input->definitions[n]) == BUSTER_TIER1_CFG_NONE && tier1_cfg_interval_at(result, n, input->definitions[m]) == BUSTER_TIER1_CFG_NONE;
                    }
                }
                if (apart)
                {
                    roots[from] = into;
                    sizes[into] += sizes[from];
                    nexts[tails[into]] = heads[from];
                    tails[into] = tails[from];
                }
            }
        }
    }
    // A root's new id in \`sizes\`, which it no longer needs: earlier roots take lower ids, so each write lands at or
    // before the slot being read.
    uint32_t count = 0;
    for (uint32_t s = 0; ready && s < spills; s += 1)
    {
        if (roots[s] == s)
        {
            allocation->spill_values[count] = allocation->spill_values[s];
            sizes[s] = count;
            count += 1;
        }
    }
    for (uint32_t v = 0; ready && v < input->value_count; v += 1)
    {
        ids[v] = ids[v] != UINT32_MAX ? sizes[tier1_cfg_slot_root(roots, ids[v])] : UINT32_MAX;
    }
    allocation->spill_count = ready ? count : spills;
    arena_pop_to(scratch, mark);
    return ready;
}

// Each block's global values live into it and live out of it (1. above), ascending: block b's are
// in_values[in_offsets[b] .. in_offsets[b + 1]) and out_values[out_offsets[b] .. out_offsets[b + 1]). Live-out
// includes the global phi operands the block passes on its edges; edge-local operands are in neither (#1384). And
// what the readers would otherwise search the lists for, which the groups' rows give a vector at a time: for each
// live-in entry, whether the value is live out of the block too; for each value, whether it is global and live out of
// its home; and for each block after the first, whether every value live into it is live out of the block before.
typedef struct Tier1CfgLiveSets Tier1CfgLiveSets;
struct Tier1CfgLiveSets
{
    uint32_t* in_offsets;
    uint32_t* in_values;
    uint32_t* out_offsets;
    uint32_t* out_values;
    uint8_t* in_out;
    uint8_t* home_out;
    uint8_t* continues;
};

// One group's seeds, the dense ids [first, last): with `set`, each definition's bit in its home's def row, each
// ordinary use in another block, and each phi occurrence passed from a block other than the operand's home, in the
// use rows. Without it, the words those bits are in go back to zero, which leaves the rows clear for the next group:
// a group's bits are its rows' only ones. `phi_offsets` and `phi_sources` list each dense id's phi occurrences by
// their predecessors.
static void tier1_cfg_live_seeds(const Tier1CfgInput* input, const uint32_t* home, const uint32_t* dense_values, const uint32_t* blocks_of, const uint32_t* phi_offsets, const uint32_t* phi_sources, uint32_t first, uint32_t last, Dataflow* liveness, bool set)
{
    const uint64_t words = liveness->row_words;
    for (uint32_t i = first; i < last; i += 1)
    {
        const uint32_t v = dense_values[i];
        const uint32_t bit = i - first;
        const uint64_t word = bit >> 6;
        const uint64_t mask = set ? UINT64_C(1) << (bit & 63) : 0;
        uint64_t* def = liveness->def + (uint64_t)home[v] * words + word;
        *def = set ? *def | mask : 0;
        for (uint32_t u = input->use_offsets[v]; u < input->use_offsets[v + 1]; u += 1)
        {
            const uint32_t block = blocks_of != 0 ? blocks_of[input->use_positions[u]] : tier1_cfg_block_of(input, input->use_positions[u]);
            if (block != home[v])
            {
                uint64_t* use = liveness->use + (uint64_t)block * words + word;
                *use = set ? *use | mask : 0;
            }
        }
        for (uint32_t k = phi_offsets[i]; k < phi_offsets[i + 1]; k += 1)
        {
            const uint32_t predecessor = phi_sources[k];
            if (predecessor != home[v])
            {
                uint64_t* use = liveness->use + (uint64_t)predecessor * words + word;
                *use = set ? *use | mask : 0;
            }
        }
    }
}

// Past this many block rows swept, blocks times groups, the groups are solved sparsely: a group's dense solve sweeps
// every block's row whatever its values touch, so a function of many short ranges, more than one group of them, took
// time growing with blocks times values (allocating #1353's function of 16,000 scoped loops took 306 ms, of 4,000 25 ms;
// sparsely, 59 and 12 ms). A function of up to 512 global values, one group, never is. The bound is the work the dense
// solves would do, not a storage limit: "Sparse groups" in docs/commands/tier1-cfg.md has the measurements.
#define BUSTER_TIER1_CFG_SPARSE_ROWS (1u << 16)

// One block's row in a sparse group: its definitions, the group's values live into it and out of it, and those live into
// it not yet sent on to its predecessors.
typedef struct Tier1CfgLiveRow Tier1CfgLiveRow;
struct __attribute__((aligned(64))) Tier1CfgLiveRow
{
    __m512i def;
    __m512i in;
    __m512i out;
    __m512i pending;
};

// A sparse group's state, and tier1_cfg_live_sets' columns it counts into or fills.
typedef struct Tier1CfgSparse Tier1CfgSparse;
struct Tier1CfgSparse
{
    const Tier1CfgInput* input;
    const uint32_t* home;
    const uint32_t* dense_values;
    const uint32_t* blocks_of;
    const uint32_t* phi_offsets;
    const uint32_t* phi_sources;
    // The group's rows, in the order it touched their blocks, one a block at most: block b's is row_of[b] where stamps[b]
    // is the group's generation.
    Tier1CfgLiveRow* rows;
    uint32_t* row_blocks;
    uint32_t* row_of;
    uint32_t* stamps;
    // The blocks whose pending rows are nonzero, each once.
    uint32_t* work;
    uint32_t generation;
    uint32_t row_count;
    uint32_t peak_rows;
    uint64_t visits;
    uint32_t* in_offsets;
    uint32_t* out_offsets;
    uint8_t* continues;
    uint8_t* home_out;
    uint32_t* in_cursors;
    uint32_t* out_cursors;
    uint32_t* in_values;
    uint8_t* in_out;
    uint32_t* out_values;
};

static __m512i tier1_cfg_sparse_bit(uint32_t bit)
{
    return _mm512_maskz_set1_epi64((__mmask8)(1u << (bit >> 6)), (long long)(UINT64_C(1) << (bit & 63)));
}

static bool tier1_cfg_sparse_any(__m512i bits)
{
    return _mm512_test_epi64_mask(bits, bits) != 0;
}

// Block b's row in the current group, an empty one where the group hasn't touched the block yet.
static Tier1CfgLiveRow* tier1_cfg_sparse_row(Tier1CfgSparse* sparse, uint32_t block)
{
    if (sparse->stamps[block] != sparse->generation)
    {
        const uint32_t r = sparse->row_count;
        sparse->row_count += 1;
        sparse->stamps[block] = sparse->generation;
        sparse->row_of[block] = r;
        sparse->row_blocks[r] = block;
        sparse->rows[r] = (Tier1CfgLiveRow){
            .def = _mm512_setzero_si512(),
            .in = _mm512_setzero_si512(),
            .out = _mm512_setzero_si512(),
            .pending = _mm512_setzero_si512(),
        };
    }
    return sparse->rows + sparse->row_of[block];
}

// One group of tier1_cfg_live_sets, the dense ids [first, last), solved over the blocks its values touch alone: the
// least solution of the equations dataflow_liveness solves, IN[b] = USE[b] | (OUT[b] & ~DEF[b]) and OUT[b] the union of
// b's successors' IN, then OUT[b] |= the operands b passes. A row exists only for a value's home, its uses' blocks, the
// blocks passing it to a phi and those it is found live into; a block's newly live values go to each predecessor once,
// as one OR of 512 bits, and a predecessor whose IN grows waits for its turn. The order the blocks are taken in changes
// the work, not the solution, so the lists are those of the dense solve. Then the group's rows, as the dense rows are
// read: without `fill`, counted into in_offsets[b + 1] and out_offsets[b + 1], with `continues` narrowed and each value's
// home_out set; with it, stored at the cursors. False where a value is live into the entry or into its own home, which
// isn't SSA. Out of line: the dense groups' code stays as it was.
static __attribute__((noinline)) bool tier1_cfg_live_group_sparse(Tier1CfgSparse* sparse, uint32_t first, uint32_t last, bool fill)
{
    const Tier1CfgInput* const input = sparse->input;
    const uint32_t* const home = sparse->home;
    const uint32_t* const dense_values = sparse->dense_values;
    sparse->generation += 1;
    if (sparse->generation == 0)
    {
        memset(sparse->stamps, 0, (uint64_t)input->block_count * sizeof(uint32_t));
        sparse->generation = 1;
    }
    sparse->row_count = 0;
    for (uint32_t i = first; i < last; i += 1)
    {
        const uint32_t v = dense_values[i];
        const __m512i bit = tier1_cfg_sparse_bit(i - first);
        Tier1CfgLiveRow* defining = tier1_cfg_sparse_row(sparse, home[v]);
        defining->def = _mm512_or_si512(defining->def, bit);
        for (uint32_t u = input->use_offsets[v]; u < input->use_offsets[v + 1]; u += 1)
        {
            const uint32_t block = sparse->blocks_of != 0 ? sparse->blocks_of[input->use_positions[u]] : tier1_cfg_block_of(input, input->use_positions[u]);
            if (block != home[v])
            {
                Tier1CfgLiveRow* reading = tier1_cfg_sparse_row(sparse, block);
                reading->in = _mm512_or_si512(reading->in, bit);
            }
        }
        for (uint32_t k = sparse->phi_offsets[i]; k < sparse->phi_offsets[i + 1]; k += 1)
        {
            if (sparse->phi_sources[k] != home[v])
            {
                Tier1CfgLiveRow* passing = tier1_cfg_sparse_row(sparse, sparse->phi_sources[k]);
                passing->in = _mm512_or_si512(passing->in, bit);
            }
        }
    }
    uint32_t waiting = 0;
    for (uint32_t r = 0; r < sparse->row_count; r += 1)
    {
        sparse->rows[r].pending = sparse->rows[r].in;
        if (tier1_cfg_sparse_any(sparse->rows[r].in))
        {
            sparse->work[waiting] = sparse->row_blocks[r];
            waiting += 1;
        }
    }
    while (waiting != 0)
    {
        waiting -= 1;
        const uint32_t block = sparse->work[waiting];
        Tier1CfgLiveRow* row = sparse->rows + sparse->row_of[block];
        const __m512i delta = row->pending;
        row->pending = _mm512_setzero_si512();
        sparse->visits += fill ? 0 : 1;
        for (uint32_t p = input->predecessor_offsets[block]; p < input->predecessor_offsets[block + 1]; p += 1)
        {
            const uint32_t predecessor = input->predecessors[p];
            Tier1CfgLiveRow* before = tier1_cfg_sparse_row(sparse, predecessor);
            const __m512i added = _mm512_andnot_si512(before->out, delta);
            if (tier1_cfg_sparse_any(added))
            {
                before->out = _mm512_or_si512(before->out, added);
                const __m512i fresh = _mm512_andnot_si512(_mm512_or_si512(before->def, before->in), added);
                if (tier1_cfg_sparse_any(fresh))
                {
                    if (!tier1_cfg_sparse_any(before->pending))
                    {
                        sparse->work[waiting] = predecessor;
                        waiting += 1;
                    }
                    before->in = _mm512_or_si512(before->in, fresh);
                    before->pending = _mm512_or_si512(before->pending, fresh);
                }
            }
        }
    }
    // The same edge uses join OUT even where their defining block kills propagation to IN.
    bool valid = true;
    for (uint32_t i = first; i < last; i += 1)
    {
        const uint32_t v = dense_values[i];
        const __m512i bit = tier1_cfg_sparse_bit(i - first);
        for (uint32_t k = sparse->phi_offsets[i]; k < sparse->phi_offsets[i + 1]; k += 1)
        {
            Tier1CfgLiveRow* passing = tier1_cfg_sparse_row(sparse, sparse->phi_sources[k]);
            passing->out = _mm512_or_si512(passing->out, bit);
        }
        const Tier1CfgLiveRow* defining = sparse->rows + sparse->row_of[home[v]];
        const bool entry = sparse->stamps[0] == sparse->generation && tier1_cfg_sparse_any(_mm512_and_si512(sparse->rows[sparse->row_of[0]].in, bit));
        valid = valid && !entry && !tier1_cfg_sparse_any(_mm512_and_si512(defining->in, bit));
        sparse->home_out[v] = fill ? sparse->home_out[v] : tier1_cfg_sparse_any(_mm512_and_si512(defining->out, bit));
    }
    sparse->peak_rows = sparse->row_count > sparse->peak_rows ? sparse->row_count : sparse->peak_rows;
    for (uint32_t r = 0; valid && r < sparse->row_count; r += 1)
    {
        const Tier1CfgLiveRow* row = sparse->rows + r;
        const uint32_t b = sparse->row_blocks[r];
        if (!fill)
        {
            const bool after = b != 0 && sparse->stamps[b - 1] == sparse->generation;
            const __m512i previous_out = after ? sparse->rows[sparse->row_of[b - 1]].out : _mm512_setzero_si512();
            sparse->in_offsets[b + 1] += (uint32_t)_mm512_reduce_add_epi64(_mm512_popcnt_epi64(row->in));
            sparse->out_offsets[b + 1] += (uint32_t)_mm512_reduce_add_epi64(_mm512_popcnt_epi64(row->out));
            sparse->continues[b] = sparse->continues[b] && !tier1_cfg_sparse_any(_mm512_andnot_si512(previous_out, row->in));
        }
        else
        {
            uint64_t in[BUSTER_DATAFLOW_VECTOR_WORDS] __attribute__((aligned(64)));
            uint64_t out[BUSTER_DATAFLOW_VECTOR_WORDS] __attribute__((aligned(64)));
            _mm512_store_si512((void*)in, row->in);
            _mm512_store_si512((void*)out, row->out);
            for (uint32_t w = 0; w < BUSTER_DATAFLOW_VECTOR_WORDS; w += 1)
            {
                for (uint64_t bits = in[w]; bits != 0; bits &= bits - 1)
                {
                    const uint32_t bit = (uint32_t)__builtin_ctzll(bits);
                    sparse->in_values[sparse->in_cursors[b]] = dense_values[first + w * 64 + bit];
                    sparse->in_out[sparse->in_cursors[b]] = (out[w] >> bit) & 1;
                    sparse->in_cursors[b] += 1;
                }
                for (uint64_t bits = out[w]; bits != 0; bits &= bits - 1)
                {
                    sparse->out_values[sparse->out_cursors[b]] = dense_values[first + w * 64 + (uint32_t)__builtin_ctzll(bits)];
                    sparse->out_cursors[b] += 1;
                }
            }
        }
    }
    return valid;
}

// The global values' liveness in groups of BUSTER_DATAFLOW_VECTOR_BITS dense ids, each solved by dataflow_liveness in
// one vector row per block, so that its four matrices take blocks * 256 bytes however many values are global (#1384):
// a short-lived value used one block after its definition no longer widens every block's rows. Liveness is per value,
// so a group's rows are exactly its values' columns of one solve over all of them. A function of up to 512 global
// values is one group and one solve, as before. Each group's rows are counted per block, then filled into the
// block-major lists, ascending since the groups go in dense id order, which is value order; with more than one group,
// each is solved again for the fill rather than kept. A global phi operand joins its predecessor's use row unless that
// block is its home, and its predecessor's out row after the solve, even where it is (the USE |= P & ~D, OUT |= P of
// 1. above). A value live into the entry or into its own home is not SSA: INVALID. Past BUSTER_TIER1_CFG_SPARSE_ROWS,
// or with `force_sparse` (the tests'), every group is solved by tier1_cfg_live_group_sparse instead, with no dense rows,
// and *sparse says so. Failure restores the scratch arena.
static Tier1CfgError tier1_cfg_live_sets(const Tier1CfgInput* input, const uint32_t* home, const uint32_t* dense, const uint32_t* dense_values, uint32_t dense_count, const uint32_t* blocks_of, bool force_sparse, Arena* scratch, Tier1CfgLiveSets* live, uint64_t* iterations, uint64_t* matrix_bytes, uint8_t* sparse)
{
    const uint64_t mark = scratch->length;
    Tier1CfgError error = TIER1_CFG_CAPACITY;
    const uint32_t blocks = input->block_count;
    const uint32_t groups = (uint32_t)(((uint64_t)dense_count + BUSTER_DATAFLOW_VECTOR_BITS - 1) / BUSTER_DATAFLOW_VECTOR_BITS);
    const uint32_t width = dense_count < BUSTER_DATAFLOW_VECTOR_BITS ? dense_count : BUSTER_DATAFLOW_VECTOR_BITS;
    const bool sparse_groups = groups != 0 && (force_sparse || (groups > 1 && (uint64_t)blocks * groups > BUSTER_TIER1_CFG_SPARSE_ROWS));
    // Each dense id's phi occurrences, by their predecessors, counted then filled.
    uint32_t* phi_offsets = arena_push_array(scratch, (uint64_t)dense_count + 2, sizeof(uint32_t), _Alignof(uint32_t));
    bool ready = phi_offsets != 0;
    if (ready)
    {
        memset(phi_offsets, 0, ((uint64_t)dense_count + 2) * sizeof(uint32_t));
        for (uint32_t k = 0; k < input->phi_count; k += 1)
        {
            for (uint32_t o = input->phi_operand_offsets[k]; o < input->phi_operand_offsets[k + 1]; o += 1)
            {
                const uint32_t operand = input->phi_operands[o];
                if (operand != BUSTER_TIER1_CFG_NONE && dense[operand] != BUSTER_TIER1_CFG_NONE)
                {
                    phi_offsets[dense[operand] + 2] += 1;
                }
            }
        }
        for (uint32_t i = 0; i < dense_count; i += 1)
        {
            phi_offsets[i + 2] += phi_offsets[i + 1];
        }
    }
    uint32_t* phi_sources = ready ? arena_push_array(scratch, (uint64_t)phi_offsets[dense_count + 1] + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    ready = ready && phi_sources != 0;
    for (uint32_t b = 0; ready && b < blocks; b += 1)
    {
        const uint32_t first = input->predecessor_offsets[b];
        for (uint32_t k = input->phi_offsets[b]; k < input->phi_offsets[b + 1]; k += 1)
        {
            const uint32_t from = input->phi_operand_offsets[k];
            const uint32_t count = input->phi_operand_offsets[k + 1] - from;
            for (uint32_t j = 0; j < count; j += 1)
            {
                const uint32_t operand = input->phi_operands[from + j];
                if (operand != BUSTER_TIER1_CFG_NONE && dense[operand] != BUSTER_TIER1_CFG_NONE)
                {
                    phi_sources[phi_offsets[dense[operand] + 1]] = input->predecessors[first + j];
                    phi_offsets[dense[operand] + 1] += 1;
                }
            }
        }
    }
    // The fill advanced each id's start to the next's, so phi_offsets[i] .. phi_offsets[i + 1] is id i's.
    uint32_t* in_offsets = ready ? arena_push_array(scratch, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* out_offsets = ready ? arena_push_array(scratch, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* in_cursors = ready ? arena_push_array(scratch, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* out_cursors = ready ? arena_push_array(scratch, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint8_t* home_out = ready ? arena_push(scratch, (uint64_t)input->value_count + 1, 1) : 0;
    uint8_t* continues = ready ? arena_push(scratch, (uint64_t)blocks + 1, 1) : 0;
    Dataflow liveness = { 0 };
    Tier1CfgSparse solver = {
        .input = input,
        .home = home,
        .dense_values = dense_values,
        .blocks_of = blocks_of,
        .phi_offsets = phi_offsets,
        .phi_sources = phi_sources,
        .in_offsets = in_offsets,
        .out_offsets = out_offsets,
        .continues = continues,
        .home_out = home_out,
        .in_cursors = in_cursors,
        .out_cursors = out_cursors,
    };
    if (ready && sparse_groups)
    {
        solver.rows = arena_push_array(scratch, blocks, sizeof(Tier1CfgLiveRow), _Alignof(Tier1CfgLiveRow));
        solver.row_blocks = arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t));
        solver.row_of = arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t));
        solver.stamps = arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t));
        solver.work = arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t));
        ready = solver.rows != 0 && solver.row_blocks != 0 && solver.row_of != 0 && solver.stamps != 0 && solver.work != 0;
        if (ready)
        {
            memset(solver.stamps, 0, (uint64_t)blocks * sizeof(uint32_t));
        }
    }
    ready = ready && in_offsets != 0 && out_offsets != 0 && in_cursors != 0 && out_cursors != 0 && home_out != 0 && continues != 0 && (sparse_groups || dataflow_create(scratch, blocks, width, input->edge_count, &liveness));
    if (ready)
    {
        memset(in_offsets, 0, ((uint64_t)blocks + 1) * sizeof(uint32_t));
        memset(out_offsets, 0, ((uint64_t)blocks + 1) * sizeof(uint32_t));
        memset(home_out, 0, (uint64_t)input->value_count + 1);
        memset(continues, 1, (uint64_t)blocks + 1);
    }
    if (ready && !sparse_groups)
    {
        memcpy(liveness.successor_offsets, input->successor_offsets, ((uint64_t)blocks + 1) * sizeof(uint32_t));
        if (input->edge_count != 0)
        {
            memcpy(liveness.successors, input->successors, (uint64_t)input->edge_count * sizeof(uint32_t));
        }
        ready = dataflow_postorder(&liveness, scratch);
    }
    const uint64_t words = liveness.row_words;
    // Without a global value there are no rows: the count is the one sweep that changes nothing (dataflow_liveness).
    uint64_t sweeps = ready && groups == 0 ? dataflow_liveness(&liveness) : 0;
    uint32_t* in_values = 0;
    uint32_t* out_values = 0;
    uint8_t* in_out = 0;
    bool valid = true;
    for (uint32_t pass = 0; ready && valid && pass < 2; pass += 1)
    {
        if (pass == 1)
        {
            uint64_t in_run = 0;
            uint64_t out_run = 0;
            for (uint32_t b = 0; b < blocks; b += 1)
            {
                const uint64_t in_here = in_offsets[b + 1];
                const uint64_t out_here = out_offsets[b + 1];
                in_offsets[b] = (uint32_t)in_run;
                out_offsets[b] = (uint32_t)out_run;
                in_cursors[b] = (uint32_t)in_run;
                out_cursors[b] = (uint32_t)out_run;
                in_run += in_here;
                out_run += out_here;
                ready = ready && in_run <= UINT32_MAX && out_run <= UINT32_MAX;
            }
            if (ready)
            {
                in_offsets[blocks] = (uint32_t)in_run;
                out_offsets[blocks] = (uint32_t)out_run;
            }
            in_values = ready ? arena_push_array(scratch, in_run + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
            out_values = ready ? arena_push_array(scratch, out_run + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
            in_out = ready ? arena_push(scratch, in_run + 1, 1) : 0;
            ready = ready && in_values != 0 && out_values != 0 && in_out != 0;
            solver.in_values = in_values;
            solver.in_out = in_out;
            solver.out_values = out_values;
        }
        for (uint32_t g = 0; ready && valid && sparse_groups && g < groups; g += 1)
        {
            const uint32_t first = g * BUSTER_DATAFLOW_VECTOR_BITS;
            const uint32_t last = dense_count - first < BUSTER_DATAFLOW_VECTOR_BITS ? dense_count : first + BUSTER_DATAFLOW_VECTOR_BITS;
            valid = tier1_cfg_live_group_sparse(&solver, first, last, pass == 1);
        }
        for (uint32_t g = 0; ready && valid && !sparse_groups && g < groups; g += 1)
        {
            const uint32_t first = g * BUSTER_DATAFLOW_VECTOR_BITS;
            const uint32_t last = dense_count - first < BUSTER_DATAFLOW_VECTOR_BITS ? dense_count : first + BUSTER_DATAFLOW_VECTOR_BITS;
            if (pass == 0 || groups > 1)
            {
                tier1_cfg_live_seeds(input, home, dense_values, blocks_of, phi_offsets, phi_sources, first, last, &liveness, true);
                const uint64_t solved = dataflow_liveness(&liveness);
                sweeps += pass == 0 ? solved : 0;
                // The same edge uses join OUT even where their defining block kills propagation to IN.
                for (uint32_t i = first; i < last; i += 1)
                {
                    for (uint32_t k = phi_offsets[i]; k < phi_offsets[i + 1]; k += 1)
                    {
                        tier1_cfg_set(liveness.out + (uint64_t)phi_sources[k] * words, i - first);
                    }
                }
                // Only another solve, of the next group or of this one for the fill, reads the rows again.
                if (groups > 1)
                {
                    tier1_cfg_live_seeds(input, home, dense_values, blocks_of, phi_offsets, phi_sources, first, last, &liveness, false);
                }
            }
            for (uint32_t i = first; pass == 0 && i < last; i += 1)
            {
                const uint64_t* in_home = liveness.in + (uint64_t)home[dense_values[i]] * words;
                valid = valid && !tier1_cfg_bit(liveness.in, i - first) && !tier1_cfg_bit(in_home, i - first);
                home_out[dense_values[i]] = tier1_cfg_bit(liveness.out + (uint64_t)home[dense_values[i]] * words, i - first);
            }
            // A group's rows are one vector each (words is BUSTER_DATAFLOW_VECTOR_WORDS): counted a row at a time, with
            // whether the block's live-in values are live out of the block before, and filled from its nonzero words.
            __m512i previous_out = _mm512_setzero_si512();
            for (uint32_t b = 0; valid && b < blocks; b += 1)
            {
                const uint64_t* in = liveness.in + (uint64_t)b * BUSTER_DATAFLOW_VECTOR_WORDS;
                const uint64_t* out = liveness.out + (uint64_t)b * BUSTER_DATAFLOW_VECTOR_WORDS;
                const __m512i in_row = _mm512_load_si512(in);
                const __m512i out_row = _mm512_load_si512(out);
                if (pass == 0)
                {
                    in_offsets[b + 1] += (uint32_t)_mm512_reduce_add_epi64(_mm512_popcnt_epi64(in_row));
                    out_offsets[b + 1] += (uint32_t)_mm512_reduce_add_epi64(_mm512_popcnt_epi64(out_row));
                    continues[b] = continues[b] && _mm512_test_epi64_mask(_mm512_andnot_si512(previous_out, in_row), _mm512_set1_epi64(-1)) == 0;
                }
                previous_out = out_row;
                for (uint32_t words_in = pass == 1 ? _mm512_test_epi64_mask(in_row, in_row) : 0; words_in != 0; words_in &= words_in - 1)
                {
                    const uint32_t w = (uint32_t)__builtin_ctz(words_in);
                    for (uint64_t bits = in[w]; bits != 0; bits &= bits - 1)
                    {
                        const uint32_t bit = (uint32_t)__builtin_ctzll(bits);
                        in_values[in_cursors[b]] = dense_values[first + w * 64 + bit];
                        in_out[in_cursors[b]] = (out[w] >> bit) & 1;
                        in_cursors[b] += 1;
                    }
                }
                for (uint32_t words_out = pass == 1 ? _mm512_test_epi64_mask(out_row, out_row) : 0; words_out != 0; words_out &= words_out - 1)
                {
                    const uint32_t w = (uint32_t)__builtin_ctz(words_out);
                    for (uint64_t bits = out[w]; bits != 0; bits &= bits - 1)
                    {
                        out_values[out_cursors[b]] = dense_values[first + w * 64 + (uint32_t)__builtin_ctzll(bits)];
                        out_cursors[b] += 1;
                    }
                }
            }
        }
    }
    if (ready && valid)
    {
        *live = (Tier1CfgLiveSets){
            .in_offsets = in_offsets,
            .in_values = in_values,
            .out_offsets = out_offsets,
            .out_values = out_values,
            .in_out = in_out,
            .home_out = home_out,
            .continues = continues,
        };
        *iterations = sparse_groups ? solver.visits : sweeps;
        *matrix_bytes = sparse_groups ? (uint64_t)solver.peak_rows * sizeof(Tier1CfgLiveRow) : 4 * (uint64_t)blocks * words * sizeof(uint64_t);
        *sparse = sparse_groups;
        error = TIER1_CFG_OK;
    }
    else
    {
        error = ready ? TIER1_CFG_INVALID : TIER1_CFG_CAPACITY;
        arena_pop_to(scratch, mark);
    }
    return error;
}

// Whether `block` is among a value's blocks, list[begin .. end), ascending (tier1_cfg_prepare's).
static bool tier1_cfg_listed(const uint32_t* list, uint32_t begin, uint32_t end, uint32_t block)
{
    const uint32_t limit = end;
    while (begin < end)
    {
        const uint32_t middle = begin + (end - begin) / 2;
        const bool below = list[middle] < block;
        begin = below ? middle + 1 : begin;
        end = below ? end : middle;
    }
    return begin < limit && list[begin] == block;
}

// Locations at block boundaries, in the live lists' order, followed by each block's local phi tails at exits. The edge
// pass indexes exit_at/exit_stamp by original value, including locals. A cursor per value moves only forward: blocks
// are visited in layout order, and within a block the entry is at or before the exit. `ready` is false when the
// columns do not fit, and the edge pass then searches.
typedef struct Tier1CfgBoundaries Tier1CfgBoundaries;
struct Tier1CfgBoundaries
{
    const uint32_t* in_offsets;
    uint32_t* out_offsets;
    uint32_t* entry_locations;
    uint32_t* exit_locations;
    uint32_t* phi_locations;
    uint32_t* exit_at;
    uint32_t* exit_stamp;
    bool ready;
};

static uint32_t tier1_cfg_cursor_cover(const Tier1CfgAllocation* result, uint32_t* cursors, uint32_t* lasts, uint32_t value, uint32_t position)
{
    const uint32_t begin = result->value_interval_offsets[value];
    const uint32_t end = result->value_interval_offsets[value + 1];
    uint32_t interval = cursors[value];
    if (lasts[value] != BUSTER_TIER1_CFG_NONE && position < lasts[value])
    {
        interval = begin;
    }
    while (interval < end && result->intervals.ends[interval] <= position)
    {
        interval += 1;
    }
    cursors[value] = interval;
    lasts[value] = position;
    return interval < end && result->intervals.starts[interval] <= position ? interval : BUSTER_TIER1_CFG_NONE;
}

static uint32_t tier1_cfg_cursor_where(const Tier1CfgAllocation* result, uint32_t* cursors, uint32_t* lasts, uint32_t value, uint32_t position)
{
    const uint32_t interval = tier1_cfg_cursor_cover(result, cursors, lasts, value, position);
    uint32_t location = BUSTER_TIER1_CFG_NONE;
    uint8_t kind = 0;
    if (interval != BUSTER_TIER1_CFG_NONE && !tier1_cfg_interval_location(result, value, interval, position, &location, &kind))
    {
        location = BUSTER_TIER1_CFG_NONE;
    }
    (void)kind;
    return location;
}

static uint32_t tier1_cfg_cursor_entry(const Tier1CfgAllocation* result, uint32_t* cursors, uint32_t* lasts, uint32_t value, uint32_t entry)
{
    const uint32_t interval = tier1_cfg_cursor_cover(result, cursors, lasts, value, entry);
    uint32_t location = BUSTER_TIER1_CFG_NONE;
    if (interval != BUSTER_TIER1_CFG_NONE)
    {
        const uint32_t position = result->intervals.starts[interval] < entry ? entry - 1 : entry;
        uint8_t kind = 0;
        if (!tier1_cfg_interval_entry(result, value, interval, position, entry, &location, &kind))
        {
            location = BUSTER_TIER1_CFG_NONE;
        }
        (void)kind;
    }
    return location;
}

static Tier1CfgBoundaries tier1_cfg_boundaries(const Tier1CfgInput* input, const Tier1CfgAllocation* result, const Tier1CfgLiveSets* live, const uint8_t* edge_local, const uint32_t* defined_offsets, const uint32_t* defined, Arena* scratch)
{
    const uint64_t mark = scratch->length;
    const uint32_t blocks = input->block_count;
    const uint32_t values = input->value_count;
    Tier1CfgBoundaries bounds = { 0 };
    // Entries follow the live-in lists exactly; exits, the live-out lists and then the local tails.
    const uint32_t* in_offsets = live->in_offsets;
    uint32_t* out_offsets = arena_push_array(scratch, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t));
    uint32_t* cursors = arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t));
    uint32_t* lasts = arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t));
    bool ok = out_offsets != 0 && cursors != 0 && lasts != 0;
    const uint64_t in_run = in_offsets[blocks];
    uint64_t out_run = 0;
    for (uint32_t b = 0; ok && b < blocks; b += 1)
    {
        out_offsets[b] = (uint32_t)out_run;
        out_run += live->out_offsets[b + 1] - live->out_offsets[b];
        for (uint32_t x = defined_offsets[b]; x < defined_offsets[b + 1]; x += 1)
        {
            out_run += edge_local[defined[x]] != 0;
        }
        ok = out_run <= UINT32_MAX;
    }
    if (ok)
    {
        out_offsets[blocks] = (uint32_t)out_run;
    }
    uint32_t* entry_locations = ok ? arena_push_array(scratch, in_run + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* exit_locations = ok ? arena_push_array(scratch, out_run + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* phi_locations = ok ? arena_push_array(scratch, (uint64_t)input->phi_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* exit_at = ok ? arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* exit_stamp = ok ? arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    ok = ok && entry_locations != 0 && exit_locations != 0 && phi_locations != 0 && exit_at != 0 && exit_stamp != 0;
    if (ok)
    {
        memset(exit_stamp, 0, ((uint64_t)values + 1) * sizeof(uint32_t));
        for (uint32_t v = 0; v < values; v += 1)
        {
            cursors[v] = result->value_interval_offsets[v];
            lasts[v] = BUSTER_TIER1_CFG_NONE;
        }
        for (uint32_t b = 0; b < blocks; b += 1)
        {
            const uint32_t entry = input->block_starts[b];
            const uint32_t exit = input->block_starts[b + 1] - 1;
            for (uint32_t x = in_offsets[b]; x < in_offsets[b + 1]; x += 1)
            {
                entry_locations[x] = tier1_cfg_cursor_entry(result, cursors, lasts, live->in_values[x], entry);
            }
            for (uint32_t k = input->phi_offsets[b]; k < input->phi_offsets[b + 1]; k += 1)
            {
                phi_locations[k] = tier1_cfg_cursor_entry(result, cursors, lasts, input->phi_values[k], entry);
            }
            uint32_t rank = 0;
            for (uint32_t x = live->out_offsets[b]; x < live->out_offsets[b + 1]; x += 1)
            {
                exit_locations[out_offsets[b] + rank] = tier1_cfg_cursor_where(result, cursors, lasts, live->out_values[x], exit);
                rank += 1;
            }
            // Local tails follow the global exits. The cursors are per value, so this preserves each one's forward
            // sweep without changing the live-in and phi order in which edges stage their moves.
            for (uint32_t x = defined_offsets[b]; x < defined_offsets[b + 1]; x += 1)
            {
                const uint32_t v = defined[x];
                if (edge_local[v] != 0)
                {
                    exit_locations[out_offsets[b] + rank] = tier1_cfg_cursor_where(result, cursors, lasts, v, exit);
                    rank += 1;
                }
            }
        }
        bounds.in_offsets = in_offsets;
        bounds.out_offsets = out_offsets;
        bounds.entry_locations = entry_locations;
        bounds.exit_locations = exit_locations;
        bounds.phi_locations = phi_locations;
        bounds.exit_at = exit_at;
        bounds.exit_stamp = exit_stamp;
        bounds.ready = true;
    }
    else
    {
        arena_pop_to(scratch, mark);
        bounds = (Tier1CfgBoundaries){ 0 };
    }
    return bounds;
}

// The interval of the operand interval `i`'s tie names (tier1_cfg_ties, #2685), which ends where `i` starts at its
// value's definition, or BUSTER_TIER1_CFG_NONE where a tie doesn't hint it.
static uint32_t tier1_cfg_tied_operand(const Tier1CfgInput* input, const Tier1CfgPieces* pieces, uint32_t i)
{
    const uint32_t v = pieces->values[i];
    const uint32_t hint = pieces->hints[i];
    const uint32_t named = pieces->hint_intervals[i];
    const bool exit = named != BUSTER_TIER1_CFG_NONE && (named & BUSTER_TIER1_ALLOCATE_HINT_EXIT) != 0;
    const uint32_t taken = exit ? named & ~BUSTER_TIER1_ALLOCATE_HINT_EXIT : BUSTER_TIER1_CFG_NONE;
    const bool tied = input->ties != 0 && hint != BUSTER_TIER1_CFG_NONE && hint != v && (input->ties[2 * (uint64_t)v] == hint || input->ties[2 * (uint64_t)v + 1] == hint);
    const bool defined = taken != BUSTER_TIER1_CFG_NONE && pieces->starts[i] == input->definitions[v] && pieces->ends[taken] == pieces->starts[i] && pieces->values[taken] == hint;
    return tied && defined ? taken : BUSTER_TIER1_CFG_NONE;
}

// Whether interval i may take a call's argument register and avoid the others' (#2823): a general one, not a phi's
// (`phis`, whose edges place it), with no alternate, that nothing hints or a tie alone.
static bool tier1_cfg_argument_open(const Tier1CfgInput* input, const Tier1CfgPieces* pieces, const uint8_t* phis, uint32_t i)
{
    const bool unhinted = pieces->hints[i] == BUSTER_TIER1_CFG_NONE && pieces->hint_intervals[i] == BUSTER_TIER1_CFG_NONE;
    const bool tied = !unhinted && tier1_cfg_tied_operand(input, pieces, i) != BUSTER_TIER1_CFG_NONE;
    return (unhinted || tied) && pieces->alternates[i] == BUSTER_TIER1_CFG_NONE && phis[pieces->values[i]] == 0 && pieces->classes[i] == BUSTER_TIER1_ALLOCATE_GPR;
}

// A general interval whose last use is a call's register argument, and that nothing but that register and a tie hints
// (#2646: no other value, named interval or alternate), and not a phi's, whose edges place it, avoids the general registers the call reads its other
// arguments in (#2823), added to `crossed`. Where its own register is taken, by a value the call reads in another
// register or one that lives past it, it took the lowest free one, often the register another argument goes to while
// that argument sat in this one's: the call's parallel move then swapped them through the scratch register, three moves
// where one was owed. Lua's luaT_callorderiTM calls put the constant for rcx in rsi while the value for rsi sat in rcx. A
// register it avoids stays its last choice (Tier1AllocationInput.avoided_registers), and a hinted interval keeps its
// hint.
//
// A two-address result takes its dying operand's register (#2685), so the register and the avoided ones go back along
// the ties to the operand's interval where nothing else hints that one, and to its own tied operand's: lua_settable's
// `L->top - 2` for rdx and `L->top - 1` for rcx, each a load then an add, loaded each into the other's register. Only
// where the chain starts at a definition nothing hints: one whose first tie names an operand that can't follow (a value
// live past it, or one hinted elsewhere) keeps its ties instead, as rebuildPage's copy of sz into rdx does, which would
// otherwise leave rsi for another register and move there.
//
// Each position's registers are one pass over the uses, scattered into a column on `scratch`, and each interval reads
// its end's. Scalar: the scatter's positions collide (a call's arguments share one), and the walks back are chains, one
// or two ties long. False where `scratch` is short; it ends as it began.
static bool tier1_cfg_argument_avoidance(const Tier1CfgInput* input, const Tier1CfgPieces* pieces, uint8_t* register_hints, uint32_t count, Arena* scratch, uint32_t* crossed)
{
    const uint64_t mark = scratch->length;
    uint32_t* read = arena_push_array(scratch, (uint64_t)input->position_count + 1, sizeof(uint32_t), _Alignof(uint32_t));
    uint8_t* phis = read != 0 ? arena_push(scratch, (uint64_t)input->value_count + 1, 1) : 0;
    if (phis != 0)
    {
        memset(read, 0, ((uint64_t)input->position_count + 1) * sizeof(uint32_t));
        memset(phis, 0, (uint64_t)input->value_count + 1);
        for (uint32_t k = 0; k < input->phi_count; k += 1)
        {
            phis[input->phi_values[k]] = 1;
        }
        for (uint32_t v = 0; v < input->value_count; v += 1)
        {
            const bool general = input->classes[v] == BUSTER_TIER1_ALLOCATE_GPR;
            for (uint32_t u = input->use_offsets[v]; general && u < input->use_offsets[v + 1]; u += 1)
            {
                const uint8_t reg = input->use_registers[u];
                read[input->use_positions[u]] |= reg < 32 ? 1u << reg : 0;
            }
        }
        for (uint32_t i = 0; i < count; i += 1)
        {
            const uint8_t reg = register_hints[i];
            const bool argument = reg < 32 && tier1_cfg_argument_open(input, pieces, phis, i) && pieces->ends[i] != 0;
            // The chain back along the ties, through operands with no register hint of their own (one step each), to its
            // root: a definition nothing hints. A chain that stops at a tie it can't follow, an operand live on or hinted
            // elsewhere, is left to its ties, which avoiding the registers would break.
            uint32_t root = i;
            uint32_t operand = argument ? tier1_cfg_tied_operand(input, pieces, i) : BUSTER_TIER1_CFG_NONE;
            for (uint32_t steps = 0; operand != BUSTER_TIER1_CFG_NONE && steps < count; steps += 1)
            {
                const bool open = register_hints[operand] == UINT8_MAX && tier1_cfg_argument_open(input, pieces, phis, operand);
                root = open ? operand : root;
                operand = open ? tier1_cfg_tied_operand(input, pieces, operand) : BUSTER_TIER1_CFG_NONE;
            }
            const bool rooted = argument && tier1_cfg_tied_operand(input, pieces, root) == BUSTER_TIER1_CFG_NONE;
            const uint32_t avoided = rooted ? read[pieces->ends[i] - 1] & ~(1u << reg) : 0;
            uint32_t member = rooted ? i : BUSTER_TIER1_CFG_NONE;
            for (uint32_t steps = 0; member != BUSTER_TIER1_CFG_NONE && steps < count; steps += 1)
            {
                crossed[member] |= avoided;
                register_hints[member] = reg;
                member = member != root ? tier1_cfg_tied_operand(input, pieces, member) : BUSTER_TIER1_CFG_NONE;
            }
        }
    }
    arena_pop_to(scratch, mark);
    return phis != 0;
}

// The general registers each of `count` intervals avoids (Tier1CfgInput.sequences, #2767), into `crossed`: those of the
// fixed sequences that a range of its value's phi web lives across (at positions after the range's start and before its
// end), but those a sequence leaves to its reader where the range is the reader's (a shift's count in cl); 0 for another
// class's interval. A whole web avoids them: a value that took them in its other ranges would move out of them on the
// way into one that crosses a sequence (Lua's divisor did, on the edge into its division), or a range of it would take
// another register from a block the sequence never runs in, which its later ranges follow by their hints
// (sqlite3BtreeIndexMoveto's pRes, into its hot loop); and a phi in other registers than its operands moves on its edges.
// Each register some sequence writes has a prefix count over the sequences that write it, and each position the count of
// the sequences before it, both on `scratch`: a range's sequences are those from the count past its start to the count at
// its end, two loads, and it lives across one writing a register where that register's counts at those bounds differ,
// so a range over a long run of sequences costs as little as a short one. Each value's readings, the sequences it is the reader of, are a list
// in sequence order, where two more halvings find a range's own among its sequences, which its counts then leave out:
// each reading lies inside at most one range of its value. The webs are the phis' and their operands' union, found with
// halving paths. False where `scratch` is short; it ends as it began.
static bool tier1_cfg_crossed(const Tier1CfgInput* input, const uint32_t* starts, const uint32_t* ends, const uint32_t* values, const uint8_t* classes, uint32_t count, Arena* scratch, uint32_t* crossed)
{
    const uint64_t saved = scratch->length;
    const uint32_t sequences = input->sequence_count;
    const uint32_t* readers = input->sequence_readers;
    uint32_t written = 0;
    for (uint32_t k = 0; k < sequences; k += 1)
    {
        written |= input->sequence_registers[k];
    }
    const uint32_t kinds = (uint32_t)__builtin_popcount(written);
    uint32_t* prefix = arena_push_array(scratch, (uint64_t)kinds * (sequences + 1) + 1, sizeof(uint32_t), _Alignof(uint32_t));
    uint32_t* before = prefix != 0 ? arena_push_array(scratch, (uint64_t)input->position_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* reader_offsets = before != 0 && readers != 0 ? arena_push_array(scratch, (uint64_t)input->value_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* readings = reader_offsets != 0 ? arena_push_array(scratch, (uint64_t)sequences + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    // Each value's web's root, then each root's registers.
    uint32_t* webs = before != 0 ? arena_push_array(scratch, (uint64_t)input->value_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* web_masks = webs != 0 ? arena_push_array(scratch, (uint64_t)input->value_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    const bool ready = web_masks != 0 && (readers == 0 || readings != 0);
    // Past the values, a mask that no sequence's missing operand or result is read from.
    for (uint32_t v = 0; ready && v <= input->value_count; v += 1)
    {
        webs[v] = v;
        web_masks[v] = 0;
    }
    for (uint32_t k = 0; ready && k < input->phi_count; k += 1)
    {
        uint32_t a = input->phi_values[k];
        while (webs[a] != a)
        {
            webs[a] = webs[webs[a]];
            a = webs[a];
        }
        for (uint32_t o = input->phi_operand_offsets[k]; o < input->phi_operand_offsets[k + 1]; o += 1)
        {
            uint32_t b = input->phi_operands[o];
            while (b != BUSTER_TIER1_CFG_NONE && webs[b] != b)
            {
                webs[b] = webs[webs[b]];
                b = webs[b];
            }
            if (b != BUSTER_TIER1_CFG_NONE && b != a)
            {
                webs[b] = a;
            }
        }
    }
    // Every value straight to its root, so that each range finds its web's registers in one load.
    for (uint32_t v = 0; ready && v < input->value_count; v += 1)
    {
        uint32_t root = v;
        while (webs[root] != root)
        {
            webs[root] = webs[webs[root]];
            root = webs[root];
        }
        webs[v] = root;
    }
    // The sequences before each position: k up to and including the k-th sequence's position.
    uint32_t q = 0;
    for (uint32_t k = 0; ready && k < sequences; k += 1)
    {
        for (; q <= input->sequences[k]; q += 1)
        {
            before[q] = k;
        }
    }
    for (; ready && q <= input->position_count; q += 1)
    {
        before[q] = sequences;
    }
    uint32_t row = 0;
    for (uint32_t left = ready ? written : 0; left != 0; left &= left - 1)
    {
        const uint32_t r = (uint32_t)__builtin_ctz(left);
        uint32_t* counts = prefix + (uint64_t)row * (sequences + 1);
        counts[0] = 0;
        for (uint32_t k = 0; k < sequences; k += 1)
        {
            counts[k + 1] = counts[k] + ((input->sequence_registers[k] >> r) & 1);
        }
        row += 1;
    }
    if (ready && readers != 0)
    {
        // Counted by value, then each value's start, then filled in sequence order, which is position order.
        memset(reader_offsets, 0, ((uint64_t)input->value_count + 1) * sizeof(uint32_t));
        for (uint32_t k = 0; k < sequences; k += 1)
        {
            reader_offsets[readers[k] != BUSTER_TIER1_CFG_NONE ? readers[k] + 1 : 0] += readers[k] != BUSTER_TIER1_CFG_NONE;
        }
        for (uint32_t v = 0; v < input->value_count; v += 1)
        {
            reader_offsets[v + 1] += reader_offsets[v];
        }
        for (uint32_t k = 0; k < sequences; k += 1)
        {
            if (readers[k] != BUSTER_TIER1_CFG_NONE)
            {
                readings[reader_offsets[readers[k]]] = k;
                reader_offsets[readers[k]] += 1;
            }
        }
        // The fill advanced each value's start to the next one's: shift them back.
        for (uint32_t v = input->value_count; v > 0; v -= 1)
        {
            reader_offsets[v] = reader_offsets[v - 1];
        }
        reader_offsets[0] = 0;
    }
    for (uint32_t i = 0; ready && i < count; i += 1)
    {
        // The first sequence past the start, and the first at or past the end: a range ends past its start.
        const bool general = classes[i] == BUSTER_TIER1_ALLOCATE_GPR;
        const uint32_t low = general ? before[starts[i] + 1] : 0;
        const uint32_t past = general ? before[ends[i]] : 0;
        // The interval's own readings among them: its value's, from the first past its start to the first at its end.
        const bool inside = low < past;
        uint32_t first = inside && readers != 0 ? reader_offsets[values[i]] : 0;
        uint32_t last = inside && readers != 0 ? reader_offsets[values[i] + 1] : 0;
        while (first < last)
        {
            const uint32_t middle = first + (last - first) / 2;
            first = readings[middle] < low ? middle + 1 : first;
            last = readings[middle] < low ? last : middle;
        }
        uint32_t through = first;
        last = inside && readers != 0 ? reader_offsets[values[i] + 1] : 0;
        while (through < last)
        {
            const uint32_t middle = through + (last - through) / 2;
            through = readings[middle] < past ? middle + 1 : through;
            last = readings[middle] < past ? last : middle;
        }
        uint32_t mask = 0;
        row = 0;
        for (uint32_t left = inside ? written : 0; left != 0; left &= left - 1)
        {
            const uint32_t r = (uint32_t)__builtin_ctz(left);
            const uint32_t* counts = prefix + (uint64_t)row * (sequences + 1);
            uint32_t writing = counts[past] - counts[low];
            for (uint32_t e = first; e < through; e += 1)
            {
                writing -= (input->sequence_registers[readings[e]] >> r) & 1;
            }
            mask |= writing != 0 ? 1u << r : 0;
            row += 1;
        }
        web_masks[webs[values[i]]] |= mask;
    }
    // The operands and results that avoid their sequences' registers, and their webs with them.
    for (uint32_t k = 0; ready && k < sequences; k += 1)
    {
        const uint32_t operand = input->sequence_operands != 0 ? input->sequence_operands[k] : BUSTER_TIER1_CFG_NONE;
        const uint32_t result = input->sequence_results != 0 ? input->sequence_results[k] : BUSTER_TIER1_CFG_NONE;
        web_masks[operand != BUSTER_TIER1_CFG_NONE ? webs[operand] : input->value_count] |= input->sequence_registers[k];
        web_masks[result != BUSTER_TIER1_CFG_NONE ? webs[result] : input->value_count] |= input->sequence_registers[k];
    }
    for (uint32_t i = 0; ready && i < count; i += 1)
    {
        crossed[i] = classes[i] == BUSTER_TIER1_ALLOCATE_GPR ? web_masks[webs[values[i]]] : 0;
    }
    arena_pop_to(scratch, saved);
    return ready;
}

// What tier1_cfg_prepare leaves for tier1_cfg_assign and tier1_cfg_finish (#2538): the intervals, in the output arena
// as a result's are, and on the scratch arena the working state the two read, which tier1_cfg_release gives back. The
// intervals don't depend on the registers a value may take where the input has no fixed range, so one preparation serves
// every problem over the same values that tier1_cfg_column describes. The arenas' lengths at the preparation's start,
// which a failure of the three restores.
typedef struct Tier1CfgPrepared Tier1CfgPrepared;
struct Tier1CfgPrepared
{
    // The intervals and each value's run of them, the position column and liveness's counts; intervals.allowed_registers
    // is the input's own problem's column, the one the interval builder wrote.
    Tier1CfgAllocation candidate;
    // Each block's global values live into it and out of it (tier1_cfg_live_sets).
    Tier1CfgLiveSets live;
    // Excluded phi operands live through their home's exit. Reuse the definitions' home CSR for their boundaries.
    uint8_t* edge_local;
    uint32_t* defined_offsets;
    uint32_t* defined;
    uint32_t* edge_ordinals;
    // Each block's entry state's size, for the edges' moves.
    uint32_t* entering;
    // The splits: each piece of a range after the first in its block, by the position it starts at and its value.
    uint32_t* split_positions;
    uint32_t* split_values;
    uint32_t splits;
    uint64_t output_saved;
    uint64_t scratch_saved;
};

// Validation, homes and dense values, hints, liveness, block lists and the intervals (1. and 2. above), for `input`'s
// problem, the liveness's groups sparse where `force_sparse` says (the tests') or past BUSTER_TIER1_CFG_SPARSE_ROWS.
// Failure restores both arenas.
static Tier1CfgError tier1_cfg_prepare_path(const Tier1CfgInput* input, Arena* output, Arena* scratch, Tier1CfgPrepared* prepared, bool force_sparse)
{
    Tier1CfgError error = TIER1_CFG_INVALID;
    const uint64_t output_saved = output != 0 ? output->length : 0;
    const uint64_t scratch_saved = scratch != 0 ? scratch->length : 0;
    Tier1CfgAllocation candidate = { 0 };
    const bool arguments = input != 0 && output != 0 && scratch != 0 && output != scratch && prepared != 0;
    // The position-to-block column, which validation fills and reads (#1399), retained for emission; past its bound, or
    // where the output has no room, every reader searches block_starts instead.
    uint32_t* filled = arguments && input->position_count <= BUSTER_TIER1_CFG_POSITION_BLOCKS ? arena_push_array(output, input->position_count, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    if (arguments && tier1_cfg_input_valid_into(input, scratch, filled))
    {
        error = TIER1_CFG_CAPACITY;
        const uint32_t blocks = input->block_count;
        const uint32_t values = input->value_count;
        // Borrowed immutable columns; all preparation stores go to disjoint new arena storage.
        const uint32_t* const phi_offsets = input->phi_offsets;
        const uint32_t* const phi_operand_offsets = input->phi_operand_offsets;
        const uint32_t* const phi_operands = input->phi_operands;
        const uint32_t* const predecessor_offsets = input->predecessor_offsets;
        const uint32_t* const predecessors = input->predecessors;
        // Each value's definition block, and whether it is used outside it (dense ids, ascending value order).
        uint32_t* home = arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t));
        uint32_t* dense = arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t));
        uint32_t* dense_values = arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t));
        uint8_t* edge_local = arena_push(scratch, (uint64_t)values + 1, 1);
        bool ready = home != 0 && dense != 0 && dense_values != 0 && edge_local != 0;
        const uint32_t* blocks_of = filled;
        candidate.position_blocks = filled;
        uint32_t dense_count = 0;
        for (uint32_t v = 0; ready && v < values; v += 1)
        {
            home[v] = blocks_of != 0 ? blocks_of[input->definitions[v]] : tier1_cfg_block_of(input, input->definitions[v]);
            dense[v] = BUSTER_TIER1_CFG_NONE;
            edge_local[v] = 0;
        }
        // A phi reads an operand in its predecessor, not at the successor's entry. Inspect every occurrence: a
        // later remote one makes a value global even when earlier occurrences only passed it from its home.
        for (uint32_t b = 0; ready && b < blocks; b += 1)
        {
            const uint32_t first = predecessor_offsets[b];
            const uint32_t phi_end = phi_offsets[b + 1];
            for (uint32_t k = phi_offsets[b]; k < phi_end; k += 1)
            {
                const uint32_t from = phi_operand_offsets[k];
                const uint32_t count = phi_operand_offsets[k + 1] - from;
                for (uint32_t j = 0; j < count; j += 1)
                {
                    const uint32_t operand = phi_operands[from + j];
                    if (operand != BUSTER_TIER1_CFG_NONE)
                    {
                        if (home[operand] == predecessors[first + j])
                        {
                            edge_local[operand] = 1;
                        }
                        else
                        {
                            dense[operand] = 0;
                        }
                    }
                }
            }
        }
        for (uint32_t v = 0; ready && v < values; v += 1)
        {
            for (uint32_t u = input->use_offsets[v]; dense[v] == BUSTER_TIER1_CFG_NONE && u < input->use_offsets[v + 1]; u += 1)
            {
                const uint32_t block = blocks_of != 0 ? blocks_of[input->use_positions[u]] : tier1_cfg_block_of(input, input->use_positions[u]);
                dense[v] = block != home[v] ? 0 : BUSTER_TIER1_CFG_NONE;
            }
        }
        for (uint32_t v = 0; ready && v < values; v += 1)
        {
            if (dense[v] != BUSTER_TIER1_CFG_NONE)
            {
                dense[v] = dense_count;
                dense_values[dense_count] = v;
                dense_count += 1;
                edge_local[v] = 0;
            }
            candidate.edge_local_values += edge_local[v] != 0;
        }
        uint32_t* edge_ordinals = 0;
        ready = ready && (input->phi_count == 0 || tier1_cfg_edge_ordinals(input, scratch, &edge_ordinals));
        // Each block's anchor and chosen predecessor (#2553, tier1_cfg_anchors).
        uint32_t* anchors = ready ? arena_push_array(scratch, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint32_t* chosen = ready ? arena_push_array(scratch, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        ready = ready && anchors != 0 && chosen != 0 && tier1_cfg_anchors(input, output, scratch, anchors, chosen);
        // Each phi's hint: its operand from its block's chosen predecessor, or else from its first predecessor.
        uint32_t* phi_hints = ready ? arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        ready = ready && phi_hints != 0;
        if (ready)
        {
            memset(phi_hints, 0xff, ((uint64_t)values + 1) * sizeof(uint32_t));
        }
        for (uint32_t b = 0; ready && b < blocks; b += 1)
        {
            const uint32_t nearest = chosen[b] != BUSTER_TIER1_CFG_NONE ? chosen[b] : 0;
            const uint32_t predecessors = input->predecessor_offsets[b + 1] - input->predecessor_offsets[b];
            for (uint32_t k = input->phi_offsets[b]; k < input->phi_offsets[b + 1]; k += 1)
            {
                // An undefined operand hints nothing: then the first defined one, if any.
                uint32_t hint = input->phi_operands[input->phi_operand_offsets[k] + nearest];
                for (uint32_t j = 0; hint == BUSTER_TIER1_CFG_NONE && j < predecessors; j += 1)
                {
                    hint = input->phi_operands[input->phi_operand_offsets[k] + j];
                }
                phi_hints[input->phi_values[k]] = hint;
            }
        }
        // And a value a phi takes along an edge, hinted to the phi where nothing else hints it: along a back edge, the
        // phi has its register by then, from its definition, or (a loop's header laid out after its body, as a
        // dispatch loop's join is) from its ranges in the body's blocks before. Where the operand takes it, the edge
        // moves nothing for it; where the phi has no register yet, the hint goes on along the phis
        // (tier1_cfg_operand_targets, #2553), for which this pass notes each value's first phi that takes it (`ups`)
        // and whether it is a phi.
        uint32_t* ups = ready ? arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint8_t* phis = ready ? arena_push(scratch, (uint64_t)values + 1, 1) : 0;
        ready = ready && ups != 0 && phis != 0;
        if (ready)
        {
            memset(ups, 0xff, ((uint64_t)values + 1) * sizeof(uint32_t));
            memset(phis, 0, (uint64_t)values + 1);
        }
        for (uint32_t b = 0; ready && b < blocks; b += 1)
        {
            for (uint32_t k = input->phi_offsets[b]; k < input->phi_offsets[b + 1]; k += 1)
            {
                const uint32_t phi = input->phi_values[k];
                phis[phi] = 1;
                for (uint32_t o = input->phi_operand_offsets[k]; o < input->phi_operand_offsets[k + 1]; o += 1)
                {
                    const uint32_t operand = input->phi_operands[o];
                    if (operand != BUSTER_TIER1_CFG_NONE)
                    {
                        phi_hints[operand] = phi_hints[operand] == BUSTER_TIER1_CFG_NONE ? phi : phi_hints[operand];
                        ups[operand] = ups[operand] == BUSTER_TIER1_CFG_NONE && operand != phi ? phi : ups[operand];
                    }
                }
            }
        }
        Tier1CfgLiveSets live = { 0 };
        if (ready)
        {
            const Tier1CfgError solved = tier1_cfg_live_sets(input, home, dense, dense_values, dense_count, blocks_of, force_sparse, scratch, &live, &candidate.liveness_iterations, &candidate.liveness_bytes, &candidate.sparse_liveness);
            ready = solved == TIER1_CFG_OK;
            error = solved == TIER1_CFG_INVALID ? TIER1_CFG_INVALID : error;
            candidate.cross_block_values = dense_count;
            candidate.live_entries = ready ? (uint64_t)live.in_offsets[blocks] + live.out_offsets[blocks] : 0;
        }
        // Blocks whose entry state continues from their layout predecessor (see 2. above), and each block's entry
        // state's size, for the edges' moves.
        uint8_t* merges = ready ? arena_push(scratch, blocks, 1) : 0;
        uint32_t* entering = ready ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        ready = ready && merges != 0 && entering != 0;
        for (uint32_t b = 0; ready && b < blocks; b += 1)
        {
            merges[b] = b != 0 && input->phi_offsets[b] == input->phi_offsets[b + 1] && live.continues[b] != 0;
            entering[b] = input->phi_offsets[b + 1] - input->phi_offsets[b] + live.in_offsets[b + 1] - live.in_offsets[b];
        }
        // Each block's first successor in layout; and, for a block no earlier block reaches (a dispatch loop's handler,
        // its join laid out after them), the first of its predecessors' successors, a sibling whose entry it takes.
        // The join, in turn, takes for its phis their places at its first successor's entry, which comes before it.
        // A handler an earlier block reaches too (Lua's OP_TFORCALL, which OP_TFORPREP's `goto` enters) takes the
        // sibling of the multiway branch that reaches it (`dispatchers`, the branch's index among its predecessors): every
        // dispatch enters it, and the earlier block's edge moves its values once per loop (#2782).
        uint32_t* firsts = ready ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint32_t* siblings = ready ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint32_t* dispatchers = ready ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        // Per block, the interval the value being built has at its entry, where entry_stamps says it is that value's; and the
        // one it has at its exit, where it is live out of the block (#2553).
        uint32_t* entry_pieces = ready ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint32_t* entry_stamps = ready ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint32_t* exit_pieces = ready ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint32_t* exit_stamps = ready ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        ready = ready && firsts != 0 && siblings != 0 && dispatchers != 0 && entry_pieces != 0 && entry_stamps != 0 && exit_pieces != 0 && exit_stamps != 0;
        for (uint32_t b = 0; ready && b < blocks; b += 1)
        {
            uint32_t first = BUSTER_TIER1_CFG_NONE;
            for (uint32_t s = input->successor_offsets[b]; s < input->successor_offsets[b + 1]; s += 1)
            {
                first = input->successors[s] < first ? input->successors[s] : first;
            }
            firsts[b] = first;
        }
        for (uint32_t b = 0; ready && b < blocks; b += 1)
        {
            bool reached = false;
            uint32_t sibling = BUSTER_TIER1_CFG_NONE;
            uint32_t dispatcher = BUSTER_TIER1_CFG_NONE;
            for (uint32_t p = input->predecessor_offsets[b]; p < input->predecessor_offsets[b + 1]; p += 1)
            {
                const uint32_t predecessor = input->predecessors[p];
                const bool multiway = input->successor_offsets[predecessor + 1] - input->successor_offsets[predecessor] >= BUSTER_TIER1_CFG_MULTIWAY;
                reached |= predecessor < b;
                sibling = firsts[predecessor] < b && firsts[predecessor] < sibling ? firsts[predecessor] : sibling;
                dispatcher = dispatcher == BUSTER_TIER1_CFG_NONE && multiway && predecessor > b && firsts[predecessor] < b ? p - input->predecessor_offsets[b] : dispatcher;
            }
            const uint32_t dispatched = dispatcher != BUSTER_TIER1_CFG_NONE ? firsts[input->predecessors[input->predecessor_offsets[b] + dispatcher]] : BUSTER_TIER1_CFG_NONE;
            siblings[b] = reached ? BUSTER_TIER1_CFG_NONE : sibling;
            dispatchers[b] = reached && dispatched != BUSTER_TIER1_CFG_NONE ? dispatcher : BUSTER_TIER1_CFG_NONE;
        }
        // Each value's blocks, ascending: its definition's and those it is live into. Counted per value, with the values
        // each block defines, then filled block by block.
        uint32_t* list_offsets = ready ? arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint32_t* defined_offsets = ready ? arena_push_array(scratch, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint32_t* defined = ready ? arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint32_t* cursors = ready ? arena_push_array(scratch, (uint64_t)(values > blocks ? values : blocks) + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        ready = ready && list_offsets != 0 && defined_offsets != 0 && defined != 0 && cursors != 0;
        if (ready)
        {
            memset(list_offsets, 0, ((uint64_t)values + 1) * sizeof(uint32_t));
            memset(defined_offsets, 0, ((uint64_t)blocks + 1) * sizeof(uint32_t));
            for (uint32_t v = 0; v < values; v += 1)
            {
                list_offsets[v + 1] += 1;
                defined_offsets[home[v] + 1] += 1;
            }
            for (uint32_t x = 0; x < live.in_offsets[blocks]; x += 1)
            {
                list_offsets[live.in_values[x] + 1] += 1;
            }
            for (uint32_t v = 0; v < values; v += 1)
            {
                list_offsets[v + 1] += list_offsets[v];
            }
            for (uint32_t b = 0; b < blocks; b += 1)
            {
                defined_offsets[b + 1] += defined_offsets[b];
                cursors[b] = defined_offsets[b];
            }
            for (uint32_t v = 0; v < values; v += 1)
            {
                defined[cursors[home[v]]] = v;
                cursors[home[v]] += 1;
            }
        }
        // And whether the value is live out of each of its blocks, for a global value (tier1_cfg_live_sets' flags).
        uint32_t* list = ready ? arena_push_array(scratch, (uint64_t)list_offsets[values] + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint8_t* list_out = ready ? arena_push(scratch, (uint64_t)list_offsets[values] + 1, 1) : 0;
        ready = ready && list != 0 && list_out != 0;
        if (ready)
        {
            for (uint32_t v = 0; v < values; v += 1)
            {
                cursors[v] = list_offsets[v];
            }
            for (uint32_t b = 0; b < blocks; b += 1)
            {
                for (uint32_t x = defined_offsets[b]; x < defined_offsets[b + 1]; x += 1)
                {
                    const uint32_t v = defined[x];
                    list[cursors[v]] = b;
                    list_out[cursors[v]] = live.home_out[v];
                    cursors[v] += 1;
                }
                for (uint32_t x = live.in_offsets[b]; x < live.in_offsets[b + 1]; x += 1)
                {
                    const uint32_t v = live.in_values[x];
                    list[cursors[v]] = b;
                    list_out[cursors[v]] = live.in_out[x];
                    cursors[v] += 1;
                }
            }
        }
        // Fixed ranges by start, counted per position then filled: a value's range is cut around each one of its
        // class that blocks every register the value may take (2. above), and a block whose start one covers doesn't
        // continue its predecessor's ranges.
        const uint32_t fixed_count = input->fixed.count;
        uint32_t* fixed_offsets = ready ? arena_push_array(scratch, (uint64_t)input->position_count + 2, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        uint32_t* fixed_sorted = ready ? arena_push_array(scratch, (uint64_t)fixed_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        ready = ready && fixed_offsets != 0 && fixed_sorted != 0;
        uint32_t longest = 1;
        if (ready)
        {
            memset(fixed_offsets, 0, ((uint64_t)input->position_count + 2) * sizeof(uint32_t));
            for (uint32_t r = 0; r < fixed_count; r += 1)
            {
                const uint32_t length = input->fixed.ends[r] - input->fixed.starts[r];
                fixed_offsets[input->fixed.starts[r] + 1] += 1;
                longest = length > longest ? length : longest;
            }
            for (uint32_t q = 0; q <= input->position_count; q += 1)
            {
                fixed_offsets[q + 1] += fixed_offsets[q];
            }
            for (uint32_t r = 0; r < fixed_count; r += 1)
            {
                fixed_sorted[fixed_offsets[input->fixed.starts[r]]] = r;
                fixed_offsets[input->fixed.starts[r]] += 1;
            }
            // The fill advanced each start to the next's: shift them back.
            for (uint32_t q = input->position_count + 1; q > 0; q -= 1)
            {
                fixed_offsets[q] = fixed_offsets[q - 1];
            }
            fixed_offsets[0] = 0;
            for (uint32_t b = 1; b < blocks; b += 1)
            {
                const uint32_t entry = input->block_starts[b];
                const uint32_t low = entry >= longest ? entry - longest + 1 : 0;
                for (uint32_t k = fixed_offsets[low]; merges[b] && k < fixed_offsets[entry + 1]; k += 1)
                {
                    merges[b] = input->fixed.ends[fixed_sorted[k]] <= entry;
                }
            }
        }
        // Per block, the block whose entry ranges give the ranges live out of it their continuations (#2774), or none: its
        // first successor in layout where that comes no later than it, else the block that successor's entry takes its
        // opening from (`joined` below), where that comes no later than it; none where the first successor is the next
        // block in layout and merges, since a range live into it goes on into it. BUSTER_TIER1_CFG_LATER marks the second
        // kind, whose value must enter that first successor. Most blocks have none, so a range checks one word.
        uint32_t* continued = ready ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        ready = ready && continued != 0;
        for (uint32_t b = 0; ready && b < blocks; b += 1)
        {
            const uint32_t next = firsts[b];
            const bool later = next != BUSTER_TIER1_CFG_NONE && next > b;
            const uint32_t model = !later ? BUSTER_TIER1_CFG_NONE : siblings[next] != BUSTER_TIER1_CFG_NONE ? siblings[next] : firsts[next] < next ? firsts[next] : BUSTER_TIER1_CFG_NONE;
            const uint32_t taken = later ? model : next;
            const bool merged = next == b + 1 && merges[next];
            continued[b] = taken > b || merged ? BUSTER_TIER1_CFG_NONE : taken | (later ? BUSTER_TIER1_CFG_LATER : 0);
        }
        // Intervals, counted, then filled, by value and position; and the splits, each piece of a range after the
        // first in its block, by the position it starts at and its value.
        candidate.value_interval_offsets = ready ? arena_push_array(output, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        ready = ready && candidate.value_interval_offsets != 0;
        Tier1CfgPieces pieces = { 0 };
        uint64_t interval_count = 0;
        uint64_t split_count = 0;
        // The intervals' register hints (#2646), which tier1_cfg_argument_avoidance carries back along ties (#2823).
        uint8_t* argument_hints = 0;
        for (uint32_t pass = 0; ready && pass < 2; pass += 1)
        {
            uint32_t* use_offsets = 0;
            pieces = (Tier1CfgPieces){
                .fill = pass == 1,
            };
            if (pass == 1)
            {
                ready = interval_count <= BUSTER_TIER1_ALLOCATE_MAX_INTERVALS && split_count <= BUSTER_TIER1_ALLOCATE_MAX_INTERVALS;
                pieces.starts = ready ? arena_push_array(output, interval_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
                pieces.ends = ready ? arena_push_array(output, interval_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
                pieces.values = ready ? arena_push_array(output, interval_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
                pieces.allowed = ready ? arena_push_array(output, interval_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
                pieces.classes = ready ? arena_push(output, interval_count + 1, 1) : 0;
                pieces.remat = ready ? arena_push(output, interval_count + 1, 1) : 0;
                pieces.hints = ready ? arena_push_array(output, interval_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
                pieces.hint_intervals = ready ? arena_push_array(output, interval_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
                pieces.alternates = ready ? arena_push_array(output, interval_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
                pieces.continuations = ready ? arena_push_array(output, interval_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
                use_offsets = ready ? arena_push_array(output, interval_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
                pieces.split_positions = ready ? arena_push_array(scratch, split_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
                pieces.split_values = ready ? arena_push_array(scratch, split_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
                ready = ready && pieces.starts != 0 && pieces.ends != 0 && pieces.values != 0 && pieces.allowed != 0 && pieces.classes != 0 && pieces.remat != 0 && pieces.hints != 0 && pieces.hint_intervals != 0 && pieces.alternates != 0 && pieces.continuations != 0 && use_offsets != 0 && pieces.split_positions != 0 && pieces.split_values != 0;
                pieces.fill = ready;
            }
            if (ready)
            {
                memset(entry_stamps, 0, (uint64_t)blocks * sizeof(uint32_t));
                memset(exit_stamps, 0, (uint64_t)blocks * sizeof(uint32_t));
            }
            for (uint32_t v = 0; ready && v < values; v += 1)
            {
                if (pass == 1)
                {
                    candidate.value_interval_offsets[v] = (uint32_t)pieces.count;
                }
                const uint64_t first = pieces.count;
                uint32_t use = input->use_offsets[v];
                const uint32_t use_end = input->use_offsets[v + 1];
                bool stray = false;
                for (uint32_t x = list_offsets[v]; x < list_offsets[v + 1]; x += 1)
                {
                    const uint32_t b = list[x];
                    const bool defined_here = b == home[v];
                    const bool live_out = (defined_here && edge_local[v] != 0) || list_out[x] != 0;
                    // A use before this block lies in no block the value is live in: not SSA.
                    while (use < use_end && input->use_positions[use] < input->block_starts[b])
                    {
                        stray = true;
                        use += 1;
                    }
                    uint32_t last_use = BUSTER_TIER1_CFG_NONE;
                    while (use < use_end && input->use_positions[use] < input->block_starts[b + 1])
                    {
                        last_use = input->use_positions[use];
                        use += 1;
                    }
                    const uint32_t start = defined_here ? input->definitions[v] : input->block_starts[b];
                    const uint32_t end = live_out ? input->block_starts[b + 1] : last_use != BUSTER_TIER1_CFG_NONE ? last_use + 1 : start + 1;
                    // The range's pieces: before each fixed range that blocks the value, and over it.
                    uint32_t cursor = start;
                    uint32_t piece = 0;
                    uint32_t k = fixed_offsets[start >= longest ? start - longest + 1 : 0];
                    while (cursor < end)
                    {
                        uint32_t blocked_start = end;
                        uint32_t blocked_end = end;
                        for (; blocked_start == end && k < fixed_offsets[end]; k += 1)
                        {
                            const uint32_t r = fixed_sorted[k];
                            if (input->fixed.classes[r] == input->classes[v] && (input->allowed_registers[v] & ~input->fixed.registers[r]) == 0 && input->fixed.ends[r] > cursor)
                            {
                                blocked_start = input->fixed.starts[r] > cursor ? input->fixed.starts[r] : cursor;
                                blocked_end = input->fixed.ends[r] < end ? input->fixed.ends[r] : end;
                            }
                        }
                        for (uint32_t part = 0; part < 2; part += 1)
                        {
                            const uint32_t from = part == 0 ? cursor : blocked_start;
                            const uint32_t to = part == 0 ? blocked_start : blocked_end;
                            if (from < to)
                            {
                                // A merged block continues the value's range from its layout predecessor, its previous
                                // block. A range the value enters a block with keeps, where it can, the register it had
                                // before; a phi takes its operand's; a piece after a split, the value's last.
                                const bool entry = piece == 0 && from == input->block_starts[b];
                                if (piece == 0 && !defined_here && merges[b] && pieces.count > first)
                                {
                                    if (pieces.fill)
                                    {
                                        pieces.ends[pieces.count - 1] = to;
                                    }
                                }
                                else
                                {
                                    // A block laid out after its first successor (a dispatch loop's join) takes that
                                    // successor's convention for the values the two share, as its phis do (#2553).
                                    const uint32_t joined = firsts[b] < b ? firsts[b] : BUSTER_TIER1_CFG_NONE;
                                    const uint32_t model = !entry ? BUSTER_TIER1_CFG_NONE : !defined_here && siblings[b] != BUSTER_TIER1_CFG_NONE ? siblings[b] : joined;
                                    const bool modeled = model != BUSTER_TIER1_CFG_NONE && entry_stamps[model] == v + 1 && (!pieces.fill || pieces.starts[entry_pieces[model]] < from);
                                    // Else a value the block takes from before it, its place at the anchor's exit (#2553): a
                                    // phi's, its operand's at a predecessor's, comes once every value has its intervals.
                                    const uint32_t anchor = entry && !defined_here ? anchors[b] : BUSTER_TIER1_CFG_NONE;
                                    const bool anchored = !modeled && anchor != BUSTER_TIER1_CFG_NONE && exit_stamps[anchor] == v + 1;
                                    const uint32_t earlier = modeled ? entry_pieces[model] : anchored ? exit_pieces[anchor] | BUSTER_TIER1_ALLOCATE_HINT_EXIT : BUSTER_TIER1_CFG_NONE;
                                    tier1_cfg_piece(&pieces, input, v, from, to, piece == 0 && defined_here ? phi_hints[v] : v, earlier, piece != 0);
                                }
                                if (entry)
                                {
                                    entry_stamps[b] = v + 1;
                                    entry_pieces[b] = (uint32_t)pieces.count - 1;
                                }
                                piece += 1;
                            }
                        }
                        cursor = blocked_start < end ? blocked_end : end;
                    }
                    if (live_out && pieces.count > first)
                    {
                        exit_stamps[b] = v + 1;
                        exit_pieces[b] = (uint32_t)pieces.count - 1;
                        // The value's place after the block (#2774), at the entry of the block's first successor in layout
                        // (`continued` above): its entry range there where that block comes no later than this one, else the
                        // range that block's entry takes its opening from, as a dispatch loop's join, laid out after its
                        // handlers, takes their first one's, where the value enters it. A range a merged block continues
                        // opens before that block, not at it. A range that goes on into the next block in layout, which
                        // merges, keeps the place the last of its blocks that gives one gives, where its own last gives
                        // none: the edges out of the blocks before, a loop's back edge among them, store it there too.
                        const uint32_t entered = pieces.fill ? continued[b] : BUSTER_TIER1_CFG_NONE;
                        const uint32_t taken = entered & ~BUSTER_TIER1_CFG_LATER;
                        const bool later = entered != BUSTER_TIER1_CFG_NONE && (entered & BUSTER_TIER1_CFG_LATER) != 0;
                        const bool stamped = entered != BUSTER_TIER1_CFG_NONE && entry_stamps[taken] == v + 1 && home[v] != taken;
                        // Where the first successor comes later, the value must be live into it: among the value's blocks,
                        // which hold its home besides those it is live into.
                        const bool enters = stamped && (later ? dense[v] != BUSTER_TIER1_CFG_NONE && firsts[b] != home[v] && tier1_cfg_listed(list, list_offsets[v], list_offsets[v + 1], firsts[b]) : pieces.starts[entry_pieces[taken]] == input->block_starts[taken]);
                        if (enters)
                        {
                            pieces.continuations[pieces.count - 1] = entry_pieces[taken];
                        }
                    }
                }
                ready = !stray && use == use_end;
                error = ready ? error : TIER1_CFG_INVALID;
            }
            if (ready && pass == 0)
            {
                interval_count = pieces.count;
                split_count = pieces.splits;
            }
            if (ready && pass == 1)
            {
                const uint32_t count = (uint32_t)pieces.count;
                candidate.value_interval_offsets[values] = count;
                // Uses are sorted per value and intervals are by value and position: each slice is contiguous.
                uint32_t use = 0;
                for (uint32_t i = 0; i < count; i += 1)
                {
                    const uint32_t v = pieces.values[i];
                    use = use < input->use_offsets[v] ? input->use_offsets[v] : use;
                    use_offsets[i] = use;
                    while (use < input->use_offsets[v + 1] && input->use_positions[use] < pieces.ends[i])
                    {
                        use += 1;
                    }
                }
                use_offsets[count] = input->use_count;
                // Each interval whose last use reads its value in a named register, at the interval's end (#2646).
                uint8_t* register_hints = input->use_registers != 0 ? arena_push(output, (uint64_t)count + 1, 1) : 0;
                ready = input->use_registers == 0 || register_hints != 0;
                for (uint32_t i = 0; register_hints != 0 && i < count; i += 1)
                {
                    const uint32_t end = use_offsets[i + 1];
                    const bool used = end > use_offsets[i] && input->use_positions[end - 1] + 1 == pieces.ends[i];
                    register_hints[i] = used ? input->use_registers[end - 1] : UINT8_MAX;
                }
                tier1_cfg_phi_exits(input, chosen, ups, firsts, dispatchers, candidate.value_interval_offsets, &pieces);
                tier1_cfg_operand_targets(input, phi_hints, ups, phis, candidate.value_interval_offsets, &pieces);
                tier1_cfg_ties(input, candidate.value_interval_offsets, &pieces);
                tier1_cfg_body_hints(input, candidate.value_interval_offsets, &pieces);
                argument_hints = register_hints;
                candidate.block_starts = input->block_starts;
                candidate.block_count = input->block_count;
                candidate.intervals = (Tier1AllocationInput){
                    .starts = pieces.starts,
                    .ends = pieces.ends,
                    .values = pieces.values,
                    .allowed_registers = pieces.allowed,
                    .classes = pieces.classes,
                    .hint_values = pieces.hints,
                    .alternate_intervals = pieces.alternates,
                    .continuation_intervals = pieces.continuations,
                    .hint_intervals = pieces.hint_intervals,
                    .register_hints = register_hints,
                    .rematerializable = input->rematerializable != 0 ? pieces.remat : 0,
                    .use_offsets = use_offsets,
                    .use_positions = input->use_positions,
                    .use_required = input->use_required,
                    .clobbers = input->clobbers,
                    .clobber_count = input->clobber_count,
                    .clobber_registers = {
                        input->clobber_registers[BUSTER_TIER1_ALLOCATE_GPR],
                        input->clobber_registers[BUSTER_TIER1_ALLOCATE_VECTOR],
                        input->clobber_registers[BUSTER_TIER1_ALLOCATE_MASK],
                    },
                    .use_count = input->use_count,
                    .count = count,
                    .value_count = values,
                    .position_count = input->position_count,
                    .registers = {
                        input->registers[BUSTER_TIER1_ALLOCATE_GPR],
                        input->registers[BUSTER_TIER1_ALLOCATE_VECTOR],
                        input->registers[BUSTER_TIER1_ALLOCATE_MASK],
                    },
                    .fixed = input->fixed,
                };
            }
        }
        // A general value live across a fixed sequence avoids its registers in all its ranges, as does its phi web (#2767),
        // the same in every problem over these intervals. The ranges are whole now, a merged block's having grown past the
        // piece the builder started.
        // And every general range avoids the problem's avoided_general registers (#2819).
        // And a call's unhinted argument avoids the call's other argument registers (#2823).
        const bool avoids = input->sequence_count != 0 || input->avoided_general != 0 || argument_hints != 0;
        uint32_t* crossed = ready && avoids ? arena_push_array(output, (uint64_t)candidate.intervals.count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        if (crossed != 0 && input->sequence_count == 0)
        {
            memset(crossed, 0, ((uint64_t)candidate.intervals.count + 1) * sizeof(uint32_t));
        }
        ready = ready && (!avoids || (crossed != 0 && (input->sequence_count == 0 || tier1_cfg_crossed(input, pieces.starts, pieces.ends, pieces.values, pieces.classes, candidate.intervals.count, scratch, crossed))));
        for (uint32_t i = 0; ready && input->avoided_general != 0 && i < candidate.intervals.count; i += 1)
        {
            crossed[i] |= pieces.classes[i] == BUSTER_TIER1_ALLOCATE_GPR ? input->avoided_general : 0;
        }
        ready = ready && (argument_hints == 0 || tier1_cfg_argument_avoidance(input, &pieces, argument_hints, candidate.intervals.count, scratch, crossed));
        candidate.intervals.avoided_registers = crossed;
        if (ready)
        {
            *prepared = (Tier1CfgPrepared){
                .candidate = candidate,
                .live = live,
                .edge_local = edge_local,
                .defined_offsets = defined_offsets,
                .defined = defined,
                .edge_ordinals = edge_ordinals,
                .entering = entering,
                .split_positions = pieces.split_positions,
                .split_values = pieces.split_values,
                .splits = (uint32_t)pieces.splits,
                .output_saved = output_saved,
                .scratch_saved = scratch_saved,
            };
            error = TIER1_CFG_OK;
        }
    }
    if (error != TIER1_CFG_OK)
    {
        if (output != 0)
        {
            arena_pop_to(output, output_saved);
        }
        if (scratch != 0)
        {
            arena_pop_to(scratch, scratch_saved);
        }
    }
    return error;
}

static Tier1CfgError tier1_cfg_prepare(const Tier1CfgInput* input, Arena* output, Arena* scratch, Tier1CfgPrepared* prepared)
{
    return tier1_cfg_prepare_path(input, output, scratch, prepared, false);
}

// A problem's registers in the prepared intervals' allocator input: its classes' registers and its clobbers, which
// differ between problems over the same intervals (the CFG consumer's preferred problem has clobbers, #2574).
static void tier1_cfg_problem_registers(const Tier1CfgInput* input, Tier1AllocationInput* intervals)
{
    for (uint32_t c = 0; c < BUSTER_TIER1_ALLOCATE_CLASSES; c += 1)
    {
        intervals->registers[c] = input->registers[c];
        intervals->clobber_registers[c] = input->clobber_registers[c];
    }
    intervals->clobbers = input->clobbers;
    intervals->clobber_count = input->clobber_count;
}

// Whether a merged interval crosses a block's entry from several predecessors. A call in the preceding block must
// not choose that join's convention: every other incoming path would then pay for its promotion or spill too.
// Halving locates the first internal boundary; the scan visits only blocks the interval actually covers. An entry
// at the interval's start and a boundary at its end belong to separate intervals and don't constrain this one.
static bool tier1_cfg_interval_crosses_join(const Tier1CfgInput* input, uint32_t start, uint32_t end)
{
    uint32_t first = 0;
    uint32_t past = input->block_count;
    while (first < past)
    {
        const uint32_t middle = first + (past - first) / 2;
        first = input->block_starts[middle] <= start ? middle + 1 : first;
        past = input->block_starts[middle] <= start ? past : middle;
    }
    bool joined = false;
    for (uint32_t b = first; !joined && b < input->block_count && input->block_starts[b] < end; b += 1)
    {
        joined = input->predecessor_offsets[b + 1] - input->predecessor_offsets[b] > 1;
    }
    return joined;
}

// A nonrecomputable interval that crosses a clobber takes a preserved register where one is free (#2610). This is
// an avoidance, not a restriction: a bound definition keeps its incoming register, and pressure may keep that same
// register beyond the definition. Only intervals with both clobbered and preserved choices need a decision. Sixteen
// masks at a time identify them; each remaining interval locates its first strict interior clobber by halving the
// sorted positions. A merged interval that crosses a join keeps its original convention. The prepared avoidance
// column belongs to both problems, so copy it only for an actual addition.
static bool tier1_cfg_clobber_avoidance(const Tier1CfgInput* input, Arena* output, Tier1AllocationInput* intervals)
{
    const uint32_t count = intervals->count;
    const __m512i table = _mm512_setr_epi32(input->clobber_registers[0], input->clobber_registers[1], input->clobber_registers[2], 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    const __m512i zero = _mm512_setzero_si512();
    uint32_t* avoided = 0;
    bool ok = true;
    for (uint32_t i = 0; ok && input->clobber_count != 0 && i < count; i += 16)
    {
        const uint32_t left = count - i;
        const __mmask16 lanes = left >= 16 ? (__mmask16)0xffff : (__mmask16)((1u << left) - 1);
        const __m512i classes = _mm512_cvtepu8_epi32(_mm_maskz_loadu_epi8(lanes, intervals->classes + i));
        const __m512i clobbered = _mm512_permutexvar_epi32(classes, table);
        const __m512i allowed = _mm512_maskz_loadu_epi32(lanes, intervals->allowed_registers + i);
        const __m128i recipes = intervals->rematerializable != 0 ? _mm_maskz_loadu_epi8(lanes, intervals->rematerializable + i) : _mm_setzero_si128();
        uint32_t candidates = lanes & _mm_cmpeq_epi8_mask(recipes, _mm_setzero_si128()) &
                              _mm512_cmpneq_epi32_mask(_mm512_and_si512(allowed, clobbered), zero) &
                              _mm512_cmpneq_epi32_mask(_mm512_andnot_si512(clobbered, allowed), zero);
        for (; ok && candidates != 0; candidates &= candidates - 1)
        {
            const uint32_t interval = i + (uint32_t)__builtin_ctz(candidates);
            const uint32_t start = intervals->starts[interval];
            uint32_t first = 0;
            uint32_t past = input->clobber_count;
            while (first < past)
            {
                const uint32_t middle = first + (past - first) / 2;
                first = input->clobbers[middle] <= start ? middle + 1 : first;
                past = input->clobbers[middle] <= start ? past : middle;
            }
            if (first < input->clobber_count && input->clobbers[first] < intervals->ends[interval] &&
                !tier1_cfg_interval_crosses_join(input, start, intervals->ends[interval]))
            {
                if (avoided == 0)
                {
                    avoided = arena_push_array(output, (uint64_t)count + 1, sizeof(uint32_t), _Alignof(uint32_t));
                    ok = avoided != 0;
                    if (ok && intervals->avoided_registers != 0)
                    {
                        memcpy(avoided, intervals->avoided_registers, (uint64_t)count * 4);
                    }
                    else if (ok)
                    {
                        memset(avoided, 0, (uint64_t)count * 4);
                    }
                }
                if (ok)
                {
                    avoided[interval] |= input->clobber_registers[intervals->classes[interval]];
                }
            }
        }
    }
    intervals->avoided_registers = avoided != 0 ? avoided : intervals->avoided_registers;
    return ok;
}

// One assignment (3. above) over the prepared intervals, for `input`'s registers and `column`, the registers each
// interval may take: null for the prepared column, the input the preparation was given; else tier1_cfg_column's for
// another problem over the same values. Failure leaves the result unchanged; tier1_allocate restores the output arena.
static Tier1CfgError tier1_cfg_assign(const Tier1CfgInput* input, const Tier1CfgPrepared* prepared, const uint32_t* column, Arena* output, Tier1CfgAllocation* result)
{
    const uint64_t saved = output->length;
    Tier1CfgAllocation candidate = prepared->candidate;
    candidate.intervals.allowed_registers = column != 0 ? column : candidate.intervals.allowed_registers;
    tier1_cfg_problem_registers(input, &candidate.intervals);
    const bool ready = tier1_cfg_clobber_avoidance(input, output, &candidate.intervals);
    const Tier1AllocationError allocated = ready ? tier1_allocate(&candidate.intervals, output, &candidate.allocation) : TIER1_ALLOCATION_CAPACITY;
    const Tier1CfgError error = allocated == TIER1_ALLOCATION_OK ? TIER1_CFG_OK : allocated == TIER1_ALLOCATION_CONSTRAINT ? TIER1_CFG_CONSTRAINT : allocated == TIER1_ALLOCATION_INVALID ? TIER1_CFG_INVALID : TIER1_CFG_CAPACITY;
    if (error == TIER1_CFG_OK)
    {
        *result = candidate;
    }
    else
    {
        arena_pop_to(output, saved);
    }
    return error;
}

// For one group of up to 512 values, allocate a row only where a value is live at entry or has a spill fragment.
// held starts at LIVE_IN and descends to LIVE_IN & IN. A stored value is current at exit even if lost at entry.
typedef struct Tier1CfgSlotRow Tier1CfgSlotRow;
struct Tier1CfgSlotRow
{
    uint64_t held[BUSTER_DATAFLOW_VECTOR_WORDS];
    uint64_t stored[BUSTER_DATAFLOW_VECTOR_WORDS];
    __m512i pending;
};

typedef struct Tier1CfgSlotGroup Tier1CfgSlotGroup;
struct Tier1CfgSlotGroup
{
    Tier1CfgSlotRow** rows;
    uint32_t* touched;
    uint32_t* work;
    uint32_t count;
};

static Tier1CfgSlotRow* tier1_cfg_slot_row(Tier1CfgSlotGroup* group, uint32_t b, Arena* scratch)
{
    Tier1CfgSlotRow* row = group->rows[b];
    if (row == 0)
    {
        row = BUSTER_ARENA_PUSH_ARRAY(scratch, Tier1CfgSlotRow, 1);
        if (row != 0)
        {
            memset(row, 0, sizeof(*row));
            group->rows[b] = row;
            group->touched[group->count] = b;
            group->count += 1;
        }
    }
    return row;
}

// Remove unsupported entry facts. Only losses that change OUT need to reach successors. Nonempty pending bits
// also mark membership in the worklist, so each block occupies at most one entry.
static void tier1_cfg_slot_losses(Tier1CfgSlotGroup* group, uint32_t b, __m512i missing, uint32_t* work_count)
{
    Tier1CfgSlotRow* row = group->rows[b];
    const __m512i held = _mm512_load_si512(row->held);
    const __m512i lost = _mm512_and_si512(held, missing);
    _mm512_store_si512(row->held, _mm512_andnot_si512(missing, held));
    const __m512i leaving = _mm512_andnot_si512(_mm512_load_si512(row->stored), lost);
    if (_mm512_test_epi64_mask(leaving, leaving) != 0)
    {
        const __m512i pending = row->pending;
        if (_mm512_test_epi64_mask(pending, pending) == 0)
        {
            group->work[*work_count] = b;
            *work_count += 1;
        }
        row->pending = _mm512_or_si512(pending, leaving);
    }
}

static bool tier1_cfg_current_group(const Tier1CfgInput* input, const Tier1CfgAllocation* result, const uint32_t* ranked, uint32_t first, uint32_t last, Tier1CfgSlotGroup* group, Arena* scratch)
{
    const uint32_t blocks = input->block_count;
    const Tier1Allocation* allocation = &result->allocation;
    const Tier1AllocationInput* intervals = &result->intervals;
    bool ready = true;
    for (uint32_t r = first; ready && r < last; r += 1)
    {
        const uint32_t v = ranked[r];
        const uint32_t home = tier1_cfg_block_at(input, result, input->definitions[v]);
        const uint32_t begin = result->value_interval_offsets[v];
        const uint32_t end = result->value_interval_offsets[v + 1];
        for (uint32_t k = begin; ready && k < end; k += 1)
        {
            uint32_t b = tier1_cfg_block_at(input, result, intervals->starts[k]);
            b += input->block_starts[b] < intervals->starts[k] ? 1 : 0;
            const uint32_t limit = intervals->ends[k];
            for (; ready && b < blocks && input->block_starts[b] < limit; b += 1)
            {
                if (b != home)
                {
                    Tier1CfgSlotRow* row = tier1_cfg_slot_row(group, b, scratch);
                    ready = row != 0;
                    if (ready)
                    {
                        tier1_cfg_set(row->held, r - first);
                    }
                }
            }
        }
        const uint32_t fragment_end = allocation->fragment_offsets[end];
        for (uint32_t f = allocation->fragment_offsets[begin]; ready && f < fragment_end; f += 1)
        {
            if (allocation->kinds[f] == BUSTER_TIER1_ALLOCATE_SPILL)
            {
                const uint32_t end_block = tier1_cfg_block_at(input, result, allocation->ends[f] - 1);
                for (uint32_t b = tier1_cfg_block_at(input, result, allocation->starts[f]); ready && b <= end_block; b += 1)
                {
                    Tier1CfgSlotRow* row = tier1_cfg_slot_row(group, b, scratch);
                    ready = row != 0;
                    if (ready)
                    {
                        tier1_cfg_set(row->stored, r - first);
                    }
                }
            }
        }
    }
    // Seed losses with the predecessor meet, restricted to live entries. An absent row has empty OUT. Reading an
    // already narrowed predecessor is sound: its pending losses can only remove the same bits a second time.
    const uint32_t count = group->count;
    Tier1CfgSlotRow** const rows = group->rows;
    const uint32_t* const touched = group->touched;
    const uint32_t* const predecessor_offsets = input->predecessor_offsets;
    const uint32_t* const predecessors = input->predecessors;
    const uint32_t* const successor_offsets = input->successor_offsets;
    const uint32_t* const successors = input->successors;
    uint32_t work_count = 0;
    for (uint32_t i = 0; ready && i < count; i += 1)
    {
        const uint32_t b = touched[i];
        const __m512i held = _mm512_load_si512(rows[b]->held);
        if (_mm512_test_epi64_mask(held, held) != 0)
        {
            const uint32_t from = predecessor_offsets[b];
            const uint32_t to = predecessor_offsets[b + 1];
            __m512i meet = b != 0 && from != to ? held : _mm512_setzero_si512();
            for (uint32_t e = from; b != 0 && e < to; e += 1)
            {
                const Tier1CfgSlotRow* pred = rows[predecessors[e]];
                if (pred == 0)
                {
                    meet = _mm512_setzero_si512();
                    break;
                }
                // meet & (pred->held | pred->stored).
                meet = _mm512_ternarylogic_epi64(meet, _mm512_load_si512(pred->held), _mm512_load_si512(pred->stored), 0xE0);
            }
            tier1_cfg_slot_losses(group, b, _mm512_andnot_si512(meet, held), &work_count);
        }
    }
    while (work_count != 0)
    {
        work_count -= 1;
        const uint32_t b = group->work[work_count];
        Tier1CfgSlotRow* row = rows[b];
        const __m512i lost = row->pending;
        row->pending = _mm512_setzero_si512();
        const uint32_t end = successor_offsets[b + 1];
        for (uint32_t e = successor_offsets[b]; e < end; e += 1)
        {
            const uint32_t to = successors[e];
            if (rows[to] != 0)
            {
                tier1_cfg_slot_losses(group, to, lost, &work_count);
            }
        }
    }
    return ready;
}

// Which values' slots hold them at each block's start, whatever place their ranges enter the block in (#2553): a forward
// must-analysis. Once stored, a value's slot holds it while it lives: an SSA value never changes, and no other value
// writes the slot meanwhile, since slots are shared only by values never live at once (tier1_cfg_share_slots). So a
// value's slot holds it at a block's start where it does at the exit of every predecessor; and at a block's exit where
// it does at the block's start and the value lives through the block, or where one of the value's fragments in the
// block is its slot (an edge or a transition stored it there, or it rests there). With SLOT[b] those values:
//
//     IN[b] = AND over b's predecessors p of OUT[p]        OUT[b] = (IN[b] & LIVE_IN[b]) | SLOT[b]
//
// The entry's IN and that of a block without predecessors are empty. A value is live into no block its definition is in,
// so a loop's earlier iteration proves nothing of the next. The candidates are the values with a slot that are live into
// some block, read from their own intervals (each covers the start of every block its value is live into, but its
// definition's), rather than from every block's live-in list, which holds every global value and was read twice. They
// are solved 512 at a time. Only blocks with live entries or spill fragments get rows. A forward worklist removes
// unsupported bits until every live entry is justified on every predecessor. The result gets those entries in value order
// (current_slot_offsets and current_slots, on `output`): counted, then filled, a group solved again for the fill where
// there is more than one. An edge searches its predecessor's list where it would store a value into its own slot; a
// store the block makes itself is the predecessor's own proof (tier1_cfg_slot_current). The scratch arena ends as it
// began. False where an arena is short.
static bool tier1_cfg_current_slots(const Tier1CfgInput* input, Tier1CfgAllocation* result, Arena* output, Arena* scratch)
{
    const uint64_t output_mark = output->length;
    const uint64_t mark = scratch->length;
    const uint32_t blocks = input->block_count;
    const uint32_t values = input->value_count;
    const uint32_t* spill_ids = result->allocation.spill_ids;
    const Tier1AllocationInput* intervals = &result->intervals;
    // The candidates in value order, each rank's value: a value with a slot one of whose intervals covers the start of a
    // block other than its definition's, which it is then live into. Only the values with slots are looked at, not every
    // block's live-in list.
    uint32_t* ranked = arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t));
    uint32_t* cursors = arena_push_array(scratch, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t));
    uint32_t* offsets = arena_push_array(output, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t));
    bool ready = ranked != 0 && cursors != 0 && offsets != 0;
    uint32_t count = 0;
    if (ready)
    {
        memset(offsets, 0, ((uint64_t)blocks + 1) * sizeof(uint32_t));
        for (uint32_t v = 0; v < values; v += 1)
        {
            bool entered = false;
            const uint32_t home = spill_ids[v] != UINT32_MAX ? tier1_cfg_block_at(input, result, input->definitions[v]) : 0;
            for (uint32_t k = spill_ids[v] != UINT32_MAX ? result->value_interval_offsets[v] : 0; !entered && spill_ids[v] != UINT32_MAX && k < result->value_interval_offsets[v + 1]; k += 1)
            {
                uint32_t b = tier1_cfg_block_at(input, result, intervals->starts[k]);
                b += input->block_starts[b] < intervals->starts[k] ? 1 : 0;
                entered = b < blocks && input->block_starts[b] < intervals->ends[k] && (b != home || (b + 1 < blocks && input->block_starts[b + 1] < intervals->ends[k]));
            }
            ranked[count] = v;
            count += entered;
        }
    }
    const uint32_t groups = (uint32_t)(((uint64_t)count + BUSTER_DATAFLOW_VECTOR_BITS - 1) / BUSTER_DATAFLOW_VECTOR_BITS);
    Tier1CfgSlotGroup group = { 0 };
    if (ready && groups != 0)
    {
        group.rows = BUSTER_ARENA_PUSH_ARRAY(scratch, Tier1CfgSlotRow*, blocks);
        group.touched = BUSTER_ARENA_PUSH_ARRAY(scratch, uint32_t, blocks);
        group.work = BUSTER_ARENA_PUSH_ARRAY(scratch, uint32_t, blocks);
        ready = group.rows != 0 && group.touched != 0 && group.work != 0;
        if (ready)
        {
            memset(group.rows, 0, (uint64_t)blocks * sizeof(*group.rows));
        }
    }
    const uint64_t row_mark = scratch->length;
    uint32_t* slots = 0;
    for (uint32_t pass = 0; ready && pass < 2; pass += 1)
    {
        if (pass == 1)
        {
            uint64_t run = 0;
            for (uint32_t b = 0; b < blocks; b += 1)
            {
                const uint64_t here = offsets[b + 1];
                offsets[b] = (uint32_t)run;
                cursors[b] = (uint32_t)run;
                run += here;
                ready = ready && run <= UINT32_MAX;
            }
            offsets[blocks] = (uint32_t)run;
            slots = ready ? arena_push_array(output, run + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
            ready = slots != 0;
        }
        for (uint32_t g = 0; ready && g < groups; g += 1)
        {
            const uint32_t first = g * BUSTER_DATAFLOW_VECTOR_BITS;
            const uint32_t last = count - first < BUSTER_DATAFLOW_VECTOR_BITS ? count : first + BUSTER_DATAFLOW_VECTOR_BITS;
            if (pass == 0 || groups > 1)
            {
                for (uint32_t i = 0; i < group.count; i += 1)
                {
                    group.rows[group.touched[i]] = 0;
                }
                arena_pop_to(scratch, row_mark);
                group.count = 0;
                ready = tier1_cfg_current_group(input, result, ranked, first, last, &group, scratch);
            }
            const uint32_t touched = group.count;
            for (uint32_t i = 0; ready && i < touched; i += 1)
            {
                const uint32_t b = group.touched[i];
                const uint64_t* current = group.rows[b]->held;
                const __m512i held = _mm512_load_si512(current);
                if (pass == 0)
                {
                    offsets[b + 1] += (uint32_t)_mm512_reduce_add_epi64(_mm512_popcnt_epi64(held));
                }
                for (uint32_t words = pass == 1 ? _mm512_test_epi64_mask(held, held) : 0; words != 0; words &= words - 1)
                {
                    const uint32_t w = (uint32_t)__builtin_ctz(words);
                    for (uint64_t bits = current[w]; bits != 0; bits &= bits - 1)
                    {
                        slots[cursors[b]] = ranked[first + w * 64 + (uint32_t)__builtin_ctzll(bits)];
                        cursors[b] += 1;
                    }
                }
            }
        }
    }
    if (ready)
    {
        result->current_slot_offsets = offsets;
        result->current_slots = slots;
    }
    else
    {
        arena_pop_to(output, output_mark);
    }
    arena_pop_to(scratch, mark);
    return ready;
}

// Lookup columns, slot sharing, the splits' and the edges' moves (4. and 5. above) for an assignment of the prepared
// intervals, `result` as tier1_cfg_assign left it, with `input` its problem. The scratch arena goes back to where this
// found it, the preparation's state kept; failure restores the output arena too and leaves the result unchanged.
static Tier1CfgError tier1_cfg_finish(const Tier1CfgInput* input, const Tier1CfgPrepared* prepared, Arena* output, Arena* scratch, Tier1CfgAllocation* result)
{
    Tier1CfgError error = TIER1_CFG_CAPACITY;
    const uint64_t output_mark = output->length;
    const uint64_t scratch_mark = scratch->length;
    Tier1CfgAllocation candidate = *result;
    const uint32_t blocks = input->block_count;
    const Tier1CfgLiveSets* live = &prepared->live;
    const uint8_t* edge_local = prepared->edge_local;
    const uint32_t* defined_offsets = prepared->defined_offsets;
    const uint32_t* defined = prepared->defined;
    const uint32_t* entering = prepared->entering;
    tier1_cfg_install_lookup(input, output, scratch, &candidate);
    bool ready = input->slot_widths == 0 || candidate.allocation.spill_count < 2 || tier1_cfg_share_slots(input, &candidate, scratch);
    if (ready)
    {
        tier1_cfg_carried_unread(input, &candidate, output, scratch);
    }
    // Splits by position, counted then filled: the values whose ranges are cut there, and the distinct positions.
    const uint32_t splits = ready ? prepared->splits : 0;
    uint32_t* split_offsets = ready ? arena_push_array(scratch, (uint64_t)input->position_count + 2, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* split_values = ready ? arena_push_array(scratch, (uint64_t)splits + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    ready = ready && split_offsets != 0 && split_values != 0;
    uint32_t split_positions = 0;
    uint32_t split_widest = 0;
    if (ready)
    {
        memset(split_offsets, 0, ((uint64_t)input->position_count + 2) * sizeof(uint32_t));
        for (uint32_t k = 0; k < splits; k += 1)
        {
            split_offsets[prepared->split_positions[k] + 1] += 1;
        }
        for (uint32_t q = 0; q <= input->position_count; q += 1)
        {
            const uint32_t here = split_offsets[q + 1];
            split_positions += here != 0;
            split_widest = here > split_widest ? here : split_widest;
            split_offsets[q + 1] += split_offsets[q];
        }
        for (uint32_t k = 0; k < splits; k += 1)
        {
            split_values[split_offsets[prepared->split_positions[k]]] = prepared->split_values[k];
            split_offsets[prepared->split_positions[k]] += 1;
        }
        // The fill advanced each start to the next's: shift them back.
        for (uint32_t q = input->position_count + 1; q > 0; q -= 1)
        {
            split_offsets[q] = split_offsets[q - 1];
        }
        split_offsets[0] = 0;
    }
    // Edge and split moves: each edge's, then each split's, resolved into a staging area, then all published at
    // their exact extent. An edge has at most four moves per value of its successor's entry state
    // (tier1_resolve_moves' bound, two per move, and a slot-to-slot move takes two), and a split as many per value
    // it cuts.
    const uint32_t spills = ready ? candidate.allocation.spill_count : 0;
    const uint32_t locations = BUSTER_TIER1_CFG_SPILL + spills + BUSTER_TIER1_ALLOCATE_CLASSES;
    uint64_t bound = 4 * (uint64_t)splits;
    uint32_t widest = split_widest;
    for (uint32_t e = 0; ready && e < input->edge_count; e += 1)
    {
        const uint32_t target = input->successors[e];
        bound += 4 * (uint64_t)entering[target];
        widest = entering[target] > widest ? entering[target] : widest;
    }
    ready = ready && bound <= UINT32_MAX;
    uint32_t* spill_ends = ready && spills != 0 ? arena_push_array(scratch, (uint64_t)candidate.allocation.fragment_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    ready = ready && (spills == 0 || spill_ends != 0);
    if (ready && spills != 0)
    {
        tier1_cfg_spill_prefix(&candidate, spill_ends);
    }
    // The slots current at each block's start (#2553), which each block's edges search.
    ready = ready && (spills == 0 || tier1_cfg_current_slots(input, &candidate, output, scratch));
    Tier1CfgEdge edge = { .spill_ends = spill_ends };
    uint32_t* staged = ready ? arena_push_array(scratch, (bound + 2) * 3, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* sources = ready ? arena_push_array(scratch, (uint64_t)widest + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* destinations = ready ? arena_push_array(scratch, (uint64_t)widest + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    edge.recompute = ready ? arena_push_array(scratch, ((uint64_t)widest + 1) * 3, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    edge.carried_at = ready ? arena_push_array(scratch, locations, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    edge.carried_stamps = ready ? arena_push_array(scratch, locations, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    for (uint32_t c = 0; c < BUSTER_TIER1_ALLOCATE_CLASSES; c += 1)
    {
        edge.pending[c] = ready ? arena_push_array(scratch, ((uint64_t)widest + 1) * 3, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
        ready = ready && edge.pending[c] != 0;
    }
    candidate.edge_placements = ready ? arena_push(output, (uint64_t)input->edge_count + 1, 1) : 0;
    candidate.edge_move_offsets = ready ? arena_push_array(output, (uint64_t)input->edge_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    candidate.split_positions = ready ? arena_push_array(output, (uint64_t)split_positions + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    candidate.split_move_offsets = ready ? arena_push_array(output, (uint64_t)split_positions + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    ready = ready && staged != 0 && sources != 0 && destinations != 0 && edge.recompute != 0 && edge.carried_at != 0 && edge.carried_stamps != 0 && candidate.edge_placements != 0 && candidate.edge_move_offsets != 0 && candidate.split_positions != 0 && candidate.split_move_offsets != 0;
    if (ready)
    {
        memset(edge.carried_stamps, 0, (uint64_t)locations * sizeof(uint32_t));
    }
    Tier1CfgBoundaries bounds = { 0 };
    if (ready)
    {
        bounds = tier1_cfg_boundaries(input, &candidate, live, edge_local, defined_offsets, defined, scratch);
    }
    uint32_t staged_count = 0;
    for (uint32_t b = 0; ready && b < blocks; b += 1)
    {
        const uint32_t exit = input->block_starts[b + 1] - 1;
        edge.block_start = input->block_starts[b];
        // The block's current slots (tier1_cfg_current_slots).
        edge.current = candidate.current_slot_offsets != 0 ? candidate.current_slots : 0;
        edge.current_begin = candidate.current_slot_offsets != 0 ? candidate.current_slot_offsets[b] : 0;
        edge.current_end = candidate.current_slot_offsets != 0 ? candidate.current_slot_offsets[b + 1] : 0;
        if (bounds.ready)
        {
            uint32_t rank = 0;
            for (uint32_t x = live->out_offsets[b]; x < live->out_offsets[b + 1]; x += 1)
            {
                const uint32_t v = live->out_values[x];
                bounds.exit_at[v] = bounds.exit_locations[bounds.out_offsets[b] + rank];
                bounds.exit_stamp[v] = b + 1;
                rank += 1;
            }
            for (uint32_t x = defined_offsets[b]; x < defined_offsets[b + 1]; x += 1)
            {
                const uint32_t v = defined[x];
                if (edge_local[v] != 0)
                {
                    bounds.exit_at[v] = bounds.exit_locations[bounds.out_offsets[b] + rank];
                    bounds.exit_stamp[v] = b + 1;
                    rank += 1;
                }
            }
        }
        for (uint32_t e = input->successor_offsets[b]; ready && e < input->successor_offsets[b + 1]; e += 1)
        {
            const uint32_t target = input->successors[e];
            const uint32_t entry = input->block_starts[target];
            candidate.edge_move_offsets[e] = staged_count;
            edge.stamp += 1;
            edge.recompute_count = 0;
            for (uint32_t c = 0; c < BUSTER_TIER1_ALLOCATE_CLASSES; c += 1)
            {
                edge.pending_count[c] = 0;
                edge.memory_pair[c] = false;
            }
            for (uint32_t x = live->in_offsets[target]; ready && x < live->in_offsets[target + 1]; x += 1)
            {
                const uint32_t v = live->in_values[x];
                if (bounds.ready)
                {
                    const uint32_t from = bounds.exit_stamp[v] == b + 1 ? bounds.exit_at[v] : BUSTER_TIER1_CFG_NONE;
                    ready = tier1_cfg_edge_known(input, &candidate, &edge, v, v, from, bounds.entry_locations[x], exit);
                }
                else
                {
                    ready = tier1_cfg_edge_value(input, &candidate, &edge, v, v, exit, entry);
                }
            }
            const uint32_t j = prepared->edge_ordinals != 0 ? prepared->edge_ordinals[e] : 0;
            for (uint32_t k = input->phi_offsets[target]; ready && k < input->phi_offsets[target + 1]; k += 1)
            {
                const uint32_t operand = input->phi_operands[input->phi_operand_offsets[k] + j];
                if (operand == BUSTER_TIER1_CFG_NONE)
                {
                    ready = true;
                }
                else if (bounds.ready)
                {
                    const uint32_t from = bounds.exit_stamp[operand] == b + 1 ? bounds.exit_at[operand] : BUSTER_TIER1_CFG_NONE;
                    ready = tier1_cfg_edge_known(input, &candidate, &edge, input->phi_values[k], operand, from, bounds.phi_locations[k], exit);
                }
                else
                {
                    ready = tier1_cfg_edge_value(input, &candidate, &edge, input->phi_values[k], operand, exit, entry);
                }
            }
            ready = ready && tier1_cfg_edge_stage(input, spills, &edge, scratch, sources, destinations, staged, bound + 2, &staged_count, &candidate.temp_slots);
            error = ready ? error : TIER1_CFG_INVALID;
            if (ready)
            {
                const bool moves = staged_count != candidate.edge_move_offsets[e] || (input->edge_copies != 0 && input->edge_copies[e] != 0);
                const bool one_successor = input->successor_offsets[b + 1] - input->successor_offsets[b] == 1;
                const bool one_predecessor = input->predecessor_offsets[target + 1] - input->predecessor_offsets[target] == 1;
                candidate.edge_placements[e] = !moves ? TIER1_CFG_EDGE_EMPTY : one_successor ? TIER1_CFG_EDGE_PREDECESSOR : one_predecessor ? TIER1_CFG_EDGE_SUCCESSOR : TIER1_CFG_EDGE_SPLIT;
                candidate.split_edges += candidate.edge_placements[e] == TIER1_CFG_EDGE_SPLIT;
            }
        }
    }
    if (ready)
    {
        candidate.edge_move_offsets[input->edge_count] = staged_count;
    }
    // Slot-current elision is for CFG edges only; keep the existing split-move contract unchanged.
    edge.spill_ends = 0;
    edge.current = 0;
    // Each split's moves: from the value's location just before the position to its new piece's.
    for (uint32_t q = 0; ready && q < input->position_count; q += 1)
    {
        if (split_offsets[q] != split_offsets[q + 1])
        {
            candidate.split_positions[candidate.split_count] = q;
            candidate.split_move_offsets[candidate.split_count] = staged_count;
            candidate.split_count += 1;
            edge.stamp += 1;
            edge.recompute_count = 0;
            for (uint32_t c = 0; c < BUSTER_TIER1_ALLOCATE_CLASSES; c += 1)
            {
                edge.pending_count[c] = 0;
                edge.memory_pair[c] = false;
            }
            for (uint32_t k = split_offsets[q]; ready && k < split_offsets[q + 1]; k += 1)
            {
                ready = q != 0 && tier1_cfg_edge_value(input, &candidate, &edge, split_values[k], split_values[k], q - 1, q);
            }
            ready = ready && tier1_cfg_edge_stage(input, spills, &edge, scratch, sources, destinations, staged, bound + 2, &staged_count, &candidate.temp_slots);
            error = ready ? error : TIER1_CFG_INVALID;
        }
    }
    if (ready)
    {
        candidate.split_move_offsets[candidate.split_count] = staged_count;
        candidate.move_count = staged_count;
        candidate.move_sources = arena_push_array(output, (uint64_t)staged_count + 1, sizeof(uint32_t), _Alignof(uint32_t));
        candidate.move_destinations = arena_push_array(output, (uint64_t)staged_count + 1, sizeof(uint32_t), _Alignof(uint32_t));
        candidate.move_values = arena_push_array(output, (uint64_t)staged_count + 1, sizeof(uint32_t), _Alignof(uint32_t));
        ready = candidate.move_sources != 0 && candidate.move_destinations != 0 && candidate.move_values != 0;
        error = ready ? TIER1_CFG_OK : TIER1_CFG_CAPACITY;
    }
    for (uint32_t m = 0; ready && m < staged_count; m += 1)
    {
        candidate.move_sources[m] = staged[(uint64_t)m * 3];
        candidate.move_destinations[m] = staged[(uint64_t)m * 3 + 1];
        candidate.move_values[m] = staged[(uint64_t)m * 3 + 2];
    }
    if (error == TIER1_CFG_OK)
    {
        candidate.retained_bytes = output->length - prepared->output_saved;
        candidate.scratch_bytes = scratch->length - prepared->scratch_saved;
        arena_pop_to(scratch, scratch_mark);
        *result = candidate;
    }
    else
    {
        arena_pop_to(output, output_mark);
        arena_pop_to(scratch, scratch_mark);
    }
    return error;
}

// The scratch arena back to where tier1_cfg_prepare found it, once nothing reads the preparation's state.
static void tier1_cfg_release(const Tier1CfgPrepared* prepared, Arena* scratch)
{
    arena_pop_to(scratch, prepared->scratch_saved);
}

// The three in a row, for the input's own problem, the liveness sparse where `force_sparse` says (the tests').
static Tier1CfgError tier1_cfg_allocate_impl(const Tier1CfgInput* input, Arena* output, Arena* scratch, Tier1CfgAllocation* result, bool force_sparse)
{
    Tier1CfgPrepared prepared = { 0 };
    Tier1CfgAllocation candidate = { 0 };
    Tier1CfgError error = result != 0 ? tier1_cfg_prepare_path(input, output, scratch, &prepared, force_sparse) : TIER1_CFG_INVALID;
    const bool held = error == TIER1_CFG_OK;
    error = held ? tier1_cfg_assign(input, &prepared, 0, output, &candidate) : error;
    error = error == TIER1_CFG_OK ? tier1_cfg_finish(input, &prepared, output, scratch, &candidate) : error;
    if (held && error == TIER1_CFG_OK)
    {
        tier1_cfg_release(&prepared, scratch);
        *result = candidate;
    }
    else if (held)
    {
        arena_pop_to(output, prepared.output_saved);
        arena_pop_to(scratch, prepared.scratch_saved);
    }
    return error;
}

static __attribute__((unused)) Tier1CfgError tier1_cfg_allocate(const Tier1CfgInput* input, Arena* output, Arena* scratch, Tier1CfgAllocation* result)
{
    return tier1_cfg_allocate_impl(input, output, scratch, result, false);
}

// The tests force the sparse groups (tier1_cfg_live_group_sparse) on every case, as well as past the bound.
static __attribute__((unused)) Tier1CfgError tier1_cfg_allocate_sparse(const Tier1CfgInput* input, Arena* output, Arena* scratch, Tier1CfgAllocation* result)
{
    return tier1_cfg_allocate_impl(input, output, scratch, result, true);
}

// Whether each value's registers lie in its class's, and its definition's in its allowed ones: tier1_cfg_input_valid's
// two conditions on a value's registers, 16 values a step, the class's registers by an in-register lookup of the three
// and each condition an andnot. The classes were validated with the prepared input.
static bool tier1_cfg_sets_valid_vector(const Tier1CfgInput* input)
{
    const __m512i table = _mm512_maskz_loadu_epi32((__mmask16)((1u << BUSTER_TIER1_ALLOCATE_CLASSES) - 1), input->registers);
    const uint32_t values = input->value_count;
    __mmask16 bad = 0;
    for (uint32_t v = 0; v < values; v += 16)
    {
        const uint32_t left = values - v;
        const __mmask16 lanes = left >= 16 ? (__mmask16)0xffff : (__mmask16)((1u << left) - 1);
        const __m512i sets = _mm512_permutexvar_epi32(_mm512_cvtepu8_epi32(_mm_maskz_loadu_epi8(lanes, input->classes + v)), table);
        const __m512i allowed = _mm512_maskz_loadu_epi32(lanes, input->allowed_registers + v);
        const __m512i outside = _mm512_andnot_si512(sets, allowed);
        const __m512i defined = input->definition_registers != 0 ? _mm512_maskz_loadu_epi32(lanes, input->definition_registers + v) : _mm512_setzero_si512();
        const __m512i unallowed = _mm512_andnot_si512(allowed, defined);
        bad |= _mm512_mask_test_epi32_mask(lanes, outside, outside) | _mm512_mask_test_epi32_mask(lanes, unallowed, unallowed);
    }
    return bad == 0;
}

// The registers each prepared interval may take in another problem over the same values (#2538): `input` is the
// prepared one but for its registers, allowed_registers and definition_registers. Each value's run of intervals takes its
// allowed set, and the interval that holds its definition its definition's registers where some are bound, as
// tier1_cfg_piece gives them; the column is on `output`. The registers each avoids (#2767) are the intervals' own. TIER1_CFG_INVALID where the problem breaks what
// tier1_cfg_input_valid checks of those three, or where the input has a fixed range, around which a value's intervals
// depend on its registers (2. above), so that no column of the prepared ones fits another problem.
static __attribute__((unused)) Tier1CfgError tier1_cfg_column(const Tier1CfgInput* input, const Tier1CfgPrepared* prepared, Arena* output, uint32_t** column)
{
    const Tier1CfgAllocation* intervals = &prepared->candidate;
    bool valid = input->fixed.count == 0 && (input->value_count == 0 || input->allowed_registers != 0);
    for (uint32_t c = 0; valid && c < BUSTER_TIER1_ALLOCATE_CLASSES; c += 1)
    {
        valid = input->scratch_registers[c] < 32 && ((input->registers[c] >> input->scratch_registers[c]) & 1) == 0;
    }
    valid = valid && (input->registers[BUSTER_TIER1_ALLOCATE_GPR] & 0xffff0000u) == 0 && input->scratch_registers[BUSTER_TIER1_ALLOCATE_GPR] < 16;
    valid = valid && (input->registers[BUSTER_TIER1_ALLOCATE_MASK] & ~BUSTER_TIER1_ALLOCATE_MASK_REGISTERS) == 0 && input->scratch_registers[BUSTER_TIER1_ALLOCATE_MASK] < 8;
    valid = valid && tier1_cfg_sets_valid_vector(input);
    uint32_t* written = valid ? arena_push_array(output, (uint64_t)intervals->intervals.count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    for (uint32_t v = 0; written != 0 && v < input->value_count; v += 1)
    {
        const uint32_t allowed = input->allowed_registers[v];
        const uint32_t defined = input->definition_registers != 0 ? input->definition_registers[v] : 0;
        const uint32_t definition = input->definitions[v];
        for (uint32_t i = intervals->value_interval_offsets[v]; i < intervals->value_interval_offsets[v + 1]; i += 1)
        {
            written[i] = defined != 0 && intervals->intervals.starts[i] <= definition && definition < intervals->intervals.ends[i] ? defined : allowed;
        }
    }
    *column = written;
    return !valid ? TIER1_CFG_INVALID : written == 0 ? TIER1_CFG_CAPACITY : TIER1_CFG_OK;
}

// Whether a preferred problem's allocation replaces the plain one (tier1_emit_cfg.c's callee-saved preference, #1116):
// allocated, without a split, each class's temporary slot a frame row of its own.
static __attribute__((unused)) bool tier1_cfg_taken(Tier1CfgError error, const Tier1CfgAllocation* allocation)
{
    return error == TIER1_CFG_OK && allocation->split_count == 0 && (allocation->temp_slots & ~((1u << BUSTER_TIER1_ALLOCATE_CLASSES) - 1)) == 0;
}

// tier1_cfg_assign, and another problem's verdict inside the same call (#2538's step 3, tier1_allocate_verdict): `other`
// is the prepared input but for its registers, allowed and definition registers, `other_column` its column (null for the
// prepared one). `*taken` says whether the verdict was taken, `*constraint` what it is.
static Tier1CfgError tier1_cfg_assign_verdict(const Tier1CfgInput* input, const Tier1CfgPrepared* prepared, const uint32_t* column, const Tier1CfgInput* other, const uint32_t* other_column, Arena* output, Tier1CfgAllocation* result, bool* taken, bool* constraint)
{
    const uint64_t saved = output->length;
    Tier1CfgAllocation candidate = prepared->candidate;
    Tier1AllocationVerdict verdict = {
        .allowed_registers = other_column != 0 ? other_column : candidate.intervals.allowed_registers,
        .avoided_registers = candidate.intervals.avoided_registers,
    };
    candidate.intervals.allowed_registers = column != 0 ? column : candidate.intervals.allowed_registers;
    tier1_cfg_problem_registers(input, &candidate.intervals);
    for (uint32_t c = 0; c < BUSTER_TIER1_ALLOCATE_CLASSES; c += 1)
    {
        verdict.registers[c] = other->registers[c];
        verdict.clobber_registers[c] = other->clobber_registers[c];
    }
    const bool ready = tier1_cfg_clobber_avoidance(input, output, &candidate.intervals);
    const Tier1AllocationError allocated = ready ? tier1_allocate_verdict(&candidate.intervals, output, &verdict, &candidate.allocation) : TIER1_ALLOCATION_CAPACITY;
    const Tier1CfgError error = allocated == TIER1_ALLOCATION_OK ? TIER1_CFG_OK : allocated == TIER1_ALLOCATION_CONSTRAINT ? TIER1_CFG_CONSTRAINT : allocated == TIER1_ALLOCATION_INVALID ? TIER1_CFG_INVALID : TIER1_CFG_CAPACITY;
    if (error == TIER1_CFG_OK)
    {
        *result = candidate;
    }
    else
    {
        arena_pop_to(output, saved);
    }
    *taken = verdict.taken;
    *constraint = verdict.constraint;
    return error;
}

// A preferred problem for the one-call order (#2538): its classes' registers, and each value's registers but those of its
// definition, which the order adds while the definition is bound (tier1_cfg_preferred). `verdict` takes the plain
// problem's verdict inside the preferred problem's assignment (step 3); without it the plain problem is assigned whole
// first (step 2), the form the tests compare it with.
typedef struct Tier1CfgPreference Tier1CfgPreference;
struct Tier1CfgPreference
{
    const uint32_t* sets;
    uint32_t registers[BUSTER_TIER1_ALLOCATE_CLASSES];
    // The preferred problem's clobbers (Tier1CfgInput.clobbers, #2574), or none.
    const uint32_t* clobbers;
    uint32_t clobber_count;
    uint32_t clobber_registers[BUSTER_TIER1_ALLOCATE_CLASSES];
    bool verdict;
};

// The preferred problem over `input`'s values: the preference's registers, and each value's set with its definition's
// registers, input's while bound, on `output`. False where the arena is short.
static __attribute__((unused)) bool tier1_cfg_preferred(const Tier1CfgInput* input, const Tier1CfgPreference* preference, Arena* output, Tier1CfgInput* preferred)
{
    uint32_t* allowed = arena_push_array(output, (uint64_t)input->value_count + 1, sizeof(uint32_t), _Alignof(uint32_t));
    for (uint32_t v = 0; allowed != 0 && v < input->value_count; v += 1)
    {
        allowed[v] = preference->sets[v] | (input->definition_registers != 0 ? input->definition_registers[v] : 0);
    }
    *preferred = *input;
    preferred->allowed_registers = allowed;
    preferred->clobbers = preference->clobbers;
    preferred->clobber_count = preference->clobber_count;
    for (uint32_t c = 0; c < BUSTER_TIER1_ALLOCATE_CLASSES; c += 1)
    {
        preferred->registers[c] = preference->registers[c];
        preferred->clobber_registers[c] = preference->clobber_registers[c];
    }
    return allowed != 0;
}

// The one-call order's state between its halves (#2538): the intervals, prepared once, and the plain problem's
// assignment where one was made.
typedef struct Tier1CfgOrder Tier1CfgOrder;
struct Tier1CfgOrder
{
    Tier1CfgPrepared prepared;
    Tier1CfgAllocation plain;
};

// The one-call order's first half: the intervals (tier1_cfg_prepare), whose columns the preference reads in
// `order->prepared.candidate`. tier1_cfg_order_run or tier1_cfg_release ends what this holds.
static __attribute__((unused)) Tier1CfgError tier1_cfg_order_prepare(const Tier1CfgInput* input, Arena* output, Arena* scratch, Tier1CfgOrder* order)
{
    *order = (Tier1CfgOrder){ 0 };
    return tier1_cfg_prepare(input, output, scratch, &order->prepared);
}

// The plain problem assigned whole over the prepared intervals: with `freed`, its definitions already free, over the free
// problem's column. Where a definition bound to its registers (a parameter's incoming one) leaves a use no register,
// every definition is freed (`input->definition_registers` made null) and the problem assigned again.
static Tier1CfgError tier1_cfg_order_plain(Tier1CfgInput* input, Arena* output, Tier1CfgOrder* order, bool freed)
{
    uint32_t* column = 0;
    Tier1CfgError error = freed ? tier1_cfg_column(input, &order->prepared, output, &column) : TIER1_CFG_OK;
    error = error == TIER1_CFG_OK ? tier1_cfg_assign(input, &order->prepared, column, output, &order->plain) : error;
    if (error == TIER1_CFG_CONSTRAINT && !freed)
    {
        input->definition_registers = 0;
        error = tier1_cfg_column(input, &order->prepared, output, &column);
        error = error == TIER1_CFG_OK ? tier1_cfg_assign(input, &order->prepared, column, output, &order->plain) : error;
    }
    return error;
}

// The preferred problem assigned, with the plain problem's verdict inside its call (step 3): its column, and with
// `freed` the free plain problem's. Returns the preferred assignment's outcome; `*verdict` says whether the plain
// problem's verdict was taken, `*constraint` what it is.
static Tier1CfgError tier1_cfg_order_verdict(const Tier1CfgInput* input, const Tier1CfgPreference* preference, Arena* output, Tier1CfgOrder* order, bool freed, Tier1CfgInput* preferred, Tier1CfgAllocation* second, bool* verdict, bool* constraint)
{
    uint32_t* column = 0;
    uint32_t* plain_column = 0;
    *verdict = false;
    *constraint = false;
    Tier1CfgError error = tier1_cfg_preferred(input, preference, output, preferred) ? TIER1_CFG_OK : TIER1_CFG_CAPACITY;
    error = error == TIER1_CFG_OK ? tier1_cfg_column(preferred, &order->prepared, output, &column) : error;
    error = error == TIER1_CFG_OK && freed ? tier1_cfg_column(input, &order->prepared, output, &plain_column) : error;
    error = error == TIER1_CFG_OK ? tier1_cfg_assign_verdict(preferred, &order->prepared, column, input, plain_column, output, second, verdict, constraint) : error;
    return error;
}

// The one-call order's second half. With a preference that takes the verdict (step 3): the preferred problem assigned
// with the plain one's verdict inside its call; where that is a constraint, every definition freed and the preferred
// problem assigned again with the free plain one's verdict, a second constraint the plain problem's outcome. Without, or
// where no verdict was taken (step 2): the plain problem assigned whole first (tier1_cfg_order_plain), then the preferred
// one over the definitions the plain one left. The preferred allocation is finished and stands where tier1_cfg_taken takes
// it, with `*taken` set and its allowed sets in `*preferred_allowed`; else the plain problem, assigned whole now if only
// its verdict was taken, is finished. `*preferred_error` is the preferred problem's outcome. Returns the outcome of the
// allocation that stands, and gives back the scratch arena the order held; failure restores both arenas.
static __attribute__((unused)) Tier1CfgError tier1_cfg_order_run(Tier1CfgInput* input, const Tier1CfgPreference* preference, Arena* output, Arena* scratch, Tier1CfgOrder* order, Tier1CfgAllocation* result, const uint32_t** preferred_allowed, Tier1CfgError* preferred_error, bool* taken)
{
    Tier1CfgError error = TIER1_CFG_OK;
    Tier1CfgError second_error = TIER1_CFG_OK;
    Tier1CfgAllocation second = { 0 };
    Tier1CfgInput preferred = *input;
    // Whether the plain problem's verdict is known, its definitions were freed, and it was assigned whole.
    bool known = false;
    bool freed = false;
    bool assigned = false;
    if (preference != 0 && preference->verdict)
    {
        bool verdict = false;
        bool constraint = false;
        second_error = tier1_cfg_order_verdict(input, preference, output, order, false, &preferred, &second, &verdict, &constraint);
        known = verdict && !constraint;
        if (verdict && constraint)
        {
            input->definition_registers = 0;
            freed = true;
            second_error = tier1_cfg_order_verdict(input, preference, output, order, true, &preferred, &second, &verdict, &constraint);
            known = verdict;
            error = verdict && constraint ? TIER1_CFG_CONSTRAINT : TIER1_CFG_OK;
        }
    }
    if (!known)
    {
        error = tier1_cfg_order_plain(input, output, order, freed);
        assigned = true;
        uint32_t* column = 0;
        const bool prefer = error == TIER1_CFG_OK && preference != 0;
        second_error = prefer ? (tier1_cfg_preferred(input, preference, output, &preferred) ? TIER1_CFG_OK : TIER1_CFG_CAPACITY) : TIER1_CFG_OK;
        second_error = prefer && second_error == TIER1_CFG_OK ? tier1_cfg_column(&preferred, &order->prepared, output, &column) : second_error;
        second_error = prefer && second_error == TIER1_CFG_OK ? tier1_cfg_assign(&preferred, &order->prepared, column, output, &second) : second_error;
    }
    const bool prefer = error == TIER1_CFG_OK && preference != 0;
    second_error = prefer && second_error == TIER1_CFG_OK ? tier1_cfg_finish(&preferred, &order->prepared, output, scratch, &second) : second_error;
    const bool replaced = prefer && tier1_cfg_taken(second_error, &second);
    if (replaced)
    {
        *result = second;
        *preferred_allowed = preferred.allowed_registers;
    }
    else if (error == TIER1_CFG_OK)
    {
        // The plain problem stands: assigned whole now where only its verdict was taken.
        error = assigned ? TIER1_CFG_OK : tier1_cfg_order_plain(input, output, order, freed);
        error = error == TIER1_CFG_OK ? tier1_cfg_finish(input, &order->prepared, output, scratch, &order->plain) : error;
        if (error == TIER1_CFG_OK)
        {
            *result = order->plain;
        }
    }
    if (error != TIER1_CFG_OK)
    {
        arena_pop_to(output, order->prepared.output_saved);
    }
    tier1_cfg_release(&order->prepared, scratch);
    *preferred_error = preference != 0 ? second_error : TIER1_CFG_OK;
    *taken = replaced;
    return error;
}

static bool tier1_cfg_same_column(const void* left, const void* right, uint64_t bytes)
{
    return (left == 0) == (right == 0) && (left == 0 || bytes == 0 || memcmp(left, right, bytes) == 0);
}

// 0 where two allocations of `input`'s problem are the same, field by field, else the first group of fields that
// differs, from 1: the allocator's input and its counts; its interval columns; the hints and recomputations; the use
// slices; the assignment's counts; its fragments; its per-value and slot columns; the values' runs of intervals; the
// edges' placements; the moves; the splits; the liveness counts and temporary slots; and the lookup columns. Memory
// counts aren't compared: they depend on where each allocation's arenas stood.
static __attribute__((unused)) uint32_t tier1_cfg_differs(const Tier1CfgInput* input, const Tier1CfgAllocation* left, const Tier1CfgAllocation* right)
{
    const Tier1AllocationInput* a = &left->intervals;
    const Tier1AllocationInput* b = &right->intervals;
    const Tier1Allocation* x = &left->allocation;
    const Tier1Allocation* y = &right->allocation;
    const uint64_t count = a->count;
    const uint64_t fragments = x->fragment_count;
    const uint64_t values = input->value_count;
    const uint64_t edges = input->edge_count;
    uint32_t differs = 0;
    bool same = a->count == b->count && a->value_count == b->value_count && a->position_count == b->position_count && a->use_count == b->use_count && a->fixed.count == b->fixed.count &&
                a->clobber_count == b->clobber_count && tier1_cfg_same_column(a->clobbers, b->clobbers, (uint64_t)a->clobber_count * 4);
    for (uint32_t c = 0; same && c < BUSTER_TIER1_ALLOCATE_CLASSES; c += 1)
    {
        same = a->registers[c] == b->registers[c] && a->clobber_registers[c] == b->clobber_registers[c];
    }
    differs = same ? differs : 1;
    same = same && tier1_cfg_same_column(a->starts, b->starts, count * 4) && tier1_cfg_same_column(a->ends, b->ends, count * 4) && tier1_cfg_same_column(a->values, b->values, count * 4) &&
           tier1_cfg_same_column(a->allowed_registers, b->allowed_registers, count * 4) && tier1_cfg_same_column(a->classes, b->classes, count);
    differs = same || differs != 0 ? differs : 2;
    same = same && tier1_cfg_same_column(a->hint_values, b->hint_values, count * 4) && tier1_cfg_same_column(a->hint_intervals, b->hint_intervals, count * 4) &&
           tier1_cfg_same_column(a->alternate_intervals, b->alternate_intervals, count * 4) && tier1_cfg_same_column(a->continuation_intervals, b->continuation_intervals, count * 4) &&
           tier1_cfg_same_column(a->rematerializable, b->rematerializable, count) && tier1_cfg_same_column(a->flags, b->flags, count) && tier1_cfg_same_column(a->hints, b->hints, count) &&
           tier1_cfg_same_column(a->register_hints, b->register_hints, count) && tier1_cfg_same_column(a->avoided_registers, b->avoided_registers, count * 4);
    differs = same || differs != 0 ? differs : 3;
    same = same && tier1_cfg_same_column(a->use_offsets, b->use_offsets, (count + 1) * 4) && a->use_positions == b->use_positions && a->use_required == b->use_required;
    differs = same || differs != 0 ? differs : 4;
    same = same && x->fragment_count == y->fragment_count && x->interval_count == y->interval_count && x->spill_count == y->spill_count && x->vector_intervals == y->vector_intervals &&
           x->scalar_intervals == y->scalar_intervals && x->splits == y->splits && memcmp(x->peak_pressure, y->peak_pressure, sizeof(x->peak_pressure)) == 0;
    differs = same || differs != 0 ? differs : 5;
    same = same && tier1_cfg_same_column(x->fragment_offsets, y->fragment_offsets, ((uint64_t)x->interval_count + 1) * 4) && tier1_cfg_same_column(x->starts, y->starts, fragments * 4) &&
           tier1_cfg_same_column(x->ends, y->ends, fragments * 4) && tier1_cfg_same_column(x->kinds, y->kinds, fragments) && tier1_cfg_same_column(x->registers, y->registers, fragments);
    differs = same || differs != 0 ? differs : 6;
    same = same && tier1_cfg_same_column(x->value_registers, y->value_registers, values) && tier1_cfg_same_column(x->spill_ids, y->spill_ids, values * 4) &&
           tier1_cfg_same_column(x->spill_values, y->spill_values, (uint64_t)x->spill_count * 4);
    differs = same || differs != 0 ? differs : 7;
    same = same && tier1_cfg_same_column(left->value_interval_offsets, right->value_interval_offsets, (values + 1) * 4);
    differs = same || differs != 0 ? differs : 8;
    same = same && tier1_cfg_same_column(left->edge_placements, right->edge_placements, edges) && tier1_cfg_same_column(left->edge_move_offsets, right->edge_move_offsets, (edges + 1) * 4);
    differs = same || differs != 0 ? differs : 9;
    same = same && left->move_count == right->move_count && tier1_cfg_same_column(left->move_sources, right->move_sources, (uint64_t)left->move_count * 4) &&
           tier1_cfg_same_column(left->move_destinations, right->move_destinations, (uint64_t)left->move_count * 4) && tier1_cfg_same_column(left->move_values, right->move_values, (uint64_t)left->move_count * 4);
    differs = same || differs != 0 ? differs : 10;
    same = same && left->split_count == right->split_count && left->split_edges == right->split_edges && tier1_cfg_same_column(left->split_positions, right->split_positions, (uint64_t)left->split_count * 4) &&
           tier1_cfg_same_column(left->split_move_offsets, right->split_move_offsets, ((uint64_t)left->split_count + 1) * 4);
    differs = same || differs != 0 ? differs : 11;
    same = same && left->cross_block_values == right->cross_block_values && left->edge_local_values == right->edge_local_values && left->liveness_bytes == right->liveness_bytes && left->live_entries == right->live_entries && left->temp_slots == right->temp_slots && left->liveness_iterations == right->liveness_iterations;
    differs = same || differs != 0 ? differs : 12;
    // The block column's rows: one per value with a base.
    uint64_t rows = 0;
    for (uint32_t v = 0; same && left->value_block_base != 0 && v < values; v += 1)
    {
        rows += left->value_block_base[v] != BUSTER_TIER1_CFG_NONE;
    }
    same = same && tier1_cfg_same_column(left->position_blocks, right->position_blocks, (uint64_t)input->position_count * 4) && tier1_cfg_same_column(left->value_block_base, right->value_block_base, values * 4) &&
           tier1_cfg_same_column(left->value_block_intervals, right->value_block_intervals, rows * input->block_count * 4);
    differs = same || differs != 0 ? differs : 13;
    return differs;
}

typedef struct Tier1CfgCheck Tier1CfgCheck;
struct Tier1CfgCheck
{
    // "ok", or the first failure, with its block, value and position where they apply.
    const char* reason;
    uint32_t block;
    uint32_t value;
    uint32_t position;
    uint64_t checks;
};

// The checker's locations: registers, slots, then the temporary slots. A stamp other than the current one means
// "unknown".
typedef struct Tier1CfgState Tier1CfgState;
struct Tier1CfgState
{
    uint32_t* values;
    uint32_t* stamps;
    uint32_t stamp;
    uint32_t count;
};

static uint32_t tier1_cfg_state_get(const Tier1CfgState* state, uint32_t location)
{
    return location < state->count && state->stamps[location] == state->stamp ? state->values[location] : BUSTER_TIER1_CFG_NONE;
}

static void tier1_cfg_state_set(Tier1CfgState* state, uint32_t location, uint32_t value)
{
    state->values[location] = value;
    state->stamps[location] = state->stamp;
}

static bool tier1_cfg_fail(Tier1CfgCheck* check, const char* reason, uint32_t block, uint32_t value, uint32_t position)
{
    if (check->reason == 0)
    {
        check->reason = reason;
        check->block = block;
        check->value = value;
        check->position = position;
    }
    return false;
}

// Whether a write of `location` at `position` would overwrite a value other than `value` that the allocation still
// keeps there: two live values in one register.
static bool tier1_cfg_clobbers(const Tier1CfgAllocation* result, const Tier1CfgState* state, uint32_t location, uint32_t value, uint32_t position)
{
    const uint32_t held = tier1_cfg_state_get(state, location);
    uint32_t where = 0;
    uint8_t kind = 0;
    return held != BUSTER_TIER1_CFG_NONE && held != value && held < result->intervals.value_count && tier1_cfg_location_oracle(result, held, position, &where, &kind) && where == location;
}

// One move of an edge or a split, applied to `state`: it must write a location of its value's class, a register only
// if the class may hold it there or it is the class's scratch, and read the value it says it carries, or recompute a
// value with a recipe. At a split (`position` inside a block) it mustn't land on a value the allocation still keeps
// in that location.
static bool tier1_cfg_apply(const Tier1CfgInput* input, const Tier1CfgAllocation* result, Tier1CfgState* state, uint32_t m, uint32_t block, uint32_t position, bool split, Tier1CfgCheck* check)
{
    const uint32_t from = result->move_sources[m];
    const uint32_t to = result->move_destinations[m];
    const uint32_t carried = result->move_values[m];
    const uint32_t class = carried < input->value_count ? input->classes[carried] : BUSTER_TIER1_CFG_NONE;
    const bool reg = to < BUSTER_TIER1_CFG_SPILL;
    const bool writable = !reg || (class < BUSTER_TIER1_ALLOCATE_CLASSES && (((input->registers[class] | UINT32_C(1) << input->scratch_registers[class]) >> (to % 32)) & 1) != 0);
    bool valid = (to < state->count && class != BUSTER_TIER1_CFG_NONE && tier1_cfg_location_class(input, result, to) == class && writable) || tier1_cfg_fail(check, "a move to no location of its value's class", block, carried, position);
    valid = valid && (!split || !tier1_cfg_clobbers(result, state, to, carried, position) || tier1_cfg_fail(check, "a split's move over another live value", block, carried, position));
    if (valid && from == BUSTER_TIER1_CFG_REMATERIALIZE)
    {
        valid = (input->rematerializable != 0 && input->rematerializable[carried] != 0) || tier1_cfg_fail(check, "a rematerialization without a recipe", block, carried, position);
        tier1_cfg_state_set(state, to, carried);
    }
    else if (valid)
    {
        const uint32_t moved = tier1_cfg_state_get(state, from);
        valid = (tier1_cfg_location_class(input, result, from) == class) || tier1_cfg_fail(check, "a move from no location of its value's class", block, carried, position);
        valid = valid && ((moved != BUSTER_TIER1_CFG_NONE && moved == carried) || tier1_cfg_fail(check, "a move that reads another value than it says it carries", block, carried, position));
        tier1_cfg_state_set(state, to, moved);
    }
    check->checks += 1;
    return valid;
}

// The allocation's columns, as the certificate's shape requires them (tier1_certificate_cfg.c), before anything reads
// through them: each present where its count needs it, the interval and fragment maps' ends, the slots' count within
// the values and each slot's value in range. What the columns' entries mean is left to the checks that read them.
static bool tier1_cfg_verify_columns(const Tier1CfgInput* input, const Tier1CfgAllocation* result)
{
    const Tier1AllocationInput* intervals = &result->intervals;
    const Tier1Allocation* allocation = &result->allocation;
    const uint32_t values = input->value_count;
    bool valid = result->value_interval_offsets != 0 && (intervals->count == 0 || (intervals->values != 0 && intervals->classes != 0 && intervals->starts != 0 && intervals->ends != 0));
    valid = valid && allocation->interval_count == intervals->count && allocation->fragment_offsets != 0 && allocation->fragment_offsets[0] == 0 && allocation->fragment_offsets[intervals->count] == allocation->fragment_count;
    valid = valid && (allocation->fragment_count == 0 || (allocation->starts != 0 && allocation->ends != 0 && allocation->kinds != 0 && allocation->registers != 0));
    valid = valid && allocation->spill_count <= values && (allocation->spill_count == 0 || (allocation->spill_values != 0 && allocation->spill_ids != 0));
    for (uint32_t s = 0; valid && s < allocation->spill_count; s += 1)
    {
        valid = allocation->spill_values[s] < values;
    }
    valid = valid && result->edge_move_offsets != 0 && result->split_move_offsets != 0 && result->edge_placements != 0;
    valid = valid && (result->move_count == 0 || (result->move_sources != 0 && result->move_destinations != 0 && result->move_values != 0));
    valid = valid && (result->split_count == 0 || result->split_positions != 0);
    return valid;
}

static __attribute__((unused)) bool tier1_cfg_verify(const Tier1CfgInput* input, const Tier1CfgAllocation* result, Arena* scratch, Tier1CfgCheck* check)
{
    const uint64_t saved = scratch->length;
    *check = (Tier1CfgCheck){ 0 };
    bool valid = tier1_cfg_input_valid(input, scratch) || tier1_cfg_fail(check, "invalid input", 0, 0, 0);
    valid = valid && (tier1_cfg_verify_columns(input, result) || tier1_cfg_fail(check, "the allocation's columns", 0, 0, 0));
    const uint32_t blocks = input->block_count;
    const uint32_t values = input->value_count;
    const Tier1Allocation* allocation = &result->allocation;
    const Tier1AllocationInput* intervals = &result->intervals;
    // Every value's intervals: its own, in position order, without overlap, each with fragments from start to end.
    valid = valid && ((result->value_interval_offsets[0] == 0 && result->value_interval_offsets[values] == intervals->count && allocation->interval_count == intervals->count) || tier1_cfg_fail(check, "interval map", 0, 0, 0));
    for (uint32_t v = 0; valid && v < values; v += 1)
    {
        // Each offset bounded before it bounds a read: a malformed allocation is refused, never read past its columns.
        valid = (result->value_interval_offsets[v] <= result->value_interval_offsets[v + 1] && result->value_interval_offsets[v + 1] <= intervals->count) || tier1_cfg_fail(check, "interval map", 0, v, 0);
        for (uint32_t i = result->value_interval_offsets[v]; valid && i < result->value_interval_offsets[v + 1]; i += 1)
        {
            valid = (intervals->values[i] == v && intervals->classes[i] == input->classes[v] && intervals->starts[i] < intervals->ends[i] && intervals->ends[i] <= input->position_count && (i == result->value_interval_offsets[v] || intervals->ends[i - 1] <= intervals->starts[i])) || tier1_cfg_fail(check, "an interval out of its value's order", 0, v, intervals->starts[i]);
            valid = valid && ((allocation->fragment_offsets[i] <= allocation->fragment_offsets[i + 1] && allocation->fragment_offsets[i + 1] <= allocation->fragment_count) || tier1_cfg_fail(check, "an interval's fragments past the allocation's", 0, v, intervals->starts[i]));
            uint32_t position = intervals->starts[i];
            for (uint32_t f = valid ? allocation->fragment_offsets[i] : 0; valid && f < allocation->fragment_offsets[i + 1]; f += 1)
            {
                const bool reg = allocation->kinds[f] == BUSTER_TIER1_ALLOCATE_REGISTER;
                valid = (allocation->starts[f] == position && allocation->ends[f] > position && allocation->kinds[f] <= BUSTER_TIER1_ALLOCATE_REMATERIALIZE) || tier1_cfg_fail(check, "fragments don't tile their interval", 0, v, position);
                valid = valid && ((!reg || (allocation->registers[f] < 32 && ((input->allowed_registers[v] >> allocation->registers[f]) & 1) != 0)) || tier1_cfg_fail(check, "a register outside the value's mask", 0, v, position));
                valid = valid && (reg || allocation->registers[f] == UINT8_MAX || tier1_cfg_fail(check, "a register on a fragment without one", 0, v, position));
                // The definition's fragment in one of its registers.
                const uint32_t defined = input->definition_registers != 0 ? input->definition_registers[v] : 0;
                const bool defines = allocation->starts[f] <= input->definitions[v] && input->definitions[v] < allocation->ends[f];
                valid = valid && ((defined == 0 || !defines || (reg && ((defined >> allocation->registers[f]) & 1) != 0)) || tier1_cfg_fail(check, "a definition outside its registers", 0, v, position));
                // A slot of the value's class: values of one class may share it (tier1_cfg_share_slots).
                valid = valid && ((allocation->kinds[f] != BUSTER_TIER1_ALLOCATE_SPILL || (allocation->spill_count != 0 && allocation->spill_ids[v] < allocation->spill_count && input->classes[allocation->spill_values[allocation->spill_ids[v]]] == input->classes[v])) || tier1_cfg_fail(check, "a spill without a slot", 0, v, position));
                valid = valid && ((allocation->kinds[f] != BUSTER_TIER1_ALLOCATE_REMATERIALIZE || (input->rematerializable != 0 && input->rematerializable[v] != 0)) || tier1_cfg_fail(check, "a rematerialization of a value without a recipe", 0, v, position));
                position = allocation->ends[f];
            }
            valid = valid && ((position == intervals->ends[i]) || tier1_cfg_fail(check, "fragments don't reach their interval's end", 0, v, position));
        }
    }
    // The moves: every edge's, then every split's, each split at a position strictly inside a block, in order.
    valid = valid && ((result->edge_move_offsets[0] == 0 && result->edge_move_offsets[input->edge_count] == result->split_move_offsets[0] && result->split_move_offsets[result->split_count] == result->move_count) || tier1_cfg_fail(check, "the moves' extents", 0, 0, 0));
    for (uint32_t e = 0; valid && e < input->edge_count; e += 1)
    {
        valid = result->edge_move_offsets[e] <= result->edge_move_offsets[e + 1] || tier1_cfg_fail(check, "an edge's moves out of order", 0, 0, 0);
    }
    for (uint32_t k = 0; valid && k < result->split_count; k += 1)
    {
        const uint32_t q = result->split_positions[k];
        valid = (q < input->position_count && (k == 0 || q > result->split_positions[k - 1]) && input->block_starts[tier1_cfg_block_of(input, q)] != q && result->split_move_offsets[k] <= result->split_move_offsets[k + 1]) || tier1_cfg_fail(check, "a split out of order or at a block's start", 0, 0, q);
    }
    // Every phi operand's predecessor, by value (counted, then filled), and which values are phis.
    uint32_t* pass_offsets = valid ? arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* pass_blocks = valid ? arena_push_array(scratch, (uint64_t)input->phi_operand_offsets[input->phi_count] + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint8_t* is_phi = valid ? arena_push(scratch, (uint64_t)values + 1, 1) : 0;
    valid = valid && ((pass_offsets != 0 && pass_blocks != 0 && is_phi != 0) || tier1_cfg_fail(check, "checker memory", 0, 0, 0));
    if (valid)
    {
        memset(pass_offsets, 0, ((uint64_t)values + 1) * sizeof(uint32_t));
        memset(is_phi, 0, (uint64_t)values + 1);
        for (uint32_t pass = 0; pass < 2; pass += 1)
        {
            for (uint32_t b = 0; b < blocks; b += 1)
            {
                for (uint32_t k = input->phi_offsets[b]; k < input->phi_offsets[b + 1]; k += 1)
                {
                    is_phi[input->phi_values[k]] = 1;
                    for (uint32_t j = 0; j < input->phi_operand_offsets[k + 1] - input->phi_operand_offsets[k]; j += 1)
                    {
                        const uint32_t operand = input->phi_operands[input->phi_operand_offsets[k] + j];
                        if (operand == BUSTER_TIER1_CFG_NONE)
                        {
                        }
                        else if (pass == 0)
                        {
                            pass_offsets[operand + 1] += 1;
                        }
                        else
                        {
                            pass_blocks[pass_offsets[operand]] = input->predecessors[input->predecessor_offsets[b] + j];
                            pass_offsets[operand] += 1;
                        }
                    }
                }
            }
            if (pass == 0)
            {
                for (uint32_t v = 0; v < values; v += 1)
                {
                    pass_offsets[v + 1] += pass_offsets[v];
                }
            }
            else
            {
                // The fill advanced each start to its end: shift them back.
                for (uint32_t v = values; v > 0; v -= 1)
                {
                    pass_offsets[v] = pass_offsets[v - 1];
                }
                pass_offsets[0] = 0;
            }
        }
    }
    // Liveness by walking every use back to its definition: live-in pairs, counted, then filled.
    uint32_t* home = valid ? arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* marks = valid ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* stack = valid ? arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* live_offsets = valid ? arena_push_array(scratch, (uint64_t)blocks + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    valid = valid && ((home != 0 && marks != 0 && stack != 0 && live_offsets != 0) || tier1_cfg_fail(check, "checker memory", 0, 0, 0));
    uint32_t* live = 0;
    for (uint32_t pass = 0; valid && pass < 2; pass += 1)
    {
        uint32_t* fill = 0;
        if (pass == 0)
        {
            memset(live_offsets, 0, ((uint64_t)blocks + 1) * sizeof(uint32_t));
            for (uint32_t v = 0; v < values; v += 1)
            {
                home[v] = tier1_cfg_block_of(input, input->definitions[v]);
            }
        }
        else
        {
            for (uint32_t b = 0; b < blocks; b += 1)
            {
                live_offsets[b + 1] += live_offsets[b];
            }
            live = arena_push_array(scratch, (uint64_t)live_offsets[blocks] + 1, sizeof(uint32_t), _Alignof(uint32_t));
            fill = arena_push_array(scratch, blocks, sizeof(uint32_t), _Alignof(uint32_t));
            valid = (live != 0 && fill != 0) || tier1_cfg_fail(check, "checker memory", 0, 0, 0);
            for (uint32_t b = 0; valid && b < blocks; b += 1)
            {
                fill[b] = live_offsets[b];
            }
        }
        memset(marks, 0xff, (uint64_t)blocks * sizeof(uint32_t));
        for (uint32_t v = 0; valid && v < values; v += 1)
        {
            uint32_t depth = 0;
            // Seeds: ordinary uses outside the home block, and every predecessor that passes v to a phi.
            for (uint32_t u = input->use_offsets[v]; u < input->use_offsets[v + 1]; u += 1)
            {
                const uint32_t b = tier1_cfg_block_of(input, input->use_positions[u]);
                if (b != home[v] && marks[b] != v)
                {
                    marks[b] = v;
                    stack[depth] = b;
                    depth += 1;
                }
            }
            for (uint32_t i = pass_offsets[v]; i < pass_offsets[v + 1]; i += 1)
            {
                const uint32_t p = pass_blocks[i];
                if (p != home[v] && marks[p] != v)
                {
                    marks[p] = v;
                    stack[depth] = p;
                    depth += 1;
                }
            }
            // Each marked block is live-in; walk its predecessors until the home block.
            while (valid && depth != 0)
            {
                depth -= 1;
                const uint32_t b = stack[depth];
                valid = b != 0 || tier1_cfg_fail(check, "a value live into the entry", 0, v, 0);
                if (pass == 0)
                {
                    live_offsets[b + 1] += 1;
                }
                else
                {
                    live[fill[b]] = v;
                    fill[b] += 1;
                }
                for (uint32_t e = input->predecessor_offsets[b]; valid && e < input->predecessor_offsets[b + 1]; e += 1)
                {
                    const uint32_t q = input->predecessors[e];
                    if (q != home[v] && marks[q] != v)
                    {
                        marks[q] = v;
                        stack[depth] = q;
                        depth += 1;
                    }
                }
                check->checks += 1;
            }
        }
    }
    // Events by position: fragment transitions, uses, clobbers and definitions (counted, then filled).
    uint32_t* event_offsets = valid ? arena_push_array(scratch, (uint64_t)input->position_count + 2, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    valid = valid && ((event_offsets != 0) || tier1_cfg_fail(check, "checker memory", 0, 0, 0));
    uint32_t* events = 0;
    uint32_t* event_fill = 0;
    for (uint32_t pass = 0; valid && pass < 2; pass += 1)
    {
        if (pass == 0)
        {
            memset(event_offsets, 0, ((uint64_t)input->position_count + 2) * sizeof(uint32_t));
        }
        else
        {
            for (uint32_t q = 0; q <= input->position_count; q += 1)
            {
                event_offsets[q + 1] += event_offsets[q];
            }
            events = arena_push_array(scratch, (uint64_t)event_offsets[input->position_count] * 2 + 2, sizeof(uint32_t), _Alignof(uint32_t));
            event_fill = arena_push_array(scratch, (uint64_t)input->position_count + 1, sizeof(uint32_t), _Alignof(uint32_t));
            valid = (events != 0 && event_fill != 0) || tier1_cfg_fail(check, "checker memory", 0, 0, 0);
            for (uint32_t q = 0; valid && q < input->position_count; q += 1)
            {
                event_fill[q] = event_offsets[q];
            }
        }
        // Kinds: 0 transition (fragment f), 1 use (use u), 2 clobber (fixed range r), 3 definition (value v), 4 the
        // start of a piece of a range cut inside its block (interval i).
        for (uint32_t i = 0; valid && i < intervals->count; i += 1)
        {
            for (uint32_t f = allocation->fragment_offsets[i] + 1; f < allocation->fragment_offsets[i + 1]; f += 1)
            {
                const uint32_t q = allocation->starts[f];
                if (pass == 0)
                {
                    event_offsets[q + 1] += 1;
                }
                else
                {
                    events[(uint64_t)event_fill[q] * 2] = 0;
                    events[(uint64_t)event_fill[q] * 2 + 1] = f;
                    event_fill[q] += 1;
                }
            }
        }
        for (uint32_t v = 0; valid && v < values; v += 1)
        {
            for (uint32_t u = input->use_offsets[v]; u < input->use_offsets[v + 1]; u += 1)
            {
                const uint32_t q = input->use_positions[u];
                if (pass == 0)
                {
                    event_offsets[q + 1] += 1;
                }
                else
                {
                    events[(uint64_t)event_fill[q] * 2] = 1;
                    events[(uint64_t)event_fill[q] * 2 + 1] = u;
                    event_fill[q] += 1;
                }
            }
        }
        for (uint32_t r = 0; valid && r < input->fixed.count; r += 1)
        {
            const uint32_t q = input->fixed.starts[r];
            if (pass == 0)
            {
                event_offsets[q + 1] += 1;
            }
            else
            {
                events[(uint64_t)event_fill[q] * 2] = 2;
                events[(uint64_t)event_fill[q] * 2 + 1] = r;
                event_fill[q] += 1;
            }
        }
        for (uint32_t v = 0; valid && v < values; v += 1)
        {
            const uint32_t q = input->definitions[v];
            if (is_phi[v] == 0 && pass == 0)
            {
                event_offsets[q + 1] += 1;
            }
            else if (is_phi[v] == 0)
            {
                events[(uint64_t)event_fill[q] * 2] = 3;
                events[(uint64_t)event_fill[q] * 2 + 1] = v;
                event_fill[q] += 1;
            }
        }
        // An interval that starts neither at its value's definition nor at its block's start: a piece of a range cut
        // around a fixed range, which a split's moves bring its value to.
        for (uint32_t i = 0; valid && i < intervals->count; i += 1)
        {
            const uint32_t q = intervals->starts[i];
            if (q != input->definitions[intervals->values[i]] && input->block_starts[tier1_cfg_block_of(input, q)] != q)
            {
                if (pass == 0)
                {
                    event_offsets[q + 1] += 1;
                }
                else
                {
                    events[(uint64_t)event_fill[q] * 2] = 4;
                    events[(uint64_t)event_fill[q] * 2 + 1] = i;
                    event_fill[q] += 1;
                }
            }
        }
    }
    // The value of each use, and the interval of each fragment.
    uint32_t* use_values = valid ? arena_push_array(scratch, (uint64_t)input->use_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    uint32_t* fragment_intervals = valid ? arena_push_array(scratch, (uint64_t)allocation->fragment_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    valid = valid && ((use_values != 0 && fragment_intervals != 0) || tier1_cfg_fail(check, "checker memory", 0, 0, 0));
    for (uint32_t v = 0; valid && v < values; v += 1)
    {
        for (uint32_t u = input->use_offsets[v]; u < input->use_offsets[v + 1]; u += 1)
        {
            use_values[u] = v;
        }
    }
    for (uint32_t i = 0; valid && i < intervals->count; i += 1)
    {
        for (uint32_t f = allocation->fragment_offsets[i]; f < allocation->fragment_offsets[i + 1]; f += 1)
        {
            fragment_intervals[f] = i;
        }
    }
    const uint32_t locations = BUSTER_TIER1_CFG_SPILL + allocation->spill_count + BUSTER_TIER1_ALLOCATE_CLASSES;
    Tier1CfgState state = {
        .count = locations,
    };
    Tier1CfgState edge = {
        .count = locations,
    };
    state.values = valid ? arena_push_array(scratch, locations, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    state.stamps = valid ? arena_push_array(scratch, locations, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    edge.values = valid ? arena_push_array(scratch, locations, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    edge.stamps = valid ? arena_push_array(scratch, locations, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    valid = valid && ((state.values != 0 && state.stamps != 0 && edge.values != 0 && edge.stamps != 0) || tier1_cfg_fail(check, "checker memory", 0, 0, 0));
    if (valid)
    {
        memset(state.stamps, 0, (uint64_t)locations * sizeof(uint32_t));
        memset(edge.stamps, 0, (uint64_t)locations * sizeof(uint32_t));
    }
    // The slots the allocation asserts current at each block's start (tier1_cfg_current_slots, #2553): each a value live
    // into the block, in its own slot there, which every edge into the block must bring, and none at a block no edge
    // enters. `entered` stamps the values live into the block being checked.
    const uint32_t* current_offsets = result->current_slot_offsets;
    uint32_t* entered = valid ? arena_push_array(scratch, (uint64_t)values + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    valid = valid && (entered != 0 || tier1_cfg_fail(check, "checker memory", 0, 0, 0));
    valid = valid && (current_offsets == 0 || (result->current_slots != 0 && current_offsets[0] == 0) || tier1_cfg_fail(check, "the current slots' columns", 0, 0, 0));
    for (uint32_t b = 0; valid && current_offsets != 0 && b < blocks; b += 1)
    {
        const bool reached = b != 0 && input->predecessor_offsets[b] != input->predecessor_offsets[b + 1];
        valid = (current_offsets[b] <= current_offsets[b + 1] && (reached || current_offsets[b] == current_offsets[b + 1])) || tier1_cfg_fail(check, "a current slot at a block no edge enters", b, 0, input->block_starts[b]);
    }
    if (valid)
    {
        memset(entered, 0, ((uint64_t)values + 1) * sizeof(uint32_t));
    }
    uint32_t split = 0;
    for (uint32_t b = 0; valid && b < blocks; b += 1)
    {
        const uint32_t entry = input->block_starts[b];
        state.stamp += 1;
        // The entry state: the live-in values and the phis where the allocation keeps them at the block's start.
        const uint32_t phi_first = input->phi_offsets[b];
        const uint32_t phi_end = input->phi_offsets[b + 1];
        for (uint32_t i = live_offsets[b]; valid && i < live_offsets[b + 1] + (phi_end - phi_first); i += 1)
        {
            const uint32_t v = i < live_offsets[b + 1] ? live[i] : input->phi_values[phi_first + i - live_offsets[b + 1]];
            uint32_t location = 0;
            uint8_t kind = 0;
            valid = tier1_cfg_entry_location_oracle(result, v, entry, &location, &kind) || tier1_cfg_fail(check, "a value live at a block's start without a location", b, v, entry);
            if (valid && kind != BUSTER_TIER1_ALLOCATE_REMATERIALIZE)
            {
                valid = tier1_cfg_state_get(&state, location) == BUSTER_TIER1_CFG_NONE || tier1_cfg_fail(check, "two values live in one location at a block's start", b, v, entry);
                tier1_cfg_state_set(&state, location, v);
            }
            if (i < live_offsets[b + 1])
            {
                entered[v] = b + 1;
            }
            check->checks += 1;
        }
        for (uint32_t k = current_offsets != 0 ? current_offsets[b] : 0; valid && current_offsets != 0 && k < current_offsets[b + 1]; k += 1)
        {
            const uint32_t v = result->current_slots[k];
            valid = (v < values && entered[v] == b + 1 && allocation->spill_ids[v] < allocation->spill_count) || tier1_cfg_fail(check, "a current slot of a value not live into its block", b, v, entry);
            const uint32_t slot = valid ? BUSTER_TIER1_CFG_SPILL + allocation->spill_ids[v] : 0;
            const uint32_t held = valid ? tier1_cfg_state_get(&state, slot) : BUSTER_TIER1_CFG_NONE;
            valid = valid && ((held == BUSTER_TIER1_CFG_NONE || held == v) || tier1_cfg_fail(check, "two values live in one location at a block's start", b, v, entry));
            if (valid)
            {
                tier1_cfg_state_set(&state, slot, v);
            }
            check->checks += 1;
        }
        for (uint32_t q = entry; valid && q < input->block_starts[b + 1]; q += 1)
        {
            // Stores, then a split's moves, then loads and rematerializations, uses, clobbers and definitions.
            for (uint32_t step = 0; valid && step < 5; step += 1)
            {
                if (step == 1 && split < result->split_count && result->split_positions[split] == q)
                {
                    for (uint32_t m = result->split_move_offsets[split]; valid && m < result->split_move_offsets[split + 1]; m += 1)
                    {
                        valid = tier1_cfg_apply(input, result, &state, m, b, q, true, check);
                    }
                    split += 1;
                }
                for (uint32_t e = event_offsets[q]; valid && e < event_offsets[q + 1]; e += 1)
                {
                    const uint32_t kind = events[(uint64_t)e * 2];
                    const uint32_t item = events[(uint64_t)e * 2 + 1];
                    if (kind == 0 && (step == 0 || step == 1))
                    {
                        const uint32_t f = item;
                        const uint32_t interval = fragment_intervals[f];
                        const uint32_t v = intervals->values[interval];
                        const uint32_t class = intervals->classes[interval];
                        const uint8_t previous = allocation->kinds[f - 1];
                        const uint8_t current = allocation->kinds[f];
                        const uint32_t slot = BUSTER_TIER1_CFG_SPILL + allocation->spill_ids[v];
                        if (step == 0 && current == BUSTER_TIER1_ALLOCATE_SPILL)
                        {
                            valid = (previous == BUSTER_TIER1_ALLOCATE_REGISTER && tier1_cfg_state_get(&state, class * 32 + allocation->registers[f - 1]) == v) || tier1_cfg_fail(check, "a store of a register that doesn't hold its value", b, v, q);
                            valid = valid && (!tier1_cfg_clobbers(result, &state, slot, v, q) || tier1_cfg_fail(check, "a store over another live value", b, v, q));
                            tier1_cfg_state_set(&state, slot, v);
                        }
                        else if (step == 1 && current == BUSTER_TIER1_ALLOCATE_REGISTER)
                        {
                            const uint32_t target = class * 32 + allocation->registers[f];
                            const uint32_t from = previous == BUSTER_TIER1_ALLOCATE_SPILL ? slot : previous == BUSTER_TIER1_ALLOCATE_REGISTER ? class * 32 + allocation->registers[f - 1] : BUSTER_TIER1_CFG_REMATERIALIZE;
                            valid = (from == BUSTER_TIER1_CFG_REMATERIALIZE || tier1_cfg_state_get(&state, from) == v) || tier1_cfg_fail(check, "a reload from a location that doesn't hold its value", b, v, q);
                            valid = valid && (!tier1_cfg_clobbers(result, &state, target, v, q) || tier1_cfg_fail(check, "a reload over another live value", b, v, q));
                            tier1_cfg_state_set(&state, target, v);
                        }
                        check->checks += 1;
                    }
                    else if (kind == 1 && step == 4 && q == input->definitions[use_values[item]] && is_phi[use_values[item]] == 0)
                    {
                        // The definition's own use: where the definition puts the value, a register if it's required.
                        const uint32_t v = use_values[item];
                        uint32_t location = 0;
                        uint8_t where = 0;
                        valid = tier1_cfg_location_oracle(result, v, q, &location, &where) || tier1_cfg_fail(check, "a definition outside its value's intervals", b, v, q);
                        valid = valid && ((where == BUSTER_TIER1_ALLOCATE_REGISTER || input->use_required == 0 || input->use_required[item] == 0) || tier1_cfg_fail(check, "a required definition without a register", b, v, q));
                        check->checks += 1;
                    }
                    else if (kind == 1 && step == 2 && (q != input->definitions[use_values[item]] || is_phi[use_values[item]] != 0))
                    {
                        const uint32_t v = use_values[item];
                        uint32_t location = 0;
                        uint8_t where = 0;
                        valid = tier1_cfg_location_oracle(result, v, q, &location, &where) || tier1_cfg_fail(check, "a use outside its value's intervals", b, v, q);
                        if (valid && where == BUSTER_TIER1_ALLOCATE_REMATERIALIZE)
                        {
                            valid = (input->use_required == 0 || input->use_required[item] == 0) || tier1_cfg_fail(check, "a required use without a register", b, v, q);
                        }
                        else if (valid)
                        {
                            valid = tier1_cfg_state_get(&state, location) == v || tier1_cfg_fail(check, "a use that finds another value", b, v, q);
                            valid = valid && ((where == BUSTER_TIER1_ALLOCATE_REGISTER || input->use_required == 0 || input->use_required[item] == 0) || tier1_cfg_fail(check, "a required use without a register", b, v, q));
                        }
                        check->checks += 1;
                    }
                    else if (kind == 2 && step == 3)
                    {
                        const uint32_t class = input->fixed.classes[item];
                        for (uint32_t r = 0; r < 32; r += 1)
                        {
                            if (((input->fixed.registers[item] >> r) & 1) != 0)
                            {
                                valid = valid && (!tier1_cfg_clobbers(result, &state, class * 32 + r, BUSTER_TIER1_CFG_NONE, q) || tier1_cfg_fail(check, "a fixed range over a live value", b, BUSTER_TIER1_CFG_NONE, q));
                                tier1_cfg_state_set(&state, class * 32 + r, BUSTER_TIER1_CFG_NONE - 1);
                            }
                        }
                        check->checks += 1;
                    }
                    else if (kind == 4 && step == 1)
                    {
                        // A cut piece's value where the piece's first fragment keeps it, now that the split's moves
                        // have run: no use may read that piece, which would leave a move to the wrong location unseen.
                        const uint32_t v = intervals->values[item];
                        uint32_t location = 0;
                        uint8_t where = 0;
                        valid = tier1_cfg_location_oracle(result, v, q, &location, &where) || tier1_cfg_fail(check, "a piece outside its value's intervals", b, v, q);
                        valid = valid && (where == BUSTER_TIER1_ALLOCATE_REMATERIALIZE || tier1_cfg_state_get(&state, location) == v || tier1_cfg_fail(check, "a split that doesn't bring a value to its piece", b, v, q));
                        check->checks += 1;
                    }
                    else if (kind == 3 && step == 4)
                    {
                        const uint32_t v = item;
                        uint32_t location = 0;
                        uint8_t where = 0;
                        valid = tier1_cfg_location_oracle(result, v, q, &location, &where) || tier1_cfg_fail(check, "a definition outside its value's intervals", b, v, q);
                        if (valid && where != BUSTER_TIER1_ALLOCATE_REMATERIALIZE)
                        {
                            valid = !tier1_cfg_clobbers(result, &state, location, v, q) || tier1_cfg_fail(check, "a definition over another live value", b, v, q);
                            tier1_cfg_state_set(&state, location, v);
                        }
                        check->checks += 1;
                    }
                }
            }
        }
        // Each edge: the predecessor's final state, its moves in order, then the successor's entry expectations.
        for (uint32_t e = input->successor_offsets[b]; valid && e < input->successor_offsets[b + 1]; e += 1)
        {
            const uint32_t s = input->successors[e];
            const uint32_t s_entry = input->block_starts[s];
            const uint32_t moves = result->edge_move_offsets[e + 1] - result->edge_move_offsets[e];
            const uint32_t out_degree = input->successor_offsets[b + 1] - input->successor_offsets[b];
            const uint32_t in_degree = input->predecessor_offsets[s + 1] - input->predecessor_offsets[s];
            const uint8_t placement = result->edge_placements[e];
            const bool copies = input->edge_copies != 0 && input->edge_copies[e] != 0;
            valid = ((moves == 0 && !copies) == (placement == TIER1_CFG_EDGE_EMPTY)) || tier1_cfg_fail(check, "an edge's placement disagrees with its moves", b, BUSTER_TIER1_CFG_NONE, s_entry);
            valid = valid && ((placement != TIER1_CFG_EDGE_PREDECESSOR || out_degree == 1) || tier1_cfg_fail(check, "moves at the end of a block with several successors", b, BUSTER_TIER1_CFG_NONE, s_entry));
            valid = valid && ((placement != TIER1_CFG_EDGE_SUCCESSOR || in_degree == 1) || tier1_cfg_fail(check, "moves at the start of a block with several predecessors", b, BUSTER_TIER1_CFG_NONE, s_entry));
            edge.stamp = state.stamp;
            memcpy(edge.values, state.values, (uint64_t)locations * sizeof(uint32_t));
            memcpy(edge.stamps, state.stamps, (uint64_t)locations * sizeof(uint32_t));
            for (uint32_t m = result->edge_move_offsets[e]; valid && m < result->edge_move_offsets[e + 1]; m += 1)
            {
                valid = tier1_cfg_apply(input, result, &edge, m, b, s_entry, false, check);
            }
            uint32_t j = 0;
            while (valid && input->predecessors[input->predecessor_offsets[s] + j] != b)
            {
                j += 1;
            }
            const uint32_t s_phis = input->phi_offsets[s + 1] - input->phi_offsets[s];
            for (uint32_t i = live_offsets[s]; valid && i < live_offsets[s + 1] + s_phis; i += 1)
            {
                const bool phi = i >= live_offsets[s + 1];
                const uint32_t k = phi ? input->phi_offsets[s] + i - live_offsets[s + 1] : 0;
                const uint32_t v = phi ? input->phi_values[k] : live[i];
                const uint32_t expected = phi ? input->phi_operands[input->phi_operand_offsets[k] + j] : v;
                // An undefined operand: whatever the phi's location holds is its value along the edge.
                const bool undefined = expected == BUSTER_TIER1_CFG_NONE;
                uint32_t location = 0;
                uint8_t kind = 0;
                valid = tier1_cfg_entry_location_oracle(result, v, s_entry, &location, &kind) || tier1_cfg_fail(check, "a value live at a block's start without a location", s, v, s_entry);
                if (valid && kind == BUSTER_TIER1_ALLOCATE_REMATERIALIZE)
                {
                    valid = (!phi && input->rematerializable != 0 && input->rematerializable[v] != 0) || tier1_cfg_fail(check, "a phi without a location", s, v, s_entry);
                }
                else if (valid)
                {
                    valid = undefined || tier1_cfg_state_get(&edge, location) == expected || tier1_cfg_fail(check, phi ? "an edge that doesn't bring a phi its operand" : "an edge that doesn't bring a live value", s, v, s_entry);
                }
                check->checks += 1;
            }
            for (uint32_t k = current_offsets != 0 ? current_offsets[s] : 0; valid && current_offsets != 0 && k < current_offsets[s + 1]; k += 1)
            {
                const uint32_t v = result->current_slots[k];
                const bool slotted = v < values && allocation->spill_ids[v] < allocation->spill_count;
                valid = (slotted && tier1_cfg_state_get(&edge, BUSTER_TIER1_CFG_SPILL + allocation->spill_ids[v]) == v) || tier1_cfg_fail(check, "an edge that doesn't bring a current slot", s, v, s_entry);
                check->checks += 1;
            }
        }
    }
    valid = valid && (split == result->split_count || tier1_cfg_fail(check, "a split the blocks never reach", 0, 0, 0));
    if (valid)
    {
        check->reason = "ok";
    }
    arena_pop_to(scratch, saved);
    return valid;
}

