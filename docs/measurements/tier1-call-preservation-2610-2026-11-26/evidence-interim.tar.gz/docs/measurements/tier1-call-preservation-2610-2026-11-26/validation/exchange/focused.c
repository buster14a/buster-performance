#define BUSTER_UNIT BUSTER_UNIT_BACKEND
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
//
// The executable's entry point, main, which includes most of the compiler and all of its tests. build.sh compiles this
// file once per unit, in parallel, so that the build waits for the largest unit rather than for all of this code in one
// clang process (#270): main.c alone is the driver's unit, and each main_unit_*.c names another unit and includes this
// file. Shared interfaces and fixtures are read by their consumers; private implementation and independent tests
// stay with the units that use them, keeping their parsing and edit dependencies there. Each command first tests its
// unit (and an independent test's branch is included with its test), so the other units' branches fold to false. Clang
// emits a static function only once emitted code refers to it, and emits none of theirs. main, in the driver's unit, asks
// each other unit for the command in turn, then its own commands, then runs the compiler itself.
//
// The modules that several units' commands run compile in one unit alone, their home, which the others call (#270):
// the lexer in the driver's unit, the preprocessor and the parser in the front end's, and the linker's (the runtime's
// import and binding, a PIE's inputs and the executable writer) in the dynamic PIEs' unit. A module's entry points
// take its macro (BUSTER_LEXER_ENTRY and the others, below) where its other functions take static: in the home it is
// nothing, so that they have external linkage there, and in the other units BUSTER_ELSEWHERE, which makes their
// definitions inline ones that are never inlined, which clang doesn't emit: their calls go to the home's, and the
// static functions that only the entry points reach aren't emitted there either. A unit without main.c, a benchmark's,
// has them static. The parser, preprocessor and executable writer expose declarations to other units; their bodies
// stay with their existing homes and direct private consumers, and the complete driver's (below). A command
// whose code calls a home's entry point runs in two units' copies of the code, so a home's code must share no static
// variable with its callers' units: main.c's units have one lane context (lane.c), and ./build.sh check-call-graph
// checks the rest (call_graph.c).
#define BUSTER_UNIT_DRIVER 0
#define BUSTER_UNIT_X86 1
#define BUSTER_UNIT_FRONTEND 2
#define BUSTER_UNIT_ASSEMBLER 3
#define BUSTER_UNIT_LINK 4
#define BUSTER_UNIT_EXECUTABLE 5
#define BUSTER_UNIT_DYNAMIC 6
#define BUSTER_UNIT_TYPES 7
#define BUSTER_UNIT_BACKEND 8
#define BUSTER_UNIT_CHECKER 9
#define BUSTER_UNIT_CHECK_BUILTINS 10
#ifndef BUSTER_UNIT
#define BUSTER_UNIT BUSTER_UNIT_DRIVER
#endif
#define BUSTER_IN_UNIT(unit) (BUSTER_UNIT == (unit))
// Source checking is emitted only in CHECKER; code generation also has consumers in BACKEND. The backend and
// builtin tests share semantic actions without the source reader, graph or lowering. The complete driver is DRIVER
// with the whole compiler as well: the source, checker and code-generation consumers and the preprocessor's and
// executable writer's private bodies, which other units own. A fuzz build's callbacks run in DRIVER and need it,
// including a custom callback's access to the normal compiler modules; the self-tests and benchmarks that take main.c
// as their input pass -DBUSTER_COMPLETE_DRIVER=1 to read all of the compiler's code, not only what DRIVER emits. An
// ordinary build passes neither, and the other units ignore both.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER) && (BUSTER_FUZZ_AVAILABLE || BUSTER_COMPLETE_DRIVER)
#undef BUSTER_COMPLETE_DRIVER
#define BUSTER_COMPLETE_DRIVER 1
#else
#undef BUSTER_COMPLETE_DRIVER
#define BUSTER_COMPLETE_DRIVER 0
#endif
#define BUSTER_SOURCE_CONSUMER (BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER) || BUSTER_COMPLETE_DRIVER)
#define BUSTER_BACKEND_CONSUMER (BUSTER_SOURCE_CONSUMER || BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND))
#define BUSTER_CHECKER_CONSUMER (BUSTER_BACKEND_CONSUMER || BUSTER_IN_UNIT(BUSTER_UNIT_CHECK_BUILTINS))

// An entry point in a unit that isn't its module's home: an inline definition, which clang emits only to inline it,
// and noinline keeps it from that, so that the unit's calls go to the home's external definition. Calling the module's
// static functions from it is a C2y feature that clang takes in C17 as an extension (-Wstatic-in-inline): the
// definition is only ever compiled in its home.
#define BUSTER_ELSEWHERE inline __attribute__((noinline))
#pragma clang diagnostic ignored "-Wstatic-in-inline"
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#define BUSTER_HOME_DRIVER
#else
#define BUSTER_HOME_DRIVER BUSTER_ELSEWHERE
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#define BUSTER_HOME_FRONTEND
#else
#define BUSTER_HOME_FRONTEND BUSTER_ELSEWHERE
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_DYNAMIC)
#define BUSTER_HOME_DYNAMIC
#else
#define BUSTER_HOME_DYNAMIC BUSTER_ELSEWHERE
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#define BUSTER_HOME_CHECKER
#else
#define BUSTER_HOME_CHECKER BUSTER_ELSEWHERE
#endif
// The modules' homes (at the top): the lexer's (c_lexer.c), the preprocessor's (c_preprocessor.c), the parser's
// (c_parser.c) and the linker's (link.c's); and the checker's, for the IR's commands on real C (ir_source_test.c's
// ir_source_prepare, the driver's check and emission of a file), which the backend's unit runs with the IR (#784).
#define BUSTER_LEXER_ENTRY BUSTER_HOME_DRIVER
#if BUSTER_COMPLETE_DRIVER
#define BUSTER_PREPROCESSOR_ENTRY BUSTER_HOME_FRONTEND
#else
#define BUSTER_PREPROCESSOR_ENTRY
#endif
// Parser bodies are included only by their frontend home; the other units use these external declarations.
#define BUSTER_PARSER_ENTRY
#define BUSTER_LINKER_ENTRY BUSTER_HOME_DYNAMIC
#define BUSTER_IR_SOURCE_ENTRY BUSTER_HOME_CHECKER

// The ISA requirement tables are immutable and need no initialization. Share their frontend copy without sharing
// encoder storage or adding calls/loads to the local table-building kernels. Standalone inclusions stay static.
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#define BUSTER_X86_TARGET_DATA __attribute__((visibility("hidden")))
#else
#define BUSTER_X86_TARGET_DATA static
#endif
// So are the option spellings (c_option_table.c): a compile reads them in the driver's, the front end's and the
// checker's units, from the front end's copy.
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#define BUSTER_C_OPTION_DATA __attribute__((visibility("hidden")))
#else
#define BUSTER_C_OPTION_DATA_ELSEWHERE
#endif

#include <stdint.h>
#include <inttypes.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include <assert.h>
#include <errno.h>

#define BUSTER_ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))
#define BUSTER_COMPILE_TIME_STRING_LENGTH(strlit) (BUSTER_ARRAY_LENGTH(strlit) - 1)
#define BUSTER_S8_INIT(strlit) {.pointer = (char*)(strlit), .length = BUSTER_COMPILE_TIME_STRING_LENGTH(strlit)}
#define BUSTER_S8(strlit) ((String8)BUSTER_S8_INIT(strlit))

// OS-dependent includes
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>

// CPU architecture dependent includes
#include "host_isa.h"

#include "buster/compiler/c_lexer.c"

#include "buster/compiler/string8.h"

// The tests' normalized temporary directory, for the test files and benchmarks that build their trees from it.
#include "buster/compiler/test_paths.h"

// The external tools the cross-checks spawn, probed once per command (#1129), and their tests, for the test-tool command.
// Every test file after this point sees its types and functions.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER) || BUSTER_IN_UNIT(BUSTER_UNIT_TYPES) || BUSTER_IN_UNIT(BUSTER_UNIT_X86) || BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND) || BUSTER_IN_UNIT(BUSTER_UNIT_LINK) || BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/test_tool.c"
#endif

// The lexer benchmark is a separate translation unit, linked into the compiler executable.
int run_c_lexer_benchmark(int argc, char** argv);

// The lexer tests, for the test-lexer command.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/c_lexer_test.c"
#endif

// The x86-64 encoder and its tests, for the test-x86-encoder command. Its benchmark is another translation unit.
#undef BUSTER_UNIT
#include "buster/compiler/x86_64_encoder.c"
#define BUSTER_UNIT BUSTER_UNIT_BACKEND
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER) || BUSTER_IN_UNIT(BUSTER_UNIT_X86) || BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND) || BUSTER_IN_UNIT(BUSTER_UNIT_ASSEMBLER) || BUSTER_IN_UNIT(BUSTER_UNIT_LINK) || BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/x86_64_encoder_test.c"
#endif
#include "buster/compiler/x86_zen5.c"
#include "buster/compiler/x86_64_disassembler.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_X86)
#include "buster/compiler/x86_64_disassembler_test.c"
#endif
#include "buster/compiler/x86_64_disassembler_cli.c"
int run_x86_disassembler_benchmark(int argc, char** argv);
int run_x86_encoder_benchmark(int argc, char** argv);

// The lane base layer (groups of threads, and the arenas they allocate from) and its tests, for the test-lanes command.
// Its benchmark is another translation unit.
#undef BUSTER_UNIT
#include "buster/compiler/lane.c"
#define BUSTER_UNIT BUSTER_UNIT_BACKEND
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER) || BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE)
#include "buster/compiler/lane_test.c"
#endif
int run_lane_benchmark(int argc, char** argv);

#include "buster/compiler/diagnostic.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/diagnostic_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/diagnostic_benchmark.c"
#endif

// Liveness and interference over aligned bitsets, independent of the future IR's use/def construction.
#include "buster/compiler/dataflow.c"
#include "buster/compiler/dataflow_program.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/dataflow_test.c"
#endif
int run_dataflow_benchmark(int argc, char** argv);
// The tier-neutral emission metadata protocol's tests, for test-emission-metadata.
int run_emission_metadata_tests(int argc, char** argv);
// Fused AVX-512 direct-to-ELF64 C17 compiler (#2850).
#include "buster/compiler/c_direct.h"

// Entry-rooted dominance, frontiers and natural loops over borrowed CFG columns.
#if BUSTER_BACKEND_CONSUMER
#include "buster/compiler/dominators.c"
#include "buster/compiler/dominators_export.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/dominators_test.c"
#endif

// Local promotion over a completed CFG: vector SSA construction, its nonrecursive scalar twin and semantic tests.
#include "buster/compiler/ssa.c"
#include "buster/compiler/ssa_program.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ssa_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ssa_benchmark.c"
#endif

#include "buster/compiler/tier1_allocate.c"
#include "buster/compiler/tier1_rematerialize.c"
// #939's allocation certificates: the checker of a source/stream program, the interval allocator's fragment adapter and
// the CFG allocator's producer, which Tier 1's consumers run when their options ask for it.
#include "buster/compiler/tier1_certificate.c"
#include "buster/compiler/tier1_certificate_interval.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier1_allocate_test.c"
#endif
#include "buster/compiler/tier1_cfg.c"
#include "buster/compiler/tier1_certificate_cfg.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier1_cfg_test.c"
#endif
#endif
int run_tier1_allocate_benchmark(int argc, char** argv);
int run_dominator_benchmark(int argc, char** argv);

// The preprocessor's fuzz tooling (#109): the generator, the clang oracle, the comparison and the minimizer, and their
// self-tests, for the test-preprocessor-fuzz command. test-preprocessor --fuzz runs the preprocessor against them
// (c_preprocessor_fuzz.c).
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#include "buster/compiler/preprocessor_fuzz.c"
#include "buster/compiler/preprocessor_fuzz_generate.c"
#include "buster/compiler/preprocessor_fuzz_clang.c"
#include "buster/compiler/preprocessor_fuzz_test.c"
#include "buster/compiler/preprocessor_fuzz_benchmark.c"
#endif

// External randomized C compiler comparison and its independent process/accounting fixtures.
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/differential.c"
#include "buster/compiler/differential_test.c"
#endif

// Token refinement: identifier interning (c_intern.c) and the per-file pass after the lexer (c_refine.c), and their
// tests, for the test-refinement command. Its benchmark is another translation unit.
#include "buster/compiler/c_intern.c"
#include "buster/compiler/c_refine.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#include "buster/compiler/c_refine_test.c"
#endif
int run_refinement_benchmark(int argc, char** argv);

// The preprocessor (c_preprocessor.c, with the predefined macros of c_predefines.c) and its tests, for the -E and
// test-preprocessor commands.
#include "buster/compiler/c_predefines.c"
#include "buster/compiler/c_preprocessor.c"
#include "buster/compiler/c_builtin_catalog.c"
#include "buster/compiler/test_process.c"
// libm's functions for the tests' oracles, which the compiler's link doesn't take (#652).
#include "buster/compiler/test_libm.c"
// The clang and gcc runs the tests compare with, kept between runs (#542), and its tests, for the test-oracle-cache
// command.
#include "buster/compiler/oracle_cache.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/oracle_cache_test.c"
#endif
#include "buster/compiler/c_preprocessor_test.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#include "buster/compiler/c_predefines_test.c"
#include "buster/compiler/c_preprocessor_fuzz.c"
#endif
#include "buster/compiler/c_preprocessor_oracle.c"
#include "buster/compiler/x86_target_forms.c"
int run_preprocessor_benchmark(int argc, char** argv);

// The per-file jobs on lanes and the run-ahead that fill the preprocessor's file cache (c_files.c), and their tests, for
// the test-files command. Its benchmark is another translation unit.
#include "buster/compiler/c_files.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#include "buster/compiler/c_files_test.c"
#endif
int run_files_benchmark(int argc, char** argv);

// The parser (c_parser.c) and its tests, for the default command, which preprocesses and parses a file, and the
// test-parser command.
#include "buster/compiler/c_parser.c"
#include "buster/compiler/c_parser_test.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#include "buster/compiler/c_gnu_test.c"
#include "buster/compiler/c_gnu_benchmark.c"
#endif
int run_parser_benchmark(int argc, char** argv);

// Scoped name-resolution kernels and their event-stream oracle; c_parser.c includes the shared kernels.
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#include "buster/compiler/c_bindings_test.c"
#include "buster/compiler/c_bindings_benchmark.c"
#endif
#include "buster/compiler/c_parser_bindings.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#include "buster/compiler/c_parser_bindings_test.c"
#include "buster/compiler/c_parser_bindings_benchmark.c"
#endif

// Selective lowering consumes resolved definition/reference columns; the checker producer is still pending.
#include "buster/compiler/c_lowering.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#include "buster/compiler/c_lowering_test.c"
#include "buster/compiler/c_lowering_benchmark.c"
#endif

// The link representation (atoms, symbols, fixups and names, which the object writer and the linker share), the test
// programs generated in it, and their tests, for the test-link command.
#include "buster/compiler/link.c"
#include "buster/compiler/link_program.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_LINK) || BUSTER_IN_UNIT(BUSTER_UNIT_DYNAMIC) || BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE)
#include "buster/compiler/link_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_LINK) || BUSTER_IN_UNIT(BUSTER_UNIT_DYNAMIC) || BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE)
#include "buster/compiler/link_order_test.c"
#endif

// The object writer (ET_REL objects from the link representation, for -c) and its tests, for the test-object-writer
// command. Its benchmark is another translation unit.
#include "buster/compiler/object_writer.c"
#include "buster/compiler/object_writer_test.c"
#include "buster/compiler/debug.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_LINK) || BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/debug_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_LINK) || BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/debug_benchmark.c"
#endif
int run_object_writer_benchmark(int argc, char** argv);

// The import path's readers (ELF objects, archives, shared libraries and linker scripts into the link representation),
// the C runtime's files, found and imported with them, and their tests, for the test-import command.
#include "buster/compiler/import.c"
#include "buster/compiler/runtime.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_LINK) || BUSTER_IN_UNIT(BUSTER_UNIT_DYNAMIC) || BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE)
#include "buster/compiler/import_test.c"
#endif
int run_import_benchmark(int argc, char** argv);

// Binding: the C runtime joined to a program's link and each name bound, and its tests, for the test-bind command. Its
// benchmark is another translation unit.
#include "buster/compiler/bind.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_LINK) || BUSTER_IN_UNIT(BUSTER_UNIT_DYNAMIC) || BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE)
#include "buster/compiler/bind_test.c"
#endif
int run_bind_benchmark(int argc, char** argv);

// The direct path's executables (layout, patching, the build ID and the output file) and their tests, for the
// test-executable command. Its benchmark is another translation unit.
#include "buster/compiler/executable.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_LINK) || BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE) || BUSTER_IN_UNIT(BUSTER_UNIT_DYNAMIC) || BUSTER_IN_UNIT(BUSTER_UNIT_ASSEMBLER) || BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/executable_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_LINK) || BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/debug_executable_test.c"
#endif
// The object writer's DWARF checks (ObjectOptions.debug), which test-object-writer runs: they need debug.c's units and
// the executable tests' ELF reading.
#if BUSTER_IN_UNIT(BUSTER_UNIT_LINK)
#include "buster/compiler/object_debug_test.c"
#endif
int run_executable_benchmark(int argc, char** argv);

// A dynamic PIE's inputs from the runtime and binding, and the dynamic PIE's tests, for the test-dynamic command.
#include "buster/compiler/dynamic.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_DYNAMIC) || BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/dynamic_test.c"
#endif

// The static executables' tests with the C runtime, for the test-static command.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DYNAMIC) || BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE)
#include "buster/compiler/static_test.c"
#endif

// The runtime snapshot (the imported runtime kept in the cache directory) and its tests, for the test-snapshot command.
// Its benchmark is another translation unit.
#include "buster/compiler/snapshot.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/snapshot_test.c"
#endif
int run_snapshot_benchmark(int argc, char** argv);

// Foreign inputs (other compilers' objects, archives, shared libraries and scripts: opened, parsed and resolved, with
// the archive members the link needs loaded and COMDAT groups picked) and their tests, for the test-foreign command. Its
// benchmark is another translation unit.
#include "buster/compiler/inflate.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE)
#include "buster/compiler/inflate_test.c"
#endif
#include "buster/compiler/foreign.c"
#include "buster/compiler/foreign_unwind.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE)
#include "buster/compiler/foreign_unwind_benchmark.c"
#endif
#include "buster/compiler/foreign_gc.c"
#include "buster/compiler/foreign_link.c"
#include "buster/compiler/foreign_gc_link.c"
#include "buster/compiler/foreign_unwind_dedup.c"
#include "buster/compiler/foreign_unwind_dedup_link.c"
#include "buster/compiler/foreign_strings.c"
#include "buster/compiler/foreign_strings_link.c"
#include "buster/compiler/foreign_driver.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/foreign_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_EXECUTABLE)
#include "buster/compiler/foreign_gc_benchmark.c"
#include "buster/compiler/foreign_unwind_dedup_benchmark.c"
#endif
int run_foreign_benchmark(int argc, char** argv);
// The link benchmark (the direct path against the object writer and the linkers, on the same programs) and the floors'
// (what the machine and the kernel charge a linker) are other translation units.
int run_link_benchmark(int argc, char** argv);
int run_floors_benchmark(int argc, char** argv);
int run_floors_input_tests(void);

// Branch sizing (each branch's rel8 or rel32 form inside a function, before it's encoded), the functions its tests
// generate, and its tests, for the test-branch-sizing command. Its benchmark is another translation unit.
#include "buster/compiler/branch_sizing.c"
#include "buster/compiler/branch_sizing_generate.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER) || BUSTER_IN_UNIT(BUSTER_UNIT_X86)
#include "buster/compiler/branch_sizing_test.c"
#endif
int run_branch_sizing_benchmark(int argc, char** argv);

// What the x86 forms a code generator emits mean (their effects, the immediate's contract, the operand-resolved effects
// and the value-preserving form choice), before the assembler's matcher, which takes its values' immediates from it.
// Its tests, for the test-x86-semantics command, follow the assembler's (they take the encoder's tests' printer and
// branch sizing's tests' runner, and check x86_match.c against the shared rule). Its benchmark is another translation
// unit.
#include "buster/compiler/x86_semantics.c"

#include "buster/compiler/x86_match.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#include "buster/compiler/x86_target_test.c"
#endif
#include "buster/compiler/assembler.c"
#include "buster/compiler/assembler_driver.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_ASSEMBLER)
#include "buster/compiler/assembler_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_ASSEMBLER)
#include "buster/compiler/assembler_benchmark.c"
#endif
// The assembly sink (#1362): a unit of the link representation as GNU as's AT&T source, from the emission's symbolic view
// (the link and each function's sized records), which -S writes (the emission keeps the records for it), and its
// tests, for the test-assembly-output command, which take the assembler's matcher for their fixtures' records and its
// tests' GNU as comparison.
#if BUSTER_BACKEND_CONSUMER || BUSTER_IN_UNIT(BUSTER_UNIT_ASSEMBLER)
#include "buster/compiler/assembly_output.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_ASSEMBLER)
#include "buster/compiler/assembly_output_test.c"
#endif

#include "buster/compiler/x86_semantics_test.c"
// The Zen 5 model's harness and tests (#181), whose fixtures come from the form table and the effects tables, and
// which run only the forms the host's target allows.
#if BUSTER_IN_UNIT(BUSTER_UNIT_X86)
#include "buster/compiler/x86_zen5_measure.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_X86)
#include "buster/compiler/x86_zen5_test.c"
#endif
int run_x86_semantics_benchmark(int argc, char** argv);
// The compiler's code of the headers' x86 intrinsics against clang -O0's, for the test-x86-intrinsics command: the objects
// decoded by the disassembler and followed by the effects above.
#if BUSTER_IN_UNIT(BUSTER_UNIT_X86) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/x86_intrinsics_test.c"
#endif

// Experimental postallocation scheduling over resolved machine-record effects and measured operand costs.
#if BUSTER_BACKEND_CONSUMER
#include "buster/compiler/tier1_schedule.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier1_schedule_test.c"
#endif
#endif
int run_tier1_schedule_benchmark(int argc, char** argv);

// The C type table (TypeIds, hash-consing, layout, conversions, compatibility and printing) and its tests, for the
// test-types command. Its benchmark is another translation unit.
#include "buster/compiler/c_types.c"
#include "buster/compiler/c_builtin_intrinsic_types.c"
#include "buster/compiler/c_builtin_intrinsic_features.c"
#include "buster/compiler/c_builtin_intrinsic_catalog.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_TYPES) || BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND) || BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_types_test.c"
#endif
int run_type_benchmark(int argc, char** argv);

// Immutable source-position histories retain declaration visibility for deferred body consumers.
#include "buster/compiler/c_environment.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_environment_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_FRONTEND)
#include "buster/compiler/c_environment_benchmark.c"
#endif
// The checker's own code goes in a section of its own, .text.buster_checker, which every unit starts on a page (#502):
// the driver's time depends on where its hot loops fall in the instruction caches, and code compiled before them, in
// their unit or in another, moved them by any number of bytes. In their section, only the checker's own code moves
// them. Its tests and the builtins' actions, which the driver seldom runs, stay in .text.
// BUSTER_CHECKER_OFFSET (0 unless BUSTER_BUILD_DEFINES sets it: a multiple of 16 below a page) starts the checker's
// code that many bytes into its page, after int3 padding. Ordinary ./build.sh shifts moves units' .text;
// shifts --checker-placements moves this section's checker unit at link time (#1312, docs/commands/build.md).
#ifndef BUSTER_CHECKER_OFFSET
#define BUSTER_CHECKER_OFFSET 0
#endif
_Static_assert(BUSTER_CHECKER_OFFSET >= 0 && BUSTER_CHECKER_OFFSET < 4096 && BUSTER_CHECKER_OFFSET % 16 == 0, "BUSTER_CHECKER_OFFSET must be a multiple of 16 below 4096");
#define BUSTER_CHECKER_OFFSET_TEXT_(offset) #offset
#define BUSTER_CHECKER_OFFSET_TEXT(offset) BUSTER_CHECKER_OFFSET_TEXT_(offset)
__asm__(".section .text.buster_checker,\"ax\",@progbits\n\t.p2align 12\n\t.skip " BUSTER_CHECKER_OFFSET_TEXT(BUSTER_CHECKER_OFFSET) ", 0xcc\n\t.text");
#pragma clang section text = ".text.buster_checker"
#if BUSTER_SOURCE_CONSUMER
#include "buster/compiler/c_check_environment.c"
#include "buster/compiler/c_check_body_bindings.c"
#include "buster/compiler/c_check_lazy.c"
#endif
#pragma clang section text = ""

#include "buster/compiler/c_builtin.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_TYPES) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECK_BUILTINS)
#include "buster/compiler/c_builtin_test.c"
#endif
#if BUSTER_CHECKER_CONSUMER
#pragma clang section text = ".text.buster_checker"
#include "buster/compiler/c_check_actions.c"
#pragma clang section text = ""
#include "buster/compiler/c_check_builtin_x86.c"
#include "buster/compiler/c_check_builtin.c"
#include "buster/compiler/c_check_varargs.c"
#include "buster/compiler/c_check_builtin_misc.c"
#include "buster/compiler/c_check_builtin_query.c"
#include "buster/compiler/c_check_builtin_bit_cast.c"
#include "buster/compiler/c_check_builtin_float.c"
#include "buster/compiler/c_check_builtin_math.c"
#include "buster/compiler/c_check_builtin_library.c"
#include "buster/compiler/c_check_builtin_atomic.c"
#include "buster/compiler/c_check_builtin_atomic_rmw.c"
#include "buster/compiler/c_check_builtin_atomic_c11.c"
#include "buster/compiler/c_check_builtin_vector.c"
#include "buster/compiler/c_check_builtin_typed_overflow.c"
#include "buster/compiler/c_check_builtin_rounds.c"
#pragma clang section text = ".text.buster_checker"
#include "buster/compiler/c_checker.c"
#if BUSTER_SOURCE_CONSUMER
#include "buster/compiler/c_check_literals.c"
#include "buster/compiler/c_check_warning_source.c"
#include "buster/compiler/c_check_initializer.c"
#include "buster/compiler/c_check_data.c"
#include "buster/compiler/c_check_input.c"
// #113's deferred bodies: check_input with every function body read apart, out of order and on lanes.
#include "buster/compiler/c_check_deferred.c"
#include "buster/compiler/c_check_diagnostic.c"
#include "buster/compiler/c_check_initializer_input.c"
#include "buster/compiler/c_check_data_input.c"
#elif BUSTER_IN_UNIT(BUSTER_UNIT_CHECK_BUILTINS)
#include "buster/compiler/c_check_constant_bytes.c"
#include "buster/compiler/c_check_os_log_input.c"
#endif
#pragma clang section text = ""
#endif
int run_checker_benchmark(int argc, char** argv);
int run_builtin_benchmark(int argc, char** argv);

// The System V calling convention (each type's classes, and each call's argument locations) and its tests, for the
// test-calling-convention command. Its benchmark is another translation unit.
#include "buster/compiler/calling_convention.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_TYPES) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/calling_convention_test.c"
#endif
int run_calling_convention_benchmark(int argc, char** argv);

// The tier-neutral source and frame events and their resolution against a final layout (#1056), which the frame
// emitters below publish and the emission consumes.
#include "buster/compiler/emission_metadata.c"

// Frame storage, explicit prologue/epilogue planning and its native instruction consumer.
#if BUSTER_BACKEND_CONSUMER
#include "buster/compiler/tier1_frame.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier1_frame_test.c"
#endif
#include "buster/compiler/tier1_frame_emit.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier1_frame_execution_test.c"
#endif

// Tier 0 (a function's typed stream to instruction records, by templates with registers from the value stack's
// depths), the programs its tests and benchmark generate, and its tests, for the test-tier0 command. Its benchmark
// (benchmark-backend) is another translation unit.
#include "buster/compiler/tier0.c"
#include "buster/compiler/tier0_inline.c"
#include "buster/compiler/unwind.c"
#include "buster/compiler/unwind_tier0.c"
// The tier-neutral emitted function (#1056): Tier 0's adapter, the frame events' resolution and their verifier.
#include "buster/compiler/emitted_code.c"
#include "buster/compiler/tier0_generate.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier0_test.c"
#endif
#include "buster/compiler/c_builtin_lower.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/c_builtin_lower_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/c_builtin_lower_benchmark.c"
#endif
#include "buster/compiler/c_builtin_varargs_lower.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/c_builtin_varargs_lower_test.c"
#endif
#include "buster/compiler/c_builtin_misc_lower.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/c_builtin_misc_lower_test.c"
#endif
#include "buster/compiler/c_builtin_float_lower.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/c_builtin_float_lower_test.c"
#endif
#include "buster/compiler/c_builtin_terminal_helpers.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/c_builtin_terminal_helpers_test.c"
#endif
#include "buster/compiler/c_builtin_atomic_helpers.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/c_builtin_atomic_helpers_test.c"
#endif
#include "buster/compiler/c_builtin_atomic_rmw_helpers.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/c_builtin_atomic_rmw_helpers_test.c"
#endif
#include "buster/compiler/c_builtin_rounds_helper.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/c_builtin_rounds_helper_test.c"
#endif
#include "buster/compiler/c_builtin_math_helpers.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/c_builtin_math_helpers_test.c"
#endif
#include "buster/compiler/c_builtin_x86_helpers.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier0_variadic_frame_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/unwind_tier0_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/unwind_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/unwind_native_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/unwind_benchmark.c"
#endif
// Streaming the output (#88): Tier 0's code written while it compiles, in the data-first order, against the end.
#include "buster/compiler/streaming.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/streaming_test.c"
#include "buster/compiler/streaming_benchmark.c"
#include "buster/compiler/streaming_benchmark_test.c"
#endif
#endif
int run_backend_benchmark(int argc, char** argv);
int run_tier1_frame_benchmark(int argc, char** argv);

// Source checking's program consumer shares the ABI and Tier 0 interfaces. Keep the source driver and its
// integration tests after those consumers so one checked unit can retain both executable bodies and static data.
#if BUSTER_BACKEND_CONSUMER
#pragma clang section text = ".text.buster_checker"
#include "buster/compiler/c_check_program.c"
#pragma clang section text = ""
#elif BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#pragma clang section text = ".text.buster_checker"
#include "buster/compiler/c_check_clock.c"
#include "buster/compiler/worker_budget.c"
#pragma clang section text = ""
#endif
// #129's oracle: the functions and objects two objects define, compared (ours from -c, clang -O0 -c's), with the names
// the checked source makes, for the checker's selection tests, test-checker-corpus --symbols and test-c-testsuite
// --cross-check.
#include "buster/compiler/c_lowering_symbols.c"
#if BUSTER_SOURCE_CONSUMER
#pragma clang section text = ".text.buster_checker"
#include "buster/compiler/c_check_prefix.c"
#include "buster/compiler/c_check_repair.c"
// One request's semantic configuration (#1057): the code generation and layout refusals, the checked program's target
// and predefines and the measurements' receipt, which the driver, the corpus check and the source preparation share.
#include "buster/compiler/c_check_request.c"
#include "buster/compiler/c_checker_driver.c"
// The driver's commands of several source files (#152): their units on lanes, and one executable of them all.
#include "buster/compiler/c_checker_units.c"
// #2531's measure-attested: attested declarations' census, beside a command's units (check_driver_attested).
#include "buster/compiler/c_check_attested.c"
#pragma clang section text = ""
// #2524's node machine: a full expression's typed entries in one visit a node. Its state and its records' accessors, then
// one file a sweep: T (types), C (contexts and templates) and X (the entries). T's transition table is baked below; its
// shadow (measure-node-machine --shadow) is c_check_node_census.c's.
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_node_machine.c"
#include "buster/compiler/c_check_node_machine_type.c"
#include "buster/compiler/c_check_node_machine_contexts.c"
#include "buster/compiler/c_check_node_machine_expand.c"
#include "buster/compiler/c_check_node_machine_lower.c"
// T where it sits (step 2's first measure): the machine's state at reader time and T on the front's expressions there.
#include "buster/compiler/c_check_node_machine_reader.c"
#include "buster/compiler/c_check_node_machine_alone.c"
#include "buster/compiler/c_check_node_bodies.c"
// #2850's step 1: a leaf's and a lookup's record from one load each, in the shadow (measure-node-machine --shadow --facts).
#include "buster/compiler/c_check_node_machine_facts.c"
// #2850's step 2's second piece: what reads T's record, counted in the shadow (measure-node-machine --shadow --facts-reads).
#include "buster/compiler/c_check_node_machine_reads.c"
// #2850's step 2, C on the window: C's answers from the window's bytes, 64 records a step (--shadow --window-contexts).
#include "buster/compiler/c_check_node_window_counter.c"
#include "buster/compiler/c_check_node_machine_window.c"
// #2850's step 2, X's rows on the window: the kinds and classes of X's entries from C's answers there (--shadow --window-rows).
#include "buster/compiler/c_check_node_machine_rows.c"
#endif
// bake-tables (#590): the backend's tables written into this executable's own file, built, by build.sh, from this
// unit, whose Tier 0 and unwind copies the C driver above uses (baked.h).
#include "buster/compiler/baked.c"
#endif
// The checker unit's own tests compile unoptimized, between `optimize off` and `on` (#681). On the 9700X, the measured
// 716c980d to 4ce693ad pair's checker-unit mean fell from 33.7 to 27.35 s, and compilation-phase wall from 33.7 to
// 28.5 s (two builds per role, excluding final linking and remaining script overhead). AGENTS.md links the frozen
// record, including the small observed SQLite runtime costs, controller limitations and correctness scope.
// No benchmark's timed code calls these tests: they generate inputs and compare results outside the samples.
// A new test of the checker's goes inside.
#pragma clang optimize off
#if BUSTER_CHECKER_CONSUMER
#include "buster/compiler/c_checker_test.c"
#endif
#pragma clang optimize on
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECK_BUILTINS)
#include "buster/compiler/c_builtin_intrinsic_types_test.c"
#include "buster/compiler/c_builtin_intrinsic_features_test.c"
#include "buster/compiler/c_builtin_intrinsic_catalog_test.c"
#include "buster/compiler/c_builtin_intrinsic_inventory_test.c"
#include "buster/compiler/c_check_builtin_x86_test.c"
#include "buster/compiler/c_check_builtin_vector_test.c"
#include "buster/compiler/c_check_builtin_test.c"
#include "buster/compiler/c_check_varargs_test.c"
#include "buster/compiler/c_check_builtin_misc_test.c"
#include "buster/compiler/c_check_builtin_query_test.c"
#include "buster/compiler/c_check_builtin_bit_cast_test.c"
#include "buster/compiler/c_check_builtin_float_test.c"
#include "buster/compiler/c_check_builtin_math_test.c"
#include "buster/compiler/c_check_builtin_atomic_test.c"
#include "buster/compiler/c_check_builtin_atomic_rmw_test.c"
#include "buster/compiler/c_check_builtin_typed_overflow_test.c"
#include "buster/compiler/c_check_builtin_bits_test.c"
#include "buster/compiler/c_check_builtin_rounds_test.c"
#endif
#if BUSTER_BACKEND_CONSUMER
#include "buster/compiler/c_check_corpus.c"
#endif
#if BUSTER_SOURCE_CONSUMER
// #1057: a real C file prepared as -c prepares it, which the source benchmarks and the IR's commands on real C share.
#include "buster/compiler/c_check_source_prepare.c"
#endif
#pragma clang optimize off
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_deferred_test.c"
#include "buster/compiler/c_check_mutation_test.c"
#include "buster/compiler/c_check_constraints_test.c"
#include "buster/compiler/c_checker_driver_test.c"
#include "buster/compiler/c_check_debug_test.c"
#endif
// #151's test-check-lanes: the functions' lanes, every output one lane's (check_program_emit_lanes).
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_lanes_test.c"
#endif
// #152's test-check-units: the driver's commands of several source files, every unit's output its own alone's.
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_units_test.c"
#include "buster/compiler/c_check_unwind_test.c"
#include "buster/compiler/c_check_asm_test.c"
#endif
#pragma clang optimize on
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_source_benchmark.c"
#endif
// #113's benchmark-checker-deferred: the deferred reader against source order's, and its position checks.
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_deferred_benchmark.c"
#endif
// #129's benchmark-lowering-source: what lowering only the referenced definitions saves on real units.
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_lowering_source_benchmark.c"
#endif
// #1048's measure-lowering-templates: how much of the lowering a table of node templates covers.
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_lower_inventory.c"
#endif
// #2524's measure-node-machine: the node machine's census, what its set and silence tests would take.
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_node_census.c"
#endif
// #136's benchmark-backend-source: benchmark-backend's variants on the functions -c compiles of real units.
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
// Both source-benchmark families use these counters; keep their first inclusion before the IR source helpers.
#include "buster/compiler/tier0_benchmark_measure.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/tier0_source_benchmark.c"
#endif
// #2874's measure-tier0-entries: what a typed entry's records depend on, on the same functions.
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/tier0_entries_measure.c"
#endif
// #1398's test-tier0-inline: Tier 0's splice of always_inline functions, its vector path against its twin, on real C.
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_tier0_inline_test.c"
#endif
// #151's benchmark-check-lanes: a unit's functions compiled on lanes, against one lane.
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_lanes_benchmark.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_binding_benchmark.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_debug_benchmark.c"
#endif
#pragma clang optimize off
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_source_benchmark_test.c"
#include "buster/compiler/c_lowering_source_benchmark_test.c"
#include "buster/compiler/c_check_lower_inventory_test.c"
#include "buster/compiler/c_check_node_census_test.c"
#include "buster/compiler/c_check_attested_test.c"
#endif
// #1048's test-lowering-templates: node templates against the tasks' rules, function for function.
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_program_templates_test.c"
#include "buster/compiler/tier0_source_benchmark_test.c"
#include "buster/compiler/tier0_entries_measure_test.c"
#include "buster/compiler/c_check_lanes_benchmark_test.c"
#include "buster/compiler/c_option_table_test.c"
#include "buster/compiler/c_check_request_test.c"
#include "buster/compiler/c_check_corpus_symbols_test.c"
#endif
#pragma clang optimize on

// Tier 1's arena-backed instruction columns, exact verifier twins, stable text form and typed-stream adapter.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER) && !BUSTER_SOURCE_CONSUMER
#define BUSTER_IR_STORAGE_ONLY
#include "buster/compiler/ir.c"
#undef BUSTER_IR_STORAGE_ONLY
#endif
#if BUSTER_BACKEND_CONSUMER
#include "buster/compiler/ir.c"
#include "buster/compiler/ir_simd_typed.c"
#include "buster/compiler/ir_lower.c"
#include "buster/compiler/ssa_ir.c"
#include "buster/compiler/ir_validate.c"
#include "buster/compiler/interpreter.c"
#include "buster/compiler/interpreter_native.c"
#include "buster/compiler/interpreter_typed_abi.c"
#include "buster/compiler/interpreter_link.c"
#include "buster/compiler/ir_parse.c"
#include "buster/compiler/ir_interpreter.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_test.c"
#include "buster/compiler/ir_lower_test.c"
#include "buster/compiler/ssa_ir_test.c"
#include "buster/compiler/ir_parse_test.c"
#include "buster/compiler/interpreter_test.c"
#include "buster/compiler/tier0_mask_test.c"
#include "buster/compiler/interpreter_native_test.c"
#include "buster/compiler/interpreter_link_test.c"
#include "buster/compiler/ir_interpreter_test.c"
#endif
#include "buster/compiler/interpreter_driver.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_benchmark.c"
#include "buster/compiler/ir_lower_benchmark.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/ir_source_test.c"
#else
// Keep the production pass at its first include position without the source-test preparation interface.
#include "buster/compiler/ir_dataflow.c"
#endif
#include "buster/compiler/tier1_cfg_ir.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier1_cfg_source_test.c"
#include "buster/compiler/tier1_cfg_source_benchmark.c"
#include "buster/compiler/tier1_certificate_benchmark.c"
#endif

// Verified Tier 1 optimization passes and independent before/after semantic tests.
#include "buster/compiler/ir_optimize.c"
// #141: Tier 1's 128-bit integers as pairs of 64-bit halves, before the optimizer.
#include "buster/compiler/ir_wide.c"
// #1624: Tier 1's vectors wider than the target's registers as its widest vectors' pieces, before the optimizer.
#include "buster/compiler/ir_vector_split.c"
#include "buster/compiler/ir_rebuild.c"
#include "buster/compiler/ir_reduce.c"
#include "buster/compiler/ir_reduce_oracle.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_reduce_test.c"
#include "buster/compiler/ir_reduce_driver.c"
#include "buster/compiler/ir_reduce_driver_test.c"
#endif
#include "buster/compiler/ir_optimize_inline.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_optimize_inline_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_optimize_test.c"
#else
// The production pass was first included by the test root here. Keep that position without its fixture dependency.
#include "buster/compiler/ir_if_convert.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_optimize_benchmark.c"
#endif
#include "buster/compiler/ir_optimize_gvn.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_optimize_gvn_test.c"
#endif
#include "buster/compiler/ir_optimize_licm.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_optimize_licm_test.c"
#endif
// #2755: Tier 1's loop unroller, --tier1-passes=+unroll.
#include "buster/compiler/ir_optimize_unroll.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_optimize_unroll_test.c"
#endif
// #3309: loop store motion, before promotion.
#include "buster/compiler/ir_store_motion.c"
#include "buster/compiler/ir_optimize_sroa.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_optimize_sroa_test.c"
#include "buster/compiler/ir_optimize_inline_simd_test.c"
#include "buster/compiler/ir_optimize_inline_cfg_test.c"
#endif
// #175's first #139 pass tests in the IR's text form: hand-written before/after pairs under tests/ir/optimize.
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_optimize_text_test.c"
#else
#include "buster/compiler/ir_optimize_verified.c"
#endif
// #2743: the loop vectorizer of countable innermost loops (Tier 1's --tier1-passes=+vectorize) and its fixtures.
#include "buster/compiler/ir_vectorize_loops.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_vectorize_loops_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_store_motion_test.c"
#endif
// #866's GVN variants on real source's lowered IR are part of #131's IR benchmark, which needs GVN's definitions.
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_source_benchmark.c"
#include "buster/compiler/ir_source_passes.c"
#include "buster/compiler/ir_optimize_passes_benchmark.c"
#include "buster/compiler/ir_metamorphic.c"
#endif

// Selected effective uses feed liveness, allocation and the bounded native function consumer.
#undef BUSTER_UNIT
#include "buster/compiler/tier1_select.c"
#define BUSTER_UNIT BUSTER_UNIT_BACKEND
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/tier1_select_test.c"
#endif
#include "buster/compiler/tier1_liveness.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier1_liveness_test.c"
#endif
#include "buster/compiler/tier1_emit.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier1_emit_test.c"
#include "buster/compiler/tier1_pipeline_test.c"
#endif
// #179: hand-written IR of AVX-512's masks through Tier 1, natively against the shared IR's interpreter.
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier1_masks_test.c"
#endif
// #141: the 128-bit integers' split into halves through Tier 1, natively against the shared IR's interpreter.
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier1_wide_test.c"
#endif
#endif
// The driver remains the baked tables' storage home; it needs their declarations without the selection kernels.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER) && !BUSTER_SOURCE_CONSUMER
#define BUSTER_TIER1_BURS_STORAGE_ONLY
#include "buster/compiler/tier1_select_burs.c"
#undef BUSTER_TIER1_BURS_STORAGE_ONLY
#endif
// #179: what a mask's spill costs, to memory against to a general register, and the programs' checks.
#if BUSTER_IN_UNIT(BUSTER_UNIT_X86)
#include "buster/compiler/mask_spill_measure.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_X86)
#include "buster/compiler/mask_spill_measure_test.c"
#endif
#if BUSTER_BACKEND_CONSUMER
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/tier1_pipeline_benchmark.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND) || BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/tier1_select_source_benchmark.c"
#endif
// #939: the certificate of the CFG consumer's code on real C, decoded from its records, beside the emission it certifies:
// the checker's unit's command, as its corpus's preparation's home.
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/tier1_code_certificate_benchmark.c"
#endif
// The C driver's --tier1 (#138's piece for #140): each function Tier 1's pipeline takes compiled by it.
#pragma clang section text = ".text.buster_checker"
#if BUSTER_SOURCE_CONSUMER
#include "buster/compiler/c_check_tier1.c"
#endif
#pragma clang optimize off
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_debug_tier1_parameters_test.c"
#include "buster/compiler/c_check_tier1_outcome_test.c"
#endif
#pragma clang optimize on
#pragma clang section text = ""
// #1056: the tier-neutral emitted function's tests (row programs, Tier 0's and Tier 1's frame events, the verifier).
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/emitted_code_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/x86_target_selection_test.c"
#endif
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ir_stack_test.c"
#include "buster/compiler/ir_simd_typed_test.c"
#include "buster/compiler/ir_simd_consumer_test.c"
#endif
#endif
int run_tier1_select_benchmark(int argc, char** argv);
bool run_x86_target_selection_tests(void);
int run_tier1_model_measure(int argc, char** argv);
int run_tier1_model_measure_tests(int argc, char** argv);

// The call graph check (the style's rule against recursion, on the compiler's own LLVM IR) and its tests, for the
// check-call-graph and test-call-graph commands.
#include "buster/compiler/call_graph.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/call_graph_test.c"
#endif

// The profiling tools (ab, and the reports of perf's and objdump's text: hot-loops, label-spills, spill-report and
// branch-misses) and their tests, for the test-profile command.
#include "buster/compiler/profile.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/profile_test.c"
#endif

// measure-compile (#518): whole compiles timed as processes against a reference compiler, with --time-stages' report of
// where their time goes.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/compile_measure.c"
#endif

// #1128's benchmark-check-units: a command of several units timed as processes by each lane count, with its system time
// against one lane's (time-runs' runs, of test-check-units' program of synth's shape).
#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)
#include "buster/compiler/c_check_units_benchmark.c"
#endif
// measure-tier1-programs (#138, #1189): speedtest1 and Lua's scripts by both tiers, clang -O0 and -O2 and tcc, their runs
// and (--compiles) their builds' compiles timed as whole processes in a Williams design's order, against each other.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/tier1_code_size.c"
#include "buster/compiler/tier1_code_size_test.c"
#include "buster/compiler/tier1_programs_measure.c"
#endif
// test-sqlite (#146): SQLite's shell by both tiers against clang's, over SQLite's CLI tests and tests/sqlite's scripts.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/sqlite_test.c"
// test-sqlite-testfixture (#146): SQLite's Tcl test suite through testfixture by both tiers against clang's.
#include "buster/compiler/sqlite_testfixture.c"
#endif
// measure-tier1-rows (#1283): vector code (test-checker-driver's machine rows' unit, a lexer's byte scan and the compiler's
// own lexer) by Tier 0, Tier 1 and another compiler's Tier 1, with the moves around Tier 1's machine rows counted.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/tier1_rows_measure.c"
#endif
// measure-frames (#177): the frames functions' code makes, by build, against another build's (Tier 1's against clang
// -O2's, with and without the objects' lifetimes).
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/frame_measure.c"
#endif
// measure-helpers (#1059): the direct forms against the helpers they replace (--helper-forms=all), by both tiers, as
// whole processes in a Williams design's order: the primitives' kernels and speedtest1.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/helpers_measure.c"
#endif

// The runner the 9700X job runs its tests through (a list of commands at once, each one's output printed in the list's
// order) and its tests, for the parallel and test-parallel commands.
#include "buster/compiler/parallel.c"
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/parallel_test.c"
#endif

// Clang's caret display compared whole with clang's (#2376), for the test-carets command.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER)
#include "buster/compiler/c_caret_test.c"
#endif

// The c-testsuite harness (#145), for the test-c-testsuite command: each program compiled and linked by this
// executable, run and compared with its expected output.
#if BUSTER_IN_UNIT(BUSTER_UNIT_DRIVER) || BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/c_testsuite.c"
#endif

// #134's test-ssa-source: every function of real and generated C promoted by both of ssa_ir.c's paths with the SSA
// verifier's checks, and each program with a main run by the IR's interpreter in its three forms (all locals in memory,
// and each path's SSA), against its expected output.
#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)
#include "buster/compiler/ssa_source_generate.c"
#include "buster/compiler/ssa_source_test.c"
#include "buster/compiler/interpreter_source_driver.c"
#endif

#include "runner.c"
