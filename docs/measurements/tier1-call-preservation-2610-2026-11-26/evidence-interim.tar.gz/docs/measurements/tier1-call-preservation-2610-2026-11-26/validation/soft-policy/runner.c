// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Scratch-only focused tests of the experimental call-clobber avoidance policy.
#include "tests.c"

int main(int argc, char** argv)
{
    int result = 1;
    arena_page_policy("0");
    if (x86_encoder_initialize() && x86_semantics_initialize() && x86_zen5_initialize())
    {
        char* bounded[] = { "--count", "32" };
        if (argc == 2 && strcmp(argv[1], "existing-allocation") == 0)
        {
            result = run_tier1_allocate_tests(2, bounded);
        }
        else if (argc == 2 && strcmp(argv[1], "existing-cfg") == 0)
        {
            result = run_tier1_cfg_tests(2, bounded);
        }
        else
        {
            Arena output = arena_reserve(BUSTER_TIER1_CFG_TEST_ARENA);
            Arena scratch = arena_reserve(BUSTER_TIER1_CFG_TEST_ARENA);
            Tier1CfgTestTally tally = { 0 };
            if (output.base != 0 && scratch.base != 0)
            {
                policy_shapes(&tally, &output);
                for (uint32_t variant = 0; variant < 5; variant += 1)
                {
                    for (uint32_t calls = 1; calls < 3; calls += 1)
                    {
                        policy_orders(&tally, &output, &scratch, variant, calls);
                    }
                }
                policy_capacity(&tally, &output, &scratch);
                printf("soft-avoidance: %" PRIu64 " checks, %" PRIu64 " failures\n", tally.checks, tally.failures);
                result = tally.failures != 0;
            }
            arena_release(&output);
            arena_release(&scratch);
        }
    }
    return result;
}
