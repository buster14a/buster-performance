#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <limits.h>
#define BUSTER_IR_NONE UINT32_MAX
#define BUSTER_IR_SLOT_OVERFLOW_AREA 1
#define BUSTER_TIER1_EMIT_CFG_RECIPE_DEPTH 8
#define BUSTER_TIER1_ALLOCATE_GPR 0
#define BUSTER_TIER1_ALLOCATE_MASK 2
#define BUSTER_TIER1_REMAT_NONE 0
#define BUSTER_TIER1_REMAT_INTEGER 1
#define BUSTER_TIER1_REMAT_SYMBOL 2
#define BUSTER_TIER1_REMAT_STACK 3
#define BUSTER_TIER1_REMAT_STABLE 1
#define BUSTER_TIER1_REMAT_GOT 2
#define BUSTER_TIER1_ACCESS_DIRECT 0
#define BUSTER_TIER1_ACCESS_GOT 1
#define BUSTER_ABI_LOCATION_STACK 2
#define BUSTER_ABI_FLAG_HIGH 1
#define BUSTER_ABI_FLAG_LOW 2
#define BUSTER_ABI_FLAG_PAYLOAD 4
#define BUSTER_ABI_FLAG_FIRST 8
enum { TIER1_RULE_NONE, TIER1_RULE_CONSTANT, TIER1_RULE_SYMBOL_ADDRESS, TIER1_RULE_STACK_ADDRESS, TIER1_RULE_COPY, TIER1_RULE_ADDRESS };
typedef struct { uint32_t flags, size, alignment; } IrSlot;
typedef struct { uint32_t kind, flags; uint64_t stack_offset; } AbiLocation;
typedef struct { AbiLocation location; uint32_t size; } IrPassed;
typedef struct { uint32_t instruction_count, slot_count; IrSlot* slots; uint32_t parameter_count, parameter_passed; IrPassed* passed; struct { uint64_t stack_bytes; } incoming; } IrFunction;
typedef struct { uint8_t rule; uint32_t values[3], stack_object; int32_t displacement; uint64_t immediate; bool rip; } Tier1SelectPattern;
typedef struct { const IrFunction* function; const Tier1SelectPattern* patterns; const uint8_t* covered; } Tier1SelectPlan;
typedef struct { const uint8_t* classes; } Tier1EmitPrepared;
typedef struct { Tier1EmitPrepared prepared; uint32_t symbol_access_count; const uint8_t* symbol_access; } Tier1EmitResult;
typedef struct { uint32_t checks, failures; } Tier1EmitTest;
static void tier1_emit_test_expect(Tier1EmitTest* test, bool pass, const char* message)
{
    test->checks += 1;
    test->failures += !pass;
    if (!pass) fprintf(stderr, "check %u failed: %s\n", test->checks, message);
}
