// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
//
// The focused native regression uses the production initialization and actual
// tier1_frame_recipe_tests. The helper independently checks the native target.
#ifdef BUSTER_FRAME_RECIPE_TEST_INCLUDE
#include BUSTER_FRAME_RECIPE_TEST_INCLUDE
#endif

int main(void)
{
    int result = 1;
    arena_page_policy("0");
    if (!x86_encoder_initialize() || !x86_semantics_initialize() || !x86_zen5_initialize())
    {
        fprintf(stderr, "frame-recipes: initialization failed\n");
    }
    else
    {
        Tier1EmitTest test = {
            .input = arena_reserve(32u << 20),
            .output = arena_reserve(64u << 20),
            .scratch = arena_reserve(32u << 20),
            .allowed = malloc(X86_FORM_COUNT),
        };
        uint8_t* native = malloc(X86_FORM_COUNT);
        if (test.input.base != 0 && test.output.base != 0 && test.scratch.base != 0 && test.allowed != 0 && native != 0)
        {
            const X86Target target = { .architecture = X86_ARCH_BASELINE };
            const X86Target host = x86_target_native();
            x86_target_forms(&target, test.allowed);
            x86_target_forms(&host, native);
            test.native_allowed = native;
            tier1_frame_recipe_tests(&test);
            printf("frame-recipes: %" PRIu64 " checks, %" PRIu64 " failures, %" PRIu64 " native skips\n", test.checks, test.failures, test.native_skipped);
            result = test.failures != 0 || test.native_skipped != 0;
        }
        else
        {
            fprintf(stderr, "frame-recipes: allocation failed\n");
        }
        free(native);
        free(test.allowed);
        arena_release(&test.input);
        arena_release(&test.output);
        arena_release(&test.scratch);
    }
    return result;
}
