// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

static bool copy_function(const char* path, const char* marker, FILE* output)
{
    FILE* input = fopen(path, "r");
    bool copying = false;
    bool done = false;
    char line[4096];
    while (input != 0 && !done && fgets(line, sizeof(line), input) != 0)
    {
        copying |= strstr(line, marker) == line;
        if (copying)
        {
            fputs(line, output);
            done = strcmp(line, "}\n") == 0;
        }
    }
    if (input != 0)
    {
        fclose(input);
    }
    return done;
}

int main(void)
{
    FILE* input = fopen("head.c", "r");
    FILE* output = fopen("variants.c", "w");
    bool ok = input != 0 && output != 0;
    bool skipping = false;
    bool replaced = false;
    char line[4096];
    while (ok && fgets(line, sizeof(line), input) != 0)
    {
        if (strstr(line, "static void tier1_emit_cfg_recipes(") == line)
        {
            fputs("#include <stdlib.h>\n", output);
            ok = copy_function("../buster-tags/src/buster/compiler/main.c", "static __attribute__((unused)) uint32_t tier1_measure_experiment(", output) &&
                 copy_function("../buster-tags/src/buster/compiler/tier1_emit_cfg.c", "static void tier1_emit_cfg_recipes(", output);
            skipping = true;
            replaced = true;
        }
        else if (!skipping)
        {
            fputs(line, output);
        }
        else if (strcmp(line, "}\n") == 0)
        {
            skipping = false;
        }
    }
    if (input != 0)
    {
        fclose(input);
    }
    if (output != 0)
    {
        ok &= fclose(output) == 0;
    }
    return !(ok && replaced && !skipping);
}
