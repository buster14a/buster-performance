// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Scratch evidence for #2610. The tested map, emitter, verifier and certificates are actual production bodies.

static uint32_t exchange_test_mask(uint32_t before, uint32_t a, uint32_t b)
{
    return (before & ~((1u << a) | (1u << b))) | ((before & (1u << a)) != 0 ? 1u << b : 0) | ((before & (1u << b)) != 0 ? 1u << a : 0);
}

static void exchange_test_identity(uint8_t permutation[16])
{
    for (uint32_t r = 0; r < 16; r += 1)
    {
        permutation[r] = (uint8_t)r;
    }
}

static void exchange_test_failures(Tier1CfgTestTally* tally, Arena* output, Tier1CfgInput* input, Tier1CfgAllocation* cfg, uint32_t a, uint32_t b)
{
    const uint64_t mark = output->length;
    const uint64_t capacity = output->capacity;
    uint8_t* original = malloc(mark);
    tier1_cfg_test_expect(tally, original != 0, "snapshot complete allocation before refusal and capacity probes");
    if (original != 0)
    {
        memcpy(original, output->base, mark);
        for (uint32_t mode = 0; mode < 10; mode += 1)
        {
            uint8_t permutation[16];
            exchange_test_identity(permutation);
            permutation[a] = (uint8_t)b;
            permutation[b] = (uint8_t)a;
            Tier1CfgInput problem = *input;
            Tier1CfgAllocation result = *cfg;
            const uint32_t fixed = 1u << a;
            const uint8_t general = BUSTER_TIER1_ALLOCATE_GPR;
            const uint8_t hint = UINT8_MAX;
            if (mode == 0)
            {
                permutation[b] = (uint8_t)b;
            }
            else if (mode == 1)
            {
                permutation[a] = UINT8_MAX;
            }
            else if (mode == 2)
            {
                exchange_test_identity(permutation);
                permutation[a] = input->scratch_registers[0];
                permutation[input->scratch_registers[0]] = (uint8_t)a;
            }
            else if (mode == 3)
            {
                problem.registers[0] &= ~(1u << a);
            }
            else if (mode == 4)
            {
                problem.fixed.count = 1;
                problem.fixed.classes = &general;
                problem.fixed.registers = &fixed;
            }
            else if (mode == 5)
            {
                problem.sequence_count = 1;
                problem.sequence_registers = &fixed;
            }
            else if (mode == 6)
            {
                result.intervals.hints = &hint;
            }
            else
            {
                const uint64_t first = (mark + 63) & ~UINT64_C(63);
                const uint64_t second = (first + 4 * ((uint64_t)input->value_count + 1) + 63) & ~UINT64_C(63);
                const uint64_t third = (second + 4 * ((uint64_t)input->value_count + 1) + 63) & ~UINT64_C(63);
                output->capacity = mode == 7 ? mark : mode == 8 ? second : third;
            }
            const Tier1CfgInput before_input = problem;
            const Tier1CfgAllocation before_cfg = result;
            const Tier1EmitError error = tier1_emit_cfg_exchange_map(permutation, output, &problem, &result);
            const Tier1EmitError expected = mode < 7 ? TIER1_EMIT_INVALID : TIER1_EMIT_MEMORY;
            tier1_cfg_test_expect(tally, error == expected, "invalid mappings and each failed mask allocation refuse explicitly");
            tier1_cfg_test_expect(tally, output->length == mark && memcmp(&problem, &before_input, sizeof(problem)) == 0 &&
                                       memcmp(&result, &before_cfg, sizeof(result)) == 0 && memcmp(original, output->base, mark) == 0,
                                 "refusal leaves every prior arena byte, published column and length unchanged");
            output->capacity = capacity;
        }
    }
    free(original);
}

static void exchange_test_map(Tier1CfgTestTally* tally, Arena* output, Arena* scratch, Tier1CfgInput* input, bool failures)
{
    Tier1CfgAllocation cfg = { 0 };
    const Tier1CfgError allocated = tier1_cfg_allocate(input, output, scratch, &cfg);
    tier1_cfg_test_expect(tally, allocated == TIER1_CFG_OK, "construct a complete baseline CFG allocation");
    if (allocated == TIER1_CFG_OK)
    {
        Tier1CfgCheck check;
        tier1_cfg_test_expect(tally, tier1_cfg_verify(input, &cfg, scratch, &check), "baseline CFG verifies independently");
        tier1_cfg_test_expect(tally, tier1_cfg_test_certify(tally, input, &cfg, output, scratch, true), "baseline CFG certificate proves values and edges");
        uint32_t available = input->registers[0];
        for (uint32_t f = 0; f < input->fixed.count; f += 1)
        {
            available &= input->fixed.classes[f] == 0 ? ~input->fixed.registers[f] : UINT32_MAX;
        }
        for (uint32_t s = 0; s < input->sequence_count; s += 1)
        {
            available &= ~input->sequence_registers[s];
        }
        const bool pair = __builtin_popcount(available) >= 2;
        tier1_cfg_test_expect(tally, pair, "the fixture has two exchangeable general registers");
        if (pair)
        {
            const uint32_t a = (uint32_t)__builtin_ctz(available);
            const uint32_t b = (uint32_t)__builtin_ctz(available & (available - 1));
            uint32_t* bound = arena_push_array(output, input->value_count + 1, sizeof(uint32_t), 4);
            tier1_cfg_test_expect(tally, bound != 0, "allocate the incoming ABI binding column");
            if (bound != 0)
            {
                memset(bound, 0, (input->value_count + 1) * sizeof(uint32_t));
                // These entry definitions stand for incoming ABI values. Equal numeric vector/mask bits are untouched.
                for (uint32_t v = 0; v < input->value_count; v += 1)
                {
                    const uint32_t first = cfg.value_interval_offsets[v];
                    if (first < cfg.value_interval_offsets[v + 1] && cfg.intervals.starts[first] == input->definitions[v] && input->definitions[v] < input->block_starts[1])
                    {
                        const uint32_t fragment = cfg.allocation.fragment_offsets[first];
                        const uint8_t reg = cfg.allocation.registers[fragment];
                        bound[v] = reg < 16 ? 1u << reg : 0;
                    }
                }
                input->definition_registers = bound;
                if (failures)
                {
                    exchange_test_failures(tally, output, input, &cfg, a, b);
                }
                const uint64_t mark = output->length;
                uint8_t* expected = malloc(mark);
                tier1_cfg_test_expect(tally, expected != 0, "snapshot all preexisting CFG storage");
                if (expected != 0)
                {
                    memcpy(expected, output->base, mark);
                    uint8_t permutation[16];
                    exchange_test_identity(permutation);
                    Tier1CfgInput expected_input = *input;
                    Tier1CfgAllocation expected_cfg = cfg;
                    const uint32_t* original_allowed = input->allowed_registers;
                    const uint32_t* original_ranges = cfg.intervals.allowed_registers;
                    tier1_cfg_test_expect(tally, tier1_emit_cfg_exchange_map(permutation, output, input, &cfg) == TIER1_EMIT_OK && output->length == mark &&
                                               memcmp(&expected_input, input, sizeof(*input)) == 0 && memcmp(&expected_cfg, &cfg, sizeof(cfg)) == 0 &&
                                               memcmp(expected, output->base, mark) == 0, "identity performs no allocation or mutation");
                    permutation[a] = (uint8_t)b;
                    permutation[b] = (uint8_t)a;
                    uint8_t* expected_values = expected + (cfg.allocation.value_registers - output->base);
                    uint8_t* expected_registers = expected + (cfg.allocation.registers - output->base);
                    uint32_t* expected_sources = (uint32_t*)(expected + ((uint8_t*)cfg.move_sources - output->base));
                    uint32_t* expected_destinations = (uint32_t*)(expected + ((uint8_t*)cfg.move_destinations - output->base));
                    for (uint32_t v = 0; v < input->value_count; v += 1)
                    {
                        const uint8_t reg = expected_values[v];
                        expected_values[v] = input->classes[v] == 0 && reg < 16 ? permutation[reg] : reg;
                    }
                    for (uint32_t i = 0; i < cfg.intervals.count; i += 1)
                    {
                        for (uint32_t f = cfg.allocation.fragment_offsets[i]; f < cfg.allocation.fragment_offsets[i + 1]; f += 1)
                        {
                            const uint8_t reg = expected_registers[f];
                            expected_registers[f] = cfg.intervals.classes[i] == 0 && reg < 16 ? permutation[reg] : reg;
                            tally->spills += cfg.allocation.kinds[f] == BUSTER_TIER1_ALLOCATE_SPILL;
                            tally->unread_entries += cfg.allocation.kinds[f] == BUSTER_TIER1_ALLOCATE_REMATERIALIZE;
                        }
                    }
                    for (uint32_t m = 0; m < cfg.move_count; m += 1)
                    {
                        expected_sources[m] = expected_sources[m] < 16 ? permutation[expected_sources[m]] : expected_sources[m];
                        expected_destinations[m] = expected_destinations[m] < 16 ? permutation[expected_destinations[m]] : expected_destinations[m];
                        tally->scratch_moves += cfg.move_sources[m] == input->scratch_registers[0] || cfg.move_destinations[m] == input->scratch_registers[0];
                    }
                    const Tier1EmitError error = tier1_emit_cfg_exchange_map(permutation, output, input, &cfg);
                    tier1_cfg_test_expect(tally, error == TIER1_EMIT_OK, "complete CFG register permutation succeeds");
                    if (error == TIER1_EMIT_OK)
                    {
                        expected_input.allowed_registers = input->allowed_registers;
                        expected_input.definition_registers = input->definition_registers;
                        expected_cfg.intervals.allowed_registers = cfg.intervals.allowed_registers;
                        expected_cfg.retained_bytes += output->length - mark;
                        tier1_cfg_test_expect(tally, memcmp(expected, output->base, mark) == 0, "all old bytes equal the prescribed register rename, including spill IDs, fragment extents, move order and slot tables");
                        tier1_cfg_test_expect(tally, memcmp(&expected_input, input, sizeof(*input)) == 0 && memcmp(&expected_cfg, &cfg, sizeof(cfg)) == 0,
                                             "published metadata changes only copied mask pointers and retained bytes");
                        bool masks = true;
                        for (uint32_t v = 0; v < input->value_count; v += 1)
                        {
                            const uint32_t old_allowed = ((uint32_t*)(expected + ((const uint8_t*)original_allowed - output->base)))[v];
                            const uint32_t old_binding = ((uint32_t*)(expected + ((uint8_t*)bound - output->base)))[v];
                            const uint32_t binding = input->classes[v] == 0 && (old_binding & ((1u << a) | (1u << b))) != 0 ? 0 : old_binding;
                            masks &= input->allowed_registers[v] == (input->classes[v] == 0 ? exchange_test_mask(old_allowed, a, b) : old_allowed);
                            masks &= input->definition_registers[v] == binding;
                        }
                        for (uint32_t i = 0; i < cfg.intervals.count; i += 1)
                        {
                            const uint32_t old_allowed = ((uint32_t*)(expected + ((const uint8_t*)original_ranges - output->base)))[i];
                            masks &= cfg.intervals.allowed_registers[i] == (cfg.intervals.classes[i] == 0 ? exchange_test_mask(old_allowed, a, b) : old_allowed);
                        }
                        tier1_cfg_test_expect(tally, masks, "masks are class-scoped and only affected incoming GPR bindings are cleared for ABI entry copies");
                        const bool verified = tier1_cfg_verify(input, &cfg, scratch, &check);
                        if (!verified)
                        {
                            printf("exchange verifier failure block=%u value=%u position=%u\n", check.block, check.value, check.position);
                        }
                        tier1_cfg_test_expect(tally, verified, "renamed complete CFG passes independent verification");
                        tier1_cfg_test_expect(tally, tier1_cfg_test_certify(tally, input, &cfg, output, scratch, true), "renamed phi webs, cycles and spills pass both certificate checkers");
                        tally->allocations += 1;
                        tally->moves += cfg.move_count;
                    }
                    free(expected);
                }
            }
        }
    }
}

static void exchange_test_shapes(Tier1CfgTestTally* tally, Arena* output, Arena* scratch)
{
    for (uint32_t pressure = 0; pressure < 3; pressure += 1)
    {
        Tier1CfgTestBuilder builder = {
            .block_count = 3,
            .instructions = { 20, 16, 16 },
            .registers = { 0x88, 0x88, 0x88 },
            .scratch = { 11, 15, 0 },
            .share_slots = true,
            .use_registers = true,
        };
        tier1_cfg_test_edge(&builder, 0, 1);
        tier1_cfg_test_edge(&builder, 1, 1);
        tier1_cfg_test_edge(&builder, 1, 2);
        for (uint8_t class = 0; class < 3; class += 1)
        {
            const uint32_t first = tier1_cfg_test_value(&builder, 0, 0, class, 1u << 3);
            const uint32_t second = tier1_cfg_test_value(&builder, 0, 1, class, 1u << 7);
            const uint32_t first_operands[] = { first, builder.value_count + 1 };
            const uint32_t phi_a = tier1_cfg_test_phi(&builder, 1, class, first_operands);
            const uint32_t second_operands[] = { second, phi_a };
            const uint32_t phi_b = tier1_cfg_test_phi(&builder, 1, class, second_operands);
            tier1_cfg_test_use(&builder, phi_a, 1, 0, true);
            builder.use_register[builder.use_count - 1] = 7;
            tier1_cfg_test_use(&builder, phi_b, 1, 1, true);
            tier1_cfg_test_use(&builder, phi_a, 2, 0, true);
            tier1_cfg_test_use(&builder, phi_b, 2, 0, true);
            for (uint32_t n = 0; n < pressure * 3; n += 1)
            {
                const uint32_t value = tier1_cfg_test_value(&builder, 0, 2 + n, class, builder.registers[class]);
                builder.remat[value] = pressure == 2 && n % 2 == 0;
                tier1_cfg_test_use(&builder, value, 1, 5 + n, true);
                tier1_cfg_test_use(&builder, value, 2, 5 + n, true);
            }
        }
        Tier1CfgInput input = { 0 };
        const bool built = tier1_cfg_test_build(&builder, output, &input);
        tier1_cfg_test_expect(tally, built, "build mixed-class phi swap and pressure shapes");
        if (built)
        {
            exchange_test_map(tally, output, scratch, &input, pressure == 0);
        }
        arena_pop_to(output, 0);
        arena_pop_to(scratch, 0);
    }
}

#ifdef BUSTER_EXCHANGE_CAPACITY_REFINEMENT
static void exchange_test_optional(Tier1EmitTest* test, const Tier1SelectPlan* plan, Tier1EmitResult* emitted, uint32_t reg)
{
    uint8_t inverse[16];
    exchange_test_identity(inverse);
    inverse[X86_REGISTER_RDI] = (uint8_t)reg;
    inverse[reg] = X86_REGISTER_RDI;
    const Tier1EmitError restored = tier1_emit_cfg_exchange_map(inverse, &test->output, &emitted->cfg_input, &emitted->cfg);
    tier1_emit_test_expect(test, restored == TIER1_EMIT_OK, "restore the pre-exchange physical assignment for capacity fallback probes");
    if (restored == TIER1_EMIT_OK)
    {
        const uint64_t output_mark = test->output.length;
        const uint64_t scratch_mark = test->scratch.length;
        const uint64_t output_capacity = test->output.capacity;
        const uint64_t scratch_capacity = test->scratch.capacity;
        const Tier1CfgInput before_input = emitted->cfg_input;
        const Tier1CfgAllocation before_cfg = emitted->cfg;
        uint8_t* bytes = malloc(output_mark);
        tier1_emit_test_expect(test, bytes != 0, "snapshot the valid allocation before optional exchange exhaustion");
        if (bytes != 0)
        {
            memcpy(bytes, test->output.base, output_mark);
            for (uint32_t budget = 0; budget < 2; budget += 1)
            {
                test->scratch.capacity = budget == 0 ? scratch_mark : scratch_capacity;
                test->output.capacity = budget == 1 ? output_mark : output_capacity;
                const Tier1EmitError error = tier1_emit_cfg_exchange(plan, emitted, &test->output, &test->scratch, &emitted->cfg_input, &emitted->cfg);
                tier1_emit_test_expect(test, error == TIER1_EMIT_OK && test->output.length == output_mark && test->scratch.length == scratch_mark &&
                                           memcmp(&before_input, &emitted->cfg_input, sizeof(before_input)) == 0 && memcmp(&before_cfg, &emitted->cfg, sizeof(before_cfg)) == 0 &&
                                           memcmp(bytes, test->output.base, output_mark) == 0,
                                       "score or map exhaustion keeps the complete valid baseline allocation and succeeds");
            }
        }
        free(bytes);
        test->output.capacity = output_capacity;
        test->scratch.capacity = scratch_capacity;
    }
}
#endif

static void exchange_test_native(Tier1EmitTest* test)
{
    for (uint32_t narrow = 0; narrow < 2; narrow += 1)
    {
        Tier1CallFixture fixture = {
            .width = 8,
            .helper_count = 4,
            .kind = { TIER1_CALL_FENCE, TIER1_CALL_FENCE, TIER1_CALL_FENCE, TIER1_CALL_FENCE },
        };
        const IrSizes sizes = {
            .instruction_count = 32,
            .block_count = 4,
            .call_count = 4,
            .slot_count = 1,
            .parameter_count = 1,
        };
        IrFunction* function = &fixture.function;
        bool ready = ir_create(&test->input, &sizes, function) == IR_OK;
        tier1_emit_test_expect(test, ready, "build an incoming parameter across four hostile calls");
        if (ready)
        {
            function->result_type = IR_I64;
            function->parameter_types[0] = narrow ? IR_I8 : IR_I64;
            function->symbol_count = 5;
            function->slots[0] = (IrSlot){ .size = 8, .alignment = 8, .flags = BUSTER_IR_SLOT_ADDRESS_TAKEN };
            uint32_t next = 0;
            const uint32_t parameter = tier1_select_test_append(function, &next, IR_PARAM, narrow ? IR_I8 : IR_I64, 0, BUSTER_IR_NONE, BUSTER_IR_NONE);
            const uint32_t first_address = tier1_select_test_append(function, &next, IR_STACK_ADDR, IR_PTR, 0, BUSTER_IR_NONE, BUSTER_IR_NONE);
            const uint32_t address_value = tier1_select_test_append(function, &next, IR_PTRTOINT, IR_I64, first_address, BUSTER_IR_NONE, BUSTER_IR_NONE);
            for (uint32_t block = 0; block < 4; block += 1)
            {
                if (block != 0)
                {
                    function->block_offsets[block] = next;
                }
                tier1_call_descriptor(function, block, 0, 0, IR_VOID);
                tier1_select_test_append(function, &next, IR_CALL, IR_VOID, block + 1, block, BUSTER_IR_NONE);
                if (block == 0)
                {
                    const uint32_t again = tier1_select_test_append(function, &next, IR_STACK_ADDR, IR_PTR, 0, BUSTER_IR_NONE, BUSTER_IR_NONE);
                    const uint32_t integer = tier1_select_test_append(function, &next, IR_PTRTOINT, IR_I64, again, BUSTER_IR_NONE, BUSTER_IR_NONE);
                    const uint32_t difference = tier1_select_test_append(function, &next, IR_SUB, IR_I64, address_value, integer, BUSTER_IR_NONE);
                    tier1_select_test_append(function, &next, IR_STORE, IR_VOID, again, difference, BUSTER_IR_NONE);
                }
                if (block != 3)
                {
                    tier1_select_test_append(function, &next, IR_BR, IR_VOID, block + 1, BUSTER_IR_NONE, BUSTER_IR_NONE);
                }
            }
            const uint32_t widened = narrow ? tier1_select_test_append(function, &next, IR_SEXT, IR_I64, parameter, BUSTER_IR_NONE, BUSTER_IR_NONE) : parameter;
            const uint32_t last_address = tier1_select_test_append(function, &next, IR_STACK_ADDR, IR_PTR, 0, BUSTER_IR_NONE, BUSTER_IR_NONE);
            const uint32_t difference = tier1_select_test_append(function, &next, IR_LOAD, IR_I64, last_address, BUSTER_IR_NONE, BUSTER_IR_NONE);
            const uint32_t result = tier1_select_test_append(function, &next, IR_ADD, IR_I64, widened, difference, BUSTER_IR_NONE);
            tier1_select_test_append(function, &next, IR_RET, IR_VOID, result, BUSTER_IR_NONE, BUSTER_IR_NONE);
            function->instruction_count = next;
            function->block_offsets[4] = next;
            const uint32_t enter[] = { 0, 1, 2, 3 };
            const uint32_t leave[] = { 4, 4, 4, 4 };
            const IrDominance dominance = { .enter = enter, .leave = leave, .block_count = 4 };
            Tier1SelectPlan plan;
            uint32_t node = BUSTER_IR_NONE;
            const Tier1SelectError selected = tier1_select_plan(function, &dominance, &test->output, &test->scratch, &plan, &node);
            tier1_emit_test_expect(test, selected == TIER1_SELECT_OK, "native exchange fixture selects");
            Tier1EmitDiagnostic diagnostic = { 0 };
            const Tier1EmitOptions options = { .certify = true, .diagnostic = &diagnostic, .register_mask = tier1_liveness_register_mask(), .rematerialize = false };
            Tier1EmitResult emitted;
            const Tier1EmitError error = selected == TIER1_SELECT_OK ? tier1_emit_function(&plan, &options, test->allowed, &test->output, &test->scratch, &emitted, &node) : TIER1_EMIT_INVALID;
            if (error != TIER1_EMIT_OK)
            {
                printf("exchange native narrow=%u selected=%u error=%u node=%u cause=%u cause_error=%u\n", narrow, selected, error, node, diagnostic.cause, diagnostic.error);
            }
            tier1_emit_test_expect(test, error == TIER1_EMIT_OK, "native exchange emits and its full machine-code certificate proves ABI entry and calls");
            if (error == TIER1_EMIT_OK)
            {
                const uint32_t value = emitted.node_values[parameter];
                uint32_t location = UINT32_MAX;
                uint8_t kind = UINT8_MAX;
                const bool located = emitted.general && tier1_cfg_location(&emitted.cfg, value, 0, &location, &kind);
                const uint32_t binding = emitted.cfg_input.definition_registers != 0 ? emitted.cfg_input.definition_registers[value] : 0;
                printf("exchange native narrow=%u entry=%u kind=%u binding=%x callees=%x call_stores=%u call_loads=%u spills=%u/%u edges=%u\n",
                       narrow, location, kind, binding, emitted.callee_used, emitted.call_stores, emitted.call_loads,
                       emitted.spill_stores, emitted.spill_loads, emitted.cfg.move_count);
                tier1_emit_test_expect(test, located && kind == BUSTER_TIER1_ALLOCATE_REGISTER && location != X86_REGISTER_RDI &&
                                           ((emitted.callee_registers >> location) & 1) != 0 && binding == 0,
                                       "profitable exchange actually moves the incoming parameter into an existing callee register and frees its entry binding");
                Tier1CfgCheck check;
                tier1_emit_test_expect(test, tier1_cfg_verify(&emitted.cfg_input, &emitted.cfg, &test->scratch, &check), "native allocation verifies after renaming");
                Tier1CallObserved observed = { 0 };
                uint8_t* mapping = mmap(0, BUSTER_TIER1_CALL_CODE_BYTES, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
                uint64_t targets[BUSTER_TIER1_CALL_HELPERS] = { 0 };
                const uint8_t* entry = mapping != MAP_FAILED ? tier1_call_load(test, &fixture, &emitted, &observed, mapping, targets) : 0;
                tier1_emit_test_expect(test, entry != 0, "hostile-call fixture loads on the checked native target");
                for (uint32_t sample = 0; entry != 0 && sample < 16; sample += 1)
                {
                    const uint64_t arguments[6] = { UINT64_C(0xfedcba9876543210) - sample * UINT64_C(0x102030405060711) };
                    const uint64_t actual = tier1_call_invoke(entry, arguments);
                    const uint64_t expected = narrow ? (uint64_t)(int64_t)(int8_t)arguments[0] : arguments[0];
                    bool calls = true;
                    for (uint32_t helper = 0; helper < 4; helper += 1)
                    {
                        calls &= observed.count[helper] == sample + 1 && observed.alignment[helper] == 8;
                    }
                    tier1_emit_test_expect(test, actual == expected && calls, "renamed parameter, displaced callee value and narrow canonicalization survive all hostile ABI calls");
                }
                if (mapping != MAP_FAILED)
                {
                    munmap(mapping, BUSTER_TIER1_CALL_CODE_BYTES);
                }
#ifdef BUSTER_EXCHANGE_CAPACITY_REFINEMENT
                if (located && location < 16 && location != X86_REGISTER_RDI)
                {
                    exchange_test_optional(test, &plan, &emitted, location);
                }
#endif
            }
        }
        arena_pop_to(&test->input, 0);
        arena_pop_to(&test->output, 0);
        arena_pop_to(&test->scratch, 0);
    }
}
