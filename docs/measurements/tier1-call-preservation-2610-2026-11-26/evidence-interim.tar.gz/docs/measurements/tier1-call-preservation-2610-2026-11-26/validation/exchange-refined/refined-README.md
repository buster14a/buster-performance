# Issue 2610: exchange placement and optional memory fallback

This follows the frozen bit-128/native evidence, without replacing that
receipt. The production-shaped prototype now calls exchange once in
`tier1_emit_cfg_function`, immediately after the existing one-/two-call order
comparison. Callee-use discovery, final CFG certification, call-save row
discovery, frame layout and emitted-code certification all still follow it.
Neither allocation-order wrapper calls exchange. The optional step retains the
valid baseline on scoring or map allocation exhaustion; an invalid map remains
an error.

The actual updated sources pass **81 map checks and 70 native checks, zero
failures and zero native skips**, including the same 32 hostile-call executions
and six before/after CFG certificates as the frozen measurement variant. The
native locations, callee mask, and call/spill/edge record counts are identical
in the two receipt logs. This is focused evidence, not whole-corpus ELF parity.

The eight added checks exercise the new fallback behavior directly. After
each native fixture, the map is inverted to restore its baseline physical
assignment. A byte snapshot of the complete output arena and copies of both
published CFG structures are then taken. The actual exchange wrapper is called
first with no remaining scratch capacity, then with no remaining output
capacity. Each call must succeed with both arena lengths, both CFG structures,
and every prior output byte unchanged. No fallback behavior is simulated.

Build the same focused backend harness with the additional flag
`-DBUSTER_EXCHANGE_CAPACITY_REFINEMENT=1` and output name `refined`, then run it.
`refined-tests.c` is the exact test source for this receipt; place it at the
harness's `tests.c` path. The generator, runner and full build command are in
the earlier exchange-native-evidence.tar.gz packet. Reconstruct the updated
prototype from the same base commit, `refined-cfg.patch`, and the archived
`refined-source-map.c` and `refined-source-cost.c` at their original compiler
source paths. Source hashes and the complete build/run logs are included.

The frozen measurement variant's mutation proof belongs to the earlier
archive. No later source changes were used for that proof, and no changed
production or tagged source is included in its receipt.
