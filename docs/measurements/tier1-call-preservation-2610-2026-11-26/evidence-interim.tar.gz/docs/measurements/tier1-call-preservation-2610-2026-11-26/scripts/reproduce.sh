#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Rebuild paired programs from externally acquired pinned compiler products and inputs.
set -euo pipefail
unset BUSTER_TIER1_DUMP_BLOCKS BUSTER_TIER1_DUMP_FILE
if [ "$#" -lt 6 ] || [ "$#" -gt 7 ]; then
  printf 'usage: %s WORK INPUTS LLVM_BIN BASE_COMPILER RECIPE_COMPILER MEASUREMENT_COMPILER [GUARDED_COMPILER]\n' "$0" >&2
  exit 2
fi
packet=$(cd "$(dirname "$0")/.." && pwd)
mkdir -p "$1"
work=$(realpath "$1")
inputs=$(realpath "$2")
llvm=$(realpath "$3")
baseline=$(realpath "$4")
recipe=$(realpath "$5")
measurement=$(realpath "$6")
guarded=
if [ "$#" = 7 ]; then guarded=$(realpath "$7"); fi
export PATH="$llvm:$PATH"
resource=$("$llvm/clang" -print-resource-dir)/include
scripts=$inputs/lua-evidence/docs/measurements/tier1-reciprocal-141-2026-11-01/9700x/lua
(cd "$inputs" && sha256sum --check --status "$packet/inputs/SHA256SUMS")
cp "$packet/inputs/speedtest1-unity.c" "$work/speedtest1-unity.c"
cp "$packet/inputs/frame.c" "$work/frame.c"
sources=()
for unit in lapi lcode lctype ldebug ldo ldump lfunc lgc llex lmem lobject lopcodes lparser lstate lstring ltable ltm lundump lvm lzio lauxlib lbaselib lcorolib ldblib liolib lmathlib loadlib loslib lstrlib ltablib lutf8lib linit lua; do
  sources+=("$inputs/lua-5.4.8/src/$unit.c")
done
"$llvm/clang" -O0 "$work/frame.c" -o "$work/frame-clang0"
"$work/frame-clang0" > "$work/frame.clang0.out"
"$llvm/clang" -O0 -std=gnu99 -DLUA_COMPAT_5_3 -DLUA_USE_LINUX '-Dluai_makeseed(L)=0' -o "$work/lua-clang0" "${sources[@]}" -lm -ldl
for script in calls tables strings arithmetic closures; do
  "$work/lua-clang0" "$scripts/$script.lua" > "$work/$script.clang0.out"
done
common=(--tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --tier1-report)
sqlite_options=(-DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$inputs/sqlite" "-I$inputs")
build()
{
  local compiler=$1 mask=$2 label=$3
  local out=$work/$label
  mkdir -p "$out"
  if [ -e "$out/speedtest1" ] || [ -e "$out/lua" ]; then
    printf 'refusing to overwrite recorded executables: %s\n' "$out" >&2
    return 1
  fi
  rm -f "$out/frame.kinds" "$out/speedtest1.kinds" "$out/lua.kinds"
  BUSTER_TIER1_EXPERIMENT=$mask BUSTER_TIER1_KINDS="$out/frame.kinds" "$compiler" "${common[@]}" --verify --tier1-refusals -o "$out/frame" "$work/frame.c" > "$out/frame-build.txt" 2>&1
  "$out/frame" > "$out/frame.out"
  cmp "$work/frame.clang0.out" "$out/frame.out"
  awk -F '\t' '$1 == "tier1" { for (i = 2; i <= NF; i++) { split($i, p, "="); f[p[1]] = p[2] } found = 1; good = f["compiled"] == 6 && f["code_certified"] == 6 && f["code_uncertified"] == 0 && f["fallbacks"] == 0 && f["internal_failures"] == 0 && f["resource_failures"] == 0 } END { exit !(found && good) }' "$out/frame-build.txt"
  BUSTER_TIER1_EXPERIMENT=$mask BUSTER_TIER1_KINDS="$out/speedtest1.kinds" "$compiler" "${common[@]}" "${sqlite_options[@]}" -o "$out/speedtest1" "$work/speedtest1-unity.c" -lm > "$out/st-build.txt" 2>&1
  BUSTER_TIER1_EXPERIMENT=$mask BUSTER_TIER1_KINDS="$out/lua.kinds" "$compiler" "${common[@]}" -std=gnu99 -DLUA_COMPAT_5_3 -DLUA_USE_LINUX '-Dluai_makeseed(L)=0' -o "$out/lua" "${sources[@]}" -lm -ldl > "$out/lua-build.txt" 2>&1
  mkdir -p "$out/verify-data/tmp"
  SQLITE_TMPDIR="$out/verify-data/tmp" "$out/speedtest1" --shrink-memory --reprepare --stats --journal wal --size 5 --heap 40000000 64 --testset mix1 --verify "$out/verify-data/test.db" > "$out/st.verify.txt" 2>&1
  rg -F 'Verification Hash: 1248168 a7fa3957840af6d608d53fcdd57a125b35385b9d1e813739' "$out/st.verify.txt"
  for script in calls tables strings arithmetic closures; do
    "$out/lua" "$scripts/$script.lua" > "$out/$script.out" 2> "$out/$script.err"
    cmp "$work/$script.clang0.out" "$out/$script.out"
  done
  sha256sum "$compiler" "$out/speedtest1" "$out/lua" > "$out/hashes.sha256"
  printf '%s: compiler and native checks passed\n' "$label"
}
parity()
{
  local reference=$work/$1 out=$work/$2
  : > "$out/parity.txt"
  for program in speedtest1 lua; do
    sha256sum "$reference/$program" "$out/$program" > "$out/$program.section-inputs.sha256"
    "$llvm/llvm-objcopy" --dump-section ".text=$out/$program.reference.text" "$reference/$program" /dev/null
    "$llvm/llvm-objcopy" --dump-section ".text=$out/$program.text" "$out/$program" /dev/null
    sha256sum --check --status "$out/$program.section-inputs.sha256"
    cmp "$out/$program.reference.text" "$out/$program.text"
    cmp "$reference/$program" "$out/$program"
    printf '%s: whole ELF parity exact\n' "$program" >> "$out/parity.txt"
  done
}
build "$baseline" 0 baseline
build "$recipe" 0 recipe
build "$measurement" 0 variants/0
parity baseline variants/0
build "$measurement" 1 variants/1
parity recipe variants/1
for mask in 2 3 5 7 11; do build "$measurement" "$mask" "variants/$mask"; done
if [ -n "$guarded" ]; then
  build "$guarded" 0 guarded/0
  parity baseline guarded/0
  build "$guarded" 2 guarded/2
  parity variants/2 guarded/2
  for mask in 6 18 34; do build "$guarded" "$mask" "guarded/$mask"; done
  BUSTER_TIER1_EXPERIMENT=18 "$guarded" test-tier1-emit > "$work/guarded/18/test-tier1-emit.log" 2>&1
  for mask in 0 18; do
    out=$work/guarded/$mask
    BUSTER_TIER1_EXPERIMENT=$mask BUSTER_TIER1_KINDS="$out/speedtest1-verified.kinds" "$guarded" "${common[@]}" --verify "${sqlite_options[@]}" -o "$out/speedtest1-verified" "$work/speedtest1-unity.c" -lm > "$out/st-verified-build.txt" 2>&1
    cmp "$out/speedtest1" "$out/speedtest1-verified"
    cmp "$out/speedtest1.kinds" "$out/speedtest1-verified.kinds"
    sha256sum "$out/speedtest1" "$out/speedtest1-verified" > "$out/verified-parity.sha256"
  done
fi
