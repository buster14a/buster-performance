#include <stdio.h>
#include "frame-source.inc"

int main(void)
{
    return fwrite(check_test_tier1_frame_source, 1, sizeof(check_test_tier1_frame_source) - 1, stdout) != sizeof(check_test_tier1_frame_source) - 1;
}
