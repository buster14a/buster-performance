#!/usr/bin/env bash
set -euo pipefail
task=/workspace/scratch/f0b04b7641b0
export PATH=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
compiler=$task/guarded-ci/product/bin/compiler
inputs=$task/buster/build/2610-inputs
out=$task/guarded-artifacts/18
resource=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/lib/clang/23/include
cd "$task/buster-tags"
BUSTER_TIER1_EXPERIMENT=18 "$compiler" test-tier1-emit > "$out/test-tier1-emit.log" 2>&1
printf 'Mask 18 full test-tier1-emit passed.\n'
cd "$task"
rm -f "$out/speedtest1-verified.kinds"
BUSTER_TIER1_EXPERIMENT=18 BUSTER_TIER1_KINDS="$out/speedtest1-verified.kinds" "$compiler" --tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --tier1-report --verify -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$inputs/sqlite" "-I$inputs" -o "$out/speedtest1-verified" "$task/baseline-artifacts/speedtest1-unity.c" -lm > "$out/st-verified-build.txt" 2>&1
sha256sum "$out/speedtest1" "$out/speedtest1-verified" "$out/speedtest1.kinds" "$out/speedtest1-verified.kinds" > "$out/verified-parity.sha256"
cmp "$out/speedtest1" "$out/speedtest1-verified"
cmp "$out/speedtest1.kinds" "$out/speedtest1-verified.kinds"
printf 'Mask 18 SQLite --verify: whole-ELF and origin-sidecar parity exact.\n'
