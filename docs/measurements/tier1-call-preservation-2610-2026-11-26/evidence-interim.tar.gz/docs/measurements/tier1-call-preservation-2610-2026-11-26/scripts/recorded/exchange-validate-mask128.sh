#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
set -euo pipefail
unset BUSTER_TIER1_DUMP_BLOCKS BUSTER_TIER1_DUMP_FILE
task=/workspace/scratch/f0b04b7641b0
export PATH=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
compiler=$task/exchange-ci/product/bin/compiler
inputs=$task/buster/build/2610-inputs
resource=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/lib/clang/23/include
cd "$task/buster-tags"
BUSTER_TIER1_EXPERIMENT=128 "$compiler" test-tier1-emit > "$task/exchange-artifacts/128/test-tier1-emit.log" 2>&1
printf 'Mask128 full test-tier1-emit passed.\n'
cd "$task"
for mask in 0 128; do
    out=$task/exchange-artifacts/$mask
    if [ -e "$out/speedtest1-verified" ]; then
        printf 'Refusing to overwrite previous verified executable: %s\n' "$out" >&2
        exit 1
    fi
    rm -f "$out/speedtest1-verified.kinds"
    BUSTER_TIER1_EXPERIMENT=$mask BUSTER_TIER1_KINDS="$out/speedtest1-verified.kinds" "$compiler" --tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --tier1-report --verify -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$inputs/sqlite" "-I$inputs" -o "$out/speedtest1-verified" "$task/baseline-artifacts/speedtest1-unity.c" -lm > "$out/st-verified-build.txt" 2>&1
    sha256sum "$out/speedtest1" "$out/speedtest1-verified" "$out/speedtest1.kinds" "$out/speedtest1-verified.kinds" > "$out/verified-parity.sha256"
    cmp "$out/speedtest1" "$out/speedtest1-verified"
    cmp "$out/speedtest1.kinds" "$out/speedtest1-verified.kinds"
    printf 'Mask%s SQLite --verify: whole-ELF and origin-sidecar parity exact.\n' "$mask"
done
