#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Import bounded receipts and text sidecars; deliberately omit executables and raw CFG/Callgrind files.
set -euo pipefail
source_dir=$(realpath "${1:?usage: import-variant.sh SOURCE_DIRECTORY LABEL}")
label=${2:?variant label required, for example guarded/18}
[[ "$label" =~ ^[a-zA-Z0-9][a-zA-Z0-9/_-]*$ ]]
packet=$(cd "$(dirname "$0")/.." && pwd)
dest=$packet/local/$label
mkdir -p "$dest"
for name in frame-build.txt frame.out frame.err st.verify.txt hashes.sha256 parity.txt parity.sha256 verified-parity.sha256 test-tier1-emit.log; do
  if [ -f "$source_dir/$name" ]; then cp "$source_dir/$name" "$dest/"; fi
done
for script in calls tables strings arithmetic closures; do
  for extension in out err; do
    if [ -f "$source_dir/$script.$extension" ]; then cp "$source_dir/$script.$extension" "$dest/"; fi
  done
done
for program in frame speedtest1 lua; do
  if [ -f "$source_dir/$program.kinds" ]; then gzip -n -c "$source_dir/$program.kinds" > "$dest/$program.kinds.gz"; fi
  for suffix in section-inputs.sha256 section-inputs-check.txt; do
    if [ -f "$source_dir/$program.$suffix" ]; then cp "$source_dir/$program.$suffix" "$dest/"; fi
  done
done
for corpus in st lua st-verified; do
  if [ -f "$source_dir/$corpus-build.txt" ]; then
    gzip -n -c "$source_dir/$corpus-build.txt" > "$dest/$corpus-build.txt.gz"
    rg '^tier1\t|^tier1-vectorize\t' "$source_dir/$corpus-build.txt" > "$dest/$corpus-summary.txt"
  fi
done
variant_log=$(dirname "$source_dir")/variant-$(basename "$source_dir").log
if [ -f "$variant_log" ]; then cp "$variant_log" "$dest/build-and-verify.log"; fi
printf 'Imported from %s\nNo executable, raw CFG dump or Callgrind capture was copied.\n' "$source_dir" > "$dest/IMPORT.txt"
