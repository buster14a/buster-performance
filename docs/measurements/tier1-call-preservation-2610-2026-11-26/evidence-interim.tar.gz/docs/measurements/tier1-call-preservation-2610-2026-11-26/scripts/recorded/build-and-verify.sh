#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/f0b04b7641b0
export PATH=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
compiler=$PWD/head-ci/product/bin/compiler
inputs=$PWD/buster/build/2610-inputs
out=$PWD/head-artifacts
resource=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/lib/clang/23/include
scripts=$inputs/lua-evidence/docs/measurements/tier1-reciprocal-141-2026-11-01/9700x/lua

"$compiler" --tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --tier1-report -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$inputs/sqlite" "-I$inputs" -o "$out/speedtest1" "$PWD/baseline-artifacts/speedtest1-unity.c" -lm > "$out/st-build.txt" 2>&1
printf 'Head SQLite build completed.\n'

sources=()
for unit in lapi lcode lctype ldebug ldo ldump lfunc lgc llex lmem lobject lopcodes lparser lstate lstring ltable ltm lundump lvm lzio lauxlib lbaselib lcorolib ldblib liolib lmathlib loadlib loslib lstrlib ltablib lutf8lib linit lua; do
  sources+=("$inputs/lua-5.4.8/src/$unit.c")
done
"$compiler" --tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --tier1-report -std=gnu99 -DLUA_COMPAT_5_3 -DLUA_USE_LINUX '-Dluai_makeseed(L)=0' -o "$out/lua" "${sources[@]}" -lm -ldl > "$out/lua-build.txt" 2>&1
printf 'Head Lua build completed.\n'

mkdir -p "$out/verify-data/tmp"
SQLITE_TMPDIR="$out/verify-data/tmp" "$out/speedtest1" --shrink-memory --reprepare --stats --journal wal --size 5 --heap 40000000 64 --testset mix1 --verify "$out/verify-data/test.db" > "$out/st.verify.txt" 2>&1
rg -F 'Verification Hash: 1248168 a7fa3957840af6d608d53fcdd57a125b35385b9d1e813739' "$out/st.verify.txt"
for script in calls tables strings arithmetic closures; do
  "$out/lua" "$scripts/$script.lua" > "$out/$script.out" 2> "$out/$script.err"
  cmp "$PWD/baseline-artifacts/$script.clang0.out" "$out/$script.out"
  printf '%s: output matches Clang -O0 oracle\n' "$script"
done
sha256sum "$compiler" "$out/speedtest1" "$out/lua" > "$out/hashes.sha256"
