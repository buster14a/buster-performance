#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/f0b04b7641b0
mask=${1:?experiment mask required}
case "$mask" in 0|34) ;; *) exit 2 ;; esac
export PATH=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
compiler=$PWD/guarded-ci/product/bin/compiler
inputs=$PWD/buster/build/2610-inputs
out=$PWD/guarded-artifacts/$mask
resource=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/lib/clang/23/include
sources=()
for unit in lapi lcode lctype ldebug ldo ldump lfunc lgc llex lmem lobject lopcodes lparser lstate lstring ltable ltm lundump lvm lzio lauxlib lbaselib lcorolib ldblib liolib lmathlib loadlib loslib lstrlib ltablib lutf8lib linit lua; do
  sources+=("$inputs/lua-5.4.8/src/$unit.c")
done
rm -f "$out/lua-dump.kinds" "$out/lua-cfg.dump"
BUSTER_TIER1_EXPERIMENT=$mask BUSTER_TIER1_KINDS="$out/lua-dump.kinds" BUSTER_TIER1_DUMP_BLOCKS=300 BUSTER_TIER1_DUMP_FILE="$out/lua-cfg.dump" "$compiler" --tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --tier1-report -std=gnu99 -DLUA_COMPAT_5_3 -DLUA_USE_LINUX '-Dluai_makeseed(L)=0' -o "$out/lua-dump" "${sources[@]}" -lm -ldl > "$out/lua-dump-build.txt" 2>&1
cmp "$out/lua" "$out/lua-dump"
cmp "$out/lua.kinds" "$out/lua-dump.kinds"
sha256sum "$out/lua" "$out/lua-dump" "$out/lua.kinds" "$out/lua-dump.kinds" "$out/lua-cfg.dump" > "$out/lua-dump-parity.sha256"
rm "$out/lua-dump"
printf 'Mask %s Lua CFG dump: whole-ELF and sidecar parity exact.\n' "$mask"
awk -F '\t' '$1 == "luaV_execute" { print "luaV_execute records=" length($2) }' "$out/lua.kinds"
rg '^DUMP' "$out/lua-cfg.dump"
