#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Frozen-corpus validation for the hosted #2610 register-permutation experiment.
set -euo pipefail
unset BUSTER_TIER1_DUMP_BLOCKS BUSTER_TIER1_DUMP_FILE
cd /workspace/scratch/f0b04b7641b0
mask=${1:?experiment mask required}
case "$mask" in 0|2|128) ;; *) exit 2 ;; esac
export PATH=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
compiler=$PWD/exchange-ci/product/bin/compiler
inputs=$PWD/buster/build/2610-inputs
out=$PWD/exchange-artifacts/$mask
resource=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/lib/clang/23/include
scripts=$inputs/lua-evidence/docs/measurements/tier1-reciprocal-141-2026-11-01/9700x/lua
if [ -e "$out/speedtest1" ] || [ -e "$out/lua" ] || [ -e "$out/frame" ]; then
    printf 'Refusing to overwrite recorded program executables: %s\n' "$out" >&2
    exit 1
fi
mkdir -p "$out"
rm -f "$out/frame.kinds" "$out/speedtest1.kinds" "$out/lua.kinds" "$out/cfg.dump" "$out/lua-cfg.dump"

BUSTER_TIER1_EXPERIMENT=$mask BUSTER_TIER1_KINDS="$out/frame.kinds" "$compiler" --tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --verify --tier1-report --tier1-refusals -o "$out/frame" "$PWD/experiment-artifacts/frame.c" > "$out/frame-build.txt" 2>&1
"$out/frame" > "$out/frame.out" 2> "$out/frame.err"
cmp "$PWD/experiment-artifacts/frame.clang0.out" "$out/frame.out"
awk -F '\t' '$1 == "tier1" { for (i = 2; i <= NF; i++) { split($i, pair, "="); fields[pair[1]] = pair[2] } found = 1; good = fields["compiled"] == 6 && fields["code_certified"] == 6 && fields["code_uncertified"] == 0 && fields["fallbacks"] == 0 && fields["internal_failures"] == 0 && fields["resource_failures"] == 0 } END { exit !(found && good) }' "$out/frame-build.txt"
printf 'Variant %s: six frame-fixture functions certified; native output matches Clang.\n' "$mask"

dump_environment=()
if [ "$mask" = 128 ]; then dump_environment=(BUSTER_TIER1_DUMP_BLOCKS=300 "BUSTER_TIER1_DUMP_FILE=$out/cfg.dump"); fi
env BUSTER_TIER1_EXPERIMENT="$mask" "BUSTER_TIER1_KINDS=$out/speedtest1.kinds" "${dump_environment[@]}" "$compiler" --tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --tier1-report -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$inputs/sqlite" "-I$inputs" -o "$out/speedtest1" "$PWD/baseline-artifacts/speedtest1-unity.c" -lm > "$out/st-build.txt" 2>&1
awk -F '\t' '$1 == "tier1" { for (i = 2; i <= NF; i++) { split($i, pair, "="); fields[pair[1]] = pair[2] } found = 1; good = fields["compiled"] == 2709 && fields["fallbacks"] == 0 && fields["internal_failures"] == 0 && fields["resource_failures"] == 0 } END { exit !(found && good) }' "$out/st-build.txt"
printf 'Variant %s: SQLite built with original Tier 1 coverage.\n' "$mask"

sources=()
for unit in lapi lcode lctype ldebug ldo ldump lfunc lgc llex lmem lobject lopcodes lparser lstate lstring ltable ltm lundump lvm lzio lauxlib lbaselib lcorolib ldblib liolib lmathlib loadlib loslib lstrlib ltablib lutf8lib linit lua; do
    sources+=("$inputs/lua-5.4.8/src/$unit.c")
done
dump_environment=()
if [ "$mask" = 128 ]; then dump_environment=(BUSTER_TIER1_DUMP_BLOCKS=300 "BUSTER_TIER1_DUMP_FILE=$out/lua-cfg.dump"); fi
env BUSTER_TIER1_EXPERIMENT="$mask" "BUSTER_TIER1_KINDS=$out/lua.kinds" "${dump_environment[@]}" "$compiler" --tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --tier1-report -std=gnu99 -DLUA_COMPAT_5_3 -DLUA_USE_LINUX '-Dluai_makeseed(L)=0' -o "$out/lua" "${sources[@]}" -lm -ldl > "$out/lua-build.txt" 2>&1
awk -F '\t' '$1 == "tier1" { for (i = 2; i <= NF; i++) { split($i, pair, "="); fields[pair[1]] = pair[2] } found = 1; good = fields["compiled"] == 1086 && fields["unsupported"] == 1 && fields["fallbacks"] == 1 && fields["internal_failures"] == 0 && fields["resource_failures"] == 0 } END { exit !(found && good) }' "$out/lua-build.txt"
rg '^tier1-kind-outcome\tluaD_rawrunprotected\tcategory=unsupported\tstage=lowering\tcause=admission\terror=2\temission_error=0\tfallback=1\t' "$out/lua-build.txt"
printf 'Variant %s: Lua built with its original unsupported function only.\n' "$mask"

case "$mask" in
    0|2)
        reference=$PWD/baseline-artifacts
        kind_reference=$PWD/experiment-artifacts/0
        if [ "$mask" = 2 ]; then reference=$PWD/experiment-artifacts/2; kind_reference=$reference; fi
        : > "$out/parity.txt"
        for program in speedtest1 lua; do
            sha256sum "$reference/$program" "$out/$program" "$kind_reference/$program.kinds" "$out/$program.kinds" >> "$out/parity.sha256"
            cmp "$reference/$program" "$out/$program"
            cmp "$kind_reference/$program.kinds" "$out/$program.kinds"
            printf '%s: complete ELF and origin sidecar parity exact\n' "$program" >> "$out/parity.txt"
        done
        cat "$out/parity.txt"
        ;;
esac

mkdir -p "$out/verify-data/tmp"
SQLITE_TMPDIR="$out/verify-data/tmp" "$out/speedtest1" --shrink-memory --reprepare --stats --journal wal --size 5 --heap 40000000 64 --testset mix1 --verify "$out/verify-data/test.db" > "$out/st.verify.txt" 2>&1
rg -F 'Verification Hash: 1248168 a7fa3957840af6d608d53fcdd57a125b35385b9d1e813739' "$out/st.verify.txt"
for script in calls tables strings arithmetic closures; do
    "$out/lua" "$scripts/$script.lua" > "$out/$script.out" 2> "$out/$script.err"
    cmp "$PWD/baseline-artifacts/$script.clang0.out" "$out/$script.out"
    printf 'Variant %s %s: output matches Clang -O0 oracle\n' "$mask" "$script"
done
sha256sum "$compiler" "$out/frame" "$out/speedtest1" "$out/lua" "$out/frame.kinds" "$out/speedtest1.kinds" "$out/lua.kinds" > "$out/hashes.sha256"
