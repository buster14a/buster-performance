#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
set -euo pipefail
cd "$(dirname "$0")/.."
manifest_tmp=$(mktemp)
trap 'rm -f "$manifest_tmp"' EXIT
while IFS= read -r file; do
  [ "$file" = SHA256SUMS ] && continue
  sha256sum "$file"
done < <(rg --files --hidden -g '!**/.git/**' | LC_ALL=C sort) > "$manifest_tmp"
cp "$manifest_tmp" SHA256SUMS
sha256sum --check --status SHA256SUMS
