#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/f0b04b7641b0
mask=${1:?experiment mask required}
case "$mask" in 0|1|2|3|5|7|10|11) ;; *) exit 2 ;; esac
export PATH=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
compiler=$PWD/measurement-ci/product/bin/compiler
inputs=$PWD/buster/build/2610-inputs
out=$PWD/experiment-artifacts/$mask
resource=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/lib/clang/23/include
records=$(awk -F '\t' '$1 == "sqlite3RunParser" { print length($2) }' "$out/speedtest1.kinds")
test -n "$records"
awk -F '\t' -v records="$records" 'length($2) == records { print $1 }' "$out/speedtest1.kinds" > "$out/runparser-record-candidates.txt"
BUSTER_TIER1_EXPERIMENT=$mask BUSTER_TIER1_DUMP_BLOCKS=1 BUSTER_TIER1_DUMP_FILE=/dev/stdout "$compiler" --tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --tier1-report -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$inputs/sqlite" "-I$inputs" -o "$out/runparser-dump-speedtest1" "$PWD/baseline-artifacts/speedtest1-unity.c" -lm 2> "$out/runparser-dump-build.txt" | awk -v wanted="$records" '$1 == "DUMP" { keep = 0; for (i = 1; i <= NF; i++) if ($i == "records=" wanted) keep = 1 } keep { print }' > "$out/runparser-candidates.dump"
test -s "$out/runparser-candidates.dump"
cmp "$out/speedtest1" "$out/runparser-dump-speedtest1"
sha256sum "$out/speedtest1" "$out/runparser-dump-speedtest1" "$out/runparser-candidates.dump" > "$out/runparser-dump-parity.sha256"
rm "$out/runparser-dump-speedtest1"
printf 'Variant %s RunParser candidate dump: records=%s, whole-ELF parity exact.\n' "$mask" "$records"
rg '^DUMP' "$out/runparser-candidates.dump"
