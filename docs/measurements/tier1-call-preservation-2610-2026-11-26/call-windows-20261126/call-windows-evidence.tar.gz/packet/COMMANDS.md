# Commands and reproduction

## Executed records

metadata/build-test-commands.txt records both source-stage build commands,
the first core build's missing completion evidence, its successful retry,
the exporter-fix build, and all eight emitter test invocations.

metadata/executed-commands.txt records the six successful candidate
compiles, two final normalization compiles, full-ELF comparisons, and all
three sequential run-pair invocations. These were executed from the
recovered directory with the absolute paths recorded in the file.
metadata/main-c992-control-commands.txt contains the later main control
compiles and comparisons; metadata/main-c992-build.log.gz is its retained
build report. No reconstructed build command is labeled as an executed
command for that refresh.

The successful workload compiles use --tier1 --lanes 1, --verify, the
pinned LLVM resource-header directory, unchanged workload sources, and
-fno-asynchronous-unwind-tables. SQLite uses the existing unity source and
SQLite configuration defines; Lua uses the existing 33-source ordering and
deterministic luai_makeseed(L)=0 define.

## Reproduction template

The following is a reproduction template, not an additional executed
measurement claim. Restore the frozen workload sources and toolchain from
INPUTS_AND_TOOLS.md, restore the measured source commit, and build the
compiler following the executed record. Rebase only the filesystem paths
in the recorded compile commands, preserving all flags and inputs.

Build the small C helpers with the local C compiler:

```sh
cc -O2 -std=c17 tools/measure-2610-v2.c -o measure-2610-v2
cc -O2 -std=c17 tools/gap-2610-v2.c -o gap-2610-v2
```

The measured compiler binaries are not redistributed. The frozen binary
hashes are in PROVENANCE.md and metadata/external-tools.sha256. Independent
rebuilds may differ as binaries; the exact recorded source and command
inputs identify what was measured.

For each already compiled candidate, run:

```sh
./measure-2610-v2 run-pair "$OUT" "$SCRIPTS" "$VALGRIND" "$VALGRIND_LIB" "$OUT/raw"
```

The C runner preserves constant executable/database paths under
/tmp/buster-2610-current, uses an exclusive suite lock, and sets LC_ALL=C,
TZ=UTC, VALGRIND_LIB and SQLITE_TMPDIR. It runs native correctness first,
then Callgrind with --tool=callgrind --dump-instr=yes --error-exitcode=99.

SQLite native verification uses --shrink-memory --reprepare --stats
--journal wal --size 5 --heap 40000000 64 --testset mix1 --verify verify.db.
The counted command uses count.db without --verify. Lua uses arithmetic.lua
from the frozen script directory.

To rejoin a retained raw capture, restore the corresponding exact ELF,
generate objdump -d --no-show-raw-insn disassembly, decompress its raw
capture and sidecar, then run:

```sh
GAP_EXECUTABLE="$EXE" ./gap-2610-v2 count "$DISASM" "$CAPTURE" '???' 0x108000 "$KINDS" > "$JOIN"
./measure-2610-v2 summary-file "$JOIN" "$WORKLOAD" > "$SUMMARY" 2> "$AUDIT"
```

The explicit executable bounds prevent unrelated runtime instructions
with the same Callgrind object placeholder from entering program totals.
The fixed load bias was independently checked for these captures.

Compare per-function totals and the transport union with:

```sh
./measure-2610-v2 compare-functions "$BASE_JOIN" "$HEAD_JOIN"
./measure-2610-v2 compare-origins "$BASE_JOIN" "$HEAD_JOIN" SLCTURehxtum
```

The expected-invalid-origin fixture deliberately returns a failed audit;
it is not a failed workload capture. The valid m fixture passes. Complete
source is retained so helper behavior can be inspected without executing
the substantial workloads.

