# Call-window evidence packet

Read the adjacent public README for conclusions and limitations. This archive
contains eight measured workload records: two reused main-control records and
six new records from three candidates. Only SQLite speedtest1 and Lua
arithmetic are captured for these candidates.

- results/current-0: original control tags, joins and raw captures, plus
  regenerated v2 summaries.
- results/current-windows, current-windows-rows, current-windows-combined:
  completed new captures, tags, reports, trace records and function deltas.
- results/window-normalization and window-normalization-v2: code-identity
  checks for the two source stages, without new dynamic captures.
- results/main-c992-control: later main compilation parity appendix.
- results/*-export-refused: failed first-stage SQLite publication records;
  incomplete sidecars are not used in any summary.
- results/tokenizer: normalized code and path-count variation evidence.
- results/comparison-baselines and against-prior-candidates: derived
  comparisons to the earlier row/partition packet, not fresh captures.
- results/tag-fixtures: accepted m and rejected-invalid-origin helper tests.
- tools/: original and revised C helpers and exact patches.
- metadata/: immutable source identities and patches, executed command
  records, external artifact hashes, build logs and verification receipts.
- inputs/: exact input digests and small unity wrapper.
- oracles/ and licenses/: retained oracle outputs and provenance notices.

Verify all entries from this directory with:
`sha256sum -c SHA256SUMS`.

The valid candidate joins have zero unmatched instructions. Their visible
untagged startup/PLT records and outside-object exclusions are preserved.
Origin m is separately reported and included in the unique transport union.
A decreased C/R column alone is not evidence of decreased transport.

The actual yy_reduce emitted-code checker returns indirect/unsupported
(code_reason 5). Its allocation certificate passes. All three modes miss
the 660,000 C/R goal. No hardware run or acceptance is claimed.

