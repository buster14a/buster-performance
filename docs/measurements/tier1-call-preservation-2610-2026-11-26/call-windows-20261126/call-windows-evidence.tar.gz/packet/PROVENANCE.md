# Provenance

## Scope and roles

This packet was assembled on 2026-11-26 in session
6b086a82-e9b8-83eb-aad4-587684d3a052, OpenAI / GPT-6 Astra Pro.
The root task and source-analysis agents produced the source, built frozen
compilers, compiled workloads and ran native/Callgrind captures. The evidence
agent independently regenerated summaries and per-function comparisons,
checked origin accounting, raw compressed capture equality, native oracle
equality, normalization parity, and archive integrity. The later main
refresh was compiled by root and independently compared byte-for-byte
during packet construction.

This is experimental evidence for buster14a/buster issue 2610. No source
change or performance acceptance is implied by archival publication.
No Benchpress/9700X job was requested or executed. The host and exact
shared inputs/tools are recorded in INPUTS_AND_TOOLS.md.

## Immutable compiler source stages

| Purpose | Commit | Tree |
| --- | --- | --- |
| Core window implementation and fixture correction | f53fa950052be6bbf3840f553f8bbaf476011d5e | f0ebe84eb59fca9f0f641183f7c82ef4a6aa2cbe |
| Actual measured source, export whitelist correction | bb10db3b3aa023100f5501961be311295e1d11a6 | fc09354951cdd06f034e96b4865327a6beb72332 |
| Original uninstrumented main control | 8cfefb2dccc92c754092cd3ce9a0eafa62c6bdca | 4241118797538fffdade71a25345b7b2575137f7 |
| Later main control refresh | c9921c19dcb75d9af678530ee7045da4971d622c | 48c770e3367d2e0814358d020386b92f98753806 |

Core parent is ad9047dd851f25c323f715ca8b43b1d8ef3b2264. The parent-to-core
patch and core-to-measured patch are retained separately. The latter
changes only the tag-export whitelist and its explanation. No active
worktree changes after bb10 are part of this packet.

The exact measured tree fc09354951cdd06f034e96b4865327a6beb72332 was later
published to draft PR #3639 as 34dff18e25126d8ec939a73f2c3d58cce95da0b6,
parent b13983aca01ab5b48c1f3881a761f9e9a4cfb6a4. Root read the published
tree and DCO attribution back. This published commit mapping does not
replace the raw measured local source identity. Hosted results are not
claimed in this frozen packet.

The original instrumented control source was locally built at
87c533f3ee942788082508854cb7355b4b193fda, published as
98a3ce6b84e68bb91382ef9d30c152fd74f2e4cf, with identical tree
ac3a25d98b8e1dff7977047a0b72aa7096c2e0c0. Its mask-zero complete output
ELFs match both uninstrumented main controls and both normalization
stages. The reused baseline source does not change because later parity
was established.

## Binary and helper SHA256

| Artifact | SHA256 |
| --- | --- |
| compiler-call-windows, core source | 0543bca9f34fb41bb7ff724ebd1d49d5e8f835d8ac247bea33c6a1996a20ca45 |
| compiler-call-windows-v2, measured source | 2be5e3058e24e11ad7ea823dfeaa0160151972dcc298d7b466efa823acffbe59 |
| compiler-main-c9921c19, later control | f2a1bd3e2317294759ae39ac77a8d9572fd9aad49fb4d70098e4296dc8cb9c2a |
| measure-2610-v2 binary | 436e0b01c218d961727491e43f2acfe5c1cccad69f1715dcb0e8956f05cde3aa |
| gap-2610-v2 binary | 132fe336b958e9a7a601db7f9d099a53b946baf16f964af1b12041355cd8c8af |
| measure-2610-v2.c | 04a9fbc77f15821cf8251ecef9af058eabdbfc23c0d1d80a60edff5167057bce |
| gap-2610-v2.c | 63007549f11f8ab5b89d18e19e4181051ec8f817aad0fee3881ec39c5b7e37f5 |

Candidate ELF/sidecar hashes are in each results directory's
external-artifacts.sha256. Large binaries and disassemblies remain external
and are deliberately not in this compact archive.

## Related frozen evidence

Original current-main controls and six-workload capture:
performance commit 24e35c4a126dbe220b65984964ed00758ad1384e,
current-main-20261126 archive SHA256
04ac58c9f5f6cb3fe49e76bab09c4625123ff2a56e7ff4be71a7c26b59b3a204.

Prior rows/partition evidence:
rows-partition-20261126 archive SHA256
9f83d80ea4f79c3376e73a0b9ed7c195c2389cc848b7d44aaef173e1604d95e6.
The prior rows-all and combined records are reused only for derived
contextual comparisons; raw captures are not duplicated here.

Earlier batch-v2 evidence:
performance commit c6d7d1530579faa4e9ddb1a1ceb97bcf825bf46c,
batch-v2-20261126 archive SHA256
cc0b19bbf7d9ccaacd83b2f9a12cbe4c6c74daf102eb7ecbcb62ec9b94e8bb1a.

No test result from a later source is substituted for an earlier failure.
The prior ad9047 enabled-emitter four-failure record stays in its own packet;
the corrected f53 and bb10 eight passing logs are recorded here.

