# Third-party notices and adaptations

Buster source excerpts, patches, the unity wrapper, and measurement tooling
are distributed under Apache-2.0 WITH LLVM-exception; the complete Buster
license is included as licenses/Buster-LICENSE. Existing SPDX and source
attribution comments remain in the retained C tools.

The original measure-2610.c is the #2610 capture/accounting driver.
The gap helper retains the #1189/#2553 attribution and the #2610
executable-range correction. Origin-tagging provenance includes
buster-performance commit ddb5213da1fce7ac9325afbf6364a797bbc63b5b,
docs/measurements/tier1-dominator-places-2553-2026-11-12/scripts/kinds-2553.patch.
This session's version-2 modifications add explicit m accounting for real
interior allocation register copies; original C sources and exact diff
patches are retained beside the revised sources. The capture runner itself
is unchanged.

SQLite is in the public domain; its notice is retained at
licenses/SQLite-public-domain.txt. Lua 5.4.8 is under the MIT license,
retained in licenses/Lua-5.4.8.txt. Input URLs, exact versions and digests
appear in INPUTS_AND_TOOLS.md. Workload source trees are not redistributed
by this packet.

LLVM, Valgrind and the operating-system toolchain are external execution
dependencies, not redistributed binaries in this archive. Their source or
package identities are recorded to make the measurement environment
reconstructible. The archive contains generated measurement records,
compressed program outputs and bounded diagnostic extracts.

