# Batch-v2 evidence contents

This archive identifies the measured bit-2048 source and captures. Its
source and scope are in PROVENANCE.md; actual workload/test/capture settings
and the explicitly reconstructed compiler-build recipe are in COMMANDS.md.

- results/current-0: two reused control captures, tags, joins and logs.
- results/current-batch-v2: two new candidate captures, tags, joins, logs and allocator dump.
- results: paired and per-function/category comparisons, emitter logs and tokenizer comparison.
- metadata: exact source identities and delta, compiler hash, baseline parity and hosted status.
- tools: unchanged C measurement and join helpers.
- inputs: frozen input/resource-header manifests and the tiny unity wrapper.
- oracles and licenses: retained native oracle provenance and required notices.

All files except SHA256SUMS are covered by that manifest. The public README
beside the archive develops the findings: yy_reduce remains at 2,781,240 C/R,
and later review discovered generic dispatch-relay guard gaps. The optional
branch-cost follow-up and its harness are archived separately and are not
part of this measured compiler.

The four summaries are labeled by variant in results/paired-summary.tsv.
The candidate has SQLite and arithmetic native/dynamic evidence only.
