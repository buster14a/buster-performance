# Commands for the measured batch-v2 pair

The workload, emitter-test and capture settings below are recorded from the
root agent's executed invocations. Repeated paths and Lua source arguments
are parameterized without changing options. Compiler-build reconstruction
is explicitly distinguished from retained invocation evidence.

## Compiler identity and reconstructed build recipe

The actual local source was 62b736730c3f64acef9164e2a74cb43023d8c571, identical
in complete tree to published b13983aca01ab5b48c1f3881a761f9e9a4cfb6a4.
The compiler used for workload compilation was frozen at
/workspace/scratch/eeeceb19ae05/recovered/campaign/compiler-batch-v2.
Its SHA256 is 21dde3c95442db8c581b9ef77e09d222dcc5fb49062e5127a5b9bc810a3a7c00.

The original incremental compiler build invocation/log is not retained.
The following is a **reconstructed reproducible recipe** based on the pinned
source, toolchain and preceding configured build; it is not an executed-call
transcript for this particular compiler:

```sh
# From an isolated checkout of the stated source, with the restored sibling tools:
PATH="$PWD/../recovered/tooling/llvm-23.1.4/bin:$PWD/../toolchain/cmake-4.4.3-ninja-1.13.2/bin:$PATH" \
BUSTER_TOOLCHAIN=path BUSTER_HOST_ARCH=vector BUSTER_DEBUG_INFO=0 \
BUSTER_PARALLEL_CODEGEN=0 ./build.sh --config Release --jobs 2
```

Do not substitute a later build/compiler from the active diagnostic worktree:
the parent continued developing other experiments after freezing batch-v2.
The source patch and tracked tree inventory in metadata/ identify the
measured source independently of those later changes.

## Paths and unchanged helper programs

```sh
cd /workspace/scratch/eeeceb19ae05/recovered
rec="$PWD"
compiler="$rec/campaign/compiler-batch-v2"
out="$rec/campaign/current-batch-v2"
resource="$rec/tooling/llvm-23.1.4/lib/clang/23/include"
scripts="$rec/inputs/lua-scripts"
measure="$rec/campaign/measure-2610"
gap="$rec/campaign/gap-2610"
valgrind="$rec/tooling/valgrind/usr/bin/valgrind"
valgrind_lib="$rec/tooling/valgrind/usr/libexec/valgrind"
```

From an extracted packet, the unchanged helper sources build as follows:

```sh
gcc -O2 -Wall -Wextra tools/measure-2610.c -o measure-2610
gcc -O2 -Wall -Wextra tools/gap-2610.c -o gap-2610
```

Their actual binary hashes are in metadata/external-tools.sha256.

## Candidate workload compilation

SQLite uses the exact three-line wrapper in inputs/speedtest1-unity.c:

```sh
BUSTER_TIER1_EXPERIMENT=2048 BUSTER_TIER1_REGION_WORK=2147483648 \
BUSTER_TIER1_EXCHANGE_TRACE=26310 BUSTER_TIER1_KINDS="$out/speedtest1.kinds" \
BUSTER_TIER1_DUMP_BLOCKS=1900 BUSTER_TIER1_DUMP_FILE="$out/allocations.cfg" \
"$compiler" --tier1 --lanes 1 -isystem "$resource" \
  -fno-asynchronous-unwind-tables --tier1-report \
  -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 \
  -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE \
  "-I$rec/inputs/corpus/sqlite" "-I$rec/inputs" \
  -o "$out/speedtest1" "$rec/campaign/speedtest1-unity.c" -lm \
  > "$out/st-build.txt" 2>&1
```

Lua uses this fixed 33-source order and fixed seed:

```sh
set --
for unit in lapi lcode lctype ldebug ldo ldump lfunc lgc llex lmem lobject lopcodes lparser lstate lstring ltable ltm lundump lvm lzio lauxlib lbaselib lcorolib ldblib liolib lmathlib loadlib loslib lstrlib ltablib lutf8lib linit lua; do
  set -- "$@" "$rec/inputs/lua-5.4.8/src/$unit.c"
done

BUSTER_TIER1_EXPERIMENT=2048 BUSTER_TIER1_REGION_WORK=2147483648 \
BUSTER_TIER1_EXCHANGE_TRACE=26310 BUSTER_TIER1_KINDS="$out/lua.kinds" \
"$compiler" --tier1 --lanes 1 -isystem "$resource" \
  -fno-asynchronous-unwind-tables --tier1-report \
  -std=gnu99 -DLUA_COMPAT_5_3 -DLUA_USE_LINUX '-Dluai_makeseed(L)=0' \
  -o "$out/lua" "$@" -lm -ldl > "$out/lua-build.txt" 2>&1
```

No extra target-ISA flags or branch-cost, partition, row-home or region-order
environment variables were supplied. The SQLite-only dump variables were
not set for the Lua invocation. These settings describe the measured source,
which predates the new optional branch-cost helper.

The control was not recompiled or recaptured by this batch step. Its policy-0
source, exact commands, complete main-control ELF comparisons and six-workload
capture are retained in the sibling current-main-20261126 packet. The two
paired control captures are included here unchanged.

## Emitter validation

Executed from /workspace/scratch/eeeceb19ae05/buster-current-measurement
while its compiler was the frozen batch-v2 build:

```sh
./build/compiler test-tier1-emit \
  > ../recovered/campaign/batch-emitter-v2.txt 2>&1

BUSTER_TIER1_EXPERIMENT=2048 BUSTER_TIER1_REGION_WORK=2147483648 \
BUSTER_TIER1_EXCHANGE_TRACE=25 ./build/compiler test-tier1-emit \
  > ../recovered/campaign/batch-activation-v2.txt 2>&1
```

Each retained log reports 259254 checks and zero failures. The second also
retains BATCH_REGION activation traces.

## Paired measurement and native checks

Executed from the recovered workspace:

```sh
"$measure" run-pair "$out" "$scripts" "$valgrind" "$valgrind_lib" "$out/raw"
```

The unchanged driver sets LC_ALL=C, TZ=UTC, VALGRIND_LIB and SQLITE_TMPDIR,
copies the variant to fixed /tmp/buster-2610-current program paths, and holds
an exclusive lock for the complete suite. It fixes workload cwd, database
names, temp layout and arguments. SQLite native verification runs in
/tmp/buster-2610-current/sqlite-data with:

```text
/tmp/buster-2610-current/speedtest1 --shrink-memory --reprepare --stats --journal wal --size 5 --heap 40000000 64 --testset mix1 --verify verify.db
```

The counted command uses count.db and omits --verify. Lua invokes the fixed
/tmp/buster-2610-current/lua with arithmetic.lua from the frozen scripts cwd.
Callgrind receives --tool=callgrind --dump-instr=yes --error-exitcode=99 and
the workload's --callgrind-out-file. Exact argv is also retained in compressed
Callgrind stderr.

The candidate pair and the reused control pair were independently checked
against the frozen SQLite verification hash and arithmetic Clang stdout;
the arithmetic native stderr files are empty. No additional candidate Lua
native execution is claimed in this packet.

## Joins, summaries and per-function comparison

For each program:

```sh
objdump -d --no-show-raw-insn "$out/$program" > "$out/$program.dis"
```

For speedtest1 set program=speedtest1; for arithmetic set program=lua:

```sh
GAP_EXECUTABLE="$out/$program" "$gap" count \
  "$out/$program.dis" "$out/$workload.cg" '???' 0x108000 \
  "$out/$program.kinds" > "$out/$workload.tsv"
"$measure" summary-file "$out/$workload.tsv" "$workload" \
  > "$out/$workload.summary.tsv" 2> "$out/$workload.audit.txt"
```

The packet preserves full compressed joins and summaries regenerated with
the unchanged helper. For each paired workload, postprocessing compares:

```sh
control="$rec/campaign/current-0"
candidate="$rec/campaign/current-batch-v2"
"$measure" compare-functions "$control/$workload.tsv" "$candidate/$workload.tsv"
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" SLCTURehxtu
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" SLTtUu
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" CR
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" ehxTtUu
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" a
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" r
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" f
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" n
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" j
```

These origin selections mean transport union, spills/reloads, call
preservation, edges, argument copies, rematerialization, frames, nodes and
control. Public sign summaries and positive-category rows are direct
postprocessing of the retained comparison tables.

## Tokenizer code comparison

The small results/tokenizer/*.asm excerpts come from the exact full-program
disassemblies identified in each variant's external-artifacts.sha256. The
excerpts retain instruction text and symbolic target names after stripping
absolute instruction and numeric target addresses, including trailing padding
before the next symbol. The remaining RIP displacements are normalized with:

```sh
sed -E 's/-?0x[0-9a-f]+\(%rip\)/RIP_DISPLACEMENT(%rip)/g' \
  results/tokenizer/current-0.asm > results/tokenizer/current-0.normalized.asm
sed -E 's/-?0x[0-9a-f]+\(%rip\)/RIP_DISPLACEMENT(%rip)/g' \
  results/tokenizer/current-batch-v2.asm > results/tokenizer/current-batch-v2.normalized.asm
cmp results/tokenizer/current-0.normalized.asm results/tokenizer/current-batch-v2.normalized.asm
```

The normalized listings match. The separate dynamic -14 is retained as
observed path-count variation, with no claim about its specific cause.

## Archive verification

The packet manifest covers all files except the manifest itself. Archive
creation sorts names, fixes mtime to 2026-11-26 00:00:00 UTC and uid/gid to
zero, and uses gzip -n. A fresh extraction was checked against SHA256SUMS;
all retained gzip streams were tested. The separate branch-cost support
archive has its own manifest and scope and is not an input to these captures.
