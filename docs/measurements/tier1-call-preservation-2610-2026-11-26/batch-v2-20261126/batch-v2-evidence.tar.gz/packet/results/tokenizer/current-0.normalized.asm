lea    RIP_DISPLACEMENT(%rip),%rax        # <sqlite3_config.mAnytimeConfigOption+0x2314>
lea    RIP_DISPLACEMENT(%rip),%rcx        # <aiClass>
movzbl (%rdi),%edx
movzbl (%rcx,%rdx,1),%edx
cmp    $0x1e,%edx
ja     <sqlite3GetToken+0x68e>
lea    RIP_DISPLACEMENT(%rip),%r8        # <sqlite3CtypeMap>
movslq (%rax,%rdx,4),%rdx
add    %rdx,%rax
jmp    *%rax
mov    $0x1,%eax
jmp    <sqlite3GetToken+0x39>
add    $0x1,%rax
movzbl (%rdi,%rax,1),%ecx
movzbl (%r8,%rcx,1),%ecx
and    $0x1,%ecx
test   %ecx,%ecx
jne    <sqlite3GetToken+0x35>
movl   $0xb8,(%rsi)
ret
cmpb   $0x2d,0x1(%rdi)
jne    <sqlite3GetToken+0x75>
mov    $0x2,%eax
jmp    <sqlite3GetToken+0x66>
cmp    $0xa,%ecx
je     <sqlite3GetToken+0x6e>
add    $0x1,%rax
movzbl (%rdi,%rax,1),%ecx
test   %ecx,%ecx
jne    <sqlite3GetToken+0x5d>
movl   $0xb9,(%rsi)
ret
cmpb   $0x3e,0x1(%rdi)
jne    <sqlite3GetToken+0x8e>
movl   $0x71,(%rsi)
xor    %eax,%eax
cmpb   $0x3e,0x2(%rdi)
sete   %al
add    $0x2,%eax
ret
movl   $0x6c,(%rsi)
mov    $0x1,%eax
ret
movl   $0x16,(%rsi)
mov    $0x1,%eax
ret
movl   $0x17,(%rsi)
mov    $0x1,%eax
ret
movl   $0x1,(%rsi)
mov    $0x1,%eax
ret
movl   $0x6b,(%rsi)
mov    $0x1,%eax
ret
movl   $0x6d,(%rsi)
mov    $0x1,%eax
ret
cmpb   $0x2a,0x1(%rdi)
jne    <sqlite3GetToken+0xe2>
cmpb   $0x0,0x2(%rdi)
jne    <sqlite3GetToken+0xee>
movl   $0x6e,(%rsi)
mov    $0x1,%eax
ret
mov    $0x3,%eax
movzbl 0x2(%rdi),%ecx
jmp    <sqlite3GetToken+0x10b>
cmpb   $0x2f,(%rdi,%rax,1)
je     <sqlite3GetToken+0x112>
movzbl (%rdi,%rax,1),%ecx
test   %ecx,%ecx
je     <sqlite3GetToken+0x112>
add    $0x1,%rax
cmp    $0x2a,%ecx
jne    <sqlite3GetToken+0xff>
jmp    <sqlite3GetToken+0xf9>
test   %ecx,%ecx
je     <sqlite3GetToken+0x11a>
add    $0x1,%rax
movl   $0xb9,(%rsi)
ret
movl   $0x6f,(%rsi)
mov    $0x1,%eax
ret
movl   $0x36,(%rsi)
xor    %eax,%eax
cmpb   $0x3d,0x1(%rdi)
sete   %al
add    $0x1,%eax
ret
movzbl 0x1(%rdi),%eax
cmp    $0x3d,%eax
jne    <sqlite3GetToken+0x155>
movl   $0x38,(%rsi)
mov    $0x2,%eax
ret
cmp    $0x3e,%eax
jne    <sqlite3GetToken+0x166>
movl   $0x35,(%rsi)
mov    $0x2,%eax
ret
cmp    $0x3c,%eax
jne    <sqlite3GetToken+0x177>
movl   $0x69,(%rsi)
mov    $0x2,%eax
ret
movl   $0x39,(%rsi)
mov    $0x1,%eax
ret
movzbl 0x1(%rdi),%eax
cmp    $0x3d,%eax
jne    <sqlite3GetToken+0x198>
movl   $0x3a,(%rsi)
mov    $0x2,%eax
ret
cmp    $0x3e,%eax
jne    <sqlite3GetToken+0x1a9>
movl   $0x6a,(%rsi)
mov    $0x2,%eax
ret
movl   $0x37,(%rsi)
mov    $0x1,%eax
ret
cmpb   $0x3d,0x1(%rdi)
je     <sqlite3GetToken+0x1c7>
movl   $0xba,(%rsi)
mov    $0x1,%eax
ret
movl   $0x35,(%rsi)
mov    $0x2,%eax
ret
cmpb   $0x7c,0x1(%rdi)
je     <sqlite3GetToken+0x1e5>
movl   $0x68,(%rsi)
mov    $0x1,%eax
ret
movl   $0x70,(%rsi)
mov    $0x2,%eax
ret
movl   $0x19,(%rsi)
mov    $0x1,%eax
ret
movl   $0x67,(%rsi)
mov    $0x1,%eax
ret
movl   $0x73,(%rsi)
mov    $0x1,%eax
ret
movzbl (%rdi),%eax
mov    $0x1,%ecx
jmp    <sqlite3GetToken+0x236>
cmp    %eax,%edx
jne    <sqlite3GetToken+0x232>
movzbl 0x1(%rdi,%rcx,1),%r8d
cmp    %eax,%r8d
jne    <sqlite3GetToken+0x23e>
add    $0x1,%rcx
add    $0x1,%rcx
movzbl (%rdi,%rcx,1),%edx
test   %edx,%edx
jne    <sqlite3GetToken+0x21f>
cmp    $0x27,%edx
jne    <sqlite3GetToken+0x24e>
movl   $0x76,(%rsi)
lea    0x1(%rcx),%rax
ret
test   %edx,%edx
je     <sqlite3GetToken+0x25d>
movl   $0x3c,(%rsi)
lea    0x1(%rcx),%rax
ret
movl   $0xba,(%rsi)
mov    %rcx,%rax
ret
movzbl 0x1(%rdi),%eax
movzbl (%r8,%rax,1),%eax
and    $0x4,%eax
test   %eax,%eax
jne    <sqlite3GetToken+0x283>
movl   $0x8e,(%rsi)
mov    $0x1,%eax
ret
movl   $0x9c,(%rsi)
cmpb   $0x30,(%rdi)
jne    <sqlite3GetToken+0x2d8>
cmpb   $0x78,0x1(%rdi)
je     <sqlite3GetToken+0x29a>
cmpb   $0x58,0x1(%rdi)
jne    <sqlite3GetToken+0x2d8>
movzbl 0x2(%rdi),%eax
movzbl (%r8,%rax,1),%eax
and    $0x8,%eax
test   %eax,%eax
je     <sqlite3GetToken+0x2d8>
mov    $0x3,%eax
jmp    <sqlite3GetToken+0x2c1>
cmpb   $0x5f,(%rdi,%rax,1)
jne    <sqlite3GetToken+0x2d3>
movl   $0xb7,(%rsi)
add    $0x1,%rax
movzbl (%rdi,%rax,1),%ecx
movzbl (%r8,%rcx,1),%ecx
and    $0x8,%ecx
test   %ecx,%ecx
je     <sqlite3GetToken+0x2b1>
jmp    <sqlite3GetToken+0x2bd>
jmp    <sqlite3GetToken+0x3b8>
xor    %eax,%eax
jmp    <sqlite3GetToken+0x2ec>
cmpb   $0x5f,(%rdi,%rax,1)
jne    <sqlite3GetToken+0x2fe>
movl   $0xb7,(%rsi)
add    $0x1,%rax
movzbl (%rdi,%rax,1),%ecx
movzbl (%r8,%rcx,1),%ecx
and    $0x4,%ecx
test   %ecx,%ecx
je     <sqlite3GetToken+0x2dc>
jmp    <sqlite3GetToken+0x2e8>
cmpb   $0x2e,(%rdi,%rax,1)
jne    <sqlite3GetToken+0x33a>
cmpl   $0x9c,(%rsi)
jne    <sqlite3GetToken+0x312>
movl   $0x9a,(%rsi)
add    $0x1,%rax
jmp    <sqlite3GetToken+0x328>
cmpb   $0x5f,(%rdi,%rax,1)
jne    <sqlite3GetToken+0x33a>
movl   $0xb7,(%rsi)
add    $0x1,%rax
movzbl (%rdi,%rax,1),%ecx
movzbl (%r8,%rcx,1),%ecx
and    $0x4,%ecx
test   %ecx,%ecx
je     <sqlite3GetToken+0x318>
jmp    <sqlite3GetToken+0x324>
cmpb   $0x65,(%rdi,%rax,1)
je     <sqlite3GetToken+0x346>
cmpb   $0x45,(%rdi,%rax,1)
jne    <sqlite3GetToken+0x3b8>
movzbl 0x1(%rdi,%rax,1),%ecx
movzbl (%r8,%rcx,1),%ecx
and    $0x4,%ecx
test   %ecx,%ecx
jne    <sqlite3GetToken+0x376>
cmpb   $0x2b,0x1(%rdi,%rax,1)
je     <sqlite3GetToken+0x365>
cmpb   $0x2d,0x1(%rdi,%rax,1)
jne    <sqlite3GetToken+0x3b8>
movzbl 0x2(%rdi,%rax,1),%ecx
movzbl (%r8,%rcx,1),%ecx
and    $0x4,%ecx
test   %ecx,%ecx
je     <sqlite3GetToken+0x3b8>
cmpl   $0x9c,(%rsi)
jne    <sqlite3GetToken+0x384>
movl   $0x9a,(%rsi)
add    $0x2,%rax
jmp    <sqlite3GetToken+0x39a>
cmpb   $0x5f,(%rdi,%rax,1)
jne    <sqlite3GetToken+0x3ac>
movl   $0xb7,(%rsi)
add    $0x1,%rax
movzbl (%rdi,%rax,1),%ecx
movzbl (%r8,%rcx,1),%ecx
and    $0x4,%ecx
test   %ecx,%ecx
je     <sqlite3GetToken+0x38a>
jmp    <sqlite3GetToken+0x396>
jmp    <sqlite3GetToken+0x3b8>
movl   $0xba,(%rsi)
add    $0x1,%rax
movzbl (%rdi,%rax,1),%ecx
movzbl (%r8,%rcx,1),%ecx
and    $0x46,%ecx
test   %ecx,%ecx
jne    <sqlite3GetToken+0x3ae>
ret
mov    $0x1,%eax
movzbl (%rdi),%ecx
jmp    <sqlite3GetToken+0x3df>
movzbl (%rdi,%rax,1),%ecx
test   %ecx,%ecx
je     <sqlite3GetToken+0x3e4>
add    $0x1,%rax
cmp    $0x5d,%ecx
jne    <sqlite3GetToken+0x3d3>
cmp    $0x5d,%ecx
jne    <sqlite3GetToken+0x3f0>
mov    $0x3c,%ecx
jmp    <sqlite3GetToken+0x3f5>
mov    $0xba,%ecx
mov    %ecx,(%rsi)
ret
movl   $0x9d,(%rsi)
mov    $0x1,%eax
jmp    <sqlite3GetToken+0x409>
add    $0x1,%rax
movzbl (%rdi,%rax,1),%ecx
movzbl (%r8,%rcx,1),%ecx
and    $0x4,%ecx
test   %ecx,%ecx
jne    <sqlite3GetToken+0x405>
ret
xor    %eax,%eax
movl   $0x9d,(%rsi)
mov    $0x1,%ecx
jmp    <sqlite3GetToken+0x43d>
movzbl (%r8,%rdx,1),%edx
and    $0x46,%edx
test   %edx,%edx
je     <sqlite3GetToken+0x44b>
add    $0x1,%rax
add    $0x1,%rcx
movzbl (%rdi,%rcx,1),%edx
mov    %edx,%r9d
test   %r9d,%r9d
jne    <sqlite3GetToken+0x429>
jmp    <sqlite3GetToken+0x48a>
cmp    $0x28,%r9d
jne    <sqlite3GetToken+0x499>
test   %rax,%rax
jle    <sqlite3GetToken+0x499>
add    $0x1,%rcx
movzbl (%rdi,%rcx,1),%edx
mov    %edx,%r9d
test   %r9d,%r9d
je     <sqlite3GetToken+0x478>
movzbl (%r8,%rdx,1),%edx
and    $0x1,%edx
test   %edx,%edx
jne    <sqlite3GetToken+0x478>
cmp    $0x29,%r9d
jne    <sqlite3GetToken+0x456>
cmp    $0x29,%r9d
jne    <sqlite3GetToken+0x484>
add    $0x1,%rcx
jmp    <sqlite3GetToken+0x48a>
movl   $0xba,(%rsi)
test   %rax,%rax
jne    <sqlite3GetToken+0x495>
movl   $0xba,(%rsi)
mov    %rcx,%rax
ret
cmp    $0x3a,%r9d
jne    <sqlite3GetToken+0x4ac>
cmpb   $0x3a,0x1(%rdi,%rcx,1)
jne    <sqlite3GetToken+0x4ac>
add    $0x1,%rcx
jmp    <sqlite3GetToken+0x439>
jmp    <sqlite3GetToken+0x48a>
movzbl 0x1(%rdi),%eax
cmpb   $0x2,(%rcx,%rax,1)
jbe    <sqlite3GetToken+0x4c2>
mov    $0x1,%eax
jmp    <sqlite3GetToken+0x69e>
mov    $0x2,%r9d
jmp    <sqlite3GetToken+0x4ce>
add    $0x1,%r9
movzbl (%rdi,%r9,1),%eax
cmpb   $0x2,(%rcx,%rax,1)
jbe    <sqlite3GetToken+0x4ca>
movzbl (%rdi,%r9,1),%eax
movzbl (%r8,%rax,1),%eax
and    $0x46,%eax
test   %eax,%eax
je     <sqlite3GetToken+0x4f3>
lea    0x1(%r9),%rax
jmp    <sqlite3GetToken+0x69e>
movl   $0x3c,(%rsi)
lea    RIP_DISPLACEMENT(%rip),%rax        # <sqlite3UpperToLower>
movzbl (%rdi),%ecx
movzbl (%rax,%rcx,1),%ecx
shl    $0x2,%ecx
movzbl -0x1(%rdi,%r9,1),%edx
movzbl (%rax,%rdx,1),%eax
lea    (%rax,%rax,2),%eax
xor    %eax,%ecx
xor    %r9,%rcx
movabs $0x4081020408102041,%rax
imul   %rcx
sar    $0x5,%rdx
mov    %rdx,%rax
shr    $0x3f,%rax
add    %rax,%rdx
imul   $0x7f,%rdx,%rdx
neg    %rdx
add    %rcx,%rdx
mov    %rdx,%rax
lea    RIP_DISPLACEMENT(%rip),%rcx        # <aKWHash>
movzbl (%rcx,%rax,1),%eax
jmp    <sqlite3GetToken+0x58e>
movsbl (%rdi,%rcx,1),%r8d
and    $0xffffffdf,%r8d
movsbl (%rdx,%rcx,1),%r10d
cmp    %r10d,%r8d
jne    <sqlite3GetToken+0x56d>
add    $0x1,%rcx
cmp    %r9,%rcx
jl     <sqlite3GetToken+0x551>
cmp    %r9,%rcx
jl     <sqlite3GetToken+0x583>
lea    RIP_DISPLACEMENT(%rip),%rcx        # <aKWCode>
movzbl (%rcx,%rax,1),%eax
mov    %eax,(%rsi)
mov    %r9,%rax
ret
lea    RIP_DISPLACEMENT(%rip),%rcx        # <aKWNext>
movzbl (%rcx,%rax,1),%eax
test   %rax,%rax
jle    <sqlite3GetToken+0x57f>
lea    RIP_DISPLACEMENT(%rip),%rcx        # <aKWLen>
movzbl (%rcx,%rax,1),%ecx
cmp    %r9,%rcx
jne    <sqlite3GetToken+0x583>
lea    RIP_DISPLACEMENT(%rip),%rcx        # <zKWText>
lea    RIP_DISPLACEMENT(%rip),%rdx        # <aKWOffset>
movzwl (%rdx,%rax,2),%edx
lea    (%rcx,%rdx,1),%r8
movsbl (%rdi),%r10d
and    $0xffffffdf,%r10d
movsbl (%rcx,%rdx,1),%ecx
cmp    %ecx,%r10d
jne    <sqlite3GetToken+0x583>
movsbl 0x1(%rdi),%ecx
and    $0xffffffdf,%ecx
lea    RIP_DISPLACEMENT(%rip),%r10        # <zKWText>
movsbl 0x1(%r10,%rdx,1),%edx
cmp    %edx,%ecx
jne    <sqlite3GetToken+0x583>
mov    $0x2,%ecx
mov    %r8,%rdx
jmp    <sqlite3GetToken+0x568>
cmpb   $0x27,0x1(%rdi)
jne    <sqlite3GetToken+0x65f>
movl   $0x9b,(%rsi)
mov    $0x2,%eax
jmp    <sqlite3GetToken+0x606>
add    $0x1,%rax
movzbl (%rdi,%rax,1),%ecx
movzbl (%r8,%rcx,1),%ecx
and    $0x8,%ecx
test   %ecx,%ecx
jne    <sqlite3GetToken+0x602>
cmpb   $0x27,(%rdi,%rax,1)
jne    <sqlite3GetToken+0x63c>
mov    %rax,%rcx
sar    $0x3f,%rcx
and    $0x1,%rcx
add    %rax,%rcx
and    $0xfffffffffffffffe,%rcx
mov    %rcx,%r11
mov    %rax,%rcx
sub    %r11,%rcx
test   %rcx,%rcx
je     <sqlite3GetToken+0x654>
movl   $0xba,(%rsi)
jmp    <sqlite3GetToken+0x64e>
cmpb   $0x27,(%rdi,%rax,1)
je     <sqlite3GetToken+0x654>
add    $0x1,%rax
cmpb   $0x0,(%rdi,%rax,1)
jne    <sqlite3GetToken+0x644>
cmpb   $0x0,(%rdi,%rax,1)
je     <sqlite3GetToken+0x65e>
add    $0x1,%rax
ret
mov    $0x1,%eax
jmp    <sqlite3GetToken+0x69e>
cmpb   $0xbb,0x1(%rdi)
jne    <sqlite3GetToken+0x67e>
cmpb   $0xbf,0x2(%rdi)
jne    <sqlite3GetToken+0x67e>
movl   $0xb8,(%rsi)
mov    $0x3,%eax
ret
mov    $0x1,%eax
jmp    <sqlite3GetToken+0x69e>
movl   $0xba,(%rsi)
xor    %eax,%eax
ret
movl   $0xba,(%rsi)
mov    $0x1,%eax
ret
add    $0x1,%rax
movzbl (%rdi,%rax,1),%ecx
movzbl (%r8,%rcx,1),%ecx
and    $0x46,%ecx
test   %ecx,%ecx
jne    <sqlite3GetToken+0x69a>
movl   $0x3c,(%rsi)
ret
int3
int3
int3
int3
int3
int3
int3
int3
int3
int3
int3
