# Batch-v2 source, tool and input identities

This is a new candidate measurement against two reused current-main control
captures. It is separate from both the old-source recovery and the current-main
bit-1024 diagnostic run.

## Measured candidate

- Repository: buster14a/buster, repository ID 1421805693.
- Issue: https://github.com/buster14a/buster/issues/2610.
- Measurement PR: https://github.com/buster14a/buster/pull/3639.
- Actual local build source: 62b736730c3f64acef9164e2a74cb43023d8c571.
- Published source: b13983aca01ab5b48c1f3881a761f9e9a4cfb6a4.
- Published parent: 98a3ce6b84e68bb91382ef9d30c152fd74f2e4cf.
- Shared complete source tree: 295abde70e4c296759c4317a1d725f7bb1c11327.
- Frozen compiler: campaign/compiler-batch-v2.
- Compiler SHA256:
  21dde3c95442db8c581b9ef77e09d222dcc5fb49062e5127a5b9bc810a3a7c00.
- Candidate SQLite SHA256:
  5c95905262c3507d6f83e2053ce1ba4bd67f275353a3577c1bfa310474af8fac.
- Candidate Lua SHA256:
  503f5593ad8ec55a48a278b29a918e03ee3757e96a752545de75908492cfcce7.
- Policy mask: 2048; diagnostic region work: 2147483648; trace selector: 26310.
- SQLite allocator dump selector: 1900; output: allocations.cfg.
- No optional branch-cost, partition or row-home mode.

The local and published source trees were checked with git and the GitHub API.
metadata/source-tree.txt retains the tracked tree inventory and
metadata/measured-source.patch retains the delta from the preceding local
measurement source. metadata/source-and-controls.json preserves published
and hosted merge identities. The original incremental compiler build command
and log are not retained; COMMANDS.md provides a labeled reconstructed recipe.
The compiler executable and generated ELF files remain external.

## Reused control

- Uninstrumented main pin: 8cfefb2dccc92c754092cd3ce9a0eafa62c6bdca.
- Main tree: 4241118797538fffdade71a25345b7b2575137f7.
- Main compiler SHA256:
  d59afd2e48114fa6cc9bc043cfe1d5c3c3cc134e33ef9dd95febbbdbca8f57a9.
- Actual local policy-0 source: 87c533f3ee942788082508854cb7355b4b193fda.
- Published equivalent source: 98a3ce6b84e68bb91382ef9d30c152fd74f2e4cf.
- Shared control measurement tree: ac3a25d98b8e1dff7977047a0b72aa7096c2e0c0.
- Policy-0 measurement compiler SHA256:
  f80016e95babaca424441d4650a0b149b90433bb4ba7e5e06688d213ed3f716f.
- Control SQLite SHA256:
  dba5e7c4382df7f8cea6d72e9aed6619535ea2af193d99695117127de3b5f7f3.
- Control Lua SHA256:
  610c60a34458d25ec177d097b7603d83d95d699fb18a7527e2bc6155e2096765.

The complete policy-0 ELFs match the independent uninstrumented main outputs.
That parity was established during the preceding current-main capture, and its
receipt is copied here. Both control raw captures, tags and joins are reused
unchanged; they were not recaptured by the batch-v2 compiler.

Published control evidence:
https://github.com/buster14a/buster-performance/commit/24e35c4a126dbe220b65984964ed00758ad1384e,
sibling current-main-20261126/current-main-evidence.tar.gz, SHA256
04ac58c9f5f6cb3fe49e76bab09c4625123ff2a56e7ff4be71a7c26b59b3a204.

## Hosted validation

- Successful test workflow:
  https://github.com/buster14a/buster/actions/runs/45874827976.
- Run head: b13983aca01ab5b48c1f3881a761f9e9a4cfb6a4.
- Hosted merge: 81980ca257326cd6bce083e4a37253435c683bf2.
- Hosted merge parents:
  8cfefb2dccc92c754092cd3ce9a0eafa62c6bdca,
  b13983aca01ab5b48c1f3881a761f9e9a4cfb6a4.
- Hosted merge tree: 295abde70e4c296759c4317a1d725f7bb1c11327.
- Run created 2026-11-26T18:18:12Z; updated 2026-11-26T18:29:06Z.
- 39 jobs: 22 success, 17 skipped.
- All twelve selected vector candidates, analyzer, integration qualification,
  coverage and measurement storage succeeded.
- Hardware job 140103874942, Native tests and benchmarks on Benchpress
  (Ryzen 7 9700X), was skipped, runner_name=null, runner_group_name=null.
  Its started/completed timestamp is 2026-11-26T18:28:41Z.

metadata/hosted-status.json is an independently fetched compact API snapshot
of the entire job list. No hardware job was requested or performed in this
work. No claim is made about separate workflows from this status snapshot.

## Frozen inputs

- Hosted input artifact 15130172676, run 45844778824.
- Input ZIP size: 64,082,047 bytes.
- Input ZIP SHA256:
  5bbb1ed386a4ed5fdcf294af31c06f965805b455d7fdd2ef65797186d28ce6d0.
- SQLite corpus:
  https://github.com/buster14a/buster-performance/releases/download/ci-corpora-preprocessor-391e729af658/preprocessor-391e729af658-ci.tar.zst.
- Corpus SHA256:
  ceb39bf938cd7a7469bbb53646c3318d0cbfdac4d37b6d05b183c4fd0b9898c2.
- SQLite 3.53.2 sqlite3.c SHA256:
  0a409f1633283fa31a9126b11fbfd64a1991c5d30defad07e5745d4667f5e23d.
- sqlite3.h SHA256:
  9e69a1353a4288450b0d5239ede11fc7f1f4c8e5eb07491fc8317eacb5b7de7e.
- speedtest1.c source:
  https://raw.githubusercontent.com/sqlite/sqlite/ccc132c5be20ab5c755c97a08d06b1b592fef330/test/speedtest1.c.
- speedtest1.c SHA256:
  b5eaf4bbcbb320fd8eb3f3e6c4cd5f51a64dd0cd70efe969634d1785e3419675.
- Lua 5.4.8 source: https://www.lua.org/ftp/lua-5.4.8.tar.gz.
- Lua archive SHA256:
  4f18ddae154e793e46eeab727c59ef1c0c0c2b744e7b94219710d76f530629ae.
- Lua script source: buster-performance commit
  818cfbbc0be238da287c16d8e2a91fd7275cf228, path
  docs/measurements/tier1-reciprocal-141-2026-11-01/9700x/lua.
  The path is historical input provenance, not this campaign's execution host.
- Individual input digests: inputs/workload-inputs.sha256 (71 entries),
  relative to the recovered inputs root.
- LLVM resource-header inventory: inputs/resource-headers.sha256 (327 entries),
  relative to tooling/llvm-23.1.4/lib/clang/23/include.
- Native oracle files are unchanged from the recovered campaign.

## Toolchain, measurement helpers and host

- Clang 23.1.4, LLVM commit 7a941dfb2877a0b8cf30323fefa85ad019e0b0f5.
- LLVM archive SHA256:
  efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378.
- Configured build tools: CMake 4.4.3 and Ninja 1.13.2.
- Valgrind 3.24.0-3 Debian package:
  https://deb.debian.org/debian/pool/main/v/valgrind/valgrind_3.24.0-3_amd64.deb.
- Valgrind package SHA256:
  0359e30820ccee7ee5c8d4c951ca276e3978b18f157d71bd77981de05b344907.
  This is the same package hash as the original campaign.
- Host: AMD EPYC 9V74, Linux 6.18.57, glibc 2.41.
- C helper compiler: GCC 14.2.0-19; disassembler: GNU objdump 2.44.
- Unchanged measure-2610.c SHA256:
  61af44ef005df0d31bc4ad68ad0d00ab68965f9f68c7e51548433717304d4ab9.
- Unchanged gap-2610.c SHA256:
  73763316ae4d87024397fb207b6a8d3ce69d93c1c3bab65c80eb217e0721e76b.

Actual helper binary and restored tool archive digests are retained in
metadata/external-tools.sha256. Original instruction-origin tagging was
adapted from buster-performance ddb5213da1fce7ac9325afbf6364a797bbc63b5b,
docs/measurements/tier1-dominator-places-2553-2026-11-12/scripts/kinds-2553.patch.
The gap helper retains the original #1189/#2553 attribution and the #2610
executable-range correction. Neither helper implementation changes here.

## Limits and later support

The first bit-2048 invocation was disabled by the old 2047 mask and is not
treated as candidate evidence. This packet uses the corrected batch-v2 source.
It contains two new candidate captures and two reused control captures.
Batch-v2 native checks cover the SQLite hash and Lua arithmetic only.

A later independent emitter review found the dispatch-relay and
PREDECESSOR-prefix guard limitations described in README.md. The separate
branch-cost-support.tar.gz preserves a focused follow-up proposal and harness,
including conservative refusals and independent total-edge gains. Its source
is not the compiler that produced these measurements, and its standalone
checks do not retroactively qualify the measured generic guard.

The primary target remains unmet. There is no accepted production allocation
change, production budget increase, full six-workload dynamic candidate
qualification, full-corpus emitted-code certificate or hardware qualification.

Agent session: 6b086a82-e9b8-83eb-aad4-587684d3a052 (OpenAI session ID; no share URL is exposed)
Model: OpenAI / GPT-6 Astra Pro
