#include "sqlite3.c"
#define randomFunc speedtest1_randomFunc
#include "speedtest1.c"
