// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Original #2610 measurement driver. Run prepared SQLite/Lua binaries under Callgrind, then join the instruction
// counts with #2553's origin tags through gap.c. This measures generated programs, never compiler elapsed time.
#define _GNU_SOURCE
#include <errno.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

#define BUSTER_MEASURE_PATH 4096
#define BUSTER_MEASURE_FUNCTIONS 16384
#define BUSTER_MEASURE_CASES 6
#define BUSTER_MEASURE_CURRENT "/tmp/buster-2610-current"

static const char* const workloads[BUSTER_MEASURE_CASES] = { "speedtest1", "arithmetic", "calls", "closures", "strings", "tables" };
static const char origin_letters[] = "SLTUCReapfrjnhxtu";

typedef struct FunctionCount FunctionCount;
struct FunctionCount
{
    char* name;
    uint64_t count;
    int fitted;
    bool checked;
};

typedef struct Summary Summary;
struct Summary
{
    uint64_t total;
    uint64_t unmatched;
    uint64_t outside;
    uint64_t origins[256];
    uint64_t reduce_total;
    uint64_t reduce_origins[256];
    uint64_t hot_total;
    uint64_t hot_origins[256];
    FunctionCount functions[BUSTER_MEASURE_FUNCTIONS];
    uint32_t function_count;
    bool saw_total;
    bool saw_unmatched;
};

static bool path_join(char* out, const char* dir, const char* name)
{
    const int size = snprintf(out, BUSTER_MEASURE_PATH, "%s/%s", dir, name);
    return size > 0 && size < BUSTER_MEASURE_PATH;
}

static bool make_directory(const char* path)
{
    return mkdir(path, 0777) == 0 || errno == EEXIST;
}

static bool copy_program(const char* out, const char* name)
{
    char source[BUSTER_MEASURE_PATH];
    char target[BUSTER_MEASURE_PATH];
    bool ok = path_join(source, out, name) && path_join(target, BUSTER_MEASURE_CURRENT, name);
    const int input = ok ? open(source, O_RDONLY) : -1;
    const int output = input >= 0 ? open(target, O_WRONLY | O_CREAT | O_TRUNC, 0755) : -1;
    ok = ok && input >= 0 && output >= 0;
    char bytes[65536];
    ssize_t count = 0;
    while (ok && (count = read(input, bytes, sizeof(bytes))) != 0)
    {
        if (count < 0)
        {
            ok = errno == EINTR;
        }
        else
        {
            ssize_t copied = 0;
            while (ok && copied < count)
            {
                const ssize_t written = write(output, bytes + copied, (size_t)(count - copied));
                ok = written > 0 || (written < 0 && errno == EINTR);
                copied += written > 0 ? written : 0;
            }
        }
    }
    if (input >= 0)
    {
        close(input);
    }
    if (output >= 0)
    {
        ok = close(output) == 0 && ok;
    }
    return ok;
}

static bool run_command(char* const* args, const char* directory, const char* output, const char* errors)
{
    const pid_t child = fork();
    bool ok = child >= 0;
    if (child == 0)
    {
        const int out = open(output, O_WRONLY | O_CREAT | O_TRUNC, 0666);
        const int err = open(errors, O_WRONLY | O_CREAT | O_TRUNC, 0666);
        if (out < 0 || err < 0 || dup2(out, STDOUT_FILENO) < 0 || dup2(err, STDERR_FILENO) < 0 || (directory != NULL && chdir(directory) != 0))
        {
            _exit(125);
        }
        close(out);
        close(err);
        execvp(args[0], args);
        _exit(126);
    }
    int status = 0;
    if (ok)
    {
        pid_t waited;
        do
        {
            waited = waitpid(child, &status, 0);
        }
        while (waited < 0 && errno == EINTR);
        ok = waited == child && WIFEXITED(status) && WEXITSTATUS(status) == 0;
    }
    if (!ok)
    {
        fprintf(stderr, "command failed: %s (wait status %d); see %s\n", args[0], status, errors);
    }
    return ok;
}

// Preserve completed captures outside the ephemeral measurement filesystem. This runs only after both measured
// processes have exited, without adding an environment variable or changing their paths/arguments.
static bool archive_workload(const char* out, const char* archive, const char* name)
{
    const char* const suffixes[] = { "cg", "native.out", "native.err", "callgrind.out", "callgrind.err" };
    bool ok = true;
    for (uint32_t i = 0; ok && archive != NULL && i < sizeof(suffixes) / sizeof(suffixes[0]); i += 1)
    {
        char filename[160];
        char source[BUSTER_MEASURE_PATH];
        char target[BUSTER_MEASURE_PATH];
        char partial[BUSTER_MEASURE_PATH];
        char errors[BUSTER_MEASURE_PATH];
        snprintf(filename, sizeof(filename), "%s.%s", name, suffixes[i]);
        ok = path_join(source, out, filename);
        snprintf(filename, sizeof(filename), "%s.%s.gz", name, suffixes[i]);
        ok = ok && path_join(target, archive, filename);
        snprintf(filename, sizeof(filename), "%s.%s.gz.partial", name, suffixes[i]);
        ok = ok && path_join(partial, archive, filename);
        snprintf(filename, sizeof(filename), "%s.archive.err", name);
        ok = ok && path_join(errors, archive, filename);
        char* args[] = { "gzip", "-n", "-c", source, NULL };
        ok = ok && run_command(args, NULL, partial, errors);
        const int file = ok ? open(partial, O_RDONLY) : -1;
        ok = ok && file >= 0 && fsync(file) == 0;
        if (file >= 0)
        {
            ok = close(file) == 0 && ok;
        }
        ok = ok && rename(partial, target) == 0;
    }
    return ok;
}

static bool run_workload(const char* out, const char* scripts, const char* valgrind, const char* archive, uint32_t index)
{
    const char* const name = workloads[index];
    char binary[BUSTER_MEASURE_PATH];
    char script[128];
    char database[BUSTER_MEASURE_PATH];
    char temporary[BUSTER_MEASURE_PATH];
    char plain_output[BUSTER_MEASURE_PATH];
    char plain_errors[BUSTER_MEASURE_PATH];
    char cg_output[BUSTER_MEASURE_PATH];
    char cg_errors[BUSTER_MEASURE_PATH];
    char cg_option[BUSTER_MEASURE_PATH];
    char filename[128];
    bool ok = path_join(binary, BUSTER_MEASURE_CURRENT, index == 0 ? "speedtest1" : "lua") && path_join(database, BUSTER_MEASURE_CURRENT, "sqlite-data") && path_join(temporary, database, "tmp");
    snprintf(script, sizeof(script), "%s.lua", name);
    snprintf(filename, sizeof(filename), "%s.native.out", name);
    ok = ok && path_join(plain_output, out, filename);
    snprintf(filename, sizeof(filename), "%s.native.err", name);
    ok = ok && path_join(plain_errors, out, filename);
    snprintf(filename, sizeof(filename), "%s.callgrind.out", name);
    ok = ok && path_join(cg_output, out, filename);
    snprintf(filename, sizeof(filename), "%s.callgrind.err", name);
    ok = ok && path_join(cg_errors, out, filename);
    const int option_length = snprintf(cg_option, sizeof(cg_option), "--callgrind-out-file=%s/%s.cg", out, name);
    ok = ok && option_length > 0 && option_length < (int)sizeof(cg_option);
    if (ok && index == 0)
    {
        ok = make_directory(database) && make_directory(temporary) && setenv("SQLITE_TMPDIR", temporary, 1) == 0;
        const char* files[] = { "verify.db", "verify.db-wal", "verify.db-shm", "verify.db-journal", "count.db", "count.db-wal", "count.db-shm", "count.db-journal" };
        for (uint32_t f = 0; ok && f < sizeof(files) / sizeof(files[0]); f += 1)
        {
            char path[BUSTER_MEASURE_PATH];
            ok = path_join(path, database, files[f]) && (unlink(path) == 0 || errno == ENOENT);
        }
    }
    char* sqlite_plain[] = { binary, "--shrink-memory", "--reprepare", "--stats", "--journal", "wal", "--size", "5", "--heap", "40000000", "64", "--testset", "mix1", "--verify", "verify.db", NULL };
    char* lua_plain[] = { binary, script, NULL };
    char* sqlite_count[] = { (char*)valgrind, "--tool=callgrind", "--dump-instr=yes", "--error-exitcode=99", cg_option, binary, "--shrink-memory", "--reprepare", "--stats", "--journal", "wal", "--size", "5", "--heap", "40000000", "64", "--testset", "mix1", "count.db", NULL };
    char* lua_count[] = { (char*)valgrind, "--tool=callgrind", "--dump-instr=yes", "--error-exitcode=99", cg_option, binary, script, NULL };
    const char* directory = index == 0 ? database : scripts;
    ok = ok && run_command(index == 0 ? sqlite_plain : lua_plain, directory, plain_output, plain_errors);
    ok = ok && run_command(index == 0 ? sqlite_count : lua_count, directory, cg_output, cg_errors);
    ok = ok && archive_workload(out, archive, name);
    printf("%s %s\n", name, ok ? "captured" : "FAILED");
    fflush(stdout);
    return ok;
}

static bool run_suite(const char* out, const char* scripts, const char* valgrind, const char* library, const char* archive, uint32_t first, uint32_t cases)
{
    bool ok = make_directory(out) && make_directory(BUSTER_MEASURE_CURRENT) && setenv("LC_ALL", "C", 1) == 0 && setenv("TZ", "UTC", 1) == 0 && setenv("VALGRIND_LIB", library, 1) == 0;
    ok = ok && (archive == NULL || make_directory(archive));
    const int lock = ok ? open(BUSTER_MEASURE_CURRENT "/suite.lock", O_RDWR | O_CREAT | O_CLOEXEC, 0600) : -1;
    ok = ok && lock >= 0 && flock(lock, LOCK_EX | LOCK_NB) == 0;
    ok = ok && copy_program(out, "speedtest1") && copy_program(out, "lua");
    uint32_t running = 0;
    uint32_t next = first;
    while (ok && next < cases)
    {
        const pid_t child = fork();
        if (child == 0)
        {
            _exit(run_workload(out, scripts, valgrind, archive, next) ? 0 : 1);
        }
        ok = child > 0;
        next += ok;
        running += ok;
        if (running == 2 || (!ok && running != 0))
        {
            int status = 0;
            pid_t waited;
            do
            {
                waited = waitpid(-1, &status, 0);
            }
            while (waited < 0 && errno == EINTR);
            ok = ok && waited > 0 && WIFEXITED(status) && WEXITSTATUS(status) == 0;
            running -= waited > 0;
        }
    }
    while (running != 0)
    {
        int status = 0;
        pid_t waited;
        do
        {
            waited = waitpid(-1, &status, 0);
        }
        while (waited < 0 && errno == EINTR);
        ok = ok && waited > 0 && WIFEXITED(status) && WEXITSTATUS(status) == 0;
        running -= waited > 0;
        running = waited < 0 ? 0 : running;
    }
    if (lock >= 0)
    {
        close(lock);
    }
    return ok;
}

static FunctionCount* function_count(Summary* summary, const char* name)
{
    FunctionCount* result = NULL;
    for (uint32_t f = 0; result == NULL && f < summary->function_count; f += 1)
    {
        result = strcmp(summary->functions[f].name, name) == 0 ? &summary->functions[f] : NULL;
    }
    if (result == NULL && summary->function_count < BUSTER_MEASURE_FUNCTIONS)
    {
        result = &summary->functions[summary->function_count];
        result->name = strdup(name);
        summary->function_count += result->name != NULL;
        result = result->name != NULL ? result : NULL;
    }
    return result;
}

static uint64_t origin_sum(const uint64_t* counts, const char* letters)
{
    uint64_t result = 0;
    for (const char* c = letters; *c != 0; c += 1)
    {
        result += counts[(uint8_t)*c];
    }
    return result;
}

static bool summarize(const char* name, const char* path, bool tagged, FILE* output, FILE* audit)
{
    Summary* const summary = calloc(1, sizeof(Summary));
    FILE* input = fopen(path, "r");
    bool ok = summary != NULL && input != NULL;
    char* line = NULL;
    size_t capacity = 0;
    while (ok && getline(&line, &capacity, input) > 0)
    {
        line[strcspn(line, "\r\n")] = 0;
        char* field[5] = { 0 };
        char* cursor = line;
        for (uint32_t f = 0; f < 5 && cursor != NULL; f += 1)
        {
            field[f] = strsep(&cursor, "\t");
        }
        if (strcmp(field[0], "#total") == 0 && field[1] != NULL)
        {
            summary->total = strtoull(field[1], NULL, 10);
            summary->saw_total = true;
        }
        else if (strcmp(field[0], "#check") == 0 && field[1] != NULL && strcmp(field[1], "unmatched") == 0 && field[2] != NULL)
        {
            summary->unmatched = strtoull(field[2], NULL, 10);
            summary->saw_unmatched = true;
        }
        else if (strcmp(field[0], "#check") == 0 && field[1] != NULL && strcmp(field[1], "outside_object") == 0 && field[2] != NULL)
        {
            summary->outside = strtoull(field[2], NULL, 10);
            fprintf(audit, "%s\toutside_object\t%" PRIu64 "\n", name, summary->outside);
        }
        else if (strcmp(field[0], "#check") == 0 && field[1] != NULL && strcmp(field[1], "executable_range") == 0 && field[2] != NULL && field[3] != NULL)
        {
            fprintf(audit, "%s\texecutable_range\t%s\t%s\n", name, field[2], field[3]);
        }
        else if (strcmp(field[0], "#check") == 0 && field[1] != NULL && strcmp(field[1], "kinds") == 0 && field[2] != NULL && field[3] != NULL)
        {
            FunctionCount* const function = function_count(summary, field[2]);
            ok = function != NULL;
            if (ok && sscanf(field[3], "fitted %d functions", &function->fitted) == 1)
            {
                function->checked = true;
            }
            fprintf(audit, "%s\t%s\t%s\n", name, field[2], field[3]);
        }
        else if (field[0][0] != '#' && field[1] != NULL && field[2] != NULL && field[3] != NULL)
        {
            const uint8_t origin = (uint8_t)field[1][0];
            const uint64_t count = strtoull(field[3], NULL, 10);
            FunctionCount* const function = function_count(summary, field[0]);
            ok = function != NULL && field[1][1] == 0 && (strchr(origin_letters, origin) != NULL || origin == '-' || origin == '_');
            if (ok)
            {
                function->count += count;
                summary->origins[origin] += count;
                if (strcmp(field[0], "yy_reduce") == 0)
                {
                    summary->reduce_total += count;
                    summary->reduce_origins[origin] += count;
                }
                if (strcmp(field[0], "sqlite3VdbeExec") == 0 || strcmp(field[0], "luaV_execute") == 0)
                {
                    summary->hot_total += count;
                    summary->hot_origins[origin] += count;
                }
                if (origin == '-')
                {
                    fprintf(audit, "%s\tuntagged\t%s\t%s\t%" PRIu64 "\n", name, field[0], field[2], count);
                }
            }
        }
    }
    if (summary != NULL)
    {
        const uint64_t accounted = origin_sum(summary->origins, "SLTUCReapfrjnhxtu-_");
        ok = ok && summary->saw_total && summary->saw_unmatched && summary->total != 0 && summary->unmatched == 0 && accounted == summary->total;
        ok = ok && (!tagged || origin_sum(summary->origins, origin_letters) != 0);
        fprintf(audit, "%s\ttotal=%" PRIu64 "\taccounted=%" PRIu64 "\tunmatched=%" PRIu64 "\n", name, summary->total, accounted, summary->unmatched);
        for (uint32_t f = 0; f < summary->function_count; f += 1)
        {
            const FunctionCount* const function = &summary->functions[f];
            if (function->checked && function->count != 0 && function->fitted != 1)
            {
                fprintf(audit, "%s\tFAILED tag fit\t%s\tfitted=%d\texecuted=%" PRIu64 "\n", name, function->name, function->fitted, function->count);
                ok = false;
            }
            free(function->name);
        }
        fprintf(output, "%s\t%" PRIu64, name, summary->total);
        for (const char* c = "SLCR ehxTtUurafpjn"; *c != 0; c += 1)
        {
            if (*c != ' ')
            {
                fprintf(output, "\t%" PRIu64, summary->origins[(uint8_t)*c]);
            }
        }
        fprintf(output, "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%s\n",
                origin_sum(summary->origins, "SLTtUu"), origin_sum(summary->origins, "CR"), origin_sum(summary->origins, "ehxTtUu"), origin_sum(summary->origins, "SLCTUR ehxtu"),
                summary->reduce_total, summary->reduce_origins['C'], summary->reduce_origins['R'], summary->hot_total, origin_sum(summary->hot_origins, "SLCTUR ehxtu"), summary->origins['-'], summary->outside, ok ? (tagged ? "PASS" : "UNTAGGED") : "FAIL");
    }
    free(line);
    free(summary);
    if (input != NULL)
    {
        fclose(input);
    }
    return ok;
}

static bool join_suite(const char* out, const char* gap, const char* object, const char* bias, bool tagged, uint32_t cases)
{
    char binary[BUSTER_MEASURE_PATH];
    char disassembly[BUSTER_MEASURE_PATH];
    char kinds[BUSTER_MEASURE_PATH];
    char capture[BUSTER_MEASURE_PATH];
    char tsv[BUSTER_MEASURE_PATH];
    char errors[BUSTER_MEASURE_PATH];
    char summary_path[BUSTER_MEASURE_PATH];
    char audit_path[BUSTER_MEASURE_PATH];
    bool ok = path_join(summary_path, out, tagged ? "summary.tsv" : "summary-untagged.tsv") && path_join(audit_path, out, tagged ? "audit.tsv" : "audit-untagged.tsv");
    FILE* summary = ok ? fopen(summary_path, "w") : NULL;
    FILE* audit = ok ? fopen(audit_path, "w") : NULL;
    ok = ok && summary != NULL && audit != NULL;
    if (ok)
    {
        fprintf(summary, "workload\ttotal\tS\tL\tC\tR\te\th\tx\tT\tt\tU\tu\tr\ta\tf\tp\tj\tn\tspills_all\tcalls_all\tedges_all\ttransport_all\tyy_total\tyy_C\tyy_R\thot_total\thot_transport\tuntagged\toutside_object\taudit\n");
    }
    for (uint32_t i = 0; ok && i < cases; i += 1)
    {
        const char* const program = i == 0 ? "speedtest1" : "lua";
        char filename[128];
        ok = path_join(binary, out, program);
        snprintf(filename, sizeof(filename), "%s.dis", program);
        ok = ok && path_join(disassembly, out, filename);
        snprintf(filename, sizeof(filename), "%s.kinds", program);
        ok = ok && path_join(kinds, out, filename);
        snprintf(filename, sizeof(filename), "%s.cg", workloads[i]);
        ok = ok && path_join(capture, out, filename);
        snprintf(filename, sizeof(filename), tagged ? "%s.tsv" : "%s-untagged.tsv", workloads[i]);
        ok = ok && path_join(tsv, out, filename);
        snprintf(filename, sizeof(filename), "%s.join.err", workloads[i]);
        ok = ok && path_join(errors, out, filename);
        char* disassemble[] = { "objdump", "-d", "--no-show-raw-insn", binary, NULL };
        char* join[] = { (char*)gap, "count", disassembly, capture, (char*)object, (char*)bias, tagged ? kinds : NULL, NULL };
        ok = ok && setenv("GAP_EXECUTABLE", binary, 1) == 0;
        ok = ok && (i > 1 || run_command(disassemble, NULL, disassembly, errors));
        ok = ok && run_command(join, NULL, tsv, errors);
        ok = ok && summarize(workloads[i], tsv, tagged, summary, audit);
    }
    if (summary != NULL)
    {
        fclose(summary);
    }
    if (audit != NULL)
    {
        fclose(audit);
    }
    return ok;
}

typedef struct FunctionPair FunctionPair;
struct FunctionPair
{
    char* name;
    uint64_t count[2];
};

static int compare_change(const void* left, const void* right)
{
    const FunctionPair* const a = left;
    const FunctionPair* const b = right;
    const int64_t da = (int64_t)a->count[1] - (int64_t)a->count[0];
    const int64_t db = (int64_t)b->count[1] - (int64_t)b->count[0];
    const uint64_t aa = da < 0 ? (uint64_t)-da : (uint64_t)da;
    const uint64_t ab = db < 0 ? (uint64_t)-db : (uint64_t)db;
    return aa > ab ? -1 : aa < ab ? 1 : strcmp(a->name, b->name);
}

static bool compare_functions(const char* before, const char* after, const char* origins)
{
    FunctionPair* const functions = calloc(BUSTER_MEASURE_FUNCTIONS, sizeof(FunctionPair));
    uint32_t count = 0;
    bool ok = functions != NULL;
    for (uint32_t side = 0; ok && side < 2; side += 1)
    {
        FILE* input = fopen(side == 0 ? before : after, "r");
        ok = input != NULL;
        char* line = NULL;
        size_t capacity = 0;
        while (ok && getline(&line, &capacity, input) > 0)
        {
            char* field[4] = { 0 };
            char* cursor = line;
            for (uint32_t f = 0; f < 4 && cursor != NULL; f += 1)
            {
                field[f] = strsep(&cursor, "\t");
            }
            if (field[0][0] != '#' && field[1] != NULL && field[2] != NULL && field[3] != NULL && (origins == NULL || strchr(origins, field[1][0]) != NULL))
            {
                uint32_t f = 0;
                while (f < count && strcmp(functions[f].name, field[0]) != 0)
                {
                    f += 1;
                }
                ok = f < BUSTER_MEASURE_FUNCTIONS;
                if (ok && f == count)
                {
                    functions[count].name = strdup(field[0]);
                    ok = functions[count].name != NULL;
                    count += ok;
                }
                if (ok)
                {
                    functions[f].count[side] += strtoull(field[3], NULL, 10);
                }
            }
        }
        free(line);
        if (input != NULL)
        {
            fclose(input);
        }
    }
    if (ok)
    {
        qsort(functions, count, sizeof(FunctionPair), compare_change);
        printf("function\tbase\thead\tdelta\n");
        for (uint32_t f = 0; f < count; f += 1)
        {
            if (functions[f].count[0] != functions[f].count[1])
            {
                printf("%s\t%" PRIu64 "\t%" PRIu64 "\t%" PRId64 "\n", functions[f].name, functions[f].count[0], functions[f].count[1], (int64_t)functions[f].count[1] - (int64_t)functions[f].count[0]);
            }
        }
    }
    for (uint32_t f = 0; f < count; f += 1)
    {
        free(functions[f].name);
    }
    free(functions);
    return ok;
}

int main(int argc, char** argv)
{
    bool ok = false;
    if ((argc == 6 || argc == 7) && strcmp(argv[1], "run") == 0)
    {
        ok = run_suite(argv[2], argv[3], argv[4], argv[5], argc == 7 ? argv[6] : NULL, 0, BUSTER_MEASURE_CASES);
    }
    else if ((argc == 6 || argc == 7) && strcmp(argv[1], "run-pair") == 0)
    {
        ok = run_suite(argv[2], argv[3], argv[4], argv[5], argc == 7 ? argv[6] : NULL, 0, 2);
    }
    else if ((argc == 6 || argc == 7) && strcmp(argv[1], "run-lua") == 0)
    {
        ok = run_suite(argv[2], argv[3], argv[4], argv[5], argc == 7 ? argv[6] : NULL, 1, BUSTER_MEASURE_CASES);
    }
    else if (argc == 6 && strcmp(argv[1], "join") == 0)
    {
        ok = join_suite(argv[2], argv[3], argv[4], argv[5], true, BUSTER_MEASURE_CASES);
    }
    else if (argc == 6 && strcmp(argv[1], "join-untagged") == 0)
    {
        ok = join_suite(argv[2], argv[3], argv[4], argv[5], false, BUSTER_MEASURE_CASES);
    }
    else if (argc == 6 && strcmp(argv[1], "join-pair-untagged") == 0)
    {
        ok = join_suite(argv[2], argv[3], argv[4], argv[5], false, 2);
    }
    else if (argc == 4 && strcmp(argv[1], "compare-functions") == 0)
    {
        ok = compare_functions(argv[2], argv[3], NULL);
    }
    else if (argc == 5 && strcmp(argv[1], "compare-origins") == 0)
    {
        ok = compare_functions(argv[2], argv[3], argv[4]);
    }
    else if (argc == 4 && strcmp(argv[1], "summary-file") == 0)
    {
        ok = summarize(argv[3], argv[2], true, stdout, stderr);
    }
    else
    {
        fprintf(stderr, "usage: measure-2610 run|run-pair|run-lua OUT SCRIPTS VALGRIND VALGRIND_LIB [ARCHIVE]\n       measure-2610 join|join-untagged|join-pair-untagged OUT GAP OBJECT LOAD_BIAS\n       measure-2610 compare-functions BASE_TSV HEAD_TSV\nOUT must contain prepared speedtest1 and lua binaries; join also needs their .kinds sidecars.\nExecutables and SQLite database paths stay constant under " BUSTER_MEASURE_CURRENT "; an exclusive lock covers the complete suite.\nARCHIVE receives each completed workload's raw capture and output logs, gzip-compressed before the worker exits.\n");
    }
    return ok ? 0 : 1;
}
