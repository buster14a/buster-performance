// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Syntax-only seam for the modified complete scoring file; no compiler build or executable is linked.
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <immintrin.h>
typedef enum { TIER1_EMIT_OK, TIER1_EMIT_INVALID, TIER1_EMIT_MEMORY, TIER1_EMIT_LIMIT } Tier1EmitError;
enum { TIER1_CFG_EDGE_EMPTY, TIER1_CFG_EDGE_PREDECESSOR, TIER1_CFG_EDGE_SUCCESSOR, TIER1_CFG_EDGE_SPLIT };
enum { IR_BR, IR_CBR, IR_BR_INDIRECT };
typedef struct { uint8_t* base; uint64_t length, capacity; } Arena;
typedef struct { const uint32_t* successors; const uint32_t* successor_offsets; uint32_t block_count, edge_count; } Tier1CfgInput;
typedef struct { const uint32_t* block_offsets; const uint8_t* op; uint32_t block_count; } IrFunction;
typedef struct { const IrFunction* function; } Tier1SelectPlan;
typedef struct { uint32_t fragment_count; } Tier1Allocation;
typedef struct { Tier1Allocation allocation; const uint32_t* edge_move_offsets; const uint8_t* edge_placements; uint8_t temp_slots; } Tier1CfgAllocation;
typedef struct { uint32_t count, block; } Tier1EmitRecolorCall;
typedef struct { const uint64_t* weights; const uint64_t* edge_weights; const Tier1EmitRecolorCall* calls; uint32_t count, callee; } Tier1EmitRecolorModel;
typedef struct { __int128 preservation, arguments, edges; } Tier1EmitRecolorCost;
typedef struct { uint32_t call_count, fragment_count; } Tier1EmitRegionArguments;
typedef struct { uint64_t generation; uint32_t blocks; const uint32_t* stores; const uint32_t* loads; } Tier1EmitEpochCache;
typedef struct {
    const Tier1EmitEpochCache* cache; uint64_t generation; uint32_t block_count, fragment_count;
    const uint32_t* blocks; const uint32_t* stores; const uint32_t* loads; const uint32_t* fragments;
} Tier1EmitEpochTrial;
typedef struct {
    Tier1CfgAllocation cfg; uint32_t edge_count; uint8_t temp_slots;
    const uint32_t* edges; const uint32_t* offsets; const uint8_t* placements;
    const uint32_t* after_memory; const uint32_t* before_memory; const uint32_t* after_recipes; const uint32_t* before_recipes;
} Tier1EmitRegionProposal;
extern bool tier1_emit_recolor_charge(uint64_t, uint64_t*);
extern void* ir_allocate(Arena*, uint64_t, uint64_t, bool*);
extern void arena_pop_to(Arena*, uint64_t);
extern bool tier1_emit_region_argument_records(const Tier1EmitRegionArguments*, const Tier1EmitRecolorModel*, const Tier1CfgAllocation*, uint32_t, Arena*, uint32_t*);
extern Tier1EmitError tier1_emit_region_argument_gains(const Tier1EmitRegionArguments*, const Tier1EmitRecolorModel*, const Tier1CfgAllocation*, const Tier1CfgAllocation*,
                                                      const uint32_t*, uint32_t, Arena*, uint64_t*, int64_t*, __int128*);
#include "../proposed/src/buster/compiler/tier1_emit_region_score.c"
