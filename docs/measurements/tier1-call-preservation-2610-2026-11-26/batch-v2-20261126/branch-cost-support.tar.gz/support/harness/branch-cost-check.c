// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Focused #2610 control-cost experiment; the branch and path functions are exact source extractions.
// The capture stubs replace only record storage and edge-move emission. Branch orientation is not rewritten.
#include <stdbool.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>

#define BUSTER_ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))
#define BUSTER_TIER1_EMIT_CFG_STUB 0x80000000u
#define BUSTER_TIER1_RECOLOR_ACTIVE_WORK UINT64_C(100000000)
enum { X86_FORM_NONE, X86_FORM_JMP_REL8, X86_FORM_JMP_RM64, X86_FORM_JE_REL8 = 10, X86_FORM_JNE_REL8,
       X86_FORM_JL_REL8, X86_FORM_JGE_REL8, X86_FORM_JLE_REL8, X86_FORM_JG_REL8,
       X86_FORM_JB_REL8, X86_FORM_JAE_REL8, X86_FORM_JBE_REL8, X86_FORM_JA_REL8 };
enum { TIER1_CFG_EDGE_EMPTY, TIER1_CFG_EDGE_PREDECESSOR, TIER1_CFG_EDGE_SUCCESSOR, TIER1_CFG_EDGE_SPLIT };
enum { IR_BR, IR_CBR, IR_BR_INDIRECT, IR_RETURN };
typedef enum { TIER1_EMIT_OK, TIER1_EMIT_INVALID, TIER1_EMIT_MEMORY, TIER1_EMIT_LIMIT } Tier1EmitError;
typedef struct { const uint32_t* successors; const uint32_t* successor_offsets; uint32_t block_count, edge_count; } Tier1CfgInput;
typedef struct { const uint8_t* edge_placements; } Tier1CfgAllocation;
typedef struct { const uint32_t* block_offsets; const uint8_t* op; uint32_t block_count; } IrFunction;
typedef struct { const IrFunction* function; } Tier1SelectPlan;
typedef struct { uint16_t form; uint32_t goal; bool move; uint8_t mode; } CapturedRecord;
typedef struct { CapturedRecord records[64]; uint32_t count, branch_count, branches[64], targets[64]; } Tier1EmitBuffer;
typedef struct {
    Tier1CfgInput cfg_input; Tier1CfgAllocation cfg;
    uint32_t edge_stubs, jumps, dispatch_copies, move_counts[2];
} Tier1EmitResult;
typedef struct { __int128 preservation, arguments, edges; } Tier1EmitRecolorCost;
typedef struct { const uint64_t* edge_weights; } Tier1EmitRecolorModel;
typedef struct {
    Tier1EmitRecolorCost cost; int64_t* preservation_gains; int64_t* block_gains;
    int64_t* edge_gains; int64_t* total_edge_gains;
} Tier1EmitRegionScore;
typedef struct { uint8_t* base; uint64_t length, capacity; } Arena;

static uint64_t checks, paths, transitions;
static void require(bool good, const char* message)
{
    checks += 1;
    if (!good) { fprintf(stderr, "FAIL: %s\n", message); exit(1); }
}
static void* ir_allocate(Arena* arena, uint64_t count, uint64_t width, bool* ok)
{
    const uint64_t at = (arena->length + 63) & ~UINT64_C(63);
    const uint64_t bytes = count * width;
    if (!*ok || at > arena->capacity || bytes > arena->capacity - at) { *ok = false; return NULL; }
    void* result = arena->base + at;
    memset(result, 0, bytes);
    arena->length = at + bytes;
    return result;
}
static void arena_pop_to(Arena* arena, uint64_t length) { arena->length = length; }
static bool tier1_emit_recolor_charge(uint64_t amount, uint64_t* work)
{
    const bool ok = *work <= BUSTER_TIER1_RECOLOR_ACTIVE_WORK && amount <= BUSTER_TIER1_RECOLOR_ACTIVE_WORK - *work;
    *work += ok ? amount : 0;
    return ok;
}
static Tier1EmitError tier1_emit_cfg_jump(Tier1EmitBuffer* buffer, uint16_t form, uint32_t goal,
                                         uint32_t* branches, uint32_t* goals, uint32_t* pending, Tier1EmitResult* emitted)
{
    if (buffer->count == BUSTER_ARRAY_LENGTH(buffer->records)) { return TIER1_EMIT_MEMORY; }
    branches[*pending] = buffer->branch_count;
    buffer->branches[buffer->branch_count] = buffer->count;
    buffer->targets[buffer->branch_count++] = 0;
    goals[*pending] = goal;
    *pending += 1;
    buffer->records[buffer->count++] = (CapturedRecord){ .form = form, .goal = goal };
    emitted->jumps += 1;
    return TIER1_EMIT_OK;
}
static Tier1EmitError tier1_emit_cfg_moves(Tier1EmitResult* emitted, uint32_t edge, Tier1EmitBuffer* buffer)
{
    for (uint32_t k = 0; k < emitted->move_counts[edge]; k += 1)
    {
        if (buffer->count == BUSTER_ARRAY_LENGTH(buffer->records)) { return TIER1_EMIT_MEMORY; }
        buffer->records[buffer->count++] = (CapturedRecord){ .goal = edge, .move = true };
    }
    return TIER1_EMIT_OK;
}
#include "emitter-inverse.inc"
#include "emitter-branch.inc"
#include "emitter-dispatch.inc"
#include "existing-control.inc"
#include "../proposed/src/buster/compiler/tier1_emit_region_branch_cost.c"
#include "path-gain.inc"
#include "certify-result.inc"

static uint32_t actual_path(uint32_t block, uint32_t target_true, uint32_t target_false, unsigned split,
                            uint32_t true_moves, uint32_t false_moves, uint16_t condition, bool outcome)
{
    const uint32_t targets[2] = { target_true, target_false };
    const uint8_t placements[2] = {
        (split & 1u) ? TIER1_CFG_EDGE_SPLIT : TIER1_CFG_EDGE_EMPTY,
        (split & 2u) ? TIER1_CFG_EDGE_SPLIT : TIER1_CFG_EDGE_EMPTY,
    };
    Tier1EmitResult emitted = {
        .cfg_input = { .successors = targets }, .cfg = { .edge_placements = placements },
        .move_counts = { true_moves, false_moves },
    };
    Tier1EmitBuffer buffer = { 0 };
    uint32_t stub_first[2] = { UINT32_MAX, UINT32_MAX };
    uint32_t branches[8], goals[8], pending = 0;
    require(tier1_emit_cfg_branch(&emitted, block, 0, condition, &buffer, stub_first, branches, goals, &pending) == TIER1_EMIT_OK,
            "actual emitter produces branch records");
    uint32_t pc = 0, instructions = 0, arrived = UINT32_MAX, moves[2] = { 0, 0 };
    for (uint32_t step = 0; step < 32 && arrived == UINT32_MAX; step += 1)
    {
        if (pc == buffer.count) { arrived = block + 1; break; }
        require(pc < buffer.count, "captured control stays in the record buffer");
        const CapturedRecord record = buffer.records[pc++];
        if (record.move) { moves[record.goal] += 1; continue; }
        instructions += 1;
        const bool jump = record.form == X86_FORM_JMP_REL8 || (record.form == condition ? outcome : !outcome);
        if (jump)
        {
            if ((record.goal & BUSTER_TIER1_EMIT_CFG_STUB) != 0)
            {
                const uint32_t edge = record.goal & ~BUSTER_TIER1_EMIT_CFG_STUB;
                require(edge < 2 && stub_first[edge] != UINT32_MAX, "taken stub is defined");
                pc = stub_first[edge];
            }
            else { arrived = record.goal; }
        }
    }
    const uint32_t edge = outcome ? 0 : 1;
    require(arrived == targets[edge], "each true/false path reaches the semantic successor");
    require(moves[edge ^ 1u] == 0, "a path does not execute its sibling's edge moves");
    require(moves[edge] == ((split & (1u << edge)) != 0 ? emitted.move_counts[edge] : 0), "a path executes its own split moves once");
    paths += 1;
    return instructions;
}

static void exhaustive_records(void)
{
    for (uint32_t block = 0; block < 7; block += 1)
    for (uint32_t t = 0; t < 8; t += 1)
    for (uint32_t f = 0; f < 8; f += 1)
    if (t != f)
    for (unsigned split = 0; split < 4; split += 1)
    for (uint32_t mt = 0; mt < 4; mt += 1)
    for (uint32_t mf = 0; mf < 4; mf += 1)
    for (uint16_t condition = X86_FORM_JE_REL8; condition <= X86_FORM_JA_REL8; condition += 1)
    {
        uint32_t predicted[2];
        tier1_emit_region_branch_records(block, t, f, (split & 1u) != 0, (split & 2u) != 0, predicted);
        for (uint32_t k = 0; k < 2; k += 1)
        {
            const uint32_t observed = actual_path(block, t, f, split, mt, mf, condition, k == 0);
            require(observed == predicted[k], "predicted branch instructions equal the actual emitter's executed path");
        }
    }
}

static void transition_and_guard_checks(void)
{
    const uint32_t offsets[] = { 0, 2, 2, 2, 2 };
    const uint32_t node_offsets[] = { 0, 1, 2, 3, 4 };
    uint8_t ops[] = { IR_CBR, IR_RETURN, IR_RETURN, IR_RETURN };
    uint32_t targets[2] = { 2, 3 };
    uint8_t old_place[2], new_place[2];
    const uint64_t weights[] = { 3, 5 };
    Tier1CfgInput input = { .successors = targets, .successor_offsets = offsets, .block_count = 4, .edge_count = 2 };
    IrFunction function = { .block_offsets = node_offsets, .op = ops, .block_count = 4 };
    Tier1SelectPlan plan = { .function = &function };
    Tier1CfgAllocation before = { .edge_placements = old_place }, after = { .edge_placements = new_place };
    Tier1EmitRecolorModel model = { .edge_weights = weights };
    int64_t copies[2] = { 7, -3 }, total[2];
    for (uint32_t layout = 0; layout < 3; layout += 1)
    {
        targets[0] = layout == 0 ? 1 : 2;
        targets[1] = layout == 1 ? 1 : 3;
        for (unsigned old = 0; old < 4; old += 1)
        for (unsigned next = 0; next < 4; next += 1)
        {
            old_place[0] = (old & 1u) ? TIER1_CFG_EDGE_SPLIT : TIER1_CFG_EDGE_EMPTY;
            old_place[1] = (old & 2u) ? TIER1_CFG_EDGE_SPLIT : TIER1_CFG_EDGE_EMPTY;
            new_place[0] = (next & 1u) ? TIER1_CFG_EDGE_SPLIT : TIER1_CFG_EDGE_EMPTY;
            new_place[1] = (next & 2u) ? TIER1_CFG_EDGE_SPLIT : TIER1_CFG_EDGE_EMPTY;
            Tier1EmitRegionScore score = { .edge_gains = copies, .total_edge_gains = total, .cost = { .edges = 1000 } };
            uint64_t work = 0;
            require(tier1_emit_region_branch_gains(&plan, &input, &before, &after, &model, &work, &score) == TIER1_EMIT_OK,
                    "direct conditional control transition is supported");
            __int128 expected = 1000;
            for (uint32_t k = 0; k < 2; k += 1)
            {
                const int64_t actual = (int64_t)actual_path(0, targets[0], targets[1], old, 2, 3, X86_FORM_JE_REL8, k == 0) -
                                      actual_path(0, targets[0], targets[1], next, 2, 3, X86_FORM_JE_REL8, k == 0);
                require(total[k] == copies[k] + actual, "both total edge gains include the actual branch delta");
                expected -= (__int128)weights[k] * actual;
            }
            require(score.cost.edges == expected, "weighted control delta uses each semantic edge's weight");
            require(copies[0] == 7 && copies[1] == -3, "transport edge gains stay untouched");
            Tier1EmitRecolorCost initial = { .edges = weights[0] * (old_place[0] == TIER1_CFG_EDGE_SPLIT) +
                                                     weights[1] * (old_place[1] == TIER1_CFG_EDGE_SPLIT) };
            work = 0;
            require(tier1_emit_region_branch_initial(&plan, &input, &before, &model, &work, &initial) == TIER1_EMIT_OK,
                    "initial score rebase succeeds");
            expected = 0;
            for (uint32_t k = 0; k < 2; k += 1)
            {
                expected += (__int128)weights[k] * actual_path(0, targets[0], targets[1], old, 0, 0, X86_FORM_JE_REL8, k == 0);
            }
            require(initial.edges == expected, "initial score prices actual branch records");
            transitions += 1;
        }
    }
    targets[0] = 2; targets[1] = 3;
    old_place[0] = old_place[1] = new_place[1] = TIER1_CFG_EDGE_EMPTY;
    new_place[0] = TIER1_CFG_EDGE_SPLIT;
    for (uint32_t forbidden = 0; forbidden < 3; forbidden += 1)
    {
        ops[forbidden == 0 ? 0 : targets[forbidden - 1]] = IR_BR_INDIRECT;
        Tier1EmitRegionScore score = { .edge_gains = copies, .total_edge_gains = total };
        uint64_t work = 0;
        require(tier1_emit_region_branch_gains(&plan, &input, &before, &after, &model, &work, &score) == TIER1_EMIT_INVALID,
                "indirect source or either indirect target refuses split changes");
        ops[0] = IR_CBR; ops[2] = ops[3] = IR_RETURN;
    }
    new_place[0] = old_place[0] = TIER1_CFG_EDGE_EMPTY;
    new_place[1] = TIER1_CFG_EDGE_SUCCESSOR;
    ops[3] = IR_BR_INDIRECT;
    Tier1EmitRegionScore score = { .edge_gains = copies, .total_edge_gains = total };
    uint64_t work = 0;
    require(tier1_emit_region_branch_gains(&plan, &input, &before, &after, &model, &work, &score) == TIER1_EMIT_INVALID,
            "stable split flags retain the original indirect-successor guard");
    ops[3] = IR_RETURN;
    Tier1EmitRecolorCost initial = { .edges = 123 };
    work = BUSTER_TIER1_RECOLOR_ACTIVE_WORK;
    require(tier1_emit_region_branch_initial(&plan, &input, &before, &model, &work, &initial) == TIER1_EMIT_LIMIT && initial.edges == 123,
            "initial control budget refusal does not publish partial cost");
}

static void dispatch_relays(void)
{
    Tier1EmitBuffer buffer = {
        .records = { [0] = { .form = X86_FORM_JMP_REL8 }, [3] = { .form = X86_FORM_JMP_REL8 },
                     [4] = { .form = X86_FORM_JMP_RM64, .mode = 0 } },
        .count = 6, .branch_count = 2, .branches = { 0, 3 },
    };
    const uint32_t block_first[] = { 0, 1, 2, 3, 4, 5 };
    const uint32_t pending_branches[] = { 0, 1 }, pending_goals[] = { 4, 0 };
    Tier1EmitResult emitted = { .jumps = 2 };
    tier1_emit_cfg_dispatch(&buffer, block_first, 6, pending_branches, pending_goals, 2, &emitted);
    require(buffer.records[0].form == X86_FORM_JMP_RM64 && buffer.records[3].form == X86_FORM_JMP_RM64 &&
            emitted.dispatch_copies == 2 && buffer.branch_count == 0,
            "actual dispatch pass copies through an earlier direct-jump relay");

    Tier1EmitBuffer prefixed = {
        .records = { [0] = { .move = true }, [1] = { .form = X86_FORM_JMP_REL8 },
                     [3] = { .form = X86_FORM_JMP_REL8 }, [4] = { .form = X86_FORM_JMP_RM64, .mode = 0 } },
        .count = 6, .branch_count = 2, .branches = { 1, 3 },
    };
    Tier1EmitResult prefixed_emitted = { .jumps = 2 };
    tier1_emit_cfg_dispatch(&prefixed, block_first, 6, pending_branches, pending_goals, 2, &prefixed_emitted);
    require(prefixed.records[1].form == X86_FORM_JMP_RM64 && prefixed.records[3].form == X86_FORM_JMP_REL8 &&
            prefixed_emitted.dispatch_copies == 1 && prefixed.branch_count == 1,
            "a predecessor move before the relay jump prevents the later incoming dispatch fusion");

    const uint32_t offsets[] = { 0, 1, 1, 1, 3, 4, 4 };
    uint32_t targets[] = { 4, 0, 5, 5 };
    const uint32_t node_offsets[] = { 0, 1, 2, 3, 4, 5, 6 };
    uint8_t ops[] = { IR_BR, IR_RETURN, IR_RETURN, IR_CBR, IR_BR_INDIRECT, IR_RETURN };
    Tier1CfgInput input = { .successor_offsets = offsets, .successors = targets, .block_count = 6, .edge_count = 4 };
    IrFunction function = { .block_offsets = node_offsets, .op = ops, .block_count = 6 };
    Tier1SelectPlan plan = { .function = &function };
    bool supported = true, dispatch = false;
    uint64_t work = 0;
    require(tier1_emit_region_branch_pair(&plan, &input, 3, &work, &supported) == TIER1_EMIT_OK && !supported,
            "a conditional target relaying to dispatch is outside the supported domain");
    require(tier1_emit_region_branch_dispatch(&plan, &input, 0, &work, &dispatch) == TIER1_EMIT_OK && dispatch,
            "single-successor dispatch chain is identified");
    uint8_t before_place[] = { 0, 0, 0, 0 }, after_place[] = { 0, TIER1_CFG_EDGE_SUCCESSOR, 0, 0 };
    Tier1CfgAllocation before = { .edge_placements = before_place }, after = { .edge_placements = after_place };
    const uint64_t weights[] = { 1, 1, 1, 1 };
    Tier1EmitRecolorModel model = { .edge_weights = weights };
    int64_t copies[4] = { 0, 0, 0, 0 }, total[4];
    Tier1EmitRegionScore score = { .edge_gains = copies, .total_edge_gains = total };
    require(tier1_emit_region_branch_gains(&plan, &input, &before, &after, &model, &work, &score) == TIER1_EMIT_INVALID,
            "changing successor placement into a dispatch relay is refused even without a split change");
    after_place[1] = TIER1_CFG_EDGE_EMPTY;
    after_place[0] = TIER1_CFG_EDGE_PREDECESSOR;
    require(tier1_emit_region_branch_gains(&plan, &input, &before, &after, &model, &work, &score) == TIER1_EMIT_INVALID,
            "adding predecessor moves in a dispatch relay is refused");
    before_place[0] = TIER1_CFG_EDGE_PREDECESSOR;
    after_place[0] = TIER1_CFG_EDGE_EMPTY;
    require(tier1_emit_region_branch_gains(&plan, &input, &before, &after, &model, &work, &score) == TIER1_EMIT_INVALID,
            "removing predecessor moves in a dispatch relay is refused");
    after_place[0] = TIER1_CFG_EDGE_PREDECESSOR;
    require(tier1_emit_region_branch_gains(&plan, &input, &before, &after, &model, &work, &score) == TIER1_EMIT_OK,
            "unchanged predecessor prefix presence retains the fixed control behavior");
    ops[4] = IR_BR; targets[3] = 0; work = 0; dispatch = true;
    require(tier1_emit_region_branch_dispatch(&plan, &input, 0, &work, &dispatch) == TIER1_EMIT_OK && !dispatch && work == 36,
            "single-successor cycle without indirect dispatch terminates after B charged visits");
    work = BUSTER_TIER1_RECOLOR_ACTIVE_WORK - 5; dispatch = true;
    require(tier1_emit_region_branch_dispatch(&plan, &input, 0, &work, &dispatch) == TIER1_EMIT_LIMIT && dispatch,
            "dispatch walk budget refusal leaves the result unchanged");
}

static void certificate_columns(void)
{
    const uint32_t offsets[] = { 0, 2, 2, 2 };
    const uint32_t targets[] = { 1, 2 };
    Tier1CfgInput input = { .successor_offsets = offsets, .successors = targets, .block_count = 3, .edge_count = 2 };
    int64_t blocks[3] = { 0, 0, 0 }, copies[2] = { -1, 0 }, total[2] = { 0, 0 };
    Tier1EmitRegionScore score = { .preservation_gains = blocks, .block_gains = blocks, .edge_gains = copies, .total_edge_gains = total };
    uint8_t memory[4096] __attribute__((aligned(64)));
    Arena arena = { .base = memory, .capacity = sizeof(memory) };
    uint64_t work = 0;
    uint32_t metric = 0;
    require(tier1_emit_region_certify_result(&input, &score, &arena, &work, &metric) == TIER1_REGION_PATH_LOSS && metric == 1 && arena.length == 0,
            "branch savings cannot hide a transport loss");
    copies[0] = 0; total[0] = -1; work = 0;
    require(tier1_emit_region_certify_result(&input, &score, &arena, &work, &metric) == TIER1_REGION_PATH_LOSS && metric == 2 && arena.length == 0,
            "extra branches are checked by the total certificate");
    score.total_edge_gains = NULL; work = 0;
    require(tier1_emit_region_certify_result(&input, &score, &arena, &work, &metric) == TIER1_REGION_PATH_OK && arena.length == 0,
            "null optional column retains original certificate behavior");
}

static void print_table(void)
{
    puts("fallthrough\tsplit_true\tsplit_false\ttrue_branch_records\tfalse_branch_records");
    const char* names[] = { "true", "false", "neither" };
    for (uint32_t layout = 0; layout < 3; layout += 1)
    for (unsigned split = 0; split < 4; split += 1)
    {
        uint32_t records[2];
        tier1_emit_region_branch_records(0, layout == 0 ? 1 : 2, layout == 1 ? 1 : 3,
                                         (split & 1u) != 0, (split & 2u) != 0, records);
        printf("%s\t%u\t%u\t%u\t%u\n", names[layout], split & 1u, (split >> 1) & 1u, records[0], records[1]);
    }
}
int main(void)
{
    exhaustive_records();
    transition_and_guard_checks();
    dispatch_relays();
    certificate_columns();
    fprintf(stderr, "PASS: %" PRIu64 " checks; %" PRIu64 " actual emitted paths; %" PRIu64 " old/new split transitions; 0 failures\n",
            checks, paths, transitions);
    print_table();
    return 0;
}
