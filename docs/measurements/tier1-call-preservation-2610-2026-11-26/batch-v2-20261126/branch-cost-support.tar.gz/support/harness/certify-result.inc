static Tier1EmitRegionPathStatus tier1_emit_region_certify_result(const Tier1CfgInput* input, const Tier1EmitRegionScore* score,
                                                                 Arena* scratch, uint64_t* work, uint32_t* failed_metric)
{
#if defined(BUSTER_TIER1_MEASURE_KINDS)
    const uint64_t stage_work = *work;
#endif
    Tier1EmitRegionPathStatus status = tier1_emit_region_path_gain(input, score->preservation_gains, score->edge_gains,
                                                                  scratch, BUSTER_TIER1_RECOLOR_ACTIVE_WORK, work, 0);
    uint32_t metric = status != TIER1_REGION_PATH_OK ? 1 : 0;
    if (status == TIER1_REGION_PATH_OK)
    {
        const int64_t* total_edges = score->total_edge_gains != 0 ? score->total_edge_gains : score->edge_gains;
        status = tier1_emit_region_path_gain(input, score->block_gains, total_edges,
                                             scratch, BUSTER_TIER1_RECOLOR_ACTIVE_WORK, work, 0);
        metric = status != TIER1_REGION_PATH_OK ? 2 : 0;
    }
    if (failed_metric != 0)
    {
        *failed_metric = metric;
    }
#if defined(BUSTER_TIER1_MEASURE_KINDS)
    tier1_emit_region_measure_work(BUSTER_TIER1_REGION_WORK_PATHS, stage_work, *work);
#endif
    return status;
}
