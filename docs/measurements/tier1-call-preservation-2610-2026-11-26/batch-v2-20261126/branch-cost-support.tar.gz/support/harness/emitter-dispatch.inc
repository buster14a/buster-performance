static void tier1_emit_cfg_dispatch(Tier1EmitBuffer* buffer, const uint32_t* block_first, uint32_t blocks, const uint32_t* pending_branches, const uint32_t* pending_goals, uint32_t pending,
                                    Tier1EmitResult* emitted)
{
    uint32_t copies = 0;
    for (uint32_t k = 0; k < pending; k += 1)
    {
        const uint32_t goal = pending_goals[k];
        const uint32_t branch = pending_branches[k];
        const uint32_t record = buffer->branches[branch];
        const uint32_t first = (goal & BUSTER_TIER1_EMIT_CFG_STUB) == 0 && goal < blocks ? block_first[goal] : UINT32_MAX;
        const bool dispatch = first < buffer->count && buffer->records[record].form == X86_FORM_JMP_REL8 && buffer->records[first].form == X86_FORM_JMP_RM64 &&
                              buffer->records[first].mode == 0;
        if (dispatch)
        {
            buffer->records[record] = buffer->records[first];
            buffer->targets[branch] = UINT32_MAX;
            copies += 1;
        }
    }
    uint32_t kept = 0;
    for (uint32_t b = 0; copies != 0 && b < buffer->branch_count; b += 1)
    {
        if (buffer->targets[b] != UINT32_MAX)
        {
            buffer->branches[kept] = buffer->branches[b];
            buffer->targets[kept] = buffer->targets[b];
            kept += 1;
        }
    }
    buffer->branch_count = copies != 0 ? kept : buffer->branch_count;
    emitted->jumps -= copies;
    emitted->dispatch_copies += copies;
}
