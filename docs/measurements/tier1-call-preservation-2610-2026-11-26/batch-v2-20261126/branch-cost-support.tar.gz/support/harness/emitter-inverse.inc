static uint16_t tier1_emit_cfg_inverse(uint16_t form)
{
    static const uint16_t pairs[][2] = {
        { X86_FORM_JE_REL8, X86_FORM_JNE_REL8 },
        { X86_FORM_JL_REL8, X86_FORM_JGE_REL8 },
        { X86_FORM_JLE_REL8, X86_FORM_JG_REL8 },
        { X86_FORM_JB_REL8, X86_FORM_JAE_REL8 },
        { X86_FORM_JBE_REL8, X86_FORM_JA_REL8 },
    };
    uint16_t inverse = X86_FORM_NONE;
    for (uint32_t p = 0; p < BUSTER_ARRAY_LENGTH(pairs); p += 1)
    {
        inverse = pairs[p][0] == form ? pairs[p][1] : pairs[p][1] == form ? pairs[p][0] : inverse;
    }
    return inverse;
}
