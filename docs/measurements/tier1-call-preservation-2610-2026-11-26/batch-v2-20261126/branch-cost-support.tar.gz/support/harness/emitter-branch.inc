static Tier1EmitError tier1_emit_cfg_branch(Tier1EmitResult* emitted, uint32_t b, uint32_t e_true, uint16_t condition, Tier1EmitBuffer* buffer, uint32_t* stub_first, uint32_t* pending_branches, uint32_t* pending_goals, uint32_t* pending)
{
    const Tier1CfgInput* input = &emitted->cfg_input;
    const Tier1CfgAllocation* cfg = &emitted->cfg;
    const uint32_t e_false = e_true + 1;
    const uint32_t t = input->successors[e_true];
    const uint32_t f = input->successors[e_false];
    const bool split_true = cfg->edge_placements[e_true] == TIER1_CFG_EDGE_SPLIT;
    const bool split_false = cfg->edge_placements[e_false] == TIER1_CFG_EDGE_SPLIT;
    const uint16_t inverse = tier1_emit_cfg_inverse(condition);
    // With two stubs, put the next block's stub last, so its moves fall into that block. A lone stub stays inline
    // after the conditional jump; without stubs, the next block is the fall-through successor.
    const bool reverse = (!split_true && !split_false && t == b + 1) || (split_true && (!split_false || f == b + 1));
    const uint32_t taken_edge = reverse ? e_false : e_true;
    const uint32_t inline_edge = reverse ? e_true : e_false;
    const uint32_t taken_block = reverse ? f : t;
    const uint32_t inline_block = reverse ? t : f;
    const bool taken_split = reverse ? split_false : split_true;
    const bool inline_split = reverse ? split_true : split_false;
    Tier1EmitError error = inverse != X86_FORM_NONE ? TIER1_EMIT_OK : TIER1_EMIT_INVALID;
    if (error == TIER1_EMIT_OK)
    {
        error = tier1_emit_cfg_jump(buffer, reverse ? inverse : condition, taken_split ? BUSTER_TIER1_EMIT_CFG_STUB | taken_edge : taken_block, pending_branches, pending_goals, pending, emitted);
    }
    if (error == TIER1_EMIT_OK && inline_split)
    {
        stub_first[inline_edge] = buffer->count;
        emitted->edge_stubs += 1;
        error = tier1_emit_cfg_moves(emitted, inline_edge, buffer);
    }
    if (error == TIER1_EMIT_OK && (inline_block != b + 1 || taken_split))
    {
        error = tier1_emit_cfg_jump(buffer, X86_FORM_JMP_REL8, inline_block, pending_branches, pending_goals, pending, emitted);
    }
    if (error == TIER1_EMIT_OK && taken_split)
    {
        stub_first[taken_edge] = buffer->count;
        emitted->edge_stubs += 1;
        error = tier1_emit_cfg_moves(emitted, taken_edge, buffer);
        if (error == TIER1_EMIT_OK && taken_block != b + 1)
        {
            error = tier1_emit_cfg_jump(buffer, X86_FORM_JMP_REL8, taken_block, pending_branches, pending_goals, pending, emitted);
        }
    }
    return error;
}
