static bool tier1_emit_region_score_control(const Tier1SelectPlan* plan, const Tier1CfgInput* input,
                                            uint32_t edge, uint8_t old_place, uint8_t new_place)
{
    const IrFunction* function = plan->function;
    const uint32_t added = input->block_count - function->block_count;
    bool ok = (old_place == TIER1_CFG_EDGE_SPLIT) == (new_place == TIER1_CFG_EDGE_SPLIT);
    const uint32_t target = input->successors[edge];
    if (ok && target >= added)
    {
        const uint32_t block = target - added;
        const uint32_t first = function->block_offsets[block];
        const uint32_t end = function->block_offsets[block + 1];
        const bool indirect = first < end && function->op[end - 1] == IR_BR_INDIRECT;
        ok = !indirect || (old_place == TIER1_CFG_EDGE_SUCCESSOR) == (new_place == TIER1_CFG_EDGE_SUCCESSOR);
    }
    return ok;
}
