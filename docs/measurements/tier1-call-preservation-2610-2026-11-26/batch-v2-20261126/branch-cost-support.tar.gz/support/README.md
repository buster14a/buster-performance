# Optional conditional-branch pricing for the #2610 batch probe

This archive preserves a focused follow-up proposal and its standalone
validation. It is not part of the measured batch-v2 source. The parent agent
subsequently applied the proposal to a new local candidate; that candidate's
builds and workload results are outside this archive.

The new mode is enabled only when both bit 2048 and
`BUSTER_TIER1_BATCH_BRANCH_COST=1` are supplied. Existing bit 1024 uses the
unchanged scoring entry point with the optional control mode disabled.
A null `total_edge_gains` retains the original path-certificate behavior.

## Exact conditional-edge cost

The compact helper follows the orientation chosen by
`tier1_emit_cfg_branch`. Both semantic paths execute one Jcc. The inlined
path then executes one JMP exactly when its target is not the next layout
block, or when the taken path has a stub. The taken path executes a JMP only
when it has a stub and its target is not the next layout block.

The counts below exclude comparisons and edge copies, which are handled by
their existing categories. They include the common Jcc.

| Fallthrough | True split | False split | True-path branch records | False-path branch records |
| --- | ---: | ---: | ---: | ---: |
| True | 0 | 0 | 1 | 1 |
| True | 1 | 0 | 1 | 1 |
| True | 0 | 1 | 1 | 2 |
| True | 1 | 1 | 1 | 2 |
| False | 0 | 0 | 1 | 1 |
| False | 1 | 0 | 2 | 1 |
| False | 0 | 1 | 1 | 1 |
| False | 1 | 1 | 2 | 1 |
| Neither | 0 | 0 | 1 | 2 |
| Neither | 1 | 0 | 2 | 1 |
| Neither | 0 | 1 | 1 | 2 |
| Neither | 1 | 1 | 2 | 2 |

Changing one split flag can change both semantic edges' costs. For example,
when neither successor is the layout fallthrough, adding only a true-edge
split changes the pair from (1, 2) to (2, 1). Charging only the changed edge
would miss the false edge's saving; removing that split would miss its cost.

## Patch behavior and invariants

`conditional-branch-cost.patch` modifies three existing files and adds
`tier1_emit_region_branch_cost.c`:

- The original score entry point forwards with conditional control disabled.
  Only the batch probe calls the optional implementation.
- Opt-in batches retain complete displaced-owner closure, but do not
  automatically enlarge the range to eliminate every new split edge. The
  completed candidate is still materialized, epoch-scored and certified.
- The opt-in scorer requires a complete materialized edge view and validates
  each changed source pair together.
- `edge_gains` remains copy-only. The transport certificate still uses C/R
  gains plus copy-only edge gains. `total_edge_gains` adds the branch deltas
  and is used only by the total-instruction certificate.
- The opt-in baseline replaces the old fixed split offset with actual
  conditional-pair branch costs for eligible pairs. Weighted changes price
  both edges using their own existing CFG weights.
- Optional column storage, initialization, structural control visits and
  dispatch-chain walks are charged to the existing work allowance.
- Source-side indirect split changes are refused. The existing
  indirect-successor placement guard is retained and strengthened for relay
  chains in the opt-in mode.
- The trace adds `branch_cost=0/1` so evidence can distinguish the modes.

### Indirect-dispatch relays need a broader guard

Checking only whether the immediate target terminates in IR_BR_INDIRECT is
insufficient. The existing `tier1_emit_cfg_dispatch` pass can first turn an
earlier direct-jump block into an indirect-jump copy, and then copy that new
first record into a later jump targeting the relay.

The focused harness reproduces this with exact extracted dispatch code:
block 0 jumps to indirect block 4, and a later block 3 jumps to block 0.
The pass creates two indirect copies. Thus a conditional orientation change
can change executed records outside the source block even when its immediate
target's IR terminator is a direct branch.

The proposal conservatively treats every single-successor chain reaching an
IR_BR_INDIRECT terminator as dispatch-sensitive. It ignores intervening body
records, so it can reject safe cases, but cannot admit a relay by assuming its
body blocks fusion. A walk visits at most B blocks and charges before each
visit. A repeated deterministic chain without an indirect terminator is a
cycle and cannot acquire an indirect first record from this pass.

A changed conditional pair is refused when either successor is
dispatch-sensitive. A changed SUCCESSOR placement into a dispatch-sensitive
chain is also refused, even if no split bit changes. This protects a relay's
first-record fusion state.

A PREDECESSOR-presence change on an edge whose source is dispatch-sensitive
is refused as well. In the same relay example, adding a predecessor move
before block 0's JMP removes the first indirect-copy record and prevents the
later block 3 jump from fusing. The harness checks that inserting or removing
this prefix is refused while unchanged predecessor presence is accepted.
This case changes no split flag and was not covered by the measured strict
guard's immediate-target SUCCESSOR check.

## Validation performed

The standalone C harness compiles extracted, unmodified implementations of:

- `tier1_emit_cfg_inverse`
- `tier1_emit_cfg_branch`
- `tier1_emit_cfg_dispatch`
- the original strict control guard
- `tier1_emit_region_path_gain`

Its small capture adapters replace record storage and edge-move emission.
They do not rewrite branch orientation. The harness interprets the emitted
record paths, checks the semantic destination and each stub's move ownership,
and compares the observed branch count with the proposed helper.

Result: **3,718,338 checks, 502,048 interpreted emitted-record paths,
48 old/new split transitions, zero failures.**

Coverage includes all ten supported Jcc forms, all four split combinations,
true/false/neither fallthrough, distinct self/back/forward targets, zero through
three move records per stub, both semantic outcomes, weighted sibling deltas,
direct and relayed dispatch refusals, cyclic relay termination, budget
refusal, and the two separate path-certificate columns. Explicit certificate
fixtures establish that a branch saving cannot hide a transport regression
and that the total certificate rejects an extra branch.

The complete modified score file also passes a GCC syntax-only check against
a minimal declaration seam. The patch passes `git apply --check` against its
captured originals. No full compiler build, workload capture or hardware run
was performed for this proposal. Integration still needs the normal emitter
tests and a measured candidate run; the harness establishes the local control
mapping and the stated refusals, not complete compiler qualification.

## Reproduce

From this directory:

```sh
gcc -O2 -Wall -Wextra -Werror -mavx512f -mavx512vl -mavx512dq \
  harness/branch-cost-check.c -o harness/branch-cost-check
./harness/branch-cost-check > branch-cost-table.tsv 2> harness/validation.txt
gcc -fsyntax-only -Wall -Wextra -Werror -Wno-unused-function \
  -mavx512f -mavx512vl -mavx512dq harness/score-syntax.c
git apply --check --directory=original conditional-branch-cost.patch
```

The AVX-512 flags are needed only because the unchanged path-certificate
implementation uses those intrinsics. The branch-cost mapping itself uses
ordinary scalar C.

## Source and attribution

The source checkout was
`/workspace/scratch/eeeceb19ae05/buster-current-measurement`. Its HEAD identity
is in source-commit.txt, and its observed source-file digests are in
source-files.sha256. The three modified-file originals match commit
`62b736730c3f64acef9164e2a74cb43023d8c571`, which contains the bit-2048 prototype
with the activation-mask and endpoint-charge fixes. The active worktree may
contain other concurrent work, so the observed file hashes and exact emitter
extractions are retained independently. Original and proposed snapshots are
retained here. They describe this focused proposal, not a snapshot of the
parent's later combined candidate. The branch helper includes the subsequent
PREDECESSOR-presence relay guard; the measured batch-v2 source contains neither
this helper nor the opt-in branch-cost mode.

The emitter excerpts and path implementation are from buster14a/buster under
Apache-2.0 WITH LLVM-exception. Their original contents are preserved.
The helper, focused harness and documentation are original project work under
the same existing terms. The project license is retained in LICENSE.
There is no imported external implementation.

Agent session: 6b086a82-e9b8-83eb-aad4-587684d3a052 (OpenAI session ID; no share URL is exposed)
Model: OpenAI / GPT-6 Astra Pro
