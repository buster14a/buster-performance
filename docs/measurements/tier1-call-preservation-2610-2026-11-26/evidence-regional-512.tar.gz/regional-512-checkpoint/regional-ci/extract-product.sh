#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Select only the compiler and identity receipts from the hosted measurement product.
set -euo pipefail
task=/workspace/scratch/f0b04b7641b0
zip=${1:?downloaded artifact ZIP required}
expected_zip=${2:?artifact ZIP SHA256 required}
expected_tar=${3:?producer product-tar SHA256 required}
stage=/tmp/buster-2610-regional-download
out=$task/regional-ci
mkdir -p "$stage"
if [ -e "$out/product" ]; then
    printf 'Refusing to replace an extracted regional product.\n' >&2
    exit 1
fi
printf '%s  %s\n' "$expected_zip" "$zip" | sha256sum --check --strict > "$out/artifact-zip-check.txt"
sha256sum "$zip" > "$out/artifact-zip.sha256"
stat -c '%s' "$zip" > "$out/artifact-zip.bytes"
unzip -Z1 "$zip" > "$out/zip-members.txt"
printf 'product.tar.zst\n' | cmp - "$out/zip-members.txt"
unzip -p "$zip" product.tar.zst > "$stage/product.tar.zst"
sha256sum "$stage/product.tar.zst" > "$out/product-tar.sha256"
printf '%s  %s\n' "$expected_tar" "$stage/product.tar.zst" | sha256sum --check --strict > "$out/product-tar-check.txt"
tar --zstd -tvf "$stage/product.tar.zst" > "$out/tar-listing.txt"
tar --zstd -tf "$stage/product.tar.zst" > "$out/tar-members.txt"
if rg -v '^[-d]' "$out/tar-listing.txt" || rg -v '^product(/|$)' "$out/tar-members.txt" || rg '(^|/)\.\.(/|$)' "$out/tar-members.txt"; then
    printf 'Product archive contains an unsupported entry.\n' >&2
    exit 1
fi
tar --zstd -xf "$stage/product.tar.zst" -C "$out" --no-same-owner \
    product/bin/compiler product/compile_commands.json product/files.sha256 product/identity product/provenance
cd "$out/product"
test -x bin/compiler
test -s identity/summary
sha256sum --ignore-missing --check --strict files.sha256 > "$out/selected-files-check.txt"
sha256sum bin/compiler > "$out/compiler.sha256"
printf 'Selected extraction only: compiler, compile commands, complete identity/provenance, full upstream manifest.\n' > "$out/extraction.txt"
printf 'The unextracted clang-server and preprocessor oracle are not needed for these program builds.\n' >> "$out/extraction.txt"
printf 'Artifact ZIP verified against GitHub digest; every selected file verified against files.sha256.\n' >> "$out/extraction.txt"
# Identity matching against the exact source-proof.json remains a separate mandatory gate before invocation.
rm -- "$zip" "$stage/product.tar.zst"
printf 'Removed only the verified staging ZIP and tar; retained all checksum and provenance receipts.\n' >> "$out/extraction.txt"
