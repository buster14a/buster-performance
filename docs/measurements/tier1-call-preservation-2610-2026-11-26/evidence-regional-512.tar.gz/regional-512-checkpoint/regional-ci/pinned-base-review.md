# Pinned measurement base review

The temporary draft measurement PR 3639 was retargeted to `codex/2610-measurement-base`, fixed at `74eacd4744a8131ba4c1a5bd8ad87b89ec0f7dbe`. This is the same actual main parent used by the prior weighted compiler, whose masks 0 and 128 reproduced the original full program ELFs and origin sidecars. The purpose is a controlled measurement of the new policy without combining unrelated later main changes or resolving their conflicts during the experiment.

The exact pinned-base workflow was read through the GitHub connector before retargeting. Its `.github/workflows/9700x.yml` blob is `2a6761880e7b202ef9220f3b710b8b585dbf91a1`. The `pull_request` trigger has no branch or path filter and lists `opened`, `reopened`, `synchronize`, `ready_for_review`, and `converted_to_draft`. It does not list `edited`, so a retarget alone need not start the workflow. The subsequent head update supplies the listed `synchronize` event. The separate `merge_group` trigger is restricted to `main`; that restriction does not apply to `pull_request`.

The changes job checks out `github.sha` with its parents and compares `HEAD^1..HEAD`, reading the actual first parent's workflow. Hosted test jobs also check out `github.sha`. Therefore the product source is GitHub's actual test merge, not the branch head in isolation. The declared hardware job rejects draft PRs and requires successful evidence with `hardware=admit`; the exact pinned-base CI guide also states that draft and ready PRs both receive hosted feedback and never queue hardware. No workflow edit or workflow dispatch was used.

Sources:

- https://github.com/buster14a/buster/blob/74eacd4744a8131ba4c1a5bd8ad87b89ec0f7dbe/.github/workflows/9700x.yml
- https://github.com/buster14a/buster/blob/74eacd4744a8131ba4c1a5bd8ad87b89ec0f7dbe/.github/workflows/hosted-correctness.yml
- https://github.com/buster14a/buster/blob/74eacd4744a8131ba4c1a5bd8ad87b89ec0f7dbe/docs/commands/ci.md
- https://api.github.com/repos/buster14a/buster/compare/8e4d32879e17b7d9548cad54257a2f8461328366...74eacd4744a8131ba4c1a5bd8ad87b89ec0f7dbe

The compare response contains 17 commits and no workflow changes. It does contain checker/Tier 0 updates, CI cost data, documentation, and nightly-coordinator changes. These are already present in the prior weighted test merge. The new source proof records the exact new merge and verifies all 13 staged compiler files by Git blob identity and the local SHA256 manifest.

This hosted run qualifies the frozen measurement pair. It does not establish compatibility with the latest main or satisfy main's separate merge-queue contract. Corpus masks 0 and 256 must still match their previous complete SQLite/Lua ELFs and origin sidecars before mask 512 is handed to dynamic measurement.
