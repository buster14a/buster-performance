# Prepared bit 512 regional-preservation corpus protocol

**Prepared scripts only. No regional compiler or corpus build has run.** The
expected hosted compiler path is `regional-ci/product/bin/compiler`. Its actual
source head, merge parents/tree, product manifest, workflow/artifact and compiler
digest must be recorded when the artifact becomes available.

From `/workspace/scratch/f0b04b7641b0`, `bash regional-artifacts/run-corpus.sh`
runs masks **0, 256, 512** sequentially, with one compile lane per invocation.
Each program build refuses to overwrite an existing executable and creates a
fresh origin sidecar. Both control builds must pass before 512 is reached:

- **0:** complete SQLite/Lua ELF parity with `baseline-artifacts`, and exact
  origin sidecars with `experiment-artifacts/0`.
- **256:** complete SQLite/Lua ELF and sidecar parity with the immutable
  `weighted-artifacts/256` programs.

All source paths, source order, defines and compiler/linker flags are inherited
from the completed weighted protocol. SQLite uses the same
`baseline-artifacts/speedtest1-unity.c` source path. Lua remains 5.4.8 with the
same 33 translation units and source-supported `-Dluai_makeseed(L)=0` override.
The resource directory is the pinned Clang 23.1.4 installation. The scripts retain
`--tier1 --lanes 1`, `-fno-asynchronous-unwind-tables`, and the complete existing
SQLite/Lua defines and libraries.

For every mask, the required native/compiler gates are unchanged:

- Six frame-fixture functions compiled and code-certified, zero uncertified or
  fallback/internal/resource failures, and native output equal to the Clang oracle.
- SQLite 2709/2709 functions compiled, with no fallback/internal/resource failures.
- Lua 1086/1087 functions compiled, with only the original
  `luaD_rawrunprotected` unsupported-lowering fallback.
- SQLite native verification hash
  `1248168 a7fa3957840af6d608d53fcdd57a125b35385b9d1e813739`.
- All five frozen Lua outputs exactly equal their original Clang-O0 oracles.

Candidate 512 additionally captures SQLite and Lua CFG dumps at the existing
minimum-block threshold 300. The SQLite invocation sets
`BUSTER_TIER1_EXCHANGE_TRACE=26310`, targeting the existing yy_reduce instruction
count. Inherited dump/tag/trace settings are cleared before the script runs.

`validate-mask512.sh` preserves the weighted protocol's additional gates: the
full emitter suite, followed by SQLite `--tier1 --verify` with 2709 functions,
2351 code-certified / 74 uncertified, zero fallback/internal/resource failures,
and exact measured/verified ELF plus sidecar parity. Its source-tree working
directory can be supplied through `BUSTER_2610_SOURCE_TREE`; it defaults to the
same existing fixture tree used previously. This helper is called after corpus
correctness by `run-corpus.sh`.

No script launches Callgrind or any hardware/timing benchmark. Allocation-design
will capture SQLite and arithmetic first, using its stable-path driver and
immediate raw archival. The other Lua dynamic workloads remain contingent on
primary-target success or a specifically identified remaining question. The
five Lua native correctness oracles above run for every built variant.

`prepared-scripts.sha256` identifies these prepared scripts. `protocol-source.sha256`
identifies the frozen scripts from which they were adapted and their input
manifest/source/oracle references. `syntax-check.txt` records `bash -n` only;
it is not a build or correctness result. The existing static-feasibility archive
remains immutable at SHA256
`c1fbc089ab2bb079783b0441f4c69aa411b8067f8d96156a2b5c92fe19b1ca85`.
