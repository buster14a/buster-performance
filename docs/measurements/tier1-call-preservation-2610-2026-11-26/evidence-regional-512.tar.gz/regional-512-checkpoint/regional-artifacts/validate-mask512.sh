#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
set -euo pipefail
unset BUSTER_TIER1_DUMP_BLOCKS BUSTER_TIER1_DUMP_FILE BUSTER_TIER1_KINDS BUSTER_TIER1_EXCHANGE_TRACE
task=/workspace/scratch/f0b04b7641b0
export PATH=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
compiler=$task/regional-ci/product/bin/compiler
if [ ! -x "$compiler" ]; then
    printf 'Required hosted regional compiler is unavailable: %s\n' "$compiler" >&2
    exit 1
fi
inputs=$task/buster/build/2610-inputs
resource=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/lib/clang/23/include
cd "${BUSTER_2610_SOURCE_TREE:-$task/buster-tags}"
BUSTER_TIER1_EXPERIMENT=512 "$compiler" test-tier1-emit > "$task/regional-artifacts/512/test-tier1-emit.log" 2>&1
printf 'Mask512 full test-tier1-emit passed.\n'
cd "$task"
for mask in 512; do
    out=$task/regional-artifacts/$mask
    if [ -e "$out/speedtest1-verified" ]; then
        printf 'Refusing to overwrite previous verified executable: %s\n' "$out" >&2
        exit 1
    fi
    rm -f "$out/speedtest1-verified.kinds"
    BUSTER_TIER1_EXPERIMENT=$mask BUSTER_TIER1_KINDS="$out/speedtest1-verified.kinds" "$compiler" --tier1 --lanes 1 -isystem "$resource" -fno-asynchronous-unwind-tables --tier1-report --verify -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$inputs/sqlite" "-I$inputs" -o "$out/speedtest1-verified" "$task/baseline-artifacts/speedtest1-unity.c" -lm > "$out/st-verified-build.txt" 2>&1
    awk -F '\t' '$1 == "tier1" { for (i = 2; i <= NF; i++) { split($i, pair, "="); fields[pair[1]] = pair[2] } found = 1; good = fields["compiled"] == 2709 && fields["code_certified"] == 2351 && fields["code_uncertified"] == 74 && fields["fallbacks"] == 0 && fields["internal_failures"] == 0 && fields["resource_failures"] == 0 } END { exit !(found && good) }' "$out/st-verified-build.txt"
    sha256sum "$out/speedtest1" "$out/speedtest1-verified" "$out/speedtest1.kinds" "$out/speedtest1-verified.kinds" > "$out/verified-parity.sha256"
    cmp "$out/speedtest1" "$out/speedtest1-verified"
    cmp "$out/speedtest1.kinds" "$out/speedtest1-verified.kinds"
    printf 'Mask%s SQLite --verify: whole-ELF and origin-sidecar parity exact.\n' "$mask"
done
