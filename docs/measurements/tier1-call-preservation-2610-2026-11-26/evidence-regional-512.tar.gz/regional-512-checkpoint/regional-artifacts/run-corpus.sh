#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Run only after the hosted compiler's identity/manifest is verified. Each compile is one lane and sequential.
set -euo pipefail
cd /workspace/scratch/f0b04b7641b0
for mask in 0 256 512; do
    bash regional-artifacts/build-variant.sh "$mask" > "regional-artifacts/mask-$mask.log" 2>&1
done
bash regional-artifacts/validate-mask512.sh > regional-artifacts/validation-512.log 2>&1
