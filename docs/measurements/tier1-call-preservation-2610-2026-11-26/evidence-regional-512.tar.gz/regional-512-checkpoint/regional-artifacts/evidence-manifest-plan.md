# Regional preservation evidence manifest plan

This is a preparation inventory, not an acceptance report. No mask-512 corpus result or performance conclusion is asserted until the hosted product and its controls have passed.

## Exact source and hosted product

- `regional-stage/source.sha256` and the 13 staged compiler sources, including the frozen final work-charge policy.
- `regional-stage/checker-syntax.log`, the syntax command/provenance owned by root, and exact head commit/tree.
- `regional-ci/source-proof.json`, remote/local Git blob lists and SHA256 verification receipt: actual test merge, both parents, actual tree, PR, pinned base, and workflow run.
- `regional-ci/pinned-base-review.md`: event/filter review and the limit of this historical-base experiment.
- Product identity, configuration, source/compile flags, host/toolchain provenance and `files.sha256`; download artifact id/name/size/digest, local ZIP hash, product/compiler hash, and extraction/checksum receipt. Generated executables are excluded from the compact packet.

## Focused correctness and structural feasibility

- `regional-2610-evidence.tar.gz`, immutable SHA256 `c6bbff1752602b411036560ea6487146b660653d4dc1f0990766e7cd679e11b8` (90,735 bytes), from allocation_design: actual transform, exact cost/model and policy sources, generic/native/policy/budget/cold-tie fixtures, exact build command, mutation/resource checks, and final run log. The final reported counts are 195 generic checks plus 202 native/policy checks, all passing. Its README and separate manifests distinguish the earlier qualified policy `c068c3a7...` from the final hosted policy `a4394978...` and its actual final build/run. The archive is the authority for the detailed scope.
- `regional-path-evidence.tar.gz`, immutable SHA256 `0643d9f03ea00999e343ce6df962dc88ad17125b5f2255d40736e6d7d58347ef`: standalone actual-source call-path proof fixtures, 254 checks with zero failures. This guard applies only to exact estimated total-instruction ties.
- `regional-feasibility-evidence.tar.gz`, immutable SHA256 `c1fbc089ab2bb079783b0441f4c69aa411b8067f8d96156a2b5c92fe19b1ca85`: occupancy/matching analysis of the original yy_reduce CFG and exact aggregate rotor edge-flow identity. The dump exposes 301 result-producing call positions, not all 617 calls; per-site matching is an optimistic bound, not a simultaneous whole-function assignment or certificate.
- Retain the earlier exact epoch and Q32 frequency proof receipts that this model depends on, with their source hashes. Uniform successor probabilities remain a heuristic.

## Corpus protocol and correctness

- Frozen input/version/license manifest and all exact commands; fixed Lua hash seed and one compiler lane.
- `build-variant.sh`, `run-corpus.sh`, `validate-mask512.sh`, their hashes, and protocol-source hash checks.
- Mask 0: entire SQLite/Lua ELF and origin-sidecar equality with original controls.
- Mask 256: entire SQLite/Lua ELF and origin-sidecar equality with the previous weighted experiment.
- Mask 512: six frame functions certified with native oracle output; unchanged SQLite 2709 and Lua 1086/1087 coverage, with only the original Lua fallback; SQLite verification hash and all five Lua native oracles.
- Full mask-512 emitter test, SQLite `--verify` report, and exact verified/unverified ELF and sidecar equality.
- Compiler reports, origin sidecars, native stdout/stderr, all hashes and parity receipts. Retain compact selected yy_reduce trace/CFG/disassembly excerpts; exclude huge full dumps and program binaries from the compact packet.

## Dynamic instruction evidence

Allocation_design owns the stable-path captures, exact executable mapping, instruction-origin joins and audits. Start with SQLite and arithmetic; run the remaining Lua workloads only after the primary target passes or to answer a specific authorized remaining question. Preserve every new raw Callgrind capture and its stdout/stderr in the durable checkpoint immediately after each workload. Separate ordinary instruction counts, preservation C/R, argument/edge/entry traffic, origin unions, and whole-program totals so reductions in one category cannot conceal an overall regression.

Record the target yy_reduce result explicitly, even if whole-program SQLite improves. Keep old rejected candidates, fresh-baseline differences, and the earlier executor-reset/raw-loss caveat intact. The next regional checkpoint must use a new filename and retain the hashes of all prior frozen checkpoint archives.
