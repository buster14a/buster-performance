# Regional mask 512: source, control, and correctness results

## Source and compiler

The measurement head is `b3c0232157bcaaa1621216c8c599afe9a26eae13`, tree `3cfdb625a5227269ae2036c5d202db3bdcaa347e`. GitHub built test merge `ebcfa4950065c2b72b4a178cfee917a1cd2f50fa`, tree `13708a5ba2a14cb5b28b7a9fff08368bab378b3f`, with parents `74eacd4744a8131ba4c1a5bd8ad87b89ec0f7dbe` and the measurement head. All 13 staged compiler blobs match that actual merge tree. The pinned-base review and limitation are in `regional-ci/pinned-base-review.md`.

Hosted run: `45829398832`. Product artifact: `15121702942`, vector / none / O3. The downloaded ZIP is 84,815,091 bytes, SHA256 `649629599a73f8c432bba34b5ad8b889f2801ad81e4929373295dd62c4cc0bbc`. Its product tar matches the producer digest `13024ac43d9b414075b3c3a6c7d15dc7d9f34f7d02850cf3b4d3cb6abce63aa7`. Selected files all match the product manifest. The embedded revision, tree, run, repository, and configuration match the source proof.

Compiler SHA256: `dbb40417ac38cec2c9e51a3ea53572001f1ec3b0522c6aa2595c49914f182ce3`. Only the compiler, compile commands, and complete identity/provenance receipts were extracted; the checked staging ZIP and tar were removed after their hashes were recorded.

## Controls and native oracles

The unchanged scripts ran masks 0, 256, and 512 sequentially, each compiler invocation using one lane and the original frozen source flags and Lua seed.

| Gate | Result |
| --- | --- |
| Mask 0 SQLite and Lua complete ELF equality | Exact against original baseline |
| Mask 0 complete origin-sidecar equality | Exact against original mask-0 sidecars |
| Mask 256 SQLite and Lua complete ELF equality | Exact against previous weighted mask 256 |
| Mask 256 complete origin-sidecar equality | Exact against previous weighted mask 256 |
| Six frame functions, all three masks | Six compiled and code-certified; zero fallback/internal/resource failures; native output equals Clang |
| SQLite coverage, all three masks | 2709 functions compiled; zero fallback/internal/resource failures |
| Lua coverage, all three masks | 1086 compiled of 1087; only original `luaD_rawrunprotected` unsupported fallback |
| Native SQLite verification, all three masks | Original verification hash matches |
| Five native Lua workload outputs, all three masks | Every stdout equals the frozen Clang -O0 oracle; stderr empty |
| Mask 512 full emitter suite | 257194 checks, zero failures |
| Mask 512 SQLite `--verify` | 2351 code-certified, 74 code-uncertified; 2709 compiled; zero fallback/internal/resource failures |
| Mask 512 verified versus ordinary SQLite | Complete ELF and complete origin sidecar exactly equal |

SQLite verification hash:

```text
1248168 a7fa3957840af6d608d53fcdd57a125b35385b9d1e813739
```

The earlier known local full-pipeline sandbox caveat remains unchanged; that command was not retried. The full emitter suite and real frozen-corpus verification above ran successfully with this exact hosted compiler.

## Target trace: static result only

The trace was selected by the frozen yy_reduce instruction count, 26310. It records all 617 model calls and the following summary:

```text
supported=1 bounded=0 selected=31 published=1 considered=302 trials=302
endpoint_refusals=0 edge_refusals=109 work=133717101
saving=0.008928572061 preservation=0.094531258103
```

The search reached its unchanged work limit and retained the already scored prefix. Every selected interval belongs to v6 / RDI: 24 target RBX, five target RBP, and two target R14. No RSI or R9 interval was reached before exhaustion. The trace and aggregate table are `512/yy-reduce.trace` and `512/yy-reduce-selected-summary.tsv`.

The saving fields are Q32-model estimates per invocation, printed as decimal values. They are not dynamic counts or performance claims. Actual instruction measurements and exact origin joins are owned by the measurement task. This record makes no target-performance acceptance claim.

## Immutable candidate hashes

| Artifact | SHA256 |
| --- | --- |
| SQLite executable | `18a7027437a4fe2c98ea746573fc17c28d39693cfb8c12a37ebe70dcf54061b2` |
| Lua executable | `483dc969dab1b318217160b3986edaa4bcfe616999515d53abbdefa8cb806cd0` |
| SQLite origin sidecar | `d9432af2bf74939e4ab827570c8a50b971c0682da90ec60b28ae3ad4ab73ddd5` |
| Lua origin sidecar | `4278f373b10cd4259d77dcb8c436477df7584e6aca575880afc830d8297f0c3a` |

The executable files remain unchanged for capture and are excluded from compact evidence archives. Full CFG dumps are retained locally; only selected excerpts and their source hashes belong in the compact evidence packet.
