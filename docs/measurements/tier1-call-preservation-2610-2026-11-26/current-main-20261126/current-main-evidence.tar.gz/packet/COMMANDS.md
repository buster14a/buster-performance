# Executed commands and reproduction

The build, compilation, capture and emitter-test commands below are recorded
from the root agent's executed calls. Repeated absolute paths and source lists
are parameterized without changing options. The comparison and independent
native-oracle checks are separate postprocessing. No elapsed compilation time
or hardware timing is used as evidence.

## Local compiler builds

In /workspace/scratch/eeeceb19ae05/buster-current-measurement:

```sh
PATH="$PWD/../recovered/tooling/llvm-23.1.4/bin:$PWD/../toolchain/cmake-4.4.3-ninja-1.13.2/bin:$PATH" \
BUSTER_TOOLCHAIN=path BUSTER_HOST_ARCH=vector BUSTER_DEBUG_INFO=0 \
BUSTER_PARALLEL_CODEGEN=0 \
./build.sh --config Release --jobs 2 \
  > ../recovered/campaign/current-measurement-build.log 2>&1
```

The uninstrumented main build runs the same command from
/workspace/scratch/eeeceb19ae05/buster, with output redirected to
../recovered/campaign/main-build.log. Exact source pins, source-tree listings
and compiler hashes are in PROVENANCE.md and metadata/.

## Workspace and unchanged helpers

```sh
cd /workspace/scratch/eeeceb19ae05/recovered
rec="$PWD"
compiler="$rec/../buster-current-measurement/build/compiler"
resource="$rec/tooling/llvm-23.1.4/lib/clang/23/include"
scripts="$rec/inputs/lua-scripts"
measure="$rec/campaign/measure-2610"
gap="$rec/campaign/gap-2610"
valgrind="$rec/tooling/valgrind/usr/bin/valgrind"
valgrind_lib="$rec/tooling/valgrind/usr/libexec/valgrind"
```

The unchanged helpers in this packet can be rebuilt from an extracted packet:

```sh
gcc -O2 -Wall -Wextra tools/measure-2610.c -o measure-2610
gcc -O2 -Wall -Wextra tools/gap-2610.c -o gap-2610
```

The actual binary hashes are recorded in metadata/external-tools.sha256.
Those absolute paths refer to the recovery workspace; the unchanged source
digests define the reproducible helper contract.

## Workload compilation

For both SQLite and Lua, control environment and output directory are:

```sh
out="$rec/campaign/current-0"
export BUSTER_TIER1_EXPERIMENT=0
export BUSTER_TIER1_KINDS="$out/speedtest1.kinds"
unset BUSTER_TIER1_REGION_WORK BUSTER_TIER1_EXCHANGE_TRACE BUSTER_TIER1_REGION_ORDER
```

The candidate's environment and output directory are:

```sh
out="$rec/campaign/current-high"
export BUSTER_TIER1_EXPERIMENT=1024
export BUSTER_TIER1_REGION_WORK=2147483648
export BUSTER_TIER1_EXCHANGE_TRACE=26310
export BUSTER_TIER1_KINDS="$out/speedtest1.kinds"
unset BUSTER_TIER1_REGION_ORDER
```

These exports represent the command-local environment assignments in the
executed invocations; the explicit unsets make their absent settings clear for
reproduction. The candidate retains default parameter-major order.

SQLite, with the chosen environment and output directory:

```sh
BUSTER_TIER1_KINDS="$out/speedtest1.kinds" \
"$compiler" --tier1 --lanes 1 -isystem "$resource" \
  -fno-asynchronous-unwind-tables --tier1-report \
  -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 \
  -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE \
  "-I$rec/inputs/corpus/sqlite" "-I$rec/inputs" \
  -o "$out/speedtest1" "$rec/campaign/speedtest1-unity.c" -lm \
  > "$out/st-build.txt" 2>&1
```

The exact three-line unity wrapper is inputs/speedtest1-unity.c. No extra
target-ISA flags were passed. All four measurement compilations use the same
restored LLVM resource-header path.

Lua's source order is retained from the frozen campaign:

```sh
set --
for unit in lapi lcode lctype ldebug ldo ldump lfunc lgc llex lmem lobject lopcodes lparser lstate lstring ltable ltm lundump lvm lzio lauxlib lbaselib lcorolib ldblib liolib lmathlib loadlib loslib lstrlib ltablib lutf8lib linit lua; do
  set -- "$@" "$rec/inputs/lua-5.4.8/src/$unit.c"
done

BUSTER_TIER1_KINDS="$out/lua.kinds" \
"$compiler" --tier1 --lanes 1 -isystem "$resource" \
  -fno-asynchronous-unwind-tables --tier1-report \
  -std=gnu99 -DLUA_COMPAT_5_3 -DLUA_USE_LINUX '-Dluai_makeseed(L)=0' \
  -o "$out/lua" "$@" -lm -ldl \
  > "$out/lua-build.txt" 2>&1
```

The separate main control uses the same workload sources, options and resource
headers with the uninstrumented main compiler. Entire output comparisons:

```sh
cmp "$rec/campaign/main-control/speedtest1" "$rec/campaign/current-0/speedtest1"
cmp "$rec/campaign/main-control/lua" "$rec/campaign/current-0/lua"
sha256sum "$rec/campaign/main-control/speedtest1" "$rec/campaign/current-0/speedtest1"
sha256sum "$rec/campaign/main-control/lua" "$rec/campaign/current-0/lua"
```

## Captures and fixed measurement context

These commands ran sequentially from the recovered workspace:

```sh
"$measure" run "$rec/campaign/current-0" "$scripts" \
  "$valgrind" "$valgrind_lib" "$rec/campaign/current-0/raw"
"$measure" run-pair "$rec/campaign/current-high" "$scripts" \
  "$valgrind" "$valgrind_lib" "$rec/campaign/current-high/raw"
```

The first command covers all six workloads; the second covers SQLite and Lua
arithmetic. The unchanged driver sets LC_ALL=C, TZ=UTC, VALGRIND_LIB and
SQLITE_TMPDIR. It copies each variant to fixed executable paths under
/tmp/buster-2610-current and holds that directory's exclusive suite lock for
the whole invocation. It removes old measured databases and keeps database
names, temp layout, arguments and per-workload cwd fixed.

SQLite native verification runs from /tmp/buster-2610-current/sqlite-data:

```text
/tmp/buster-2610-current/speedtest1 --shrink-memory --reprepare --stats --journal wal --size 5 --heap 40000000 64 --testset mix1 --verify verify.db
```

Its counted invocation uses count.db and omits --verify. Lua invokes the shared
/tmp/buster-2610-current/lua with the named WORKLOAD.lua script from the frozen
scripts directory. Callgrind receives --tool=callgrind --dump-instr=yes,
--error-exitcode=99 and the per-workload --callgrind-out-file. The exact
workload argv also appears in compressed Callgrind stderr. Raw stdout and
stderr are compressed separately beside each raw capture.

## Disassembly, joins and summaries

For each variant, disassemble both generated programs:

```sh
objdump -d --no-show-raw-insn "$out/speedtest1" > "$out/speedtest1.dis"
objdump -d --no-show-raw-insn "$out/lua" > "$out/lua.dis"
```

For speedtest1 select program=speedtest1. For arithmetic, calls, closures,
strings and tables select program=lua. Perform this join only for workloads
actually captured in that variant:

```sh
GAP_EXECUTABLE="$out/$program" "$gap" count \
  "$out/$program.dis" "$out/$workload.cg" '???' 0x108000 \
  "$out/$program.kinds" > "$out/$workload.tsv"
"$measure" summary-file "$out/$workload.tsv" "$workload" \
  > "$out/$workload.summary.tsv" 2> "$out/$workload.audit.txt"
```

Full joins, summaries and tag-fit/origin audits are included. Large
disassemblies and uncompressed captures remain external with their hashes.
Compressed captures round-trip exactly to those originals.

For both paired workloads, compare every function and category:

```sh
control="$rec/campaign/current-0"
candidate="$rec/campaign/current-high"
"$measure" compare-functions "$control/$workload.tsv" "$candidate/$workload.tsv"
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" SLCTURehxtu
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" SLTtUu
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" CR
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" ehxTtUu
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" a
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" r
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" f
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" n
```

The origin selections are transport union, spills/reloads, call preservation,
edges, argument copies, rematerialization, frames and nodes respectively.
The union deduplicates overlapping spill and edge origin sets; argument copies
are separate. The comparison tables preserve every differing function.
positive-function-category-deltas.tsv filters positive deltas from those
tables; function-category-summary.tsv counts each delta's sign and sums it.

## Additional native-oracle checks

Both SQLite verification hashes and the control's five Lua outputs were
checked from the driver's native outputs. Candidate arithmetic is also from
run-pair. Candidate calls, closures, strings and tables were additionally run
natively, with output saved in this packet's results/current-high/native:

```sh
(cd "$scripts" && LC_ALL=C TZ=UTC "$candidate/lua" "$workload.lua") \
  > "$validation/$workload.out" 2> "$validation/$workload.err"
cmp "$validation/$workload.out" "$packet/oracles/$workload.clang0.out"
test ! -s "$validation/$workload.err"
```

The archived Clang oracle outputs are unchanged from the prior campaign.
All ten Lua stdout comparisons pass, and all stderr files are empty. The
extra four candidate workloads have no new dynamic capture in this packet.

## Targeted tokenizer comparison

The two sqlite3GetToken instruction listings in results/gettoken/ have
absolute instruction addresses and numeric target addresses removed while
retaining mnemonic, operands and symbolic target. To normalize their remaining
signed hexadecimal RIP-relative displacements, the comparison used:

```sh
sed -E 's/-?0x[0-9a-f]+\(%rip\)/RIP_DISPLACEMENT(%rip)/g' \
  results/gettoken/current-0.asm > results/gettoken/current-0.normalized.asm
sed -E 's/-?0x[0-9a-f]+\(%rip\)/RIP_DISPLACEMENT(%rip)/g' \
  results/gettoken/current-high.asm > results/gettoken/current-high.normalized.asm
cmp results/gettoken/current-0.normalized.asm results/gettoken/current-high.normalized.asm
```

Both contain 499 instructions and match after this normalization. Dynamic
instruction-type counts still differ by +28; the comparison does not erase or
explain that observed difference. The original and normalized listings are
retained together.

## Enlarged-allowance emitter regression

Executed from /workspace/scratch/eeeceb19ae05/buster-current-measurement:

```sh
BUSTER_TIER1_EXPERIMENT=1024 BUSTER_TIER1_REGION_WORK=2147483648 \
./build/compiler test-tier1-emit \
  > ../recovered/campaign/current-high-emitter.log 2>&1
```

No other environment settings were supplied in that invocation. The retained
log reports 259244 checks and zero failures. It is not a six-workload dynamic
qualification or a full-corpus emitted-code certificate.
