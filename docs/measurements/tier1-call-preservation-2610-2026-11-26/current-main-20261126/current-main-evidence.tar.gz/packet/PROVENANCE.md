# Source, artifact and input identities

This packet records the November 26, 2026 recovery session's new main-pinned
baseline and diagnostic enlarged-allowance candidate. Both compilers were built
locally from the source identities below. These generated programs are separate
from the old-source recovery packet.

## Compiler and source

- Repository: buster14a/buster, GitHub repository ID 1421805693.
- Issue: https://github.com/buster14a/buster/issues/2610.
- Measurement PR: https://github.com/buster14a/buster/pull/3639.
- Uninstrumented main:
  8cfefb2dccc92c754092cd3ce9a0eafa62c6bdca.
- Main tree: 4241118797538fffdade71a25345b7b2575137f7.
- Main compiler SHA256:
  d59afd2e48114fa6cc9bc043cfe1d5c3c3cc134e33ef9dd95febbbdbca8f57a9.
- Published measurement commit:
  98a3ce6b84e68bb91382ef9d30c152fd74f2e4cf.
- Published parents, ordered:
  8cfefb2dccc92c754092cd3ce9a0eafa62c6bdca,
  79510829fb67510fb1ac2dfe4a28a0a12a9f2912.
- Actual local measurement build commit:
  87c533f3ee942788082508854cb7355b4b193fda.
- Identical complete measurement tree for the local and published commits:
  ac3a25d98b8e1dff7977047a0b72aa7096c2e0c0.
- Measurement compiler SHA256:
  f80016e95babaca424441d4650a0b149b90433bb4ba7e5e06688d213ed3f716f.
- Both compiler builds: Release, vector host target, debug information disabled,
  parallel codegen disabled, pinned Clang 23.1.4, two build jobs.

Complete tracked source-tree listings, local commit identities, CMake caches,
compile command databases and build logs are under metadata/. The published
commit was checked with the GitHub API. The unchanged measurement helper source
and actual helper binary digests are retained separately.

The paired programs are built by the same measurement compiler with policies
0 and 1024. The candidate sets BUSTER_TIER1_REGION_WORK=2147483648 and
BUSTER_TIER1_EXCHANGE_TRACE=26310. Traversal order is the default parameter-major
order. The target trace selector is diagnostic-only. Full generated ELF parity
with the separately built uninstrumented main is established for policy 0.
The compiler executables and generated binaries remain external.

## Hosted validation, separate from local measurement

- Successful test run:
  https://github.com/buster14a/buster/actions/runs/45869082244.
- Run head: 98a3ce6b84e68bb91382ef9d30c152fd74f2e4cf.
- Hosted test merge: 383ba11dc497ef386e16f3ae5c3e0d1c643759e7.
- Hosted merge parents, ordered:
  74eacd4744a8131ba4c1a5bd8ad87b89ec0f7dbe,
  98a3ce6b84e68bb91382ef9d30c152fd74f2e4cf.
- Hosted merge tree: ac3a25d98b8e1dff7977047a0b72aa7096c2e0c0,
  identical to the locally measured tree.
- All twelve hosted vector candidates, static analyzer, integration
  qualification, vector row verdict and coverage record succeeded.
- Benchpress hardware job 140084410479 was skipped, with null runner name and
  null runner group. No hardware run was requested or performed in this work.

metadata/hosted-status.json retains the 39-job snapshot. It describes this
particular completed workflow, not the status of every other workflow on the
pull request. Local generated-code counts are not attributed to a hosted
compiler artifact.

## Inputs

The frozen workload inputs and native oracles are the same as the recovered
old campaign:

- Hosted input artifact: 15130172676 from run 45844778824.
- Input ZIP size: 64,082,047 bytes.
- Input ZIP SHA256:
  5bbb1ed386a4ed5fdcf294af31c06f965805b455d7fdd2ef65797186d28ce6d0.
- SQLite corpus archive:
  https://github.com/buster14a/buster-performance/releases/download/ci-corpora-preprocessor-391e729af658/preprocessor-391e729af658-ci.tar.zst.
- Corpus archive SHA256:
  ceb39bf938cd7a7469bbb53646c3318d0cbfdac4d37b6d05b183c4fd0b9898c2.
- SQLite 3.53.2 sqlite3.c SHA256:
  0a409f1633283fa31a9126b11fbfd64a1991c5d30defad07e5745d4667f5e23d.
- sqlite3.h SHA256:
  9e69a1353a4288450b0d5239ede11fc7f1f4c8e5eb07491fc8317eacb5b7de7e.
- speedtest1.c source:
  https://raw.githubusercontent.com/sqlite/sqlite/ccc132c5be20ab5c755c97a08d06b1b592fef330/test/speedtest1.c.
- speedtest1.c SHA256:
  b5eaf4bbcbb320fd8eb3f3e6c4cd5f51a64dd0cd70efe969634d1785e3419675.
- Lua source: https://www.lua.org/ftp/lua-5.4.8.tar.gz.
- Lua archive SHA256:
  4f18ddae154e793e46eeab727c59ef1c0c0c2b744e7b94219710d76f530629ae.
- Lua scripts: buster-performance commit
  818cfbbc0be238da287c16d8e2a91fd7275cf228, directory
  docs/measurements/tier1-reciprocal-141-2026-11-01/9700x/lua.
  This directory name identifies historical inputs, not execution hardware.
- Individual source/script digests: inputs/workload-inputs.sha256, relative
  to the recovered inputs root.

Both programs in both variants use the restored LLVM 23.1.4 resource headers,
whose inventory is inputs/resource-headers.sha256, relative to
tooling/llvm-23.1.4/lib/clang/23/include. The independent main control uses
the same workload source and compilation options.

## Tools and host

- Clang: 23.1.4, LLVM commit 7a941dfb2877a0b8cf30323fefa85ad019e0b0f5.
- LLVM archive SHA256:
  efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378.
- CMake: 4.4.3; Ninja: 1.13.2.
- Valgrind package:
  https://deb.debian.org/debian/pool/main/v/valgrind/valgrind_3.24.0-3_amd64.deb.
- Valgrind package SHA256:
  0359e30820ccee7ee5c8d4c951ca276e3978b18f157d71bd77981de05b344907.
  This exactly matches the package hash recorded in the prior session.
- Native/counting host: AMD EPYC 9V74, Linux 6.18.57, glibc 2.41.
- Disassembler: GNU objdump 2.44.
- C helpers built with GCC 14.2.0, restored unchanged from the preceding
  weighted archive:
  - measure-2610.c SHA256:
    61af44ef005df0d31bc4ad68ad0d00ab68965f9f68c7e51548433717304d4ab9.
  - gap-2610.c SHA256:
    73763316ae4d87024397fb207b6a8d3ce69d93c1c3bab65c80eb217e0721e76b.

Original instruction-origin tagging was adapted from buster-performance commit
ddb5213da1fce7ac9325afbf6364a797bbc63b5b,
docs/measurements/tier1-dominator-places-2553-2026-11-12/scripts/kinds-2553.patch.
The C join helper retains its original #1189/#2553 attribution and the #2610
executable-range correction. No helper implementation is changed here.

## Evidence lineage and scope

The original evidence archives were recovered from buster-performance campaign
commit 4b7481be76d5b93497a1530a3115c6ab51fae17f:

- evidence-weighted.tar.gz SHA256:
  5a166ec22fe2e4a0fd52ce3e77ad185b53cae21b64dfb23a23c85ae1236ce919.
- evidence-regional-512.tar.gz SHA256:
  9a06db88fe167ecb6604c391d5ac3b4ae5702e36a5c3ded76df4bc2984b904ee.

The old-source recapture is separately published in buster-performance commit
74348e714d6ae194e86bfb62e6f4eeaad666ba17, at the sibling recovery-20261126 path.
Its recovery-evidence.tar.gz SHA256 is
31e3d515124edfcfd06d861a88953681912ef2149b649293e98998ee39ed160c.
It is not modified by this packet.

All eight compressed Callgrind captures in this packet were generated anew:
six control workloads and two candidate workloads. Candidate calls, closures,
strings and tables have native correctness results only. The +28
sqlite3GetToken total delta is retained as observed path-count variation in
structurally unchanged code; the cause has not been established. There is no
new six-workload dynamic candidate qualification, no hardware evidence, and no
accepted production change. The primary yy_reduce target remains unmet.

Agent session: 6b086a82-e9b8-83eb-aad4-587684d3a052 (OpenAI session ID; no share URL is exposed)
Model: OpenAI / GPT-6 Astra Pro
