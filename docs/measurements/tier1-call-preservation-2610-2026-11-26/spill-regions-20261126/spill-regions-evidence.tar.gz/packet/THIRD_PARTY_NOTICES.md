# Third-party notices and adaptations

Buster's original source excerpts, the unity wrapper, and measurement
tooling retain Apache-2.0 WITH LLVM-exception; the complete Buster license
is included as licenses/Buster-LICENSE. The full source patches also
retain any component-specific terms in their existing portions. The exact
v2 LICENSING.md, THIRD_PARTY_NOTICES.md, LICENSE and complete LICENSES
directory are included under licenses/buster-v2. This packet does not
relabel mixed-source portions as wholly first-party. Existing SPDX and
source attribution comments remain in all retained C tools and excerpts.

The original measure-2610.c is the #2610 capture/accounting driver.
The gap helper retains the #1189/#2553 attribution and the #2610
executable-range correction. Origin-tagging provenance includes
buster-performance commit ddb5213da1fce7ac9325afbf6364a797bbc63b5b,
docs/measurements/tier1-dominator-places-2553-2026-11-12/scripts/kinds-2553.patch.
This session's version-2 modifications add explicit m accounting for real
interior allocation register copies; original C sources and exact diff
patches are retained beside the revised sources. The capture runner itself
is unchanged.

SQLite is in the public domain; its notice is retained at
licenses/SQLite-public-domain.txt. Lua 5.4.8 is under the MIT license,
retained in licenses/Lua-5.4.8.txt. Input URLs, exact versions and digests
appear in INPUTS_AND_TOOLS.md. Workload source trees are not redistributed
by this packet.

LLVM, Valgrind and the operating-system toolchain are external execution
dependencies, not redistributed binaries in this archive. Their source or
package identities are recorded to make the measurement environment
reconstructible. The archive contains generated measurement records,
compressed program outputs and bounded diagnostic extracts.

The additional spill-evidence-2610.c reader and spill proof fixture are
original code from this directed session under the project default terms.
The reader's external C library/toolchain use does not import their
implementation into this source packet.

