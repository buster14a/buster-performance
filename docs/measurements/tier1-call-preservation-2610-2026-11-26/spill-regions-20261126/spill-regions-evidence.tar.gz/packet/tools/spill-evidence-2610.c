// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See licenses/Buster-LICENSE.
// Original offline evidence auditor for #2610. Reads the complete joined records, independently balances each
// object's total, and reports every origin and overlapping category without treating a category shift as a saving.
// This is a bounded text/report tool, not a compiler implementation or a compiler-throughput measurement.
#define _GNU_SOURCE
#include <errno.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUSTER_EVIDENCE_FUNCTIONS 16384
#define BUSTER_EVIDENCE_BUCKETS 32768
#define BUSTER_EVIDENCE_ORIGINS 20

static const char origins[] = "SLTUCReapfrjnhxtum-_";

typedef struct EvidenceFunction EvidenceFunction;
struct EvidenceFunction
{
    char* name;
    uint64_t counts[2][BUSTER_EVIDENCE_ORIGINS];
};

typedef struct EvidenceCategory EvidenceCategory;
struct EvidenceCategory
{
    const char* name;
    const char* letters;
};

static const EvidenceCategory categories[] = {
    { "total", "*" },
    { "S", "S" }, { "L", "L" }, { "C", "C" }, { "R", "R" },
    { "e", "e" }, { "h", "h" }, { "x", "x" },
    { "T", "T" }, { "t", "t" }, { "U", "U" }, { "u", "u" },
    { "r", "r" }, { "a", "a" }, { "f", "f" }, { "p", "p" },
    { "j", "j" }, { "n", "n" }, { "m", "m" },
    { "spills_all", "SLTUtu" },
    { "calls_all", "CR" },
    { "edges_all", "ehxTtUu" },
    { "transport_all", "SLCTURehxtum" },
    { "allocation_memory", "SLCRTUtu" },
    { "interior_spills", "SL" },
    { "edge_memory", "TUtu" },
    { "edge_copies", "ehx" },
};

static uint64_t evidence_hash(const char* text)
{
    uint64_t hash = UINT64_C(14695981039346656037);
    for (const unsigned char* c = (const unsigned char*)text; *c != 0; c += 1)
    {
        hash = (hash ^ *c) * UINT64_C(1099511628211);
    }
    return hash;
}

static bool evidence_number(const char* text, uint64_t* result)
{
    char* end = NULL;
    errno = 0;
    const unsigned long long value = strtoull(text, &end, 10);
    const bool ok = text[0] >= '0' && text[0] <= '9' && errno == 0 &&
                    end != text && (*end == 0 || (*end == '\n' && end[1] == 0)) && value <= INT64_MAX;
    if (ok)
    {
        *result = (uint64_t)value;
    }
    return ok;
}

static bool evidence_read(const char* path, uint32_t side, EvidenceFunction* functions, uint32_t* function_count,
                          uint32_t* buckets, uint64_t* total, uint64_t* accounted)
{
    FILE* input = fopen(path, "r");
    bool ok = input != NULL;
    bool saw_total = false;
    bool saw_unmatched = false;
    char* line = NULL;
    size_t capacity = 0;
    uint32_t rows = 0;
    while (ok && getline(&line, &capacity, input) > 0)
    {
        rows += 1;
        ok = rows <= 1000000 && strlen(line) < 4096;
        char* field[4] = { 0 };
        char* cursor = line;
        for (uint32_t f = 0; f < 4 && cursor != NULL; f += 1)
        {
            field[f] = strsep(&cursor, "\t");
        }
        if (strcmp(field[0], "#total") == 0)
        {
            ok = ok && !saw_total && field[1] != NULL && evidence_number(field[1], total);
            saw_total = ok;
        }
        else if (strcmp(field[0], "#check") == 0 && field[1] != NULL && strcmp(field[1], "unmatched") == 0)
        {
            uint64_t unmatched = 1;
            ok = ok && !saw_unmatched && field[2] != NULL && evidence_number(field[2], &unmatched) && unmatched == 0;
            saw_unmatched = ok;
        }
        else if (field[0][0] != '#')
        {
            uint64_t value = 0;
            ok = ok && field[1] != NULL && field[1][0] != 0 && field[1][1] == 0 && field[2] != NULL &&
                 field[3] != NULL && cursor == NULL && evidence_number(field[3], &value);
            const char* origin = ok ? strchr(origins, field[1][0]) : NULL;
            ok = ok && origin != NULL;
            uint32_t slot = (uint32_t)evidence_hash(field[0]) & (BUSTER_EVIDENCE_BUCKETS - 1);
            uint32_t steps = 0;
            while (ok && buckets[slot] != 0 && strcmp(functions[buckets[slot] - 1].name, field[0]) != 0)
            {
                slot = (slot + 1) & (BUSTER_EVIDENCE_BUCKETS - 1);
                steps += 1;
                ok = steps < BUSTER_EVIDENCE_BUCKETS;
            }
            if (ok && buckets[slot] == 0)
            {
                ok = *function_count < BUSTER_EVIDENCE_FUNCTIONS;
                if (ok)
                {
                    functions[*function_count].name = strdup(field[0]);
                    ok = functions[*function_count].name != NULL;
                    buckets[slot] = ok ? ++*function_count : 0;
                }
            }
            if (ok)
            {
                const uint32_t f = buckets[slot] - 1;
                const uint32_t o = (uint32_t)(origin - origins);
                ok = o < BUSTER_EVIDENCE_ORIGINS && value <= INT64_MAX - functions[f].counts[side][o] &&
                     value <= INT64_MAX - *accounted;
                if (ok)
                {
                    functions[f].counts[side][o] += value;
                    *accounted += value;
                }
            }
        }
    }
    ok = ok && !ferror(input) && saw_total && saw_unmatched && *total == *accounted;
    free(line);
    if (input != NULL)
    {
        ok = fclose(input) == 0 && ok;
    }
    if (!ok)
    {
        fprintf(stderr, "evidence input refused: %s at row %u\n", path, rows);
    }
    return ok;
}

static uint64_t evidence_sum(const uint64_t* values, const char* letters)
{
    uint64_t total = 0;
    for (uint32_t o = 0; o < BUSTER_EVIDENCE_ORIGINS; o += 1)
    {
        total += letters[0] == '*' || strchr(letters, origins[o]) != NULL ? values[o] : 0;
    }
    return total;
}

static int evidence_order(const void* left, const void* right)
{
    return strcmp(((const EvidenceFunction*)left)->name, ((const EvidenceFunction*)right)->name);
}

int main(int argc, char** argv)
{
    bool ok = argc == 10 && strlen(origins) == BUSTER_EVIDENCE_ORIGINS;
    EvidenceFunction* functions = ok ? calloc(BUSTER_EVIDENCE_FUNCTIONS, sizeof(EvidenceFunction)) : NULL;
    uint32_t* buckets = ok ? calloc(BUSTER_EVIDENCE_BUCKETS, sizeof(uint32_t)) : NULL;
    ok = ok && functions != NULL && buckets != NULL;
    uint32_t count = 0;
    uint64_t total[2] = { 0 };
    uint64_t accounted[2] = { 0 };
    for (uint32_t side = 0; ok && side < 2; side += 1)
    {
        ok = evidence_read(argv[side + 1], side, functions, &count, buckets, total + side, accounted + side);
    }
    FILE* summary = ok ? fopen(argv[5], "a") : NULL;
    FILE* details = ok ? fopen(argv[6], "a") : NULL;
    FILE* positive = ok ? fopen(argv[7], "a") : NULL;
    FILE* outside = ok ? fopen(argv[8], "a") : NULL;
    FILE* audit = ok ? fopen(argv[9], "a") : NULL;
    ok = ok && summary != NULL && details != NULL && positive != NULL && outside != NULL && audit != NULL;
    if (ok)
    {
        if (ftell(summary) == 0)
        {
            fprintf(summary, "candidate\tworkload\tcategory\tbase\thead\tdelta\tpositive_functions\tnegative_functions\tpositive_outside_yy\tnegative_outside_yy\n");
        }
        if (ftell(details) == 0)
        {
            fprintf(details, "candidate\tworkload\tcategory\tfunction\tbase\thead\tdelta\n");
        }
        if (ftell(positive) == 0)
        {
            fprintf(positive, "candidate\tworkload\tcategory\tfunction\tbase\thead\tdelta\n");
        }
        if (ftell(outside) == 0)
        {
            fprintf(outside, "candidate\tworkload\tcategory\tfunction\tbase\thead\tdelta\n");
        }
        qsort(functions, count, sizeof(EvidenceFunction), evidence_order);
        for (uint32_t c = 0; c < sizeof(categories) / sizeof(categories[0]); c += 1)
        {
            uint64_t sums[2] = { 0 };
            uint32_t increases = 0, negative = 0, outside_positive = 0, outside_negative = 0;
            for (uint32_t f = 0; f < count; f += 1)
            {
                const uint64_t a = evidence_sum(functions[f].counts[0], categories[c].letters);
                const uint64_t b = evidence_sum(functions[f].counts[1], categories[c].letters);
                const int64_t delta = (int64_t)b - (int64_t)a;
                sums[0] += a;
                sums[1] += b;
                increases += delta > 0;
                negative += delta < 0;
                outside_positive += delta > 0 && strcmp(functions[f].name, "yy_reduce") != 0;
                outside_negative += delta < 0 && strcmp(functions[f].name, "yy_reduce") != 0;
                if (delta != 0)
                {
                    fprintf(details, "%s\t%s\t%s\t%s\t%" PRIu64 "\t%" PRIu64 "\t%" PRId64 "\n", argv[3], argv[4], categories[c].name, functions[f].name, a, b, delta);
                }
                if (delta > 0)
                {
                    fprintf(positive, "%s\t%s\t%s\t%s\t%" PRIu64 "\t%" PRIu64 "\t%" PRId64 "\n", argv[3], argv[4], categories[c].name, functions[f].name, a, b, delta);
                    if (strcmp(functions[f].name, "yy_reduce") != 0)
                    {
                        fprintf(outside, "%s\t%s\t%s\t%s\t%" PRIu64 "\t%" PRIu64 "\t%" PRId64 "\n", argv[3], argv[4], categories[c].name, functions[f].name, a, b, delta);
                    }
                }
            }
            fprintf(summary, "%s\t%s\t%s\t%" PRIu64 "\t%" PRIu64 "\t%" PRId64 "\t%u\t%u\t%u\t%u\n", argv[3], argv[4], categories[c].name,
                    sums[0], sums[1], (int64_t)sums[1] - (int64_t)sums[0], increases, negative, outside_positive, outside_negative);
        }
        fprintf(audit, "%s\t%s\tbase=%" PRIu64 "\tbase_accounted=%" PRIu64 "\thead=%" PRIu64 "\thead_accounted=%" PRIu64 "\tfunctions=%u\tPASS\n",
                argv[3], argv[4], total[0], accounted[0], total[1], accounted[1], count);
    }
    FILE* outputs[] = { summary, details, positive, outside, audit };
    for (uint32_t i = 0; i < 5; i += 1)
    {
        if (outputs[i] != NULL)
        {
            const bool written = !ferror(outputs[i]);
            ok = fclose(outputs[i]) == 0 && written && ok;
        }
    }
    for (uint32_t f = 0; f < count; f += 1)
    {
        free(functions[f].name);
    }
    free(functions);
    free(buckets);
    if (argc != 10)
    {
        fprintf(stderr, "usage: spill-evidence BASE.tsv HEAD.tsv CANDIDATE WORKLOAD SUMMARY.tsv DETAILS.tsv POSITIVE.tsv OUTSIDE.tsv AUDIT.txt\n");
    }
    return ok ? 0 : 1;
}
