# Spill-region evidence packet

Read the adjacent public README for results and acceptance qualifications.
This archive contains eight new workload records: SQLite and arithmetic
for pure spill regions; SQLite and five Lua scripts for spill regions,
call windows and parameter-row reuse. Their v1 outputs are byte-identical
to both complete v2 executable/sidecar pairs.

- `results/current-spill` and `results/current-spill-windows-rows` retain
  complete joins, sidecars, allocation dumps, compile reports, native
  outputs, per-function differences and raw Callgrind captures.
- `results/current-0` retains all six complete baseline joins and sidecars.
  Its raw captures are referenced by immutable record in `PROVENANCE.md`.
- The corresponding `-v2` directories retain qualification reports and
  hashes. They contain no newly claimed dynamic capture.
- `results/main-44cf-control` and `metadata/integration-44cf-*` retain the
  main-control refresh and earlier hosted-integration qualification.
- `validation` contains independently rerun parity, accounting, input,
  raw-capture and native-oracle checks.
- `source`, `tools`, `inputs`, `oracles` and `licenses` retain the exact
  policy/fixture excerpts, full patches, C helpers, input inventories and
  component notices needed to reconstruct the experiment.

`yy_reduce` reaches 576,735 C/R. Combined allocation memory and transport
never rise per function in the measured six workloads. Individual raw
spill and edge categories do rise outside `yy_reduce`. The configured
work cap is raised, the actual yy emitted-code certificate is unsupported
for indirect dispatch, and no 9700X execution is claimed. These limits
remain part of the result.

Verify all archived entries from this directory with
`sha256sum -c SHA256SUMS`.
