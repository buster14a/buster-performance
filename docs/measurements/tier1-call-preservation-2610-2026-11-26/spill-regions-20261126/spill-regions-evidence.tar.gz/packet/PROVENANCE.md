# Provenance

## Roles and scope

Prepared on 2026-11-26 in session
`6b086a82-e9b8-83eb-aad4-587684d3a052`, OpenAI / GPT-6 Astra Pro.
Root and the source-analysis agent produced the compiler changes, built the
frozen compiler executables, compiled the workloads, and ran native and
Callgrind captures. The regional-analysis agent independently rejoined all
fourteen control/candidate instruction captures, checked raw compression,
native oracles, source/input hashes, and complete ELF/sidecar parity, and
constructed this evidence packet. No compiler build or new dynamic capture
was performed during packet construction.

This packet is a reproducible C/R-target checkpoint for buster#2610.
Its literal individual-category gate and hardware acceptance are not
claimed. No Benchpress/9700X access or queue request occurred. Host,
toolchain and external input identities appear in `INPUTS_AND_TOOLS.md`.

## Source identities

| Stage | Commit | Complete tree |
| --- | --- | --- |
| Earlier measured window parent | `bb10db3b3aa023100f5501961be311295e1d11a6` | `fc09354951cdd06f034e96b4865327a6beb72332` |
| Actual spill v1 capture source | `39fc19ac969e5ba06809453d473e0d7aa8b09d45` | `6ff5642f9a52b51b32a22730713a8e7e2259ed2c` |
| Latest-main/ASM qualification, local v2 | `b8633fa0abb63a3b08e11746226ed39740af45ec` | `024052df8ddc3cd42ab7fd6a5c92c39a43b762b1` |
| Same v2 published on draft #3639 | `704c32b94d88ffa50960e1d807fb678ec2131f17` | `024052df8ddc3cd42ab7fd6a5c92c39a43b762b1` |
| Uninstrumented current-main refresh | `44cf35e195eb73e7306f13882ef15b2d9b301c4d` | `8f41ea6e814b906765a34f11def2dba554921070` |

The published v2 parent is
`e1077b9b30c94dabe2426848dad3a18479a2bc61`. Root verified the remote tree,
the seven written source-blob hashes and the DCO trailer by reading them
back. The packet's local v2 source identity and measured v1 identity remain
distinct from that publication identity.

The earlier local v1 name `1968d3845` was amended to correct the commit
message/sign-off record. `metadata/v1-message-only-identity.txt` records
the two identical complete trees. No code, compiler binary or measurement
was replaced by that message correction. The corrected full commit record
and message are retained separately.

`source/bb10-to-spill-v1.patch` is the complete parent-to-v1 delta.
`source/spill-v1-to-v2-main-asm.patch` is the complete v1-to-v2 delta,
including the main integration, guard and added fixture. The original v1
policy and two focused fixture sources are retained separately with their
notices. The full spill policy module has the same SHA256 in v1 and v2:
`30d76ccdddcf99b8db2e052b5acde717aa29fd58729c7c335bdfac8ada1b90ff`.

## Frozen products and parity

| Compiler | SHA256 |
| --- | --- |
| Spill v1 | `9b687fc273b8a9c69ab0dee27d890c3035a0151f839991613e6cd7d14b53f68f` |
| Spill v2 | `394f30a1985b2ea39cc752c0244566a8636d0f987c91fa242e69c5085ee8e7a9` |
| Main 44cf refresh | `3e5f72128c282d4f241e67a6497740dce4e6644cfb64aca6fabd55dde32a7dc3` |

Each results directory retains executable/disassembly or qualification
product hashes. Binaries and huge disassemblies are omitted from this
compact archive. Complete workload source is also omitted; its exact
external identities and per-file hashes are retained.

The original `current-0` executable capture is tied to uninstrumented main
`8cfefb2dccc92c754092cd3ce9a0eafa62c6bdca`. Its tagged measurement source
was local `87c533f3ee942788082508854cb7355b4b193fda`, published as
`98a3ce6b84e68bb91382ef9d30c152fd74f2e4cf`, with complete tree
`ac3a25d98b8e1dff7977047a0b72aa7096c2e0c0`. The independent main44cf
refresh reproduces both full current-0 executables. That parity reuses
existing captures; it is not a new dynamic baseline.

For both spill configurations, v2 equals v1 for both complete executables
and both complete origin sidecars. Eight full-file `cmp` operations passed
at root and independently during packet construction. Therefore the v1
dynamic records apply unchanged to those v2 outputs. No new v2 Callgrind
run is asserted.

## Earlier hosted integration

The local integration merge
`50c91bf5f7b2bb9863744cbe08ffb5374dc43c79` was published as
`e1077b9b30c94dabe2426848dad3a18479a2bc61`, both tree
`7fafc9a1db3e9bdbf9bdfae35fb5ee2f16a12bbb`. PR merge snapshot
`d969b8c8e112fe5f87c75beefeb3bbe818395f28` has the same tree.
Hosted correctness run 45886418191 succeeded (22 successful jobs,
17 skipped). Hardware job 140142438537 was skipped with no runner.
Machine-problem interchange run 45886418073 also succeeded.

The job JSON and record identify that exact earlier integration. It
predates the spill policy; these successes are not attributed to v1, v2
or the separately prepared production extraction. This packet claims only
the locally retained emitter tests and output parity for v2, plus the
separately identified completed hosted integration below.

At 20:37:45 UTC, machine-problem interchange run 45891074759 and
correctness run 45891074877 for v2 head `704c32b9` had both completed
successfully. The actual tested PR merge is
`c073a956e2a59199e679616291929399a4bb640d` into main
`4cac2430b304510610388ee3f1e33b0c6a8a3dab`. Retained excerpts report
42,840 passing checks normally and under ASan/UBSan and completion of
100,000 seeded fuzz runs. Correctness has 22 successful jobs and 17 skips;
machine-problem has five successful jobs and six skips. Correctness's four
main shards have 166 passing commands, zero failures and one duplicate
unity-ownership skip. The retained Tier 1 check counts are emitter 261009,
CFG 107509, allocation 92098, pipeline 6172, certificate 2147 and interval 17,
all with zero failures. Hardware job 140157486687 was skipped with null
runner name/ID. The eight `metadata/spill-v2-hosted-*.json` records retain
the completed runs/jobs/counts, final hardware state and earlier admission
excerpt identifying the exact tested merge. The final hardware record
supersedes the initial admission excerpt's pending-job note.

The separate uninstrumented main 4cac refresh has tree
`dbdf719e191eea41402b0a1d41ae25ac8cd34fdf` and compiler SHA256
`55164cac092ff027b0a4dba9aaf463c628a218639db023d6f27fb007a85f1562`.
Both full output ELFs match current-0. Its build log and workload commands
survive; the packet auditor independently repeated both comparisons.
This is a control refresh, not a new dynamic capture or a relabeling of
the standalone v2 source.

## Existing control raw evidence

The six original-control raw captures are retained without duplication in
performance commit `59c3f7d5c24986905c33a19f15e9595f30a88f10`, at
`docs/measurements/tier1-call-preservation-2610-2026-11-26/rows-partition-20261126`.
Its archive SHA256 is
`9f83d80ea4f79c3376e73a0b9ed7c195c2389cc848b7d44aaef173e1604d95e6`.
This packet includes all six complete control joins and both sidecars so
every published comparison can be recomputed directly.

The immediately preceding window checkpoint was published at performance
commit `018fdb66d4235aef5c3cd27b3f508ddb1bb7d93e`. The helper C sources,
their original/v2 patches, licenses, oracle files and input inventories
were copied unchanged from that packet and checked against the helpers
actually used for these captures.

The new `tools/spill-evidence-2610.c` is original offline audit code,
compiled with pinned Clang 23.1.4. It independently sums complete joined
records and reports overlapping categories explicitly. It changes no
capture, compiler or origin sidecar and makes no throughput claim.

## Build receipts

V1 used a direct CMake incremental build in the existing Release/vector/g0
build tree. V2 used the repository wrapper and reconfigured the same Clang
toolchain before building 44 units. Exact commands and the build owner's
reported successful exits appear in
`metadata/compiler-build-test-commands.txt`. Full build stdout was tool
output only; no retained full build log is claimed. All six emitter logs,
frozen binary digests, source commits and workload compile reports survive.

## Independent integrity checks

- 14 complete regenerated instruction joins are byte-identical.
- 40 new compressed raw files pass gzip checks and match their originals.
- Eight new workload outputs match the native oracles with empty native stderr.
- Eight v1/v2 complete executable/sidecar comparisons pass.
- Two current-0/main44cf complete executable comparisons pass.
- Two current-0/main4cac complete executable comparisons pass.
- 71 workload inputs and 327 LLVM resource headers match their frozen digests.
- Every joined object total balances with zero unmatched instructions.

`validation/` retains each receipt. Whole-archive extraction, per-file
SHA256 and gzip verification are recorded in the adjacent public
`archive-verification.txt` after the final packet freeze.
