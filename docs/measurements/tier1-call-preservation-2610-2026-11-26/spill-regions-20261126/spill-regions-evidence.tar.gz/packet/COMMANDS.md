# Executed commands and reproduction

The exact workload compile, native/Callgrind and join command record is
`metadata/spill-v1-workload-commands.txt`. It preserves source order,
arguments, output paths and environment switches. The complete v2
qualification compilation and eight comparison commands are in
`metadata/spill-v2-parity-commands.txt`. Main refresh commands are in
`metadata/main-44cf-control-commands.txt`. Actual compiler build/test
commands and the retained-log boundary appear in
`metadata/compiler-build-test-commands.txt`.

Both modes use `BUSTER_TIER1_EXPERIMENT=0`,
`BUSTER_TIER1_SPILL_REGIONS=1`, and
`BUSTER_TIER1_REGION_WORK=8589934592`. Pure spill mode sets windows and
rows to 0; the combined mode sets both to 1. SQLite's trace instruction
count is 26310, and its allocation dump threshold is 1900 blocks.
The recorded workload commands use `--tier1 --lanes 1 --verify` with
the pinned LLVM resource headers and unchanged SQLite/Lua definitions.

The measurement driver keeps executable and database paths fixed under
`/tmp/buster-2610-current`, locks the complete suite, runs native and
Callgrind processes to completion, and archives each capture before
exiting. Its exact child argument vectors are in
`tools/measure-2610-v2.c`. Callgrind counts use `--dump-instr=yes`;
`gap-2610-v2` restricts object `???` at load bias `0x108000` to the
executable's PT_LOAD ranges. Outside-object observations are reported,
while any unmatched inside-object count remains a failure.

## Independently executed packet audits

The packet auditor compiled only the small original evidence reader:

```sh
/workspace/scratch/eeeceb19ae05/recovered/tooling/llvm-23.1.4/bin/clang \
  -std=gnu17 -O2 -Wall -Wextra -Werror \
  tools/spill-evidence-2610.c -o ../spill-evidence-2610
```

From the recovered campaign, for each of six controls, two pure-spill
records and six combined records, the auditor reran this exact command
shape with the concrete mode/workload names:

```sh
GAP_EXECUTABLE="$campaign_root/$mode/$program" \
  "$campaign_root/gap-2610-v2" count \
  "$campaign_root/$mode/$program.dis" \
  "$campaign_root/$mode/$workload.cg" '???' 0x108000 \
  "$campaign_root/$mode/$program.kinds" > rejoined.tsv
cmp "$campaign_root/$mode/$workload.tsv" rejoined.tsv
```

Here `campaign_root` is
`/workspace/scratch/eeeceb19ae05/recovered/campaign`, `program` is
`speedtest1` for SQLite and `lua` for the Lua scripts, and `mode` is
`current-0`, `current-spill` or `current-spill-windows-rows`.
All 14 comparisons pass; `validation/rejoin-parity.txt` enumerates them.

Every new `raw/*.gz` was checked with `gzip -t`, then decompressed and
compared byte-for-byte to its uncompressed original. Native stderr was
required empty. Lua native output was compared with the corresponding
frozen `.clang0.out`; SQLite's complete `Verification Hash:` line was
compared with `oracles/sqlite-verification-hash.txt`.

For each of eight candidate/control comparisons, the auditor ran:

```sh
../spill-evidence-2610 \
  "$campaign_root/current-0/$workload.tsv" \
  "$campaign_root/$mode/$workload.tsv" "$mode" "$workload" \
  results/function-category-summary.tsv results/function-category-deltas.tsv \
  results/positive-function-category-deltas.tsv \
  results/positive-categories-outside-yy.tsv validation/join-accounting-audit.txt
```

The outputs are appended, so begin with absent or empty output files when
reproducing the complete table. The reader rejects unknown origins,
malformed/overflowing counts, nonzero unmatched totals, or disagreement
between the sum of all records and the object's declared total.

All 14 `summary-file` results were independently regenerated through
`measure-2610-v2`, preserving its full origin columns and audit reports.
The six control rows, two pure rows and six combined rows form
`results/summary.tsv`. Category comparisons do not infer a missing origin
from a reduced total; every category is summed from the full records.

Finally the auditor reran both main44cf/control `cmp` operations and all
eight v1/v2 complete-file comparisons, checked both source trees for the
v1 message-only correction, and verified identical v1/v2 spill-module
hashes. Workload and resource-header inventories were checked with
`sha256sum -c` from their recorded input roots.

The archive is created deterministically from `packet/`, using sorted
names, numeric owner/group 0, fixed mtime and `gzip -n`. After extraction
into a fresh directory, `sha256sum -c packet/SHA256SUMS` and `gzip -t`
on every archived gzip file are required to pass. Those final receipts
are outside the archive, beside its SHA256.
