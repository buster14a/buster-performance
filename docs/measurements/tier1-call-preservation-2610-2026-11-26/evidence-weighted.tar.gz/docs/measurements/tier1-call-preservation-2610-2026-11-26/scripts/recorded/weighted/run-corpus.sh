#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Run only after the hosted compiler's identity/manifest is verified. Each compile is one lane and sequential.
set -euo pipefail
cd /workspace/scratch/f0b04b7641b0
for mask in 0 128 256; do
    bash weighted-artifacts/build-variant.sh "$mask" > "weighted-artifacts/mask-$mask.log" 2>&1
done
bash weighted-artifacts/validate-mask256.sh > weighted-artifacts/validation-256.log 2>&1
