# Issue 2610: switch probability structure

This is a read-only diagnosis. No compiler implementation, probability model, threshold, or benchmark gate was changed.

## Concrete shape of `yy_reduce`

The frozen allocation dump and the current weighted-256 dump contain byte-identical complete `yy_reduce` chunks: SHA-256 `92d1faf7e1053bb26b93ef2aaff285d1173f63293bee63019667d420435bbbb1`. The function has 26,310 IR instructions and 1,910 blocks.

Its top switch is a dense jump table, not a sparse comparison tree. Block 0 has two successors: the common suffix, block 1909, and dispatch block 1. The native code checks unsigned `yyruleno > 347`, branches to the common suffix when true, and otherwise reads a signed 32-bit relative target from the table at `0x91bc` and jumps to it. `yy-reduce-entry-cfg.txt` and `yy-reduce-entry-disassembly.txt` preserve these facts.

The uniform-successor model therefore sends one half of all entry mass directly past every reduction action. The fresh baseline instruction capture instead records:

| Site | Executions |
| --- | ---: |
| Real function entry, `0x188830` | 1,227,631 |
| Table-index move, `0x18887f` | 1,022,189 |
| Indirect dispatch, `0x188888` | 1,022,189 |
| Derived range-check bypass | 205,442 |

Thus actual dispatch probability is 83.265167%, versus the model's 50%; actual bypass probability is 16.734833%. `yy-reduce-entry-instructions.tsv` is an excerpt of the newly captured baseline joined instruction table. This is measured evidence about the model error, not a proposed probability constant for the compiler.

## Case aliases and an impossible table edge

The generic ELF reader `table.c` checked every signed relative entry in the measured baseline binary. It found **348 entries, 279 distinct native targets, and zero entries targeting the common suffix**. Block 1 nevertheless has **280 distinct CFG successors**, because the lowering includes the default label in an indirect branch's possible-target list even when no table entry uses it.

The model consequently gives the impossible table-to-default edge 1/280 of dispatch mass. It also assigns equal weights to target blocks with different case multiplicities:

| Cases per native target | Number of targets | Total entries |
| ---: | ---: | ---: |
| 1 | 244 | 244 |
| 2 | 23 | 46 |
| 3 | 4 | 12 |
| 4 | 2 | 8 |
| 5 | 2 | 10 |
| 6 | 1 | 6 |
| 7 | 2 | 14 |
| 8 | 1 | 8 |

For example, rules 15, 18, 47, 62, 72, 81, 100, and 246 all reach `0x189ac0`; the source action simply stores zero. Treating this target as one outcome gives it less mass than a uniform distribution over table indices would. This alias error can act in the opposite direction to the range-guard error: several heavily aliased actions are call-free. Correcting only the first error is not evidence that a candidate exchange becomes profitable.

The source declares `YYNRULE=412` and `YYNRULE_WITH_ACTION=348`. Rules 0 through 347 have explicit action cases; default comments list rules 348 through 411. Uniformity across all 412 valid rule numbers would be a different statistical assumption, not an existing IR fact or a measured distribution. The post-switch array accesses require a valid rule number for defined behavior, but the exchange scorer has no proven finite selector domain. Source comments and macro names must not become allocator special cases.

## Information available in the compiler

`c_check_program_lower.c`'s `CheckLowerTable` holds exact table entries, their count, the lowest value, the fallback, and label identities. `check_lower_switch_dispatch` emits an ordinary bounds-check branch followed by the table load and indirect jump. It always lists the default label first. `check_tier1_switch_tables` already projects the entries/count/symbol information into `IrSwitchTable` for the switch-to-constant-table optimization.

That external table view is not carried by `Tier1SelectPlan` or `IrFunction`. The latter keeps labels and explicit indirect-target lists. `ir_cfg_validated` deduplicates successor blocks, and `Tier1CfgInput` deliberately exposes distinct-successor CSR rows. Neither the table's numeric entry multiplicities nor the distinction between an unused default label and a true table target can be reconstructed from those rows alone. Counting IR label occurrences is insufficient too: adjacent cases can share one label, and separated clusters can acquire different labels that later name the same block.

Large sparse switches are a separate lowering in `c_check_program_sparse_switch.c`. It splits sorted case intervals by interval count, then emits ordinary equality/range branches in leaves. The sorted case plan exists during lowering, but tree provenance and case interval counts are not attached to the final branches. Equal binary decisions are therefore not generally invariant under switch lowering, though that is not the top-level shape of this `yy_reduce`.

## Existing expectation hints

The checker accepts `__builtin_expect` and `__builtin_expect_with_probability`. It classifies a known expected value as frequent, rare, or unknown. Lowering then keeps only a `predictable_branches` bit, which becomes `BUSTER_IR_BRANCH_PREDICTABLE`. Its documented meaning is merely that one outcome is strongly favored; neither direction nor a numerical probability survives. If-conversion uses the bit to avoid replacing a predictable branch. The frequency estimator cannot infer which successor to favor from it.

This SQLite source defines both `likely(X)` and `unlikely(X)` as `(X)` and describes them as comments for readers. They do not provide expectation metadata in this build.

## Consequence

There is a real lowering-induced probability distortion, not a comparison-tree accident in this particular function. A general improvement could preserve and consume exact table incidence and proven selector-range information, or preserve directional expectation metadata. Those are facts available upstream or derivable by an explicit analysis; assigning probabilities to unknown selector values would still require a stated heuristic. The present final CFG cannot supply those facts by itself.

The dynamic parameter counts in `yy-reduce-epochs.tsv` are 1.214795 C+R instructions per entry for RDI and 1.239521 for RSI. One added global entry move would consume most of either gross saving before displaced-callee and argument costs. Whether a global exchange wins therefore still requires the complete cost comparison. These findings do not authorize a threshold reduction or establish that a region-limited exchange is profitable.

## Reproduction

The table audit command was:

```sh
clang -std=c17 -O2 -Wall -Wextra -Werror table.c -o table
./table ../weighted-artifacts/0/speedtest1 0x91bc 348 0x194cdb > yy-reduce-table.tsv 2> yy-reduce-table.txt
```

The compiler used was the pinned Clang 23.1.4. `source.sha256` records the exact source and evidence inputs. The reader only decodes an existing ELF table; it does not compile the corpus or modify its executable.
