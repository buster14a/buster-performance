// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Read one ELF64 relative-address table for a structural diagnostic; no compiler policy is changed.
#include <elf.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv)
{
    int result = 1;
    FILE* file = argc == 5 ? fopen(argv[1], "rb") : NULL;
    if (file != NULL)
    {
        const uint64_t address = strtoull(argv[2], NULL, 0);
        const uint64_t count = strtoull(argv[3], NULL, 0);
        const uint64_t fallback = strtoull(argv[4], NULL, 0);
        Elf64_Ehdr header;
        bool valid = fread(&header, sizeof(header), 1, file) == 1 && memcmp(header.e_ident, ELFMAG, SELFMAG) == 0 &&
                     header.e_ident[EI_CLASS] == ELFCLASS64 && header.e_ident[EI_DATA] == ELFDATA2LSB &&
                     header.e_phentsize == sizeof(Elf64_Phdr) && count != 0 && count <= SIZE_MAX / sizeof(uint64_t);
        uint64_t offset = UINT64_MAX;
        for (uint32_t p = 0; valid && p < header.e_phnum; p += 1)
        {
            Elf64_Phdr program;
            valid = fseek(file, (long)(header.e_phoff + (uint64_t)p * header.e_phentsize), SEEK_SET) == 0 && fread(&program, sizeof(program), 1, file) == 1;
            if (valid && program.p_type == PT_LOAD && address >= program.p_vaddr && address - program.p_vaddr <= program.p_filesz &&
                count <= (program.p_filesz - (address - program.p_vaddr)) / sizeof(int32_t))
            {
                offset = program.p_offset + address - program.p_vaddr;
            }
        }
        uint64_t* targets = valid && offset != UINT64_MAX ? malloc(count * sizeof(uint64_t)) : NULL;
        valid = targets != NULL && fseek(file, (long)offset, SEEK_SET) == 0;
        for (uint64_t i = 0; valid && i < count; i += 1)
        {
            int32_t relative;
            valid = fread(&relative, sizeof(relative), 1, file) == 1;
            if (valid)
            {
                targets[i] = address + (int64_t)relative;
            }
        }
        if (valid)
        {
            uint64_t unique = 0;
            uint64_t default_entries = 0;
            uint64_t most = 0;
            printf("target\tmultiplicity\tindices\n");
            for (uint64_t i = 0; i < count; i += 1)
            {
                default_entries += targets[i] == fallback;
                bool first = true;
                for (uint64_t j = 0; j < i; j += 1)
                {
                    first &= targets[j] != targets[i];
                }
                if (first)
                {
                    uint64_t multiplicity = 0;
                    for (uint64_t j = i; j < count; j += 1)
                    {
                        multiplicity += targets[j] == targets[i];
                    }
                    unique += 1;
                    most = multiplicity > most ? multiplicity : most;
                    printf("0x%" PRIx64 "\t%" PRIu64 "\t", targets[i], multiplicity);
                    for (uint64_t j = i; j < count; j += 1)
                    {
                        if (targets[j] == targets[i])
                        {
                            printf("%s%" PRIu64, j == i ? "" : ",", j);
                        }
                    }
                    printf("\n");
                }
            }
            fprintf(stderr, "address=0x%" PRIx64 " entries=%" PRIu64 " unique_targets=%" PRIu64 " fallback_entries=%" PRIu64 " largest_multiplicity=%" PRIu64 "\n", address, count, unique, default_entries, most);
            result = 0;
        }
        free(targets);
        fclose(file);
    }
    return result;
}
