// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Strict comparison of objdump -d -w -M intel --disassemble=FUNCTION output. Only linked PC-relative address
// fields may differ; each changed field must decode to the printed target and both targets must have the same
// symbolic identity. All instruction offsets, sizes, remaining bytes and normalized textual operands must match.
#define _GNU_SOURCE
#include <ctype.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct CompareInstruction CompareInstruction;
struct CompareInstruction
{
    uint64_t address;
    uint8_t bytes[16];
    uint32_t size;
    char* text;
};

typedef struct CompareFunction CompareFunction;
struct CompareFunction
{
    CompareInstruction* instructions;
    uint32_t count;
    uint64_t base;
    uint64_t bytes;
};

static bool compare_load(const char* path, CompareFunction* function)
{
    FILE* const input = fopen(path, "r");
    char* line = 0;
    size_t capacity = 0;
    bool ok = input != 0;
    function->instructions = calloc(20000, sizeof(CompareInstruction));
    ok = ok && function->instructions != 0;
    while (ok && getline(&line, &capacity, input) >= 0)
    {
        char* end = 0;
        const uint64_t address = strtoull(line, &end, 16);
        if (end > line && *end == ':')
        {
            char* const first = strchr(end + 1, '\t');
            char* const text = first != 0 ? strchr(first + 1, '\t') : 0;
            ok = text != 0 && function->count < 20000;
            CompareInstruction instruction = { .address = address };
            char* cursor = first != 0 ? first + 1 : 0;
            while (ok && cursor < text)
            {
                while (cursor < text && *cursor == ' ')
                {
                    cursor += 1;
                }
                if (cursor < text)
                {
                    const unsigned long byte = strtoul(cursor, &end, 16);
                    ok = end == cursor + 2 && end <= text && byte <= UINT8_MAX && instruction.size < 15;
                    if (ok)
                    {
                        instruction.bytes[instruction.size++] = (uint8_t)byte;
                        cursor = end;
                    }
                }
            }
            if (ok)
            {
                instruction.text = strdup(text + 1);
                ok = instruction.size != 0 && instruction.text != 0;
                if (ok)
                {
                    instruction.text[strcspn(instruction.text, "\r\n")] = 0;
                    function->base = function->count == 0 ? address : function->base;
                    ok = address == function->base + function->bytes;
                    function->bytes += instruction.size;
                    function->instructions[function->count++] = instruction;
                }
            }
        }
    }
    if (input != 0)
    {
        ok = !ferror(input) && fclose(input) == 0 && ok;
    }
    free(line);
    return ok && function->count != 0;
}

// Normalize display addresses only when objdump supplies a symbolic destination. Numeric ordinary immediates,
// register choices, widths and addressing modes are preserved. Return a decoded external-PC-relative target.
static bool compare_text(const CompareInstruction* instruction, char output[2048], uint64_t* target, bool* relative)
{
    const char* const text = instruction->text;
    const char* const symbol = strchr(text, '<');
    const char* const symbol_end = symbol != 0 ? strchr(symbol, '>') : 0;
    const char* const rip = strstr(text, "[rip");
    const char* const comment = strchr(text, '#');
    bool ok = strlen(text) < 1500;
    *relative = false;
    output[0] = 0;
    if (ok && rip != 0)
    {
        const char* const closing = strchr(rip, ']');
        char* parsed = 0;
        *target = comment != 0 ? strtoull(comment + 1, &parsed, 16) : 0;
        ok = closing != 0 && comment != 0 && closing < comment && symbol != 0 && symbol_end != 0 && parsed > comment + 1 && parsed <= symbol;
        if (ok)
        {
            const int prefix = (int)(rip - text);
            const int identity = (int)(symbol_end - symbol + 1);
            const int suffix = (int)(comment - closing - 1);
            snprintf(output, 2048, "%.*s[rip:%.*s]%.*s", prefix, text, identity, symbol, suffix, closing + 1);
            *relative = true;
        }
    }
    else if (ok && symbol != 0)
    {
        const char* operand = text;
        while (*operand != 0 && !isspace((unsigned char)*operand))
        {
            operand += 1;
        }
        while (isspace((unsigned char)*operand))
        {
            operand += 1;
        }
        char* parsed = 0;
        *target = strtoull(operand, &parsed, 16);
        ok = (strncmp(text, "call", 4) == 0 || text[0] == 'j') && parsed > operand && parsed <= symbol && symbol_end != 0;
        if (ok)
        {
            snprintf(output, 2048, "%.*s%s", (int)(operand - text), text, symbol);
            *relative = true;
        }
    }
    else if (ok)
    {
        strcpy(output, text);
    }
    size_t length = strlen(output);
    while (length != 0 && isspace((unsigned char)output[length - 1]))
    {
        output[--length] = 0;
    }
    return ok;
}

static uint32_t compare_u32(const uint8_t* bytes)
{
    return (uint32_t)bytes[0] | (uint32_t)bytes[1] << 8 | (uint32_t)bytes[2] << 16 | (uint32_t)bytes[3] << 24;
}

int main(int argc, char** argv)
{
    CompareFunction a = { 0 };
    CompareFunction b = { 0 };
    bool ok = argc == 3 && compare_load(argv[1], &a) && compare_load(argv[2], &b);
    ok = ok && a.count == b.count && a.bytes == b.bytes;
    uint32_t changed = 0;
    uint32_t same = 0;
    uint32_t calls = 0;
    uint32_t rip = 0;
    for (uint32_t i = 0; ok && i < a.count; i += 1)
    {
        const CompareInstruction* const left = &a.instructions[i];
        const CompareInstruction* const right = &b.instructions[i];
        char text_a[2048];
        char text_b[2048];
        uint64_t target_a = 0;
        uint64_t target_b = 0;
        bool relative_a = false;
        bool relative_b = false;
        ok = left->size == right->size && left->address - a.base == right->address - b.base &&
             compare_text(left, text_a, &target_a, &relative_a) && compare_text(right, text_b, &target_b, &relative_b) &&
             relative_a == relative_b && strcmp(text_a, text_b) == 0;
        const bool identical = ok && memcmp(left->bytes, right->bytes, left->size) == 0;
        if (identical)
        {
            same += 1;
        }
        else if (ok)
        {
            uint32_t fits = 0;
            uint32_t position = 0;
            const uint32_t displacement_a = (uint32_t)(target_a - left->address - left->size);
            const uint32_t displacement_b = (uint32_t)(target_b - right->address - right->size);
            // Only a contiguous disp32 may differ. Its encoded signed displacement must resolve to the full printed
            // target, in both objects. The matching symbolic target and every other textual operand were checked above.
            for (uint32_t j = 0; relative_a && j + 4 <= left->size; j += 1)
            {
                bool match = compare_u32(left->bytes + j) == displacement_a && compare_u32(right->bytes + j) == displacement_b &&
                             left->address + left->size + (int32_t)displacement_a == target_a &&
                             right->address + right->size + (int32_t)displacement_b == target_b;
                for (uint32_t k = 0; match && k < left->size; k += 1)
                {
                    match = (k >= j && k < j + 4) || left->bytes[k] == right->bytes[k];
                }
                fits += match;
                position = match ? j : position;
            }
            const bool is_rip = strstr(left->text, "[rip") != 0;
            const bool is_call = left->size == 5 && left->bytes[0] == 0xe8 && position == 1;
            ok = fits == 1 && (is_rip || is_call);
            if (ok)
            {
                changed += 1;
                calls += is_call;
                rip += is_rip;
                printf("relocation\toffset=%" PRIx64 "\tdisp32=%u\t%s\n", left->address - a.base, position, text_a);
            }
        }
        if (!ok)
        {
            fprintf(stderr, "FAIL instruction=%u offsets=%" PRIx64 "/%" PRIx64 "\nA %s\nB %s\n", i,
                    left->address - a.base, right->address - b.base, left->text, right->text);
        }
    }
    printf("%s instructions=%u bytes=%" PRIu64 " raw_identical_instructions=%u relocated_instructions=%u direct_calls=%u rip_relative=%u base_a=%" PRIx64 " base_b=%" PRIx64 "\n",
           ok ? "PASS" : "FAIL", a.count, a.bytes, same, changed, calls, rip, a.base, b.base);
    for (uint32_t i = 0; i < a.count; i += 1)
    {
        free(a.instructions[i].text);
    }
    for (uint32_t i = 0; i < b.count; i += 1)
    {
        free(b.instructions[i].text);
    }
    free(a.instructions);
    free(b.instructions);
    return ok ? 0 : 1;
}
