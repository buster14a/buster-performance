# Bounded uniform CFG frequencies for issue 2610

This is an isolated, unpublished cost-model experiment. It changes no compiler
source or frozen measurement. `frequency.c` estimates per-block visits under
uniform probabilities over each block's **distinct successors**. The producer
is the already validated `Tier1CfgInput` graph; the proposed consumer is the
exchange scorer's exact lazy-save epoch columns. It is a heuristic estimate,
not a profile or a guarantee that an exchange improves a real execution.

The completed pinned-Clang run passed **1,100 checks, zero failures**.
The frozen `yy_reduce` graph also converged: **1,910 blocks, 3,073 edges, 49
sweeps, 230,336 work units**, every one of the 4,294,967,296 entry ticks absorbed,
zero residual. The parser independently checked matching duplicate-free CSR
views. `yy-reduce-weights.tsv` retains its per-block result.

After an executor reset, the unchanged repository staging script restored the
exact Clang 23.1.4 / LLVM `7a941dfb2877a0b8cf30323fefa85ad019e0b0f5` toolchain.
The complete replay passed: **17 adapter checks**, the same **1,100 checks under
AddressSanitizer/UndefinedBehaviorSanitizer**, and the actual CFG result above.
The stopped-rotor mutant failed **14 checks** and the dropped-remainder mutant
failed **82**, both exiting 1. The original sources and tests were unchanged by
mutation generation. No full compiler build was used.

LeakSanitizer's separate process-scanning mode cannot attach under this
executor's ptrace restrictions. The first runtime refusal is retained in
`sanitizer-leak-runtime.log`. The successful address/UB run explicitly uses
`ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1`; it makes no leak
checking claim and changed no executor permission.

## Proposed handoff

```c
static bool tier1_emit_exchange_frequency(
    const Tier1CfgInput* input, Arena* scratch, uint64_t** weights);
```

`adapter.c` supplies that exact interface. On success it retains one uint64 Q32
visit weight per block in scratch and publishes the pointer. Its work arrays
are popped. On any refusal it restores the original scratch length and leaves
the caller's pointer cell unchanged. It never writes any previously allocated
scratch bytes. Arena peak/committed-page bookkeeping follows the existing
allocator's normal semantics; restoring the logical length does not undo a
page commit. Scratch high-water is 36 bytes/block plus alignment; retained
storage is 8 bytes/block.

The core takes matching immutable CSR views, an entry index, explicit limits,
28 bytes/block of 8-byte-aligned workspace and a separate uint64 output slice.
All those stores and the optional report are disjoint. It validates spans,
endpoints and duplicate rows, including duplicates across vector chunks. The
normal producer's matching-view transpose validation is a precondition, not
silently replaced by the helper. Core output remains byte-for-byte unchanged
on refusal. Its raw status and statistics are exposed for focused tests; the
adapter reduces every refusal to false.

Entry mass is `1ULL << 32`. Entry argument movement therefore costs one such
unit per instruction and per invocation, independently of a loop revisiting
block 0. The consumer should multiply each block's uint32 store/load or ABI
shuffle counts by that block's uint64 weight using checked 128-bit arithmetic.
A fixture explicitly demonstrates that a valid product can exceed 64 bits.

## Algorithm and refusal

Forward reachability and reverse reachability from terminal blocks first
reject any reachable block with no path to a terminal. This rejects reachable
closed recurrent components even behind branches whose mathematical mass is
less than one tick. Unreachable cycles remain zero and do not cause refusal.

The flow then visits blocks in layout order. A forward edge can propagate
within one sweep; a self or backward edge waits for the next. Each consumed
pending amount is cleared before distribution, added to that block's visits,
and split by quotient plus remainder. Remainder ticks go to consecutive
successor ordinals starting at a rotating per-block cursor. Across a block's
whole history, cumulative outgoing shares differ by at most one tick. No mass
is rounded away. At every completed sweep, absorbed plus pending mass must be
exactly the initial unit. Only zero pending mass permits publication.

The adapter allows 128 sweeps and 8,388,608 work units. Work includes block rows
and examined edges in validation, reachability and propagation; every sweep
also charges its scans. Resource exhaustion, malformed input, an unreachable
terminal from a reachable block, overflow or unfinished propagation declines
the optional optimization. These are generic bounded-work choices, not tuned
function names or benchmark gates. They have no claim of optimality.

Vector code handles endpoint classification, duplicate detection, worklist
compaction, fanout and residual reduction, including masked tails. The layout
sweep preserves the explicitly chosen propagation order. There is one flow
implementation, no scalar comparison solver. No throughput claim or Zen 5
timing is made for these scratch kernels.

## Semantic tests and limits

The fixed expectations cover a terminal, chains, diamond, 3-way and 65-way
switches, nested cold branches, self-loops with both edge orders, nested loops,
a slow exit, reachable and unreachable cycles, invalid inputs, capacity,
budget and page-boundary tails. A reversed 18-block chain needs 18 sweeps,
making layout-dependent refusal explicit. Relabeled nested loops finish in
78 versus 107 sweeps and agree with the analytic visits within eight ticks.
A 63/64-return loop refuses the default 128 sweeps; the test's explicit larger
budget converges in 1,446, with visits near 64 entry units at its header.

Sibling/edge reorderings are checked against stated tick tolerances. These
fixtures do not establish a universal small error bound. Ill-conditioned
graphs may amplify fixed-point rounding; a rational one-third cost tie can
become a few ticks positive or negative depending on successor order.

Uniform branching also has a more substantial limitation: a dynamically cold
hook still receives a positive estimated probability. A conditional saving
cannot guarantee repayment of an unconditional entry copy on every actual
path. The estimate should guide experiments; native correctness, certification
and paired generated-program instruction counts remain separate gates.

`adapter-tests.c` includes the actual repository `lane.c` arena implementation
(its retained MIT/RAD Debugger attribution applies to that file) with a small
projection of only the CFG descriptor fields the adapter reads. Full backend
type integration is a separate compiler check. `mutate.c` makes private copies
that either stop rotating the remainder cursor or discard all remainder
ticks. The unchanged semantic tests must reject both.

## Reproduction

From this directory, run `bash run.sh` after the repository's unmodified
`tools/ci/session-toolchain.sh stage`. The script names the original pinned
Clang 23.1.4 path and records its full version; an explicit first argument may
name the same restored compiler. It builds only these small standalone
fixtures, the arena adapter and the dump parser. It runs the core normally and
under AddressSanitizer/UndefinedBehaviorSanitizer, the adapter, and the two
mutants, then replays the frozen `yy_reduce` dump. Each step has a separate log,
and `source-sha256.txt` pins every source and the compressed dump. The tests
consume original source rather than a second implementation of the algorithm.
