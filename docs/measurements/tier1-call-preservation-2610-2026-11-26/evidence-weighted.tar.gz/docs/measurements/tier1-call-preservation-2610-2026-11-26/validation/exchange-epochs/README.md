# Exact call-preservation epochs for #2610

This is an isolated, source-backed experiment. It changes neither the frozen
measurement compiler nor a production checkout. Its inputs are the selected IR
and the complete, already validated CFG allocation, before frame/record emission.

## Provenance

The source and fixture dependencies are `buster14a/buster` at
`8e4d32879e17b7d9548cad54257a2f8461328366`, with the frozen measurement patch
`kinds-2610-exchange.patch` (SHA256
`20b334a1a86c772cba1dc1afe932b8fa25f0415a4801f332c8cdd2fb4c0bbd8e`). The hosted
equivalent is measurement commit
`54d033d00ef89737da7d37e689e5aefc8b0ad72b`.

The transition/entry construction and ordered state walk are adapted from that
revision's `tier1_emit_cfg_records`; the small shared state update comes from
`tier1_emit_phase`. Existing ordinary/carry/join/pressure/dropped-definition test
builders are used verbatim through the actual backend unity includes. New test
builders and tooling are original work under the repository license. No external
implementation was imported.

## Integration API

Copy `tier1_emit_exchange_epochs.c` and `tier1_emit_transition_state.c` into the
compiler source directory, and apply `shared-phase.patch` to `tier1_emit.c`.
Include the epoch module immediately before `tier1_emit_exchange_cost.c`, after
the ordinary CFG emitter helpers. The state helper's include guard lets the
epoch module and real emitter share its definition.

```c
typedef struct Tier1EmitExchangeEpoch {
    uint32_t blocks;
    uint32_t* stores;
    uint32_t* loads;
} Tier1EmitExchangeEpoch;

static Tier1EmitError tier1_emit_exchange_epochs(
    const Tier1SelectPlan* plan,
    const Tier1EmitResult* emitted,
    const Tier1CfgInput* input,
    const Tier1CfgAllocation* cfg,
    Arena* scratch,
    Tier1EmitExchangeEpoch* result);
```

Each column has `blocks * 16` elements, indexed by `block * 16 + abstract_gpr`.
It records the exact call-save stores and deferred call-save reloads emitted if
that abstract allocation register is caller-saved. All sixteen columns are
computed in one state walk. A permutation selects columns according to the
destination register's ABI class. Explicit fixed-sequence saves are not included:
an admissible exchange must leave all registers used by those sequences fixed.

On success, only these two result columns remain in scratch; the caller's outer
mark owns them. On failure, scratch length and the caller's result are unchanged.
No selected IR, allocation, emitted result or output arena is modified. Failure
is appropriate for declining an optional optimization; the valid original
allocation remains available. With proof instrumentation disabled the result
structure is 24 bytes and has no per-node masks or counters.

For weighted scoring, multiply each `uint32_t` count by the corresponding Q32
`uint64_t` block weight using a checked 128-bit accumulator. Charge actual entry
copies separately at one function entry. Argument-shuffle costs also remain a
separate term. These columns do not estimate dynamic branch probabilities.

## Why this preserves the emitter's lazy semantics

The walk reconstructs actual transition CSR, block-entry intervals, the reverse
dropped-definition closure, register columns, owner columns, saved row owners,
and the owed mask. It keeps the same consequential order as emission: repay owed
registers, apply use transitions, set the definition register column, apply
definition transitions, update call/fixed rows, install a non-dropped definition
owner, then drop owed state on returns. Registers persist between block walks;
owners are reset. A sole earlier predecessor can supply saved row owners, while
owed state always starts clear at a block entry.

The existing `tier1_emit_owed`, `tier1_emit_kept`, `tier1_emit_saved`,
`tier1_emit_fixed_rows`, entry-location and dead-definition helpers are called
directly. A lookup of each value's allocation at each node cannot replace this
walk: covered and dropped definitions, phase transitions and inherited saved
rows carry state that such a lookup omits.

For an admissible register permutation, owner identities and saved row identities
are unchanged, while each register/owed bit moves to its mapped lane. The reused
helpers' tests and updates are lane-wise. The permutation therefore commutes
with each state step and with the block-row copy. Treating every abstract GPR as
caller-saved computes all projected schedules at once. This argument assumes
the exchange leaves fixed instruction roles unchanged; the scorer/map owns that
eligibility condition. Physical scratch availability for ROW emission is a
separate exchange eligibility concern and is not established by this helper.

## Validation

Both the untouched emitter and a scratch copy using the proposed shared-phase
patch pass **2,017 checks, zero failures**, with byte-identical complete logs.
The run covers 36 actual CFG emissions, all allocation-certified; the eight
controlled-map emissions also require machine-code certificates. The compared
records include 77 C stores and 88 R reloads; fixtures exercise 155 fragment
transitions, 36 dropped definitions, 30 covered nodes and 20 carried block rows.

The oracle independently reads actual emitted C/R tags, machine instruction
forms and exact node-phase origins. It checks every eligible register at every
block and every node. The full abstract columns are also compared across a
forced RDI/RBX permutation, with rematerialization on/off and a kept frame
pointer on/off. Capacity failures before result allocation and during metadata
construction restore the single scratch arena and leave the result untouched.

The lazy-owner counterexample is emitted and certified, not simulated by a
second cost model:

| Shape | Allocation | C | R | Entry moves |
| --- | --- | ---: | ---: | ---: |
| One block, three calls | Original | 1 | 1 | 0 |
| One block, three calls | RDI/RBX exchanged | 2 | 2 | 1 |
| Three blocks, saved rows carried | Original | 1 | 3 | 0 |
| Three blocks, saved rows carried | RDI/RBX exchanged | 2 | 2 | 1 |

The abstract columns predict both exchanged outcomes exactly. A raw live-at-call
count incorrectly favors the first exchange, because one unread caller value
needs one epoch while two different callee owners need two. The three-block
case also proves that retained saved rows can avoid stores while repayment at
block ends still produces distinct loads.

The production configuration without proof fields passes the same pinned
Clang's syntax check. This is a correctness and accounting proof. It makes no
hardware throughput or universal dynamic-performance claim.

## Reproduction

Run from this directory with the frozen dependency checkout at `../../buster-tags`.
All builds use the sanctioned restored Clang 23.1.4,
LLVM revision `7a941dfb2877a0b8cf30323fefa85ad019e0b0f5`.

```sh
clang -O2 -Wall -Werror generate.c -o generate
./generate ../../buster-tags/src/buster/compiler/main.c focused.c
./generate ../../buster-tags/src/buster/compiler/main.c shared-focused.c shared
./generate ../../buster-tags/src/buster/compiler/main.c production-focused.c production
cp ../../buster-tags/src/buster/compiler/tier1_emit.c emitter-shared.c
patch emitter-shared.c < shared-phase.patch
clang -O0 -g0 -march=native \
  -I../../buster-tags/src -I../../buster-tags/src/buster/compiler \
  -fwrapv -funsigned-char -fno-strict-aliasing -Wall -Werror -Wno-unused-function \
  -fno-stack-protector \
  -DBUSTER_HOST_SSP_DEFAULT=BUSTER_PREDEFINES_SSP_OFF \
  '-DBUSTER_CLANG_DEFAULT_TARGET="x86_64-unknown-linux-gnu"' \
  -DBUSTER_EXECUTABLE_UNIT -DBUSTER_HOST_STATIC=1 \
  -ffunction-sections -fdata-sections -Wl,--gc-sections \
  focused.c -pthread -ldl -o epoch
timeout 60 ./epoch > run-api.log 2>&1
```

Repeat the same compile with `shared-focused.c -o epoch-shared`, execute it into
`run-shared.log`, and require `cmp run-api.log run-shared.log` to succeed. For
the production configuration use `production-focused.c -fsyntax-only`, omitting
linker and library arguments. The recorded build logs are empty on success.

The generator uses the repository's actual main include prefix and normal
standalone ownership for tables; it removes only the command dispatcher and
appends the focused runner. No production function body is edited in the
original-emitter harness. The shared twin changes only the supplied phase hunk.

An executor restart erased earlier `/tmp` captures and the toolchain cache.
These API/shared-phase runs were performed after the unchanged sanctioned
toolchain was restored; the logs and sources here survived in the workspace.
They do not assert retention of the erased raw Callgrind measurements.
