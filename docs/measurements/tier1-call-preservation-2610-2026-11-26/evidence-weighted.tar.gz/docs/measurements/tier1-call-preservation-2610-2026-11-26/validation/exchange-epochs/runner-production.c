// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
#include "tier1_emit_exchange_epochs.c"

_Static_assert(sizeof(Tier1EmitExchangeEpoch) == 24, "production epoch data retains only block count and two columns");

int main(void)
{
    return 0;
}
