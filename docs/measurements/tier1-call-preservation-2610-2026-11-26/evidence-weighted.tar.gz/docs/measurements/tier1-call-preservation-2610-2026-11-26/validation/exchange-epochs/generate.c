// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
//
// Generate a focused backend unity from the repository's own include list. The
// production bodies and the regression fixture remain unmodified. Only table
// storage is made local, using the modules' normal standalone inclusion paths.
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv)
{
    int result = 1;
    const bool shared = argc == 4 && strcmp(argv[3], "shared") == 0;
    const bool production = argc == 4 && strcmp(argv[3], "production") == 0;
    FILE* input = argc == 3 || shared || production ? fopen(argv[1], "r") : 0;
    FILE* output = input != 0 ? fopen(argv[2], "w") : 0;
    if (input != 0 && output != 0)
    {
        fputs("#define BUSTER_UNIT BUSTER_UNIT_BACKEND\n", output);
        char line[4096];
        bool ended = false;
        unsigned local = 0;
        unsigned target = 0;
        while (fgets(line, sizeof(line), input) != 0)
        {
            if (strcmp(line, "// The other units' main_command, each in its own unit (at the top).\n") == 0)
            {
                ended = true;
                break;
            }
            if (shared && strcmp(line, "#include \"buster/compiler/tier1_emit.c\"\n") == 0)
            {
                fputs("#include \"emitter-shared.c\"\n", output);
            }
            else if (strcmp(line, "#define BUSTER_X86_TARGET_DATA_ELSEWHERE\n") == 0)
            {
                fputs("#define BUSTER_X86_TARGET_DATA static\n", output);
                target += 1;
            }
            else
            {
                const bool standalone = strcmp(line, "#include \"buster/compiler/x86_64_encoder.c\"\n") == 0 ||
                                        strcmp(line, "#include \"buster/compiler/lane.c\"\n") == 0 ||
                                        strcmp(line, "#include \"buster/compiler/tier1_select.c\"\n") == 0;
                if (standalone)
                {
                    fputs("#undef BUSTER_UNIT\n", output);
                    local += 1;
                }
                fputs(line, output);
                if (standalone)
                {
                    fputs("#define BUSTER_UNIT BUSTER_UNIT_BACKEND\n", output);
                }
            }
        }
        fputs(production ? "#include \"runner-production.c\"\n" : "#include \"runner.c\"\n", output);
        result = !(ended && local == 3 && target == 1 && !ferror(input) && !ferror(output));
    }
    if (output != 0)
    {
        result |= fclose(output) != 0;
    }
    if (input != 0)
    {
        result |= fclose(input) != 0;
    }
    return result;
}
