// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
#include "tests.c"

int main(void)
{
    int result = 1;
    arena_page_policy("0");
    if (x86_encoder_initialize() && x86_semantics_initialize() && x86_zen5_initialize())
    {
        Tier1EmitTest test = {
            .input = arena_reserve(32u << 20),
            .output = arena_reserve(64u << 20),
            .scratch = arena_reserve(32u << 20),
            .allowed = malloc(X86_FORM_COUNT),
        };
        uint8_t* host_forms = malloc(X86_FORM_COUNT);
        if (test.input.base != 0 && test.output.base != 0 && test.scratch.base != 0 && test.allowed != 0 && host_forms != 0)
        {
            const X86Target baseline = { .architecture = X86_ARCH_BASELINE };
            const X86Target host = x86_target_native();
            x86_target_forms(&baseline, test.allowed);
            x86_target_forms(&host, host_forms);
            test.native_allowed = host_forms;
            weighted_tests(&test);
            const uint64_t before = test.checks;
            exchange_test_native(&test);
            printf("weighted and native: %" PRIu64 " checks, %" PRIu64 " failures, %" PRIu64 " native checks, %" PRIu64 " native skips\n",
                   test.checks, test.failures, test.checks - before, test.native_skipped);
            result = test.failures != 0 || test.native_skipped != 0;
        }
        free(host_forms);
        free(test.allowed);
        arena_release(&test.input);
        arena_release(&test.output);
        arena_release(&test.scratch);
    }
    return result;
}
