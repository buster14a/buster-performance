#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
set -euo pipefail
cd -- "$(dirname -- "$0")"
frequency_clang=${1:-/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang}
frequency_flags=(-std=c17 -O2 -g0 -march=native -fwrapv -funsigned-char -fno-strict-aliasing -Wall -Wextra -Werror)
"$frequency_clang" --version > compiler-version.txt
"$frequency_clang" "${frequency_flags[@]}" tests.c -o frequency-tests > build.log 2>&1
./frequency-tests > run.log 2>&1
"$frequency_clang" "${frequency_flags[@]}" -Wno-unused-function -pthread adapter-tests.c -o adapter-tests > adapter-build.log 2>&1
./adapter-tests > adapter-run.log 2>&1
"$frequency_clang" "${frequency_flags[@]}" -fsanitize=address,undefined -fno-omit-frame-pointer tests.c -o frequency-sanitized > sanitizer-build.log 2>&1
# The executor disallows LeakSanitizer's ptrace attachment. Keep address/UB checks enabled without that unrelated
# process-scanning mode; sanitizer-leak-runtime.log preserves the first runtime refusal.
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 ./frequency-sanitized > sanitizer-run.log 2>&1
"$frequency_clang" -std=c17 -O2 -Wall -Wextra -Werror mutate.c -o mutate > mutation-build.log 2>&1
for mutation in rotor remainder; do
    mkdir -p "mutants/$mutation"
    ./mutate frequency.c "mutants/$mutation/frequency.c" "$mutation"
    cp tests.c "mutants/$mutation/tests.c"
    "$frequency_clang" "${frequency_flags[@]}" "mutants/$mutation/tests.c" -o "mutants/$mutation/tests" > "mutants/$mutation/build.log" 2>&1
    set +e
    "mutants/$mutation/tests" > "mutants/$mutation/run.log" 2>&1
    mutation_status=$?
    set -e
    printf '%s\n' "$mutation_status" > "mutants/$mutation/status.txt"
    [[ $mutation_status -eq 1 ]]
done
"$frequency_clang" "${frequency_flags[@]}" dump.c -o dump-frequency > dump-build.log 2>&1
gzip -cd ../../exchange-artifacts/128/cfg.dump.gz | ./dump-frequency 1910 128 yy-reduce-weights.tsv > yy-reduce.log
sha256sum frequency.c adapter.c tests.c adapter-tests.c dump.c mutate.c run.sh ../../buster-exchange/src/buster/compiler/lane.c ../../exchange-artifacts/128/cfg.dump.gz > source-sha256.txt
tail -n 1 run.log adapter-run.log sanitizer-run.log mutants/rotor/run.log mutants/remainder/run.log
cat yy-reduce.log
