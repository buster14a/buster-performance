// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Focused semantic fixtures for frequency.c: closed-form visits and conservation, not a second flow solver.

#define _GNU_SOURCE
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
#include "frequency.c"

#define BUSTER_FREQUENCY_TEST_BLOCKS 160u
#define BUSTER_FREQUENCY_TEST_EDGES 512u
#define BUSTER_FREQUENCY_TEST_SENTINEL UINT64_C(0xa713eac4082fd965)

typedef struct FrequencyTestGraph FrequencyTestGraph;
struct FrequencyTestGraph
{
    uint32_t sources[BUSTER_FREQUENCY_TEST_EDGES];
    uint32_t targets[BUSTER_FREQUENCY_TEST_EDGES];
    uint32_t blocks;
    uint32_t edges;
    uint32_t entry;
};

typedef struct FrequencyTestCsr FrequencyTestCsr;
struct FrequencyTestCsr
{
    Tier1FrequencyGraph graph;
    uint32_t* storage;
    size_t bytes;
};

static uint32_t frequency_test_checks;
static uint32_t frequency_test_failures;

static void frequency_test_check(bool ok, const char* name, const char* check)
{
    frequency_test_checks += 1;
    frequency_test_failures += !ok;
    if (!ok)
    {
        fprintf(stderr, "FAIL %s: %s\n", name, check);
    }
}

static void frequency_test_edge(FrequencyTestGraph* graph, uint32_t source, uint32_t target)
{
    if (graph->edges >= BUSTER_FREQUENCY_TEST_EDGES || source >= graph->blocks || target >= graph->blocks)
    {
        abort();
    }
    graph->sources[graph->edges] = source;
    graph->targets[graph->edges] = target;
    graph->edges += 1;
}

static FrequencyTestCsr frequency_test_csr(const FrequencyTestGraph* input)
{
    const uint32_t blocks = input->blocks;
    const uint32_t edges = input->edges;
    const size_t count = 2 * ((size_t)blocks + 1 + edges);
    uint32_t* const storage = calloc(count, sizeof(uint32_t));
    if (storage == 0)
    {
        abort();
    }
    uint32_t* const so = storage;
    uint32_t* const po = so + blocks + 1;
    uint32_t* const ss = po + blocks + 1;
    uint32_t* const pp = ss + edges;
    uint32_t sn = 0;
    uint32_t pn = 0;
    // Fixture representation only: enumerate the supplied literal edges into both CSR views.
    for (uint32_t b = 0; b < blocks; b += 1)
    {
        so[b] = sn;
        po[b] = pn;
        for (uint32_t e = 0; e < edges; e += 1)
        {
            if (input->sources[e] == b)
            {
                ss[sn++] = input->targets[e];
            }
            if (input->targets[e] == b)
            {
                pp[pn++] = input->sources[e];
            }
        }
    }
    so[blocks] = sn;
    po[blocks] = pn;
    const FrequencyTestCsr result = {
        .graph = {
            .successor_offsets = so,
            .successors = ss,
            .predecessor_offsets = po,
            .predecessors = pp,
            .block_count = blocks,
            .edge_count = edges,
            .entry = input->entry,
        },
        .storage = storage,
        .bytes = count * sizeof(uint32_t),
    };
    return result;
}

static Tier1FrequencyStats frequency_test_run(const char* name, const Tier1FrequencyGraph* graph,
                                             Tier1FrequencyStatus expected, uint32_t rounds, uint64_t work,
                                             const uint64_t* exact, uint64_t tolerance, uint64_t* actual)
{
    const uint32_t blocks = graph->block_count;
    const uint64_t bytes = tier1_frequency_workspace_bytes(blocks);
    uint8_t* const memory = malloc((size_t)bytes + 32);
    uint64_t* const output = malloc(((size_t)blocks + 2) * sizeof(uint64_t));
    if (memory == 0 || output == 0)
    {
        abort();
    }
    memset(memory, 0xc9, (size_t)bytes + 32);
    for (uint32_t b = 0; b < blocks + 2; b += 1)
    {
        output[b] = BUSTER_FREQUENCY_TEST_SENTINEL;
    }
    const Tier1FrequencyLimits limits = {
        .rounds = rounds,
        .work = work,
    };
    Tier1FrequencyStats stats = { 0 };
    const Tier1FrequencyStatus status = tier1_frequency_estimate(graph, &limits, memory + 16, bytes, output + 1, blocks, &stats);
    frequency_test_check(status == expected, name, "status");
    frequency_test_check(stats.work <= work, name, "bounded work");
    frequency_test_check(stats.rounds <= rounds, name, "bounded rounds");
    frequency_test_check(output[0] == BUSTER_FREQUENCY_TEST_SENTINEL && output[blocks + 1] == BUSTER_FREQUENCY_TEST_SENTINEL, name, "output guards");
    for (uint32_t j = 0; j < 16; j += 1)
    {
        frequency_test_check(memory[j] == 0xc9 && memory[bytes + 16 + j] == 0xc9, name, "workspace guards");
    }
    if (status == TIER1_FREQUENCY_OK)
    {
        frequency_test_check(stats.pending_mass == 0 && stats.absorbed_mass == BUSTER_TIER1_FREQUENCY_ONE, name, "exact absorption");
        for (uint32_t b = 0; b < blocks; b += 1)
        {
            if (exact != 0)
            {
                const uint64_t value = output[b + 1];
                const uint64_t difference = value > exact[b] ? value - exact[b] : exact[b] - value;
                frequency_test_check(difference <= tolerance, name, "closed-form visits");
            }
            if (actual != 0)
            {
                actual[b] = output[b + 1];
            }
        }
    }
    else
    {
        for (uint32_t b = 0; b < blocks; b += 1)
        {
            frequency_test_check(output[b + 1] == BUSTER_FREQUENCY_TEST_SENTINEL, name, "refusal preserves output");
        }
    }
    printf("%s status=%u rounds=%u work=%" PRIu64 " reached=%u absorbed=%" PRIu64 " pending=%" PRIu64 "\n",
           name, status, stats.rounds, stats.work, stats.reachable_blocks, stats.absorbed_mass, stats.pending_mass);
    free(output);
    free(memory);
    return stats;
}

static void frequency_test_fixture(const char* name, const FrequencyTestGraph* input, Tier1FrequencyStatus expected,
                                   uint32_t rounds, const uint64_t* exact, uint64_t tolerance, uint64_t* actual)
{
    FrequencyTestCsr csr = frequency_test_csr(input);
    void* const snapshot = malloc(csr.bytes);
    if (snapshot == 0)
    {
        abort();
    }
    memcpy(snapshot, csr.storage, csr.bytes);
    frequency_test_run(name, &csr.graph, expected, rounds, BUSTER_TIER1_FREQUENCY_WORK, exact, tolerance, actual);
    frequency_test_check(memcmp(snapshot, csr.storage, csr.bytes) == 0, name, "graph is immutable");
    free(snapshot);
    free(csr.storage);
}

static void frequency_test_acyclic(void)
{
    const uint64_t unit = BUSTER_TIER1_FREQUENCY_ONE;
    FrequencyTestGraph single = {
        .blocks = 1,
    };
    frequency_test_fixture("terminal", &single, TIER1_FREQUENCY_OK, 1, &unit, 0, 0);
    FrequencyTestGraph diamond = {
        .blocks = 4,
    };
    frequency_test_edge(&diamond, 0, 1);
    frequency_test_edge(&diamond, 0, 2);
    frequency_test_edge(&diamond, 1, 3);
    frequency_test_edge(&diamond, 2, 3);
    const uint64_t weights[] = { unit, unit / 2, unit / 2, unit };
    frequency_test_fixture("diamond", &diamond, TIER1_FREQUENCY_OK, 1, weights, 0, 0);
    FrequencyTestGraph chain = {
        .blocks = 18,
    };
    uint64_t expected[18];
    for (uint32_t b = 0; b < 18; b += 1)
    {
        expected[b] = unit;
        if (b + 1 < 18)
        {
            frequency_test_edge(&chain, b, b + 1);
        }
    }
    frequency_test_fixture("forward-chain-tail", &chain, TIER1_FREQUENCY_OK, 1, expected, 0, 0);
    chain.edges = 0;
    chain.entry = 17;
    for (uint32_t b = 1; b < 18; b += 1)
    {
        frequency_test_edge(&chain, b, b - 1);
    }
    frequency_test_fixture("backward-layout-budget", &chain, TIER1_FREQUENCY_UNCONVERGED, 1, 0, 0, 0);
    frequency_test_fixture("backward-layout-complete", &chain, TIER1_FREQUENCY_OK, 18, expected, 0, 0);
    for (uint32_t width = 3; width <= 65; width += 62)
    {
        uint64_t before[BUSTER_FREQUENCY_TEST_BLOCKS] = { 0 };
        uint64_t after[BUSTER_FREQUENCY_TEST_BLOCKS] = { 0 };
        FrequencyTestGraph wide = {
            .blocks = width + 2,
        };
        for (uint32_t arm = 1; arm <= width; arm += 1)
        {
            frequency_test_edge(&wide, 0, arm);
            frequency_test_edge(&wide, arm, width + 1);
        }
        frequency_test_fixture("multiway", &wide, TIER1_FREQUENCY_OK, 1, 0, 0, before);
        wide.edges = 0;
        for (uint32_t arm = width; arm != 0; arm -= 1)
        {
            frequency_test_edge(&wide, 0, arm);
            frequency_test_edge(&wide, arm, width + 1);
        }
        frequency_test_fixture("multiway-reversed-edges", &wide, TIER1_FREQUENCY_OK, 1, 0, 0, after);
        uint64_t sum = 0;
        for (uint32_t arm = 1; arm <= width; arm += 1)
        {
            sum += before[arm];
            frequency_test_check(before[arm] == unit / width || before[arm] == unit / width + 1, "multiway", "uniform within one tick");
            const uint64_t delta = before[arm] > after[arm] ? before[arm] - after[arm] : after[arm] - before[arm];
            frequency_test_check(delta <= 1, "multiway", "edge permutation within one tick");
        }
        frequency_test_check(sum == unit && before[0] == unit && before[width + 1] == unit, "multiway", "arm and join conservation");
    }
}

static void frequency_test_loops(void)
{
    const uint64_t unit = BUSTER_TIER1_FREQUENCY_ONE;
    FrequencyTestGraph loop = {
        .blocks = 2,
    };
    frequency_test_edge(&loop, 0, 0);
    frequency_test_edge(&loop, 0, 1);
    const uint64_t self[] = { 2 * unit, unit };
    frequency_test_fixture("self-loop-first", &loop, TIER1_FREQUENCY_OK, 128, self, 1, 0);
    loop.edges = 0;
    frequency_test_edge(&loop, 0, 1);
    frequency_test_edge(&loop, 0, 0);
    frequency_test_fixture("self-loop-last", &loop, TIER1_FREQUENCY_OK, 128, self, 1, 0);
    FrequencyTestGraph nested = {
        .blocks = 6,
    };
    frequency_test_edge(&nested, 0, 1);
    frequency_test_edge(&nested, 0, 5);
    frequency_test_edge(&nested, 1, 2);
    frequency_test_edge(&nested, 1, 3);
    frequency_test_edge(&nested, 2, 1);
    frequency_test_edge(&nested, 3, 4);
    frequency_test_edge(&nested, 4, 0);
    const uint64_t nested_exact[] = { 2 * unit, 2 * unit, unit, unit, unit, unit };
    uint64_t before[6] = { 0 };
    frequency_test_fixture("nested-loops", &nested, TIER1_FREQUENCY_OK, 128, nested_exact, 8, before);
    const uint32_t permutation[] = { 4, 2, 5, 0, 3, 1 };
    FrequencyTestGraph relabeled = {
        .blocks = 6,
        .entry = permutation[0],
    };
    uint64_t after[6] = { 0 };
    uint64_t permuted_exact[6];
    for (uint32_t b = 0; b < 6; b += 1)
    {
        permuted_exact[permutation[b]] = nested_exact[b];
    }
    for (uint32_t e = nested.edges; e != 0; e -= 1)
    {
        frequency_test_edge(&relabeled, permutation[nested.sources[e - 1]], permutation[nested.targets[e - 1]]);
    }
    frequency_test_fixture("nested-loops-relabeled", &relabeled, TIER1_FREQUENCY_OK, 128, permuted_exact, 8, after);
    for (uint32_t b = 0; b < 6; b += 1)
    {
        const uint64_t delta = before[b] > after[permutation[b]] ? before[b] - after[permutation[b]] : after[permutation[b]] - before[b];
        frequency_test_check(delta <= 8, "nested-loops", "layout/edge permutation tick bound");
    }
    FrequencyTestGraph slow = {
        .blocks = 65,
    };
    uint64_t slow_exact[65];
    slow_exact[0] = 64 * unit;
    for (uint32_t b = 1; b <= 64; b += 1)
    {
        frequency_test_edge(&slow, 0, b);
        slow_exact[b] = unit;
        if (b < 64)
        {
            frequency_test_edge(&slow, b, 0);
        }
    }
    frequency_test_fixture("slow-exit-bounded-refusal", &slow, TIER1_FREQUENCY_UNCONVERGED, 128, 0, 0, 0);
    frequency_test_fixture("slow-exit-explicit-larger-budget", &slow, TIER1_FREQUENCY_OK, 4096, slow_exact, 64, 0);
}

static void frequency_test_cold_and_nonreturning(void)
{
    const uint64_t unit = BUSTER_TIER1_FREQUENCY_ONE;
    for (uint32_t depth = 5; depth <= 35; depth += 30)
    {
        FrequencyTestGraph cold = {
            .blocks = depth + 2,
        };
        uint64_t exact[BUSTER_FREQUENCY_TEST_BLOCKS];
        uint64_t actual[BUSTER_FREQUENCY_TEST_BLOCKS] = { 0 };
        for (uint32_t b = 0; b < depth; b += 1)
        {
            frequency_test_edge(&cold, b, b + 1);
            frequency_test_edge(&cold, b, depth + 1);
            exact[b] = b <= 32 ? unit >> b : 0;
        }
        frequency_test_edge(&cold, depth, depth + 1);
        exact[depth] = depth <= 32 ? unit >> depth : 0;
        exact[depth + 1] = unit;
        frequency_test_fixture("nested-cold-branches", &cold, TIER1_FREQUENCY_OK, 1, exact, 1, actual);
        if (depth == 5)
        {
            const __uint128_t estimated_saving = (__uint128_t)actual[depth] * 2;
            frequency_test_check(estimated_saving < unit, "nested-cold-branches", "two conditional saves do not repay one entry move");
        }
        // Even a structurally reachable sub-tick cold branch into a closed component must be refused.
        cold.targets[cold.edges - 1] = depth;
        frequency_test_fixture("cold-reachable-closed-cycle", &cold, TIER1_FREQUENCY_NONRETURNING, 128, 0, 0, 0);
    }
    FrequencyTestGraph closed = {
        .blocks = 3,
    };
    frequency_test_edge(&closed, 0, 1);
    frequency_test_edge(&closed, 1, 2);
    frequency_test_edge(&closed, 2, 1);
    frequency_test_fixture("reachable-closed-cycle", &closed, TIER1_FREQUENCY_NONRETURNING, 128, 0, 0, 0);
    closed.sources[0] = 1;
    closed.targets[0] = 1;
    const uint64_t unreachable[] = { unit, 0, 0 };
    frequency_test_fixture("unreachable-cycle-is-zero", &closed, TIER1_FREQUENCY_OK, 128, unreachable, 0, 0);
    const __uint128_t product = (__uint128_t)(64 * unit) * UINT32_MAX;
    frequency_test_check(product > UINT64_MAX, "cost-handoff", "wide arithmetic is necessary for count times Q32 visits");
}

static void frequency_test_refusals(void)
{
    FrequencyTestGraph input = {
        .blocks = 3,
    };
    frequency_test_edge(&input, 0, 1);
    frequency_test_edge(&input, 1, 2);
    FrequencyTestCsr csr = frequency_test_csr(&input);
    frequency_test_run("zero-work", &csr.graph, TIER1_FREQUENCY_WORK_LIMIT, 128, 0, 0, 0, 0);
    frequency_test_run("exhausted-after-validation", &csr.graph, TIER1_FREQUENCY_WORK_LIMIT, 128, 10, 0, 0, 0);
    uint32_t* so = (uint32_t*)csr.graph.successor_offsets;
    so[1] = 3;
    frequency_test_run("bad-offset", &csr.graph, TIER1_FREQUENCY_INVALID, 128, 1000, 0, 0, 0);
    so[1] = 1;
    uint32_t* ss = (uint32_t*)csr.graph.successors;
    ss[0] = 3;
    frequency_test_run("bad-target", &csr.graph, TIER1_FREQUENCY_INVALID, 128, 1000, 0, 0, 0);
    ss[0] = 1;
    uint8_t workspace[88] __attribute__((aligned(8)));
    uint64_t weights[3] = { 7, 8, 9 };
    const uint64_t original[] = { 7, 8, 9 };
    const Tier1FrequencyLimits limits = {
        .rounds = 128,
        .work = 1000,
    };
    Tier1FrequencyStatus status = tier1_frequency_estimate(&csr.graph, &limits, workspace, 83, weights, 3, 0);
    frequency_test_check(status == TIER1_FREQUENCY_CAPACITY && memcmp(weights, original, sizeof(weights)) == 0, "short-workspace", "refusal and unchanged output");
    status = tier1_frequency_estimate(&csr.graph, &limits, workspace, sizeof(workspace), weights, 2, 0);
    frequency_test_check(status == TIER1_FREQUENCY_CAPACITY && memcmp(weights, original, sizeof(weights)) == 0, "short-output", "refusal and unchanged output");
    status = tier1_frequency_estimate(&csr.graph, &limits, workspace + 1, 84, weights, 3, 0);
    frequency_test_check(status == TIER1_FREQUENCY_INVALID && memcmp(weights, original, sizeof(weights)) == 0, "bad-alignment", "refusal and unchanged output");
    free(csr.storage);
    FrequencyTestGraph duplicate = {
        .blocks = 20,
    };
    for (uint32_t b = 1; b < 20; b += 1)
    {
        frequency_test_edge(&duplicate, 0, b);
    }
    frequency_test_edge(&duplicate, 0, 1);
    frequency_test_fixture("duplicate-across-vector-chunks", &duplicate, TIER1_FREQUENCY_INVALID, 128, 0, 0, 0);
    duplicate.edges = 2;
    duplicate.targets[1] = 1;
    frequency_test_fixture("duplicate-inside-vector-chunk", &duplicate, TIER1_FREQUENCY_INVALID, 128, 0, 0, 0);
}

static void frequency_test_guarded_tails(void)
{
    const size_t page = (size_t)sysconf(_SC_PAGESIZE);
    FrequencyTestGraph input = {
        .blocks = 19,
    };
    for (uint32_t b = 1; b < 18; b += 1)
    {
        frequency_test_edge(&input, 0, b);
        frequency_test_edge(&input, b, 18);
    }
    FrequencyTestCsr csr = frequency_test_csr(&input);
    uint8_t* maps[4];
    const uint32_t* columns[] = { csr.graph.successor_offsets, csr.graph.predecessor_offsets, csr.graph.successors, csr.graph.predecessors };
    const uint32_t counts[] = { 20, 20, 34, 34 };
    const uint32_t* guarded[4];
    for (uint32_t i = 0; i < 4; i += 1)
    {
        maps[i] = mmap(0, page * 2, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (maps[i] == MAP_FAILED || mprotect(maps[i] + page, page, PROT_NONE) != 0)
        {
            abort();
        }
        uint8_t* const tail = maps[i] + page - counts[i] * sizeof(uint32_t);
        memcpy(tail, columns[i], counts[i] * sizeof(uint32_t));
        guarded[i] = (const uint32_t*)tail;
    }
    csr.graph.successor_offsets = guarded[0];
    csr.graph.predecessor_offsets = guarded[1];
    csr.graph.successors = guarded[2];
    csr.graph.predecessors = guarded[3];
    frequency_test_run("guard-pages-vector-tails", &csr.graph, TIER1_FREQUENCY_OK, 1, 10000, 0, 0, 0);
    for (uint32_t i = 0; i < 4; i += 1)
    {
        munmap(maps[i], page * 2);
    }
    free(csr.storage);
}

int main(void)
{
    frequency_test_acyclic();
    frequency_test_loops();
    frequency_test_cold_and_nonreturning();
    frequency_test_refusals();
    frequency_test_guarded_tails();
    printf("frequency checks=%u failures=%u\n", frequency_test_checks, frequency_test_failures);
    return frequency_test_failures == 0 ? 0 : 1;
}
