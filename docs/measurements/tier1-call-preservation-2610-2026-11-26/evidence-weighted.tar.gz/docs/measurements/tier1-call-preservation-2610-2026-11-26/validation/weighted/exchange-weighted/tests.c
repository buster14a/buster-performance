// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Focused real-backend tests for complete-mapping epoch/frequency scoring.
#include "../exchange-native/tests.c"

typedef enum WeightedShape
{
    WEIGHTED_ONE_ARM,
    WEIGHTED_BOTH_ARMS,
    WEIGHTED_LAZY,
    WEIGHTED_DISPLACED,
    WEIGHTED_ROW,
    WEIGHTED_NONRETURNING,
} WeightedShape;

static bool weighted_function(Tier1EmitTest* test, WeightedShape shape, IrFunction* function)
{
    const bool lazy = shape == WEIGHTED_LAZY;
    const bool straight = lazy || shape == WEIGHTED_DISPLACED;
    const bool row = shape == WEIGHTED_ROW;
    const bool nonreturning = shape == WEIGHTED_NONRETURNING;
    const IrSizes sizes = {
        .instruction_count = 32,
        .block_count = straight ? 1 : nonreturning ? 3 : 4,
        .parameter_count = lazy ? 1 : 2,
        .constant_count = lazy ? 2 : straight ? 0 : 1,
        .call_count = straight ? (lazy ? 3 : 4) : row ? 3 : shape == WEIGHTED_BOTH_ARMS ? 2 : 1,
        .row_count = row ? 1 : 0,
    };
    bool ready = ir_create(&test->input, &sizes, function) == IR_OK;
    if (ready)
    {
        function->result_type = IR_I64;
        function->symbol_count = 8;
        for (uint32_t p = 0; p < function->parameter_count; p += 1)
        {
            function->parameter_types[p] = IR_I64;
        }
        for (uint32_t call = 0; call < function->call_count; call += 1)
        {
            function->calls[call].result_type = IR_VOID;
        }
        uint32_t next = 0;
        uint32_t call = 0;
        const uint32_t parameter = tier1_select_test_append(function, &next, IR_PARAM, IR_I64, 0, BUSTER_IR_NONE, BUSTER_IR_NONE);
        const uint32_t second = !lazy ? tier1_select_test_append(function, &next, IR_PARAM, IR_I64, 1, BUSTER_IR_NONE, BUSTER_IR_NONE) : BUSTER_IR_NONE;
        const uint32_t address = tier1_select_test_append(function, &next, IR_SYMBOL_ADDR, IR_PTR, 7, BUSTER_IR_NONE, BUSTER_IR_NONE);
        if (lazy)
        {
            function->constants[0].low = UINT64_C(0x123456789abcdef1);
            function->constants[1].low = UINT64_C(0x223456789abcdef3);
            for (uint32_t k = 0; k < 2; k += 1)
            {
                const uint32_t constant = tier1_select_test_append(function, &next, IR_CONST, IR_I64, k, BUSTER_IR_NONE, BUSTER_IR_NONE);
                tier1_select_test_append(function, &next, IR_CALL, IR_VOID, call + 1, call, BUSTER_IR_NONE);
                call += 1;
                tier1_select_test_append(function, &next, IR_STORE, IR_VOID, address, constant, BUSTER_IR_NONE);
            }
            tier1_select_test_append(function, &next, IR_CALL, IR_VOID, call + 1, call, BUSTER_IR_NONE);
            tier1_select_test_append(function, &next, IR_RET, IR_VOID, parameter, BUSTER_IR_NONE, BUSTER_IR_NONE);
        }
        else if (shape == WEIGHTED_DISPLACED)
        {
            // One caller owner is read after calls1..3 and dies before call4. The callee owner survives all4 calls
            // unread until return. This violates pointwise occupied-call subset but saves one weighted record net:
            // caller C1/R3 -> callee C1/R1, with one additional entry copy.
            for (uint32_t k = 0; k < 4; k += 1)
            {
                tier1_select_test_append(function, &next, IR_CALL, IR_VOID, call + 1, call, BUSTER_IR_NONE);
                call += 1;
                if (k < 3)
                {
                    tier1_select_test_append(function, &next, IR_STORE, IR_VOID, address, parameter, BUSTER_IR_NONE);
                }
            }
            tier1_select_test_append(function, &next, IR_RET, IR_VOID, second, BUSTER_IR_NONE, BUSTER_IR_NONE);
        }
        else
        {
            // The second incoming parameter is copied into RBX and consumed before the branch. Its existing
            // callee-save slot is therefore available for a later exchange without introducing a new frame save.
            tier1_select_test_append(function, &next, IR_STORE, IR_VOID, address, second, BUSTER_IR_NONE);
            if (row)
            {
                function->rows[0] = (Tier0Operation){
                    .records = {
                        { .immediate = 7, .rm = BUSTER_TIER0_ROLE_SCRATCH(0), .form = X86_FORM_MOV_R64_IMM64 },
                    },
                    .record_count = 1,
                    .result_class = BUSTER_TYPED_CLASS_VOID,
                };
                function->calls[call].row = 1;
                tier1_select_test_append(function, &next, IR_CALL, IR_VOID, 0, call, BUSTER_IR_NONE);
                call += 1;
            }
            function->constants[0].low = 0;
            const uint32_t zero = tier1_select_test_append(function, &next, IR_CONST, IR_I64, 0, BUSTER_IR_NONE, BUSTER_IR_NONE);
            const uint32_t condition = tier1_select_test_append(function, &next, IR_ICMP, IR_I1, parameter, zero, IR_NE);
            tier1_select_test_append(function, &next, IR_CBR, IR_VOID, condition, 1, 2);
            function->block_offsets[1] = next;
            tier1_select_test_append(function, &next, IR_CALL, IR_VOID, call + 1, call, BUSTER_IR_NONE);
            call += 1;
            tier1_select_test_append(function, &next, IR_BR, IR_VOID, nonreturning ? 1 : 3, BUSTER_IR_NONE, BUSTER_IR_NONE);
            function->block_offsets[2] = next;
            if (shape == WEIGHTED_BOTH_ARMS || row)
            {
                tier1_select_test_append(function, &next, IR_CALL, IR_VOID, call + 1, call, BUSTER_IR_NONE);
                call += 1;
            }
            if (!nonreturning)
            {
                tier1_select_test_append(function, &next, IR_BR, IR_VOID, 3, BUSTER_IR_NONE, BUSTER_IR_NONE);
                function->block_offsets[3] = next;
            }
            tier1_select_test_append(function, &next, IR_RET, IR_VOID, parameter, BUSTER_IR_NONE, BUSTER_IR_NONE);
        }
        function->instruction_count = next;
        function->block_offsets[function->block_count] = next;
    }
    return ready;
}

static Tier1EmitError weighted_prepare(Tier1EmitTest* test, const Tier1SelectPlan* plan, WeightedShape shape,
                                       const Tier1EmitOptions* options, Tier1EmitResult* emitted)
{
    *emitted = (Tier1EmitResult){ .general = true };
    emitted->prepared.vex = !x86_target_form_allowed(test->allowed, X86_FORM_VMOVDQA64_X_XM128);
    emitted->prepared.unsigned_dword_memory_forms = tier1_emit_unsigned_dword_memory_forms(test->allowed);
    emitted->prepared.unsigned_i64_float_forms = tier1_emit_unsigned_i64_float_forms(test->allowed);
    emitted->prepared.avx2 = x86_target_form_allowed(test->allowed, X86_FORM_VPCMPEQD_Y_Y_YM256);
    emitted->prepared.sse = !x86_target_form_allowed(test->allowed, X86_FORM_VMOVDQU_X_XM128);
    emitted->prepared.zmm = x86_target_form_allowed(test->allowed, X86_FORM_VMOVDQA64_Z_ZM512);
    Tier1EmitError error = tier1_emit_cfg_problem(plan, 0, options, &test->output, &test->scratch, emitted);
    if (error == TIER1_EMIT_OK)
    {
        // Controlled legal allocation constraints give the scorer a stable, reviewable baseline. All liveness,
        // fragments, moves and certificates are produced by the real backend. This does not mock its behavior.
        emitted->cfg_input.registers[BUSTER_TIER1_ALLOCATE_GPR] |= emitted->callee_registers;
        uint32_t* allowed = (uint32_t*)emitted->cfg_input.allowed_registers;
        uint32_t* definitions = (uint32_t*)emitted->cfg_input.definition_registers;
        for (uint32_t value = 0; value < emitted->cfg_input.value_count; value += 1)
        {
            const uint32_t node = emitted->value_nodes[value];
            const uint32_t op = plan->function->op[node];
            uint32_t reg = X86_REGISTER_RAX;
            if (op == IR_PARAM)
            {
                reg = plan->function->a[node] == 0 ? X86_REGISTER_RDI : X86_REGISTER_RBX;
                if (definitions != 0 && plan->function->a[node] != 0)
                {
                    definitions[value] = 0;
                }
            }
            else if (shape == WEIGHTED_LAZY && op == IR_CONST)
            {
                reg = X86_REGISTER_RBX;
            }
            allowed[value] = 1u << reg;
        }
        // The full emitter's preference stage may deliberately widen these masks. This fixture exercises the
        // scorer on the constrained baseline itself, using the same complete allocator and independent proof.
        const Tier1CfgError allocated = tier1_cfg_allocate(&emitted->cfg_input, &test->output, &test->scratch, &emitted->cfg);
        error = tier1_emit_cfg_allocated(allocated, &emitted->cfg);
        if (error != TIER1_EMIT_OK)
        {
            printf("weighted allocation refusal shape=%u error=%u\n", shape, error);
        }
    }
    if (error == TIER1_EMIT_OK)
    {
        Tier1CertReport report = { 0 };
        Tier1CertCfgStats stats = { 0 };
        const Tier1CertError verified = tier1_certificate_cfg_check(&emitted->cfg_input, &emitted->cfg, &test->output, &test->scratch, &report, &stats);
        error = verified == TIER1_CERT_OK ? error : TIER1_EMIT_CERTIFICATE;
        emitted->certified = error == TIER1_EMIT_OK;
    }
    return error;
}

static Tier1EmitError weighted_finish(Tier1EmitTest* test, const Tier1SelectPlan* plan, const Tier1EmitOptions* options,
                                      const uint8_t permutation[16], Tier1EmitResult* emitted)
{
    Tier1EmitError error = tier1_emit_cfg_exchange_map(permutation, &test->output, &emitted->cfg_input, &emitted->cfg);
    if (error == TIER1_EMIT_OK)
    {
        emitted->callee_used = tier1_emit_cfg_callee_used(&emitted->cfg, emitted->callee_registers);
        Tier1CertReport report = { 0 };
        Tier1CertCfgStats stats = { 0 };
        const Tier1CertError verified = tier1_certificate_cfg_check(&emitted->cfg_input, &emitted->cfg, &test->output, &test->scratch, &report, &stats);
        error = verified == TIER1_CERT_OK ? error : TIER1_EMIT_CERTIFICATE;
        emitted->certified = error == TIER1_EMIT_OK;
    }
    if (error == TIER1_EMIT_OK)
    {
        error = tier1_emit_cfg_saves(plan, &test->scratch, emitted);
    }
    if (error == TIER1_EMIT_OK)
    {
        emitted->allocation = emitted->cfg.allocation;
        error = tier1_emit_cfg_frame(plan, options, &test->output, &test->scratch, emitted);
    }
    if (error == TIER1_EMIT_OK)
    {
        uint32_t failed = BUSTER_IR_NONE;
        error = tier1_emit_cfg_records(plan, test->allowed, true, false, &test->output, &test->scratch, emitted, &failed);
    }
    if (error == TIER1_EMIT_OK)
    {
        Tier1CertReport report = { 0 };
        Tier1CertEmittedStats stats = { 0 };
        emitted->code_reason = tier1_certificate_emitted_check_debug(plan, emitted, &test->output, &test->scratch, 0, 0, &report, &stats);
        emitted->code_checked = true;
        error = emitted->code_reason == TIER1_CERT_EMITTED_OK ? error : TIER1_EMIT_CERTIFICATE;
    }
    return error;
}

static uint64_t weighted_footprint(const Tier1EmitResult* emitted)
{
    const Tier1CfgInput* input = &emitted->cfg_input;
    const Tier1CfgAllocation* cfg = &emitted->cfg;
    uint64_t hash = UINT64_C(0xcbf29ce484222325);
    for (uint32_t v = 0; v < input->value_count; v += 1)
    {
        hash = (hash ^ input->allowed_registers[v]) * UINT64_C(0x100000001b3);
        hash = (hash ^ (input->definition_registers != 0 ? input->definition_registers[v] : 0)) * UINT64_C(0x100000001b3);
    }
    for (uint32_t f = 0; f < cfg->allocation.fragment_count; f += 1)
    {
        hash = (hash ^ cfg->allocation.starts[f]) * UINT64_C(0x100000001b3);
        hash = (hash ^ cfg->allocation.ends[f]) * UINT64_C(0x100000001b3);
        hash = (hash ^ cfg->allocation.registers[f]) * UINT64_C(0x100000001b3);
        hash = (hash ^ cfg->allocation.kinds[f]) * UINT64_C(0x100000001b3);
    }
    for (uint32_t m = 0; m < cfg->move_count; m += 1)
    {
        hash = (hash ^ cfg->move_sources[m]) * UINT64_C(0x100000001b3);
        hash = (hash ^ cfg->move_destinations[m]) * UINT64_C(0x100000001b3);
    }
    return hash;
}

static void weighted_shape(Tier1EmitTest* test, WeightedShape shape)
{
    const char* const names[] = { "half-diamond tie", "exclusive arms", "lazy owners", "callee demand elsewhere", "physical ROW scratch", "reachable nonreturning arm" };
    IrFunction function = { 0 };
    bool ready = weighted_function(test, shape, &function);
    IrDominance dominance = { 0 };
    ready = ready && tier1_terminal_dominance(test, &function, &dominance);
    Tier1SelectPlan plan = { 0 };
    uint32_t failure = BUSTER_IR_NONE;
    const Tier1SelectError selected = ready ? tier1_select_plan(&function, &dominance, &test->output, &test->scratch, &plan, &failure) : TIER1_SELECT_ERROR_INVALID;
    tier1_emit_test_expect(test, selected == TIER1_SELECT_OK, "weighted fixture passes actual IR selection");
    const Tier1EmitOptions options = { .register_mask = tier1_liveness_register_mask(), .certify = true, .rematerialize = false };
    Tier1EmitResult emitted = { 0 };
    Tier1EmitError error = selected == TIER1_SELECT_OK ? weighted_prepare(test, &plan, shape, &options, &emitted) : TIER1_EMIT_INVALID;
    tier1_emit_test_expect(test, error == TIER1_EMIT_OK && emitted.certified, "weighted fixture has a complete certified baseline allocation");
    if (error == TIER1_EMIT_OK)
    {
        uint32_t entry_location = 0;
        uint8_t entry_kind = UINT8_MAX;
        const bool bound = tier1_cfg_location(&emitted.cfg, emitted.node_values[0], 0, &entry_location, &entry_kind);
        tier1_emit_test_expect(test, bound && entry_kind == BUSTER_TIER1_ALLOCATE_REGISTER && entry_location == X86_REGISTER_RDI &&
                                   (tier1_emit_cfg_callee_used(&emitted.cfg, emitted.callee_registers) & (1u << X86_REGISTER_RBX)) != 0,
                               "the controlled baseline retains incoming RDI and an already used RBX before scoring");
        const uint64_t mark = test->scratch.length;
        const uint64_t footprint = weighted_footprint(&emitted);
        const Tier1CfgInput original_input = emitted.cfg_input;
        const Tier1CfgAllocation original_cfg = emitted.cfg;
        uint8_t permutation[16];
        const bool scored = tier1_emit_exchange_cost(&plan, &emitted, &emitted.cfg_input, &emitted.cfg, &test->scratch, permutation);
        const bool profitable = shape == WEIGHTED_BOTH_ARMS || shape == WEIGHTED_DISPLACED;
        uint32_t changed = 0;
        for (uint32_t r = 0; r < 16; r += 1)
        {
            changed += permutation[r] != r;
        }
        tier1_emit_test_expect(test, scored == (shape != WEIGHTED_NONRETURNING) && changed == (profitable ? 2u : 0u), names[shape]);
        tier1_emit_test_expect(test, test->scratch.length == mark && footprint == weighted_footprint(&emitted) &&
                                   memcmp(&original_input, &emitted.cfg_input, sizeof(original_input)) == 0 && memcmp(&original_cfg, &emitted.cfg, sizeof(original_cfg)) == 0,
                               "weighted scoring and refused flow leave every caller-owned allocation column unchanged");
        if (shape == WEIGHTED_ONE_ARM || shape == WEIGHTED_BOTH_ARMS || shape == WEIGHTED_LAZY || shape == WEIGHTED_DISPLACED)
        {
            Tier1EmitExchangeEpoch epochs = { 0 };
            uint64_t* weights = 0;
            const bool modeled = tier1_emit_exchange_epochs(&plan, &emitted, &emitted.cfg_input, &emitted.cfg, &test->scratch, &epochs) == TIER1_EMIT_OK &&
                                 tier1_emit_exchange_frequency(&emitted.cfg_input, &test->scratch, &weights);
            __int128 caller = 0;
            __int128 callee = 0;
            for (uint32_t b = 0; modeled && b < epochs.blocks; b += 1)
            {
                const uint64_t base = (uint64_t)b * 16;
                caller += (__int128)weights[b] * (epochs.stores[base + X86_REGISTER_RDI] + epochs.loads[base + X86_REGISTER_RDI]);
                callee += (__int128)weights[b] * (epochs.stores[base + X86_REGISTER_RBX] + epochs.loads[base + X86_REGISTER_RBX]);
            }
            const uint64_t one = UINT64_C(1) << 32;
            const uint64_t wanted_caller = shape == WEIGHTED_ONE_ARM ? 1 : shape == WEIGHTED_DISPLACED ? 4 : 2;
            const uint64_t wanted_callee = shape == WEIGHTED_LAZY ? 4 : shape == WEIGHTED_DISPLACED ? 2 : 0;
            tier1_emit_test_expect(test, modeled && caller == (__int128)wanted_caller * one && callee == (__int128)wanted_callee * one,
                                   "actual epochs and uniform paths produce the hand-derived per-invocation preservation cost");
            arena_pop_to(&test->scratch, mark);
            if (shape == WEIGHTED_BOTH_ARMS)
            {
                Arena bounded = test->scratch;
                bounded.capacity = mark;
                uint8_t refused[16];
                memset(refused, 0x5a, sizeof(refused));
                const bool available = tier1_emit_exchange_cost(&plan, &emitted, &emitted.cfg_input, &emitted.cfg, &bounded, refused);
                bool identity = true;
                for (uint32_t r = 0; r < 16; r += 1)
                {
                    identity &= refused[r] == r;
                }
                tier1_emit_test_expect(test, !available && identity && bounded.length == mark && footprint == weighted_footprint(&emitted),
                                       "cost scratch exhaustion preserves the valid allocation and returns identity");
            }
        }
        if (shape != WEIGHTED_NONRETURNING)
        {
            error = weighted_finish(test, &plan, &options, permutation, &emitted);
            tier1_emit_test_expect(test, error == TIER1_EMIT_OK && emitted.certified && emitted.code_checked && emitted.code_reason == TIER1_CERT_EMITTED_OK,
                                   "the selected weighted mapping emits with independent allocation and machine-code certificates");
        }
        printf("weighted %s: scored=%u changed=%u emit=%u C/R=%u/%u entry-binding=%x\n", names[shape], scored, changed, error, emitted.call_stores, emitted.call_loads,
               emitted.cfg_input.definition_registers != 0 ? emitted.cfg_input.definition_registers[emitted.node_values[0]] : 0);
    }
    else
    {
        printf("weighted %s: selection=%u node=%u prepare=%u\n", names[shape], selected, failure, error);
    }
    arena_pop_to(&test->input, 0);
    arena_pop_to(&test->output, 0);
    arena_pop_to(&test->scratch, 0);
}

static void weighted_cycles(Tier1EmitTest* test)
{
    const uint64_t one = UINT64_C(1) << 32;
    const uint64_t weights[1] = { one };
    __int128 columns[16] = { 0 };
    columns[X86_REGISTER_RDI] = 4 * (__int128)one;
    columns[X86_REGISTER_RSI] = 4 * (__int128)one;
    columns[X86_REGISTER_RBX] = 2 * (__int128)one;
    columns[X86_REGISTER_RBP] = 2 * (__int128)one;
    const uint32_t entry[2] = { X86_REGISTER_RDI, X86_REGISTER_RSI };
    Tier1EmitExchangeCall call = {
        .source = { X86_REGISTER_RSI, X86_REGISTER_RBX },
        .destination = { X86_REGISTER_RDI, X86_REGISTER_RSI },
        .count = 2,
        .moves = 2,
    };
    for (uint32_t mapping = 1; mapping < 4; mapping += 1)
    {
        uint8_t permutation[16];
        exchange_test_identity(permutation);
        if ((mapping & 1) != 0)
        {
            permutation[X86_REGISTER_RDI] = X86_REGISTER_RBX;
            permutation[X86_REGISTER_RBX] = X86_REGISTER_RDI;
        }
        if ((mapping & 2) != 0)
        {
            permutation[X86_REGISTER_RSI] = X86_REGISTER_RBP;
            permutation[X86_REGISTER_RBP] = X86_REGISTER_RSI;
        }
        __int128 score = 0;
        const uint64_t mark = test->scratch.length;
        const bool scored = tier1_emit_exchange_score(&call, 1, (1u << X86_REGISTER_RBX) | (1u << X86_REGISTER_RBP), weights, columns,
                                                       entry, entry, 2, 0, permutation, &test->scratch, &score);
        const uint32_t expected = mapping == 1 ? 0 : mapping == 2 ? 1 : 2;
        tier1_emit_test_expect(test, scored && score == (__int128)expected * one && test->scratch.length == mark,
                               "cumulative complete-mapping score charges and removes a real ABI argument cycle exactly");
    }
}

static void weighted_tests(Tier1EmitTest* test)
{
    weighted_cycles(test);
    for (uint32_t shape = 0; shape <= WEIGHTED_NONRETURNING; shape += 1)
    {
        weighted_shape(test, (WeightedShape)shape);
    }
}
