# Issue 2610: weighted exchange qualification

This is a focused, source-level qualification receipt for the isolated production-shaped exchange prototype. It is not a corpus performance result and does not establish that uniform CFG frequencies predict runtime hotness.

## Observed result

`run.log` records **113 checks, 0 failures**, including **70 native checks**, **32 native function executions**, and **0 native skips**. Each execution traversed four hostile ABI helpers. Both the I64 parameter and narrow signed I8 parameter variants passed, including entry binding removal, ABI alignment, return values, and actual machine-code certification.

The six controlled IR cases use the real selector, complete CFG allocator, independent CFG certificate, scorer, exchange map, emitter, and emitted-code certificate. The fixture supplies deliberately constrained legal register masks to make its starting allocation unambiguous; it calls the complete allocator directly so the emitter's separate preference stage cannot widen those masks. The native cases exercise the full production emission path, including that preference stage and the optional exchange placement after order comparison.

| Case | Hand-derived preservation cost, before entry moves | Required decision | Observed |
| --- | --- | --- | --- |
| Call on one half of a diamond | RDI C+R = 1 per invocation; exchanging adds 1 entry move | Identity on an exact tie | Pass |
| One call on each exclusive arm | RDI C+R = 2 per invocation, not 4; exchanging adds 1 entry move | Exchange RDI/RBX | Pass |
| One lazy caller owner, two successive callee owners | RDI C+R = 2; displaced RBX C+R = 4, plus entry move | Identity | Pass |
| Displaced callee remains live at a different call | RDI C+R = 4; RBX C+R = 2, plus entry move | Exchange despite pointwise subset failure | Pass |
| Selected machine ROW with a physical scratch GPR | ROW scratch selection uses a physical caller pool | Identity until that scratch constraint is modeled | Pass |
| Reachable nonreturning arm | Uniform flow cannot terminate with zero residual mass | Refuse scoring and preserve identity | Pass |

The ABI-cycle test invokes the actual move resolver for three complete permutations. One swap creates a three-instruction argument cycle and has score 0; another scores 1; their combined permutation removes that cycle and scores 2. This checks cumulative rescoring instead of assuming that individual pair costs add.

The scorer's bounded-scratch refusal is checked against the caller-owned allocation columns and arena mark. The native cases also retain the existing score-memory and map-memory fallback checks: the optional pass succeeds while preserving the complete original allocation byte-for-byte. Successful controlled mappings receive both allocation and machine-code certificates.

## Exact sources and reproduction

The source tree was based on `8e4d32879e17b7d9548cad54257a2f8461328366`. `source-overlay/` contains exact copies of its changed production files at compilation; `source.sha256` identifies the consumed files. Apply those copies only to a separate checkout of that base. `exchange-native/tests.c` in the evidence archive is the earlier map/native fixture included by this harness. This runner invokes its native cases, not its separate generic map-shape suite.

`generate.c` constructs a focused backend unity from the repository's own `main.c` includes. It stops before the command dispatcher and uses the modules' existing standalone table-storage paths. It does not replace any allocator, scorer, emitter, verifier, certificate, or ABI helper body. Unreachable commands are removed with function/data sections and linker garbage collection.

Run `./replay.sh /absolute/path/to/isolated/source` after placing this directory and the sibling `exchange-native/tests.c` as laid out in the archive. The default compiler is the pinned Clang 23.1.4 path used for the recorded build. `BUSTER_FOCUSED_CLANG` may select an equivalent compiler explicitly. The recorded build used `-O0 -g0`, the repository's native flags and host definitions, and `BUSTER_EXCHANGE_CAPACITY_REFINEMENT=1`. `build.log` is empty because compilation produced no diagnostics.

The earlier preparation attempts were corrected entirely in the test fixture: include RBX in the class pool; use the opcode/rm field for MOV_R64_IMM64's scratch role; and call the complete allocator directly for the controlled masks. No production behavior was changed to make these checks pass.

These tests establish the stated cost-model, safety, ABI, and refusal properties on the included scenarios. Corpus acceptance remains separate; in particular, static equal-branch flow is a heuristic and can still differ from measured execution frequencies.
