#!/usr/bin/env bash
set -euo pipefail

cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
source_root=$(realpath -- "${1:?Pass the isolated source checkout}")
focused_clang=${BUSTER_FOCUSED_CLANG:-/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang}

"$focused_clang" -O2 -Wall -Werror generate.c -o generate
./generate "$source_root/src/buster/compiler/main.c" focused.c
"$focused_clang" -O0 -g0 -march=native \
    "-I$source_root/src" "-I$source_root/src/buster/compiler" \
    -fwrapv -funsigned-char -fno-strict-aliasing \
    -Wall -Werror -Wno-unused-function -fno-stack-protector \
    -DBUSTER_HOST_SSP_DEFAULT=BUSTER_PREDEFINES_SSP_OFF \
    '-DBUSTER_CLANG_DEFAULT_TARGET="x86_64-unknown-linux-gnu"' \
    -DBUSTER_EXECUTABLE_UNIT -DBUSTER_HOST_STATIC=1 \
    -DBUSTER_EXCHANGE_CAPACITY_REFINEMENT=1 \
    -ffunction-sections -fdata-sections -Wl,--gc-sections \
    focused.c -pthread -ldl -o weighted > build.log 2>&1
./weighted > run.log 2>&1
cat run.log
