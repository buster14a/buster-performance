# Restored-environment canonical measurements

This is the original archive's readme. This compact copy includes all eight raw
Callgrind captures and their compressed native/counted stdout/stderr, all count
TSVs/audits, and selected target instruction rows. Complete-program disassemblies
and the full instruction-level join remain in the separately preserved archive
identified by `raw-archive.sha256`; `original-archive-SHA256SUMS` records its full
contents and intentionally also names those omitted files. The packet-root
manifest verifies the included subset.

These captures were made after the executor restart described in the campaign
protocol. The prior raw captures were lost; these are newly executed runs of the
same immutable programs and fixed workload inputs. The raw Callgrind file and
native/counted stdout/stderr for every completed workload were compressed into
this workspace directory before its worker exited. Disassemblies, joined TSVs,
audits and the selected yy_reduce instruction rows are retained here too.

## Identity and protocol

The baseline programs/sidecars are the original mask0 artifacts, byte-identical
to the new weighted compiler's mask0 controls. Weighted compiler mask128 also
passed complete ELF/sidecar parity against the frozen128 controls. The compiler
for mask256 is SHA256
`2d194ea6fc6f62f48ac87cbb72fac8254fd5fb4526e5e5ed2e0c93680ef2c884`, from requested
head `3ec965d8ffea57df950aef046457c20b0efbbf99`.

The programs remain immutable in `experiment-artifacts/0` and
`weighted-artifacts/256`. Their hashes and sidecar hashes are in
`baseline-inputs.sha256` and `candidate-inputs.sha256`. Full corpus/source/compiler
pins and the native/certificate gates are recorded by the validation workflow.

Execution used `measure-2610.c` SHA256
`61af44ef005df0d31bc4ad68ad0d00ab68965f9f68c7e51548433717304d4ab9` and the unchanged
`gap-2610.c` SHA256
`73763316ae4d87024397fb207b6a8d3ce69d93c1c3bab65c80eb217e0721e76b`. The only driver
change since the prior campaign is post-execution compression into an optional
archive directory. Executable paths, program argv, cwd, database paths and
environment settings are unchanged. The driver holds its exclusive suite lock
until all children and archive work have exited.

All command paths below are relative to `/workspace/scratch/f0b04b7641b0` unless
absolute. `SCRIPTS` denotes the unchanged directory
`buster/build/2610-inputs/lua-evidence/docs/measurements/tier1-reciprocal-141-2026-11-01/9700x/lua`;
the historical directory name is input provenance, not a hardware benchmark.
`VALGRIND` and `VALGRIND_LIB` denote
`tools-local/valgrind/usr/bin/valgrind` and
`tools-local/valgrind/usr/libexec/valgrind`, respectively, both passed as absolute
paths. Valgrind is the existing 3.24.0 installation.

```text
./measure-2610 run /tmp/buster-2610-measurements/e000 SCRIPTS VALGRIND VALGRIND_LIB /workspace/scratch/f0b04b7641b0/measurement-restored-2610/e000
./measure-2610 join /tmp/buster-2610-measurements/e000 /workspace/scratch/f0b04b7641b0/gap-2610 '???' 0x108000
./measure-2610 run-pair /tmp/buster-2610-measurements/e256 SCRIPTS VALGRIND VALGRIND_LIB /workspace/scratch/f0b04b7641b0/measurement-restored-2610/e256
```

Mask256 was deliberately limited to SQLite and arithmetic after the static trace
showed no yy_reduce exchange. For these two programs `objdump -d
--no-show-raw-insn` wrote the disassembly; `GAP_EXECUTABLE=PROGRAM gap-2610 count
DISASSEMBLY CAPTURE '???' 0x108000 KINDS` produced each count TSV. The driver's
`summary-file` command produced the two summary rows and their full audits.
No other mask256 Lua workload was captured.

The baseline SQLite instruction detail used the same gap command with
`GAP_INSTRUCTIONS=1`. `call-epochs-count.c` joins those actual emitted-origin
instruction rows by source/destination GPR and reports the entry instruction as
a count witness. The disassembly independently confirms that the witness is the
actual first instruction of yy_reduce.

## Results

All six new baseline joins and both mask256 joins pass exact origin accounting,
unique fitted tag lengths and zero unmatched instructions within the executable.
Outside-object startup/finalizer instructions remain separately reported.

| Workload | Fresh mask0 | Mask256 | Delta |
| --- | ---: | ---: | ---: |
| SQLite | 2,250,814,969 | 2,236,572,790 | -14,242,179 |
| Lua arithmetic | 865,590,587 | 865,586,335 | -4,252 |

For SQLite the C/R reduction is 20,680,856, argument moves decrease 716,572, and
entry moves increase 7,155,249. Spill, edge, rematerialization, frame, branch and
ordinary-node counts are unchanged. The instruction reduction is about 0.633%.
For arithmetic C/R decreases 10,103, entry/argument moves increase 5,853, and frame
instructions decrease 2.

The primary target does not change: yy_reduce remains 103,295,056 instructions,
including 1,851,473 C stores and 2,072,465 R reloads. Independent code comparison
also finds identical yy_reduce instructions, resolved symbolic references and
tags in 0 and 256. These results establish a useful diagnostic but do not satisfy
the requested yy_reduce improvement.

Compared with the preserved pre-restart mask0 summary, all six workloads retain
identical transport/C/R and other non-node category totals. SQLite, arithmetic,
closures and strings have identical complete totals. Calls and tables each
execute two fewer ordinary-node instructions after the restart. That tiny
cross-environment difference is retained explicitly, with no asserted cause;
mask256 above is compared against the fresh paired baseline.

## yy_reduce entry and call-preservation cost

The entry instruction at `0x188830`, `push %rbx`, executes 1,227,631 times. The
function's 3,923,938 C/R records therefore amount to 3.196350 per invocation.

| Abstract register in baseline | C | R | C+R per invocation |
| --- | ---: | ---: | ---: |
| RSI | 725,774 | 795,900 | 1.239521 |
| RDI | 710,597 | 780,723 | 1.214795 |
| R9 | 402,755 | 479,238 | 0.718451 |
| RAX | 12,347 | 16,604 | 0.023583 |

An unconditional entry copy for RSI/RDI would consume most of that gross saving,
leaving about 0.24/0.21 records per invocation before displaced-callee epochs and
argument shuffle changes. This table alone does not establish a profitable
exchange.

The actual indirect table dispatch at `0x188888` executes 1,022,189 times, or
83.265167% of invocations. The range-check bypass is 205,442 invocations,
16.734833%. These counts quantify a concrete difference from the current uniform
lowered-CFG probability, which assigns 50% to each side of that initial guard.

Per-function totals and C/R/ABI deltas are in `e256`. Full new raw captures are
compressed in `e000` and `e256`; the old raw files remain unavailable.
