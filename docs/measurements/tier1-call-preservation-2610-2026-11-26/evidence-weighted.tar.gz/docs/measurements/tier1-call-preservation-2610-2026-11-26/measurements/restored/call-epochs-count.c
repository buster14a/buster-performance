// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
// Summarize exact #ins rows emitted by gap-2610 for one function. The first executed instruction is an entry-count
// witness only after the caller checks the disassembly's actual function entry; this tool prints that instruction.
#define _POSIX_C_SOURCE 200809L
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv)
{
    const char* const names[16] = { "rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi", "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15" };
    uint64_t stores[17] = { 0 };
    uint64_t loads[17] = { 0 };
    uint64_t first = UINT64_MAX;
    uint64_t entries = 0;
    uint64_t total = 0;
    char first_text[256] = { 0 };
    FILE* input = argc == 3 ? fopen(argv[1], "r") : NULL;
    bool ok = input != NULL;
    char* line = NULL;
    size_t capacity = 0;
    while (input != NULL && getline(&line, &capacity, input) >= 0)
    {
        if (strncmp(line, "#ins\t", 5) == 0)
        {
            char* context = NULL;
            char* fields[7];
            uint32_t count = 0;
            for (char* token = strtok_r(line, "\t\n", &context); token != NULL && count < 7; token = strtok_r(NULL, "\t\n", &context))
            {
                fields[count++] = token;
            }
            ok = ok && count == 7;
            if (count == 7 && strcmp(fields[1], argv[2]) == 0)
            {
                const uint64_t address = strtoull(fields[2], NULL, 16);
                const uint64_t executions = strtoull(fields[5], NULL, 10);
                total += executions;
                if (address < first)
                {
                    first = address;
                    entries = executions;
                    snprintf(first_text, sizeof(first_text), "%s", fields[6]);
                }
                const char kind = fields[3][0];
                if (kind == 'C' || kind == 'R')
                {
                    const char* reg = kind == 'C' ? strchr(fields[6], '%') : strrchr(fields[6], '%');
                    uint32_t selected = 16;
                    for (uint32_t r = 0; reg != NULL && r < 16; r += 1)
                    {
                        const size_t length = strlen(names[r]);
                        const bool matches = strncmp(reg + 1, names[r], length) == 0;
                        const bool ended = matches && (reg[length + 1] == 0 || reg[length + 1] == ',' || reg[length + 1] == ' ');
                        if (ended)
                        {
                            selected = r;
                        }
                    }
                    stores[selected] += kind == 'C' ? executions : 0;
                    loads[selected] += kind == 'R' ? executions : 0;
                }
            }
        }
    }
    if (input != NULL)
    {
        ok = !ferror(input) && fclose(input) == 0 && ok;
    }
    free(line);
    ok = ok && first != UINT64_MAX && entries != 0;
    if (ok)
    {
        printf("function\t%s\nfirst_address\t%" PRIx64 "\nfirst_instruction\t%s\nentries\t%" PRIu64 "\ntotal\t%" PRIu64 "\n", argv[2], first, first_text, entries, total);
        printf("register\tC\tR\tC+R\tC+R_per_entry\n");
        uint64_t all_stores = 0;
        uint64_t all_loads = 0;
        for (uint32_t r = 0; r < 17; r += 1)
        {
            all_stores += stores[r];
            all_loads += loads[r];
            printf("%s\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%.9f\n", r < 16 ? names[r] : "other", stores[r], loads[r], stores[r] + loads[r], (double)(stores[r] + loads[r]) / (double)entries);
        }
        printf("all\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%.9f\n", all_stores, all_loads, all_stores + all_loads, (double)(all_stores + all_loads) / (double)entries);
    }
    return ok ? 0 : 1;
}
