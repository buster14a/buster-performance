// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
#define main measure_driver_main
#include "measure-2610.c"
#undef main

int main(void)
{
    char source[] = "/tmp/buster-2610-archive-source-XXXXXX";
    char archive[] = "/tmp/buster-2610-archive-result-XXXXXX";
    const char* const suffixes[] = { "cg", "native.out", "native.err", "callgrind.out", "callgrind.err" };
    const unsigned char bytes[] = { 'c', 'a', 'p', 't', 'u', 'r', 'e', 0, 255, '\n' };
    bool ok = mkdtemp(source) != NULL && mkdtemp(archive) != NULL;
    for (uint32_t i = 0; ok && i < 5; i += 1)
    {
        char path[BUSTER_MEASURE_PATH];
        snprintf(path, sizeof(path), "%s/proof.%s", source, suffixes[i]);
        FILE* file = fopen(path, "wb");
        ok = file != NULL;
        if (file != NULL)
        {
            ok = fwrite(bytes, 1, sizeof(bytes), file) == sizeof(bytes);
            ok = fclose(file) == 0 && ok;
        }
    }
    ok = ok && archive_workload(source, archive, "proof");
    for (uint32_t i = 0; ok && i < 5; i += 1)
    {
        char compressed[BUSTER_MEASURE_PATH];
        char recovered[BUSTER_MEASURE_PATH];
        char errors[BUSTER_MEASURE_PATH];
        snprintf(compressed, sizeof(compressed), "%s/proof.%s.gz", archive, suffixes[i]);
        snprintf(recovered, sizeof(recovered), "%s/proof.%s.recovered", archive, suffixes[i]);
        snprintf(errors, sizeof(errors), "%s/proof.check.err", archive);
        char* args[] = { "gzip", "-d", "-c", compressed, NULL };
        ok = run_command(args, NULL, recovered, errors);
        FILE* file = ok ? fopen(recovered, "rb") : NULL;
        unsigned char readback[sizeof(bytes) + 1];
        ok = ok && file != NULL;
        if (file != NULL)
        {
            ok = fread(readback, 1, sizeof(readback), file) == sizeof(bytes) && memcmp(readback, bytes, sizeof(bytes)) == 0;
            ok = fclose(file) == 0 && ok;
        }
    }
    printf("per-workload archive: %s; five binary payloads recovered exactly\n", ok ? "PASS" : "FAIL");
    return ok ? 0 : 1;
}
