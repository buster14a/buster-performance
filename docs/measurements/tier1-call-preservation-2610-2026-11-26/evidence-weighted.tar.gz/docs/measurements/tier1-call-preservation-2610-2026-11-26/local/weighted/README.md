# Weighted exchange: hosted compiler and corpus validation

**Correctness and control gates passed. Mask 256 leaves `yy_reduce` unchanged
apart from linked address displacements, so it does not solve the primary
target of issue #2610.** Fresh dynamic measurements are owned separately by
allocation-design. This record makes no performance acceptance or timing claim.

## Compiler identity

| Field | Recorded identity |
|---|---|
| Requested source | `3ec965d8ffea57df950aef046457c20b0efbbf99` |
| Requested tree | `6d8ad37a3d09cc36736af79e371371ccffc32a07` |
| Actual hosted merge | `298b9d7189127039b433a2007497e171425312e0` |
| Actual tree | `a1d20ab296ebf48ad85c12210dd089568e6fab44` |
| Main parent | `74eacd4744a8131ba4c1a5bd8ad87b89ec0f7dbe` |
| Workflow / artifact | `45813208911` / `15113529524` |
| Product row | `vector none O3` |
| Compiler SHA256 | `2d194ea6fc6f62f48ac87cbb72fac8254fd5fb4526e5e5ed2e0c93680ef2c884` |
| Downloaded ZIP SHA256 | `921a72fb75a67d5c6f0bfccfee066f3be686e6dc63301e4907b40eb5d293a9e3` |
| ZIP bytes | 84,775,539 |

The product manifest checks every extracted file. All nine staged compiler
source blobs, including `main.c`, exactly match the actual merge tree. Its main
parent is the same as the preceding exchange and trace products. The
branch-to-merge diff adds prior frontend/checker, Tier0, tests, documentation and
CI-cost changes, with no Tier1 allocator/emitter or workflow changes. The exact
paths, blob IDs and provenance are in `merge-provenance.json`.

## Executed gates

From the task root, `bash weighted-artifacts/run-corpus.sh` ran masks **0, 128,
256** sequentially at one compile lane, then the extra mask-256 validation.
`executed-scripts.sha256` identifies the exact scripts used. The earlier
`prepared-scripts.sha256` is a historical preparation receipt and predates the
trace option; it is not the executed-script identity.

The scripts reuse the frozen SQLite/Lua sources, common unity source path,
source order, flags, fixed Lua hash seed, resource directory and original native
oracles. For all three masks:

- The six-function frame fixture is fully code-certified and matches its native
  Clang oracle, with no uncertified functions or fallback/internal/resource failures.
- SQLite compiles all 2,709 functions, with no fallback/internal/resource failures.
  Native verification yields
  `1248168 a7fa3957840af6d608d53fcdd57a125b35385b9d1e813739`.
- Lua compiles 1,086 of 1,087 functions. Its only fallback is the original
  `luaD_rawrunprotected` unsupported lowering. All five native outputs match the
  original Clang-O0 oracles exactly.

Mask 0 reproduces the **entire ELF** of both original baseline programs and the
original origin sidecars. Mask 128 reproduces the **entire ELF and sidecars** of
the frozen exchange-128 programs. Both controls passed before mask 256 was built.

Mask 256 passes the full `test-tier1-emit` suite: **257,194 checks, zero
failures**. Its SQLite `--tier1 --verify` build compiles all 2,709 functions with
2,351 code-certified and 74 uncertified, matching established coverage and no
fallback/internal/resource failures. The verified whole ELF and origin sidecar
are byte-identical to the ordinary mask-256 outputs. This is not an all-function
emitted-code certificate claim. Logs and SHA256 receipts are retained by mask.

SQLite mask 256 enables `BUSTER_TIER1_EXCHANGE_TRACE=26310`; the trace changes no
allocation decision. SQLite and Lua CFG dumps use the existing minimum-block
threshold 300. The working dumps are retained separately, not copied into the
compact packet.

## `yy_reduce` target identity

The weighted trace supports all 617 calls and converges on all 1,910 blocks.
All 24 eligible pair scores are negative. The least negative scores are
RSI/R15 at -0.195837039500 and RDI/R15 at -0.223028070759 estimated records per
invocation. No exchange is selected. These are uniform-branch heuristic costs,
not measured execution frequencies or a speed guarantee.

The complete `yy_reduce` origin-tag row is byte-identical, SHA256
`5b0423eef2842061fc3de70ba1a9ca954beb5c17a0007c2c0d6f9a3b59020556`.
Both ELF symbols are **50,459 bytes** and decode to **12,103 instructions**.
The symbol moves from `0x188830` to `0x181b70` because other functions change.
Consequently, raw linked function bytes are not identical. The strict comparator
checks the complete function and establishes:

- The same instruction offsets, lengths, registers, widths, ordinary immediates,
  addressing modes, branch destinations and symbolic call/data targets.
- Exact raw bytes for 11,289 instructions.
- Only one verified PC-relative disp32 differs in each of the remaining 814
  instructions: 613 direct calls and 201 RIP-relative data/function accesses.
  Each displacement decodes to the corresponding printed target; all other bytes
  are identical, and both target symbolic identities match.

`yy-reduce-code-parity.txt` records every accepted relocation and the final PASS;
`yy-reduce-code-parity.err` is empty. `compare-function.c` contains the complete
strict comparator, and the two disassemblies preserve its actual inputs. This
establishes unchanged allocation/instruction structure for the target, not
identity of other functions or the whole mask-256 executable.

Exact target comparison commands, from the task root:

```sh
objdump -d -w -M intel --disassemble=yy_reduce weighted-artifacts/0/speedtest1 > weighted-artifacts/yy-reduce-0.dis
objdump -d -w -M intel --disassemble=yy_reduce weighted-artifacts/256/speedtest1 > weighted-artifacts/yy-reduce-256.dis
awk -F '\t' '$1=="yy_reduce" {print;found=1} END {exit !found}' weighted-artifacts/0/speedtest1.kinds > weighted-artifacts/yy-reduce-0.kinds
awk -F '\t' '$1=="yy_reduce" {print;found=1} END {exit !found}' weighted-artifacts/256/speedtest1.kinds > weighted-artifacts/yy-reduce-256.kinds
cmp weighted-artifacts/yy-reduce-0.kinds weighted-artifacts/yy-reduce-256.kinds
/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang -std=c17 -O2 -Wall -Wextra -Werror weighted-artifacts/compare-function.c -o weighted-artifacts/compare-function
weighted-artifacts/compare-function weighted-artifacts/yy-reduce-0.dis weighted-artifacts/yy-reduce-256.dis > weighted-artifacts/yy-reduce-code-parity.txt 2> weighted-artifacts/yy-reduce-code-parity.err
rg '^WEIGHTED' weighted-artifacts/256/st-build.txt > weighted-artifacts/yy-reduce.trace
```

No prepared executable was modified by these read-only inspections. SQLite is
public domain; the compact packet retains its notice and the Lua MIT notice.
No further optional compiler or native tests were run after these gates.
