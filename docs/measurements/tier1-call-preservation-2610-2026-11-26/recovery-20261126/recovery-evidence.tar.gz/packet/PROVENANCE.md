# Source, artifact and input identities

This is the November 26, 2026 recovery session's recapture of the old frozen
candidate 1024. The compiler and source are unchanged from the prior session.

## Compiler

- Repository: buster14a/buster, GitHub repository ID 1421805693.
- Measurement PR: https://github.com/buster14a/buster/pull/3639.
- Requested head: 79510829fb67510fb1ac2dfe4a28a0a12a9f2912.
- Base: 74eacd4744a8131ba4c1a5bd8ad87b89ec0f7dbe.
- Actual test merge: 0bdefd975178987e4e697154785459bb995d38a4.
- Actual merge tree: 6e15050f83bfd1a2d5667e6f47c8621210467816.
- Merge parents, ordered: 74eacd4744a8131ba4c1a5bd8ad87b89ec0f7dbe,
  79510829fb67510fb1ac2dfe4a28a0a12a9f2912.
- Hosted run: https://github.com/buster14a/buster/actions/runs/45844778824.
- Compiler product artifact: 15130403006.
- Product ZIP size: 84,918,661 bytes.
- Product ZIP SHA256:
  096c759d1cfb5da5e5fb7dd39b8a2db7da206e649868dc7aaf76796b6a784112.
- Compiler binary SHA256:
  ef2705db18a48b901638f03bbe7ac9b4c196ee8460445f6c5b40c0b9cba5eee7.
- Product row: vector none O3.
- Original product identity, compile command database, provenance and external
  file manifest are retained under metadata/product.

The paired programs are built by this same compiler with experimental masks
0 and 1024. The archive does not include the compiler or generated binaries.
The target trace is diagnostic-only and selected by instruction count 26310.

## Inputs

- Hosted input artifact: 15130172676 from the same run.
- Input ZIP size: 64,082,047 bytes.
- Input ZIP SHA256:
  5bbb1ed386a4ed5fdcf294af31c06f965805b455d7fdd2ef65797186d28ce6d0.
- SQLite corpus archive:
  https://github.com/buster14a/buster-performance/releases/download/ci-corpora-preprocessor-391e729af658/preprocessor-391e729af658-ci.tar.zst.
- Corpus archive SHA256:
  ceb39bf938cd7a7469bbb53646c3318d0cbfdac4d37b6d05b183c4fd0b9898c2.
- SQLite 3.53.2 sqlite3.c SHA256:
  0a409f1633283fa31a9126b11fbfd64a1991c5d30defad07e5745d4667f5e23d.
- sqlite3.h SHA256:
  9e69a1353a4288450b0d5239ede11fc7f1f4c8e5eb07491fc8317eacb5b7de7e.
- speedtest1.c source:
  https://raw.githubusercontent.com/sqlite/sqlite/ccc132c5be20ab5c755c97a08d06b1b592fef330/test/speedtest1.c.
- speedtest1.c SHA256:
  b5eaf4bbcbb320fd8eb3f3e6c4cd5f51a64dd0cd70efe969634d1785e3419675.
- Lua source: https://www.lua.org/ftp/lua-5.4.8.tar.gz.
- Lua archive SHA256:
  4f18ddae154e793e46eeab727c59ef1c0c0c2b744e7b94219710d76f530629ae.
- Lua scripts: buster-performance commit
  818cfbbc0be238da287c16d8e2a91fd7275cf228, directory
  docs/measurements/tier1-reciprocal-141-2026-11-01/9700x/lua.
  The directory name identifies historical inputs, not execution hardware.
- Individual source/script digests are in inputs/workload-inputs.sha256,
  relative to the recovered inputs root.

The control SQLite compilation used the resource headers in the frozen corpus;
the candidate SQLite and both Lua compilations used the separately restored
LLVM 23.1.4 resource headers. Both complete header inventories are retained in
inputs. Complete control executable and sidecar parity were verified against
the older archived controls.

## Tools and host

- Clang: 23.1.4, LLVM commit 7a941dfb2877a0b8cf30323fefa85ad019e0b0f5.
- LLVM archive SHA256:
  efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378.
- Valgrind package:
  https://deb.debian.org/debian/pool/main/v/valgrind/valgrind_3.24.0-3_amd64.deb.
- Valgrind package SHA256:
  0359e30820ccee7ee5c8d4c951ca276e3978b18f157d71bd77981de05b344907.
  This is exactly the package hash recorded in the prior session.
- Native/counting host: AMD EPYC 9V74, Linux 6.18.57, glibc 2.41.
- Disassembler: GNU objdump 2.44.
- C measurement helpers were restored unchanged from the preceding weighted
  archive. Their SHA256 values remain:
  - measure-2610.c:
    61af44ef005df0d31bc4ad68ad0d00ab68965f9f68c7e51548433717304d4ab9.
  - gap-2610.c:
    73763316ae4d87024397fb207b6a8d3ce69d93c1c3bab65c80eb217e0721e76b.

The original instrument-origin tagging was adapted from buster-performance
commit ddb5213da1fce7ac9325afbf6364a797bbc63b5b,
docs/measurements/tier1-dominator-places-2553-2026-11-12/scripts/kinds-2553.patch.
The C join helper retains its original #1189/#2553 attribution and the #2610
executable-range correction. No helper implementation is changed here.

## Evidence lineage

The input evidence archives were recovered from buster-performance campaign
commit 4b7481be76d5b93497a1530a3115c6ab51fae17f:
- evidence-weighted.tar.gz:
  5a166ec22fe2e4a0fd52ce3e77ad185b53cae21b64dfb23a23c85ae1236ce919.
- evidence-regional-512.tar.gz:
  9a06db88fe167ecb6604c391d5ac3b4ae5702e36a5c3ded76df4bc2984b904ee.

The four captures in this packet were generated anew in the recovery session.
The old reports' lost-raw-file caveats remain in force for those old captures.
No 9700X result is newly produced or claimed.

Agent session: 6b086a82-e9b8-83eb-aad4-587684d3a052 (OpenAI session ID; no share URL is exposed)
Model: OpenAI / GPT-6 Astra Pro
