# Retained component notices

The unchanged Buster measurement helpers and tiny unity wrapper are recovered
from the earlier campaign under the project's existing Apache-2.0 WITH
LLVM-exception terms. Their original source headers and attribution are
preserved. The gap helper retains its #1189/#2553 history and existing #2610
executable-range adaptation. Source revisions and digests are in PROVENANCE.md.
The recovery documentation and original measurement records use the project
default terms.

SQLite 3.53.2 and speedtest1.c are public-domain SQLite source. Generated
function names, instruction-origin sidecars and execution reports derive from
those programs. The SQLite disclaimer/blessing is in
licenses/SQLite-public-domain.txt.

Lua 5.4.8 is MIT-licensed, Copyright (C) 1994-2025 Lua.org, PUC-Rio. Its complete
notice is in licenses/Lua-5.4.8.txt. Lua function names, origin sidecars and
execution reports derive from that release.

The external LLVM/Clang, GNU compiler/binutils, system libraries and Valgrind
retain their own terms. This packet does not redistribute their binaries,
third-party runtime libraries, full program source, generated program
executables or disassembly. Digests and external manifests identify those
reproducible inputs without changing their terms.
