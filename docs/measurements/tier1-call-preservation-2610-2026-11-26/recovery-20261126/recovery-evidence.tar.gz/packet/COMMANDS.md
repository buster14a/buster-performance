# Executed commands and reproduction

These are the recovery session's actual compilation and measurement invocations,
with repeated paths parameterized below. They are recorded from the root agent's
executed calls, not inferred from compilation log contents. Helper regeneration
and the additional native-oracle checks are stated separately. Neither compiler
elapsed times nor host benchmark timings are used as evidence.

## Workspace and helpers

```sh
cd /workspace/scratch/eeeceb19ae05/recovered
rec="$PWD"
compiler="$rec/product/product/bin/compiler"
resource="$rec/tooling/llvm-23.1.4/lib/clang/23/include"
scripts="$rec/inputs/lua-scripts"
measure="$rec/campaign/measure-2610"
gap="$rec/campaign/gap-2610"
valgrind="$rec/tooling/valgrind/usr/bin/valgrind"
valgrind_lib="$rec/tooling/valgrind/usr/libexec/valgrind"
```

The unchanged helper source files are in tools/ in this packet. Rebuild them,
for example, with the recovered C compiler toolchain:

```sh
gcc -O2 -Wall -Wextra tools/measure-2610.c -o measure-2610
gcc -O2 -Wall -Wextra tools/gap-2610.c -o gap-2610
```

Their original executed binary digests are in metadata/external-tools.sha256;
that manifest's absolute paths refer to the recovery workspace. Source digests
and behavior are the reproducible helper contract.

## SQLite compilation

Control:

```sh
BUSTER_TIER1_EXPERIMENT=0 \
BUSTER_TIER1_KINDS="$rec/campaign/old-control/speedtest1.kinds" \
"$compiler" --tier1 --lanes 1 \
  -isystem "$rec/inputs/corpus/headers/usr/lib/clang/23/include" \
  -fno-asynchronous-unwind-tables --tier1-report \
  -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 \
  -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE \
  "-I$rec/inputs/corpus/sqlite" "-I$rec/inputs" \
  -o "$rec/campaign/old-control/speedtest1" \
  "$rec/campaign/speedtest1-unity.c" -lm \
  > "$rec/campaign/old-control/st-build.txt" 2>&1
```

Candidate:

```sh
BUSTER_TIER1_EXPERIMENT=1024 BUSTER_TIER1_EXCHANGE_TRACE=26310 \
BUSTER_TIER1_KINDS="$rec/campaign/old-1024/speedtest1.kinds" \
"$compiler" --tier1 --lanes 1 -isystem "$resource" \
  -fno-asynchronous-unwind-tables --tier1-report \
  -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 \
  -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE \
  "-I$rec/inputs/corpus/sqlite" "-I$rec/inputs" \
  -o "$rec/campaign/old-1024/speedtest1" \
  "$rec/campaign/speedtest1-unity.c" -lm \
  > "$rec/campaign/old-1024/st-build.txt" 2>&1
```

The exact unity wrapper is inputs/speedtest1-unity.c in this packet. There are
no additional target-ISA flags. The two resource-header inventories are
recorded independently.

## Lua compilation

The source order is identical to the original campaign's scripts/reproduce.sh.
Both variants use the restored LLVM resource-header path:

```sh
sources=()
for unit in lapi lcode lctype ldebug ldo ldump lfunc lgc llex lmem lobject lopcodes lparser lstate lstring ltable ltm lundump lvm lzio lauxlib lbaselib lcorolib ldblib liolib lmathlib loadlib loslib lstrlib ltablib lutf8lib linit lua; do
  sources+=("$rec/inputs/lua-5.4.8/src/$unit.c")
done
```

The two executed invocations are represented by mask/label pairs
`0 old-control` and `1024 old-1024`:

```sh
BUSTER_TIER1_EXPERIMENT="$mask" \
BUSTER_TIER1_KINDS="$rec/campaign/$label/lua.kinds" \
"$compiler" --tier1 --lanes 1 -isystem "$resource" \
  -fno-asynchronous-unwind-tables --tier1-report \
  -std=gnu99 -DLUA_COMPAT_5_3 -DLUA_USE_LINUX '-Dluai_makeseed(L)=0' \
  -o "$rec/campaign/$label/lua" "${sources[@]}" -lm -ldl \
  > "$rec/campaign/$label/lua-build.txt" 2>&1
```

## Paired captures

Both commands ran from the recovered workspace, sequentially. The driver holds
the same suite lock for each complete pair:

```sh
"$measure" run-pair "$rec/campaign/old-control" "$scripts" \
  "$valgrind" "$valgrind_lib" "$rec/campaign/old-control/raw"
"$measure" run-pair "$rec/campaign/old-1024" "$scripts" \
  "$valgrind" "$valgrind_lib" "$rec/campaign/old-1024/raw"
```

The driver sets `LC_ALL=C`, `TZ=UTC`, `VALGRIND_LIB` and `SQLITE_TMPDIR`.
It copies each variant to the same executable paths under
`/tmp/buster-2610-current`, uses that directory's exclusive suite lock, removes
old measured database files, and keeps the database/temp directory layout,
arguments and per-workload cwd fixed.

SQLite's native verification invocation is:

```text
/tmp/buster-2610-current/speedtest1 --shrink-memory --reprepare --stats --journal wal --size 5 --heap 40000000 64 --testset mix1 --verify verify.db
```

Its counted invocation uses `count.db` and omits `--verify`. Both run from
`/tmp/buster-2610-current/sqlite-data`. The Lua pair invokes the shared
`/tmp/buster-2610-current/lua arithmetic.lua` from the frozen scripts directory.
Callgrind receives `--tool=callgrind --dump-instr=yes --error-exitcode=99` and
the per-workload `--callgrind-out-file`. These exact commands appear in the
compressed Callgrind stderr files too.

## Disassembly, joins and summaries

For each variant, disassemble speedtest1 and lua:

```sh
objdump -d --no-show-raw-insn "$out/speedtest1" > "$out/speedtest1.dis"
objdump -d --no-show-raw-insn "$out/lua" > "$out/lua.dis"
```

For the SQLite workload select `program=speedtest1`,
`workload=speedtest1`; for Lua arithmetic select `program=lua`,
`workload=arithmetic`:

```sh
GAP_EXECUTABLE="$out/$program" "$gap" count \
  "$out/$program.dis" "$out/$workload.cg" '???' 0x108000 \
  "$out/$program.kinds" > "$out/$workload.tsv"
"$measure" summary-file "$out/$workload.tsv" "$workload" \
  > "$out/$workload.summary.tsv" 2> "$out/$workload.audit.txt"
```

The joined tables, summaries and audits are included. The large disassemblies
and uncompressed captures are omitted; their digests are recorded with the
external executable digests. The compressed captures reproduce the originals.

For each workload, the complete per-function and separate traffic comparisons
were generated with:

```sh
"$measure" compare-functions "$control/$workload.tsv" "$candidate/$workload.tsv"
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" SLCTURehxtu
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" SLTtUu
```

## Additional native-oracle checks

SQLite's verification hash and Lua arithmetic's stdout are checked from the
native outputs already produced by run-pair. The other four Lua scripts are
additionally executed for both variants:

```sh
(cd "$scripts" && LC_ALL=C TZ=UTC "$out/lua" "$workload.lua") \
  > "$validation/$workload.out" 2> "$validation/$workload.err"
cmp "$validation/$workload.out" "$packet/oracles/$workload.clang0.out"
test ! -s "$validation/$workload.err"
```

The extra workloads are calls, closures, strings and tables. The archived
Clang oracle stdout is unchanged from the prior campaign. All ten comparisons
pass. These four additional workloads have native correctness receipts only;
they have no new Callgrind capture in this packet.
