## Frozen inputs

- Hosted input artifact 15130172676, run 45844778824.
- Input ZIP size: 64,082,047 bytes.
- Input ZIP SHA256:
  5bbb1ed386a4ed5fdcf294af31c06f965805b455d7fdd2ef65797186d28ce6d0.
- SQLite corpus:
  https://github.com/buster14a/buster-performance/releases/download/ci-corpora-preprocessor-391e729af658/preprocessor-391e729af658-ci.tar.zst.
- Corpus SHA256:
  ceb39bf938cd7a7469bbb53646c3318d0cbfdac4d37b6d05b183c4fd0b9898c2.
- SQLite 3.53.2 sqlite3.c SHA256:
  0a409f1633283fa31a9126b11fbfd64a1991c5d30defad07e5745d4667f5e23d.
- sqlite3.h SHA256:
  9e69a1353a4288450b0d5239ede11fc7f1f4c8e5eb07491fc8317eacb5b7de7e.
- speedtest1.c source:
  https://raw.githubusercontent.com/sqlite/sqlite/ccc132c5be20ab5c755c97a08d06b1b592fef330/test/speedtest1.c.
- speedtest1.c SHA256:
  b5eaf4bbcbb320fd8eb3f3e6c4cd5f51a64dd0cd70efe969634d1785e3419675.
- Lua 5.4.8 source: https://www.lua.org/ftp/lua-5.4.8.tar.gz.
- Lua archive SHA256:
  4f18ddae154e793e46eeab727c59ef1c0c0c2b744e7b94219710d76f530629ae.
- Lua script source: buster-performance commit
  818cfbbc0be238da287c16d8e2a91fd7275cf228, path
  docs/measurements/tier1-reciprocal-141-2026-11-01/9700x/lua.
  The path is historical input provenance, not this campaign's execution host.
- Individual input digests: inputs/workload-inputs.sha256 (71 entries),
  relative to the recovered inputs root.
- LLVM resource-header inventory: inputs/resource-headers.sha256 (327 entries),
  relative to tooling/llvm-23.1.4/lib/clang/23/include.
- Native oracle files are unchanged from the recovered campaign.

## Toolchain, measurement helpers and host

- Clang 23.1.4, LLVM commit 7a941dfb2877a0b8cf30323fefa85ad019e0b0f5.
- LLVM archive SHA256:
  efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378.
- Configured build tools: CMake 4.4.3 and Ninja 1.13.2.
- Valgrind 3.24.0-3 Debian package:
  https://deb.debian.org/debian/pool/main/v/valgrind/valgrind_3.24.0-3_amd64.deb.
- Valgrind package SHA256:
  0359e30820ccee7ee5c8d4c951ca276e3978b18f157d71bd77981de05b344907.
  This is the same package hash as the original campaign.
- Host: AMD EPYC 9V74, Linux 6.18.57, glibc 2.41.
- C helper compiler: GCC 14.2.0-19; disassembler: GNU objdump 2.44.
- Unchanged measure-2610.c SHA256:
  61af44ef005df0d31bc4ad68ad0d00ab68965f9f68c7e51548433717304d4ab9.
- Unchanged gap-2610.c SHA256:
  73763316ae4d87024397fb207b6a8d3ce69d93c1c3bab65c80eb217e0721e76b.

Actual helper binary and restored tool archive digests are retained in
metadata/external-tools.sha256. Original instruction-origin tagging was
adapted from buster-performance ddb5213da1fce7ac9325afbf6364a797bbc63b5b,
docs/measurements/tier1-dominator-places-2553-2026-11-12/scripts/kinds-2553.patch.
The gap helper retains the original #1189/#2553 attribution and the #2610
executable-range correction. Neither helper implementation changes here.

