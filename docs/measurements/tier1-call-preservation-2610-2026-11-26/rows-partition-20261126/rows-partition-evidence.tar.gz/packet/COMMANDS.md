# Executed commands and independent postprocessing

## Exact command records

Two plain-text records retain the actual orchestration arguments:

- metadata/build-parity-emitter-commands.txt: compiler build and frozen binary
  copy, partition-control compilation with --verify, whole-ELF comparisons,
  default emitter suite and the initially failing enabled emitter suite.
- metadata/executed-commands.txt: row-only and combined SQLite/Lua compilation,
  both run-pair invocations, hard-link preparation of the row full-suite
  directory, full six-workload run and join.

These records use the actual recovery workspace paths and preserve the
complete 33-source Lua ordering and fixed seed. No compiler-build command is
reconstructed for this packet. The immutable source and compiler digest are
recorded in PROVENANCE.md and metadata/source-and-modes.json.

The frozen compiler build used:

```sh
# CWD: /workspace/scratch/eeeceb19ae05/buster-current-measurement
PATH="$PWD/../recovered/tooling/llvm-23.1.4/bin:$PWD/../toolchain/cmake-4.4.3-ninja-1.13.2/bin:$PATH" \
BUSTER_TOOLCHAIN=path BUSTER_HOST_ARCH=vector BUSTER_DEBUG_INFO=0 \
BUSTER_PARALLEL_CODEGEN=0 ./build.sh --config Release --jobs 2 \
  > ../recovered/campaign/branch-partition-rows-build.log 2>&1
cp -- build/cmake/vector-g0/Release/compiler \
  ../recovered/campaign/compiler-branch-partition-rows
```

Every new workload compilation uses the same frozen input/resource-header
paths and options as the preceding campaign, plus --verify. Exact mode
settings are:

| Variant | Command-local settings |
| --- | --- |
| partition-control SQLite | EXPERIMENT=0, PARTITION_PARAMETERS=1, EXCHANGE_TRACE=26310, program KINDS |
| partition-control Lua | EXPERIMENT=0, PARTITION_PARAMETERS=1, program KINDS |
| current-rows | EXPERIMENT=0, PARAMETER_ROWS=1, EXCHANGE_TRACE=26310, program KINDS |
| current-branch-partition-rows | EXPERIMENT=2048, REGION_WORK=8589934592, BATCH_BRANCH_COST=1, PARTITION_PARAMETERS=1, PARAMETER_ROWS=1, EXCHANGE_TRACE=26310, program KINDS |

Each setting has the BUSTER_TIER1_ prefix. The two candidate SQLite commands
also set DUMP_BLOCKS=1900 and their DUMP_FILE; Lua does not. The exact records
are authoritative for quoting, paths and arguments.

## Capture context

The unchanged measure-2610 C driver fixes executable locations under
/tmp/buster-2610-current and holds that directory's exclusive lock through
the full invocation. It sets LC_ALL=C, TZ=UTC, VALGRIND_LIB and SQLITE_TMPDIR
and fixes cwd, databases and workload arguments.

SQLite native verification is:

```text
/tmp/buster-2610-current/speedtest1 --shrink-memory --reprepare --stats --journal wal --size 5 --heap 40000000 64 --testset mix1 --verify verify.db
```

The counted invocation uses count.db and omits --verify. Lua executes each
named script from the frozen scripts directory with the fixed program path.
Callgrind arguments include --tool=callgrind --dump-instr=yes --error-exitcode=99
and the per-workload --callgrind-out-file. The original argv is also present
in retained compressed stderr.

The same measurement tool produces the two initial pair captures and the
later full-suite row capture. The latter runs on identical hard-linked
programs and sidecars, not on a newly rebuilt compiler or program. The six
control captures are reused from the preceding current-main evidence.

## Unchanged helper build and joins

From an extracted packet:

```sh
gcc -O2 -Wall -Wextra tools/measure-2610.c -o measure-2610
gcc -O2 -Wall -Wextra tools/gap-2610.c -o gap-2610
```

The actual helper binary hashes are in metadata/external-tools.sha256.
For each program, full disassembly was produced with:

```sh
objdump -d --no-show-raw-insn "$out/$program" > "$out/$program.dis"
```

For SQLite set program=speedtest1, and for each Lua workload set program=lua.
The join and independent summary commands are:

```sh
GAP_EXECUTABLE="$out/$program" "$gap" count \
  "$out/$program.dis" "$out/$workload.cg" '???' 0x108000 \
  "$out/$program.kinds" > "$out/$workload.tsv"
"$measure" summary-file "$out/$workload.tsv" "$workload" \
  > "$out/$workload.summary.tsv" 2> "$out/$workload.audit.txt"
```

The row full-suite command used measure-2610 join as retained in
metadata/executed-commands.txt; that driver applies the same join convention.
Full joins and independently regenerated summaries/audits are archived.

## Function/category comparison

For every captured candidate workload, the baseline is current-0 unless a
table explicitly says combined-versus-rows. Independent postprocessing used:

```sh
"$measure" compare-functions "$control/$workload.tsv" "$candidate/$workload.tsv"
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" SLCTURehxtu
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" SLTtUu
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" CR
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" ehxTtUu
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" a
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" r
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" f
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" n
"$measure" compare-origins "$control/$workload.tsv" "$candidate/$workload.tsv" j
```

The origins select transport union, spills/reloads, call preservation, edges,
argument copies, rematerialization, frames, nodes and control respectively.
The union deduplicates overlapping spill and edge origins. Argument and
control-origin costs are separate. Sign-count and positive-row tables are
direct postprocessing of these complete per-function outputs.

The extra combined-versus-rows comparison uses current-rows-all as control
and current-branch-partition-rows as candidate for the two common workloads.
Both the total and transport per-function deltas are retained.

## Tokenizer and native validation

The targeted tokenizer excerpts are derived from each full disassembly,
whose SHA256 is retained externally. Absolute instruction addresses and
numeric target addresses are stripped, preserving all symbolic target names.
After that, only signed hexadecimal RIP displacements are normalized:

```sh
sed -E 's/-?0x[0-9a-f]+\(%rip\)/RIP_DISPLACEMENT(%rip)/g' \
  results/tokenizer/VARIANT.asm > results/tokenizer/VARIANT.normalized.asm
cmp results/tokenizer/current-0.normalized.asm results/tokenizer/VARIANT.normalized.asm
```

Every normalized listing matches, including retained trailing padding.
The accompanying per-type counts preserve the +28 and +14 observed changes.

All included raw captures were checked with gzip -dc piped to cmp against
their original uncompressed captures. Native SQLite verification-hash lines
were compared to oracles/sqlite-verification-hash.txt. Every included native
Lua stdout was compared to the corresponding oracles/WORKLOAD.clang0.out,
and its stderr was checked empty. No extra candidate native run is inferred
from the existence of other frozen oracle files.

## Emitter result boundaries

The exact enabled emitter invocation uses the same frozen compiler and
REGION_WORK=2147483648, with mask 2048 and all three optional modes set to 1.
That allowance differs from the combined workload compilation's 8589934592.
The retained original log reports four failures. The default log reports
zero failures. Both run 259263 checks.

Any later test correction and rerun belongs to its own source identity.
Neither the original logs nor the measured program identities are rewritten
to incorporate that later result.
