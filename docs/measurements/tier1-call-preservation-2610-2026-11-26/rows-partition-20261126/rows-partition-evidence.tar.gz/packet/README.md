# Rows and partition evidence contents

The immutable measured source is ad9047dd851f25c323f715ca8b43b1d8ef3b2264.
PROVENANCE.md identifies its tree, frozen compiler and programs.
COMMANDS.md points to exact executed build, compile, test and capture records.

results/current-0 contains six reused controls.
results/partition-control contains compilation reports and sidecars for the
complete-ELF parity check, without a new dynamic capture.
results/current-rows contains the first SQLite/arithmetic row pair.
results/current-rows-all contains a new six-workload capture of the exact
same programs; its complete sidecars are shared with current-rows.
results/current-branch-partition-rows contains the combined candidate pair.
results/combined-versus-rows contains the separate incremental comparison.
results/tokenizer retains code and counts for the observed path variation.

All 16 captures have compressed raw logs and regenerated summaries/audits.
Inputs, tools, oracles, licenses and source identities are preserved separately.
The original enabled emitter suite has four failures; it is not labeled pass.
The primary yy_reduce target remains unmet. There is no hardware qualification.

SHA256SUMS covers every other file in this packet.
