typedef int (*transform)(int);
int id(int);
int plain(void);
int sum5(int, int, int, int, int);
int extra(int, ...);
int old();
int use_pointer(const int *);
int use_transform(transform);
transform choose(int);
struct Pair { int x, y; };
struct Pair pair(int);
int use_pair(struct Pair);
int nested_calls(int x, volatile int *v, int *p) {
    return sum5(choose(id(x))(id(x)), old(id(x)), id(extra(2, (float)x, id(*v))),
                use_pointer(x ? p : (1-1)), use_transform(choose(plain())))
         + use_pair(pair(sum5(1, 2, 3, 4, extra(5, old(), p))));
}
int f0(void) { return plain(); }
int f1(int x) { return id(x); }
int f2(int x) { return id(id(x)); }
int f3(int x) { return id(id(id(x))); }
int f4(int x) { return sum5(id(x), id(x), x, id(x), x); }
int f5(int x) { return extra(x, x, id(x)); }
int f6(void) { return use_pointer(1 - 1); }
int f7(int x) { return choose(x)(id(x)); }
int f8(transform t, int x) { return t(t(x)); }
int f9(int x) { return use_transform(choose(x)); }
int g1(int x) { return old(x); }
int g2(struct Pair x) { return use_pair(x); }
int g3(volatile int *p) { return id(*p); }
int g4(int x) { return id(old(x)); }
