#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";dir=$PWD
cd ../fact-call-product
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh --config Release >"$dir/build.log" 2>&1
cc=$PWD/build/compiler
cp ../buster/build/predefines.h build/predefines.h
cd ../switch-inputs
source ../switch-local-args.sh
for g in calls sqlite lua musl; do
  if [[ $g == calls ]];then args=(-std=gnu17 "$dir/calls.c");else var=${g}_arguments;eval "args=(${!var})";fi
  for m in whole lean loads operators leanoperators reads small packed;do
    case $m in
      whole) flags=(--facts);; lean) flags=(--facts-lean);; loads) flags=(--facts-loads);;
      operators) flags=(--facts --facts-operators);; leanoperators) flags=(--facts-lean --facts-operators);;
      reads) flags=(--facts-reads);; small) flags=(--facts --facts-window 16);; packed) flags=(--facts --facts-packed);;
    esac
    "$cc" measure-node-machine --shadow "${flags[@]}" --passes 1 "${args[@]}" >"$dir/$g-$m.log" 2>&1
  done
done
