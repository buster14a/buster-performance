#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD
root=$PWD/../fact-call-product
parent=$PWD/../main-fbef-clean
for c in candidate parent;do
 cc=$root/build/compiler;[[ $c == candidate ]] || cc=$parent/build/compiler
 for m in whole lean loads operators leanoperators reads small packed; do
  case $m in
   whole) flags=(--facts);; lean) flags=(--facts-lean);; loads) flags=(--facts-loads);;
   operators) flags=(--facts --facts-operators);; leanoperators) flags=(--facts-lean --facts-operators);;
   reads) flags=(--facts-reads);; small) flags=(--facts --facts-window 16);; packed) flags=(--facts --facts-packed);;
  esac
  "$cc" measure-node-machine --shadow "${flags[@]}" --passes 1 -std=gnu17 "$d/calls.c" >"$d/directed-$c-$m.log" 2>&1
 done
done
