
objects/parent-znver5.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <f_i32>:
   0:	movss  xmm0,DWORD PTR [rdi]
   4:	cvttss2si eax,xmm0
   8:	ret
   9:	int3
   a:	int3
   b:	int3
   c:	int3
   d:	int3
   e:	int3
   f:	int3

0000000000000010 <f_i32_indexed>:
  10:	movss  xmm0,DWORD PTR [rdi+rsi*4]
  15:	cvttss2si eax,xmm0
  19:	ret
  1a:	int3
  1b:	int3
  1c:	int3
  1d:	int3
  1e:	int3
  1f:	int3

0000000000000020 <f_i32_packed>:
  20:	movss  xmm0,DWORD PTR [rdi+0x1]
  25:	cvttss2si eax,xmm0
  29:	ret
  2a:	int3
  2b:	int3
  2c:	int3
  2d:	int3
  2e:	int3
  2f:	int3

0000000000000030 <f_i32_volatile>:
  30:	movss  xmm0,DWORD PTR [rdi]
  34:	cvttss2si eax,xmm0
  38:	ret
  39:	int3
  3a:	int3
  3b:	int3
  3c:	int3
  3d:	int3
  3e:	int3
  3f:	int3

0000000000000040 <f_i32_shared>:
  40:	movss  xmm0,DWORD PTR [rdi]
  44:	movss  DWORD PTR [rsi],xmm0
  48:	cvttss2si eax,xmm0
  4c:	ret
  4d:	int3
  4e:	int3
  4f:	int3

0000000000000050 <f_i32_across_store>:
  50:	movss  xmm1,DWORD PTR [rdi]
  54:	movss  DWORD PTR [rsi],xmm0
  58:	cvttss2si eax,xmm1
  5c:	ret
  5d:	int3
  5e:	int3
  5f:	int3

0000000000000060 <f_i32_negative>:
  60:	movss  xmm0,DWORD PTR [rdi+rsi*4-0x4]
  66:	cvttss2si eax,xmm0
  6a:	ret
  6b:	int3
  6c:	int3
  6d:	int3
  6e:	int3
  6f:	int3

0000000000000070 <d_i32>:
  70:	movsd  xmm0,QWORD PTR [rdi]
  74:	cvttsd2si eax,xmm0
  78:	ret
  79:	int3
  7a:	int3
  7b:	int3
  7c:	int3
  7d:	int3
  7e:	int3
  7f:	int3

0000000000000080 <d_i32_indexed>:
  80:	movsd  xmm0,QWORD PTR [rdi+rsi*8]
  85:	cvttsd2si eax,xmm0
  89:	ret
  8a:	int3
  8b:	int3
  8c:	int3
  8d:	int3
  8e:	int3
  8f:	int3

0000000000000090 <d_i32_packed>:
  90:	movsd  xmm0,QWORD PTR [rdi+0x1]
  95:	cvttsd2si eax,xmm0
  99:	ret
  9a:	int3
  9b:	int3
  9c:	int3
  9d:	int3
  9e:	int3
  9f:	int3

00000000000000a0 <d_i32_volatile>:
  a0:	movsd  xmm0,QWORD PTR [rdi]
  a4:	cvttsd2si eax,xmm0
  a8:	ret
  a9:	int3
  aa:	int3
  ab:	int3
  ac:	int3
  ad:	int3
  ae:	int3
  af:	int3

00000000000000b0 <d_i32_shared>:
  b0:	movsd  xmm0,QWORD PTR [rdi]
  b4:	movsd  QWORD PTR [rsi],xmm0
  b8:	cvttsd2si eax,xmm0
  bc:	ret
  bd:	int3
  be:	int3
  bf:	int3

00000000000000c0 <d_i32_across_store>:
  c0:	movsd  xmm1,QWORD PTR [rdi]
  c4:	movsd  QWORD PTR [rsi],xmm0
  c8:	cvttsd2si eax,xmm1
  cc:	ret
  cd:	int3
  ce:	int3
  cf:	int3

00000000000000d0 <d_i32_negative>:
  d0:	movsd  xmm0,QWORD PTR [rdi+rsi*8-0x8]
  d6:	cvttsd2si eax,xmm0
  da:	ret
  db:	int3
  dc:	int3
  dd:	int3
  de:	int3
  df:	int3

00000000000000e0 <f_i64>:
  e0:	movss  xmm0,DWORD PTR [rdi]
  e4:	cvttss2si rax,xmm0
  e9:	ret
  ea:	int3
  eb:	int3
  ec:	int3
  ed:	int3
  ee:	int3
  ef:	int3

00000000000000f0 <f_i64_indexed>:
  f0:	movss  xmm0,DWORD PTR [rdi+rsi*4]
  f5:	cvttss2si rax,xmm0
  fa:	ret
  fb:	int3
  fc:	int3
  fd:	int3
  fe:	int3
  ff:	int3

0000000000000100 <f_i64_packed>:
 100:	movss  xmm0,DWORD PTR [rdi+0x1]
 105:	cvttss2si rax,xmm0
 10a:	ret
 10b:	int3
 10c:	int3
 10d:	int3
 10e:	int3
 10f:	int3

0000000000000110 <f_i64_volatile>:
 110:	movss  xmm0,DWORD PTR [rdi]
 114:	cvttss2si rax,xmm0
 119:	ret
 11a:	int3
 11b:	int3
 11c:	int3
 11d:	int3
 11e:	int3
 11f:	int3

0000000000000120 <f_i64_shared>:
 120:	movss  xmm0,DWORD PTR [rdi]
 124:	movss  DWORD PTR [rsi],xmm0
 128:	cvttss2si rax,xmm0
 12d:	ret
 12e:	int3
 12f:	int3

0000000000000130 <f_i64_across_store>:
 130:	movss  xmm1,DWORD PTR [rdi]
 134:	movss  DWORD PTR [rsi],xmm0
 138:	cvttss2si rax,xmm1
 13d:	ret
 13e:	int3
 13f:	int3

0000000000000140 <f_i64_negative>:
 140:	movss  xmm0,DWORD PTR [rdi+rsi*4-0x4]
 146:	cvttss2si rax,xmm0
 14b:	ret
 14c:	int3
 14d:	int3
 14e:	int3
 14f:	int3

0000000000000150 <d_i64>:
 150:	movsd  xmm0,QWORD PTR [rdi]
 154:	cvttsd2si rax,xmm0
 159:	ret
 15a:	int3
 15b:	int3
 15c:	int3
 15d:	int3
 15e:	int3
 15f:	int3

0000000000000160 <d_i64_indexed>:
 160:	movsd  xmm0,QWORD PTR [rdi+rsi*8]
 165:	cvttsd2si rax,xmm0
 16a:	ret
 16b:	int3
 16c:	int3
 16d:	int3
 16e:	int3
 16f:	int3

0000000000000170 <d_i64_packed>:
 170:	movsd  xmm0,QWORD PTR [rdi+0x1]
 175:	cvttsd2si rax,xmm0
 17a:	ret
 17b:	int3
 17c:	int3
 17d:	int3
 17e:	int3
 17f:	int3

0000000000000180 <d_i64_volatile>:
 180:	movsd  xmm0,QWORD PTR [rdi]
 184:	cvttsd2si rax,xmm0
 189:	ret
 18a:	int3
 18b:	int3
 18c:	int3
 18d:	int3
 18e:	int3
 18f:	int3

0000000000000190 <d_i64_shared>:
 190:	movsd  xmm0,QWORD PTR [rdi]
 194:	movsd  QWORD PTR [rsi],xmm0
 198:	cvttsd2si rax,xmm0
 19d:	ret
 19e:	int3
 19f:	int3

00000000000001a0 <d_i64_across_store>:
 1a0:	movsd  xmm1,QWORD PTR [rdi]
 1a4:	movsd  QWORD PTR [rsi],xmm0
 1a8:	cvttsd2si rax,xmm1
 1ad:	ret
 1ae:	int3
 1af:	int3

00000000000001b0 <d_i64_negative>:
 1b0:	movsd  xmm0,QWORD PTR [rdi+rsi*8-0x8]
 1b6:	cvttsd2si rax,xmm0
 1bb:	ret
 1bc:	int3
 1bd:	int3
 1be:	int3
 1bf:	int3

00000000000001c0 <f_u32>:
 1c0:	movss  xmm0,DWORD PTR [rdi]
 1c4:	cvttss2si rax,xmm0
 1c9:	ret
 1ca:	int3
 1cb:	int3
 1cc:	int3
 1cd:	int3
 1ce:	int3
 1cf:	int3

00000000000001d0 <f_u32_indexed>:
 1d0:	movss  xmm0,DWORD PTR [rdi+rsi*4]
 1d5:	cvttss2si rax,xmm0
 1da:	ret
 1db:	int3
 1dc:	int3
 1dd:	int3
 1de:	int3
 1df:	int3

00000000000001e0 <f_u32_packed>:
 1e0:	movss  xmm0,DWORD PTR [rdi+0x1]
 1e5:	cvttss2si rax,xmm0
 1ea:	ret
 1eb:	int3
 1ec:	int3
 1ed:	int3
 1ee:	int3
 1ef:	int3

00000000000001f0 <f_u32_volatile>:
 1f0:	movss  xmm0,DWORD PTR [rdi]
 1f4:	cvttss2si rax,xmm0
 1f9:	ret
 1fa:	int3
 1fb:	int3
 1fc:	int3
 1fd:	int3
 1fe:	int3
 1ff:	int3

0000000000000200 <f_u32_shared>:
 200:	movss  xmm0,DWORD PTR [rdi]
 204:	movss  DWORD PTR [rsi],xmm0
 208:	cvttss2si rax,xmm0
 20d:	ret
 20e:	int3
 20f:	int3

0000000000000210 <f_u32_across_store>:
 210:	movss  xmm1,DWORD PTR [rdi]
 214:	movss  DWORD PTR [rsi],xmm0
 218:	cvttss2si rax,xmm1
 21d:	ret
 21e:	int3
 21f:	int3

0000000000000220 <f_u32_negative>:
 220:	movss  xmm0,DWORD PTR [rdi+rsi*4-0x4]
 226:	cvttss2si rax,xmm0
 22b:	ret
 22c:	int3
 22d:	int3
 22e:	int3
 22f:	int3

0000000000000230 <d_u32>:
 230:	movsd  xmm0,QWORD PTR [rdi]
 234:	cvttsd2si rax,xmm0
 239:	ret
 23a:	int3
 23b:	int3
 23c:	int3
 23d:	int3
 23e:	int3
 23f:	int3

0000000000000240 <d_u32_indexed>:
 240:	movsd  xmm0,QWORD PTR [rdi+rsi*8]
 245:	cvttsd2si rax,xmm0
 24a:	ret
 24b:	int3
 24c:	int3
 24d:	int3
 24e:	int3
 24f:	int3

0000000000000250 <d_u32_packed>:
 250:	movsd  xmm0,QWORD PTR [rdi+0x1]
 255:	cvttsd2si rax,xmm0
 25a:	ret
 25b:	int3
 25c:	int3
 25d:	int3
 25e:	int3
 25f:	int3

0000000000000260 <d_u32_volatile>:
 260:	movsd  xmm0,QWORD PTR [rdi]
 264:	cvttsd2si rax,xmm0
 269:	ret
 26a:	int3
 26b:	int3
 26c:	int3
 26d:	int3
 26e:	int3
 26f:	int3

0000000000000270 <d_u32_shared>:
 270:	movsd  xmm0,QWORD PTR [rdi]
 274:	movsd  QWORD PTR [rsi],xmm0
 278:	cvttsd2si rax,xmm0
 27d:	ret
 27e:	int3
 27f:	int3

0000000000000280 <d_u32_across_store>:
 280:	movsd  xmm1,QWORD PTR [rdi]
 284:	movsd  QWORD PTR [rsi],xmm0
 288:	cvttsd2si rax,xmm1
 28d:	ret
 28e:	int3
 28f:	int3

0000000000000290 <d_u32_negative>:
 290:	movsd  xmm0,QWORD PTR [rdi+rsi*8-0x8]
 296:	cvttsd2si rax,xmm0
 29b:	ret
