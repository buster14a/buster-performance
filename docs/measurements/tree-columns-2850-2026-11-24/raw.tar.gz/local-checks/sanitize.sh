#!/usr/bin/env bash
# Usage: bash sanitize.sh /path/to/patched-buster [mutate-cut]
set -euo pipefail
src=$(realpath "$1")/src/buster/compiler
here=$(dirname "$(realpath "$0")")
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
awk '/^#define BUSTER_PARSE_COLUMN_TILE/ {copy=1} /^\/\/ The entry point/ && copy {exit} copy' "$src/c_parser.c" > "$work/kernel.inc"
awk '/^static uint32_t parse_test_check_postorder\(/ {copy=1} /^static uint32_t parse_test_check_postorder_self\(/ {exit} copy' "$src/c_parser_test.c" > "$work/oracle.inc"
if [[ ${2:-} == mutate-cut ]]; then
    sed -i 's/if (node == BUSTER_PARSE_NONE)/if (root + 1 < end)/' "$work/kernel.inc"
fi
clang -O1 -g -fsanitize=address,undefined -march=native -I"$work" "$here/forest-check.c" -o "$work/check"
"$work/check"
