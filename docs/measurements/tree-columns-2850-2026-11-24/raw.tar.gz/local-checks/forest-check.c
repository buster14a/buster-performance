#include <immintrin.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#define BUSTER_INLINE static inline
#define BUSTER_PARSE_NONE UINT32_MAX
#define BUSTER_ARRAY_LENGTH(array) (sizeof(array) / sizeof((array)[0]))

typedef struct
{
    uint8_t* base;
    size_t length;
    size_t capacity;
} Arena;

static void* reserve(Arena* arena, size_t bytes)
{
    void* data = NULL;
    if (bytes <= arena->capacity - arena->length)
    {
        data = arena->base + arena->length;
        arena->length += bytes;
    }
    return data;
}

#define BUSTER_ARENA_PUSH_ARRAY(arena, type, count) ((type*)reserve(arena, (count) * sizeof(type)))

static void arena_pop_to(Arena* arena, size_t mark)
{
    arena->length = mark;
}

#include "kernel.inc"
#include "oracle.inc"

static uint32_t state = 69;

static uint32_t random32(void)
{
    state = 1664525u * state + 1013904223u;
    return state;
}

// Subdivide each side of the root into contiguous child subtrees.
static void generate_tree(uint32_t* parents, uint32_t begin, uint32_t end, uint32_t parent)
{
    const uint32_t root = begin + random32() % (end - begin);
    parents[root] = parent;
    for (uint32_t i = begin; i < root;)
    {
        const uint32_t next = i + 1 + random32() % (root - i);
        generate_tree(parents, i, next, root);
        i = next;
    }
    for (uint32_t i = root + 1; i < end;)
    {
        const uint32_t next = i + 1 + random32() % (end - i);
        generate_tree(parents, i, next, root);
        i = next;
    }
}

static uint32_t check_forest(Arena* arena)
{
    const uint32_t count = 1 + random32() % 16000;
    const uint32_t slots = count + 1;
    uint32_t* parents = malloc((size_t)7 * slots * sizeof(uint32_t));
    uint32_t failures = parents == NULL;
    if (parents != NULL)
    {
        uint32_t* postorder = parents + slots;
        uint32_t* positions = postorder + slots;
        uint32_t* ends = positions + slots;
        uint32_t* first = ends + slots;
        uint32_t* next = first + slots;
        const ParseTestColumns columns = {positions, ends, first, next};
        for (uint32_t i = 0; i < count;)
        {
            const uint32_t last = i + 1 + random32() % (count - i);
            generate_tree(parents, i, last, UINT32_MAX);
            i = last;
        }
        for (unsigned sized = 0; sized < 2; sized += 1)
        {
            uint32_t* sizes = sized == 1 ? next + slots : NULL;
            memset(postorder, 0xa5, (size_t)6 * slots * sizeof(uint32_t));
            parse_tree_columns(parents, count, postorder, positions, ends, first, next, sizes);
            uint32_t expected;
            failures += parse_test_check_columns(parents, count, &columns, arena) != UINT32_MAX;
            failures += parse_test_check_postorder(parents, count, postorder, count, sizes, arena, &expected) != UINT32_MAX;
        }
        free(parents);
    }
    return failures;
}

int main(void)
{
    Arena arena = {.capacity = 8u << 20};
    arena.base = malloc(arena.capacity);
    uint32_t failures = arena.base == NULL;
    unsigned forests = 0;
    if (arena.base != NULL)
    {
        failures += parse_test_columns_guarded() + parse_test_columns_ranges(&arena);
        while (failures == 0 && forests < 300)
        {
            failures += check_forest(&arena);
            forests += 1;
        }
        free(arena.base);
    }
    printf("%u failures across guarded ranges and %u generated ordered forests, seed 69\n", failures, forests);
    return failures != 0;
}
