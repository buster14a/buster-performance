#!/usr/bin/env bash
set -euo pipefail
task_root=/home/david/buster-fast-bench/1740-sqlite-output-v3-01a1b81e
replay_root=/home/david/buster-fast-bench/1740-replay-01a1b81e
cd "$task_root"
test ! -e cohort-controller.status
test ! -e record
test "$(cat prepare-build.status)" = 0
test "$(cat prepare-controls.status)" = 0
printf '%s  source-manifest.sha256\n' 112bc0227aa18e1f39896822c964811cc555fc4dc2be794580308db94940eb98 | sha256sum --check --quiet
sha256sum --check source-manifest.sha256
sha256sum --check prepare-guard.sha256
bindings=(
    "$task_root/guarded-runner"
    "$task_root/guard-v3.c"
    "$task_root/run-one-v3.sh"
    "$task_root/perf-reader-v3.awk"
    "$task_root/expected-perf-verbose.stderr"
    "$task_root/PROTOCOL-V3.txt"
    "$task_root/source-manifest.sha256"
    "$replay_root/base/build/compiler"
    "$replay_root/head/build/compiler"
    /var/lib/buster-9700x/corpora/preprocessor-391e729af658/sqlite/sqlite3.c
    /usr/bin/perf
)
finish()
{
    result=$?
    set +e
    sha256sum "${bindings[@]}" > cohort-bindings.after.sha256
    identity_status=$?
    cmp cohort-bindings.before.sha256 cohort-bindings.after.sha256
    comparison_status=$?
    printf '%s\n' "$identity_status" > cohort-after-identity.status
    printf '%s\n' "$comparison_status" > cohort-before-after-comparison.status
    date -u > cohort-finished.utc
    if test "$identity_status" != 0 || test "$comparison_status" != 0; then result=1; fi
    printf '%s\n' "$result" > cohort-controller.status
    exit "$result"
}
sha256sum "${bindings[@]}" > cohort-bindings.before.sha256
date -u > cohort-started.utc
trap finish EXIT
export EXCLUSIVE_OWNER=codex-1740-sqlite-v3-01a1b81e
export EXCLUSIVE_TITLE='#1740 historical SQLite V3 reused/fresh diagnostic (one observation per grant)'
export EXCLUSIVE_LINK=https://github.com/buster14a/buster/issues/1217
# OUTSIDE every lock: the controller validates this and obtains a fresh grant for each observation.
"$task_root/guarded-runner" --sqlite1740-controller
