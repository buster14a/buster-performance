#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# SOURCE PROPOSAL ONLY. Run once in its own admitted exclusive grant, never as a compiler cohort.
set -euo pipefail
test "$#" = 0
test "$BUSTER_9700X_HELD" = 1
export LC_ALL=C
task_root=/home/david/buster-fast-bench/1740-sqlite-output-v3-01a1b81e
cd "$task_root"
sha256sum --check source-manifest.sha256
test ! -e reader-controls
mkdir -m 700 reader-controls
check_reader()
{
    name=$1
    expected=$2
    mkdir -m 700 "reader-controls/$name"
    set +e
    awk -v coverage="reader-controls/$name/coverage.tsv" -v times="reader-controls/$name/times.tsv" \
        -f perf-reader-v3.awk "reader-controls/$name.perf" > "reader-controls/$name/stdout" 2> "reader-controls/$name/stderr"
    status=$?
    set -e
    printf '%s\n' "$status" > "reader-controls/$name/status"
    test "$status" = "$expected"
    test ! -s "reader-controls/$name/stdout"
    test ! -s "reader-controls/$name/stderr"
    printf 'PASS reader %s expected=%s observed=%s\n' "$name" "$expected" "$status"
}
cp valid-synthetic.perf reader-controls/positive.perf
check_reader positive 0
sed 's/^cycles:u: 9007199254740993 /cycles:u: 9007199254740992 /' valid-synthetic.perf > reader-controls/value-above-2pow53.perf
check_reader value-above-2pow53 1
cp valid-synthetic.perf reader-controls/unknown-raw.perf
printf 'unknown:u: -1: 1 123456789 123456789\nunknown:u: 1 123456789 123456789\n' >> reader-controls/unknown-raw.perf
check_reader unknown-raw 1
cp valid-synthetic.perf reader-controls/unknown-summary.perf
printf '1 unknown-counter\n' >> reader-controls/unknown-summary.perf
check_reader unknown-summary 1
sed '/^instructions:u: 18446744073709551615 /d' valid-synthetic.perf > reader-controls/missing-aggregate.perf
check_reader missing-aggregate 1
cp valid-synthetic.perf reader-controls/duplicate-indexed.perf
printf 'cycles:u: -1: 9007199254740993 123456789 123456789\n' >> reader-controls/duplicate-indexed.perf
check_reader duplicate-indexed 1
sed 's/^cycles:u: -1: 9007199254740993 123456789 123456789$/cycles:u: -1: 9007199254740993 123456789 123456788/' valid-synthetic.perf > reader-controls/coverage-mismatch.perf
check_reader coverage-mismatch 1
sed 's/18446744073709551615/18446744073709551616/g' valid-synthetic.perf > reader-controls/uint64-overflow.perf
check_reader uint64-overflow 1
sed 's/^cycles:u: -1:/cycles:u: 0:/' valid-synthetic.perf > reader-controls/wrong-cpu-marker.perf
check_reader wrong-cpu-marker 1
sed 's/^1.000000000 seconds time elapsed$/999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999 seconds time elapsed/' valid-synthetic.perf > reader-controls/footer-overflow.perf
check_reader footer-overflow 1
sed 's/^0.800000000 seconds user$/46.000000000 seconds user/' valid-synthetic.perf > reader-controls/user-over-bound.perf
check_reader user-over-bound 1
sed 's/^0.200000000 seconds sys$/46.000000000 seconds sys/' valid-synthetic.perf > reader-controls/system-over-bound.perf
check_reader system-over-bound 1
sed 's/^1.000000000 seconds time elapsed$/0.000000000 seconds time elapsed/' valid-synthetic.perf > reader-controls/zero-elapsed.perf
check_reader zero-elapsed 1
cp valid-synthetic.perf reader-controls/unknown-footer.perf
printf '1.000000000 seconds unknown\n' >> reader-controls/unknown-footer.perf
check_reader unknown-footer 1
cp valid-synthetic.perf reader-controls/trailing-footer.perf
printf '1.000000000 seconds time elapsed unexpected\n' >> reader-controls/trailing-footer.perf
check_reader trailing-footer 1
cp valid-synthetic.perf reader-controls/negative-unknown-summary.perf
printf '%s\n' '-1 unknown-counter' >> reader-controls/negative-unknown-summary.perf
check_reader negative-unknown-summary 1
cp valid-synthetic.perf reader-controls/exponent-unknown-summary.perf
printf '1e3 unknown-counter\n' >> reader-controls/exponent-unknown-summary.perf
check_reader exponent-unknown-summary 1
printf '%s  %s\n' 78eb5acc78504a30233fab1aa1f1c2d6c2dd6ad2a9191f776a41bcf6e1173f1f expected-perf-verbose.stderr | sha256sum --check --quiet
cp expected-perf-verbose.stderr reader-controls/exact.stderr
cp expected-perf-verbose.stderr reader-controls/added.stderr
printf 'unreviewed diagnostic\n' >> reader-controls/added.stderr
head -c -1 expected-perf-verbose.stderr > reader-controls/missing-byte.stderr
for control in exact added missing-byte
do
    expected=1
    if test "$control" = exact; then expected=0; fi
    set +e
    cmp expected-perf-verbose.stderr "reader-controls/$control.stderr" > "reader-controls/$control.cmp.stdout" 2> "reader-controls/$control.cmp.stderr"
    status=$?
    set -e
    printf '%s\n' "$status" > "reader-controls/$control.cmp.status"
    test "$status" = "$expected"
    printf 'PASS stderr %s expected=%s observed=%s\n' "$control" "$expected" "$status"
done
sha256sum --check source-manifest.sha256
printf 'PASS: 20 formatter controls; no compiler or measured observation executed\n'
