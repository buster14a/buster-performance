# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
    function uint64(value, positive) {
        return value~/^(0|[1-9][0-9]*)$/ && (!positive || ("x" value)!="x0") &&
            (length(value)<20 || (length(value)==20 && ("x" value)<="x18446744073709551615"));
    }
    function seconds(value, positive) {
        return length(value)<=12 && value~/^[0-9]+([.][0-9]+)?$/ && value+0>=0 && value+0<=45 &&
            (!positive || value+0>0);
    }
    BEGIN {
        split("cycles:u instructions:u task-clock context-switches cpu-migrations minor-faults major-faults", keys, " ");
        print "family\tevent\tcpu\traw-value\tenabled-ns\trunning-ns" > coverage;
        print "wall-seconds\tuser-seconds\tsystem-seconds" > times;
    }
    {
        recognized_raw=0; recognized_summary=0; recognized_footer=0;
        for (i=1;i<=7;i++) {
            prefix=keys[i] ": ";
            if (index($0,prefix)==1) {
                recognized_raw=1;
                rest=substr($0,length(prefix)+1);
                fields=split(rest, parts, /: /);
                family=fields==2 ? "indexed" : fields==1 ? "aggregate" : "invalid";
                cpu=family=="indexed" ? parts[1] : "not-applicable";
                values=split(family=="indexed" ? parts[2] : parts[1], number, / +/);
                if (family=="invalid" || (family=="indexed" && ("x" cpu)!="x-1") || values!=3 ||
                    !uint64(number[1],0) || !uint64(number[2],1) || !uint64(number[3],1) ||
                    ("x" number[2])!=("x" number[3])) bad=1;
                if (i<=2 && number[1]=="0") bad=1;
                if (family=="indexed") {
                    indexed[keys[i]]++;
                    indexed_value[keys[i]]=number[1]; indexed_enabled[keys[i]]=number[2]; indexed_running[keys[i]]=number[3];
                } else if (family=="aggregate") {
                    aggregate[keys[i]]++;
                    aggregate_value[keys[i]]=number[1]; aggregate_enabled[keys[i]]=number[2]; aggregate_running[keys[i]]=number[3];
                }
                print family "\t" keys[i] "\t" cpu "\t" number[1] "\t" number[2] "\t" number[3] > coverage;
            }
            if ($2==keys[i] || $3==keys[i]) {
                recognized_summary=1;
                summary[keys[i]]++;
                summary_value[keys[i]]=$1;
                if ($1!~/^[0-9]+([.][0-9]+)?$/ || (i<=2 && $1+0<=0)) bad=1;
            }
        }
        if (!recognized_raw && $0~/^[^ \t]+: /) bad=1;
        if (NF==4 && $2=="seconds" && $3=="time" && $4=="elapsed") {
            recognized_footer=1; wall_rows++; wall=$1; if (!seconds($1,1)) bad=1;
        }
        if (NF==3 && $2=="seconds" && $3=="user") {
            recognized_footer=1; user_rows++; user_value=$1; if (!seconds($1,0)) bad=1;
        }
        if (NF==3 && $2=="seconds" && $3=="sys") {
            recognized_footer=1; system_rows++; system_value=$1; if (!seconds($1,0)) bad=1;
        }
        numeric_like=$1~/^[+-]?([0-9]|[.][0-9])/ || tolower($1)~/^[+-]?(inf(inity)?|nan)$/;
        if (!recognized_summary && !recognized_footer && numeric_like && $2!="") bad=1;
        if ($2=="seconds" && !recognized_footer) bad=1;
    }
    END {
        for (i=1;i<=7;i++) {
            key=keys[i];
            if (indexed[key]!=1 || aggregate[key]!=1 || summary[key]!=1 ||
                ("x" indexed_value[key])!=("x" aggregate_value[key]) ||
                ("x" indexed_enabled[key])!=("x" aggregate_enabled[key]) ||
                ("x" indexed_running[key])!=("x" aggregate_running[key])) bad=1;
            # task-clock summary is rounded milliseconds; the other six summaries preserve integer counts.
            if (key!="task-clock" && ("x" summary_value[key])!=("x" indexed_value[key])) bad=1;
        }
        if (wall_rows!=1 || user_rows!=1 || system_rows!=1) bad=1;
        print wall "\t" user_value "\t" system_value > times;
        if (close(coverage)!=0 || close(times)!=0) bad=1;
        exit bad;
}
