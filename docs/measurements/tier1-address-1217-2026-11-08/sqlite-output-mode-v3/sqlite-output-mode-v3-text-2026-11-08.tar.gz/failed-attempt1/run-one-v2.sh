#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# PREPARATION ONLY. One fixed observation per fresh exclusive grant.
set -euo pipefail
umask 022
test "$#" = 3
case "$1" in 0|1|2) role=$1;; *) exit 1;; esac
case "$2" in reused|fresh) mode=$2;; *) exit 1;; esac
case "$3" in 00|01|02|03|04|05|06) round=$3;; *) exit 1;; esac
test "$BUSTER_9700X_HELD" = 1
clang_root=/home/david/.cache/buster/benchpress-clang/efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378
export PATH="$clang_root/bin:/usr/bin:/bin"
export LD_LIBRARY_PATH="$clang_root/lib"
export LC_ALL=C LANG=C TZ=UTC SOURCE_DATE_EPOCH=0
unset CPATH C_INCLUDE_PATH
task_root=/home/david/buster-fast-bench/1740-sqlite-output-01a1b81e
replay_root=/home/david/buster-fast-bench/1740-replay-01a1b81e
record=$task_root/record
sqlite=/var/lib/buster-9700x/corpora/preprocessor-391e729af658/sqlite
base_compiler=$replay_root/base/build/compiler
head_compiler=$replay_root/head/build/compiler
base_hash=cdd8abd85f2c2ec8d5b25b0fe222b6755fec28956265f95d57e76a5ce3f63dc8
head_hash=bda9607748f4984326a22b168fadeaf856e335aa0889194cbfa5cea4aa8db2ab
input_hash=0a409f1633283fa31a9126b11fbfd64a1991c5d30defad07e5745d4667f5e23d
perf_hash=a6da58ffc54b3c9bfe8d0d046ade1dbc70e8f5121932e35de916ad39162f7d4f
phase=measured
if test "$round" = 00; then phase=warm-up; fi
tag=$phase-r$round-m$mode-s$role
case_dir=$record/$tag
mkdir -m 700 "$case_dir"
exec > "$case_dir/helper.stdout" 2> "$case_dir/helper.stderr"
trap 'result=$?; printf "%s\n" "$result" > "$case_dir/helper.status"; exit "$result"' EXIT
check_identities()
{
    printf '%s  %s\n' "$base_hash" "$base_compiler" "$head_hash" "$head_compiler" \
        "$input_hash" "$sqlite/sqlite3.c" "$perf_hash" /usr/bin/perf | sha256sum --check --quiet
}
record_cpu2_policy()
{
    printf 'field\tvalue\n'
    for field in scaling_governor energy_performance_preference
    do
        path=/sys/devices/system/cpu/cpu2/cpufreq/$field
        value=missing
        if test -e "$path"; then value=$(cat "$path"); fi
        printf '%s\t%s\n' "$field" "$value"
    done
    for field in thread_siblings_list core_id physical_package_id
    do
        path=/sys/devices/system/cpu/cpu2/topology/$field
        value=missing
        if test -e "$path"; then value=$(cat "$path"); fi
        printf '%s\t%s\n' "$field" "$value"
    done
}
check_identities
/usr/bin/perf --version > "$case_dir/perf.version"
/usr/bin/readelf --version > "$case_dir/readelf.version"
sha256sum /usr/bin/perf /usr/bin/readelf /usr/bin/stat /usr/bin/sha256sum \
    "$task_root/guarded-runner" "$task_root/run-one-v2.sh" > "$case_dir/tool-identities.sha256"
compiler=$base_compiler
side=base
if test "$role" = 1; then compiler=$head_compiler; side=head; fi
output=$record/reused.o
before_inode=absent
before_bytes=absent
before_links=absent
if test "$mode" = fresh
then
    output=$record/fresh-r$round-s$role.o
    test ! -e "$output"
    test ! -L "$output"
else
    if test "$round" = 00 && test "$role" = 0
    then
        test ! -e "$output"
        test ! -L "$output"
        install -m 644 /dev/null "$output"
    fi
    test -f "$output"
    test ! -L "$output"
    before_links=$(stat -c %h "$output")
    test "$before_links" = 1
    before_inode=$(stat -c %i "$output")
    before_bytes=$(stat -c %s "$output")
fi
printf 'PATH\t%s\nLD_LIBRARY_PATH\t%s\nLC_ALL\t%s\nLANG\t%s\nTZ\t%s\nSOURCE_DATE_EPOCH\t%s\nCPATH\tunset\nC_INCLUDE_PATH\tunset\n' \
    "$PATH" "$LD_LIBRARY_PATH" "$LC_ALL" "$LANG" "$TZ" "$SOURCE_DATE_EPOCH" > "$case_dir/selected-environment.tsv"
printf 'requested-perf-and-compiler-cpu=2\naffinity-evidence=fixed metadata probe immediately before perf, not an independent observation inside the compiler\npolicy-evidence=cpu2-policy.before.tsv and cpu2-policy.after.tsv; missing means the fixed sysfs path is absent; no policy changed\n' > "$case_dir/cpu-policy.txt"
record_cpu2_policy > "$case_dir/cpu2-policy.before.tsv"
taskset -c 2 /usr/bin/awk '$1=="Cpus_allowed_list:" { print $2; count++ } END { exit count!=1 }' \
    /proc/self/status > "$case_dir/cpu2-affinity-probe.txt"
test "$(cat "$case_dir/cpu2-affinity-probe.txt")" = 2
set +e
taskset -c 2 /usr/bin/perf --debug-file "$case_dir/perf.debug" stat -vv --no-scale --no-big-num \
    --output "$case_dir/perf.txt" \
    --event cycles:u,instructions:u,task-clock,context-switches,cpu-migrations,minor-faults,major-faults \
    -- "$compiler" -c -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE \
    "-I$sqlite" "$sqlite/sqlite3.c" -o "$output" > "$case_dir/compiler.stdout" 2> "$case_dir/compiler.stderr"
status=$?
set -e
printf '%s\n' "$status" > "$case_dir/compiler.status"
record_cpu2_policy > "$case_dir/cpu2-policy.after.tsv"
test "$status" = 0
test ! -s "$case_dir/compiler.stdout"
test ! -s "$case_dir/compiler.stderr"
# -vv raw tuples preserve uint64 integers; compare enabled/running as strings, never floating point.
# The expected native formatter has not yet been confirmed by execution. A mismatch refuses this cohort.
awk -v coverage="$case_dir/coverage.tsv" -v times="$case_dir/times.tsv" '
    BEGIN {
        split("cycles:u instructions:u task-clock context-switches cpu-migrations minor-faults major-faults", keys, " ");
        print "event\tcpu\traw-value\tenabled-ns\trunning-ns" > coverage;
        print "wall-seconds\tuser-seconds\tsystem-seconds" > times;
    }
    {
        for (i=1;i<=7;i++) {
            prefix=keys[i] ": ";
            if (index($0,prefix)==1) {
                rest=substr($0,length(prefix)+1);
                fields=split(rest, parts, /: /);
                values=split(parts[2], number, / +/);
                if (fields!=2 || parts[1]!~/^-?[0-9]+$/ || values!=3 ||
                    number[1]!~/^[0-9]+$/ || number[2]!~/^[0-9]+$/ || number[3]!~/^[0-9]+$/ ||
                    number[2]~/^0+$/ || ("x" number[2])!=("x" number[3])) bad=1;
                if (i<=2 && number[1]~/^0+$/) bad=1;
                raw[keys[i]]++;
                print keys[i] "\t" parts[1] "\t" number[1] "\t" number[2] "\t" number[3] > coverage;
            }
            if ($2==keys[i] || $3==keys[i]) {
                summary[keys[i]]++;
                if ($1!~/^[0-9]+([.][0-9]+)?$/ || (i<=2 && $1+0<=0)) bad=1;
            }
        }
        if ($2=="seconds" && $3=="time" && $4=="elapsed") { wall_rows++; wall=$1; if ($1!~/^[0-9]+([.][0-9]+)?$/ || $1+0<=0) bad=1 }
        if ($2=="seconds" && $3=="user") { user_rows++; user_value=$1; if ($1!~/^[0-9]+([.][0-9]+)?$/) bad=1 }
        if ($2=="seconds" && $3=="sys") { system_rows++; system_value=$1; if ($1!~/^[0-9]+([.][0-9]+)?$/) bad=1 }
    }
    END {
        for (i=1;i<=7;i++) if (raw[keys[i]]!=1 || summary[keys[i]]!=1) bad=1;
        if (wall_rows!=1 || user_rows!=1 || system_rows!=1) bad=1;
        print wall "\t" user_value "\t" system_value > times;
        if (close(coverage)!=0 || close(times)!=0) bad=1;
        exit bad;
    }' "$case_dir/perf.txt"
test -f "$output"
test ! -L "$output"
after_links=$(stat -c %h "$output")
test "$after_links" = 1
after_inode=$(stat -c %i "$output")
after_bytes=$(stat -c %s "$output")
after_mode=$(stat -c %a "$output")
test "$after_mode" = 644
publication=fresh-create
if test "$mode" = reused
then
    test "$before_inode" = "$after_inode"
    publication=reused-equal
    if test "$after_bytes" -lt "$before_bytes"; then publication=reused-shrink; fi
    if test "$after_bytes" -gt "$before_bytes"; then publication=reused-grow; fi
fi
digest=$(sha256sum "$output")
digest=${digest%% *}
reference=$record/reference-$side.o
if test -f "$reference"
then
    test ! -L "$reference"
    test "$(stat -c %h "$reference")" = 1
    cmp "$reference" "$output"
else
    test ! -e "$reference"
    test ! -L "$reference"
    test "$round" = 00
    cp --reflink=never "$output" "$reference"
fi
/usr/bin/readelf -SW "$output" > "$case_dir/sections.txt"
printf 'phase\tround\tmode\trole\tcompiler\toutput\tbefore_inode\tbefore_bytes\tbefore_links\tafter_inode\tafter_bytes\tafter_links\tafter_mode\tsha256\tpublication_mode\tstatus\n' > "$case_dir/manifest.tsv"
printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$phase" "$round" "$mode" "$role" "$compiler" "$output" "$before_inode" "$before_bytes" "$before_links" \
    "$after_inode" "$after_bytes" "$after_links" "$after_mode" "$digest" "$publication" "$status" >> "$case_dir/manifest.tsv"
check_identities
