// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin.
// Public-copy preparation only. Raw inputs and existing outputs are never written.
// A removable block is exactly a nonempty waiting-holder first line, one title
// line and one link line, optionally followed immediately by one pull-request
// line. Every accepted holder line is LF-terminated; CRLF is accepted. No scan
// skips arbitrary intervening lines to find a later link. Nested waiting, own
// grants, metrics or status lines where title/link is required fail closed.
// All holder lines count toward the 256-line / 64-KiB limits. All bytes outside
// complete blocks are copied literally, including CRLF and final lines. Empty
// waiting-holder lines are copied literally. No own-grant format matches.
// Input text must be valid UTF-8 without ASCII C0/DEL or Unicode C1 controls,
// except that ASCII TAB, LF and CR are accepted. Rejection creates no output.
#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

enum
{
    INPUT_LIMIT = 16 * 1024 * 1024,
    BLOCK_BYTE_LIMIT = 64 * 1024,
    BLOCK_LINE_LIMIT = 256,
};

static const unsigned char waiting_prefix[] = "exclusive.sh: waiting for the 9700X, held by: ";
static const unsigned char title_prefix[] = "  title: ";
static const unsigned char link_prefix[] = "  link: ";
static const unsigned char pull_request_prefix[] = "  pull request: ";
static const unsigned char replacement[] = "[publication: unrelated shared-lock waiting-holder details omitted]\n";

static bool same_metadata(const struct stat* before, const struct stat* after)
{
    return S_ISREG(after->st_mode) && before->st_dev == after->st_dev && before->st_ino == after->st_ino &&
           before->st_size == after->st_size && before->st_mtim.tv_sec == after->st_mtim.tv_sec &&
           before->st_mtim.tv_nsec == after->st_mtim.tv_nsec && before->st_ctim.tv_sec == after->st_ctim.tv_sec &&
           before->st_ctim.tv_nsec == after->st_ctim.tv_nsec;
}

static bool text_bytes(const unsigned char* input, size_t size)
{
    bool valid = true;
    size_t cursor = 0;
    while (valid && cursor < size)
    {
        unsigned char first = input[cursor++];
        if (first < 0x80)
        {
            valid = first == '\t' || first == '\n' || first == '\r' || (first >= 0x20 && first <= 0x7e);
        }
        else
        {
            size_t following = 0;
            uint32_t value = 0;
            uint32_t minimum = 0;
            if (first >= 0xc2 && first <= 0xdf)
            {
                following = 1;
                value = first & 0x1fu;
                minimum = 0x80;
            }
            else if (first >= 0xe0 && first <= 0xef)
            {
                following = 2;
                value = first & 0x0fu;
                minimum = 0x800;
            }
            else if (first >= 0xf0 && first <= 0xf4)
            {
                following = 3;
                value = first & 0x07u;
                minimum = 0x10000;
            }
            else
            {
                valid = false;
            }
            valid = valid && following <= size - cursor;
            for (size_t i = 0; valid && i < following; i += 1)
            {
                unsigned char next = input[cursor++];
                valid = next >= 0x80 && next <= 0xbf;
                value = (value << 6) | (next & 0x3fu);
            }
            valid = valid && value >= minimum && value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff) &&
                    !(value >= 0x80 && value <= 0x9f);
        }
    }
    return valid;
}

static bool read_input(const char* filename, unsigned char** result, size_t* size)
{
    *result = NULL;
    *size = 0;
    int descriptor = open(filename, O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
    struct stat before;
    bool valid = descriptor >= 0 && fstat(descriptor, &before) == 0 && S_ISREG(before.st_mode) &&
                 before.st_size >= 0 && before.st_size <= INPUT_LIMIT;
    size_t length = valid ? (size_t)before.st_size : 0;
    unsigned char* input = valid ? malloc(length + 1) : NULL;
    valid = valid && input != NULL;
    size_t used = 0;
    while (valid && used < length)
    {
        ssize_t count = read(descriptor, input + used, length - used);
        if (count < 0 && errno == EINTR)
        {
            continue;
        }
        valid = count > 0;
        if (valid)
        {
            used += (size_t)count;
        }
    }
    if (valid)
    {
        unsigned char extra;
        ssize_t count;
        do
        {
            count = read(descriptor, &extra, 1);
        } while (count < 0 && errno == EINTR);
        struct stat after;
        valid = count == 0 && fstat(descriptor, &after) == 0 && same_metadata(&before, &after) && text_bytes(input, length);
    }
    if (descriptor >= 0)
    {
        valid = close(descriptor) == 0 && valid;
    }
    if (valid)
    {
        input[length] = 0;
        *result = input;
        *size = length;
    }
    else
    {
        free(input);
    }
    return valid;
}

static size_t line_end(const unsigned char* input, size_t size, size_t begin)
{
    size_t end = begin;
    while (end < size && input[end] != '\n')
    {
        end += 1;
    }
    if (end < size)
    {
        end += 1;
    }
    return end;
}

static bool starts_with(const unsigned char* input, size_t begin, size_t end, const unsigned char* prefix, size_t prefix_size)
{
    return end - begin >= prefix_size && memcmp(input + begin, prefix, prefix_size) == 0;
}

static bool has_holder(const unsigned char* input, size_t begin, size_t end)
{
    bool present = false;
    for (size_t i = begin + sizeof(waiting_prefix) - 1; i < end; i += 1)
    {
        unsigned char value = input[i];
        present = present || (value != ' ' && value != '\t' && value != '\r' && value != '\n');
    }
    return present;
}

static bool holder_line(const unsigned char* input, size_t size, size_t block_begin, size_t* block_end, size_t* lines, const unsigned char* prefix, size_t prefix_size)
{
    bool valid = *block_end < size && *lines < BLOCK_LINE_LIMIT;
    size_t next = valid ? line_end(input, size, *block_end) : *block_end;
    valid = valid && starts_with(input, *block_end, next, prefix, prefix_size) &&
            next > *block_end && input[next - 1] == '\n' && next - block_begin <= BLOCK_BYTE_LIMIT;
    if (valid)
    {
        *block_end = next;
        *lines += 1;
    }
    return valid;
}

static bool append_bytes(unsigned char* output, size_t capacity, size_t* used, const unsigned char* source, size_t size)
{
    bool valid = *used <= capacity && size <= capacity - *used;
    if (valid)
    {
        if (output != NULL && size != 0)
        {
            memcpy(output + *used, source, size);
        }
        *used += size;
    }
    return valid;
}

static bool transform(const unsigned char* input, size_t size, unsigned char* output, size_t capacity, size_t* output_size, size_t* blocks)
{
    bool valid = true;
    size_t cursor = 0;
    size_t used = 0;
    size_t count = 0;
    while (valid && cursor < size)
    {
        size_t end = line_end(input, size, cursor);
        bool waiting = starts_with(input, cursor, end, waiting_prefix, sizeof(waiting_prefix) - 1);
        if (waiting && has_holder(input, cursor, end))
        {
            size_t block_end = end;
            size_t lines = 1;
            valid = end > cursor && input[end - 1] == '\n' && block_end - cursor <= BLOCK_BYTE_LIMIT &&
                    holder_line(input, size, cursor, &block_end, &lines, title_prefix, sizeof(title_prefix) - 1) &&
                    holder_line(input, size, cursor, &block_end, &lines, link_prefix, sizeof(link_prefix) - 1);
            if (valid && block_end < size)
            {
                size_t next = line_end(input, size, block_end);
                if (starts_with(input, block_end, next, pull_request_prefix, sizeof(pull_request_prefix) - 1))
                {
                    valid = holder_line(input, size, cursor, &block_end, &lines, pull_request_prefix, sizeof(pull_request_prefix) - 1);
                }
            }
            valid = valid && append_bytes(output, capacity, &used, replacement, sizeof(replacement) - 1);
            if (valid)
            {
                cursor = block_end;
                count += 1;
            }
        }
        else
        {
            valid = append_bytes(output, capacity, &used, input + cursor, end - cursor);
            cursor = end;
        }
    }
    if (valid)
    {
        *output_size = used;
        *blocks = count;
    }
    return valid;
}

static bool write_fresh(const char* filename, const unsigned char* output, size_t size)
{
    int descriptor = open(filename, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600);
    bool valid = descriptor >= 0;
    size_t written = 0;
    while (valid && written < size)
    {
        ssize_t count = write(descriptor, output + written, size - written);
        if (count < 0 && errno == EINTR)
        {
            continue;
        }
        valid = count > 0;
        if (valid)
        {
            written += (size_t)count;
        }
    }
    if (descriptor >= 0)
    {
        valid = close(descriptor) == 0 && valid;
    }
    return valid;
}

int main(int argc, char** argv)
{
    int result = 2;
    unsigned char* input = NULL;
    unsigned char* output = NULL;
    size_t input_size = 0;
    size_t output_size = 0;
    size_t blocks = 0;
    if (argc == 3)
    {
        result = 1;
        bool valid = read_input(argv[1], &input, &input_size) &&
                     transform(input, input_size, NULL, SIZE_MAX, &output_size, &blocks) && output_size < SIZE_MAX;
        output = valid ? malloc(output_size + 1) : NULL;
        valid = valid && output != NULL;
        size_t actual_size = 0;
        size_t actual_blocks = 0;
        valid = valid && transform(input, input_size, output, output_size, &actual_size, &actual_blocks) &&
                actual_size == output_size && actual_blocks == blocks && write_fresh(argv[2], output, output_size);
        if (valid && fprintf(stderr, "sanitized-blocks=%zu\n", blocks) >= 0 && fflush(stderr) == 0)
        {
            result = 0;
        }
    }
    free(output);
    free(input);
    return result;
}
