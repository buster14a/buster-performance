#!/usr/bin/env bash
set -euo pipefail
task_root=/home/david/buster-fast-bench/1740-sqlite-output-v3-01a1b81e
trap 'result=$?; printf "%s\n" "$result" > "$task_root/prepare-build.status"; exit "$result"' EXIT
clang_root=/home/david/.cache/buster/benchpress-clang/efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378
export PATH="$clang_root/bin:/usr/bin:/bin" LD_LIBRARY_PATH="$clang_root/lib" LC_ALL=C
unset CPATH C_INCLUDE_PATH
cd "$task_root"
test ! -e guarded-runner
printf '%s  source-manifest.sha256\n' 112bc0227aa18e1f39896822c964811cc555fc4dc2be794580308db94940eb98 | sha256sum --check --quiet
sha256sum --check source-manifest.sha256
printf '%s  %s\n' c336d48383874cffaab0dc4c5c359456d871f21380b746520dde5c7f4c125a67 "$clang_root/bin/clang" | sha256sum --check --quiet
date -u
EXCLUSIVE_OWNER=codex-1740-sqlite-v3-01a1b81e \
EXCLUSIVE_TITLE='#1740 SQLite V3 guard path-only build' \
EXCLUSIVE_LINK=https://github.com/buster14a/buster/issues/1217 \
    /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 60s \
    taskset -c 2 "$clang_root/bin/clang" -std=gnu17 -O2 -Wall -Wextra -Werror guard-v3.c -lm -o guarded-runner
sha256sum guarded-runner > prepare-guard.sha256
printf '%s  source-manifest.sha256\n' 112bc0227aa18e1f39896822c964811cc555fc4dc2be794580308db94940eb98 | sha256sum --check --quiet
sha256sum --check source-manifest.sha256
date -u
