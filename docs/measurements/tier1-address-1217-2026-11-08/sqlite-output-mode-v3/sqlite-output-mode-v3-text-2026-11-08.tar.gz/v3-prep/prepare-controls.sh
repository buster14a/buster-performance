#!/usr/bin/env bash
set -euo pipefail
task_root=/home/david/buster-fast-bench/1740-sqlite-output-v3-01a1b81e
trap 'result=$?; printf "%s\n" "$result" > "$task_root/prepare-controls.status"; exit "$result"' EXIT
cd "$task_root"
test "$(cat prepare-build.status)" = 0
test ! -e reader-controls
test ! -e record
sha256sum --check prepare-guard.sha256
printf '%s  source-manifest.sha256\n' 112bc0227aa18e1f39896822c964811cc555fc4dc2be794580308db94940eb98 | sha256sum --check --quiet
sha256sum --check source-manifest.sha256
date -u
EXCLUSIVE_OWNER=codex-1740-sqlite-v3-01a1b81e \
EXCLUSIVE_TITLE='#1740 SQLite V3 twenty formatter controls only' \
EXCLUSIVE_LINK=https://github.com/buster14a/buster/issues/1217 \
    /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 60s \
    taskset -c 2 /usr/bin/bash reader-controls.sh
sha256sum --check prepare-guard.sha256
printf '%s  source-manifest.sha256\n' 112bc0227aa18e1f39896822c964811cc555fc4dc2be794580308db94940eb98 | sha256sum --check --quiet
sha256sum --check source-manifest.sha256
test ! -e record
date -u
