#!/usr/bin/env bash
set -euo pipefail
root=/home/david/buster-fast-bench/1736-codex-01a1bae5
test "$(uname -n)" = benchpress
cd "$root"
test -f input-audit-expected.sha256
printf '%s\n' 'a76acd02972eac43db0661ac5c52514c38f5614e3d8b55b9e30a203e7162cb74  input-audit-expected.sha256' | sha256sum -c -
test "$(wc -l < input-audit-expected.sha256)" -eq 71
# A regular-file manifest cannot authenticate symlink targets. Reject symlinks
# anywhere under the supplied input tree before checking the copied files.
test -z "$(find inputs -type l -print -quit)"
sha256sum -c input-audit-expected.sha256
sha256sum -c preparation.sha256
sha256sum -c inputs-and-binaries.sha256
