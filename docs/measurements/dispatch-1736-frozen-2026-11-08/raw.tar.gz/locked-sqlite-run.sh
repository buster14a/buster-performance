#!/usr/bin/env bash
set -uo pipefail
root=/home/david/buster-fast-bench/1736-codex-01a1bae5
side=${1:?side required}
mode=${2:?mode required}
case "$side-$mode" in main-verify|candidate-verify|main-callgrind|candidate-callgrind) ;; *) exit 2;; esac
test "${BUSTER_9700X_HELD:-}" = 1 || exit 1
receipt="$root/receipts/grant-run-sqlite-$side-$mode"
test ! -e "$receipt" || exit 1
mkdir "$receipt" || exit 1
date -u '+granted=%FT%TZ' > "$receipt/time.txt"
sha256sum "$root/sqlite-run.sh" "$root/locked-sqlite-run.sh" > "$receipt/scripts.sha256"
setsid /usr/bin/timeout --signal=TERM --kill-after=10s 540s /usr/bin/bash "$root/sqlite-run.sh" "$side" "$mode" > "$receipt/output.txt" 2>&1 &
leader=$!
wait "$leader"
status=$?
printf '%s\n' "$status" > "$receipt/status"
if pgrep -g "$leader" > "$receipt/remaining-pids"; then
  kill -TERM -- "-$leader" 2>/dev/null || true
  sleep 1
  if pgrep -g "$leader" > "$receipt/remaining-after-term"; then
    kill -KILL -- "-$leader" 2>/dev/null || true
  fi
  status=1
fi
date -u '+released=%FT%TZ' >> "$receipt/time.txt"
exit "$status"
