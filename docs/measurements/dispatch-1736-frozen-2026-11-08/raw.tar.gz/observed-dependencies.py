#!/usr/bin/env python3
"""List and hash regular files opened read-only in the recorded strace files."""
import hashlib
import os
from pathlib import Path
import re
import sys

root = Path(sys.argv[1]).resolve()
found = set()
directories = set()
missing = set()
for trace in root.glob("receipts/*/reads.strace.*"):
    for line in trace.read_text(errors="replace").splitlines():
        if not re.search(r"\bopen(?:at|at2)?\(", line):
            continue
        if "O_WRONLY" in line or "O_CREAT" in line or "O_TRUNC" in line:
            continue
        match = re.search(r" = \d+<(/[^>]+)>", line)
        if not match:
            continue
        raw = match.group(1)
        if raw.startswith(("/proc/", "/sys/", "/dev/")) or raw.startswith(str(root) + "/"):
            continue
        if " (deleted)" in raw:
            missing.add(raw)
            continue
        path = Path(raw)
        if path.is_file():
            found.add(os.path.realpath(path))
        elif path.is_dir():
            directories.add(os.path.realpath(path))
        else:
            missing.add(raw)
for name in sorted(found):
    digest = hashlib.sha256()
    with open(name, "rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    print(f"{digest.hexdigest()}  {name}")
for name in sorted(directories):
    entries = sorted(os.listdir(name))
    digest = hashlib.sha256("\0".join(entries).encode()).hexdigest()
    print(f"{digest}  DIRECTORY:{name}")
if missing:
    print("unresolved open paths: " + repr(sorted(missing)), file=sys.stderr)
    sys.exit(1)
