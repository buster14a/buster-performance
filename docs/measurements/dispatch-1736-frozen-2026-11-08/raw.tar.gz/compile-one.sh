#!/usr/bin/env bash
set -euo pipefail
root=/home/david/buster-fast-bench/1736-codex-01a1bae5
toolchain=/home/david/.cache/buster/benchpress-clang/efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378
side=${1:?main or candidate}
mode=${2:?ordinary or tagged}
case "$side-$mode" in main-ordinary|main-tagged|candidate-ordinary|candidate-tagged) ;; *) exit 2;; esac
test "$(uname -n)" = benchpress
test "${BUSTER_9700X_HELD:-}" = 1
cd "$root"
sha256sum -c preparation.sha256
sha256sum -c expected.sha256
sha256sum -c inputs-and-binaries.sha256
printf 'c336d48383874cffaab0dc4c5c359456d871f21380b746520dde5c7f4c125a67  %s/bin/clang\n19dd78d959f397ed3b79a7aae9912dce0c057c86a639ad3957de2e541e1ec07a  %s/.manifest\n' "$toolchain" "$toolchain" | sha256sum -c -
suffix=${3:-}
case "$suffix" in ''|-recheck) ;; *) exit 2;; esac
name="sqlite-$side-$mode$suffix"
receipt="$root/receipts/$name"
out="$root/out/$name"
test ! -e "$receipt" && test ! -e "$out"
mkdir "$receipt" "$root/cache/$name" "$root/tmp/$name"
compiler="$root/bin/$side-$mode"
args=(--tier1 -fno-asynchronous-unwind-tables --tier1-report --tier1-refusals --tier1-schedule=none
      -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE
      "-I$root/inputs/sqlite" "-I$root/inputs/st" -o "$out" "$root/inputs/st/speedtest1-unity.c" -lm)
envs=("PATH=$toolchain/bin:/usr/local/bin:/usr/bin:/bin" "LD_LIBRARY_PATH=$toolchain/lib"
      "BUSTER_CLANG_RESOURCE_DIR=$toolchain/lib/clang/23" "HOME=$root/home" "TMPDIR=$root/tmp/$name"
      "XDG_CACHE_HOME=$root/cache/$name" LC_ALL=C SOURCE_DATE_EPOCH=0)
if test "$mode" = tagged; then envs+=("BUSTER_TIER1_KINDS=$receipt/tags.kinds"); fi
printf '%s\0' "$compiler" "${args[@]}" > "$receipt/argv.nul"
printf '%s\n' "${envs[@]}" > "$receipt/environment.txt"
date -u '+started=%FT%TZ' > "$receipt/timing.txt"
uname -a > "$receipt/host.txt"
sha256sum /usr/bin/strace /usr/bin/objdump /usr/bin/readelf "$toolchain/.manifest" "$toolchain/.manifest-complete" "$toolchain/.complete" > "$receipt/tools.sha256"
cd "$root/work"
set +e
env -i "${envs[@]}" /usr/bin/strace -ff -qq -ttt -yy -s 4096 -e trace=%file,%process,read,pread64,mmap,close -e raw=read,pread64 -o "$receipt/reads.strace" "$compiler" "${args[@]}" > "$receipt/stdout" 2> "$receipt/stderr"
status=$?
set -e
printf '%s\n' "$status" > "$receipt/status"
date -u '+finished=%FT%TZ' >> "$receipt/timing.txt"
cd "$root"
sha256sum -c inputs-and-binaries.sha256 > "$receipt/input-recheck.txt"
sha256sum -c "$receipt/tools.sha256" > "$receipt/tool-recheck.txt"
test "$status" -eq 0
test -s "$out"
sha256sum "$out" > "$receipt/elf.sha256"
readelf -W -h -l -d -s "$out" > "$receipt/readelf.txt"
awk '$4 == "FUNC" && $7 != "UND" && $8 == "sqlite3VdbeExec" {print $2, $3, $4, $5, $6, $7, $8}' "$receipt/readelf.txt" | LC_ALL=C sort -u > "$receipt/hot.symbol"
test "$(wc -l < "$receipt/hot.symbol")" -eq 1
sha256sum "$receipt"/reads.strace.* > "$receipt/traces.sha256"
if test "$mode" = tagged; then
  awk -F '\t' '$1 == "tier1-kind-outcome" && $2 == "sqlite3VdbeExec" {print}' "$receipt/stderr" > "$receipt/hot.outcome"
  test "$(wc -l < "$receipt/hot.outcome")" -eq 1
  grep -Eq $'^tier1-kind-outcome\tsqlite3VdbeExec\tcategory=compiled\tstage=tier1\tcause=none\terror=0\temission_error=0\tfallback=0\trecords=[1-9][0-9]*\ttags=[1-9][0-9]*\tT=[0-9]+\tU=[0-9]+\te=[0-9]+$' "$receipt/hot.outcome"
  test -s "$receipt/tags.kinds"
fi
