
/home/david/Documents/Codex/2026-11-19/profile-and-improve-buster-compilation-speed/work/u32-memory-evidence/edges/no-f-default-candidate.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <indexed_f>:
   0:	sub    esi,0x3
   3:	movsxd rax,esi
   6:	mov    r11d,DWORD PTR [rdi+rax*4]
   a:	xorps  xmm0,xmm0
   d:	cvtsi2ss xmm0,r11
  12:	ret
  13:	int3
  14:	int3
  15:	int3
  16:	int3
  17:	int3
  18:	int3
  19:	int3
  1a:	int3
  1b:	int3
  1c:	int3
  1d:	int3
  1e:	int3
  1f:	int3

0000000000000020 <alias_f>:
  20:	movsxd rsi,esi
  23:	mov    eax,DWORD PTR [rdi+rsi*4]
  26:	mov    DWORD PTR [rdi+rsi*4],edx
  29:	mov    r11d,eax
  2c:	xorps  xmm0,xmm0
  2f:	cvtsi2ss xmm0,r11
  34:	ret
  35:	int3
  36:	int3
  37:	int3
  38:	int3
  39:	int3
  3a:	int3
  3b:	int3
  3c:	int3
  3d:	int3
  3e:	int3
  3f:	int3

0000000000000040 <call_f>:
  40:	push   rbx
  41:	movsxd rsi,esi
  44:	mov    ebx,DWORD PTR [rdi+rsi*4]
  47:	lea    rdi,[rdi+rsi*4]
  4b:	mov    rsi,rdx
  4e:	call   53 <call_f+0x13>
  53:	mov    r11d,ebx
  56:	xorps  xmm0,xmm0
  59:	cvtsi2ss xmm0,r11
  5e:	pop    rbx
  5f:	ret

0000000000000060 <volatile_f>:
  60:	movsxd rsi,esi
  63:	mov    eax,DWORD PTR [rdi+rsi*4]
  66:	mov    DWORD PTR [rdi+rsi*4],edx
  69:	mov    r11d,eax
  6c:	xorps  xmm0,xmm0
  6f:	cvtsi2ss xmm0,r11
  74:	ret
  75:	int3
  76:	int3
  77:	int3
  78:	int3
  79:	int3
  7a:	int3
  7b:	int3
  7c:	int3
  7d:	int3
  7e:	int3
  7f:	int3

0000000000000080 <atomic_f>:
  80:	movsxd rsi,esi
  83:	mov    eax,DWORD PTR [rdi+rsi*4]
  86:	mov    r11,rdx
  89:	xchg   DWORD PTR [rdi+rsi*4],r11d
  8d:	mov    r11d,eax
  90:	xorps  xmm0,xmm0
  93:	cvtsi2ss xmm0,r11
  98:	ret
  99:	int3
  9a:	int3
  9b:	int3
  9c:	int3
  9d:	int3
  9e:	int3
  9f:	int3

00000000000000a0 <guarded_f>:
  a0:	test   esi,esi
  a2:	je     b0 <guarded_f+0x10>
  a4:	mov    r11d,DWORD PTR [rdi]
  a7:	xorps  xmm0,xmm0
  aa:	cvtsi2ss xmm0,r11
  af:	ret
  b0:	mov    r11d,edx
  b3:	xorps  xmm0,xmm0
  b6:	cvtsi2ss xmm0,r11
  bb:	ret
  bc:	int3
  bd:	int3
  be:	int3
  bf:	int3

00000000000000c0 <packed_f>:
  c0:	mov    r11d,DWORD PTR [rdi+0x1]
  c4:	xorps  xmm0,xmm0
  c7:	cvtsi2ss xmm0,r11
  cc:	ret
  cd:	int3
  ce:	int3
  cf:	int3

00000000000000d0 <indexed_d>:
  d0:	sub    esi,0x3
  d3:	movsxd rax,esi
  d6:	mov    r11d,DWORD PTR [rdi+rax*4]
  da:	xorps  xmm0,xmm0
  dd:	cvtsi2sd xmm0,r11
  e2:	ret
  e3:	int3
  e4:	int3
  e5:	int3
  e6:	int3
  e7:	int3
  e8:	int3
  e9:	int3
  ea:	int3
  eb:	int3
  ec:	int3
  ed:	int3
  ee:	int3
  ef:	int3

00000000000000f0 <alias_d>:
  f0:	movsxd rsi,esi
  f3:	mov    eax,DWORD PTR [rdi+rsi*4]
  f6:	mov    DWORD PTR [rdi+rsi*4],edx
  f9:	mov    r11d,eax
  fc:	xorps  xmm0,xmm0
  ff:	cvtsi2sd xmm0,r11
 104:	ret
 105:	int3
 106:	int3
 107:	int3
 108:	int3
 109:	int3
 10a:	int3
 10b:	int3
 10c:	int3
 10d:	int3
 10e:	int3
 10f:	int3

0000000000000110 <call_d>:
 110:	push   rbx
 111:	movsxd rsi,esi
 114:	mov    ebx,DWORD PTR [rdi+rsi*4]
 117:	lea    rdi,[rdi+rsi*4]
 11b:	mov    rsi,rdx
 11e:	call   123 <call_d+0x13>
 123:	mov    r11d,ebx
 126:	xorps  xmm0,xmm0
 129:	cvtsi2sd xmm0,r11
 12e:	pop    rbx
 12f:	ret

0000000000000130 <volatile_d>:
 130:	movsxd rsi,esi
 133:	mov    eax,DWORD PTR [rdi+rsi*4]
 136:	mov    DWORD PTR [rdi+rsi*4],edx
 139:	mov    r11d,eax
 13c:	xorps  xmm0,xmm0
 13f:	cvtsi2sd xmm0,r11
 144:	ret
 145:	int3
 146:	int3
 147:	int3
 148:	int3
 149:	int3
 14a:	int3
 14b:	int3
 14c:	int3
 14d:	int3
 14e:	int3
 14f:	int3

0000000000000150 <atomic_d>:
 150:	movsxd rsi,esi
 153:	mov    eax,DWORD PTR [rdi+rsi*4]
 156:	mov    r11,rdx
 159:	xchg   DWORD PTR [rdi+rsi*4],r11d
 15d:	mov    r11d,eax
 160:	xorps  xmm0,xmm0
 163:	cvtsi2sd xmm0,r11
 168:	ret
 169:	int3
 16a:	int3
 16b:	int3
 16c:	int3
 16d:	int3
 16e:	int3
 16f:	int3

0000000000000170 <guarded_d>:
 170:	test   esi,esi
 172:	je     180 <guarded_d+0x10>
 174:	mov    r11d,DWORD PTR [rdi]
 177:	xorps  xmm0,xmm0
 17a:	cvtsi2sd xmm0,r11
 17f:	ret
 180:	mov    r11d,edx
 183:	xorps  xmm0,xmm0
 186:	cvtsi2sd xmm0,r11
 18b:	ret
 18c:	int3
 18d:	int3
 18e:	int3
 18f:	int3

0000000000000190 <packed_d>:
 190:	mov    r11d,DWORD PTR [rdi+0x1]
 194:	xorps  xmm0,xmm0
 197:	cvtsi2sd xmm0,r11
 19c:	ret
