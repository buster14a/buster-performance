#!/usr/bin/env bash
set -euo pipefail
workdir="$HOME/buster-fast-bench/1453-codex-20261106-perf"
sqlite="$HOME/buster-fast-bench/1296-codex-20261105/corpus/sqlite"
export EXCLUSIVE_OWNER=codex-1453 EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1453 LC_ALL=C
cd "$workdir/repo"
git fetch "$workdir/style.bundle" HEAD
git worktree add --detach "$workdir/style" 55f7f86752a3c9d2290ffd3ac33bb9e7b71c31e8
export EXCLUSIVE_TITLE='PR 1453 one-return style build'
"$HOME/buster-fast-bench/exclusive.sh" bash -c '
  set -euo pipefail
  test "${BUSTER_9700X_HELD:-}" = 1
  workdir="$1"
  { printf "held=%s\n" "$BUSTER_9700X_HELD"; cat /var/lib/buster-9700x/owner; } > "$workdir/style-build.receipt"
  env BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0 "$workdir/style/build.sh" --jobs 4 > "$workdir/style-build.log" 2>&1
  { printf "status=0\n"; cat /var/lib/buster-9700x/owner; sha256sum "$workdir/style/build/compiler"; } >> "$workdir/style-build.receipt"
' -- "$workdir"
sha256sum "$workdir/currenthead/build/compiler" "$workdir/style/build/compiler" > "$workdir/style-identities.sha256"
if cmp -s "$workdir/currenthead/build/compiler" "$workdir/style/build/compiler"; then
  printf 'Identical compiled executables\n'
  exit 0
fi
for round in 1 2 3; do
  if [[ "$round" == 2 ]]; then order=(style currenthead); else order=(currenthead style); fi
  for version in "${order[@]}"; do
    export EXCLUSIVE_TITLE="PR 1453 $version style comparison sample $round"
    "$HOME/buster-fast-bench/exclusive.sh" bash -c '
      set -euo pipefail
      version="$1"; round="$2"; workdir="$3"; sqlite="$4"
      test "${BUSTER_9700X_HELD:-}" = 1
      cp "$workdir/$version/build/compiler" "$workdir/compiler"
      prefix="$workdir/$version-style-paired-$round"
      { printf "held=%s\n" "$BUSTER_9700X_HELD"; cat /var/lib/buster-9700x/owner; sha256sum "$workdir/compiler"; } > "$prefix.receipt"
      taskset -c 2 perf stat -x, -e instructions:u,cycles:u -o "$prefix.perf" -- "$workdir/compiler" -fsyntax-only -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$sqlite" "$sqlite/sqlite3.c" > "$prefix.out" 2> "$prefix.err"
      { printf "status=0\n"; cat /var/lib/buster-9700x/owner; sha256sum "$prefix.out" "$prefix.err"; } >> "$prefix.receipt"
    ' -- "$version" "$round" "$workdir" "$sqlite"
  done
done
