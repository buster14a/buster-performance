#!/usr/bin/env bash
set -euo pipefail
root=/home/david/buster-fast-bench/1736-95fb-01a1bae5
baseline=/home/david/buster-fast-bench/1752-current-01a1bae5
side=${1:?base or candidate}
case "$side" in base|candidate) ;; *) exit 2;; esac
kind=${2:-ordinary}
case "$kind" in ordinary|tagged) ;; *) exit 2;; esac
suffix=${3:-}
case "$suffix" in ''|-retry) ;; *) exit 2;; esac
toolchain=/home/david/.cache/buster/benchpress-clang/efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378
export PATH="$toolchain/bin:/usr/local/bin:/usr/bin:/bin" LD_LIBRARY_PATH="$toolchain/lib" BUSTER_CLANG_RESOURCE_DIR="$toolchain/lib/clang/23" LC_ALL=C
unset CPATH C_INCLUDE_PATH OBJC_INCLUDE_PATH BUSTER_HOST_RUNTIME BUSTER_BUILD_DEFINES BUSTER_TIER1_KINDS
record="$root/out/$side-$kind-sqlite$suffix"
test ! -e "$record"
mkdir -p "$record" "$root/tmp/$side-$kind$suffix" "$root/cache/$side-$kind$suffix"
export TMPDIR="$root/tmp/$side-$kind$suffix" XDG_CACHE_HOME="$root/cache/$side-$kind$suffix"
if test "$kind" = tagged; then export BUSTER_TIER1_KINDS="$record/kinds"; fi
compiler="$root/out/$side-$kind"
args=(--tier1 -fno-asynchronous-unwind-tables --tier1-report --tier1-refusals --tier1-schedule=none
      -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE
      "-I$baseline/inputs/sqlite" "-I$baseline/inputs/st" -o "$record/program" "$baseline/inputs/st/speedtest1-unity.c" -lm)
(cd "$baseline/inputs" && sha256sum -c "$baseline/logs/inputs.sha256") > "$record/inputs-before.txt"
printf '%s\0' "$compiler" "${args[@]}" > "$record/argv.nul"
sha256sum "$compiler" > "$record/compiler.sha256"
date -u '+queued=%FT%TZ' > "$record/time.txt"
env EXCLUSIVE_OWNER=codex-1736-95fb-01a1bae5 EXCLUSIVE_TITLE="PR1736 95fb $side SQLite $kind compile" EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1736 \
 /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 540s "$compiler" "${args[@]}" > "$record/stdout" 2> "$record/stderr"
date -u '+finished=%FT%TZ' >> "$record/time.txt"
sha256sum "$record/program" > "$record/program.sha256"
(cd "$baseline/inputs" && sha256sum -c "$baseline/logs/inputs.sha256") > "$record/inputs-after.txt"
