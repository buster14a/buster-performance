
head/TCVTROWPS2PHH.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <tested>:
       0: 48 81 ec 38 04 00 00         	sub	rsp, 0x438
       7: 48 89 bc 24 c8 03 00 00      	mov	qword ptr [rsp + 0x3c8], rdi
       f: 48 89 b4 24 d0 03 00 00      	mov	qword ptr [rsp + 0x3d0], rsi
      17: 66 44 89 84 24 d8 03 00 00   	mov	word ptr [rsp + 0x3d8], r8w
      20: 66 44 89 8c 24 e0 03 00 00   	mov	word ptr [rsp + 0x3e0], r9w
      29: 48 8b 84 24 c8 03 00 00      	mov	rax, qword ptr [rsp + 0x3c8]
      31: 0f b7 8c 24 d8 03 00 00      	movzx	ecx, word ptr [rsp + 0x3d8]
      39: 0f b7 94 24 e0 03 00 00      	movzx	edx, word ptr [rsp + 0x3e0]
      41: 48 8b b4 24 d0 03 00 00      	mov	rsi, qword ptr [rsp + 0x3d0]
      49: 8b bc 24 48 04 00 00         	mov	edi, dword ptr [rsp + 0x448]
      50: 4c 8d 84 24 f0 03 00 00      	lea	r8, [rsp + 0x3f0]
      58: 48 89 04 24                  	mov	qword ptr [rsp], rax
      5c: 48 87 f9                     	xchg	rdi, rcx
      5f: 48 87 f2                     	xchg	rsi, rdx
      62: e8 00 00 00 00               	call	0x67 <tested+0x67>
      67: 48 8b 04 24                  	mov	rax, qword ptr [rsp]
      6b: 62 e1 fe 48 6f 84 24 f0 03 00 00     	vmovdqu64	zmm16, zmmword ptr [rsp + 0x3f0]
      76: 62 e1 fe 48 7f 84 24 48 00 00 00     	vmovdqu64	zmmword ptr [rsp + 0x48], zmm16
      81: 62 e1 fe 48 6f 84 24 48 00 00 00     	vmovdqu64	zmm16, zmmword ptr [rsp + 0x48]
      8c: 62 e1 fe 48 7f 00            	vmovdqu64	zmmword ptr [rax], zmm16
      92: 62 e1 fe 48 7f 84 24 08 00 00 00     	vmovdqu64	zmmword ptr [rsp + 0x8], zmm16
      9d: 48 81 c4 38 04 00 00         	add	rsp, 0x438
      a4: c3                           	ret
      a5: cc                           	int3
      a6: cc                           	int3
      a7: cc                           	int3
      a8: cc                           	int3
      a9: cc                           	int3
      aa: cc                           	int3
      ab: cc                           	int3
      ac: cc                           	int3
      ad: cc                           	int3
      ae: cc                           	int3
      af: cc                           	int3

00000000000000b0 <.Lbuster_builtin_0_0>:
      b0: 55                           	push	rbp
      b1: 48 89 e5                     	mov	rbp, rsp
      b4: 48 83 ec 40                  	sub	rsp, 0x40
      b8: 48 83 e4 c0                  	and	rsp, -0x40
      bc: c5 f8 57 c0                  	vxorps	xmm0, xmm0, xmm0
      c0: 62 f1 fe 48 7f 04 24         	vmovdqu64	zmmword ptr [rsp], zmm0
      c7: c6 04 24 01                  	mov	byte ptr [rsp], 0x1
      cb: 66 89 74 24 10               	mov	word ptr [rsp + 0x10], si
      d0: 40 88 7c 24 30               	mov	byte ptr [rsp + 0x30], dil
      d5: c4 e2 78 49 04 24            	ldtilecfg	[rsp]
      db: c4 e2 7b 4b 04 32            	tileloadd	tmm0, [rdx + rsi]
      e1: 62 f2 74 48 6d c0            	tcvtrowps2phh	zmm0, tmm0, ecx
      e7: 62 d1 fe 48 7f 00            	vmovdqu64	zmmword ptr [r8], zmm0
      ed: c4 e2 78 49 c0               	tilerelease
      f2: 48 89 ec                     	mov	rsp, rbp
      f5: 5d                           	pop	rbp
      f6: c3                           	ret
