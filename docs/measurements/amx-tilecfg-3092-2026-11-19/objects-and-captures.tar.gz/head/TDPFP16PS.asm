
head/TDPFP16PS.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <tested>:
       0: 55                           	push	rbp
       1: 48 89 e5                     	mov	rbp, rsp
       4: 48 81 ec 00 08 00 00         	sub	rsp, 0x800
       b: 48 81 e4 00 fc ff ff         	and	rsp, -0x400
      12: 48 89 7c 24 10               	mov	qword ptr [rsp + 0x10], rdi
      17: 48 89 74 24 18               	mov	qword ptr [rsp + 0x18], rsi
      1c: 48 89 54 24 20               	mov	qword ptr [rsp + 0x20], rdx
      21: 48 89 4c 24 28               	mov	qword ptr [rsp + 0x28], rcx
      26: 66 44 89 44 24 30            	mov	word ptr [rsp + 0x30], r8w
      2c: 66 44 89 4c 24 38            	mov	word ptr [rsp + 0x38], r9w
      32: 48 8b 44 24 10               	mov	rax, qword ptr [rsp + 0x10]
      37: 0f b7 4c 24 30               	movzx	ecx, word ptr [rsp + 0x30]
      3c: 0f b7 54 24 38               	movzx	edx, word ptr [rsp + 0x38]
      41: 0f b7 75 10                  	movzx	esi, word ptr [rbp + 0x10]
      45: 48 8b 7c 24 18               	mov	rdi, qword ptr [rsp + 0x18]
      4a: 4c 8b 44 24 20               	mov	r8, qword ptr [rsp + 0x20]
      4f: 4c 8b 4c 24 28               	mov	r9, qword ptr [rsp + 0x28]
      54: 4c 8d 94 24 00 04 00 00      	lea	r10, [rsp + 0x400]
      5c: 48 89 44 24 08               	mov	qword ptr [rsp + 0x8], rax
      61: 4c 89 14 24                  	mov	qword ptr [rsp], r10
      65: 48 87 f9                     	xchg	rdi, rcx
      68: 48 87 f2                     	xchg	rsi, rdx
      6b: e8 00 00 00 00               	call	0x70 <tested+0x70>
      70: 48 8b 44 24 08               	mov	rax, qword ptr [rsp + 0x8]
      75: 48 8d 8c 24 00 04 00 00      	lea	rcx, [rsp + 0x400]
      7d: ba 00 04 00 00               	mov	edx, 0x400
      82: 48 8b f1                     	mov	rsi, rcx
      85: 48 8b f8                     	mov	rdi, rax
      88: e8 00 00 00 00               	call	0x8d <tested+0x8d>
      8d: 48 89 ec                     	mov	rsp, rbp
      90: 5d                           	pop	rbp
      91: c3                           	ret
      92: cc                           	int3
      93: cc                           	int3
      94: cc                           	int3
      95: cc                           	int3
      96: cc                           	int3
      97: cc                           	int3
      98: cc                           	int3
      99: cc                           	int3
      9a: cc                           	int3
      9b: cc                           	int3
      9c: cc                           	int3
      9d: cc                           	int3
      9e: cc                           	int3
      9f: cc                           	int3

00000000000000a0 <.Lbuster_builtin_0_0>:
      a0: 55                           	push	rbp
      a1: 48 89 e5                     	mov	rbp, rsp
      a4: 48 83 ec 40                  	sub	rsp, 0x40
      a8: 48 83 e4 c0                  	and	rsp, -0x40
      ac: 0f 57 c0                     	xorps	xmm0, xmm0
      af: 0f 11 04 24                  	movups	xmmword ptr [rsp], xmm0
      b3: 0f 11 44 24 10               	movups	xmmword ptr [rsp + 0x10], xmm0
      b8: 0f 11 44 24 20               	movups	xmmword ptr [rsp + 0x20], xmm0
      bd: 0f 11 44 24 30               	movups	xmmword ptr [rsp + 0x30], xmm0
      c2: c6 04 24 01                  	mov	byte ptr [rsp], 0x1
      c6: 66 89 74 24 10               	mov	word ptr [rsp + 0x10], si
      cb: 40 88 7c 24 30               	mov	byte ptr [rsp + 0x30], dil
      d0: 66 89 54 24 12               	mov	word ptr [rsp + 0x12], dx
      d5: 40 88 7c 24 31               	mov	byte ptr [rsp + 0x31], dil
      da: 66 89 74 24 14               	mov	word ptr [rsp + 0x14], si
      df: 8b c2                        	mov	eax, edx
      e1: c1 e8 02                     	shr	eax, 0x2
      e4: 88 44 24 32                  	mov	byte ptr [rsp + 0x32], al
      e8: 4c 8b 5d 10                  	mov	r11, qword ptr [rbp + 0x10]
      ec: c4 e2 78 49 04 24            	ldtilecfg	[rsp]
      f2: c4 e2 7b 4b 04 31            	tileloadd	tmm0, [rcx + rsi]
      f8: c4 c2 7b 4b 0c 10            	tileloadd	tmm1, [r8 + rdx]
      fe: c4 c2 7b 4b 14 31            	tileloadd	tmm2, [r9 + rsi]
     104: c4 e2 6b 5c c1               	tdpfp16ps	tmm0, tmm1, tmm2
     109: 49 8b fb                     	mov	rdi, r11
     10c: b9 80 00 00 00               	mov	ecx, 0x80
     111: 31 c0                        	xor	eax, eax
     113: f3 48 ab                     	rep		stosq	qword ptr es:[rdi], rax
     116: c4 c2 7a 4b 04 33            	tilestored	[r11 + rsi], tmm0
     11c: c4 e2 78 49 c0               	tilerelease
     121: 48 89 ec                     	mov	rsp, rbp
     124: 5d                           	pop	rbp
     125: c3                           	ret
