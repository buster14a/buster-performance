
head/TILELOADD.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <tested>:
       0: 55                           	push	rbp
       1: 48 89 e5                     	mov	rbp, rsp
       4: 48 81 ec 00 08 00 00         	sub	rsp, 0x800
       b: 48 81 e4 00 fc ff ff         	and	rsp, -0x400
      12: 48 89 7c 24 08               	mov	qword ptr [rsp + 0x8], rdi
      17: 48 89 74 24 10               	mov	qword ptr [rsp + 0x10], rsi
      1c: 66 44 89 44 24 18            	mov	word ptr [rsp + 0x18], r8w
      22: 66 44 89 4c 24 20            	mov	word ptr [rsp + 0x20], r9w
      28: 48 8b 44 24 08               	mov	rax, qword ptr [rsp + 0x8]
      2d: 0f b7 4c 24 18               	movzx	ecx, word ptr [rsp + 0x18]
      32: 0f b7 54 24 20               	movzx	edx, word ptr [rsp + 0x20]
      37: 48 8b 74 24 10               	mov	rsi, qword ptr [rsp + 0x10]
      3c: 48 8b 7d 20                  	mov	rdi, qword ptr [rbp + 0x20]
      40: 4c 8d 84 24 00 04 00 00      	lea	r8, [rsp + 0x400]
      48: 48 89 04 24                  	mov	qword ptr [rsp], rax
      4c: 48 87 f9                     	xchg	rdi, rcx
      4f: 48 87 f2                     	xchg	rsi, rdx
      52: e8 00 00 00 00               	call	0x57 <tested+0x57>
      57: 48 8b 04 24                  	mov	rax, qword ptr [rsp]
      5b: 48 8d 8c 24 00 04 00 00      	lea	rcx, [rsp + 0x400]
      63: ba 00 04 00 00               	mov	edx, 0x400
      68: 48 8b f1                     	mov	rsi, rcx
      6b: 48 8b f8                     	mov	rdi, rax
      6e: e8 00 00 00 00               	call	0x73 <tested+0x73>
      73: 48 89 ec                     	mov	rsp, rbp
      76: 5d                           	pop	rbp
      77: c3                           	ret
      78: cc                           	int3
      79: cc                           	int3
      7a: cc                           	int3
      7b: cc                           	int3
      7c: cc                           	int3
      7d: cc                           	int3
      7e: cc                           	int3
      7f: cc                           	int3

0000000000000080 <.Lbuster_builtin_0_0>:
      80: 55                           	push	rbp
      81: 48 89 e5                     	mov	rbp, rsp
      84: 48 83 ec 40                  	sub	rsp, 0x40
      88: 48 83 e4 c0                  	and	rsp, -0x40
      8c: 0f 57 c0                     	xorps	xmm0, xmm0
      8f: 0f 11 04 24                  	movups	xmmword ptr [rsp], xmm0
      93: 0f 11 44 24 10               	movups	xmmword ptr [rsp + 0x10], xmm0
      98: 0f 11 44 24 20               	movups	xmmword ptr [rsp + 0x20], xmm0
      9d: 0f 11 44 24 30               	movups	xmmword ptr [rsp + 0x30], xmm0
      a2: c6 04 24 01                  	mov	byte ptr [rsp], 0x1
      a6: 66 89 74 24 10               	mov	word ptr [rsp + 0x10], si
      ab: 40 88 7c 24 30               	mov	byte ptr [rsp + 0x30], dil
      b0: c4 e2 78 49 04 24            	ldtilecfg	[rsp]
      b6: c4 e2 7b 4b 04 0a            	tileloadd	tmm0, [rdx + rcx]
      bc: 49 8b f8                     	mov	rdi, r8
      bf: b9 80 00 00 00               	mov	ecx, 0x80
      c4: 31 c0                        	xor	eax, eax
      c6: f3 48 ab                     	rep		stosq	qword ptr es:[rdi], rax
      c9: c4 c2 7a 4b 04 30            	tilestored	[r8 + rsi], tmm0
      cf: c4 e2 78 49 c0               	tilerelease
      d4: 48 89 ec                     	mov	rsp, rbp
      d7: 5d                           	pop	rbp
      d8: c3                           	ret
