
base/TILESTORED.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <tested>:
       0: 48 83 ec 28                  	sub	rsp, 0x28
       4: 48 89 3c 24                  	mov	qword ptr [rsp], rdi
       8: 48 89 74 24 08               	mov	qword ptr [rsp + 0x8], rsi
       d: 66 44 89 44 24 10            	mov	word ptr [rsp + 0x10], r8w
      13: 66 44 89 4c 24 18            	mov	word ptr [rsp + 0x18], r9w
      19: 0f b7 44 24 10               	movzx	eax, word ptr [rsp + 0x10]
      1e: 0f b7 4c 24 18               	movzx	ecx, word ptr [rsp + 0x18]
      23: 48 8b 14 24                  	mov	rdx, qword ptr [rsp]
      27: 48 8b 74 24 40               	mov	rsi, qword ptr [rsp + 0x40]
      2c: 48 8b 7c 24 08               	mov	rdi, qword ptr [rsp + 0x8]
      31: 4c 8b c7                     	mov	r8, rdi
      34: 48 8b f8                     	mov	rdi, rax
      37: 48 87 f1                     	xchg	rsi, rcx
      3a: e8 00 00 00 00               	call	0x3f <tested+0x3f>
      3f: 48 83 c4 28                  	add	rsp, 0x28
      43: c3                           	ret
      44: cc                           	int3
      45: cc                           	int3
      46: cc                           	int3
      47: cc                           	int3
      48: cc                           	int3
      49: cc                           	int3
      4a: cc                           	int3
      4b: cc                           	int3
      4c: cc                           	int3
      4d: cc                           	int3
      4e: cc                           	int3
      4f: cc                           	int3

0000000000000050 <.Lbuster_builtin_0_0>:
      50: 55                           	push	rbp
      51: 48 89 e5                     	mov	rbp, rsp
      54: 48 83 ec 40                  	sub	rsp, 0x40
      58: 48 83 e4 c0                  	and	rsp, -0x40
      5c: 31 c0                        	xor	eax, eax
      5e: 48 89 04 24                  	mov	qword ptr [rsp], rax
      62: 48 89 44 24 08               	mov	qword ptr [rsp + 0x8], rax
      67: 48 89 44 24 10               	mov	qword ptr [rsp + 0x10], rax
      6c: 48 89 44 24 18               	mov	qword ptr [rsp + 0x18], rax
      71: 48 89 44 24 20               	mov	qword ptr [rsp + 0x20], rax
      76: 48 89 44 24 28               	mov	qword ptr [rsp + 0x28], rax
      7b: 48 89 44 24 30               	mov	qword ptr [rsp + 0x30], rax
      80: 48 89 44 24 38               	mov	qword ptr [rsp + 0x38], rax
      85: c6 04 24 01                  	mov	byte ptr [rsp], 0x1
      89: 66 89 74 24 10               	mov	word ptr [rsp + 0x10], si
      8e: 40 88 7c 24 30               	mov	byte ptr [rsp + 0x30], dil
      93: c4 e2 78 49 04 24            	ldtilecfg	[rsp]
      99: c4 c2 7b 4b 04 30            	tileloadd	tmm0, [r8 + rsi]
      9f: c4 e2 7a 4b 04 0a            	tilestored	[rdx + rcx], tmm0
      a5: c4 e2 78 49 c0               	tilerelease
      aa: 48 89 ec                     	mov	rsp, rbp
      ad: 5d                           	pop	rbp
      ae: c3                           	ret
