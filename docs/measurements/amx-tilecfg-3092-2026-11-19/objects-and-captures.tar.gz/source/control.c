unsigned control(unsigned x) { return x + 1; }
