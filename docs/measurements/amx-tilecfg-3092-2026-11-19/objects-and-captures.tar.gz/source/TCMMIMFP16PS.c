typedef int Tile __attribute__((vector_size(1024), aligned(64)));
__attribute__((target("amx-complex")))
void tested(void *out, const Tile *a, const Tile *b, const Tile *c, unsigned short m, unsigned short n, unsigned short k, unsigned row, unsigned long stride)
{
    *(Tile*)out = __builtin_ia32_tcmmimfp16ps_internal(m, n, k, *a, *b, *c);
}
