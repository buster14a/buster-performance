typedef int Tile __attribute__((vector_size(1024), aligned(64)));
__attribute__((target("amx-avx512,avx10.2")))
void tested(void *out, const Tile *a, const Tile *b, const Tile *c, unsigned short m, unsigned short n, unsigned short k, unsigned row, unsigned long stride)
{
    typedef __bf16 V __attribute__((vector_size(64))); *(V*)out = __builtin_ia32_tcvtrowps2bf16h_internal(m, n, *a, row);
}
