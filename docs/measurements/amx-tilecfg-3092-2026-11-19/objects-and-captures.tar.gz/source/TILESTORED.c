typedef int Tile __attribute__((vector_size(1024), aligned(64)));
__attribute__((target("amx-tile")))
void tested(void *out, const Tile *a, const Tile *b, const Tile *c, unsigned short m, unsigned short n, unsigned short k, unsigned row, unsigned long stride)
{
    __builtin_ia32_tilestored64_internal(m, n, out, stride, *a);
}
