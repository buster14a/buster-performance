#!/usr/bin/env bash
set -euo pipefail
root=/home/david/buster-fast-bench/1736-current-01a1bae5
kind=${1:?ordinary or tagged}
case "$kind" in ordinary|tagged) ;; *) exit 2;; esac
clangroot=/home/david/.cache/buster/benchpress-clang/efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378
export PATH="$clangroot/bin:/usr/local/bin:/usr/bin:/bin" LD_LIBRARY_PATH="$clangroot/lib" BUSTER_CLANG_RESOURCE_DIR="$clangroot/lib/clang/23" LC_ALL=C
unset CPATH C_INCLUDE_PATH OBJC_INCLUDE_PATH BUSTER_HOST_RUNTIME BUSTER_TIER1_KINDS
printf '%s  %s\n' 141776fef464c4555a5e04387681109bd85f766ec480f1c95a8d1edcb22e58e7 "$root/kinds.patch" | sha256sum -c -
cd "$root/source"
defines=
if test "$kind" = tagged; then defines=-DBUSTER_TIER1_MEASURE_KINDS=1; fi
date -u +%FT%TZ > "$root/logs/$kind-start.txt"
env EXCLUSIVE_OWNER=codex-1736-current-01a1bae5 EXCLUSIVE_TITLE="PR1736 current candidate $kind build" EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1736 \
  /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 540s \
  env BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0 BUSTER_BUILD_DEFINES="$defines" ./build.sh --jobs 8 > "$root/logs/$kind-build.log" 2>&1
cp build/compiler "$root/out/candidate-$kind"
sha256sum "$root/out/candidate-$kind" > "$root/logs/$kind.sha256"
date -u +%FT%TZ > "$root/logs/$kind-end.txt"
