#define MAKE(x) x
#define STAMP _Pragma("clang diagnostic push")
