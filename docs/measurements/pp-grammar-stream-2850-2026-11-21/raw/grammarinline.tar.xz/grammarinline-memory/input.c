typedef int I;
int f(I x) { return 5 + x; }
