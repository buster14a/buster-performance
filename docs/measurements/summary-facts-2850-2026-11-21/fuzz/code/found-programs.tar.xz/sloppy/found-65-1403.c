struct pair { int first; long second; int (*call)(int); int list[4]; struct pair* next; char tag; unsigned bits : 3; };
enum color { RED, GREEN = 5, BLUE = 70000 };
typedef __SIZE_TYPE__ size_t;
extern int g;
static int sg;
extern long gl;
extern unsigned gu;
extern char gc;
extern short gh;
extern double gd;
extern float gflt;
int ga[8];
static char sc[16];
struct pair gp;
static struct pair sp;
extern struct pair* gq;
extern const char* names[4];
extern int weak_one __attribute__((weak));
int one(int a);
int callee(int a, long b);
long wide(long a);
double real(double a);
void voided(void);
void stop(void) __attribute__((noreturn));
extern int (*gf)(int);
int f(int a, long b, char c, int* p, struct pair* q, int (*fp)(int), double d, unsigned u, short h, char* s)
{
    static int counter;
    int local = 0;
    long along = 0;
    double dl = 0;
    int* ptr = 0;
    char* text = 0;
    unsigned char uc = 0;
    along = (short)"abc" + 1;
    return local + (int)along + (int)dl + (ptr != 0) + (text != 0) + counter + uc;
}
