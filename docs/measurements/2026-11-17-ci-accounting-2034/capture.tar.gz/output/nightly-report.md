## Nightly main measurements: cycle 2026-11-17

Mode: **run**. Europe/Madrid time 07:41 CET, inside the window (02:00 to 08:00).

Snapshot: `178c9e2606fb086025126d6f2521098342c75773`, pinned earlier this cycle, the newest of 1105 first-parent states in scope, from `a98b996eee47`, the epoch: the main commit that added the nightly worker. The 34 first-parent states of the last fortnight before it are out of scope: their workflow can't run as a nightly worker, and their coverage is what their pushes and the old daily run measured.
This cycle's comprehensive run measures `178c9e2606fb086025126d6f2521098342c75773`, the snapshot.

| Status | States |
| --- | ---: |
| not-required | 65 |
| complete | 153 |
| in-flight | 0 |
| blocked-native | 421 |
| blocked-hosted | 79 |
| failed | 1 |
| ready | 385 |
| preparing | 0 |
| needs-preparation | 1 |

Complete by a pull request's reused measurement: 0. This cycle: 60 hardware runs selected, 0 completed, 60 failed or blocked, 0 deferred; 40 hosted preparations.
Carried over: 386 states; the oldest is `d90075350630d027886cd5a244d2edb48c7d39ce`, committed 133.8 hours ago.
Capacity: 89.7 code states a day arrived over the last 7.0 days; 0.3 completed per cycle over 7 cycles.

Merge queue: 175 states since `a6ba875e9d5a`, the first a candidate's run tested; 0 without a passing candidate's run of their own commit.

**The backlog cannot drain at this rate**: arrivals exceed the observed nightly capacity, or the oldest pending state is over three days old.

### Evidence

- `013ceb613493` complete: https://github.com/buster14a/buster/actions/runs/43538151259
- `090b0faa8c59` complete: https://github.com/buster14a/buster/actions/runs/43341714661
- `a3d33e10c69f` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43236344900
- `eedbdece0c01` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43229509757
- `c79858dd79a9` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43190175300
- `e5d6243932d5` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43189193445
- `00be045df908` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43189160326
- `533730d3fb61` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43188417748
- `b59aa86f7a13` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43187542961
- `4e2f80da9c30` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43184932762
- `5807175401d5` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43184470405
- `100321cb0abc` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43120480914
- `5f849d1cb19a` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43116139530
- `86f0d73000a9` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43106632058
- `66e34536421c` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43066809428
- `7c625a187605` blocked-hosted: https://github.com/buster14a/buster/actions/runs/43064400880
- `9b26112acc82` blocked-native: https://github.com/buster14a/buster/actions/runs/44032126732
- `9e3a613689f0` blocked-native: https://github.com/buster14a/buster/actions/runs/44031514310
- `6fbdc3341840` blocked-native: https://github.com/buster14a/buster/actions/runs/44030916206
- `e29df96476c6` blocked-native: https://github.com/buster14a/buster/actions/runs/44030312729
- `d97f123cb9be` blocked-native: https://github.com/buster14a/buster/actions/runs/44029523395
- `5f31df917d51` blocked-native: https://github.com/buster14a/buster/actions/runs/44028917207
- `a182b6713ef2` blocked-native: https://github.com/buster14a/buster/actions/runs/44028324832
- `be4c78e67b91` blocked-native: https://github.com/buster14a/buster/actions/runs/44027572087
- `de32ed91e4e0` blocked-native: https://github.com/buster14a/buster/actions/runs/44026826345
- `75f5ca6899e3` blocked-native: https://github.com/buster14a/buster/actions/runs/44026269266
- `b232fd53e318` blocked-native: https://github.com/buster14a/buster/actions/runs/44025534174
- `a88e553e49a3` blocked-native: https://github.com/buster14a/buster/actions/runs/44024972843
- `feb35c2ecfae` blocked-native: https://github.com/buster14a/buster/actions/runs/44024401251
- `f0b5add22f41` blocked-native: https://github.com/buster14a/buster/actions/runs/44023836203
- `31921dfdfffc` blocked-native: https://github.com/buster14a/buster/actions/runs/44023070581
- `fe36feed4f08` blocked-native: https://github.com/buster14a/buster/actions/runs/44022473028
- `d36aed26dc3a` blocked-native: https://github.com/buster14a/buster/actions/runs/44021893066
- `f6c9556fcd3f` blocked-native: https://github.com/buster14a/buster/actions/runs/44021316622
- `9646ec6fc38f` blocked-native: https://github.com/buster14a/buster/actions/runs/44020756881
- `05b8b90d19a2` blocked-native: https://github.com/buster14a/buster/actions/runs/44020225530
- `a93476c73911` blocked-native: https://github.com/buster14a/buster/actions/runs/44019684612
- `e05ad580f328` blocked-native: https://github.com/buster14a/buster/actions/runs/44019129405
- `7535f2434cdc` blocked-native: https://github.com/buster14a/buster/actions/runs/44018587908
- `4435b753866f` blocked-native: https://github.com/buster14a/buster/actions/runs/44018028814

### Remaining, oldest first

- `d90075350630` ready
- `d781d70cf25e` ready
- `915bc1ba2b32` ready
- `647fa88d7b08` ready
- `41b5cf0310c5` ready
- `7db251fb92b8` ready
- `ac227d0ad726` ready
- `827c955f6b44` ready
- `7e745c6230df` ready
- `13cb3dd842dc` ready
- `d5b7cd7aa7fd` ready
- `96503c9b8545` ready
- `7e0cbf0cf17b` ready
- `ed7e8b819a39` ready
- `1a9a6b79847b` ready
- `ffc203d29e70` ready
- `05d9b197853f` ready
- `4f07ef3ff6fc` ready
- `295d239217f6` ready
- `a654e911d694` ready
- `bd4e76716379` needs-preparation
- `7be0864fad0e` ready
- `35dda0b6f4f4` ready
- `f4171ccc0bc0` ready
- `1a97e67bb68c` ready
- `a64f6a8cd0c4` ready
- `20947235daa2` ready
- `6a93a60d8573` ready
- `df4f1fcff4aa` ready
- `3e6d6ee657ab` ready
- ...

