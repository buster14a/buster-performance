typedef int result; typedef int word; typedef int *ptr; typedef long tall;
extern result f0(void);
result value0(word x) {
 return f0(
 
 );
}
void stmt0(word x) {
 f0(
 
 );
}
extern result f1(word);
result value1(word x) {
 return f1(
 20
 );
}
void stmt1(word x) {
 f1(
 x
 );
}
extern result f2(word, word);
result value2(word x) {
 return f2(
 20,
 21
 );
}
void stmt2(word x) {
 f2(
 x,
 31
 );
}
extern result f3(word, word, word);
result value3(word x) {
 return f3(
 20,
 21,
 22
 );
}
void stmt3(word x) {
 f3(
 x,
 31,
 x
 );
}
extern result f4(word, word, word, word);
result value4(word x) {
 return f4(
 20,
 21,
 22,
 23
 );
}
void stmt4(word x) {
 f4(
 x,
 31,
 x,
 33
 );
}
extern result f5(word, word, word, word, word);
result value5(word x) {
 return f5(
 20,
 21,
 22,
 23,
 24
 );
}
void stmt5(word x) {
 f5(
 x,
 31,
 x,
 33,
 x
 );
}
extern result f6(word, word, word, word, word, word);
result value6(word x) {
 return f6(
 20,
 21,
 22,
 23,
 24,
 25
 );
}
void stmt6(word x) {
 f6(
 x,
 31,
 x,
 33,
 x,
 35
 );
}
extern result f7(word, word, word, word, word, word, word);
result value7(word x) {
 return f7(
 20,
 21,
 22,
 23,
 24,
 25,
 26
 );
}
void stmt7(word x) {
 f7(
 x,
 31,
 x,
 33,
 x,
 35,
 x
 );
}
extern result f8(word, word, word, word, word, word, word, word);
result value8(word x) {
 return f8(
 20,
 21,
 22,
 23,
 24,
 25,
 26,
 27
 );
}
void stmt8(word x) {
 f8(
 x,
 31,
 x,
 33,
 x,
 35,
 x,
 37
 );
}
extern word mixed(word,ptr,tall,word);
result mixed_use(word a, ptr p, tall l) {return mixed(a, p, l, 11);}
static int inside(word x) { return x*9; }
result static_use(word val) { return inside(val); }
#define ARG 10
#define APPLY(T) f1(T)
#line 113 "virtual-source.h"
result macro_exp(void) {return APPLY(ARG);}
result shadowed(word x) { { typedef word local; local x = 2; return f1(x); } }
