// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Independent guard-page test of the 16-lane selection and masked tail load.
#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>

static uint32_t rng = 0x8b3a5f19;
static uint32_t next_random(void)
{
    rng ^= rng << 13;
    rng ^= rng >> 17;
    rng ^= rng << 5;
    return rng;
}

int main(void)
{
    const long page = sysconf(_SC_PAGESIZE);
    if (page <= 0) return 2;
    uint8_t* const eval_map = mmap(NULL, (size_t)page * 2, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    uint8_t* const ops_map = mmap(NULL, (size_t)page * 2, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (eval_map == MAP_FAILED || ops_map == MAP_FAILED) return 2;
    if (mprotect(eval_map + page, (size_t)page, PROT_NONE) || mprotect(ops_map + page, (size_t)page, PROT_NONE)) return 2;
    uint64_t checks = 0;
    for (uint32_t live = 1; live <= 16; live += 1)
    {
        uint8_t* const evaluated = eval_map + page - live;
        uint32_t* const ops = (uint32_t*)(ops_map + page - live * sizeof(uint32_t));
        for (uint32_t iteration = 0; iteration < 1024; iteration += 1)
        {
            uint32_t set[4];
            for (uint32_t i = 0; i < 4; i += 1) set[i] = next_random();
            uint32_t expected = 0;
            for (uint32_t i = 0; i < live; i += 1)
            {
                ops[i] = next_random() & 127u;
                const uint32_t r = next_random() & 3u;
                evaluated[i] = (uint8_t)(r == 0 ? 0 : r == 1 ? 1 : r == 2 ? 2 : 255);
                expected |= (uint32_t)((set[ops[i] >> 5] & (1u << (ops[i] & 31))) != 0 && evaluated[i] == 0) << i;
            }
            const uint32_t lanes = live == 16 ? 0xffffu : (1u << live) - 1;
            const __m512i words = _mm512_maskz_loadu_epi32((__mmask16)15u, set);
            const __m512i op_words = _mm512_maskz_loadu_epi32((__mmask16)lanes, ops);
            const __m512i word = _mm512_permutexvar_epi32(_mm512_srli_epi32(op_words, 5), words);
            const __m512i bit = _mm512_sllv_epi32(_mm512_set1_epi32(1), _mm512_and_si512(op_words, _mm512_set1_epi32(31)));
            uint32_t selected = _mm512_mask_test_epi32_mask((__mmask16)lanes, word, bit);
            const __m128i states = _mm_maskz_loadu_epi8((__mmask16)lanes, evaluated);
            selected &= _mm_cmpeq_epi8_mask(states, _mm_setzero_si128());
            if (selected != expected)
            {
                fprintf(stderr, "mismatch live=%u iteration=%u expected=%x actual=%x\n", live, iteration, expected, selected);
                return 1;
            }
            checks += 1;
        }
    }
    printf("guard-page lane selections: %llu checked, 0 failures\n", (unsigned long long)checks);
    munmap(eval_map, (size_t)page * 2);
    munmap(ops_map, (size_t)page * 2);
    return 0;
}
