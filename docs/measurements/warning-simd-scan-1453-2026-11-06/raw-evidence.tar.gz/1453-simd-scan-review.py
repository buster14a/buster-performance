import itertools
import os
import subprocess
import sys

parent, candidate = map(os.path.abspath, sys.argv[1:])
contexts = [
    'int run(int c) { if (0) return c ? 1.5 : 2.5; return 0; }',
    'int run(int c) { if (0) return c ? 1.5 : (double _Complex)0; return 0; }',
    'int run(int c) { if (0) return (side(), c ? 1.5 : 2.5); return 0; }',
    'int run(int c) { if (0) { int a[3] = {1.5, 2.5, 3.5}; return a[c]; } return 0; }',
    'int run(int c) { if (0) { struct S s = {.a=1.5, .b=2.5}; return s.a; } return c; }',
    'int run(int c) { return 0 && take(c ? 1.5 : 2.5); }',
    'int run(int c) { return 1 || take((side(), 1.5)); }',
    'int run(int c) { return _Generic(0, int: c, default: take(1.5)); }',
    'int run(int c) { if (0) { int x = c ? 1.5 : take(2.5); return x; } return 0; }',
    'int run(int c) { if (0) return (side(), (side(), 1.5)); return c; }',
    'int run(int c) { if (0) { unsigned char b[2] = {[0 ... 1]=257}; return b[c]; } return 0; }',
    'int run(int c) { if (0) return c ? (side(), 1.5) : 3.0; return 0; }',
]
prelude = 'struct S { int a; int b; }; int take(int); int side(void);\n'
flags = [[], ['-Werror=literal-conversion'], ['-Wno-literal-conversion']]
padding = [0, 1, 2, 3, 7, 15, 16, 17]
count = 0
differences = []
for context, pad, scalar, std, options in itertools.product(contexts, padding, [False, True], ['c17', 'c23'], flags):
    prefix = ''.join(f'int p{i}={i};\n' for i in range(pad))
    source = prelude + prefix + context + '\n'
    arguments = ['-std=' + std, '-fsyntax-only', '-fno-caret-diagnostics', '-x', 'c', *options, *(['--scalar'] if scalar else []), '-']
    old, new = [subprocess.run([exe, *arguments], input=source, text=True, capture_output=True) for exe in (parent, candidate)]
    count += 1
    if (old.returncode, old.stdout, old.stderr) != (new.returncode, new.stdout, new.stderr):
        differences.append((context, pad, scalar, std, options, old.returncode, new.returncode, old.stderr, new.stderr))
print('comparisons', count, 'differences', len(differences))
for item in differences[:8]: print(item)
if differences: raise SystemExit(1)
