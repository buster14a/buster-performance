#!/usr/bin/env bash
set -euo pipefail
workdir="$HOME/buster-fast-bench/1453-codex-20261106-perf"
sqlite="$HOME/buster-fast-bench/1296-codex-20261105/corpus/sqlite"
export EXCLUSIVE_OWNER=codex-1453 EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1453 LC_ALL=C
cd "$workdir/repo"
git fetch "$workdir/candidate12.bundle" HEAD
for entry in candidate12:a60ed16b0f7e8e1c13f067495320348fec44fee7; do
  version="${entry%%:*}"; sha="${entry#*:}"
  git worktree add --detach "$workdir/$version" "$sha"
  export EXCLUSIVE_TITLE="PR 1453 $version unevaluated SIMD scan build"
  "$HOME/buster-fast-bench/exclusive.sh" env BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0 "$workdir/$version/build.sh" --jobs 4 > "$workdir/$version-build.log" 2>&1
  sha256sum "$workdir/$version/build/compiler" > "$workdir/$version.sha256"
done
for round in 1 2 3; do
  if [[ "$round" == 2 ]]; then order=(candidate12 style); else order=(style candidate12); fi
  for version in "${order[@]}"; do
    export EXCLUSIVE_TITLE="PR 1453 $version unevaluated SIMD scan sample $round"
    "$HOME/buster-fast-bench/exclusive.sh" bash -c '
      set -euo pipefail
      version="$1"; round="$2"; workdir="$3"; sqlite="$4"
      test "${BUSTER_9700X_HELD:-}" = 1
      cp "$workdir/$version/build/compiler" "$workdir/compiler"
      prefix="$workdir/$version-c12-paired-$round"
      { printf "held=%s\n" "$BUSTER_9700X_HELD"; cat /var/lib/buster-9700x/owner; sha256sum "$workdir/compiler"; } > "$prefix.receipt"
      taskset -c 2 perf stat -x, -e instructions:u,cycles:u -o "$prefix.perf" -- "$workdir/compiler" -fsyntax-only -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$sqlite" "$sqlite/sqlite3.c" > "$prefix.out" 2> "$prefix.err"
      { printf "status=0\n"; cat /var/lib/buster-9700x/owner; sha256sum "$prefix.out" "$prefix.err"; } >> "$prefix.receipt"
    ' -- "$version" "$round" "$workdir" "$sqlite"
  done
done
