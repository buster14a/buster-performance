
results/costv2/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f7d3d0 <node_facts_window_run>:
 1f7d3d0:	push   %rbp
 1f7d3d1:	push   %r15
 1f7d3d3:	push   %r14
 1f7d3d5:	push   %r13
 1f7d3d7:	push   %r12
 1f7d3d9:	push   %rbx
 1f7d3da:	sub    $0xca8,%rsp
 1f7d3e1:	mov    0x940(%rdi),%r14
 1f7d3e8:	mov    0x8(%rsi),%r15d
 1f7d3ec:	mov    %rsi,%rbp
 1f7d3ef:	test   %r15,%r15
 1f7d3f2:	je     1f7d5b6 <node_facts_window_run+0x1e6>
 1f7d3f8:	mov    %r15d,%eax
 1f7d3fb:	and    $0x7,%eax
 1f7d3fe:	cmp    $0x8,%r15d
 1f7d402:	jae    1f7d40b <node_facts_window_run+0x3b>
 1f7d404:	xor    %ecx,%ecx
 1f7d406:	jmp    1f7d9ae <node_facts_window_run+0x5de>
 1f7d40b:	mov    %r15d,%edx
 1f7d40e:	and    $0xfffffff8,%edx
 1f7d411:	xor    %ecx,%ecx
 1f7d413:	jmp    1f7d43b <node_facts_window_run+0x6b>
 1f7d415:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7d420:	xor    %esi,%esi
 1f7d422:	mov    0x9c0(%rdi),%r8
 1f7d429:	mov    %sil,0x7(%r8,%rcx,1)
 1f7d42e:	add    $0x8,%rcx
 1f7d432:	cmp    %rcx,%rdx
 1f7d435:	je     1f7d5ad <node_facts_window_run+0x1dd>
 1f7d43b:	mov    0x9b8(%rdi),%rsi
 1f7d442:	cmpb   $0x0,(%rsi,%rcx,1)
 1f7d446:	je     1f7d460 <node_facts_window_run+0x90>
 1f7d448:	movzbl 0x69454(%rbp,%rcx,1),%esi
 1f7d450:	jmp    1f7d462 <node_facts_window_run+0x92>
 1f7d452:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d460:	xor    %esi,%esi
 1f7d462:	mov    0x9c0(%rdi),%r8
 1f7d469:	mov    %sil,(%r8,%rcx,1)
 1f7d46d:	mov    0x9b8(%rdi),%rsi
 1f7d474:	cmpb   $0x0,0x1(%rsi,%rcx,1)
 1f7d479:	je     1f7d490 <node_facts_window_run+0xc0>
 1f7d47b:	movzbl 0x69455(%rbp,%rcx,1),%esi
 1f7d483:	jmp    1f7d492 <node_facts_window_run+0xc2>
 1f7d485:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7d490:	xor    %esi,%esi
 1f7d492:	mov    0x9c0(%rdi),%r8
 1f7d499:	mov    %sil,0x1(%r8,%rcx,1)
 1f7d49e:	mov    0x9b8(%rdi),%rsi
 1f7d4a5:	cmpb   $0x0,0x2(%rsi,%rcx,1)
 1f7d4aa:	je     1f7d4c0 <node_facts_window_run+0xf0>
 1f7d4ac:	movzbl 0x69456(%rbp,%rcx,1),%esi
 1f7d4b4:	jmp    1f7d4c2 <node_facts_window_run+0xf2>
 1f7d4b6:	cs nopw 0x0(%rax,%rax,1)
 1f7d4c0:	xor    %esi,%esi
 1f7d4c2:	mov    0x9c0(%rdi),%r8
 1f7d4c9:	mov    %sil,0x2(%r8,%rcx,1)
 1f7d4ce:	mov    0x9b8(%rdi),%rsi
 1f7d4d5:	cmpb   $0x0,0x3(%rsi,%rcx,1)
 1f7d4da:	je     1f7d4f0 <node_facts_window_run+0x120>
 1f7d4dc:	movzbl 0x69457(%rbp,%rcx,1),%esi
 1f7d4e4:	jmp    1f7d4f2 <node_facts_window_run+0x122>
 1f7d4e6:	cs nopw 0x0(%rax,%rax,1)
 1f7d4f0:	xor    %esi,%esi
 1f7d4f2:	mov    0x9c0(%rdi),%r8
 1f7d4f9:	mov    %sil,0x3(%r8,%rcx,1)
 1f7d4fe:	mov    0x9b8(%rdi),%rsi
 1f7d505:	cmpb   $0x0,0x4(%rsi,%rcx,1)
 1f7d50a:	je     1f7d520 <node_facts_window_run+0x150>
 1f7d50c:	movzbl 0x69458(%rbp,%rcx,1),%esi
 1f7d514:	jmp    1f7d522 <node_facts_window_run+0x152>
 1f7d516:	cs nopw 0x0(%rax,%rax,1)
 1f7d520:	xor    %esi,%esi
 1f7d522:	mov    0x9c0(%rdi),%r8
 1f7d529:	mov    %sil,0x4(%r8,%rcx,1)
 1f7d52e:	mov    0x9b8(%rdi),%rsi
 1f7d535:	cmpb   $0x0,0x5(%rsi,%rcx,1)
 1f7d53a:	je     1f7d550 <node_facts_window_run+0x180>
 1f7d53c:	movzbl 0x69459(%rbp,%rcx,1),%esi
 1f7d544:	jmp    1f7d552 <node_facts_window_run+0x182>
 1f7d546:	cs nopw 0x0(%rax,%rax,1)
 1f7d550:	xor    %esi,%esi
 1f7d552:	mov    0x9c0(%rdi),%r8
 1f7d559:	mov    %sil,0x5(%r8,%rcx,1)
 1f7d55e:	mov    0x9b8(%rdi),%rsi
 1f7d565:	cmpb   $0x0,0x6(%rsi,%rcx,1)
 1f7d56a:	je     1f7d580 <node_facts_window_run+0x1b0>
 1f7d56c:	movzbl 0x6945a(%rbp,%rcx,1),%esi
 1f7d574:	jmp    1f7d582 <node_facts_window_run+0x1b2>
 1f7d576:	cs nopw 0x0(%rax,%rax,1)
 1f7d580:	xor    %esi,%esi
 1f7d582:	mov    0x9c0(%rdi),%r8
 1f7d589:	mov    %sil,0x6(%r8,%rcx,1)
 1f7d58e:	mov    0x9b8(%rdi),%rsi
 1f7d595:	cmpb   $0x0,0x7(%rsi,%rcx,1)
 1f7d59a:	je     1f7d420 <node_facts_window_run+0x50>
 1f7d5a0:	movzbl 0x6945b(%rbp,%rcx,1),%esi
 1f7d5a8:	jmp    1f7d422 <node_facts_window_run+0x52>
 1f7d5ad:	test   %rax,%rax
 1f7d5b0:	jne    1f7d9ae <node_facts_window_run+0x5de>
 1f7d5b6:	vpbroadcastq %rbp,%ymm0
 1f7d5bc:	vpaddq -0x19bbda4(%rip),%ymm0,%ymm0        # 5c1820 <.LCPI3_0>
 1f7d5c4:	vmovups 0x1f0(%rdi),%zmm1
 1f7d5ce:	mov    0x9c0(%rdi),%rax
 1f7d5d5:	mov    0x9c8(%rdi),%rdx
 1f7d5dc:	mov    0x69250(%rbp),%r8d
 1f7d5e3:	lea    0x2c(%rbp),%r11
 1f7d5e7:	lea    0x6a4d4(%rbp),%rcx
 1f7d5ee:	lea    0x79854(%rbp),%rsi
 1f7d5f5:	lea    0x73754(%rbp),%r9
 1f7d5fc:	mov    0x230(%rdi),%r10
 1f7d603:	vmovdqu 0x240(%rdi),%xmm3
 1f7d60b:	vmovq  0x258(%rdi),%xmm2
 1f7d613:	mov    %r11,0x1f0(%rdi)
 1f7d61a:	mov    %rax,0x1f8(%rdi)
 1f7d621:	mov    %rcx,0x200(%rdi)
 1f7d628:	mov    %rdx,0x208(%rdi)
 1f7d62f:	mov    $0x1,%edx
 1f7d634:	vmovdqu %ymm0,0x210(%rdi)
 1f7d63c:	mov    %rsi,0x230(%rdi)
 1f7d643:	mov    %r9,0x240(%rdi)
 1f7d64a:	mov    %r8d,0x258(%rdi)
 1f7d651:	vmovups %zmm1,0x850(%rsp)
 1f7d65c:	mov    %r10,0x658(%rsp)
 1f7d664:	vmovdqa %xmm3,0x820(%rsp)
 1f7d66d:	vmovdqa %xmm2,0x810(%rsp)
 1f7d676:	mov    %r11,0xb8(%rsp)
 1f7d67e:	xor    %esi,%esi
 1f7d680:	mov    %rdi,(%rsp)
 1f7d684:	vmovups 0x9d0(%rdi),%zmm0
 1f7d68e:	vmovups 0x268(%rdi),%zmm1
 1f7d698:	vmovups %zmm0,0x268(%rdi)
 1f7d6a2:	vmovups %zmm1,0x9d0(%rdi)
 1f7d6ac:	vmovdqu 0xa10(%rdi),%xmm0
 1f7d6b4:	vmovdqu 0x2a8(%rdi),%xmm1
 1f7d6bc:	vmovdqu %xmm0,0x2a8(%rdi)
 1f7d6c4:	vmovdqu %xmm1,0xa10(%rdi)
 1f7d6cc:	mov    0xa20(%rdi),%rcx
 1f7d6d3:	mov    0x2b8(%rdi),%rax
 1f7d6da:	mov    %rcx,0x2b8(%rdi)
 1f7d6e1:	lea    0xa28(%rdi),%rcx
 1f7d6e8:	mov    %rax,0xa20(%rdi)
 1f7d6ef:	movl   $0x0,0xa28(%rdi)
 1f7d6f9:	mov    %r15d,0xa2c(%rdi)
 1f7d700:	mov    %rcx,0x248(%rdi)
 1f7d707:	movl   $0x0,0x25c(%rdi)
 1f7d711:	vzeroupper
 1f7d714:	call   1f7baf0 <node_facts_given>
 1f7d719:	mov    (%rsp),%rax
 1f7d71d:	mov    (%rsp),%rdi
 1f7d721:	xor    %esi,%esi
 1f7d723:	xor    %edx,%edx
 1f7d725:	xor    %ecx,%ecx
 1f7d727:	mov    0xe0(%rax),%rbx
 1f7d72e:	call   1f7bd00 <node_facts_window>
 1f7d733:	mov    (%rsp),%rax
 1f7d737:	mov    (%rsp),%rdi
 1f7d73b:	xor    %esi,%esi
 1f7d73d:	mov    0xe0(%rax),%rax
 1f7d744:	sub    %rbx,%rax
 1f7d747:	add    %rax,0xa30(%r14)
 1f7d74e:	call   1f7c950 <node_facts_lists_same>
 1f7d753:	mov    (%rsp),%rdi
 1f7d757:	test   %al,%al
 1f7d759:	jne    1f7d7ad <node_facts_window_run+0x3dd>
 1f7d75b:	incq   0xa00(%r14)
 1f7d762:	mov    0x940(%rdi),%rax
 1f7d769:	mov    0x11e0(%rax),%ecx
 1f7d76f:	cmp    $0xf,%rcx
 1f7d773:	ja     1f7d7ad <node_facts_window_run+0x3dd>
 1f7d775:	mov    0x422c(%rbp),%edx
 1f7d77b:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7d782:	mov    0x1f0(%rdi),%rcx
 1f7d789:	mov    0x11e0(%rax),%edx
 1f7d78f:	movzbl (%rcx),%ecx
 1f7d792:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7d799:	mov    0x11e0(%rax),%ecx
 1f7d79f:	movb   $0x2,0x11d0(%rax,%rcx,1)
 1f7d7a7:	incl   0x11e0(%rax)
 1f7d7ad:	mov    %r15,0xc0(%rsp)
 1f7d7b5:	mov    %rbp,0x18(%rsp)
 1f7d7ba:	test   %r15d,%r15d
 1f7d7bd:	je     1f7da75 <node_facts_window_run+0x6a5>
 1f7d7c3:	mov    $0x1a,%r15d
 1f7d7c9:	mov    $0xcc,%ebp
 1f7d7ce:	mov    $0x102,%r12d
 1f7d7d4:	mov    $0x8c,%r13d
 1f7d7da:	xor    %ebx,%ebx
 1f7d7dc:	jmp    1f7d7f5 <node_facts_window_run+0x425>
 1f7d7de:	xchg   %ax,%ax
 1f7d7e0:	inc    %rbx
 1f7d7e3:	add    $0x40,%r15
 1f7d7e7:	cmp    %rbx,0xc0(%rsp)
 1f7d7ef:	je     1f7d9bf <node_facts_window_run+0x5ef>
 1f7d7f5:	mov    0x1f8(%rdi),%rax
 1f7d7fc:	movzbl (%rax,%rbx,1),%eax
 1f7d800:	cmp    $0x7,%eax
 1f7d803:	ja     1f7d7e0 <node_facts_window_run+0x410>
 1f7d805:	bt     %eax,%ebp
 1f7d808:	jae    1f7d7e0 <node_facts_window_run+0x410>
 1f7d80a:	mov    %eax,%ecx
 1f7d80c:	mov    0x2c0(%rdi),%rsi
 1f7d813:	and    $0xfe,%cl
 1f7d816:	cmp    $0x2,%cl
 1f7d819:	sete   %cl
 1f7d81c:	cmp    $0x7,%eax
 1f7d81f:	sete   %dl
 1f7d822:	or     %cl,%dl
 1f7d824:	movzbl -0x1(%rsi,%r15,1),%ecx
 1f7d82a:	movzbl %dl,%edx
 1f7d82d:	add    %rdx,0x9f0(%r14)
 1f7d834:	cmp    $0x7,%eax
 1f7d837:	ja     1f7d972 <node_facts_window_run+0x5a2>
 1f7d83d:	bt     %eax,%r13d
 1f7d841:	mov    $0x0,%edx
 1f7d846:	jae    1f7d854 <node_facts_window_run+0x484>
 1f7d848:	lea    -0x1(%rcx),%esi
 1f7d84b:	xor    %edx,%edx
 1f7d84d:	cmp    $0x2,%sil
 1f7d851:	setb   %dl
 1f7d854:	add    %rdx,0x9f8(%r14)
 1f7d85b:	xor    %edx,%edx
 1f7d85d:	cmp    $0x7,%eax
 1f7d860:	ja     1f7d876 <node_facts_window_run+0x4a6>
 1f7d862:	bt     %eax,%r13d
 1f7d866:	jae    1f7d876 <node_facts_window_run+0x4a6>
 1f7d868:	mov    0x1f0(%rdi),%rax
 1f7d86f:	cmpb   $0x22,(%rax,%rbx,1)
 1f7d873:	sete   %dl
 1f7d876:	dec    %cl
 1f7d878:	vmovd  %edx,%xmm0
 1f7d87c:	cmp    $0x2,%cl
 1f7d87f:	setb   %al
 1f7d882:	and    %dl,%al
 1f7d884:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f7d88a:	vpmovzxbq %xmm0,%xmm0
 1f7d88f:	vptestmq -0x19af361(%rip){1to2},%xmm0,%k0        # 5ce538 <.LCPI3_1>
 1f7d899:	vmovdqu 0xa10(%r14),%xmm0
 1f7d8a2:	vpmovm2q %k0,%xmm1
 1f7d8a8:	vpsubq %xmm1,%xmm0,%xmm0
 1f7d8ac:	vmovdqu %xmm0,0xa10(%r14)
 1f7d8b5:	cmp    $0x1,%al
 1f7d8b7:	jne    1f7d8f0 <node_facts_window_run+0x520>
 1f7d8b9:	mov    0x2c0(%rdi),%rax
 1f7d8c0:	movzwl (%rax,%r15,1),%eax
 1f7d8c5:	bt     $0x1,%eax
 1f7d8c9:	adcq   $0x0,0xa20(%r14)
 1f7d8d1:	mov    0x2c0(%rdi),%rax
 1f7d8d8:	movzwl (%rax,%r15,1),%eax
 1f7d8dd:	bextr  %r12d,%eax,%eax
 1f7d8e2:	jmp    1f7d8f2 <node_facts_window_run+0x522>
 1f7d8e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d8f0:	xor    %eax,%eax
 1f7d8f2:	add    %rax,0xa28(%r14)
 1f7d8f9:	xor    %esi,%esi
 1f7d8fb:	mov    %ebx,%edx
 1f7d8fd:	xor    %ecx,%ecx
 1f7d8ff:	call   1f7cf70 <node_facts_same>
 1f7d904:	mov    (%rsp),%rdi
 1f7d908:	test   %al,%al
 1f7d90a:	jne    1f7d7e0 <node_facts_window_run+0x410>
 1f7d910:	incq   0xa00(%r14)
 1f7d917:	mov    0x940(%rdi),%rax
 1f7d91e:	mov    0x11e0(%rax),%ecx
 1f7d924:	cmp    $0xf,%rcx
 1f7d928:	ja     1f7d7e0 <node_facts_window_run+0x410>
 1f7d92e:	mov    0x18(%rsp),%rdx
 1f7d933:	mov    0x422c(%rdx,%rbx,4),%edx
 1f7d93a:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7d941:	mov    0x1f0(%rdi),%rcx
 1f7d948:	mov    0x11e0(%rax),%edx
 1f7d94e:	movzbl (%rcx,%rbx,1),%ecx
 1f7d952:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7d959:	mov    0x11e0(%rax),%ecx
 1f7d95f:	movb   $0x5,0x11d0(%rax,%rcx,1)
 1f7d967:	incl   0x11e0(%rax)
 1f7d96d:	jmp    1f7d7e0 <node_facts_window_run+0x410>
 1f7d972:	xor    %edx,%edx
 1f7d974:	add    %rdx,0x9f8(%r14)
 1f7d97b:	xor    %edx,%edx
 1f7d97d:	cmp    $0x7,%eax
 1f7d980:	jbe    1f7d862 <node_facts_window_run+0x492>
 1f7d986:	jmp    1f7d876 <node_facts_window_run+0x4a6>
 1f7d98b:	nopl   0x0(%rax,%rax,1)
 1f7d990:	movzbl 0x69454(%rbp,%rcx,1),%edx
 1f7d998:	mov    0x9c0(%rdi),%rsi
 1f7d99f:	mov    %dl,(%rsi,%rcx,1)
 1f7d9a2:	inc    %rcx
 1f7d9a5:	dec    %rax
 1f7d9a8:	je     1f7d5b6 <node_facts_window_run+0x1e6>
 1f7d9ae:	mov    0x9b8(%rdi),%rdx
 1f7d9b5:	cmpb   $0x0,(%rdx,%rcx,1)
 1f7d9b9:	jne    1f7d990 <node_facts_window_run+0x5c0>
 1f7d9bb:	xor    %edx,%edx
 1f7d9bd:	jmp    1f7d998 <node_facts_window_run+0x5c8>
 1f7d9bf:	mov    $0x3,%edx
 1f7d9c4:	xor    %esi,%esi
 1f7d9c6:	xor    %ebx,%ebx
 1f7d9c8:	call   1f7baf0 <node_facts_given>
 1f7d9cd:	mov    (%rsp),%rdi
 1f7d9d1:	xor    %esi,%esi
 1f7d9d3:	xor    %edx,%edx
 1f7d9d5:	xor    %ecx,%ecx
 1f7d9d7:	call   1f7bd00 <node_facts_window>
 1f7d9dc:	mov    (%rsp),%rdi
 1f7d9e0:	mov    0xc0(%rsp),%r15
 1f7d9e8:	mov    0x18(%rsp),%rbp
 1f7d9ed:	jmp    1f7d9fc <node_facts_window_run+0x62c>
 1f7d9ef:	nop
 1f7d9f0:	inc    %rbx
 1f7d9f3:	cmp    %rbx,%r15
 1f7d9f6:	je     1f7da94 <node_facts_window_run+0x6c4>
 1f7d9fc:	mov    0x1f8(%rdi),%rax
 1f7da03:	testb  $0x2,(%rax,%rbx,1)
 1f7da07:	je     1f7d9f0 <node_facts_window_run+0x620>
 1f7da09:	xor    %esi,%esi
 1f7da0b:	mov    %ebx,%edx
 1f7da0d:	xor    %ecx,%ecx
 1f7da0f:	call   1f7cf70 <node_facts_same>
 1f7da14:	mov    (%rsp),%rdi
 1f7da18:	test   %al,%al
 1f7da1a:	jne    1f7d9f0 <node_facts_window_run+0x620>
 1f7da1c:	incq   0xa00(%r14)
 1f7da23:	mov    0x940(%rdi),%rax
 1f7da2a:	mov    0x11e0(%rax),%ecx
 1f7da30:	cmp    $0xf,%rcx
 1f7da34:	ja     1f7d9f0 <node_facts_window_run+0x620>
 1f7da36:	mov    0x422c(%rbp,%rbx,4),%edx
 1f7da3d:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7da44:	mov    0x1f0(%rdi),%rcx
 1f7da4b:	mov    0x11e0(%rax),%edx
 1f7da51:	movzbl (%rcx,%rbx,1),%ecx
 1f7da55:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7da5c:	mov    0x11e0(%rax),%ecx
 1f7da62:	movb   $0x1,0x11d0(%rax,%rcx,1)
 1f7da6a:	incl   0x11e0(%rax)
 1f7da70:	jmp    1f7d9f0 <node_facts_window_run+0x620>
 1f7da75:	mov    $0x3,%edx
 1f7da7a:	xor    %esi,%esi
 1f7da7c:	call   1f7baf0 <node_facts_given>
 1f7da81:	mov    (%rsp),%rdi
 1f7da85:	xor    %esi,%esi
 1f7da87:	xor    %edx,%edx
 1f7da89:	xor    %ecx,%ecx
 1f7da8b:	call   1f7bd00 <node_facts_window>
 1f7da90:	mov    (%rsp),%rdi
 1f7da94:	xor    %esi,%esi
 1f7da96:	xor    %edx,%edx
 1f7da98:	call   1f7baf0 <node_facts_given>
 1f7da9d:	mov    (%rsp),%rax
 1f7daa1:	xor    %esi,%esi
 1f7daa3:	xor    %ecx,%ecx
 1f7daa5:	mov    0xd0(%rax),%r15
 1f7daac:	rdtsc
 1f7daae:	mov    (%rsp),%rdi
 1f7dab2:	mov    %rdx,%rbx
 1f7dab5:	shl    $0x20,%rbx
 1f7dab9:	xor    %edx,%edx
 1f7dabb:	or     %rax,%rbx
 1f7dabe:	call   1f7bd00 <node_facts_window>
 1f7dac3:	mov    (%rsp),%r11
 1f7dac7:	rdtsc
 1f7dac9:	shl    $0x20,%rdx
 1f7dacd:	or     %rax,%rdx
 1f7dad0:	sub    %rbx,%rdx
 1f7dad3:	add    %rdx,0xa08(%r14)
 1f7dada:	mov    0xd0(%r11),%rax
 1f7dae1:	sub    %r15,%rax
 1f7dae4:	mov    0xc0(%rsp),%r15
 1f7daec:	add    %rax,0xa38(%r14)
 1f7daf3:	mov    0x950(%r11),%rdi
 1f7dafa:	test   %rdi,%rdi
 1f7dafd:	je     1f84d06 <node_facts_window_run+0x7936>
 1f7db03:	mov    0xb68(%rdi),%rax
 1f7db0a:	mov    0xad0(%rdi),%r9
 1f7db11:	lea    0x757d4(%rbp),%r12
 1f7db18:	mov    %rax,0x50(%rsp)
 1f7db1d:	mov    (%r11),%rax
 1f7db20:	mov    %rax,0xb0(%rsp)
 1f7db28:	mov    0x948(%r11),%rax
 1f7db2f:	mov    %rax,0xa8(%rsp)
 1f7db37:	mov    0x8(%rax),%rax
 1f7db3b:	mov    0x78(%rax),%eax
 1f7db3e:	mov    %eax,0xa0(%rsp)
 1f7db45:	movzbl 0xb90(%rdi),%eax
 1f7db4c:	mov    %al,0x68(%rsp)
 1f7db50:	rdtsc
 1f7db52:	mov    0x8(%rbp),%esi
 1f7db55:	mov    0x2c0(%r11),%r8
 1f7db5c:	mov    %rax,0xf0(%rsp)
 1f7db64:	lea    0x3f(%rsi),%eax
 1f7db67:	mov    %rdx,0xe8(%rsp)
 1f7db6f:	mov    %r9,0x48(%rsp)
 1f7db74:	mov    %rdi,0x8(%rsp)
 1f7db79:	mov    %r12,0x38(%rsp)
 1f7db7e:	mov    %rsi,0x28(%rsp)
 1f7db83:	mov    %r8,0x20(%rsp)
 1f7db88:	and    $0xffffffc0,%eax
 1f7db8b:	cmpq   $0x0,0xc20(%r11)
 1f7db93:	je     1f7e860 <node_facts_window_run+0x1490>
 1f7db99:	cmpb   $0x1,0xd58(%r11)
 1f7dba1:	jne    1f7f2b0 <node_facts_window_run+0x1ee0>
 1f7dba7:	test   %eax,%eax
 1f7dba9:	je     1f807b5 <node_facts_window_run+0x33e5>
 1f7dbaf:	vpbroadcastd -0x19acc4d(%rip),%zmm14        # 5d0f6c <.LCPI3_5>
 1f7dbb9:	vpbroadcastb -0x1ac6e82(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7dbc2:	vpbroadcastb -0x1ac6e8b(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7dbcc:	vpbroadcastd -0x19acc62(%rip),%zmm17        # 5d0f74 <.LCPI3_11>
 1f7dbd6:	vpbroadcastd -0x19acc64(%rip),%zmm18        # 5d0f7c <.LCPI3_13>
 1f7dbe0:	mov    (%r11),%rcx
 1f7dbe3:	lea    0x69454(%rbp),%r10
 1f7dbea:	lea    0x422c(%rbp),%rdx
 1f7dbf1:	mov    %eax,%r15d
 1f7dbf4:	xor    %ebx,%ebx
 1f7dbf6:	mov    %rcx,0x78(%rsp)
 1f7dbfb:	mov    %r10,0x98(%rsp)
 1f7dc03:	mov    %rdx,0x80(%rsp)
 1f7dc0b:	movq   $0x0,0x40(%rsp)
 1f7dc14:	movq   $0x0,0x30(%rsp)
 1f7dc1d:	movq   $0x0,0x10(%rsp)
 1f7dc26:	mov    %r15,0x90(%rsp)
 1f7dc2e:	jmp    1f7dd06 <node_facts_window_run+0x936>
 1f7dc33:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7dc40:	vpxor  %xmm1,%xmm1,%xmm1
 1f7dc44:	vpxor  %xmm0,%xmm0,%xmm0
 1f7dc48:	vpxor  %xmm5,%xmm5,%xmm5
 1f7dc4c:	vpxor  %xmm4,%xmm4,%xmm4
 1f7dc50:	vpxor  %xmm3,%xmm3,%xmm3
 1f7dc54:	vpxor  %xmm7,%xmm7,%xmm7
 1f7dc58:	vpxor  %xmm8,%xmm8,%xmm8
 1f7dc5d:	vpxor  %xmm9,%xmm9,%xmm9
 1f7dc62:	vpxor  %xmm2,%xmm2,%xmm2
 1f7dc66:	vpxord %xmm20,%xmm20,%xmm20
 1f7dc6c:	mov    0xb10(%rdi),%rax
 1f7dc73:	vmovdqu64 %xmm20,(%rax,%rbx,1)
 1f7dc7a:	mov    0xb18(%rdi),%rax
 1f7dc81:	vmovdqu %xmm2,(%rax,%rbx,1)
 1f7dc86:	mov    0xb88(%r11),%rax
 1f7dc8d:	vmovdqu %xmm9,(%rax,%rbx,1)
 1f7dc92:	mov    0xb90(%r11),%rax
 1f7dc99:	vmovdqu %xmm8,(%rax,%rbx,1)
 1f7dc9e:	mov    0xb98(%r11),%rax
 1f7dca5:	vmovdqu %xmm7,(%rax,%rbx,1)
 1f7dcaa:	mov    0xba0(%r11),%rax
 1f7dcb1:	vmovdqu %xmm3,(%rax,%rbx,1)
 1f7dcb6:	mov    0xba8(%r11),%rax
 1f7dcbd:	vmovdqu %xmm4,(%rax,%rbx,1)
 1f7dcc2:	mov    0xc28(%r11),%rax
 1f7dcc9:	vmovdqu64 %zmm5,(%rax,%rbx,4)
 1f7dcd0:	mov    0xcd8(%r11),%rax
 1f7dcd7:	vmovdqu64 %zmm0,(%rax,%rbx,8)
 1f7dcde:	mov    0xcd8(%r11),%rax
 1f7dce5:	vmovdqu64 %zmm1,0x40(%rax,%rbx,8)
 1f7dced:	mov    0xd60(%r11),%rax
 1f7dcf4:	vmovdqu %xmm6,(%rax,%rbx,1)
 1f7dcf9:	add    $0x10,%rbx
 1f7dcfd:	cmp    %r15,%rbx
 1f7dd00:	jae    1f807d0 <node_facts_window_run+0x3400>
 1f7dd06:	vpxor  %xmm6,%xmm6,%xmm6
 1f7dd0a:	cmp    %rsi,%rbx
 1f7dd0d:	jae    1f7dc40 <node_facts_window_run+0x870>
 1f7dd13:	mov    %esi,%eax
 1f7dd15:	sub    %ebx,%eax
 1f7dd17:	mov    $0x10,%ecx
 1f7dd1c:	mov    $0xffffffff,%edx
 1f7dd21:	mov    %rbx,%rbp
 1f7dd24:	vpxor  %xmm12,%xmm12,%xmm12
 1f7dd29:	cmp    $0x10,%eax
 1f7dd2c:	cmovae %ecx,%eax
 1f7dd2f:	mov    0x9b8(%r11),%rcx
 1f7dd36:	shl    $0x6,%rbp
 1f7dd3a:	shlx   %eax,%edx,%eax
 1f7dd3f:	vmovdqu (%r8,%rbp,1),%ymm4
 1f7dd45:	vmovdqu64 0x40(%r8,%rbp,1),%ymm26
 1f7dd4d:	vmovdqu64 0x80(%r8,%rbp,1),%ymm27
 1f7dd55:	vmovdqu64 0xc0(%r8,%rbp,1),%ymm28
 1f7dd5d:	vmovdqu 0x100(%r8,%rbp,1),%ymm5
 1f7dd67:	vmovdqu 0x140(%r8,%rbp,1),%ymm6
 1f7dd71:	vmovdqu64 0x180(%r8,%rbp,1),%ymm24
 1f7dd79:	vmovdqu64 0x1c0(%r8,%rbp,1),%ymm25
 1f7dd81:	vmovdqu 0x200(%r8,%rbp,1),%ymm7
 1f7dd8b:	vmovdqu 0x240(%r8,%rbp,1),%ymm13
 1f7dd95:	vmovdqu64 0x280(%r8,%rbp,1),%ymm22
 1f7dd9d:	vmovdqu64 0x2c0(%r8,%rbp,1),%ymm23
 1f7dda5:	vmovdqu 0x300(%r8,%rbp,1),%ymm11
 1f7ddaf:	vmovdqu64 0x340(%r8,%rbp,1),%ymm19
 1f7ddb7:	vmovdqu64 0x380(%r8,%rbp,1),%ymm20
 1f7ddbf:	vmovdqu64 0x3c0(%r8,%rbp,1),%ymm21
 1f7ddc7:	not    %eax
 1f7ddc9:	kmovd  %eax,%k1
 1f7ddcd:	mov    0xb48(%rdi),%rax
 1f7ddd4:	vmovdqu8 (%rcx,%rbx,1),%xmm0{%k1}{z}
 1f7dddb:	mov    0x98(%rsp),%rcx
 1f7dde3:	vmovdqu8 (%rcx,%rbx,1),%xmm10{%k1}{z}
 1f7ddea:	vptestmb %xmm0,%xmm0,%k6
 1f7ddf0:	vpcmpeqb -0x19b60ea(%rip),%xmm10,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7ddfa:	vmovdqu32 (%r12,%rbx,4),%zmm0{%k7}{z}
 1f7de01:	kmovq  %k7,%k1
 1f7de06:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7de0d:	vptestnmd %zmm17,%zmm12,%k0
 1f7de13:	ktestw %k0,%k7
 1f7de17:	jne    1f7e554 <node_facts_window_run+0x1184>
 1f7de1d:	vpmovsxbd -0x19ace76(%rip),%xmm3        # 5d0fb0 <.LCPI3_75>
 1f7de26:	vmovdqa64 -0x1ac76f0(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7de30:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7de37:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7de3e:	vptestmd -0x19aced0(%rip){1to16},%zmm12,%k0        # 5d0f78 <.LCPI3_12>
 1f7de48:	vmovdqa64 %zmm0,%zmm2
 1f7de4e:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7de54:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7de5a:	vmovdqa64 %zmm3,%zmm9
 1f7de60:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7de66:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7de6c:	kmovd  %k0,%r13d
 1f7de70:	vptestmd %zmm18,%zmm12,%k0
 1f7de76:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7de7c:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7de83:	vmovdqu64 %zmm1,0x1e0(%rsp)
 1f7de8e:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7de95:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7de99:	vmovdqa64 %zmm1,%zmm4
 1f7de9f:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7dea5:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7deab:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7deb1:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7deb7:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7debe:	vmovdqu %ymm3,0x160(%rsp)
 1f7dec7:	vinserti64x4 $0x1,%ymm13,%zmm7,%zmm3
 1f7dece:	vpunpcklqdq %ymm13,%ymm7,%ymm7
 1f7ded3:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm13
 1f7deda:	vmovdqa64 %zmm3,%zmm6
 1f7dee0:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7dee6:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7deec:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7def2:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7def8:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7defe:	vmovdqa64 %zmm13,%zmm7
 1f7df04:	vmovdqu64 %zmm5,0x290(%rsp)
 1f7df0f:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7df16:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7df1c:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7df23:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7df2a:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7df30:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7df37:	vpermt2d %zmm5,%zmm9,%zmm13
 1f7df3d:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7df43:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7df49:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7df50:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7df57:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7df5e:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7df65:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm21{%k6}{z}
 1f7df6c:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7df73:	vpsrld $0x19,%zmm19,%zmm0
 1f7df7a:	vpandd -0x19ad01c(%rip){1to16},%zmm0,%zmm0        # 5d0f68 <.LCPI3_4>
 1f7df84:	vpsrld $0x18,%zmm19,%zmm1
 1f7df8b:	vpsrld $0x1a,%zmm19,%zmm7
 1f7df92:	vpternlogd $0xec,%zmm14,%zmm0,%zmm1
 1f7df99:	vpandd -0x19acfef(%rip){1to16},%zmm19,%zmm0        # 5d0fb4 <.LCPI3_76>
 1f7dfa3:	vpmovdb %zmm1,%xmm20
 1f7dfa9:	vpsrld $0xc,%zmm21,%zmm1
 1f7dfb0:	vpmovdb %zmm1,%xmm24
 1f7dfb6:	vpcmpeqd -0x19ad050(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f70 <.LCPI3_7>
 1f7dfc0:	vporq  %xmm15,%xmm20,%xmm0
 1f7dfc6:	vmovdqu8 %xmm0,%xmm20{%k1}
 1f7dfcc:	vpcmpeqb %xmm15,%xmm10,%k1{%k6}
 1f7dfd2:	vpternlogq $0xf8,%xmm16,%xmm24,%xmm20
 1f7dfd9:	kmovd  %k1,%eax
 1f7dfdd:	kmovw  %k1,0x120(%rsp)
 1f7dfe6:	korw   %k0,%k1,%k1
 1f7dfea:	kmovw  %k1,0x1a0(%rsp)
 1f7dff3:	test   %ax,%ax
 1f7dff6:	je     1f7e1b1 <node_facts_window_run+0xde1>
 1f7dffc:	vmovdqu64 %zmm4,0x660(%rsp)
 1f7e007:	vmovdqu %ymm5,0x5f0(%rsp)
 1f7e010:	vmovdqu64 %zmm7,0x530(%rsp)
 1f7e01b:	vmovdqa64 %xmm24,0x570(%rsp)
 1f7e023:	vmovdqu64 %zmm23,0x5b0(%rsp)
 1f7e02e:	vmovdqu64 %zmm22,0x450(%rsp)
 1f7e039:	vmovdqu64 %zmm19,0x2d0(%rsp)
 1f7e044:	vmovdqu64 %zmm13,0x490(%rsp)
 1f7e04f:	vmovdqu64 %zmm21,0x3d0(%rsp)
 1f7e05a:	vmovdqu64 %zmm12,0x4d0(%rsp)
 1f7e065:	vmovdqa64 %xmm20,0x220(%rsp)
 1f7e06d:	kmovw  %k7,0x350(%rsp)
 1f7e076:	mov    %rbp,0x310(%rsp)
 1f7e07e:	kmovd  %k6,0x390(%rsp)
 1f7e088:	movzwl %ax,%r14d
 1f7e08c:	movzwl %r13w,%r13d
 1f7e090:	xor    %ebp,%ebp
 1f7e092:	mov    0x80(%rsp),%rax
 1f7e09a:	lea    (%rax,%rbx,4),%r15
 1f7e09e:	xchg   %ax,%ax
 1f7e0a0:	xor    %r12d,%r12d
 1f7e0a3:	tzcnt  %r14d,%r12d
 1f7e0a8:	xor    %edx,%edx
 1f7e0aa:	mov    (%r15,%r12,4),%esi
 1f7e0ae:	vzeroupper
 1f7e0b1:	call   1f93910 <node_tests_window_line>
 1f7e0b6:	mov    0x8(%rsp),%rdi
 1f7e0bb:	mov    $0x1,%ecx
 1f7e0c0:	test   $0x2,%al
 1f7e0c2:	shlx   %r12d,%ecx,%eax
 1f7e0c7:	cmove  %ebp,%eax
 1f7e0ca:	or     %eax,%r13d
 1f7e0cd:	blsr   %r14d,%r14d
 1f7e0d2:	jne    1f7e0a0 <node_facts_window_run+0xcd0>
 1f7e0d4:	vpbroadcastd -0x19ad172(%rip),%zmm14        # 5d0f6c <.LCPI3_5>
 1f7e0de:	vpbroadcastb -0x1ac73a7(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e0e7:	vpbroadcastb -0x1ac73b0(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e0f1:	vpbroadcastd -0x19ad187(%rip),%zmm17        # 5d0f74 <.LCPI3_11>
 1f7e0fb:	vpbroadcastd -0x19ad189(%rip),%zmm18        # 5d0f7c <.LCPI3_13>
 1f7e105:	vmovdqa64 0x220(%rsp),%xmm20
 1f7e10d:	vmovdqu64 0x4d0(%rsp),%zmm12
 1f7e118:	vmovdqu64 0x3d0(%rsp),%zmm21
 1f7e123:	vmovdqu64 0x490(%rsp),%zmm13
 1f7e12e:	vmovdqu64 0x2d0(%rsp),%zmm19
 1f7e139:	vmovdqu64 0x450(%rsp),%zmm22
 1f7e144:	vmovdqu64 0x5b0(%rsp),%zmm23
 1f7e14f:	vmovdqa64 0x570(%rsp),%xmm24
 1f7e157:	vmovdqu64 0x530(%rsp),%zmm7
 1f7e162:	vmovdqu 0x5f0(%rsp),%ymm5
 1f7e16b:	vmovdqu64 0x660(%rsp),%zmm4
 1f7e176:	mov    (%rsp),%r11
 1f7e17a:	mov    0x48(%rsp),%r9
 1f7e17f:	mov    0x38(%rsp),%r12
 1f7e184:	mov    0x28(%rsp),%rsi
 1f7e189:	mov    0x20(%rsp),%r8
 1f7e18e:	mov    0x90(%rsp),%r15
 1f7e196:	kmovd  0x390(%rsp),%k6
 1f7e1a0:	mov    0x310(%rsp),%rbp
 1f7e1a8:	kmovw  0x350(%rsp),%k7
 1f7e1b1:	vpsrld $0x2,%zmm21,%zmm0
 1f7e1b8:	vpandd -0x19ad242(%rip){1to16},%zmm0,%zmm2        # 5d0f80 <.LCPI3_14>
 1f7e1c2:	vpbroadcastd -0x19ad248(%rip),%zmm0        # 5d0f84 <.LCPI3_15>
 1f7e1cc:	vptestmd -0x19ad24e(%rip){1to16},%zmm21,%k3        # 5d0f88 <.LCPI3_16>
 1f7e1d6:	vmovdqu64 0x290(%rsp),%zmm1
 1f7e1e1:	vptestnmd %zmm4,%zmm4,%k1
 1f7e1e7:	vpbroadcastd -0x19ad25d(%rip),%zmm6        # 5d0f94 <.LCPI3_21>
 1f7e1f1:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7e1f8:	kmovd  %r13d,%k4
 1f7e1fd:	vpsrld $0x10,%zmm21,%zmm10
 1f7e204:	vpbroadcastb -0x1ac74cb(%rip),%xmm8        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7e20d:	vpbroadcastb -0x1ac74d3(%rip),%xmm9        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7e216:	kmovw  %k1,%eax
 1f7e21a:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7e220:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7e227:	vmovdqu64 0x1e0(%rsp),%zmm0
 1f7e232:	korw   %k1,%k3,%k3
 1f7e236:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7e23d:	vpandd -0x19ad28f(%rip){1to16},%zmm19,%zmm5        # 5d0fb8 <.LCPI3_79>
 1f7e247:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7e24d:	vpbroadcastb -0x1ac7512(%rip),%xmm7        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7e256:	vinserti64x4 $0x1,0x160(%rsp),%zmm0,%zmm0
 1f7e25f:	kmovw  %k0,%ecx
 1f7e263:	korw   %k2,%k3,%k2
 1f7e267:	vpaddd -0x19ad2e1(%rip){1to16},%zmm5,%zmm5        # 5d0f90 <.LCPI3_20>
 1f7e271:	andn   %ecx,%eax,%eax
 1f7e276:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7e27c:	kmovd  %eax,%k3
 1f7e280:	shr    $0x8,%eax
 1f7e283:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7e289:	kmovd  %eax,%k3
 1f7e28d:	vmovdqu8 %xmm15,%xmm4{%k2}{z}
 1f7e293:	vpcmpltud %zmm6,%zmm5,%k2
 1f7e29a:	vpslld $0x1f,%zmm5,%zmm5
 1f7e2a1:	vpxor  %xmm6,%xmm6,%xmm6
 1f7e2a5:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7e2ab:	vptestmd -0x19ad329(%rip){1to16},%zmm23,%k3        # 5d0f8c <.LCPI3_17>
 1f7e2b5:	vpandd %zmm18,%zmm23,%zmm3
 1f7e2bb:	vptestnmd %zmm3,%zmm3,%k0
 1f7e2c1:	kandd  %k6,%k0,%k0
 1f7e2c6:	korw   %k3,%k4,%k3
 1f7e2ca:	kandd  %k2,%k0,%k4
 1f7e2cf:	vpcmpeqd %zmm17,%zmm2,%k2{%k4}
 1f7e2d5:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7e2db:	vmovdqu8 -0x19b65a5(%rip),%xmm2{%k4}        # 5c7d40 <.LCPI3_25>
 1f7e2e5:	knotw  %k2,%k0
 1f7e2e9:	kandd  %k0,%k4,%k5
 1f7e2ee:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7e2f4:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7e2fb:	vpaddd %zmm5,%zmm10,%zmm11
 1f7e301:	vpbroadcastb -0x1ac75c5(%rip),%xmm5        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7e30a:	vmovdqu8 -0x19b65c4(%rip),%xmm2{%k4}        # 5c7d50 <.LCPI3_26>
 1f7e314:	vptestnmd %zmm11,%zmm11,%k4
 1f7e31a:	vpblendmb -0x19b65b4(%rip),%xmm5,%xmm5{%k4}        # 5c7d70 <.LCPI3_28>
 1f7e324:	vpcmpnleud -0x19ad397(%rip){1to16},%zmm11,%k4        # 5d0f98 <.LCPI3_22>
 1f7e32f:	cmpb   $0x0,0xb90(%rdi)
 1f7e336:	vmovdqu8 -0x19b65c0(%rip),%xmm5{%k4}        # 5c7d80 <.LCPI3_29>
 1f7e340:	vpcmpnleud -0x19ad3af(%rip){1to16},%zmm11,%k4        # 5d0f9c <.LCPI3_23>
 1f7e34b:	vmovdqu8 -0x19b65c5(%rip),%xmm5{%k4}        # 5c7d90 <.LCPI3_30>
 1f7e355:	vptestmd %zmm3,%zmm3,%k4
 1f7e35b:	vpor   %xmm4,%xmm8,%xmm3
 1f7e35f:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7e365:	kmovw  0x1a0(%rsp),%k4
 1f7e36e:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7e374:	vpor   %xmm2,%xmm4,%xmm2
 1f7e378:	vpord  -0x19ad3c6(%rip){1to4},%xmm2,%xmm3        # 5d0fbc <.LCPI3_82>
 1f7e382:	vpbroadcastb -0x1ac7645(%rip),%xmm5        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7e38b:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7e391:	vpor   %xmm5,%xmm2,%xmm3
 1f7e395:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7e39b:	vpmovdb %zmm21,%xmm3
 1f7e3a1:	kmovw  0x120(%rsp),%k3
 1f7e3aa:	vpor   %xmm3,%xmm9,%xmm4
 1f7e3ae:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7e3b4:	vptestmd -0x19ad41e(%rip){1to16},%zmm12,%k3{%k7}        # 5d0fa0 <.LCPI3_32>
 1f7e3be:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7e3c4:	vpor   %xmm5,%xmm4,%xmm6
 1f7e3c8:	vpsrld $0xb,%zmm23,%zmm7
 1f7e3cf:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7e3d5:	vpandd -0x19ad41f(%rip){1to4},%xmm24,%xmm4        # 5d0fc0 <.LCPI3_84>
 1f7e3df:	vptestmd -0x19ad445(%rip){1to16},%zmm23,%k1        # 5d0fa4 <.LCPI3_33>
 1f7e3e9:	vpmovdb %zmm7,%xmm7
 1f7e3ef:	vpand  %xmm7,%xmm8,%xmm7
 1f7e3f3:	vporq  %xmm16,%xmm4,%xmm5
 1f7e3f9:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7e3ff:	vpmovdb %zmm23,%xmm5
 1f7e405:	vgf2p8affineqb $0x0,-0x19afe80(%rip){1to2},%xmm5,%xmm5        # 5ce590 <.LCPI3_85>
 1f7e410:	vpternlogq $0xf8,%xmm9,%xmm5,%xmm4
 1f7e417:	vpmovdb %zmm19,%xmm9
 1f7e41d:	vpor   %xmm4,%xmm15,%xmm5
 1f7e421:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7e427:	vinserti32x4 $0x3,%xmm13,%zmm22,%zmm5{%k6}{z}
 1f7e42e:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7e435:	vpsrld $0x8,%zmm19,%zmm13
 1f7e43c:	vpsrld $0x10,%zmm19,%zmm6
 1f7e443:	vpmovdb %zmm6,%xmm7
 1f7e449:	vpmovdb %zmm13,%xmm8
 1f7e44f:	vpmovdb %zmm12,%xmm6
 1f7e455:	je     1f7e54a <node_facts_window_run+0x117a>
 1f7e45b:	vmovdqa64 -0x1ac7c65(%rip),%zmm19        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7e465:	vptestmd %zmm10,%zmm10,%k1{%k2}
 1f7e46b:	add    %r8,%rbp
 1f7e46e:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e473:	vpxor  %xmm13,%xmm13,%xmm13
 1f7e478:	vpcmpneqd -0x19ad4db(%rip){1to16},%zmm10,%k0{%k1}        # 5d0fa8 <.LCPI3_38>
 1f7e483:	vmovdqa %xmm7,%xmm10
 1f7e487:	vpternlogq $0xfe,%xmm9,%xmm3,%xmm10
 1f7e48e:	kmovq  %k1,%k2
 1f7e493:	kmovw  %k1,%eax
 1f7e497:	popcnt %eax,%ecx
 1f7e49b:	vpgatherdd 0x10(%rbp,%zmm19,1),%zmm12{%k2}
 1f7e4a3:	kmovq  %k1,%k2
 1f7e4a8:	vpcmpnleud -0x19ad507(%rip){1to16},%zmm12,%k3        # 5d0fac <.LCPI3_39>
 1f7e4b3:	vpgatherdd 0x14(%rbp,%zmm19,1),%zmm13{%k2}
 1f7e4bb:	add    %rcx,0x30(%rsp)
 1f7e4c0:	mov    0x10(%rsp),%r10
 1f7e4c5:	vpcmpeqd %zmm11,%zmm12,%k2
 1f7e4cb:	vmovdqa64 %xmm20,%xmm11
 1f7e4d1:	vpternlogq $0xfe,%xmm8,%xmm10,%xmm11
 1f7e4d8:	vptestnmd %zmm13,%zmm13,%k2{%k2}
 1f7e4de:	vptestmd %zmm13,%zmm13,%k4
 1f7e4e4:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm11
 1f7e4eb:	korw   %k4,%k3,%k3
 1f7e4ef:	kandw  %k2,%k0,%k2
 1f7e4f3:	knotw  %k0,%k0
 1f7e4f7:	kandd  %k1,%k0,%k0
 1f7e4fc:	kandw  %k0,%k3,%k0
 1f7e500:	korw   %k0,%k2,%k2
 1f7e504:	vptestnmd %zmm14,%zmm21,%k0{%k2}
 1f7e50a:	kandw  %k0,%k1,%k0
 1f7e50e:	knotd  %k6,%k1
 1f7e513:	kmovd  %k0,%ecx
 1f7e517:	vptestmb %xmm11,%xmm11,%k0{%k1}
 1f7e51d:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7e523:	andn   %eax,%ecx,%eax
 1f7e528:	popcnt %eax,%eax
 1f7e52c:	kmovw  %k0,%ecx
 1f7e530:	popcnt %ecx,%ecx
 1f7e534:	kmovw  %k1,%edx
 1f7e538:	popcnt %edx,%edx
 1f7e53c:	add    %rdx,%r10
 1f7e53f:	add    %rax,%r10
 1f7e542:	add    %rcx,%r10
 1f7e545:	mov    %r10,0x10(%rsp)
 1f7e54a:	mov    0x18(%rsp),%rbp
 1f7e54f:	jmp    1f7dc6c <node_facts_window_run+0x89c>
 1f7e554:	kandw  %k0,%k7,%k0
 1f7e558:	vmovdqa %xmm10,0x290(%rsp)
 1f7e561:	vmovdqu64 %zmm11,0x310(%rsp)
 1f7e56c:	vmovdqu64 %ymm19,0x220(%rsp)
 1f7e574:	vmovdqu64 %zmm20,0x4d0(%rsp)
 1f7e57f:	vmovdqu64 %ymm21,0x3d0(%rsp)
 1f7e58a:	vmovdqu64 %zmm7,0x490(%rsp)
 1f7e595:	vmovdqu %ymm13,0x2d0(%rsp)
 1f7e59e:	vmovdqu64 %zmm22,0x450(%rsp)
 1f7e5a9:	vmovdqu64 %ymm23,0x5b0(%rsp)
 1f7e5b4:	vmovdqu64 %zmm5,0x570(%rsp)
 1f7e5bf:	vmovdqu %ymm6,0x530(%rsp)
 1f7e5c8:	vmovdqu64 %zmm24,0x5f0(%rsp)
 1f7e5d3:	vmovdqu64 %ymm25,0x660(%rsp)
 1f7e5db:	vmovdqu64 %zmm4,0x720(%rsp)
 1f7e5e6:	vmovdqu64 %ymm26,0x430(%rsp)
 1f7e5f1:	vmovdqu64 %zmm27,0x6e0(%rsp)
 1f7e5fc:	vmovdqu64 %ymm28,0x410(%rsp)
 1f7e607:	vmovdqu64 %zmm0,0x7c0(%rsp)
 1f7e60f:	kmovd  %k6,0x390(%rsp)
 1f7e619:	kmovw  %k7,0x350(%rsp)
 1f7e622:	kmovd  %k0,%eax
 1f7e626:	movzwl %ax,%eax
 1f7e629:	jmp    1f7e7d6 <node_facts_window_run+0x1406>
 1f7e62e:	mov    0x40(%rsp),%rsi
 1f7e633:	mov    (%r12,%r13,4),%r9d
 1f7e637:	mov    0xb48(%rdi),%rdx
 1f7e63e:	shl    $0x6,%rax
 1f7e642:	mov    %r8b,0x160(%rsp)
 1f7e64a:	mov    0x20(%r11),%rcx
 1f7e64e:	cmpb   $0x1,(%rdx,%r9,1)
 1f7e653:	mov    %r9,0x1e0(%rsp)
 1f7e65b:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7e660:	adc    $0x0,%rsi
 1f7e664:	and    $0x1,%edx
 1f7e667:	mov    %rsi,0x40(%rsp)
 1f7e66c:	mov    0x80(%rsp),%r14
 1f7e674:	mov    (%r14,%r13,4),%esi
 1f7e678:	vzeroupper
 1f7e67b:	call   1f93910 <node_tests_window_line>
 1f7e680:	mov    %al,0x1a0(%rsp)
 1f7e687:	mov    (%r14,%r13,4),%esi
 1f7e68b:	mov    0x8(%rsp),%rdi
 1f7e690:	call   1f93a60 <node_tests_window_returns>
 1f7e695:	mov    0x8(%rsp),%rdi
 1f7e69a:	or     0x160(%rsp),%al
 1f7e6a1:	mov    0x1e0(%rsp),%rdx
 1f7e6a9:	vpbroadcastd -0x19ad747(%rip),%zmm14        # 5d0f6c <.LCPI3_5>
 1f7e6b3:	vpbroadcastb -0x1ac797c(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e6bc:	vpbroadcastb -0x1ac7985(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e6c6:	vpbroadcastd -0x19ad75c(%rip),%zmm17        # 5d0f74 <.LCPI3_11>
 1f7e6d0:	vpbroadcastd -0x19ad75e(%rip),%zmm18        # 5d0f7c <.LCPI3_13>
 1f7e6da:	vmovdqa 0x290(%rsp),%xmm10
 1f7e6e3:	vmovdqu64 0x310(%rsp),%zmm11
 1f7e6ee:	vmovdqu64 0x220(%rsp),%ymm19
 1f7e6f6:	vmovdqu64 0x4d0(%rsp),%zmm20
 1f7e701:	vmovdqu64 0x3d0(%rsp),%ymm21
 1f7e70c:	vmovdqu64 0x490(%rsp),%zmm7
 1f7e717:	vmovdqu 0x2d0(%rsp),%ymm13
 1f7e720:	vmovdqu64 0x450(%rsp),%zmm22
 1f7e72b:	vmovdqu64 0x5b0(%rsp),%ymm23
 1f7e736:	vmovdqu64 0x570(%rsp),%zmm5
 1f7e741:	vmovdqu 0x530(%rsp),%ymm6
 1f7e74a:	vmovdqu64 0x5f0(%rsp),%zmm24
 1f7e755:	vmovdqu64 0x660(%rsp),%ymm25
 1f7e75d:	vmovdqu64 0x720(%rsp),%zmm4
 1f7e768:	vmovdqu64 0x430(%rsp),%ymm26
 1f7e773:	vmovdqu64 0x6e0(%rsp),%zmm27
 1f7e77e:	vmovdqu64 0x410(%rsp),%ymm28
 1f7e789:	vmovdqu64 0x7c0(%rsp),%zmm0
 1f7e791:	mov    (%rsp),%r11
 1f7e795:	mov    0x48(%rsp),%r9
 1f7e79a:	mov    0x28(%rsp),%rsi
 1f7e79f:	mov    0x20(%rsp),%r8
 1f7e7a4:	kmovd  0x390(%rsp),%k6
 1f7e7ae:	kmovw  0x350(%rsp),%k7
 1f7e7b7:	or     0x1a0(%rsp),%al
 1f7e7be:	mov    0xb48(%rdi),%rcx
 1f7e7c5:	mov    %al,(%rcx,%rdx,1)
 1f7e7c8:	mov    0x120(%rsp),%eax
 1f7e7cf:	blsr   %eax,%eax
 1f7e7d4:	je     1f7e843 <node_facts_window_run+0x1473>
 1f7e7d6:	tzcnt  %eax,%r13d
 1f7e7db:	mov    %eax,0x120(%rsp)
 1f7e7e2:	mov    0x60(%r11),%edx
 1f7e7e6:	add    %rbx,%r13
 1f7e7e9:	mov    %r13,%rcx
 1f7e7ec:	shl    $0x6,%rcx
 1f7e7f0:	mov    (%r8,%rcx,1),%eax
 1f7e7f4:	mov    0xc(%r8,%rcx,1),%ecx
 1f7e7f9:	mov    $0x1,%r8b
 1f7e7fc:	shr    $0x3,%eax
 1f7e7ff:	cmp    %edx,%eax
 1f7e801:	cmovae %edx,%eax
 1f7e804:	test   %rcx,%rcx
 1f7e807:	je     1f7e62e <node_facts_window_run+0x125e>
 1f7e80d:	mov    0x78(%rsp),%rdx
 1f7e812:	mov    0x40(%rsp),%rsi
 1f7e817:	cmp    0x3b8(%rdx),%ecx
 1f7e81d:	jae    1f7e633 <node_facts_window_run+0x1263>
 1f7e823:	mov    0x78(%rsp),%rdx
 1f7e828:	mov    0x3a8(%rdx),%rdx
 1f7e82f:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7e833:	setne  %r8b
 1f7e837:	shl    $0x5,%r8b
 1f7e83b:	inc    %r8b
 1f7e83e:	jmp    1f7e633 <node_facts_window_run+0x1263>
 1f7e843:	mov    0xb48(%rdi),%rax
 1f7e84a:	kmovq  %k7,%k1
 1f7e84f:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e854:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7e85b:	jmp    1f7de1d <node_facts_window_run+0xa4d>
 1f7e860:	cmpq   $0x0,0xb40(%r11)
 1f7e868:	je     1f7ff5a <node_facts_window_run+0x2b8a>
 1f7e86e:	test   %eax,%eax
 1f7e870:	je     1f807b5 <node_facts_window_run+0x33e5>
 1f7e876:	vpbroadcastd -0x19ad914(%rip),%zmm10        # 5d0f6c <.LCPI3_5>
 1f7e880:	vpbroadcastb -0x1ac7b49(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e889:	vpbroadcastb -0x1ac7b51(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e892:	vpbroadcastd -0x19ad928(%rip),%zmm13        # 5d0f74 <.LCPI3_11>
 1f7e89c:	vpbroadcastd -0x19ad92a(%rip),%zmm14        # 5d0f7c <.LCPI3_13>
 1f7e8a6:	mov    (%r11),%rcx
 1f7e8a9:	lea    0x69454(%rbp),%r10
 1f7e8b0:	lea    0x422c(%rbp),%rdx
 1f7e8b7:	mov    %eax,%r15d
 1f7e8ba:	xor    %r14d,%r14d
 1f7e8bd:	mov    %rcx,0x5f0(%rsp)
 1f7e8c5:	mov    %r10,0x5b0(%rsp)
 1f7e8cd:	mov    %rdx,0x570(%rsp)
 1f7e8d5:	movq   $0x0,0x40(%rsp)
 1f7e8de:	movq   $0x0,0x30(%rsp)
 1f7e8e7:	movq   $0x0,0x10(%rsp)
 1f7e8f0:	mov    %r15,0x530(%rsp)
 1f7e8f8:	jmp    1f7e983 <node_facts_window_run+0x15b3>
 1f7e8fd:	nopl   (%rax)
 1f7e900:	vpxor  %xmm1,%xmm1,%xmm1
 1f7e904:	vpxor  %xmm3,%xmm3,%xmm3
 1f7e908:	vpxor  %xmm4,%xmm4,%xmm4
 1f7e90c:	vpxor  %xmm5,%xmm5,%xmm5
 1f7e910:	vpxor  %xmm0,%xmm0,%xmm0
 1f7e914:	vpxord %xmm16,%xmm16,%xmm16
 1f7e91a:	mov    0xb10(%rdi),%rax
 1f7e921:	vmovdqu64 %xmm16,(%rax,%r14,1)
 1f7e928:	mov    0xb18(%rdi),%rax
 1f7e92f:	vmovdqu %xmm0,(%rax,%r14,1)
 1f7e935:	mov    0xb88(%r11),%rax
 1f7e93c:	vmovdqu %xmm5,(%rax,%r14,1)
 1f7e942:	mov    0xb90(%r11),%rax
 1f7e949:	vmovdqu %xmm4,(%rax,%r14,1)
 1f7e94f:	mov    0xb98(%r11),%rax
 1f7e956:	vmovdqu %xmm3,(%rax,%r14,1)
 1f7e95c:	mov    0xba0(%r11),%rax
 1f7e963:	vmovdqu %xmm1,(%rax,%r14,1)
 1f7e969:	mov    0xba8(%r11),%rax
 1f7e970:	vmovdqu %xmm2,(%rax,%r14,1)
 1f7e976:	add    $0x10,%r14
 1f7e97a:	cmp    %r15,%r14
 1f7e97d:	jae    1f807d0 <node_facts_window_run+0x3400>
 1f7e983:	vpxor  %xmm2,%xmm2,%xmm2
 1f7e987:	cmp    %rsi,%r14
 1f7e98a:	jae    1f7e900 <node_facts_window_run+0x1530>
 1f7e990:	mov    %esi,%eax
 1f7e992:	sub    %r14d,%eax
 1f7e995:	mov    $0x10,%ecx
 1f7e99a:	mov    $0xffffffff,%edx
 1f7e99f:	mov    %r14,%rbp
 1f7e9a2:	vpxord %xmm18,%xmm18,%xmm18
 1f7e9a8:	cmp    $0x10,%eax
 1f7e9ab:	cmovae %ecx,%eax
 1f7e9ae:	mov    0x9b8(%r11),%rcx
 1f7e9b5:	shl    $0x6,%rbp
 1f7e9b9:	shlx   %eax,%edx,%eax
 1f7e9be:	vmovdqu (%r8,%rbp,1),%ymm0
 1f7e9c4:	vmovdqu 0x180(%r8,%rbp,1),%ymm3
 1f7e9ce:	vmovdqu 0x80(%r8,%rbp,1),%ymm1
 1f7e9d8:	vmovdqu 0x100(%r8,%rbp,1),%ymm2
 1f7e9e2:	not    %eax
 1f7e9e4:	vinserti64x4 $0x1,0x40(%r8,%rbp,1),%zmm0,%zmm6
 1f7e9ed:	vmovdqu 0x200(%r8,%rbp,1),%ymm0
 1f7e9f7:	vinserti64x4 $0x1,0x1c0(%r8,%rbp,1),%zmm3,%zmm7
 1f7ea00:	vinserti64x4 $0x1,0xc0(%r8,%rbp,1),%zmm1,%zmm1
 1f7ea09:	vinserti64x4 $0x1,0x140(%r8,%rbp,1),%zmm2,%zmm2
 1f7ea12:	kmovd  %eax,%k1
 1f7ea16:	vinserti64x4 $0x1,0x240(%r8,%rbp,1),%zmm0,%zmm3
 1f7ea1f:	vmovdqu 0x280(%r8,%rbp,1),%ymm0
 1f7ea29:	mov    0xb48(%rdi),%rax
 1f7ea30:	vinserti64x4 $0x1,0x2c0(%r8,%rbp,1),%zmm0,%zmm9
 1f7ea39:	vmovdqu 0x300(%r8,%rbp,1),%ymm0
 1f7ea43:	vmovdqu8 (%rcx,%r14,1),%xmm4{%k1}{z}
 1f7ea4a:	mov    0x5b0(%rsp),%rcx
 1f7ea52:	vinserti64x4 $0x1,0x340(%r8,%rbp,1),%zmm0,%zmm8
 1f7ea5b:	vmovdqu 0x380(%r8,%rbp,1),%ymm0
 1f7ea65:	vinserti64x4 $0x1,0x3c0(%r8,%rbp,1),%zmm0,%zmm15
 1f7ea6e:	vmovdqu8 (%rcx,%r14,1),%xmm5{%k1}{z}
 1f7ea75:	vptestmb %xmm4,%xmm4,%k6
 1f7ea7b:	vpcmpeqb -0x19b6d75(%rip),%xmm5,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7ea85:	vmovdqu32 (%r12,%r14,4),%zmm0{%k7}{z}
 1f7ea8c:	kmovq  %k7,%k1
 1f7ea91:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7ea98:	vptestnmd %zmm13,%zmm18,%k0
 1f7ea9e:	ktestw %k0,%k7
 1f7eaa2:	jne    1f7f06a <node_facts_window_run+0x1c9a>
 1f7eaa8:	vmovdqa64 -0x1ac8372(%rip),%zmm0        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7eab2:	vptestmd -0x19adb44(%rip){1to16},%zmm18,%k0        # 5d0f78 <.LCPI3_12>
 1f7eabc:	kmovd  %k6,%edx
 1f7eac0:	vpermt2d %zmm1,%zmm0,%zmm6
 1f7eac6:	vpermt2d %zmm7,%zmm0,%zmm2
 1f7eacc:	vpermt2d %zmm9,%zmm0,%zmm3
 1f7ead2:	vpermt2d %zmm15,%zmm0,%zmm8
 1f7ead8:	kmovd  %k0,%r13d
 1f7eadc:	vptestmd %zmm14,%zmm18,%k0
 1f7eae2:	vshufi64x2 $0x44,%zmm2,%zmm6,%zmm0
 1f7eae9:	vshufi64x2 $0x44,%zmm8,%zmm3,%zmm1
 1f7eaf0:	vshufi64x2 $0xee,%zmm2,%zmm6,%zmm2
 1f7eaf7:	vshufi64x2 $0xee,%zmm8,%zmm3,%zmm3
 1f7eafe:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm15{%k6}{z}
 1f7eb05:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7eb0c:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm17{%k6}{z}
 1f7eb13:	vshufi64x2 $0x88,%zmm3,%zmm2,%zmm7
 1f7eb1a:	vpsrld $0x19,%zmm15,%zmm0
 1f7eb21:	vpandd -0x19adbc3(%rip){1to16},%zmm0,%zmm0        # 5d0f68 <.LCPI3_4>
 1f7eb2b:	vpsrld $0x18,%zmm15,%zmm1
 1f7eb32:	vpsrld $0x1a,%zmm15,%zmm6
 1f7eb39:	vpternlogd $0xec,%zmm10,%zmm0,%zmm1
 1f7eb40:	vpandd -0x19adb96(%rip){1to16},%zmm15,%zmm0        # 5d0fb4 <.LCPI3_76>
 1f7eb4a:	vpmovdb %zmm1,%xmm16
 1f7eb50:	vpsrld $0xc,%zmm17,%zmm1
 1f7eb57:	vpmovdb %zmm1,%xmm20
 1f7eb5d:	vpcmpeqd -0x19adbf7(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f70 <.LCPI3_7>
 1f7eb67:	vporq  %xmm11,%xmm16,%xmm0
 1f7eb6d:	vmovdqu8 %xmm0,%xmm16{%k1}
 1f7eb73:	vpcmpeqb %xmm11,%xmm5,%k1{%k6}
 1f7eb79:	vpternlogq $0xf8,%xmm12,%xmm20,%xmm16
 1f7eb80:	kmovd  %k1,%eax
 1f7eb84:	kmovw  %k1,0x120(%rsp)
 1f7eb8d:	korw   %k0,%k1,%k1
 1f7eb91:	kmovw  %k1,0x1e0(%rsp)
 1f7eb9a:	test   %ax,%ax
 1f7eb9d:	je     1f7ed2a <node_facts_window_run+0x195a>
 1f7eba3:	vmovdqu64 %zmm7,0x450(%rsp)
 1f7ebae:	vmovdqu64 %zmm6,0x2d0(%rsp)
 1f7ebb9:	vmovdqa64 %xmm20,0x490(%rsp)
 1f7ebc1:	vmovdqu64 %zmm19,0x3d0(%rsp)
 1f7ebcc:	vmovdqu64 %zmm18,0x4d0(%rsp)
 1f7ebd7:	vmovdqu64 %zmm15,0x220(%rsp)
 1f7ebe2:	vmovdqa %xmm4,0x290(%rsp)
 1f7ebeb:	vmovdqu64 %zmm17,0x310(%rsp)
 1f7ebf6:	mov    %edx,0x350(%rsp)
 1f7ebfd:	vmovdqa64 %xmm16,0x390(%rsp)
 1f7ec05:	kmovw  %k7,0x160(%rsp)
 1f7ec0e:	kmovw  %k6,0x1a0(%rsp)
 1f7ec17:	movzwl %ax,%ebx
 1f7ec1a:	movzwl %r13w,%r13d
 1f7ec1e:	mov    0x570(%rsp),%rax
 1f7ec26:	lea    (%rax,%r14,4),%r15
 1f7ec2a:	nopw   0x0(%rax,%rax,1)
 1f7ec30:	xor    %r12d,%r12d
 1f7ec33:	tzcnt  %ebx,%r12d
 1f7ec38:	xor    %edx,%edx
 1f7ec3a:	mov    (%r15,%r12,4),%esi
 1f7ec3e:	vzeroupper
 1f7ec41:	call   1f93910 <node_tests_window_line>
 1f7ec46:	mov    0x8(%rsp),%rdi
 1f7ec4b:	mov    $0x1,%edx
 1f7ec50:	xor    %ecx,%ecx
 1f7ec52:	test   $0x2,%al
 1f7ec54:	shlx   %r12d,%edx,%eax
 1f7ec59:	cmove  %ecx,%eax
 1f7ec5c:	or     %eax,%r13d
 1f7ec5f:	blsr   %ebx,%ebx
 1f7ec64:	jne    1f7ec30 <node_facts_window_run+0x1860>
 1f7ec66:	vpbroadcastd -0x19add04(%rip),%zmm10        # 5d0f6c <.LCPI3_5>
 1f7ec70:	vpbroadcastb -0x1ac7f39(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7ec79:	vpbroadcastb -0x1ac7f41(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7ec82:	vpbroadcastd -0x19add18(%rip),%zmm13        # 5d0f74 <.LCPI3_11>
 1f7ec8c:	vpbroadcastd -0x19add1a(%rip),%zmm14        # 5d0f7c <.LCPI3_13>
 1f7ec96:	vmovdqa64 0x390(%rsp),%xmm16
 1f7ec9e:	vmovdqu64 0x310(%rsp),%zmm17
 1f7eca9:	vmovdqa 0x290(%rsp),%xmm4
 1f7ecb2:	vmovdqu64 0x220(%rsp),%zmm15
 1f7ecbd:	vmovdqu64 0x4d0(%rsp),%zmm18
 1f7ecc8:	vmovdqu64 0x3d0(%rsp),%zmm19
 1f7ecd3:	vmovdqa64 0x490(%rsp),%xmm20
 1f7ecdb:	vmovdqu64 0x2d0(%rsp),%zmm6
 1f7ece6:	vmovdqu64 0x450(%rsp),%zmm7
 1f7ecf1:	mov    (%rsp),%r11
 1f7ecf5:	mov    0x48(%rsp),%r9
 1f7ecfa:	mov    0x38(%rsp),%r12
 1f7ecff:	mov    0x28(%rsp),%rsi
 1f7ed04:	mov    0x20(%rsp),%r8
 1f7ed09:	mov    0x530(%rsp),%r15
 1f7ed11:	kmovw  0x1a0(%rsp),%k6
 1f7ed1a:	kmovw  0x160(%rsp),%k7
 1f7ed23:	mov    0x350(%rsp),%edx
 1f7ed2a:	vpsrld $0x2,%zmm17,%zmm0
 1f7ed31:	vpandd -0x19addbb(%rip){1to16},%zmm0,%zmm0        # 5d0f80 <.LCPI3_14>
 1f7ed3b:	vptestmd -0x19addbd(%rip){1to16},%zmm17,%k2        # 5d0f88 <.LCPI3_16>
 1f7ed45:	vpandd -0x19add97(%rip){1to16},%zmm15,%zmm3        # 5d0fb8 <.LCPI3_79>
 1f7ed4f:	vptestnmb %xmm4,%xmm4,%k0
 1f7ed55:	vpbroadcastd -0x19addcb(%rip),%zmm4        # 5d0f94 <.LCPI3_21>
 1f7ed5f:	vptestmd -0x19adddd(%rip){1to16},%zmm19,%k3        # 5d0f8c <.LCPI3_17>
 1f7ed69:	vpandd %zmm14,%zmm19,%zmm1
 1f7ed6f:	vpbroadcastb -0x1ac8034(%rip),%xmm8        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7ed78:	vpbroadcastb -0x1ac803f(%rip),%xmm5        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7ed81:	vpbroadcastb -0x1ac8047(%rip),%xmm9        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7ed8a:	vpcmpneqd -0x19ade11(%rip){1to16},%zmm0,%k1        # 5d0f84 <.LCPI3_15>
 1f7ed95:	vpaddd -0x19ade0f(%rip){1to16},%zmm3,%zmm3        # 5d0f90 <.LCPI3_20>
 1f7ed9f:	vpcmpeqd %zmm4,%zmm6,%k5{%k6}
 1f7eda5:	vpsrld $0x10,%zmm17,%zmm6
 1f7edac:	korw   %k1,%k2,%k1
 1f7edb0:	vptestnmd %zmm7,%zmm7,%k2
 1f7edb6:	korw   %k2,%k0,%k2
 1f7edba:	vptestnmd %zmm1,%zmm1,%k0
 1f7edc0:	korw   %k1,%k2,%k1
 1f7edc4:	kmovd  %k0,%eax
 1f7edc8:	vpcmpltud %zmm4,%zmm3,%k0
 1f7edcf:	vpslld $0x1f,%zmm3,%zmm3
 1f7edd6:	vpxor  %xmm4,%xmm4,%xmm4
 1f7edda:	vptestmd %zmm0,%zmm0,%k1{%k1}
 1f7ede0:	kmovd  %k0,%ecx
 1f7ede4:	and    %eax,%ecx
 1f7ede6:	mov    %edx,%eax
 1f7ede8:	and    %ecx,%eax
 1f7edea:	kmovd  %eax,%k4
 1f7edee:	vmovdqu8 %xmm11,%xmm2{%k1}{z}
 1f7edf4:	kmovd  %r13d,%k1
 1f7edf9:	korw   %k3,%k1,%k3
 1f7edfd:	vpcmpeqd %zmm13,%zmm0,%k1{%k4}
 1f7ee03:	vmovdqu8 %xmm8,%xmm0{%k5}{z}
 1f7ee09:	vmovdqu8 -0x19b70d3(%rip),%xmm0{%k4}        # 5c7d40 <.LCPI3_25>
 1f7ee13:	knotw  %k1,%k0
 1f7ee17:	kmovd  %k0,%ecx
 1f7ee1b:	and    %eax,%ecx
 1f7ee1d:	kmovd  %ecx,%k4
 1f7ee21:	vpcmpgtd %zmm3,%zmm4,%k4{%k4}
 1f7ee27:	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
 1f7ee2e:	vpaddd %zmm3,%zmm6,%zmm7
 1f7ee34:	vpbroadcastb -0x1ac80f8(%rip),%xmm3        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7ee3d:	vmovdqu8 -0x19b70f7(%rip),%xmm0{%k4}        # 5c7d50 <.LCPI3_26>
 1f7ee47:	vptestnmd %zmm7,%zmm7,%k4
 1f7ee4d:	vpblendmb -0x19b70e7(%rip),%xmm3,%xmm3{%k4}        # 5c7d70 <.LCPI3_28>
 1f7ee57:	vpcmpnleud -0x19adeca(%rip){1to16},%zmm7,%k4        # 5d0f98 <.LCPI3_22>
 1f7ee62:	cmpb   $0x0,0xb90(%rdi)
 1f7ee69:	vmovdqu8 -0x19b70f3(%rip),%xmm3{%k4}        # 5c7d80 <.LCPI3_29>
 1f7ee73:	vpcmpnleud -0x19adee2(%rip){1to16},%zmm7,%k4        # 5d0f9c <.LCPI3_23>
 1f7ee7e:	vmovdqu8 -0x19b70f8(%rip),%xmm3{%k4}        # 5c7d90 <.LCPI3_30>
 1f7ee88:	vptestmd %zmm1,%zmm1,%k4
 1f7ee8e:	vpor   %xmm5,%xmm2,%xmm1
 1f7ee92:	vmovdqu8 %xmm1,%xmm2{%k4}
 1f7ee98:	kmovw  0x1e0(%rsp),%k4
 1f7eea1:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f7eea7:	vpor   %xmm0,%xmm2,%xmm0
 1f7eeab:	vpord  -0x19adef9(%rip){1to4},%xmm0,%xmm1        # 5d0fbc <.LCPI3_82>
 1f7eeb5:	vpbroadcastb -0x1ac8178(%rip),%xmm3        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7eebe:	vmovdqu8 %xmm1,%xmm0{%k4}
 1f7eec4:	vpor   %xmm3,%xmm0,%xmm1
 1f7eec8:	vmovdqu8 %xmm1,%xmm0{%k3}
 1f7eece:	vpmovdb %zmm17,%xmm1
 1f7eed4:	kmovw  0x120(%rsp),%k3
 1f7eedd:	vpor   %xmm1,%xmm9,%xmm2
 1f7eee1:	vmovdqu8 %xmm2,%xmm1{%k3}
 1f7eee7:	vptestmd -0x19adf51(%rip){1to16},%zmm18,%k3{%k7}        # 5d0fa0 <.LCPI3_32>
 1f7eef1:	vmovdqu8 %xmm8,%xmm2{%k3}{z}
 1f7eef7:	vpor   %xmm3,%xmm2,%xmm3
 1f7eefb:	vpsrld $0x8,%zmm15,%zmm8
 1f7ef02:	vmovdqu8 %xmm2,%xmm3{%k2}
 1f7ef08:	vpandd -0x19adf52(%rip){1to4},%xmm20,%xmm2        # 5d0fc0 <.LCPI3_84>
 1f7ef12:	vptestmd -0x19adf78(%rip){1to16},%zmm19,%k2        # 5d0fa4 <.LCPI3_33>
 1f7ef1c:	vpor   %xmm2,%xmm12,%xmm4
 1f7ef20:	vmovdqu8 %xmm4,%xmm2{%k6}
 1f7ef26:	vpmovdb %zmm19,%xmm4
 1f7ef2c:	vgf2p8affineqb $0x0,-0x19b09a7(%rip){1to2},%xmm4,%xmm4        # 5ce590 <.LCPI3_85>
 1f7ef37:	vpternlogq $0xf8,%xmm9,%xmm4,%xmm2
 1f7ef3e:	vpor   %xmm2,%xmm11,%xmm4
 1f7ef42:	vmovdqu8 %xmm4,%xmm2{%k2}
 1f7ef48:	vpsrld $0xb,%zmm19,%zmm4
 1f7ef4f:	vpmovdb %zmm4,%xmm4
 1f7ef55:	vpand  %xmm5,%xmm4,%xmm4
 1f7ef59:	vpmovdb %zmm15,%xmm5
 1f7ef5f:	vpternlogq $0xfe,%xmm4,%xmm3,%xmm2
 1f7ef66:	vpsrld $0x10,%zmm15,%zmm3
 1f7ef6d:	vpmovdb %zmm8,%xmm4
 1f7ef73:	vpmovdb %zmm3,%xmm3
 1f7ef79:	je     1f7f060 <node_facts_window_run+0x1c90>
 1f7ef7f:	vmovdqa64 -0x1ac8789(%rip),%zmm15        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7ef89:	vptestmd %zmm6,%zmm6,%k1{%k1}
 1f7ef8f:	add    %r8,%rbp
 1f7ef92:	vpxor  %xmm8,%xmm8,%xmm8
 1f7ef97:	vpxor  %xmm9,%xmm9,%xmm9
 1f7ef9c:	vpcmpneqd -0x19adfff(%rip){1to16},%zmm6,%k0{%k1}        # 5d0fa8 <.LCPI3_38>
 1f7efa7:	vmovdqa %xmm3,%xmm6
 1f7efab:	vpternlogq $0xfe,%xmm5,%xmm1,%xmm6
 1f7efb2:	kmovq  %k1,%k2
 1f7efb7:	kmovw  %k1,%eax
 1f7efbb:	popcnt %eax,%ecx
 1f7efbf:	vpgatherdd 0x10(%rbp,%zmm15,1),%zmm8{%k2}
 1f7efc7:	kmovq  %k1,%k2
 1f7efcc:	vpcmpnleud -0x19ae02b(%rip){1to16},%zmm8,%k3        # 5d0fac <.LCPI3_39>
 1f7efd7:	vpgatherdd 0x14(%rbp,%zmm15,1),%zmm9{%k2}
 1f7efdf:	add    %rcx,0x30(%rsp)
 1f7efe4:	mov    0x10(%rsp),%r10
 1f7efe9:	vpcmpeqd %zmm7,%zmm8,%k2
 1f7efef:	vmovdqa64 %xmm16,%xmm7
 1f7eff5:	vpternlogq $0xfe,%xmm4,%xmm6,%xmm7
 1f7effc:	vptestnmd %zmm9,%zmm9,%k2{%k2}
 1f7f002:	vptestmd %zmm9,%zmm9,%k4
 1f7f008:	vpternlogq $0xfe,%xmm2,%xmm0,%xmm7
 1f7f00f:	korw   %k4,%k3,%k3
 1f7f013:	kandw  %k2,%k0,%k2
 1f7f017:	knotw  %k0,%k0
 1f7f01b:	kandd  %k1,%k0,%k0
 1f7f020:	kandw  %k0,%k3,%k0
 1f7f024:	korw   %k0,%k2,%k2
 1f7f028:	vptestnmd %zmm10,%zmm17,%k0{%k2}
 1f7f02e:	kandw  %k0,%k1,%k0
 1f7f032:	kmovd  %k0,%ecx
 1f7f036:	vptestmb %xmm7,%xmm7,%k0
 1f7f03c:	andn   %eax,%ecx,%eax
 1f7f041:	kmovd  %k0,%ecx
 1f7f045:	andn   %ecx,%edx,%ecx
 1f7f04a:	popcnt %eax,%eax
 1f7f04e:	movzwl %cx,%ecx
 1f7f051:	popcnt %ecx,%ecx
 1f7f055:	add    %rcx,%r10
 1f7f058:	add    %rax,%r10
 1f7f05b:	mov    %r10,0x10(%rsp)
 1f7f060:	mov    0x18(%rsp),%rbp
 1f7f065:	jmp    1f7e91a <node_facts_window_run+0x154a>
 1f7f06a:	kandw  %k0,%k7,%k0
 1f7f06e:	vmovdqa %xmm5,0x1e0(%rsp)
 1f7f077:	vmovdqu64 %zmm6,0x390(%rsp)
 1f7f082:	vmovdqu64 %zmm2,0x350(%rsp)
 1f7f08d:	vmovdqu64 %zmm3,0x310(%rsp)
 1f7f098:	vmovdqu64 %zmm1,0x220(%rsp)
 1f7f0a3:	vmovdqu64 %zmm7,0x4d0(%rsp)
 1f7f0ae:	vmovdqu64 %zmm8,0x3d0(%rsp)
 1f7f0b9:	vmovdqu64 %zmm9,0x490(%rsp)
 1f7f0c4:	vmovdqu64 %zmm15,0x2d0(%rsp)
 1f7f0cf:	vmovdqu64 %zmm0,0x450(%rsp)
 1f7f0da:	kmovw  %k6,0x1a0(%rsp)
 1f7f0e3:	kmovw  %k7,0x160(%rsp)
 1f7f0ec:	vmovdqa %xmm4,0x290(%rsp)
 1f7f0f5:	kmovd  %k0,%eax
 1f7f0f9:	movzwl %ax,%r13d
 1f7f0fd:	jmp    1f7f228 <node_facts_window_run+0x1e58>
 1f7f102:	mov    (%r12,%rax,4),%r9d
 1f7f106:	mov    0xb48(%rdi),%rsi
 1f7f10d:	shl    $0x6,%rcx
 1f7f111:	mov    0x20(%r11),%rdx
 1f7f115:	cmpb   $0x1,(%rsi,%r9,1)
 1f7f11a:	mov    %r9,0x120(%rsp)
 1f7f122:	movzbl 0x30(%rdx,%rcx,1),%edx
 1f7f127:	adcq   $0x0,0x40(%rsp)
 1f7f12d:	and    $0x1,%edx
 1f7f130:	mov    0x570(%rsp),%rsi
 1f7f138:	mov    (%rsi,%rax,4),%esi
 1f7f13b:	vzeroupper
 1f7f13e:	call   1f93910 <node_tests_window_line>
 1f7f143:	mov    0x8(%rsp),%rdi
 1f7f148:	vpbroadcastd -0x19ae1e6(%rip),%zmm10        # 5d0f6c <.LCPI3_5>
 1f7f152:	vpbroadcastb -0x1ac841b(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f15b:	vpbroadcastb -0x1ac8423(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f164:	vpbroadcastd -0x19ae1fa(%rip),%zmm13        # 5d0f74 <.LCPI3_11>
 1f7f16e:	vpbroadcastd -0x19ae1fc(%rip),%zmm14        # 5d0f7c <.LCPI3_13>
 1f7f178:	vmovdqa 0x290(%rsp),%xmm4
 1f7f181:	vmovdqa 0x1e0(%rsp),%xmm5
 1f7f18a:	vmovdqu64 0x390(%rsp),%zmm6
 1f7f195:	vmovdqu64 0x350(%rsp),%zmm2
 1f7f1a0:	vmovdqu64 0x310(%rsp),%zmm3
 1f7f1ab:	vmovdqu64 0x220(%rsp),%zmm1
 1f7f1b6:	vmovdqu64 0x4d0(%rsp),%zmm7
 1f7f1c1:	vmovdqu64 0x3d0(%rsp),%zmm8
 1f7f1cc:	vmovdqu64 0x490(%rsp),%zmm9
 1f7f1d7:	vmovdqu64 0x2d0(%rsp),%zmm15
 1f7f1e2:	vmovdqu64 0x450(%rsp),%zmm0
 1f7f1ed:	mov    (%rsp),%r11
 1f7f1f1:	mov    0x120(%rsp),%rdx
 1f7f1f9:	mov    0x48(%rsp),%r9
 1f7f1fe:	mov    0x20(%rsp),%r8
 1f7f203:	kmovw  0x1a0(%rsp),%k6
 1f7f20c:	kmovw  0x160(%rsp),%k7
 1f7f215:	or     %bl,%al
 1f7f217:	blsr   %r13d,%r13d
 1f7f21c:	mov    0xb48(%rdi),%rcx
 1f7f223:	mov    %al,(%rcx,%rdx,1)
 1f7f226:	je     1f7f28d <node_facts_window_run+0x1ebd>
 1f7f228:	xor    %eax,%eax
 1f7f22a:	tzcnt  %r13d,%eax
 1f7f22f:	mov    0x60(%r11),%esi
 1f7f233:	mov    $0x1,%bl
 1f7f235:	add    %r14,%rax
 1f7f238:	mov    %rax,%rdx
 1f7f23b:	shl    $0x6,%rdx
 1f7f23f:	mov    (%r8,%rdx,1),%ecx
 1f7f243:	mov    0xc(%r8,%rdx,1),%edx
 1f7f248:	shr    $0x3,%ecx
 1f7f24b:	cmp    %esi,%ecx
 1f7f24d:	cmovae %esi,%ecx
 1f7f250:	test   %rdx,%rdx
 1f7f253:	je     1f7f102 <node_facts_window_run+0x1d32>
 1f7f259:	mov    0x5f0(%rsp),%rsi
 1f7f261:	cmp    0x3b8(%rsi),%edx
 1f7f267:	jae    1f7f102 <node_facts_window_run+0x1d32>
 1f7f26d:	mov    0x5f0(%rsp),%rsi
 1f7f275:	mov    0x3a8(%rsi),%rsi
 1f7f27c:	cmpl   $0x0,(%rsi,%rdx,4)
 1f7f280:	setne  %bl
 1f7f283:	shl    $0x5,%bl
 1f7f286:	inc    %bl
 1f7f288:	jmp    1f7f102 <node_facts_window_run+0x1d32>
 1f7f28d:	mov    0xb48(%rdi),%rax
 1f7f294:	kmovq  %k7,%k1
 1f7f299:	vpxord %xmm18,%xmm18,%xmm18
 1f7f29f:	mov    0x28(%rsp),%rsi
 1f7f2a4:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7f2ab:	jmp    1f7eaa8 <node_facts_window_run+0x16d8>
 1f7f2b0:	test   %eax,%eax
 1f7f2b2:	je     1f807b5 <node_facts_window_run+0x33e5>
 1f7f2b8:	vpbroadcastd -0x19ae356(%rip),%zmm13        # 5d0f6c <.LCPI3_5>
 1f7f2c2:	vpbroadcastb -0x1ac858b(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f2cb:	vpbroadcastb -0x1ac8593(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f2d4:	vpbroadcastd -0x19ae36a(%rip),%zmm16        # 5d0f74 <.LCPI3_11>
 1f7f2de:	vpbroadcastd -0x19ae36c(%rip),%zmm17        # 5d0f7c <.LCPI3_13>
 1f7f2e8:	mov    (%r11),%rcx
 1f7f2eb:	lea    0x69454(%rbp),%r10
 1f7f2f2:	lea    0x422c(%rbp),%rdx
 1f7f2f9:	mov    %eax,%r14d
 1f7f2fc:	xor    %r15d,%r15d
 1f7f2ff:	mov    %rcx,0x78(%rsp)
 1f7f304:	mov    %r10,0x98(%rsp)
 1f7f30c:	mov    %rdx,0x80(%rsp)
 1f7f314:	movq   $0x0,0x40(%rsp)
 1f7f31d:	movq   $0x0,0x30(%rsp)
 1f7f326:	movq   $0x0,0x10(%rsp)
 1f7f32f:	mov    %r14,0x90(%rsp)
 1f7f337:	jmp    1f7f3fb <node_facts_window_run+0x202b>
 1f7f33c:	nopl   0x0(%rax)
 1f7f340:	vpxor  %xmm1,%xmm1,%xmm1
 1f7f344:	vpxor  %xmm0,%xmm0,%xmm0
 1f7f348:	vpxor  %xmm5,%xmm5,%xmm5
 1f7f34c:	vpxor  %xmm3,%xmm3,%xmm3
 1f7f350:	vpxor  %xmm6,%xmm6,%xmm6
 1f7f354:	vpxor  %xmm7,%xmm7,%xmm7
 1f7f358:	vpxor  %xmm8,%xmm8,%xmm8
 1f7f35d:	vpxor  %xmm2,%xmm2,%xmm2
 1f7f361:	vpxord %xmm19,%xmm19,%xmm19
 1f7f367:	mov    0xb10(%rdi),%rax
 1f7f36e:	vmovdqu64 %xmm19,(%rax,%r15,1)
 1f7f375:	mov    0xb18(%rdi),%rax
 1f7f37c:	vmovdqu %xmm2,(%rax,%r15,1)
 1f7f382:	mov    0xb88(%r11),%rax
 1f7f389:	vmovdqu %xmm8,(%rax,%r15,1)
 1f7f38f:	mov    0xb90(%r11),%rax
 1f7f396:	vmovdqu %xmm7,(%rax,%r15,1)
 1f7f39c:	mov    0xb98(%r11),%rax
 1f7f3a3:	vmovdqu %xmm6,(%rax,%r15,1)
 1f7f3a9:	mov    0xba0(%r11),%rax
 1f7f3b0:	vmovdqu %xmm3,(%rax,%r15,1)
 1f7f3b6:	mov    0xba8(%r11),%rax
 1f7f3bd:	vmovdqu %xmm4,(%rax,%r15,1)
 1f7f3c3:	mov    0xc28(%r11),%rax
 1f7f3ca:	vmovdqu64 %zmm5,(%rax,%r15,4)
 1f7f3d1:	mov    0xcd8(%r11),%rax
 1f7f3d8:	vmovdqu64 %zmm0,(%rax,%r15,8)
 1f7f3df:	mov    0xcd8(%r11),%rax
 1f7f3e6:	vmovdqu64 %zmm1,0x40(%rax,%r15,8)
 1f7f3ee:	add    $0x10,%r15
 1f7f3f2:	cmp    %r14,%r15
 1f7f3f5:	jae    1f807d0 <node_facts_window_run+0x3400>
 1f7f3fb:	vpxor  %xmm4,%xmm4,%xmm4
 1f7f3ff:	cmp    %rsi,%r15
 1f7f402:	jae    1f7f340 <node_facts_window_run+0x1f70>
 1f7f408:	mov    %esi,%eax
 1f7f40a:	sub    %r15d,%eax
 1f7f40d:	mov    $0x10,%ecx
 1f7f412:	mov    $0xffffffff,%edx
 1f7f417:	mov    %r15,%rbp
 1f7f41a:	vpxor  %xmm12,%xmm12,%xmm12
 1f7f41f:	cmp    $0x10,%eax
 1f7f422:	cmovae %ecx,%eax
 1f7f425:	mov    0x9b8(%r11),%rcx
 1f7f42c:	shl    $0x6,%rbp
 1f7f430:	shlx   %eax,%edx,%eax
 1f7f435:	vmovdqu (%r8,%rbp,1),%ymm4
 1f7f43b:	vmovdqu64 0x40(%r8,%rbp,1),%ymm26
 1f7f443:	vmovdqu64 0x80(%r8,%rbp,1),%ymm27
 1f7f44b:	vmovdqu64 0xc0(%r8,%rbp,1),%ymm28
 1f7f453:	vmovdqu 0x100(%r8,%rbp,1),%ymm5
 1f7f45d:	vmovdqu 0x140(%r8,%rbp,1),%ymm6
 1f7f467:	vmovdqu64 0x180(%r8,%rbp,1),%ymm24
 1f7f46f:	vmovdqu64 0x1c0(%r8,%rbp,1),%ymm25
 1f7f477:	vmovdqu 0x200(%r8,%rbp,1),%ymm7
 1f7f481:	vmovdqu64 0x240(%r8,%rbp,1),%ymm18
 1f7f489:	vmovdqu64 0x280(%r8,%rbp,1),%ymm22
 1f7f491:	vmovdqu64 0x2c0(%r8,%rbp,1),%ymm23
 1f7f499:	vmovdqu 0x300(%r8,%rbp,1),%ymm11
 1f7f4a3:	vmovdqu64 0x340(%r8,%rbp,1),%ymm19
 1f7f4ab:	vmovdqu64 0x380(%r8,%rbp,1),%ymm20
 1f7f4b3:	vmovdqu64 0x3c0(%r8,%rbp,1),%ymm21
 1f7f4bb:	not    %eax
 1f7f4bd:	kmovd  %eax,%k1
 1f7f4c1:	mov    0xb48(%rdi),%rax
 1f7f4c8:	vmovdqu8 (%rcx,%r15,1),%xmm0{%k1}{z}
 1f7f4cf:	mov    0x98(%rsp),%rcx
 1f7f4d7:	vmovdqu8 (%rcx,%r15,1),%xmm10{%k1}{z}
 1f7f4de:	vptestmb %xmm0,%xmm0,%k6
 1f7f4e4:	vpcmpeqb -0x19b77de(%rip),%xmm10,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7f4ee:	vmovdqu32 (%r12,%r15,4),%zmm0{%k7}{z}
 1f7f4f5:	kmovq  %k7,%k1
 1f7f4fa:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7f501:	vptestnmd %zmm16,%zmm12,%k0
 1f7f507:	ktestw %k0,%k7
 1f7f50b:	jne    1f7fc4b <node_facts_window_run+0x287b>
 1f7f511:	vpmovsxbd -0x19ae56a(%rip),%xmm3        # 5d0fb0 <.LCPI3_75>
 1f7f51a:	vmovdqa64 -0x1ac8de4(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7f524:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7f52b:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7f532:	vptestmd -0x19ae5c4(%rip){1to16},%zmm12,%k0        # 5d0f78 <.LCPI3_12>
 1f7f53c:	vmovdqa64 %zmm0,%zmm2
 1f7f542:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7f548:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7f54e:	vmovdqa64 %zmm3,%zmm9
 1f7f554:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7f55a:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7f560:	kmovd  %k0,%r13d
 1f7f564:	vptestmd %zmm17,%zmm12,%k0
 1f7f56a:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7f570:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7f577:	vmovdqu64 %zmm1,0x1e0(%rsp)
 1f7f582:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7f589:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7f58d:	vmovdqa64 %zmm1,%zmm4
 1f7f593:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7f599:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7f59f:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7f5a5:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7f5ab:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7f5b2:	vmovdqu %ymm3,0x160(%rsp)
 1f7f5bb:	vinserti64x4 $0x1,%ymm18,%zmm7,%zmm3
 1f7f5c2:	vpunpcklqdq %ymm18,%ymm7,%ymm7
 1f7f5c8:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm18
 1f7f5cf:	vmovdqa64 %zmm3,%zmm6
 1f7f5d5:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7f5db:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7f5e1:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7f5e7:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7f5ed:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7f5f3:	vmovdqa64 %zmm18,%zmm7
 1f7f5f9:	vmovdqu64 %zmm5,0x290(%rsp)
 1f7f604:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7f60b:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7f611:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7f618:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7f61f:	vpermt2d %zmm5,%zmm9,%zmm18
 1f7f625:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7f62b:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7f632:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7f638:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7f63e:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7f645:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7f64c:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm21{%k6}{z}
 1f7f653:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7f65a:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm20{%k6}{z}
 1f7f661:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7f668:	vpsrld $0x19,%zmm21,%zmm0
 1f7f66f:	vpandd -0x19ae711(%rip){1to16},%zmm0,%zmm0        # 5d0f68 <.LCPI3_4>
 1f7f679:	vpsrld $0x18,%zmm21,%zmm1
 1f7f680:	vpsrld $0x1a,%zmm21,%zmm7
 1f7f687:	vpternlogd $0xec,%zmm13,%zmm0,%zmm1
 1f7f68e:	vpandd -0x19ae6e4(%rip){1to16},%zmm21,%zmm0        # 5d0fb4 <.LCPI3_76>
 1f7f698:	vpmovdb %zmm1,%xmm19
 1f7f69e:	vpsrld $0xc,%zmm20,%zmm1
 1f7f6a5:	vpmovdb %zmm1,%xmm24
 1f7f6ab:	vpcmpeqd -0x19ae745(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f70 <.LCPI3_7>
 1f7f6b5:	vporq  %xmm14,%xmm19,%xmm0
 1f7f6bb:	vmovdqu8 %xmm0,%xmm19{%k1}
 1f7f6c1:	vpcmpeqb %xmm14,%xmm10,%k1{%k6}
 1f7f6c7:	vpternlogq $0xf8,%xmm15,%xmm24,%xmm19
 1f7f6ce:	kmovd  %k1,%eax
 1f7f6d2:	kmovw  %k1,0x120(%rsp)
 1f7f6db:	korw   %k0,%k1,%k1
 1f7f6df:	kmovw  %k1,0x1a0(%rsp)
 1f7f6e8:	test   %ax,%ax
 1f7f6eb:	je     1f7f8b0 <node_facts_window_run+0x24e0>
 1f7f6f1:	vmovdqu64 %zmm4,0x660(%rsp)
 1f7f6fc:	vmovdqu %ymm5,0x5f0(%rsp)
 1f7f705:	vmovdqu64 %zmm7,0x530(%rsp)
 1f7f710:	vmovdqa64 %xmm24,0x570(%rsp)
 1f7f718:	vmovdqu64 %zmm23,0x5b0(%rsp)
 1f7f723:	vmovdqu64 %zmm22,0x450(%rsp)
 1f7f72e:	vmovdqu64 %zmm21,0x2d0(%rsp)
 1f7f739:	vmovdqu64 %zmm18,0x490(%rsp)
 1f7f744:	vmovdqu64 %zmm20,0x3d0(%rsp)
 1f7f74f:	vmovdqu64 %zmm12,0x4d0(%rsp)
 1f7f75a:	vmovdqa64 %xmm19,0x220(%rsp)
 1f7f762:	kmovw  %k7,0x350(%rsp)
 1f7f76b:	mov    %rbp,0x310(%rsp)
 1f7f773:	kmovd  %k6,0x390(%rsp)
 1f7f77d:	movzwl %ax,%r14d
 1f7f781:	movzwl %r13w,%r13d
 1f7f785:	xor    %ebp,%ebp
 1f7f787:	mov    0x80(%rsp),%rax
 1f7f78f:	lea    (%rax,%r15,4),%rbx
 1f7f793:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7f7a0:	xor    %r12d,%r12d
 1f7f7a3:	tzcnt  %r14d,%r12d
 1f7f7a8:	xor    %edx,%edx
 1f7f7aa:	mov    (%rbx,%r12,4),%esi
 1f7f7ae:	vzeroupper
 1f7f7b1:	call   1f93910 <node_tests_window_line>
 1f7f7b6:	mov    0x8(%rsp),%rdi
 1f7f7bb:	mov    $0x1,%ecx
 1f7f7c0:	test   $0x2,%al
 1f7f7c2:	shlx   %r12d,%ecx,%eax
 1f7f7c7:	cmove  %ebp,%eax
 1f7f7ca:	or     %eax,%r13d
 1f7f7cd:	blsr   %r14d,%r14d
 1f7f7d2:	jne    1f7f7a0 <node_facts_window_run+0x23d0>
 1f7f7d4:	vpbroadcastd -0x19ae872(%rip),%zmm13        # 5d0f6c <.LCPI3_5>
 1f7f7de:	vpbroadcastb -0x1ac8aa7(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f7e7:	vpbroadcastb -0x1ac8aaf(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f7f0:	vpbroadcastd -0x19ae886(%rip),%zmm16        # 5d0f74 <.LCPI3_11>
 1f7f7fa:	vpbroadcastd -0x19ae888(%rip),%zmm17        # 5d0f7c <.LCPI3_13>
 1f7f804:	vmovdqa64 0x220(%rsp),%xmm19
 1f7f80c:	vmovdqu64 0x4d0(%rsp),%zmm12
 1f7f817:	vmovdqu64 0x3d0(%rsp),%zmm20
 1f7f822:	vmovdqu64 0x490(%rsp),%zmm18
 1f7f82d:	vmovdqu64 0x2d0(%rsp),%zmm21
 1f7f838:	vmovdqu64 0x450(%rsp),%zmm22
 1f7f843:	vmovdqu64 0x5b0(%rsp),%zmm23
 1f7f84e:	vmovdqa64 0x570(%rsp),%xmm24
 1f7f856:	vmovdqu64 0x530(%rsp),%zmm7
 1f7f861:	vmovdqu 0x5f0(%rsp),%ymm5
 1f7f86a:	vmovdqu64 0x660(%rsp),%zmm4
 1f7f875:	mov    (%rsp),%r11
 1f7f879:	mov    0x48(%rsp),%r9
 1f7f87e:	mov    0x38(%rsp),%r12
 1f7f883:	mov    0x28(%rsp),%rsi
 1f7f888:	mov    0x20(%rsp),%r8
 1f7f88d:	mov    0x90(%rsp),%r14
 1f7f895:	kmovd  0x390(%rsp),%k6
 1f7f89f:	mov    0x310(%rsp),%rbp
 1f7f8a7:	kmovw  0x350(%rsp),%k7
 1f7f8b0:	vpsrld $0x2,%zmm20,%zmm0
 1f7f8b7:	vpandd -0x19ae941(%rip){1to16},%zmm0,%zmm2        # 5d0f80 <.LCPI3_14>
 1f7f8c1:	vpbroadcastd -0x19ae947(%rip),%zmm0        # 5d0f84 <.LCPI3_15>
 1f7f8cb:	vptestmd -0x19ae94d(%rip){1to16},%zmm20,%k3        # 5d0f88 <.LCPI3_16>
 1f7f8d5:	vmovdqu64 0x290(%rsp),%zmm1
 1f7f8e0:	vptestnmd %zmm4,%zmm4,%k1
 1f7f8e6:	vpbroadcastd -0x19ae95c(%rip),%zmm6        # 5d0f94 <.LCPI3_21>
 1f7f8f0:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7f8f7:	kmovd  %r13d,%k4
 1f7f8fc:	vpsrld $0x10,%zmm20,%zmm9
 1f7f903:	vpbroadcastb -0x1ac8bca(%rip),%xmm8        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7f90c:	vpbroadcastb -0x1ac8bd2(%rip),%xmm11        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7f915:	kmovw  %k1,%eax
 1f7f919:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7f91f:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7f926:	vmovdqu64 0x1e0(%rsp),%zmm0
 1f7f931:	korw   %k1,%k3,%k3
 1f7f935:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7f93c:	vpandd -0x19ae98e(%rip){1to16},%zmm21,%zmm5        # 5d0fb8 <.LCPI3_79>
 1f7f946:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7f94c:	vpbroadcastb -0x1ac8c11(%rip),%xmm7        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7f955:	vinserti64x4 $0x1,0x160(%rsp),%zmm0,%zmm0
 1f7f95e:	kmovw  %k0,%ecx
 1f7f962:	korw   %k2,%k3,%k2
 1f7f966:	vpaddd -0x19ae9e0(%rip){1to16},%zmm5,%zmm5        # 5d0f90 <.LCPI3_20>
 1f7f970:	andn   %ecx,%eax,%eax
 1f7f975:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7f97b:	kmovd  %eax,%k3
 1f7f97f:	shr    $0x8,%eax
 1f7f982:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7f988:	kmovd  %eax,%k3
 1f7f98c:	vmovdqu8 %xmm14,%xmm4{%k2}{z}
 1f7f992:	vpcmpltud %zmm6,%zmm5,%k2
 1f7f999:	vpslld $0x1f,%zmm5,%zmm5
 1f7f9a0:	vpxor  %xmm6,%xmm6,%xmm6
 1f7f9a4:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7f9aa:	vptestmd -0x19aea28(%rip){1to16},%zmm23,%k3        # 5d0f8c <.LCPI3_17>
 1f7f9b4:	vpandd %zmm17,%zmm23,%zmm3
 1f7f9ba:	vptestnmd %zmm3,%zmm3,%k0
 1f7f9c0:	kandd  %k6,%k0,%k0
 1f7f9c5:	korw   %k3,%k4,%k3
 1f7f9c9:	kandd  %k2,%k0,%k4
 1f7f9ce:	vpcmpeqd %zmm16,%zmm2,%k2{%k4}
 1f7f9d4:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7f9da:	vmovdqu8 -0x19b7ca4(%rip),%xmm2{%k4}        # 5c7d40 <.LCPI3_25>
 1f7f9e4:	knotw  %k2,%k0
 1f7f9e8:	kandd  %k0,%k4,%k5
 1f7f9ed:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7f9f3:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7f9fa:	vpaddd %zmm5,%zmm9,%zmm10
 1f7fa00:	vpbroadcastb -0x1ac8cc4(%rip),%xmm5        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7fa09:	vmovdqu8 -0x19b7cc3(%rip),%xmm2{%k4}        # 5c7d50 <.LCPI3_26>
 1f7fa13:	vptestnmd %zmm10,%zmm10,%k4
 1f7fa19:	vpblendmb -0x19b7cb3(%rip),%xmm5,%xmm5{%k4}        # 5c7d70 <.LCPI3_28>
 1f7fa23:	vpcmpnleud -0x19aea96(%rip){1to16},%zmm10,%k4        # 5d0f98 <.LCPI3_22>
 1f7fa2e:	cmpb   $0x0,0xb90(%rdi)
 1f7fa35:	vmovdqu8 -0x19b7cbf(%rip),%xmm5{%k4}        # 5c7d80 <.LCPI3_29>
 1f7fa3f:	vpcmpnleud -0x19aeaae(%rip){1to16},%zmm10,%k4        # 5d0f9c <.LCPI3_23>
 1f7fa4a:	vmovdqu8 -0x19b7cc4(%rip),%xmm5{%k4}        # 5c7d90 <.LCPI3_30>
 1f7fa54:	vptestmd %zmm3,%zmm3,%k4
 1f7fa5a:	vpor   %xmm4,%xmm8,%xmm3
 1f7fa5e:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7fa64:	kmovw  0x1a0(%rsp),%k4
 1f7fa6d:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7fa73:	vpor   %xmm2,%xmm4,%xmm2
 1f7fa77:	vpord  -0x19aeac5(%rip){1to4},%xmm2,%xmm3        # 5d0fbc <.LCPI3_82>
 1f7fa81:	vpbroadcastb -0x1ac8d44(%rip),%xmm5        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7fa8a:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7fa90:	vpor   %xmm5,%xmm2,%xmm3
 1f7fa94:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7fa9a:	vpmovdb %zmm20,%xmm3
 1f7faa0:	kmovw  0x120(%rsp),%k3
 1f7faa9:	vpor   %xmm3,%xmm11,%xmm4
 1f7faad:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7fab3:	vptestmd -0x19aeb1d(%rip){1to16},%zmm12,%k3{%k7}        # 5d0fa0 <.LCPI3_32>
 1f7fabd:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7fac3:	vpor   %xmm5,%xmm4,%xmm6
 1f7fac7:	vpsrld $0xb,%zmm23,%zmm7
 1f7face:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7fad4:	vpandd -0x19aeb1e(%rip){1to4},%xmm24,%xmm4        # 5d0fc0 <.LCPI3_84>
 1f7fade:	vptestmd -0x19aeb44(%rip){1to16},%zmm23,%k1        # 5d0fa4 <.LCPI3_33>
 1f7fae8:	vpmovdb %zmm7,%xmm7
 1f7faee:	vpand  %xmm7,%xmm8,%xmm7
 1f7faf2:	vpmovdb %zmm21,%xmm8
 1f7faf8:	vpor   %xmm4,%xmm15,%xmm5
 1f7fafc:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7fb02:	vpmovdb %zmm23,%xmm5
 1f7fb08:	vgf2p8affineqb $0x0,-0x19b1583(%rip){1to2},%xmm5,%xmm5        # 5ce590 <.LCPI3_85>
 1f7fb13:	vpternlogq $0xf8,%xmm11,%xmm5,%xmm4
 1f7fb1a:	vpsrld $0x8,%zmm21,%zmm11
 1f7fb21:	vpor   %xmm4,%xmm14,%xmm5
 1f7fb25:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7fb2b:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7fb32:	vpsrld $0x10,%zmm21,%zmm6
 1f7fb39:	vpmovdb %zmm11,%xmm7
 1f7fb3f:	vinserti32x4 $0x3,%xmm18,%zmm22,%zmm5{%k6}{z}
 1f7fb46:	vpmovdb %zmm6,%xmm6
 1f7fb4c:	je     1f7fc41 <node_facts_window_run+0x2871>
 1f7fb52:	vmovdqa64 -0x1ac935c(%rip),%zmm18        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7fb5c:	vptestmd %zmm9,%zmm9,%k1{%k2}
 1f7fb62:	add    %r8,%rbp
 1f7fb65:	vpxor  %xmm11,%xmm11,%xmm11
 1f7fb6a:	vpxor  %xmm12,%xmm12,%xmm12
 1f7fb6f:	vpcmpneqd -0x19aebd2(%rip){1to16},%zmm9,%k0{%k1}        # 5d0fa8 <.LCPI3_38>
 1f7fb7a:	vmovdqa %xmm6,%xmm9
 1f7fb7e:	vpternlogq $0xfe,%xmm8,%xmm3,%xmm9
 1f7fb85:	kmovq  %k1,%k2
 1f7fb8a:	kmovw  %k1,%eax
 1f7fb8e:	popcnt %eax,%ecx
 1f7fb92:	vpgatherdd 0x10(%rbp,%zmm18,1),%zmm11{%k2}
 1f7fb9a:	kmovq  %k1,%k2
 1f7fb9f:	vpcmpnleud -0x19aebfe(%rip){1to16},%zmm11,%k3        # 5d0fac <.LCPI3_39>
 1f7fbaa:	vpgatherdd 0x14(%rbp,%zmm18,1),%zmm12{%k2}
 1f7fbb2:	add    %rcx,0x30(%rsp)
 1f7fbb7:	mov    0x10(%rsp),%r10
 1f7fbbc:	vpcmpeqd %zmm10,%zmm11,%k2
 1f7fbc2:	vmovdqa64 %xmm19,%xmm10
 1f7fbc8:	vpternlogq $0xfe,%xmm7,%xmm9,%xmm10
 1f7fbcf:	vptestnmd %zmm12,%zmm12,%k2{%k2}
 1f7fbd5:	vptestmd %zmm12,%zmm12,%k4
 1f7fbdb:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm10
 1f7fbe2:	korw   %k4,%k3,%k3
 1f7fbe6:	kandw  %k2,%k0,%k2
 1f7fbea:	knotw  %k0,%k0
 1f7fbee:	kandd  %k1,%k0,%k0
 1f7fbf3:	kandw  %k0,%k3,%k0
 1f7fbf7:	korw   %k0,%k2,%k2
 1f7fbfb:	vptestnmd %zmm13,%zmm20,%k0{%k2}
 1f7fc01:	kandw  %k0,%k1,%k0
 1f7fc05:	knotd  %k6,%k1
 1f7fc0a:	kmovd  %k0,%ecx
 1f7fc0e:	vptestmb %xmm10,%xmm10,%k0{%k1}
 1f7fc14:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7fc1a:	andn   %eax,%ecx,%eax
 1f7fc1f:	popcnt %eax,%eax
 1f7fc23:	kmovw  %k0,%ecx
 1f7fc27:	popcnt %ecx,%ecx
 1f7fc2b:	kmovw  %k1,%edx
 1f7fc2f:	popcnt %edx,%edx
 1f7fc33:	add    %rdx,%r10
 1f7fc36:	add    %rax,%r10
 1f7fc39:	add    %rcx,%r10
 1f7fc3c:	mov    %r10,0x10(%rsp)
 1f7fc41:	mov    0x18(%rsp),%rbp
 1f7fc46:	jmp    1f7f367 <node_facts_window_run+0x1f97>
 1f7fc4b:	kandw  %k0,%k7,%k0
 1f7fc4f:	vmovdqa %xmm10,0x290(%rsp)
 1f7fc58:	vmovdqu64 %zmm11,0x310(%rsp)
 1f7fc63:	vmovdqu64 %ymm19,0x220(%rsp)
 1f7fc6b:	vmovdqu64 %zmm20,0x4d0(%rsp)
 1f7fc76:	vmovdqu64 %ymm21,0x3d0(%rsp)
 1f7fc81:	vmovdqu64 %zmm7,0x490(%rsp)
 1f7fc8c:	vmovdqu64 %ymm18,0x2d0(%rsp)
 1f7fc97:	vmovdqu64 %zmm22,0x450(%rsp)
 1f7fca2:	vmovdqu64 %ymm23,0x5b0(%rsp)
 1f7fcad:	vmovdqu64 %zmm5,0x570(%rsp)
 1f7fcb8:	vmovdqu %ymm6,0x530(%rsp)
 1f7fcc1:	vmovdqu64 %zmm24,0x5f0(%rsp)
 1f7fccc:	vmovdqu64 %ymm25,0x660(%rsp)
 1f7fcd4:	vmovdqu64 %zmm4,0x720(%rsp)
 1f7fcdf:	vmovdqu64 %ymm26,0x430(%rsp)
 1f7fcea:	vmovdqu64 %zmm27,0x6e0(%rsp)
 1f7fcf5:	vmovdqu64 %ymm28,0x410(%rsp)
 1f7fd00:	vmovdqu64 %zmm0,0x7c0(%rsp)
 1f7fd08:	kmovd  %k6,0x390(%rsp)
 1f7fd12:	kmovw  %k7,0x350(%rsp)
 1f7fd1b:	kmovd  %k0,%eax
 1f7fd1f:	movzwl %ax,%eax
 1f7fd22:	jmp    1f7fed0 <node_facts_window_run+0x2b00>
 1f7fd27:	mov    0x40(%rsp),%rsi
 1f7fd2c:	mov    (%r12,%r13,4),%r9d
 1f7fd30:	mov    0xb48(%rdi),%rdx
 1f7fd37:	shl    $0x6,%rax
 1f7fd3b:	mov    %r8b,0x160(%rsp)
 1f7fd43:	mov    0x20(%r11),%rcx
 1f7fd47:	cmpb   $0x1,(%rdx,%r9,1)
 1f7fd4c:	mov    %r9,0x1e0(%rsp)
 1f7fd54:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7fd59:	adc    $0x0,%rsi
 1f7fd5d:	and    $0x1,%edx
 1f7fd60:	mov    %rsi,0x40(%rsp)
 1f7fd65:	mov    0x80(%rsp),%rbx
 1f7fd6d:	mov    (%rbx,%r13,4),%esi
 1f7fd71:	vzeroupper
 1f7fd74:	call   1f93910 <node_tests_window_line>
 1f7fd79:	mov    %al,0x1a0(%rsp)
 1f7fd80:	mov    (%rbx,%r13,4),%esi
 1f7fd84:	mov    0x8(%rsp),%rdi
 1f7fd89:	call   1f93a60 <node_tests_window_returns>
 1f7fd8e:	mov    0x8(%rsp),%rdi
 1f7fd93:	or     0x160(%rsp),%al
 1f7fd9a:	mov    0x1e0(%rsp),%rdx
 1f7fda2:	vpbroadcastd -0x19aee40(%rip),%zmm13        # 5d0f6c <.LCPI3_5>
 1f7fdac:	vpbroadcastb -0x1ac9075(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7fdb5:	vpbroadcastb -0x1ac907d(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7fdbe:	vpbroadcastd -0x19aee54(%rip),%zmm16        # 5d0f74 <.LCPI3_11>
 1f7fdc8:	vpbroadcastd -0x19aee56(%rip),%zmm17        # 5d0f7c <.LCPI3_13>
 1f7fdd2:	vmovdqa 0x290(%rsp),%xmm10
 1f7fddb:	vmovdqu64 0x310(%rsp),%zmm11
 1f7fde6:	vmovdqu64 0x220(%rsp),%ymm19
 1f7fdee:	vmovdqu64 0x4d0(%rsp),%zmm20
 1f7fdf9:	vmovdqu64 0x3d0(%rsp),%ymm21
 1f7fe04:	vmovdqu64 0x490(%rsp),%zmm7
 1f7fe0f:	vmovdqu64 0x2d0(%rsp),%ymm18
 1f7fe1a:	vmovdqu64 0x450(%rsp),%zmm22
 1f7fe25:	vmovdqu64 0x5b0(%rsp),%ymm23
 1f7fe30:	vmovdqu64 0x570(%rsp),%zmm5
 1f7fe3b:	vmovdqu 0x530(%rsp),%ymm6
 1f7fe44:	vmovdqu64 0x5f0(%rsp),%zmm24
 1f7fe4f:	vmovdqu64 0x660(%rsp),%ymm25
 1f7fe57:	vmovdqu64 0x720(%rsp),%zmm4
 1f7fe62:	vmovdqu64 0x430(%rsp),%ymm26
 1f7fe6d:	vmovdqu64 0x6e0(%rsp),%zmm27
 1f7fe78:	vmovdqu64 0x410(%rsp),%ymm28
 1f7fe83:	vmovdqu64 0x7c0(%rsp),%zmm0
 1f7fe8b:	mov    (%rsp),%r11
 1f7fe8f:	mov    0x48(%rsp),%r9
 1f7fe94:	mov    0x28(%rsp),%rsi
 1f7fe99:	mov    0x20(%rsp),%r8
 1f7fe9e:	kmovd  0x390(%rsp),%k6
 1f7fea8:	kmovw  0x350(%rsp),%k7
 1f7feb1:	or     0x1a0(%rsp),%al
 1f7feb8:	mov    0xb48(%rdi),%rcx
 1f7febf:	mov    %al,(%rcx,%rdx,1)
 1f7fec2:	mov    0x120(%rsp),%eax
 1f7fec9:	blsr   %eax,%eax
 1f7fece:	je     1f7ff3d <node_facts_window_run+0x2b6d>
 1f7fed0:	tzcnt  %eax,%r13d
 1f7fed5:	mov    %eax,0x120(%rsp)
 1f7fedc:	mov    0x60(%r11),%edx
 1f7fee0:	add    %r15,%r13
 1f7fee3:	mov    %r13,%rcx
 1f7fee6:	shl    $0x6,%rcx
 1f7feea:	mov    (%r8,%rcx,1),%eax
 1f7feee:	mov    0xc(%r8,%rcx,1),%ecx
 1f7fef3:	mov    $0x1,%r8b
 1f7fef6:	shr    $0x3,%eax
 1f7fef9:	cmp    %edx,%eax
 1f7fefb:	cmovae %edx,%eax
 1f7fefe:	test   %rcx,%rcx
 1f7ff01:	je     1f7fd27 <node_facts_window_run+0x2957>
 1f7ff07:	mov    0x78(%rsp),%rdx
 1f7ff0c:	mov    0x40(%rsp),%rsi
 1f7ff11:	cmp    0x3b8(%rdx),%ecx
 1f7ff17:	jae    1f7fd2c <node_facts_window_run+0x295c>
 1f7ff1d:	mov    0x78(%rsp),%rdx
 1f7ff22:	mov    0x3a8(%rdx),%rdx
 1f7ff29:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7ff2d:	setne  %r8b
 1f7ff31:	shl    $0x5,%r8b
 1f7ff35:	inc    %r8b
 1f7ff38:	jmp    1f7fd2c <node_facts_window_run+0x295c>
 1f7ff3d:	mov    0xb48(%rdi),%rax
 1f7ff44:	kmovq  %k7,%k1
 1f7ff49:	vpxor  %xmm12,%xmm12,%xmm12
 1f7ff4e:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7ff55:	jmp    1f7f511 <node_facts_window_run+0x2141>
 1f7ff5a:	test   %eax,%eax
 1f7ff5c:	je     1f807b5 <node_facts_window_run+0x33e5>
 1f7ff62:	vpbroadcastd -0x19af000(%rip),%zmm6        # 5d0f6c <.LCPI3_5>
 1f7ff6c:	vpbroadcastb -0x1ac9233(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7ff75:	vpbroadcastd -0x19af00b(%rip),%zmm8        # 5d0f74 <.LCPI3_11>
 1f7ff7f:	vpbroadcastd -0x19af00d(%rip),%zmm9        # 5d0f7c <.LCPI3_13>
 1f7ff89:	lea    0x69454(%rbp),%rcx
 1f7ff90:	lea    0x422c(%rbp),%r14
 1f7ff97:	mov    %eax,%r10d
 1f7ff9a:	xor    %r15d,%r15d
 1f7ff9d:	mov    %rcx,0x4d0(%rsp)
 1f7ffa5:	movq   $0x0,0x40(%rsp)
 1f7ffae:	movq   $0x0,0x30(%rsp)
 1f7ffb7:	movq   $0x0,0x10(%rsp)
 1f7ffc0:	mov    %r10,0x3d0(%rsp)
 1f7ffc8:	mov    %r14,0x490(%rsp)
 1f7ffd0:	jmp    1f8000c <node_facts_window_run+0x2c3c>
 1f7ffd2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7ffe0:	vpxor  %xmm11,%xmm11,%xmm11
 1f7ffe5:	mov    0xb10(%rdi),%rax
 1f7ffec:	vmovdqu %xmm11,(%rax,%r15,1)
 1f7fff2:	mov    0xb18(%rdi),%rax
 1f7fff9:	vmovdqu %xmm0,(%rax,%r15,1)
 1f7ffff:	add    $0x10,%r15
 1f80003:	cmp    %r10,%r15
 1f80006:	jae    1f807d0 <node_facts_window_run+0x3400>
 1f8000c:	vpxor  %xmm0,%xmm0,%xmm0
 1f80010:	cmp    %rsi,%r15
 1f80013:	jae    1f7ffe0 <node_facts_window_run+0x2c10>
 1f80015:	mov    %esi,%eax
 1f80017:	sub    %r15d,%eax
 1f8001a:	mov    $0x10,%ecx
 1f8001f:	mov    $0xffffffff,%edx
 1f80024:	mov    %r15,%rbp
 1f80027:	cmp    $0x10,%eax
 1f8002a:	cmovae %ecx,%eax
 1f8002d:	mov    0x9b8(%r11),%rcx
 1f80034:	shl    $0x6,%rbp
 1f80038:	shlx   %eax,%edx,%eax
 1f8003d:	vmovdqu 0x100(%r8,%rbp,1),%ymm2
 1f80047:	vmovdqu 0x180(%r8,%rbp,1),%ymm3
 1f80051:	vmovdqu (%r8,%rbp,1),%ymm0
 1f80057:	vmovdqu 0x80(%r8,%rbp,1),%ymm1
 1f80061:	not    %eax
 1f80063:	vinserti64x4 $0x1,0x140(%r8,%rbp,1),%zmm2,%zmm5
 1f8006c:	vinserti64x4 $0x1,0x1c0(%r8,%rbp,1),%zmm3,%zmm2
 1f80075:	vinserti64x4 $0x1,0x40(%r8,%rbp,1),%zmm0,%zmm4
 1f8007e:	vmovdqu 0x200(%r8,%rbp,1),%ymm0
 1f80088:	vinserti64x4 $0x1,0xc0(%r8,%rbp,1),%zmm1,%zmm12
 1f80091:	kmovd  %eax,%k1
 1f80095:	vinserti64x4 $0x1,0x240(%r8,%rbp,1),%zmm0,%zmm11
 1f8009e:	vmovdqu 0x280(%r8,%rbp,1),%ymm0
 1f800a8:	mov    0xb48(%rdi),%rax
 1f800af:	vinserti64x4 $0x1,0x2c0(%r8,%rbp,1),%zmm0,%zmm14
 1f800b8:	vmovdqu 0x300(%r8,%rbp,1),%ymm0
 1f800c2:	vmovdqu8 (%rcx,%r15,1),%xmm10{%k1}{z}
 1f800c9:	mov    0x4d0(%rsp),%rcx
 1f800d1:	vinserti64x4 $0x1,0x340(%r8,%rbp,1),%zmm0,%zmm13
 1f800da:	vmovdqu 0x380(%r8,%rbp,1),%ymm0
 1f800e4:	vinserti64x4 $0x1,0x3c0(%r8,%rbp,1),%zmm0,%zmm15
 1f800ed:	vmovdqu8 (%rcx,%r15,1),%xmm3{%k1}{z}
 1f800f4:	vptestmb %xmm10,%xmm10,%k2
 1f800fa:	vpxor  %xmm0,%xmm0,%xmm0
 1f800fe:	vpcmpeqb %xmm7,%xmm3,%k3{%k2}
 1f80104:	vmovdqu32 (%r12,%r15,4),%zmm1{%k3}{z}
 1f8010b:	kmovq  %k3,%k1
 1f80110:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f80117:	vptestnmd %zmm8,%zmm0,%k0
 1f8011d:	ktestw %k0,%k3
 1f80121:	jne    1f805c3 <node_facts_window_run+0x31f3>
 1f80127:	vmovdqa64 -0x1ac99f1(%rip),%zmm1        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f80131:	kmovd  %k2,%edx
 1f80135:	vpermt2d %zmm12,%zmm1,%zmm4
 1f8013b:	vpermt2d %zmm2,%zmm1,%zmm5
 1f80141:	vpermt2d %zmm14,%zmm1,%zmm11
 1f80147:	vpermt2d %zmm15,%zmm1,%zmm13
 1f8014d:	vshufi64x2 $0x44,%zmm13,%zmm11,%zmm2
 1f80154:	vshufi64x2 $0x44,%zmm5,%zmm4,%zmm1
 1f8015b:	vshufi64x2 $0xee,%zmm5,%zmm4,%zmm14
 1f80162:	vshufi64x2 $0xee,%zmm13,%zmm11,%zmm13
 1f80169:	vshufi32x4 $0x88,%zmm2,%zmm1,%zmm4{%k2}{z}
 1f80170:	vshufi32x4 $0xdd,%zmm2,%zmm1,%zmm5{%k2}{z}
 1f80177:	vshufi32x4 $0xdd,%zmm13,%zmm14,%zmm12{%k2}{z}
 1f8017e:	vpsrld $0x19,%zmm4,%zmm1
 1f80185:	vpandd -0x19af227(%rip){1to16},%zmm1,%zmm1        # 5d0f68 <.LCPI3_4>
 1f8018f:	vpsrld $0x18,%zmm4,%zmm2
 1f80196:	vpternlogd $0xec,%zmm6,%zmm1,%zmm2
 1f8019d:	vpandd -0x19af1f3(%rip){1to16},%zmm4,%zmm1        # 5d0fb4 <.LCPI3_76>
 1f801a7:	vpmovdb %zmm2,%xmm11
 1f801ad:	vpbroadcastb -0x1ac9476(%rip),%xmm2        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f801b6:	vpcmpeqd -0x19af250(%rip){1to16},%zmm1,%k1{%k2}        # 5d0f70 <.LCPI3_7>
 1f801c0:	vpor   %xmm2,%xmm11,%xmm1
 1f801c4:	vpcmpeqb %xmm2,%xmm3,%k0{%k2}
 1f801ca:	kmovd  %k0,%eax
 1f801ce:	vmovdqu8 %xmm1,%xmm11{%k1}
 1f801d4:	vptestmd %zmm9,%zmm0,%k1
 1f801da:	korw   %k1,%k0,%k5
 1f801de:	vptestmd -0x19af270(%rip){1to16},%zmm0,%k0        # 5d0f78 <.LCPI3_12>
 1f801e8:	kmovd  %k0,%r13d
 1f801ec:	test   %ax,%ax
 1f801ef:	je     1f8033e <node_facts_window_run+0x2f6e>
 1f801f5:	lea    (%r14,%r15,4),%r14
 1f801f9:	movzwl %r13w,%r13d
 1f801fd:	movzwl %ax,%ebx
 1f80200:	vmovdqu64 %zmm13,0x220(%rsp)
 1f8020b:	vmovdqu64 %zmm14,0x310(%rsp)
 1f80216:	vmovdqu64 %zmm5,0x350(%rsp)
 1f80221:	vmovdqu64 %zmm4,0x390(%rsp)
 1f8022c:	kmovw  %k5,0x290(%rsp)
 1f80235:	vmovdqu64 %zmm12,0x160(%rsp)
 1f80240:	mov    %edx,0x1a0(%rsp)
 1f80247:	vmovdqa %xmm11,0x1e0(%rsp)
 1f80250:	vmovdqa %xmm10,0x120(%rsp)
 1f80259:	nopl   0x0(%rax)
 1f80260:	xor    %r12d,%r12d
 1f80263:	tzcnt  %ebx,%r12d
 1f80268:	xor    %edx,%edx
 1f8026a:	mov    (%r14,%r12,4),%esi
 1f8026e:	vzeroupper
 1f80271:	call   1f93910 <node_tests_window_line>
 1f80276:	mov    0x8(%rsp),%rdi
 1f8027b:	mov    $0x1,%edx
 1f80280:	xor    %ecx,%ecx
 1f80282:	test   $0x2,%al
 1f80284:	shlx   %r12d,%edx,%eax
 1f80289:	cmove  %ecx,%eax
 1f8028c:	or     %eax,%r13d
 1f8028f:	blsr   %ebx,%ebx
 1f80294:	jne    1f80260 <node_facts_window_run+0x2e90>
 1f80296:	vpbroadcastd -0x19af334(%rip),%zmm6        # 5d0f6c <.LCPI3_5>
 1f802a0:	vpbroadcastb -0x1ac9567(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f802a9:	vpbroadcastd -0x19af33f(%rip),%zmm8        # 5d0f74 <.LCPI3_11>
 1f802b3:	vpbroadcastd -0x19af341(%rip),%zmm9        # 5d0f7c <.LCPI3_13>
 1f802bd:	vmovdqa 0x120(%rsp),%xmm10
 1f802c6:	vmovdqa 0x1e0(%rsp),%xmm11
 1f802cf:	vmovdqu64 0x160(%rsp),%zmm12
 1f802da:	vmovdqu64 0x390(%rsp),%zmm4
 1f802e5:	vmovdqu64 0x350(%rsp),%zmm5
 1f802f0:	vmovdqu64 0x310(%rsp),%zmm14
 1f802fb:	vmovdqu64 0x220(%rsp),%zmm13
 1f80306:	mov    (%rsp),%r11
 1f8030a:	mov    0x48(%rsp),%r9
 1f8030f:	mov    0x38(%rsp),%r12
 1f80314:	mov    0x28(%rsp),%rsi
 1f80319:	mov    0x20(%rsp),%r8
 1f8031e:	mov    0x490(%rsp),%r14
 1f80326:	mov    0x3d0(%rsp),%r10
 1f8032e:	mov    0x1a0(%rsp),%edx
 1f80335:	kmovw  0x290(%rsp),%k5
 1f8033e:	vpsrld $0x2,%zmm12,%zmm2
 1f80345:	vpandd -0x19af3cf(%rip){1to16},%zmm2,%zmm2        # 5d0f80 <.LCPI3_14>
 1f8034f:	vptestmd -0x19af3d1(%rip){1to16},%zmm12,%k2        # 5d0f88 <.LCPI3_16>
 1f80359:	vshufi64x2 $0x88,%zmm13,%zmm14,%zmm0
 1f80360:	vptestnmb %xmm10,%xmm10,%k0
 1f80366:	vpsrld $0x1a,%zmm4,%zmm1
 1f8036d:	vpandd -0x19af3bf(%rip){1to16},%zmm4,%zmm4        # 5d0fb8 <.LCPI3_79>
 1f80377:	kmovd  %r13d,%k3
 1f8037c:	vpcmpneqd -0x19af403(%rip){1to16},%zmm2,%k1        # 5d0f84 <.LCPI3_15>
 1f80387:	vpaddd -0x19af401(%rip){1to16},%zmm4,%zmm4        # 5d0f90 <.LCPI3_20>
 1f80391:	korw   %k1,%k2,%k1
 1f80395:	vptestnmd %zmm0,%zmm0,%k2
 1f8039b:	vpandd %zmm9,%zmm5,%zmm0
 1f803a1:	korw   %k2,%k0,%k0
 1f803a5:	vptestmd -0x19af423(%rip){1to16},%zmm5,%k2        # 5d0f8c <.LCPI3_17>
 1f803af:	vpbroadcastd -0x19af425(%rip),%zmm5        # 5d0f94 <.LCPI3_21>
 1f803b9:	korw   %k1,%k0,%k1
 1f803bd:	vptestnmd %zmm0,%zmm0,%k0
 1f803c3:	kmovd  %k0,%eax
 1f803c7:	vptestmd %zmm2,%zmm2,%k1{%k1}
 1f803cd:	vmovdqu8 -0x19b86e7(%rip),%xmm3{%k1}{z}        # 5c7cf0 <.LCPI3_8>
 1f803d7:	vpcmpeqd %zmm5,%zmm1,%k4
 1f803dd:	vpcmpltud %zmm5,%zmm4,%k0
 1f803e4:	korw   %k2,%k3,%k1
 1f803e8:	vpslld $0x1f,%zmm4,%zmm1
 1f803ef:	vpbroadcastb -0x1ac96b3(%rip),%xmm4        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f803f8:	vptestmb %xmm10,%xmm10,%k4{%k4}
 1f803fe:	kmovd  %k0,%ecx
 1f80402:	and    %eax,%ecx
 1f80404:	mov    %edx,%eax
 1f80406:	and    %ecx,%eax
 1f80408:	vmovdqu8 -0x19b86e2(%rip),%xmm5{%k4}{z}        # 5c7d30 <.LCPI3_24>
 1f80412:	kmovd  %eax,%k3
 1f80416:	vpcmpeqd %zmm8,%zmm2,%k2{%k3}
 1f8041c:	vpxor  %xmm2,%xmm2,%xmm2
 1f80420:	knotw  %k2,%k0
 1f80424:	kmovd  %k0,%ecx
 1f80428:	and    %eax,%ecx
 1f8042a:	vmovdqu8 -0x19b86f4(%rip),%xmm5{%k3}        # 5c7d40 <.LCPI3_25>
 1f80434:	kmovd  %ecx,%k3
 1f80438:	vpcmpgtd %zmm1,%zmm2,%k3{%k3}
 1f8043e:	vpsrld $0x10,%zmm12,%zmm1
 1f80445:	vpternlogd $0xff,%zmm2,%zmm2,%zmm2
 1f8044c:	vpaddd %zmm2,%zmm1,%zmm2
 1f80452:	vmovdqu8 -0x19b870c(%rip),%xmm5{%k3}        # 5c7d50 <.LCPI3_26>
 1f8045c:	vptestnmd %zmm2,%zmm2,%k3
 1f80462:	vpblendmb -0x19b86fc(%rip),%xmm4,%xmm4{%k3}        # 5c7d70 <.LCPI3_28>
 1f8046c:	vpcmpnleud -0x19af4df(%rip){1to16},%zmm2,%k3        # 5d0f98 <.LCPI3_22>
 1f80477:	cmpb   $0x0,0xb90(%rdi)
 1f8047e:	vmovdqu8 -0x19b8708(%rip),%xmm4{%k3}        # 5c7d80 <.LCPI3_29>
 1f80488:	vpcmpnleud -0x19af4f7(%rip){1to16},%zmm2,%k3        # 5d0f9c <.LCPI3_23>
 1f80493:	vmovdqu8 -0x19b870d(%rip),%xmm4{%k3}        # 5c7d90 <.LCPI3_30>
 1f8049d:	vptestmd %zmm0,%zmm0,%k3
 1f804a3:	vpor   %xmm7,%xmm3,%xmm0
 1f804a7:	vmovdqu8 %xmm0,%xmm3{%k3}
 1f804ad:	vmovdqu8 %xmm4,%xmm5{%k2}
 1f804b3:	vpor   %xmm5,%xmm3,%xmm0
 1f804b7:	vpord  -0x19af505(%rip){1to4},%xmm0,%xmm3        # 5d0fbc <.LCPI3_82>
 1f804c1:	vmovdqu8 %xmm3,%xmm0{%k5}
 1f804c7:	vpord  -0x19af50d(%rip){1to4},%xmm0,%xmm3        # 5d0fc4 <.LCPI3_86>
 1f804d1:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f804d7:	vpsrld $0xc,%zmm12,%zmm3
 1f804de:	vpmovdb %zmm3,%xmm3
 1f804e4:	vpternlogd $0xf8,-0x19af527(%rip){1to4},%xmm3,%xmm11        # 5d0fc8 <.LCPI3_87>
 1f804ef:	je     1f805b9 <node_facts_window_run+0x31e9>
 1f804f5:	vmovdqa64 -0x1ac9cff(%rip),%zmm5        # 4b6800 <abi_test_hex.digits+0xb480>
 1f804ff:	vptestmd %zmm1,%zmm1,%k1{%k2}
 1f80505:	add    %r8,%rbp
 1f80508:	vpxor  %xmm3,%xmm3,%xmm3
 1f8050c:	vpxor  %xmm4,%xmm4,%xmm4
 1f80510:	vpcmpneqd -0x19af573(%rip){1to16},%zmm1,%k0{%k1}        # 5d0fa8 <.LCPI3_38>
 1f8051b:	vpor   %xmm0,%xmm11,%xmm1
 1f8051f:	kmovq  %k1,%k2
 1f80524:	kmovw  %k1,%eax
 1f80528:	popcnt %eax,%ecx
 1f8052c:	vpgatherdd 0x10(%rbp,%zmm5,1),%zmm3{%k2}
 1f80534:	kmovq  %k1,%k2
 1f80539:	vpcmpnleud -0x19af598(%rip){1to16},%zmm3,%k3        # 5d0fac <.LCPI3_39>
 1f80544:	vpgatherdd 0x14(%rbp,%zmm5,1),%zmm4{%k2}
 1f8054c:	add    %rcx,0x30(%rsp)
 1f80551:	mov    0x10(%rsp),%rbx
 1f80556:	vpcmpeqd %zmm2,%zmm3,%k2
 1f8055c:	vptestnmd %zmm4,%zmm4,%k2{%k2}
 1f80562:	vptestmd %zmm4,%zmm4,%k4
 1f80568:	korw   %k4,%k3,%k3
 1f8056c:	kandw  %k2,%k0,%k2
 1f80570:	knotw  %k0,%k0
 1f80574:	kandd  %k1,%k0,%k0
 1f80579:	kandw  %k0,%k3,%k0
 1f8057d:	korw   %k0,%k2,%k2
 1f80581:	vptestnmd %zmm6,%zmm12,%k0{%k2}
 1f80587:	kandw  %k0,%k1,%k0
 1f8058b:	kmovd  %k0,%ecx
 1f8058f:	vptestmb %xmm1,%xmm1,%k0
 1f80595:	andn   %eax,%ecx,%eax
 1f8059a:	kmovd  %k0,%ecx
 1f8059e:	andn   %ecx,%edx,%ecx
 1f805a3:	popcnt %eax,%eax
 1f805a7:	movzwl %cx,%ecx
 1f805aa:	add    %rax,%rbx
 1f805ad:	popcnt %ecx,%ecx
 1f805b1:	add    %rcx,%rbx
 1f805b4:	mov    %rbx,0x10(%rsp)
 1f805b9:	mov    0x18(%rsp),%rbp
 1f805be:	jmp    1f7ffe5 <node_facts_window_run+0x2c15>
 1f805c3:	vmovdqu64 %zmm1,0x530(%rsp)
 1f805ce:	vmovdqu64 %zmm15,0x5b0(%rsp)
 1f805d9:	vmovdqu64 %zmm14,0x450(%rsp)
 1f805e4:	vmovdqu64 %zmm13,0x2d0(%rsp)
 1f805ef:	vmovdqu64 %zmm2,0x220(%rsp)
 1f805fa:	vmovdqu64 %zmm12,0x310(%rsp)
 1f80605:	vmovdqu64 %zmm11,0x350(%rsp)
 1f80610:	vmovdqa %xmm3,0x390(%rsp)
 1f80619:	vmovdqu64 %zmm5,0x290(%rsp)
 1f80624:	kmovw  %k2,0x160(%rsp)
 1f8062d:	vmovdqu64 %zmm4,0x1a0(%rsp)
 1f80638:	vmovdqa %xmm10,0x120(%rsp)
 1f80641:	kmovw  %k3,0x570(%rsp)
 1f8064a:	kandw  %k0,%k3,%k0
 1f8064e:	mov    0x40(%rsp),%rbx
 1f80653:	kmovd  %k0,%eax
 1f80657:	movzwl %ax,%r13d
 1f8065b:	xor    %eax,%eax
 1f8065d:	tzcnt  %r13d,%eax
 1f80662:	mov    0x60(%r11),%edx
 1f80666:	mov    0x20(%r11),%rcx
 1f8066a:	add    %r15,%rax
 1f8066d:	mov    (%r12,%rax,4),%r9d
 1f80671:	mov    (%r14,%rax,4),%esi
 1f80675:	shl    $0x6,%rax
 1f80679:	mov    (%r8,%rax,1),%eax
 1f8067d:	mov    %r9,0x1e0(%rsp)
 1f80685:	shr    $0x3,%eax
 1f80688:	cmp    %edx,%eax
 1f8068a:	cmovae %edx,%eax
 1f8068d:	shl    $0x6,%rax
 1f80691:	mov    0x30(%rcx,%rax,1),%edx
 1f80695:	mov    0xb48(%rdi),%rax
 1f8069c:	cmpb   $0x1,(%rax,%r9,1)
 1f806a1:	adc    $0x0,%rbx
 1f806a5:	and    $0x1,%edx
 1f806a8:	vzeroupper
 1f806ab:	call   1f93910 <node_tests_window_line>
 1f806b0:	mov    0x8(%rsp),%rdi
 1f806b5:	mov    0x20(%rsp),%r8
 1f806ba:	mov    (%rsp),%r11
 1f806be:	mov    0x1e0(%rsp),%rdx
 1f806c6:	or     $0x1,%al
 1f806c8:	blsr   %r13d,%r13d
 1f806cd:	mov    0xb48(%rdi),%rcx
 1f806d4:	mov    %al,(%rcx,%rdx,1)
 1f806d7:	jne    1f8065b <node_facts_window_run+0x328b>
 1f806d9:	mov    %rbx,0x40(%rsp)
 1f806de:	mov    0xb48(%rdi),%rax
 1f806e5:	vpbroadcastd -0x19af783(%rip),%zmm6        # 5d0f6c <.LCPI3_5>
 1f806ef:	vpbroadcastb -0x1ac99b6(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f806f8:	vpbroadcastd -0x19af78e(%rip),%zmm8        # 5d0f74 <.LCPI3_11>
 1f80702:	vpbroadcastd -0x19af790(%rip),%zmm9        # 5d0f7c <.LCPI3_13>
 1f8070c:	vpxor  %xmm0,%xmm0,%xmm0
 1f80710:	vmovdqu64 0x530(%rsp),%zmm1
 1f8071b:	kmovw  0x570(%rsp),%k1
 1f80724:	vmovdqa 0x120(%rsp),%xmm10
 1f8072d:	vmovdqu64 0x1a0(%rsp),%zmm4
 1f80738:	vmovdqu64 0x290(%rsp),%zmm5
 1f80743:	vmovdqa 0x390(%rsp),%xmm3
 1f8074c:	vmovdqu64 0x350(%rsp),%zmm11
 1f80757:	vmovdqu64 0x310(%rsp),%zmm12
 1f80762:	vmovdqu64 0x220(%rsp),%zmm2
 1f8076d:	vmovdqu64 0x2d0(%rsp),%zmm13
 1f80778:	vmovdqu64 0x450(%rsp),%zmm14
 1f80783:	vmovdqu64 0x5b0(%rsp),%zmm15
 1f8078e:	mov    0x48(%rsp),%r9
 1f80793:	mov    0x28(%rsp),%rsi
 1f80798:	mov    0x3d0(%rsp),%r10
 1f807a0:	kmovw  0x160(%rsp),%k2
 1f807a9:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f807b0:	jmp    1f80127 <node_facts_window_run+0x2d57>
 1f807b5:	movq   $0x0,0x40(%rsp)
 1f807be:	movq   $0x0,0x30(%rsp)
 1f807c7:	movq   $0x0,0x10(%rsp)
 1f807d0:	mov    0x40(%rsp),%rax
 1f807d5:	mov    0x30(%rsp),%rcx
 1f807da:	lea    0x7e8(%r9),%rsi
 1f807e1:	add    %rax,0xa90(%r9)
 1f807e8:	mov    0xad0(%rdi),%rax
 1f807ef:	add    %rcx,0x868(%rax)
 1f807f6:	mov    0x10(%rsp),%rcx
 1f807fb:	mov    0xad0(%rdi),%rax
 1f80802:	add    %rcx,0x870(%rax)
 1f80809:	rdtsc
 1f8080b:	mov    0x8(%rbp),%ecx
 1f8080e:	cmpq   $0x0,0xc20(%r11)
 1f80816:	mov    %rax,0x720(%rsp)
 1f8081e:	mov    %rdx,0x430(%rsp)
 1f80826:	je     1f80f54 <node_facts_window_run+0x3b84>
 1f8082c:	cmpb   $0x1,0xd58(%r11)
 1f80834:	jne    1f80f54 <node_facts_window_run+0x3b84>
 1f8083a:	mov    0xad0(%rdi),%rdx
 1f80841:	cmpq   $0x0,0x1a0(%rdx)
 1f80849:	sete   %dl
 1f8084c:	test   %rcx,%rcx
 1f8084f:	je     1f8161f <node_facts_window_run+0x424f>
 1f80855:	vpbroadcastb %edx,%zmm1
 1f8085b:	vgf2p8affineqb $0x0,-0x19b22ce(%rip){1to8},%zmm1,%zmm1        # 5ce598 <.LCPI3_88>
 1f80866:	vmovdqu64 0x288(%rdi),%zmm0
 1f80870:	vbroadcasti32x4 -0x19b8a6a(%rip),%zmm2        # 5c7e10 <.LCPI3_89>
 1f8087a:	vmovdqa64 -0x1ac9fc4(%rip),%zmm7        # 4b68c0 <abi_test_hex.digits+0xb540>
 1f80884:	vbroadcasti32x4 -0x19b8a6e(%rip),%zmm8        # 5c7e20 <.LCPI3_90>
 1f8088e:	vbroadcasti32x4 -0x19b8a68(%rip),%zmm17        # 5c7e30 <.LCPI3_91>
 1f80898:	vbroadcasti32x4 -0x19b8a62(%rip),%zmm18        # 5c7e40 <.LCPI3_92>
 1f808a2:	vbroadcasti32x4 -0x19b8bac(%rip),%zmm20        # 5c7d00 <.LCPI3_9>
 1f808ac:	vbroadcasti32x4 -0x19b8a66(%rip),%zmm27        # 5c7e50 <.LCPI3_93>
 1f808b6:	vbroadcasti32x4 -0x19b8a60(%rip),%zmm28        # 5c7e60 <.LCPI3_94>
 1f808c0:	vmovdqa64 -0x1ac9c8a(%rip),%zmm29        # 4b6c40 <abi_test_hex.digits+0xb8c0>
 1f808ca:	vmovdqa64 -0x1ac9c54(%rip),%zmm30        # 4b6c80 <abi_test_hex.digits+0xb900>
 1f808d4:	mov    %rsi,0x28(%rsp)
 1f808d9:	movzbl 0x4c8(%rdi),%esi
 1f808e0:	mov    0xd60(%r11),%rax
 1f808e7:	mov    0xd78(%r11),%r8
 1f808ee:	xor    %r9d,%r9d
 1f808f1:	vpxord %xmm22,%xmm22,%xmm22
 1f808f7:	vpxor  %xmm5,%xmm5,%xmm5
 1f808fb:	vpxor  %xmm15,%xmm15,%xmm15
 1f80900:	xor    %edx,%edx
 1f80902:	vpxor  %xmm9,%xmm9,%xmm9
 1f80907:	vpxord %xmm25,%xmm25,%xmm25
 1f8090d:	neg    %rsi
 1f80910:	mov    %rax,0x10(%rsp)
 1f80915:	mov    %r8,0x20(%rsp)
 1f8091a:	movq   $0x0,0x38(%rsp)
 1f80923:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f80930:	mov    0xb10(%rdi),%r10
 1f80937:	vmovdqu64 0x2c(%rbp,%r9,1),%zmm4
 1f80942:	vmovdqa64 %zmm5,%zmm13
 1f80948:	vmovdqu64 0x108(%rdi),%zmm5
 1f80952:	vmovdqu64 0x88(%rdi),%zmm3
 1f8095c:	vmovdqu64 0x188(%rdi),%zmm19
 1f80966:	vmovdqu64 0x208(%rdi),%zmm21
 1f80970:	vmovdqu64 0x348(%rdi),%zmm26
 1f8097a:	vmovdqu64 0x3c8(%rdi),%zmm11
 1f80984:	vmovdqa64 %zmm25,%zmm6
 1f8098a:	vmovdqa64 %zmm22,%zmm25
 1f80990:	vmovdqu64 0x2c8(%rdi),%zmm22
 1f8099a:	mov    0x10(%rsp),%rax
 1f8099f:	vmovdqu64 (%r10,%r9,1),%zmm10
 1f809a6:	mov    0xb18(%rdi),%r10
 1f809ad:	vpermt2b 0x148(%rdi),%zmm4,%zmm5
 1f809b7:	vpermt2b 0xc8(%rdi),%zmm4,%zmm3
 1f809c1:	vpermt2b 0x248(%rdi),%zmm4,%zmm21
 1f809cb:	vpandq %zmm2,%zmm4,%zmm14
 1f809d1:	vpermt2b 0x1c8(%rdi),%zmm4,%zmm19
 1f809db:	vpermt2b 0x308(%rdi),%zmm4,%zmm22
 1f809e5:	vpermt2b 0x388(%rdi),%zmm4,%zmm26
 1f809ef:	vpermt2b 0x408(%rdi),%zmm4,%zmm11
 1f809f9:	vmovdqu64 (%r10,%r9,1),%zmm31
 1f80a00:	mov    0xb20(%rdi),%r10
 1f80a07:	vpsrlw $0x2,%zmm10,%zmm12
 1f80a0e:	vpsrlw $0x3,%zmm10,%zmm4
 1f80a15:	vpmovb2m %zmm3,%k0
 1f80a1b:	kmovq  %k0,%r11
 1f80a20:	vpternlogq $0xf8,-0x19b24eb(%rip){1to8},%zmm31,%zmm5        # 5ce540 <.LCPI3_42>
 1f80a2b:	vpternlogq $0xf8,-0x19b24ee(%rip){1to8},%zmm12,%zmm5        # 5ce548 <.LCPI3_43>
 1f80a36:	vpternlogq $0xf8,-0x19b24f1(%rip){1to8},%zmm4,%zmm5        # 5ce550 <.LCPI3_44>
 1f80a41:	vmovdqu64 %zmm5,(%r10,%r9,1)
 1f80a48:	vmovdqu64 0x6b554(%rbp,%r9,2),%zmm4
 1f80a53:	vmovdqu64 0x6b594(%rbp,%r9,2),%zmm16
 1f80a5e:	vmovdqu64 0x6d614(%rbp,%r9,2),%zmm23
 1f80a69:	vpmovuswb %zmm4,%ymm4
 1f80a6f:	vpmovuswb %zmm16,%ymm16
 1f80a75:	vpmovuswb %zmm23,%ymm23
 1f80a7b:	vinserti64x4 $0x1,%ymm16,%zmm4,%zmm4
 1f80a82:	vptestmb %zmm4,%zmm4,%k1
 1f80a88:	vpsubb %zmm4,%zmm7,%zmm16
 1f80a8e:	vpcmpltub %zmm4,%zmm7,%k4{%k1}
 1f80a95:	kmovq  %k1,%r10
 1f80a9a:	vpcmpnltub %zmm4,%zmm7,%k1
 1f80aa1:	vmovdqu64 0x6d5d4(%rbp,%r9,2),%zmm4
 1f80aac:	kmovq  %k1,%r14
 1f80ab1:	and    %r10,%r14
 1f80ab4:	mov    0xb28(%rdi),%r10
 1f80abb:	kmovq  %r14,%k1
 1f80ac0:	vpermt2b %zmm22,%zmm16,%zmm25{%k1}{z}
 1f80ac6:	knotq  %k1,%k6
 1f80acb:	vpmovuswb %zmm4,%ymm4
 1f80ad1:	vptestmb %zmm26,%zmm25,%k5
 1f80ad7:	kmovq  %k5,%rbx
 1f80adc:	vinserti64x4 $0x1,%ymm23,%zmm4,%zmm24
 1f80ae3:	vmovdqa64 %zmm13,%zmm4
 1f80ae9:	vpermt2b %zmm5,%zmm16,%zmm4{%k1}{z}
 1f80aef:	vptestmb %zmm24,%zmm24,%k2
 1f80af5:	vpsubb %zmm24,%zmm7,%zmm23
 1f80afb:	vpcmpltub %zmm24,%zmm7,%k3{%k2}
 1f80b02:	vpcmpnltub %zmm24,%zmm7,%k2{%k2}
 1f80b09:	vpermt2b %zmm5,%zmm23,%zmm13{%k2}{z}
 1f80b0f:	vporq  %zmm4,%zmm13,%zmm24
 1f80b15:	vmovdqu64 %zmm24,(%r10,%r9,1)
 1f80b1c:	mov    %r9,%r10
 1f80b1f:	shr    $0x3,%r10
 1f80b23:	kortestq %k4,%k3
 1f80b28:	vpandq (%rax,%r9,1),%zmm1,%zmm25
 1f80b2f:	mov    0x20(%rsp),%rax
 1f80b34:	vpermt2b %zmm25,%zmm16,%zmm6
 1f80b3a:	vptestnmb %zmm6,%zmm6,%k5
 1f80b40:	korq   %k5,%k6,%k5
 1f80b45:	vpcmpeqb %zmm8,%zmm14,%k5{%k5}
 1f80b4b:	kmovq  %k5,(%rax,%r10,1)
 1f80b51:	jne    1f80dff <node_facts_window_run+0x3a2f>
 1f80b57:	vmovdqa64 %zmm15,%zmm6
 1f80b5d:	vpermi2b %zmm31,%zmm15,%zmm23{%k2}{z}
 1f80b63:	vpermt2b %zmm31,%zmm16,%zmm6{%k1}{z}
 1f80b69:	vpternlogq $0xe0,%zmm2,%zmm31,%zmm21
 1f80b70:	vpandq %zmm19,%zmm24,%zmm26
 1f80b76:	vpandd -0x19afbbc(%rip){1to16},%zmm10,%zmm19        # 5d0fc4 <.LCPI3_86>
 1f80b80:	mov    0x8(%rsp),%r8
 1f80b85:	mov    %edx,%edi
 1f80b87:	vpsrlw $0x3,%zmm6,%zmm15
 1f80b8e:	vpternlogq $0xe4,-0x19b2611(%rip){1to8},%zmm23,%zmm15        # 5ce588 <.LCPI3_53>
 1f80b99:	vpermb %zmm0,%zmm15,%zmm15
 1f80b9f:	vptestmb %zmm15,%zmm21,%k2
 1f80ba5:	vpandq %zmm17,%zmm6,%zmm21
 1f80bab:	vpandd -0x19afbf9(%rip){1to16},%zmm6,%zmm6        # 5d0fbc <.LCPI3_82>
 1f80bb5:	vmovdqa64 %zmm31,%zmm15
 1f80bbb:	vpcmpeqb %zmm18,%zmm21,%k3
 1f80bc1:	vpandq %zmm17,%zmm23,%zmm21
 1f80bc7:	kmovq  %k2,%r15
 1f80bcc:	vpcmpeqb -0x1aca296(%rip),%zmm26,%k2        # 4b6940 <abi_test_hex.digits+0xb5c0>
 1f80bd6:	vpcmpeqb %zmm18,%zmm21,%k4
 1f80bdc:	korq   %k4,%k3,%k3
 1f80be1:	vpcmpeqb -0x1aca1eb(%rip),%zmm14,%k3{%k3}        # 4b6a00 <abi_test_hex.digits+0xb680>
 1f80beb:	vpcmpeqb %zmm8,%zmm14,%k4
 1f80bf1:	kmovq  %k4,%rax
 1f80bf6:	vptestmb %zmm26,%zmm26,%k4
 1f80bfc:	and    %rsi,%rax
 1f80bff:	korq   %k4,%k0,%k0
 1f80c04:	vpternlogq $0xfe,%zmm6,%zmm26,%zmm19
 1f80c0b:	vpsllw $0x7,%zmm10,%zmm6
 1f80c12:	vptestnmb %zmm19,%zmm19,%k5
 1f80c18:	kmovq  %k2,%r12
 1f80c1d:	vpmovb2m %zmm6,%k2
 1f80c23:	vpbroadcastw %r9d,%zmm6
 1f80c29:	kmovq  %k5,%rbp
 1f80c2e:	vpcmpeqb -0x1aca0f8(%rip),%zmm14,%k5        # 4b6b40 <abi_test_hex.digits+0xb7c0>
 1f80c38:	andn   %r12,%r11,%r11
 1f80c3d:	knotq  %k3,%k3
 1f80c42:	kmovq  %k3,%r10
 1f80c47:	vptestmb %zmm20,%zmm10,%k3
 1f80c4d:	kmovq  %k3,%r13
 1f80c52:	and    %r15,%r10
 1f80c55:	and    %r13,%rax
 1f80c58:	mov    0xb30(%r8),%r13
 1f80c5f:	and    %r11,%r10
 1f80c62:	and    %rax,%rbp
 1f80c65:	and    %r14,%rbp
 1f80c68:	kmovq  %rbp,%k3
 1f80c6d:	vpmovm2b %k3,%zmm14
 1f80c73:	vpermt2b %zmm14,%zmm16,%zmm9
 1f80c79:	vptestmb -0x1aca103(%rip),%zmm10,%k3{%k4}        # 4b6b80 <abi_test_hex.digits+0xb800>
 1f80c83:	vpaddw %zmm10,%zmm10,%zmm16
 1f80c89:	vpandq %zmm3,%zmm10,%zmm10
 1f80c8f:	vptestmb %zmm27,%zmm4,%k4
 1f80c95:	vpaddw %zmm10,%zmm10,%zmm10
 1f80c9b:	vptestmb %zmm20,%zmm3,%k4{%k4}
 1f80ca1:	vptestmb %zmm9,%zmm9,%k1{%k1}
 1f80ca7:	vporq  %zmm30,%zmm6,%zmm9
 1f80cad:	vporq  %zmm29,%zmm6,%zmm6
 1f80cb3:	vptestmb %zmm27,%zmm13,%k4{%k4}
 1f80cb9:	kandq  %k3,%k5,%k3
 1f80cbe:	kandq  %k2,%k5,%k5
 1f80cc3:	kandq  %k1,%k5,%k1
 1f80cc8:	kshiftrq $0x20,%k1,%k5
 1f80cce:	vpcompressw %zmm6,%zmm6{%k1}{z}
 1f80cd4:	kmovd  %k1,%eax
 1f80cd8:	vptestmb %zmm11,%zmm24,%k1
 1f80cde:	vpandq -0x19b2790(%rip){1to8},%zmm16,%zmm11        # 5ce558 <.LCPI3_47>
 1f80ce8:	vpsllw $0x3,%zmm31,%zmm16
 1f80cef:	vpternlogq $0xf8,-0x19b279a(%rip){1to8},%zmm3,%zmm11        # 5ce560 <.LCPI3_48>
 1f80cfa:	vpcompressw %zmm9,%zmm9{%k5}{z}
 1f80d00:	kmovd  %k5,%r14d
 1f80d04:	vpternlogq $0xf8,-0x19b27a7(%rip){1to8},%zmm12,%zmm11        # 5ce568 <.LCPI3_49>
 1f80d0f:	vpsllw $0x4,%zmm31,%zmm12
 1f80d16:	vpternlogq $0xf8,-0x19b27b1(%rip){1to8},%zmm10,%zmm11        # 5ce570 <.LCPI3_50>
 1f80d21:	vpternlogq $0xf8,-0x19b27b4(%rip){1to8},%zmm16,%zmm11        # 5ce578 <.LCPI3_51>
 1f80d2c:	vpternlogq $0xf8,-0x19b27b7(%rip){1to8},%zmm12,%zmm11        # 5ce580 <.LCPI3_52>
 1f80d37:	vmovdqu64 %zmm11,0x0(%r13,%r9,1)
 1f80d3f:	mov    0xb40(%r8),%r13
 1f80d46:	vmovdqu64 %zmm6,0x0(%r13,%rdi,2)
 1f80d4e:	popcnt %eax,%r13d
 1f80d53:	kmovq  %k0,%rdi
 1f80d58:	vptestnmb %zmm28,%zmm26,%k0{%k4}
 1f80d5e:	mov    0xb40(%r8),%rax
 1f80d65:	add    %edx,%r13d
 1f80d68:	vmovdqu64 %zmm9,(%rax,%r13,2)
 1f80d6f:	kmovq  %k1,%rax
 1f80d74:	korq   %k3,%k0,%k1
 1f80d79:	vmovdqa64 %zmm14,%zmm9
 1f80d7f:	kmovq  %k1,%rdx
 1f80d84:	vptestmb -0x1aca28e(%rip),%zmm3,%k1        # 4b6b00 <abi_test_hex.digits+0xb780>
 1f80d8e:	mov    0xb38(%r8),%r11
 1f80d95:	or     %rbx,%rax
 1f80d98:	or     %r10,%rdx
 1f80d9b:	or     %rbp,%rdx
 1f80d9e:	mov    %rax,0x8(%r11,%r9,1)
 1f80da3:	andn   %rdi,%rdx,%rax
 1f80da8:	mov    %rdx,(%r11,%r9,1)
 1f80dac:	popcnt %r14d,%edx
 1f80db1:	mov    %r8,%rdi
 1f80db4:	mov    %rax,0x10(%r11,%r9,1)
 1f80db9:	add    %r13d,%edx
 1f80dbc:	kmovq  %k1,0x18(%r11,%r9,1)
 1f80dc3:	korq   %k2,%k1,%k1
 1f80dc8:	kmovq  %k1,%rax
 1f80dcd:	or     %rbp,%rax
 1f80dd0:	mov    %rax,0x20(%r11,%r9,1)
 1f80dd5:	mov    %rbp,0x28(%r11,%r9,1)
 1f80dda:	mov    0x18(%rsp),%rbp
 1f80ddf:	kmovq  %k3,0x30(%r11,%r9,1)
 1f80de6:	kmovq  %k0,0x38(%r11,%r9,1)
 1f80ded:	add    $0x40,%r9
 1f80df1:	cmp    %rcx,%r9
 1f80df4:	jb     1f80930 <node_facts_window_run+0x3560>
 1f80dfa:	jmp    1f816ee <node_facts_window_run+0x431e>
 1f80dff:	kmovq  %k4,%rax
 1f80e04:	mov    %rax,0x120(%rsp)
 1f80e0c:	mov    %rax,%rbp
 1f80e0f:	mov    0x18(%rsp),%r13
 1f80e14:	mov    0x8(%rsp),%rdi
 1f80e19:	test   %rax,%rax
 1f80e1c:	je     1f80edb <node_facts_window_run+0x3b0b>
 1f80e22:	xor    %eax,%eax
 1f80e24:	tzcnt  %rbp,%rax
 1f80e29:	lea    (%rax,%r9,1),%r8
 1f80e2d:	mov    %rax,0x30(%rsp)
 1f80e32:	mov    %r8d,%r15d
 1f80e35:	movzwl 0x6b554(%r13,%r15,2),%eax
 1f80e3e:	mov    %r8d,%r12d
 1f80e41:	mov    0xb28(%rdi),%r13
 1f80e48:	mov    0x18(%rsp),%r10
 1f80e4d:	sub    %eax,%r12d
 1f80e50:	mov    0xb20(%rdi),%rax
 1f80e57:	movzbl (%rax,%r12,1),%eax
 1f80e5c:	or     %al,0x0(%r13,%r15,1)
 1f80e61:	mov    0x18(%rsp),%rax
 1f80e66:	movzbl 0x2c(%rax,%r15,1),%eax
 1f80e6c:	movzbl 0x2c(%r10,%r12,1),%r15d
 1f80e72:	xor    %r10d,%r10d
 1f80e75:	and    $0x7f,%r15d
 1f80e79:	and    $0x7f,%eax
 1f80e7c:	movzbl 0x2c8(%rdi,%r15,1),%r13d
 1f80e85:	test   %r13b,0x348(%rdi,%rax,1)
 1f80e8d:	mov    0x30(%rsp),%rax
 1f80e92:	mov    0x18(%rsp),%r13
 1f80e97:	setne  %r10b
 1f80e9b:	shlx   %rax,%r10,%rax
 1f80ea0:	or     %rax,%rbx
 1f80ea3:	cmp    %r8d,%ecx
 1f80ea6:	mov    0xb38(%rdi),%r8
 1f80ead:	seta   %al
 1f80eb0:	cmp    $0x22,%r15
 1f80eb4:	sete   %r10b
 1f80eb8:	and    %al,%r10b
 1f80ebb:	movzbl %r10b,%eax
 1f80ebf:	shlx   %r12,%rax,%rax
 1f80ec4:	and    $0xffffffc0,%r12d
 1f80ec8:	not    %rax
 1f80ecb:	and    %rax,0x20(%r8,%r12,1)
 1f80ed0:	blsr   %rbp,%rbp
 1f80ed5:	jne    1f80e22 <node_facts_window_run+0x3a52>
 1f80edb:	kmovq  %k3,%r10
 1f80ee0:	mov    %r10,%r12
 1f80ee3:	test   %r10,%r10
 1f80ee6:	je     1f80f25 <node_facts_window_run+0x3b55>
 1f80ee8:	xor    %eax,%eax
 1f80eea:	tzcnt  %r12,%rax
 1f80eef:	or     %r9,%rax
 1f80ef2:	mov    %eax,%r15d
 1f80ef5:	movzwl 0x6d5d4(%r13,%r15,2),%ebp
 1f80efe:	mov    0xb20(%rdi),%r13
 1f80f05:	sub    %ebp,%eax
 1f80f07:	mov    0xb28(%rdi),%rbp
 1f80f0e:	movzbl 0x0(%r13,%rax,1),%eax
 1f80f14:	mov    0x18(%rsp),%r13
 1f80f19:	or     %al,0x0(%rbp,%r15,1)
 1f80f1e:	blsr   %r12,%r12
 1f80f23:	jne    1f80ee8 <node_facts_window_run+0x3b18>
 1f80f25:	mov    0xb28(%rdi),%rdi
 1f80f2c:	popcnt 0x120(%rsp),%rax
 1f80f36:	popcnt %r10,%r10
 1f80f3b:	add    0x38(%rsp),%rax
 1f80f40:	vmovdqu64 (%rdi,%r9,1),%zmm24
 1f80f47:	add    %r10,%rax
 1f80f4a:	mov    %rax,0x38(%rsp)
 1f80f4f:	jmp    1f80b57 <node_facts_window_run+0x3787>
 1f80f54:	test   %rcx,%rcx
 1f80f57:	je     1f8161f <node_facts_window_run+0x424f>
 1f80f5d:	vmovdqu64 0x288(%rdi),%zmm0
 1f80f67:	vbroadcasti32x4 -0x19b9161(%rip),%zmm1        # 5c7e10 <.LCPI3_89>
 1f80f71:	vmovdqa64 -0x1aca6bb(%rip),%zmm6        # 4b68c0 <abi_test_hex.digits+0xb540>
 1f80f7b:	vbroadcasti32x4 -0x19b9155(%rip),%zmm15        # 5c7e30 <.LCPI3_91>
 1f80f85:	vbroadcasti32x4 -0x19b914f(%rip),%zmm16        # 5c7e40 <.LCPI3_92>
 1f80f8f:	vbroadcasti32x4 -0x19b9299(%rip),%zmm19        # 5c7d00 <.LCPI3_9>
 1f80f99:	vbroadcasti32x4 -0x19b9273(%rip),%zmm23        # 5c7d30 <.LCPI3_24>
 1f80fa3:	vbroadcasti32x4 -0x19b913d(%rip),%zmm24        # 5c7e70 <.LCPI3_95>
 1f80fad:	vbroadcasti32x4 -0x19b9137(%rip),%zmm25        # 5c7e80 <.LCPI3_96>
 1f80fb7:	vbroadcasti32x4 -0x19b9171(%rip),%zmm26        # 5c7e50 <.LCPI3_93>
 1f80fc1:	vbroadcasti32x4 -0x19b916b(%rip),%zmm27        # 5c7e60 <.LCPI3_94>
 1f80fcb:	vmovdqa64 -0x1aca395(%rip),%zmm28        # 4b6c40 <abi_test_hex.digits+0xb8c0>
 1f80fd5:	vmovdqa64 -0x1aca35f(%rip),%zmm29        # 4b6c80 <abi_test_hex.digits+0xb900>
 1f80fdf:	movzbl 0x4c8(%rdi),%eax
 1f80fe6:	mov    %rdi,%r10
 1f80fe9:	mov    %rsi,0x28(%rsp)
 1f80fee:	xor    %edx,%edx
 1f80ff0:	vpxord %xmm21,%xmm21,%xmm21
 1f80ff6:	vpxor  %xmm4,%xmm4,%xmm4
 1f80ffa:	xor    %edi,%edi
 1f80ffc:	vpxor  %xmm12,%xmm12,%xmm12
 1f81001:	vpxor  %xmm3,%xmm3,%xmm3
 1f81005:	neg    %rax
 1f81008:	mov    %rax,0x10(%rsp)
 1f8100d:	movq   $0x0,0x20(%rsp)
 1f81016:	cs nopw 0x0(%rax,%rax,1)
 1f81020:	mov    0xb10(%r10),%rax
 1f81027:	mov    0xb18(%r10),%rsi
 1f8102e:	vmovdqu64 0x2c(%rbp,%rdi,1),%zmm2
 1f81039:	vmovdqa64 %zmm4,%zmm9
 1f8103f:	vmovdqu64 0x108(%r10),%zmm4
 1f81049:	vmovdqu64 0x88(%r10),%zmm31
 1f81053:	vmovdqu64 0x188(%r10),%zmm13
 1f8105d:	vmovdqu64 0x208(%r10),%zmm14
 1f81067:	vmovdqu64 0x348(%r10),%zmm22
 1f81071:	vmovdqu64 0x3c8(%r10),%zmm7
 1f8107b:	vmovdqa64 %zmm21,%zmm20
 1f81081:	vmovdqu64 0x2c8(%r10),%zmm21
 1f8108b:	vmovdqu64 (%rax,%rdi,1),%zmm5
 1f81092:	vmovdqu64 (%rsi,%rdi,1),%zmm30
 1f81099:	mov    0xb20(%r10),%rax
 1f810a0:	vpermt2b 0x148(%r10),%zmm2,%zmm4
 1f810aa:	vpermt2b 0xc8(%r10),%zmm2,%zmm31
 1f810b4:	vpandq %zmm1,%zmm2,%zmm10
 1f810ba:	vpermt2b 0x248(%r10),%zmm2,%zmm14
 1f810c4:	vpermt2b 0x1c8(%r10),%zmm2,%zmm13
 1f810ce:	vpermt2b 0x308(%r10),%zmm2,%zmm21
 1f810d8:	vpermt2b 0x388(%r10),%zmm2,%zmm22
 1f810e2:	vpermt2b 0x408(%r10),%zmm2,%zmm7
 1f810ec:	vpsrlw $0x2,%zmm5,%zmm8
 1f810f3:	vpternlogq $0xf8,-0x19b2bbe(%rip){1to8},%zmm30,%zmm4        # 5ce540 <.LCPI3_42>
 1f810fe:	vpsrlw $0x3,%zmm5,%zmm2
 1f81105:	vpternlogq $0xf8,-0x19b2bc8(%rip){1to8},%zmm8,%zmm4        # 5ce548 <.LCPI3_43>
 1f81110:	vpternlogq $0xf8,-0x19b2bcb(%rip){1to8},%zmm2,%zmm4        # 5ce550 <.LCPI3_44>
 1f8111b:	vpmovb2m %zmm31,%k0
 1f81121:	kmovq  %k0,%r9
 1f81126:	vmovdqu64 %zmm4,(%rax,%rdi,1)
 1f8112d:	vmovdqu64 0x6b554(%rbp,%rdi,2),%zmm2
 1f81138:	vmovdqu64 0x6b594(%rbp,%rdi,2),%zmm11
 1f81143:	vmovdqu64 0x6d614(%rbp,%rdi,2),%zmm17
 1f8114e:	vpmovuswb %zmm2,%ymm2
 1f81154:	vpmovuswb %zmm11,%ymm11
 1f8115a:	vpmovuswb %zmm17,%ymm17
 1f81160:	vinserti64x4 $0x1,%ymm11,%zmm2,%zmm2
 1f81167:	vptestmb %zmm2,%zmm2,%k1
 1f8116d:	vpsubb %zmm2,%zmm6,%zmm11
 1f81173:	vpcmpltub %zmm2,%zmm6,%k4{%k1}
 1f8117a:	kmovq  %k1,%rax
 1f8117f:	vpcmpnltub %zmm2,%zmm6,%k1
 1f81186:	vmovdqu64 0x6d5d4(%rbp,%rdi,2),%zmm2
 1f81191:	kmovq  %k1,%r11
 1f81196:	and    %rax,%r11
 1f81199:	mov    0xb28(%r10),%rax
 1f811a0:	kmovq  %r11,%k1
 1f811a5:	vpermt2b %zmm21,%zmm11,%zmm20{%k1}{z}
 1f811ab:	vpmovuswb %zmm2,%ymm2
 1f811b1:	vptestmb %zmm22,%zmm20,%k5
 1f811b7:	kmovq  %k5,%r10
 1f811bc:	vinserti64x4 $0x1,%ymm17,%zmm2,%zmm18
 1f811c3:	vmovdqa64 %zmm9,%zmm2
 1f811c9:	vpermt2b %zmm4,%zmm11,%zmm2{%k1}{z}
 1f811cf:	vptestmb %zmm18,%zmm18,%k2
 1f811d5:	vpsubb %zmm18,%zmm6,%zmm17
 1f811db:	vpcmpltub %zmm18,%zmm6,%k3{%k2}
 1f811e2:	vpcmpnltub %zmm18,%zmm6,%k2{%k2}
 1f811e9:	vpermt2b %zmm4,%zmm17,%zmm9{%k2}{z}
 1f811ef:	kortestq %k4,%k3
 1f811f4:	vporq  %zmm2,%zmm9,%zmm18
 1f811fa:	vmovdqu64 %zmm18,(%rax,%rdi,1)
 1f81201:	jne    1f814a3 <node_facts_window_run+0x40d3>
 1f81207:	vmovdqa64 %zmm12,%zmm20
 1f8120d:	vpermi2b %zmm30,%zmm12,%zmm17{%k2}{z}
 1f81213:	vpermt2b %zmm30,%zmm11,%zmm20{%k1}{z}
 1f81219:	vpternlogq $0xe0,%zmm1,%zmm30,%zmm14
 1f81220:	vpandq %zmm13,%zmm18,%zmm22
 1f81226:	vpandd -0x19b0274(%rip){1to16},%zmm20,%zmm13        # 5d0fbc <.LCPI3_82>
 1f81230:	mov    0x8(%rsp),%rsi
 1f81235:	mov    %edx,%r13d
 1f81238:	vpsrlw $0x3,%zmm20,%zmm12
 1f8123f:	vpternlogq $0xe4,-0x19b2cc2(%rip){1to8},%zmm17,%zmm12        # 5ce588 <.LCPI3_53>
 1f8124a:	vpermb %zmm0,%zmm12,%zmm12
 1f81250:	vptestmb %zmm12,%zmm14,%k2
 1f81256:	vpandq %zmm15,%zmm20,%zmm14
 1f8125c:	vmovdqa64 %zmm30,%zmm12
 1f81262:	vpcmpeqb %zmm16,%zmm14,%k3
 1f81268:	vpandq %zmm15,%zmm17,%zmm14
 1f8126e:	kmovq  %k2,%rbx
 1f81273:	vpcmpeqb -0x1aca93d(%rip),%zmm22,%k2        # 4b6940 <abi_test_hex.digits+0xb5c0>
 1f8127d:	vpcmpeqb %zmm16,%zmm14,%k4
 1f81283:	vpandd -0x19b02c9(%rip){1to16},%zmm5,%zmm14        # 5d0fc4 <.LCPI3_86>
 1f8128d:	korq   %k4,%k3,%k3
 1f81292:	vpcmpeqb -0x1aca89c(%rip),%zmm10,%k3{%k3}        # 4b6a00 <abi_test_hex.digits+0xb680>
 1f8129c:	vptestmb %zmm22,%zmm22,%k4
 1f812a2:	korq   %k4,%k0,%k0
 1f812a7:	kmovq  %k2,%r14
 1f812ac:	vpternlogq $0xfe,%zmm13,%zmm22,%zmm14
 1f812b3:	vpsllw $0x7,%zmm5,%zmm13
 1f812ba:	andn   %r14,%r9,%r9
 1f812bf:	knotq  %k3,%k3
 1f812c4:	vptestnmb %zmm14,%zmm14,%k5
 1f812ca:	vpmovb2m %zmm13,%k2
 1f812d0:	vpaddw %zmm5,%zmm5,%zmm13
 1f812d6:	kmovq  %k3,%r12
 1f812db:	vpcmpeqb -0x1aca9e5(%rip),%zmm10,%k3        # 4b6900 <abi_test_hex.digits+0xb580>
 1f812e5:	kmovq  %k5,%r15
 1f812ea:	vpcmpeqb %zmm24,%zmm10,%k5
 1f812f0:	and    %rbx,%r12
 1f812f3:	and    %r9,%r12
 1f812f6:	kmovq  %k3,%rax
 1f812fb:	and    0x10(%rsp),%rax
 1f81300:	vptestmb %zmm19,%zmm5,%k3
 1f81306:	kmovq  %k3,%r8
 1f8130b:	and    %r8,%rax
 1f8130e:	mov    0xb30(%rsi),%r8
 1f81315:	and    %rax,%r15
 1f81318:	and    %r11,%r15
 1f8131b:	kmovq  %r15,%k3
 1f81320:	vpmovm2b %k3,%zmm10
 1f81326:	vpermt2b %zmm10,%zmm11,%zmm3
 1f8132c:	vptestmb %zmm25,%zmm5,%k3{%k4}
 1f81332:	vpandq %zmm31,%zmm5,%zmm5
 1f81338:	vptestmb %zmm26,%zmm2,%k4
 1f8133e:	vpaddw %zmm5,%zmm5,%zmm5
 1f81344:	vptestmb %zmm19,%zmm31,%k4{%k4}
 1f8134a:	vptestmb %zmm3,%zmm3,%k1{%k1}
 1f81350:	kandq  %k3,%k5,%k3
 1f81355:	kandq  %k2,%k5,%k5
 1f8135a:	vpbroadcastw %edi,%zmm3
 1f81360:	vporq  %zmm29,%zmm3,%zmm11
 1f81366:	vporq  %zmm28,%zmm3,%zmm3
 1f8136c:	vptestmb %zmm26,%zmm9,%k4{%k4}
 1f81372:	kandq  %k1,%k5,%k1
 1f81377:	kshiftrq $0x20,%k1,%k5
 1f8137d:	vpcompressw %zmm3,%zmm3{%k1}{z}
 1f81383:	kmovd  %k1,%eax
 1f81387:	vptestmb %zmm7,%zmm18,%k1
 1f8138d:	vpandq -0x19b2e3f(%rip){1to8},%zmm13,%zmm7        # 5ce558 <.LCPI3_47>
 1f81397:	vpsllw $0x3,%zmm30,%zmm13
 1f8139e:	vpternlogq $0xf8,-0x19b2e49(%rip){1to8},%zmm31,%zmm7        # 5ce560 <.LCPI3_48>
 1f813a9:	vpcompressw %zmm11,%zmm11{%k5}{z}
 1f813af:	kmovd  %k5,%r11d
 1f813b3:	vpternlogq $0xf8,-0x19b2e56(%rip){1to8},%zmm8,%zmm7        # 5ce568 <.LCPI3_49>
 1f813be:	vpsllw $0x4,%zmm30,%zmm8
 1f813c5:	vpternlogq $0xf8,-0x19b2e60(%rip){1to8},%zmm5,%zmm7        # 5ce570 <.LCPI3_50>
 1f813d0:	vpternlogq $0xf8,-0x19b2e63(%rip){1to8},%zmm13,%zmm7        # 5ce578 <.LCPI3_51>
 1f813db:	vpternlogq $0xf8,-0x19b2e66(%rip){1to8},%zmm8,%zmm7        # 5ce580 <.LCPI3_52>
 1f813e6:	vmovdqu64 %zmm7,(%r8,%rdi,1)
 1f813ed:	mov    0xb40(%rsi),%r8
 1f813f4:	vmovdqu64 %zmm3,(%r8,%r13,2)
 1f813fb:	popcnt %eax,%r13d
 1f81400:	kmovq  %k0,%r8
 1f81405:	vptestnmb %zmm27,%zmm22,%k0{%k4}
 1f8140b:	vmovdqa64 %zmm10,%zmm3
 1f81411:	mov    0xb40(%rsi),%rax
 1f81418:	add    %edx,%r13d
 1f8141b:	vmovdqu64 %zmm11,(%rax,%r13,2)
 1f81422:	kmovq  %k1,%rax
 1f81427:	korq   %k3,%k0,%k1
 1f8142c:	mov    0xb38(%rsi),%r9
 1f81433:	kmovq  %k1,%rdx
 1f81438:	or     %r10,%rax
 1f8143b:	vptestmb %zmm23,%zmm31,%k1
 1f81441:	mov    %rsi,%r10
 1f81444:	or     %r12,%rdx
 1f81447:	or     %r15,%rdx
 1f8144a:	mov    %rax,0x8(%r9,%rdi,1)
 1f8144f:	mov    %rdx,(%r9,%rdi,1)
 1f81453:	andn   %r8,%rdx,%rdx
 1f81458:	mov    %rdx,0x10(%r9,%rdi,1)
 1f8145d:	kmovq  %k1,0x18(%r9,%rdi,1)
 1f81464:	korq   %k2,%k1,%k1
 1f81469:	popcnt %r11d,%edx
 1f8146e:	kmovq  %k1,%rax
 1f81473:	add    %r13d,%edx
 1f81476:	or     %r15,%rax
 1f81479:	mov    %rax,0x20(%r9,%rdi,1)
 1f8147e:	mov    %r15,0x28(%r9,%rdi,1)
 1f81483:	kmovq  %k3,0x30(%r9,%rdi,1)
 1f8148a:	kmovq  %k0,0x38(%r9,%rdi,1)
 1f81491:	add    $0x40,%rdi
 1f81495:	cmp    %rcx,%rdi
 1f81498:	jb     1f81020 <node_facts_window_run+0x3c50>
 1f8149e:	jmp    1f815df <node_facts_window_run+0x420f>
 1f814a3:	kmovq  %k4,%rax
 1f814a8:	mov    %rax,0x38(%rsp)
 1f814ad:	mov    %rax,%r14
 1f814b0:	mov    0x8(%rsp),%r13
 1f814b5:	test   %rax,%rax
 1f814b8:	je     1f81571 <node_facts_window_run+0x41a1>
 1f814be:	mov    0x18(%rsp),%r8
 1f814c3:	xor    %esi,%esi
 1f814c5:	tzcnt  %r14,%rsi
 1f814ca:	mov    0xb28(%r13),%rbx
 1f814d1:	lea    (%rsi,%rdi,1),%r12
 1f814d5:	mov    %r12d,%eax
 1f814d8:	mov    %r12d,%r15d
 1f814db:	movzwl 0x6b554(%r8,%rax,2),%ebp
 1f814e4:	mov    0x18(%rsp),%r8
 1f814e9:	sub    %ebp,%r15d
 1f814ec:	mov    0xb20(%r13),%rbp
 1f814f3:	movzbl 0x0(%rbp,%r15,1),%ebp
 1f814f9:	or     %bpl,(%rbx,%rax,1)
 1f814fd:	movzbl 0x2c(%r8,%rax,1),%eax
 1f81503:	mov    0x18(%rsp),%r8
 1f81508:	movzbl 0x2c(%r8,%r15,1),%ebx
 1f8150e:	and    $0x7f,%eax
 1f81511:	xor    %r8d,%r8d
 1f81514:	and    $0x7f,%ebx
 1f81517:	movzbl 0x2c8(%r13,%rbx,1),%ebp
 1f81520:	test   %bpl,0x348(%r13,%rax,1)
 1f81528:	mov    0x18(%rsp),%rbp
 1f8152d:	setne  %r8b
 1f81531:	shlx   %rsi,%r8,%rax
 1f81536:	mov    0xb38(%r13),%rsi
 1f8153d:	or     %rax,%r10
 1f81540:	cmp    %r12d,%ecx
 1f81543:	seta   %al
 1f81546:	cmp    $0x22,%rbx
 1f8154a:	sete   %r8b
 1f8154e:	and    %al,%r8b
 1f81551:	movzbl %r8b,%eax
 1f81555:	shlx   %r15,%rax,%rax
 1f8155a:	and    $0xffffffc0,%r15d
 1f8155e:	not    %rax
 1f81561:	and    %rax,0x20(%rsi,%r15,1)
 1f81566:	blsr   %r14,%r14
 1f8156b:	jne    1f814be <node_facts_window_run+0x40ee>
 1f81571:	kmovq  %k3,%r14
 1f81576:	mov    %r14,%r15
 1f81579:	test   %r14,%r14
 1f8157c:	je     1f815b3 <node_facts_window_run+0x41e3>
 1f8157e:	xor    %eax,%eax
 1f81580:	tzcnt  %r15,%rax
 1f81585:	mov    0xb20(%r13),%rsi
 1f8158c:	mov    0xb28(%r13),%r12
 1f81593:	or     %rdi,%rax
 1f81596:	mov    %eax,%r8d
 1f81599:	movzwl 0x6d5d4(%rbp,%r8,2),%ebx
 1f815a2:	sub    %ebx,%eax
 1f815a4:	movzbl (%rsi,%rax,1),%eax
 1f815a8:	or     %al,(%r12,%r8,1)
 1f815ac:	blsr   %r15,%r15
 1f815b1:	jne    1f8157e <node_facts_window_run+0x41ae>
 1f815b3:	mov    0xb28(%r13),%rsi
 1f815ba:	popcnt 0x38(%rsp),%rax
 1f815c1:	popcnt %r14,%r8
 1f815c6:	add    0x20(%rsp),%rax
 1f815cb:	vmovdqu64 (%rsi,%rdi,1),%zmm18
 1f815d2:	add    %r8,%rax
 1f815d5:	mov    %rax,0x20(%rsp)
 1f815da:	jmp    1f81207 <node_facts_window_run+0x3e37>
 1f815df:	mov    0x48(%rsp),%r9
 1f815e4:	mov    0x20(%rsp),%rsi
 1f815e9:	mov    %ecx,%eax
 1f815eb:	dec    %rcx
 1f815ee:	shr    $0x6,%rcx
 1f815f2:	inc    %rcx
 1f815f5:	mov    %ecx,%edi
 1f815f7:	and    $0x7,%edi
 1f815fa:	add    %rsi,0xa88(%r9)
 1f81601:	mov    0xb38(%r10),%rsi
 1f81608:	cmp    $0x1c1,%eax
 1f8160d:	jae    1f8162a <node_facts_window_run+0x425a>
 1f8160f:	mov    (%rsp),%r11
 1f81613:	vpxor  %xmm0,%xmm0,%xmm0
 1f81617:	xor    %r8d,%r8d
 1f8161a:	jmp    1f816c5 <node_facts_window_run+0x42f5>
 1f8161f:	xor    %edx,%edx
 1f81621:	vpxor  %xmm0,%xmm0,%xmm0
 1f81625:	jmp    1f817f2 <node_facts_window_run+0x4422>
 1f8162a:	and    $0xfffffffffffffff8,%rcx
 1f8162e:	vpxor  %xmm0,%xmm0,%xmm0
 1f81632:	xor    %r8d,%r8d
 1f81635:	data16 cs nopw 0x0(%rax,%rax,1)
 1f81640:	vpopcntq (%rsi,%r8,1),%zmm1
 1f81647:	vpopcntq 0x40(%rsi,%r8,1),%zmm3
 1f8164f:	vpopcntq 0x80(%rsi,%r8,1),%zmm2
 1f81657:	vpopcntq 0xc0(%rsi,%r8,1),%zmm4
 1f8165f:	vpaddq %zmm0,%zmm1,%zmm0
 1f81665:	vpaddq %zmm3,%zmm2,%zmm1
 1f8166b:	vpopcntq 0x100(%rsi,%r8,1),%zmm2
 1f81673:	vpopcntq 0x140(%rsi,%r8,1),%zmm3
 1f8167b:	vpaddq %zmm0,%zmm1,%zmm0
 1f81681:	vpaddq %zmm4,%zmm2,%zmm1
 1f81687:	vpopcntq 0x1c0(%rsi,%r8,1),%zmm2
 1f8168f:	vpaddq %zmm1,%zmm3,%zmm1
 1f81695:	vpopcntq 0x180(%rsi,%r8,1),%zmm3
 1f8169d:	add    $0x200,%r8
 1f816a4:	add    $0xfffffffffffffff8,%rcx
 1f816a8:	vpaddq %zmm0,%zmm1,%zmm0
 1f816ae:	vpaddq %zmm3,%zmm2,%zmm1
 1f816b4:	vpaddq %zmm0,%zmm1,%zmm0
 1f816ba:	jne    1f81640 <node_facts_window_run+0x4270>
 1f816bc:	mov    (%rsp),%r11
 1f816c0:	test   %rdi,%rdi
 1f816c3:	je     1f816e6 <node_facts_window_run+0x4316>
 1f816c5:	add    %r8,%rsi
 1f816c8:	shl    $0x6,%edi
 1f816cb:	xor    %ecx,%ecx
 1f816cd:	nopl   (%rax)
 1f816d0:	vpopcntq (%rsi,%rcx,1),%zmm1
 1f816d7:	add    $0x40,%rcx
 1f816db:	vpaddq %zmm0,%zmm1,%zmm0
 1f816e1:	cmp    %rcx,%rdi
 1f816e4:	jne    1f816d0 <node_facts_window_run+0x4300>
 1f816e6:	mov    %r10,%rdi
 1f816e9:	jmp    1f817ed <node_facts_window_run+0x441d>
 1f816ee:	mov    0x48(%rsp),%r9
 1f816f3:	mov    0x38(%rsp),%rax
 1f816f8:	mov    %ecx,%r8d
 1f816fb:	dec    %rcx
 1f816fe:	shr    $0x6,%rcx
 1f81702:	inc    %rcx
 1f81705:	add    %rax,0xa88(%r9)
 1f8170c:	mov    %rdi,%rax
 1f8170f:	mov    0xb38(%rdi),%rsi
 1f81716:	mov    %ecx,%edi
 1f81718:	and    $0x7,%edi
 1f8171b:	cmp    $0x1c1,%r8d
 1f81722:	jae    1f81730 <node_facts_window_run+0x4360>
 1f81724:	vpxor  %xmm0,%xmm0,%xmm0
 1f81728:	xor    %r8d,%r8d
 1f8172b:	jmp    1f817c1 <node_facts_window_run+0x43f1>
 1f81730:	and    $0xfffffffffffffff8,%rcx
 1f81734:	vpxor  %xmm0,%xmm0,%xmm0
 1f81738:	xor    %r8d,%r8d
 1f8173b:	nopl   0x0(%rax,%rax,1)
 1f81740:	vpopcntq (%rsi,%r8,1),%zmm1
 1f81747:	vpopcntq 0x40(%rsi,%r8,1),%zmm3
 1f8174f:	vpopcntq 0x80(%rsi,%r8,1),%zmm2
 1f81757:	vpopcntq 0xc0(%rsi,%r8,1),%zmm4
 1f8175f:	vpaddq %zmm0,%zmm1,%zmm0
 1f81765:	vpaddq %zmm3,%zmm2,%zmm1
 1f8176b:	vpopcntq 0x100(%rsi,%r8,1),%zmm2
 1f81773:	vpopcntq 0x140(%rsi,%r8,1),%zmm3
 1f8177b:	vpaddq %zmm0,%zmm1,%zmm0
 1f81781:	vpaddq %zmm4,%zmm2,%zmm1
 1f81787:	vpopcntq 0x1c0(%rsi,%r8,1),%zmm2
 1f8178f:	vpaddq %zmm1,%zmm3,%zmm1
 1f81795:	vpopcntq 0x180(%rsi,%r8,1),%zmm3
 1f8179d:	add    $0x200,%r8
 1f817a4:	add    $0xfffffffffffffff8,%rcx
 1f817a8:	vpaddq %zmm0,%zmm1,%zmm0
 1f817ae:	vpaddq %zmm3,%zmm2,%zmm1
 1f817b4:	vpaddq %zmm0,%zmm1,%zmm0
 1f817ba:	jne    1f81740 <node_facts_window_run+0x4370>
 1f817bc:	test   %rdi,%rdi
 1f817bf:	je     1f817e6 <node_facts_window_run+0x4416>
 1f817c1:	add    %r8,%rsi
 1f817c4:	shl    $0x6,%edi
 1f817c7:	xor    %ecx,%ecx
 1f817c9:	nopl   0x0(%rax)
 1f817d0:	vpopcntq (%rsi,%rcx,1),%zmm1
 1f817d7:	add    $0x40,%rcx
 1f817db:	vpaddq %zmm0,%zmm1,%zmm0
 1f817e1:	cmp    %rcx,%rdi
 1f817e4:	jne    1f817d0 <node_facts_window_run+0x4400>
 1f817e6:	mov    (%rsp),%r11
 1f817ea:	mov    %rax,%rdi
 1f817ed:	mov    0x28(%rsp),%rsi
 1f817f2:	vextracti32x4 $0x3,%zmm0,%xmm1
 1f817f9:	mov    $0x24,%al
 1f817fb:	vpermq $0xff,%zmm0,%zmm2
 1f81802:	vextracti64x4 $0x1,%zmm0,%ymm3
 1f81809:	movq   $0x0,0x220(%rsp)
 1f81815:	vpbroadcastq %xmm1,%xmm1
 1f8181a:	kmovd  %eax,%k1
 1f8181e:	mov    $0x9,%al
 1f81820:	vextracti32x4 $0x2,%zmm2,%xmm2
 1f81827:	vpblendd $0x3,%ymm0,%ymm3,%ymm0
 1f8182d:	vpaddq %xmm1,%xmm3,%xmm1
 1f81831:	kmovd  %eax,%k2
 1f81835:	vmovdqu64 0x40(%rsi),%zmm4{%k1}{z}
 1f8183c:	vpaddq %xmm2,%xmm1,%xmm1
 1f81840:	vmovdqu64 (%rsi),%zmm2{%k2}{z}
 1f81846:	vpsrldq $0x8,%xmm1,%xmm1
 1f8184b:	vpsubq %ymm1,%ymm0,%ymm0
 1f8184f:	vshufi64x2 $0x55,%zmm0,%zmm0,%zmm3
 1f81856:	vpermq $0x64,%ymm0,%ymm0
 1f8185c:	vpaddq %zmm4,%zmm3,%zmm1
 1f81862:	vpaddq %zmm2,%zmm0,%zmm0
 1f81868:	vmovdqu64 %zmm1,0x40(%rsi){%k1}
 1f8186f:	vmovdqu64 %zmm0,(%rsi){%k2}
 1f81875:	test   %edx,%edx
 1f81877:	je     1f81940 <node_facts_window_run+0x4570>
 1f8187d:	mov    $0x8,%ebp
 1f81882:	mov    %edx,%r14d
 1f81885:	xor    %r12d,%r12d
 1f81888:	xor    %r13d,%r13d
 1f8188b:	xor    %r15d,%r15d
 1f8188e:	xchg   %ax,%ax
 1f81890:	mov    0xb40(%rdi),%rax
 1f81897:	mov    0x18(%rsp),%rsi
 1f8189c:	mov    0xb48(%rdi),%rcx
 1f818a3:	movzwl (%rax,%r13,2),%ebx
 1f818a8:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f818b0:	sub    %eax,%ebx
 1f818b2:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f818ba:	mov    %ebx,%edx
 1f818bc:	sub    %eax,%edx
 1f818be:	cmpb   $0x2,0x69454(%rsi,%rdx,1)
 1f818c6:	mov    0x757d4(%rsi,%rdx,4),%eax
 1f818cd:	cmovne %r12,%rax
 1f818d1:	movzbl (%rcx,%rax,1),%eax
 1f818d5:	cmovne %ebp,%eax
 1f818d8:	test   $0x8,%al
 1f818da:	je     1f818ed <node_facts_window_run+0x451d>
 1f818dc:	movzbl %al,%eax
 1f818df:	test   $0x10,%al
 1f818e1:	jne    1f81912 <node_facts_window_run+0x4542>
 1f818e3:	inc    %r13
 1f818e6:	cmp    %r13,%r14
 1f818e9:	jne    1f81890 <node_facts_window_run+0x44c0>
 1f818eb:	jmp    1f81939 <node_facts_window_run+0x4569>
 1f818ed:	mov    0x18(%rsp),%rsi
 1f818f2:	vzeroupper
 1f818f5:	call   1f93be0 <node_tests_window_wants>
 1f818fa:	mov    0x8(%rsp),%rdi
 1f818ff:	mov    0x48(%rsp),%r9
 1f81904:	mov    (%rsp),%r11
 1f81908:	movzbl %al,%eax
 1f8190b:	inc    %r15
 1f8190e:	test   $0x10,%al
 1f81910:	je     1f818e3 <node_facts_window_run+0x4513>
 1f81912:	mov    0xb38(%rdi),%rdx
 1f81919:	mov    %ebx,%ecx
 1f8191b:	mov    $0xfffffffffffffffe,%rax
 1f81922:	and    $0xffffffc0,%ebx
 1f81925:	rol    %cl,%rax
 1f81928:	and    %rax,0x20(%rdx,%rbx,1)
 1f8192d:	inc    %r13
 1f81930:	cmp    %r13,%r14
 1f81933:	jne    1f81890 <node_facts_window_run+0x44c0>
 1f81939:	mov    0x18(%rsp),%rbp
 1f8193e:	jmp    1f81946 <node_facts_window_run+0x4576>
 1f81940:	xor    %r14d,%r14d
 1f81943:	xor    %r15d,%r15d
 1f81946:	add    %r15,0x828(%r9)
 1f8194d:	rdtsc
 1f8194f:	add    %r14,0x820(%r9)
 1f81956:	cmpl   $0x0,0xa90(%r11)
 1f8195e:	mov    %rax,0x6e0(%rsp)
 1f81966:	mov    %rdx,0x410(%rsp)
 1f8196e:	mov    0x50(%rsp),%r13
 1f81973:	je     1f82847 <node_facts_window_run+0x5477>
 1f81979:	movzbl 0x68(%rsp),%eax
 1f8197e:	lea    0x42ec(%rbp),%rdx
 1f81985:	mov    $0x40,%ebx
 1f8198a:	mov    $0xffffffffffffffff,%r14
 1f81991:	xor    %r15d,%r15d
 1f81994:	xor    %r12d,%r12d
 1f81997:	mov    %eax,0x98(%rsp)
 1f8199e:	movzbl 0x40(%rdi),%eax
 1f819a2:	shl    $0x1b,%rax
 1f819a6:	mov    %rax,0x40(%rsp)
 1f819ab:	mov    0xa8(%rsp),%rax
 1f819b3:	mov    (%rax),%rax
 1f819b6:	mov    0x6c8(%rax),%ecx
 1f819bc:	mov    0x6e8(%rax),%eax
 1f819c2:	mov    %ecx,0x80(%rsp)
 1f819c9:	mov    %eax,0x7c0(%rsp)
 1f819d0:	movzbl 0x3a(%rdi),%eax
 1f819d4:	lea    0x422c(%rbp),%rcx
 1f819db:	mov    %eax,0x90(%rsp)
 1f819e2:	movzbl 0x3c(%rdi),%eax
 1f819e6:	mov    %eax,0x78(%rsp)
 1f819ea:	mov    0xa0(%rsp),%eax
 1f819f1:	mov    %rdx,0x60(%rsp)
 1f819f6:	mov    %rcx,0xe0(%rsp)
 1f819fe:	movq   $0x0,0x220(%rsp)
 1f81a0a:	vpbroadcastd %eax,%zmm3
 1f81a10:	jmp    1f81a37 <node_facts_window_run+0x4667>
 1f81a12:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81a20:	movb   $0x0,0x61(%rdx)
 1f81a24:	mov    0xa90(%r11),%eax
 1f81a2b:	inc    %r15
 1f81a2e:	cmp    %rax,%r15
 1f81a31:	jae    1f82847 <node_facts_window_run+0x5477>
 1f81a37:	mov    0xa88(%r11),%rax
 1f81a3e:	imul   $0x68,%r15,%rdx
 1f81a42:	add    %r13,%rdx
 1f81a45:	cmpb   $0x0,(%rax,%r15,1)
 1f81a4a:	je     1f81a20 <node_facts_window_run+0x4650>
 1f81a4c:	mov    0xa50(%r11),%rax
 1f81a53:	mov    (%rax,%r15,4),%eax
 1f81a57:	cmp    0x20(%r9),%eax
 1f81a5b:	jae    1f81a20 <node_facts_window_run+0x4650>
 1f81a5d:	mov    0x18(%r9),%rcx
 1f81a61:	movzbl (%rcx,%rax,1),%eax
 1f81a65:	shr    $0x5,%al
 1f81a68:	and    $0x1,%al
 1f81a6a:	mov    %al,0x61(%rdx)
 1f81a6d:	je     1f81a24 <node_facts_window_run+0x4654>
 1f81a6f:	mov    0xa70(%r11),%rax
 1f81a76:	mov    0xb30(%rdi),%rcx
 1f81a7d:	mov    (%rax,%r15,4),%r10d
 1f81a81:	mov    0x651b8(%rbp,%r10,4),%ebp
 1f81a89:	mov    %r10,0x290(%rsp)
 1f81a91:	sub    %ebp,%r10d
 1f81a94:	inc    %r10d
 1f81a97:	mov    %r10d,%eax
 1f81a9a:	mov    %rax,0x160(%rsp)
 1f81aa2:	mov    %rdx,0x2d0(%rsp)
 1f81aaa:	test   %rbp,%rbp
 1f81aad:	je     1f81ad5 <node_facts_window_run+0x4705>
 1f81aaf:	lea    -0x1(%rbp),%rdx
 1f81ab3:	shr    $0x6,%rdx
 1f81ab7:	inc    %rdx
 1f81aba:	mov    %edx,%eax
 1f81abc:	and    $0x7,%eax
 1f81abf:	cmp    $0x1c1,%ebp
 1f81ac5:	jae    1f81adf <node_facts_window_run+0x470f>
 1f81ac7:	mov    %rdi,%r9
 1f81aca:	vpxor  %xmm0,%xmm0,%xmm0
 1f81ace:	xor    %esi,%esi
 1f81ad0:	jmp    1f81c50 <node_facts_window_run+0x4880>
 1f81ad5:	mov    %rdi,%r9
 1f81ad8:	xor    %eax,%eax
 1f81ada:	jmp    1f81cc3 <node_facts_window_run+0x48f3>
 1f81adf:	movabs $0x7fffffffffffff8,%rsi
 1f81ae9:	mov    %r10,0x30(%rsp)
 1f81aee:	vpxor  %xmm0,%xmm0,%xmm0
 1f81af2:	and    %rsi,%rdx
 1f81af5:	mov    0x160(%rsp),%rsi
 1f81afd:	lea    0x1c0(%rcx,%rsi,1),%rdi
 1f81b05:	xor    %esi,%esi
 1f81b07:	nopw   0x0(%rax,%rax,1)
 1f81b10:	lea    0x0(%rbp,%rsi,1),%r9
 1f81b15:	mov    %r9d,%r8d
 1f81b18:	sub    $0x40,%r9
 1f81b1c:	shlx   %r8,%r14,%r8
 1f81b21:	not    %r8
 1f81b24:	mov    %r8,%r10
 1f81b27:	cmovae %r14,%r10
 1f81b2b:	cmp    $0x40,%r9
 1f81b2f:	shlx   %r9,%r14,%r9
 1f81b34:	not    %r9
 1f81b37:	kmovq  %r10,%k1
 1f81b3c:	cmovae %r14,%r9
 1f81b40:	vmovdqu8 -0x1c0(%rdi),%zmm1{%k1}{z}
 1f81b47:	kmovq  %r9,%k1
 1f81b4c:	lea    -0x80(%rbp,%rsi,1),%r9
 1f81b51:	vmovdqu8 -0x180(%rdi),%zmm2{%k1}{z}
 1f81b58:	cmp    $0x40,%r9
 1f81b5c:	mov    %r8,%r9
 1f81b5f:	cmovae %r14,%r9
 1f81b63:	kmovq  %r9,%k1
 1f81b68:	lea    -0xc0(%rbp,%rsi,1),%r9
 1f81b70:	cmp    $0x40,%r9
 1f81b74:	mov    %r8,%r9
 1f81b77:	cmovae %r14,%r9
 1f81b7b:	vpternlogq $0xfe,%zmm1,%zmm0,%zmm2
 1f81b82:	vmovdqu8 -0x140(%rdi),%zmm0{%k1}{z}
 1f81b89:	kmovq  %r9,%k1
 1f81b8e:	lea    -0x100(%rbp,%rsi,1),%r9
 1f81b96:	vmovdqu8 -0x100(%rdi),%zmm1{%k1}{z}
 1f81b9d:	cmp    $0x40,%r9
 1f81ba1:	mov    %r8,%r9
 1f81ba4:	cmovae %r14,%r9
 1f81ba8:	kmovq  %r9,%k1
 1f81bad:	lea    -0x140(%rbp,%rsi,1),%r9
 1f81bb5:	cmp    $0x40,%r9
 1f81bb9:	mov    %r8,%r9
 1f81bbc:	cmovae %r14,%r9
 1f81bc0:	vpternlogq $0xfe,%zmm0,%zmm2,%zmm1
 1f81bc7:	vmovdqu8 -0xc0(%rdi),%zmm0{%k1}{z}
 1f81bce:	kmovq  %r9,%k1
 1f81bd3:	lea    -0x180(%rbp,%rsi,1),%r9
 1f81bdb:	vmovdqu8 -0x80(%rdi),%zmm2{%k1}{z}
 1f81be2:	cmp    $0x40,%r9
 1f81be6:	mov    %r8,%r9
 1f81be9:	cmovae %r14,%r9
 1f81bed:	kmovq  %r9,%k1
 1f81bf2:	lea    -0x1c0(%rbp,%rsi,1),%r9
 1f81bfa:	vmovdqu8 -0x40(%rdi),%zmm4{%k1}{z}
 1f81c01:	cmp    $0x40,%r9
 1f81c05:	cmovae %r14,%r8
 1f81c09:	add    $0xfffffffffffffe00,%rsi
 1f81c10:	kmovq  %r8,%k1
 1f81c15:	vpternlogq $0xfe,%zmm0,%zmm1,%zmm2
 1f81c1c:	vmovdqu8 (%rdi),%zmm0{%k1}{z}
 1f81c22:	add    $0x200,%rdi
 1f81c29:	add    $0xfffffffffffffff8,%rdx
 1f81c2d:	vpternlogq $0xfe,%zmm4,%zmm2,%zmm0
 1f81c34:	jne    1f81b10 <node_facts_window_run+0x4740>
 1f81c3a:	test   %rax,%rax
 1f81c3d:	je     1f82773 <node_facts_window_run+0x53a3>
 1f81c43:	mov    0x8(%rsp),%r9
 1f81c48:	mov    0x30(%rsp),%r10
 1f81c4d:	neg    %rsi
 1f81c50:	mov    0x160(%rsp),%rdi
 1f81c58:	lea    (%rcx,%rsi,1),%rdx
 1f81c5c:	shl    $0x6,%eax
 1f81c5f:	add    %rdi,%rdx
 1f81c62:	mov    %rbp,%rdi
 1f81c65:	sub    %rsi,%rdi
 1f81c68:	xor    %esi,%esi
 1f81c6a:	nopw   0x0(%rax,%rax,1)
 1f81c70:	mov    %edi,%r8d
 1f81c73:	sub    $0x40,%rdi
 1f81c77:	shlx   %r8,%r14,%r8
 1f81c7c:	not    %r8
 1f81c7f:	cmovae %r14,%r8
 1f81c83:	kmovq  %r8,%k1
 1f81c88:	vmovdqu8 (%rdx,%rsi,1),%zmm1{%k1}{z}
 1f81c8f:	add    $0x40,%rsi
 1f81c93:	vporq  %zmm1,%zmm0,%zmm0
 1f81c99:	cmp    %rsi,%rax
 1f81c9c:	jne    1f81c70 <node_facts_window_run+0x48a0>
 1f81c9e:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f81ca5:	vporq  %zmm1,%zmm0,%zmm0
 1f81cab:	vextracti128 $0x1,%ymm0,%xmm1
 1f81cb1:	vpor   %xmm1,%xmm0,%xmm0
 1f81cb5:	vpshufd $0xee,%xmm0,%xmm1
 1f81cba:	vpor   %xmm1,%xmm0,%xmm0
 1f81cbe:	vmovq  %xmm0,%rax
 1f81cc3:	mov    0xa58(%r11),%rdx
 1f81cca:	mov    0xa68(%r11),%rsi
 1f81cd1:	mov    (%rdx,%r15,4),%edi
 1f81cd5:	mov    %rax,%rdx
 1f81cd8:	shr    $0x20,%rdx
 1f81cdc:	mov    (%rsi,%r15,4),%r8d
 1f81ce0:	or     %rax,%rdx
 1f81ce3:	mov    %rdx,%rsi
 1f81ce6:	shr    $0x10,%rsi
 1f81cea:	or     %edx,%esi
 1f81cec:	mov    %esi,%eax
 1f81cee:	shr    $0x8,%eax
 1f81cf1:	or     %esi,%eax
 1f81cf3:	mov    %edi,0x350(%rsp)
 1f81cfa:	cmp    %ebp,%edi
 1f81cfc:	jbe    1f81d02 <node_facts_window_run+0x4932>
 1f81cfe:	or     (%rcx,%r8,1),%al
 1f81d02:	movzbl %al,%esi
 1f81d05:	lea    0x0(,%rsi,8),%edx
 1f81d0c:	lea    0x0(,%rsi,4),%ecx
 1f81d13:	mov    %edx,%eax
 1f81d15:	mov    %ecx,0x310(%rsp)
 1f81d1c:	and    $0x8,%eax
 1f81d1f:	and    $0x10,%ecx
 1f81d22:	and    $0x40,%edx
 1f81d25:	or     %eax,%ecx
 1f81d27:	mov    %esi,%eax
 1f81d29:	and    $0x10,%eax
 1f81d2c:	lea    (%rcx,%rax,2),%eax
 1f81d2f:	or     %eax,%edx
 1f81d31:	mov    %esi,%eax
 1f81d33:	and    $0x2,%eax
 1f81d36:	mov    %rdx,0x1a0(%rsp)
 1f81d3e:	mov    %rsi,0x5b0(%rsp)
 1f81d46:	mov    %eax,0x570(%rsp)
 1f81d4d:	mov    %r8,0x530(%rsp)
 1f81d55:	je     1f81d72 <node_facts_window_run+0x49a2>
 1f81d57:	cmpb   $0x1,0x26(%r9)
 1f81d5c:	jne    1f81d72 <node_facts_window_run+0x49a2>
 1f81d5e:	movzbl 0x54(%r9),%eax
 1f81d63:	xor    %edx,%edx
 1f81d65:	shl    $0x11,%eax
 1f81d68:	add    %rax,0x1a0(%rsp)
 1f81d70:	jmp    1f81d74 <node_facts_window_run+0x49a4>
 1f81d72:	xor    %edx,%edx
 1f81d74:	mov    0xb70(%r9),%rcx
 1f81d7b:	mov    0xb78(%r9),%rax
 1f81d82:	mov    %r12d,%esi
 1f81d85:	mov    %ebp,%r8d
 1f81d88:	shr    $0x6,%r8d
 1f81d8c:	mov    %r12d,0x450(%rsp)
 1f81d94:	lea    (%rcx,%rsi,8),%rdi
 1f81d98:	lea    (%rax,%rsi,8),%r9
 1f81d9c:	mov    %rdi,0x4d0(%rsp)
 1f81da4:	mov    %r9,0x3d0(%rsp)
 1f81dac:	mov    %r10d,%r9d
 1f81daf:	and    $0x3f,%r10d
 1f81db3:	shr    $0x6,%r9d
 1f81db7:	lea    0x1(%r8),%rdi
 1f81dbb:	mov    %r10,0x30(%rsp)
 1f81dc0:	xor    $0x3f,%r10d
 1f81dc4:	mov    %r8,0x490(%rsp)
 1f81dcc:	mov    %rbp,0x10(%rsp)
 1f81dd1:	mov    %rdi,0x390(%rsp)
 1f81dd9:	mov    %rbp,%r8
 1f81ddc:	mov    %r9,0x5f0(%rsp)
 1f81de4:	cmp    $0x40,%ebp
 1f81de7:	jae    1f81e05 <node_facts_window_run+0x4a35>
 1f81de9:	mov    %r8,%r13
 1f81dec:	mov    $0xffffffff,%r14d
 1f81df2:	xor    %r8d,%r8d
 1f81df5:	movq   $0x0,0x20(%rsp)
 1f81dfe:	xor    %ebp,%ebp
 1f81e00:	jmp    1f82070 <node_facts_window_run+0x4ca0>
 1f81e05:	shr    $1,%edi
 1f81e07:	lea    0x8(%rcx,%rsi,8),%rcx
 1f81e0c:	lea    0x8(%rax,%rsi,8),%rax
 1f81e11:	shl    $0x6,%r9d
 1f81e15:	mov    $0xffffffff,%r14d
 1f81e1b:	mov    %r15,0x660(%rsp)
 1f81e23:	mov    %r8d,%r12d
 1f81e26:	xor    %r8d,%r8d
 1f81e29:	xor    %ebp,%ebp
 1f81e2b:	shl    $0x7,%rdi
 1f81e2f:	mov    %rcx,0x120(%rsp)
 1f81e37:	mov    %r9,0x28(%rsp)
 1f81e3c:	mov    %rax,0x38(%rsp)
 1f81e41:	mov    %rdi,0x1e0(%rsp)
 1f81e49:	xor    %r9d,%r9d
 1f81e4c:	movq   $0x0,0x20(%rsp)
 1f81e55:	data16 cs nopw 0x0(%rax,%rax,1)
 1f81e60:	mov    0x8(%rsp),%rdi
 1f81e65:	mov    %r12d,%r15d
 1f81e68:	sub    $0x40,%r15d
 1f81e6c:	mov    $0x40,%ecx
 1f81e71:	mov    0x28(%rsp),%r11
 1f81e76:	mov    0x30(%rsp),%rsi
 1f81e7b:	mov    $0x0,%eax
 1f81e80:	mov    0x120(%rsp),%rdx
 1f81e88:	cmovb  %r12d,%ecx
 1f81e8c:	cmp    0x10(%rsp),%r9
 1f81e91:	mov    0xb38(%rdi),%r13
 1f81e98:	cmovae %eax,%ecx
 1f81e9b:	mov    $0xffffffffffffffff,%rax
 1f81ea2:	add    %r11,%r13
 1f81ea5:	cmp    $0x40,%ecx
 1f81ea8:	shlx   %rcx,%rax,%rcx
 1f81ead:	mov    0x58(%r9,%r13,1),%rbx
 1f81eb2:	not    %rcx
 1f81eb5:	cmove  %rax,%rcx
 1f81eb9:	shrx   %rsi,0x18(%r9,%r13,1),%rax
 1f81ec0:	add    %rbx,%rbx
 1f81ec3:	shlx   %r10,%rbx,%rbx
 1f81ec8:	or     %rax,%rbx
 1f81ecb:	mov    0x48(%r9,%r13,1),%rax
 1f81ed0:	shrx   %rsi,0x8(%r9,%r13,1),%r13
 1f81ed7:	and    %rcx,%rbx
 1f81eda:	add    %rax,%rax
 1f81edd:	shlx   %r10,%rax,%rax
 1f81ee2:	or     %r13,%rax
 1f81ee5:	and    %rcx,%rax
 1f81ee8:	mov    %rax,-0x8(%rdx,%r8,8)
 1f81eed:	mov    0xb38(%rdi),%rax
 1f81ef4:	mov    %r14d,%edi
 1f81ef7:	mov    %r11,%r14
 1f81efa:	add    %r11,%rax
 1f81efd:	shrx   %rsi,0x10(%r9,%rax,1),%r11
 1f81f04:	mov    0x50(%r9,%rax,1),%rax
 1f81f09:	add    %rax,%rax
 1f81f0c:	shlx   %r10,%rax,%r13
 1f81f11:	mov    0x38(%rsp),%rax
 1f81f16:	or     %r11,%r13
 1f81f19:	mov    %r9d,%r11d
 1f81f1c:	and    %rcx,%r13
 1f81f1f:	mov    0x20(%rsp),%rcx
 1f81f24:	mov    %r13,-0x8(%rax,%r8,8)
 1f81f29:	popcnt %rbx,%rax
 1f81f2e:	add    %eax,%ecx
 1f81f30:	lzcnt  %rbx,%rax
 1f81f35:	sub    %eax,%r11d
 1f81f38:	lea    0x40(%r9),%rax
 1f81f3c:	add    $0x3f,%r11d
 1f81f40:	test   %rbx,%rbx
 1f81f43:	mov    %edi,%ebx
 1f81f45:	mov    $0x40,%edi
 1f81f4a:	cmovne %r11d,%ebx
 1f81f4e:	or     -0x8(%rdx,%r8,8),%rbp
 1f81f53:	cmp    $0x40,%r15d
 1f81f57:	mov    $0xffffffffffffffff,%r11
 1f81f5e:	cmovae %edi,%r15d
 1f81f62:	cmp    0x10(%rsp),%rax
 1f81f67:	mov    0x8(%rsp),%rdi
 1f81f6c:	mov    $0x0,%eax
 1f81f71:	cmovae %eax,%r15d
 1f81f75:	mov    0xb38(%rdi),%rax
 1f81f7c:	add    %r14,%rax
 1f81f7f:	shlx   %r15,%r11,%r14
 1f81f84:	cmp    $0x40,%r15d
 1f81f88:	mov    0x98(%r9,%rax,1),%r15
 1f81f90:	not    %r14
 1f81f93:	cmove  %r11,%r14
 1f81f97:	shrx   %rsi,0x58(%r9,%rax,1),%r11
 1f81f9e:	add    %r15,%r15
 1f81fa1:	shlx   %r10,%r15,%r15
 1f81fa6:	or     %r11,%r15
 1f81fa9:	mov    0x88(%r9,%rax,1),%r11
 1f81fb1:	shrx   %rsi,0x48(%r9,%rax,1),%rax
 1f81fb8:	and    %r14,%r15
 1f81fbb:	add    %r11,%r11
 1f81fbe:	shlx   %r10,%r11,%r11
 1f81fc3:	or     %rax,%r11
 1f81fc6:	and    %r14,%r11
 1f81fc9:	mov    %r11,(%rdx,%r8,8)
 1f81fcd:	mov    0xb38(%rdi),%rax
 1f81fd4:	add    0x28(%rsp),%rax
 1f81fd9:	shrx   %rsi,0x50(%r9,%rax,1),%r11
 1f81fe0:	mov    0x90(%r9,%rax,1),%rax
 1f81fe8:	popcnt %r15,%rsi
 1f81fed:	add    %ecx,%esi
 1f81fef:	lzcnt  %r15,%rcx
 1f81ff4:	mov    %rsi,0x20(%rsp)
 1f81ff9:	mov    0x38(%rsp),%rsi
 1f81ffe:	add    %rax,%rax
 1f82001:	shlx   %r10,%rax,%rax
 1f82006:	or     %r11,%rax
 1f82009:	and    %r14,%rax
 1f8200c:	mov    %r9d,%r14d
 1f8200f:	sub    %ecx,%r14d
 1f82012:	add    $0x7f,%r14d
 1f82016:	test   %r15,%r15
 1f82019:	mov    %rax,(%rsi,%r8,8)
 1f8201d:	cmove  %ebx,%r14d
 1f82021:	or     (%rdx,%r8,8),%rbp
 1f82025:	add    $0x2,%r8
 1f82029:	sub    $0xffffffffffffff80,%r9
 1f8202d:	add    $0xffffff80,%r12d
 1f82031:	or     %r13,%rbp
 1f82034:	or     %rax,%rbp
 1f82037:	cmp    %r9,0x1e0(%rsp)
 1f8203f:	jne    1f81e60 <node_facts_window_run+0x4a90>
 1f82045:	mov    0x490(%rsp),%rax
 1f8204d:	mov    (%rsp),%r11
 1f82051:	mov    0x660(%rsp),%r15
 1f82059:	mov    0x10(%rsp),%r13
 1f8205e:	mov    $0x40,%ebx
 1f82063:	xor    %edx,%edx
 1f82065:	inc    %rax
 1f82068:	test   $0x1,%al
 1f8206a:	je     1f82160 <node_facts_window_run+0x4d90>
 1f82070:	mov    0x8(%rsp),%r12
 1f82075:	mov    0x5f0(%rsp),%rax
 1f8207d:	mov    %r8,%r9
 1f82080:	shl    $0x6,%r9
 1f82084:	mov    %r13d,%ecx
 1f82087:	mov    0x30(%rsp),%r11
 1f8208c:	sub    %r9d,%ecx
 1f8208f:	cmp    $0x40,%ecx
 1f82092:	cmovae %ebx,%ecx
 1f82095:	cmp    %r13,%r9
 1f82098:	cmovae %edx,%ecx
 1f8209b:	mov    $0xffffffffffffffff,%rdx
 1f820a2:	mov    0xb38(%r12),%rsi
 1f820aa:	add    %r8,%rax
 1f820ad:	shl    $0x6,%rax
 1f820b1:	cmp    $0x40,%ecx
 1f820b4:	shlx   %rcx,%rdx,%rcx
 1f820b9:	not    %rcx
 1f820bc:	cmove  %rdx,%rcx
 1f820c0:	mov    0x58(%rsi,%rax,1),%rdx
 1f820c5:	mov    0x48(%rsi,%rax,1),%rbx
 1f820ca:	shrx   %r11,0x18(%rsi,%rax,1),%rdi
 1f820d1:	shrx   %r11,0x8(%rsi,%rax,1),%rsi
 1f820d8:	add    %rdx,%rdx
 1f820db:	add    %rbx,%rbx
 1f820de:	shlx   %r10,%rdx,%rdx
 1f820e3:	or     %rdi,%rdx
 1f820e6:	shlx   %r10,%rbx,%rdi
 1f820eb:	mov    0x4d0(%rsp),%rbx
 1f820f3:	or     %rsi,%rdi
 1f820f6:	and    %rcx,%rdx
 1f820f9:	and    %rcx,%rdi
 1f820fc:	mov    %rdi,(%rbx,%r8,8)
 1f82100:	mov    0xb38(%r12),%rsi
 1f82108:	shrx   %r11,0x10(%rsi,%rax,1),%rdi
 1f8210f:	mov    0x50(%rsi,%rax,1),%rsi
 1f82114:	mov    0x20(%rsp),%rax
 1f82119:	mov    (%rsp),%r11
 1f8211d:	add    %rsi,%rsi
 1f82120:	shlx   %r10,%rsi,%rsi
 1f82125:	or     %rdi,%rsi
 1f82128:	mov    %r14d,%edi
 1f8212b:	lea    0x3f(%r9),%r14d
 1f8212f:	and    %rcx,%rsi
 1f82132:	popcnt %rdx,%rcx
 1f82137:	add    %eax,%ecx
 1f82139:	mov    %rcx,0x20(%rsp)
 1f8213e:	lzcnt  %rdx,%rcx
 1f82143:	mov    0x3d0(%rsp),%rax
 1f8214b:	sub    %ecx,%r14d
 1f8214e:	test   %rdx,%rdx
 1f82151:	cmove  %edi,%r14d
 1f82155:	mov    %rsi,(%rax,%r8,8)
 1f82159:	or     (%rbx,%r8,8),%rbp
 1f8215d:	or     %rsi,%rbp
 1f82160:	test   %r13d,%r13d
 1f82163:	je     1f82192 <node_facts_window_run+0x4dc2>
 1f82165:	lea    -0x1(%r13),%rax
 1f82169:	mov    $0xffffffff,%ebx
 1f8216e:	shr    $0x4,%rax
 1f82172:	inc    %rax
 1f82175:	mov    %eax,%edx
 1f82177:	and    $0x3,%edx
 1f8217a:	cmp    $0x31,%r13d
 1f8217e:	jae    1f821b0 <node_facts_window_run+0x4de0>
 1f82180:	vpxor  %xmm0,%xmm0,%xmm0
 1f82184:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f8218b:	xor    %ecx,%ecx
 1f8218d:	jmp    1f822f3 <node_facts_window_run+0x4f23>
 1f82192:	mov    0x8(%rsp),%r8
 1f82197:	mov    0x530(%rsp),%rdi
 1f8219f:	mov    0x50(%rsp),%r13
 1f821a4:	xor    %edx,%edx
 1f821a6:	mov    $0xffffffff,%ecx
 1f821ab:	jmp    1f823ce <node_facts_window_run+0x4ffe>
 1f821b0:	mov    %r15,0x660(%rsp)
 1f821b8:	and    $0xfffffffffffffffc,%rax
 1f821bc:	lea    -0x30(%r13),%edi
 1f821c0:	lea    -0x20(%r13),%r8d
 1f821c4:	lea    -0x10(%r13),%r9d
 1f821c8:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f821cf:	mov    $0xffff,%r15d
 1f821d5:	vpxor  %xmm0,%xmm0,%xmm0
 1f821d9:	mov    0x60(%rsp),%rcx
 1f821de:	mov    0x160(%rsp),%rsi
 1f821e6:	lea    (%rcx,%rsi,4),%rsi
 1f821ea:	xor    %ecx,%ecx
 1f821ec:	nopl   0x0(%rax)
 1f821f0:	lea    0x0(%r13,%rcx,1),%r10
 1f821f5:	shlx   %r10d,%ebx,%r11d
 1f821fa:	sub    $0x10,%r10
 1f821fe:	not    %r11d
 1f82201:	cmovae %r15d,%r11d
 1f82205:	cmp    $0x10,%r10
 1f82209:	kmovd  %r11d,%k1
 1f8220e:	lea    (%r9,%rcx,1),%r11d
 1f82212:	vmovdqu32 -0xc0(%rsi),%zmm2{%k1}{z}
 1f82219:	shlx   %r11d,%ebx,%r10d
 1f8221e:	lea    (%r8,%rcx,1),%r11d
 1f82222:	not    %r10d
 1f82225:	cmovae %r15d,%r10d
 1f82229:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82230:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f82236:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f8223c:	kmovd  %r10d,%k1
 1f82241:	lea    -0x20(%r13,%rcx,1),%r10
 1f82246:	vmovdqu32 -0x80(%rsi),%zmm2{%k1}{z}
 1f8224d:	cmp    $0x10,%r10
 1f82251:	shlx   %r11d,%ebx,%r10d
 1f82256:	lea    (%rdi,%rcx,1),%r11d
 1f8225a:	not    %r10d
 1f8225d:	cmovae %r15d,%r10d
 1f82261:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82268:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f8226e:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82274:	kmovd  %r10d,%k1
 1f82279:	lea    -0x30(%r13,%rcx,1),%r10
 1f8227e:	vmovdqu32 -0x40(%rsi),%zmm2{%k1}{z}
 1f82285:	cmp    $0x10,%r10
 1f82289:	shlx   %r11d,%ebx,%r10d
 1f8228e:	not    %r10d
 1f82291:	cmovae %r15d,%r10d
 1f82295:	add    $0xffffffffffffffc0,%rcx
 1f82299:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f822a0:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f822a6:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f822ac:	kmovd  %r10d,%k1
 1f822b1:	vmovdqu32 (%rsi),%zmm2{%k1}{z}
 1f822b7:	add    $0x100,%rsi
 1f822be:	add    $0xfffffffffffffffc,%rax
 1f822c2:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f822c9:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f822cf:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f822d5:	jne    1f821f0 <node_facts_window_run+0x4e20>
 1f822db:	mov    0x660(%rsp),%r15
 1f822e3:	test   %rdx,%rdx
 1f822e6:	je     1f82782 <node_facts_window_run+0x53b2>
 1f822ec:	mov    (%rsp),%r11
 1f822f0:	neg    %rcx
 1f822f3:	mov    0x160(%rsp),%rax
 1f822fb:	mov    0x10(%rsp),%rsi
 1f82300:	mov    0x8(%rsp),%r8
 1f82305:	mov    0x50(%rsp),%r13
 1f8230a:	mov    $0xffff,%r10d
 1f82310:	shl    $0x4,%edx
 1f82313:	lea    0x0(,%rax,4),%rax
 1f8231b:	sub    %rcx,%rsi
 1f8231e:	lea    (%rax,%rcx,4),%rax
 1f82322:	add    0xe0(%rsp),%rax
 1f8232a:	xor    %ecx,%ecx
 1f8232c:	nopl   0x0(%rax)
 1f82330:	mov    %esi,%edi
 1f82332:	sub    $0x10,%rsi
 1f82336:	shlx   %edi,%ebx,%edi
 1f8233b:	not    %edi
 1f8233d:	cmovae %r10d,%edi
 1f82341:	kmovd  %edi,%k1
 1f82345:	vmovdqu32 (%rax,%rcx,4),%zmm2{%k1}{z}
 1f8234c:	add    $0x10,%rcx
 1f82350:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82357:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f8235d:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82363:	cmp    %rcx,%rdx
 1f82366:	jne    1f82330 <node_facts_window_run+0x4f60>
 1f82368:	vextracti64x4 $0x1,%zmm1,%ymm2
 1f8236f:	mov    0x530(%rsp),%rdi
 1f82377:	vpminud %ymm2,%ymm1,%ymm1
 1f8237c:	vextracti128 $0x1,%ymm1,%xmm2
 1f82382:	vpminud %xmm2,%xmm1,%xmm1
 1f82387:	vpshufd $0xee,%xmm1,%xmm2
 1f8238c:	vpminud %xmm2,%xmm1,%xmm1
 1f82391:	vpshufd $0x55,%xmm1,%xmm2
 1f82396:	vpminud %xmm2,%xmm1,%xmm1
 1f8239b:	vmovd  %xmm1,%ecx
 1f8239f:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f823a6:	vpmaxud %ymm1,%ymm0,%ymm0
 1f823ab:	vextracti128 $0x1,%ymm0,%xmm1
 1f823b1:	vpmaxud %xmm1,%xmm0,%xmm0
 1f823b6:	vpshufd $0xee,%xmm0,%xmm1
 1f823bb:	vpmaxud %xmm1,%xmm0,%xmm0
 1f823c0:	vpshufd $0x55,%xmm0,%xmm1
 1f823c5:	vpmaxud %xmm1,%xmm0,%xmm0
 1f823ca:	vmovd  %xmm0,%edx
 1f823ce:	mov    0x310(%rsp),%eax
 1f823d5:	and    $0x100,%eax
 1f823da:	mov    %edi,%r10d
 1f823dd:	or     %rax,0x1a0(%rsp)
 1f823e5:	mov    0x350(%rsp),%eax
 1f823ec:	mov    0x18(%rsp),%rsi
 1f823f1:	cmp    0x10(%rsp),%eax
 1f823f5:	mov    0x290(%rsp),%rax
 1f823fd:	cmovbe %eax,%r10d
 1f82401:	mov    0x422c(%rsi,%r10,4),%esi
 1f82409:	mov    %rsi,0x28(%rsp)
 1f8240e:	mov    %r10,0x120(%rsp)
 1f82416:	ja     1f8241e <node_facts_window_run+0x504e>
 1f82418:	xor    %esi,%esi
 1f8241a:	xor    %edi,%edi
 1f8241c:	jmp    1f82443 <node_facts_window_run+0x5073>
 1f8241e:	mov    %rdi,%r9
 1f82421:	mov    0xb38(%r8),%rdi
 1f82428:	mov    %r9d,%r8d
 1f8242b:	and    $0xffffffc0,%r8d
 1f8242f:	shrx   %r9,0x8(%rdi,%r8,1),%rsi
 1f82436:	shrx   %r9,0x10(%rdi,%r8,1),%rdi
 1f8243d:	and    $0x1,%esi
 1f82440:	and    $0x1,%edi
 1f82443:	mov    0x10(%rsp),%r9
 1f82448:	mov    0x490(%rsp),%r10
 1f82450:	mov    0x4d0(%rsp),%rbx
 1f82458:	or     %rsi,%rbp
 1f8245b:	mov    0x3d0(%rsp),%r12
 1f82463:	mov    %edx,%eax
 1f82465:	or     %rdi,%rbp
 1f82468:	shlx   %r9,%rsi,%r8
 1f8246d:	mov    0x28(%rsp),%rsi
 1f82472:	shl    $0x3,%r10d
 1f82476:	or     %r8,(%rbx,%r10,1)
 1f8247a:	shlx   %r9,%rdi,%r8
 1f8247f:	mov    0x8(%rsp),%rdi
 1f82484:	or     %r8,(%r12,%r10,1)
 1f82488:	mov    %ecx,%r8d
 1f8248b:	mov    0x2d0(%rsp),%r10
 1f82493:	cmp    %ecx,%esi
 1f82495:	cmovb  %esi,%r8d
 1f82499:	cmp    %edx,%esi
 1f8249b:	cmova  %esi,%eax
 1f8249e:	cmp    0xa0(%rsp),%esi
 1f824a5:	cmovae %ecx,%r8d
 1f824a9:	cmovae %edx,%eax
 1f824ac:	mov    0x1a0(%rsp),%rcx
 1f824b4:	mov    0x390(%rsp),%rdx
 1f824bc:	mov    %rcx,(%r10)
 1f824bf:	mov    %rbx,0x8(%r10)
 1f824c3:	mov    %r12,0x10(%r10)
 1f824c7:	mov    %edx,0x18(%r10)
 1f824cb:	mov    0x160(%rsp),%rdx
 1f824d3:	mov    %r8d,0x38(%rsp)
 1f824d8:	mov    %eax,0x30(%rsp)
 1f824dc:	mov    0xb10(%rdi),%rcx
 1f824e3:	add    %rdx,%rcx
 1f824e6:	mov    %rcx,0x20(%r10)
 1f824ea:	mov    0xb20(%rdi),%rcx
 1f824f1:	add    %rdx,%rcx
 1f824f4:	mov    %rcx,0x28(%r10)
 1f824f8:	mov    0x570(%rsp),%ecx
 1f824ff:	add    0xb28(%rdi),%rdx
 1f82506:	mov    %rdx,0x30(%r10)
 1f8250a:	mov    %r8d,0x38(%r10)
 1f8250e:	mov    %eax,0x3c(%r10)
 1f82512:	mov    0x20(%rsp),%rax
 1f82517:	mov    $0x0,%r8d
 1f8251d:	mov    %eax,0x40(%r10)
 1f82521:	mov    0x310(%rsp),%eax
 1f82528:	mov    %r14d,0x44(%r10)
 1f8252c:	mov    %ecx,0x48(%r10)
 1f82530:	and    $0x80,%eax
 1f82535:	cmpl   $0x0,0x80(%rsp)
 1f8253d:	mov    %eax,0x4c(%r10)
 1f82541:	je     1f82580 <node_facts_window_run+0x51b0>
 1f82543:	mov    0x28(%rsp),%rcx
 1f82548:	cmp    0xa0(%rsp),%ecx
 1f8254f:	cmovae %r8d,%ecx
 1f82553:	jae    1f82580 <node_facts_window_run+0x51b0>
 1f82555:	mov    0xb08(%rdi),%rdx
 1f8255c:	mov    %ecx,%esi
 1f8255e:	mov    $0x1,%r10d
 1f82564:	shr    $0x6,%ecx
 1f82567:	mov    $0x6,%r9d
 1f8256d:	shlx   %rsi,%r10,%rsi
 1f82572:	mov    0x2d0(%rsp),%r10
 1f8257a:	and    (%rdx,%rcx,8),%rsi
 1f8257e:	jne    1f825ae <node_facts_window_run+0x51de>
 1f82580:	mov    0xb8(%rsp),%rcx
 1f82588:	mov    0x120(%rsp),%rax
 1f82590:	movzbl (%rcx,%rax,1),%eax
 1f82594:	and    $0x7f,%eax
 1f82597:	cmpl   $0x0,0x7c0(%rsp)
 1f8259f:	movzbl 0x448(%rdi,%rax,1),%r9d
 1f825a8:	jne    1f827de <node_facts_window_run+0x540e>
 1f825ae:	mov    0x10(%rsp),%rsi
 1f825b3:	mov    0x290(%rsp),%rbx
 1f825bb:	mov    0xb38(%rdi),%rdx
 1f825c2:	mov    0x20(%rsp),%r12
 1f825c7:	cmp    %esi,0x350(%rsp)
 1f825ce:	mov    %ebx,%ecx
 1f825d0:	setbe  %al
 1f825d3:	and    $0xffffffc0,%ecx
 1f825d6:	inc    %r14d
 1f825d9:	shrx   %rbx,0x20(%rdx,%rcx,1),%rcx
 1f825e0:	mov    0x5b0(%rsp),%rbx
 1f825e8:	xor    %esi,%r14d
 1f825eb:	mov    0x90(%rsp),%esi
 1f825f2:	mov    %r12d,%edx
 1f825f5:	xor    $0x1,%edx
 1f825f8:	and    $0x22,%ebx
 1f825fb:	cmp    $0x2,%r9d
 1f825ff:	cmovne %r8d,%esi
 1f82603:	test   %ebx,%ebx
 1f82605:	mov    %rdi,%r8
 1f82608:	cmove  %ebx,%esi
 1f8260b:	test   %rbp,%rbp
 1f8260e:	mov    $0x0,%ebx
 1f82613:	setne  %dil
 1f82617:	or     %al,%dil
 1f8261a:	or     %r14d,%edx
 1f8261d:	mov    0x40(%rsp),%rdx
 1f82622:	cmovne 0x78(%rsp),%ebx
 1f82627:	test   %r12d,%r12d
 1f8262a:	movzbl %dil,%eax
 1f8262e:	mov    %r8,%rdi
 1f82631:	cmove  %r12d,%ebx
 1f82635:	or     %eax,%ebx
 1f82637:	xor    %eax,%eax
 1f82639:	test   %r9d,%r9d
 1f8263c:	sete   %al
 1f8263f:	or     %esi,%ebx
 1f82641:	andn   %eax,%ecx,%eax
 1f82646:	mov    $0x101,%ecx
 1f8264b:	or     %eax,%ebx
 1f8264d:	mov    0xa88(%r11),%rax
 1f82654:	movzbl (%rax,%r15,1),%eax
 1f82659:	bextr  %ecx,%eax,%eax
 1f8265e:	or     %eax,%ebx
 1f82660:	xor    %eax,%eax
 1f82662:	cmp    $0x6,%r9d
 1f82666:	sete   %al
 1f82669:	lea    (%rdx,%rax,4),%r14
 1f8266d:	or     0x1a0(%rsp),%r14
 1f82675:	cmpb   $0x1,0x3b(%r8)
 1f8267a:	jne    1f826da <node_facts_window_run+0x530a>
 1f8267c:	mov    0x18(%rsp),%rbp
 1f82681:	mov    0x450(%rsp),%r12d
 1f82689:	mov    0x28(%rsp),%rsi
 1f8268e:	test   %ebx,%ebx
 1f82690:	jne    1f826ec <node_facts_window_run+0x531c>
 1f82692:	mov    0xa8(%rsp),%rax
 1f8269a:	mov    0x8(%rax),%rdx
 1f8269e:	mov    0x78(%rdx),%eax
 1f826a1:	cmp    %eax,%esi
 1f826a3:	jae    1f826ec <node_facts_window_run+0x531c>
 1f826a5:	mov    0x98(%rdx),%rcx
 1f826ac:	movzbl (%rcx,%rsi,1),%r8d
 1f826b1:	cmp    $0x4a,%r8d
 1f826b5:	je     1f826d1 <node_facts_window_run+0x5301>
 1f826b7:	cmp    $0x1e,%r8d
 1f826bb:	jne    1f826ec <node_facts_window_run+0x531c>
 1f826bd:	mov    0xa8(%rdx),%rdx
 1f826c4:	mov    (%rdx,%rsi,4),%edx
 1f826c7:	cmp    %eax,%edx
 1f826c9:	jae    1f826ec <node_facts_window_run+0x531c>
 1f826cb:	cmpb   $0x4a,(%rcx,%rdx,1)
 1f826cf:	jne    1f826ec <node_facts_window_run+0x531c>
 1f826d1:	or     $0x1000000,%r14
 1f826d8:	jmp    1f826ec <node_facts_window_run+0x531c>
 1f826da:	mov    0x18(%rsp),%rbp
 1f826df:	mov    0x450(%rsp),%r12d
 1f826e7:	mov    0x28(%rsp),%rsi
 1f826ec:	cmpl   $0x0,0xb00(%rdi)
 1f826f3:	mov    0x38(%rsp),%edx
 1f826f7:	mov    0x30(%rsp),%ecx
 1f826fb:	jne    1f82795 <node_facts_window_run+0x53c5>
 1f82701:	cmp    0xae8(%rdi),%edx
 1f82707:	ja     1f82715 <node_facts_window_run+0x5345>
 1f82709:	cmp    0xae4(%rdi),%ecx
 1f8270f:	jae    1f82795 <node_facts_window_run+0x53c5>
 1f82715:	mov    %r14,0x50(%r10)
 1f82719:	mov    %r9b,0x60(%r10)
 1f8271d:	mov    %edx,0x58(%r10)
 1f82721:	mov    %ecx,0x5c(%r10)
 1f82725:	mov    %bl,0x62(%r10)
 1f82729:	mov    0x220(%rsp),%rdx
 1f82731:	or     0x98(%rsp),%ebx
 1f82738:	mov    0x390(%rsp),%rsi
 1f82740:	mov    $0xffffffffffffffff,%r14
 1f82747:	mov    0xb88(%rdi),%rax
 1f8274e:	mov    %edx,%ecx
 1f82750:	add    %ebx,%edx
 1f82752:	add    %r12d,%esi
 1f82755:	mov    $0x40,%ebx
 1f8275a:	mov    %rdx,0x220(%rsp)
 1f82762:	mov    %r15d,(%rax,%rcx,4)
 1f82766:	mov    %esi,%r12d
 1f82769:	mov    0x48(%rsp),%r9
 1f8276e:	jmp    1f81a24 <node_facts_window_run+0x4654>
 1f82773:	mov    0x8(%rsp),%r9
 1f82778:	mov    0x30(%rsp),%r10
 1f8277d:	jmp    1f81c9e <node_facts_window_run+0x48ce>
 1f82782:	mov    (%rsp),%r11
 1f82786:	mov    0x8(%rsp),%r8
 1f8278b:	mov    0x50(%rsp),%r13
 1f82790:	jmp    1f82368 <node_facts_window_run+0x4f98>
 1f82795:	vmovdqu64 %zmm3,0x120(%rsp)
 1f827a0:	mov    %r9d,0x10(%rsp)
 1f827a5:	vzeroupper
 1f827a8:	call   1f6a000 <node_census_reader_marks>
 1f827ad:	vmovdqu64 0x120(%rsp),%zmm3
 1f827b8:	mov    0x10(%rsp),%r9d
 1f827bd:	mov    0x2d0(%rsp),%r10
 1f827c5:	mov    0x8(%rsp),%rdi
 1f827ca:	mov    (%rsp),%r11
 1f827ce:	mov    0x30(%rsp),%ecx
 1f827d2:	mov    0x38(%rsp),%edx
 1f827d6:	or     %rax,%r14
 1f827d9:	jmp    1f82715 <node_facts_window_run+0x5345>
 1f827de:	cmp    $0x2,%r9d
 1f827e2:	jne    1f825ae <node_facts_window_run+0x51de>
 1f827e8:	mov    0xa8(%rsp),%rax
 1f827f0:	mov    0x28(%rsp),%rdx
 1f827f5:	vmovdqu64 %zmm3,0x120(%rsp)
 1f82800:	mov    (%rax),%rax
 1f82803:	mov    0x6e0(%rax),%rdi
 1f8280a:	mov    0x6e8(%rax),%esi
 1f82810:	vzeroupper
 1f82813:	call   1f69be0 <node_census_cleans>
 1f82818:	vmovdqu64 0x120(%rsp),%zmm3
 1f82823:	mov    0x2d0(%rsp),%r10
 1f8282b:	mov    0x8(%rsp),%rdi
 1f82830:	mov    (%rsp),%r11
 1f82834:	movzbl %al,%eax
 1f82837:	xor    %r8d,%r8d
 1f8283a:	lea    0x2(,%rax,4),%r9d
 1f82842:	jmp    1f825ae <node_facts_window_run+0x51de>
 1f82847:	rdtsc
 1f82849:	mov    %rdx,0x38(%rsp)
 1f8284e:	mov    %rax,0x28(%rsp)
 1f82853:	cmpb   $0x0,0x68(%rsp)
 1f82858:	je     1f829d4 <node_facts_window_run+0x5604>
 1f8285e:	cmpl   $0x0,0xa90(%r11)
 1f82866:	je     1f829d4 <node_facts_window_run+0x5604>
 1f8286c:	mov    $0xffffffffffffffff,%rdx
 1f82873:	xor    %r9d,%r9d
 1f82876:	xor    %ecx,%ecx
 1f82878:	jmp    1f82893 <node_facts_window_run+0x54c3>
 1f8287a:	nopw   0x0(%rax,%rax,1)
 1f82880:	mov    0xa90(%r11),%eax
 1f82887:	inc    %rcx
 1f8288a:	cmp    %rax,%rcx
 1f8288d:	jae    1f829d4 <node_facts_window_run+0x5604>
 1f82893:	imul   $0x68,%rcx,%r10
 1f82897:	cmpb   $0x0,0x61(%r13,%r10,1)
 1f8289d:	je     1f82880 <node_facts_window_run+0x54b0>
 1f8289f:	mov    0xa68(%r11),%rdi
 1f828a6:	mov    0xa70(%r11),%r8
 1f828ad:	add    %r13,%r10
 1f828b0:	mov    $0x40,%esi
 1f828b5:	mov    (%rdi,%rcx,4),%eax
 1f828b8:	mov    (%r8,%rcx,4),%r11d
 1f828bc:	mov    0x10(%r10),%r8
 1f828c0:	mov    %rax,0x20(%rsp)
 1f828c5:	mov    %rcx,0x10(%rsp)
 1f828ca:	mov    0x651b8(%rbp,%r11,4),%edi
 1f828d2:	mov    0x8(%rsp),%rcx
 1f828d7:	sub    0xb78(%rcx),%r8
 1f828de:	add    0xb80(%rcx),%r8
 1f828e5:	cmpl   $0x0,0x18(%r10)
 1f828ea:	je     1f8297b <node_facts_window_run+0x55ab>
 1f828f0:	sub    %edi,%r11d
 1f828f3:	mov    %edi,%r13d
 1f828f6:	xor    %r15d,%r15d
 1f828f9:	xor    %r12d,%r12d
 1f828fc:	mov    %edi,%ebp
 1f828fe:	inc    %r11d
 1f82901:	mov    %r11d,%ebx
 1f82904:	and    $0x3f,%r11d
 1f82908:	and    $0xffffffc0,%ebx
 1f8290b:	mov    %r11d,%r14d
 1f8290e:	xor    $0x3f,%r14d
 1f82912:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82920:	sub    $0x40,%ebp
 1f82923:	cmovae %esi,%r13d
 1f82927:	cmp    %r15d,%edi
 1f8292a:	cmovbe %r9d,%r13d
 1f8292e:	mov    0xb38(%rcx),%r9
 1f82935:	add    %rbx,%r9
 1f82938:	cmp    $0x40,%r13d
 1f8293c:	shlx   %r13,%rdx,%r13
 1f82941:	shrx   %r11,(%r15,%r9,1),%rax
 1f82947:	mov    0x40(%r15,%r9,1),%r9
 1f8294c:	not    %r13
 1f8294f:	cmove  %rdx,%r13
 1f82953:	add    $0x40,%r15
 1f82957:	add    %r9,%r9
 1f8295a:	shlx   %r14,%r9,%r9
 1f8295f:	or     %rax,%r9
 1f82962:	and    %r13,%r9
 1f82965:	mov    %ebp,%r13d
 1f82968:	mov    %r9,(%r8,%r12,8)
 1f8296c:	inc    %r12
 1f8296f:	xor    %r9d,%r9d
 1f82972:	mov    0x18(%r10),%eax
 1f82976:	cmp    %rax,%r12
 1f82979:	jb     1f82920 <node_facts_window_run+0x5550>
 1f8297b:	mov    (%rsp),%r11
 1f8297f:	mov    0x10(%rsp),%rcx
 1f82984:	mov    0x18(%rsp),%rbp
 1f82989:	mov    0x50(%rsp),%r13
 1f8298e:	mov    0xa58(%r11),%r10
 1f82995:	cmp    %edi,(%r10,%rcx,4)
 1f82999:	jbe    1f82880 <node_facts_window_run+0x54b0>
 1f8299f:	mov    0x8(%rsp),%rax
 1f829a4:	mov    0x20(%rsp),%rsi
 1f829a9:	mov    0xb38(%rax),%rax
 1f829b0:	mov    %esi,%r9d
 1f829b3:	and    $0xffffffc0,%r9d
 1f829b7:	shrx   %rsi,(%rax,%r9,1),%rax
 1f829bd:	xor    %r9d,%r9d
 1f829c0:	and    $0x1,%eax
 1f829c3:	shlx   %rdi,%rax,%rax
 1f829c8:	shr    $0x6,%edi
 1f829cb:	or     %rax,(%r8,%rdi,8)
 1f829cf:	jmp    1f82880 <node_facts_window_run+0x54b0>
 1f829d4:	shlq   $0x20,0xe8(%rsp)
 1f829dd:	shlq   $0x20,0x430(%rsp)
 1f829e6:	shlq   $0x20,0x410(%rsp)
 1f829ef:	shlq   $0x20,0x38(%rsp)
 1f829f5:	lea    0x890(%rsp),%rdi
 1f829fd:	mov    $0x418,%edx
 1f82a02:	mov    0xb0(%rsp),%rbx
 1f82a0a:	mov    %rbx,%rsi
 1f82a0d:	vzeroupper
 1f82a10:	call   355e9b0 <memcpy>
 1f82a15:	mov    0x220(%rsp),%rax
 1f82a1d:	movb   $0x0,0x5b(%rbx)
 1f82a21:	test   %eax,%eax
 1f82a23:	je     1f82cd0 <node_facts_window_run+0x5900>
 1f82a29:	mov    (%rsp),%rdi
 1f82a2d:	mov    0x8(%rsp),%r9
 1f82a32:	mov    %eax,%r14d
 1f82a35:	xor    %r15d,%r15d
 1f82a38:	jmp    1f82a88 <node_facts_window_run+0x56b8>
 1f82a3a:	nopw   0x0(%rax,%rax,1)
 1f82a40:	movzbl 0x760(%rsp),%ecx
 1f82a48:	mov    (%rsp),%rdi
 1f82a4c:	mov    0x8(%rsp),%r9
 1f82a51:	xor    %edx,%edx
 1f82a53:	add    %rdx,0x8a0(%r8)
 1f82a5a:	mov    %rax,0x50(%r12)
 1f82a5f:	mov    %cl,0x60(%r12)
 1f82a64:	inc    %r15
 1f82a67:	mov    0x534(%r9),%eax
 1f82a6e:	mov    %eax,0x58(%r12)
 1f82a73:	mov    0x538(%r9),%eax
 1f82a7a:	mov    %eax,0x5c(%r12)
 1f82a7f:	cmp    %r15,%r14
 1f82a82:	je     1f82c6f <node_facts_window_run+0x589f>
 1f82a88:	mov    0xb88(%r9),%rax
 1f82a8f:	mov    0xa68(%rdi),%r8
 1f82a96:	mov    0xa70(%rdi),%rcx
 1f82a9d:	mov    (%rax,%r15,4),%r12d
 1f82aa1:	mov    0xa58(%rdi),%rax
 1f82aa8:	mov    (%r8,%r12,4),%ebp
 1f82aac:	mov    (%rcx,%r12,4),%r13d
 1f82ab0:	mov    0xa48(%rdi),%r8
 1f82ab7:	mov    0xa50(%rdi),%rcx
 1f82abe:	mov    0xb0(%rsp),%rdi
 1f82ac6:	mov    (%rcx,%r12,4),%ebx
 1f82aca:	mov    (%r8,%r12,4),%esi
 1f82ace:	mov    (%rax,%r12,4),%ecx
 1f82ad2:	mov    %ebx,%edx
 1f82ad4:	call   1f530c0 <node_machine_type>
 1f82ad9:	mov    (%rsp),%rax
 1f82add:	mov    0x8(%rsp),%rdi
 1f82ae2:	mov    0x18(%rsp),%rcx
 1f82ae7:	mov    0xa58(%rax),%rax
 1f82aee:	mov    (%rax,%r12,4),%eax
 1f82af2:	cmp    0x651b8(%rcx,%r13,4),%eax
 1f82afa:	jbe    1f82b33 <node_facts_window_run+0x5763>
 1f82afc:	inc    %r13d
 1f82aff:	cmp    %r13d,%ebp
 1f82b02:	je     1f82b33 <node_facts_window_run+0x5763>
 1f82b04:	mov    0xb10(%rdi),%rdx
 1f82b0b:	mov    0xb20(%rdi),%rsi
 1f82b12:	mov    %r13d,%eax
 1f82b15:	mov    0xb28(%rdi),%rcx
 1f82b1c:	movzbl (%rdx,%rbp,1),%r8d
 1f82b21:	mov    %r8b,(%rdx,%rax,1)
 1f82b25:	movzbl (%rsi,%rbp,1),%edx
 1f82b29:	mov    %dl,(%rsi,%rax,1)
 1f82b2c:	movzbl (%rcx,%rbp,1),%edx
 1f82b30:	mov    %dl,(%rcx,%rax,1)
 1f82b33:	mov    0x18(%rsp),%rax
 1f82b38:	xor    %r9d,%r9d
 1f82b3b:	mov    0xa8(%rsp),%rdx
 1f82b43:	mov    $0xffffffff,%r8d
 1f82b49:	mov    0x422c(%rax,%rbp,4),%ecx
 1f82b50:	cmpb   $0x23,0x2c(%rax,%rbp,1)
 1f82b55:	jne    1f82b90 <node_facts_window_run+0x57c0>
 1f82b57:	mov    0x50(%rsp),%r13
 1f82b5c:	cmp    0xa0(%rsp),%ecx
 1f82b63:	jae    1f82b95 <node_facts_window_run+0x57c5>
 1f82b65:	mov    0x338(%rdx),%rax
 1f82b6c:	mov    (%rdx),%rsi
 1f82b6f:	mov    (%rax,%rcx,4),%r8d
 1f82b73:	cmp    0x764(%rsi),%r8d
 1f82b7a:	jae    1f82b95 <node_facts_window_run+0x57c5>
 1f82b7c:	mov    0x1e8(%rdx),%rax
 1f82b83:	mov    (%rax,%r8,4),%r9d
 1f82b87:	jmp    1f82b95 <node_facts_window_run+0x57c5>
 1f82b89:	nopl   0x0(%rax)
 1f82b90:	mov    0x50(%rsp),%r13
 1f82b95:	imul   $0x68,%r12,%r12
 1f82b99:	movb   $0x0,0x760(%rsp)
 1f82ba1:	add    %r13,%r12
 1f82ba4:	cmpb   $0x0,0x68(%rsp)
 1f82ba9:	je     1f82bc0 <node_facts_window_run+0x57f0>
 1f82bab:	mov    0x10(%r12),%rax
 1f82bb0:	sub    0xb78(%rdi),%rax
 1f82bb7:	add    0xb80(%rdi),%rax
 1f82bbe:	jmp    1f82bc2 <node_facts_window_run+0x57f2>
 1f82bc0:	xor    %eax,%eax
 1f82bc2:	movzbl 0x68(%rsp),%edx
 1f82bc7:	mov    %rax,0x4d0(%rdi)
 1f82bce:	mov    0xb8(%rsp),%rax
 1f82bd6:	mov    %ebx,%esi
 1f82bd8:	mov    %dl,0x4d8(%rdi)
 1f82bde:	movzbl (%rax,%rbp,1),%edx
 1f82be2:	push   %r12
 1f82be4:	lea    0x768(%rsp),%rax
 1f82bec:	push   %rax
 1f82bed:	call   1f549a0 <node_census_reader_expression>
 1f82bf2:	add    $0x10,%rsp
 1f82bf6:	cmpb   $0x1,0x62(%r12)
 1f82bfc:	mov    0x48(%rsp),%r8
 1f82c01:	adcq   $0x0,0x898(%r8)
 1f82c09:	cmpb   $0x0,0x62(%r12)
 1f82c0f:	jne    1f82a40 <node_facts_window_run+0x5670>
 1f82c15:	movzbl 0x760(%rsp),%ecx
 1f82c1d:	mov    (%rsp),%rdi
 1f82c21:	mov    $0x1,%edx
 1f82c26:	cmp    0x50(%r12),%rax
 1f82c2b:	jne    1f82c65 <node_facts_window_run+0x5895>
 1f82c2d:	mov    0x8(%rsp),%r9
 1f82c32:	cmp    0x60(%r12),%cl
 1f82c37:	jne    1f82a53 <node_facts_window_run+0x5683>
 1f82c3d:	mov    0x534(%r9),%esi
 1f82c44:	cmp    0x58(%r12),%esi
 1f82c49:	jne    1f82a53 <node_facts_window_run+0x5683>
 1f82c4f:	mov    0x538(%r9),%esi
 1f82c56:	xor    %edx,%edx
 1f82c58:	cmp    0x5c(%r12),%esi
 1f82c5d:	setne  %dl
 1f82c60:	jmp    1f82a53 <node_facts_window_run+0x5683>
 1f82c65:	mov    0x8(%rsp),%r9
 1f82c6a:	jmp    1f82a53 <node_facts_window_run+0x5683>
 1f82c6f:	rdtsc
 1f82c71:	xor    %ebx,%ebx
 1f82c73:	mov    %rdi,%r15
 1f82c76:	mov    %r9,%r12
 1f82c79:	shl    $0x20,%rdx
 1f82c7d:	or     %rax,%rdx
 1f82c80:	mov    %rdx,0x20(%rsp)
 1f82c85:	mov    0xb0(%rsp),%rbp
 1f82c8d:	nopl   (%rax)
 1f82c90:	mov    0xb88(%r12),%rax
 1f82c98:	mov    0xa48(%r15),%rcx
 1f82c9f:	mov    0xa50(%r15),%rdx
 1f82ca6:	mov    %rbp,%rdi
 1f82ca9:	mov    (%rax,%rbx,4),%eax
 1f82cac:	mov    (%rcx,%rax,4),%esi
 1f82caf:	mov    0xa58(%r15),%rcx
 1f82cb6:	mov    (%rdx,%rax,4),%edx
 1f82cb9:	mov    (%rcx,%rax,4),%ecx
 1f82cbc:	call   1f530c0 <node_machine_type>
 1f82cc1:	inc    %rbx
 1f82cc4:	cmp    %rbx,%r14
 1f82cc7:	jne    1f82c90 <node_facts_window_run+0x58c0>
 1f82cc9:	mov    0x18(%rsp),%rbp
 1f82cce:	jmp    1f82cde <node_facts_window_run+0x590e>
 1f82cd0:	rdtsc
 1f82cd2:	shl    $0x20,%rdx
 1f82cd6:	or     %rax,%rdx
 1f82cd9:	mov    %rdx,0x20(%rsp)
 1f82cde:	mov    0xe8(%rsp),%rax
 1f82ce6:	lea    0x890(%rsp),%rsi
 1f82cee:	or     %rax,0xf0(%rsp)
 1f82cf6:	mov    0x430(%rsp),%rax
 1f82cfe:	or     %rax,0x720(%rsp)
 1f82d06:	rdtsc
 1f82d08:	mov    0x410(%rsp),%rcx
 1f82d10:	shl    $0x20,%rdx
 1f82d14:	or     %rcx,0x6e0(%rsp)
 1f82d1c:	mov    0x38(%rsp),%rcx
 1f82d21:	or     %rcx,0x28(%rsp)
 1f82d26:	or     %rax,%rdx
 1f82d29:	mov    %rdx,0x38(%rsp)
 1f82d2e:	mov    $0x418,%edx
 1f82d33:	mov    0xb0(%rsp),%rdi
 1f82d3b:	call   355e9b0 <memcpy>
 1f82d40:	mov    (%rsp),%r11
 1f82d44:	cmpl   $0x0,0xa90(%r11)
 1f82d4c:	je     1f82fbd <node_facts_window_run+0x5bed>
 1f82d52:	xorb   $0x1,0x68(%rsp)
 1f82d57:	add    $0x62,%r13
 1f82d5b:	xor    %r14d,%r14d
 1f82d5e:	xor    %eax,%eax
 1f82d60:	mov    0x48(%rsp),%r8
 1f82d65:	mov    0x8(%rsp),%rdi
 1f82d6a:	jmp    1f82d8d <node_facts_window_run+0x59bd>
 1f82d6c:	nopl   0x0(%rax)
 1f82d70:	mov    %rax,%r15
 1f82d73:	mov    0xa90(%r11),%ecx
 1f82d7a:	inc    %r14
 1f82d7d:	add    $0x68,%r13
 1f82d81:	mov    %r15,%rax
 1f82d84:	cmp    %rcx,%r14
 1f82d87:	jae    1f82fc5 <node_facts_window_run+0x5bf5>
 1f82d8d:	cmpb   $0x0,-0x1(%r13)
 1f82d92:	je     1f82d70 <node_facts_window_run+0x59a0>
 1f82d94:	xor    %edx,%edx
 1f82d96:	cmpb   $0x0,0x0(%r13)
 1f82d9b:	mov    0xa70(%r11),%rcx
 1f82da2:	sete   %dl
 1f82da5:	mov    (%rcx,%r14,4),%ecx
 1f82da9:	add    %rdx,0x890(%r8)
 1f82db0:	and    0x68(%rsp),%dl
 1f82db4:	movzbl %dl,%edx
 1f82db7:	add    %rdx,0x690(%r8)
 1f82dbe:	cmp    $0x1,%dl
 1f82dc1:	jne    1f82dd0 <node_facts_window_run+0x5a00>
 1f82dc3:	mov    0xa58(%r11),%rdx
 1f82dca:	mov    (%rdx,%r14,4),%edx
 1f82dce:	jmp    1f82dd2 <node_facts_window_run+0x5a02>
 1f82dd0:	xor    %edx,%edx
 1f82dd2:	add    %rdx,0x698(%r8)
 1f82dd9:	mov    0xa58(%r11),%rdx
 1f82de0:	mov    (%rdx,%r14,4),%edx
 1f82de4:	cmp    0x651b8(%rbp,%rcx,4),%edx
 1f82deb:	jbe    1f82e10 <node_facts_window_run+0x5a40>
 1f82ded:	mov    0xa68(%r11),%rdx
 1f82df4:	inc    %ecx
 1f82df6:	xor    %r15d,%r15d
 1f82df9:	cmp    %ecx,(%rdx,%r14,4)
 1f82dfd:	setne  %r15b
 1f82e01:	jmp    1f82e13 <node_facts_window_run+0x5a43>
 1f82e03:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82e10:	xor    %r15d,%r15d
 1f82e13:	mov    0xa50(%r11),%rcx
 1f82e1a:	mov    0x240(%r8),%rdx
 1f82e21:	mov    (%rcx,%r14,4),%ebx
 1f82e25:	mov    (%rdx,%rbx,8),%r12
 1f82e29:	cmp    %r12,-0x12(%r13)
 1f82e2d:	jne    1f82e70 <node_facts_window_run+0x5aa0>
 1f82e2f:	mov    0x248(%r8),%rdx
 1f82e36:	movzbl -0x2(%r13),%ecx
 1f82e3b:	cmp    (%rdx,%rbx,1),%cl
 1f82e3e:	jne    1f82e70 <node_facts_window_run+0x5aa0>
 1f82e40:	mov    0xb50(%rdi),%rdx
 1f82e47:	mov    -0xa(%r13),%ecx
 1f82e4b:	cmp    (%rdx,%rbx,4),%ecx
 1f82e4e:	jne    1f82e70 <node_facts_window_run+0x5aa0>
 1f82e50:	mov    0xb58(%rdi),%rdx
 1f82e57:	mov    -0x6(%r13),%ecx
 1f82e5b:	cmp    (%rdx,%rbx,4),%ecx
 1f82e5e:	sete   %cl
 1f82e61:	jmp    1f82e72 <node_facts_window_run+0x5aa2>
 1f82e63:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82e70:	xor    %ecx,%ecx
 1f82e72:	incq   0xa50(%r8)
 1f82e79:	add    %rax,%r15
 1f82e7c:	mov    %ecx,%edx
 1f82e7e:	mov    0xa58(%r11),%rax
 1f82e85:	xor    $0x1,%dl
 1f82e88:	vmovd  (%rax,%r14,4),%xmm0
 1f82e8e:	movzbl %dl,%eax
 1f82e91:	vmovd  %eax,%xmm1
 1f82e95:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f82e99:	vpaddq 0xa58(%r8),%xmm0,%xmm0
 1f82ea2:	vmovdqu %xmm0,0xa58(%r8)
 1f82eab:	test   %cl,%cl
 1f82ead:	jne    1f82d73 <node_facts_window_run+0x59a3>
 1f82eb3:	mov    0x12e4(%r8),%eax
 1f82eba:	cmp    0x50049e4(%rip),%eax        # 6f878a4 <node_census_list>
 1f82ec0:	jae    1f82d73 <node_facts_window_run+0x59a3>
 1f82ec6:	inc    %eax
 1f82ec8:	xor    %esi,%esi
 1f82eca:	mov    %eax,0x12e4(%r8)
 1f82ed1:	mov    0xa68(%r11),%rcx
 1f82ed8:	mov    (%rdi),%rax
 1f82edb:	mov    (%rcx,%r14,4),%ecx
 1f82edf:	mov    0x18(%rax),%rax
 1f82ee3:	mov    0x422c(%rbp,%rcx,4),%ecx
 1f82eea:	cmp    0x78(%rax),%ecx
 1f82eed:	jae    1f82f31 <node_facts_window_run+0x5b61>
 1f82eef:	mov    0x68(%rax),%rax
 1f82ef3:	mov    0x8(%rdi),%rdi
 1f82ef7:	mov    (%rax,%rcx,4),%eax
 1f82efa:	cmp    0x1538(%rdi),%eax
 1f82f00:	jae    1f82f31 <node_facts_window_run+0x5b61>
 1f82f02:	mov    0x1530(%rdi),%rcx
 1f82f09:	test   %rcx,%rcx
 1f82f0c:	je     1f82f31 <node_facts_window_run+0x5b61>
 1f82f0e:	mov    (%rcx,%rax,4),%esi
 1f82f11:	lea    0x760(%rsp),%rdx
 1f82f19:	lea    0x510(%rsp),%rcx
 1f82f21:	call   111f9b0 <pp_presumed>
 1f82f26:	mov    0x48(%rsp),%r8
 1f82f2b:	mov    (%rsp),%r11
 1f82f2f:	mov    %eax,%esi
 1f82f31:	mov    0xa58(%r11),%rax
 1f82f38:	mov    -0x12(%r13),%rcx
 1f82f3c:	movzbl -0x2(%r13),%r9d
 1f82f41:	mov    -0xa(%r13),%r11d
 1f82f45:	mov    -0x6(%r13),%r10d
 1f82f49:	mov    (%rax,%r14,4),%edx
 1f82f4d:	mov    0x248(%r8),%rax
 1f82f54:	movzbl (%rax,%rbx,1),%eax
 1f82f58:	mov    %rax,0x10(%rsp)
 1f82f5d:	mov    %r13,0x50(%rsp)
 1f82f62:	mov    0x8(%rsp),%r13
 1f82f67:	mov    0xb50(%r13),%rax
 1f82f6e:	mov    0xb58(%r13),%rdi
 1f82f75:	mov    (%rax,%rbx,4),%ebp
 1f82f78:	mov    (%rdi,%rbx,4),%ebx
 1f82f7b:	sub    $0x8,%rsp
 1f82f7f:	lea    -0x196212e(%rip),%rdi        # 620e58 <.str.11115>
 1f82f86:	mov    %r12,%r8
 1f82f89:	xor    %eax,%eax
 1f82f8b:	push   %rbx
 1f82f8c:	push   %rbp
 1f82f8d:	push   %r10
 1f82f8f:	push   %r11
 1f82f91:	push   0x38(%rsp)
 1f82f95:	call   34ef0d0 <_IO_printf>
 1f82f9a:	mov    %r13,%rdi
 1f82f9d:	mov    0x80(%rsp),%r13
 1f82fa5:	mov    0x78(%rsp),%r8
 1f82faa:	mov    0x30(%rsp),%r11
 1f82faf:	add    $0x30,%rsp
 1f82fb3:	mov    0x18(%rsp),%rbp
 1f82fb8:	jmp    1f82d73 <node_facts_window_run+0x59a3>
 1f82fbd:	mov    0x48(%rsp),%r8
 1f82fc2:	xor    %r15d,%r15d
 1f82fc5:	vpmovsxbq -0x1acc287(%rip),%xmm0        # 4b6d47 <abi_test_hex.digits+0xb9c7>
 1f82fce:	vmovd  0x8(%rbp),%xmm2
 1f82fd3:	mov    0x20(%rsp),%rcx
 1f82fd8:	mov    0x38(%rsp),%r9
 1f82fdd:	mov    0x28(%rsp),%rdi
 1f82fe2:	vmovq  %r15,%xmm1
 1f82fe7:	xor    %eax,%eax
 1f82fe9:	mov    0x720(%rsp),%rdx
 1f82ff1:	mov    0x6e0(%rsp),%rsi
 1f82ff9:	mov    0xc0(%rsp),%r15
 1f83001:	sub    %rcx,%r9
 1f83004:	sub    %rdi,%rcx
 1f83007:	sub    %r9,%rcx
 1f8300a:	cmovae %rcx,%rax
 1f8300e:	mov    0xf0(%rsp),%rcx
 1f83016:	sub    %rdx,%rsi
 1f83019:	vpinsrq $0x0,%r9,%xmm0,%xmm0
 1f8301f:	vpunpcklqdq %xmm1,%xmm2,%xmm1
 1f83023:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f83029:	vpaddq 0xa98(%r8),%ymm0,%ymm0
 1f83032:	vmovq  %rsi,%xmm1
 1f83037:	sub    %rcx,%rdi
 1f8303a:	sub    %rcx,%rdx
 1f8303d:	add    %rax,%rdi
 1f83040:	vmovq  %rdx,%xmm2
 1f83045:	vmovdqu %ymm0,0xa98(%r8)
 1f8304e:	vmovq  %rax,%xmm0
 1f83053:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f83057:	vmovq  %rdi,%xmm1
 1f8305c:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f83060:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f83066:	vpaddq 0xa68(%r8),%ymm0,%ymm0
 1f8306f:	vmovdqu %ymm0,0xa68(%r8)
 1f83078:	cmpq   $0x0,0xb40(%r11)
 1f83080:	je     1f84d06 <node_facts_window_run+0x7936>
 1f83086:	mov    0x940(%r11),%r12
 1f8308d:	mov    0x8(%rbp),%ebx
 1f83090:	rdtsc
 1f83092:	lea    0x890(%rsp),%rcx
 1f8309a:	vpxor  %xmm0,%xmm0,%xmm0
 1f8309e:	vmovdqu64 %zmm0,0x8b0(%rsp)
 1f830a9:	vmovdqu64 %zmm0,0x890(%rsp)
 1f830b4:	mov    %r11,%rdi
 1f830b7:	mov    %rbp,%rsi
 1f830ba:	shl    $0x20,%rdx
 1f830be:	or     %rax,%rdx
 1f830c1:	mov    %rdx,0x50(%rsp)
 1f830c6:	mov    %ebx,%edx
 1f830c8:	vzeroupper
 1f830cb:	call   1f93d00 <node_contexts_window_loop>
 1f830d0:	vmovups 0x8b8(%rsp),%ymm0
 1f830d9:	vmovdqu 0x8b8(%rsp),%xmm1
 1f830e2:	mov    %rbp,%rsi
 1f830e5:	vmovups %ymm0,0x1e0(%rsp)
 1f830ee:	vpbroadcastq 0x8c8(%rsp),%ymm0
 1f830f8:	mov    (%rsp),%rax
 1f830fc:	vpsubq %xmm0,%xmm1,%xmm0
 1f83100:	vpaddq 0x8c8(%rsp),%xmm0,%xmm0
 1f83109:	vpblendd $0xc,%xmm0,%xmm1,%xmm0
 1f8310f:	vmovdqu %xmm0,0xc08(%rax)
 1f83117:	rdtsc
 1f83119:	shl    $0x20,%rdx
 1f8311d:	or     %rax,%rdx
 1f83120:	mov    %rdx,0x48(%rsp)
 1f83125:	mov    %ebx,%edx
 1f83127:	mov    (%rsp),%rdi
 1f8312b:	vzeroupper
 1f8312e:	call   1f95cb0 <node_contexts_window_targets>
 1f83133:	rdtsc
 1f83135:	mov    %rbp,%rsi
 1f83138:	shl    $0x20,%rdx
 1f8313c:	or     %rax,%rdx
 1f8313f:	mov    %rdx,0xb0(%rsp)
 1f83147:	mov    (%rsp),%rdi
 1f8314b:	call   1f96040 <node_contexts_window_part>
 1f83150:	rdtsc
 1f83152:	lea    0x760(%rsp),%rcx
 1f8315a:	vpxor  %xmm0,%xmm0,%xmm0
 1f8315e:	vmovdqu64 %zmm0,0x780(%rsp)
 1f83166:	vmovdqu64 %zmm0,0x760(%rsp)
 1f83171:	mov    %rbp,%rsi
 1f83174:	shl    $0x20,%rdx
 1f83178:	or     %rax,%rdx
 1f8317b:	mov    %rdx,0xb8(%rsp)
 1f83183:	mov    %ebx,%edx
 1f83185:	mov    (%rsp),%rdi
 1f83189:	vzeroupper
 1f8318c:	call   1f93d00 <node_contexts_window_loop>
 1f83191:	rdtsc
 1f83193:	mov    %rbp,%rsi
 1f83196:	shl    $0x20,%rdx
 1f8319a:	or     %rax,%rdx
 1f8319d:	mov    %rdx,0xa8(%rsp)
 1f831a5:	mov    %ebx,%edx
 1f831a7:	mov    (%rsp),%rdi
 1f831ab:	call   1f95cb0 <node_contexts_window_targets>
 1f831b0:	rdtsc
 1f831b2:	mov    %rbp,%rsi
 1f831b5:	shl    $0x20,%rdx
 1f831b9:	or     %rax,%rdx
 1f831bc:	mov    %rdx,0xa0(%rsp)
 1f831c4:	mov    (%rsp),%rdi
 1f831c8:	call   1f96040 <node_contexts_window_part>
 1f831cd:	mov    (%rsp),%r11
 1f831d1:	rdtsc
 1f831d3:	shl    $0x20,%rdx
 1f831d7:	or     %rax,%rdx
 1f831da:	cmpl   $0x0,0xa90(%r11)
 1f831e2:	mov    %rdx,0x1a0(%rsp)
 1f831ea:	mov    %rbx,0x160(%rsp)
 1f831f2:	je     1f83723 <node_facts_window_run+0x6353>
 1f831f8:	vpbroadcastq -0x19b4cc9(%rip),%xmm0        # 5ce538 <.LCPI3_1>
 1f83201:	xor    %ebx,%ebx
 1f83203:	xor    %edi,%edi
 1f83205:	mov    %r12,0x28(%rsp)
 1f8320a:	jmp    1f8322d <node_facts_window_run+0x5e5d>
 1f8320c:	mov    (%rsp),%r11
 1f83210:	xor    %esi,%esi
 1f83212:	incq   0x12e8(%r12,%rsi,8)
 1f8321a:	mov    0xa90(%r11),%eax
 1f83221:	inc    %rdi
 1f83224:	cmp    %rax,%rdi
 1f83227:	jae    1f83725 <node_facts_window_run+0x6355>
 1f8322d:	mov    0xb80(%r11),%rax
 1f83234:	movzbl (%rax,%rdi,1),%r8d
 1f83239:	test   %r8b,%r8b
 1f8323c:	je     1f8321a <node_facts_window_run+0x5e4a>
 1f8323e:	mov    0xa70(%r11),%rcx
 1f83245:	mov    0xa68(%r11),%rax
 1f8324c:	mov    (%rcx,%rdi,4),%ecx
 1f8324f:	mov    (%rax,%rdi,4),%r13d
 1f83253:	mov    0x651b8(%rbp,%rcx,4),%esi
 1f8325a:	incq   0xab8(%r12)
 1f83262:	mov    0xa58(%r11),%rax
 1f83269:	mov    (%rax,%rdi,4),%eax
 1f8326c:	add    %rax,0xac0(%r12)
 1f83274:	cmp    $0x1,%r8b
 1f83278:	jne    1f832d0 <node_facts_window_run+0x5f00>
 1f8327a:	mov    0xa58(%r11),%rax
 1f83281:	mov    (%rax,%rdi,4),%r10d
 1f83285:	test   %r10d,%r10d
 1f83288:	je     1f83210 <node_facts_window_run+0x5e40>
 1f8328a:	mov    0xbe8(%r11),%rax
 1f83291:	sub    %esi,%ecx
 1f83293:	xor    %r11d,%r11d
 1f83296:	inc    %ecx
 1f83298:	nopl   0x0(%rax,%rax,1)
 1f832a0:	lea    (%rcx,%r11,1),%r9d
 1f832a4:	cmp    %esi,%r11d
 1f832a7:	cmovae %r13d,%r9d
 1f832ab:	mov    %r9d,%edx
 1f832ae:	shr    $0x3,%edx
 1f832b1:	and    $0xfffffff8,%edx
 1f832b4:	mov    0x10(%rax,%rdx,8),%r8
 1f832b9:	bt     %r9,%r8
 1f832bd:	jb     1f8334f <node_facts_window_run+0x5f7f>
 1f832c3:	inc    %r11d
 1f832c6:	cmp    %r11d,%r10d
 1f832c9:	jne    1f832a0 <node_facts_window_run+0x5ed0>
 1f832cb:	jmp    1f8320c <node_facts_window_run+0x5e3c>
 1f832d0:	mov    0xa58(%r11),%rcx
 1f832d7:	mov    0xb68(%r11),%rdx
 1f832de:	cmp    $0x3,%r8b
 1f832e2:	sete   %al
 1f832e5:	mov    (%rcx,%rdi,4),%r9d
 1f832e9:	movzbl (%rdx,%rdi,1),%r10d
 1f832ee:	test   %r9,%r9
 1f832f1:	sete   %cl
 1f832f4:	cmp    $0x2,%r10b
 1f832f8:	sete   %dl
 1f832fb:	or     %al,%dl
 1f832fd:	or     %cl,%dl
 1f832ff:	je     1f83309 <node_facts_window_run+0x5f39>
 1f83301:	xor    %r14d,%r14d
 1f83304:	jmp    1f83634 <node_facts_window_run+0x6264>
 1f83309:	mov    0xa70(%r11),%rcx
 1f83310:	mov    0xa68(%r11),%rax
 1f83317:	mov    %r13,0x20(%rsp)
 1f8331c:	mov    0xbe8(%r11),%r12
 1f83323:	mov    %rbx,0x10(%rsp)
 1f83328:	mov    (%rcx,%rdi,4),%ecx
 1f8332b:	mov    (%rax,%rdi,4),%r13d
 1f8332f:	mov    0xb48(%r11),%rax
 1f83336:	mov    0x651b8(%rbp,%rcx,4),%ebp
 1f8333d:	sub    %ebp,%ecx
 1f8333f:	cmp    $0x1,%r9d
 1f83343:	jne    1f8339e <node_facts_window_run+0x5fce>
 1f83345:	xor    %r14d,%r14d
 1f83348:	xor    %ebx,%ebx
 1f8334a:	jmp    1f8358a <node_facts_window_run+0x61ba>
 1f8334f:	mov    (%rsp),%r11
 1f83353:	mov    %r9d,%esi
 1f83356:	mov    0xbd0(%r11),%rcx
 1f8335d:	movzbl (%rcx,%rsi,1),%ecx
 1f83361:	mov    $0x1,%esi
 1f83366:	cmp    $0xd,%ecx
 1f83369:	je     1f83212 <node_facts_window_run+0x5e42>
 1f8336f:	lea    -0xf(%rcx),%r8d
 1f83373:	mov    $0x2,%esi
 1f83378:	cmp    $0x2,%r8b
 1f8337c:	jb     1f83212 <node_facts_window_run+0x5e42>
 1f83382:	cmp    $0xe,%ecx
 1f83385:	je     1f836dd <node_facts_window_run+0x630d>
 1f8338b:	cmp    $0x11,%ecx
 1f8338e:	jne    1f836e7 <node_facts_window_run+0x6317>
 1f83394:	mov    $0x4,%esi
 1f83399:	jmp    1f83212 <node_facts_window_run+0x5e42>
 1f8339e:	mov    %r9d,%edx
 1f833a1:	and    $0xfffffffe,%edx
 1f833a4:	mov    %r10b,0x68(%rsp)
 1f833a9:	mov    %r8b,0x38(%rsp)
 1f833ae:	mov    %r9,0x30(%rsp)
 1f833b3:	xor    %r14d,%r14d
 1f833b6:	xor    %r15d,%r15d
 1f833b9:	mov    %edx,0x8(%rsp)
 1f833bd:	lea    0x2(%rcx),%edx
 1f833c0:	mov    %rcx,0x120(%rsp)
 1f833c8:	jmp    1f833ea <node_facts_window_run+0x601a>
 1f833ca:	nopw   0x0(%rax,%rax,1)
 1f833d0:	xor    %r11d,%r11d
 1f833d3:	add    %r10,%r14
 1f833d6:	add    $0x2,%edx
 1f833d9:	inc    %r15d
 1f833dc:	add    %r11,%r14
 1f833df:	cmp    0x8(%rsp),%r15d
 1f833e4:	je     1f83533 <node_facts_window_run+0x6163>
 1f833ea:	mov    %r15d,%ebx
 1f833ed:	lea    -0x1(%rdx),%r15d
 1f833f1:	cmp    %ebp,%ebx
 1f833f3:	mov    $0x1,%r11d
 1f833f9:	mov    $0x1,%r10d
 1f833ff:	cmovae %r13d,%r15d
 1f83403:	mov    %r15d,%esi
 1f83406:	and    $0xffffffc0,%esi
 1f83409:	movzbl (%rax,%r15,1),%r8d
 1f8340e:	shrx   %r15,(%r12,%rsi,1),%rsi
 1f83414:	and    $0x1,%r8d
 1f83418:	mov    %esi,%r9d
 1f8341b:	and    $0x1,%r9d
 1f8341f:	cmp    %r8d,%r9d
 1f83422:	jne    1f83493 <node_facts_window_run+0x60c3>
 1f83424:	test   $0x1,%sil
 1f83428:	je     1f83490 <node_facts_window_run+0x60c0>
 1f8342a:	mov    (%rsp),%rcx
 1f8342e:	mov    0xbb0(%rcx),%r8
 1f83435:	mov    0xb58(%rcx),%rsi
 1f8343c:	movzbl (%r8,%r15,1),%r8d
 1f83441:	cmp    (%rsi,%r15,1),%r8b
 1f83445:	jne    1f83493 <node_facts_window_run+0x60c3>
 1f83447:	mov    (%rsp),%rcx
 1f8344b:	mov    0xbc0(%rcx),%r8
 1f83452:	mov    0xb50(%rcx),%rsi
 1f83459:	movzbl (%r8,%r15,1),%r8d
 1f8345e:	cmp    (%rsi,%r15,1),%r8b
 1f83462:	jne    1f83493 <node_facts_window_run+0x60c3>
 1f83464:	mov    (%rsp),%rcx
 1f83468:	xor    %r10d,%r10d
 1f8346b:	mov    0xbd8(%rcx),%r8
 1f83472:	mov    0xb60(%rcx),%rsi
 1f83479:	mov    (%r8,%r15,4),%r8d
 1f8347d:	cmp    (%rsi,%r15,4),%r8d
 1f83481:	setne  %r10b
 1f83485:	jmp    1f83493 <node_facts_window_run+0x60c3>
 1f83487:	nopw   0x0(%rax,%rax,1)
 1f83490:	xor    %r10d,%r10d
 1f83493:	lea    0x1(%rbx),%r15d
 1f83497:	mov    %r13d,%esi
 1f8349a:	cmp    %ebp,%r15d
 1f8349d:	cmovb  %edx,%esi
 1f834a0:	mov    %esi,%r8d
 1f834a3:	and    $0xffffffc0,%r8d
 1f834a7:	movzbl (%rax,%rsi,1),%r9d
 1f834ac:	shrx   %rsi,(%r12,%r8,1),%r8
 1f834b2:	and    $0x1,%r9d
 1f834b6:	mov    %r8d,%ecx
 1f834b9:	and    $0x1,%ecx
 1f834bc:	cmp    %r9d,%ecx
 1f834bf:	jne    1f833d3 <node_facts_window_run+0x6003>
 1f834c5:	test   $0x1,%r8b
 1f834c9:	je     1f833d0 <node_facts_window_run+0x6000>
 1f834cf:	mov    (%rsp),%r9
 1f834d3:	mov    0xbb0(%r9),%r8
 1f834da:	mov    0xb58(%r9),%rcx
 1f834e1:	movzbl (%r8,%rsi,1),%r8d
 1f834e6:	cmp    (%rcx,%rsi,1),%r8b
 1f834ea:	jne    1f833d3 <node_facts_window_run+0x6003>
 1f834f0:	mov    0xbc0(%r9),%r8
 1f834f7:	mov    0xb50(%r9),%rcx
 1f834fe:	movzbl (%r8,%rsi,1),%r8d
 1f83503:	cmp    (%rcx,%rsi,1),%r8b
 1f83507:	jne    1f833d3 <node_facts_window_run+0x6003>
 1f8350d:	mov    (%rsp),%r8
 1f83511:	xor    %r11d,%r11d
 1f83514:	mov    0xb60(%r8),%rcx
 1f8351b:	mov    0xbd8(%r8),%r8
 1f83522:	mov    (%r8,%rsi,4),%r8d
 1f83526:	cmp    (%rcx,%rsi,4),%r8d
 1f8352a:	setne  %r11b
 1f8352e:	jmp    1f833d3 <node_facts_window_run+0x6003>
 1f83533:	mov    0x30(%rsp),%r9
 1f83538:	mov    0xc0(%rsp),%r15
 1f83540:	test   $0x1,%r9b
 1f83544:	jne    1f8356f <node_facts_window_run+0x619f>
 1f83546:	mov    (%rsp),%r11
 1f8354a:	mov    0x18(%rsp),%rbp
 1f8354f:	mov    0x28(%rsp),%r12
 1f83554:	mov    0x10(%rsp),%rbx
 1f83559:	mov    0x20(%rsp),%r13
 1f8355e:	movzbl 0x38(%rsp),%r8d
 1f83564:	movzbl 0x68(%rsp),%r10d
 1f8356a:	jmp    1f83634 <node_facts_window_run+0x6264>
 1f8356f:	mov    (%rsp),%r11
 1f83573:	movzbl 0x38(%rsp),%r8d
 1f83579:	movzbl 0x68(%rsp),%r10d
 1f8357f:	mov    0x120(%rsp),%rcx
 1f83587:	add    $0x2,%ebx
 1f8358a:	inc    %ecx
 1f8358c:	add    %ebx,%ecx
 1f8358e:	cmp    %ebp,%ebx
 1f83590:	cmovb  %ecx,%r13d
 1f83594:	mov    %r13d,%ecx
 1f83597:	and    $0xffffffc0,%ecx
 1f8359a:	movzbl (%rax,%r13,1),%edx
 1f8359f:	mov    $0x1,%eax
 1f835a4:	shrx   %r13,(%r12,%rcx,1),%rcx
 1f835aa:	and    $0x1,%edx
 1f835ad:	mov    %ecx,%esi
 1f835af:	and    $0x1,%esi
 1f835b2:	cmp    %edx,%esi
 1f835b4:	jne    1f83619 <node_facts_window_run+0x6249>
 1f835b6:	mov    0x18(%rsp),%rbp
 1f835bb:	mov    0x28(%rsp),%r12
 1f835c0:	mov    0x10(%rsp),%rbx
 1f835c5:	test   $0x1,%cl
 1f835c8:	je     1f8362a <node_facts_window_run+0x625a>
 1f835ca:	mov    0xbb0(%r11),%rdx
 1f835d1:	mov    0xb58(%r11),%rcx
 1f835d8:	movzbl (%rdx,%r13,1),%edx
 1f835dd:	cmp    (%rcx,%r13,1),%dl
 1f835e1:	jne    1f8362c <node_facts_window_run+0x625c>
 1f835e3:	mov    0xbc0(%r11),%rdx
 1f835ea:	mov    0xb50(%r11),%rcx
 1f835f1:	movzbl (%rdx,%r13,1),%edx
 1f835f6:	cmp    (%rcx,%r13,1),%dl
 1f835fa:	jne    1f8362c <node_facts_window_run+0x625c>
 1f835fc:	mov    0xbd8(%r11),%rax
 1f83603:	mov    0xb60(%r11),%rcx
 1f8360a:	mov    (%rax,%r13,4),%edx
 1f8360e:	xor    %eax,%eax
 1f83610:	cmp    (%rcx,%r13,4),%edx
 1f83614:	setne  %al
 1f83617:	jmp    1f8362c <node_facts_window_run+0x625c>
 1f83619:	mov    0x18(%rsp),%rbp
 1f8361e:	mov    0x28(%rsp),%r12
 1f83623:	mov    0x10(%rsp),%rbx
 1f83628:	jmp    1f8362c <node_facts_window_run+0x625c>
 1f8362a:	xor    %eax,%eax
 1f8362c:	mov    0x20(%rsp),%r13
 1f83631:	add    %rax,%r14
 1f83634:	cmp    $0x2,%r10b
 1f83638:	sete   %al
 1f8363b:	cmp    $0x3,%r8b
 1f8363f:	sete   %cl
 1f83642:	xor    %cl,%al
 1f83644:	test   %r14,%r14
 1f83647:	vmovd  %ecx,%xmm1
 1f8364b:	setne  %dl
 1f8364e:	incq   0xac8(%r12)
 1f83656:	add    %r9,%rbx
 1f83659:	or     %al,%dl
 1f8365b:	vpinsrb $0x1,%edx,%xmm1,%xmm1
 1f83661:	vpmovzxbq %xmm1,%xmm1
 1f83666:	vptestmq %xmm0,%xmm1,%k0
 1f8366c:	vmovdqu 0xad8(%r12),%xmm1
 1f83676:	vpmovm2q %k0,%xmm2
 1f8367c:	vpsubq %xmm2,%xmm1,%xmm1
 1f83680:	vmovdqu %xmm1,0xad8(%r12)
 1f8368a:	add    %r14,0xae8(%r12)
 1f83692:	mov    0xb78(%r11),%rax
 1f83699:	mov    (%rax,%rdi,8),%rax
 1f8369d:	add    %rax,0xb30(%r12)
 1f836a5:	cmp    $0x1,%dl
 1f836a8:	jne    1f8321a <node_facts_window_run+0x5e4a>
 1f836ae:	mov    0x1368(%r12),%eax
 1f836b6:	cmp    $0xf,%rax
 1f836ba:	ja     1f8321a <node_facts_window_run+0x5e4a>
 1f836c0:	mov    0x422c(%rbp,%r13,4),%ecx
 1f836c8:	mov    %ecx,0x1328(%r12,%rax,4)
 1f836d0:	incl   0x1368(%r12)
 1f836d8:	jmp    1f8321a <node_facts_window_run+0x5e4a>
 1f836dd:	mov    $0x3,%esi
 1f836e2:	jmp    1f83212 <node_facts_window_run+0x5e42>
 1f836e7:	mov    $0x1,%esi
 1f836ec:	shlx   %r9,%rsi,%r8
 1f836f1:	mov    $0x5,%esi
 1f836f6:	test   %r8,0x18(%rax,%rdx,8)
 1f836fb:	jne    1f83212 <node_facts_window_run+0x5e42>
 1f83701:	mov    $0x6,%esi
 1f83706:	test   %r8,0x20(%rax,%rdx,8)
 1f8370b:	jne    1f83212 <node_facts_window_run+0x5e42>
 1f83711:	xor    %eax,%eax
 1f83713:	cmp    $0x7,%ecx
 1f83716:	setne  %al
 1f83719:	lea    0x2(%rax,%rax,4),%rsi
 1f8371e:	jmp    1f83212 <node_facts_window_run+0x5e42>
 1f83723:	xor    %ebx,%ebx
 1f83725:	add    %rbx,0xad0(%r12)
 1f8372d:	mov    0xb8(%rsp),%rdx
 1f83735:	mov    0xb0(%rsp),%rsi
 1f8373d:	mov    0x48(%rsp),%rcx
 1f83742:	vmovd  0x160(%rsp),%xmm4
 1f8374b:	vmovdqu 0xb78(%r12),%xmm0
 1f83755:	vmovq  0x8b0(%rsp),%xmm1
 1f8375e:	vpaddq 0x8d8(%rsp),%xmm0,%xmm0
 1f83767:	vmovdqu %xmm0,0xb78(%r12)
 1f83771:	mov    0x8e8(%rsp),%rax
 1f83779:	add    %rax,0xb88(%r12)
 1f83781:	mov    %rdx,%rax
 1f83784:	sub    %rsi,%rax
 1f83787:	sub    %rcx,%rsi
 1f8378a:	sub    0x50(%rsp),%rcx
 1f8378f:	vmovdqu64 0x890(%rsp),%zmm0
 1f8379a:	vmovq  %rax,%xmm2
 1f8379f:	vmovq  %rsi,%xmm3
 1f837a4:	mov    0x1a0(%rsp),%rsi
 1f837ac:	mov    0xa8(%rsp),%rax
 1f837b4:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f837b8:	vmovq  %rcx,%xmm3
 1f837bd:	mov    0xa0(%rsp),%rcx
 1f837c5:	vpunpcklqdq %xmm3,%xmm4,%xmm3
 1f837c9:	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
 1f837cf:	vshufi64x2 $0x44,%zmm2,%zmm0,%zmm0
 1f837d6:	vpaddq 0xaf0(%r12),%zmm0,%zmm0
 1f837e1:	sub    %rcx,%rsi
 1f837e4:	sub    %rax,%rcx
 1f837e7:	sub    %rdx,%rax
 1f837ea:	vmovq  %rsi,%xmm3
 1f837ef:	vmovq  %rax,%xmm2
 1f837f4:	vpunpcklqdq %xmm1,%xmm3,%xmm1
 1f837f8:	vmovdqu64 %zmm0,0xaf0(%r12)
 1f83803:	vmovq  %rcx,%xmm0
 1f83808:	vpunpcklqdq %xmm0,%xmm2,%xmm0
 1f8380c:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f83812:	vinserti64x4 $0x1,0x1e0(%rsp),%zmm0,%zmm0
 1f8381b:	vpaddq 0xb38(%r12),%zmm0,%zmm0
 1f83826:	vmovdqu64 %zmm0,0xb38(%r12)
 1f83831:	cmpq   $0x0,0xc20(%r11)
 1f83839:	je     1f84d06 <node_facts_window_run+0x7936>
 1f8383f:	mov    0x940(%r11),%rax
 1f83846:	mov    0x8(%rbp),%r12d
 1f8384a:	vpxor  %xmm0,%xmm0,%xmm0
 1f8384e:	vmovdqu %ymm0,0x890(%rsp)
 1f83857:	movq   $0x0,0x8b0(%rsp)
 1f83863:	mov    %r11,%rdi
 1f83866:	mov    %rax,0x1a0(%rsp)
 1f8386e:	rdtsc
 1f83870:	mov    %r12d,%esi
 1f83873:	mov    %rdx,0x4d0(%rsp)
 1f8387b:	lea    0x890(%rsp),%rdx
 1f83883:	mov    %rax,%r14
 1f83886:	vzeroupper
 1f83889:	call   1f96420 <node_rows_window_reads>
 1f8388e:	rdtsc
 1f83890:	mov    %rbp,%rsi
 1f83893:	mov    %rdx,0x3d0(%rsp)
 1f8389b:	mov    %r12d,%edx
 1f8389e:	mov    (%rsp),%rdi
 1f838a2:	mov    %rax,%r15
 1f838a5:	call   1f96b40 <node_rows_window_shapes>
 1f838aa:	mov    (%rsp),%rdi
 1f838ae:	rdtsc
 1f838b0:	mov    0xc10(%rdi),%rcx
 1f838b7:	or     0xc08(%rdi),%rcx
 1f838be:	mov    %rax,0x60(%rsp)
 1f838c3:	mov    %rdx,0x490(%rsp)
 1f838cb:	je     1f838e4 <node_facts_window_run+0x6514>
 1f838cd:	lea    0x890(%rsp),%rcx
 1f838d5:	mov    %rbp,%rsi
 1f838d8:	mov    %r12d,%edx
 1f838db:	call   1f96f70 <node_rows_window_updates>
 1f838e0:	mov    (%rsp),%rdi
 1f838e4:	rdtsc
 1f838e6:	mov    %rbp,%rsi
 1f838e9:	mov    %rdx,0x2d0(%rsp)
 1f838f1:	mov    %r12d,%edx
 1f838f4:	mov    %rax,0x350(%rsp)
 1f838fc:	call   1f97780 <node_rows_window_write>
 1f83901:	mov    %eax,%ecx
 1f83903:	rdtsc
 1f83905:	mov    0x8a0(%rsp),%r8
 1f8390d:	mov    0x8b0(%rsp),%r9d
 1f83915:	vpxor  %xmm0,%xmm0,%xmm0
 1f83919:	vmovdqu %xmm0,0x51c(%rsp)
 1f83922:	vmovdqa %xmm0,0x510(%rsp)
 1f8392b:	movl   $0x0,0xfc(%rsp)
 1f83936:	movq   $0x0,0x288(%rsp)
 1f83942:	mov    %rax,0x390(%rsp)
 1f8394a:	mov    %rdx,0x450(%rsp)
 1f83952:	sub    $0x8,%rsp
 1f83956:	mov    0x8(%rsp),%rdi
 1f8395b:	lea    0x290(%rsp),%rax
 1f83963:	lea    0x104(%rsp),%r10
 1f8396b:	lea    0x518(%rsp),%r11
 1f83973:	mov    %rbp,%rsi
 1f83976:	mov    %r12d,%edx
 1f83979:	mov    %ecx,0x298(%rsp)
 1f83980:	push   %rax
 1f83981:	push   %r10
 1f83983:	push   %r11
 1f83985:	call   1f97da0 <node_rows_window_values>
 1f8398a:	add    $0x20,%rsp
 1f8398e:	rdtsc
 1f83990:	mov    %rbp,%rsi
 1f83993:	mov    %rdx,0x5b0(%rsp)
 1f8399b:	mov    %rax,0x310(%rsp)
 1f839a3:	mov    (%rsp),%rdi
 1f839a7:	call   1f98c40 <node_rows_window_part>
 1f839ac:	mov    (%rsp),%rdi
 1f839b0:	rdtsc
 1f839b2:	movl   $0x0,0xd0(%rsp)
 1f839bd:	movq   $0x0,0xc8(%rsp)
 1f839c9:	cmpb   $0x1,0xd58(%rdi)
 1f839d0:	mov    %rax,0x220(%rsp)
 1f839d8:	mov    %rdx,0x570(%rsp)
 1f839e0:	jne    1f839f9 <node_facts_window_run+0x6629>
 1f839e2:	lea    0xc8(%rsp),%rcx
 1f839ea:	mov    %rbp,%rsi
 1f839ed:	mov    %r12d,%edx
 1f839f0:	call   1f98d50 <node_rows_window_summary>
 1f839f5:	mov    (%rsp),%rdi
 1f839f9:	rdtsc
 1f839fb:	mov    0xdc0(%rdi),%ecx
 1f83a01:	movl   $0x0,0xdc0(%rdi)
 1f83a0b:	mov    0xa90(%rdi),%r13d
 1f83a12:	cmpb   $0x0,0xdc4(%rdi)
 1f83a19:	mov    %rcx,0x268(%rsp)
 1f83a21:	mov    %rax,0x88(%rsp)
 1f83a29:	mov    %rdx,0x530(%rsp)
 1f83a31:	je     1f83a62 <node_facts_window_run+0x6692>
 1f83a33:	mov    0xdcc(%rdi),%ecx
 1f83a39:	mov    $0x1,%esi
 1f83a3e:	mov    %ecx,%ebx
 1f83a40:	inc    %ecx
 1f83a42:	and    $0x3,%ebx
 1f83a45:	mov    %ecx,0xdcc(%rdi)
 1f83a4b:	mov    0xc8(%rsp),%ebp
 1f83a52:	cmp    $0x2,%ebx
 1f83a55:	jne    1f84931 <node_facts_window_run+0x7561>
 1f83a5b:	mov    $0x2,%ebx
 1f83a60:	jmp    1f83a7b <node_facts_window_run+0x66ab>
 1f83a62:	mov    0xc8(%rsp),%ebp
 1f83a69:	mov    $0xffffffff,%ebx
 1f83a6e:	mov    %ebx,%eax
 1f83a70:	xor    $0x3,%eax
 1f83a73:	xor    %esi,%esi
 1f83a75:	or     %ebp,%eax
 1f83a77:	sete   %sil
 1f83a7b:	cmpb   $0x1,0xd58(%rdi)
 1f83a82:	mov    %esi,0x114(%rsp)
 1f83a89:	mov    %r15,0x260(%rsp)
 1f83a91:	mov    %r14,0x70(%rsp)
 1f83a96:	jne    1f83b54 <node_facts_window_run+0x6784>
 1f83a9c:	mov    0xd98(%rdi),%rsi
 1f83aa3:	mov    0xda8(%rdi),%rdi
 1f83aaa:	lea    (%r12,%r12,1),%rdx
 1f83aae:	call   355e9b0 <memcpy>
 1f83ab3:	mov    (%rsp),%rax
 1f83ab7:	mov    (%rsp),%rcx
 1f83abb:	mov    %r13,%rdx
 1f83abe:	mov    0xda0(%rax),%rsi
 1f83ac5:	mov    0xdb0(%rcx),%rdi
 1f83acc:	call   355e9b0 <memcpy>
 1f83ad1:	mov    (%rsp),%rax
 1f83ad5:	mov    (%rsp),%rcx
 1f83ad9:	mov    %ebp,%edx
 1f83adb:	shl    $0x2,%rdx
 1f83adf:	mov    0xd90(%rax),%rsi
 1f83ae6:	mov    0xdb8(%rcx),%rdi
 1f83aed:	call   355e9b0 <memcpy>
 1f83af2:	mov    (%rsp),%rdi
 1f83af6:	xor    %eax,%eax
 1f83af8:	mov    %r12d,%ecx
 1f83afb:	sub    $0x1,%ecx
 1f83afe:	cmovb  %eax,%ecx
 1f83b01:	test   %ebx,%ebx
 1f83b03:	sete   %dl
 1f83b06:	cmp    $0x1,%ebx
 1f83b09:	sete   %sil
 1f83b0d:	test   %r13d,%r13d
 1f83b10:	sete   %r8b
 1f83b14:	mov    0xda8(%rdi),%rax
 1f83b1b:	and    %sil,%r8b
 1f83b1e:	or     %dl,%r8b
 1f83b21:	movzbl %r8b,%edx
 1f83b25:	xor    %dx,(%rax,%rcx,2)
 1f83b29:	test   %r13d,%r13d
 1f83b2c:	mov    0xdb0(%rdi),%rax
 1f83b33:	setne  %cl
 1f83b36:	and    %sil,%cl
 1f83b39:	xor    %cl,(%rax)
 1f83b3b:	cmp    $0x3,%ebx
 1f83b3e:	mov    0xdb8(%rdi),%rdx
 1f83b45:	sete   %al
 1f83b48:	test   %ebp,%ebp
 1f83b4a:	setne  %cl
 1f83b4d:	and    %al,%cl
 1f83b4f:	movzbl %cl,%eax
 1f83b52:	xor    %eax,(%rdx)
 1f83b54:	mov    %ebp,0x118(%rsp)
 1f83b5b:	mov    %r13,0x630(%rsp)
 1f83b63:	mov    0xca8(%rdi),%rsi
 1f83b6a:	mov    0xcb8(%rdi),%rdi
 1f83b71:	mov    0x290(%rsp),%r14d
 1f83b79:	mov    %r14d,%ebx
 1f83b7c:	mov    %rbx,%rdx
 1f83b7f:	call   355e9b0 <memcpy>
 1f83b84:	mov    (%rsp),%rax
 1f83b88:	mov    (%rsp),%rcx
 1f83b8c:	mov    %rbx,%rdx
 1f83b8f:	mov    0xcb0(%rax),%rsi
 1f83b96:	mov    0xcc0(%rcx),%rdi
 1f83b9d:	call   355e9b0 <memcpy>
 1f83ba2:	mov    (%rsp),%rax
 1f83ba6:	mov    (%rsp),%rcx
 1f83baa:	lea    0x0(,%rbx,8),%rdx
 1f83bb2:	mov    %rbx,0x648(%rsp)
 1f83bba:	mov    %rdx,0x638(%rsp)
 1f83bc2:	mov    0xcc8(%rax),%rsi
 1f83bc9:	mov    0xcd0(%rcx),%rdi
 1f83bd0:	call   355e9b0 <memcpy>
 1f83bd5:	mov    (%rsp),%rax
 1f83bd9:	mov    $0xffffffff,%edi
 1f83bde:	movzbl 0xdd0(%rax),%ecx
 1f83be5:	mov    (%rsp),%rax
 1f83be9:	mov    0xdd8(%rax),%edx
 1f83bef:	imul   $0x4ec4ec4f,%rdx,%rax
 1f83bf6:	shr    $0x22,%rax
 1f83bfa:	lea    (%rax,%rax,2),%esi
 1f83bfd:	lea    (%rax,%rsi,4),%eax
 1f83c00:	mov    %edx,%esi
 1f83c02:	sub    %eax,%esi
 1f83c04:	test   %ecx,%ecx
 1f83c06:	cmovne %esi,%edi
 1f83c09:	xor    %eax,%eax
 1f83c0b:	lea    -0x1(%rdi),%esi
 1f83c0e:	cmp    $0x3,%esi
 1f83c11:	mov    %r12d,%esi
 1f83c14:	cmovae %edi,%eax
 1f83c17:	test   %r14d,%r14d
 1f83c1a:	cmovne %edi,%eax
 1f83c1d:	add    %edx,%ecx
 1f83c1f:	mov    (%rsp),%rdx
 1f83c23:	mov    (%rsp),%rdi
 1f83c27:	cmp    $0x1,%eax
 1f83c2a:	vpbroadcastd %eax,%xmm0
 1f83c30:	vpcmpeqd -0x19bbe48(%rip),%xmm0,%xmm1        # 5c7df0 <.LCPI3_69>
 1f83c38:	vpcmpeqd -0x19bbe40(%rip),%xmm0,%xmm0        # 5c7e00 <.LCPI3_70>
 1f83c40:	mov    %ecx,0xdd8(%rdx)
 1f83c46:	mov    (%rsp),%rcx
 1f83c4a:	sete   %dl
 1f83c4d:	vpsrld $0x1f,%xmm1,%xmm1
 1f83c52:	vpsrld $0x1f,%xmm0,%xmm0
 1f83c57:	mov    0xcb8(%rcx),%rcx
 1f83c5e:	xor    %dl,(%rcx)
 1f83c60:	mov    (%rsp),%rcx
 1f83c64:	cmp    $0x2,%eax
 1f83c67:	sete   %dl
 1f83c6a:	mov    0xcc0(%rcx),%rcx
 1f83c71:	xor    %dl,(%rcx)
 1f83c73:	xor    %ecx,%ecx
 1f83c75:	cmp    $0x3,%eax
 1f83c78:	mov    0xcd0(%rdi),%rdx
 1f83c7f:	sete   %cl
 1f83c82:	xor    %rcx,(%rdx)
 1f83c85:	mov    0xfc(%rsp),%ecx
 1f83c8c:	vmovsd 0x510(%rsp),%xmm2
 1f83c95:	vmovups 0x51c(%rsp),%xmm3
 1f83c9e:	mov    %rcx,0x278(%rsp)
 1f83ca6:	mov    0x288(%rsp),%rcx
 1f83cae:	mov    %rcx,0x270(%rsp)
 1f83cb6:	mov    0x518(%rsp),%ecx
 1f83cbd:	vmovups %ymm2,0x830(%rsp)
 1f83cc6:	vshufps $0x24,%xmm3,%xmm2,%xmm2
 1f83ccb:	mov    %rcx,0x650(%rsp)
 1f83cd3:	vpinsrd $0x2,%ecx,%xmm2,%xmm2
 1f83cd9:	xor    %ecx,%ecx
 1f83cdb:	cmp    $0xc,%eax
 1f83cde:	vmovaps %xmm3,0x800(%rsp)
 1f83ce7:	sete   %cl
 1f83cea:	xor    0x528(%rsp),%ecx
 1f83cf1:	vpxor  %xmm1,%xmm2,%xmm1
 1f83cf5:	xor    %ebx,%ebx
 1f83cf7:	test   %eax,%eax
 1f83cf9:	vmovdqa %xmm1,0x6c0(%rsp)
 1f83d02:	vshufps $0xe9,%xmm3,%xmm3,%xmm1
 1f83d07:	sete   %bpl
 1f83d0b:	cmp    $0x4,%eax
 1f83d0e:	vxorps %xmm0,%xmm1,%xmm0
 1f83d12:	sete   0x5f(%rsp)
 1f83d17:	cmp    $0x5,%eax
 1f83d1a:	vmovlps %xmm0,0x6d0(%rsp)
 1f83d23:	vxorps %xmm0,%xmm0,%xmm0
 1f83d27:	mov    %ecx,0x6d8(%rsp)
 1f83d2e:	rdtsc
 1f83d30:	vmovups %ymm0,0x760(%rsp)
 1f83d39:	movq   $0x0,0x780(%rsp)
 1f83d45:	mov    %rax,0x5f0(%rsp)
 1f83d4d:	mov    %rdx,0xf0(%rsp)
 1f83d55:	sete   0x5e(%rsp)
 1f83d5a:	lea    0x760(%rsp),%rdx
 1f83d62:	mov    (%rsp),%rdi
 1f83d66:	vzeroupper
 1f83d69:	call   1f96420 <node_rows_window_reads>
 1f83d6e:	rdtsc
 1f83d70:	mov    %rdx,0xe8(%rsp)
 1f83d78:	mov    %r12d,%edx
 1f83d7b:	mov    %rax,0x660(%rsp)
 1f83d83:	mov    0x18(%rsp),%r13
 1f83d88:	mov    (%rsp),%rdi
 1f83d8c:	mov    %r13,%rsi
 1f83d8f:	call   1f96b40 <node_rows_window_shapes>
 1f83d94:	mov    (%rsp),%rdi
 1f83d98:	rdtsc
 1f83d9a:	mov    0xc10(%rdi),%rcx
 1f83da1:	or     0xc08(%rdi),%rcx
 1f83da8:	mov    %rax,0x98(%rsp)
 1f83db0:	mov    %rdx,0x720(%rsp)
 1f83db8:	je     1f83dd1 <node_facts_window_run+0x6a01>
 1f83dba:	lea    0x760(%rsp),%rcx
 1f83dc2:	mov    %r13,%rsi
 1f83dc5:	mov    %r12d,%edx
 1f83dc8:	call   1f96f70 <node_rows_window_updates>
 1f83dcd:	mov    (%rsp),%rdi
 1f83dd1:	rdtsc
 1f83dd3:	mov    %bpl,%bl
 1f83dd6:	mov    %r13,%rsi
 1f83dd9:	mov    %rax,0x40(%rsp)
 1f83dde:	mov    %rdx,0x430(%rsp)
 1f83de6:	mov    %r12d,%edx
 1f83de9:	call   1f97780 <node_rows_window_write>
 1f83dee:	mov    %eax,%ebp
 1f83df0:	rdtsc
 1f83df2:	mov    0x770(%rsp),%r8
 1f83dfa:	mov    0x780(%rsp),%r9d
 1f83e02:	vxorps %xmm0,%xmm0,%xmm0
 1f83e06:	vmovups %xmm0,0x6ac(%rsp)
 1f83e0f:	vmovaps %xmm0,0x6a0(%rsp)
 1f83e18:	movl   $0x0,0xf8(%rsp)
 1f83e23:	movq   $0x0,0x280(%rsp)
 1f83e2f:	mov    %rax,0x80(%rsp)
 1f83e37:	mov    %rdx,0x6e0(%rsp)
 1f83e3f:	sub    $0x8,%rsp
 1f83e43:	mov    0x8(%rsp),%rdi
 1f83e48:	lea    0x288(%rsp),%rax
 1f83e50:	lea    0x6a8(%rsp),%r11
 1f83e58:	mov    %r12,0xe8(%rsp)
 1f83e60:	lea    0x100(%rsp),%r10
 1f83e68:	mov    %r13,%rsi
 1f83e6b:	mov    %r12d,%edx
 1f83e6e:	mov    %ebp,0x124(%rsp)
 1f83e75:	mov    %ebp,%ecx
 1f83e77:	push   %rax
 1f83e78:	push   %r10
 1f83e7a:	push   %r11
 1f83e7c:	call   1f97da0 <node_rows_window_values>
 1f83e81:	add    $0x20,%rsp
 1f83e85:	rdtsc
 1f83e87:	mov    %r13,%rsi
 1f83e8a:	mov    %rdx,0x410(%rsp)
 1f83e92:	mov    %rax,0x90(%rsp)
 1f83e9a:	mov    (%rsp),%rdi
 1f83e9e:	call   1f98c40 <node_rows_window_part>
 1f83ea3:	mov    (%rsp),%r11
 1f83ea7:	rdtsc
 1f83ea9:	movl   $0x0,0x108(%rsp)
 1f83eb4:	movq   $0x0,0x100(%rsp)
 1f83ec0:	cmpb   $0x1,0xd58(%r11)
 1f83ec8:	mov    %rax,0x78(%rsp)
 1f83ecd:	mov    %rdx,0x7c0(%rsp)
 1f83ed5:	jne    1f83ef6 <node_facts_window_run+0x6b26>
 1f83ed7:	lea    0x100(%rsp),%rcx
 1f83edf:	mov    0xe0(%rsp),%rdx
 1f83ee7:	mov    %r11,%rdi
 1f83eea:	mov    %r13,%rsi
 1f83eed:	call   1f98d50 <node_rows_window_summary>
 1f83ef2:	mov    (%rsp),%r11
 1f83ef6:	rdtsc
 1f83ef8:	mov    0xdc0(%r11),%ecx
 1f83eff:	xor    %ebx,%r14d
 1f83f02:	movl   $0x0,0xdc0(%r11)
 1f83f0d:	cmpl   $0x0,0xa90(%r11)
 1f83f15:	mov    %rax,0xd8(%rsp)
 1f83f1d:	mov    %rdx,0x640(%rsp)
 1f83f25:	mov    %r14d,0x290(%rsp)
 1f83f2d:	mov    %ecx,0x110(%rsp)
 1f83f34:	mov    0x1a0(%rsp),%rbp
 1f83f3c:	je     1f847e7 <node_facts_window_run+0x7417>
 1f83f42:	vpbroadcastq -0x19b5a13(%rip),%xmm2        # 5ce538 <.LCPI3_1>
 1f83f4b:	xor    %r15d,%r15d
 1f83f4e:	jmp    1f83f6f <node_facts_window_run+0x6b9f>
 1f83f50:	mov    (%rsp),%r11
 1f83f54:	incq   0xbb8(%rbp,%rsi,8)
 1f83f5c:	mov    0xa90(%r11),%eax
 1f83f63:	inc    %r15
 1f83f66:	cmp    %rax,%r15
 1f83f69:	jae    1f847e7 <node_facts_window_run+0x7417>
 1f83f6f:	mov    0xd40(%r11),%rax
 1f83f76:	movzbl (%rax,%r15,1),%eax
 1f83f7b:	test   %al,%al
 1f83f7d:	je     1f83f5c <node_facts_window_run+0x6b8c>
 1f83f7f:	mov    0xa70(%r11),%rdx
 1f83f86:	mov    0xa68(%r11),%rcx
 1f83f8d:	mov    (%rdx,%r15,4),%edx
 1f83f91:	mov    (%rcx,%r15,4),%r14d
 1f83f95:	mov    0x651b8(%r13,%rdx,4),%edi
 1f83f9d:	incq   0xb90(%rbp)
 1f83fa4:	mov    0xa58(%r11),%rcx
 1f83fab:	mov    (%rcx,%r15,4),%ecx
 1f83faf:	add    %rcx,0xb98(%rbp)
 1f83fb6:	cmp    $0x1,%al
 1f83fb8:	jne    1f84020 <node_facts_window_run+0x6c50>
 1f83fba:	mov    0xa58(%r11),%rax
 1f83fc1:	mov    $0x1,%esi
 1f83fc6:	mov    (%rax,%r15,4),%r10d
 1f83fca:	test   %r10d,%r10d
 1f83fcd:	je     1f83f54 <node_facts_window_run+0x6b84>
 1f83fcf:	mov    0xbe8(%r11),%rax
 1f83fd6:	sub    %edi,%edx
 1f83fd8:	xor    %ecx,%ecx
 1f83fda:	xor    %r11d,%r11d
 1f83fdd:	inc    %edx
 1f83fdf:	nop
 1f83fe0:	lea    (%rdx,%r11,1),%r9d
 1f83fe4:	cmp    %edi,%r11d
 1f83fe7:	cmovae %r14d,%r9d
 1f83feb:	mov    %r9d,%r8d
 1f83fee:	shr    $0x3,%r8d
 1f83ff2:	and    $0xfffffff8,%r8d
 1f83ff6:	mov    0x28(%rax,%r8,8),%rbx
 1f83ffb:	bt     %r9,%rbx
 1f83fff:	jb     1f84370 <node_facts_window_run+0x6fa0>
 1f84005:	inc    %r11d
 1f84008:	cmp    %r11d,%r10d
 1f8400b:	jne    1f83fe0 <node_facts_window_run+0x6c10>
 1f8400d:	jmp    1f83f50 <node_facts_window_run+0x6b80>
 1f84012:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f84020:	mov    0xa68(%r11),%rcx
 1f84027:	mov    0xa70(%r11),%rdx
 1f8402e:	mov    0xa58(%r11),%rax
 1f84035:	xor    %r9d,%r9d
 1f84038:	mov    (%rcx,%r15,4),%ecx
 1f8403c:	mov    %rcx,0x8(%rsp)
 1f84041:	mov    (%rdx,%r15,4),%ecx
 1f84045:	mov    0xc40(%r11),%rdx
 1f8404c:	mov    0x651b8(%r13,%rcx,4),%esi
 1f84054:	cmp    %esi,(%rax,%r15,4)
 1f84058:	jbe    1f84064 <node_facts_window_run+0x6c94>
 1f8405a:	mov    0x8(%rsp),%rax
 1f8405f:	movzbl (%rdx,%rax,1),%r9d
 1f84064:	mov    0xc60(%r11),%r8
 1f8406b:	mov    0xc80(%r11),%r10
 1f84072:	mov    %ecx,%edi
 1f84074:	sub    %esi,%edi
 1f84076:	mov    %ecx,%esi
 1f84078:	shr    $0x3,%esi
 1f8407b:	mov    0x940(%r11),%rax
 1f84082:	inc    %edi
 1f84084:	movzbl (%r8,%rdi,1),%ebx
 1f84089:	shr    $0x3,%edi
 1f8408c:	mov    (%r10,%rsi,4),%r12d
 1f84090:	mov    0xa50(%r11),%rsi
 1f84097:	mov    %r10,0x28(%rsp)
 1f8409c:	mov    %r8,0x20(%rsp)
 1f840a1:	add    (%r10,%rdi,4),%ebx
 1f840a5:	movzbl (%r8,%rcx,1),%edi
 1f840aa:	movzbl (%rdx,%rcx,1),%r10d
 1f840af:	mov    %r12d,%ecx
 1f840b2:	mov    (%rsi,%r15,4),%esi
 1f840b6:	mov    %rbx,0x10(%rsp)
 1f840bb:	sub    %ebx,%ecx
 1f840bd:	mov    0x130(%rax),%rbx
 1f840c4:	add    %edi,%ecx
 1f840c6:	add    %r10d,%ecx
 1f840c9:	add    %ecx,%r9d
 1f840cc:	mov    (%rbx,%rsi,4),%r8d
 1f840d0:	cmp    $0xffffffff,%r8d
 1f840d4:	je     1f84365 <node_facts_window_run+0x6f95>
 1f840da:	mov    %r12d,0x160(%rsp)
 1f840e2:	mov    %r10,0x50(%rsp)
 1f840e7:	mov    %rdi,0x1e0(%rsp)
 1f840ef:	mov    0xdd4(%r11),%r10d
 1f840f6:	movzbl 0xdd0(%r11),%edi
 1f840fe:	mov    $0x4,%edx
 1f84103:	mov    %r14,0xb0(%rsp)
 1f8410b:	mov    %r10d,%ebx
 1f8410e:	and    $0x3,%ebx
 1f84111:	test   %edi,%edi
 1f84113:	mov    %r10d,0xb8(%rsp)
 1f8411b:	cmove  %edx,%ebx
 1f8411e:	test   $0x4,%r10b
 1f84122:	movabs $0x8000000000000000,%r10
 1f8412c:	mov    $0x1,%edx
 1f84131:	cmove  %rdx,%r10
 1f84135:	test   %r8d,%r8d
 1f84138:	sete   %dl
 1f8413b:	mov    %r10,0x38(%rsp)
 1f84140:	mov    %edi,0xa0(%rsp)
 1f84147:	mov    %r8d,0xa8(%rsp)
 1f8414f:	mov    %r9,0x48(%rsp)
 1f84154:	and    %dil,%dl
 1f84157:	cmp    $0x2,%ebx
 1f8415a:	sete   %dil
 1f8415e:	or     %dl,%dil
 1f84161:	movzbl %dil,%edx
 1f84165:	add    %r8d,%edx
 1f84168:	mov    0x110(%rax),%r8
 1f8416f:	cmp    $0x3,%ebx
 1f84172:	sete   %dil
 1f84176:	cmpb   $0x0,(%r8,%rsi,1)
 1f8417b:	setne  %r8b
 1f8417f:	cmp    %edx,%r9d
 1f84182:	setne  %r12b
 1f84186:	xor    %r10d,%r10d
 1f84189:	or     %r8b,%r12b
 1f8418c:	jne    1f844c9 <node_facts_window_run+0x70f9>
 1f84192:	test   %edx,%edx
 1f84194:	je     1f844c9 <node_facts_window_run+0x70f9>
 1f8419a:	mov    0x128(%rax),%rdx
 1f841a1:	mov    0x140(%rax),%rbp
 1f841a8:	mov    %ecx,%ecx
 1f841aa:	mov    (%rdx,%rsi,4),%edx
 1f841ad:	mov    0x148(%rax),%rsi
 1f841b4:	add    %rdx,%rsi
 1f841b7:	add    %rdx,%rbp
 1f841ba:	shl    $0x3,%rdx
 1f841be:	add    0x150(%rax),%rdx
 1f841c5:	cmp    $0x1,%ebx
 1f841c8:	mov    %rsi,0x68(%rsp)
 1f841cd:	sete   %al
 1f841d0:	cmp    $0x3,%ebx
 1f841d3:	mov    %rdx,0x30(%rsp)
 1f841d8:	sete   %dl
 1f841db:	mov    0x48(%rsp),%r8
 1f841e0:	cmp    $0x2,%r8d
 1f841e4:	lea    -0x1(%r8),%r13d
 1f841e8:	mov    %r8d,%r8d
 1f841eb:	setae  %sil
 1f841ef:	and    %al,%sil
 1f841f2:	mov    0x8(%rsp),%rax
 1f841f7:	shr    $0x3,%eax
 1f841fa:	mov    %rax,0x120(%rsp)
 1f84202:	or     %dl,%sil
 1f84205:	mov    (%rsp),%rax
 1f84209:	mov    0xca8(%rax),%r11
 1f84210:	test   %sil,%sil
 1f84213:	je     1f843d5 <node_facts_window_run+0x7005>
 1f84219:	mov    0xb8(%rsp),%eax
 1f84220:	xor    %esi,%esi
 1f84222:	and    $0x8,%eax
 1f84225:	shr    $0x3,%eax
 1f84228:	and    %al,%dil
 1f8422b:	mov    $0x0,%edi
 1f84230:	mov    0x10(%rsp),%rax
 1f84235:	cmovne %r13,%rdi
 1f84239:	sub    0x160(%rsp),%eax
 1f84240:	neg    %r13
 1f84243:	xor    %r14d,%r14d
 1f84246:	sub    0x50(%rsp),%eax
 1f8424a:	neg    %rdi
 1f8424d:	sub    0x1e0(%rsp),%eax
 1f84254:	mov    %rax,0x50(%rsp)
 1f84259:	mov    $0x1,%eax
 1f8425e:	mov    %r13,0x1e0(%rsp)
 1f84266:	jmp    1f8428a <node_facts_window_run+0x6eba>
 1f84268:	nopl   0x0(%rax,%rax,1)
 1f84270:	inc    %rsi
 1f84273:	cmp    %r8,%rax
 1f84276:	mov    %r10d,%r14d
 1f84279:	setae  %dl
 1f8427c:	inc    %rax
 1f8427f:	or     %r12b,%dl
 1f84282:	test   %dl,%dl
 1f84284:	jne    1f844c9 <node_facts_window_run+0x70f9>
 1f8428a:	lea    -0x1(%rax),%rdx
 1f8428e:	cmp    %rcx,%rdx
 1f84291:	jae    1f842a0 <node_facts_window_run+0x6ed0>
 1f84293:	mov    0x10(%rsp),%rdx
 1f84298:	lea    (%rdx,%rsi,1),%r9d
 1f8429c:	mov    %esi,%edx
 1f8429e:	jmp    1f842d1 <node_facts_window_run+0x6f01>
 1f842a0:	mov    0x8(%rsp),%rdx
 1f842a5:	mov    0x20(%rsp),%r9
 1f842aa:	mov    0x28(%rsp),%r12
 1f842af:	mov    0x120(%rsp),%r10
 1f842b7:	movzbl (%r9,%rdx,1),%r9d
 1f842bc:	mov    0x50(%rsp),%rdx
 1f842c1:	add    (%r12,%r10,4),%r9d
 1f842c5:	lea    (%rdx,%rax,1),%r10d
 1f842c9:	lea    -0x1(%rax),%edx
 1f842cc:	lea    -0x1(%r10,%r9,1),%r9d
 1f842d1:	or     %ebx,%edx
 1f842d3:	lea    (%rdi,%rax,1),%r10
 1f842d7:	mov    $0x0,%edx
 1f842dc:	mov    $0x1,%r12b
 1f842df:	mov    %r9d,%r9d
 1f842e2:	sete   %r13b
 1f842e6:	xor    -0x1(%rbp,%rax,1),%r13b
 1f842eb:	cmp    $0x1,%r10
 1f842ef:	mov    $0x1,%r10b
 1f842f2:	cmove  0x38(%rsp),%rdx
 1f842f8:	cmp    %r13b,(%r11,%r9,1)
 1f842fc:	jne    1f84339 <node_facts_window_run+0x6f69>
 1f842fe:	mov    0x1e0(%rsp),%r12
 1f84306:	cmp    $0x1,%ebx
 1f84309:	sete   %r13b
 1f8430d:	add    %rax,%r12
 1f84310:	cmp    $0x1,%r12
 1f84314:	sete   %r12b
 1f84318:	and    %r13b,%r12b
 1f8431b:	mov    0x68(%rsp),%r13
 1f84320:	xor    -0x1(%r13,%rax,1),%r12b
 1f84325:	mov    (%rsp),%r13
 1f84329:	mov    0xcb0(%r13),%r13
 1f84330:	cmp    %r12b,0x0(%r13,%r9,1)
 1f84335:	setne  %r12b
 1f84339:	test   $0x1,%r14b
 1f8433d:	jne    1f84270 <node_facts_window_run+0x6ea0>
 1f84343:	mov    0x30(%rsp),%r10
 1f84348:	mov    (%rsp),%r14
 1f8434c:	xor    -0x8(%r10,%rax,8),%rdx
 1f84351:	mov    0xcc8(%r14),%r10
 1f84358:	cmp    %rdx,(%r10,%r9,8)
 1f8435c:	setne  %r10b
 1f84360:	jmp    1f84270 <node_facts_window_run+0x6ea0>
 1f84365:	xor    %r10d,%r10d
 1f84368:	xor    %r12d,%r12d
 1f8436b:	jmp    1f84504 <node_facts_window_run+0x7134>
 1f84370:	mov    (%rsp),%r11
 1f84374:	mov    %r9d,%edx
 1f84377:	mov    0xbb0(%r11),%rsi
 1f8437e:	movzbl (%rsi,%rdx,1),%esi
 1f84382:	and    $0x3f,%sil
 1f84386:	cmp    $0x14,%sil
 1f8438a:	je     1f8439c <node_facts_window_run+0x6fcc>
 1f8438c:	mov    0xc30(%r11),%rsi
 1f84393:	xor    %ecx,%ecx
 1f84395:	cmpb   $0x7f,(%rsi,%rdx,1)
 1f84399:	setne  %cl
 1f8439c:	and    $0x3f,%r9d
 1f843a0:	mov    $0x1,%edx
 1f843a5:	mov    $0x2,%esi
 1f843aa:	shlx   %r9,%rdx,%rdx
 1f843af:	test   %rdx,0x30(%rax,%r8,8)
 1f843b4:	jne    1f83f54 <node_facts_window_run+0x6b84>
 1f843ba:	test   %rdx,0x38(%rax,%r8,8)
 1f843bf:	mov    $0x3,%eax
 1f843c4:	cmovne %rax,%rcx
 1f843c8:	incq   0xbb8(%rbp,%rcx,8)
 1f843d0:	jmp    1f83f5c <node_facts_window_run+0x6b8c>
 1f843d5:	mov    0x10(%rsp),%rax
 1f843da:	sub    0x160(%rsp),%eax
 1f843e1:	xor    %esi,%esi
 1f843e3:	xor    %edi,%edi
 1f843e5:	sub    0x50(%rsp),%eax
 1f843e9:	sub    0x1e0(%rsp),%eax
 1f843f0:	jmp    1f84418 <node_facts_window_run+0x7048>
 1f843f2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f84400:	inc    %rsi
 1f84403:	mov    %r10d,%edi
 1f84406:	cmp    %r8,%rsi
 1f84409:	setae  %dl
 1f8440c:	or     %r12b,%dl
 1f8440f:	cmp    $0x1,%dl
 1f84412:	je     1f844c9 <node_facts_window_run+0x70f9>
 1f84418:	cmp    %rcx,%rsi
 1f8441b:	jae    1f84430 <node_facts_window_run+0x7060>
 1f8441d:	mov    0x10(%rsp),%rdx
 1f84422:	add    %esi,%edx
 1f84424:	jmp    1f84454 <node_facts_window_run+0x7084>
 1f84426:	cs nopw 0x0(%rax,%rax,1)
 1f84430:	mov    0x8(%rsp),%rdx
 1f84435:	mov    0x20(%rsp),%r9
 1f8443a:	mov    0x120(%rsp),%r10
 1f84442:	movzbl (%r9,%rdx,1),%edx
 1f84447:	mov    0x28(%rsp),%r9
 1f8444c:	add    (%r9,%r10,4),%edx
 1f84450:	add    %eax,%edx
 1f84452:	add    %esi,%edx
 1f84454:	mov    %esi,%r9d
 1f84457:	or     %ebx,%r9d
 1f8445a:	mov    $0x1,%r10b
 1f8445d:	mov    $0x1,%r12b
 1f84460:	mov    %edx,%edx
 1f84462:	sete   %r9b
 1f84466:	xor    0x0(%rbp,%rsi,1),%r9b
 1f8446b:	cmp    %r9b,(%r11,%rdx,1)
 1f8446f:	jne    1f8449e <node_facts_window_run+0x70ce>
 1f84471:	cmp    $0x1,%ebx
 1f84474:	sete   %r9b
 1f84478:	cmp    %rsi,%r13
 1f8447b:	sete   %r14b
 1f8447f:	and    %r9b,%r14b
 1f84482:	mov    0x68(%rsp),%r9
 1f84487:	xor    (%r9,%rsi,1),%r14b
 1f8448b:	mov    (%rsp),%r9
 1f8448f:	mov    0xcb0(%r9),%r9
 1f84496:	cmp    %r14b,(%r9,%rdx,1)
 1f8449a:	setne  %r12b
 1f8449e:	test   $0x1,%dil
 1f844a2:	jne    1f84400 <node_facts_window_run+0x7030>
 1f844a8:	mov    0x30(%rsp),%rdi
 1f844ad:	mov    (%rsp),%r9
 1f844b1:	mov    (%rdi,%rsi,8),%rdi
 1f844b5:	mov    0xcc8(%r9),%r9
 1f844bc:	cmp    %rdi,(%r9,%rdx,8)
 1f844c0:	setne  %r10b
 1f844c4:	jmp    1f84400 <node_facts_window_run+0x7030>
 1f844c9:	mov    0xb8(%rsp),%eax
 1f844d0:	mov    (%rsp),%r11
 1f844d4:	mov    0x18(%rsp),%r13
 1f844d9:	mov    0x1a0(%rsp),%rbp
 1f844e1:	mov    0xb0(%rsp),%r14
 1f844e9:	mov    0x48(%rsp),%r9
 1f844ee:	mov    0xa8(%rsp),%r8d
 1f844f6:	add    0xa0(%rsp),%eax
 1f844fd:	mov    %eax,0xdd4(%r11)
 1f84504:	cmp    $0xffffffff,%r8d
 1f84508:	vmovd  %r9d,%xmm1
 1f8450d:	mov    %r12d,%ecx
 1f84510:	sete   %al
 1f84513:	incq   0xba0(%rbp)
 1f8451a:	or     %r10b,%r12b
 1f8451d:	xor    $0x1,%cl
 1f84520:	mov    0xa58(%r11),%rdx
 1f84527:	and    %r10b,%cl
 1f8452a:	vmovd  (%rdx,%r15,4),%xmm0
 1f84530:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f84534:	vpaddq 0xba8(%rbp),%xmm0,%xmm0
 1f8453c:	vmovdqu %xmm0,0xba8(%rbp)
 1f84544:	vmovd  %r12d,%xmm0
 1f84549:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f8454f:	movzbl %cl,%eax
 1f84552:	vpmovzxbq %xmm0,%xmm0
 1f84557:	vptestmq %xmm2,%xmm0,%k0
 1f8455d:	vmovdqu 0xbd8(%rbp),%xmm0
 1f84565:	vpmovm2q %k0,%xmm1
 1f8456b:	vpsubq %xmm1,%xmm0,%xmm0
 1f8456f:	vmovdqu %xmm0,0xbd8(%rbp)
 1f84577:	add    %rax,0xcc0(%rbp)
 1f8457e:	mov    0xd48(%r11),%rax
 1f84585:	mov    (%rax,%r15,8),%rax
 1f84589:	add    %rax,0xc48(%rbp)
 1f84590:	test   $0x1,%r12b
 1f84594:	je     1f845c0 <node_facts_window_run+0x71f0>
 1f84596:	mov    0x13ac(%rbp),%eax
 1f8459c:	cmp    $0xf,%rax
 1f845a0:	ja     1f83f5c <node_facts_window_run+0x6b8c>
 1f845a6:	mov    0x422c(%r13,%r14,4),%ecx
 1f845ae:	mov    %ecx,0x136c(%rbp,%rax,4)
 1f845b5:	incl   0x13ac(%rbp)
 1f845bb:	jmp    1f83f5c <node_facts_window_run+0x6b8c>
 1f845c0:	cmpb   $0x1,0xd58(%r11)
 1f845c8:	jne    1f83f5c <node_facts_window_run+0x6b8c>
 1f845ce:	mov    0xda0(%r11),%rax
 1f845d5:	mov    $0x4,%r12d
 1f845db:	movzbl (%rax,%r15,1),%r14d
 1f845e0:	incq   0xce8(%rbp)
 1f845e7:	mov    0xa70(%r11),%rax
 1f845ee:	mov    0xd98(%r11),%rcx
 1f845f5:	mov    (%rax,%r15,4),%eax
 1f845f9:	lea    0x1(%rax),%edx
 1f845fc:	movzwl -0x2(%rcx,%rdx,2),%ebp
 1f84601:	sub    0x651b8(%r13,%rax,4),%edx
 1f84609:	cmpb   $0x1,0xdc4(%r11)
 1f84611:	movzwl -0x2(%rcx,%rdx,2),%eax
 1f84616:	jne    1f84629 <node_facts_window_run+0x7259>
 1f84618:	mov    0xdc8(%r11),%r12d
 1f8461f:	and    $0x3,%r12d
 1f84623:	je     1f846ee <node_facts_window_run+0x731e>
 1f84629:	cmp    $0x1,%r12d
 1f8462d:	mov    $0xffffffff,%r8d
 1f84633:	sete   %cl
 1f84636:	cmp    %ax,%bp
 1f84639:	sete   %bl
 1f8463c:	and    %cl,%bl
 1f8463e:	mov    0x940(%r11),%r13
 1f84645:	sub    %eax,%ebp
 1f84647:	cmpq   $0x0,0x168(%r13)
 1f8464f:	je     1f847a4 <node_facts_window_run+0x73d4>
 1f84655:	mov    0xa50(%r11),%rcx
 1f8465c:	mov    (%rcx,%r15,4),%edx
 1f84660:	cmp    0x20(%r13),%edx
 1f84664:	jae    1f847a4 <node_facts_window_run+0x73d4>
 1f8466a:	mov    0x188(%r13),%rdi
 1f84671:	movzbl %bl,%esi
 1f84674:	mov    %ebp,%r9d
 1f84677:	lea    (%rsi,%rdi,1),%rcx
 1f8467b:	add    %r9,%rcx
 1f8467e:	cmp    0x190(%r13),%rcx
 1f84685:	ja     1f84712 <node_facts_window_run+0x7342>
 1f8468b:	cmp    $0xfffe,%ebp
 1f84691:	ja     1f84712 <node_facts_window_run+0x7342>
 1f84693:	shl    $0x2,%rdi
 1f84697:	mov    %r8d,0x28(%rsp)
 1f8469c:	mov    %rsi,0x10(%rsp)
 1f846a1:	lea    0x0(,%rax,4),%esi
 1f846a8:	add    0x180(%r13),%rdi
 1f846af:	add    0xd90(%r11),%rsi
 1f846b6:	mov    %rdx,0x8(%rsp)
 1f846bb:	lea    0x0(,%r9,4),%rdx
 1f846c3:	mov    %rdi,0x20(%rsp)
 1f846c8:	mov    %r9,0x38(%rsp)
 1f846cd:	call   355e9b0 <memcpy>
 1f846d2:	test   %bl,%bl
 1f846d4:	je     1f8471b <node_facts_window_run+0x734b>
 1f846d6:	mov    0x28(%rsp),%eax
 1f846da:	mov    0x20(%rsp),%rcx
 1f846df:	mov    0x38(%rsp),%rdx
 1f846e4:	mov    0x8(%rsp),%rsi
 1f846e9:	mov    %eax,(%rcx,%rdx,4)
 1f846ec:	jmp    1f84731 <node_facts_window_run+0x7361>
 1f846ee:	xor    %r8d,%r8d
 1f846f1:	mov    $0x1,%bl
 1f846f3:	xor    %r12d,%r12d
 1f846f6:	mov    0x940(%r11),%r13
 1f846fd:	sub    %eax,%ebp
 1f846ff:	cmpq   $0x0,0x168(%r13)
 1f84707:	jne    1f84655 <node_facts_window_run+0x7285>
 1f8470d:	jmp    1f847a4 <node_facts_window_run+0x73d4>
 1f84712:	incq   0x198(%r13)
 1f84719:	jmp    1f84795 <node_facts_window_run+0x73c5>
 1f8471b:	mov    0x20(%rsp),%rax
 1f84720:	mov    0x8(%rsp),%rsi
 1f84725:	cmp    $0x1,%r12d
 1f84729:	jne    1f84731 <node_facts_window_run+0x7361>
 1f8472b:	movl   $0x0,(%rax)
 1f84731:	mov    0x188(%r13),%eax
 1f84738:	mov    0x168(%r13),%rcx
 1f8473f:	mov    0x10(%rsp),%rdi
 1f84744:	mov    (%rsp),%r11
 1f84748:	mov    $0x1,%edx
 1f8474d:	vpbroadcastq -0x19b621e(%rip),%xmm2        # 5ce538 <.LCPI3_1>
 1f84756:	mov    %eax,(%rcx,%rsi,4)
 1f84759:	add    %ebp,%edi
 1f8475b:	cmp    $0x3,%r12d
 1f8475f:	mov    0x170(%r13),%rax
 1f84766:	sete   %cl
 1f84769:	add    %cl,%cl
 1f8476b:	cmp    $0x2,%r12d
 1f8476f:	movzbl %cl,%ecx
 1f84772:	cmove  %edx,%ecx
 1f84775:	mov    %di,(%rax,%rsi,2)
 1f84779:	mov    0xda0(%r11),%rax
 1f84780:	mov    0x178(%r13),%rdx
 1f84787:	xor    (%rax,%r15,1),%cl
 1f8478b:	mov    %cl,(%rdx,%rsi,1)
 1f8478e:	add    %rdi,0x188(%r13)
 1f84795:	movzbl 0xdc4(%r11),%eax
 1f8479d:	add    %eax,0xdc8(%r11)
 1f847a4:	vmovd  %ebp,%xmm1
 1f847a8:	mov    0x1a0(%rsp),%rbp
 1f847b0:	mov    $0x101,%eax
 1f847b5:	mov    0x18(%rsp),%r13
 1f847ba:	bextr  %eax,%r14d,%eax
 1f847bf:	and    $0x1,%r14d
 1f847c3:	vmovd  %eax,%xmm0
 1f847c7:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f847cb:	vpaddq 0xcf0(%rbp),%xmm0,%xmm0
 1f847d3:	vmovdqu %xmm0,0xcf0(%rbp)
 1f847db:	add    %r14,0xd00(%rbp)
 1f847e2:	jmp    1f83f5c <node_facts_window_run+0x6b8c>
 1f847e7:	shlq   $0x20,0x4d0(%rsp)
 1f847f0:	shlq   $0x20,0x3d0(%rsp)
 1f847f9:	shlq   $0x20,0x490(%rsp)
 1f84802:	shlq   $0x20,0x2d0(%rsp)
 1f8480b:	shlq   $0x20,0x450(%rsp)
 1f84814:	shlq   $0x20,0x5b0(%rsp)
 1f8481d:	shlq   $0x20,0x570(%rsp)
 1f84826:	shlq   $0x20,0x530(%rsp)
 1f8482f:	shlq   $0x20,0xf0(%rsp)
 1f84838:	shlq   $0x20,0xe8(%rsp)
 1f84841:	shlq   $0x20,0x720(%rsp)
 1f8484a:	shlq   $0x20,0x430(%rsp)
 1f84853:	shlq   $0x20,0x6e0(%rsp)
 1f8485c:	shlq   $0x20,0x410(%rsp)
 1f84865:	shlq   $0x20,0x7c0(%rsp)
 1f8486e:	mov    $0x1,%r8d
 1f84874:	vmovd  0xe0(%rsp),%xmm1
 1f8487d:	mov    0x648(%rsp),%rbx
 1f84885:	mov    0x640(%rsp),%r12
 1f8488d:	mov    0x11c(%rsp),%eax
 1f84894:	vmovd  %ebx,%xmm0
 1f84898:	shl    $0x20,%r12
 1f8489c:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f848a0:	vpaddq 0xbe8(%rbp),%xmm0,%xmm0
 1f848a8:	vmovdqu %xmm0,0xbe8(%rbp)
 1f848b0:	cmp    %eax,0x290(%rsp)
 1f848b7:	jne    1f84905 <node_facts_window_run+0x7535>
 1f848b9:	mov    0xca8(%r11),%rsi
 1f848c0:	mov    0xcb8(%r11),%rdi
 1f848c7:	mov    %rbx,%rdx
 1f848ca:	mov    %r11,%r14
 1f848cd:	call   355e9a0 <strlen+0x10>
 1f848d2:	mov    0xc0(%rsp),%r15
 1f848da:	mov    0x70(%rsp),%rsi
 1f848df:	mov    0x260(%rsp),%r13
 1f848e7:	test   %eax,%eax
 1f848e9:	je     1f84947 <node_facts_window_run+0x7577>
 1f848eb:	mov    %r14,%r11
 1f848ee:	mov    0x60(%rsp),%rax
 1f848f3:	mov    0x88(%rsp),%rcx
 1f848fb:	mov    0xd8(%rsp),%r14
 1f84903:	jmp    1f84982 <node_facts_window_run+0x75b2>
 1f84905:	mov    0xc0(%rsp),%r15
 1f8490d:	mov    0x70(%rsp),%rsi
 1f84912:	mov    0x260(%rsp),%r13
 1f8491a:	mov    0x60(%rsp),%rax
 1f8491f:	mov    0x88(%rsp),%rcx
 1f84927:	mov    0xd8(%rsp),%r14
 1f8492f:	jmp    1f84988 <node_facts_window_run+0x75b8>
 1f84931:	setb   %al
 1f84934:	test   %r12d,%r12d
 1f84937:	sete   %cl
 1f8493a:	test   %cl,%al
 1f8493c:	je     1f83a6e <node_facts_window_run+0x669e>
 1f84942:	jmp    1f83a7b <node_facts_window_run+0x66ab>
 1f84947:	mov    0xcb0(%r14),%rsi
 1f8494e:	mov    0xcc0(%r14),%rdi
 1f84955:	mov    %rbx,%rdx
 1f84958:	call   355e9a0 <strlen+0x10>
 1f8495d:	test   %eax,%eax
 1f8495f:	je     1f84ddb <node_facts_window_run+0x7a0b>
 1f84965:	mov    %r14,%r11
 1f84968:	mov    0x60(%rsp),%rax
 1f8496d:	mov    0x88(%rsp),%rcx
 1f84975:	mov    0xd8(%rsp),%r14
 1f8497d:	mov    0x70(%rsp),%rsi
 1f84982:	mov    $0x1,%r8d
 1f84988:	mov    0x2d0(%rsp),%rdx
 1f84990:	or     0x4d0(%rsp),%rsi
 1f84998:	or     0x3d0(%rsp),%r13
 1f849a0:	or     0x490(%rsp),%rax
 1f849a8:	add    %r8,0xbf8(%rbp)
 1f849af:	or     %r12,%r14
 1f849b2:	or     %rdx,0x350(%rsp)
 1f849ba:	mov    0x450(%rsp),%rdx
 1f849c2:	or     %rdx,0x390(%rsp)
 1f849ca:	mov    0x5b0(%rsp),%rdx
 1f849d2:	or     %rdx,0x310(%rsp)
 1f849da:	mov    0x570(%rsp),%rdx
 1f849e2:	or     %rdx,0x220(%rsp)
 1f849ea:	mov    0xf0(%rsp),%rdx
 1f849f2:	or     0x530(%rsp),%rcx
 1f849fa:	or     %rdx,0x5f0(%rsp)
 1f84a02:	mov    0xe8(%rsp),%rdx
 1f84a0a:	or     %rdx,0x660(%rsp)
 1f84a12:	mov    0x720(%rsp),%rdx
 1f84a1a:	or     %rdx,0x98(%rsp)
 1f84a22:	mov    0x430(%rsp),%rdx
 1f84a2a:	or     %rdx,0x40(%rsp)
 1f84a2f:	mov    0x6e0(%rsp),%rdx
 1f84a37:	or     %rdx,0x80(%rsp)
 1f84a3f:	mov    0x410(%rsp),%rdx
 1f84a47:	or     %rdx,0x90(%rsp)
 1f84a4f:	mov    0x7c0(%rsp),%rdx
 1f84a57:	or     %rdx,0x78(%rsp)
 1f84a5c:	cmpb   $0x1,0xd58(%r11)
 1f84a64:	jne    1f84af9 <node_facts_window_run+0x7729>
 1f84a6a:	mov    0x114(%rsp),%edx
 1f84a71:	mov    $0x1,%ebx
 1f84a76:	xor    0x118(%rsp),%edx
 1f84a7d:	cmp    0x100(%rsp),%edx
 1f84a84:	jne    1f84b02 <node_facts_window_run+0x7732>
 1f84a86:	mov    0xcc(%rsp),%edx
 1f84a8d:	mov    %rax,0x60(%rsp)
 1f84a92:	cmp    0x104(%rsp),%edx
 1f84a99:	jne    1f84afd <node_facts_window_run+0x772d>
 1f84a9b:	mov    0xd0(%rsp),%eax
 1f84aa2:	cmp    0x108(%rsp),%eax
 1f84aa9:	jne    1f84afd <node_facts_window_run+0x772d>
 1f84aab:	mov    %rsi,0x70(%rsp)
 1f84ab0:	mov    %rcx,0x88(%rsp)
 1f84ab8:	mov    0xd98(%r11),%rsi
 1f84abf:	mov    0xda8(%r11),%rdi
 1f84ac6:	mov    %r11,%r12
 1f84ac9:	mov    0xe0(%rsp),%rax
 1f84ad1:	lea    (%rax,%rax,1),%rdx
 1f84ad5:	call   355e9a0 <strlen+0x10>
 1f84ada:	test   %eax,%eax
 1f84adc:	je     1f84eab <node_facts_window_run+0x7adb>
 1f84ae2:	mov    0x60(%rsp),%rax
 1f84ae7:	mov    0x88(%rsp),%rcx
 1f84aef:	mov    0x70(%rsp),%rsi
 1f84af4:	mov    %r12,%r11
 1f84af7:	jmp    1f84b02 <node_facts_window_run+0x7732>
 1f84af9:	xor    %ebx,%ebx
 1f84afb:	jmp    1f84b02 <node_facts_window_run+0x7732>
 1f84afd:	mov    0x60(%rsp),%rax
 1f84b02:	vmovd  0x268(%rsp),%xmm1
 1f84b0b:	mov    0x220(%rsp),%rdx
 1f84b13:	vmovd  %ebx,%xmm2
 1f84b17:	mov    0x78(%rsp),%rdi
 1f84b1c:	vpmovzxdq 0x800(%rsp),%ymm7
 1f84b26:	vmovq  0x350(%rsp),%xmm4
 1f84b2f:	vmovq  %r13,%xmm3
 1f84b34:	vmovq  %rsi,%xmm5
 1f84b39:	mov    0x90(%rsp),%rsi
 1f84b41:	mov    0x80(%rsp),%r8
 1f84b49:	sub    %rdx,%rcx
 1f84b4c:	sub    %rdi,%r14
 1f84b4f:	vmovq  %rcx,%xmm0
 1f84b54:	mov    0x310(%rsp),%rcx
 1f84b5c:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84b60:	vmovd  0xd0(%rsp),%xmm1
 1f84b69:	sub    %rcx,%rdx
 1f84b6c:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f84b70:	vmovq  %rax,%xmm2
 1f84b75:	mov    0x390(%rsp),%rax
 1f84b7d:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f84b83:	vpaddq 0xd08(%rbp),%ymm0,%ymm0
 1f84b8b:	vmovd  0x278(%rsp),%xmm1
 1f84b94:	vpbroadcastq %rax,%ymm6
 1f84b9a:	sub    %rax,%rcx
 1f84b9d:	mov    %rsi,%rax
 1f84ba0:	sub    %r8,%rax
 1f84ba3:	vmovdqu %ymm0,0xd08(%rbp)
 1f84bab:	add    %r14,0xd28(%rbp)
 1f84bb2:	vmovq  0x270(%rsp),%xmm0
 1f84bbb:	vpaddq 0xc90(%rbp),%ymm7,%ymm7
 1f84bc3:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84bc7:	vmovdqu %ymm7,0xc90(%rbp)
 1f84bcf:	vpaddq 0xcb0(%rbp),%xmm0,%xmm0
 1f84bd7:	vmovdqu %xmm0,0xcb0(%rbp)
 1f84bdf:	vpunpcklqdq %xmm2,%xmm3,%xmm0
 1f84be3:	vmovq  0x40(%rsp),%xmm2
 1f84be9:	vmovq  0x98(%rsp),%xmm3
 1f84bf2:	vinserti128 $0x1,%xmm4,%ymm0,%ymm0
 1f84bf8:	vpbroadcastq %r8,%ymm4
 1f84bfe:	vpblendd $0xc0,%ymm6,%ymm0,%ymm1
 1f84c04:	vpermq $0x90,%ymm0,%ymm0
 1f84c0a:	vpbroadcastq %rsi,%ymm6
 1f84c10:	vpblendd $0x3,%ymm5,%ymm0,%ymm0
 1f84c16:	vpbroadcastq %rdi,%ymm5
 1f84c1c:	vpsubq %ymm0,%ymm1,%ymm0
 1f84c20:	vmovdqu 0x890(%rsp),%ymm1
 1f84c29:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f84c2d:	vpblendd $0x30,%ymm4,%ymm2,%ymm3
 1f84c33:	vpermq $0xd0,%ymm2,%ymm2
 1f84c39:	vmovdqa64 -0x1acdf43(%rip),%zmm4        # 4b6d00 <abi_test_hex.digits+0xb980>
 1f84c43:	vpblendd $0xc0,%ymm5,%ymm3,%ymm3
 1f84c49:	vpmovzxdq 0x830(%rsp),%zmm5
 1f84c54:	vinserti64x4 $0x1,%ymm0,%zmm1,%zmm0
 1f84c5b:	vpaddq 0xc00(%rbp),%zmm0,%zmm0
 1f84c62:	vmovq  %rcx,%xmm1
 1f84c67:	vmovdqu64 %zmm0,0xc00(%rbp)
 1f84c6e:	vmovq  %rax,%xmm0
 1f84c73:	mov    0x660(%rsp),%rax
 1f84c7b:	add    %rdx,0xc40(%rbp)
 1f84c82:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84c86:	vpmovzxdq 0xc8(%rsp),%xmm1
 1f84c90:	vmovq  %rax,%xmm7
 1f84c95:	sub    0x5f0(%rsp),%rax
 1f84c9d:	vpblendd $0x3,%ymm7,%ymm2,%ymm2
 1f84ca3:	vpblendd $0xc0,%ymm6,%ymm2,%ymm2
 1f84ca9:	vmovdqa64 -0x1acdff3(%rip),%zmm6        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f84cb3:	vpsubq %ymm2,%ymm3,%ymm2
 1f84cb7:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f84cbd:	vpaddq 0xcc8(%rbp),%ymm0,%ymm0
 1f84cc5:	vmovq  %rax,%xmm8
 1f84cca:	mov    $0x80,%al
 1f84ccc:	kmovd  %eax,%k1
 1f84cd0:	mov    0x650(%rsp),%rax
 1f84cd8:	vpermi2q %zmm8,%zmm2,%zmm6
 1f84cde:	vmovdqu %ymm0,0xcc8(%rbp)
 1f84ce6:	vpermi2q %zmm5,%zmm6,%zmm4
 1f84cec:	vpbroadcastq %rax,%zmm4{%k1}
 1f84cf2:	vpaddq 0xc50(%rbp),%zmm4,%zmm0
 1f84cfc:	vmovdqu64 %zmm0,0xc50(%rbp)
 1f84d06:	vmovups 0x9d0(%r11),%zmm0
 1f84d10:	vmovups 0x268(%r11),%zmm1
 1f84d1a:	vmovups 0x850(%rsp),%zmm3
 1f84d25:	vmovaps 0x820(%rsp),%xmm2
 1f84d2e:	xor    %esi,%esi
 1f84d30:	mov    %r15,%rdx
 1f84d33:	vmovups %zmm0,0x268(%r11)
 1f84d3d:	vmovups %zmm1,0x9d0(%r11)
 1f84d47:	vmovups 0xa10(%r11),%xmm0
 1f84d50:	vmovups 0x2a8(%r11),%xmm1
 1f84d59:	vmovups %xmm0,0x2a8(%r11)
 1f84d62:	vmovups %xmm1,0xa10(%r11)
 1f84d6b:	vmovaps 0x810(%rsp),%xmm1
 1f84d74:	mov    0x2b8(%r11),%rax
 1f84d7b:	mov    0xa20(%r11),%rcx
 1f84d82:	mov    %rcx,0x2b8(%r11)
 1f84d89:	mov    %rax,0xa20(%r11)
 1f84d90:	mov    0x658(%rsp),%rax
 1f84d98:	vmovups %zmm3,0x1f0(%r11)
 1f84da2:	mov    %rax,0x230(%r11)
 1f84da9:	vmovups %xmm2,0x240(%r11)
 1f84db2:	vmovlps %xmm1,0x258(%r11)
 1f84dbb:	mov    0x9b8(%r11),%rdi
 1f84dc2:	add    $0xca8,%rsp
 1f84dc9:	pop    %rbx
 1f84dca:	pop    %r12
 1f84dcc:	pop    %r13
 1f84dce:	pop    %r14
 1f84dd0:	pop    %r15
 1f84dd2:	pop    %rbp
 1f84dd3:	vzeroupper
 1f84dd6:	jmp    355ea20 <memset>
 1f84ddb:	mov    0xcc8(%r14),%rsi
 1f84de2:	mov    0xcd0(%r14),%rdi
 1f84de9:	mov    0x638(%rsp),%rdx
 1f84df1:	call   355e9a0 <strlen+0x10>
 1f84df6:	test   %eax,%eax
 1f84df8:	jne    1f84f2f <node_facts_window_run+0x7b5f>
 1f84dfe:	movzbl 0x5f(%rsp),%ecx
 1f84e03:	xor    %eax,%eax
 1f84e05:	mov    0xd8(%rsp),%r14
 1f84e0d:	mov    $0x1,%r8d
 1f84e13:	mov    %cl,%al
 1f84e15:	xor    0x278(%rsp),%eax
 1f84e1c:	mov    0x88(%rsp),%rcx
 1f84e24:	cmp    0xf8(%rsp),%eax
 1f84e2b:	mov    0x60(%rsp),%rax
 1f84e30:	jne    1f84f38 <node_facts_window_run+0x7b68>
 1f84e36:	movzbl 0x5e(%rsp),%esi
 1f84e3b:	mov    (%rsp),%r11
 1f84e3f:	xor    %edx,%edx
 1f84e41:	mov    %sil,%dl
 1f84e44:	xor    0x270(%rsp),%rdx
 1f84e4c:	cmp    0x280(%rsp),%rdx
 1f84e54:	jne    1f84f25 <node_facts_window_run+0x7b55>
 1f84e5a:	vmovdqu 0x6cc(%rsp),%xmm1
 1f84e63:	vmovdqa 0x6c0(%rsp),%xmm0
 1f84e6c:	mov    0x70(%rsp),%rsi
 1f84e71:	vpxor  0x6a0(%rsp),%xmm0,%xmm0
 1f84e7a:	vpternlogq $0xf6,0x6ac(%rsp),%xmm1,%xmm0
 1f84e86:	vptest %xmm0,%xmm0
 1f84e8b:	jne    1f84988 <node_facts_window_run+0x75b8>
 1f84e91:	mov    0x110(%rsp),%edx
 1f84e98:	xor    %r8d,%r8d
 1f84e9b:	cmp    %edx,0x268(%rsp)
 1f84ea2:	setne  %r8b
 1f84ea6:	jmp    1f84988 <node_facts_window_run+0x75b8>
 1f84eab:	mov    0xda0(%r12),%rsi
 1f84eb3:	mov    0xdb0(%r12),%rdi
 1f84ebb:	mov    0x630(%rsp),%rdx
 1f84ec3:	call   355e9a0 <strlen+0x10>
 1f84ec8:	mov    %r12,%r11
 1f84ecb:	mov    0x88(%rsp),%rcx
 1f84ed3:	mov    0x70(%rsp),%rsi
 1f84ed8:	test   %eax,%eax
 1f84eda:	mov    0x60(%rsp),%rax
 1f84edf:	jne    1f84b02 <node_facts_window_run+0x7732>
 1f84ee5:	mov    0xc8(%rsp),%edx
 1f84eec:	mov    0xd90(%r11),%rsi
 1f84ef3:	mov    0xdb8(%r11),%rdi
 1f84efa:	shl    $0x2,%rdx
 1f84efe:	call   355e9a0 <strlen+0x10>
 1f84f03:	xor    %ebx,%ebx
 1f84f05:	test   %eax,%eax
 1f84f07:	mov    0x70(%rsp),%rsi
 1f84f0c:	mov    0x88(%rsp),%rcx
 1f84f14:	mov    (%rsp),%r11
 1f84f18:	mov    0x60(%rsp),%rax
 1f84f1d:	setne  %bl
 1f84f20:	jmp    1f84b02 <node_facts_window_run+0x7732>
 1f84f25:	mov    0x70(%rsp),%rsi
 1f84f2a:	jmp    1f84988 <node_facts_window_run+0x75b8>
 1f84f2f:	mov    (%rsp),%r11
 1f84f33:	jmp    1f84968 <node_facts_window_run+0x7598>
 1f84f38:	mov    (%rsp),%r11
 1f84f3c:	mov    0x70(%rsp),%rsi
 1f84f41:	jmp    1f84988 <node_facts_window_run+0x75b8>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
