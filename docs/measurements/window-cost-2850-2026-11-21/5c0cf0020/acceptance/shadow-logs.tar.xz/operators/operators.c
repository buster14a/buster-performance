int ga[16], gb[16];
int fn(int);
int c0(int *p, int *q, long n, unsigned u) { return ((p) < (p)); }
int c1(int *p, int *q, long n, unsigned u) { return ((p) > (p)); }
int c2(int *p, int *q, long n, unsigned u) { return ((p) <= (p)); }
int c3(int *p, int *q, long n, unsigned u) { return ((p) >= (p)); }
int c4(int *p, int *q, long n, unsigned u) { return ((p) == (p)); }
int c5(int *p, int *q, long n, unsigned u) { return ((p) != (p)); }
int c6(int *p, int *q, long n, unsigned u) { return ((p) && (p)); }
int c7(int *p, int *q, long n, unsigned u) { return ((p) || (p)); }
int c8(int *p, int *q, long n, unsigned u) { return ((p) < (q)); }
int c9(int *p, int *q, long n, unsigned u) { return ((p) > (q)); }
int c10(int *p, int *q, long n, unsigned u) { return ((p) <= (q)); }
int c11(int *p, int *q, long n, unsigned u) { return ((p) >= (q)); }
int c12(int *p, int *q, long n, unsigned u) { return ((p) == (q)); }
int c13(int *p, int *q, long n, unsigned u) { return ((p) != (q)); }
int c14(int *p, int *q, long n, unsigned u) { return ((p) && (q)); }
int c15(int *p, int *q, long n, unsigned u) { return ((p) || (q)); }
int c16(int *p, int *q, long n, unsigned u) { return ((p) < (ga)); }
int c17(int *p, int *q, long n, unsigned u) { return ((p) > (ga)); }
int c18(int *p, int *q, long n, unsigned u) { return ((p) <= (ga)); }
int c19(int *p, int *q, long n, unsigned u) { return ((p) >= (ga)); }
int c20(int *p, int *q, long n, unsigned u) { return ((p) == (ga)); }
int c21(int *p, int *q, long n, unsigned u) { return ((p) != (ga)); }
int c22(int *p, int *q, long n, unsigned u) { return ((p) && (ga)); }
int c23(int *p, int *q, long n, unsigned u) { return ((p) || (ga)); }
int c24(int *p, int *q, long n, unsigned u) { return ((p) < (gb)); }
int c25(int *p, int *q, long n, unsigned u) { return ((p) > (gb)); }
int c26(int *p, int *q, long n, unsigned u) { return ((p) <= (gb)); }
int c27(int *p, int *q, long n, unsigned u) { return ((p) >= (gb)); }
int c28(int *p, int *q, long n, unsigned u) { return ((p) == (gb)); }
int c29(int *p, int *q, long n, unsigned u) { return ((p) != (gb)); }
int c30(int *p, int *q, long n, unsigned u) { return ((p) && (gb)); }
int c31(int *p, int *q, long n, unsigned u) { return ((p) || (gb)); }
int c32(int *p, int *q, long n, unsigned u) { return ((p) < (ga + n)); }
int c33(int *p, int *q, long n, unsigned u) { return ((p) > (ga + n)); }
int c34(int *p, int *q, long n, unsigned u) { return ((p) <= (ga + n)); }
int c35(int *p, int *q, long n, unsigned u) { return ((p) >= (ga + n)); }
int c36(int *p, int *q, long n, unsigned u) { return ((p) == (ga + n)); }
int c37(int *p, int *q, long n, unsigned u) { return ((p) != (ga + n)); }
int c38(int *p, int *q, long n, unsigned u) { return ((p) && (ga + n)); }
int c39(int *p, int *q, long n, unsigned u) { return ((p) || (ga + n)); }
int c40(int *p, int *q, long n, unsigned u) { return ((p) < ((int*)0)); }
int c41(int *p, int *q, long n, unsigned u) { return ((p) > ((int*)0)); }
int c42(int *p, int *q, long n, unsigned u) { return ((p) <= ((int*)0)); }
int c43(int *p, int *q, long n, unsigned u) { return ((p) >= ((int*)0)); }
int c44(int *p, int *q, long n, unsigned u) { return ((p) == ((int*)0)); }
int c45(int *p, int *q, long n, unsigned u) { return ((p) != ((int*)0)); }
int c46(int *p, int *q, long n, unsigned u) { return ((p) && ((int*)0)); }
int c47(int *p, int *q, long n, unsigned u) { return ((p) || ((int*)0)); }
int c48(int *p, int *q, long n, unsigned u) { return ((p) < ((int*)42)); }
int c49(int *p, int *q, long n, unsigned u) { return ((p) > ((int*)42)); }
int c50(int *p, int *q, long n, unsigned u) { return ((p) <= ((int*)42)); }
int c51(int *p, int *q, long n, unsigned u) { return ((p) >= ((int*)42)); }
int c52(int *p, int *q, long n, unsigned u) { return ((p) == ((int*)42)); }
int c53(int *p, int *q, long n, unsigned u) { return ((p) != ((int*)42)); }
int c54(int *p, int *q, long n, unsigned u) { return ((p) && ((int*)42)); }
int c55(int *p, int *q, long n, unsigned u) { return ((p) || ((int*)42)); }
int c56(int *p, int *q, long n, unsigned u) { return ((p) < (n)); }
int c57(int *p, int *q, long n, unsigned u) { return ((p) > (n)); }
int c58(int *p, int *q, long n, unsigned u) { return ((p) <= (n)); }
int c59(int *p, int *q, long n, unsigned u) { return ((p) >= (n)); }
int c60(int *p, int *q, long n, unsigned u) { return ((p) == (n)); }
int c61(int *p, int *q, long n, unsigned u) { return ((p) != (n)); }
int c62(int *p, int *q, long n, unsigned u) { return ((p) && (n)); }
int c63(int *p, int *q, long n, unsigned u) { return ((p) || (n)); }
int c64(int *p, int *q, long n, unsigned u) { return ((p) < (u)); }
int c65(int *p, int *q, long n, unsigned u) { return ((p) > (u)); }
int c66(int *p, int *q, long n, unsigned u) { return ((p) <= (u)); }
int c67(int *p, int *q, long n, unsigned u) { return ((p) >= (u)); }
int c68(int *p, int *q, long n, unsigned u) { return ((p) == (u)); }
int c69(int *p, int *q, long n, unsigned u) { return ((p) != (u)); }
int c70(int *p, int *q, long n, unsigned u) { return ((p) && (u)); }
int c71(int *p, int *q, long n, unsigned u) { return ((p) || (u)); }
int c72(int *p, int *q, long n, unsigned u) { return ((p) < (0)); }
int c73(int *p, int *q, long n, unsigned u) { return ((p) > (0)); }
int c74(int *p, int *q, long n, unsigned u) { return ((p) <= (0)); }
int c75(int *p, int *q, long n, unsigned u) { return ((p) >= (0)); }
int c76(int *p, int *q, long n, unsigned u) { return ((p) == (0)); }
int c77(int *p, int *q, long n, unsigned u) { return ((p) != (0)); }
int c78(int *p, int *q, long n, unsigned u) { return ((p) && (0)); }
int c79(int *p, int *q, long n, unsigned u) { return ((p) || (0)); }
int c80(int *p, int *q, long n, unsigned u) { return ((p) < (42)); }
int c81(int *p, int *q, long n, unsigned u) { return ((p) > (42)); }
int c82(int *p, int *q, long n, unsigned u) { return ((p) <= (42)); }
int c83(int *p, int *q, long n, unsigned u) { return ((p) >= (42)); }
int c84(int *p, int *q, long n, unsigned u) { return ((p) == (42)); }
int c85(int *p, int *q, long n, unsigned u) { return ((p) != (42)); }
int c86(int *p, int *q, long n, unsigned u) { return ((p) && (42)); }
int c87(int *p, int *q, long n, unsigned u) { return ((p) || (42)); }
int c88(int *p, int *q, long n, unsigned u) { return ((q) < (p)); }
int c89(int *p, int *q, long n, unsigned u) { return ((q) > (p)); }
int c90(int *p, int *q, long n, unsigned u) { return ((q) <= (p)); }
int c91(int *p, int *q, long n, unsigned u) { return ((q) >= (p)); }
int c92(int *p, int *q, long n, unsigned u) { return ((q) == (p)); }
int c93(int *p, int *q, long n, unsigned u) { return ((q) != (p)); }
int c94(int *p, int *q, long n, unsigned u) { return ((q) && (p)); }
int c95(int *p, int *q, long n, unsigned u) { return ((q) || (p)); }
int c96(int *p, int *q, long n, unsigned u) { return ((q) < (q)); }
int c97(int *p, int *q, long n, unsigned u) { return ((q) > (q)); }
int c98(int *p, int *q, long n, unsigned u) { return ((q) <= (q)); }
int c99(int *p, int *q, long n, unsigned u) { return ((q) >= (q)); }
int c100(int *p, int *q, long n, unsigned u) { return ((q) == (q)); }
int c101(int *p, int *q, long n, unsigned u) { return ((q) != (q)); }
int c102(int *p, int *q, long n, unsigned u) { return ((q) && (q)); }
int c103(int *p, int *q, long n, unsigned u) { return ((q) || (q)); }
int c104(int *p, int *q, long n, unsigned u) { return ((q) < (ga)); }
int c105(int *p, int *q, long n, unsigned u) { return ((q) > (ga)); }
int c106(int *p, int *q, long n, unsigned u) { return ((q) <= (ga)); }
int c107(int *p, int *q, long n, unsigned u) { return ((q) >= (ga)); }
int c108(int *p, int *q, long n, unsigned u) { return ((q) == (ga)); }
int c109(int *p, int *q, long n, unsigned u) { return ((q) != (ga)); }
int c110(int *p, int *q, long n, unsigned u) { return ((q) && (ga)); }
int c111(int *p, int *q, long n, unsigned u) { return ((q) || (ga)); }
int c112(int *p, int *q, long n, unsigned u) { return ((q) < (gb)); }
int c113(int *p, int *q, long n, unsigned u) { return ((q) > (gb)); }
int c114(int *p, int *q, long n, unsigned u) { return ((q) <= (gb)); }
int c115(int *p, int *q, long n, unsigned u) { return ((q) >= (gb)); }
int c116(int *p, int *q, long n, unsigned u) { return ((q) == (gb)); }
int c117(int *p, int *q, long n, unsigned u) { return ((q) != (gb)); }
int c118(int *p, int *q, long n, unsigned u) { return ((q) && (gb)); }
int c119(int *p, int *q, long n, unsigned u) { return ((q) || (gb)); }
int c120(int *p, int *q, long n, unsigned u) { return ((q) < (ga + n)); }
int c121(int *p, int *q, long n, unsigned u) { return ((q) > (ga + n)); }
int c122(int *p, int *q, long n, unsigned u) { return ((q) <= (ga + n)); }
int c123(int *p, int *q, long n, unsigned u) { return ((q) >= (ga + n)); }
int c124(int *p, int *q, long n, unsigned u) { return ((q) == (ga + n)); }
int c125(int *p, int *q, long n, unsigned u) { return ((q) != (ga + n)); }
int c126(int *p, int *q, long n, unsigned u) { return ((q) && (ga + n)); }
int c127(int *p, int *q, long n, unsigned u) { return ((q) || (ga + n)); }
int c128(int *p, int *q, long n, unsigned u) { return ((q) < ((int*)0)); }
int c129(int *p, int *q, long n, unsigned u) { return ((q) > ((int*)0)); }
int c130(int *p, int *q, long n, unsigned u) { return ((q) <= ((int*)0)); }
int c131(int *p, int *q, long n, unsigned u) { return ((q) >= ((int*)0)); }
int c132(int *p, int *q, long n, unsigned u) { return ((q) == ((int*)0)); }
int c133(int *p, int *q, long n, unsigned u) { return ((q) != ((int*)0)); }
int c134(int *p, int *q, long n, unsigned u) { return ((q) && ((int*)0)); }
int c135(int *p, int *q, long n, unsigned u) { return ((q) || ((int*)0)); }
int c136(int *p, int *q, long n, unsigned u) { return ((q) < ((int*)42)); }
int c137(int *p, int *q, long n, unsigned u) { return ((q) > ((int*)42)); }
int c138(int *p, int *q, long n, unsigned u) { return ((q) <= ((int*)42)); }
int c139(int *p, int *q, long n, unsigned u) { return ((q) >= ((int*)42)); }
int c140(int *p, int *q, long n, unsigned u) { return ((q) == ((int*)42)); }
int c141(int *p, int *q, long n, unsigned u) { return ((q) != ((int*)42)); }
int c142(int *p, int *q, long n, unsigned u) { return ((q) && ((int*)42)); }
int c143(int *p, int *q, long n, unsigned u) { return ((q) || ((int*)42)); }
int c144(int *p, int *q, long n, unsigned u) { return ((q) < (n)); }
int c145(int *p, int *q, long n, unsigned u) { return ((q) > (n)); }
int c146(int *p, int *q, long n, unsigned u) { return ((q) <= (n)); }
int c147(int *p, int *q, long n, unsigned u) { return ((q) >= (n)); }
int c148(int *p, int *q, long n, unsigned u) { return ((q) == (n)); }
int c149(int *p, int *q, long n, unsigned u) { return ((q) != (n)); }
int c150(int *p, int *q, long n, unsigned u) { return ((q) && (n)); }
int c151(int *p, int *q, long n, unsigned u) { return ((q) || (n)); }
int c152(int *p, int *q, long n, unsigned u) { return ((q) < (u)); }
int c153(int *p, int *q, long n, unsigned u) { return ((q) > (u)); }
int c154(int *p, int *q, long n, unsigned u) { return ((q) <= (u)); }
int c155(int *p, int *q, long n, unsigned u) { return ((q) >= (u)); }
int c156(int *p, int *q, long n, unsigned u) { return ((q) == (u)); }
int c157(int *p, int *q, long n, unsigned u) { return ((q) != (u)); }
int c158(int *p, int *q, long n, unsigned u) { return ((q) && (u)); }
int c159(int *p, int *q, long n, unsigned u) { return ((q) || (u)); }
int c160(int *p, int *q, long n, unsigned u) { return ((q) < (0)); }
int c161(int *p, int *q, long n, unsigned u) { return ((q) > (0)); }
int c162(int *p, int *q, long n, unsigned u) { return ((q) <= (0)); }
int c163(int *p, int *q, long n, unsigned u) { return ((q) >= (0)); }
int c164(int *p, int *q, long n, unsigned u) { return ((q) == (0)); }
int c165(int *p, int *q, long n, unsigned u) { return ((q) != (0)); }
int c166(int *p, int *q, long n, unsigned u) { return ((q) && (0)); }
int c167(int *p, int *q, long n, unsigned u) { return ((q) || (0)); }
int c168(int *p, int *q, long n, unsigned u) { return ((q) < (42)); }
int c169(int *p, int *q, long n, unsigned u) { return ((q) > (42)); }
int c170(int *p, int *q, long n, unsigned u) { return ((q) <= (42)); }
int c171(int *p, int *q, long n, unsigned u) { return ((q) >= (42)); }
int c172(int *p, int *q, long n, unsigned u) { return ((q) == (42)); }
int c173(int *p, int *q, long n, unsigned u) { return ((q) != (42)); }
int c174(int *p, int *q, long n, unsigned u) { return ((q) && (42)); }
int c175(int *p, int *q, long n, unsigned u) { return ((q) || (42)); }
int c176(int *p, int *q, long n, unsigned u) { return ((ga) < (p)); }
int c177(int *p, int *q, long n, unsigned u) { return ((ga) > (p)); }
int c178(int *p, int *q, long n, unsigned u) { return ((ga) <= (p)); }
int c179(int *p, int *q, long n, unsigned u) { return ((ga) >= (p)); }
int c180(int *p, int *q, long n, unsigned u) { return ((ga) == (p)); }
int c181(int *p, int *q, long n, unsigned u) { return ((ga) != (p)); }
int c182(int *p, int *q, long n, unsigned u) { return ((ga) && (p)); }
int c183(int *p, int *q, long n, unsigned u) { return ((ga) || (p)); }
int c184(int *p, int *q, long n, unsigned u) { return ((ga) < (q)); }
int c185(int *p, int *q, long n, unsigned u) { return ((ga) > (q)); }
int c186(int *p, int *q, long n, unsigned u) { return ((ga) <= (q)); }
int c187(int *p, int *q, long n, unsigned u) { return ((ga) >= (q)); }
int c188(int *p, int *q, long n, unsigned u) { return ((ga) == (q)); }
int c189(int *p, int *q, long n, unsigned u) { return ((ga) != (q)); }
int c190(int *p, int *q, long n, unsigned u) { return ((ga) && (q)); }
int c191(int *p, int *q, long n, unsigned u) { return ((ga) || (q)); }
int c192(int *p, int *q, long n, unsigned u) { return ((ga) < (ga)); }
int c193(int *p, int *q, long n, unsigned u) { return ((ga) > (ga)); }
int c194(int *p, int *q, long n, unsigned u) { return ((ga) <= (ga)); }
int c195(int *p, int *q, long n, unsigned u) { return ((ga) >= (ga)); }
int c196(int *p, int *q, long n, unsigned u) { return ((ga) == (ga)); }
int c197(int *p, int *q, long n, unsigned u) { return ((ga) != (ga)); }
int c198(int *p, int *q, long n, unsigned u) { return ((ga) && (ga)); }
int c199(int *p, int *q, long n, unsigned u) { return ((ga) || (ga)); }
int c200(int *p, int *q, long n, unsigned u) { return ((ga) < (gb)); }
int c201(int *p, int *q, long n, unsigned u) { return ((ga) > (gb)); }
int c202(int *p, int *q, long n, unsigned u) { return ((ga) <= (gb)); }
int c203(int *p, int *q, long n, unsigned u) { return ((ga) >= (gb)); }
int c204(int *p, int *q, long n, unsigned u) { return ((ga) == (gb)); }
int c205(int *p, int *q, long n, unsigned u) { return ((ga) != (gb)); }
int c206(int *p, int *q, long n, unsigned u) { return ((ga) && (gb)); }
int c207(int *p, int *q, long n, unsigned u) { return ((ga) || (gb)); }
int c208(int *p, int *q, long n, unsigned u) { return ((ga) < (ga + n)); }
int c209(int *p, int *q, long n, unsigned u) { return ((ga) > (ga + n)); }
int c210(int *p, int *q, long n, unsigned u) { return ((ga) <= (ga + n)); }
int c211(int *p, int *q, long n, unsigned u) { return ((ga) >= (ga + n)); }
int c212(int *p, int *q, long n, unsigned u) { return ((ga) == (ga + n)); }
int c213(int *p, int *q, long n, unsigned u) { return ((ga) != (ga + n)); }
int c214(int *p, int *q, long n, unsigned u) { return ((ga) && (ga + n)); }
int c215(int *p, int *q, long n, unsigned u) { return ((ga) || (ga + n)); }
int c216(int *p, int *q, long n, unsigned u) { return ((ga) < ((int*)0)); }
int c217(int *p, int *q, long n, unsigned u) { return ((ga) > ((int*)0)); }
int c218(int *p, int *q, long n, unsigned u) { return ((ga) <= ((int*)0)); }
int c219(int *p, int *q, long n, unsigned u) { return ((ga) >= ((int*)0)); }
int c220(int *p, int *q, long n, unsigned u) { return ((ga) == ((int*)0)); }
int c221(int *p, int *q, long n, unsigned u) { return ((ga) != ((int*)0)); }
int c222(int *p, int *q, long n, unsigned u) { return ((ga) && ((int*)0)); }
int c223(int *p, int *q, long n, unsigned u) { return ((ga) || ((int*)0)); }
int c224(int *p, int *q, long n, unsigned u) { return ((ga) < ((int*)42)); }
int c225(int *p, int *q, long n, unsigned u) { return ((ga) > ((int*)42)); }
int c226(int *p, int *q, long n, unsigned u) { return ((ga) <= ((int*)42)); }
int c227(int *p, int *q, long n, unsigned u) { return ((ga) >= ((int*)42)); }
int c228(int *p, int *q, long n, unsigned u) { return ((ga) == ((int*)42)); }
int c229(int *p, int *q, long n, unsigned u) { return ((ga) != ((int*)42)); }
int c230(int *p, int *q, long n, unsigned u) { return ((ga) && ((int*)42)); }
int c231(int *p, int *q, long n, unsigned u) { return ((ga) || ((int*)42)); }
int c232(int *p, int *q, long n, unsigned u) { return ((ga) < (n)); }
int c233(int *p, int *q, long n, unsigned u) { return ((ga) > (n)); }
int c234(int *p, int *q, long n, unsigned u) { return ((ga) <= (n)); }
int c235(int *p, int *q, long n, unsigned u) { return ((ga) >= (n)); }
int c236(int *p, int *q, long n, unsigned u) { return ((ga) == (n)); }
int c237(int *p, int *q, long n, unsigned u) { return ((ga) != (n)); }
int c238(int *p, int *q, long n, unsigned u) { return ((ga) && (n)); }
int c239(int *p, int *q, long n, unsigned u) { return ((ga) || (n)); }
int c240(int *p, int *q, long n, unsigned u) { return ((ga) < (u)); }
int c241(int *p, int *q, long n, unsigned u) { return ((ga) > (u)); }
int c242(int *p, int *q, long n, unsigned u) { return ((ga) <= (u)); }
int c243(int *p, int *q, long n, unsigned u) { return ((ga) >= (u)); }
int c244(int *p, int *q, long n, unsigned u) { return ((ga) == (u)); }
int c245(int *p, int *q, long n, unsigned u) { return ((ga) != (u)); }
int c246(int *p, int *q, long n, unsigned u) { return ((ga) && (u)); }
int c247(int *p, int *q, long n, unsigned u) { return ((ga) || (u)); }
int c248(int *p, int *q, long n, unsigned u) { return ((ga) < (0)); }
int c249(int *p, int *q, long n, unsigned u) { return ((ga) > (0)); }
int c250(int *p, int *q, long n, unsigned u) { return ((ga) <= (0)); }
int c251(int *p, int *q, long n, unsigned u) { return ((ga) >= (0)); }
int c252(int *p, int *q, long n, unsigned u) { return ((ga) == (0)); }
int c253(int *p, int *q, long n, unsigned u) { return ((ga) != (0)); }
int c254(int *p, int *q, long n, unsigned u) { return ((ga) && (0)); }
int c255(int *p, int *q, long n, unsigned u) { return ((ga) || (0)); }
int c256(int *p, int *q, long n, unsigned u) { return ((ga) < (42)); }
int c257(int *p, int *q, long n, unsigned u) { return ((ga) > (42)); }
int c258(int *p, int *q, long n, unsigned u) { return ((ga) <= (42)); }
int c259(int *p, int *q, long n, unsigned u) { return ((ga) >= (42)); }
int c260(int *p, int *q, long n, unsigned u) { return ((ga) == (42)); }
int c261(int *p, int *q, long n, unsigned u) { return ((ga) != (42)); }
int c262(int *p, int *q, long n, unsigned u) { return ((ga) && (42)); }
int c263(int *p, int *q, long n, unsigned u) { return ((ga) || (42)); }
int c264(int *p, int *q, long n, unsigned u) { return ((gb) < (p)); }
int c265(int *p, int *q, long n, unsigned u) { return ((gb) > (p)); }
int c266(int *p, int *q, long n, unsigned u) { return ((gb) <= (p)); }
int c267(int *p, int *q, long n, unsigned u) { return ((gb) >= (p)); }
int c268(int *p, int *q, long n, unsigned u) { return ((gb) == (p)); }
int c269(int *p, int *q, long n, unsigned u) { return ((gb) != (p)); }
int c270(int *p, int *q, long n, unsigned u) { return ((gb) && (p)); }
int c271(int *p, int *q, long n, unsigned u) { return ((gb) || (p)); }
int c272(int *p, int *q, long n, unsigned u) { return ((gb) < (q)); }
int c273(int *p, int *q, long n, unsigned u) { return ((gb) > (q)); }
int c274(int *p, int *q, long n, unsigned u) { return ((gb) <= (q)); }
int c275(int *p, int *q, long n, unsigned u) { return ((gb) >= (q)); }
int c276(int *p, int *q, long n, unsigned u) { return ((gb) == (q)); }
int c277(int *p, int *q, long n, unsigned u) { return ((gb) != (q)); }
int c278(int *p, int *q, long n, unsigned u) { return ((gb) && (q)); }
int c279(int *p, int *q, long n, unsigned u) { return ((gb) || (q)); }
int c280(int *p, int *q, long n, unsigned u) { return ((gb) < (ga)); }
int c281(int *p, int *q, long n, unsigned u) { return ((gb) > (ga)); }
int c282(int *p, int *q, long n, unsigned u) { return ((gb) <= (ga)); }
int c283(int *p, int *q, long n, unsigned u) { return ((gb) >= (ga)); }
int c284(int *p, int *q, long n, unsigned u) { return ((gb) == (ga)); }
int c285(int *p, int *q, long n, unsigned u) { return ((gb) != (ga)); }
int c286(int *p, int *q, long n, unsigned u) { return ((gb) && (ga)); }
int c287(int *p, int *q, long n, unsigned u) { return ((gb) || (ga)); }
int c288(int *p, int *q, long n, unsigned u) { return ((gb) < (gb)); }
int c289(int *p, int *q, long n, unsigned u) { return ((gb) > (gb)); }
int c290(int *p, int *q, long n, unsigned u) { return ((gb) <= (gb)); }
int c291(int *p, int *q, long n, unsigned u) { return ((gb) >= (gb)); }
int c292(int *p, int *q, long n, unsigned u) { return ((gb) == (gb)); }
int c293(int *p, int *q, long n, unsigned u) { return ((gb) != (gb)); }
int c294(int *p, int *q, long n, unsigned u) { return ((gb) && (gb)); }
int c295(int *p, int *q, long n, unsigned u) { return ((gb) || (gb)); }
int c296(int *p, int *q, long n, unsigned u) { return ((gb) < (ga + n)); }
int c297(int *p, int *q, long n, unsigned u) { return ((gb) > (ga + n)); }
int c298(int *p, int *q, long n, unsigned u) { return ((gb) <= (ga + n)); }
int c299(int *p, int *q, long n, unsigned u) { return ((gb) >= (ga + n)); }
int c300(int *p, int *q, long n, unsigned u) { return ((gb) == (ga + n)); }
int c301(int *p, int *q, long n, unsigned u) { return ((gb) != (ga + n)); }
int c302(int *p, int *q, long n, unsigned u) { return ((gb) && (ga + n)); }
int c303(int *p, int *q, long n, unsigned u) { return ((gb) || (ga + n)); }
int c304(int *p, int *q, long n, unsigned u) { return ((gb) < ((int*)0)); }
int c305(int *p, int *q, long n, unsigned u) { return ((gb) > ((int*)0)); }
int c306(int *p, int *q, long n, unsigned u) { return ((gb) <= ((int*)0)); }
int c307(int *p, int *q, long n, unsigned u) { return ((gb) >= ((int*)0)); }
int c308(int *p, int *q, long n, unsigned u) { return ((gb) == ((int*)0)); }
int c309(int *p, int *q, long n, unsigned u) { return ((gb) != ((int*)0)); }
int c310(int *p, int *q, long n, unsigned u) { return ((gb) && ((int*)0)); }
int c311(int *p, int *q, long n, unsigned u) { return ((gb) || ((int*)0)); }
int c312(int *p, int *q, long n, unsigned u) { return ((gb) < ((int*)42)); }
int c313(int *p, int *q, long n, unsigned u) { return ((gb) > ((int*)42)); }
int c314(int *p, int *q, long n, unsigned u) { return ((gb) <= ((int*)42)); }
int c315(int *p, int *q, long n, unsigned u) { return ((gb) >= ((int*)42)); }
int c316(int *p, int *q, long n, unsigned u) { return ((gb) == ((int*)42)); }
int c317(int *p, int *q, long n, unsigned u) { return ((gb) != ((int*)42)); }
int c318(int *p, int *q, long n, unsigned u) { return ((gb) && ((int*)42)); }
int c319(int *p, int *q, long n, unsigned u) { return ((gb) || ((int*)42)); }
int c320(int *p, int *q, long n, unsigned u) { return ((gb) < (n)); }
int c321(int *p, int *q, long n, unsigned u) { return ((gb) > (n)); }
int c322(int *p, int *q, long n, unsigned u) { return ((gb) <= (n)); }
int c323(int *p, int *q, long n, unsigned u) { return ((gb) >= (n)); }
int c324(int *p, int *q, long n, unsigned u) { return ((gb) == (n)); }
int c325(int *p, int *q, long n, unsigned u) { return ((gb) != (n)); }
int c326(int *p, int *q, long n, unsigned u) { return ((gb) && (n)); }
int c327(int *p, int *q, long n, unsigned u) { return ((gb) || (n)); }
int c328(int *p, int *q, long n, unsigned u) { return ((gb) < (u)); }
int c329(int *p, int *q, long n, unsigned u) { return ((gb) > (u)); }
int c330(int *p, int *q, long n, unsigned u) { return ((gb) <= (u)); }
int c331(int *p, int *q, long n, unsigned u) { return ((gb) >= (u)); }
int c332(int *p, int *q, long n, unsigned u) { return ((gb) == (u)); }
int c333(int *p, int *q, long n, unsigned u) { return ((gb) != (u)); }
int c334(int *p, int *q, long n, unsigned u) { return ((gb) && (u)); }
int c335(int *p, int *q, long n, unsigned u) { return ((gb) || (u)); }
int c336(int *p, int *q, long n, unsigned u) { return ((gb) < (0)); }
int c337(int *p, int *q, long n, unsigned u) { return ((gb) > (0)); }
int c338(int *p, int *q, long n, unsigned u) { return ((gb) <= (0)); }
int c339(int *p, int *q, long n, unsigned u) { return ((gb) >= (0)); }
int c340(int *p, int *q, long n, unsigned u) { return ((gb) == (0)); }
int c341(int *p, int *q, long n, unsigned u) { return ((gb) != (0)); }
int c342(int *p, int *q, long n, unsigned u) { return ((gb) && (0)); }
int c343(int *p, int *q, long n, unsigned u) { return ((gb) || (0)); }
int c344(int *p, int *q, long n, unsigned u) { return ((gb) < (42)); }
int c345(int *p, int *q, long n, unsigned u) { return ((gb) > (42)); }
int c346(int *p, int *q, long n, unsigned u) { return ((gb) <= (42)); }
int c347(int *p, int *q, long n, unsigned u) { return ((gb) >= (42)); }
int c348(int *p, int *q, long n, unsigned u) { return ((gb) == (42)); }
int c349(int *p, int *q, long n, unsigned u) { return ((gb) != (42)); }
int c350(int *p, int *q, long n, unsigned u) { return ((gb) && (42)); }
int c351(int *p, int *q, long n, unsigned u) { return ((gb) || (42)); }
int c352(int *p, int *q, long n, unsigned u) { return ((ga + n) < (p)); }
int c353(int *p, int *q, long n, unsigned u) { return ((ga + n) > (p)); }
int c354(int *p, int *q, long n, unsigned u) { return ((ga + n) <= (p)); }
int c355(int *p, int *q, long n, unsigned u) { return ((ga + n) >= (p)); }
int c356(int *p, int *q, long n, unsigned u) { return ((ga + n) == (p)); }
int c357(int *p, int *q, long n, unsigned u) { return ((ga + n) != (p)); }
int c358(int *p, int *q, long n, unsigned u) { return ((ga + n) && (p)); }
int c359(int *p, int *q, long n, unsigned u) { return ((ga + n) || (p)); }
int c360(int *p, int *q, long n, unsigned u) { return ((ga + n) < (q)); }
int c361(int *p, int *q, long n, unsigned u) { return ((ga + n) > (q)); }
int c362(int *p, int *q, long n, unsigned u) { return ((ga + n) <= (q)); }
int c363(int *p, int *q, long n, unsigned u) { return ((ga + n) >= (q)); }
int c364(int *p, int *q, long n, unsigned u) { return ((ga + n) == (q)); }
int c365(int *p, int *q, long n, unsigned u) { return ((ga + n) != (q)); }
int c366(int *p, int *q, long n, unsigned u) { return ((ga + n) && (q)); }
int c367(int *p, int *q, long n, unsigned u) { return ((ga + n) || (q)); }
int c368(int *p, int *q, long n, unsigned u) { return ((ga + n) < (ga)); }
int c369(int *p, int *q, long n, unsigned u) { return ((ga + n) > (ga)); }
int c370(int *p, int *q, long n, unsigned u) { return ((ga + n) <= (ga)); }
int c371(int *p, int *q, long n, unsigned u) { return ((ga + n) >= (ga)); }
int c372(int *p, int *q, long n, unsigned u) { return ((ga + n) == (ga)); }
int c373(int *p, int *q, long n, unsigned u) { return ((ga + n) != (ga)); }
int c374(int *p, int *q, long n, unsigned u) { return ((ga + n) && (ga)); }
int c375(int *p, int *q, long n, unsigned u) { return ((ga + n) || (ga)); }
int c376(int *p, int *q, long n, unsigned u) { return ((ga + n) < (gb)); }
int c377(int *p, int *q, long n, unsigned u) { return ((ga + n) > (gb)); }
int c378(int *p, int *q, long n, unsigned u) { return ((ga + n) <= (gb)); }
int c379(int *p, int *q, long n, unsigned u) { return ((ga + n) >= (gb)); }
int c380(int *p, int *q, long n, unsigned u) { return ((ga + n) == (gb)); }
int c381(int *p, int *q, long n, unsigned u) { return ((ga + n) != (gb)); }
int c382(int *p, int *q, long n, unsigned u) { return ((ga + n) && (gb)); }
int c383(int *p, int *q, long n, unsigned u) { return ((ga + n) || (gb)); }
int c384(int *p, int *q, long n, unsigned u) { return ((ga + n) < (ga + n)); }
int c385(int *p, int *q, long n, unsigned u) { return ((ga + n) > (ga + n)); }
int c386(int *p, int *q, long n, unsigned u) { return ((ga + n) <= (ga + n)); }
int c387(int *p, int *q, long n, unsigned u) { return ((ga + n) >= (ga + n)); }
int c388(int *p, int *q, long n, unsigned u) { return ((ga + n) == (ga + n)); }
int c389(int *p, int *q, long n, unsigned u) { return ((ga + n) != (ga + n)); }
int c390(int *p, int *q, long n, unsigned u) { return ((ga + n) && (ga + n)); }
int c391(int *p, int *q, long n, unsigned u) { return ((ga + n) || (ga + n)); }
int c392(int *p, int *q, long n, unsigned u) { return ((ga + n) < ((int*)0)); }
int c393(int *p, int *q, long n, unsigned u) { return ((ga + n) > ((int*)0)); }
int c394(int *p, int *q, long n, unsigned u) { return ((ga + n) <= ((int*)0)); }
int c395(int *p, int *q, long n, unsigned u) { return ((ga + n) >= ((int*)0)); }
int c396(int *p, int *q, long n, unsigned u) { return ((ga + n) == ((int*)0)); }
int c397(int *p, int *q, long n, unsigned u) { return ((ga + n) != ((int*)0)); }
int c398(int *p, int *q, long n, unsigned u) { return ((ga + n) && ((int*)0)); }
int c399(int *p, int *q, long n, unsigned u) { return ((ga + n) || ((int*)0)); }
int c400(int *p, int *q, long n, unsigned u) { return ((ga + n) < ((int*)42)); }
int c401(int *p, int *q, long n, unsigned u) { return ((ga + n) > ((int*)42)); }
int c402(int *p, int *q, long n, unsigned u) { return ((ga + n) <= ((int*)42)); }
int c403(int *p, int *q, long n, unsigned u) { return ((ga + n) >= ((int*)42)); }
int c404(int *p, int *q, long n, unsigned u) { return ((ga + n) == ((int*)42)); }
int c405(int *p, int *q, long n, unsigned u) { return ((ga + n) != ((int*)42)); }
int c406(int *p, int *q, long n, unsigned u) { return ((ga + n) && ((int*)42)); }
int c407(int *p, int *q, long n, unsigned u) { return ((ga + n) || ((int*)42)); }
int c408(int *p, int *q, long n, unsigned u) { return ((ga + n) < (n)); }
int c409(int *p, int *q, long n, unsigned u) { return ((ga + n) > (n)); }
int c410(int *p, int *q, long n, unsigned u) { return ((ga + n) <= (n)); }
int c411(int *p, int *q, long n, unsigned u) { return ((ga + n) >= (n)); }
int c412(int *p, int *q, long n, unsigned u) { return ((ga + n) == (n)); }
int c413(int *p, int *q, long n, unsigned u) { return ((ga + n) != (n)); }
int c414(int *p, int *q, long n, unsigned u) { return ((ga + n) && (n)); }
int c415(int *p, int *q, long n, unsigned u) { return ((ga + n) || (n)); }
int c416(int *p, int *q, long n, unsigned u) { return ((ga + n) < (u)); }
int c417(int *p, int *q, long n, unsigned u) { return ((ga + n) > (u)); }
int c418(int *p, int *q, long n, unsigned u) { return ((ga + n) <= (u)); }
int c419(int *p, int *q, long n, unsigned u) { return ((ga + n) >= (u)); }
int c420(int *p, int *q, long n, unsigned u) { return ((ga + n) == (u)); }
int c421(int *p, int *q, long n, unsigned u) { return ((ga + n) != (u)); }
int c422(int *p, int *q, long n, unsigned u) { return ((ga + n) && (u)); }
int c423(int *p, int *q, long n, unsigned u) { return ((ga + n) || (u)); }
int c424(int *p, int *q, long n, unsigned u) { return ((ga + n) < (0)); }
int c425(int *p, int *q, long n, unsigned u) { return ((ga + n) > (0)); }
int c426(int *p, int *q, long n, unsigned u) { return ((ga + n) <= (0)); }
int c427(int *p, int *q, long n, unsigned u) { return ((ga + n) >= (0)); }
int c428(int *p, int *q, long n, unsigned u) { return ((ga + n) == (0)); }
int c429(int *p, int *q, long n, unsigned u) { return ((ga + n) != (0)); }
int c430(int *p, int *q, long n, unsigned u) { return ((ga + n) && (0)); }
int c431(int *p, int *q, long n, unsigned u) { return ((ga + n) || (0)); }
int c432(int *p, int *q, long n, unsigned u) { return ((ga + n) < (42)); }
int c433(int *p, int *q, long n, unsigned u) { return ((ga + n) > (42)); }
int c434(int *p, int *q, long n, unsigned u) { return ((ga + n) <= (42)); }
int c435(int *p, int *q, long n, unsigned u) { return ((ga + n) >= (42)); }
int c436(int *p, int *q, long n, unsigned u) { return ((ga + n) == (42)); }
int c437(int *p, int *q, long n, unsigned u) { return ((ga + n) != (42)); }
int c438(int *p, int *q, long n, unsigned u) { return ((ga + n) && (42)); }
int c439(int *p, int *q, long n, unsigned u) { return ((ga + n) || (42)); }
int c440(int *p, int *q, long n, unsigned u) { return (((int*)0) < (p)); }
int c441(int *p, int *q, long n, unsigned u) { return (((int*)0) > (p)); }
int c442(int *p, int *q, long n, unsigned u) { return (((int*)0) <= (p)); }
int c443(int *p, int *q, long n, unsigned u) { return (((int*)0) >= (p)); }
int c444(int *p, int *q, long n, unsigned u) { return (((int*)0) == (p)); }
int c445(int *p, int *q, long n, unsigned u) { return (((int*)0) != (p)); }
int c446(int *p, int *q, long n, unsigned u) { return (((int*)0) && (p)); }
int c447(int *p, int *q, long n, unsigned u) { return (((int*)0) || (p)); }
int c448(int *p, int *q, long n, unsigned u) { return (((int*)0) < (q)); }
int c449(int *p, int *q, long n, unsigned u) { return (((int*)0) > (q)); }
int c450(int *p, int *q, long n, unsigned u) { return (((int*)0) <= (q)); }
int c451(int *p, int *q, long n, unsigned u) { return (((int*)0) >= (q)); }
int c452(int *p, int *q, long n, unsigned u) { return (((int*)0) == (q)); }
int c453(int *p, int *q, long n, unsigned u) { return (((int*)0) != (q)); }
int c454(int *p, int *q, long n, unsigned u) { return (((int*)0) && (q)); }
int c455(int *p, int *q, long n, unsigned u) { return (((int*)0) || (q)); }
int c456(int *p, int *q, long n, unsigned u) { return (((int*)0) < (ga)); }
int c457(int *p, int *q, long n, unsigned u) { return (((int*)0) > (ga)); }
int c458(int *p, int *q, long n, unsigned u) { return (((int*)0) <= (ga)); }
int c459(int *p, int *q, long n, unsigned u) { return (((int*)0) >= (ga)); }
int c460(int *p, int *q, long n, unsigned u) { return (((int*)0) == (ga)); }
int c461(int *p, int *q, long n, unsigned u) { return (((int*)0) != (ga)); }
int c462(int *p, int *q, long n, unsigned u) { return (((int*)0) && (ga)); }
int c463(int *p, int *q, long n, unsigned u) { return (((int*)0) || (ga)); }
int c464(int *p, int *q, long n, unsigned u) { return (((int*)0) < (gb)); }
int c465(int *p, int *q, long n, unsigned u) { return (((int*)0) > (gb)); }
int c466(int *p, int *q, long n, unsigned u) { return (((int*)0) <= (gb)); }
int c467(int *p, int *q, long n, unsigned u) { return (((int*)0) >= (gb)); }
int c468(int *p, int *q, long n, unsigned u) { return (((int*)0) == (gb)); }
int c469(int *p, int *q, long n, unsigned u) { return (((int*)0) != (gb)); }
int c470(int *p, int *q, long n, unsigned u) { return (((int*)0) && (gb)); }
int c471(int *p, int *q, long n, unsigned u) { return (((int*)0) || (gb)); }
int c472(int *p, int *q, long n, unsigned u) { return (((int*)0) < (ga + n)); }
int c473(int *p, int *q, long n, unsigned u) { return (((int*)0) > (ga + n)); }
int c474(int *p, int *q, long n, unsigned u) { return (((int*)0) <= (ga + n)); }
int c475(int *p, int *q, long n, unsigned u) { return (((int*)0) >= (ga + n)); }
int c476(int *p, int *q, long n, unsigned u) { return (((int*)0) == (ga + n)); }
int c477(int *p, int *q, long n, unsigned u) { return (((int*)0) != (ga + n)); }
int c478(int *p, int *q, long n, unsigned u) { return (((int*)0) && (ga + n)); }
int c479(int *p, int *q, long n, unsigned u) { return (((int*)0) || (ga + n)); }
int c480(int *p, int *q, long n, unsigned u) { return (((int*)0) < ((int*)0)); }
int c481(int *p, int *q, long n, unsigned u) { return (((int*)0) > ((int*)0)); }
int c482(int *p, int *q, long n, unsigned u) { return (((int*)0) <= ((int*)0)); }
int c483(int *p, int *q, long n, unsigned u) { return (((int*)0) >= ((int*)0)); }
int c484(int *p, int *q, long n, unsigned u) { return (((int*)0) == ((int*)0)); }
int c485(int *p, int *q, long n, unsigned u) { return (((int*)0) != ((int*)0)); }
int c486(int *p, int *q, long n, unsigned u) { return (((int*)0) && ((int*)0)); }
int c487(int *p, int *q, long n, unsigned u) { return (((int*)0) || ((int*)0)); }
int c488(int *p, int *q, long n, unsigned u) { return (((int*)0) < ((int*)42)); }
int c489(int *p, int *q, long n, unsigned u) { return (((int*)0) > ((int*)42)); }
int c490(int *p, int *q, long n, unsigned u) { return (((int*)0) <= ((int*)42)); }
int c491(int *p, int *q, long n, unsigned u) { return (((int*)0) >= ((int*)42)); }
int c492(int *p, int *q, long n, unsigned u) { return (((int*)0) == ((int*)42)); }
int c493(int *p, int *q, long n, unsigned u) { return (((int*)0) != ((int*)42)); }
int c494(int *p, int *q, long n, unsigned u) { return (((int*)0) && ((int*)42)); }
int c495(int *p, int *q, long n, unsigned u) { return (((int*)0) || ((int*)42)); }
int c496(int *p, int *q, long n, unsigned u) { return (((int*)0) < (n)); }
int c497(int *p, int *q, long n, unsigned u) { return (((int*)0) > (n)); }
int c498(int *p, int *q, long n, unsigned u) { return (((int*)0) <= (n)); }
int c499(int *p, int *q, long n, unsigned u) { return (((int*)0) >= (n)); }
int c500(int *p, int *q, long n, unsigned u) { return (((int*)0) == (n)); }
int c501(int *p, int *q, long n, unsigned u) { return (((int*)0) != (n)); }
int c502(int *p, int *q, long n, unsigned u) { return (((int*)0) && (n)); }
int c503(int *p, int *q, long n, unsigned u) { return (((int*)0) || (n)); }
int c504(int *p, int *q, long n, unsigned u) { return (((int*)0) < (u)); }
int c505(int *p, int *q, long n, unsigned u) { return (((int*)0) > (u)); }
int c506(int *p, int *q, long n, unsigned u) { return (((int*)0) <= (u)); }
int c507(int *p, int *q, long n, unsigned u) { return (((int*)0) >= (u)); }
int c508(int *p, int *q, long n, unsigned u) { return (((int*)0) == (u)); }
int c509(int *p, int *q, long n, unsigned u) { return (((int*)0) != (u)); }
int c510(int *p, int *q, long n, unsigned u) { return (((int*)0) && (u)); }
int c511(int *p, int *q, long n, unsigned u) { return (((int*)0) || (u)); }
int c512(int *p, int *q, long n, unsigned u) { return (((int*)0) < (0)); }
int c513(int *p, int *q, long n, unsigned u) { return (((int*)0) > (0)); }
int c514(int *p, int *q, long n, unsigned u) { return (((int*)0) <= (0)); }
int c515(int *p, int *q, long n, unsigned u) { return (((int*)0) >= (0)); }
int c516(int *p, int *q, long n, unsigned u) { return (((int*)0) == (0)); }
int c517(int *p, int *q, long n, unsigned u) { return (((int*)0) != (0)); }
int c518(int *p, int *q, long n, unsigned u) { return (((int*)0) && (0)); }
int c519(int *p, int *q, long n, unsigned u) { return (((int*)0) || (0)); }
int c520(int *p, int *q, long n, unsigned u) { return (((int*)0) < (42)); }
int c521(int *p, int *q, long n, unsigned u) { return (((int*)0) > (42)); }
int c522(int *p, int *q, long n, unsigned u) { return (((int*)0) <= (42)); }
int c523(int *p, int *q, long n, unsigned u) { return (((int*)0) >= (42)); }
int c524(int *p, int *q, long n, unsigned u) { return (((int*)0) == (42)); }
int c525(int *p, int *q, long n, unsigned u) { return (((int*)0) != (42)); }
int c526(int *p, int *q, long n, unsigned u) { return (((int*)0) && (42)); }
int c527(int *p, int *q, long n, unsigned u) { return (((int*)0) || (42)); }
int c528(int *p, int *q, long n, unsigned u) { return (((int*)42) < (p)); }
int c529(int *p, int *q, long n, unsigned u) { return (((int*)42) > (p)); }
int c530(int *p, int *q, long n, unsigned u) { return (((int*)42) <= (p)); }
int c531(int *p, int *q, long n, unsigned u) { return (((int*)42) >= (p)); }
int c532(int *p, int *q, long n, unsigned u) { return (((int*)42) == (p)); }
int c533(int *p, int *q, long n, unsigned u) { return (((int*)42) != (p)); }
int c534(int *p, int *q, long n, unsigned u) { return (((int*)42) && (p)); }
int c535(int *p, int *q, long n, unsigned u) { return (((int*)42) || (p)); }
int c536(int *p, int *q, long n, unsigned u) { return (((int*)42) < (q)); }
int c537(int *p, int *q, long n, unsigned u) { return (((int*)42) > (q)); }
int c538(int *p, int *q, long n, unsigned u) { return (((int*)42) <= (q)); }
int c539(int *p, int *q, long n, unsigned u) { return (((int*)42) >= (q)); }
int c540(int *p, int *q, long n, unsigned u) { return (((int*)42) == (q)); }
int c541(int *p, int *q, long n, unsigned u) { return (((int*)42) != (q)); }
int c542(int *p, int *q, long n, unsigned u) { return (((int*)42) && (q)); }
int c543(int *p, int *q, long n, unsigned u) { return (((int*)42) || (q)); }
int c544(int *p, int *q, long n, unsigned u) { return (((int*)42) < (ga)); }
int c545(int *p, int *q, long n, unsigned u) { return (((int*)42) > (ga)); }
int c546(int *p, int *q, long n, unsigned u) { return (((int*)42) <= (ga)); }
int c547(int *p, int *q, long n, unsigned u) { return (((int*)42) >= (ga)); }
int c548(int *p, int *q, long n, unsigned u) { return (((int*)42) == (ga)); }
int c549(int *p, int *q, long n, unsigned u) { return (((int*)42) != (ga)); }
int c550(int *p, int *q, long n, unsigned u) { return (((int*)42) && (ga)); }
int c551(int *p, int *q, long n, unsigned u) { return (((int*)42) || (ga)); }
int c552(int *p, int *q, long n, unsigned u) { return (((int*)42) < (gb)); }
int c553(int *p, int *q, long n, unsigned u) { return (((int*)42) > (gb)); }
int c554(int *p, int *q, long n, unsigned u) { return (((int*)42) <= (gb)); }
int c555(int *p, int *q, long n, unsigned u) { return (((int*)42) >= (gb)); }
int c556(int *p, int *q, long n, unsigned u) { return (((int*)42) == (gb)); }
int c557(int *p, int *q, long n, unsigned u) { return (((int*)42) != (gb)); }
int c558(int *p, int *q, long n, unsigned u) { return (((int*)42) && (gb)); }
int c559(int *p, int *q, long n, unsigned u) { return (((int*)42) || (gb)); }
int c560(int *p, int *q, long n, unsigned u) { return (((int*)42) < (ga + n)); }
int c561(int *p, int *q, long n, unsigned u) { return (((int*)42) > (ga + n)); }
int c562(int *p, int *q, long n, unsigned u) { return (((int*)42) <= (ga + n)); }
int c563(int *p, int *q, long n, unsigned u) { return (((int*)42) >= (ga + n)); }
int c564(int *p, int *q, long n, unsigned u) { return (((int*)42) == (ga + n)); }
int c565(int *p, int *q, long n, unsigned u) { return (((int*)42) != (ga + n)); }
int c566(int *p, int *q, long n, unsigned u) { return (((int*)42) && (ga + n)); }
int c567(int *p, int *q, long n, unsigned u) { return (((int*)42) || (ga + n)); }
int c568(int *p, int *q, long n, unsigned u) { return (((int*)42) < ((int*)0)); }
int c569(int *p, int *q, long n, unsigned u) { return (((int*)42) > ((int*)0)); }
int c570(int *p, int *q, long n, unsigned u) { return (((int*)42) <= ((int*)0)); }
int c571(int *p, int *q, long n, unsigned u) { return (((int*)42) >= ((int*)0)); }
int c572(int *p, int *q, long n, unsigned u) { return (((int*)42) == ((int*)0)); }
int c573(int *p, int *q, long n, unsigned u) { return (((int*)42) != ((int*)0)); }
int c574(int *p, int *q, long n, unsigned u) { return (((int*)42) && ((int*)0)); }
int c575(int *p, int *q, long n, unsigned u) { return (((int*)42) || ((int*)0)); }
int c576(int *p, int *q, long n, unsigned u) { return (((int*)42) < ((int*)42)); }
int c577(int *p, int *q, long n, unsigned u) { return (((int*)42) > ((int*)42)); }
int c578(int *p, int *q, long n, unsigned u) { return (((int*)42) <= ((int*)42)); }
int c579(int *p, int *q, long n, unsigned u) { return (((int*)42) >= ((int*)42)); }
int c580(int *p, int *q, long n, unsigned u) { return (((int*)42) == ((int*)42)); }
int c581(int *p, int *q, long n, unsigned u) { return (((int*)42) != ((int*)42)); }
int c582(int *p, int *q, long n, unsigned u) { return (((int*)42) && ((int*)42)); }
int c583(int *p, int *q, long n, unsigned u) { return (((int*)42) || ((int*)42)); }
int c584(int *p, int *q, long n, unsigned u) { return (((int*)42) < (n)); }
int c585(int *p, int *q, long n, unsigned u) { return (((int*)42) > (n)); }
int c586(int *p, int *q, long n, unsigned u) { return (((int*)42) <= (n)); }
int c587(int *p, int *q, long n, unsigned u) { return (((int*)42) >= (n)); }
int c588(int *p, int *q, long n, unsigned u) { return (((int*)42) == (n)); }
int c589(int *p, int *q, long n, unsigned u) { return (((int*)42) != (n)); }
int c590(int *p, int *q, long n, unsigned u) { return (((int*)42) && (n)); }
int c591(int *p, int *q, long n, unsigned u) { return (((int*)42) || (n)); }
int c592(int *p, int *q, long n, unsigned u) { return (((int*)42) < (u)); }
int c593(int *p, int *q, long n, unsigned u) { return (((int*)42) > (u)); }
int c594(int *p, int *q, long n, unsigned u) { return (((int*)42) <= (u)); }
int c595(int *p, int *q, long n, unsigned u) { return (((int*)42) >= (u)); }
int c596(int *p, int *q, long n, unsigned u) { return (((int*)42) == (u)); }
int c597(int *p, int *q, long n, unsigned u) { return (((int*)42) != (u)); }
int c598(int *p, int *q, long n, unsigned u) { return (((int*)42) && (u)); }
int c599(int *p, int *q, long n, unsigned u) { return (((int*)42) || (u)); }
int c600(int *p, int *q, long n, unsigned u) { return (((int*)42) < (0)); }
int c601(int *p, int *q, long n, unsigned u) { return (((int*)42) > (0)); }
int c602(int *p, int *q, long n, unsigned u) { return (((int*)42) <= (0)); }
int c603(int *p, int *q, long n, unsigned u) { return (((int*)42) >= (0)); }
int c604(int *p, int *q, long n, unsigned u) { return (((int*)42) == (0)); }
int c605(int *p, int *q, long n, unsigned u) { return (((int*)42) != (0)); }
int c606(int *p, int *q, long n, unsigned u) { return (((int*)42) && (0)); }
int c607(int *p, int *q, long n, unsigned u) { return (((int*)42) || (0)); }
int c608(int *p, int *q, long n, unsigned u) { return (((int*)42) < (42)); }
int c609(int *p, int *q, long n, unsigned u) { return (((int*)42) > (42)); }
int c610(int *p, int *q, long n, unsigned u) { return (((int*)42) <= (42)); }
int c611(int *p, int *q, long n, unsigned u) { return (((int*)42) >= (42)); }
int c612(int *p, int *q, long n, unsigned u) { return (((int*)42) == (42)); }
int c613(int *p, int *q, long n, unsigned u) { return (((int*)42) != (42)); }
int c614(int *p, int *q, long n, unsigned u) { return (((int*)42) && (42)); }
int c615(int *p, int *q, long n, unsigned u) { return (((int*)42) || (42)); }
int c616(int *p, int *q, long n, unsigned u) { return ((n) < (p)); }
int c617(int *p, int *q, long n, unsigned u) { return ((n) > (p)); }
int c618(int *p, int *q, long n, unsigned u) { return ((n) <= (p)); }
int c619(int *p, int *q, long n, unsigned u) { return ((n) >= (p)); }
int c620(int *p, int *q, long n, unsigned u) { return ((n) == (p)); }
int c621(int *p, int *q, long n, unsigned u) { return ((n) != (p)); }
int c622(int *p, int *q, long n, unsigned u) { return ((n) && (p)); }
int c623(int *p, int *q, long n, unsigned u) { return ((n) || (p)); }
int c624(int *p, int *q, long n, unsigned u) { return ((n) < (q)); }
int c625(int *p, int *q, long n, unsigned u) { return ((n) > (q)); }
int c626(int *p, int *q, long n, unsigned u) { return ((n) <= (q)); }
int c627(int *p, int *q, long n, unsigned u) { return ((n) >= (q)); }
int c628(int *p, int *q, long n, unsigned u) { return ((n) == (q)); }
int c629(int *p, int *q, long n, unsigned u) { return ((n) != (q)); }
int c630(int *p, int *q, long n, unsigned u) { return ((n) && (q)); }
int c631(int *p, int *q, long n, unsigned u) { return ((n) || (q)); }
int c632(int *p, int *q, long n, unsigned u) { return ((n) < (ga)); }
int c633(int *p, int *q, long n, unsigned u) { return ((n) > (ga)); }
int c634(int *p, int *q, long n, unsigned u) { return ((n) <= (ga)); }
int c635(int *p, int *q, long n, unsigned u) { return ((n) >= (ga)); }
int c636(int *p, int *q, long n, unsigned u) { return ((n) == (ga)); }
int c637(int *p, int *q, long n, unsigned u) { return ((n) != (ga)); }
int c638(int *p, int *q, long n, unsigned u) { return ((n) && (ga)); }
int c639(int *p, int *q, long n, unsigned u) { return ((n) || (ga)); }
int c640(int *p, int *q, long n, unsigned u) { return ((n) < (gb)); }
int c641(int *p, int *q, long n, unsigned u) { return ((n) > (gb)); }
int c642(int *p, int *q, long n, unsigned u) { return ((n) <= (gb)); }
int c643(int *p, int *q, long n, unsigned u) { return ((n) >= (gb)); }
int c644(int *p, int *q, long n, unsigned u) { return ((n) == (gb)); }
int c645(int *p, int *q, long n, unsigned u) { return ((n) != (gb)); }
int c646(int *p, int *q, long n, unsigned u) { return ((n) && (gb)); }
int c647(int *p, int *q, long n, unsigned u) { return ((n) || (gb)); }
int c648(int *p, int *q, long n, unsigned u) { return ((n) < (ga + n)); }
int c649(int *p, int *q, long n, unsigned u) { return ((n) > (ga + n)); }
int c650(int *p, int *q, long n, unsigned u) { return ((n) <= (ga + n)); }
int c651(int *p, int *q, long n, unsigned u) { return ((n) >= (ga + n)); }
int c652(int *p, int *q, long n, unsigned u) { return ((n) == (ga + n)); }
int c653(int *p, int *q, long n, unsigned u) { return ((n) != (ga + n)); }
int c654(int *p, int *q, long n, unsigned u) { return ((n) && (ga + n)); }
int c655(int *p, int *q, long n, unsigned u) { return ((n) || (ga + n)); }
int c656(int *p, int *q, long n, unsigned u) { return ((n) < ((int*)0)); }
int c657(int *p, int *q, long n, unsigned u) { return ((n) > ((int*)0)); }
int c658(int *p, int *q, long n, unsigned u) { return ((n) <= ((int*)0)); }
int c659(int *p, int *q, long n, unsigned u) { return ((n) >= ((int*)0)); }
int c660(int *p, int *q, long n, unsigned u) { return ((n) == ((int*)0)); }
int c661(int *p, int *q, long n, unsigned u) { return ((n) != ((int*)0)); }
int c662(int *p, int *q, long n, unsigned u) { return ((n) && ((int*)0)); }
int c663(int *p, int *q, long n, unsigned u) { return ((n) || ((int*)0)); }
int c664(int *p, int *q, long n, unsigned u) { return ((n) < ((int*)42)); }
int c665(int *p, int *q, long n, unsigned u) { return ((n) > ((int*)42)); }
int c666(int *p, int *q, long n, unsigned u) { return ((n) <= ((int*)42)); }
int c667(int *p, int *q, long n, unsigned u) { return ((n) >= ((int*)42)); }
int c668(int *p, int *q, long n, unsigned u) { return ((n) == ((int*)42)); }
int c669(int *p, int *q, long n, unsigned u) { return ((n) != ((int*)42)); }
int c670(int *p, int *q, long n, unsigned u) { return ((n) && ((int*)42)); }
int c671(int *p, int *q, long n, unsigned u) { return ((n) || ((int*)42)); }
int c672(int *p, int *q, long n, unsigned u) { return ((n) < (n)); }
int c673(int *p, int *q, long n, unsigned u) { return ((n) > (n)); }
int c674(int *p, int *q, long n, unsigned u) { return ((n) <= (n)); }
int c675(int *p, int *q, long n, unsigned u) { return ((n) >= (n)); }
int c676(int *p, int *q, long n, unsigned u) { return ((n) == (n)); }
int c677(int *p, int *q, long n, unsigned u) { return ((n) != (n)); }
int c678(int *p, int *q, long n, unsigned u) { return ((n) && (n)); }
int c679(int *p, int *q, long n, unsigned u) { return ((n) || (n)); }
int c680(int *p, int *q, long n, unsigned u) { return ((n) < (u)); }
int c681(int *p, int *q, long n, unsigned u) { return ((n) > (u)); }
int c682(int *p, int *q, long n, unsigned u) { return ((n) <= (u)); }
int c683(int *p, int *q, long n, unsigned u) { return ((n) >= (u)); }
int c684(int *p, int *q, long n, unsigned u) { return ((n) == (u)); }
int c685(int *p, int *q, long n, unsigned u) { return ((n) != (u)); }
int c686(int *p, int *q, long n, unsigned u) { return ((n) && (u)); }
int c687(int *p, int *q, long n, unsigned u) { return ((n) || (u)); }
int c688(int *p, int *q, long n, unsigned u) { return ((n) < (0)); }
int c689(int *p, int *q, long n, unsigned u) { return ((n) > (0)); }
int c690(int *p, int *q, long n, unsigned u) { return ((n) <= (0)); }
int c691(int *p, int *q, long n, unsigned u) { return ((n) >= (0)); }
int c692(int *p, int *q, long n, unsigned u) { return ((n) == (0)); }
int c693(int *p, int *q, long n, unsigned u) { return ((n) != (0)); }
int c694(int *p, int *q, long n, unsigned u) { return ((n) && (0)); }
int c695(int *p, int *q, long n, unsigned u) { return ((n) || (0)); }
int c696(int *p, int *q, long n, unsigned u) { return ((n) < (42)); }
int c697(int *p, int *q, long n, unsigned u) { return ((n) > (42)); }
int c698(int *p, int *q, long n, unsigned u) { return ((n) <= (42)); }
int c699(int *p, int *q, long n, unsigned u) { return ((n) >= (42)); }
int c700(int *p, int *q, long n, unsigned u) { return ((n) == (42)); }
int c701(int *p, int *q, long n, unsigned u) { return ((n) != (42)); }
int c702(int *p, int *q, long n, unsigned u) { return ((n) && (42)); }
int c703(int *p, int *q, long n, unsigned u) { return ((n) || (42)); }
int c704(int *p, int *q, long n, unsigned u) { return ((u) < (p)); }
int c705(int *p, int *q, long n, unsigned u) { return ((u) > (p)); }
int c706(int *p, int *q, long n, unsigned u) { return ((u) <= (p)); }
int c707(int *p, int *q, long n, unsigned u) { return ((u) >= (p)); }
int c708(int *p, int *q, long n, unsigned u) { return ((u) == (p)); }
int c709(int *p, int *q, long n, unsigned u) { return ((u) != (p)); }
int c710(int *p, int *q, long n, unsigned u) { return ((u) && (p)); }
int c711(int *p, int *q, long n, unsigned u) { return ((u) || (p)); }
int c712(int *p, int *q, long n, unsigned u) { return ((u) < (q)); }
int c713(int *p, int *q, long n, unsigned u) { return ((u) > (q)); }
int c714(int *p, int *q, long n, unsigned u) { return ((u) <= (q)); }
int c715(int *p, int *q, long n, unsigned u) { return ((u) >= (q)); }
int c716(int *p, int *q, long n, unsigned u) { return ((u) == (q)); }
int c717(int *p, int *q, long n, unsigned u) { return ((u) != (q)); }
int c718(int *p, int *q, long n, unsigned u) { return ((u) && (q)); }
int c719(int *p, int *q, long n, unsigned u) { return ((u) || (q)); }
int c720(int *p, int *q, long n, unsigned u) { return ((u) < (ga)); }
int c721(int *p, int *q, long n, unsigned u) { return ((u) > (ga)); }
int c722(int *p, int *q, long n, unsigned u) { return ((u) <= (ga)); }
int c723(int *p, int *q, long n, unsigned u) { return ((u) >= (ga)); }
int c724(int *p, int *q, long n, unsigned u) { return ((u) == (ga)); }
int c725(int *p, int *q, long n, unsigned u) { return ((u) != (ga)); }
int c726(int *p, int *q, long n, unsigned u) { return ((u) && (ga)); }
int c727(int *p, int *q, long n, unsigned u) { return ((u) || (ga)); }
int c728(int *p, int *q, long n, unsigned u) { return ((u) < (gb)); }
int c729(int *p, int *q, long n, unsigned u) { return ((u) > (gb)); }
int c730(int *p, int *q, long n, unsigned u) { return ((u) <= (gb)); }
int c731(int *p, int *q, long n, unsigned u) { return ((u) >= (gb)); }
int c732(int *p, int *q, long n, unsigned u) { return ((u) == (gb)); }
int c733(int *p, int *q, long n, unsigned u) { return ((u) != (gb)); }
int c734(int *p, int *q, long n, unsigned u) { return ((u) && (gb)); }
int c735(int *p, int *q, long n, unsigned u) { return ((u) || (gb)); }
int c736(int *p, int *q, long n, unsigned u) { return ((u) < (ga + n)); }
int c737(int *p, int *q, long n, unsigned u) { return ((u) > (ga + n)); }
int c738(int *p, int *q, long n, unsigned u) { return ((u) <= (ga + n)); }
int c739(int *p, int *q, long n, unsigned u) { return ((u) >= (ga + n)); }
int c740(int *p, int *q, long n, unsigned u) { return ((u) == (ga + n)); }
int c741(int *p, int *q, long n, unsigned u) { return ((u) != (ga + n)); }
int c742(int *p, int *q, long n, unsigned u) { return ((u) && (ga + n)); }
int c743(int *p, int *q, long n, unsigned u) { return ((u) || (ga + n)); }
int c744(int *p, int *q, long n, unsigned u) { return ((u) < ((int*)0)); }
int c745(int *p, int *q, long n, unsigned u) { return ((u) > ((int*)0)); }
int c746(int *p, int *q, long n, unsigned u) { return ((u) <= ((int*)0)); }
int c747(int *p, int *q, long n, unsigned u) { return ((u) >= ((int*)0)); }
int c748(int *p, int *q, long n, unsigned u) { return ((u) == ((int*)0)); }
int c749(int *p, int *q, long n, unsigned u) { return ((u) != ((int*)0)); }
int c750(int *p, int *q, long n, unsigned u) { return ((u) && ((int*)0)); }
int c751(int *p, int *q, long n, unsigned u) { return ((u) || ((int*)0)); }
int c752(int *p, int *q, long n, unsigned u) { return ((u) < ((int*)42)); }
int c753(int *p, int *q, long n, unsigned u) { return ((u) > ((int*)42)); }
int c754(int *p, int *q, long n, unsigned u) { return ((u) <= ((int*)42)); }
int c755(int *p, int *q, long n, unsigned u) { return ((u) >= ((int*)42)); }
int c756(int *p, int *q, long n, unsigned u) { return ((u) == ((int*)42)); }
int c757(int *p, int *q, long n, unsigned u) { return ((u) != ((int*)42)); }
int c758(int *p, int *q, long n, unsigned u) { return ((u) && ((int*)42)); }
int c759(int *p, int *q, long n, unsigned u) { return ((u) || ((int*)42)); }
int c760(int *p, int *q, long n, unsigned u) { return ((u) < (n)); }
int c761(int *p, int *q, long n, unsigned u) { return ((u) > (n)); }
int c762(int *p, int *q, long n, unsigned u) { return ((u) <= (n)); }
int c763(int *p, int *q, long n, unsigned u) { return ((u) >= (n)); }
int c764(int *p, int *q, long n, unsigned u) { return ((u) == (n)); }
int c765(int *p, int *q, long n, unsigned u) { return ((u) != (n)); }
int c766(int *p, int *q, long n, unsigned u) { return ((u) && (n)); }
int c767(int *p, int *q, long n, unsigned u) { return ((u) || (n)); }
int c768(int *p, int *q, long n, unsigned u) { return ((u) < (u)); }
int c769(int *p, int *q, long n, unsigned u) { return ((u) > (u)); }
int c770(int *p, int *q, long n, unsigned u) { return ((u) <= (u)); }
int c771(int *p, int *q, long n, unsigned u) { return ((u) >= (u)); }
int c772(int *p, int *q, long n, unsigned u) { return ((u) == (u)); }
int c773(int *p, int *q, long n, unsigned u) { return ((u) != (u)); }
int c774(int *p, int *q, long n, unsigned u) { return ((u) && (u)); }
int c775(int *p, int *q, long n, unsigned u) { return ((u) || (u)); }
int c776(int *p, int *q, long n, unsigned u) { return ((u) < (0)); }
int c777(int *p, int *q, long n, unsigned u) { return ((u) > (0)); }
int c778(int *p, int *q, long n, unsigned u) { return ((u) <= (0)); }
int c779(int *p, int *q, long n, unsigned u) { return ((u) >= (0)); }
int c780(int *p, int *q, long n, unsigned u) { return ((u) == (0)); }
int c781(int *p, int *q, long n, unsigned u) { return ((u) != (0)); }
int c782(int *p, int *q, long n, unsigned u) { return ((u) && (0)); }
int c783(int *p, int *q, long n, unsigned u) { return ((u) || (0)); }
int c784(int *p, int *q, long n, unsigned u) { return ((u) < (42)); }
int c785(int *p, int *q, long n, unsigned u) { return ((u) > (42)); }
int c786(int *p, int *q, long n, unsigned u) { return ((u) <= (42)); }
int c787(int *p, int *q, long n, unsigned u) { return ((u) >= (42)); }
int c788(int *p, int *q, long n, unsigned u) { return ((u) == (42)); }
int c789(int *p, int *q, long n, unsigned u) { return ((u) != (42)); }
int c790(int *p, int *q, long n, unsigned u) { return ((u) && (42)); }
int c791(int *p, int *q, long n, unsigned u) { return ((u) || (42)); }
int c792(int *p, int *q, long n, unsigned u) { return ((0) < (p)); }
int c793(int *p, int *q, long n, unsigned u) { return ((0) > (p)); }
int c794(int *p, int *q, long n, unsigned u) { return ((0) <= (p)); }
int c795(int *p, int *q, long n, unsigned u) { return ((0) >= (p)); }
int c796(int *p, int *q, long n, unsigned u) { return ((0) == (p)); }
int c797(int *p, int *q, long n, unsigned u) { return ((0) != (p)); }
int c798(int *p, int *q, long n, unsigned u) { return ((0) && (p)); }
int c799(int *p, int *q, long n, unsigned u) { return ((0) || (p)); }
int c800(int *p, int *q, long n, unsigned u) { return ((0) < (q)); }
int c801(int *p, int *q, long n, unsigned u) { return ((0) > (q)); }
int c802(int *p, int *q, long n, unsigned u) { return ((0) <= (q)); }
int c803(int *p, int *q, long n, unsigned u) { return ((0) >= (q)); }
int c804(int *p, int *q, long n, unsigned u) { return ((0) == (q)); }
int c805(int *p, int *q, long n, unsigned u) { return ((0) != (q)); }
int c806(int *p, int *q, long n, unsigned u) { return ((0) && (q)); }
int c807(int *p, int *q, long n, unsigned u) { return ((0) || (q)); }
int c808(int *p, int *q, long n, unsigned u) { return ((0) < (ga)); }
int c809(int *p, int *q, long n, unsigned u) { return ((0) > (ga)); }
int c810(int *p, int *q, long n, unsigned u) { return ((0) <= (ga)); }
int c811(int *p, int *q, long n, unsigned u) { return ((0) >= (ga)); }
int c812(int *p, int *q, long n, unsigned u) { return ((0) == (ga)); }
int c813(int *p, int *q, long n, unsigned u) { return ((0) != (ga)); }
int c814(int *p, int *q, long n, unsigned u) { return ((0) && (ga)); }
int c815(int *p, int *q, long n, unsigned u) { return ((0) || (ga)); }
int c816(int *p, int *q, long n, unsigned u) { return ((0) < (gb)); }
int c817(int *p, int *q, long n, unsigned u) { return ((0) > (gb)); }
int c818(int *p, int *q, long n, unsigned u) { return ((0) <= (gb)); }
int c819(int *p, int *q, long n, unsigned u) { return ((0) >= (gb)); }
int c820(int *p, int *q, long n, unsigned u) { return ((0) == (gb)); }
int c821(int *p, int *q, long n, unsigned u) { return ((0) != (gb)); }
int c822(int *p, int *q, long n, unsigned u) { return ((0) && (gb)); }
int c823(int *p, int *q, long n, unsigned u) { return ((0) || (gb)); }
int c824(int *p, int *q, long n, unsigned u) { return ((0) < (ga + n)); }
int c825(int *p, int *q, long n, unsigned u) { return ((0) > (ga + n)); }
int c826(int *p, int *q, long n, unsigned u) { return ((0) <= (ga + n)); }
int c827(int *p, int *q, long n, unsigned u) { return ((0) >= (ga + n)); }
int c828(int *p, int *q, long n, unsigned u) { return ((0) == (ga + n)); }
int c829(int *p, int *q, long n, unsigned u) { return ((0) != (ga + n)); }
int c830(int *p, int *q, long n, unsigned u) { return ((0) && (ga + n)); }
int c831(int *p, int *q, long n, unsigned u) { return ((0) || (ga + n)); }
int c832(int *p, int *q, long n, unsigned u) { return ((0) < ((int*)0)); }
int c833(int *p, int *q, long n, unsigned u) { return ((0) > ((int*)0)); }
int c834(int *p, int *q, long n, unsigned u) { return ((0) <= ((int*)0)); }
int c835(int *p, int *q, long n, unsigned u) { return ((0) >= ((int*)0)); }
int c836(int *p, int *q, long n, unsigned u) { return ((0) == ((int*)0)); }
int c837(int *p, int *q, long n, unsigned u) { return ((0) != ((int*)0)); }
int c838(int *p, int *q, long n, unsigned u) { return ((0) && ((int*)0)); }
int c839(int *p, int *q, long n, unsigned u) { return ((0) || ((int*)0)); }
int c840(int *p, int *q, long n, unsigned u) { return ((0) < ((int*)42)); }
int c841(int *p, int *q, long n, unsigned u) { return ((0) > ((int*)42)); }
int c842(int *p, int *q, long n, unsigned u) { return ((0) <= ((int*)42)); }
int c843(int *p, int *q, long n, unsigned u) { return ((0) >= ((int*)42)); }
int c844(int *p, int *q, long n, unsigned u) { return ((0) == ((int*)42)); }
int c845(int *p, int *q, long n, unsigned u) { return ((0) != ((int*)42)); }
int c846(int *p, int *q, long n, unsigned u) { return ((0) && ((int*)42)); }
int c847(int *p, int *q, long n, unsigned u) { return ((0) || ((int*)42)); }
int c848(int *p, int *q, long n, unsigned u) { return ((0) < (n)); }
int c849(int *p, int *q, long n, unsigned u) { return ((0) > (n)); }
int c850(int *p, int *q, long n, unsigned u) { return ((0) <= (n)); }
int c851(int *p, int *q, long n, unsigned u) { return ((0) >= (n)); }
int c852(int *p, int *q, long n, unsigned u) { return ((0) == (n)); }
int c853(int *p, int *q, long n, unsigned u) { return ((0) != (n)); }
int c854(int *p, int *q, long n, unsigned u) { return ((0) && (n)); }
int c855(int *p, int *q, long n, unsigned u) { return ((0) || (n)); }
int c856(int *p, int *q, long n, unsigned u) { return ((0) < (u)); }
int c857(int *p, int *q, long n, unsigned u) { return ((0) > (u)); }
int c858(int *p, int *q, long n, unsigned u) { return ((0) <= (u)); }
int c859(int *p, int *q, long n, unsigned u) { return ((0) >= (u)); }
int c860(int *p, int *q, long n, unsigned u) { return ((0) == (u)); }
int c861(int *p, int *q, long n, unsigned u) { return ((0) != (u)); }
int c862(int *p, int *q, long n, unsigned u) { return ((0) && (u)); }
int c863(int *p, int *q, long n, unsigned u) { return ((0) || (u)); }
int c864(int *p, int *q, long n, unsigned u) { return ((0) < (0)); }
int c865(int *p, int *q, long n, unsigned u) { return ((0) > (0)); }
int c866(int *p, int *q, long n, unsigned u) { return ((0) <= (0)); }
int c867(int *p, int *q, long n, unsigned u) { return ((0) >= (0)); }
int c868(int *p, int *q, long n, unsigned u) { return ((0) == (0)); }
int c869(int *p, int *q, long n, unsigned u) { return ((0) != (0)); }
int c870(int *p, int *q, long n, unsigned u) { return ((0) && (0)); }
int c871(int *p, int *q, long n, unsigned u) { return ((0) || (0)); }
int c872(int *p, int *q, long n, unsigned u) { return ((0) < (42)); }
int c873(int *p, int *q, long n, unsigned u) { return ((0) > (42)); }
int c874(int *p, int *q, long n, unsigned u) { return ((0) <= (42)); }
int c875(int *p, int *q, long n, unsigned u) { return ((0) >= (42)); }
int c876(int *p, int *q, long n, unsigned u) { return ((0) == (42)); }
int c877(int *p, int *q, long n, unsigned u) { return ((0) != (42)); }
int c878(int *p, int *q, long n, unsigned u) { return ((0) && (42)); }
int c879(int *p, int *q, long n, unsigned u) { return ((0) || (42)); }
int c880(int *p, int *q, long n, unsigned u) { return ((42) < (p)); }
int c881(int *p, int *q, long n, unsigned u) { return ((42) > (p)); }
int c882(int *p, int *q, long n, unsigned u) { return ((42) <= (p)); }
int c883(int *p, int *q, long n, unsigned u) { return ((42) >= (p)); }
int c884(int *p, int *q, long n, unsigned u) { return ((42) == (p)); }
int c885(int *p, int *q, long n, unsigned u) { return ((42) != (p)); }
int c886(int *p, int *q, long n, unsigned u) { return ((42) && (p)); }
int c887(int *p, int *q, long n, unsigned u) { return ((42) || (p)); }
int c888(int *p, int *q, long n, unsigned u) { return ((42) < (q)); }
int c889(int *p, int *q, long n, unsigned u) { return ((42) > (q)); }
int c890(int *p, int *q, long n, unsigned u) { return ((42) <= (q)); }
int c891(int *p, int *q, long n, unsigned u) { return ((42) >= (q)); }
int c892(int *p, int *q, long n, unsigned u) { return ((42) == (q)); }
int c893(int *p, int *q, long n, unsigned u) { return ((42) != (q)); }
int c894(int *p, int *q, long n, unsigned u) { return ((42) && (q)); }
int c895(int *p, int *q, long n, unsigned u) { return ((42) || (q)); }
int c896(int *p, int *q, long n, unsigned u) { return ((42) < (ga)); }
int c897(int *p, int *q, long n, unsigned u) { return ((42) > (ga)); }
int c898(int *p, int *q, long n, unsigned u) { return ((42) <= (ga)); }
int c899(int *p, int *q, long n, unsigned u) { return ((42) >= (ga)); }
int c900(int *p, int *q, long n, unsigned u) { return ((42) == (ga)); }
int c901(int *p, int *q, long n, unsigned u) { return ((42) != (ga)); }
int c902(int *p, int *q, long n, unsigned u) { return ((42) && (ga)); }
int c903(int *p, int *q, long n, unsigned u) { return ((42) || (ga)); }
int c904(int *p, int *q, long n, unsigned u) { return ((42) < (gb)); }
int c905(int *p, int *q, long n, unsigned u) { return ((42) > (gb)); }
int c906(int *p, int *q, long n, unsigned u) { return ((42) <= (gb)); }
int c907(int *p, int *q, long n, unsigned u) { return ((42) >= (gb)); }
int c908(int *p, int *q, long n, unsigned u) { return ((42) == (gb)); }
int c909(int *p, int *q, long n, unsigned u) { return ((42) != (gb)); }
int c910(int *p, int *q, long n, unsigned u) { return ((42) && (gb)); }
int c911(int *p, int *q, long n, unsigned u) { return ((42) || (gb)); }
int c912(int *p, int *q, long n, unsigned u) { return ((42) < (ga + n)); }
int c913(int *p, int *q, long n, unsigned u) { return ((42) > (ga + n)); }
int c914(int *p, int *q, long n, unsigned u) { return ((42) <= (ga + n)); }
int c915(int *p, int *q, long n, unsigned u) { return ((42) >= (ga + n)); }
int c916(int *p, int *q, long n, unsigned u) { return ((42) == (ga + n)); }
int c917(int *p, int *q, long n, unsigned u) { return ((42) != (ga + n)); }
int c918(int *p, int *q, long n, unsigned u) { return ((42) && (ga + n)); }
int c919(int *p, int *q, long n, unsigned u) { return ((42) || (ga + n)); }
int c920(int *p, int *q, long n, unsigned u) { return ((42) < ((int*)0)); }
int c921(int *p, int *q, long n, unsigned u) { return ((42) > ((int*)0)); }
int c922(int *p, int *q, long n, unsigned u) { return ((42) <= ((int*)0)); }
int c923(int *p, int *q, long n, unsigned u) { return ((42) >= ((int*)0)); }
int c924(int *p, int *q, long n, unsigned u) { return ((42) == ((int*)0)); }
int c925(int *p, int *q, long n, unsigned u) { return ((42) != ((int*)0)); }
int c926(int *p, int *q, long n, unsigned u) { return ((42) && ((int*)0)); }
int c927(int *p, int *q, long n, unsigned u) { return ((42) || ((int*)0)); }
int c928(int *p, int *q, long n, unsigned u) { return ((42) < ((int*)42)); }
int c929(int *p, int *q, long n, unsigned u) { return ((42) > ((int*)42)); }
int c930(int *p, int *q, long n, unsigned u) { return ((42) <= ((int*)42)); }
int c931(int *p, int *q, long n, unsigned u) { return ((42) >= ((int*)42)); }
int c932(int *p, int *q, long n, unsigned u) { return ((42) == ((int*)42)); }
int c933(int *p, int *q, long n, unsigned u) { return ((42) != ((int*)42)); }
int c934(int *p, int *q, long n, unsigned u) { return ((42) && ((int*)42)); }
int c935(int *p, int *q, long n, unsigned u) { return ((42) || ((int*)42)); }
int c936(int *p, int *q, long n, unsigned u) { return ((42) < (n)); }
int c937(int *p, int *q, long n, unsigned u) { return ((42) > (n)); }
int c938(int *p, int *q, long n, unsigned u) { return ((42) <= (n)); }
int c939(int *p, int *q, long n, unsigned u) { return ((42) >= (n)); }
int c940(int *p, int *q, long n, unsigned u) { return ((42) == (n)); }
int c941(int *p, int *q, long n, unsigned u) { return ((42) != (n)); }
int c942(int *p, int *q, long n, unsigned u) { return ((42) && (n)); }
int c943(int *p, int *q, long n, unsigned u) { return ((42) || (n)); }
int c944(int *p, int *q, long n, unsigned u) { return ((42) < (u)); }
int c945(int *p, int *q, long n, unsigned u) { return ((42) > (u)); }
int c946(int *p, int *q, long n, unsigned u) { return ((42) <= (u)); }
int c947(int *p, int *q, long n, unsigned u) { return ((42) >= (u)); }
int c948(int *p, int *q, long n, unsigned u) { return ((42) == (u)); }
int c949(int *p, int *q, long n, unsigned u) { return ((42) != (u)); }
int c950(int *p, int *q, long n, unsigned u) { return ((42) && (u)); }
int c951(int *p, int *q, long n, unsigned u) { return ((42) || (u)); }
int c952(int *p, int *q, long n, unsigned u) { return ((42) < (0)); }
int c953(int *p, int *q, long n, unsigned u) { return ((42) > (0)); }
int c954(int *p, int *q, long n, unsigned u) { return ((42) <= (0)); }
int c955(int *p, int *q, long n, unsigned u) { return ((42) >= (0)); }
int c956(int *p, int *q, long n, unsigned u) { return ((42) == (0)); }
int c957(int *p, int *q, long n, unsigned u) { return ((42) != (0)); }
int c958(int *p, int *q, long n, unsigned u) { return ((42) && (0)); }
int c959(int *p, int *q, long n, unsigned u) { return ((42) || (0)); }
int c960(int *p, int *q, long n, unsigned u) { return ((42) < (42)); }
int c961(int *p, int *q, long n, unsigned u) { return ((42) > (42)); }
int c962(int *p, int *q, long n, unsigned u) { return ((42) <= (42)); }
int c963(int *p, int *q, long n, unsigned u) { return ((42) >= (42)); }
int c964(int *p, int *q, long n, unsigned u) { return ((42) == (42)); }
int c965(int *p, int *q, long n, unsigned u) { return ((42) != (42)); }
int c966(int *p, int *q, long n, unsigned u) { return ((42) && (42)); }
int c967(int *p, int *q, long n, unsigned u) { return ((42) || (42)); }
int add(int *p, int *q) { return (p - q) != 0; }
int typed(int x,int (*p)(int)) { return fn < p || fn == p; }
