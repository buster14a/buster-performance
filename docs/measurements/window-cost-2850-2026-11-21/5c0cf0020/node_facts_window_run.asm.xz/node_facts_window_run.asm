
results/costbit/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f7d3d0 <node_facts_window_run>:
 1f7d3d0:	push   %rbp
 1f7d3d1:	push   %r15
 1f7d3d3:	push   %r14
 1f7d3d5:	push   %r13
 1f7d3d7:	push   %r12
 1f7d3d9:	push   %rbx
 1f7d3da:	sub    $0xcb8,%rsp
 1f7d3e1:	mov    0x940(%rdi),%r14
 1f7d3e8:	mov    0x8(%rsi),%r15d
 1f7d3ec:	mov    %rsi,%rbp
 1f7d3ef:	test   %r15,%r15
 1f7d3f2:	je     1f7d5b6 <node_facts_window_run+0x1e6>
 1f7d3f8:	mov    %r15d,%eax
 1f7d3fb:	and    $0x7,%eax
 1f7d3fe:	cmp    $0x8,%r15d
 1f7d402:	jae    1f7d40b <node_facts_window_run+0x3b>
 1f7d404:	xor    %ecx,%ecx
 1f7d406:	jmp    1f7d9ae <node_facts_window_run+0x5de>
 1f7d40b:	mov    %r15d,%edx
 1f7d40e:	and    $0xfffffff8,%edx
 1f7d411:	xor    %ecx,%ecx
 1f7d413:	jmp    1f7d43b <node_facts_window_run+0x6b>
 1f7d415:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7d420:	xor    %esi,%esi
 1f7d422:	mov    0x9c0(%rdi),%r8
 1f7d429:	mov    %sil,0x7(%r8,%rcx,1)
 1f7d42e:	add    $0x8,%rcx
 1f7d432:	cmp    %rcx,%rdx
 1f7d435:	je     1f7d5ad <node_facts_window_run+0x1dd>
 1f7d43b:	mov    0x9b8(%rdi),%rsi
 1f7d442:	cmpb   $0x0,(%rsi,%rcx,1)
 1f7d446:	je     1f7d460 <node_facts_window_run+0x90>
 1f7d448:	movzbl 0x69454(%rbp,%rcx,1),%esi
 1f7d450:	jmp    1f7d462 <node_facts_window_run+0x92>
 1f7d452:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d460:	xor    %esi,%esi
 1f7d462:	mov    0x9c0(%rdi),%r8
 1f7d469:	mov    %sil,(%r8,%rcx,1)
 1f7d46d:	mov    0x9b8(%rdi),%rsi
 1f7d474:	cmpb   $0x0,0x1(%rsi,%rcx,1)
 1f7d479:	je     1f7d490 <node_facts_window_run+0xc0>
 1f7d47b:	movzbl 0x69455(%rbp,%rcx,1),%esi
 1f7d483:	jmp    1f7d492 <node_facts_window_run+0xc2>
 1f7d485:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7d490:	xor    %esi,%esi
 1f7d492:	mov    0x9c0(%rdi),%r8
 1f7d499:	mov    %sil,0x1(%r8,%rcx,1)
 1f7d49e:	mov    0x9b8(%rdi),%rsi
 1f7d4a5:	cmpb   $0x0,0x2(%rsi,%rcx,1)
 1f7d4aa:	je     1f7d4c0 <node_facts_window_run+0xf0>
 1f7d4ac:	movzbl 0x69456(%rbp,%rcx,1),%esi
 1f7d4b4:	jmp    1f7d4c2 <node_facts_window_run+0xf2>
 1f7d4b6:	cs nopw 0x0(%rax,%rax,1)
 1f7d4c0:	xor    %esi,%esi
 1f7d4c2:	mov    0x9c0(%rdi),%r8
 1f7d4c9:	mov    %sil,0x2(%r8,%rcx,1)
 1f7d4ce:	mov    0x9b8(%rdi),%rsi
 1f7d4d5:	cmpb   $0x0,0x3(%rsi,%rcx,1)
 1f7d4da:	je     1f7d4f0 <node_facts_window_run+0x120>
 1f7d4dc:	movzbl 0x69457(%rbp,%rcx,1),%esi
 1f7d4e4:	jmp    1f7d4f2 <node_facts_window_run+0x122>
 1f7d4e6:	cs nopw 0x0(%rax,%rax,1)
 1f7d4f0:	xor    %esi,%esi
 1f7d4f2:	mov    0x9c0(%rdi),%r8
 1f7d4f9:	mov    %sil,0x3(%r8,%rcx,1)
 1f7d4fe:	mov    0x9b8(%rdi),%rsi
 1f7d505:	cmpb   $0x0,0x4(%rsi,%rcx,1)
 1f7d50a:	je     1f7d520 <node_facts_window_run+0x150>
 1f7d50c:	movzbl 0x69458(%rbp,%rcx,1),%esi
 1f7d514:	jmp    1f7d522 <node_facts_window_run+0x152>
 1f7d516:	cs nopw 0x0(%rax,%rax,1)
 1f7d520:	xor    %esi,%esi
 1f7d522:	mov    0x9c0(%rdi),%r8
 1f7d529:	mov    %sil,0x4(%r8,%rcx,1)
 1f7d52e:	mov    0x9b8(%rdi),%rsi
 1f7d535:	cmpb   $0x0,0x5(%rsi,%rcx,1)
 1f7d53a:	je     1f7d550 <node_facts_window_run+0x180>
 1f7d53c:	movzbl 0x69459(%rbp,%rcx,1),%esi
 1f7d544:	jmp    1f7d552 <node_facts_window_run+0x182>
 1f7d546:	cs nopw 0x0(%rax,%rax,1)
 1f7d550:	xor    %esi,%esi
 1f7d552:	mov    0x9c0(%rdi),%r8
 1f7d559:	mov    %sil,0x5(%r8,%rcx,1)
 1f7d55e:	mov    0x9b8(%rdi),%rsi
 1f7d565:	cmpb   $0x0,0x6(%rsi,%rcx,1)
 1f7d56a:	je     1f7d580 <node_facts_window_run+0x1b0>
 1f7d56c:	movzbl 0x6945a(%rbp,%rcx,1),%esi
 1f7d574:	jmp    1f7d582 <node_facts_window_run+0x1b2>
 1f7d576:	cs nopw 0x0(%rax,%rax,1)
 1f7d580:	xor    %esi,%esi
 1f7d582:	mov    0x9c0(%rdi),%r8
 1f7d589:	mov    %sil,0x6(%r8,%rcx,1)
 1f7d58e:	mov    0x9b8(%rdi),%rsi
 1f7d595:	cmpb   $0x0,0x7(%rsi,%rcx,1)
 1f7d59a:	je     1f7d420 <node_facts_window_run+0x50>
 1f7d5a0:	movzbl 0x6945b(%rbp,%rcx,1),%esi
 1f7d5a8:	jmp    1f7d422 <node_facts_window_run+0x52>
 1f7d5ad:	test   %rax,%rax
 1f7d5b0:	jne    1f7d9ae <node_facts_window_run+0x5de>
 1f7d5b6:	vpbroadcastq %rbp,%ymm0
 1f7d5bc:	vpaddq -0x19bbd24(%rip),%ymm0,%ymm0        # 5c18a0 <.LCPI3_0>
 1f7d5c4:	vmovups 0x1f0(%rdi),%zmm1
 1f7d5ce:	mov    0x9c0(%rdi),%rax
 1f7d5d5:	mov    0x9c8(%rdi),%rdx
 1f7d5dc:	mov    0x69250(%rbp),%r8d
 1f7d5e3:	lea    0x2c(%rbp),%r11
 1f7d5e7:	lea    0x6a4d4(%rbp),%rcx
 1f7d5ee:	lea    0x79854(%rbp),%rsi
 1f7d5f5:	lea    0x73754(%rbp),%r9
 1f7d5fc:	mov    0x230(%rdi),%r10
 1f7d603:	vmovdqu 0x240(%rdi),%xmm3
 1f7d60b:	vmovq  0x258(%rdi),%xmm2
 1f7d613:	mov    %r11,0x1f0(%rdi)
 1f7d61a:	mov    %rax,0x1f8(%rdi)
 1f7d621:	mov    %rcx,0x200(%rdi)
 1f7d628:	mov    %rdx,0x208(%rdi)
 1f7d62f:	mov    $0x1,%edx
 1f7d634:	vmovdqu %ymm0,0x210(%rdi)
 1f7d63c:	mov    %rsi,0x230(%rdi)
 1f7d643:	mov    %r9,0x240(%rdi)
 1f7d64a:	mov    %r8d,0x258(%rdi)
 1f7d651:	vmovups %zmm1,0x860(%rsp)
 1f7d65c:	mov    %r10,0x668(%rsp)
 1f7d664:	vmovdqa %xmm3,0x830(%rsp)
 1f7d66d:	vmovdqa %xmm2,0x820(%rsp)
 1f7d676:	mov    %r11,0xd0(%rsp)
 1f7d67e:	xor    %esi,%esi
 1f7d680:	mov    %rdi,(%rsp)
 1f7d684:	vmovups 0x9d0(%rdi),%zmm0
 1f7d68e:	vmovups 0x268(%rdi),%zmm1
 1f7d698:	vmovups %zmm0,0x268(%rdi)
 1f7d6a2:	vmovups %zmm1,0x9d0(%rdi)
 1f7d6ac:	vmovdqu 0xa10(%rdi),%xmm0
 1f7d6b4:	vmovdqu 0x2a8(%rdi),%xmm1
 1f7d6bc:	vmovdqu %xmm0,0x2a8(%rdi)
 1f7d6c4:	vmovdqu %xmm1,0xa10(%rdi)
 1f7d6cc:	mov    0xa20(%rdi),%rcx
 1f7d6d3:	mov    0x2b8(%rdi),%rax
 1f7d6da:	mov    %rcx,0x2b8(%rdi)
 1f7d6e1:	lea    0xa28(%rdi),%rcx
 1f7d6e8:	mov    %rax,0xa20(%rdi)
 1f7d6ef:	movl   $0x0,0xa28(%rdi)
 1f7d6f9:	mov    %r15d,0xa2c(%rdi)
 1f7d700:	mov    %rcx,0x248(%rdi)
 1f7d707:	movl   $0x0,0x25c(%rdi)
 1f7d711:	vzeroupper
 1f7d714:	call   1f7bb10 <node_facts_given>
 1f7d719:	mov    (%rsp),%rax
 1f7d71d:	mov    (%rsp),%rdi
 1f7d721:	xor    %esi,%esi
 1f7d723:	xor    %edx,%edx
 1f7d725:	xor    %ecx,%ecx
 1f7d727:	mov    0xe0(%rax),%rbx
 1f7d72e:	call   1f7bd00 <node_facts_window>
 1f7d733:	mov    (%rsp),%rax
 1f7d737:	mov    (%rsp),%rdi
 1f7d73b:	xor    %esi,%esi
 1f7d73d:	mov    0xe0(%rax),%rax
 1f7d744:	sub    %rbx,%rax
 1f7d747:	add    %rax,0xa30(%r14)
 1f7d74e:	call   1f7c950 <node_facts_lists_same>
 1f7d753:	mov    (%rsp),%rdi
 1f7d757:	test   %al,%al
 1f7d759:	jne    1f7d7ad <node_facts_window_run+0x3dd>
 1f7d75b:	incq   0xa00(%r14)
 1f7d762:	mov    0x940(%rdi),%rax
 1f7d769:	mov    0x11e0(%rax),%ecx
 1f7d76f:	cmp    $0xf,%rcx
 1f7d773:	ja     1f7d7ad <node_facts_window_run+0x3dd>
 1f7d775:	mov    0x422c(%rbp),%edx
 1f7d77b:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7d782:	mov    0x1f0(%rdi),%rcx
 1f7d789:	mov    0x11e0(%rax),%edx
 1f7d78f:	movzbl (%rcx),%ecx
 1f7d792:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7d799:	mov    0x11e0(%rax),%ecx
 1f7d79f:	movb   $0x2,0x11d0(%rax,%rcx,1)
 1f7d7a7:	incl   0x11e0(%rax)
 1f7d7ad:	mov    %r15,0xd8(%rsp)
 1f7d7b5:	mov    %rbp,0x20(%rsp)
 1f7d7ba:	test   %r15d,%r15d
 1f7d7bd:	je     1f7da75 <node_facts_window_run+0x6a5>
 1f7d7c3:	mov    $0x1a,%r15d
 1f7d7c9:	mov    $0xcc,%ebp
 1f7d7ce:	mov    $0x102,%r12d
 1f7d7d4:	mov    $0x8c,%r13d
 1f7d7da:	xor    %ebx,%ebx
 1f7d7dc:	jmp    1f7d7f5 <node_facts_window_run+0x425>
 1f7d7de:	xchg   %ax,%ax
 1f7d7e0:	inc    %rbx
 1f7d7e3:	add    $0x40,%r15
 1f7d7e7:	cmp    %rbx,0xd8(%rsp)
 1f7d7ef:	je     1f7d9bf <node_facts_window_run+0x5ef>
 1f7d7f5:	mov    0x1f8(%rdi),%rax
 1f7d7fc:	movzbl (%rax,%rbx,1),%eax
 1f7d800:	cmp    $0x7,%eax
 1f7d803:	ja     1f7d7e0 <node_facts_window_run+0x410>
 1f7d805:	bt     %eax,%ebp
 1f7d808:	jae    1f7d7e0 <node_facts_window_run+0x410>
 1f7d80a:	mov    %eax,%ecx
 1f7d80c:	mov    0x2c0(%rdi),%rsi
 1f7d813:	and    $0xfe,%cl
 1f7d816:	cmp    $0x2,%cl
 1f7d819:	sete   %cl
 1f7d81c:	cmp    $0x7,%eax
 1f7d81f:	sete   %dl
 1f7d822:	or     %cl,%dl
 1f7d824:	movzbl -0x1(%rsi,%r15,1),%ecx
 1f7d82a:	movzbl %dl,%edx
 1f7d82d:	add    %rdx,0x9f0(%r14)
 1f7d834:	cmp    $0x7,%eax
 1f7d837:	ja     1f7d972 <node_facts_window_run+0x5a2>
 1f7d83d:	bt     %eax,%r13d
 1f7d841:	mov    $0x0,%edx
 1f7d846:	jae    1f7d854 <node_facts_window_run+0x484>
 1f7d848:	lea    -0x1(%rcx),%esi
 1f7d84b:	xor    %edx,%edx
 1f7d84d:	cmp    $0x2,%sil
 1f7d851:	setb   %dl
 1f7d854:	add    %rdx,0x9f8(%r14)
 1f7d85b:	xor    %edx,%edx
 1f7d85d:	cmp    $0x7,%eax
 1f7d860:	ja     1f7d876 <node_facts_window_run+0x4a6>
 1f7d862:	bt     %eax,%r13d
 1f7d866:	jae    1f7d876 <node_facts_window_run+0x4a6>
 1f7d868:	mov    0x1f0(%rdi),%rax
 1f7d86f:	cmpb   $0x22,(%rax,%rbx,1)
 1f7d873:	sete   %dl
 1f7d876:	dec    %cl
 1f7d878:	vmovd  %edx,%xmm0
 1f7d87c:	cmp    $0x2,%cl
 1f7d87f:	setb   %al
 1f7d882:	and    %dl,%al
 1f7d884:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f7d88a:	vpmovzxbq %xmm0,%xmm0
 1f7d88f:	vptestmq -0x19af301(%rip){1to2},%xmm0,%k0        # 5ce598 <.LCPI3_1>
 1f7d899:	vmovdqu 0xa10(%r14),%xmm0
 1f7d8a2:	vpmovm2q %k0,%xmm1
 1f7d8a8:	vpsubq %xmm1,%xmm0,%xmm0
 1f7d8ac:	vmovdqu %xmm0,0xa10(%r14)
 1f7d8b5:	cmp    $0x1,%al
 1f7d8b7:	jne    1f7d8f0 <node_facts_window_run+0x520>
 1f7d8b9:	mov    0x2c0(%rdi),%rax
 1f7d8c0:	movzwl (%rax,%r15,1),%eax
 1f7d8c5:	bt     $0x1,%eax
 1f7d8c9:	adcq   $0x0,0xa20(%r14)
 1f7d8d1:	mov    0x2c0(%rdi),%rax
 1f7d8d8:	movzwl (%rax,%r15,1),%eax
 1f7d8dd:	bextr  %r12d,%eax,%eax
 1f7d8e2:	jmp    1f7d8f2 <node_facts_window_run+0x522>
 1f7d8e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d8f0:	xor    %eax,%eax
 1f7d8f2:	add    %rax,0xa28(%r14)
 1f7d8f9:	xor    %esi,%esi
 1f7d8fb:	mov    %ebx,%edx
 1f7d8fd:	xor    %ecx,%ecx
 1f7d8ff:	call   1f7cf70 <node_facts_same>
 1f7d904:	mov    (%rsp),%rdi
 1f7d908:	test   %al,%al
 1f7d90a:	jne    1f7d7e0 <node_facts_window_run+0x410>
 1f7d910:	incq   0xa00(%r14)
 1f7d917:	mov    0x940(%rdi),%rax
 1f7d91e:	mov    0x11e0(%rax),%ecx
 1f7d924:	cmp    $0xf,%rcx
 1f7d928:	ja     1f7d7e0 <node_facts_window_run+0x410>
 1f7d92e:	mov    0x20(%rsp),%rdx
 1f7d933:	mov    0x422c(%rdx,%rbx,4),%edx
 1f7d93a:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7d941:	mov    0x1f0(%rdi),%rcx
 1f7d948:	mov    0x11e0(%rax),%edx
 1f7d94e:	movzbl (%rcx,%rbx,1),%ecx
 1f7d952:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7d959:	mov    0x11e0(%rax),%ecx
 1f7d95f:	movb   $0x5,0x11d0(%rax,%rcx,1)
 1f7d967:	incl   0x11e0(%rax)
 1f7d96d:	jmp    1f7d7e0 <node_facts_window_run+0x410>
 1f7d972:	xor    %edx,%edx
 1f7d974:	add    %rdx,0x9f8(%r14)
 1f7d97b:	xor    %edx,%edx
 1f7d97d:	cmp    $0x7,%eax
 1f7d980:	jbe    1f7d862 <node_facts_window_run+0x492>
 1f7d986:	jmp    1f7d876 <node_facts_window_run+0x4a6>
 1f7d98b:	nopl   0x0(%rax,%rax,1)
 1f7d990:	movzbl 0x69454(%rbp,%rcx,1),%edx
 1f7d998:	mov    0x9c0(%rdi),%rsi
 1f7d99f:	mov    %dl,(%rsi,%rcx,1)
 1f7d9a2:	inc    %rcx
 1f7d9a5:	dec    %rax
 1f7d9a8:	je     1f7d5b6 <node_facts_window_run+0x1e6>
 1f7d9ae:	mov    0x9b8(%rdi),%rdx
 1f7d9b5:	cmpb   $0x0,(%rdx,%rcx,1)
 1f7d9b9:	jne    1f7d990 <node_facts_window_run+0x5c0>
 1f7d9bb:	xor    %edx,%edx
 1f7d9bd:	jmp    1f7d998 <node_facts_window_run+0x5c8>
 1f7d9bf:	mov    $0x3,%edx
 1f7d9c4:	xor    %esi,%esi
 1f7d9c6:	xor    %ebx,%ebx
 1f7d9c8:	call   1f7bb10 <node_facts_given>
 1f7d9cd:	mov    (%rsp),%rdi
 1f7d9d1:	xor    %esi,%esi
 1f7d9d3:	xor    %edx,%edx
 1f7d9d5:	xor    %ecx,%ecx
 1f7d9d7:	call   1f7bd00 <node_facts_window>
 1f7d9dc:	mov    (%rsp),%rdi
 1f7d9e0:	mov    0xd8(%rsp),%r15
 1f7d9e8:	mov    0x20(%rsp),%rbp
 1f7d9ed:	jmp    1f7d9fc <node_facts_window_run+0x62c>
 1f7d9ef:	nop
 1f7d9f0:	inc    %rbx
 1f7d9f3:	cmp    %rbx,%r15
 1f7d9f6:	je     1f7da94 <node_facts_window_run+0x6c4>
 1f7d9fc:	mov    0x1f8(%rdi),%rax
 1f7da03:	testb  $0x2,(%rax,%rbx,1)
 1f7da07:	je     1f7d9f0 <node_facts_window_run+0x620>
 1f7da09:	xor    %esi,%esi
 1f7da0b:	mov    %ebx,%edx
 1f7da0d:	xor    %ecx,%ecx
 1f7da0f:	call   1f7cf70 <node_facts_same>
 1f7da14:	mov    (%rsp),%rdi
 1f7da18:	test   %al,%al
 1f7da1a:	jne    1f7d9f0 <node_facts_window_run+0x620>
 1f7da1c:	incq   0xa00(%r14)
 1f7da23:	mov    0x940(%rdi),%rax
 1f7da2a:	mov    0x11e0(%rax),%ecx
 1f7da30:	cmp    $0xf,%rcx
 1f7da34:	ja     1f7d9f0 <node_facts_window_run+0x620>
 1f7da36:	mov    0x422c(%rbp,%rbx,4),%edx
 1f7da3d:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7da44:	mov    0x1f0(%rdi),%rcx
 1f7da4b:	mov    0x11e0(%rax),%edx
 1f7da51:	movzbl (%rcx,%rbx,1),%ecx
 1f7da55:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7da5c:	mov    0x11e0(%rax),%ecx
 1f7da62:	movb   $0x1,0x11d0(%rax,%rcx,1)
 1f7da6a:	incl   0x11e0(%rax)
 1f7da70:	jmp    1f7d9f0 <node_facts_window_run+0x620>
 1f7da75:	mov    $0x3,%edx
 1f7da7a:	xor    %esi,%esi
 1f7da7c:	call   1f7bb10 <node_facts_given>
 1f7da81:	mov    (%rsp),%rdi
 1f7da85:	xor    %esi,%esi
 1f7da87:	xor    %edx,%edx
 1f7da89:	xor    %ecx,%ecx
 1f7da8b:	call   1f7bd00 <node_facts_window>
 1f7da90:	mov    (%rsp),%rdi
 1f7da94:	xor    %esi,%esi
 1f7da96:	xor    %edx,%edx
 1f7da98:	call   1f7bb10 <node_facts_given>
 1f7da9d:	mov    (%rsp),%rax
 1f7daa1:	xor    %esi,%esi
 1f7daa3:	xor    %ecx,%ecx
 1f7daa5:	mov    0xd0(%rax),%r15
 1f7daac:	rdtsc
 1f7daae:	mov    (%rsp),%rdi
 1f7dab2:	mov    %rdx,%rbx
 1f7dab5:	shl    $0x20,%rbx
 1f7dab9:	xor    %edx,%edx
 1f7dabb:	or     %rax,%rbx
 1f7dabe:	call   1f7bd00 <node_facts_window>
 1f7dac3:	mov    (%rsp),%r11
 1f7dac7:	rdtsc
 1f7dac9:	shl    $0x20,%rdx
 1f7dacd:	or     %rax,%rdx
 1f7dad0:	sub    %rbx,%rdx
 1f7dad3:	add    %rdx,0xa08(%r14)
 1f7dada:	mov    0xd0(%r11),%rax
 1f7dae1:	sub    %r15,%rax
 1f7dae4:	mov    0xd8(%rsp),%r15
 1f7daec:	add    %rax,0xa38(%r14)
 1f7daf3:	mov    0x950(%r11),%r13
 1f7dafa:	test   %r13,%r13
 1f7dafd:	je     1f84c3c <node_facts_window_run+0x786c>
 1f7db03:	mov    (%r11),%rax
 1f7db06:	mov    0xb30(%r13),%r9
 1f7db0d:	mov    0xbc8(%r13),%r10
 1f7db14:	lea    0x757d4(%rbp),%r12
 1f7db1b:	mov    %rax,0xc8(%rsp)
 1f7db23:	mov    0x948(%r11),%rax
 1f7db2a:	mov    %rax,0xb8(%rsp)
 1f7db32:	mov    0x8(%rax),%rax
 1f7db36:	mov    0x78(%rax),%eax
 1f7db39:	mov    %eax,0xc0(%rsp)
 1f7db40:	movzbl 0xbf0(%r13),%eax
 1f7db48:	mov    %al,0x90(%rsp)
 1f7db4f:	rdtsc
 1f7db51:	mov    0x8(%rbp),%esi
 1f7db54:	mov    0x2c0(%r11),%rdi
 1f7db5b:	mov    %rax,0x100(%rsp)
 1f7db63:	lea    0x3f(%rsi),%eax
 1f7db66:	mov    %rdx,0xf8(%rsp)
 1f7db6e:	mov    %r9,0x40(%rsp)
 1f7db73:	mov    %r13,0x8(%rsp)
 1f7db78:	mov    %r10,0x30(%rsp)
 1f7db7d:	mov    %r12,0x38(%rsp)
 1f7db82:	mov    %rsi,0x28(%rsp)
 1f7db87:	mov    %rdi,0x18(%rsp)
 1f7db8c:	and    $0xffffffc0,%eax
 1f7db8f:	cmpq   $0x0,0xc20(%r11)
 1f7db97:	je     1f7e840 <node_facts_window_run+0x1470>
 1f7db9d:	cmpb   $0x1,0xd58(%r11)
 1f7dba5:	jne    1f7f284 <node_facts_window_run+0x1eb4>
 1f7dbab:	test   %eax,%eax
 1f7dbad:	je     1f8076d <node_facts_window_run+0x339d>
 1f7dbb3:	vpbroadcastd -0x19acc11(%rip),%zmm14        # 5d0fac <.LCPI3_5>
 1f7dbbd:	vpbroadcastb -0x1ac6e06(%rip),%xmm15        # 4b6dc0 <abi_test_hex.digits+0xba40>
 1f7dbc6:	vpbroadcastb -0x1ac6e0f(%rip),%xmm16        # 4b6dc1 <abi_test_hex.digits+0xba41>
 1f7dbd0:	vpbroadcastd -0x19acc26(%rip),%zmm17        # 5d0fb4 <.LCPI3_11>
 1f7dbda:	vpbroadcastd -0x19acc28(%rip),%zmm18        # 5d0fbc <.LCPI3_13>
 1f7dbe4:	mov    (%r11),%rcx
 1f7dbe7:	lea    0x69454(%rbp),%r8
 1f7dbee:	lea    0x422c(%rbp),%rdx
 1f7dbf5:	mov    %eax,%r15d
 1f7dbf8:	xor    %ebx,%ebx
 1f7dbfa:	mov    %rcx,0x88(%rsp)
 1f7dc02:	mov    %r8,0xb0(%rsp)
 1f7dc0a:	mov    %rdx,0x98(%rsp)
 1f7dc12:	movq   $0x0,0x48(%rsp)
 1f7dc1b:	movq   $0x0,0x110(%rsp)
 1f7dc27:	movq   $0x0,0x10(%rsp)
 1f7dc30:	mov    %r15,0xa8(%rsp)
 1f7dc38:	jmp    1f7dd06 <node_facts_window_run+0x936>
 1f7dc3d:	nopl   (%rax)
 1f7dc40:	vpxor  %xmm1,%xmm1,%xmm1
 1f7dc44:	vpxor  %xmm0,%xmm0,%xmm0
 1f7dc48:	vpxor  %xmm5,%xmm5,%xmm5
 1f7dc4c:	vpxor  %xmm4,%xmm4,%xmm4
 1f7dc50:	vpxor  %xmm3,%xmm3,%xmm3
 1f7dc54:	vpxor  %xmm7,%xmm7,%xmm7
 1f7dc58:	vpxor  %xmm8,%xmm8,%xmm8
 1f7dc5d:	vpxor  %xmm9,%xmm9,%xmm9
 1f7dc62:	vpxor  %xmm2,%xmm2,%xmm2
 1f7dc66:	vpxord %xmm20,%xmm20,%xmm20
 1f7dc6c:	mov    0xb70(%r13),%rax
 1f7dc73:	vmovdqu64 %xmm20,(%rax,%rbx,1)
 1f7dc7a:	mov    0xb78(%r13),%rax
 1f7dc81:	vmovdqu %xmm2,(%rax,%rbx,1)
 1f7dc86:	mov    0xb88(%r11),%rax
 1f7dc8d:	vmovdqu %xmm9,(%rax,%rbx,1)
 1f7dc92:	mov    0xb90(%r11),%rax
 1f7dc99:	vmovdqu %xmm8,(%rax,%rbx,1)
 1f7dc9e:	mov    0xb98(%r11),%rax
 1f7dca5:	vmovdqu %xmm7,(%rax,%rbx,1)
 1f7dcaa:	mov    0xba0(%r11),%rax
 1f7dcb1:	vmovdqu %xmm3,(%rax,%rbx,1)
 1f7dcb6:	mov    0xba8(%r11),%rax
 1f7dcbd:	vmovdqu %xmm4,(%rax,%rbx,1)
 1f7dcc2:	mov    0xc28(%r11),%rax
 1f7dcc9:	vmovdqu64 %zmm5,(%rax,%rbx,4)
 1f7dcd0:	mov    0xcd8(%r11),%rax
 1f7dcd7:	vmovdqu64 %zmm0,(%rax,%rbx,8)
 1f7dcde:	mov    0xcd8(%r11),%rax
 1f7dce5:	vmovdqu64 %zmm1,0x40(%rax,%rbx,8)
 1f7dced:	mov    0xd60(%r11),%rax
 1f7dcf4:	vmovdqu %xmm6,(%rax,%rbx,1)
 1f7dcf9:	add    $0x10,%rbx
 1f7dcfd:	cmp    %r15,%rbx
 1f7dd00:	jae    1f8078b <node_facts_window_run+0x33bb>
 1f7dd06:	vpxor  %xmm6,%xmm6,%xmm6
 1f7dd0a:	cmp    %rsi,%rbx
 1f7dd0d:	jae    1f7dc40 <node_facts_window_run+0x870>
 1f7dd13:	mov    %esi,%eax
 1f7dd15:	sub    %ebx,%eax
 1f7dd17:	mov    $0x10,%ecx
 1f7dd1c:	mov    $0xffffffff,%edx
 1f7dd21:	vpxor  %xmm12,%xmm12,%xmm12
 1f7dd26:	cmp    $0x10,%eax
 1f7dd29:	cmovae %ecx,%eax
 1f7dd2c:	mov    0x9b8(%r11),%rcx
 1f7dd33:	shlx   %eax,%edx,%eax
 1f7dd38:	mov    %rbx,%rdx
 1f7dd3b:	shl    $0x6,%rdx
 1f7dd3f:	not    %eax
 1f7dd41:	vmovdqu (%rdi,%rdx,1),%ymm4
 1f7dd46:	vmovdqu64 0x40(%rdi,%rdx,1),%ymm26
 1f7dd4e:	vmovdqu64 0x80(%rdi,%rdx,1),%ymm27
 1f7dd56:	vmovdqu64 0xc0(%rdi,%rdx,1),%ymm28
 1f7dd5e:	vmovdqu 0x100(%rdi,%rdx,1),%ymm5
 1f7dd67:	vmovdqu 0x140(%rdi,%rdx,1),%ymm6
 1f7dd70:	vmovdqu64 0x180(%rdi,%rdx,1),%ymm24
 1f7dd78:	vmovdqu64 0x1c0(%rdi,%rdx,1),%ymm25
 1f7dd80:	vmovdqu 0x200(%rdi,%rdx,1),%ymm7
 1f7dd89:	vmovdqu 0x240(%rdi,%rdx,1),%ymm13
 1f7dd92:	vmovdqu64 0x280(%rdi,%rdx,1),%ymm22
 1f7dd9a:	vmovdqu64 0x2c0(%rdi,%rdx,1),%ymm23
 1f7dda2:	vmovdqu 0x300(%rdi,%rdx,1),%ymm11
 1f7ddab:	vmovdqu64 0x340(%rdi,%rdx,1),%ymm19
 1f7ddb3:	vmovdqu64 0x380(%rdi,%rdx,1),%ymm20
 1f7ddbb:	vmovdqu64 0x3c0(%rdi,%rdx,1),%ymm21
 1f7ddc3:	kmovd  %eax,%k1
 1f7ddc7:	mov    0xba8(%r13),%rax
 1f7ddce:	vmovdqu8 (%rcx,%rbx,1),%xmm0{%k1}{z}
 1f7ddd5:	mov    0xb0(%rsp),%rcx
 1f7dddd:	vmovdqu8 (%rcx,%rbx,1),%xmm10{%k1}{z}
 1f7dde4:	vptestmb %xmm0,%xmm0,%k6
 1f7ddea:	vpcmpeqb -0x19b6064(%rip),%xmm10,%k7{%k6}        # 5c7d90 <.LCPI3_10>
 1f7ddf4:	vmovdqu32 (%r12,%rbx,4),%zmm0{%k7}{z}
 1f7ddfb:	kmovq  %k7,%k1
 1f7de00:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7de07:	vptestnmd %zmm17,%zmm12,%k0
 1f7de0d:	ktestw %k0,%k7
 1f7de11:	jne    1f7e546 <node_facts_window_run+0x1176>
 1f7de17:	vpmovsxbd -0x19ace30(%rip),%xmm3        # 5d0ff0 <.LCPI3_70>
 1f7de20:	vmovdqa64 -0x1ac76ea(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7de2a:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7de31:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7de38:	vptestmd -0x19ace8a(%rip){1to16},%zmm12,%k0        # 5d0fb8 <.LCPI3_12>
 1f7de42:	vmovdqa64 %zmm0,%zmm2
 1f7de48:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7de4e:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7de54:	vmovdqa64 %zmm3,%zmm9
 1f7de5a:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7de60:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7de66:	kmovd  %k0,%r13d
 1f7de6a:	vptestmd %zmm18,%zmm12,%k0
 1f7de70:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7de76:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7de7d:	vmovdqu64 %zmm1,0x1b0(%rsp)
 1f7de88:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7de8f:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7de93:	vmovdqa64 %zmm1,%zmm4
 1f7de99:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7de9f:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7dea5:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7deab:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7deb1:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7deb8:	vmovdqu %ymm3,0x170(%rsp)
 1f7dec1:	vinserti64x4 $0x1,%ymm13,%zmm7,%zmm3
 1f7dec8:	vpunpcklqdq %ymm13,%ymm7,%ymm7
 1f7decd:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm13
 1f7ded4:	vmovdqa64 %zmm3,%zmm6
 1f7deda:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7dee0:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7dee6:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7deec:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7def2:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7def8:	vmovdqa64 %zmm13,%zmm7
 1f7defe:	vmovdqu64 %zmm5,0x2a0(%rsp)
 1f7df09:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7df10:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7df16:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7df1d:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7df24:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7df2a:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7df31:	vpermt2d %zmm5,%zmm9,%zmm13
 1f7df37:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7df3d:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7df43:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7df4a:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7df51:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7df58:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7df5f:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm21{%k6}{z}
 1f7df66:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7df6d:	vpsrld $0x19,%zmm19,%zmm0
 1f7df74:	vpandd -0x19acfd6(%rip){1to16},%zmm0,%zmm0        # 5d0fa8 <.LCPI3_4>
 1f7df7e:	vpsrld $0x18,%zmm19,%zmm1
 1f7df85:	vpsrld $0x1a,%zmm19,%zmm7
 1f7df8c:	vpternlogd $0xec,%zmm14,%zmm0,%zmm1
 1f7df93:	vpandd -0x19acfa9(%rip){1to16},%zmm19,%zmm0        # 5d0ff4 <.LCPI3_71>
 1f7df9d:	vpmovdb %zmm1,%xmm20
 1f7dfa3:	vpsrld $0xc,%zmm21,%zmm1
 1f7dfaa:	vpmovdb %zmm1,%xmm24
 1f7dfb0:	vpcmpeqd -0x19ad00a(%rip){1to16},%zmm0,%k1{%k6}        # 5d0fb0 <.LCPI3_7>
 1f7dfba:	vporq  %xmm15,%xmm20,%xmm0
 1f7dfc0:	vmovdqu8 %xmm0,%xmm20{%k1}
 1f7dfc6:	vpcmpeqb %xmm15,%xmm10,%k1{%k6}
 1f7dfcc:	vpternlogq $0xf8,%xmm16,%xmm24,%xmm20
 1f7dfd3:	kmovd  %k1,%eax
 1f7dfd7:	kmovw  %k1,0x70(%rsp)
 1f7dfdd:	korw   %k0,%k1,%k1
 1f7dfe1:	kmovw  %k1,0x60(%rsp)
 1f7dfe7:	test   %ax,%ax
 1f7dfea:	je     1f7e19d <node_facts_window_run+0xdcd>
 1f7dff0:	vmovdqu64 %zmm4,0x670(%rsp)
 1f7dffb:	vmovdqu %ymm5,0x540(%rsp)
 1f7e004:	vmovdqu64 %zmm7,0x580(%rsp)
 1f7e00c:	vmovdqa64 %xmm24,0x4c0(%rsp)
 1f7e014:	vmovdqu64 %zmm23,0x5c0(%rsp)
 1f7e01c:	vmovdqu64 %zmm22,0x600(%rsp)
 1f7e024:	vmovdqu64 %zmm19,0x440(%rsp)
 1f7e02c:	vmovdqu64 %zmm13,0x2e0(%rsp)
 1f7e037:	vmovdqu64 %zmm21,0x3e0(%rsp)
 1f7e042:	vmovdqu64 %zmm12,0x480(%rsp)
 1f7e04a:	vmovdqa64 %xmm20,0x320(%rsp)
 1f7e052:	kmovw  %k7,0x360(%rsp)
 1f7e05b:	mov    %rdx,0x1f0(%rsp)
 1f7e063:	kmovd  %k6,0x3a0(%rsp)
 1f7e06d:	movzwl %ax,%r14d
 1f7e071:	movzwl %r13w,%r13d
 1f7e075:	mov    0x98(%rsp),%rax
 1f7e07d:	mov    %rbx,0x260(%rsp)
 1f7e085:	mov    0x8(%rsp),%rbp
 1f7e08a:	lea    (%rax,%rbx,4),%r15
 1f7e08e:	xor    %ebx,%ebx
 1f7e090:	xor    %r12d,%r12d
 1f7e093:	tzcnt  %r14d,%r12d
 1f7e098:	mov    %rbp,%rdi
 1f7e09b:	xor    %edx,%edx
 1f7e09d:	mov    (%r15,%r12,4),%esi
 1f7e0a1:	vzeroupper
 1f7e0a4:	call   1f93850 <node_tests_window_line>
 1f7e0a9:	mov    $0x1,%ecx
 1f7e0ae:	test   $0x2,%al
 1f7e0b0:	shlx   %r12d,%ecx,%eax
 1f7e0b5:	cmove  %ebx,%eax
 1f7e0b8:	or     %eax,%r13d
 1f7e0bb:	blsr   %r14d,%r14d
 1f7e0c0:	jne    1f7e090 <node_facts_window_run+0xcc0>
 1f7e0c2:	vpbroadcastd -0x19ad120(%rip),%zmm14        # 5d0fac <.LCPI3_5>
 1f7e0cc:	vpbroadcastb -0x1ac7315(%rip),%xmm15        # 4b6dc0 <abi_test_hex.digits+0xba40>
 1f7e0d5:	vpbroadcastb -0x1ac731e(%rip),%xmm16        # 4b6dc1 <abi_test_hex.digits+0xba41>
 1f7e0df:	vpbroadcastd -0x19ad135(%rip),%zmm17        # 5d0fb4 <.LCPI3_11>
 1f7e0e9:	vpbroadcastd -0x19ad137(%rip),%zmm18        # 5d0fbc <.LCPI3_13>
 1f7e0f3:	vmovdqa64 0x320(%rsp),%xmm20
 1f7e0fb:	vmovdqu64 0x480(%rsp),%zmm12
 1f7e103:	vmovdqu64 0x3e0(%rsp),%zmm21
 1f7e10e:	vmovdqu64 0x2e0(%rsp),%zmm13
 1f7e119:	vmovdqu64 0x440(%rsp),%zmm19
 1f7e121:	vmovdqu64 0x600(%rsp),%zmm22
 1f7e129:	vmovdqu64 0x5c0(%rsp),%zmm23
 1f7e131:	vmovdqa64 0x4c0(%rsp),%xmm24
 1f7e139:	vmovdqu64 0x580(%rsp),%zmm7
 1f7e141:	vmovdqu 0x540(%rsp),%ymm5
 1f7e14a:	vmovdqu64 0x670(%rsp),%zmm4
 1f7e155:	mov    (%rsp),%r11
 1f7e159:	mov    0x40(%rsp),%r9
 1f7e15e:	mov    0x30(%rsp),%r10
 1f7e163:	mov    0x38(%rsp),%r12
 1f7e168:	mov    0x28(%rsp),%rsi
 1f7e16d:	mov    0x18(%rsp),%rdi
 1f7e172:	mov    0xa8(%rsp),%r15
 1f7e17a:	mov    0x260(%rsp),%rbx
 1f7e182:	kmovd  0x3a0(%rsp),%k6
 1f7e18c:	mov    0x1f0(%rsp),%rdx
 1f7e194:	kmovw  0x360(%rsp),%k7
 1f7e19d:	vpsrld $0x2,%zmm21,%zmm0
 1f7e1a4:	vpandd -0x19ad1ee(%rip){1to16},%zmm0,%zmm2        # 5d0fc0 <.LCPI3_14>
 1f7e1ae:	vpbroadcastd -0x19ad1f4(%rip),%zmm0        # 5d0fc4 <.LCPI3_15>
 1f7e1b8:	vptestmd -0x19ad1fa(%rip){1to16},%zmm21,%k3        # 5d0fc8 <.LCPI3_16>
 1f7e1c2:	vmovdqu64 0x2a0(%rsp),%zmm1
 1f7e1cd:	vptestnmd %zmm4,%zmm4,%k1
 1f7e1d3:	vpbroadcastd -0x19ad209(%rip),%zmm6        # 5d0fd4 <.LCPI3_21>
 1f7e1dd:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7e1e4:	kmovd  %r13d,%k4
 1f7e1e9:	vpsrld $0x10,%zmm21,%zmm10
 1f7e1f0:	vpbroadcastb -0x1ac7437(%rip),%xmm8        # 4b6dc2 <abi_test_hex.digits+0xba42>
 1f7e1f9:	vpbroadcastb -0x1ac743f(%rip),%xmm9        # 4b6dc3 <abi_test_hex.digits+0xba43>
 1f7e202:	kmovw  %k1,%eax
 1f7e206:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7e20c:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7e213:	vmovdqu64 0x1b0(%rsp),%zmm0
 1f7e21e:	korw   %k1,%k3,%k3
 1f7e222:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7e229:	vpandd -0x19ad23b(%rip){1to16},%zmm19,%zmm5        # 5d0ff8 <.LCPI3_74>
 1f7e233:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7e239:	vpbroadcastb -0x1ac747e(%rip),%xmm7        # 4b6dc4 <abi_test_hex.digits+0xba44>
 1f7e242:	vinserti64x4 $0x1,0x170(%rsp),%zmm0,%zmm0
 1f7e24e:	kmovw  %k0,%ecx
 1f7e252:	korw   %k2,%k3,%k2
 1f7e256:	vpaddd -0x19ad290(%rip){1to16},%zmm5,%zmm5        # 5d0fd0 <.LCPI3_20>
 1f7e260:	andn   %ecx,%eax,%eax
 1f7e265:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7e26b:	kmovd  %eax,%k3
 1f7e26f:	shr    $0x8,%eax
 1f7e272:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7e278:	kmovd  %eax,%k3
 1f7e27c:	vmovdqu8 %xmm15,%xmm4{%k2}{z}
 1f7e282:	vpcmpltud %zmm6,%zmm5,%k2
 1f7e289:	vpslld $0x1f,%zmm5,%zmm5
 1f7e290:	vpxor  %xmm6,%xmm6,%xmm6
 1f7e294:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7e29a:	vptestmd -0x19ad2d8(%rip){1to16},%zmm23,%k3        # 5d0fcc <.LCPI3_17>
 1f7e2a4:	vpandd %zmm18,%zmm23,%zmm3
 1f7e2aa:	vptestnmd %zmm3,%zmm3,%k0
 1f7e2b0:	kandd  %k6,%k0,%k0
 1f7e2b5:	korw   %k3,%k4,%k3
 1f7e2b9:	kandd  %k2,%k0,%k4
 1f7e2be:	vpcmpeqd %zmm17,%zmm2,%k2{%k4}
 1f7e2c4:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7e2ca:	vmovdqu8 -0x19b6514(%rip),%xmm2{%k4}        # 5c7dc0 <.LCPI3_25>
 1f7e2d4:	knotw  %k2,%k0
 1f7e2d8:	kandd  %k0,%k4,%k5
 1f7e2dd:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7e2e3:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7e2ea:	vpaddd %zmm5,%zmm10,%zmm11
 1f7e2f0:	vpbroadcastb -0x1ac7534(%rip),%xmm5        # 4b6dc5 <abi_test_hex.digits+0xba45>
 1f7e2f9:	vmovdqu8 -0x19b6533(%rip),%xmm2{%k4}        # 5c7dd0 <.LCPI3_26>
 1f7e303:	vptestnmd %zmm11,%zmm11,%k4
 1f7e309:	vpblendmb -0x19b6523(%rip),%xmm5,%xmm5{%k4}        # 5c7df0 <.LCPI3_28>
 1f7e313:	vpcmpnleud -0x19ad346(%rip){1to16},%zmm11,%k4        # 5d0fd8 <.LCPI3_22>
 1f7e31e:	mov    0x8(%rsp),%r13
 1f7e323:	cmpb   $0x0,0xbf0(%r13)
 1f7e32b:	vmovdqu8 -0x19b6535(%rip),%xmm5{%k4}        # 5c7e00 <.LCPI3_29>
 1f7e335:	vpcmpnleud -0x19ad364(%rip){1to16},%zmm11,%k4        # 5d0fdc <.LCPI3_23>
 1f7e340:	vmovdqu8 -0x19b653a(%rip),%xmm5{%k4}        # 5c7e10 <.LCPI3_30>
 1f7e34a:	vptestmd %zmm3,%zmm3,%k4
 1f7e350:	vpor   %xmm4,%xmm8,%xmm3
 1f7e354:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7e35a:	kmovw  0x60(%rsp),%k4
 1f7e360:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7e366:	vpor   %xmm2,%xmm4,%xmm2
 1f7e36a:	vpord  -0x19ad378(%rip){1to4},%xmm2,%xmm3        # 5d0ffc <.LCPI3_77>
 1f7e374:	vpbroadcastb -0x1ac75b7(%rip),%xmm5        # 4b6dc6 <abi_test_hex.digits+0xba46>
 1f7e37d:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7e383:	vpor   %xmm5,%xmm2,%xmm3
 1f7e387:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7e38d:	vpmovdb %zmm21,%xmm3
 1f7e393:	kmovw  0x70(%rsp),%k3
 1f7e399:	vpor   %xmm3,%xmm9,%xmm4
 1f7e39d:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7e3a3:	vptestmd -0x19ad3cd(%rip){1to16},%zmm12,%k3{%k7}        # 5d0fe0 <.LCPI3_32>
 1f7e3ad:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7e3b3:	vpor   %xmm5,%xmm4,%xmm6
 1f7e3b7:	vpsrld $0xb,%zmm23,%zmm7
 1f7e3be:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7e3c4:	vpandd -0x19ad3ce(%rip){1to4},%xmm24,%xmm4        # 5d1000 <.LCPI3_79>
 1f7e3ce:	vptestmd -0x19ad3f4(%rip){1to16},%zmm23,%k1        # 5d0fe4 <.LCPI3_33>
 1f7e3d8:	vpmovdb %zmm7,%xmm7
 1f7e3de:	vpand  %xmm7,%xmm8,%xmm7
 1f7e3e2:	vporq  %xmm16,%xmm4,%xmm5
 1f7e3e8:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7e3ee:	vpmovdb %zmm23,%xmm5
 1f7e3f4:	vgf2p8affineqb $0x0,-0x19afe47(%rip){1to2},%xmm5,%xmm5        # 5ce5b8 <.LCPI3_80>
 1f7e3ff:	vpternlogq $0xf8,%xmm9,%xmm5,%xmm4
 1f7e406:	vpmovdb %zmm19,%xmm9
 1f7e40c:	vpor   %xmm4,%xmm15,%xmm5
 1f7e410:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7e416:	vinserti32x4 $0x3,%xmm13,%zmm22,%zmm5{%k6}{z}
 1f7e41d:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7e424:	vpsrld $0x8,%zmm19,%zmm13
 1f7e42b:	vpsrld $0x10,%zmm19,%zmm6
 1f7e432:	vpmovdb %zmm6,%xmm7
 1f7e438:	vpmovdb %zmm13,%xmm8
 1f7e43e:	vpmovdb %zmm12,%xmm6
 1f7e444:	je     1f7e53c <node_facts_window_run+0x116c>
 1f7e44a:	vmovdqa64 -0x1ac7c54(%rip),%zmm19        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7e454:	vptestmd %zmm10,%zmm10,%k1{%k2}
 1f7e45a:	add    %rdi,%rdx
 1f7e45d:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e462:	vpxor  %xmm13,%xmm13,%xmm13
 1f7e467:	vpcmpneqd -0x19ad48a(%rip){1to16},%zmm10,%k0{%k1}        # 5d0fe8 <.LCPI3_38>
 1f7e472:	vmovdqa %xmm7,%xmm10
 1f7e476:	vpternlogq $0xfe,%xmm9,%xmm3,%xmm10
 1f7e47d:	kmovq  %k1,%k2
 1f7e482:	kmovw  %k1,%eax
 1f7e486:	popcnt %eax,%ecx
 1f7e48a:	vpgatherdd 0x10(%rdx,%zmm19,1),%zmm12{%k2}
 1f7e492:	kmovq  %k1,%k2
 1f7e497:	vpcmpnleud -0x19ad4b6(%rip){1to16},%zmm12,%k3        # 5d0fec <.LCPI3_39>
 1f7e4a2:	vpgatherdd 0x14(%rdx,%zmm19,1),%zmm13{%k2}
 1f7e4aa:	add    %rcx,0x110(%rsp)
 1f7e4b2:	mov    0x10(%rsp),%r8
 1f7e4b7:	vpcmpeqd %zmm11,%zmm12,%k2
 1f7e4bd:	vmovdqa64 %xmm20,%xmm11
 1f7e4c3:	vpternlogq $0xfe,%xmm8,%xmm10,%xmm11
 1f7e4ca:	vptestnmd %zmm13,%zmm13,%k2{%k2}
 1f7e4d0:	vptestmd %zmm13,%zmm13,%k4
 1f7e4d6:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm11
 1f7e4dd:	korw   %k4,%k3,%k3
 1f7e4e1:	kandw  %k2,%k0,%k2
 1f7e4e5:	knotw  %k0,%k0
 1f7e4e9:	kandd  %k1,%k0,%k0
 1f7e4ee:	kandw  %k0,%k3,%k0
 1f7e4f2:	korw   %k0,%k2,%k2
 1f7e4f6:	vptestnmd %zmm14,%zmm21,%k0{%k2}
 1f7e4fc:	kandw  %k0,%k1,%k0
 1f7e500:	knotd  %k6,%k1
 1f7e505:	kmovd  %k0,%ecx
 1f7e509:	vptestmb %xmm11,%xmm11,%k0{%k1}
 1f7e50f:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7e515:	andn   %eax,%ecx,%eax
 1f7e51a:	popcnt %eax,%eax
 1f7e51e:	kmovw  %k0,%ecx
 1f7e522:	popcnt %ecx,%ecx
 1f7e526:	kmovw  %k1,%edx
 1f7e52a:	popcnt %edx,%edx
 1f7e52e:	add    %rdx,%r8
 1f7e531:	add    %rax,%r8
 1f7e534:	add    %rcx,%r8
 1f7e537:	mov    %r8,0x10(%rsp)
 1f7e53c:	mov    0x20(%rsp),%rbp
 1f7e541:	jmp    1f7dc6c <node_facts_window_run+0x89c>
 1f7e546:	kandw  %k0,%k7,%k0
 1f7e54a:	mov    %rdx,0x1f0(%rsp)
 1f7e552:	vmovdqa %xmm10,0x170(%rsp)
 1f7e55b:	vmovdqu64 %zmm11,0x2a0(%rsp)
 1f7e566:	vmovdqu64 %ymm19,0x320(%rsp)
 1f7e56e:	vmovdqu64 %zmm20,0x480(%rsp)
 1f7e576:	vmovdqu64 %ymm21,0x3e0(%rsp)
 1f7e57e:	vmovdqu64 %zmm7,0x2e0(%rsp)
 1f7e589:	vmovdqu %ymm13,0x440(%rsp)
 1f7e592:	vmovdqu64 %zmm22,0x600(%rsp)
 1f7e59a:	vmovdqu64 %ymm23,0x5c0(%rsp)
 1f7e5a2:	vmovdqu64 %zmm5,0x4c0(%rsp)
 1f7e5aa:	vmovdqu %ymm6,0x580(%rsp)
 1f7e5b3:	vmovdqu64 %zmm24,0x540(%rsp)
 1f7e5bb:	vmovdqu64 %ymm25,0x670(%rsp)
 1f7e5c6:	vmovdqu64 %zmm4,0x770(%rsp)
 1f7e5d1:	vmovdqu64 %ymm26,0x420(%rsp)
 1f7e5d9:	vmovdqu64 %zmm27,0x730(%rsp)
 1f7e5e4:	vmovdqu64 %ymm28,0x520(%rsp)
 1f7e5ec:	vmovdqu64 %zmm0,0x6f0(%rsp)
 1f7e5f7:	mov    %rbx,0x260(%rsp)
 1f7e5ff:	kmovd  %k6,0x3a0(%rsp)
 1f7e609:	kmovw  %k7,0x360(%rsp)
 1f7e612:	kmovd  %k0,%eax
 1f7e616:	movzwl %ax,%eax
 1f7e619:	jmp    1f7e7ad <node_facts_window_run+0x13dd>
 1f7e61e:	mov    0x48(%rsp),%rsi
 1f7e623:	mov    (%r12,%r13,4),%r8d
 1f7e627:	shl    $0x6,%rax
 1f7e62b:	mov    0x20(%r11),%rcx
 1f7e62f:	mov    %r8,0x1b0(%rsp)
 1f7e637:	mov    0x8(%rsp),%r14
 1f7e63c:	mov    0xba8(%r14),%rdx
 1f7e643:	mov    %r14,%rdi
 1f7e646:	cmpb   $0x1,(%rdx,%r8,1)
 1f7e64b:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7e650:	adc    $0x0,%rsi
 1f7e654:	and    $0x1,%edx
 1f7e657:	mov    %rsi,0x48(%rsp)
 1f7e65c:	mov    0x98(%rsp),%rbx
 1f7e664:	mov    (%rbx,%r13,4),%esi
 1f7e668:	vzeroupper
 1f7e66b:	call   1f93850 <node_tests_window_line>
 1f7e670:	mov    (%rbx,%r13,4),%esi
 1f7e674:	mov    %r14,%rdi
 1f7e677:	mov    %al,0x60(%rsp)
 1f7e67b:	call   1f939a0 <node_tests_window_returns>
 1f7e680:	or     %bpl,%al
 1f7e683:	or     0x60(%rsp),%al
 1f7e687:	mov    0xba8(%r14),%rcx
 1f7e68e:	mov    0x1b0(%rsp),%rdx
 1f7e696:	vpbroadcastd -0x19ad6f4(%rip),%zmm14        # 5d0fac <.LCPI3_5>
 1f7e6a0:	vpbroadcastb -0x1ac78e9(%rip),%xmm15        # 4b6dc0 <abi_test_hex.digits+0xba40>
 1f7e6a9:	vpbroadcastb -0x1ac78f2(%rip),%xmm16        # 4b6dc1 <abi_test_hex.digits+0xba41>
 1f7e6b3:	vpbroadcastd -0x19ad709(%rip),%zmm17        # 5d0fb4 <.LCPI3_11>
 1f7e6bd:	vpbroadcastd -0x19ad70b(%rip),%zmm18        # 5d0fbc <.LCPI3_13>
 1f7e6c7:	vmovdqa 0x170(%rsp),%xmm10
 1f7e6d0:	vmovdqu64 0x2a0(%rsp),%zmm11
 1f7e6db:	vmovdqu64 0x320(%rsp),%ymm19
 1f7e6e3:	vmovdqu64 0x480(%rsp),%zmm20
 1f7e6eb:	vmovdqu64 0x3e0(%rsp),%ymm21
 1f7e6f3:	vmovdqu64 0x2e0(%rsp),%zmm7
 1f7e6fe:	vmovdqu 0x440(%rsp),%ymm13
 1f7e707:	vmovdqu64 0x600(%rsp),%zmm22
 1f7e70f:	vmovdqu64 0x5c0(%rsp),%ymm23
 1f7e717:	vmovdqu64 0x4c0(%rsp),%zmm5
 1f7e71f:	vmovdqu 0x580(%rsp),%ymm6
 1f7e728:	vmovdqu64 0x540(%rsp),%zmm24
 1f7e730:	vmovdqu64 0x670(%rsp),%ymm25
 1f7e73b:	vmovdqu64 0x770(%rsp),%zmm4
 1f7e746:	vmovdqu64 0x420(%rsp),%ymm26
 1f7e74e:	vmovdqu64 0x730(%rsp),%zmm27
 1f7e759:	vmovdqu64 0x520(%rsp),%ymm28
 1f7e761:	vmovdqu64 0x6f0(%rsp),%zmm0
 1f7e76c:	mov    (%rsp),%r11
 1f7e770:	mov    0x40(%rsp),%r9
 1f7e775:	mov    0x30(%rsp),%r10
 1f7e77a:	mov    0x28(%rsp),%rsi
 1f7e77f:	mov    0x18(%rsp),%rdi
 1f7e784:	mov    0x260(%rsp),%rbx
 1f7e78c:	kmovd  0x3a0(%rsp),%k6
 1f7e796:	kmovw  0x360(%rsp),%k7
 1f7e79f:	mov    %al,(%rcx,%rdx,1)
 1f7e7a2:	mov    0x70(%rsp),%eax
 1f7e7a6:	blsr   %eax,%eax
 1f7e7ab:	je     1f7e81b <node_facts_window_run+0x144b>
 1f7e7ad:	tzcnt  %eax,%r13d
 1f7e7b2:	mov    %eax,0x70(%rsp)
 1f7e7b6:	mov    0x60(%r11),%edx
 1f7e7ba:	mov    $0x1,%bpl
 1f7e7bd:	add    %rbx,%r13
 1f7e7c0:	mov    %r13,%rcx
 1f7e7c3:	shl    $0x6,%rcx
 1f7e7c7:	mov    (%rdi,%rcx,1),%eax
 1f7e7ca:	mov    0xc(%rdi,%rcx,1),%ecx
 1f7e7ce:	shr    $0x3,%eax
 1f7e7d1:	cmp    %edx,%eax
 1f7e7d3:	cmovae %edx,%eax
 1f7e7d6:	test   %rcx,%rcx
 1f7e7d9:	je     1f7e61e <node_facts_window_run+0x124e>
 1f7e7df:	mov    0x88(%rsp),%rdx
 1f7e7e7:	mov    0x48(%rsp),%rsi
 1f7e7ec:	cmp    0x3b8(%rdx),%ecx
 1f7e7f2:	jae    1f7e623 <node_facts_window_run+0x1253>
 1f7e7f8:	mov    0x88(%rsp),%rdx
 1f7e800:	mov    0x3a8(%rdx),%rdx
 1f7e807:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7e80b:	setne  %bpl
 1f7e80f:	shl    $0x5,%bpl
 1f7e813:	inc    %bpl
 1f7e816:	jmp    1f7e623 <node_facts_window_run+0x1253>
 1f7e81b:	mov    0xba8(%r14),%rax
 1f7e822:	kmovq  %k7,%k1
 1f7e827:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e82c:	mov    0x1f0(%rsp),%rdx
 1f7e834:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7e83b:	jmp    1f7de17 <node_facts_window_run+0xa47>
 1f7e840:	cmpq   $0x0,0xb40(%r11)
 1f7e848:	je     1f7ff0a <node_facts_window_run+0x2b3a>
 1f7e84e:	test   %eax,%eax
 1f7e850:	je     1f8076d <node_facts_window_run+0x339d>
 1f7e856:	vpbroadcastd -0x19ad8b4(%rip),%zmm10        # 5d0fac <.LCPI3_5>
 1f7e860:	vpbroadcastb -0x1ac7aa9(%rip),%xmm11        # 4b6dc0 <abi_test_hex.digits+0xba40>
 1f7e869:	vpbroadcastb -0x1ac7ab1(%rip),%xmm12        # 4b6dc1 <abi_test_hex.digits+0xba41>
 1f7e872:	vpbroadcastd -0x19ad8c8(%rip),%zmm13        # 5d0fb4 <.LCPI3_11>
 1f7e87c:	vpbroadcastd -0x19ad8ca(%rip),%zmm14        # 5d0fbc <.LCPI3_13>
 1f7e886:	mov    (%r11),%rcx
 1f7e889:	lea    0x69454(%rbp),%r8
 1f7e890:	lea    0x422c(%rbp),%rdx
 1f7e897:	xor    %r14d,%r14d
 1f7e89a:	mov    %rcx,0x540(%rsp)
 1f7e8a2:	mov    %r8,0x5c0(%rsp)
 1f7e8aa:	mov    %rdx,0x4c0(%rsp)
 1f7e8b2:	mov    %eax,%r8d
 1f7e8b5:	movq   $0x0,0x48(%rsp)
 1f7e8be:	movq   $0x0,0x110(%rsp)
 1f7e8ca:	movq   $0x0,0x10(%rsp)
 1f7e8d3:	mov    %r8,0x580(%rsp)
 1f7e8db:	jmp    1f7e963 <node_facts_window_run+0x1593>
 1f7e8e0:	vpxor  %xmm1,%xmm1,%xmm1
 1f7e8e4:	vpxor  %xmm3,%xmm3,%xmm3
 1f7e8e8:	vpxor  %xmm4,%xmm4,%xmm4
 1f7e8ec:	vpxor  %xmm5,%xmm5,%xmm5
 1f7e8f0:	vpxor  %xmm0,%xmm0,%xmm0
 1f7e8f4:	vpxord %xmm16,%xmm16,%xmm16
 1f7e8fa:	mov    0xb70(%r13),%rax
 1f7e901:	vmovdqu64 %xmm16,(%rax,%r14,1)
 1f7e908:	mov    0xb78(%r13),%rax
 1f7e90f:	vmovdqu %xmm0,(%rax,%r14,1)
 1f7e915:	mov    0xb88(%r11),%rax
 1f7e91c:	vmovdqu %xmm5,(%rax,%r14,1)
 1f7e922:	mov    0xb90(%r11),%rax
 1f7e929:	vmovdqu %xmm4,(%rax,%r14,1)
 1f7e92f:	mov    0xb98(%r11),%rax
 1f7e936:	vmovdqu %xmm3,(%rax,%r14,1)
 1f7e93c:	mov    0xba0(%r11),%rax
 1f7e943:	vmovdqu %xmm1,(%rax,%r14,1)
 1f7e949:	mov    0xba8(%r11),%rax
 1f7e950:	vmovdqu %xmm2,(%rax,%r14,1)
 1f7e956:	add    $0x10,%r14
 1f7e95a:	cmp    %r8,%r14
 1f7e95d:	jae    1f8078b <node_facts_window_run+0x33bb>
 1f7e963:	vpxor  %xmm2,%xmm2,%xmm2
 1f7e967:	cmp    %rsi,%r14
 1f7e96a:	jae    1f7e8e0 <node_facts_window_run+0x1510>
 1f7e970:	mov    %esi,%eax
 1f7e972:	sub    %r14d,%eax
 1f7e975:	mov    $0x10,%ecx
 1f7e97a:	mov    $0xffffffff,%edx
 1f7e97f:	vpxord %xmm18,%xmm18,%xmm18
 1f7e985:	cmp    $0x10,%eax
 1f7e988:	cmovae %ecx,%eax
 1f7e98b:	mov    0x9b8(%r11),%rcx
 1f7e992:	shlx   %eax,%edx,%eax
 1f7e997:	mov    %r14,%rdx
 1f7e99a:	shl    $0x6,%rdx
 1f7e99e:	not    %eax
 1f7e9a0:	vmovdqu (%rdi,%rdx,1),%ymm0
 1f7e9a5:	vmovdqu 0x180(%rdi,%rdx,1),%ymm3
 1f7e9ae:	vmovdqu 0x80(%rdi,%rdx,1),%ymm1
 1f7e9b7:	vmovdqu 0x100(%rdi,%rdx,1),%ymm2
 1f7e9c0:	kmovd  %eax,%k1
 1f7e9c4:	vinserti64x4 $0x1,0x40(%rdi,%rdx,1),%zmm0,%zmm6
 1f7e9cd:	vmovdqu 0x200(%rdi,%rdx,1),%ymm0
 1f7e9d6:	vinserti64x4 $0x1,0x1c0(%rdi,%rdx,1),%zmm3,%zmm7
 1f7e9df:	mov    0xba8(%r13),%rax
 1f7e9e6:	vinserti64x4 $0x1,0xc0(%rdi,%rdx,1),%zmm1,%zmm1
 1f7e9ef:	vinserti64x4 $0x1,0x140(%rdi,%rdx,1),%zmm2,%zmm2
 1f7e9f8:	vinserti64x4 $0x1,0x240(%rdi,%rdx,1),%zmm0,%zmm3
 1f7ea01:	vmovdqu 0x280(%rdi,%rdx,1),%ymm0
 1f7ea0a:	vmovdqu8 (%rcx,%r14,1),%xmm4{%k1}{z}
 1f7ea11:	mov    0x5c0(%rsp),%rcx
 1f7ea19:	vinserti64x4 $0x1,0x2c0(%rdi,%rdx,1),%zmm0,%zmm9
 1f7ea22:	vmovdqu 0x300(%rdi,%rdx,1),%ymm0
 1f7ea2b:	vinserti64x4 $0x1,0x340(%rdi,%rdx,1),%zmm0,%zmm8
 1f7ea34:	vmovdqu 0x380(%rdi,%rdx,1),%ymm0
 1f7ea3d:	vinserti64x4 $0x1,0x3c0(%rdi,%rdx,1),%zmm0,%zmm15
 1f7ea46:	vmovdqu8 (%rcx,%r14,1),%xmm5{%k1}{z}
 1f7ea4d:	vptestmb %xmm4,%xmm4,%k6
 1f7ea53:	vpcmpeqb -0x19b6ccd(%rip),%xmm5,%k7{%k6}        # 5c7d90 <.LCPI3_10>
 1f7ea5d:	vmovdqu32 (%r12,%r14,4),%zmm0{%k7}{z}
 1f7ea64:	kmovq  %k7,%k1
 1f7ea69:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7ea70:	vptestnmd %zmm13,%zmm18,%k0
 1f7ea76:	ktestw %k0,%k7
 1f7ea7a:	jne    1f7f03f <node_facts_window_run+0x1c6f>
 1f7ea80:	vmovdqa64 -0x1ac834a(%rip),%zmm0        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7ea8a:	vptestmd -0x19adadc(%rip){1to16},%zmm18,%k0        # 5d0fb8 <.LCPI3_12>
 1f7ea94:	kmovd  %k6,%ebx
 1f7ea98:	vpermt2d %zmm1,%zmm0,%zmm6
 1f7ea9e:	vpermt2d %zmm7,%zmm0,%zmm2
 1f7eaa4:	vpermt2d %zmm9,%zmm0,%zmm3
 1f7eaaa:	vpermt2d %zmm15,%zmm0,%zmm8
 1f7eab0:	kmovd  %k0,%r13d
 1f7eab4:	vptestmd %zmm14,%zmm18,%k0
 1f7eaba:	vshufi64x2 $0x44,%zmm2,%zmm6,%zmm0
 1f7eac1:	vshufi64x2 $0x44,%zmm8,%zmm3,%zmm1
 1f7eac8:	vshufi64x2 $0xee,%zmm2,%zmm6,%zmm2
 1f7eacf:	vshufi64x2 $0xee,%zmm8,%zmm3,%zmm3
 1f7ead6:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm15{%k6}{z}
 1f7eadd:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7eae4:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm17{%k6}{z}
 1f7eaeb:	vshufi64x2 $0x88,%zmm3,%zmm2,%zmm7
 1f7eaf2:	vpsrld $0x19,%zmm15,%zmm0
 1f7eaf9:	vpandd -0x19adb5b(%rip){1to16},%zmm0,%zmm0        # 5d0fa8 <.LCPI3_4>
 1f7eb03:	vpsrld $0x18,%zmm15,%zmm1
 1f7eb0a:	vpsrld $0x1a,%zmm15,%zmm6
 1f7eb11:	vpternlogd $0xec,%zmm10,%zmm0,%zmm1
 1f7eb18:	vpandd -0x19adb2e(%rip){1to16},%zmm15,%zmm0        # 5d0ff4 <.LCPI3_71>
 1f7eb22:	vpmovdb %zmm1,%xmm16
 1f7eb28:	vpsrld $0xc,%zmm17,%zmm1
 1f7eb2f:	vpmovdb %zmm1,%xmm20
 1f7eb35:	vpcmpeqd -0x19adb8f(%rip){1to16},%zmm0,%k1{%k6}        # 5d0fb0 <.LCPI3_7>
 1f7eb3f:	vporq  %xmm11,%xmm16,%xmm0
 1f7eb45:	vmovdqu8 %xmm0,%xmm16{%k1}
 1f7eb4b:	vpcmpeqb %xmm11,%xmm5,%k1{%k6}
 1f7eb51:	vpternlogq $0xf8,%xmm12,%xmm20,%xmm16
 1f7eb58:	kmovd  %k1,%eax
 1f7eb5c:	kmovw  %k1,0x70(%rsp)
 1f7eb62:	korw   %k0,%k1,%k1
 1f7eb66:	kmovw  %k1,0x1b0(%rsp)
 1f7eb6f:	test   %ax,%ax
 1f7eb72:	je     1f7ecf9 <node_facts_window_run+0x1929>
 1f7eb78:	vmovdqu64 %zmm7,0x600(%rsp)
 1f7eb80:	vmovdqu64 %zmm6,0x440(%rsp)
 1f7eb88:	vmovdqa64 %xmm20,0x2e0(%rsp)
 1f7eb90:	vmovdqu64 %zmm19,0x3e0(%rsp)
 1f7eb9b:	vmovdqu64 %zmm18,0x480(%rsp)
 1f7eba3:	vmovdqu64 %zmm15,0x320(%rsp)
 1f7ebae:	vmovdqa %xmm4,0x2a0(%rsp)
 1f7ebb7:	vmovdqu64 %zmm17,0x1f0(%rsp)
 1f7ebc2:	mov    %ebx,0x360(%rsp)
 1f7ebc9:	vmovdqa64 %xmm16,0x3a0(%rsp)
 1f7ebd1:	kmovw  %k7,0x170(%rsp)
 1f7ebda:	kmovw  %k6,0x60(%rsp)
 1f7ebe0:	mov    %rdx,0x260(%rsp)
 1f7ebe8:	movzwl %ax,%ebx
 1f7ebeb:	movzwl %r13w,%r13d
 1f7ebef:	mov    0x4c0(%rsp),%rax
 1f7ebf7:	mov    0x8(%rsp),%rbp
 1f7ebfc:	lea    (%rax,%r14,4),%r15
 1f7ec00:	xor    %r12d,%r12d
 1f7ec03:	tzcnt  %ebx,%r12d
 1f7ec08:	mov    %rbp,%rdi
 1f7ec0b:	xor    %edx,%edx
 1f7ec0d:	mov    (%r15,%r12,4),%esi
 1f7ec11:	vzeroupper
 1f7ec14:	call   1f93850 <node_tests_window_line>
 1f7ec19:	mov    $0x1,%edx
 1f7ec1e:	xor    %ecx,%ecx
 1f7ec20:	test   $0x2,%al
 1f7ec22:	shlx   %r12d,%edx,%eax
 1f7ec27:	cmove  %ecx,%eax
 1f7ec2a:	or     %eax,%r13d
 1f7ec2d:	blsr   %ebx,%ebx
 1f7ec32:	jne    1f7ec00 <node_facts_window_run+0x1830>
 1f7ec34:	vpbroadcastd -0x19adc92(%rip),%zmm10        # 5d0fac <.LCPI3_5>
 1f7ec3e:	vpbroadcastb -0x1ac7e87(%rip),%xmm11        # 4b6dc0 <abi_test_hex.digits+0xba40>
 1f7ec47:	vpbroadcastb -0x1ac7e8f(%rip),%xmm12        # 4b6dc1 <abi_test_hex.digits+0xba41>
 1f7ec50:	vpbroadcastd -0x19adca6(%rip),%zmm13        # 5d0fb4 <.LCPI3_11>
 1f7ec5a:	vpbroadcastd -0x19adca8(%rip),%zmm14        # 5d0fbc <.LCPI3_13>
 1f7ec64:	vmovdqa64 0x3a0(%rsp),%xmm16
 1f7ec6c:	vmovdqu64 0x1f0(%rsp),%zmm17
 1f7ec77:	vmovdqa 0x2a0(%rsp),%xmm4
 1f7ec80:	vmovdqu64 0x320(%rsp),%zmm15
 1f7ec8b:	vmovdqu64 0x480(%rsp),%zmm18
 1f7ec93:	vmovdqu64 0x3e0(%rsp),%zmm19
 1f7ec9e:	vmovdqa64 0x2e0(%rsp),%xmm20
 1f7eca6:	vmovdqu64 0x440(%rsp),%zmm6
 1f7ecae:	vmovdqu64 0x600(%rsp),%zmm7
 1f7ecb6:	mov    (%rsp),%r11
 1f7ecba:	mov    0x40(%rsp),%r9
 1f7ecbf:	mov    0x30(%rsp),%r10
 1f7ecc4:	mov    0x38(%rsp),%r12
 1f7ecc9:	mov    0x28(%rsp),%rsi
 1f7ecce:	mov    0x18(%rsp),%rdi
 1f7ecd3:	mov    0x580(%rsp),%r8
 1f7ecdb:	mov    0x260(%rsp),%rdx
 1f7ece3:	kmovw  0x60(%rsp),%k6
 1f7ece9:	kmovw  0x170(%rsp),%k7
 1f7ecf2:	mov    0x360(%rsp),%ebx
 1f7ecf9:	vpsrld $0x2,%zmm17,%zmm0
 1f7ed00:	vpandd -0x19add4a(%rip){1to16},%zmm0,%zmm0        # 5d0fc0 <.LCPI3_14>
 1f7ed0a:	vptestmd -0x19add4c(%rip){1to16},%zmm17,%k2        # 5d0fc8 <.LCPI3_16>
 1f7ed14:	vpandd -0x19add26(%rip){1to16},%zmm15,%zmm3        # 5d0ff8 <.LCPI3_74>
 1f7ed1e:	vptestnmb %xmm4,%xmm4,%k0
 1f7ed24:	vpbroadcastd -0x19add5a(%rip),%zmm4        # 5d0fd4 <.LCPI3_21>
 1f7ed2e:	vptestmd -0x19add6c(%rip){1to16},%zmm19,%k3        # 5d0fcc <.LCPI3_17>
 1f7ed38:	vpandd %zmm14,%zmm19,%zmm1
 1f7ed3e:	vpbroadcastb -0x1ac7f83(%rip),%xmm8        # 4b6dc4 <abi_test_hex.digits+0xba44>
 1f7ed47:	vpbroadcastb -0x1ac7f8e(%rip),%xmm5        # 4b6dc2 <abi_test_hex.digits+0xba42>
 1f7ed50:	vpbroadcastb -0x1ac7f96(%rip),%xmm9        # 4b6dc3 <abi_test_hex.digits+0xba43>
 1f7ed59:	vpcmpneqd -0x19adda0(%rip){1to16},%zmm0,%k1        # 5d0fc4 <.LCPI3_15>
 1f7ed64:	vpaddd -0x19add9e(%rip){1to16},%zmm3,%zmm3        # 5d0fd0 <.LCPI3_20>
 1f7ed6e:	vpcmpeqd %zmm4,%zmm6,%k5{%k6}
 1f7ed74:	vpsrld $0x10,%zmm17,%zmm6
 1f7ed7b:	korw   %k1,%k2,%k1
 1f7ed7f:	vptestnmd %zmm7,%zmm7,%k2
 1f7ed85:	korw   %k2,%k0,%k2
 1f7ed89:	vptestnmd %zmm1,%zmm1,%k0
 1f7ed8f:	korw   %k1,%k2,%k1
 1f7ed93:	kmovd  %k0,%eax
 1f7ed97:	vpcmpltud %zmm4,%zmm3,%k0
 1f7ed9e:	vpslld $0x1f,%zmm3,%zmm3
 1f7eda5:	vpxor  %xmm4,%xmm4,%xmm4
 1f7eda9:	vptestmd %zmm0,%zmm0,%k1{%k1}
 1f7edaf:	kmovd  %k0,%ecx
 1f7edb3:	and    %eax,%ecx
 1f7edb5:	mov    %ebx,%eax
 1f7edb7:	and    %ecx,%eax
 1f7edb9:	kmovd  %eax,%k4
 1f7edbd:	vmovdqu8 %xmm11,%xmm2{%k1}{z}
 1f7edc3:	kmovd  %r13d,%k1
 1f7edc8:	korw   %k3,%k1,%k3
 1f7edcc:	vpcmpeqd %zmm13,%zmm0,%k1{%k4}
 1f7edd2:	vmovdqu8 %xmm8,%xmm0{%k5}{z}
 1f7edd8:	vmovdqu8 -0x19b7022(%rip),%xmm0{%k4}        # 5c7dc0 <.LCPI3_25>
 1f7ede2:	knotw  %k1,%k0
 1f7ede6:	kmovd  %k0,%ecx
 1f7edea:	and    %eax,%ecx
 1f7edec:	kmovd  %ecx,%k4
 1f7edf0:	vpcmpgtd %zmm3,%zmm4,%k4{%k4}
 1f7edf6:	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
 1f7edfd:	vpaddd %zmm3,%zmm6,%zmm7
 1f7ee03:	vpbroadcastb -0x1ac8047(%rip),%xmm3        # 4b6dc5 <abi_test_hex.digits+0xba45>
 1f7ee0c:	vmovdqu8 -0x19b7046(%rip),%xmm0{%k4}        # 5c7dd0 <.LCPI3_26>
 1f7ee16:	vptestnmd %zmm7,%zmm7,%k4
 1f7ee1c:	vpblendmb -0x19b7036(%rip),%xmm3,%xmm3{%k4}        # 5c7df0 <.LCPI3_28>
 1f7ee26:	vpcmpnleud -0x19ade59(%rip){1to16},%zmm7,%k4        # 5d0fd8 <.LCPI3_22>
 1f7ee31:	mov    0x8(%rsp),%r13
 1f7ee36:	cmpb   $0x0,0xbf0(%r13)
 1f7ee3e:	vmovdqu8 -0x19b7048(%rip),%xmm3{%k4}        # 5c7e00 <.LCPI3_29>
 1f7ee48:	vpcmpnleud -0x19ade77(%rip){1to16},%zmm7,%k4        # 5d0fdc <.LCPI3_23>
 1f7ee53:	vmovdqu8 -0x19b704d(%rip),%xmm3{%k4}        # 5c7e10 <.LCPI3_30>
 1f7ee5d:	vptestmd %zmm1,%zmm1,%k4
 1f7ee63:	vpor   %xmm5,%xmm2,%xmm1
 1f7ee67:	vmovdqu8 %xmm1,%xmm2{%k4}
 1f7ee6d:	kmovw  0x1b0(%rsp),%k4
 1f7ee76:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f7ee7c:	vpor   %xmm0,%xmm2,%xmm0
 1f7ee80:	vpord  -0x19ade8e(%rip){1to4},%xmm0,%xmm1        # 5d0ffc <.LCPI3_77>
 1f7ee8a:	vpbroadcastb -0x1ac80cd(%rip),%xmm3        # 4b6dc6 <abi_test_hex.digits+0xba46>
 1f7ee93:	vmovdqu8 %xmm1,%xmm0{%k4}
 1f7ee99:	vpor   %xmm3,%xmm0,%xmm1
 1f7ee9d:	vmovdqu8 %xmm1,%xmm0{%k3}
 1f7eea3:	vpmovdb %zmm17,%xmm1
 1f7eea9:	kmovw  0x70(%rsp),%k3
 1f7eeaf:	vpor   %xmm1,%xmm9,%xmm2
 1f7eeb3:	vmovdqu8 %xmm2,%xmm1{%k3}
 1f7eeb9:	vptestmd -0x19adee3(%rip){1to16},%zmm18,%k3{%k7}        # 5d0fe0 <.LCPI3_32>
 1f7eec3:	vmovdqu8 %xmm8,%xmm2{%k3}{z}
 1f7eec9:	vpor   %xmm3,%xmm2,%xmm3
 1f7eecd:	vpsrld $0x8,%zmm15,%zmm8
 1f7eed4:	vmovdqu8 %xmm2,%xmm3{%k2}
 1f7eeda:	vpandd -0x19adee4(%rip){1to4},%xmm20,%xmm2        # 5d1000 <.LCPI3_79>
 1f7eee4:	vptestmd -0x19adf0a(%rip){1to16},%zmm19,%k2        # 5d0fe4 <.LCPI3_33>
 1f7eeee:	vpor   %xmm2,%xmm12,%xmm4
 1f7eef2:	vmovdqu8 %xmm4,%xmm2{%k6}
 1f7eef8:	vpmovdb %zmm19,%xmm4
 1f7eefe:	vgf2p8affineqb $0x0,-0x19b0951(%rip){1to2},%xmm4,%xmm4        # 5ce5b8 <.LCPI3_80>
 1f7ef09:	vpternlogq $0xf8,%xmm9,%xmm4,%xmm2
 1f7ef10:	vpor   %xmm2,%xmm11,%xmm4
 1f7ef14:	vmovdqu8 %xmm4,%xmm2{%k2}
 1f7ef1a:	vpsrld $0xb,%zmm19,%zmm4
 1f7ef21:	vpmovdb %zmm4,%xmm4
 1f7ef27:	vpand  %xmm5,%xmm4,%xmm4
 1f7ef2b:	vpmovdb %zmm15,%xmm5
 1f7ef31:	vpternlogq $0xfe,%xmm4,%xmm3,%xmm2
 1f7ef38:	vpsrld $0x10,%zmm15,%zmm3
 1f7ef3f:	vpmovdb %zmm8,%xmm4
 1f7ef45:	vpmovdb %zmm3,%xmm3
 1f7ef4b:	je     1f7f035 <node_facts_window_run+0x1c65>
 1f7ef51:	vmovdqa64 -0x1ac875b(%rip),%zmm15        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7ef5b:	vptestmd %zmm6,%zmm6,%k1{%k1}
 1f7ef61:	add    %rdi,%rdx
 1f7ef64:	vpxor  %xmm8,%xmm8,%xmm8
 1f7ef69:	vpxor  %xmm9,%xmm9,%xmm9
 1f7ef6e:	vpcmpneqd -0x19adf91(%rip){1to16},%zmm6,%k0{%k1}        # 5d0fe8 <.LCPI3_38>
 1f7ef79:	vmovdqa %xmm3,%xmm6
 1f7ef7d:	vpternlogq $0xfe,%xmm5,%xmm1,%xmm6
 1f7ef84:	kmovq  %k1,%k2
 1f7ef89:	kmovw  %k1,%eax
 1f7ef8d:	popcnt %eax,%ecx
 1f7ef91:	vpgatherdd 0x10(%rdx,%zmm15,1),%zmm8{%k2}
 1f7ef99:	kmovq  %k1,%k2
 1f7ef9e:	vpcmpnleud -0x19adfbd(%rip){1to16},%zmm8,%k3        # 5d0fec <.LCPI3_39>
 1f7efa9:	vpgatherdd 0x14(%rdx,%zmm15,1),%zmm9{%k2}
 1f7efb1:	add    %rcx,0x110(%rsp)
 1f7efb9:	mov    0x10(%rsp),%rdx
 1f7efbe:	vpcmpeqd %zmm7,%zmm8,%k2
 1f7efc4:	vmovdqa64 %xmm16,%xmm7
 1f7efca:	vpternlogq $0xfe,%xmm4,%xmm6,%xmm7
 1f7efd1:	vptestnmd %zmm9,%zmm9,%k2{%k2}
 1f7efd7:	vptestmd %zmm9,%zmm9,%k4
 1f7efdd:	vpternlogq $0xfe,%xmm2,%xmm0,%xmm7
 1f7efe4:	korw   %k4,%k3,%k3
 1f7efe8:	kandw  %k2,%k0,%k2
 1f7efec:	knotw  %k0,%k0
 1f7eff0:	kandd  %k1,%k0,%k0
 1f7eff5:	kandw  %k0,%k3,%k0
 1f7eff9:	korw   %k0,%k2,%k2
 1f7effd:	vptestnmd %zmm10,%zmm17,%k0{%k2}
 1f7f003:	kandw  %k0,%k1,%k0
 1f7f007:	kmovd  %k0,%ecx
 1f7f00b:	vptestmb %xmm7,%xmm7,%k0
 1f7f011:	andn   %eax,%ecx,%eax
 1f7f016:	kmovd  %k0,%ecx
 1f7f01a:	andn   %ecx,%ebx,%ecx
 1f7f01f:	popcnt %eax,%eax
 1f7f023:	movzwl %cx,%ecx
 1f7f026:	popcnt %ecx,%ecx
 1f7f02a:	add    %rcx,%rdx
 1f7f02d:	add    %rax,%rdx
 1f7f030:	mov    %rdx,0x10(%rsp)
 1f7f035:	mov    0x20(%rsp),%rbp
 1f7f03a:	jmp    1f7e8fa <node_facts_window_run+0x152a>
 1f7f03f:	kandw  %k0,%k7,%k0
 1f7f043:	mov    %rdx,0x260(%rsp)
 1f7f04b:	vmovdqa %xmm5,0x70(%rsp)
 1f7f051:	vmovdqu64 %zmm6,0x1b0(%rsp)
 1f7f05c:	vmovdqu64 %zmm2,0x3a0(%rsp)
 1f7f067:	vmovdqu64 %zmm3,0x360(%rsp)
 1f7f072:	vmovdqu64 %zmm1,0x1f0(%rsp)
 1f7f07d:	vmovdqu64 %zmm7,0x320(%rsp)
 1f7f088:	vmovdqu64 %zmm8,0x480(%rsp)
 1f7f090:	vmovdqu64 %zmm9,0x3e0(%rsp)
 1f7f09b:	vmovdqu64 %zmm15,0x2e0(%rsp)
 1f7f0a6:	vmovdqu64 %zmm0,0x440(%rsp)
 1f7f0ae:	kmovw  %k6,0x60(%rsp)
 1f7f0b4:	kmovw  %k7,0x170(%rsp)
 1f7f0bd:	vmovdqa %xmm4,0x2a0(%rsp)
 1f7f0c6:	kmovd  %k0,%eax
 1f7f0ca:	movzwl %ax,%r13d
 1f7f0ce:	jmp    1f7f1ed <node_facts_window_run+0x1e1d>
 1f7f0d3:	mov    0x8(%rsp),%r15
 1f7f0d8:	mov    (%r12,%rax,4),%ebx
 1f7f0dc:	shl    $0x6,%rcx
 1f7f0e0:	mov    0x20(%r11),%rdx
 1f7f0e4:	mov    0xba8(%r15),%rsi
 1f7f0eb:	movzbl 0x30(%rdx,%rcx,1),%edx
 1f7f0f0:	mov    %r15,%rdi
 1f7f0f3:	cmpb   $0x1,(%rsi,%rbx,1)
 1f7f0f7:	adcq   $0x0,0x48(%rsp)
 1f7f0fd:	and    $0x1,%edx
 1f7f100:	mov    0x4c0(%rsp),%rsi
 1f7f108:	mov    (%rsi,%rax,4),%esi
 1f7f10b:	vzeroupper
 1f7f10e:	call   1f93850 <node_tests_window_line>
 1f7f113:	vpbroadcastd -0x19ae171(%rip),%zmm10        # 5d0fac <.LCPI3_5>
 1f7f11d:	vpbroadcastb -0x1ac8366(%rip),%xmm11        # 4b6dc0 <abi_test_hex.digits+0xba40>
 1f7f126:	vpbroadcastb -0x1ac836e(%rip),%xmm12        # 4b6dc1 <abi_test_hex.digits+0xba41>
 1f7f12f:	vpbroadcastd -0x19ae185(%rip),%zmm13        # 5d0fb4 <.LCPI3_11>
 1f7f139:	vpbroadcastd -0x19ae187(%rip),%zmm14        # 5d0fbc <.LCPI3_13>
 1f7f143:	vmovdqa 0x2a0(%rsp),%xmm4
 1f7f14c:	vmovdqa 0x70(%rsp),%xmm5
 1f7f152:	vmovdqu64 0x1b0(%rsp),%zmm6
 1f7f15d:	vmovdqu64 0x3a0(%rsp),%zmm2
 1f7f168:	vmovdqu64 0x360(%rsp),%zmm3
 1f7f173:	vmovdqu64 0x1f0(%rsp),%zmm1
 1f7f17e:	vmovdqu64 0x320(%rsp),%zmm7
 1f7f189:	vmovdqu64 0x480(%rsp),%zmm8
 1f7f191:	vmovdqu64 0x3e0(%rsp),%zmm9
 1f7f19c:	vmovdqu64 0x2e0(%rsp),%zmm15
 1f7f1a7:	vmovdqu64 0x440(%rsp),%zmm0
 1f7f1af:	mov    (%rsp),%r11
 1f7f1b3:	mov    0xba8(%r15),%rcx
 1f7f1ba:	mov    0x40(%rsp),%r9
 1f7f1bf:	mov    0x30(%rsp),%r10
 1f7f1c4:	mov    0x18(%rsp),%rdi
 1f7f1c9:	mov    0x580(%rsp),%r8
 1f7f1d1:	kmovw  0x60(%rsp),%k6
 1f7f1d7:	kmovw  0x170(%rsp),%k7
 1f7f1e0:	or     %bpl,%al
 1f7f1e3:	blsr   %r13d,%r13d
 1f7f1e8:	mov    %al,(%rcx,%rbx,1)
 1f7f1eb:	je     1f7f254 <node_facts_window_run+0x1e84>
 1f7f1ed:	xor    %eax,%eax
 1f7f1ef:	tzcnt  %r13d,%eax
 1f7f1f4:	mov    0x60(%r11),%esi
 1f7f1f8:	mov    $0x1,%bpl
 1f7f1fb:	add    %r14,%rax
 1f7f1fe:	mov    %rax,%rdx
 1f7f201:	shl    $0x6,%rdx
 1f7f205:	mov    (%rdi,%rdx,1),%ecx
 1f7f208:	mov    0xc(%rdi,%rdx,1),%edx
 1f7f20c:	shr    $0x3,%ecx
 1f7f20f:	cmp    %esi,%ecx
 1f7f211:	cmovae %esi,%ecx
 1f7f214:	test   %rdx,%rdx
 1f7f217:	je     1f7f0d3 <node_facts_window_run+0x1d03>
 1f7f21d:	mov    0x540(%rsp),%rsi
 1f7f225:	cmp    0x3b8(%rsi),%edx
 1f7f22b:	jae    1f7f0d3 <node_facts_window_run+0x1d03>
 1f7f231:	mov    0x540(%rsp),%rsi
 1f7f239:	mov    0x3a8(%rsi),%rsi
 1f7f240:	cmpl   $0x0,(%rsi,%rdx,4)
 1f7f244:	setne  %bpl
 1f7f248:	shl    $0x5,%bpl
 1f7f24c:	inc    %bpl
 1f7f24f:	jmp    1f7f0d3 <node_facts_window_run+0x1d03>
 1f7f254:	mov    0x8(%rsp),%rax
 1f7f259:	kmovq  %k7,%k1
 1f7f25e:	vpxord %xmm18,%xmm18,%xmm18
 1f7f264:	mov    0x28(%rsp),%rsi
 1f7f269:	mov    0x260(%rsp),%rdx
 1f7f271:	mov    0xba8(%rax),%rax
 1f7f278:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7f27f:	jmp    1f7ea80 <node_facts_window_run+0x16b0>
 1f7f284:	test   %eax,%eax
 1f7f286:	je     1f8076d <node_facts_window_run+0x339d>
 1f7f28c:	vpbroadcastd -0x19ae2ea(%rip),%zmm13        # 5d0fac <.LCPI3_5>
 1f7f296:	vpbroadcastb -0x1ac84df(%rip),%xmm14        # 4b6dc0 <abi_test_hex.digits+0xba40>
 1f7f29f:	vpbroadcastb -0x1ac84e7(%rip),%xmm15        # 4b6dc1 <abi_test_hex.digits+0xba41>
 1f7f2a8:	vpbroadcastd -0x19ae2fe(%rip),%zmm16        # 5d0fb4 <.LCPI3_11>
 1f7f2b2:	vpbroadcastd -0x19ae300(%rip),%zmm17        # 5d0fbc <.LCPI3_13>
 1f7f2bc:	mov    (%r11),%rcx
 1f7f2bf:	lea    0x69454(%rbp),%r8
 1f7f2c6:	lea    0x422c(%rbp),%rdx
 1f7f2cd:	mov    %eax,%r15d
 1f7f2d0:	xor    %ebx,%ebx
 1f7f2d2:	mov    %rcx,0x88(%rsp)
 1f7f2da:	mov    %r8,0xb0(%rsp)
 1f7f2e2:	mov    %rdx,0x98(%rsp)
 1f7f2ea:	movq   $0x0,0x48(%rsp)
 1f7f2f3:	movq   $0x0,0x110(%rsp)
 1f7f2ff:	movq   $0x0,0x10(%rsp)
 1f7f308:	mov    %r15,0xa8(%rsp)
 1f7f310:	jmp    1f7f3d5 <node_facts_window_run+0x2005>
 1f7f315:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7f320:	vpxor  %xmm1,%xmm1,%xmm1
 1f7f324:	vpxor  %xmm0,%xmm0,%xmm0
 1f7f328:	vpxor  %xmm5,%xmm5,%xmm5
 1f7f32c:	vpxor  %xmm3,%xmm3,%xmm3
 1f7f330:	vpxor  %xmm6,%xmm6,%xmm6
 1f7f334:	vpxor  %xmm7,%xmm7,%xmm7
 1f7f338:	vpxor  %xmm8,%xmm8,%xmm8
 1f7f33d:	vpxor  %xmm2,%xmm2,%xmm2
 1f7f341:	vpxord %xmm19,%xmm19,%xmm19
 1f7f347:	mov    0xb70(%r13),%rax
 1f7f34e:	vmovdqu64 %xmm19,(%rax,%rbx,1)
 1f7f355:	mov    0xb78(%r13),%rax
 1f7f35c:	vmovdqu %xmm2,(%rax,%rbx,1)
 1f7f361:	mov    0xb88(%r11),%rax
 1f7f368:	vmovdqu %xmm8,(%rax,%rbx,1)
 1f7f36d:	mov    0xb90(%r11),%rax
 1f7f374:	vmovdqu %xmm7,(%rax,%rbx,1)
 1f7f379:	mov    0xb98(%r11),%rax
 1f7f380:	vmovdqu %xmm6,(%rax,%rbx,1)
 1f7f385:	mov    0xba0(%r11),%rax
 1f7f38c:	vmovdqu %xmm3,(%rax,%rbx,1)
 1f7f391:	mov    0xba8(%r11),%rax
 1f7f398:	vmovdqu %xmm4,(%rax,%rbx,1)
 1f7f39d:	mov    0xc28(%r11),%rax
 1f7f3a4:	vmovdqu64 %zmm5,(%rax,%rbx,4)
 1f7f3ab:	mov    0xcd8(%r11),%rax
 1f7f3b2:	vmovdqu64 %zmm0,(%rax,%rbx,8)
 1f7f3b9:	mov    0xcd8(%r11),%rax
 1f7f3c0:	vmovdqu64 %zmm1,0x40(%rax,%rbx,8)
 1f7f3c8:	add    $0x10,%rbx
 1f7f3cc:	cmp    %r15,%rbx
 1f7f3cf:	jae    1f8078b <node_facts_window_run+0x33bb>
 1f7f3d5:	vpxor  %xmm4,%xmm4,%xmm4
 1f7f3d9:	cmp    %rsi,%rbx
 1f7f3dc:	jae    1f7f320 <node_facts_window_run+0x1f50>
 1f7f3e2:	mov    %esi,%eax
 1f7f3e4:	sub    %ebx,%eax
 1f7f3e6:	mov    $0x10,%ecx
 1f7f3eb:	mov    $0xffffffff,%edx
 1f7f3f0:	vpxor  %xmm12,%xmm12,%xmm12
 1f7f3f5:	cmp    $0x10,%eax
 1f7f3f8:	cmovae %ecx,%eax
 1f7f3fb:	mov    0x9b8(%r11),%rcx
 1f7f402:	shlx   %eax,%edx,%eax
 1f7f407:	mov    %rbx,%rdx
 1f7f40a:	shl    $0x6,%rdx
 1f7f40e:	not    %eax
 1f7f410:	vmovdqu (%rdi,%rdx,1),%ymm4
 1f7f415:	vmovdqu64 0x40(%rdi,%rdx,1),%ymm26
 1f7f41d:	vmovdqu64 0x80(%rdi,%rdx,1),%ymm27
 1f7f425:	vmovdqu64 0xc0(%rdi,%rdx,1),%ymm28
 1f7f42d:	vmovdqu 0x100(%rdi,%rdx,1),%ymm5
 1f7f436:	vmovdqu 0x140(%rdi,%rdx,1),%ymm6
 1f7f43f:	vmovdqu64 0x180(%rdi,%rdx,1),%ymm24
 1f7f447:	vmovdqu64 0x1c0(%rdi,%rdx,1),%ymm25
 1f7f44f:	vmovdqu 0x200(%rdi,%rdx,1),%ymm7
 1f7f458:	vmovdqu64 0x240(%rdi,%rdx,1),%ymm18
 1f7f460:	vmovdqu64 0x280(%rdi,%rdx,1),%ymm22
 1f7f468:	vmovdqu64 0x2c0(%rdi,%rdx,1),%ymm23
 1f7f470:	vmovdqu 0x300(%rdi,%rdx,1),%ymm11
 1f7f479:	vmovdqu64 0x340(%rdi,%rdx,1),%ymm19
 1f7f481:	vmovdqu64 0x380(%rdi,%rdx,1),%ymm20
 1f7f489:	vmovdqu64 0x3c0(%rdi,%rdx,1),%ymm21
 1f7f491:	kmovd  %eax,%k1
 1f7f495:	mov    0xba8(%r13),%rax
 1f7f49c:	vmovdqu8 (%rcx,%rbx,1),%xmm0{%k1}{z}
 1f7f4a3:	mov    0xb0(%rsp),%rcx
 1f7f4ab:	vmovdqu8 (%rcx,%rbx,1),%xmm10{%k1}{z}
 1f7f4b2:	vptestmb %xmm0,%xmm0,%k6
 1f7f4b8:	vpcmpeqb -0x19b7732(%rip),%xmm10,%k7{%k6}        # 5c7d90 <.LCPI3_10>
 1f7f4c2:	vmovdqu32 (%r12,%rbx,4),%zmm0{%k7}{z}
 1f7f4c9:	kmovq  %k7,%k1
 1f7f4ce:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7f4d5:	vptestnmd %zmm16,%zmm12,%k0
 1f7f4db:	ktestw %k0,%k7
 1f7f4df:	jne    1f7fc0e <node_facts_window_run+0x283e>
 1f7f4e5:	vpmovsxbd -0x19ae4fe(%rip),%xmm3        # 5d0ff0 <.LCPI3_70>
 1f7f4ee:	vmovdqa64 -0x1ac8db8(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7f4f8:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7f4ff:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7f506:	vptestmd -0x19ae558(%rip){1to16},%zmm12,%k0        # 5d0fb8 <.LCPI3_12>
 1f7f510:	vmovdqa64 %zmm0,%zmm2
 1f7f516:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7f51c:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7f522:	vmovdqa64 %zmm3,%zmm9
 1f7f528:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7f52e:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7f534:	kmovd  %k0,%r13d
 1f7f538:	vptestmd %zmm17,%zmm12,%k0
 1f7f53e:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7f544:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7f54b:	vmovdqu64 %zmm1,0x1b0(%rsp)
 1f7f556:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7f55d:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7f561:	vmovdqa64 %zmm1,%zmm4
 1f7f567:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7f56d:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7f573:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7f579:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7f57f:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7f586:	vmovdqu %ymm3,0x170(%rsp)
 1f7f58f:	vinserti64x4 $0x1,%ymm18,%zmm7,%zmm3
 1f7f596:	vpunpcklqdq %ymm18,%ymm7,%ymm7
 1f7f59c:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm18
 1f7f5a3:	vmovdqa64 %zmm3,%zmm6
 1f7f5a9:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7f5af:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7f5b5:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7f5bb:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7f5c1:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7f5c7:	vmovdqa64 %zmm18,%zmm7
 1f7f5cd:	vmovdqu64 %zmm5,0x2a0(%rsp)
 1f7f5d8:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7f5df:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7f5e5:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7f5ec:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7f5f3:	vpermt2d %zmm5,%zmm9,%zmm18
 1f7f5f9:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7f5ff:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7f606:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7f60c:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7f612:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7f619:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7f620:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm21{%k6}{z}
 1f7f627:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7f62e:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm20{%k6}{z}
 1f7f635:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7f63c:	vpsrld $0x19,%zmm21,%zmm0
 1f7f643:	vpandd -0x19ae6a5(%rip){1to16},%zmm0,%zmm0        # 5d0fa8 <.LCPI3_4>
 1f7f64d:	vpsrld $0x18,%zmm21,%zmm1
 1f7f654:	vpsrld $0x1a,%zmm21,%zmm7
 1f7f65b:	vpternlogd $0xec,%zmm13,%zmm0,%zmm1
 1f7f662:	vpandd -0x19ae678(%rip){1to16},%zmm21,%zmm0        # 5d0ff4 <.LCPI3_71>
 1f7f66c:	vpmovdb %zmm1,%xmm19
 1f7f672:	vpsrld $0xc,%zmm20,%zmm1
 1f7f679:	vpmovdb %zmm1,%xmm24
 1f7f67f:	vpcmpeqd -0x19ae6d9(%rip){1to16},%zmm0,%k1{%k6}        # 5d0fb0 <.LCPI3_7>
 1f7f689:	vporq  %xmm14,%xmm19,%xmm0
 1f7f68f:	vmovdqu8 %xmm0,%xmm19{%k1}
 1f7f695:	vpcmpeqb %xmm14,%xmm10,%k1{%k6}
 1f7f69b:	vpternlogq $0xf8,%xmm15,%xmm24,%xmm19
 1f7f6a2:	kmovd  %k1,%eax
 1f7f6a6:	kmovw  %k1,0x70(%rsp)
 1f7f6ac:	korw   %k0,%k1,%k1
 1f7f6b0:	kmovw  %k1,0x60(%rsp)
 1f7f6b6:	test   %ax,%ax
 1f7f6b9:	je     1f7f86d <node_facts_window_run+0x249d>
 1f7f6bf:	vmovdqu64 %zmm4,0x670(%rsp)
 1f7f6ca:	vmovdqu %ymm5,0x540(%rsp)
 1f7f6d3:	vmovdqu64 %zmm7,0x580(%rsp)
 1f7f6db:	vmovdqa64 %xmm24,0x4c0(%rsp)
 1f7f6e3:	vmovdqu64 %zmm23,0x5c0(%rsp)
 1f7f6eb:	vmovdqu64 %zmm22,0x600(%rsp)
 1f7f6f3:	vmovdqu64 %zmm21,0x440(%rsp)
 1f7f6fb:	vmovdqu64 %zmm18,0x2e0(%rsp)
 1f7f706:	vmovdqu64 %zmm20,0x3e0(%rsp)
 1f7f711:	vmovdqu64 %zmm12,0x480(%rsp)
 1f7f719:	vmovdqa64 %xmm19,0x320(%rsp)
 1f7f721:	kmovw  %k7,0x360(%rsp)
 1f7f72a:	mov    %rdx,0x1f0(%rsp)
 1f7f732:	kmovd  %k6,0x3a0(%rsp)
 1f7f73c:	movzwl %ax,%r14d
 1f7f740:	movzwl %r13w,%r13d
 1f7f744:	xor    %r15d,%r15d
 1f7f747:	mov    0x98(%rsp),%rax
 1f7f74f:	mov    %rbx,0x260(%rsp)
 1f7f757:	mov    0x8(%rsp),%rbp
 1f7f75c:	lea    (%rax,%rbx,4),%rbx
 1f7f760:	xor    %r12d,%r12d
 1f7f763:	tzcnt  %r14d,%r12d
 1f7f768:	mov    %rbp,%rdi
 1f7f76b:	xor    %edx,%edx
 1f7f76d:	mov    (%rbx,%r12,4),%esi
 1f7f771:	vzeroupper
 1f7f774:	call   1f93850 <node_tests_window_line>
 1f7f779:	mov    $0x1,%ecx
 1f7f77e:	test   $0x2,%al
 1f7f780:	shlx   %r12d,%ecx,%eax
 1f7f785:	cmove  %r15d,%eax
 1f7f789:	or     %eax,%r13d
 1f7f78c:	blsr   %r14d,%r14d
 1f7f791:	jne    1f7f760 <node_facts_window_run+0x2390>
 1f7f793:	vpbroadcastd -0x19ae7f1(%rip),%zmm13        # 5d0fac <.LCPI3_5>
 1f7f79d:	vpbroadcastb -0x1ac89e6(%rip),%xmm14        # 4b6dc0 <abi_test_hex.digits+0xba40>
 1f7f7a6:	vpbroadcastb -0x1ac89ee(%rip),%xmm15        # 4b6dc1 <abi_test_hex.digits+0xba41>
 1f7f7af:	vpbroadcastd -0x19ae805(%rip),%zmm16        # 5d0fb4 <.LCPI3_11>
 1f7f7b9:	vpbroadcastd -0x19ae807(%rip),%zmm17        # 5d0fbc <.LCPI3_13>
 1f7f7c3:	vmovdqa64 0x320(%rsp),%xmm19
 1f7f7cb:	vmovdqu64 0x480(%rsp),%zmm12
 1f7f7d3:	vmovdqu64 0x3e0(%rsp),%zmm20
 1f7f7de:	vmovdqu64 0x2e0(%rsp),%zmm18
 1f7f7e9:	vmovdqu64 0x440(%rsp),%zmm21
 1f7f7f1:	vmovdqu64 0x600(%rsp),%zmm22
 1f7f7f9:	vmovdqu64 0x5c0(%rsp),%zmm23
 1f7f801:	vmovdqa64 0x4c0(%rsp),%xmm24
 1f7f809:	vmovdqu64 0x580(%rsp),%zmm7
 1f7f811:	vmovdqu 0x540(%rsp),%ymm5
 1f7f81a:	vmovdqu64 0x670(%rsp),%zmm4
 1f7f825:	mov    (%rsp),%r11
 1f7f829:	mov    0x40(%rsp),%r9
 1f7f82e:	mov    0x30(%rsp),%r10
 1f7f833:	mov    0x38(%rsp),%r12
 1f7f838:	mov    0x28(%rsp),%rsi
 1f7f83d:	mov    0x18(%rsp),%rdi
 1f7f842:	mov    0xa8(%rsp),%r15
 1f7f84a:	mov    0x260(%rsp),%rbx
 1f7f852:	kmovd  0x3a0(%rsp),%k6
 1f7f85c:	mov    0x1f0(%rsp),%rdx
 1f7f864:	kmovw  0x360(%rsp),%k7
 1f7f86d:	vpsrld $0x2,%zmm20,%zmm0
 1f7f874:	vpandd -0x19ae8be(%rip){1to16},%zmm0,%zmm2        # 5d0fc0 <.LCPI3_14>
 1f7f87e:	vpbroadcastd -0x19ae8c4(%rip),%zmm0        # 5d0fc4 <.LCPI3_15>
 1f7f888:	vptestmd -0x19ae8ca(%rip){1to16},%zmm20,%k3        # 5d0fc8 <.LCPI3_16>
 1f7f892:	vmovdqu64 0x2a0(%rsp),%zmm1
 1f7f89d:	vptestnmd %zmm4,%zmm4,%k1
 1f7f8a3:	vpbroadcastd -0x19ae8d9(%rip),%zmm6        # 5d0fd4 <.LCPI3_21>
 1f7f8ad:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7f8b4:	kmovd  %r13d,%k4
 1f7f8b9:	vpsrld $0x10,%zmm20,%zmm9
 1f7f8c0:	vpbroadcastb -0x1ac8b07(%rip),%xmm8        # 4b6dc2 <abi_test_hex.digits+0xba42>
 1f7f8c9:	vpbroadcastb -0x1ac8b0f(%rip),%xmm11        # 4b6dc3 <abi_test_hex.digits+0xba43>
 1f7f8d2:	kmovw  %k1,%eax
 1f7f8d6:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7f8dc:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7f8e3:	vmovdqu64 0x1b0(%rsp),%zmm0
 1f7f8ee:	korw   %k1,%k3,%k3
 1f7f8f2:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7f8f9:	vpandd -0x19ae90b(%rip){1to16},%zmm21,%zmm5        # 5d0ff8 <.LCPI3_74>
 1f7f903:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7f909:	vpbroadcastb -0x1ac8b4e(%rip),%xmm7        # 4b6dc4 <abi_test_hex.digits+0xba44>
 1f7f912:	vinserti64x4 $0x1,0x170(%rsp),%zmm0,%zmm0
 1f7f91e:	kmovw  %k0,%ecx
 1f7f922:	korw   %k2,%k3,%k2
 1f7f926:	vpaddd -0x19ae960(%rip){1to16},%zmm5,%zmm5        # 5d0fd0 <.LCPI3_20>
 1f7f930:	andn   %ecx,%eax,%eax
 1f7f935:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7f93b:	kmovd  %eax,%k3
 1f7f93f:	shr    $0x8,%eax
 1f7f942:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7f948:	kmovd  %eax,%k3
 1f7f94c:	vmovdqu8 %xmm14,%xmm4{%k2}{z}
 1f7f952:	vpcmpltud %zmm6,%zmm5,%k2
 1f7f959:	vpslld $0x1f,%zmm5,%zmm5
 1f7f960:	vpxor  %xmm6,%xmm6,%xmm6
 1f7f964:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7f96a:	vptestmd -0x19ae9a8(%rip){1to16},%zmm23,%k3        # 5d0fcc <.LCPI3_17>
 1f7f974:	vpandd %zmm17,%zmm23,%zmm3
 1f7f97a:	vptestnmd %zmm3,%zmm3,%k0
 1f7f980:	kandd  %k6,%k0,%k0
 1f7f985:	korw   %k3,%k4,%k3
 1f7f989:	kandd  %k2,%k0,%k4
 1f7f98e:	vpcmpeqd %zmm16,%zmm2,%k2{%k4}
 1f7f994:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7f99a:	vmovdqu8 -0x19b7be4(%rip),%xmm2{%k4}        # 5c7dc0 <.LCPI3_25>
 1f7f9a4:	knotw  %k2,%k0
 1f7f9a8:	kandd  %k0,%k4,%k5
 1f7f9ad:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7f9b3:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7f9ba:	vpaddd %zmm5,%zmm9,%zmm10
 1f7f9c0:	vpbroadcastb -0x1ac8c04(%rip),%xmm5        # 4b6dc5 <abi_test_hex.digits+0xba45>
 1f7f9c9:	vmovdqu8 -0x19b7c03(%rip),%xmm2{%k4}        # 5c7dd0 <.LCPI3_26>
 1f7f9d3:	vptestnmd %zmm10,%zmm10,%k4
 1f7f9d9:	vpblendmb -0x19b7bf3(%rip),%xmm5,%xmm5{%k4}        # 5c7df0 <.LCPI3_28>
 1f7f9e3:	vpcmpnleud -0x19aea16(%rip){1to16},%zmm10,%k4        # 5d0fd8 <.LCPI3_22>
 1f7f9ee:	mov    0x8(%rsp),%r13
 1f7f9f3:	cmpb   $0x0,0xbf0(%r13)
 1f7f9fb:	vmovdqu8 -0x19b7c05(%rip),%xmm5{%k4}        # 5c7e00 <.LCPI3_29>
 1f7fa05:	vpcmpnleud -0x19aea34(%rip){1to16},%zmm10,%k4        # 5d0fdc <.LCPI3_23>
 1f7fa10:	vmovdqu8 -0x19b7c0a(%rip),%xmm5{%k4}        # 5c7e10 <.LCPI3_30>
 1f7fa1a:	vptestmd %zmm3,%zmm3,%k4
 1f7fa20:	vpor   %xmm4,%xmm8,%xmm3
 1f7fa24:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7fa2a:	kmovw  0x60(%rsp),%k4
 1f7fa30:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7fa36:	vpor   %xmm2,%xmm4,%xmm2
 1f7fa3a:	vpord  -0x19aea48(%rip){1to4},%xmm2,%xmm3        # 5d0ffc <.LCPI3_77>
 1f7fa44:	vpbroadcastb -0x1ac8c87(%rip),%xmm5        # 4b6dc6 <abi_test_hex.digits+0xba46>
 1f7fa4d:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7fa53:	vpor   %xmm5,%xmm2,%xmm3
 1f7fa57:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7fa5d:	vpmovdb %zmm20,%xmm3
 1f7fa63:	kmovw  0x70(%rsp),%k3
 1f7fa69:	vpor   %xmm3,%xmm11,%xmm4
 1f7fa6d:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7fa73:	vptestmd -0x19aea9d(%rip){1to16},%zmm12,%k3{%k7}        # 5d0fe0 <.LCPI3_32>
 1f7fa7d:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7fa83:	vpor   %xmm5,%xmm4,%xmm6
 1f7fa87:	vpsrld $0xb,%zmm23,%zmm7
 1f7fa8e:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7fa94:	vpandd -0x19aea9e(%rip){1to4},%xmm24,%xmm4        # 5d1000 <.LCPI3_79>
 1f7fa9e:	vptestmd -0x19aeac4(%rip){1to16},%zmm23,%k1        # 5d0fe4 <.LCPI3_33>
 1f7faa8:	vpmovdb %zmm7,%xmm7
 1f7faae:	vpand  %xmm7,%xmm8,%xmm7
 1f7fab2:	vpmovdb %zmm21,%xmm8
 1f7fab8:	vpor   %xmm4,%xmm15,%xmm5
 1f7fabc:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7fac2:	vpmovdb %zmm23,%xmm5
 1f7fac8:	vgf2p8affineqb $0x0,-0x19b151b(%rip){1to2},%xmm5,%xmm5        # 5ce5b8 <.LCPI3_80>
 1f7fad3:	vpternlogq $0xf8,%xmm11,%xmm5,%xmm4
 1f7fada:	vpsrld $0x8,%zmm21,%zmm11
 1f7fae1:	vpor   %xmm4,%xmm14,%xmm5
 1f7fae5:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7faeb:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7faf2:	vpsrld $0x10,%zmm21,%zmm6
 1f7faf9:	vpmovdb %zmm11,%xmm7
 1f7faff:	vinserti32x4 $0x3,%xmm18,%zmm22,%zmm5{%k6}{z}
 1f7fb06:	vpmovdb %zmm6,%xmm6
 1f7fb0c:	je     1f7fc04 <node_facts_window_run+0x2834>
 1f7fb12:	vmovdqa64 -0x1ac931c(%rip),%zmm18        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7fb1c:	vptestmd %zmm9,%zmm9,%k1{%k2}
 1f7fb22:	add    %rdi,%rdx
 1f7fb25:	vpxor  %xmm11,%xmm11,%xmm11
 1f7fb2a:	vpxor  %xmm12,%xmm12,%xmm12
 1f7fb2f:	vpcmpneqd -0x19aeb52(%rip){1to16},%zmm9,%k0{%k1}        # 5d0fe8 <.LCPI3_38>
 1f7fb3a:	vmovdqa %xmm6,%xmm9
 1f7fb3e:	vpternlogq $0xfe,%xmm8,%xmm3,%xmm9
 1f7fb45:	kmovq  %k1,%k2
 1f7fb4a:	kmovw  %k1,%eax
 1f7fb4e:	popcnt %eax,%ecx
 1f7fb52:	vpgatherdd 0x10(%rdx,%zmm18,1),%zmm11{%k2}
 1f7fb5a:	kmovq  %k1,%k2
 1f7fb5f:	vpcmpnleud -0x19aeb7e(%rip){1to16},%zmm11,%k3        # 5d0fec <.LCPI3_39>
 1f7fb6a:	vpgatherdd 0x14(%rdx,%zmm18,1),%zmm12{%k2}
 1f7fb72:	add    %rcx,0x110(%rsp)
 1f7fb7a:	mov    0x10(%rsp),%r8
 1f7fb7f:	vpcmpeqd %zmm10,%zmm11,%k2
 1f7fb85:	vmovdqa64 %xmm19,%xmm10
 1f7fb8b:	vpternlogq $0xfe,%xmm7,%xmm9,%xmm10
 1f7fb92:	vptestnmd %zmm12,%zmm12,%k2{%k2}
 1f7fb98:	vptestmd %zmm12,%zmm12,%k4
 1f7fb9e:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm10
 1f7fba5:	korw   %k4,%k3,%k3
 1f7fba9:	kandw  %k2,%k0,%k2
 1f7fbad:	knotw  %k0,%k0
 1f7fbb1:	kandd  %k1,%k0,%k0
 1f7fbb6:	kandw  %k0,%k3,%k0
 1f7fbba:	korw   %k0,%k2,%k2
 1f7fbbe:	vptestnmd %zmm13,%zmm20,%k0{%k2}
 1f7fbc4:	kandw  %k0,%k1,%k0
 1f7fbc8:	knotd  %k6,%k1
 1f7fbcd:	kmovd  %k0,%ecx
 1f7fbd1:	vptestmb %xmm10,%xmm10,%k0{%k1}
 1f7fbd7:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7fbdd:	andn   %eax,%ecx,%eax
 1f7fbe2:	popcnt %eax,%eax
 1f7fbe6:	kmovw  %k0,%ecx
 1f7fbea:	popcnt %ecx,%ecx
 1f7fbee:	kmovw  %k1,%edx
 1f7fbf2:	popcnt %edx,%edx
 1f7fbf6:	add    %rdx,%r8
 1f7fbf9:	add    %rax,%r8
 1f7fbfc:	add    %rcx,%r8
 1f7fbff:	mov    %r8,0x10(%rsp)
 1f7fc04:	mov    0x20(%rsp),%rbp
 1f7fc09:	jmp    1f7f347 <node_facts_window_run+0x1f77>
 1f7fc0e:	kandw  %k0,%k7,%k0
 1f7fc12:	mov    %rdx,0x1f0(%rsp)
 1f7fc1a:	mov    %rbx,0x260(%rsp)
 1f7fc22:	vmovdqa %xmm10,0x170(%rsp)
 1f7fc2b:	vmovdqu64 %zmm11,0x2a0(%rsp)
 1f7fc36:	vmovdqu64 %ymm19,0x320(%rsp)
 1f7fc3e:	vmovdqu64 %zmm20,0x480(%rsp)
 1f7fc46:	vmovdqu64 %ymm21,0x3e0(%rsp)
 1f7fc4e:	vmovdqu64 %zmm7,0x2e0(%rsp)
 1f7fc59:	vmovdqu64 %ymm18,0x440(%rsp)
 1f7fc61:	vmovdqu64 %zmm22,0x600(%rsp)
 1f7fc69:	vmovdqu64 %ymm23,0x5c0(%rsp)
 1f7fc71:	vmovdqu64 %zmm5,0x4c0(%rsp)
 1f7fc79:	vmovdqu %ymm6,0x580(%rsp)
 1f7fc82:	vmovdqu64 %zmm24,0x540(%rsp)
 1f7fc8a:	vmovdqu64 %ymm25,0x670(%rsp)
 1f7fc95:	vmovdqu64 %zmm4,0x770(%rsp)
 1f7fca0:	vmovdqu64 %ymm26,0x420(%rsp)
 1f7fca8:	vmovdqu64 %zmm27,0x730(%rsp)
 1f7fcb3:	vmovdqu64 %ymm28,0x520(%rsp)
 1f7fcbb:	vmovdqu64 %zmm0,0x6f0(%rsp)
 1f7fcc6:	kmovd  %k6,0x3a0(%rsp)
 1f7fcd0:	kmovw  %k7,0x360(%rsp)
 1f7fcd9:	kmovd  %k0,%eax
 1f7fcdd:	movzwl %ax,%eax
 1f7fce0:	jmp    1f7fe6a <node_facts_window_run+0x2a9a>
 1f7fce5:	mov    0x48(%rsp),%rsi
 1f7fcea:	mov    (%r12,%r13,4),%r8d
 1f7fcee:	shl    $0x6,%rax
 1f7fcf2:	mov    0x20(%r11),%rcx
 1f7fcf6:	mov    %r8,0x1b0(%rsp)
 1f7fcfe:	mov    0x8(%rsp),%rbx
 1f7fd03:	mov    0xba8(%rbx),%rdx
 1f7fd0a:	mov    %rbx,%rdi
 1f7fd0d:	cmpb   $0x1,(%rdx,%r8,1)
 1f7fd12:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7fd17:	adc    $0x0,%rsi
 1f7fd1b:	and    $0x1,%edx
 1f7fd1e:	mov    %rsi,0x48(%rsp)
 1f7fd23:	mov    0x98(%rsp),%r14
 1f7fd2b:	mov    (%r14,%r13,4),%esi
 1f7fd2f:	vzeroupper
 1f7fd32:	call   1f93850 <node_tests_window_line>
 1f7fd37:	mov    (%r14,%r13,4),%esi
 1f7fd3b:	mov    %rbx,%rdi
 1f7fd3e:	mov    %al,0x60(%rsp)
 1f7fd42:	call   1f939a0 <node_tests_window_returns>
 1f7fd47:	or     %bpl,%al
 1f7fd4a:	or     0x60(%rsp),%al
 1f7fd4e:	mov    0xba8(%rbx),%rcx
 1f7fd55:	mov    0x1b0(%rsp),%rdx
 1f7fd5d:	vpbroadcastd -0x19aedbb(%rip),%zmm13        # 5d0fac <.LCPI3_5>
 1f7fd67:	vpbroadcastb -0x1ac8fb0(%rip),%xmm14        # 4b6dc0 <abi_test_hex.digits+0xba40>
 1f7fd70:	vpbroadcastb -0x1ac8fb8(%rip),%xmm15        # 4b6dc1 <abi_test_hex.digits+0xba41>
 1f7fd79:	vpbroadcastd -0x19aedcf(%rip),%zmm16        # 5d0fb4 <.LCPI3_11>
 1f7fd83:	vpbroadcastd -0x19aedd1(%rip),%zmm17        # 5d0fbc <.LCPI3_13>
 1f7fd8d:	vmovdqa 0x170(%rsp),%xmm10
 1f7fd96:	vmovdqu64 0x2a0(%rsp),%zmm11
 1f7fda1:	vmovdqu64 0x320(%rsp),%ymm19
 1f7fda9:	vmovdqu64 0x480(%rsp),%zmm20
 1f7fdb1:	vmovdqu64 0x3e0(%rsp),%ymm21
 1f7fdb9:	vmovdqu64 0x2e0(%rsp),%zmm7
 1f7fdc4:	vmovdqu64 0x440(%rsp),%ymm18
 1f7fdcc:	vmovdqu64 0x600(%rsp),%zmm22
 1f7fdd4:	vmovdqu64 0x5c0(%rsp),%ymm23
 1f7fddc:	vmovdqu64 0x4c0(%rsp),%zmm5
 1f7fde4:	vmovdqu 0x580(%rsp),%ymm6
 1f7fded:	vmovdqu64 0x540(%rsp),%zmm24
 1f7fdf5:	vmovdqu64 0x670(%rsp),%ymm25
 1f7fe00:	vmovdqu64 0x770(%rsp),%zmm4
 1f7fe0b:	vmovdqu64 0x420(%rsp),%ymm26
 1f7fe13:	vmovdqu64 0x730(%rsp),%zmm27
 1f7fe1e:	vmovdqu64 0x520(%rsp),%ymm28
 1f7fe26:	vmovdqu64 0x6f0(%rsp),%zmm0
 1f7fe31:	mov    (%rsp),%r11
 1f7fe35:	mov    0x40(%rsp),%r9
 1f7fe3a:	mov    0x30(%rsp),%r10
 1f7fe3f:	mov    0x28(%rsp),%rsi
 1f7fe44:	mov    0x18(%rsp),%rdi
 1f7fe49:	kmovd  0x3a0(%rsp),%k6
 1f7fe53:	kmovw  0x360(%rsp),%k7
 1f7fe5c:	mov    %al,(%rcx,%rdx,1)
 1f7fe5f:	mov    0x70(%rsp),%eax
 1f7fe63:	blsr   %eax,%eax
 1f7fe68:	je     1f7fedd <node_facts_window_run+0x2b0d>
 1f7fe6a:	mov    %eax,0x70(%rsp)
 1f7fe6e:	tzcnt  %eax,%r13d
 1f7fe73:	mov    0x60(%r11),%edx
 1f7fe77:	mov    $0x1,%bpl
 1f7fe7a:	add    0x260(%rsp),%r13
 1f7fe82:	mov    %r13,%rcx
 1f7fe85:	shl    $0x6,%rcx
 1f7fe89:	mov    (%rdi,%rcx,1),%eax
 1f7fe8c:	mov    0xc(%rdi,%rcx,1),%ecx
 1f7fe90:	shr    $0x3,%eax
 1f7fe93:	cmp    %edx,%eax
 1f7fe95:	cmovae %edx,%eax
 1f7fe98:	test   %rcx,%rcx
 1f7fe9b:	je     1f7fce5 <node_facts_window_run+0x2915>
 1f7fea1:	mov    0x88(%rsp),%rdx
 1f7fea9:	mov    0x48(%rsp),%rsi
 1f7feae:	cmp    0x3b8(%rdx),%ecx
 1f7feb4:	jae    1f7fcea <node_facts_window_run+0x291a>
 1f7feba:	mov    0x88(%rsp),%rdx
 1f7fec2:	mov    0x3a8(%rdx),%rdx
 1f7fec9:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7fecd:	setne  %bpl
 1f7fed1:	shl    $0x5,%bpl
 1f7fed5:	inc    %bpl
 1f7fed8:	jmp    1f7fcea <node_facts_window_run+0x291a>
 1f7fedd:	mov    0xba8(%rbx),%rax
 1f7fee4:	kmovq  %k7,%k1
 1f7fee9:	vpxor  %xmm12,%xmm12,%xmm12
 1f7feee:	mov    0x260(%rsp),%rbx
 1f7fef6:	mov    0x1f0(%rsp),%rdx
 1f7fefe:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7ff05:	jmp    1f7f4e5 <node_facts_window_run+0x2115>
 1f7ff0a:	test   %eax,%eax
 1f7ff0c:	je     1f8076d <node_facts_window_run+0x339d>
 1f7ff12:	vpbroadcastd -0x19aef70(%rip),%zmm6        # 5d0fac <.LCPI3_5>
 1f7ff1c:	vpbroadcastb -0x1ac9163(%rip),%xmm7        # 4b6dc2 <abi_test_hex.digits+0xba42>
 1f7ff25:	vpbroadcastd -0x19aef7b(%rip),%zmm8        # 5d0fb4 <.LCPI3_11>
 1f7ff2f:	vpbroadcastd -0x19aef7d(%rip),%zmm9        # 5d0fbc <.LCPI3_13>
 1f7ff39:	lea    0x69454(%rbp),%rcx
 1f7ff40:	lea    0x422c(%rbp),%r15
 1f7ff47:	mov    %eax,%r8d
 1f7ff4a:	xor    %r14d,%r14d
 1f7ff4d:	mov    %rcx,0x480(%rsp)
 1f7ff55:	movq   $0x0,0x48(%rsp)
 1f7ff5e:	movq   $0x0,0x110(%rsp)
 1f7ff6a:	movq   $0x0,0x10(%rsp)
 1f7ff73:	mov    %r8,0x3e0(%rsp)
 1f7ff7b:	mov    %r15,0x2e0(%rsp)
 1f7ff83:	jmp    1f7ffbc <node_facts_window_run+0x2bec>
 1f7ff85:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7ff90:	vpxor  %xmm11,%xmm11,%xmm11
 1f7ff95:	mov    0xb70(%r13),%rax
 1f7ff9c:	vmovdqu %xmm11,(%rax,%r14,1)
 1f7ffa2:	mov    0xb78(%r13),%rax
 1f7ffa9:	vmovdqu %xmm0,(%rax,%r14,1)
 1f7ffaf:	add    $0x10,%r14
 1f7ffb3:	cmp    %r8,%r14
 1f7ffb6:	jae    1f8078b <node_facts_window_run+0x33bb>
 1f7ffbc:	vpxor  %xmm0,%xmm0,%xmm0
 1f7ffc0:	cmp    %rsi,%r14
 1f7ffc3:	jae    1f7ff90 <node_facts_window_run+0x2bc0>
 1f7ffc5:	mov    %esi,%eax
 1f7ffc7:	sub    %r14d,%eax
 1f7ffca:	mov    $0x10,%ecx
 1f7ffcf:	mov    $0xffffffff,%edx
 1f7ffd4:	mov    %r14,%rbp
 1f7ffd7:	cmp    $0x10,%eax
 1f7ffda:	cmovae %ecx,%eax
 1f7ffdd:	mov    0x9b8(%r11),%rcx
 1f7ffe4:	shl    $0x6,%rbp
 1f7ffe8:	shlx   %eax,%edx,%eax
 1f7ffed:	vmovdqu 0x100(%rdi,%rbp,1),%ymm2
 1f7fff6:	vmovdqu 0x180(%rdi,%rbp,1),%ymm3
 1f7ffff:	vmovdqu (%rdi,%rbp,1),%ymm0
 1f80004:	vmovdqu 0x80(%rdi,%rbp,1),%ymm1
 1f8000d:	not    %eax
 1f8000f:	vinserti64x4 $0x1,0x140(%rdi,%rbp,1),%zmm2,%zmm5
 1f80018:	vinserti64x4 $0x1,0x1c0(%rdi,%rbp,1),%zmm3,%zmm2
 1f80021:	vinserti64x4 $0x1,0x40(%rdi,%rbp,1),%zmm0,%zmm4
 1f8002a:	vmovdqu 0x200(%rdi,%rbp,1),%ymm0
 1f80033:	vinserti64x4 $0x1,0xc0(%rdi,%rbp,1),%zmm1,%zmm12
 1f8003c:	kmovd  %eax,%k1
 1f80040:	vinserti64x4 $0x1,0x240(%rdi,%rbp,1),%zmm0,%zmm11
 1f80049:	vmovdqu 0x280(%rdi,%rbp,1),%ymm0
 1f80052:	mov    0xba8(%r13),%rax
 1f80059:	vinserti64x4 $0x1,0x2c0(%rdi,%rbp,1),%zmm0,%zmm14
 1f80062:	vmovdqu 0x300(%rdi,%rbp,1),%ymm0
 1f8006b:	vmovdqu8 (%rcx,%r14,1),%xmm10{%k1}{z}
 1f80072:	mov    0x480(%rsp),%rcx
 1f8007a:	vinserti64x4 $0x1,0x340(%rdi,%rbp,1),%zmm0,%zmm13
 1f80083:	vmovdqu 0x380(%rdi,%rbp,1),%ymm0
 1f8008c:	vinserti64x4 $0x1,0x3c0(%rdi,%rbp,1),%zmm0,%zmm15
 1f80095:	vmovdqu8 (%rcx,%r14,1),%xmm3{%k1}{z}
 1f8009c:	vptestmb %xmm10,%xmm10,%k2
 1f800a2:	vpxor  %xmm0,%xmm0,%xmm0
 1f800a6:	vpcmpeqb %xmm7,%xmm3,%k3{%k2}
 1f800ac:	vmovdqu32 (%r12,%r14,4),%zmm1{%k3}{z}
 1f800b3:	kmovq  %k3,%k1
 1f800b8:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f800bf:	vptestnmd %zmm8,%zmm0,%k0
 1f800c5:	ktestw %k0,%k3
 1f800c9:	jne    1f80581 <node_facts_window_run+0x31b1>
 1f800cf:	vmovdqa64 -0x1ac9999(%rip),%zmm1        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f800d9:	kmovd  %k2,%edx
 1f800dd:	vpermt2d %zmm12,%zmm1,%zmm4
 1f800e3:	vpermt2d %zmm2,%zmm1,%zmm5
 1f800e9:	vpermt2d %zmm14,%zmm1,%zmm11
 1f800ef:	vpermt2d %zmm15,%zmm1,%zmm13
 1f800f5:	vshufi64x2 $0x44,%zmm13,%zmm11,%zmm2
 1f800fc:	vshufi64x2 $0x44,%zmm5,%zmm4,%zmm1
 1f80103:	vshufi64x2 $0xee,%zmm5,%zmm4,%zmm14
 1f8010a:	vshufi64x2 $0xee,%zmm13,%zmm11,%zmm13
 1f80111:	vshufi32x4 $0x88,%zmm2,%zmm1,%zmm4{%k2}{z}
 1f80118:	vshufi32x4 $0xdd,%zmm2,%zmm1,%zmm5{%k2}{z}
 1f8011f:	vshufi32x4 $0xdd,%zmm13,%zmm14,%zmm12{%k2}{z}
 1f80126:	vpsrld $0x19,%zmm4,%zmm1
 1f8012d:	vpandd -0x19af18f(%rip){1to16},%zmm1,%zmm1        # 5d0fa8 <.LCPI3_4>
 1f80137:	vpsrld $0x18,%zmm4,%zmm2
 1f8013e:	vpternlogd $0xec,%zmm6,%zmm1,%zmm2
 1f80145:	vpandd -0x19af15b(%rip){1to16},%zmm4,%zmm1        # 5d0ff4 <.LCPI3_71>
 1f8014f:	vpmovdb %zmm2,%xmm11
 1f80155:	vpbroadcastb -0x1ac939e(%rip),%xmm2        # 4b6dc0 <abi_test_hex.digits+0xba40>
 1f8015e:	vpcmpeqd -0x19af1b8(%rip){1to16},%zmm1,%k1{%k2}        # 5d0fb0 <.LCPI3_7>
 1f80168:	vpor   %xmm2,%xmm11,%xmm1
 1f8016c:	vpcmpeqb %xmm2,%xmm3,%k0{%k2}
 1f80172:	kmovd  %k0,%eax
 1f80176:	vmovdqu8 %xmm1,%xmm11{%k1}
 1f8017c:	vptestmd %zmm9,%zmm0,%k1
 1f80182:	korw   %k1,%k0,%k5
 1f80186:	vptestmd -0x19af1d8(%rip){1to16},%zmm0,%k0        # 5d0fb8 <.LCPI3_12>
 1f80190:	kmovd  %k0,%r13d
 1f80194:	test   %ax,%ax
 1f80197:	je     1f802f3 <node_facts_window_run+0x2f23>
 1f8019d:	vmovdqu64 %zmm13,0x320(%rsp)
 1f801a8:	vmovdqu64 %zmm14,0x1f0(%rsp)
 1f801b3:	vmovdqu64 %zmm5,0x360(%rsp)
 1f801be:	vmovdqu64 %zmm4,0x3a0(%rsp)
 1f801c9:	kmovw  %k5,0x260(%rsp)
 1f801d2:	vmovdqu64 %zmm12,0x2a0(%rsp)
 1f801dd:	mov    %edx,0x170(%rsp)
 1f801e4:	vmovdqa %xmm11,0x60(%rsp)
 1f801ea:	vmovdqa %xmm10,0x1b0(%rsp)
 1f801f3:	mov    %r14,0x70(%rsp)
 1f801f8:	lea    (%r15,%r14,4),%r14
 1f801fc:	movzwl %r13w,%r13d
 1f80200:	movzwl %ax,%ebx
 1f80203:	mov    0x8(%rsp),%r15
 1f80208:	nopl   0x0(%rax,%rax,1)
 1f80210:	xor    %r12d,%r12d
 1f80213:	tzcnt  %ebx,%r12d
 1f80218:	mov    %r15,%rdi
 1f8021b:	xor    %edx,%edx
 1f8021d:	mov    (%r14,%r12,4),%esi
 1f80221:	vzeroupper
 1f80224:	call   1f93850 <node_tests_window_line>
 1f80229:	mov    $0x1,%edx
 1f8022e:	xor    %ecx,%ecx
 1f80230:	test   $0x2,%al
 1f80232:	shlx   %r12d,%edx,%eax
 1f80237:	cmove  %ecx,%eax
 1f8023a:	or     %eax,%r13d
 1f8023d:	blsr   %ebx,%ebx
 1f80242:	jne    1f80210 <node_facts_window_run+0x2e40>
 1f80244:	vpbroadcastd -0x19af2a2(%rip),%zmm6        # 5d0fac <.LCPI3_5>
 1f8024e:	vpbroadcastb -0x1ac9495(%rip),%xmm7        # 4b6dc2 <abi_test_hex.digits+0xba42>
 1f80257:	vpbroadcastd -0x19af2ad(%rip),%zmm8        # 5d0fb4 <.LCPI3_11>
 1f80261:	vpbroadcastd -0x19af2af(%rip),%zmm9        # 5d0fbc <.LCPI3_13>
 1f8026b:	vmovdqa 0x1b0(%rsp),%xmm10
 1f80274:	vmovdqa 0x60(%rsp),%xmm11
 1f8027a:	vmovdqu64 0x2a0(%rsp),%zmm12
 1f80285:	vmovdqu64 0x3a0(%rsp),%zmm4
 1f80290:	vmovdqu64 0x360(%rsp),%zmm5
 1f8029b:	vmovdqu64 0x1f0(%rsp),%zmm14
 1f802a6:	vmovdqu64 0x320(%rsp),%zmm13
 1f802b1:	mov    (%rsp),%r11
 1f802b5:	mov    0x40(%rsp),%r9
 1f802ba:	mov    0x30(%rsp),%r10
 1f802bf:	mov    0x38(%rsp),%r12
 1f802c4:	mov    0x28(%rsp),%rsi
 1f802c9:	mov    0x18(%rsp),%rdi
 1f802ce:	mov    0x2e0(%rsp),%r15
 1f802d6:	mov    0x3e0(%rsp),%r8
 1f802de:	mov    0x70(%rsp),%r14
 1f802e3:	mov    0x170(%rsp),%edx
 1f802ea:	kmovw  0x260(%rsp),%k5
 1f802f3:	vpsrld $0x2,%zmm12,%zmm2
 1f802fa:	vpandd -0x19af344(%rip){1to16},%zmm2,%zmm2        # 5d0fc0 <.LCPI3_14>
 1f80304:	vptestmd -0x19af346(%rip){1to16},%zmm12,%k2        # 5d0fc8 <.LCPI3_16>
 1f8030e:	vshufi64x2 $0x88,%zmm13,%zmm14,%zmm0
 1f80315:	vptestnmb %xmm10,%xmm10,%k0
 1f8031b:	vpsrld $0x1a,%zmm4,%zmm1
 1f80322:	vpandd -0x19af334(%rip){1to16},%zmm4,%zmm4        # 5d0ff8 <.LCPI3_74>
 1f8032c:	kmovd  %r13d,%k3
 1f80331:	vpcmpneqd -0x19af378(%rip){1to16},%zmm2,%k1        # 5d0fc4 <.LCPI3_15>
 1f8033c:	vpaddd -0x19af376(%rip){1to16},%zmm4,%zmm4        # 5d0fd0 <.LCPI3_20>
 1f80346:	korw   %k1,%k2,%k1
 1f8034a:	vptestnmd %zmm0,%zmm0,%k2
 1f80350:	vpandd %zmm9,%zmm5,%zmm0
 1f80356:	korw   %k2,%k0,%k0
 1f8035a:	vptestmd -0x19af398(%rip){1to16},%zmm5,%k2        # 5d0fcc <.LCPI3_17>
 1f80364:	vpbroadcastd -0x19af39a(%rip),%zmm5        # 5d0fd4 <.LCPI3_21>
 1f8036e:	korw   %k1,%k0,%k1
 1f80372:	vptestnmd %zmm0,%zmm0,%k0
 1f80378:	kmovd  %k0,%eax
 1f8037c:	vptestmd %zmm2,%zmm2,%k1{%k1}
 1f80382:	vmovdqu8 -0x19b861c(%rip),%xmm3{%k1}{z}        # 5c7d70 <.LCPI3_8>
 1f8038c:	vpcmpeqd %zmm5,%zmm1,%k4
 1f80392:	vpcmpltud %zmm5,%zmm4,%k0
 1f80399:	korw   %k2,%k3,%k1
 1f8039d:	vpslld $0x1f,%zmm4,%zmm1
 1f803a4:	vpbroadcastb -0x1ac95e8(%rip),%xmm4        # 4b6dc5 <abi_test_hex.digits+0xba45>
 1f803ad:	vptestmb %xmm10,%xmm10,%k4{%k4}
 1f803b3:	kmovd  %k0,%ecx
 1f803b7:	and    %eax,%ecx
 1f803b9:	mov    %edx,%eax
 1f803bb:	and    %ecx,%eax
 1f803bd:	vmovdqu8 -0x19b8617(%rip),%xmm5{%k4}{z}        # 5c7db0 <.LCPI3_24>
 1f803c7:	kmovd  %eax,%k3
 1f803cb:	vpcmpeqd %zmm8,%zmm2,%k2{%k3}
 1f803d1:	vpxor  %xmm2,%xmm2,%xmm2
 1f803d5:	knotw  %k2,%k0
 1f803d9:	kmovd  %k0,%ecx
 1f803dd:	and    %eax,%ecx
 1f803df:	vmovdqu8 -0x19b8629(%rip),%xmm5{%k3}        # 5c7dc0 <.LCPI3_25>
 1f803e9:	kmovd  %ecx,%k3
 1f803ed:	vpcmpgtd %zmm1,%zmm2,%k3{%k3}
 1f803f3:	vpsrld $0x10,%zmm12,%zmm1
 1f803fa:	vpternlogd $0xff,%zmm2,%zmm2,%zmm2
 1f80401:	vpaddd %zmm2,%zmm1,%zmm2
 1f80407:	vmovdqu8 -0x19b8641(%rip),%xmm5{%k3}        # 5c7dd0 <.LCPI3_26>
 1f80411:	vptestnmd %zmm2,%zmm2,%k3
 1f80417:	vpblendmb -0x19b8631(%rip),%xmm4,%xmm4{%k3}        # 5c7df0 <.LCPI3_28>
 1f80421:	vpcmpnleud -0x19af454(%rip){1to16},%zmm2,%k3        # 5d0fd8 <.LCPI3_22>
 1f8042c:	mov    0x8(%rsp),%r13
 1f80431:	cmpb   $0x0,0xbf0(%r13)
 1f80439:	vmovdqu8 -0x19b8643(%rip),%xmm4{%k3}        # 5c7e00 <.LCPI3_29>
 1f80443:	vpcmpnleud -0x19af472(%rip){1to16},%zmm2,%k3        # 5d0fdc <.LCPI3_23>
 1f8044e:	vmovdqu8 -0x19b8648(%rip),%xmm4{%k3}        # 5c7e10 <.LCPI3_30>
 1f80458:	vptestmd %zmm0,%zmm0,%k3
 1f8045e:	vpor   %xmm7,%xmm3,%xmm0
 1f80462:	vmovdqu8 %xmm0,%xmm3{%k3}
 1f80468:	vmovdqu8 %xmm4,%xmm5{%k2}
 1f8046e:	vpor   %xmm5,%xmm3,%xmm0
 1f80472:	vpord  -0x19af480(%rip){1to4},%xmm0,%xmm3        # 5d0ffc <.LCPI3_77>
 1f8047c:	vmovdqu8 %xmm3,%xmm0{%k5}
 1f80482:	vpord  -0x19af488(%rip){1to4},%xmm0,%xmm3        # 5d1004 <.LCPI3_81>
 1f8048c:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f80492:	vpsrld $0xc,%zmm12,%zmm3
 1f80499:	vpmovdb %zmm3,%xmm3
 1f8049f:	vpternlogd $0xf8,-0x19af4a2(%rip){1to4},%xmm3,%xmm11        # 5d1008 <.LCPI3_82>
 1f804aa:	je     1f80577 <node_facts_window_run+0x31a7>
 1f804b0:	vmovdqa64 -0x1ac9cba(%rip),%zmm5        # 4b6800 <abi_test_hex.digits+0xb480>
 1f804ba:	vptestmd %zmm1,%zmm1,%k1{%k2}
 1f804c0:	add    %rdi,%rbp
 1f804c3:	vpxor  %xmm3,%xmm3,%xmm3
 1f804c7:	vpxor  %xmm4,%xmm4,%xmm4
 1f804cb:	vpcmpneqd -0x19af4ee(%rip){1to16},%zmm1,%k0{%k1}        # 5d0fe8 <.LCPI3_38>
 1f804d6:	vpor   %xmm0,%xmm11,%xmm1
 1f804da:	kmovq  %k1,%k2
 1f804df:	kmovw  %k1,%eax
 1f804e3:	popcnt %eax,%ecx
 1f804e7:	vpgatherdd 0x10(%rbp,%zmm5,1),%zmm3{%k2}
 1f804ef:	kmovq  %k1,%k2
 1f804f4:	vpcmpnleud -0x19af513(%rip){1to16},%zmm3,%k3        # 5d0fec <.LCPI3_39>
 1f804ff:	vpgatherdd 0x14(%rbp,%zmm5,1),%zmm4{%k2}
 1f80507:	add    %rcx,0x110(%rsp)
 1f8050f:	mov    0x10(%rsp),%rbx
 1f80514:	vpcmpeqd %zmm2,%zmm3,%k2
 1f8051a:	vptestnmd %zmm4,%zmm4,%k2{%k2}
 1f80520:	vptestmd %zmm4,%zmm4,%k4
 1f80526:	korw   %k4,%k3,%k3
 1f8052a:	kandw  %k2,%k0,%k2
 1f8052e:	knotw  %k0,%k0
 1f80532:	kandd  %k1,%k0,%k0
 1f80537:	kandw  %k0,%k3,%k0
 1f8053b:	korw   %k0,%k2,%k2
 1f8053f:	vptestnmd %zmm6,%zmm12,%k0{%k2}
 1f80545:	kandw  %k0,%k1,%k0
 1f80549:	kmovd  %k0,%ecx
 1f8054d:	vptestmb %xmm1,%xmm1,%k0
 1f80553:	andn   %eax,%ecx,%eax
 1f80558:	kmovd  %k0,%ecx
 1f8055c:	andn   %ecx,%edx,%ecx
 1f80561:	popcnt %eax,%eax
 1f80565:	movzwl %cx,%ecx
 1f80568:	add    %rax,%rbx
 1f8056b:	popcnt %ecx,%ecx
 1f8056f:	add    %rcx,%rbx
 1f80572:	mov    %rbx,0x10(%rsp)
 1f80577:	mov    0x20(%rsp),%rbp
 1f8057c:	jmp    1f7ff95 <node_facts_window_run+0x2bc5>
 1f80581:	vmovdqu64 %zmm1,0x580(%rsp)
 1f80589:	vmovdqu64 %zmm15,0x5c0(%rsp)
 1f80591:	vmovdqu64 %zmm14,0x600(%rsp)
 1f80599:	vmovdqu64 %zmm13,0x440(%rsp)
 1f805a1:	vmovdqu64 %zmm2,0x320(%rsp)
 1f805ac:	vmovdqu64 %zmm12,0x1f0(%rsp)
 1f805b7:	vmovdqu64 %zmm11,0x360(%rsp)
 1f805c2:	vmovdqa %xmm3,0x3a0(%rsp)
 1f805cb:	vmovdqu64 %zmm5,0x260(%rsp)
 1f805d6:	kmovw  %k2,0x2a0(%rsp)
 1f805df:	vmovdqu64 %zmm4,0x170(%rsp)
 1f805ea:	vmovdqa %xmm10,0x1b0(%rsp)
 1f805f3:	kmovw  %k3,0x4c0(%rsp)
 1f805fc:	mov    %r14,0x70(%rsp)
 1f80601:	kandw  %k0,%k3,%k0
 1f80605:	mov    0x48(%rsp),%r14
 1f8060a:	kmovd  %k0,%eax
 1f8060e:	movzwl %ax,%r13d
 1f80612:	xor    %eax,%eax
 1f80614:	tzcnt  %r13d,%eax
 1f80619:	add    0x70(%rsp),%rax
 1f8061e:	mov    0x60(%r11),%edx
 1f80622:	mov    0x20(%r11),%rcx
 1f80626:	mov    (%r12,%rax,4),%r8d
 1f8062a:	mov    (%r15,%rax,4),%esi
 1f8062e:	shl    $0x6,%rax
 1f80632:	mov    (%rdi,%rax,1),%eax
 1f80635:	mov    %r8,0x60(%rsp)
 1f8063a:	mov    0x8(%rsp),%rbx
 1f8063f:	shr    $0x3,%eax
 1f80642:	cmp    %edx,%eax
 1f80644:	cmovae %edx,%eax
 1f80647:	shl    $0x6,%rax
 1f8064b:	mov    0x30(%rcx,%rax,1),%edx
 1f8064f:	mov    0xba8(%rbx),%rax
 1f80656:	mov    %rbx,%rdi
 1f80659:	cmpb   $0x1,(%rax,%r8,1)
 1f8065e:	adc    $0x0,%r14
 1f80662:	and    $0x1,%edx
 1f80665:	vzeroupper
 1f80668:	call   1f93850 <node_tests_window_line>
 1f8066d:	mov    0x18(%rsp),%rdi
 1f80672:	mov    (%rsp),%r11
 1f80676:	mov    0xba8(%rbx),%rcx
 1f8067d:	mov    0x60(%rsp),%rdx
 1f80682:	or     $0x1,%al
 1f80684:	blsr   %r13d,%r13d
 1f80689:	mov    %al,(%rcx,%rdx,1)
 1f8068c:	jne    1f80612 <node_facts_window_run+0x3242>
 1f8068e:	mov    %r14,0x48(%rsp)
 1f80693:	vpbroadcastd -0x19af6f1(%rip),%zmm6        # 5d0fac <.LCPI3_5>
 1f8069d:	vpbroadcastb -0x1ac98e4(%rip),%xmm7        # 4b6dc2 <abi_test_hex.digits+0xba42>
 1f806a6:	vpbroadcastd -0x19af6fc(%rip),%zmm8        # 5d0fb4 <.LCPI3_11>
 1f806b0:	vpbroadcastd -0x19af6fe(%rip),%zmm9        # 5d0fbc <.LCPI3_13>
 1f806ba:	vpxor  %xmm0,%xmm0,%xmm0
 1f806be:	mov    0x8(%rsp),%rax
 1f806c3:	vmovdqu64 0x580(%rsp),%zmm1
 1f806cb:	kmovw  0x4c0(%rsp),%k1
 1f806d4:	vmovdqa 0x1b0(%rsp),%xmm10
 1f806dd:	vmovdqu64 0x170(%rsp),%zmm4
 1f806e8:	vmovdqu64 0x260(%rsp),%zmm5
 1f806f3:	vmovdqa 0x3a0(%rsp),%xmm3
 1f806fc:	vmovdqu64 0x360(%rsp),%zmm11
 1f80707:	vmovdqu64 0x1f0(%rsp),%zmm12
 1f80712:	vmovdqu64 0x320(%rsp),%zmm2
 1f8071d:	vmovdqu64 0x440(%rsp),%zmm13
 1f80725:	vmovdqu64 0x600(%rsp),%zmm14
 1f8072d:	vmovdqu64 0x5c0(%rsp),%zmm15
 1f80735:	mov    0x40(%rsp),%r9
 1f8073a:	mov    0x30(%rsp),%r10
 1f8073f:	mov    0x28(%rsp),%rsi
 1f80744:	mov    0x3e0(%rsp),%r8
 1f8074c:	mov    0x70(%rsp),%r14
 1f80751:	kmovw  0x2a0(%rsp),%k2
 1f8075a:	mov    0xba8(%rax),%rax
 1f80761:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f80768:	jmp    1f800cf <node_facts_window_run+0x2cff>
 1f8076d:	movq   $0x0,0x48(%rsp)
 1f80776:	movq   $0x0,0x110(%rsp)
 1f80782:	movq   $0x0,0x10(%rsp)
 1f8078b:	mov    0x48(%rsp),%rax
 1f80790:	mov    0x110(%rsp),%rcx
 1f80798:	lea    0x7e8(%r9),%rsi
 1f8079f:	add    %rax,0xa90(%r9)
 1f807a6:	mov    0xb30(%r13),%rax
 1f807ad:	add    %rcx,0x868(%rax)
 1f807b4:	mov    0x10(%rsp),%rcx
 1f807b9:	mov    0xb30(%r13),%rax
 1f807c0:	add    %rcx,0x870(%rax)
 1f807c7:	rdtsc
 1f807c9:	mov    0x8(%rbp),%ecx
 1f807cc:	cmpq   $0x0,0xc20(%r11)
 1f807d4:	mov    %rax,0x88(%rsp)
 1f807dc:	mov    %rdx,0x770(%rsp)
 1f807e4:	je     1f80ebe <node_facts_window_run+0x3aee>
 1f807ea:	cmpb   $0x1,0xd58(%r11)
 1f807f2:	jne    1f80ebe <node_facts_window_run+0x3aee>
 1f807f8:	mov    0xb30(%r13),%rdx
 1f807ff:	cmpq   $0x0,0x1a0(%rdx)
 1f80807:	sete   %dl
 1f8080a:	test   %rcx,%rcx
 1f8080d:	je     1f81537 <node_facts_window_run+0x4167>
 1f80813:	vpbroadcastb %edx,%zmm1
 1f80819:	vgf2p8affineqb $0x0,-0x19b2264(%rip){1to8},%zmm1,%zmm1        # 5ce5c0 <.LCPI3_83>
 1f80824:	vmovdqu64 0x2c0(%r13),%zmm0
 1f8082b:	vbroadcasti32x4 -0x19b89a5(%rip),%zmm2        # 5c7e90 <.LCPI3_84>
 1f80835:	vmovdqa64 -0x1ac9f3f(%rip),%zmm5        # 4b6900 <abi_test_hex.digits+0xb580>
 1f8083f:	vbroadcasti32x4 -0x19b89a9(%rip),%zmm6        # 5c7ea0 <.LCPI3_85>
 1f80849:	vbroadcasti32x4 -0x19b89a3(%rip),%zmm13        # 5c7eb0 <.LCPI3_86>
 1f80853:	vbroadcasti32x4 -0x19b899d(%rip),%zmm14        # 5c7ec0 <.LCPI3_87>
 1f8085d:	vbroadcasti32x4 -0x19b8ae7(%rip),%zmm16        # 5c7d80 <.LCPI3_9>
 1f80867:	vbroadcasti32x4 -0x19b8ac1(%rip),%zmm19        # 5c7db0 <.LCPI3_24>
 1f80871:	vbroadcasti32x4 -0x19b89ab(%rip),%zmm20        # 5c7ed0 <.LCPI3_88>
 1f8087b:	vbroadcasti32x4 -0x19b89a5(%rip),%zmm22        # 5c7ee0 <.LCPI3_89>
 1f80885:	vmovdqa64 -0x1ac9bcf(%rip),%zmm23        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f8088f:	vmovdqa64 -0x1ac9b99(%rip),%zmm24        # 4b6d00 <abi_test_hex.digits+0xb980>
 1f80899:	mov    %rsi,0x18(%rsp)
 1f8089e:	movzbl 0x500(%r13),%esi
 1f808a6:	mov    0xd60(%r11),%rax
 1f808ad:	mov    0xd78(%r11),%r8
 1f808b4:	xor    %r9d,%r9d
 1f808b7:	vpxord %xmm21,%xmm21,%xmm21
 1f808bd:	vpxord %xmm25,%xmm25,%xmm25
 1f808c3:	vpxor  %xmm8,%xmm8,%xmm8
 1f808c8:	vpxord %xmm30,%xmm30,%xmm30
 1f808ce:	vpxord %xmm17,%xmm17,%xmm17
 1f808d4:	xor    %edx,%edx
 1f808d6:	neg    %rsi
 1f808d9:	mov    %rax,0x10(%rsp)
 1f808de:	movq   $0x0,0x28(%rsp)
 1f808e7:	nopw   0x0(%rax,%rax,1)
 1f808f0:	vmovdqu64 0x2c(%rbp,%r9,1),%zmm3
 1f808fb:	mov    0xb70(%r13),%r10
 1f80902:	vmovdqa64 0xc0(%r13),%zmm28
 1f80909:	vmovdqa64 0x140(%r13),%zmm10
 1f80910:	vmovdqa64 0x1c0(%r13),%zmm9
 1f80917:	vmovdqa64 0x240(%r13),%zmm11
 1f8091e:	vmovdqa64 0x380(%r13),%zmm18
 1f80925:	vmovdqa64 0x400(%r13),%zmm31
 1f8092c:	vmovdqa64 %zmm17,%zmm29
 1f80932:	vmovdqa64 %zmm21,%zmm17
 1f80938:	vmovdqa64 0x300(%r13),%zmm21
 1f8093f:	vmovdqa64 %zmm25,%zmm4
 1f80945:	vmovdqa64 %zmm4,%zmm27
 1f8094b:	mov    0x10(%rsp),%rax
 1f80950:	vpermt2b 0x100(%r13),%zmm3,%zmm28
 1f80957:	vpermt2b 0x280(%r13),%zmm3,%zmm11
 1f8095e:	vpandq %zmm2,%zmm3,%zmm7
 1f80964:	vpermt2b 0x180(%r13),%zmm3,%zmm10
 1f8096b:	vpermt2b 0x200(%r13),%zmm3,%zmm9
 1f80972:	vpermt2b 0x340(%r13),%zmm3,%zmm21
 1f80979:	vpermt2b 0x3c0(%r13),%zmm3,%zmm18
 1f80980:	vpermt2b 0x440(%r13),%zmm3,%zmm31
 1f80987:	vmovdqu64 (%r10,%r9,1),%zmm3
 1f8098e:	mov    0xb78(%r13),%r10
 1f80995:	vgf2p8affineqb $0x0,-0x19b23d8(%rip){1to8},%zmm3,%zmm25        # 5ce5c8 <.LCPI3_90>
 1f809a0:	vmovdqu64 (%r10,%r9,1),%zmm26
 1f809a7:	mov    0xb80(%r13),%r10
 1f809ae:	vpandq -0x19b2418(%rip){1to8},%zmm26,%zmm12        # 5ce5a0 <.LCPI3_42>
 1f809b8:	vpmovb2m %zmm28,%k0
 1f809be:	kmovq  %k0,%r11
 1f809c3:	vpternlogq $0xfe,%zmm10,%zmm12,%zmm25
 1f809ca:	vmovdqu64 %zmm25,(%r10,%r9,1)
 1f809d1:	vmovdqu64 0x6b554(%rbp,%r9,2),%zmm10
 1f809dc:	vmovdqu64 0x6b594(%rbp,%r9,2),%zmm12
 1f809e7:	vmovdqu64 0x6d5d4(%rbp,%r9,2),%zmm15
 1f809f2:	vpmovuswb %zmm10,%ymm10
 1f809f8:	vpmovuswb %zmm12,%ymm12
 1f809fe:	vinserti64x4 $0x1,%ymm12,%zmm10,%zmm10
 1f80a05:	vpmovuswb %zmm15,%ymm12
 1f80a0b:	vmovdqu64 0x6d614(%rbp,%r9,2),%zmm15
 1f80a16:	vptestmb %zmm10,%zmm10,%k1
 1f80a1c:	vpcmpltub %zmm10,%zmm5,%k4{%k1}
 1f80a23:	kmovq  %k1,%r10
 1f80a28:	vpcmpnltub %zmm10,%zmm5,%k1
 1f80a2f:	vpsubb %zmm10,%zmm5,%zmm10
 1f80a35:	kmovq  %k1,%r14
 1f80a3a:	and    %r10,%r14
 1f80a3d:	mov    0xb88(%r13),%r10
 1f80a44:	kmovq  %r14,%k1
 1f80a49:	vpermt2b %zmm25,%zmm10,%zmm27{%k1}{z}
 1f80a4f:	vpermt2b %zmm21,%zmm10,%zmm17{%k1}{z}
 1f80a55:	knotq  %k1,%k6
 1f80a5a:	vpmovuswb %zmm15,%ymm15
 1f80a60:	vptestmb %zmm18,%zmm17,%k5
 1f80a66:	kmovq  %k5,%rbx
 1f80a6b:	vinserti64x4 $0x1,%ymm15,%zmm12,%zmm15
 1f80a72:	vptestmb %zmm15,%zmm15,%k2
 1f80a78:	vpsubb %zmm15,%zmm5,%zmm12
 1f80a7e:	vpcmpltub %zmm15,%zmm5,%k3{%k2}
 1f80a85:	vpcmpnltub %zmm15,%zmm5,%k2{%k2}
 1f80a8c:	vpermt2b %zmm25,%zmm12,%zmm4{%k2}{z}
 1f80a92:	vporq  %zmm27,%zmm4,%zmm15
 1f80a98:	vmovdqu64 %zmm15,(%r10,%r9,1)
 1f80a9f:	mov    %r9,%r10
 1f80aa2:	shr    $0x3,%r10
 1f80aa6:	kortestq %k4,%k3
 1f80aab:	vpandq (%rax,%r9,1),%zmm1,%zmm17
 1f80ab2:	vpermt2b %zmm17,%zmm10,%zmm29
 1f80ab8:	vptestnmb %zmm29,%zmm29,%k5
 1f80abe:	korq   %k5,%k6,%k5
 1f80ac3:	vpcmpeqb %zmm6,%zmm7,%k5{%k5}
 1f80ac9:	kmovq  %k5,(%r8,%r10,1)
 1f80acf:	jne    1f80d52 <node_facts_window_run+0x3982>
 1f80ad5:	vmovdqa64 %zmm8,%zmm18
 1f80adb:	vpermi2b %zmm26,%zmm8,%zmm12{%k2}{z}
 1f80ae1:	vpermt2b %zmm26,%zmm10,%zmm18{%k1}{z}
 1f80ae7:	vpternlogq $0xe0,%zmm2,%zmm26,%zmm11
 1f80aee:	vpcmpeqb %zmm6,%zmm7,%k4
 1f80af4:	vpcmpeqb %zmm20,%zmm7,%k5
 1f80afa:	mov    0x8(%rsp),%rdi
 1f80aff:	vpternlogq $0x80,%zmm28,%zmm4,%zmm27
 1f80b06:	kmovq  %k4,%rax
 1f80b0b:	and    %rsi,%rax
 1f80b0e:	vpsrlw $0x3,%zmm18,%zmm8
 1f80b15:	vpternlogq $0xe4,-0x19b2570(%rip){1to8},%zmm12,%zmm8        # 5ce5b0 <.LCPI3_50>
 1f80b20:	mov    0xb90(%rdi),%r13
 1f80b27:	mov    0x8(%rsp),%rdi
 1f80b2c:	vpermb %zmm0,%zmm8,%zmm8
 1f80b32:	vptestmb %zmm8,%zmm11,%k2
 1f80b38:	vpandq %zmm13,%zmm18,%zmm8
 1f80b3e:	vpandd -0x19afb44(%rip){1to16},%zmm3,%zmm11        # 5d1004 <.LCPI3_81>
 1f80b48:	vpcmpeqb %zmm14,%zmm8,%k3
 1f80b4e:	vpandq %zmm15,%zmm9,%zmm8
 1f80b54:	kmovq  %k2,%r12
 1f80b59:	vpcmpeqb -0x1aca123(%rip),%zmm8,%k2        # 4b6a40 <abi_test_hex.digits+0xb6c0>
 1f80b63:	vpandq %zmm13,%zmm12,%zmm9
 1f80b69:	vgf2p8affineqb $0x0,-0x19b25a4(%rip){1to8},%zmm26,%zmm12        # 5ce5d0 <.LCPI3_91>
 1f80b74:	vptestmb %zmm8,%zmm8,%k4
 1f80b7a:	korq   %k4,%k0,%k0
 1f80b7f:	kmovq  %k2,%rbp
 1f80b84:	vpcmpeqb %zmm14,%zmm9,%k2
 1f80b8a:	vpandd -0x19afb98(%rip){1to16},%zmm18,%zmm9        # 5d0ffc <.LCPI3_77>
 1f80b94:	korq   %k2,%k3,%k2
 1f80b99:	vpcmpeqb -0x1aca0a3(%rip),%zmm7,%k2{%k2}        # 4b6b00 <abi_test_hex.digits+0xb780>
 1f80ba3:	vpternlogq $0xfe,%zmm9,%zmm8,%zmm11
 1f80baa:	vpsllw $0x7,%zmm3,%zmm9
 1f80bb1:	knotq  %k2,%k2
 1f80bb6:	kmovq  %k2,%r15
 1f80bbb:	vptestmb %zmm16,%zmm3,%k2
 1f80bc1:	kmovq  %k2,%r10
 1f80bc6:	vptestnmb %zmm11,%zmm11,%k2
 1f80bcc:	vpandd -0x19afbca(%rip){1to16},%zmm28,%zmm11        # 5d100c <.LCPI3_92>
 1f80bd6:	and    %r10,%rax
 1f80bd9:	kmovq  %k2,%r10
 1f80bde:	vpmovb2m %zmm9,%k2
 1f80be4:	vpbroadcastw %r9d,%zmm9
 1f80bea:	and    %rax,%r10
 1f80bed:	and    %r14,%r10
 1f80bf0:	kmovq  %r10,%k3
 1f80bf5:	vpmovm2b %k3,%zmm7
 1f80bfb:	vptestmb %zmm22,%zmm3,%k3{%k4}
 1f80c01:	vpternlogq $0xe0,-0x19b2664(%rip){1to8},%zmm28,%zmm3        # 5ce5a8 <.LCPI3_47>
 1f80c0c:	vpermt2b %zmm7,%zmm10,%zmm30
 1f80c12:	vporq  %zmm24,%zmm9,%zmm10
 1f80c18:	vporq  %zmm23,%zmm9,%zmm9
 1f80c1e:	vgf2p8affineqb $0x0,-0x19b2651(%rip){1to8},%zmm3,%zmm3        # 5ce5d8 <.LCPI3_93>
 1f80c29:	vptestmb %zmm30,%zmm30,%k1{%k1}
 1f80c2f:	kandq  %k3,%k5,%k3
 1f80c34:	kandq  %k2,%k5,%k5
 1f80c39:	vmovdqa64 %zmm7,%zmm30
 1f80c3f:	kandq  %k1,%k5,%k1
 1f80c44:	vpternlogq $0xfe,%zmm3,%zmm11,%zmm12
 1f80c4b:	vpcompressw %zmm9,%zmm9{%k1}{z}
 1f80c51:	kmovd  %k1,%eax
 1f80c55:	kshiftrq $0x20,%k1,%k5
 1f80c5b:	vptestmb %zmm15,%zmm31,%k1
 1f80c61:	vmovdqu64 %zmm12,0x0(%r13,%r9,1)
 1f80c69:	vpcompressw %zmm10,%zmm10{%k5}{z}
 1f80c6f:	kmovd  %k5,%r14d
 1f80c73:	mov    0xba0(%rdi),%r13
 1f80c7a:	mov    %edx,%edi
 1f80c7c:	vmovdqu64 %zmm9,0x0(%r13,%rdi,2)
 1f80c84:	popcnt %eax,%r13d
 1f80c89:	kmovq  %k0,%rdi
 1f80c8e:	vptestmb %zmm19,%zmm28,%k0
 1f80c94:	add    %edx,%r13d
 1f80c97:	mov    0x8(%rsp),%rdx
 1f80c9c:	mov    0xba0(%rdx),%rax
 1f80ca3:	andn   %rbp,%r11,%rdx
 1f80ca8:	mov    0x20(%rsp),%rbp
 1f80cad:	and    %r12,%rdx
 1f80cb0:	mov    0x8(%rsp),%r12
 1f80cb5:	and    %rdx,%r15
 1f80cb8:	kmovq  %k3,%rdx
 1f80cbd:	vmovdqu64 %zmm10,(%rax,%r13,2)
 1f80cc4:	kmovq  %k1,%rax
 1f80cc9:	vpcmpeqb %zmm16,%zmm8,%k1
 1f80ccf:	vmovdqa64 %zmm26,%zmm8
 1f80cd5:	vptestmb %zmm16,%zmm27,%k1{%k1}
 1f80cdb:	mov    0xb98(%r12),%r12
 1f80ce3:	or     %rbx,%rax
 1f80ce6:	kmovq  %k1,%r11
 1f80ceb:	mov    %rax,0x8(%r12,%r9,1)
 1f80cf0:	or     %rdx,%r11
 1f80cf3:	popcnt %r14d,%edx
 1f80cf8:	or     %r10,%r11
 1f80cfb:	add    %r13d,%edx
 1f80cfe:	mov    0x8(%rsp),%r13
 1f80d03:	or     %r15,%r11
 1f80d06:	andn   %rdi,%r11,%rax
 1f80d0b:	mov    %r11,(%r12,%r9,1)
 1f80d0f:	mov    %rax,0x10(%r12,%r9,1)
 1f80d14:	kmovq  %k0,0x18(%r12,%r9,1)
 1f80d1b:	korq   %k2,%k0,%k0
 1f80d20:	kmovq  %k0,%rax
 1f80d25:	or     %r10,%rax
 1f80d28:	mov    %rax,0x20(%r12,%r9,1)
 1f80d2d:	mov    %r10,0x28(%r12,%r9,1)
 1f80d32:	kmovq  %k3,0x30(%r12,%r9,1)
 1f80d39:	kmovq  %k1,0x38(%r12,%r9,1)
 1f80d40:	add    $0x40,%r9
 1f80d44:	cmp    %rcx,%r9
 1f80d47:	jb     1f808f0 <node_facts_window_run+0x3520>
 1f80d4d:	jmp    1f8161b <node_facts_window_run+0x424b>
 1f80d52:	kmovq  %k4,%rax
 1f80d57:	mov    %rax,0x70(%rsp)
 1f80d5c:	mov    %rax,%rbp
 1f80d5f:	mov    0x20(%rsp),%rdi
 1f80d64:	test   %rax,%rax
 1f80d67:	je     1f80e39 <node_facts_window_run+0x3a69>
 1f80d6d:	xor    %eax,%eax
 1f80d6f:	tzcnt  %rbp,%rax
 1f80d74:	lea    (%rax,%r9,1),%r12
 1f80d78:	mov    %rax,0x38(%rsp)
 1f80d7d:	mov    %r12d,%r10d
 1f80d80:	movzwl 0x6b554(%rdi,%r10,2),%eax
 1f80d89:	mov    %r12,0x110(%rsp)
 1f80d91:	mov    0x8(%rsp),%r15
 1f80d96:	sub    %eax,%r12d
 1f80d99:	mov    0xb80(%r13),%rax
 1f80da0:	mov    0xb88(%r15),%r13
 1f80da7:	mov    0x8(%rsp),%r15
 1f80dac:	movzbl (%rax,%r12,1),%eax
 1f80db1:	or     %al,0x0(%r13,%r10,1)
 1f80db6:	movzbl 0x2c(%rdi,%r10,1),%eax
 1f80dbc:	movzbl 0x2c(%rdi,%r12,1),%r10d
 1f80dc2:	mov    0x8(%rsp),%rdi
 1f80dc7:	and    $0x7f,%r10d
 1f80dcb:	and    $0x7f,%eax
 1f80dce:	movzbl 0x300(%r15,%r10,1),%r13d
 1f80dd7:	xor    %r15d,%r15d
 1f80dda:	test   %r13b,0x380(%rdi,%rax,1)
 1f80de2:	mov    0x38(%rsp),%rax
 1f80de7:	mov    0x8(%rsp),%r13
 1f80dec:	mov    0x20(%rsp),%rdi
 1f80df1:	setne  %r15b
 1f80df5:	shlx   %rax,%r15,%rax
 1f80dfa:	mov    0xb98(%r13),%r15
 1f80e01:	or     %rax,%rbx
 1f80e04:	cmp    0x110(%rsp),%ecx
 1f80e0b:	seta   %al
 1f80e0e:	cmp    $0x22,%r10
 1f80e12:	sete   %r10b
 1f80e16:	and    %al,%r10b
 1f80e19:	movzbl %r10b,%eax
 1f80e1d:	shlx   %r12,%rax,%rax
 1f80e22:	and    $0xffffffc0,%r12d
 1f80e26:	not    %rax
 1f80e29:	and    %rax,0x20(%r15,%r12,1)
 1f80e2e:	blsr   %rbp,%rbp
 1f80e33:	jne    1f80d6d <node_facts_window_run+0x399d>
 1f80e39:	kmovq  %k3,%r15
 1f80e3e:	mov    %r15,%r12
 1f80e41:	test   %r15,%r15
 1f80e44:	je     1f80e92 <node_facts_window_run+0x3ac2>
 1f80e46:	mov    0x8(%rsp),%r13
 1f80e4b:	xor    %eax,%eax
 1f80e4d:	tzcnt  %r12,%rax
 1f80e52:	or     %r9,%rax
 1f80e55:	mov    %eax,%r10d
 1f80e58:	movzwl 0x6d5d4(%rdi,%r10,2),%ebp
 1f80e61:	mov    0x8(%rsp),%rdi
 1f80e66:	mov    0xb80(%r13),%r13
 1f80e6d:	sub    %ebp,%eax
 1f80e6f:	mov    0xb88(%rdi),%rbp
 1f80e76:	mov    0x20(%rsp),%rdi
 1f80e7b:	movzbl 0x0(%r13,%rax,1),%eax
 1f80e81:	mov    0x8(%rsp),%r13
 1f80e86:	or     %al,0x0(%rbp,%r10,1)
 1f80e8b:	blsr   %r12,%r12
 1f80e90:	jne    1f80e46 <node_facts_window_run+0x3a76>
 1f80e92:	mov    0xb88(%r13),%rdi
 1f80e99:	popcnt 0x70(%rsp),%rax
 1f80ea0:	popcnt %r15,%r10
 1f80ea5:	add    0x28(%rsp),%rax
 1f80eaa:	vmovdqu64 (%rdi,%r9,1),%zmm15
 1f80eb1:	add    %r10,%rax
 1f80eb4:	mov    %rax,0x28(%rsp)
 1f80eb9:	jmp    1f80ad5 <node_facts_window_run+0x3705>
 1f80ebe:	test   %rcx,%rcx
 1f80ec1:	je     1f81537 <node_facts_window_run+0x4167>
 1f80ec7:	vmovdqu64 0x2c0(%r13),%zmm0
 1f80ece:	vbroadcasti32x4 -0x19b9048(%rip),%zmm1        # 5c7e90 <.LCPI3_84>
 1f80ed8:	vmovdqa64 -0x1aca5e2(%rip),%zmm4        # 4b6900 <abi_test_hex.digits+0xb580>
 1f80ee2:	vbroadcasti32x4 -0x19b903c(%rip),%zmm11        # 5c7eb0 <.LCPI3_86>
 1f80eec:	vbroadcasti32x4 -0x19b9036(%rip),%zmm12        # 5c7ec0 <.LCPI3_87>
 1f80ef6:	vbroadcasti32x4 -0x19b9060(%rip),%zmm14        # 5c7ea0 <.LCPI3_85>
 1f80f00:	vbroadcasti32x4 -0x19b918a(%rip),%zmm15        # 5c7d80 <.LCPI3_9>
 1f80f0a:	vbroadcasti32x4 -0x19b90f4(%rip),%zmm16        # 5c7e20 <.LCPI3_31>
 1f80f14:	vbroadcasti32x4 -0x19b917e(%rip),%zmm17        # 5c7da0 <.LCPI3_18>
 1f80f1e:	vbroadcasti32x4 -0x19b9178(%rip),%zmm18        # 5c7db0 <.LCPI3_24>
 1f80f28:	vbroadcasti32x4 -0x19b9062(%rip),%zmm20        # 5c7ed0 <.LCPI3_88>
 1f80f32:	vbroadcasti32x4 -0x19b905c(%rip),%zmm21        # 5c7ee0 <.LCPI3_89>
 1f80f3c:	vmovdqa64 -0x1aca286(%rip),%zmm22        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f80f46:	vmovdqa64 -0x1aca250(%rip),%zmm23        # 4b6d00 <abi_test_hex.digits+0xb980>
 1f80f50:	mov    %rsi,0x18(%rsp)
 1f80f55:	movzbl 0x500(%r13),%esi
 1f80f5d:	xor    %edx,%edx
 1f80f5f:	vpxor  %xmm10,%xmm10,%xmm10
 1f80f64:	vpxord %xmm24,%xmm24,%xmm24
 1f80f6a:	xor    %edi,%edi
 1f80f6c:	vpxord %xmm25,%xmm25,%xmm25
 1f80f72:	vpxord %xmm29,%xmm29,%xmm29
 1f80f78:	movq   $0x0,0x10(%rsp)
 1f80f81:	neg    %rsi
 1f80f84:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f80f90:	vmovdqu64 0x2c(%rbp,%rdi,1),%zmm3
 1f80f9b:	mov    0xb70(%r13),%rax
 1f80fa2:	mov    0xb78(%r13),%r8
 1f80fa9:	vmovdqa64 0xc0(%r13),%zmm27
 1f80fb0:	vmovdqa64 0x140(%r13),%zmm6
 1f80fb7:	vmovdqa64 0x1c0(%r13),%zmm5
 1f80fbe:	vmovdqa64 0x240(%r13),%zmm7
 1f80fc5:	vmovdqa64 0x380(%r13),%zmm13
 1f80fcc:	vmovdqa64 0x400(%r13),%zmm28
 1f80fd3:	vmovdqa64 %zmm10,%zmm19
 1f80fd9:	vmovdqa64 0x300(%r13),%zmm10
 1f80fe0:	vmovdqa64 %zmm24,%zmm26
 1f80fe6:	vmovdqa64 %zmm26,%zmm31
 1f80fec:	vmovdqu64 (%rax,%rdi,1),%zmm30
 1f80ff3:	mov    0xb80(%r13),%rax
 1f80ffa:	vgf2p8affineqb $0x0,-0x19b2a3d(%rip){1to8},%zmm30,%zmm24        # 5ce5c8 <.LCPI3_90>
 1f81005:	vpermt2b 0x100(%r13),%zmm3,%zmm27
 1f8100c:	vpandq %zmm1,%zmm3,%zmm2
 1f81012:	vpermt2b 0x280(%r13),%zmm3,%zmm7
 1f81019:	vpermt2b 0x180(%r13),%zmm3,%zmm6
 1f81020:	vpermt2b 0x200(%r13),%zmm3,%zmm5
 1f81027:	vpermt2b 0x340(%r13),%zmm3,%zmm10
 1f8102e:	vpermt2b 0x3c0(%r13),%zmm3,%zmm13
 1f81035:	vpermt2b 0x440(%r13),%zmm3,%zmm28
 1f8103c:	vmovdqu64 (%r8,%rdi,1),%zmm3
 1f81043:	vpandq -0x19b2aad(%rip){1to8},%zmm3,%zmm8        # 5ce5a0 <.LCPI3_42>
 1f8104d:	vpmovb2m %zmm27,%k0
 1f81053:	vpternlogq $0xfe,%zmm6,%zmm8,%zmm24
 1f8105a:	kmovq  %k0,%r9
 1f8105f:	vmovdqu64 %zmm24,(%rax,%rdi,1)
 1f81066:	vmovdqu64 0x6b554(%rbp,%rdi,2),%zmm6
 1f81071:	vmovdqu64 0x6b594(%rbp,%rdi,2),%zmm8
 1f8107c:	vmovdqu64 0x6d5d4(%rbp,%rdi,2),%zmm9
 1f81087:	vpmovuswb %zmm6,%ymm6
 1f8108d:	vpmovuswb %zmm8,%ymm8
 1f81093:	vinserti64x4 $0x1,%ymm8,%zmm6,%zmm6
 1f8109a:	vpmovuswb %zmm9,%ymm8
 1f810a0:	vmovdqu64 0x6d614(%rbp,%rdi,2),%zmm9
 1f810ab:	vptestmb %zmm6,%zmm6,%k1
 1f810b1:	vpcmpltub %zmm6,%zmm4,%k4{%k1}
 1f810b8:	kmovq  %k1,%rax
 1f810bd:	vpcmpnltub %zmm6,%zmm4,%k1
 1f810c4:	vpsubb %zmm6,%zmm4,%zmm6
 1f810ca:	kmovq  %k1,%r11
 1f810cf:	and    %rax,%r11
 1f810d2:	mov    0xb88(%r13),%rax
 1f810d9:	kmovq  %r11,%k1
 1f810de:	vpermt2b %zmm10,%zmm6,%zmm19{%k1}{z}
 1f810e4:	vpermt2b %zmm24,%zmm6,%zmm31{%k1}{z}
 1f810ea:	vpmovuswb %zmm9,%ymm9
 1f810f0:	vptestmb %zmm13,%zmm19,%k5
 1f810f6:	kmovq  %k5,%r10
 1f810fb:	vinserti64x4 $0x1,%ymm9,%zmm8,%zmm9
 1f81102:	vptestmb %zmm9,%zmm9,%k2
 1f81108:	vpsubb %zmm9,%zmm4,%zmm8
 1f8110e:	vpcmpltub %zmm9,%zmm4,%k3{%k2}
 1f81115:	vpcmpnltub %zmm9,%zmm4,%k2{%k2}
 1f8111c:	vpermt2b %zmm24,%zmm8,%zmm26{%k2}{z}
 1f81122:	kortestq %k4,%k3
 1f81127:	vporq  %zmm31,%zmm26,%zmm9
 1f8112d:	vmovdqu64 %zmm9,(%rax,%rdi,1)
 1f81134:	jne    1f81398 <node_facts_window_run+0x3fc8>
 1f8113a:	vpermi2b %zmm3,%zmm25,%zmm8{%k2}{z}
 1f81140:	vpermt2b %zmm3,%zmm6,%zmm25{%k1}{z}
 1f81146:	vpternlogq $0xe0,%zmm1,%zmm3,%zmm7
 1f8114d:	vpandq %zmm9,%zmm5,%zmm5
 1f81153:	vpcmpeqb %zmm20,%zmm2,%k5
 1f81159:	vgf2p8affineqb $0x0,-0x19b2b94(%rip){1to8},%zmm3,%zmm19        # 5ce5d0 <.LCPI3_91>
 1f81164:	vpternlogq $0x80,%zmm27,%zmm26,%zmm31
 1f8116b:	vptestmb %zmm5,%zmm5,%k4
 1f81171:	korq   %k4,%k0,%k0
 1f81176:	vpsrlw $0x3,%zmm25,%zmm13
 1f8117d:	vpternlogq $0xe4,-0x19b2bd8(%rip){1to8},%zmm8,%zmm13        # 5ce5b0 <.LCPI3_50>
 1f81188:	vpermb %zmm0,%zmm13,%zmm13
 1f8118e:	vptestmb %zmm13,%zmm7,%k2
 1f81194:	vpandq %zmm11,%zmm25,%zmm7
 1f8119a:	kmovq  %k2,%r14
 1f8119f:	vpcmpeqb -0x1aca769(%rip),%zmm5,%k2        # 4b6a40 <abi_test_hex.digits+0xb6c0>
 1f811a9:	vpcmpeqb %zmm12,%zmm7,%k3
 1f811af:	vpandq %zmm11,%zmm8,%zmm7
 1f811b5:	vpandq %zmm17,%zmm30,%zmm8
 1f811bb:	kmovq  %k2,%r15
 1f811c0:	vpcmpeqb %zmm12,%zmm7,%k2
 1f811c6:	vpandq %zmm16,%zmm25,%zmm7
 1f811cc:	vmovdqa64 %zmm3,%zmm25
 1f811d2:	korq   %k2,%k3,%k2
 1f811d7:	vpcmpeqb -0x1aca6e1(%rip),%zmm2,%k2{%k2}        # 4b6b00 <abi_test_hex.digits+0xb780>
 1f811e1:	vpternlogq $0xfe,%zmm7,%zmm5,%zmm8
 1f811e8:	vpsllw $0x7,%zmm30,%zmm7
 1f811ef:	knotq  %k2,%k2
 1f811f4:	kmovq  %k2,%rbx
 1f811f9:	vpcmpeqb %zmm14,%zmm2,%k2
 1f811ff:	kmovq  %k2,%rax
 1f81204:	vptestmb %zmm15,%zmm30,%k2
 1f8120a:	kmovq  %k2,%r8
 1f8120f:	and    %rsi,%rax
 1f81212:	vptestnmb %zmm8,%zmm8,%k2
 1f81218:	vpandd -0x19b0216(%rip){1to16},%zmm27,%zmm8        # 5d100c <.LCPI3_92>
 1f81222:	and    %r8,%rax
 1f81225:	kmovq  %k2,%r12
 1f8122a:	mov    0xb90(%r13),%r8
 1f81231:	vpmovb2m %zmm7,%k2
 1f81237:	and    %rax,%r12
 1f8123a:	and    %r11,%r12
 1f8123d:	kmovq  %r12,%k3
 1f81242:	vpmovm2b %k3,%zmm2
 1f81248:	vptestmb %zmm21,%zmm30,%k3{%k4}
 1f8124e:	vpternlogq $0xe0,-0x19b2cb1(%rip){1to8},%zmm27,%zmm30        # 5ce5a8 <.LCPI3_47>
 1f81259:	vpermt2b %zmm2,%zmm6,%zmm29
 1f8125f:	vpbroadcastw %edi,%zmm6
 1f81265:	vgf2p8affineqb $0x0,-0x19b2c98(%rip){1to8},%zmm30,%zmm13        # 5ce5d8 <.LCPI3_93>
 1f81270:	vporq  %zmm23,%zmm6,%zmm7
 1f81276:	vporq  %zmm22,%zmm6,%zmm6
 1f8127c:	vptestmb %zmm29,%zmm29,%k1{%k1}
 1f81282:	kandq  %k3,%k5,%k3
 1f81287:	kandq  %k2,%k5,%k5
 1f8128c:	vmovdqa64 %zmm2,%zmm29
 1f81292:	kandq  %k1,%k5,%k1
 1f81297:	vpternlogq $0xfe,%zmm13,%zmm8,%zmm19
 1f8129e:	vpcompressw %zmm6,%zmm6{%k1}{z}
 1f812a4:	kmovd  %k1,%eax
 1f812a8:	kshiftrq $0x20,%k1,%k5
 1f812ae:	vptestmb %zmm9,%zmm28,%k1
 1f812b4:	vmovdqu64 %zmm19,(%r8,%rdi,1)
 1f812bb:	vpcompressw %zmm7,%zmm7{%k5}{z}
 1f812c1:	kmovd  %k5,%r11d
 1f812c5:	mov    0xba0(%r13),%r8
 1f812cc:	mov    %edx,%r13d
 1f812cf:	vmovdqu64 %zmm6,(%r8,%r13,2)
 1f812d6:	popcnt %eax,%r13d
 1f812db:	kmovq  %k0,%r8
 1f812e0:	vptestmb %zmm18,%zmm27,%k0
 1f812e6:	add    %edx,%r13d
 1f812e9:	mov    0x8(%rsp),%rdx
 1f812ee:	mov    0xba0(%rdx),%rax
 1f812f5:	andn   %r15,%r9,%rdx
 1f812fa:	and    %r14,%rdx
 1f812fd:	mov    0x8(%rsp),%r14
 1f81302:	and    %rdx,%rbx
 1f81305:	kmovq  %k3,%rdx
 1f8130a:	vmovdqu64 %zmm7,(%rax,%r13,2)
 1f81311:	kmovq  %k1,%rax
 1f81316:	vpcmpeqb %zmm15,%zmm5,%k1
 1f8131c:	vptestmb %zmm15,%zmm31,%k1{%k1}
 1f81322:	mov    0xb98(%r14),%r14
 1f81329:	or     %r10,%rax
 1f8132c:	kmovq  %k1,%r9
 1f81331:	mov    %rax,0x8(%r14,%rdi,1)
 1f81336:	or     %rdx,%r9
 1f81339:	popcnt %r11d,%edx
 1f8133e:	or     %r12,%r9
 1f81341:	add    %r13d,%edx
 1f81344:	mov    0x8(%rsp),%r13
 1f81349:	or     %rbx,%r9
 1f8134c:	andn   %r8,%r9,%rax
 1f81351:	mov    %r9,(%r14,%rdi,1)
 1f81355:	mov    %rax,0x10(%r14,%rdi,1)
 1f8135a:	kmovq  %k0,0x18(%r14,%rdi,1)
 1f81361:	korq   %k2,%k0,%k0
 1f81366:	kmovq  %k0,%rax
 1f8136b:	or     %r12,%rax
 1f8136e:	mov    %rax,0x20(%r14,%rdi,1)
 1f81373:	mov    %r12,0x28(%r14,%rdi,1)
 1f81378:	kmovq  %k3,0x30(%r14,%rdi,1)
 1f8137f:	kmovq  %k1,0x38(%r14,%rdi,1)
 1f81386:	add    $0x40,%rdi
 1f8138a:	cmp    %rcx,%rdi
 1f8138d:	jb     1f80f90 <node_facts_window_run+0x3bc0>
 1f81393:	jmp    1f814f2 <node_facts_window_run+0x4122>
 1f81398:	kmovq  %k4,%rax
 1f8139d:	mov    %rax,%r14
 1f813a0:	mov    %rax,0x38(%rsp)
 1f813a5:	test   %rax,%rax
 1f813a8:	je     1f81484 <node_facts_window_run+0x40b4>
 1f813ae:	xor    %eax,%eax
 1f813b0:	tzcnt  %r14,%rax
 1f813b5:	mov    %rax,0x28(%rsp)
 1f813ba:	lea    (%rax,%rdi,1),%r12
 1f813be:	mov    0x20(%rsp),%r8
 1f813c3:	mov    %r12d,%eax
 1f813c6:	mov    %r12d,%r15d
 1f813c9:	mov    0x8(%rsp),%r13
 1f813ce:	movzwl 0x6b554(%r8,%rax,2),%ebp
 1f813d7:	mov    0x8(%rsp),%r8
 1f813dc:	sub    %ebp,%r15d
 1f813df:	mov    0xb80(%r8),%rbp
 1f813e6:	mov    0x8(%rsp),%r8
 1f813eb:	mov    0xb88(%r8),%rbx
 1f813f2:	movzbl 0x0(%rbp,%r15,1),%ebp
 1f813f8:	mov    0x20(%rsp),%r8
 1f813fd:	or     %bpl,(%rbx,%rax,1)
 1f81401:	movzbl 0x2c(%r8,%rax,1),%eax
 1f81407:	mov    0x20(%rsp),%r8
 1f8140c:	movzbl 0x2c(%r8,%r15,1),%ebx
 1f81412:	mov    0x8(%rsp),%r8
 1f81417:	and    $0x7f,%eax
 1f8141a:	and    $0x7f,%ebx
 1f8141d:	movzbl 0x300(%r8,%rbx,1),%ebp
 1f81426:	xor    %r8d,%r8d
 1f81429:	test   %bpl,0x380(%r13,%rax,1)
 1f81431:	mov    0x28(%rsp),%rax
 1f81436:	mov    0x8(%rsp),%r13
 1f8143b:	mov    0x20(%rsp),%rbp
 1f81440:	setne  %r8b
 1f81444:	shlx   %rax,%r8,%rax
 1f81449:	or     %rax,%r10
 1f8144c:	cmp    %r12d,%ecx
 1f8144f:	seta   %al
 1f81452:	cmp    $0x22,%rbx
 1f81456:	mov    0xb98(%r13),%rbx
 1f8145d:	sete   %r8b
 1f81461:	and    %al,%r8b
 1f81464:	movzbl %r8b,%eax
 1f81468:	shlx   %r15,%rax,%rax
 1f8146d:	and    $0xffffffc0,%r15d
 1f81471:	not    %rax
 1f81474:	and    %rax,0x20(%rbx,%r15,1)
 1f81479:	blsr   %r14,%r14
 1f8147e:	jne    1f813ae <node_facts_window_run+0x3fde>
 1f81484:	kmovq  %k3,%r14
 1f81489:	mov    %r14,%r15
 1f8148c:	test   %r14,%r14
 1f8148f:	je     1f814c6 <node_facts_window_run+0x40f6>
 1f81491:	xor    %eax,%eax
 1f81493:	tzcnt  %r15,%rax
 1f81498:	mov    0xb88(%r13),%r12
 1f8149f:	or     %rdi,%rax
 1f814a2:	mov    %eax,%r8d
 1f814a5:	movzwl 0x6d5d4(%rbp,%r8,2),%ebx
 1f814ae:	sub    %ebx,%eax
 1f814b0:	mov    0xb80(%r13),%rbx
 1f814b7:	movzbl (%rbx,%rax,1),%eax
 1f814bb:	or     %al,(%r12,%r8,1)
 1f814bf:	blsr   %r15,%r15
 1f814c4:	jne    1f81491 <node_facts_window_run+0x40c1>
 1f814c6:	mov    0xb88(%r13),%rbx
 1f814cd:	popcnt 0x38(%rsp),%rax
 1f814d4:	popcnt %r14,%r8
 1f814d9:	add    0x10(%rsp),%rax
 1f814de:	vmovdqu64 (%rbx,%rdi,1),%zmm9
 1f814e5:	add    %r8,%rax
 1f814e8:	mov    %rax,0x10(%rsp)
 1f814ed:	jmp    1f8113a <node_facts_window_run+0x3d6a>
 1f814f2:	mov    0x40(%rsp),%r9
 1f814f7:	mov    0x10(%rsp),%rsi
 1f814fc:	mov    %ecx,%eax
 1f814fe:	dec    %rcx
 1f81501:	shr    $0x6,%rcx
 1f81505:	inc    %rcx
 1f81508:	mov    %ecx,%edi
 1f8150a:	and    $0x7,%edi
 1f8150d:	add    %rsi,0xa88(%r9)
 1f81514:	mov    0xb98(%r13),%rsi
 1f8151b:	cmp    $0x1c1,%eax
 1f81520:	jae    1f81542 <node_facts_window_run+0x4172>
 1f81522:	mov    (%rsp),%r11
 1f81526:	mov    0x30(%rsp),%r10
 1f8152b:	vpxor  %xmm0,%xmm0,%xmm0
 1f8152f:	xor    %r8d,%r8d
 1f81532:	jmp    1f815e9 <node_facts_window_run+0x4219>
 1f81537:	xor    %edx,%edx
 1f81539:	vpxor  %xmm0,%xmm0,%xmm0
 1f8153d:	jmp    1f8171f <node_facts_window_run+0x434f>
 1f81542:	mov    0x30(%rsp),%r10
 1f81547:	and    $0xfffffffffffffff8,%rcx
 1f8154b:	vpxor  %xmm0,%xmm0,%xmm0
 1f8154f:	xor    %r8d,%r8d
 1f81552:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81560:	vpopcntq (%rsi,%r8,1),%zmm1
 1f81567:	vpopcntq 0x40(%rsi,%r8,1),%zmm3
 1f8156f:	vpopcntq 0x80(%rsi,%r8,1),%zmm2
 1f81577:	vpopcntq 0xc0(%rsi,%r8,1),%zmm4
 1f8157f:	vpaddq %zmm0,%zmm1,%zmm0
 1f81585:	vpaddq %zmm3,%zmm2,%zmm1
 1f8158b:	vpopcntq 0x100(%rsi,%r8,1),%zmm2
 1f81593:	vpopcntq 0x140(%rsi,%r8,1),%zmm3
 1f8159b:	vpaddq %zmm0,%zmm1,%zmm0
 1f815a1:	vpaddq %zmm4,%zmm2,%zmm1
 1f815a7:	vpopcntq 0x1c0(%rsi,%r8,1),%zmm2
 1f815af:	vpaddq %zmm1,%zmm3,%zmm1
 1f815b5:	vpopcntq 0x180(%rsi,%r8,1),%zmm3
 1f815bd:	add    $0x200,%r8
 1f815c4:	add    $0xfffffffffffffff8,%rcx
 1f815c8:	vpaddq %zmm0,%zmm1,%zmm0
 1f815ce:	vpaddq %zmm3,%zmm2,%zmm1
 1f815d4:	vpaddq %zmm0,%zmm1,%zmm0
 1f815da:	jne    1f81560 <node_facts_window_run+0x4190>
 1f815dc:	mov    (%rsp),%r11
 1f815e0:	test   %rdi,%rdi
 1f815e3:	je     1f8171a <node_facts_window_run+0x434a>
 1f815e9:	add    %r8,%rsi
 1f815ec:	shl    $0x6,%edi
 1f815ef:	xor    %ecx,%ecx
 1f815f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81600:	vpopcntq (%rsi,%rcx,1),%zmm1
 1f81607:	add    $0x40,%rcx
 1f8160b:	vpaddq %zmm0,%zmm1,%zmm0
 1f81611:	cmp    %rcx,%rdi
 1f81614:	jne    1f81600 <node_facts_window_run+0x4230>
 1f81616:	jmp    1f8171a <node_facts_window_run+0x434a>
 1f8161b:	mov    0x40(%rsp),%r9
 1f81620:	mov    0x28(%rsp),%rax
 1f81625:	mov    %ecx,%r8d
 1f81628:	dec    %rcx
 1f8162b:	shr    $0x6,%rcx
 1f8162f:	inc    %rcx
 1f81632:	mov    %ecx,%edi
 1f81634:	and    $0x7,%edi
 1f81637:	add    %rax,0xa88(%r9)
 1f8163e:	mov    0xb98(%r13),%rsi
 1f81645:	cmp    $0x1c1,%r8d
 1f8164c:	jae    1f8165f <node_facts_window_run+0x428f>
 1f8164e:	mov    0x30(%rsp),%r10
 1f81653:	vpxor  %xmm0,%xmm0,%xmm0
 1f81657:	xor    %r8d,%r8d
 1f8165a:	jmp    1f816f1 <node_facts_window_run+0x4321>
 1f8165f:	mov    0x30(%rsp),%r10
 1f81664:	and    $0xfffffffffffffff8,%rcx
 1f81668:	vpxor  %xmm0,%xmm0,%xmm0
 1f8166c:	xor    %r8d,%r8d
 1f8166f:	nop
 1f81670:	vpopcntq (%rsi,%r8,1),%zmm1
 1f81677:	vpopcntq 0x40(%rsi,%r8,1),%zmm3
 1f8167f:	vpopcntq 0x80(%rsi,%r8,1),%zmm2
 1f81687:	vpopcntq 0xc0(%rsi,%r8,1),%zmm4
 1f8168f:	vpaddq %zmm0,%zmm1,%zmm0
 1f81695:	vpaddq %zmm3,%zmm2,%zmm1
 1f8169b:	vpopcntq 0x100(%rsi,%r8,1),%zmm2
 1f816a3:	vpopcntq 0x140(%rsi,%r8,1),%zmm3
 1f816ab:	vpaddq %zmm0,%zmm1,%zmm0
 1f816b1:	vpaddq %zmm4,%zmm2,%zmm1
 1f816b7:	vpopcntq 0x1c0(%rsi,%r8,1),%zmm2
 1f816bf:	vpaddq %zmm1,%zmm3,%zmm1
 1f816c5:	vpopcntq 0x180(%rsi,%r8,1),%zmm3
 1f816cd:	add    $0x200,%r8
 1f816d4:	add    $0xfffffffffffffff8,%rcx
 1f816d8:	vpaddq %zmm0,%zmm1,%zmm0
 1f816de:	vpaddq %zmm3,%zmm2,%zmm1
 1f816e4:	vpaddq %zmm0,%zmm1,%zmm0
 1f816ea:	jne    1f81670 <node_facts_window_run+0x42a0>
 1f816ec:	test   %rdi,%rdi
 1f816ef:	je     1f81716 <node_facts_window_run+0x4346>
 1f816f1:	add    %r8,%rsi
 1f816f4:	shl    $0x6,%edi
 1f816f7:	xor    %ecx,%ecx
 1f816f9:	nopl   0x0(%rax)
 1f81700:	vpopcntq (%rsi,%rcx,1),%zmm1
 1f81707:	add    $0x40,%rcx
 1f8170b:	vpaddq %zmm0,%zmm1,%zmm0
 1f81711:	cmp    %rcx,%rdi
 1f81714:	jne    1f81700 <node_facts_window_run+0x4330>
 1f81716:	mov    (%rsp),%r11
 1f8171a:	mov    0x18(%rsp),%rsi
 1f8171f:	vextracti32x4 $0x3,%zmm0,%xmm1
 1f81726:	mov    $0x24,%al
 1f81728:	vpermq $0xff,%zmm0,%zmm2
 1f8172f:	vextracti64x4 $0x1,%zmm0,%ymm3
 1f81736:	movq   $0x0,0x1f0(%rsp)
 1f81742:	vpbroadcastq %xmm1,%xmm1
 1f81747:	kmovd  %eax,%k1
 1f8174b:	mov    $0x9,%al
 1f8174d:	vextracti32x4 $0x2,%zmm2,%xmm2
 1f81754:	vpblendd $0x3,%ymm0,%ymm3,%ymm0
 1f8175a:	vpaddq %xmm1,%xmm3,%xmm1
 1f8175e:	kmovd  %eax,%k2
 1f81762:	vmovdqu64 0x40(%rsi),%zmm4{%k1}{z}
 1f81769:	vpaddq %xmm2,%xmm1,%xmm1
 1f8176d:	vmovdqu64 (%rsi),%zmm2{%k2}{z}
 1f81773:	vpsrldq $0x8,%xmm1,%xmm1
 1f81778:	vpsubq %ymm1,%ymm0,%ymm0
 1f8177c:	vshufi64x2 $0x55,%zmm0,%zmm0,%zmm3
 1f81783:	vpermq $0x64,%ymm0,%ymm0
 1f81789:	vpaddq %zmm4,%zmm3,%zmm1
 1f8178f:	vpaddq %zmm2,%zmm0,%zmm0
 1f81795:	vmovdqu64 %zmm1,0x40(%rsi){%k1}
 1f8179c:	vmovdqu64 %zmm0,(%rsi){%k2}
 1f817a2:	test   %edx,%edx
 1f817a4:	je     1f81884 <node_facts_window_run+0x44b4>
 1f817aa:	mov    $0x8,%ebp
 1f817af:	mov    %edx,%r14d
 1f817b2:	xor    %r12d,%r12d
 1f817b5:	xor    %r13d,%r13d
 1f817b8:	xor    %r15d,%r15d
 1f817bb:	nopl   0x0(%rax,%rax,1)
 1f817c0:	mov    0x8(%rsp),%rcx
 1f817c5:	mov    0x20(%rsp),%rsi
 1f817ca:	mov    0xba0(%rcx),%rax
 1f817d1:	mov    0xba8(%rcx),%rcx
 1f817d8:	movzwl (%rax,%r13,2),%ebx
 1f817dd:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f817e5:	sub    %eax,%ebx
 1f817e7:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f817ef:	mov    %ebx,%edx
 1f817f1:	sub    %eax,%edx
 1f817f3:	cmpb   $0x2,0x69454(%rsi,%rdx,1)
 1f817fb:	mov    0x757d4(%rsi,%rdx,4),%eax
 1f81802:	cmovne %r12,%rax
 1f81806:	movzbl (%rcx,%rax,1),%eax
 1f8180a:	cmovne %ebp,%eax
 1f8180d:	test   $0x8,%al
 1f8180f:	je     1f81822 <node_facts_window_run+0x4452>
 1f81811:	movzbl %al,%eax
 1f81814:	test   $0x10,%al
 1f81816:	jne    1f8184c <node_facts_window_run+0x447c>
 1f81818:	inc    %r13
 1f8181b:	cmp    %r13,%r14
 1f8181e:	jne    1f817c0 <node_facts_window_run+0x43f0>
 1f81820:	jmp    1f81878 <node_facts_window_run+0x44a8>
 1f81822:	mov    0x8(%rsp),%rdi
 1f81827:	mov    0x20(%rsp),%rsi
 1f8182c:	vzeroupper
 1f8182f:	call   1f93b20 <node_tests_window_wants>
 1f81834:	mov    0x30(%rsp),%r10
 1f81839:	mov    0x40(%rsp),%r9
 1f8183e:	mov    (%rsp),%r11
 1f81842:	movzbl %al,%eax
 1f81845:	inc    %r15
 1f81848:	test   $0x10,%al
 1f8184a:	je     1f81818 <node_facts_window_run+0x4448>
 1f8184c:	mov    0x8(%rsp),%rdx
 1f81851:	mov    %ebx,%ecx
 1f81853:	mov    $0xfffffffffffffffe,%rax
 1f8185a:	and    $0xffffffc0,%ebx
 1f8185d:	rol    %cl,%rax
 1f81860:	mov    0xb98(%rdx),%rcx
 1f81867:	and    %rax,0x20(%rcx,%rbx,1)
 1f8186c:	inc    %r13
 1f8186f:	cmp    %r13,%r14
 1f81872:	jne    1f817c0 <node_facts_window_run+0x43f0>
 1f81878:	mov    0x20(%rsp),%rbp
 1f8187d:	mov    0x8(%rsp),%r13
 1f81882:	jmp    1f8188a <node_facts_window_run+0x44ba>
 1f81884:	xor    %r14d,%r14d
 1f81887:	xor    %r15d,%r15d
 1f8188a:	add    %r15,0x828(%r9)
 1f81891:	rdtsc
 1f81893:	add    %r14,0x820(%r9)
 1f8189a:	cmpl   $0x0,0xa90(%r11)
 1f818a2:	mov    %rax,0x420(%rsp)
 1f818aa:	mov    %rdx,0x730(%rsp)
 1f818b2:	mov    0xb8(%rsp),%rax
 1f818ba:	je     1f8272e <node_facts_window_run+0x535e>
 1f818c0:	movzbl 0x90(%rsp),%ecx
 1f818c8:	mov    (%rax),%rax
 1f818cb:	mov    $0xffffffffffffffff,%r14
 1f818d2:	xor    %r15d,%r15d
 1f818d5:	xor    %r12d,%r12d
 1f818d8:	mov    %ecx,0x670(%rsp)
 1f818df:	movzbl 0x40(%r13),%ecx
 1f818e4:	mov    0x6c8(%rax),%edx
 1f818ea:	mov    0x6e8(%rax),%eax
 1f818f0:	shl    $0x1b,%rcx
 1f818f4:	mov    %rcx,0xb0(%rsp)
 1f818fc:	mov    %edx,0x48(%rsp)
 1f81900:	mov    %eax,0x520(%rsp)
 1f81907:	movzbl 0x3a(%r13),%eax
 1f8190c:	lea    0x42ec(%rbp),%rdx
 1f81913:	lea    0x422c(%rbp),%rcx
 1f8191a:	mov    %eax,0x98(%rsp)
 1f81921:	movzbl 0x3c(%r13),%eax
 1f81926:	mov    %eax,0xa8(%rsp)
 1f8192d:	mov    0xc0(%rsp),%eax
 1f81934:	mov    %rdx,0x58(%rsp)
 1f81939:	mov    %rcx,0x6f0(%rsp)
 1f81941:	movq   $0x0,0x1f0(%rsp)
 1f8194d:	vpbroadcastd %eax,%zmm3
 1f81953:	jmp    1f81977 <node_facts_window_run+0x45a7>
 1f81955:	data16 cs nopw 0x0(%rax,%rax,1)
 1f81960:	movb   $0x0,0x61(%rdx)
 1f81964:	mov    0xa90(%r11),%eax
 1f8196b:	inc    %r15
 1f8196e:	cmp    %rax,%r15
 1f81971:	jae    1f8272e <node_facts_window_run+0x535e>
 1f81977:	mov    0xa88(%r11),%rax
 1f8197e:	imul   $0x68,%r15,%rdx
 1f81982:	add    %r10,%rdx
 1f81985:	cmpb   $0x0,(%rax,%r15,1)
 1f8198a:	je     1f81960 <node_facts_window_run+0x4590>
 1f8198c:	mov    0xa50(%r11),%rax
 1f81993:	mov    (%rax,%r15,4),%eax
 1f81997:	cmp    0x20(%r9),%eax
 1f8199b:	jae    1f81960 <node_facts_window_run+0x4590>
 1f8199d:	mov    0x18(%r9),%rcx
 1f819a1:	movzbl (%rcx,%rax,1),%eax
 1f819a5:	shr    $0x5,%al
 1f819a8:	and    $0x1,%al
 1f819aa:	mov    %al,0x61(%rdx)
 1f819ad:	je     1f81964 <node_facts_window_run+0x4594>
 1f819af:	mov    0xa70(%r11),%rax
 1f819b6:	mov    0xb90(%r13),%rcx
 1f819bd:	mov    (%rax,%r15,4),%eax
 1f819c1:	mov    0x651b8(%rbp,%rax,4),%ebp
 1f819c8:	mov    %eax,%r9d
 1f819cb:	mov    %rax,0x2a0(%rsp)
 1f819d3:	sub    %ebp,%r9d
 1f819d6:	inc    %r9d
 1f819d9:	mov    %r9d,%eax
 1f819dc:	mov    %rax,0x170(%rsp)
 1f819e4:	mov    %rdx,0x2e0(%rsp)
 1f819ec:	test   %rbp,%rbp
 1f819ef:	je     1f81a14 <node_facts_window_run+0x4644>
 1f819f1:	lea    -0x1(%rbp),%rdx
 1f819f5:	shr    $0x6,%rdx
 1f819f9:	inc    %rdx
 1f819fc:	mov    %edx,%eax
 1f819fe:	and    $0x7,%eax
 1f81a01:	cmp    $0x1c1,%ebp
 1f81a07:	jae    1f81a1b <node_facts_window_run+0x464b>
 1f81a09:	vpxor  %xmm0,%xmm0,%xmm0
 1f81a0d:	xor    %esi,%esi
 1f81a0f:	jmp    1f81b8e <node_facts_window_run+0x47be>
 1f81a14:	xor    %eax,%eax
 1f81a16:	jmp    1f81c03 <node_facts_window_run+0x4833>
 1f81a1b:	movabs $0x7fffffffffffff8,%rsi
 1f81a25:	mov    %r9,0x110(%rsp)
 1f81a2d:	vpxor  %xmm0,%xmm0,%xmm0
 1f81a31:	and    %rsi,%rdx
 1f81a34:	mov    0x170(%rsp),%rsi
 1f81a3c:	lea    0x1c0(%rcx,%rsi,1),%rdi
 1f81a44:	xor    %esi,%esi
 1f81a46:	cs nopw 0x0(%rax,%rax,1)
 1f81a50:	lea    0x0(%rbp,%rsi,1),%r9
 1f81a55:	mov    %r9d,%r8d
 1f81a58:	sub    $0x40,%r9
 1f81a5c:	shlx   %r8,%r14,%r8
 1f81a61:	not    %r8
 1f81a64:	mov    %r8,%r10
 1f81a67:	cmovae %r14,%r10
 1f81a6b:	cmp    $0x40,%r9
 1f81a6f:	shlx   %r9,%r14,%r9
 1f81a74:	not    %r9
 1f81a77:	kmovq  %r10,%k1
 1f81a7c:	cmovae %r14,%r9
 1f81a80:	vmovdqu8 -0x1c0(%rdi),%zmm1{%k1}{z}
 1f81a87:	kmovq  %r9,%k1
 1f81a8c:	lea    -0x80(%rbp,%rsi,1),%r9
 1f81a91:	vmovdqu8 -0x180(%rdi),%zmm2{%k1}{z}
 1f81a98:	cmp    $0x40,%r9
 1f81a9c:	mov    %r8,%r9
 1f81a9f:	cmovae %r14,%r9
 1f81aa3:	kmovq  %r9,%k1
 1f81aa8:	lea    -0xc0(%rbp,%rsi,1),%r9
 1f81ab0:	cmp    $0x40,%r9
 1f81ab4:	mov    %r8,%r9
 1f81ab7:	cmovae %r14,%r9
 1f81abb:	vpternlogq $0xfe,%zmm1,%zmm0,%zmm2
 1f81ac2:	vmovdqu8 -0x140(%rdi),%zmm0{%k1}{z}
 1f81ac9:	kmovq  %r9,%k1
 1f81ace:	lea    -0x100(%rbp,%rsi,1),%r9
 1f81ad6:	vmovdqu8 -0x100(%rdi),%zmm1{%k1}{z}
 1f81add:	cmp    $0x40,%r9
 1f81ae1:	mov    %r8,%r9
 1f81ae4:	cmovae %r14,%r9
 1f81ae8:	kmovq  %r9,%k1
 1f81aed:	lea    -0x140(%rbp,%rsi,1),%r9
 1f81af5:	cmp    $0x40,%r9
 1f81af9:	mov    %r8,%r9
 1f81afc:	cmovae %r14,%r9
 1f81b00:	vpternlogq $0xfe,%zmm0,%zmm2,%zmm1
 1f81b07:	vmovdqu8 -0xc0(%rdi),%zmm0{%k1}{z}
 1f81b0e:	kmovq  %r9,%k1
 1f81b13:	lea    -0x180(%rbp,%rsi,1),%r9
 1f81b1b:	vmovdqu8 -0x80(%rdi),%zmm2{%k1}{z}
 1f81b22:	cmp    $0x40,%r9
 1f81b26:	mov    %r8,%r9
 1f81b29:	cmovae %r14,%r9
 1f81b2d:	kmovq  %r9,%k1
 1f81b32:	lea    -0x1c0(%rbp,%rsi,1),%r9
 1f81b3a:	vmovdqu8 -0x40(%rdi),%zmm4{%k1}{z}
 1f81b41:	cmp    $0x40,%r9
 1f81b45:	cmovae %r14,%r8
 1f81b49:	add    $0xfffffffffffffe00,%rsi
 1f81b50:	kmovq  %r8,%k1
 1f81b55:	vpternlogq $0xfe,%zmm0,%zmm1,%zmm2
 1f81b5c:	vmovdqu8 (%rdi),%zmm0{%k1}{z}
 1f81b62:	add    $0x200,%rdi
 1f81b69:	add    $0xfffffffffffffff8,%rdx
 1f81b6d:	vpternlogq $0xfe,%zmm4,%zmm2,%zmm0
 1f81b74:	jne    1f81a50 <node_facts_window_run+0x4680>
 1f81b7a:	test   %rax,%rax
 1f81b7d:	je     1f82662 <node_facts_window_run+0x5292>
 1f81b83:	mov    0x110(%rsp),%r9
 1f81b8b:	neg    %rsi
 1f81b8e:	mov    0x170(%rsp),%rdi
 1f81b96:	lea    (%rcx,%rsi,1),%rdx
 1f81b9a:	shl    $0x6,%eax
 1f81b9d:	add    %rdi,%rdx
 1f81ba0:	mov    %rbp,%rdi
 1f81ba3:	sub    %rsi,%rdi
 1f81ba6:	xor    %esi,%esi
 1f81ba8:	nopl   0x0(%rax,%rax,1)
 1f81bb0:	mov    %edi,%r8d
 1f81bb3:	sub    $0x40,%rdi
 1f81bb7:	shlx   %r8,%r14,%r8
 1f81bbc:	not    %r8
 1f81bbf:	cmovae %r14,%r8
 1f81bc3:	kmovq  %r8,%k1
 1f81bc8:	vmovdqu8 (%rdx,%rsi,1),%zmm1{%k1}{z}
 1f81bcf:	add    $0x40,%rsi
 1f81bd3:	vporq  %zmm1,%zmm0,%zmm0
 1f81bd9:	cmp    %rsi,%rax
 1f81bdc:	jne    1f81bb0 <node_facts_window_run+0x47e0>
 1f81bde:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f81be5:	vporq  %zmm1,%zmm0,%zmm0
 1f81beb:	vextracti128 $0x1,%ymm0,%xmm1
 1f81bf1:	vpor   %xmm1,%xmm0,%xmm0
 1f81bf5:	vpshufd $0xee,%xmm0,%xmm1
 1f81bfa:	vpor   %xmm1,%xmm0,%xmm0
 1f81bfe:	vmovq  %xmm0,%rax
 1f81c03:	mov    0xa58(%r11),%rdx
 1f81c0a:	mov    0xa68(%r11),%rsi
 1f81c11:	mov    (%rdx,%r15,4),%edi
 1f81c15:	mov    %rax,%rdx
 1f81c18:	shr    $0x20,%rdx
 1f81c1c:	mov    (%rsi,%r15,4),%r8d
 1f81c20:	or     %rax,%rdx
 1f81c23:	mov    %rdx,%rsi
 1f81c26:	shr    $0x10,%rsi
 1f81c2a:	or     %edx,%esi
 1f81c2c:	mov    %esi,%eax
 1f81c2e:	shr    $0x8,%eax
 1f81c31:	or     %esi,%eax
 1f81c33:	mov    %edi,0x3a0(%rsp)
 1f81c3a:	cmp    %ebp,%edi
 1f81c3c:	jbe    1f81c42 <node_facts_window_run+0x4872>
 1f81c3e:	or     (%rcx,%r8,1),%al
 1f81c42:	movzbl %al,%esi
 1f81c45:	lea    0x0(,%rsi,8),%edx
 1f81c4c:	lea    0x0(,%rsi,4),%ecx
 1f81c53:	mov    %edx,%eax
 1f81c55:	mov    %ecx,0x360(%rsp)
 1f81c5c:	and    $0x8,%eax
 1f81c5f:	and    $0x10,%ecx
 1f81c62:	and    $0x40,%edx
 1f81c65:	or     %eax,%ecx
 1f81c67:	mov    %esi,%eax
 1f81c69:	and    $0x10,%eax
 1f81c6c:	lea    (%rcx,%rax,2),%eax
 1f81c6f:	or     %eax,%edx
 1f81c71:	mov    %esi,%eax
 1f81c73:	and    $0x2,%eax
 1f81c76:	mov    %rdx,0x60(%rsp)
 1f81c7b:	mov    %rsi,0x600(%rsp)
 1f81c83:	mov    %eax,0x5c0(%rsp)
 1f81c8a:	je     1f81ca0 <node_facts_window_run+0x48d0>
 1f81c8c:	cmpb   $0x1,0x26(%r13)
 1f81c91:	jne    1f81ca0 <node_facts_window_run+0x48d0>
 1f81c93:	movzbl 0x54(%r13),%eax
 1f81c98:	shl    $0x11,%eax
 1f81c9b:	add    %rax,0x60(%rsp)
 1f81ca0:	mov    0xbd0(%r13),%rcx
 1f81ca7:	mov    0xbd8(%r13),%rax
 1f81cae:	mov    %r12d,%esi
 1f81cb1:	mov    %r8,0x4c0(%rsp)
 1f81cb9:	mov    %ebp,%r8d
 1f81cbc:	shr    $0x6,%r8d
 1f81cc0:	mov    %r12d,0x440(%rsp)
 1f81cc8:	lea    (%rcx,%rsi,8),%rdi
 1f81ccc:	lea    (%rax,%rsi,8),%rdx
 1f81cd0:	mov    %rdi,0x320(%rsp)
 1f81cd8:	mov    %rdx,0x480(%rsp)
 1f81ce0:	mov    %r9d,%edx
 1f81ce3:	and    $0x3f,%r9d
 1f81ce7:	shr    $0x6,%edx
 1f81cea:	lea    0x1(%r8),%rdi
 1f81cee:	mov    %r8,0x3e0(%rsp)
 1f81cf6:	mov    %rbp,0x10(%rsp)
 1f81cfb:	mov    %rbp,%r8
 1f81cfe:	mov    %r9d,%r10d
 1f81d01:	xor    $0x3f,%r10d
 1f81d05:	mov    %rdi,0x260(%rsp)
 1f81d0d:	mov    %rdx,0x580(%rsp)
 1f81d15:	cmp    $0x40,%ebp
 1f81d18:	jae    1f81d35 <node_facts_window_run+0x4965>
 1f81d1a:	mov    %r8,%rdx
 1f81d1d:	mov    $0xffffffff,%r14d
 1f81d23:	xor    %r8d,%r8d
 1f81d26:	xor    %ebp,%ebp
 1f81d28:	xor    %r12d,%r12d
 1f81d2b:	mov    $0x40,%ebx
 1f81d30:	jmp    1f81fad <node_facts_window_run+0x4bdd>
 1f81d35:	shr    $1,%edi
 1f81d37:	lea    0x8(%rcx,%rsi,8),%rcx
 1f81d3c:	lea    0x8(%rax,%rsi,8),%rax
 1f81d41:	shl    $0x6,%edx
 1f81d44:	mov    $0xffffffff,%r14d
 1f81d4a:	mov    %r15,0x540(%rsp)
 1f81d52:	xor    %ebp,%ebp
 1f81d54:	shl    $0x7,%rdi
 1f81d58:	mov    %rcx,0x70(%rsp)
 1f81d5d:	mov    %rdx,0x18(%rsp)
 1f81d62:	mov    %rax,0x28(%rsp)
 1f81d67:	mov    %rdi,0x1b0(%rsp)
 1f81d6f:	mov    %r9,0x110(%rsp)
 1f81d77:	mov    %r8d,%eax
 1f81d7a:	xor    %r9d,%r9d
 1f81d7d:	xor    %r8d,%r8d
 1f81d80:	xor    %edi,%edi
 1f81d82:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81d90:	mov    %eax,0x38(%rsp)
 1f81d94:	mov    %eax,%r13d
 1f81d97:	sub    $0x40,%r13d
 1f81d9b:	mov    $0x40,%ecx
 1f81da0:	mov    0x8(%rsp),%r11
 1f81da5:	cmovb  %eax,%ecx
 1f81da8:	cmp    0x10(%rsp),%r9
 1f81dad:	mov    0x18(%rsp),%rsi
 1f81db2:	mov    0x110(%rsp),%r12
 1f81dba:	mov    $0x0,%eax
 1f81dbf:	mov    0x70(%rsp),%rdx
 1f81dc4:	mov    0xb98(%r11),%r15
 1f81dcb:	cmovae %eax,%ecx
 1f81dce:	mov    $0xffffffffffffffff,%rax
 1f81dd5:	add    %rsi,%r15
 1f81dd8:	cmp    $0x40,%ecx
 1f81ddb:	shlx   %rcx,%rax,%rcx
 1f81de0:	mov    0x58(%r9,%r15,1),%rbx
 1f81de5:	not    %rcx
 1f81de8:	cmove  %rax,%rcx
 1f81dec:	shrx   %r12,0x18(%r9,%r15,1),%rax
 1f81df3:	add    %rbx,%rbx
 1f81df6:	shlx   %r10,%rbx,%rbx
 1f81dfb:	or     %rax,%rbx
 1f81dfe:	mov    0x48(%r9,%r15,1),%rax
 1f81e03:	shrx   %r12,0x8(%r9,%r15,1),%r15
 1f81e0a:	and    %rcx,%rbx
 1f81e0d:	add    %rax,%rax
 1f81e10:	shlx   %r10,%rax,%rax
 1f81e15:	or     %r15,%rax
 1f81e18:	and    %rcx,%rax
 1f81e1b:	mov    %rax,-0x8(%rdx,%r8,8)
 1f81e20:	mov    0xb98(%r11),%rax
 1f81e27:	add    %rsi,%rax
 1f81e2a:	mov    0x8(%rsp),%rsi
 1f81e2f:	shrx   %r12,0x10(%r9,%rax,1),%r11
 1f81e36:	mov    0x50(%r9,%rax,1),%rax
 1f81e3b:	add    %rax,%rax
 1f81e3e:	shlx   %r10,%rax,%r15
 1f81e43:	mov    0x28(%rsp),%rax
 1f81e48:	or     %r11,%r15
 1f81e4b:	mov    %r9d,%r11d
 1f81e4e:	and    %rcx,%r15
 1f81e51:	mov    %edi,%ecx
 1f81e53:	mov    $0x40,%edi
 1f81e58:	mov    %r15,-0x8(%rax,%r8,8)
 1f81e5d:	popcnt %rbx,%rax
 1f81e62:	add    %eax,%ecx
 1f81e64:	lzcnt  %rbx,%rax
 1f81e69:	sub    %eax,%r11d
 1f81e6c:	lea    0x40(%r9),%rax
 1f81e70:	add    $0x3f,%r11d
 1f81e74:	test   %rbx,%rbx
 1f81e77:	mov    %r14d,%ebx
 1f81e7a:	cmovne %r11d,%ebx
 1f81e7e:	or     -0x8(%rdx,%r8,8),%rbp
 1f81e83:	cmp    $0x40,%r13d
 1f81e87:	mov    $0xffffffffffffffff,%r11
 1f81e8e:	cmovae %edi,%r13d
 1f81e92:	cmp    0x10(%rsp),%rax
 1f81e97:	mov    $0x0,%eax
 1f81e9c:	mov    0x18(%rsp),%rdi
 1f81ea1:	cmovae %eax,%r13d
 1f81ea5:	mov    0xb98(%rsi),%rax
 1f81eac:	shlx   %r13,%r11,%r14
 1f81eb1:	not    %r14
 1f81eb4:	add    %rdi,%rax
 1f81eb7:	cmp    $0x40,%r13d
 1f81ebb:	mov    0x98(%r9,%rax,1),%r13
 1f81ec3:	cmove  %r11,%r14
 1f81ec7:	shrx   %r12,0x58(%r9,%rax,1),%r11
 1f81ece:	add    %r13,%r13
 1f81ed1:	shlx   %r10,%r13,%r13
 1f81ed6:	or     %r11,%r13
 1f81ed9:	mov    0x88(%r9,%rax,1),%r11
 1f81ee1:	shrx   %r12,0x48(%r9,%rax,1),%rax
 1f81ee8:	and    %r14,%r13
 1f81eeb:	add    %r11,%r11
 1f81eee:	shlx   %r10,%r11,%r11
 1f81ef3:	or     %rax,%r11
 1f81ef6:	and    %r14,%r11
 1f81ef9:	mov    %r11,(%rdx,%r8,8)
 1f81efd:	mov    0xb98(%rsi),%rax
 1f81f04:	mov    0x28(%rsp),%rsi
 1f81f09:	add    %rdi,%rax
 1f81f0c:	popcnt %r13,%rdi
 1f81f11:	shrx   %r12,0x50(%r9,%rax,1),%r11
 1f81f18:	mov    0x90(%r9,%rax,1),%rax
 1f81f20:	add    %ecx,%edi
 1f81f22:	lzcnt  %r13,%rcx
 1f81f27:	add    %rax,%rax
 1f81f2a:	shlx   %r10,%rax,%rax
 1f81f2f:	or     %r11,%rax
 1f81f32:	and    %r14,%rax
 1f81f35:	mov    %r9d,%r14d
 1f81f38:	sub    %ecx,%r14d
 1f81f3b:	add    $0x7f,%r14d
 1f81f3f:	test   %r13,%r13
 1f81f42:	mov    %rax,(%rsi,%r8,8)
 1f81f46:	cmove  %ebx,%r14d
 1f81f4a:	or     (%rdx,%r8,8),%rbp
 1f81f4e:	add    $0x2,%r8
 1f81f52:	sub    $0xffffffffffffff80,%r9
 1f81f56:	or     %r15,%rbp
 1f81f59:	or     %rax,%rbp
 1f81f5c:	mov    0x38(%rsp),%eax
 1f81f60:	add    $0xffffff80,%eax
 1f81f63:	cmp    %r9,0x1b0(%rsp)
 1f81f6b:	jne    1f81d90 <node_facts_window_run+0x49c0>
 1f81f71:	mov    0x3e0(%rsp),%rax
 1f81f79:	mov    (%rsp),%r11
 1f81f7d:	mov    0x8(%rsp),%r13
 1f81f82:	mov    0x540(%rsp),%r15
 1f81f8a:	mov    0x110(%rsp),%r9
 1f81f92:	mov    0x10(%rsp),%rdx
 1f81f97:	mov    $0x40,%ebx
 1f81f9c:	mov    %rbp,%r12
 1f81f9f:	mov    %rdi,%rbp
 1f81fa2:	inc    %rax
 1f81fa5:	test   $0x1,%al
 1f81fa7:	je     1f82093 <node_facts_window_run+0x4cc3>
 1f81fad:	mov    0x580(%rsp),%r11
 1f81fb5:	mov    %r8,%rax
 1f81fb8:	shl    $0x6,%rax
 1f81fbc:	mov    %edx,%ecx
 1f81fbe:	mov    0xb98(%r13),%rsi
 1f81fc5:	sub    %eax,%ecx
 1f81fc7:	cmp    $0x40,%ecx
 1f81fca:	cmovae %ebx,%ecx
 1f81fcd:	cmp    %rdx,%rax
 1f81fd0:	mov    $0x0,%edx
 1f81fd5:	cmovae %edx,%ecx
 1f81fd8:	mov    $0xffffffffffffffff,%rdx
 1f81fdf:	add    %r8,%r11
 1f81fe2:	shl    $0x6,%r11
 1f81fe6:	cmp    $0x40,%ecx
 1f81fe9:	shlx   %rcx,%rdx,%rcx
 1f81fee:	mov    0x58(%rsi,%r11,1),%rbx
 1f81ff3:	not    %rcx
 1f81ff6:	shrx   %r9,0x18(%rsi,%r11,1),%rdi
 1f81ffd:	cmove  %rdx,%rcx
 1f82001:	add    %rbx,%rbx
 1f82004:	shlx   %r10,%rbx,%rdx
 1f82009:	mov    0x48(%rsi,%r11,1),%rbx
 1f8200e:	shrx   %r9,0x8(%rsi,%r11,1),%rsi
 1f82015:	or     %rdi,%rdx
 1f82018:	and    %rcx,%rdx
 1f8201b:	add    %rbx,%rbx
 1f8201e:	shlx   %r10,%rbx,%rdi
 1f82023:	mov    0x320(%rsp),%rbx
 1f8202b:	or     %rsi,%rdi
 1f8202e:	and    %rcx,%rdi
 1f82031:	mov    %rdi,(%rbx,%r8,8)
 1f82035:	mov    0xb98(%r13),%rsi
 1f8203c:	shrx   %r9,0x10(%rsi,%r11,1),%rdi
 1f82043:	mov    0x50(%rsi,%r11,1),%rsi
 1f82048:	mov    %ebp,%r9d
 1f8204b:	popcnt %rdx,%rbp
 1f82050:	mov    (%rsp),%r11
 1f82054:	add    %r9d,%ebp
 1f82057:	add    %rsi,%rsi
 1f8205a:	shlx   %r10,%rsi,%rsi
 1f8205f:	mov    %r14d,%r10d
 1f82062:	lea    0x3f(%rax),%r14d
 1f82066:	or     %rdi,%rsi
 1f82069:	and    %rcx,%rsi
 1f8206c:	lzcnt  %rdx,%rcx
 1f82071:	sub    %ecx,%r14d
 1f82074:	mov    0x480(%rsp),%rcx
 1f8207c:	test   %rdx,%rdx
 1f8207f:	mov    0x10(%rsp),%rdx
 1f82084:	cmove  %r10d,%r14d
 1f82088:	mov    %rsi,(%rcx,%r8,8)
 1f8208c:	or     (%rbx,%r8,8),%r12
 1f82090:	or     %rsi,%r12
 1f82093:	test   %edx,%edx
 1f82095:	je     1f820c6 <node_facts_window_run+0x4cf6>
 1f82097:	lea    -0x1(%rdx),%rax
 1f8209b:	mov    %rdx,%rdi
 1f8209e:	mov    $0xffffffff,%ebx
 1f820a3:	shr    $0x4,%rax
 1f820a7:	inc    %rax
 1f820aa:	mov    %eax,%edx
 1f820ac:	and    $0x3,%edx
 1f820af:	cmp    $0x31,%edi
 1f820b2:	jae    1f820d2 <node_facts_window_run+0x4d02>
 1f820b4:	vpxor  %xmm0,%xmm0,%xmm0
 1f820b8:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f820bf:	xor    %ecx,%ecx
 1f820c1:	jmp    1f82226 <node_facts_window_run+0x4e56>
 1f820c6:	xor    %edx,%edx
 1f820c8:	mov    $0xffffffff,%ecx
 1f820cd:	jmp    1f822f6 <node_facts_window_run+0x4f26>
 1f820d2:	mov    %r15,0x540(%rsp)
 1f820da:	and    $0xfffffffffffffffc,%rax
 1f820de:	lea    -0x20(%rdi),%r8d
 1f820e2:	lea    -0x10(%rdi),%r9d
 1f820e6:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f820ed:	mov    $0xffff,%r15d
 1f820f3:	vpxor  %xmm0,%xmm0,%xmm0
 1f820f7:	mov    0x58(%rsp),%rcx
 1f820fc:	mov    0x170(%rsp),%rsi
 1f82104:	lea    (%rcx,%rsi,4),%rsi
 1f82108:	lea    -0x30(%rdi),%ecx
 1f8210b:	mov    %rcx,0x18(%rsp)
 1f82110:	xor    %ecx,%ecx
 1f82112:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82120:	lea    (%rdi,%rcx,1),%r10
 1f82124:	shlx   %r10d,%ebx,%r11d
 1f82129:	sub    $0x10,%r10
 1f8212d:	not    %r11d
 1f82130:	cmovae %r15d,%r11d
 1f82134:	cmp    $0x10,%r10
 1f82138:	kmovd  %r11d,%k1
 1f8213d:	lea    (%r9,%rcx,1),%r11d
 1f82141:	vmovdqu32 -0xc0(%rsi),%zmm2{%k1}{z}
 1f82148:	shlx   %r11d,%ebx,%r10d
 1f8214d:	lea    (%r8,%rcx,1),%r11d
 1f82151:	not    %r10d
 1f82154:	cmovae %r15d,%r10d
 1f82158:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f8215f:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f82165:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f8216b:	kmovd  %r10d,%k1
 1f82170:	lea    -0x20(%rdi,%rcx,1),%r10
 1f82175:	vmovdqu32 -0x80(%rsi),%zmm2{%k1}{z}
 1f8217c:	cmp    $0x10,%r10
 1f82180:	shlx   %r11d,%ebx,%r10d
 1f82185:	mov    0x18(%rsp),%r11
 1f8218a:	not    %r10d
 1f8218d:	cmovae %r15d,%r10d
 1f82191:	add    %ecx,%r11d
 1f82194:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f8219b:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f821a1:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f821a7:	kmovd  %r10d,%k1
 1f821ac:	lea    -0x30(%rdi,%rcx,1),%r10
 1f821b1:	vmovdqu32 -0x40(%rsi),%zmm2{%k1}{z}
 1f821b8:	cmp    $0x10,%r10
 1f821bc:	shlx   %r11d,%ebx,%r10d
 1f821c1:	not    %r10d
 1f821c4:	cmovae %r15d,%r10d
 1f821c8:	add    $0xffffffffffffffc0,%rcx
 1f821cc:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f821d3:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f821d9:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f821df:	kmovd  %r10d,%k1
 1f821e4:	vmovdqu32 (%rsi),%zmm2{%k1}{z}
 1f821ea:	add    $0x100,%rsi
 1f821f1:	add    $0xfffffffffffffffc,%rax
 1f821f5:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f821fc:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f82202:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82208:	jne    1f82120 <node_facts_window_run+0x4d50>
 1f8220e:	mov    0x540(%rsp),%r15
 1f82216:	test   %rdx,%rdx
 1f82219:	je     1f8266f <node_facts_window_run+0x529f>
 1f8221f:	mov    (%rsp),%r11
 1f82223:	neg    %rcx
 1f82226:	mov    0x170(%rsp),%rax
 1f8222e:	mov    0x10(%rsp),%rsi
 1f82233:	mov    $0xffff,%r8d
 1f82239:	shl    $0x4,%edx
 1f8223c:	lea    0x0(,%rax,4),%rax
 1f82244:	sub    %rcx,%rsi
 1f82247:	lea    (%rax,%rcx,4),%rax
 1f8224b:	add    0x6f0(%rsp),%rax
 1f82253:	xor    %ecx,%ecx
 1f82255:	data16 cs nopw 0x0(%rax,%rax,1)
 1f82260:	mov    %esi,%edi
 1f82262:	sub    $0x10,%rsi
 1f82266:	shlx   %edi,%ebx,%edi
 1f8226b:	not    %edi
 1f8226d:	cmovae %r8d,%edi
 1f82271:	kmovd  %edi,%k1
 1f82275:	vmovdqu32 (%rax,%rcx,4),%zmm2{%k1}{z}
 1f8227c:	add    $0x10,%rcx
 1f82280:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82287:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f8228d:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82293:	cmp    %rcx,%rdx
 1f82296:	jne    1f82260 <node_facts_window_run+0x4e90>
 1f82298:	vextracti64x4 $0x1,%zmm1,%ymm2
 1f8229f:	vpminud %ymm2,%ymm1,%ymm1
 1f822a4:	vextracti128 $0x1,%ymm1,%xmm2
 1f822aa:	vpminud %xmm2,%xmm1,%xmm1
 1f822af:	vpshufd $0xee,%xmm1,%xmm2
 1f822b4:	vpminud %xmm2,%xmm1,%xmm1
 1f822b9:	vpshufd $0x55,%xmm1,%xmm2
 1f822be:	vpminud %xmm2,%xmm1,%xmm1
 1f822c3:	vmovd  %xmm1,%ecx
 1f822c7:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f822ce:	vpmaxud %ymm1,%ymm0,%ymm0
 1f822d3:	vextracti128 $0x1,%ymm0,%xmm1
 1f822d9:	vpmaxud %xmm1,%xmm0,%xmm0
 1f822de:	vpshufd $0xee,%xmm0,%xmm1
 1f822e3:	vpmaxud %xmm1,%xmm0,%xmm0
 1f822e8:	vpshufd $0x55,%xmm0,%xmm1
 1f822ed:	vpmaxud %xmm1,%xmm0,%xmm0
 1f822f2:	vmovd  %xmm0,%edx
 1f822f6:	mov    0x360(%rsp),%eax
 1f822fd:	and    $0x100,%eax
 1f82302:	mov    0x4c0(%rsp),%r8
 1f8230a:	or     %rax,0x60(%rsp)
 1f8230f:	mov    0x3a0(%rsp),%eax
 1f82316:	mov    0x2a0(%rsp),%rdi
 1f8231e:	mov    0x20(%rsp),%rsi
 1f82323:	cmp    0x10(%rsp),%eax
 1f82327:	mov    %r8d,%eax
 1f8232a:	cmovbe %edi,%eax
 1f8232d:	mov    0x422c(%rsi,%rax,4),%esi
 1f82334:	mov    %rsi,0x18(%rsp)
 1f82339:	ja     1f82341 <node_facts_window_run+0x4f71>
 1f8233b:	xor    %esi,%esi
 1f8233d:	xor    %edi,%edi
 1f8233f:	jmp    1f82363 <node_facts_window_run+0x4f93>
 1f82341:	mov    0xb98(%r13),%rdi
 1f82348:	mov    %r8,%r10
 1f8234b:	and    $0xffffffc0,%r8d
 1f8234f:	shrx   %r10,0x8(%rdi,%r8,1),%rsi
 1f82356:	shrx   %r10,0x10(%rdi,%r8,1),%rdi
 1f8235d:	and    $0x1,%esi
 1f82360:	and    $0x1,%edi
 1f82363:	mov    0x3e0(%rsp),%rbx
 1f8236b:	mov    0x10(%rsp),%r10
 1f82370:	mov    0x320(%rsp),%r9
 1f82378:	or     %rsi,%r12
 1f8237b:	or     %rdi,%r12
 1f8237e:	shlx   %r10,%rsi,%r8
 1f82383:	shl    $0x3,%ebx
 1f82386:	mov    %ecx,%esi
 1f82388:	or     %r8,(%r9,%rbx,1)
 1f8238c:	shlx   %r10,%rdi,%r8
 1f82391:	mov    0x480(%rsp),%r10
 1f82399:	mov    %edx,%edi
 1f8239b:	or     %r8,(%r10,%rbx,1)
 1f8239f:	mov    0x18(%rsp),%rbx
 1f823a4:	mov    0x2e0(%rsp),%r8
 1f823ac:	cmp    %ecx,%ebx
 1f823ae:	cmovb  %ebx,%esi
 1f823b1:	cmp    %edx,%ebx
 1f823b3:	cmova  %ebx,%edi
 1f823b6:	cmp    0xc0(%rsp),%ebx
 1f823bd:	cmovae %ecx,%esi
 1f823c0:	mov    0x60(%rsp),%rcx
 1f823c5:	cmovae %edx,%edi
 1f823c8:	mov    0x170(%rsp),%rdx
 1f823d0:	mov    %rcx,(%r8)
 1f823d3:	mov    0x260(%rsp),%rcx
 1f823db:	mov    %r9,0x8(%r8)
 1f823df:	mov    %r10,0x10(%r8)
 1f823e3:	mov    %esi,0x28(%rsp)
 1f823e7:	mov    %edi,0x38(%rsp)
 1f823eb:	mov    0x40(%rsp),%r9
 1f823f0:	mov    %ecx,0x18(%r8)
 1f823f4:	mov    0xb70(%r13),%rcx
 1f823fb:	add    %rdx,%rcx
 1f823fe:	mov    %rcx,0x20(%r8)
 1f82402:	mov    0xb80(%r13),%rcx
 1f82409:	add    %rdx,%rcx
 1f8240c:	mov    %rcx,0x28(%r8)
 1f82410:	mov    0x5c0(%rsp),%ecx
 1f82417:	add    0xb88(%r13),%rdx
 1f8241e:	mov    %rdx,0x30(%r8)
 1f82422:	mov    0x360(%rsp),%edx
 1f82429:	mov    %esi,0x38(%r8)
 1f8242d:	mov    %edi,0x3c(%r8)
 1f82431:	mov    $0x0,%edi
 1f82436:	mov    %ebp,0x40(%r8)
 1f8243a:	mov    %r14d,0x44(%r8)
 1f8243e:	mov    %ecx,0x48(%r8)
 1f82442:	and    $0x80,%edx
 1f82448:	cmpl   $0x0,0x48(%rsp)
 1f8244d:	mov    %edx,0x4c(%r8)
 1f82451:	je     1f8248c <node_facts_window_run+0x50bc>
 1f82453:	cmp    0xc0(%rsp),%ebx
 1f8245a:	mov    %ebx,%ecx
 1f8245c:	cmovae %edi,%ecx
 1f8245f:	jae    1f8248c <node_facts_window_run+0x50bc>
 1f82461:	mov    0xb68(%r13),%rdx
 1f82468:	mov    %ecx,%esi
 1f8246a:	mov    $0x1,%r8d
 1f82470:	shr    $0x6,%ecx
 1f82473:	mov    $0x6,%r10d
 1f82479:	shlx   %rsi,%r8,%rsi
 1f8247e:	mov    0x2e0(%rsp),%r8
 1f82486:	and    (%rdx,%rcx,8),%rsi
 1f8248a:	jne    1f824b2 <node_facts_window_run+0x50e2>
 1f8248c:	mov    0xd0(%rsp),%rcx
 1f82494:	movzbl (%rcx,%rax,1),%eax
 1f82498:	and    $0x7f,%eax
 1f8249b:	cmpl   $0x0,0x520(%rsp)
 1f824a3:	movzbl 0x480(%r13,%rax,1),%r10d
 1f824ac:	jne    1f826c9 <node_facts_window_run+0x52f9>
 1f824b2:	mov    0x10(%rsp),%rsi
 1f824b7:	mov    0x2a0(%rsp),%rbx
 1f824bf:	mov    0xb98(%r13),%rdx
 1f824c6:	cmp    %esi,0x3a0(%rsp)
 1f824cd:	mov    %ebx,%ecx
 1f824cf:	setbe  %al
 1f824d2:	and    $0xffffffc0,%ecx
 1f824d5:	inc    %r14d
 1f824d8:	shrx   %rbx,0x20(%rdx,%rcx,1),%rcx
 1f824df:	mov    0x600(%rsp),%rbx
 1f824e7:	xor    %esi,%r14d
 1f824ea:	mov    0x98(%rsp),%esi
 1f824f1:	mov    %ebp,%edx
 1f824f3:	xor    $0x1,%edx
 1f824f6:	and    $0x22,%ebx
 1f824f9:	cmp    $0x2,%r10d
 1f824fd:	cmovne %edi,%esi
 1f82500:	test   %ebx,%ebx
 1f82502:	cmove  %ebx,%esi
 1f82505:	test   %r12,%r12
 1f82508:	mov    $0x0,%ebx
 1f8250d:	setne  %dil
 1f82511:	or     %al,%dil
 1f82514:	or     %r14d,%edx
 1f82517:	mov    0xb0(%rsp),%rdx
 1f8251f:	cmovne 0xa8(%rsp),%ebx
 1f82527:	test   %ebp,%ebp
 1f82529:	movzbl %dil,%eax
 1f8252d:	cmove  %ebp,%ebx
 1f82530:	or     %eax,%ebx
 1f82532:	xor    %eax,%eax
 1f82534:	test   %r10d,%r10d
 1f82537:	sete   %al
 1f8253a:	or     %esi,%ebx
 1f8253c:	andn   %eax,%ecx,%eax
 1f82541:	mov    $0x101,%ecx
 1f82546:	or     %eax,%ebx
 1f82548:	mov    0xa88(%r11),%rax
 1f8254f:	movzbl (%rax,%r15,1),%eax
 1f82554:	bextr  %ecx,%eax,%eax
 1f82559:	or     %eax,%ebx
 1f8255b:	xor    %eax,%eax
 1f8255d:	cmp    $0x6,%r10d
 1f82561:	sete   %al
 1f82564:	lea    (%rdx,%rax,4),%r14
 1f82568:	or     0x60(%rsp),%r14
 1f8256d:	cmpb   $0x1,0x3b(%r13)
 1f82572:	jne    1f825d4 <node_facts_window_run+0x5204>
 1f82574:	mov    0x20(%rsp),%rbp
 1f82579:	mov    0xb8(%rsp),%rax
 1f82581:	mov    0x440(%rsp),%r12d
 1f82589:	test   %ebx,%ebx
 1f8258b:	jne    1f825e1 <node_facts_window_run+0x5211>
 1f8258d:	mov    0x8(%rax),%rdx
 1f82591:	mov    0x18(%rsp),%rsi
 1f82596:	mov    0x78(%rdx),%eax
 1f82599:	cmp    %eax,%esi
 1f8259b:	jae    1f825e1 <node_facts_window_run+0x5211>
 1f8259d:	mov    0x98(%rdx),%rcx
 1f825a4:	movzbl (%rcx,%rsi,1),%esi
 1f825a8:	cmp    $0x4a,%esi
 1f825ab:	je     1f825cb <node_facts_window_run+0x51fb>
 1f825ad:	cmp    $0x1e,%esi
 1f825b0:	jne    1f825e1 <node_facts_window_run+0x5211>
 1f825b2:	mov    0xa8(%rdx),%rdx
 1f825b9:	mov    0x18(%rsp),%rsi
 1f825be:	mov    (%rdx,%rsi,4),%edx
 1f825c1:	cmp    %eax,%edx
 1f825c3:	jae    1f825e1 <node_facts_window_run+0x5211>
 1f825c5:	cmpb   $0x4a,(%rcx,%rdx,1)
 1f825c9:	jne    1f825e1 <node_facts_window_run+0x5211>
 1f825cb:	or     $0x1000000,%r14
 1f825d2:	jmp    1f825e1 <node_facts_window_run+0x5211>
 1f825d4:	mov    0x20(%rsp),%rbp
 1f825d9:	mov    0x440(%rsp),%r12d
 1f825e1:	cmpl   $0x0,0xb60(%r13)
 1f825e9:	mov    0x28(%rsp),%edx
 1f825ed:	mov    0x38(%rsp),%ecx
 1f825f1:	jne    1f82678 <node_facts_window_run+0x52a8>
 1f825f7:	cmp    0xb48(%r13),%edx
 1f825fe:	ja     1f82609 <node_facts_window_run+0x5239>
 1f82600:	cmp    0xb44(%r13),%ecx
 1f82607:	jae    1f82678 <node_facts_window_run+0x52a8>
 1f82609:	mov    %r14,0x50(%r8)
 1f8260d:	mov    %r10b,0x60(%r8)
 1f82611:	mov    %edx,0x58(%r8)
 1f82615:	mov    %ecx,0x5c(%r8)
 1f82619:	mov    %bl,0x62(%r8)
 1f8261d:	mov    0x1f0(%rsp),%rdx
 1f82625:	or     0x670(%rsp),%ebx
 1f8262c:	mov    0x260(%rsp),%rsi
 1f82634:	mov    $0xffffffffffffffff,%r14
 1f8263b:	mov    0xbe8(%r13),%rax
 1f82642:	mov    %edx,%ecx
 1f82644:	add    %ebx,%edx
 1f82646:	add    %r12d,%esi
 1f82649:	mov    %rdx,0x1f0(%rsp)
 1f82651:	mov    %r15d,(%rax,%rcx,4)
 1f82655:	mov    %esi,%r12d
 1f82658:	mov    0x30(%rsp),%r10
 1f8265d:	jmp    1f81964 <node_facts_window_run+0x4594>
 1f82662:	mov    0x110(%rsp),%r9
 1f8266a:	jmp    1f81bde <node_facts_window_run+0x480e>
 1f8266f:	mov    (%rsp),%r11
 1f82673:	jmp    1f82298 <node_facts_window_run+0x4ec8>
 1f82678:	mov    %r10d,0x10(%rsp)
 1f8267d:	mov    %r13,%rdi
 1f82680:	mov    0x18(%rsp),%rsi
 1f82685:	vmovdqu64 %zmm3,0x110(%rsp)
 1f82690:	vzeroupper
 1f82693:	call   1f6a040 <node_census_reader_marks>
 1f82698:	vmovdqu64 0x110(%rsp),%zmm3
 1f826a3:	mov    0x10(%rsp),%r10d
 1f826a8:	mov    0x2e0(%rsp),%r8
 1f826b0:	mov    0x40(%rsp),%r9
 1f826b5:	mov    (%rsp),%r11
 1f826b9:	mov    0x38(%rsp),%ecx
 1f826bd:	mov    0x28(%rsp),%edx
 1f826c1:	or     %rax,%r14
 1f826c4:	jmp    1f82609 <node_facts_window_run+0x5239>
 1f826c9:	cmp    $0x2,%r10d
 1f826cd:	jne    1f824b2 <node_facts_window_run+0x50e2>
 1f826d3:	mov    0xb8(%rsp),%rax
 1f826db:	mov    %ebx,%edx
 1f826dd:	vmovdqu64 %zmm3,0x110(%rsp)
 1f826e8:	mov    (%rax),%rax
 1f826eb:	mov    0x6e0(%rax),%rdi
 1f826f2:	mov    0x6e8(%rax),%esi
 1f826f8:	vzeroupper
 1f826fb:	call   1f69c20 <node_census_cleans>
 1f82700:	vmovdqu64 0x110(%rsp),%zmm3
 1f8270b:	mov    0x2e0(%rsp),%r8
 1f82713:	mov    0x40(%rsp),%r9
 1f82718:	mov    (%rsp),%r11
 1f8271c:	movzbl %al,%eax
 1f8271f:	xor    %edi,%edi
 1f82721:	lea    0x2(,%rax,4),%r10d
 1f82729:	jmp    1f824b2 <node_facts_window_run+0x50e2>
 1f8272e:	rdtsc
 1f82730:	mov    %rdx,0x38(%rsp)
 1f82735:	mov    %rax,0x28(%rsp)
 1f8273a:	cmpb   $0x0,0x90(%rsp)
 1f82742:	je     1f828bd <node_facts_window_run+0x54ed>
 1f82748:	cmpl   $0x0,0xa90(%r11)
 1f82750:	je     1f828bd <node_facts_window_run+0x54ed>
 1f82756:	mov    $0xffffffffffffffff,%rdx
 1f8275d:	xor    %r9d,%r9d
 1f82760:	xor    %esi,%esi
 1f82762:	jmp    1f82783 <node_facts_window_run+0x53b3>
 1f82764:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82770:	mov    0xa90(%r11),%eax
 1f82777:	inc    %rsi
 1f8277a:	cmp    %rax,%rsi
 1f8277d:	jae    1f828bd <node_facts_window_run+0x54ed>
 1f82783:	mov    0x30(%rsp),%rax
 1f82788:	imul   $0x68,%rsi,%r10
 1f8278c:	cmpb   $0x0,0x61(%rax,%r10,1)
 1f82792:	je     1f82770 <node_facts_window_run+0x53a0>
 1f82794:	mov    0xa70(%r11),%r8
 1f8279b:	add    0x30(%rsp),%r10
 1f827a0:	mov    0xa68(%r11),%rdi
 1f827a7:	mov    %r13,%rcx
 1f827aa:	mov    (%r8,%rsi,4),%r11d
 1f827ae:	mov    0x10(%r10),%r8
 1f827b2:	mov    (%rdi,%rsi,4),%eax
 1f827b5:	sub    0xbd8(%r13),%r8
 1f827bc:	add    0xbe0(%r13),%r8
 1f827c3:	cmpl   $0x0,0x18(%r10)
 1f827c8:	mov    0x651b8(%rbp,%r11,4),%edi
 1f827d0:	mov    %rax,0x18(%rsp)
 1f827d5:	mov    %rsi,0x10(%rsp)
 1f827da:	mov    $0x40,%esi
 1f827df:	je     1f8286b <node_facts_window_run+0x549b>
 1f827e5:	sub    %edi,%r11d
 1f827e8:	mov    %edi,%r13d
 1f827eb:	xor    %r15d,%r15d
 1f827ee:	xor    %r12d,%r12d
 1f827f1:	mov    %edi,%ebp
 1f827f3:	inc    %r11d
 1f827f6:	mov    %r11d,%ebx
 1f827f9:	and    $0x3f,%r11d
 1f827fd:	and    $0xffffffc0,%ebx
 1f82800:	mov    %r11d,%r14d
 1f82803:	xor    $0x3f,%r14d
 1f82807:	nopw   0x0(%rax,%rax,1)
 1f82810:	sub    $0x40,%ebp
 1f82813:	cmovae %esi,%r13d
 1f82817:	cmp    %r15d,%edi
 1f8281a:	cmovbe %r9d,%r13d
 1f8281e:	mov    0xb98(%rcx),%r9
 1f82825:	add    %rbx,%r9
 1f82828:	cmp    $0x40,%r13d
 1f8282c:	shlx   %r13,%rdx,%r13
 1f82831:	shrx   %r11,(%r15,%r9,1),%rax
 1f82837:	mov    0x40(%r15,%r9,1),%r9
 1f8283c:	not    %r13
 1f8283f:	cmove  %rdx,%r13
 1f82843:	add    $0x40,%r15
 1f82847:	add    %r9,%r9
 1f8284a:	shlx   %r14,%r9,%r9
 1f8284f:	or     %rax,%r9
 1f82852:	and    %r13,%r9
 1f82855:	mov    %ebp,%r13d
 1f82858:	mov    %r9,(%r8,%r12,8)
 1f8285c:	inc    %r12
 1f8285f:	xor    %r9d,%r9d
 1f82862:	mov    0x18(%r10),%eax
 1f82866:	cmp    %rax,%r12
 1f82869:	jb     1f82810 <node_facts_window_run+0x5440>
 1f8286b:	mov    (%rsp),%r11
 1f8286f:	mov    0x10(%rsp),%rsi
 1f82874:	mov    0x20(%rsp),%rbp
 1f82879:	mov    %rcx,%r13
 1f8287c:	mov    0xa58(%r11),%r10
 1f82883:	cmp    %edi,(%r10,%rsi,4)
 1f82887:	jbe    1f82770 <node_facts_window_run+0x53a0>
 1f8288d:	mov    0x18(%rsp),%rcx
 1f82892:	mov    0xb98(%r13),%rax
 1f82899:	mov    %ecx,%r9d
 1f8289c:	and    $0xffffffc0,%r9d
 1f828a0:	shrx   %rcx,(%rax,%r9,1),%rax
 1f828a6:	xor    %r9d,%r9d
 1f828a9:	and    $0x1,%eax
 1f828ac:	shlx   %rdi,%rax,%rax
 1f828b1:	shr    $0x6,%edi
 1f828b4:	or     %rax,(%r8,%rdi,8)
 1f828b8:	jmp    1f82770 <node_facts_window_run+0x53a0>
 1f828bd:	shlq   $0x20,0xf8(%rsp)
 1f828c6:	shlq   $0x20,0x770(%rsp)
 1f828cf:	shlq   $0x20,0x730(%rsp)
 1f828d8:	shlq   $0x20,0x38(%rsp)
 1f828de:	lea    0x8a0(%rsp),%rdi
 1f828e6:	mov    $0x418,%edx
 1f828eb:	mov    0xc8(%rsp),%rbx
 1f828f3:	mov    %rbx,%rsi
 1f828f6:	vzeroupper
 1f828f9:	call   355eab0 <memcpy>
 1f828fe:	mov    0x1f0(%rsp),%rax
 1f82906:	movb   $0x0,0x5b(%rbx)
 1f8290a:	test   %eax,%eax
 1f8290c:	je     1f82bbf <node_facts_window_run+0x57ef>
 1f82912:	mov    (%rsp),%rdi
 1f82916:	mov    %eax,%r14d
 1f82919:	xor    %r15d,%r15d
 1f8291c:	jmp    1f82963 <node_facts_window_run+0x5593>
 1f8291e:	xchg   %ax,%ax
 1f82920:	movzbl 0x7b0(%rsp),%ecx
 1f82928:	mov    (%rsp),%rdi
 1f8292c:	xor    %edx,%edx
 1f8292e:	add    %rdx,0x8a0(%r8)
 1f82935:	mov    %rax,0x50(%r12)
 1f8293a:	mov    %cl,0x60(%r12)
 1f8293f:	inc    %r15
 1f82942:	mov    0x56c(%r13),%eax
 1f82949:	mov    %eax,0x58(%r12)
 1f8294e:	mov    0x570(%r13),%eax
 1f82955:	mov    %eax,0x5c(%r12)
 1f8295a:	cmp    %r15,%r14
 1f8295d:	je     1f82b5b <node_facts_window_run+0x578b>
 1f82963:	mov    0xbe8(%r13),%rax
 1f8296a:	mov    0xa68(%rdi),%r8
 1f82971:	mov    0xa70(%rdi),%rcx
 1f82978:	mov    (%rax,%r15,4),%r12d
 1f8297c:	mov    0xa58(%rdi),%rax
 1f82983:	mov    (%r8,%r12,4),%ebp
 1f82987:	mov    (%rcx,%r12,4),%r13d
 1f8298b:	mov    0xa48(%rdi),%r8
 1f82992:	mov    0xa50(%rdi),%rcx
 1f82999:	mov    0xc8(%rsp),%rdi
 1f829a1:	mov    (%rcx,%r12,4),%ebx
 1f829a5:	mov    (%r8,%r12,4),%esi
 1f829a9:	mov    (%rax,%r12,4),%ecx
 1f829ad:	mov    %ebx,%edx
 1f829af:	call   1f53100 <node_machine_type>
 1f829b4:	mov    (%rsp),%rax
 1f829b8:	mov    0x20(%rsp),%rcx
 1f829bd:	mov    0xa58(%rax),%rax
 1f829c4:	mov    (%rax,%r12,4),%eax
 1f829c8:	cmp    0x651b8(%rcx,%r13,4),%eax
 1f829d0:	jbe    1f82a0d <node_facts_window_run+0x563d>
 1f829d2:	inc    %r13d
 1f829d5:	cmp    %r13d,%ebp
 1f829d8:	je     1f82a0d <node_facts_window_run+0x563d>
 1f829da:	mov    0x8(%rsp),%rsi
 1f829df:	mov    %r13d,%eax
 1f829e2:	mov    0xb70(%rsi),%rdx
 1f829e9:	mov    0xb88(%rsi),%rcx
 1f829f0:	mov    0xb80(%rsi),%rsi
 1f829f7:	movzbl (%rdx,%rbp,1),%edi
 1f829fb:	mov    %dil,(%rdx,%rax,1)
 1f829ff:	movzbl (%rsi,%rbp,1),%edx
 1f82a03:	mov    %dl,(%rsi,%rax,1)
 1f82a06:	movzbl (%rcx,%rbp,1),%edx
 1f82a0a:	mov    %dl,(%rcx,%rax,1)
 1f82a0d:	mov    0x20(%rsp),%rax
 1f82a12:	xor    %r9d,%r9d
 1f82a15:	mov    0x30(%rsp),%rdx
 1f82a1a:	mov    $0xffffffff,%r8d
 1f82a20:	mov    0x422c(%rax,%rbp,4),%ecx
 1f82a27:	cmpb   $0x23,0x2c(%rax,%rbp,1)
 1f82a2c:	jne    1f82a70 <node_facts_window_run+0x56a0>
 1f82a2e:	mov    0x8(%rsp),%r13
 1f82a33:	cmp    0xc0(%rsp),%ecx
 1f82a3a:	jae    1f82a75 <node_facts_window_run+0x56a5>
 1f82a3c:	mov    0xb8(%rsp),%rsi
 1f82a44:	mov    0x338(%rsi),%rax
 1f82a4b:	mov    (%rsi),%rdi
 1f82a4e:	mov    (%rax,%rcx,4),%r8d
 1f82a52:	cmp    0x764(%rdi),%r8d
 1f82a59:	jae    1f82a75 <node_facts_window_run+0x56a5>
 1f82a5b:	mov    0x1e8(%rsi),%rax
 1f82a62:	mov    (%rax,%r8,4),%r9d
 1f82a66:	jmp    1f82a75 <node_facts_window_run+0x56a5>
 1f82a68:	nopl   0x0(%rax,%rax,1)
 1f82a70:	mov    0x8(%rsp),%r13
 1f82a75:	imul   $0x68,%r12,%r12
 1f82a79:	movb   $0x0,0x7b0(%rsp)
 1f82a81:	add    %rdx,%r12
 1f82a84:	cmpb   $0x0,0x90(%rsp)
 1f82a8c:	je     1f82ab0 <node_facts_window_run+0x56e0>
 1f82a8e:	mov    0x10(%r12),%rax
 1f82a93:	sub    0xbd8(%r13),%rax
 1f82a9a:	add    0xbe0(%r13),%rax
 1f82aa1:	jmp    1f82ab2 <node_facts_window_run+0x56e2>
 1f82aa3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82ab0:	xor    %eax,%eax
 1f82ab2:	movzbl 0x90(%rsp),%edx
 1f82aba:	mov    %rax,0x508(%r13)
 1f82ac1:	mov    0xd0(%rsp),%rax
 1f82ac9:	mov    %r13,%rdi
 1f82acc:	mov    %ebx,%esi
 1f82ace:	mov    %dl,0x510(%r13)
 1f82ad5:	movzbl (%rax,%rbp,1),%edx
 1f82ad9:	push   %r12
 1f82adb:	lea    0x7b8(%rsp),%rax
 1f82ae3:	push   %rax
 1f82ae4:	call   1f549e0 <node_census_reader_expression>
 1f82ae9:	add    $0x10,%rsp
 1f82aed:	cmpb   $0x1,0x62(%r12)
 1f82af3:	mov    0x40(%rsp),%r8
 1f82af8:	adcq   $0x0,0x898(%r8)
 1f82b00:	cmpb   $0x0,0x62(%r12)
 1f82b06:	jne    1f82920 <node_facts_window_run+0x5550>
 1f82b0c:	movzbl 0x7b0(%rsp),%ecx
 1f82b14:	mov    (%rsp),%rdi
 1f82b18:	mov    $0x1,%edx
 1f82b1d:	cmp    0x50(%r12),%rax
 1f82b22:	jne    1f8292e <node_facts_window_run+0x555e>
 1f82b28:	cmp    0x60(%r12),%cl
 1f82b2d:	jne    1f8292e <node_facts_window_run+0x555e>
 1f82b33:	mov    0x56c(%r13),%esi
 1f82b3a:	cmp    0x58(%r12),%esi
 1f82b3f:	jne    1f8292e <node_facts_window_run+0x555e>
 1f82b45:	mov    0x570(%r13),%esi
 1f82b4c:	xor    %edx,%edx
 1f82b4e:	cmp    0x5c(%r12),%esi
 1f82b53:	setne  %dl
 1f82b56:	jmp    1f8292e <node_facts_window_run+0x555e>
 1f82b5b:	rdtsc
 1f82b5d:	xor    %ebx,%ebx
 1f82b5f:	mov    %rdi,%r15
 1f82b62:	shl    $0x20,%rdx
 1f82b66:	or     %rax,%rdx
 1f82b69:	mov    %rdx,0x110(%rsp)
 1f82b71:	mov    0xc8(%rsp),%r12
 1f82b79:	nopl   0x0(%rax)
 1f82b80:	mov    0xbe8(%r13),%rax
 1f82b87:	mov    0xa48(%r15),%rcx
 1f82b8e:	mov    0xa50(%r15),%rdx
 1f82b95:	mov    %r12,%rdi
 1f82b98:	mov    (%rax,%rbx,4),%eax
 1f82b9b:	mov    (%rcx,%rax,4),%esi
 1f82b9e:	mov    0xa58(%r15),%rcx
 1f82ba5:	mov    (%rdx,%rax,4),%edx
 1f82ba8:	mov    (%rcx,%rax,4),%ecx
 1f82bab:	call   1f53100 <node_machine_type>
 1f82bb0:	inc    %rbx
 1f82bb3:	cmp    %rbx,%r14
 1f82bb6:	jne    1f82b80 <node_facts_window_run+0x57b0>
 1f82bb8:	mov    0x20(%rsp),%rbp
 1f82bbd:	jmp    1f82bd0 <node_facts_window_run+0x5800>
 1f82bbf:	rdtsc
 1f82bc1:	shl    $0x20,%rdx
 1f82bc5:	or     %rax,%rdx
 1f82bc8:	mov    %rdx,0x110(%rsp)
 1f82bd0:	mov    0xf8(%rsp),%rax
 1f82bd8:	lea    0x8a0(%rsp),%rsi
 1f82be0:	or     %rax,0x100(%rsp)
 1f82be8:	mov    0x770(%rsp),%rax
 1f82bf0:	or     %rax,0x88(%rsp)
 1f82bf8:	rdtsc
 1f82bfa:	mov    0x730(%rsp),%rcx
 1f82c02:	shl    $0x20,%rdx
 1f82c06:	or     %rcx,0x420(%rsp)
 1f82c0e:	mov    0x38(%rsp),%rcx
 1f82c13:	or     %rcx,0x28(%rsp)
 1f82c18:	or     %rax,%rdx
 1f82c1b:	mov    %rdx,0x38(%rsp)
 1f82c20:	mov    $0x418,%edx
 1f82c25:	mov    0xc8(%rsp),%rdi
 1f82c2d:	call   355eab0 <memcpy>
 1f82c32:	mov    (%rsp),%r11
 1f82c36:	cmpl   $0x0,0xa90(%r11)
 1f82c3e:	je     1f82ed3 <node_facts_window_run+0x5b03>
 1f82c44:	xorb   $0x1,0x90(%rsp)
 1f82c4c:	xor    %r14d,%r14d
 1f82c4f:	xor    %eax,%eax
 1f82c51:	mov    0x30(%rsp),%r10
 1f82c56:	mov    0x40(%rsp),%r8
 1f82c5b:	add    $0x62,%r10
 1f82c5f:	jmp    1f82c8d <node_facts_window_run+0x58bd>
 1f82c61:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82c70:	mov    %rax,%r15
 1f82c73:	mov    0xa90(%r11),%ecx
 1f82c7a:	inc    %r14
 1f82c7d:	add    $0x68,%r10
 1f82c81:	mov    %r15,%rax
 1f82c84:	cmp    %rcx,%r14
 1f82c87:	jae    1f82edb <node_facts_window_run+0x5b0b>
 1f82c8d:	cmpb   $0x0,-0x1(%r10)
 1f82c92:	je     1f82c70 <node_facts_window_run+0x58a0>
 1f82c94:	xor    %edx,%edx
 1f82c96:	cmpb   $0x0,(%r10)
 1f82c9a:	mov    0xa70(%r11),%rcx
 1f82ca1:	sete   %dl
 1f82ca4:	mov    (%rcx,%r14,4),%ecx
 1f82ca8:	add    %rdx,0x890(%r8)
 1f82caf:	and    0x90(%rsp),%dl
 1f82cb6:	movzbl %dl,%edx
 1f82cb9:	add    %rdx,0x690(%r8)
 1f82cc0:	cmp    $0x1,%dl
 1f82cc3:	jne    1f82ce0 <node_facts_window_run+0x5910>
 1f82cc5:	mov    0xa58(%r11),%rdx
 1f82ccc:	mov    (%rdx,%r14,4),%edx
 1f82cd0:	jmp    1f82ce2 <node_facts_window_run+0x5912>
 1f82cd2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82ce0:	xor    %edx,%edx
 1f82ce2:	add    %rdx,0x698(%r8)
 1f82ce9:	mov    0xa58(%r11),%rdx
 1f82cf0:	mov    (%rdx,%r14,4),%edx
 1f82cf4:	cmp    0x651b8(%rbp,%rcx,4),%edx
 1f82cfb:	jbe    1f82d20 <node_facts_window_run+0x5950>
 1f82cfd:	mov    0xa68(%r11),%rdx
 1f82d04:	inc    %ecx
 1f82d06:	xor    %r15d,%r15d
 1f82d09:	cmp    %ecx,(%rdx,%r14,4)
 1f82d0d:	setne  %r15b
 1f82d11:	jmp    1f82d23 <node_facts_window_run+0x5953>
 1f82d13:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82d20:	xor    %r15d,%r15d
 1f82d23:	mov    0xa50(%r11),%rcx
 1f82d2a:	mov    0x240(%r8),%rdx
 1f82d31:	mov    (%rcx,%r14,4),%ebx
 1f82d35:	mov    (%rdx,%rbx,8),%r12
 1f82d39:	cmp    %r12,-0x12(%r10)
 1f82d3d:	jne    1f82d80 <node_facts_window_run+0x59b0>
 1f82d3f:	mov    0x248(%r8),%rdx
 1f82d46:	movzbl -0x2(%r10),%ecx
 1f82d4b:	cmp    (%rdx,%rbx,1),%cl
 1f82d4e:	jne    1f82d80 <node_facts_window_run+0x59b0>
 1f82d50:	mov    0xbb0(%r13),%rdx
 1f82d57:	mov    -0xa(%r10),%ecx
 1f82d5b:	cmp    (%rdx,%rbx,4),%ecx
 1f82d5e:	jne    1f82d80 <node_facts_window_run+0x59b0>
 1f82d60:	mov    0xbb8(%r13),%rdx
 1f82d67:	mov    -0x6(%r10),%ecx
 1f82d6b:	cmp    (%rdx,%rbx,4),%ecx
 1f82d6e:	sete   %cl
 1f82d71:	jmp    1f82d82 <node_facts_window_run+0x59b2>
 1f82d73:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82d80:	xor    %ecx,%ecx
 1f82d82:	incq   0xa50(%r8)
 1f82d89:	add    %rax,%r15
 1f82d8c:	mov    %ecx,%edx
 1f82d8e:	mov    0xa58(%r11),%rax
 1f82d95:	xor    $0x1,%dl
 1f82d98:	vmovd  (%rax,%r14,4),%xmm0
 1f82d9e:	movzbl %dl,%eax
 1f82da1:	vmovd  %eax,%xmm1
 1f82da5:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f82da9:	vpaddq 0xa58(%r8),%xmm0,%xmm0
 1f82db2:	vmovdqu %xmm0,0xa58(%r8)
 1f82dbb:	test   %cl,%cl
 1f82dbd:	jne    1f82c73 <node_facts_window_run+0x58a3>
 1f82dc3:	mov    0x12e4(%r8),%eax
 1f82dca:	cmp    0x5004ad4(%rip),%eax        # 6f878a4 <node_census_list>
 1f82dd0:	jae    1f82c73 <node_facts_window_run+0x58a3>
 1f82dd6:	inc    %eax
 1f82dd8:	xor    %esi,%esi
 1f82dda:	mov    %eax,0x12e4(%r8)
 1f82de1:	mov    0xa68(%r11),%rcx
 1f82de8:	mov    0x0(%r13),%rax
 1f82dec:	mov    (%rcx,%r14,4),%ecx
 1f82df0:	mov    0x18(%rax),%rax
 1f82df4:	mov    0x422c(%rbp,%rcx,4),%ecx
 1f82dfb:	cmp    0x78(%rax),%ecx
 1f82dfe:	jae    1f82e48 <node_facts_window_run+0x5a78>
 1f82e00:	mov    0x68(%rax),%rax
 1f82e04:	mov    0x8(%r13),%rdi
 1f82e08:	mov    (%rax,%rcx,4),%eax
 1f82e0b:	cmp    0x1538(%rdi),%eax
 1f82e11:	jae    1f82e48 <node_facts_window_run+0x5a78>
 1f82e13:	mov    0x1530(%rdi),%rcx
 1f82e1a:	test   %rcx,%rcx
 1f82e1d:	je     1f82e48 <node_facts_window_run+0x5a78>
 1f82e1f:	mov    (%rcx,%rax,4),%esi
 1f82e22:	lea    0x7b0(%rsp),%rdx
 1f82e2a:	lea    0x500(%rsp),%rcx
 1f82e32:	mov    %r10,%r13
 1f82e35:	call   111f9b0 <pp_presumed>
 1f82e3a:	mov    0x40(%rsp),%r8
 1f82e3f:	mov    (%rsp),%r11
 1f82e43:	mov    %r13,%r10
 1f82e46:	mov    %eax,%esi
 1f82e48:	mov    0xa58(%r11),%rax
 1f82e4f:	mov    -0x12(%r10),%rcx
 1f82e53:	movzbl -0x2(%r10),%r9d
 1f82e58:	mov    %r10,%rbp
 1f82e5b:	mov    (%rax,%r14,4),%edx
 1f82e5f:	mov    0x248(%r8),%rax
 1f82e66:	movzbl (%rax,%rbx,1),%eax
 1f82e6a:	mov    %rax,0x10(%rsp)
 1f82e6f:	mov    -0xa(%r10),%eax
 1f82e73:	mov    -0x6(%r10),%r10d
 1f82e77:	mov    %rax,0x18(%rsp)
 1f82e7c:	mov    0x8(%rsp),%r13
 1f82e81:	mov    0xbb0(%r13),%rax
 1f82e88:	mov    0xbb8(%r13),%rdi
 1f82e8f:	mov    (%rax,%rbx,4),%r11d
 1f82e93:	mov    (%rdi,%rbx,4),%ebx
 1f82e96:	sub    $0x8,%rsp
 1f82e9a:	mov    %r12,%r8
 1f82e9d:	lea    -0x196200c(%rip),%rdi        # 620e98 <.str.11115>
 1f82ea4:	xor    %eax,%eax
 1f82ea6:	push   %rbx
 1f82ea7:	push   %r11
 1f82ea9:	push   %r10
 1f82eab:	push   0x38(%rsp)
 1f82eaf:	push   0x38(%rsp)
 1f82eb3:	call   34ef1d0 <_IO_printf>
 1f82eb8:	mov    0x70(%rsp),%r8
 1f82ebd:	mov    0x30(%rsp),%r11
 1f82ec2:	mov    %rbp,%r10
 1f82ec5:	add    $0x30,%rsp
 1f82ec9:	mov    0x20(%rsp),%rbp
 1f82ece:	jmp    1f82c73 <node_facts_window_run+0x58a3>
 1f82ed3:	mov    0x40(%rsp),%r8
 1f82ed8:	xor    %r15d,%r15d
 1f82edb:	vpmovsxbq -0x1acc11d(%rip),%xmm0        # 4b6dc7 <abi_test_hex.digits+0xba47>
 1f82ee4:	vmovd  0x8(%rbp),%xmm2
 1f82ee9:	mov    0x110(%rsp),%rcx
 1f82ef1:	mov    0x38(%rsp),%r9
 1f82ef6:	mov    0x28(%rsp),%rdi
 1f82efb:	vmovq  %r15,%xmm1
 1f82f00:	xor    %eax,%eax
 1f82f02:	mov    0x88(%rsp),%rdx
 1f82f0a:	mov    0x420(%rsp),%rsi
 1f82f12:	mov    0xd8(%rsp),%r15
 1f82f1a:	sub    %rcx,%r9
 1f82f1d:	sub    %rdi,%rcx
 1f82f20:	sub    %r9,%rcx
 1f82f23:	cmovae %rcx,%rax
 1f82f27:	mov    0x100(%rsp),%rcx
 1f82f2f:	sub    %rdx,%rsi
 1f82f32:	vpinsrq $0x0,%r9,%xmm0,%xmm0
 1f82f38:	vpunpcklqdq %xmm1,%xmm2,%xmm1
 1f82f3c:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f82f42:	vpaddq 0xa98(%r8),%ymm0,%ymm0
 1f82f4b:	vmovq  %rsi,%xmm1
 1f82f50:	sub    %rcx,%rdi
 1f82f53:	sub    %rcx,%rdx
 1f82f56:	add    %rax,%rdi
 1f82f59:	vmovq  %rdx,%xmm2
 1f82f5e:	vmovdqu %ymm0,0xa98(%r8)
 1f82f67:	vmovq  %rax,%xmm0
 1f82f6c:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f82f70:	vmovq  %rdi,%xmm1
 1f82f75:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f82f79:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f82f7f:	vpaddq 0xa68(%r8),%ymm0,%ymm0
 1f82f88:	vmovdqu %ymm0,0xa68(%r8)
 1f82f91:	cmpq   $0x0,0xb40(%r11)
 1f82f99:	je     1f84c3c <node_facts_window_run+0x786c>
 1f82f9f:	mov    0x940(%r11),%r12
 1f82fa6:	mov    0x8(%rbp),%ebx
 1f82fa9:	rdtsc
 1f82fab:	lea    0x8a0(%rsp),%rcx
 1f82fb3:	vpxor  %xmm0,%xmm0,%xmm0
 1f82fb7:	vmovdqu64 %zmm0,0x8c0(%rsp)
 1f82fbf:	vmovdqu64 %zmm0,0x8a0(%rsp)
 1f82fca:	mov    %r11,%rdi
 1f82fcd:	mov    %rbp,%rsi
 1f82fd0:	shl    $0x20,%rdx
 1f82fd4:	or     %rax,%rdx
 1f82fd7:	mov    %rdx,0x30(%rsp)
 1f82fdc:	mov    %ebx,%edx
 1f82fde:	vzeroupper
 1f82fe1:	call   1f93c40 <node_contexts_window_loop>
 1f82fe6:	vmovups 0x8c8(%rsp),%ymm0
 1f82fef:	vmovdqu 0x8c8(%rsp),%xmm1
 1f82ff8:	mov    %rbp,%rsi
 1f82ffb:	vmovups %ymm0,0x1b0(%rsp)
 1f83004:	vpbroadcastq 0x8d8(%rsp),%ymm0
 1f8300e:	mov    (%rsp),%rax
 1f83012:	vpsubq %xmm0,%xmm1,%xmm0
 1f83016:	vpaddq 0x8d8(%rsp),%xmm0,%xmm0
 1f8301f:	vpblendd $0xc,%xmm0,%xmm1,%xmm0
 1f83025:	vmovdqu %xmm0,0xc08(%rax)
 1f8302d:	rdtsc
 1f8302f:	shl    $0x20,%rdx
 1f83033:	or     %rax,%rdx
 1f83036:	mov    %rdx,0x40(%rsp)
 1f8303b:	mov    %ebx,%edx
 1f8303d:	mov    (%rsp),%rdi
 1f83041:	vzeroupper
 1f83044:	call   1f95bf0 <node_contexts_window_targets>
 1f83049:	rdtsc
 1f8304b:	mov    %rbp,%rsi
 1f8304e:	shl    $0x20,%rdx
 1f83052:	or     %rax,%rdx
 1f83055:	mov    %rdx,0xc8(%rsp)
 1f8305d:	mov    (%rsp),%rdi
 1f83061:	call   1f95f80 <node_contexts_window_part>
 1f83066:	rdtsc
 1f83068:	lea    0x7b0(%rsp),%rcx
 1f83070:	vpxor  %xmm0,%xmm0,%xmm0
 1f83074:	vmovdqu64 %zmm0,0x7d0(%rsp)
 1f8307f:	vmovdqu64 %zmm0,0x7b0(%rsp)
 1f8308a:	mov    %rbp,%rsi
 1f8308d:	shl    $0x20,%rdx
 1f83091:	or     %rax,%rdx
 1f83094:	mov    %rdx,0xd0(%rsp)
 1f8309c:	mov    %ebx,%edx
 1f8309e:	mov    (%rsp),%rdi
 1f830a2:	vzeroupper
 1f830a5:	call   1f93c40 <node_contexts_window_loop>
 1f830aa:	rdtsc
 1f830ac:	mov    %rbp,%rsi
 1f830af:	shl    $0x20,%rdx
 1f830b3:	or     %rax,%rdx
 1f830b6:	mov    %rdx,0xc0(%rsp)
 1f830be:	mov    %ebx,%edx
 1f830c0:	mov    (%rsp),%rdi
 1f830c4:	call   1f95bf0 <node_contexts_window_targets>
 1f830c9:	rdtsc
 1f830cb:	mov    %rbp,%rsi
 1f830ce:	shl    $0x20,%rdx
 1f830d2:	or     %rax,%rdx
 1f830d5:	mov    %rdx,0xb8(%rsp)
 1f830dd:	mov    (%rsp),%rdi
 1f830e1:	call   1f95f80 <node_contexts_window_part>
 1f830e6:	mov    (%rsp),%r11
 1f830ea:	rdtsc
 1f830ec:	shl    $0x20,%rdx
 1f830f0:	or     %rax,%rdx
 1f830f3:	cmpl   $0x0,0xa90(%r11)
 1f830fb:	mov    %rdx,0x60(%rsp)
 1f83100:	mov    %rbx,0x170(%rsp)
 1f83108:	je     1f83639 <node_facts_window_run+0x6269>
 1f8310e:	vpbroadcastq -0x19b4b7f(%rip),%xmm0        # 5ce598 <.LCPI3_1>
 1f83117:	xor    %ebx,%ebx
 1f83119:	xor    %edi,%edi
 1f8311b:	mov    %r12,0x28(%rsp)
 1f83120:	jmp    1f83143 <node_facts_window_run+0x5d73>
 1f83122:	mov    (%rsp),%r11
 1f83126:	xor    %esi,%esi
 1f83128:	incq   0x12e8(%r12,%rsi,8)
 1f83130:	mov    0xa90(%r11),%eax
 1f83137:	inc    %rdi
 1f8313a:	cmp    %rax,%rdi
 1f8313d:	jae    1f8363b <node_facts_window_run+0x626b>
 1f83143:	mov    0xb80(%r11),%rax
 1f8314a:	movzbl (%rax,%rdi,1),%r8d
 1f8314f:	test   %r8b,%r8b
 1f83152:	je     1f83130 <node_facts_window_run+0x5d60>
 1f83154:	mov    0xa70(%r11),%rcx
 1f8315b:	mov    0xa68(%r11),%rax
 1f83162:	mov    (%rcx,%rdi,4),%ecx
 1f83165:	mov    (%rax,%rdi,4),%r13d
 1f83169:	mov    0x651b8(%rbp,%rcx,4),%esi
 1f83170:	incq   0xab8(%r12)
 1f83178:	mov    0xa58(%r11),%rax
 1f8317f:	mov    (%rax,%rdi,4),%eax
 1f83182:	add    %rax,0xac0(%r12)
 1f8318a:	cmp    $0x1,%r8b
 1f8318e:	jne    1f831e0 <node_facts_window_run+0x5e10>
 1f83190:	mov    0xa58(%r11),%rax
 1f83197:	mov    (%rax,%rdi,4),%r10d
 1f8319b:	test   %r10d,%r10d
 1f8319e:	je     1f83126 <node_facts_window_run+0x5d56>
 1f831a0:	mov    0xbe8(%r11),%rax
 1f831a7:	sub    %esi,%ecx
 1f831a9:	xor    %r11d,%r11d
 1f831ac:	inc    %ecx
 1f831ae:	xchg   %ax,%ax
 1f831b0:	lea    (%rcx,%r11,1),%r9d
 1f831b4:	cmp    %esi,%r11d
 1f831b7:	cmovae %r13d,%r9d
 1f831bb:	mov    %r9d,%edx
 1f831be:	shr    $0x3,%edx
 1f831c1:	and    $0xfffffff8,%edx
 1f831c4:	mov    0x10(%rax,%rdx,8),%r8
 1f831c9:	bt     %r9,%r8
 1f831cd:	jb     1f8325f <node_facts_window_run+0x5e8f>
 1f831d3:	inc    %r11d
 1f831d6:	cmp    %r11d,%r10d
 1f831d9:	jne    1f831b0 <node_facts_window_run+0x5de0>
 1f831db:	jmp    1f83122 <node_facts_window_run+0x5d52>
 1f831e0:	mov    0xa58(%r11),%rcx
 1f831e7:	mov    0xb68(%r11),%rdx
 1f831ee:	cmp    $0x3,%r8b
 1f831f2:	sete   %al
 1f831f5:	mov    (%rcx,%rdi,4),%r9d
 1f831f9:	movzbl (%rdx,%rdi,1),%r10d
 1f831fe:	test   %r9,%r9
 1f83201:	sete   %cl
 1f83204:	cmp    $0x2,%r10b
 1f83208:	sete   %dl
 1f8320b:	or     %al,%dl
 1f8320d:	or     %cl,%dl
 1f8320f:	je     1f83219 <node_facts_window_run+0x5e49>
 1f83211:	xor    %r14d,%r14d
 1f83214:	jmp    1f8354a <node_facts_window_run+0x617a>
 1f83219:	mov    0xa70(%r11),%rcx
 1f83220:	mov    0xa68(%r11),%rax
 1f83227:	mov    %r13,0x18(%rsp)
 1f8322c:	mov    0xbe8(%r11),%r12
 1f83233:	mov    %rbx,0x10(%rsp)
 1f83238:	mov    (%rcx,%rdi,4),%ecx
 1f8323b:	mov    (%rax,%rdi,4),%r13d
 1f8323f:	mov    0xb48(%r11),%rax
 1f83246:	mov    0x651b8(%rbp,%rcx,4),%ebp
 1f8324d:	sub    %ebp,%ecx
 1f8324f:	cmp    $0x1,%r9d
 1f83253:	jne    1f832ae <node_facts_window_run+0x5ede>
 1f83255:	xor    %r14d,%r14d
 1f83258:	xor    %ebx,%ebx
 1f8325a:	jmp    1f834a0 <node_facts_window_run+0x60d0>
 1f8325f:	mov    (%rsp),%r11
 1f83263:	mov    %r9d,%esi
 1f83266:	mov    0xbd0(%r11),%rcx
 1f8326d:	movzbl (%rcx,%rsi,1),%ecx
 1f83271:	mov    $0x1,%esi
 1f83276:	cmp    $0xd,%ecx
 1f83279:	je     1f83128 <node_facts_window_run+0x5d58>
 1f8327f:	lea    -0xf(%rcx),%r8d
 1f83283:	mov    $0x2,%esi
 1f83288:	cmp    $0x2,%r8b
 1f8328c:	jb     1f83128 <node_facts_window_run+0x5d58>
 1f83292:	cmp    $0xe,%ecx
 1f83295:	je     1f835f3 <node_facts_window_run+0x6223>
 1f8329b:	cmp    $0x11,%ecx
 1f8329e:	jne    1f835fd <node_facts_window_run+0x622d>
 1f832a4:	mov    $0x4,%esi
 1f832a9:	jmp    1f83128 <node_facts_window_run+0x5d58>
 1f832ae:	mov    %r9d,%edx
 1f832b1:	and    $0xfffffffe,%edx
 1f832b4:	mov    %r10b,0x110(%rsp)
 1f832bc:	mov    %r8b,0x38(%rsp)
 1f832c1:	mov    %r9,0x90(%rsp)
 1f832c9:	xor    %r14d,%r14d
 1f832cc:	xor    %r15d,%r15d
 1f832cf:	mov    %edx,0x8(%rsp)
 1f832d3:	lea    0x2(%rcx),%edx
 1f832d6:	mov    %rcx,0x70(%rsp)
 1f832db:	jmp    1f832fa <node_facts_window_run+0x5f2a>
 1f832dd:	nopl   (%rax)
 1f832e0:	xor    %r11d,%r11d
 1f832e3:	add    %r10,%r14
 1f832e6:	add    $0x2,%edx
 1f832e9:	inc    %r15d
 1f832ec:	add    %r11,%r14
 1f832ef:	cmp    0x8(%rsp),%r15d
 1f832f4:	je     1f83443 <node_facts_window_run+0x6073>
 1f832fa:	mov    %r15d,%ebx
 1f832fd:	lea    -0x1(%rdx),%r15d
 1f83301:	cmp    %ebp,%ebx
 1f83303:	mov    $0x1,%r11d
 1f83309:	mov    $0x1,%r10d
 1f8330f:	cmovae %r13d,%r15d
 1f83313:	mov    %r15d,%esi
 1f83316:	and    $0xffffffc0,%esi
 1f83319:	movzbl (%rax,%r15,1),%r8d
 1f8331e:	shrx   %r15,(%r12,%rsi,1),%rsi
 1f83324:	and    $0x1,%r8d
 1f83328:	mov    %esi,%r9d
 1f8332b:	and    $0x1,%r9d
 1f8332f:	cmp    %r8d,%r9d
 1f83332:	jne    1f833a3 <node_facts_window_run+0x5fd3>
 1f83334:	test   $0x1,%sil
 1f83338:	je     1f833a0 <node_facts_window_run+0x5fd0>
 1f8333a:	mov    (%rsp),%rcx
 1f8333e:	mov    0xbb0(%rcx),%r8
 1f83345:	mov    0xb58(%rcx),%rsi
 1f8334c:	movzbl (%r8,%r15,1),%r8d
 1f83351:	cmp    (%rsi,%r15,1),%r8b
 1f83355:	jne    1f833a3 <node_facts_window_run+0x5fd3>
 1f83357:	mov    (%rsp),%rcx
 1f8335b:	mov    0xbc0(%rcx),%r8
 1f83362:	mov    0xb50(%rcx),%rsi
 1f83369:	movzbl (%r8,%r15,1),%r8d
 1f8336e:	cmp    (%rsi,%r15,1),%r8b
 1f83372:	jne    1f833a3 <node_facts_window_run+0x5fd3>
 1f83374:	mov    (%rsp),%rcx
 1f83378:	xor    %r10d,%r10d
 1f8337b:	mov    0xbd8(%rcx),%r8
 1f83382:	mov    0xb60(%rcx),%rsi
 1f83389:	mov    (%r8,%r15,4),%r8d
 1f8338d:	cmp    (%rsi,%r15,4),%r8d
 1f83391:	setne  %r10b
 1f83395:	jmp    1f833a3 <node_facts_window_run+0x5fd3>
 1f83397:	nopw   0x0(%rax,%rax,1)
 1f833a0:	xor    %r10d,%r10d
 1f833a3:	lea    0x1(%rbx),%r15d
 1f833a7:	mov    %r13d,%esi
 1f833aa:	cmp    %ebp,%r15d
 1f833ad:	cmovb  %edx,%esi
 1f833b0:	mov    %esi,%r8d
 1f833b3:	and    $0xffffffc0,%r8d
 1f833b7:	movzbl (%rax,%rsi,1),%r9d
 1f833bc:	shrx   %rsi,(%r12,%r8,1),%r8
 1f833c2:	and    $0x1,%r9d
 1f833c6:	mov    %r8d,%ecx
 1f833c9:	and    $0x1,%ecx
 1f833cc:	cmp    %r9d,%ecx
 1f833cf:	jne    1f832e3 <node_facts_window_run+0x5f13>
 1f833d5:	test   $0x1,%r8b
 1f833d9:	je     1f832e0 <node_facts_window_run+0x5f10>
 1f833df:	mov    (%rsp),%r9
 1f833e3:	mov    0xbb0(%r9),%r8
 1f833ea:	mov    0xb58(%r9),%rcx
 1f833f1:	movzbl (%r8,%rsi,1),%r8d
 1f833f6:	cmp    (%rcx,%rsi,1),%r8b
 1f833fa:	jne    1f832e3 <node_facts_window_run+0x5f13>
 1f83400:	mov    0xbc0(%r9),%r8
 1f83407:	mov    0xb50(%r9),%rcx
 1f8340e:	movzbl (%r8,%rsi,1),%r8d
 1f83413:	cmp    (%rcx,%rsi,1),%r8b
 1f83417:	jne    1f832e3 <node_facts_window_run+0x5f13>
 1f8341d:	mov    (%rsp),%r8
 1f83421:	xor    %r11d,%r11d
 1f83424:	mov    0xb60(%r8),%rcx
 1f8342b:	mov    0xbd8(%r8),%r8
 1f83432:	mov    (%r8,%rsi,4),%r8d
 1f83436:	cmp    (%rcx,%rsi,4),%r8d
 1f8343a:	setne  %r11b
 1f8343e:	jmp    1f832e3 <node_facts_window_run+0x5f13>
 1f83443:	mov    0x90(%rsp),%r9
 1f8344b:	mov    0xd8(%rsp),%r15
 1f83453:	test   $0x1,%r9b
 1f83457:	jne    1f83485 <node_facts_window_run+0x60b5>
 1f83459:	mov    (%rsp),%r11
 1f8345d:	mov    0x20(%rsp),%rbp
 1f83462:	mov    0x28(%rsp),%r12
 1f83467:	mov    0x10(%rsp),%rbx
 1f8346c:	mov    0x18(%rsp),%r13
 1f83471:	movzbl 0x38(%rsp),%r8d
 1f83477:	movzbl 0x110(%rsp),%r10d
 1f83480:	jmp    1f8354a <node_facts_window_run+0x617a>
 1f83485:	mov    (%rsp),%r11
 1f83489:	movzbl 0x38(%rsp),%r8d
 1f8348f:	movzbl 0x110(%rsp),%r10d
 1f83498:	mov    0x70(%rsp),%rcx
 1f8349d:	add    $0x2,%ebx
 1f834a0:	inc    %ecx
 1f834a2:	add    %ebx,%ecx
 1f834a4:	cmp    %ebp,%ebx
 1f834a6:	cmovb  %ecx,%r13d
 1f834aa:	mov    %r13d,%ecx
 1f834ad:	and    $0xffffffc0,%ecx
 1f834b0:	movzbl (%rax,%r13,1),%edx
 1f834b5:	mov    $0x1,%eax
 1f834ba:	shrx   %r13,(%r12,%rcx,1),%rcx
 1f834c0:	and    $0x1,%edx
 1f834c3:	mov    %ecx,%esi
 1f834c5:	and    $0x1,%esi
 1f834c8:	cmp    %edx,%esi
 1f834ca:	jne    1f8352f <node_facts_window_run+0x615f>
 1f834cc:	mov    0x20(%rsp),%rbp
 1f834d1:	mov    0x28(%rsp),%r12
 1f834d6:	mov    0x10(%rsp),%rbx
 1f834db:	test   $0x1,%cl
 1f834de:	je     1f83540 <node_facts_window_run+0x6170>
 1f834e0:	mov    0xbb0(%r11),%rdx
 1f834e7:	mov    0xb58(%r11),%rcx
 1f834ee:	movzbl (%rdx,%r13,1),%edx
 1f834f3:	cmp    (%rcx,%r13,1),%dl
 1f834f7:	jne    1f83542 <node_facts_window_run+0x6172>
 1f834f9:	mov    0xbc0(%r11),%rdx
 1f83500:	mov    0xb50(%r11),%rcx
 1f83507:	movzbl (%rdx,%r13,1),%edx
 1f8350c:	cmp    (%rcx,%r13,1),%dl
 1f83510:	jne    1f83542 <node_facts_window_run+0x6172>
 1f83512:	mov    0xbd8(%r11),%rax
 1f83519:	mov    0xb60(%r11),%rcx
 1f83520:	mov    (%rax,%r13,4),%edx
 1f83524:	xor    %eax,%eax
 1f83526:	cmp    (%rcx,%r13,4),%edx
 1f8352a:	setne  %al
 1f8352d:	jmp    1f83542 <node_facts_window_run+0x6172>
 1f8352f:	mov    0x20(%rsp),%rbp
 1f83534:	mov    0x28(%rsp),%r12
 1f83539:	mov    0x10(%rsp),%rbx
 1f8353e:	jmp    1f83542 <node_facts_window_run+0x6172>
 1f83540:	xor    %eax,%eax
 1f83542:	mov    0x18(%rsp),%r13
 1f83547:	add    %rax,%r14
 1f8354a:	cmp    $0x2,%r10b
 1f8354e:	sete   %al
 1f83551:	cmp    $0x3,%r8b
 1f83555:	sete   %cl
 1f83558:	xor    %cl,%al
 1f8355a:	test   %r14,%r14
 1f8355d:	vmovd  %ecx,%xmm1
 1f83561:	setne  %dl
 1f83564:	incq   0xac8(%r12)
 1f8356c:	add    %r9,%rbx
 1f8356f:	or     %al,%dl
 1f83571:	vpinsrb $0x1,%edx,%xmm1,%xmm1
 1f83577:	vpmovzxbq %xmm1,%xmm1
 1f8357c:	vptestmq %xmm0,%xmm1,%k0
 1f83582:	vmovdqu 0xad8(%r12),%xmm1
 1f8358c:	vpmovm2q %k0,%xmm2
 1f83592:	vpsubq %xmm2,%xmm1,%xmm1
 1f83596:	vmovdqu %xmm1,0xad8(%r12)
 1f835a0:	add    %r14,0xae8(%r12)
 1f835a8:	mov    0xb78(%r11),%rax
 1f835af:	mov    (%rax,%rdi,8),%rax
 1f835b3:	add    %rax,0xb30(%r12)
 1f835bb:	cmp    $0x1,%dl
 1f835be:	jne    1f83130 <node_facts_window_run+0x5d60>
 1f835c4:	mov    0x1368(%r12),%eax
 1f835cc:	cmp    $0xf,%rax
 1f835d0:	ja     1f83130 <node_facts_window_run+0x5d60>
 1f835d6:	mov    0x422c(%rbp,%r13,4),%ecx
 1f835de:	mov    %ecx,0x1328(%r12,%rax,4)
 1f835e6:	incl   0x1368(%r12)
 1f835ee:	jmp    1f83130 <node_facts_window_run+0x5d60>
 1f835f3:	mov    $0x3,%esi
 1f835f8:	jmp    1f83128 <node_facts_window_run+0x5d58>
 1f835fd:	mov    $0x1,%esi
 1f83602:	shlx   %r9,%rsi,%r8
 1f83607:	mov    $0x5,%esi
 1f8360c:	test   %r8,0x18(%rax,%rdx,8)
 1f83611:	jne    1f83128 <node_facts_window_run+0x5d58>
 1f83617:	mov    $0x6,%esi
 1f8361c:	test   %r8,0x20(%rax,%rdx,8)
 1f83621:	jne    1f83128 <node_facts_window_run+0x5d58>
 1f83627:	xor    %eax,%eax
 1f83629:	cmp    $0x7,%ecx
 1f8362c:	setne  %al
 1f8362f:	lea    0x2(%rax,%rax,4),%rsi
 1f83634:	jmp    1f83128 <node_facts_window_run+0x5d58>
 1f83639:	xor    %ebx,%ebx
 1f8363b:	add    %rbx,0xad0(%r12)
 1f83643:	mov    0xd0(%rsp),%rdx
 1f8364b:	mov    0xc8(%rsp),%rsi
 1f83653:	mov    0x40(%rsp),%rcx
 1f83658:	vmovd  0x170(%rsp),%xmm4
 1f83661:	vmovdqu 0xb78(%r12),%xmm0
 1f8366b:	vmovq  0x8c0(%rsp),%xmm1
 1f83674:	vpaddq 0x8e8(%rsp),%xmm0,%xmm0
 1f8367d:	vmovdqu %xmm0,0xb78(%r12)
 1f83687:	mov    0x8f8(%rsp),%rax
 1f8368f:	add    %rax,0xb88(%r12)
 1f83697:	mov    %rdx,%rax
 1f8369a:	sub    %rsi,%rax
 1f8369d:	sub    %rcx,%rsi
 1f836a0:	sub    0x30(%rsp),%rcx
 1f836a5:	vmovdqu64 0x8a0(%rsp),%zmm0
 1f836b0:	vmovq  %rax,%xmm2
 1f836b5:	vmovq  %rsi,%xmm3
 1f836ba:	mov    0x60(%rsp),%rsi
 1f836bf:	mov    0xc0(%rsp),%rax
 1f836c7:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f836cb:	vmovq  %rcx,%xmm3
 1f836d0:	mov    0xb8(%rsp),%rcx
 1f836d8:	vpunpcklqdq %xmm3,%xmm4,%xmm3
 1f836dc:	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
 1f836e2:	vshufi64x2 $0x44,%zmm2,%zmm0,%zmm0
 1f836e9:	vpaddq 0xaf0(%r12),%zmm0,%zmm0
 1f836f4:	sub    %rcx,%rsi
 1f836f7:	sub    %rax,%rcx
 1f836fa:	sub    %rdx,%rax
 1f836fd:	vmovq  %rsi,%xmm3
 1f83702:	vmovq  %rax,%xmm2
 1f83707:	vpunpcklqdq %xmm1,%xmm3,%xmm1
 1f8370b:	vmovdqu64 %zmm0,0xaf0(%r12)
 1f83716:	vmovq  %rcx,%xmm0
 1f8371b:	vpunpcklqdq %xmm0,%xmm2,%xmm0
 1f8371f:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f83725:	vinserti64x4 $0x1,0x1b0(%rsp),%zmm0,%zmm0
 1f83731:	vpaddq 0xb38(%r12),%zmm0,%zmm0
 1f8373c:	vmovdqu64 %zmm0,0xb38(%r12)
 1f83747:	cmpq   $0x0,0xc20(%r11)
 1f8374f:	je     1f84c3c <node_facts_window_run+0x786c>
 1f83755:	mov    0x940(%r11),%rax
 1f8375c:	mov    0x8(%rbp),%r12d
 1f83760:	vpxor  %xmm0,%xmm0,%xmm0
 1f83764:	vmovdqu %ymm0,0x8a0(%rsp)
 1f8376d:	movq   $0x0,0x8c0(%rsp)
 1f83779:	mov    %r11,%rdi
 1f8377c:	mov    %rax,0x60(%rsp)
 1f83781:	rdtsc
 1f83783:	mov    %r12d,%esi
 1f83786:	mov    %rdx,0x320(%rsp)
 1f8378e:	lea    0x8a0(%rsp),%rdx
 1f83796:	mov    %rax,%r14
 1f83799:	vzeroupper
 1f8379c:	call   1f96360 <node_rows_window_reads>
 1f837a1:	rdtsc
 1f837a3:	mov    %rbp,%rsi
 1f837a6:	mov    %rdx,0x480(%rsp)
 1f837ae:	mov    %r12d,%edx
 1f837b1:	mov    (%rsp),%rdi
 1f837b5:	mov    %rax,%r15
 1f837b8:	call   1f96a80 <node_rows_window_shapes>
 1f837bd:	mov    (%rsp),%rdi
 1f837c1:	rdtsc
 1f837c3:	mov    0xc10(%rdi),%rcx
 1f837ca:	or     0xc08(%rdi),%rcx
 1f837d1:	mov    %rax,0x58(%rsp)
 1f837d6:	mov    %rdx,0x3e0(%rsp)
 1f837de:	je     1f837f7 <node_facts_window_run+0x6427>
 1f837e0:	lea    0x8a0(%rsp),%rcx
 1f837e8:	mov    %rbp,%rsi
 1f837eb:	mov    %r12d,%edx
 1f837ee:	call   1f96eb0 <node_rows_window_updates>
 1f837f3:	mov    (%rsp),%rdi
 1f837f7:	rdtsc
 1f837f9:	mov    %rbp,%rsi
 1f837fc:	mov    %rdx,0x2e0(%rsp)
 1f83804:	mov    %r12d,%edx
 1f83807:	mov    %rax,0x3a0(%rsp)
 1f8380f:	call   1f976c0 <node_rows_window_write>
 1f83814:	mov    %eax,%ecx
 1f83816:	rdtsc
 1f83818:	mov    0x8b0(%rsp),%r8
 1f83820:	mov    0x8c0(%rsp),%r9d
 1f83828:	vpxor  %xmm0,%xmm0,%xmm0
 1f8382c:	vmovdqu %xmm0,0x50c(%rsp)
 1f83835:	vmovdqa %xmm0,0x500(%rsp)
 1f8383e:	movl   $0x0,0x10c(%rsp)
 1f83849:	movq   $0x0,0x258(%rsp)
 1f83855:	mov    %rax,0x260(%rsp)
 1f8385d:	mov    %rdx,0x440(%rsp)
 1f83865:	sub    $0x8,%rsp
 1f83869:	mov    0x8(%rsp),%rdi
 1f8386e:	lea    0x260(%rsp),%rax
 1f83876:	lea    0x114(%rsp),%r10
 1f8387e:	lea    0x508(%rsp),%r11
 1f83886:	mov    %rbp,%rsi
 1f83889:	mov    %r12d,%edx
 1f8388c:	mov    %ecx,0x2a8(%rsp)
 1f83893:	push   %rax
 1f83894:	push   %r10
 1f83896:	push   %r11
 1f83898:	call   1f97ce0 <node_rows_window_values>
 1f8389d:	add    $0x20,%rsp
 1f838a1:	rdtsc
 1f838a3:	mov    %rbp,%rsi
 1f838a6:	mov    %rdx,0x600(%rsp)
 1f838ae:	mov    %rax,0x360(%rsp)
 1f838b6:	mov    (%rsp),%rdi
 1f838ba:	call   1f98b80 <node_rows_window_part>
 1f838bf:	mov    (%rsp),%rdi
 1f838c3:	rdtsc
 1f838c5:	movl   $0x0,0xe8(%rsp)
 1f838d0:	movq   $0x0,0xe0(%rsp)
 1f838dc:	cmpb   $0x1,0xd58(%rdi)
 1f838e3:	mov    %rax,0x1f0(%rsp)
 1f838eb:	mov    %rdx,0x5c0(%rsp)
 1f838f3:	jne    1f8390c <node_facts_window_run+0x653c>
 1f838f5:	lea    0xe0(%rsp),%rcx
 1f838fd:	mov    %rbp,%rsi
 1f83900:	mov    %r12d,%edx
 1f83903:	call   1f98c90 <node_rows_window_summary>
 1f83908:	mov    (%rsp),%rdi
 1f8390c:	rdtsc
 1f8390e:	mov    0xdc0(%rdi),%ecx
 1f83914:	movl   $0x0,0xdc0(%rdi)
 1f8391e:	mov    0xa90(%rdi),%r13d
 1f83925:	cmpb   $0x0,0xdc4(%rdi)
 1f8392c:	mov    %rcx,0x238(%rsp)
 1f83934:	mov    %rax,0xa0(%rsp)
 1f8393c:	mov    %rdx,0x4c0(%rsp)
 1f83944:	je     1f83975 <node_facts_window_run+0x65a5>
 1f83946:	mov    0xdcc(%rdi),%ecx
 1f8394c:	mov    $0x1,%esi
 1f83951:	mov    %ecx,%ebx
 1f83953:	inc    %ecx
 1f83955:	and    $0x3,%ebx
 1f83958:	mov    %ecx,0xdcc(%rdi)
 1f8395e:	mov    0xe0(%rsp),%ebp
 1f83965:	cmp    $0x2,%ebx
 1f83968:	jne    1f84857 <node_facts_window_run+0x7487>
 1f8396e:	mov    $0x2,%ebx
 1f83973:	jmp    1f8398e <node_facts_window_run+0x65be>
 1f83975:	mov    0xe0(%rsp),%ebp
 1f8397c:	mov    $0xffffffff,%ebx
 1f83981:	mov    %ebx,%eax
 1f83983:	xor    $0x3,%eax
 1f83986:	xor    %esi,%esi
 1f83988:	or     %ebp,%eax
 1f8398a:	sete   %sil
 1f8398e:	cmpb   $0x1,0xd58(%rdi)
 1f83995:	mov    %esi,0x164(%rsp)
 1f8399c:	mov    %r15,0x230(%rsp)
 1f839a4:	mov    %r14,0x80(%rsp)
 1f839ac:	jne    1f83a6a <node_facts_window_run+0x669a>
 1f839b2:	mov    0xd98(%rdi),%rsi
 1f839b9:	mov    0xda8(%rdi),%rdi
 1f839c0:	lea    (%r12,%r12,1),%rdx
 1f839c4:	call   355eab0 <memcpy>
 1f839c9:	mov    (%rsp),%rax
 1f839cd:	mov    (%rsp),%rcx
 1f839d1:	mov    %r13,%rdx
 1f839d4:	mov    0xda0(%rax),%rsi
 1f839db:	mov    0xdb0(%rcx),%rdi
 1f839e2:	call   355eab0 <memcpy>
 1f839e7:	mov    (%rsp),%rax
 1f839eb:	mov    (%rsp),%rcx
 1f839ef:	mov    %ebp,%edx
 1f839f1:	shl    $0x2,%rdx
 1f839f5:	mov    0xd90(%rax),%rsi
 1f839fc:	mov    0xdb8(%rcx),%rdi
 1f83a03:	call   355eab0 <memcpy>
 1f83a08:	mov    (%rsp),%rdi
 1f83a0c:	xor    %eax,%eax
 1f83a0e:	mov    %r12d,%ecx
 1f83a11:	sub    $0x1,%ecx
 1f83a14:	cmovb  %eax,%ecx
 1f83a17:	test   %ebx,%ebx
 1f83a19:	sete   %dl
 1f83a1c:	cmp    $0x1,%ebx
 1f83a1f:	sete   %sil
 1f83a23:	test   %r13d,%r13d
 1f83a26:	sete   %r8b
 1f83a2a:	mov    0xda8(%rdi),%rax
 1f83a31:	and    %sil,%r8b
 1f83a34:	or     %dl,%r8b
 1f83a37:	movzbl %r8b,%edx
 1f83a3b:	xor    %dx,(%rax,%rcx,2)
 1f83a3f:	test   %r13d,%r13d
 1f83a42:	mov    0xdb0(%rdi),%rax
 1f83a49:	setne  %cl
 1f83a4c:	and    %sil,%cl
 1f83a4f:	xor    %cl,(%rax)
 1f83a51:	cmp    $0x3,%ebx
 1f83a54:	mov    0xdb8(%rdi),%rdx
 1f83a5b:	sete   %al
 1f83a5e:	test   %ebp,%ebp
 1f83a60:	setne  %cl
 1f83a63:	and    %al,%cl
 1f83a65:	movzbl %cl,%eax
 1f83a68:	xor    %eax,(%rdx)
 1f83a6a:	mov    %ebp,0x168(%rsp)
 1f83a71:	mov    %r13,0x640(%rsp)
 1f83a79:	mov    0xca8(%rdi),%rsi
 1f83a80:	mov    0xcb8(%rdi),%rdi
 1f83a87:	mov    0x2a0(%rsp),%r14d
 1f83a8f:	mov    %r14d,%ebx
 1f83a92:	mov    %rbx,%rdx
 1f83a95:	call   355eab0 <memcpy>
 1f83a9a:	mov    (%rsp),%rax
 1f83a9e:	mov    (%rsp),%rcx
 1f83aa2:	mov    %rbx,%rdx
 1f83aa5:	mov    0xcb0(%rax),%rsi
 1f83aac:	mov    0xcc0(%rcx),%rdi
 1f83ab3:	call   355eab0 <memcpy>
 1f83ab8:	mov    (%rsp),%rax
 1f83abc:	mov    (%rsp),%rcx
 1f83ac0:	lea    0x0(,%rbx,8),%rdx
 1f83ac8:	mov    %rbx,0x658(%rsp)
 1f83ad0:	mov    %rdx,0x648(%rsp)
 1f83ad8:	mov    0xcc8(%rax),%rsi
 1f83adf:	mov    0xcd0(%rcx),%rdi
 1f83ae6:	call   355eab0 <memcpy>
 1f83aeb:	mov    (%rsp),%rax
 1f83aef:	mov    $0xffffffff,%edi
 1f83af4:	movzbl 0xdd0(%rax),%ecx
 1f83afb:	mov    (%rsp),%rax
 1f83aff:	mov    0xdd8(%rax),%edx
 1f83b05:	imul   $0x4ec4ec4f,%rdx,%rax
 1f83b0c:	shr    $0x22,%rax
 1f83b10:	lea    (%rax,%rax,2),%esi
 1f83b13:	lea    (%rax,%rsi,4),%eax
 1f83b16:	mov    %edx,%esi
 1f83b18:	sub    %eax,%esi
 1f83b1a:	test   %ecx,%ecx
 1f83b1c:	cmovne %esi,%edi
 1f83b1f:	xor    %eax,%eax
 1f83b21:	lea    -0x1(%rdi),%esi
 1f83b24:	cmp    $0x3,%esi
 1f83b27:	mov    %r12d,%esi
 1f83b2a:	cmovae %edi,%eax
 1f83b2d:	test   %r14d,%r14d
 1f83b30:	cmovne %edi,%eax
 1f83b33:	add    %edx,%ecx
 1f83b35:	mov    (%rsp),%rdx
 1f83b39:	mov    (%rsp),%rdi
 1f83b3d:	cmp    $0x1,%eax
 1f83b40:	vpbroadcastd %eax,%xmm0
 1f83b46:	vpcmpeqd -0x19bbcde(%rip),%xmm0,%xmm1        # 5c7e70 <.LCPI3_64>
 1f83b4e:	vpcmpeqd -0x19bbcd6(%rip),%xmm0,%xmm0        # 5c7e80 <.LCPI3_65>
 1f83b56:	mov    %ecx,0xdd8(%rdx)
 1f83b5c:	mov    (%rsp),%rcx
 1f83b60:	sete   %dl
 1f83b63:	vpsrld $0x1f,%xmm1,%xmm1
 1f83b68:	vpsrld $0x1f,%xmm0,%xmm0
 1f83b6d:	mov    0xcb8(%rcx),%rcx
 1f83b74:	xor    %dl,(%rcx)
 1f83b76:	mov    (%rsp),%rcx
 1f83b7a:	cmp    $0x2,%eax
 1f83b7d:	sete   %dl
 1f83b80:	mov    0xcc0(%rcx),%rcx
 1f83b87:	xor    %dl,(%rcx)
 1f83b89:	xor    %ecx,%ecx
 1f83b8b:	cmp    $0x3,%eax
 1f83b8e:	mov    0xcd0(%rdi),%rdx
 1f83b95:	sete   %cl
 1f83b98:	xor    %rcx,(%rdx)
 1f83b9b:	mov    0x10c(%rsp),%ecx
 1f83ba2:	vmovsd 0x500(%rsp),%xmm2
 1f83bab:	vmovups 0x50c(%rsp),%xmm3
 1f83bb4:	mov    %rcx,0x248(%rsp)
 1f83bbc:	mov    0x258(%rsp),%rcx
 1f83bc4:	mov    %rcx,0x240(%rsp)
 1f83bcc:	mov    0x508(%rsp),%ecx
 1f83bd3:	vmovups %ymm2,0x840(%rsp)
 1f83bdc:	vshufps $0x24,%xmm3,%xmm2,%xmm2
 1f83be1:	mov    %rcx,0x660(%rsp)
 1f83be9:	vpinsrd $0x2,%ecx,%xmm2,%xmm2
 1f83bef:	xor    %ecx,%ecx
 1f83bf1:	cmp    $0xc,%eax
 1f83bf4:	vmovaps %xmm3,0x810(%rsp)
 1f83bfd:	sete   %cl
 1f83c00:	xor    0x518(%rsp),%ecx
 1f83c07:	vpxor  %xmm1,%xmm2,%xmm1
 1f83c0b:	xor    %ebx,%ebx
 1f83c0d:	test   %eax,%eax
 1f83c0f:	vmovdqa %xmm1,0x6d0(%rsp)
 1f83c18:	vshufps $0xe9,%xmm3,%xmm3,%xmm1
 1f83c1d:	sete   %bpl
 1f83c21:	cmp    $0x4,%eax
 1f83c24:	vxorps %xmm0,%xmm1,%xmm0
 1f83c28:	sete   0x57(%rsp)
 1f83c2d:	cmp    $0x5,%eax
 1f83c30:	vmovlps %xmm0,0x6e0(%rsp)
 1f83c39:	vxorps %xmm0,%xmm0,%xmm0
 1f83c3d:	mov    %ecx,0x6e8(%rsp)
 1f83c44:	rdtsc
 1f83c46:	vmovups %ymm0,0x7b0(%rsp)
 1f83c4f:	movq   $0x0,0x7d0(%rsp)
 1f83c5b:	mov    %rax,0x580(%rsp)
 1f83c63:	mov    %rdx,0x100(%rsp)
 1f83c6b:	sete   0x56(%rsp)
 1f83c70:	lea    0x7b0(%rsp),%rdx
 1f83c78:	mov    (%rsp),%rdi
 1f83c7c:	vzeroupper
 1f83c7f:	call   1f96360 <node_rows_window_reads>
 1f83c84:	rdtsc
 1f83c86:	mov    %rdx,0xf8(%rsp)
 1f83c8e:	mov    %r12d,%edx
 1f83c91:	mov    %rax,0x540(%rsp)
 1f83c99:	mov    0x20(%rsp),%r13
 1f83c9e:	mov    (%rsp),%rdi
 1f83ca2:	mov    %r13,%rsi
 1f83ca5:	call   1f96a80 <node_rows_window_shapes>
 1f83caa:	mov    (%rsp),%rdi
 1f83cae:	rdtsc
 1f83cb0:	mov    0xc10(%rdi),%rcx
 1f83cb7:	or     0xc08(%rdi),%rcx
 1f83cbe:	mov    %rax,0x670(%rsp)
 1f83cc6:	mov    %rdx,0x88(%rsp)
 1f83cce:	je     1f83ce7 <node_facts_window_run+0x6917>
 1f83cd0:	lea    0x7b0(%rsp),%rcx
 1f83cd8:	mov    %r13,%rsi
 1f83cdb:	mov    %r12d,%edx
 1f83cde:	call   1f96eb0 <node_rows_window_updates>
 1f83ce3:	mov    (%rsp),%rdi
 1f83ce7:	rdtsc
 1f83ce9:	mov    %bpl,%bl
 1f83cec:	mov    %r13,%rsi
 1f83cef:	mov    %rax,0xb0(%rsp)
 1f83cf7:	mov    %rdx,0x770(%rsp)
 1f83cff:	mov    %r12d,%edx
 1f83d02:	call   1f976c0 <node_rows_window_write>
 1f83d07:	mov    %eax,%ebp
 1f83d09:	rdtsc
 1f83d0b:	mov    0x7c0(%rsp),%r8
 1f83d13:	mov    0x7d0(%rsp),%r9d
 1f83d1b:	vxorps %xmm0,%xmm0,%xmm0
 1f83d1f:	vmovups %xmm0,0x6bc(%rsp)
 1f83d28:	vmovaps %xmm0,0x6b0(%rsp)
 1f83d31:	movl   $0x0,0x108(%rsp)
 1f83d3c:	movq   $0x0,0x250(%rsp)
 1f83d48:	mov    %rax,0x48(%rsp)
 1f83d4d:	mov    %rdx,0x420(%rsp)
 1f83d55:	sub    $0x8,%rsp
 1f83d59:	mov    0x8(%rsp),%rdi
 1f83d5e:	lea    0x258(%rsp),%rax
 1f83d66:	lea    0x6b8(%rsp),%r11
 1f83d6e:	mov    %r12,0x6f8(%rsp)
 1f83d76:	lea    0x110(%rsp),%r10
 1f83d7e:	mov    %r13,%rsi
 1f83d81:	mov    %r12d,%edx
 1f83d84:	mov    %ebp,0x174(%rsp)
 1f83d8b:	mov    %ebp,%ecx
 1f83d8d:	push   %rax
 1f83d8e:	push   %r10
 1f83d90:	push   %r11
 1f83d92:	call   1f97ce0 <node_rows_window_values>
 1f83d97:	add    $0x20,%rsp
 1f83d9b:	rdtsc
 1f83d9d:	mov    %r13,%rsi
 1f83da0:	mov    %rdx,0x730(%rsp)
 1f83da8:	mov    %rax,0x98(%rsp)
 1f83db0:	mov    (%rsp),%rdi
 1f83db4:	call   1f98b80 <node_rows_window_part>
 1f83db9:	mov    (%rsp),%r11
 1f83dbd:	rdtsc
 1f83dbf:	movl   $0x0,0x158(%rsp)
 1f83dca:	movq   $0x0,0x150(%rsp)
 1f83dd6:	cmpb   $0x1,0xd58(%r11)
 1f83dde:	mov    %rax,0xa8(%rsp)
 1f83de6:	mov    %rdx,0x520(%rsp)
 1f83dee:	jne    1f83e0f <node_facts_window_run+0x6a3f>
 1f83df0:	lea    0x150(%rsp),%rcx
 1f83df8:	mov    0x6f0(%rsp),%rdx
 1f83e00:	mov    %r11,%rdi
 1f83e03:	mov    %r13,%rsi
 1f83e06:	call   1f98c90 <node_rows_window_summary>
 1f83e0b:	mov    (%rsp),%r11
 1f83e0f:	rdtsc
 1f83e11:	mov    0xdc0(%r11),%ecx
 1f83e18:	xor    %ebx,%r14d
 1f83e1b:	movl   $0x0,0xdc0(%r11)
 1f83e26:	cmpl   $0x0,0xa90(%r11)
 1f83e2e:	mov    %rax,0xf0(%rsp)
 1f83e36:	mov    %rdx,0x650(%rsp)
 1f83e3e:	mov    %r14d,0x2a0(%rsp)
 1f83e46:	mov    %ecx,0x160(%rsp)
 1f83e4d:	mov    0x60(%rsp),%rbp
 1f83e52:	je     1f84704 <node_facts_window_run+0x7334>
 1f83e58:	vpbroadcastq -0x19b58c9(%rip),%xmm2        # 5ce598 <.LCPI3_1>
 1f83e61:	xor    %r15d,%r15d
 1f83e64:	jmp    1f83e85 <node_facts_window_run+0x6ab5>
 1f83e66:	mov    (%rsp),%r11
 1f83e6a:	incq   0xbb8(%rbp,%rsi,8)
 1f83e72:	mov    0xa90(%r11),%eax
 1f83e79:	inc    %r15
 1f83e7c:	cmp    %rax,%r15
 1f83e7f:	jae    1f84704 <node_facts_window_run+0x7334>
 1f83e85:	mov    0xd40(%r11),%rax
 1f83e8c:	movzbl (%rax,%r15,1),%eax
 1f83e91:	test   %al,%al
 1f83e93:	je     1f83e72 <node_facts_window_run+0x6aa2>
 1f83e95:	mov    0xa70(%r11),%rdx
 1f83e9c:	mov    0xa68(%r11),%rcx
 1f83ea3:	mov    (%rdx,%r15,4),%edx
 1f83ea7:	mov    (%rcx,%r15,4),%r14d
 1f83eab:	mov    0x651b8(%r13,%rdx,4),%edi
 1f83eb3:	incq   0xb90(%rbp)
 1f83eba:	mov    0xa58(%r11),%rcx
 1f83ec1:	mov    (%rcx,%r15,4),%ecx
 1f83ec5:	add    %rcx,0xb98(%rbp)
 1f83ecc:	cmp    $0x1,%al
 1f83ece:	jne    1f83f40 <node_facts_window_run+0x6b70>
 1f83ed0:	mov    0xa58(%r11),%rax
 1f83ed7:	mov    $0x1,%esi
 1f83edc:	mov    (%rax,%r15,4),%r10d
 1f83ee0:	test   %r10d,%r10d
 1f83ee3:	je     1f83e6a <node_facts_window_run+0x6a9a>
 1f83ee5:	mov    0xbe8(%r11),%rax
 1f83eec:	sub    %edi,%edx
 1f83eee:	xor    %ecx,%ecx
 1f83ef0:	xor    %r11d,%r11d
 1f83ef3:	inc    %edx
 1f83ef5:	data16 cs nopw 0x0(%rax,%rax,1)
 1f83f00:	lea    (%rdx,%r11,1),%r9d
 1f83f04:	cmp    %edi,%r11d
 1f83f07:	cmovae %r14d,%r9d
 1f83f0b:	mov    %r9d,%r8d
 1f83f0e:	shr    $0x3,%r8d
 1f83f12:	and    $0xfffffff8,%r8d
 1f83f16:	mov    0x28(%rax,%r8,8),%rbx
 1f83f1b:	bt     %r9,%rbx
 1f83f1f:	jb     1f84293 <node_facts_window_run+0x6ec3>
 1f83f25:	inc    %r11d
 1f83f28:	cmp    %r11d,%r10d
 1f83f2b:	jne    1f83f00 <node_facts_window_run+0x6b30>
 1f83f2d:	jmp    1f83e66 <node_facts_window_run+0x6a96>
 1f83f32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f83f40:	mov    0xa68(%r11),%rcx
 1f83f47:	mov    0xa70(%r11),%rdx
 1f83f4e:	mov    0xa58(%r11),%rax
 1f83f55:	xor    %r9d,%r9d
 1f83f58:	mov    (%rcx,%r15,4),%ecx
 1f83f5c:	mov    %rcx,0x8(%rsp)
 1f83f61:	mov    (%rdx,%r15,4),%ecx
 1f83f65:	mov    0xc40(%r11),%rdx
 1f83f6c:	mov    0x651b8(%r13,%rcx,4),%esi
 1f83f74:	cmp    %esi,(%rax,%r15,4)
 1f83f78:	jbe    1f83f84 <node_facts_window_run+0x6bb4>
 1f83f7a:	mov    0x8(%rsp),%rax
 1f83f7f:	movzbl (%rdx,%rax,1),%r9d
 1f83f84:	mov    0xc60(%r11),%r8
 1f83f8b:	mov    0xc80(%r11),%r10
 1f83f92:	mov    %ecx,%edi
 1f83f94:	sub    %esi,%edi
 1f83f96:	mov    %ecx,%esi
 1f83f98:	shr    $0x3,%esi
 1f83f9b:	mov    0x940(%r11),%rax
 1f83fa2:	inc    %edi
 1f83fa4:	movzbl (%r8,%rdi,1),%ebx
 1f83fa9:	shr    $0x3,%edi
 1f83fac:	mov    (%r10,%rsi,4),%r12d
 1f83fb0:	mov    0xa50(%r11),%rsi
 1f83fb7:	mov    %r10,0x28(%rsp)
 1f83fbc:	mov    %r8,0x18(%rsp)
 1f83fc1:	add    (%r10,%rdi,4),%ebx
 1f83fc5:	movzbl (%r8,%rcx,1),%edi
 1f83fca:	movzbl (%rdx,%rcx,1),%r10d
 1f83fcf:	mov    %r12d,%ecx
 1f83fd2:	mov    (%rsi,%r15,4),%esi
 1f83fd6:	mov    %rbx,0x10(%rsp)
 1f83fdb:	sub    %ebx,%ecx
 1f83fdd:	mov    0x130(%rax),%rbx
 1f83fe4:	add    %edi,%ecx
 1f83fe6:	add    %r10d,%ecx
 1f83fe9:	add    %ecx,%r9d
 1f83fec:	mov    (%rbx,%rsi,4),%r8d
 1f83ff0:	cmp    $0xffffffff,%r8d
 1f83ff4:	je     1f84288 <node_facts_window_run+0x6eb8>
 1f83ffa:	mov    %r12d,0x170(%rsp)
 1f84002:	mov    %r10,0x30(%rsp)
 1f84007:	mov    %rdi,0x1b0(%rsp)
 1f8400f:	mov    0xdd4(%r11),%r10d
 1f84016:	movzbl 0xdd0(%r11),%edi
 1f8401e:	mov    $0x4,%edx
 1f84023:	mov    %r14,0xc8(%rsp)
 1f8402b:	mov    %r10d,%ebx
 1f8402e:	and    $0x3,%ebx
 1f84031:	test   %edi,%edi
 1f84033:	mov    %r10d,0xd0(%rsp)
 1f8403b:	cmove  %edx,%ebx
 1f8403e:	test   $0x4,%r10b
 1f84042:	movabs $0x8000000000000000,%r10
 1f8404c:	mov    $0x1,%edx
 1f84051:	cmove  %rdx,%r10
 1f84055:	test   %r8d,%r8d
 1f84058:	sete   %dl
 1f8405b:	mov    %r10,0x38(%rsp)
 1f84060:	mov    %edi,0xb8(%rsp)
 1f84067:	mov    %r8d,0xc0(%rsp)
 1f8406f:	mov    %r9,0x40(%rsp)
 1f84074:	and    %dil,%dl
 1f84077:	cmp    $0x2,%ebx
 1f8407a:	sete   %dil
 1f8407e:	or     %dl,%dil
 1f84081:	movzbl %dil,%edx
 1f84085:	add    %r8d,%edx
 1f84088:	mov    0x110(%rax),%r8
 1f8408f:	cmp    $0x3,%ebx
 1f84092:	sete   %dil
 1f84096:	cmpb   $0x0,(%r8,%rsi,1)
 1f8409b:	setne  %r8b
 1f8409f:	cmp    %edx,%r9d
 1f840a2:	setne  %r12b
 1f840a6:	xor    %r10d,%r10d
 1f840a9:	or     %r8b,%r12b
 1f840ac:	jne    1f843ec <node_facts_window_run+0x701c>
 1f840b2:	test   %edx,%edx
 1f840b4:	je     1f843ec <node_facts_window_run+0x701c>
 1f840ba:	mov    0x128(%rax),%rdx
 1f840c1:	mov    0x140(%rax),%rbp
 1f840c8:	mov    %ecx,%ecx
 1f840ca:	mov    (%rdx,%rsi,4),%edx
 1f840cd:	mov    0x148(%rax),%rsi
 1f840d4:	add    %rdx,%rsi
 1f840d7:	add    %rdx,%rbp
 1f840da:	shl    $0x3,%rdx
 1f840de:	add    0x150(%rax),%rdx
 1f840e5:	cmp    $0x1,%ebx
 1f840e8:	mov    %rsi,0x110(%rsp)
 1f840f0:	sete   %al
 1f840f3:	cmp    $0x3,%ebx
 1f840f6:	mov    %rdx,0x90(%rsp)
 1f840fe:	sete   %dl
 1f84101:	mov    0x40(%rsp),%r8
 1f84106:	cmp    $0x2,%r8d
 1f8410a:	lea    -0x1(%r8),%r13d
 1f8410e:	mov    %r8d,%r8d
 1f84111:	setae  %sil
 1f84115:	and    %al,%sil
 1f84118:	mov    0x8(%rsp),%rax
 1f8411d:	shr    $0x3,%eax
 1f84120:	mov    %rax,0x70(%rsp)
 1f84125:	or     %dl,%sil
 1f84128:	mov    (%rsp),%rax
 1f8412c:	mov    0xca8(%rax),%r11
 1f84133:	test   %sil,%sil
 1f84136:	je     1f842f8 <node_facts_window_run+0x6f28>
 1f8413c:	mov    0xd0(%rsp),%eax
 1f84143:	xor    %esi,%esi
 1f84145:	and    $0x8,%eax
 1f84148:	shr    $0x3,%eax
 1f8414b:	and    %al,%dil
 1f8414e:	mov    $0x0,%edi
 1f84153:	mov    0x10(%rsp),%rax
 1f84158:	cmovne %r13,%rdi
 1f8415c:	sub    0x170(%rsp),%eax
 1f84163:	neg    %r13
 1f84166:	xor    %r14d,%r14d
 1f84169:	sub    0x30(%rsp),%eax
 1f8416d:	neg    %rdi
 1f84170:	sub    0x1b0(%rsp),%eax
 1f84177:	mov    %rax,0x30(%rsp)
 1f8417c:	mov    $0x1,%eax
 1f84181:	mov    %r13,0x1b0(%rsp)
 1f84189:	jmp    1f841aa <node_facts_window_run+0x6dda>
 1f8418b:	nopl   0x0(%rax,%rax,1)
 1f84190:	inc    %rsi
 1f84193:	cmp    %r8,%rax
 1f84196:	mov    %r10d,%r14d
 1f84199:	setae  %dl
 1f8419c:	inc    %rax
 1f8419f:	or     %r12b,%dl
 1f841a2:	test   %dl,%dl
 1f841a4:	jne    1f843ec <node_facts_window_run+0x701c>
 1f841aa:	lea    -0x1(%rax),%rdx
 1f841ae:	cmp    %rcx,%rdx
 1f841b1:	jae    1f841c0 <node_facts_window_run+0x6df0>
 1f841b3:	mov    0x10(%rsp),%rdx
 1f841b8:	lea    (%rdx,%rsi,1),%r9d
 1f841bc:	mov    %esi,%edx
 1f841be:	jmp    1f841ee <node_facts_window_run+0x6e1e>
 1f841c0:	mov    0x8(%rsp),%rdx
 1f841c5:	mov    0x18(%rsp),%r9
 1f841ca:	mov    0x28(%rsp),%r12
 1f841cf:	mov    0x70(%rsp),%r10
 1f841d4:	movzbl (%r9,%rdx,1),%r9d
 1f841d9:	mov    0x30(%rsp),%rdx
 1f841de:	add    (%r12,%r10,4),%r9d
 1f841e2:	lea    (%rdx,%rax,1),%r10d
 1f841e6:	lea    -0x1(%rax),%edx
 1f841e9:	lea    -0x1(%r10,%r9,1),%r9d
 1f841ee:	or     %ebx,%edx
 1f841f0:	lea    (%rdi,%rax,1),%r10
 1f841f4:	mov    $0x0,%edx
 1f841f9:	mov    $0x1,%r12b
 1f841fc:	mov    %r9d,%r9d
 1f841ff:	sete   %r13b
 1f84203:	xor    -0x1(%rbp,%rax,1),%r13b
 1f84208:	cmp    $0x1,%r10
 1f8420c:	mov    $0x1,%r10b
 1f8420f:	cmove  0x38(%rsp),%rdx
 1f84215:	cmp    %r13b,(%r11,%r9,1)
 1f84219:	jne    1f84259 <node_facts_window_run+0x6e89>
 1f8421b:	mov    0x1b0(%rsp),%r12
 1f84223:	cmp    $0x1,%ebx
 1f84226:	sete   %r13b
 1f8422a:	add    %rax,%r12
 1f8422d:	cmp    $0x1,%r12
 1f84231:	sete   %r12b
 1f84235:	and    %r13b,%r12b
 1f84238:	mov    0x110(%rsp),%r13
 1f84240:	xor    -0x1(%r13,%rax,1),%r12b
 1f84245:	mov    (%rsp),%r13
 1f84249:	mov    0xcb0(%r13),%r13
 1f84250:	cmp    %r12b,0x0(%r13,%r9,1)
 1f84255:	setne  %r12b
 1f84259:	test   $0x1,%r14b
 1f8425d:	jne    1f84190 <node_facts_window_run+0x6dc0>
 1f84263:	mov    0x90(%rsp),%r10
 1f8426b:	mov    (%rsp),%r14
 1f8426f:	xor    -0x8(%r10,%rax,8),%rdx
 1f84274:	mov    0xcc8(%r14),%r10
 1f8427b:	cmp    %rdx,(%r10,%r9,8)
 1f8427f:	setne  %r10b
 1f84283:	jmp    1f84190 <node_facts_window_run+0x6dc0>
 1f84288:	xor    %r10d,%r10d
 1f8428b:	xor    %r12d,%r12d
 1f8428e:	jmp    1f84424 <node_facts_window_run+0x7054>
 1f84293:	mov    (%rsp),%r11
 1f84297:	mov    %r9d,%edx
 1f8429a:	mov    0xbb0(%r11),%rsi
 1f842a1:	movzbl (%rsi,%rdx,1),%esi
 1f842a5:	and    $0x3f,%sil
 1f842a9:	cmp    $0x14,%sil
 1f842ad:	je     1f842bf <node_facts_window_run+0x6eef>
 1f842af:	mov    0xc30(%r11),%rsi
 1f842b6:	xor    %ecx,%ecx
 1f842b8:	cmpb   $0x7f,(%rsi,%rdx,1)
 1f842bc:	setne  %cl
 1f842bf:	and    $0x3f,%r9d
 1f842c3:	mov    $0x1,%edx
 1f842c8:	mov    $0x2,%esi
 1f842cd:	shlx   %r9,%rdx,%rdx
 1f842d2:	test   %rdx,0x30(%rax,%r8,8)
 1f842d7:	jne    1f83e6a <node_facts_window_run+0x6a9a>
 1f842dd:	test   %rdx,0x38(%rax,%r8,8)
 1f842e2:	mov    $0x3,%eax
 1f842e7:	cmovne %rax,%rcx
 1f842eb:	incq   0xbb8(%rbp,%rcx,8)
 1f842f3:	jmp    1f83e72 <node_facts_window_run+0x6aa2>
 1f842f8:	mov    0x10(%rsp),%rax
 1f842fd:	sub    0x170(%rsp),%eax
 1f84304:	xor    %esi,%esi
 1f84306:	xor    %edi,%edi
 1f84308:	sub    0x30(%rsp),%eax
 1f8430c:	sub    0x1b0(%rsp),%eax
 1f84313:	jmp    1f84338 <node_facts_window_run+0x6f68>
 1f84315:	data16 cs nopw 0x0(%rax,%rax,1)
 1f84320:	inc    %rsi
 1f84323:	mov    %r10d,%edi
 1f84326:	cmp    %r8,%rsi
 1f84329:	setae  %dl
 1f8432c:	or     %r12b,%dl
 1f8432f:	cmp    $0x1,%dl
 1f84332:	je     1f843ec <node_facts_window_run+0x701c>
 1f84338:	cmp    %rcx,%rsi
 1f8433b:	jae    1f84350 <node_facts_window_run+0x6f80>
 1f8433d:	mov    0x10(%rsp),%rdx
 1f84342:	add    %esi,%edx
 1f84344:	jmp    1f84371 <node_facts_window_run+0x6fa1>
 1f84346:	cs nopw 0x0(%rax,%rax,1)
 1f84350:	mov    0x8(%rsp),%rdx
 1f84355:	mov    0x18(%rsp),%r9
 1f8435a:	mov    0x70(%rsp),%r10
 1f8435f:	movzbl (%r9,%rdx,1),%edx
 1f84364:	mov    0x28(%rsp),%r9
 1f84369:	add    (%r9,%r10,4),%edx
 1f8436d:	add    %eax,%edx
 1f8436f:	add    %esi,%edx
 1f84371:	mov    %esi,%r9d
 1f84374:	or     %ebx,%r9d
 1f84377:	mov    $0x1,%r10b
 1f8437a:	mov    $0x1,%r12b
 1f8437d:	mov    %edx,%edx
 1f8437f:	sete   %r9b
 1f84383:	xor    0x0(%rbp,%rsi,1),%r9b
 1f84388:	cmp    %r9b,(%r11,%rdx,1)
 1f8438c:	jne    1f843be <node_facts_window_run+0x6fee>
 1f8438e:	cmp    $0x1,%ebx
 1f84391:	sete   %r9b
 1f84395:	cmp    %rsi,%r13
 1f84398:	sete   %r14b
 1f8439c:	and    %r9b,%r14b
 1f8439f:	mov    0x110(%rsp),%r9
 1f843a7:	xor    (%r9,%rsi,1),%r14b
 1f843ab:	mov    (%rsp),%r9
 1f843af:	mov    0xcb0(%r9),%r9
 1f843b6:	cmp    %r14b,(%r9,%rdx,1)
 1f843ba:	setne  %r12b
 1f843be:	test   $0x1,%dil
 1f843c2:	jne    1f84320 <node_facts_window_run+0x6f50>
 1f843c8:	mov    0x90(%rsp),%rdi
 1f843d0:	mov    (%rsp),%r9
 1f843d4:	mov    (%rdi,%rsi,8),%rdi
 1f843d8:	mov    0xcc8(%r9),%r9
 1f843df:	cmp    %rdi,(%r9,%rdx,8)
 1f843e3:	setne  %r10b
 1f843e7:	jmp    1f84320 <node_facts_window_run+0x6f50>
 1f843ec:	mov    0xd0(%rsp),%eax
 1f843f3:	mov    (%rsp),%r11
 1f843f7:	mov    0x20(%rsp),%r13
 1f843fc:	mov    0x60(%rsp),%rbp
 1f84401:	mov    0xc8(%rsp),%r14
 1f84409:	mov    0x40(%rsp),%r9
 1f8440e:	mov    0xc0(%rsp),%r8d
 1f84416:	add    0xb8(%rsp),%eax
 1f8441d:	mov    %eax,0xdd4(%r11)
 1f84424:	cmp    $0xffffffff,%r8d
 1f84428:	vmovd  %r9d,%xmm1
 1f8442d:	mov    %r12d,%ecx
 1f84430:	sete   %al
 1f84433:	incq   0xba0(%rbp)
 1f8443a:	or     %r10b,%r12b
 1f8443d:	xor    $0x1,%cl
 1f84440:	mov    0xa58(%r11),%rdx
 1f84447:	and    %r10b,%cl
 1f8444a:	vmovd  (%rdx,%r15,4),%xmm0
 1f84450:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f84454:	vpaddq 0xba8(%rbp),%xmm0,%xmm0
 1f8445c:	vmovdqu %xmm0,0xba8(%rbp)
 1f84464:	vmovd  %r12d,%xmm0
 1f84469:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f8446f:	movzbl %cl,%eax
 1f84472:	vpmovzxbq %xmm0,%xmm0
 1f84477:	vptestmq %xmm2,%xmm0,%k0
 1f8447d:	vmovdqu 0xbd8(%rbp),%xmm0
 1f84485:	vpmovm2q %k0,%xmm1
 1f8448b:	vpsubq %xmm1,%xmm0,%xmm0
 1f8448f:	vmovdqu %xmm0,0xbd8(%rbp)
 1f84497:	add    %rax,0xcc0(%rbp)
 1f8449e:	mov    0xd48(%r11),%rax
 1f844a5:	mov    (%rax,%r15,8),%rax
 1f844a9:	add    %rax,0xc48(%rbp)
 1f844b0:	test   $0x1,%r12b
 1f844b4:	je     1f844e0 <node_facts_window_run+0x7110>
 1f844b6:	mov    0x13ac(%rbp),%eax
 1f844bc:	cmp    $0xf,%rax
 1f844c0:	ja     1f83e72 <node_facts_window_run+0x6aa2>
 1f844c6:	mov    0x422c(%r13,%r14,4),%ecx
 1f844ce:	mov    %ecx,0x136c(%rbp,%rax,4)
 1f844d5:	incl   0x13ac(%rbp)
 1f844db:	jmp    1f83e72 <node_facts_window_run+0x6aa2>
 1f844e0:	cmpb   $0x1,0xd58(%r11)
 1f844e8:	jne    1f83e72 <node_facts_window_run+0x6aa2>
 1f844ee:	mov    0xda0(%r11),%rax
 1f844f5:	mov    $0x4,%r12d
 1f844fb:	movzbl (%rax,%r15,1),%r14d
 1f84500:	incq   0xce8(%rbp)
 1f84507:	mov    0xa70(%r11),%rax
 1f8450e:	mov    0xd98(%r11),%rcx
 1f84515:	mov    (%rax,%r15,4),%eax
 1f84519:	lea    0x1(%rax),%edx
 1f8451c:	movzwl -0x2(%rcx,%rdx,2),%ebp
 1f84521:	sub    0x651b8(%r13,%rax,4),%edx
 1f84529:	cmpb   $0x1,0xdc4(%r11)
 1f84531:	movzwl -0x2(%rcx,%rdx,2),%eax
 1f84536:	jne    1f84549 <node_facts_window_run+0x7179>
 1f84538:	mov    0xdc8(%r11),%r12d
 1f8453f:	and    $0x3,%r12d
 1f84543:	je     1f8460e <node_facts_window_run+0x723e>
 1f84549:	cmp    $0x1,%r12d
 1f8454d:	mov    $0xffffffff,%r8d
 1f84553:	sete   %cl
 1f84556:	cmp    %ax,%bp
 1f84559:	sete   %bl
 1f8455c:	and    %cl,%bl
 1f8455e:	mov    0x940(%r11),%r13
 1f84565:	sub    %eax,%ebp
 1f84567:	cmpq   $0x0,0x168(%r13)
 1f8456f:	je     1f846c4 <node_facts_window_run+0x72f4>
 1f84575:	mov    0xa50(%r11),%rcx
 1f8457c:	mov    (%rcx,%r15,4),%edx
 1f84580:	cmp    0x20(%r13),%edx
 1f84584:	jae    1f846c4 <node_facts_window_run+0x72f4>
 1f8458a:	mov    0x188(%r13),%rdi
 1f84591:	movzbl %bl,%esi
 1f84594:	mov    %ebp,%r9d
 1f84597:	lea    (%rsi,%rdi,1),%rcx
 1f8459b:	add    %r9,%rcx
 1f8459e:	cmp    0x190(%r13),%rcx
 1f845a5:	ja     1f84632 <node_facts_window_run+0x7262>
 1f845ab:	cmp    $0xfffe,%ebp
 1f845b1:	ja     1f84632 <node_facts_window_run+0x7262>
 1f845b3:	shl    $0x2,%rdi
 1f845b7:	mov    %r8d,0x28(%rsp)
 1f845bc:	mov    %rsi,0x10(%rsp)
 1f845c1:	lea    0x0(,%rax,4),%esi
 1f845c8:	add    0x180(%r13),%rdi
 1f845cf:	add    0xd90(%r11),%rsi
 1f845d6:	mov    %rdx,0x8(%rsp)
 1f845db:	lea    0x0(,%r9,4),%rdx
 1f845e3:	mov    %rdi,0x18(%rsp)
 1f845e8:	mov    %r9,0x38(%rsp)
 1f845ed:	call   355eab0 <memcpy>
 1f845f2:	test   %bl,%bl
 1f845f4:	je     1f8463b <node_facts_window_run+0x726b>
 1f845f6:	mov    0x28(%rsp),%eax
 1f845fa:	mov    0x18(%rsp),%rcx
 1f845ff:	mov    0x38(%rsp),%rdx
 1f84604:	mov    0x8(%rsp),%rsi
 1f84609:	mov    %eax,(%rcx,%rdx,4)
 1f8460c:	jmp    1f84651 <node_facts_window_run+0x7281>
 1f8460e:	xor    %r8d,%r8d
 1f84611:	mov    $0x1,%bl
 1f84613:	xor    %r12d,%r12d
 1f84616:	mov    0x940(%r11),%r13
 1f8461d:	sub    %eax,%ebp
 1f8461f:	cmpq   $0x0,0x168(%r13)
 1f84627:	jne    1f84575 <node_facts_window_run+0x71a5>
 1f8462d:	jmp    1f846c4 <node_facts_window_run+0x72f4>
 1f84632:	incq   0x198(%r13)
 1f84639:	jmp    1f846b5 <node_facts_window_run+0x72e5>
 1f8463b:	mov    0x18(%rsp),%rax
 1f84640:	mov    0x8(%rsp),%rsi
 1f84645:	cmp    $0x1,%r12d
 1f84649:	jne    1f84651 <node_facts_window_run+0x7281>
 1f8464b:	movl   $0x0,(%rax)
 1f84651:	mov    0x188(%r13),%eax
 1f84658:	mov    0x168(%r13),%rcx
 1f8465f:	mov    0x10(%rsp),%rdi
 1f84664:	mov    (%rsp),%r11
 1f84668:	mov    $0x1,%edx
 1f8466d:	vpbroadcastq -0x19b60de(%rip),%xmm2        # 5ce598 <.LCPI3_1>
 1f84676:	mov    %eax,(%rcx,%rsi,4)
 1f84679:	add    %ebp,%edi
 1f8467b:	cmp    $0x3,%r12d
 1f8467f:	mov    0x170(%r13),%rax
 1f84686:	sete   %cl
 1f84689:	add    %cl,%cl
 1f8468b:	cmp    $0x2,%r12d
 1f8468f:	movzbl %cl,%ecx
 1f84692:	cmove  %edx,%ecx
 1f84695:	mov    %di,(%rax,%rsi,2)
 1f84699:	mov    0xda0(%r11),%rax
 1f846a0:	mov    0x178(%r13),%rdx
 1f846a7:	xor    (%rax,%r15,1),%cl
 1f846ab:	mov    %cl,(%rdx,%rsi,1)
 1f846ae:	add    %rdi,0x188(%r13)
 1f846b5:	movzbl 0xdc4(%r11),%eax
 1f846bd:	add    %eax,0xdc8(%r11)
 1f846c4:	vmovd  %ebp,%xmm1
 1f846c8:	mov    0x60(%rsp),%rbp
 1f846cd:	mov    $0x101,%eax
 1f846d2:	mov    0x20(%rsp),%r13
 1f846d7:	bextr  %eax,%r14d,%eax
 1f846dc:	and    $0x1,%r14d
 1f846e0:	vmovd  %eax,%xmm0
 1f846e4:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f846e8:	vpaddq 0xcf0(%rbp),%xmm0,%xmm0
 1f846f0:	vmovdqu %xmm0,0xcf0(%rbp)
 1f846f8:	add    %r14,0xd00(%rbp)
 1f846ff:	jmp    1f83e72 <node_facts_window_run+0x6aa2>
 1f84704:	shlq   $0x20,0x320(%rsp)
 1f8470d:	shlq   $0x20,0x480(%rsp)
 1f84716:	shlq   $0x20,0x3e0(%rsp)
 1f8471f:	shlq   $0x20,0x2e0(%rsp)
 1f84728:	shlq   $0x20,0x440(%rsp)
 1f84731:	shlq   $0x20,0x600(%rsp)
 1f8473a:	shlq   $0x20,0x5c0(%rsp)
 1f84743:	shlq   $0x20,0x4c0(%rsp)
 1f8474c:	shlq   $0x20,0x100(%rsp)
 1f84755:	shlq   $0x20,0xf8(%rsp)
 1f8475e:	shlq   $0x20,0x88(%rsp)
 1f84767:	shlq   $0x20,0x770(%rsp)
 1f84770:	shlq   $0x20,0x420(%rsp)
 1f84779:	shlq   $0x20,0x730(%rsp)
 1f84782:	shlq   $0x20,0x520(%rsp)
 1f8478b:	mov    $0x1,%r8d
 1f84791:	vmovd  0x6f0(%rsp),%xmm1
 1f8479a:	mov    0x658(%rsp),%rbx
 1f847a2:	mov    0x650(%rsp),%r12
 1f847aa:	mov    0x16c(%rsp),%eax
 1f847b1:	vmovd  %ebx,%xmm0
 1f847b5:	shl    $0x20,%r12
 1f847b9:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f847bd:	vpaddq 0xbe8(%rbp),%xmm0,%xmm0
 1f847c5:	vmovdqu %xmm0,0xbe8(%rbp)
 1f847cd:	cmp    %eax,0x2a0(%rsp)
 1f847d4:	jne    1f84828 <node_facts_window_run+0x7458>
 1f847d6:	mov    0xca8(%r11),%rsi
 1f847dd:	mov    0xcb8(%r11),%rdi
 1f847e4:	mov    %rbx,%rdx
 1f847e7:	mov    %r11,%r14
 1f847ea:	call   355eaa0 <strlen+0x10>
 1f847ef:	mov    0xd8(%rsp),%r15
 1f847f7:	mov    0x80(%rsp),%rsi
 1f847ff:	mov    0x230(%rsp),%r13
 1f84807:	test   %eax,%eax
 1f84809:	je     1f8486d <node_facts_window_run+0x749d>
 1f8480b:	mov    %r14,%r11
 1f8480e:	mov    0x58(%rsp),%rax
 1f84813:	mov    0xa0(%rsp),%rcx
 1f8481b:	mov    0xf0(%rsp),%r14
 1f84823:	jmp    1f848ab <node_facts_window_run+0x74db>
 1f84828:	mov    0xd8(%rsp),%r15
 1f84830:	mov    0x80(%rsp),%rsi
 1f84838:	mov    0x230(%rsp),%r13
 1f84840:	mov    0x58(%rsp),%rax
 1f84845:	mov    0xa0(%rsp),%rcx
 1f8484d:	mov    0xf0(%rsp),%r14
 1f84855:	jmp    1f848b1 <node_facts_window_run+0x74e1>
 1f84857:	setb   %al
 1f8485a:	test   %r12d,%r12d
 1f8485d:	sete   %cl
 1f84860:	test   %cl,%al
 1f84862:	je     1f83981 <node_facts_window_run+0x65b1>
 1f84868:	jmp    1f8398e <node_facts_window_run+0x65be>
 1f8486d:	mov    0xcb0(%r14),%rsi
 1f84874:	mov    0xcc0(%r14),%rdi
 1f8487b:	mov    %rbx,%rdx
 1f8487e:	call   355eaa0 <strlen+0x10>
 1f84883:	test   %eax,%eax
 1f84885:	je     1f84d11 <node_facts_window_run+0x7941>
 1f8488b:	mov    %r14,%r11
 1f8488e:	mov    0x58(%rsp),%rax
 1f84893:	mov    0xa0(%rsp),%rcx
 1f8489b:	mov    0xf0(%rsp),%r14
 1f848a3:	mov    0x80(%rsp),%rsi
 1f848ab:	mov    $0x1,%r8d
 1f848b1:	mov    0x2e0(%rsp),%rdx
 1f848b9:	or     0x320(%rsp),%rsi
 1f848c1:	or     0x480(%rsp),%r13
 1f848c9:	or     0x3e0(%rsp),%rax
 1f848d1:	add    %r8,0xbf8(%rbp)
 1f848d8:	or     %r12,%r14
 1f848db:	or     %rdx,0x3a0(%rsp)
 1f848e3:	mov    0x440(%rsp),%rdx
 1f848eb:	or     %rdx,0x260(%rsp)
 1f848f3:	mov    0x600(%rsp),%rdx
 1f848fb:	or     %rdx,0x360(%rsp)
 1f84903:	mov    0x5c0(%rsp),%rdx
 1f8490b:	or     %rdx,0x1f0(%rsp)
 1f84913:	mov    0x100(%rsp),%rdx
 1f8491b:	or     0x4c0(%rsp),%rcx
 1f84923:	or     %rdx,0x580(%rsp)
 1f8492b:	mov    0xf8(%rsp),%rdx
 1f84933:	or     %rdx,0x540(%rsp)
 1f8493b:	mov    0x88(%rsp),%rdx
 1f84943:	or     %rdx,0x670(%rsp)
 1f8494b:	mov    0x770(%rsp),%rdx
 1f84953:	or     %rdx,0xb0(%rsp)
 1f8495b:	mov    0x420(%rsp),%rdx
 1f84963:	or     %rdx,0x48(%rsp)
 1f84968:	mov    0x730(%rsp),%rdx
 1f84970:	or     %rdx,0x98(%rsp)
 1f84978:	mov    0x520(%rsp),%rdx
 1f84980:	or     %rdx,0xa8(%rsp)
 1f84988:	cmpb   $0x1,0xd58(%r11)
 1f84990:	jne    1f84a2f <node_facts_window_run+0x765f>
 1f84996:	mov    0x164(%rsp),%edx
 1f8499d:	mov    $0x1,%ebx
 1f849a2:	xor    0x168(%rsp),%edx
 1f849a9:	cmp    0x150(%rsp),%edx
 1f849b0:	jne    1f84a38 <node_facts_window_run+0x7668>
 1f849b6:	mov    0xe4(%rsp),%edx
 1f849bd:	mov    %rax,0x58(%rsp)
 1f849c2:	cmp    0x154(%rsp),%edx
 1f849c9:	jne    1f84a33 <node_facts_window_run+0x7663>
 1f849cb:	mov    0xe8(%rsp),%eax
 1f849d2:	cmp    0x158(%rsp),%eax
 1f849d9:	jne    1f84a33 <node_facts_window_run+0x7663>
 1f849db:	mov    %rsi,0x80(%rsp)
 1f849e3:	mov    %rcx,0xa0(%rsp)
 1f849eb:	mov    0xd98(%r11),%rsi
 1f849f2:	mov    0xda8(%r11),%rdi
 1f849f9:	mov    %r11,%r12
 1f849fc:	mov    0x6f0(%rsp),%rax
 1f84a04:	lea    (%rax,%rax,1),%rdx
 1f84a08:	call   355eaa0 <strlen+0x10>
 1f84a0d:	test   %eax,%eax
 1f84a0f:	je     1f84de4 <node_facts_window_run+0x7a14>
 1f84a15:	mov    0x58(%rsp),%rax
 1f84a1a:	mov    0xa0(%rsp),%rcx
 1f84a22:	mov    0x80(%rsp),%rsi
 1f84a2a:	mov    %r12,%r11
 1f84a2d:	jmp    1f84a38 <node_facts_window_run+0x7668>
 1f84a2f:	xor    %ebx,%ebx
 1f84a31:	jmp    1f84a38 <node_facts_window_run+0x7668>
 1f84a33:	mov    0x58(%rsp),%rax
 1f84a38:	vmovd  0x238(%rsp),%xmm1
 1f84a41:	mov    0x1f0(%rsp),%rdx
 1f84a49:	vmovd  %ebx,%xmm2
 1f84a4d:	mov    0xa8(%rsp),%rdi
 1f84a55:	vpmovzxdq 0x810(%rsp),%ymm7
 1f84a5f:	vmovq  0x3a0(%rsp),%xmm4
 1f84a68:	vmovq  %r13,%xmm3
 1f84a6d:	vmovq  %rsi,%xmm5
 1f84a72:	mov    0x98(%rsp),%rsi
 1f84a7a:	mov    0x48(%rsp),%r8
 1f84a7f:	sub    %rdx,%rcx
 1f84a82:	sub    %rdi,%r14
 1f84a85:	vmovq  %rcx,%xmm0
 1f84a8a:	mov    0x360(%rsp),%rcx
 1f84a92:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84a96:	vmovd  0xe8(%rsp),%xmm1
 1f84a9f:	sub    %rcx,%rdx
 1f84aa2:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f84aa6:	vmovq  %rax,%xmm2
 1f84aab:	mov    0x260(%rsp),%rax
 1f84ab3:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f84ab9:	vpaddq 0xd08(%rbp),%ymm0,%ymm0
 1f84ac1:	vmovd  0x248(%rsp),%xmm1
 1f84aca:	vpbroadcastq %rax,%ymm6
 1f84ad0:	sub    %rax,%rcx
 1f84ad3:	mov    %rsi,%rax
 1f84ad6:	sub    %r8,%rax
 1f84ad9:	vmovdqu %ymm0,0xd08(%rbp)
 1f84ae1:	add    %r14,0xd28(%rbp)
 1f84ae8:	vmovq  0x240(%rsp),%xmm0
 1f84af1:	vpaddq 0xc90(%rbp),%ymm7,%ymm7
 1f84af9:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84afd:	vmovdqu %ymm7,0xc90(%rbp)
 1f84b05:	vpaddq 0xcb0(%rbp),%xmm0,%xmm0
 1f84b0d:	vmovdqu %xmm0,0xcb0(%rbp)
 1f84b15:	vpunpcklqdq %xmm2,%xmm3,%xmm0
 1f84b19:	vmovq  0xb0(%rsp),%xmm2
 1f84b22:	vmovq  0x670(%rsp),%xmm3
 1f84b2b:	vinserti128 $0x1,%xmm4,%ymm0,%ymm0
 1f84b31:	vpbroadcastq %r8,%ymm4
 1f84b37:	vpblendd $0xc0,%ymm6,%ymm0,%ymm1
 1f84b3d:	vpermq $0x90,%ymm0,%ymm0
 1f84b43:	vpbroadcastq %rsi,%ymm6
 1f84b49:	vpblendd $0x3,%ymm5,%ymm0,%ymm0
 1f84b4f:	vpbroadcastq %rdi,%ymm5
 1f84b55:	vpsubq %ymm0,%ymm1,%ymm0
 1f84b59:	vmovdqu 0x8a0(%rsp),%ymm1
 1f84b62:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f84b66:	vpblendd $0x30,%ymm4,%ymm2,%ymm3
 1f84b6c:	vpermq $0xd0,%ymm2,%ymm2
 1f84b72:	vmovdqa64 -0x1acddfc(%rip),%zmm4        # 4b6d80 <abi_test_hex.digits+0xba00>
 1f84b7c:	vpblendd $0xc0,%ymm5,%ymm3,%ymm3
 1f84b82:	vpmovzxdq 0x840(%rsp),%zmm5
 1f84b8a:	vinserti64x4 $0x1,%ymm0,%zmm1,%zmm0
 1f84b91:	vpaddq 0xc00(%rbp),%zmm0,%zmm0
 1f84b98:	vmovq  %rcx,%xmm1
 1f84b9d:	vmovdqu64 %zmm0,0xc00(%rbp)
 1f84ba4:	vmovq  %rax,%xmm0
 1f84ba9:	mov    0x540(%rsp),%rax
 1f84bb1:	add    %rdx,0xc40(%rbp)
 1f84bb8:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84bbc:	vpmovzxdq 0xe0(%rsp),%xmm1
 1f84bc6:	vmovq  %rax,%xmm7
 1f84bcb:	sub    0x580(%rsp),%rax
 1f84bd3:	vpblendd $0x3,%ymm7,%ymm2,%ymm2
 1f84bd9:	vpblendd $0xc0,%ymm6,%ymm2,%ymm2
 1f84bdf:	vmovdqa64 -0x1acdea9(%rip),%zmm6        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f84be9:	vpsubq %ymm2,%ymm3,%ymm2
 1f84bed:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f84bf3:	vpaddq 0xcc8(%rbp),%ymm0,%ymm0
 1f84bfb:	vmovq  %rax,%xmm8
 1f84c00:	mov    $0x80,%al
 1f84c02:	kmovd  %eax,%k1
 1f84c06:	mov    0x660(%rsp),%rax
 1f84c0e:	vpermi2q %zmm8,%zmm2,%zmm6
 1f84c14:	vmovdqu %ymm0,0xcc8(%rbp)
 1f84c1c:	vpermi2q %zmm5,%zmm6,%zmm4
 1f84c22:	vpbroadcastq %rax,%zmm4{%k1}
 1f84c28:	vpaddq 0xc50(%rbp),%zmm4,%zmm0
 1f84c32:	vmovdqu64 %zmm0,0xc50(%rbp)
 1f84c3c:	vmovups 0x9d0(%r11),%zmm0
 1f84c46:	vmovups 0x268(%r11),%zmm1
 1f84c50:	vmovups 0x860(%rsp),%zmm3
 1f84c5b:	vmovaps 0x830(%rsp),%xmm2
 1f84c64:	xor    %esi,%esi
 1f84c66:	mov    %r15,%rdx
 1f84c69:	vmovups %zmm0,0x268(%r11)
 1f84c73:	vmovups %zmm1,0x9d0(%r11)
 1f84c7d:	vmovups 0xa10(%r11),%xmm0
 1f84c86:	vmovups 0x2a8(%r11),%xmm1
 1f84c8f:	vmovups %xmm0,0x2a8(%r11)
 1f84c98:	vmovups %xmm1,0xa10(%r11)
 1f84ca1:	vmovaps 0x820(%rsp),%xmm1
 1f84caa:	mov    0x2b8(%r11),%rax
 1f84cb1:	mov    0xa20(%r11),%rcx
 1f84cb8:	mov    %rcx,0x2b8(%r11)
 1f84cbf:	mov    %rax,0xa20(%r11)
 1f84cc6:	mov    0x668(%rsp),%rax
 1f84cce:	vmovups %zmm3,0x1f0(%r11)
 1f84cd8:	mov    %rax,0x230(%r11)
 1f84cdf:	vmovups %xmm2,0x240(%r11)
 1f84ce8:	vmovlps %xmm1,0x258(%r11)
 1f84cf1:	mov    0x9b8(%r11),%rdi
 1f84cf8:	add    $0xcb8,%rsp
 1f84cff:	pop    %rbx
 1f84d00:	pop    %r12
 1f84d02:	pop    %r13
 1f84d04:	pop    %r14
 1f84d06:	pop    %r15
 1f84d08:	pop    %rbp
 1f84d09:	vzeroupper
 1f84d0c:	jmp    355eb20 <memset>
 1f84d11:	mov    0xcc8(%r14),%rsi
 1f84d18:	mov    0xcd0(%r14),%rdi
 1f84d1f:	mov    0x648(%rsp),%rdx
 1f84d27:	call   355eaa0 <strlen+0x10>
 1f84d2c:	test   %eax,%eax
 1f84d2e:	jne    1f84e71 <node_facts_window_run+0x7aa1>
 1f84d34:	movzbl 0x57(%rsp),%ecx
 1f84d39:	xor    %eax,%eax
 1f84d3b:	mov    0xf0(%rsp),%r14
 1f84d43:	mov    $0x1,%r8d
 1f84d49:	mov    %cl,%al
 1f84d4b:	xor    0x248(%rsp),%eax
 1f84d52:	mov    0xa0(%rsp),%rcx
 1f84d5a:	cmp    0x108(%rsp),%eax
 1f84d61:	mov    0x58(%rsp),%rax
 1f84d66:	jne    1f84e7a <node_facts_window_run+0x7aaa>
 1f84d6c:	movzbl 0x56(%rsp),%esi
 1f84d71:	mov    (%rsp),%r11
 1f84d75:	xor    %edx,%edx
 1f84d77:	mov    %sil,%dl
 1f84d7a:	xor    0x240(%rsp),%rdx
 1f84d82:	cmp    0x250(%rsp),%rdx
 1f84d8a:	jne    1f84e64 <node_facts_window_run+0x7a94>
 1f84d90:	vmovdqu 0x6dc(%rsp),%xmm1
 1f84d99:	vmovdqa 0x6d0(%rsp),%xmm0
 1f84da2:	mov    0x80(%rsp),%rsi
 1f84daa:	vpxor  0x6b0(%rsp),%xmm0,%xmm0
 1f84db3:	vpternlogq $0xf6,0x6bc(%rsp),%xmm1,%xmm0
 1f84dbf:	vptest %xmm0,%xmm0
 1f84dc4:	jne    1f848b1 <node_facts_window_run+0x74e1>
 1f84dca:	mov    0x160(%rsp),%edx
 1f84dd1:	xor    %r8d,%r8d
 1f84dd4:	cmp    %edx,0x238(%rsp)
 1f84ddb:	setne  %r8b
 1f84ddf:	jmp    1f848b1 <node_facts_window_run+0x74e1>
 1f84de4:	mov    0xda0(%r12),%rsi
 1f84dec:	mov    0xdb0(%r12),%rdi
 1f84df4:	mov    0x640(%rsp),%rdx
 1f84dfc:	call   355eaa0 <strlen+0x10>
 1f84e01:	mov    %r12,%r11
 1f84e04:	mov    0xa0(%rsp),%rcx
 1f84e0c:	mov    0x80(%rsp),%rsi
 1f84e14:	test   %eax,%eax
 1f84e16:	mov    0x58(%rsp),%rax
 1f84e1b:	jne    1f84a38 <node_facts_window_run+0x7668>
 1f84e21:	mov    0xe0(%rsp),%edx
 1f84e28:	mov    0xd90(%r11),%rsi
 1f84e2f:	mov    0xdb8(%r11),%rdi
 1f84e36:	shl    $0x2,%rdx
 1f84e3a:	call   355eaa0 <strlen+0x10>
 1f84e3f:	xor    %ebx,%ebx
 1f84e41:	test   %eax,%eax
 1f84e43:	mov    0x80(%rsp),%rsi
 1f84e4b:	mov    0xa0(%rsp),%rcx
 1f84e53:	mov    (%rsp),%r11
 1f84e57:	mov    0x58(%rsp),%rax
 1f84e5c:	setne  %bl
 1f84e5f:	jmp    1f84a38 <node_facts_window_run+0x7668>
 1f84e64:	mov    0x80(%rsp),%rsi
 1f84e6c:	jmp    1f848b1 <node_facts_window_run+0x74e1>
 1f84e71:	mov    (%rsp),%r11
 1f84e75:	jmp    1f8488e <node_facts_window_run+0x74be>
 1f84e7a:	mov    (%rsp),%r11
 1f84e7e:	mov    0x80(%rsp),%rsi
 1f84e86:	jmp    1f848b1 <node_facts_window_run+0x74e1>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
