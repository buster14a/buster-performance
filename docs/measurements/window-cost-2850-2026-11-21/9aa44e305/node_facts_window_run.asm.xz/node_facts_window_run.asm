
results/costv3/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f7d410 <node_facts_window_run>:
 1f7d410:	push   %rbp
 1f7d411:	push   %r15
 1f7d413:	push   %r14
 1f7d415:	push   %r13
 1f7d417:	push   %r12
 1f7d419:	push   %rbx
 1f7d41a:	sub    $0xca8,%rsp
 1f7d421:	mov    0x940(%rdi),%r14
 1f7d428:	mov    0x8(%rsi),%r15d
 1f7d42c:	mov    %rsi,%rbp
 1f7d42f:	test   %r15,%r15
 1f7d432:	je     1f7d5f6 <node_facts_window_run+0x1e6>
 1f7d438:	mov    %r15d,%eax
 1f7d43b:	and    $0x7,%eax
 1f7d43e:	cmp    $0x8,%r15d
 1f7d442:	jae    1f7d44b <node_facts_window_run+0x3b>
 1f7d444:	xor    %ecx,%ecx
 1f7d446:	jmp    1f7d9ee <node_facts_window_run+0x5de>
 1f7d44b:	mov    %r15d,%edx
 1f7d44e:	and    $0xfffffff8,%edx
 1f7d451:	xor    %ecx,%ecx
 1f7d453:	jmp    1f7d47b <node_facts_window_run+0x6b>
 1f7d455:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7d460:	xor    %esi,%esi
 1f7d462:	mov    0x9c0(%rdi),%r8
 1f7d469:	mov    %sil,0x7(%r8,%rcx,1)
 1f7d46e:	add    $0x8,%rcx
 1f7d472:	cmp    %rcx,%rdx
 1f7d475:	je     1f7d5ed <node_facts_window_run+0x1dd>
 1f7d47b:	mov    0x9b8(%rdi),%rsi
 1f7d482:	cmpb   $0x0,(%rsi,%rcx,1)
 1f7d486:	je     1f7d4a0 <node_facts_window_run+0x90>
 1f7d488:	movzbl 0x69454(%rbp,%rcx,1),%esi
 1f7d490:	jmp    1f7d4a2 <node_facts_window_run+0x92>
 1f7d492:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d4a0:	xor    %esi,%esi
 1f7d4a2:	mov    0x9c0(%rdi),%r8
 1f7d4a9:	mov    %sil,(%r8,%rcx,1)
 1f7d4ad:	mov    0x9b8(%rdi),%rsi
 1f7d4b4:	cmpb   $0x0,0x1(%rsi,%rcx,1)
 1f7d4b9:	je     1f7d4d0 <node_facts_window_run+0xc0>
 1f7d4bb:	movzbl 0x69455(%rbp,%rcx,1),%esi
 1f7d4c3:	jmp    1f7d4d2 <node_facts_window_run+0xc2>
 1f7d4c5:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7d4d0:	xor    %esi,%esi
 1f7d4d2:	mov    0x9c0(%rdi),%r8
 1f7d4d9:	mov    %sil,0x1(%r8,%rcx,1)
 1f7d4de:	mov    0x9b8(%rdi),%rsi
 1f7d4e5:	cmpb   $0x0,0x2(%rsi,%rcx,1)
 1f7d4ea:	je     1f7d500 <node_facts_window_run+0xf0>
 1f7d4ec:	movzbl 0x69456(%rbp,%rcx,1),%esi
 1f7d4f4:	jmp    1f7d502 <node_facts_window_run+0xf2>
 1f7d4f6:	cs nopw 0x0(%rax,%rax,1)
 1f7d500:	xor    %esi,%esi
 1f7d502:	mov    0x9c0(%rdi),%r8
 1f7d509:	mov    %sil,0x2(%r8,%rcx,1)
 1f7d50e:	mov    0x9b8(%rdi),%rsi
 1f7d515:	cmpb   $0x0,0x3(%rsi,%rcx,1)
 1f7d51a:	je     1f7d530 <node_facts_window_run+0x120>
 1f7d51c:	movzbl 0x69457(%rbp,%rcx,1),%esi
 1f7d524:	jmp    1f7d532 <node_facts_window_run+0x122>
 1f7d526:	cs nopw 0x0(%rax,%rax,1)
 1f7d530:	xor    %esi,%esi
 1f7d532:	mov    0x9c0(%rdi),%r8
 1f7d539:	mov    %sil,0x3(%r8,%rcx,1)
 1f7d53e:	mov    0x9b8(%rdi),%rsi
 1f7d545:	cmpb   $0x0,0x4(%rsi,%rcx,1)
 1f7d54a:	je     1f7d560 <node_facts_window_run+0x150>
 1f7d54c:	movzbl 0x69458(%rbp,%rcx,1),%esi
 1f7d554:	jmp    1f7d562 <node_facts_window_run+0x152>
 1f7d556:	cs nopw 0x0(%rax,%rax,1)
 1f7d560:	xor    %esi,%esi
 1f7d562:	mov    0x9c0(%rdi),%r8
 1f7d569:	mov    %sil,0x4(%r8,%rcx,1)
 1f7d56e:	mov    0x9b8(%rdi),%rsi
 1f7d575:	cmpb   $0x0,0x5(%rsi,%rcx,1)
 1f7d57a:	je     1f7d590 <node_facts_window_run+0x180>
 1f7d57c:	movzbl 0x69459(%rbp,%rcx,1),%esi
 1f7d584:	jmp    1f7d592 <node_facts_window_run+0x182>
 1f7d586:	cs nopw 0x0(%rax,%rax,1)
 1f7d590:	xor    %esi,%esi
 1f7d592:	mov    0x9c0(%rdi),%r8
 1f7d599:	mov    %sil,0x5(%r8,%rcx,1)
 1f7d59e:	mov    0x9b8(%rdi),%rsi
 1f7d5a5:	cmpb   $0x0,0x6(%rsi,%rcx,1)
 1f7d5aa:	je     1f7d5c0 <node_facts_window_run+0x1b0>
 1f7d5ac:	movzbl 0x6945a(%rbp,%rcx,1),%esi
 1f7d5b4:	jmp    1f7d5c2 <node_facts_window_run+0x1b2>
 1f7d5b6:	cs nopw 0x0(%rax,%rax,1)
 1f7d5c0:	xor    %esi,%esi
 1f7d5c2:	mov    0x9c0(%rdi),%r8
 1f7d5c9:	mov    %sil,0x6(%r8,%rcx,1)
 1f7d5ce:	mov    0x9b8(%rdi),%rsi
 1f7d5d5:	cmpb   $0x0,0x7(%rsi,%rcx,1)
 1f7d5da:	je     1f7d460 <node_facts_window_run+0x50>
 1f7d5e0:	movzbl 0x6945b(%rbp,%rcx,1),%esi
 1f7d5e8:	jmp    1f7d462 <node_facts_window_run+0x52>
 1f7d5ed:	test   %rax,%rax
 1f7d5f0:	jne    1f7d9ee <node_facts_window_run+0x5de>
 1f7d5f6:	vpbroadcastq %rbp,%ymm0
 1f7d5fc:	vpaddq -0x19bbde4(%rip),%ymm0,%ymm0        # 5c1820 <.LCPI3_0>
 1f7d604:	vmovups 0x1f0(%rdi),%zmm1
 1f7d60e:	mov    0x9c0(%rdi),%rax
 1f7d615:	mov    0x9c8(%rdi),%rdx
 1f7d61c:	mov    0x69250(%rbp),%r8d
 1f7d623:	lea    0x2c(%rbp),%r11
 1f7d627:	lea    0x6a4d4(%rbp),%rcx
 1f7d62e:	lea    0x79854(%rbp),%rsi
 1f7d635:	lea    0x73754(%rbp),%r9
 1f7d63c:	mov    0x230(%rdi),%r10
 1f7d643:	vmovdqu 0x240(%rdi),%xmm3
 1f7d64b:	vmovq  0x258(%rdi),%xmm2
 1f7d653:	mov    %r11,0x1f0(%rdi)
 1f7d65a:	mov    %rax,0x1f8(%rdi)
 1f7d661:	mov    %rcx,0x200(%rdi)
 1f7d668:	mov    %rdx,0x208(%rdi)
 1f7d66f:	mov    $0x1,%edx
 1f7d674:	vmovdqu %ymm0,0x210(%rdi)
 1f7d67c:	mov    %rsi,0x230(%rdi)
 1f7d683:	mov    %r9,0x240(%rdi)
 1f7d68a:	mov    %r8d,0x258(%rdi)
 1f7d691:	vmovups %zmm1,0x850(%rsp)
 1f7d69c:	mov    %r10,0x658(%rsp)
 1f7d6a4:	vmovdqa %xmm3,0x820(%rsp)
 1f7d6ad:	vmovdqa %xmm2,0x810(%rsp)
 1f7d6b6:	mov    %r11,0xb8(%rsp)
 1f7d6be:	xor    %esi,%esi
 1f7d6c0:	mov    %rdi,(%rsp)
 1f7d6c4:	vmovups 0x9d0(%rdi),%zmm0
 1f7d6ce:	vmovups 0x268(%rdi),%zmm1
 1f7d6d8:	vmovups %zmm0,0x268(%rdi)
 1f7d6e2:	vmovups %zmm1,0x9d0(%rdi)
 1f7d6ec:	vmovdqu 0xa10(%rdi),%xmm0
 1f7d6f4:	vmovdqu 0x2a8(%rdi),%xmm1
 1f7d6fc:	vmovdqu %xmm0,0x2a8(%rdi)
 1f7d704:	vmovdqu %xmm1,0xa10(%rdi)
 1f7d70c:	mov    0xa20(%rdi),%rcx
 1f7d713:	mov    0x2b8(%rdi),%rax
 1f7d71a:	mov    %rcx,0x2b8(%rdi)
 1f7d721:	lea    0xa28(%rdi),%rcx
 1f7d728:	mov    %rax,0xa20(%rdi)
 1f7d72f:	movl   $0x0,0xa28(%rdi)
 1f7d739:	mov    %r15d,0xa2c(%rdi)
 1f7d740:	mov    %rcx,0x248(%rdi)
 1f7d747:	movl   $0x0,0x25c(%rdi)
 1f7d751:	vzeroupper
 1f7d754:	call   1f7bb50 <node_facts_given>
 1f7d759:	mov    (%rsp),%rax
 1f7d75d:	mov    (%rsp),%rdi
 1f7d761:	xor    %esi,%esi
 1f7d763:	xor    %edx,%edx
 1f7d765:	xor    %ecx,%ecx
 1f7d767:	mov    0xe0(%rax),%rbx
 1f7d76e:	call   1f7bd40 <node_facts_window>
 1f7d773:	mov    (%rsp),%rax
 1f7d777:	mov    (%rsp),%rdi
 1f7d77b:	xor    %esi,%esi
 1f7d77d:	mov    0xe0(%rax),%rax
 1f7d784:	sub    %rbx,%rax
 1f7d787:	add    %rax,0xa30(%r14)
 1f7d78e:	call   1f7c990 <node_facts_lists_same>
 1f7d793:	mov    (%rsp),%rdi
 1f7d797:	test   %al,%al
 1f7d799:	jne    1f7d7ed <node_facts_window_run+0x3dd>
 1f7d79b:	incq   0xa00(%r14)
 1f7d7a2:	mov    0x940(%rdi),%rax
 1f7d7a9:	mov    0x11e0(%rax),%ecx
 1f7d7af:	cmp    $0xf,%rcx
 1f7d7b3:	ja     1f7d7ed <node_facts_window_run+0x3dd>
 1f7d7b5:	mov    0x422c(%rbp),%edx
 1f7d7bb:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7d7c2:	mov    0x1f0(%rdi),%rcx
 1f7d7c9:	mov    0x11e0(%rax),%edx
 1f7d7cf:	movzbl (%rcx),%ecx
 1f7d7d2:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7d7d9:	mov    0x11e0(%rax),%ecx
 1f7d7df:	movb   $0x2,0x11d0(%rax,%rcx,1)
 1f7d7e7:	incl   0x11e0(%rax)
 1f7d7ed:	mov    %r15,0xc0(%rsp)
 1f7d7f5:	mov    %rbp,0x28(%rsp)
 1f7d7fa:	test   %r15d,%r15d
 1f7d7fd:	je     1f7dab5 <node_facts_window_run+0x6a5>
 1f7d803:	mov    $0x1a,%r15d
 1f7d809:	mov    $0xcc,%ebp
 1f7d80e:	mov    $0x102,%r12d
 1f7d814:	mov    $0x8c,%r13d
 1f7d81a:	xor    %ebx,%ebx
 1f7d81c:	jmp    1f7d835 <node_facts_window_run+0x425>
 1f7d81e:	xchg   %ax,%ax
 1f7d820:	inc    %rbx
 1f7d823:	add    $0x40,%r15
 1f7d827:	cmp    %rbx,0xc0(%rsp)
 1f7d82f:	je     1f7d9ff <node_facts_window_run+0x5ef>
 1f7d835:	mov    0x1f8(%rdi),%rax
 1f7d83c:	movzbl (%rax,%rbx,1),%eax
 1f7d840:	cmp    $0x7,%eax
 1f7d843:	ja     1f7d820 <node_facts_window_run+0x410>
 1f7d845:	bt     %eax,%ebp
 1f7d848:	jae    1f7d820 <node_facts_window_run+0x410>
 1f7d84a:	mov    %eax,%ecx
 1f7d84c:	mov    0x2c0(%rdi),%rsi
 1f7d853:	and    $0xfe,%cl
 1f7d856:	cmp    $0x2,%cl
 1f7d859:	sete   %cl
 1f7d85c:	cmp    $0x7,%eax
 1f7d85f:	sete   %dl
 1f7d862:	or     %cl,%dl
 1f7d864:	movzbl -0x1(%rsi,%r15,1),%ecx
 1f7d86a:	movzbl %dl,%edx
 1f7d86d:	add    %rdx,0x9f0(%r14)
 1f7d874:	cmp    $0x7,%eax
 1f7d877:	ja     1f7d9b2 <node_facts_window_run+0x5a2>
 1f7d87d:	bt     %eax,%r13d
 1f7d881:	mov    $0x0,%edx
 1f7d886:	jae    1f7d894 <node_facts_window_run+0x484>
 1f7d888:	lea    -0x1(%rcx),%esi
 1f7d88b:	xor    %edx,%edx
 1f7d88d:	cmp    $0x2,%sil
 1f7d891:	setb   %dl
 1f7d894:	add    %rdx,0x9f8(%r14)
 1f7d89b:	xor    %edx,%edx
 1f7d89d:	cmp    $0x7,%eax
 1f7d8a0:	ja     1f7d8b6 <node_facts_window_run+0x4a6>
 1f7d8a2:	bt     %eax,%r13d
 1f7d8a6:	jae    1f7d8b6 <node_facts_window_run+0x4a6>
 1f7d8a8:	mov    0x1f0(%rdi),%rax
 1f7d8af:	cmpb   $0x22,(%rax,%rbx,1)
 1f7d8b3:	sete   %dl
 1f7d8b6:	dec    %cl
 1f7d8b8:	vmovd  %edx,%xmm0
 1f7d8bc:	cmp    $0x2,%cl
 1f7d8bf:	setb   %al
 1f7d8c2:	and    %dl,%al
 1f7d8c4:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f7d8ca:	vpmovzxbq %xmm0,%xmm0
 1f7d8cf:	vptestmq -0x19af3a1(%rip){1to2},%xmm0,%k0        # 5ce538 <.LCPI3_1>
 1f7d8d9:	vmovdqu 0xa10(%r14),%xmm0
 1f7d8e2:	vpmovm2q %k0,%xmm1
 1f7d8e8:	vpsubq %xmm1,%xmm0,%xmm0
 1f7d8ec:	vmovdqu %xmm0,0xa10(%r14)
 1f7d8f5:	cmp    $0x1,%al
 1f7d8f7:	jne    1f7d930 <node_facts_window_run+0x520>
 1f7d8f9:	mov    0x2c0(%rdi),%rax
 1f7d900:	movzwl (%rax,%r15,1),%eax
 1f7d905:	bt     $0x1,%eax
 1f7d909:	adcq   $0x0,0xa20(%r14)
 1f7d911:	mov    0x2c0(%rdi),%rax
 1f7d918:	movzwl (%rax,%r15,1),%eax
 1f7d91d:	bextr  %r12d,%eax,%eax
 1f7d922:	jmp    1f7d932 <node_facts_window_run+0x522>
 1f7d924:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d930:	xor    %eax,%eax
 1f7d932:	add    %rax,0xa28(%r14)
 1f7d939:	xor    %esi,%esi
 1f7d93b:	mov    %ebx,%edx
 1f7d93d:	xor    %ecx,%ecx
 1f7d93f:	call   1f7cfb0 <node_facts_same>
 1f7d944:	mov    (%rsp),%rdi
 1f7d948:	test   %al,%al
 1f7d94a:	jne    1f7d820 <node_facts_window_run+0x410>
 1f7d950:	incq   0xa00(%r14)
 1f7d957:	mov    0x940(%rdi),%rax
 1f7d95e:	mov    0x11e0(%rax),%ecx
 1f7d964:	cmp    $0xf,%rcx
 1f7d968:	ja     1f7d820 <node_facts_window_run+0x410>
 1f7d96e:	mov    0x28(%rsp),%rdx
 1f7d973:	mov    0x422c(%rdx,%rbx,4),%edx
 1f7d97a:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7d981:	mov    0x1f0(%rdi),%rcx
 1f7d988:	mov    0x11e0(%rax),%edx
 1f7d98e:	movzbl (%rcx,%rbx,1),%ecx
 1f7d992:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7d999:	mov    0x11e0(%rax),%ecx
 1f7d99f:	movb   $0x5,0x11d0(%rax,%rcx,1)
 1f7d9a7:	incl   0x11e0(%rax)
 1f7d9ad:	jmp    1f7d820 <node_facts_window_run+0x410>
 1f7d9b2:	xor    %edx,%edx
 1f7d9b4:	add    %rdx,0x9f8(%r14)
 1f7d9bb:	xor    %edx,%edx
 1f7d9bd:	cmp    $0x7,%eax
 1f7d9c0:	jbe    1f7d8a2 <node_facts_window_run+0x492>
 1f7d9c6:	jmp    1f7d8b6 <node_facts_window_run+0x4a6>
 1f7d9cb:	nopl   0x0(%rax,%rax,1)
 1f7d9d0:	movzbl 0x69454(%rbp,%rcx,1),%edx
 1f7d9d8:	mov    0x9c0(%rdi),%rsi
 1f7d9df:	mov    %dl,(%rsi,%rcx,1)
 1f7d9e2:	inc    %rcx
 1f7d9e5:	dec    %rax
 1f7d9e8:	je     1f7d5f6 <node_facts_window_run+0x1e6>
 1f7d9ee:	mov    0x9b8(%rdi),%rdx
 1f7d9f5:	cmpb   $0x0,(%rdx,%rcx,1)
 1f7d9f9:	jne    1f7d9d0 <node_facts_window_run+0x5c0>
 1f7d9fb:	xor    %edx,%edx
 1f7d9fd:	jmp    1f7d9d8 <node_facts_window_run+0x5c8>
 1f7d9ff:	mov    $0x3,%edx
 1f7da04:	xor    %esi,%esi
 1f7da06:	xor    %ebx,%ebx
 1f7da08:	call   1f7bb50 <node_facts_given>
 1f7da0d:	mov    (%rsp),%rdi
 1f7da11:	xor    %esi,%esi
 1f7da13:	xor    %edx,%edx
 1f7da15:	xor    %ecx,%ecx
 1f7da17:	call   1f7bd40 <node_facts_window>
 1f7da1c:	mov    (%rsp),%rdi
 1f7da20:	mov    0xc0(%rsp),%r15
 1f7da28:	mov    0x28(%rsp),%rbp
 1f7da2d:	jmp    1f7da3c <node_facts_window_run+0x62c>
 1f7da2f:	nop
 1f7da30:	inc    %rbx
 1f7da33:	cmp    %rbx,%r15
 1f7da36:	je     1f7dad4 <node_facts_window_run+0x6c4>
 1f7da3c:	mov    0x1f8(%rdi),%rax
 1f7da43:	testb  $0x2,(%rax,%rbx,1)
 1f7da47:	je     1f7da30 <node_facts_window_run+0x620>
 1f7da49:	xor    %esi,%esi
 1f7da4b:	mov    %ebx,%edx
 1f7da4d:	xor    %ecx,%ecx
 1f7da4f:	call   1f7cfb0 <node_facts_same>
 1f7da54:	mov    (%rsp),%rdi
 1f7da58:	test   %al,%al
 1f7da5a:	jne    1f7da30 <node_facts_window_run+0x620>
 1f7da5c:	incq   0xa00(%r14)
 1f7da63:	mov    0x940(%rdi),%rax
 1f7da6a:	mov    0x11e0(%rax),%ecx
 1f7da70:	cmp    $0xf,%rcx
 1f7da74:	ja     1f7da30 <node_facts_window_run+0x620>
 1f7da76:	mov    0x422c(%rbp,%rbx,4),%edx
 1f7da7d:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7da84:	mov    0x1f0(%rdi),%rcx
 1f7da8b:	mov    0x11e0(%rax),%edx
 1f7da91:	movzbl (%rcx,%rbx,1),%ecx
 1f7da95:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7da9c:	mov    0x11e0(%rax),%ecx
 1f7daa2:	movb   $0x1,0x11d0(%rax,%rcx,1)
 1f7daaa:	incl   0x11e0(%rax)
 1f7dab0:	jmp    1f7da30 <node_facts_window_run+0x620>
 1f7dab5:	mov    $0x3,%edx
 1f7daba:	xor    %esi,%esi
 1f7dabc:	call   1f7bb50 <node_facts_given>
 1f7dac1:	mov    (%rsp),%rdi
 1f7dac5:	xor    %esi,%esi
 1f7dac7:	xor    %edx,%edx
 1f7dac9:	xor    %ecx,%ecx
 1f7dacb:	call   1f7bd40 <node_facts_window>
 1f7dad0:	mov    (%rsp),%rdi
 1f7dad4:	xor    %esi,%esi
 1f7dad6:	xor    %edx,%edx
 1f7dad8:	call   1f7bb50 <node_facts_given>
 1f7dadd:	mov    (%rsp),%rax
 1f7dae1:	xor    %esi,%esi
 1f7dae3:	xor    %ecx,%ecx
 1f7dae5:	mov    0xd0(%rax),%r15
 1f7daec:	rdtsc
 1f7daee:	mov    (%rsp),%rdi
 1f7daf2:	mov    %rdx,%rbx
 1f7daf5:	shl    $0x20,%rbx
 1f7daf9:	xor    %edx,%edx
 1f7dafb:	or     %rax,%rbx
 1f7dafe:	call   1f7bd40 <node_facts_window>
 1f7db03:	mov    (%rsp),%r11
 1f7db07:	rdtsc
 1f7db09:	shl    $0x20,%rdx
 1f7db0d:	or     %rax,%rdx
 1f7db10:	sub    %rbx,%rdx
 1f7db13:	add    %rdx,0xa08(%r14)
 1f7db1a:	mov    0xd0(%r11),%rax
 1f7db21:	sub    %r15,%rax
 1f7db24:	mov    0xc0(%rsp),%r15
 1f7db2c:	add    %rax,0xa38(%r14)
 1f7db33:	mov    0x950(%r11),%rdi
 1f7db3a:	test   %rdi,%rdi
 1f7db3d:	je     1f84d56 <node_facts_window_run+0x7946>
 1f7db43:	mov    0x9e8(%rdi),%rax
 1f7db4a:	mov    0x950(%rdi),%r9
 1f7db51:	lea    0x757d4(%rbp),%r12
 1f7db58:	mov    %rax,0x50(%rsp)
 1f7db5d:	mov    (%r11),%rax
 1f7db60:	mov    %rax,0xb0(%rsp)
 1f7db68:	mov    0x948(%r11),%rax
 1f7db6f:	mov    %rax,0xa8(%rsp)
 1f7db77:	mov    0x8(%rax),%rax
 1f7db7b:	mov    0x78(%rax),%eax
 1f7db7e:	mov    %eax,0xa0(%rsp)
 1f7db85:	movzbl 0xa10(%rdi),%eax
 1f7db8c:	mov    %al,0x68(%rsp)
 1f7db90:	rdtsc
 1f7db92:	mov    0x8(%rbp),%esi
 1f7db95:	mov    0x2c0(%r11),%r8
 1f7db9c:	mov    %rax,0xf0(%rsp)
 1f7dba4:	lea    0x3f(%rsi),%eax
 1f7dba7:	mov    %rdx,0xe8(%rsp)
 1f7dbaf:	mov    %r9,0x40(%rsp)
 1f7dbb4:	mov    %rdi,0x10(%rsp)
 1f7dbb9:	mov    %r12,0x30(%rsp)
 1f7dbbe:	mov    %rsi,0x18(%rsp)
 1f7dbc3:	mov    %r8,0x20(%rsp)
 1f7dbc8:	and    $0xffffffc0,%eax
 1f7dbcb:	cmpq   $0x0,0xc20(%r11)
 1f7dbd3:	je     1f7e8a0 <node_facts_window_run+0x1490>
 1f7dbd9:	cmpb   $0x1,0xd58(%r11)
 1f7dbe1:	jne    1f7f2f0 <node_facts_window_run+0x1ee0>
 1f7dbe7:	test   %eax,%eax
 1f7dbe9:	je     1f807f5 <node_facts_window_run+0x33e5>
 1f7dbef:	vpbroadcastd -0x19acc7d(%rip),%zmm14        # 5d0f7c <.LCPI3_5>
 1f7dbf9:	vpbroadcastb -0x1ac6ec2(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7dc02:	vpbroadcastb -0x1ac6ecb(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7dc0c:	vpbroadcastd -0x19acc92(%rip),%zmm17        # 5d0f84 <.LCPI3_11>
 1f7dc16:	vpbroadcastd -0x19acc94(%rip),%zmm18        # 5d0f8c <.LCPI3_13>
 1f7dc20:	mov    (%r11),%rcx
 1f7dc23:	lea    0x69454(%rbp),%r10
 1f7dc2a:	lea    0x422c(%rbp),%rdx
 1f7dc31:	mov    %eax,%r15d
 1f7dc34:	xor    %ebx,%ebx
 1f7dc36:	mov    %rcx,0x78(%rsp)
 1f7dc3b:	mov    %r10,0x98(%rsp)
 1f7dc43:	mov    %rdx,0x80(%rsp)
 1f7dc4b:	movq   $0x0,0x48(%rsp)
 1f7dc54:	movq   $0x0,0x38(%rsp)
 1f7dc5d:	movq   $0x0,0x8(%rsp)
 1f7dc66:	mov    %r15,0x90(%rsp)
 1f7dc6e:	jmp    1f7dd46 <node_facts_window_run+0x936>
 1f7dc73:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7dc80:	vpxor  %xmm1,%xmm1,%xmm1
 1f7dc84:	vpxor  %xmm0,%xmm0,%xmm0
 1f7dc88:	vpxor  %xmm5,%xmm5,%xmm5
 1f7dc8c:	vpxor  %xmm4,%xmm4,%xmm4
 1f7dc90:	vpxor  %xmm3,%xmm3,%xmm3
 1f7dc94:	vpxor  %xmm7,%xmm7,%xmm7
 1f7dc98:	vpxor  %xmm8,%xmm8,%xmm8
 1f7dc9d:	vpxor  %xmm9,%xmm9,%xmm9
 1f7dca2:	vpxor  %xmm2,%xmm2,%xmm2
 1f7dca6:	vpxord %xmm20,%xmm20,%xmm20
 1f7dcac:	mov    0x990(%rdi),%rax
 1f7dcb3:	vmovdqu64 %xmm20,(%rax,%rbx,1)
 1f7dcba:	mov    0x998(%rdi),%rax
 1f7dcc1:	vmovdqu %xmm2,(%rax,%rbx,1)
 1f7dcc6:	mov    0xb88(%r11),%rax
 1f7dccd:	vmovdqu %xmm9,(%rax,%rbx,1)
 1f7dcd2:	mov    0xb90(%r11),%rax
 1f7dcd9:	vmovdqu %xmm8,(%rax,%rbx,1)
 1f7dcde:	mov    0xb98(%r11),%rax
 1f7dce5:	vmovdqu %xmm7,(%rax,%rbx,1)
 1f7dcea:	mov    0xba0(%r11),%rax
 1f7dcf1:	vmovdqu %xmm3,(%rax,%rbx,1)
 1f7dcf6:	mov    0xba8(%r11),%rax
 1f7dcfd:	vmovdqu %xmm4,(%rax,%rbx,1)
 1f7dd02:	mov    0xc28(%r11),%rax
 1f7dd09:	vmovdqu64 %zmm5,(%rax,%rbx,4)
 1f7dd10:	mov    0xcd8(%r11),%rax
 1f7dd17:	vmovdqu64 %zmm0,(%rax,%rbx,8)
 1f7dd1e:	mov    0xcd8(%r11),%rax
 1f7dd25:	vmovdqu64 %zmm1,0x40(%rax,%rbx,8)
 1f7dd2d:	mov    0xd60(%r11),%rax
 1f7dd34:	vmovdqu %xmm6,(%rax,%rbx,1)
 1f7dd39:	add    $0x10,%rbx
 1f7dd3d:	cmp    %r15,%rbx
 1f7dd40:	jae    1f80810 <node_facts_window_run+0x3400>
 1f7dd46:	vpxor  %xmm6,%xmm6,%xmm6
 1f7dd4a:	cmp    %rsi,%rbx
 1f7dd4d:	jae    1f7dc80 <node_facts_window_run+0x870>
 1f7dd53:	mov    %esi,%eax
 1f7dd55:	sub    %ebx,%eax
 1f7dd57:	mov    $0x10,%ecx
 1f7dd5c:	mov    $0xffffffff,%edx
 1f7dd61:	mov    %rbx,%rbp
 1f7dd64:	vpxor  %xmm12,%xmm12,%xmm12
 1f7dd69:	cmp    $0x10,%eax
 1f7dd6c:	cmovae %ecx,%eax
 1f7dd6f:	mov    0x9b8(%r11),%rcx
 1f7dd76:	shl    $0x6,%rbp
 1f7dd7a:	shlx   %eax,%edx,%eax
 1f7dd7f:	vmovdqu (%r8,%rbp,1),%ymm4
 1f7dd85:	vmovdqu64 0x40(%r8,%rbp,1),%ymm26
 1f7dd8d:	vmovdqu64 0x80(%r8,%rbp,1),%ymm27
 1f7dd95:	vmovdqu64 0xc0(%r8,%rbp,1),%ymm28
 1f7dd9d:	vmovdqu 0x100(%r8,%rbp,1),%ymm5
 1f7dda7:	vmovdqu 0x140(%r8,%rbp,1),%ymm6
 1f7ddb1:	vmovdqu64 0x180(%r8,%rbp,1),%ymm24
 1f7ddb9:	vmovdqu64 0x1c0(%r8,%rbp,1),%ymm25
 1f7ddc1:	vmovdqu 0x200(%r8,%rbp,1),%ymm7
 1f7ddcb:	vmovdqu 0x240(%r8,%rbp,1),%ymm13
 1f7ddd5:	vmovdqu64 0x280(%r8,%rbp,1),%ymm22
 1f7dddd:	vmovdqu64 0x2c0(%r8,%rbp,1),%ymm23
 1f7dde5:	vmovdqu 0x300(%r8,%rbp,1),%ymm11
 1f7ddef:	vmovdqu64 0x340(%r8,%rbp,1),%ymm19
 1f7ddf7:	vmovdqu64 0x380(%r8,%rbp,1),%ymm20
 1f7ddff:	vmovdqu64 0x3c0(%r8,%rbp,1),%ymm21
 1f7de07:	not    %eax
 1f7de09:	kmovd  %eax,%k1
 1f7de0d:	mov    0x9c8(%rdi),%rax
 1f7de14:	vmovdqu8 (%rcx,%rbx,1),%xmm0{%k1}{z}
 1f7de1b:	mov    0x98(%rsp),%rcx
 1f7de23:	vmovdqu8 (%rcx,%rbx,1),%xmm10{%k1}{z}
 1f7de2a:	vptestmb %xmm0,%xmm0,%k6
 1f7de30:	vpcmpeqb -0x19b612a(%rip),%xmm10,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7de3a:	vmovdqu32 (%r12,%rbx,4),%zmm0{%k7}{z}
 1f7de41:	kmovq  %k7,%k1
 1f7de46:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7de4d:	vptestnmd %zmm17,%zmm12,%k0
 1f7de53:	ktestw %k0,%k7
 1f7de57:	jne    1f7e594 <node_facts_window_run+0x1184>
 1f7de5d:	vpmovsxbd -0x19acea6(%rip),%xmm3        # 5d0fc0 <.LCPI3_77>
 1f7de66:	vmovdqa64 -0x1ac7730(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7de70:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7de77:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7de7e:	vptestmd -0x19acf00(%rip){1to16},%zmm12,%k0        # 5d0f88 <.LCPI3_12>
 1f7de88:	vmovdqa64 %zmm0,%zmm2
 1f7de8e:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7de94:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7de9a:	vmovdqa64 %zmm3,%zmm9
 1f7dea0:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7dea6:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7deac:	kmovd  %k0,%r13d
 1f7deb0:	vptestmd %zmm18,%zmm12,%k0
 1f7deb6:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7debc:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7dec3:	vmovdqu64 %zmm1,0x1e0(%rsp)
 1f7dece:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7ded5:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7ded9:	vmovdqa64 %zmm1,%zmm4
 1f7dedf:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7dee5:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7deeb:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7def1:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7def7:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7defe:	vmovdqu %ymm3,0x160(%rsp)
 1f7df07:	vinserti64x4 $0x1,%ymm13,%zmm7,%zmm3
 1f7df0e:	vpunpcklqdq %ymm13,%ymm7,%ymm7
 1f7df13:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm13
 1f7df1a:	vmovdqa64 %zmm3,%zmm6
 1f7df20:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7df26:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7df2c:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7df32:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7df38:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7df3e:	vmovdqa64 %zmm13,%zmm7
 1f7df44:	vmovdqu64 %zmm5,0x290(%rsp)
 1f7df4f:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7df56:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7df5c:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7df63:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7df6a:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7df70:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7df77:	vpermt2d %zmm5,%zmm9,%zmm13
 1f7df7d:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7df83:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7df89:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7df90:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7df97:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7df9e:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7dfa5:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm21{%k6}{z}
 1f7dfac:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7dfb3:	vpsrld $0x19,%zmm19,%zmm0
 1f7dfba:	vpandd -0x19ad04c(%rip){1to16},%zmm0,%zmm0        # 5d0f78 <.LCPI3_4>
 1f7dfc4:	vpsrld $0x18,%zmm19,%zmm1
 1f7dfcb:	vpsrld $0x1a,%zmm19,%zmm7
 1f7dfd2:	vpternlogd $0xec,%zmm14,%zmm0,%zmm1
 1f7dfd9:	vpandd -0x19ad01f(%rip){1to16},%zmm19,%zmm0        # 5d0fc4 <.LCPI3_78>
 1f7dfe3:	vpmovdb %zmm1,%xmm20
 1f7dfe9:	vpsrld $0xc,%zmm21,%zmm1
 1f7dff0:	vpmovdb %zmm1,%xmm24
 1f7dff6:	vpcmpeqd -0x19ad080(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f80 <.LCPI3_7>
 1f7e000:	vporq  %xmm15,%xmm20,%xmm0
 1f7e006:	vmovdqu8 %xmm0,%xmm20{%k1}
 1f7e00c:	vpcmpeqb %xmm15,%xmm10,%k1{%k6}
 1f7e012:	vpternlogq $0xf8,%xmm16,%xmm24,%xmm20
 1f7e019:	kmovd  %k1,%eax
 1f7e01d:	kmovw  %k1,0x120(%rsp)
 1f7e026:	korw   %k0,%k1,%k1
 1f7e02a:	kmovw  %k1,0x1a0(%rsp)
 1f7e033:	test   %ax,%ax
 1f7e036:	je     1f7e1f1 <node_facts_window_run+0xde1>
 1f7e03c:	vmovdqu64 %zmm4,0x660(%rsp)
 1f7e047:	vmovdqu %ymm5,0x5f0(%rsp)
 1f7e050:	vmovdqu64 %zmm7,0x530(%rsp)
 1f7e05b:	vmovdqa64 %xmm24,0x570(%rsp)
 1f7e063:	vmovdqu64 %zmm23,0x5b0(%rsp)
 1f7e06e:	vmovdqu64 %zmm22,0x450(%rsp)
 1f7e079:	vmovdqu64 %zmm19,0x2d0(%rsp)
 1f7e084:	vmovdqu64 %zmm13,0x490(%rsp)
 1f7e08f:	vmovdqu64 %zmm21,0x3d0(%rsp)
 1f7e09a:	vmovdqu64 %zmm12,0x4d0(%rsp)
 1f7e0a5:	vmovdqa64 %xmm20,0x220(%rsp)
 1f7e0ad:	kmovw  %k7,0x350(%rsp)
 1f7e0b6:	mov    %rbp,0x310(%rsp)
 1f7e0be:	kmovd  %k6,0x390(%rsp)
 1f7e0c8:	movzwl %ax,%r14d
 1f7e0cc:	movzwl %r13w,%r13d
 1f7e0d0:	xor    %ebp,%ebp
 1f7e0d2:	mov    0x80(%rsp),%rax
 1f7e0da:	lea    (%rax,%rbx,4),%r15
 1f7e0de:	xchg   %ax,%ax
 1f7e0e0:	xor    %r12d,%r12d
 1f7e0e3:	tzcnt  %r14d,%r12d
 1f7e0e8:	xor    %edx,%edx
 1f7e0ea:	mov    (%r15,%r12,4),%esi
 1f7e0ee:	vzeroupper
 1f7e0f1:	call   1f93960 <node_tests_window_line>
 1f7e0f6:	mov    0x10(%rsp),%rdi
 1f7e0fb:	mov    $0x1,%ecx
 1f7e100:	test   $0x2,%al
 1f7e102:	shlx   %r12d,%ecx,%eax
 1f7e107:	cmove  %ebp,%eax
 1f7e10a:	or     %eax,%r13d
 1f7e10d:	blsr   %r14d,%r14d
 1f7e112:	jne    1f7e0e0 <node_facts_window_run+0xcd0>
 1f7e114:	vpbroadcastd -0x19ad1a2(%rip),%zmm14        # 5d0f7c <.LCPI3_5>
 1f7e11e:	vpbroadcastb -0x1ac73e7(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e127:	vpbroadcastb -0x1ac73f0(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e131:	vpbroadcastd -0x19ad1b7(%rip),%zmm17        # 5d0f84 <.LCPI3_11>
 1f7e13b:	vpbroadcastd -0x19ad1b9(%rip),%zmm18        # 5d0f8c <.LCPI3_13>
 1f7e145:	vmovdqa64 0x220(%rsp),%xmm20
 1f7e14d:	vmovdqu64 0x4d0(%rsp),%zmm12
 1f7e158:	vmovdqu64 0x3d0(%rsp),%zmm21
 1f7e163:	vmovdqu64 0x490(%rsp),%zmm13
 1f7e16e:	vmovdqu64 0x2d0(%rsp),%zmm19
 1f7e179:	vmovdqu64 0x450(%rsp),%zmm22
 1f7e184:	vmovdqu64 0x5b0(%rsp),%zmm23
 1f7e18f:	vmovdqa64 0x570(%rsp),%xmm24
 1f7e197:	vmovdqu64 0x530(%rsp),%zmm7
 1f7e1a2:	vmovdqu 0x5f0(%rsp),%ymm5
 1f7e1ab:	vmovdqu64 0x660(%rsp),%zmm4
 1f7e1b6:	mov    (%rsp),%r11
 1f7e1ba:	mov    0x40(%rsp),%r9
 1f7e1bf:	mov    0x30(%rsp),%r12
 1f7e1c4:	mov    0x18(%rsp),%rsi
 1f7e1c9:	mov    0x20(%rsp),%r8
 1f7e1ce:	mov    0x90(%rsp),%r15
 1f7e1d6:	kmovd  0x390(%rsp),%k6
 1f7e1e0:	mov    0x310(%rsp),%rbp
 1f7e1e8:	kmovw  0x350(%rsp),%k7
 1f7e1f1:	vpsrld $0x2,%zmm21,%zmm0
 1f7e1f8:	vpandd -0x19ad272(%rip){1to16},%zmm0,%zmm2        # 5d0f90 <.LCPI3_14>
 1f7e202:	vpbroadcastd -0x19ad278(%rip),%zmm0        # 5d0f94 <.LCPI3_15>
 1f7e20c:	vptestmd -0x19ad27e(%rip){1to16},%zmm21,%k3        # 5d0f98 <.LCPI3_16>
 1f7e216:	vmovdqu64 0x290(%rsp),%zmm1
 1f7e221:	vptestnmd %zmm4,%zmm4,%k1
 1f7e227:	vpbroadcastd -0x19ad28d(%rip),%zmm6        # 5d0fa4 <.LCPI3_21>
 1f7e231:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7e238:	kmovd  %r13d,%k4
 1f7e23d:	vpsrld $0x10,%zmm21,%zmm10
 1f7e244:	vpbroadcastb -0x1ac750b(%rip),%xmm8        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7e24d:	vpbroadcastb -0x1ac7513(%rip),%xmm9        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7e256:	kmovw  %k1,%eax
 1f7e25a:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7e260:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7e267:	vmovdqu64 0x1e0(%rsp),%zmm0
 1f7e272:	korw   %k1,%k3,%k3
 1f7e276:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7e27d:	vpandd -0x19ad2bf(%rip){1to16},%zmm19,%zmm5        # 5d0fc8 <.LCPI3_81>
 1f7e287:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7e28d:	vpbroadcastb -0x1ac7552(%rip),%xmm7        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7e296:	vinserti64x4 $0x1,0x160(%rsp),%zmm0,%zmm0
 1f7e29f:	kmovw  %k0,%ecx
 1f7e2a3:	korw   %k2,%k3,%k2
 1f7e2a7:	vpaddd -0x19ad311(%rip){1to16},%zmm5,%zmm5        # 5d0fa0 <.LCPI3_20>
 1f7e2b1:	andn   %ecx,%eax,%eax
 1f7e2b6:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7e2bc:	kmovd  %eax,%k3
 1f7e2c0:	shr    $0x8,%eax
 1f7e2c3:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7e2c9:	kmovd  %eax,%k3
 1f7e2cd:	vmovdqu8 %xmm15,%xmm4{%k2}{z}
 1f7e2d3:	vpcmpltud %zmm6,%zmm5,%k2
 1f7e2da:	vpslld $0x1f,%zmm5,%zmm5
 1f7e2e1:	vpxor  %xmm6,%xmm6,%xmm6
 1f7e2e5:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7e2eb:	vptestmd -0x19ad359(%rip){1to16},%zmm23,%k3        # 5d0f9c <.LCPI3_17>
 1f7e2f5:	vpandd %zmm18,%zmm23,%zmm3
 1f7e2fb:	vptestnmd %zmm3,%zmm3,%k0
 1f7e301:	kandd  %k6,%k0,%k0
 1f7e306:	korw   %k3,%k4,%k3
 1f7e30a:	kandd  %k2,%k0,%k4
 1f7e30f:	vpcmpeqd %zmm17,%zmm2,%k2{%k4}
 1f7e315:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7e31b:	vmovdqu8 -0x19b65e5(%rip),%xmm2{%k4}        # 5c7d40 <.LCPI3_25>
 1f7e325:	knotw  %k2,%k0
 1f7e329:	kandd  %k0,%k4,%k5
 1f7e32e:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7e334:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7e33b:	vpaddd %zmm5,%zmm10,%zmm11
 1f7e341:	vpbroadcastb -0x1ac7605(%rip),%xmm5        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7e34a:	vmovdqu8 -0x19b6604(%rip),%xmm2{%k4}        # 5c7d50 <.LCPI3_26>
 1f7e354:	vptestnmd %zmm11,%zmm11,%k4
 1f7e35a:	vpblendmb -0x19b65f4(%rip),%xmm5,%xmm5{%k4}        # 5c7d70 <.LCPI3_28>
 1f7e364:	vpcmpnleud -0x19ad3c7(%rip){1to16},%zmm11,%k4        # 5d0fa8 <.LCPI3_22>
 1f7e36f:	cmpb   $0x0,0xa10(%rdi)
 1f7e376:	vmovdqu8 -0x19b6600(%rip),%xmm5{%k4}        # 5c7d80 <.LCPI3_29>
 1f7e380:	vpcmpnleud -0x19ad3df(%rip){1to16},%zmm11,%k4        # 5d0fac <.LCPI3_23>
 1f7e38b:	vmovdqu8 -0x19b6605(%rip),%xmm5{%k4}        # 5c7d90 <.LCPI3_30>
 1f7e395:	vptestmd %zmm3,%zmm3,%k4
 1f7e39b:	vpor   %xmm4,%xmm8,%xmm3
 1f7e39f:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7e3a5:	kmovw  0x1a0(%rsp),%k4
 1f7e3ae:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7e3b4:	vpor   %xmm2,%xmm4,%xmm2
 1f7e3b8:	vpord  -0x19ad3f6(%rip){1to4},%xmm2,%xmm3        # 5d0fcc <.LCPI3_84>
 1f7e3c2:	vpbroadcastb -0x1ac7685(%rip),%xmm5        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7e3cb:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7e3d1:	vpor   %xmm5,%xmm2,%xmm3
 1f7e3d5:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7e3db:	vpmovdb %zmm21,%xmm3
 1f7e3e1:	kmovw  0x120(%rsp),%k3
 1f7e3ea:	vpor   %xmm3,%xmm9,%xmm4
 1f7e3ee:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7e3f4:	vptestmd -0x19ad44e(%rip){1to16},%zmm12,%k3{%k7}        # 5d0fb0 <.LCPI3_32>
 1f7e3fe:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7e404:	vpor   %xmm5,%xmm4,%xmm6
 1f7e408:	vpsrld $0xb,%zmm23,%zmm7
 1f7e40f:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7e415:	vpandd -0x19ad44f(%rip){1to4},%xmm24,%xmm4        # 5d0fd0 <.LCPI3_86>
 1f7e41f:	vptestmd -0x19ad475(%rip){1to16},%zmm23,%k1        # 5d0fb4 <.LCPI3_33>
 1f7e429:	vpmovdb %zmm7,%xmm7
 1f7e42f:	vpand  %xmm7,%xmm8,%xmm7
 1f7e433:	vporq  %xmm16,%xmm4,%xmm5
 1f7e439:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7e43f:	vpmovdb %zmm23,%xmm5
 1f7e445:	vgf2p8affineqb $0x0,-0x19afeb0(%rip){1to2},%xmm5,%xmm5        # 5ce5a0 <.LCPI3_87>
 1f7e450:	vpternlogq $0xf8,%xmm9,%xmm5,%xmm4
 1f7e457:	vpmovdb %zmm19,%xmm9
 1f7e45d:	vpor   %xmm4,%xmm15,%xmm5
 1f7e461:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7e467:	vinserti32x4 $0x3,%xmm13,%zmm22,%zmm5{%k6}{z}
 1f7e46e:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7e475:	vpsrld $0x8,%zmm19,%zmm13
 1f7e47c:	vpsrld $0x10,%zmm19,%zmm6
 1f7e483:	vpmovdb %zmm6,%xmm7
 1f7e489:	vpmovdb %zmm13,%xmm8
 1f7e48f:	vpmovdb %zmm12,%xmm6
 1f7e495:	je     1f7e58a <node_facts_window_run+0x117a>
 1f7e49b:	vmovdqa64 -0x1ac7ca5(%rip),%zmm19        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7e4a5:	vptestmd %zmm10,%zmm10,%k1{%k2}
 1f7e4ab:	add    %r8,%rbp
 1f7e4ae:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e4b3:	vpxor  %xmm13,%xmm13,%xmm13
 1f7e4b8:	vpcmpneqd -0x19ad50b(%rip){1to16},%zmm10,%k0{%k1}        # 5d0fb8 <.LCPI3_38>
 1f7e4c3:	vmovdqa %xmm7,%xmm10
 1f7e4c7:	vpternlogq $0xfe,%xmm9,%xmm3,%xmm10
 1f7e4ce:	kmovq  %k1,%k2
 1f7e4d3:	kmovw  %k1,%eax
 1f7e4d7:	popcnt %eax,%ecx
 1f7e4db:	vpgatherdd 0x10(%rbp,%zmm19,1),%zmm12{%k2}
 1f7e4e3:	kmovq  %k1,%k2
 1f7e4e8:	vpcmpnleud -0x19ad537(%rip){1to16},%zmm12,%k3        # 5d0fbc <.LCPI3_39>
 1f7e4f3:	vpgatherdd 0x14(%rbp,%zmm19,1),%zmm13{%k2}
 1f7e4fb:	add    %rcx,0x38(%rsp)
 1f7e500:	mov    0x8(%rsp),%r10
 1f7e505:	vpcmpeqd %zmm11,%zmm12,%k2
 1f7e50b:	vmovdqa64 %xmm20,%xmm11
 1f7e511:	vpternlogq $0xfe,%xmm8,%xmm10,%xmm11
 1f7e518:	vptestnmd %zmm13,%zmm13,%k2{%k2}
 1f7e51e:	vptestmd %zmm13,%zmm13,%k4
 1f7e524:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm11
 1f7e52b:	korw   %k4,%k3,%k3
 1f7e52f:	kandw  %k2,%k0,%k2
 1f7e533:	knotw  %k0,%k0
 1f7e537:	kandd  %k1,%k0,%k0
 1f7e53c:	kandw  %k0,%k3,%k0
 1f7e540:	korw   %k0,%k2,%k2
 1f7e544:	vptestnmd %zmm14,%zmm21,%k0{%k2}
 1f7e54a:	kandw  %k0,%k1,%k0
 1f7e54e:	knotd  %k6,%k1
 1f7e553:	kmovd  %k0,%ecx
 1f7e557:	vptestmb %xmm11,%xmm11,%k0{%k1}
 1f7e55d:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7e563:	andn   %eax,%ecx,%eax
 1f7e568:	popcnt %eax,%eax
 1f7e56c:	kmovw  %k0,%ecx
 1f7e570:	popcnt %ecx,%ecx
 1f7e574:	kmovw  %k1,%edx
 1f7e578:	popcnt %edx,%edx
 1f7e57c:	add    %rdx,%r10
 1f7e57f:	add    %rax,%r10
 1f7e582:	add    %rcx,%r10
 1f7e585:	mov    %r10,0x8(%rsp)
 1f7e58a:	mov    0x28(%rsp),%rbp
 1f7e58f:	jmp    1f7dcac <node_facts_window_run+0x89c>
 1f7e594:	kandw  %k0,%k7,%k0
 1f7e598:	vmovdqa %xmm10,0x290(%rsp)
 1f7e5a1:	vmovdqu64 %zmm11,0x310(%rsp)
 1f7e5ac:	vmovdqu64 %ymm19,0x220(%rsp)
 1f7e5b4:	vmovdqu64 %zmm20,0x4d0(%rsp)
 1f7e5bf:	vmovdqu64 %ymm21,0x3d0(%rsp)
 1f7e5ca:	vmovdqu64 %zmm7,0x490(%rsp)
 1f7e5d5:	vmovdqu %ymm13,0x2d0(%rsp)
 1f7e5de:	vmovdqu64 %zmm22,0x450(%rsp)
 1f7e5e9:	vmovdqu64 %ymm23,0x5b0(%rsp)
 1f7e5f4:	vmovdqu64 %zmm5,0x570(%rsp)
 1f7e5ff:	vmovdqu %ymm6,0x530(%rsp)
 1f7e608:	vmovdqu64 %zmm24,0x5f0(%rsp)
 1f7e613:	vmovdqu64 %ymm25,0x660(%rsp)
 1f7e61b:	vmovdqu64 %zmm4,0x720(%rsp)
 1f7e626:	vmovdqu64 %ymm26,0x430(%rsp)
 1f7e631:	vmovdqu64 %zmm27,0x6e0(%rsp)
 1f7e63c:	vmovdqu64 %ymm28,0x410(%rsp)
 1f7e647:	vmovdqu64 %zmm0,0x7c0(%rsp)
 1f7e64f:	kmovd  %k6,0x390(%rsp)
 1f7e659:	kmovw  %k7,0x350(%rsp)
 1f7e662:	kmovd  %k0,%eax
 1f7e666:	movzwl %ax,%eax
 1f7e669:	jmp    1f7e816 <node_facts_window_run+0x1406>
 1f7e66e:	mov    0x48(%rsp),%rsi
 1f7e673:	mov    (%r12,%r13,4),%r9d
 1f7e677:	mov    0x9c8(%rdi),%rdx
 1f7e67e:	shl    $0x6,%rax
 1f7e682:	mov    %r8b,0x160(%rsp)
 1f7e68a:	mov    0x20(%r11),%rcx
 1f7e68e:	cmpb   $0x1,(%rdx,%r9,1)
 1f7e693:	mov    %r9,0x1e0(%rsp)
 1f7e69b:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7e6a0:	adc    $0x0,%rsi
 1f7e6a4:	and    $0x1,%edx
 1f7e6a7:	mov    %rsi,0x48(%rsp)
 1f7e6ac:	mov    0x80(%rsp),%r14
 1f7e6b4:	mov    (%r14,%r13,4),%esi
 1f7e6b8:	vzeroupper
 1f7e6bb:	call   1f93960 <node_tests_window_line>
 1f7e6c0:	mov    %al,0x1a0(%rsp)
 1f7e6c7:	mov    (%r14,%r13,4),%esi
 1f7e6cb:	mov    0x10(%rsp),%rdi
 1f7e6d0:	call   1f93ab0 <node_tests_window_returns>
 1f7e6d5:	mov    0x10(%rsp),%rdi
 1f7e6da:	or     0x160(%rsp),%al
 1f7e6e1:	mov    0x1e0(%rsp),%rdx
 1f7e6e9:	vpbroadcastd -0x19ad777(%rip),%zmm14        # 5d0f7c <.LCPI3_5>
 1f7e6f3:	vpbroadcastb -0x1ac79bc(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e6fc:	vpbroadcastb -0x1ac79c5(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e706:	vpbroadcastd -0x19ad78c(%rip),%zmm17        # 5d0f84 <.LCPI3_11>
 1f7e710:	vpbroadcastd -0x19ad78e(%rip),%zmm18        # 5d0f8c <.LCPI3_13>
 1f7e71a:	vmovdqa 0x290(%rsp),%xmm10
 1f7e723:	vmovdqu64 0x310(%rsp),%zmm11
 1f7e72e:	vmovdqu64 0x220(%rsp),%ymm19
 1f7e736:	vmovdqu64 0x4d0(%rsp),%zmm20
 1f7e741:	vmovdqu64 0x3d0(%rsp),%ymm21
 1f7e74c:	vmovdqu64 0x490(%rsp),%zmm7
 1f7e757:	vmovdqu 0x2d0(%rsp),%ymm13
 1f7e760:	vmovdqu64 0x450(%rsp),%zmm22
 1f7e76b:	vmovdqu64 0x5b0(%rsp),%ymm23
 1f7e776:	vmovdqu64 0x570(%rsp),%zmm5
 1f7e781:	vmovdqu 0x530(%rsp),%ymm6
 1f7e78a:	vmovdqu64 0x5f0(%rsp),%zmm24
 1f7e795:	vmovdqu64 0x660(%rsp),%ymm25
 1f7e79d:	vmovdqu64 0x720(%rsp),%zmm4
 1f7e7a8:	vmovdqu64 0x430(%rsp),%ymm26
 1f7e7b3:	vmovdqu64 0x6e0(%rsp),%zmm27
 1f7e7be:	vmovdqu64 0x410(%rsp),%ymm28
 1f7e7c9:	vmovdqu64 0x7c0(%rsp),%zmm0
 1f7e7d1:	mov    (%rsp),%r11
 1f7e7d5:	mov    0x40(%rsp),%r9
 1f7e7da:	mov    0x18(%rsp),%rsi
 1f7e7df:	mov    0x20(%rsp),%r8
 1f7e7e4:	kmovd  0x390(%rsp),%k6
 1f7e7ee:	kmovw  0x350(%rsp),%k7
 1f7e7f7:	or     0x1a0(%rsp),%al
 1f7e7fe:	mov    0x9c8(%rdi),%rcx
 1f7e805:	mov    %al,(%rcx,%rdx,1)
 1f7e808:	mov    0x120(%rsp),%eax
 1f7e80f:	blsr   %eax,%eax
 1f7e814:	je     1f7e883 <node_facts_window_run+0x1473>
 1f7e816:	tzcnt  %eax,%r13d
 1f7e81b:	mov    %eax,0x120(%rsp)
 1f7e822:	mov    0x60(%r11),%edx
 1f7e826:	add    %rbx,%r13
 1f7e829:	mov    %r13,%rcx
 1f7e82c:	shl    $0x6,%rcx
 1f7e830:	mov    (%r8,%rcx,1),%eax
 1f7e834:	mov    0xc(%r8,%rcx,1),%ecx
 1f7e839:	mov    $0x1,%r8b
 1f7e83c:	shr    $0x3,%eax
 1f7e83f:	cmp    %edx,%eax
 1f7e841:	cmovae %edx,%eax
 1f7e844:	test   %rcx,%rcx
 1f7e847:	je     1f7e66e <node_facts_window_run+0x125e>
 1f7e84d:	mov    0x78(%rsp),%rdx
 1f7e852:	mov    0x48(%rsp),%rsi
 1f7e857:	cmp    0x3b8(%rdx),%ecx
 1f7e85d:	jae    1f7e673 <node_facts_window_run+0x1263>
 1f7e863:	mov    0x78(%rsp),%rdx
 1f7e868:	mov    0x3a8(%rdx),%rdx
 1f7e86f:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7e873:	setne  %r8b
 1f7e877:	shl    $0x5,%r8b
 1f7e87b:	inc    %r8b
 1f7e87e:	jmp    1f7e673 <node_facts_window_run+0x1263>
 1f7e883:	mov    0x9c8(%rdi),%rax
 1f7e88a:	kmovq  %k7,%k1
 1f7e88f:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e894:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7e89b:	jmp    1f7de5d <node_facts_window_run+0xa4d>
 1f7e8a0:	cmpq   $0x0,0xb40(%r11)
 1f7e8a8:	je     1f7ff9a <node_facts_window_run+0x2b8a>
 1f7e8ae:	test   %eax,%eax
 1f7e8b0:	je     1f807f5 <node_facts_window_run+0x33e5>
 1f7e8b6:	vpbroadcastd -0x19ad944(%rip),%zmm10        # 5d0f7c <.LCPI3_5>
 1f7e8c0:	vpbroadcastb -0x1ac7b89(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e8c9:	vpbroadcastb -0x1ac7b91(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e8d2:	vpbroadcastd -0x19ad958(%rip),%zmm13        # 5d0f84 <.LCPI3_11>
 1f7e8dc:	vpbroadcastd -0x19ad95a(%rip),%zmm14        # 5d0f8c <.LCPI3_13>
 1f7e8e6:	mov    (%r11),%rcx
 1f7e8e9:	lea    0x69454(%rbp),%r10
 1f7e8f0:	lea    0x422c(%rbp),%rdx
 1f7e8f7:	mov    %eax,%r15d
 1f7e8fa:	xor    %r14d,%r14d
 1f7e8fd:	mov    %rcx,0x5f0(%rsp)
 1f7e905:	mov    %r10,0x5b0(%rsp)
 1f7e90d:	mov    %rdx,0x570(%rsp)
 1f7e915:	movq   $0x0,0x48(%rsp)
 1f7e91e:	movq   $0x0,0x38(%rsp)
 1f7e927:	movq   $0x0,0x8(%rsp)
 1f7e930:	mov    %r15,0x530(%rsp)
 1f7e938:	jmp    1f7e9c3 <node_facts_window_run+0x15b3>
 1f7e93d:	nopl   (%rax)
 1f7e940:	vpxor  %xmm1,%xmm1,%xmm1
 1f7e944:	vpxor  %xmm3,%xmm3,%xmm3
 1f7e948:	vpxor  %xmm4,%xmm4,%xmm4
 1f7e94c:	vpxor  %xmm5,%xmm5,%xmm5
 1f7e950:	vpxor  %xmm0,%xmm0,%xmm0
 1f7e954:	vpxord %xmm16,%xmm16,%xmm16
 1f7e95a:	mov    0x990(%rdi),%rax
 1f7e961:	vmovdqu64 %xmm16,(%rax,%r14,1)
 1f7e968:	mov    0x998(%rdi),%rax
 1f7e96f:	vmovdqu %xmm0,(%rax,%r14,1)
 1f7e975:	mov    0xb88(%r11),%rax
 1f7e97c:	vmovdqu %xmm5,(%rax,%r14,1)
 1f7e982:	mov    0xb90(%r11),%rax
 1f7e989:	vmovdqu %xmm4,(%rax,%r14,1)
 1f7e98f:	mov    0xb98(%r11),%rax
 1f7e996:	vmovdqu %xmm3,(%rax,%r14,1)
 1f7e99c:	mov    0xba0(%r11),%rax
 1f7e9a3:	vmovdqu %xmm1,(%rax,%r14,1)
 1f7e9a9:	mov    0xba8(%r11),%rax
 1f7e9b0:	vmovdqu %xmm2,(%rax,%r14,1)
 1f7e9b6:	add    $0x10,%r14
 1f7e9ba:	cmp    %r15,%r14
 1f7e9bd:	jae    1f80810 <node_facts_window_run+0x3400>
 1f7e9c3:	vpxor  %xmm2,%xmm2,%xmm2
 1f7e9c7:	cmp    %rsi,%r14
 1f7e9ca:	jae    1f7e940 <node_facts_window_run+0x1530>
 1f7e9d0:	mov    %esi,%eax
 1f7e9d2:	sub    %r14d,%eax
 1f7e9d5:	mov    $0x10,%ecx
 1f7e9da:	mov    $0xffffffff,%edx
 1f7e9df:	mov    %r14,%rbp
 1f7e9e2:	vpxord %xmm18,%xmm18,%xmm18
 1f7e9e8:	cmp    $0x10,%eax
 1f7e9eb:	cmovae %ecx,%eax
 1f7e9ee:	mov    0x9b8(%r11),%rcx
 1f7e9f5:	shl    $0x6,%rbp
 1f7e9f9:	shlx   %eax,%edx,%eax
 1f7e9fe:	vmovdqu (%r8,%rbp,1),%ymm0
 1f7ea04:	vmovdqu 0x180(%r8,%rbp,1),%ymm3
 1f7ea0e:	vmovdqu 0x80(%r8,%rbp,1),%ymm1
 1f7ea18:	vmovdqu 0x100(%r8,%rbp,1),%ymm2
 1f7ea22:	not    %eax
 1f7ea24:	vinserti64x4 $0x1,0x40(%r8,%rbp,1),%zmm0,%zmm6
 1f7ea2d:	vmovdqu 0x200(%r8,%rbp,1),%ymm0
 1f7ea37:	vinserti64x4 $0x1,0x1c0(%r8,%rbp,1),%zmm3,%zmm7
 1f7ea40:	vinserti64x4 $0x1,0xc0(%r8,%rbp,1),%zmm1,%zmm1
 1f7ea49:	vinserti64x4 $0x1,0x140(%r8,%rbp,1),%zmm2,%zmm2
 1f7ea52:	kmovd  %eax,%k1
 1f7ea56:	vinserti64x4 $0x1,0x240(%r8,%rbp,1),%zmm0,%zmm3
 1f7ea5f:	vmovdqu 0x280(%r8,%rbp,1),%ymm0
 1f7ea69:	mov    0x9c8(%rdi),%rax
 1f7ea70:	vinserti64x4 $0x1,0x2c0(%r8,%rbp,1),%zmm0,%zmm9
 1f7ea79:	vmovdqu 0x300(%r8,%rbp,1),%ymm0
 1f7ea83:	vmovdqu8 (%rcx,%r14,1),%xmm4{%k1}{z}
 1f7ea8a:	mov    0x5b0(%rsp),%rcx
 1f7ea92:	vinserti64x4 $0x1,0x340(%r8,%rbp,1),%zmm0,%zmm8
 1f7ea9b:	vmovdqu 0x380(%r8,%rbp,1),%ymm0
 1f7eaa5:	vinserti64x4 $0x1,0x3c0(%r8,%rbp,1),%zmm0,%zmm15
 1f7eaae:	vmovdqu8 (%rcx,%r14,1),%xmm5{%k1}{z}
 1f7eab5:	vptestmb %xmm4,%xmm4,%k6
 1f7eabb:	vpcmpeqb -0x19b6db5(%rip),%xmm5,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7eac5:	vmovdqu32 (%r12,%r14,4),%zmm0{%k7}{z}
 1f7eacc:	kmovq  %k7,%k1
 1f7ead1:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7ead8:	vptestnmd %zmm13,%zmm18,%k0
 1f7eade:	ktestw %k0,%k7
 1f7eae2:	jne    1f7f0aa <node_facts_window_run+0x1c9a>
 1f7eae8:	vmovdqa64 -0x1ac83b2(%rip),%zmm0        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7eaf2:	vptestmd -0x19adb74(%rip){1to16},%zmm18,%k0        # 5d0f88 <.LCPI3_12>
 1f7eafc:	kmovd  %k6,%edx
 1f7eb00:	vpermt2d %zmm1,%zmm0,%zmm6
 1f7eb06:	vpermt2d %zmm7,%zmm0,%zmm2
 1f7eb0c:	vpermt2d %zmm9,%zmm0,%zmm3
 1f7eb12:	vpermt2d %zmm15,%zmm0,%zmm8
 1f7eb18:	kmovd  %k0,%r13d
 1f7eb1c:	vptestmd %zmm14,%zmm18,%k0
 1f7eb22:	vshufi64x2 $0x44,%zmm2,%zmm6,%zmm0
 1f7eb29:	vshufi64x2 $0x44,%zmm8,%zmm3,%zmm1
 1f7eb30:	vshufi64x2 $0xee,%zmm2,%zmm6,%zmm2
 1f7eb37:	vshufi64x2 $0xee,%zmm8,%zmm3,%zmm3
 1f7eb3e:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm15{%k6}{z}
 1f7eb45:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7eb4c:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm17{%k6}{z}
 1f7eb53:	vshufi64x2 $0x88,%zmm3,%zmm2,%zmm7
 1f7eb5a:	vpsrld $0x19,%zmm15,%zmm0
 1f7eb61:	vpandd -0x19adbf3(%rip){1to16},%zmm0,%zmm0        # 5d0f78 <.LCPI3_4>
 1f7eb6b:	vpsrld $0x18,%zmm15,%zmm1
 1f7eb72:	vpsrld $0x1a,%zmm15,%zmm6
 1f7eb79:	vpternlogd $0xec,%zmm10,%zmm0,%zmm1
 1f7eb80:	vpandd -0x19adbc6(%rip){1to16},%zmm15,%zmm0        # 5d0fc4 <.LCPI3_78>
 1f7eb8a:	vpmovdb %zmm1,%xmm16
 1f7eb90:	vpsrld $0xc,%zmm17,%zmm1
 1f7eb97:	vpmovdb %zmm1,%xmm20
 1f7eb9d:	vpcmpeqd -0x19adc27(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f80 <.LCPI3_7>
 1f7eba7:	vporq  %xmm11,%xmm16,%xmm0
 1f7ebad:	vmovdqu8 %xmm0,%xmm16{%k1}
 1f7ebb3:	vpcmpeqb %xmm11,%xmm5,%k1{%k6}
 1f7ebb9:	vpternlogq $0xf8,%xmm12,%xmm20,%xmm16
 1f7ebc0:	kmovd  %k1,%eax
 1f7ebc4:	kmovw  %k1,0x120(%rsp)
 1f7ebcd:	korw   %k0,%k1,%k1
 1f7ebd1:	kmovw  %k1,0x1e0(%rsp)
 1f7ebda:	test   %ax,%ax
 1f7ebdd:	je     1f7ed6a <node_facts_window_run+0x195a>
 1f7ebe3:	vmovdqu64 %zmm7,0x450(%rsp)
 1f7ebee:	vmovdqu64 %zmm6,0x2d0(%rsp)
 1f7ebf9:	vmovdqa64 %xmm20,0x490(%rsp)
 1f7ec01:	vmovdqu64 %zmm19,0x3d0(%rsp)
 1f7ec0c:	vmovdqu64 %zmm18,0x4d0(%rsp)
 1f7ec17:	vmovdqu64 %zmm15,0x220(%rsp)
 1f7ec22:	vmovdqa %xmm4,0x290(%rsp)
 1f7ec2b:	vmovdqu64 %zmm17,0x310(%rsp)
 1f7ec36:	mov    %edx,0x350(%rsp)
 1f7ec3d:	vmovdqa64 %xmm16,0x390(%rsp)
 1f7ec45:	kmovw  %k7,0x160(%rsp)
 1f7ec4e:	kmovw  %k6,0x1a0(%rsp)
 1f7ec57:	movzwl %ax,%ebx
 1f7ec5a:	movzwl %r13w,%r13d
 1f7ec5e:	mov    0x570(%rsp),%rax
 1f7ec66:	lea    (%rax,%r14,4),%r15
 1f7ec6a:	nopw   0x0(%rax,%rax,1)
 1f7ec70:	xor    %r12d,%r12d
 1f7ec73:	tzcnt  %ebx,%r12d
 1f7ec78:	xor    %edx,%edx
 1f7ec7a:	mov    (%r15,%r12,4),%esi
 1f7ec7e:	vzeroupper
 1f7ec81:	call   1f93960 <node_tests_window_line>
 1f7ec86:	mov    0x10(%rsp),%rdi
 1f7ec8b:	mov    $0x1,%edx
 1f7ec90:	xor    %ecx,%ecx
 1f7ec92:	test   $0x2,%al
 1f7ec94:	shlx   %r12d,%edx,%eax
 1f7ec99:	cmove  %ecx,%eax
 1f7ec9c:	or     %eax,%r13d
 1f7ec9f:	blsr   %ebx,%ebx
 1f7eca4:	jne    1f7ec70 <node_facts_window_run+0x1860>
 1f7eca6:	vpbroadcastd -0x19add34(%rip),%zmm10        # 5d0f7c <.LCPI3_5>
 1f7ecb0:	vpbroadcastb -0x1ac7f79(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7ecb9:	vpbroadcastb -0x1ac7f81(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7ecc2:	vpbroadcastd -0x19add48(%rip),%zmm13        # 5d0f84 <.LCPI3_11>
 1f7eccc:	vpbroadcastd -0x19add4a(%rip),%zmm14        # 5d0f8c <.LCPI3_13>
 1f7ecd6:	vmovdqa64 0x390(%rsp),%xmm16
 1f7ecde:	vmovdqu64 0x310(%rsp),%zmm17
 1f7ece9:	vmovdqa 0x290(%rsp),%xmm4
 1f7ecf2:	vmovdqu64 0x220(%rsp),%zmm15
 1f7ecfd:	vmovdqu64 0x4d0(%rsp),%zmm18
 1f7ed08:	vmovdqu64 0x3d0(%rsp),%zmm19
 1f7ed13:	vmovdqa64 0x490(%rsp),%xmm20
 1f7ed1b:	vmovdqu64 0x2d0(%rsp),%zmm6
 1f7ed26:	vmovdqu64 0x450(%rsp),%zmm7
 1f7ed31:	mov    (%rsp),%r11
 1f7ed35:	mov    0x40(%rsp),%r9
 1f7ed3a:	mov    0x30(%rsp),%r12
 1f7ed3f:	mov    0x18(%rsp),%rsi
 1f7ed44:	mov    0x20(%rsp),%r8
 1f7ed49:	mov    0x530(%rsp),%r15
 1f7ed51:	kmovw  0x1a0(%rsp),%k6
 1f7ed5a:	kmovw  0x160(%rsp),%k7
 1f7ed63:	mov    0x350(%rsp),%edx
 1f7ed6a:	vpsrld $0x2,%zmm17,%zmm0
 1f7ed71:	vpandd -0x19addeb(%rip){1to16},%zmm0,%zmm0        # 5d0f90 <.LCPI3_14>
 1f7ed7b:	vptestmd -0x19added(%rip){1to16},%zmm17,%k2        # 5d0f98 <.LCPI3_16>
 1f7ed85:	vpandd -0x19addc7(%rip){1to16},%zmm15,%zmm3        # 5d0fc8 <.LCPI3_81>
 1f7ed8f:	vptestnmb %xmm4,%xmm4,%k0
 1f7ed95:	vpbroadcastd -0x19addfb(%rip),%zmm4        # 5d0fa4 <.LCPI3_21>
 1f7ed9f:	vptestmd -0x19ade0d(%rip){1to16},%zmm19,%k3        # 5d0f9c <.LCPI3_17>
 1f7eda9:	vpandd %zmm14,%zmm19,%zmm1
 1f7edaf:	vpbroadcastb -0x1ac8074(%rip),%xmm8        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7edb8:	vpbroadcastb -0x1ac807f(%rip),%xmm5        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7edc1:	vpbroadcastb -0x1ac8087(%rip),%xmm9        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7edca:	vpcmpneqd -0x19ade41(%rip){1to16},%zmm0,%k1        # 5d0f94 <.LCPI3_15>
 1f7edd5:	vpaddd -0x19ade3f(%rip){1to16},%zmm3,%zmm3        # 5d0fa0 <.LCPI3_20>
 1f7eddf:	vpcmpeqd %zmm4,%zmm6,%k5{%k6}
 1f7ede5:	vpsrld $0x10,%zmm17,%zmm6
 1f7edec:	korw   %k1,%k2,%k1
 1f7edf0:	vptestnmd %zmm7,%zmm7,%k2
 1f7edf6:	korw   %k2,%k0,%k2
 1f7edfa:	vptestnmd %zmm1,%zmm1,%k0
 1f7ee00:	korw   %k1,%k2,%k1
 1f7ee04:	kmovd  %k0,%eax
 1f7ee08:	vpcmpltud %zmm4,%zmm3,%k0
 1f7ee0f:	vpslld $0x1f,%zmm3,%zmm3
 1f7ee16:	vpxor  %xmm4,%xmm4,%xmm4
 1f7ee1a:	vptestmd %zmm0,%zmm0,%k1{%k1}
 1f7ee20:	kmovd  %k0,%ecx
 1f7ee24:	and    %eax,%ecx
 1f7ee26:	mov    %edx,%eax
 1f7ee28:	and    %ecx,%eax
 1f7ee2a:	kmovd  %eax,%k4
 1f7ee2e:	vmovdqu8 %xmm11,%xmm2{%k1}{z}
 1f7ee34:	kmovd  %r13d,%k1
 1f7ee39:	korw   %k3,%k1,%k3
 1f7ee3d:	vpcmpeqd %zmm13,%zmm0,%k1{%k4}
 1f7ee43:	vmovdqu8 %xmm8,%xmm0{%k5}{z}
 1f7ee49:	vmovdqu8 -0x19b7113(%rip),%xmm0{%k4}        # 5c7d40 <.LCPI3_25>
 1f7ee53:	knotw  %k1,%k0
 1f7ee57:	kmovd  %k0,%ecx
 1f7ee5b:	and    %eax,%ecx
 1f7ee5d:	kmovd  %ecx,%k4
 1f7ee61:	vpcmpgtd %zmm3,%zmm4,%k4{%k4}
 1f7ee67:	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
 1f7ee6e:	vpaddd %zmm3,%zmm6,%zmm7
 1f7ee74:	vpbroadcastb -0x1ac8138(%rip),%xmm3        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7ee7d:	vmovdqu8 -0x19b7137(%rip),%xmm0{%k4}        # 5c7d50 <.LCPI3_26>
 1f7ee87:	vptestnmd %zmm7,%zmm7,%k4
 1f7ee8d:	vpblendmb -0x19b7127(%rip),%xmm3,%xmm3{%k4}        # 5c7d70 <.LCPI3_28>
 1f7ee97:	vpcmpnleud -0x19adefa(%rip){1to16},%zmm7,%k4        # 5d0fa8 <.LCPI3_22>
 1f7eea2:	cmpb   $0x0,0xa10(%rdi)
 1f7eea9:	vmovdqu8 -0x19b7133(%rip),%xmm3{%k4}        # 5c7d80 <.LCPI3_29>
 1f7eeb3:	vpcmpnleud -0x19adf12(%rip){1to16},%zmm7,%k4        # 5d0fac <.LCPI3_23>
 1f7eebe:	vmovdqu8 -0x19b7138(%rip),%xmm3{%k4}        # 5c7d90 <.LCPI3_30>
 1f7eec8:	vptestmd %zmm1,%zmm1,%k4
 1f7eece:	vpor   %xmm5,%xmm2,%xmm1
 1f7eed2:	vmovdqu8 %xmm1,%xmm2{%k4}
 1f7eed8:	kmovw  0x1e0(%rsp),%k4
 1f7eee1:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f7eee7:	vpor   %xmm0,%xmm2,%xmm0
 1f7eeeb:	vpord  -0x19adf29(%rip){1to4},%xmm0,%xmm1        # 5d0fcc <.LCPI3_84>
 1f7eef5:	vpbroadcastb -0x1ac81b8(%rip),%xmm3        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7eefe:	vmovdqu8 %xmm1,%xmm0{%k4}
 1f7ef04:	vpor   %xmm3,%xmm0,%xmm1
 1f7ef08:	vmovdqu8 %xmm1,%xmm0{%k3}
 1f7ef0e:	vpmovdb %zmm17,%xmm1
 1f7ef14:	kmovw  0x120(%rsp),%k3
 1f7ef1d:	vpor   %xmm1,%xmm9,%xmm2
 1f7ef21:	vmovdqu8 %xmm2,%xmm1{%k3}
 1f7ef27:	vptestmd -0x19adf81(%rip){1to16},%zmm18,%k3{%k7}        # 5d0fb0 <.LCPI3_32>
 1f7ef31:	vmovdqu8 %xmm8,%xmm2{%k3}{z}
 1f7ef37:	vpor   %xmm3,%xmm2,%xmm3
 1f7ef3b:	vpsrld $0x8,%zmm15,%zmm8
 1f7ef42:	vmovdqu8 %xmm2,%xmm3{%k2}
 1f7ef48:	vpandd -0x19adf82(%rip){1to4},%xmm20,%xmm2        # 5d0fd0 <.LCPI3_86>
 1f7ef52:	vptestmd -0x19adfa8(%rip){1to16},%zmm19,%k2        # 5d0fb4 <.LCPI3_33>
 1f7ef5c:	vpor   %xmm2,%xmm12,%xmm4
 1f7ef60:	vmovdqu8 %xmm4,%xmm2{%k6}
 1f7ef66:	vpmovdb %zmm19,%xmm4
 1f7ef6c:	vgf2p8affineqb $0x0,-0x19b09d7(%rip){1to2},%xmm4,%xmm4        # 5ce5a0 <.LCPI3_87>
 1f7ef77:	vpternlogq $0xf8,%xmm9,%xmm4,%xmm2
 1f7ef7e:	vpor   %xmm2,%xmm11,%xmm4
 1f7ef82:	vmovdqu8 %xmm4,%xmm2{%k2}
 1f7ef88:	vpsrld $0xb,%zmm19,%zmm4
 1f7ef8f:	vpmovdb %zmm4,%xmm4
 1f7ef95:	vpand  %xmm5,%xmm4,%xmm4
 1f7ef99:	vpmovdb %zmm15,%xmm5
 1f7ef9f:	vpternlogq $0xfe,%xmm4,%xmm3,%xmm2
 1f7efa6:	vpsrld $0x10,%zmm15,%zmm3
 1f7efad:	vpmovdb %zmm8,%xmm4
 1f7efb3:	vpmovdb %zmm3,%xmm3
 1f7efb9:	je     1f7f0a0 <node_facts_window_run+0x1c90>
 1f7efbf:	vmovdqa64 -0x1ac87c9(%rip),%zmm15        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7efc9:	vptestmd %zmm6,%zmm6,%k1{%k1}
 1f7efcf:	add    %r8,%rbp
 1f7efd2:	vpxor  %xmm8,%xmm8,%xmm8
 1f7efd7:	vpxor  %xmm9,%xmm9,%xmm9
 1f7efdc:	vpcmpneqd -0x19ae02f(%rip){1to16},%zmm6,%k0{%k1}        # 5d0fb8 <.LCPI3_38>
 1f7efe7:	vmovdqa %xmm3,%xmm6
 1f7efeb:	vpternlogq $0xfe,%xmm5,%xmm1,%xmm6
 1f7eff2:	kmovq  %k1,%k2
 1f7eff7:	kmovw  %k1,%eax
 1f7effb:	popcnt %eax,%ecx
 1f7efff:	vpgatherdd 0x10(%rbp,%zmm15,1),%zmm8{%k2}
 1f7f007:	kmovq  %k1,%k2
 1f7f00c:	vpcmpnleud -0x19ae05b(%rip){1to16},%zmm8,%k3        # 5d0fbc <.LCPI3_39>
 1f7f017:	vpgatherdd 0x14(%rbp,%zmm15,1),%zmm9{%k2}
 1f7f01f:	add    %rcx,0x38(%rsp)
 1f7f024:	mov    0x8(%rsp),%r10
 1f7f029:	vpcmpeqd %zmm7,%zmm8,%k2
 1f7f02f:	vmovdqa64 %xmm16,%xmm7
 1f7f035:	vpternlogq $0xfe,%xmm4,%xmm6,%xmm7
 1f7f03c:	vptestnmd %zmm9,%zmm9,%k2{%k2}
 1f7f042:	vptestmd %zmm9,%zmm9,%k4
 1f7f048:	vpternlogq $0xfe,%xmm2,%xmm0,%xmm7
 1f7f04f:	korw   %k4,%k3,%k3
 1f7f053:	kandw  %k2,%k0,%k2
 1f7f057:	knotw  %k0,%k0
 1f7f05b:	kandd  %k1,%k0,%k0
 1f7f060:	kandw  %k0,%k3,%k0
 1f7f064:	korw   %k0,%k2,%k2
 1f7f068:	vptestnmd %zmm10,%zmm17,%k0{%k2}
 1f7f06e:	kandw  %k0,%k1,%k0
 1f7f072:	kmovd  %k0,%ecx
 1f7f076:	vptestmb %xmm7,%xmm7,%k0
 1f7f07c:	andn   %eax,%ecx,%eax
 1f7f081:	kmovd  %k0,%ecx
 1f7f085:	andn   %ecx,%edx,%ecx
 1f7f08a:	popcnt %eax,%eax
 1f7f08e:	movzwl %cx,%ecx
 1f7f091:	popcnt %ecx,%ecx
 1f7f095:	add    %rcx,%r10
 1f7f098:	add    %rax,%r10
 1f7f09b:	mov    %r10,0x8(%rsp)
 1f7f0a0:	mov    0x28(%rsp),%rbp
 1f7f0a5:	jmp    1f7e95a <node_facts_window_run+0x154a>
 1f7f0aa:	kandw  %k0,%k7,%k0
 1f7f0ae:	vmovdqa %xmm5,0x1e0(%rsp)
 1f7f0b7:	vmovdqu64 %zmm6,0x390(%rsp)
 1f7f0c2:	vmovdqu64 %zmm2,0x350(%rsp)
 1f7f0cd:	vmovdqu64 %zmm3,0x310(%rsp)
 1f7f0d8:	vmovdqu64 %zmm1,0x220(%rsp)
 1f7f0e3:	vmovdqu64 %zmm7,0x4d0(%rsp)
 1f7f0ee:	vmovdqu64 %zmm8,0x3d0(%rsp)
 1f7f0f9:	vmovdqu64 %zmm9,0x490(%rsp)
 1f7f104:	vmovdqu64 %zmm15,0x2d0(%rsp)
 1f7f10f:	vmovdqu64 %zmm0,0x450(%rsp)
 1f7f11a:	kmovw  %k6,0x1a0(%rsp)
 1f7f123:	kmovw  %k7,0x160(%rsp)
 1f7f12c:	vmovdqa %xmm4,0x290(%rsp)
 1f7f135:	kmovd  %k0,%eax
 1f7f139:	movzwl %ax,%r13d
 1f7f13d:	jmp    1f7f268 <node_facts_window_run+0x1e58>
 1f7f142:	mov    (%r12,%rax,4),%r9d
 1f7f146:	mov    0x9c8(%rdi),%rsi
 1f7f14d:	shl    $0x6,%rcx
 1f7f151:	mov    0x20(%r11),%rdx
 1f7f155:	cmpb   $0x1,(%rsi,%r9,1)
 1f7f15a:	mov    %r9,0x120(%rsp)
 1f7f162:	movzbl 0x30(%rdx,%rcx,1),%edx
 1f7f167:	adcq   $0x0,0x48(%rsp)
 1f7f16d:	and    $0x1,%edx
 1f7f170:	mov    0x570(%rsp),%rsi
 1f7f178:	mov    (%rsi,%rax,4),%esi
 1f7f17b:	vzeroupper
 1f7f17e:	call   1f93960 <node_tests_window_line>
 1f7f183:	mov    0x10(%rsp),%rdi
 1f7f188:	vpbroadcastd -0x19ae216(%rip),%zmm10        # 5d0f7c <.LCPI3_5>
 1f7f192:	vpbroadcastb -0x1ac845b(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f19b:	vpbroadcastb -0x1ac8463(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f1a4:	vpbroadcastd -0x19ae22a(%rip),%zmm13        # 5d0f84 <.LCPI3_11>
 1f7f1ae:	vpbroadcastd -0x19ae22c(%rip),%zmm14        # 5d0f8c <.LCPI3_13>
 1f7f1b8:	vmovdqa 0x290(%rsp),%xmm4
 1f7f1c1:	vmovdqa 0x1e0(%rsp),%xmm5
 1f7f1ca:	vmovdqu64 0x390(%rsp),%zmm6
 1f7f1d5:	vmovdqu64 0x350(%rsp),%zmm2
 1f7f1e0:	vmovdqu64 0x310(%rsp),%zmm3
 1f7f1eb:	vmovdqu64 0x220(%rsp),%zmm1
 1f7f1f6:	vmovdqu64 0x4d0(%rsp),%zmm7
 1f7f201:	vmovdqu64 0x3d0(%rsp),%zmm8
 1f7f20c:	vmovdqu64 0x490(%rsp),%zmm9
 1f7f217:	vmovdqu64 0x2d0(%rsp),%zmm15
 1f7f222:	vmovdqu64 0x450(%rsp),%zmm0
 1f7f22d:	mov    (%rsp),%r11
 1f7f231:	mov    0x120(%rsp),%rdx
 1f7f239:	mov    0x40(%rsp),%r9
 1f7f23e:	mov    0x20(%rsp),%r8
 1f7f243:	kmovw  0x1a0(%rsp),%k6
 1f7f24c:	kmovw  0x160(%rsp),%k7
 1f7f255:	or     %bl,%al
 1f7f257:	blsr   %r13d,%r13d
 1f7f25c:	mov    0x9c8(%rdi),%rcx
 1f7f263:	mov    %al,(%rcx,%rdx,1)
 1f7f266:	je     1f7f2cd <node_facts_window_run+0x1ebd>
 1f7f268:	xor    %eax,%eax
 1f7f26a:	tzcnt  %r13d,%eax
 1f7f26f:	mov    0x60(%r11),%esi
 1f7f273:	mov    $0x1,%bl
 1f7f275:	add    %r14,%rax
 1f7f278:	mov    %rax,%rdx
 1f7f27b:	shl    $0x6,%rdx
 1f7f27f:	mov    (%r8,%rdx,1),%ecx
 1f7f283:	mov    0xc(%r8,%rdx,1),%edx
 1f7f288:	shr    $0x3,%ecx
 1f7f28b:	cmp    %esi,%ecx
 1f7f28d:	cmovae %esi,%ecx
 1f7f290:	test   %rdx,%rdx
 1f7f293:	je     1f7f142 <node_facts_window_run+0x1d32>
 1f7f299:	mov    0x5f0(%rsp),%rsi
 1f7f2a1:	cmp    0x3b8(%rsi),%edx
 1f7f2a7:	jae    1f7f142 <node_facts_window_run+0x1d32>
 1f7f2ad:	mov    0x5f0(%rsp),%rsi
 1f7f2b5:	mov    0x3a8(%rsi),%rsi
 1f7f2bc:	cmpl   $0x0,(%rsi,%rdx,4)
 1f7f2c0:	setne  %bl
 1f7f2c3:	shl    $0x5,%bl
 1f7f2c6:	inc    %bl
 1f7f2c8:	jmp    1f7f142 <node_facts_window_run+0x1d32>
 1f7f2cd:	mov    0x9c8(%rdi),%rax
 1f7f2d4:	kmovq  %k7,%k1
 1f7f2d9:	vpxord %xmm18,%xmm18,%xmm18
 1f7f2df:	mov    0x18(%rsp),%rsi
 1f7f2e4:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7f2eb:	jmp    1f7eae8 <node_facts_window_run+0x16d8>
 1f7f2f0:	test   %eax,%eax
 1f7f2f2:	je     1f807f5 <node_facts_window_run+0x33e5>
 1f7f2f8:	vpbroadcastd -0x19ae386(%rip),%zmm13        # 5d0f7c <.LCPI3_5>
 1f7f302:	vpbroadcastb -0x1ac85cb(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f30b:	vpbroadcastb -0x1ac85d3(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f314:	vpbroadcastd -0x19ae39a(%rip),%zmm16        # 5d0f84 <.LCPI3_11>
 1f7f31e:	vpbroadcastd -0x19ae39c(%rip),%zmm17        # 5d0f8c <.LCPI3_13>
 1f7f328:	mov    (%r11),%rcx
 1f7f32b:	lea    0x69454(%rbp),%r10
 1f7f332:	lea    0x422c(%rbp),%rdx
 1f7f339:	mov    %eax,%r14d
 1f7f33c:	xor    %r15d,%r15d
 1f7f33f:	mov    %rcx,0x78(%rsp)
 1f7f344:	mov    %r10,0x98(%rsp)
 1f7f34c:	mov    %rdx,0x80(%rsp)
 1f7f354:	movq   $0x0,0x48(%rsp)
 1f7f35d:	movq   $0x0,0x38(%rsp)
 1f7f366:	movq   $0x0,0x8(%rsp)
 1f7f36f:	mov    %r14,0x90(%rsp)
 1f7f377:	jmp    1f7f43b <node_facts_window_run+0x202b>
 1f7f37c:	nopl   0x0(%rax)
 1f7f380:	vpxor  %xmm1,%xmm1,%xmm1
 1f7f384:	vpxor  %xmm0,%xmm0,%xmm0
 1f7f388:	vpxor  %xmm5,%xmm5,%xmm5
 1f7f38c:	vpxor  %xmm3,%xmm3,%xmm3
 1f7f390:	vpxor  %xmm6,%xmm6,%xmm6
 1f7f394:	vpxor  %xmm7,%xmm7,%xmm7
 1f7f398:	vpxor  %xmm8,%xmm8,%xmm8
 1f7f39d:	vpxor  %xmm2,%xmm2,%xmm2
 1f7f3a1:	vpxord %xmm19,%xmm19,%xmm19
 1f7f3a7:	mov    0x990(%rdi),%rax
 1f7f3ae:	vmovdqu64 %xmm19,(%rax,%r15,1)
 1f7f3b5:	mov    0x998(%rdi),%rax
 1f7f3bc:	vmovdqu %xmm2,(%rax,%r15,1)
 1f7f3c2:	mov    0xb88(%r11),%rax
 1f7f3c9:	vmovdqu %xmm8,(%rax,%r15,1)
 1f7f3cf:	mov    0xb90(%r11),%rax
 1f7f3d6:	vmovdqu %xmm7,(%rax,%r15,1)
 1f7f3dc:	mov    0xb98(%r11),%rax
 1f7f3e3:	vmovdqu %xmm6,(%rax,%r15,1)
 1f7f3e9:	mov    0xba0(%r11),%rax
 1f7f3f0:	vmovdqu %xmm3,(%rax,%r15,1)
 1f7f3f6:	mov    0xba8(%r11),%rax
 1f7f3fd:	vmovdqu %xmm4,(%rax,%r15,1)
 1f7f403:	mov    0xc28(%r11),%rax
 1f7f40a:	vmovdqu64 %zmm5,(%rax,%r15,4)
 1f7f411:	mov    0xcd8(%r11),%rax
 1f7f418:	vmovdqu64 %zmm0,(%rax,%r15,8)
 1f7f41f:	mov    0xcd8(%r11),%rax
 1f7f426:	vmovdqu64 %zmm1,0x40(%rax,%r15,8)
 1f7f42e:	add    $0x10,%r15
 1f7f432:	cmp    %r14,%r15
 1f7f435:	jae    1f80810 <node_facts_window_run+0x3400>
 1f7f43b:	vpxor  %xmm4,%xmm4,%xmm4
 1f7f43f:	cmp    %rsi,%r15
 1f7f442:	jae    1f7f380 <node_facts_window_run+0x1f70>
 1f7f448:	mov    %esi,%eax
 1f7f44a:	sub    %r15d,%eax
 1f7f44d:	mov    $0x10,%ecx
 1f7f452:	mov    $0xffffffff,%edx
 1f7f457:	mov    %r15,%rbp
 1f7f45a:	vpxor  %xmm12,%xmm12,%xmm12
 1f7f45f:	cmp    $0x10,%eax
 1f7f462:	cmovae %ecx,%eax
 1f7f465:	mov    0x9b8(%r11),%rcx
 1f7f46c:	shl    $0x6,%rbp
 1f7f470:	shlx   %eax,%edx,%eax
 1f7f475:	vmovdqu (%r8,%rbp,1),%ymm4
 1f7f47b:	vmovdqu64 0x40(%r8,%rbp,1),%ymm26
 1f7f483:	vmovdqu64 0x80(%r8,%rbp,1),%ymm27
 1f7f48b:	vmovdqu64 0xc0(%r8,%rbp,1),%ymm28
 1f7f493:	vmovdqu 0x100(%r8,%rbp,1),%ymm5
 1f7f49d:	vmovdqu 0x140(%r8,%rbp,1),%ymm6
 1f7f4a7:	vmovdqu64 0x180(%r8,%rbp,1),%ymm24
 1f7f4af:	vmovdqu64 0x1c0(%r8,%rbp,1),%ymm25
 1f7f4b7:	vmovdqu 0x200(%r8,%rbp,1),%ymm7
 1f7f4c1:	vmovdqu64 0x240(%r8,%rbp,1),%ymm18
 1f7f4c9:	vmovdqu64 0x280(%r8,%rbp,1),%ymm22
 1f7f4d1:	vmovdqu64 0x2c0(%r8,%rbp,1),%ymm23
 1f7f4d9:	vmovdqu 0x300(%r8,%rbp,1),%ymm11
 1f7f4e3:	vmovdqu64 0x340(%r8,%rbp,1),%ymm19
 1f7f4eb:	vmovdqu64 0x380(%r8,%rbp,1),%ymm20
 1f7f4f3:	vmovdqu64 0x3c0(%r8,%rbp,1),%ymm21
 1f7f4fb:	not    %eax
 1f7f4fd:	kmovd  %eax,%k1
 1f7f501:	mov    0x9c8(%rdi),%rax
 1f7f508:	vmovdqu8 (%rcx,%r15,1),%xmm0{%k1}{z}
 1f7f50f:	mov    0x98(%rsp),%rcx
 1f7f517:	vmovdqu8 (%rcx,%r15,1),%xmm10{%k1}{z}
 1f7f51e:	vptestmb %xmm0,%xmm0,%k6
 1f7f524:	vpcmpeqb -0x19b781e(%rip),%xmm10,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7f52e:	vmovdqu32 (%r12,%r15,4),%zmm0{%k7}{z}
 1f7f535:	kmovq  %k7,%k1
 1f7f53a:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7f541:	vptestnmd %zmm16,%zmm12,%k0
 1f7f547:	ktestw %k0,%k7
 1f7f54b:	jne    1f7fc8b <node_facts_window_run+0x287b>
 1f7f551:	vpmovsxbd -0x19ae59a(%rip),%xmm3        # 5d0fc0 <.LCPI3_77>
 1f7f55a:	vmovdqa64 -0x1ac8e24(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7f564:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7f56b:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7f572:	vptestmd -0x19ae5f4(%rip){1to16},%zmm12,%k0        # 5d0f88 <.LCPI3_12>
 1f7f57c:	vmovdqa64 %zmm0,%zmm2
 1f7f582:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7f588:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7f58e:	vmovdqa64 %zmm3,%zmm9
 1f7f594:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7f59a:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7f5a0:	kmovd  %k0,%r13d
 1f7f5a4:	vptestmd %zmm17,%zmm12,%k0
 1f7f5aa:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7f5b0:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7f5b7:	vmovdqu64 %zmm1,0x1e0(%rsp)
 1f7f5c2:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7f5c9:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7f5cd:	vmovdqa64 %zmm1,%zmm4
 1f7f5d3:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7f5d9:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7f5df:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7f5e5:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7f5eb:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7f5f2:	vmovdqu %ymm3,0x160(%rsp)
 1f7f5fb:	vinserti64x4 $0x1,%ymm18,%zmm7,%zmm3
 1f7f602:	vpunpcklqdq %ymm18,%ymm7,%ymm7
 1f7f608:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm18
 1f7f60f:	vmovdqa64 %zmm3,%zmm6
 1f7f615:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7f61b:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7f621:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7f627:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7f62d:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7f633:	vmovdqa64 %zmm18,%zmm7
 1f7f639:	vmovdqu64 %zmm5,0x290(%rsp)
 1f7f644:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7f64b:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7f651:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7f658:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7f65f:	vpermt2d %zmm5,%zmm9,%zmm18
 1f7f665:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7f66b:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7f672:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7f678:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7f67e:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7f685:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7f68c:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm21{%k6}{z}
 1f7f693:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7f69a:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm20{%k6}{z}
 1f7f6a1:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7f6a8:	vpsrld $0x19,%zmm21,%zmm0
 1f7f6af:	vpandd -0x19ae741(%rip){1to16},%zmm0,%zmm0        # 5d0f78 <.LCPI3_4>
 1f7f6b9:	vpsrld $0x18,%zmm21,%zmm1
 1f7f6c0:	vpsrld $0x1a,%zmm21,%zmm7
 1f7f6c7:	vpternlogd $0xec,%zmm13,%zmm0,%zmm1
 1f7f6ce:	vpandd -0x19ae714(%rip){1to16},%zmm21,%zmm0        # 5d0fc4 <.LCPI3_78>
 1f7f6d8:	vpmovdb %zmm1,%xmm19
 1f7f6de:	vpsrld $0xc,%zmm20,%zmm1
 1f7f6e5:	vpmovdb %zmm1,%xmm24
 1f7f6eb:	vpcmpeqd -0x19ae775(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f80 <.LCPI3_7>
 1f7f6f5:	vporq  %xmm14,%xmm19,%xmm0
 1f7f6fb:	vmovdqu8 %xmm0,%xmm19{%k1}
 1f7f701:	vpcmpeqb %xmm14,%xmm10,%k1{%k6}
 1f7f707:	vpternlogq $0xf8,%xmm15,%xmm24,%xmm19
 1f7f70e:	kmovd  %k1,%eax
 1f7f712:	kmovw  %k1,0x120(%rsp)
 1f7f71b:	korw   %k0,%k1,%k1
 1f7f71f:	kmovw  %k1,0x1a0(%rsp)
 1f7f728:	test   %ax,%ax
 1f7f72b:	je     1f7f8f0 <node_facts_window_run+0x24e0>
 1f7f731:	vmovdqu64 %zmm4,0x660(%rsp)
 1f7f73c:	vmovdqu %ymm5,0x5f0(%rsp)
 1f7f745:	vmovdqu64 %zmm7,0x530(%rsp)
 1f7f750:	vmovdqa64 %xmm24,0x570(%rsp)
 1f7f758:	vmovdqu64 %zmm23,0x5b0(%rsp)
 1f7f763:	vmovdqu64 %zmm22,0x450(%rsp)
 1f7f76e:	vmovdqu64 %zmm21,0x2d0(%rsp)
 1f7f779:	vmovdqu64 %zmm18,0x490(%rsp)
 1f7f784:	vmovdqu64 %zmm20,0x3d0(%rsp)
 1f7f78f:	vmovdqu64 %zmm12,0x4d0(%rsp)
 1f7f79a:	vmovdqa64 %xmm19,0x220(%rsp)
 1f7f7a2:	kmovw  %k7,0x350(%rsp)
 1f7f7ab:	mov    %rbp,0x310(%rsp)
 1f7f7b3:	kmovd  %k6,0x390(%rsp)
 1f7f7bd:	movzwl %ax,%r14d
 1f7f7c1:	movzwl %r13w,%r13d
 1f7f7c5:	xor    %ebp,%ebp
 1f7f7c7:	mov    0x80(%rsp),%rax
 1f7f7cf:	lea    (%rax,%r15,4),%rbx
 1f7f7d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7f7e0:	xor    %r12d,%r12d
 1f7f7e3:	tzcnt  %r14d,%r12d
 1f7f7e8:	xor    %edx,%edx
 1f7f7ea:	mov    (%rbx,%r12,4),%esi
 1f7f7ee:	vzeroupper
 1f7f7f1:	call   1f93960 <node_tests_window_line>
 1f7f7f6:	mov    0x10(%rsp),%rdi
 1f7f7fb:	mov    $0x1,%ecx
 1f7f800:	test   $0x2,%al
 1f7f802:	shlx   %r12d,%ecx,%eax
 1f7f807:	cmove  %ebp,%eax
 1f7f80a:	or     %eax,%r13d
 1f7f80d:	blsr   %r14d,%r14d
 1f7f812:	jne    1f7f7e0 <node_facts_window_run+0x23d0>
 1f7f814:	vpbroadcastd -0x19ae8a2(%rip),%zmm13        # 5d0f7c <.LCPI3_5>
 1f7f81e:	vpbroadcastb -0x1ac8ae7(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f827:	vpbroadcastb -0x1ac8aef(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f830:	vpbroadcastd -0x19ae8b6(%rip),%zmm16        # 5d0f84 <.LCPI3_11>
 1f7f83a:	vpbroadcastd -0x19ae8b8(%rip),%zmm17        # 5d0f8c <.LCPI3_13>
 1f7f844:	vmovdqa64 0x220(%rsp),%xmm19
 1f7f84c:	vmovdqu64 0x4d0(%rsp),%zmm12
 1f7f857:	vmovdqu64 0x3d0(%rsp),%zmm20
 1f7f862:	vmovdqu64 0x490(%rsp),%zmm18
 1f7f86d:	vmovdqu64 0x2d0(%rsp),%zmm21
 1f7f878:	vmovdqu64 0x450(%rsp),%zmm22
 1f7f883:	vmovdqu64 0x5b0(%rsp),%zmm23
 1f7f88e:	vmovdqa64 0x570(%rsp),%xmm24
 1f7f896:	vmovdqu64 0x530(%rsp),%zmm7
 1f7f8a1:	vmovdqu 0x5f0(%rsp),%ymm5
 1f7f8aa:	vmovdqu64 0x660(%rsp),%zmm4
 1f7f8b5:	mov    (%rsp),%r11
 1f7f8b9:	mov    0x40(%rsp),%r9
 1f7f8be:	mov    0x30(%rsp),%r12
 1f7f8c3:	mov    0x18(%rsp),%rsi
 1f7f8c8:	mov    0x20(%rsp),%r8
 1f7f8cd:	mov    0x90(%rsp),%r14
 1f7f8d5:	kmovd  0x390(%rsp),%k6
 1f7f8df:	mov    0x310(%rsp),%rbp
 1f7f8e7:	kmovw  0x350(%rsp),%k7
 1f7f8f0:	vpsrld $0x2,%zmm20,%zmm0
 1f7f8f7:	vpandd -0x19ae971(%rip){1to16},%zmm0,%zmm2        # 5d0f90 <.LCPI3_14>
 1f7f901:	vpbroadcastd -0x19ae977(%rip),%zmm0        # 5d0f94 <.LCPI3_15>
 1f7f90b:	vptestmd -0x19ae97d(%rip){1to16},%zmm20,%k3        # 5d0f98 <.LCPI3_16>
 1f7f915:	vmovdqu64 0x290(%rsp),%zmm1
 1f7f920:	vptestnmd %zmm4,%zmm4,%k1
 1f7f926:	vpbroadcastd -0x19ae98c(%rip),%zmm6        # 5d0fa4 <.LCPI3_21>
 1f7f930:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7f937:	kmovd  %r13d,%k4
 1f7f93c:	vpsrld $0x10,%zmm20,%zmm9
 1f7f943:	vpbroadcastb -0x1ac8c0a(%rip),%xmm8        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7f94c:	vpbroadcastb -0x1ac8c12(%rip),%xmm11        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7f955:	kmovw  %k1,%eax
 1f7f959:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7f95f:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7f966:	vmovdqu64 0x1e0(%rsp),%zmm0
 1f7f971:	korw   %k1,%k3,%k3
 1f7f975:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7f97c:	vpandd -0x19ae9be(%rip){1to16},%zmm21,%zmm5        # 5d0fc8 <.LCPI3_81>
 1f7f986:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7f98c:	vpbroadcastb -0x1ac8c51(%rip),%xmm7        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7f995:	vinserti64x4 $0x1,0x160(%rsp),%zmm0,%zmm0
 1f7f99e:	kmovw  %k0,%ecx
 1f7f9a2:	korw   %k2,%k3,%k2
 1f7f9a6:	vpaddd -0x19aea10(%rip){1to16},%zmm5,%zmm5        # 5d0fa0 <.LCPI3_20>
 1f7f9b0:	andn   %ecx,%eax,%eax
 1f7f9b5:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7f9bb:	kmovd  %eax,%k3
 1f7f9bf:	shr    $0x8,%eax
 1f7f9c2:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7f9c8:	kmovd  %eax,%k3
 1f7f9cc:	vmovdqu8 %xmm14,%xmm4{%k2}{z}
 1f7f9d2:	vpcmpltud %zmm6,%zmm5,%k2
 1f7f9d9:	vpslld $0x1f,%zmm5,%zmm5
 1f7f9e0:	vpxor  %xmm6,%xmm6,%xmm6
 1f7f9e4:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7f9ea:	vptestmd -0x19aea58(%rip){1to16},%zmm23,%k3        # 5d0f9c <.LCPI3_17>
 1f7f9f4:	vpandd %zmm17,%zmm23,%zmm3
 1f7f9fa:	vptestnmd %zmm3,%zmm3,%k0
 1f7fa00:	kandd  %k6,%k0,%k0
 1f7fa05:	korw   %k3,%k4,%k3
 1f7fa09:	kandd  %k2,%k0,%k4
 1f7fa0e:	vpcmpeqd %zmm16,%zmm2,%k2{%k4}
 1f7fa14:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7fa1a:	vmovdqu8 -0x19b7ce4(%rip),%xmm2{%k4}        # 5c7d40 <.LCPI3_25>
 1f7fa24:	knotw  %k2,%k0
 1f7fa28:	kandd  %k0,%k4,%k5
 1f7fa2d:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7fa33:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7fa3a:	vpaddd %zmm5,%zmm9,%zmm10
 1f7fa40:	vpbroadcastb -0x1ac8d04(%rip),%xmm5        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7fa49:	vmovdqu8 -0x19b7d03(%rip),%xmm2{%k4}        # 5c7d50 <.LCPI3_26>
 1f7fa53:	vptestnmd %zmm10,%zmm10,%k4
 1f7fa59:	vpblendmb -0x19b7cf3(%rip),%xmm5,%xmm5{%k4}        # 5c7d70 <.LCPI3_28>
 1f7fa63:	vpcmpnleud -0x19aeac6(%rip){1to16},%zmm10,%k4        # 5d0fa8 <.LCPI3_22>
 1f7fa6e:	cmpb   $0x0,0xa10(%rdi)
 1f7fa75:	vmovdqu8 -0x19b7cff(%rip),%xmm5{%k4}        # 5c7d80 <.LCPI3_29>
 1f7fa7f:	vpcmpnleud -0x19aeade(%rip){1to16},%zmm10,%k4        # 5d0fac <.LCPI3_23>
 1f7fa8a:	vmovdqu8 -0x19b7d04(%rip),%xmm5{%k4}        # 5c7d90 <.LCPI3_30>
 1f7fa94:	vptestmd %zmm3,%zmm3,%k4
 1f7fa9a:	vpor   %xmm4,%xmm8,%xmm3
 1f7fa9e:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7faa4:	kmovw  0x1a0(%rsp),%k4
 1f7faad:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7fab3:	vpor   %xmm2,%xmm4,%xmm2
 1f7fab7:	vpord  -0x19aeaf5(%rip){1to4},%xmm2,%xmm3        # 5d0fcc <.LCPI3_84>
 1f7fac1:	vpbroadcastb -0x1ac8d84(%rip),%xmm5        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7faca:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7fad0:	vpor   %xmm5,%xmm2,%xmm3
 1f7fad4:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7fada:	vpmovdb %zmm20,%xmm3
 1f7fae0:	kmovw  0x120(%rsp),%k3
 1f7fae9:	vpor   %xmm3,%xmm11,%xmm4
 1f7faed:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7faf3:	vptestmd -0x19aeb4d(%rip){1to16},%zmm12,%k3{%k7}        # 5d0fb0 <.LCPI3_32>
 1f7fafd:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7fb03:	vpor   %xmm5,%xmm4,%xmm6
 1f7fb07:	vpsrld $0xb,%zmm23,%zmm7
 1f7fb0e:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7fb14:	vpandd -0x19aeb4e(%rip){1to4},%xmm24,%xmm4        # 5d0fd0 <.LCPI3_86>
 1f7fb1e:	vptestmd -0x19aeb74(%rip){1to16},%zmm23,%k1        # 5d0fb4 <.LCPI3_33>
 1f7fb28:	vpmovdb %zmm7,%xmm7
 1f7fb2e:	vpand  %xmm7,%xmm8,%xmm7
 1f7fb32:	vpmovdb %zmm21,%xmm8
 1f7fb38:	vpor   %xmm4,%xmm15,%xmm5
 1f7fb3c:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7fb42:	vpmovdb %zmm23,%xmm5
 1f7fb48:	vgf2p8affineqb $0x0,-0x19b15b3(%rip){1to2},%xmm5,%xmm5        # 5ce5a0 <.LCPI3_87>
 1f7fb53:	vpternlogq $0xf8,%xmm11,%xmm5,%xmm4
 1f7fb5a:	vpsrld $0x8,%zmm21,%zmm11
 1f7fb61:	vpor   %xmm4,%xmm14,%xmm5
 1f7fb65:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7fb6b:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7fb72:	vpsrld $0x10,%zmm21,%zmm6
 1f7fb79:	vpmovdb %zmm11,%xmm7
 1f7fb7f:	vinserti32x4 $0x3,%xmm18,%zmm22,%zmm5{%k6}{z}
 1f7fb86:	vpmovdb %zmm6,%xmm6
 1f7fb8c:	je     1f7fc81 <node_facts_window_run+0x2871>
 1f7fb92:	vmovdqa64 -0x1ac939c(%rip),%zmm18        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7fb9c:	vptestmd %zmm9,%zmm9,%k1{%k2}
 1f7fba2:	add    %r8,%rbp
 1f7fba5:	vpxor  %xmm11,%xmm11,%xmm11
 1f7fbaa:	vpxor  %xmm12,%xmm12,%xmm12
 1f7fbaf:	vpcmpneqd -0x19aec02(%rip){1to16},%zmm9,%k0{%k1}        # 5d0fb8 <.LCPI3_38>
 1f7fbba:	vmovdqa %xmm6,%xmm9
 1f7fbbe:	vpternlogq $0xfe,%xmm8,%xmm3,%xmm9
 1f7fbc5:	kmovq  %k1,%k2
 1f7fbca:	kmovw  %k1,%eax
 1f7fbce:	popcnt %eax,%ecx
 1f7fbd2:	vpgatherdd 0x10(%rbp,%zmm18,1),%zmm11{%k2}
 1f7fbda:	kmovq  %k1,%k2
 1f7fbdf:	vpcmpnleud -0x19aec2e(%rip){1to16},%zmm11,%k3        # 5d0fbc <.LCPI3_39>
 1f7fbea:	vpgatherdd 0x14(%rbp,%zmm18,1),%zmm12{%k2}
 1f7fbf2:	add    %rcx,0x38(%rsp)
 1f7fbf7:	mov    0x8(%rsp),%r10
 1f7fbfc:	vpcmpeqd %zmm10,%zmm11,%k2
 1f7fc02:	vmovdqa64 %xmm19,%xmm10
 1f7fc08:	vpternlogq $0xfe,%xmm7,%xmm9,%xmm10
 1f7fc0f:	vptestnmd %zmm12,%zmm12,%k2{%k2}
 1f7fc15:	vptestmd %zmm12,%zmm12,%k4
 1f7fc1b:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm10
 1f7fc22:	korw   %k4,%k3,%k3
 1f7fc26:	kandw  %k2,%k0,%k2
 1f7fc2a:	knotw  %k0,%k0
 1f7fc2e:	kandd  %k1,%k0,%k0
 1f7fc33:	kandw  %k0,%k3,%k0
 1f7fc37:	korw   %k0,%k2,%k2
 1f7fc3b:	vptestnmd %zmm13,%zmm20,%k0{%k2}
 1f7fc41:	kandw  %k0,%k1,%k0
 1f7fc45:	knotd  %k6,%k1
 1f7fc4a:	kmovd  %k0,%ecx
 1f7fc4e:	vptestmb %xmm10,%xmm10,%k0{%k1}
 1f7fc54:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7fc5a:	andn   %eax,%ecx,%eax
 1f7fc5f:	popcnt %eax,%eax
 1f7fc63:	kmovw  %k0,%ecx
 1f7fc67:	popcnt %ecx,%ecx
 1f7fc6b:	kmovw  %k1,%edx
 1f7fc6f:	popcnt %edx,%edx
 1f7fc73:	add    %rdx,%r10
 1f7fc76:	add    %rax,%r10
 1f7fc79:	add    %rcx,%r10
 1f7fc7c:	mov    %r10,0x8(%rsp)
 1f7fc81:	mov    0x28(%rsp),%rbp
 1f7fc86:	jmp    1f7f3a7 <node_facts_window_run+0x1f97>
 1f7fc8b:	kandw  %k0,%k7,%k0
 1f7fc8f:	vmovdqa %xmm10,0x290(%rsp)
 1f7fc98:	vmovdqu64 %zmm11,0x310(%rsp)
 1f7fca3:	vmovdqu64 %ymm19,0x220(%rsp)
 1f7fcab:	vmovdqu64 %zmm20,0x4d0(%rsp)
 1f7fcb6:	vmovdqu64 %ymm21,0x3d0(%rsp)
 1f7fcc1:	vmovdqu64 %zmm7,0x490(%rsp)
 1f7fccc:	vmovdqu64 %ymm18,0x2d0(%rsp)
 1f7fcd7:	vmovdqu64 %zmm22,0x450(%rsp)
 1f7fce2:	vmovdqu64 %ymm23,0x5b0(%rsp)
 1f7fced:	vmovdqu64 %zmm5,0x570(%rsp)
 1f7fcf8:	vmovdqu %ymm6,0x530(%rsp)
 1f7fd01:	vmovdqu64 %zmm24,0x5f0(%rsp)
 1f7fd0c:	vmovdqu64 %ymm25,0x660(%rsp)
 1f7fd14:	vmovdqu64 %zmm4,0x720(%rsp)
 1f7fd1f:	vmovdqu64 %ymm26,0x430(%rsp)
 1f7fd2a:	vmovdqu64 %zmm27,0x6e0(%rsp)
 1f7fd35:	vmovdqu64 %ymm28,0x410(%rsp)
 1f7fd40:	vmovdqu64 %zmm0,0x7c0(%rsp)
 1f7fd48:	kmovd  %k6,0x390(%rsp)
 1f7fd52:	kmovw  %k7,0x350(%rsp)
 1f7fd5b:	kmovd  %k0,%eax
 1f7fd5f:	movzwl %ax,%eax
 1f7fd62:	jmp    1f7ff10 <node_facts_window_run+0x2b00>
 1f7fd67:	mov    0x48(%rsp),%rsi
 1f7fd6c:	mov    (%r12,%r13,4),%r9d
 1f7fd70:	mov    0x9c8(%rdi),%rdx
 1f7fd77:	shl    $0x6,%rax
 1f7fd7b:	mov    %r8b,0x160(%rsp)
 1f7fd83:	mov    0x20(%r11),%rcx
 1f7fd87:	cmpb   $0x1,(%rdx,%r9,1)
 1f7fd8c:	mov    %r9,0x1e0(%rsp)
 1f7fd94:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7fd99:	adc    $0x0,%rsi
 1f7fd9d:	and    $0x1,%edx
 1f7fda0:	mov    %rsi,0x48(%rsp)
 1f7fda5:	mov    0x80(%rsp),%rbx
 1f7fdad:	mov    (%rbx,%r13,4),%esi
 1f7fdb1:	vzeroupper
 1f7fdb4:	call   1f93960 <node_tests_window_line>
 1f7fdb9:	mov    %al,0x1a0(%rsp)
 1f7fdc0:	mov    (%rbx,%r13,4),%esi
 1f7fdc4:	mov    0x10(%rsp),%rdi
 1f7fdc9:	call   1f93ab0 <node_tests_window_returns>
 1f7fdce:	mov    0x10(%rsp),%rdi
 1f7fdd3:	or     0x160(%rsp),%al
 1f7fdda:	mov    0x1e0(%rsp),%rdx
 1f7fde2:	vpbroadcastd -0x19aee70(%rip),%zmm13        # 5d0f7c <.LCPI3_5>
 1f7fdec:	vpbroadcastb -0x1ac90b5(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7fdf5:	vpbroadcastb -0x1ac90bd(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7fdfe:	vpbroadcastd -0x19aee84(%rip),%zmm16        # 5d0f84 <.LCPI3_11>
 1f7fe08:	vpbroadcastd -0x19aee86(%rip),%zmm17        # 5d0f8c <.LCPI3_13>
 1f7fe12:	vmovdqa 0x290(%rsp),%xmm10
 1f7fe1b:	vmovdqu64 0x310(%rsp),%zmm11
 1f7fe26:	vmovdqu64 0x220(%rsp),%ymm19
 1f7fe2e:	vmovdqu64 0x4d0(%rsp),%zmm20
 1f7fe39:	vmovdqu64 0x3d0(%rsp),%ymm21
 1f7fe44:	vmovdqu64 0x490(%rsp),%zmm7
 1f7fe4f:	vmovdqu64 0x2d0(%rsp),%ymm18
 1f7fe5a:	vmovdqu64 0x450(%rsp),%zmm22
 1f7fe65:	vmovdqu64 0x5b0(%rsp),%ymm23
 1f7fe70:	vmovdqu64 0x570(%rsp),%zmm5
 1f7fe7b:	vmovdqu 0x530(%rsp),%ymm6
 1f7fe84:	vmovdqu64 0x5f0(%rsp),%zmm24
 1f7fe8f:	vmovdqu64 0x660(%rsp),%ymm25
 1f7fe97:	vmovdqu64 0x720(%rsp),%zmm4
 1f7fea2:	vmovdqu64 0x430(%rsp),%ymm26
 1f7fead:	vmovdqu64 0x6e0(%rsp),%zmm27
 1f7feb8:	vmovdqu64 0x410(%rsp),%ymm28
 1f7fec3:	vmovdqu64 0x7c0(%rsp),%zmm0
 1f7fecb:	mov    (%rsp),%r11
 1f7fecf:	mov    0x40(%rsp),%r9
 1f7fed4:	mov    0x18(%rsp),%rsi
 1f7fed9:	mov    0x20(%rsp),%r8
 1f7fede:	kmovd  0x390(%rsp),%k6
 1f7fee8:	kmovw  0x350(%rsp),%k7
 1f7fef1:	or     0x1a0(%rsp),%al
 1f7fef8:	mov    0x9c8(%rdi),%rcx
 1f7feff:	mov    %al,(%rcx,%rdx,1)
 1f7ff02:	mov    0x120(%rsp),%eax
 1f7ff09:	blsr   %eax,%eax
 1f7ff0e:	je     1f7ff7d <node_facts_window_run+0x2b6d>
 1f7ff10:	tzcnt  %eax,%r13d
 1f7ff15:	mov    %eax,0x120(%rsp)
 1f7ff1c:	mov    0x60(%r11),%edx
 1f7ff20:	add    %r15,%r13
 1f7ff23:	mov    %r13,%rcx
 1f7ff26:	shl    $0x6,%rcx
 1f7ff2a:	mov    (%r8,%rcx,1),%eax
 1f7ff2e:	mov    0xc(%r8,%rcx,1),%ecx
 1f7ff33:	mov    $0x1,%r8b
 1f7ff36:	shr    $0x3,%eax
 1f7ff39:	cmp    %edx,%eax
 1f7ff3b:	cmovae %edx,%eax
 1f7ff3e:	test   %rcx,%rcx
 1f7ff41:	je     1f7fd67 <node_facts_window_run+0x2957>
 1f7ff47:	mov    0x78(%rsp),%rdx
 1f7ff4c:	mov    0x48(%rsp),%rsi
 1f7ff51:	cmp    0x3b8(%rdx),%ecx
 1f7ff57:	jae    1f7fd6c <node_facts_window_run+0x295c>
 1f7ff5d:	mov    0x78(%rsp),%rdx
 1f7ff62:	mov    0x3a8(%rdx),%rdx
 1f7ff69:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7ff6d:	setne  %r8b
 1f7ff71:	shl    $0x5,%r8b
 1f7ff75:	inc    %r8b
 1f7ff78:	jmp    1f7fd6c <node_facts_window_run+0x295c>
 1f7ff7d:	mov    0x9c8(%rdi),%rax
 1f7ff84:	kmovq  %k7,%k1
 1f7ff89:	vpxor  %xmm12,%xmm12,%xmm12
 1f7ff8e:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7ff95:	jmp    1f7f551 <node_facts_window_run+0x2141>
 1f7ff9a:	test   %eax,%eax
 1f7ff9c:	je     1f807f5 <node_facts_window_run+0x33e5>
 1f7ffa2:	vpbroadcastd -0x19af030(%rip),%zmm6        # 5d0f7c <.LCPI3_5>
 1f7ffac:	vpbroadcastb -0x1ac9273(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7ffb5:	vpbroadcastd -0x19af03b(%rip),%zmm8        # 5d0f84 <.LCPI3_11>
 1f7ffbf:	vpbroadcastd -0x19af03d(%rip),%zmm9        # 5d0f8c <.LCPI3_13>
 1f7ffc9:	lea    0x69454(%rbp),%rcx
 1f7ffd0:	lea    0x422c(%rbp),%r14
 1f7ffd7:	mov    %eax,%r10d
 1f7ffda:	xor    %r15d,%r15d
 1f7ffdd:	mov    %rcx,0x4d0(%rsp)
 1f7ffe5:	movq   $0x0,0x48(%rsp)
 1f7ffee:	movq   $0x0,0x38(%rsp)
 1f7fff7:	movq   $0x0,0x8(%rsp)
 1f80000:	mov    %r10,0x3d0(%rsp)
 1f80008:	mov    %r14,0x490(%rsp)
 1f80010:	jmp    1f8004c <node_facts_window_run+0x2c3c>
 1f80012:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f80020:	vpxor  %xmm11,%xmm11,%xmm11
 1f80025:	mov    0x990(%rdi),%rax
 1f8002c:	vmovdqu %xmm11,(%rax,%r15,1)
 1f80032:	mov    0x998(%rdi),%rax
 1f80039:	vmovdqu %xmm0,(%rax,%r15,1)
 1f8003f:	add    $0x10,%r15
 1f80043:	cmp    %r10,%r15
 1f80046:	jae    1f80810 <node_facts_window_run+0x3400>
 1f8004c:	vpxor  %xmm0,%xmm0,%xmm0
 1f80050:	cmp    %rsi,%r15
 1f80053:	jae    1f80020 <node_facts_window_run+0x2c10>
 1f80055:	mov    %esi,%eax
 1f80057:	sub    %r15d,%eax
 1f8005a:	mov    $0x10,%ecx
 1f8005f:	mov    $0xffffffff,%edx
 1f80064:	mov    %r15,%rbp
 1f80067:	cmp    $0x10,%eax
 1f8006a:	cmovae %ecx,%eax
 1f8006d:	mov    0x9b8(%r11),%rcx
 1f80074:	shl    $0x6,%rbp
 1f80078:	shlx   %eax,%edx,%eax
 1f8007d:	vmovdqu 0x100(%r8,%rbp,1),%ymm2
 1f80087:	vmovdqu 0x180(%r8,%rbp,1),%ymm3
 1f80091:	vmovdqu (%r8,%rbp,1),%ymm0
 1f80097:	vmovdqu 0x80(%r8,%rbp,1),%ymm1
 1f800a1:	not    %eax
 1f800a3:	vinserti64x4 $0x1,0x140(%r8,%rbp,1),%zmm2,%zmm5
 1f800ac:	vinserti64x4 $0x1,0x1c0(%r8,%rbp,1),%zmm3,%zmm2
 1f800b5:	vinserti64x4 $0x1,0x40(%r8,%rbp,1),%zmm0,%zmm4
 1f800be:	vmovdqu 0x200(%r8,%rbp,1),%ymm0
 1f800c8:	vinserti64x4 $0x1,0xc0(%r8,%rbp,1),%zmm1,%zmm12
 1f800d1:	kmovd  %eax,%k1
 1f800d5:	vinserti64x4 $0x1,0x240(%r8,%rbp,1),%zmm0,%zmm11
 1f800de:	vmovdqu 0x280(%r8,%rbp,1),%ymm0
 1f800e8:	mov    0x9c8(%rdi),%rax
 1f800ef:	vinserti64x4 $0x1,0x2c0(%r8,%rbp,1),%zmm0,%zmm14
 1f800f8:	vmovdqu 0x300(%r8,%rbp,1),%ymm0
 1f80102:	vmovdqu8 (%rcx,%r15,1),%xmm10{%k1}{z}
 1f80109:	mov    0x4d0(%rsp),%rcx
 1f80111:	vinserti64x4 $0x1,0x340(%r8,%rbp,1),%zmm0,%zmm13
 1f8011a:	vmovdqu 0x380(%r8,%rbp,1),%ymm0
 1f80124:	vinserti64x4 $0x1,0x3c0(%r8,%rbp,1),%zmm0,%zmm15
 1f8012d:	vmovdqu8 (%rcx,%r15,1),%xmm3{%k1}{z}
 1f80134:	vptestmb %xmm10,%xmm10,%k2
 1f8013a:	vpxor  %xmm0,%xmm0,%xmm0
 1f8013e:	vpcmpeqb %xmm7,%xmm3,%k3{%k2}
 1f80144:	vmovdqu32 (%r12,%r15,4),%zmm1{%k3}{z}
 1f8014b:	kmovq  %k3,%k1
 1f80150:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f80157:	vptestnmd %zmm8,%zmm0,%k0
 1f8015d:	ktestw %k0,%k3
 1f80161:	jne    1f80603 <node_facts_window_run+0x31f3>
 1f80167:	vmovdqa64 -0x1ac9a31(%rip),%zmm1        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f80171:	kmovd  %k2,%edx
 1f80175:	vpermt2d %zmm12,%zmm1,%zmm4
 1f8017b:	vpermt2d %zmm2,%zmm1,%zmm5
 1f80181:	vpermt2d %zmm14,%zmm1,%zmm11
 1f80187:	vpermt2d %zmm15,%zmm1,%zmm13
 1f8018d:	vshufi64x2 $0x44,%zmm13,%zmm11,%zmm2
 1f80194:	vshufi64x2 $0x44,%zmm5,%zmm4,%zmm1
 1f8019b:	vshufi64x2 $0xee,%zmm5,%zmm4,%zmm14
 1f801a2:	vshufi64x2 $0xee,%zmm13,%zmm11,%zmm13
 1f801a9:	vshufi32x4 $0x88,%zmm2,%zmm1,%zmm4{%k2}{z}
 1f801b0:	vshufi32x4 $0xdd,%zmm2,%zmm1,%zmm5{%k2}{z}
 1f801b7:	vshufi32x4 $0xdd,%zmm13,%zmm14,%zmm12{%k2}{z}
 1f801be:	vpsrld $0x19,%zmm4,%zmm1
 1f801c5:	vpandd -0x19af257(%rip){1to16},%zmm1,%zmm1        # 5d0f78 <.LCPI3_4>
 1f801cf:	vpsrld $0x18,%zmm4,%zmm2
 1f801d6:	vpternlogd $0xec,%zmm6,%zmm1,%zmm2
 1f801dd:	vpandd -0x19af223(%rip){1to16},%zmm4,%zmm1        # 5d0fc4 <.LCPI3_78>
 1f801e7:	vpmovdb %zmm2,%xmm11
 1f801ed:	vpbroadcastb -0x1ac94b6(%rip),%xmm2        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f801f6:	vpcmpeqd -0x19af280(%rip){1to16},%zmm1,%k1{%k2}        # 5d0f80 <.LCPI3_7>
 1f80200:	vpor   %xmm2,%xmm11,%xmm1
 1f80204:	vpcmpeqb %xmm2,%xmm3,%k0{%k2}
 1f8020a:	kmovd  %k0,%eax
 1f8020e:	vmovdqu8 %xmm1,%xmm11{%k1}
 1f80214:	vptestmd %zmm9,%zmm0,%k1
 1f8021a:	korw   %k1,%k0,%k5
 1f8021e:	vptestmd -0x19af2a0(%rip){1to16},%zmm0,%k0        # 5d0f88 <.LCPI3_12>
 1f80228:	kmovd  %k0,%r13d
 1f8022c:	test   %ax,%ax
 1f8022f:	je     1f8037e <node_facts_window_run+0x2f6e>
 1f80235:	lea    (%r14,%r15,4),%r14
 1f80239:	movzwl %r13w,%r13d
 1f8023d:	movzwl %ax,%ebx
 1f80240:	vmovdqu64 %zmm13,0x220(%rsp)
 1f8024b:	vmovdqu64 %zmm14,0x310(%rsp)
 1f80256:	vmovdqu64 %zmm5,0x350(%rsp)
 1f80261:	vmovdqu64 %zmm4,0x390(%rsp)
 1f8026c:	kmovw  %k5,0x290(%rsp)
 1f80275:	vmovdqu64 %zmm12,0x160(%rsp)
 1f80280:	mov    %edx,0x1a0(%rsp)
 1f80287:	vmovdqa %xmm11,0x1e0(%rsp)
 1f80290:	vmovdqa %xmm10,0x120(%rsp)
 1f80299:	nopl   0x0(%rax)
 1f802a0:	xor    %r12d,%r12d
 1f802a3:	tzcnt  %ebx,%r12d
 1f802a8:	xor    %edx,%edx
 1f802aa:	mov    (%r14,%r12,4),%esi
 1f802ae:	vzeroupper
 1f802b1:	call   1f93960 <node_tests_window_line>
 1f802b6:	mov    0x10(%rsp),%rdi
 1f802bb:	mov    $0x1,%edx
 1f802c0:	xor    %ecx,%ecx
 1f802c2:	test   $0x2,%al
 1f802c4:	shlx   %r12d,%edx,%eax
 1f802c9:	cmove  %ecx,%eax
 1f802cc:	or     %eax,%r13d
 1f802cf:	blsr   %ebx,%ebx
 1f802d4:	jne    1f802a0 <node_facts_window_run+0x2e90>
 1f802d6:	vpbroadcastd -0x19af364(%rip),%zmm6        # 5d0f7c <.LCPI3_5>
 1f802e0:	vpbroadcastb -0x1ac95a7(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f802e9:	vpbroadcastd -0x19af36f(%rip),%zmm8        # 5d0f84 <.LCPI3_11>
 1f802f3:	vpbroadcastd -0x19af371(%rip),%zmm9        # 5d0f8c <.LCPI3_13>
 1f802fd:	vmovdqa 0x120(%rsp),%xmm10
 1f80306:	vmovdqa 0x1e0(%rsp),%xmm11
 1f8030f:	vmovdqu64 0x160(%rsp),%zmm12
 1f8031a:	vmovdqu64 0x390(%rsp),%zmm4
 1f80325:	vmovdqu64 0x350(%rsp),%zmm5
 1f80330:	vmovdqu64 0x310(%rsp),%zmm14
 1f8033b:	vmovdqu64 0x220(%rsp),%zmm13
 1f80346:	mov    (%rsp),%r11
 1f8034a:	mov    0x40(%rsp),%r9
 1f8034f:	mov    0x30(%rsp),%r12
 1f80354:	mov    0x18(%rsp),%rsi
 1f80359:	mov    0x20(%rsp),%r8
 1f8035e:	mov    0x490(%rsp),%r14
 1f80366:	mov    0x3d0(%rsp),%r10
 1f8036e:	mov    0x1a0(%rsp),%edx
 1f80375:	kmovw  0x290(%rsp),%k5
 1f8037e:	vpsrld $0x2,%zmm12,%zmm2
 1f80385:	vpandd -0x19af3ff(%rip){1to16},%zmm2,%zmm2        # 5d0f90 <.LCPI3_14>
 1f8038f:	vptestmd -0x19af401(%rip){1to16},%zmm12,%k2        # 5d0f98 <.LCPI3_16>
 1f80399:	vshufi64x2 $0x88,%zmm13,%zmm14,%zmm0
 1f803a0:	vptestnmb %xmm10,%xmm10,%k0
 1f803a6:	vpsrld $0x1a,%zmm4,%zmm1
 1f803ad:	vpandd -0x19af3ef(%rip){1to16},%zmm4,%zmm4        # 5d0fc8 <.LCPI3_81>
 1f803b7:	kmovd  %r13d,%k3
 1f803bc:	vpcmpneqd -0x19af433(%rip){1to16},%zmm2,%k1        # 5d0f94 <.LCPI3_15>
 1f803c7:	vpaddd -0x19af431(%rip){1to16},%zmm4,%zmm4        # 5d0fa0 <.LCPI3_20>
 1f803d1:	korw   %k1,%k2,%k1
 1f803d5:	vptestnmd %zmm0,%zmm0,%k2
 1f803db:	vpandd %zmm9,%zmm5,%zmm0
 1f803e1:	korw   %k2,%k0,%k0
 1f803e5:	vptestmd -0x19af453(%rip){1to16},%zmm5,%k2        # 5d0f9c <.LCPI3_17>
 1f803ef:	vpbroadcastd -0x19af455(%rip),%zmm5        # 5d0fa4 <.LCPI3_21>
 1f803f9:	korw   %k1,%k0,%k1
 1f803fd:	vptestnmd %zmm0,%zmm0,%k0
 1f80403:	kmovd  %k0,%eax
 1f80407:	vptestmd %zmm2,%zmm2,%k1{%k1}
 1f8040d:	vmovdqu8 -0x19b8727(%rip),%xmm3{%k1}{z}        # 5c7cf0 <.LCPI3_8>
 1f80417:	vpcmpeqd %zmm5,%zmm1,%k4
 1f8041d:	vpcmpltud %zmm5,%zmm4,%k0
 1f80424:	korw   %k2,%k3,%k1
 1f80428:	vpslld $0x1f,%zmm4,%zmm1
 1f8042f:	vpbroadcastb -0x1ac96f3(%rip),%xmm4        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f80438:	vptestmb %xmm10,%xmm10,%k4{%k4}
 1f8043e:	kmovd  %k0,%ecx
 1f80442:	and    %eax,%ecx
 1f80444:	mov    %edx,%eax
 1f80446:	and    %ecx,%eax
 1f80448:	vmovdqu8 -0x19b8722(%rip),%xmm5{%k4}{z}        # 5c7d30 <.LCPI3_24>
 1f80452:	kmovd  %eax,%k3
 1f80456:	vpcmpeqd %zmm8,%zmm2,%k2{%k3}
 1f8045c:	vpxor  %xmm2,%xmm2,%xmm2
 1f80460:	knotw  %k2,%k0
 1f80464:	kmovd  %k0,%ecx
 1f80468:	and    %eax,%ecx
 1f8046a:	vmovdqu8 -0x19b8734(%rip),%xmm5{%k3}        # 5c7d40 <.LCPI3_25>
 1f80474:	kmovd  %ecx,%k3
 1f80478:	vpcmpgtd %zmm1,%zmm2,%k3{%k3}
 1f8047e:	vpsrld $0x10,%zmm12,%zmm1
 1f80485:	vpternlogd $0xff,%zmm2,%zmm2,%zmm2
 1f8048c:	vpaddd %zmm2,%zmm1,%zmm2
 1f80492:	vmovdqu8 -0x19b874c(%rip),%xmm5{%k3}        # 5c7d50 <.LCPI3_26>
 1f8049c:	vptestnmd %zmm2,%zmm2,%k3
 1f804a2:	vpblendmb -0x19b873c(%rip),%xmm4,%xmm4{%k3}        # 5c7d70 <.LCPI3_28>
 1f804ac:	vpcmpnleud -0x19af50f(%rip){1to16},%zmm2,%k3        # 5d0fa8 <.LCPI3_22>
 1f804b7:	cmpb   $0x0,0xa10(%rdi)
 1f804be:	vmovdqu8 -0x19b8748(%rip),%xmm4{%k3}        # 5c7d80 <.LCPI3_29>
 1f804c8:	vpcmpnleud -0x19af527(%rip){1to16},%zmm2,%k3        # 5d0fac <.LCPI3_23>
 1f804d3:	vmovdqu8 -0x19b874d(%rip),%xmm4{%k3}        # 5c7d90 <.LCPI3_30>
 1f804dd:	vptestmd %zmm0,%zmm0,%k3
 1f804e3:	vpor   %xmm7,%xmm3,%xmm0
 1f804e7:	vmovdqu8 %xmm0,%xmm3{%k3}
 1f804ed:	vmovdqu8 %xmm4,%xmm5{%k2}
 1f804f3:	vpor   %xmm5,%xmm3,%xmm0
 1f804f7:	vpord  -0x19af535(%rip){1to4},%xmm0,%xmm3        # 5d0fcc <.LCPI3_84>
 1f80501:	vmovdqu8 %xmm3,%xmm0{%k5}
 1f80507:	vpord  -0x19af53d(%rip){1to4},%xmm0,%xmm3        # 5d0fd4 <.LCPI3_88>
 1f80511:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f80517:	vpsrld $0xc,%zmm12,%zmm3
 1f8051e:	vpmovdb %zmm3,%xmm3
 1f80524:	vpternlogd $0xf8,-0x19af557(%rip){1to4},%xmm3,%xmm11        # 5d0fd8 <.LCPI3_89>
 1f8052f:	je     1f805f9 <node_facts_window_run+0x31e9>
 1f80535:	vmovdqa64 -0x1ac9d3f(%rip),%zmm5        # 4b6800 <abi_test_hex.digits+0xb480>
 1f8053f:	vptestmd %zmm1,%zmm1,%k1{%k2}
 1f80545:	add    %r8,%rbp
 1f80548:	vpxor  %xmm3,%xmm3,%xmm3
 1f8054c:	vpxor  %xmm4,%xmm4,%xmm4
 1f80550:	vpcmpneqd -0x19af5a3(%rip){1to16},%zmm1,%k0{%k1}        # 5d0fb8 <.LCPI3_38>
 1f8055b:	vpor   %xmm0,%xmm11,%xmm1
 1f8055f:	kmovq  %k1,%k2
 1f80564:	kmovw  %k1,%eax
 1f80568:	popcnt %eax,%ecx
 1f8056c:	vpgatherdd 0x10(%rbp,%zmm5,1),%zmm3{%k2}
 1f80574:	kmovq  %k1,%k2
 1f80579:	vpcmpnleud -0x19af5c8(%rip){1to16},%zmm3,%k3        # 5d0fbc <.LCPI3_39>
 1f80584:	vpgatherdd 0x14(%rbp,%zmm5,1),%zmm4{%k2}
 1f8058c:	add    %rcx,0x38(%rsp)
 1f80591:	mov    0x8(%rsp),%rbx
 1f80596:	vpcmpeqd %zmm2,%zmm3,%k2
 1f8059c:	vptestnmd %zmm4,%zmm4,%k2{%k2}
 1f805a2:	vptestmd %zmm4,%zmm4,%k4
 1f805a8:	korw   %k4,%k3,%k3
 1f805ac:	kandw  %k2,%k0,%k2
 1f805b0:	knotw  %k0,%k0
 1f805b4:	kandd  %k1,%k0,%k0
 1f805b9:	kandw  %k0,%k3,%k0
 1f805bd:	korw   %k0,%k2,%k2
 1f805c1:	vptestnmd %zmm6,%zmm12,%k0{%k2}
 1f805c7:	kandw  %k0,%k1,%k0
 1f805cb:	kmovd  %k0,%ecx
 1f805cf:	vptestmb %xmm1,%xmm1,%k0
 1f805d5:	andn   %eax,%ecx,%eax
 1f805da:	kmovd  %k0,%ecx
 1f805de:	andn   %ecx,%edx,%ecx
 1f805e3:	popcnt %eax,%eax
 1f805e7:	movzwl %cx,%ecx
 1f805ea:	add    %rax,%rbx
 1f805ed:	popcnt %ecx,%ecx
 1f805f1:	add    %rcx,%rbx
 1f805f4:	mov    %rbx,0x8(%rsp)
 1f805f9:	mov    0x28(%rsp),%rbp
 1f805fe:	jmp    1f80025 <node_facts_window_run+0x2c15>
 1f80603:	vmovdqu64 %zmm1,0x530(%rsp)
 1f8060e:	vmovdqu64 %zmm15,0x5b0(%rsp)
 1f80619:	vmovdqu64 %zmm14,0x450(%rsp)
 1f80624:	vmovdqu64 %zmm13,0x2d0(%rsp)
 1f8062f:	vmovdqu64 %zmm2,0x220(%rsp)
 1f8063a:	vmovdqu64 %zmm12,0x310(%rsp)
 1f80645:	vmovdqu64 %zmm11,0x350(%rsp)
 1f80650:	vmovdqa %xmm3,0x390(%rsp)
 1f80659:	vmovdqu64 %zmm5,0x290(%rsp)
 1f80664:	kmovw  %k2,0x160(%rsp)
 1f8066d:	vmovdqu64 %zmm4,0x1a0(%rsp)
 1f80678:	vmovdqa %xmm10,0x120(%rsp)
 1f80681:	kmovw  %k3,0x570(%rsp)
 1f8068a:	kandw  %k0,%k3,%k0
 1f8068e:	mov    0x48(%rsp),%rbx
 1f80693:	kmovd  %k0,%eax
 1f80697:	movzwl %ax,%r13d
 1f8069b:	xor    %eax,%eax
 1f8069d:	tzcnt  %r13d,%eax
 1f806a2:	mov    0x60(%r11),%edx
 1f806a6:	mov    0x20(%r11),%rcx
 1f806aa:	add    %r15,%rax
 1f806ad:	mov    (%r12,%rax,4),%r9d
 1f806b1:	mov    (%r14,%rax,4),%esi
 1f806b5:	shl    $0x6,%rax
 1f806b9:	mov    (%r8,%rax,1),%eax
 1f806bd:	mov    %r9,0x1e0(%rsp)
 1f806c5:	shr    $0x3,%eax
 1f806c8:	cmp    %edx,%eax
 1f806ca:	cmovae %edx,%eax
 1f806cd:	shl    $0x6,%rax
 1f806d1:	mov    0x30(%rcx,%rax,1),%edx
 1f806d5:	mov    0x9c8(%rdi),%rax
 1f806dc:	cmpb   $0x1,(%rax,%r9,1)
 1f806e1:	adc    $0x0,%rbx
 1f806e5:	and    $0x1,%edx
 1f806e8:	vzeroupper
 1f806eb:	call   1f93960 <node_tests_window_line>
 1f806f0:	mov    0x10(%rsp),%rdi
 1f806f5:	mov    0x20(%rsp),%r8
 1f806fa:	mov    (%rsp),%r11
 1f806fe:	mov    0x1e0(%rsp),%rdx
 1f80706:	or     $0x1,%al
 1f80708:	blsr   %r13d,%r13d
 1f8070d:	mov    0x9c8(%rdi),%rcx
 1f80714:	mov    %al,(%rcx,%rdx,1)
 1f80717:	jne    1f8069b <node_facts_window_run+0x328b>
 1f80719:	mov    %rbx,0x48(%rsp)
 1f8071e:	mov    0x9c8(%rdi),%rax
 1f80725:	vpbroadcastd -0x19af7b3(%rip),%zmm6        # 5d0f7c <.LCPI3_5>
 1f8072f:	vpbroadcastb -0x1ac99f6(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f80738:	vpbroadcastd -0x19af7be(%rip),%zmm8        # 5d0f84 <.LCPI3_11>
 1f80742:	vpbroadcastd -0x19af7c0(%rip),%zmm9        # 5d0f8c <.LCPI3_13>
 1f8074c:	vpxor  %xmm0,%xmm0,%xmm0
 1f80750:	vmovdqu64 0x530(%rsp),%zmm1
 1f8075b:	kmovw  0x570(%rsp),%k1
 1f80764:	vmovdqa 0x120(%rsp),%xmm10
 1f8076d:	vmovdqu64 0x1a0(%rsp),%zmm4
 1f80778:	vmovdqu64 0x290(%rsp),%zmm5
 1f80783:	vmovdqa 0x390(%rsp),%xmm3
 1f8078c:	vmovdqu64 0x350(%rsp),%zmm11
 1f80797:	vmovdqu64 0x310(%rsp),%zmm12
 1f807a2:	vmovdqu64 0x220(%rsp),%zmm2
 1f807ad:	vmovdqu64 0x2d0(%rsp),%zmm13
 1f807b8:	vmovdqu64 0x450(%rsp),%zmm14
 1f807c3:	vmovdqu64 0x5b0(%rsp),%zmm15
 1f807ce:	mov    0x40(%rsp),%r9
 1f807d3:	mov    0x18(%rsp),%rsi
 1f807d8:	mov    0x3d0(%rsp),%r10
 1f807e0:	kmovw  0x160(%rsp),%k2
 1f807e9:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f807f0:	jmp    1f80167 <node_facts_window_run+0x2d57>
 1f807f5:	movq   $0x0,0x48(%rsp)
 1f807fe:	movq   $0x0,0x38(%rsp)
 1f80807:	movq   $0x0,0x8(%rsp)
 1f80810:	mov    0x48(%rsp),%rax
 1f80815:	mov    0x38(%rsp),%rcx
 1f8081a:	lea    0x7e8(%r9),%rsi
 1f80821:	add    %rax,0xa90(%r9)
 1f80828:	mov    0x950(%rdi),%rax
 1f8082f:	add    %rcx,0x868(%rax)
 1f80836:	mov    0x8(%rsp),%rcx
 1f8083b:	mov    0x950(%rdi),%rax
 1f80842:	add    %rcx,0x870(%rax)
 1f80849:	rdtsc
 1f8084b:	mov    0x8(%rbp),%ecx
 1f8084e:	cmpq   $0x0,0xc20(%r11)
 1f80856:	mov    %rax,0x720(%rsp)
 1f8085e:	mov    %rdx,0x430(%rsp)
 1f80866:	je     1f80f75 <node_facts_window_run+0x3b65>
 1f8086c:	cmpb   $0x1,0xd58(%r11)
 1f80874:	jne    1f80f75 <node_facts_window_run+0x3b65>
 1f8087a:	mov    0x950(%rdi),%rdx
 1f80881:	cmpq   $0x0,0x1a0(%rdx)
 1f80889:	sete   %dl
 1f8088c:	test   %rcx,%rcx
 1f8088f:	je     1f8162c <node_facts_window_run+0x421c>
 1f80895:	vpbroadcastb %edx,%zmm1
 1f8089b:	vgf2p8affineqb $0x0,-0x19b22fe(%rip){1to8},%zmm1,%zmm1        # 5ce5a8 <.LCPI3_90>
 1f808a6:	vmovdqu64 0x288(%rdi),%zmm0
 1f808b0:	vbroadcasti32x4 -0x19b8aaa(%rip),%zmm2        # 5c7e10 <.LCPI3_91>
 1f808ba:	vmovdqa64 -0x1aca004(%rip),%zmm8        # 4b68c0 <abi_test_hex.digits+0xb540>
 1f808c4:	vbroadcasti32x4 -0x19b8aae(%rip),%zmm10        # 5c7e20 <.LCPI3_92>
 1f808ce:	vpbroadcastq -0x19b2368(%rip),%zmm12        # 5ce570 <.LCPI3_50>
 1f808d8:	vbroadcasti32x4 -0x19b8ab2(%rip),%zmm19        # 5c7e30 <.LCPI3_93>
 1f808e2:	vbroadcasti32x4 -0x19b8aac(%rip),%zmm20        # 5c7e40 <.LCPI3_94>
 1f808ec:	vbroadcasti32x4 -0x19b8bf6(%rip),%zmm22        # 5c7d00 <.LCPI3_9>
 1f808f6:	vbroadcasti32x4 -0x19b8ab0(%rip),%zmm29        # 5c7e50 <.LCPI3_95>
 1f80900:	vbroadcasti32x4 -0x19b8aaa(%rip),%zmm30        # 5c7e60 <.LCPI3_96>
 1f8090a:	vmovdqa64 -0x1ac9cd4(%rip),%zmm31        # 4b6c40 <abi_test_hex.digits+0xb8c0>
 1f80914:	vmovdqa64 -0x1ac9c9e(%rip),%zmm3        # 4b6c80 <abi_test_hex.digits+0xb900>
 1f8091e:	vpbroadcastq -0x19b23c8(%rip),%zmm28        # 5ce560 <.LCPI3_47>
 1f80928:	mov    %rsi,0x18(%rsp)
 1f8092d:	movzbl 0x348(%rdi),%esi
 1f80934:	mov    0xd60(%r11),%rax
 1f8093b:	mov    0xd78(%r11),%r8
 1f80942:	xor    %r9d,%r9d
 1f80945:	vpxor  %xmm6,%xmm6,%xmm6
 1f80949:	vpxord %xmm25,%xmm25,%xmm25
 1f8094f:	xor    %edx,%edx
 1f80951:	vpxord %xmm18,%xmm18,%xmm18
 1f80957:	vpxor  %xmm11,%xmm11,%xmm11
 1f8095c:	vpxord %xmm27,%xmm27,%xmm27
 1f80962:	neg    %rsi
 1f80965:	mov    %rax,0x8(%rsp)
 1f8096a:	mov    %r8,0x20(%rsp)
 1f8096f:	movq   $0x0,0x30(%rsp)
 1f80978:	nopl   0x0(%rax,%rax,1)
 1f80980:	vmovdqu64 0x2c(%rbp,%r9,1),%zmm4
 1f8098b:	mov    0x990(%rdi),%r10
 1f80992:	vmovdqa64 %zmm27,%zmm9
 1f80998:	vmovdqa64 %zmm6,%zmm27
 1f8099e:	vmovdqu64 0x108(%rdi),%zmm6
 1f809a8:	vmovdqu64 0x88(%rdi),%zmm5
 1f809b2:	vmovdqu64 0x188(%rdi),%zmm21
 1f809bc:	vmovdqu64 0x208(%rdi),%zmm23
 1f809c6:	vmovdqa64 %zmm25,%zmm7
 1f809cc:	mov    0x8(%rsp),%rax
 1f809d1:	vmovdqu64 (%r10,%r9,1),%zmm13
 1f809d8:	mov    0x998(%rdi),%r10
 1f809df:	vpermt2b 0x148(%rdi),%zmm4,%zmm6
 1f809e9:	vpermt2b 0xc8(%rdi),%zmm4,%zmm5
 1f809f3:	vpermt2b 0x248(%rdi),%zmm4,%zmm23
 1f809fd:	vpandq %zmm2,%zmm4,%zmm16
 1f80a03:	vpermt2b 0x1c8(%rdi),%zmm4,%zmm21
 1f80a0d:	vmovdqu64 (%r10,%r9,1),%zmm4
 1f80a14:	mov    0x9a0(%rdi),%r10
 1f80a1b:	vpandq -0x19b24e5(%rip){1to8},%zmm4,%zmm25        # 5ce540 <.LCPI3_42>
 1f80a25:	vpsrlw $0x2,%zmm13,%zmm14
 1f80a2c:	vpsrlw $0x3,%zmm13,%zmm15
 1f80a33:	vpternlogq $0xf8,-0x19b24f6(%rip){1to8},%zmm6,%zmm25        # 5ce548 <.LCPI3_43>
 1f80a3e:	vpmovb2m %zmm5,%k0
 1f80a44:	vpternlogq $0xf8,-0x19b24ff(%rip){1to8},%zmm14,%zmm25        # 5ce550 <.LCPI3_44>
 1f80a4f:	kmovq  %k0,%r11
 1f80a54:	vpternlogq $0xf8,-0x19b2507(%rip){1to8},%zmm15,%zmm25        # 5ce558 <.LCPI3_45>
 1f80a5f:	vmovdqu64 %zmm25,(%r10,%r9,1)
 1f80a66:	vmovdqu64 0x6b554(%rbp,%r9,2),%zmm15
 1f80a71:	vmovdqu64 0x6b594(%rbp,%r9,2),%zmm17
 1f80a7c:	vmovdqu64 0x6d614(%rbp,%r9,2),%zmm24
 1f80a87:	vpmovuswb %zmm15,%ymm15
 1f80a8d:	vpmovuswb %zmm17,%ymm17
 1f80a93:	vpmovuswb %zmm24,%ymm24
 1f80a99:	vinserti64x4 $0x1,%ymm17,%zmm15,%zmm15
 1f80aa0:	vptestmb %zmm15,%zmm15,%k1
 1f80aa6:	vpsubb %zmm15,%zmm8,%zmm17
 1f80aac:	vpcmpltub %zmm15,%zmm8,%k4{%k1}
 1f80ab3:	kmovq  %k1,%r10
 1f80ab8:	vpcmpnltub %zmm15,%zmm8,%k1
 1f80abf:	vmovdqu64 0x6d5d4(%rbp,%r9,2),%zmm15
 1f80aca:	kmovq  %k1,%r14
 1f80acf:	and    %r10,%r14
 1f80ad2:	mov    0x9a8(%rdi),%r10
 1f80ad9:	kmovq  %r14,%k1
 1f80ade:	vpermt2b %zmm6,%zmm17,%zmm27{%k1}{z}
 1f80ae4:	knotq  %k1,%k6
 1f80ae9:	vpmovuswb %zmm15,%ymm15
 1f80aef:	vpsllw $0x2,%zmm27,%zmm27
 1f80af6:	vpandq %zmm27,%zmm6,%zmm27
 1f80afc:	vptestmb %zmm28,%zmm27,%k5
 1f80b02:	kmovq  %k5,%rbx
 1f80b07:	vinserti64x4 $0x1,%ymm24,%zmm15,%zmm26
 1f80b0e:	vmovdqa64 %zmm7,%zmm15
 1f80b14:	vpermt2b %zmm25,%zmm17,%zmm15{%k1}{z}
 1f80b1a:	vptestmb %zmm26,%zmm26,%k2
 1f80b20:	vpsubb %zmm26,%zmm8,%zmm24
 1f80b26:	vpcmpltub %zmm26,%zmm8,%k3{%k2}
 1f80b2d:	vpcmpnltub %zmm26,%zmm8,%k2{%k2}
 1f80b34:	vpermt2b %zmm25,%zmm24,%zmm7{%k2}{z}
 1f80b3a:	vporq  %zmm15,%zmm7,%zmm26
 1f80b40:	vmovdqu64 %zmm26,(%r10,%r9,1)
 1f80b47:	mov    %r9,%r10
 1f80b4a:	shr    $0x3,%r10
 1f80b4e:	kortestq %k4,%k3
 1f80b53:	vpandq (%rax,%r9,1),%zmm1,%zmm27
 1f80b5a:	mov    0x20(%rsp),%rax
 1f80b5f:	vpermt2b %zmm27,%zmm17,%zmm9
 1f80b65:	vptestnmb %zmm9,%zmm9,%k5
 1f80b6b:	korq   %k5,%k6,%k5
 1f80b70:	vpcmpeqb %zmm10,%zmm16,%k5{%k5}
 1f80b76:	kmovq  %k5,(%rax,%r10,1)
 1f80b7c:	jne    1f80e2c <node_facts_window_run+0x3a1c>
 1f80b82:	vmovdqa64 %zmm18,%zmm9
 1f80b88:	vpermi2b %zmm4,%zmm18,%zmm24{%k2}{z}
 1f80b8e:	vpermt2b %zmm4,%zmm17,%zmm9{%k1}{z}
 1f80b94:	vpternlogq $0xe0,%zmm2,%zmm4,%zmm23
 1f80b9b:	vpcmpeqb %zmm10,%zmm16,%k5
 1f80ba1:	mov    0x10(%rsp),%r8
 1f80ba6:	mov    %edx,%edi
 1f80ba8:	kmovq  %k5,%rax
 1f80bad:	vpcmpeqb -0x1aca077(%rip),%zmm16,%k5        # 4b6b40 <abi_test_hex.digits+0xb7c0>
 1f80bb7:	and    %rsi,%rax
 1f80bba:	vpsrlw $0x3,%zmm9,%zmm18
 1f80bc1:	vpternlogq $0xe4,-0x19b2634(%rip){1to8},%zmm24,%zmm18        # 5ce598 <.LCPI3_55>
 1f80bcc:	mov    0x9b0(%r8),%r13
 1f80bd3:	vpermb %zmm0,%zmm18,%zmm18
 1f80bd9:	vptestmb %zmm18,%zmm23,%k2
 1f80bdf:	vpandq %zmm19,%zmm9,%zmm18
 1f80be5:	vpandd -0x19afc23(%rip){1to16},%zmm9,%zmm9        # 5d0fcc <.LCPI3_84>
 1f80bef:	vpcmpeqb %zmm20,%zmm18,%k3
 1f80bf5:	vpandq %zmm26,%zmm21,%zmm18
 1f80bfb:	kmovq  %k2,%r12
 1f80c00:	vpcmpeqb -0x1aca2ca(%rip),%zmm18,%k2        # 4b6940 <abi_test_hex.digits+0xb5c0>
 1f80c0a:	vpandq %zmm19,%zmm24,%zmm21
 1f80c10:	vpcmpeqb %zmm20,%zmm21,%k4
 1f80c16:	vpandd -0x19afc4c(%rip){1to16},%zmm13,%zmm21        # 5d0fd4 <.LCPI3_88>
 1f80c20:	kmovq  %k2,%r10
 1f80c25:	korq   %k4,%k3,%k2
 1f80c2a:	vpcmpeqb -0x1aca234(%rip),%zmm16,%k2{%k2}        # 4b6a00 <abi_test_hex.digits+0xb680>
 1f80c34:	vptestmb %zmm18,%zmm18,%k4
 1f80c3a:	vpternlogq $0xfe,%zmm9,%zmm18,%zmm21
 1f80c41:	vpsllw $0x7,%zmm13,%zmm9
 1f80c48:	andn   %r10,%r11,%r10
 1f80c4d:	knotq  %k2,%k2
 1f80c52:	kmovq  %k2,%rbp
 1f80c57:	vptestmb %zmm22,%zmm13,%k2
 1f80c5d:	kmovq  %k2,%r15
 1f80c62:	vptestnmb %zmm21,%zmm21,%k2
 1f80c68:	and    %r12,%rbp
 1f80c6b:	and    %r15,%rax
 1f80c6e:	kmovq  %k2,%r15
 1f80c73:	vpmovb2m %zmm9,%k2
 1f80c79:	vpbroadcastw %r9d,%zmm9
 1f80c7f:	and    %r10,%rbp
 1f80c82:	and    %rax,%r15
 1f80c85:	and    %r14,%r15
 1f80c88:	kmovq  %r15,%k3
 1f80c8d:	vpmovm2b %k3,%zmm16
 1f80c93:	vpermt2b %zmm16,%zmm17,%zmm11
 1f80c99:	vptestmb -0x1aca123(%rip),%zmm13,%k3{%k4}        # 4b6b80 <abi_test_hex.digits+0xb800>
 1f80ca3:	vpaddw %zmm13,%zmm13,%zmm17
 1f80ca9:	vpandq -0x19b274b(%rip){1to8},%zmm17,%zmm17        # 5ce568 <.LCPI3_49>
 1f80cb3:	vpandq %zmm5,%zmm13,%zmm13
 1f80cb9:	vpternlogq $0xf8,-0x19b274c(%rip){1to8},%zmm5,%zmm17        # 5ce578 <.LCPI3_51>
 1f80cc4:	vpaddw %zmm13,%zmm13,%zmm13
 1f80cca:	vpternlogq $0xf8,-0x19b2755(%rip){1to8},%zmm14,%zmm17        # 5ce580 <.LCPI3_52>
 1f80cd5:	vpternlogq $0xf8,-0x19b2758(%rip){1to8},%zmm13,%zmm17        # 5ce588 <.LCPI3_53>
 1f80ce0:	vpsllw $0x3,%zmm4,%zmm13
 1f80ce7:	vpternlogq $0xf8,-0x19b2762(%rip){1to8},%zmm13,%zmm17        # 5ce590 <.LCPI3_54>
 1f80cf2:	vpsllw $0x4,%zmm4,%zmm13
 1f80cf9:	vptestmb %zmm11,%zmm11,%k1{%k1}
 1f80cff:	vporq  %zmm3,%zmm9,%zmm11
 1f80d05:	vporq  %zmm31,%zmm9,%zmm9
 1f80d0b:	kandq  %k3,%k5,%k3
 1f80d10:	kandq  %k2,%k5,%k5
 1f80d15:	kandq  %k1,%k5,%k1
 1f80d1a:	kshiftrq $0x20,%k1,%k5
 1f80d20:	vpcompressw %zmm9,%zmm9{%k1}{z}
 1f80d26:	kmovd  %k1,%eax
 1f80d2a:	korq   %k4,%k0,%k1
 1f80d2f:	vptestmb %zmm29,%zmm15,%k4
 1f80d35:	vptestmb %zmm22,%zmm5,%k4{%k4}
 1f80d3b:	vpternlogq $0xf8,%zmm12,%zmm13,%zmm17
 1f80d42:	vpcompressw %zmm11,%zmm11{%k5}{z}
 1f80d48:	kmovd  %k5,%r14d
 1f80d4c:	vmovdqu64 %zmm17,0x0(%r13,%r9,1)
 1f80d54:	mov    0x9c0(%r8),%r13
 1f80d5b:	vptestmb %zmm29,%zmm7,%k4{%k4}
 1f80d61:	vpandq %zmm26,%zmm5,%zmm7
 1f80d67:	vmovdqu64 %zmm9,0x0(%r13,%rdi,2)
 1f80d6f:	popcnt %eax,%r13d
 1f80d74:	mov    0x9c0(%r8),%rax
 1f80d7b:	add    %edx,%r13d
 1f80d7e:	vptestnmb %zmm30,%zmm18,%k0{%k4}
 1f80d84:	vmovdqa64 %zmm4,%zmm18
 1f80d8a:	vmovdqu64 %zmm11,(%rax,%r13,2)
 1f80d91:	kmovq  %k1,%rax
 1f80d96:	vptestmb %zmm12,%zmm7,%k1
 1f80d9c:	vmovdqa64 %zmm16,%zmm11
 1f80da2:	kmovq  %k1,%rdx
 1f80da7:	mov    0x9b8(%r8),%r10
 1f80dae:	korq   %k3,%k0,%k1
 1f80db3:	or     %rbx,%rdx
 1f80db6:	kmovq  %k1,%rdi
 1f80dbb:	vptestmb -0x1aca2c5(%rip),%zmm5,%k1        # 4b6b00 <abi_test_hex.digits+0xb780>
 1f80dc5:	or     %rbp,%rdi
 1f80dc8:	mov    0x28(%rsp),%rbp
 1f80dcd:	or     %r15,%rdi
 1f80dd0:	andn   %rax,%rdi,%rax
 1f80dd5:	mov    %rdx,0x8(%r10,%r9,1)
 1f80dda:	mov    %rdi,(%r10,%r9,1)
 1f80dde:	popcnt %r14d,%edx
 1f80de3:	mov    %r8,%rdi
 1f80de6:	mov    %rax,0x10(%r10,%r9,1)
 1f80deb:	add    %r13d,%edx
 1f80dee:	kmovq  %k1,0x18(%r10,%r9,1)
 1f80df5:	korq   %k2,%k1,%k1
 1f80dfa:	kmovq  %k1,%rax
 1f80dff:	or     %r15,%rax
 1f80e02:	mov    %rax,0x20(%r10,%r9,1)
 1f80e07:	mov    %r15,0x28(%r10,%r9,1)
 1f80e0c:	kmovq  %k3,0x30(%r10,%r9,1)
 1f80e13:	kmovq  %k0,0x38(%r10,%r9,1)
 1f80e1a:	add    $0x40,%r9
 1f80e1e:	cmp    %rcx,%r9
 1f80e21:	jb     1f80980 <node_facts_window_run+0x3570>
 1f80e27:	jmp    1f8170b <node_facts_window_run+0x42fb>
 1f80e2c:	kmovq  %k4,%rax
 1f80e31:	mov    %rax,0x120(%rsp)
 1f80e39:	mov    %rax,%rbp
 1f80e3c:	mov    0x28(%rsp),%r8
 1f80e41:	mov    0x10(%rsp),%rdi
 1f80e46:	test   %rax,%rax
 1f80e49:	je     1f80f01 <node_facts_window_run+0x3af1>
 1f80e4f:	xor    %eax,%eax
 1f80e51:	tzcnt  %rbp,%rax
 1f80e56:	mov    0x9a8(%rdi),%r10
 1f80e5d:	lea    (%rax,%r9,1),%r13
 1f80e61:	mov    %rax,0x38(%rsp)
 1f80e66:	mov    %r13d,%r15d
 1f80e69:	movzwl 0x6b554(%r8,%r15,2),%eax
 1f80e72:	mov    %r13d,%r12d
 1f80e75:	sub    %eax,%r12d
 1f80e78:	mov    0x9a0(%rdi),%rax
 1f80e7f:	movzbl (%rax,%r12,1),%eax
 1f80e84:	or     %al,(%r10,%r15,1)
 1f80e88:	movzbl 0x2c(%r8,%r12,1),%r10d
 1f80e8e:	movzbl 0x2c(%r8,%r15,1),%eax
 1f80e94:	and    $0x7f,%r10d
 1f80e98:	and    $0x7f,%eax
 1f80e9b:	movzbl 0x108(%rdi,%r10,1),%r15d
 1f80ea4:	movzbl 0x108(%rdi,%rax,1),%eax
 1f80eac:	shl    $0x2,%r15d
 1f80eb0:	and    %eax,%r15d
 1f80eb3:	xor    %eax,%eax
 1f80eb5:	test   $0xc,%r15b
 1f80eb9:	mov    0x38(%rsp),%r15
 1f80ebe:	setne  %al
 1f80ec1:	shlx   %r15,%rax,%rax
 1f80ec6:	mov    0x9b8(%rdi),%r15
 1f80ecd:	or     %rax,%rbx
 1f80ed0:	cmp    %r13d,%ecx
 1f80ed3:	seta   %al
 1f80ed6:	cmp    $0x22,%r10
 1f80eda:	sete   %r10b
 1f80ede:	and    %al,%r10b
 1f80ee1:	movzbl %r10b,%eax
 1f80ee5:	shlx   %r12,%rax,%rax
 1f80eea:	and    $0xffffffc0,%r12d
 1f80eee:	not    %rax
 1f80ef1:	and    %rax,0x20(%r15,%r12,1)
 1f80ef6:	blsr   %rbp,%rbp
 1f80efb:	jne    1f80e4f <node_facts_window_run+0x3a3f>
 1f80f01:	kmovq  %k3,%r10
 1f80f06:	mov    %r10,%r12
 1f80f09:	test   %r10,%r10
 1f80f0c:	je     1f80f46 <node_facts_window_run+0x3b36>
 1f80f0e:	xor    %eax,%eax
 1f80f10:	tzcnt  %r12,%rax
 1f80f15:	mov    0x9a0(%rdi),%r13
 1f80f1c:	or     %r9,%rax
 1f80f1f:	mov    %eax,%r15d
 1f80f22:	movzwl 0x6d5d4(%r8,%r15,2),%ebp
 1f80f2b:	sub    %ebp,%eax
 1f80f2d:	mov    0x9a8(%rdi),%rbp
 1f80f34:	movzbl 0x0(%r13,%rax,1),%eax
 1f80f3a:	or     %al,0x0(%rbp,%r15,1)
 1f80f3f:	blsr   %r12,%r12
 1f80f44:	jne    1f80f0e <node_facts_window_run+0x3afe>
 1f80f46:	mov    0x9a8(%rdi),%rdi
 1f80f4d:	popcnt 0x120(%rsp),%rax
 1f80f57:	popcnt %r10,%r10
 1f80f5c:	add    0x30(%rsp),%rax
 1f80f61:	vmovdqu64 (%rdi,%r9,1),%zmm26
 1f80f68:	add    %r10,%rax
 1f80f6b:	mov    %rax,0x30(%rsp)
 1f80f70:	jmp    1f80b82 <node_facts_window_run+0x3772>
 1f80f75:	test   %rcx,%rcx
 1f80f78:	je     1f8162c <node_facts_window_run+0x421c>
 1f80f7e:	vmovdqu64 0x288(%rdi),%zmm0
 1f80f88:	vbroadcasti32x4 -0x19b9182(%rip),%zmm1        # 5c7e10 <.LCPI3_91>
 1f80f92:	vmovdqa64 -0x1aca6dc(%rip),%zmm7        # 4b68c0 <abi_test_hex.digits+0xb540>
 1f80f9c:	vpbroadcastq -0x19b2a36(%rip),%zmm10        # 5ce570 <.LCPI3_50>
 1f80fa6:	vbroadcasti32x4 -0x19b9180(%rip),%zmm17        # 5c7e30 <.LCPI3_93>
 1f80fb0:	vbroadcasti32x4 -0x19b917a(%rip),%zmm18        # 5c7e40 <.LCPI3_94>
 1f80fba:	vbroadcasti32x4 -0x19b92c4(%rip),%zmm21        # 5c7d00 <.LCPI3_9>
 1f80fc4:	vbroadcasti32x4 -0x19b929e(%rip),%zmm25        # 5c7d30 <.LCPI3_24>
 1f80fce:	vbroadcasti32x4 -0x19b9168(%rip),%zmm26        # 5c7e70 <.LCPI3_97>
 1f80fd8:	vbroadcasti32x4 -0x19b9162(%rip),%zmm27        # 5c7e80 <.LCPI3_98>
 1f80fe2:	vbroadcasti32x4 -0x19b919c(%rip),%zmm28        # 5c7e50 <.LCPI3_95>
 1f80fec:	vbroadcasti32x4 -0x19b9196(%rip),%zmm29        # 5c7e60 <.LCPI3_96>
 1f80ff6:	vmovdqa64 -0x1aca3c0(%rip),%zmm30        # 4b6c40 <abi_test_hex.digits+0xb8c0>
 1f81000:	vmovdqa64 -0x1aca38a(%rip),%zmm31        # 4b6c80 <abi_test_hex.digits+0xb900>
 1f8100a:	vpbroadcastq -0x19b2ab4(%rip),%zmm24        # 5ce560 <.LCPI3_47>
 1f81014:	movzbl 0x348(%rdi),%eax
 1f8101b:	mov    %rsi,0x18(%rsp)
 1f81020:	xor    %edx,%edx
 1f81022:	vpxord %xmm22,%xmm22,%xmm22
 1f81028:	vpxord %xmm23,%xmm23,%xmm23
 1f8102e:	xor    %esi,%esi
 1f81030:	xor    %r8d,%r8d
 1f81033:	vpxor  %xmm14,%xmm14,%xmm14
 1f81038:	vpxor  %xmm6,%xmm6,%xmm6
 1f8103c:	neg    %rax
 1f8103f:	mov    %rax,0x8(%rsp)
 1f81044:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81050:	vmovdqu64 0x2c(%rbp,%rsi,1),%zmm2
 1f8105b:	mov    0x990(%rdi),%rax
 1f81062:	vmovdqa64 %zmm22,%zmm5
 1f81068:	vmovdqu64 0x108(%rdi),%zmm22
 1f81072:	vmovdqu64 0x88(%rdi),%zmm3
 1f8107c:	vmovdqu64 0x188(%rdi),%zmm15
 1f81086:	vmovdqu64 0x208(%rdi),%zmm16
 1f81090:	vmovdqa64 %zmm23,%zmm11
 1f81096:	vmovdqu64 (%rax,%rsi,1),%zmm8
 1f8109d:	mov    0x998(%rdi),%rax
 1f810a4:	vpermt2b 0x148(%rdi),%zmm2,%zmm22
 1f810ae:	vpermt2b 0xc8(%rdi),%zmm2,%zmm3
 1f810b8:	vpandq %zmm1,%zmm2,%zmm12
 1f810be:	vpermt2b 0x248(%rdi),%zmm2,%zmm16
 1f810c8:	vpermt2b 0x1c8(%rdi),%zmm2,%zmm15
 1f810d2:	vmovdqu64 (%rax,%rsi,1),%zmm2
 1f810d9:	mov    0x9a0(%rdi),%rax
 1f810e0:	vpandq -0x19b2baa(%rip){1to8},%zmm2,%zmm23        # 5ce540 <.LCPI3_42>
 1f810ea:	vpsrlw $0x2,%zmm8,%zmm9
 1f810f1:	vpsrlw $0x3,%zmm8,%zmm4
 1f810f8:	vpternlogq $0xf8,-0x19b2bbb(%rip){1to8},%zmm22,%zmm23        # 5ce548 <.LCPI3_43>
 1f81103:	vpmovb2m %zmm3,%k0
 1f81109:	vpternlogq $0xf8,-0x19b2bc4(%rip){1to8},%zmm9,%zmm23        # 5ce550 <.LCPI3_44>
 1f81114:	kmovq  %k0,%r9
 1f81119:	vpternlogq $0xf8,-0x19b2bcc(%rip){1to8},%zmm4,%zmm23        # 5ce558 <.LCPI3_45>
 1f81124:	vmovdqu64 %zmm23,(%rax,%rsi,1)
 1f8112b:	vmovdqu64 0x6b554(%rbp,%rsi,2),%zmm4
 1f81136:	vmovdqu64 0x6b594(%rbp,%rsi,2),%zmm13
 1f81141:	vmovdqu64 0x6d614(%rbp,%rsi,2),%zmm19
 1f8114c:	vpmovuswb %zmm4,%ymm4
 1f81152:	vpmovuswb %zmm13,%ymm13
 1f81158:	vpmovuswb %zmm19,%ymm19
 1f8115e:	vinserti64x4 $0x1,%ymm13,%zmm4,%zmm4
 1f81165:	vptestmb %zmm4,%zmm4,%k1
 1f8116b:	vpsubb %zmm4,%zmm7,%zmm13
 1f81171:	vpcmpltub %zmm4,%zmm7,%k4{%k1}
 1f81178:	kmovq  %k1,%rax
 1f8117d:	vpcmpnltub %zmm4,%zmm7,%k1
 1f81184:	vmovdqu64 0x6d5d4(%rbp,%rsi,2),%zmm4
 1f8118f:	kmovq  %k1,%r11
 1f81194:	and    %rax,%r11
 1f81197:	mov    0x9a8(%rdi),%rax
 1f8119e:	kmovq  %r11,%k1
 1f811a3:	vpermt2b %zmm22,%zmm13,%zmm5{%k1}{z}
 1f811a9:	vpmovuswb %zmm4,%ymm4
 1f811af:	vpsllw $0x2,%zmm5,%zmm5
 1f811b6:	vpandq %zmm5,%zmm22,%zmm5
 1f811bc:	vptestmb %zmm24,%zmm5,%k5
 1f811c2:	kmovq  %k5,%r10
 1f811c7:	vinserti64x4 $0x1,%ymm19,%zmm4,%zmm20
 1f811ce:	vmovdqa64 %zmm11,%zmm4
 1f811d4:	vpermt2b %zmm23,%zmm13,%zmm4{%k1}{z}
 1f811da:	vptestmb %zmm20,%zmm20,%k2
 1f811e0:	vpsubb %zmm20,%zmm7,%zmm19
 1f811e6:	vpcmpltub %zmm20,%zmm7,%k3{%k2}
 1f811ed:	vpcmpnltub %zmm20,%zmm7,%k2{%k2}
 1f811f4:	vpermt2b %zmm23,%zmm19,%zmm11{%k2}{z}
 1f811fa:	kortestq %k4,%k3
 1f811ff:	vporq  %zmm4,%zmm11,%zmm20
 1f81205:	vmovdqu64 %zmm20,(%rax,%rsi,1)
 1f8120c:	jne    1f814b3 <node_facts_window_run+0x40a3>
 1f81212:	vmovdqa64 %zmm14,%zmm5
 1f81218:	vpermi2b %zmm2,%zmm14,%zmm19{%k2}{z}
 1f8121e:	vpermt2b %zmm2,%zmm13,%zmm5{%k1}{z}
 1f81224:	vpternlogq $0xe0,%zmm1,%zmm2,%zmm16
 1f8122b:	vpcmpeqb %zmm26,%zmm12,%k5
 1f81231:	mov    0x10(%rsp),%rdi
 1f81236:	mov    %edx,%ebp
 1f81238:	vpsrlw $0x3,%zmm5,%zmm14
 1f8123f:	vpternlogq $0xe4,-0x19b2cb2(%rip){1to8},%zmm19,%zmm14        # 5ce598 <.LCPI3_55>
 1f8124a:	mov    0x9b0(%rdi),%r13
 1f81251:	vpermb %zmm0,%zmm14,%zmm14
 1f81257:	vptestmb %zmm14,%zmm16,%k2
 1f8125d:	vpandq %zmm17,%zmm5,%zmm14
 1f81263:	vpandd -0x19b02a1(%rip){1to16},%zmm5,%zmm5        # 5d0fcc <.LCPI3_84>
 1f8126d:	vpcmpeqb %zmm18,%zmm14,%k3
 1f81273:	vpandq %zmm20,%zmm15,%zmm14
 1f81279:	kmovq  %k2,%r14
 1f8127e:	vpcmpeqb -0x1aca948(%rip),%zmm14,%k2        # 4b6940 <abi_test_hex.digits+0xb5c0>
 1f81288:	vpandq %zmm17,%zmm19,%zmm15
 1f8128e:	vpcmpeqb %zmm18,%zmm15,%k4
 1f81294:	vpandd -0x19b02ca(%rip){1to16},%zmm8,%zmm15        # 5d0fd4 <.LCPI3_88>
 1f8129e:	kmovq  %k2,%r12
 1f812a3:	korq   %k4,%k3,%k2
 1f812a8:	vpcmpeqb -0x1aca8b2(%rip),%zmm12,%k2{%k2}        # 4b6a00 <abi_test_hex.digits+0xb680>
 1f812b2:	vptestmb %zmm14,%zmm14,%k4
 1f812b8:	vpternlogq $0xfe,%zmm5,%zmm14,%zmm15
 1f812bf:	vpsllw $0x7,%zmm8,%zmm5
 1f812c6:	andn   %r12,%r9,%r9
 1f812cb:	knotq  %k2,%k2
 1f812d0:	kmovq  %k2,%r15
 1f812d5:	vpcmpeqb -0x1aca9df(%rip),%zmm12,%k2        # 4b6900 <abi_test_hex.digits+0xb580>
 1f812df:	and    %r14,%r15
 1f812e2:	and    %r9,%r15
 1f812e5:	kmovq  %k2,%rax
 1f812ea:	and    0x8(%rsp),%rax
 1f812ef:	vptestmb %zmm21,%zmm8,%k2
 1f812f5:	kmovq  %k2,%rbx
 1f812fa:	vptestnmb %zmm15,%zmm15,%k2
 1f81300:	and    %rbx,%rax
 1f81303:	kmovq  %k2,%rbx
 1f81308:	vpmovb2m %zmm5,%k2
 1f8130e:	vpbroadcastw %esi,%zmm5
 1f81314:	and    %rax,%rbx
 1f81317:	and    %r11,%rbx
 1f8131a:	kmovq  %rbx,%k3
 1f8131f:	vpmovm2b %k3,%zmm12
 1f81325:	vpermt2b %zmm12,%zmm13,%zmm6
 1f8132b:	vpaddw %zmm8,%zmm8,%zmm13
 1f81331:	vpandq -0x19b2dd3(%rip){1to8},%zmm13,%zmm13        # 5ce568 <.LCPI3_49>
 1f8133b:	vptestmb %zmm27,%zmm8,%k3{%k4}
 1f81341:	vpandq %zmm3,%zmm8,%zmm8
 1f81347:	vpternlogq $0xf8,-0x19b2dda(%rip){1to8},%zmm3,%zmm13        # 5ce578 <.LCPI3_51>
 1f81352:	vpaddw %zmm8,%zmm8,%zmm8
 1f81358:	vpternlogq $0xf8,-0x19b2de3(%rip){1to8},%zmm9,%zmm13        # 5ce580 <.LCPI3_52>
 1f81363:	vpternlogq $0xf8,-0x19b2de6(%rip){1to8},%zmm8,%zmm13        # 5ce588 <.LCPI3_53>
 1f8136e:	vpsllw $0x3,%zmm2,%zmm8
 1f81375:	vpternlogq $0xf8,-0x19b2df0(%rip){1to8},%zmm8,%zmm13        # 5ce590 <.LCPI3_54>
 1f81380:	vpsllw $0x4,%zmm2,%zmm8
 1f81387:	vptestmb %zmm6,%zmm6,%k1{%k1}
 1f8138d:	kandq  %k3,%k5,%k3
 1f81392:	kandq  %k2,%k5,%k5
 1f81397:	vporq  %zmm31,%zmm5,%zmm6
 1f8139d:	vporq  %zmm30,%zmm5,%zmm5
 1f813a3:	kandq  %k1,%k5,%k1
 1f813a8:	kshiftrq $0x20,%k1,%k5
 1f813ae:	vpcompressw %zmm5,%zmm5{%k1}{z}
 1f813b4:	kmovd  %k1,%eax
 1f813b8:	korq   %k4,%k0,%k1
 1f813bd:	vptestmb %zmm28,%zmm4,%k4
 1f813c3:	vpandq %zmm20,%zmm3,%zmm4
 1f813c9:	vptestmb %zmm21,%zmm3,%k4{%k4}
 1f813cf:	vpternlogq $0xf8,%zmm10,%zmm8,%zmm13
 1f813d6:	vpcompressw %zmm6,%zmm6{%k5}{z}
 1f813dc:	kmovd  %k5,%r11d
 1f813e0:	vmovdqu64 %zmm13,0x0(%r13,%rsi,1)
 1f813e8:	mov    0x9c0(%rdi),%r13
 1f813ef:	vptestmb %zmm28,%zmm11,%k4{%k4}
 1f813f5:	vmovdqu64 %zmm5,0x0(%r13,%rbp,2)
 1f813fd:	popcnt %eax,%r13d
 1f81402:	mov    0x9c0(%rdi),%rax
 1f81409:	add    %edx,%r13d
 1f8140c:	vptestnmb %zmm29,%zmm14,%k0{%k4}
 1f81412:	vmovdqa64 %zmm2,%zmm14
 1f81418:	vmovdqu64 %zmm6,(%rax,%r13,2)
 1f8141f:	kmovq  %k1,%rax
 1f81424:	vptestmb %zmm10,%zmm4,%k1
 1f8142a:	vmovdqa64 %zmm12,%zmm6
 1f81430:	mov    0x9b8(%rdi),%r9
 1f81437:	kmovq  %k1,%rdx
 1f8143c:	korq   %k3,%k0,%k1
 1f81441:	or     %r10,%rdx
 1f81444:	kmovq  %k1,%rbp
 1f81449:	vptestmb %zmm25,%zmm3,%k1
 1f8144f:	or     %r15,%rbp
 1f81452:	or     %rbx,%rbp
 1f81455:	mov    %rdx,0x8(%r9,%rsi,1)
 1f8145a:	mov    %rbp,(%r9,%rsi,1)
 1f8145e:	andn   %rax,%rbp,%rax
 1f81463:	mov    0x28(%rsp),%rbp
 1f81468:	popcnt %r11d,%edx
 1f8146d:	mov    %rax,0x10(%r9,%rsi,1)
 1f81472:	kmovq  %k1,0x18(%r9,%rsi,1)
 1f81479:	korq   %k2,%k1,%k1
 1f8147e:	add    %r13d,%edx
 1f81481:	kmovq  %k1,%rax
 1f81486:	or     %rbx,%rax
 1f81489:	mov    %rax,0x20(%r9,%rsi,1)
 1f8148e:	mov    %rbx,0x28(%r9,%rsi,1)
 1f81493:	kmovq  %k3,0x30(%r9,%rsi,1)
 1f8149a:	kmovq  %k0,0x38(%r9,%rsi,1)
 1f814a1:	add    $0x40,%rsi
 1f814a5:	cmp    %rcx,%rsi
 1f814a8:	jb     1f81050 <node_facts_window_run+0x3c40>
 1f814ae:	jmp    1f815ef <node_facts_window_run+0x41df>
 1f814b3:	kmovq  %k4,%rax
 1f814b8:	mov    %rax,0x20(%rsp)
 1f814bd:	mov    %rax,%r14
 1f814c0:	mov    0x10(%rsp),%rdi
 1f814c5:	test   %rax,%rax
 1f814c8:	je     1f8157f <node_facts_window_run+0x416f>
 1f814ce:	mov    0x28(%rsp),%rbx
 1f814d3:	xor    %r13d,%r13d
 1f814d6:	tzcnt  %r14,%r13
 1f814db:	lea    0x0(%r13,%rsi,1),%r12
 1f814e0:	mov    %r12d,%eax
 1f814e3:	mov    %r12d,%r15d
 1f814e6:	movzwl 0x6b554(%rbx,%rax,2),%ebp
 1f814ee:	mov    0x9a8(%rdi),%rbx
 1f814f5:	sub    %ebp,%r15d
 1f814f8:	mov    0x9a0(%rdi),%rbp
 1f814ff:	movzbl 0x0(%rbp,%r15,1),%ebp
 1f81505:	or     %bpl,(%rbx,%rax,1)
 1f81509:	mov    0x28(%rsp),%rbx
 1f8150e:	movzbl 0x2c(%rbx,%rax,1),%eax
 1f81513:	mov    0x28(%rsp),%rbx
 1f81518:	movzbl 0x2c(%rbx,%r15,1),%ebx
 1f8151e:	and    $0x7f,%eax
 1f81521:	movzbl 0x108(%rdi,%rax,1),%eax
 1f81529:	and    $0x7f,%ebx
 1f8152c:	movzbl 0x108(%rdi,%rbx,1),%ebp
 1f81534:	shl    $0x2,%ebp
 1f81537:	and    %eax,%ebp
 1f81539:	xor    %eax,%eax
 1f8153b:	test   $0xc,%bpl
 1f8153f:	setne  %al
 1f81542:	shlx   %r13,%rax,%rax
 1f81547:	or     %rax,%r10
 1f8154a:	cmp    %r12d,%ecx
 1f8154d:	mov    0x9b8(%rdi),%r12
 1f81554:	seta   %al
 1f81557:	cmp    $0x22,%rbx
 1f8155b:	sete   %bl
 1f8155e:	and    %al,%bl
 1f81560:	movzbl %bl,%eax
 1f81563:	shlx   %r15,%rax,%rax
 1f81568:	and    $0xffffffc0,%r15d
 1f8156c:	not    %rax
 1f8156f:	and    %rax,0x20(%r12,%r15,1)
 1f81574:	blsr   %r14,%r14
 1f81579:	jne    1f814ce <node_facts_window_run+0x40be>
 1f8157f:	kmovq  %k3,%r14
 1f81584:	mov    %r14,%r15
 1f81587:	test   %r14,%r14
 1f8158a:	je     1f815c7 <node_facts_window_run+0x41b7>
 1f8158c:	mov    0x28(%rsp),%r12
 1f81591:	xor    %eax,%eax
 1f81593:	tzcnt  %r15,%rax
 1f81598:	mov    0x9a8(%rdi),%r13
 1f8159f:	or     %rsi,%rax
 1f815a2:	mov    %eax,%ebx
 1f815a4:	movzwl 0x6d5d4(%r12,%rbx,2),%ebp
 1f815ad:	mov    0x9a0(%rdi),%r12
 1f815b4:	sub    %ebp,%eax
 1f815b6:	movzbl (%r12,%rax,1),%eax
 1f815bb:	or     %al,0x0(%r13,%rbx,1)
 1f815c0:	blsr   %r15,%r15
 1f815c5:	jne    1f8158c <node_facts_window_run+0x417c>
 1f815c7:	mov    0x9a8(%rdi),%rdi
 1f815ce:	popcnt 0x20(%rsp),%rax
 1f815d5:	popcnt %r14,%rbx
 1f815da:	vmovdqu64 (%rdi,%rsi,1),%zmm20
 1f815e1:	add    %r8,%rax
 1f815e4:	add    %rbx,%rax
 1f815e7:	mov    %rax,%r8
 1f815ea:	jmp    1f81212 <node_facts_window_run+0x3e02>
 1f815ef:	mov    0x40(%rsp),%r9
 1f815f4:	mov    %ecx,%eax
 1f815f6:	dec    %rcx
 1f815f9:	shr    $0x6,%rcx
 1f815fd:	inc    %rcx
 1f81600:	mov    %ecx,%r10d
 1f81603:	and    $0x7,%r10d
 1f81607:	add    %r8,0xa88(%r9)
 1f8160e:	mov    0x9b8(%rdi),%rsi
 1f81615:	cmp    $0x1c1,%eax
 1f8161a:	jae    1f81637 <node_facts_window_run+0x4227>
 1f8161c:	mov    (%rsp),%r11
 1f81620:	vpxor  %xmm0,%xmm0,%xmm0
 1f81624:	xor    %r8d,%r8d
 1f81627:	jmp    1f816d9 <node_facts_window_run+0x42c9>
 1f8162c:	xor    %edx,%edx
 1f8162e:	vpxor  %xmm0,%xmm0,%xmm0
 1f81632:	jmp    1f8180f <node_facts_window_run+0x43ff>
 1f81637:	and    $0xfffffffffffffff8,%rcx
 1f8163b:	vpxor  %xmm0,%xmm0,%xmm0
 1f8163f:	xor    %r8d,%r8d
 1f81642:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81650:	vpopcntq (%rsi,%r8,1),%zmm1
 1f81657:	vpopcntq 0x40(%rsi,%r8,1),%zmm3
 1f8165f:	vpopcntq 0x80(%rsi,%r8,1),%zmm2
 1f81667:	vpopcntq 0xc0(%rsi,%r8,1),%zmm4
 1f8166f:	vpaddq %zmm0,%zmm1,%zmm0
 1f81675:	vpaddq %zmm3,%zmm2,%zmm1
 1f8167b:	vpopcntq 0x100(%rsi,%r8,1),%zmm2
 1f81683:	vpopcntq 0x140(%rsi,%r8,1),%zmm3
 1f8168b:	vpaddq %zmm0,%zmm1,%zmm0
 1f81691:	vpaddq %zmm4,%zmm2,%zmm1
 1f81697:	vpopcntq 0x1c0(%rsi,%r8,1),%zmm2
 1f8169f:	vpaddq %zmm1,%zmm3,%zmm1
 1f816a5:	vpopcntq 0x180(%rsi,%r8,1),%zmm3
 1f816ad:	add    $0x200,%r8
 1f816b4:	add    $0xfffffffffffffff8,%rcx
 1f816b8:	vpaddq %zmm0,%zmm1,%zmm0
 1f816be:	vpaddq %zmm3,%zmm2,%zmm1
 1f816c4:	vpaddq %zmm0,%zmm1,%zmm0
 1f816ca:	jne    1f81650 <node_facts_window_run+0x4240>
 1f816cc:	mov    (%rsp),%r11
 1f816d0:	test   %r10,%r10
 1f816d3:	je     1f8180a <node_facts_window_run+0x43fa>
 1f816d9:	add    %r8,%rsi
 1f816dc:	shl    $0x6,%r10d
 1f816e0:	xor    %ecx,%ecx
 1f816e2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f816f0:	vpopcntq (%rsi,%rcx,1),%zmm1
 1f816f7:	add    $0x40,%rcx
 1f816fb:	vpaddq %zmm0,%zmm1,%zmm0
 1f81701:	cmp    %rcx,%r10
 1f81704:	jne    1f816f0 <node_facts_window_run+0x42e0>
 1f81706:	jmp    1f8180a <node_facts_window_run+0x43fa>
 1f8170b:	mov    0x40(%rsp),%r9
 1f81710:	mov    0x30(%rsp),%rax
 1f81715:	mov    %ecx,%r8d
 1f81718:	dec    %rcx
 1f8171b:	shr    $0x6,%rcx
 1f8171f:	inc    %rcx
 1f81722:	add    %rax,0xa88(%r9)
 1f81729:	mov    %ecx,%eax
 1f8172b:	and    $0x7,%eax
 1f8172e:	mov    0x9b8(%rdi),%rsi
 1f81735:	cmp    $0x1c1,%r8d
 1f8173c:	jae    1f8174a <node_facts_window_run+0x433a>
 1f8173e:	vpxor  %xmm0,%xmm0,%xmm0
 1f81742:	xor    %r8d,%r8d
 1f81745:	jmp    1f817e1 <node_facts_window_run+0x43d1>
 1f8174a:	and    $0xfffffffffffffff8,%rcx
 1f8174e:	vpxor  %xmm0,%xmm0,%xmm0
 1f81752:	xor    %r8d,%r8d
 1f81755:	data16 cs nopw 0x0(%rax,%rax,1)
 1f81760:	vpopcntq (%rsi,%r8,1),%zmm1
 1f81767:	vpopcntq 0x40(%rsi,%r8,1),%zmm3
 1f8176f:	vpopcntq 0x80(%rsi,%r8,1),%zmm2
 1f81777:	vpopcntq 0xc0(%rsi,%r8,1),%zmm4
 1f8177f:	vpaddq %zmm0,%zmm1,%zmm0
 1f81785:	vpaddq %zmm3,%zmm2,%zmm1
 1f8178b:	vpopcntq 0x100(%rsi,%r8,1),%zmm2
 1f81793:	vpopcntq 0x140(%rsi,%r8,1),%zmm3
 1f8179b:	vpaddq %zmm0,%zmm1,%zmm0
 1f817a1:	vpaddq %zmm4,%zmm2,%zmm1
 1f817a7:	vpopcntq 0x1c0(%rsi,%r8,1),%zmm2
 1f817af:	vpaddq %zmm1,%zmm3,%zmm1
 1f817b5:	vpopcntq 0x180(%rsi,%r8,1),%zmm3
 1f817bd:	add    $0x200,%r8
 1f817c4:	add    $0xfffffffffffffff8,%rcx
 1f817c8:	vpaddq %zmm0,%zmm1,%zmm0
 1f817ce:	vpaddq %zmm3,%zmm2,%zmm1
 1f817d4:	vpaddq %zmm0,%zmm1,%zmm0
 1f817da:	jne    1f81760 <node_facts_window_run+0x4350>
 1f817dc:	test   %rax,%rax
 1f817df:	je     1f81806 <node_facts_window_run+0x43f6>
 1f817e1:	add    %r8,%rsi
 1f817e4:	shl    $0x6,%eax
 1f817e7:	xor    %ecx,%ecx
 1f817e9:	nopl   0x0(%rax)
 1f817f0:	vpopcntq (%rsi,%rcx,1),%zmm1
 1f817f7:	add    $0x40,%rcx
 1f817fb:	vpaddq %zmm0,%zmm1,%zmm0
 1f81801:	cmp    %rcx,%rax
 1f81804:	jne    1f817f0 <node_facts_window_run+0x43e0>
 1f81806:	mov    (%rsp),%r11
 1f8180a:	mov    0x18(%rsp),%rsi
 1f8180f:	vextracti32x4 $0x3,%zmm0,%xmm1
 1f81816:	mov    $0x24,%al
 1f81818:	vpermq $0xff,%zmm0,%zmm2
 1f8181f:	vextracti64x4 $0x1,%zmm0,%ymm3
 1f81826:	movq   $0x0,0x220(%rsp)
 1f81832:	vpbroadcastq %xmm1,%xmm1
 1f81837:	kmovd  %eax,%k1
 1f8183b:	mov    $0x9,%al
 1f8183d:	vextracti32x4 $0x2,%zmm2,%xmm2
 1f81844:	vpblendd $0x3,%ymm0,%ymm3,%ymm0
 1f8184a:	vpaddq %xmm1,%xmm3,%xmm1
 1f8184e:	kmovd  %eax,%k2
 1f81852:	vmovdqu64 0x40(%rsi),%zmm4{%k1}{z}
 1f81859:	vpaddq %xmm2,%xmm1,%xmm1
 1f8185d:	vmovdqu64 (%rsi),%zmm2{%k2}{z}
 1f81863:	vpsrldq $0x8,%xmm1,%xmm1
 1f81868:	vpsubq %ymm1,%ymm0,%ymm0
 1f8186c:	vshufi64x2 $0x55,%zmm0,%zmm0,%zmm3
 1f81873:	vpermq $0x64,%ymm0,%ymm0
 1f81879:	vpaddq %zmm4,%zmm3,%zmm1
 1f8187f:	vpaddq %zmm2,%zmm0,%zmm0
 1f81885:	vmovdqu64 %zmm1,0x40(%rsi){%k1}
 1f8188c:	vmovdqu64 %zmm0,(%rsi){%k2}
 1f81892:	test   %edx,%edx
 1f81894:	je     1f81960 <node_facts_window_run+0x4550>
 1f8189a:	mov    $0x8,%ebp
 1f8189f:	mov    %edx,%r14d
 1f818a2:	xor    %r12d,%r12d
 1f818a5:	xor    %r13d,%r13d
 1f818a8:	xor    %r15d,%r15d
 1f818ab:	nopl   0x0(%rax,%rax,1)
 1f818b0:	mov    0x9c0(%rdi),%rax
 1f818b7:	mov    0x28(%rsp),%rsi
 1f818bc:	mov    0x9c8(%rdi),%rcx
 1f818c3:	movzwl (%rax,%r13,2),%ebx
 1f818c8:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f818d0:	sub    %eax,%ebx
 1f818d2:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f818da:	mov    %ebx,%edx
 1f818dc:	sub    %eax,%edx
 1f818de:	cmpb   $0x2,0x69454(%rsi,%rdx,1)
 1f818e6:	mov    0x757d4(%rsi,%rdx,4),%eax
 1f818ed:	cmovne %r12,%rax
 1f818f1:	movzbl (%rcx,%rax,1),%eax
 1f818f5:	cmovne %ebp,%eax
 1f818f8:	test   $0x8,%al
 1f818fa:	je     1f8190d <node_facts_window_run+0x44fd>
 1f818fc:	movzbl %al,%eax
 1f818ff:	test   $0x10,%al
 1f81901:	jne    1f81932 <node_facts_window_run+0x4522>
 1f81903:	inc    %r13
 1f81906:	cmp    %r13,%r14
 1f81909:	jne    1f818b0 <node_facts_window_run+0x44a0>
 1f8190b:	jmp    1f81959 <node_facts_window_run+0x4549>
 1f8190d:	mov    0x28(%rsp),%rsi
 1f81912:	vzeroupper
 1f81915:	call   1f93c30 <node_tests_window_wants>
 1f8191a:	mov    0x10(%rsp),%rdi
 1f8191f:	mov    0x40(%rsp),%r9
 1f81924:	mov    (%rsp),%r11
 1f81928:	movzbl %al,%eax
 1f8192b:	inc    %r15
 1f8192e:	test   $0x10,%al
 1f81930:	je     1f81903 <node_facts_window_run+0x44f3>
 1f81932:	mov    0x9b8(%rdi),%rdx
 1f81939:	mov    %ebx,%ecx
 1f8193b:	mov    $0xfffffffffffffffe,%rax
 1f81942:	and    $0xffffffc0,%ebx
 1f81945:	rol    %cl,%rax
 1f81948:	and    %rax,0x20(%rdx,%rbx,1)
 1f8194d:	inc    %r13
 1f81950:	cmp    %r13,%r14
 1f81953:	jne    1f818b0 <node_facts_window_run+0x44a0>
 1f81959:	mov    0x28(%rsp),%rbp
 1f8195e:	jmp    1f81966 <node_facts_window_run+0x4556>
 1f81960:	xor    %r14d,%r14d
 1f81963:	xor    %r15d,%r15d
 1f81966:	add    %r15,0x828(%r9)
 1f8196d:	rdtsc
 1f8196f:	add    %r14,0x820(%r9)
 1f81976:	cmpl   $0x0,0xa90(%r11)
 1f8197e:	mov    %rax,0x6e0(%rsp)
 1f81986:	mov    %rdx,0x410(%rsp)
 1f8198e:	mov    0x50(%rsp),%r13
 1f81993:	je     1f8289d <node_facts_window_run+0x548d>
 1f81999:	movzbl 0x68(%rsp),%eax
 1f8199e:	lea    0x42ec(%rbp),%rdx
 1f819a5:	mov    $0x40,%ebx
 1f819aa:	mov    $0xffffffffffffffff,%r14
 1f819b1:	xor    %r15d,%r15d
 1f819b4:	xor    %r12d,%r12d
 1f819b7:	mov    %eax,0x98(%rsp)
 1f819be:	movzbl 0x40(%rdi),%eax
 1f819c2:	shl    $0x1b,%rax
 1f819c6:	mov    %rax,0x48(%rsp)
 1f819cb:	mov    0xa8(%rsp),%rax
 1f819d3:	mov    (%rax),%rax
 1f819d6:	mov    0x6c8(%rax),%ecx
 1f819dc:	mov    0x6e8(%rax),%eax
 1f819e2:	mov    %ecx,0x80(%rsp)
 1f819e9:	mov    %eax,0x7c0(%rsp)
 1f819f0:	movzbl 0x3a(%rdi),%eax
 1f819f4:	lea    0x422c(%rbp),%rcx
 1f819fb:	mov    %eax,0x90(%rsp)
 1f81a02:	movzbl 0x3c(%rdi),%eax
 1f81a06:	mov    %eax,0x78(%rsp)
 1f81a0a:	mov    0xa0(%rsp),%eax
 1f81a11:	mov    %rdx,0x60(%rsp)
 1f81a16:	mov    %rcx,0xe0(%rsp)
 1f81a1e:	movq   $0x0,0x220(%rsp)
 1f81a2a:	vpbroadcastd %eax,%zmm3
 1f81a30:	jmp    1f81a57 <node_facts_window_run+0x4647>
 1f81a32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81a40:	movb   $0x0,0x61(%rdx)
 1f81a44:	mov    0xa90(%r11),%eax
 1f81a4b:	inc    %r15
 1f81a4e:	cmp    %rax,%r15
 1f81a51:	jae    1f8289d <node_facts_window_run+0x548d>
 1f81a57:	mov    0xa88(%r11),%rax
 1f81a5e:	imul   $0x68,%r15,%rdx
 1f81a62:	add    %r13,%rdx
 1f81a65:	cmpb   $0x0,(%rax,%r15,1)
 1f81a6a:	je     1f81a40 <node_facts_window_run+0x4630>
 1f81a6c:	mov    0xa50(%r11),%rax
 1f81a73:	mov    (%rax,%r15,4),%eax
 1f81a77:	cmp    0x20(%r9),%eax
 1f81a7b:	jae    1f81a40 <node_facts_window_run+0x4630>
 1f81a7d:	mov    0x18(%r9),%rcx
 1f81a81:	movzbl (%rcx,%rax,1),%eax
 1f81a85:	shr    $0x5,%al
 1f81a88:	and    $0x1,%al
 1f81a8a:	mov    %al,0x61(%rdx)
 1f81a8d:	je     1f81a44 <node_facts_window_run+0x4634>
 1f81a8f:	mov    0xa70(%r11),%rax
 1f81a96:	mov    0x9b0(%rdi),%rcx
 1f81a9d:	mov    (%rax,%r15,4),%r10d
 1f81aa1:	mov    0x651b8(%rbp,%r10,4),%ebp
 1f81aa9:	mov    %r10,0x290(%rsp)
 1f81ab1:	sub    %ebp,%r10d
 1f81ab4:	inc    %r10d
 1f81ab7:	mov    %r10d,%eax
 1f81aba:	mov    %rax,0x160(%rsp)
 1f81ac2:	mov    %rdx,0x2d0(%rsp)
 1f81aca:	test   %rbp,%rbp
 1f81acd:	je     1f81af2 <node_facts_window_run+0x46e2>
 1f81acf:	lea    -0x1(%rbp),%rdx
 1f81ad3:	shr    $0x6,%rdx
 1f81ad7:	inc    %rdx
 1f81ada:	mov    %edx,%eax
 1f81adc:	and    $0x7,%eax
 1f81adf:	cmp    $0x1c1,%ebp
 1f81ae5:	jae    1f81af9 <node_facts_window_run+0x46e9>
 1f81ae7:	vpxor  %xmm0,%xmm0,%xmm0
 1f81aeb:	xor    %esi,%esi
 1f81aed:	jmp    1f81c70 <node_facts_window_run+0x4860>
 1f81af2:	xor    %eax,%eax
 1f81af4:	jmp    1f81ce3 <node_facts_window_run+0x48d3>
 1f81af9:	movabs $0x7fffffffffffff8,%rsi
 1f81b03:	mov    %r10,0x38(%rsp)
 1f81b08:	vpxor  %xmm0,%xmm0,%xmm0
 1f81b0c:	and    %rsi,%rdx
 1f81b0f:	mov    0x160(%rsp),%rsi
 1f81b17:	lea    0x1c0(%rcx,%rsi,1),%rdi
 1f81b1f:	xor    %esi,%esi
 1f81b21:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81b30:	lea    0x0(%rbp,%rsi,1),%r9
 1f81b35:	mov    %r9d,%r8d
 1f81b38:	sub    $0x40,%r9
 1f81b3c:	shlx   %r8,%r14,%r8
 1f81b41:	not    %r8
 1f81b44:	mov    %r8,%r10
 1f81b47:	cmovae %r14,%r10
 1f81b4b:	cmp    $0x40,%r9
 1f81b4f:	shlx   %r9,%r14,%r9
 1f81b54:	not    %r9
 1f81b57:	kmovq  %r10,%k1
 1f81b5c:	cmovae %r14,%r9
 1f81b60:	vmovdqu8 -0x1c0(%rdi),%zmm1{%k1}{z}
 1f81b67:	kmovq  %r9,%k1
 1f81b6c:	lea    -0x80(%rbp,%rsi,1),%r9
 1f81b71:	vmovdqu8 -0x180(%rdi),%zmm2{%k1}{z}
 1f81b78:	cmp    $0x40,%r9
 1f81b7c:	mov    %r8,%r9
 1f81b7f:	cmovae %r14,%r9
 1f81b83:	kmovq  %r9,%k1
 1f81b88:	lea    -0xc0(%rbp,%rsi,1),%r9
 1f81b90:	cmp    $0x40,%r9
 1f81b94:	mov    %r8,%r9
 1f81b97:	cmovae %r14,%r9
 1f81b9b:	vpternlogq $0xfe,%zmm1,%zmm0,%zmm2
 1f81ba2:	vmovdqu8 -0x140(%rdi),%zmm0{%k1}{z}
 1f81ba9:	kmovq  %r9,%k1
 1f81bae:	lea    -0x100(%rbp,%rsi,1),%r9
 1f81bb6:	vmovdqu8 -0x100(%rdi),%zmm1{%k1}{z}
 1f81bbd:	cmp    $0x40,%r9
 1f81bc1:	mov    %r8,%r9
 1f81bc4:	cmovae %r14,%r9
 1f81bc8:	kmovq  %r9,%k1
 1f81bcd:	lea    -0x140(%rbp,%rsi,1),%r9
 1f81bd5:	cmp    $0x40,%r9
 1f81bd9:	mov    %r8,%r9
 1f81bdc:	cmovae %r14,%r9
 1f81be0:	vpternlogq $0xfe,%zmm0,%zmm2,%zmm1
 1f81be7:	vmovdqu8 -0xc0(%rdi),%zmm0{%k1}{z}
 1f81bee:	kmovq  %r9,%k1
 1f81bf3:	lea    -0x180(%rbp,%rsi,1),%r9
 1f81bfb:	vmovdqu8 -0x80(%rdi),%zmm2{%k1}{z}
 1f81c02:	cmp    $0x40,%r9
 1f81c06:	mov    %r8,%r9
 1f81c09:	cmovae %r14,%r9
 1f81c0d:	kmovq  %r9,%k1
 1f81c12:	lea    -0x1c0(%rbp,%rsi,1),%r9
 1f81c1a:	vmovdqu8 -0x40(%rdi),%zmm4{%k1}{z}
 1f81c21:	cmp    $0x40,%r9
 1f81c25:	cmovae %r14,%r8
 1f81c29:	add    $0xfffffffffffffe00,%rsi
 1f81c30:	kmovq  %r8,%k1
 1f81c35:	vpternlogq $0xfe,%zmm0,%zmm1,%zmm2
 1f81c3c:	vmovdqu8 (%rdi),%zmm0{%k1}{z}
 1f81c42:	add    $0x200,%rdi
 1f81c49:	add    $0xfffffffffffffff8,%rdx
 1f81c4d:	vpternlogq $0xfe,%zmm4,%zmm2,%zmm0
 1f81c54:	jne    1f81b30 <node_facts_window_run+0x4720>
 1f81c5a:	test   %rax,%rax
 1f81c5d:	je     1f82812 <node_facts_window_run+0x5402>
 1f81c63:	mov    0x10(%rsp),%rdi
 1f81c68:	mov    0x38(%rsp),%r10
 1f81c6d:	neg    %rsi
 1f81c70:	mov    0x160(%rsp),%r8
 1f81c78:	lea    (%rcx,%rsi,1),%rdx
 1f81c7c:	mov    %rbp,%r9
 1f81c7f:	sub    %rsi,%r9
 1f81c82:	shl    $0x6,%eax
 1f81c85:	xor    %esi,%esi
 1f81c87:	add    %r8,%rdx
 1f81c8a:	nopw   0x0(%rax,%rax,1)
 1f81c90:	mov    %r9d,%r8d
 1f81c93:	sub    $0x40,%r9
 1f81c97:	shlx   %r8,%r14,%r8
 1f81c9c:	not    %r8
 1f81c9f:	cmovae %r14,%r8
 1f81ca3:	kmovq  %r8,%k1
 1f81ca8:	vmovdqu8 (%rdx,%rsi,1),%zmm1{%k1}{z}
 1f81caf:	add    $0x40,%rsi
 1f81cb3:	vporq  %zmm1,%zmm0,%zmm0
 1f81cb9:	cmp    %rsi,%rax
 1f81cbc:	jne    1f81c90 <node_facts_window_run+0x4880>
 1f81cbe:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f81cc5:	vporq  %zmm1,%zmm0,%zmm0
 1f81ccb:	vextracti128 $0x1,%ymm0,%xmm1
 1f81cd1:	vpor   %xmm1,%xmm0,%xmm0
 1f81cd5:	vpshufd $0xee,%xmm0,%xmm1
 1f81cda:	vpor   %xmm1,%xmm0,%xmm0
 1f81cde:	vmovq  %xmm0,%rax
 1f81ce3:	mov    0xa58(%r11),%rdx
 1f81cea:	mov    0xa68(%r11),%rsi
 1f81cf1:	mov    (%rdx,%r15,4),%r8d
 1f81cf5:	mov    %rax,%rdx
 1f81cf8:	shr    $0x20,%rdx
 1f81cfc:	mov    (%rsi,%r15,4),%r9d
 1f81d00:	or     %rax,%rdx
 1f81d03:	mov    %rdx,%rsi
 1f81d06:	shr    $0x10,%rsi
 1f81d0a:	or     %edx,%esi
 1f81d0c:	mov    %esi,%eax
 1f81d0e:	shr    $0x8,%eax
 1f81d11:	or     %esi,%eax
 1f81d13:	mov    %r8d,0x350(%rsp)
 1f81d1b:	cmp    %ebp,%r8d
 1f81d1e:	jbe    1f81d24 <node_facts_window_run+0x4914>
 1f81d20:	or     (%rcx,%r9,1),%al
 1f81d24:	movzbl %al,%esi
 1f81d27:	lea    0x0(,%rsi,8),%edx
 1f81d2e:	lea    0x0(,%rsi,4),%ecx
 1f81d35:	mov    %edx,%eax
 1f81d37:	mov    %ecx,0x310(%rsp)
 1f81d3e:	and    $0x8,%eax
 1f81d41:	and    $0x10,%ecx
 1f81d44:	and    $0x40,%edx
 1f81d47:	or     %eax,%ecx
 1f81d49:	mov    %esi,%eax
 1f81d4b:	and    $0x10,%eax
 1f81d4e:	lea    (%rcx,%rax,2),%eax
 1f81d51:	or     %eax,%edx
 1f81d53:	mov    %esi,%eax
 1f81d55:	and    $0x2,%eax
 1f81d58:	mov    %rdx,0x1a0(%rsp)
 1f81d60:	mov    %rsi,0x5b0(%rsp)
 1f81d68:	mov    %eax,0x570(%rsp)
 1f81d6f:	mov    %r9,0x530(%rsp)
 1f81d77:	je     1f81d92 <node_facts_window_run+0x4982>
 1f81d79:	cmpb   $0x1,0x26(%rdi)
 1f81d7d:	jne    1f81d92 <node_facts_window_run+0x4982>
 1f81d7f:	movzbl 0x54(%rdi),%eax
 1f81d83:	xor    %edx,%edx
 1f81d85:	shl    $0x11,%eax
 1f81d88:	add    %rax,0x1a0(%rsp)
 1f81d90:	jmp    1f81d94 <node_facts_window_run+0x4984>
 1f81d92:	xor    %edx,%edx
 1f81d94:	mov    0x9f0(%rdi),%rcx
 1f81d9b:	mov    0x9f8(%rdi),%rax
 1f81da2:	mov    %r12d,%esi
 1f81da5:	mov    %ebp,%r8d
 1f81da8:	shr    $0x6,%r8d
 1f81dac:	mov    %r12d,0x450(%rsp)
 1f81db4:	lea    (%rcx,%rsi,8),%rdi
 1f81db8:	lea    (%rax,%rsi,8),%r9
 1f81dbc:	mov    %rdi,0x4d0(%rsp)
 1f81dc4:	mov    %r9,0x3d0(%rsp)
 1f81dcc:	mov    %r10d,%r9d
 1f81dcf:	and    $0x3f,%r10d
 1f81dd3:	shr    $0x6,%r9d
 1f81dd7:	lea    0x1(%r8),%rdi
 1f81ddb:	mov    %r10,0x38(%rsp)
 1f81de0:	xor    $0x3f,%r10d
 1f81de4:	mov    %r8,0x490(%rsp)
 1f81dec:	mov    %rbp,0x8(%rsp)
 1f81df1:	mov    %rdi,0x390(%rsp)
 1f81df9:	mov    %rbp,%r8
 1f81dfc:	mov    %r9,0x5f0(%rsp)
 1f81e04:	cmp    $0x40,%ebp
 1f81e07:	jae    1f81e25 <node_facts_window_run+0x4a15>
 1f81e09:	mov    %r8,%r13
 1f81e0c:	mov    $0xffffffff,%r14d
 1f81e12:	xor    %r8d,%r8d
 1f81e15:	movq   $0x0,0x20(%rsp)
 1f81e1e:	xor    %ebp,%ebp
 1f81e20:	jmp    1f82090 <node_facts_window_run+0x4c80>
 1f81e25:	shr    $1,%edi
 1f81e27:	lea    0x8(%rcx,%rsi,8),%rcx
 1f81e2c:	lea    0x8(%rax,%rsi,8),%rax
 1f81e31:	shl    $0x6,%r9d
 1f81e35:	mov    $0xffffffff,%r14d
 1f81e3b:	mov    %r15,0x660(%rsp)
 1f81e43:	mov    %r8d,%r12d
 1f81e46:	xor    %r8d,%r8d
 1f81e49:	xor    %ebp,%ebp
 1f81e4b:	shl    $0x7,%rdi
 1f81e4f:	mov    %rcx,0x120(%rsp)
 1f81e57:	mov    %r9,0x18(%rsp)
 1f81e5c:	mov    %rax,0x30(%rsp)
 1f81e61:	mov    %rdi,0x1e0(%rsp)
 1f81e69:	xor    %r9d,%r9d
 1f81e6c:	movq   $0x0,0x20(%rsp)
 1f81e75:	data16 cs nopw 0x0(%rax,%rax,1)
 1f81e80:	mov    0x10(%rsp),%rdi
 1f81e85:	mov    %r12d,%r15d
 1f81e88:	sub    $0x40,%r15d
 1f81e8c:	mov    $0x40,%ecx
 1f81e91:	mov    0x18(%rsp),%r11
 1f81e96:	mov    0x38(%rsp),%rsi
 1f81e9b:	mov    $0x0,%eax
 1f81ea0:	mov    0x120(%rsp),%rdx
 1f81ea8:	cmovb  %r12d,%ecx
 1f81eac:	cmp    0x8(%rsp),%r9
 1f81eb1:	mov    0x9b8(%rdi),%r13
 1f81eb8:	cmovae %eax,%ecx
 1f81ebb:	mov    $0xffffffffffffffff,%rax
 1f81ec2:	add    %r11,%r13
 1f81ec5:	cmp    $0x40,%ecx
 1f81ec8:	shlx   %rcx,%rax,%rcx
 1f81ecd:	mov    0x58(%r9,%r13,1),%rbx
 1f81ed2:	not    %rcx
 1f81ed5:	cmove  %rax,%rcx
 1f81ed9:	shrx   %rsi,0x18(%r9,%r13,1),%rax
 1f81ee0:	add    %rbx,%rbx
 1f81ee3:	shlx   %r10,%rbx,%rbx
 1f81ee8:	or     %rax,%rbx
 1f81eeb:	mov    0x48(%r9,%r13,1),%rax
 1f81ef0:	shrx   %rsi,0x8(%r9,%r13,1),%r13
 1f81ef7:	and    %rcx,%rbx
 1f81efa:	add    %rax,%rax
 1f81efd:	shlx   %r10,%rax,%rax
 1f81f02:	or     %r13,%rax
 1f81f05:	and    %rcx,%rax
 1f81f08:	mov    %rax,-0x8(%rdx,%r8,8)
 1f81f0d:	mov    0x9b8(%rdi),%rax
 1f81f14:	mov    %r14d,%edi
 1f81f17:	mov    %r11,%r14
 1f81f1a:	add    %r11,%rax
 1f81f1d:	shrx   %rsi,0x10(%r9,%rax,1),%r11
 1f81f24:	mov    0x50(%r9,%rax,1),%rax
 1f81f29:	add    %rax,%rax
 1f81f2c:	shlx   %r10,%rax,%r13
 1f81f31:	mov    0x30(%rsp),%rax
 1f81f36:	or     %r11,%r13
 1f81f39:	mov    %r9d,%r11d
 1f81f3c:	and    %rcx,%r13
 1f81f3f:	mov    0x20(%rsp),%rcx
 1f81f44:	mov    %r13,-0x8(%rax,%r8,8)
 1f81f49:	popcnt %rbx,%rax
 1f81f4e:	add    %eax,%ecx
 1f81f50:	lzcnt  %rbx,%rax
 1f81f55:	sub    %eax,%r11d
 1f81f58:	lea    0x40(%r9),%rax
 1f81f5c:	add    $0x3f,%r11d
 1f81f60:	test   %rbx,%rbx
 1f81f63:	mov    %edi,%ebx
 1f81f65:	mov    $0x40,%edi
 1f81f6a:	cmovne %r11d,%ebx
 1f81f6e:	or     -0x8(%rdx,%r8,8),%rbp
 1f81f73:	cmp    $0x40,%r15d
 1f81f77:	mov    $0xffffffffffffffff,%r11
 1f81f7e:	cmovae %edi,%r15d
 1f81f82:	cmp    0x8(%rsp),%rax
 1f81f87:	mov    0x10(%rsp),%rdi
 1f81f8c:	mov    $0x0,%eax
 1f81f91:	cmovae %eax,%r15d
 1f81f95:	mov    0x9b8(%rdi),%rax
 1f81f9c:	add    %r14,%rax
 1f81f9f:	shlx   %r15,%r11,%r14
 1f81fa4:	cmp    $0x40,%r15d
 1f81fa8:	mov    0x98(%r9,%rax,1),%r15
 1f81fb0:	not    %r14
 1f81fb3:	cmove  %r11,%r14
 1f81fb7:	shrx   %rsi,0x58(%r9,%rax,1),%r11
 1f81fbe:	add    %r15,%r15
 1f81fc1:	shlx   %r10,%r15,%r15
 1f81fc6:	or     %r11,%r15
 1f81fc9:	mov    0x88(%r9,%rax,1),%r11
 1f81fd1:	shrx   %rsi,0x48(%r9,%rax,1),%rax
 1f81fd8:	and    %r14,%r15
 1f81fdb:	add    %r11,%r11
 1f81fde:	shlx   %r10,%r11,%r11
 1f81fe3:	or     %rax,%r11
 1f81fe6:	and    %r14,%r11
 1f81fe9:	mov    %r11,(%rdx,%r8,8)
 1f81fed:	mov    0x9b8(%rdi),%rax
 1f81ff4:	add    0x18(%rsp),%rax
 1f81ff9:	shrx   %rsi,0x50(%r9,%rax,1),%r11
 1f82000:	mov    0x90(%r9,%rax,1),%rax
 1f82008:	popcnt %r15,%rsi
 1f8200d:	add    %ecx,%esi
 1f8200f:	lzcnt  %r15,%rcx
 1f82014:	mov    %rsi,0x20(%rsp)
 1f82019:	mov    0x30(%rsp),%rsi
 1f8201e:	add    %rax,%rax
 1f82021:	shlx   %r10,%rax,%rax
 1f82026:	or     %r11,%rax
 1f82029:	and    %r14,%rax
 1f8202c:	mov    %r9d,%r14d
 1f8202f:	sub    %ecx,%r14d
 1f82032:	add    $0x7f,%r14d
 1f82036:	test   %r15,%r15
 1f82039:	mov    %rax,(%rsi,%r8,8)
 1f8203d:	cmove  %ebx,%r14d
 1f82041:	or     (%rdx,%r8,8),%rbp
 1f82045:	add    $0x2,%r8
 1f82049:	sub    $0xffffffffffffff80,%r9
 1f8204d:	add    $0xffffff80,%r12d
 1f82051:	or     %r13,%rbp
 1f82054:	or     %rax,%rbp
 1f82057:	cmp    %r9,0x1e0(%rsp)
 1f8205f:	jne    1f81e80 <node_facts_window_run+0x4a70>
 1f82065:	mov    0x490(%rsp),%rax
 1f8206d:	mov    (%rsp),%r11
 1f82071:	mov    0x660(%rsp),%r15
 1f82079:	mov    0x8(%rsp),%r13
 1f8207e:	mov    $0x40,%ebx
 1f82083:	xor    %edx,%edx
 1f82085:	inc    %rax
 1f82088:	test   $0x1,%al
 1f8208a:	je     1f82180 <node_facts_window_run+0x4d70>
 1f82090:	mov    0x10(%rsp),%r12
 1f82095:	mov    0x5f0(%rsp),%rax
 1f8209d:	mov    %r8,%r9
 1f820a0:	shl    $0x6,%r9
 1f820a4:	mov    %r13d,%ecx
 1f820a7:	mov    0x38(%rsp),%r11
 1f820ac:	sub    %r9d,%ecx
 1f820af:	cmp    $0x40,%ecx
 1f820b2:	cmovae %ebx,%ecx
 1f820b5:	cmp    %r13,%r9
 1f820b8:	cmovae %edx,%ecx
 1f820bb:	mov    $0xffffffffffffffff,%rdx
 1f820c2:	mov    0x9b8(%r12),%rsi
 1f820ca:	add    %r8,%rax
 1f820cd:	shl    $0x6,%rax
 1f820d1:	cmp    $0x40,%ecx
 1f820d4:	shlx   %rcx,%rdx,%rcx
 1f820d9:	not    %rcx
 1f820dc:	cmove  %rdx,%rcx
 1f820e0:	mov    0x58(%rsi,%rax,1),%rdx
 1f820e5:	mov    0x48(%rsi,%rax,1),%rbx
 1f820ea:	shrx   %r11,0x18(%rsi,%rax,1),%rdi
 1f820f1:	shrx   %r11,0x8(%rsi,%rax,1),%rsi
 1f820f8:	add    %rdx,%rdx
 1f820fb:	add    %rbx,%rbx
 1f820fe:	shlx   %r10,%rdx,%rdx
 1f82103:	or     %rdi,%rdx
 1f82106:	shlx   %r10,%rbx,%rdi
 1f8210b:	mov    0x4d0(%rsp),%rbx
 1f82113:	or     %rsi,%rdi
 1f82116:	and    %rcx,%rdx
 1f82119:	and    %rcx,%rdi
 1f8211c:	mov    %rdi,(%rbx,%r8,8)
 1f82120:	mov    0x9b8(%r12),%rsi
 1f82128:	shrx   %r11,0x10(%rsi,%rax,1),%rdi
 1f8212f:	mov    0x50(%rsi,%rax,1),%rsi
 1f82134:	mov    0x20(%rsp),%rax
 1f82139:	mov    (%rsp),%r11
 1f8213d:	add    %rsi,%rsi
 1f82140:	shlx   %r10,%rsi,%rsi
 1f82145:	or     %rdi,%rsi
 1f82148:	mov    %r14d,%edi
 1f8214b:	lea    0x3f(%r9),%r14d
 1f8214f:	and    %rcx,%rsi
 1f82152:	popcnt %rdx,%rcx
 1f82157:	add    %eax,%ecx
 1f82159:	mov    %rcx,0x20(%rsp)
 1f8215e:	lzcnt  %rdx,%rcx
 1f82163:	mov    0x3d0(%rsp),%rax
 1f8216b:	sub    %ecx,%r14d
 1f8216e:	test   %rdx,%rdx
 1f82171:	cmove  %edi,%r14d
 1f82175:	mov    %rsi,(%rax,%r8,8)
 1f82179:	or     (%rbx,%r8,8),%rbp
 1f8217d:	or     %rsi,%rbp
 1f82180:	test   %r13d,%r13d
 1f82183:	je     1f821b2 <node_facts_window_run+0x4da2>
 1f82185:	lea    -0x1(%r13),%rax
 1f82189:	mov    $0xffffffff,%ebx
 1f8218e:	shr    $0x4,%rax
 1f82192:	inc    %rax
 1f82195:	mov    %eax,%edx
 1f82197:	and    $0x3,%edx
 1f8219a:	cmp    $0x31,%r13d
 1f8219e:	jae    1f821d0 <node_facts_window_run+0x4dc0>
 1f821a0:	vpxor  %xmm0,%xmm0,%xmm0
 1f821a4:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f821ab:	xor    %ecx,%ecx
 1f821ad:	jmp    1f82313 <node_facts_window_run+0x4f03>
 1f821b2:	mov    0x10(%rsp),%rdi
 1f821b7:	mov    0x530(%rsp),%r8
 1f821bf:	mov    0x50(%rsp),%r13
 1f821c4:	xor    %edx,%edx
 1f821c6:	mov    $0xffffffff,%ecx
 1f821cb:	jmp    1f823f1 <node_facts_window_run+0x4fe1>
 1f821d0:	mov    %r15,0x660(%rsp)
 1f821d8:	and    $0xfffffffffffffffc,%rax
 1f821dc:	lea    -0x30(%r13),%edi
 1f821e0:	lea    -0x20(%r13),%r8d
 1f821e4:	lea    -0x10(%r13),%r9d
 1f821e8:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f821ef:	mov    $0xffff,%r15d
 1f821f5:	vpxor  %xmm0,%xmm0,%xmm0
 1f821f9:	mov    0x60(%rsp),%rcx
 1f821fe:	mov    0x160(%rsp),%rsi
 1f82206:	lea    (%rcx,%rsi,4),%rsi
 1f8220a:	xor    %ecx,%ecx
 1f8220c:	nopl   0x0(%rax)
 1f82210:	lea    0x0(%r13,%rcx,1),%r10
 1f82215:	shlx   %r10d,%ebx,%r11d
 1f8221a:	sub    $0x10,%r10
 1f8221e:	not    %r11d
 1f82221:	cmovae %r15d,%r11d
 1f82225:	cmp    $0x10,%r10
 1f82229:	kmovd  %r11d,%k1
 1f8222e:	lea    (%r9,%rcx,1),%r11d
 1f82232:	vmovdqu32 -0xc0(%rsi),%zmm2{%k1}{z}
 1f82239:	shlx   %r11d,%ebx,%r10d
 1f8223e:	lea    (%r8,%rcx,1),%r11d
 1f82242:	not    %r10d
 1f82245:	cmovae %r15d,%r10d
 1f82249:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82250:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f82256:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f8225c:	kmovd  %r10d,%k1
 1f82261:	lea    -0x20(%r13,%rcx,1),%r10
 1f82266:	vmovdqu32 -0x80(%rsi),%zmm2{%k1}{z}
 1f8226d:	cmp    $0x10,%r10
 1f82271:	shlx   %r11d,%ebx,%r10d
 1f82276:	lea    (%rdi,%rcx,1),%r11d
 1f8227a:	not    %r10d
 1f8227d:	cmovae %r15d,%r10d
 1f82281:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82288:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f8228e:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82294:	kmovd  %r10d,%k1
 1f82299:	lea    -0x30(%r13,%rcx,1),%r10
 1f8229e:	vmovdqu32 -0x40(%rsi),%zmm2{%k1}{z}
 1f822a5:	cmp    $0x10,%r10
 1f822a9:	shlx   %r11d,%ebx,%r10d
 1f822ae:	not    %r10d
 1f822b1:	cmovae %r15d,%r10d
 1f822b5:	add    $0xffffffffffffffc0,%rcx
 1f822b9:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f822c0:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f822c6:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f822cc:	kmovd  %r10d,%k1
 1f822d1:	vmovdqu32 (%rsi),%zmm2{%k1}{z}
 1f822d7:	add    $0x100,%rsi
 1f822de:	add    $0xfffffffffffffffc,%rax
 1f822e2:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f822e9:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f822ef:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f822f5:	jne    1f82210 <node_facts_window_run+0x4e00>
 1f822fb:	mov    0x660(%rsp),%r15
 1f82303:	test   %rdx,%rdx
 1f82306:	je     1f82821 <node_facts_window_run+0x5411>
 1f8230c:	mov    (%rsp),%r11
 1f82310:	neg    %rcx
 1f82313:	mov    0x160(%rsp),%rax
 1f8231b:	mov    0x8(%rsp),%rsi
 1f82320:	mov    0x10(%rsp),%rdi
 1f82325:	mov    0x50(%rsp),%r13
 1f8232a:	mov    $0xffff,%r10d
 1f82330:	shl    $0x4,%edx
 1f82333:	lea    0x0(,%rax,4),%rax
 1f8233b:	sub    %rcx,%rsi
 1f8233e:	lea    (%rax,%rcx,4),%rax
 1f82342:	add    0xe0(%rsp),%rax
 1f8234a:	xor    %ecx,%ecx
 1f8234c:	nopl   0x0(%rax)
 1f82350:	mov    %esi,%r8d
 1f82353:	sub    $0x10,%rsi
 1f82357:	shlx   %r8d,%ebx,%r8d
 1f8235c:	not    %r8d
 1f8235f:	cmovae %r10d,%r8d
 1f82363:	kmovd  %r8d,%k1
 1f82368:	vmovdqu32 (%rax,%rcx,4),%zmm2{%k1}{z}
 1f8236f:	add    $0x10,%rcx
 1f82373:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f8237a:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f82380:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82386:	cmp    %rcx,%rdx
 1f82389:	jne    1f82350 <node_facts_window_run+0x4f40>
 1f8238b:	vextracti64x4 $0x1,%zmm1,%ymm2
 1f82392:	mov    0x530(%rsp),%r8
 1f8239a:	vpminud %ymm2,%ymm1,%ymm1
 1f8239f:	vextracti128 $0x1,%ymm1,%xmm2
 1f823a5:	vpminud %xmm2,%xmm1,%xmm1
 1f823aa:	vpshufd $0xee,%xmm1,%xmm2
 1f823af:	vpminud %xmm2,%xmm1,%xmm1
 1f823b4:	vpshufd $0x55,%xmm1,%xmm2
 1f823b9:	vpminud %xmm2,%xmm1,%xmm1
 1f823be:	vmovd  %xmm1,%ecx
 1f823c2:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f823c9:	vpmaxud %ymm1,%ymm0,%ymm0
 1f823ce:	vextracti128 $0x1,%ymm0,%xmm1
 1f823d4:	vpmaxud %xmm1,%xmm0,%xmm0
 1f823d9:	vpshufd $0xee,%xmm0,%xmm1
 1f823de:	vpmaxud %xmm1,%xmm0,%xmm0
 1f823e3:	vpshufd $0x55,%xmm0,%xmm1
 1f823e8:	vpmaxud %xmm1,%xmm0,%xmm0
 1f823ed:	vmovd  %xmm0,%edx
 1f823f1:	mov    0x310(%rsp),%eax
 1f823f8:	and    $0x100,%eax
 1f823fd:	mov    %r8d,%ebx
 1f82400:	or     %rax,0x1a0(%rsp)
 1f82408:	mov    0x350(%rsp),%eax
 1f8240f:	mov    0x290(%rsp),%r10
 1f82417:	mov    0x28(%rsp),%rsi
 1f8241c:	cmp    0x8(%rsp),%eax
 1f82420:	cmovbe %r10d,%ebx
 1f82424:	mov    0x422c(%rsi,%rbx,4),%eax
 1f8242b:	mov    %rax,0x18(%rsp)
 1f82430:	mov    %rbx,0x120(%rsp)
 1f82438:	ja     1f82441 <node_facts_window_run+0x5031>
 1f8243a:	xor    %esi,%esi
 1f8243c:	xor    %r10d,%r10d
 1f8243f:	jmp    1f82464 <node_facts_window_run+0x5054>
 1f82441:	mov    0x9b8(%rdi),%r10
 1f82448:	mov    %r8,%r9
 1f8244b:	and    $0xffffffc0,%r8d
 1f8244f:	shrx   %r9,0x8(%r10,%r8,1),%rsi
 1f82456:	shrx   %r9,0x10(%r10,%r8,1),%r10
 1f8245d:	and    $0x1,%esi
 1f82460:	and    $0x1,%r10d
 1f82464:	mov    0x490(%rsp),%rax
 1f8246c:	mov    0x8(%rsp),%r9
 1f82471:	mov    0x4d0(%rsp),%rbx
 1f82479:	mov    0x3d0(%rsp),%r12
 1f82481:	or     %rsi,%rbp
 1f82484:	or     %r10,%rbp
 1f82487:	shlx   %r9,%rsi,%r8
 1f8248c:	shl    $0x3,%eax
 1f8248f:	mov    %ecx,%esi
 1f82491:	or     %r8,(%rbx,%rax,1)
 1f82495:	shlx   %r9,%r10,%r8
 1f8249a:	mov    0x2d0(%rsp),%r10
 1f824a2:	or     %r8,(%r12,%rax,1)
 1f824a6:	mov    0x18(%rsp),%rax
 1f824ab:	mov    %edx,%r8d
 1f824ae:	cmp    %ecx,%eax
 1f824b0:	cmovb  %eax,%esi
 1f824b3:	cmp    %edx,%eax
 1f824b5:	cmova  %eax,%r8d
 1f824b9:	cmp    0xa0(%rsp),%eax
 1f824c0:	cmovae %ecx,%esi
 1f824c3:	mov    0x1a0(%rsp),%rcx
 1f824cb:	cmovae %edx,%r8d
 1f824cf:	mov    0x160(%rsp),%rdx
 1f824d7:	mov    %rcx,(%r10)
 1f824da:	mov    0x390(%rsp),%rcx
 1f824e2:	mov    %rbx,0x8(%r10)
 1f824e6:	mov    %r12,0x10(%r10)
 1f824ea:	mov    %esi,0x30(%rsp)
 1f824ee:	mov    %r8d,0x38(%rsp)
 1f824f3:	mov    0x20(%rsp),%rax
 1f824f8:	mov    0x290(%rsp),%rbx
 1f82500:	mov    %ecx,0x18(%r10)
 1f82504:	mov    0x990(%rdi),%rcx
 1f8250b:	add    %rdx,%rcx
 1f8250e:	mov    %rcx,0x20(%r10)
 1f82512:	mov    0x9a0(%rdi),%rcx
 1f82519:	add    %rdx,%rcx
 1f8251c:	mov    %rcx,0x28(%r10)
 1f82520:	mov    0x570(%rsp),%ecx
 1f82527:	add    0x9a8(%rdi),%rdx
 1f8252e:	mov    %rdx,0x30(%r10)
 1f82532:	mov    %esi,0x38(%r10)
 1f82536:	mov    %r8d,0x3c(%r10)
 1f8253a:	mov    %eax,0x40(%r10)
 1f8253e:	mov    0x310(%rsp),%eax
 1f82545:	mov    $0x0,%r8d
 1f8254b:	mov    %r14d,0x44(%r10)
 1f8254f:	mov    %ecx,0x48(%r10)
 1f82553:	and    $0x80,%eax
 1f82558:	cmpl   $0x0,0x80(%rsp)
 1f82560:	mov    %eax,0x4c(%r10)
 1f82564:	je     1f825a3 <node_facts_window_run+0x5193>
 1f82566:	mov    0x18(%rsp),%rcx
 1f8256b:	cmp    0xa0(%rsp),%ecx
 1f82572:	cmovae %r8d,%ecx
 1f82576:	jae    1f825a3 <node_facts_window_run+0x5193>
 1f82578:	mov    0x988(%rdi),%rdx
 1f8257f:	mov    %ecx,%esi
 1f82581:	mov    $0x1,%r10d
 1f82587:	shr    $0x6,%ecx
 1f8258a:	mov    $0x6,%r9d
 1f82590:	shlx   %rsi,%r10,%rsi
 1f82595:	mov    0x2d0(%rsp),%r10
 1f8259d:	and    (%rdx,%rcx,8),%rsi
 1f825a1:	jne    1f825d1 <node_facts_window_run+0x51c1>
 1f825a3:	mov    0xb8(%rsp),%rcx
 1f825ab:	mov    0x120(%rsp),%rax
 1f825b3:	movzbl (%rcx,%rax,1),%eax
 1f825b7:	and    $0x7f,%eax
 1f825ba:	cmpl   $0x0,0x7c0(%rsp)
 1f825c2:	movzbl 0x2c8(%rdi,%rax,1),%r9d
 1f825cb:	jne    1f82834 <node_facts_window_run+0x5424>
 1f825d1:	mov    0x8(%rsp),%rsi
 1f825d6:	mov    0x9b8(%rdi),%rdx
 1f825dd:	mov    %ebx,%ecx
 1f825df:	mov    0x20(%rsp),%r12
 1f825e4:	cmp    %esi,0x350(%rsp)
 1f825eb:	setbe  %al
 1f825ee:	and    $0xffffffc0,%ecx
 1f825f1:	inc    %r14d
 1f825f4:	shrx   %rbx,0x20(%rdx,%rcx,1),%rcx
 1f825fb:	mov    0x5b0(%rsp),%rbx
 1f82603:	xor    %esi,%r14d
 1f82606:	mov    0x90(%rsp),%esi
 1f8260d:	mov    %r12d,%edx
 1f82610:	xor    $0x1,%edx
 1f82613:	and    $0x22,%ebx
 1f82616:	cmp    $0x2,%r9d
 1f8261a:	cmovne %r8d,%esi
 1f8261e:	test   %ebx,%ebx
 1f82620:	cmove  %ebx,%esi
 1f82623:	test   %rbp,%rbp
 1f82626:	mov    $0x0,%ebx
 1f8262b:	setne  %r8b
 1f8262f:	or     %al,%r8b
 1f82632:	or     %r14d,%edx
 1f82635:	mov    0x48(%rsp),%rdx
 1f8263a:	cmovne 0x78(%rsp),%ebx
 1f8263f:	test   %r12d,%r12d
 1f82642:	movzbl %r8b,%eax
 1f82646:	mov    %r9d,%r8d
 1f82649:	cmove  %r12d,%ebx
 1f8264d:	or     %eax,%ebx
 1f8264f:	xor    %eax,%eax
 1f82651:	test   %r9d,%r9d
 1f82654:	sete   %al
 1f82657:	or     %esi,%ebx
 1f82659:	andn   %eax,%ecx,%eax
 1f8265e:	mov    $0x101,%ecx
 1f82663:	or     %eax,%ebx
 1f82665:	mov    0xa88(%r11),%rax
 1f8266c:	movzbl (%rax,%r15,1),%eax
 1f82671:	bextr  %ecx,%eax,%eax
 1f82676:	or     %eax,%ebx
 1f82678:	xor    %eax,%eax
 1f8267a:	cmp    $0x6,%r9d
 1f8267e:	sete   %al
 1f82681:	lea    (%rdx,%rax,4),%r14
 1f82685:	or     0x1a0(%rsp),%r14
 1f8268d:	cmpb   $0x1,0x3b(%rdi)
 1f82691:	jne    1f82794 <node_facts_window_run+0x5384>
 1f82697:	mov    0x28(%rsp),%rbp
 1f8269c:	mov    0x450(%rsp),%r12d
 1f826a4:	mov    0x18(%rsp),%rsi
 1f826a9:	mov    0x30(%rsp),%edx
 1f826ad:	mov    0x40(%rsp),%r9
 1f826b2:	test   %ebx,%ebx
 1f826b4:	jne    1f82716 <node_facts_window_run+0x5306>
 1f826b6:	mov    0xa8(%rsp),%rax
 1f826be:	mov    %r9,%rcx
 1f826c1:	mov    0x8(%rax),%r9
 1f826c5:	mov    0x78(%r9),%eax
 1f826c9:	cmp    %eax,%esi
 1f826cb:	jae    1f82713 <node_facts_window_run+0x5303>
 1f826cd:	mov    0x98(%r9),%rdx
 1f826d4:	mov    %r8d,0x8(%rsp)
 1f826d9:	movzbl (%rdx,%rsi,1),%r8d
 1f826de:	cmp    $0x4a,%r8d
 1f826e2:	je     1f82703 <node_facts_window_run+0x52f3>
 1f826e4:	cmp    $0x1e,%r8d
 1f826e8:	jne    1f8270a <node_facts_window_run+0x52fa>
 1f826ea:	mov    0xa8(%r9),%r9
 1f826f1:	mov    %rdx,%r8
 1f826f4:	mov    (%r9,%rsi,4),%edx
 1f826f8:	cmp    %eax,%edx
 1f826fa:	jae    1f8270a <node_facts_window_run+0x52fa>
 1f826fc:	cmpb   $0x4a,(%r8,%rdx,1)
 1f82701:	jne    1f8270a <node_facts_window_run+0x52fa>
 1f82703:	or     $0x1000000,%r14
 1f8270a:	mov    0x30(%rsp),%edx
 1f8270e:	mov    0x8(%rsp),%r8d
 1f82713:	mov    %rcx,%r9
 1f82716:	cmpl   $0x0,0x980(%rdi)
 1f8271d:	mov    0x38(%rsp),%ecx
 1f82721:	jne    1f827c0 <node_facts_window_run+0x53b0>
 1f82727:	cmp    0x968(%rdi),%edx
 1f8272d:	ja     1f8273b <node_facts_window_run+0x532b>
 1f8272f:	cmp    0x964(%rdi),%ecx
 1f82735:	jae    1f827c0 <node_facts_window_run+0x53b0>
 1f8273b:	mov    0x390(%rsp),%rsi
 1f82743:	mov    %r14,0x50(%r10)
 1f82747:	mov    %r8b,0x60(%r10)
 1f8274b:	mov    %edx,0x58(%r10)
 1f8274f:	mov    %ecx,0x5c(%r10)
 1f82753:	mov    %bl,0x62(%r10)
 1f82757:	mov    0x220(%rsp),%rdx
 1f8275f:	or     0x98(%rsp),%ebx
 1f82766:	mov    $0xffffffffffffffff,%r14
 1f8276d:	mov    0xa08(%rdi),%rax
 1f82774:	add    %r12d,%esi
 1f82777:	mov    %edx,%ecx
 1f82779:	add    %ebx,%edx
 1f8277b:	mov    $0x40,%ebx
 1f82780:	mov    %esi,%r12d
 1f82783:	mov    %r15d,(%rax,%rcx,4)
 1f82787:	mov    %rdx,0x220(%rsp)
 1f8278f:	jmp    1f81a44 <node_facts_window_run+0x4634>
 1f82794:	mov    0x28(%rsp),%rbp
 1f82799:	mov    0x450(%rsp),%r12d
 1f827a1:	mov    0x18(%rsp),%rsi
 1f827a6:	mov    0x30(%rsp),%edx
 1f827aa:	mov    0x40(%rsp),%r9
 1f827af:	cmpl   $0x0,0x980(%rdi)
 1f827b6:	mov    0x38(%rsp),%ecx
 1f827ba:	je     1f82727 <node_facts_window_run+0x5317>
 1f827c0:	mov    0x38(%rsp),%ecx
 1f827c4:	vmovdqu64 %zmm3,0x120(%rsp)
 1f827cf:	mov    %r8d,0x8(%rsp)
 1f827d4:	vzeroupper
 1f827d7:	call   1f6a060 <node_census_reader_marks>
 1f827dc:	vmovdqu64 0x120(%rsp),%zmm3
 1f827e7:	mov    0x8(%rsp),%r8d
 1f827ec:	mov    0x38(%rsp),%ecx
 1f827f0:	mov    0x30(%rsp),%edx
 1f827f4:	mov    0x2d0(%rsp),%r10
 1f827fc:	mov    0x10(%rsp),%rdi
 1f82801:	mov    0x40(%rsp),%r9
 1f82806:	mov    (%rsp),%r11
 1f8280a:	or     %rax,%r14
 1f8280d:	jmp    1f8273b <node_facts_window_run+0x532b>
 1f82812:	mov    0x10(%rsp),%rdi
 1f82817:	mov    0x38(%rsp),%r10
 1f8281c:	jmp    1f81cbe <node_facts_window_run+0x48ae>
 1f82821:	mov    (%rsp),%r11
 1f82825:	mov    0x10(%rsp),%rdi
 1f8282a:	mov    0x50(%rsp),%r13
 1f8282f:	jmp    1f8238b <node_facts_window_run+0x4f7b>
 1f82834:	cmp    $0x2,%r9d
 1f82838:	jne    1f825d1 <node_facts_window_run+0x51c1>
 1f8283e:	mov    0xa8(%rsp),%rax
 1f82846:	mov    0x18(%rsp),%rdx
 1f8284b:	vmovdqu64 %zmm3,0x120(%rsp)
 1f82856:	mov    (%rax),%rax
 1f82859:	mov    0x6e0(%rax),%rdi
 1f82860:	mov    0x6e8(%rax),%esi
 1f82866:	vzeroupper
 1f82869:	call   1f69c40 <node_census_cleans>
 1f8286e:	vmovdqu64 0x120(%rsp),%zmm3
 1f82879:	mov    0x2d0(%rsp),%r10
 1f82881:	mov    0x10(%rsp),%rdi
 1f82886:	mov    (%rsp),%r11
 1f8288a:	movzbl %al,%eax
 1f8288d:	xor    %r8d,%r8d
 1f82890:	lea    0x2(,%rax,4),%r9d
 1f82898:	jmp    1f825d1 <node_facts_window_run+0x51c1>
 1f8289d:	rdtsc
 1f8289f:	mov    %rdx,0x30(%rsp)
 1f828a4:	mov    %rax,0x18(%rsp)
 1f828a9:	cmpb   $0x0,0x68(%rsp)
 1f828ae:	je     1f82a24 <node_facts_window_run+0x5614>
 1f828b4:	cmpl   $0x0,0xa90(%r11)
 1f828bc:	je     1f82a24 <node_facts_window_run+0x5614>
 1f828c2:	mov    $0xffffffffffffffff,%rdx
 1f828c9:	xor    %r9d,%r9d
 1f828cc:	xor    %ecx,%ecx
 1f828ce:	jmp    1f828e3 <node_facts_window_run+0x54d3>
 1f828d0:	mov    0xa90(%r11),%eax
 1f828d7:	inc    %rcx
 1f828da:	cmp    %rax,%rcx
 1f828dd:	jae    1f82a24 <node_facts_window_run+0x5614>
 1f828e3:	imul   $0x68,%rcx,%r10
 1f828e7:	cmpb   $0x0,0x61(%r13,%r10,1)
 1f828ed:	je     1f828d0 <node_facts_window_run+0x54c0>
 1f828ef:	mov    0xa68(%r11),%rdi
 1f828f6:	mov    0xa70(%r11),%r8
 1f828fd:	add    %r13,%r10
 1f82900:	mov    $0x40,%esi
 1f82905:	mov    (%rdi,%rcx,4),%eax
 1f82908:	mov    (%r8,%rcx,4),%r11d
 1f8290c:	mov    0x10(%r10),%r8
 1f82910:	mov    %rax,0x20(%rsp)
 1f82915:	mov    %rcx,0x8(%rsp)
 1f8291a:	mov    0x651b8(%rbp,%r11,4),%edi
 1f82922:	mov    0x10(%rsp),%rcx
 1f82927:	sub    0x9f8(%rcx),%r8
 1f8292e:	add    0xa00(%rcx),%r8
 1f82935:	cmpl   $0x0,0x18(%r10)
 1f8293a:	je     1f829cb <node_facts_window_run+0x55bb>
 1f82940:	sub    %edi,%r11d
 1f82943:	mov    %edi,%r13d
 1f82946:	xor    %r15d,%r15d
 1f82949:	xor    %r12d,%r12d
 1f8294c:	mov    %edi,%ebp
 1f8294e:	inc    %r11d
 1f82951:	mov    %r11d,%ebx
 1f82954:	and    $0x3f,%r11d
 1f82958:	and    $0xffffffc0,%ebx
 1f8295b:	mov    %r11d,%r14d
 1f8295e:	xor    $0x3f,%r14d
 1f82962:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82970:	sub    $0x40,%ebp
 1f82973:	cmovae %esi,%r13d
 1f82977:	cmp    %r15d,%edi
 1f8297a:	cmovbe %r9d,%r13d
 1f8297e:	mov    0x9b8(%rcx),%r9
 1f82985:	add    %rbx,%r9
 1f82988:	cmp    $0x40,%r13d
 1f8298c:	shlx   %r13,%rdx,%r13
 1f82991:	shrx   %r11,(%r15,%r9,1),%rax
 1f82997:	mov    0x40(%r15,%r9,1),%r9
 1f8299c:	not    %r13
 1f8299f:	cmove  %rdx,%r13
 1f829a3:	add    $0x40,%r15
 1f829a7:	add    %r9,%r9
 1f829aa:	shlx   %r14,%r9,%r9
 1f829af:	or     %rax,%r9
 1f829b2:	and    %r13,%r9
 1f829b5:	mov    %ebp,%r13d
 1f829b8:	mov    %r9,(%r8,%r12,8)
 1f829bc:	inc    %r12
 1f829bf:	xor    %r9d,%r9d
 1f829c2:	mov    0x18(%r10),%eax
 1f829c6:	cmp    %rax,%r12
 1f829c9:	jb     1f82970 <node_facts_window_run+0x5560>
 1f829cb:	mov    (%rsp),%r11
 1f829cf:	mov    0x8(%rsp),%rcx
 1f829d4:	mov    0x28(%rsp),%rbp
 1f829d9:	mov    0x50(%rsp),%r13
 1f829de:	mov    0xa58(%r11),%r10
 1f829e5:	cmp    %edi,(%r10,%rcx,4)
 1f829e9:	jbe    1f828d0 <node_facts_window_run+0x54c0>
 1f829ef:	mov    0x10(%rsp),%rax
 1f829f4:	mov    0x20(%rsp),%rsi
 1f829f9:	mov    0x9b8(%rax),%rax
 1f82a00:	mov    %esi,%r9d
 1f82a03:	and    $0xffffffc0,%r9d
 1f82a07:	shrx   %rsi,(%rax,%r9,1),%rax
 1f82a0d:	xor    %r9d,%r9d
 1f82a10:	and    $0x1,%eax
 1f82a13:	shlx   %rdi,%rax,%rax
 1f82a18:	shr    $0x6,%edi
 1f82a1b:	or     %rax,(%r8,%rdi,8)
 1f82a1f:	jmp    1f828d0 <node_facts_window_run+0x54c0>
 1f82a24:	shlq   $0x20,0xe8(%rsp)
 1f82a2d:	shlq   $0x20,0x430(%rsp)
 1f82a36:	shlq   $0x20,0x410(%rsp)
 1f82a3f:	shlq   $0x20,0x30(%rsp)
 1f82a45:	lea    0x890(%rsp),%rdi
 1f82a4d:	mov    $0x418,%edx
 1f82a52:	mov    0xb0(%rsp),%rbx
 1f82a5a:	mov    %rbx,%rsi
 1f82a5d:	vzeroupper
 1f82a60:	call   355e9f0 <memcpy>
 1f82a65:	mov    0x220(%rsp),%rax
 1f82a6d:	movb   $0x0,0x5b(%rbx)
 1f82a71:	test   %eax,%eax
 1f82a73:	je     1f82d20 <node_facts_window_run+0x5910>
 1f82a79:	mov    (%rsp),%rdi
 1f82a7d:	mov    0x10(%rsp),%r9
 1f82a82:	mov    %eax,%r14d
 1f82a85:	xor    %r15d,%r15d
 1f82a88:	jmp    1f82ad8 <node_facts_window_run+0x56c8>
 1f82a8a:	nopw   0x0(%rax,%rax,1)
 1f82a90:	movzbl 0x760(%rsp),%ecx
 1f82a98:	mov    (%rsp),%rdi
 1f82a9c:	mov    0x10(%rsp),%r9
 1f82aa1:	xor    %edx,%edx
 1f82aa3:	add    %rdx,0x8a0(%r8)
 1f82aaa:	mov    %rax,0x50(%r12)
 1f82aaf:	mov    %cl,0x60(%r12)
 1f82ab4:	inc    %r15
 1f82ab7:	mov    0x3b4(%r9),%eax
 1f82abe:	mov    %eax,0x58(%r12)
 1f82ac3:	mov    0x3b8(%r9),%eax
 1f82aca:	mov    %eax,0x5c(%r12)
 1f82acf:	cmp    %r15,%r14
 1f82ad2:	je     1f82cbf <node_facts_window_run+0x58af>
 1f82ad8:	mov    0xa08(%r9),%rax
 1f82adf:	mov    0xa68(%rdi),%r8
 1f82ae6:	mov    0xa70(%rdi),%rcx
 1f82aed:	mov    (%rax,%r15,4),%r12d
 1f82af1:	mov    0xa58(%rdi),%rax
 1f82af8:	mov    (%r8,%r12,4),%ebp
 1f82afc:	mov    (%rcx,%r12,4),%r13d
 1f82b00:	mov    0xa48(%rdi),%r8
 1f82b07:	mov    0xa50(%rdi),%rcx
 1f82b0e:	mov    0xb0(%rsp),%rdi
 1f82b16:	mov    (%rcx,%r12,4),%ebx
 1f82b1a:	mov    (%r8,%r12,4),%esi
 1f82b1e:	mov    (%rax,%r12,4),%ecx
 1f82b22:	mov    %ebx,%edx
 1f82b24:	call   1f53120 <node_machine_type>
 1f82b29:	mov    (%rsp),%rax
 1f82b2d:	mov    0x10(%rsp),%rdi
 1f82b32:	mov    0x28(%rsp),%rcx
 1f82b37:	mov    0xa58(%rax),%rax
 1f82b3e:	mov    (%rax,%r12,4),%eax
 1f82b42:	cmp    0x651b8(%rcx,%r13,4),%eax
 1f82b4a:	jbe    1f82b83 <node_facts_window_run+0x5773>
 1f82b4c:	inc    %r13d
 1f82b4f:	cmp    %r13d,%ebp
 1f82b52:	je     1f82b83 <node_facts_window_run+0x5773>
 1f82b54:	mov    0x990(%rdi),%rdx
 1f82b5b:	mov    0x9a0(%rdi),%rsi
 1f82b62:	mov    %r13d,%eax
 1f82b65:	mov    0x9a8(%rdi),%rcx
 1f82b6c:	movzbl (%rdx,%rbp,1),%r8d
 1f82b71:	mov    %r8b,(%rdx,%rax,1)
 1f82b75:	movzbl (%rsi,%rbp,1),%edx
 1f82b79:	mov    %dl,(%rsi,%rax,1)
 1f82b7c:	movzbl (%rcx,%rbp,1),%edx
 1f82b80:	mov    %dl,(%rcx,%rax,1)
 1f82b83:	mov    0x28(%rsp),%rax
 1f82b88:	xor    %r9d,%r9d
 1f82b8b:	mov    0xa8(%rsp),%rdx
 1f82b93:	mov    $0xffffffff,%r8d
 1f82b99:	mov    0x422c(%rax,%rbp,4),%ecx
 1f82ba0:	cmpb   $0x23,0x2c(%rax,%rbp,1)
 1f82ba5:	jne    1f82be0 <node_facts_window_run+0x57d0>
 1f82ba7:	mov    0x50(%rsp),%r13
 1f82bac:	cmp    0xa0(%rsp),%ecx
 1f82bb3:	jae    1f82be5 <node_facts_window_run+0x57d5>
 1f82bb5:	mov    0x338(%rdx),%rax
 1f82bbc:	mov    (%rdx),%rsi
 1f82bbf:	mov    (%rax,%rcx,4),%r8d
 1f82bc3:	cmp    0x764(%rsi),%r8d
 1f82bca:	jae    1f82be5 <node_facts_window_run+0x57d5>
 1f82bcc:	mov    0x1e8(%rdx),%rax
 1f82bd3:	mov    (%rax,%r8,4),%r9d
 1f82bd7:	jmp    1f82be5 <node_facts_window_run+0x57d5>
 1f82bd9:	nopl   0x0(%rax)
 1f82be0:	mov    0x50(%rsp),%r13
 1f82be5:	imul   $0x68,%r12,%r12
 1f82be9:	movb   $0x0,0x760(%rsp)
 1f82bf1:	add    %r13,%r12
 1f82bf4:	cmpb   $0x0,0x68(%rsp)
 1f82bf9:	je     1f82c10 <node_facts_window_run+0x5800>
 1f82bfb:	mov    0x10(%r12),%rax
 1f82c00:	sub    0x9f8(%rdi),%rax
 1f82c07:	add    0xa00(%rdi),%rax
 1f82c0e:	jmp    1f82c12 <node_facts_window_run+0x5802>
 1f82c10:	xor    %eax,%eax
 1f82c12:	movzbl 0x68(%rsp),%edx
 1f82c17:	mov    %rax,0x350(%rdi)
 1f82c1e:	mov    0xb8(%rsp),%rax
 1f82c26:	mov    %ebx,%esi
 1f82c28:	mov    %dl,0x358(%rdi)
 1f82c2e:	movzbl (%rax,%rbp,1),%edx
 1f82c32:	push   %r12
 1f82c34:	lea    0x768(%rsp),%rax
 1f82c3c:	push   %rax
 1f82c3d:	call   1f54a00 <node_census_reader_expression>
 1f82c42:	add    $0x10,%rsp
 1f82c46:	cmpb   $0x1,0x62(%r12)
 1f82c4c:	mov    0x40(%rsp),%r8
 1f82c51:	adcq   $0x0,0x898(%r8)
 1f82c59:	cmpb   $0x0,0x62(%r12)
 1f82c5f:	jne    1f82a90 <node_facts_window_run+0x5680>
 1f82c65:	movzbl 0x760(%rsp),%ecx
 1f82c6d:	mov    (%rsp),%rdi
 1f82c71:	mov    $0x1,%edx
 1f82c76:	cmp    0x50(%r12),%rax
 1f82c7b:	jne    1f82cb5 <node_facts_window_run+0x58a5>
 1f82c7d:	mov    0x10(%rsp),%r9
 1f82c82:	cmp    0x60(%r12),%cl
 1f82c87:	jne    1f82aa3 <node_facts_window_run+0x5693>
 1f82c8d:	mov    0x3b4(%r9),%esi
 1f82c94:	cmp    0x58(%r12),%esi
 1f82c99:	jne    1f82aa3 <node_facts_window_run+0x5693>
 1f82c9f:	mov    0x3b8(%r9),%esi
 1f82ca6:	xor    %edx,%edx
 1f82ca8:	cmp    0x5c(%r12),%esi
 1f82cad:	setne  %dl
 1f82cb0:	jmp    1f82aa3 <node_facts_window_run+0x5693>
 1f82cb5:	mov    0x10(%rsp),%r9
 1f82cba:	jmp    1f82aa3 <node_facts_window_run+0x5693>
 1f82cbf:	rdtsc
 1f82cc1:	xor    %ebx,%ebx
 1f82cc3:	mov    %rdi,%r15
 1f82cc6:	mov    %r9,%r12
 1f82cc9:	shl    $0x20,%rdx
 1f82ccd:	or     %rax,%rdx
 1f82cd0:	mov    %rdx,0x20(%rsp)
 1f82cd5:	mov    0xb0(%rsp),%rbp
 1f82cdd:	nopl   (%rax)
 1f82ce0:	mov    0xa08(%r12),%rax
 1f82ce8:	mov    0xa48(%r15),%rcx
 1f82cef:	mov    0xa50(%r15),%rdx
 1f82cf6:	mov    %rbp,%rdi
 1f82cf9:	mov    (%rax,%rbx,4),%eax
 1f82cfc:	mov    (%rcx,%rax,4),%esi
 1f82cff:	mov    0xa58(%r15),%rcx
 1f82d06:	mov    (%rdx,%rax,4),%edx
 1f82d09:	mov    (%rcx,%rax,4),%ecx
 1f82d0c:	call   1f53120 <node_machine_type>
 1f82d11:	inc    %rbx
 1f82d14:	cmp    %rbx,%r14
 1f82d17:	jne    1f82ce0 <node_facts_window_run+0x58d0>
 1f82d19:	mov    0x28(%rsp),%rbp
 1f82d1e:	jmp    1f82d2e <node_facts_window_run+0x591e>
 1f82d20:	rdtsc
 1f82d22:	shl    $0x20,%rdx
 1f82d26:	or     %rax,%rdx
 1f82d29:	mov    %rdx,0x20(%rsp)
 1f82d2e:	mov    0xe8(%rsp),%rax
 1f82d36:	lea    0x890(%rsp),%rsi
 1f82d3e:	or     %rax,0xf0(%rsp)
 1f82d46:	mov    0x430(%rsp),%rax
 1f82d4e:	or     %rax,0x720(%rsp)
 1f82d56:	rdtsc
 1f82d58:	mov    0x410(%rsp),%rcx
 1f82d60:	shl    $0x20,%rdx
 1f82d64:	or     %rcx,0x6e0(%rsp)
 1f82d6c:	mov    0x30(%rsp),%rcx
 1f82d71:	or     %rcx,0x18(%rsp)
 1f82d76:	or     %rax,%rdx
 1f82d79:	mov    %rdx,0x30(%rsp)
 1f82d7e:	mov    $0x418,%edx
 1f82d83:	mov    0xb0(%rsp),%rdi
 1f82d8b:	call   355e9f0 <memcpy>
 1f82d90:	mov    (%rsp),%r11
 1f82d94:	cmpl   $0x0,0xa90(%r11)
 1f82d9c:	je     1f8300d <node_facts_window_run+0x5bfd>
 1f82da2:	xorb   $0x1,0x68(%rsp)
 1f82da7:	add    $0x62,%r13
 1f82dab:	xor    %r14d,%r14d
 1f82dae:	xor    %eax,%eax
 1f82db0:	mov    0x40(%rsp),%r8
 1f82db5:	mov    0x10(%rsp),%rdi
 1f82dba:	jmp    1f82ddd <node_facts_window_run+0x59cd>
 1f82dbc:	nopl   0x0(%rax)
 1f82dc0:	mov    %rax,%r15
 1f82dc3:	mov    0xa90(%r11),%ecx
 1f82dca:	inc    %r14
 1f82dcd:	add    $0x68,%r13
 1f82dd1:	mov    %r15,%rax
 1f82dd4:	cmp    %rcx,%r14
 1f82dd7:	jae    1f83015 <node_facts_window_run+0x5c05>
 1f82ddd:	cmpb   $0x0,-0x1(%r13)
 1f82de2:	je     1f82dc0 <node_facts_window_run+0x59b0>
 1f82de4:	xor    %edx,%edx
 1f82de6:	cmpb   $0x0,0x0(%r13)
 1f82deb:	mov    0xa70(%r11),%rcx
 1f82df2:	sete   %dl
 1f82df5:	mov    (%rcx,%r14,4),%ecx
 1f82df9:	add    %rdx,0x890(%r8)
 1f82e00:	and    0x68(%rsp),%dl
 1f82e04:	movzbl %dl,%edx
 1f82e07:	add    %rdx,0x690(%r8)
 1f82e0e:	cmp    $0x1,%dl
 1f82e11:	jne    1f82e20 <node_facts_window_run+0x5a10>
 1f82e13:	mov    0xa58(%r11),%rdx
 1f82e1a:	mov    (%rdx,%r14,4),%edx
 1f82e1e:	jmp    1f82e22 <node_facts_window_run+0x5a12>
 1f82e20:	xor    %edx,%edx
 1f82e22:	add    %rdx,0x698(%r8)
 1f82e29:	mov    0xa58(%r11),%rdx
 1f82e30:	mov    (%rdx,%r14,4),%edx
 1f82e34:	cmp    0x651b8(%rbp,%rcx,4),%edx
 1f82e3b:	jbe    1f82e60 <node_facts_window_run+0x5a50>
 1f82e3d:	mov    0xa68(%r11),%rdx
 1f82e44:	inc    %ecx
 1f82e46:	xor    %r15d,%r15d
 1f82e49:	cmp    %ecx,(%rdx,%r14,4)
 1f82e4d:	setne  %r15b
 1f82e51:	jmp    1f82e63 <node_facts_window_run+0x5a53>
 1f82e53:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82e60:	xor    %r15d,%r15d
 1f82e63:	mov    0xa50(%r11),%rcx
 1f82e6a:	mov    0x240(%r8),%rdx
 1f82e71:	mov    (%rcx,%r14,4),%ebx
 1f82e75:	mov    (%rdx,%rbx,8),%r12
 1f82e79:	cmp    %r12,-0x12(%r13)
 1f82e7d:	jne    1f82ec0 <node_facts_window_run+0x5ab0>
 1f82e7f:	mov    0x248(%r8),%rdx
 1f82e86:	movzbl -0x2(%r13),%ecx
 1f82e8b:	cmp    (%rdx,%rbx,1),%cl
 1f82e8e:	jne    1f82ec0 <node_facts_window_run+0x5ab0>
 1f82e90:	mov    0x9d0(%rdi),%rdx
 1f82e97:	mov    -0xa(%r13),%ecx
 1f82e9b:	cmp    (%rdx,%rbx,4),%ecx
 1f82e9e:	jne    1f82ec0 <node_facts_window_run+0x5ab0>
 1f82ea0:	mov    0x9d8(%rdi),%rdx
 1f82ea7:	mov    -0x6(%r13),%ecx
 1f82eab:	cmp    (%rdx,%rbx,4),%ecx
 1f82eae:	sete   %cl
 1f82eb1:	jmp    1f82ec2 <node_facts_window_run+0x5ab2>
 1f82eb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82ec0:	xor    %ecx,%ecx
 1f82ec2:	incq   0xa50(%r8)
 1f82ec9:	add    %rax,%r15
 1f82ecc:	mov    %ecx,%edx
 1f82ece:	mov    0xa58(%r11),%rax
 1f82ed5:	xor    $0x1,%dl
 1f82ed8:	vmovd  (%rax,%r14,4),%xmm0
 1f82ede:	movzbl %dl,%eax
 1f82ee1:	vmovd  %eax,%xmm1
 1f82ee5:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f82ee9:	vpaddq 0xa58(%r8),%xmm0,%xmm0
 1f82ef2:	vmovdqu %xmm0,0xa58(%r8)
 1f82efb:	test   %cl,%cl
 1f82efd:	jne    1f82dc3 <node_facts_window_run+0x59b3>
 1f82f03:	mov    0x12e4(%r8),%eax
 1f82f0a:	cmp    0x5004994(%rip),%eax        # 6f878a4 <node_census_list>
 1f82f10:	jae    1f82dc3 <node_facts_window_run+0x59b3>
 1f82f16:	inc    %eax
 1f82f18:	xor    %esi,%esi
 1f82f1a:	mov    %eax,0x12e4(%r8)
 1f82f21:	mov    0xa68(%r11),%rcx
 1f82f28:	mov    (%rdi),%rax
 1f82f2b:	mov    (%rcx,%r14,4),%ecx
 1f82f2f:	mov    0x18(%rax),%rax
 1f82f33:	mov    0x422c(%rbp,%rcx,4),%ecx
 1f82f3a:	cmp    0x78(%rax),%ecx
 1f82f3d:	jae    1f82f81 <node_facts_window_run+0x5b71>
 1f82f3f:	mov    0x68(%rax),%rax
 1f82f43:	mov    0x8(%rdi),%rdi
 1f82f47:	mov    (%rax,%rcx,4),%eax
 1f82f4a:	cmp    0x1538(%rdi),%eax
 1f82f50:	jae    1f82f81 <node_facts_window_run+0x5b71>
 1f82f52:	mov    0x1530(%rdi),%rcx
 1f82f59:	test   %rcx,%rcx
 1f82f5c:	je     1f82f81 <node_facts_window_run+0x5b71>
 1f82f5e:	mov    (%rcx,%rax,4),%esi
 1f82f61:	lea    0x760(%rsp),%rdx
 1f82f69:	lea    0x510(%rsp),%rcx
 1f82f71:	call   111f9b0 <pp_presumed>
 1f82f76:	mov    0x40(%rsp),%r8
 1f82f7b:	mov    (%rsp),%r11
 1f82f7f:	mov    %eax,%esi
 1f82f81:	mov    0xa58(%r11),%rax
 1f82f88:	mov    -0x12(%r13),%rcx
 1f82f8c:	movzbl -0x2(%r13),%r9d
 1f82f91:	mov    -0xa(%r13),%r11d
 1f82f95:	mov    -0x6(%r13),%r10d
 1f82f99:	mov    (%rax,%r14,4),%edx
 1f82f9d:	mov    0x248(%r8),%rax
 1f82fa4:	movzbl (%rax,%rbx,1),%eax
 1f82fa8:	mov    %rax,0x8(%rsp)
 1f82fad:	mov    %r13,0x50(%rsp)
 1f82fb2:	mov    0x10(%rsp),%r13
 1f82fb7:	mov    0x9d0(%r13),%rax
 1f82fbe:	mov    0x9d8(%r13),%rdi
 1f82fc5:	mov    (%rax,%rbx,4),%ebp
 1f82fc8:	mov    (%rdi,%rbx,4),%ebx
 1f82fcb:	sub    $0x8,%rsp
 1f82fcf:	lea    -0x196216e(%rip),%rdi        # 620e68 <.str.11115>
 1f82fd6:	mov    %r12,%r8
 1f82fd9:	xor    %eax,%eax
 1f82fdb:	push   %rbx
 1f82fdc:	push   %rbp
 1f82fdd:	push   %r10
 1f82fdf:	push   %r11
 1f82fe1:	push   0x30(%rsp)
 1f82fe5:	call   34ef110 <_IO_printf>
 1f82fea:	mov    %r13,%rdi
 1f82fed:	mov    0x80(%rsp),%r13
 1f82ff5:	mov    0x70(%rsp),%r8
 1f82ffa:	mov    0x30(%rsp),%r11
 1f82fff:	add    $0x30,%rsp
 1f83003:	mov    0x28(%rsp),%rbp
 1f83008:	jmp    1f82dc3 <node_facts_window_run+0x59b3>
 1f8300d:	mov    0x40(%rsp),%r8
 1f83012:	xor    %r15d,%r15d
 1f83015:	vpmovsxbq -0x1acc2d7(%rip),%xmm0        # 4b6d47 <abi_test_hex.digits+0xb9c7>
 1f8301e:	vmovd  0x8(%rbp),%xmm2
 1f83023:	mov    0x20(%rsp),%rcx
 1f83028:	mov    0x30(%rsp),%r9
 1f8302d:	mov    0x18(%rsp),%rdi
 1f83032:	vmovq  %r15,%xmm1
 1f83037:	xor    %eax,%eax
 1f83039:	mov    0x720(%rsp),%rdx
 1f83041:	mov    0x6e0(%rsp),%rsi
 1f83049:	mov    0xc0(%rsp),%r15
 1f83051:	sub    %rcx,%r9
 1f83054:	sub    %rdi,%rcx
 1f83057:	sub    %r9,%rcx
 1f8305a:	cmovae %rcx,%rax
 1f8305e:	mov    0xf0(%rsp),%rcx
 1f83066:	sub    %rdx,%rsi
 1f83069:	vpinsrq $0x0,%r9,%xmm0,%xmm0
 1f8306f:	vpunpcklqdq %xmm1,%xmm2,%xmm1
 1f83073:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f83079:	vpaddq 0xa98(%r8),%ymm0,%ymm0
 1f83082:	vmovq  %rsi,%xmm1
 1f83087:	sub    %rcx,%rdi
 1f8308a:	sub    %rcx,%rdx
 1f8308d:	add    %rax,%rdi
 1f83090:	vmovq  %rdx,%xmm2
 1f83095:	vmovdqu %ymm0,0xa98(%r8)
 1f8309e:	vmovq  %rax,%xmm0
 1f830a3:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f830a7:	vmovq  %rdi,%xmm1
 1f830ac:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f830b0:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f830b6:	vpaddq 0xa68(%r8),%ymm0,%ymm0
 1f830bf:	vmovdqu %ymm0,0xa68(%r8)
 1f830c8:	cmpq   $0x0,0xb40(%r11)
 1f830d0:	je     1f84d56 <node_facts_window_run+0x7946>
 1f830d6:	mov    0x940(%r11),%r12
 1f830dd:	mov    0x8(%rbp),%ebx
 1f830e0:	rdtsc
 1f830e2:	lea    0x890(%rsp),%rcx
 1f830ea:	vpxor  %xmm0,%xmm0,%xmm0
 1f830ee:	vmovdqu64 %zmm0,0x8b0(%rsp)
 1f830f9:	vmovdqu64 %zmm0,0x890(%rsp)
 1f83104:	mov    %r11,%rdi
 1f83107:	mov    %rbp,%rsi
 1f8310a:	shl    $0x20,%rdx
 1f8310e:	or     %rax,%rdx
 1f83111:	mov    %rdx,0x50(%rsp)
 1f83116:	mov    %ebx,%edx
 1f83118:	vzeroupper
 1f8311b:	call   1f93d40 <node_contexts_window_loop>
 1f83120:	vmovups 0x8b8(%rsp),%ymm0
 1f83129:	vmovdqu 0x8b8(%rsp),%xmm1
 1f83132:	mov    %rbp,%rsi
 1f83135:	vmovups %ymm0,0x1e0(%rsp)
 1f8313e:	vpbroadcastq 0x8c8(%rsp),%ymm0
 1f83148:	mov    (%rsp),%rax
 1f8314c:	vpsubq %xmm0,%xmm1,%xmm0
 1f83150:	vpaddq 0x8c8(%rsp),%xmm0,%xmm0
 1f83159:	vpblendd $0xc,%xmm0,%xmm1,%xmm0
 1f8315f:	vmovdqu %xmm0,0xc08(%rax)
 1f83167:	rdtsc
 1f83169:	shl    $0x20,%rdx
 1f8316d:	or     %rax,%rdx
 1f83170:	mov    %rdx,0x40(%rsp)
 1f83175:	mov    %ebx,%edx
 1f83177:	mov    (%rsp),%rdi
 1f8317b:	vzeroupper
 1f8317e:	call   1f95cf0 <node_contexts_window_targets>
 1f83183:	rdtsc
 1f83185:	mov    %rbp,%rsi
 1f83188:	shl    $0x20,%rdx
 1f8318c:	or     %rax,%rdx
 1f8318f:	mov    %rdx,0xb0(%rsp)
 1f83197:	mov    (%rsp),%rdi
 1f8319b:	call   1f96080 <node_contexts_window_part>
 1f831a0:	rdtsc
 1f831a2:	lea    0x760(%rsp),%rcx
 1f831aa:	vpxor  %xmm0,%xmm0,%xmm0
 1f831ae:	vmovdqu64 %zmm0,0x780(%rsp)
 1f831b6:	vmovdqu64 %zmm0,0x760(%rsp)
 1f831c1:	mov    %rbp,%rsi
 1f831c4:	shl    $0x20,%rdx
 1f831c8:	or     %rax,%rdx
 1f831cb:	mov    %rdx,0xb8(%rsp)
 1f831d3:	mov    %ebx,%edx
 1f831d5:	mov    (%rsp),%rdi
 1f831d9:	vzeroupper
 1f831dc:	call   1f93d40 <node_contexts_window_loop>
 1f831e1:	rdtsc
 1f831e3:	mov    %rbp,%rsi
 1f831e6:	shl    $0x20,%rdx
 1f831ea:	or     %rax,%rdx
 1f831ed:	mov    %rdx,0xa8(%rsp)
 1f831f5:	mov    %ebx,%edx
 1f831f7:	mov    (%rsp),%rdi
 1f831fb:	call   1f95cf0 <node_contexts_window_targets>
 1f83200:	rdtsc
 1f83202:	mov    %rbp,%rsi
 1f83205:	shl    $0x20,%rdx
 1f83209:	or     %rax,%rdx
 1f8320c:	mov    %rdx,0xa0(%rsp)
 1f83214:	mov    (%rsp),%rdi
 1f83218:	call   1f96080 <node_contexts_window_part>
 1f8321d:	mov    (%rsp),%r11
 1f83221:	rdtsc
 1f83223:	shl    $0x20,%rdx
 1f83227:	or     %rax,%rdx
 1f8322a:	cmpl   $0x0,0xa90(%r11)
 1f83232:	mov    %rdx,0x1a0(%rsp)
 1f8323a:	mov    %rbx,0x160(%rsp)
 1f83242:	je     1f83773 <node_facts_window_run+0x6363>
 1f83248:	vpbroadcastq -0x19b4d19(%rip),%xmm0        # 5ce538 <.LCPI3_1>
 1f83251:	xor    %ebx,%ebx
 1f83253:	xor    %edi,%edi
 1f83255:	mov    %r12,0x18(%rsp)
 1f8325a:	jmp    1f8327d <node_facts_window_run+0x5e6d>
 1f8325c:	mov    (%rsp),%r11
 1f83260:	xor    %esi,%esi
 1f83262:	incq   0x12e8(%r12,%rsi,8)
 1f8326a:	mov    0xa90(%r11),%eax
 1f83271:	inc    %rdi
 1f83274:	cmp    %rax,%rdi
 1f83277:	jae    1f83775 <node_facts_window_run+0x6365>
 1f8327d:	mov    0xb80(%r11),%rax
 1f83284:	movzbl (%rax,%rdi,1),%r8d
 1f83289:	test   %r8b,%r8b
 1f8328c:	je     1f8326a <node_facts_window_run+0x5e5a>
 1f8328e:	mov    0xa70(%r11),%rcx
 1f83295:	mov    0xa68(%r11),%rax
 1f8329c:	mov    (%rcx,%rdi,4),%ecx
 1f8329f:	mov    (%rax,%rdi,4),%r13d
 1f832a3:	mov    0x651b8(%rbp,%rcx,4),%esi
 1f832aa:	incq   0xab8(%r12)
 1f832b2:	mov    0xa58(%r11),%rax
 1f832b9:	mov    (%rax,%rdi,4),%eax
 1f832bc:	add    %rax,0xac0(%r12)
 1f832c4:	cmp    $0x1,%r8b
 1f832c8:	jne    1f83320 <node_facts_window_run+0x5f10>
 1f832ca:	mov    0xa58(%r11),%rax
 1f832d1:	mov    (%rax,%rdi,4),%r10d
 1f832d5:	test   %r10d,%r10d
 1f832d8:	je     1f83260 <node_facts_window_run+0x5e50>
 1f832da:	mov    0xbe8(%r11),%rax
 1f832e1:	sub    %esi,%ecx
 1f832e3:	xor    %r11d,%r11d
 1f832e6:	inc    %ecx
 1f832e8:	nopl   0x0(%rax,%rax,1)
 1f832f0:	lea    (%rcx,%r11,1),%r9d
 1f832f4:	cmp    %esi,%r11d
 1f832f7:	cmovae %r13d,%r9d
 1f832fb:	mov    %r9d,%edx
 1f832fe:	shr    $0x3,%edx
 1f83301:	and    $0xfffffff8,%edx
 1f83304:	mov    0x10(%rax,%rdx,8),%r8
 1f83309:	bt     %r9,%r8
 1f8330d:	jb     1f8339f <node_facts_window_run+0x5f8f>
 1f83313:	inc    %r11d
 1f83316:	cmp    %r11d,%r10d
 1f83319:	jne    1f832f0 <node_facts_window_run+0x5ee0>
 1f8331b:	jmp    1f8325c <node_facts_window_run+0x5e4c>
 1f83320:	mov    0xa58(%r11),%rcx
 1f83327:	mov    0xb68(%r11),%rdx
 1f8332e:	cmp    $0x3,%r8b
 1f83332:	sete   %al
 1f83335:	mov    (%rcx,%rdi,4),%r9d
 1f83339:	movzbl (%rdx,%rdi,1),%r10d
 1f8333e:	test   %r9,%r9
 1f83341:	sete   %cl
 1f83344:	cmp    $0x2,%r10b
 1f83348:	sete   %dl
 1f8334b:	or     %al,%dl
 1f8334d:	or     %cl,%dl
 1f8334f:	je     1f83359 <node_facts_window_run+0x5f49>
 1f83351:	xor    %r14d,%r14d
 1f83354:	jmp    1f83684 <node_facts_window_run+0x6274>
 1f83359:	mov    0xa70(%r11),%rcx
 1f83360:	mov    0xa68(%r11),%rax
 1f83367:	mov    %r13,0x20(%rsp)
 1f8336c:	mov    0xbe8(%r11),%r12
 1f83373:	mov    %rbx,0x8(%rsp)
 1f83378:	mov    (%rcx,%rdi,4),%ecx
 1f8337b:	mov    (%rax,%rdi,4),%r13d
 1f8337f:	mov    0xb48(%r11),%rax
 1f83386:	mov    0x651b8(%rbp,%rcx,4),%ebp
 1f8338d:	sub    %ebp,%ecx
 1f8338f:	cmp    $0x1,%r9d
 1f83393:	jne    1f833ee <node_facts_window_run+0x5fde>
 1f83395:	xor    %r14d,%r14d
 1f83398:	xor    %ebx,%ebx
 1f8339a:	jmp    1f835da <node_facts_window_run+0x61ca>
 1f8339f:	mov    (%rsp),%r11
 1f833a3:	mov    %r9d,%esi
 1f833a6:	mov    0xbd0(%r11),%rcx
 1f833ad:	movzbl (%rcx,%rsi,1),%ecx
 1f833b1:	mov    $0x1,%esi
 1f833b6:	cmp    $0xd,%ecx
 1f833b9:	je     1f83262 <node_facts_window_run+0x5e52>
 1f833bf:	lea    -0xf(%rcx),%r8d
 1f833c3:	mov    $0x2,%esi
 1f833c8:	cmp    $0x2,%r8b
 1f833cc:	jb     1f83262 <node_facts_window_run+0x5e52>
 1f833d2:	cmp    $0xe,%ecx
 1f833d5:	je     1f8372d <node_facts_window_run+0x631d>
 1f833db:	cmp    $0x11,%ecx
 1f833de:	jne    1f83737 <node_facts_window_run+0x6327>
 1f833e4:	mov    $0x4,%esi
 1f833e9:	jmp    1f83262 <node_facts_window_run+0x5e52>
 1f833ee:	mov    %r9d,%edx
 1f833f1:	and    $0xfffffffe,%edx
 1f833f4:	mov    %r10b,0x68(%rsp)
 1f833f9:	mov    %r8b,0x30(%rsp)
 1f833fe:	mov    %r9,0x38(%rsp)
 1f83403:	xor    %r14d,%r14d
 1f83406:	xor    %r15d,%r15d
 1f83409:	mov    %edx,0x10(%rsp)
 1f8340d:	lea    0x2(%rcx),%edx
 1f83410:	mov    %rcx,0x120(%rsp)
 1f83418:	jmp    1f8343a <node_facts_window_run+0x602a>
 1f8341a:	nopw   0x0(%rax,%rax,1)
 1f83420:	xor    %r11d,%r11d
 1f83423:	add    %r10,%r14
 1f83426:	add    $0x2,%edx
 1f83429:	inc    %r15d
 1f8342c:	add    %r11,%r14
 1f8342f:	cmp    0x10(%rsp),%r15d
 1f83434:	je     1f83583 <node_facts_window_run+0x6173>
 1f8343a:	mov    %r15d,%ebx
 1f8343d:	lea    -0x1(%rdx),%r15d
 1f83441:	cmp    %ebp,%ebx
 1f83443:	mov    $0x1,%r11d
 1f83449:	mov    $0x1,%r10d
 1f8344f:	cmovae %r13d,%r15d
 1f83453:	mov    %r15d,%esi
 1f83456:	and    $0xffffffc0,%esi
 1f83459:	movzbl (%rax,%r15,1),%r8d
 1f8345e:	shrx   %r15,(%r12,%rsi,1),%rsi
 1f83464:	and    $0x1,%r8d
 1f83468:	mov    %esi,%r9d
 1f8346b:	and    $0x1,%r9d
 1f8346f:	cmp    %r8d,%r9d
 1f83472:	jne    1f834e3 <node_facts_window_run+0x60d3>
 1f83474:	test   $0x1,%sil
 1f83478:	je     1f834e0 <node_facts_window_run+0x60d0>
 1f8347a:	mov    (%rsp),%rcx
 1f8347e:	mov    0xbb0(%rcx),%r8
 1f83485:	mov    0xb58(%rcx),%rsi
 1f8348c:	movzbl (%r8,%r15,1),%r8d
 1f83491:	cmp    (%rsi,%r15,1),%r8b
 1f83495:	jne    1f834e3 <node_facts_window_run+0x60d3>
 1f83497:	mov    (%rsp),%rcx
 1f8349b:	mov    0xbc0(%rcx),%r8
 1f834a2:	mov    0xb50(%rcx),%rsi
 1f834a9:	movzbl (%r8,%r15,1),%r8d
 1f834ae:	cmp    (%rsi,%r15,1),%r8b
 1f834b2:	jne    1f834e3 <node_facts_window_run+0x60d3>
 1f834b4:	mov    (%rsp),%rcx
 1f834b8:	xor    %r10d,%r10d
 1f834bb:	mov    0xbd8(%rcx),%r8
 1f834c2:	mov    0xb60(%rcx),%rsi
 1f834c9:	mov    (%r8,%r15,4),%r8d
 1f834cd:	cmp    (%rsi,%r15,4),%r8d
 1f834d1:	setne  %r10b
 1f834d5:	jmp    1f834e3 <node_facts_window_run+0x60d3>
 1f834d7:	nopw   0x0(%rax,%rax,1)
 1f834e0:	xor    %r10d,%r10d
 1f834e3:	lea    0x1(%rbx),%r15d
 1f834e7:	mov    %r13d,%esi
 1f834ea:	cmp    %ebp,%r15d
 1f834ed:	cmovb  %edx,%esi
 1f834f0:	mov    %esi,%r8d
 1f834f3:	and    $0xffffffc0,%r8d
 1f834f7:	movzbl (%rax,%rsi,1),%r9d
 1f834fc:	shrx   %rsi,(%r12,%r8,1),%r8
 1f83502:	and    $0x1,%r9d
 1f83506:	mov    %r8d,%ecx
 1f83509:	and    $0x1,%ecx
 1f8350c:	cmp    %r9d,%ecx
 1f8350f:	jne    1f83423 <node_facts_window_run+0x6013>
 1f83515:	test   $0x1,%r8b
 1f83519:	je     1f83420 <node_facts_window_run+0x6010>
 1f8351f:	mov    (%rsp),%r9
 1f83523:	mov    0xbb0(%r9),%r8
 1f8352a:	mov    0xb58(%r9),%rcx
 1f83531:	movzbl (%r8,%rsi,1),%r8d
 1f83536:	cmp    (%rcx,%rsi,1),%r8b
 1f8353a:	jne    1f83423 <node_facts_window_run+0x6013>
 1f83540:	mov    0xbc0(%r9),%r8
 1f83547:	mov    0xb50(%r9),%rcx
 1f8354e:	movzbl (%r8,%rsi,1),%r8d
 1f83553:	cmp    (%rcx,%rsi,1),%r8b
 1f83557:	jne    1f83423 <node_facts_window_run+0x6013>
 1f8355d:	mov    (%rsp),%r8
 1f83561:	xor    %r11d,%r11d
 1f83564:	mov    0xb60(%r8),%rcx
 1f8356b:	mov    0xbd8(%r8),%r8
 1f83572:	mov    (%r8,%rsi,4),%r8d
 1f83576:	cmp    (%rcx,%rsi,4),%r8d
 1f8357a:	setne  %r11b
 1f8357e:	jmp    1f83423 <node_facts_window_run+0x6013>
 1f83583:	mov    0x38(%rsp),%r9
 1f83588:	mov    0xc0(%rsp),%r15
 1f83590:	test   $0x1,%r9b
 1f83594:	jne    1f835bf <node_facts_window_run+0x61af>
 1f83596:	mov    (%rsp),%r11
 1f8359a:	mov    0x28(%rsp),%rbp
 1f8359f:	mov    0x18(%rsp),%r12
 1f835a4:	mov    0x8(%rsp),%rbx
 1f835a9:	mov    0x20(%rsp),%r13
 1f835ae:	movzbl 0x30(%rsp),%r8d
 1f835b4:	movzbl 0x68(%rsp),%r10d
 1f835ba:	jmp    1f83684 <node_facts_window_run+0x6274>
 1f835bf:	mov    (%rsp),%r11
 1f835c3:	movzbl 0x30(%rsp),%r8d
 1f835c9:	movzbl 0x68(%rsp),%r10d
 1f835cf:	mov    0x120(%rsp),%rcx
 1f835d7:	add    $0x2,%ebx
 1f835da:	inc    %ecx
 1f835dc:	add    %ebx,%ecx
 1f835de:	cmp    %ebp,%ebx
 1f835e0:	cmovb  %ecx,%r13d
 1f835e4:	mov    %r13d,%ecx
 1f835e7:	and    $0xffffffc0,%ecx
 1f835ea:	movzbl (%rax,%r13,1),%edx
 1f835ef:	mov    $0x1,%eax
 1f835f4:	shrx   %r13,(%r12,%rcx,1),%rcx
 1f835fa:	and    $0x1,%edx
 1f835fd:	mov    %ecx,%esi
 1f835ff:	and    $0x1,%esi
 1f83602:	cmp    %edx,%esi
 1f83604:	jne    1f83669 <node_facts_window_run+0x6259>
 1f83606:	mov    0x28(%rsp),%rbp
 1f8360b:	mov    0x18(%rsp),%r12
 1f83610:	mov    0x8(%rsp),%rbx
 1f83615:	test   $0x1,%cl
 1f83618:	je     1f8367a <node_facts_window_run+0x626a>
 1f8361a:	mov    0xbb0(%r11),%rdx
 1f83621:	mov    0xb58(%r11),%rcx
 1f83628:	movzbl (%rdx,%r13,1),%edx
 1f8362d:	cmp    (%rcx,%r13,1),%dl
 1f83631:	jne    1f8367c <node_facts_window_run+0x626c>
 1f83633:	mov    0xbc0(%r11),%rdx
 1f8363a:	mov    0xb50(%r11),%rcx
 1f83641:	movzbl (%rdx,%r13,1),%edx
 1f83646:	cmp    (%rcx,%r13,1),%dl
 1f8364a:	jne    1f8367c <node_facts_window_run+0x626c>
 1f8364c:	mov    0xbd8(%r11),%rax
 1f83653:	mov    0xb60(%r11),%rcx
 1f8365a:	mov    (%rax,%r13,4),%edx
 1f8365e:	xor    %eax,%eax
 1f83660:	cmp    (%rcx,%r13,4),%edx
 1f83664:	setne  %al
 1f83667:	jmp    1f8367c <node_facts_window_run+0x626c>
 1f83669:	mov    0x28(%rsp),%rbp
 1f8366e:	mov    0x18(%rsp),%r12
 1f83673:	mov    0x8(%rsp),%rbx
 1f83678:	jmp    1f8367c <node_facts_window_run+0x626c>
 1f8367a:	xor    %eax,%eax
 1f8367c:	mov    0x20(%rsp),%r13
 1f83681:	add    %rax,%r14
 1f83684:	cmp    $0x2,%r10b
 1f83688:	sete   %al
 1f8368b:	cmp    $0x3,%r8b
 1f8368f:	sete   %cl
 1f83692:	xor    %cl,%al
 1f83694:	test   %r14,%r14
 1f83697:	vmovd  %ecx,%xmm1
 1f8369b:	setne  %dl
 1f8369e:	incq   0xac8(%r12)
 1f836a6:	add    %r9,%rbx
 1f836a9:	or     %al,%dl
 1f836ab:	vpinsrb $0x1,%edx,%xmm1,%xmm1
 1f836b1:	vpmovzxbq %xmm1,%xmm1
 1f836b6:	vptestmq %xmm0,%xmm1,%k0
 1f836bc:	vmovdqu 0xad8(%r12),%xmm1
 1f836c6:	vpmovm2q %k0,%xmm2
 1f836cc:	vpsubq %xmm2,%xmm1,%xmm1
 1f836d0:	vmovdqu %xmm1,0xad8(%r12)
 1f836da:	add    %r14,0xae8(%r12)
 1f836e2:	mov    0xb78(%r11),%rax
 1f836e9:	mov    (%rax,%rdi,8),%rax
 1f836ed:	add    %rax,0xb30(%r12)
 1f836f5:	cmp    $0x1,%dl
 1f836f8:	jne    1f8326a <node_facts_window_run+0x5e5a>
 1f836fe:	mov    0x1368(%r12),%eax
 1f83706:	cmp    $0xf,%rax
 1f8370a:	ja     1f8326a <node_facts_window_run+0x5e5a>
 1f83710:	mov    0x422c(%rbp,%r13,4),%ecx
 1f83718:	mov    %ecx,0x1328(%r12,%rax,4)
 1f83720:	incl   0x1368(%r12)
 1f83728:	jmp    1f8326a <node_facts_window_run+0x5e5a>
 1f8372d:	mov    $0x3,%esi
 1f83732:	jmp    1f83262 <node_facts_window_run+0x5e52>
 1f83737:	mov    $0x1,%esi
 1f8373c:	shlx   %r9,%rsi,%r8
 1f83741:	mov    $0x5,%esi
 1f83746:	test   %r8,0x18(%rax,%rdx,8)
 1f8374b:	jne    1f83262 <node_facts_window_run+0x5e52>
 1f83751:	mov    $0x6,%esi
 1f83756:	test   %r8,0x20(%rax,%rdx,8)
 1f8375b:	jne    1f83262 <node_facts_window_run+0x5e52>
 1f83761:	xor    %eax,%eax
 1f83763:	cmp    $0x7,%ecx
 1f83766:	setne  %al
 1f83769:	lea    0x2(%rax,%rax,4),%rsi
 1f8376e:	jmp    1f83262 <node_facts_window_run+0x5e52>
 1f83773:	xor    %ebx,%ebx
 1f83775:	add    %rbx,0xad0(%r12)
 1f8377d:	mov    0xb8(%rsp),%rdx
 1f83785:	mov    0xb0(%rsp),%rsi
 1f8378d:	mov    0x40(%rsp),%rcx
 1f83792:	vmovd  0x160(%rsp),%xmm4
 1f8379b:	vmovdqu 0xb78(%r12),%xmm0
 1f837a5:	vmovq  0x8b0(%rsp),%xmm1
 1f837ae:	vpaddq 0x8d8(%rsp),%xmm0,%xmm0
 1f837b7:	vmovdqu %xmm0,0xb78(%r12)
 1f837c1:	mov    0x8e8(%rsp),%rax
 1f837c9:	add    %rax,0xb88(%r12)
 1f837d1:	mov    %rdx,%rax
 1f837d4:	sub    %rsi,%rax
 1f837d7:	sub    %rcx,%rsi
 1f837da:	sub    0x50(%rsp),%rcx
 1f837df:	vmovdqu64 0x890(%rsp),%zmm0
 1f837ea:	vmovq  %rax,%xmm2
 1f837ef:	vmovq  %rsi,%xmm3
 1f837f4:	mov    0x1a0(%rsp),%rsi
 1f837fc:	mov    0xa8(%rsp),%rax
 1f83804:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f83808:	vmovq  %rcx,%xmm3
 1f8380d:	mov    0xa0(%rsp),%rcx
 1f83815:	vpunpcklqdq %xmm3,%xmm4,%xmm3
 1f83819:	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
 1f8381f:	vshufi64x2 $0x44,%zmm2,%zmm0,%zmm0
 1f83826:	vpaddq 0xaf0(%r12),%zmm0,%zmm0
 1f83831:	sub    %rcx,%rsi
 1f83834:	sub    %rax,%rcx
 1f83837:	sub    %rdx,%rax
 1f8383a:	vmovq  %rsi,%xmm3
 1f8383f:	vmovq  %rax,%xmm2
 1f83844:	vpunpcklqdq %xmm1,%xmm3,%xmm1
 1f83848:	vmovdqu64 %zmm0,0xaf0(%r12)
 1f83853:	vmovq  %rcx,%xmm0
 1f83858:	vpunpcklqdq %xmm0,%xmm2,%xmm0
 1f8385c:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f83862:	vinserti64x4 $0x1,0x1e0(%rsp),%zmm0,%zmm0
 1f8386b:	vpaddq 0xb38(%r12),%zmm0,%zmm0
 1f83876:	vmovdqu64 %zmm0,0xb38(%r12)
 1f83881:	cmpq   $0x0,0xc20(%r11)
 1f83889:	je     1f84d56 <node_facts_window_run+0x7946>
 1f8388f:	mov    0x940(%r11),%rax
 1f83896:	mov    0x8(%rbp),%r12d
 1f8389a:	vpxor  %xmm0,%xmm0,%xmm0
 1f8389e:	vmovdqu %ymm0,0x890(%rsp)
 1f838a7:	movq   $0x0,0x8b0(%rsp)
 1f838b3:	mov    %r11,%rdi
 1f838b6:	mov    %rax,0x1a0(%rsp)
 1f838be:	rdtsc
 1f838c0:	mov    %r12d,%esi
 1f838c3:	mov    %rdx,0x4d0(%rsp)
 1f838cb:	lea    0x890(%rsp),%rdx
 1f838d3:	mov    %rax,%r14
 1f838d6:	vzeroupper
 1f838d9:	call   1f96460 <node_rows_window_reads>
 1f838de:	rdtsc
 1f838e0:	mov    %rbp,%rsi
 1f838e3:	mov    %rdx,0x3d0(%rsp)
 1f838eb:	mov    %r12d,%edx
 1f838ee:	mov    (%rsp),%rdi
 1f838f2:	mov    %rax,%r15
 1f838f5:	call   1f96b80 <node_rows_window_shapes>
 1f838fa:	mov    (%rsp),%rdi
 1f838fe:	rdtsc
 1f83900:	mov    0xc10(%rdi),%rcx
 1f83907:	or     0xc08(%rdi),%rcx
 1f8390e:	mov    %rax,0x60(%rsp)
 1f83913:	mov    %rdx,0x490(%rsp)
 1f8391b:	je     1f83934 <node_facts_window_run+0x6524>
 1f8391d:	lea    0x890(%rsp),%rcx
 1f83925:	mov    %rbp,%rsi
 1f83928:	mov    %r12d,%edx
 1f8392b:	call   1f96fb0 <node_rows_window_updates>
 1f83930:	mov    (%rsp),%rdi
 1f83934:	rdtsc
 1f83936:	mov    %rbp,%rsi
 1f83939:	mov    %rdx,0x2d0(%rsp)
 1f83941:	mov    %r12d,%edx
 1f83944:	mov    %rax,0x350(%rsp)
 1f8394c:	call   1f977c0 <node_rows_window_write>
 1f83951:	mov    %eax,%ecx
 1f83953:	rdtsc
 1f83955:	mov    0x8a0(%rsp),%r8
 1f8395d:	mov    0x8b0(%rsp),%r9d
 1f83965:	vpxor  %xmm0,%xmm0,%xmm0
 1f83969:	vmovdqu %xmm0,0x51c(%rsp)
 1f83972:	vmovdqa %xmm0,0x510(%rsp)
 1f8397b:	movl   $0x0,0xfc(%rsp)
 1f83986:	movq   $0x0,0x288(%rsp)
 1f83992:	mov    %rax,0x390(%rsp)
 1f8399a:	mov    %rdx,0x450(%rsp)
 1f839a2:	sub    $0x8,%rsp
 1f839a6:	mov    0x8(%rsp),%rdi
 1f839ab:	lea    0x290(%rsp),%rax
 1f839b3:	lea    0x104(%rsp),%r10
 1f839bb:	lea    0x518(%rsp),%r11
 1f839c3:	mov    %rbp,%rsi
 1f839c6:	mov    %r12d,%edx
 1f839c9:	mov    %ecx,0x298(%rsp)
 1f839d0:	push   %rax
 1f839d1:	push   %r10
 1f839d3:	push   %r11
 1f839d5:	call   1f97de0 <node_rows_window_values>
 1f839da:	add    $0x20,%rsp
 1f839de:	rdtsc
 1f839e0:	mov    %rbp,%rsi
 1f839e3:	mov    %rdx,0x5b0(%rsp)
 1f839eb:	mov    %rax,0x310(%rsp)
 1f839f3:	mov    (%rsp),%rdi
 1f839f7:	call   1f98c80 <node_rows_window_part>
 1f839fc:	mov    (%rsp),%rdi
 1f83a00:	rdtsc
 1f83a02:	movl   $0x0,0xd0(%rsp)
 1f83a0d:	movq   $0x0,0xc8(%rsp)
 1f83a19:	cmpb   $0x1,0xd58(%rdi)
 1f83a20:	mov    %rax,0x220(%rsp)
 1f83a28:	mov    %rdx,0x570(%rsp)
 1f83a30:	jne    1f83a49 <node_facts_window_run+0x6639>
 1f83a32:	lea    0xc8(%rsp),%rcx
 1f83a3a:	mov    %rbp,%rsi
 1f83a3d:	mov    %r12d,%edx
 1f83a40:	call   1f98d90 <node_rows_window_summary>
 1f83a45:	mov    (%rsp),%rdi
 1f83a49:	rdtsc
 1f83a4b:	mov    0xdc0(%rdi),%ecx
 1f83a51:	movl   $0x0,0xdc0(%rdi)
 1f83a5b:	mov    0xa90(%rdi),%r13d
 1f83a62:	cmpb   $0x0,0xdc4(%rdi)
 1f83a69:	mov    %rcx,0x268(%rsp)
 1f83a71:	mov    %rax,0x88(%rsp)
 1f83a79:	mov    %rdx,0x530(%rsp)
 1f83a81:	je     1f83ab2 <node_facts_window_run+0x66a2>
 1f83a83:	mov    0xdcc(%rdi),%ecx
 1f83a89:	mov    $0x1,%esi
 1f83a8e:	mov    %ecx,%ebx
 1f83a90:	inc    %ecx
 1f83a92:	and    $0x3,%ebx
 1f83a95:	mov    %ecx,0xdcc(%rdi)
 1f83a9b:	mov    0xc8(%rsp),%ebp
 1f83aa2:	cmp    $0x2,%ebx
 1f83aa5:	jne    1f84981 <node_facts_window_run+0x7571>
 1f83aab:	mov    $0x2,%ebx
 1f83ab0:	jmp    1f83acb <node_facts_window_run+0x66bb>
 1f83ab2:	mov    0xc8(%rsp),%ebp
 1f83ab9:	mov    $0xffffffff,%ebx
 1f83abe:	mov    %ebx,%eax
 1f83ac0:	xor    $0x3,%eax
 1f83ac3:	xor    %esi,%esi
 1f83ac5:	or     %ebp,%eax
 1f83ac7:	sete   %sil
 1f83acb:	cmpb   $0x1,0xd58(%rdi)
 1f83ad2:	mov    %esi,0x114(%rsp)
 1f83ad9:	mov    %r15,0x260(%rsp)
 1f83ae1:	mov    %r14,0x70(%rsp)
 1f83ae6:	jne    1f83ba4 <node_facts_window_run+0x6794>
 1f83aec:	mov    0xd98(%rdi),%rsi
 1f83af3:	mov    0xda8(%rdi),%rdi
 1f83afa:	lea    (%r12,%r12,1),%rdx
 1f83afe:	call   355e9f0 <memcpy>
 1f83b03:	mov    (%rsp),%rax
 1f83b07:	mov    (%rsp),%rcx
 1f83b0b:	mov    %r13,%rdx
 1f83b0e:	mov    0xda0(%rax),%rsi
 1f83b15:	mov    0xdb0(%rcx),%rdi
 1f83b1c:	call   355e9f0 <memcpy>
 1f83b21:	mov    (%rsp),%rax
 1f83b25:	mov    (%rsp),%rcx
 1f83b29:	mov    %ebp,%edx
 1f83b2b:	shl    $0x2,%rdx
 1f83b2f:	mov    0xd90(%rax),%rsi
 1f83b36:	mov    0xdb8(%rcx),%rdi
 1f83b3d:	call   355e9f0 <memcpy>
 1f83b42:	mov    (%rsp),%rdi
 1f83b46:	xor    %eax,%eax
 1f83b48:	mov    %r12d,%ecx
 1f83b4b:	sub    $0x1,%ecx
 1f83b4e:	cmovb  %eax,%ecx
 1f83b51:	test   %ebx,%ebx
 1f83b53:	sete   %dl
 1f83b56:	cmp    $0x1,%ebx
 1f83b59:	sete   %sil
 1f83b5d:	test   %r13d,%r13d
 1f83b60:	sete   %r8b
 1f83b64:	mov    0xda8(%rdi),%rax
 1f83b6b:	and    %sil,%r8b
 1f83b6e:	or     %dl,%r8b
 1f83b71:	movzbl %r8b,%edx
 1f83b75:	xor    %dx,(%rax,%rcx,2)
 1f83b79:	test   %r13d,%r13d
 1f83b7c:	mov    0xdb0(%rdi),%rax
 1f83b83:	setne  %cl
 1f83b86:	and    %sil,%cl
 1f83b89:	xor    %cl,(%rax)
 1f83b8b:	cmp    $0x3,%ebx
 1f83b8e:	mov    0xdb8(%rdi),%rdx
 1f83b95:	sete   %al
 1f83b98:	test   %ebp,%ebp
 1f83b9a:	setne  %cl
 1f83b9d:	and    %al,%cl
 1f83b9f:	movzbl %cl,%eax
 1f83ba2:	xor    %eax,(%rdx)
 1f83ba4:	mov    %ebp,0x118(%rsp)
 1f83bab:	mov    %r13,0x630(%rsp)
 1f83bb3:	mov    0xca8(%rdi),%rsi
 1f83bba:	mov    0xcb8(%rdi),%rdi
 1f83bc1:	mov    0x290(%rsp),%r14d
 1f83bc9:	mov    %r14d,%ebx
 1f83bcc:	mov    %rbx,%rdx
 1f83bcf:	call   355e9f0 <memcpy>
 1f83bd4:	mov    (%rsp),%rax
 1f83bd8:	mov    (%rsp),%rcx
 1f83bdc:	mov    %rbx,%rdx
 1f83bdf:	mov    0xcb0(%rax),%rsi
 1f83be6:	mov    0xcc0(%rcx),%rdi
 1f83bed:	call   355e9f0 <memcpy>
 1f83bf2:	mov    (%rsp),%rax
 1f83bf6:	mov    (%rsp),%rcx
 1f83bfa:	lea    0x0(,%rbx,8),%rdx
 1f83c02:	mov    %rbx,0x648(%rsp)
 1f83c0a:	mov    %rdx,0x638(%rsp)
 1f83c12:	mov    0xcc8(%rax),%rsi
 1f83c19:	mov    0xcd0(%rcx),%rdi
 1f83c20:	call   355e9f0 <memcpy>
 1f83c25:	mov    (%rsp),%rax
 1f83c29:	mov    $0xffffffff,%edi
 1f83c2e:	movzbl 0xdd0(%rax),%ecx
 1f83c35:	mov    (%rsp),%rax
 1f83c39:	mov    0xdd8(%rax),%edx
 1f83c3f:	imul   $0x4ec4ec4f,%rdx,%rax
 1f83c46:	shr    $0x22,%rax
 1f83c4a:	lea    (%rax,%rax,2),%esi
 1f83c4d:	lea    (%rax,%rsi,4),%eax
 1f83c50:	mov    %edx,%esi
 1f83c52:	sub    %eax,%esi
 1f83c54:	test   %ecx,%ecx
 1f83c56:	cmovne %esi,%edi
 1f83c59:	xor    %eax,%eax
 1f83c5b:	lea    -0x1(%rdi),%esi
 1f83c5e:	cmp    $0x3,%esi
 1f83c61:	mov    %r12d,%esi
 1f83c64:	cmovae %edi,%eax
 1f83c67:	test   %r14d,%r14d
 1f83c6a:	cmovne %edi,%eax
 1f83c6d:	add    %edx,%ecx
 1f83c6f:	mov    (%rsp),%rdx
 1f83c73:	mov    (%rsp),%rdi
 1f83c77:	cmp    $0x1,%eax
 1f83c7a:	vpbroadcastd %eax,%xmm0
 1f83c80:	vpcmpeqd -0x19bbe98(%rip),%xmm0,%xmm1        # 5c7df0 <.LCPI3_71>
 1f83c88:	vpcmpeqd -0x19bbe90(%rip),%xmm0,%xmm0        # 5c7e00 <.LCPI3_72>
 1f83c90:	mov    %ecx,0xdd8(%rdx)
 1f83c96:	mov    (%rsp),%rcx
 1f83c9a:	sete   %dl
 1f83c9d:	vpsrld $0x1f,%xmm1,%xmm1
 1f83ca2:	vpsrld $0x1f,%xmm0,%xmm0
 1f83ca7:	mov    0xcb8(%rcx),%rcx
 1f83cae:	xor    %dl,(%rcx)
 1f83cb0:	mov    (%rsp),%rcx
 1f83cb4:	cmp    $0x2,%eax
 1f83cb7:	sete   %dl
 1f83cba:	mov    0xcc0(%rcx),%rcx
 1f83cc1:	xor    %dl,(%rcx)
 1f83cc3:	xor    %ecx,%ecx
 1f83cc5:	cmp    $0x3,%eax
 1f83cc8:	mov    0xcd0(%rdi),%rdx
 1f83ccf:	sete   %cl
 1f83cd2:	xor    %rcx,(%rdx)
 1f83cd5:	mov    0xfc(%rsp),%ecx
 1f83cdc:	vmovsd 0x510(%rsp),%xmm2
 1f83ce5:	vmovups 0x51c(%rsp),%xmm3
 1f83cee:	mov    %rcx,0x278(%rsp)
 1f83cf6:	mov    0x288(%rsp),%rcx
 1f83cfe:	mov    %rcx,0x270(%rsp)
 1f83d06:	mov    0x518(%rsp),%ecx
 1f83d0d:	vmovups %ymm2,0x830(%rsp)
 1f83d16:	vshufps $0x24,%xmm3,%xmm2,%xmm2
 1f83d1b:	mov    %rcx,0x650(%rsp)
 1f83d23:	vpinsrd $0x2,%ecx,%xmm2,%xmm2
 1f83d29:	xor    %ecx,%ecx
 1f83d2b:	cmp    $0xc,%eax
 1f83d2e:	vmovaps %xmm3,0x800(%rsp)
 1f83d37:	sete   %cl
 1f83d3a:	xor    0x528(%rsp),%ecx
 1f83d41:	vpxor  %xmm1,%xmm2,%xmm1
 1f83d45:	xor    %ebx,%ebx
 1f83d47:	test   %eax,%eax
 1f83d49:	vmovdqa %xmm1,0x6c0(%rsp)
 1f83d52:	vshufps $0xe9,%xmm3,%xmm3,%xmm1
 1f83d57:	sete   %bpl
 1f83d5b:	cmp    $0x4,%eax
 1f83d5e:	vxorps %xmm0,%xmm1,%xmm0
 1f83d62:	sete   0x5f(%rsp)
 1f83d67:	cmp    $0x5,%eax
 1f83d6a:	vmovlps %xmm0,0x6d0(%rsp)
 1f83d73:	vxorps %xmm0,%xmm0,%xmm0
 1f83d77:	mov    %ecx,0x6d8(%rsp)
 1f83d7e:	rdtsc
 1f83d80:	vmovups %ymm0,0x760(%rsp)
 1f83d89:	movq   $0x0,0x780(%rsp)
 1f83d95:	mov    %rax,0x5f0(%rsp)
 1f83d9d:	mov    %rdx,0xf0(%rsp)
 1f83da5:	sete   0x5e(%rsp)
 1f83daa:	lea    0x760(%rsp),%rdx
 1f83db2:	mov    (%rsp),%rdi
 1f83db6:	vzeroupper
 1f83db9:	call   1f96460 <node_rows_window_reads>
 1f83dbe:	rdtsc
 1f83dc0:	mov    %rdx,0xe8(%rsp)
 1f83dc8:	mov    %r12d,%edx
 1f83dcb:	mov    %rax,0x660(%rsp)
 1f83dd3:	mov    0x28(%rsp),%r13
 1f83dd8:	mov    (%rsp),%rdi
 1f83ddc:	mov    %r13,%rsi
 1f83ddf:	call   1f96b80 <node_rows_window_shapes>
 1f83de4:	mov    (%rsp),%rdi
 1f83de8:	rdtsc
 1f83dea:	mov    0xc10(%rdi),%rcx
 1f83df1:	or     0xc08(%rdi),%rcx
 1f83df8:	mov    %rax,0x98(%rsp)
 1f83e00:	mov    %rdx,0x720(%rsp)
 1f83e08:	je     1f83e21 <node_facts_window_run+0x6a11>
 1f83e0a:	lea    0x760(%rsp),%rcx
 1f83e12:	mov    %r13,%rsi
 1f83e15:	mov    %r12d,%edx
 1f83e18:	call   1f96fb0 <node_rows_window_updates>
 1f83e1d:	mov    (%rsp),%rdi
 1f83e21:	rdtsc
 1f83e23:	mov    %bpl,%bl
 1f83e26:	mov    %r13,%rsi
 1f83e29:	mov    %rax,0x48(%rsp)
 1f83e2e:	mov    %rdx,0x430(%rsp)
 1f83e36:	mov    %r12d,%edx
 1f83e39:	call   1f977c0 <node_rows_window_write>
 1f83e3e:	mov    %eax,%ebp
 1f83e40:	rdtsc
 1f83e42:	mov    0x770(%rsp),%r8
 1f83e4a:	mov    0x780(%rsp),%r9d
 1f83e52:	vxorps %xmm0,%xmm0,%xmm0
 1f83e56:	vmovups %xmm0,0x6ac(%rsp)
 1f83e5f:	vmovaps %xmm0,0x6a0(%rsp)
 1f83e68:	movl   $0x0,0xf8(%rsp)
 1f83e73:	movq   $0x0,0x280(%rsp)
 1f83e7f:	mov    %rax,0x80(%rsp)
 1f83e87:	mov    %rdx,0x6e0(%rsp)
 1f83e8f:	sub    $0x8,%rsp
 1f83e93:	mov    0x8(%rsp),%rdi
 1f83e98:	lea    0x288(%rsp),%rax
 1f83ea0:	lea    0x6a8(%rsp),%r11
 1f83ea8:	mov    %r12,0xe8(%rsp)
 1f83eb0:	lea    0x100(%rsp),%r10
 1f83eb8:	mov    %r13,%rsi
 1f83ebb:	mov    %r12d,%edx
 1f83ebe:	mov    %ebp,0x124(%rsp)
 1f83ec5:	mov    %ebp,%ecx
 1f83ec7:	push   %rax
 1f83ec8:	push   %r10
 1f83eca:	push   %r11
 1f83ecc:	call   1f97de0 <node_rows_window_values>
 1f83ed1:	add    $0x20,%rsp
 1f83ed5:	rdtsc
 1f83ed7:	mov    %r13,%rsi
 1f83eda:	mov    %rdx,0x410(%rsp)
 1f83ee2:	mov    %rax,0x90(%rsp)
 1f83eea:	mov    (%rsp),%rdi
 1f83eee:	call   1f98c80 <node_rows_window_part>
 1f83ef3:	mov    (%rsp),%r11
 1f83ef7:	rdtsc
 1f83ef9:	movl   $0x0,0x108(%rsp)
 1f83f04:	movq   $0x0,0x100(%rsp)
 1f83f10:	cmpb   $0x1,0xd58(%r11)
 1f83f18:	mov    %rax,0x78(%rsp)
 1f83f1d:	mov    %rdx,0x7c0(%rsp)
 1f83f25:	jne    1f83f46 <node_facts_window_run+0x6b36>
 1f83f27:	lea    0x100(%rsp),%rcx
 1f83f2f:	mov    0xe0(%rsp),%rdx
 1f83f37:	mov    %r11,%rdi
 1f83f3a:	mov    %r13,%rsi
 1f83f3d:	call   1f98d90 <node_rows_window_summary>
 1f83f42:	mov    (%rsp),%r11
 1f83f46:	rdtsc
 1f83f48:	mov    0xdc0(%r11),%ecx
 1f83f4f:	xor    %ebx,%r14d
 1f83f52:	movl   $0x0,0xdc0(%r11)
 1f83f5d:	cmpl   $0x0,0xa90(%r11)
 1f83f65:	mov    %rax,0xd8(%rsp)
 1f83f6d:	mov    %rdx,0x640(%rsp)
 1f83f75:	mov    %r14d,0x290(%rsp)
 1f83f7d:	mov    %ecx,0x110(%rsp)
 1f83f84:	mov    0x1a0(%rsp),%rbp
 1f83f8c:	je     1f84837 <node_facts_window_run+0x7427>
 1f83f92:	vpbroadcastq -0x19b5a63(%rip),%xmm2        # 5ce538 <.LCPI3_1>
 1f83f9b:	xor    %r15d,%r15d
 1f83f9e:	jmp    1f83fbf <node_facts_window_run+0x6baf>
 1f83fa0:	mov    (%rsp),%r11
 1f83fa4:	incq   0xbb8(%rbp,%rsi,8)
 1f83fac:	mov    0xa90(%r11),%eax
 1f83fb3:	inc    %r15
 1f83fb6:	cmp    %rax,%r15
 1f83fb9:	jae    1f84837 <node_facts_window_run+0x7427>
 1f83fbf:	mov    0xd40(%r11),%rax
 1f83fc6:	movzbl (%rax,%r15,1),%eax
 1f83fcb:	test   %al,%al
 1f83fcd:	je     1f83fac <node_facts_window_run+0x6b9c>
 1f83fcf:	mov    0xa70(%r11),%rdx
 1f83fd6:	mov    0xa68(%r11),%rcx
 1f83fdd:	mov    (%rdx,%r15,4),%edx
 1f83fe1:	mov    (%rcx,%r15,4),%r14d
 1f83fe5:	mov    0x651b8(%r13,%rdx,4),%edi
 1f83fed:	incq   0xb90(%rbp)
 1f83ff4:	mov    0xa58(%r11),%rcx
 1f83ffb:	mov    (%rcx,%r15,4),%ecx
 1f83fff:	add    %rcx,0xb98(%rbp)
 1f84006:	cmp    $0x1,%al
 1f84008:	jne    1f84070 <node_facts_window_run+0x6c60>
 1f8400a:	mov    0xa58(%r11),%rax
 1f84011:	mov    $0x1,%esi
 1f84016:	mov    (%rax,%r15,4),%r10d
 1f8401a:	test   %r10d,%r10d
 1f8401d:	je     1f83fa4 <node_facts_window_run+0x6b94>
 1f8401f:	mov    0xbe8(%r11),%rax
 1f84026:	sub    %edi,%edx
 1f84028:	xor    %ecx,%ecx
 1f8402a:	xor    %r11d,%r11d
 1f8402d:	inc    %edx
 1f8402f:	nop
 1f84030:	lea    (%rdx,%r11,1),%r9d
 1f84034:	cmp    %edi,%r11d
 1f84037:	cmovae %r14d,%r9d
 1f8403b:	mov    %r9d,%r8d
 1f8403e:	shr    $0x3,%r8d
 1f84042:	and    $0xfffffff8,%r8d
 1f84046:	mov    0x28(%rax,%r8,8),%rbx
 1f8404b:	bt     %r9,%rbx
 1f8404f:	jb     1f843c0 <node_facts_window_run+0x6fb0>
 1f84055:	inc    %r11d
 1f84058:	cmp    %r11d,%r10d
 1f8405b:	jne    1f84030 <node_facts_window_run+0x6c20>
 1f8405d:	jmp    1f83fa0 <node_facts_window_run+0x6b90>
 1f84062:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f84070:	mov    0xa68(%r11),%rcx
 1f84077:	mov    0xa70(%r11),%rdx
 1f8407e:	mov    0xa58(%r11),%rax
 1f84085:	xor    %r9d,%r9d
 1f84088:	mov    (%rcx,%r15,4),%ecx
 1f8408c:	mov    %rcx,0x10(%rsp)
 1f84091:	mov    (%rdx,%r15,4),%ecx
 1f84095:	mov    0xc40(%r11),%rdx
 1f8409c:	mov    0x651b8(%r13,%rcx,4),%esi
 1f840a4:	cmp    %esi,(%rax,%r15,4)
 1f840a8:	jbe    1f840b4 <node_facts_window_run+0x6ca4>
 1f840aa:	mov    0x10(%rsp),%rax
 1f840af:	movzbl (%rdx,%rax,1),%r9d
 1f840b4:	mov    0xc60(%r11),%r8
 1f840bb:	mov    0xc80(%r11),%r10
 1f840c2:	mov    %ecx,%edi
 1f840c4:	sub    %esi,%edi
 1f840c6:	mov    %ecx,%esi
 1f840c8:	shr    $0x3,%esi
 1f840cb:	mov    0x940(%r11),%rax
 1f840d2:	inc    %edi
 1f840d4:	movzbl (%r8,%rdi,1),%ebx
 1f840d9:	shr    $0x3,%edi
 1f840dc:	mov    (%r10,%rsi,4),%r12d
 1f840e0:	mov    0xa50(%r11),%rsi
 1f840e7:	mov    %r10,0x18(%rsp)
 1f840ec:	mov    %r8,0x20(%rsp)
 1f840f1:	add    (%r10,%rdi,4),%ebx
 1f840f5:	movzbl (%r8,%rcx,1),%edi
 1f840fa:	movzbl (%rdx,%rcx,1),%r10d
 1f840ff:	mov    %r12d,%ecx
 1f84102:	mov    (%rsi,%r15,4),%esi
 1f84106:	mov    %rbx,0x8(%rsp)
 1f8410b:	sub    %ebx,%ecx
 1f8410d:	mov    0x130(%rax),%rbx
 1f84114:	add    %edi,%ecx
 1f84116:	add    %r10d,%ecx
 1f84119:	add    %ecx,%r9d
 1f8411c:	mov    (%rbx,%rsi,4),%r8d
 1f84120:	cmp    $0xffffffff,%r8d
 1f84124:	je     1f843b5 <node_facts_window_run+0x6fa5>
 1f8412a:	mov    %r12d,0x160(%rsp)
 1f84132:	mov    %r10,0x50(%rsp)
 1f84137:	mov    %rdi,0x1e0(%rsp)
 1f8413f:	mov    0xdd4(%r11),%r10d
 1f84146:	movzbl 0xdd0(%r11),%edi
 1f8414e:	mov    $0x4,%edx
 1f84153:	mov    %r14,0xb0(%rsp)
 1f8415b:	mov    %r10d,%ebx
 1f8415e:	and    $0x3,%ebx
 1f84161:	test   %edi,%edi
 1f84163:	mov    %r10d,0xb8(%rsp)
 1f8416b:	cmove  %edx,%ebx
 1f8416e:	test   $0x4,%r10b
 1f84172:	movabs $0x8000000000000000,%r10
 1f8417c:	mov    $0x1,%edx
 1f84181:	cmove  %rdx,%r10
 1f84185:	test   %r8d,%r8d
 1f84188:	sete   %dl
 1f8418b:	mov    %r10,0x30(%rsp)
 1f84190:	mov    %edi,0xa0(%rsp)
 1f84197:	mov    %r8d,0xa8(%rsp)
 1f8419f:	mov    %r9,0x40(%rsp)
 1f841a4:	and    %dil,%dl
 1f841a7:	cmp    $0x2,%ebx
 1f841aa:	sete   %dil
 1f841ae:	or     %dl,%dil
 1f841b1:	movzbl %dil,%edx
 1f841b5:	add    %r8d,%edx
 1f841b8:	mov    0x110(%rax),%r8
 1f841bf:	cmp    $0x3,%ebx
 1f841c2:	sete   %dil
 1f841c6:	cmpb   $0x0,(%r8,%rsi,1)
 1f841cb:	setne  %r8b
 1f841cf:	cmp    %edx,%r9d
 1f841d2:	setne  %r12b
 1f841d6:	xor    %r10d,%r10d
 1f841d9:	or     %r8b,%r12b
 1f841dc:	jne    1f84519 <node_facts_window_run+0x7109>
 1f841e2:	test   %edx,%edx
 1f841e4:	je     1f84519 <node_facts_window_run+0x7109>
 1f841ea:	mov    0x128(%rax),%rdx
 1f841f1:	mov    0x140(%rax),%rbp
 1f841f8:	mov    %ecx,%ecx
 1f841fa:	mov    (%rdx,%rsi,4),%edx
 1f841fd:	mov    0x148(%rax),%rsi
 1f84204:	add    %rdx,%rsi
 1f84207:	add    %rdx,%rbp
 1f8420a:	shl    $0x3,%rdx
 1f8420e:	add    0x150(%rax),%rdx
 1f84215:	cmp    $0x1,%ebx
 1f84218:	mov    %rsi,0x68(%rsp)
 1f8421d:	sete   %al
 1f84220:	cmp    $0x3,%ebx
 1f84223:	mov    %rdx,0x38(%rsp)
 1f84228:	sete   %dl
 1f8422b:	mov    0x40(%rsp),%r8
 1f84230:	cmp    $0x2,%r8d
 1f84234:	lea    -0x1(%r8),%r13d
 1f84238:	mov    %r8d,%r8d
 1f8423b:	setae  %sil
 1f8423f:	and    %al,%sil
 1f84242:	mov    0x10(%rsp),%rax
 1f84247:	shr    $0x3,%eax
 1f8424a:	mov    %rax,0x120(%rsp)
 1f84252:	or     %dl,%sil
 1f84255:	mov    (%rsp),%rax
 1f84259:	mov    0xca8(%rax),%r11
 1f84260:	test   %sil,%sil
 1f84263:	je     1f84425 <node_facts_window_run+0x7015>
 1f84269:	mov    0xb8(%rsp),%eax
 1f84270:	xor    %esi,%esi
 1f84272:	and    $0x8,%eax
 1f84275:	shr    $0x3,%eax
 1f84278:	and    %al,%dil
 1f8427b:	mov    $0x0,%edi
 1f84280:	mov    0x8(%rsp),%rax
 1f84285:	cmovne %r13,%rdi
 1f84289:	sub    0x160(%rsp),%eax
 1f84290:	neg    %r13
 1f84293:	xor    %r14d,%r14d
 1f84296:	sub    0x50(%rsp),%eax
 1f8429a:	neg    %rdi
 1f8429d:	sub    0x1e0(%rsp),%eax
 1f842a4:	mov    %rax,0x50(%rsp)
 1f842a9:	mov    $0x1,%eax
 1f842ae:	mov    %r13,0x1e0(%rsp)
 1f842b6:	jmp    1f842da <node_facts_window_run+0x6eca>
 1f842b8:	nopl   0x0(%rax,%rax,1)
 1f842c0:	inc    %rsi
 1f842c3:	cmp    %r8,%rax
 1f842c6:	mov    %r10d,%r14d
 1f842c9:	setae  %dl
 1f842cc:	inc    %rax
 1f842cf:	or     %r12b,%dl
 1f842d2:	test   %dl,%dl
 1f842d4:	jne    1f84519 <node_facts_window_run+0x7109>
 1f842da:	lea    -0x1(%rax),%rdx
 1f842de:	cmp    %rcx,%rdx
 1f842e1:	jae    1f842f0 <node_facts_window_run+0x6ee0>
 1f842e3:	mov    0x8(%rsp),%rdx
 1f842e8:	lea    (%rdx,%rsi,1),%r9d
 1f842ec:	mov    %esi,%edx
 1f842ee:	jmp    1f84321 <node_facts_window_run+0x6f11>
 1f842f0:	mov    0x10(%rsp),%rdx
 1f842f5:	mov    0x20(%rsp),%r9
 1f842fa:	mov    0x18(%rsp),%r12
 1f842ff:	mov    0x120(%rsp),%r10
 1f84307:	movzbl (%r9,%rdx,1),%r9d
 1f8430c:	mov    0x50(%rsp),%rdx
 1f84311:	add    (%r12,%r10,4),%r9d
 1f84315:	lea    (%rdx,%rax,1),%r10d
 1f84319:	lea    -0x1(%rax),%edx
 1f8431c:	lea    -0x1(%r10,%r9,1),%r9d
 1f84321:	or     %ebx,%edx
 1f84323:	lea    (%rdi,%rax,1),%r10
 1f84327:	mov    $0x0,%edx
 1f8432c:	mov    $0x1,%r12b
 1f8432f:	mov    %r9d,%r9d
 1f84332:	sete   %r13b
 1f84336:	xor    -0x1(%rbp,%rax,1),%r13b
 1f8433b:	cmp    $0x1,%r10
 1f8433f:	mov    $0x1,%r10b
 1f84342:	cmove  0x30(%rsp),%rdx
 1f84348:	cmp    %r13b,(%r11,%r9,1)
 1f8434c:	jne    1f84389 <node_facts_window_run+0x6f79>
 1f8434e:	mov    0x1e0(%rsp),%r12
 1f84356:	cmp    $0x1,%ebx
 1f84359:	sete   %r13b
 1f8435d:	add    %rax,%r12
 1f84360:	cmp    $0x1,%r12
 1f84364:	sete   %r12b
 1f84368:	and    %r13b,%r12b
 1f8436b:	mov    0x68(%rsp),%r13
 1f84370:	xor    -0x1(%r13,%rax,1),%r12b
 1f84375:	mov    (%rsp),%r13
 1f84379:	mov    0xcb0(%r13),%r13
 1f84380:	cmp    %r12b,0x0(%r13,%r9,1)
 1f84385:	setne  %r12b
 1f84389:	test   $0x1,%r14b
 1f8438d:	jne    1f842c0 <node_facts_window_run+0x6eb0>
 1f84393:	mov    0x38(%rsp),%r10
 1f84398:	mov    (%rsp),%r14
 1f8439c:	xor    -0x8(%r10,%rax,8),%rdx
 1f843a1:	mov    0xcc8(%r14),%r10
 1f843a8:	cmp    %rdx,(%r10,%r9,8)
 1f843ac:	setne  %r10b
 1f843b0:	jmp    1f842c0 <node_facts_window_run+0x6eb0>
 1f843b5:	xor    %r10d,%r10d
 1f843b8:	xor    %r12d,%r12d
 1f843bb:	jmp    1f84554 <node_facts_window_run+0x7144>
 1f843c0:	mov    (%rsp),%r11
 1f843c4:	mov    %r9d,%edx
 1f843c7:	mov    0xbb0(%r11),%rsi
 1f843ce:	movzbl (%rsi,%rdx,1),%esi
 1f843d2:	and    $0x3f,%sil
 1f843d6:	cmp    $0x14,%sil
 1f843da:	je     1f843ec <node_facts_window_run+0x6fdc>
 1f843dc:	mov    0xc30(%r11),%rsi
 1f843e3:	xor    %ecx,%ecx
 1f843e5:	cmpb   $0x7f,(%rsi,%rdx,1)
 1f843e9:	setne  %cl
 1f843ec:	and    $0x3f,%r9d
 1f843f0:	mov    $0x1,%edx
 1f843f5:	mov    $0x2,%esi
 1f843fa:	shlx   %r9,%rdx,%rdx
 1f843ff:	test   %rdx,0x30(%rax,%r8,8)
 1f84404:	jne    1f83fa4 <node_facts_window_run+0x6b94>
 1f8440a:	test   %rdx,0x38(%rax,%r8,8)
 1f8440f:	mov    $0x3,%eax
 1f84414:	cmovne %rax,%rcx
 1f84418:	incq   0xbb8(%rbp,%rcx,8)
 1f84420:	jmp    1f83fac <node_facts_window_run+0x6b9c>
 1f84425:	mov    0x8(%rsp),%rax
 1f8442a:	sub    0x160(%rsp),%eax
 1f84431:	xor    %esi,%esi
 1f84433:	xor    %edi,%edi
 1f84435:	sub    0x50(%rsp),%eax
 1f84439:	sub    0x1e0(%rsp),%eax
 1f84440:	jmp    1f84468 <node_facts_window_run+0x7058>
 1f84442:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f84450:	inc    %rsi
 1f84453:	mov    %r10d,%edi
 1f84456:	cmp    %r8,%rsi
 1f84459:	setae  %dl
 1f8445c:	or     %r12b,%dl
 1f8445f:	cmp    $0x1,%dl
 1f84462:	je     1f84519 <node_facts_window_run+0x7109>
 1f84468:	cmp    %rcx,%rsi
 1f8446b:	jae    1f84480 <node_facts_window_run+0x7070>
 1f8446d:	mov    0x8(%rsp),%rdx
 1f84472:	add    %esi,%edx
 1f84474:	jmp    1f844a4 <node_facts_window_run+0x7094>
 1f84476:	cs nopw 0x0(%rax,%rax,1)
 1f84480:	mov    0x10(%rsp),%rdx
 1f84485:	mov    0x20(%rsp),%r9
 1f8448a:	mov    0x120(%rsp),%r10
 1f84492:	movzbl (%r9,%rdx,1),%edx
 1f84497:	mov    0x18(%rsp),%r9
 1f8449c:	add    (%r9,%r10,4),%edx
 1f844a0:	add    %eax,%edx
 1f844a2:	add    %esi,%edx
 1f844a4:	mov    %esi,%r9d
 1f844a7:	or     %ebx,%r9d
 1f844aa:	mov    $0x1,%r10b
 1f844ad:	mov    $0x1,%r12b
 1f844b0:	mov    %edx,%edx
 1f844b2:	sete   %r9b
 1f844b6:	xor    0x0(%rbp,%rsi,1),%r9b
 1f844bb:	cmp    %r9b,(%r11,%rdx,1)
 1f844bf:	jne    1f844ee <node_facts_window_run+0x70de>
 1f844c1:	cmp    $0x1,%ebx
 1f844c4:	sete   %r9b
 1f844c8:	cmp    %rsi,%r13
 1f844cb:	sete   %r14b
 1f844cf:	and    %r9b,%r14b
 1f844d2:	mov    0x68(%rsp),%r9
 1f844d7:	xor    (%r9,%rsi,1),%r14b
 1f844db:	mov    (%rsp),%r9
 1f844df:	mov    0xcb0(%r9),%r9
 1f844e6:	cmp    %r14b,(%r9,%rdx,1)
 1f844ea:	setne  %r12b
 1f844ee:	test   $0x1,%dil
 1f844f2:	jne    1f84450 <node_facts_window_run+0x7040>
 1f844f8:	mov    0x38(%rsp),%rdi
 1f844fd:	mov    (%rsp),%r9
 1f84501:	mov    (%rdi,%rsi,8),%rdi
 1f84505:	mov    0xcc8(%r9),%r9
 1f8450c:	cmp    %rdi,(%r9,%rdx,8)
 1f84510:	setne  %r10b
 1f84514:	jmp    1f84450 <node_facts_window_run+0x7040>
 1f84519:	mov    0xb8(%rsp),%eax
 1f84520:	mov    (%rsp),%r11
 1f84524:	mov    0x28(%rsp),%r13
 1f84529:	mov    0x1a0(%rsp),%rbp
 1f84531:	mov    0xb0(%rsp),%r14
 1f84539:	mov    0x40(%rsp),%r9
 1f8453e:	mov    0xa8(%rsp),%r8d
 1f84546:	add    0xa0(%rsp),%eax
 1f8454d:	mov    %eax,0xdd4(%r11)
 1f84554:	cmp    $0xffffffff,%r8d
 1f84558:	vmovd  %r9d,%xmm1
 1f8455d:	mov    %r12d,%ecx
 1f84560:	sete   %al
 1f84563:	incq   0xba0(%rbp)
 1f8456a:	or     %r10b,%r12b
 1f8456d:	xor    $0x1,%cl
 1f84570:	mov    0xa58(%r11),%rdx
 1f84577:	and    %r10b,%cl
 1f8457a:	vmovd  (%rdx,%r15,4),%xmm0
 1f84580:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f84584:	vpaddq 0xba8(%rbp),%xmm0,%xmm0
 1f8458c:	vmovdqu %xmm0,0xba8(%rbp)
 1f84594:	vmovd  %r12d,%xmm0
 1f84599:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f8459f:	movzbl %cl,%eax
 1f845a2:	vpmovzxbq %xmm0,%xmm0
 1f845a7:	vptestmq %xmm2,%xmm0,%k0
 1f845ad:	vmovdqu 0xbd8(%rbp),%xmm0
 1f845b5:	vpmovm2q %k0,%xmm1
 1f845bb:	vpsubq %xmm1,%xmm0,%xmm0
 1f845bf:	vmovdqu %xmm0,0xbd8(%rbp)
 1f845c7:	add    %rax,0xcc0(%rbp)
 1f845ce:	mov    0xd48(%r11),%rax
 1f845d5:	mov    (%rax,%r15,8),%rax
 1f845d9:	add    %rax,0xc48(%rbp)
 1f845e0:	test   $0x1,%r12b
 1f845e4:	je     1f84610 <node_facts_window_run+0x7200>
 1f845e6:	mov    0x13ac(%rbp),%eax
 1f845ec:	cmp    $0xf,%rax
 1f845f0:	ja     1f83fac <node_facts_window_run+0x6b9c>
 1f845f6:	mov    0x422c(%r13,%r14,4),%ecx
 1f845fe:	mov    %ecx,0x136c(%rbp,%rax,4)
 1f84605:	incl   0x13ac(%rbp)
 1f8460b:	jmp    1f83fac <node_facts_window_run+0x6b9c>
 1f84610:	cmpb   $0x1,0xd58(%r11)
 1f84618:	jne    1f83fac <node_facts_window_run+0x6b9c>
 1f8461e:	mov    0xda0(%r11),%rax
 1f84625:	mov    $0x4,%r12d
 1f8462b:	movzbl (%rax,%r15,1),%r14d
 1f84630:	incq   0xce8(%rbp)
 1f84637:	mov    0xa70(%r11),%rax
 1f8463e:	mov    0xd98(%r11),%rcx
 1f84645:	mov    (%rax,%r15,4),%eax
 1f84649:	lea    0x1(%rax),%edx
 1f8464c:	movzwl -0x2(%rcx,%rdx,2),%ebp
 1f84651:	sub    0x651b8(%r13,%rax,4),%edx
 1f84659:	cmpb   $0x1,0xdc4(%r11)
 1f84661:	movzwl -0x2(%rcx,%rdx,2),%eax
 1f84666:	jne    1f84679 <node_facts_window_run+0x7269>
 1f84668:	mov    0xdc8(%r11),%r12d
 1f8466f:	and    $0x3,%r12d
 1f84673:	je     1f8473e <node_facts_window_run+0x732e>
 1f84679:	cmp    $0x1,%r12d
 1f8467d:	mov    $0xffffffff,%r8d
 1f84683:	sete   %cl
 1f84686:	cmp    %ax,%bp
 1f84689:	sete   %bl
 1f8468c:	and    %cl,%bl
 1f8468e:	mov    0x940(%r11),%r13
 1f84695:	sub    %eax,%ebp
 1f84697:	cmpq   $0x0,0x168(%r13)
 1f8469f:	je     1f847f4 <node_facts_window_run+0x73e4>
 1f846a5:	mov    0xa50(%r11),%rcx
 1f846ac:	mov    (%rcx,%r15,4),%edx
 1f846b0:	cmp    0x20(%r13),%edx
 1f846b4:	jae    1f847f4 <node_facts_window_run+0x73e4>
 1f846ba:	mov    0x188(%r13),%rdi
 1f846c1:	movzbl %bl,%esi
 1f846c4:	mov    %ebp,%r9d
 1f846c7:	lea    (%rsi,%rdi,1),%rcx
 1f846cb:	add    %r9,%rcx
 1f846ce:	cmp    0x190(%r13),%rcx
 1f846d5:	ja     1f84762 <node_facts_window_run+0x7352>
 1f846db:	cmp    $0xfffe,%ebp
 1f846e1:	ja     1f84762 <node_facts_window_run+0x7352>
 1f846e3:	shl    $0x2,%rdi
 1f846e7:	mov    %r8d,0x18(%rsp)
 1f846ec:	mov    %rsi,0x8(%rsp)
 1f846f1:	lea    0x0(,%rax,4),%esi
 1f846f8:	add    0x180(%r13),%rdi
 1f846ff:	add    0xd90(%r11),%rsi
 1f84706:	mov    %rdx,0x10(%rsp)
 1f8470b:	lea    0x0(,%r9,4),%rdx
 1f84713:	mov    %rdi,0x20(%rsp)
 1f84718:	mov    %r9,0x30(%rsp)
 1f8471d:	call   355e9f0 <memcpy>
 1f84722:	test   %bl,%bl
 1f84724:	je     1f8476b <node_facts_window_run+0x735b>
 1f84726:	mov    0x18(%rsp),%eax
 1f8472a:	mov    0x20(%rsp),%rcx
 1f8472f:	mov    0x30(%rsp),%rdx
 1f84734:	mov    0x10(%rsp),%rsi
 1f84739:	mov    %eax,(%rcx,%rdx,4)
 1f8473c:	jmp    1f84781 <node_facts_window_run+0x7371>
 1f8473e:	xor    %r8d,%r8d
 1f84741:	mov    $0x1,%bl
 1f84743:	xor    %r12d,%r12d
 1f84746:	mov    0x940(%r11),%r13
 1f8474d:	sub    %eax,%ebp
 1f8474f:	cmpq   $0x0,0x168(%r13)
 1f84757:	jne    1f846a5 <node_facts_window_run+0x7295>
 1f8475d:	jmp    1f847f4 <node_facts_window_run+0x73e4>
 1f84762:	incq   0x198(%r13)
 1f84769:	jmp    1f847e5 <node_facts_window_run+0x73d5>
 1f8476b:	mov    0x20(%rsp),%rax
 1f84770:	mov    0x10(%rsp),%rsi
 1f84775:	cmp    $0x1,%r12d
 1f84779:	jne    1f84781 <node_facts_window_run+0x7371>
 1f8477b:	movl   $0x0,(%rax)
 1f84781:	mov    0x188(%r13),%eax
 1f84788:	mov    0x168(%r13),%rcx
 1f8478f:	mov    0x8(%rsp),%rdi
 1f84794:	mov    (%rsp),%r11
 1f84798:	mov    $0x1,%edx
 1f8479d:	vpbroadcastq -0x19b626e(%rip),%xmm2        # 5ce538 <.LCPI3_1>
 1f847a6:	mov    %eax,(%rcx,%rsi,4)
 1f847a9:	add    %ebp,%edi
 1f847ab:	cmp    $0x3,%r12d
 1f847af:	mov    0x170(%r13),%rax
 1f847b6:	sete   %cl
 1f847b9:	add    %cl,%cl
 1f847bb:	cmp    $0x2,%r12d
 1f847bf:	movzbl %cl,%ecx
 1f847c2:	cmove  %edx,%ecx
 1f847c5:	mov    %di,(%rax,%rsi,2)
 1f847c9:	mov    0xda0(%r11),%rax
 1f847d0:	mov    0x178(%r13),%rdx
 1f847d7:	xor    (%rax,%r15,1),%cl
 1f847db:	mov    %cl,(%rdx,%rsi,1)
 1f847de:	add    %rdi,0x188(%r13)
 1f847e5:	movzbl 0xdc4(%r11),%eax
 1f847ed:	add    %eax,0xdc8(%r11)
 1f847f4:	vmovd  %ebp,%xmm1
 1f847f8:	mov    0x1a0(%rsp),%rbp
 1f84800:	mov    $0x101,%eax
 1f84805:	mov    0x28(%rsp),%r13
 1f8480a:	bextr  %eax,%r14d,%eax
 1f8480f:	and    $0x1,%r14d
 1f84813:	vmovd  %eax,%xmm0
 1f84817:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f8481b:	vpaddq 0xcf0(%rbp),%xmm0,%xmm0
 1f84823:	vmovdqu %xmm0,0xcf0(%rbp)
 1f8482b:	add    %r14,0xd00(%rbp)
 1f84832:	jmp    1f83fac <node_facts_window_run+0x6b9c>
 1f84837:	shlq   $0x20,0x4d0(%rsp)
 1f84840:	shlq   $0x20,0x3d0(%rsp)
 1f84849:	shlq   $0x20,0x490(%rsp)
 1f84852:	shlq   $0x20,0x2d0(%rsp)
 1f8485b:	shlq   $0x20,0x450(%rsp)
 1f84864:	shlq   $0x20,0x5b0(%rsp)
 1f8486d:	shlq   $0x20,0x570(%rsp)
 1f84876:	shlq   $0x20,0x530(%rsp)
 1f8487f:	shlq   $0x20,0xf0(%rsp)
 1f84888:	shlq   $0x20,0xe8(%rsp)
 1f84891:	shlq   $0x20,0x720(%rsp)
 1f8489a:	shlq   $0x20,0x430(%rsp)
 1f848a3:	shlq   $0x20,0x6e0(%rsp)
 1f848ac:	shlq   $0x20,0x410(%rsp)
 1f848b5:	shlq   $0x20,0x7c0(%rsp)
 1f848be:	mov    $0x1,%r8d
 1f848c4:	vmovd  0xe0(%rsp),%xmm1
 1f848cd:	mov    0x648(%rsp),%rbx
 1f848d5:	mov    0x640(%rsp),%r12
 1f848dd:	mov    0x11c(%rsp),%eax
 1f848e4:	vmovd  %ebx,%xmm0
 1f848e8:	shl    $0x20,%r12
 1f848ec:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f848f0:	vpaddq 0xbe8(%rbp),%xmm0,%xmm0
 1f848f8:	vmovdqu %xmm0,0xbe8(%rbp)
 1f84900:	cmp    %eax,0x290(%rsp)
 1f84907:	jne    1f84955 <node_facts_window_run+0x7545>
 1f84909:	mov    0xca8(%r11),%rsi
 1f84910:	mov    0xcb8(%r11),%rdi
 1f84917:	mov    %rbx,%rdx
 1f8491a:	mov    %r11,%r14
 1f8491d:	call   355e9e0 <strlen+0x10>
 1f84922:	mov    0xc0(%rsp),%r15
 1f8492a:	mov    0x70(%rsp),%rsi
 1f8492f:	mov    0x260(%rsp),%r13
 1f84937:	test   %eax,%eax
 1f84939:	je     1f84997 <node_facts_window_run+0x7587>
 1f8493b:	mov    %r14,%r11
 1f8493e:	mov    0x60(%rsp),%rax
 1f84943:	mov    0x88(%rsp),%rcx
 1f8494b:	mov    0xd8(%rsp),%r14
 1f84953:	jmp    1f849d2 <node_facts_window_run+0x75c2>
 1f84955:	mov    0xc0(%rsp),%r15
 1f8495d:	mov    0x70(%rsp),%rsi
 1f84962:	mov    0x260(%rsp),%r13
 1f8496a:	mov    0x60(%rsp),%rax
 1f8496f:	mov    0x88(%rsp),%rcx
 1f84977:	mov    0xd8(%rsp),%r14
 1f8497f:	jmp    1f849d8 <node_facts_window_run+0x75c8>
 1f84981:	setb   %al
 1f84984:	test   %r12d,%r12d
 1f84987:	sete   %cl
 1f8498a:	test   %cl,%al
 1f8498c:	je     1f83abe <node_facts_window_run+0x66ae>
 1f84992:	jmp    1f83acb <node_facts_window_run+0x66bb>
 1f84997:	mov    0xcb0(%r14),%rsi
 1f8499e:	mov    0xcc0(%r14),%rdi
 1f849a5:	mov    %rbx,%rdx
 1f849a8:	call   355e9e0 <strlen+0x10>
 1f849ad:	test   %eax,%eax
 1f849af:	je     1f84e2b <node_facts_window_run+0x7a1b>
 1f849b5:	mov    %r14,%r11
 1f849b8:	mov    0x60(%rsp),%rax
 1f849bd:	mov    0x88(%rsp),%rcx
 1f849c5:	mov    0xd8(%rsp),%r14
 1f849cd:	mov    0x70(%rsp),%rsi
 1f849d2:	mov    $0x1,%r8d
 1f849d8:	mov    0x2d0(%rsp),%rdx
 1f849e0:	or     0x4d0(%rsp),%rsi
 1f849e8:	or     0x3d0(%rsp),%r13
 1f849f0:	or     0x490(%rsp),%rax
 1f849f8:	add    %r8,0xbf8(%rbp)
 1f849ff:	or     %r12,%r14
 1f84a02:	or     %rdx,0x350(%rsp)
 1f84a0a:	mov    0x450(%rsp),%rdx
 1f84a12:	or     %rdx,0x390(%rsp)
 1f84a1a:	mov    0x5b0(%rsp),%rdx
 1f84a22:	or     %rdx,0x310(%rsp)
 1f84a2a:	mov    0x570(%rsp),%rdx
 1f84a32:	or     %rdx,0x220(%rsp)
 1f84a3a:	mov    0xf0(%rsp),%rdx
 1f84a42:	or     0x530(%rsp),%rcx
 1f84a4a:	or     %rdx,0x5f0(%rsp)
 1f84a52:	mov    0xe8(%rsp),%rdx
 1f84a5a:	or     %rdx,0x660(%rsp)
 1f84a62:	mov    0x720(%rsp),%rdx
 1f84a6a:	or     %rdx,0x98(%rsp)
 1f84a72:	mov    0x430(%rsp),%rdx
 1f84a7a:	or     %rdx,0x48(%rsp)
 1f84a7f:	mov    0x6e0(%rsp),%rdx
 1f84a87:	or     %rdx,0x80(%rsp)
 1f84a8f:	mov    0x410(%rsp),%rdx
 1f84a97:	or     %rdx,0x90(%rsp)
 1f84a9f:	mov    0x7c0(%rsp),%rdx
 1f84aa7:	or     %rdx,0x78(%rsp)
 1f84aac:	cmpb   $0x1,0xd58(%r11)
 1f84ab4:	jne    1f84b49 <node_facts_window_run+0x7739>
 1f84aba:	mov    0x114(%rsp),%edx
 1f84ac1:	mov    $0x1,%ebx
 1f84ac6:	xor    0x118(%rsp),%edx
 1f84acd:	cmp    0x100(%rsp),%edx
 1f84ad4:	jne    1f84b52 <node_facts_window_run+0x7742>
 1f84ad6:	mov    0xcc(%rsp),%edx
 1f84add:	mov    %rax,0x60(%rsp)
 1f84ae2:	cmp    0x104(%rsp),%edx
 1f84ae9:	jne    1f84b4d <node_facts_window_run+0x773d>
 1f84aeb:	mov    0xd0(%rsp),%eax
 1f84af2:	cmp    0x108(%rsp),%eax
 1f84af9:	jne    1f84b4d <node_facts_window_run+0x773d>
 1f84afb:	mov    %rsi,0x70(%rsp)
 1f84b00:	mov    %rcx,0x88(%rsp)
 1f84b08:	mov    0xd98(%r11),%rsi
 1f84b0f:	mov    0xda8(%r11),%rdi
 1f84b16:	mov    %r11,%r12
 1f84b19:	mov    0xe0(%rsp),%rax
 1f84b21:	lea    (%rax,%rax,1),%rdx
 1f84b25:	call   355e9e0 <strlen+0x10>
 1f84b2a:	test   %eax,%eax
 1f84b2c:	je     1f84efb <node_facts_window_run+0x7aeb>
 1f84b32:	mov    0x60(%rsp),%rax
 1f84b37:	mov    0x88(%rsp),%rcx
 1f84b3f:	mov    0x70(%rsp),%rsi
 1f84b44:	mov    %r12,%r11
 1f84b47:	jmp    1f84b52 <node_facts_window_run+0x7742>
 1f84b49:	xor    %ebx,%ebx
 1f84b4b:	jmp    1f84b52 <node_facts_window_run+0x7742>
 1f84b4d:	mov    0x60(%rsp),%rax
 1f84b52:	vmovd  0x268(%rsp),%xmm1
 1f84b5b:	mov    0x220(%rsp),%rdx
 1f84b63:	vmovd  %ebx,%xmm2
 1f84b67:	mov    0x78(%rsp),%rdi
 1f84b6c:	vpmovzxdq 0x800(%rsp),%ymm7
 1f84b76:	vmovq  0x350(%rsp),%xmm4
 1f84b7f:	vmovq  %r13,%xmm3
 1f84b84:	vmovq  %rsi,%xmm5
 1f84b89:	mov    0x90(%rsp),%rsi
 1f84b91:	mov    0x80(%rsp),%r8
 1f84b99:	sub    %rdx,%rcx
 1f84b9c:	sub    %rdi,%r14
 1f84b9f:	vmovq  %rcx,%xmm0
 1f84ba4:	mov    0x310(%rsp),%rcx
 1f84bac:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84bb0:	vmovd  0xd0(%rsp),%xmm1
 1f84bb9:	sub    %rcx,%rdx
 1f84bbc:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f84bc0:	vmovq  %rax,%xmm2
 1f84bc5:	mov    0x390(%rsp),%rax
 1f84bcd:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f84bd3:	vpaddq 0xd08(%rbp),%ymm0,%ymm0
 1f84bdb:	vmovd  0x278(%rsp),%xmm1
 1f84be4:	vpbroadcastq %rax,%ymm6
 1f84bea:	sub    %rax,%rcx
 1f84bed:	mov    %rsi,%rax
 1f84bf0:	sub    %r8,%rax
 1f84bf3:	vmovdqu %ymm0,0xd08(%rbp)
 1f84bfb:	add    %r14,0xd28(%rbp)
 1f84c02:	vmovq  0x270(%rsp),%xmm0
 1f84c0b:	vpaddq 0xc90(%rbp),%ymm7,%ymm7
 1f84c13:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84c17:	vmovdqu %ymm7,0xc90(%rbp)
 1f84c1f:	vpaddq 0xcb0(%rbp),%xmm0,%xmm0
 1f84c27:	vmovdqu %xmm0,0xcb0(%rbp)
 1f84c2f:	vpunpcklqdq %xmm2,%xmm3,%xmm0
 1f84c33:	vmovq  0x48(%rsp),%xmm2
 1f84c39:	vmovq  0x98(%rsp),%xmm3
 1f84c42:	vinserti128 $0x1,%xmm4,%ymm0,%ymm0
 1f84c48:	vpbroadcastq %r8,%ymm4
 1f84c4e:	vpblendd $0xc0,%ymm6,%ymm0,%ymm1
 1f84c54:	vpermq $0x90,%ymm0,%ymm0
 1f84c5a:	vpbroadcastq %rsi,%ymm6
 1f84c60:	vpblendd $0x3,%ymm5,%ymm0,%ymm0
 1f84c66:	vpbroadcastq %rdi,%ymm5
 1f84c6c:	vpsubq %ymm0,%ymm1,%ymm0
 1f84c70:	vmovdqu 0x890(%rsp),%ymm1
 1f84c79:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f84c7d:	vpblendd $0x30,%ymm4,%ymm2,%ymm3
 1f84c83:	vpermq $0xd0,%ymm2,%ymm2
 1f84c89:	vmovdqa64 -0x1acdf93(%rip),%zmm4        # 4b6d00 <abi_test_hex.digits+0xb980>
 1f84c93:	vpblendd $0xc0,%ymm5,%ymm3,%ymm3
 1f84c99:	vpmovzxdq 0x830(%rsp),%zmm5
 1f84ca4:	vinserti64x4 $0x1,%ymm0,%zmm1,%zmm0
 1f84cab:	vpaddq 0xc00(%rbp),%zmm0,%zmm0
 1f84cb2:	vmovq  %rcx,%xmm1
 1f84cb7:	vmovdqu64 %zmm0,0xc00(%rbp)
 1f84cbe:	vmovq  %rax,%xmm0
 1f84cc3:	mov    0x660(%rsp),%rax
 1f84ccb:	add    %rdx,0xc40(%rbp)
 1f84cd2:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84cd6:	vpmovzxdq 0xc8(%rsp),%xmm1
 1f84ce0:	vmovq  %rax,%xmm7
 1f84ce5:	sub    0x5f0(%rsp),%rax
 1f84ced:	vpblendd $0x3,%ymm7,%ymm2,%ymm2
 1f84cf3:	vpblendd $0xc0,%ymm6,%ymm2,%ymm2
 1f84cf9:	vmovdqa64 -0x1ace043(%rip),%zmm6        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f84d03:	vpsubq %ymm2,%ymm3,%ymm2
 1f84d07:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f84d0d:	vpaddq 0xcc8(%rbp),%ymm0,%ymm0
 1f84d15:	vmovq  %rax,%xmm8
 1f84d1a:	mov    $0x80,%al
 1f84d1c:	kmovd  %eax,%k1
 1f84d20:	mov    0x650(%rsp),%rax
 1f84d28:	vpermi2q %zmm8,%zmm2,%zmm6
 1f84d2e:	vmovdqu %ymm0,0xcc8(%rbp)
 1f84d36:	vpermi2q %zmm5,%zmm6,%zmm4
 1f84d3c:	vpbroadcastq %rax,%zmm4{%k1}
 1f84d42:	vpaddq 0xc50(%rbp),%zmm4,%zmm0
 1f84d4c:	vmovdqu64 %zmm0,0xc50(%rbp)
 1f84d56:	vmovups 0x9d0(%r11),%zmm0
 1f84d60:	vmovups 0x268(%r11),%zmm1
 1f84d6a:	vmovups 0x850(%rsp),%zmm3
 1f84d75:	vmovaps 0x820(%rsp),%xmm2
 1f84d7e:	xor    %esi,%esi
 1f84d80:	mov    %r15,%rdx
 1f84d83:	vmovups %zmm0,0x268(%r11)
 1f84d8d:	vmovups %zmm1,0x9d0(%r11)
 1f84d97:	vmovups 0xa10(%r11),%xmm0
 1f84da0:	vmovups 0x2a8(%r11),%xmm1
 1f84da9:	vmovups %xmm0,0x2a8(%r11)
 1f84db2:	vmovups %xmm1,0xa10(%r11)
 1f84dbb:	vmovaps 0x810(%rsp),%xmm1
 1f84dc4:	mov    0x2b8(%r11),%rax
 1f84dcb:	mov    0xa20(%r11),%rcx
 1f84dd2:	mov    %rcx,0x2b8(%r11)
 1f84dd9:	mov    %rax,0xa20(%r11)
 1f84de0:	mov    0x658(%rsp),%rax
 1f84de8:	vmovups %zmm3,0x1f0(%r11)
 1f84df2:	mov    %rax,0x230(%r11)
 1f84df9:	vmovups %xmm2,0x240(%r11)
 1f84e02:	vmovlps %xmm1,0x258(%r11)
 1f84e0b:	mov    0x9b8(%r11),%rdi
 1f84e12:	add    $0xca8,%rsp
 1f84e19:	pop    %rbx
 1f84e1a:	pop    %r12
 1f84e1c:	pop    %r13
 1f84e1e:	pop    %r14
 1f84e20:	pop    %r15
 1f84e22:	pop    %rbp
 1f84e23:	vzeroupper
 1f84e26:	jmp    355ea60 <memset>
 1f84e2b:	mov    0xcc8(%r14),%rsi
 1f84e32:	mov    0xcd0(%r14),%rdi
 1f84e39:	mov    0x638(%rsp),%rdx
 1f84e41:	call   355e9e0 <strlen+0x10>
 1f84e46:	test   %eax,%eax
 1f84e48:	jne    1f84f7f <node_facts_window_run+0x7b6f>
 1f84e4e:	movzbl 0x5f(%rsp),%ecx
 1f84e53:	xor    %eax,%eax
 1f84e55:	mov    0xd8(%rsp),%r14
 1f84e5d:	mov    $0x1,%r8d
 1f84e63:	mov    %cl,%al
 1f84e65:	xor    0x278(%rsp),%eax
 1f84e6c:	mov    0x88(%rsp),%rcx
 1f84e74:	cmp    0xf8(%rsp),%eax
 1f84e7b:	mov    0x60(%rsp),%rax
 1f84e80:	jne    1f84f88 <node_facts_window_run+0x7b78>
 1f84e86:	movzbl 0x5e(%rsp),%esi
 1f84e8b:	mov    (%rsp),%r11
 1f84e8f:	xor    %edx,%edx
 1f84e91:	mov    %sil,%dl
 1f84e94:	xor    0x270(%rsp),%rdx
 1f84e9c:	cmp    0x280(%rsp),%rdx
 1f84ea4:	jne    1f84f75 <node_facts_window_run+0x7b65>
 1f84eaa:	vmovdqu 0x6cc(%rsp),%xmm1
 1f84eb3:	vmovdqa 0x6c0(%rsp),%xmm0
 1f84ebc:	mov    0x70(%rsp),%rsi
 1f84ec1:	vpxor  0x6a0(%rsp),%xmm0,%xmm0
 1f84eca:	vpternlogq $0xf6,0x6ac(%rsp),%xmm1,%xmm0
 1f84ed6:	vptest %xmm0,%xmm0
 1f84edb:	jne    1f849d8 <node_facts_window_run+0x75c8>
 1f84ee1:	mov    0x110(%rsp),%edx
 1f84ee8:	xor    %r8d,%r8d
 1f84eeb:	cmp    %edx,0x268(%rsp)
 1f84ef2:	setne  %r8b
 1f84ef6:	jmp    1f849d8 <node_facts_window_run+0x75c8>
 1f84efb:	mov    0xda0(%r12),%rsi
 1f84f03:	mov    0xdb0(%r12),%rdi
 1f84f0b:	mov    0x630(%rsp),%rdx
 1f84f13:	call   355e9e0 <strlen+0x10>
 1f84f18:	mov    %r12,%r11
 1f84f1b:	mov    0x88(%rsp),%rcx
 1f84f23:	mov    0x70(%rsp),%rsi
 1f84f28:	test   %eax,%eax
 1f84f2a:	mov    0x60(%rsp),%rax
 1f84f2f:	jne    1f84b52 <node_facts_window_run+0x7742>
 1f84f35:	mov    0xc8(%rsp),%edx
 1f84f3c:	mov    0xd90(%r11),%rsi
 1f84f43:	mov    0xdb8(%r11),%rdi
 1f84f4a:	shl    $0x2,%rdx
 1f84f4e:	call   355e9e0 <strlen+0x10>
 1f84f53:	xor    %ebx,%ebx
 1f84f55:	test   %eax,%eax
 1f84f57:	mov    0x70(%rsp),%rsi
 1f84f5c:	mov    0x88(%rsp),%rcx
 1f84f64:	mov    (%rsp),%r11
 1f84f68:	mov    0x60(%rsp),%rax
 1f84f6d:	setne  %bl
 1f84f70:	jmp    1f84b52 <node_facts_window_run+0x7742>
 1f84f75:	mov    0x70(%rsp),%rsi
 1f84f7a:	jmp    1f849d8 <node_facts_window_run+0x75c8>
 1f84f7f:	mov    (%rsp),%r11
 1f84f83:	jmp    1f849b8 <node_facts_window_run+0x75a8>
 1f84f88:	mov    (%rsp),%r11
 1f84f8c:	mov    0x70(%rsp),%rsi
 1f84f91:	jmp    1f849d8 <node_facts_window_run+0x75c8>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
