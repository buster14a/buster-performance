
results/xh4/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f76fc0 <node_facts_reader_flush>:
 1f76fc0:	push   %rbp
 1f76fc1:	push   %r15
 1f76fc3:	push   %r14
 1f76fc5:	push   %r13
 1f76fc7:	push   %r12
 1f76fc9:	push   %rbx
 1f76fca:	sub    $0x58,%rsp
 1f76fce:	mov    0x940(%rdi),%r12
 1f76fd5:	cmpl   $0x0,0x250(%rdi)
 1f76fdc:	mov    %rsi,%r15
 1f76fdf:	mov    %rdi,%r14
 1f76fe2:	je     1f7711d <node_facts_reader_flush+0x15d>
 1f76fe8:	cmpb   $0x0,0x93f(%r14)
 1f76ff0:	je     1f7712b <node_facts_reader_flush+0x16b>
 1f76ff6:	mov    0x25c(%r14),%ebx
 1f76ffd:	inc    %ebx
 1f76fff:	je     1f78a2d <node_facts_reader_flush+0x1a6d>
 1f77005:	mov    (%r14),%rax
 1f77008:	xor    %ebp,%ebp
 1f7700a:	mov    %r15,0x48(%rsp)
 1f7700f:	mov    %r12,0x20(%rsp)
 1f77014:	mov    %rax,0x40(%rsp)
 1f77019:	nopl   0x0(%rax)
 1f77020:	mov    %r14,%rdi
 1f77023:	mov    %ebp,%esi
 1f77025:	xor    %edx,%edx
 1f77027:	call   1f7bbe0 <node_facts_given>
 1f7702c:	rdtsc
 1f7702e:	mov    %r14,%rdi
 1f77031:	mov    %ebp,%esi
 1f77033:	xor    %ecx,%ecx
 1f77035:	mov    %rdx,%r12
 1f77038:	shl    $0x20,%r12
 1f7703c:	xor    %edx,%edx
 1f7703e:	or     %rax,%r12
 1f77041:	call   1f7be00 <node_facts_window>
 1f77046:	rdtsc
 1f77048:	inc    %ebp
 1f7704a:	shl    $0x20,%rdx
 1f7704e:	or     %rax,%rdx
 1f77051:	sub    %r12,%rdx
 1f77054:	mov    0x20(%rsp),%r12
 1f77059:	add    %rdx,0x910(%r12)
 1f77061:	cmp    %ebp,%ebx
 1f77063:	jne    1f77020 <node_facts_reader_flush+0x60>
 1f77065:	rdtsc
 1f77067:	xor    %r15d,%r15d
 1f7706a:	mov    %rdx,%r13
 1f7706d:	shl    $0x20,%r13
 1f77071:	or     %rax,%r13
 1f77074:	mov    0xa90(%r14),%eax
 1f7707b:	test   %eax,%eax
 1f7707d:	je     1f7716d <node_facts_reader_flush+0x1ad>
 1f77083:	xor    %r12d,%r12d
 1f77086:	xor    %ebp,%ebp
 1f77088:	jmp    1f770ae <node_facts_reader_flush+0xee>
 1f7708a:	nopw   0x0(%rax,%rax,1)
 1f77090:	add    %ecx,%r15d
 1f77093:	cmp    $0x1,%eax
 1f77096:	mov    0xa90(%r14),%eax
 1f7709d:	sbb    $0xffffffff,%ebp
 1f770a0:	inc    %r12
 1f770a3:	mov    %eax,%ecx
 1f770a5:	cmp    %rcx,%r12
 1f770a8:	jae    1f77160 <node_facts_reader_flush+0x1a0>
 1f770ae:	mov    0xa80(%r14),%rcx
 1f770b5:	cmpb   $0x0,(%rcx,%r12,1)
 1f770ba:	je     1f770a0 <node_facts_reader_flush+0xe0>
 1f770bc:	mov    0xa78(%r14),%rax
 1f770c3:	mov    %r14,%rdi
 1f770c6:	mov    (%rax,%r12,4),%eax
 1f770ca:	mov    %eax,0x9a8(%r14)
 1f770d1:	mov    0xa60(%r14),%rcx
 1f770d8:	mov    0xa58(%r14),%rax
 1f770df:	mov    0xa68(%r14),%rsi
 1f770e6:	mov    (%rcx,%r12,4),%edx
 1f770ea:	mov    (%rax,%r12,4),%ecx
 1f770ee:	mov    0xa70(%r14),%rax
 1f770f5:	mov    (%rsi,%r12,4),%r8d
 1f770f9:	mov    0x48(%rsp),%rsi
 1f770fe:	mov    (%rax,%r12,4),%r9d
 1f77102:	call   1f78b80 <node_facts_front_expression>
 1f77107:	xor    %ecx,%ecx
 1f77109:	test   %eax,%eax
 1f7710b:	jne    1f77090 <node_facts_reader_flush+0xd0>
 1f7710d:	mov    0xa58(%r14),%rcx
 1f77114:	mov    (%rcx,%r12,4),%ecx
 1f77118:	jmp    1f77090 <node_facts_reader_flush+0xd0>
 1f7711d:	cmpb   $0x0,0x93f(%r14)
 1f77125:	jne    1f78a2d <node_facts_reader_flush+0x1a6d>
 1f7712b:	incq   0x908(%r12)
 1f77133:	movb   $0x1,0x93f(%r14)
 1f7713b:	cmpb   $0x1,0x9b0(%r14)
 1f77143:	jne    1f78a2d <node_facts_reader_flush+0x1a6d>
 1f77149:	mov    0x9b8(%r14),%rdi
 1f77150:	mov    0x8(%r15),%edx
 1f77154:	xor    %esi,%esi
 1f77156:	call   355eb60 <memset>
 1f7715b:	jmp    1f78a2d <node_facts_reader_flush+0x1a6d>
 1f77160:	mov    0x20(%rsp),%r12
 1f77165:	mov    %r15d,%ecx
 1f77168:	mov    %ebp,%r15d
 1f7716b:	jmp    1f7716f <node_facts_reader_flush+0x1af>
 1f7716d:	xor    %ecx,%ecx
 1f7716f:	rdtsc
 1f77171:	vmovd  %ecx,%xmm1
 1f77175:	shl    $0x20,%rdx
 1f77179:	or     %rax,%rdx
 1f7717c:	sub    %r13,%rdx
 1f7717f:	vmovq  %rdx,%xmm0
 1f77184:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f77188:	vpaddq 0x9c0(%r12),%xmm0,%xmm0
 1f77192:	vmovdqu %xmm0,0x9c0(%r12)
 1f7719c:	add    %r15,0x908(%r12)
 1f771a4:	mov    0x258(%r14),%edx
 1f771ab:	mov    %edx,0x9a8(%r14)
 1f771b2:	mov    %edx,%eax
 1f771b4:	mov    0xa90(%r14),%ecx
 1f771bb:	test   %ecx,%ecx
 1f771bd:	je     1f7744e <node_facts_reader_flush+0x48e>
 1f771c3:	mov    0xa80(%r14),%rdx
 1f771ca:	xor    %eax,%eax
 1f771cc:	jmp    1f771e5 <node_facts_reader_flush+0x225>
 1f771ce:	xchg   %ax,%ax
 1f771d0:	mov    0xa90(%r14),%ecx
 1f771d7:	inc    %rax
 1f771da:	mov    %ecx,%esi
 1f771dc:	cmp    %rsi,%rax
 1f771df:	jae    1f77440 <node_facts_reader_flush+0x480>
 1f771e5:	cmpb   $0x0,(%rdx,%rax,1)
 1f771e9:	je     1f771d7 <node_facts_reader_flush+0x217>
 1f771eb:	mov    0xa58(%r14),%rcx
 1f771f2:	cmpl   $0x0,(%rcx,%rax,4)
 1f771f6:	je     1f771d0 <node_facts_reader_flush+0x210>
 1f771f8:	xor    %ecx,%ecx
 1f771fa:	nopw   0x0(%rax,%rax,1)
 1f77200:	mov    0xa60(%r14),%rdx
 1f77207:	mov    0x958(%r14),%rsi
 1f7720e:	mov    0x1f0(%r14),%rdi
 1f77215:	mov    (%rdx,%rax,4),%edx
 1f77218:	add    %ecx,%edx
 1f7721a:	movzbl (%rsi,%rdx,1),%esi
 1f7721e:	cmp    (%rdi,%rdx,1),%sil
 1f77222:	jne    1f773a0 <node_facts_reader_flush+0x3e0>
 1f77228:	mov    0x1f8(%r14),%rdi
 1f7722f:	mov    0x960(%r14),%r9
 1f77236:	movzbl (%rdi,%rdx,1),%r8d
 1f7723b:	cmp    %r8b,(%r9,%rdx,1)
 1f7723f:	jne    1f773a0 <node_facts_reader_flush+0x3e0>
 1f77245:	mov    0x968(%r14),%rdi
 1f7724c:	mov    0x200(%r14),%r9
 1f77253:	movzbl (%rdi,%rdx,1),%edi
 1f77257:	cmp    (%r9,%rdx,1),%dil
 1f7725b:	jne    1f773a0 <node_facts_reader_flush+0x3e0>
 1f77261:	mov    0x978(%r14),%rdi
 1f77268:	mov    0x210(%r14),%r9
 1f7726f:	movzwl (%rdi,%rdx,2),%edi
 1f77273:	cmp    (%r9,%rdx,2),%di
 1f77278:	jne    1f773a0 <node_facts_reader_flush+0x3e0>
 1f7727e:	mov    0x980(%r14),%rdi
 1f77285:	mov    0x218(%r14),%r9
 1f7728c:	movzwl (%rdi,%rdx,2),%edi
 1f77290:	cmp    (%r9,%rdx,2),%di
 1f77295:	jne    1f773a0 <node_facts_reader_flush+0x3e0>
 1f7729b:	mov    0x990(%r14),%rdi
 1f772a2:	mov    0x228(%r14),%r9
 1f772a9:	movzwl (%rdi,%rdx,2),%edi
 1f772ad:	cmp    (%r9,%rdx,2),%di
 1f772b2:	jne    1f773a0 <node_facts_reader_flush+0x3e0>
 1f772b8:	mov    0x998(%r14),%r9
 1f772bf:	mov    0x230(%r14),%r10
 1f772c6:	mov    (%r9,%rdx,4),%r9d
 1f772ca:	mov    (%r10,%rdx,4),%r10d
 1f772ce:	cmp    %r10d,%r9d
 1f772d1:	jne    1f77324 <node_facts_reader_flush+0x364>
 1f772d3:	mov    %r8d,%r11d
 1f772d6:	and    $0xfb,%r11b
 1f772da:	cmp    $0x2,%r11b
 1f772de:	jne    1f77324 <node_facts_reader_flush+0x364>
 1f772e0:	mov    0x988(%r14),%rsi
 1f772e7:	mov    0x220(%r14),%rdi
 1f772ee:	mov    (%rsi,%rdx,4),%esi
 1f772f1:	mov    (%rdi,%rdx,4),%edi
 1f772f4:	cmp    %edi,%esi
 1f772f6:	je     1f77418 <node_facts_reader_flush+0x458>
 1f772fc:	mov    0x28(%r14),%r8
 1f77300:	shl    $0x5,%rsi
 1f77304:	shl    $0x5,%rdi
 1f77308:	vmovdqu (%r8,%rsi,1),%ymm0
 1f7730e:	vpxor  (%r8,%rdi,1),%ymm0,%ymm0
 1f77314:	vptest %ymm0,%ymm0
 1f77319:	jne    1f773a0 <node_facts_reader_flush+0x3e0>
 1f7731f:	jmp    1f77418 <node_facts_reader_flush+0x458>
 1f77324:	cmp    %r10d,%r9d
 1f77327:	sete   %r11b
 1f7732b:	cmp    $0x1,%r8b
 1f7732f:	setne  %r8b
 1f77333:	and    %r11b,%r8b
 1f77336:	cmp    $0x1,%r8b
 1f7733a:	jne    1f77399 <node_facts_reader_flush+0x3d9>
 1f7733c:	mov    0x988(%r14),%r8
 1f77343:	mov    0x220(%r14),%r9
 1f7734a:	mov    (%r8,%rdx,4),%r8d
 1f7734e:	cmp    (%r9,%rdx,4),%r8d
 1f77352:	jne    1f773a0 <node_facts_reader_flush+0x3e0>
 1f77354:	cmp    $0x22,%sil
 1f77358:	jne    1f77418 <node_facts_reader_flush+0x458>
 1f7735e:	test   %rdi,%rdi
 1f77361:	je     1f77418 <node_facts_reader_flush+0x458>
 1f77367:	mov    0x9a0(%r14),%rsi
 1f7736e:	mov    0x240(%r14),%r9
 1f77375:	data16 cs nopw 0x0(%rax,%rax,1)
 1f77380:	mov    %r8d,%r10d
 1f77383:	movzwl (%rsi,%r10,2),%r11d
 1f77388:	cmp    (%r9,%r10,2),%r11w
 1f7738d:	jne    1f773a0 <node_facts_reader_flush+0x3e0>
 1f7738f:	inc    %r8d
 1f77392:	dec    %rdi
 1f77395:	jne    1f77380 <node_facts_reader_flush+0x3c0>
 1f77397:	jmp    1f77418 <node_facts_reader_flush+0x458>
 1f77399:	cmp    %r10d,%r9d
 1f7739c:	je     1f77418 <node_facts_reader_flush+0x458>
 1f7739e:	xchg   %ax,%ax
 1f773a0:	incq   0x9a8(%r12)
 1f773a8:	mov    (%r14),%rsi
 1f773ab:	mov    0x238(%r14),%rdi
 1f773b2:	mov    (%rdi,%rdx,4),%r8d
 1f773b6:	mov    0x10(%rsi),%rsi
 1f773ba:	mov    $0xffffffff,%edi
 1f773bf:	cmp    0xec(%rsi),%r8d
 1f773c6:	jae    1f773d0 <node_facts_reader_flush+0x410>
 1f773c8:	mov    0x28(%rsi),%rsi
 1f773cc:	mov    (%rsi,%r8,4),%edi
 1f773d0:	mov    0x940(%r14),%rsi
 1f773d7:	mov    0x11e0(%rsi),%r8d
 1f773de:	cmp    $0xf,%r8
 1f773e2:	ja     1f77418 <node_facts_reader_flush+0x458>
 1f773e4:	mov    %edi,0x1180(%rsi,%r8,4)
 1f773ec:	mov    0x1f0(%r14),%rdi
 1f773f3:	movzbl (%rdi,%rdx,1),%edx
 1f773f7:	mov    0x11e0(%rsi),%edi
 1f773fd:	mov    %dl,0x11c0(%rsi,%rdi,1)
 1f77404:	mov    0x11e0(%rsi),%edx
 1f7740a:	movb   $0x3,0x11d0(%rsi,%rdx,1)
 1f77412:	incl   0x11e0(%rsi)
 1f77418:	mov    0xa80(%r14),%rdx
 1f7741f:	cmpb   $0x0,(%rdx,%rax,1)
 1f77423:	je     1f771d0 <node_facts_reader_flush+0x210>
 1f77429:	mov    0xa58(%r14),%rsi
 1f77430:	inc    %ecx
 1f77432:	cmp    (%rsi,%rax,4),%ecx
 1f77435:	jb     1f77200 <node_facts_reader_flush+0x240>
 1f7743b:	jmp    1f771d0 <node_facts_reader_flush+0x210>
 1f77440:	mov    0x258(%r14),%eax
 1f77447:	mov    0x9a8(%r14),%edx
 1f7744e:	mov    0x998(%r14),%rdi
 1f77455:	mov    0x230(%r14),%rcx
 1f7745c:	mov    0x240(%r14),%rsi
 1f77463:	vmovdqu64 0x958(%r14),%zmm0
 1f7746d:	mov    %rdi,0x230(%r14)
 1f77474:	mov    0x9a0(%r14),%rdi
 1f7747b:	mov    %rdi,0x240(%r14)
 1f77482:	mov    %edx,0x258(%r14)
 1f77489:	vmovdqu64 0x1f0(%r14),%zmm1
 1f77493:	vmovdqu64 %zmm0,0x1f0(%r14)
 1f7749d:	vmovdqu64 %zmm1,0x958(%r14)
 1f774a7:	mov    %rcx,0x998(%r14)
 1f774ae:	mov    %rsi,0x9a0(%r14)
 1f774b5:	mov    %eax,0x9a8(%r14)
 1f774bc:	mov    %ebx,%eax
 1f774be:	xor    %ebx,%ebx
 1f774c0:	movl   $0x0,0x9ac(%r14)
 1f774cb:	mov    %rax,0x28(%rsp)
 1f774d0:	jmp    1f774f3 <node_facts_reader_flush+0x533>
 1f774d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f774e0:	mov    0x38(%rsp),%rbx
 1f774e5:	inc    %rbx
 1f774e8:	cmp    0x28(%rsp),%rbx
 1f774ed:	je     1f77be3 <node_facts_reader_flush+0xc23>
 1f774f3:	mov    0x248(%r14),%rax
 1f774fa:	mov    $0x1,%edx
 1f774ff:	mov    %r14,%rdi
 1f77502:	mov    %ebx,%esi
 1f77504:	mov    (%rax,%rbx,4),%r13d
 1f77508:	mov    0x4(%rax,%rbx,4),%ebp
 1f7750c:	vzeroupper
 1f7750f:	call   1f7bbe0 <node_facts_given>
 1f77514:	mov    %r14,%rdi
 1f77517:	mov    %ebx,%esi
 1f77519:	xor    %edx,%edx
 1f7751b:	xor    %ecx,%ecx
 1f7751d:	call   1f7be00 <node_facts_window>
 1f77522:	mov    %r14,%rdi
 1f77525:	mov    %ebx,%esi
 1f77527:	mov    %rbx,0x38(%rsp)
 1f7752c:	call   1f7ca50 <node_facts_lists_same>
 1f77531:	test   %al,%al
 1f77533:	jne    1f775aa <node_facts_reader_flush+0x5ea>
 1f77535:	incq   0x900(%r12)
 1f7753d:	mov    (%r14),%rax
 1f77540:	mov    0x238(%r14),%rcx
 1f77547:	mov    (%rcx,%r13,4),%edx
 1f7754b:	mov    0x10(%rax),%rax
 1f7754f:	mov    $0xffffffff,%ecx
 1f77554:	cmp    0xec(%rax),%edx
 1f7755a:	jae    1f77563 <node_facts_reader_flush+0x5a3>
 1f7755c:	mov    0x28(%rax),%rax
 1f77560:	mov    (%rax,%rdx,4),%ecx
 1f77563:	mov    0x940(%r14),%rax
 1f7756a:	mov    0x11e0(%rax),%edx
 1f77570:	cmp    $0xf,%rdx
 1f77574:	ja     1f775aa <node_facts_reader_flush+0x5ea>
 1f77576:	mov    %ecx,0x1180(%rax,%rdx,4)
 1f7757d:	mov    0x1f0(%r14),%rcx
 1f77584:	mov    0x11e0(%rax),%edx
 1f7758a:	movzbl (%rcx,%r13,1),%ecx
 1f7758f:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f77596:	mov    0x11e0(%rax),%ecx
 1f7759c:	movb   $0x2,0x11d0(%rax,%rcx,1)
 1f775a4:	incl   0x11e0(%rax)
 1f775aa:	vpbroadcastq -0x19a90bb(%rip),%xmm2        # 5ce4f8 <.LCPI1286_0>
 1f775b3:	vpbroadcastd -0x19a66a0(%rip),%xmm3        # 5d0f1c <.LCPI1286_1>
 1f775bc:	cmp    %r13d,%ebp
 1f775bf:	je     1f774e0 <node_facts_reader_flush+0x520>
 1f775c5:	sub    %r13d,%ebp
 1f775c8:	xor    %ecx,%ecx
 1f775ca:	mov    %ebp,%eax
 1f775cc:	mov    %rax,(%rsp)
 1f775d0:	jmp    1f775ed <node_facts_reader_flush+0x62d>
 1f775d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f775e0:	inc    %rcx
 1f775e3:	cmp    (%rsp),%rcx
 1f775e7:	je     1f774e0 <node_facts_reader_flush+0x520>
 1f775ed:	mov    0x1f8(%r14),%rsi
 1f775f4:	lea    0x0(%r13,%rcx,1),%edx
 1f775f9:	mov    0x1f0(%r14),%rax
 1f77600:	mov    %rdx,0x18(%rsp)
 1f77605:	movzbl (%rsi,%rdx,1),%edi
 1f77609:	movzbl (%rax,%rdx,1),%eax
 1f7760d:	cmp    $0x1,%edi
 1f77610:	sete   %sil
 1f77614:	cmp    $0x6,%edi
 1f77617:	sete   %r8b
 1f7761b:	or     %sil,%r8b
 1f7761e:	mov    0xa98(%r14),%rsi
 1f77625:	movzbl %r8b,%r8d
 1f77629:	movzbl (%rsi,%rdx,1),%esi
 1f7762d:	test   %sil,%sil
 1f77630:	setne  %r9b
 1f77634:	add    %r8,0x8c0(%r12)
 1f7763c:	and    %r9b,%r8b
 1f7763f:	vmovd  %r9d,%xmm0
 1f77644:	vpinsrb $0x1,%r8d,%xmm0,%xmm0
 1f7764a:	vpmovzxbq %xmm0,%xmm0
 1f7764f:	vptestmq %xmm2,%xmm0,%k0
 1f77655:	vmovdqu 0x978(%r12),%xmm0
 1f7765f:	vpmovm2q %k0,%xmm1
 1f77665:	vpsubq %xmm1,%xmm0,%xmm0
 1f77669:	vmovdqu %xmm0,0x978(%r12)
 1f77673:	cmp    $0x7,%edi
 1f77676:	ja     1f775e0 <node_facts_reader_flush+0x620>
 1f7767c:	mov    $0xcc,%r8d
 1f77682:	bt     %edi,%r8d
 1f77686:	jae    1f775e0 <node_facts_reader_flush+0x620>
 1f7768c:	test   %sil,%sil
 1f7768f:	mov    %edi,%r9d
 1f77692:	mov    %rcx,%r11
 1f77695:	setne  %sil
 1f77699:	cmp    $0x6,%dil
 1f7769d:	sete   %r8b
 1f776a1:	and    $0xfe,%r9b
 1f776a5:	cmp    $0x2,%r9b
 1f776a9:	sete   %r9b
 1f776ad:	cmp    $0x7,%dil
 1f776b1:	mov    0x2c0(%r14),%rdi
 1f776b8:	sete   %bpl
 1f776bc:	shl    $0x6,%r11
 1f776c0:	or     %r9b,%bpl
 1f776c3:	vmovd  %ebp,%xmm0
 1f776c7:	movzbl %bpl,%r10d
 1f776cb:	movzbl 0x19(%rdi,%r11,1),%edi
 1f776d1:	dec    %dil
 1f776d4:	sete   %r15b
 1f776d8:	cmp    $0x2,%dil
 1f776dc:	setb   %r9b
 1f776e0:	setae  %dil
 1f776e4:	and    %bpl,%r15b
 1f776e7:	and    %r10b,%sil
 1f776ea:	and    %r9b,%bpl
 1f776ed:	and    %r10b,%dil
 1f776f0:	vpinsrb $0x1,%ebp,%xmm0,%xmm0
 1f776f6:	vpinsrb $0x2,%r15d,%xmm0,%xmm0
 1f776fc:	vpinsrb $0x3,%r8d,%xmm0,%xmm0
 1f77702:	and    %r9b,%r8b
 1f77705:	and    %sil,%r9b
 1f77708:	vpmovzxbd %xmm0,%xmm0
 1f7770d:	movzbl %r8b,%r8d
 1f77711:	vptestmd %xmm3,%xmm0,%k0
 1f77717:	vmovdqu 0x8c8(%r12),%ymm0
 1f77721:	vpmovm2q %k0,%ymm1
 1f77727:	vpsubq %ymm1,%ymm0,%ymm0
 1f7772b:	vmovdqu %ymm0,0x8c8(%r12)
 1f77735:	vmovd  %esi,%xmm0
 1f77739:	add    %r8,0x8e8(%r12)
 1f77741:	movzbl %dil,%esi
 1f77745:	lea    (%rcx,%r13,1),%r8
 1f77749:	vpinsrb $0x1,%r9d,%xmm0,%xmm0
 1f7774f:	vpmovzxbq %xmm0,%xmm0
 1f77754:	vptestmq %xmm2,%xmm0,%k0
 1f7775a:	vmovdqu 0x988(%r12),%xmm0
 1f77764:	vpmovm2q %k0,%xmm1
 1f7776a:	vpsubq %xmm1,%xmm0,%xmm0
 1f7776e:	vmovdqu %xmm0,0x988(%r12)
 1f77778:	add    %r10,0xd30(%r12,%rax,8)
 1f77780:	add    %rsi,0xf58(%r12,%rax,8)
 1f77788:	mov    0x288(%r14),%rax
 1f7778f:	movzbl (%rax,%r8,1),%esi
 1f77794:	mov    %esi,%ebp
 1f77796:	and    $0x60,%bpl
 1f7779a:	cmp    $0x40,%bpl
 1f7779e:	jne    1f777b0 <node_facts_reader_flush+0x7f0>
 1f777a0:	mov    0x290(%r14),%rax
 1f777a7:	movzwl (%rax,%r8,2),%edx
 1f777ac:	jmp    1f777b2 <node_facts_reader_flush+0x7f2>
 1f777ae:	xchg   %ax,%ax
 1f777b0:	xor    %edx,%edx
 1f777b2:	mov    0x2a0(%r14),%rdi
 1f777b9:	mov    0x2c0(%r14),%rax
 1f777c0:	mov    0x268(%r14),%r15
 1f777c7:	mov    (%rdi,%r8,8),%r12d
 1f777cb:	mov    0x4(%rdi,%r8,8),%r10d
 1f777d0:	mov    0x2b0(%r14),%rdi
 1f777d7:	mov    (%r15,%r8,4),%ebx
 1f777db:	mov    %rax,0x10(%rsp)
 1f777e0:	add    %rax,%r11
 1f777e3:	mov    0x2a8(%r14),%rax
 1f777ea:	mov    0x1f0(%r14),%r15
 1f777f1:	mov    (%rdi,%r8,8),%rdi
 1f777f5:	mov    (%rax,%r8,8),%r9d
 1f777f9:	mov    0x4(%rax,%r8,8),%eax
 1f777fe:	mov    %rdi,0x8(%rsp)
 1f77803:	mov    0x18(%rsp),%rdi
 1f77808:	movzbl (%r15,%rdi,1),%r15d
 1f7780d:	cmp    %ebx,(%r11)
 1f77810:	jne    1f77880 <node_facts_reader_flush+0x8c0>
 1f77812:	mov    0x298(%r14),%rdi
 1f77819:	mov    (%rdi,%r8,4),%edi
 1f7781d:	cmp    %edi,0x4(%r11)
 1f77821:	jne    1f77880 <node_facts_reader_flush+0x8c0>
 1f77823:	mov    0x270(%r14),%rdi
 1f7782a:	mov    (%rdi,%r8,4),%edi
 1f7782e:	cmp    %edi,0x8(%r11)
 1f77832:	jne    1f77880 <node_facts_reader_flush+0x8c0>
 1f77834:	mov    0x278(%r14),%rdi
 1f7783b:	mov    (%rdi,%r8,4),%edi
 1f7783f:	cmp    %edi,0xc(%r11)
 1f77843:	jne    1f7788b <node_facts_reader_flush+0x8cb>
 1f77845:	mov    0x280(%r14),%rdi
 1f7784c:	mov    (%rdi,%r8,8),%rdi
 1f77850:	cmp    %rdi,0x10(%r11)
 1f77854:	jne    1f77880 <node_facts_reader_flush+0x8c0>
 1f77856:	movzbl 0x18(%r11),%edi
 1f7785b:	cmp    %sil,%dil
 1f7785e:	sete   %r8b
 1f77862:	cmp    $0x40,%bpl
 1f77866:	jne    1f77890 <node_facts_reader_flush+0x8d0>
 1f77868:	cmp    %sil,%dil
 1f7786b:	jne    1f77890 <node_facts_reader_flush+0x8d0>
 1f7786d:	cmp    %dx,0x1a(%r11)
 1f77872:	sete   %r8b
 1f77876:	cmp    %r12d,0x20(%r11)
 1f7787a:	je     1f77896 <node_facts_reader_flush+0x8d6>
 1f7787c:	jmp    1f778c0 <node_facts_reader_flush+0x900>
 1f7787e:	xchg   %ax,%ax
 1f77880:	xor    %r8d,%r8d
 1f77883:	cmp    %r12d,0x20(%r11)
 1f77887:	je     1f77896 <node_facts_reader_flush+0x8d6>
 1f77889:	jmp    1f778c0 <node_facts_reader_flush+0x900>
 1f7788b:	xor    %r8d,%r8d
 1f7788e:	xchg   %ax,%ax
 1f77890:	cmp    %r12d,0x20(%r11)
 1f77894:	jne    1f778c0 <node_facts_reader_flush+0x900>
 1f77896:	cmp    %r10d,0x24(%r11)
 1f7789a:	jne    1f778c0 <node_facts_reader_flush+0x900>
 1f7789c:	cmp    %r9d,0x28(%r11)
 1f778a0:	jne    1f778c0 <node_facts_reader_flush+0x900>
 1f778a2:	cmp    %eax,0x2c(%r11)
 1f778a6:	sete   %r9b
 1f778aa:	mov    0x30(%r11),%r10
 1f778ae:	mov    $0x1,%al
 1f778b0:	cmp    $0x22,%r15b
 1f778b4:	jne    1f77b40 <node_facts_reader_flush+0xb80>
 1f778ba:	jmp    1f778d3 <node_facts_reader_flush+0x913>
 1f778bc:	nopl   0x0(%rax)
 1f778c0:	xor    %r9d,%r9d
 1f778c3:	mov    0x30(%r11),%r10
 1f778c7:	mov    $0x1,%al
 1f778c9:	cmp    $0x22,%r15b
 1f778cd:	jne    1f77b40 <node_facts_reader_flush+0xb80>
 1f778d3:	cmp    $0x40,%bpl
 1f778d7:	je     1f77b40 <node_facts_reader_flush+0xb80>
 1f778dd:	cmpb   $0x0,0x19(%r11)
 1f778e2:	je     1f77b40 <node_facts_reader_flush+0xb80>
 1f778e8:	testb  $0x2,0x1a(%r11)
 1f778ed:	je     1f77b40 <node_facts_reader_flush+0xb80>
 1f778f3:	mov    0x228(%r14),%rsi
 1f778fa:	mov    0x18(%rsp),%rdx
 1f778ff:	movzwl (%rsi,%rdx,2),%r12d
 1f77904:	test   %r12,%r12
 1f77907:	je     1f77b40 <node_facts_reader_flush+0xb80>
 1f7790d:	mov    0x220(%r14),%rax
 1f77914:	mov    0x18(%rsp),%rdx
 1f77919:	mov    0x240(%r14),%r11
 1f77920:	mov    %r12d,%ebp
 1f77923:	and    $0x7,%ebp
 1f77926:	mov    (%rax,%rdx,4),%eax
 1f77929:	mov    %rax,0x30(%rsp)
 1f7792e:	cmp    $0x8,%r12w
 1f77933:	jae    1f77944 <node_facts_reader_flush+0x984>
 1f77935:	mov    0x10(%rsp),%rdx
 1f7793a:	mov    $0x1,%al
 1f7793c:	xor    %r15d,%r15d
 1f7793f:	jmp    1f77ad9 <node_facts_reader_flush+0xb19>
 1f77944:	mov    0x10(%rsp),%rdx
 1f77949:	mov    %r11,0x50(%rsp)
 1f7794e:	lea    0xe(%r11,%rax,2),%r11
 1f77953:	and    $0xfffffff8,%r12d
 1f77957:	mov    $0x1,%al
 1f77959:	xor    %r15d,%r15d
 1f7795c:	nopl   0x0(%rax)
 1f77960:	cmp    $0x1,%al
 1f77962:	jne    1f77ac0 <node_facts_reader_flush+0xb00>
 1f77968:	movzwl -0xe(%r11,%r15,2),%eax
 1f7796e:	mov    0x2b8(%r14),%rbx
 1f77975:	mov    %ecx,%esi
 1f77977:	sub    %eax,%esi
 1f77979:	mov    %rsi,%rax
 1f7797c:	shl    $0x6,%rax
 1f77980:	mov    0x38(%rdx,%rax,1),%rdi
 1f77985:	lea    0x0(,%r13,8),%rax
 1f7798d:	add    %rax,%rbx
 1f77990:	cmp    (%rbx,%rsi,8),%rdi
 1f77994:	jne    1f77ac0 <node_facts_reader_flush+0xb00>
 1f7799a:	movzwl -0xc(%r11,%r15,2),%esi
 1f779a0:	mov    0x2b8(%r14),%rbx
 1f779a7:	mov    %ecx,%edi
 1f779a9:	sub    %esi,%edi
 1f779ab:	add    %rax,%rbx
 1f779ae:	mov    %rdi,%rsi
 1f779b1:	shl    $0x6,%rsi
 1f779b5:	mov    0x38(%rdx,%rsi,1),%rsi
 1f779ba:	cmp    (%rbx,%rdi,8),%rsi
 1f779be:	jne    1f77ac0 <node_facts_reader_flush+0xb00>
 1f779c4:	movzwl -0xa(%r11,%r15,2),%esi
 1f779ca:	mov    0x2b8(%r14),%rbx
 1f779d1:	mov    %ecx,%edi
 1f779d3:	sub    %esi,%edi
 1f779d5:	add    %rax,%rbx
 1f779d8:	mov    %rdi,%rsi
 1f779db:	shl    $0x6,%rsi
 1f779df:	mov    0x38(%rdx,%rsi,1),%rsi
 1f779e4:	cmp    (%rbx,%rdi,8),%rsi
 1f779e8:	jne    1f77ac0 <node_facts_reader_flush+0xb00>
 1f779ee:	movzwl -0x8(%r11,%r15,2),%esi
 1f779f4:	mov    0x2b8(%r14),%rbx
 1f779fb:	mov    %ecx,%edi
 1f779fd:	sub    %esi,%edi
 1f779ff:	add    %rax,%rbx
 1f77a02:	mov    %rdi,%rsi
 1f77a05:	shl    $0x6,%rsi
 1f77a09:	mov    0x38(%rdx,%rsi,1),%rsi
 1f77a0e:	cmp    (%rbx,%rdi,8),%rsi
 1f77a12:	jne    1f77ac0 <node_facts_reader_flush+0xb00>
 1f77a18:	movzwl -0x6(%r11,%r15,2),%esi
 1f77a1e:	mov    0x2b8(%r14),%rbx
 1f77a25:	mov    %ecx,%edi
 1f77a27:	sub    %esi,%edi
 1f77a29:	add    %rax,%rbx
 1f77a2c:	mov    %rdi,%rsi
 1f77a2f:	shl    $0x6,%rsi
 1f77a33:	mov    0x38(%rdx,%rsi,1),%rsi
 1f77a38:	cmp    (%rbx,%rdi,8),%rsi
 1f77a3c:	jne    1f77ac0 <node_facts_reader_flush+0xb00>
 1f77a42:	movzwl -0x4(%r11,%r15,2),%esi
 1f77a48:	mov    0x2b8(%r14),%rbx
 1f77a4f:	mov    %ecx,%edi
 1f77a51:	sub    %esi,%edi
 1f77a53:	add    %rax,%rbx
 1f77a56:	mov    %rdi,%rsi
 1f77a59:	shl    $0x6,%rsi
 1f77a5d:	mov    0x38(%rdx,%rsi,1),%rsi
 1f77a62:	cmp    (%rbx,%rdi,8),%rsi
 1f77a66:	jne    1f77ac0 <node_facts_reader_flush+0xb00>
 1f77a68:	movzwl -0x2(%r11,%r15,2),%esi
 1f77a6e:	mov    0x2b8(%r14),%rbx
 1f77a75:	mov    %ecx,%edi
 1f77a77:	sub    %esi,%edi
 1f77a79:	add    %rax,%rbx
 1f77a7c:	mov    %rdi,%rsi
 1f77a7f:	shl    $0x6,%rsi
 1f77a83:	mov    0x38(%rdx,%rsi,1),%rsi
 1f77a88:	cmp    (%rbx,%rdi,8),%rsi
 1f77a8c:	jne    1f77ac0 <node_facts_reader_flush+0xb00>
 1f77a8e:	movzwl (%r11,%r15,2),%esi
 1f77a93:	add    0x2b8(%r14),%rax
 1f77a9a:	mov    %ecx,%edi
 1f77a9c:	sub    %esi,%edi
 1f77a9e:	mov    %rdi,%rsi
 1f77aa1:	shl    $0x6,%rsi
 1f77aa5:	mov    0x38(%rdx,%rsi,1),%rsi
 1f77aaa:	cmp    (%rax,%rdi,8),%rsi
 1f77aae:	sete   %al
 1f77ab1:	add    $0x8,%r15
 1f77ab5:	cmp    %r15,%r12
 1f77ab8:	jne    1f77960 <node_facts_reader_flush+0x9a0>
 1f77abe:	jmp    1f77acf <node_facts_reader_flush+0xb0f>
 1f77ac0:	xor    %eax,%eax
 1f77ac2:	add    $0x8,%r15
 1f77ac6:	cmp    %r15,%r12
 1f77ac9:	jne    1f77960 <node_facts_reader_flush+0x9a0>
 1f77acf:	mov    0x50(%rsp),%r11
 1f77ad4:	test   %rbp,%rbp
 1f77ad7:	je     1f77b40 <node_facts_reader_flush+0xb80>
 1f77ad9:	mov    0x30(%rsp),%rsi
 1f77ade:	add    %rsi,%rsi
 1f77ae1:	lea    (%rsi,%r15,2),%rsi
 1f77ae5:	add    %rsi,%r11
 1f77ae8:	xor    %esi,%esi
 1f77aea:	jmp    1f77b23 <node_facts_reader_flush+0xb63>
 1f77aec:	nopl   0x0(%rax)
 1f77af0:	movzwl (%r11,%rsi,2),%eax
 1f77af5:	lea    0x0(,%r13,8),%rbx
 1f77afd:	add    0x2b8(%r14),%rbx
 1f77b04:	mov    %ecx,%edi
 1f77b06:	sub    %eax,%edi
 1f77b08:	mov    %rdi,%rax
 1f77b0b:	shl    $0x6,%rax
 1f77b0f:	mov    0x38(%rdx,%rax,1),%rax
 1f77b14:	cmp    (%rbx,%rdi,8),%rax
 1f77b18:	sete   %al
 1f77b1b:	inc    %rsi
 1f77b1e:	cmp    %rsi,%rbp
 1f77b21:	je     1f77b40 <node_facts_reader_flush+0xb80>
 1f77b23:	cmp    $0x1,%al
 1f77b25:	je     1f77af0 <node_facts_reader_flush+0xb30>
 1f77b27:	xor    %eax,%eax
 1f77b29:	inc    %rsi
 1f77b2c:	cmp    %rsi,%rbp
 1f77b2f:	jne    1f77b23 <node_facts_reader_flush+0xb63>
 1f77b31:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f77b40:	mov    0x20(%rsp),%r12
 1f77b45:	and    %r9b,%r8b
 1f77b48:	cmp    $0x1,%r8b
 1f77b4c:	jne    1f77b5d <node_facts_reader_flush+0xb9d>
 1f77b4e:	cmp    0x8(%rsp),%r10
 1f77b53:	jne    1f77b5d <node_facts_reader_flush+0xb9d>
 1f77b55:	test   %al,%al
 1f77b57:	jne    1f775e0 <node_facts_reader_flush+0x620>
 1f77b5d:	incq   0x8f0(%r12)
 1f77b65:	mov    0x18(%rsp),%rdx
 1f77b6a:	mov    (%r14),%rax
 1f77b6d:	mov    0x238(%r14),%rsi
 1f77b74:	mov    (%rsi,%rdx,4),%edi
 1f77b77:	mov    0x10(%rax),%rax
 1f77b7b:	mov    $0xffffffff,%esi
 1f77b80:	cmp    0xec(%rax),%edi
 1f77b86:	jae    1f77b8f <node_facts_reader_flush+0xbcf>
 1f77b88:	mov    0x28(%rax),%rax
 1f77b8c:	mov    (%rax,%rdi,4),%esi
 1f77b8f:	mov    0x940(%r14),%rax
 1f77b96:	mov    0x11e0(%rax),%edi
 1f77b9c:	cmp    $0xf,%rdi
 1f77ba0:	ja     1f775e0 <node_facts_reader_flush+0x620>
 1f77ba6:	mov    %esi,0x1180(%rax,%rdi,4)
 1f77bad:	mov    0x18(%rsp),%rdx
 1f77bb2:	mov    0x1f0(%r14),%rsi
 1f77bb9:	movzbl (%rsi,%rdx,1),%edx
 1f77bbd:	mov    0x11e0(%rax),%esi
 1f77bc3:	mov    %dl,0x11c0(%rax,%rsi,1)
 1f77bca:	mov    0x11e0(%rax),%edx
 1f77bd0:	movb   $0x0,0x11d0(%rax,%rdx,1)
 1f77bd8:	incl   0x11e0(%rax)
 1f77bde:	jmp    1f775e0 <node_facts_reader_flush+0x620>
 1f77be3:	mov    0x998(%r14),%rsi
 1f77bea:	mov    0x230(%r14),%rax
 1f77bf1:	mov    0x240(%r14),%rcx
 1f77bf8:	mov    0x258(%r14),%edx
 1f77bff:	vmovdqu64 0x958(%r14),%zmm0
 1f77c09:	mov    0x40(%rsp),%r13
 1f77c0e:	xor    %r15d,%r15d
 1f77c11:	mov    %rsi,0x230(%r14)
 1f77c18:	mov    0x9a0(%r14),%rsi
 1f77c1f:	mov    %rsi,0x240(%r14)
 1f77c26:	mov    0x9a8(%r14),%esi
 1f77c2d:	mov    %esi,0x258(%r14)
 1f77c34:	vmovdqu64 0x1f0(%r14),%zmm1
 1f77c3e:	vmovdqu64 %zmm0,0x1f0(%r14)
 1f77c48:	vmovdqu64 %zmm1,0x958(%r14)
 1f77c52:	mov    %rax,0x998(%r14)
 1f77c59:	mov    %rcx,0x9a0(%r14)
 1f77c60:	mov    %edx,0x9a8(%r14)
 1f77c67:	movl   $0x0,0x9ac(%r14)
 1f77c72:	jmp    1f77c93 <node_facts_reader_flush+0xcd3>
 1f77c74:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f77c80:	mov    0x38(%rsp),%r15
 1f77c85:	inc    %r15
 1f77c88:	cmp    0x28(%rsp),%r15
 1f77c8d:	je     1f781a2 <node_facts_reader_flush+0x11e2>
 1f77c93:	mov    0x248(%r14),%rax
 1f77c9a:	mov    $0x3,%edx
 1f77c9f:	mov    %r14,%rdi
 1f77ca2:	mov    %r15d,%esi
 1f77ca5:	mov    (%rax,%r15,4),%ebx
 1f77ca9:	mov    0x4(%rax,%r15,4),%ebp
 1f77cae:	vzeroupper
 1f77cb1:	call   1f7bbe0 <node_facts_given>
 1f77cb6:	mov    %r14,%rdi
 1f77cb9:	mov    %r15,0x38(%rsp)
 1f77cbe:	mov    %r15d,%esi
 1f77cc1:	xor    %edx,%edx
 1f77cc3:	xor    %ecx,%ecx
 1f77cc5:	call   1f7be00 <node_facts_window>
 1f77cca:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1f77cce:	cmp    %ebx,%ebp
 1f77cd0:	je     1f77c80 <node_facts_reader_flush+0xcc0>
 1f77cd2:	sub    %ebx,%ebp
 1f77cd4:	xor    %eax,%eax
 1f77cd6:	mov    %rbp,0x18(%rsp)
 1f77cdb:	jmp    1f77ce8 <node_facts_reader_flush+0xd28>
 1f77cdd:	nopl   (%rax)
 1f77ce0:	inc    %rax
 1f77ce3:	cmp    %rbp,%rax
 1f77ce6:	je     1f77c80 <node_facts_reader_flush+0xcc0>
 1f77ce8:	mov    0x1f8(%r14),%rdx
 1f77cef:	lea    (%rbx,%rax,1),%ecx
 1f77cf2:	testb  $0x2,(%rdx,%rcx,1)
 1f77cf6:	je     1f77ce0 <node_facts_reader_flush+0xd20>
 1f77cf8:	mov    0x288(%r14),%rdx
 1f77cff:	lea    (%rax,%rbx,1),%r8
 1f77d03:	movzbl (%rdx,%r8,1),%edi
 1f77d08:	mov    %edi,%r10d
 1f77d0b:	and    $0x60,%r10b
 1f77d0f:	cmp    $0x40,%r10b
 1f77d13:	jne    1f77d30 <node_facts_reader_flush+0xd70>
 1f77d15:	mov    0x290(%r14),%rdx
 1f77d1c:	movzwl (%rdx,%r8,2),%r9d
 1f77d21:	jmp    1f77d33 <node_facts_reader_flush+0xd73>
 1f77d23:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f77d30:	xor    %r9d,%r9d
 1f77d33:	mov    0x268(%r14),%rsi
 1f77d3a:	mov    0x2c0(%r14),%rdx
 1f77d41:	mov    %rax,%r11
 1f77d44:	shl    $0x6,%r11
 1f77d48:	mov    (%rsi,%r8,4),%esi
 1f77d4c:	add    %rdx,%r11
 1f77d4f:	cmp    %esi,(%r11)
 1f77d52:	jne    1f77dd0 <node_facts_reader_flush+0xe10>
 1f77d54:	mov    0x298(%r14),%rsi
 1f77d5b:	mov    (%rsi,%r8,4),%esi
 1f77d5f:	cmp    %esi,0x4(%r11)
 1f77d63:	jne    1f77dd0 <node_facts_reader_flush+0xe10>
 1f77d65:	mov    0x270(%r14),%rsi
 1f77d6c:	mov    (%rsi,%r8,4),%esi
 1f77d70:	cmp    %esi,0x8(%r11)
 1f77d74:	jne    1f77dd0 <node_facts_reader_flush+0xe10>
 1f77d76:	mov    0x278(%r14),%rsi
 1f77d7d:	mov    (%rsi,%r8,4),%esi
 1f77d81:	cmp    %esi,0xc(%r11)
 1f77d85:	jne    1f77de5 <node_facts_reader_flush+0xe25>
 1f77d87:	mov    0x280(%r14),%rsi
 1f77d8e:	mov    (%rsi,%r8,8),%rsi
 1f77d92:	cmp    %rsi,0x10(%r11)
 1f77d96:	jne    1f77dd0 <node_facts_reader_flush+0xe10>
 1f77d98:	movzbl 0x18(%r11),%ebp
 1f77d9d:	cmp    %dil,%bpl
 1f77da0:	sete   %sil
 1f77da4:	cmp    $0x40,%r10b
 1f77da8:	jne    1f77df0 <node_facts_reader_flush+0xe30>
 1f77daa:	cmp    %dil,%bpl
 1f77dad:	jne    1f77df0 <node_facts_reader_flush+0xe30>
 1f77daf:	cmp    %r9w,0x1a(%r11)
 1f77db4:	sete   %sil
 1f77db8:	mov    0x2a0(%r14),%rdi
 1f77dbf:	mov    (%rdi,%r8,8),%r9d
 1f77dc3:	cmp    %r9d,0x20(%r11)
 1f77dc7:	je     1f77e01 <node_facts_reader_flush+0xe41>
 1f77dc9:	jmp    1f77e30 <node_facts_reader_flush+0xe70>
 1f77dcb:	nopl   0x0(%rax,%rax,1)
 1f77dd0:	xor    %esi,%esi
 1f77dd2:	mov    0x2a0(%r14),%rdi
 1f77dd9:	mov    (%rdi,%r8,8),%r9d
 1f77ddd:	cmp    %r9d,0x20(%r11)
 1f77de1:	je     1f77e01 <node_facts_reader_flush+0xe41>
 1f77de3:	jmp    1f77e30 <node_facts_reader_flush+0xe70>
 1f77de5:	xor    %esi,%esi
 1f77de7:	nopw   0x0(%rax,%rax,1)
 1f77df0:	mov    0x2a0(%r14),%rdi
 1f77df7:	mov    (%rdi,%r8,8),%r9d
 1f77dfb:	cmp    %r9d,0x20(%r11)
 1f77dff:	jne    1f77e30 <node_facts_reader_flush+0xe70>
 1f77e01:	mov    0x4(%rdi,%r8,8),%edi
 1f77e06:	cmp    %edi,0x24(%r11)
 1f77e0a:	jne    1f77e30 <node_facts_reader_flush+0xe70>
 1f77e0c:	mov    0x2a8(%r14),%rdi
 1f77e13:	mov    (%rdi,%r8,8),%r9d
 1f77e17:	cmp    %r9d,0x28(%r11)
 1f77e1b:	jne    1f77e30 <node_facts_reader_flush+0xe70>
 1f77e1d:	mov    0x4(%rdi,%r8,8),%edi
 1f77e22:	cmp    %edi,0x2c(%r11)
 1f77e26:	sete   %dil
 1f77e2a:	jmp    1f77e32 <node_facts_reader_flush+0xe72>
 1f77e2c:	nopl   0x0(%rax)
 1f77e30:	xor    %edi,%edi
 1f77e32:	mov    0x1f0(%r14),%r12
 1f77e39:	mov    0x2b0(%r14),%r9
 1f77e40:	mov    $0x1,%r15b
 1f77e43:	mov    (%r9,%r8,8),%r8
 1f77e47:	mov    0x30(%r11),%r9
 1f77e4b:	cmpb   $0x22,(%r12,%rcx,1)
 1f77e50:	jne    1f780f0 <node_facts_reader_flush+0x1130>
 1f77e56:	mov    0x20(%rsp),%r12
 1f77e5b:	cmp    $0x40,%r10b
 1f77e5f:	je     1f780f5 <node_facts_reader_flush+0x1135>
 1f77e65:	cmpb   $0x0,0x19(%r11)
 1f77e6a:	je     1f780f5 <node_facts_reader_flush+0x1135>
 1f77e70:	testb  $0x2,0x1a(%r11)
 1f77e75:	je     1f780f5 <node_facts_reader_flush+0x1135>
 1f77e7b:	mov    0x228(%r14),%r10
 1f77e82:	movzwl (%r10,%rcx,2),%r13d
 1f77e87:	test   %r13,%r13
 1f77e8a:	je     1f780f5 <node_facts_reader_flush+0x1135>
 1f77e90:	mov    0x220(%r14),%r11
 1f77e97:	mov    0x240(%r14),%r10
 1f77e9e:	mov    (%r11,%rcx,4),%r15d
 1f77ea2:	mov    %r13d,%r11d
 1f77ea5:	and    $0x7,%r11d
 1f77ea9:	mov    %r15,0x30(%rsp)
 1f77eae:	cmp    $0x8,%r13w
 1f77eb3:	jae    1f77ec0 <node_facts_reader_flush+0xf00>
 1f77eb5:	mov    $0x1,%r15b
 1f77eb8:	xor    %r12d,%r12d
 1f77ebb:	jmp    1f78088 <node_facts_reader_flush+0x10c8>
 1f77ec0:	lea    0xe(%r10,%r15,2),%rbp
 1f77ec5:	and    $0xfffffff8,%r13d
 1f77ec9:	mov    $0x1,%r15b
 1f77ecc:	xor    %r12d,%r12d
 1f77ecf:	mov    %edi,0x8(%rsp)
 1f77ed3:	mov    %r10,(%rsp)
 1f77ed7:	mov    %r13,0x10(%rsp)
 1f77edc:	jmp    1f77ef0 <node_facts_reader_flush+0xf30>
 1f77ede:	xchg   %ax,%ax
 1f77ee0:	xor    %r15d,%r15d
 1f77ee3:	add    $0x8,%r12
 1f77ee7:	cmp    %r12,%r13
 1f77eea:	je     1f78083 <node_facts_reader_flush+0x10c3>
 1f77ef0:	cmp    $0x1,%r15b
 1f77ef4:	jne    1f77ee0 <node_facts_reader_flush+0xf20>
 1f77ef6:	movzwl -0xe(%rbp,%r12,2),%r15d
 1f77efc:	mov    %r9,%rdi
 1f77eff:	mov    %r8,%r9
 1f77f02:	mov    0x2b8(%r14),%r8
 1f77f09:	mov    %eax,%r13d
 1f77f0c:	sub    %r15d,%r13d
 1f77f0f:	mov    %r13,%r15
 1f77f12:	shl    $0x6,%r15
 1f77f16:	mov    0x38(%rdx,%r15,1),%r10
 1f77f1b:	lea    0x0(,%rbx,8),%r15
 1f77f23:	add    %r15,%r8
 1f77f26:	cmp    (%r8,%r13,8),%r10
 1f77f2a:	jne    1f78060 <node_facts_reader_flush+0x10a0>
 1f77f30:	movzwl -0xc(%rbp,%r12,2),%r8d
 1f77f36:	mov    0x2b8(%r14),%r13
 1f77f3d:	mov    %eax,%r10d
 1f77f40:	sub    %r8d,%r10d
 1f77f43:	add    %r15,%r13
 1f77f46:	mov    %r10,%r8
 1f77f49:	shl    $0x6,%r8
 1f77f4d:	mov    0x38(%rdx,%r8,1),%r8
 1f77f52:	cmp    0x0(%r13,%r10,8),%r8
 1f77f57:	jne    1f78060 <node_facts_reader_flush+0x10a0>
 1f77f5d:	movzwl -0xa(%rbp,%r12,2),%r8d
 1f77f63:	mov    0x2b8(%r14),%r13
 1f77f6a:	mov    %eax,%r10d
 1f77f6d:	sub    %r8d,%r10d
 1f77f70:	add    %r15,%r13
 1f77f73:	mov    %r10,%r8
 1f77f76:	shl    $0x6,%r8
 1f77f7a:	mov    0x38(%rdx,%r8,1),%r8
 1f77f7f:	cmp    0x0(%r13,%r10,8),%r8
 1f77f84:	jne    1f78060 <node_facts_reader_flush+0x10a0>
 1f77f8a:	movzwl -0x8(%rbp,%r12,2),%r8d
 1f77f90:	mov    0x2b8(%r14),%r13
 1f77f97:	mov    %eax,%r10d
 1f77f9a:	sub    %r8d,%r10d
 1f77f9d:	add    %r15,%r13
 1f77fa0:	mov    %r10,%r8
 1f77fa3:	shl    $0x6,%r8
 1f77fa7:	mov    0x38(%rdx,%r8,1),%r8
 1f77fac:	cmp    0x0(%r13,%r10,8),%r8
 1f77fb1:	jne    1f78060 <node_facts_reader_flush+0x10a0>
 1f77fb7:	movzwl -0x6(%rbp,%r12,2),%r8d
 1f77fbd:	mov    0x2b8(%r14),%r13
 1f77fc4:	mov    %eax,%r10d
 1f77fc7:	sub    %r8d,%r10d
 1f77fca:	add    %r15,%r13
 1f77fcd:	mov    %r10,%r8
 1f77fd0:	shl    $0x6,%r8
 1f77fd4:	mov    0x38(%rdx,%r8,1),%r8
 1f77fd9:	cmp    0x0(%r13,%r10,8),%r8
 1f77fde:	jne    1f78060 <node_facts_reader_flush+0x10a0>
 1f77fe4:	movzwl -0x4(%rbp,%r12,2),%r8d
 1f77fea:	mov    0x2b8(%r14),%r13
 1f77ff1:	mov    %eax,%r10d
 1f77ff4:	sub    %r8d,%r10d
 1f77ff7:	add    %r15,%r13
 1f77ffa:	mov    %r10,%r8
 1f77ffd:	shl    $0x6,%r8
 1f78001:	mov    0x38(%rdx,%r8,1),%r8
 1f78006:	cmp    0x0(%r13,%r10,8),%r8
 1f7800b:	jne    1f78060 <node_facts_reader_flush+0x10a0>
 1f7800d:	movzwl -0x2(%rbp,%r12,2),%r8d
 1f78013:	mov    0x2b8(%r14),%r13
 1f7801a:	mov    %eax,%r10d
 1f7801d:	sub    %r8d,%r10d
 1f78020:	add    %r15,%r13
 1f78023:	mov    %r10,%r8
 1f78026:	shl    $0x6,%r8
 1f7802a:	mov    0x38(%rdx,%r8,1),%r8
 1f7802f:	cmp    0x0(%r13,%r10,8),%r8
 1f78034:	jne    1f78060 <node_facts_reader_flush+0x10a0>
 1f78036:	movzwl 0x0(%rbp,%r12,2),%r8d
 1f7803c:	add    0x2b8(%r14),%r15
 1f78043:	mov    %eax,%r10d
 1f78046:	sub    %r8d,%r10d
 1f78049:	mov    %r10,%r8
 1f7804c:	shl    $0x6,%r8
 1f78050:	mov    0x38(%rdx,%r8,1),%r8
 1f78055:	cmp    (%r15,%r10,8),%r8
 1f78059:	sete   %r15b
 1f7805d:	jmp    1f78063 <node_facts_reader_flush+0x10a3>
 1f7805f:	nop
 1f78060:	xor    %r15d,%r15d
 1f78063:	mov    %r9,%r8
 1f78066:	mov    %rdi,%r9
 1f78069:	mov    0x8(%rsp),%edi
 1f7806d:	mov    (%rsp),%r10
 1f78071:	mov    0x10(%rsp),%r13
 1f78076:	add    $0x8,%r12
 1f7807a:	cmp    %r12,%r13
 1f7807d:	jne    1f77ef0 <node_facts_reader_flush+0xf30>
 1f78083:	test   %r11,%r11
 1f78086:	je     1f780f0 <node_facts_reader_flush+0x1130>
 1f78088:	mov    0x30(%rsp),%r13
 1f7808d:	add    %r13,%r13
 1f78090:	lea    0x0(%r13,%r12,2),%r12
 1f78095:	add    %r12,%r10
 1f78098:	xor    %r12d,%r12d
 1f7809b:	jmp    1f780d7 <node_facts_reader_flush+0x1117>
 1f7809d:	nopl   (%rax)
 1f780a0:	movzwl (%r10,%r12,2),%ebp
 1f780a5:	mov    %eax,%r15d
 1f780a8:	sub    %ebp,%r15d
 1f780ab:	lea    0x0(,%rbx,8),%rbp
 1f780b3:	add    0x2b8(%r14),%rbp
 1f780ba:	mov    %r15,%r13
 1f780bd:	shl    $0x6,%r13
 1f780c1:	mov    0x38(%rdx,%r13,1),%r13
 1f780c6:	cmp    0x0(%rbp,%r15,8),%r13
 1f780cb:	sete   %r15b
 1f780cf:	inc    %r12
 1f780d2:	cmp    %r12,%r11
 1f780d5:	je     1f780f0 <node_facts_reader_flush+0x1130>
 1f780d7:	cmp    $0x1,%r15b
 1f780db:	je     1f780a0 <node_facts_reader_flush+0x10e0>
 1f780dd:	xor    %r15d,%r15d
 1f780e0:	inc    %r12
 1f780e3:	cmp    %r12,%r11
 1f780e6:	jne    1f780d7 <node_facts_reader_flush+0x1117>
 1f780e8:	nopl   0x0(%rax,%rax,1)
 1f780f0:	mov    0x20(%rsp),%r12
 1f780f5:	mov    0x40(%rsp),%r13
 1f780fa:	mov    0x18(%rsp),%rbp
 1f780ff:	and    %dil,%sil
 1f78102:	cmp    $0x1,%sil
 1f78106:	jne    1f78116 <node_facts_reader_flush+0x1156>
 1f78108:	cmp    %r8,%r9
 1f7810b:	jne    1f78116 <node_facts_reader_flush+0x1156>
 1f7810d:	test   %r15b,%r15b
 1f78110:	jne    1f77ce0 <node_facts_reader_flush+0xd20>
 1f78116:	vmovdqu 0x8f0(%r12),%xmm0
 1f78120:	vpsubq %xmm1,%xmm0,%xmm0
 1f78124:	vmovdqu %xmm0,0x8f0(%r12)
 1f7812e:	mov    (%r14),%rdx
 1f78131:	mov    0x238(%r14),%rsi
 1f78138:	mov    (%rsi,%rcx,4),%edi
 1f7813b:	mov    0x10(%rdx),%rdx
 1f7813f:	mov    $0xffffffff,%esi
 1f78144:	cmp    0xec(%rdx),%edi
 1f7814a:	jae    1f78153 <node_facts_reader_flush+0x1193>
 1f7814c:	mov    0x28(%rdx),%rdx
 1f78150:	mov    (%rdx,%rdi,4),%esi
 1f78153:	mov    0x940(%r14),%rdx
 1f7815a:	mov    0x11e0(%rdx),%edi
 1f78160:	cmp    $0xf,%rdi
 1f78164:	ja     1f77ce0 <node_facts_reader_flush+0xd20>
 1f7816a:	mov    %esi,0x1180(%rdx,%rdi,4)
 1f78171:	mov    0x1f0(%r14),%rsi
 1f78178:	movzbl (%rsi,%rcx,1),%ecx
 1f7817c:	mov    0x11e0(%rdx),%esi
 1f78182:	mov    %cl,0x11c0(%rdx,%rsi,1)
 1f78189:	mov    0x11e0(%rdx),%ecx
 1f7818f:	movb   $0x1,0x11d0(%rdx,%rcx,1)
 1f78197:	incl   0x11e0(%rdx)
 1f7819d:	jmp    1f77ce0 <node_facts_reader_flush+0xd20>
 1f781a2:	testb  $0x1,0xb30(%r14)
 1f781aa:	jne    1f7854a <node_facts_reader_flush+0x158a>
 1f781b0:	xor    %esi,%esi
 1f781b2:	jmp    1f782b7 <node_facts_reader_flush+0x12f7>
 1f781b7:	mov    0x290(%r14),%rax
 1f781be:	movzwl (%rax,%rcx,2),%eax
 1f781c2:	mov    0x270(%r14),%r9
 1f781c9:	mov    0x2a0(%r14),%r11
 1f781d0:	mov    0x2a8(%r14),%rbx
 1f781d7:	shl    $0x6,%rdx
 1f781db:	mov    0x298(%r14),%r8
 1f781e2:	mov    0x280(%r14),%r10
 1f781e9:	mov    0x2b0(%r14),%r15
 1f781f0:	add    %rdx,%r12
 1f781f3:	mov    0x268(%r14),%rdx
 1f781fa:	mov    (%r9,%rcx,4),%ebp
 1f781fe:	mov    0x278(%r14),%r9
 1f78205:	vmovq  (%rbx,%rcx,8),%xmm0
 1f7820a:	vmovq  (%r11,%rcx,8),%xmm1
 1f78210:	mov    (%r8,%rcx,4),%r8d
 1f78214:	mov    (%r10,%rcx,8),%r10
 1f78218:	mov    (%r15,%rcx,8),%r15
 1f7821c:	mov    (%rdx,%rcx,4),%edx
 1f7821f:	mov    (%r9,%rcx,4),%r9d
 1f78223:	movabs $0x2525252525252525,%rcx
 1f7822d:	mov    %edx,(%r12)
 1f78231:	mov    %r8d,0x4(%r12)
 1f78236:	mov    %ebp,0x8(%r12)
 1f7823b:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f7823f:	mov    %r9d,0xc(%r12)
 1f78244:	mov    %r10,0x10(%r12)
 1f78249:	mov    %dil,0x18(%r12)
 1f7824e:	movb   $0x1,0x19(%r12)
 1f78254:	mov    %ax,0x1a(%r12)
 1f7825a:	movl   $0x0,0x1c(%r12)
 1f78263:	vmovdqu %xmm0,0x20(%r12)
 1f7826a:	mov    %r15,0x30(%r12)
 1f7826f:	mov    %rcx,0x38(%r12)
 1f78274:	rdtsc
 1f78276:	lea    0x1(%rsi),%rbx
 1f7827a:	mov    %r14,%rdi
 1f7827d:	xor    %ecx,%ecx
 1f7827f:	mov    %rdx,%r12
 1f78282:	shl    $0x20,%r12
 1f78286:	xor    %edx,%edx
 1f78288:	or     %rax,%r12
 1f7828b:	call   1f7be00 <node_facts_window>
 1f78290:	rdtsc
 1f78292:	mov    %rbx,%rsi
 1f78295:	shl    $0x20,%rdx
 1f78299:	or     %rax,%rdx
 1f7829c:	sub    %r12,%rdx
 1f7829f:	mov    0x20(%rsp),%r12
 1f782a4:	add    %rdx,0x918(%r12)
 1f782ac:	cmp    0x28(%rsp),%rbx
 1f782b1:	je     1f7895a <node_facts_reader_flush+0x199a>
 1f782b7:	mov    0x248(%r14),%rax
 1f782be:	mov    (%rax,%rsi,4),%ecx
 1f782c1:	mov    0x4(%rax,%rsi,4),%eax
 1f782c5:	cmp    %ecx,%eax
 1f782c7:	je     1f78274 <node_facts_reader_flush+0x12b4>
 1f782c9:	mov    0x2c0(%r14),%r12
 1f782d0:	sub    %ecx,%eax
 1f782d2:	cmp    $0x1,%eax
 1f782d5:	jne    1f782e0 <node_facts_reader_flush+0x1320>
 1f782d7:	xor    %edx,%edx
 1f782d9:	jmp    1f78529 <node_facts_reader_flush+0x1569>
 1f782de:	xchg   %ax,%ax
 1f782e0:	lea    0x0(,%rcx,8),%r9
 1f782e8:	lea    0x0(,%rcx,4),%r11
 1f782f0:	mov    %rsi,0x18(%rsp)
 1f782f5:	mov    %eax,%esi
 1f782f7:	and    $0xfffffffe,%esi
 1f782fa:	mov    %rax,(%rsp)
 1f782fe:	mov    %r12,0x8(%rsp)
 1f78303:	mov    %r12,%r15
 1f78306:	xor    %edx,%edx
 1f78308:	jmp    1f783ab <node_facts_reader_flush+0x13eb>
 1f7830d:	nopl   (%rax)
 1f78310:	mov    0x290(%r14),%r8
 1f78317:	add    %rcx,%r8
 1f7831a:	add    %rcx,%r8
 1f7831d:	movzwl 0x2(%r8,%rdx,2),%ebx
 1f78323:	mov    0x2a8(%r14),%r8
 1f7832a:	add    %r9,%r8
 1f7832d:	vmovq  0x8(%r8,%rdx,8),%xmm0
 1f78334:	mov    0x2a0(%r14),%r8
 1f7833b:	add    %r9,%r8
 1f7833e:	vmovq  0x8(%r8,%rdx,8),%xmm1
 1f78345:	mov    0x2b0(%r14),%r8
 1f7834c:	add    %r9,%r8
 1f7834f:	mov    0x8(%r8,%rdx,8),%r8
 1f78354:	mov    %r12d,0x40(%r15)
 1f78358:	mov    %r13d,0x44(%r15)
 1f7835c:	mov    %edi,0x48(%r15)
 1f78360:	mov    %r10d,0x4c(%r15)
 1f78364:	mov    %rax,0x50(%r15)
 1f78368:	movabs $0x2525252525252525,%rax
 1f78372:	mov    %bpl,0x58(%r15)
 1f78376:	movb   $0x1,0x59(%r15)
 1f7837b:	mov    %bx,0x5a(%r15)
 1f78380:	movl   $0x0,0x5c(%r15)
 1f78388:	add    $0x2,%rdx
 1f7838c:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f78390:	vmovdqu %xmm0,0x60(%r15)
 1f78396:	mov    %r8,0x70(%r15)
 1f7839a:	mov    %rax,0x78(%r15)
 1f7839e:	sub    $0xffffffffffffff80,%r15
 1f783a2:	cmp    %rdx,%rsi
 1f783a5:	je     1f78510 <node_facts_reader_flush+0x1550>
 1f783ab:	mov    0x288(%r14),%rax
 1f783b2:	mov    0x280(%r14),%r8
 1f783b9:	add    %rcx,%rax
 1f783bc:	add    %r9,%r8
 1f783bf:	movzbl (%rdx,%rax,1),%ebp
 1f783c3:	mov    0x268(%r14),%rax
 1f783ca:	add    %r11,%rax
 1f783cd:	mov    %ebp,%ebx
 1f783cf:	mov    (%rax,%rdx,4),%r12d
 1f783d3:	mov    0x298(%r14),%rax
 1f783da:	and    $0x60,%bl
 1f783dd:	add    %r11,%rax
 1f783e0:	mov    (%rax,%rdx,4),%r13d
 1f783e4:	mov    0x270(%r14),%rax
 1f783eb:	add    %r11,%rax
 1f783ee:	mov    (%rax,%rdx,4),%edi
 1f783f1:	mov    0x278(%r14),%rax
 1f783f8:	add    %r11,%rax
 1f783fb:	mov    (%rax,%rdx,4),%r10d
 1f783ff:	mov    (%r8,%rdx,8),%rax
 1f78403:	cmp    $0x40,%bl
 1f78406:	jne    1f78420 <node_facts_reader_flush+0x1460>
 1f78408:	mov    0x290(%r14),%rbx
 1f7840f:	add    %rcx,%rbx
 1f78412:	add    %rcx,%rbx
 1f78415:	movzwl (%rbx,%rdx,2),%ebx
 1f78419:	jmp    1f78422 <node_facts_reader_flush+0x1462>
 1f7841b:	nopl   0x0(%rax,%rax,1)
 1f78420:	xor    %ebx,%ebx
 1f78422:	mov    0x2a8(%r14),%r8
 1f78429:	add    %r9,%r8
 1f7842c:	vmovsd (%r8,%rdx,8),%xmm0
 1f78432:	mov    0x2a0(%r14),%r8
 1f78439:	add    %r9,%r8
 1f7843c:	vmovsd (%r8,%rdx,8),%xmm1
 1f78442:	mov    0x2b0(%r14),%r8
 1f78449:	add    %r9,%r8
 1f7844c:	mov    (%r8,%rdx,8),%r8
 1f78450:	mov    %r12d,(%r15)
 1f78453:	mov    %r13d,0x4(%r15)
 1f78457:	mov    %edi,0x8(%r15)
 1f7845b:	mov    %r10d,0xc(%r15)
 1f7845f:	mov    %rax,0x10(%r15)
 1f78463:	movabs $0x2525252525252525,%rax
 1f7846d:	mov    %bpl,0x18(%r15)
 1f78471:	movb   $0x1,0x19(%r15)
 1f78476:	mov    %bx,0x1a(%r15)
 1f7847b:	movl   $0x0,0x1c(%r15)
 1f78483:	vmovlhps %xmm0,%xmm1,%xmm0
 1f78487:	vmovups %xmm0,0x20(%r15)
 1f7848d:	mov    %r8,0x30(%r15)
 1f78491:	mov    %rax,0x38(%r15)
 1f78495:	mov    0x288(%r14),%rax
 1f7849c:	mov    0x280(%r14),%rbx
 1f784a3:	add    %rcx,%rax
 1f784a6:	add    %r9,%rbx
 1f784a9:	movzbl 0x1(%rdx,%rax,1),%ebp
 1f784ae:	mov    0x268(%r14),%rax
 1f784b5:	add    %r11,%rax
 1f784b8:	mov    %ebp,%r8d
 1f784bb:	mov    0x4(%rax,%rdx,4),%r12d
 1f784c0:	mov    0x298(%r14),%rax
 1f784c7:	and    $0x60,%r8b
 1f784cb:	add    %r11,%rax
 1f784ce:	mov    0x4(%rax,%rdx,4),%r13d
 1f784d3:	mov    0x270(%r14),%rax
 1f784da:	add    %r11,%rax
 1f784dd:	mov    0x4(%rax,%rdx,4),%edi
 1f784e1:	mov    0x278(%r14),%rax
 1f784e8:	add    %r11,%rax
 1f784eb:	mov    0x4(%rax,%rdx,4),%r10d
 1f784f0:	mov    0x8(%rbx,%rdx,8),%rax
 1f784f5:	cmp    $0x40,%r8b
 1f784f9:	je     1f78310 <node_facts_reader_flush+0x1350>
 1f784ff:	xor    %ebx,%ebx
 1f78501:	jmp    1f78323 <node_facts_reader_flush+0x1363>
 1f78506:	cs nopw 0x0(%rax,%rax,1)
 1f78510:	testb  $0x1,(%rsp)
 1f78514:	mov    0x40(%rsp),%r13
 1f78519:	mov    0x18(%rsp),%rsi
 1f7851e:	mov    0x8(%rsp),%r12
 1f78523:	je     1f78274 <node_facts_reader_flush+0x12b4>
 1f78529:	mov    0x288(%r14),%rax
 1f78530:	add    %rdx,%rcx
 1f78533:	movzbl (%rax,%rcx,1),%edi
 1f78537:	mov    %edi,%eax
 1f78539:	and    $0x60,%al
 1f7853b:	cmp    $0x40,%al
 1f7853d:	je     1f781b7 <node_facts_reader_flush+0x11f7>
 1f78543:	xor    %eax,%eax
 1f78545:	jmp    1f781c2 <node_facts_reader_flush+0x1202>
 1f7854a:	cmpb   $0x1,0xb38(%r14)
 1f78552:	jne    1f785cd <node_facts_reader_flush+0x160d>
 1f78558:	rdtsc
 1f7855a:	mov    %rdx,%r12
 1f7855d:	shl    $0x20,%r12
 1f78561:	or     %rax,%r12
 1f78564:	cmpl   $0x0,0xa90(%r14)
 1f7856c:	je     1f785a5 <node_facts_reader_flush+0x15e5>
 1f7856e:	xor    %ebx,%ebx
 1f78570:	mov    0xa48(%r14),%rax
 1f78577:	mov    0xa50(%r14),%rcx
 1f7857e:	mov    %r13,%rdi
 1f78581:	mov    (%rax,%rbx,4),%esi
 1f78584:	mov    0xa58(%r14),%rax
 1f7858b:	mov    (%rcx,%rbx,4),%edx
 1f7858e:	mov    (%rax,%rbx,4),%ecx
 1f78591:	call   1f53190 <node_machine_type>
 1f78596:	mov    0xa90(%r14),%eax
 1f7859d:	inc    %rbx
 1f785a0:	cmp    %rax,%rbx
 1f785a3:	jb     1f78570 <node_facts_reader_flush+0x15b0>
 1f785a5:	rdtsc
 1f785a7:	shl    $0x20,%rdx
 1f785ab:	or     %rax,%rdx
 1f785ae:	sub    %r12,%rdx
 1f785b1:	mov    0x20(%rsp),%r12
 1f785b6:	add    %rdx,0x920(%r12)
 1f785be:	mov    0x250(%r14),%eax
 1f785c5:	add    %rax,0x928(%r12)
 1f785cd:	xor    %esi,%esi
 1f785cf:	jmp    1f786c4 <node_facts_reader_flush+0x1704>
 1f785d4:	mov    0x290(%r14),%rax
 1f785db:	movzwl (%rax,%rcx,2),%eax
 1f785df:	mov    0x270(%r14),%r9
 1f785e6:	mov    0x2a0(%r14),%r11
 1f785ed:	mov    0x2a8(%r14),%rbx
 1f785f4:	shl    $0x6,%rdx
 1f785f8:	mov    0x298(%r14),%r8
 1f785ff:	mov    0x280(%r14),%r10
 1f78606:	mov    0x2b0(%r14),%r15
 1f7860d:	add    %rdx,%r13
 1f78610:	mov    0x268(%r14),%rdx
 1f78617:	mov    (%r9,%rcx,4),%ebp
 1f7861b:	mov    0x278(%r14),%r9
 1f78622:	vmovq  (%rbx,%rcx,8),%xmm0
 1f78627:	vmovq  (%r11,%rcx,8),%xmm1
 1f7862d:	mov    (%r8,%rcx,4),%r8d
 1f78631:	mov    (%r10,%rcx,8),%r10
 1f78635:	mov    (%r15,%rcx,8),%r15
 1f78639:	mov    (%rdx,%rcx,4),%edx
 1f7863c:	mov    (%r9,%rcx,4),%r9d
 1f78640:	movabs $0x2525252525252525,%rcx
 1f7864a:	mov    %edx,0x0(%r13)
 1f7864e:	mov    %r8d,0x4(%r13)
 1f78652:	mov    %ebp,0x8(%r13)
 1f78656:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f7865a:	mov    %r9d,0xc(%r13)
 1f7865e:	mov    %r10,0x10(%r13)
 1f78662:	mov    %dil,0x18(%r13)
 1f78666:	movb   $0x1,0x19(%r13)
 1f7866b:	mov    %ax,0x1a(%r13)
 1f78670:	movl   $0x0,0x1c(%r13)
 1f78678:	vmovdqu %xmm0,0x20(%r13)
 1f7867e:	mov    %r15,0x30(%r13)
 1f78682:	mov    %rcx,0x38(%r13)
 1f78686:	rdtsc
 1f78688:	lea    0x1(%rsi),%rbx
 1f7868c:	mov    %r14,%rdi
 1f7868f:	xor    %ecx,%ecx
 1f78691:	mov    %rdx,%r15
 1f78694:	shl    $0x20,%r15
 1f78698:	xor    %edx,%edx
 1f7869a:	or     %rax,%r15
 1f7869d:	call   1f7be00 <node_facts_window>
 1f786a2:	rdtsc
 1f786a4:	mov    %rbx,%rsi
 1f786a7:	shl    $0x20,%rdx
 1f786ab:	or     %rax,%rdx
 1f786ae:	sub    %r15,%rdx
 1f786b1:	add    %rdx,0x918(%r12)
 1f786b9:	cmp    0x28(%rsp),%rbx
 1f786be:	je     1f789dd <node_facts_reader_flush+0x1a1d>
 1f786c4:	mov    0x248(%r14),%rax
 1f786cb:	mov    (%rax,%rsi,4),%ecx
 1f786ce:	mov    0x4(%rax,%rsi,4),%eax
 1f786d2:	cmp    %ecx,%eax
 1f786d4:	je     1f78686 <node_facts_reader_flush+0x16c6>
 1f786d6:	mov    0x2c0(%r14),%r13
 1f786dd:	sub    %ecx,%eax
 1f786df:	cmp    $0x1,%eax
 1f786e2:	jne    1f786f0 <node_facts_reader_flush+0x1730>
 1f786e4:	xor    %edx,%edx
 1f786e6:	jmp    1f78939 <node_facts_reader_flush+0x1979>
 1f786eb:	nopl   0x0(%rax,%rax,1)
 1f786f0:	lea    0x0(,%rcx,8),%r9
 1f786f8:	lea    0x0(,%rcx,4),%r11
 1f78700:	mov    %rsi,0x18(%rsp)
 1f78705:	mov    %eax,%esi
 1f78707:	and    $0xfffffffe,%esi
 1f7870a:	mov    %rax,(%rsp)
 1f7870e:	mov    %r13,0x8(%rsp)
 1f78713:	mov    %r13,%r15
 1f78716:	xor    %edx,%edx
 1f78718:	jmp    1f787bb <node_facts_reader_flush+0x17fb>
 1f7871d:	nopl   (%rax)
 1f78720:	mov    0x290(%r14),%r8
 1f78727:	add    %rcx,%r8
 1f7872a:	add    %rcx,%r8
 1f7872d:	movzwl 0x2(%r8,%rdx,2),%ebx
 1f78733:	mov    0x2a8(%r14),%r8
 1f7873a:	add    %r9,%r8
 1f7873d:	vmovq  0x8(%r8,%rdx,8),%xmm0
 1f78744:	mov    0x2a0(%r14),%r8
 1f7874b:	add    %r9,%r8
 1f7874e:	vmovq  0x8(%r8,%rdx,8),%xmm1
 1f78755:	mov    0x2b0(%r14),%r8
 1f7875c:	add    %r9,%r8
 1f7875f:	mov    0x8(%r8,%rdx,8),%r8
 1f78764:	mov    %r12d,0x40(%r15)
 1f78768:	mov    %r13d,0x44(%r15)
 1f7876c:	mov    %edi,0x48(%r15)
 1f78770:	mov    %r10d,0x4c(%r15)
 1f78774:	mov    %rax,0x50(%r15)
 1f78778:	movabs $0x2525252525252525,%rax
 1f78782:	mov    %bpl,0x58(%r15)
 1f78786:	movb   $0x1,0x59(%r15)
 1f7878b:	mov    %bx,0x5a(%r15)
 1f78790:	movl   $0x0,0x5c(%r15)
 1f78798:	add    $0x2,%rdx
 1f7879c:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f787a0:	vmovdqu %xmm0,0x60(%r15)
 1f787a6:	mov    %r8,0x70(%r15)
 1f787aa:	mov    %rax,0x78(%r15)
 1f787ae:	sub    $0xffffffffffffff80,%r15
 1f787b2:	cmp    %rdx,%rsi
 1f787b5:	je     1f78920 <node_facts_reader_flush+0x1960>
 1f787bb:	mov    0x288(%r14),%rax
 1f787c2:	mov    0x280(%r14),%r8
 1f787c9:	add    %rcx,%rax
 1f787cc:	add    %r9,%r8
 1f787cf:	movzbl (%rdx,%rax,1),%ebp
 1f787d3:	mov    0x268(%r14),%rax
 1f787da:	add    %r11,%rax
 1f787dd:	mov    %ebp,%ebx
 1f787df:	mov    (%rax,%rdx,4),%r12d
 1f787e3:	mov    0x298(%r14),%rax
 1f787ea:	and    $0x60,%bl
 1f787ed:	add    %r11,%rax
 1f787f0:	mov    (%rax,%rdx,4),%r13d
 1f787f4:	mov    0x270(%r14),%rax
 1f787fb:	add    %r11,%rax
 1f787fe:	mov    (%rax,%rdx,4),%edi
 1f78801:	mov    0x278(%r14),%rax
 1f78808:	add    %r11,%rax
 1f7880b:	mov    (%rax,%rdx,4),%r10d
 1f7880f:	mov    (%r8,%rdx,8),%rax
 1f78813:	cmp    $0x40,%bl
 1f78816:	jne    1f78830 <node_facts_reader_flush+0x1870>
 1f78818:	mov    0x290(%r14),%rbx
 1f7881f:	add    %rcx,%rbx
 1f78822:	add    %rcx,%rbx
 1f78825:	movzwl (%rbx,%rdx,2),%ebx
 1f78829:	jmp    1f78832 <node_facts_reader_flush+0x1872>
 1f7882b:	nopl   0x0(%rax,%rax,1)
 1f78830:	xor    %ebx,%ebx
 1f78832:	mov    0x2a8(%r14),%r8
 1f78839:	add    %r9,%r8
 1f7883c:	vmovsd (%r8,%rdx,8),%xmm0
 1f78842:	mov    0x2a0(%r14),%r8
 1f78849:	add    %r9,%r8
 1f7884c:	vmovsd (%r8,%rdx,8),%xmm1
 1f78852:	mov    0x2b0(%r14),%r8
 1f78859:	add    %r9,%r8
 1f7885c:	mov    (%r8,%rdx,8),%r8
 1f78860:	mov    %r12d,(%r15)
 1f78863:	mov    %r13d,0x4(%r15)
 1f78867:	mov    %edi,0x8(%r15)
 1f7886b:	mov    %r10d,0xc(%r15)
 1f7886f:	mov    %rax,0x10(%r15)
 1f78873:	movabs $0x2525252525252525,%rax
 1f7887d:	mov    %bpl,0x18(%r15)
 1f78881:	movb   $0x1,0x19(%r15)
 1f78886:	mov    %bx,0x1a(%r15)
 1f7888b:	movl   $0x0,0x1c(%r15)
 1f78893:	vmovlhps %xmm0,%xmm1,%xmm0
 1f78897:	vmovups %xmm0,0x20(%r15)
 1f7889d:	mov    %r8,0x30(%r15)
 1f788a1:	mov    %rax,0x38(%r15)
 1f788a5:	mov    0x288(%r14),%rax
 1f788ac:	mov    0x280(%r14),%rbx
 1f788b3:	add    %rcx,%rax
 1f788b6:	add    %r9,%rbx
 1f788b9:	movzbl 0x1(%rdx,%rax,1),%ebp
 1f788be:	mov    0x268(%r14),%rax
 1f788c5:	add    %r11,%rax
 1f788c8:	mov    %ebp,%r8d
 1f788cb:	mov    0x4(%rax,%rdx,4),%r12d
 1f788d0:	mov    0x298(%r14),%rax
 1f788d7:	and    $0x60,%r8b
 1f788db:	add    %r11,%rax
 1f788de:	mov    0x4(%rax,%rdx,4),%r13d
 1f788e3:	mov    0x270(%r14),%rax
 1f788ea:	add    %r11,%rax
 1f788ed:	mov    0x4(%rax,%rdx,4),%edi
 1f788f1:	mov    0x278(%r14),%rax
 1f788f8:	add    %r11,%rax
 1f788fb:	mov    0x4(%rax,%rdx,4),%r10d
 1f78900:	mov    0x8(%rbx,%rdx,8),%rax
 1f78905:	cmp    $0x40,%r8b
 1f78909:	je     1f78720 <node_facts_reader_flush+0x1760>
 1f7890f:	xor    %ebx,%ebx
 1f78911:	jmp    1f78733 <node_facts_reader_flush+0x1773>
 1f78916:	cs nopw 0x0(%rax,%rax,1)
 1f78920:	testb  $0x1,(%rsp)
 1f78924:	mov    0x20(%rsp),%r12
 1f78929:	mov    0x18(%rsp),%rsi
 1f7892e:	mov    0x8(%rsp),%r13
 1f78933:	je     1f78686 <node_facts_reader_flush+0x16c6>
 1f78939:	mov    0x288(%r14),%rax
 1f78940:	add    %rdx,%rcx
 1f78943:	movzbl (%rax,%rcx,1),%edi
 1f78947:	mov    %edi,%eax
 1f78949:	and    $0x60,%al
 1f7894b:	cmp    $0x40,%al
 1f7894d:	je     1f785d4 <node_facts_reader_flush+0x1614>
 1f78953:	xor    %eax,%eax
 1f78955:	jmp    1f785df <node_facts_reader_flush+0x161f>
 1f7895a:	cmpb   $0x1,0xb38(%r14)
 1f78962:	jne    1f789dd <node_facts_reader_flush+0x1a1d>
 1f78968:	rdtsc
 1f7896a:	mov    %rdx,%r12
 1f7896d:	shl    $0x20,%r12
 1f78971:	or     %rax,%r12
 1f78974:	cmpl   $0x0,0xa90(%r14)
 1f7897c:	je     1f789b5 <node_facts_reader_flush+0x19f5>
 1f7897e:	xor    %ebx,%ebx
 1f78980:	mov    0xa48(%r14),%rax
 1f78987:	mov    0xa50(%r14),%rcx
 1f7898e:	mov    %r13,%rdi
 1f78991:	mov    (%rax,%rbx,4),%esi
 1f78994:	mov    0xa58(%r14),%rax
 1f7899b:	mov    (%rcx,%rbx,4),%edx
 1f7899e:	mov    (%rax,%rbx,4),%ecx
 1f789a1:	call   1f53190 <node_machine_type>
 1f789a6:	mov    0xa90(%r14),%eax
 1f789ad:	inc    %rbx
 1f789b0:	cmp    %rax,%rbx
 1f789b3:	jb     1f78980 <node_facts_reader_flush+0x19c0>
 1f789b5:	rdtsc
 1f789b7:	shl    $0x20,%rdx
 1f789bb:	or     %rax,%rdx
 1f789be:	sub    %r12,%rdx
 1f789c1:	mov    0x20(%rsp),%r12
 1f789c6:	add    %rdx,0x920(%r12)
 1f789ce:	mov    0x250(%r14),%eax
 1f789d5:	add    %rax,0x928(%r12)
 1f789dd:	mov    0xa90(%r14),%eax
 1f789e4:	vmovd  0x28(%rsp),%xmm0
 1f789ea:	mov    0x48(%rsp),%r15
 1f789ef:	add    %rax,0x8a8(%r12)
 1f789f7:	vmovd  0x250(%r14),%xmm1
 1f78a00:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f78a04:	vpaddq 0x8b0(%r12),%xmm0,%xmm0
 1f78a0e:	vmovdqu %xmm0,0x8b0(%r12)
 1f78a18:	cmpb   $0x1,0x9b0(%r14)
 1f78a20:	jne    1f78a2d <node_facts_reader_flush+0x1a6d>
 1f78a22:	mov    %r14,%rdi
 1f78a25:	mov    %r15,%rsi
 1f78a28:	call   1f7d4d0 <node_facts_window_run>
 1f78a2d:	mov    0x60(%r14),%eax
 1f78a31:	mov    %rax,0x938(%r12)
 1f78a39:	mov    0x920(%r14),%rax
 1f78a40:	mov    %rax,0x940(%r12)
 1f78a48:	mov    0x68(%r14),%eax
 1f78a4c:	sub    0x70(%r14),%eax
 1f78a50:	mov    %rax,0x948(%r12)
 1f78a58:	mov    0x928(%r14),%rax
 1f78a5f:	mov    %rax,0x950(%r12)
 1f78a67:	mov    0x8f8(%r14),%rax
 1f78a6e:	mov    %rax,0x958(%r12)
 1f78a76:	mov    0x900(%r14),%rax
 1f78a7d:	mov    %rax,0x960(%r12)
 1f78a85:	mov    0x78(%r14),%eax
 1f78a89:	mov    %rax,0x968(%r12)
 1f78a91:	mov    0xa8(%r14),%eax
 1f78a98:	mov    %rax,0x970(%r12)
 1f78aa0:	mov    0xd0(%r14),%rax
 1f78aa7:	mov    %rax,0xa40(%r12)
 1f78aaf:	mov    0xd8(%r14),%rax
 1f78ab6:	mov    %rax,0xa48(%r12)
 1f78abe:	movl   $0x0,0x250(%r14)
 1f78ac9:	movq   $0x0,0x258(%r14)
 1f78ad4:	movl   $0xffffffff,0x260(%r14)
 1f78adf:	mov    0x248(%r14),%rax
 1f78ae6:	movl   $0x0,(%rax)
 1f78aec:	movzbl 0x9b0(%r14),%eax
 1f78af4:	shl    $0xc,%eax
 1f78af7:	mov    %eax,0x74(%r14)
 1f78afb:	movl   $0x0,0x9a8(%r14)
 1f78b06:	movl   $0x0,0xa90(%r14)
 1f78b11:	incq   0xb30(%r14)
 1f78b18:	cmpq   $0x0,0xc20(%r14)
 1f78b20:	je     1f78b6d <node_facts_reader_flush+0x1bad>
 1f78b22:	rdtsc
 1f78b24:	mov    %rdx,%rcx
 1f78b27:	shl    $0x20,%rcx
 1f78b2b:	or     %rax,%rcx
 1f78b2e:	cmpl   $0x0,0x8(%r15)
 1f78b33:	je     1f78b59 <node_facts_reader_flush+0x1b99>
 1f78b35:	xor    %eax,%eax
 1f78b37:	vpxor  %xmm0,%xmm0,%xmm0
 1f78b3b:	nopl   0x0(%rax,%rax,1)
 1f78b40:	mov    0xc70(%r14),%rdx
 1f78b47:	mov    %eax,%esi
 1f78b49:	add    $0x40,%eax
 1f78b4c:	vmovdqu64 %zmm0,(%rdx,%rsi,1)
 1f78b53:	cmp    0x8(%r15),%eax
 1f78b57:	jb     1f78b40 <node_facts_reader_flush+0x1b80>
 1f78b59:	rdtsc
 1f78b5b:	shl    $0x20,%rdx
 1f78b5f:	or     %rax,%rdx
 1f78b62:	sub    %rcx,%rdx
 1f78b65:	add    %rdx,0xcc8(%r12)
 1f78b6d:	add    $0x58,%rsp
 1f78b71:	pop    %rbx
 1f78b72:	pop    %r12
 1f78b74:	pop    %r13
 1f78b76:	pop    %r14
 1f78b78:	pop    %r15
 1f78b7a:	pop    %rbp
 1f78b7b:	vzeroupper
 1f78b7e:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
