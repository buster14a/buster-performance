
results/xh4/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f78b80 <node_facts_front_expression>:
 1f78b80:	push   %rbp
 1f78b81:	push   %r15
 1f78b83:	push   %r14
 1f78b85:	push   %r13
 1f78b87:	push   %r12
 1f78b89:	push   %rbx
 1f78b8a:	sub    $0xb8,%rsp
 1f78b91:	mov    %r8d,%ebp
 1f78b94:	mov    %rdx,0x78(%rsp)
 1f78b99:	mov    %rsi,%r10
 1f78b9c:	mov    %rdi,%r12
 1f78b9f:	xor    %eax,%eax
 1f78ba1:	cmp    %r8d,%r9d
 1f78ba4:	jae    1f78bb1 <node_facts_front_expression+0x31>
 1f78ba6:	mov    %r9d,%eax
 1f78ba9:	mov    0x651b8(%r10,%rax,4),%eax
 1f78bb1:	cmpb   $0x1,0x69238(%r10)
 1f78bb9:	jne    1f7a007 <node_facts_front_expression+0x1487>
 1f78bbf:	cmp    %ebp,%r9d
 1f78bc2:	mov    %ebp,%edx
 1f78bc4:	cmovb  %r9d,%edx
 1f78bc8:	cmpb   $0xfe,0x6a4d4(%r10,%rdx,1)
 1f78bd1:	setne  %dl
 1f78bd4:	test   %eax,%eax
 1f78bd6:	je     1f7a01d <node_facts_front_expression+0x149d>
 1f78bdc:	mov    %ebp,%esi
 1f78bde:	xor    %edi,%edi
 1f78be0:	cmpb   $0x23,0x2c(%r10,%rsi,1)
 1f78be6:	setne  %dil
 1f78bea:	add    %eax,%edi
 1f78bec:	cmp    %edi,%ecx
 1f78bee:	sete   %sil
 1f78bf2:	inc    %r9d
 1f78bf5:	sub    %eax,%r9d
 1f78bf8:	setae  %dil
 1f78bfc:	and    %dl,%dil
 1f78bff:	and    %sil,%dil
 1f78c02:	mov    %edi,%edx
 1f78c04:	xor    $0x1,%dl
 1f78c07:	movzbl %dl,%esi
 1f78c0a:	xor    %edx,%edx
 1f78c0c:	test   %dil,%dil
 1f78c0f:	cmovne %r9d,%edx
 1f78c13:	test   %ecx,%ecx
 1f78c15:	sete   %dil
 1f78c19:	mov    %rdx,0x70(%rsp)
 1f78c1e:	or     %sil,%dil
 1f78c21:	jne    1f7a024 <node_facts_front_expression+0x14a4>
 1f78c27:	vpbroadcastd -0x19a7d11(%rip),%zmm17        # 5d0f20 <.LCPI1287_0>
 1f78c31:	mov    0x948(%r12),%rdi
 1f78c39:	mov    0x10(%r12),%rdx
 1f78c3e:	vpternlogd $0xff,%xmm16,%xmm16,%xmm16
 1f78c45:	mov    %eax,%eax
 1f78c47:	mov    %rax,0x60(%rsp)
 1f78c4c:	mov    %ecx,%eax
 1f78c4e:	xor    %r14d,%r14d
 1f78c51:	mov    %esi,0x18(%rsp)
 1f78c55:	mov    %rax,0x68(%rsp)
 1f78c5a:	mov    %ebp,0x24(%rsp)
 1f78c5e:	mov    %r10,0x38(%rsp)
 1f78c63:	mov    %rdx,0x58(%rsp)
 1f78c68:	mov    %rdi,0x28(%rsp)
 1f78c6d:	jmp    1f78c95 <node_facts_front_expression+0x115>
 1f78c6f:	nop
 1f78c70:	mov    0x998(%r12),%rax
 1f78c78:	inc    %r11d
 1f78c7b:	inc    %r14
 1f78c7e:	mov    %r9d,0x18(%rsp)
 1f78c83:	mov    %r11d,(%rax,%rcx,4)
 1f78c87:	mov    %r9d,%eax
 1f78c8a:	cmp    0x68(%rsp),%r14
 1f78c8f:	jae    1f7a02d <node_facts_front_expression+0x14ad>
 1f78c95:	mov    0x70(%rsp),%rax
 1f78c9a:	mov    $0x1,%r9d
 1f78ca0:	cmp    0x60(%rsp),%r14
 1f78ca5:	lea    (%rax,%r14,1),%r15d
 1f78ca9:	cmove  %ebp,%r15d
 1f78cad:	je     1f78cb8 <node_facts_front_expression+0x138>
 1f78caf:	movzbl 0x1442c(%r10,%r15,1),%r9d
 1f78cb8:	mov    0x78(%rsp),%rax
 1f78cbd:	movzbl 0x154ac(%r10,%r15,1),%ecx
 1f78cc6:	movzbl 0x2c(%r10,%r15,1),%ebx
 1f78ccc:	mov    0x422c(%r10,%r15,4),%r11d
 1f78cd4:	mov    %r9d,0xc(%rsp)
 1f78cd9:	lea    (%rax,%r14,1),%r13d
 1f78cdd:	movzbl %cl,%eax
 1f78ce0:	cmp    $0xff,%rcx
 1f78ce7:	mov    %eax,0x4c(%rsp)
 1f78ceb:	movzbl 0x1652c(%r10,%r15,1),%eax
 1f78cf4:	setne  %dl
 1f78cf7:	cmp    $0xff,%rax
 1f78cfd:	setne  %sil
 1f78d01:	cmp    $0xff,%r9d
 1f78d08:	setne  %r8b
 1f78d0c:	and    %dl,%r8b
 1f78d0f:	mov    %r9d,%edx
 1f78d12:	cmp    %rdx,%r14
 1f78d15:	setae  %dl
 1f78d18:	and    %sil,%dl
 1f78d1b:	and    %r8b,%dl
 1f78d1e:	cmp    %rcx,%r14
 1f78d21:	mov    %ebx,%r8d
 1f78d24:	mov    $0x2,%ebx
 1f78d29:	setae  %sil
 1f78d2d:	cmp    %rax,%r14
 1f78d30:	setae  %cl
 1f78d33:	and    %sil,%cl
 1f78d36:	and    %dl,%cl
 1f78d38:	cmovne 0x18(%rsp),%ebx
 1f78d3d:	cmp    $0x1,%cl
 1f78d40:	jne    1f78e30 <node_facts_front_expression+0x2b0>
 1f78d46:	test   %r8b,%r8b
 1f78d49:	jne    1f78e30 <node_facts_front_expression+0x2b0>
 1f78d4f:	mov    0x33aac(%r10,%r15,4),%edx
 1f78d57:	movzbl 0x4bd30(%r10,%r15,1),%eax
 1f78d60:	mov    %r8b,0xa(%rsp)
 1f78d65:	mov    %edx,%ecx
 1f78d67:	shr    $0x3,%ecx
 1f78d6a:	cmp    $0x1,%eax
 1f78d6d:	je     1f78ecf <node_facts_front_expression+0x34f>
 1f78d73:	test   %eax,%eax
 1f78d75:	jne    1f78f6b <node_facts_front_expression+0x3eb>
 1f78d7b:	mov    0x43cb0(%r10,%r15,8),%rsi
 1f78d83:	mov    0x30(%r12),%rcx
 1f78d88:	mov    %esi,%eax
 1f78d8a:	movslq (%rcx,%rax,4),%rax
 1f78d8e:	test   %rax,%rax
 1f78d91:	jle    1f78dc8 <node_facts_front_expression+0x248>
 1f78d93:	mov    0x8(%r12),%r9
 1f78d98:	mov    0x28(%r12),%rcx
 1f78d9d:	mov    %rax,%rdx
 1f78da0:	shl    $0x5,%rdx
 1f78da4:	mov    0x438(%r9),%r8
 1f78dab:	mov    (%r8,%r11,4),%r8d
 1f78daf:	cmp    (%rcx,%rdx,1),%r8d
 1f78db3:	jne    1f78dc8 <node_facts_front_expression+0x248>
 1f78db5:	mov    0x298(%r9),%r8
 1f78dbc:	test   %r8,%r8
 1f78dbf:	je     1f78e0a <node_facts_front_expression+0x28a>
 1f78dc1:	cmpl   $0x0,0x8(%r8)
 1f78dc6:	je     1f78e0a <node_facts_front_expression+0x28a>
 1f78dc8:	mov    %r12,%rdi
 1f78dcb:	mov    %r11d,%edx
 1f78dce:	mov    %r11,%r15
 1f78dd1:	vzeroupper
 1f78dd4:	call   1f52900 <node_facts_declaration>
 1f78dd9:	vpbroadcastd -0x19a7ec3(%rip),%zmm17        # 5d0f20 <.LCPI1287_0>
 1f78de3:	mov    0x38(%rsp),%r10
 1f78de8:	mov    0x28(%rsp),%rdi
 1f78ded:	vpternlogd $0xff,%xmm16,%xmm16,%xmm16
 1f78df4:	mov    %r15,%r11
 1f78df7:	test   %eax,%eax
 1f78df9:	je     1f790d2 <node_facts_front_expression+0x552>
 1f78dff:	mov    0x28(%r12),%rcx
 1f78e04:	mov    %eax,%edx
 1f78e06:	shl    $0x5,%rdx
 1f78e0a:	testb  $0x4,0x1c(%rcx,%rdx,1)
 1f78e0f:	jne    1f790d2 <node_facts_front_expression+0x552>
 1f78e15:	mov    $0xff,%r15b
 1f78e18:	movb   $0x2,0xb(%rsp)
 1f78e1d:	movq   $0x0,0x10(%rsp)
 1f78e26:	jmp    1f79810 <node_facts_front_expression+0xc90>
 1f78e2b:	nopl   0x0(%rax,%rax,1)
 1f78e30:	test   %cl,%cl
 1f78e32:	je     1f7a028 <node_facts_front_expression+0x14a8>
 1f78e38:	movzbl %r8b,%ecx
 1f78e3c:	movzbl %al,%r9d
 1f78e40:	movzbl 0xae5(%r12,%rcx,1),%eax
 1f78e49:	movzbl 0xaa0(%r12,%rcx,1),%edx
 1f78e52:	mov    %al,0x30(%rsp)
 1f78e56:	cmp    $0x18,%r8b
 1f78e5a:	jne    1f78ea0 <node_facts_front_expression+0x320>
 1f78e5c:	mov    0xc(%rsp),%ebx
 1f78e60:	cmp    0x60(%rsp),%r14
 1f78e65:	je     1f78e7b <node_facts_front_expression+0x2fb>
 1f78e67:	mov    0x1f0(%rdi),%rax
 1f78e6e:	mov    (%rax,%r11,4),%eax
 1f78e72:	cmp    $0x8,%eax
 1f78e75:	jne    1f794df <node_facts_front_expression+0x95f>
 1f78e7b:	movzbl 0x93d(%r12),%edx
 1f78e84:	mov    $0x8,%eax
 1f78e89:	movb   $0xd,0x30(%rsp)
 1f78e8e:	movq   $0x0,0x10(%rsp)
 1f78e97:	add    $0x3,%dl
 1f78e9a:	jmp    1f794f0 <node_facts_front_expression+0x970>
 1f78e9f:	nop
 1f78ea0:	mov    0xc(%rsp),%ebx
 1f78ea4:	mov    %r8d,%eax
 1f78ea7:	and    $0xfe,%al
 1f78ea9:	cmp    $0x20,%al
 1f78eab:	jne    1f7909e <node_facts_front_expression+0x51e>
 1f78eb1:	mov    0x58(%rsp),%rax
 1f78eb6:	lea    0x1(%r11),%ecx
 1f78eba:	movq   $0x0,0x10(%rsp)
 1f78ec3:	mov    0x60(%rax),%rax
 1f78ec7:	mov    (%rax,%rcx,4),%eax
 1f78eca:	jmp    1f794f0 <node_facts_front_expression+0x970>
 1f78ecf:	cmp    0x60(%r12),%ecx
 1f78ed4:	jae    1f78eeb <node_facts_front_expression+0x36b>
 1f78ed6:	mov    0x20(%r12),%r8
 1f78edb:	shl    $0x6,%rcx
 1f78edf:	testb  $0x1,0x34(%r8,%rcx,1)
 1f78ee5:	jne    1f79206 <node_facts_front_expression+0x686>
 1f78eeb:	lea    0x80(%rsp),%rdx
 1f78ef3:	mov    %r11d,%esi
 1f78ef6:	mov    %r11,0x40(%rsp)
 1f78efb:	vzeroupper
 1f78efe:	call   14f1600 <node_front_literal>
 1f78f03:	mov    0x80(%rsp),%edx
 1f78f0a:	mov    0x88(%rsp),%rbp
 1f78f12:	mov    0x90(%rsp),%r10
 1f78f1a:	movzwl 0x98(%rsp),%r9d
 1f78f23:	mov    0xa8(%rsp),%rsi
 1f78f2b:	testb  $0x1,0xa1(%rsp)
 1f78f33:	je     1f79108 <node_facts_front_expression+0x588>
 1f78f39:	mov    $0x4,%ecx
 1f78f3e:	mov    $0x20000,%r11d
 1f78f44:	cmp    $0x1b0,%edx
 1f78f4a:	je     1f79fec <node_facts_front_expression+0x146c>
 1f78f50:	mov    %rbp,0x18(%rsp)
 1f78f55:	mov    %r9,%rdi
 1f78f58:	mov    %r10,%rsi
 1f78f5b:	xor    %r8d,%r8d
 1f78f5e:	xor    %r9d,%r9d
 1f78f61:	xor    %r10d,%r10d
 1f78f64:	xor    %ebp,%ebp
 1f78f66:	jmp    1f79142 <node_facts_front_expression+0x5c2>
 1f78f6b:	mov    0x43cb0(%r10,%r15,8),%ebx
 1f78f73:	xor    %r8d,%r8d
 1f78f76:	mov    $0x3,%esi
 1f78f7b:	mov    %r11,0x40(%rsp)
 1f78f80:	mov    $0x1,%al
 1f78f82:	mov    %rsi,0x10(%rsp)
 1f78f87:	mov    $0x1,%esi
 1f78f8c:	mov    %rsi,0x30(%rsp)
 1f78f91:	mov    $0x1,%sil
 1f78f94:	test   %ebx,%ebx
 1f78f96:	setne  %r8b
 1f78f9a:	xor    %r11d,%r11d
 1f78f9d:	xor    %r9d,%r9d
 1f78fa0:	xor    %r10d,%r10d
 1f78fa3:	shl    $0x17,%r8d
 1f78fa7:	or     $0x80,%r8d
 1f78fae:	mov    (%r12),%rdi
 1f78fb2:	mov    $0xff,%ebp
 1f78fb7:	cmp    0x28(%rdi),%ecx
 1f78fba:	jae    1f78fc5 <node_facts_front_expression+0x445>
 1f78fbc:	mov    0x18(%rdi),%rdi
 1f78fc0:	mov    %ecx,%ecx
 1f78fc2:	mov    (%rdi,%rcx,4),%ebp
 1f78fc5:	cmp    $0xfffe,%r10
 1f78fcc:	mov    $0xfffe,%ecx
 1f78fd1:	mov    $0xff,%r15b
 1f78fd4:	movb   $0x1,0xb(%rsp)
 1f78fd9:	cmovb  %r10,%rcx
 1f78fdd:	inc    %ecx
 1f78fdf:	test   %sil,%sil
 1f78fe2:	cmovne %ecx,%r9d
 1f78fe6:	test   %r11b,%r11b
 1f78fe9:	je     1f78fff <node_facts_front_expression+0x47f>
 1f78feb:	mov    0x24(%rsp),%ebp
 1f78fef:	movq   $0x0,0x10(%rsp)
 1f78ff8:	xor    %eax,%eax
 1f78ffa:	jmp    1f7961d <node_facts_front_expression+0xa9d>
 1f78fff:	mov    0x10(%rsp),%rdi
 1f79004:	mov    0x40(%rsp),%r11
 1f79009:	cmp    $0x1,%edi
 1f7900c:	setne  %cl
 1f7900f:	and    %al,%cl
 1f79011:	or     %sil,%cl
 1f79014:	cmp    $0x1,%cl
 1f79017:	jne    1f790ea <node_facts_front_expression+0x56a>
 1f7901d:	mov    0x74(%r12),%eax
 1f79022:	cmp    0x70(%r12),%eax
 1f79027:	jae    1f790ea <node_facts_front_expression+0x56a>
 1f7902d:	xor    $0x1,%sil
 1f79031:	inc    %rax
 1f79034:	movb   $0x6,0xb(%rsp)
 1f79039:	movq   $0x0,0x10(%rsp)
 1f79042:	movzbl %sil,%ecx
 1f79046:	mov    0x30(%rsp),%rsi
 1f7904b:	mov    %eax,0x74(%r12)
 1f79050:	shl    $0x6,%ecx
 1f79053:	lea    (%rsi,%rdi,4),%esi
 1f79056:	mov    %r11,%rdi
 1f79059:	mov    %rax,%r11
 1f7905c:	shl    $0x5,%r11
 1f79060:	or     %ecx,%esi
 1f79062:	mov    0x28(%r12),%rcx
 1f79067:	mov    %edx,(%rcx,%r11,1)
 1f7906b:	mov    %ebp,0x4(%rcx,%r11,1)
 1f79070:	mov    %r8d,0x8(%rcx,%r11,1)
 1f79075:	mov    %ebx,0xc(%rcx,%r11,1)
 1f7907a:	mov    %r10,0x10(%rcx,%r11,1)
 1f7907f:	mov    %sil,0x18(%rcx,%r11,1)
 1f79084:	movb   $0x1,0x19(%rcx,%r11,1)
 1f7908a:	mov    %r9w,0x1a(%rcx,%r11,1)
 1f79090:	movl   $0x0,0x1c(%rcx,%r11,1)
 1f79099:	mov    %rdi,%r11
 1f7909c:	jmp    1f790f5 <node_facts_front_expression+0x575>
 1f7909e:	cmp    $0x17,%ecx
 1f790a1:	je     1f794cf <node_facts_front_expression+0x94f>
 1f790a7:	cmp    $0x22,%ecx
 1f790aa:	je     1f7927a <node_facts_front_expression+0x6fa>
 1f790b0:	cmp    $0x24,%ecx
 1f790b3:	jne    1f794dd <node_facts_front_expression+0x95d>
 1f790b9:	mov    0x2f8(%rdi),%rax
 1f790c0:	movq   $0x0,0x10(%rsp)
 1f790c9:	mov    (%rax,%r11,4),%eax
 1f790cd:	jmp    1f794f0 <node_facts_front_expression+0x970>
 1f790d2:	mov    $0xff,%r15b
 1f790d5:	movb   $0x1,0xb(%rsp)
 1f790da:	movq   $0x0,0x10(%rsp)
 1f790e3:	xor    %eax,%eax
 1f790e5:	jmp    1f79810 <node_facts_front_expression+0xc90>
 1f790ea:	xor    %eax,%eax
 1f790ec:	movq   $0x0,0x10(%rsp)
 1f790f5:	mov    0x24(%rsp),%ebp
 1f790f9:	mov    0x28(%rsp),%rdi
 1f790fe:	mov    0x38(%rsp),%r10
 1f79103:	jmp    1f7962c <node_facts_front_expression+0xaac>
 1f79108:	xor    %r8d,%r8d
 1f7910b:	xor    %ecx,%ecx
 1f7910d:	cmp    $0xb8,%edx
 1f79113:	mov    $0x2,%edi
 1f79118:	mov    %rsi,0x18(%rsp)
 1f7911d:	sete   %cl
 1f79120:	setne  %r8b
 1f79124:	testb  $0x1,0xa0(%rsp)
 1f7912c:	lea    0x1(%rcx,%rcx,1),%ecx
 1f79130:	cmovne %edi,%r8d
 1f79134:	cmovne %edi,%ecx
 1f79137:	xor    %edi,%edi
 1f79139:	xor    %esi,%esi
 1f7913b:	lea    0x20000(%r8),%r11d
 1f79142:	vpbroadcastd -0x19a822c(%rip),%zmm17        # 5d0f20 <.LCPI1287_0>
 1f7914c:	cmpb   $0x1,0xa2(%rsp)
 1f79154:	vpternlogd $0xff,%xmm16,%xmm16,%xmm16
 1f7915b:	mov    %rcx,0x10(%rsp)
 1f79160:	jne    1f791b3 <node_facts_front_expression+0x633>
 1f79162:	mov    0x28(%rsp),%rcx
 1f79167:	mov    %rdi,0x30(%rsp)
 1f7916c:	mov    %al,0xb(%rsp)
 1f79170:	mov    0x40(%rsp),%r15
 1f79175:	mov    0x8(%rcx),%rdi
 1f79179:	mov    0x58(%rdi),%rax
 1f7917d:	cmpb   $0x3,(%rax,%r15,1)
 1f79182:	jne    1f791a9 <node_facts_front_expression+0x629>
 1f79184:	mov    0x10(%rsp),%rcx
 1f79189:	mov    0x60(%rdi),%rax
 1f7918d:	mov    %ecx,%edi
 1f7918f:	xor    $0x1,%edi
 1f79192:	mov    %rbp,%rcx
 1f79195:	or     0x18(%rsp),%rcx
 1f7919a:	cmovne %r8d,%r11d
 1f7919e:	or     (%rax,%r15,4),%edi
 1f791a2:	cmovne %r8d,%r11d
 1f791a6:	mov    %r11d,%r8d
 1f791a9:	movzbl 0xb(%rsp),%eax
 1f791ae:	mov    0x30(%rsp),%rdi
 1f791b3:	test   %al,%al
 1f791b5:	je     1f7a042 <node_facts_front_expression+0x14c2>
 1f791bb:	or     %rdi,%rsi
 1f791be:	or     0x18(%rsp),%rsi
 1f791c3:	mov    %r10,%rax
 1f791c6:	mov    %edx,%ecx
 1f791c8:	movq   $0x0,0x30(%rsp)
 1f791d1:	mov    %ebx,0x18(%rsp)
 1f791d5:	setne  %r11b
 1f791d9:	or     %r9,%rax
 1f791dc:	sete   %sil
 1f791e0:	cmove  %rbp,%r10
 1f791e4:	test   %rbp,%rbp
 1f791e7:	sete   %al
 1f791ea:	shr    $0x3,%ecx
 1f791ed:	xor    %ebx,%ebx
 1f791ef:	mov    (%r12),%rdi
 1f791f3:	mov    $0xff,%ebp
 1f791f8:	cmp    0x28(%rdi),%ecx
 1f791fb:	jb     1f78fbc <node_facts_front_expression+0x43c>
 1f79201:	jmp    1f78fc5 <node_facts_front_expression+0x445>
 1f79206:	mov    0x43cb0(%r10,%r15,8),%rsi
 1f7920e:	mov    $0x1,%r9d
 1f79214:	test   %rsi,%rsi
 1f79217:	jne    1f79245 <node_facts_front_expression+0x6c5>
 1f79219:	mov    0x58(%rsp),%rax
 1f7921e:	mov    0x58(%rax),%rax
 1f79222:	cmpb   $0x3,(%rax,%r11,1)
 1f79227:	jne    1f79245 <node_facts_front_expression+0x6c5>
 1f79229:	mov    0x58(%rsp),%rax
 1f7922e:	xor    %r9d,%r9d
 1f79231:	mov    0x60(%rax),%rax
 1f79235:	cmpl   $0x0,(%rax,%r11,4)
 1f7923a:	sete   %r9b
 1f7923e:	shl    $0x11,%r9d
 1f79242:	inc    %r9d
 1f79245:	mov    0x74(%r12),%eax
 1f7924a:	mov    $0xff,%r15b
 1f7924d:	cmp    0x70(%r12),%eax
 1f79252:	setae  %dil
 1f79256:	inc    %eax
 1f79258:	sete   %r10b
 1f7925c:	or     %dil,%r10b
 1f7925f:	je     1f79792 <node_facts_front_expression+0xc12>
 1f79265:	xor    %eax,%eax
 1f79267:	movb   $0x1,0xb(%rsp)
 1f7926c:	movq   $0x0,0x10(%rsp)
 1f79275:	jmp    1f79802 <node_facts_front_expression+0xc82>
 1f7927a:	movzbl 0x1862c(%r10,%r15,1),%ecx
 1f79283:	mov    $0x4,%eax
 1f79288:	mov    %dl,0xb(%rsp)
 1f7928c:	cmp    $0xff,%ecx
 1f79292:	je     1f7a02d <node_facts_front_expression+0x14ad>
 1f79298:	lea    -0x1(%rcx),%edx
 1f7929b:	mov    %rcx,0x50(%rsp)
 1f792a0:	mov    0x9a8(%r12),%ecx
 1f792a8:	mov    %edx,%esi
 1f792aa:	add    %rcx,%rsi
 1f792ad:	mov    0x254(%r12),%ecx
 1f792b5:	cmp    %rcx,%rsi
 1f792b8:	ja     1f7a02d <node_facts_front_expression+0x14ad>
 1f792be:	mov    %r8b,0xa(%rsp)
 1f792c3:	mov    %rdx,0x10(%rsp)
 1f792c8:	test   %edx,%edx
 1f792ca:	je     1f794ab <node_facts_front_expression+0x92b>
 1f792d0:	mov    0x10(%rsp),%rcx
 1f792d5:	mov    0x50(%rsp),%rdx
 1f792da:	mov    $0x1,%r8d
 1f792e0:	mov    %ecx,%eax
 1f792e2:	and    $0x7,%eax
 1f792e5:	lea    -0x2(%rdx),%esi
 1f792e8:	cmp    $0x7,%sil
 1f792ec:	jb     1f79471 <node_facts_front_expression+0x8f1>
 1f792f2:	mov    0x10(%rsp),%rdx
 1f792f7:	mov    %r11,0x40(%rsp)
 1f792fc:	xor    %ecx,%ecx
 1f792fe:	mov    %edx,%edi
 1f79300:	and    $0xfffffff8,%edi
 1f79303:	neg    %edi
 1f79305:	data16 cs nopw 0x0(%rax,%rax,1)
 1f79310:	mov    0x9a8(%r12),%ebx
 1f79318:	mov    0x9a0(%r12),%r11
 1f79320:	lea    (%rdx,%rcx,1),%esi
 1f79323:	add    $0xfffffff8,%ecx
 1f79326:	lea    -0x1(%rbx,%rsi,1),%ebx
 1f7932a:	mov    %r8w,(%r11,%rbx,2)
 1f7932f:	mov    %r15d,%r11d
 1f79332:	sub    %r8d,%r11d
 1f79335:	mov    0x9a8(%r12),%ebx
 1f7933d:	add    0x651b8(%r10,%r11,4),%r8d
 1f79345:	mov    0x9a0(%r12),%r11
 1f7934d:	lea    -0x2(%rbx,%rsi,1),%ebx
 1f79351:	mov    %r8w,(%r11,%rbx,2)
 1f79356:	mov    %r15d,%r11d
 1f79359:	sub    %r8d,%r11d
 1f7935c:	mov    0x9a8(%r12),%ebx
 1f79364:	add    0x651b8(%r10,%r11,4),%r8d
 1f7936c:	mov    0x9a0(%r12),%r11
 1f79374:	lea    -0x3(%rbx,%rsi,1),%ebx
 1f79378:	mov    %r8w,(%r11,%rbx,2)
 1f7937d:	mov    %r15d,%r11d
 1f79380:	sub    %r8d,%r11d
 1f79383:	mov    0x9a8(%r12),%ebx
 1f7938b:	add    0x651b8(%r10,%r11,4),%r8d
 1f79393:	mov    0x9a0(%r12),%r11
 1f7939b:	lea    -0x4(%rbx,%rsi,1),%ebx
 1f7939f:	mov    %r8w,(%r11,%rbx,2)
 1f793a4:	mov    %r15d,%r11d
 1f793a7:	sub    %r8d,%r11d
 1f793aa:	mov    0x9a8(%r12),%ebx
 1f793b2:	add    0x651b8(%r10,%r11,4),%r8d
 1f793ba:	mov    0x9a0(%r12),%r11
 1f793c2:	lea    -0x5(%rbx,%rsi,1),%ebx
 1f793c6:	mov    %r8w,(%r11,%rbx,2)
 1f793cb:	mov    %r15d,%r11d
 1f793ce:	sub    %r8d,%r11d
 1f793d1:	mov    0x9a8(%r12),%ebx
 1f793d9:	add    0x651b8(%r10,%r11,4),%r8d
 1f793e1:	mov    0x9a0(%r12),%r11
 1f793e9:	lea    -0x6(%rbx,%rsi,1),%ebx
 1f793ed:	mov    %r8w,(%r11,%rbx,2)
 1f793f2:	mov    %r15d,%r11d
 1f793f5:	sub    %r8d,%r11d
 1f793f8:	mov    0x9a8(%r12),%ebx
 1f79400:	add    0x651b8(%r10,%r11,4),%r8d
 1f79408:	mov    0x9a0(%r12),%r11
 1f79410:	lea    -0x7(%rbx,%rsi,1),%ebx
 1f79414:	mov    %r8w,(%r11,%rbx,2)
 1f79419:	mov    %r15d,%r11d
 1f7941c:	sub    %r8d,%r11d
 1f7941f:	mov    0x9a8(%r12),%ebx
 1f79427:	add    0x651b8(%r10,%r11,4),%r8d
 1f7942f:	mov    0x9a0(%r12),%r11
 1f79437:	lea    -0x8(%rbx,%rsi,1),%esi
 1f7943b:	mov    %r8w,(%r11,%rsi,2)
 1f79440:	mov    %r15d,%esi
 1f79443:	sub    %r8d,%esi
 1f79446:	add    0x651b8(%r10,%rsi,4),%r8d
 1f7944e:	cmp    %ecx,%edi
 1f79450:	jne    1f79310 <node_facts_front_expression+0x790>
 1f79456:	mov    0x28(%rsp),%rdi
 1f7945b:	mov    0x40(%rsp),%r11
 1f79460:	mov    0xc(%rsp),%ebx
 1f79464:	test   %eax,%eax
 1f79466:	je     1f794ab <node_facts_front_expression+0x92b>
 1f79468:	mov    0x50(%rsp),%rdx
 1f7946d:	lea    -0x1(%rdx,%rcx,1),%ecx
 1f79471:	dec    %ecx
 1f79473:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f79480:	mov    0x9a8(%r12),%esi
 1f79488:	mov    0x9a0(%r12),%rdx
 1f79490:	add    %ecx,%esi
 1f79492:	dec    %ecx
 1f79494:	mov    %r8w,(%rdx,%rsi,2)
 1f79499:	mov    %r15d,%edx
 1f7949c:	sub    %r8d,%edx
 1f7949f:	add    0x651b8(%r10,%rdx,4),%r8d
 1f794a7:	dec    %eax
 1f794a9:	jne    1f79480 <node_facts_front_expression+0x900>
 1f794ab:	mov    0x9a8(%r12),%eax
 1f794b3:	movzbl 0xa(%rsp),%r8d
 1f794b9:	movzbl 0xb(%rsp),%edx
 1f794be:	mov    0x10(%rsp),%rcx
 1f794c3:	add    %eax,%ecx
 1f794c5:	mov    %ecx,0x9a8(%r12)
 1f794cd:	jmp    1f794f0 <node_facts_front_expression+0x970>
 1f794cf:	movq   $0x0,0x10(%rsp)
 1f794d8:	mov    %r9d,%eax
 1f794db:	jmp    1f794f0 <node_facts_front_expression+0x970>
 1f794dd:	xor    %eax,%eax
 1f794df:	movq   $0x0,0x10(%rsp)
 1f794e8:	nopl   0x0(%rax,%rax,1)
 1f794f0:	mov    %edx,%ecx
 1f794f2:	mov    $0xff,%r15b
 1f794f5:	mov    %dl,0xb(%rsp)
 1f794f9:	and    $0xfb,%cl
 1f794fc:	cmp    $0x3,%cl
 1f794ff:	jne    1f79636 <node_facts_front_expression+0xab6>
 1f79505:	mov    %r8b,0xa(%rsp)
 1f7950a:	movzbl 0x30(%rsp),%r8d
 1f79510:	xor    %r15d,%r15d
 1f79513:	test   %ebx,%ebx
 1f79515:	je     1f79550 <node_facts_front_expression+0x9d0>
 1f79517:	mov    0x968(%r12),%rcx
 1f7951f:	mov    %r13d,%edx
 1f79522:	sub    %ebx,%edx
 1f79524:	mov    0x10(%rsp),%rdi
 1f79529:	movzbl (%rcx,%rdx,1),%ecx
 1f7952d:	cmp    $0xff,%ecx
 1f79533:	je     1f79546 <node_facts_front_expression+0x9c6>
 1f79535:	mov    %ecx,%r15d
 1f79538:	and    $0xf,%ecx
 1f7953b:	shr    $0x4,%r15d
 1f7953f:	cmp    %ecx,%r8d
 1f79542:	adc    $0x0,%r15d
 1f79546:	mov    0x4c(%rsp),%esi
 1f7954a:	test   %esi,%esi
 1f7954c:	jne    1f7955d <node_facts_front_expression+0x9dd>
 1f7954e:	jmp    1f7958b <node_facts_front_expression+0xa0b>
 1f79550:	mov    0x10(%rsp),%rdi
 1f79555:	mov    0x4c(%rsp),%esi
 1f79559:	test   %esi,%esi
 1f7955b:	je     1f7958b <node_facts_front_expression+0xa0b>
 1f7955d:	mov    0x968(%r12),%rcx
 1f79565:	mov    %r13d,%edx
 1f79568:	sub    %esi,%edx
 1f7956a:	movzbl (%rcx,%rdx,1),%ecx
 1f7956e:	cmp    $0xff,%ecx
 1f79574:	je     1f7958b <node_facts_front_expression+0xa0b>
 1f79576:	mov    %ecx,%edx
 1f79578:	and    $0xf,%ecx
 1f7957b:	shr    $0x4,%edx
 1f7957e:	cmp    %ecx,%r8d
 1f79581:	adc    $0x0,%edx
 1f79584:	cmp    %r15d,%edx
 1f79587:	cmova  %edx,%r15d
 1f7958b:	mov    %r11,0x40(%rsp)
 1f79590:	test   %r9d,%r9d
 1f79593:	je     1f795c4 <node_facts_front_expression+0xa44>
 1f79595:	mov    0x968(%r12),%rcx
 1f7959d:	mov    %r13d,%edx
 1f795a0:	sub    %r9d,%edx
 1f795a3:	movzbl (%rcx,%rdx,1),%ecx
 1f795a7:	cmp    $0xff,%ecx
 1f795ad:	je     1f795c4 <node_facts_front_expression+0xa44>
 1f795af:	mov    %ecx,%edx
 1f795b1:	and    $0xf,%ecx
 1f795b4:	shr    $0x4,%edx
 1f795b7:	cmp    %ecx,%r8d
 1f795ba:	adc    $0x0,%edx
 1f795bd:	cmp    %r15d,%edx
 1f795c0:	cmova  %edx,%r15d
 1f795c4:	test   %di,%di
 1f795c7:	je     1f79607 <node_facts_front_expression+0xa87>
 1f795c9:	mov    0x968(%r12),%r9
 1f795d1:	mov    0x9a0(%r12),%r10
 1f795d9:	movzwl %di,%r11d
 1f795dd:	cmp    $0x10,%di
 1f795e1:	jae    1f7975d <node_facts_front_expression+0xbdd>
 1f795e7:	xor    %edi,%edi
 1f795e9:	mov    %r11,%rcx
 1f795ec:	and    $0x3,%rcx
 1f795f0:	mov    %eax,%edx
 1f795f2:	mov    %rdi,%rbx
 1f795f5:	jne    1f79648 <node_facts_front_expression+0xac8>
 1f795f7:	mov    0x24(%rsp),%ebp
 1f795fb:	sub    %r11d,%edi
 1f795fe:	cmp    $0xfffffffc,%edi
 1f79601:	jbe    1f79690 <node_facts_front_expression+0xb10>
 1f79607:	cmp    $0x4,%r15d
 1f7960b:	mov    $0x4,%ecx
 1f79610:	cmovae %ecx,%r15d
 1f79614:	shl    $0x4,%r15b
 1f79618:	or     0x30(%rsp),%r15b
 1f7961d:	mov    0x28(%rsp),%rdi
 1f79622:	mov    0x38(%rsp),%r10
 1f79627:	mov    0x40(%rsp),%r11
 1f7962c:	mov    0xc(%rsp),%ebx
 1f79630:	movzbl 0xa(%rsp),%r8d
 1f79636:	mov    0x18(%rsp),%r9d
 1f7963b:	jmp    1f7981d <node_facts_front_expression+0xc9d>
 1f79640:	inc    %rbx
 1f79643:	dec    %rcx
 1f79646:	je     1f795f7 <node_facts_front_expression+0xa77>
 1f79648:	lea    (%rdx,%rbx,1),%esi
 1f7964b:	mov    %r13d,%ebp
 1f7964e:	movzwl (%r10,%rsi,2),%esi
 1f79653:	sub    %esi,%ebp
 1f79655:	movzbl (%r9,%rbp,1),%esi
 1f7965a:	cmp    $0xff,%esi
 1f79660:	je     1f79640 <node_facts_front_expression+0xac0>
 1f79662:	mov    %esi,%ebp
 1f79664:	and    $0xf,%esi
 1f79667:	shr    $0x4,%ebp
 1f7966a:	cmp    %esi,%r8d
 1f7966d:	adc    $0x0,%ebp
 1f79670:	cmp    %r15d,%ebp
 1f79673:	cmova  %ebp,%r15d
 1f79677:	jmp    1f79640 <node_facts_front_expression+0xac0>
 1f79679:	nopl   0x0(%rax)
 1f79680:	mov    %ecx,%r15d
 1f79683:	add    $0x4,%rbx
 1f79687:	cmp    %rbx,%r11
 1f7968a:	je     1f79607 <node_facts_front_expression+0xa87>
 1f79690:	lea    (%rdx,%rbx,1),%ecx
 1f79693:	mov    %r13d,%esi
 1f79696:	movzwl (%r10,%rcx,2),%ecx
 1f7969b:	sub    %ecx,%esi
 1f7969d:	movzbl (%r9,%rsi,1),%ecx
 1f796a2:	cmp    $0xff,%ecx
 1f796a8:	je     1f796bf <node_facts_front_expression+0xb3f>
 1f796aa:	mov    %ecx,%esi
 1f796ac:	and    $0xf,%ecx
 1f796af:	shr    $0x4,%esi
 1f796b2:	cmp    %ecx,%r8d
 1f796b5:	adc    $0x0,%esi
 1f796b8:	cmp    %r15d,%esi
 1f796bb:	cmova  %esi,%r15d
 1f796bf:	lea    0x1(%rdx,%rbx,1),%ecx
 1f796c3:	mov    %r13d,%esi
 1f796c6:	movzwl (%r10,%rcx,2),%ecx
 1f796cb:	sub    %ecx,%esi
 1f796cd:	movzbl (%r9,%rsi,1),%ecx
 1f796d2:	cmp    $0xff,%ecx
 1f796d8:	je     1f796ef <node_facts_front_expression+0xb6f>
 1f796da:	mov    %ecx,%esi
 1f796dc:	and    $0xf,%ecx
 1f796df:	shr    $0x4,%esi
 1f796e2:	cmp    %ecx,%r8d
 1f796e5:	adc    $0x0,%esi
 1f796e8:	cmp    %r15d,%esi
 1f796eb:	cmova  %esi,%r15d
 1f796ef:	lea    0x2(%rdx,%rbx,1),%ecx
 1f796f3:	mov    %r13d,%esi
 1f796f6:	movzwl (%r10,%rcx,2),%ecx
 1f796fb:	sub    %ecx,%esi
 1f796fd:	movzbl (%r9,%rsi,1),%ecx
 1f79702:	cmp    $0xff,%ecx
 1f79708:	je     1f7971f <node_facts_front_expression+0xb9f>
 1f7970a:	mov    %ecx,%esi
 1f7970c:	and    $0xf,%ecx
 1f7970f:	shr    $0x4,%esi
 1f79712:	cmp    %ecx,%r8d
 1f79715:	adc    $0x0,%esi
 1f79718:	cmp    %r15d,%esi
 1f7971b:	cmova  %esi,%r15d
 1f7971f:	lea    0x3(%rdx,%rbx,1),%ecx
 1f79723:	mov    %r13d,%esi
 1f79726:	movzwl (%r10,%rcx,2),%ecx
 1f7972b:	sub    %ecx,%esi
 1f7972d:	movzbl (%r9,%rsi,1),%esi
 1f79732:	cmp    $0xff,%esi
 1f79738:	je     1f79683 <node_facts_front_expression+0xb03>
 1f7973e:	mov    %esi,%ecx
 1f79740:	and    $0xf,%esi
 1f79743:	shr    $0x4,%ecx
 1f79746:	cmp    %esi,%r8d
 1f79749:	adc    $0x0,%ecx
 1f7974c:	cmp    %r15d,%ecx
 1f7974f:	ja     1f79680 <node_facts_front_expression+0xb00>
 1f79755:	mov    %r15d,%ecx
 1f79758:	jmp    1f79680 <node_facts_front_expression+0xb00>
 1f7975d:	lea    -0x1(%r11),%rcx
 1f79761:	mov    %eax,%edx
 1f79763:	add    %ecx,%edx
 1f79765:	jb     1f795e7 <node_facts_front_expression+0xa67>
 1f7976b:	shr    $0x20,%rcx
 1f7976f:	jne    1f795e7 <node_facts_front_expression+0xa67>
 1f79775:	vpbroadcastd %r13d,%zmm0
 1f7977b:	vpbroadcastd %r8d,%zmm1
 1f79781:	cmp    $0x40,%di
 1f79785:	jae    1f798b3 <node_facts_front_expression+0xd33>
 1f7978b:	xor    %edi,%edi
 1f7978d:	jmp    1f79e3c <node_facts_front_expression+0x12bc>
 1f79792:	add    %rcx,%r8
 1f79795:	cmp    $0xfffe,%rsi
 1f7979c:	mov    $0xfffe,%ecx
 1f797a1:	mov    %r11,%rdi
 1f797a4:	mov    %eax,%r11d
 1f797a7:	movb   $0x6,0xb(%rsp)
 1f797ac:	movq   $0x0,0x10(%rsp)
 1f797b5:	mov    (%r8),%r8d
 1f797b8:	mov    %eax,0x74(%r12)
 1f797bd:	cmovb  %rsi,%rcx
 1f797c1:	shl    $0x5,%r11
 1f797c5:	mov    0x28(%r12),%r10
 1f797ca:	inc    %ecx
 1f797cc:	mov    %edx,(%r10,%r11,1)
 1f797d0:	mov    %r8d,0x4(%r10,%r11,1)
 1f797d5:	mov    %r9d,0x8(%r10,%r11,1)
 1f797da:	movl   $0x0,0xc(%r10,%r11,1)
 1f797e3:	mov    %rsi,0x10(%r10,%r11,1)
 1f797e8:	movw   $0x104,0x18(%r10,%r11,1)
 1f797f0:	mov    %cx,0x1a(%r10,%r11,1)
 1f797f6:	movl   $0x0,0x1c(%r10,%r11,1)
 1f797ff:	mov    %rdi,%r11
 1f79802:	mov    0x28(%rsp),%rdi
 1f79807:	mov    0x38(%rsp),%r10
 1f7980c:	nopl   0x0(%rax)
 1f79810:	mov    %ebx,%r9d
 1f79813:	mov    0xc(%rsp),%ebx
 1f79817:	movzbl 0xa(%rsp),%r8d
 1f7981d:	mov    0x968(%r12),%rdx
 1f79825:	mov    %r13d,%ecx
 1f79828:	movzbl 0xb(%rsp),%esi
 1f7982d:	mov    %r15b,(%rdx,%rcx,1)
 1f79831:	mov    0x958(%r12),%rdx
 1f79839:	mov    %r8b,(%rdx,%rcx,1)
 1f7983d:	mov    0x960(%r12),%rdx
 1f79845:	mov    %sil,(%rdx,%rcx,1)
 1f79849:	mov    0x4c(%rsp),%esi
 1f7984d:	mov    0x978(%r12),%rdx
 1f79855:	mov    %bx,(%rdx,%rcx,2)
 1f79859:	mov    0x980(%r12),%rdx
 1f79861:	mov    %si,(%rdx,%rcx,2)
 1f79865:	mov    0x988(%r12),%rdx
 1f7986d:	mov    %eax,(%rdx,%rcx,4)
 1f79870:	mov    0x10(%rsp),%rdx
 1f79875:	mov    0x990(%r12),%rax
 1f7987d:	mov    %dx,(%rax,%rcx,2)
 1f79881:	mov    0x8(%rdi),%rax
 1f79885:	mov    0x98(%rax),%rax
 1f7988c:	movzbl (%rax,%r11,1),%eax
 1f79891:	cmp    $0x49,%eax
 1f79894:	je     1f78c70 <node_facts_front_expression+0xf0>
 1f7989a:	cmp    $0x53,%eax
 1f7989d:	je     1f78c70 <node_facts_front_expression+0xf0>
 1f798a3:	mov    0x1690(%rdi),%rax
 1f798aa:	mov    (%rax,%r11,4),%r11d
 1f798ae:	jmp    1f78c70 <node_facts_front_expression+0xf0>
 1f798b3:	mov    %r11d,%edx
 1f798b6:	vpbroadcastd %r15d,%zmm2
 1f798bc:	and    $0xffffffc0,%edx
 1f798bf:	mov    %eax,%edi
 1f798c1:	mov    %rdx,0x50(%rsp)
 1f798c6:	vmovdqa64 %zmm2,%zmm3
 1f798cc:	vmovdqa64 %zmm2,%zmm4
 1f798d2:	vmovdqa64 %zmm2,%zmm5
 1f798d8:	nopl   0x0(%rax,%rax,1)
 1f798e0:	mov    %edi,%ecx
 1f798e2:	vpmovzxwd (%r10,%rcx,2),%zmm6
 1f798e9:	vpmovzxwd 0x40(%r10,%rcx,2),%zmm8
 1f798f1:	vpmovzxwd 0x20(%r10,%rcx,2),%zmm7
 1f798f9:	vpmovzxwd 0x60(%r10,%rcx,2),%zmm9
 1f79901:	add    $0x40,%edi
 1f79904:	add    $0xffffffffffffffc0,%rdx
 1f79908:	vpsubd %zmm6,%zmm0,%zmm6
 1f7990e:	vpsubd %zmm7,%zmm0,%zmm11
 1f79914:	vpsubd %zmm9,%zmm0,%zmm7
 1f7991a:	vpsubd %zmm8,%zmm0,%zmm8
 1f79920:	vpmovzxdq %ymm6,%zmm12
 1f79926:	vextracti64x4 $0x1,%zmm6,%ymm9
 1f7992d:	vextracti64x4 $0x1,%zmm11,%ymm6
 1f79934:	vpmovzxdq %ymm11,%zmm11
 1f7993a:	vpmovzxdq %ymm7,%zmm15
 1f79940:	vpmovzxdq %ymm9,%zmm10
 1f79946:	vpmovzxdq %ymm6,%zmm9
 1f7994c:	vextracti64x4 $0x1,%zmm8,%ymm6
 1f79953:	vpmovzxdq %ymm8,%zmm8
 1f79959:	vpmovzxdq %ymm6,%zmm6
 1f7995f:	vmovd  %xmm12,%ecx
 1f79963:	vpextrq $0x1,%xmm12,%rbx
 1f79969:	vextracti128 $0x1,%ymm12,%xmm13
 1f7996f:	movzbl (%r9,%rcx,1),%ecx
 1f79974:	vmovd  %xmm13,%esi
 1f79978:	vmovd  %ecx,%xmm14
 1f7997c:	vpinsrb $0x1,(%r9,%rbx,1),%xmm14,%xmm14
 1f79983:	vpextrq $0x1,%xmm13,%rcx
 1f79989:	vextracti32x4 $0x2,%zmm12,%xmm13
 1f79990:	vextracti32x4 $0x3,%zmm12,%xmm12
 1f79997:	vpinsrb $0x2,(%r9,%rsi,1),%xmm14,%xmm14
 1f7999e:	vpextrq $0x1,%xmm13,%rsi
 1f799a4:	vpinsrb $0x3,(%r9,%rcx,1),%xmm14,%xmm14
 1f799ab:	vmovd  %xmm13,%ecx
 1f799af:	vpinsrb $0x4,(%r9,%rcx,1),%xmm14,%xmm13
 1f799b6:	vpextrq $0x1,%xmm12,%rcx
 1f799bc:	vpinsrb $0x5,(%r9,%rsi,1),%xmm13,%xmm13
 1f799c3:	vmovd  %xmm12,%esi
 1f799c7:	vpinsrb $0x6,(%r9,%rsi,1),%xmm13,%xmm12
 1f799ce:	vmovd  %xmm10,%esi
 1f799d2:	vextracti128 $0x1,%ymm10,%xmm13
 1f799d8:	vpinsrb $0x7,(%r9,%rcx,1),%xmm12,%xmm12
 1f799df:	vpextrq $0x1,%xmm10,%rcx
 1f799e5:	vpinsrb $0x8,(%r9,%rsi,1),%xmm12,%xmm12
 1f799ec:	vmovd  %xmm13,%esi
 1f799f0:	vpinsrb $0x9,(%r9,%rcx,1),%xmm12,%xmm12
 1f799f7:	vpextrq $0x1,%xmm13,%rcx
 1f799fd:	vextracti128 $0x1,%ymm11,%xmm13
 1f79a03:	vpinsrb $0xa,(%r9,%rsi,1),%xmm12,%xmm12
 1f79a0a:	vmovd  %xmm11,%esi
 1f79a0e:	movzbl (%r9,%rsi,1),%esi
 1f79a13:	vpinsrb $0xb,(%r9,%rcx,1),%xmm12,%xmm12
 1f79a1a:	vpextrq $0x1,%xmm11,%rcx
 1f79a20:	vmovd  %esi,%xmm14
 1f79a24:	vpinsrb $0x1,(%r9,%rcx,1),%xmm14,%xmm14
 1f79a2b:	vmovd  %xmm13,%esi
 1f79a2f:	vpextrq $0x1,%xmm13,%rcx
 1f79a35:	vextracti32x4 $0x2,%zmm11,%xmm13
 1f79a3c:	vextracti32x4 $0x3,%zmm11,%xmm11
 1f79a43:	vpinsrb $0x2,(%r9,%rsi,1),%xmm14,%xmm14
 1f79a4a:	vmovd  %xmm13,%esi
 1f79a4e:	vpinsrb $0x3,(%r9,%rcx,1),%xmm14,%xmm14
 1f79a55:	vpextrq $0x1,%xmm13,%rcx
 1f79a5b:	vextracti32x4 $0x2,%zmm10,%xmm13
 1f79a62:	vextracti32x4 $0x3,%zmm10,%xmm10
 1f79a69:	vpinsrb $0x4,(%r9,%rsi,1),%xmm14,%xmm14
 1f79a70:	vmovd  %xmm13,%esi
 1f79a74:	vpinsrb $0xc,(%r9,%rsi,1),%xmm12,%xmm12
 1f79a7b:	vmovd  %xmm11,%esi
 1f79a7f:	vpinsrb $0x5,(%r9,%rcx,1),%xmm14,%xmm14
 1f79a86:	vpextrq $0x1,%xmm11,%rcx
 1f79a8c:	vpinsrb $0x6,(%r9,%rsi,1),%xmm14,%xmm11
 1f79a93:	vmovd  %xmm9,%esi
 1f79a97:	vpinsrb $0x7,(%r9,%rcx,1),%xmm11,%xmm11
 1f79a9e:	vpextrq $0x1,%xmm9,%rcx
 1f79aa4:	vpinsrb $0x8,(%r9,%rsi,1),%xmm11,%xmm11
 1f79aab:	vpextrq $0x1,%xmm13,%rsi
 1f79ab1:	vextracti128 $0x1,%ymm9,%xmm13
 1f79ab7:	vpinsrb $0xd,(%r9,%rsi,1),%xmm12,%xmm12
 1f79abe:	vpextrq $0x1,%xmm8,%rsi
 1f79ac4:	vpinsrb $0x9,(%r9,%rcx,1),%xmm11,%xmm11
 1f79acb:	vmovd  %xmm13,%ecx
 1f79acf:	vpinsrb $0xa,(%r9,%rcx,1),%xmm11,%xmm11
 1f79ad6:	vpextrq $0x1,%xmm13,%rcx
 1f79adc:	vextracti32x4 $0x2,%zmm9,%xmm13
 1f79ae3:	vextracti32x4 $0x3,%zmm9,%xmm9
 1f79aea:	vpinsrb $0xb,(%r9,%rcx,1),%xmm11,%xmm11
 1f79af1:	vmovd  %xmm13,%ecx
 1f79af5:	vpinsrb $0xc,(%r9,%rcx,1),%xmm11,%xmm11
 1f79afc:	vmovd  %xmm8,%ecx
 1f79b00:	movzbl (%r9,%rcx,1),%ecx
 1f79b05:	vmovd  %ecx,%xmm14
 1f79b09:	vpinsrb $0x1,(%r9,%rsi,1),%xmm14,%xmm14
 1f79b10:	vpextrq $0x1,%xmm13,%rcx
 1f79b16:	vextracti128 $0x1,%ymm8,%xmm13
 1f79b1c:	vmovd  %xmm13,%esi
 1f79b20:	vpinsrb $0xd,(%r9,%rcx,1),%xmm11,%xmm11
 1f79b27:	vpextrq $0x1,%xmm10,%rcx
 1f79b2d:	vpinsrb $0x2,(%r9,%rsi,1),%xmm14,%xmm14
 1f79b34:	vmovd  %xmm10,%esi
 1f79b38:	vextracti64x4 $0x1,%zmm7,%ymm10
 1f79b3f:	vpinsrb $0xe,(%r9,%rsi,1),%xmm12,%xmm7
 1f79b46:	vpextrq $0x1,%xmm13,%rsi
 1f79b4c:	vextracti32x4 $0x2,%zmm8,%xmm13
 1f79b53:	vextracti32x4 $0x3,%zmm8,%xmm8
 1f79b5a:	vpinsrb $0x3,(%r9,%rsi,1),%xmm14,%xmm12
 1f79b61:	vmovd  %xmm9,%esi
 1f79b65:	vpinsrb $0xe,(%r9,%rsi,1),%xmm11,%xmm11
 1f79b6c:	vmovd  %xmm13,%esi
 1f79b70:	vpinsrb $0xf,(%r9,%rcx,1),%xmm7,%xmm7
 1f79b77:	vmovd  %xmm8,%ecx
 1f79b7b:	vpinsrb $0x4,(%r9,%rsi,1),%xmm12,%xmm12
 1f79b82:	vpextrq $0x1,%xmm13,%rsi
 1f79b88:	vpinsrb $0x5,(%r9,%rsi,1),%xmm12,%xmm12
 1f79b8f:	vpextrq $0x1,%xmm8,%rsi
 1f79b95:	vpcmpneqb %xmm16,%xmm7,%k4
 1f79b9c:	vpmovzxbd %xmm7,%zmm7
 1f79ba2:	vpinsrb $0x6,(%r9,%rcx,1),%xmm12,%xmm8
 1f79ba9:	vmovd  %xmm6,%ecx
 1f79bad:	vpinsrb $0x7,(%r9,%rsi,1),%xmm8,%xmm8
 1f79bb4:	vpextrq $0x1,%xmm6,%rsi
 1f79bba:	vpinsrb $0x8,(%r9,%rcx,1),%xmm8,%xmm8
 1f79bc1:	vpextrq $0x1,%xmm9,%rcx
 1f79bc7:	vextracti128 $0x1,%ymm6,%xmm9
 1f79bcd:	vpinsrb $0x9,(%r9,%rsi,1),%xmm8,%xmm8
 1f79bd4:	vmovd  %xmm9,%esi
 1f79bd8:	vpinsrb $0xa,(%r9,%rsi,1),%xmm8,%xmm8
 1f79bdf:	vpextrq $0x1,%xmm9,%rsi
 1f79be5:	vextracti32x4 $0x2,%zmm6,%xmm9
 1f79bec:	vextracti32x4 $0x3,%zmm6,%xmm6
 1f79bf3:	vpinsrb $0xb,(%r9,%rsi,1),%xmm8,%xmm8
 1f79bfa:	vmovd  %xmm9,%esi
 1f79bfe:	vpinsrb $0xc,(%r9,%rsi,1),%xmm8,%xmm8
 1f79c05:	vpextrq $0x1,%xmm9,%rsi
 1f79c0b:	vpinsrb $0xf,(%r9,%rcx,1),%xmm11,%xmm9
 1f79c12:	vpextrq $0x1,%xmm15,%rcx
 1f79c18:	vextracti128 $0x1,%ymm15,%xmm11
 1f79c1e:	vpinsrb $0xd,(%r9,%rsi,1),%xmm8,%xmm8
 1f79c25:	vmovd  %xmm6,%esi
 1f79c29:	vpinsrb $0xe,(%r9,%rsi,1),%xmm8,%xmm8
 1f79c30:	vmovd  %xmm15,%esi
 1f79c34:	vpcmpneqb %xmm16,%xmm9,%k3
 1f79c3b:	vpmovzxbd %xmm9,%zmm9
 1f79c41:	movzbl (%r9,%rsi,1),%esi
 1f79c46:	vmovd  %esi,%xmm12
 1f79c4a:	vpinsrb $0x1,(%r9,%rcx,1),%xmm12,%xmm12
 1f79c51:	vmovd  %xmm11,%esi
 1f79c55:	vpextrq $0x1,%xmm11,%rcx
 1f79c5b:	vextracti32x4 $0x2,%zmm15,%xmm11
 1f79c62:	vpinsrb $0x2,(%r9,%rsi,1),%xmm12,%xmm12
 1f79c69:	vmovd  %xmm11,%esi
 1f79c6d:	vpinsrb $0x3,(%r9,%rcx,1),%xmm12,%xmm12
 1f79c74:	vpextrq $0x1,%xmm11,%rcx
 1f79c7a:	vpinsrb $0x4,(%r9,%rsi,1),%xmm12,%xmm11
 1f79c81:	vpextrq $0x1,%xmm6,%rsi
 1f79c87:	vpmovzxdq %ymm10,%zmm6
 1f79c8d:	vextracti32x4 $0x3,%zmm15,%xmm10
 1f79c94:	vpinsrb $0xf,(%r9,%rsi,1),%xmm8,%xmm8
 1f79c9b:	vmovd  %xmm10,%esi
 1f79c9f:	vpinsrb $0x5,(%r9,%rcx,1),%xmm11,%xmm11
 1f79ca6:	vpextrq $0x1,%xmm10,%rcx
 1f79cac:	vpinsrb $0x6,(%r9,%rsi,1),%xmm11,%xmm10
 1f79cb3:	vmovd  %xmm6,%esi
 1f79cb7:	vextracti128 $0x1,%ymm6,%xmm11
 1f79cbd:	vpcmpneqb %xmm16,%xmm8,%k2
 1f79cc4:	vpmovzxbd %xmm8,%zmm8
 1f79cca:	vpinsrb $0x7,(%r9,%rcx,1),%xmm10,%xmm10
 1f79cd1:	vpextrq $0x1,%xmm6,%rcx
 1f79cd7:	vpsrld $0x4,%zmm8,%zmm12
 1f79cde:	vpandd %zmm17,%zmm8,%zmm8
 1f79ce4:	vpcmpgtd %zmm1,%zmm8,%k6
 1f79cea:	vpmovm2d %k6,%zmm8
 1f79cf0:	vpsubd %zmm8,%zmm12,%zmm8
 1f79cf6:	vpinsrb $0x8,(%r9,%rsi,1),%xmm10,%xmm10
 1f79cfd:	vmovd  %xmm11,%esi
 1f79d01:	vpmaxud %zmm4,%zmm8,%zmm4{%k2}
 1f79d07:	vpinsrb $0x9,(%r9,%rcx,1),%xmm10,%xmm10
 1f79d0e:	vpextrq $0x1,%xmm11,%rcx
 1f79d14:	vextracti32x4 $0x2,%zmm6,%xmm11
 1f79d1b:	vextracti32x4 $0x3,%zmm6,%xmm6
 1f79d22:	vpinsrb $0xa,(%r9,%rsi,1),%xmm10,%xmm10
 1f79d29:	vmovd  %xmm11,%esi
 1f79d2d:	vpinsrb $0xb,(%r9,%rcx,1),%xmm10,%xmm10
 1f79d34:	vpextrq $0x1,%xmm11,%rcx
 1f79d3a:	vpsrld $0x4,%zmm9,%zmm11
 1f79d41:	vpandd %zmm17,%zmm9,%zmm9
 1f79d47:	vpcmpgtd %zmm1,%zmm9,%k5
 1f79d4d:	vpinsrb $0xc,(%r9,%rsi,1),%xmm10,%xmm10
 1f79d54:	vmovd  %xmm6,%esi
 1f79d58:	vpinsrb $0xd,(%r9,%rcx,1),%xmm10,%xmm10
 1f79d5f:	vpextrq $0x1,%xmm6,%rcx
 1f79d65:	vpinsrb $0xe,(%r9,%rsi,1),%xmm10,%xmm6
 1f79d6c:	vpsrld $0x4,%zmm7,%zmm10
 1f79d73:	vpandd %zmm17,%zmm7,%zmm7
 1f79d79:	vpcmpgtd %zmm1,%zmm7,%k0
 1f79d7f:	vpmovm2d %k5,%zmm7
 1f79d85:	vpsubd %zmm7,%zmm11,%zmm7
 1f79d8b:	vpmaxud %zmm3,%zmm7,%zmm3{%k3}
 1f79d91:	vpinsrb $0xf,(%r9,%rcx,1),%xmm6,%xmm6
 1f79d98:	vpcmpneqb %xmm16,%xmm6,%k1
 1f79d9f:	vpmovzxbd %xmm6,%zmm6
 1f79da5:	vpsrld $0x4,%zmm6,%zmm13
 1f79dac:	vpandd %zmm17,%zmm6,%zmm6
 1f79db2:	vpcmpgtd %zmm1,%zmm6,%k7
 1f79db8:	vpmovm2d %k0,%zmm6
 1f79dbe:	vpsubd %zmm6,%zmm10,%zmm6
 1f79dc4:	vpmovm2d %k7,%zmm9
 1f79dca:	vpsubd %zmm9,%zmm13,%zmm9
 1f79dd0:	vpmaxud %zmm2,%zmm6,%zmm2{%k4}
 1f79dd6:	vpmaxud %zmm5,%zmm9,%zmm5{%k1}
 1f79ddc:	jne    1f798e0 <node_facts_front_expression+0xd60>
 1f79de2:	vpmaxud %zmm3,%zmm2,%zmm2
 1f79de8:	vpmaxud %zmm5,%zmm4,%zmm3
 1f79dee:	mov    0x50(%rsp),%rdi
 1f79df3:	vpmaxud %zmm3,%zmm2,%zmm2
 1f79df9:	vextracti64x4 $0x1,%zmm2,%ymm3
 1f79e00:	vpmaxud %ymm3,%ymm2,%ymm2
 1f79e05:	vextracti128 $0x1,%ymm2,%xmm3
 1f79e0b:	vpmaxud %xmm3,%xmm2,%xmm2
 1f79e10:	vpshufd $0xee,%xmm2,%xmm3
 1f79e15:	vpmaxud %xmm3,%xmm2,%xmm2
 1f79e1a:	vpshufd $0x55,%xmm2,%xmm3
 1f79e1f:	vpmaxud %xmm3,%xmm2,%xmm2
 1f79e24:	vmovd  %xmm2,%r15d
 1f79e29:	cmp    %r11d,%edi
 1f79e2c:	je     1f79607 <node_facts_front_expression+0xa87>
 1f79e32:	test   $0x30,%r11b
 1f79e36:	je     1f795e9 <node_facts_front_expression+0xa69>
 1f79e3c:	mov    %r11d,%esi
 1f79e3f:	and    $0xfffffff0,%esi
 1f79e42:	mov    %rdi,%rcx
 1f79e45:	mov    %rdi,%rdx
 1f79e48:	vpbroadcastd %r15d,%zmm2
 1f79e4e:	add    %eax,%ecx
 1f79e50:	sub    %rsi,%rdx
 1f79e53:	mov    %rsi,%rbx
 1f79e56:	cs nopw 0x0(%rax,%rax,1)
 1f79e60:	mov    %ecx,%esi
 1f79e62:	vpmovzxwd (%r10,%rsi,2),%zmm3
 1f79e69:	add    $0x10,%ecx
 1f79e6c:	add    $0x10,%rdx
 1f79e70:	vpsubd %zmm3,%zmm0,%zmm3
 1f79e76:	vextracti64x4 $0x1,%zmm3,%ymm4
 1f79e7d:	vpmovzxdq %ymm3,%zmm3
 1f79e83:	vpmovzxdq %ymm4,%zmm4
 1f79e89:	vmovd  %xmm3,%edi
 1f79e8d:	vpextrq $0x1,%xmm3,%rsi
 1f79e93:	vextracti128 $0x1,%ymm3,%xmm5
 1f79e99:	movzbl (%r9,%rdi,1),%edi
 1f79e9e:	vmovd  %edi,%xmm6
 1f79ea2:	vpinsrb $0x1,(%r9,%rsi,1),%xmm6,%xmm6
 1f79ea9:	vmovd  %xmm5,%edi
 1f79ead:	vpextrq $0x1,%xmm5,%rsi
 1f79eb3:	vextracti32x4 $0x2,%zmm3,%xmm5
 1f79eba:	vextracti32x4 $0x3,%zmm3,%xmm3
 1f79ec1:	vpinsrb $0x2,(%r9,%rdi,1),%xmm6,%xmm6
 1f79ec8:	vmovd  %xmm5,%edi
 1f79ecc:	vpinsrb $0x3,(%r9,%rsi,1),%xmm6,%xmm6
 1f79ed3:	vpextrq $0x1,%xmm5,%rsi
 1f79ed9:	vpinsrb $0x4,(%r9,%rdi,1),%xmm6,%xmm5
 1f79ee0:	vmovd  %xmm3,%edi
 1f79ee4:	vpinsrb $0x5,(%r9,%rsi,1),%xmm5,%xmm5
 1f79eeb:	vpextrq $0x1,%xmm3,%rsi
 1f79ef1:	vpinsrb $0x6,(%r9,%rdi,1),%xmm5,%xmm3
 1f79ef8:	vmovd  %xmm4,%edi
 1f79efc:	vextracti128 $0x1,%ymm4,%xmm5
 1f79f02:	vpinsrb $0x7,(%r9,%rsi,1),%xmm3,%xmm3
 1f79f09:	vpextrq $0x1,%xmm4,%rsi
 1f79f0f:	vpinsrb $0x8,(%r9,%rdi,1),%xmm3,%xmm3
 1f79f16:	vmovd  %xmm5,%edi
 1f79f1a:	vpinsrb $0x9,(%r9,%rsi,1),%xmm3,%xmm3
 1f79f21:	vpextrq $0x1,%xmm5,%rsi
 1f79f27:	vextracti32x4 $0x2,%zmm4,%xmm5
 1f79f2e:	vextracti32x4 $0x3,%zmm4,%xmm4
 1f79f35:	vpinsrb $0xa,(%r9,%rdi,1),%xmm3,%xmm3
 1f79f3c:	vmovd  %xmm5,%edi
 1f79f40:	vpinsrb $0xb,(%r9,%rsi,1),%xmm3,%xmm3
 1f79f47:	vpextrq $0x1,%xmm5,%rsi
 1f79f4d:	vpinsrb $0xc,(%r9,%rdi,1),%xmm3,%xmm3
 1f79f54:	vmovd  %xmm4,%edi
 1f79f58:	vpinsrb $0xd,(%r9,%rsi,1),%xmm3,%xmm3
 1f79f5f:	vpextrq $0x1,%xmm4,%rsi
 1f79f65:	vpinsrb $0xe,(%r9,%rdi,1),%xmm3,%xmm3
 1f79f6c:	vpinsrb $0xf,(%r9,%rsi,1),%xmm3,%xmm3
 1f79f73:	vpcmpneqb %xmm16,%xmm3,%k1
 1f79f7a:	vpmovzxbd %xmm3,%zmm3
 1f79f80:	vpandd %zmm17,%zmm3,%zmm4
 1f79f86:	vpsrld $0x4,%zmm3,%zmm3
 1f79f8d:	vpcmpgtd %zmm1,%zmm4,%k0
 1f79f93:	vpmovm2d %k0,%zmm4
 1f79f99:	vpsubd %zmm4,%zmm3,%zmm3
 1f79f9f:	vpmaxud %zmm2,%zmm3,%zmm2{%k1}
 1f79fa5:	jne    1f79e60 <node_facts_front_expression+0x12e0>
 1f79fab:	vextracti64x4 $0x1,%zmm2,%ymm0
 1f79fb2:	mov    %rbx,%rdi
 1f79fb5:	vpmaxud %ymm0,%ymm2,%ymm0
 1f79fba:	vextracti128 $0x1,%ymm0,%xmm1
 1f79fc0:	vpmaxud %xmm1,%xmm0,%xmm0
 1f79fc5:	vpshufd $0xee,%xmm0,%xmm1
 1f79fca:	vpmaxud %xmm1,%xmm0,%xmm0
 1f79fcf:	vpshufd $0x55,%xmm0,%xmm1
 1f79fd4:	vpmaxud %xmm1,%xmm0,%xmm0
 1f79fd9:	vmovd  %xmm0,%r15d
 1f79fde:	cmp    %r11d,%edi
 1f79fe1:	jne    1f795e9 <node_facts_front_expression+0xa69>
 1f79fe7:	jmp    1f79607 <node_facts_front_expression+0xa87>
 1f79fec:	mov    %rbp,%r10
 1f79fef:	xor    %r8d,%r8d
 1f79ff2:	xor    %edi,%edi
 1f79ff4:	xor    %r9d,%r9d
 1f79ff7:	xor    %ebp,%ebp
 1f79ff9:	movq   $0x0,0x18(%rsp)
 1f7a002:	jmp    1f79142 <node_facts_front_expression+0x5c2>
 1f7a007:	mov    %r9d,%edx
 1f7a00a:	sub    %eax,%edx
 1f7a00c:	inc    %edx
 1f7a00e:	cmp    0x10(%r10),%edx
 1f7a012:	setae  %dl
 1f7a015:	test   %eax,%eax
 1f7a017:	jne    1f78bdc <node_facts_front_expression+0x5c>
 1f7a01d:	mov    $0x1,%eax
 1f7a022:	jmp    1f7a02d <node_facts_front_expression+0x14ad>
 1f7a024:	mov    %esi,%eax
 1f7a026:	jmp    1f7a02d <node_facts_front_expression+0x14ad>
 1f7a028:	mov    $0x2,%eax
 1f7a02d:	add    $0xb8,%rsp
 1f7a034:	pop    %rbx
 1f7a035:	pop    %r12
 1f7a037:	pop    %r13
 1f7a039:	pop    %r14
 1f7a03b:	pop    %r15
 1f7a03d:	pop    %rbp
 1f7a03e:	vzeroupper
 1f7a041:	ret
 1f7a042:	mov    $0x3,%eax
 1f7a047:	jmp    1f7a02d <node_facts_front_expression+0x14ad>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
