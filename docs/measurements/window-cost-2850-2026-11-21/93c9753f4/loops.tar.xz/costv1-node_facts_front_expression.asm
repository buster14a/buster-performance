
results/costv1/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f78ab0 <node_facts_front_expression>:
 1f78ab0:	push   %rbp
 1f78ab1:	push   %r15
 1f78ab3:	push   %r14
 1f78ab5:	push   %r13
 1f78ab7:	push   %r12
 1f78ab9:	push   %rbx
 1f78aba:	sub    $0xb8,%rsp
 1f78ac1:	mov    %r8d,%ebp
 1f78ac4:	mov    %rdx,0x78(%rsp)
 1f78ac9:	mov    %rsi,%r10
 1f78acc:	mov    %rdi,%r12
 1f78acf:	xor    %eax,%eax
 1f78ad1:	cmp    %r8d,%r9d
 1f78ad4:	jae    1f78ae1 <node_facts_front_expression+0x31>
 1f78ad6:	mov    %r9d,%eax
 1f78ad9:	mov    0x651b8(%r10,%rax,4),%eax
 1f78ae1:	cmpb   $0x1,0x69238(%r10)
 1f78ae9:	jne    1f79f37 <node_facts_front_expression+0x1487>
 1f78aef:	cmp    %ebp,%r9d
 1f78af2:	mov    %ebp,%edx
 1f78af4:	cmovb  %r9d,%edx
 1f78af8:	cmpb   $0xfe,0x6a4d4(%r10,%rdx,1)
 1f78b01:	setne  %dl
 1f78b04:	test   %eax,%eax
 1f78b06:	je     1f79f4d <node_facts_front_expression+0x149d>
 1f78b0c:	mov    %ebp,%esi
 1f78b0e:	xor    %edi,%edi
 1f78b10:	cmpb   $0x23,0x2c(%r10,%rsi,1)
 1f78b16:	setne  %dil
 1f78b1a:	add    %eax,%edi
 1f78b1c:	cmp    %edi,%ecx
 1f78b1e:	sete   %sil
 1f78b22:	inc    %r9d
 1f78b25:	sub    %eax,%r9d
 1f78b28:	setae  %dil
 1f78b2c:	and    %dl,%dil
 1f78b2f:	and    %sil,%dil
 1f78b32:	mov    %edi,%edx
 1f78b34:	xor    $0x1,%dl
 1f78b37:	movzbl %dl,%esi
 1f78b3a:	xor    %edx,%edx
 1f78b3c:	test   %dil,%dil
 1f78b3f:	cmovne %r9d,%edx
 1f78b43:	test   %ecx,%ecx
 1f78b45:	sete   %dil
 1f78b49:	mov    %rdx,0x70(%rsp)
 1f78b4e:	or     %sil,%dil
 1f78b51:	jne    1f79f54 <node_facts_front_expression+0x14a4>
 1f78b57:	vpbroadcastd -0x19a7c09(%rip),%zmm17        # 5d0f58 <.LCPI1287_0>
 1f78b61:	mov    0x948(%r12),%rdi
 1f78b69:	mov    0x10(%r12),%rdx
 1f78b6e:	vpternlogd $0xff,%xmm16,%xmm16,%xmm16
 1f78b75:	mov    %eax,%eax
 1f78b77:	mov    %rax,0x60(%rsp)
 1f78b7c:	mov    %ecx,%eax
 1f78b7e:	xor    %r14d,%r14d
 1f78b81:	mov    %esi,0x18(%rsp)
 1f78b85:	mov    %rax,0x68(%rsp)
 1f78b8a:	mov    %ebp,0x24(%rsp)
 1f78b8e:	mov    %r10,0x38(%rsp)
 1f78b93:	mov    %rdx,0x58(%rsp)
 1f78b98:	mov    %rdi,0x28(%rsp)
 1f78b9d:	jmp    1f78bc5 <node_facts_front_expression+0x115>
 1f78b9f:	nop
 1f78ba0:	mov    0x998(%r12),%rax
 1f78ba8:	inc    %r11d
 1f78bab:	inc    %r14
 1f78bae:	mov    %r9d,0x18(%rsp)
 1f78bb3:	mov    %r11d,(%rax,%rcx,4)
 1f78bb7:	mov    %r9d,%eax
 1f78bba:	cmp    0x68(%rsp),%r14
 1f78bbf:	jae    1f79f5d <node_facts_front_expression+0x14ad>
 1f78bc5:	mov    0x70(%rsp),%rax
 1f78bca:	mov    $0x1,%r9d
 1f78bd0:	cmp    0x60(%rsp),%r14
 1f78bd5:	lea    (%rax,%r14,1),%r15d
 1f78bd9:	cmove  %ebp,%r15d
 1f78bdd:	je     1f78be8 <node_facts_front_expression+0x138>
 1f78bdf:	movzbl 0x1442c(%r10,%r15,1),%r9d
 1f78be8:	mov    0x78(%rsp),%rax
 1f78bed:	movzbl 0x154ac(%r10,%r15,1),%ecx
 1f78bf6:	movzbl 0x2c(%r10,%r15,1),%ebx
 1f78bfc:	mov    0x422c(%r10,%r15,4),%r11d
 1f78c04:	mov    %r9d,0xc(%rsp)
 1f78c09:	lea    (%rax,%r14,1),%r13d
 1f78c0d:	movzbl %cl,%eax
 1f78c10:	cmp    $0xff,%rcx
 1f78c17:	mov    %eax,0x4c(%rsp)
 1f78c1b:	movzbl 0x1652c(%r10,%r15,1),%eax
 1f78c24:	setne  %dl
 1f78c27:	cmp    $0xff,%rax
 1f78c2d:	setne  %sil
 1f78c31:	cmp    $0xff,%r9d
 1f78c38:	setne  %r8b
 1f78c3c:	and    %dl,%r8b
 1f78c3f:	mov    %r9d,%edx
 1f78c42:	cmp    %rdx,%r14
 1f78c45:	setae  %dl
 1f78c48:	and    %sil,%dl
 1f78c4b:	and    %r8b,%dl
 1f78c4e:	cmp    %rcx,%r14
 1f78c51:	mov    %ebx,%r8d
 1f78c54:	mov    $0x2,%ebx
 1f78c59:	setae  %sil
 1f78c5d:	cmp    %rax,%r14
 1f78c60:	setae  %cl
 1f78c63:	and    %sil,%cl
 1f78c66:	and    %dl,%cl
 1f78c68:	cmovne 0x18(%rsp),%ebx
 1f78c6d:	cmp    $0x1,%cl
 1f78c70:	jne    1f78d60 <node_facts_front_expression+0x2b0>
 1f78c76:	test   %r8b,%r8b
 1f78c79:	jne    1f78d60 <node_facts_front_expression+0x2b0>
 1f78c7f:	mov    0x33aac(%r10,%r15,4),%edx
 1f78c87:	movzbl 0x4bd30(%r10,%r15,1),%eax
 1f78c90:	mov    %r8b,0xa(%rsp)
 1f78c95:	mov    %edx,%ecx
 1f78c97:	shr    $0x3,%ecx
 1f78c9a:	cmp    $0x1,%eax
 1f78c9d:	je     1f78dff <node_facts_front_expression+0x34f>
 1f78ca3:	test   %eax,%eax
 1f78ca5:	jne    1f78e9b <node_facts_front_expression+0x3eb>
 1f78cab:	mov    0x43cb0(%r10,%r15,8),%rsi
 1f78cb3:	mov    0x30(%r12),%rcx
 1f78cb8:	mov    %esi,%eax
 1f78cba:	movslq (%rcx,%rax,4),%rax
 1f78cbe:	test   %rax,%rax
 1f78cc1:	jle    1f78cf8 <node_facts_front_expression+0x248>
 1f78cc3:	mov    0x8(%r12),%r9
 1f78cc8:	mov    0x28(%r12),%rcx
 1f78ccd:	mov    %rax,%rdx
 1f78cd0:	shl    $0x5,%rdx
 1f78cd4:	mov    0x438(%r9),%r8
 1f78cdb:	mov    (%r8,%r11,4),%r8d
 1f78cdf:	cmp    (%rcx,%rdx,1),%r8d
 1f78ce3:	jne    1f78cf8 <node_facts_front_expression+0x248>
 1f78ce5:	mov    0x298(%r9),%r8
 1f78cec:	test   %r8,%r8
 1f78cef:	je     1f78d3a <node_facts_front_expression+0x28a>
 1f78cf1:	cmpl   $0x0,0x8(%r8)
 1f78cf6:	je     1f78d3a <node_facts_front_expression+0x28a>
 1f78cf8:	mov    %r12,%rdi
 1f78cfb:	mov    %r11d,%edx
 1f78cfe:	mov    %r11,%r15
 1f78d01:	vzeroupper
 1f78d04:	call   1f52830 <node_facts_declaration>
 1f78d09:	vpbroadcastd -0x19a7dbb(%rip),%zmm17        # 5d0f58 <.LCPI1287_0>
 1f78d13:	mov    0x38(%rsp),%r10
 1f78d18:	mov    0x28(%rsp),%rdi
 1f78d1d:	vpternlogd $0xff,%xmm16,%xmm16,%xmm16
 1f78d24:	mov    %r15,%r11
 1f78d27:	test   %eax,%eax
 1f78d29:	je     1f79002 <node_facts_front_expression+0x552>
 1f78d2f:	mov    0x28(%r12),%rcx
 1f78d34:	mov    %eax,%edx
 1f78d36:	shl    $0x5,%rdx
 1f78d3a:	testb  $0x4,0x1c(%rcx,%rdx,1)
 1f78d3f:	jne    1f79002 <node_facts_front_expression+0x552>
 1f78d45:	mov    $0xff,%r15b
 1f78d48:	movb   $0x2,0xb(%rsp)
 1f78d4d:	movq   $0x0,0x10(%rsp)
 1f78d56:	jmp    1f79740 <node_facts_front_expression+0xc90>
 1f78d5b:	nopl   0x0(%rax,%rax,1)
 1f78d60:	test   %cl,%cl
 1f78d62:	je     1f79f58 <node_facts_front_expression+0x14a8>
 1f78d68:	movzbl %r8b,%ecx
 1f78d6c:	movzbl %al,%r9d
 1f78d70:	movzbl 0xae5(%r12,%rcx,1),%eax
 1f78d79:	movzbl 0xaa0(%r12,%rcx,1),%edx
 1f78d82:	mov    %al,0x30(%rsp)
 1f78d86:	cmp    $0x18,%r8b
 1f78d8a:	jne    1f78dd0 <node_facts_front_expression+0x320>
 1f78d8c:	mov    0xc(%rsp),%ebx
 1f78d90:	cmp    0x60(%rsp),%r14
 1f78d95:	je     1f78dab <node_facts_front_expression+0x2fb>
 1f78d97:	mov    0x1f0(%rdi),%rax
 1f78d9e:	mov    (%rax,%r11,4),%eax
 1f78da2:	cmp    $0x8,%eax
 1f78da5:	jne    1f7940f <node_facts_front_expression+0x95f>
 1f78dab:	movzbl 0x93d(%r12),%edx
 1f78db4:	mov    $0x8,%eax
 1f78db9:	movb   $0xd,0x30(%rsp)
 1f78dbe:	movq   $0x0,0x10(%rsp)
 1f78dc7:	add    $0x3,%dl
 1f78dca:	jmp    1f79420 <node_facts_front_expression+0x970>
 1f78dcf:	nop
 1f78dd0:	mov    0xc(%rsp),%ebx
 1f78dd4:	mov    %r8d,%eax
 1f78dd7:	and    $0xfe,%al
 1f78dd9:	cmp    $0x20,%al
 1f78ddb:	jne    1f78fce <node_facts_front_expression+0x51e>
 1f78de1:	mov    0x58(%rsp),%rax
 1f78de6:	lea    0x1(%r11),%ecx
 1f78dea:	movq   $0x0,0x10(%rsp)
 1f78df3:	mov    0x60(%rax),%rax
 1f78df7:	mov    (%rax,%rcx,4),%eax
 1f78dfa:	jmp    1f79420 <node_facts_front_expression+0x970>
 1f78dff:	cmp    0x60(%r12),%ecx
 1f78e04:	jae    1f78e1b <node_facts_front_expression+0x36b>
 1f78e06:	mov    0x20(%r12),%r8
 1f78e0b:	shl    $0x6,%rcx
 1f78e0f:	testb  $0x1,0x34(%r8,%rcx,1)
 1f78e15:	jne    1f79136 <node_facts_front_expression+0x686>
 1f78e1b:	lea    0x80(%rsp),%rdx
 1f78e23:	mov    %r11d,%esi
 1f78e26:	mov    %r11,0x40(%rsp)
 1f78e2b:	vzeroupper
 1f78e2e:	call   14f1600 <node_front_literal>
 1f78e33:	mov    0x80(%rsp),%edx
 1f78e3a:	mov    0x88(%rsp),%rbp
 1f78e42:	mov    0x90(%rsp),%r10
 1f78e4a:	movzwl 0x98(%rsp),%r9d
 1f78e53:	mov    0xa8(%rsp),%rsi
 1f78e5b:	testb  $0x1,0xa1(%rsp)
 1f78e63:	je     1f79038 <node_facts_front_expression+0x588>
 1f78e69:	mov    $0x4,%ecx
 1f78e6e:	mov    $0x20000,%r11d
 1f78e74:	cmp    $0x1b0,%edx
 1f78e7a:	je     1f79f1c <node_facts_front_expression+0x146c>
 1f78e80:	mov    %rbp,0x18(%rsp)
 1f78e85:	mov    %r9,%rdi
 1f78e88:	mov    %r10,%rsi
 1f78e8b:	xor    %r8d,%r8d
 1f78e8e:	xor    %r9d,%r9d
 1f78e91:	xor    %r10d,%r10d
 1f78e94:	xor    %ebp,%ebp
 1f78e96:	jmp    1f79072 <node_facts_front_expression+0x5c2>
 1f78e9b:	mov    0x43cb0(%r10,%r15,8),%ebx
 1f78ea3:	xor    %r8d,%r8d
 1f78ea6:	mov    $0x3,%esi
 1f78eab:	mov    %r11,0x40(%rsp)
 1f78eb0:	mov    $0x1,%al
 1f78eb2:	mov    %rsi,0x10(%rsp)
 1f78eb7:	mov    $0x1,%esi
 1f78ebc:	mov    %rsi,0x30(%rsp)
 1f78ec1:	mov    $0x1,%sil
 1f78ec4:	test   %ebx,%ebx
 1f78ec6:	setne  %r8b
 1f78eca:	xor    %r11d,%r11d
 1f78ecd:	xor    %r9d,%r9d
 1f78ed0:	xor    %r10d,%r10d
 1f78ed3:	shl    $0x17,%r8d
 1f78ed7:	or     $0x80,%r8d
 1f78ede:	mov    (%r12),%rdi
 1f78ee2:	mov    $0xff,%ebp
 1f78ee7:	cmp    0x28(%rdi),%ecx
 1f78eea:	jae    1f78ef5 <node_facts_front_expression+0x445>
 1f78eec:	mov    0x18(%rdi),%rdi
 1f78ef0:	mov    %ecx,%ecx
 1f78ef2:	mov    (%rdi,%rcx,4),%ebp
 1f78ef5:	cmp    $0xfffe,%r10
 1f78efc:	mov    $0xfffe,%ecx
 1f78f01:	mov    $0xff,%r15b
 1f78f04:	movb   $0x1,0xb(%rsp)
 1f78f09:	cmovb  %r10,%rcx
 1f78f0d:	inc    %ecx
 1f78f0f:	test   %sil,%sil
 1f78f12:	cmovne %ecx,%r9d
 1f78f16:	test   %r11b,%r11b
 1f78f19:	je     1f78f2f <node_facts_front_expression+0x47f>
 1f78f1b:	mov    0x24(%rsp),%ebp
 1f78f1f:	movq   $0x0,0x10(%rsp)
 1f78f28:	xor    %eax,%eax
 1f78f2a:	jmp    1f7954d <node_facts_front_expression+0xa9d>
 1f78f2f:	mov    0x10(%rsp),%rdi
 1f78f34:	mov    0x40(%rsp),%r11
 1f78f39:	cmp    $0x1,%edi
 1f78f3c:	setne  %cl
 1f78f3f:	and    %al,%cl
 1f78f41:	or     %sil,%cl
 1f78f44:	cmp    $0x1,%cl
 1f78f47:	jne    1f7901a <node_facts_front_expression+0x56a>
 1f78f4d:	mov    0x74(%r12),%eax
 1f78f52:	cmp    0x70(%r12),%eax
 1f78f57:	jae    1f7901a <node_facts_front_expression+0x56a>
 1f78f5d:	xor    $0x1,%sil
 1f78f61:	inc    %rax
 1f78f64:	movb   $0x6,0xb(%rsp)
 1f78f69:	movq   $0x0,0x10(%rsp)
 1f78f72:	movzbl %sil,%ecx
 1f78f76:	mov    0x30(%rsp),%rsi
 1f78f7b:	mov    %eax,0x74(%r12)
 1f78f80:	shl    $0x6,%ecx
 1f78f83:	lea    (%rsi,%rdi,4),%esi
 1f78f86:	mov    %r11,%rdi
 1f78f89:	mov    %rax,%r11
 1f78f8c:	shl    $0x5,%r11
 1f78f90:	or     %ecx,%esi
 1f78f92:	mov    0x28(%r12),%rcx
 1f78f97:	mov    %edx,(%rcx,%r11,1)
 1f78f9b:	mov    %ebp,0x4(%rcx,%r11,1)
 1f78fa0:	mov    %r8d,0x8(%rcx,%r11,1)
 1f78fa5:	mov    %ebx,0xc(%rcx,%r11,1)
 1f78faa:	mov    %r10,0x10(%rcx,%r11,1)
 1f78faf:	mov    %sil,0x18(%rcx,%r11,1)
 1f78fb4:	movb   $0x1,0x19(%rcx,%r11,1)
 1f78fba:	mov    %r9w,0x1a(%rcx,%r11,1)
 1f78fc0:	movl   $0x0,0x1c(%rcx,%r11,1)
 1f78fc9:	mov    %rdi,%r11
 1f78fcc:	jmp    1f79025 <node_facts_front_expression+0x575>
 1f78fce:	cmp    $0x17,%ecx
 1f78fd1:	je     1f793ff <node_facts_front_expression+0x94f>
 1f78fd7:	cmp    $0x22,%ecx
 1f78fda:	je     1f791aa <node_facts_front_expression+0x6fa>
 1f78fe0:	cmp    $0x24,%ecx
 1f78fe3:	jne    1f7940d <node_facts_front_expression+0x95d>
 1f78fe9:	mov    0x2f8(%rdi),%rax
 1f78ff0:	movq   $0x0,0x10(%rsp)
 1f78ff9:	mov    (%rax,%r11,4),%eax
 1f78ffd:	jmp    1f79420 <node_facts_front_expression+0x970>
 1f79002:	mov    $0xff,%r15b
 1f79005:	movb   $0x1,0xb(%rsp)
 1f7900a:	movq   $0x0,0x10(%rsp)
 1f79013:	xor    %eax,%eax
 1f79015:	jmp    1f79740 <node_facts_front_expression+0xc90>
 1f7901a:	xor    %eax,%eax
 1f7901c:	movq   $0x0,0x10(%rsp)
 1f79025:	mov    0x24(%rsp),%ebp
 1f79029:	mov    0x28(%rsp),%rdi
 1f7902e:	mov    0x38(%rsp),%r10
 1f79033:	jmp    1f7955c <node_facts_front_expression+0xaac>
 1f79038:	xor    %r8d,%r8d
 1f7903b:	xor    %ecx,%ecx
 1f7903d:	cmp    $0xb8,%edx
 1f79043:	mov    $0x2,%edi
 1f79048:	mov    %rsi,0x18(%rsp)
 1f7904d:	sete   %cl
 1f79050:	setne  %r8b
 1f79054:	testb  $0x1,0xa0(%rsp)
 1f7905c:	lea    0x1(%rcx,%rcx,1),%ecx
 1f79060:	cmovne %edi,%r8d
 1f79064:	cmovne %edi,%ecx
 1f79067:	xor    %edi,%edi
 1f79069:	xor    %esi,%esi
 1f7906b:	lea    0x20000(%r8),%r11d
 1f79072:	vpbroadcastd -0x19a8124(%rip),%zmm17        # 5d0f58 <.LCPI1287_0>
 1f7907c:	cmpb   $0x1,0xa2(%rsp)
 1f79084:	vpternlogd $0xff,%xmm16,%xmm16,%xmm16
 1f7908b:	mov    %rcx,0x10(%rsp)
 1f79090:	jne    1f790e3 <node_facts_front_expression+0x633>
 1f79092:	mov    0x28(%rsp),%rcx
 1f79097:	mov    %rdi,0x30(%rsp)
 1f7909c:	mov    %al,0xb(%rsp)
 1f790a0:	mov    0x40(%rsp),%r15
 1f790a5:	mov    0x8(%rcx),%rdi
 1f790a9:	mov    0x58(%rdi),%rax
 1f790ad:	cmpb   $0x3,(%rax,%r15,1)
 1f790b2:	jne    1f790d9 <node_facts_front_expression+0x629>
 1f790b4:	mov    0x10(%rsp),%rcx
 1f790b9:	mov    0x60(%rdi),%rax
 1f790bd:	mov    %ecx,%edi
 1f790bf:	xor    $0x1,%edi
 1f790c2:	mov    %rbp,%rcx
 1f790c5:	or     0x18(%rsp),%rcx
 1f790ca:	cmovne %r8d,%r11d
 1f790ce:	or     (%rax,%r15,4),%edi
 1f790d2:	cmovne %r8d,%r11d
 1f790d6:	mov    %r11d,%r8d
 1f790d9:	movzbl 0xb(%rsp),%eax
 1f790de:	mov    0x30(%rsp),%rdi
 1f790e3:	test   %al,%al
 1f790e5:	je     1f79f72 <node_facts_front_expression+0x14c2>
 1f790eb:	or     %rdi,%rsi
 1f790ee:	or     0x18(%rsp),%rsi
 1f790f3:	mov    %r10,%rax
 1f790f6:	mov    %edx,%ecx
 1f790f8:	movq   $0x0,0x30(%rsp)
 1f79101:	mov    %ebx,0x18(%rsp)
 1f79105:	setne  %r11b
 1f79109:	or     %r9,%rax
 1f7910c:	sete   %sil
 1f79110:	cmove  %rbp,%r10
 1f79114:	test   %rbp,%rbp
 1f79117:	sete   %al
 1f7911a:	shr    $0x3,%ecx
 1f7911d:	xor    %ebx,%ebx
 1f7911f:	mov    (%r12),%rdi
 1f79123:	mov    $0xff,%ebp
 1f79128:	cmp    0x28(%rdi),%ecx
 1f7912b:	jb     1f78eec <node_facts_front_expression+0x43c>
 1f79131:	jmp    1f78ef5 <node_facts_front_expression+0x445>
 1f79136:	mov    0x43cb0(%r10,%r15,8),%rsi
 1f7913e:	mov    $0x1,%r9d
 1f79144:	test   %rsi,%rsi
 1f79147:	jne    1f79175 <node_facts_front_expression+0x6c5>
 1f79149:	mov    0x58(%rsp),%rax
 1f7914e:	mov    0x58(%rax),%rax
 1f79152:	cmpb   $0x3,(%rax,%r11,1)
 1f79157:	jne    1f79175 <node_facts_front_expression+0x6c5>
 1f79159:	mov    0x58(%rsp),%rax
 1f7915e:	xor    %r9d,%r9d
 1f79161:	mov    0x60(%rax),%rax
 1f79165:	cmpl   $0x0,(%rax,%r11,4)
 1f7916a:	sete   %r9b
 1f7916e:	shl    $0x11,%r9d
 1f79172:	inc    %r9d
 1f79175:	mov    0x74(%r12),%eax
 1f7917a:	mov    $0xff,%r15b
 1f7917d:	cmp    0x70(%r12),%eax
 1f79182:	setae  %dil
 1f79186:	inc    %eax
 1f79188:	sete   %r10b
 1f7918c:	or     %dil,%r10b
 1f7918f:	je     1f796c2 <node_facts_front_expression+0xc12>
 1f79195:	xor    %eax,%eax
 1f79197:	movb   $0x1,0xb(%rsp)
 1f7919c:	movq   $0x0,0x10(%rsp)
 1f791a5:	jmp    1f79732 <node_facts_front_expression+0xc82>
 1f791aa:	movzbl 0x1862c(%r10,%r15,1),%ecx
 1f791b3:	mov    $0x4,%eax
 1f791b8:	mov    %dl,0xb(%rsp)
 1f791bc:	cmp    $0xff,%ecx
 1f791c2:	je     1f79f5d <node_facts_front_expression+0x14ad>
 1f791c8:	lea    -0x1(%rcx),%edx
 1f791cb:	mov    %rcx,0x50(%rsp)
 1f791d0:	mov    0x9a8(%r12),%ecx
 1f791d8:	mov    %edx,%esi
 1f791da:	add    %rcx,%rsi
 1f791dd:	mov    0x254(%r12),%ecx
 1f791e5:	cmp    %rcx,%rsi
 1f791e8:	ja     1f79f5d <node_facts_front_expression+0x14ad>
 1f791ee:	mov    %r8b,0xa(%rsp)
 1f791f3:	mov    %rdx,0x10(%rsp)
 1f791f8:	test   %edx,%edx
 1f791fa:	je     1f793db <node_facts_front_expression+0x92b>
 1f79200:	mov    0x10(%rsp),%rcx
 1f79205:	mov    0x50(%rsp),%rdx
 1f7920a:	mov    $0x1,%r8d
 1f79210:	mov    %ecx,%eax
 1f79212:	and    $0x7,%eax
 1f79215:	lea    -0x2(%rdx),%esi
 1f79218:	cmp    $0x7,%sil
 1f7921c:	jb     1f793a1 <node_facts_front_expression+0x8f1>
 1f79222:	mov    0x10(%rsp),%rdx
 1f79227:	mov    %r11,0x40(%rsp)
 1f7922c:	xor    %ecx,%ecx
 1f7922e:	mov    %edx,%edi
 1f79230:	and    $0xfffffff8,%edi
 1f79233:	neg    %edi
 1f79235:	data16 cs nopw 0x0(%rax,%rax,1)
 1f79240:	mov    0x9a8(%r12),%ebx
 1f79248:	mov    0x9a0(%r12),%r11
 1f79250:	lea    (%rdx,%rcx,1),%esi
 1f79253:	add    $0xfffffff8,%ecx
 1f79256:	lea    -0x1(%rbx,%rsi,1),%ebx
 1f7925a:	mov    %r8w,(%r11,%rbx,2)
 1f7925f:	mov    %r15d,%r11d
 1f79262:	sub    %r8d,%r11d
 1f79265:	mov    0x9a8(%r12),%ebx
 1f7926d:	add    0x651b8(%r10,%r11,4),%r8d
 1f79275:	mov    0x9a0(%r12),%r11
 1f7927d:	lea    -0x2(%rbx,%rsi,1),%ebx
 1f79281:	mov    %r8w,(%r11,%rbx,2)
 1f79286:	mov    %r15d,%r11d
 1f79289:	sub    %r8d,%r11d
 1f7928c:	mov    0x9a8(%r12),%ebx
 1f79294:	add    0x651b8(%r10,%r11,4),%r8d
 1f7929c:	mov    0x9a0(%r12),%r11
 1f792a4:	lea    -0x3(%rbx,%rsi,1),%ebx
 1f792a8:	mov    %r8w,(%r11,%rbx,2)
 1f792ad:	mov    %r15d,%r11d
 1f792b0:	sub    %r8d,%r11d
 1f792b3:	mov    0x9a8(%r12),%ebx
 1f792bb:	add    0x651b8(%r10,%r11,4),%r8d
 1f792c3:	mov    0x9a0(%r12),%r11
 1f792cb:	lea    -0x4(%rbx,%rsi,1),%ebx
 1f792cf:	mov    %r8w,(%r11,%rbx,2)
 1f792d4:	mov    %r15d,%r11d
 1f792d7:	sub    %r8d,%r11d
 1f792da:	mov    0x9a8(%r12),%ebx
 1f792e2:	add    0x651b8(%r10,%r11,4),%r8d
 1f792ea:	mov    0x9a0(%r12),%r11
 1f792f2:	lea    -0x5(%rbx,%rsi,1),%ebx
 1f792f6:	mov    %r8w,(%r11,%rbx,2)
 1f792fb:	mov    %r15d,%r11d
 1f792fe:	sub    %r8d,%r11d
 1f79301:	mov    0x9a8(%r12),%ebx
 1f79309:	add    0x651b8(%r10,%r11,4),%r8d
 1f79311:	mov    0x9a0(%r12),%r11
 1f79319:	lea    -0x6(%rbx,%rsi,1),%ebx
 1f7931d:	mov    %r8w,(%r11,%rbx,2)
 1f79322:	mov    %r15d,%r11d
 1f79325:	sub    %r8d,%r11d
 1f79328:	mov    0x9a8(%r12),%ebx
 1f79330:	add    0x651b8(%r10,%r11,4),%r8d
 1f79338:	mov    0x9a0(%r12),%r11
 1f79340:	lea    -0x7(%rbx,%rsi,1),%ebx
 1f79344:	mov    %r8w,(%r11,%rbx,2)
 1f79349:	mov    %r15d,%r11d
 1f7934c:	sub    %r8d,%r11d
 1f7934f:	mov    0x9a8(%r12),%ebx
 1f79357:	add    0x651b8(%r10,%r11,4),%r8d
 1f7935f:	mov    0x9a0(%r12),%r11
 1f79367:	lea    -0x8(%rbx,%rsi,1),%esi
 1f7936b:	mov    %r8w,(%r11,%rsi,2)
 1f79370:	mov    %r15d,%esi
 1f79373:	sub    %r8d,%esi
 1f79376:	add    0x651b8(%r10,%rsi,4),%r8d
 1f7937e:	cmp    %ecx,%edi
 1f79380:	jne    1f79240 <node_facts_front_expression+0x790>
 1f79386:	mov    0x28(%rsp),%rdi
 1f7938b:	mov    0x40(%rsp),%r11
 1f79390:	mov    0xc(%rsp),%ebx
 1f79394:	test   %eax,%eax
 1f79396:	je     1f793db <node_facts_front_expression+0x92b>
 1f79398:	mov    0x50(%rsp),%rdx
 1f7939d:	lea    -0x1(%rdx,%rcx,1),%ecx
 1f793a1:	dec    %ecx
 1f793a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f793b0:	mov    0x9a8(%r12),%esi
 1f793b8:	mov    0x9a0(%r12),%rdx
 1f793c0:	add    %ecx,%esi
 1f793c2:	dec    %ecx
 1f793c4:	mov    %r8w,(%rdx,%rsi,2)
 1f793c9:	mov    %r15d,%edx
 1f793cc:	sub    %r8d,%edx
 1f793cf:	add    0x651b8(%r10,%rdx,4),%r8d
 1f793d7:	dec    %eax
 1f793d9:	jne    1f793b0 <node_facts_front_expression+0x900>
 1f793db:	mov    0x9a8(%r12),%eax
 1f793e3:	movzbl 0xa(%rsp),%r8d
 1f793e9:	movzbl 0xb(%rsp),%edx
 1f793ee:	mov    0x10(%rsp),%rcx
 1f793f3:	add    %eax,%ecx
 1f793f5:	mov    %ecx,0x9a8(%r12)
 1f793fd:	jmp    1f79420 <node_facts_front_expression+0x970>
 1f793ff:	movq   $0x0,0x10(%rsp)
 1f79408:	mov    %r9d,%eax
 1f7940b:	jmp    1f79420 <node_facts_front_expression+0x970>
 1f7940d:	xor    %eax,%eax
 1f7940f:	movq   $0x0,0x10(%rsp)
 1f79418:	nopl   0x0(%rax,%rax,1)
 1f79420:	mov    %edx,%ecx
 1f79422:	mov    $0xff,%r15b
 1f79425:	mov    %dl,0xb(%rsp)
 1f79429:	and    $0xfb,%cl
 1f7942c:	cmp    $0x3,%cl
 1f7942f:	jne    1f79566 <node_facts_front_expression+0xab6>
 1f79435:	mov    %r8b,0xa(%rsp)
 1f7943a:	movzbl 0x30(%rsp),%r8d
 1f79440:	xor    %r15d,%r15d
 1f79443:	test   %ebx,%ebx
 1f79445:	je     1f79480 <node_facts_front_expression+0x9d0>
 1f79447:	mov    0x968(%r12),%rcx
 1f7944f:	mov    %r13d,%edx
 1f79452:	sub    %ebx,%edx
 1f79454:	mov    0x10(%rsp),%rdi
 1f79459:	movzbl (%rcx,%rdx,1),%ecx
 1f7945d:	cmp    $0xff,%ecx
 1f79463:	je     1f79476 <node_facts_front_expression+0x9c6>
 1f79465:	mov    %ecx,%r15d
 1f79468:	and    $0xf,%ecx
 1f7946b:	shr    $0x4,%r15d
 1f7946f:	cmp    %ecx,%r8d
 1f79472:	adc    $0x0,%r15d
 1f79476:	mov    0x4c(%rsp),%esi
 1f7947a:	test   %esi,%esi
 1f7947c:	jne    1f7948d <node_facts_front_expression+0x9dd>
 1f7947e:	jmp    1f794bb <node_facts_front_expression+0xa0b>
 1f79480:	mov    0x10(%rsp),%rdi
 1f79485:	mov    0x4c(%rsp),%esi
 1f79489:	test   %esi,%esi
 1f7948b:	je     1f794bb <node_facts_front_expression+0xa0b>
 1f7948d:	mov    0x968(%r12),%rcx
 1f79495:	mov    %r13d,%edx
 1f79498:	sub    %esi,%edx
 1f7949a:	movzbl (%rcx,%rdx,1),%ecx
 1f7949e:	cmp    $0xff,%ecx
 1f794a4:	je     1f794bb <node_facts_front_expression+0xa0b>
 1f794a6:	mov    %ecx,%edx
 1f794a8:	and    $0xf,%ecx
 1f794ab:	shr    $0x4,%edx
 1f794ae:	cmp    %ecx,%r8d
 1f794b1:	adc    $0x0,%edx
 1f794b4:	cmp    %r15d,%edx
 1f794b7:	cmova  %edx,%r15d
 1f794bb:	mov    %r11,0x40(%rsp)
 1f794c0:	test   %r9d,%r9d
 1f794c3:	je     1f794f4 <node_facts_front_expression+0xa44>
 1f794c5:	mov    0x968(%r12),%rcx
 1f794cd:	mov    %r13d,%edx
 1f794d0:	sub    %r9d,%edx
 1f794d3:	movzbl (%rcx,%rdx,1),%ecx
 1f794d7:	cmp    $0xff,%ecx
 1f794dd:	je     1f794f4 <node_facts_front_expression+0xa44>
 1f794df:	mov    %ecx,%edx
 1f794e1:	and    $0xf,%ecx
 1f794e4:	shr    $0x4,%edx
 1f794e7:	cmp    %ecx,%r8d
 1f794ea:	adc    $0x0,%edx
 1f794ed:	cmp    %r15d,%edx
 1f794f0:	cmova  %edx,%r15d
 1f794f4:	test   %di,%di
 1f794f7:	je     1f79537 <node_facts_front_expression+0xa87>
 1f794f9:	mov    0x968(%r12),%r9
 1f79501:	mov    0x9a0(%r12),%r10
 1f79509:	movzwl %di,%r11d
 1f7950d:	cmp    $0x10,%di
 1f79511:	jae    1f7968d <node_facts_front_expression+0xbdd>
 1f79517:	xor    %edi,%edi
 1f79519:	mov    %r11,%rcx
 1f7951c:	and    $0x3,%rcx
 1f79520:	mov    %eax,%edx
 1f79522:	mov    %rdi,%rbx
 1f79525:	jne    1f79578 <node_facts_front_expression+0xac8>
 1f79527:	mov    0x24(%rsp),%ebp
 1f7952b:	sub    %r11d,%edi
 1f7952e:	cmp    $0xfffffffc,%edi
 1f79531:	jbe    1f795c0 <node_facts_front_expression+0xb10>
 1f79537:	cmp    $0x4,%r15d
 1f7953b:	mov    $0x4,%ecx
 1f79540:	cmovae %ecx,%r15d
 1f79544:	shl    $0x4,%r15b
 1f79548:	or     0x30(%rsp),%r15b
 1f7954d:	mov    0x28(%rsp),%rdi
 1f79552:	mov    0x38(%rsp),%r10
 1f79557:	mov    0x40(%rsp),%r11
 1f7955c:	mov    0xc(%rsp),%ebx
 1f79560:	movzbl 0xa(%rsp),%r8d
 1f79566:	mov    0x18(%rsp),%r9d
 1f7956b:	jmp    1f7974d <node_facts_front_expression+0xc9d>
 1f79570:	inc    %rbx
 1f79573:	dec    %rcx
 1f79576:	je     1f79527 <node_facts_front_expression+0xa77>
 1f79578:	lea    (%rdx,%rbx,1),%esi
 1f7957b:	mov    %r13d,%ebp
 1f7957e:	movzwl (%r10,%rsi,2),%esi
 1f79583:	sub    %esi,%ebp
 1f79585:	movzbl (%r9,%rbp,1),%esi
 1f7958a:	cmp    $0xff,%esi
 1f79590:	je     1f79570 <node_facts_front_expression+0xac0>
 1f79592:	mov    %esi,%ebp
 1f79594:	and    $0xf,%esi
 1f79597:	shr    $0x4,%ebp
 1f7959a:	cmp    %esi,%r8d
 1f7959d:	adc    $0x0,%ebp
 1f795a0:	cmp    %r15d,%ebp
 1f795a3:	cmova  %ebp,%r15d
 1f795a7:	jmp    1f79570 <node_facts_front_expression+0xac0>
 1f795a9:	nopl   0x0(%rax)
 1f795b0:	mov    %ecx,%r15d
 1f795b3:	add    $0x4,%rbx
 1f795b7:	cmp    %rbx,%r11
 1f795ba:	je     1f79537 <node_facts_front_expression+0xa87>
 1f795c0:	lea    (%rdx,%rbx,1),%ecx
 1f795c3:	mov    %r13d,%esi
 1f795c6:	movzwl (%r10,%rcx,2),%ecx
 1f795cb:	sub    %ecx,%esi
 1f795cd:	movzbl (%r9,%rsi,1),%ecx
 1f795d2:	cmp    $0xff,%ecx
 1f795d8:	je     1f795ef <node_facts_front_expression+0xb3f>
 1f795da:	mov    %ecx,%esi
 1f795dc:	and    $0xf,%ecx
 1f795df:	shr    $0x4,%esi
 1f795e2:	cmp    %ecx,%r8d
 1f795e5:	adc    $0x0,%esi
 1f795e8:	cmp    %r15d,%esi
 1f795eb:	cmova  %esi,%r15d
 1f795ef:	lea    0x1(%rdx,%rbx,1),%ecx
 1f795f3:	mov    %r13d,%esi
 1f795f6:	movzwl (%r10,%rcx,2),%ecx
 1f795fb:	sub    %ecx,%esi
 1f795fd:	movzbl (%r9,%rsi,1),%ecx
 1f79602:	cmp    $0xff,%ecx
 1f79608:	je     1f7961f <node_facts_front_expression+0xb6f>
 1f7960a:	mov    %ecx,%esi
 1f7960c:	and    $0xf,%ecx
 1f7960f:	shr    $0x4,%esi
 1f79612:	cmp    %ecx,%r8d
 1f79615:	adc    $0x0,%esi
 1f79618:	cmp    %r15d,%esi
 1f7961b:	cmova  %esi,%r15d
 1f7961f:	lea    0x2(%rdx,%rbx,1),%ecx
 1f79623:	mov    %r13d,%esi
 1f79626:	movzwl (%r10,%rcx,2),%ecx
 1f7962b:	sub    %ecx,%esi
 1f7962d:	movzbl (%r9,%rsi,1),%ecx
 1f79632:	cmp    $0xff,%ecx
 1f79638:	je     1f7964f <node_facts_front_expression+0xb9f>
 1f7963a:	mov    %ecx,%esi
 1f7963c:	and    $0xf,%ecx
 1f7963f:	shr    $0x4,%esi
 1f79642:	cmp    %ecx,%r8d
 1f79645:	adc    $0x0,%esi
 1f79648:	cmp    %r15d,%esi
 1f7964b:	cmova  %esi,%r15d
 1f7964f:	lea    0x3(%rdx,%rbx,1),%ecx
 1f79653:	mov    %r13d,%esi
 1f79656:	movzwl (%r10,%rcx,2),%ecx
 1f7965b:	sub    %ecx,%esi
 1f7965d:	movzbl (%r9,%rsi,1),%esi
 1f79662:	cmp    $0xff,%esi
 1f79668:	je     1f795b3 <node_facts_front_expression+0xb03>
 1f7966e:	mov    %esi,%ecx
 1f79670:	and    $0xf,%esi
 1f79673:	shr    $0x4,%ecx
 1f79676:	cmp    %esi,%r8d
 1f79679:	adc    $0x0,%ecx
 1f7967c:	cmp    %r15d,%ecx
 1f7967f:	ja     1f795b0 <node_facts_front_expression+0xb00>
 1f79685:	mov    %r15d,%ecx
 1f79688:	jmp    1f795b0 <node_facts_front_expression+0xb00>
 1f7968d:	lea    -0x1(%r11),%rcx
 1f79691:	mov    %eax,%edx
 1f79693:	add    %ecx,%edx
 1f79695:	jb     1f79517 <node_facts_front_expression+0xa67>
 1f7969b:	shr    $0x20,%rcx
 1f7969f:	jne    1f79517 <node_facts_front_expression+0xa67>
 1f796a5:	vpbroadcastd %r13d,%zmm0
 1f796ab:	vpbroadcastd %r8d,%zmm1
 1f796b1:	cmp    $0x40,%di
 1f796b5:	jae    1f797e3 <node_facts_front_expression+0xd33>
 1f796bb:	xor    %edi,%edi
 1f796bd:	jmp    1f79d6c <node_facts_front_expression+0x12bc>
 1f796c2:	add    %rcx,%r8
 1f796c5:	cmp    $0xfffe,%rsi
 1f796cc:	mov    $0xfffe,%ecx
 1f796d1:	mov    %r11,%rdi
 1f796d4:	mov    %eax,%r11d
 1f796d7:	movb   $0x6,0xb(%rsp)
 1f796dc:	movq   $0x0,0x10(%rsp)
 1f796e5:	mov    (%r8),%r8d
 1f796e8:	mov    %eax,0x74(%r12)
 1f796ed:	cmovb  %rsi,%rcx
 1f796f1:	shl    $0x5,%r11
 1f796f5:	mov    0x28(%r12),%r10
 1f796fa:	inc    %ecx
 1f796fc:	mov    %edx,(%r10,%r11,1)
 1f79700:	mov    %r8d,0x4(%r10,%r11,1)
 1f79705:	mov    %r9d,0x8(%r10,%r11,1)
 1f7970a:	movl   $0x0,0xc(%r10,%r11,1)
 1f79713:	mov    %rsi,0x10(%r10,%r11,1)
 1f79718:	movw   $0x104,0x18(%r10,%r11,1)
 1f79720:	mov    %cx,0x1a(%r10,%r11,1)
 1f79726:	movl   $0x0,0x1c(%r10,%r11,1)
 1f7972f:	mov    %rdi,%r11
 1f79732:	mov    0x28(%rsp),%rdi
 1f79737:	mov    0x38(%rsp),%r10
 1f7973c:	nopl   0x0(%rax)
 1f79740:	mov    %ebx,%r9d
 1f79743:	mov    0xc(%rsp),%ebx
 1f79747:	movzbl 0xa(%rsp),%r8d
 1f7974d:	mov    0x968(%r12),%rdx
 1f79755:	mov    %r13d,%ecx
 1f79758:	movzbl 0xb(%rsp),%esi
 1f7975d:	mov    %r15b,(%rdx,%rcx,1)
 1f79761:	mov    0x958(%r12),%rdx
 1f79769:	mov    %r8b,(%rdx,%rcx,1)
 1f7976d:	mov    0x960(%r12),%rdx
 1f79775:	mov    %sil,(%rdx,%rcx,1)
 1f79779:	mov    0x4c(%rsp),%esi
 1f7977d:	mov    0x978(%r12),%rdx
 1f79785:	mov    %bx,(%rdx,%rcx,2)
 1f79789:	mov    0x980(%r12),%rdx
 1f79791:	mov    %si,(%rdx,%rcx,2)
 1f79795:	mov    0x988(%r12),%rdx
 1f7979d:	mov    %eax,(%rdx,%rcx,4)
 1f797a0:	mov    0x10(%rsp),%rdx
 1f797a5:	mov    0x990(%r12),%rax
 1f797ad:	mov    %dx,(%rax,%rcx,2)
 1f797b1:	mov    0x8(%rdi),%rax
 1f797b5:	mov    0x98(%rax),%rax
 1f797bc:	movzbl (%rax,%r11,1),%eax
 1f797c1:	cmp    $0x49,%eax
 1f797c4:	je     1f78ba0 <node_facts_front_expression+0xf0>
 1f797ca:	cmp    $0x53,%eax
 1f797cd:	je     1f78ba0 <node_facts_front_expression+0xf0>
 1f797d3:	mov    0x1690(%rdi),%rax
 1f797da:	mov    (%rax,%r11,4),%r11d
 1f797de:	jmp    1f78ba0 <node_facts_front_expression+0xf0>
 1f797e3:	mov    %r11d,%edx
 1f797e6:	vpbroadcastd %r15d,%zmm2
 1f797ec:	and    $0xffffffc0,%edx
 1f797ef:	mov    %eax,%edi
 1f797f1:	mov    %rdx,0x50(%rsp)
 1f797f6:	vmovdqa64 %zmm2,%zmm3
 1f797fc:	vmovdqa64 %zmm2,%zmm4
 1f79802:	vmovdqa64 %zmm2,%zmm5
 1f79808:	nopl   0x0(%rax,%rax,1)
 1f79810:	mov    %edi,%ecx
 1f79812:	vpmovzxwd (%r10,%rcx,2),%zmm6
 1f79819:	vpmovzxwd 0x40(%r10,%rcx,2),%zmm8
 1f79821:	vpmovzxwd 0x20(%r10,%rcx,2),%zmm7
 1f79829:	vpmovzxwd 0x60(%r10,%rcx,2),%zmm9
 1f79831:	add    $0x40,%edi
 1f79834:	add    $0xffffffffffffffc0,%rdx
 1f79838:	vpsubd %zmm6,%zmm0,%zmm6
 1f7983e:	vpsubd %zmm7,%zmm0,%zmm11
 1f79844:	vpsubd %zmm9,%zmm0,%zmm7
 1f7984a:	vpsubd %zmm8,%zmm0,%zmm8
 1f79850:	vpmovzxdq %ymm6,%zmm12
 1f79856:	vextracti64x4 $0x1,%zmm6,%ymm9
 1f7985d:	vextracti64x4 $0x1,%zmm11,%ymm6
 1f79864:	vpmovzxdq %ymm11,%zmm11
 1f7986a:	vpmovzxdq %ymm7,%zmm15
 1f79870:	vpmovzxdq %ymm9,%zmm10
 1f79876:	vpmovzxdq %ymm6,%zmm9
 1f7987c:	vextracti64x4 $0x1,%zmm8,%ymm6
 1f79883:	vpmovzxdq %ymm8,%zmm8
 1f79889:	vpmovzxdq %ymm6,%zmm6
 1f7988f:	vmovd  %xmm12,%ecx
 1f79893:	vpextrq $0x1,%xmm12,%rbx
 1f79899:	vextracti128 $0x1,%ymm12,%xmm13
 1f7989f:	movzbl (%r9,%rcx,1),%ecx
 1f798a4:	vmovd  %xmm13,%esi
 1f798a8:	vmovd  %ecx,%xmm14
 1f798ac:	vpinsrb $0x1,(%r9,%rbx,1),%xmm14,%xmm14
 1f798b3:	vpextrq $0x1,%xmm13,%rcx
 1f798b9:	vextracti32x4 $0x2,%zmm12,%xmm13
 1f798c0:	vextracti32x4 $0x3,%zmm12,%xmm12
 1f798c7:	vpinsrb $0x2,(%r9,%rsi,1),%xmm14,%xmm14
 1f798ce:	vpextrq $0x1,%xmm13,%rsi
 1f798d4:	vpinsrb $0x3,(%r9,%rcx,1),%xmm14,%xmm14
 1f798db:	vmovd  %xmm13,%ecx
 1f798df:	vpinsrb $0x4,(%r9,%rcx,1),%xmm14,%xmm13
 1f798e6:	vpextrq $0x1,%xmm12,%rcx
 1f798ec:	vpinsrb $0x5,(%r9,%rsi,1),%xmm13,%xmm13
 1f798f3:	vmovd  %xmm12,%esi
 1f798f7:	vpinsrb $0x6,(%r9,%rsi,1),%xmm13,%xmm12
 1f798fe:	vmovd  %xmm10,%esi
 1f79902:	vextracti128 $0x1,%ymm10,%xmm13
 1f79908:	vpinsrb $0x7,(%r9,%rcx,1),%xmm12,%xmm12
 1f7990f:	vpextrq $0x1,%xmm10,%rcx
 1f79915:	vpinsrb $0x8,(%r9,%rsi,1),%xmm12,%xmm12
 1f7991c:	vmovd  %xmm13,%esi
 1f79920:	vpinsrb $0x9,(%r9,%rcx,1),%xmm12,%xmm12
 1f79927:	vpextrq $0x1,%xmm13,%rcx
 1f7992d:	vextracti128 $0x1,%ymm11,%xmm13
 1f79933:	vpinsrb $0xa,(%r9,%rsi,1),%xmm12,%xmm12
 1f7993a:	vmovd  %xmm11,%esi
 1f7993e:	movzbl (%r9,%rsi,1),%esi
 1f79943:	vpinsrb $0xb,(%r9,%rcx,1),%xmm12,%xmm12
 1f7994a:	vpextrq $0x1,%xmm11,%rcx
 1f79950:	vmovd  %esi,%xmm14
 1f79954:	vpinsrb $0x1,(%r9,%rcx,1),%xmm14,%xmm14
 1f7995b:	vmovd  %xmm13,%esi
 1f7995f:	vpextrq $0x1,%xmm13,%rcx
 1f79965:	vextracti32x4 $0x2,%zmm11,%xmm13
 1f7996c:	vextracti32x4 $0x3,%zmm11,%xmm11
 1f79973:	vpinsrb $0x2,(%r9,%rsi,1),%xmm14,%xmm14
 1f7997a:	vmovd  %xmm13,%esi
 1f7997e:	vpinsrb $0x3,(%r9,%rcx,1),%xmm14,%xmm14
 1f79985:	vpextrq $0x1,%xmm13,%rcx
 1f7998b:	vextracti32x4 $0x2,%zmm10,%xmm13
 1f79992:	vextracti32x4 $0x3,%zmm10,%xmm10
 1f79999:	vpinsrb $0x4,(%r9,%rsi,1),%xmm14,%xmm14
 1f799a0:	vmovd  %xmm13,%esi
 1f799a4:	vpinsrb $0xc,(%r9,%rsi,1),%xmm12,%xmm12
 1f799ab:	vmovd  %xmm11,%esi
 1f799af:	vpinsrb $0x5,(%r9,%rcx,1),%xmm14,%xmm14
 1f799b6:	vpextrq $0x1,%xmm11,%rcx
 1f799bc:	vpinsrb $0x6,(%r9,%rsi,1),%xmm14,%xmm11
 1f799c3:	vmovd  %xmm9,%esi
 1f799c7:	vpinsrb $0x7,(%r9,%rcx,1),%xmm11,%xmm11
 1f799ce:	vpextrq $0x1,%xmm9,%rcx
 1f799d4:	vpinsrb $0x8,(%r9,%rsi,1),%xmm11,%xmm11
 1f799db:	vpextrq $0x1,%xmm13,%rsi
 1f799e1:	vextracti128 $0x1,%ymm9,%xmm13
 1f799e7:	vpinsrb $0xd,(%r9,%rsi,1),%xmm12,%xmm12
 1f799ee:	vpextrq $0x1,%xmm8,%rsi
 1f799f4:	vpinsrb $0x9,(%r9,%rcx,1),%xmm11,%xmm11
 1f799fb:	vmovd  %xmm13,%ecx
 1f799ff:	vpinsrb $0xa,(%r9,%rcx,1),%xmm11,%xmm11
 1f79a06:	vpextrq $0x1,%xmm13,%rcx
 1f79a0c:	vextracti32x4 $0x2,%zmm9,%xmm13
 1f79a13:	vextracti32x4 $0x3,%zmm9,%xmm9
 1f79a1a:	vpinsrb $0xb,(%r9,%rcx,1),%xmm11,%xmm11
 1f79a21:	vmovd  %xmm13,%ecx
 1f79a25:	vpinsrb $0xc,(%r9,%rcx,1),%xmm11,%xmm11
 1f79a2c:	vmovd  %xmm8,%ecx
 1f79a30:	movzbl (%r9,%rcx,1),%ecx
 1f79a35:	vmovd  %ecx,%xmm14
 1f79a39:	vpinsrb $0x1,(%r9,%rsi,1),%xmm14,%xmm14
 1f79a40:	vpextrq $0x1,%xmm13,%rcx
 1f79a46:	vextracti128 $0x1,%ymm8,%xmm13
 1f79a4c:	vmovd  %xmm13,%esi
 1f79a50:	vpinsrb $0xd,(%r9,%rcx,1),%xmm11,%xmm11
 1f79a57:	vpextrq $0x1,%xmm10,%rcx
 1f79a5d:	vpinsrb $0x2,(%r9,%rsi,1),%xmm14,%xmm14
 1f79a64:	vmovd  %xmm10,%esi
 1f79a68:	vextracti64x4 $0x1,%zmm7,%ymm10
 1f79a6f:	vpinsrb $0xe,(%r9,%rsi,1),%xmm12,%xmm7
 1f79a76:	vpextrq $0x1,%xmm13,%rsi
 1f79a7c:	vextracti32x4 $0x2,%zmm8,%xmm13
 1f79a83:	vextracti32x4 $0x3,%zmm8,%xmm8
 1f79a8a:	vpinsrb $0x3,(%r9,%rsi,1),%xmm14,%xmm12
 1f79a91:	vmovd  %xmm9,%esi
 1f79a95:	vpinsrb $0xe,(%r9,%rsi,1),%xmm11,%xmm11
 1f79a9c:	vmovd  %xmm13,%esi
 1f79aa0:	vpinsrb $0xf,(%r9,%rcx,1),%xmm7,%xmm7
 1f79aa7:	vmovd  %xmm8,%ecx
 1f79aab:	vpinsrb $0x4,(%r9,%rsi,1),%xmm12,%xmm12
 1f79ab2:	vpextrq $0x1,%xmm13,%rsi
 1f79ab8:	vpinsrb $0x5,(%r9,%rsi,1),%xmm12,%xmm12
 1f79abf:	vpextrq $0x1,%xmm8,%rsi
 1f79ac5:	vpcmpneqb %xmm16,%xmm7,%k4
 1f79acc:	vpmovzxbd %xmm7,%zmm7
 1f79ad2:	vpinsrb $0x6,(%r9,%rcx,1),%xmm12,%xmm8
 1f79ad9:	vmovd  %xmm6,%ecx
 1f79add:	vpinsrb $0x7,(%r9,%rsi,1),%xmm8,%xmm8
 1f79ae4:	vpextrq $0x1,%xmm6,%rsi
 1f79aea:	vpinsrb $0x8,(%r9,%rcx,1),%xmm8,%xmm8
 1f79af1:	vpextrq $0x1,%xmm9,%rcx
 1f79af7:	vextracti128 $0x1,%ymm6,%xmm9
 1f79afd:	vpinsrb $0x9,(%r9,%rsi,1),%xmm8,%xmm8
 1f79b04:	vmovd  %xmm9,%esi
 1f79b08:	vpinsrb $0xa,(%r9,%rsi,1),%xmm8,%xmm8
 1f79b0f:	vpextrq $0x1,%xmm9,%rsi
 1f79b15:	vextracti32x4 $0x2,%zmm6,%xmm9
 1f79b1c:	vextracti32x4 $0x3,%zmm6,%xmm6
 1f79b23:	vpinsrb $0xb,(%r9,%rsi,1),%xmm8,%xmm8
 1f79b2a:	vmovd  %xmm9,%esi
 1f79b2e:	vpinsrb $0xc,(%r9,%rsi,1),%xmm8,%xmm8
 1f79b35:	vpextrq $0x1,%xmm9,%rsi
 1f79b3b:	vpinsrb $0xf,(%r9,%rcx,1),%xmm11,%xmm9
 1f79b42:	vpextrq $0x1,%xmm15,%rcx
 1f79b48:	vextracti128 $0x1,%ymm15,%xmm11
 1f79b4e:	vpinsrb $0xd,(%r9,%rsi,1),%xmm8,%xmm8
 1f79b55:	vmovd  %xmm6,%esi
 1f79b59:	vpinsrb $0xe,(%r9,%rsi,1),%xmm8,%xmm8
 1f79b60:	vmovd  %xmm15,%esi
 1f79b64:	vpcmpneqb %xmm16,%xmm9,%k3
 1f79b6b:	vpmovzxbd %xmm9,%zmm9
 1f79b71:	movzbl (%r9,%rsi,1),%esi
 1f79b76:	vmovd  %esi,%xmm12
 1f79b7a:	vpinsrb $0x1,(%r9,%rcx,1),%xmm12,%xmm12
 1f79b81:	vmovd  %xmm11,%esi
 1f79b85:	vpextrq $0x1,%xmm11,%rcx
 1f79b8b:	vextracti32x4 $0x2,%zmm15,%xmm11
 1f79b92:	vpinsrb $0x2,(%r9,%rsi,1),%xmm12,%xmm12
 1f79b99:	vmovd  %xmm11,%esi
 1f79b9d:	vpinsrb $0x3,(%r9,%rcx,1),%xmm12,%xmm12
 1f79ba4:	vpextrq $0x1,%xmm11,%rcx
 1f79baa:	vpinsrb $0x4,(%r9,%rsi,1),%xmm12,%xmm11
 1f79bb1:	vpextrq $0x1,%xmm6,%rsi
 1f79bb7:	vpmovzxdq %ymm10,%zmm6
 1f79bbd:	vextracti32x4 $0x3,%zmm15,%xmm10
 1f79bc4:	vpinsrb $0xf,(%r9,%rsi,1),%xmm8,%xmm8
 1f79bcb:	vmovd  %xmm10,%esi
 1f79bcf:	vpinsrb $0x5,(%r9,%rcx,1),%xmm11,%xmm11
 1f79bd6:	vpextrq $0x1,%xmm10,%rcx
 1f79bdc:	vpinsrb $0x6,(%r9,%rsi,1),%xmm11,%xmm10
 1f79be3:	vmovd  %xmm6,%esi
 1f79be7:	vextracti128 $0x1,%ymm6,%xmm11
 1f79bed:	vpcmpneqb %xmm16,%xmm8,%k2
 1f79bf4:	vpmovzxbd %xmm8,%zmm8
 1f79bfa:	vpinsrb $0x7,(%r9,%rcx,1),%xmm10,%xmm10
 1f79c01:	vpextrq $0x1,%xmm6,%rcx
 1f79c07:	vpsrld $0x4,%zmm8,%zmm12
 1f79c0e:	vpandd %zmm17,%zmm8,%zmm8
 1f79c14:	vpcmpgtd %zmm1,%zmm8,%k6
 1f79c1a:	vpmovm2d %k6,%zmm8
 1f79c20:	vpsubd %zmm8,%zmm12,%zmm8
 1f79c26:	vpinsrb $0x8,(%r9,%rsi,1),%xmm10,%xmm10
 1f79c2d:	vmovd  %xmm11,%esi
 1f79c31:	vpmaxud %zmm4,%zmm8,%zmm4{%k2}
 1f79c37:	vpinsrb $0x9,(%r9,%rcx,1),%xmm10,%xmm10
 1f79c3e:	vpextrq $0x1,%xmm11,%rcx
 1f79c44:	vextracti32x4 $0x2,%zmm6,%xmm11
 1f79c4b:	vextracti32x4 $0x3,%zmm6,%xmm6
 1f79c52:	vpinsrb $0xa,(%r9,%rsi,1),%xmm10,%xmm10
 1f79c59:	vmovd  %xmm11,%esi
 1f79c5d:	vpinsrb $0xb,(%r9,%rcx,1),%xmm10,%xmm10
 1f79c64:	vpextrq $0x1,%xmm11,%rcx
 1f79c6a:	vpsrld $0x4,%zmm9,%zmm11
 1f79c71:	vpandd %zmm17,%zmm9,%zmm9
 1f79c77:	vpcmpgtd %zmm1,%zmm9,%k5
 1f79c7d:	vpinsrb $0xc,(%r9,%rsi,1),%xmm10,%xmm10
 1f79c84:	vmovd  %xmm6,%esi
 1f79c88:	vpinsrb $0xd,(%r9,%rcx,1),%xmm10,%xmm10
 1f79c8f:	vpextrq $0x1,%xmm6,%rcx
 1f79c95:	vpinsrb $0xe,(%r9,%rsi,1),%xmm10,%xmm6
 1f79c9c:	vpsrld $0x4,%zmm7,%zmm10
 1f79ca3:	vpandd %zmm17,%zmm7,%zmm7
 1f79ca9:	vpcmpgtd %zmm1,%zmm7,%k0
 1f79caf:	vpmovm2d %k5,%zmm7
 1f79cb5:	vpsubd %zmm7,%zmm11,%zmm7
 1f79cbb:	vpmaxud %zmm3,%zmm7,%zmm3{%k3}
 1f79cc1:	vpinsrb $0xf,(%r9,%rcx,1),%xmm6,%xmm6
 1f79cc8:	vpcmpneqb %xmm16,%xmm6,%k1
 1f79ccf:	vpmovzxbd %xmm6,%zmm6
 1f79cd5:	vpsrld $0x4,%zmm6,%zmm13
 1f79cdc:	vpandd %zmm17,%zmm6,%zmm6
 1f79ce2:	vpcmpgtd %zmm1,%zmm6,%k7
 1f79ce8:	vpmovm2d %k0,%zmm6
 1f79cee:	vpsubd %zmm6,%zmm10,%zmm6
 1f79cf4:	vpmovm2d %k7,%zmm9
 1f79cfa:	vpsubd %zmm9,%zmm13,%zmm9
 1f79d00:	vpmaxud %zmm2,%zmm6,%zmm2{%k4}
 1f79d06:	vpmaxud %zmm5,%zmm9,%zmm5{%k1}
 1f79d0c:	jne    1f79810 <node_facts_front_expression+0xd60>
 1f79d12:	vpmaxud %zmm3,%zmm2,%zmm2
 1f79d18:	vpmaxud %zmm5,%zmm4,%zmm3
 1f79d1e:	mov    0x50(%rsp),%rdi
 1f79d23:	vpmaxud %zmm3,%zmm2,%zmm2
 1f79d29:	vextracti64x4 $0x1,%zmm2,%ymm3
 1f79d30:	vpmaxud %ymm3,%ymm2,%ymm2
 1f79d35:	vextracti128 $0x1,%ymm2,%xmm3
 1f79d3b:	vpmaxud %xmm3,%xmm2,%xmm2
 1f79d40:	vpshufd $0xee,%xmm2,%xmm3
 1f79d45:	vpmaxud %xmm3,%xmm2,%xmm2
 1f79d4a:	vpshufd $0x55,%xmm2,%xmm3
 1f79d4f:	vpmaxud %xmm3,%xmm2,%xmm2
 1f79d54:	vmovd  %xmm2,%r15d
 1f79d59:	cmp    %r11d,%edi
 1f79d5c:	je     1f79537 <node_facts_front_expression+0xa87>
 1f79d62:	test   $0x30,%r11b
 1f79d66:	je     1f79519 <node_facts_front_expression+0xa69>
 1f79d6c:	mov    %r11d,%esi
 1f79d6f:	and    $0xfffffff0,%esi
 1f79d72:	mov    %rdi,%rcx
 1f79d75:	mov    %rdi,%rdx
 1f79d78:	vpbroadcastd %r15d,%zmm2
 1f79d7e:	add    %eax,%ecx
 1f79d80:	sub    %rsi,%rdx
 1f79d83:	mov    %rsi,%rbx
 1f79d86:	cs nopw 0x0(%rax,%rax,1)
 1f79d90:	mov    %ecx,%esi
 1f79d92:	vpmovzxwd (%r10,%rsi,2),%zmm3
 1f79d99:	add    $0x10,%ecx
 1f79d9c:	add    $0x10,%rdx
 1f79da0:	vpsubd %zmm3,%zmm0,%zmm3
 1f79da6:	vextracti64x4 $0x1,%zmm3,%ymm4
 1f79dad:	vpmovzxdq %ymm3,%zmm3
 1f79db3:	vpmovzxdq %ymm4,%zmm4
 1f79db9:	vmovd  %xmm3,%edi
 1f79dbd:	vpextrq $0x1,%xmm3,%rsi
 1f79dc3:	vextracti128 $0x1,%ymm3,%xmm5
 1f79dc9:	movzbl (%r9,%rdi,1),%edi
 1f79dce:	vmovd  %edi,%xmm6
 1f79dd2:	vpinsrb $0x1,(%r9,%rsi,1),%xmm6,%xmm6
 1f79dd9:	vmovd  %xmm5,%edi
 1f79ddd:	vpextrq $0x1,%xmm5,%rsi
 1f79de3:	vextracti32x4 $0x2,%zmm3,%xmm5
 1f79dea:	vextracti32x4 $0x3,%zmm3,%xmm3
 1f79df1:	vpinsrb $0x2,(%r9,%rdi,1),%xmm6,%xmm6
 1f79df8:	vmovd  %xmm5,%edi
 1f79dfc:	vpinsrb $0x3,(%r9,%rsi,1),%xmm6,%xmm6
 1f79e03:	vpextrq $0x1,%xmm5,%rsi
 1f79e09:	vpinsrb $0x4,(%r9,%rdi,1),%xmm6,%xmm5
 1f79e10:	vmovd  %xmm3,%edi
 1f79e14:	vpinsrb $0x5,(%r9,%rsi,1),%xmm5,%xmm5
 1f79e1b:	vpextrq $0x1,%xmm3,%rsi
 1f79e21:	vpinsrb $0x6,(%r9,%rdi,1),%xmm5,%xmm3
 1f79e28:	vmovd  %xmm4,%edi
 1f79e2c:	vextracti128 $0x1,%ymm4,%xmm5
 1f79e32:	vpinsrb $0x7,(%r9,%rsi,1),%xmm3,%xmm3
 1f79e39:	vpextrq $0x1,%xmm4,%rsi
 1f79e3f:	vpinsrb $0x8,(%r9,%rdi,1),%xmm3,%xmm3
 1f79e46:	vmovd  %xmm5,%edi
 1f79e4a:	vpinsrb $0x9,(%r9,%rsi,1),%xmm3,%xmm3
 1f79e51:	vpextrq $0x1,%xmm5,%rsi
 1f79e57:	vextracti32x4 $0x2,%zmm4,%xmm5
 1f79e5e:	vextracti32x4 $0x3,%zmm4,%xmm4
 1f79e65:	vpinsrb $0xa,(%r9,%rdi,1),%xmm3,%xmm3
 1f79e6c:	vmovd  %xmm5,%edi
 1f79e70:	vpinsrb $0xb,(%r9,%rsi,1),%xmm3,%xmm3
 1f79e77:	vpextrq $0x1,%xmm5,%rsi
 1f79e7d:	vpinsrb $0xc,(%r9,%rdi,1),%xmm3,%xmm3
 1f79e84:	vmovd  %xmm4,%edi
 1f79e88:	vpinsrb $0xd,(%r9,%rsi,1),%xmm3,%xmm3
 1f79e8f:	vpextrq $0x1,%xmm4,%rsi
 1f79e95:	vpinsrb $0xe,(%r9,%rdi,1),%xmm3,%xmm3
 1f79e9c:	vpinsrb $0xf,(%r9,%rsi,1),%xmm3,%xmm3
 1f79ea3:	vpcmpneqb %xmm16,%xmm3,%k1
 1f79eaa:	vpmovzxbd %xmm3,%zmm3
 1f79eb0:	vpandd %zmm17,%zmm3,%zmm4
 1f79eb6:	vpsrld $0x4,%zmm3,%zmm3
 1f79ebd:	vpcmpgtd %zmm1,%zmm4,%k0
 1f79ec3:	vpmovm2d %k0,%zmm4
 1f79ec9:	vpsubd %zmm4,%zmm3,%zmm3
 1f79ecf:	vpmaxud %zmm2,%zmm3,%zmm2{%k1}
 1f79ed5:	jne    1f79d90 <node_facts_front_expression+0x12e0>
 1f79edb:	vextracti64x4 $0x1,%zmm2,%ymm0
 1f79ee2:	mov    %rbx,%rdi
 1f79ee5:	vpmaxud %ymm0,%ymm2,%ymm0
 1f79eea:	vextracti128 $0x1,%ymm0,%xmm1
 1f79ef0:	vpmaxud %xmm1,%xmm0,%xmm0
 1f79ef5:	vpshufd $0xee,%xmm0,%xmm1
 1f79efa:	vpmaxud %xmm1,%xmm0,%xmm0
 1f79eff:	vpshufd $0x55,%xmm0,%xmm1
 1f79f04:	vpmaxud %xmm1,%xmm0,%xmm0
 1f79f09:	vmovd  %xmm0,%r15d
 1f79f0e:	cmp    %r11d,%edi
 1f79f11:	jne    1f79519 <node_facts_front_expression+0xa69>
 1f79f17:	jmp    1f79537 <node_facts_front_expression+0xa87>
 1f79f1c:	mov    %rbp,%r10
 1f79f1f:	xor    %r8d,%r8d
 1f79f22:	xor    %edi,%edi
 1f79f24:	xor    %r9d,%r9d
 1f79f27:	xor    %ebp,%ebp
 1f79f29:	movq   $0x0,0x18(%rsp)
 1f79f32:	jmp    1f79072 <node_facts_front_expression+0x5c2>
 1f79f37:	mov    %r9d,%edx
 1f79f3a:	sub    %eax,%edx
 1f79f3c:	inc    %edx
 1f79f3e:	cmp    0x10(%r10),%edx
 1f79f42:	setae  %dl
 1f79f45:	test   %eax,%eax
 1f79f47:	jne    1f78b0c <node_facts_front_expression+0x5c>
 1f79f4d:	mov    $0x1,%eax
 1f79f52:	jmp    1f79f5d <node_facts_front_expression+0x14ad>
 1f79f54:	mov    %esi,%eax
 1f79f56:	jmp    1f79f5d <node_facts_front_expression+0x14ad>
 1f79f58:	mov    $0x2,%eax
 1f79f5d:	add    $0xb8,%rsp
 1f79f64:	pop    %rbx
 1f79f65:	pop    %r12
 1f79f67:	pop    %r13
 1f79f69:	pop    %r14
 1f79f6b:	pop    %r15
 1f79f6d:	pop    %rbp
 1f79f6e:	vzeroupper
 1f79f71:	ret
 1f79f72:	mov    $0x3,%eax
 1f79f77:	jmp    1f79f5d <node_facts_front_expression+0x14ad>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
