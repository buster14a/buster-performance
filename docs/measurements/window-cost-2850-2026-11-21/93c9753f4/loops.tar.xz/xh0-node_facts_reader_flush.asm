
results/xh0/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f76070 <node_facts_reader_flush>:
 1f76070:	push   %rbp
 1f76071:	push   %r15
 1f76073:	push   %r14
 1f76075:	push   %r13
 1f76077:	push   %r12
 1f76079:	push   %rbx
 1f7607a:	sub    $0x58,%rsp
 1f7607e:	mov    0x938(%rdi),%r12
 1f76085:	cmpl   $0x0,0x250(%rdi)
 1f7608c:	mov    %rsi,%r15
 1f7608f:	mov    %rdi,%r14
 1f76092:	je     1f761cd <node_facts_reader_flush+0x15d>
 1f76098:	cmpb   $0x0,0x937(%r14)
 1f760a0:	je     1f761db <node_facts_reader_flush+0x16b>
 1f760a6:	mov    0x25c(%r14),%ebx
 1f760ad:	inc    %ebx
 1f760af:	je     1f77add <node_facts_reader_flush+0x1a6d>
 1f760b5:	mov    (%r14),%rax
 1f760b8:	xor    %ebp,%ebp
 1f760ba:	mov    %r15,0x48(%rsp)
 1f760bf:	mov    %r12,0x20(%rsp)
 1f760c4:	mov    %rax,0x40(%rsp)
 1f760c9:	nopl   0x0(%rax)
 1f760d0:	mov    %r14,%rdi
 1f760d3:	mov    %ebp,%esi
 1f760d5:	xor    %edx,%edx
 1f760d7:	call   1f7ac80 <node_facts_given>
 1f760dc:	rdtsc
 1f760de:	mov    %r14,%rdi
 1f760e1:	mov    %ebp,%esi
 1f760e3:	xor    %ecx,%ecx
 1f760e5:	mov    %rdx,%r12
 1f760e8:	shl    $0x20,%r12
 1f760ec:	xor    %edx,%edx
 1f760ee:	or     %rax,%r12
 1f760f1:	call   1f7ae80 <node_facts_window>
 1f760f6:	rdtsc
 1f760f8:	inc    %ebp
 1f760fa:	shl    $0x20,%rdx
 1f760fe:	or     %rax,%rdx
 1f76101:	sub    %r12,%rdx
 1f76104:	mov    0x20(%rsp),%r12
 1f76109:	add    %rdx,0x8f0(%r12)
 1f76111:	cmp    %ebp,%ebx
 1f76113:	jne    1f760d0 <node_facts_reader_flush+0x60>
 1f76115:	rdtsc
 1f76117:	xor    %r15d,%r15d
 1f7611a:	mov    %rdx,%r13
 1f7611d:	shl    $0x20,%r13
 1f76121:	or     %rax,%r13
 1f76124:	mov    0xa88(%r14),%eax
 1f7612b:	test   %eax,%eax
 1f7612d:	je     1f7621d <node_facts_reader_flush+0x1ad>
 1f76133:	xor    %r12d,%r12d
 1f76136:	xor    %ebp,%ebp
 1f76138:	jmp    1f7615e <node_facts_reader_flush+0xee>
 1f7613a:	nopw   0x0(%rax,%rax,1)
 1f76140:	add    %ecx,%r15d
 1f76143:	cmp    $0x1,%eax
 1f76146:	mov    0xa88(%r14),%eax
 1f7614d:	sbb    $0xffffffff,%ebp
 1f76150:	inc    %r12
 1f76153:	mov    %eax,%ecx
 1f76155:	cmp    %rcx,%r12
 1f76158:	jae    1f76210 <node_facts_reader_flush+0x1a0>
 1f7615e:	mov    0xa78(%r14),%rcx
 1f76165:	cmpb   $0x0,(%rcx,%r12,1)
 1f7616a:	je     1f76150 <node_facts_reader_flush+0xe0>
 1f7616c:	mov    0xa70(%r14),%rax
 1f76173:	mov    %r14,%rdi
 1f76176:	mov    (%rax,%r12,4),%eax
 1f7617a:	mov    %eax,0x9a0(%r14)
 1f76181:	mov    0xa58(%r14),%rcx
 1f76188:	mov    0xa50(%r14),%rax
 1f7618f:	mov    0xa60(%r14),%rsi
 1f76196:	mov    (%rcx,%r12,4),%edx
 1f7619a:	mov    (%rax,%r12,4),%ecx
 1f7619e:	mov    0xa68(%r14),%rax
 1f761a5:	mov    (%rsi,%r12,4),%r8d
 1f761a9:	mov    0x48(%rsp),%rsi
 1f761ae:	mov    (%rax,%r12,4),%r9d
 1f761b2:	call   1f77c20 <node_facts_front_expression>
 1f761b7:	xor    %ecx,%ecx
 1f761b9:	test   %eax,%eax
 1f761bb:	jne    1f76140 <node_facts_reader_flush+0xd0>
 1f761bd:	mov    0xa50(%r14),%rcx
 1f761c4:	mov    (%rcx,%r12,4),%ecx
 1f761c8:	jmp    1f76140 <node_facts_reader_flush+0xd0>
 1f761cd:	cmpb   $0x0,0x937(%r14)
 1f761d5:	jne    1f77add <node_facts_reader_flush+0x1a6d>
 1f761db:	incq   0x8e8(%r12)
 1f761e3:	movb   $0x1,0x937(%r14)
 1f761eb:	cmpb   $0x1,0x9a8(%r14)
 1f761f3:	jne    1f77add <node_facts_reader_flush+0x1a6d>
 1f761f9:	mov    0x9b0(%r14),%rdi
 1f76200:	mov    0x8(%r15),%edx
 1f76204:	xor    %esi,%esi
 1f76206:	call   355bda0 <memset>
 1f7620b:	jmp    1f77add <node_facts_reader_flush+0x1a6d>
 1f76210:	mov    0x20(%rsp),%r12
 1f76215:	mov    %r15d,%ecx
 1f76218:	mov    %ebp,%r15d
 1f7621b:	jmp    1f7621f <node_facts_reader_flush+0x1af>
 1f7621d:	xor    %ecx,%ecx
 1f7621f:	rdtsc
 1f76221:	vmovd  %ecx,%xmm1
 1f76225:	shl    $0x20,%rdx
 1f76229:	or     %rax,%rdx
 1f7622c:	sub    %r13,%rdx
 1f7622f:	vmovq  %rdx,%xmm0
 1f76234:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f76238:	vpaddq 0x998(%r12),%xmm0,%xmm0
 1f76242:	vmovdqu %xmm0,0x998(%r12)
 1f7624c:	add    %r15,0x8e8(%r12)
 1f76254:	mov    0x258(%r14),%edx
 1f7625b:	mov    %edx,0x9a0(%r14)
 1f76262:	mov    %edx,%eax
 1f76264:	mov    0xa88(%r14),%ecx
 1f7626b:	test   %ecx,%ecx
 1f7626d:	je     1f764fe <node_facts_reader_flush+0x48e>
 1f76273:	mov    0xa78(%r14),%rdx
 1f7627a:	xor    %eax,%eax
 1f7627c:	jmp    1f76295 <node_facts_reader_flush+0x225>
 1f7627e:	xchg   %ax,%ax
 1f76280:	mov    0xa88(%r14),%ecx
 1f76287:	inc    %rax
 1f7628a:	mov    %ecx,%esi
 1f7628c:	cmp    %rsi,%rax
 1f7628f:	jae    1f764f0 <node_facts_reader_flush+0x480>
 1f76295:	cmpb   $0x0,(%rdx,%rax,1)
 1f76299:	je     1f76287 <node_facts_reader_flush+0x217>
 1f7629b:	mov    0xa50(%r14),%rcx
 1f762a2:	cmpl   $0x0,(%rcx,%rax,4)
 1f762a6:	je     1f76280 <node_facts_reader_flush+0x210>
 1f762a8:	xor    %ecx,%ecx
 1f762aa:	nopw   0x0(%rax,%rax,1)
 1f762b0:	mov    0xa58(%r14),%rdx
 1f762b7:	mov    0x950(%r14),%rsi
 1f762be:	mov    0x1f0(%r14),%rdi
 1f762c5:	mov    (%rdx,%rax,4),%edx
 1f762c8:	add    %ecx,%edx
 1f762ca:	movzbl (%rsi,%rdx,1),%esi
 1f762ce:	cmp    (%rdi,%rdx,1),%sil
 1f762d2:	jne    1f76450 <node_facts_reader_flush+0x3e0>
 1f762d8:	mov    0x1f8(%r14),%rdi
 1f762df:	mov    0x958(%r14),%r9
 1f762e6:	movzbl (%rdi,%rdx,1),%r8d
 1f762eb:	cmp    %r8b,(%r9,%rdx,1)
 1f762ef:	jne    1f76450 <node_facts_reader_flush+0x3e0>
 1f762f5:	mov    0x960(%r14),%rdi
 1f762fc:	mov    0x200(%r14),%r9
 1f76303:	movzbl (%rdi,%rdx,1),%edi
 1f76307:	cmp    (%r9,%rdx,1),%dil
 1f7630b:	jne    1f76450 <node_facts_reader_flush+0x3e0>
 1f76311:	mov    0x970(%r14),%rdi
 1f76318:	mov    0x210(%r14),%r9
 1f7631f:	movzwl (%rdi,%rdx,2),%edi
 1f76323:	cmp    (%r9,%rdx,2),%di
 1f76328:	jne    1f76450 <node_facts_reader_flush+0x3e0>
 1f7632e:	mov    0x978(%r14),%rdi
 1f76335:	mov    0x218(%r14),%r9
 1f7633c:	movzwl (%rdi,%rdx,2),%edi
 1f76340:	cmp    (%r9,%rdx,2),%di
 1f76345:	jne    1f76450 <node_facts_reader_flush+0x3e0>
 1f7634b:	mov    0x988(%r14),%rdi
 1f76352:	mov    0x228(%r14),%r9
 1f76359:	movzwl (%rdi,%rdx,2),%edi
 1f7635d:	cmp    (%r9,%rdx,2),%di
 1f76362:	jne    1f76450 <node_facts_reader_flush+0x3e0>
 1f76368:	mov    0x990(%r14),%r9
 1f7636f:	mov    0x230(%r14),%r10
 1f76376:	mov    (%r9,%rdx,4),%r9d
 1f7637a:	mov    (%r10,%rdx,4),%r10d
 1f7637e:	cmp    %r10d,%r9d
 1f76381:	jne    1f763d4 <node_facts_reader_flush+0x364>
 1f76383:	mov    %r8d,%r11d
 1f76386:	and    $0xfb,%r11b
 1f7638a:	cmp    $0x2,%r11b
 1f7638e:	jne    1f763d4 <node_facts_reader_flush+0x364>
 1f76390:	mov    0x980(%r14),%rsi
 1f76397:	mov    0x220(%r14),%rdi
 1f7639e:	mov    (%rsi,%rdx,4),%esi
 1f763a1:	mov    (%rdi,%rdx,4),%edi
 1f763a4:	cmp    %edi,%esi
 1f763a6:	je     1f764c8 <node_facts_reader_flush+0x458>
 1f763ac:	mov    0x28(%r14),%r8
 1f763b0:	shl    $0x5,%rsi
 1f763b4:	shl    $0x5,%rdi
 1f763b8:	vmovdqu (%r8,%rsi,1),%ymm0
 1f763be:	vpxor  (%r8,%rdi,1),%ymm0,%ymm0
 1f763c4:	vptest %ymm0,%ymm0
 1f763c9:	jne    1f76450 <node_facts_reader_flush+0x3e0>
 1f763cf:	jmp    1f764c8 <node_facts_reader_flush+0x458>
 1f763d4:	cmp    %r10d,%r9d
 1f763d7:	sete   %r11b
 1f763db:	cmp    $0x1,%r8b
 1f763df:	setne  %r8b
 1f763e3:	and    %r11b,%r8b
 1f763e6:	cmp    $0x1,%r8b
 1f763ea:	jne    1f76449 <node_facts_reader_flush+0x3d9>
 1f763ec:	mov    0x980(%r14),%r8
 1f763f3:	mov    0x220(%r14),%r9
 1f763fa:	mov    (%r8,%rdx,4),%r8d
 1f763fe:	cmp    (%r9,%rdx,4),%r8d
 1f76402:	jne    1f76450 <node_facts_reader_flush+0x3e0>
 1f76404:	cmp    $0x22,%sil
 1f76408:	jne    1f764c8 <node_facts_reader_flush+0x458>
 1f7640e:	test   %rdi,%rdi
 1f76411:	je     1f764c8 <node_facts_reader_flush+0x458>
 1f76417:	mov    0x998(%r14),%rsi
 1f7641e:	mov    0x240(%r14),%r9
 1f76425:	data16 cs nopw 0x0(%rax,%rax,1)
 1f76430:	mov    %r8d,%r10d
 1f76433:	movzwl (%rsi,%r10,2),%r11d
 1f76438:	cmp    (%r9,%r10,2),%r11w
 1f7643d:	jne    1f76450 <node_facts_reader_flush+0x3e0>
 1f7643f:	inc    %r8d
 1f76442:	dec    %rdi
 1f76445:	jne    1f76430 <node_facts_reader_flush+0x3c0>
 1f76447:	jmp    1f764c8 <node_facts_reader_flush+0x458>
 1f76449:	cmp    %r10d,%r9d
 1f7644c:	je     1f764c8 <node_facts_reader_flush+0x458>
 1f7644e:	xchg   %ax,%ax
 1f76450:	incq   0x980(%r12)
 1f76458:	mov    (%r14),%rsi
 1f7645b:	mov    0x238(%r14),%rdi
 1f76462:	mov    (%rdi,%rdx,4),%r8d
 1f76466:	mov    0x10(%rsi),%rsi
 1f7646a:	mov    $0xffffffff,%edi
 1f7646f:	cmp    0xec(%rsi),%r8d
 1f76476:	jae    1f76480 <node_facts_reader_flush+0x410>
 1f76478:	mov    0x28(%rsi),%rsi
 1f7647c:	mov    (%rsi,%r8,4),%edi
 1f76480:	mov    0x938(%r14),%rsi
 1f76487:	mov    0x11b8(%rsi),%r8d
 1f7648e:	cmp    $0xf,%r8
 1f76492:	ja     1f764c8 <node_facts_reader_flush+0x458>
 1f76494:	mov    %edi,0x1158(%rsi,%r8,4)
 1f7649c:	mov    0x1f0(%r14),%rdi
 1f764a3:	movzbl (%rdi,%rdx,1),%edx
 1f764a7:	mov    0x11b8(%rsi),%edi
 1f764ad:	mov    %dl,0x1198(%rsi,%rdi,1)
 1f764b4:	mov    0x11b8(%rsi),%edx
 1f764ba:	movb   $0x3,0x11a8(%rsi,%rdx,1)
 1f764c2:	incl   0x11b8(%rsi)
 1f764c8:	mov    0xa78(%r14),%rdx
 1f764cf:	cmpb   $0x0,(%rdx,%rax,1)
 1f764d3:	je     1f76280 <node_facts_reader_flush+0x210>
 1f764d9:	mov    0xa50(%r14),%rsi
 1f764e0:	inc    %ecx
 1f764e2:	cmp    (%rsi,%rax,4),%ecx
 1f764e5:	jb     1f762b0 <node_facts_reader_flush+0x240>
 1f764eb:	jmp    1f76280 <node_facts_reader_flush+0x210>
 1f764f0:	mov    0x258(%r14),%eax
 1f764f7:	mov    0x9a0(%r14),%edx
 1f764fe:	mov    0x990(%r14),%rdi
 1f76505:	mov    0x230(%r14),%rcx
 1f7650c:	mov    0x240(%r14),%rsi
 1f76513:	vmovdqu64 0x950(%r14),%zmm0
 1f7651d:	mov    %rdi,0x230(%r14)
 1f76524:	mov    0x998(%r14),%rdi
 1f7652b:	mov    %rdi,0x240(%r14)
 1f76532:	mov    %edx,0x258(%r14)
 1f76539:	vmovdqu64 0x1f0(%r14),%zmm1
 1f76543:	vmovdqu64 %zmm0,0x1f0(%r14)
 1f7654d:	vmovdqu64 %zmm1,0x950(%r14)
 1f76557:	mov    %rcx,0x990(%r14)
 1f7655e:	mov    %rsi,0x998(%r14)
 1f76565:	mov    %eax,0x9a0(%r14)
 1f7656c:	mov    %ebx,%eax
 1f7656e:	xor    %ebx,%ebx
 1f76570:	movl   $0x0,0x9a4(%r14)
 1f7657b:	mov    %rax,0x28(%rsp)
 1f76580:	jmp    1f765a3 <node_facts_reader_flush+0x533>
 1f76582:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f76590:	mov    0x38(%rsp),%rbx
 1f76595:	inc    %rbx
 1f76598:	cmp    0x28(%rsp),%rbx
 1f7659d:	je     1f76c93 <node_facts_reader_flush+0xc23>
 1f765a3:	mov    0x248(%r14),%rax
 1f765aa:	mov    $0x1,%edx
 1f765af:	mov    %r14,%rdi
 1f765b2:	mov    %ebx,%esi
 1f765b4:	mov    (%rax,%rbx,4),%r13d
 1f765b8:	mov    0x4(%rax,%rbx,4),%ebp
 1f765bc:	vzeroupper
 1f765bf:	call   1f7ac80 <node_facts_given>
 1f765c4:	mov    %r14,%rdi
 1f765c7:	mov    %ebx,%esi
 1f765c9:	xor    %edx,%edx
 1f765cb:	xor    %ecx,%ecx
 1f765cd:	call   1f7ae80 <node_facts_window>
 1f765d2:	mov    %r14,%rdi
 1f765d5:	mov    %ebx,%esi
 1f765d7:	mov    %rbx,0x38(%rsp)
 1f765dc:	call   1f7bad0 <node_facts_lists_same>
 1f765e1:	test   %al,%al
 1f765e3:	jne    1f7665a <node_facts_reader_flush+0x5ea>
 1f765e5:	incq   0x8e0(%r12)
 1f765ed:	mov    (%r14),%rax
 1f765f0:	mov    0x238(%r14),%rcx
 1f765f7:	mov    (%rcx,%r13,4),%edx
 1f765fb:	mov    0x10(%rax),%rax
 1f765ff:	mov    $0xffffffff,%ecx
 1f76604:	cmp    0xec(%rax),%edx
 1f7660a:	jae    1f76613 <node_facts_reader_flush+0x5a3>
 1f7660c:	mov    0x28(%rax),%rax
 1f76610:	mov    (%rax,%rdx,4),%ecx
 1f76613:	mov    0x938(%r14),%rax
 1f7661a:	mov    0x11b8(%rax),%edx
 1f76620:	cmp    $0xf,%rdx
 1f76624:	ja     1f7665a <node_facts_reader_flush+0x5ea>
 1f76626:	mov    %ecx,0x1158(%rax,%rdx,4)
 1f7662d:	mov    0x1f0(%r14),%rcx
 1f76634:	mov    0x11b8(%rax),%edx
 1f7663a:	movzbl (%rcx,%r13,1),%ecx
 1f7663f:	mov    %cl,0x1198(%rax,%rdx,1)
 1f76646:	mov    0x11b8(%rax),%ecx
 1f7664c:	movb   $0x2,0x11a8(%rax,%rcx,1)
 1f76654:	incl   0x11b8(%rax)
 1f7665a:	vpbroadcastq -0x19aa5ab(%rip),%xmm2        # 5cc0b8 <.LCPI1282_0>
 1f76663:	vpbroadcastd -0x19a7b94(%rip),%xmm3        # 5cead8 <.LCPI1282_1>
 1f7666c:	cmp    %r13d,%ebp
 1f7666f:	je     1f76590 <node_facts_reader_flush+0x520>
 1f76675:	sub    %r13d,%ebp
 1f76678:	xor    %ecx,%ecx
 1f7667a:	mov    %ebp,%eax
 1f7667c:	mov    %rax,(%rsp)
 1f76680:	jmp    1f7669d <node_facts_reader_flush+0x62d>
 1f76682:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f76690:	inc    %rcx
 1f76693:	cmp    (%rsp),%rcx
 1f76697:	je     1f76590 <node_facts_reader_flush+0x520>
 1f7669d:	mov    0x1f8(%r14),%rsi
 1f766a4:	lea    0x0(%r13,%rcx,1),%edx
 1f766a9:	mov    0x1f0(%r14),%rax
 1f766b0:	mov    %rdx,0x18(%rsp)
 1f766b5:	movzbl (%rsi,%rdx,1),%edi
 1f766b9:	movzbl (%rax,%rdx,1),%eax
 1f766bd:	cmp    $0x1,%edi
 1f766c0:	sete   %sil
 1f766c4:	cmp    $0x6,%edi
 1f766c7:	sete   %r8b
 1f766cb:	or     %sil,%r8b
 1f766ce:	mov    0xa90(%r14),%rsi
 1f766d5:	movzbl %r8b,%r8d
 1f766d9:	movzbl (%rsi,%rdx,1),%esi
 1f766dd:	test   %sil,%sil
 1f766e0:	setne  %r9b
 1f766e4:	add    %r8,0x8a0(%r12)
 1f766ec:	and    %r9b,%r8b
 1f766ef:	vmovd  %r9d,%xmm0
 1f766f4:	vpinsrb $0x1,%r8d,%xmm0,%xmm0
 1f766fa:	vpmovzxbq %xmm0,%xmm0
 1f766ff:	vptestmq %xmm2,%xmm0,%k0
 1f76705:	vmovdqu 0x950(%r12),%xmm0
 1f7670f:	vpmovm2q %k0,%xmm1
 1f76715:	vpsubq %xmm1,%xmm0,%xmm0
 1f76719:	vmovdqu %xmm0,0x950(%r12)
 1f76723:	cmp    $0x7,%edi
 1f76726:	ja     1f76690 <node_facts_reader_flush+0x620>
 1f7672c:	mov    $0xcc,%r8d
 1f76732:	bt     %edi,%r8d
 1f76736:	jae    1f76690 <node_facts_reader_flush+0x620>
 1f7673c:	test   %sil,%sil
 1f7673f:	mov    %edi,%r9d
 1f76742:	mov    %rcx,%r11
 1f76745:	setne  %sil
 1f76749:	cmp    $0x6,%dil
 1f7674d:	sete   %r8b
 1f76751:	and    $0xfe,%r9b
 1f76755:	cmp    $0x2,%r9b
 1f76759:	sete   %r9b
 1f7675d:	cmp    $0x7,%dil
 1f76761:	mov    0x2c0(%r14),%rdi
 1f76768:	sete   %bpl
 1f7676c:	shl    $0x6,%r11
 1f76770:	or     %r9b,%bpl
 1f76773:	vmovd  %ebp,%xmm0
 1f76777:	movzbl %bpl,%r10d
 1f7677b:	movzbl 0x19(%rdi,%r11,1),%edi
 1f76781:	dec    %dil
 1f76784:	sete   %r15b
 1f76788:	cmp    $0x2,%dil
 1f7678c:	setb   %r9b
 1f76790:	setae  %dil
 1f76794:	and    %bpl,%r15b
 1f76797:	and    %r10b,%sil
 1f7679a:	and    %r9b,%bpl
 1f7679d:	and    %r10b,%dil
 1f767a0:	vpinsrb $0x1,%ebp,%xmm0,%xmm0
 1f767a6:	vpinsrb $0x2,%r15d,%xmm0,%xmm0
 1f767ac:	vpinsrb $0x3,%r8d,%xmm0,%xmm0
 1f767b2:	and    %r9b,%r8b
 1f767b5:	and    %sil,%r9b
 1f767b8:	vpmovzxbd %xmm0,%xmm0
 1f767bd:	movzbl %r8b,%r8d
 1f767c1:	vptestmd %xmm3,%xmm0,%k0
 1f767c7:	vmovdqu 0x8a8(%r12),%ymm0
 1f767d1:	vpmovm2q %k0,%ymm1
 1f767d7:	vpsubq %ymm1,%ymm0,%ymm0
 1f767db:	vmovdqu %ymm0,0x8a8(%r12)
 1f767e5:	vmovd  %esi,%xmm0
 1f767e9:	add    %r8,0x8c8(%r12)
 1f767f1:	movzbl %dil,%esi
 1f767f5:	lea    (%rcx,%r13,1),%r8
 1f767f9:	vpinsrb $0x1,%r9d,%xmm0,%xmm0
 1f767ff:	vpmovzxbq %xmm0,%xmm0
 1f76804:	vptestmq %xmm2,%xmm0,%k0
 1f7680a:	vmovdqu 0x960(%r12),%xmm0
 1f76814:	vpmovm2q %k0,%xmm1
 1f7681a:	vpsubq %xmm1,%xmm0,%xmm0
 1f7681e:	vmovdqu %xmm0,0x960(%r12)
 1f76828:	add    %r10,0xd08(%r12,%rax,8)
 1f76830:	add    %rsi,0xf30(%r12,%rax,8)
 1f76838:	mov    0x288(%r14),%rax
 1f7683f:	movzbl (%rax,%r8,1),%esi
 1f76844:	mov    %esi,%ebp
 1f76846:	and    $0x60,%bpl
 1f7684a:	cmp    $0x40,%bpl
 1f7684e:	jne    1f76860 <node_facts_reader_flush+0x7f0>
 1f76850:	mov    0x290(%r14),%rax
 1f76857:	movzwl (%rax,%r8,2),%edx
 1f7685c:	jmp    1f76862 <node_facts_reader_flush+0x7f2>
 1f7685e:	xchg   %ax,%ax
 1f76860:	xor    %edx,%edx
 1f76862:	mov    0x2a0(%r14),%rdi
 1f76869:	mov    0x2c0(%r14),%rax
 1f76870:	mov    0x268(%r14),%r15
 1f76877:	mov    (%rdi,%r8,8),%r12d
 1f7687b:	mov    0x4(%rdi,%r8,8),%r10d
 1f76880:	mov    0x2b0(%r14),%rdi
 1f76887:	mov    (%r15,%r8,4),%ebx
 1f7688b:	mov    %rax,0x10(%rsp)
 1f76890:	add    %rax,%r11
 1f76893:	mov    0x2a8(%r14),%rax
 1f7689a:	mov    0x1f0(%r14),%r15
 1f768a1:	mov    (%rdi,%r8,8),%rdi
 1f768a5:	mov    (%rax,%r8,8),%r9d
 1f768a9:	mov    0x4(%rax,%r8,8),%eax
 1f768ae:	mov    %rdi,0x8(%rsp)
 1f768b3:	mov    0x18(%rsp),%rdi
 1f768b8:	movzbl (%r15,%rdi,1),%r15d
 1f768bd:	cmp    %ebx,(%r11)
 1f768c0:	jne    1f76930 <node_facts_reader_flush+0x8c0>
 1f768c2:	mov    0x298(%r14),%rdi
 1f768c9:	mov    (%rdi,%r8,4),%edi
 1f768cd:	cmp    %edi,0x4(%r11)
 1f768d1:	jne    1f76930 <node_facts_reader_flush+0x8c0>
 1f768d3:	mov    0x270(%r14),%rdi
 1f768da:	mov    (%rdi,%r8,4),%edi
 1f768de:	cmp    %edi,0x8(%r11)
 1f768e2:	jne    1f76930 <node_facts_reader_flush+0x8c0>
 1f768e4:	mov    0x278(%r14),%rdi
 1f768eb:	mov    (%rdi,%r8,4),%edi
 1f768ef:	cmp    %edi,0xc(%r11)
 1f768f3:	jne    1f7693b <node_facts_reader_flush+0x8cb>
 1f768f5:	mov    0x280(%r14),%rdi
 1f768fc:	mov    (%rdi,%r8,8),%rdi
 1f76900:	cmp    %rdi,0x10(%r11)
 1f76904:	jne    1f76930 <node_facts_reader_flush+0x8c0>
 1f76906:	movzbl 0x18(%r11),%edi
 1f7690b:	cmp    %sil,%dil
 1f7690e:	sete   %r8b
 1f76912:	cmp    $0x40,%bpl
 1f76916:	jne    1f76940 <node_facts_reader_flush+0x8d0>
 1f76918:	cmp    %sil,%dil
 1f7691b:	jne    1f76940 <node_facts_reader_flush+0x8d0>
 1f7691d:	cmp    %dx,0x1a(%r11)
 1f76922:	sete   %r8b
 1f76926:	cmp    %r12d,0x20(%r11)
 1f7692a:	je     1f76946 <node_facts_reader_flush+0x8d6>
 1f7692c:	jmp    1f76970 <node_facts_reader_flush+0x900>
 1f7692e:	xchg   %ax,%ax
 1f76930:	xor    %r8d,%r8d
 1f76933:	cmp    %r12d,0x20(%r11)
 1f76937:	je     1f76946 <node_facts_reader_flush+0x8d6>
 1f76939:	jmp    1f76970 <node_facts_reader_flush+0x900>
 1f7693b:	xor    %r8d,%r8d
 1f7693e:	xchg   %ax,%ax
 1f76940:	cmp    %r12d,0x20(%r11)
 1f76944:	jne    1f76970 <node_facts_reader_flush+0x900>
 1f76946:	cmp    %r10d,0x24(%r11)
 1f7694a:	jne    1f76970 <node_facts_reader_flush+0x900>
 1f7694c:	cmp    %r9d,0x28(%r11)
 1f76950:	jne    1f76970 <node_facts_reader_flush+0x900>
 1f76952:	cmp    %eax,0x2c(%r11)
 1f76956:	sete   %r9b
 1f7695a:	mov    0x30(%r11),%r10
 1f7695e:	mov    $0x1,%al
 1f76960:	cmp    $0x22,%r15b
 1f76964:	jne    1f76bf0 <node_facts_reader_flush+0xb80>
 1f7696a:	jmp    1f76983 <node_facts_reader_flush+0x913>
 1f7696c:	nopl   0x0(%rax)
 1f76970:	xor    %r9d,%r9d
 1f76973:	mov    0x30(%r11),%r10
 1f76977:	mov    $0x1,%al
 1f76979:	cmp    $0x22,%r15b
 1f7697d:	jne    1f76bf0 <node_facts_reader_flush+0xb80>
 1f76983:	cmp    $0x40,%bpl
 1f76987:	je     1f76bf0 <node_facts_reader_flush+0xb80>
 1f7698d:	cmpb   $0x0,0x19(%r11)
 1f76992:	je     1f76bf0 <node_facts_reader_flush+0xb80>
 1f76998:	testb  $0x2,0x1a(%r11)
 1f7699d:	je     1f76bf0 <node_facts_reader_flush+0xb80>
 1f769a3:	mov    0x228(%r14),%rsi
 1f769aa:	mov    0x18(%rsp),%rdx
 1f769af:	movzwl (%rsi,%rdx,2),%r12d
 1f769b4:	test   %r12,%r12
 1f769b7:	je     1f76bf0 <node_facts_reader_flush+0xb80>
 1f769bd:	mov    0x220(%r14),%rax
 1f769c4:	mov    0x18(%rsp),%rdx
 1f769c9:	mov    0x240(%r14),%r11
 1f769d0:	mov    %r12d,%ebp
 1f769d3:	and    $0x7,%ebp
 1f769d6:	mov    (%rax,%rdx,4),%eax
 1f769d9:	mov    %rax,0x30(%rsp)
 1f769de:	cmp    $0x8,%r12w
 1f769e3:	jae    1f769f4 <node_facts_reader_flush+0x984>
 1f769e5:	mov    0x10(%rsp),%rdx
 1f769ea:	mov    $0x1,%al
 1f769ec:	xor    %r15d,%r15d
 1f769ef:	jmp    1f76b89 <node_facts_reader_flush+0xb19>
 1f769f4:	mov    0x10(%rsp),%rdx
 1f769f9:	mov    %r11,0x50(%rsp)
 1f769fe:	lea    0xe(%r11,%rax,2),%r11
 1f76a03:	and    $0xfffffff8,%r12d
 1f76a07:	mov    $0x1,%al
 1f76a09:	xor    %r15d,%r15d
 1f76a0c:	nopl   0x0(%rax)
 1f76a10:	cmp    $0x1,%al
 1f76a12:	jne    1f76b70 <node_facts_reader_flush+0xb00>
 1f76a18:	movzwl -0xe(%r11,%r15,2),%eax
 1f76a1e:	mov    0x2b8(%r14),%rbx
 1f76a25:	mov    %ecx,%esi
 1f76a27:	sub    %eax,%esi
 1f76a29:	mov    %rsi,%rax
 1f76a2c:	shl    $0x6,%rax
 1f76a30:	mov    0x38(%rdx,%rax,1),%rdi
 1f76a35:	lea    0x0(,%r13,8),%rax
 1f76a3d:	add    %rax,%rbx
 1f76a40:	cmp    (%rbx,%rsi,8),%rdi
 1f76a44:	jne    1f76b70 <node_facts_reader_flush+0xb00>
 1f76a4a:	movzwl -0xc(%r11,%r15,2),%esi
 1f76a50:	mov    0x2b8(%r14),%rbx
 1f76a57:	mov    %ecx,%edi
 1f76a59:	sub    %esi,%edi
 1f76a5b:	add    %rax,%rbx
 1f76a5e:	mov    %rdi,%rsi
 1f76a61:	shl    $0x6,%rsi
 1f76a65:	mov    0x38(%rdx,%rsi,1),%rsi
 1f76a6a:	cmp    (%rbx,%rdi,8),%rsi
 1f76a6e:	jne    1f76b70 <node_facts_reader_flush+0xb00>
 1f76a74:	movzwl -0xa(%r11,%r15,2),%esi
 1f76a7a:	mov    0x2b8(%r14),%rbx
 1f76a81:	mov    %ecx,%edi
 1f76a83:	sub    %esi,%edi
 1f76a85:	add    %rax,%rbx
 1f76a88:	mov    %rdi,%rsi
 1f76a8b:	shl    $0x6,%rsi
 1f76a8f:	mov    0x38(%rdx,%rsi,1),%rsi
 1f76a94:	cmp    (%rbx,%rdi,8),%rsi
 1f76a98:	jne    1f76b70 <node_facts_reader_flush+0xb00>
 1f76a9e:	movzwl -0x8(%r11,%r15,2),%esi
 1f76aa4:	mov    0x2b8(%r14),%rbx
 1f76aab:	mov    %ecx,%edi
 1f76aad:	sub    %esi,%edi
 1f76aaf:	add    %rax,%rbx
 1f76ab2:	mov    %rdi,%rsi
 1f76ab5:	shl    $0x6,%rsi
 1f76ab9:	mov    0x38(%rdx,%rsi,1),%rsi
 1f76abe:	cmp    (%rbx,%rdi,8),%rsi
 1f76ac2:	jne    1f76b70 <node_facts_reader_flush+0xb00>
 1f76ac8:	movzwl -0x6(%r11,%r15,2),%esi
 1f76ace:	mov    0x2b8(%r14),%rbx
 1f76ad5:	mov    %ecx,%edi
 1f76ad7:	sub    %esi,%edi
 1f76ad9:	add    %rax,%rbx
 1f76adc:	mov    %rdi,%rsi
 1f76adf:	shl    $0x6,%rsi
 1f76ae3:	mov    0x38(%rdx,%rsi,1),%rsi
 1f76ae8:	cmp    (%rbx,%rdi,8),%rsi
 1f76aec:	jne    1f76b70 <node_facts_reader_flush+0xb00>
 1f76af2:	movzwl -0x4(%r11,%r15,2),%esi
 1f76af8:	mov    0x2b8(%r14),%rbx
 1f76aff:	mov    %ecx,%edi
 1f76b01:	sub    %esi,%edi
 1f76b03:	add    %rax,%rbx
 1f76b06:	mov    %rdi,%rsi
 1f76b09:	shl    $0x6,%rsi
 1f76b0d:	mov    0x38(%rdx,%rsi,1),%rsi
 1f76b12:	cmp    (%rbx,%rdi,8),%rsi
 1f76b16:	jne    1f76b70 <node_facts_reader_flush+0xb00>
 1f76b18:	movzwl -0x2(%r11,%r15,2),%esi
 1f76b1e:	mov    0x2b8(%r14),%rbx
 1f76b25:	mov    %ecx,%edi
 1f76b27:	sub    %esi,%edi
 1f76b29:	add    %rax,%rbx
 1f76b2c:	mov    %rdi,%rsi
 1f76b2f:	shl    $0x6,%rsi
 1f76b33:	mov    0x38(%rdx,%rsi,1),%rsi
 1f76b38:	cmp    (%rbx,%rdi,8),%rsi
 1f76b3c:	jne    1f76b70 <node_facts_reader_flush+0xb00>
 1f76b3e:	movzwl (%r11,%r15,2),%esi
 1f76b43:	add    0x2b8(%r14),%rax
 1f76b4a:	mov    %ecx,%edi
 1f76b4c:	sub    %esi,%edi
 1f76b4e:	mov    %rdi,%rsi
 1f76b51:	shl    $0x6,%rsi
 1f76b55:	mov    0x38(%rdx,%rsi,1),%rsi
 1f76b5a:	cmp    (%rax,%rdi,8),%rsi
 1f76b5e:	sete   %al
 1f76b61:	add    $0x8,%r15
 1f76b65:	cmp    %r15,%r12
 1f76b68:	jne    1f76a10 <node_facts_reader_flush+0x9a0>
 1f76b6e:	jmp    1f76b7f <node_facts_reader_flush+0xb0f>
 1f76b70:	xor    %eax,%eax
 1f76b72:	add    $0x8,%r15
 1f76b76:	cmp    %r15,%r12
 1f76b79:	jne    1f76a10 <node_facts_reader_flush+0x9a0>
 1f76b7f:	mov    0x50(%rsp),%r11
 1f76b84:	test   %rbp,%rbp
 1f76b87:	je     1f76bf0 <node_facts_reader_flush+0xb80>
 1f76b89:	mov    0x30(%rsp),%rsi
 1f76b8e:	add    %rsi,%rsi
 1f76b91:	lea    (%rsi,%r15,2),%rsi
 1f76b95:	add    %rsi,%r11
 1f76b98:	xor    %esi,%esi
 1f76b9a:	jmp    1f76bd3 <node_facts_reader_flush+0xb63>
 1f76b9c:	nopl   0x0(%rax)
 1f76ba0:	movzwl (%r11,%rsi,2),%eax
 1f76ba5:	lea    0x0(,%r13,8),%rbx
 1f76bad:	add    0x2b8(%r14),%rbx
 1f76bb4:	mov    %ecx,%edi
 1f76bb6:	sub    %eax,%edi
 1f76bb8:	mov    %rdi,%rax
 1f76bbb:	shl    $0x6,%rax
 1f76bbf:	mov    0x38(%rdx,%rax,1),%rax
 1f76bc4:	cmp    (%rbx,%rdi,8),%rax
 1f76bc8:	sete   %al
 1f76bcb:	inc    %rsi
 1f76bce:	cmp    %rsi,%rbp
 1f76bd1:	je     1f76bf0 <node_facts_reader_flush+0xb80>
 1f76bd3:	cmp    $0x1,%al
 1f76bd5:	je     1f76ba0 <node_facts_reader_flush+0xb30>
 1f76bd7:	xor    %eax,%eax
 1f76bd9:	inc    %rsi
 1f76bdc:	cmp    %rsi,%rbp
 1f76bdf:	jne    1f76bd3 <node_facts_reader_flush+0xb63>
 1f76be1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f76bf0:	mov    0x20(%rsp),%r12
 1f76bf5:	and    %r9b,%r8b
 1f76bf8:	cmp    $0x1,%r8b
 1f76bfc:	jne    1f76c0d <node_facts_reader_flush+0xb9d>
 1f76bfe:	cmp    0x8(%rsp),%r10
 1f76c03:	jne    1f76c0d <node_facts_reader_flush+0xb9d>
 1f76c05:	test   %al,%al
 1f76c07:	jne    1f76690 <node_facts_reader_flush+0x620>
 1f76c0d:	incq   0x8d0(%r12)
 1f76c15:	mov    0x18(%rsp),%rdx
 1f76c1a:	mov    (%r14),%rax
 1f76c1d:	mov    0x238(%r14),%rsi
 1f76c24:	mov    (%rsi,%rdx,4),%edi
 1f76c27:	mov    0x10(%rax),%rax
 1f76c2b:	mov    $0xffffffff,%esi
 1f76c30:	cmp    0xec(%rax),%edi
 1f76c36:	jae    1f76c3f <node_facts_reader_flush+0xbcf>
 1f76c38:	mov    0x28(%rax),%rax
 1f76c3c:	mov    (%rax,%rdi,4),%esi
 1f76c3f:	mov    0x938(%r14),%rax
 1f76c46:	mov    0x11b8(%rax),%edi
 1f76c4c:	cmp    $0xf,%rdi
 1f76c50:	ja     1f76690 <node_facts_reader_flush+0x620>
 1f76c56:	mov    %esi,0x1158(%rax,%rdi,4)
 1f76c5d:	mov    0x18(%rsp),%rdx
 1f76c62:	mov    0x1f0(%r14),%rsi
 1f76c69:	movzbl (%rsi,%rdx,1),%edx
 1f76c6d:	mov    0x11b8(%rax),%esi
 1f76c73:	mov    %dl,0x1198(%rax,%rsi,1)
 1f76c7a:	mov    0x11b8(%rax),%edx
 1f76c80:	movb   $0x0,0x11a8(%rax,%rdx,1)
 1f76c88:	incl   0x11b8(%rax)
 1f76c8e:	jmp    1f76690 <node_facts_reader_flush+0x620>
 1f76c93:	mov    0x990(%r14),%rsi
 1f76c9a:	mov    0x230(%r14),%rax
 1f76ca1:	mov    0x240(%r14),%rcx
 1f76ca8:	mov    0x258(%r14),%edx
 1f76caf:	vmovdqu64 0x950(%r14),%zmm0
 1f76cb9:	mov    0x40(%rsp),%r13
 1f76cbe:	xor    %r15d,%r15d
 1f76cc1:	mov    %rsi,0x230(%r14)
 1f76cc8:	mov    0x998(%r14),%rsi
 1f76ccf:	mov    %rsi,0x240(%r14)
 1f76cd6:	mov    0x9a0(%r14),%esi
 1f76cdd:	mov    %esi,0x258(%r14)
 1f76ce4:	vmovdqu64 0x1f0(%r14),%zmm1
 1f76cee:	vmovdqu64 %zmm0,0x1f0(%r14)
 1f76cf8:	vmovdqu64 %zmm1,0x950(%r14)
 1f76d02:	mov    %rax,0x990(%r14)
 1f76d09:	mov    %rcx,0x998(%r14)
 1f76d10:	mov    %edx,0x9a0(%r14)
 1f76d17:	movl   $0x0,0x9a4(%r14)
 1f76d22:	jmp    1f76d43 <node_facts_reader_flush+0xcd3>
 1f76d24:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f76d30:	mov    0x38(%rsp),%r15
 1f76d35:	inc    %r15
 1f76d38:	cmp    0x28(%rsp),%r15
 1f76d3d:	je     1f77252 <node_facts_reader_flush+0x11e2>
 1f76d43:	mov    0x248(%r14),%rax
 1f76d4a:	mov    $0x3,%edx
 1f76d4f:	mov    %r14,%rdi
 1f76d52:	mov    %r15d,%esi
 1f76d55:	mov    (%rax,%r15,4),%ebx
 1f76d59:	mov    0x4(%rax,%r15,4),%ebp
 1f76d5e:	vzeroupper
 1f76d61:	call   1f7ac80 <node_facts_given>
 1f76d66:	mov    %r14,%rdi
 1f76d69:	mov    %r15,0x38(%rsp)
 1f76d6e:	mov    %r15d,%esi
 1f76d71:	xor    %edx,%edx
 1f76d73:	xor    %ecx,%ecx
 1f76d75:	call   1f7ae80 <node_facts_window>
 1f76d7a:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1f76d7e:	cmp    %ebx,%ebp
 1f76d80:	je     1f76d30 <node_facts_reader_flush+0xcc0>
 1f76d82:	sub    %ebx,%ebp
 1f76d84:	xor    %eax,%eax
 1f76d86:	mov    %rbp,0x18(%rsp)
 1f76d8b:	jmp    1f76d98 <node_facts_reader_flush+0xd28>
 1f76d8d:	nopl   (%rax)
 1f76d90:	inc    %rax
 1f76d93:	cmp    %rbp,%rax
 1f76d96:	je     1f76d30 <node_facts_reader_flush+0xcc0>
 1f76d98:	mov    0x1f8(%r14),%rdx
 1f76d9f:	lea    (%rbx,%rax,1),%ecx
 1f76da2:	testb  $0x2,(%rdx,%rcx,1)
 1f76da6:	je     1f76d90 <node_facts_reader_flush+0xd20>
 1f76da8:	mov    0x288(%r14),%rdx
 1f76daf:	lea    (%rax,%rbx,1),%r8
 1f76db3:	movzbl (%rdx,%r8,1),%edi
 1f76db8:	mov    %edi,%r10d
 1f76dbb:	and    $0x60,%r10b
 1f76dbf:	cmp    $0x40,%r10b
 1f76dc3:	jne    1f76de0 <node_facts_reader_flush+0xd70>
 1f76dc5:	mov    0x290(%r14),%rdx
 1f76dcc:	movzwl (%rdx,%r8,2),%r9d
 1f76dd1:	jmp    1f76de3 <node_facts_reader_flush+0xd73>
 1f76dd3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f76de0:	xor    %r9d,%r9d
 1f76de3:	mov    0x268(%r14),%rsi
 1f76dea:	mov    0x2c0(%r14),%rdx
 1f76df1:	mov    %rax,%r11
 1f76df4:	shl    $0x6,%r11
 1f76df8:	mov    (%rsi,%r8,4),%esi
 1f76dfc:	add    %rdx,%r11
 1f76dff:	cmp    %esi,(%r11)
 1f76e02:	jne    1f76e80 <node_facts_reader_flush+0xe10>
 1f76e04:	mov    0x298(%r14),%rsi
 1f76e0b:	mov    (%rsi,%r8,4),%esi
 1f76e0f:	cmp    %esi,0x4(%r11)
 1f76e13:	jne    1f76e80 <node_facts_reader_flush+0xe10>
 1f76e15:	mov    0x270(%r14),%rsi
 1f76e1c:	mov    (%rsi,%r8,4),%esi
 1f76e20:	cmp    %esi,0x8(%r11)
 1f76e24:	jne    1f76e80 <node_facts_reader_flush+0xe10>
 1f76e26:	mov    0x278(%r14),%rsi
 1f76e2d:	mov    (%rsi,%r8,4),%esi
 1f76e31:	cmp    %esi,0xc(%r11)
 1f76e35:	jne    1f76e95 <node_facts_reader_flush+0xe25>
 1f76e37:	mov    0x280(%r14),%rsi
 1f76e3e:	mov    (%rsi,%r8,8),%rsi
 1f76e42:	cmp    %rsi,0x10(%r11)
 1f76e46:	jne    1f76e80 <node_facts_reader_flush+0xe10>
 1f76e48:	movzbl 0x18(%r11),%ebp
 1f76e4d:	cmp    %dil,%bpl
 1f76e50:	sete   %sil
 1f76e54:	cmp    $0x40,%r10b
 1f76e58:	jne    1f76ea0 <node_facts_reader_flush+0xe30>
 1f76e5a:	cmp    %dil,%bpl
 1f76e5d:	jne    1f76ea0 <node_facts_reader_flush+0xe30>
 1f76e5f:	cmp    %r9w,0x1a(%r11)
 1f76e64:	sete   %sil
 1f76e68:	mov    0x2a0(%r14),%rdi
 1f76e6f:	mov    (%rdi,%r8,8),%r9d
 1f76e73:	cmp    %r9d,0x20(%r11)
 1f76e77:	je     1f76eb1 <node_facts_reader_flush+0xe41>
 1f76e79:	jmp    1f76ee0 <node_facts_reader_flush+0xe70>
 1f76e7b:	nopl   0x0(%rax,%rax,1)
 1f76e80:	xor    %esi,%esi
 1f76e82:	mov    0x2a0(%r14),%rdi
 1f76e89:	mov    (%rdi,%r8,8),%r9d
 1f76e8d:	cmp    %r9d,0x20(%r11)
 1f76e91:	je     1f76eb1 <node_facts_reader_flush+0xe41>
 1f76e93:	jmp    1f76ee0 <node_facts_reader_flush+0xe70>
 1f76e95:	xor    %esi,%esi
 1f76e97:	nopw   0x0(%rax,%rax,1)
 1f76ea0:	mov    0x2a0(%r14),%rdi
 1f76ea7:	mov    (%rdi,%r8,8),%r9d
 1f76eab:	cmp    %r9d,0x20(%r11)
 1f76eaf:	jne    1f76ee0 <node_facts_reader_flush+0xe70>
 1f76eb1:	mov    0x4(%rdi,%r8,8),%edi
 1f76eb6:	cmp    %edi,0x24(%r11)
 1f76eba:	jne    1f76ee0 <node_facts_reader_flush+0xe70>
 1f76ebc:	mov    0x2a8(%r14),%rdi
 1f76ec3:	mov    (%rdi,%r8,8),%r9d
 1f76ec7:	cmp    %r9d,0x28(%r11)
 1f76ecb:	jne    1f76ee0 <node_facts_reader_flush+0xe70>
 1f76ecd:	mov    0x4(%rdi,%r8,8),%edi
 1f76ed2:	cmp    %edi,0x2c(%r11)
 1f76ed6:	sete   %dil
 1f76eda:	jmp    1f76ee2 <node_facts_reader_flush+0xe72>
 1f76edc:	nopl   0x0(%rax)
 1f76ee0:	xor    %edi,%edi
 1f76ee2:	mov    0x1f0(%r14),%r12
 1f76ee9:	mov    0x2b0(%r14),%r9
 1f76ef0:	mov    $0x1,%r15b
 1f76ef3:	mov    (%r9,%r8,8),%r8
 1f76ef7:	mov    0x30(%r11),%r9
 1f76efb:	cmpb   $0x22,(%r12,%rcx,1)
 1f76f00:	jne    1f771a0 <node_facts_reader_flush+0x1130>
 1f76f06:	mov    0x20(%rsp),%r12
 1f76f0b:	cmp    $0x40,%r10b
 1f76f0f:	je     1f771a5 <node_facts_reader_flush+0x1135>
 1f76f15:	cmpb   $0x0,0x19(%r11)
 1f76f1a:	je     1f771a5 <node_facts_reader_flush+0x1135>
 1f76f20:	testb  $0x2,0x1a(%r11)
 1f76f25:	je     1f771a5 <node_facts_reader_flush+0x1135>
 1f76f2b:	mov    0x228(%r14),%r10
 1f76f32:	movzwl (%r10,%rcx,2),%r13d
 1f76f37:	test   %r13,%r13
 1f76f3a:	je     1f771a5 <node_facts_reader_flush+0x1135>
 1f76f40:	mov    0x220(%r14),%r11
 1f76f47:	mov    0x240(%r14),%r10
 1f76f4e:	mov    (%r11,%rcx,4),%r15d
 1f76f52:	mov    %r13d,%r11d
 1f76f55:	and    $0x7,%r11d
 1f76f59:	mov    %r15,0x30(%rsp)
 1f76f5e:	cmp    $0x8,%r13w
 1f76f63:	jae    1f76f70 <node_facts_reader_flush+0xf00>
 1f76f65:	mov    $0x1,%r15b
 1f76f68:	xor    %r12d,%r12d
 1f76f6b:	jmp    1f77138 <node_facts_reader_flush+0x10c8>
 1f76f70:	lea    0xe(%r10,%r15,2),%rbp
 1f76f75:	and    $0xfffffff8,%r13d
 1f76f79:	mov    $0x1,%r15b
 1f76f7c:	xor    %r12d,%r12d
 1f76f7f:	mov    %edi,0x8(%rsp)
 1f76f83:	mov    %r10,(%rsp)
 1f76f87:	mov    %r13,0x10(%rsp)
 1f76f8c:	jmp    1f76fa0 <node_facts_reader_flush+0xf30>
 1f76f8e:	xchg   %ax,%ax
 1f76f90:	xor    %r15d,%r15d
 1f76f93:	add    $0x8,%r12
 1f76f97:	cmp    %r12,%r13
 1f76f9a:	je     1f77133 <node_facts_reader_flush+0x10c3>
 1f76fa0:	cmp    $0x1,%r15b
 1f76fa4:	jne    1f76f90 <node_facts_reader_flush+0xf20>
 1f76fa6:	movzwl -0xe(%rbp,%r12,2),%r15d
 1f76fac:	mov    %r9,%rdi
 1f76faf:	mov    %r8,%r9
 1f76fb2:	mov    0x2b8(%r14),%r8
 1f76fb9:	mov    %eax,%r13d
 1f76fbc:	sub    %r15d,%r13d
 1f76fbf:	mov    %r13,%r15
 1f76fc2:	shl    $0x6,%r15
 1f76fc6:	mov    0x38(%rdx,%r15,1),%r10
 1f76fcb:	lea    0x0(,%rbx,8),%r15
 1f76fd3:	add    %r15,%r8
 1f76fd6:	cmp    (%r8,%r13,8),%r10
 1f76fda:	jne    1f77110 <node_facts_reader_flush+0x10a0>
 1f76fe0:	movzwl -0xc(%rbp,%r12,2),%r8d
 1f76fe6:	mov    0x2b8(%r14),%r13
 1f76fed:	mov    %eax,%r10d
 1f76ff0:	sub    %r8d,%r10d
 1f76ff3:	add    %r15,%r13
 1f76ff6:	mov    %r10,%r8
 1f76ff9:	shl    $0x6,%r8
 1f76ffd:	mov    0x38(%rdx,%r8,1),%r8
 1f77002:	cmp    0x0(%r13,%r10,8),%r8
 1f77007:	jne    1f77110 <node_facts_reader_flush+0x10a0>
 1f7700d:	movzwl -0xa(%rbp,%r12,2),%r8d
 1f77013:	mov    0x2b8(%r14),%r13
 1f7701a:	mov    %eax,%r10d
 1f7701d:	sub    %r8d,%r10d
 1f77020:	add    %r15,%r13
 1f77023:	mov    %r10,%r8
 1f77026:	shl    $0x6,%r8
 1f7702a:	mov    0x38(%rdx,%r8,1),%r8
 1f7702f:	cmp    0x0(%r13,%r10,8),%r8
 1f77034:	jne    1f77110 <node_facts_reader_flush+0x10a0>
 1f7703a:	movzwl -0x8(%rbp,%r12,2),%r8d
 1f77040:	mov    0x2b8(%r14),%r13
 1f77047:	mov    %eax,%r10d
 1f7704a:	sub    %r8d,%r10d
 1f7704d:	add    %r15,%r13
 1f77050:	mov    %r10,%r8
 1f77053:	shl    $0x6,%r8
 1f77057:	mov    0x38(%rdx,%r8,1),%r8
 1f7705c:	cmp    0x0(%r13,%r10,8),%r8
 1f77061:	jne    1f77110 <node_facts_reader_flush+0x10a0>
 1f77067:	movzwl -0x6(%rbp,%r12,2),%r8d
 1f7706d:	mov    0x2b8(%r14),%r13
 1f77074:	mov    %eax,%r10d
 1f77077:	sub    %r8d,%r10d
 1f7707a:	add    %r15,%r13
 1f7707d:	mov    %r10,%r8
 1f77080:	shl    $0x6,%r8
 1f77084:	mov    0x38(%rdx,%r8,1),%r8
 1f77089:	cmp    0x0(%r13,%r10,8),%r8
 1f7708e:	jne    1f77110 <node_facts_reader_flush+0x10a0>
 1f77094:	movzwl -0x4(%rbp,%r12,2),%r8d
 1f7709a:	mov    0x2b8(%r14),%r13
 1f770a1:	mov    %eax,%r10d
 1f770a4:	sub    %r8d,%r10d
 1f770a7:	add    %r15,%r13
 1f770aa:	mov    %r10,%r8
 1f770ad:	shl    $0x6,%r8
 1f770b1:	mov    0x38(%rdx,%r8,1),%r8
 1f770b6:	cmp    0x0(%r13,%r10,8),%r8
 1f770bb:	jne    1f77110 <node_facts_reader_flush+0x10a0>
 1f770bd:	movzwl -0x2(%rbp,%r12,2),%r8d
 1f770c3:	mov    0x2b8(%r14),%r13
 1f770ca:	mov    %eax,%r10d
 1f770cd:	sub    %r8d,%r10d
 1f770d0:	add    %r15,%r13
 1f770d3:	mov    %r10,%r8
 1f770d6:	shl    $0x6,%r8
 1f770da:	mov    0x38(%rdx,%r8,1),%r8
 1f770df:	cmp    0x0(%r13,%r10,8),%r8
 1f770e4:	jne    1f77110 <node_facts_reader_flush+0x10a0>
 1f770e6:	movzwl 0x0(%rbp,%r12,2),%r8d
 1f770ec:	add    0x2b8(%r14),%r15
 1f770f3:	mov    %eax,%r10d
 1f770f6:	sub    %r8d,%r10d
 1f770f9:	mov    %r10,%r8
 1f770fc:	shl    $0x6,%r8
 1f77100:	mov    0x38(%rdx,%r8,1),%r8
 1f77105:	cmp    (%r15,%r10,8),%r8
 1f77109:	sete   %r15b
 1f7710d:	jmp    1f77113 <node_facts_reader_flush+0x10a3>
 1f7710f:	nop
 1f77110:	xor    %r15d,%r15d
 1f77113:	mov    %r9,%r8
 1f77116:	mov    %rdi,%r9
 1f77119:	mov    0x8(%rsp),%edi
 1f7711d:	mov    (%rsp),%r10
 1f77121:	mov    0x10(%rsp),%r13
 1f77126:	add    $0x8,%r12
 1f7712a:	cmp    %r12,%r13
 1f7712d:	jne    1f76fa0 <node_facts_reader_flush+0xf30>
 1f77133:	test   %r11,%r11
 1f77136:	je     1f771a0 <node_facts_reader_flush+0x1130>
 1f77138:	mov    0x30(%rsp),%r13
 1f7713d:	add    %r13,%r13
 1f77140:	lea    0x0(%r13,%r12,2),%r12
 1f77145:	add    %r12,%r10
 1f77148:	xor    %r12d,%r12d
 1f7714b:	jmp    1f77187 <node_facts_reader_flush+0x1117>
 1f7714d:	nopl   (%rax)
 1f77150:	movzwl (%r10,%r12,2),%ebp
 1f77155:	mov    %eax,%r15d
 1f77158:	sub    %ebp,%r15d
 1f7715b:	lea    0x0(,%rbx,8),%rbp
 1f77163:	add    0x2b8(%r14),%rbp
 1f7716a:	mov    %r15,%r13
 1f7716d:	shl    $0x6,%r13
 1f77171:	mov    0x38(%rdx,%r13,1),%r13
 1f77176:	cmp    0x0(%rbp,%r15,8),%r13
 1f7717b:	sete   %r15b
 1f7717f:	inc    %r12
 1f77182:	cmp    %r12,%r11
 1f77185:	je     1f771a0 <node_facts_reader_flush+0x1130>
 1f77187:	cmp    $0x1,%r15b
 1f7718b:	je     1f77150 <node_facts_reader_flush+0x10e0>
 1f7718d:	xor    %r15d,%r15d
 1f77190:	inc    %r12
 1f77193:	cmp    %r12,%r11
 1f77196:	jne    1f77187 <node_facts_reader_flush+0x1117>
 1f77198:	nopl   0x0(%rax,%rax,1)
 1f771a0:	mov    0x20(%rsp),%r12
 1f771a5:	mov    0x40(%rsp),%r13
 1f771aa:	mov    0x18(%rsp),%rbp
 1f771af:	and    %dil,%sil
 1f771b2:	cmp    $0x1,%sil
 1f771b6:	jne    1f771c6 <node_facts_reader_flush+0x1156>
 1f771b8:	cmp    %r8,%r9
 1f771bb:	jne    1f771c6 <node_facts_reader_flush+0x1156>
 1f771bd:	test   %r15b,%r15b
 1f771c0:	jne    1f76d90 <node_facts_reader_flush+0xd20>
 1f771c6:	vmovdqu 0x8d0(%r12),%xmm0
 1f771d0:	vpsubq %xmm1,%xmm0,%xmm0
 1f771d4:	vmovdqu %xmm0,0x8d0(%r12)
 1f771de:	mov    (%r14),%rdx
 1f771e1:	mov    0x238(%r14),%rsi
 1f771e8:	mov    (%rsi,%rcx,4),%edi
 1f771eb:	mov    0x10(%rdx),%rdx
 1f771ef:	mov    $0xffffffff,%esi
 1f771f4:	cmp    0xec(%rdx),%edi
 1f771fa:	jae    1f77203 <node_facts_reader_flush+0x1193>
 1f771fc:	mov    0x28(%rdx),%rdx
 1f77200:	mov    (%rdx,%rdi,4),%esi
 1f77203:	mov    0x938(%r14),%rdx
 1f7720a:	mov    0x11b8(%rdx),%edi
 1f77210:	cmp    $0xf,%rdi
 1f77214:	ja     1f76d90 <node_facts_reader_flush+0xd20>
 1f7721a:	mov    %esi,0x1158(%rdx,%rdi,4)
 1f77221:	mov    0x1f0(%r14),%rsi
 1f77228:	movzbl (%rsi,%rcx,1),%ecx
 1f7722c:	mov    0x11b8(%rdx),%esi
 1f77232:	mov    %cl,0x1198(%rdx,%rsi,1)
 1f77239:	mov    0x11b8(%rdx),%ecx
 1f7723f:	movb   $0x1,0x11a8(%rdx,%rcx,1)
 1f77247:	incl   0x11b8(%rdx)
 1f7724d:	jmp    1f76d90 <node_facts_reader_flush+0xd20>
 1f77252:	testb  $0x1,0xb28(%r14)
 1f7725a:	jne    1f775fa <node_facts_reader_flush+0x158a>
 1f77260:	xor    %esi,%esi
 1f77262:	jmp    1f77367 <node_facts_reader_flush+0x12f7>
 1f77267:	mov    0x290(%r14),%rax
 1f7726e:	movzwl (%rax,%rcx,2),%eax
 1f77272:	mov    0x270(%r14),%r9
 1f77279:	mov    0x2a0(%r14),%r11
 1f77280:	mov    0x2a8(%r14),%rbx
 1f77287:	shl    $0x6,%rdx
 1f7728b:	mov    0x298(%r14),%r8
 1f77292:	mov    0x280(%r14),%r10
 1f77299:	mov    0x2b0(%r14),%r15
 1f772a0:	add    %rdx,%r12
 1f772a3:	mov    0x268(%r14),%rdx
 1f772aa:	mov    (%r9,%rcx,4),%ebp
 1f772ae:	mov    0x278(%r14),%r9
 1f772b5:	vmovq  (%rbx,%rcx,8),%xmm0
 1f772ba:	vmovq  (%r11,%rcx,8),%xmm1
 1f772c0:	mov    (%r8,%rcx,4),%r8d
 1f772c4:	mov    (%r10,%rcx,8),%r10
 1f772c8:	mov    (%r15,%rcx,8),%r15
 1f772cc:	mov    (%rdx,%rcx,4),%edx
 1f772cf:	mov    (%r9,%rcx,4),%r9d
 1f772d3:	movabs $0x2525252525252525,%rcx
 1f772dd:	mov    %edx,(%r12)
 1f772e1:	mov    %r8d,0x4(%r12)
 1f772e6:	mov    %ebp,0x8(%r12)
 1f772eb:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f772ef:	mov    %r9d,0xc(%r12)
 1f772f4:	mov    %r10,0x10(%r12)
 1f772f9:	mov    %dil,0x18(%r12)
 1f772fe:	movb   $0x1,0x19(%r12)
 1f77304:	mov    %ax,0x1a(%r12)
 1f7730a:	movl   $0x0,0x1c(%r12)
 1f77313:	vmovdqu %xmm0,0x20(%r12)
 1f7731a:	mov    %r15,0x30(%r12)
 1f7731f:	mov    %rcx,0x38(%r12)
 1f77324:	rdtsc
 1f77326:	lea    0x1(%rsi),%rbx
 1f7732a:	mov    %r14,%rdi
 1f7732d:	xor    %ecx,%ecx
 1f7732f:	mov    %rdx,%r12
 1f77332:	shl    $0x20,%r12
 1f77336:	xor    %edx,%edx
 1f77338:	or     %rax,%r12
 1f7733b:	call   1f7ae80 <node_facts_window>
 1f77340:	rdtsc
 1f77342:	mov    %rbx,%rsi
 1f77345:	shl    $0x20,%rdx
 1f77349:	or     %rax,%rdx
 1f7734c:	sub    %r12,%rdx
 1f7734f:	mov    0x20(%rsp),%r12
 1f77354:	add    %rdx,0x8f8(%r12)
 1f7735c:	cmp    0x28(%rsp),%rbx
 1f77361:	je     1f77a0a <node_facts_reader_flush+0x199a>
 1f77367:	mov    0x248(%r14),%rax
 1f7736e:	mov    (%rax,%rsi,4),%ecx
 1f77371:	mov    0x4(%rax,%rsi,4),%eax
 1f77375:	cmp    %ecx,%eax
 1f77377:	je     1f77324 <node_facts_reader_flush+0x12b4>
 1f77379:	mov    0x2c0(%r14),%r12
 1f77380:	sub    %ecx,%eax
 1f77382:	cmp    $0x1,%eax
 1f77385:	jne    1f77390 <node_facts_reader_flush+0x1320>
 1f77387:	xor    %edx,%edx
 1f77389:	jmp    1f775d9 <node_facts_reader_flush+0x1569>
 1f7738e:	xchg   %ax,%ax
 1f77390:	lea    0x0(,%rcx,8),%r9
 1f77398:	lea    0x0(,%rcx,4),%r11
 1f773a0:	mov    %rsi,0x18(%rsp)
 1f773a5:	mov    %eax,%esi
 1f773a7:	and    $0xfffffffe,%esi
 1f773aa:	mov    %rax,(%rsp)
 1f773ae:	mov    %r12,0x8(%rsp)
 1f773b3:	mov    %r12,%r15
 1f773b6:	xor    %edx,%edx
 1f773b8:	jmp    1f7745b <node_facts_reader_flush+0x13eb>
 1f773bd:	nopl   (%rax)
 1f773c0:	mov    0x290(%r14),%r8
 1f773c7:	add    %rcx,%r8
 1f773ca:	add    %rcx,%r8
 1f773cd:	movzwl 0x2(%r8,%rdx,2),%ebx
 1f773d3:	mov    0x2a8(%r14),%r8
 1f773da:	add    %r9,%r8
 1f773dd:	vmovq  0x8(%r8,%rdx,8),%xmm0
 1f773e4:	mov    0x2a0(%r14),%r8
 1f773eb:	add    %r9,%r8
 1f773ee:	vmovq  0x8(%r8,%rdx,8),%xmm1
 1f773f5:	mov    0x2b0(%r14),%r8
 1f773fc:	add    %r9,%r8
 1f773ff:	mov    0x8(%r8,%rdx,8),%r8
 1f77404:	mov    %r12d,0x40(%r15)
 1f77408:	mov    %r13d,0x44(%r15)
 1f7740c:	mov    %edi,0x48(%r15)
 1f77410:	mov    %r10d,0x4c(%r15)
 1f77414:	mov    %rax,0x50(%r15)
 1f77418:	movabs $0x2525252525252525,%rax
 1f77422:	mov    %bpl,0x58(%r15)
 1f77426:	movb   $0x1,0x59(%r15)
 1f7742b:	mov    %bx,0x5a(%r15)
 1f77430:	movl   $0x0,0x5c(%r15)
 1f77438:	add    $0x2,%rdx
 1f7743c:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f77440:	vmovdqu %xmm0,0x60(%r15)
 1f77446:	mov    %r8,0x70(%r15)
 1f7744a:	mov    %rax,0x78(%r15)
 1f7744e:	sub    $0xffffffffffffff80,%r15
 1f77452:	cmp    %rdx,%rsi
 1f77455:	je     1f775c0 <node_facts_reader_flush+0x1550>
 1f7745b:	mov    0x288(%r14),%rax
 1f77462:	mov    0x280(%r14),%r8
 1f77469:	add    %rcx,%rax
 1f7746c:	add    %r9,%r8
 1f7746f:	movzbl (%rdx,%rax,1),%ebp
 1f77473:	mov    0x268(%r14),%rax
 1f7747a:	add    %r11,%rax
 1f7747d:	mov    %ebp,%ebx
 1f7747f:	mov    (%rax,%rdx,4),%r12d
 1f77483:	mov    0x298(%r14),%rax
 1f7748a:	and    $0x60,%bl
 1f7748d:	add    %r11,%rax
 1f77490:	mov    (%rax,%rdx,4),%r13d
 1f77494:	mov    0x270(%r14),%rax
 1f7749b:	add    %r11,%rax
 1f7749e:	mov    (%rax,%rdx,4),%edi
 1f774a1:	mov    0x278(%r14),%rax
 1f774a8:	add    %r11,%rax
 1f774ab:	mov    (%rax,%rdx,4),%r10d
 1f774af:	mov    (%r8,%rdx,8),%rax
 1f774b3:	cmp    $0x40,%bl
 1f774b6:	jne    1f774d0 <node_facts_reader_flush+0x1460>
 1f774b8:	mov    0x290(%r14),%rbx
 1f774bf:	add    %rcx,%rbx
 1f774c2:	add    %rcx,%rbx
 1f774c5:	movzwl (%rbx,%rdx,2),%ebx
 1f774c9:	jmp    1f774d2 <node_facts_reader_flush+0x1462>
 1f774cb:	nopl   0x0(%rax,%rax,1)
 1f774d0:	xor    %ebx,%ebx
 1f774d2:	mov    0x2a8(%r14),%r8
 1f774d9:	add    %r9,%r8
 1f774dc:	vmovsd (%r8,%rdx,8),%xmm0
 1f774e2:	mov    0x2a0(%r14),%r8
 1f774e9:	add    %r9,%r8
 1f774ec:	vmovsd (%r8,%rdx,8),%xmm1
 1f774f2:	mov    0x2b0(%r14),%r8
 1f774f9:	add    %r9,%r8
 1f774fc:	mov    (%r8,%rdx,8),%r8
 1f77500:	mov    %r12d,(%r15)
 1f77503:	mov    %r13d,0x4(%r15)
 1f77507:	mov    %edi,0x8(%r15)
 1f7750b:	mov    %r10d,0xc(%r15)
 1f7750f:	mov    %rax,0x10(%r15)
 1f77513:	movabs $0x2525252525252525,%rax
 1f7751d:	mov    %bpl,0x18(%r15)
 1f77521:	movb   $0x1,0x19(%r15)
 1f77526:	mov    %bx,0x1a(%r15)
 1f7752b:	movl   $0x0,0x1c(%r15)
 1f77533:	vmovlhps %xmm0,%xmm1,%xmm0
 1f77537:	vmovups %xmm0,0x20(%r15)
 1f7753d:	mov    %r8,0x30(%r15)
 1f77541:	mov    %rax,0x38(%r15)
 1f77545:	mov    0x288(%r14),%rax
 1f7754c:	mov    0x280(%r14),%rbx
 1f77553:	add    %rcx,%rax
 1f77556:	add    %r9,%rbx
 1f77559:	movzbl 0x1(%rdx,%rax,1),%ebp
 1f7755e:	mov    0x268(%r14),%rax
 1f77565:	add    %r11,%rax
 1f77568:	mov    %ebp,%r8d
 1f7756b:	mov    0x4(%rax,%rdx,4),%r12d
 1f77570:	mov    0x298(%r14),%rax
 1f77577:	and    $0x60,%r8b
 1f7757b:	add    %r11,%rax
 1f7757e:	mov    0x4(%rax,%rdx,4),%r13d
 1f77583:	mov    0x270(%r14),%rax
 1f7758a:	add    %r11,%rax
 1f7758d:	mov    0x4(%rax,%rdx,4),%edi
 1f77591:	mov    0x278(%r14),%rax
 1f77598:	add    %r11,%rax
 1f7759b:	mov    0x4(%rax,%rdx,4),%r10d
 1f775a0:	mov    0x8(%rbx,%rdx,8),%rax
 1f775a5:	cmp    $0x40,%r8b
 1f775a9:	je     1f773c0 <node_facts_reader_flush+0x1350>
 1f775af:	xor    %ebx,%ebx
 1f775b1:	jmp    1f773d3 <node_facts_reader_flush+0x1363>
 1f775b6:	cs nopw 0x0(%rax,%rax,1)
 1f775c0:	testb  $0x1,(%rsp)
 1f775c4:	mov    0x40(%rsp),%r13
 1f775c9:	mov    0x18(%rsp),%rsi
 1f775ce:	mov    0x8(%rsp),%r12
 1f775d3:	je     1f77324 <node_facts_reader_flush+0x12b4>
 1f775d9:	mov    0x288(%r14),%rax
 1f775e0:	add    %rdx,%rcx
 1f775e3:	movzbl (%rax,%rcx,1),%edi
 1f775e7:	mov    %edi,%eax
 1f775e9:	and    $0x60,%al
 1f775eb:	cmp    $0x40,%al
 1f775ed:	je     1f77267 <node_facts_reader_flush+0x11f7>
 1f775f3:	xor    %eax,%eax
 1f775f5:	jmp    1f77272 <node_facts_reader_flush+0x1202>
 1f775fa:	cmpb   $0x1,0xb30(%r14)
 1f77602:	jne    1f7767d <node_facts_reader_flush+0x160d>
 1f77608:	rdtsc
 1f7760a:	mov    %rdx,%r12
 1f7760d:	shl    $0x20,%r12
 1f77611:	or     %rax,%r12
 1f77614:	cmpl   $0x0,0xa88(%r14)
 1f7761c:	je     1f77655 <node_facts_reader_flush+0x15e5>
 1f7761e:	xor    %ebx,%ebx
 1f77620:	mov    0xa40(%r14),%rax
 1f77627:	mov    0xa48(%r14),%rcx
 1f7762e:	mov    %r13,%rdi
 1f77631:	mov    (%rax,%rbx,4),%esi
 1f77634:	mov    0xa50(%r14),%rax
 1f7763b:	mov    (%rcx,%rbx,4),%edx
 1f7763e:	mov    (%rax,%rbx,4),%ecx
 1f77641:	call   1f52a90 <node_machine_type>
 1f77646:	mov    0xa88(%r14),%eax
 1f7764d:	inc    %rbx
 1f77650:	cmp    %rax,%rbx
 1f77653:	jb     1f77620 <node_facts_reader_flush+0x15b0>
 1f77655:	rdtsc
 1f77657:	shl    $0x20,%rdx
 1f7765b:	or     %rax,%rdx
 1f7765e:	sub    %r12,%rdx
 1f77661:	mov    0x20(%rsp),%r12
 1f77666:	add    %rdx,0x900(%r12)
 1f7766e:	mov    0x250(%r14),%eax
 1f77675:	add    %rax,0x908(%r12)
 1f7767d:	xor    %esi,%esi
 1f7767f:	jmp    1f77774 <node_facts_reader_flush+0x1704>
 1f77684:	mov    0x290(%r14),%rax
 1f7768b:	movzwl (%rax,%rcx,2),%eax
 1f7768f:	mov    0x270(%r14),%r9
 1f77696:	mov    0x2a0(%r14),%r11
 1f7769d:	mov    0x2a8(%r14),%rbx
 1f776a4:	shl    $0x6,%rdx
 1f776a8:	mov    0x298(%r14),%r8
 1f776af:	mov    0x280(%r14),%r10
 1f776b6:	mov    0x2b0(%r14),%r15
 1f776bd:	add    %rdx,%r13
 1f776c0:	mov    0x268(%r14),%rdx
 1f776c7:	mov    (%r9,%rcx,4),%ebp
 1f776cb:	mov    0x278(%r14),%r9
 1f776d2:	vmovq  (%rbx,%rcx,8),%xmm0
 1f776d7:	vmovq  (%r11,%rcx,8),%xmm1
 1f776dd:	mov    (%r8,%rcx,4),%r8d
 1f776e1:	mov    (%r10,%rcx,8),%r10
 1f776e5:	mov    (%r15,%rcx,8),%r15
 1f776e9:	mov    (%rdx,%rcx,4),%edx
 1f776ec:	mov    (%r9,%rcx,4),%r9d
 1f776f0:	movabs $0x2525252525252525,%rcx
 1f776fa:	mov    %edx,0x0(%r13)
 1f776fe:	mov    %r8d,0x4(%r13)
 1f77702:	mov    %ebp,0x8(%r13)
 1f77706:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f7770a:	mov    %r9d,0xc(%r13)
 1f7770e:	mov    %r10,0x10(%r13)
 1f77712:	mov    %dil,0x18(%r13)
 1f77716:	movb   $0x1,0x19(%r13)
 1f7771b:	mov    %ax,0x1a(%r13)
 1f77720:	movl   $0x0,0x1c(%r13)
 1f77728:	vmovdqu %xmm0,0x20(%r13)
 1f7772e:	mov    %r15,0x30(%r13)
 1f77732:	mov    %rcx,0x38(%r13)
 1f77736:	rdtsc
 1f77738:	lea    0x1(%rsi),%rbx
 1f7773c:	mov    %r14,%rdi
 1f7773f:	xor    %ecx,%ecx
 1f77741:	mov    %rdx,%r15
 1f77744:	shl    $0x20,%r15
 1f77748:	xor    %edx,%edx
 1f7774a:	or     %rax,%r15
 1f7774d:	call   1f7ae80 <node_facts_window>
 1f77752:	rdtsc
 1f77754:	mov    %rbx,%rsi
 1f77757:	shl    $0x20,%rdx
 1f7775b:	or     %rax,%rdx
 1f7775e:	sub    %r15,%rdx
 1f77761:	add    %rdx,0x8f8(%r12)
 1f77769:	cmp    0x28(%rsp),%rbx
 1f7776e:	je     1f77a8d <node_facts_reader_flush+0x1a1d>
 1f77774:	mov    0x248(%r14),%rax
 1f7777b:	mov    (%rax,%rsi,4),%ecx
 1f7777e:	mov    0x4(%rax,%rsi,4),%eax
 1f77782:	cmp    %ecx,%eax
 1f77784:	je     1f77736 <node_facts_reader_flush+0x16c6>
 1f77786:	mov    0x2c0(%r14),%r13
 1f7778d:	sub    %ecx,%eax
 1f7778f:	cmp    $0x1,%eax
 1f77792:	jne    1f777a0 <node_facts_reader_flush+0x1730>
 1f77794:	xor    %edx,%edx
 1f77796:	jmp    1f779e9 <node_facts_reader_flush+0x1979>
 1f7779b:	nopl   0x0(%rax,%rax,1)
 1f777a0:	lea    0x0(,%rcx,8),%r9
 1f777a8:	lea    0x0(,%rcx,4),%r11
 1f777b0:	mov    %rsi,0x18(%rsp)
 1f777b5:	mov    %eax,%esi
 1f777b7:	and    $0xfffffffe,%esi
 1f777ba:	mov    %rax,(%rsp)
 1f777be:	mov    %r13,0x8(%rsp)
 1f777c3:	mov    %r13,%r15
 1f777c6:	xor    %edx,%edx
 1f777c8:	jmp    1f7786b <node_facts_reader_flush+0x17fb>
 1f777cd:	nopl   (%rax)
 1f777d0:	mov    0x290(%r14),%r8
 1f777d7:	add    %rcx,%r8
 1f777da:	add    %rcx,%r8
 1f777dd:	movzwl 0x2(%r8,%rdx,2),%ebx
 1f777e3:	mov    0x2a8(%r14),%r8
 1f777ea:	add    %r9,%r8
 1f777ed:	vmovq  0x8(%r8,%rdx,8),%xmm0
 1f777f4:	mov    0x2a0(%r14),%r8
 1f777fb:	add    %r9,%r8
 1f777fe:	vmovq  0x8(%r8,%rdx,8),%xmm1
 1f77805:	mov    0x2b0(%r14),%r8
 1f7780c:	add    %r9,%r8
 1f7780f:	mov    0x8(%r8,%rdx,8),%r8
 1f77814:	mov    %r12d,0x40(%r15)
 1f77818:	mov    %r13d,0x44(%r15)
 1f7781c:	mov    %edi,0x48(%r15)
 1f77820:	mov    %r10d,0x4c(%r15)
 1f77824:	mov    %rax,0x50(%r15)
 1f77828:	movabs $0x2525252525252525,%rax
 1f77832:	mov    %bpl,0x58(%r15)
 1f77836:	movb   $0x1,0x59(%r15)
 1f7783b:	mov    %bx,0x5a(%r15)
 1f77840:	movl   $0x0,0x5c(%r15)
 1f77848:	add    $0x2,%rdx
 1f7784c:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f77850:	vmovdqu %xmm0,0x60(%r15)
 1f77856:	mov    %r8,0x70(%r15)
 1f7785a:	mov    %rax,0x78(%r15)
 1f7785e:	sub    $0xffffffffffffff80,%r15
 1f77862:	cmp    %rdx,%rsi
 1f77865:	je     1f779d0 <node_facts_reader_flush+0x1960>
 1f7786b:	mov    0x288(%r14),%rax
 1f77872:	mov    0x280(%r14),%r8
 1f77879:	add    %rcx,%rax
 1f7787c:	add    %r9,%r8
 1f7787f:	movzbl (%rdx,%rax,1),%ebp
 1f77883:	mov    0x268(%r14),%rax
 1f7788a:	add    %r11,%rax
 1f7788d:	mov    %ebp,%ebx
 1f7788f:	mov    (%rax,%rdx,4),%r12d
 1f77893:	mov    0x298(%r14),%rax
 1f7789a:	and    $0x60,%bl
 1f7789d:	add    %r11,%rax
 1f778a0:	mov    (%rax,%rdx,4),%r13d
 1f778a4:	mov    0x270(%r14),%rax
 1f778ab:	add    %r11,%rax
 1f778ae:	mov    (%rax,%rdx,4),%edi
 1f778b1:	mov    0x278(%r14),%rax
 1f778b8:	add    %r11,%rax
 1f778bb:	mov    (%rax,%rdx,4),%r10d
 1f778bf:	mov    (%r8,%rdx,8),%rax
 1f778c3:	cmp    $0x40,%bl
 1f778c6:	jne    1f778e0 <node_facts_reader_flush+0x1870>
 1f778c8:	mov    0x290(%r14),%rbx
 1f778cf:	add    %rcx,%rbx
 1f778d2:	add    %rcx,%rbx
 1f778d5:	movzwl (%rbx,%rdx,2),%ebx
 1f778d9:	jmp    1f778e2 <node_facts_reader_flush+0x1872>
 1f778db:	nopl   0x0(%rax,%rax,1)
 1f778e0:	xor    %ebx,%ebx
 1f778e2:	mov    0x2a8(%r14),%r8
 1f778e9:	add    %r9,%r8
 1f778ec:	vmovsd (%r8,%rdx,8),%xmm0
 1f778f2:	mov    0x2a0(%r14),%r8
 1f778f9:	add    %r9,%r8
 1f778fc:	vmovsd (%r8,%rdx,8),%xmm1
 1f77902:	mov    0x2b0(%r14),%r8
 1f77909:	add    %r9,%r8
 1f7790c:	mov    (%r8,%rdx,8),%r8
 1f77910:	mov    %r12d,(%r15)
 1f77913:	mov    %r13d,0x4(%r15)
 1f77917:	mov    %edi,0x8(%r15)
 1f7791b:	mov    %r10d,0xc(%r15)
 1f7791f:	mov    %rax,0x10(%r15)
 1f77923:	movabs $0x2525252525252525,%rax
 1f7792d:	mov    %bpl,0x18(%r15)
 1f77931:	movb   $0x1,0x19(%r15)
 1f77936:	mov    %bx,0x1a(%r15)
 1f7793b:	movl   $0x0,0x1c(%r15)
 1f77943:	vmovlhps %xmm0,%xmm1,%xmm0
 1f77947:	vmovups %xmm0,0x20(%r15)
 1f7794d:	mov    %r8,0x30(%r15)
 1f77951:	mov    %rax,0x38(%r15)
 1f77955:	mov    0x288(%r14),%rax
 1f7795c:	mov    0x280(%r14),%rbx
 1f77963:	add    %rcx,%rax
 1f77966:	add    %r9,%rbx
 1f77969:	movzbl 0x1(%rdx,%rax,1),%ebp
 1f7796e:	mov    0x268(%r14),%rax
 1f77975:	add    %r11,%rax
 1f77978:	mov    %ebp,%r8d
 1f7797b:	mov    0x4(%rax,%rdx,4),%r12d
 1f77980:	mov    0x298(%r14),%rax
 1f77987:	and    $0x60,%r8b
 1f7798b:	add    %r11,%rax
 1f7798e:	mov    0x4(%rax,%rdx,4),%r13d
 1f77993:	mov    0x270(%r14),%rax
 1f7799a:	add    %r11,%rax
 1f7799d:	mov    0x4(%rax,%rdx,4),%edi
 1f779a1:	mov    0x278(%r14),%rax
 1f779a8:	add    %r11,%rax
 1f779ab:	mov    0x4(%rax,%rdx,4),%r10d
 1f779b0:	mov    0x8(%rbx,%rdx,8),%rax
 1f779b5:	cmp    $0x40,%r8b
 1f779b9:	je     1f777d0 <node_facts_reader_flush+0x1760>
 1f779bf:	xor    %ebx,%ebx
 1f779c1:	jmp    1f777e3 <node_facts_reader_flush+0x1773>
 1f779c6:	cs nopw 0x0(%rax,%rax,1)
 1f779d0:	testb  $0x1,(%rsp)
 1f779d4:	mov    0x20(%rsp),%r12
 1f779d9:	mov    0x18(%rsp),%rsi
 1f779de:	mov    0x8(%rsp),%r13
 1f779e3:	je     1f77736 <node_facts_reader_flush+0x16c6>
 1f779e9:	mov    0x288(%r14),%rax
 1f779f0:	add    %rdx,%rcx
 1f779f3:	movzbl (%rax,%rcx,1),%edi
 1f779f7:	mov    %edi,%eax
 1f779f9:	and    $0x60,%al
 1f779fb:	cmp    $0x40,%al
 1f779fd:	je     1f77684 <node_facts_reader_flush+0x1614>
 1f77a03:	xor    %eax,%eax
 1f77a05:	jmp    1f7768f <node_facts_reader_flush+0x161f>
 1f77a0a:	cmpb   $0x1,0xb30(%r14)
 1f77a12:	jne    1f77a8d <node_facts_reader_flush+0x1a1d>
 1f77a18:	rdtsc
 1f77a1a:	mov    %rdx,%r12
 1f77a1d:	shl    $0x20,%r12
 1f77a21:	or     %rax,%r12
 1f77a24:	cmpl   $0x0,0xa88(%r14)
 1f77a2c:	je     1f77a65 <node_facts_reader_flush+0x19f5>
 1f77a2e:	xor    %ebx,%ebx
 1f77a30:	mov    0xa40(%r14),%rax
 1f77a37:	mov    0xa48(%r14),%rcx
 1f77a3e:	mov    %r13,%rdi
 1f77a41:	mov    (%rax,%rbx,4),%esi
 1f77a44:	mov    0xa50(%r14),%rax
 1f77a4b:	mov    (%rcx,%rbx,4),%edx
 1f77a4e:	mov    (%rax,%rbx,4),%ecx
 1f77a51:	call   1f52a90 <node_machine_type>
 1f77a56:	mov    0xa88(%r14),%eax
 1f77a5d:	inc    %rbx
 1f77a60:	cmp    %rax,%rbx
 1f77a63:	jb     1f77a30 <node_facts_reader_flush+0x19c0>
 1f77a65:	rdtsc
 1f77a67:	shl    $0x20,%rdx
 1f77a6b:	or     %rax,%rdx
 1f77a6e:	sub    %r12,%rdx
 1f77a71:	mov    0x20(%rsp),%r12
 1f77a76:	add    %rdx,0x900(%r12)
 1f77a7e:	mov    0x250(%r14),%eax
 1f77a85:	add    %rax,0x908(%r12)
 1f77a8d:	mov    0xa88(%r14),%eax
 1f77a94:	vmovd  0x28(%rsp),%xmm0
 1f77a9a:	mov    0x48(%rsp),%r15
 1f77a9f:	add    %rax,0x888(%r12)
 1f77aa7:	vmovd  0x250(%r14),%xmm1
 1f77ab0:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f77ab4:	vpaddq 0x890(%r12),%xmm0,%xmm0
 1f77abe:	vmovdqu %xmm0,0x890(%r12)
 1f77ac8:	cmpb   $0x1,0x9a8(%r14)
 1f77ad0:	jne    1f77add <node_facts_reader_flush+0x1a6d>
 1f77ad2:	mov    %r14,%rdi
 1f77ad5:	mov    %r15,%rsi
 1f77ad8:	call   1f7c550 <node_facts_window_run>
 1f77add:	mov    0x60(%r14),%eax
 1f77ae1:	mov    %rax,0x918(%r12)
 1f77ae9:	mov    0x918(%r14),%rax
 1f77af0:	mov    %rax,0x920(%r12)
 1f77af8:	mov    0x68(%r14),%eax
 1f77afc:	sub    0x70(%r14),%eax
 1f77b00:	mov    %rax,0x928(%r12)
 1f77b08:	mov    0x920(%r14),%rax
 1f77b0f:	mov    %rax,0x930(%r12)
 1f77b17:	mov    0x8f8(%r14),%rax
 1f77b1e:	mov    %rax,0x938(%r12)
 1f77b26:	mov    0x78(%r14),%eax
 1f77b2a:	mov    %rax,0x940(%r12)
 1f77b32:	mov    0xa8(%r14),%eax
 1f77b39:	mov    %rax,0x948(%r12)
 1f77b41:	mov    0xd0(%r14),%rax
 1f77b48:	mov    %rax,0xa18(%r12)
 1f77b50:	mov    0xd8(%r14),%rax
 1f77b57:	mov    %rax,0xa20(%r12)
 1f77b5f:	movl   $0x0,0x250(%r14)
 1f77b6a:	movq   $0x0,0x258(%r14)
 1f77b75:	movl   $0xffffffff,0x260(%r14)
 1f77b80:	mov    0x248(%r14),%rax
 1f77b87:	movl   $0x0,(%rax)
 1f77b8d:	movzbl 0x9a8(%r14),%eax
 1f77b95:	shl    $0xc,%eax
 1f77b98:	mov    %eax,0x74(%r14)
 1f77b9c:	movl   $0x0,0x9a0(%r14)
 1f77ba7:	movl   $0x0,0xa88(%r14)
 1f77bb2:	incq   0xb28(%r14)
 1f77bb9:	cmpq   $0x0,0xc18(%r14)
 1f77bc1:	je     1f77c0d <node_facts_reader_flush+0x1b9d>
 1f77bc3:	rdtsc
 1f77bc5:	mov    %rdx,%rcx
 1f77bc8:	shl    $0x20,%rcx
 1f77bcc:	or     %rax,%rcx
 1f77bcf:	cmpl   $0x0,0x8(%r15)
 1f77bd4:	je     1f77bf9 <node_facts_reader_flush+0x1b89>
 1f77bd6:	xor    %eax,%eax
 1f77bd8:	vpxor  %xmm0,%xmm0,%xmm0
 1f77bdc:	nopl   0x0(%rax)
 1f77be0:	mov    0xc68(%r14),%rdx
 1f77be7:	mov    %eax,%esi
 1f77be9:	add    $0x40,%eax
 1f77bec:	vmovdqu64 %zmm0,(%rdx,%rsi,1)
 1f77bf3:	cmp    0x8(%r15),%eax
 1f77bf7:	jb     1f77be0 <node_facts_reader_flush+0x1b70>
 1f77bf9:	rdtsc
 1f77bfb:	shl    $0x20,%rdx
 1f77bff:	or     %rax,%rdx
 1f77c02:	sub    %rcx,%rdx
 1f77c05:	add    %rdx,0xca0(%r12)
 1f77c0d:	add    $0x58,%rsp
 1f77c11:	pop    %rbx
 1f77c12:	pop    %r12
 1f77c14:	pop    %r13
 1f77c16:	pop    %r14
 1f77c18:	pop    %r15
 1f77c1a:	pop    %rbp
 1f77c1b:	vzeroupper
 1f77c1e:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
