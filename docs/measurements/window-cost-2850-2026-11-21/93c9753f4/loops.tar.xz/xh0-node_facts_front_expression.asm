
results/xh0/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f77c20 <node_facts_front_expression>:
 1f77c20:	push   %rbp
 1f77c21:	push   %r15
 1f77c23:	push   %r14
 1f77c25:	push   %r13
 1f77c27:	push   %r12
 1f77c29:	push   %rbx
 1f77c2a:	sub    $0xb8,%rsp
 1f77c31:	mov    %r8d,%ebp
 1f77c34:	mov    %rdx,0x78(%rsp)
 1f77c39:	mov    %rsi,%r10
 1f77c3c:	mov    %rdi,%r12
 1f77c3f:	xor    %eax,%eax
 1f77c41:	cmp    %r8d,%r9d
 1f77c44:	jae    1f77c51 <node_facts_front_expression+0x31>
 1f77c46:	mov    %r9d,%eax
 1f77c49:	mov    0x651b8(%r10,%rax,4),%eax
 1f77c51:	cmpb   $0x1,0x69238(%r10)
 1f77c59:	jne    1f790a7 <node_facts_front_expression+0x1487>
 1f77c5f:	cmp    %ebp,%r9d
 1f77c62:	mov    %ebp,%edx
 1f77c64:	cmovb  %r9d,%edx
 1f77c68:	cmpb   $0xfe,0x6a4d4(%r10,%rdx,1)
 1f77c71:	setne  %dl
 1f77c74:	test   %eax,%eax
 1f77c76:	je     1f790bd <node_facts_front_expression+0x149d>
 1f77c7c:	mov    %ebp,%esi
 1f77c7e:	xor    %edi,%edi
 1f77c80:	cmpb   $0x23,0x2c(%r10,%rsi,1)
 1f77c86:	setne  %dil
 1f77c8a:	add    %eax,%edi
 1f77c8c:	cmp    %edi,%ecx
 1f77c8e:	sete   %sil
 1f77c92:	inc    %r9d
 1f77c95:	sub    %eax,%r9d
 1f77c98:	setae  %dil
 1f77c9c:	and    %dl,%dil
 1f77c9f:	and    %sil,%dil
 1f77ca2:	mov    %edi,%edx
 1f77ca4:	xor    $0x1,%dl
 1f77ca7:	movzbl %dl,%esi
 1f77caa:	xor    %edx,%edx
 1f77cac:	test   %dil,%dil
 1f77caf:	cmovne %r9d,%edx
 1f77cb3:	test   %ecx,%ecx
 1f77cb5:	sete   %dil
 1f77cb9:	mov    %rdx,0x70(%rsp)
 1f77cbe:	or     %sil,%dil
 1f77cc1:	jne    1f790c4 <node_facts_front_expression+0x14a4>
 1f77cc7:	vpbroadcastd -0x19a91f5(%rip),%zmm17        # 5ceadc <.LCPI1283_0>
 1f77cd1:	mov    0x940(%r12),%rdi
 1f77cd9:	mov    0x10(%r12),%rdx
 1f77cde:	vpternlogd $0xff,%xmm16,%xmm16,%xmm16
 1f77ce5:	mov    %eax,%eax
 1f77ce7:	mov    %rax,0x60(%rsp)
 1f77cec:	mov    %ecx,%eax
 1f77cee:	xor    %r14d,%r14d
 1f77cf1:	mov    %esi,0x18(%rsp)
 1f77cf5:	mov    %rax,0x68(%rsp)
 1f77cfa:	mov    %ebp,0x24(%rsp)
 1f77cfe:	mov    %r10,0x38(%rsp)
 1f77d03:	mov    %rdx,0x58(%rsp)
 1f77d08:	mov    %rdi,0x28(%rsp)
 1f77d0d:	jmp    1f77d35 <node_facts_front_expression+0x115>
 1f77d0f:	nop
 1f77d10:	mov    0x990(%r12),%rax
 1f77d18:	inc    %r11d
 1f77d1b:	inc    %r14
 1f77d1e:	mov    %r9d,0x18(%rsp)
 1f77d23:	mov    %r11d,(%rax,%rcx,4)
 1f77d27:	mov    %r9d,%eax
 1f77d2a:	cmp    0x68(%rsp),%r14
 1f77d2f:	jae    1f790cd <node_facts_front_expression+0x14ad>
 1f77d35:	mov    0x70(%rsp),%rax
 1f77d3a:	mov    $0x1,%r9d
 1f77d40:	cmp    0x60(%rsp),%r14
 1f77d45:	lea    (%rax,%r14,1),%r15d
 1f77d49:	cmove  %ebp,%r15d
 1f77d4d:	je     1f77d58 <node_facts_front_expression+0x138>
 1f77d4f:	movzbl 0x1442c(%r10,%r15,1),%r9d
 1f77d58:	mov    0x78(%rsp),%rax
 1f77d5d:	movzbl 0x154ac(%r10,%r15,1),%ecx
 1f77d66:	movzbl 0x2c(%r10,%r15,1),%ebx
 1f77d6c:	mov    0x422c(%r10,%r15,4),%r11d
 1f77d74:	mov    %r9d,0xc(%rsp)
 1f77d79:	lea    (%rax,%r14,1),%r13d
 1f77d7d:	movzbl %cl,%eax
 1f77d80:	cmp    $0xff,%rcx
 1f77d87:	mov    %eax,0x4c(%rsp)
 1f77d8b:	movzbl 0x1652c(%r10,%r15,1),%eax
 1f77d94:	setne  %dl
 1f77d97:	cmp    $0xff,%rax
 1f77d9d:	setne  %sil
 1f77da1:	cmp    $0xff,%r9d
 1f77da8:	setne  %r8b
 1f77dac:	and    %dl,%r8b
 1f77daf:	mov    %r9d,%edx
 1f77db2:	cmp    %rdx,%r14
 1f77db5:	setae  %dl
 1f77db8:	and    %sil,%dl
 1f77dbb:	and    %r8b,%dl
 1f77dbe:	cmp    %rcx,%r14
 1f77dc1:	mov    %ebx,%r8d
 1f77dc4:	mov    $0x2,%ebx
 1f77dc9:	setae  %sil
 1f77dcd:	cmp    %rax,%r14
 1f77dd0:	setae  %cl
 1f77dd3:	and    %sil,%cl
 1f77dd6:	and    %dl,%cl
 1f77dd8:	cmovne 0x18(%rsp),%ebx
 1f77ddd:	cmp    $0x1,%cl
 1f77de0:	jne    1f77ed0 <node_facts_front_expression+0x2b0>
 1f77de6:	test   %r8b,%r8b
 1f77de9:	jne    1f77ed0 <node_facts_front_expression+0x2b0>
 1f77def:	mov    0x33aac(%r10,%r15,4),%edx
 1f77df7:	movzbl 0x4bd30(%r10,%r15,1),%eax
 1f77e00:	mov    %r8b,0xa(%rsp)
 1f77e05:	mov    %edx,%ecx
 1f77e07:	shr    $0x3,%ecx
 1f77e0a:	cmp    $0x1,%eax
 1f77e0d:	je     1f77f6f <node_facts_front_expression+0x34f>
 1f77e13:	test   %eax,%eax
 1f77e15:	jne    1f7800b <node_facts_front_expression+0x3eb>
 1f77e1b:	mov    0x43cb0(%r10,%r15,8),%rsi
 1f77e23:	mov    0x30(%r12),%rcx
 1f77e28:	mov    %esi,%eax
 1f77e2a:	mov    (%rcx,%rax,4),%eax
 1f77e2d:	test   %rax,%rax
 1f77e30:	je     1f77e67 <node_facts_front_expression+0x247>
 1f77e32:	mov    0x8(%r12),%r9
 1f77e37:	mov    0x28(%r12),%rcx
 1f77e3c:	mov    %rax,%rdx
 1f77e3f:	shl    $0x5,%rdx
 1f77e43:	mov    0x428(%r9),%r8
 1f77e4a:	mov    (%r8,%r11,4),%r8d
 1f77e4e:	cmp    (%rcx,%rdx,1),%r8d
 1f77e52:	jne    1f77e67 <node_facts_front_expression+0x247>
 1f77e54:	mov    0x298(%r9),%r8
 1f77e5b:	test   %r8,%r8
 1f77e5e:	je     1f77ea9 <node_facts_front_expression+0x289>
 1f77e60:	cmpl   $0x0,0x8(%r8)
 1f77e65:	je     1f77ea9 <node_facts_front_expression+0x289>
 1f77e67:	mov    %r12,%rdi
 1f77e6a:	mov    %r11d,%edx
 1f77e6d:	mov    %r11,%r15
 1f77e70:	vzeroupper
 1f77e73:	call   1f522e0 <node_facts_declaration>
 1f77e78:	vpbroadcastd -0x19a93a6(%rip),%zmm17        # 5ceadc <.LCPI1283_0>
 1f77e82:	mov    0x38(%rsp),%r10
 1f77e87:	mov    0x28(%rsp),%rdi
 1f77e8c:	vpternlogd $0xff,%xmm16,%xmm16,%xmm16
 1f77e93:	mov    %r15,%r11
 1f77e96:	test   %eax,%eax
 1f77e98:	je     1f78172 <node_facts_front_expression+0x552>
 1f77e9e:	mov    0x28(%r12),%rcx
 1f77ea3:	mov    %eax,%edx
 1f77ea5:	shl    $0x5,%rdx
 1f77ea9:	testb  $0x4,0x1c(%rcx,%rdx,1)
 1f77eae:	jne    1f78172 <node_facts_front_expression+0x552>
 1f77eb4:	mov    $0xff,%r15b
 1f77eb7:	movb   $0x2,0xb(%rsp)
 1f77ebc:	movq   $0x0,0x10(%rsp)
 1f77ec5:	jmp    1f788b0 <node_facts_front_expression+0xc90>
 1f77eca:	nopw   0x0(%rax,%rax,1)
 1f77ed0:	test   %cl,%cl
 1f77ed2:	je     1f790c8 <node_facts_front_expression+0x14a8>
 1f77ed8:	movzbl %r8b,%ecx
 1f77edc:	movzbl %al,%r9d
 1f77ee0:	movzbl 0xadd(%r12,%rcx,1),%eax
 1f77ee9:	movzbl 0xa98(%r12,%rcx,1),%edx
 1f77ef2:	mov    %al,0x30(%rsp)
 1f77ef6:	cmp    $0x18,%r8b
 1f77efa:	jne    1f77f40 <node_facts_front_expression+0x320>
 1f77efc:	mov    0xc(%rsp),%ebx
 1f77f00:	cmp    0x60(%rsp),%r14
 1f77f05:	je     1f77f1b <node_facts_front_expression+0x2fb>
 1f77f07:	mov    0x1f0(%rdi),%rax
 1f77f0e:	mov    (%rax,%r11,4),%eax
 1f77f12:	cmp    $0x8,%eax
 1f77f15:	jne    1f7857f <node_facts_front_expression+0x95f>
 1f77f1b:	movzbl 0x935(%r12),%edx
 1f77f24:	mov    $0x8,%eax
 1f77f29:	movb   $0xd,0x30(%rsp)
 1f77f2e:	movq   $0x0,0x10(%rsp)
 1f77f37:	add    $0x3,%dl
 1f77f3a:	jmp    1f78590 <node_facts_front_expression+0x970>
 1f77f3f:	nop
 1f77f40:	mov    0xc(%rsp),%ebx
 1f77f44:	mov    %r8d,%eax
 1f77f47:	and    $0xfe,%al
 1f77f49:	cmp    $0x20,%al
 1f77f4b:	jne    1f7813e <node_facts_front_expression+0x51e>
 1f77f51:	mov    0x58(%rsp),%rax
 1f77f56:	lea    0x1(%r11),%ecx
 1f77f5a:	movq   $0x0,0x10(%rsp)
 1f77f63:	mov    0x60(%rax),%rax
 1f77f67:	mov    (%rax,%rcx,4),%eax
 1f77f6a:	jmp    1f78590 <node_facts_front_expression+0x970>
 1f77f6f:	cmp    0x60(%r12),%ecx
 1f77f74:	jae    1f77f8b <node_facts_front_expression+0x36b>
 1f77f76:	mov    0x20(%r12),%r8
 1f77f7b:	shl    $0x6,%rcx
 1f77f7f:	testb  $0x1,0x34(%r8,%rcx,1)
 1f77f85:	jne    1f782a6 <node_facts_front_expression+0x686>
 1f77f8b:	lea    0x80(%rsp),%rdx
 1f77f93:	mov    %r11d,%esi
 1f77f96:	mov    %r11,0x40(%rsp)
 1f77f9b:	vzeroupper
 1f77f9e:	call   14f1770 <node_front_literal>
 1f77fa3:	mov    0x80(%rsp),%edx
 1f77faa:	mov    0x88(%rsp),%rbp
 1f77fb2:	mov    0x90(%rsp),%r10
 1f77fba:	movzwl 0x98(%rsp),%r9d
 1f77fc3:	mov    0xa8(%rsp),%rsi
 1f77fcb:	testb  $0x1,0xa1(%rsp)
 1f77fd3:	je     1f781a8 <node_facts_front_expression+0x588>
 1f77fd9:	mov    $0x4,%ecx
 1f77fde:	mov    $0x20000,%r11d
 1f77fe4:	cmp    $0x1b0,%edx
 1f77fea:	je     1f7908c <node_facts_front_expression+0x146c>
 1f77ff0:	mov    %rbp,0x18(%rsp)
 1f77ff5:	mov    %r9,%rdi
 1f77ff8:	mov    %r10,%rsi
 1f77ffb:	xor    %r8d,%r8d
 1f77ffe:	xor    %r9d,%r9d
 1f78001:	xor    %r10d,%r10d
 1f78004:	xor    %ebp,%ebp
 1f78006:	jmp    1f781e2 <node_facts_front_expression+0x5c2>
 1f7800b:	mov    0x43cb0(%r10,%r15,8),%ebx
 1f78013:	xor    %r8d,%r8d
 1f78016:	mov    $0x3,%esi
 1f7801b:	mov    %r11,0x40(%rsp)
 1f78020:	mov    $0x1,%al
 1f78022:	mov    %rsi,0x10(%rsp)
 1f78027:	mov    $0x1,%esi
 1f7802c:	mov    %rsi,0x30(%rsp)
 1f78031:	mov    $0x1,%sil
 1f78034:	test   %ebx,%ebx
 1f78036:	setne  %r8b
 1f7803a:	xor    %r11d,%r11d
 1f7803d:	xor    %r9d,%r9d
 1f78040:	xor    %r10d,%r10d
 1f78043:	shl    $0x17,%r8d
 1f78047:	or     $0x80,%r8d
 1f7804e:	mov    (%r12),%rdi
 1f78052:	mov    $0xff,%ebp
 1f78057:	cmp    0x28(%rdi),%ecx
 1f7805a:	jae    1f78065 <node_facts_front_expression+0x445>
 1f7805c:	mov    0x18(%rdi),%rdi
 1f78060:	mov    %ecx,%ecx
 1f78062:	mov    (%rdi,%rcx,4),%ebp
 1f78065:	cmp    $0xfffe,%r10
 1f7806c:	mov    $0xfffe,%ecx
 1f78071:	mov    $0xff,%r15b
 1f78074:	movb   $0x1,0xb(%rsp)
 1f78079:	cmovb  %r10,%rcx
 1f7807d:	inc    %ecx
 1f7807f:	test   %sil,%sil
 1f78082:	cmovne %ecx,%r9d
 1f78086:	test   %r11b,%r11b
 1f78089:	je     1f7809f <node_facts_front_expression+0x47f>
 1f7808b:	mov    0x24(%rsp),%ebp
 1f7808f:	movq   $0x0,0x10(%rsp)
 1f78098:	xor    %eax,%eax
 1f7809a:	jmp    1f786bd <node_facts_front_expression+0xa9d>
 1f7809f:	mov    0x10(%rsp),%rdi
 1f780a4:	mov    0x40(%rsp),%r11
 1f780a9:	cmp    $0x1,%edi
 1f780ac:	setne  %cl
 1f780af:	and    %al,%cl
 1f780b1:	or     %sil,%cl
 1f780b4:	cmp    $0x1,%cl
 1f780b7:	jne    1f7818a <node_facts_front_expression+0x56a>
 1f780bd:	mov    0x74(%r12),%eax
 1f780c2:	cmp    0x70(%r12),%eax
 1f780c7:	jae    1f7818a <node_facts_front_expression+0x56a>
 1f780cd:	xor    $0x1,%sil
 1f780d1:	inc    %rax
 1f780d4:	movb   $0x6,0xb(%rsp)
 1f780d9:	movq   $0x0,0x10(%rsp)
 1f780e2:	movzbl %sil,%ecx
 1f780e6:	mov    0x30(%rsp),%rsi
 1f780eb:	mov    %eax,0x74(%r12)
 1f780f0:	shl    $0x6,%ecx
 1f780f3:	lea    (%rsi,%rdi,4),%esi
 1f780f6:	mov    %r11,%rdi
 1f780f9:	mov    %rax,%r11
 1f780fc:	shl    $0x5,%r11
 1f78100:	or     %ecx,%esi
 1f78102:	mov    0x28(%r12),%rcx
 1f78107:	mov    %edx,(%rcx,%r11,1)
 1f7810b:	mov    %ebp,0x4(%rcx,%r11,1)
 1f78110:	mov    %r8d,0x8(%rcx,%r11,1)
 1f78115:	mov    %ebx,0xc(%rcx,%r11,1)
 1f7811a:	mov    %r10,0x10(%rcx,%r11,1)
 1f7811f:	mov    %sil,0x18(%rcx,%r11,1)
 1f78124:	movb   $0x1,0x19(%rcx,%r11,1)
 1f7812a:	mov    %r9w,0x1a(%rcx,%r11,1)
 1f78130:	movl   $0x0,0x1c(%rcx,%r11,1)
 1f78139:	mov    %rdi,%r11
 1f7813c:	jmp    1f78195 <node_facts_front_expression+0x575>
 1f7813e:	cmp    $0x17,%ecx
 1f78141:	je     1f7856f <node_facts_front_expression+0x94f>
 1f78147:	cmp    $0x22,%ecx
 1f7814a:	je     1f7831a <node_facts_front_expression+0x6fa>
 1f78150:	cmp    $0x24,%ecx
 1f78153:	jne    1f7857d <node_facts_front_expression+0x95d>
 1f78159:	mov    0x2f8(%rdi),%rax
 1f78160:	movq   $0x0,0x10(%rsp)
 1f78169:	mov    (%rax,%r11,4),%eax
 1f7816d:	jmp    1f78590 <node_facts_front_expression+0x970>
 1f78172:	mov    $0xff,%r15b
 1f78175:	movb   $0x1,0xb(%rsp)
 1f7817a:	movq   $0x0,0x10(%rsp)
 1f78183:	xor    %eax,%eax
 1f78185:	jmp    1f788b0 <node_facts_front_expression+0xc90>
 1f7818a:	xor    %eax,%eax
 1f7818c:	movq   $0x0,0x10(%rsp)
 1f78195:	mov    0x24(%rsp),%ebp
 1f78199:	mov    0x28(%rsp),%rdi
 1f7819e:	mov    0x38(%rsp),%r10
 1f781a3:	jmp    1f786cc <node_facts_front_expression+0xaac>
 1f781a8:	xor    %r8d,%r8d
 1f781ab:	xor    %ecx,%ecx
 1f781ad:	cmp    $0xb8,%edx
 1f781b3:	mov    $0x2,%edi
 1f781b8:	mov    %rsi,0x18(%rsp)
 1f781bd:	sete   %cl
 1f781c0:	setne  %r8b
 1f781c4:	testb  $0x1,0xa0(%rsp)
 1f781cc:	lea    0x1(%rcx,%rcx,1),%ecx
 1f781d0:	cmovne %edi,%r8d
 1f781d4:	cmovne %edi,%ecx
 1f781d7:	xor    %edi,%edi
 1f781d9:	xor    %esi,%esi
 1f781db:	lea    0x20000(%r8),%r11d
 1f781e2:	vpbroadcastd -0x19a9710(%rip),%zmm17        # 5ceadc <.LCPI1283_0>
 1f781ec:	cmpb   $0x1,0xa2(%rsp)
 1f781f4:	vpternlogd $0xff,%xmm16,%xmm16,%xmm16
 1f781fb:	mov    %rcx,0x10(%rsp)
 1f78200:	jne    1f78253 <node_facts_front_expression+0x633>
 1f78202:	mov    0x28(%rsp),%rcx
 1f78207:	mov    %rdi,0x30(%rsp)
 1f7820c:	mov    %al,0xb(%rsp)
 1f78210:	mov    0x40(%rsp),%r15
 1f78215:	mov    0x8(%rcx),%rdi
 1f78219:	mov    0x58(%rdi),%rax
 1f7821d:	cmpb   $0x3,(%rax,%r15,1)
 1f78222:	jne    1f78249 <node_facts_front_expression+0x629>
 1f78224:	mov    0x10(%rsp),%rcx
 1f78229:	mov    0x60(%rdi),%rax
 1f7822d:	mov    %ecx,%edi
 1f7822f:	xor    $0x1,%edi
 1f78232:	mov    %rbp,%rcx
 1f78235:	or     0x18(%rsp),%rcx
 1f7823a:	cmovne %r8d,%r11d
 1f7823e:	or     (%rax,%r15,4),%edi
 1f78242:	cmovne %r8d,%r11d
 1f78246:	mov    %r11d,%r8d
 1f78249:	movzbl 0xb(%rsp),%eax
 1f7824e:	mov    0x30(%rsp),%rdi
 1f78253:	test   %al,%al
 1f78255:	je     1f790e2 <node_facts_front_expression+0x14c2>
 1f7825b:	or     %rdi,%rsi
 1f7825e:	or     0x18(%rsp),%rsi
 1f78263:	mov    %r10,%rax
 1f78266:	mov    %edx,%ecx
 1f78268:	movq   $0x0,0x30(%rsp)
 1f78271:	mov    %ebx,0x18(%rsp)
 1f78275:	setne  %r11b
 1f78279:	or     %r9,%rax
 1f7827c:	sete   %sil
 1f78280:	cmove  %rbp,%r10
 1f78284:	test   %rbp,%rbp
 1f78287:	sete   %al
 1f7828a:	shr    $0x3,%ecx
 1f7828d:	xor    %ebx,%ebx
 1f7828f:	mov    (%r12),%rdi
 1f78293:	mov    $0xff,%ebp
 1f78298:	cmp    0x28(%rdi),%ecx
 1f7829b:	jb     1f7805c <node_facts_front_expression+0x43c>
 1f782a1:	jmp    1f78065 <node_facts_front_expression+0x445>
 1f782a6:	mov    0x43cb0(%r10,%r15,8),%rsi
 1f782ae:	mov    $0x1,%r9d
 1f782b4:	test   %rsi,%rsi
 1f782b7:	jne    1f782e5 <node_facts_front_expression+0x6c5>
 1f782b9:	mov    0x58(%rsp),%rax
 1f782be:	mov    0x58(%rax),%rax
 1f782c2:	cmpb   $0x3,(%rax,%r11,1)
 1f782c7:	jne    1f782e5 <node_facts_front_expression+0x6c5>
 1f782c9:	mov    0x58(%rsp),%rax
 1f782ce:	xor    %r9d,%r9d
 1f782d1:	mov    0x60(%rax),%rax
 1f782d5:	cmpl   $0x0,(%rax,%r11,4)
 1f782da:	sete   %r9b
 1f782de:	shl    $0x11,%r9d
 1f782e2:	inc    %r9d
 1f782e5:	mov    0x74(%r12),%eax
 1f782ea:	mov    $0xff,%r15b
 1f782ed:	cmp    0x70(%r12),%eax
 1f782f2:	setae  %dil
 1f782f6:	inc    %eax
 1f782f8:	sete   %r10b
 1f782fc:	or     %dil,%r10b
 1f782ff:	je     1f78832 <node_facts_front_expression+0xc12>
 1f78305:	xor    %eax,%eax
 1f78307:	movb   $0x1,0xb(%rsp)
 1f7830c:	movq   $0x0,0x10(%rsp)
 1f78315:	jmp    1f788a2 <node_facts_front_expression+0xc82>
 1f7831a:	movzbl 0x1862c(%r10,%r15,1),%ecx
 1f78323:	mov    $0x4,%eax
 1f78328:	mov    %dl,0xb(%rsp)
 1f7832c:	cmp    $0xff,%ecx
 1f78332:	je     1f790cd <node_facts_front_expression+0x14ad>
 1f78338:	lea    -0x1(%rcx),%edx
 1f7833b:	mov    %rcx,0x50(%rsp)
 1f78340:	mov    0x9a0(%r12),%ecx
 1f78348:	mov    %edx,%esi
 1f7834a:	add    %rcx,%rsi
 1f7834d:	mov    0x254(%r12),%ecx
 1f78355:	cmp    %rcx,%rsi
 1f78358:	ja     1f790cd <node_facts_front_expression+0x14ad>
 1f7835e:	mov    %r8b,0xa(%rsp)
 1f78363:	mov    %rdx,0x10(%rsp)
 1f78368:	test   %edx,%edx
 1f7836a:	je     1f7854b <node_facts_front_expression+0x92b>
 1f78370:	mov    0x10(%rsp),%rcx
 1f78375:	mov    0x50(%rsp),%rdx
 1f7837a:	mov    $0x1,%r8d
 1f78380:	mov    %ecx,%eax
 1f78382:	and    $0x7,%eax
 1f78385:	lea    -0x2(%rdx),%esi
 1f78388:	cmp    $0x7,%sil
 1f7838c:	jb     1f78511 <node_facts_front_expression+0x8f1>
 1f78392:	mov    0x10(%rsp),%rdx
 1f78397:	mov    %r11,0x40(%rsp)
 1f7839c:	xor    %ecx,%ecx
 1f7839e:	mov    %edx,%edi
 1f783a0:	and    $0xfffffff8,%edi
 1f783a3:	neg    %edi
 1f783a5:	data16 cs nopw 0x0(%rax,%rax,1)
 1f783b0:	mov    0x9a0(%r12),%ebx
 1f783b8:	mov    0x998(%r12),%r11
 1f783c0:	lea    (%rdx,%rcx,1),%esi
 1f783c3:	add    $0xfffffff8,%ecx
 1f783c6:	lea    -0x1(%rbx,%rsi,1),%ebx
 1f783ca:	mov    %r8w,(%r11,%rbx,2)
 1f783cf:	mov    %r15d,%r11d
 1f783d2:	sub    %r8d,%r11d
 1f783d5:	mov    0x9a0(%r12),%ebx
 1f783dd:	add    0x651b8(%r10,%r11,4),%r8d
 1f783e5:	mov    0x998(%r12),%r11
 1f783ed:	lea    -0x2(%rbx,%rsi,1),%ebx
 1f783f1:	mov    %r8w,(%r11,%rbx,2)
 1f783f6:	mov    %r15d,%r11d
 1f783f9:	sub    %r8d,%r11d
 1f783fc:	mov    0x9a0(%r12),%ebx
 1f78404:	add    0x651b8(%r10,%r11,4),%r8d
 1f7840c:	mov    0x998(%r12),%r11
 1f78414:	lea    -0x3(%rbx,%rsi,1),%ebx
 1f78418:	mov    %r8w,(%r11,%rbx,2)
 1f7841d:	mov    %r15d,%r11d
 1f78420:	sub    %r8d,%r11d
 1f78423:	mov    0x9a0(%r12),%ebx
 1f7842b:	add    0x651b8(%r10,%r11,4),%r8d
 1f78433:	mov    0x998(%r12),%r11
 1f7843b:	lea    -0x4(%rbx,%rsi,1),%ebx
 1f7843f:	mov    %r8w,(%r11,%rbx,2)
 1f78444:	mov    %r15d,%r11d
 1f78447:	sub    %r8d,%r11d
 1f7844a:	mov    0x9a0(%r12),%ebx
 1f78452:	add    0x651b8(%r10,%r11,4),%r8d
 1f7845a:	mov    0x998(%r12),%r11
 1f78462:	lea    -0x5(%rbx,%rsi,1),%ebx
 1f78466:	mov    %r8w,(%r11,%rbx,2)
 1f7846b:	mov    %r15d,%r11d
 1f7846e:	sub    %r8d,%r11d
 1f78471:	mov    0x9a0(%r12),%ebx
 1f78479:	add    0x651b8(%r10,%r11,4),%r8d
 1f78481:	mov    0x998(%r12),%r11
 1f78489:	lea    -0x6(%rbx,%rsi,1),%ebx
 1f7848d:	mov    %r8w,(%r11,%rbx,2)
 1f78492:	mov    %r15d,%r11d
 1f78495:	sub    %r8d,%r11d
 1f78498:	mov    0x9a0(%r12),%ebx
 1f784a0:	add    0x651b8(%r10,%r11,4),%r8d
 1f784a8:	mov    0x998(%r12),%r11
 1f784b0:	lea    -0x7(%rbx,%rsi,1),%ebx
 1f784b4:	mov    %r8w,(%r11,%rbx,2)
 1f784b9:	mov    %r15d,%r11d
 1f784bc:	sub    %r8d,%r11d
 1f784bf:	mov    0x9a0(%r12),%ebx
 1f784c7:	add    0x651b8(%r10,%r11,4),%r8d
 1f784cf:	mov    0x998(%r12),%r11
 1f784d7:	lea    -0x8(%rbx,%rsi,1),%esi
 1f784db:	mov    %r8w,(%r11,%rsi,2)
 1f784e0:	mov    %r15d,%esi
 1f784e3:	sub    %r8d,%esi
 1f784e6:	add    0x651b8(%r10,%rsi,4),%r8d
 1f784ee:	cmp    %ecx,%edi
 1f784f0:	jne    1f783b0 <node_facts_front_expression+0x790>
 1f784f6:	mov    0x28(%rsp),%rdi
 1f784fb:	mov    0x40(%rsp),%r11
 1f78500:	mov    0xc(%rsp),%ebx
 1f78504:	test   %eax,%eax
 1f78506:	je     1f7854b <node_facts_front_expression+0x92b>
 1f78508:	mov    0x50(%rsp),%rdx
 1f7850d:	lea    -0x1(%rdx,%rcx,1),%ecx
 1f78511:	dec    %ecx
 1f78513:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f78520:	mov    0x9a0(%r12),%esi
 1f78528:	mov    0x998(%r12),%rdx
 1f78530:	add    %ecx,%esi
 1f78532:	dec    %ecx
 1f78534:	mov    %r8w,(%rdx,%rsi,2)
 1f78539:	mov    %r15d,%edx
 1f7853c:	sub    %r8d,%edx
 1f7853f:	add    0x651b8(%r10,%rdx,4),%r8d
 1f78547:	dec    %eax
 1f78549:	jne    1f78520 <node_facts_front_expression+0x900>
 1f7854b:	mov    0x9a0(%r12),%eax
 1f78553:	movzbl 0xa(%rsp),%r8d
 1f78559:	movzbl 0xb(%rsp),%edx
 1f7855e:	mov    0x10(%rsp),%rcx
 1f78563:	add    %eax,%ecx
 1f78565:	mov    %ecx,0x9a0(%r12)
 1f7856d:	jmp    1f78590 <node_facts_front_expression+0x970>
 1f7856f:	movq   $0x0,0x10(%rsp)
 1f78578:	mov    %r9d,%eax
 1f7857b:	jmp    1f78590 <node_facts_front_expression+0x970>
 1f7857d:	xor    %eax,%eax
 1f7857f:	movq   $0x0,0x10(%rsp)
 1f78588:	nopl   0x0(%rax,%rax,1)
 1f78590:	mov    %edx,%ecx
 1f78592:	mov    $0xff,%r15b
 1f78595:	mov    %dl,0xb(%rsp)
 1f78599:	and    $0xfb,%cl
 1f7859c:	cmp    $0x3,%cl
 1f7859f:	jne    1f786d6 <node_facts_front_expression+0xab6>
 1f785a5:	mov    %r8b,0xa(%rsp)
 1f785aa:	movzbl 0x30(%rsp),%r8d
 1f785b0:	xor    %r15d,%r15d
 1f785b3:	test   %ebx,%ebx
 1f785b5:	je     1f785f0 <node_facts_front_expression+0x9d0>
 1f785b7:	mov    0x960(%r12),%rcx
 1f785bf:	mov    %r13d,%edx
 1f785c2:	sub    %ebx,%edx
 1f785c4:	mov    0x10(%rsp),%rdi
 1f785c9:	movzbl (%rcx,%rdx,1),%ecx
 1f785cd:	cmp    $0xff,%ecx
 1f785d3:	je     1f785e6 <node_facts_front_expression+0x9c6>
 1f785d5:	mov    %ecx,%r15d
 1f785d8:	and    $0xf,%ecx
 1f785db:	shr    $0x4,%r15d
 1f785df:	cmp    %ecx,%r8d
 1f785e2:	adc    $0x0,%r15d
 1f785e6:	mov    0x4c(%rsp),%esi
 1f785ea:	test   %esi,%esi
 1f785ec:	jne    1f785fd <node_facts_front_expression+0x9dd>
 1f785ee:	jmp    1f7862b <node_facts_front_expression+0xa0b>
 1f785f0:	mov    0x10(%rsp),%rdi
 1f785f5:	mov    0x4c(%rsp),%esi
 1f785f9:	test   %esi,%esi
 1f785fb:	je     1f7862b <node_facts_front_expression+0xa0b>
 1f785fd:	mov    0x960(%r12),%rcx
 1f78605:	mov    %r13d,%edx
 1f78608:	sub    %esi,%edx
 1f7860a:	movzbl (%rcx,%rdx,1),%ecx
 1f7860e:	cmp    $0xff,%ecx
 1f78614:	je     1f7862b <node_facts_front_expression+0xa0b>
 1f78616:	mov    %ecx,%edx
 1f78618:	and    $0xf,%ecx
 1f7861b:	shr    $0x4,%edx
 1f7861e:	cmp    %ecx,%r8d
 1f78621:	adc    $0x0,%edx
 1f78624:	cmp    %r15d,%edx
 1f78627:	cmova  %edx,%r15d
 1f7862b:	mov    %r11,0x40(%rsp)
 1f78630:	test   %r9d,%r9d
 1f78633:	je     1f78664 <node_facts_front_expression+0xa44>
 1f78635:	mov    0x960(%r12),%rcx
 1f7863d:	mov    %r13d,%edx
 1f78640:	sub    %r9d,%edx
 1f78643:	movzbl (%rcx,%rdx,1),%ecx
 1f78647:	cmp    $0xff,%ecx
 1f7864d:	je     1f78664 <node_facts_front_expression+0xa44>
 1f7864f:	mov    %ecx,%edx
 1f78651:	and    $0xf,%ecx
 1f78654:	shr    $0x4,%edx
 1f78657:	cmp    %ecx,%r8d
 1f7865a:	adc    $0x0,%edx
 1f7865d:	cmp    %r15d,%edx
 1f78660:	cmova  %edx,%r15d
 1f78664:	test   %di,%di
 1f78667:	je     1f786a7 <node_facts_front_expression+0xa87>
 1f78669:	mov    0x960(%r12),%r9
 1f78671:	mov    0x998(%r12),%r10
 1f78679:	movzwl %di,%r11d
 1f7867d:	cmp    $0x10,%di
 1f78681:	jae    1f787fd <node_facts_front_expression+0xbdd>
 1f78687:	xor    %edi,%edi
 1f78689:	mov    %r11,%rcx
 1f7868c:	and    $0x3,%rcx
 1f78690:	mov    %eax,%edx
 1f78692:	mov    %rdi,%rbx
 1f78695:	jne    1f786e8 <node_facts_front_expression+0xac8>
 1f78697:	mov    0x24(%rsp),%ebp
 1f7869b:	sub    %r11d,%edi
 1f7869e:	cmp    $0xfffffffc,%edi
 1f786a1:	jbe    1f78730 <node_facts_front_expression+0xb10>
 1f786a7:	cmp    $0x4,%r15d
 1f786ab:	mov    $0x4,%ecx
 1f786b0:	cmovae %ecx,%r15d
 1f786b4:	shl    $0x4,%r15b
 1f786b8:	or     0x30(%rsp),%r15b
 1f786bd:	mov    0x28(%rsp),%rdi
 1f786c2:	mov    0x38(%rsp),%r10
 1f786c7:	mov    0x40(%rsp),%r11
 1f786cc:	mov    0xc(%rsp),%ebx
 1f786d0:	movzbl 0xa(%rsp),%r8d
 1f786d6:	mov    0x18(%rsp),%r9d
 1f786db:	jmp    1f788bd <node_facts_front_expression+0xc9d>
 1f786e0:	inc    %rbx
 1f786e3:	dec    %rcx
 1f786e6:	je     1f78697 <node_facts_front_expression+0xa77>
 1f786e8:	lea    (%rdx,%rbx,1),%esi
 1f786eb:	mov    %r13d,%ebp
 1f786ee:	movzwl (%r10,%rsi,2),%esi
 1f786f3:	sub    %esi,%ebp
 1f786f5:	movzbl (%r9,%rbp,1),%esi
 1f786fa:	cmp    $0xff,%esi
 1f78700:	je     1f786e0 <node_facts_front_expression+0xac0>
 1f78702:	mov    %esi,%ebp
 1f78704:	and    $0xf,%esi
 1f78707:	shr    $0x4,%ebp
 1f7870a:	cmp    %esi,%r8d
 1f7870d:	adc    $0x0,%ebp
 1f78710:	cmp    %r15d,%ebp
 1f78713:	cmova  %ebp,%r15d
 1f78717:	jmp    1f786e0 <node_facts_front_expression+0xac0>
 1f78719:	nopl   0x0(%rax)
 1f78720:	mov    %ecx,%r15d
 1f78723:	add    $0x4,%rbx
 1f78727:	cmp    %rbx,%r11
 1f7872a:	je     1f786a7 <node_facts_front_expression+0xa87>
 1f78730:	lea    (%rdx,%rbx,1),%ecx
 1f78733:	mov    %r13d,%esi
 1f78736:	movzwl (%r10,%rcx,2),%ecx
 1f7873b:	sub    %ecx,%esi
 1f7873d:	movzbl (%r9,%rsi,1),%ecx
 1f78742:	cmp    $0xff,%ecx
 1f78748:	je     1f7875f <node_facts_front_expression+0xb3f>
 1f7874a:	mov    %ecx,%esi
 1f7874c:	and    $0xf,%ecx
 1f7874f:	shr    $0x4,%esi
 1f78752:	cmp    %ecx,%r8d
 1f78755:	adc    $0x0,%esi
 1f78758:	cmp    %r15d,%esi
 1f7875b:	cmova  %esi,%r15d
 1f7875f:	lea    0x1(%rdx,%rbx,1),%ecx
 1f78763:	mov    %r13d,%esi
 1f78766:	movzwl (%r10,%rcx,2),%ecx
 1f7876b:	sub    %ecx,%esi
 1f7876d:	movzbl (%r9,%rsi,1),%ecx
 1f78772:	cmp    $0xff,%ecx
 1f78778:	je     1f7878f <node_facts_front_expression+0xb6f>
 1f7877a:	mov    %ecx,%esi
 1f7877c:	and    $0xf,%ecx
 1f7877f:	shr    $0x4,%esi
 1f78782:	cmp    %ecx,%r8d
 1f78785:	adc    $0x0,%esi
 1f78788:	cmp    %r15d,%esi
 1f7878b:	cmova  %esi,%r15d
 1f7878f:	lea    0x2(%rdx,%rbx,1),%ecx
 1f78793:	mov    %r13d,%esi
 1f78796:	movzwl (%r10,%rcx,2),%ecx
 1f7879b:	sub    %ecx,%esi
 1f7879d:	movzbl (%r9,%rsi,1),%ecx
 1f787a2:	cmp    $0xff,%ecx
 1f787a8:	je     1f787bf <node_facts_front_expression+0xb9f>
 1f787aa:	mov    %ecx,%esi
 1f787ac:	and    $0xf,%ecx
 1f787af:	shr    $0x4,%esi
 1f787b2:	cmp    %ecx,%r8d
 1f787b5:	adc    $0x0,%esi
 1f787b8:	cmp    %r15d,%esi
 1f787bb:	cmova  %esi,%r15d
 1f787bf:	lea    0x3(%rdx,%rbx,1),%ecx
 1f787c3:	mov    %r13d,%esi
 1f787c6:	movzwl (%r10,%rcx,2),%ecx
 1f787cb:	sub    %ecx,%esi
 1f787cd:	movzbl (%r9,%rsi,1),%esi
 1f787d2:	cmp    $0xff,%esi
 1f787d8:	je     1f78723 <node_facts_front_expression+0xb03>
 1f787de:	mov    %esi,%ecx
 1f787e0:	and    $0xf,%esi
 1f787e3:	shr    $0x4,%ecx
 1f787e6:	cmp    %esi,%r8d
 1f787e9:	adc    $0x0,%ecx
 1f787ec:	cmp    %r15d,%ecx
 1f787ef:	ja     1f78720 <node_facts_front_expression+0xb00>
 1f787f5:	mov    %r15d,%ecx
 1f787f8:	jmp    1f78720 <node_facts_front_expression+0xb00>
 1f787fd:	lea    -0x1(%r11),%rcx
 1f78801:	mov    %eax,%edx
 1f78803:	add    %ecx,%edx
 1f78805:	jb     1f78687 <node_facts_front_expression+0xa67>
 1f7880b:	shr    $0x20,%rcx
 1f7880f:	jne    1f78687 <node_facts_front_expression+0xa67>
 1f78815:	vpbroadcastd %r13d,%zmm0
 1f7881b:	vpbroadcastd %r8d,%zmm1
 1f78821:	cmp    $0x40,%di
 1f78825:	jae    1f78953 <node_facts_front_expression+0xd33>
 1f7882b:	xor    %edi,%edi
 1f7882d:	jmp    1f78edc <node_facts_front_expression+0x12bc>
 1f78832:	add    %rcx,%r8
 1f78835:	cmp    $0xfffe,%rsi
 1f7883c:	mov    $0xfffe,%ecx
 1f78841:	mov    %r11,%rdi
 1f78844:	mov    %eax,%r11d
 1f78847:	movb   $0x6,0xb(%rsp)
 1f7884c:	movq   $0x0,0x10(%rsp)
 1f78855:	mov    (%r8),%r8d
 1f78858:	mov    %eax,0x74(%r12)
 1f7885d:	cmovb  %rsi,%rcx
 1f78861:	shl    $0x5,%r11
 1f78865:	mov    0x28(%r12),%r10
 1f7886a:	inc    %ecx
 1f7886c:	mov    %edx,(%r10,%r11,1)
 1f78870:	mov    %r8d,0x4(%r10,%r11,1)
 1f78875:	mov    %r9d,0x8(%r10,%r11,1)
 1f7887a:	movl   $0x0,0xc(%r10,%r11,1)
 1f78883:	mov    %rsi,0x10(%r10,%r11,1)
 1f78888:	movw   $0x104,0x18(%r10,%r11,1)
 1f78890:	mov    %cx,0x1a(%r10,%r11,1)
 1f78896:	movl   $0x0,0x1c(%r10,%r11,1)
 1f7889f:	mov    %rdi,%r11
 1f788a2:	mov    0x28(%rsp),%rdi
 1f788a7:	mov    0x38(%rsp),%r10
 1f788ac:	nopl   0x0(%rax)
 1f788b0:	mov    %ebx,%r9d
 1f788b3:	mov    0xc(%rsp),%ebx
 1f788b7:	movzbl 0xa(%rsp),%r8d
 1f788bd:	mov    0x960(%r12),%rdx
 1f788c5:	mov    %r13d,%ecx
 1f788c8:	movzbl 0xb(%rsp),%esi
 1f788cd:	mov    %r15b,(%rdx,%rcx,1)
 1f788d1:	mov    0x950(%r12),%rdx
 1f788d9:	mov    %r8b,(%rdx,%rcx,1)
 1f788dd:	mov    0x958(%r12),%rdx
 1f788e5:	mov    %sil,(%rdx,%rcx,1)
 1f788e9:	mov    0x4c(%rsp),%esi
 1f788ed:	mov    0x970(%r12),%rdx
 1f788f5:	mov    %bx,(%rdx,%rcx,2)
 1f788f9:	mov    0x978(%r12),%rdx
 1f78901:	mov    %si,(%rdx,%rcx,2)
 1f78905:	mov    0x980(%r12),%rdx
 1f7890d:	mov    %eax,(%rdx,%rcx,4)
 1f78910:	mov    0x10(%rsp),%rdx
 1f78915:	mov    0x988(%r12),%rax
 1f7891d:	mov    %dx,(%rax,%rcx,2)
 1f78921:	mov    0x8(%rdi),%rax
 1f78925:	mov    0x98(%rax),%rax
 1f7892c:	movzbl (%rax,%r11,1),%eax
 1f78931:	cmp    $0x49,%eax
 1f78934:	je     1f77d10 <node_facts_front_expression+0xf0>
 1f7893a:	cmp    $0x53,%eax
 1f7893d:	je     1f77d10 <node_facts_front_expression+0xf0>
 1f78943:	mov    0x16a0(%rdi),%rax
 1f7894a:	mov    (%rax,%r11,4),%r11d
 1f7894e:	jmp    1f77d10 <node_facts_front_expression+0xf0>
 1f78953:	mov    %r11d,%edx
 1f78956:	vpbroadcastd %r15d,%zmm2
 1f7895c:	and    $0xffffffc0,%edx
 1f7895f:	mov    %eax,%edi
 1f78961:	mov    %rdx,0x50(%rsp)
 1f78966:	vmovdqa64 %zmm2,%zmm3
 1f7896c:	vmovdqa64 %zmm2,%zmm4
 1f78972:	vmovdqa64 %zmm2,%zmm5
 1f78978:	nopl   0x0(%rax,%rax,1)
 1f78980:	mov    %edi,%ecx
 1f78982:	vpmovzxwd (%r10,%rcx,2),%zmm6
 1f78989:	vpmovzxwd 0x40(%r10,%rcx,2),%zmm8
 1f78991:	vpmovzxwd 0x20(%r10,%rcx,2),%zmm7
 1f78999:	vpmovzxwd 0x60(%r10,%rcx,2),%zmm9
 1f789a1:	add    $0x40,%edi
 1f789a4:	add    $0xffffffffffffffc0,%rdx
 1f789a8:	vpsubd %zmm6,%zmm0,%zmm6
 1f789ae:	vpsubd %zmm7,%zmm0,%zmm11
 1f789b4:	vpsubd %zmm9,%zmm0,%zmm7
 1f789ba:	vpsubd %zmm8,%zmm0,%zmm8
 1f789c0:	vpmovzxdq %ymm6,%zmm12
 1f789c6:	vextracti64x4 $0x1,%zmm6,%ymm9
 1f789cd:	vextracti64x4 $0x1,%zmm11,%ymm6
 1f789d4:	vpmovzxdq %ymm11,%zmm11
 1f789da:	vpmovzxdq %ymm7,%zmm15
 1f789e0:	vpmovzxdq %ymm9,%zmm10
 1f789e6:	vpmovzxdq %ymm6,%zmm9
 1f789ec:	vextracti64x4 $0x1,%zmm8,%ymm6
 1f789f3:	vpmovzxdq %ymm8,%zmm8
 1f789f9:	vpmovzxdq %ymm6,%zmm6
 1f789ff:	vmovd  %xmm12,%ecx
 1f78a03:	vpextrq $0x1,%xmm12,%rbx
 1f78a09:	vextracti128 $0x1,%ymm12,%xmm13
 1f78a0f:	movzbl (%r9,%rcx,1),%ecx
 1f78a14:	vmovd  %xmm13,%esi
 1f78a18:	vmovd  %ecx,%xmm14
 1f78a1c:	vpinsrb $0x1,(%r9,%rbx,1),%xmm14,%xmm14
 1f78a23:	vpextrq $0x1,%xmm13,%rcx
 1f78a29:	vextracti32x4 $0x2,%zmm12,%xmm13
 1f78a30:	vextracti32x4 $0x3,%zmm12,%xmm12
 1f78a37:	vpinsrb $0x2,(%r9,%rsi,1),%xmm14,%xmm14
 1f78a3e:	vpextrq $0x1,%xmm13,%rsi
 1f78a44:	vpinsrb $0x3,(%r9,%rcx,1),%xmm14,%xmm14
 1f78a4b:	vmovd  %xmm13,%ecx
 1f78a4f:	vpinsrb $0x4,(%r9,%rcx,1),%xmm14,%xmm13
 1f78a56:	vpextrq $0x1,%xmm12,%rcx
 1f78a5c:	vpinsrb $0x5,(%r9,%rsi,1),%xmm13,%xmm13
 1f78a63:	vmovd  %xmm12,%esi
 1f78a67:	vpinsrb $0x6,(%r9,%rsi,1),%xmm13,%xmm12
 1f78a6e:	vmovd  %xmm10,%esi
 1f78a72:	vextracti128 $0x1,%ymm10,%xmm13
 1f78a78:	vpinsrb $0x7,(%r9,%rcx,1),%xmm12,%xmm12
 1f78a7f:	vpextrq $0x1,%xmm10,%rcx
 1f78a85:	vpinsrb $0x8,(%r9,%rsi,1),%xmm12,%xmm12
 1f78a8c:	vmovd  %xmm13,%esi
 1f78a90:	vpinsrb $0x9,(%r9,%rcx,1),%xmm12,%xmm12
 1f78a97:	vpextrq $0x1,%xmm13,%rcx
 1f78a9d:	vextracti128 $0x1,%ymm11,%xmm13
 1f78aa3:	vpinsrb $0xa,(%r9,%rsi,1),%xmm12,%xmm12
 1f78aaa:	vmovd  %xmm11,%esi
 1f78aae:	movzbl (%r9,%rsi,1),%esi
 1f78ab3:	vpinsrb $0xb,(%r9,%rcx,1),%xmm12,%xmm12
 1f78aba:	vpextrq $0x1,%xmm11,%rcx
 1f78ac0:	vmovd  %esi,%xmm14
 1f78ac4:	vpinsrb $0x1,(%r9,%rcx,1),%xmm14,%xmm14
 1f78acb:	vmovd  %xmm13,%esi
 1f78acf:	vpextrq $0x1,%xmm13,%rcx
 1f78ad5:	vextracti32x4 $0x2,%zmm11,%xmm13
 1f78adc:	vextracti32x4 $0x3,%zmm11,%xmm11
 1f78ae3:	vpinsrb $0x2,(%r9,%rsi,1),%xmm14,%xmm14
 1f78aea:	vmovd  %xmm13,%esi
 1f78aee:	vpinsrb $0x3,(%r9,%rcx,1),%xmm14,%xmm14
 1f78af5:	vpextrq $0x1,%xmm13,%rcx
 1f78afb:	vextracti32x4 $0x2,%zmm10,%xmm13
 1f78b02:	vextracti32x4 $0x3,%zmm10,%xmm10
 1f78b09:	vpinsrb $0x4,(%r9,%rsi,1),%xmm14,%xmm14
 1f78b10:	vmovd  %xmm13,%esi
 1f78b14:	vpinsrb $0xc,(%r9,%rsi,1),%xmm12,%xmm12
 1f78b1b:	vmovd  %xmm11,%esi
 1f78b1f:	vpinsrb $0x5,(%r9,%rcx,1),%xmm14,%xmm14
 1f78b26:	vpextrq $0x1,%xmm11,%rcx
 1f78b2c:	vpinsrb $0x6,(%r9,%rsi,1),%xmm14,%xmm11
 1f78b33:	vmovd  %xmm9,%esi
 1f78b37:	vpinsrb $0x7,(%r9,%rcx,1),%xmm11,%xmm11
 1f78b3e:	vpextrq $0x1,%xmm9,%rcx
 1f78b44:	vpinsrb $0x8,(%r9,%rsi,1),%xmm11,%xmm11
 1f78b4b:	vpextrq $0x1,%xmm13,%rsi
 1f78b51:	vextracti128 $0x1,%ymm9,%xmm13
 1f78b57:	vpinsrb $0xd,(%r9,%rsi,1),%xmm12,%xmm12
 1f78b5e:	vpextrq $0x1,%xmm8,%rsi
 1f78b64:	vpinsrb $0x9,(%r9,%rcx,1),%xmm11,%xmm11
 1f78b6b:	vmovd  %xmm13,%ecx
 1f78b6f:	vpinsrb $0xa,(%r9,%rcx,1),%xmm11,%xmm11
 1f78b76:	vpextrq $0x1,%xmm13,%rcx
 1f78b7c:	vextracti32x4 $0x2,%zmm9,%xmm13
 1f78b83:	vextracti32x4 $0x3,%zmm9,%xmm9
 1f78b8a:	vpinsrb $0xb,(%r9,%rcx,1),%xmm11,%xmm11
 1f78b91:	vmovd  %xmm13,%ecx
 1f78b95:	vpinsrb $0xc,(%r9,%rcx,1),%xmm11,%xmm11
 1f78b9c:	vmovd  %xmm8,%ecx
 1f78ba0:	movzbl (%r9,%rcx,1),%ecx
 1f78ba5:	vmovd  %ecx,%xmm14
 1f78ba9:	vpinsrb $0x1,(%r9,%rsi,1),%xmm14,%xmm14
 1f78bb0:	vpextrq $0x1,%xmm13,%rcx
 1f78bb6:	vextracti128 $0x1,%ymm8,%xmm13
 1f78bbc:	vmovd  %xmm13,%esi
 1f78bc0:	vpinsrb $0xd,(%r9,%rcx,1),%xmm11,%xmm11
 1f78bc7:	vpextrq $0x1,%xmm10,%rcx
 1f78bcd:	vpinsrb $0x2,(%r9,%rsi,1),%xmm14,%xmm14
 1f78bd4:	vmovd  %xmm10,%esi
 1f78bd8:	vextracti64x4 $0x1,%zmm7,%ymm10
 1f78bdf:	vpinsrb $0xe,(%r9,%rsi,1),%xmm12,%xmm7
 1f78be6:	vpextrq $0x1,%xmm13,%rsi
 1f78bec:	vextracti32x4 $0x2,%zmm8,%xmm13
 1f78bf3:	vextracti32x4 $0x3,%zmm8,%xmm8
 1f78bfa:	vpinsrb $0x3,(%r9,%rsi,1),%xmm14,%xmm12
 1f78c01:	vmovd  %xmm9,%esi
 1f78c05:	vpinsrb $0xe,(%r9,%rsi,1),%xmm11,%xmm11
 1f78c0c:	vmovd  %xmm13,%esi
 1f78c10:	vpinsrb $0xf,(%r9,%rcx,1),%xmm7,%xmm7
 1f78c17:	vmovd  %xmm8,%ecx
 1f78c1b:	vpinsrb $0x4,(%r9,%rsi,1),%xmm12,%xmm12
 1f78c22:	vpextrq $0x1,%xmm13,%rsi
 1f78c28:	vpinsrb $0x5,(%r9,%rsi,1),%xmm12,%xmm12
 1f78c2f:	vpextrq $0x1,%xmm8,%rsi
 1f78c35:	vpcmpneqb %xmm16,%xmm7,%k4
 1f78c3c:	vpmovzxbd %xmm7,%zmm7
 1f78c42:	vpinsrb $0x6,(%r9,%rcx,1),%xmm12,%xmm8
 1f78c49:	vmovd  %xmm6,%ecx
 1f78c4d:	vpinsrb $0x7,(%r9,%rsi,1),%xmm8,%xmm8
 1f78c54:	vpextrq $0x1,%xmm6,%rsi
 1f78c5a:	vpinsrb $0x8,(%r9,%rcx,1),%xmm8,%xmm8
 1f78c61:	vpextrq $0x1,%xmm9,%rcx
 1f78c67:	vextracti128 $0x1,%ymm6,%xmm9
 1f78c6d:	vpinsrb $0x9,(%r9,%rsi,1),%xmm8,%xmm8
 1f78c74:	vmovd  %xmm9,%esi
 1f78c78:	vpinsrb $0xa,(%r9,%rsi,1),%xmm8,%xmm8
 1f78c7f:	vpextrq $0x1,%xmm9,%rsi
 1f78c85:	vextracti32x4 $0x2,%zmm6,%xmm9
 1f78c8c:	vextracti32x4 $0x3,%zmm6,%xmm6
 1f78c93:	vpinsrb $0xb,(%r9,%rsi,1),%xmm8,%xmm8
 1f78c9a:	vmovd  %xmm9,%esi
 1f78c9e:	vpinsrb $0xc,(%r9,%rsi,1),%xmm8,%xmm8
 1f78ca5:	vpextrq $0x1,%xmm9,%rsi
 1f78cab:	vpinsrb $0xf,(%r9,%rcx,1),%xmm11,%xmm9
 1f78cb2:	vpextrq $0x1,%xmm15,%rcx
 1f78cb8:	vextracti128 $0x1,%ymm15,%xmm11
 1f78cbe:	vpinsrb $0xd,(%r9,%rsi,1),%xmm8,%xmm8
 1f78cc5:	vmovd  %xmm6,%esi
 1f78cc9:	vpinsrb $0xe,(%r9,%rsi,1),%xmm8,%xmm8
 1f78cd0:	vmovd  %xmm15,%esi
 1f78cd4:	vpcmpneqb %xmm16,%xmm9,%k3
 1f78cdb:	vpmovzxbd %xmm9,%zmm9
 1f78ce1:	movzbl (%r9,%rsi,1),%esi
 1f78ce6:	vmovd  %esi,%xmm12
 1f78cea:	vpinsrb $0x1,(%r9,%rcx,1),%xmm12,%xmm12
 1f78cf1:	vmovd  %xmm11,%esi
 1f78cf5:	vpextrq $0x1,%xmm11,%rcx
 1f78cfb:	vextracti32x4 $0x2,%zmm15,%xmm11
 1f78d02:	vpinsrb $0x2,(%r9,%rsi,1),%xmm12,%xmm12
 1f78d09:	vmovd  %xmm11,%esi
 1f78d0d:	vpinsrb $0x3,(%r9,%rcx,1),%xmm12,%xmm12
 1f78d14:	vpextrq $0x1,%xmm11,%rcx
 1f78d1a:	vpinsrb $0x4,(%r9,%rsi,1),%xmm12,%xmm11
 1f78d21:	vpextrq $0x1,%xmm6,%rsi
 1f78d27:	vpmovzxdq %ymm10,%zmm6
 1f78d2d:	vextracti32x4 $0x3,%zmm15,%xmm10
 1f78d34:	vpinsrb $0xf,(%r9,%rsi,1),%xmm8,%xmm8
 1f78d3b:	vmovd  %xmm10,%esi
 1f78d3f:	vpinsrb $0x5,(%r9,%rcx,1),%xmm11,%xmm11
 1f78d46:	vpextrq $0x1,%xmm10,%rcx
 1f78d4c:	vpinsrb $0x6,(%r9,%rsi,1),%xmm11,%xmm10
 1f78d53:	vmovd  %xmm6,%esi
 1f78d57:	vextracti128 $0x1,%ymm6,%xmm11
 1f78d5d:	vpcmpneqb %xmm16,%xmm8,%k2
 1f78d64:	vpmovzxbd %xmm8,%zmm8
 1f78d6a:	vpinsrb $0x7,(%r9,%rcx,1),%xmm10,%xmm10
 1f78d71:	vpextrq $0x1,%xmm6,%rcx
 1f78d77:	vpsrld $0x4,%zmm8,%zmm12
 1f78d7e:	vpandd %zmm17,%zmm8,%zmm8
 1f78d84:	vpcmpgtd %zmm1,%zmm8,%k6
 1f78d8a:	vpmovm2d %k6,%zmm8
 1f78d90:	vpsubd %zmm8,%zmm12,%zmm8
 1f78d96:	vpinsrb $0x8,(%r9,%rsi,1),%xmm10,%xmm10
 1f78d9d:	vmovd  %xmm11,%esi
 1f78da1:	vpmaxud %zmm4,%zmm8,%zmm4{%k2}
 1f78da7:	vpinsrb $0x9,(%r9,%rcx,1),%xmm10,%xmm10
 1f78dae:	vpextrq $0x1,%xmm11,%rcx
 1f78db4:	vextracti32x4 $0x2,%zmm6,%xmm11
 1f78dbb:	vextracti32x4 $0x3,%zmm6,%xmm6
 1f78dc2:	vpinsrb $0xa,(%r9,%rsi,1),%xmm10,%xmm10
 1f78dc9:	vmovd  %xmm11,%esi
 1f78dcd:	vpinsrb $0xb,(%r9,%rcx,1),%xmm10,%xmm10
 1f78dd4:	vpextrq $0x1,%xmm11,%rcx
 1f78dda:	vpsrld $0x4,%zmm9,%zmm11
 1f78de1:	vpandd %zmm17,%zmm9,%zmm9
 1f78de7:	vpcmpgtd %zmm1,%zmm9,%k5
 1f78ded:	vpinsrb $0xc,(%r9,%rsi,1),%xmm10,%xmm10
 1f78df4:	vmovd  %xmm6,%esi
 1f78df8:	vpinsrb $0xd,(%r9,%rcx,1),%xmm10,%xmm10
 1f78dff:	vpextrq $0x1,%xmm6,%rcx
 1f78e05:	vpinsrb $0xe,(%r9,%rsi,1),%xmm10,%xmm6
 1f78e0c:	vpsrld $0x4,%zmm7,%zmm10
 1f78e13:	vpandd %zmm17,%zmm7,%zmm7
 1f78e19:	vpcmpgtd %zmm1,%zmm7,%k0
 1f78e1f:	vpmovm2d %k5,%zmm7
 1f78e25:	vpsubd %zmm7,%zmm11,%zmm7
 1f78e2b:	vpmaxud %zmm3,%zmm7,%zmm3{%k3}
 1f78e31:	vpinsrb $0xf,(%r9,%rcx,1),%xmm6,%xmm6
 1f78e38:	vpcmpneqb %xmm16,%xmm6,%k1
 1f78e3f:	vpmovzxbd %xmm6,%zmm6
 1f78e45:	vpsrld $0x4,%zmm6,%zmm13
 1f78e4c:	vpandd %zmm17,%zmm6,%zmm6
 1f78e52:	vpcmpgtd %zmm1,%zmm6,%k7
 1f78e58:	vpmovm2d %k0,%zmm6
 1f78e5e:	vpsubd %zmm6,%zmm10,%zmm6
 1f78e64:	vpmovm2d %k7,%zmm9
 1f78e6a:	vpsubd %zmm9,%zmm13,%zmm9
 1f78e70:	vpmaxud %zmm2,%zmm6,%zmm2{%k4}
 1f78e76:	vpmaxud %zmm5,%zmm9,%zmm5{%k1}
 1f78e7c:	jne    1f78980 <node_facts_front_expression+0xd60>
 1f78e82:	vpmaxud %zmm3,%zmm2,%zmm2
 1f78e88:	vpmaxud %zmm5,%zmm4,%zmm3
 1f78e8e:	mov    0x50(%rsp),%rdi
 1f78e93:	vpmaxud %zmm3,%zmm2,%zmm2
 1f78e99:	vextracti64x4 $0x1,%zmm2,%ymm3
 1f78ea0:	vpmaxud %ymm3,%ymm2,%ymm2
 1f78ea5:	vextracti128 $0x1,%ymm2,%xmm3
 1f78eab:	vpmaxud %xmm3,%xmm2,%xmm2
 1f78eb0:	vpshufd $0xee,%xmm2,%xmm3
 1f78eb5:	vpmaxud %xmm3,%xmm2,%xmm2
 1f78eba:	vpshufd $0x55,%xmm2,%xmm3
 1f78ebf:	vpmaxud %xmm3,%xmm2,%xmm2
 1f78ec4:	vmovd  %xmm2,%r15d
 1f78ec9:	cmp    %r11d,%edi
 1f78ecc:	je     1f786a7 <node_facts_front_expression+0xa87>
 1f78ed2:	test   $0x30,%r11b
 1f78ed6:	je     1f78689 <node_facts_front_expression+0xa69>
 1f78edc:	mov    %r11d,%esi
 1f78edf:	and    $0xfffffff0,%esi
 1f78ee2:	mov    %rdi,%rcx
 1f78ee5:	mov    %rdi,%rdx
 1f78ee8:	vpbroadcastd %r15d,%zmm2
 1f78eee:	add    %eax,%ecx
 1f78ef0:	sub    %rsi,%rdx
 1f78ef3:	mov    %rsi,%rbx
 1f78ef6:	cs nopw 0x0(%rax,%rax,1)
 1f78f00:	mov    %ecx,%esi
 1f78f02:	vpmovzxwd (%r10,%rsi,2),%zmm3
 1f78f09:	add    $0x10,%ecx
 1f78f0c:	add    $0x10,%rdx
 1f78f10:	vpsubd %zmm3,%zmm0,%zmm3
 1f78f16:	vextracti64x4 $0x1,%zmm3,%ymm4
 1f78f1d:	vpmovzxdq %ymm3,%zmm3
 1f78f23:	vpmovzxdq %ymm4,%zmm4
 1f78f29:	vmovd  %xmm3,%edi
 1f78f2d:	vpextrq $0x1,%xmm3,%rsi
 1f78f33:	vextracti128 $0x1,%ymm3,%xmm5
 1f78f39:	movzbl (%r9,%rdi,1),%edi
 1f78f3e:	vmovd  %edi,%xmm6
 1f78f42:	vpinsrb $0x1,(%r9,%rsi,1),%xmm6,%xmm6
 1f78f49:	vmovd  %xmm5,%edi
 1f78f4d:	vpextrq $0x1,%xmm5,%rsi
 1f78f53:	vextracti32x4 $0x2,%zmm3,%xmm5
 1f78f5a:	vextracti32x4 $0x3,%zmm3,%xmm3
 1f78f61:	vpinsrb $0x2,(%r9,%rdi,1),%xmm6,%xmm6
 1f78f68:	vmovd  %xmm5,%edi
 1f78f6c:	vpinsrb $0x3,(%r9,%rsi,1),%xmm6,%xmm6
 1f78f73:	vpextrq $0x1,%xmm5,%rsi
 1f78f79:	vpinsrb $0x4,(%r9,%rdi,1),%xmm6,%xmm5
 1f78f80:	vmovd  %xmm3,%edi
 1f78f84:	vpinsrb $0x5,(%r9,%rsi,1),%xmm5,%xmm5
 1f78f8b:	vpextrq $0x1,%xmm3,%rsi
 1f78f91:	vpinsrb $0x6,(%r9,%rdi,1),%xmm5,%xmm3
 1f78f98:	vmovd  %xmm4,%edi
 1f78f9c:	vextracti128 $0x1,%ymm4,%xmm5
 1f78fa2:	vpinsrb $0x7,(%r9,%rsi,1),%xmm3,%xmm3
 1f78fa9:	vpextrq $0x1,%xmm4,%rsi
 1f78faf:	vpinsrb $0x8,(%r9,%rdi,1),%xmm3,%xmm3
 1f78fb6:	vmovd  %xmm5,%edi
 1f78fba:	vpinsrb $0x9,(%r9,%rsi,1),%xmm3,%xmm3
 1f78fc1:	vpextrq $0x1,%xmm5,%rsi
 1f78fc7:	vextracti32x4 $0x2,%zmm4,%xmm5
 1f78fce:	vextracti32x4 $0x3,%zmm4,%xmm4
 1f78fd5:	vpinsrb $0xa,(%r9,%rdi,1),%xmm3,%xmm3
 1f78fdc:	vmovd  %xmm5,%edi
 1f78fe0:	vpinsrb $0xb,(%r9,%rsi,1),%xmm3,%xmm3
 1f78fe7:	vpextrq $0x1,%xmm5,%rsi
 1f78fed:	vpinsrb $0xc,(%r9,%rdi,1),%xmm3,%xmm3
 1f78ff4:	vmovd  %xmm4,%edi
 1f78ff8:	vpinsrb $0xd,(%r9,%rsi,1),%xmm3,%xmm3
 1f78fff:	vpextrq $0x1,%xmm4,%rsi
 1f79005:	vpinsrb $0xe,(%r9,%rdi,1),%xmm3,%xmm3
 1f7900c:	vpinsrb $0xf,(%r9,%rsi,1),%xmm3,%xmm3
 1f79013:	vpcmpneqb %xmm16,%xmm3,%k1
 1f7901a:	vpmovzxbd %xmm3,%zmm3
 1f79020:	vpandd %zmm17,%zmm3,%zmm4
 1f79026:	vpsrld $0x4,%zmm3,%zmm3
 1f7902d:	vpcmpgtd %zmm1,%zmm4,%k0
 1f79033:	vpmovm2d %k0,%zmm4
 1f79039:	vpsubd %zmm4,%zmm3,%zmm3
 1f7903f:	vpmaxud %zmm2,%zmm3,%zmm2{%k1}
 1f79045:	jne    1f78f00 <node_facts_front_expression+0x12e0>
 1f7904b:	vextracti64x4 $0x1,%zmm2,%ymm0
 1f79052:	mov    %rbx,%rdi
 1f79055:	vpmaxud %ymm0,%ymm2,%ymm0
 1f7905a:	vextracti128 $0x1,%ymm0,%xmm1
 1f79060:	vpmaxud %xmm1,%xmm0,%xmm0
 1f79065:	vpshufd $0xee,%xmm0,%xmm1
 1f7906a:	vpmaxud %xmm1,%xmm0,%xmm0
 1f7906f:	vpshufd $0x55,%xmm0,%xmm1
 1f79074:	vpmaxud %xmm1,%xmm0,%xmm0
 1f79079:	vmovd  %xmm0,%r15d
 1f7907e:	cmp    %r11d,%edi
 1f79081:	jne    1f78689 <node_facts_front_expression+0xa69>
 1f79087:	jmp    1f786a7 <node_facts_front_expression+0xa87>
 1f7908c:	mov    %rbp,%r10
 1f7908f:	xor    %r8d,%r8d
 1f79092:	xor    %edi,%edi
 1f79094:	xor    %r9d,%r9d
 1f79097:	xor    %ebp,%ebp
 1f79099:	movq   $0x0,0x18(%rsp)
 1f790a2:	jmp    1f781e2 <node_facts_front_expression+0x5c2>
 1f790a7:	mov    %r9d,%edx
 1f790aa:	sub    %eax,%edx
 1f790ac:	inc    %edx
 1f790ae:	cmp    0x10(%r10),%edx
 1f790b2:	setae  %dl
 1f790b5:	test   %eax,%eax
 1f790b7:	jne    1f77c7c <node_facts_front_expression+0x5c>
 1f790bd:	mov    $0x1,%eax
 1f790c2:	jmp    1f790cd <node_facts_front_expression+0x14ad>
 1f790c4:	mov    %esi,%eax
 1f790c6:	jmp    1f790cd <node_facts_front_expression+0x14ad>
 1f790c8:	mov    $0x2,%eax
 1f790cd:	add    $0xb8,%rsp
 1f790d4:	pop    %rbx
 1f790d5:	pop    %r12
 1f790d7:	pop    %r13
 1f790d9:	pop    %r14
 1f790db:	pop    %r15
 1f790dd:	pop    %rbp
 1f790de:	vzeroupper
 1f790e1:	ret
 1f790e2:	mov    $0x3,%eax
 1f790e7:	jmp    1f790cd <node_facts_front_expression+0x14ad>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
