
results/costv1/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f7d3d0 <node_facts_window_run>:
 1f7d3d0:	push   %rbp
 1f7d3d1:	push   %r15
 1f7d3d3:	push   %r14
 1f7d3d5:	push   %r13
 1f7d3d7:	push   %r12
 1f7d3d9:	push   %rbx
 1f7d3da:	sub    $0xca8,%rsp
 1f7d3e1:	mov    0x940(%rdi),%r14
 1f7d3e8:	mov    0x8(%rsi),%r15d
 1f7d3ec:	mov    %rsi,%r10
 1f7d3ef:	test   %r15,%r15
 1f7d3f2:	je     1f7d5b7 <node_facts_window_run+0x1e7>
 1f7d3f8:	mov    %r15d,%eax
 1f7d3fb:	and    $0x7,%eax
 1f7d3fe:	cmp    $0x8,%r15d
 1f7d402:	jae    1f7d40b <node_facts_window_run+0x3b>
 1f7d404:	xor    %ecx,%ecx
 1f7d406:	jmp    1f7d9bf <node_facts_window_run+0x5ef>
 1f7d40b:	mov    %r15d,%edx
 1f7d40e:	and    $0xfffffff8,%edx
 1f7d411:	xor    %ecx,%ecx
 1f7d413:	jmp    1f7d43b <node_facts_window_run+0x6b>
 1f7d415:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7d420:	xor    %esi,%esi
 1f7d422:	mov    0x9c0(%rdi),%r8
 1f7d429:	mov    %sil,0x7(%r8,%rcx,1)
 1f7d42e:	add    $0x8,%rcx
 1f7d432:	cmp    %rcx,%rdx
 1f7d435:	je     1f7d5ae <node_facts_window_run+0x1de>
 1f7d43b:	mov    0x9b8(%rdi),%rsi
 1f7d442:	cmpb   $0x0,(%rsi,%rcx,1)
 1f7d446:	je     1f7d460 <node_facts_window_run+0x90>
 1f7d448:	movzbl 0x69454(%r10,%rcx,1),%esi
 1f7d451:	jmp    1f7d462 <node_facts_window_run+0x92>
 1f7d453:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d460:	xor    %esi,%esi
 1f7d462:	mov    0x9c0(%rdi),%r8
 1f7d469:	mov    %sil,(%r8,%rcx,1)
 1f7d46d:	mov    0x9b8(%rdi),%rsi
 1f7d474:	cmpb   $0x0,0x1(%rsi,%rcx,1)
 1f7d479:	je     1f7d490 <node_facts_window_run+0xc0>
 1f7d47b:	movzbl 0x69455(%r10,%rcx,1),%esi
 1f7d484:	jmp    1f7d492 <node_facts_window_run+0xc2>
 1f7d486:	cs nopw 0x0(%rax,%rax,1)
 1f7d490:	xor    %esi,%esi
 1f7d492:	mov    0x9c0(%rdi),%r8
 1f7d499:	mov    %sil,0x1(%r8,%rcx,1)
 1f7d49e:	mov    0x9b8(%rdi),%rsi
 1f7d4a5:	cmpb   $0x0,0x2(%rsi,%rcx,1)
 1f7d4aa:	je     1f7d4c0 <node_facts_window_run+0xf0>
 1f7d4ac:	movzbl 0x69456(%r10,%rcx,1),%esi
 1f7d4b5:	jmp    1f7d4c2 <node_facts_window_run+0xf2>
 1f7d4b7:	nopw   0x0(%rax,%rax,1)
 1f7d4c0:	xor    %esi,%esi
 1f7d4c2:	mov    0x9c0(%rdi),%r8
 1f7d4c9:	mov    %sil,0x2(%r8,%rcx,1)
 1f7d4ce:	mov    0x9b8(%rdi),%rsi
 1f7d4d5:	cmpb   $0x0,0x3(%rsi,%rcx,1)
 1f7d4da:	je     1f7d4f0 <node_facts_window_run+0x120>
 1f7d4dc:	movzbl 0x69457(%r10,%rcx,1),%esi
 1f7d4e5:	jmp    1f7d4f2 <node_facts_window_run+0x122>
 1f7d4e7:	nopw   0x0(%rax,%rax,1)
 1f7d4f0:	xor    %esi,%esi
 1f7d4f2:	mov    0x9c0(%rdi),%r8
 1f7d4f9:	mov    %sil,0x3(%r8,%rcx,1)
 1f7d4fe:	mov    0x9b8(%rdi),%rsi
 1f7d505:	cmpb   $0x0,0x4(%rsi,%rcx,1)
 1f7d50a:	je     1f7d520 <node_facts_window_run+0x150>
 1f7d50c:	movzbl 0x69458(%r10,%rcx,1),%esi
 1f7d515:	jmp    1f7d522 <node_facts_window_run+0x152>
 1f7d517:	nopw   0x0(%rax,%rax,1)
 1f7d520:	xor    %esi,%esi
 1f7d522:	mov    0x9c0(%rdi),%r8
 1f7d529:	mov    %sil,0x4(%r8,%rcx,1)
 1f7d52e:	mov    0x9b8(%rdi),%rsi
 1f7d535:	cmpb   $0x0,0x5(%rsi,%rcx,1)
 1f7d53a:	je     1f7d550 <node_facts_window_run+0x180>
 1f7d53c:	movzbl 0x69459(%r10,%rcx,1),%esi
 1f7d545:	jmp    1f7d552 <node_facts_window_run+0x182>
 1f7d547:	nopw   0x0(%rax,%rax,1)
 1f7d550:	xor    %esi,%esi
 1f7d552:	mov    0x9c0(%rdi),%r8
 1f7d559:	mov    %sil,0x5(%r8,%rcx,1)
 1f7d55e:	mov    0x9b8(%rdi),%rsi
 1f7d565:	cmpb   $0x0,0x6(%rsi,%rcx,1)
 1f7d56a:	je     1f7d580 <node_facts_window_run+0x1b0>
 1f7d56c:	movzbl 0x6945a(%r10,%rcx,1),%esi
 1f7d575:	jmp    1f7d582 <node_facts_window_run+0x1b2>
 1f7d577:	nopw   0x0(%rax,%rax,1)
 1f7d580:	xor    %esi,%esi
 1f7d582:	mov    0x9c0(%rdi),%r8
 1f7d589:	mov    %sil,0x6(%r8,%rcx,1)
 1f7d58e:	mov    0x9b8(%rdi),%rsi
 1f7d595:	cmpb   $0x0,0x7(%rsi,%rcx,1)
 1f7d59a:	je     1f7d420 <node_facts_window_run+0x50>
 1f7d5a0:	movzbl 0x6945b(%r10,%rcx,1),%esi
 1f7d5a9:	jmp    1f7d422 <node_facts_window_run+0x52>
 1f7d5ae:	test   %rax,%rax
 1f7d5b1:	jne    1f7d9bf <node_facts_window_run+0x5ef>
 1f7d5b7:	vpbroadcastq %r10,%ymm0
 1f7d5bd:	vpaddq -0x19bbda5(%rip),%ymm0,%ymm0        # 5c1820 <.LCPI3_0>
 1f7d5c5:	vmovups 0x1f0(%rdi),%zmm1
 1f7d5cf:	mov    0x9c0(%rdi),%rax
 1f7d5d6:	mov    0x9c8(%rdi),%rdx
 1f7d5dd:	mov    0x69250(%r10),%r8d
 1f7d5e4:	lea    0x2c(%r10),%r11
 1f7d5e8:	lea    0x6a4d4(%r10),%rcx
 1f7d5ef:	lea    0x79854(%r10),%rsi
 1f7d5f6:	lea    0x73754(%r10),%r9
 1f7d5fd:	mov    %r10,0x18(%rsp)
 1f7d602:	mov    0x230(%rdi),%r10
 1f7d609:	vmovdqu 0x240(%rdi),%xmm3
 1f7d611:	vmovq  0x258(%rdi),%xmm2
 1f7d619:	mov    %r11,0x1f0(%rdi)
 1f7d620:	mov    %rax,0x1f8(%rdi)
 1f7d627:	mov    %rcx,0x200(%rdi)
 1f7d62e:	mov    %rdx,0x208(%rdi)
 1f7d635:	mov    $0x1,%edx
 1f7d63a:	vmovdqu %ymm0,0x210(%rdi)
 1f7d642:	mov    %rsi,0x230(%rdi)
 1f7d649:	mov    %r9,0x240(%rdi)
 1f7d650:	mov    %r8d,0x258(%rdi)
 1f7d657:	vmovups %zmm1,0x850(%rsp)
 1f7d662:	mov    %r10,0x718(%rsp)
 1f7d66a:	vmovdqa %xmm3,0x820(%rsp)
 1f7d673:	vmovdqa %xmm2,0x810(%rsp)
 1f7d67c:	mov    %r11,0xc0(%rsp)
 1f7d684:	xor    %esi,%esi
 1f7d686:	mov    %rdi,(%rsp)
 1f7d68a:	vmovups 0x9d0(%rdi),%zmm0
 1f7d694:	vmovups 0x268(%rdi),%zmm1
 1f7d69e:	vmovups %zmm0,0x268(%rdi)
 1f7d6a8:	vmovups %zmm1,0x9d0(%rdi)
 1f7d6b2:	vmovdqu 0xa10(%rdi),%xmm0
 1f7d6ba:	vmovdqu 0x2a8(%rdi),%xmm1
 1f7d6c2:	vmovdqu %xmm0,0x2a8(%rdi)
 1f7d6ca:	vmovdqu %xmm1,0xa10(%rdi)
 1f7d6d2:	mov    0xa20(%rdi),%rcx
 1f7d6d9:	mov    0x2b8(%rdi),%rax
 1f7d6e0:	mov    %rcx,0x2b8(%rdi)
 1f7d6e7:	lea    0xa28(%rdi),%rcx
 1f7d6ee:	mov    %rax,0xa20(%rdi)
 1f7d6f5:	movl   $0x0,0xa28(%rdi)
 1f7d6ff:	mov    %r15d,0xa2c(%rdi)
 1f7d706:	mov    %rcx,0x248(%rdi)
 1f7d70d:	movl   $0x0,0x25c(%rdi)
 1f7d717:	vzeroupper
 1f7d71a:	call   1f7bb10 <node_facts_given>
 1f7d71f:	mov    (%rsp),%rax
 1f7d723:	mov    (%rsp),%rdi
 1f7d727:	xor    %esi,%esi
 1f7d729:	xor    %edx,%edx
 1f7d72b:	xor    %ecx,%ecx
 1f7d72d:	mov    0xe0(%rax),%rbx
 1f7d734:	call   1f7bd00 <node_facts_window>
 1f7d739:	mov    (%rsp),%rax
 1f7d73d:	mov    (%rsp),%rdi
 1f7d741:	xor    %esi,%esi
 1f7d743:	mov    0xe0(%rax),%rax
 1f7d74a:	sub    %rbx,%rax
 1f7d74d:	add    %rax,0xa30(%r14)
 1f7d754:	call   1f7c950 <node_facts_lists_same>
 1f7d759:	mov    (%rsp),%rdi
 1f7d75d:	test   %al,%al
 1f7d75f:	jne    1f7d7b8 <node_facts_window_run+0x3e8>
 1f7d761:	incq   0xa00(%r14)
 1f7d768:	mov    0x940(%rdi),%rax
 1f7d76f:	mov    0x11e0(%rax),%ecx
 1f7d775:	cmp    $0xf,%rcx
 1f7d779:	ja     1f7d7b8 <node_facts_window_run+0x3e8>
 1f7d77b:	mov    0x18(%rsp),%rdx
 1f7d780:	mov    0x422c(%rdx),%edx
 1f7d786:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7d78d:	mov    0x1f0(%rdi),%rcx
 1f7d794:	mov    0x11e0(%rax),%edx
 1f7d79a:	movzbl (%rcx),%ecx
 1f7d79d:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7d7a4:	mov    0x11e0(%rax),%ecx
 1f7d7aa:	movb   $0x2,0x11d0(%rax,%rcx,1)
 1f7d7b2:	incl   0x11e0(%rax)
 1f7d7b8:	mov    %r15,0xb8(%rsp)
 1f7d7c0:	test   %r15d,%r15d
 1f7d7c3:	je     1f7da8a <node_facts_window_run+0x6ba>
 1f7d7c9:	mov    $0x1a,%r15d
 1f7d7cf:	mov    $0xcc,%ebp
 1f7d7d4:	mov    $0x102,%r12d
 1f7d7da:	mov    $0x8c,%r13d
 1f7d7e0:	xor    %ebx,%ebx
 1f7d7e2:	jmp    1f7d805 <node_facts_window_run+0x435>
 1f7d7e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d7f0:	inc    %rbx
 1f7d7f3:	add    $0x40,%r15
 1f7d7f7:	cmp    %rbx,0xb8(%rsp)
 1f7d7ff:	je     1f7d9d0 <node_facts_window_run+0x600>
 1f7d805:	mov    0x1f8(%rdi),%rax
 1f7d80c:	movzbl (%rax,%rbx,1),%eax
 1f7d810:	cmp    $0x7,%eax
 1f7d813:	ja     1f7d7f0 <node_facts_window_run+0x420>
 1f7d815:	bt     %eax,%ebp
 1f7d818:	jae    1f7d7f0 <node_facts_window_run+0x420>
 1f7d81a:	mov    %eax,%ecx
 1f7d81c:	mov    0x2c0(%rdi),%rsi
 1f7d823:	and    $0xfe,%cl
 1f7d826:	cmp    $0x2,%cl
 1f7d829:	sete   %cl
 1f7d82c:	cmp    $0x7,%eax
 1f7d82f:	sete   %dl
 1f7d832:	or     %cl,%dl
 1f7d834:	movzbl -0x1(%rsi,%r15,1),%ecx
 1f7d83a:	movzbl %dl,%edx
 1f7d83d:	add    %rdx,0x9f0(%r14)
 1f7d844:	cmp    $0x7,%eax
 1f7d847:	ja     1f7d982 <node_facts_window_run+0x5b2>
 1f7d84d:	bt     %eax,%r13d
 1f7d851:	mov    $0x0,%edx
 1f7d856:	jae    1f7d864 <node_facts_window_run+0x494>
 1f7d858:	lea    -0x1(%rcx),%esi
 1f7d85b:	xor    %edx,%edx
 1f7d85d:	cmp    $0x2,%sil
 1f7d861:	setb   %dl
 1f7d864:	add    %rdx,0x9f8(%r14)
 1f7d86b:	xor    %edx,%edx
 1f7d86d:	cmp    $0x7,%eax
 1f7d870:	ja     1f7d886 <node_facts_window_run+0x4b6>
 1f7d872:	bt     %eax,%r13d
 1f7d876:	jae    1f7d886 <node_facts_window_run+0x4b6>
 1f7d878:	mov    0x1f0(%rdi),%rax
 1f7d87f:	cmpb   $0x22,(%rax,%rbx,1)
 1f7d883:	sete   %dl
 1f7d886:	dec    %cl
 1f7d888:	vmovd  %edx,%xmm0
 1f7d88c:	cmp    $0x2,%cl
 1f7d88f:	setb   %al
 1f7d892:	and    %dl,%al
 1f7d894:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f7d89a:	vpmovzxbq %xmm0,%xmm0
 1f7d89f:	vptestmq -0x19af371(%rip){1to2},%xmm0,%k0        # 5ce538 <.LCPI3_1>
 1f7d8a9:	vmovdqu 0xa10(%r14),%xmm0
 1f7d8b2:	vpmovm2q %k0,%xmm1
 1f7d8b8:	vpsubq %xmm1,%xmm0,%xmm0
 1f7d8bc:	vmovdqu %xmm0,0xa10(%r14)
 1f7d8c5:	cmp    $0x1,%al
 1f7d8c7:	jne    1f7d900 <node_facts_window_run+0x530>
 1f7d8c9:	mov    0x2c0(%rdi),%rax
 1f7d8d0:	movzwl (%rax,%r15,1),%eax
 1f7d8d5:	bt     $0x1,%eax
 1f7d8d9:	adcq   $0x0,0xa20(%r14)
 1f7d8e1:	mov    0x2c0(%rdi),%rax
 1f7d8e8:	movzwl (%rax,%r15,1),%eax
 1f7d8ed:	bextr  %r12d,%eax,%eax
 1f7d8f2:	jmp    1f7d902 <node_facts_window_run+0x532>
 1f7d8f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d900:	xor    %eax,%eax
 1f7d902:	add    %rax,0xa28(%r14)
 1f7d909:	xor    %esi,%esi
 1f7d90b:	mov    %ebx,%edx
 1f7d90d:	xor    %ecx,%ecx
 1f7d90f:	call   1f7cf70 <node_facts_same>
 1f7d914:	mov    (%rsp),%rdi
 1f7d918:	mov    0x18(%rsp),%rdx
 1f7d91d:	test   %al,%al
 1f7d91f:	jne    1f7d7f0 <node_facts_window_run+0x420>
 1f7d925:	incq   0xa00(%r14)
 1f7d92c:	mov    0x940(%rdi),%rax
 1f7d933:	mov    0x11e0(%rax),%ecx
 1f7d939:	cmp    $0xf,%rcx
 1f7d93d:	ja     1f7d7f0 <node_facts_window_run+0x420>
 1f7d943:	mov    0x422c(%rdx,%rbx,4),%edx
 1f7d94a:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7d951:	mov    0x1f0(%rdi),%rcx
 1f7d958:	mov    0x11e0(%rax),%edx
 1f7d95e:	movzbl (%rcx,%rbx,1),%ecx
 1f7d962:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7d969:	mov    0x11e0(%rax),%ecx
 1f7d96f:	movb   $0x5,0x11d0(%rax,%rcx,1)
 1f7d977:	incl   0x11e0(%rax)
 1f7d97d:	jmp    1f7d7f0 <node_facts_window_run+0x420>
 1f7d982:	xor    %edx,%edx
 1f7d984:	add    %rdx,0x9f8(%r14)
 1f7d98b:	xor    %edx,%edx
 1f7d98d:	cmp    $0x7,%eax
 1f7d990:	jbe    1f7d872 <node_facts_window_run+0x4a2>
 1f7d996:	jmp    1f7d886 <node_facts_window_run+0x4b6>
 1f7d99b:	nopl   0x0(%rax,%rax,1)
 1f7d9a0:	movzbl 0x69454(%r10,%rcx,1),%edx
 1f7d9a9:	mov    0x9c0(%rdi),%rsi
 1f7d9b0:	mov    %dl,(%rsi,%rcx,1)
 1f7d9b3:	inc    %rcx
 1f7d9b6:	dec    %rax
 1f7d9b9:	je     1f7d5b7 <node_facts_window_run+0x1e7>
 1f7d9bf:	mov    0x9b8(%rdi),%rdx
 1f7d9c6:	cmpb   $0x0,(%rdx,%rcx,1)
 1f7d9ca:	jne    1f7d9a0 <node_facts_window_run+0x5d0>
 1f7d9cc:	xor    %edx,%edx
 1f7d9ce:	jmp    1f7d9a9 <node_facts_window_run+0x5d9>
 1f7d9d0:	mov    $0x3,%edx
 1f7d9d5:	xor    %esi,%esi
 1f7d9d7:	xor    %ebx,%ebx
 1f7d9d9:	call   1f7bb10 <node_facts_given>
 1f7d9de:	mov    (%rsp),%rdi
 1f7d9e2:	xor    %esi,%esi
 1f7d9e4:	xor    %edx,%edx
 1f7d9e6:	xor    %ecx,%ecx
 1f7d9e8:	call   1f7bd00 <node_facts_window>
 1f7d9ed:	mov    (%rsp),%rdi
 1f7d9f1:	mov    0xb8(%rsp),%r15
 1f7d9f9:	jmp    1f7da0c <node_facts_window_run+0x63c>
 1f7d9fb:	nopl   0x0(%rax,%rax,1)
 1f7da00:	inc    %rbx
 1f7da03:	cmp    %rbx,%r15
 1f7da06:	je     1f7daa9 <node_facts_window_run+0x6d9>
 1f7da0c:	mov    0x1f8(%rdi),%rax
 1f7da13:	testb  $0x2,(%rax,%rbx,1)
 1f7da17:	je     1f7da00 <node_facts_window_run+0x630>
 1f7da19:	xor    %esi,%esi
 1f7da1b:	mov    %ebx,%edx
 1f7da1d:	xor    %ecx,%ecx
 1f7da1f:	call   1f7cf70 <node_facts_same>
 1f7da24:	mov    0x18(%rsp),%rdx
 1f7da29:	mov    (%rsp),%rdi
 1f7da2d:	test   %al,%al
 1f7da2f:	jne    1f7da00 <node_facts_window_run+0x630>
 1f7da31:	incq   0xa00(%r14)
 1f7da38:	mov    0x940(%rdi),%rax
 1f7da3f:	mov    0x11e0(%rax),%ecx
 1f7da45:	cmp    $0xf,%rcx
 1f7da49:	ja     1f7da00 <node_facts_window_run+0x630>
 1f7da4b:	mov    0x422c(%rdx,%rbx,4),%edx
 1f7da52:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7da59:	mov    0x1f0(%rdi),%rcx
 1f7da60:	mov    0x11e0(%rax),%edx
 1f7da66:	movzbl (%rcx,%rbx,1),%ecx
 1f7da6a:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7da71:	mov    0x11e0(%rax),%ecx
 1f7da77:	movb   $0x1,0x11d0(%rax,%rcx,1)
 1f7da7f:	incl   0x11e0(%rax)
 1f7da85:	jmp    1f7da00 <node_facts_window_run+0x630>
 1f7da8a:	mov    $0x3,%edx
 1f7da8f:	xor    %esi,%esi
 1f7da91:	call   1f7bb10 <node_facts_given>
 1f7da96:	mov    (%rsp),%rdi
 1f7da9a:	xor    %esi,%esi
 1f7da9c:	xor    %edx,%edx
 1f7da9e:	xor    %ecx,%ecx
 1f7daa0:	call   1f7bd00 <node_facts_window>
 1f7daa5:	mov    (%rsp),%rdi
 1f7daa9:	xor    %esi,%esi
 1f7daab:	xor    %edx,%edx
 1f7daad:	call   1f7bb10 <node_facts_given>
 1f7dab2:	mov    (%rsp),%rax
 1f7dab6:	xor    %esi,%esi
 1f7dab8:	xor    %ecx,%ecx
 1f7daba:	mov    0xd0(%rax),%r15
 1f7dac1:	rdtsc
 1f7dac3:	mov    (%rsp),%rdi
 1f7dac7:	mov    %rdx,%rbx
 1f7daca:	shl    $0x20,%rbx
 1f7dace:	xor    %edx,%edx
 1f7dad0:	or     %rax,%rbx
 1f7dad3:	call   1f7bd00 <node_facts_window>
 1f7dad8:	mov    0x18(%rsp),%rsi
 1f7dadd:	mov    (%rsp),%r11
 1f7dae1:	rdtsc
 1f7dae3:	shl    $0x20,%rdx
 1f7dae7:	or     %rax,%rdx
 1f7daea:	sub    %rbx,%rdx
 1f7daed:	add    %rdx,0xa08(%r14)
 1f7daf4:	mov    0xd0(%r11),%rax
 1f7dafb:	sub    %r15,%rax
 1f7dafe:	mov    0xb8(%rsp),%r15
 1f7db06:	add    %rax,0xa38(%r14)
 1f7db0d:	mov    0x950(%r11),%r13
 1f7db14:	test   %r13,%r13
 1f7db17:	je     1f84c34 <node_facts_window_run+0x7864>
 1f7db1d:	mov    0xb68(%r13),%rax
 1f7db24:	mov    0xad0(%r13),%rdi
 1f7db2b:	lea    0x757d4(%rsi),%r12
 1f7db32:	mov    %rax,0x50(%rsp)
 1f7db37:	mov    (%r11),%rax
 1f7db3a:	mov    %rax,0x80(%rsp)
 1f7db42:	mov    0x948(%r11),%rax
 1f7db49:	mov    %rax,0xa0(%rsp)
 1f7db51:	mov    0x8(%rax),%rax
 1f7db55:	mov    0x78(%rax),%eax
 1f7db58:	mov    %eax,0xa8(%rsp)
 1f7db5f:	movzbl 0xb90(%r13),%eax
 1f7db67:	mov    %al,0x70(%rsp)
 1f7db6b:	rdtsc
 1f7db6d:	mov    0x8(%rsi),%r8d
 1f7db71:	mov    0x2c0(%r11),%r9
 1f7db78:	mov    %rax,0xf0(%rsp)
 1f7db80:	lea    0x3f(%r8),%eax
 1f7db84:	mov    %rdx,0xe8(%rsp)
 1f7db8c:	mov    %rdi,0x40(%rsp)
 1f7db91:	mov    %r13,0x8(%rsp)
 1f7db96:	mov    %r12,0x220(%rsp)
 1f7db9e:	mov    %r8,0x38(%rsp)
 1f7dba3:	mov    %r9,0x20(%rsp)
 1f7dba8:	and    $0xffffffc0,%eax
 1f7dbab:	cmpq   $0x0,0xc20(%r11)
 1f7dbb3:	je     1f7e89d <node_facts_window_run+0x14cd>
 1f7dbb9:	cmpb   $0x1,0xd58(%r11)
 1f7dbc1:	jne    1f7f31c <node_facts_window_run+0x1f4c>
 1f7dbc7:	test   %eax,%eax
 1f7dbc9:	je     1f80850 <node_facts_window_run+0x3480>
 1f7dbcf:	vpbroadcastd -0x19acc6d(%rip),%zmm14        # 5d0f6c <.LCPI3_5>
 1f7dbd9:	vpbroadcastb -0x1ac6ea2(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7dbe2:	vpbroadcastb -0x1ac6eab(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7dbec:	vpbroadcastd -0x19acc82(%rip),%zmm17        # 5d0f74 <.LCPI3_11>
 1f7dbf6:	vpbroadcastd -0x19acc84(%rip),%zmm18        # 5d0f7c <.LCPI3_13>
 1f7dc00:	mov    (%r11),%rcx
 1f7dc03:	lea    0x69454(%rsi),%r10
 1f7dc0a:	lea    0x422c(%rsi),%rdx
 1f7dc11:	mov    %eax,%r15d
 1f7dc14:	xor    %ebp,%ebp
 1f7dc16:	mov    %rcx,0x78(%rsp)
 1f7dc1b:	mov    %r10,0x98(%rsp)
 1f7dc23:	mov    %rdx,0x88(%rsp)
 1f7dc2b:	movq   $0x0,0x48(%rsp)
 1f7dc34:	movq   $0x0,0x28(%rsp)
 1f7dc3d:	movq   $0x0,0x10(%rsp)
 1f7dc46:	mov    %r15,0x90(%rsp)
 1f7dc4e:	jmp    1f7dd26 <node_facts_window_run+0x956>
 1f7dc53:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7dc60:	vpxor  %xmm1,%xmm1,%xmm1
 1f7dc64:	vpxor  %xmm0,%xmm0,%xmm0
 1f7dc68:	vpxor  %xmm5,%xmm5,%xmm5
 1f7dc6c:	vpxor  %xmm4,%xmm4,%xmm4
 1f7dc70:	vpxor  %xmm3,%xmm3,%xmm3
 1f7dc74:	vpxor  %xmm7,%xmm7,%xmm7
 1f7dc78:	vpxor  %xmm8,%xmm8,%xmm8
 1f7dc7d:	vpxor  %xmm9,%xmm9,%xmm9
 1f7dc82:	vpxor  %xmm2,%xmm2,%xmm2
 1f7dc86:	vpxord %xmm20,%xmm20,%xmm20
 1f7dc8c:	mov    0xb10(%r13),%rax
 1f7dc93:	vmovdqu64 %xmm20,(%rax,%rbp,1)
 1f7dc9a:	mov    0xb18(%r13),%rax
 1f7dca1:	vmovdqu %xmm2,(%rax,%rbp,1)
 1f7dca6:	mov    0xb88(%r11),%rax
 1f7dcad:	vmovdqu %xmm9,(%rax,%rbp,1)
 1f7dcb2:	mov    0xb90(%r11),%rax
 1f7dcb9:	vmovdqu %xmm8,(%rax,%rbp,1)
 1f7dcbe:	mov    0xb98(%r11),%rax
 1f7dcc5:	vmovdqu %xmm7,(%rax,%rbp,1)
 1f7dcca:	mov    0xba0(%r11),%rax
 1f7dcd1:	vmovdqu %xmm3,(%rax,%rbp,1)
 1f7dcd6:	mov    0xba8(%r11),%rax
 1f7dcdd:	vmovdqu %xmm4,(%rax,%rbp,1)
 1f7dce2:	mov    0xc28(%r11),%rax
 1f7dce9:	vmovdqu64 %zmm5,(%rax,%rbp,4)
 1f7dcf0:	mov    0xcd8(%r11),%rax
 1f7dcf7:	vmovdqu64 %zmm0,(%rax,%rbp,8)
 1f7dcfe:	mov    0xcd8(%r11),%rax
 1f7dd05:	vmovdqu64 %zmm1,0x40(%rax,%rbp,8)
 1f7dd0d:	mov    0xd60(%r11),%rax
 1f7dd14:	vmovdqu %xmm6,(%rax,%rbp,1)
 1f7dd19:	add    $0x10,%rbp
 1f7dd1d:	cmp    %r15,%rbp
 1f7dd20:	jae    1f8086b <node_facts_window_run+0x349b>
 1f7dd26:	vpxor  %xmm6,%xmm6,%xmm6
 1f7dd2a:	cmp    %r8,%rbp
 1f7dd2d:	jae    1f7dc60 <node_facts_window_run+0x890>
 1f7dd33:	mov    %r8d,%eax
 1f7dd36:	sub    %ebp,%eax
 1f7dd38:	mov    $0x10,%ecx
 1f7dd3d:	mov    $0xffffffff,%edx
 1f7dd42:	vpxor  %xmm12,%xmm12,%xmm12
 1f7dd47:	cmp    $0x10,%eax
 1f7dd4a:	cmovae %ecx,%eax
 1f7dd4d:	mov    0x9b8(%r11),%rcx
 1f7dd54:	shlx   %eax,%edx,%eax
 1f7dd59:	mov    %rbp,%rdx
 1f7dd5c:	shl    $0x6,%rdx
 1f7dd60:	not    %eax
 1f7dd62:	vmovdqu (%r9,%rdx,1),%ymm4
 1f7dd68:	vmovdqu64 0x40(%r9,%rdx,1),%ymm26
 1f7dd70:	vmovdqu64 0x80(%r9,%rdx,1),%ymm27
 1f7dd78:	vmovdqu64 0xc0(%r9,%rdx,1),%ymm28
 1f7dd80:	vmovdqu 0x100(%r9,%rdx,1),%ymm5
 1f7dd8a:	vmovdqu 0x140(%r9,%rdx,1),%ymm6
 1f7dd94:	vmovdqu64 0x180(%r9,%rdx,1),%ymm24
 1f7dd9c:	vmovdqu64 0x1c0(%r9,%rdx,1),%ymm25
 1f7dda4:	vmovdqu 0x200(%r9,%rdx,1),%ymm7
 1f7ddae:	vmovdqu 0x240(%r9,%rdx,1),%ymm13
 1f7ddb8:	vmovdqu64 0x280(%r9,%rdx,1),%ymm22
 1f7ddc0:	vmovdqu64 0x2c0(%r9,%rdx,1),%ymm23
 1f7ddc8:	vmovdqu 0x300(%r9,%rdx,1),%ymm11
 1f7ddd2:	vmovdqu64 0x340(%r9,%rdx,1),%ymm19
 1f7ddda:	vmovdqu64 0x380(%r9,%rdx,1),%ymm20
 1f7dde2:	vmovdqu64 0x3c0(%r9,%rdx,1),%ymm21
 1f7ddea:	kmovd  %eax,%k1
 1f7ddee:	mov    0xb48(%r13),%rax
 1f7ddf5:	vmovdqu8 (%rcx,%rbp,1),%xmm0{%k1}{z}
 1f7ddfc:	mov    0x98(%rsp),%rcx
 1f7de04:	vmovdqu8 (%rcx,%rbp,1),%xmm10{%k1}{z}
 1f7de0b:	vptestmb %xmm0,%xmm0,%k6
 1f7de11:	vpcmpeqb -0x19b610b(%rip),%xmm10,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7de1b:	vmovdqu32 (%r12,%rbp,4),%zmm0{%k7}{z}
 1f7de22:	kmovq  %k7,%k1
 1f7de27:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7de2e:	vptestnmd %zmm17,%zmm12,%k0
 1f7de34:	ktestw %k0,%k7
 1f7de38:	jne    1f7e58d <node_facts_window_run+0x11bd>
 1f7de3e:	vpmovsxbd -0x19ace97(%rip),%xmm3        # 5d0fb0 <.LCPI3_75>
 1f7de47:	vmovdqa64 -0x1ac7711(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7de51:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7de58:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7de5f:	vptestmd -0x19acef1(%rip){1to16},%zmm12,%k0        # 5d0f78 <.LCPI3_12>
 1f7de69:	vmovdqa64 %zmm0,%zmm2
 1f7de6f:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7de75:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7de7b:	vmovdqa64 %zmm3,%zmm9
 1f7de81:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7de87:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7de8d:	kmovd  %k0,%r13d
 1f7de91:	vptestmd %zmm18,%zmm12,%k0
 1f7de97:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7de9d:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7dea4:	vmovdqu64 %zmm1,0x1e0(%rsp)
 1f7deaf:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7deb6:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7deba:	vmovdqa64 %zmm1,%zmm4
 1f7dec0:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7dec6:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7decc:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7ded2:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7ded8:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7dedf:	vmovdqu %ymm3,0x1a0(%rsp)
 1f7dee8:	vinserti64x4 $0x1,%ymm13,%zmm7,%zmm3
 1f7deef:	vpunpcklqdq %ymm13,%ymm7,%ymm7
 1f7def4:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm13
 1f7defb:	vmovdqa64 %zmm3,%zmm6
 1f7df01:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7df07:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7df0d:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7df13:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7df19:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7df1f:	vmovdqa64 %zmm13,%zmm7
 1f7df25:	vmovdqu64 %zmm5,0x260(%rsp)
 1f7df30:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7df37:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7df3d:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7df44:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7df4b:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7df51:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7df58:	vpermt2d %zmm5,%zmm9,%zmm13
 1f7df5e:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7df64:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7df6a:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7df71:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7df78:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7df7f:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7df86:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm21{%k6}{z}
 1f7df8d:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7df94:	vpsrld $0x19,%zmm19,%zmm0
 1f7df9b:	vpandd -0x19ad03d(%rip){1to16},%zmm0,%zmm0        # 5d0f68 <.LCPI3_4>
 1f7dfa5:	vpsrld $0x18,%zmm19,%zmm1
 1f7dfac:	vpsrld $0x1a,%zmm19,%zmm7
 1f7dfb3:	vpternlogd $0xec,%zmm14,%zmm0,%zmm1
 1f7dfba:	vpandd -0x19ad010(%rip){1to16},%zmm19,%zmm0        # 5d0fb4 <.LCPI3_76>
 1f7dfc4:	vpmovdb %zmm1,%xmm20
 1f7dfca:	vpsrld $0xc,%zmm21,%zmm1
 1f7dfd1:	vpmovdb %zmm1,%xmm24
 1f7dfd7:	vpcmpeqd -0x19ad071(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f70 <.LCPI3_7>
 1f7dfe1:	vporq  %xmm15,%xmm20,%xmm0
 1f7dfe7:	vmovdqu8 %xmm0,%xmm20{%k1}
 1f7dfed:	vpcmpeqb %xmm15,%xmm10,%k1{%k6}
 1f7dff3:	vpternlogq $0xf8,%xmm16,%xmm24,%xmm20
 1f7dffa:	kmovd  %k1,%eax
 1f7dffe:	kmovw  %k1,0x30(%rsp)
 1f7e004:	korw   %k0,%k1,%k1
 1f7e008:	kmovw  %k1,0x60(%rsp)
 1f7e00e:	test   %ax,%ax
 1f7e011:	je     1f7e1ef <node_facts_window_run+0xe1f>
 1f7e017:	vmovdqu64 %zmm4,0x720(%rsp)
 1f7e022:	vmovdqu %ymm5,0x6b0(%rsp)
 1f7e02b:	vmovdqu64 %zmm7,0x530(%rsp)
 1f7e036:	vmovdqa64 %xmm24,0x570(%rsp)
 1f7e03e:	vmovdqu64 %zmm23,0x630(%rsp)
 1f7e049:	vmovdqu64 %zmm22,0x490(%rsp)
 1f7e054:	vmovdqu64 %zmm19,0x4d0(%rsp)
 1f7e05f:	vmovdqu64 %zmm13,0x410(%rsp)
 1f7e06a:	vmovdqu64 %zmm21,0x3d0(%rsp)
 1f7e075:	vmovdqu64 %zmm12,0x450(%rsp)
 1f7e080:	vmovdqa64 %xmm20,0x2a0(%rsp)
 1f7e088:	kmovw  %k7,0x160(%rsp)
 1f7e091:	mov    %rdx,0x390(%rsp)
 1f7e099:	kmovd  %k6,0x2e0(%rsp)
 1f7e0a3:	movzwl %ax,%r14d
 1f7e0a7:	movzwl %r13w,%r13d
 1f7e0ab:	xor    %ebx,%ebx
 1f7e0ad:	mov    0x88(%rsp),%rax
 1f7e0b5:	mov    %rbp,0x350(%rsp)
 1f7e0bd:	lea    (%rax,%rbp,4),%r15
 1f7e0c1:	mov    0x8(%rsp),%rbp
 1f7e0c6:	cs nopw 0x0(%rax,%rax,1)
 1f7e0d0:	xor    %r12d,%r12d
 1f7e0d3:	tzcnt  %r14d,%r12d
 1f7e0d8:	mov    %rbp,%rdi
 1f7e0db:	xor    %edx,%edx
 1f7e0dd:	mov    (%r15,%r12,4),%esi
 1f7e0e1:	vzeroupper
 1f7e0e4:	call   1f93890 <node_tests_window_line>
 1f7e0e9:	mov    $0x1,%ecx
 1f7e0ee:	test   $0x2,%al
 1f7e0f0:	shlx   %r12d,%ecx,%eax
 1f7e0f5:	cmove  %ebx,%eax
 1f7e0f8:	or     %eax,%r13d
 1f7e0fb:	blsr   %r14d,%r14d
 1f7e100:	jne    1f7e0d0 <node_facts_window_run+0xd00>
 1f7e102:	vpbroadcastd -0x19ad1a0(%rip),%zmm14        # 5d0f6c <.LCPI3_5>
 1f7e10c:	vpbroadcastb -0x1ac73d5(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e115:	vpbroadcastb -0x1ac73de(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e11f:	vpbroadcastd -0x19ad1b5(%rip),%zmm17        # 5d0f74 <.LCPI3_11>
 1f7e129:	vpbroadcastd -0x19ad1b7(%rip),%zmm18        # 5d0f7c <.LCPI3_13>
 1f7e133:	vmovdqa64 0x2a0(%rsp),%xmm20
 1f7e13b:	vmovdqu64 0x450(%rsp),%zmm12
 1f7e146:	vmovdqu64 0x3d0(%rsp),%zmm21
 1f7e151:	vmovdqu64 0x410(%rsp),%zmm13
 1f7e15c:	vmovdqu64 0x4d0(%rsp),%zmm19
 1f7e167:	vmovdqu64 0x490(%rsp),%zmm22
 1f7e172:	vmovdqu64 0x630(%rsp),%zmm23
 1f7e17d:	vmovdqa64 0x570(%rsp),%xmm24
 1f7e185:	vmovdqu64 0x530(%rsp),%zmm7
 1f7e190:	vmovdqu 0x6b0(%rsp),%ymm5
 1f7e199:	vmovdqu64 0x720(%rsp),%zmm4
 1f7e1a4:	mov    (%rsp),%r11
 1f7e1a8:	mov    0x18(%rsp),%rsi
 1f7e1ad:	mov    0x40(%rsp),%rdi
 1f7e1b2:	mov    0x220(%rsp),%r12
 1f7e1ba:	mov    0x38(%rsp),%r8
 1f7e1bf:	mov    0x20(%rsp),%r9
 1f7e1c4:	mov    0x90(%rsp),%r15
 1f7e1cc:	mov    0x350(%rsp),%rbp
 1f7e1d4:	kmovd  0x2e0(%rsp),%k6
 1f7e1de:	mov    0x390(%rsp),%rdx
 1f7e1e6:	kmovw  0x160(%rsp),%k7
 1f7e1ef:	vpsrld $0x2,%zmm21,%zmm0
 1f7e1f6:	vpandd -0x19ad280(%rip){1to16},%zmm0,%zmm2        # 5d0f80 <.LCPI3_14>
 1f7e200:	vpbroadcastd -0x19ad286(%rip),%zmm0        # 5d0f84 <.LCPI3_15>
 1f7e20a:	vptestmd -0x19ad28c(%rip){1to16},%zmm21,%k3        # 5d0f88 <.LCPI3_16>
 1f7e214:	vmovdqu64 0x260(%rsp),%zmm1
 1f7e21f:	vptestnmd %zmm4,%zmm4,%k1
 1f7e225:	vpbroadcastd -0x19ad29b(%rip),%zmm6        # 5d0f94 <.LCPI3_21>
 1f7e22f:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7e236:	kmovd  %r13d,%k4
 1f7e23b:	vpsrld $0x10,%zmm21,%zmm10
 1f7e242:	vpbroadcastb -0x1ac7509(%rip),%xmm8        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7e24b:	vpbroadcastb -0x1ac7511(%rip),%xmm9        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7e254:	kmovw  %k1,%eax
 1f7e258:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7e25e:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7e265:	vmovdqu64 0x1e0(%rsp),%zmm0
 1f7e270:	korw   %k1,%k3,%k3
 1f7e274:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7e27b:	vpandd -0x19ad2cd(%rip){1to16},%zmm19,%zmm5        # 5d0fb8 <.LCPI3_79>
 1f7e285:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7e28b:	vpbroadcastb -0x1ac7550(%rip),%xmm7        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7e294:	vinserti64x4 $0x1,0x1a0(%rsp),%zmm0,%zmm0
 1f7e29d:	kmovw  %k0,%ecx
 1f7e2a1:	korw   %k2,%k3,%k2
 1f7e2a5:	vpaddd -0x19ad31f(%rip){1to16},%zmm5,%zmm5        # 5d0f90 <.LCPI3_20>
 1f7e2af:	andn   %ecx,%eax,%eax
 1f7e2b4:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7e2ba:	kmovd  %eax,%k3
 1f7e2be:	shr    $0x8,%eax
 1f7e2c1:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7e2c7:	kmovd  %eax,%k3
 1f7e2cb:	vmovdqu8 %xmm15,%xmm4{%k2}{z}
 1f7e2d1:	vpcmpltud %zmm6,%zmm5,%k2
 1f7e2d8:	vpslld $0x1f,%zmm5,%zmm5
 1f7e2df:	vpxor  %xmm6,%xmm6,%xmm6
 1f7e2e3:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7e2e9:	vptestmd -0x19ad367(%rip){1to16},%zmm23,%k3        # 5d0f8c <.LCPI3_17>
 1f7e2f3:	vpandd %zmm18,%zmm23,%zmm3
 1f7e2f9:	vptestnmd %zmm3,%zmm3,%k0
 1f7e2ff:	kandd  %k6,%k0,%k0
 1f7e304:	korw   %k3,%k4,%k3
 1f7e308:	kandd  %k2,%k0,%k4
 1f7e30d:	vpcmpeqd %zmm17,%zmm2,%k2{%k4}
 1f7e313:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7e319:	vmovdqu8 -0x19b65e3(%rip),%xmm2{%k4}        # 5c7d40 <.LCPI3_25>
 1f7e323:	knotw  %k2,%k0
 1f7e327:	kandd  %k0,%k4,%k5
 1f7e32c:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7e332:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7e339:	vpaddd %zmm5,%zmm10,%zmm11
 1f7e33f:	vpbroadcastb -0x1ac7603(%rip),%xmm5        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7e348:	vmovdqu8 -0x19b6602(%rip),%xmm2{%k4}        # 5c7d50 <.LCPI3_26>
 1f7e352:	vptestnmd %zmm11,%zmm11,%k4
 1f7e358:	vpblendmb -0x19b65f2(%rip),%xmm5,%xmm5{%k4}        # 5c7d70 <.LCPI3_28>
 1f7e362:	vpcmpnleud -0x19ad3d5(%rip){1to16},%zmm11,%k4        # 5d0f98 <.LCPI3_22>
 1f7e36d:	mov    0x8(%rsp),%r13
 1f7e372:	cmpb   $0x0,0xb90(%r13)
 1f7e37a:	vmovdqu8 -0x19b6604(%rip),%xmm5{%k4}        # 5c7d80 <.LCPI3_29>
 1f7e384:	vpcmpnleud -0x19ad3f3(%rip){1to16},%zmm11,%k4        # 5d0f9c <.LCPI3_23>
 1f7e38f:	vmovdqu8 -0x19b6609(%rip),%xmm5{%k4}        # 5c7d90 <.LCPI3_30>
 1f7e399:	vptestmd %zmm3,%zmm3,%k4
 1f7e39f:	vpor   %xmm4,%xmm8,%xmm3
 1f7e3a3:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7e3a9:	kmovw  0x60(%rsp),%k4
 1f7e3af:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7e3b5:	vpor   %xmm2,%xmm4,%xmm2
 1f7e3b9:	vpord  -0x19ad407(%rip){1to4},%xmm2,%xmm3        # 5d0fbc <.LCPI3_82>
 1f7e3c3:	vpbroadcastb -0x1ac7686(%rip),%xmm5        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7e3cc:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7e3d2:	vpor   %xmm5,%xmm2,%xmm3
 1f7e3d6:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7e3dc:	vpmovdb %zmm21,%xmm3
 1f7e3e2:	kmovw  0x30(%rsp),%k3
 1f7e3e8:	vpor   %xmm3,%xmm9,%xmm4
 1f7e3ec:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7e3f2:	vptestmd -0x19ad45c(%rip){1to16},%zmm12,%k3{%k7}        # 5d0fa0 <.LCPI3_32>
 1f7e3fc:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7e402:	vpor   %xmm5,%xmm4,%xmm6
 1f7e406:	vpsrld $0xb,%zmm23,%zmm7
 1f7e40d:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7e413:	vpandd -0x19ad45d(%rip){1to4},%xmm24,%xmm4        # 5d0fc0 <.LCPI3_84>
 1f7e41d:	vptestmd -0x19ad483(%rip){1to16},%zmm23,%k1        # 5d0fa4 <.LCPI3_33>
 1f7e427:	vpmovdb %zmm7,%xmm7
 1f7e42d:	vpand  %xmm7,%xmm8,%xmm7
 1f7e431:	vporq  %xmm16,%xmm4,%xmm5
 1f7e437:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7e43d:	vpmovdb %zmm23,%xmm5
 1f7e443:	vgf2p8affineqb $0x0,-0x19afebe(%rip){1to2},%xmm5,%xmm5        # 5ce590 <.LCPI3_85>
 1f7e44e:	vpternlogq $0xf8,%xmm9,%xmm5,%xmm4
 1f7e455:	vpmovdb %zmm19,%xmm9
 1f7e45b:	vpor   %xmm4,%xmm15,%xmm5
 1f7e45f:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7e465:	vinserti32x4 $0x3,%xmm13,%zmm22,%zmm5{%k6}{z}
 1f7e46c:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7e473:	vpsrld $0x8,%zmm19,%zmm13
 1f7e47a:	vpsrld $0x10,%zmm19,%zmm6
 1f7e481:	vpmovdb %zmm6,%xmm7
 1f7e487:	vpmovdb %zmm13,%xmm8
 1f7e48d:	vpmovdb %zmm12,%xmm6
 1f7e493:	je     1f7dc8c <node_facts_window_run+0x8bc>
 1f7e499:	vmovdqa64 -0x1ac7ca3(%rip),%zmm19        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7e4a3:	vptestmd %zmm10,%zmm10,%k1{%k2}
 1f7e4a9:	add    %r9,%rdx
 1f7e4ac:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e4b1:	vpxor  %xmm13,%xmm13,%xmm13
 1f7e4b6:	vpcmpneqd -0x19ad519(%rip){1to16},%zmm10,%k0{%k1}        # 5d0fa8 <.LCPI3_38>
 1f7e4c1:	vmovdqa %xmm7,%xmm10
 1f7e4c5:	vpternlogq $0xfe,%xmm9,%xmm3,%xmm10
 1f7e4cc:	kmovq  %k1,%k2
 1f7e4d1:	kmovw  %k1,%eax
 1f7e4d5:	popcnt %eax,%ecx
 1f7e4d9:	vpgatherdd 0x10(%rdx,%zmm19,1),%zmm12{%k2}
 1f7e4e1:	kmovq  %k1,%k2
 1f7e4e6:	vpcmpnleud -0x19ad545(%rip){1to16},%zmm12,%k3        # 5d0fac <.LCPI3_39>
 1f7e4f1:	vpgatherdd 0x14(%rdx,%zmm19,1),%zmm13{%k2}
 1f7e4f9:	add    %rcx,0x28(%rsp)
 1f7e4fe:	mov    0x10(%rsp),%r10
 1f7e503:	vpcmpeqd %zmm11,%zmm12,%k2
 1f7e509:	vmovdqa64 %xmm20,%xmm11
 1f7e50f:	vpternlogq $0xfe,%xmm8,%xmm10,%xmm11
 1f7e516:	vptestnmd %zmm13,%zmm13,%k2{%k2}
 1f7e51c:	vptestmd %zmm13,%zmm13,%k4
 1f7e522:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm11
 1f7e529:	korw   %k4,%k3,%k3
 1f7e52d:	kandw  %k2,%k0,%k2
 1f7e531:	knotw  %k0,%k0
 1f7e535:	kandd  %k1,%k0,%k0
 1f7e53a:	kandw  %k0,%k3,%k0
 1f7e53e:	korw   %k0,%k2,%k2
 1f7e542:	vptestnmd %zmm14,%zmm21,%k0{%k2}
 1f7e548:	kandw  %k0,%k1,%k0
 1f7e54c:	knotd  %k6,%k1
 1f7e551:	kmovd  %k0,%ecx
 1f7e555:	vptestmb %xmm11,%xmm11,%k0{%k1}
 1f7e55b:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7e561:	andn   %eax,%ecx,%eax
 1f7e566:	popcnt %eax,%eax
 1f7e56a:	kmovw  %k0,%ecx
 1f7e56e:	popcnt %ecx,%ecx
 1f7e572:	kmovw  %k1,%edx
 1f7e576:	popcnt %edx,%edx
 1f7e57a:	add    %rdx,%r10
 1f7e57d:	add    %rax,%r10
 1f7e580:	add    %rcx,%r10
 1f7e583:	mov    %r10,0x10(%rsp)
 1f7e588:	jmp    1f7dc8c <node_facts_window_run+0x8bc>
 1f7e58d:	kandw  %k0,%k7,%k0
 1f7e591:	mov    %rdx,0x390(%rsp)
 1f7e599:	vmovdqa %xmm10,0x260(%rsp)
 1f7e5a2:	vmovdqu64 %zmm11,0x350(%rsp)
 1f7e5ad:	vmovdqu64 %ymm19,0x2a0(%rsp)
 1f7e5b5:	vmovdqu64 %zmm20,0x450(%rsp)
 1f7e5c0:	vmovdqu64 %ymm21,0x3d0(%rsp)
 1f7e5cb:	vmovdqu64 %zmm7,0x410(%rsp)
 1f7e5d6:	vmovdqu %ymm13,0x4d0(%rsp)
 1f7e5df:	vmovdqu64 %zmm22,0x490(%rsp)
 1f7e5ea:	vmovdqu64 %ymm23,0x630(%rsp)
 1f7e5f5:	vmovdqu64 %zmm5,0x570(%rsp)
 1f7e600:	vmovdqu %ymm6,0x530(%rsp)
 1f7e609:	vmovdqu64 %zmm24,0x6b0(%rsp)
 1f7e614:	vmovdqu64 %ymm25,0x720(%rsp)
 1f7e61c:	vmovdqu64 %zmm4,0x5f0(%rsp)
 1f7e627:	vmovdqu64 %ymm26,0x100(%rsp)
 1f7e62f:	vmovdqu64 %zmm27,0x5b0(%rsp)
 1f7e63a:	vmovdqu64 %ymm28,0x120(%rsp)
 1f7e642:	vmovdqu64 %zmm0,0x670(%rsp)
 1f7e64d:	kmovd  %k6,0x2e0(%rsp)
 1f7e657:	kmovw  %k7,0x160(%rsp)
 1f7e660:	kmovd  %k0,%eax
 1f7e664:	movzwl %ax,%eax
 1f7e667:	jmp    1f7e80e <node_facts_window_run+0x143e>
 1f7e66c:	mov    0x48(%rsp),%rsi
 1f7e671:	mov    (%r12,%r13,4),%r8d
 1f7e675:	mov    %dil,0x1a0(%rsp)
 1f7e67d:	shl    $0x6,%rax
 1f7e681:	mov    0x20(%r11),%rcx
 1f7e685:	mov    %r8,0x1e0(%rsp)
 1f7e68d:	mov    0x8(%rsp),%r14
 1f7e692:	mov    0xb48(%r14),%rdx
 1f7e699:	mov    %r14,%rdi
 1f7e69c:	cmpb   $0x1,(%rdx,%r8,1)
 1f7e6a1:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7e6a6:	adc    $0x0,%rsi
 1f7e6aa:	and    $0x1,%edx
 1f7e6ad:	mov    %rsi,0x48(%rsp)
 1f7e6b2:	mov    0x88(%rsp),%rbx
 1f7e6ba:	mov    (%rbx,%r13,4),%esi
 1f7e6be:	vzeroupper
 1f7e6c1:	call   1f93890 <node_tests_window_line>
 1f7e6c6:	mov    (%rbx,%r13,4),%esi
 1f7e6ca:	mov    %r14,%rdi
 1f7e6cd:	mov    %al,0x60(%rsp)
 1f7e6d1:	call   1f939e0 <node_tests_window_returns>
 1f7e6d6:	or     0x1a0(%rsp),%al
 1f7e6dd:	mov    0xb48(%r14),%rcx
 1f7e6e4:	mov    0x1e0(%rsp),%rdx
 1f7e6ec:	vpbroadcastd -0x19ad78a(%rip),%zmm14        # 5d0f6c <.LCPI3_5>
 1f7e6f6:	vpbroadcastb -0x1ac79bf(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e6ff:	vpbroadcastb -0x1ac79c8(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e709:	vpbroadcastd -0x19ad79f(%rip),%zmm17        # 5d0f74 <.LCPI3_11>
 1f7e713:	vpbroadcastd -0x19ad7a1(%rip),%zmm18        # 5d0f7c <.LCPI3_13>
 1f7e71d:	vmovdqa 0x260(%rsp),%xmm10
 1f7e726:	vmovdqu64 0x350(%rsp),%zmm11
 1f7e731:	vmovdqu64 0x2a0(%rsp),%ymm19
 1f7e739:	vmovdqu64 0x450(%rsp),%zmm20
 1f7e744:	vmovdqu64 0x3d0(%rsp),%ymm21
 1f7e74f:	vmovdqu64 0x410(%rsp),%zmm7
 1f7e75a:	vmovdqu 0x4d0(%rsp),%ymm13
 1f7e763:	vmovdqu64 0x490(%rsp),%zmm22
 1f7e76e:	vmovdqu64 0x630(%rsp),%ymm23
 1f7e779:	vmovdqu64 0x570(%rsp),%zmm5
 1f7e784:	vmovdqu 0x530(%rsp),%ymm6
 1f7e78d:	vmovdqu64 0x6b0(%rsp),%zmm24
 1f7e798:	vmovdqu64 0x720(%rsp),%ymm25
 1f7e7a0:	vmovdqu64 0x5f0(%rsp),%zmm4
 1f7e7ab:	vmovdqu64 0x100(%rsp),%ymm26
 1f7e7b3:	vmovdqu64 0x5b0(%rsp),%zmm27
 1f7e7be:	vmovdqu64 0x120(%rsp),%ymm28
 1f7e7c6:	vmovdqu64 0x670(%rsp),%zmm0
 1f7e7d1:	mov    (%rsp),%r11
 1f7e7d5:	mov    0x18(%rsp),%rsi
 1f7e7da:	mov    0x40(%rsp),%rdi
 1f7e7df:	mov    0x38(%rsp),%r8
 1f7e7e4:	mov    0x20(%rsp),%r9
 1f7e7e9:	kmovd  0x2e0(%rsp),%k6
 1f7e7f3:	kmovw  0x160(%rsp),%k7
 1f7e7fc:	or     0x60(%rsp),%al
 1f7e800:	mov    %al,(%rcx,%rdx,1)
 1f7e803:	mov    0x30(%rsp),%eax
 1f7e807:	blsr   %eax,%eax
 1f7e80c:	je     1f7e878 <node_facts_window_run+0x14a8>
 1f7e80e:	tzcnt  %eax,%r13d
 1f7e813:	mov    %eax,0x30(%rsp)
 1f7e817:	mov    0x60(%r11),%edx
 1f7e81b:	mov    $0x1,%dil
 1f7e81e:	add    %rbp,%r13
 1f7e821:	mov    %r13,%rcx
 1f7e824:	shl    $0x6,%rcx
 1f7e828:	mov    (%r9,%rcx,1),%eax
 1f7e82c:	mov    0xc(%r9,%rcx,1),%ecx
 1f7e831:	shr    $0x3,%eax
 1f7e834:	cmp    %edx,%eax
 1f7e836:	cmovae %edx,%eax
 1f7e839:	test   %rcx,%rcx
 1f7e83c:	je     1f7e66c <node_facts_window_run+0x129c>
 1f7e842:	mov    0x78(%rsp),%rdx
 1f7e847:	mov    0x48(%rsp),%rsi
 1f7e84c:	cmp    0x3b8(%rdx),%ecx
 1f7e852:	jae    1f7e671 <node_facts_window_run+0x12a1>
 1f7e858:	mov    0x78(%rsp),%rdx
 1f7e85d:	mov    0x3a8(%rdx),%rdx
 1f7e864:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7e868:	setne  %dil
 1f7e86c:	shl    $0x5,%dil
 1f7e870:	inc    %dil
 1f7e873:	jmp    1f7e671 <node_facts_window_run+0x12a1>
 1f7e878:	mov    0xb48(%r14),%rax
 1f7e87f:	kmovq  %k7,%k1
 1f7e884:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e889:	mov    0x390(%rsp),%rdx
 1f7e891:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7e898:	jmp    1f7de3e <node_facts_window_run+0xa6e>
 1f7e89d:	cmpq   $0x0,0xb40(%r11)
 1f7e8a5:	je     1f7ffd8 <node_facts_window_run+0x2c08>
 1f7e8ab:	test   %eax,%eax
 1f7e8ad:	je     1f80850 <node_facts_window_run+0x3480>
 1f7e8b3:	vpbroadcastd -0x19ad951(%rip),%zmm10        # 5d0f6c <.LCPI3_5>
 1f7e8bd:	vpbroadcastb -0x1ac7b86(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e8c6:	vpbroadcastb -0x1ac7b8e(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e8cf:	vpbroadcastd -0x19ad965(%rip),%zmm13        # 5d0f74 <.LCPI3_11>
 1f7e8d9:	vpbroadcastd -0x19ad967(%rip),%zmm14        # 5d0f7c <.LCPI3_13>
 1f7e8e3:	mov    (%r11),%rcx
 1f7e8e6:	lea    0x69454(%rsi),%r10
 1f7e8ed:	lea    0x422c(%rsi),%rdx
 1f7e8f4:	mov    %eax,%ebp
 1f7e8f6:	xor    %r14d,%r14d
 1f7e8f9:	mov    %rcx,0x6b0(%rsp)
 1f7e901:	mov    %r10,0x630(%rsp)
 1f7e909:	mov    %rdx,0x570(%rsp)
 1f7e911:	movq   $0x0,0x48(%rsp)
 1f7e91a:	movq   $0x0,0x28(%rsp)
 1f7e923:	movq   $0x0,0x10(%rsp)
 1f7e92c:	mov    %rbp,0x530(%rsp)
 1f7e934:	jmp    1f7e9c3 <node_facts_window_run+0x15f3>
 1f7e939:	nopl   0x0(%rax)
 1f7e940:	vpxor  %xmm1,%xmm1,%xmm1
 1f7e944:	vpxor  %xmm3,%xmm3,%xmm3
 1f7e948:	vpxor  %xmm4,%xmm4,%xmm4
 1f7e94c:	vpxor  %xmm5,%xmm5,%xmm5
 1f7e950:	vpxor  %xmm0,%xmm0,%xmm0
 1f7e954:	vpxord %xmm16,%xmm16,%xmm16
 1f7e95a:	mov    0xb10(%r13),%rax
 1f7e961:	vmovdqu64 %xmm16,(%rax,%r14,1)
 1f7e968:	mov    0xb18(%r13),%rax
 1f7e96f:	vmovdqu %xmm0,(%rax,%r14,1)
 1f7e975:	mov    0xb88(%r11),%rax
 1f7e97c:	vmovdqu %xmm5,(%rax,%r14,1)
 1f7e982:	mov    0xb90(%r11),%rax
 1f7e989:	vmovdqu %xmm4,(%rax,%r14,1)
 1f7e98f:	mov    0xb98(%r11),%rax
 1f7e996:	vmovdqu %xmm3,(%rax,%r14,1)
 1f7e99c:	mov    0xba0(%r11),%rax
 1f7e9a3:	vmovdqu %xmm1,(%rax,%r14,1)
 1f7e9a9:	mov    0xba8(%r11),%rax
 1f7e9b0:	vmovdqu %xmm2,(%rax,%r14,1)
 1f7e9b6:	add    $0x10,%r14
 1f7e9ba:	cmp    %rbp,%r14
 1f7e9bd:	jae    1f8086b <node_facts_window_run+0x349b>
 1f7e9c3:	vpxor  %xmm2,%xmm2,%xmm2
 1f7e9c7:	cmp    %r8,%r14
 1f7e9ca:	jae    1f7e940 <node_facts_window_run+0x1570>
 1f7e9d0:	mov    %r8d,%eax
 1f7e9d3:	sub    %r14d,%eax
 1f7e9d6:	mov    $0x10,%ecx
 1f7e9db:	mov    $0xffffffff,%edx
 1f7e9e0:	vpxord %xmm18,%xmm18,%xmm18
 1f7e9e6:	cmp    $0x10,%eax
 1f7e9e9:	cmovae %ecx,%eax
 1f7e9ec:	mov    0x9b8(%r11),%rcx
 1f7e9f3:	shlx   %eax,%edx,%eax
 1f7e9f8:	mov    %r14,%rdx
 1f7e9fb:	shl    $0x6,%rdx
 1f7e9ff:	not    %eax
 1f7ea01:	vmovdqu (%r9,%rdx,1),%ymm0
 1f7ea07:	vmovdqu 0x180(%r9,%rdx,1),%ymm3
 1f7ea11:	vmovdqu 0x80(%r9,%rdx,1),%ymm1
 1f7ea1b:	vmovdqu 0x100(%r9,%rdx,1),%ymm2
 1f7ea25:	kmovd  %eax,%k1
 1f7ea29:	vinserti64x4 $0x1,0x40(%r9,%rdx,1),%zmm0,%zmm6
 1f7ea32:	vmovdqu 0x200(%r9,%rdx,1),%ymm0
 1f7ea3c:	vinserti64x4 $0x1,0x1c0(%r9,%rdx,1),%zmm3,%zmm7
 1f7ea45:	mov    0xb48(%r13),%rax
 1f7ea4c:	vinserti64x4 $0x1,0xc0(%r9,%rdx,1),%zmm1,%zmm1
 1f7ea55:	vinserti64x4 $0x1,0x140(%r9,%rdx,1),%zmm2,%zmm2
 1f7ea5e:	vinserti64x4 $0x1,0x240(%r9,%rdx,1),%zmm0,%zmm3
 1f7ea67:	vmovdqu 0x280(%r9,%rdx,1),%ymm0
 1f7ea71:	vmovdqu8 (%rcx,%r14,1),%xmm4{%k1}{z}
 1f7ea78:	mov    0x630(%rsp),%rcx
 1f7ea80:	vinserti64x4 $0x1,0x2c0(%r9,%rdx,1),%zmm0,%zmm9
 1f7ea89:	vmovdqu 0x300(%r9,%rdx,1),%ymm0
 1f7ea93:	vinserti64x4 $0x1,0x340(%r9,%rdx,1),%zmm0,%zmm8
 1f7ea9c:	vmovdqu 0x380(%r9,%rdx,1),%ymm0
 1f7eaa6:	vinserti64x4 $0x1,0x3c0(%r9,%rdx,1),%zmm0,%zmm15
 1f7eaaf:	vmovdqu8 (%rcx,%r14,1),%xmm5{%k1}{z}
 1f7eab6:	vptestmb %xmm4,%xmm4,%k6
 1f7eabc:	vpcmpeqb -0x19b6db6(%rip),%xmm5,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7eac6:	vmovdqu32 (%r12,%r14,4),%zmm0{%k7}{z}
 1f7eacd:	kmovq  %k7,%k1
 1f7ead2:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7ead9:	vptestnmd %zmm13,%zmm18,%k0
 1f7eadf:	ktestw %k0,%k7
 1f7eae3:	jne    1f7f0c5 <node_facts_window_run+0x1cf5>
 1f7eae9:	vmovdqa64 -0x1ac83b3(%rip),%zmm0        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7eaf3:	vptestmd -0x19adb85(%rip){1to16},%zmm18,%k0        # 5d0f78 <.LCPI3_12>
 1f7eafd:	kmovd  %k6,%r10d
 1f7eb01:	vpermt2d %zmm1,%zmm0,%zmm6
 1f7eb07:	vpermt2d %zmm7,%zmm0,%zmm2
 1f7eb0d:	vpermt2d %zmm9,%zmm0,%zmm3
 1f7eb13:	vpermt2d %zmm15,%zmm0,%zmm8
 1f7eb19:	kmovd  %k0,%r13d
 1f7eb1d:	vptestmd %zmm14,%zmm18,%k0
 1f7eb23:	vshufi64x2 $0x44,%zmm2,%zmm6,%zmm0
 1f7eb2a:	vshufi64x2 $0x44,%zmm8,%zmm3,%zmm1
 1f7eb31:	vshufi64x2 $0xee,%zmm2,%zmm6,%zmm2
 1f7eb38:	vshufi64x2 $0xee,%zmm8,%zmm3,%zmm3
 1f7eb3f:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm15{%k6}{z}
 1f7eb46:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7eb4d:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm17{%k6}{z}
 1f7eb54:	vshufi64x2 $0x88,%zmm3,%zmm2,%zmm7
 1f7eb5b:	vpsrld $0x19,%zmm15,%zmm0
 1f7eb62:	vpandd -0x19adc04(%rip){1to16},%zmm0,%zmm0        # 5d0f68 <.LCPI3_4>
 1f7eb6c:	vpsrld $0x18,%zmm15,%zmm1
 1f7eb73:	vpsrld $0x1a,%zmm15,%zmm6
 1f7eb7a:	vpternlogd $0xec,%zmm10,%zmm0,%zmm1
 1f7eb81:	vpandd -0x19adbd7(%rip){1to16},%zmm15,%zmm0        # 5d0fb4 <.LCPI3_76>
 1f7eb8b:	vpmovdb %zmm1,%xmm16
 1f7eb91:	vpsrld $0xc,%zmm17,%zmm1
 1f7eb98:	vpmovdb %zmm1,%xmm20
 1f7eb9e:	vpcmpeqd -0x19adc38(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f70 <.LCPI3_7>
 1f7eba8:	vporq  %xmm11,%xmm16,%xmm0
 1f7ebae:	vmovdqu8 %xmm0,%xmm16{%k1}
 1f7ebb4:	vpcmpeqb %xmm11,%xmm5,%k1{%k6}
 1f7ebba:	vpternlogq $0xf8,%xmm12,%xmm20,%xmm16
 1f7ebc1:	kmovd  %k1,%eax
 1f7ebc5:	kmovw  %k1,0x30(%rsp)
 1f7ebcb:	korw   %k0,%k1,%k1
 1f7ebcf:	kmovw  %k1,0x1e0(%rsp)
 1f7ebd8:	test   %ax,%ax
 1f7ebdb:	je     1f7ed86 <node_facts_window_run+0x19b6>
 1f7ebe1:	vmovdqu64 %zmm7,0x490(%rsp)
 1f7ebec:	vmovdqu64 %zmm6,0x4d0(%rsp)
 1f7ebf7:	vmovdqa64 %xmm20,0x410(%rsp)
 1f7ebff:	vmovdqu64 %zmm19,0x3d0(%rsp)
 1f7ec0a:	vmovdqu64 %zmm18,0x450(%rsp)
 1f7ec15:	vmovdqu64 %zmm15,0x2a0(%rsp)
 1f7ec20:	vmovdqa %xmm4,0x260(%rsp)
 1f7ec29:	vmovdqu64 %zmm17,0x350(%rsp)
 1f7ec34:	mov    %r10d,0x390(%rsp)
 1f7ec3c:	vmovdqa64 %xmm16,0x160(%rsp)
 1f7ec44:	kmovw  %k7,0x1a0(%rsp)
 1f7ec4d:	kmovw  %k6,0x60(%rsp)
 1f7ec53:	mov    %rdx,0x2e0(%rsp)
 1f7ec5b:	movzwl %ax,%ebx
 1f7ec5e:	movzwl %r13w,%r13d
 1f7ec62:	mov    0x570(%rsp),%rax
 1f7ec6a:	mov    0x8(%rsp),%rbp
 1f7ec6f:	lea    (%rax,%r14,4),%r15
 1f7ec73:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7ec80:	xor    %r12d,%r12d
 1f7ec83:	tzcnt  %ebx,%r12d
 1f7ec88:	mov    %rbp,%rdi
 1f7ec8b:	xor    %edx,%edx
 1f7ec8d:	mov    (%r15,%r12,4),%esi
 1f7ec91:	vzeroupper
 1f7ec94:	call   1f93890 <node_tests_window_line>
 1f7ec99:	mov    $0x1,%edx
 1f7ec9e:	xor    %ecx,%ecx
 1f7eca0:	test   $0x2,%al
 1f7eca2:	shlx   %r12d,%edx,%eax
 1f7eca7:	cmove  %ecx,%eax
 1f7ecaa:	or     %eax,%r13d
 1f7ecad:	blsr   %ebx,%ebx
 1f7ecb2:	jne    1f7ec80 <node_facts_window_run+0x18b0>
 1f7ecb4:	vpbroadcastd -0x19add52(%rip),%zmm10        # 5d0f6c <.LCPI3_5>
 1f7ecbe:	vpbroadcastb -0x1ac7f87(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7ecc7:	vpbroadcastb -0x1ac7f8f(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7ecd0:	vpbroadcastd -0x19add66(%rip),%zmm13        # 5d0f74 <.LCPI3_11>
 1f7ecda:	vpbroadcastd -0x19add68(%rip),%zmm14        # 5d0f7c <.LCPI3_13>
 1f7ece4:	vmovdqa64 0x160(%rsp),%xmm16
 1f7ecec:	vmovdqu64 0x350(%rsp),%zmm17
 1f7ecf7:	vmovdqa 0x260(%rsp),%xmm4
 1f7ed00:	vmovdqu64 0x2a0(%rsp),%zmm15
 1f7ed0b:	vmovdqu64 0x450(%rsp),%zmm18
 1f7ed16:	vmovdqu64 0x3d0(%rsp),%zmm19
 1f7ed21:	vmovdqa64 0x410(%rsp),%xmm20
 1f7ed29:	vmovdqu64 0x4d0(%rsp),%zmm6
 1f7ed34:	vmovdqu64 0x490(%rsp),%zmm7
 1f7ed3f:	mov    (%rsp),%r11
 1f7ed43:	mov    0x18(%rsp),%rsi
 1f7ed48:	mov    0x40(%rsp),%rdi
 1f7ed4d:	mov    0x220(%rsp),%r12
 1f7ed55:	mov    0x38(%rsp),%r8
 1f7ed5a:	mov    0x20(%rsp),%r9
 1f7ed5f:	mov    0x530(%rsp),%rbp
 1f7ed67:	mov    0x2e0(%rsp),%rdx
 1f7ed6f:	kmovw  0x60(%rsp),%k6
 1f7ed75:	kmovw  0x1a0(%rsp),%k7
 1f7ed7e:	mov    0x390(%rsp),%r10d
 1f7ed86:	vpsrld $0x2,%zmm17,%zmm0
 1f7ed8d:	vpandd -0x19ade17(%rip){1to16},%zmm0,%zmm0        # 5d0f80 <.LCPI3_14>
 1f7ed97:	vptestmd -0x19ade19(%rip){1to16},%zmm17,%k2        # 5d0f88 <.LCPI3_16>
 1f7eda1:	vpandd -0x19addf3(%rip){1to16},%zmm15,%zmm3        # 5d0fb8 <.LCPI3_79>
 1f7edab:	vptestnmb %xmm4,%xmm4,%k0
 1f7edb1:	vpbroadcastd -0x19ade27(%rip),%zmm4        # 5d0f94 <.LCPI3_21>
 1f7edbb:	vptestmd -0x19ade39(%rip){1to16},%zmm19,%k3        # 5d0f8c <.LCPI3_17>
 1f7edc5:	vpandd %zmm14,%zmm19,%zmm1
 1f7edcb:	vpbroadcastb -0x1ac8090(%rip),%xmm8        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7edd4:	vpbroadcastb -0x1ac809b(%rip),%xmm5        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7eddd:	vpbroadcastb -0x1ac80a3(%rip),%xmm9        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7ede6:	vpcmpneqd -0x19ade6d(%rip){1to16},%zmm0,%k1        # 5d0f84 <.LCPI3_15>
 1f7edf1:	vpaddd -0x19ade6b(%rip){1to16},%zmm3,%zmm3        # 5d0f90 <.LCPI3_20>
 1f7edfb:	vpcmpeqd %zmm4,%zmm6,%k5{%k6}
 1f7ee01:	vpsrld $0x10,%zmm17,%zmm6
 1f7ee08:	korw   %k1,%k2,%k1
 1f7ee0c:	vptestnmd %zmm7,%zmm7,%k2
 1f7ee12:	korw   %k2,%k0,%k2
 1f7ee16:	vptestnmd %zmm1,%zmm1,%k0
 1f7ee1c:	korw   %k1,%k2,%k1
 1f7ee20:	kmovd  %k0,%eax
 1f7ee24:	vpcmpltud %zmm4,%zmm3,%k0
 1f7ee2b:	vpslld $0x1f,%zmm3,%zmm3
 1f7ee32:	vpxor  %xmm4,%xmm4,%xmm4
 1f7ee36:	vptestmd %zmm0,%zmm0,%k1{%k1}
 1f7ee3c:	kmovd  %k0,%ecx
 1f7ee40:	and    %eax,%ecx
 1f7ee42:	mov    %r10d,%eax
 1f7ee45:	and    %ecx,%eax
 1f7ee47:	kmovd  %eax,%k4
 1f7ee4b:	vmovdqu8 %xmm11,%xmm2{%k1}{z}
 1f7ee51:	kmovd  %r13d,%k1
 1f7ee56:	korw   %k3,%k1,%k3
 1f7ee5a:	vpcmpeqd %zmm13,%zmm0,%k1{%k4}
 1f7ee60:	vmovdqu8 %xmm8,%xmm0{%k5}{z}
 1f7ee66:	vmovdqu8 -0x19b7130(%rip),%xmm0{%k4}        # 5c7d40 <.LCPI3_25>
 1f7ee70:	knotw  %k1,%k0
 1f7ee74:	kmovd  %k0,%ecx
 1f7ee78:	and    %eax,%ecx
 1f7ee7a:	kmovd  %ecx,%k4
 1f7ee7e:	vpcmpgtd %zmm3,%zmm4,%k4{%k4}
 1f7ee84:	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
 1f7ee8b:	vpaddd %zmm3,%zmm6,%zmm7
 1f7ee91:	vpbroadcastb -0x1ac8155(%rip),%xmm3        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7ee9a:	vmovdqu8 -0x19b7154(%rip),%xmm0{%k4}        # 5c7d50 <.LCPI3_26>
 1f7eea4:	vptestnmd %zmm7,%zmm7,%k4
 1f7eeaa:	vpblendmb -0x19b7144(%rip),%xmm3,%xmm3{%k4}        # 5c7d70 <.LCPI3_28>
 1f7eeb4:	vpcmpnleud -0x19adf27(%rip){1to16},%zmm7,%k4        # 5d0f98 <.LCPI3_22>
 1f7eebf:	mov    0x8(%rsp),%r13
 1f7eec4:	cmpb   $0x0,0xb90(%r13)
 1f7eecc:	vmovdqu8 -0x19b7156(%rip),%xmm3{%k4}        # 5c7d80 <.LCPI3_29>
 1f7eed6:	vpcmpnleud -0x19adf45(%rip){1to16},%zmm7,%k4        # 5d0f9c <.LCPI3_23>
 1f7eee1:	vmovdqu8 -0x19b715b(%rip),%xmm3{%k4}        # 5c7d90 <.LCPI3_30>
 1f7eeeb:	vptestmd %zmm1,%zmm1,%k4
 1f7eef1:	vpor   %xmm5,%xmm2,%xmm1
 1f7eef5:	vmovdqu8 %xmm1,%xmm2{%k4}
 1f7eefb:	kmovw  0x1e0(%rsp),%k4
 1f7ef04:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f7ef0a:	vpor   %xmm0,%xmm2,%xmm0
 1f7ef0e:	vpord  -0x19adf5c(%rip){1to4},%xmm0,%xmm1        # 5d0fbc <.LCPI3_82>
 1f7ef18:	vpbroadcastb -0x1ac81db(%rip),%xmm3        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7ef21:	vmovdqu8 %xmm1,%xmm0{%k4}
 1f7ef27:	vpor   %xmm3,%xmm0,%xmm1
 1f7ef2b:	vmovdqu8 %xmm1,%xmm0{%k3}
 1f7ef31:	vpmovdb %zmm17,%xmm1
 1f7ef37:	kmovw  0x30(%rsp),%k3
 1f7ef3d:	vpor   %xmm1,%xmm9,%xmm2
 1f7ef41:	vmovdqu8 %xmm2,%xmm1{%k3}
 1f7ef47:	vptestmd -0x19adfb1(%rip){1to16},%zmm18,%k3{%k7}        # 5d0fa0 <.LCPI3_32>
 1f7ef51:	vmovdqu8 %xmm8,%xmm2{%k3}{z}
 1f7ef57:	vpor   %xmm3,%xmm2,%xmm3
 1f7ef5b:	vpsrld $0x8,%zmm15,%zmm8
 1f7ef62:	vmovdqu8 %xmm2,%xmm3{%k2}
 1f7ef68:	vpandd -0x19adfb2(%rip){1to4},%xmm20,%xmm2        # 5d0fc0 <.LCPI3_84>
 1f7ef72:	vptestmd -0x19adfd8(%rip){1to16},%zmm19,%k2        # 5d0fa4 <.LCPI3_33>
 1f7ef7c:	vpor   %xmm2,%xmm12,%xmm4
 1f7ef80:	vmovdqu8 %xmm4,%xmm2{%k6}
 1f7ef86:	vpmovdb %zmm19,%xmm4
 1f7ef8c:	vgf2p8affineqb $0x0,-0x19b0a07(%rip){1to2},%xmm4,%xmm4        # 5ce590 <.LCPI3_85>
 1f7ef97:	vpternlogq $0xf8,%xmm9,%xmm4,%xmm2
 1f7ef9e:	vpor   %xmm2,%xmm11,%xmm4
 1f7efa2:	vmovdqu8 %xmm4,%xmm2{%k2}
 1f7efa8:	vpsrld $0xb,%zmm19,%zmm4
 1f7efaf:	vpmovdb %zmm4,%xmm4
 1f7efb5:	vpand  %xmm5,%xmm4,%xmm4
 1f7efb9:	vpmovdb %zmm15,%xmm5
 1f7efbf:	vpternlogq $0xfe,%xmm4,%xmm3,%xmm2
 1f7efc6:	vpsrld $0x10,%zmm15,%zmm3
 1f7efcd:	vpmovdb %zmm8,%xmm4
 1f7efd3:	vpmovdb %zmm3,%xmm3
 1f7efd9:	je     1f7e95a <node_facts_window_run+0x158a>
 1f7efdf:	vmovdqa64 -0x1ac87e9(%rip),%zmm15        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7efe9:	vptestmd %zmm6,%zmm6,%k1{%k1}
 1f7efef:	add    %r9,%rdx
 1f7eff2:	vpxor  %xmm8,%xmm8,%xmm8
 1f7eff7:	vpxor  %xmm9,%xmm9,%xmm9
 1f7effc:	vpcmpneqd -0x19ae05f(%rip){1to16},%zmm6,%k0{%k1}        # 5d0fa8 <.LCPI3_38>
 1f7f007:	vmovdqa %xmm3,%xmm6
 1f7f00b:	vpternlogq $0xfe,%xmm5,%xmm1,%xmm6
 1f7f012:	kmovq  %k1,%k2
 1f7f017:	kmovw  %k1,%eax
 1f7f01b:	popcnt %eax,%ecx
 1f7f01f:	vpgatherdd 0x10(%rdx,%zmm15,1),%zmm8{%k2}
 1f7f027:	kmovq  %k1,%k2
 1f7f02c:	vpcmpnleud -0x19ae08b(%rip){1to16},%zmm8,%k3        # 5d0fac <.LCPI3_39>
 1f7f037:	vpgatherdd 0x14(%rdx,%zmm15,1),%zmm9{%k2}
 1f7f03f:	add    %rcx,0x28(%rsp)
 1f7f044:	mov    0x10(%rsp),%rdx
 1f7f049:	vpcmpeqd %zmm7,%zmm8,%k2
 1f7f04f:	vmovdqa64 %xmm16,%xmm7
 1f7f055:	vpternlogq $0xfe,%xmm4,%xmm6,%xmm7
 1f7f05c:	vptestnmd %zmm9,%zmm9,%k2{%k2}
 1f7f062:	vptestmd %zmm9,%zmm9,%k4
 1f7f068:	vpternlogq $0xfe,%xmm2,%xmm0,%xmm7
 1f7f06f:	korw   %k4,%k3,%k3
 1f7f073:	kandw  %k2,%k0,%k2
 1f7f077:	knotw  %k0,%k0
 1f7f07b:	kandd  %k1,%k0,%k0
 1f7f080:	kandw  %k0,%k3,%k0
 1f7f084:	korw   %k0,%k2,%k2
 1f7f088:	vptestnmd %zmm10,%zmm17,%k0{%k2}
 1f7f08e:	kandw  %k0,%k1,%k0
 1f7f092:	kmovd  %k0,%ecx
 1f7f096:	vptestmb %xmm7,%xmm7,%k0
 1f7f09c:	andn   %eax,%ecx,%eax
 1f7f0a1:	kmovd  %k0,%ecx
 1f7f0a5:	andn   %ecx,%r10d,%ecx
 1f7f0aa:	popcnt %eax,%eax
 1f7f0ae:	movzwl %cx,%ecx
 1f7f0b1:	popcnt %ecx,%ecx
 1f7f0b5:	add    %rcx,%rdx
 1f7f0b8:	add    %rax,%rdx
 1f7f0bb:	mov    %rdx,0x10(%rsp)
 1f7f0c0:	jmp    1f7e95a <node_facts_window_run+0x158a>
 1f7f0c5:	kandw  %k0,%k7,%k0
 1f7f0c9:	mov    %rdx,0x2e0(%rsp)
 1f7f0d1:	vmovdqa %xmm5,0x1e0(%rsp)
 1f7f0da:	vmovdqu64 %zmm6,0x160(%rsp)
 1f7f0e5:	vmovdqu64 %zmm2,0x390(%rsp)
 1f7f0f0:	vmovdqu64 %zmm3,0x350(%rsp)
 1f7f0fb:	vmovdqu64 %zmm1,0x2a0(%rsp)
 1f7f106:	vmovdqu64 %zmm7,0x450(%rsp)
 1f7f111:	vmovdqu64 %zmm8,0x3d0(%rsp)
 1f7f11c:	vmovdqu64 %zmm9,0x410(%rsp)
 1f7f127:	vmovdqu64 %zmm15,0x4d0(%rsp)
 1f7f132:	vmovdqu64 %zmm0,0x490(%rsp)
 1f7f13d:	kmovw  %k6,0x60(%rsp)
 1f7f143:	kmovw  %k7,0x1a0(%rsp)
 1f7f14c:	vmovdqa %xmm4,0x260(%rsp)
 1f7f155:	kmovd  %k0,%eax
 1f7f159:	movzwl %ax,%r13d
 1f7f15d:	jmp    1f7f28c <node_facts_window_run+0x1ebc>
 1f7f162:	mov    (%r12,%rax,4),%r8d
 1f7f166:	shl    $0x6,%rcx
 1f7f16a:	mov    0x20(%r11),%rdx
 1f7f16e:	mov    %r8,0x30(%rsp)
 1f7f173:	movzbl 0x30(%rdx,%rcx,1),%edx
 1f7f178:	mov    0x8(%rsp),%r15
 1f7f17d:	mov    0xb48(%r15),%rsi
 1f7f184:	mov    %r15,%rdi
 1f7f187:	cmpb   $0x1,(%rsi,%r8,1)
 1f7f18c:	adcq   $0x0,0x48(%rsp)
 1f7f192:	and    $0x1,%edx
 1f7f195:	mov    0x570(%rsp),%rsi
 1f7f19d:	mov    (%rsi,%rax,4),%esi
 1f7f1a0:	vzeroupper
 1f7f1a3:	call   1f93890 <node_tests_window_line>
 1f7f1a8:	vpbroadcastd -0x19ae246(%rip),%zmm10        # 5d0f6c <.LCPI3_5>
 1f7f1b2:	vpbroadcastb -0x1ac847b(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f1bb:	vpbroadcastb -0x1ac8483(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f1c4:	vpbroadcastd -0x19ae25a(%rip),%zmm13        # 5d0f74 <.LCPI3_11>
 1f7f1ce:	vpbroadcastd -0x19ae25c(%rip),%zmm14        # 5d0f7c <.LCPI3_13>
 1f7f1d8:	vmovdqa 0x260(%rsp),%xmm4
 1f7f1e1:	vmovdqa 0x1e0(%rsp),%xmm5
 1f7f1ea:	vmovdqu64 0x160(%rsp),%zmm6
 1f7f1f5:	vmovdqu64 0x390(%rsp),%zmm2
 1f7f200:	vmovdqu64 0x350(%rsp),%zmm3
 1f7f20b:	vmovdqu64 0x2a0(%rsp),%zmm1
 1f7f216:	vmovdqu64 0x450(%rsp),%zmm7
 1f7f221:	vmovdqu64 0x3d0(%rsp),%zmm8
 1f7f22c:	vmovdqu64 0x410(%rsp),%zmm9
 1f7f237:	vmovdqu64 0x4d0(%rsp),%zmm15
 1f7f242:	vmovdqu64 0x490(%rsp),%zmm0
 1f7f24d:	mov    (%rsp),%r11
 1f7f251:	mov    0xb48(%r15),%rcx
 1f7f258:	mov    0x30(%rsp),%rdx
 1f7f25d:	mov    0x18(%rsp),%rsi
 1f7f262:	mov    0x40(%rsp),%rdi
 1f7f267:	mov    0x38(%rsp),%r8
 1f7f26c:	mov    0x20(%rsp),%r9
 1f7f271:	kmovw  0x60(%rsp),%k6
 1f7f277:	kmovw  0x1a0(%rsp),%k7
 1f7f280:	or     %bl,%al
 1f7f282:	blsr   %r13d,%r13d
 1f7f287:	mov    %al,(%rcx,%rdx,1)
 1f7f28a:	je     1f7f2f1 <node_facts_window_run+0x1f21>
 1f7f28c:	xor    %eax,%eax
 1f7f28e:	tzcnt  %r13d,%eax
 1f7f293:	mov    0x60(%r11),%esi
 1f7f297:	mov    $0x1,%bl
 1f7f299:	add    %r14,%rax
 1f7f29c:	mov    %rax,%rdx
 1f7f29f:	shl    $0x6,%rdx
 1f7f2a3:	mov    (%r9,%rdx,1),%ecx
 1f7f2a7:	mov    0xc(%r9,%rdx,1),%edx
 1f7f2ac:	shr    $0x3,%ecx
 1f7f2af:	cmp    %esi,%ecx
 1f7f2b1:	cmovae %esi,%ecx
 1f7f2b4:	test   %rdx,%rdx
 1f7f2b7:	je     1f7f162 <node_facts_window_run+0x1d92>
 1f7f2bd:	mov    0x6b0(%rsp),%rsi
 1f7f2c5:	cmp    0x3b8(%rsi),%edx
 1f7f2cb:	jae    1f7f162 <node_facts_window_run+0x1d92>
 1f7f2d1:	mov    0x6b0(%rsp),%rsi
 1f7f2d9:	mov    0x3a8(%rsi),%rsi
 1f7f2e0:	cmpl   $0x0,(%rsi,%rdx,4)
 1f7f2e4:	setne  %bl
 1f7f2e7:	shl    $0x5,%bl
 1f7f2ea:	inc    %bl
 1f7f2ec:	jmp    1f7f162 <node_facts_window_run+0x1d92>
 1f7f2f1:	mov    0x8(%rsp),%rax
 1f7f2f6:	kmovq  %k7,%k1
 1f7f2fb:	vpxord %xmm18,%xmm18,%xmm18
 1f7f301:	mov    0x2e0(%rsp),%rdx
 1f7f309:	mov    0xb48(%rax),%rax
 1f7f310:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7f317:	jmp    1f7eae9 <node_facts_window_run+0x1719>
 1f7f31c:	test   %eax,%eax
 1f7f31e:	je     1f80850 <node_facts_window_run+0x3480>
 1f7f324:	vpbroadcastd -0x19ae3c2(%rip),%zmm13        # 5d0f6c <.LCPI3_5>
 1f7f32e:	vpbroadcastb -0x1ac85f7(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f337:	vpbroadcastb -0x1ac85ff(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f340:	vpbroadcastd -0x19ae3d6(%rip),%zmm16        # 5d0f74 <.LCPI3_11>
 1f7f34a:	vpbroadcastd -0x19ae3d8(%rip),%zmm17        # 5d0f7c <.LCPI3_13>
 1f7f354:	mov    (%r11),%rcx
 1f7f357:	lea    0x69454(%rsi),%r10
 1f7f35e:	lea    0x422c(%rsi),%rdx
 1f7f365:	mov    %eax,%r15d
 1f7f368:	xor    %ebp,%ebp
 1f7f36a:	mov    %rcx,0x78(%rsp)
 1f7f36f:	mov    %r10,0x98(%rsp)
 1f7f377:	mov    %rdx,0x88(%rsp)
 1f7f37f:	movq   $0x0,0x48(%rsp)
 1f7f388:	movq   $0x0,0x28(%rsp)
 1f7f391:	movq   $0x0,0x10(%rsp)
 1f7f39a:	mov    %r15,0x90(%rsp)
 1f7f3a2:	jmp    1f7f465 <node_facts_window_run+0x2095>
 1f7f3a7:	nopw   0x0(%rax,%rax,1)
 1f7f3b0:	vpxor  %xmm1,%xmm1,%xmm1
 1f7f3b4:	vpxor  %xmm0,%xmm0,%xmm0
 1f7f3b8:	vpxor  %xmm5,%xmm5,%xmm5
 1f7f3bc:	vpxor  %xmm3,%xmm3,%xmm3
 1f7f3c0:	vpxor  %xmm6,%xmm6,%xmm6
 1f7f3c4:	vpxor  %xmm7,%xmm7,%xmm7
 1f7f3c8:	vpxor  %xmm8,%xmm8,%xmm8
 1f7f3cd:	vpxor  %xmm2,%xmm2,%xmm2
 1f7f3d1:	vpxord %xmm19,%xmm19,%xmm19
 1f7f3d7:	mov    0xb10(%r13),%rax
 1f7f3de:	vmovdqu64 %xmm19,(%rax,%rbp,1)
 1f7f3e5:	mov    0xb18(%r13),%rax
 1f7f3ec:	vmovdqu %xmm2,(%rax,%rbp,1)
 1f7f3f1:	mov    0xb88(%r11),%rax
 1f7f3f8:	vmovdqu %xmm8,(%rax,%rbp,1)
 1f7f3fd:	mov    0xb90(%r11),%rax
 1f7f404:	vmovdqu %xmm7,(%rax,%rbp,1)
 1f7f409:	mov    0xb98(%r11),%rax
 1f7f410:	vmovdqu %xmm6,(%rax,%rbp,1)
 1f7f415:	mov    0xba0(%r11),%rax
 1f7f41c:	vmovdqu %xmm3,(%rax,%rbp,1)
 1f7f421:	mov    0xba8(%r11),%rax
 1f7f428:	vmovdqu %xmm4,(%rax,%rbp,1)
 1f7f42d:	mov    0xc28(%r11),%rax
 1f7f434:	vmovdqu64 %zmm5,(%rax,%rbp,4)
 1f7f43b:	mov    0xcd8(%r11),%rax
 1f7f442:	vmovdqu64 %zmm0,(%rax,%rbp,8)
 1f7f449:	mov    0xcd8(%r11),%rax
 1f7f450:	vmovdqu64 %zmm1,0x40(%rax,%rbp,8)
 1f7f458:	add    $0x10,%rbp
 1f7f45c:	cmp    %r15,%rbp
 1f7f45f:	jae    1f8086b <node_facts_window_run+0x349b>
 1f7f465:	vpxor  %xmm4,%xmm4,%xmm4
 1f7f469:	cmp    %r8,%rbp
 1f7f46c:	jae    1f7f3b0 <node_facts_window_run+0x1fe0>
 1f7f472:	mov    %r8d,%eax
 1f7f475:	sub    %ebp,%eax
 1f7f477:	mov    $0x10,%ecx
 1f7f47c:	mov    $0xffffffff,%edx
 1f7f481:	vpxor  %xmm12,%xmm12,%xmm12
 1f7f486:	cmp    $0x10,%eax
 1f7f489:	cmovae %ecx,%eax
 1f7f48c:	mov    0x9b8(%r11),%rcx
 1f7f493:	shlx   %eax,%edx,%eax
 1f7f498:	mov    %rbp,%rdx
 1f7f49b:	shl    $0x6,%rdx
 1f7f49f:	not    %eax
 1f7f4a1:	vmovdqu (%r9,%rdx,1),%ymm4
 1f7f4a7:	vmovdqu64 0x40(%r9,%rdx,1),%ymm26
 1f7f4af:	vmovdqu64 0x80(%r9,%rdx,1),%ymm27
 1f7f4b7:	vmovdqu64 0xc0(%r9,%rdx,1),%ymm28
 1f7f4bf:	vmovdqu 0x100(%r9,%rdx,1),%ymm5
 1f7f4c9:	vmovdqu 0x140(%r9,%rdx,1),%ymm6
 1f7f4d3:	vmovdqu64 0x180(%r9,%rdx,1),%ymm24
 1f7f4db:	vmovdqu64 0x1c0(%r9,%rdx,1),%ymm25
 1f7f4e3:	vmovdqu 0x200(%r9,%rdx,1),%ymm7
 1f7f4ed:	vmovdqu64 0x240(%r9,%rdx,1),%ymm18
 1f7f4f5:	vmovdqu64 0x280(%r9,%rdx,1),%ymm22
 1f7f4fd:	vmovdqu64 0x2c0(%r9,%rdx,1),%ymm23
 1f7f505:	vmovdqu 0x300(%r9,%rdx,1),%ymm11
 1f7f50f:	vmovdqu64 0x340(%r9,%rdx,1),%ymm19
 1f7f517:	vmovdqu64 0x380(%r9,%rdx,1),%ymm20
 1f7f51f:	vmovdqu64 0x3c0(%r9,%rdx,1),%ymm21
 1f7f527:	kmovd  %eax,%k1
 1f7f52b:	mov    0xb48(%r13),%rax
 1f7f532:	vmovdqu8 (%rcx,%rbp,1),%xmm0{%k1}{z}
 1f7f539:	mov    0x98(%rsp),%rcx
 1f7f541:	vmovdqu8 (%rcx,%rbp,1),%xmm10{%k1}{z}
 1f7f548:	vptestmb %xmm0,%xmm0,%k6
 1f7f54e:	vpcmpeqb -0x19b7848(%rip),%xmm10,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7f558:	vmovdqu32 (%r12,%rbp,4),%zmm0{%k7}{z}
 1f7f55f:	kmovq  %k7,%k1
 1f7f564:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7f56b:	vptestnmd %zmm16,%zmm12,%k0
 1f7f571:	ktestw %k0,%k7
 1f7f575:	jne    1f7fcc5 <node_facts_window_run+0x28f5>
 1f7f57b:	vpmovsxbd -0x19ae5d4(%rip),%xmm3        # 5d0fb0 <.LCPI3_75>
 1f7f584:	vmovdqa64 -0x1ac8e4e(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7f58e:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7f595:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7f59c:	vptestmd -0x19ae62e(%rip){1to16},%zmm12,%k0        # 5d0f78 <.LCPI3_12>
 1f7f5a6:	vmovdqa64 %zmm0,%zmm2
 1f7f5ac:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7f5b2:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7f5b8:	vmovdqa64 %zmm3,%zmm9
 1f7f5be:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7f5c4:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7f5ca:	kmovd  %k0,%r13d
 1f7f5ce:	vptestmd %zmm17,%zmm12,%k0
 1f7f5d4:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7f5da:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7f5e1:	vmovdqu64 %zmm1,0x1e0(%rsp)
 1f7f5ec:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7f5f3:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7f5f7:	vmovdqa64 %zmm1,%zmm4
 1f7f5fd:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7f603:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7f609:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7f60f:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7f615:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7f61c:	vmovdqu %ymm3,0x1a0(%rsp)
 1f7f625:	vinserti64x4 $0x1,%ymm18,%zmm7,%zmm3
 1f7f62c:	vpunpcklqdq %ymm18,%ymm7,%ymm7
 1f7f632:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm18
 1f7f639:	vmovdqa64 %zmm3,%zmm6
 1f7f63f:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7f645:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7f64b:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7f651:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7f657:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7f65d:	vmovdqa64 %zmm18,%zmm7
 1f7f663:	vmovdqu64 %zmm5,0x260(%rsp)
 1f7f66e:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7f675:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7f67b:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7f682:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7f689:	vpermt2d %zmm5,%zmm9,%zmm18
 1f7f68f:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7f695:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7f69c:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7f6a2:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7f6a8:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7f6af:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7f6b6:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm21{%k6}{z}
 1f7f6bd:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7f6c4:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm20{%k6}{z}
 1f7f6cb:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7f6d2:	vpsrld $0x19,%zmm21,%zmm0
 1f7f6d9:	vpandd -0x19ae77b(%rip){1to16},%zmm0,%zmm0        # 5d0f68 <.LCPI3_4>
 1f7f6e3:	vpsrld $0x18,%zmm21,%zmm1
 1f7f6ea:	vpsrld $0x1a,%zmm21,%zmm7
 1f7f6f1:	vpternlogd $0xec,%zmm13,%zmm0,%zmm1
 1f7f6f8:	vpandd -0x19ae74e(%rip){1to16},%zmm21,%zmm0        # 5d0fb4 <.LCPI3_76>
 1f7f702:	vpmovdb %zmm1,%xmm19
 1f7f708:	vpsrld $0xc,%zmm20,%zmm1
 1f7f70f:	vpmovdb %zmm1,%xmm24
 1f7f715:	vpcmpeqd -0x19ae7af(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f70 <.LCPI3_7>
 1f7f71f:	vporq  %xmm14,%xmm19,%xmm0
 1f7f725:	vmovdqu8 %xmm0,%xmm19{%k1}
 1f7f72b:	vpcmpeqb %xmm14,%xmm10,%k1{%k6}
 1f7f731:	vpternlogq $0xf8,%xmm15,%xmm24,%xmm19
 1f7f738:	kmovd  %k1,%eax
 1f7f73c:	kmovw  %k1,0x30(%rsp)
 1f7f742:	korw   %k0,%k1,%k1
 1f7f746:	kmovw  %k1,0x60(%rsp)
 1f7f74c:	test   %ax,%ax
 1f7f74f:	je     1f7f92f <node_facts_window_run+0x255f>
 1f7f755:	vmovdqu64 %zmm4,0x720(%rsp)
 1f7f760:	vmovdqu %ymm5,0x6b0(%rsp)
 1f7f769:	vmovdqu64 %zmm7,0x530(%rsp)
 1f7f774:	vmovdqa64 %xmm24,0x570(%rsp)
 1f7f77c:	vmovdqu64 %zmm23,0x630(%rsp)
 1f7f787:	vmovdqu64 %zmm22,0x490(%rsp)
 1f7f792:	vmovdqu64 %zmm21,0x4d0(%rsp)
 1f7f79d:	vmovdqu64 %zmm18,0x410(%rsp)
 1f7f7a8:	vmovdqu64 %zmm20,0x3d0(%rsp)
 1f7f7b3:	vmovdqu64 %zmm12,0x450(%rsp)
 1f7f7be:	vmovdqa64 %xmm19,0x2a0(%rsp)
 1f7f7c6:	kmovw  %k7,0x160(%rsp)
 1f7f7cf:	mov    %rdx,0x390(%rsp)
 1f7f7d7:	kmovd  %k6,0x2e0(%rsp)
 1f7f7e1:	movzwl %ax,%r14d
 1f7f7e5:	movzwl %r13w,%r13d
 1f7f7e9:	xor    %r15d,%r15d
 1f7f7ec:	mov    0x88(%rsp),%rax
 1f7f7f4:	mov    %rbp,0x350(%rsp)
 1f7f7fc:	lea    (%rax,%rbp,4),%rbx
 1f7f800:	mov    0x8(%rsp),%rbp
 1f7f805:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7f810:	xor    %r12d,%r12d
 1f7f813:	tzcnt  %r14d,%r12d
 1f7f818:	mov    %rbp,%rdi
 1f7f81b:	xor    %edx,%edx
 1f7f81d:	mov    (%rbx,%r12,4),%esi
 1f7f821:	vzeroupper
 1f7f824:	call   1f93890 <node_tests_window_line>
 1f7f829:	mov    $0x1,%ecx
 1f7f82e:	test   $0x2,%al
 1f7f830:	shlx   %r12d,%ecx,%eax
 1f7f835:	cmove  %r15d,%eax
 1f7f839:	or     %eax,%r13d
 1f7f83c:	blsr   %r14d,%r14d
 1f7f841:	jne    1f7f810 <node_facts_window_run+0x2440>
 1f7f843:	vpbroadcastd -0x19ae8e1(%rip),%zmm13        # 5d0f6c <.LCPI3_5>
 1f7f84d:	vpbroadcastb -0x1ac8b16(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f856:	vpbroadcastb -0x1ac8b1e(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f85f:	vpbroadcastd -0x19ae8f5(%rip),%zmm16        # 5d0f74 <.LCPI3_11>
 1f7f869:	vpbroadcastd -0x19ae8f7(%rip),%zmm17        # 5d0f7c <.LCPI3_13>
 1f7f873:	vmovdqa64 0x2a0(%rsp),%xmm19
 1f7f87b:	vmovdqu64 0x450(%rsp),%zmm12
 1f7f886:	vmovdqu64 0x3d0(%rsp),%zmm20
 1f7f891:	vmovdqu64 0x410(%rsp),%zmm18
 1f7f89c:	vmovdqu64 0x4d0(%rsp),%zmm21
 1f7f8a7:	vmovdqu64 0x490(%rsp),%zmm22
 1f7f8b2:	vmovdqu64 0x630(%rsp),%zmm23
 1f7f8bd:	vmovdqa64 0x570(%rsp),%xmm24
 1f7f8c5:	vmovdqu64 0x530(%rsp),%zmm7
 1f7f8d0:	vmovdqu 0x6b0(%rsp),%ymm5
 1f7f8d9:	vmovdqu64 0x720(%rsp),%zmm4
 1f7f8e4:	mov    (%rsp),%r11
 1f7f8e8:	mov    0x18(%rsp),%rsi
 1f7f8ed:	mov    0x40(%rsp),%rdi
 1f7f8f2:	mov    0x220(%rsp),%r12
 1f7f8fa:	mov    0x38(%rsp),%r8
 1f7f8ff:	mov    0x20(%rsp),%r9
 1f7f904:	mov    0x90(%rsp),%r15
 1f7f90c:	mov    0x350(%rsp),%rbp
 1f7f914:	kmovd  0x2e0(%rsp),%k6
 1f7f91e:	mov    0x390(%rsp),%rdx
 1f7f926:	kmovw  0x160(%rsp),%k7
 1f7f92f:	vpsrld $0x2,%zmm20,%zmm0
 1f7f936:	vpandd -0x19ae9c0(%rip){1to16},%zmm0,%zmm2        # 5d0f80 <.LCPI3_14>
 1f7f940:	vpbroadcastd -0x19ae9c6(%rip),%zmm0        # 5d0f84 <.LCPI3_15>
 1f7f94a:	vptestmd -0x19ae9cc(%rip){1to16},%zmm20,%k3        # 5d0f88 <.LCPI3_16>
 1f7f954:	vmovdqu64 0x260(%rsp),%zmm1
 1f7f95f:	vptestnmd %zmm4,%zmm4,%k1
 1f7f965:	vpbroadcastd -0x19ae9db(%rip),%zmm6        # 5d0f94 <.LCPI3_21>
 1f7f96f:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7f976:	kmovd  %r13d,%k4
 1f7f97b:	vpsrld $0x10,%zmm20,%zmm9
 1f7f982:	vpbroadcastb -0x1ac8c49(%rip),%xmm8        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7f98b:	vpbroadcastb -0x1ac8c51(%rip),%xmm11        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7f994:	kmovw  %k1,%eax
 1f7f998:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7f99e:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7f9a5:	vmovdqu64 0x1e0(%rsp),%zmm0
 1f7f9b0:	korw   %k1,%k3,%k3
 1f7f9b4:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7f9bb:	vpandd -0x19aea0d(%rip){1to16},%zmm21,%zmm5        # 5d0fb8 <.LCPI3_79>
 1f7f9c5:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7f9cb:	vpbroadcastb -0x1ac8c90(%rip),%xmm7        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7f9d4:	vinserti64x4 $0x1,0x1a0(%rsp),%zmm0,%zmm0
 1f7f9dd:	kmovw  %k0,%ecx
 1f7f9e1:	korw   %k2,%k3,%k2
 1f7f9e5:	vpaddd -0x19aea5f(%rip){1to16},%zmm5,%zmm5        # 5d0f90 <.LCPI3_20>
 1f7f9ef:	andn   %ecx,%eax,%eax
 1f7f9f4:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7f9fa:	kmovd  %eax,%k3
 1f7f9fe:	shr    $0x8,%eax
 1f7fa01:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7fa07:	kmovd  %eax,%k3
 1f7fa0b:	vmovdqu8 %xmm14,%xmm4{%k2}{z}
 1f7fa11:	vpcmpltud %zmm6,%zmm5,%k2
 1f7fa18:	vpslld $0x1f,%zmm5,%zmm5
 1f7fa1f:	vpxor  %xmm6,%xmm6,%xmm6
 1f7fa23:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7fa29:	vptestmd -0x19aeaa7(%rip){1to16},%zmm23,%k3        # 5d0f8c <.LCPI3_17>
 1f7fa33:	vpandd %zmm17,%zmm23,%zmm3
 1f7fa39:	vptestnmd %zmm3,%zmm3,%k0
 1f7fa3f:	kandd  %k6,%k0,%k0
 1f7fa44:	korw   %k3,%k4,%k3
 1f7fa48:	kandd  %k2,%k0,%k4
 1f7fa4d:	vpcmpeqd %zmm16,%zmm2,%k2{%k4}
 1f7fa53:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7fa59:	vmovdqu8 -0x19b7d23(%rip),%xmm2{%k4}        # 5c7d40 <.LCPI3_25>
 1f7fa63:	knotw  %k2,%k0
 1f7fa67:	kandd  %k0,%k4,%k5
 1f7fa6c:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7fa72:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7fa79:	vpaddd %zmm5,%zmm9,%zmm10
 1f7fa7f:	vpbroadcastb -0x1ac8d43(%rip),%xmm5        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7fa88:	vmovdqu8 -0x19b7d42(%rip),%xmm2{%k4}        # 5c7d50 <.LCPI3_26>
 1f7fa92:	vptestnmd %zmm10,%zmm10,%k4
 1f7fa98:	vpblendmb -0x19b7d32(%rip),%xmm5,%xmm5{%k4}        # 5c7d70 <.LCPI3_28>
 1f7faa2:	vpcmpnleud -0x19aeb15(%rip){1to16},%zmm10,%k4        # 5d0f98 <.LCPI3_22>
 1f7faad:	mov    0x8(%rsp),%r13
 1f7fab2:	cmpb   $0x0,0xb90(%r13)
 1f7faba:	vmovdqu8 -0x19b7d44(%rip),%xmm5{%k4}        # 5c7d80 <.LCPI3_29>
 1f7fac4:	vpcmpnleud -0x19aeb33(%rip){1to16},%zmm10,%k4        # 5d0f9c <.LCPI3_23>
 1f7facf:	vmovdqu8 -0x19b7d49(%rip),%xmm5{%k4}        # 5c7d90 <.LCPI3_30>
 1f7fad9:	vptestmd %zmm3,%zmm3,%k4
 1f7fadf:	vpor   %xmm4,%xmm8,%xmm3
 1f7fae3:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7fae9:	kmovw  0x60(%rsp),%k4
 1f7faef:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7faf5:	vpor   %xmm2,%xmm4,%xmm2
 1f7faf9:	vpord  -0x19aeb47(%rip){1to4},%xmm2,%xmm3        # 5d0fbc <.LCPI3_82>
 1f7fb03:	vpbroadcastb -0x1ac8dc6(%rip),%xmm5        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7fb0c:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7fb12:	vpor   %xmm5,%xmm2,%xmm3
 1f7fb16:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7fb1c:	vpmovdb %zmm20,%xmm3
 1f7fb22:	kmovw  0x30(%rsp),%k3
 1f7fb28:	vpor   %xmm3,%xmm11,%xmm4
 1f7fb2c:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7fb32:	vptestmd -0x19aeb9c(%rip){1to16},%zmm12,%k3{%k7}        # 5d0fa0 <.LCPI3_32>
 1f7fb3c:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7fb42:	vpor   %xmm5,%xmm4,%xmm6
 1f7fb46:	vpsrld $0xb,%zmm23,%zmm7
 1f7fb4d:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7fb53:	vpandd -0x19aeb9d(%rip){1to4},%xmm24,%xmm4        # 5d0fc0 <.LCPI3_84>
 1f7fb5d:	vptestmd -0x19aebc3(%rip){1to16},%zmm23,%k1        # 5d0fa4 <.LCPI3_33>
 1f7fb67:	vpmovdb %zmm7,%xmm7
 1f7fb6d:	vpand  %xmm7,%xmm8,%xmm7
 1f7fb71:	vpmovdb %zmm21,%xmm8
 1f7fb77:	vpor   %xmm4,%xmm15,%xmm5
 1f7fb7b:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7fb81:	vpmovdb %zmm23,%xmm5
 1f7fb87:	vgf2p8affineqb $0x0,-0x19b1602(%rip){1to2},%xmm5,%xmm5        # 5ce590 <.LCPI3_85>
 1f7fb92:	vpternlogq $0xf8,%xmm11,%xmm5,%xmm4
 1f7fb99:	vpsrld $0x8,%zmm21,%zmm11
 1f7fba0:	vpor   %xmm4,%xmm14,%xmm5
 1f7fba4:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7fbaa:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7fbb1:	vpsrld $0x10,%zmm21,%zmm6
 1f7fbb8:	vpmovdb %zmm11,%xmm7
 1f7fbbe:	vinserti32x4 $0x3,%xmm18,%zmm22,%zmm5{%k6}{z}
 1f7fbc5:	vpmovdb %zmm6,%xmm6
 1f7fbcb:	je     1f7f3d7 <node_facts_window_run+0x2007>
 1f7fbd1:	vmovdqa64 -0x1ac93db(%rip),%zmm18        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7fbdb:	vptestmd %zmm9,%zmm9,%k1{%k2}
 1f7fbe1:	add    %r9,%rdx
 1f7fbe4:	vpxor  %xmm11,%xmm11,%xmm11
 1f7fbe9:	vpxor  %xmm12,%xmm12,%xmm12
 1f7fbee:	vpcmpneqd -0x19aec51(%rip){1to16},%zmm9,%k0{%k1}        # 5d0fa8 <.LCPI3_38>
 1f7fbf9:	vmovdqa %xmm6,%xmm9
 1f7fbfd:	vpternlogq $0xfe,%xmm8,%xmm3,%xmm9
 1f7fc04:	kmovq  %k1,%k2
 1f7fc09:	kmovw  %k1,%eax
 1f7fc0d:	popcnt %eax,%ecx
 1f7fc11:	vpgatherdd 0x10(%rdx,%zmm18,1),%zmm11{%k2}
 1f7fc19:	kmovq  %k1,%k2
 1f7fc1e:	vpcmpnleud -0x19aec7d(%rip){1to16},%zmm11,%k3        # 5d0fac <.LCPI3_39>
 1f7fc29:	vpgatherdd 0x14(%rdx,%zmm18,1),%zmm12{%k2}
 1f7fc31:	add    %rcx,0x28(%rsp)
 1f7fc36:	mov    0x10(%rsp),%r10
 1f7fc3b:	vpcmpeqd %zmm10,%zmm11,%k2
 1f7fc41:	vmovdqa64 %xmm19,%xmm10
 1f7fc47:	vpternlogq $0xfe,%xmm7,%xmm9,%xmm10
 1f7fc4e:	vptestnmd %zmm12,%zmm12,%k2{%k2}
 1f7fc54:	vptestmd %zmm12,%zmm12,%k4
 1f7fc5a:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm10
 1f7fc61:	korw   %k4,%k3,%k3
 1f7fc65:	kandw  %k2,%k0,%k2
 1f7fc69:	knotw  %k0,%k0
 1f7fc6d:	kandd  %k1,%k0,%k0
 1f7fc72:	kandw  %k0,%k3,%k0
 1f7fc76:	korw   %k0,%k2,%k2
 1f7fc7a:	vptestnmd %zmm13,%zmm20,%k0{%k2}
 1f7fc80:	kandw  %k0,%k1,%k0
 1f7fc84:	knotd  %k6,%k1
 1f7fc89:	kmovd  %k0,%ecx
 1f7fc8d:	vptestmb %xmm10,%xmm10,%k0{%k1}
 1f7fc93:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7fc99:	andn   %eax,%ecx,%eax
 1f7fc9e:	popcnt %eax,%eax
 1f7fca2:	kmovw  %k0,%ecx
 1f7fca6:	popcnt %ecx,%ecx
 1f7fcaa:	kmovw  %k1,%edx
 1f7fcae:	popcnt %edx,%edx
 1f7fcb2:	add    %rdx,%r10
 1f7fcb5:	add    %rax,%r10
 1f7fcb8:	add    %rcx,%r10
 1f7fcbb:	mov    %r10,0x10(%rsp)
 1f7fcc0:	jmp    1f7f3d7 <node_facts_window_run+0x2007>
 1f7fcc5:	kandw  %k0,%k7,%k0
 1f7fcc9:	mov    %rdx,0x390(%rsp)
 1f7fcd1:	vmovdqa %xmm10,0x260(%rsp)
 1f7fcda:	vmovdqu64 %zmm11,0x350(%rsp)
 1f7fce5:	vmovdqu64 %ymm19,0x2a0(%rsp)
 1f7fced:	vmovdqu64 %zmm20,0x450(%rsp)
 1f7fcf8:	vmovdqu64 %ymm21,0x3d0(%rsp)
 1f7fd03:	vmovdqu64 %zmm7,0x410(%rsp)
 1f7fd0e:	vmovdqu64 %ymm18,0x4d0(%rsp)
 1f7fd19:	vmovdqu64 %zmm22,0x490(%rsp)
 1f7fd24:	vmovdqu64 %ymm23,0x630(%rsp)
 1f7fd2f:	vmovdqu64 %zmm5,0x570(%rsp)
 1f7fd3a:	vmovdqu %ymm6,0x530(%rsp)
 1f7fd43:	vmovdqu64 %zmm24,0x6b0(%rsp)
 1f7fd4e:	vmovdqu64 %ymm25,0x720(%rsp)
 1f7fd56:	vmovdqu64 %zmm4,0x5f0(%rsp)
 1f7fd61:	vmovdqu64 %ymm26,0x100(%rsp)
 1f7fd69:	vmovdqu64 %zmm27,0x5b0(%rsp)
 1f7fd74:	vmovdqu64 %ymm28,0x120(%rsp)
 1f7fd7c:	vmovdqu64 %zmm0,0x670(%rsp)
 1f7fd87:	kmovd  %k6,0x2e0(%rsp)
 1f7fd91:	kmovw  %k7,0x160(%rsp)
 1f7fd9a:	kmovd  %k0,%eax
 1f7fd9e:	movzwl %ax,%eax
 1f7fda1:	jmp    1f7ff49 <node_facts_window_run+0x2b79>
 1f7fda6:	mov    0x48(%rsp),%rsi
 1f7fdab:	mov    (%r12,%r13,4),%r8d
 1f7fdaf:	mov    %dil,0x1a0(%rsp)
 1f7fdb7:	shl    $0x6,%rax
 1f7fdbb:	mov    0x20(%r11),%rcx
 1f7fdbf:	mov    %r8,0x1e0(%rsp)
 1f7fdc7:	mov    0x8(%rsp),%rbx
 1f7fdcc:	mov    0xb48(%rbx),%rdx
 1f7fdd3:	mov    %rbx,%rdi
 1f7fdd6:	cmpb   $0x1,(%rdx,%r8,1)
 1f7fddb:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7fde0:	adc    $0x0,%rsi
 1f7fde4:	and    $0x1,%edx
 1f7fde7:	mov    %rsi,0x48(%rsp)
 1f7fdec:	mov    0x88(%rsp),%r14
 1f7fdf4:	mov    (%r14,%r13,4),%esi
 1f7fdf8:	vzeroupper
 1f7fdfb:	call   1f93890 <node_tests_window_line>
 1f7fe00:	mov    (%r14,%r13,4),%esi
 1f7fe04:	mov    %rbx,%rdi
 1f7fe07:	mov    %al,0x60(%rsp)
 1f7fe0b:	call   1f939e0 <node_tests_window_returns>
 1f7fe10:	or     0x1a0(%rsp),%al
 1f7fe17:	mov    0xb48(%rbx),%rcx
 1f7fe1e:	mov    0x1e0(%rsp),%rdx
 1f7fe26:	vpbroadcastd -0x19aeec4(%rip),%zmm13        # 5d0f6c <.LCPI3_5>
 1f7fe30:	vpbroadcastb -0x1ac90f9(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7fe39:	vpbroadcastb -0x1ac9101(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7fe42:	vpbroadcastd -0x19aeed8(%rip),%zmm16        # 5d0f74 <.LCPI3_11>
 1f7fe4c:	vpbroadcastd -0x19aeeda(%rip),%zmm17        # 5d0f7c <.LCPI3_13>
 1f7fe56:	vmovdqa 0x260(%rsp),%xmm10
 1f7fe5f:	vmovdqu64 0x350(%rsp),%zmm11
 1f7fe6a:	vmovdqu64 0x2a0(%rsp),%ymm19
 1f7fe72:	vmovdqu64 0x450(%rsp),%zmm20
 1f7fe7d:	vmovdqu64 0x3d0(%rsp),%ymm21
 1f7fe88:	vmovdqu64 0x410(%rsp),%zmm7
 1f7fe93:	vmovdqu64 0x4d0(%rsp),%ymm18
 1f7fe9e:	vmovdqu64 0x490(%rsp),%zmm22
 1f7fea9:	vmovdqu64 0x630(%rsp),%ymm23
 1f7feb4:	vmovdqu64 0x570(%rsp),%zmm5
 1f7febf:	vmovdqu 0x530(%rsp),%ymm6
 1f7fec8:	vmovdqu64 0x6b0(%rsp),%zmm24
 1f7fed3:	vmovdqu64 0x720(%rsp),%ymm25
 1f7fedb:	vmovdqu64 0x5f0(%rsp),%zmm4
 1f7fee6:	vmovdqu64 0x100(%rsp),%ymm26
 1f7feee:	vmovdqu64 0x5b0(%rsp),%zmm27
 1f7fef9:	vmovdqu64 0x120(%rsp),%ymm28
 1f7ff01:	vmovdqu64 0x670(%rsp),%zmm0
 1f7ff0c:	mov    (%rsp),%r11
 1f7ff10:	mov    0x18(%rsp),%rsi
 1f7ff15:	mov    0x40(%rsp),%rdi
 1f7ff1a:	mov    0x38(%rsp),%r8
 1f7ff1f:	mov    0x20(%rsp),%r9
 1f7ff24:	kmovd  0x2e0(%rsp),%k6
 1f7ff2e:	kmovw  0x160(%rsp),%k7
 1f7ff37:	or     0x60(%rsp),%al
 1f7ff3b:	mov    %al,(%rcx,%rdx,1)
 1f7ff3e:	mov    0x30(%rsp),%eax
 1f7ff42:	blsr   %eax,%eax
 1f7ff47:	je     1f7ffb3 <node_facts_window_run+0x2be3>
 1f7ff49:	tzcnt  %eax,%r13d
 1f7ff4e:	mov    %eax,0x30(%rsp)
 1f7ff52:	mov    0x60(%r11),%edx
 1f7ff56:	mov    $0x1,%dil
 1f7ff59:	add    %rbp,%r13
 1f7ff5c:	mov    %r13,%rcx
 1f7ff5f:	shl    $0x6,%rcx
 1f7ff63:	mov    (%r9,%rcx,1),%eax
 1f7ff67:	mov    0xc(%r9,%rcx,1),%ecx
 1f7ff6c:	shr    $0x3,%eax
 1f7ff6f:	cmp    %edx,%eax
 1f7ff71:	cmovae %edx,%eax
 1f7ff74:	test   %rcx,%rcx
 1f7ff77:	je     1f7fda6 <node_facts_window_run+0x29d6>
 1f7ff7d:	mov    0x78(%rsp),%rdx
 1f7ff82:	mov    0x48(%rsp),%rsi
 1f7ff87:	cmp    0x3b8(%rdx),%ecx
 1f7ff8d:	jae    1f7fdab <node_facts_window_run+0x29db>
 1f7ff93:	mov    0x78(%rsp),%rdx
 1f7ff98:	mov    0x3a8(%rdx),%rdx
 1f7ff9f:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7ffa3:	setne  %dil
 1f7ffa7:	shl    $0x5,%dil
 1f7ffab:	inc    %dil
 1f7ffae:	jmp    1f7fdab <node_facts_window_run+0x29db>
 1f7ffb3:	mov    0xb48(%rbx),%rax
 1f7ffba:	kmovq  %k7,%k1
 1f7ffbf:	vpxor  %xmm12,%xmm12,%xmm12
 1f7ffc4:	mov    0x390(%rsp),%rdx
 1f7ffcc:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7ffd3:	jmp    1f7f57b <node_facts_window_run+0x21ab>
 1f7ffd8:	test   %eax,%eax
 1f7ffda:	je     1f80850 <node_facts_window_run+0x3480>
 1f7ffe0:	vpbroadcastd -0x19af07e(%rip),%zmm6        # 5d0f6c <.LCPI3_5>
 1f7ffea:	vpbroadcastb -0x1ac92b1(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7fff3:	vpbroadcastd -0x19af089(%rip),%zmm8        # 5d0f74 <.LCPI3_11>
 1f7fffd:	vpbroadcastd -0x19af08b(%rip),%zmm9        # 5d0f7c <.LCPI3_13>
 1f80007:	lea    0x69454(%rsi),%rcx
 1f8000e:	lea    0x422c(%rsi),%r15
 1f80015:	mov    %eax,%r10d
 1f80018:	xor    %r14d,%r14d
 1f8001b:	mov    %rcx,0x450(%rsp)
 1f80023:	movq   $0x0,0x48(%rsp)
 1f8002c:	movq   $0x0,0x28(%rsp)
 1f80035:	movq   $0x0,0x10(%rsp)
 1f8003e:	mov    %r10,0x3d0(%rsp)
 1f80046:	mov    %r15,0x410(%rsp)
 1f8004e:	jmp    1f8007c <node_facts_window_run+0x2cac>
 1f80050:	vpxor  %xmm11,%xmm11,%xmm11
 1f80055:	mov    0xb10(%r13),%rax
 1f8005c:	vmovdqu %xmm11,(%rax,%r14,1)
 1f80062:	mov    0xb18(%r13),%rax
 1f80069:	vmovdqu %xmm0,(%rax,%r14,1)
 1f8006f:	add    $0x10,%r14
 1f80073:	cmp    %r10,%r14
 1f80076:	jae    1f8086b <node_facts_window_run+0x349b>
 1f8007c:	vpxor  %xmm0,%xmm0,%xmm0
 1f80080:	cmp    %r8,%r14
 1f80083:	jae    1f80050 <node_facts_window_run+0x2c80>
 1f80085:	mov    %r8d,%eax
 1f80088:	sub    %r14d,%eax
 1f8008b:	mov    $0x10,%ecx
 1f80090:	mov    $0xffffffff,%edx
 1f80095:	mov    %r14,%rbp
 1f80098:	cmp    $0x10,%eax
 1f8009b:	cmovae %ecx,%eax
 1f8009e:	mov    0x9b8(%r11),%rcx
 1f800a5:	shl    $0x6,%rbp
 1f800a9:	shlx   %eax,%edx,%eax
 1f800ae:	vmovdqu 0x100(%r9,%rbp,1),%ymm2
 1f800b8:	vmovdqu 0x180(%r9,%rbp,1),%ymm3
 1f800c2:	vmovdqu (%r9,%rbp,1),%ymm0
 1f800c8:	vmovdqu 0x80(%r9,%rbp,1),%ymm1
 1f800d2:	not    %eax
 1f800d4:	vinserti64x4 $0x1,0x140(%r9,%rbp,1),%zmm2,%zmm5
 1f800dd:	vinserti64x4 $0x1,0x1c0(%r9,%rbp,1),%zmm3,%zmm2
 1f800e6:	vinserti64x4 $0x1,0x40(%r9,%rbp,1),%zmm0,%zmm4
 1f800ef:	vmovdqu 0x200(%r9,%rbp,1),%ymm0
 1f800f9:	vinserti64x4 $0x1,0xc0(%r9,%rbp,1),%zmm1,%zmm12
 1f80102:	kmovd  %eax,%k1
 1f80106:	vinserti64x4 $0x1,0x240(%r9,%rbp,1),%zmm0,%zmm11
 1f8010f:	vmovdqu 0x280(%r9,%rbp,1),%ymm0
 1f80119:	mov    0xb48(%r13),%rax
 1f80120:	vinserti64x4 $0x1,0x2c0(%r9,%rbp,1),%zmm0,%zmm14
 1f80129:	vmovdqu 0x300(%r9,%rbp,1),%ymm0
 1f80133:	vmovdqu8 (%rcx,%r14,1),%xmm10{%k1}{z}
 1f8013a:	mov    0x450(%rsp),%rcx
 1f80142:	vinserti64x4 $0x1,0x340(%r9,%rbp,1),%zmm0,%zmm13
 1f8014b:	vmovdqu 0x380(%r9,%rbp,1),%ymm0
 1f80155:	vinserti64x4 $0x1,0x3c0(%r9,%rbp,1),%zmm0,%zmm15
 1f8015e:	vmovdqu8 (%rcx,%r14,1),%xmm3{%k1}{z}
 1f80165:	vptestmb %xmm10,%xmm10,%k2
 1f8016b:	vpxor  %xmm0,%xmm0,%xmm0
 1f8016f:	vpcmpeqb %xmm7,%xmm3,%k3{%k2}
 1f80175:	vmovdqu32 (%r12,%r14,4),%zmm1{%k3}{z}
 1f8017c:	kmovq  %k3,%k1
 1f80181:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f80188:	vptestnmd %zmm8,%zmm0,%k0
 1f8018e:	ktestw %k0,%k3
 1f80192:	jne    1f8064c <node_facts_window_run+0x327c>
 1f80198:	vmovdqa64 -0x1ac9a62(%rip),%zmm1        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f801a2:	kmovd  %k2,%edx
 1f801a6:	vpermt2d %zmm12,%zmm1,%zmm4
 1f801ac:	vpermt2d %zmm2,%zmm1,%zmm5
 1f801b2:	vpermt2d %zmm14,%zmm1,%zmm11
 1f801b8:	vpermt2d %zmm15,%zmm1,%zmm13
 1f801be:	vshufi64x2 $0x44,%zmm13,%zmm11,%zmm2
 1f801c5:	vshufi64x2 $0x44,%zmm5,%zmm4,%zmm1
 1f801cc:	vshufi64x2 $0xee,%zmm5,%zmm4,%zmm14
 1f801d3:	vshufi64x2 $0xee,%zmm13,%zmm11,%zmm13
 1f801da:	vshufi32x4 $0x88,%zmm2,%zmm1,%zmm4{%k2}{z}
 1f801e1:	vshufi32x4 $0xdd,%zmm2,%zmm1,%zmm5{%k2}{z}
 1f801e8:	vshufi32x4 $0xdd,%zmm13,%zmm14,%zmm12{%k2}{z}
 1f801ef:	vpsrld $0x19,%zmm4,%zmm1
 1f801f6:	vpandd -0x19af298(%rip){1to16},%zmm1,%zmm1        # 5d0f68 <.LCPI3_4>
 1f80200:	vpsrld $0x18,%zmm4,%zmm2
 1f80207:	vpternlogd $0xec,%zmm6,%zmm1,%zmm2
 1f8020e:	vpandd -0x19af264(%rip){1to16},%zmm4,%zmm1        # 5d0fb4 <.LCPI3_76>
 1f80218:	vpmovdb %zmm2,%xmm11
 1f8021e:	vpbroadcastb -0x1ac94e7(%rip),%xmm2        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f80227:	vpcmpeqd -0x19af2c1(%rip){1to16},%zmm1,%k1{%k2}        # 5d0f70 <.LCPI3_7>
 1f80231:	vpor   %xmm2,%xmm11,%xmm1
 1f80235:	vpcmpeqb %xmm2,%xmm3,%k0{%k2}
 1f8023b:	kmovd  %k0,%eax
 1f8023f:	vmovdqu8 %xmm1,%xmm11{%k1}
 1f80245:	vptestmd %zmm9,%zmm0,%k1
 1f8024b:	korw   %k1,%k0,%k5
 1f8024f:	vptestmd -0x19af2e1(%rip){1to16},%zmm0,%k0        # 5d0f78 <.LCPI3_12>
 1f80259:	kmovd  %k0,%r13d
 1f8025d:	test   %ax,%ax
 1f80260:	je     1f803c6 <node_facts_window_run+0x2ff6>
 1f80266:	vmovdqu64 %zmm13,0x2a0(%rsp)
 1f80271:	vmovdqu64 %zmm14,0x350(%rsp)
 1f8027c:	vmovdqu64 %zmm5,0x390(%rsp)
 1f80287:	vmovdqu64 %zmm4,0x160(%rsp)
 1f80292:	kmovw  %k5,0x2e0(%rsp)
 1f8029b:	vmovdqu64 %zmm12,0x260(%rsp)
 1f802a6:	mov    %edx,0x1a0(%rsp)
 1f802ad:	vmovdqa %xmm11,0x60(%rsp)
 1f802b3:	vmovdqa %xmm10,0x1e0(%rsp)
 1f802bc:	mov    %r14,0x30(%rsp)
 1f802c1:	lea    (%r15,%r14,4),%r14
 1f802c5:	movzwl %r13w,%r13d
 1f802c9:	movzwl %ax,%ebx
 1f802cc:	mov    0x8(%rsp),%r15
 1f802d1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f802e0:	xor    %r12d,%r12d
 1f802e3:	tzcnt  %ebx,%r12d
 1f802e8:	mov    %r15,%rdi
 1f802eb:	xor    %edx,%edx
 1f802ed:	mov    (%r14,%r12,4),%esi
 1f802f1:	vzeroupper
 1f802f4:	call   1f93890 <node_tests_window_line>
 1f802f9:	mov    $0x1,%edx
 1f802fe:	xor    %ecx,%ecx
 1f80300:	test   $0x2,%al
 1f80302:	shlx   %r12d,%edx,%eax
 1f80307:	cmove  %ecx,%eax
 1f8030a:	or     %eax,%r13d
 1f8030d:	blsr   %ebx,%ebx
 1f80312:	jne    1f802e0 <node_facts_window_run+0x2f10>
 1f80314:	vpbroadcastd -0x19af3b2(%rip),%zmm6        # 5d0f6c <.LCPI3_5>
 1f8031e:	vpbroadcastb -0x1ac95e5(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f80327:	vpbroadcastd -0x19af3bd(%rip),%zmm8        # 5d0f74 <.LCPI3_11>
 1f80331:	vpbroadcastd -0x19af3bf(%rip),%zmm9        # 5d0f7c <.LCPI3_13>
 1f8033b:	vmovdqa 0x1e0(%rsp),%xmm10
 1f80344:	vmovdqa 0x60(%rsp),%xmm11
 1f8034a:	vmovdqu64 0x260(%rsp),%zmm12
 1f80355:	vmovdqu64 0x160(%rsp),%zmm4
 1f80360:	vmovdqu64 0x390(%rsp),%zmm5
 1f8036b:	vmovdqu64 0x350(%rsp),%zmm14
 1f80376:	vmovdqu64 0x2a0(%rsp),%zmm13
 1f80381:	mov    (%rsp),%r11
 1f80385:	mov    0x18(%rsp),%rsi
 1f8038a:	mov    0x40(%rsp),%rdi
 1f8038f:	mov    0x220(%rsp),%r12
 1f80397:	mov    0x38(%rsp),%r8
 1f8039c:	mov    0x20(%rsp),%r9
 1f803a1:	mov    0x410(%rsp),%r15
 1f803a9:	mov    0x3d0(%rsp),%r10
 1f803b1:	mov    0x30(%rsp),%r14
 1f803b6:	mov    0x1a0(%rsp),%edx
 1f803bd:	kmovw  0x2e0(%rsp),%k5
 1f803c6:	vpsrld $0x2,%zmm12,%zmm2
 1f803cd:	vpandd -0x19af457(%rip){1to16},%zmm2,%zmm2        # 5d0f80 <.LCPI3_14>
 1f803d7:	vptestmd -0x19af459(%rip){1to16},%zmm12,%k2        # 5d0f88 <.LCPI3_16>
 1f803e1:	vshufi64x2 $0x88,%zmm13,%zmm14,%zmm0
 1f803e8:	vptestnmb %xmm10,%xmm10,%k0
 1f803ee:	vpsrld $0x1a,%zmm4,%zmm1
 1f803f5:	vpandd -0x19af447(%rip){1to16},%zmm4,%zmm4        # 5d0fb8 <.LCPI3_79>
 1f803ff:	kmovd  %r13d,%k3
 1f80404:	vpcmpneqd -0x19af48b(%rip){1to16},%zmm2,%k1        # 5d0f84 <.LCPI3_15>
 1f8040f:	vpaddd -0x19af489(%rip){1to16},%zmm4,%zmm4        # 5d0f90 <.LCPI3_20>
 1f80419:	korw   %k1,%k2,%k1
 1f8041d:	vptestnmd %zmm0,%zmm0,%k2
 1f80423:	vpandd %zmm9,%zmm5,%zmm0
 1f80429:	korw   %k2,%k0,%k0
 1f8042d:	vptestmd -0x19af4ab(%rip){1to16},%zmm5,%k2        # 5d0f8c <.LCPI3_17>
 1f80437:	vpbroadcastd -0x19af4ad(%rip),%zmm5        # 5d0f94 <.LCPI3_21>
 1f80441:	korw   %k1,%k0,%k1
 1f80445:	vptestnmd %zmm0,%zmm0,%k0
 1f8044b:	kmovd  %k0,%eax
 1f8044f:	vptestmd %zmm2,%zmm2,%k1{%k1}
 1f80455:	vmovdqu8 -0x19b876f(%rip),%xmm3{%k1}{z}        # 5c7cf0 <.LCPI3_8>
 1f8045f:	vpcmpeqd %zmm5,%zmm1,%k4
 1f80465:	vpcmpltud %zmm5,%zmm4,%k0
 1f8046c:	korw   %k2,%k3,%k1
 1f80470:	vpslld $0x1f,%zmm4,%zmm1
 1f80477:	vpbroadcastb -0x1ac973b(%rip),%xmm4        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f80480:	vptestmb %xmm10,%xmm10,%k4{%k4}
 1f80486:	kmovd  %k0,%ecx
 1f8048a:	and    %eax,%ecx
 1f8048c:	mov    %edx,%eax
 1f8048e:	and    %ecx,%eax
 1f80490:	vmovdqu8 -0x19b876a(%rip),%xmm5{%k4}{z}        # 5c7d30 <.LCPI3_24>
 1f8049a:	kmovd  %eax,%k3
 1f8049e:	vpcmpeqd %zmm8,%zmm2,%k2{%k3}
 1f804a4:	vpxor  %xmm2,%xmm2,%xmm2
 1f804a8:	knotw  %k2,%k0
 1f804ac:	kmovd  %k0,%ecx
 1f804b0:	and    %eax,%ecx
 1f804b2:	vmovdqu8 -0x19b877c(%rip),%xmm5{%k3}        # 5c7d40 <.LCPI3_25>
 1f804bc:	kmovd  %ecx,%k3
 1f804c0:	vpcmpgtd %zmm1,%zmm2,%k3{%k3}
 1f804c6:	vpsrld $0x10,%zmm12,%zmm1
 1f804cd:	vpternlogd $0xff,%zmm2,%zmm2,%zmm2
 1f804d4:	vpaddd %zmm2,%zmm1,%zmm2
 1f804da:	vmovdqu8 -0x19b8794(%rip),%xmm5{%k3}        # 5c7d50 <.LCPI3_26>
 1f804e4:	vptestnmd %zmm2,%zmm2,%k3
 1f804ea:	vpblendmb -0x19b8784(%rip),%xmm4,%xmm4{%k3}        # 5c7d70 <.LCPI3_28>
 1f804f4:	vpcmpnleud -0x19af567(%rip){1to16},%zmm2,%k3        # 5d0f98 <.LCPI3_22>
 1f804ff:	mov    0x8(%rsp),%r13
 1f80504:	cmpb   $0x0,0xb90(%r13)
 1f8050c:	vmovdqu8 -0x19b8796(%rip),%xmm4{%k3}        # 5c7d80 <.LCPI3_29>
 1f80516:	vpcmpnleud -0x19af585(%rip){1to16},%zmm2,%k3        # 5d0f9c <.LCPI3_23>
 1f80521:	vmovdqu8 -0x19b879b(%rip),%xmm4{%k3}        # 5c7d90 <.LCPI3_30>
 1f8052b:	vptestmd %zmm0,%zmm0,%k3
 1f80531:	vpor   %xmm7,%xmm3,%xmm0
 1f80535:	vmovdqu8 %xmm0,%xmm3{%k3}
 1f8053b:	vmovdqu8 %xmm4,%xmm5{%k2}
 1f80541:	vpor   %xmm5,%xmm3,%xmm0
 1f80545:	vpord  -0x19af593(%rip){1to4},%xmm0,%xmm3        # 5d0fbc <.LCPI3_82>
 1f8054f:	vmovdqu8 %xmm3,%xmm0{%k5}
 1f80555:	vpord  -0x19af59b(%rip){1to4},%xmm0,%xmm3        # 5d0fc4 <.LCPI3_86>
 1f8055f:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f80565:	vpsrld $0xc,%zmm12,%zmm3
 1f8056c:	vpmovdb %zmm3,%xmm3
 1f80572:	vpternlogd $0xf8,-0x19af5b5(%rip){1to4},%xmm3,%xmm11        # 5d0fc8 <.LCPI3_87>
 1f8057d:	je     1f80055 <node_facts_window_run+0x2c85>
 1f80583:	vmovdqa64 -0x1ac9d8d(%rip),%zmm5        # 4b6800 <abi_test_hex.digits+0xb480>
 1f8058d:	vptestmd %zmm1,%zmm1,%k1{%k2}
 1f80593:	add    %r9,%rbp
 1f80596:	vpxor  %xmm3,%xmm3,%xmm3
 1f8059a:	vpxor  %xmm4,%xmm4,%xmm4
 1f8059e:	vpcmpneqd -0x19af601(%rip){1to16},%zmm1,%k0{%k1}        # 5d0fa8 <.LCPI3_38>
 1f805a9:	vpor   %xmm0,%xmm11,%xmm1
 1f805ad:	kmovq  %k1,%k2
 1f805b2:	kmovw  %k1,%eax
 1f805b6:	popcnt %eax,%ecx
 1f805ba:	vpgatherdd 0x10(%rbp,%zmm5,1),%zmm3{%k2}
 1f805c2:	kmovq  %k1,%k2
 1f805c7:	vpcmpnleud -0x19af626(%rip){1to16},%zmm3,%k3        # 5d0fac <.LCPI3_39>
 1f805d2:	vpgatherdd 0x14(%rbp,%zmm5,1),%zmm4{%k2}
 1f805da:	add    %rcx,0x28(%rsp)
 1f805df:	mov    0x10(%rsp),%rbx
 1f805e4:	vpcmpeqd %zmm2,%zmm3,%k2
 1f805ea:	vptestnmd %zmm4,%zmm4,%k2{%k2}
 1f805f0:	vptestmd %zmm4,%zmm4,%k4
 1f805f6:	korw   %k4,%k3,%k3
 1f805fa:	kandw  %k2,%k0,%k2
 1f805fe:	knotw  %k0,%k0
 1f80602:	kandd  %k1,%k0,%k0
 1f80607:	kandw  %k0,%k3,%k0
 1f8060b:	korw   %k0,%k2,%k2
 1f8060f:	vptestnmd %zmm6,%zmm12,%k0{%k2}
 1f80615:	kandw  %k0,%k1,%k0
 1f80619:	kmovd  %k0,%ecx
 1f8061d:	vptestmb %xmm1,%xmm1,%k0
 1f80623:	andn   %eax,%ecx,%eax
 1f80628:	kmovd  %k0,%ecx
 1f8062c:	andn   %ecx,%edx,%ecx
 1f80631:	popcnt %eax,%eax
 1f80635:	movzwl %cx,%ecx
 1f80638:	add    %rax,%rbx
 1f8063b:	popcnt %ecx,%ecx
 1f8063f:	add    %rcx,%rbx
 1f80642:	mov    %rbx,0x10(%rsp)
 1f80647:	jmp    1f80055 <node_facts_window_run+0x2c85>
 1f8064c:	vmovdqu64 %zmm1,0x530(%rsp)
 1f80657:	vmovdqu64 %zmm15,0x630(%rsp)
 1f80662:	vmovdqu64 %zmm14,0x490(%rsp)
 1f8066d:	vmovdqu64 %zmm13,0x4d0(%rsp)
 1f80678:	vmovdqu64 %zmm2,0x2a0(%rsp)
 1f80683:	vmovdqu64 %zmm12,0x350(%rsp)
 1f8068e:	vmovdqu64 %zmm11,0x390(%rsp)
 1f80699:	vmovdqa %xmm3,0x160(%rsp)
 1f806a2:	vmovdqu64 %zmm5,0x2e0(%rsp)
 1f806ad:	kmovw  %k2,0x260(%rsp)
 1f806b6:	vmovdqu64 %zmm4,0x1a0(%rsp)
 1f806c1:	vmovdqa %xmm10,0x1e0(%rsp)
 1f806ca:	kmovw  %k3,0x570(%rsp)
 1f806d3:	mov    %r14,0x30(%rsp)
 1f806d8:	kandw  %k0,%k3,%k0
 1f806dc:	mov    0x48(%rsp),%r14
 1f806e1:	kmovd  %k0,%eax
 1f806e5:	movzwl %ax,%r13d
 1f806e9:	xor    %eax,%eax
 1f806eb:	tzcnt  %r13d,%eax
 1f806f0:	add    0x30(%rsp),%rax
 1f806f5:	mov    0x60(%r11),%edx
 1f806f9:	mov    0x20(%r11),%rcx
 1f806fd:	mov    (%r12,%rax,4),%edi
 1f80701:	mov    (%r15,%rax,4),%esi
 1f80705:	shl    $0x6,%rax
 1f80709:	mov    (%r9,%rax,1),%eax
 1f8070d:	mov    %rdi,0x60(%rsp)
 1f80712:	mov    0x8(%rsp),%rbx
 1f80717:	shr    $0x3,%eax
 1f8071a:	cmp    %edx,%eax
 1f8071c:	cmovae %edx,%eax
 1f8071f:	shl    $0x6,%rax
 1f80723:	mov    0x30(%rcx,%rax,1),%edx
 1f80727:	mov    0xb48(%rbx),%rax
 1f8072e:	cmpb   $0x1,(%rax,%rdi,1)
 1f80732:	mov    %rbx,%rdi
 1f80735:	adc    $0x0,%r14
 1f80739:	and    $0x1,%edx
 1f8073c:	vzeroupper
 1f8073f:	call   1f93890 <node_tests_window_line>
 1f80744:	mov    0x20(%rsp),%r9
 1f80749:	mov    (%rsp),%r11
 1f8074d:	mov    0xb48(%rbx),%rcx
 1f80754:	mov    0x60(%rsp),%rdx
 1f80759:	or     $0x1,%al
 1f8075b:	blsr   %r13d,%r13d
 1f80760:	mov    %al,(%rcx,%rdx,1)
 1f80763:	jne    1f806e9 <node_facts_window_run+0x3319>
 1f80765:	mov    %r14,0x48(%rsp)
 1f8076a:	vpbroadcastd -0x19af808(%rip),%zmm6        # 5d0f6c <.LCPI3_5>
 1f80774:	vpbroadcastb -0x1ac9a3b(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f8077d:	vpbroadcastd -0x19af813(%rip),%zmm8        # 5d0f74 <.LCPI3_11>
 1f80787:	vpbroadcastd -0x19af815(%rip),%zmm9        # 5d0f7c <.LCPI3_13>
 1f80791:	vpxor  %xmm0,%xmm0,%xmm0
 1f80795:	mov    0x8(%rsp),%rax
 1f8079a:	vmovdqu64 0x530(%rsp),%zmm1
 1f807a5:	kmovw  0x570(%rsp),%k1
 1f807ae:	vmovdqa 0x1e0(%rsp),%xmm10
 1f807b7:	vmovdqu64 0x1a0(%rsp),%zmm4
 1f807c2:	vmovdqu64 0x2e0(%rsp),%zmm5
 1f807cd:	vmovdqa 0x160(%rsp),%xmm3
 1f807d6:	vmovdqu64 0x390(%rsp),%zmm11
 1f807e1:	vmovdqu64 0x350(%rsp),%zmm12
 1f807ec:	vmovdqu64 0x2a0(%rsp),%zmm2
 1f807f7:	vmovdqu64 0x4d0(%rsp),%zmm13
 1f80802:	vmovdqu64 0x490(%rsp),%zmm14
 1f8080d:	vmovdqu64 0x630(%rsp),%zmm15
 1f80818:	mov    0x18(%rsp),%rsi
 1f8081d:	mov    0x40(%rsp),%rdi
 1f80822:	mov    0x38(%rsp),%r8
 1f80827:	mov    0x3d0(%rsp),%r10
 1f8082f:	mov    0x30(%rsp),%r14
 1f80834:	kmovw  0x260(%rsp),%k2
 1f8083d:	mov    0xb48(%rax),%rax
 1f80844:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f8084b:	jmp    1f80198 <node_facts_window_run+0x2dc8>
 1f80850:	movq   $0x0,0x48(%rsp)
 1f80859:	movq   $0x0,0x28(%rsp)
 1f80862:	movq   $0x0,0x10(%rsp)
 1f8086b:	mov    0x48(%rsp),%rax
 1f80870:	mov    0x28(%rsp),%rcx
 1f80875:	add    %rax,0xa90(%rdi)
 1f8087c:	mov    0xad0(%r13),%rax
 1f80883:	add    %rcx,0x868(%rax)
 1f8088a:	mov    0x10(%rsp),%rcx
 1f8088f:	mov    0xad0(%r13),%rax
 1f80896:	add    %rcx,0x870(%rax)
 1f8089d:	rdtsc
 1f8089f:	mov    0x8(%rsi),%r8d
 1f808a3:	cmpq   $0x0,0xc20(%r11)
 1f808ab:	mov    %rax,0x78(%rsp)
 1f808b0:	mov    %rdx,0x5f0(%rsp)
 1f808b8:	je     1f8105f <node_facts_window_run+0x3c8f>
 1f808be:	cmpb   $0x1,0xd58(%r11)
 1f808c6:	jne    1f8105f <node_facts_window_run+0x3c8f>
 1f808cc:	mov    0xad0(%r13),%rax
 1f808d3:	cmpq   $0x0,0x1a0(%rax)
 1f808db:	sete   %al
 1f808de:	test   %r8,%r8
 1f808e1:	je     1f8176d <node_facts_window_run+0x439d>
 1f808e7:	vpbroadcastb %eax,%zmm1
 1f808ed:	vgf2p8affineqb $0x0,-0x19b2360(%rip){1to8},%zmm1,%zmm1        # 5ce598 <.LCPI3_88>
 1f808f8:	vmovdqu64 0x288(%r13),%zmm0
 1f80902:	vbroadcasti32x4 -0x19b8afc(%rip),%zmm2        # 5c7e10 <.LCPI3_89>
 1f8090c:	vmovdqa64 -0x1aca056(%rip),%zmm7        # 4b68c0 <abi_test_hex.digits+0xb540>
 1f80916:	vbroadcasti32x4 -0x19b8b00(%rip),%zmm8        # 5c7e20 <.LCPI3_90>
 1f80920:	vbroadcasti32x4 -0x19b8afa(%rip),%zmm17        # 5c7e30 <.LCPI3_91>
 1f8092a:	vbroadcasti32x4 -0x19b8af4(%rip),%zmm18        # 5c7e40 <.LCPI3_92>
 1f80934:	vbroadcasti32x4 -0x19b8c3e(%rip),%zmm20        # 5c7d00 <.LCPI3_9>
 1f8093e:	vbroadcasti32x4 -0x19b8af8(%rip),%zmm27        # 5c7e50 <.LCPI3_93>
 1f80948:	vbroadcasti32x4 -0x19b8af2(%rip),%zmm28        # 5c7e60 <.LCPI3_94>
 1f80952:	vmovdqa64 -0x1ac9d1c(%rip),%zmm29        # 4b6c40 <abi_test_hex.digits+0xb8c0>
 1f8095c:	vmovdqa64 -0x1ac9ce6(%rip),%zmm30        # 4b6c80 <abi_test_hex.digits+0xb900>
 1f80966:	movzbl 0x4c8(%r13),%ecx
 1f8096e:	mov    0xd60(%r11),%rax
 1f80975:	mov    0xd78(%r11),%r10
 1f8097c:	xor    %r14d,%r14d
 1f8097f:	vpxord %xmm22,%xmm22,%xmm22
 1f80985:	vpxor  %xmm5,%xmm5,%xmm5
 1f80989:	vpxor  %xmm14,%xmm14,%xmm14
 1f8098e:	xor    %r9d,%r9d
 1f80991:	xor    %edx,%edx
 1f80993:	xor    %edi,%edi
 1f80995:	xor    %ebx,%ebx
 1f80997:	vpxor  %xmm4,%xmm4,%xmm4
 1f8099b:	vpxord %xmm25,%xmm25,%xmm25
 1f809a1:	neg    %rcx
 1f809a4:	mov    %rcx,0x1a0(%rsp)
 1f809ac:	mov    %rax,0x260(%rsp)
 1f809b4:	mov    %r10,0x2e0(%rsp)
 1f809bc:	xor    %ecx,%ecx
 1f809be:	movq   $0x0,0x160(%rsp)
 1f809ca:	nopw   0x0(%rax,%rax,1)
 1f809d0:	vmovdqu64 0x2c(%rsi,%r14,1),%zmm9
 1f809db:	vmovdqu64 0x88(%r13),%zmm3
 1f809e5:	mov    %rbx,0x38(%rsp)
 1f809ea:	mov    %rdi,0x20(%rsp)
 1f809ef:	mov    %rcx,0x10(%rsp)
 1f809f4:	vmovdqu64 0x188(%r13),%zmm16
 1f809fe:	vmovdqu64 0x208(%r13),%zmm19
 1f80a08:	vmovdqu64 0x348(%r13),%zmm26
 1f80a12:	vmovdqu64 0x3c8(%r13),%zmm10
 1f80a1c:	vmovdqa64 %zmm25,%zmm6
 1f80a22:	vmovdqa64 %zmm22,%zmm25
 1f80a28:	vmovdqu64 0x2c8(%r13),%zmm22
 1f80a32:	vmovdqa64 %zmm5,%zmm21
 1f80a38:	vmovdqu64 0x108(%r13),%zmm5
 1f80a42:	vpermt2b 0xc8(%r13),%zmm9,%zmm3
 1f80a4c:	vpermt2b 0x248(%r13),%zmm9,%zmm19
 1f80a56:	vpermt2b 0x148(%r13),%zmm9,%zmm5
 1f80a60:	vpandq %zmm2,%zmm9,%zmm15
 1f80a66:	vpermt2b 0x1c8(%r13),%zmm9,%zmm16
 1f80a70:	vpermt2b 0x308(%r13),%zmm9,%zmm22
 1f80a7a:	vpermt2b 0x388(%r13),%zmm9,%zmm26
 1f80a84:	vpermt2b 0x408(%r13),%zmm9,%zmm10
 1f80a8e:	vpmovb2m %zmm3,%k0
 1f80a94:	kmovq  %k0,%rax
 1f80a99:	mov    %rax,0x220(%rsp)
 1f80aa1:	mov    0xb10(%r13),%rax
 1f80aa8:	mov    0x2e0(%rsp),%rcx
 1f80ab0:	vmovdqu64 (%rax,%r14,1),%zmm9
 1f80ab7:	mov    0xb18(%r13),%rax
 1f80abe:	vmovdqu64 (%rax,%r14,1),%zmm31
 1f80ac5:	mov    0xb20(%r13),%rax
 1f80acc:	vpsrlw $0x2,%zmm9,%zmm11
 1f80ad3:	vpsrlw $0x3,%zmm9,%zmm12
 1f80ada:	vpternlogq $0xf8,-0x19b25a5(%rip){1to8},%zmm31,%zmm5        # 5ce540 <.LCPI3_42>
 1f80ae5:	vpternlogq $0xf8,-0x19b25a8(%rip){1to8},%zmm11,%zmm5        # 5ce548 <.LCPI3_43>
 1f80af0:	vpternlogq $0xf8,-0x19b25ab(%rip){1to8},%zmm12,%zmm5        # 5ce550 <.LCPI3_44>
 1f80afb:	vmovdqu64 %zmm5,(%rax,%r14,1)
 1f80b02:	vmovdqu64 0x6b554(%rsi,%r14,2),%zmm12
 1f80b0d:	vmovdqu64 0x6b594(%rsi,%r14,2),%zmm13
 1f80b18:	vmovdqu64 0x6d614(%rsi,%r14,2),%zmm23
 1f80b23:	vpmovuswb %zmm12,%ymm12
 1f80b29:	vpmovuswb %zmm13,%ymm13
 1f80b2f:	vpmovuswb %zmm23,%ymm23
 1f80b35:	vinserti64x4 $0x1,%ymm13,%zmm12,%zmm12
 1f80b3c:	vptestmb %zmm12,%zmm12,%k1
 1f80b42:	vpsubb %zmm12,%zmm7,%zmm13
 1f80b48:	vpcmpltub %zmm12,%zmm7,%k4{%k1}
 1f80b4f:	kmovq  %k1,%rax
 1f80b54:	vpcmpnltub %zmm12,%zmm7,%k1
 1f80b5b:	vmovdqu64 0x6d5d4(%rsi,%r14,2),%zmm12
 1f80b66:	kmovq  %k1,%rbp
 1f80b6b:	and    %rax,%rbp
 1f80b6e:	mov    0xb28(%r13),%rax
 1f80b75:	kmovq  %rbp,%k1
 1f80b7a:	vpermt2b %zmm22,%zmm13,%zmm25{%k1}{z}
 1f80b80:	knotq  %k1,%k6
 1f80b85:	vpmovuswb %zmm12,%ymm12
 1f80b8b:	vptestmb %zmm26,%zmm25,%k5
 1f80b91:	kmovq  %k5,%rbx
 1f80b96:	vinserti64x4 $0x1,%ymm23,%zmm12,%zmm23
 1f80b9d:	vmovdqa64 %zmm21,%zmm12
 1f80ba3:	vpermt2b %zmm5,%zmm13,%zmm12{%k1}{z}
 1f80ba9:	vptestmb %zmm23,%zmm23,%k2
 1f80baf:	vpsubb %zmm23,%zmm7,%zmm24
 1f80bb5:	vpcmpltub %zmm23,%zmm7,%k3{%k2}
 1f80bbc:	vpcmpnltub %zmm23,%zmm7,%k2{%k2}
 1f80bc3:	vpermt2b %zmm5,%zmm24,%zmm21{%k2}{z}
 1f80bc9:	vporq  %zmm12,%zmm21,%zmm23
 1f80bcf:	vmovdqu64 %zmm23,(%rax,%r14,1)
 1f80bd6:	mov    0x260(%rsp),%rax
 1f80bde:	vpandq (%rax,%r14,1),%zmm1,%zmm25
 1f80be5:	mov    %r14,%rax
 1f80be8:	shr    $0x3,%rax
 1f80bec:	kortestq %k4,%k3
 1f80bf1:	vpermt2b %zmm25,%zmm13,%zmm6
 1f80bf7:	vptestnmb %zmm6,%zmm6,%k5
 1f80bfd:	korq   %k5,%k6,%k5
 1f80c02:	vpcmpeqb %zmm8,%zmm15,%k5{%k5}
 1f80c08:	kmovq  %k5,(%rcx,%rax,1)
 1f80c0e:	jne    1f80f0a <node_facts_window_run+0x3b3a>
 1f80c14:	mov    %rbx,0x28(%rsp)
 1f80c19:	vpermi2b %zmm31,%zmm14,%zmm24{%k2}{z}
 1f80c1f:	vpermt2b %zmm31,%zmm13,%zmm14{%k1}{z}
 1f80c25:	vpternlogq $0xe0,%zmm2,%zmm31,%zmm19
 1f80c2c:	vpandq %zmm16,%zmm23,%zmm26
 1f80c32:	mov    %r9d,%r10d
 1f80c35:	vpsrlw $0x3,%zmm14,%zmm6
 1f80c3c:	vpternlogq $0xe4,-0x19b26bf(%rip){1to8},%zmm24,%zmm6        # 5ce588 <.LCPI3_53>
 1f80c47:	vpandq %zmm17,%zmm24,%zmm24
 1f80c4d:	vpcmpeqb %zmm18,%zmm24,%k4
 1f80c53:	vpermb %zmm0,%zmm6,%zmm6
 1f80c59:	vptestmb %zmm6,%zmm19,%k2
 1f80c5f:	vpandq %zmm17,%zmm14,%zmm19
 1f80c65:	vpandd -0x19afcb3(%rip){1to16},%zmm14,%zmm14        # 5d0fbc <.LCPI3_82>
 1f80c6f:	vpcmpeqb %zmm18,%zmm19,%k3
 1f80c75:	vpandd -0x19afcbb(%rip){1to16},%zmm9,%zmm19        # 5d0fc4 <.LCPI3_86>
 1f80c7f:	kmovq  %k2,%rax
 1f80c84:	vpcmpeqb -0x1aca34e(%rip),%zmm26,%k2        # 4b6940 <abi_test_hex.digits+0xb5c0>
 1f80c8e:	korq   %k4,%k3,%k3
 1f80c93:	vpcmpeqb -0x1aca29d(%rip),%zmm15,%k4{%k3}        # 4b6a00 <abi_test_hex.digits+0xb680>
 1f80c9d:	mov    %rax,0x1e0(%rsp)
 1f80ca5:	vpcmpeqb -0x1aca16f(%rip),%zmm15,%k3        # 4b6b40 <abi_test_hex.digits+0xb7c0>
 1f80caf:	vpternlogq $0xfe,%zmm14,%zmm26,%zmm19
 1f80cb6:	kmovq  %k2,%rax
 1f80cbb:	vpcmpeqb %zmm8,%zmm15,%k2
 1f80cc1:	vmovdqa64 %zmm31,%zmm14
 1f80cc7:	vptestnmb %zmm19,%zmm19,%k5
 1f80ccd:	kmovq  %k2,%r13
 1f80cd2:	vptestmb %zmm20,%zmm9,%k2
 1f80cd8:	knotq  %k4,%k4
 1f80cdd:	mov    %rax,0x60(%rsp)
 1f80ce2:	kmovq  %k2,%r15
 1f80ce7:	vptestmb %zmm26,%zmm26,%k2
 1f80ced:	kmovq  %k5,%r11
 1f80cf2:	vptestmb -0x1aca17c(%rip),%zmm9,%k5{%k2}        # 4b6b80 <abi_test_hex.digits+0xb800>
 1f80cfc:	kmovq  %k4,%rdi
 1f80d01:	vptestmb %zmm27,%zmm12,%k4
 1f80d07:	vpsllw $0x7,%zmm9,%zmm12
 1f80d0e:	vptestmb %zmm20,%zmm3,%k4{%k4}
 1f80d14:	korq   %k2,%k0,%k0
 1f80d19:	vptestmb %zmm27,%zmm21,%k4{%k4}
 1f80d1f:	kandq  %k5,%k3,%k5
 1f80d24:	kmovq  %k5,%rax
 1f80d29:	mov    %rax,0x30(%rsp)
 1f80d2e:	and    0x1a0(%rsp),%r13
 1f80d36:	vptestnmb %zmm28,%zmm26,%k4{%k4}
 1f80d3c:	mov    0x8(%rsp),%rcx
 1f80d41:	mov    0x220(%rsp),%rsi
 1f80d49:	and    0x1e0(%rsp),%rdi
 1f80d51:	and    %r15,%r13
 1f80d54:	kmovq  %k0,%r15
 1f80d59:	vptestmb %zmm10,%zmm23,%k0
 1f80d5f:	vpaddw %zmm9,%zmm9,%zmm10
 1f80d65:	vpandq -0x19b2817(%rip){1to8},%zmm10,%zmm10        # 5ce558 <.LCPI3_47>
 1f80d6f:	vpandq %zmm3,%zmm9,%zmm9
 1f80d75:	korq   %k5,%k4,%k5
 1f80d7a:	mov    0xb30(%rcx),%rbx
 1f80d81:	and    %r13,%r11
 1f80d84:	vpternlogq $0xf8,-0x19b282f(%rip){1to8},%zmm3,%zmm10        # 5ce560 <.LCPI3_48>
 1f80d8f:	vpaddw %zmm9,%zmm9,%zmm9
 1f80d95:	kmovq  %k0,%rax
 1f80d9a:	vptestmb -0x1aca2a4(%rip),%zmm3,%k0        # 4b6b00 <abi_test_hex.digits+0xb780>
 1f80da4:	or     0x28(%rsp),%rax
 1f80da9:	and    %rbp,%r11
 1f80dac:	vpternlogq $0xf8,-0x19b284f(%rip){1to8},%zmm11,%zmm10        # 5ce568 <.LCPI3_49>
 1f80db7:	kmovq  %k4,%rbp
 1f80dbc:	kmovq  %r11,%k4
 1f80dc1:	vpternlogq $0xf8,-0x19b285c(%rip){1to8},%zmm9,%zmm10        # 5ce570 <.LCPI3_50>
 1f80dcc:	vpsllw $0x3,%zmm31,%zmm9
 1f80dd3:	vpmovm2b %k4,%zmm6
 1f80dd9:	vpermt2b %zmm6,%zmm13,%zmm4
 1f80ddf:	vpternlogq $0xf8,-0x19b2872(%rip){1to8},%zmm9,%zmm10        # 5ce578 <.LCPI3_51>
 1f80dea:	vpsllw $0x4,%zmm31,%zmm9
 1f80df1:	vpmovb2m %zmm12,%k4
 1f80df7:	vpternlogq $0xf8,-0x19b2882(%rip){1to8},%zmm9,%zmm10        # 5ce580 <.LCPI3_52>
 1f80e02:	kandq  %k4,%k3,%k3
 1f80e07:	vptestmb %zmm4,%zmm4,%k1{%k1}
 1f80e0d:	vpbroadcastw %r14d,%zmm4
 1f80e13:	vporq  %zmm30,%zmm4,%zmm12
 1f80e19:	vporq  %zmm29,%zmm4,%zmm4
 1f80e1f:	vmovdqu64 %zmm10,(%rbx,%r14,1)
 1f80e26:	kandq  %k1,%k3,%k1
 1f80e2b:	mov    0xb40(%rcx),%rbx
 1f80e32:	vpcompressw %zmm4,%zmm4{%k1}{z}
 1f80e38:	kmovd  %k1,%r12d
 1f80e3c:	kshiftrq $0x20,%k1,%k3
 1f80e42:	popcnt %r12d,%r12d
 1f80e47:	vpcompressw %zmm12,%zmm12{%k3}{z}
 1f80e4d:	kmovd  %k3,%r13d
 1f80e51:	add    %r9d,%r12d
 1f80e54:	vmovdqu64 %zmm4,(%rbx,%r10,2)
 1f80e5b:	andn   0x60(%rsp),%rsi,%r10
 1f80e62:	mov    0x38(%rsp),%rbx
 1f80e67:	vmovdqa64 %zmm6,%zmm4
 1f80e6d:	mov    0xb40(%rcx),%r9
 1f80e74:	and    %r10,%rdi
 1f80e77:	vmovdqu64 %zmm12,(%r9,%r12,2)
 1f80e7e:	kmovq  %k5,%r9
 1f80e83:	mov    0xb38(%rcx),%r10
 1f80e8a:	or     %r11,%r9
 1f80e8d:	or     %rdi,%r9
 1f80e90:	andn   %r15,%r9,%rsi
 1f80e95:	mov    %rax,0x8(%r10,%r14,1)
 1f80e9a:	mov    %r9,(%r10,%r14,1)
 1f80e9e:	popcnt %r13d,%r9d
 1f80ea3:	mov    %rcx,%r13
 1f80ea6:	popcnt %rdi,%rcx
 1f80eab:	mov    %rsi,0x10(%r10,%r14,1)
 1f80eb0:	kmovq  %k0,0x18(%r10,%r14,1)
 1f80eb7:	korq   %k4,%k0,%k0
 1f80ebc:	popcnt %r11,%rsi
 1f80ec1:	mov    0x20(%rsp),%rdi
 1f80ec6:	add    %rcx,%rdx
 1f80ec9:	mov    0x10(%rsp),%rcx
 1f80ece:	kmovq  %k0,%rax
 1f80ed3:	add    %r12d,%r9d
 1f80ed6:	or     %r11,%rax
 1f80ed9:	mov    %rax,0x20(%r10,%r14,1)
 1f80ede:	popcnt 0x30(%rsp),%r10
 1f80ee5:	add    $0x40,%r14
 1f80ee9:	add    %rsi,%rcx
 1f80eec:	popcnt %rbp,%rsi
 1f80ef1:	add    %rsi,%rbx
 1f80ef4:	mov    0x18(%rsp),%rsi
 1f80ef9:	add    %r10,%rdi
 1f80efc:	cmp    %r8,%r14
 1f80eff:	jb     1f809d0 <node_facts_window_run+0x3600>
 1f80f05:	jmp    1f81784 <node_facts_window_run+0x43b4>
 1f80f0a:	kmovq  %k4,%rax
 1f80f0f:	mov    %rsi,%rcx
 1f80f12:	mov    %rax,%rdi
 1f80f15:	mov    %rax,0x30(%rsp)
 1f80f1a:	test   %rax,%rax
 1f80f1d:	je     1f80fe6 <node_facts_window_run+0x3c16>
 1f80f23:	xor    %eax,%eax
 1f80f25:	tzcnt  %rdi,%rax
 1f80f2a:	mov    %rcx,%rsi
 1f80f2d:	lea    (%rax,%r14,1),%r11
 1f80f31:	mov    %rax,0x28(%rsp)
 1f80f36:	mov    %r11d,%r15d
 1f80f39:	movzwl 0x6b554(%rcx,%r15,2),%r12d
 1f80f42:	mov    %r11d,%r10d
 1f80f45:	mov    0x8(%rsp),%rax
 1f80f4a:	sub    %r12d,%r10d
 1f80f4d:	mov    0xb20(%r13),%r12
 1f80f54:	mov    0xb28(%rax),%r13
 1f80f5b:	mov    0x8(%rsp),%rax
 1f80f60:	movzbl (%r12,%r10,1),%r12d
 1f80f65:	or     %r12b,0x0(%r13,%r15,1)
 1f80f6a:	movzbl 0x2c(%rcx,%r10,1),%r12d
 1f80f70:	movzbl 0x2c(%rcx,%r15,1),%r15d
 1f80f76:	mov    0x8(%rsp),%rcx
 1f80f7b:	and    $0x7f,%r12d
 1f80f7f:	and    $0x7f,%r15d
 1f80f83:	movzbl 0x2c8(%rax,%r12,1),%r13d
 1f80f8c:	xor    %eax,%eax
 1f80f8e:	test   %r13b,0x348(%rcx,%r15,1)
 1f80f96:	mov    %rsi,%rcx
 1f80f99:	mov    0x28(%rsp),%rsi
 1f80f9e:	mov    0x8(%rsp),%r13
 1f80fa3:	setne  %al
 1f80fa6:	shlx   %rsi,%rax,%rax
 1f80fab:	mov    0xb38(%r13),%rsi
 1f80fb2:	or     %rax,%rbx
 1f80fb5:	cmp    %r11d,%r8d
 1f80fb8:	seta   %al
 1f80fbb:	cmp    $0x22,%r12
 1f80fbf:	sete   %r11b
 1f80fc3:	and    %al,%r11b
 1f80fc6:	movzbl %r11b,%eax
 1f80fca:	shlx   %r10,%rax,%rax
 1f80fcf:	and    $0xffffffc0,%r10d
 1f80fd3:	not    %rax
 1f80fd6:	and    %rax,0x20(%rsi,%r10,1)
 1f80fdb:	blsr   %rdi,%rdi
 1f80fe0:	jne    1f80f23 <node_facts_window_run+0x3b53>
 1f80fe6:	kmovq  %k3,%rdi
 1f80feb:	mov    %rbx,0x28(%rsp)
 1f80ff0:	mov    %rdi,%r10
 1f80ff3:	test   %rdi,%rdi
 1f80ff6:	je     1f8102d <node_facts_window_run+0x3c5d>
 1f80ff8:	xor    %eax,%eax
 1f80ffa:	tzcnt  %r10,%rax
 1f80fff:	mov    0xb20(%r13),%rsi
 1f81006:	mov    0xb28(%r13),%r15
 1f8100d:	or     %r14,%rax
 1f81010:	mov    %eax,%r11d
 1f81013:	movzwl 0x6d5d4(%rcx,%r11,2),%ebx
 1f8101c:	sub    %ebx,%eax
 1f8101e:	movzbl (%rsi,%rax,1),%eax
 1f81022:	or     %al,(%r15,%r11,1)
 1f81026:	blsr   %r10,%r10
 1f8102b:	jne    1f80ff8 <node_facts_window_run+0x3c28>
 1f8102d:	mov    0xb28(%r13),%rcx
 1f81034:	popcnt 0x30(%rsp),%rax
 1f8103b:	popcnt %rdi,%rdi
 1f81040:	add    0x160(%rsp),%rax
 1f81048:	vmovdqu64 (%rcx,%r14,1),%zmm23
 1f8104f:	add    %rdi,%rax
 1f81052:	mov    %rax,0x160(%rsp)
 1f8105a:	jmp    1f80c19 <node_facts_window_run+0x3849>
 1f8105f:	test   %r8,%r8
 1f81062:	je     1f8176d <node_facts_window_run+0x439d>
 1f81068:	vmovdqu64 0x288(%r13),%zmm0
 1f81072:	vbroadcasti32x4 -0x19b926c(%rip),%zmm1        # 5c7e10 <.LCPI3_89>
 1f8107c:	vmovdqa64 -0x1aca7c6(%rip),%zmm6        # 4b68c0 <abi_test_hex.digits+0xb540>
 1f81086:	vbroadcasti32x4 -0x19b9260(%rip),%zmm15        # 5c7e30 <.LCPI3_91>
 1f81090:	vbroadcasti32x4 -0x19b925a(%rip),%zmm16        # 5c7e40 <.LCPI3_92>
 1f8109a:	vbroadcasti32x4 -0x19b93a4(%rip),%zmm19        # 5c7d00 <.LCPI3_9>
 1f810a4:	vbroadcasti32x4 -0x19b937e(%rip),%zmm23        # 5c7d30 <.LCPI3_24>
 1f810ae:	vbroadcasti32x4 -0x19b9248(%rip),%zmm24        # 5c7e70 <.LCPI3_95>
 1f810b8:	vbroadcasti32x4 -0x19b9242(%rip),%zmm25        # 5c7e80 <.LCPI3_96>
 1f810c2:	vbroadcasti32x4 -0x19b927c(%rip),%zmm26        # 5c7e50 <.LCPI3_93>
 1f810cc:	vbroadcasti32x4 -0x19b9276(%rip),%zmm27        # 5c7e60 <.LCPI3_94>
 1f810d6:	vmovdqa64 -0x1aca4a0(%rip),%zmm28        # 4b6c40 <abi_test_hex.digits+0xb8c0>
 1f810e0:	vmovdqa64 -0x1aca46a(%rip),%zmm29        # 4b6c80 <abi_test_hex.digits+0xb900>
 1f810ea:	movzbl 0x4c8(%r13),%eax
 1f810f2:	xor    %r9d,%r9d
 1f810f5:	vpxord %xmm21,%xmm21,%xmm21
 1f810fb:	vpxor  %xmm4,%xmm4,%xmm4
 1f810ff:	xor    %r11d,%r11d
 1f81102:	vpxor  %xmm11,%xmm11,%xmm11
 1f81107:	vpxor  %xmm2,%xmm2,%xmm2
 1f8110b:	xor    %edx,%edx
 1f8110d:	xor    %ecx,%ecx
 1f8110f:	xor    %edi,%edi
 1f81111:	xor    %ebx,%ebx
 1f81113:	neg    %rax
 1f81116:	mov    %rax,0x60(%rsp)
 1f8111b:	movq   $0x0,0x160(%rsp)
 1f81127:	mov    %r8,0x1e0(%rsp)
 1f8112f:	nop
 1f81130:	vmovdqu64 0x2c(%rsi,%r11,1),%zmm3
 1f8113b:	mov    %rbx,0x38(%rsp)
 1f81140:	mov    %rdi,0x20(%rsp)
 1f81145:	mov    %rcx,0x10(%rsp)
 1f8114a:	mov    0xb18(%r13),%rcx
 1f81151:	mov    0xb10(%r13),%rdi
 1f81158:	vmovdqu64 0x88(%r13),%zmm31
 1f81162:	vmovdqu64 0x188(%r13),%zmm12
 1f8116c:	vmovdqu64 0x208(%r13),%zmm13
 1f81176:	vmovdqu64 0x348(%r13),%zmm22
 1f81180:	vmovdqu64 0x3c8(%r13),%zmm5
 1f8118a:	vmovdqa64 %zmm21,%zmm20
 1f81190:	vmovdqu64 0x2c8(%r13),%zmm21
 1f8119a:	vmovdqa64 %zmm4,%zmm14
 1f811a0:	vmovdqu64 0x108(%r13),%zmm4
 1f811aa:	vmovdqu64 (%rcx,%r11,1),%zmm30
 1f811b1:	vpermt2b 0x148(%r13),%zmm3,%zmm4
 1f811bb:	vpermt2b 0xc8(%r13),%zmm3,%zmm31
 1f811c5:	vpandq %zmm1,%zmm3,%zmm10
 1f811cb:	vpermt2b 0x248(%r13),%zmm3,%zmm13
 1f811d5:	vpermt2b 0x1c8(%r13),%zmm3,%zmm12
 1f811df:	vpermt2b 0x308(%r13),%zmm3,%zmm21
 1f811e9:	vpermt2b 0x388(%r13),%zmm3,%zmm22
 1f811f3:	vpermt2b 0x408(%r13),%zmm3,%zmm5
 1f811fd:	vmovdqu64 (%rdi,%r11,1),%zmm3
 1f81204:	vpternlogq $0xf8,-0x19b2ccf(%rip){1to8},%zmm30,%zmm4        # 5ce540 <.LCPI3_42>
 1f8120f:	vpsrlw $0x2,%zmm3,%zmm7
 1f81216:	vpsrlw $0x3,%zmm3,%zmm8
 1f8121d:	vpmovb2m %zmm31,%k0
 1f81223:	vpternlogq $0xf8,-0x19b2ce6(%rip){1to8},%zmm7,%zmm4        # 5ce548 <.LCPI3_43>
 1f8122e:	kmovq  %k0,%rax
 1f81233:	vpternlogq $0xf8,-0x19b2cee(%rip){1to8},%zmm8,%zmm4        # 5ce550 <.LCPI3_44>
 1f8123e:	mov    %rax,0x28(%rsp)
 1f81243:	mov    0xb20(%r13),%rax
 1f8124a:	mov    %rdx,0x220(%rsp)
 1f81252:	vmovdqu64 %zmm4,(%rax,%r11,1)
 1f81259:	vmovdqu64 0x6b554(%rsi,%r11,2),%zmm8
 1f81264:	vmovdqu64 0x6b594(%rsi,%r11,2),%zmm9
 1f8126f:	vmovdqu64 0x6d614(%rsi,%r11,2),%zmm17
 1f8127a:	vpmovuswb %zmm8,%ymm8
 1f81280:	vpmovuswb %zmm9,%ymm9
 1f81286:	vpmovuswb %zmm17,%ymm17
 1f8128c:	vinserti64x4 $0x1,%ymm9,%zmm8,%zmm8
 1f81293:	vptestmb %zmm8,%zmm8,%k1
 1f81299:	vpsubb %zmm8,%zmm6,%zmm9
 1f8129f:	vpcmpltub %zmm8,%zmm6,%k4{%k1}
 1f812a6:	kmovq  %k1,%rax
 1f812ab:	vpcmpnltub %zmm8,%zmm6,%k1
 1f812b2:	vmovdqu64 0x6d5d4(%rsi,%r11,2),%zmm8
 1f812bd:	kmovq  %k1,%r15
 1f812c2:	and    %rax,%r15
 1f812c5:	mov    0xb28(%r13),%rax
 1f812cc:	kmovq  %r15,%k1
 1f812d1:	vpermt2b %zmm21,%zmm9,%zmm20{%k1}{z}
 1f812d7:	vpmovuswb %zmm8,%ymm8
 1f812dd:	vptestmb %zmm22,%zmm20,%k5
 1f812e3:	kmovq  %k5,%rcx
 1f812e8:	vinserti64x4 $0x1,%ymm17,%zmm8,%zmm17
 1f812ef:	vmovdqa64 %zmm14,%zmm8
 1f812f5:	vpermt2b %zmm4,%zmm9,%zmm8{%k1}{z}
 1f812fb:	vptestmb %zmm17,%zmm17,%k2
 1f81301:	vpsubb %zmm17,%zmm6,%zmm18
 1f81307:	vpcmpltub %zmm17,%zmm6,%k3{%k2}
 1f8130e:	vpcmpnltub %zmm17,%zmm6,%k2{%k2}
 1f81315:	vpermt2b %zmm4,%zmm18,%zmm14{%k2}{z}
 1f8131b:	kortestq %k4,%k3
 1f81320:	vporq  %zmm8,%zmm14,%zmm17
 1f81326:	vmovdqu64 %zmm17,(%rax,%r11,1)
 1f8132d:	jne    1f8160d <node_facts_window_run+0x423d>
 1f81333:	mov    %rcx,0x30(%rsp)
 1f81338:	vpermi2b %zmm30,%zmm11,%zmm18{%k2}{z}
 1f8133e:	vpermt2b %zmm30,%zmm9,%zmm11{%k1}{z}
 1f81344:	vpternlogq $0xe0,%zmm1,%zmm30,%zmm13
 1f8134b:	vpandq %zmm12,%zmm17,%zmm12
 1f81351:	vptestmb %zmm26,%zmm8,%k6
 1f81357:	mov    %r9d,%esi
 1f8135a:	vpsrlw $0x3,%zmm11,%zmm20
 1f81361:	vpternlogq $0xe4,-0x19b2de4(%rip){1to8},%zmm18,%zmm20        # 5ce588 <.LCPI3_53>
 1f8136c:	vpermb %zmm0,%zmm20,%zmm20
 1f81372:	vptestmb %zmm20,%zmm13,%k2
 1f81378:	vpandq %zmm15,%zmm11,%zmm13
 1f8137e:	vpandd -0x19b03cc(%rip){1to16},%zmm11,%zmm11        # 5d0fbc <.LCPI3_82>
 1f81388:	kmovq  %k2,%rax
 1f8138d:	vpcmpeqb -0x1acaa57(%rip),%zmm12,%k2        # 4b6940 <abi_test_hex.digits+0xb5c0>
 1f81397:	vpcmpeqb %zmm16,%zmm13,%k3
 1f8139d:	vpandq %zmm15,%zmm18,%zmm13
 1f813a3:	vpcmpeqb %zmm16,%zmm13,%k4
 1f813a9:	vpandd -0x19b03ef(%rip){1to16},%zmm3,%zmm13        # 5d0fc4 <.LCPI3_86>
 1f813b3:	kmovq  %k2,%r10
 1f813b8:	korq   %k4,%k3,%k2
 1f813bd:	vpcmpeqb -0x1aca9c7(%rip),%zmm10,%k2{%k2}        # 4b6a00 <abi_test_hex.digits+0xb680>
 1f813c7:	vpcmpeqb -0x1acaad1(%rip),%zmm10,%k4        # 4b6900 <abi_test_hex.digits+0xb580>
 1f813d1:	vpcmpeqb %zmm24,%zmm10,%k3
 1f813d7:	vpsllw $0x7,%zmm3,%zmm10
 1f813de:	vpternlogq $0xfe,%zmm11,%zmm12,%zmm13
 1f813e5:	vmovdqa64 %zmm30,%zmm11
 1f813eb:	vptestnmb %zmm13,%zmm13,%k5
 1f813f1:	kmovq  %k5,%r12
 1f813f6:	knotq  %k2,%k2
 1f813fb:	kmovq  %k4,%r13
 1f81400:	and    0x60(%rsp),%r13
 1f81405:	kmovq  %k2,%rdi
 1f8140a:	vptestmb %zmm19,%zmm3,%k2
 1f81410:	kmovq  %k2,%rbx
 1f81415:	vptestmb %zmm12,%zmm12,%k2
 1f8141b:	and    %rax,%rdi
 1f8141e:	vptestmb %zmm25,%zmm3,%k4{%k2}
 1f81424:	korq   %k2,%k0,%k0
 1f81429:	and    %rbx,%r13
 1f8142c:	kmovq  %k0,%rbx
 1f81431:	vptestmb %zmm5,%zmm17,%k0
 1f81437:	vpaddw %zmm3,%zmm3,%zmm5
 1f8143d:	vpandq -0x19b2eef(%rip){1to8},%zmm5,%zmm5        # 5ce558 <.LCPI3_47>
 1f81447:	vpandq %zmm31,%zmm3,%zmm3
 1f8144d:	and    %r13,%r12
 1f81450:	vpternlogq $0xf8,-0x19b2efb(%rip){1to8},%zmm31,%zmm5        # 5ce560 <.LCPI3_48>
 1f8145b:	vpaddw %zmm3,%zmm3,%zmm3
 1f81461:	mov    0x8(%rsp),%r13
 1f81466:	kmovq  %k0,%rcx
 1f8146b:	or     0x30(%rsp),%rcx
 1f81470:	vptestmb %zmm23,%zmm31,%k0
 1f81476:	and    %r15,%r12
 1f81479:	vpternlogq $0xf8,-0x19b2f1c(%rip){1to8},%zmm7,%zmm5        # 5ce568 <.LCPI3_49>
 1f81484:	kandq  %k4,%k3,%k5
 1f81489:	vptestmb %zmm19,%zmm31,%k4{%k6}
 1f8148f:	vpternlogq $0xf8,-0x19b2f2a(%rip){1to8},%zmm3,%zmm5        # 5ce570 <.LCPI3_50>
 1f8149a:	vpsllw $0x3,%zmm30,%zmm3
 1f814a1:	kmovq  %k5,%rbp
 1f814a6:	vpternlogq $0xf8,-0x19b2f39(%rip){1to8},%zmm3,%zmm5        # 5ce578 <.LCPI3_51>
 1f814b1:	vpsllw $0x4,%zmm30,%zmm3
 1f814b8:	vpternlogq $0xf8,-0x19b2f43(%rip){1to8},%zmm3,%zmm5        # 5ce580 <.LCPI3_52>
 1f814c3:	mov    0xb30(%r13),%rdx
 1f814ca:	vptestmb %zmm26,%zmm14,%k4{%k4}
 1f814d0:	vptestnmb %zmm27,%zmm12,%k4{%k4}
 1f814d6:	vmovdqu64 %zmm5,(%rdx,%r11,1)
 1f814dd:	mov    0xb40(%r13),%rdx
 1f814e4:	korq   %k5,%k4,%k5
 1f814e9:	kmovq  %k4,%r15
 1f814ee:	kmovq  %r12,%k4
 1f814f3:	vpmovm2b %k4,%zmm8
 1f814f9:	vpermt2b %zmm8,%zmm9,%zmm2
 1f814ff:	vpmovb2m %zmm10,%k4
 1f81505:	kandq  %k4,%k3,%k3
 1f8150a:	vptestmb %zmm2,%zmm2,%k1{%k1}
 1f81510:	vpbroadcastw %r11d,%zmm2
 1f81516:	vporq  %zmm29,%zmm2,%zmm9
 1f8151c:	vporq  %zmm28,%zmm2,%zmm2
 1f81522:	kandq  %k1,%k3,%k1
 1f81527:	vpcompressw %zmm2,%zmm2{%k1}{z}
 1f8152d:	kshiftrq $0x20,%k1,%k3
 1f81533:	kmovd  %k1,%r14d
 1f81537:	vpcompressw %zmm9,%zmm9{%k3}{z}
 1f8153d:	popcnt %r14d,%r14d
 1f81542:	kmovd  %k3,%r8d
 1f81546:	add    %r9d,%r14d
 1f81549:	popcnt %r8d,%r9d
 1f8154e:	popcnt %rbp,%r8
 1f81553:	add    %r14d,%r9d
 1f81556:	vmovdqu64 %zmm2,(%rdx,%rsi,2)
 1f8155d:	mov    0x28(%rsp),%rsi
 1f81562:	vmovdqa64 %zmm8,%zmm2
 1f81568:	mov    0xb40(%r13),%rdx
 1f8156f:	andn   %r10,%rsi,%rsi
 1f81574:	vmovdqu64 %zmm9,(%rdx,%r14,2)
 1f8157b:	kmovq  %k5,%rdx
 1f81580:	and    %rsi,%rdi
 1f81583:	popcnt %r15,%rsi
 1f81588:	mov    0xb38(%r13),%rax
 1f8158f:	or     %r12,%rdx
 1f81592:	or     %rdi,%rdx
 1f81595:	mov    %rcx,0x8(%rax,%r11,1)
 1f8159a:	andn   %rbx,%rdx,%rcx
 1f8159f:	mov    %rdx,(%rax,%r11,1)
 1f815a3:	mov    0x38(%rsp),%rbx
 1f815a8:	mov    0x220(%rsp),%rdx
 1f815b0:	mov    %rcx,0x10(%rax,%r11,1)
 1f815b5:	kmovq  %k0,0x18(%rax,%r11,1)
 1f815bc:	korq   %k4,%k0,%k0
 1f815c1:	kmovq  %k0,%rcx
 1f815c6:	or     %r12,%rcx
 1f815c9:	mov    %rcx,0x20(%rax,%r11,1)
 1f815ce:	popcnt %rdi,%rax
 1f815d3:	mov    0x20(%rsp),%rdi
 1f815d8:	mov    0x10(%rsp),%rcx
 1f815dd:	add    $0x40,%r11
 1f815e1:	add    %rsi,%rbx
 1f815e4:	mov    0x18(%rsp),%rsi
 1f815e9:	add    %rax,%rdx
 1f815ec:	popcnt %r12,%rax
 1f815f1:	add    %r8,%rdi
 1f815f4:	mov    0x1e0(%rsp),%r8
 1f815fc:	add    %rax,%rcx
 1f815ff:	cmp    %r8,%r11
 1f81602:	jb     1f81130 <node_facts_window_run+0x3d60>
 1f81608:	jmp    1f81784 <node_facts_window_run+0x43b4>
 1f8160d:	kmovq  %k4,%rax
 1f81612:	mov    %rax,%rdi
 1f81615:	mov    %rax,0x1a0(%rsp)
 1f8161d:	test   %rax,%rax
 1f81620:	je     1f816f2 <node_facts_window_run+0x4322>
 1f81626:	xor    %eax,%eax
 1f81628:	tzcnt  %rdi,%rax
 1f8162d:	mov    %rsi,%rbx
 1f81630:	mov    %rax,0x30(%rsp)
 1f81635:	lea    (%rax,%r11,1),%r14
 1f81639:	mov    0x8(%rsp),%rax
 1f8163e:	mov    %r14d,%r12d
 1f81641:	movzwl 0x6b554(%rsi,%r12,2),%ebp
 1f8164a:	mov    %r14d,%r10d
 1f8164d:	mov    0xb20(%rax),%r13
 1f81654:	mov    0x8(%rsp),%rax
 1f81659:	sub    %ebp,%r10d
 1f8165c:	mov    0xb28(%rax),%rbp
 1f81663:	movzbl 0x0(%r13,%r10,1),%r13d
 1f81669:	mov    0x8(%rsp),%rax
 1f8166e:	or     %r13b,0x0(%rbp,%r12,1)
 1f81673:	movzbl 0x2c(%rsi,%r10,1),%r13d
 1f81679:	movzbl 0x2c(%rsi,%r12,1),%r12d
 1f8167f:	mov    %rcx,%rsi
 1f81682:	mov    0x8(%rsp),%rcx
 1f81687:	and    $0x7f,%r13d
 1f8168b:	and    $0x7f,%r12d
 1f8168f:	movzbl 0x2c8(%rax,%r13,1),%ebp
 1f81698:	xor    %eax,%eax
 1f8169a:	test   %bpl,0x348(%rcx,%r12,1)
 1f816a2:	mov    %rsi,%rcx
 1f816a5:	mov    %rbx,%rsi
 1f816a8:	mov    0x30(%rsp),%rbx
 1f816ad:	setne  %al
 1f816b0:	shlx   %rbx,%rax,%rax
 1f816b5:	or     %rax,%rcx
 1f816b8:	cmp    %r14d,%r8d
 1f816bb:	seta   %al
 1f816be:	cmp    $0x22,%r13
 1f816c2:	mov    0x8(%rsp),%r13
 1f816c7:	sete   %bl
 1f816ca:	and    %al,%bl
 1f816cc:	movzbl %bl,%eax
 1f816cf:	shlx   %r10,%rax,%rax
 1f816d4:	and    $0xffffffc0,%r10d
 1f816d8:	mov    0xb38(%r13),%rbx
 1f816df:	not    %rax
 1f816e2:	and    %rax,0x20(%rbx,%r10,1)
 1f816e7:	blsr   %rdi,%rdi
 1f816ec:	jne    1f81626 <node_facts_window_run+0x4256>
 1f816f2:	kmovq  %k3,%rdi
 1f816f7:	mov    %rdi,%r10
 1f816fa:	test   %rdi,%rdi
 1f816fd:	je     1f81733 <node_facts_window_run+0x4363>
 1f816ff:	xor    %eax,%eax
 1f81701:	tzcnt  %r10,%rax
 1f81706:	mov    0xb20(%r13),%r14
 1f8170d:	mov    0xb28(%r13),%r12
 1f81714:	or     %r11,%rax
 1f81717:	mov    %eax,%ebx
 1f81719:	movzwl 0x6d5d4(%rsi,%rbx,2),%ebp
 1f81721:	sub    %ebp,%eax
 1f81723:	movzbl (%r14,%rax,1),%eax
 1f81728:	or     %al,(%r12,%rbx,1)
 1f8172c:	blsr   %r10,%r10
 1f81731:	jne    1f816ff <node_facts_window_run+0x432f>
 1f81733:	mov    %rcx,0x30(%rsp)
 1f81738:	mov    0xb28(%r13),%rcx
 1f8173f:	popcnt %rdi,%rdi
 1f81744:	popcnt 0x1a0(%rsp),%rax
 1f8174e:	add    0x160(%rsp),%rax
 1f81756:	vmovdqu64 (%rcx,%r11,1),%zmm17
 1f8175d:	add    %rdi,%rax
 1f81760:	mov    %rax,0x160(%rsp)
 1f81768:	jmp    1f81338 <node_facts_window_run+0x3f68>
 1f8176d:	movq   $0x0,0x160(%rsp)
 1f81779:	xor    %edx,%edx
 1f8177b:	xor    %ecx,%ecx
 1f8177d:	xor    %edi,%edi
 1f8177f:	xor    %ebx,%ebx
 1f81781:	xor    %r9d,%r9d
 1f81784:	mov    0x40(%rsp),%r8
 1f81789:	mov    0x160(%rsp),%rax
 1f81791:	movq   $0x0,0x2a0(%rsp)
 1f8179d:	add    %rax,0xa88(%r8)
 1f817a4:	add    %rdx,0x7e8(%r8)
 1f817ab:	add    %rcx,0x800(%r8)
 1f817b2:	add    %rdi,0x838(%r8)
 1f817b9:	add    %rbx,0x850(%r8)
 1f817c0:	test   %r9d,%r9d
 1f817c3:	je     1f81896 <node_facts_window_run+0x44c6>
 1f817c9:	mov    %r9d,%r14d
 1f817cc:	mov    0x50(%rsp),%r9
 1f817d1:	mov    $0x8,%ebp
 1f817d6:	xor    %r12d,%r12d
 1f817d9:	xor    %r13d,%r13d
 1f817dc:	xor    %r15d,%r15d
 1f817df:	nop
 1f817e0:	mov    0x8(%rsp),%rcx
 1f817e5:	mov    0xb40(%rcx),%rax
 1f817ec:	mov    0xb48(%rcx),%rcx
 1f817f3:	movzwl (%rax,%r13,2),%ebx
 1f817f8:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f81800:	sub    %eax,%ebx
 1f81802:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f8180a:	mov    %ebx,%edx
 1f8180c:	sub    %eax,%edx
 1f8180e:	cmpb   $0x2,0x69454(%rsi,%rdx,1)
 1f81816:	mov    0x757d4(%rsi,%rdx,4),%eax
 1f8181d:	cmovne %r12,%rax
 1f81821:	movzbl (%rcx,%rax,1),%eax
 1f81825:	cmovne %ebp,%eax
 1f81828:	test   $0x8,%al
 1f8182a:	je     1f8183d <node_facts_window_run+0x446d>
 1f8182c:	movzbl %al,%eax
 1f8182f:	test   $0x10,%al
 1f81831:	jne    1f81863 <node_facts_window_run+0x4493>
 1f81833:	inc    %r13
 1f81836:	cmp    %r13,%r14
 1f81839:	jne    1f817e0 <node_facts_window_run+0x4410>
 1f8183b:	jmp    1f8188f <node_facts_window_run+0x44bf>
 1f8183d:	mov    0x8(%rsp),%rdi
 1f81842:	vzeroupper
 1f81845:	call   1f93b60 <node_tests_window_wants>
 1f8184a:	mov    0x50(%rsp),%r9
 1f8184f:	mov    0x40(%rsp),%r8
 1f81854:	mov    0x18(%rsp),%rsi
 1f81859:	movzbl %al,%eax
 1f8185c:	inc    %r15
 1f8185f:	test   $0x10,%al
 1f81861:	je     1f81833 <node_facts_window_run+0x4463>
 1f81863:	mov    0x8(%rsp),%rdx
 1f81868:	mov    %ebx,%ecx
 1f8186a:	mov    $0xfffffffffffffffe,%rax
 1f81871:	and    $0xffffffc0,%ebx
 1f81874:	rol    %cl,%rax
 1f81877:	mov    0xb38(%rdx),%rcx
 1f8187e:	and    %rax,0x20(%rcx,%rbx,1)
 1f81883:	inc    %r13
 1f81886:	cmp    %r13,%r14
 1f81889:	jne    1f817e0 <node_facts_window_run+0x4410>
 1f8188f:	mov    0x8(%rsp),%r13
 1f81894:	jmp    1f818a1 <node_facts_window_run+0x44d1>
 1f81896:	mov    0x50(%rsp),%r9
 1f8189b:	xor    %r14d,%r14d
 1f8189e:	xor    %r15d,%r15d
 1f818a1:	add    %r15,0x828(%r8)
 1f818a8:	rdtsc
 1f818aa:	add    %r14,0x820(%r8)
 1f818b1:	mov    %rax,0x100(%rsp)
 1f818b9:	mov    %rdx,0x5b0(%rsp)
 1f818c1:	mov    (%rsp),%rax
 1f818c5:	mov    0x80(%rsp),%r12
 1f818cd:	cmpl   $0x0,0xa90(%rax)
 1f818d4:	je     1f8270d <node_facts_window_run+0x533d>
 1f818da:	movzbl 0x70(%rsp),%eax
 1f818df:	lea    0x42ec(%rsi),%rdx
 1f818e6:	mov    $0xffffffffffffffff,%r14
 1f818ed:	xor    %ebp,%ebp
 1f818ef:	mov    %eax,0x720(%rsp)
 1f818f6:	movzbl 0x40(%r13),%eax
 1f818fb:	shl    $0x1b,%rax
 1f818ff:	mov    %rax,0x98(%rsp)
 1f81907:	mov    0xa0(%rsp),%rax
 1f8190f:	mov    (%rax),%rax
 1f81912:	mov    0x6c8(%rax),%ecx
 1f81918:	mov    0x6e8(%rax),%eax
 1f8191e:	mov    %ecx,0x48(%rsp)
 1f81922:	mov    %eax,0x120(%rsp)
 1f81929:	movzbl 0x3a(%r13),%eax
 1f8192e:	lea    0x422c(%rsi),%rcx
 1f81935:	mov    %eax,0x88(%rsp)
 1f8193c:	movzbl 0x3c(%r13),%eax
 1f81941:	mov    %eax,0x90(%rsp)
 1f81948:	mov    0xa8(%rsp),%eax
 1f8194f:	mov    %rdx,0xb0(%rsp)
 1f81957:	mov    %rcx,0x670(%rsp)
 1f8195f:	movl   $0x0,0x260(%rsp)
 1f8196a:	movq   $0x0,0x2a0(%rsp)
 1f81976:	vpbroadcastd %eax,%zmm3
 1f8197c:	jmp    1f8199a <node_facts_window_run+0x45ca>
 1f8197e:	xchg   %ax,%ax
 1f81980:	movb   $0x0,0x61(%rdx)
 1f81984:	mov    (%rsp),%rax
 1f81988:	inc    %rbp
 1f8198b:	mov    0xa90(%rax),%eax
 1f81991:	cmp    %rax,%rbp
 1f81994:	jae    1f8270d <node_facts_window_run+0x533d>
 1f8199a:	mov    (%rsp),%rax
 1f8199e:	imul   $0x68,%rbp,%rdx
 1f819a2:	add    %r9,%rdx
 1f819a5:	mov    0xa88(%rax),%rax
 1f819ac:	cmpb   $0x0,(%rax,%rbp,1)
 1f819b0:	je     1f81980 <node_facts_window_run+0x45b0>
 1f819b2:	mov    (%rsp),%rax
 1f819b6:	mov    0xa50(%rax),%rax
 1f819bd:	mov    (%rax,%rbp,4),%eax
 1f819c0:	cmp    0x20(%r8),%eax
 1f819c4:	jae    1f81980 <node_facts_window_run+0x45b0>
 1f819c6:	mov    0x18(%r8),%rcx
 1f819ca:	movzbl (%rcx,%rax,1),%eax
 1f819ce:	shr    $0x5,%al
 1f819d1:	and    $0x1,%al
 1f819d3:	mov    %al,0x61(%rdx)
 1f819d6:	je     1f81984 <node_facts_window_run+0x45b4>
 1f819d8:	mov    %rdx,0x490(%rsp)
 1f819e0:	mov    0xb30(%r13),%rcx
 1f819e7:	mov    $0x40,%r15d
 1f819ed:	mov    (%rsp),%rax
 1f819f1:	mov    0xa70(%rax),%rax
 1f819f8:	mov    (%rax,%rbp,4),%eax
 1f819fb:	mov    0x651b8(%rsi,%rax,4),%ebx
 1f81a02:	mov    %eax,%r9d
 1f81a05:	mov    %rax,0x2e0(%rsp)
 1f81a0d:	sub    %ebx,%r9d
 1f81a10:	inc    %r9d
 1f81a13:	mov    %r9d,%r11d
 1f81a16:	test   %rbx,%rbx
 1f81a19:	je     1f81a3e <node_facts_window_run+0x466e>
 1f81a1b:	lea    -0x1(%rbx),%rdx
 1f81a1f:	shr    $0x6,%rdx
 1f81a23:	inc    %rdx
 1f81a26:	mov    %edx,%eax
 1f81a28:	and    $0x7,%eax
 1f81a2b:	cmp    $0x1c1,%ebx
 1f81a31:	jae    1f81a45 <node_facts_window_run+0x4675>
 1f81a33:	vpxor  %xmm0,%xmm0,%xmm0
 1f81a37:	xor    %esi,%esi
 1f81a39:	jmp    1f81b9a <node_facts_window_run+0x47ca>
 1f81a3e:	xor    %eax,%eax
 1f81a40:	jmp    1f81c03 <node_facts_window_run+0x4833>
 1f81a45:	lea    0x1c0(%rcx,%r11,1),%rdi
 1f81a4d:	and    $0xfffffffffffffff8,%rdx
 1f81a51:	mov    %r9,0x28(%rsp)
 1f81a56:	vpxor  %xmm0,%xmm0,%xmm0
 1f81a5a:	xor    %esi,%esi
 1f81a5c:	nopl   0x0(%rax)
 1f81a60:	lea    (%rbx,%rsi,1),%r9
 1f81a64:	mov    %r9d,%r8d
 1f81a67:	sub    $0x40,%r9
 1f81a6b:	shlx   %r8,%r14,%r8
 1f81a70:	not    %r8
 1f81a73:	mov    %r8,%r10
 1f81a76:	cmovae %r14,%r10
 1f81a7a:	cmp    $0x40,%r9
 1f81a7e:	shlx   %r9,%r14,%r9
 1f81a83:	not    %r9
 1f81a86:	kmovq  %r10,%k1
 1f81a8b:	cmovae %r14,%r9
 1f81a8f:	vmovdqu8 -0x1c0(%rdi),%zmm1{%k1}{z}
 1f81a96:	kmovq  %r9,%k1
 1f81a9b:	lea    -0x80(%rbx,%rsi,1),%r9
 1f81aa0:	vmovdqu8 -0x180(%rdi),%zmm2{%k1}{z}
 1f81aa7:	cmp    $0x40,%r9
 1f81aab:	mov    %r8,%r9
 1f81aae:	cmovae %r14,%r9
 1f81ab2:	kmovq  %r9,%k1
 1f81ab7:	lea    -0xc0(%rbx,%rsi,1),%r9
 1f81abf:	cmp    $0x40,%r9
 1f81ac3:	mov    %r8,%r9
 1f81ac6:	cmovae %r14,%r9
 1f81aca:	vpternlogq $0xfe,%zmm1,%zmm0,%zmm2
 1f81ad1:	vmovdqu8 -0x140(%rdi),%zmm0{%k1}{z}
 1f81ad8:	kmovq  %r9,%k1
 1f81add:	lea    -0x100(%rbx,%rsi,1),%r9
 1f81ae5:	vmovdqu8 -0x100(%rdi),%zmm1{%k1}{z}
 1f81aec:	cmp    $0x40,%r9
 1f81af0:	mov    %r8,%r9
 1f81af3:	cmovae %r14,%r9
 1f81af7:	kmovq  %r9,%k1
 1f81afc:	lea    -0x140(%rbx,%rsi,1),%r9
 1f81b04:	cmp    $0x40,%r9
 1f81b08:	mov    %r8,%r9
 1f81b0b:	cmovae %r14,%r9
 1f81b0f:	vpternlogq $0xfe,%zmm0,%zmm2,%zmm1
 1f81b16:	vmovdqu8 -0xc0(%rdi),%zmm0{%k1}{z}
 1f81b1d:	kmovq  %r9,%k1
 1f81b22:	lea    -0x180(%rbx,%rsi,1),%r9
 1f81b2a:	vmovdqu8 -0x80(%rdi),%zmm2{%k1}{z}
 1f81b31:	cmp    $0x40,%r9
 1f81b35:	mov    %r8,%r9
 1f81b38:	cmovae %r14,%r9
 1f81b3c:	kmovq  %r9,%k1
 1f81b41:	lea    -0x1c0(%rbx,%rsi,1),%r9
 1f81b49:	vmovdqu8 -0x40(%rdi),%zmm4{%k1}{z}
 1f81b50:	cmp    $0x40,%r9
 1f81b54:	cmovae %r14,%r8
 1f81b58:	add    $0xfffffffffffffe00,%rsi
 1f81b5f:	kmovq  %r8,%k1
 1f81b64:	vpternlogq $0xfe,%zmm0,%zmm1,%zmm2
 1f81b6b:	vmovdqu8 (%rdi),%zmm0{%k1}{z}
 1f81b71:	add    $0x200,%rdi
 1f81b78:	add    $0xfffffffffffffff8,%rdx
 1f81b7c:	vpternlogq $0xfe,%zmm4,%zmm2,%zmm0
 1f81b83:	jne    1f81a60 <node_facts_window_run+0x4690>
 1f81b89:	test   %rax,%rax
 1f81b8c:	je     1f8264a <node_facts_window_run+0x527a>
 1f81b92:	mov    0x28(%rsp),%r9
 1f81b97:	neg    %rsi
 1f81b9a:	lea    (%rcx,%rsi,1),%rdx
 1f81b9e:	mov    %rbx,%rdi
 1f81ba1:	sub    %rsi,%rdi
 1f81ba4:	shl    $0x6,%eax
 1f81ba7:	xor    %esi,%esi
 1f81ba9:	add    %r11,%rdx
 1f81bac:	nopl   0x0(%rax)
 1f81bb0:	mov    %edi,%r8d
 1f81bb3:	sub    $0x40,%rdi
 1f81bb7:	shlx   %r8,%r14,%r8
 1f81bbc:	not    %r8
 1f81bbf:	cmovae %r14,%r8
 1f81bc3:	kmovq  %r8,%k1
 1f81bc8:	vmovdqu8 (%rdx,%rsi,1),%zmm1{%k1}{z}
 1f81bcf:	add    $0x40,%rsi
 1f81bd3:	vporq  %zmm1,%zmm0,%zmm0
 1f81bd9:	cmp    %rsi,%rax
 1f81bdc:	jne    1f81bb0 <node_facts_window_run+0x47e0>
 1f81bde:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f81be5:	vporq  %zmm1,%zmm0,%zmm0
 1f81beb:	vextracti128 $0x1,%ymm0,%xmm1
 1f81bf1:	vpor   %xmm1,%xmm0,%xmm0
 1f81bf5:	vpshufd $0xee,%xmm0,%xmm1
 1f81bfa:	vpor   %xmm1,%xmm0,%xmm0
 1f81bfe:	vmovq  %xmm0,%rax
 1f81c03:	mov    (%rsp),%rsi
 1f81c07:	mov    0xa58(%rsi),%rdx
 1f81c0e:	mov    0xa68(%rsi),%rsi
 1f81c15:	mov    (%rdx,%rbp,4),%edi
 1f81c18:	mov    %rax,%rdx
 1f81c1b:	shr    $0x20,%rdx
 1f81c1f:	mov    (%rsi,%rbp,4),%r8d
 1f81c23:	or     %rax,%rdx
 1f81c26:	mov    %rdx,%rsi
 1f81c29:	shr    $0x10,%rsi
 1f81c2d:	or     %edx,%esi
 1f81c2f:	mov    %esi,%eax
 1f81c31:	shr    $0x8,%eax
 1f81c34:	or     %esi,%eax
 1f81c36:	mov    %edi,0x390(%rsp)
 1f81c3d:	cmp    %ebx,%edi
 1f81c3f:	jbe    1f81c45 <node_facts_window_run+0x4875>
 1f81c41:	or     (%rcx,%r8,1),%al
 1f81c45:	movzbl %al,%esi
 1f81c48:	lea    0x0(,%rsi,8),%edx
 1f81c4f:	lea    0x0(,%rsi,4),%ecx
 1f81c56:	mov    %edx,%eax
 1f81c58:	mov    %ecx,0x350(%rsp)
 1f81c5f:	and    $0x8,%eax
 1f81c62:	and    $0x10,%ecx
 1f81c65:	and    $0x40,%edx
 1f81c68:	or     %eax,%ecx
 1f81c6a:	mov    %esi,%eax
 1f81c6c:	and    $0x10,%eax
 1f81c6f:	lea    (%rcx,%rax,2),%eax
 1f81c72:	or     %eax,%edx
 1f81c74:	mov    %esi,%eax
 1f81c76:	and    $0x2,%eax
 1f81c79:	mov    %rdx,0x60(%rsp)
 1f81c7e:	mov    %rsi,0x630(%rsp)
 1f81c86:	mov    %eax,0x570(%rsp)
 1f81c8d:	je     1f81ca3 <node_facts_window_run+0x48d3>
 1f81c8f:	cmpb   $0x1,0x26(%r13)
 1f81c94:	jne    1f81ca3 <node_facts_window_run+0x48d3>
 1f81c96:	movzbl 0x54(%r13),%eax
 1f81c9b:	shl    $0x11,%eax
 1f81c9e:	add    %rax,0x60(%rsp)
 1f81ca3:	mov    %r8,0x530(%rsp)
 1f81cab:	mov    %rbp,0x4d0(%rsp)
 1f81cb3:	mov    0xb70(%r13),%rcx
 1f81cba:	mov    0xb78(%r13),%rax
 1f81cc1:	mov    %ebx,%edi
 1f81cc3:	shr    $0x6,%edi
 1f81cc6:	mov    0x260(%rsp),%esi
 1f81ccd:	lea    (%rcx,%rsi,8),%rdx
 1f81cd1:	mov    %rdx,0x450(%rsp)
 1f81cd9:	lea    (%rax,%rsi,8),%rdx
 1f81cdd:	mov    %rdx,0x3d0(%rsp)
 1f81ce5:	mov    %r9d,%edx
 1f81ce8:	and    $0x3f,%r9d
 1f81cec:	mov    %rdi,0x410(%rsp)
 1f81cf4:	shr    $0x6,%edx
 1f81cf7:	inc    %rdi
 1f81cfa:	mov    %r11,0x1a0(%rsp)
 1f81d02:	mov    %rbx,0x10(%rsp)
 1f81d07:	mov    %r9d,%r10d
 1f81d0a:	xor    $0x3f,%r10d
 1f81d0e:	mov    %rdi,0x160(%rsp)
 1f81d16:	mov    %rdx,0x6b0(%rsp)
 1f81d1e:	cmp    $0x40,%ebx
 1f81d21:	jae    1f81d36 <node_facts_window_run+0x4966>
 1f81d23:	mov    $0xffffffff,%r14d
 1f81d29:	xor    %r8d,%r8d
 1f81d2c:	xor    %ebp,%ebp
 1f81d2e:	xor    %r12d,%r12d
 1f81d31:	jmp    1f81f9a <node_facts_window_run+0x4bca>
 1f81d36:	shr    $1,%edi
 1f81d38:	lea    0x8(%rcx,%rsi,8),%rcx
 1f81d3d:	lea    0x8(%rax,%rsi,8),%rax
 1f81d42:	shl    $0x6,%edx
 1f81d45:	mov    $0xffffffff,%r14d
 1f81d4b:	xor    %r8d,%r8d
 1f81d4e:	xor    %ebp,%ebp
 1f81d50:	shl    $0x7,%rdi
 1f81d54:	mov    %rcx,0x30(%rsp)
 1f81d59:	mov    %rdx,0x20(%rsp)
 1f81d5e:	mov    %rax,0x38(%rsp)
 1f81d63:	mov    %rdi,0x1e0(%rsp)
 1f81d6b:	mov    %r9,0x28(%rsp)
 1f81d70:	xor    %r9d,%r9d
 1f81d73:	mov    %ebx,%eax
 1f81d75:	xor    %edi,%edi
 1f81d77:	nopw   0x0(%rax,%rax,1)
 1f81d80:	mov    %eax,0x220(%rsp)
 1f81d87:	mov    %eax,%r13d
 1f81d8a:	sub    $0x40,%r13d
 1f81d8e:	mov    $0x40,%ecx
 1f81d93:	mov    0x8(%rsp),%r11
 1f81d98:	cmovb  %eax,%ecx
 1f81d9b:	cmp    0x10(%rsp),%r9
 1f81da0:	mov    0x20(%rsp),%rsi
 1f81da5:	mov    0x28(%rsp),%r12
 1f81daa:	mov    $0x0,%eax
 1f81daf:	mov    0x30(%rsp),%rdx
 1f81db4:	mov    0xb38(%r11),%r15
 1f81dbb:	cmovae %eax,%ecx
 1f81dbe:	mov    $0xffffffffffffffff,%rax
 1f81dc5:	add    %rsi,%r15
 1f81dc8:	cmp    $0x40,%ecx
 1f81dcb:	shlx   %rcx,%rax,%rcx
 1f81dd0:	mov    0x58(%r9,%r15,1),%rbx
 1f81dd5:	not    %rcx
 1f81dd8:	cmove  %rax,%rcx
 1f81ddc:	shrx   %r12,0x18(%r9,%r15,1),%rax
 1f81de3:	add    %rbx,%rbx
 1f81de6:	shlx   %r10,%rbx,%rbx
 1f81deb:	or     %rax,%rbx
 1f81dee:	mov    0x48(%r9,%r15,1),%rax
 1f81df3:	shrx   %r12,0x8(%r9,%r15,1),%r15
 1f81dfa:	and    %rcx,%rbx
 1f81dfd:	add    %rax,%rax
 1f81e00:	shlx   %r10,%rax,%rax
 1f81e05:	or     %r15,%rax
 1f81e08:	and    %rcx,%rax
 1f81e0b:	mov    %rax,-0x8(%rdx,%r8,8)
 1f81e10:	mov    0xb38(%r11),%rax
 1f81e17:	add    %rsi,%rax
 1f81e1a:	mov    0x8(%rsp),%rsi
 1f81e1f:	shrx   %r12,0x10(%r9,%rax,1),%r11
 1f81e26:	mov    0x50(%r9,%rax,1),%rax
 1f81e2b:	add    %rax,%rax
 1f81e2e:	shlx   %r10,%rax,%r15
 1f81e33:	mov    0x38(%rsp),%rax
 1f81e38:	or     %r11,%r15
 1f81e3b:	mov    %r9d,%r11d
 1f81e3e:	and    %rcx,%r15
 1f81e41:	mov    %edi,%ecx
 1f81e43:	mov    $0x40,%edi
 1f81e48:	mov    %r15,-0x8(%rax,%r8,8)
 1f81e4d:	popcnt %rbx,%rax
 1f81e52:	add    %eax,%ecx
 1f81e54:	lzcnt  %rbx,%rax
 1f81e59:	sub    %eax,%r11d
 1f81e5c:	lea    0x40(%r9),%rax
 1f81e60:	add    $0x3f,%r11d
 1f81e64:	test   %rbx,%rbx
 1f81e67:	mov    %r14d,%ebx
 1f81e6a:	cmovne %r11d,%ebx
 1f81e6e:	or     -0x8(%rdx,%r8,8),%rbp
 1f81e73:	cmp    $0x40,%r13d
 1f81e77:	mov    $0xffffffffffffffff,%r11
 1f81e7e:	cmovae %edi,%r13d
 1f81e82:	cmp    0x10(%rsp),%rax
 1f81e87:	mov    $0x0,%eax
 1f81e8c:	mov    0x20(%rsp),%rdi
 1f81e91:	cmovae %eax,%r13d
 1f81e95:	mov    0xb38(%rsi),%rax
 1f81e9c:	shlx   %r13,%r11,%r14
 1f81ea1:	not    %r14
 1f81ea4:	add    %rdi,%rax
 1f81ea7:	cmp    $0x40,%r13d
 1f81eab:	mov    0x98(%r9,%rax,1),%r13
 1f81eb3:	cmove  %r11,%r14
 1f81eb7:	shrx   %r12,0x58(%r9,%rax,1),%r11
 1f81ebe:	add    %r13,%r13
 1f81ec1:	shlx   %r10,%r13,%r13
 1f81ec6:	or     %r11,%r13
 1f81ec9:	mov    0x88(%r9,%rax,1),%r11
 1f81ed1:	shrx   %r12,0x48(%r9,%rax,1),%rax
 1f81ed8:	and    %r14,%r13
 1f81edb:	add    %r11,%r11
 1f81ede:	shlx   %r10,%r11,%r11
 1f81ee3:	or     %rax,%r11
 1f81ee6:	and    %r14,%r11
 1f81ee9:	mov    %r11,(%rdx,%r8,8)
 1f81eed:	mov    0xb38(%rsi),%rax
 1f81ef4:	mov    0x38(%rsp),%rsi
 1f81ef9:	add    %rdi,%rax
 1f81efc:	popcnt %r13,%rdi
 1f81f01:	shrx   %r12,0x50(%r9,%rax,1),%r11
 1f81f08:	mov    0x90(%r9,%rax,1),%rax
 1f81f10:	add    %ecx,%edi
 1f81f12:	lzcnt  %r13,%rcx
 1f81f17:	add    %rax,%rax
 1f81f1a:	shlx   %r10,%rax,%rax
 1f81f1f:	or     %r11,%rax
 1f81f22:	and    %r14,%rax
 1f81f25:	mov    %r9d,%r14d
 1f81f28:	sub    %ecx,%r14d
 1f81f2b:	add    $0x7f,%r14d
 1f81f2f:	test   %r13,%r13
 1f81f32:	mov    %rax,(%rsi,%r8,8)
 1f81f36:	cmove  %ebx,%r14d
 1f81f3a:	or     (%rdx,%r8,8),%rbp
 1f81f3e:	add    $0x2,%r8
 1f81f42:	sub    $0xffffffffffffff80,%r9
 1f81f46:	or     %r15,%rbp
 1f81f49:	or     %rax,%rbp
 1f81f4c:	mov    0x220(%rsp),%eax
 1f81f53:	add    $0xffffff80,%eax
 1f81f56:	cmp    %r9,0x1e0(%rsp)
 1f81f5e:	jne    1f81d80 <node_facts_window_run+0x49b0>
 1f81f64:	mov    0x410(%rsp),%rax
 1f81f6c:	mov    0x8(%rsp),%r13
 1f81f71:	mov    0x1a0(%rsp),%r11
 1f81f79:	mov    0x28(%rsp),%r9
 1f81f7e:	mov    0x10(%rsp),%rbx
 1f81f83:	mov    $0x40,%r15d
 1f81f89:	mov    %rbp,%r12
 1f81f8c:	mov    %rdi,%rbp
 1f81f8f:	inc    %rax
 1f81f92:	test   $0x1,%al
 1f81f94:	je     1f82080 <node_facts_window_run+0x4cb0>
 1f81f9a:	mov    0x6b0(%rsp),%r11
 1f81fa2:	mov    %r8,%rax
 1f81fa5:	shl    $0x6,%rax
 1f81fa9:	mov    %ebx,%ecx
 1f81fab:	mov    0xb38(%r13),%rsi
 1f81fb2:	mov    $0x0,%edx
 1f81fb7:	sub    %eax,%ecx
 1f81fb9:	cmp    $0x40,%ecx
 1f81fbc:	cmovae %r15d,%ecx
 1f81fc0:	cmp    %rbx,%rax
 1f81fc3:	cmovae %edx,%ecx
 1f81fc6:	mov    $0xffffffffffffffff,%rdx
 1f81fcd:	add    %r8,%r11
 1f81fd0:	shl    $0x6,%r11
 1f81fd4:	cmp    $0x40,%ecx
 1f81fd7:	shlx   %rcx,%rdx,%rcx
 1f81fdc:	mov    0x58(%rsi,%r11,1),%r15
 1f81fe1:	not    %rcx
 1f81fe4:	shrx   %r9,0x18(%rsi,%r11,1),%rdi
 1f81feb:	cmove  %rdx,%rcx
 1f81fef:	add    %r15,%r15
 1f81ff2:	shlx   %r10,%r15,%rdx
 1f81ff7:	mov    0x48(%rsi,%r11,1),%r15
 1f81ffc:	shrx   %r9,0x8(%rsi,%r11,1),%rsi
 1f82003:	or     %rdi,%rdx
 1f82006:	and    %rcx,%rdx
 1f82009:	add    %r15,%r15
 1f8200c:	shlx   %r10,%r15,%rdi
 1f82011:	mov    0x450(%rsp),%r15
 1f82019:	or     %rsi,%rdi
 1f8201c:	and    %rcx,%rdi
 1f8201f:	mov    %rdi,(%r15,%r8,8)
 1f82023:	mov    0xb38(%r13),%rsi
 1f8202a:	shrx   %r9,0x10(%rsi,%r11,1),%rdi
 1f82031:	mov    0x50(%rsi,%r11,1),%rsi
 1f82036:	mov    %ebp,%r9d
 1f82039:	popcnt %rdx,%rbp
 1f8203e:	mov    0x1a0(%rsp),%r11
 1f82046:	add    %r9d,%ebp
 1f82049:	add    %rsi,%rsi
 1f8204c:	shlx   %r10,%rsi,%rsi
 1f82051:	mov    %r14d,%r10d
 1f82054:	lea    0x3f(%rax),%r14d
 1f82058:	or     %rdi,%rsi
 1f8205b:	and    %rcx,%rsi
 1f8205e:	lzcnt  %rdx,%rcx
 1f82063:	sub    %ecx,%r14d
 1f82066:	mov    0x3d0(%rsp),%rcx
 1f8206e:	test   %rdx,%rdx
 1f82071:	cmove  %r10d,%r14d
 1f82075:	mov    %rsi,(%rcx,%r8,8)
 1f82079:	or     (%r15,%r8,8),%r12
 1f8207d:	or     %rsi,%r12
 1f82080:	test   %ebx,%ebx
 1f82082:	je     1f820b6 <node_facts_window_run+0x4ce6>
 1f82084:	lea    -0x1(%rbx),%rax
 1f82088:	mov    $0xffffffff,%r15d
 1f8208e:	shr    $0x4,%rax
 1f82092:	inc    %rax
 1f82095:	mov    %eax,%edx
 1f82097:	and    $0x3,%edx
 1f8209a:	cmp    $0x31,%ebx
 1f8209d:	jae    1f820c7 <node_facts_window_run+0x4cf7>
 1f8209f:	mov    0x18(%rsp),%rsi
 1f820a4:	vpxor  %xmm0,%xmm0,%xmm0
 1f820a8:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f820af:	xor    %ecx,%ecx
 1f820b1:	jmp    1f82207 <node_facts_window_run+0x4e37>
 1f820b6:	mov    0x18(%rsp),%rsi
 1f820bb:	xor    %edx,%edx
 1f820bd:	mov    $0xffffffff,%ecx
 1f820c2:	jmp    1f822c7 <node_facts_window_run+0x4ef7>
 1f820c7:	mov    0xb0(%rsp),%rcx
 1f820cf:	and    $0xfffffffffffffffc,%rax
 1f820d3:	mov    %rbx,%rdi
 1f820d6:	lea    -0x20(%rbx),%r8d
 1f820da:	lea    -0x10(%rbx),%r9d
 1f820de:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f820e5:	vpxor  %xmm0,%xmm0,%xmm0
 1f820e9:	lea    (%rcx,%r11,4),%rsi
 1f820ed:	lea    -0x30(%rbx),%ecx
 1f820f0:	mov    $0xffff,%ebx
 1f820f5:	mov    %rcx,0x20(%rsp)
 1f820fa:	xor    %ecx,%ecx
 1f820fc:	nopl   0x0(%rax)
 1f82100:	lea    (%rdi,%rcx,1),%r10
 1f82104:	shlx   %r10d,%r15d,%r11d
 1f82109:	sub    $0x10,%r10
 1f8210d:	not    %r11d
 1f82110:	cmovae %ebx,%r11d
 1f82114:	cmp    $0x10,%r10
 1f82118:	kmovd  %r11d,%k1
 1f8211d:	lea    (%r9,%rcx,1),%r11d
 1f82121:	vmovdqu32 -0xc0(%rsi),%zmm2{%k1}{z}
 1f82128:	shlx   %r11d,%r15d,%r10d
 1f8212d:	lea    (%r8,%rcx,1),%r11d
 1f82131:	not    %r10d
 1f82134:	cmovae %ebx,%r10d
 1f82138:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f8213f:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f82145:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f8214b:	kmovd  %r10d,%k1
 1f82150:	lea    -0x20(%rdi,%rcx,1),%r10
 1f82155:	vmovdqu32 -0x80(%rsi),%zmm2{%k1}{z}
 1f8215c:	cmp    $0x10,%r10
 1f82160:	shlx   %r11d,%r15d,%r10d
 1f82165:	mov    0x20(%rsp),%r11
 1f8216a:	not    %r10d
 1f8216d:	cmovae %ebx,%r10d
 1f82171:	add    %ecx,%r11d
 1f82174:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f8217b:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f82181:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82187:	kmovd  %r10d,%k1
 1f8218c:	lea    -0x30(%rdi,%rcx,1),%r10
 1f82191:	vmovdqu32 -0x40(%rsi),%zmm2{%k1}{z}
 1f82198:	cmp    $0x10,%r10
 1f8219c:	shlx   %r11d,%r15d,%r10d
 1f821a1:	not    %r10d
 1f821a4:	cmovae %ebx,%r10d
 1f821a8:	add    $0xffffffffffffffc0,%rcx
 1f821ac:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f821b3:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f821b9:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f821bf:	kmovd  %r10d,%k1
 1f821c4:	vmovdqu32 (%rsi),%zmm2{%k1}{z}
 1f821ca:	add    $0x100,%rsi
 1f821d1:	add    $0xfffffffffffffffc,%rax
 1f821d5:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f821dc:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f821e2:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f821e8:	jne    1f82100 <node_facts_window_run+0x4d30>
 1f821ee:	test   %rdx,%rdx
 1f821f1:	je     1f82654 <node_facts_window_run+0x5284>
 1f821f7:	mov    0x18(%rsp),%rsi
 1f821fc:	mov    0x1a0(%rsp),%r11
 1f82204:	neg    %rcx
 1f82207:	mov    $0xffff,%r9d
 1f8220d:	lea    0x0(,%r11,4),%rax
 1f82215:	mov    0x10(%rsp),%r8
 1f8221a:	shl    $0x4,%edx
 1f8221d:	lea    (%rax,%rcx,4),%rax
 1f82221:	add    0x670(%rsp),%rax
 1f82229:	sub    %rcx,%r8
 1f8222c:	xor    %ecx,%ecx
 1f8222e:	xchg   %ax,%ax
 1f82230:	mov    %r8d,%edi
 1f82233:	sub    $0x10,%r8
 1f82237:	shlx   %edi,%r15d,%edi
 1f8223c:	not    %edi
 1f8223e:	cmovae %r9d,%edi
 1f82242:	kmovd  %edi,%k1
 1f82246:	vmovdqu32 (%rax,%rcx,4),%zmm2{%k1}{z}
 1f8224d:	add    $0x10,%rcx
 1f82251:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82258:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f8225e:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82264:	cmp    %rcx,%rdx
 1f82267:	jne    1f82230 <node_facts_window_run+0x4e60>
 1f82269:	vextracti64x4 $0x1,%zmm1,%ymm2
 1f82270:	vpminud %ymm2,%ymm1,%ymm1
 1f82275:	vextracti128 $0x1,%ymm1,%xmm2
 1f8227b:	vpminud %xmm2,%xmm1,%xmm1
 1f82280:	vpshufd $0xee,%xmm1,%xmm2
 1f82285:	vpminud %xmm2,%xmm1,%xmm1
 1f8228a:	vpshufd $0x55,%xmm1,%xmm2
 1f8228f:	vpminud %xmm2,%xmm1,%xmm1
 1f82294:	vmovd  %xmm1,%ecx
 1f82298:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f8229f:	vpmaxud %ymm1,%ymm0,%ymm0
 1f822a4:	vextracti128 $0x1,%ymm0,%xmm1
 1f822aa:	vpmaxud %xmm1,%xmm0,%xmm0
 1f822af:	vpshufd $0xee,%xmm0,%xmm1
 1f822b4:	vpmaxud %xmm1,%xmm0,%xmm0
 1f822b9:	vpshufd $0x55,%xmm0,%xmm1
 1f822be:	vpmaxud %xmm1,%xmm0,%xmm0
 1f822c3:	vmovd  %xmm0,%edx
 1f822c7:	mov    0x350(%rsp),%eax
 1f822ce:	and    $0x100,%eax
 1f822d3:	mov    0x530(%rsp),%r8
 1f822db:	or     %rax,0x60(%rsp)
 1f822e0:	mov    0x390(%rsp),%eax
 1f822e7:	cmp    0x10(%rsp),%eax
 1f822eb:	mov    %r8d,%eax
 1f822ee:	cmovbe 0x2e0(%rsp),%eax
 1f822f6:	mov    0x422c(%rsi,%rax,4),%edi
 1f822fd:	mov    %rdi,0x20(%rsp)
 1f82302:	mov    0x490(%rsp),%r15
 1f8230a:	ja     1f82313 <node_facts_window_run+0x4f43>
 1f8230c:	xor    %r9d,%r9d
 1f8230f:	xor    %edi,%edi
 1f82311:	jmp    1f82336 <node_facts_window_run+0x4f66>
 1f82313:	mov    0xb38(%r13),%rdi
 1f8231a:	mov    %r8,%rbx
 1f8231d:	and    $0xffffffc0,%r8d
 1f82321:	shrx   %rbx,0x8(%rdi,%r8,1),%r9
 1f82328:	shrx   %rbx,0x10(%rdi,%r8,1),%rdi
 1f8232f:	and    $0x1,%r9d
 1f82333:	and    $0x1,%edi
 1f82336:	mov    0x410(%rsp),%r11
 1f8233e:	mov    0x10(%rsp),%rbx
 1f82343:	mov    0x450(%rsp),%r10
 1f8234b:	or     %r9,%r12
 1f8234e:	or     %rdi,%r12
 1f82351:	shlx   %rbx,%r9,%r8
 1f82356:	shl    $0x3,%r11d
 1f8235a:	or     %r8,(%r10,%r11,1)
 1f8235e:	shlx   %rbx,%rdi,%r8
 1f82363:	mov    0x3d0(%rsp),%rbx
 1f8236b:	mov    %edx,%edi
 1f8236d:	or     %r8,(%rbx,%r11,1)
 1f82371:	mov    0x20(%rsp),%r8
 1f82376:	mov    %ecx,%r11d
 1f82379:	cmp    %ecx,%r8d
 1f8237c:	cmovb  %r8d,%r11d
 1f82380:	cmp    %edx,%r8d
 1f82383:	cmova  %r8d,%edi
 1f82387:	cmp    0xa8(%rsp),%r8d
 1f8238f:	cmovae %ecx,%r11d
 1f82393:	mov    0x60(%rsp),%rcx
 1f82398:	cmovae %edx,%edi
 1f8239b:	mov    0x1a0(%rsp),%rdx
 1f823a3:	mov    %rcx,(%r15)
 1f823a6:	mov    0x160(%rsp),%rcx
 1f823ae:	mov    %r10,0x8(%r15)
 1f823b2:	mov    %rbx,0x10(%r15)
 1f823b6:	mov    %edi,0x38(%rsp)
 1f823ba:	mov    0x50(%rsp),%r9
 1f823bf:	mov    %ecx,0x18(%r15)
 1f823c3:	mov    0xb10(%r13),%rcx
 1f823ca:	add    %rdx,%rcx
 1f823cd:	mov    %rcx,0x20(%r15)
 1f823d1:	mov    0xb20(%r13),%rcx
 1f823d8:	add    %rdx,%rcx
 1f823db:	mov    %rcx,0x28(%r15)
 1f823df:	mov    0x570(%rsp),%ecx
 1f823e6:	add    0xb28(%r13),%rdx
 1f823ed:	mov    %rdx,0x30(%r15)
 1f823f1:	mov    0x350(%rsp),%edx
 1f823f8:	mov    %r11d,0x38(%r15)
 1f823fc:	mov    %edi,0x3c(%r15)
 1f82400:	mov    %ebp,0x40(%r15)
 1f82404:	mov    %r14d,0x44(%r15)
 1f82408:	mov    %ecx,0x48(%r15)
 1f8240c:	and    $0x80,%edx
 1f82412:	cmpl   $0x0,0x48(%rsp)
 1f82417:	mov    %edx,0x4c(%r15)
 1f8241b:	je     1f8245a <node_facts_window_run+0x508a>
 1f8241d:	cmp    0xa8(%rsp),%r8d
 1f82425:	mov    $0x0,%edx
 1f8242a:	mov    %r8d,%ecx
 1f8242d:	cmovae %edx,%ecx
 1f82430:	jae    1f8245a <node_facts_window_run+0x508a>
 1f82432:	mov    0xb08(%r13),%rdx
 1f82439:	mov    %ecx,%edi
 1f8243b:	mov    $0x1,%r8d
 1f82441:	shr    $0x6,%ecx
 1f82444:	mov    $0x6,%r10d
 1f8244a:	shlx   %rdi,%r8,%rdi
 1f8244f:	mov    0x20(%rsp),%r8
 1f82454:	and    (%rdx,%rcx,8),%rdi
 1f82458:	jne    1f82480 <node_facts_window_run+0x50b0>
 1f8245a:	mov    0xc0(%rsp),%rcx
 1f82462:	movzbl (%rcx,%rax,1),%eax
 1f82466:	and    $0x7f,%eax
 1f82469:	cmpl   $0x0,0x120(%rsp)
 1f82471:	movzbl 0x448(%r13,%rax,1),%r10d
 1f8247a:	jne    1f826aa <node_facts_window_run+0x52da>
 1f82480:	mov    0x10(%rsp),%rdi
 1f82485:	mov    0x2e0(%rsp),%r8
 1f8248d:	mov    0xb38(%r13),%rdx
 1f82494:	mov    0x630(%rsp),%rbx
 1f8249c:	cmp    %edi,0x390(%rsp)
 1f824a3:	mov    %r8d,%ecx
 1f824a6:	setbe  %al
 1f824a9:	and    $0xffffffc0,%ecx
 1f824ac:	inc    %r14d
 1f824af:	and    $0x22,%ebx
 1f824b2:	shrx   %r8,0x20(%rdx,%rcx,1),%rcx
 1f824b9:	mov    0x88(%rsp),%r8d
 1f824c1:	mov    %ebp,%edx
 1f824c3:	xor    %edi,%r14d
 1f824c6:	xor    $0x1,%edx
 1f824c9:	cmp    $0x2,%r10d
 1f824cd:	mov    $0x0,%edi
 1f824d2:	cmovne %edi,%r8d
 1f824d6:	test   %ebx,%ebx
 1f824d8:	cmove  %ebx,%r8d
 1f824dc:	test   %r12,%r12
 1f824df:	mov    $0x0,%ebx
 1f824e4:	setne  %dil
 1f824e8:	or     %al,%dil
 1f824eb:	or     %r14d,%edx
 1f824ee:	cmovne 0x90(%rsp),%ebx
 1f824f6:	test   %ebp,%ebp
 1f824f8:	movzbl %dil,%eax
 1f824fc:	cmove  %ebp,%ebx
 1f824ff:	mov    0x4d0(%rsp),%rbp
 1f82507:	or     %eax,%ebx
 1f82509:	xor    %eax,%eax
 1f8250b:	test   %r10d,%r10d
 1f8250e:	sete   %al
 1f82511:	or     %r8d,%ebx
 1f82514:	andn   %eax,%ecx,%eax
 1f82519:	mov    $0x101,%ecx
 1f8251e:	or     %eax,%ebx
 1f82520:	mov    (%rsp),%rax
 1f82524:	mov    %r10d,0x10(%rsp)
 1f82529:	mov    0x98(%rsp),%rdx
 1f82531:	mov    0xa88(%rax),%rax
 1f82538:	movzbl (%rax,%rbp,1),%eax
 1f8253c:	bextr  %ecx,%eax,%eax
 1f82541:	or     %eax,%ebx
 1f82543:	xor    %eax,%eax
 1f82545:	cmp    $0x6,%r10d
 1f82549:	sete   %al
 1f8254c:	lea    (%rdx,%rax,4),%r14
 1f82550:	or     0x60(%rsp),%r14
 1f82555:	cmpb   $0x1,0x3b(%r13)
 1f8255a:	jne    1f825b5 <node_facts_window_run+0x51e5>
 1f8255c:	mov    0x80(%rsp),%r12
 1f82564:	test   %ebx,%ebx
 1f82566:	jne    1f825bd <node_facts_window_run+0x51ed>
 1f82568:	mov    0xa0(%rsp),%rax
 1f82570:	mov    0x20(%rsp),%r8
 1f82575:	mov    0x8(%rax),%rdx
 1f82579:	mov    0x78(%rdx),%eax
 1f8257c:	cmp    %eax,%r8d
 1f8257f:	jae    1f825c2 <node_facts_window_run+0x51f2>
 1f82581:	mov    0x98(%rdx),%rcx
 1f82588:	movzbl (%rcx,%r8,1),%edi
 1f8258d:	cmp    $0x4a,%edi
 1f82590:	je     1f825ac <node_facts_window_run+0x51dc>
 1f82592:	cmp    $0x1e,%edi
 1f82595:	jne    1f825c2 <node_facts_window_run+0x51f2>
 1f82597:	mov    0xa8(%rdx),%rdx
 1f8259e:	mov    (%rdx,%r8,4),%edx
 1f825a2:	cmp    %eax,%edx
 1f825a4:	jae    1f825c2 <node_facts_window_run+0x51f2>
 1f825a6:	cmpb   $0x4a,(%rcx,%rdx,1)
 1f825aa:	jne    1f825c2 <node_facts_window_run+0x51f2>
 1f825ac:	or     $0x1000000,%r14
 1f825b3:	jmp    1f825c2 <node_facts_window_run+0x51f2>
 1f825b5:	mov    0x80(%rsp),%r12
 1f825bd:	mov    0x20(%rsp),%r8
 1f825c2:	cmpl   $0x0,0xb00(%r13)
 1f825ca:	mov    0x38(%rsp),%ecx
 1f825ce:	jne    1f8265e <node_facts_window_run+0x528e>
 1f825d4:	cmp    0xae8(%r13),%r11d
 1f825db:	ja     1f825e6 <node_facts_window_run+0x5216>
 1f825dd:	cmp    0xae4(%r13),%ecx
 1f825e4:	jae    1f8265e <node_facts_window_run+0x528e>
 1f825e6:	mov    0x40(%rsp),%r8
 1f825eb:	mov    0x10(%rsp),%eax
 1f825ef:	mov    0x160(%rsp),%rdi
 1f825f7:	mov    %r14,0x50(%r15)
 1f825fb:	mov    0x2a0(%rsp),%rdx
 1f82603:	mov    $0xffffffffffffffff,%r14
 1f8260a:	add    0x260(%rsp),%edi
 1f82611:	mov    %al,0x60(%r15)
 1f82615:	mov    %r11d,0x58(%r15)
 1f82619:	mov    %ecx,0x5c(%r15)
 1f8261d:	mov    %bl,0x62(%r15)
 1f82621:	or     0x720(%rsp),%ebx
 1f82628:	mov    %edx,%ecx
 1f8262a:	mov    0xb88(%r13),%rax
 1f82631:	add    %ebx,%edx
 1f82633:	mov    %rdx,0x2a0(%rsp)
 1f8263b:	mov    %ebp,(%rax,%rcx,4)
 1f8263e:	mov    %edi,0x260(%rsp)
 1f82645:	jmp    1f81984 <node_facts_window_run+0x45b4>
 1f8264a:	mov    0x28(%rsp),%r9
 1f8264f:	jmp    1f81bde <node_facts_window_run+0x480e>
 1f82654:	mov    0x18(%rsp),%rsi
 1f82659:	jmp    1f82269 <node_facts_window_run+0x4e99>
 1f8265e:	vmovdqu64 %zmm3,0x220(%rsp)
 1f82669:	mov    %r13,%rdi
 1f8266c:	mov    %r8d,%esi
 1f8266f:	mov    %r11d,%edx
 1f82672:	mov    %r11d,0x20(%rsp)
 1f82677:	vzeroupper
 1f8267a:	call   1f6a000 <node_census_reader_marks>
 1f8267f:	vmovdqu64 0x220(%rsp),%zmm3
 1f8268a:	mov    0x20(%rsp),%r11d
 1f8268f:	mov    0x50(%rsp),%r9
 1f82694:	mov    0x40(%rsp),%r8
 1f82699:	mov    0x18(%rsp),%rsi
 1f8269e:	mov    0x38(%rsp),%ecx
 1f826a2:	or     %rax,%r14
 1f826a5:	jmp    1f825eb <node_facts_window_run+0x521b>
 1f826aa:	cmp    $0x2,%r10d
 1f826ae:	jne    1f82480 <node_facts_window_run+0x50b0>
 1f826b4:	mov    0xa0(%rsp),%rax
 1f826bc:	mov    %r8d,%edx
 1f826bf:	vmovdqu64 %zmm3,0x220(%rsp)
 1f826ca:	mov    %r11d,%ebx
 1f826cd:	mov    (%rax),%rax
 1f826d0:	mov    0x6e0(%rax),%rdi
 1f826d7:	mov    0x6e8(%rax),%esi
 1f826dd:	vzeroupper
 1f826e0:	call   1f69be0 <node_census_cleans>
 1f826e5:	vmovdqu64 0x220(%rsp),%zmm3
 1f826f0:	mov    0x50(%rsp),%r9
 1f826f5:	mov    0x18(%rsp),%rsi
 1f826fa:	movzbl %al,%eax
 1f826fd:	mov    %ebx,%r11d
 1f82700:	lea    0x2(,%rax,4),%r10d
 1f82708:	jmp    1f82480 <node_facts_window_run+0x50b0>
 1f8270d:	rdtsc
 1f8270f:	mov    %rdx,0x220(%rsp)
 1f82717:	mov    %rax,0x38(%rsp)
 1f8271c:	cmpb   $0x0,0x70(%rsp)
 1f82721:	je     1f828b9 <node_facts_window_run+0x54e9>
 1f82727:	mov    (%rsp),%rax
 1f8272b:	cmpl   $0x0,0xa90(%rax)
 1f82732:	je     1f828b9 <node_facts_window_run+0x54e9>
 1f82738:	mov    $0xffffffffffffffff,%rdx
 1f8273f:	xor    %esi,%esi
 1f82741:	jmp    1f82766 <node_facts_window_run+0x5396>
 1f82743:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82750:	mov    (%rsp),%rax
 1f82754:	inc    %rsi
 1f82757:	mov    0xa90(%rax),%eax
 1f8275d:	cmp    %rax,%rsi
 1f82760:	jae    1f828b9 <node_facts_window_run+0x54e9>
 1f82766:	imul   $0x68,%rsi,%r10
 1f8276a:	cmpb   $0x0,0x61(%r9,%r10,1)
 1f82770:	je     1f82750 <node_facts_window_run+0x5380>
 1f82772:	mov    (%rsp),%rax
 1f82776:	add    %r9,%r10
 1f82779:	mov    %r13,%rcx
 1f8277c:	mov    0xa68(%rax),%rdi
 1f82783:	mov    0xa70(%rax),%r8
 1f8278a:	mov    (%rdi,%rsi,4),%eax
 1f8278d:	mov    (%r8,%rsi,4),%r11d
 1f82791:	mov    0x10(%r10),%r8
 1f82795:	sub    0xb78(%r13),%r8
 1f8279c:	add    0xb80(%r13),%r8
 1f827a3:	cmpl   $0x0,0x18(%r10)
 1f827a8:	mov    %rax,0x20(%rsp)
 1f827ad:	mov    %rsi,0x10(%rsp)
 1f827b2:	mov    $0x40,%esi
 1f827b7:	mov    0x18(%rsp),%rax
 1f827bc:	mov    0x651b8(%rax,%r11,4),%edi
 1f827c4:	mov    $0x0,%eax
 1f827c9:	je     1f8285d <node_facts_window_run+0x548d>
 1f827cf:	sub    %edi,%r11d
 1f827d2:	mov    %edi,%r13d
 1f827d5:	xor    %r15d,%r15d
 1f827d8:	xor    %r12d,%r12d
 1f827db:	mov    %edi,%ebp
 1f827dd:	inc    %r11d
 1f827e0:	mov    %r11d,%ebx
 1f827e3:	and    $0x3f,%r11d
 1f827e7:	and    $0xffffffc0,%ebx
 1f827ea:	mov    %r11d,%r14d
 1f827ed:	xor    $0x3f,%r14d
 1f827f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82800:	mov    0xb38(%rcx),%r9
 1f82807:	sub    $0x40,%ebp
 1f8280a:	cmovae %esi,%r13d
 1f8280e:	cmp    %r15d,%edi
 1f82811:	cmovbe %eax,%r13d
 1f82815:	add    %rbx,%r9
 1f82818:	cmp    $0x40,%r13d
 1f8281c:	shlx   %r13,%rdx,%r13
 1f82821:	shrx   %r11,(%r15,%r9,1),%rax
 1f82827:	mov    0x40(%r15,%r9,1),%r9
 1f8282c:	not    %r13
 1f8282f:	cmove  %rdx,%r13
 1f82833:	add    $0x40,%r15
 1f82837:	add    %r9,%r9
 1f8283a:	shlx   %r14,%r9,%r9
 1f8283f:	or     %rax,%r9
 1f82842:	and    %r13,%r9
 1f82845:	mov    %ebp,%r13d
 1f82848:	mov    %r9,(%r8,%r12,8)
 1f8284c:	inc    %r12
 1f8284f:	mov    0x18(%r10),%eax
 1f82853:	cmp    %rax,%r12
 1f82856:	mov    $0x0,%eax
 1f8285b:	jb     1f82800 <node_facts_window_run+0x5430>
 1f8285d:	mov    (%rsp),%rax
 1f82861:	mov    0x10(%rsp),%rsi
 1f82866:	mov    0x50(%rsp),%r9
 1f8286b:	mov    0x80(%rsp),%r12
 1f82873:	mov    %rcx,%r13
 1f82876:	mov    0xa58(%rax),%r10
 1f8287d:	cmp    %edi,(%r10,%rsi,4)
 1f82881:	jbe    1f82750 <node_facts_window_run+0x5380>
 1f82887:	mov    0x20(%rsp),%rcx
 1f8288c:	mov    0xb38(%r13),%rax
 1f82893:	mov    %ecx,%r9d
 1f82896:	and    $0xffffffc0,%r9d
 1f8289a:	shrx   %rcx,(%rax,%r9,1),%rax
 1f828a0:	mov    0x50(%rsp),%r9
 1f828a5:	and    $0x1,%eax
 1f828a8:	shlx   %rdi,%rax,%rax
 1f828ad:	shr    $0x6,%edi
 1f828b0:	or     %rax,(%r8,%rdi,8)
 1f828b4:	jmp    1f82750 <node_facts_window_run+0x5380>
 1f828b9:	shlq   $0x20,0xe8(%rsp)
 1f828c2:	shlq   $0x20,0x5f0(%rsp)
 1f828cb:	shlq   $0x20,0x5b0(%rsp)
 1f828d4:	shlq   $0x20,0x220(%rsp)
 1f828dd:	lea    0x890(%rsp),%rdi
 1f828e5:	mov    $0x418,%edx
 1f828ea:	mov    %r12,%rsi
 1f828ed:	vzeroupper
 1f828f0:	call   355e930 <memcpy>
 1f828f5:	mov    0x2a0(%rsp),%rax
 1f828fd:	movb   $0x0,0x5b(%r12)
 1f82903:	test   %eax,%eax
 1f82905:	je     1f82baa <node_facts_window_run+0x57da>
 1f8290b:	mov    (%rsp),%rdi
 1f8290f:	mov    %eax,%r14d
 1f82912:	xor    %r15d,%r15d
 1f82915:	jmp    1f82963 <node_facts_window_run+0x5593>
 1f82917:	nopw   0x0(%rax,%rax,1)
 1f82920:	movzbl 0x7a0(%rsp),%ecx
 1f82928:	mov    (%rsp),%rdi
 1f8292c:	xor    %edx,%edx
 1f8292e:	add    %rdx,0x8a0(%r8)
 1f82935:	mov    %rax,0x50(%r12)
 1f8293a:	mov    %cl,0x60(%r12)
 1f8293f:	inc    %r15
 1f82942:	mov    0x534(%r13),%eax
 1f82949:	mov    %eax,0x58(%r12)
 1f8294e:	mov    0x538(%r13),%eax
 1f82955:	mov    %eax,0x5c(%r12)
 1f8295a:	cmp    %r15,%r14
 1f8295d:	je     1f82b48 <node_facts_window_run+0x5778>
 1f82963:	mov    0xb88(%r13),%rax
 1f8296a:	mov    0xa68(%rdi),%r8
 1f82971:	mov    0xa70(%rdi),%rcx
 1f82978:	mov    (%rax,%r15,4),%r12d
 1f8297c:	mov    0xa58(%rdi),%rax
 1f82983:	mov    (%r8,%r12,4),%ebp
 1f82987:	mov    (%rcx,%r12,4),%r13d
 1f8298b:	mov    0xa48(%rdi),%r8
 1f82992:	mov    0xa50(%rdi),%rcx
 1f82999:	mov    0x80(%rsp),%rdi
 1f829a1:	mov    (%rcx,%r12,4),%ebx
 1f829a5:	mov    (%r8,%r12,4),%esi
 1f829a9:	mov    (%rax,%r12,4),%ecx
 1f829ad:	mov    %ebx,%edx
 1f829af:	call   1f530c0 <node_machine_type>
 1f829b4:	mov    (%rsp),%rax
 1f829b8:	mov    0x18(%rsp),%r8
 1f829bd:	mov    0xa58(%rax),%rax
 1f829c4:	mov    (%rax,%r12,4),%eax
 1f829c8:	cmp    0x651b8(%r8,%r13,4),%eax
 1f829d0:	jbe    1f82a0d <node_facts_window_run+0x563d>
 1f829d2:	inc    %r13d
 1f829d5:	cmp    %r13d,%ebp
 1f829d8:	je     1f82a0d <node_facts_window_run+0x563d>
 1f829da:	mov    0x8(%rsp),%rsi
 1f829df:	mov    %r13d,%eax
 1f829e2:	mov    0xb10(%rsi),%rdx
 1f829e9:	mov    0xb28(%rsi),%rcx
 1f829f0:	mov    0xb20(%rsi),%rsi
 1f829f7:	movzbl (%rdx,%rbp,1),%edi
 1f829fb:	mov    %dil,(%rdx,%rax,1)
 1f829ff:	movzbl (%rsi,%rbp,1),%edx
 1f82a03:	mov    %dl,(%rsi,%rax,1)
 1f82a06:	movzbl (%rcx,%rbp,1),%edx
 1f82a0a:	mov    %dl,(%rcx,%rax,1)
 1f82a0d:	xor    %r9d,%r9d
 1f82a10:	mov    0x422c(%r8,%rbp,4),%ecx
 1f82a18:	cmpb   $0x23,0x2c(%r8,%rbp,1)
 1f82a1e:	mov    $0xffffffff,%r8d
 1f82a24:	jne    1f82a60 <node_facts_window_run+0x5690>
 1f82a26:	mov    0x8(%rsp),%r13
 1f82a2b:	mov    0xa0(%rsp),%rdx
 1f82a33:	cmp    0xa8(%rsp),%ecx
 1f82a3a:	jae    1f82a65 <node_facts_window_run+0x5695>
 1f82a3c:	mov    0x338(%rdx),%rax
 1f82a43:	mov    (%rdx),%rsi
 1f82a46:	mov    (%rax,%rcx,4),%r8d
 1f82a4a:	cmp    0x764(%rsi),%r8d
 1f82a51:	jae    1f82a65 <node_facts_window_run+0x5695>
 1f82a53:	mov    0x1e8(%rdx),%rax
 1f82a5a:	mov    (%rax,%r8,4),%r9d
 1f82a5e:	jmp    1f82a65 <node_facts_window_run+0x5695>
 1f82a60:	mov    0x8(%rsp),%r13
 1f82a65:	imul   $0x68,%r12,%r12
 1f82a69:	add    0x50(%rsp),%r12
 1f82a6e:	cmpb   $0x0,0x70(%rsp)
 1f82a73:	movb   $0x0,0x7a0(%rsp)
 1f82a7b:	je     1f82aa0 <node_facts_window_run+0x56d0>
 1f82a7d:	mov    0x10(%r12),%rax
 1f82a82:	sub    0xb78(%r13),%rax
 1f82a89:	add    0xb80(%r13),%rax
 1f82a90:	jmp    1f82aa2 <node_facts_window_run+0x56d2>
 1f82a92:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82aa0:	xor    %eax,%eax
 1f82aa2:	movzbl 0x70(%rsp),%edx
 1f82aa7:	mov    %rax,0x4d0(%r13)
 1f82aae:	mov    0xc0(%rsp),%rax
 1f82ab6:	mov    %r13,%rdi
 1f82ab9:	mov    %ebx,%esi
 1f82abb:	mov    %dl,0x4d8(%r13)
 1f82ac2:	movzbl (%rax,%rbp,1),%edx
 1f82ac6:	push   %r12
 1f82ac8:	lea    0x7a8(%rsp),%rax
 1f82ad0:	push   %rax
 1f82ad1:	call   1f549a0 <node_census_reader_expression>
 1f82ad6:	add    $0x10,%rsp
 1f82ada:	cmpb   $0x1,0x62(%r12)
 1f82ae0:	mov    0x40(%rsp),%r8
 1f82ae5:	adcq   $0x0,0x898(%r8)
 1f82aed:	cmpb   $0x0,0x62(%r12)
 1f82af3:	jne    1f82920 <node_facts_window_run+0x5550>
 1f82af9:	movzbl 0x7a0(%rsp),%ecx
 1f82b01:	mov    (%rsp),%rdi
 1f82b05:	mov    $0x1,%edx
 1f82b0a:	cmp    0x50(%r12),%rax
 1f82b0f:	jne    1f8292e <node_facts_window_run+0x555e>
 1f82b15:	cmp    0x60(%r12),%cl
 1f82b1a:	jne    1f8292e <node_facts_window_run+0x555e>
 1f82b20:	mov    0x534(%r13),%esi
 1f82b27:	cmp    0x58(%r12),%esi
 1f82b2c:	jne    1f8292e <node_facts_window_run+0x555e>
 1f82b32:	mov    0x538(%r13),%esi
 1f82b39:	xor    %edx,%edx
 1f82b3b:	cmp    0x5c(%r12),%esi
 1f82b40:	setne  %dl
 1f82b43:	jmp    1f8292e <node_facts_window_run+0x555e>
 1f82b48:	rdtsc
 1f82b4a:	xor    %ebx,%ebx
 1f82b4c:	mov    %rdi,%r15
 1f82b4f:	shl    $0x20,%rdx
 1f82b53:	or     %rax,%rdx
 1f82b56:	mov    %rdx,0x28(%rsp)
 1f82b5b:	mov    0x80(%rsp),%r12
 1f82b63:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82b70:	mov    0xb88(%r13),%rax
 1f82b77:	mov    0xa48(%r15),%rcx
 1f82b7e:	mov    0xa50(%r15),%rdx
 1f82b85:	mov    %r12,%rdi
 1f82b88:	mov    (%rax,%rbx,4),%eax
 1f82b8b:	mov    (%rcx,%rax,4),%esi
 1f82b8e:	mov    0xa58(%r15),%rcx
 1f82b95:	mov    (%rdx,%rax,4),%edx
 1f82b98:	mov    (%rcx,%rax,4),%ecx
 1f82b9b:	call   1f530c0 <node_machine_type>
 1f82ba0:	inc    %rbx
 1f82ba3:	cmp    %rbx,%r14
 1f82ba6:	jne    1f82b70 <node_facts_window_run+0x57a0>
 1f82ba8:	jmp    1f82bb8 <node_facts_window_run+0x57e8>
 1f82baa:	rdtsc
 1f82bac:	shl    $0x20,%rdx
 1f82bb0:	or     %rax,%rdx
 1f82bb3:	mov    %rdx,0x28(%rsp)
 1f82bb8:	mov    0xe8(%rsp),%rax
 1f82bc0:	lea    0x890(%rsp),%rsi
 1f82bc8:	mov    %r12,%rdi
 1f82bcb:	or     %rax,0xf0(%rsp)
 1f82bd3:	mov    0x5f0(%rsp),%rax
 1f82bdb:	or     %rax,0x78(%rsp)
 1f82be0:	rdtsc
 1f82be2:	mov    0x5b0(%rsp),%rcx
 1f82bea:	shl    $0x20,%rdx
 1f82bee:	or     %rcx,0x100(%rsp)
 1f82bf6:	mov    0x220(%rsp),%rcx
 1f82bfe:	or     %rcx,0x38(%rsp)
 1f82c03:	or     %rax,%rdx
 1f82c06:	mov    %rdx,0x220(%rsp)
 1f82c0e:	mov    $0x418,%edx
 1f82c13:	call   355e930 <memcpy>
 1f82c18:	mov    (%rsp),%r11
 1f82c1c:	cmpl   $0x0,0xa90(%r11)
 1f82c24:	je     1f82e86 <node_facts_window_run+0x5ab6>
 1f82c2a:	xorb   $0x1,0x70(%rsp)
 1f82c2f:	xor    %r14d,%r14d
 1f82c32:	xor    %eax,%eax
 1f82c34:	mov    0x50(%rsp),%rbp
 1f82c39:	mov    0x18(%rsp),%rsi
 1f82c3e:	mov    0x40(%rsp),%r8
 1f82c43:	add    $0x62,%rbp
 1f82c47:	jmp    1f82c6d <node_facts_window_run+0x589d>
 1f82c49:	nopl   0x0(%rax)
 1f82c50:	mov    %rax,%r15
 1f82c53:	mov    0xa90(%r11),%ecx
 1f82c5a:	inc    %r14
 1f82c5d:	add    $0x68,%rbp
 1f82c61:	mov    %r15,%rax
 1f82c64:	cmp    %rcx,%r14
 1f82c67:	jae    1f82e93 <node_facts_window_run+0x5ac3>
 1f82c6d:	cmpb   $0x0,-0x1(%rbp)
 1f82c71:	je     1f82c50 <node_facts_window_run+0x5880>
 1f82c73:	xor    %edx,%edx
 1f82c75:	cmpb   $0x0,0x0(%rbp)
 1f82c79:	mov    0xa70(%r11),%rcx
 1f82c80:	sete   %dl
 1f82c83:	mov    (%rcx,%r14,4),%ecx
 1f82c87:	add    %rdx,0x890(%r8)
 1f82c8e:	and    0x70(%rsp),%dl
 1f82c92:	movzbl %dl,%edx
 1f82c95:	add    %rdx,0x690(%r8)
 1f82c9c:	cmp    $0x1,%dl
 1f82c9f:	jne    1f82cb0 <node_facts_window_run+0x58e0>
 1f82ca1:	mov    0xa58(%r11),%rdx
 1f82ca8:	mov    (%rdx,%r14,4),%edx
 1f82cac:	jmp    1f82cb2 <node_facts_window_run+0x58e2>
 1f82cae:	xchg   %ax,%ax
 1f82cb0:	xor    %edx,%edx
 1f82cb2:	add    %rdx,0x698(%r8)
 1f82cb9:	mov    0xa58(%r11),%rdx
 1f82cc0:	mov    (%rdx,%r14,4),%edx
 1f82cc4:	cmp    0x651b8(%rsi,%rcx,4),%edx
 1f82ccb:	jbe    1f82cf0 <node_facts_window_run+0x5920>
 1f82ccd:	mov    0xa68(%r11),%rdx
 1f82cd4:	inc    %ecx
 1f82cd6:	xor    %r15d,%r15d
 1f82cd9:	cmp    %ecx,(%rdx,%r14,4)
 1f82cdd:	setne  %r15b
 1f82ce1:	jmp    1f82cf3 <node_facts_window_run+0x5923>
 1f82ce3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82cf0:	xor    %r15d,%r15d
 1f82cf3:	mov    0xa50(%r11),%rcx
 1f82cfa:	mov    0x240(%r8),%rdx
 1f82d01:	mov    (%rcx,%r14,4),%ebx
 1f82d05:	mov    (%rdx,%rbx,8),%r12
 1f82d09:	cmp    %r12,-0x12(%rbp)
 1f82d0d:	jne    1f82d40 <node_facts_window_run+0x5970>
 1f82d0f:	mov    0x248(%r8),%rdx
 1f82d16:	movzbl -0x2(%rbp),%ecx
 1f82d1a:	cmp    (%rdx,%rbx,1),%cl
 1f82d1d:	jne    1f82d40 <node_facts_window_run+0x5970>
 1f82d1f:	mov    0xb50(%r13),%rdx
 1f82d26:	mov    -0xa(%rbp),%ecx
 1f82d29:	cmp    (%rdx,%rbx,4),%ecx
 1f82d2c:	jne    1f82d40 <node_facts_window_run+0x5970>
 1f82d2e:	mov    0xb58(%r13),%rdx
 1f82d35:	mov    -0x6(%rbp),%ecx
 1f82d38:	cmp    (%rdx,%rbx,4),%ecx
 1f82d3b:	sete   %cl
 1f82d3e:	jmp    1f82d42 <node_facts_window_run+0x5972>
 1f82d40:	xor    %ecx,%ecx
 1f82d42:	incq   0xa50(%r8)
 1f82d49:	add    %rax,%r15
 1f82d4c:	mov    %ecx,%edx
 1f82d4e:	mov    0xa58(%r11),%rax
 1f82d55:	xor    $0x1,%dl
 1f82d58:	vmovd  (%rax,%r14,4),%xmm0
 1f82d5e:	movzbl %dl,%eax
 1f82d61:	vmovd  %eax,%xmm1
 1f82d65:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f82d69:	vpaddq 0xa58(%r8),%xmm0,%xmm0
 1f82d72:	vmovdqu %xmm0,0xa58(%r8)
 1f82d7b:	test   %cl,%cl
 1f82d7d:	jne    1f82c53 <node_facts_window_run+0x5883>
 1f82d83:	mov    0x12e4(%r8),%eax
 1f82d8a:	cmp    0x5004b14(%rip),%eax        # 6f878a4 <node_census_list>
 1f82d90:	jae    1f82c53 <node_facts_window_run+0x5883>
 1f82d96:	inc    %eax
 1f82d98:	mov    %eax,0x12e4(%r8)
 1f82d9f:	mov    0xa68(%r11),%rcx
 1f82da6:	mov    0x0(%r13),%rax
 1f82daa:	mov    (%rcx,%r14,4),%ecx
 1f82dae:	mov    0x18(%rax),%rax
 1f82db2:	mov    0x422c(%rsi,%rcx,4),%ecx
 1f82db9:	xor    %esi,%esi
 1f82dbb:	cmp    0x78(%rax),%ecx
 1f82dbe:	jae    1f82e02 <node_facts_window_run+0x5a32>
 1f82dc0:	mov    0x68(%rax),%rax
 1f82dc4:	mov    0x8(%r13),%rdi
 1f82dc8:	mov    (%rax,%rcx,4),%eax
 1f82dcb:	cmp    0x1538(%rdi),%eax
 1f82dd1:	jae    1f82e02 <node_facts_window_run+0x5a32>
 1f82dd3:	mov    0x1530(%rdi),%rcx
 1f82dda:	test   %rcx,%rcx
 1f82ddd:	je     1f82e02 <node_facts_window_run+0x5a32>
 1f82ddf:	mov    (%rcx,%rax,4),%esi
 1f82de2:	lea    0x7a0(%rsp),%rdx
 1f82dea:	lea    0x510(%rsp),%rcx
 1f82df2:	call   111f9b0 <pp_presumed>
 1f82df7:	mov    0x40(%rsp),%r8
 1f82dfc:	mov    (%rsp),%r11
 1f82e00:	mov    %eax,%esi
 1f82e02:	mov    0xa58(%r11),%rax
 1f82e09:	mov    -0x12(%rbp),%rcx
 1f82e0d:	movzbl -0x2(%rbp),%r9d
 1f82e12:	mov    -0x6(%rbp),%r10d
 1f82e16:	mov    (%rax,%r14,4),%edx
 1f82e1a:	mov    0x248(%r8),%rax
 1f82e21:	movzbl (%rax,%rbx,1),%eax
 1f82e25:	mov    %rax,0x10(%rsp)
 1f82e2a:	mov    -0xa(%rbp),%eax
 1f82e2d:	mov    %rax,0x20(%rsp)
 1f82e32:	mov    0x8(%rsp),%r13
 1f82e37:	mov    0xb50(%r13),%rax
 1f82e3e:	mov    0xb58(%r13),%rdi
 1f82e45:	mov    (%rax,%rbx,4),%r11d
 1f82e49:	mov    (%rdi,%rbx,4),%ebx
 1f82e4c:	sub    $0x8,%rsp
 1f82e50:	mov    %r12,%r8
 1f82e53:	lea    -0x1962002(%rip),%rdi        # 620e58 <.str.11115>
 1f82e5a:	xor    %eax,%eax
 1f82e5c:	push   %rbx
 1f82e5d:	push   %r11
 1f82e5f:	push   %r10
 1f82e61:	push   0x40(%rsp)
 1f82e65:	push   0x38(%rsp)
 1f82e69:	call   34ef050 <_IO_printf>
 1f82e6e:	mov    0x70(%rsp),%r8
 1f82e73:	mov    0x30(%rsp),%r11
 1f82e78:	add    $0x30,%rsp
 1f82e7c:	mov    0x18(%rsp),%rsi
 1f82e81:	jmp    1f82c53 <node_facts_window_run+0x5883>
 1f82e86:	mov    0x18(%rsp),%rsi
 1f82e8b:	mov    0x40(%rsp),%r8
 1f82e90:	xor    %r15d,%r15d
 1f82e93:	vpmovsxbq -0x1acc155(%rip),%xmm0        # 4b6d47 <abi_test_hex.digits+0xb9c7>
 1f82e9c:	vmovd  0x8(%rsi),%xmm2
 1f82ea1:	mov    0x28(%rsp),%rcx
 1f82ea6:	mov    0x220(%rsp),%r10
 1f82eae:	mov    0x38(%rsp),%r9
 1f82eb3:	vmovq  %r15,%xmm1
 1f82eb8:	xor    %eax,%eax
 1f82eba:	mov    0x78(%rsp),%rdx
 1f82ebf:	mov    0x100(%rsp),%rdi
 1f82ec7:	mov    0xb8(%rsp),%r15
 1f82ecf:	sub    %rcx,%r10
 1f82ed2:	sub    %r9,%rcx
 1f82ed5:	sub    %r10,%rcx
 1f82ed8:	cmovae %rcx,%rax
 1f82edc:	mov    0xf0(%rsp),%rcx
 1f82ee4:	sub    %rdx,%rdi
 1f82ee7:	vpinsrq $0x0,%r10,%xmm0,%xmm0
 1f82eed:	vpunpcklqdq %xmm1,%xmm2,%xmm1
 1f82ef1:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f82ef7:	vpaddq 0xa98(%r8),%ymm0,%ymm0
 1f82f00:	vmovq  %rdi,%xmm1
 1f82f05:	sub    %rcx,%r9
 1f82f08:	sub    %rcx,%rdx
 1f82f0b:	add    %rax,%r9
 1f82f0e:	vmovq  %rdx,%xmm2
 1f82f13:	vmovdqu %ymm0,0xa98(%r8)
 1f82f1c:	vmovq  %rax,%xmm0
 1f82f21:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f82f25:	vmovq  %r9,%xmm1
 1f82f2a:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f82f2e:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f82f34:	vpaddq 0xa68(%r8),%ymm0,%ymm0
 1f82f3d:	vmovdqu %ymm0,0xa68(%r8)
 1f82f46:	cmpq   $0x0,0xb40(%r11)
 1f82f4e:	je     1f84c34 <node_facts_window_run+0x7864>
 1f82f54:	mov    0x940(%r11),%r13
 1f82f5b:	mov    0x8(%rsi),%ebx
 1f82f5e:	rdtsc
 1f82f60:	lea    0x890(%rsp),%rcx
 1f82f68:	vpxor  %xmm0,%xmm0,%xmm0
 1f82f6c:	vmovdqu64 %zmm0,0x8b0(%rsp)
 1f82f77:	vmovdqu64 %zmm0,0x890(%rsp)
 1f82f82:	mov    %r11,%rdi
 1f82f85:	mov    %rsi,%r12
 1f82f88:	shl    $0x20,%rdx
 1f82f8c:	or     %rax,%rdx
 1f82f8f:	mov    %rdx,0x40(%rsp)
 1f82f94:	mov    %ebx,%edx
 1f82f96:	vzeroupper
 1f82f99:	call   1f93c80 <node_contexts_window_loop>
 1f82f9e:	vmovups 0x8b8(%rsp),%ymm0
 1f82fa7:	vmovdqu 0x8b8(%rsp),%xmm1
 1f82fb0:	mov    %r12,%rsi
 1f82fb3:	vmovups %ymm0,0x1e0(%rsp)
 1f82fbc:	vpbroadcastq 0x8c8(%rsp),%ymm0
 1f82fc6:	mov    (%rsp),%rax
 1f82fca:	vpsubq %xmm0,%xmm1,%xmm0
 1f82fce:	vpaddq 0x8c8(%rsp),%xmm0,%xmm0
 1f82fd7:	vpblendd $0xc,%xmm0,%xmm1,%xmm0
 1f82fdd:	vmovdqu %xmm0,0xc08(%rax)
 1f82fe5:	rdtsc
 1f82fe7:	shl    $0x20,%rdx
 1f82feb:	or     %rax,%rdx
 1f82fee:	mov    %rdx,0x50(%rsp)
 1f82ff3:	mov    %ebx,%edx
 1f82ff5:	mov    (%rsp),%rdi
 1f82ff9:	vzeroupper
 1f82ffc:	call   1f95c30 <node_contexts_window_targets>
 1f83001:	rdtsc
 1f83003:	mov    %r12,%rsi
 1f83006:	shl    $0x20,%rdx
 1f8300a:	or     %rax,%rdx
 1f8300d:	mov    %rdx,0xc0(%rsp)
 1f83015:	mov    (%rsp),%rdi
 1f83019:	call   1f95fc0 <node_contexts_window_part>
 1f8301e:	rdtsc
 1f83020:	lea    0x7a0(%rsp),%rcx
 1f83028:	vpxor  %xmm0,%xmm0,%xmm0
 1f8302c:	vmovdqu64 %zmm0,0x7c0(%rsp)
 1f83034:	vmovdqu64 %zmm0,0x7a0(%rsp)
 1f8303f:	mov    %r12,%rsi
 1f83042:	shl    $0x20,%rdx
 1f83046:	or     %rax,%rdx
 1f83049:	mov    %rdx,0x80(%rsp)
 1f83051:	mov    %ebx,%edx
 1f83053:	mov    (%rsp),%rdi
 1f83057:	vzeroupper
 1f8305a:	call   1f93c80 <node_contexts_window_loop>
 1f8305f:	rdtsc
 1f83061:	mov    %r12,%rsi
 1f83064:	shl    $0x20,%rdx
 1f83068:	or     %rax,%rdx
 1f8306b:	mov    %rdx,0xa8(%rsp)
 1f83073:	mov    %ebx,%edx
 1f83075:	mov    (%rsp),%rdi
 1f83079:	call   1f95c30 <node_contexts_window_targets>
 1f8307e:	rdtsc
 1f83080:	mov    %r12,%rsi
 1f83083:	shl    $0x20,%rdx
 1f83087:	or     %rax,%rdx
 1f8308a:	mov    %rdx,0xa0(%rsp)
 1f83092:	mov    (%rsp),%rdi
 1f83096:	call   1f95fc0 <node_contexts_window_part>
 1f8309b:	mov    (%rsp),%r11
 1f8309f:	rdtsc
 1f830a1:	shl    $0x20,%rdx
 1f830a5:	or     %rax,%rdx
 1f830a8:	cmpl   $0x0,0xa90(%r11)
 1f830b0:	mov    %rdx,0x60(%rsp)
 1f830b5:	mov    %rbx,0x1a0(%rsp)
 1f830bd:	je     1f835fd <node_facts_window_run+0x622d>
 1f830c3:	vpbroadcastq -0x19b4b94(%rip),%xmm0        # 5ce538 <.LCPI3_1>
 1f830cc:	mov    0x18(%rsp),%r10
 1f830d1:	xor    %ebx,%ebx
 1f830d3:	xor    %edi,%edi
 1f830d5:	mov    %r13,0x70(%rsp)
 1f830da:	jmp    1f83102 <node_facts_window_run+0x5d32>
 1f830dc:	mov    (%rsp),%r11
 1f830e0:	xor    %esi,%esi
 1f830e2:	mov    0x18(%rsp),%r10
 1f830e7:	incq   0x12e8(%r13,%rsi,8)
 1f830ef:	mov    0xa90(%r11),%eax
 1f830f6:	inc    %rdi
 1f830f9:	cmp    %rax,%rdi
 1f830fc:	jae    1f83604 <node_facts_window_run+0x6234>
 1f83102:	mov    0xb80(%r11),%rax
 1f83109:	movzbl (%rax,%rdi,1),%r8d
 1f8310e:	test   %r8b,%r8b
 1f83111:	je     1f830ef <node_facts_window_run+0x5d1f>
 1f83113:	mov    0xa70(%r11),%rcx
 1f8311a:	mov    0xa68(%r11),%rax
 1f83121:	mov    (%rcx,%rdi,4),%ecx
 1f83124:	mov    (%rax,%rdi,4),%r12d
 1f83128:	mov    0x651b8(%r10,%rcx,4),%esi
 1f83130:	incq   0xab8(%r13)
 1f83137:	mov    0xa58(%r11),%rax
 1f8313e:	mov    (%rax,%rdi,4),%eax
 1f83141:	add    %rax,0xac0(%r13)
 1f83148:	cmp    $0x1,%r8b
 1f8314c:	jne    1f831a0 <node_facts_window_run+0x5dd0>
 1f8314e:	mov    0xa58(%r11),%rax
 1f83155:	mov    (%rax,%rdi,4),%r10d
 1f83159:	test   %r10d,%r10d
 1f8315c:	je     1f830e0 <node_facts_window_run+0x5d10>
 1f8315e:	mov    0xbe8(%r11),%rax
 1f83165:	sub    %esi,%ecx
 1f83167:	xor    %r11d,%r11d
 1f8316a:	inc    %ecx
 1f8316c:	nopl   0x0(%rax)
 1f83170:	lea    (%rcx,%r11,1),%r9d
 1f83174:	cmp    %esi,%r11d
 1f83177:	cmovae %r12d,%r9d
 1f8317b:	mov    %r9d,%edx
 1f8317e:	shr    $0x3,%edx
 1f83181:	and    $0xfffffff8,%edx
 1f83184:	mov    0x10(%rax,%rdx,8),%r8
 1f83189:	bt     %r9,%r8
 1f8318d:	jb     1f8322b <node_facts_window_run+0x5e5b>
 1f83193:	inc    %r11d
 1f83196:	cmp    %r11d,%r10d
 1f83199:	jne    1f83170 <node_facts_window_run+0x5da0>
 1f8319b:	jmp    1f830dc <node_facts_window_run+0x5d0c>
 1f831a0:	mov    0xa58(%r11),%rcx
 1f831a7:	mov    0xb68(%r11),%rdx
 1f831ae:	cmp    $0x3,%r8b
 1f831b2:	sete   %al
 1f831b5:	mov    (%rcx,%rdi,4),%esi
 1f831b8:	movzbl (%rdx,%rdi,1),%r9d
 1f831bd:	test   %rsi,%rsi
 1f831c0:	sete   %cl
 1f831c3:	cmp    $0x2,%r9b
 1f831c7:	sete   %dl
 1f831ca:	or     %al,%dl
 1f831cc:	or     %cl,%dl
 1f831ce:	je     1f831d8 <node_facts_window_run+0x5e08>
 1f831d0:	xor    %r14d,%r14d
 1f831d3:	jmp    1f83515 <node_facts_window_run+0x6145>
 1f831d8:	mov    0xa70(%r11),%rcx
 1f831df:	mov    0xa68(%r11),%rax
 1f831e6:	mov    %r9b,0x220(%rsp)
 1f831ee:	mov    %r12,0x38(%rsp)
 1f831f3:	mov    0xbe8(%r11),%r12
 1f831fa:	mov    %rbx,0x20(%rsp)
 1f831ff:	mov    %rsi,0x10(%rsp)
 1f83204:	mov    (%rcx,%rdi,4),%ecx
 1f83207:	mov    (%rax,%rdi,4),%r13d
 1f8320b:	mov    0xb48(%r11),%rax
 1f83212:	mov    0x651b8(%r10,%rcx,4),%ebp
 1f8321a:	sub    %ebp,%ecx
 1f8321c:	cmp    $0x1,%esi
 1f8321f:	jne    1f8327f <node_facts_window_run+0x5eaf>
 1f83221:	xor    %r14d,%r14d
 1f83224:	xor    %ebx,%ebx
 1f83226:	jmp    1f83459 <node_facts_window_run+0x6089>
 1f8322b:	mov    (%rsp),%r11
 1f8322f:	mov    %r9d,%esi
 1f83232:	mov    0x18(%rsp),%r10
 1f83237:	mov    0xbd0(%r11),%rcx
 1f8323e:	movzbl (%rcx,%rsi,1),%ecx
 1f83242:	mov    $0x1,%esi
 1f83247:	cmp    $0xd,%ecx
 1f8324a:	je     1f830e7 <node_facts_window_run+0x5d17>
 1f83250:	lea    -0xf(%rcx),%r8d
 1f83254:	mov    $0x2,%esi
 1f83259:	cmp    $0x2,%r8b
 1f8325d:	jb     1f830e7 <node_facts_window_run+0x5d17>
 1f83263:	cmp    $0xe,%ecx
 1f83266:	je     1f835b7 <node_facts_window_run+0x61e7>
 1f8326c:	cmp    $0x11,%ecx
 1f8326f:	jne    1f835c1 <node_facts_window_run+0x61f1>
 1f83275:	mov    $0x4,%esi
 1f8327a:	jmp    1f830e7 <node_facts_window_run+0x5d17>
 1f8327f:	mov    %esi,%edx
 1f83281:	and    $0xfffffffe,%edx
 1f83284:	mov    %r8b,0x28(%rsp)
 1f83289:	xor    %r14d,%r14d
 1f8328c:	xor    %r15d,%r15d
 1f8328f:	mov    %edx,0x8(%rsp)
 1f83293:	lea    0x2(%rcx),%edx
 1f83296:	mov    %rcx,0x30(%rsp)
 1f8329b:	jmp    1f832ba <node_facts_window_run+0x5eea>
 1f8329d:	nopl   (%rax)
 1f832a0:	xor    %r11d,%r11d
 1f832a3:	add    %r10,%r14
 1f832a6:	add    $0x2,%edx
 1f832a9:	inc    %r15d
 1f832ac:	add    %r11,%r14
 1f832af:	cmp    0x8(%rsp),%r15d
 1f832b4:	je     1f83403 <node_facts_window_run+0x6033>
 1f832ba:	mov    %r15d,%ebx
 1f832bd:	lea    -0x1(%rdx),%r15d
 1f832c1:	cmp    %ebp,%ebx
 1f832c3:	mov    $0x1,%r11d
 1f832c9:	mov    $0x1,%r10d
 1f832cf:	cmovae %r13d,%r15d
 1f832d3:	mov    %r15d,%esi
 1f832d6:	and    $0xffffffc0,%esi
 1f832d9:	movzbl (%rax,%r15,1),%r8d
 1f832de:	shrx   %r15,(%r12,%rsi,1),%rsi
 1f832e4:	and    $0x1,%r8d
 1f832e8:	mov    %esi,%r9d
 1f832eb:	and    $0x1,%r9d
 1f832ef:	cmp    %r8d,%r9d
 1f832f2:	jne    1f83363 <node_facts_window_run+0x5f93>
 1f832f4:	test   $0x1,%sil
 1f832f8:	je     1f83360 <node_facts_window_run+0x5f90>
 1f832fa:	mov    (%rsp),%rcx
 1f832fe:	mov    0xbb0(%rcx),%r8
 1f83305:	mov    0xb58(%rcx),%rsi
 1f8330c:	movzbl (%r8,%r15,1),%r8d
 1f83311:	cmp    (%rsi,%r15,1),%r8b
 1f83315:	jne    1f83363 <node_facts_window_run+0x5f93>
 1f83317:	mov    (%rsp),%rcx
 1f8331b:	mov    0xbc0(%rcx),%r8
 1f83322:	mov    0xb50(%rcx),%rsi
 1f83329:	movzbl (%r8,%r15,1),%r8d
 1f8332e:	cmp    (%rsi,%r15,1),%r8b
 1f83332:	jne    1f83363 <node_facts_window_run+0x5f93>
 1f83334:	mov    (%rsp),%rcx
 1f83338:	xor    %r10d,%r10d
 1f8333b:	mov    0xbd8(%rcx),%r8
 1f83342:	mov    0xb60(%rcx),%rsi
 1f83349:	mov    (%r8,%r15,4),%r8d
 1f8334d:	cmp    (%rsi,%r15,4),%r8d
 1f83351:	setne  %r10b
 1f83355:	jmp    1f83363 <node_facts_window_run+0x5f93>
 1f83357:	nopw   0x0(%rax,%rax,1)
 1f83360:	xor    %r10d,%r10d
 1f83363:	lea    0x1(%rbx),%r15d
 1f83367:	mov    %r13d,%esi
 1f8336a:	cmp    %ebp,%r15d
 1f8336d:	cmovb  %edx,%esi
 1f83370:	mov    %esi,%r8d
 1f83373:	and    $0xffffffc0,%r8d
 1f83377:	movzbl (%rax,%rsi,1),%r9d
 1f8337c:	shrx   %rsi,(%r12,%r8,1),%r8
 1f83382:	and    $0x1,%r9d
 1f83386:	mov    %r8d,%ecx
 1f83389:	and    $0x1,%ecx
 1f8338c:	cmp    %r9d,%ecx
 1f8338f:	jne    1f832a3 <node_facts_window_run+0x5ed3>
 1f83395:	test   $0x1,%r8b
 1f83399:	je     1f832a0 <node_facts_window_run+0x5ed0>
 1f8339f:	mov    (%rsp),%r9
 1f833a3:	mov    0xbb0(%r9),%r8
 1f833aa:	mov    0xb58(%r9),%rcx
 1f833b1:	movzbl (%r8,%rsi,1),%r8d
 1f833b6:	cmp    (%rcx,%rsi,1),%r8b
 1f833ba:	jne    1f832a3 <node_facts_window_run+0x5ed3>
 1f833c0:	mov    0xbc0(%r9),%r8
 1f833c7:	mov    0xb50(%r9),%rcx
 1f833ce:	movzbl (%r8,%rsi,1),%r8d
 1f833d3:	cmp    (%rcx,%rsi,1),%r8b
 1f833d7:	jne    1f832a3 <node_facts_window_run+0x5ed3>
 1f833dd:	mov    (%rsp),%r8
 1f833e1:	xor    %r11d,%r11d
 1f833e4:	mov    0xb60(%r8),%rcx
 1f833eb:	mov    0xbd8(%r8),%r8
 1f833f2:	mov    (%r8,%rsi,4),%r8d
 1f833f6:	cmp    (%rcx,%rsi,4),%r8d
 1f833fa:	setne  %r11b
 1f833fe:	jmp    1f832a3 <node_facts_window_run+0x5ed3>
 1f83403:	mov    0x10(%rsp),%rsi
 1f83408:	mov    0xb8(%rsp),%r15
 1f83410:	test   $0x1,%sil
 1f83414:	jne    1f83442 <node_facts_window_run+0x6072>
 1f83416:	mov    (%rsp),%r11
 1f8341a:	mov    0x18(%rsp),%r10
 1f8341f:	mov    0x70(%rsp),%r13
 1f83424:	mov    0x20(%rsp),%rbx
 1f83429:	mov    0x38(%rsp),%r12
 1f8342e:	movzbl 0x28(%rsp),%r8d
 1f83434:	movzbl 0x220(%rsp),%r9d
 1f8343d:	jmp    1f83515 <node_facts_window_run+0x6145>
 1f83442:	mov    (%rsp),%r11
 1f83446:	mov    0x18(%rsp),%r10
 1f8344b:	movzbl 0x28(%rsp),%r8d
 1f83451:	mov    0x30(%rsp),%rcx
 1f83456:	add    $0x2,%ebx
 1f83459:	inc    %ecx
 1f8345b:	add    %ebx,%ecx
 1f8345d:	cmp    %ebp,%ebx
 1f8345f:	cmovb  %ecx,%r13d
 1f83463:	mov    %r13d,%ecx
 1f83466:	and    $0xffffffc0,%ecx
 1f83469:	movzbl (%rax,%r13,1),%edx
 1f8346e:	mov    $0x1,%eax
 1f83473:	shrx   %r13,(%r12,%rcx,1),%rcx
 1f83479:	and    $0x1,%edx
 1f8347c:	mov    %ecx,%esi
 1f8347e:	and    $0x1,%esi
 1f83481:	cmp    %edx,%esi
 1f83483:	jne    1f834f1 <node_facts_window_run+0x6121>
 1f83485:	mov    0x20(%rsp),%rbx
 1f8348a:	mov    0x38(%rsp),%r12
 1f8348f:	mov    0x10(%rsp),%rsi
 1f83494:	movzbl 0x220(%rsp),%r9d
 1f8349d:	test   $0x1,%cl
 1f834a0:	je     1f8350b <node_facts_window_run+0x613b>
 1f834a2:	mov    0xbb0(%r11),%rdx
 1f834a9:	mov    0xb58(%r11),%rcx
 1f834b0:	movzbl (%rdx,%r13,1),%edx
 1f834b5:	cmp    (%rcx,%r13,1),%dl
 1f834b9:	jne    1f8350d <node_facts_window_run+0x613d>
 1f834bb:	mov    0xbc0(%r11),%rdx
 1f834c2:	mov    0xb50(%r11),%rcx
 1f834c9:	movzbl (%rdx,%r13,1),%edx
 1f834ce:	cmp    (%rcx,%r13,1),%dl
 1f834d2:	jne    1f8350d <node_facts_window_run+0x613d>
 1f834d4:	mov    0xbd8(%r11),%rax
 1f834db:	mov    0xb60(%r11),%rcx
 1f834e2:	mov    (%rax,%r13,4),%edx
 1f834e6:	xor    %eax,%eax
 1f834e8:	cmp    (%rcx,%r13,4),%edx
 1f834ec:	setne  %al
 1f834ef:	jmp    1f8350d <node_facts_window_run+0x613d>
 1f834f1:	mov    0x20(%rsp),%rbx
 1f834f6:	mov    0x38(%rsp),%r12
 1f834fb:	mov    0x10(%rsp),%rsi
 1f83500:	movzbl 0x220(%rsp),%r9d
 1f83509:	jmp    1f8350d <node_facts_window_run+0x613d>
 1f8350b:	xor    %eax,%eax
 1f8350d:	mov    0x70(%rsp),%r13
 1f83512:	add    %rax,%r14
 1f83515:	cmp    $0x2,%r9b
 1f83519:	sete   %al
 1f8351c:	cmp    $0x3,%r8b
 1f83520:	sete   %cl
 1f83523:	xor    %cl,%al
 1f83525:	test   %r14,%r14
 1f83528:	vmovd  %ecx,%xmm1
 1f8352c:	setne  %dl
 1f8352f:	incq   0xac8(%r13)
 1f83536:	add    %rsi,%rbx
 1f83539:	or     %al,%dl
 1f8353b:	vpinsrb $0x1,%edx,%xmm1,%xmm1
 1f83541:	vpmovzxbq %xmm1,%xmm1
 1f83546:	vptestmq %xmm0,%xmm1,%k0
 1f8354c:	vmovdqu 0xad8(%r13),%xmm1
 1f83555:	vpmovm2q %k0,%xmm2
 1f8355b:	vpsubq %xmm2,%xmm1,%xmm1
 1f8355f:	vmovdqu %xmm1,0xad8(%r13)
 1f83568:	add    %r14,0xae8(%r13)
 1f8356f:	mov    0xb78(%r11),%rax
 1f83576:	mov    (%rax,%rdi,8),%rax
 1f8357a:	add    %rax,0xb30(%r13)
 1f83581:	cmp    $0x1,%dl
 1f83584:	jne    1f830ef <node_facts_window_run+0x5d1f>
 1f8358a:	mov    0x1368(%r13),%eax
 1f83591:	cmp    $0xf,%rax
 1f83595:	ja     1f830ef <node_facts_window_run+0x5d1f>
 1f8359b:	mov    0x422c(%r10,%r12,4),%ecx
 1f835a3:	mov    %ecx,0x1328(%r13,%rax,4)
 1f835ab:	incl   0x1368(%r13)
 1f835b2:	jmp    1f830ef <node_facts_window_run+0x5d1f>
 1f835b7:	mov    $0x3,%esi
 1f835bc:	jmp    1f830e7 <node_facts_window_run+0x5d17>
 1f835c1:	mov    $0x1,%esi
 1f835c6:	shlx   %r9,%rsi,%r8
 1f835cb:	mov    $0x5,%esi
 1f835d0:	test   %r8,0x18(%rax,%rdx,8)
 1f835d5:	jne    1f830e7 <node_facts_window_run+0x5d17>
 1f835db:	mov    $0x6,%esi
 1f835e0:	test   %r8,0x20(%rax,%rdx,8)
 1f835e5:	jne    1f830e7 <node_facts_window_run+0x5d17>
 1f835eb:	xor    %eax,%eax
 1f835ed:	cmp    $0x7,%ecx
 1f835f0:	setne  %al
 1f835f3:	lea    0x2(%rax,%rax,4),%rsi
 1f835f8:	jmp    1f830e7 <node_facts_window_run+0x5d17>
 1f835fd:	mov    0x18(%rsp),%r10
 1f83602:	xor    %ebx,%ebx
 1f83604:	add    %rbx,0xad0(%r13)
 1f8360b:	mov    0x80(%rsp),%rdx
 1f83613:	mov    0xc0(%rsp),%rsi
 1f8361b:	mov    0x50(%rsp),%rcx
 1f83620:	vmovd  0x1a0(%rsp),%xmm4
 1f83629:	vmovdqu 0xb78(%r13),%xmm0
 1f83632:	vmovq  0x8b0(%rsp),%xmm1
 1f8363b:	vpaddq 0x8d8(%rsp),%xmm0,%xmm0
 1f83644:	vmovdqu %xmm0,0xb78(%r13)
 1f8364d:	mov    0x8e8(%rsp),%rax
 1f83655:	add    %rax,0xb88(%r13)
 1f8365c:	mov    %rdx,%rax
 1f8365f:	sub    %rsi,%rax
 1f83662:	sub    %rcx,%rsi
 1f83665:	sub    0x40(%rsp),%rcx
 1f8366a:	vmovdqu64 0x890(%rsp),%zmm0
 1f83675:	vmovq  %rax,%xmm2
 1f8367a:	vmovq  %rsi,%xmm3
 1f8367f:	mov    0x60(%rsp),%rsi
 1f83684:	mov    0xa8(%rsp),%rax
 1f8368c:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f83690:	vmovq  %rcx,%xmm3
 1f83695:	mov    0xa0(%rsp),%rcx
 1f8369d:	vpunpcklqdq %xmm3,%xmm4,%xmm3
 1f836a1:	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
 1f836a7:	vshufi64x2 $0x44,%zmm2,%zmm0,%zmm0
 1f836ae:	vpaddq 0xaf0(%r13),%zmm0,%zmm0
 1f836b8:	sub    %rcx,%rsi
 1f836bb:	sub    %rax,%rcx
 1f836be:	sub    %rdx,%rax
 1f836c1:	vmovq  %rsi,%xmm3
 1f836c6:	vmovq  %rax,%xmm2
 1f836cb:	vpunpcklqdq %xmm1,%xmm3,%xmm1
 1f836cf:	vmovdqu64 %zmm0,0xaf0(%r13)
 1f836d9:	vmovq  %rcx,%xmm0
 1f836de:	vpunpcklqdq %xmm0,%xmm2,%xmm0
 1f836e2:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f836e8:	vinserti64x4 $0x1,0x1e0(%rsp),%zmm0,%zmm0
 1f836f1:	vpaddq 0xb38(%r13),%zmm0,%zmm0
 1f836fb:	vmovdqu64 %zmm0,0xb38(%r13)
 1f83705:	cmpq   $0x0,0xc20(%r11)
 1f8370d:	je     1f84c34 <node_facts_window_run+0x7864>
 1f83713:	mov    0x8(%r10),%r15d
 1f83717:	mov    0x940(%r11),%r14
 1f8371e:	vpxor  %xmm0,%xmm0,%xmm0
 1f83722:	vmovdqu %ymm0,0x890(%rsp)
 1f8372b:	movq   $0x0,0x8b0(%rsp)
 1f83737:	rdtsc
 1f83739:	mov    %r11,%rdi
 1f8373c:	mov    %r10,%rbx
 1f8373f:	mov    %rdx,0x710(%rsp)
 1f83747:	lea    0x890(%rsp),%rdx
 1f8374f:	mov    %r15d,%esi
 1f83752:	mov    %rax,0xe0(%rsp)
 1f8375a:	vzeroupper
 1f8375d:	call   1f963a0 <node_rows_window_reads>
 1f83762:	rdtsc
 1f83764:	mov    %rbx,%rsi
 1f83767:	mov    %rdx,0x260(%rsp)
 1f8376f:	mov    %r15d,%edx
 1f83772:	mov    %rax,0x5f0(%rsp)
 1f8377a:	mov    (%rsp),%rdi
 1f8377e:	call   1f96ac0 <node_rows_window_shapes>
 1f83783:	mov    (%rsp),%rdi
 1f83787:	rdtsc
 1f83789:	mov    0xc10(%rdi),%rcx
 1f83790:	or     0xc08(%rdi),%rcx
 1f83797:	mov    %rax,0x100(%rsp)
 1f8379f:	mov    %rdx,0x2e0(%rsp)
 1f837a7:	je     1f837c0 <node_facts_window_run+0x63f0>
 1f837a9:	lea    0x890(%rsp),%rcx
 1f837b1:	mov    %rbx,%rsi
 1f837b4:	mov    %r15d,%edx
 1f837b7:	call   1f96ef0 <node_rows_window_updates>
 1f837bc:	mov    (%rsp),%rdi
 1f837c0:	rdtsc
 1f837c2:	mov    %rbx,%rsi
 1f837c5:	mov    %rdx,0x160(%rsp)
 1f837cd:	mov    %r15d,%edx
 1f837d0:	mov    %rax,0x120(%rsp)
 1f837d8:	call   1f97700 <node_rows_window_write>
 1f837dd:	mov    %eax,%ecx
 1f837df:	rdtsc
 1f837e1:	mov    0x8a0(%rsp),%r8
 1f837e9:	mov    0x8b0(%rsp),%r9d
 1f837f1:	vpxor  %xmm0,%xmm0,%xmm0
 1f837f5:	vmovdqu %xmm0,0x51c(%rsp)
 1f837fe:	vmovdqa %xmm0,0x510(%rsp)
 1f83807:	movl   $0x0,0xfc(%rsp)
 1f83812:	movq   $0x0,0x348(%rsp)
 1f8381e:	mov    %rax,0x5b0(%rsp)
 1f83826:	mov    %rdx,0x390(%rsp)
 1f8382e:	sub    $0x8,%rsp
 1f83832:	mov    0x8(%rsp),%rdi
 1f83837:	lea    0x350(%rsp),%rax
 1f8383f:	lea    0x104(%rsp),%r10
 1f83847:	lea    0x518(%rsp),%r11
 1f8384f:	mov    %rbx,%rsi
 1f83852:	mov    %r15d,%edx
 1f83855:	mov    %ecx,0x1a8(%rsp)
 1f8385c:	push   %rax
 1f8385d:	push   %r10
 1f8385f:	push   %r11
 1f83861:	call   1f97d20 <node_rows_window_values>
 1f83866:	add    $0x20,%rsp
 1f8386a:	rdtsc
 1f8386c:	mov    %rbx,%rsi
 1f8386f:	mov    %rdx,0x350(%rsp)
 1f83877:	mov    %rax,0x670(%rsp)
 1f8387f:	mov    (%rsp),%rdi
 1f83883:	call   1f98bc0 <node_rows_window_part>
 1f83888:	mov    (%rsp),%rdi
 1f8388c:	rdtsc
 1f8388e:	movl   $0x0,0xd0(%rsp)
 1f83899:	movq   $0x0,0xc8(%rsp)
 1f838a5:	cmpb   $0x1,0xd58(%rdi)
 1f838ac:	mov    %rax,0xd8(%rsp)
 1f838b4:	mov    %rdx,0x2a0(%rsp)
 1f838bc:	jne    1f838d7 <node_facts_window_run+0x6507>
 1f838be:	mov    0x18(%rsp),%rsi
 1f838c3:	lea    0xc8(%rsp),%rcx
 1f838cb:	mov    %r15d,%edx
 1f838ce:	call   1f98cd0 <node_rows_window_summary>
 1f838d3:	mov    (%rsp),%rdi
 1f838d7:	rdtsc
 1f838d9:	mov    0xdc0(%rdi),%ecx
 1f838df:	movl   $0x0,0xdc0(%rdi)
 1f838e9:	mov    0xa90(%rdi),%r12d
 1f838f0:	cmpb   $0x0,0xdc4(%rdi)
 1f838f7:	mov    %rcx,0x320(%rsp)
 1f838ff:	mov    %rax,0xb0(%rsp)
 1f83907:	mov    %rdx,0x450(%rsp)
 1f8390f:	je     1f83941 <node_facts_window_run+0x6571>
 1f83911:	mov    0xdcc(%rdi),%ecx
 1f83917:	mov    $0x1,%esi
 1f8391c:	mov    %ecx,%ebx
 1f8391e:	inc    %ecx
 1f83920:	and    $0x3,%ebx
 1f83923:	mov    %ecx,0xdcc(%rdi)
 1f83929:	mov    0xc8(%rsp),%r13d
 1f83931:	cmp    $0x2,%ebx
 1f83934:	jne    1f83e26 <node_facts_window_run+0x6a56>
 1f8393a:	mov    $0x2,%ebx
 1f8393f:	jmp    1f8395c <node_facts_window_run+0x658c>
 1f83941:	mov    0xc8(%rsp),%r13d
 1f83949:	mov    $0xffffffff,%ebx
 1f8394e:	mov    %ebx,%eax
 1f83950:	xor    $0x3,%eax
 1f83953:	xor    %esi,%esi
 1f83955:	or     %r13d,%eax
 1f83958:	sete   %sil
 1f8395c:	cmpb   $0x1,0xd58(%rdi)
 1f83963:	mov    %esi,0x154(%rsp)
 1f8396a:	mov    %r14,0x60(%rsp)
 1f8396f:	jne    1f83a2f <node_facts_window_run+0x665f>
 1f83975:	mov    0xd98(%rdi),%rsi
 1f8397c:	mov    0xda8(%rdi),%rdi
 1f83983:	lea    (%r15,%r15,1),%rdx
 1f83987:	call   355e930 <memcpy>
 1f8398c:	mov    (%rsp),%rax
 1f83990:	mov    (%rsp),%rcx
 1f83994:	mov    %r12,%rdx
 1f83997:	mov    0xda0(%rax),%rsi
 1f8399e:	mov    0xdb0(%rcx),%rdi
 1f839a5:	call   355e930 <memcpy>
 1f839aa:	mov    (%rsp),%rax
 1f839ae:	mov    (%rsp),%rcx
 1f839b2:	mov    %r13d,%edx
 1f839b5:	shl    $0x2,%rdx
 1f839b9:	mov    0xd90(%rax),%rsi
 1f839c0:	mov    0xdb8(%rcx),%rdi
 1f839c7:	call   355e930 <memcpy>
 1f839cc:	mov    (%rsp),%rdi
 1f839d0:	xor    %eax,%eax
 1f839d2:	mov    %r15d,%ecx
 1f839d5:	sub    $0x1,%ecx
 1f839d8:	cmovb  %eax,%ecx
 1f839db:	test   %ebx,%ebx
 1f839dd:	sete   %dl
 1f839e0:	cmp    $0x1,%ebx
 1f839e3:	sete   %sil
 1f839e7:	test   %r12d,%r12d
 1f839ea:	sete   %r8b
 1f839ee:	mov    0xda8(%rdi),%rax
 1f839f5:	and    %sil,%r8b
 1f839f8:	or     %dl,%r8b
 1f839fb:	movzbl %r8b,%edx
 1f839ff:	xor    %dx,(%rax,%rcx,2)
 1f83a03:	test   %r12d,%r12d
 1f83a06:	mov    0xdb0(%rdi),%rax
 1f83a0d:	setne  %cl
 1f83a10:	and    %sil,%cl
 1f83a13:	xor    %cl,(%rax)
 1f83a15:	cmp    $0x3,%ebx
 1f83a18:	mov    0xdb8(%rdi),%rdx
 1f83a1f:	sete   %al
 1f83a22:	test   %r13d,%r13d
 1f83a25:	setne  %cl
 1f83a28:	and    %al,%cl
 1f83a2a:	movzbl %cl,%eax
 1f83a2d:	xor    %eax,(%rdx)
 1f83a2f:	mov    0xca8(%rdi),%rsi
 1f83a36:	mov    0x1a0(%rsp),%ebx
 1f83a3d:	mov    0xcb8(%rdi),%rdi
 1f83a44:	mov    %ebx,%r14d
 1f83a47:	mov    %r14,%rdx
 1f83a4a:	call   355e930 <memcpy>
 1f83a4f:	mov    (%rsp),%rax
 1f83a53:	mov    (%rsp),%rcx
 1f83a57:	mov    %r14,%rdx
 1f83a5a:	mov    0xcb0(%rax),%rsi
 1f83a61:	mov    0xcc0(%rcx),%rdi
 1f83a68:	call   355e930 <memcpy>
 1f83a6d:	mov    (%rsp),%rax
 1f83a71:	mov    (%rsp),%rcx
 1f83a75:	lea    0x0(,%r14,8),%rdx
 1f83a7d:	mov    %r14,0x700(%rsp)
 1f83a85:	mov    %rdx,0x6f8(%rsp)
 1f83a8d:	mov    0xcc8(%rax),%rsi
 1f83a94:	mov    0xcd0(%rcx),%rdi
 1f83a9b:	call   355e930 <memcpy>
 1f83aa0:	mov    (%rsp),%rax
 1f83aa4:	mov    $0xffffffff,%edi
 1f83aa9:	movzbl 0xdd0(%rax),%ecx
 1f83ab0:	mov    (%rsp),%rax
 1f83ab4:	mov    0xdd8(%rax),%edx
 1f83aba:	imul   $0x4ec4ec4f,%rdx,%rax
 1f83ac1:	shr    $0x22,%rax
 1f83ac5:	lea    (%rax,%rax,2),%esi
 1f83ac8:	lea    (%rax,%rsi,4),%eax
 1f83acb:	mov    %edx,%esi
 1f83acd:	sub    %eax,%esi
 1f83acf:	test   %ecx,%ecx
 1f83ad1:	cmovne %esi,%edi
 1f83ad4:	xor    %eax,%eax
 1f83ad6:	lea    -0x1(%rdi),%esi
 1f83ad9:	cmp    $0x3,%esi
 1f83adc:	mov    %r15d,%esi
 1f83adf:	cmovae %edi,%eax
 1f83ae2:	test   %ebx,%ebx
 1f83ae4:	cmovne %edi,%eax
 1f83ae7:	add    %edx,%ecx
 1f83ae9:	mov    (%rsp),%rdx
 1f83aed:	mov    (%rsp),%rdi
 1f83af1:	cmp    $0x1,%eax
 1f83af4:	vpbroadcastd %eax,%xmm0
 1f83afa:	vpcmpeqd -0x19bbd12(%rip),%xmm0,%xmm1        # 5c7df0 <.LCPI3_69>
 1f83b02:	vpcmpeqd -0x19bbd0a(%rip),%xmm0,%xmm0        # 5c7e00 <.LCPI3_70>
 1f83b0a:	mov    %ecx,0xdd8(%rdx)
 1f83b10:	mov    (%rsp),%rcx
 1f83b14:	sete   %dl
 1f83b17:	vpsrld $0x1f,%xmm1,%xmm1
 1f83b1c:	vpsrld $0x1f,%xmm0,%xmm0
 1f83b21:	mov    0xcb8(%rcx),%rcx
 1f83b28:	xor    %dl,(%rcx)
 1f83b2a:	mov    (%rsp),%rcx
 1f83b2e:	cmp    $0x2,%eax
 1f83b31:	sete   %dl
 1f83b34:	mov    0xcc0(%rcx),%rcx
 1f83b3b:	xor    %dl,(%rcx)
 1f83b3d:	xor    %ecx,%ecx
 1f83b3f:	cmp    $0x3,%eax
 1f83b42:	mov    0xcd0(%rdi),%rdx
 1f83b49:	sete   %cl
 1f83b4c:	xor    %rcx,(%rdx)
 1f83b4f:	mov    0xfc(%rsp),%ecx
 1f83b56:	vmovsd 0x510(%rsp),%xmm2
 1f83b5f:	vmovups 0x51c(%rsp),%xmm3
 1f83b68:	mov    %rcx,0x330(%rsp)
 1f83b70:	mov    0x348(%rsp),%rcx
 1f83b78:	mov    %rcx,0x328(%rsp)
 1f83b80:	mov    0x518(%rsp),%ecx
 1f83b87:	vmovups %ymm2,0x830(%rsp)
 1f83b90:	vshufps $0x24,%xmm3,%xmm2,%xmm2
 1f83b95:	mov    %rcx,0x708(%rsp)
 1f83b9d:	vpinsrd $0x2,%ecx,%xmm2,%xmm2
 1f83ba3:	xor    %ecx,%ecx
 1f83ba5:	cmp    $0xc,%eax
 1f83ba8:	vmovaps %xmm3,0x800(%rsp)
 1f83bb1:	sete   %cl
 1f83bb4:	xor    0x528(%rsp),%ecx
 1f83bbb:	vpxor  %xmm1,%xmm2,%xmm1
 1f83bbf:	xor    %ebx,%ebx
 1f83bc1:	test   %eax,%eax
 1f83bc3:	vmovdqa %xmm1,0x780(%rsp)
 1f83bcc:	vshufps $0xe9,%xmm3,%xmm3,%xmm1
 1f83bd1:	sete   %bpl
 1f83bd5:	cmp    $0x4,%eax
 1f83bd8:	vxorps %xmm0,%xmm1,%xmm0
 1f83bdc:	sete   0x5f(%rsp)
 1f83be1:	cmp    $0x5,%eax
 1f83be4:	vmovlps %xmm0,0x790(%rsp)
 1f83bed:	vxorps %xmm0,%xmm0,%xmm0
 1f83bf1:	mov    %ecx,0x798(%rsp)
 1f83bf8:	rdtsc
 1f83bfa:	vmovups %ymm0,0x7a0(%rsp)
 1f83c03:	movq   $0x0,0x7c0(%rsp)
 1f83c0f:	mov    %rax,0x3d0(%rsp)
 1f83c17:	mov    %rdx,0x6b0(%rsp)
 1f83c1f:	sete   0x5e(%rsp)
 1f83c24:	lea    0x7a0(%rsp),%rdx
 1f83c2c:	mov    (%rsp),%rdi
 1f83c30:	vzeroupper
 1f83c33:	call   1f963a0 <node_rows_window_reads>
 1f83c38:	rdtsc
 1f83c3a:	mov    %rdx,0x720(%rsp)
 1f83c42:	mov    %r15d,%edx
 1f83c45:	mov    %rax,0x410(%rsp)
 1f83c4d:	mov    0x18(%rsp),%r14
 1f83c52:	mov    (%rsp),%rdi
 1f83c56:	mov    %r14,%rsi
 1f83c59:	call   1f96ac0 <node_rows_window_shapes>
 1f83c5e:	mov    (%rsp),%rdi
 1f83c62:	rdtsc
 1f83c64:	mov    0xc10(%rdi),%rcx
 1f83c6b:	or     0xc08(%rdi),%rcx
 1f83c72:	mov    %rax,0x4d0(%rsp)
 1f83c7a:	mov    %rdx,0x48(%rsp)
 1f83c7f:	je     1f83c98 <node_facts_window_run+0x68c8>
 1f83c81:	lea    0x7a0(%rsp),%rcx
 1f83c89:	mov    %r14,%rsi
 1f83c8c:	mov    %r15d,%edx
 1f83c8f:	call   1f96ef0 <node_rows_window_updates>
 1f83c94:	mov    (%rsp),%rdi
 1f83c98:	mov    %r13d,0x158(%rsp)
 1f83ca0:	mov    %r12,0x6f0(%rsp)
 1f83ca8:	rdtsc
 1f83caa:	mov    %bpl,%bl
 1f83cad:	mov    %r14,%rsi
 1f83cb0:	mov    %rax,0x490(%rsp)
 1f83cb8:	mov    %rdx,0x88(%rsp)
 1f83cc0:	mov    %r15d,%edx
 1f83cc3:	call   1f97700 <node_rows_window_write>
 1f83cc8:	mov    %eax,%ecx
 1f83cca:	rdtsc
 1f83ccc:	mov    0x7b0(%rsp),%r8
 1f83cd4:	mov    0x7c0(%rsp),%r9d
 1f83cdc:	vxorps %xmm0,%xmm0,%xmm0
 1f83ce0:	vmovups %xmm0,0x76c(%rsp)
 1f83ce9:	vmovaps %xmm0,0x760(%rsp)
 1f83cf2:	movl   $0x0,0xf8(%rsp)
 1f83cfd:	movq   $0x0,0x340(%rsp)
 1f83d09:	mov    %rax,0x630(%rsp)
 1f83d11:	mov    %rdx,0x90(%rsp)
 1f83d19:	sub    $0x8,%rsp
 1f83d1d:	mov    0x8(%rsp),%rdi
 1f83d22:	lea    0x348(%rsp),%rax
 1f83d2a:	lea    0x768(%rsp),%r11
 1f83d32:	lea    0x100(%rsp),%r10
 1f83d3a:	mov    %r14,%rsi
 1f83d3d:	mov    %r15d,%edx
 1f83d40:	mov    %ecx,0x164(%rsp)
 1f83d47:	push   %rax
 1f83d48:	push   %r10
 1f83d4a:	push   %r11
 1f83d4c:	call   1f97d20 <node_rows_window_values>
 1f83d51:	add    $0x20,%rsp
 1f83d55:	rdtsc
 1f83d57:	mov    %r14,%rsi
 1f83d5a:	mov    %rdx,0xf0(%rsp)
 1f83d62:	mov    %rax,0x570(%rsp)
 1f83d6a:	mov    (%rsp),%rdi
 1f83d6e:	call   1f98bc0 <node_rows_window_part>
 1f83d73:	mov    (%rsp),%r11
 1f83d77:	rdtsc
 1f83d79:	movl   $0x0,0x148(%rsp)
 1f83d84:	movq   $0x0,0x140(%rsp)
 1f83d90:	cmpb   $0x1,0xd58(%r11)
 1f83d98:	mov    %rax,0x530(%rsp)
 1f83da0:	mov    %rdx,0xe8(%rsp)
 1f83da8:	jne    1f83dc6 <node_facts_window_run+0x69f6>
 1f83daa:	mov    0x18(%rsp),%rsi
 1f83daf:	lea    0x140(%rsp),%rcx
 1f83db7:	mov    %r11,%rdi
 1f83dba:	mov    %r15d,%edx
 1f83dbd:	call   1f98cd0 <node_rows_window_summary>
 1f83dc2:	mov    (%rsp),%r11
 1f83dc6:	mov    %r15,0x338(%rsp)
 1f83dce:	rdtsc
 1f83dd0:	mov    0xdc0(%r11),%ecx
 1f83dd7:	movl   $0x0,0xdc0(%r11)
 1f83de2:	mov    %rax,0x98(%rsp)
 1f83dea:	mov    %rdx,0x78(%rsp)
 1f83def:	xor    %ebx,0x1a0(%rsp)
 1f83df6:	mov    %ecx,0x150(%rsp)
 1f83dfd:	cmpl   $0x0,0xa90(%r11)
 1f83e05:	mov    0x18(%rsp),%r10
 1f83e0a:	mov    0x60(%rsp),%r13
 1f83e0f:	je     1f846e1 <node_facts_window_run+0x7311>
 1f83e15:	vpbroadcastq -0x19b58e6(%rip),%xmm2        # 5ce538 <.LCPI3_1>
 1f83e1e:	xor    %r15d,%r15d
 1f83e21:	jmp    1f83ea3 <node_facts_window_run+0x6ad3>
 1f83e26:	setb   %al
 1f83e29:	test   %r15d,%r15d
 1f83e2c:	sete   %cl
 1f83e2f:	test   %cl,%al
 1f83e31:	je     1f8394e <node_facts_window_run+0x657e>
 1f83e37:	jmp    1f8395c <node_facts_window_run+0x658c>
 1f83e3c:	incq   0x198(%r13)
 1f83e43:	movzbl 0xdc4(%r11),%eax
 1f83e4b:	add    %eax,0xdc8(%r11)
 1f83e52:	mov    0x60(%rsp),%r13
 1f83e57:	mov    $0x101,%eax
 1f83e5c:	vmovd  %ebp,%xmm1
 1f83e60:	bextr  %eax,%r14d,%eax
 1f83e65:	and    $0x1,%r14d
 1f83e69:	vmovd  %eax,%xmm0
 1f83e6d:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f83e71:	vpaddq 0xcf0(%r13),%xmm0,%xmm0
 1f83e7a:	vmovdqu %xmm0,0xcf0(%r13)
 1f83e83:	add    %r14,0xd00(%r13)
 1f83e8a:	nopw   0x0(%rax,%rax,1)
 1f83e90:	mov    0xa90(%r11),%eax
 1f83e97:	inc    %r15
 1f83e9a:	cmp    %rax,%r15
 1f83e9d:	jae    1f846e1 <node_facts_window_run+0x7311>
 1f83ea3:	mov    0xd40(%r11),%rax
 1f83eaa:	movzbl (%rax,%r15,1),%eax
 1f83eaf:	test   %al,%al
 1f83eb1:	je     1f83e90 <node_facts_window_run+0x6ac0>
 1f83eb3:	mov    0xa70(%r11),%rdx
 1f83eba:	mov    0xa68(%r11),%rcx
 1f83ec1:	mov    (%rdx,%r15,4),%edx
 1f83ec5:	mov    (%rcx,%r15,4),%r14d
 1f83ec9:	mov    0x651b8(%r10,%rdx,4),%edi
 1f83ed1:	incq   0xb90(%r13)
 1f83ed8:	mov    0xa58(%r11),%rcx
 1f83edf:	mov    (%rcx,%r15,4),%ecx
 1f83ee3:	add    %rcx,0xb98(%r13)
 1f83eea:	cmp    $0x1,%al
 1f83eec:	jne    1f83f60 <node_facts_window_run+0x6b90>
 1f83eee:	mov    0xa58(%r11),%rax
 1f83ef5:	mov    $0x1,%esi
 1f83efa:	mov    (%rax,%r15,4),%r10d
 1f83efe:	test   %r10d,%r10d
 1f83f01:	je     1f83f51 <node_facts_window_run+0x6b81>
 1f83f03:	mov    0xbe8(%r11),%rax
 1f83f0a:	sub    %edi,%edx
 1f83f0c:	xor    %ecx,%ecx
 1f83f0e:	xor    %r11d,%r11d
 1f83f11:	inc    %edx
 1f83f13:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f83f20:	lea    (%rdx,%r11,1),%r9d
 1f83f24:	cmp    %edi,%r11d
 1f83f27:	cmovae %r14d,%r9d
 1f83f2b:	mov    %r9d,%r8d
 1f83f2e:	shr    $0x3,%r8d
 1f83f32:	and    $0xfffffff8,%r8d
 1f83f36:	mov    0x28(%rax,%r8,8),%rbx
 1f83f3b:	bt     %r9,%rbx
 1f83f3f:	jb     1f842a0 <node_facts_window_run+0x6ed0>
 1f83f45:	inc    %r11d
 1f83f48:	cmp    %r11d,%r10d
 1f83f4b:	jne    1f83f20 <node_facts_window_run+0x6b50>
 1f83f4d:	mov    (%rsp),%r11
 1f83f51:	mov    0x18(%rsp),%r10
 1f83f56:	jmp    1f842ef <node_facts_window_run+0x6f1f>
 1f83f5b:	nopl   0x0(%rax,%rax,1)
 1f83f60:	mov    0xa68(%r11),%rcx
 1f83f67:	mov    0xa70(%r11),%rdx
 1f83f6e:	mov    0xa58(%r11),%rax
 1f83f75:	xor    %r9d,%r9d
 1f83f78:	mov    (%rcx,%r15,4),%ecx
 1f83f7c:	mov    %rcx,0x8(%rsp)
 1f83f81:	mov    (%rdx,%r15,4),%ecx
 1f83f85:	mov    0xc40(%r11),%rdx
 1f83f8c:	mov    0x651b8(%r10,%rcx,4),%esi
 1f83f94:	cmp    %esi,(%rax,%r15,4)
 1f83f98:	jbe    1f83fa4 <node_facts_window_run+0x6bd4>
 1f83f9a:	mov    0x8(%rsp),%rax
 1f83f9f:	movzbl (%rdx,%rax,1),%r9d
 1f83fa4:	mov    0xc60(%r11),%r8
 1f83fab:	mov    0xc80(%r11),%r10
 1f83fb2:	mov    %ecx,%edi
 1f83fb4:	sub    %esi,%edi
 1f83fb6:	mov    %ecx,%esi
 1f83fb8:	shr    $0x3,%esi
 1f83fbb:	mov    0x940(%r11),%rax
 1f83fc2:	inc    %edi
 1f83fc4:	movzbl (%r8,%rdi,1),%ebx
 1f83fc9:	shr    $0x3,%edi
 1f83fcc:	mov    %r10,0x38(%rsp)
 1f83fd1:	mov    %r8,0x20(%rsp)
 1f83fd6:	movzbl (%r8,%rcx,1),%ebp
 1f83fdb:	add    (%r10,%rdi,4),%ebx
 1f83fdf:	mov    (%r10,%rsi,4),%r10d
 1f83fe3:	mov    0xa50(%r11),%rsi
 1f83fea:	movzbl (%rdx,%rcx,1),%edi
 1f83fee:	mov    %r10d,%ecx
 1f83ff1:	mov    %rbx,0x10(%rsp)
 1f83ff6:	sub    %ebx,%ecx
 1f83ff8:	mov    (%rsi,%r15,4),%esi
 1f83ffc:	mov    0x130(%rax),%rbx
 1f84003:	add    %ebp,%ecx
 1f84005:	add    %edi,%ecx
 1f84007:	add    %ecx,%r9d
 1f8400a:	mov    (%rbx,%rsi,4),%r8d
 1f8400e:	cmp    $0xffffffff,%r8d
 1f84012:	je     1f84295 <node_facts_window_run+0x6ec5>
 1f84018:	mov    %r10d,0x40(%rsp)
 1f8401d:	mov    %rdi,0x1e0(%rsp)
 1f84025:	mov    0xdd4(%r11),%r10d
 1f8402c:	movzbl 0xdd0(%r11),%edi
 1f84034:	mov    $0x4,%edx
 1f84039:	mov    %r14,0xc0(%rsp)
 1f84041:	mov    %r10d,%ebx
 1f84044:	and    $0x3,%ebx
 1f84047:	test   %edi,%edi
 1f84049:	mov    %r10d,0x80(%rsp)
 1f84051:	cmove  %edx,%ebx
 1f84054:	test   $0x4,%r10b
 1f84058:	movabs $0x8000000000000000,%r10
 1f84062:	mov    $0x1,%edx
 1f84067:	cmove  %rdx,%r10
 1f8406b:	test   %r8d,%r8d
 1f8406e:	sete   %dl
 1f84071:	mov    %r10,0x220(%rsp)
 1f84079:	mov    %edi,0xa0(%rsp)
 1f84080:	mov    %r8d,0xa8(%rsp)
 1f84088:	mov    %r9,0x50(%rsp)
 1f8408d:	and    %dil,%dl
 1f84090:	cmp    $0x2,%ebx
 1f84093:	sete   %dil
 1f84097:	or     %dl,%dil
 1f8409a:	movzbl %dil,%edx
 1f8409e:	add    %r8d,%edx
 1f840a1:	mov    0x110(%rax),%r8
 1f840a8:	cmp    $0x3,%ebx
 1f840ab:	sete   %dil
 1f840af:	cmpb   $0x0,(%r8,%rsi,1)
 1f840b4:	setne  %r8b
 1f840b8:	cmp    %edx,%r9d
 1f840bb:	setne  %r12b
 1f840bf:	xor    %r10d,%r10d
 1f840c2:	or     %r8b,%r12b
 1f840c5:	jne    1f843e6 <node_facts_window_run+0x7016>
 1f840cb:	test   %edx,%edx
 1f840cd:	je     1f843e6 <node_facts_window_run+0x7016>
 1f840d3:	mov    0x128(%rax),%rdx
 1f840da:	mov    %rbp,%r9
 1f840dd:	mov    0x140(%rax),%rbp
 1f840e4:	mov    %ecx,%ecx
 1f840e6:	mov    (%rdx,%rsi,4),%edx
 1f840e9:	mov    0x148(%rax),%rsi
 1f840f0:	add    %rdx,%rsi
 1f840f3:	add    %rdx,%rbp
 1f840f6:	shl    $0x3,%rdx
 1f840fa:	add    0x150(%rax),%rdx
 1f84101:	cmp    $0x1,%ebx
 1f84104:	mov    %rsi,0x28(%rsp)
 1f84109:	sete   %al
 1f8410c:	cmp    $0x3,%ebx
 1f8410f:	mov    %rdx,0x70(%rsp)
 1f84114:	sete   %dl
 1f84117:	mov    0x50(%rsp),%r8
 1f8411c:	cmp    $0x2,%r8d
 1f84120:	lea    -0x1(%r8),%r13d
 1f84124:	mov    %r8d,%r8d
 1f84127:	setae  %sil
 1f8412b:	and    %al,%sil
 1f8412e:	mov    0x8(%rsp),%rax
 1f84133:	shr    $0x3,%eax
 1f84136:	mov    %rax,0x30(%rsp)
 1f8413b:	or     %dl,%sil
 1f8413e:	mov    (%rsp),%rax
 1f84142:	mov    0xca8(%rax),%r11
 1f84149:	test   %sil,%sil
 1f8414c:	je     1f842fc <node_facts_window_run+0x6f2c>
 1f84152:	mov    0x80(%rsp),%eax
 1f84159:	xor    %esi,%esi
 1f8415b:	and    $0x8,%eax
 1f8415e:	shr    $0x3,%eax
 1f84161:	and    %al,%dil
 1f84164:	mov    $0x0,%edi
 1f84169:	mov    0x10(%rsp),%rax
 1f8416e:	cmovne %r13,%rdi
 1f84172:	sub    0x40(%rsp),%eax
 1f84176:	neg    %r13
 1f84179:	xor    %r14d,%r14d
 1f8417c:	sub    0x1e0(%rsp),%eax
 1f84183:	neg    %rdi
 1f84186:	sub    %r9d,%eax
 1f84189:	mov    %rax,0x40(%rsp)
 1f8418e:	mov    $0x1,%eax
 1f84193:	mov    %r13,0x1e0(%rsp)
 1f8419b:	jmp    1f841ba <node_facts_window_run+0x6dea>
 1f8419d:	nopl   (%rax)
 1f841a0:	inc    %rsi
 1f841a3:	cmp    %r8,%rax
 1f841a6:	mov    %r10d,%r14d
 1f841a9:	setae  %dl
 1f841ac:	inc    %rax
 1f841af:	or     %r12b,%dl
 1f841b2:	test   %dl,%dl
 1f841b4:	jne    1f843e6 <node_facts_window_run+0x7016>
 1f841ba:	lea    -0x1(%rax),%rdx
 1f841be:	cmp    %rcx,%rdx
 1f841c1:	jae    1f841d0 <node_facts_window_run+0x6e00>
 1f841c3:	mov    0x10(%rsp),%rdx
 1f841c8:	lea    (%rdx,%rsi,1),%r9d
 1f841cc:	mov    %esi,%edx
 1f841ce:	jmp    1f841fe <node_facts_window_run+0x6e2e>
 1f841d0:	mov    0x8(%rsp),%rdx
 1f841d5:	mov    0x20(%rsp),%r9
 1f841da:	mov    0x38(%rsp),%r12
 1f841df:	mov    0x30(%rsp),%r10
 1f841e4:	movzbl (%r9,%rdx,1),%r9d
 1f841e9:	mov    0x40(%rsp),%rdx
 1f841ee:	add    (%r12,%r10,4),%r9d
 1f841f2:	lea    (%rdx,%rax,1),%r10d
 1f841f6:	lea    -0x1(%rax),%edx
 1f841f9:	lea    -0x1(%r10,%r9,1),%r9d
 1f841fe:	or     %ebx,%edx
 1f84200:	lea    (%rdi,%rax,1),%r10
 1f84204:	mov    $0x0,%edx
 1f84209:	mov    $0x1,%r12b
 1f8420c:	mov    %r9d,%r9d
 1f8420f:	sete   %r13b
 1f84213:	xor    -0x1(%rbp,%rax,1),%r13b
 1f84218:	cmp    $0x1,%r10
 1f8421c:	mov    $0x1,%r10b
 1f8421f:	cmove  0x220(%rsp),%rdx
 1f84228:	cmp    %r13b,(%r11,%r9,1)
 1f8422c:	jne    1f84269 <node_facts_window_run+0x6e99>
 1f8422e:	mov    0x1e0(%rsp),%r12
 1f84236:	cmp    $0x1,%ebx
 1f84239:	sete   %r13b
 1f8423d:	add    %rax,%r12
 1f84240:	cmp    $0x1,%r12
 1f84244:	sete   %r12b
 1f84248:	and    %r13b,%r12b
 1f8424b:	mov    0x28(%rsp),%r13
 1f84250:	xor    -0x1(%r13,%rax,1),%r12b
 1f84255:	mov    (%rsp),%r13
 1f84259:	mov    0xcb0(%r13),%r13
 1f84260:	cmp    %r12b,0x0(%r13,%r9,1)
 1f84265:	setne  %r12b
 1f84269:	test   $0x1,%r14b
 1f8426d:	jne    1f841a0 <node_facts_window_run+0x6dd0>
 1f84273:	mov    0x70(%rsp),%r10
 1f84278:	mov    (%rsp),%r14
 1f8427c:	xor    -0x8(%r10,%rax,8),%rdx
 1f84281:	mov    0xcc8(%r14),%r10
 1f84288:	cmp    %rdx,(%r10,%r9,8)
 1f8428c:	setne  %r10b
 1f84290:	jmp    1f841a0 <node_facts_window_run+0x6dd0>
 1f84295:	xor    %r10d,%r10d
 1f84298:	xor    %r12d,%r12d
 1f8429b:	jmp    1f84419 <node_facts_window_run+0x7049>
 1f842a0:	mov    (%rsp),%r11
 1f842a4:	mov    %r9d,%edx
 1f842a7:	mov    0xbb0(%r11),%rsi
 1f842ae:	movzbl (%rsi,%rdx,1),%esi
 1f842b2:	and    $0x3f,%sil
 1f842b6:	cmp    $0x14,%sil
 1f842ba:	je     1f842cc <node_facts_window_run+0x6efc>
 1f842bc:	mov    0xc30(%r11),%rsi
 1f842c3:	xor    %ecx,%ecx
 1f842c5:	cmpb   $0x7f,(%rsi,%rdx,1)
 1f842c9:	setne  %cl
 1f842cc:	mov    0x18(%rsp),%r10
 1f842d1:	and    $0x3f,%r9d
 1f842d5:	mov    $0x1,%edx
 1f842da:	mov    $0x2,%esi
 1f842df:	shlx   %r9,%rdx,%rdx
 1f842e4:	test   %rdx,0x30(%rax,%r8,8)
 1f842e9:	je     1f8461e <node_facts_window_run+0x724e>
 1f842ef:	incq   0xbb8(%r13,%rsi,8)
 1f842f7:	jmp    1f83e90 <node_facts_window_run+0x6ac0>
 1f842fc:	mov    0x10(%rsp),%rax
 1f84301:	sub    0x40(%rsp),%eax
 1f84305:	xor    %esi,%esi
 1f84307:	xor    %edi,%edi
 1f84309:	sub    0x1e0(%rsp),%eax
 1f84310:	sub    %r9d,%eax
 1f84313:	jmp    1f84338 <node_facts_window_run+0x6f68>
 1f84315:	data16 cs nopw 0x0(%rax,%rax,1)
 1f84320:	inc    %rsi
 1f84323:	mov    %r10d,%edi
 1f84326:	cmp    %r8,%rsi
 1f84329:	setae  %dl
 1f8432c:	or     %r12b,%dl
 1f8432f:	cmp    $0x1,%dl
 1f84332:	je     1f843e6 <node_facts_window_run+0x7016>
 1f84338:	cmp    %rcx,%rsi
 1f8433b:	jae    1f84350 <node_facts_window_run+0x6f80>
 1f8433d:	mov    0x10(%rsp),%rdx
 1f84342:	add    %esi,%edx
 1f84344:	jmp    1f84371 <node_facts_window_run+0x6fa1>
 1f84346:	cs nopw 0x0(%rax,%rax,1)
 1f84350:	mov    0x8(%rsp),%rdx
 1f84355:	mov    0x20(%rsp),%r9
 1f8435a:	mov    0x30(%rsp),%r10
 1f8435f:	movzbl (%r9,%rdx,1),%edx
 1f84364:	mov    0x38(%rsp),%r9
 1f84369:	add    (%r9,%r10,4),%edx
 1f8436d:	add    %eax,%edx
 1f8436f:	add    %esi,%edx
 1f84371:	mov    %esi,%r9d
 1f84374:	or     %ebx,%r9d
 1f84377:	mov    $0x1,%r10b
 1f8437a:	mov    $0x1,%r12b
 1f8437d:	mov    %edx,%edx
 1f8437f:	sete   %r9b
 1f84383:	xor    0x0(%rbp,%rsi,1),%r9b
 1f84388:	cmp    %r9b,(%r11,%rdx,1)
 1f8438c:	jne    1f843bb <node_facts_window_run+0x6feb>
 1f8438e:	cmp    $0x1,%ebx
 1f84391:	sete   %r9b
 1f84395:	cmp    %rsi,%r13
 1f84398:	sete   %r14b
 1f8439c:	and    %r9b,%r14b
 1f8439f:	mov    0x28(%rsp),%r9
 1f843a4:	xor    (%r9,%rsi,1),%r14b
 1f843a8:	mov    (%rsp),%r9
 1f843ac:	mov    0xcb0(%r9),%r9
 1f843b3:	cmp    %r14b,(%r9,%rdx,1)
 1f843b7:	setne  %r12b
 1f843bb:	test   $0x1,%dil
 1f843bf:	jne    1f84320 <node_facts_window_run+0x6f50>
 1f843c5:	mov    0x70(%rsp),%rdi
 1f843ca:	mov    (%rsp),%r9
 1f843ce:	mov    (%rdi,%rsi,8),%rdi
 1f843d2:	mov    0xcc8(%r9),%r9
 1f843d9:	cmp    %rdi,(%r9,%rdx,8)
 1f843dd:	setne  %r10b
 1f843e1:	jmp    1f84320 <node_facts_window_run+0x6f50>
 1f843e6:	mov    0x80(%rsp),%eax
 1f843ed:	mov    (%rsp),%r11
 1f843f1:	mov    0x60(%rsp),%r13
 1f843f6:	mov    0xc0(%rsp),%r14
 1f843fe:	mov    0x50(%rsp),%r9
 1f84403:	mov    0xa8(%rsp),%r8d
 1f8440b:	add    0xa0(%rsp),%eax
 1f84412:	mov    %eax,0xdd4(%r11)
 1f84419:	cmp    $0xffffffff,%r8d
 1f8441d:	vmovd  %r9d,%xmm1
 1f84422:	mov    %r12d,%ecx
 1f84425:	sete   %al
 1f84428:	incq   0xba0(%r13)
 1f8442f:	or     %r10b,%r12b
 1f84432:	xor    $0x1,%cl
 1f84435:	mov    0xa58(%r11),%rdx
 1f8443c:	and    %r10b,%cl
 1f8443f:	vmovd  (%rdx,%r15,4),%xmm0
 1f84445:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f84449:	vpaddq 0xba8(%r13),%xmm0,%xmm0
 1f84452:	vmovdqu %xmm0,0xba8(%r13)
 1f8445b:	vmovd  %r12d,%xmm0
 1f84460:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f84466:	movzbl %cl,%eax
 1f84469:	vpmovzxbq %xmm0,%xmm0
 1f8446e:	vptestmq %xmm2,%xmm0,%k0
 1f84474:	vmovdqu 0xbd8(%r13),%xmm0
 1f8447d:	vpmovm2q %k0,%xmm1
 1f84483:	vpsubq %xmm1,%xmm0,%xmm0
 1f84487:	vmovdqu %xmm0,0xbd8(%r13)
 1f84490:	add    %rax,0xcc0(%r13)
 1f84497:	mov    0xd48(%r11),%rax
 1f8449e:	mov    (%rax,%r15,8),%rax
 1f844a2:	add    %rax,0xc48(%r13)
 1f844a9:	test   $0x1,%r12b
 1f844ad:	je     1f844e1 <node_facts_window_run+0x7111>
 1f844af:	mov    0x13ac(%r13),%eax
 1f844b6:	mov    0x18(%rsp),%r10
 1f844bb:	cmp    $0xf,%rax
 1f844bf:	ja     1f83e90 <node_facts_window_run+0x6ac0>
 1f844c5:	mov    0x422c(%r10,%r14,4),%ecx
 1f844cd:	mov    %ecx,0x136c(%r13,%rax,4)
 1f844d5:	incl   0x13ac(%r13)
 1f844dc:	jmp    1f83e90 <node_facts_window_run+0x6ac0>
 1f844e1:	cmpb   $0x1,0xd58(%r11)
 1f844e9:	mov    0x18(%rsp),%r10
 1f844ee:	jne    1f83e90 <node_facts_window_run+0x6ac0>
 1f844f4:	mov    0xda0(%r11),%rax
 1f844fb:	mov    $0x4,%r12d
 1f84501:	movzbl (%rax,%r15,1),%r14d
 1f84506:	incq   0xce8(%r13)
 1f8450d:	mov    0xa70(%r11),%rax
 1f84514:	mov    0xd98(%r11),%rcx
 1f8451b:	mov    (%rax,%r15,4),%eax
 1f8451f:	lea    0x1(%rax),%edx
 1f84522:	movzwl -0x2(%rcx,%rdx,2),%ebp
 1f84527:	sub    0x651b8(%r10,%rax,4),%edx
 1f8452f:	cmpb   $0x1,0xdc4(%r11)
 1f84537:	movzwl -0x2(%rcx,%rdx,2),%eax
 1f8453c:	jne    1f8454f <node_facts_window_run+0x717f>
 1f8453e:	mov    0xdc8(%r11),%r12d
 1f84545:	and    $0x3,%r12d
 1f84549:	je     1f84639 <node_facts_window_run+0x7269>
 1f8454f:	cmp    $0x1,%r12d
 1f84553:	mov    $0xffffffff,%r8d
 1f84559:	sete   %cl
 1f8455c:	cmp    %ax,%bp
 1f8455f:	sete   %bl
 1f84562:	and    %cl,%bl
 1f84564:	mov    0x940(%r11),%r13
 1f8456b:	sub    %eax,%ebp
 1f8456d:	cmpq   $0x0,0x168(%r13)
 1f84575:	je     1f83e52 <node_facts_window_run+0x6a82>
 1f8457b:	mov    0xa50(%r11),%rcx
 1f84582:	mov    (%rcx,%r15,4),%edx
 1f84586:	cmp    0x20(%r13),%edx
 1f8458a:	jae    1f83e52 <node_facts_window_run+0x6a82>
 1f84590:	mov    0x188(%r13),%rdi
 1f84597:	movzbl %bl,%esi
 1f8459a:	mov    %ebp,%r9d
 1f8459d:	lea    (%rsi,%rdi,1),%rcx
 1f845a1:	add    %r9,%rcx
 1f845a4:	cmp    0x190(%r13),%rcx
 1f845ab:	ja     1f83e3c <node_facts_window_run+0x6a6c>
 1f845b1:	cmp    $0xfffe,%ebp
 1f845b7:	ja     1f83e3c <node_facts_window_run+0x6a6c>
 1f845bd:	shl    $0x2,%rdi
 1f845c1:	mov    %r8d,0x38(%rsp)
 1f845c6:	mov    %rsi,0x10(%rsp)
 1f845cb:	lea    0x0(,%rax,4),%esi
 1f845d2:	add    0x180(%r13),%rdi
 1f845d9:	add    0xd90(%r11),%rsi
 1f845e0:	mov    %rdx,0x8(%rsp)
 1f845e5:	lea    0x0(,%r9,4),%rdx
 1f845ed:	mov    %rdi,0x20(%rsp)
 1f845f2:	mov    %r9,0x220(%rsp)
 1f845fa:	call   355e930 <memcpy>
 1f845ff:	test   %bl,%bl
 1f84601:	je     1f8465d <node_facts_window_run+0x728d>
 1f84603:	mov    0x38(%rsp),%eax
 1f84607:	mov    0x20(%rsp),%rcx
 1f8460c:	mov    0x220(%rsp),%rdx
 1f84614:	mov    0x8(%rsp),%rsi
 1f84619:	mov    %eax,(%rcx,%rdx,4)
 1f8461c:	jmp    1f84673 <node_facts_window_run+0x72a3>
 1f8461e:	test   %rdx,0x38(%rax,%r8,8)
 1f84623:	mov    $0x3,%eax
 1f84628:	cmovne %rax,%rcx
 1f8462c:	incq   0xbb8(%r13,%rcx,8)
 1f84634:	jmp    1f83e90 <node_facts_window_run+0x6ac0>
 1f84639:	xor    %r8d,%r8d
 1f8463c:	mov    $0x1,%bl
 1f8463e:	xor    %r12d,%r12d
 1f84641:	mov    0x940(%r11),%r13
 1f84648:	sub    %eax,%ebp
 1f8464a:	cmpq   $0x0,0x168(%r13)
 1f84652:	jne    1f8457b <node_facts_window_run+0x71ab>
 1f84658:	jmp    1f83e52 <node_facts_window_run+0x6a82>
 1f8465d:	mov    0x20(%rsp),%rax
 1f84662:	mov    0x8(%rsp),%rsi
 1f84667:	cmp    $0x1,%r12d
 1f8466b:	jne    1f84673 <node_facts_window_run+0x72a3>
 1f8466d:	movl   $0x0,(%rax)
 1f84673:	mov    0x188(%r13),%eax
 1f8467a:	mov    0x168(%r13),%rcx
 1f84681:	mov    0x10(%rsp),%rdi
 1f84686:	mov    (%rsp),%r11
 1f8468a:	mov    $0x1,%edx
 1f8468f:	vpbroadcastq -0x19b6160(%rip),%xmm2        # 5ce538 <.LCPI3_1>
 1f84698:	mov    0x18(%rsp),%r10
 1f8469d:	mov    %eax,(%rcx,%rsi,4)
 1f846a0:	add    %ebp,%edi
 1f846a2:	cmp    $0x3,%r12d
 1f846a6:	mov    0x170(%r13),%rax
 1f846ad:	sete   %cl
 1f846b0:	add    %cl,%cl
 1f846b2:	cmp    $0x2,%r12d
 1f846b6:	movzbl %cl,%ecx
 1f846b9:	cmove  %edx,%ecx
 1f846bc:	mov    %di,(%rax,%rsi,2)
 1f846c0:	mov    0xda0(%r11),%rax
 1f846c7:	mov    0x178(%r13),%rdx
 1f846ce:	xor    (%rax,%r15,1),%cl
 1f846d2:	mov    %cl,(%rdx,%rsi,1)
 1f846d5:	add    %rdi,0x188(%r13)
 1f846dc:	jmp    1f83e43 <node_facts_window_run+0x6a73>
 1f846e1:	mov    0x710(%rsp),%r10
 1f846e9:	shlq   $0x20,0x260(%rsp)
 1f846f2:	shlq   $0x20,0x2e0(%rsp)
 1f846fb:	shlq   $0x20,0x160(%rsp)
 1f84704:	shlq   $0x20,0x390(%rsp)
 1f8470d:	shlq   $0x20,0x350(%rsp)
 1f84716:	shlq   $0x20,0x2a0(%rsp)
 1f8471f:	shlq   $0x20,0x450(%rsp)
 1f84728:	shlq   $0x20,0x6b0(%rsp)
 1f84731:	shlq   $0x20,0x720(%rsp)
 1f8473a:	shlq   $0x20,0x48(%rsp)
 1f84740:	shlq   $0x20,0x88(%rsp)
 1f84749:	shlq   $0x20,0x90(%rsp)
 1f84752:	shlq   $0x20,0xf0(%rsp)
 1f8475b:	shlq   $0x20,0xe8(%rsp)
 1f84764:	shlq   $0x20,0x78(%rsp)
 1f8476a:	mov    $0x1,%ebx
 1f8476f:	vmovd  0x338(%rsp),%xmm1
 1f84778:	mov    0x700(%rsp),%rbp
 1f84780:	mov    0x15c(%rsp),%eax
 1f84787:	shl    $0x20,%r10
 1f8478b:	vmovd  %ebp,%xmm0
 1f8478f:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84793:	vpaddq 0xbe8(%r13),%xmm0,%xmm0
 1f8479c:	vmovdqu %xmm0,0xbe8(%r13)
 1f847a5:	cmp    %eax,0x1a0(%rsp)
 1f847ac:	jne    1f84838 <node_facts_window_run+0x7468>
 1f847b2:	mov    0xca8(%r11),%rsi
 1f847b9:	mov    0xcb8(%r11),%rdi
 1f847c0:	mov    %rbp,%rdx
 1f847c3:	mov    %r10,%r12
 1f847c6:	mov    %r11,%r14
 1f847c9:	call   355e920 <strlen+0x10>
 1f847ce:	mov    0xb8(%rsp),%r15
 1f847d6:	test   %eax,%eax
 1f847d8:	jne    1f847f8 <node_facts_window_run+0x7428>
 1f847da:	mov    0xcb0(%r14),%rsi
 1f847e1:	mov    0xcc0(%r14),%rdi
 1f847e8:	mov    %rbp,%rdx
 1f847eb:	call   355e920 <strlen+0x10>
 1f847f0:	test   %eax,%eax
 1f847f2:	je     1f84d09 <node_facts_window_run+0x7939>
 1f847f8:	mov    %r14,%r11
 1f847fb:	mov    0xe0(%rsp),%rcx
 1f84803:	mov    0x5f0(%rsp),%rdx
 1f8480b:	mov    0x100(%rsp),%rsi
 1f84813:	mov    0x5b0(%rsp),%rdi
 1f8481b:	mov    0x120(%rsp),%r8
 1f84823:	mov    0x670(%rsp),%r9
 1f8482b:	mov    0xd8(%rsp),%rax
 1f84833:	mov    %r12,%r10
 1f84836:	jmp    1f84878 <node_facts_window_run+0x74a8>
 1f84838:	mov    0xb8(%rsp),%r15
 1f84840:	mov    0xe0(%rsp),%rcx
 1f84848:	mov    0x5f0(%rsp),%rdx
 1f84850:	mov    0x100(%rsp),%rsi
 1f84858:	mov    0x5b0(%rsp),%rdi
 1f84860:	mov    0x120(%rsp),%r8
 1f84868:	mov    0x670(%rsp),%r9
 1f84870:	mov    0xd8(%rsp),%rax
 1f84878:	mov    0x6b0(%rsp),%r14
 1f84880:	or     %r10,%rcx
 1f84883:	mov    0xb0(%rsp),%r10
 1f8488b:	or     0x260(%rsp),%rdx
 1f84893:	or     0x2e0(%rsp),%rsi
 1f8489b:	or     0x160(%rsp),%r8
 1f848a3:	or     0x390(%rsp),%rdi
 1f848ab:	or     0x350(%rsp),%r9
 1f848b3:	or     0x2a0(%rsp),%rax
 1f848bb:	add    %rbx,0xbf8(%r13)
 1f848c2:	or     0x450(%rsp),%r10
 1f848ca:	or     %r14,0x3d0(%rsp)
 1f848d2:	mov    0x720(%rsp),%r14
 1f848da:	or     %r14,0x410(%rsp)
 1f848e2:	mov    0x48(%rsp),%r14
 1f848e7:	or     %r14,0x4d0(%rsp)
 1f848ef:	mov    0x88(%rsp),%r14
 1f848f7:	or     %r14,0x490(%rsp)
 1f848ff:	mov    0x90(%rsp),%r14
 1f84907:	or     %r14,0x630(%rsp)
 1f8490f:	mov    0xf0(%rsp),%r14
 1f84917:	or     %r14,0x570(%rsp)
 1f8491f:	mov    0xe8(%rsp),%r14
 1f84927:	or     %r14,0x530(%rsp)
 1f8492f:	mov    0x78(%rsp),%r14
 1f84934:	or     %r14,0x98(%rsp)
 1f8493c:	cmpb   $0x1,0xd58(%r11)
 1f84944:	jne    1f84a2f <node_facts_window_run+0x765f>
 1f8494a:	mov    0x154(%rsp),%ebp
 1f84951:	mov    $0x1,%ebx
 1f84956:	xor    0x158(%rsp),%ebp
 1f8495d:	cmp    0x140(%rsp),%ebp
 1f84964:	jne    1f84a36 <node_facts_window_run+0x7666>
 1f8496a:	mov    0xcc(%rsp),%r14d
 1f84972:	mov    %rax,%rbp
 1f84975:	cmp    0x144(%rsp),%r14d
 1f8497d:	jne    1f84a33 <node_facts_window_run+0x7663>
 1f84983:	mov    0xd0(%rsp),%eax
 1f8498a:	cmp    0x148(%rsp),%eax
 1f84991:	jne    1f84a33 <node_facts_window_run+0x7663>
 1f84997:	mov    %r10,0xb0(%rsp)
 1f8499f:	mov    %r9,0x670(%rsp)
 1f849a7:	mov    %r8,0x120(%rsp)
 1f849af:	mov    %rdi,0x5b0(%rsp)
 1f849b7:	mov    %rsi,0x100(%rsp)
 1f849bf:	mov    %rdx,0x5f0(%rsp)
 1f849c7:	mov    0xd98(%r11),%rsi
 1f849ce:	mov    0xda8(%r11),%rdi
 1f849d5:	mov    %rcx,%r12
 1f849d8:	mov    %r11,%r14
 1f849db:	mov    0x338(%rsp),%rax
 1f849e3:	lea    (%rax,%rax,1),%rdx
 1f849e7:	call   355e920 <strlen+0x10>
 1f849ec:	test   %eax,%eax
 1f849ee:	je     1f84df3 <node_facts_window_run+0x7a23>
 1f849f4:	mov    0x5f0(%rsp),%rdx
 1f849fc:	mov    0x100(%rsp),%rsi
 1f84a04:	mov    0x5b0(%rsp),%rdi
 1f84a0c:	mov    0x120(%rsp),%r8
 1f84a14:	mov    0x670(%rsp),%r9
 1f84a1c:	mov    0xb0(%rsp),%r10
 1f84a24:	mov    %r14,%r11
 1f84a27:	mov    %r12,%rcx
 1f84a2a:	mov    %rbp,%rax
 1f84a2d:	jmp    1f84a36 <node_facts_window_run+0x7666>
 1f84a2f:	xor    %ebx,%ebx
 1f84a31:	jmp    1f84a36 <node_facts_window_run+0x7666>
 1f84a33:	mov    %rbp,%rax
 1f84a36:	vmovd  0x320(%rsp),%xmm1
 1f84a3f:	sub    %rax,%r10
 1f84a42:	vmovd  %ebx,%xmm2
 1f84a46:	mov    0x98(%rsp),%rbx
 1f84a4e:	vpmovzxdq 0x800(%rsp),%ymm7
 1f84a58:	vmovq  %rdx,%xmm3
 1f84a5d:	vmovq  %r8,%xmm4
 1f84a62:	vpbroadcastq %rdi,%ymm6
 1f84a68:	vmovq  %rcx,%xmm5
 1f84a6d:	mov    0x570(%rsp),%rdx
 1f84a75:	mov    0x630(%rsp),%rcx
 1f84a7d:	sub    %r9,%rax
 1f84a80:	sub    %rdi,%r9
 1f84a83:	vmovq  %r10,%xmm0
 1f84a88:	mov    0x530(%rsp),%r10
 1f84a90:	sub    %r10,%rbx
 1f84a93:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84a97:	vmovd  0xd0(%rsp),%xmm1
 1f84aa0:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f84aa4:	vmovq  %rsi,%xmm2
 1f84aa9:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f84aaf:	vpaddq 0xd08(%r13),%ymm0,%ymm0
 1f84ab8:	vmovd  0x330(%rsp),%xmm1
 1f84ac1:	vmovdqu %ymm0,0xd08(%r13)
 1f84aca:	add    %rbx,0xd28(%r13)
 1f84ad1:	vmovq  0x328(%rsp),%xmm0
 1f84ada:	vpaddq 0xc90(%r13),%ymm7,%ymm7
 1f84ae3:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84ae7:	vmovdqu %ymm7,0xc90(%r13)
 1f84af0:	vpaddq 0xcb0(%r13),%xmm0,%xmm0
 1f84af9:	vmovdqu %xmm0,0xcb0(%r13)
 1f84b02:	vpunpcklqdq %xmm2,%xmm3,%xmm0
 1f84b06:	vmovq  0x490(%rsp),%xmm2
 1f84b0f:	vmovq  0x4d0(%rsp),%xmm3
 1f84b18:	vinserti128 $0x1,%xmm4,%ymm0,%ymm0
 1f84b1e:	vpbroadcastq %rcx,%ymm4
 1f84b24:	vpblendd $0xc0,%ymm6,%ymm0,%ymm1
 1f84b2a:	vpermq $0x90,%ymm0,%ymm0
 1f84b30:	vpbroadcastq %rdx,%ymm6
 1f84b36:	vpblendd $0x3,%ymm5,%ymm0,%ymm0
 1f84b3c:	vpbroadcastq %r10,%ymm5
 1f84b42:	vpsubq %ymm0,%ymm1,%ymm0
 1f84b46:	vmovdqu 0x890(%rsp),%ymm1
 1f84b4f:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f84b53:	vpblendd $0x30,%ymm4,%ymm2,%ymm3
 1f84b59:	vpermq $0xd0,%ymm2,%ymm2
 1f84b5f:	vmovdqa64 -0x1acde69(%rip),%zmm4        # 4b6d00 <abi_test_hex.digits+0xb980>
 1f84b69:	vpblendd $0xc0,%ymm5,%ymm3,%ymm3
 1f84b6f:	vpmovzxdq 0x830(%rsp),%zmm5
 1f84b7a:	vinserti64x4 $0x1,%ymm0,%zmm1,%zmm0
 1f84b81:	vpaddq 0xc00(%r13),%zmm0,%zmm0
 1f84b88:	vmovq  %r9,%xmm1
 1f84b8d:	vmovdqu64 %zmm0,0xc00(%r13)
 1f84b94:	add    %rax,0xc40(%r13)
 1f84b9b:	mov    %rdx,%rax
 1f84b9e:	sub    %rcx,%rax
 1f84ba1:	vmovq  %rax,%xmm0
 1f84ba6:	mov    0x410(%rsp),%rax
 1f84bae:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84bb2:	vpmovzxdq 0xc8(%rsp),%xmm1
 1f84bbc:	vmovq  %rax,%xmm7
 1f84bc1:	sub    0x3d0(%rsp),%rax
 1f84bc9:	vpblendd $0x3,%ymm7,%ymm2,%ymm2
 1f84bcf:	vpblendd $0xc0,%ymm6,%ymm2,%ymm2
 1f84bd5:	vmovdqa64 -0x1acdf1f(%rip),%zmm6        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f84bdf:	vpsubq %ymm2,%ymm3,%ymm2
 1f84be3:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f84be9:	vpaddq 0xcc8(%r13),%ymm0,%ymm0
 1f84bf2:	vmovq  %rax,%xmm8
 1f84bf7:	mov    $0x80,%al
 1f84bf9:	kmovd  %eax,%k1
 1f84bfd:	mov    0x708(%rsp),%rax
 1f84c05:	vpermi2q %zmm8,%zmm2,%zmm6
 1f84c0b:	vmovdqu %ymm0,0xcc8(%r13)
 1f84c14:	vpermi2q %zmm5,%zmm6,%zmm4
 1f84c1a:	vpbroadcastq %rax,%zmm4{%k1}
 1f84c20:	vpaddq 0xc50(%r13),%zmm4,%zmm0
 1f84c2a:	vmovdqu64 %zmm0,0xc50(%r13)
 1f84c34:	vmovups 0x9d0(%r11),%zmm0
 1f84c3e:	vmovups 0x268(%r11),%zmm1
 1f84c48:	vmovups 0x850(%rsp),%zmm3
 1f84c53:	vmovaps 0x820(%rsp),%xmm2
 1f84c5c:	xor    %esi,%esi
 1f84c5e:	mov    %r15,%rdx
 1f84c61:	vmovups %zmm0,0x268(%r11)
 1f84c6b:	vmovups %zmm1,0x9d0(%r11)
 1f84c75:	vmovups 0xa10(%r11),%xmm0
 1f84c7e:	vmovups 0x2a8(%r11),%xmm1
 1f84c87:	vmovups %xmm0,0x2a8(%r11)
 1f84c90:	vmovups %xmm1,0xa10(%r11)
 1f84c99:	vmovaps 0x810(%rsp),%xmm1
 1f84ca2:	mov    0x2b8(%r11),%rax
 1f84ca9:	mov    0xa20(%r11),%rcx
 1f84cb0:	mov    %rcx,0x2b8(%r11)
 1f84cb7:	mov    %rax,0xa20(%r11)
 1f84cbe:	mov    0x718(%rsp),%rax
 1f84cc6:	vmovups %zmm3,0x1f0(%r11)
 1f84cd0:	mov    %rax,0x230(%r11)
 1f84cd7:	vmovups %xmm2,0x240(%r11)
 1f84ce0:	vmovlps %xmm1,0x258(%r11)
 1f84ce9:	mov    0x9b8(%r11),%rdi
 1f84cf0:	add    $0xca8,%rsp
 1f84cf7:	pop    %rbx
 1f84cf8:	pop    %r12
 1f84cfa:	pop    %r13
 1f84cfc:	pop    %r14
 1f84cfe:	pop    %r15
 1f84d00:	pop    %rbp
 1f84d01:	vzeroupper
 1f84d04:	jmp    355e9a0 <memset>
 1f84d09:	mov    0xcc8(%r14),%rsi
 1f84d10:	mov    0xcd0(%r14),%rdi
 1f84d17:	mov    0x6f8(%rsp),%rdx
 1f84d1f:	call   355e920 <strlen+0x10>
 1f84d24:	test   %eax,%eax
 1f84d26:	jne    1f84eb3 <node_facts_window_run+0x7ae3>
 1f84d2c:	movzbl 0x5f(%rsp),%ecx
 1f84d31:	xor    %eax,%eax
 1f84d33:	mov    0x5f0(%rsp),%rdx
 1f84d3b:	mov    0x100(%rsp),%rsi
 1f84d43:	mov    0x5b0(%rsp),%rdi
 1f84d4b:	mov    0x120(%rsp),%r8
 1f84d53:	mov    0x670(%rsp),%r9
 1f84d5b:	mov    %r12,%r10
 1f84d5e:	mov    %cl,%al
 1f84d60:	xor    0x330(%rsp),%eax
 1f84d67:	mov    0xe0(%rsp),%rcx
 1f84d6f:	cmp    0xf8(%rsp),%eax
 1f84d76:	mov    0xd8(%rsp),%rax
 1f84d7e:	jne    1f84ebc <node_facts_window_run+0x7aec>
 1f84d84:	movzbl 0x5e(%rsp),%ebp
 1f84d89:	xor    %r11d,%r11d
 1f84d8c:	mov    %bpl,%r11b
 1f84d8f:	xor    0x328(%rsp),%r11
 1f84d97:	cmp    0x340(%rsp),%r11
 1f84d9f:	mov    (%rsp),%r11
 1f84da3:	jne    1f84878 <node_facts_window_run+0x74a8>
 1f84da9:	vmovdqu 0x78c(%rsp),%xmm1
 1f84db2:	vmovdqa 0x780(%rsp),%xmm0
 1f84dbb:	vpxor  0x760(%rsp),%xmm0,%xmm0
 1f84dc4:	vpternlogq $0xf6,0x76c(%rsp),%xmm1,%xmm0
 1f84dd0:	vptest %xmm0,%xmm0
 1f84dd5:	jne    1f84878 <node_facts_window_run+0x74a8>
 1f84ddb:	mov    0x150(%rsp),%ebp
 1f84de2:	xor    %ebx,%ebx
 1f84de4:	cmp    %ebp,0x320(%rsp)
 1f84deb:	setne  %bl
 1f84dee:	jmp    1f84878 <node_facts_window_run+0x74a8>
 1f84df3:	mov    0xda0(%r14),%rsi
 1f84dfa:	mov    0xdb0(%r14),%rdi
 1f84e01:	mov    0x6f0(%rsp),%rdx
 1f84e09:	call   355e920 <strlen+0x10>
 1f84e0e:	mov    0x5f0(%rsp),%rdx
 1f84e16:	mov    0x100(%rsp),%rsi
 1f84e1e:	mov    0x5b0(%rsp),%rdi
 1f84e26:	mov    0x120(%rsp),%r8
 1f84e2e:	mov    0x670(%rsp),%r9
 1f84e36:	mov    0xb0(%rsp),%r10
 1f84e3e:	mov    %r14,%r11
 1f84e41:	mov    %r12,%rcx
 1f84e44:	test   %eax,%eax
 1f84e46:	mov    %rbp,%rax
 1f84e49:	jne    1f84a36 <node_facts_window_run+0x7666>
 1f84e4f:	mov    0xc8(%rsp),%edx
 1f84e56:	mov    0xd90(%r11),%rsi
 1f84e5d:	mov    0xdb8(%r11),%rdi
 1f84e64:	shl    $0x2,%rdx
 1f84e68:	call   355e920 <strlen+0x10>
 1f84e6d:	mov    0xb0(%rsp),%r10
 1f84e75:	mov    0x670(%rsp),%r9
 1f84e7d:	mov    0x120(%rsp),%r8
 1f84e85:	mov    0x5b0(%rsp),%rdi
 1f84e8d:	mov    0x100(%rsp),%rsi
 1f84e95:	mov    0x5f0(%rsp),%rdx
 1f84e9d:	mov    (%rsp),%r11
 1f84ea1:	xor    %ebx,%ebx
 1f84ea3:	test   %eax,%eax
 1f84ea5:	mov    %r12,%rcx
 1f84ea8:	mov    %rbp,%rax
 1f84eab:	setne  %bl
 1f84eae:	jmp    1f84a36 <node_facts_window_run+0x7666>
 1f84eb3:	mov    (%rsp),%r11
 1f84eb7:	jmp    1f847fb <node_facts_window_run+0x742b>
 1f84ebc:	mov    (%rsp),%r11
 1f84ec0:	jmp    1f84878 <node_facts_window_run+0x74a8>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
