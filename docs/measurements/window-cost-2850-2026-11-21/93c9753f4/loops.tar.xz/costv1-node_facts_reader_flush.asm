
results/costv1/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f76ef0 <node_facts_reader_flush>:
 1f76ef0:	push   %rbp
 1f76ef1:	push   %r15
 1f76ef3:	push   %r14
 1f76ef5:	push   %r13
 1f76ef7:	push   %r12
 1f76ef9:	push   %rbx
 1f76efa:	sub    $0x58,%rsp
 1f76efe:	mov    0x940(%rdi),%r12
 1f76f05:	cmpl   $0x0,0x250(%rdi)
 1f76f0c:	mov    %rsi,%r15
 1f76f0f:	mov    %rdi,%r14
 1f76f12:	je     1f7704d <node_facts_reader_flush+0x15d>
 1f76f18:	cmpb   $0x0,0x93f(%r14)
 1f76f20:	je     1f7705b <node_facts_reader_flush+0x16b>
 1f76f26:	mov    0x25c(%r14),%ebx
 1f76f2d:	inc    %ebx
 1f76f2f:	je     1f7895d <node_facts_reader_flush+0x1a6d>
 1f76f35:	mov    (%r14),%rax
 1f76f38:	xor    %ebp,%ebp
 1f76f3a:	mov    %r15,0x48(%rsp)
 1f76f3f:	mov    %r12,0x20(%rsp)
 1f76f44:	mov    %rax,0x40(%rsp)
 1f76f49:	nopl   0x0(%rax)
 1f76f50:	mov    %r14,%rdi
 1f76f53:	mov    %ebp,%esi
 1f76f55:	xor    %edx,%edx
 1f76f57:	call   1f7bb10 <node_facts_given>
 1f76f5c:	rdtsc
 1f76f5e:	mov    %r14,%rdi
 1f76f61:	mov    %ebp,%esi
 1f76f63:	xor    %ecx,%ecx
 1f76f65:	mov    %rdx,%r12
 1f76f68:	shl    $0x20,%r12
 1f76f6c:	xor    %edx,%edx
 1f76f6e:	or     %rax,%r12
 1f76f71:	call   1f7bd00 <node_facts_window>
 1f76f76:	rdtsc
 1f76f78:	inc    %ebp
 1f76f7a:	shl    $0x20,%rdx
 1f76f7e:	or     %rax,%rdx
 1f76f81:	sub    %r12,%rdx
 1f76f84:	mov    0x20(%rsp),%r12
 1f76f89:	add    %rdx,0x910(%r12)
 1f76f91:	cmp    %ebp,%ebx
 1f76f93:	jne    1f76f50 <node_facts_reader_flush+0x60>
 1f76f95:	rdtsc
 1f76f97:	xor    %r15d,%r15d
 1f76f9a:	mov    %rdx,%r13
 1f76f9d:	shl    $0x20,%r13
 1f76fa1:	or     %rax,%r13
 1f76fa4:	mov    0xa90(%r14),%eax
 1f76fab:	test   %eax,%eax
 1f76fad:	je     1f7709d <node_facts_reader_flush+0x1ad>
 1f76fb3:	xor    %r12d,%r12d
 1f76fb6:	xor    %ebp,%ebp
 1f76fb8:	jmp    1f76fde <node_facts_reader_flush+0xee>
 1f76fba:	nopw   0x0(%rax,%rax,1)
 1f76fc0:	add    %ecx,%r15d
 1f76fc3:	cmp    $0x1,%eax
 1f76fc6:	mov    0xa90(%r14),%eax
 1f76fcd:	sbb    $0xffffffff,%ebp
 1f76fd0:	inc    %r12
 1f76fd3:	mov    %eax,%ecx
 1f76fd5:	cmp    %rcx,%r12
 1f76fd8:	jae    1f77090 <node_facts_reader_flush+0x1a0>
 1f76fde:	mov    0xa80(%r14),%rcx
 1f76fe5:	cmpb   $0x0,(%rcx,%r12,1)
 1f76fea:	je     1f76fd0 <node_facts_reader_flush+0xe0>
 1f76fec:	mov    0xa78(%r14),%rax
 1f76ff3:	mov    %r14,%rdi
 1f76ff6:	mov    (%rax,%r12,4),%eax
 1f76ffa:	mov    %eax,0x9a8(%r14)
 1f77001:	mov    0xa60(%r14),%rcx
 1f77008:	mov    0xa58(%r14),%rax
 1f7700f:	mov    0xa68(%r14),%rsi
 1f77016:	mov    (%rcx,%r12,4),%edx
 1f7701a:	mov    (%rax,%r12,4),%ecx
 1f7701e:	mov    0xa70(%r14),%rax
 1f77025:	mov    (%rsi,%r12,4),%r8d
 1f77029:	mov    0x48(%rsp),%rsi
 1f7702e:	mov    (%rax,%r12,4),%r9d
 1f77032:	call   1f78ab0 <node_facts_front_expression>
 1f77037:	xor    %ecx,%ecx
 1f77039:	test   %eax,%eax
 1f7703b:	jne    1f76fc0 <node_facts_reader_flush+0xd0>
 1f7703d:	mov    0xa58(%r14),%rcx
 1f77044:	mov    (%rcx,%r12,4),%ecx
 1f77048:	jmp    1f76fc0 <node_facts_reader_flush+0xd0>
 1f7704d:	cmpb   $0x0,0x93f(%r14)
 1f77055:	jne    1f7895d <node_facts_reader_flush+0x1a6d>
 1f7705b:	incq   0x908(%r12)
 1f77063:	movb   $0x1,0x93f(%r14)
 1f7706b:	cmpb   $0x1,0x9b0(%r14)
 1f77073:	jne    1f7895d <node_facts_reader_flush+0x1a6d>
 1f77079:	mov    0x9b8(%r14),%rdi
 1f77080:	mov    0x8(%r15),%edx
 1f77084:	xor    %esi,%esi
 1f77086:	call   355e9a0 <memset>
 1f7708b:	jmp    1f7895d <node_facts_reader_flush+0x1a6d>
 1f77090:	mov    0x20(%rsp),%r12
 1f77095:	mov    %r15d,%ecx
 1f77098:	mov    %ebp,%r15d
 1f7709b:	jmp    1f7709f <node_facts_reader_flush+0x1af>
 1f7709d:	xor    %ecx,%ecx
 1f7709f:	rdtsc
 1f770a1:	vmovd  %ecx,%xmm1
 1f770a5:	shl    $0x20,%rdx
 1f770a9:	or     %rax,%rdx
 1f770ac:	sub    %r13,%rdx
 1f770af:	vmovq  %rdx,%xmm0
 1f770b4:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f770b8:	vpaddq 0x9c0(%r12),%xmm0,%xmm0
 1f770c2:	vmovdqu %xmm0,0x9c0(%r12)
 1f770cc:	add    %r15,0x908(%r12)
 1f770d4:	mov    0x258(%r14),%edx
 1f770db:	mov    %edx,0x9a8(%r14)
 1f770e2:	mov    %edx,%eax
 1f770e4:	mov    0xa90(%r14),%ecx
 1f770eb:	test   %ecx,%ecx
 1f770ed:	je     1f7737e <node_facts_reader_flush+0x48e>
 1f770f3:	mov    0xa80(%r14),%rdx
 1f770fa:	xor    %eax,%eax
 1f770fc:	jmp    1f77115 <node_facts_reader_flush+0x225>
 1f770fe:	xchg   %ax,%ax
 1f77100:	mov    0xa90(%r14),%ecx
 1f77107:	inc    %rax
 1f7710a:	mov    %ecx,%esi
 1f7710c:	cmp    %rsi,%rax
 1f7710f:	jae    1f77370 <node_facts_reader_flush+0x480>
 1f77115:	cmpb   $0x0,(%rdx,%rax,1)
 1f77119:	je     1f77107 <node_facts_reader_flush+0x217>
 1f7711b:	mov    0xa58(%r14),%rcx
 1f77122:	cmpl   $0x0,(%rcx,%rax,4)
 1f77126:	je     1f77100 <node_facts_reader_flush+0x210>
 1f77128:	xor    %ecx,%ecx
 1f7712a:	nopw   0x0(%rax,%rax,1)
 1f77130:	mov    0xa60(%r14),%rdx
 1f77137:	mov    0x958(%r14),%rsi
 1f7713e:	mov    0x1f0(%r14),%rdi
 1f77145:	mov    (%rdx,%rax,4),%edx
 1f77148:	add    %ecx,%edx
 1f7714a:	movzbl (%rsi,%rdx,1),%esi
 1f7714e:	cmp    (%rdi,%rdx,1),%sil
 1f77152:	jne    1f772d0 <node_facts_reader_flush+0x3e0>
 1f77158:	mov    0x1f8(%r14),%rdi
 1f7715f:	mov    0x960(%r14),%r9
 1f77166:	movzbl (%rdi,%rdx,1),%r8d
 1f7716b:	cmp    %r8b,(%r9,%rdx,1)
 1f7716f:	jne    1f772d0 <node_facts_reader_flush+0x3e0>
 1f77175:	mov    0x968(%r14),%rdi
 1f7717c:	mov    0x200(%r14),%r9
 1f77183:	movzbl (%rdi,%rdx,1),%edi
 1f77187:	cmp    (%r9,%rdx,1),%dil
 1f7718b:	jne    1f772d0 <node_facts_reader_flush+0x3e0>
 1f77191:	mov    0x978(%r14),%rdi
 1f77198:	mov    0x210(%r14),%r9
 1f7719f:	movzwl (%rdi,%rdx,2),%edi
 1f771a3:	cmp    (%r9,%rdx,2),%di
 1f771a8:	jne    1f772d0 <node_facts_reader_flush+0x3e0>
 1f771ae:	mov    0x980(%r14),%rdi
 1f771b5:	mov    0x218(%r14),%r9
 1f771bc:	movzwl (%rdi,%rdx,2),%edi
 1f771c0:	cmp    (%r9,%rdx,2),%di
 1f771c5:	jne    1f772d0 <node_facts_reader_flush+0x3e0>
 1f771cb:	mov    0x990(%r14),%rdi
 1f771d2:	mov    0x228(%r14),%r9
 1f771d9:	movzwl (%rdi,%rdx,2),%edi
 1f771dd:	cmp    (%r9,%rdx,2),%di
 1f771e2:	jne    1f772d0 <node_facts_reader_flush+0x3e0>
 1f771e8:	mov    0x998(%r14),%r9
 1f771ef:	mov    0x230(%r14),%r10
 1f771f6:	mov    (%r9,%rdx,4),%r9d
 1f771fa:	mov    (%r10,%rdx,4),%r10d
 1f771fe:	cmp    %r10d,%r9d
 1f77201:	jne    1f77254 <node_facts_reader_flush+0x364>
 1f77203:	mov    %r8d,%r11d
 1f77206:	and    $0xfb,%r11b
 1f7720a:	cmp    $0x2,%r11b
 1f7720e:	jne    1f77254 <node_facts_reader_flush+0x364>
 1f77210:	mov    0x988(%r14),%rsi
 1f77217:	mov    0x220(%r14),%rdi
 1f7721e:	mov    (%rsi,%rdx,4),%esi
 1f77221:	mov    (%rdi,%rdx,4),%edi
 1f77224:	cmp    %edi,%esi
 1f77226:	je     1f77348 <node_facts_reader_flush+0x458>
 1f7722c:	mov    0x28(%r14),%r8
 1f77230:	shl    $0x5,%rsi
 1f77234:	shl    $0x5,%rdi
 1f77238:	vmovdqu (%r8,%rsi,1),%ymm0
 1f7723e:	vpxor  (%r8,%rdi,1),%ymm0,%ymm0
 1f77244:	vptest %ymm0,%ymm0
 1f77249:	jne    1f772d0 <node_facts_reader_flush+0x3e0>
 1f7724f:	jmp    1f77348 <node_facts_reader_flush+0x458>
 1f77254:	cmp    %r10d,%r9d
 1f77257:	sete   %r11b
 1f7725b:	cmp    $0x1,%r8b
 1f7725f:	setne  %r8b
 1f77263:	and    %r11b,%r8b
 1f77266:	cmp    $0x1,%r8b
 1f7726a:	jne    1f772c9 <node_facts_reader_flush+0x3d9>
 1f7726c:	mov    0x988(%r14),%r8
 1f77273:	mov    0x220(%r14),%r9
 1f7727a:	mov    (%r8,%rdx,4),%r8d
 1f7727e:	cmp    (%r9,%rdx,4),%r8d
 1f77282:	jne    1f772d0 <node_facts_reader_flush+0x3e0>
 1f77284:	cmp    $0x22,%sil
 1f77288:	jne    1f77348 <node_facts_reader_flush+0x458>
 1f7728e:	test   %rdi,%rdi
 1f77291:	je     1f77348 <node_facts_reader_flush+0x458>
 1f77297:	mov    0x9a0(%r14),%rsi
 1f7729e:	mov    0x240(%r14),%r9
 1f772a5:	data16 cs nopw 0x0(%rax,%rax,1)
 1f772b0:	mov    %r8d,%r10d
 1f772b3:	movzwl (%rsi,%r10,2),%r11d
 1f772b8:	cmp    (%r9,%r10,2),%r11w
 1f772bd:	jne    1f772d0 <node_facts_reader_flush+0x3e0>
 1f772bf:	inc    %r8d
 1f772c2:	dec    %rdi
 1f772c5:	jne    1f772b0 <node_facts_reader_flush+0x3c0>
 1f772c7:	jmp    1f77348 <node_facts_reader_flush+0x458>
 1f772c9:	cmp    %r10d,%r9d
 1f772cc:	je     1f77348 <node_facts_reader_flush+0x458>
 1f772ce:	xchg   %ax,%ax
 1f772d0:	incq   0x9a8(%r12)
 1f772d8:	mov    (%r14),%rsi
 1f772db:	mov    0x238(%r14),%rdi
 1f772e2:	mov    (%rdi,%rdx,4),%r8d
 1f772e6:	mov    0x10(%rsi),%rsi
 1f772ea:	mov    $0xffffffff,%edi
 1f772ef:	cmp    0xec(%rsi),%r8d
 1f772f6:	jae    1f77300 <node_facts_reader_flush+0x410>
 1f772f8:	mov    0x28(%rsi),%rsi
 1f772fc:	mov    (%rsi,%r8,4),%edi
 1f77300:	mov    0x940(%r14),%rsi
 1f77307:	mov    0x11e0(%rsi),%r8d
 1f7730e:	cmp    $0xf,%r8
 1f77312:	ja     1f77348 <node_facts_reader_flush+0x458>
 1f77314:	mov    %edi,0x1180(%rsi,%r8,4)
 1f7731c:	mov    0x1f0(%r14),%rdi
 1f77323:	movzbl (%rdi,%rdx,1),%edx
 1f77327:	mov    0x11e0(%rsi),%edi
 1f7732d:	mov    %dl,0x11c0(%rsi,%rdi,1)
 1f77334:	mov    0x11e0(%rsi),%edx
 1f7733a:	movb   $0x3,0x11d0(%rsi,%rdx,1)
 1f77342:	incl   0x11e0(%rsi)
 1f77348:	mov    0xa80(%r14),%rdx
 1f7734f:	cmpb   $0x0,(%rdx,%rax,1)
 1f77353:	je     1f77100 <node_facts_reader_flush+0x210>
 1f77359:	mov    0xa58(%r14),%rsi
 1f77360:	inc    %ecx
 1f77362:	cmp    (%rsi,%rax,4),%ecx
 1f77365:	jb     1f77130 <node_facts_reader_flush+0x240>
 1f7736b:	jmp    1f77100 <node_facts_reader_flush+0x210>
 1f77370:	mov    0x258(%r14),%eax
 1f77377:	mov    0x9a8(%r14),%edx
 1f7737e:	mov    0x998(%r14),%rdi
 1f77385:	mov    0x230(%r14),%rcx
 1f7738c:	mov    0x240(%r14),%rsi
 1f77393:	vmovdqu64 0x958(%r14),%zmm0
 1f7739d:	mov    %rdi,0x230(%r14)
 1f773a4:	mov    0x9a0(%r14),%rdi
 1f773ab:	mov    %rdi,0x240(%r14)
 1f773b2:	mov    %edx,0x258(%r14)
 1f773b9:	vmovdqu64 0x1f0(%r14),%zmm1
 1f773c3:	vmovdqu64 %zmm0,0x1f0(%r14)
 1f773cd:	vmovdqu64 %zmm1,0x958(%r14)
 1f773d7:	mov    %rcx,0x998(%r14)
 1f773de:	mov    %rsi,0x9a0(%r14)
 1f773e5:	mov    %eax,0x9a8(%r14)
 1f773ec:	mov    %ebx,%eax
 1f773ee:	xor    %ebx,%ebx
 1f773f0:	movl   $0x0,0x9ac(%r14)
 1f773fb:	mov    %rax,0x28(%rsp)
 1f77400:	jmp    1f77423 <node_facts_reader_flush+0x533>
 1f77402:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f77410:	mov    0x38(%rsp),%rbx
 1f77415:	inc    %rbx
 1f77418:	cmp    0x28(%rsp),%rbx
 1f7741d:	je     1f77b13 <node_facts_reader_flush+0xc23>
 1f77423:	mov    0x248(%r14),%rax
 1f7742a:	mov    $0x1,%edx
 1f7742f:	mov    %r14,%rdi
 1f77432:	mov    %ebx,%esi
 1f77434:	mov    (%rax,%rbx,4),%r13d
 1f77438:	mov    0x4(%rax,%rbx,4),%ebp
 1f7743c:	vzeroupper
 1f7743f:	call   1f7bb10 <node_facts_given>
 1f77444:	mov    %r14,%rdi
 1f77447:	mov    %ebx,%esi
 1f77449:	xor    %edx,%edx
 1f7744b:	xor    %ecx,%ecx
 1f7744d:	call   1f7bd00 <node_facts_window>
 1f77452:	mov    %r14,%rdi
 1f77455:	mov    %ebx,%esi
 1f77457:	mov    %rbx,0x38(%rsp)
 1f7745c:	call   1f7c950 <node_facts_lists_same>
 1f77461:	test   %al,%al
 1f77463:	jne    1f774da <node_facts_reader_flush+0x5ea>
 1f77465:	incq   0x900(%r12)
 1f7746d:	mov    (%r14),%rax
 1f77470:	mov    0x238(%r14),%rcx
 1f77477:	mov    (%rcx,%r13,4),%edx
 1f7747b:	mov    0x10(%rax),%rax
 1f7747f:	mov    $0xffffffff,%ecx
 1f77484:	cmp    0xec(%rax),%edx
 1f7748a:	jae    1f77493 <node_facts_reader_flush+0x5a3>
 1f7748c:	mov    0x28(%rax),%rax
 1f77490:	mov    (%rax,%rdx,4),%ecx
 1f77493:	mov    0x940(%r14),%rax
 1f7749a:	mov    0x11e0(%rax),%edx
 1f774a0:	cmp    $0xf,%rdx
 1f774a4:	ja     1f774da <node_facts_reader_flush+0x5ea>
 1f774a6:	mov    %ecx,0x1180(%rax,%rdx,4)
 1f774ad:	mov    0x1f0(%r14),%rcx
 1f774b4:	mov    0x11e0(%rax),%edx
 1f774ba:	movzbl (%rcx,%r13,1),%ecx
 1f774bf:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f774c6:	mov    0x11e0(%rax),%ecx
 1f774cc:	movb   $0x2,0x11d0(%rax,%rcx,1)
 1f774d4:	incl   0x11e0(%rax)
 1f774da:	vpbroadcastq -0x19a8fbb(%rip),%xmm2        # 5ce528 <.LCPI1286_0>
 1f774e3:	vpbroadcastd -0x19a6598(%rip),%xmm3        # 5d0f54 <.LCPI1286_1>
 1f774ec:	cmp    %r13d,%ebp
 1f774ef:	je     1f77410 <node_facts_reader_flush+0x520>
 1f774f5:	sub    %r13d,%ebp
 1f774f8:	xor    %ecx,%ecx
 1f774fa:	mov    %ebp,%eax
 1f774fc:	mov    %rax,(%rsp)
 1f77500:	jmp    1f7751d <node_facts_reader_flush+0x62d>
 1f77502:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f77510:	inc    %rcx
 1f77513:	cmp    (%rsp),%rcx
 1f77517:	je     1f77410 <node_facts_reader_flush+0x520>
 1f7751d:	mov    0x1f8(%r14),%rsi
 1f77524:	lea    0x0(%r13,%rcx,1),%edx
 1f77529:	mov    0x1f0(%r14),%rax
 1f77530:	mov    %rdx,0x18(%rsp)
 1f77535:	movzbl (%rsi,%rdx,1),%edi
 1f77539:	movzbl (%rax,%rdx,1),%eax
 1f7753d:	cmp    $0x1,%edi
 1f77540:	sete   %sil
 1f77544:	cmp    $0x6,%edi
 1f77547:	sete   %r8b
 1f7754b:	or     %sil,%r8b
 1f7754e:	mov    0xa98(%r14),%rsi
 1f77555:	movzbl %r8b,%r8d
 1f77559:	movzbl (%rsi,%rdx,1),%esi
 1f7755d:	test   %sil,%sil
 1f77560:	setne  %r9b
 1f77564:	add    %r8,0x8c0(%r12)
 1f7756c:	and    %r9b,%r8b
 1f7756f:	vmovd  %r9d,%xmm0
 1f77574:	vpinsrb $0x1,%r8d,%xmm0,%xmm0
 1f7757a:	vpmovzxbq %xmm0,%xmm0
 1f7757f:	vptestmq %xmm2,%xmm0,%k0
 1f77585:	vmovdqu 0x978(%r12),%xmm0
 1f7758f:	vpmovm2q %k0,%xmm1
 1f77595:	vpsubq %xmm1,%xmm0,%xmm0
 1f77599:	vmovdqu %xmm0,0x978(%r12)
 1f775a3:	cmp    $0x7,%edi
 1f775a6:	ja     1f77510 <node_facts_reader_flush+0x620>
 1f775ac:	mov    $0xcc,%r8d
 1f775b2:	bt     %edi,%r8d
 1f775b6:	jae    1f77510 <node_facts_reader_flush+0x620>
 1f775bc:	test   %sil,%sil
 1f775bf:	mov    %edi,%r9d
 1f775c2:	mov    %rcx,%r11
 1f775c5:	setne  %sil
 1f775c9:	cmp    $0x6,%dil
 1f775cd:	sete   %r8b
 1f775d1:	and    $0xfe,%r9b
 1f775d5:	cmp    $0x2,%r9b
 1f775d9:	sete   %r9b
 1f775dd:	cmp    $0x7,%dil
 1f775e1:	mov    0x2c0(%r14),%rdi
 1f775e8:	sete   %bpl
 1f775ec:	shl    $0x6,%r11
 1f775f0:	or     %r9b,%bpl
 1f775f3:	vmovd  %ebp,%xmm0
 1f775f7:	movzbl %bpl,%r10d
 1f775fb:	movzbl 0x19(%rdi,%r11,1),%edi
 1f77601:	dec    %dil
 1f77604:	sete   %r15b
 1f77608:	cmp    $0x2,%dil
 1f7760c:	setb   %r9b
 1f77610:	setae  %dil
 1f77614:	and    %bpl,%r15b
 1f77617:	and    %r10b,%sil
 1f7761a:	and    %r9b,%bpl
 1f7761d:	and    %r10b,%dil
 1f77620:	vpinsrb $0x1,%ebp,%xmm0,%xmm0
 1f77626:	vpinsrb $0x2,%r15d,%xmm0,%xmm0
 1f7762c:	vpinsrb $0x3,%r8d,%xmm0,%xmm0
 1f77632:	and    %r9b,%r8b
 1f77635:	and    %sil,%r9b
 1f77638:	vpmovzxbd %xmm0,%xmm0
 1f7763d:	movzbl %r8b,%r8d
 1f77641:	vptestmd %xmm3,%xmm0,%k0
 1f77647:	vmovdqu 0x8c8(%r12),%ymm0
 1f77651:	vpmovm2q %k0,%ymm1
 1f77657:	vpsubq %ymm1,%ymm0,%ymm0
 1f7765b:	vmovdqu %ymm0,0x8c8(%r12)
 1f77665:	vmovd  %esi,%xmm0
 1f77669:	add    %r8,0x8e8(%r12)
 1f77671:	movzbl %dil,%esi
 1f77675:	lea    (%rcx,%r13,1),%r8
 1f77679:	vpinsrb $0x1,%r9d,%xmm0,%xmm0
 1f7767f:	vpmovzxbq %xmm0,%xmm0
 1f77684:	vptestmq %xmm2,%xmm0,%k0
 1f7768a:	vmovdqu 0x988(%r12),%xmm0
 1f77694:	vpmovm2q %k0,%xmm1
 1f7769a:	vpsubq %xmm1,%xmm0,%xmm0
 1f7769e:	vmovdqu %xmm0,0x988(%r12)
 1f776a8:	add    %r10,0xd30(%r12,%rax,8)
 1f776b0:	add    %rsi,0xf58(%r12,%rax,8)
 1f776b8:	mov    0x288(%r14),%rax
 1f776bf:	movzbl (%rax,%r8,1),%esi
 1f776c4:	mov    %esi,%ebp
 1f776c6:	and    $0x60,%bpl
 1f776ca:	cmp    $0x40,%bpl
 1f776ce:	jne    1f776e0 <node_facts_reader_flush+0x7f0>
 1f776d0:	mov    0x290(%r14),%rax
 1f776d7:	movzwl (%rax,%r8,2),%edx
 1f776dc:	jmp    1f776e2 <node_facts_reader_flush+0x7f2>
 1f776de:	xchg   %ax,%ax
 1f776e0:	xor    %edx,%edx
 1f776e2:	mov    0x2a0(%r14),%rdi
 1f776e9:	mov    0x2c0(%r14),%rax
 1f776f0:	mov    0x268(%r14),%r15
 1f776f7:	mov    (%rdi,%r8,8),%r12d
 1f776fb:	mov    0x4(%rdi,%r8,8),%r10d
 1f77700:	mov    0x2b0(%r14),%rdi
 1f77707:	mov    (%r15,%r8,4),%ebx
 1f7770b:	mov    %rax,0x10(%rsp)
 1f77710:	add    %rax,%r11
 1f77713:	mov    0x2a8(%r14),%rax
 1f7771a:	mov    0x1f0(%r14),%r15
 1f77721:	mov    (%rdi,%r8,8),%rdi
 1f77725:	mov    (%rax,%r8,8),%r9d
 1f77729:	mov    0x4(%rax,%r8,8),%eax
 1f7772e:	mov    %rdi,0x8(%rsp)
 1f77733:	mov    0x18(%rsp),%rdi
 1f77738:	movzbl (%r15,%rdi,1),%r15d
 1f7773d:	cmp    %ebx,(%r11)
 1f77740:	jne    1f777b0 <node_facts_reader_flush+0x8c0>
 1f77742:	mov    0x298(%r14),%rdi
 1f77749:	mov    (%rdi,%r8,4),%edi
 1f7774d:	cmp    %edi,0x4(%r11)
 1f77751:	jne    1f777b0 <node_facts_reader_flush+0x8c0>
 1f77753:	mov    0x270(%r14),%rdi
 1f7775a:	mov    (%rdi,%r8,4),%edi
 1f7775e:	cmp    %edi,0x8(%r11)
 1f77762:	jne    1f777b0 <node_facts_reader_flush+0x8c0>
 1f77764:	mov    0x278(%r14),%rdi
 1f7776b:	mov    (%rdi,%r8,4),%edi
 1f7776f:	cmp    %edi,0xc(%r11)
 1f77773:	jne    1f777bb <node_facts_reader_flush+0x8cb>
 1f77775:	mov    0x280(%r14),%rdi
 1f7777c:	mov    (%rdi,%r8,8),%rdi
 1f77780:	cmp    %rdi,0x10(%r11)
 1f77784:	jne    1f777b0 <node_facts_reader_flush+0x8c0>
 1f77786:	movzbl 0x18(%r11),%edi
 1f7778b:	cmp    %sil,%dil
 1f7778e:	sete   %r8b
 1f77792:	cmp    $0x40,%bpl
 1f77796:	jne    1f777c0 <node_facts_reader_flush+0x8d0>
 1f77798:	cmp    %sil,%dil
 1f7779b:	jne    1f777c0 <node_facts_reader_flush+0x8d0>
 1f7779d:	cmp    %dx,0x1a(%r11)
 1f777a2:	sete   %r8b
 1f777a6:	cmp    %r12d,0x20(%r11)
 1f777aa:	je     1f777c6 <node_facts_reader_flush+0x8d6>
 1f777ac:	jmp    1f777f0 <node_facts_reader_flush+0x900>
 1f777ae:	xchg   %ax,%ax
 1f777b0:	xor    %r8d,%r8d
 1f777b3:	cmp    %r12d,0x20(%r11)
 1f777b7:	je     1f777c6 <node_facts_reader_flush+0x8d6>
 1f777b9:	jmp    1f777f0 <node_facts_reader_flush+0x900>
 1f777bb:	xor    %r8d,%r8d
 1f777be:	xchg   %ax,%ax
 1f777c0:	cmp    %r12d,0x20(%r11)
 1f777c4:	jne    1f777f0 <node_facts_reader_flush+0x900>
 1f777c6:	cmp    %r10d,0x24(%r11)
 1f777ca:	jne    1f777f0 <node_facts_reader_flush+0x900>
 1f777cc:	cmp    %r9d,0x28(%r11)
 1f777d0:	jne    1f777f0 <node_facts_reader_flush+0x900>
 1f777d2:	cmp    %eax,0x2c(%r11)
 1f777d6:	sete   %r9b
 1f777da:	mov    0x30(%r11),%r10
 1f777de:	mov    $0x1,%al
 1f777e0:	cmp    $0x22,%r15b
 1f777e4:	jne    1f77a70 <node_facts_reader_flush+0xb80>
 1f777ea:	jmp    1f77803 <node_facts_reader_flush+0x913>
 1f777ec:	nopl   0x0(%rax)
 1f777f0:	xor    %r9d,%r9d
 1f777f3:	mov    0x30(%r11),%r10
 1f777f7:	mov    $0x1,%al
 1f777f9:	cmp    $0x22,%r15b
 1f777fd:	jne    1f77a70 <node_facts_reader_flush+0xb80>
 1f77803:	cmp    $0x40,%bpl
 1f77807:	je     1f77a70 <node_facts_reader_flush+0xb80>
 1f7780d:	cmpb   $0x0,0x19(%r11)
 1f77812:	je     1f77a70 <node_facts_reader_flush+0xb80>
 1f77818:	testb  $0x2,0x1a(%r11)
 1f7781d:	je     1f77a70 <node_facts_reader_flush+0xb80>
 1f77823:	mov    0x228(%r14),%rsi
 1f7782a:	mov    0x18(%rsp),%rdx
 1f7782f:	movzwl (%rsi,%rdx,2),%r12d
 1f77834:	test   %r12,%r12
 1f77837:	je     1f77a70 <node_facts_reader_flush+0xb80>
 1f7783d:	mov    0x220(%r14),%rax
 1f77844:	mov    0x18(%rsp),%rdx
 1f77849:	mov    0x240(%r14),%r11
 1f77850:	mov    %r12d,%ebp
 1f77853:	and    $0x7,%ebp
 1f77856:	mov    (%rax,%rdx,4),%eax
 1f77859:	mov    %rax,0x30(%rsp)
 1f7785e:	cmp    $0x8,%r12w
 1f77863:	jae    1f77874 <node_facts_reader_flush+0x984>
 1f77865:	mov    0x10(%rsp),%rdx
 1f7786a:	mov    $0x1,%al
 1f7786c:	xor    %r15d,%r15d
 1f7786f:	jmp    1f77a09 <node_facts_reader_flush+0xb19>
 1f77874:	mov    0x10(%rsp),%rdx
 1f77879:	mov    %r11,0x50(%rsp)
 1f7787e:	lea    0xe(%r11,%rax,2),%r11
 1f77883:	and    $0xfffffff8,%r12d
 1f77887:	mov    $0x1,%al
 1f77889:	xor    %r15d,%r15d
 1f7788c:	nopl   0x0(%rax)
 1f77890:	cmp    $0x1,%al
 1f77892:	jne    1f779f0 <node_facts_reader_flush+0xb00>
 1f77898:	movzwl -0xe(%r11,%r15,2),%eax
 1f7789e:	mov    0x2b8(%r14),%rbx
 1f778a5:	mov    %ecx,%esi
 1f778a7:	sub    %eax,%esi
 1f778a9:	mov    %rsi,%rax
 1f778ac:	shl    $0x6,%rax
 1f778b0:	mov    0x38(%rdx,%rax,1),%rdi
 1f778b5:	lea    0x0(,%r13,8),%rax
 1f778bd:	add    %rax,%rbx
 1f778c0:	cmp    (%rbx,%rsi,8),%rdi
 1f778c4:	jne    1f779f0 <node_facts_reader_flush+0xb00>
 1f778ca:	movzwl -0xc(%r11,%r15,2),%esi
 1f778d0:	mov    0x2b8(%r14),%rbx
 1f778d7:	mov    %ecx,%edi
 1f778d9:	sub    %esi,%edi
 1f778db:	add    %rax,%rbx
 1f778de:	mov    %rdi,%rsi
 1f778e1:	shl    $0x6,%rsi
 1f778e5:	mov    0x38(%rdx,%rsi,1),%rsi
 1f778ea:	cmp    (%rbx,%rdi,8),%rsi
 1f778ee:	jne    1f779f0 <node_facts_reader_flush+0xb00>
 1f778f4:	movzwl -0xa(%r11,%r15,2),%esi
 1f778fa:	mov    0x2b8(%r14),%rbx
 1f77901:	mov    %ecx,%edi
 1f77903:	sub    %esi,%edi
 1f77905:	add    %rax,%rbx
 1f77908:	mov    %rdi,%rsi
 1f7790b:	shl    $0x6,%rsi
 1f7790f:	mov    0x38(%rdx,%rsi,1),%rsi
 1f77914:	cmp    (%rbx,%rdi,8),%rsi
 1f77918:	jne    1f779f0 <node_facts_reader_flush+0xb00>
 1f7791e:	movzwl -0x8(%r11,%r15,2),%esi
 1f77924:	mov    0x2b8(%r14),%rbx
 1f7792b:	mov    %ecx,%edi
 1f7792d:	sub    %esi,%edi
 1f7792f:	add    %rax,%rbx
 1f77932:	mov    %rdi,%rsi
 1f77935:	shl    $0x6,%rsi
 1f77939:	mov    0x38(%rdx,%rsi,1),%rsi
 1f7793e:	cmp    (%rbx,%rdi,8),%rsi
 1f77942:	jne    1f779f0 <node_facts_reader_flush+0xb00>
 1f77948:	movzwl -0x6(%r11,%r15,2),%esi
 1f7794e:	mov    0x2b8(%r14),%rbx
 1f77955:	mov    %ecx,%edi
 1f77957:	sub    %esi,%edi
 1f77959:	add    %rax,%rbx
 1f7795c:	mov    %rdi,%rsi
 1f7795f:	shl    $0x6,%rsi
 1f77963:	mov    0x38(%rdx,%rsi,1),%rsi
 1f77968:	cmp    (%rbx,%rdi,8),%rsi
 1f7796c:	jne    1f779f0 <node_facts_reader_flush+0xb00>
 1f77972:	movzwl -0x4(%r11,%r15,2),%esi
 1f77978:	mov    0x2b8(%r14),%rbx
 1f7797f:	mov    %ecx,%edi
 1f77981:	sub    %esi,%edi
 1f77983:	add    %rax,%rbx
 1f77986:	mov    %rdi,%rsi
 1f77989:	shl    $0x6,%rsi
 1f7798d:	mov    0x38(%rdx,%rsi,1),%rsi
 1f77992:	cmp    (%rbx,%rdi,8),%rsi
 1f77996:	jne    1f779f0 <node_facts_reader_flush+0xb00>
 1f77998:	movzwl -0x2(%r11,%r15,2),%esi
 1f7799e:	mov    0x2b8(%r14),%rbx
 1f779a5:	mov    %ecx,%edi
 1f779a7:	sub    %esi,%edi
 1f779a9:	add    %rax,%rbx
 1f779ac:	mov    %rdi,%rsi
 1f779af:	shl    $0x6,%rsi
 1f779b3:	mov    0x38(%rdx,%rsi,1),%rsi
 1f779b8:	cmp    (%rbx,%rdi,8),%rsi
 1f779bc:	jne    1f779f0 <node_facts_reader_flush+0xb00>
 1f779be:	movzwl (%r11,%r15,2),%esi
 1f779c3:	add    0x2b8(%r14),%rax
 1f779ca:	mov    %ecx,%edi
 1f779cc:	sub    %esi,%edi
 1f779ce:	mov    %rdi,%rsi
 1f779d1:	shl    $0x6,%rsi
 1f779d5:	mov    0x38(%rdx,%rsi,1),%rsi
 1f779da:	cmp    (%rax,%rdi,8),%rsi
 1f779de:	sete   %al
 1f779e1:	add    $0x8,%r15
 1f779e5:	cmp    %r15,%r12
 1f779e8:	jne    1f77890 <node_facts_reader_flush+0x9a0>
 1f779ee:	jmp    1f779ff <node_facts_reader_flush+0xb0f>
 1f779f0:	xor    %eax,%eax
 1f779f2:	add    $0x8,%r15
 1f779f6:	cmp    %r15,%r12
 1f779f9:	jne    1f77890 <node_facts_reader_flush+0x9a0>
 1f779ff:	mov    0x50(%rsp),%r11
 1f77a04:	test   %rbp,%rbp
 1f77a07:	je     1f77a70 <node_facts_reader_flush+0xb80>
 1f77a09:	mov    0x30(%rsp),%rsi
 1f77a0e:	add    %rsi,%rsi
 1f77a11:	lea    (%rsi,%r15,2),%rsi
 1f77a15:	add    %rsi,%r11
 1f77a18:	xor    %esi,%esi
 1f77a1a:	jmp    1f77a53 <node_facts_reader_flush+0xb63>
 1f77a1c:	nopl   0x0(%rax)
 1f77a20:	movzwl (%r11,%rsi,2),%eax
 1f77a25:	lea    0x0(,%r13,8),%rbx
 1f77a2d:	add    0x2b8(%r14),%rbx
 1f77a34:	mov    %ecx,%edi
 1f77a36:	sub    %eax,%edi
 1f77a38:	mov    %rdi,%rax
 1f77a3b:	shl    $0x6,%rax
 1f77a3f:	mov    0x38(%rdx,%rax,1),%rax
 1f77a44:	cmp    (%rbx,%rdi,8),%rax
 1f77a48:	sete   %al
 1f77a4b:	inc    %rsi
 1f77a4e:	cmp    %rsi,%rbp
 1f77a51:	je     1f77a70 <node_facts_reader_flush+0xb80>
 1f77a53:	cmp    $0x1,%al
 1f77a55:	je     1f77a20 <node_facts_reader_flush+0xb30>
 1f77a57:	xor    %eax,%eax
 1f77a59:	inc    %rsi
 1f77a5c:	cmp    %rsi,%rbp
 1f77a5f:	jne    1f77a53 <node_facts_reader_flush+0xb63>
 1f77a61:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f77a70:	mov    0x20(%rsp),%r12
 1f77a75:	and    %r9b,%r8b
 1f77a78:	cmp    $0x1,%r8b
 1f77a7c:	jne    1f77a8d <node_facts_reader_flush+0xb9d>
 1f77a7e:	cmp    0x8(%rsp),%r10
 1f77a83:	jne    1f77a8d <node_facts_reader_flush+0xb9d>
 1f77a85:	test   %al,%al
 1f77a87:	jne    1f77510 <node_facts_reader_flush+0x620>
 1f77a8d:	incq   0x8f0(%r12)
 1f77a95:	mov    0x18(%rsp),%rdx
 1f77a9a:	mov    (%r14),%rax
 1f77a9d:	mov    0x238(%r14),%rsi
 1f77aa4:	mov    (%rsi,%rdx,4),%edi
 1f77aa7:	mov    0x10(%rax),%rax
 1f77aab:	mov    $0xffffffff,%esi
 1f77ab0:	cmp    0xec(%rax),%edi
 1f77ab6:	jae    1f77abf <node_facts_reader_flush+0xbcf>
 1f77ab8:	mov    0x28(%rax),%rax
 1f77abc:	mov    (%rax,%rdi,4),%esi
 1f77abf:	mov    0x940(%r14),%rax
 1f77ac6:	mov    0x11e0(%rax),%edi
 1f77acc:	cmp    $0xf,%rdi
 1f77ad0:	ja     1f77510 <node_facts_reader_flush+0x620>
 1f77ad6:	mov    %esi,0x1180(%rax,%rdi,4)
 1f77add:	mov    0x18(%rsp),%rdx
 1f77ae2:	mov    0x1f0(%r14),%rsi
 1f77ae9:	movzbl (%rsi,%rdx,1),%edx
 1f77aed:	mov    0x11e0(%rax),%esi
 1f77af3:	mov    %dl,0x11c0(%rax,%rsi,1)
 1f77afa:	mov    0x11e0(%rax),%edx
 1f77b00:	movb   $0x0,0x11d0(%rax,%rdx,1)
 1f77b08:	incl   0x11e0(%rax)
 1f77b0e:	jmp    1f77510 <node_facts_reader_flush+0x620>
 1f77b13:	mov    0x998(%r14),%rsi
 1f77b1a:	mov    0x230(%r14),%rax
 1f77b21:	mov    0x240(%r14),%rcx
 1f77b28:	mov    0x258(%r14),%edx
 1f77b2f:	vmovdqu64 0x958(%r14),%zmm0
 1f77b39:	mov    0x40(%rsp),%r13
 1f77b3e:	xor    %r15d,%r15d
 1f77b41:	mov    %rsi,0x230(%r14)
 1f77b48:	mov    0x9a0(%r14),%rsi
 1f77b4f:	mov    %rsi,0x240(%r14)
 1f77b56:	mov    0x9a8(%r14),%esi
 1f77b5d:	mov    %esi,0x258(%r14)
 1f77b64:	vmovdqu64 0x1f0(%r14),%zmm1
 1f77b6e:	vmovdqu64 %zmm0,0x1f0(%r14)
 1f77b78:	vmovdqu64 %zmm1,0x958(%r14)
 1f77b82:	mov    %rax,0x998(%r14)
 1f77b89:	mov    %rcx,0x9a0(%r14)
 1f77b90:	mov    %edx,0x9a8(%r14)
 1f77b97:	movl   $0x0,0x9ac(%r14)
 1f77ba2:	jmp    1f77bc3 <node_facts_reader_flush+0xcd3>
 1f77ba4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f77bb0:	mov    0x38(%rsp),%r15
 1f77bb5:	inc    %r15
 1f77bb8:	cmp    0x28(%rsp),%r15
 1f77bbd:	je     1f780d2 <node_facts_reader_flush+0x11e2>
 1f77bc3:	mov    0x248(%r14),%rax
 1f77bca:	mov    $0x3,%edx
 1f77bcf:	mov    %r14,%rdi
 1f77bd2:	mov    %r15d,%esi
 1f77bd5:	mov    (%rax,%r15,4),%ebx
 1f77bd9:	mov    0x4(%rax,%r15,4),%ebp
 1f77bde:	vzeroupper
 1f77be1:	call   1f7bb10 <node_facts_given>
 1f77be6:	mov    %r14,%rdi
 1f77be9:	mov    %r15,0x38(%rsp)
 1f77bee:	mov    %r15d,%esi
 1f77bf1:	xor    %edx,%edx
 1f77bf3:	xor    %ecx,%ecx
 1f77bf5:	call   1f7bd00 <node_facts_window>
 1f77bfa:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1f77bfe:	cmp    %ebx,%ebp
 1f77c00:	je     1f77bb0 <node_facts_reader_flush+0xcc0>
 1f77c02:	sub    %ebx,%ebp
 1f77c04:	xor    %eax,%eax
 1f77c06:	mov    %rbp,0x18(%rsp)
 1f77c0b:	jmp    1f77c18 <node_facts_reader_flush+0xd28>
 1f77c0d:	nopl   (%rax)
 1f77c10:	inc    %rax
 1f77c13:	cmp    %rbp,%rax
 1f77c16:	je     1f77bb0 <node_facts_reader_flush+0xcc0>
 1f77c18:	mov    0x1f8(%r14),%rdx
 1f77c1f:	lea    (%rbx,%rax,1),%ecx
 1f77c22:	testb  $0x2,(%rdx,%rcx,1)
 1f77c26:	je     1f77c10 <node_facts_reader_flush+0xd20>
 1f77c28:	mov    0x288(%r14),%rdx
 1f77c2f:	lea    (%rax,%rbx,1),%r8
 1f77c33:	movzbl (%rdx,%r8,1),%edi
 1f77c38:	mov    %edi,%r10d
 1f77c3b:	and    $0x60,%r10b
 1f77c3f:	cmp    $0x40,%r10b
 1f77c43:	jne    1f77c60 <node_facts_reader_flush+0xd70>
 1f77c45:	mov    0x290(%r14),%rdx
 1f77c4c:	movzwl (%rdx,%r8,2),%r9d
 1f77c51:	jmp    1f77c63 <node_facts_reader_flush+0xd73>
 1f77c53:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f77c60:	xor    %r9d,%r9d
 1f77c63:	mov    0x268(%r14),%rsi
 1f77c6a:	mov    0x2c0(%r14),%rdx
 1f77c71:	mov    %rax,%r11
 1f77c74:	shl    $0x6,%r11
 1f77c78:	mov    (%rsi,%r8,4),%esi
 1f77c7c:	add    %rdx,%r11
 1f77c7f:	cmp    %esi,(%r11)
 1f77c82:	jne    1f77d00 <node_facts_reader_flush+0xe10>
 1f77c84:	mov    0x298(%r14),%rsi
 1f77c8b:	mov    (%rsi,%r8,4),%esi
 1f77c8f:	cmp    %esi,0x4(%r11)
 1f77c93:	jne    1f77d00 <node_facts_reader_flush+0xe10>
 1f77c95:	mov    0x270(%r14),%rsi
 1f77c9c:	mov    (%rsi,%r8,4),%esi
 1f77ca0:	cmp    %esi,0x8(%r11)
 1f77ca4:	jne    1f77d00 <node_facts_reader_flush+0xe10>
 1f77ca6:	mov    0x278(%r14),%rsi
 1f77cad:	mov    (%rsi,%r8,4),%esi
 1f77cb1:	cmp    %esi,0xc(%r11)
 1f77cb5:	jne    1f77d15 <node_facts_reader_flush+0xe25>
 1f77cb7:	mov    0x280(%r14),%rsi
 1f77cbe:	mov    (%rsi,%r8,8),%rsi
 1f77cc2:	cmp    %rsi,0x10(%r11)
 1f77cc6:	jne    1f77d00 <node_facts_reader_flush+0xe10>
 1f77cc8:	movzbl 0x18(%r11),%ebp
 1f77ccd:	cmp    %dil,%bpl
 1f77cd0:	sete   %sil
 1f77cd4:	cmp    $0x40,%r10b
 1f77cd8:	jne    1f77d20 <node_facts_reader_flush+0xe30>
 1f77cda:	cmp    %dil,%bpl
 1f77cdd:	jne    1f77d20 <node_facts_reader_flush+0xe30>
 1f77cdf:	cmp    %r9w,0x1a(%r11)
 1f77ce4:	sete   %sil
 1f77ce8:	mov    0x2a0(%r14),%rdi
 1f77cef:	mov    (%rdi,%r8,8),%r9d
 1f77cf3:	cmp    %r9d,0x20(%r11)
 1f77cf7:	je     1f77d31 <node_facts_reader_flush+0xe41>
 1f77cf9:	jmp    1f77d60 <node_facts_reader_flush+0xe70>
 1f77cfb:	nopl   0x0(%rax,%rax,1)
 1f77d00:	xor    %esi,%esi
 1f77d02:	mov    0x2a0(%r14),%rdi
 1f77d09:	mov    (%rdi,%r8,8),%r9d
 1f77d0d:	cmp    %r9d,0x20(%r11)
 1f77d11:	je     1f77d31 <node_facts_reader_flush+0xe41>
 1f77d13:	jmp    1f77d60 <node_facts_reader_flush+0xe70>
 1f77d15:	xor    %esi,%esi
 1f77d17:	nopw   0x0(%rax,%rax,1)
 1f77d20:	mov    0x2a0(%r14),%rdi
 1f77d27:	mov    (%rdi,%r8,8),%r9d
 1f77d2b:	cmp    %r9d,0x20(%r11)
 1f77d2f:	jne    1f77d60 <node_facts_reader_flush+0xe70>
 1f77d31:	mov    0x4(%rdi,%r8,8),%edi
 1f77d36:	cmp    %edi,0x24(%r11)
 1f77d3a:	jne    1f77d60 <node_facts_reader_flush+0xe70>
 1f77d3c:	mov    0x2a8(%r14),%rdi
 1f77d43:	mov    (%rdi,%r8,8),%r9d
 1f77d47:	cmp    %r9d,0x28(%r11)
 1f77d4b:	jne    1f77d60 <node_facts_reader_flush+0xe70>
 1f77d4d:	mov    0x4(%rdi,%r8,8),%edi
 1f77d52:	cmp    %edi,0x2c(%r11)
 1f77d56:	sete   %dil
 1f77d5a:	jmp    1f77d62 <node_facts_reader_flush+0xe72>
 1f77d5c:	nopl   0x0(%rax)
 1f77d60:	xor    %edi,%edi
 1f77d62:	mov    0x1f0(%r14),%r12
 1f77d69:	mov    0x2b0(%r14),%r9
 1f77d70:	mov    $0x1,%r15b
 1f77d73:	mov    (%r9,%r8,8),%r8
 1f77d77:	mov    0x30(%r11),%r9
 1f77d7b:	cmpb   $0x22,(%r12,%rcx,1)
 1f77d80:	jne    1f78020 <node_facts_reader_flush+0x1130>
 1f77d86:	mov    0x20(%rsp),%r12
 1f77d8b:	cmp    $0x40,%r10b
 1f77d8f:	je     1f78025 <node_facts_reader_flush+0x1135>
 1f77d95:	cmpb   $0x0,0x19(%r11)
 1f77d9a:	je     1f78025 <node_facts_reader_flush+0x1135>
 1f77da0:	testb  $0x2,0x1a(%r11)
 1f77da5:	je     1f78025 <node_facts_reader_flush+0x1135>
 1f77dab:	mov    0x228(%r14),%r10
 1f77db2:	movzwl (%r10,%rcx,2),%r13d
 1f77db7:	test   %r13,%r13
 1f77dba:	je     1f78025 <node_facts_reader_flush+0x1135>
 1f77dc0:	mov    0x220(%r14),%r11
 1f77dc7:	mov    0x240(%r14),%r10
 1f77dce:	mov    (%r11,%rcx,4),%r15d
 1f77dd2:	mov    %r13d,%r11d
 1f77dd5:	and    $0x7,%r11d
 1f77dd9:	mov    %r15,0x30(%rsp)
 1f77dde:	cmp    $0x8,%r13w
 1f77de3:	jae    1f77df0 <node_facts_reader_flush+0xf00>
 1f77de5:	mov    $0x1,%r15b
 1f77de8:	xor    %r12d,%r12d
 1f77deb:	jmp    1f77fb8 <node_facts_reader_flush+0x10c8>
 1f77df0:	lea    0xe(%r10,%r15,2),%rbp
 1f77df5:	and    $0xfffffff8,%r13d
 1f77df9:	mov    $0x1,%r15b
 1f77dfc:	xor    %r12d,%r12d
 1f77dff:	mov    %edi,0x8(%rsp)
 1f77e03:	mov    %r10,(%rsp)
 1f77e07:	mov    %r13,0x10(%rsp)
 1f77e0c:	jmp    1f77e20 <node_facts_reader_flush+0xf30>
 1f77e0e:	xchg   %ax,%ax
 1f77e10:	xor    %r15d,%r15d
 1f77e13:	add    $0x8,%r12
 1f77e17:	cmp    %r12,%r13
 1f77e1a:	je     1f77fb3 <node_facts_reader_flush+0x10c3>
 1f77e20:	cmp    $0x1,%r15b
 1f77e24:	jne    1f77e10 <node_facts_reader_flush+0xf20>
 1f77e26:	movzwl -0xe(%rbp,%r12,2),%r15d
 1f77e2c:	mov    %r9,%rdi
 1f77e2f:	mov    %r8,%r9
 1f77e32:	mov    0x2b8(%r14),%r8
 1f77e39:	mov    %eax,%r13d
 1f77e3c:	sub    %r15d,%r13d
 1f77e3f:	mov    %r13,%r15
 1f77e42:	shl    $0x6,%r15
 1f77e46:	mov    0x38(%rdx,%r15,1),%r10
 1f77e4b:	lea    0x0(,%rbx,8),%r15
 1f77e53:	add    %r15,%r8
 1f77e56:	cmp    (%r8,%r13,8),%r10
 1f77e5a:	jne    1f77f90 <node_facts_reader_flush+0x10a0>
 1f77e60:	movzwl -0xc(%rbp,%r12,2),%r8d
 1f77e66:	mov    0x2b8(%r14),%r13
 1f77e6d:	mov    %eax,%r10d
 1f77e70:	sub    %r8d,%r10d
 1f77e73:	add    %r15,%r13
 1f77e76:	mov    %r10,%r8
 1f77e79:	shl    $0x6,%r8
 1f77e7d:	mov    0x38(%rdx,%r8,1),%r8
 1f77e82:	cmp    0x0(%r13,%r10,8),%r8
 1f77e87:	jne    1f77f90 <node_facts_reader_flush+0x10a0>
 1f77e8d:	movzwl -0xa(%rbp,%r12,2),%r8d
 1f77e93:	mov    0x2b8(%r14),%r13
 1f77e9a:	mov    %eax,%r10d
 1f77e9d:	sub    %r8d,%r10d
 1f77ea0:	add    %r15,%r13
 1f77ea3:	mov    %r10,%r8
 1f77ea6:	shl    $0x6,%r8
 1f77eaa:	mov    0x38(%rdx,%r8,1),%r8
 1f77eaf:	cmp    0x0(%r13,%r10,8),%r8
 1f77eb4:	jne    1f77f90 <node_facts_reader_flush+0x10a0>
 1f77eba:	movzwl -0x8(%rbp,%r12,2),%r8d
 1f77ec0:	mov    0x2b8(%r14),%r13
 1f77ec7:	mov    %eax,%r10d
 1f77eca:	sub    %r8d,%r10d
 1f77ecd:	add    %r15,%r13
 1f77ed0:	mov    %r10,%r8
 1f77ed3:	shl    $0x6,%r8
 1f77ed7:	mov    0x38(%rdx,%r8,1),%r8
 1f77edc:	cmp    0x0(%r13,%r10,8),%r8
 1f77ee1:	jne    1f77f90 <node_facts_reader_flush+0x10a0>
 1f77ee7:	movzwl -0x6(%rbp,%r12,2),%r8d
 1f77eed:	mov    0x2b8(%r14),%r13
 1f77ef4:	mov    %eax,%r10d
 1f77ef7:	sub    %r8d,%r10d
 1f77efa:	add    %r15,%r13
 1f77efd:	mov    %r10,%r8
 1f77f00:	shl    $0x6,%r8
 1f77f04:	mov    0x38(%rdx,%r8,1),%r8
 1f77f09:	cmp    0x0(%r13,%r10,8),%r8
 1f77f0e:	jne    1f77f90 <node_facts_reader_flush+0x10a0>
 1f77f14:	movzwl -0x4(%rbp,%r12,2),%r8d
 1f77f1a:	mov    0x2b8(%r14),%r13
 1f77f21:	mov    %eax,%r10d
 1f77f24:	sub    %r8d,%r10d
 1f77f27:	add    %r15,%r13
 1f77f2a:	mov    %r10,%r8
 1f77f2d:	shl    $0x6,%r8
 1f77f31:	mov    0x38(%rdx,%r8,1),%r8
 1f77f36:	cmp    0x0(%r13,%r10,8),%r8
 1f77f3b:	jne    1f77f90 <node_facts_reader_flush+0x10a0>
 1f77f3d:	movzwl -0x2(%rbp,%r12,2),%r8d
 1f77f43:	mov    0x2b8(%r14),%r13
 1f77f4a:	mov    %eax,%r10d
 1f77f4d:	sub    %r8d,%r10d
 1f77f50:	add    %r15,%r13
 1f77f53:	mov    %r10,%r8
 1f77f56:	shl    $0x6,%r8
 1f77f5a:	mov    0x38(%rdx,%r8,1),%r8
 1f77f5f:	cmp    0x0(%r13,%r10,8),%r8
 1f77f64:	jne    1f77f90 <node_facts_reader_flush+0x10a0>
 1f77f66:	movzwl 0x0(%rbp,%r12,2),%r8d
 1f77f6c:	add    0x2b8(%r14),%r15
 1f77f73:	mov    %eax,%r10d
 1f77f76:	sub    %r8d,%r10d
 1f77f79:	mov    %r10,%r8
 1f77f7c:	shl    $0x6,%r8
 1f77f80:	mov    0x38(%rdx,%r8,1),%r8
 1f77f85:	cmp    (%r15,%r10,8),%r8
 1f77f89:	sete   %r15b
 1f77f8d:	jmp    1f77f93 <node_facts_reader_flush+0x10a3>
 1f77f8f:	nop
 1f77f90:	xor    %r15d,%r15d
 1f77f93:	mov    %r9,%r8
 1f77f96:	mov    %rdi,%r9
 1f77f99:	mov    0x8(%rsp),%edi
 1f77f9d:	mov    (%rsp),%r10
 1f77fa1:	mov    0x10(%rsp),%r13
 1f77fa6:	add    $0x8,%r12
 1f77faa:	cmp    %r12,%r13
 1f77fad:	jne    1f77e20 <node_facts_reader_flush+0xf30>
 1f77fb3:	test   %r11,%r11
 1f77fb6:	je     1f78020 <node_facts_reader_flush+0x1130>
 1f77fb8:	mov    0x30(%rsp),%r13
 1f77fbd:	add    %r13,%r13
 1f77fc0:	lea    0x0(%r13,%r12,2),%r12
 1f77fc5:	add    %r12,%r10
 1f77fc8:	xor    %r12d,%r12d
 1f77fcb:	jmp    1f78007 <node_facts_reader_flush+0x1117>
 1f77fcd:	nopl   (%rax)
 1f77fd0:	movzwl (%r10,%r12,2),%ebp
 1f77fd5:	mov    %eax,%r15d
 1f77fd8:	sub    %ebp,%r15d
 1f77fdb:	lea    0x0(,%rbx,8),%rbp
 1f77fe3:	add    0x2b8(%r14),%rbp
 1f77fea:	mov    %r15,%r13
 1f77fed:	shl    $0x6,%r13
 1f77ff1:	mov    0x38(%rdx,%r13,1),%r13
 1f77ff6:	cmp    0x0(%rbp,%r15,8),%r13
 1f77ffb:	sete   %r15b
 1f77fff:	inc    %r12
 1f78002:	cmp    %r12,%r11
 1f78005:	je     1f78020 <node_facts_reader_flush+0x1130>
 1f78007:	cmp    $0x1,%r15b
 1f7800b:	je     1f77fd0 <node_facts_reader_flush+0x10e0>
 1f7800d:	xor    %r15d,%r15d
 1f78010:	inc    %r12
 1f78013:	cmp    %r12,%r11
 1f78016:	jne    1f78007 <node_facts_reader_flush+0x1117>
 1f78018:	nopl   0x0(%rax,%rax,1)
 1f78020:	mov    0x20(%rsp),%r12
 1f78025:	mov    0x40(%rsp),%r13
 1f7802a:	mov    0x18(%rsp),%rbp
 1f7802f:	and    %dil,%sil
 1f78032:	cmp    $0x1,%sil
 1f78036:	jne    1f78046 <node_facts_reader_flush+0x1156>
 1f78038:	cmp    %r8,%r9
 1f7803b:	jne    1f78046 <node_facts_reader_flush+0x1156>
 1f7803d:	test   %r15b,%r15b
 1f78040:	jne    1f77c10 <node_facts_reader_flush+0xd20>
 1f78046:	vmovdqu 0x8f0(%r12),%xmm0
 1f78050:	vpsubq %xmm1,%xmm0,%xmm0
 1f78054:	vmovdqu %xmm0,0x8f0(%r12)
 1f7805e:	mov    (%r14),%rdx
 1f78061:	mov    0x238(%r14),%rsi
 1f78068:	mov    (%rsi,%rcx,4),%edi
 1f7806b:	mov    0x10(%rdx),%rdx
 1f7806f:	mov    $0xffffffff,%esi
 1f78074:	cmp    0xec(%rdx),%edi
 1f7807a:	jae    1f78083 <node_facts_reader_flush+0x1193>
 1f7807c:	mov    0x28(%rdx),%rdx
 1f78080:	mov    (%rdx,%rdi,4),%esi
 1f78083:	mov    0x940(%r14),%rdx
 1f7808a:	mov    0x11e0(%rdx),%edi
 1f78090:	cmp    $0xf,%rdi
 1f78094:	ja     1f77c10 <node_facts_reader_flush+0xd20>
 1f7809a:	mov    %esi,0x1180(%rdx,%rdi,4)
 1f780a1:	mov    0x1f0(%r14),%rsi
 1f780a8:	movzbl (%rsi,%rcx,1),%ecx
 1f780ac:	mov    0x11e0(%rdx),%esi
 1f780b2:	mov    %cl,0x11c0(%rdx,%rsi,1)
 1f780b9:	mov    0x11e0(%rdx),%ecx
 1f780bf:	movb   $0x1,0x11d0(%rdx,%rcx,1)
 1f780c7:	incl   0x11e0(%rdx)
 1f780cd:	jmp    1f77c10 <node_facts_reader_flush+0xd20>
 1f780d2:	testb  $0x1,0xb30(%r14)
 1f780da:	jne    1f7847a <node_facts_reader_flush+0x158a>
 1f780e0:	xor    %esi,%esi
 1f780e2:	jmp    1f781e7 <node_facts_reader_flush+0x12f7>
 1f780e7:	mov    0x290(%r14),%rax
 1f780ee:	movzwl (%rax,%rcx,2),%eax
 1f780f2:	mov    0x270(%r14),%r9
 1f780f9:	mov    0x2a0(%r14),%r11
 1f78100:	mov    0x2a8(%r14),%rbx
 1f78107:	shl    $0x6,%rdx
 1f7810b:	mov    0x298(%r14),%r8
 1f78112:	mov    0x280(%r14),%r10
 1f78119:	mov    0x2b0(%r14),%r15
 1f78120:	add    %rdx,%r12
 1f78123:	mov    0x268(%r14),%rdx
 1f7812a:	mov    (%r9,%rcx,4),%ebp
 1f7812e:	mov    0x278(%r14),%r9
 1f78135:	vmovq  (%rbx,%rcx,8),%xmm0
 1f7813a:	vmovq  (%r11,%rcx,8),%xmm1
 1f78140:	mov    (%r8,%rcx,4),%r8d
 1f78144:	mov    (%r10,%rcx,8),%r10
 1f78148:	mov    (%r15,%rcx,8),%r15
 1f7814c:	mov    (%rdx,%rcx,4),%edx
 1f7814f:	mov    (%r9,%rcx,4),%r9d
 1f78153:	movabs $0x2525252525252525,%rcx
 1f7815d:	mov    %edx,(%r12)
 1f78161:	mov    %r8d,0x4(%r12)
 1f78166:	mov    %ebp,0x8(%r12)
 1f7816b:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f7816f:	mov    %r9d,0xc(%r12)
 1f78174:	mov    %r10,0x10(%r12)
 1f78179:	mov    %dil,0x18(%r12)
 1f7817e:	movb   $0x1,0x19(%r12)
 1f78184:	mov    %ax,0x1a(%r12)
 1f7818a:	movl   $0x0,0x1c(%r12)
 1f78193:	vmovdqu %xmm0,0x20(%r12)
 1f7819a:	mov    %r15,0x30(%r12)
 1f7819f:	mov    %rcx,0x38(%r12)
 1f781a4:	rdtsc
 1f781a6:	lea    0x1(%rsi),%rbx
 1f781aa:	mov    %r14,%rdi
 1f781ad:	xor    %ecx,%ecx
 1f781af:	mov    %rdx,%r12
 1f781b2:	shl    $0x20,%r12
 1f781b6:	xor    %edx,%edx
 1f781b8:	or     %rax,%r12
 1f781bb:	call   1f7bd00 <node_facts_window>
 1f781c0:	rdtsc
 1f781c2:	mov    %rbx,%rsi
 1f781c5:	shl    $0x20,%rdx
 1f781c9:	or     %rax,%rdx
 1f781cc:	sub    %r12,%rdx
 1f781cf:	mov    0x20(%rsp),%r12
 1f781d4:	add    %rdx,0x918(%r12)
 1f781dc:	cmp    0x28(%rsp),%rbx
 1f781e1:	je     1f7888a <node_facts_reader_flush+0x199a>
 1f781e7:	mov    0x248(%r14),%rax
 1f781ee:	mov    (%rax,%rsi,4),%ecx
 1f781f1:	mov    0x4(%rax,%rsi,4),%eax
 1f781f5:	cmp    %ecx,%eax
 1f781f7:	je     1f781a4 <node_facts_reader_flush+0x12b4>
 1f781f9:	mov    0x2c0(%r14),%r12
 1f78200:	sub    %ecx,%eax
 1f78202:	cmp    $0x1,%eax
 1f78205:	jne    1f78210 <node_facts_reader_flush+0x1320>
 1f78207:	xor    %edx,%edx
 1f78209:	jmp    1f78459 <node_facts_reader_flush+0x1569>
 1f7820e:	xchg   %ax,%ax
 1f78210:	lea    0x0(,%rcx,8),%r9
 1f78218:	lea    0x0(,%rcx,4),%r11
 1f78220:	mov    %rsi,0x18(%rsp)
 1f78225:	mov    %eax,%esi
 1f78227:	and    $0xfffffffe,%esi
 1f7822a:	mov    %rax,(%rsp)
 1f7822e:	mov    %r12,0x8(%rsp)
 1f78233:	mov    %r12,%r15
 1f78236:	xor    %edx,%edx
 1f78238:	jmp    1f782db <node_facts_reader_flush+0x13eb>
 1f7823d:	nopl   (%rax)
 1f78240:	mov    0x290(%r14),%r8
 1f78247:	add    %rcx,%r8
 1f7824a:	add    %rcx,%r8
 1f7824d:	movzwl 0x2(%r8,%rdx,2),%ebx
 1f78253:	mov    0x2a8(%r14),%r8
 1f7825a:	add    %r9,%r8
 1f7825d:	vmovq  0x8(%r8,%rdx,8),%xmm0
 1f78264:	mov    0x2a0(%r14),%r8
 1f7826b:	add    %r9,%r8
 1f7826e:	vmovq  0x8(%r8,%rdx,8),%xmm1
 1f78275:	mov    0x2b0(%r14),%r8
 1f7827c:	add    %r9,%r8
 1f7827f:	mov    0x8(%r8,%rdx,8),%r8
 1f78284:	mov    %r12d,0x40(%r15)
 1f78288:	mov    %r13d,0x44(%r15)
 1f7828c:	mov    %edi,0x48(%r15)
 1f78290:	mov    %r10d,0x4c(%r15)
 1f78294:	mov    %rax,0x50(%r15)
 1f78298:	movabs $0x2525252525252525,%rax
 1f782a2:	mov    %bpl,0x58(%r15)
 1f782a6:	movb   $0x1,0x59(%r15)
 1f782ab:	mov    %bx,0x5a(%r15)
 1f782b0:	movl   $0x0,0x5c(%r15)
 1f782b8:	add    $0x2,%rdx
 1f782bc:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f782c0:	vmovdqu %xmm0,0x60(%r15)
 1f782c6:	mov    %r8,0x70(%r15)
 1f782ca:	mov    %rax,0x78(%r15)
 1f782ce:	sub    $0xffffffffffffff80,%r15
 1f782d2:	cmp    %rdx,%rsi
 1f782d5:	je     1f78440 <node_facts_reader_flush+0x1550>
 1f782db:	mov    0x288(%r14),%rax
 1f782e2:	mov    0x280(%r14),%r8
 1f782e9:	add    %rcx,%rax
 1f782ec:	add    %r9,%r8
 1f782ef:	movzbl (%rdx,%rax,1),%ebp
 1f782f3:	mov    0x268(%r14),%rax
 1f782fa:	add    %r11,%rax
 1f782fd:	mov    %ebp,%ebx
 1f782ff:	mov    (%rax,%rdx,4),%r12d
 1f78303:	mov    0x298(%r14),%rax
 1f7830a:	and    $0x60,%bl
 1f7830d:	add    %r11,%rax
 1f78310:	mov    (%rax,%rdx,4),%r13d
 1f78314:	mov    0x270(%r14),%rax
 1f7831b:	add    %r11,%rax
 1f7831e:	mov    (%rax,%rdx,4),%edi
 1f78321:	mov    0x278(%r14),%rax
 1f78328:	add    %r11,%rax
 1f7832b:	mov    (%rax,%rdx,4),%r10d
 1f7832f:	mov    (%r8,%rdx,8),%rax
 1f78333:	cmp    $0x40,%bl
 1f78336:	jne    1f78350 <node_facts_reader_flush+0x1460>
 1f78338:	mov    0x290(%r14),%rbx
 1f7833f:	add    %rcx,%rbx
 1f78342:	add    %rcx,%rbx
 1f78345:	movzwl (%rbx,%rdx,2),%ebx
 1f78349:	jmp    1f78352 <node_facts_reader_flush+0x1462>
 1f7834b:	nopl   0x0(%rax,%rax,1)
 1f78350:	xor    %ebx,%ebx
 1f78352:	mov    0x2a8(%r14),%r8
 1f78359:	add    %r9,%r8
 1f7835c:	vmovsd (%r8,%rdx,8),%xmm0
 1f78362:	mov    0x2a0(%r14),%r8
 1f78369:	add    %r9,%r8
 1f7836c:	vmovsd (%r8,%rdx,8),%xmm1
 1f78372:	mov    0x2b0(%r14),%r8
 1f78379:	add    %r9,%r8
 1f7837c:	mov    (%r8,%rdx,8),%r8
 1f78380:	mov    %r12d,(%r15)
 1f78383:	mov    %r13d,0x4(%r15)
 1f78387:	mov    %edi,0x8(%r15)
 1f7838b:	mov    %r10d,0xc(%r15)
 1f7838f:	mov    %rax,0x10(%r15)
 1f78393:	movabs $0x2525252525252525,%rax
 1f7839d:	mov    %bpl,0x18(%r15)
 1f783a1:	movb   $0x1,0x19(%r15)
 1f783a6:	mov    %bx,0x1a(%r15)
 1f783ab:	movl   $0x0,0x1c(%r15)
 1f783b3:	vmovlhps %xmm0,%xmm1,%xmm0
 1f783b7:	vmovups %xmm0,0x20(%r15)
 1f783bd:	mov    %r8,0x30(%r15)
 1f783c1:	mov    %rax,0x38(%r15)
 1f783c5:	mov    0x288(%r14),%rax
 1f783cc:	mov    0x280(%r14),%rbx
 1f783d3:	add    %rcx,%rax
 1f783d6:	add    %r9,%rbx
 1f783d9:	movzbl 0x1(%rdx,%rax,1),%ebp
 1f783de:	mov    0x268(%r14),%rax
 1f783e5:	add    %r11,%rax
 1f783e8:	mov    %ebp,%r8d
 1f783eb:	mov    0x4(%rax,%rdx,4),%r12d
 1f783f0:	mov    0x298(%r14),%rax
 1f783f7:	and    $0x60,%r8b
 1f783fb:	add    %r11,%rax
 1f783fe:	mov    0x4(%rax,%rdx,4),%r13d
 1f78403:	mov    0x270(%r14),%rax
 1f7840a:	add    %r11,%rax
 1f7840d:	mov    0x4(%rax,%rdx,4),%edi
 1f78411:	mov    0x278(%r14),%rax
 1f78418:	add    %r11,%rax
 1f7841b:	mov    0x4(%rax,%rdx,4),%r10d
 1f78420:	mov    0x8(%rbx,%rdx,8),%rax
 1f78425:	cmp    $0x40,%r8b
 1f78429:	je     1f78240 <node_facts_reader_flush+0x1350>
 1f7842f:	xor    %ebx,%ebx
 1f78431:	jmp    1f78253 <node_facts_reader_flush+0x1363>
 1f78436:	cs nopw 0x0(%rax,%rax,1)
 1f78440:	testb  $0x1,(%rsp)
 1f78444:	mov    0x40(%rsp),%r13
 1f78449:	mov    0x18(%rsp),%rsi
 1f7844e:	mov    0x8(%rsp),%r12
 1f78453:	je     1f781a4 <node_facts_reader_flush+0x12b4>
 1f78459:	mov    0x288(%r14),%rax
 1f78460:	add    %rdx,%rcx
 1f78463:	movzbl (%rax,%rcx,1),%edi
 1f78467:	mov    %edi,%eax
 1f78469:	and    $0x60,%al
 1f7846b:	cmp    $0x40,%al
 1f7846d:	je     1f780e7 <node_facts_reader_flush+0x11f7>
 1f78473:	xor    %eax,%eax
 1f78475:	jmp    1f780f2 <node_facts_reader_flush+0x1202>
 1f7847a:	cmpb   $0x1,0xb38(%r14)
 1f78482:	jne    1f784fd <node_facts_reader_flush+0x160d>
 1f78488:	rdtsc
 1f7848a:	mov    %rdx,%r12
 1f7848d:	shl    $0x20,%r12
 1f78491:	or     %rax,%r12
 1f78494:	cmpl   $0x0,0xa90(%r14)
 1f7849c:	je     1f784d5 <node_facts_reader_flush+0x15e5>
 1f7849e:	xor    %ebx,%ebx
 1f784a0:	mov    0xa48(%r14),%rax
 1f784a7:	mov    0xa50(%r14),%rcx
 1f784ae:	mov    %r13,%rdi
 1f784b1:	mov    (%rax,%rbx,4),%esi
 1f784b4:	mov    0xa58(%r14),%rax
 1f784bb:	mov    (%rcx,%rbx,4),%edx
 1f784be:	mov    (%rax,%rbx,4),%ecx
 1f784c1:	call   1f530c0 <node_machine_type>
 1f784c6:	mov    0xa90(%r14),%eax
 1f784cd:	inc    %rbx
 1f784d0:	cmp    %rax,%rbx
 1f784d3:	jb     1f784a0 <node_facts_reader_flush+0x15b0>
 1f784d5:	rdtsc
 1f784d7:	shl    $0x20,%rdx
 1f784db:	or     %rax,%rdx
 1f784de:	sub    %r12,%rdx
 1f784e1:	mov    0x20(%rsp),%r12
 1f784e6:	add    %rdx,0x920(%r12)
 1f784ee:	mov    0x250(%r14),%eax
 1f784f5:	add    %rax,0x928(%r12)
 1f784fd:	xor    %esi,%esi
 1f784ff:	jmp    1f785f4 <node_facts_reader_flush+0x1704>
 1f78504:	mov    0x290(%r14),%rax
 1f7850b:	movzwl (%rax,%rcx,2),%eax
 1f7850f:	mov    0x270(%r14),%r9
 1f78516:	mov    0x2a0(%r14),%r11
 1f7851d:	mov    0x2a8(%r14),%rbx
 1f78524:	shl    $0x6,%rdx
 1f78528:	mov    0x298(%r14),%r8
 1f7852f:	mov    0x280(%r14),%r10
 1f78536:	mov    0x2b0(%r14),%r15
 1f7853d:	add    %rdx,%r13
 1f78540:	mov    0x268(%r14),%rdx
 1f78547:	mov    (%r9,%rcx,4),%ebp
 1f7854b:	mov    0x278(%r14),%r9
 1f78552:	vmovq  (%rbx,%rcx,8),%xmm0
 1f78557:	vmovq  (%r11,%rcx,8),%xmm1
 1f7855d:	mov    (%r8,%rcx,4),%r8d
 1f78561:	mov    (%r10,%rcx,8),%r10
 1f78565:	mov    (%r15,%rcx,8),%r15
 1f78569:	mov    (%rdx,%rcx,4),%edx
 1f7856c:	mov    (%r9,%rcx,4),%r9d
 1f78570:	movabs $0x2525252525252525,%rcx
 1f7857a:	mov    %edx,0x0(%r13)
 1f7857e:	mov    %r8d,0x4(%r13)
 1f78582:	mov    %ebp,0x8(%r13)
 1f78586:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f7858a:	mov    %r9d,0xc(%r13)
 1f7858e:	mov    %r10,0x10(%r13)
 1f78592:	mov    %dil,0x18(%r13)
 1f78596:	movb   $0x1,0x19(%r13)
 1f7859b:	mov    %ax,0x1a(%r13)
 1f785a0:	movl   $0x0,0x1c(%r13)
 1f785a8:	vmovdqu %xmm0,0x20(%r13)
 1f785ae:	mov    %r15,0x30(%r13)
 1f785b2:	mov    %rcx,0x38(%r13)
 1f785b6:	rdtsc
 1f785b8:	lea    0x1(%rsi),%rbx
 1f785bc:	mov    %r14,%rdi
 1f785bf:	xor    %ecx,%ecx
 1f785c1:	mov    %rdx,%r15
 1f785c4:	shl    $0x20,%r15
 1f785c8:	xor    %edx,%edx
 1f785ca:	or     %rax,%r15
 1f785cd:	call   1f7bd00 <node_facts_window>
 1f785d2:	rdtsc
 1f785d4:	mov    %rbx,%rsi
 1f785d7:	shl    $0x20,%rdx
 1f785db:	or     %rax,%rdx
 1f785de:	sub    %r15,%rdx
 1f785e1:	add    %rdx,0x918(%r12)
 1f785e9:	cmp    0x28(%rsp),%rbx
 1f785ee:	je     1f7890d <node_facts_reader_flush+0x1a1d>
 1f785f4:	mov    0x248(%r14),%rax
 1f785fb:	mov    (%rax,%rsi,4),%ecx
 1f785fe:	mov    0x4(%rax,%rsi,4),%eax
 1f78602:	cmp    %ecx,%eax
 1f78604:	je     1f785b6 <node_facts_reader_flush+0x16c6>
 1f78606:	mov    0x2c0(%r14),%r13
 1f7860d:	sub    %ecx,%eax
 1f7860f:	cmp    $0x1,%eax
 1f78612:	jne    1f78620 <node_facts_reader_flush+0x1730>
 1f78614:	xor    %edx,%edx
 1f78616:	jmp    1f78869 <node_facts_reader_flush+0x1979>
 1f7861b:	nopl   0x0(%rax,%rax,1)
 1f78620:	lea    0x0(,%rcx,8),%r9
 1f78628:	lea    0x0(,%rcx,4),%r11
 1f78630:	mov    %rsi,0x18(%rsp)
 1f78635:	mov    %eax,%esi
 1f78637:	and    $0xfffffffe,%esi
 1f7863a:	mov    %rax,(%rsp)
 1f7863e:	mov    %r13,0x8(%rsp)
 1f78643:	mov    %r13,%r15
 1f78646:	xor    %edx,%edx
 1f78648:	jmp    1f786eb <node_facts_reader_flush+0x17fb>
 1f7864d:	nopl   (%rax)
 1f78650:	mov    0x290(%r14),%r8
 1f78657:	add    %rcx,%r8
 1f7865a:	add    %rcx,%r8
 1f7865d:	movzwl 0x2(%r8,%rdx,2),%ebx
 1f78663:	mov    0x2a8(%r14),%r8
 1f7866a:	add    %r9,%r8
 1f7866d:	vmovq  0x8(%r8,%rdx,8),%xmm0
 1f78674:	mov    0x2a0(%r14),%r8
 1f7867b:	add    %r9,%r8
 1f7867e:	vmovq  0x8(%r8,%rdx,8),%xmm1
 1f78685:	mov    0x2b0(%r14),%r8
 1f7868c:	add    %r9,%r8
 1f7868f:	mov    0x8(%r8,%rdx,8),%r8
 1f78694:	mov    %r12d,0x40(%r15)
 1f78698:	mov    %r13d,0x44(%r15)
 1f7869c:	mov    %edi,0x48(%r15)
 1f786a0:	mov    %r10d,0x4c(%r15)
 1f786a4:	mov    %rax,0x50(%r15)
 1f786a8:	movabs $0x2525252525252525,%rax
 1f786b2:	mov    %bpl,0x58(%r15)
 1f786b6:	movb   $0x1,0x59(%r15)
 1f786bb:	mov    %bx,0x5a(%r15)
 1f786c0:	movl   $0x0,0x5c(%r15)
 1f786c8:	add    $0x2,%rdx
 1f786cc:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f786d0:	vmovdqu %xmm0,0x60(%r15)
 1f786d6:	mov    %r8,0x70(%r15)
 1f786da:	mov    %rax,0x78(%r15)
 1f786de:	sub    $0xffffffffffffff80,%r15
 1f786e2:	cmp    %rdx,%rsi
 1f786e5:	je     1f78850 <node_facts_reader_flush+0x1960>
 1f786eb:	mov    0x288(%r14),%rax
 1f786f2:	mov    0x280(%r14),%r8
 1f786f9:	add    %rcx,%rax
 1f786fc:	add    %r9,%r8
 1f786ff:	movzbl (%rdx,%rax,1),%ebp
 1f78703:	mov    0x268(%r14),%rax
 1f7870a:	add    %r11,%rax
 1f7870d:	mov    %ebp,%ebx
 1f7870f:	mov    (%rax,%rdx,4),%r12d
 1f78713:	mov    0x298(%r14),%rax
 1f7871a:	and    $0x60,%bl
 1f7871d:	add    %r11,%rax
 1f78720:	mov    (%rax,%rdx,4),%r13d
 1f78724:	mov    0x270(%r14),%rax
 1f7872b:	add    %r11,%rax
 1f7872e:	mov    (%rax,%rdx,4),%edi
 1f78731:	mov    0x278(%r14),%rax
 1f78738:	add    %r11,%rax
 1f7873b:	mov    (%rax,%rdx,4),%r10d
 1f7873f:	mov    (%r8,%rdx,8),%rax
 1f78743:	cmp    $0x40,%bl
 1f78746:	jne    1f78760 <node_facts_reader_flush+0x1870>
 1f78748:	mov    0x290(%r14),%rbx
 1f7874f:	add    %rcx,%rbx
 1f78752:	add    %rcx,%rbx
 1f78755:	movzwl (%rbx,%rdx,2),%ebx
 1f78759:	jmp    1f78762 <node_facts_reader_flush+0x1872>
 1f7875b:	nopl   0x0(%rax,%rax,1)
 1f78760:	xor    %ebx,%ebx
 1f78762:	mov    0x2a8(%r14),%r8
 1f78769:	add    %r9,%r8
 1f7876c:	vmovsd (%r8,%rdx,8),%xmm0
 1f78772:	mov    0x2a0(%r14),%r8
 1f78779:	add    %r9,%r8
 1f7877c:	vmovsd (%r8,%rdx,8),%xmm1
 1f78782:	mov    0x2b0(%r14),%r8
 1f78789:	add    %r9,%r8
 1f7878c:	mov    (%r8,%rdx,8),%r8
 1f78790:	mov    %r12d,(%r15)
 1f78793:	mov    %r13d,0x4(%r15)
 1f78797:	mov    %edi,0x8(%r15)
 1f7879b:	mov    %r10d,0xc(%r15)
 1f7879f:	mov    %rax,0x10(%r15)
 1f787a3:	movabs $0x2525252525252525,%rax
 1f787ad:	mov    %bpl,0x18(%r15)
 1f787b1:	movb   $0x1,0x19(%r15)
 1f787b6:	mov    %bx,0x1a(%r15)
 1f787bb:	movl   $0x0,0x1c(%r15)
 1f787c3:	vmovlhps %xmm0,%xmm1,%xmm0
 1f787c7:	vmovups %xmm0,0x20(%r15)
 1f787cd:	mov    %r8,0x30(%r15)
 1f787d1:	mov    %rax,0x38(%r15)
 1f787d5:	mov    0x288(%r14),%rax
 1f787dc:	mov    0x280(%r14),%rbx
 1f787e3:	add    %rcx,%rax
 1f787e6:	add    %r9,%rbx
 1f787e9:	movzbl 0x1(%rdx,%rax,1),%ebp
 1f787ee:	mov    0x268(%r14),%rax
 1f787f5:	add    %r11,%rax
 1f787f8:	mov    %ebp,%r8d
 1f787fb:	mov    0x4(%rax,%rdx,4),%r12d
 1f78800:	mov    0x298(%r14),%rax
 1f78807:	and    $0x60,%r8b
 1f7880b:	add    %r11,%rax
 1f7880e:	mov    0x4(%rax,%rdx,4),%r13d
 1f78813:	mov    0x270(%r14),%rax
 1f7881a:	add    %r11,%rax
 1f7881d:	mov    0x4(%rax,%rdx,4),%edi
 1f78821:	mov    0x278(%r14),%rax
 1f78828:	add    %r11,%rax
 1f7882b:	mov    0x4(%rax,%rdx,4),%r10d
 1f78830:	mov    0x8(%rbx,%rdx,8),%rax
 1f78835:	cmp    $0x40,%r8b
 1f78839:	je     1f78650 <node_facts_reader_flush+0x1760>
 1f7883f:	xor    %ebx,%ebx
 1f78841:	jmp    1f78663 <node_facts_reader_flush+0x1773>
 1f78846:	cs nopw 0x0(%rax,%rax,1)
 1f78850:	testb  $0x1,(%rsp)
 1f78854:	mov    0x20(%rsp),%r12
 1f78859:	mov    0x18(%rsp),%rsi
 1f7885e:	mov    0x8(%rsp),%r13
 1f78863:	je     1f785b6 <node_facts_reader_flush+0x16c6>
 1f78869:	mov    0x288(%r14),%rax
 1f78870:	add    %rdx,%rcx
 1f78873:	movzbl (%rax,%rcx,1),%edi
 1f78877:	mov    %edi,%eax
 1f78879:	and    $0x60,%al
 1f7887b:	cmp    $0x40,%al
 1f7887d:	je     1f78504 <node_facts_reader_flush+0x1614>
 1f78883:	xor    %eax,%eax
 1f78885:	jmp    1f7850f <node_facts_reader_flush+0x161f>
 1f7888a:	cmpb   $0x1,0xb38(%r14)
 1f78892:	jne    1f7890d <node_facts_reader_flush+0x1a1d>
 1f78898:	rdtsc
 1f7889a:	mov    %rdx,%r12
 1f7889d:	shl    $0x20,%r12
 1f788a1:	or     %rax,%r12
 1f788a4:	cmpl   $0x0,0xa90(%r14)
 1f788ac:	je     1f788e5 <node_facts_reader_flush+0x19f5>
 1f788ae:	xor    %ebx,%ebx
 1f788b0:	mov    0xa48(%r14),%rax
 1f788b7:	mov    0xa50(%r14),%rcx
 1f788be:	mov    %r13,%rdi
 1f788c1:	mov    (%rax,%rbx,4),%esi
 1f788c4:	mov    0xa58(%r14),%rax
 1f788cb:	mov    (%rcx,%rbx,4),%edx
 1f788ce:	mov    (%rax,%rbx,4),%ecx
 1f788d1:	call   1f530c0 <node_machine_type>
 1f788d6:	mov    0xa90(%r14),%eax
 1f788dd:	inc    %rbx
 1f788e0:	cmp    %rax,%rbx
 1f788e3:	jb     1f788b0 <node_facts_reader_flush+0x19c0>
 1f788e5:	rdtsc
 1f788e7:	shl    $0x20,%rdx
 1f788eb:	or     %rax,%rdx
 1f788ee:	sub    %r12,%rdx
 1f788f1:	mov    0x20(%rsp),%r12
 1f788f6:	add    %rdx,0x920(%r12)
 1f788fe:	mov    0x250(%r14),%eax
 1f78905:	add    %rax,0x928(%r12)
 1f7890d:	mov    0xa90(%r14),%eax
 1f78914:	vmovd  0x28(%rsp),%xmm0
 1f7891a:	mov    0x48(%rsp),%r15
 1f7891f:	add    %rax,0x8a8(%r12)
 1f78927:	vmovd  0x250(%r14),%xmm1
 1f78930:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f78934:	vpaddq 0x8b0(%r12),%xmm0,%xmm0
 1f7893e:	vmovdqu %xmm0,0x8b0(%r12)
 1f78948:	cmpb   $0x1,0x9b0(%r14)
 1f78950:	jne    1f7895d <node_facts_reader_flush+0x1a6d>
 1f78952:	mov    %r14,%rdi
 1f78955:	mov    %r15,%rsi
 1f78958:	call   1f7d3d0 <node_facts_window_run>
 1f7895d:	mov    0x60(%r14),%eax
 1f78961:	mov    %rax,0x938(%r12)
 1f78969:	mov    0x920(%r14),%rax
 1f78970:	mov    %rax,0x940(%r12)
 1f78978:	mov    0x68(%r14),%eax
 1f7897c:	sub    0x70(%r14),%eax
 1f78980:	mov    %rax,0x948(%r12)
 1f78988:	mov    0x928(%r14),%rax
 1f7898f:	mov    %rax,0x950(%r12)
 1f78997:	mov    0x8f8(%r14),%rax
 1f7899e:	mov    %rax,0x958(%r12)
 1f789a6:	mov    0x900(%r14),%rax
 1f789ad:	mov    %rax,0x960(%r12)
 1f789b5:	mov    0x78(%r14),%eax
 1f789b9:	mov    %rax,0x968(%r12)
 1f789c1:	mov    0xa8(%r14),%eax
 1f789c8:	mov    %rax,0x970(%r12)
 1f789d0:	mov    0xd0(%r14),%rax
 1f789d7:	mov    %rax,0xa40(%r12)
 1f789df:	mov    0xd8(%r14),%rax
 1f789e6:	mov    %rax,0xa48(%r12)
 1f789ee:	movl   $0x0,0x250(%r14)
 1f789f9:	movq   $0x0,0x258(%r14)
 1f78a04:	movl   $0xffffffff,0x260(%r14)
 1f78a0f:	mov    0x248(%r14),%rax
 1f78a16:	movl   $0x0,(%rax)
 1f78a1c:	movzbl 0x9b0(%r14),%eax
 1f78a24:	shl    $0xc,%eax
 1f78a27:	mov    %eax,0x74(%r14)
 1f78a2b:	movl   $0x0,0x9a8(%r14)
 1f78a36:	movl   $0x0,0xa90(%r14)
 1f78a41:	incq   0xb30(%r14)
 1f78a48:	cmpq   $0x0,0xc20(%r14)
 1f78a50:	je     1f78a9d <node_facts_reader_flush+0x1bad>
 1f78a52:	rdtsc
 1f78a54:	mov    %rdx,%rcx
 1f78a57:	shl    $0x20,%rcx
 1f78a5b:	or     %rax,%rcx
 1f78a5e:	cmpl   $0x0,0x8(%r15)
 1f78a63:	je     1f78a89 <node_facts_reader_flush+0x1b99>
 1f78a65:	xor    %eax,%eax
 1f78a67:	vpxor  %xmm0,%xmm0,%xmm0
 1f78a6b:	nopl   0x0(%rax,%rax,1)
 1f78a70:	mov    0xc70(%r14),%rdx
 1f78a77:	mov    %eax,%esi
 1f78a79:	add    $0x40,%eax
 1f78a7c:	vmovdqu64 %zmm0,(%rdx,%rsi,1)
 1f78a83:	cmp    0x8(%r15),%eax
 1f78a87:	jb     1f78a70 <node_facts_reader_flush+0x1b80>
 1f78a89:	rdtsc
 1f78a8b:	shl    $0x20,%rdx
 1f78a8f:	or     %rax,%rdx
 1f78a92:	sub    %rcx,%rdx
 1f78a95:	add    %rdx,0xcc8(%r12)
 1f78a9d:	add    $0x58,%rsp
 1f78aa1:	pop    %rbx
 1f78aa2:	pop    %r12
 1f78aa4:	pop    %r13
 1f78aa6:	pop    %r14
 1f78aa8:	pop    %r15
 1f78aaa:	pop    %rbp
 1f78aab:	vzeroupper
 1f78aae:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
