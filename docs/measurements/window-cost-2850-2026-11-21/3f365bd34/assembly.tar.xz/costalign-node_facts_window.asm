
results/costalign/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f7bdc0 <node_facts_window>:
 1f7bdc0:	push   %rbp
 1f7bdc1:	push   %r15
 1f7bdc3:	push   %r14
 1f7bdc5:	push   %r13
 1f7bdc7:	push   %r12
 1f7bdc9:	push   %rbx
 1f7bdca:	sub    $0xa8,%rsp
 1f7bdd1:	mov    0x248(%rdi),%rax
 1f7bdd8:	mov    %ecx,%ebp
 1f7bdda:	mov    %esi,%ecx
 1f7bddc:	inc    %esi
 1f7bdde:	mov    %edx,0xc(%rsp)
 1f7bde2:	mov    %rdi,%r12
 1f7bde5:	mov    (%rax,%rcx,4),%r13d
 1f7bde9:	mov    (%rax,%rsi,4),%r8d
 1f7bded:	test   %ebp,%ebp
 1f7bdef:	je     1f7c02f <node_facts_window+0x26f>
 1f7bdf5:	rdtsc
 1f7bdf7:	shl    $0x20,%rdx
 1f7bdfb:	or     %rax,%rdx
 1f7bdfe:	mov    %rdx,0x60(%rsp)
 1f7be03:	mov    %r12,0x20(%rsp)
 1f7be08:	mov    %r13,0x30(%rsp)
 1f7be0d:	cmp    %r13d,%r8d
 1f7be10:	je     1f7c04b <node_facts_window+0x28b>
 1f7be16:	vmovdqa64 -0x1ac5760(%rip),%zmm1        # 4b66c0 <abi_test_hex.digits+0xb340>
 1f7be20:	vpbroadcastb -0x1ac5729(%rip),%xmm2        # 4b6700 <abi_test_hex.digits+0xb380>
 1f7be29:	vpbroadcastb -0x1ac5731(%rip),%xmm3        # 4b6701 <abi_test_hex.digits+0xb381>
 1f7be32:	vpbroadcastq -0x19ad93b(%rip),%xmm4        # 5ce500 <.LCPI0_8>
 1f7be3b:	vpbroadcastd -0x19aaf1d(%rip),%zmm5        # 5d0f28 <.LCPI0_4>
 1f7be45:	vpbroadcastd -0x19aaf23(%rip),%zmm6        # 5d0f2c <.LCPI0_5>
 1f7be4f:	mov    0x1f8(%r12),%rsi
 1f7be57:	mov    0x200(%r12),%rdi
 1f7be5f:	mov    0x2c8(%r12),%rax
 1f7be67:	mov    0x2d0(%r12),%rcx
 1f7be6f:	mov    0x2d8(%r12),%rdx
 1f7be77:	mov    %r13,%r9
 1f7be7a:	sub    %r9d,%r8d
 1f7be7d:	mov    $0x10,%r10d
 1f7be83:	mov    $0xffffffff,%r11d
 1f7be89:	mov    %ebp,%r13d
 1f7be8c:	vpxor  %xmm0,%xmm0,%xmm0
 1f7be90:	xor    %r12d,%r12d
 1f7be93:	xor    %ebx,%ebx
 1f7be95:	xor    %r15d,%r15d
 1f7be98:	mov    %r8d,%ebp
 1f7be9b:	add    %r9,%rsi
 1f7be9e:	add    %r9,%rdi
 1f7bea1:	mov    %r8d,%r9d
 1f7bea4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7beb0:	sub    $0x10,%ebp
 1f7beb3:	mov    %r15d,%r14d
 1f7beb6:	mov    %r12d,%r15d
 1f7beb9:	cmovae %r10d,%r8d
 1f7bebd:	shlx   %r8d,%r11d,%r8d
 1f7bec2:	not    %r8d
 1f7bec5:	kmovd  %r8d,%k1
 1f7beca:	mov    %r12d,%r8d
 1f7becd:	vmovdqu8 (%rsi,%rbx,1),%xmm7{%k1}{z}
 1f7bed4:	vpand  %xmm2,%xmm7,%xmm7
 1f7bed8:	vpcmpeqb %xmm3,%xmm7,%k2{%k1}
 1f7bede:	vpcmpeqb %xmm2,%xmm7,%k1{%k1}
 1f7bee4:	vmovdqu8 (%rdi,%rbx,1),%xmm7{%k1}{z}
 1f7beeb:	vpxor  %xmm8,%xmm8,%xmm8
 1f7bef0:	vpcompressd %zmm1,%zmm8{%k2}{z}
 1f7bef6:	vpxor  %xmm10,%xmm10,%xmm10
 1f7befb:	vpcompressd %zmm1,%zmm10{%k1}{z}
 1f7bf01:	vpaddd %zmm6,%zmm1,%zmm1
 1f7bf07:	add    $0x10,%rbx
 1f7bf0b:	vmovdqu64 %zmm8,(%rax,%r8,4)
 1f7bf12:	mov    %r14d,%r8d
 1f7bf15:	vmovdqu64 %zmm10,(%rcx,%r8,4)
 1f7bf1c:	vxorps %xmm9,%xmm9,%xmm9
 1f7bf21:	vpcompressb %xmm7,%xmm9{%k1}{z}
 1f7bf27:	vgf2p8affineqb $0x0,%xmm4,%xmm7,%xmm7
 1f7bf2d:	vmovdqu %xmm9,(%rdx,%r8,1)
 1f7bf33:	kmovw  %k2,%r8d
 1f7bf37:	vpmovzxbd %xmm7,%zmm7
 1f7bf3d:	popcnt %r8d,%r12d
 1f7bf42:	kmovw  %k1,%r8d
 1f7bf46:	add    %r15d,%r12d
 1f7bf49:	popcnt %r8d,%r15d
 1f7bf4e:	mov    %ebp,%r8d
 1f7bf51:	add    %r14d,%r15d
 1f7bf54:	vpsllvd %zmm7,%zmm5,%zmm7{%k1}{z}
 1f7bf5a:	vporq  %zmm7,%zmm0,%zmm0
 1f7bf60:	cmp    %r9,%rbx
 1f7bf63:	jb     1f7beb0 <node_facts_window+0xf0>
 1f7bf69:	mov    %r12,0x38(%rsp)
 1f7bf6e:	mov    0x20(%rsp),%r12
 1f7bf73:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f7bf7a:	vporq  %zmm1,%zmm0,%zmm0
 1f7bf80:	vextracti128 $0x1,%ymm0,%xmm1
 1f7bf86:	vpor   %xmm1,%xmm0,%xmm0
 1f7bf8a:	vpshufd $0xee,%xmm0,%xmm1
 1f7bf8f:	mov    0x2d0(%r12),%rdi
 1f7bf97:	mov    0x2d8(%r12),%rax
 1f7bf9f:	vpor   %xmm1,%xmm0,%xmm0
 1f7bfa3:	lea    0x2e0(%r12),%rcx
 1f7bfab:	movl   $0x0,0x3e8(%r12)
 1f7bfb7:	vpshufd $0x55,%xmm0,%xmm1
 1f7bfbc:	mov    %rcx,0x68(%rsp)
 1f7bfc1:	vpor   %xmm1,%xmm0,%xmm0
 1f7bfc5:	vmovd  %xmm0,0x2c(%rsp)
 1f7bfcb:	vpxor  %xmm0,%xmm0,%xmm0
 1f7bfcf:	vmovdqu64 %zmm0,0x2e8(%r12)
 1f7bfda:	vmovdqu64 %zmm0,0x328(%r12)
 1f7bfe5:	vmovdqu64 %zmm0,0x368(%r12)
 1f7bff0:	vmovdqu64 %zmm0,0x3a8(%r12)
 1f7bffb:	test   %r15d,%r15d
 1f7bffe:	je     1f7c0e1 <node_facts_window+0x321>
 1f7c004:	mov    0x2e0(%r12),%rdx
 1f7c00c:	mov    %r15d,%r8d
 1f7c00f:	mov    %r8d,%esi
 1f7c012:	lea    0x2e8(%r12),%rcx
 1f7c01a:	and    $0x7,%esi
 1f7c01d:	cmp    $0x8,%r15d
 1f7c021:	jae    1f7c0e9 <node_facts_window+0x329>
 1f7c027:	xor    %r9d,%r9d
 1f7c02a:	jmp    1f7c291 <node_facts_window+0x4d1>
 1f7c02f:	movq   $0x0,0x60(%rsp)
 1f7c038:	mov    %r12,0x20(%rsp)
 1f7c03d:	mov    %r13,0x30(%rsp)
 1f7c042:	cmp    %r13d,%r8d
 1f7c045:	jne    1f7be16 <node_facts_window+0x56>
 1f7c04b:	lea    0x2e0(%r12),%rax
 1f7c053:	vpxor  %xmm0,%xmm0,%xmm0
 1f7c057:	vmovdqu64 %zmm0,0x3a8(%r12)
 1f7c062:	vmovdqu64 %zmm0,0x368(%r12)
 1f7c06d:	vmovdqu64 %zmm0,0x328(%r12)
 1f7c078:	vmovdqu64 %zmm0,0x2e8(%r12)
 1f7c083:	movl   $0x0,0x3e8(%r12)
 1f7c08f:	movq   $0x0,0x38(%rsp)
 1f7c098:	xor    %r15d,%r15d
 1f7c09b:	movl   $0x0,0x2c(%rsp)
 1f7c0a3:	mov    %rax,0x68(%rsp)
 1f7c0a8:	cmpl   $0x0,0xc(%rsp)
 1f7c0ad:	jne    1f7c2f6 <node_facts_window+0x536>
 1f7c0b3:	mov    0x38(%rsp),%rdx
 1f7c0b8:	mov    %r12,%rdi
 1f7c0bb:	mov    %r13d,%esi
 1f7c0be:	vzeroupper
 1f7c0c1:	call   1f84ff0 <node_facts_leaves>
 1f7c0c6:	test   %bpl,%bpl
 1f7c0c9:	jne    1f7c312 <node_facts_window+0x552>
 1f7c0cf:	xor    %ebx,%ebx
 1f7c0d1:	cmpl   $0x0,0x2c(%rsp)
 1f7c0d6:	jne    1f7c329 <node_facts_window+0x569>
 1f7c0dc:	jmp    1f7c989 <node_facts_window+0xbc9>
 1f7c0e1:	xor    %r15d,%r15d
 1f7c0e4:	jmp    1f7c9ef <node_facts_window+0xc2f>
 1f7c0e9:	and    $0xfffffff8,%r8d
 1f7c0ed:	mov    $0x40,%r10d
 1f7c0f3:	xor    %r9d,%r9d
 1f7c0f6:	cs nopw 0x0(%rax,%rax,1)
 1f7c100:	movzbl (%rax,%r9,1),%r11d
 1f7c105:	mov    (%rdi,%r9,4),%ebp
 1f7c109:	cmp    $0x40,%r11b
 1f7c10d:	cmovae %r10d,%r11d
 1f7c111:	movzbl %r11b,%r11d
 1f7c115:	mov    (%rcx,%r11,4),%ebx
 1f7c119:	mov    %r11d,%r14d
 1f7c11c:	shl    $0xe,%r14d
 1f7c120:	add    %rdx,%r14
 1f7c123:	mov    %ebp,(%r14,%rbx,4)
 1f7c127:	inc    %ebx
 1f7c129:	mov    %ebx,(%rcx,%r11,4)
 1f7c12d:	movzbl 0x1(%rax,%r9,1),%r11d
 1f7c133:	mov    0x4(%rdi,%r9,4),%ebp
 1f7c138:	cmp    $0x40,%r11b
 1f7c13c:	cmovae %r10d,%r11d
 1f7c140:	movzbl %r11b,%r11d
 1f7c144:	mov    (%rcx,%r11,4),%ebx
 1f7c148:	mov    %r11d,%r14d
 1f7c14b:	shl    $0xe,%r14d
 1f7c14f:	add    %rdx,%r14
 1f7c152:	mov    %ebp,(%r14,%rbx,4)
 1f7c156:	inc    %ebx
 1f7c158:	mov    %ebx,(%rcx,%r11,4)
 1f7c15c:	movzbl 0x2(%rax,%r9,1),%r11d
 1f7c162:	mov    0x8(%rdi,%r9,4),%ebp
 1f7c167:	cmp    $0x40,%r11b
 1f7c16b:	cmovae %r10d,%r11d
 1f7c16f:	movzbl %r11b,%r11d
 1f7c173:	mov    (%rcx,%r11,4),%ebx
 1f7c177:	mov    %r11d,%r14d
 1f7c17a:	shl    $0xe,%r14d
 1f7c17e:	add    %rdx,%r14
 1f7c181:	mov    %ebp,(%r14,%rbx,4)
 1f7c185:	inc    %ebx
 1f7c187:	mov    %ebx,(%rcx,%r11,4)
 1f7c18b:	movzbl 0x3(%rax,%r9,1),%r11d
 1f7c191:	mov    0xc(%rdi,%r9,4),%ebp
 1f7c196:	cmp    $0x40,%r11b
 1f7c19a:	cmovae %r10d,%r11d
 1f7c19e:	movzbl %r11b,%r11d
 1f7c1a2:	mov    (%rcx,%r11,4),%ebx
 1f7c1a6:	mov    %r11d,%r14d
 1f7c1a9:	shl    $0xe,%r14d
 1f7c1ad:	add    %rdx,%r14
 1f7c1b0:	mov    %ebp,(%r14,%rbx,4)
 1f7c1b4:	inc    %ebx
 1f7c1b6:	mov    %ebx,(%rcx,%r11,4)
 1f7c1ba:	movzbl 0x4(%rax,%r9,1),%r11d
 1f7c1c0:	mov    0x10(%rdi,%r9,4),%ebp
 1f7c1c5:	cmp    $0x40,%r11b
 1f7c1c9:	cmovae %r10d,%r11d
 1f7c1cd:	movzbl %r11b,%r11d
 1f7c1d1:	mov    (%rcx,%r11,4),%ebx
 1f7c1d5:	mov    %r11d,%r14d
 1f7c1d8:	shl    $0xe,%r14d
 1f7c1dc:	add    %rdx,%r14
 1f7c1df:	mov    %ebp,(%r14,%rbx,4)
 1f7c1e3:	inc    %ebx
 1f7c1e5:	mov    %ebx,(%rcx,%r11,4)
 1f7c1e9:	movzbl 0x5(%rax,%r9,1),%r11d
 1f7c1ef:	mov    0x14(%rdi,%r9,4),%ebp
 1f7c1f4:	cmp    $0x40,%r11b
 1f7c1f8:	cmovae %r10d,%r11d
 1f7c1fc:	movzbl %r11b,%r11d
 1f7c200:	mov    (%rcx,%r11,4),%ebx
 1f7c204:	mov    %r11d,%r14d
 1f7c207:	shl    $0xe,%r14d
 1f7c20b:	add    %rdx,%r14
 1f7c20e:	mov    %ebp,(%r14,%rbx,4)
 1f7c212:	inc    %ebx
 1f7c214:	mov    %ebx,(%rcx,%r11,4)
 1f7c218:	movzbl 0x6(%rax,%r9,1),%r11d
 1f7c21e:	mov    0x18(%rdi,%r9,4),%ebp
 1f7c223:	cmp    $0x40,%r11b
 1f7c227:	cmovae %r10d,%r11d
 1f7c22b:	movzbl %r11b,%r11d
 1f7c22f:	mov    (%rcx,%r11,4),%ebx
 1f7c233:	mov    %r11d,%r14d
 1f7c236:	shl    $0xe,%r14d
 1f7c23a:	add    %rdx,%r14
 1f7c23d:	mov    %ebp,(%r14,%rbx,4)
 1f7c241:	inc    %ebx
 1f7c243:	mov    %ebx,(%rcx,%r11,4)
 1f7c247:	movzbl 0x7(%rax,%r9,1),%r11d
 1f7c24d:	mov    0x1c(%rdi,%r9,4),%ebp
 1f7c252:	cmp    $0x40,%r11b
 1f7c256:	cmovae %r10d,%r11d
 1f7c25a:	add    $0x8,%r9
 1f7c25e:	movzbl %r11b,%r11d
 1f7c262:	mov    (%rcx,%r11,4),%ebx
 1f7c266:	mov    %r11d,%r14d
 1f7c269:	shl    $0xe,%r14d
 1f7c26d:	add    %rdx,%r14
 1f7c270:	mov    %ebp,(%r14,%rbx,4)
 1f7c274:	inc    %ebx
 1f7c276:	mov    %ebx,(%rcx,%r11,4)
 1f7c27a:	cmp    %r9,%r8
 1f7c27d:	jne    1f7c100 <node_facts_window+0x340>
 1f7c283:	mov    0x20(%rsp),%r12
 1f7c288:	test   %rsi,%rsi
 1f7c28b:	je     1f7c9ef <node_facts_window+0xc2f>
 1f7c291:	lea    (%rdi,%r9,4),%rdi
 1f7c295:	add    %r9,%rax
 1f7c298:	mov    $0x40,%r9d
 1f7c29e:	xor    %r8d,%r8d
 1f7c2a1:	mov    %r13d,%ebp
 1f7c2a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c2b0:	movzbl (%rax,%r8,1),%r10d
 1f7c2b5:	mov    (%rdi,%r8,4),%ebx
 1f7c2b9:	cmp    $0x40,%r10b
 1f7c2bd:	cmovae %r9d,%r10d
 1f7c2c1:	inc    %r8
 1f7c2c4:	movzbl %r10b,%r10d
 1f7c2c8:	mov    (%rcx,%r10,4),%r11d
 1f7c2cc:	mov    %r10d,%r14d
 1f7c2cf:	shl    $0xe,%r14d
 1f7c2d3:	add    %rdx,%r14
 1f7c2d6:	mov    %ebx,(%r14,%r11,4)
 1f7c2da:	inc    %r11d
 1f7c2dd:	mov    %r11d,(%rcx,%r10,4)
 1f7c2e1:	cmp    %r8,%rsi
 1f7c2e4:	jne    1f7c2b0 <node_facts_window+0x4f0>
 1f7c2e6:	mov    0x30(%rsp),%r13
 1f7c2eb:	cmpl   $0x0,0xc(%rsp)
 1f7c2f0:	je     1f7c0b3 <node_facts_window+0x2f3>
 1f7c2f6:	mov    0x38(%rsp),%rdx
 1f7c2fb:	mov    %r12,%rdi
 1f7c2fe:	mov    %r13d,%esi
 1f7c301:	vzeroupper
 1f7c304:	call   1f850c0 <node_facts_leaves_lean>
 1f7c309:	test   %bpl,%bpl
 1f7c30c:	je     1f7c0cf <node_facts_window+0x30f>
 1f7c312:	rdtsc
 1f7c314:	mov    %rdx,%rbx
 1f7c317:	shl    $0x20,%rbx
 1f7c31b:	or     %rax,%rbx
 1f7c31e:	cmpl   $0x0,0x2c(%rsp)
 1f7c323:	je     1f7c989 <node_facts_window+0xbc9>
 1f7c329:	lea    0x2e8(%r12),%r14
 1f7c331:	mov    %r15d,0x44(%rsp)
 1f7c336:	mov    %rbx,0x78(%rsp)
 1f7c33b:	mov    %ebp,0x48(%rsp)
 1f7c33f:	xor    %ecx,%ecx
 1f7c341:	xor    %r15d,%r15d
 1f7c344:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c350:	mov    %rcx,0x70(%rsp)
 1f7c355:	mov    (%r14),%ecx
 1f7c358:	mov    0x4(%r14),%ebp
 1f7c35c:	mov    0x8(%r14),%eax
 1f7c360:	mov    0xc(%r14),%edx
 1f7c364:	mov    0x10(%r14),%esi
 1f7c368:	vmovups 0x1c(%r14),%ymm0
 1f7c36e:	test   %ecx,%ecx
 1f7c370:	mov    %edx,0x50(%rsp)
 1f7c374:	mov    %esi,0x54(%rsp)
 1f7c378:	mov    %eax,0x4c(%rsp)
 1f7c37c:	setne  0x1b(%rsp)
 1f7c381:	test   %ebp,%ebp
 1f7c383:	setne  0x1a(%rsp)
 1f7c388:	test   %eax,%eax
 1f7c38a:	setne  0x1c(%rsp)
 1f7c38f:	test   %edx,%edx
 1f7c391:	mov    0x14(%r14),%edx
 1f7c395:	vmovups %ymm0,0x80(%rsp)
 1f7c39e:	setne  0x1f(%rsp)
 1f7c3a3:	test   %esi,%esi
 1f7c3a5:	mov    0x18(%r14),%esi
 1f7c3a9:	setne  0x19(%rsp)
 1f7c3ae:	xor    %ebx,%ebx
 1f7c3b0:	test   %edx,%edx
 1f7c3b2:	mov    %edx,0x58(%rsp)
 1f7c3b6:	mov    0x68(%rsp),%rdx
 1f7c3bb:	setne  0x1e(%rsp)
 1f7c3c0:	xor    %r12d,%r12d
 1f7c3c3:	test   %esi,%esi
 1f7c3c5:	mov    %esi,0x5c(%rsp)
 1f7c3c9:	setne  0x1d(%rsp)
 1f7c3ce:	mov    (%rdx),%rax
 1f7c3d1:	mov    %rax,0x10(%rsp)
 1f7c3d6:	test   %ecx,%ecx
 1f7c3d8:	je     1f7c400 <node_facts_window+0x640>
 1f7c3da:	mov    0x10(%rsp),%rax
 1f7c3df:	lea    (%rax,%r15,1),%rdx
 1f7c3e3:	mov    0xc(%rsp),%eax
 1f7c3e7:	test   %eax,%eax
 1f7c3e9:	je     1f7c410 <node_facts_window+0x650>
 1f7c3eb:	cmp    $0x1,%eax
 1f7c3ee:	jne    1f7c44c <node_facts_window+0x68c>
 1f7c3f0:	mov    0x20(%rsp),%rdi
 1f7c3f5:	mov    %r13d,%esi
 1f7c3f8:	vzeroupper
 1f7c3fb:	call   1f85440 <node_facts_arrows_lean>
 1f7c400:	test   %ebp,%ebp
 1f7c402:	mov    0x20(%rsp),%rbp
 1f7c407:	jne    1f7c465 <node_facts_window+0x6a5>
 1f7c409:	jmp    1f7c4ae <node_facts_window+0x6ee>
 1f7c40e:	xchg   %ax,%ax
 1f7c410:	mov    0x20(%rsp),%r13
 1f7c415:	mov    0x30(%rsp),%rsi
 1f7c41a:	mov    %r13,%rdi
 1f7c41d:	vzeroupper
 1f7c420:	call   1f85170 <node_facts_arrows>
 1f7c425:	test   %ebp,%ebp
 1f7c427:	mov    %r13,%rbp
 1f7c42a:	mov    0x30(%rsp),%r13
 1f7c42f:	je     1f7c4ae <node_facts_window+0x6ee>
 1f7c431:	mov    0x70(%rsp),%rdx
 1f7c436:	mov    0x4(%r14),%ecx
 1f7c43a:	shl    $0x12,%rdx
 1f7c43e:	add    0x10(%rsp),%rdx
 1f7c443:	add    $0x4000,%rdx
 1f7c44a:	jmp    1f7c4a0 <node_facts_window+0x6e0>
 1f7c44c:	mov    0x20(%rsp),%rdi
 1f7c451:	mov    %r13d,%esi
 1f7c454:	vzeroupper
 1f7c457:	call   1f856c0 <node_facts_arrows_loads>
 1f7c45c:	test   %ebp,%ebp
 1f7c45e:	mov    0x20(%rsp),%rbp
 1f7c463:	je     1f7c4ae <node_facts_window+0x6ee>
 1f7c465:	mov    0x10(%rsp),%rax
 1f7c46a:	mov    0x4(%r14),%ecx
 1f7c46e:	lea    0x4000(%rax,%r15,1),%rdx
 1f7c476:	mov    0xc(%rsp),%eax
 1f7c47a:	test   %eax,%eax
 1f7c47c:	je     1f7c4a0 <node_facts_window+0x6e0>
 1f7c47e:	mov    %rbp,%rdi
 1f7c481:	mov    %r13d,%esi
 1f7c484:	cmp    $0x1,%eax
 1f7c487:	jne    1f7c504 <node_facts_window+0x744>
 1f7c489:	vzeroupper
 1f7c48c:	call   1f85d20 <node_facts_subscripts_lean>
 1f7c491:	cmpl   $0x0,0x4c(%rsp)
 1f7c496:	jne    1f7c4b5 <node_facts_window+0x6f5>
 1f7c498:	jmp    1f7c520 <node_facts_window+0x760>
 1f7c49d:	nopl   (%rax)
 1f7c4a0:	mov    %rbp,%rdi
 1f7c4a3:	mov    %r13d,%esi
 1f7c4a6:	vzeroupper
 1f7c4a9:	call   1f858a0 <node_facts_subscripts>
 1f7c4ae:	cmpl   $0x0,0x4c(%rsp)
 1f7c4b3:	je     1f7c520 <node_facts_window+0x760>
 1f7c4b5:	mov    0x10(%rsp),%rax
 1f7c4ba:	mov    0x8(%r14),%ecx
 1f7c4be:	mov    %rbp,%rdi
 1f7c4c1:	mov    %r13d,%esi
 1f7c4c4:	lea    0x8000(%rax,%r15,1),%rdx
 1f7c4cc:	mov    0xc(%rsp),%eax
 1f7c4d0:	test   %eax,%eax
 1f7c4d2:	je     1f7c4f0 <node_facts_window+0x730>
 1f7c4d4:	cmp    $0x1,%eax
 1f7c4d7:	jne    1f7c4fa <node_facts_window+0x73a>
 1f7c4d9:	vzeroupper
 1f7c4dc:	call   1f866f0 <node_facts_dots_lean>
 1f7c4e1:	jmp    1f7c520 <node_facts_window+0x760>
 1f7c4e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c4f0:	vzeroupper
 1f7c4f3:	call   1f863c0 <node_facts_dots>
 1f7c4f8:	jmp    1f7c520 <node_facts_window+0x760>
 1f7c4fa:	vzeroupper
 1f7c4fd:	call   1f869f0 <node_facts_dots_loads>
 1f7c502:	jmp    1f7c520 <node_facts_window+0x760>
 1f7c504:	vzeroupper
 1f7c507:	call   1f86100 <node_facts_subscripts_loads>
 1f7c50c:	cmpl   $0x0,0x4c(%rsp)
 1f7c511:	jne    1f7c4b5 <node_facts_window+0x6f5>
 1f7c513:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c520:	cmpl   $0x0,0x50(%rsp)
 1f7c525:	je     1f7c552 <node_facts_window+0x792>
 1f7c527:	mov    0x10(%rsp),%rax
 1f7c52c:	xor    %r8d,%r8d
 1f7c52f:	cmpl   $0x0,0xc(%rsp)
 1f7c534:	mov    0xc(%r14),%ecx
 1f7c538:	mov    %rbp,%rdi
 1f7c53b:	mov    %r13d,%esi
 1f7c53e:	lea    0xc000(%rax,%r15,1),%rdx
 1f7c546:	setne  %r8b
 1f7c54a:	vzeroupper
 1f7c54d:	call   1f86be0 <node_facts_addresses_made>
 1f7c552:	cmpl   $0x0,0x54(%rsp)
 1f7c557:	je     1f7c584 <node_facts_window+0x7c4>
 1f7c559:	mov    0x10(%rsp),%rax
 1f7c55e:	xor    %r8d,%r8d
 1f7c561:	cmpl   $0x0,0xc(%rsp)
 1f7c566:	mov    0x10(%r14),%ecx
 1f7c56a:	mov    %rbp,%rdi
 1f7c56d:	mov    %r13d,%esi
 1f7c570:	lea    0x10000(%rax,%r15,1),%rdx
 1f7c578:	setne  %r8b
 1f7c57c:	vzeroupper
 1f7c57f:	call   1f86df0 <node_facts_casts>
 1f7c584:	cmpl   $0x0,0x58(%rsp)
 1f7c589:	je     1f7c5aa <node_facts_window+0x7ea>
 1f7c58b:	mov    0x10(%rsp),%rax
 1f7c590:	mov    0x14(%r14),%ecx
 1f7c594:	mov    %rbp,%rdi
 1f7c597:	mov    %r13d,%esi
 1f7c59a:	lea    0x14000(%rax,%r15,1),%rdx
 1f7c5a2:	vzeroupper
 1f7c5a5:	call   1f873b0 <node_facts_slow_list>
 1f7c5aa:	cmpl   $0x0,0x5c(%rsp)
 1f7c5af:	je     1f7c5dc <node_facts_window+0x81c>
 1f7c5b1:	mov    0x10(%rsp),%rax
 1f7c5b6:	xor    %r8d,%r8d
 1f7c5b9:	cmpl   $0x0,0xc(%rsp)
 1f7c5be:	mov    0x18(%r14),%ecx
 1f7c5c2:	mov    %rbp,%rdi
 1f7c5c5:	mov    %r13d,%esi
 1f7c5c8:	lea    0x18000(%rax,%r15,1),%rdx
 1f7c5d0:	setne  %r8b
 1f7c5d4:	vzeroupper
 1f7c5d7:	call   1f873f0 <node_facts_rows_made>
 1f7c5dc:	movzbl 0x1b(%rsp),%ecx
 1f7c5e1:	movzbl 0x1a(%rsp),%edx
 1f7c5e6:	xor    %eax,%eax
 1f7c5e8:	movzbl 0x1f(%rsp),%esi
 1f7c5ed:	vmovdqu 0x80(%rsp),%ymm0
 1f7c5f6:	mov    %cl,%al
 1f7c5f8:	xor    %ecx,%ecx
 1f7c5fa:	mov    %dl,%cl
 1f7c5fc:	movzbl 0x1c(%rsp),%edx
 1f7c601:	lea    (%rax,%rcx,2),%eax
 1f7c604:	xor    %ecx,%ecx
 1f7c606:	vptestnmd %ymm0,%ymm0,%k1
 1f7c60c:	mov    %dl,%cl
 1f7c60e:	xor    %edx,%edx
 1f7c610:	lea    (%rax,%rcx,4),%eax
 1f7c613:	movzbl 0x19(%rsp),%ecx
 1f7c618:	kshiftrb $0x1,%k1,%k0
 1f7c61e:	kmovw  %k1,0x80(%rsp)
 1f7c627:	mov    %cl,%dl
 1f7c629:	xor    %ecx,%ecx
 1f7c62b:	mov    %sil,%cl
 1f7c62e:	lea    (%rax,%rcx,8),%eax
 1f7c631:	movzbl 0x1e(%rsp),%ecx
 1f7c636:	shl    $0x4,%edx
 1f7c639:	or     %edx,%eax
 1f7c63b:	mov    %cl,%bl
 1f7c63d:	kmovd  %k1,%ecx
 1f7c641:	shl    $0x5,%ebx
 1f7c644:	not    %cl
 1f7c646:	or     %eax,%ebx
 1f7c648:	movzbl 0x1d(%rsp),%eax
 1f7c64d:	movzbl %cl,%ecx
 1f7c650:	and    $0x1,%ecx
 1f7c653:	shl    $0x7,%ecx
 1f7c656:	mov    %al,%r12b
 1f7c659:	kmovd  %k0,%eax
 1f7c65d:	shl    $0x6,%r12d
 1f7c661:	not    %al
 1f7c663:	or     %ebx,%r12d
 1f7c666:	movzbl %al,%ebx
 1f7c669:	and    $0x1,%ebx
 1f7c66c:	shl    $0x8,%ebx
 1f7c66f:	or     %ecx,%ebx
 1f7c671:	or     %r12d,%ebx
 1f7c674:	mov    0xc(%rsp),%r12d
 1f7c679:	test   %bl,%bl
 1f7c67b:	jns    1f7c6c0 <node_facts_window+0x900>
 1f7c67d:	mov    0x10(%rsp),%rax
 1f7c682:	mov    0x1c(%r14),%ecx
 1f7c686:	mov    %rbp,%rdi
 1f7c689:	mov    %r13d,%esi
 1f7c68c:	lea    0x1c000(%rax,%r15,1),%rdx
 1f7c694:	test   %r12d,%r12d
 1f7c697:	je     1f7c6b5 <node_facts_window+0x8f5>
 1f7c699:	cmp    $0x1,%r12d
 1f7c69d:	jne    1f7c7a3 <node_facts_window+0x9e3>
 1f7c6a3:	vzeroupper
 1f7c6a6:	call   1f88140 <node_facts_calls_lean>
 1f7c6ab:	test   $0x100,%ebx
 1f7c6b1:	jne    1f7c6c8 <node_facts_window+0x908>
 1f7c6b3:	jmp    1f7c6f1 <node_facts_window+0x931>
 1f7c6b5:	vzeroupper
 1f7c6b8:	call   1f87790 <node_facts_calls>
 1f7c6bd:	nopl   (%rax)
 1f7c6c0:	test   $0x100,%ebx
 1f7c6c6:	je     1f7c6f1 <node_facts_window+0x931>
 1f7c6c8:	mov    0x10(%rsp),%rax
 1f7c6cd:	mov    0x20(%r14),%ecx
 1f7c6d1:	xor    %r8d,%r8d
 1f7c6d4:	test   %r12d,%r12d
 1f7c6d7:	mov    %rbp,%rdi
 1f7c6da:	mov    %r13d,%esi
 1f7c6dd:	setne  %r8b
 1f7c6e1:	lea    0x20000(%rax,%r15,1),%rdx
 1f7c6e9:	vzeroupper
 1f7c6ec:	call   1f88d00 <node_facts_logics>
 1f7c6f1:	kmovw  0x80(%rsp),%k1
 1f7c6fa:	kshiftrb $0x3,%k1,%k0
 1f7c700:	kmovd  %k0,%eax
 1f7c704:	kshiftrb $0x2,%k1,%k0
 1f7c70a:	kmovd  %k0,%ecx
 1f7c70e:	not    %al
 1f7c710:	not    %cl
 1f7c712:	movzbl %al,%ebp
 1f7c715:	movzbl %cl,%ecx
 1f7c718:	and    $0x1,%ebp
 1f7c71b:	and    $0x1,%ecx
 1f7c71e:	shl    $0xa,%ebp
 1f7c721:	shl    $0x9,%ecx
 1f7c724:	or     %ecx,%ebp
 1f7c726:	or     %ebx,%ebp
 1f7c728:	test   $0x200,%ebp
 1f7c72e:	je     1f7c75b <node_facts_window+0x99b>
 1f7c730:	mov    0x10(%rsp),%rax
 1f7c735:	mov    0x24(%r14),%ecx
 1f7c739:	mov    0x20(%rsp),%rdi
 1f7c73e:	xor    %r8d,%r8d
 1f7c741:	test   %r12d,%r12d
 1f7c744:	mov    %r13d,%esi
 1f7c747:	setne  %r8b
 1f7c74b:	lea    0x24000(%rax,%r15,1),%rdx
 1f7c753:	vzeroupper
 1f7c756:	call   1f88fc0 <node_facts_updates>
 1f7c75b:	test   $0x400,%ebp
 1f7c761:	je     1f7c7d0 <node_facts_window+0xa10>
 1f7c763:	mov    0x10(%rsp),%rax
 1f7c768:	mov    0x28(%r14),%ecx
 1f7c76c:	lea    0x28000(%rax,%r15,1),%rdx
 1f7c774:	test   %r12d,%r12d
 1f7c777:	je     1f7c791 <node_facts_window+0x9d1>
 1f7c779:	cmp    $0x1,%r12d
 1f7c77d:	jne    1f7c7bc <node_facts_window+0x9fc>
 1f7c77f:	mov    0x20(%rsp),%rdi
 1f7c784:	mov    %r13d,%esi
 1f7c787:	vzeroupper
 1f7c78a:	call   1f89bf0 <node_facts_dereferences_lean>
 1f7c78f:	jmp    1f7c7d0 <node_facts_window+0xa10>
 1f7c791:	mov    0x20(%rsp),%rdi
 1f7c796:	mov    %r13d,%esi
 1f7c799:	vzeroupper
 1f7c79c:	call   1f899a0 <node_facts_dereferences>
 1f7c7a1:	jmp    1f7c7d0 <node_facts_window+0xa10>
 1f7c7a3:	vzeroupper
 1f7c7a6:	call   1f88a50 <node_facts_calls_loads>
 1f7c7ab:	test   $0x100,%ebx
 1f7c7b1:	jne    1f7c6c8 <node_facts_window+0x908>
 1f7c7b7:	jmp    1f7c6f1 <node_facts_window+0x931>
 1f7c7bc:	mov    0x20(%rsp),%rdi
 1f7c7c1:	mov    %r13d,%esi
 1f7c7c4:	vzeroupper
 1f7c7c7:	call   1f89de0 <node_facts_dereferences_loads>
 1f7c7cc:	nopl   0x0(%rax)
 1f7c7d0:	kmovw  0x80(%rsp),%k1
 1f7c7d9:	mov    0x20(%rsp),%r12
 1f7c7de:	kshiftrb $0x5,%k1,%k0
 1f7c7e4:	kmovd  %k0,%eax
 1f7c7e8:	kshiftrb $0x4,%k1,%k0
 1f7c7ee:	kmovd  %k0,%ecx
 1f7c7f2:	not    %al
 1f7c7f4:	not    %cl
 1f7c7f6:	movzbl %al,%ebx
 1f7c7f9:	movzbl %cl,%ecx
 1f7c7fc:	and    $0x1,%ebx
 1f7c7ff:	and    $0x1,%ecx
 1f7c802:	shl    $0xc,%ebx
 1f7c805:	shl    $0xb,%ecx
 1f7c808:	or     %ecx,%ebx
 1f7c80a:	or     %ebp,%ebx
 1f7c80c:	test   $0x800,%ebx
 1f7c812:	je     1f7c83f <node_facts_window+0xa7f>
 1f7c814:	mov    0x10(%rsp),%rax
 1f7c819:	xor    %r8d,%r8d
 1f7c81c:	cmpl   $0x0,0xc(%rsp)
 1f7c821:	mov    0x2c(%r14),%ecx
 1f7c825:	mov    %r12,%rdi
 1f7c828:	mov    %r13d,%esi
 1f7c82b:	lea    0x2c000(%rax,%r15,1),%rdx
 1f7c833:	setne  %r8b
 1f7c837:	vzeroupper
 1f7c83a:	call   1f89fa0 <node_facts_stores>
 1f7c83f:	test   $0x1000,%ebx
 1f7c845:	je     1f7c872 <node_facts_window+0xab2>
 1f7c847:	mov    0x10(%rsp),%rax
 1f7c84c:	xor    %r8d,%r8d
 1f7c84f:	cmpl   $0x0,0xc(%rsp)
 1f7c854:	mov    0x30(%r14),%ecx
 1f7c858:	mov    %r12,%rdi
 1f7c85b:	mov    %r13d,%esi
 1f7c85e:	lea    0x30000(%rax,%r15,1),%rdx
 1f7c866:	setne  %r8b
 1f7c86a:	vzeroupper
 1f7c86d:	call   1f8a590 <node_facts_converts>
 1f7c872:	kmovw  0x80(%rsp),%k1
 1f7c87b:	kshiftrb $0x7,%k1,%k0
 1f7c881:	kmovd  %k0,%eax
 1f7c885:	kshiftrb $0x6,%k1,%k0
 1f7c88b:	kmovd  %k0,%ecx
 1f7c88f:	not    %al
 1f7c891:	not    %cl
 1f7c893:	movzbl %al,%ebp
 1f7c896:	movzbl %cl,%ecx
 1f7c899:	and    $0x1,%ebp
 1f7c89c:	and    $0x1,%ecx
 1f7c89f:	shl    $0xe,%ebp
 1f7c8a2:	shl    $0xd,%ecx
 1f7c8a5:	or     %ecx,%ebp
 1f7c8a7:	or     %ebx,%ebp
 1f7c8a9:	test   $0x2000,%ebp
 1f7c8af:	jne    1f7c8d0 <node_facts_window+0xb10>
 1f7c8b1:	mov    0x20(%rsp),%r12
 1f7c8b6:	cmp    $0x4000,%ebp
 1f7c8bc:	jae    1f7c8fe <node_facts_window+0xb3e>
 1f7c8be:	mov    0x70(%rsp),%rcx
 1f7c8c3:	cmp    $0x2,%rcx
 1f7c8c7:	jbe    1f7c934 <node_facts_window+0xb74>
 1f7c8c9:	jmp    1f7c951 <node_facts_window+0xb91>
 1f7c8ce:	xchg   %ax,%ax
 1f7c8d0:	mov    0x10(%rsp),%rax
 1f7c8d5:	mov    0x34(%r14),%ecx
 1f7c8d9:	mov    0x20(%rsp),%rdi
 1f7c8de:	mov    %r13d,%esi
 1f7c8e1:	lea    0x34000(%rax,%r15,1),%rdx
 1f7c8e9:	vzeroupper
 1f7c8ec:	call   1f8ab10 <node_facts_discards>
 1f7c8f1:	mov    0x20(%rsp),%r12
 1f7c8f6:	cmp    $0x4000,%ebp
 1f7c8fc:	jb     1f7c8be <node_facts_window+0xafe>
 1f7c8fe:	mov    0x10(%rsp),%rax
 1f7c903:	xor    %r8d,%r8d
 1f7c906:	cmpl   $0x0,0xc(%rsp)
 1f7c90b:	mov    0x38(%r14),%ecx
 1f7c90f:	mov    %r12,%rdi
 1f7c912:	mov    %r13d,%esi
 1f7c915:	lea    0x38000(%rax,%r15,1),%rdx
 1f7c91d:	setne  %r8b
 1f7c921:	vzeroupper
 1f7c924:	call   1f8acc0 <node_facts_truths>
 1f7c929:	mov    0x70(%rsp),%rcx
 1f7c92e:	cmp    $0x2,%rcx
 1f7c932:	ja     1f7c951 <node_facts_window+0xb91>
 1f7c934:	inc    %rcx
 1f7c937:	add    $0x40000,%r15
 1f7c93e:	add    $0x40,%r14
 1f7c942:	shrx   %ecx,0x2c(%rsp),%eax
 1f7c949:	test   %eax,%eax
 1f7c94b:	jne    1f7c350 <node_facts_window+0x590>
 1f7c951:	testb  $0x10,0x2c(%rsp)
 1f7c956:	mov    0x48(%rsp),%ebp
 1f7c95a:	mov    0x44(%rsp),%r15d
 1f7c95f:	mov    0x78(%rsp),%rbx
 1f7c964:	je     1f7c989 <node_facts_window+0xbc9>
 1f7c966:	mov    $0x100000,%edx
 1f7c96b:	add    0x2e0(%r12),%rdx
 1f7c973:	mov    0x3e8(%r12),%ecx
 1f7c97b:	mov    %r12,%rdi
 1f7c97e:	mov    %r13d,%esi
 1f7c981:	vzeroupper
 1f7c984:	call   1f873b0 <node_facts_slow_list>
 1f7c989:	test   %bpl,%bpl
 1f7c98c:	je     1f7c999 <node_facts_window+0xbd9>
 1f7c98e:	rdtsc
 1f7c990:	shl    $0x20,%rdx
 1f7c994:	or     %rax,%rdx
 1f7c997:	jmp    1f7c99b <node_facts_window+0xbdb>
 1f7c999:	xor    %edx,%edx
 1f7c99b:	sub    %rbx,%rdx
 1f7c99e:	sub    0x60(%rsp),%rbx
 1f7c9a3:	mov    0x38(%rsp),%rax
 1f7c9a8:	vmovq  %rdx,%xmm0
 1f7c9ad:	vmovq  %rbx,%xmm1
 1f7c9b2:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f7c9b6:	vpaddq 0x910(%r12),%xmm0,%xmm0
 1f7c9c0:	vmovdqu %xmm0,0x910(%r12)
 1f7c9ca:	mov    %eax,0x930(%r12)
 1f7c9d2:	mov    %r15d,0x934(%r12)
 1f7c9da:	add    $0xa8,%rsp
 1f7c9e1:	pop    %rbx
 1f7c9e2:	pop    %r12
 1f7c9e4:	pop    %r13
 1f7c9e6:	pop    %r14
 1f7c9e8:	pop    %r15
 1f7c9ea:	pop    %rbp
 1f7c9eb:	vzeroupper
 1f7c9ee:	ret
 1f7c9ef:	mov    %r13d,%ebp
 1f7c9f2:	mov    0x30(%rsp),%r13
 1f7c9f7:	cmpl   $0x0,0xc(%rsp)
 1f7c9fc:	jne    1f7c2f6 <node_facts_window+0x536>
 1f7ca02:	jmp    1f7c0b3 <node_facts_window+0x2f3>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
