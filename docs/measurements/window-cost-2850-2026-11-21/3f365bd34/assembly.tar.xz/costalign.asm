
results/costalign/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f7d490 <node_facts_window_run>:
 1f7d490:	push   %rbp
 1f7d491:	push   %r15
 1f7d493:	push   %r14
 1f7d495:	push   %r13
 1f7d497:	push   %r12
 1f7d499:	push   %rbx
 1f7d49a:	sub    $0xd08,%rsp
 1f7d4a1:	mov    0x940(%rdi),%r14
 1f7d4a8:	mov    0x8(%rsi),%r15d
 1f7d4ac:	mov    %rsi,%r13
 1f7d4af:	test   %r15,%r15
 1f7d4b2:	je     1f7d677 <node_facts_window_run+0x1e7>
 1f7d4b8:	mov    %r15d,%eax
 1f7d4bb:	and    $0x7,%eax
 1f7d4be:	cmp    $0x8,%r15d
 1f7d4c2:	jae    1f7d4cb <node_facts_window_run+0x3b>
 1f7d4c4:	xor    %ecx,%ecx
 1f7d4c6:	jmp    1f7da7f <node_facts_window_run+0x5ef>
 1f7d4cb:	mov    %r15d,%edx
 1f7d4ce:	and    $0xfffffff8,%edx
 1f7d4d1:	xor    %ecx,%ecx
 1f7d4d3:	jmp    1f7d4fb <node_facts_window_run+0x6b>
 1f7d4d5:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7d4e0:	xor    %esi,%esi
 1f7d4e2:	mov    0x9c0(%rdi),%r8
 1f7d4e9:	mov    %sil,0x7(%r8,%rcx,1)
 1f7d4ee:	add    $0x8,%rcx
 1f7d4f2:	cmp    %rcx,%rdx
 1f7d4f5:	je     1f7d66e <node_facts_window_run+0x1de>
 1f7d4fb:	mov    0x9b8(%rdi),%rsi
 1f7d502:	cmpb   $0x0,(%rsi,%rcx,1)
 1f7d506:	je     1f7d520 <node_facts_window_run+0x90>
 1f7d508:	movzbl 0x69454(%r13,%rcx,1),%esi
 1f7d511:	jmp    1f7d522 <node_facts_window_run+0x92>
 1f7d513:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d520:	xor    %esi,%esi
 1f7d522:	mov    0x9c0(%rdi),%r8
 1f7d529:	mov    %sil,(%r8,%rcx,1)
 1f7d52d:	mov    0x9b8(%rdi),%rsi
 1f7d534:	cmpb   $0x0,0x1(%rsi,%rcx,1)
 1f7d539:	je     1f7d550 <node_facts_window_run+0xc0>
 1f7d53b:	movzbl 0x69455(%r13,%rcx,1),%esi
 1f7d544:	jmp    1f7d552 <node_facts_window_run+0xc2>
 1f7d546:	cs nopw 0x0(%rax,%rax,1)
 1f7d550:	xor    %esi,%esi
 1f7d552:	mov    0x9c0(%rdi),%r8
 1f7d559:	mov    %sil,0x1(%r8,%rcx,1)
 1f7d55e:	mov    0x9b8(%rdi),%rsi
 1f7d565:	cmpb   $0x0,0x2(%rsi,%rcx,1)
 1f7d56a:	je     1f7d580 <node_facts_window_run+0xf0>
 1f7d56c:	movzbl 0x69456(%r13,%rcx,1),%esi
 1f7d575:	jmp    1f7d582 <node_facts_window_run+0xf2>
 1f7d577:	nopw   0x0(%rax,%rax,1)
 1f7d580:	xor    %esi,%esi
 1f7d582:	mov    0x9c0(%rdi),%r8
 1f7d589:	mov    %sil,0x2(%r8,%rcx,1)
 1f7d58e:	mov    0x9b8(%rdi),%rsi
 1f7d595:	cmpb   $0x0,0x3(%rsi,%rcx,1)
 1f7d59a:	je     1f7d5b0 <node_facts_window_run+0x120>
 1f7d59c:	movzbl 0x69457(%r13,%rcx,1),%esi
 1f7d5a5:	jmp    1f7d5b2 <node_facts_window_run+0x122>
 1f7d5a7:	nopw   0x0(%rax,%rax,1)
 1f7d5b0:	xor    %esi,%esi
 1f7d5b2:	mov    0x9c0(%rdi),%r8
 1f7d5b9:	mov    %sil,0x3(%r8,%rcx,1)
 1f7d5be:	mov    0x9b8(%rdi),%rsi
 1f7d5c5:	cmpb   $0x0,0x4(%rsi,%rcx,1)
 1f7d5ca:	je     1f7d5e0 <node_facts_window_run+0x150>
 1f7d5cc:	movzbl 0x69458(%r13,%rcx,1),%esi
 1f7d5d5:	jmp    1f7d5e2 <node_facts_window_run+0x152>
 1f7d5d7:	nopw   0x0(%rax,%rax,1)
 1f7d5e0:	xor    %esi,%esi
 1f7d5e2:	mov    0x9c0(%rdi),%r8
 1f7d5e9:	mov    %sil,0x4(%r8,%rcx,1)
 1f7d5ee:	mov    0x9b8(%rdi),%rsi
 1f7d5f5:	cmpb   $0x0,0x5(%rsi,%rcx,1)
 1f7d5fa:	je     1f7d610 <node_facts_window_run+0x180>
 1f7d5fc:	movzbl 0x69459(%r13,%rcx,1),%esi
 1f7d605:	jmp    1f7d612 <node_facts_window_run+0x182>
 1f7d607:	nopw   0x0(%rax,%rax,1)
 1f7d610:	xor    %esi,%esi
 1f7d612:	mov    0x9c0(%rdi),%r8
 1f7d619:	mov    %sil,0x5(%r8,%rcx,1)
 1f7d61e:	mov    0x9b8(%rdi),%rsi
 1f7d625:	cmpb   $0x0,0x6(%rsi,%rcx,1)
 1f7d62a:	je     1f7d640 <node_facts_window_run+0x1b0>
 1f7d62c:	movzbl 0x6945a(%r13,%rcx,1),%esi
 1f7d635:	jmp    1f7d642 <node_facts_window_run+0x1b2>
 1f7d637:	nopw   0x0(%rax,%rax,1)
 1f7d640:	xor    %esi,%esi
 1f7d642:	mov    0x9c0(%rdi),%r8
 1f7d649:	mov    %sil,0x6(%r8,%rcx,1)
 1f7d64e:	mov    0x9b8(%rdi),%rsi
 1f7d655:	cmpb   $0x0,0x7(%rsi,%rcx,1)
 1f7d65a:	je     1f7d4e0 <node_facts_window_run+0x50>
 1f7d660:	movzbl 0x6945b(%r13,%rcx,1),%esi
 1f7d669:	jmp    1f7d4e2 <node_facts_window_run+0x52>
 1f7d66e:	test   %rax,%rax
 1f7d671:	jne    1f7da7f <node_facts_window_run+0x5ef>
 1f7d677:	vpbroadcastq %r13,%ymm0
 1f7d67d:	vpaddq -0x19bbe65(%rip),%ymm0,%ymm0        # 5c1820 <.LCPI3_0>
 1f7d685:	vmovups 0x1f0(%rdi),%zmm1
 1f7d68f:	mov    0x9c0(%rdi),%rax
 1f7d696:	mov    0x9c8(%rdi),%rdx
 1f7d69d:	mov    0x69250(%r13),%r8d
 1f7d6a4:	lea    0x2c(%r13),%r11
 1f7d6a8:	lea    0x6a4d4(%r13),%rcx
 1f7d6af:	lea    0x79854(%r13),%rsi
 1f7d6b6:	lea    0x73754(%r13),%r9
 1f7d6bd:	mov    0x230(%rdi),%r10
 1f7d6c4:	vmovdqu 0x240(%rdi),%xmm3
 1f7d6cc:	vmovq  0x258(%rdi),%xmm2
 1f7d6d4:	mov    %r11,0x1f0(%rdi)
 1f7d6db:	mov    %rax,0x1f8(%rdi)
 1f7d6e2:	mov    %rcx,0x200(%rdi)
 1f7d6e9:	mov    %rdx,0x208(%rdi)
 1f7d6f0:	mov    $0x1,%edx
 1f7d6f5:	vmovdqu %ymm0,0x210(%rdi)
 1f7d6fd:	mov    %rsi,0x230(%rdi)
 1f7d704:	mov    %r9,0x240(%rdi)
 1f7d70b:	mov    %r8d,0x258(%rdi)
 1f7d712:	vmovups %zmm1,0x8b0(%rsp)
 1f7d71d:	mov    %r10,0x6b8(%rsp)
 1f7d725:	vmovdqa %xmm3,0x880(%rsp)
 1f7d72e:	vmovdqa %xmm2,0x870(%rsp)
 1f7d737:	mov    %r11,0xd0(%rsp)
 1f7d73f:	xor    %esi,%esi
 1f7d741:	mov    %rdi,0x8(%rsp)
 1f7d746:	vmovups 0x9d0(%rdi),%zmm0
 1f7d750:	vmovups 0x268(%rdi),%zmm1
 1f7d75a:	vmovups %zmm0,0x268(%rdi)
 1f7d764:	vmovups %zmm1,0x9d0(%rdi)
 1f7d76e:	vmovdqu 0xa10(%rdi),%xmm0
 1f7d776:	vmovdqu 0x2a8(%rdi),%xmm1
 1f7d77e:	vmovdqu %xmm0,0x2a8(%rdi)
 1f7d786:	vmovdqu %xmm1,0xa10(%rdi)
 1f7d78e:	mov    0xa20(%rdi),%rcx
 1f7d795:	mov    0x2b8(%rdi),%rax
 1f7d79c:	mov    %rcx,0x2b8(%rdi)
 1f7d7a3:	lea    0xa28(%rdi),%rcx
 1f7d7aa:	mov    %rax,0xa20(%rdi)
 1f7d7b1:	movl   $0x0,0xa28(%rdi)
 1f7d7bb:	mov    %r15d,0xa2c(%rdi)
 1f7d7c2:	mov    %rcx,0x248(%rdi)
 1f7d7c9:	movl   $0x0,0x25c(%rdi)
 1f7d7d3:	vzeroupper
 1f7d7d6:	call   1f7bbc0 <node_facts_given>
 1f7d7db:	mov    0x8(%rsp),%rax
 1f7d7e0:	mov    0x8(%rsp),%rdi
 1f7d7e5:	xor    %esi,%esi
 1f7d7e7:	xor    %edx,%edx
 1f7d7e9:	xor    %ecx,%ecx
 1f7d7eb:	mov    0xe0(%rax),%rbx
 1f7d7f2:	call   1f7bdc0 <node_facts_window>
 1f7d7f7:	mov    0x8(%rsp),%rax
 1f7d7fc:	mov    0x8(%rsp),%rdi
 1f7d801:	xor    %esi,%esi
 1f7d803:	mov    0xe0(%rax),%rax
 1f7d80a:	sub    %rbx,%rax
 1f7d80d:	add    %rax,0xa30(%r14)
 1f7d814:	call   1f7ca10 <node_facts_lists_same>
 1f7d819:	mov    0x8(%rsp),%rdi
 1f7d81e:	test   %al,%al
 1f7d820:	jne    1f7d875 <node_facts_window_run+0x3e5>
 1f7d822:	incq   0xa00(%r14)
 1f7d829:	mov    0x940(%rdi),%rax
 1f7d830:	mov    0x11e0(%rax),%ecx
 1f7d836:	cmp    $0xf,%rcx
 1f7d83a:	ja     1f7d875 <node_facts_window_run+0x3e5>
 1f7d83c:	mov    0x422c(%r13),%edx
 1f7d843:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7d84a:	mov    0x1f0(%rdi),%rcx
 1f7d851:	mov    0x11e0(%rax),%edx
 1f7d857:	movzbl (%rcx),%ecx
 1f7d85a:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7d861:	mov    0x11e0(%rax),%ecx
 1f7d867:	movb   $0x2,0x11d0(%rax,%rcx,1)
 1f7d86f:	incl   0x11e0(%rax)
 1f7d875:	mov    %r15,0xc8(%rsp)
 1f7d87d:	mov    %r13,0x28(%rsp)
 1f7d882:	test   %r15d,%r15d
 1f7d885:	je     1f7db57 <node_facts_window_run+0x6c7>
 1f7d88b:	mov    $0x1a,%r15d
 1f7d891:	mov    $0xcc,%ebp
 1f7d896:	mov    $0x102,%r12d
 1f7d89c:	mov    $0x8c,%r13d
 1f7d8a2:	xor    %ebx,%ebx
 1f7d8a4:	jmp    1f7d8c5 <node_facts_window_run+0x435>
 1f7d8a6:	cs nopw 0x0(%rax,%rax,1)
 1f7d8b0:	inc    %rbx
 1f7d8b3:	add    $0x40,%r15
 1f7d8b7:	cmp    %rbx,0xc8(%rsp)
 1f7d8bf:	je     1f7da90 <node_facts_window_run+0x600>
 1f7d8c5:	mov    0x1f8(%rdi),%rax
 1f7d8cc:	movzbl (%rax,%rbx,1),%eax
 1f7d8d0:	cmp    $0x7,%eax
 1f7d8d3:	ja     1f7d8b0 <node_facts_window_run+0x420>
 1f7d8d5:	bt     %eax,%ebp
 1f7d8d8:	jae    1f7d8b0 <node_facts_window_run+0x420>
 1f7d8da:	mov    %eax,%ecx
 1f7d8dc:	mov    0x2c0(%rdi),%rsi
 1f7d8e3:	and    $0xfe,%cl
 1f7d8e6:	cmp    $0x2,%cl
 1f7d8e9:	sete   %cl
 1f7d8ec:	cmp    $0x7,%eax
 1f7d8ef:	sete   %dl
 1f7d8f2:	or     %cl,%dl
 1f7d8f4:	movzbl -0x1(%rsi,%r15,1),%ecx
 1f7d8fa:	movzbl %dl,%edx
 1f7d8fd:	add    %rdx,0x9f0(%r14)
 1f7d904:	cmp    $0x7,%eax
 1f7d907:	ja     1f7da43 <node_facts_window_run+0x5b3>
 1f7d90d:	bt     %eax,%r13d
 1f7d911:	mov    $0x0,%edx
 1f7d916:	jae    1f7d924 <node_facts_window_run+0x494>
 1f7d918:	lea    -0x1(%rcx),%esi
 1f7d91b:	xor    %edx,%edx
 1f7d91d:	cmp    $0x2,%sil
 1f7d921:	setb   %dl
 1f7d924:	add    %rdx,0x9f8(%r14)
 1f7d92b:	xor    %edx,%edx
 1f7d92d:	cmp    $0x7,%eax
 1f7d930:	ja     1f7d946 <node_facts_window_run+0x4b6>
 1f7d932:	bt     %eax,%r13d
 1f7d936:	jae    1f7d946 <node_facts_window_run+0x4b6>
 1f7d938:	mov    0x1f0(%rdi),%rax
 1f7d93f:	cmpb   $0x22,(%rax,%rbx,1)
 1f7d943:	sete   %dl
 1f7d946:	dec    %cl
 1f7d948:	vmovd  %edx,%xmm0
 1f7d94c:	cmp    $0x2,%cl
 1f7d94f:	setb   %al
 1f7d952:	and    %dl,%al
 1f7d954:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f7d95a:	vpmovzxbq %xmm0,%xmm0
 1f7d95f:	vptestmq -0x19af461(%rip){1to2},%xmm0,%k0        # 5ce508 <.LCPI3_1>
 1f7d969:	vmovdqu 0xa10(%r14),%xmm0
 1f7d972:	vpmovm2q %k0,%xmm1
 1f7d978:	vpsubq %xmm1,%xmm0,%xmm0
 1f7d97c:	vmovdqu %xmm0,0xa10(%r14)
 1f7d985:	cmp    $0x1,%al
 1f7d987:	jne    1f7d9c0 <node_facts_window_run+0x530>
 1f7d989:	mov    0x2c0(%rdi),%rax
 1f7d990:	movzwl (%rax,%r15,1),%eax
 1f7d995:	bt     $0x1,%eax
 1f7d999:	adcq   $0x0,0xa20(%r14)
 1f7d9a1:	mov    0x2c0(%rdi),%rax
 1f7d9a8:	movzwl (%rax,%r15,1),%eax
 1f7d9ad:	bextr  %r12d,%eax,%eax
 1f7d9b2:	jmp    1f7d9c2 <node_facts_window_run+0x532>
 1f7d9b4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d9c0:	xor    %eax,%eax
 1f7d9c2:	add    %rax,0xa28(%r14)
 1f7d9c9:	xor    %esi,%esi
 1f7d9cb:	mov    %ebx,%edx
 1f7d9cd:	xor    %ecx,%ecx
 1f7d9cf:	call   1f7d030 <node_facts_same>
 1f7d9d4:	mov    0x8(%rsp),%rdi
 1f7d9d9:	test   %al,%al
 1f7d9db:	jne    1f7d8b0 <node_facts_window_run+0x420>
 1f7d9e1:	incq   0xa00(%r14)
 1f7d9e8:	mov    0x940(%rdi),%rax
 1f7d9ef:	mov    0x11e0(%rax),%ecx
 1f7d9f5:	cmp    $0xf,%rcx
 1f7d9f9:	ja     1f7d8b0 <node_facts_window_run+0x420>
 1f7d9ff:	mov    0x28(%rsp),%rdx
 1f7da04:	mov    0x422c(%rdx,%rbx,4),%edx
 1f7da0b:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7da12:	mov    0x1f0(%rdi),%rcx
 1f7da19:	mov    0x11e0(%rax),%edx
 1f7da1f:	movzbl (%rcx,%rbx,1),%ecx
 1f7da23:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7da2a:	mov    0x11e0(%rax),%ecx
 1f7da30:	movb   $0x5,0x11d0(%rax,%rcx,1)
 1f7da38:	incl   0x11e0(%rax)
 1f7da3e:	jmp    1f7d8b0 <node_facts_window_run+0x420>
 1f7da43:	xor    %edx,%edx
 1f7da45:	add    %rdx,0x9f8(%r14)
 1f7da4c:	xor    %edx,%edx
 1f7da4e:	cmp    $0x7,%eax
 1f7da51:	jbe    1f7d932 <node_facts_window_run+0x4a2>
 1f7da57:	jmp    1f7d946 <node_facts_window_run+0x4b6>
 1f7da5c:	nopl   0x0(%rax)
 1f7da60:	movzbl 0x69454(%r13,%rcx,1),%edx
 1f7da69:	mov    0x9c0(%rdi),%rsi
 1f7da70:	mov    %dl,(%rsi,%rcx,1)
 1f7da73:	inc    %rcx
 1f7da76:	dec    %rax
 1f7da79:	je     1f7d677 <node_facts_window_run+0x1e7>
 1f7da7f:	mov    0x9b8(%rdi),%rdx
 1f7da86:	cmpb   $0x0,(%rdx,%rcx,1)
 1f7da8a:	jne    1f7da60 <node_facts_window_run+0x5d0>
 1f7da8c:	xor    %edx,%edx
 1f7da8e:	jmp    1f7da69 <node_facts_window_run+0x5d9>
 1f7da90:	mov    $0x3,%edx
 1f7da95:	xor    %esi,%esi
 1f7da97:	xor    %ebx,%ebx
 1f7da99:	call   1f7bbc0 <node_facts_given>
 1f7da9e:	mov    0x8(%rsp),%rdi
 1f7daa3:	xor    %esi,%esi
 1f7daa5:	xor    %edx,%edx
 1f7daa7:	xor    %ecx,%ecx
 1f7daa9:	call   1f7bdc0 <node_facts_window>
 1f7daae:	mov    0x8(%rsp),%rdi
 1f7dab3:	mov    0xc8(%rsp),%r15
 1f7dabb:	mov    0x28(%rsp),%r13
 1f7dac0:	jmp    1f7dadc <node_facts_window_run+0x64c>
 1f7dac2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7dad0:	inc    %rbx
 1f7dad3:	cmp    %rbx,%r15
 1f7dad6:	je     1f7db78 <node_facts_window_run+0x6e8>
 1f7dadc:	mov    0x1f8(%rdi),%rax
 1f7dae3:	testb  $0x2,(%rax,%rbx,1)
 1f7dae7:	je     1f7dad0 <node_facts_window_run+0x640>
 1f7dae9:	xor    %esi,%esi
 1f7daeb:	mov    %ebx,%edx
 1f7daed:	xor    %ecx,%ecx
 1f7daef:	call   1f7d030 <node_facts_same>
 1f7daf4:	mov    0x8(%rsp),%rdi
 1f7daf9:	test   %al,%al
 1f7dafb:	jne    1f7dad0 <node_facts_window_run+0x640>
 1f7dafd:	incq   0xa00(%r14)
 1f7db04:	mov    0x940(%rdi),%rax
 1f7db0b:	mov    0x11e0(%rax),%ecx
 1f7db11:	cmp    $0xf,%rcx
 1f7db15:	ja     1f7dad0 <node_facts_window_run+0x640>
 1f7db17:	mov    0x422c(%r13,%rbx,4),%edx
 1f7db1f:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7db26:	mov    0x1f0(%rdi),%rcx
 1f7db2d:	mov    0x11e0(%rax),%edx
 1f7db33:	movzbl (%rcx,%rbx,1),%ecx
 1f7db37:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7db3e:	mov    0x11e0(%rax),%ecx
 1f7db44:	movb   $0x1,0x11d0(%rax,%rcx,1)
 1f7db4c:	incl   0x11e0(%rax)
 1f7db52:	jmp    1f7dad0 <node_facts_window_run+0x640>
 1f7db57:	mov    $0x3,%edx
 1f7db5c:	xor    %esi,%esi
 1f7db5e:	call   1f7bbc0 <node_facts_given>
 1f7db63:	mov    0x8(%rsp),%rdi
 1f7db68:	xor    %esi,%esi
 1f7db6a:	xor    %edx,%edx
 1f7db6c:	xor    %ecx,%ecx
 1f7db6e:	call   1f7bdc0 <node_facts_window>
 1f7db73:	mov    0x8(%rsp),%rdi
 1f7db78:	xor    %esi,%esi
 1f7db7a:	xor    %edx,%edx
 1f7db7c:	call   1f7bbc0 <node_facts_given>
 1f7db81:	mov    0x8(%rsp),%rax
 1f7db86:	xor    %esi,%esi
 1f7db88:	xor    %ecx,%ecx
 1f7db8a:	mov    0xd0(%rax),%r15
 1f7db91:	rdtsc
 1f7db93:	mov    0x8(%rsp),%rdi
 1f7db98:	mov    %rdx,%rbx
 1f7db9b:	shl    $0x20,%rbx
 1f7db9f:	xor    %edx,%edx
 1f7dba1:	or     %rax,%rbx
 1f7dba4:	call   1f7bdc0 <node_facts_window>
 1f7dba9:	mov    0x8(%rsp),%r11
 1f7dbae:	rdtsc
 1f7dbb0:	shl    $0x20,%rdx
 1f7dbb4:	or     %rax,%rdx
 1f7dbb7:	sub    %rbx,%rdx
 1f7dbba:	add    %rdx,0xa08(%r14)
 1f7dbc1:	mov    0xd0(%r11),%rax
 1f7dbc8:	sub    %r15,%rax
 1f7dbcb:	mov    0xc8(%rsp),%r15
 1f7dbd3:	add    %rax,0xa38(%r14)
 1f7dbda:	mov    0x950(%r11),%rdi
 1f7dbe1:	test   %rdi,%rdi
 1f7dbe4:	je     1f84d90 <node_facts_window_run+0x7900>
 1f7dbea:	mov    0xcc8(%rdi),%rax
 1f7dbf1:	mov    0xc30(%rdi),%rsi
 1f7dbf8:	lea    0x757d4(%r13),%r12
 1f7dbff:	mov    %rax,0x68(%rsp)
 1f7dc04:	mov    (%r11),%rax
 1f7dc07:	mov    %rax,0x80(%rsp)
 1f7dc0f:	mov    0x948(%r11),%rax
 1f7dc16:	mov    %rax,0xc0(%rsp)
 1f7dc1e:	mov    0x8(%rax),%rax
 1f7dc22:	mov    0x78(%rax),%eax
 1f7dc25:	mov    %eax,0xb8(%rsp)
 1f7dc2c:	movzbl 0xcf0(%rdi),%eax
 1f7dc33:	mov    %al,0x88(%rsp)
 1f7dc3a:	rdtsc
 1f7dc3c:	mov    0x8(%r13),%r8d
 1f7dc40:	mov    0x2c0(%r11),%r9
 1f7dc47:	mov    %rax,0xf0(%rsp)
 1f7dc4f:	lea    0x3f(%r8),%eax
 1f7dc53:	mov    %rdx,0xe8(%rsp)
 1f7dc5b:	mov    %rsi,0x38(%rsp)
 1f7dc60:	mov    %rdi,0x18(%rsp)
 1f7dc65:	mov    %r12,0x30(%rsp)
 1f7dc6a:	mov    %r8,0x150(%rsp)
 1f7dc72:	mov    %r9,0x20(%rsp)
 1f7dc77:	and    $0xffffffc0,%eax
 1f7dc7a:	cmpq   $0x0,0xc20(%r11)
 1f7dc82:	je     1f7e958 <node_facts_window_run+0x14c8>
 1f7dc88:	cmpb   $0x1,0xd58(%r11)
 1f7dc90:	jne    1f7f3b2 <node_facts_window_run+0x1f22>
 1f7dc96:	test   %eax,%eax
 1f7dc98:	je     1f808b7 <node_facts_window_run+0x3427>
 1f7dc9e:	vpbroadcastd -0x19acd74(%rip),%zmm14        # 5d0f34 <.LCPI3_5>
 1f7dca8:	vpbroadcastb -0x1ac6f71(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7dcb1:	vpbroadcastb -0x1ac6f7a(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7dcbb:	vpbroadcastd -0x19acd89(%rip),%zmm17        # 5d0f3c <.LCPI3_11>
 1f7dcc5:	vpbroadcastd -0x19acd8b(%rip),%zmm18        # 5d0f44 <.LCPI3_13>
 1f7dccf:	mov    (%r11),%rcx
 1f7dcd2:	lea    0x69454(%r13),%r10
 1f7dcd9:	lea    0x422c(%r13),%rdx
 1f7dce0:	mov    %eax,%r15d
 1f7dce3:	xor    %ebx,%ebx
 1f7dce5:	mov    %rcx,0x90(%rsp)
 1f7dced:	mov    %r10,0xb0(%rsp)
 1f7dcf5:	mov    %rdx,0x98(%rsp)
 1f7dcfd:	movq   $0x0,0x40(%rsp)
 1f7dd06:	movq   $0x0,0x110(%rsp)
 1f7dd12:	movq   $0x0,0x10(%rsp)
 1f7dd1b:	mov    %r15,0xa8(%rsp)
 1f7dd23:	jmp    1f7ddf6 <node_facts_window_run+0x966>
 1f7dd28:	nopl   0x0(%rax,%rax,1)
 1f7dd30:	vpxor  %xmm1,%xmm1,%xmm1
 1f7dd34:	vpxor  %xmm0,%xmm0,%xmm0
 1f7dd38:	vpxor  %xmm5,%xmm5,%xmm5
 1f7dd3c:	vpxor  %xmm4,%xmm4,%xmm4
 1f7dd40:	vpxor  %xmm3,%xmm3,%xmm3
 1f7dd44:	vpxor  %xmm7,%xmm7,%xmm7
 1f7dd48:	vpxor  %xmm8,%xmm8,%xmm8
 1f7dd4d:	vpxor  %xmm9,%xmm9,%xmm9
 1f7dd52:	vpxor  %xmm2,%xmm2,%xmm2
 1f7dd56:	vpxord %xmm20,%xmm20,%xmm20
 1f7dd5c:	mov    0xc70(%rdi),%rax
 1f7dd63:	vmovdqu64 %xmm20,(%rax,%rbx,1)
 1f7dd6a:	mov    0xc78(%rdi),%rax
 1f7dd71:	vmovdqu %xmm2,(%rax,%rbx,1)
 1f7dd76:	mov    0xb88(%r11),%rax
 1f7dd7d:	vmovdqu %xmm9,(%rax,%rbx,1)
 1f7dd82:	mov    0xb90(%r11),%rax
 1f7dd89:	vmovdqu %xmm8,(%rax,%rbx,1)
 1f7dd8e:	mov    0xb98(%r11),%rax
 1f7dd95:	vmovdqu %xmm7,(%rax,%rbx,1)
 1f7dd9a:	mov    0xba0(%r11),%rax
 1f7dda1:	vmovdqu %xmm3,(%rax,%rbx,1)
 1f7dda6:	mov    0xba8(%r11),%rax
 1f7ddad:	vmovdqu %xmm4,(%rax,%rbx,1)
 1f7ddb2:	mov    0xc28(%r11),%rax
 1f7ddb9:	vmovdqu64 %zmm5,(%rax,%rbx,4)
 1f7ddc0:	mov    0xcd8(%r11),%rax
 1f7ddc7:	vmovdqu64 %zmm0,(%rax,%rbx,8)
 1f7ddce:	mov    0xcd8(%r11),%rax
 1f7ddd5:	vmovdqu64 %zmm1,0x40(%rax,%rbx,8)
 1f7dddd:	mov    0xd60(%r11),%rax
 1f7dde4:	vmovdqu %xmm6,(%rax,%rbx,1)
 1f7dde9:	add    $0x10,%rbx
 1f7dded:	cmp    %r15,%rbx
 1f7ddf0:	jae    1f808d5 <node_facts_window_run+0x3445>
 1f7ddf6:	vpxor  %xmm6,%xmm6,%xmm6
 1f7ddfa:	cmp    %r8,%rbx
 1f7ddfd:	jae    1f7dd30 <node_facts_window_run+0x8a0>
 1f7de03:	mov    %r8d,%eax
 1f7de06:	sub    %ebx,%eax
 1f7de08:	mov    $0x10,%ecx
 1f7de0d:	mov    $0xffffffff,%edx
 1f7de12:	mov    %rbx,%rbp
 1f7de15:	vpxor  %xmm12,%xmm12,%xmm12
 1f7de1a:	cmp    $0x10,%eax
 1f7de1d:	cmovae %ecx,%eax
 1f7de20:	mov    0x9b8(%r11),%rcx
 1f7de27:	shl    $0x6,%rbp
 1f7de2b:	shlx   %eax,%edx,%eax
 1f7de30:	vmovdqu (%r9,%rbp,1),%ymm4
 1f7de36:	vmovdqu64 0x40(%r9,%rbp,1),%ymm26
 1f7de3e:	vmovdqu64 0x80(%r9,%rbp,1),%ymm27
 1f7de46:	vmovdqu64 0xc0(%r9,%rbp,1),%ymm28
 1f7de4e:	vmovdqu 0x100(%r9,%rbp,1),%ymm5
 1f7de58:	vmovdqu 0x140(%r9,%rbp,1),%ymm6
 1f7de62:	vmovdqu64 0x180(%r9,%rbp,1),%ymm24
 1f7de6a:	vmovdqu64 0x1c0(%r9,%rbp,1),%ymm25
 1f7de72:	vmovdqu 0x200(%r9,%rbp,1),%ymm7
 1f7de7c:	vmovdqu 0x240(%r9,%rbp,1),%ymm13
 1f7de86:	vmovdqu64 0x280(%r9,%rbp,1),%ymm22
 1f7de8e:	vmovdqu64 0x2c0(%r9,%rbp,1),%ymm23
 1f7de96:	vmovdqu 0x300(%r9,%rbp,1),%ymm11
 1f7dea0:	vmovdqu64 0x340(%r9,%rbp,1),%ymm19
 1f7dea8:	vmovdqu64 0x380(%r9,%rbp,1),%ymm20
 1f7deb0:	vmovdqu64 0x3c0(%r9,%rbp,1),%ymm21
 1f7deb8:	not    %eax
 1f7deba:	kmovd  %eax,%k1
 1f7debe:	mov    0xca8(%rdi),%rax
 1f7dec5:	vmovdqu8 (%rcx,%rbx,1),%xmm0{%k1}{z}
 1f7decc:	mov    0xb0(%rsp),%rcx
 1f7ded4:	vmovdqu8 (%rcx,%rbx,1),%xmm10{%k1}{z}
 1f7dedb:	vptestmb %xmm0,%xmm0,%k6
 1f7dee1:	vpcmpeqb -0x19b61db(%rip),%xmm10,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7deeb:	vmovdqu32 (%r12,%rbx,4),%zmm0{%k7}{z}
 1f7def2:	kmovq  %k7,%k1
 1f7def7:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7defe:	vptestnmd %zmm17,%zmm12,%k0
 1f7df04:	ktestw %k0,%k7
 1f7df08:	jne    1f7e648 <node_facts_window_run+0x11b8>
 1f7df0e:	vpmovsxbd -0x19acf9f(%rip),%xmm3        # 5d0f78 <.LCPI3_74>
 1f7df17:	vmovdqa64 -0x1ac77e1(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7df21:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7df28:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7df2f:	vptestmd -0x19acff9(%rip){1to16},%zmm12,%k0        # 5d0f40 <.LCPI3_12>
 1f7df39:	vmovdqa64 %zmm0,%zmm2
 1f7df3f:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7df45:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7df4b:	vmovdqa64 %zmm3,%zmm9
 1f7df51:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7df57:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7df5d:	kmovd  %k0,%r13d
 1f7df61:	vptestmd %zmm18,%zmm12,%k0
 1f7df67:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7df6d:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7df74:	vmovdqu64 %zmm1,0x230(%rsp)
 1f7df7f:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7df86:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7df8a:	vmovdqa64 %zmm1,%zmm4
 1f7df90:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7df96:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7df9c:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7dfa2:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7dfa8:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7dfaf:	vmovdqu %ymm3,0x1f0(%rsp)
 1f7dfb8:	vinserti64x4 $0x1,%ymm13,%zmm7,%zmm3
 1f7dfbf:	vpunpcklqdq %ymm13,%ymm7,%ymm7
 1f7dfc4:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm13
 1f7dfcb:	vmovdqa64 %zmm3,%zmm6
 1f7dfd1:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7dfd7:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7dfdd:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7dfe3:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7dfe9:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7dfef:	vmovdqa64 %zmm13,%zmm7
 1f7dff5:	vmovdqu64 %zmm5,0x270(%rsp)
 1f7e000:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7e007:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7e00d:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7e014:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7e01b:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7e021:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7e028:	vpermt2d %zmm5,%zmm9,%zmm13
 1f7e02e:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7e034:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7e03a:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7e041:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7e048:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7e04f:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7e056:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm21{%k6}{z}
 1f7e05d:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7e064:	vpsrld $0x19,%zmm19,%zmm0
 1f7e06b:	vpandd -0x19ad145(%rip){1to16},%zmm0,%zmm0        # 5d0f30 <.LCPI3_4>
 1f7e075:	vpsrld $0x18,%zmm19,%zmm1
 1f7e07c:	vpsrld $0x1a,%zmm19,%zmm7
 1f7e083:	vpternlogd $0xec,%zmm14,%zmm0,%zmm1
 1f7e08a:	vpandd -0x19ad118(%rip){1to16},%zmm19,%zmm0        # 5d0f7c <.LCPI3_75>
 1f7e094:	vpmovdb %zmm1,%xmm20
 1f7e09a:	vpsrld $0xc,%zmm21,%zmm1
 1f7e0a1:	vpmovdb %zmm1,%xmm24
 1f7e0a7:	vpcmpeqd -0x19ad179(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f38 <.LCPI3_7>
 1f7e0b1:	vporq  %xmm15,%xmm20,%xmm0
 1f7e0b7:	vmovdqu8 %xmm0,%xmm20{%k1}
 1f7e0bd:	vpcmpeqb %xmm15,%xmm10,%k1{%k6}
 1f7e0c3:	vpternlogq $0xf8,%xmm16,%xmm24,%xmm20
 1f7e0ca:	kmovd  %k1,%eax
 1f7e0ce:	kmovw  %k1,0x50(%rsp)
 1f7e0d4:	korw   %k0,%k1,%k1
 1f7e0d8:	kmovw  %k1,0x1b0(%rsp)
 1f7e0e1:	test   %ax,%ax
 1f7e0e4:	je     1f7e2a2 <node_facts_window_run+0xe12>
 1f7e0ea:	vmovdqu64 %zmm4,0x6c0(%rsp)
 1f7e0f2:	vmovdqu %ymm5,0x5d0(%rsp)
 1f7e0fb:	vmovdqu64 %zmm7,0x4b0(%rsp)
 1f7e106:	vmovdqa64 %xmm24,0x610(%rsp)
 1f7e10e:	vmovdqu64 %zmm23,0x650(%rsp)
 1f7e119:	vmovdqu64 %zmm22,0x570(%rsp)
 1f7e124:	vmovdqu64 %zmm19,0x3f0(%rsp)
 1f7e12f:	vmovdqu64 %zmm13,0x4f0(%rsp)
 1f7e13a:	vmovdqu64 %zmm21,0x430(%rsp)
 1f7e145:	vmovdqu64 %zmm12,0x530(%rsp)
 1f7e150:	vmovdqa64 %xmm20,0x2b0(%rsp)
 1f7e158:	kmovw  %k7,0x3b0(%rsp)
 1f7e161:	mov    %rbp,0x370(%rsp)
 1f7e169:	kmovd  %k6,0x2f0(%rsp)
 1f7e173:	movzwl %ax,%r14d
 1f7e177:	movzwl %r13w,%r13d
 1f7e17b:	xor    %ebp,%ebp
 1f7e17d:	mov    0x98(%rsp),%rax
 1f7e185:	lea    (%rax,%rbx,4),%r15
 1f7e189:	nopl   0x0(%rax)
 1f7e190:	xor    %r12d,%r12d
 1f7e193:	tzcnt  %r14d,%r12d
 1f7e198:	xor    %edx,%edx
 1f7e19a:	mov    (%r15,%r12,4),%esi
 1f7e19e:	vzeroupper
 1f7e1a1:	call   1f939b0 <node_tests_window_line>
 1f7e1a6:	mov    0x18(%rsp),%rdi
 1f7e1ab:	mov    $0x1,%ecx
 1f7e1b0:	test   $0x2,%al
 1f7e1b2:	shlx   %r12d,%ecx,%eax
 1f7e1b7:	cmove  %ebp,%eax
 1f7e1ba:	or     %eax,%r13d
 1f7e1bd:	blsr   %r14d,%r14d
 1f7e1c2:	jne    1f7e190 <node_facts_window_run+0xd00>
 1f7e1c4:	vpbroadcastd -0x19ad29a(%rip),%zmm14        # 5d0f34 <.LCPI3_5>
 1f7e1ce:	vpbroadcastb -0x1ac7497(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e1d7:	vpbroadcastb -0x1ac74a0(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e1e1:	vpbroadcastd -0x19ad2af(%rip),%zmm17        # 5d0f3c <.LCPI3_11>
 1f7e1eb:	vpbroadcastd -0x19ad2b1(%rip),%zmm18        # 5d0f44 <.LCPI3_13>
 1f7e1f5:	vmovdqa64 0x2b0(%rsp),%xmm20
 1f7e1fd:	vmovdqu64 0x530(%rsp),%zmm12
 1f7e208:	vmovdqu64 0x430(%rsp),%zmm21
 1f7e213:	vmovdqu64 0x4f0(%rsp),%zmm13
 1f7e21e:	vmovdqu64 0x3f0(%rsp),%zmm19
 1f7e229:	vmovdqu64 0x570(%rsp),%zmm22
 1f7e234:	vmovdqu64 0x650(%rsp),%zmm23
 1f7e23f:	vmovdqa64 0x610(%rsp),%xmm24
 1f7e247:	vmovdqu64 0x4b0(%rsp),%zmm7
 1f7e252:	vmovdqu 0x5d0(%rsp),%ymm5
 1f7e25b:	vmovdqu64 0x6c0(%rsp),%zmm4
 1f7e263:	mov    0x8(%rsp),%r11
 1f7e268:	mov    0x38(%rsp),%rsi
 1f7e26d:	mov    0x30(%rsp),%r12
 1f7e272:	mov    0x150(%rsp),%r8
 1f7e27a:	mov    0x20(%rsp),%r9
 1f7e27f:	mov    0xa8(%rsp),%r15
 1f7e287:	kmovd  0x2f0(%rsp),%k6
 1f7e291:	mov    0x370(%rsp),%rbp
 1f7e299:	kmovw  0x3b0(%rsp),%k7
 1f7e2a2:	vpsrld $0x2,%zmm21,%zmm0
 1f7e2a9:	vpandd -0x19ad36b(%rip){1to16},%zmm0,%zmm2        # 5d0f48 <.LCPI3_14>
 1f7e2b3:	vpbroadcastd -0x19ad371(%rip),%zmm0        # 5d0f4c <.LCPI3_15>
 1f7e2bd:	vptestmd -0x19ad377(%rip){1to16},%zmm21,%k3        # 5d0f50 <.LCPI3_16>
 1f7e2c7:	vmovdqu64 0x270(%rsp),%zmm1
 1f7e2d2:	vptestnmd %zmm4,%zmm4,%k1
 1f7e2d8:	vpbroadcastd -0x19ad386(%rip),%zmm6        # 5d0f5c <.LCPI3_21>
 1f7e2e2:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7e2e9:	kmovd  %r13d,%k4
 1f7e2ee:	vpsrld $0x10,%zmm21,%zmm10
 1f7e2f5:	vpbroadcastb -0x1ac75bc(%rip),%xmm8        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7e2fe:	vpbroadcastb -0x1ac75c4(%rip),%xmm9        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7e307:	kmovw  %k1,%eax
 1f7e30b:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7e311:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7e318:	vmovdqu64 0x230(%rsp),%zmm0
 1f7e323:	korw   %k1,%k3,%k3
 1f7e327:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7e32e:	vpandd -0x19ad3b8(%rip){1to16},%zmm19,%zmm5        # 5d0f80 <.LCPI3_78>
 1f7e338:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7e33e:	vpbroadcastb -0x1ac7603(%rip),%xmm7        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7e347:	vinserti64x4 $0x1,0x1f0(%rsp),%zmm0,%zmm0
 1f7e353:	kmovw  %k0,%ecx
 1f7e357:	korw   %k2,%k3,%k2
 1f7e35b:	vpaddd -0x19ad40d(%rip){1to16},%zmm5,%zmm5        # 5d0f58 <.LCPI3_20>
 1f7e365:	andn   %ecx,%eax,%eax
 1f7e36a:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7e370:	kmovd  %eax,%k3
 1f7e374:	shr    $0x8,%eax
 1f7e377:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7e37d:	kmovd  %eax,%k3
 1f7e381:	vmovdqu8 %xmm15,%xmm4{%k2}{z}
 1f7e387:	vpcmpltud %zmm6,%zmm5,%k2
 1f7e38e:	vpslld $0x1f,%zmm5,%zmm5
 1f7e395:	vpxor  %xmm6,%xmm6,%xmm6
 1f7e399:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7e39f:	vptestmd -0x19ad455(%rip){1to16},%zmm23,%k3        # 5d0f54 <.LCPI3_17>
 1f7e3a9:	vpandd %zmm18,%zmm23,%zmm3
 1f7e3af:	vptestnmd %zmm3,%zmm3,%k0
 1f7e3b5:	kandd  %k6,%k0,%k0
 1f7e3ba:	korw   %k3,%k4,%k3
 1f7e3be:	kandd  %k2,%k0,%k4
 1f7e3c3:	vpcmpeqd %zmm17,%zmm2,%k2{%k4}
 1f7e3c9:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7e3cf:	vmovdqu8 -0x19b6699(%rip),%xmm2{%k4}        # 5c7d40 <.LCPI3_25>
 1f7e3d9:	knotw  %k2,%k0
 1f7e3dd:	kandd  %k0,%k4,%k5
 1f7e3e2:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7e3e8:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7e3ef:	vpaddd %zmm5,%zmm10,%zmm11
 1f7e3f5:	vpbroadcastb -0x1ac76b9(%rip),%xmm5        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7e3fe:	vmovdqu8 -0x19b66b8(%rip),%xmm2{%k4}        # 5c7d50 <.LCPI3_26>
 1f7e408:	vptestnmd %zmm11,%zmm11,%k4
 1f7e40e:	vpblendmb -0x19b66a8(%rip),%xmm5,%xmm5{%k4}        # 5c7d70 <.LCPI3_28>
 1f7e418:	vpcmpnleud -0x19ad4c3(%rip){1to16},%zmm11,%k4        # 5d0f60 <.LCPI3_22>
 1f7e423:	cmpb   $0x0,0xcf0(%rdi)
 1f7e42a:	vmovdqu8 -0x19b66b4(%rip),%xmm5{%k4}        # 5c7d80 <.LCPI3_29>
 1f7e434:	vpcmpnleud -0x19ad4db(%rip){1to16},%zmm11,%k4        # 5d0f64 <.LCPI3_23>
 1f7e43f:	vmovdqu8 -0x19b66b9(%rip),%xmm5{%k4}        # 5c7d90 <.LCPI3_30>
 1f7e449:	vptestmd %zmm3,%zmm3,%k4
 1f7e44f:	vpor   %xmm4,%xmm8,%xmm3
 1f7e453:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7e459:	kmovw  0x1b0(%rsp),%k4
 1f7e462:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7e468:	vpor   %xmm2,%xmm4,%xmm2
 1f7e46c:	vpord  -0x19ad4f2(%rip){1to4},%xmm2,%xmm3        # 5d0f84 <.LCPI3_81>
 1f7e476:	vpbroadcastb -0x1ac7739(%rip),%xmm5        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7e47f:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7e485:	vpor   %xmm5,%xmm2,%xmm3
 1f7e489:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7e48f:	vpmovdb %zmm21,%xmm3
 1f7e495:	kmovw  0x50(%rsp),%k3
 1f7e49b:	vpor   %xmm3,%xmm9,%xmm4
 1f7e49f:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7e4a5:	vptestmd -0x19ad547(%rip){1to16},%zmm12,%k3{%k7}        # 5d0f68 <.LCPI3_32>
 1f7e4af:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7e4b5:	vpor   %xmm5,%xmm4,%xmm6
 1f7e4b9:	vpsrld $0xb,%zmm23,%zmm7
 1f7e4c0:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7e4c6:	vpandd -0x19ad548(%rip){1to4},%xmm24,%xmm4        # 5d0f88 <.LCPI3_83>
 1f7e4d0:	vptestmd -0x19ad56e(%rip){1to16},%zmm23,%k1        # 5d0f6c <.LCPI3_33>
 1f7e4da:	vpmovdb %zmm7,%xmm7
 1f7e4e0:	vpand  %xmm7,%xmm8,%xmm7
 1f7e4e4:	vporq  %xmm16,%xmm4,%xmm5
 1f7e4ea:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7e4f0:	vpmovdb %zmm23,%xmm5
 1f7e4f6:	vgf2p8affineqb $0x0,-0x19affa9(%rip){1to2},%xmm5,%xmm5        # 5ce558 <.LCPI3_84>
 1f7e501:	vpternlogq $0xf8,%xmm9,%xmm5,%xmm4
 1f7e508:	vpmovdb %zmm19,%xmm9
 1f7e50e:	vpor   %xmm4,%xmm15,%xmm5
 1f7e512:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7e518:	vinserti32x4 $0x3,%xmm13,%zmm22,%zmm5{%k6}{z}
 1f7e51f:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7e526:	vpsrld $0x8,%zmm19,%zmm13
 1f7e52d:	vpsrld $0x10,%zmm19,%zmm6
 1f7e534:	vpmovdb %zmm6,%xmm7
 1f7e53a:	vpmovdb %zmm13,%xmm8
 1f7e540:	vpmovdb %zmm12,%xmm6
 1f7e546:	je     1f7e63e <node_facts_window_run+0x11ae>
 1f7e54c:	vmovdqa64 -0x1ac7d56(%rip),%zmm19        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7e556:	vptestmd %zmm10,%zmm10,%k1{%k2}
 1f7e55c:	add    %r9,%rbp
 1f7e55f:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e564:	vpxor  %xmm13,%xmm13,%xmm13
 1f7e569:	vpcmpneqd -0x19ad604(%rip){1to16},%zmm10,%k0{%k1}        # 5d0f70 <.LCPI3_38>
 1f7e574:	vmovdqa %xmm7,%xmm10
 1f7e578:	vpternlogq $0xfe,%xmm9,%xmm3,%xmm10
 1f7e57f:	kmovq  %k1,%k2
 1f7e584:	kmovw  %k1,%eax
 1f7e588:	popcnt %eax,%ecx
 1f7e58c:	vpgatherdd 0x10(%rbp,%zmm19,1),%zmm12{%k2}
 1f7e594:	kmovq  %k1,%k2
 1f7e599:	vpcmpnleud -0x19ad630(%rip){1to16},%zmm12,%k3        # 5d0f74 <.LCPI3_39>
 1f7e5a4:	vpgatherdd 0x14(%rbp,%zmm19,1),%zmm13{%k2}
 1f7e5ac:	add    %rcx,0x110(%rsp)
 1f7e5b4:	mov    0x10(%rsp),%r10
 1f7e5b9:	vpcmpeqd %zmm11,%zmm12,%k2
 1f7e5bf:	vmovdqa64 %xmm20,%xmm11
 1f7e5c5:	vpternlogq $0xfe,%xmm8,%xmm10,%xmm11
 1f7e5cc:	vptestnmd %zmm13,%zmm13,%k2{%k2}
 1f7e5d2:	vptestmd %zmm13,%zmm13,%k4
 1f7e5d8:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm11
 1f7e5df:	korw   %k4,%k3,%k3
 1f7e5e3:	kandw  %k2,%k0,%k2
 1f7e5e7:	knotw  %k0,%k0
 1f7e5eb:	kandd  %k1,%k0,%k0
 1f7e5f0:	kandw  %k0,%k3,%k0
 1f7e5f4:	korw   %k0,%k2,%k2
 1f7e5f8:	vptestnmd %zmm14,%zmm21,%k0{%k2}
 1f7e5fe:	kandw  %k0,%k1,%k0
 1f7e602:	knotd  %k6,%k1
 1f7e607:	kmovd  %k0,%ecx
 1f7e60b:	vptestmb %xmm11,%xmm11,%k0{%k1}
 1f7e611:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7e617:	andn   %eax,%ecx,%eax
 1f7e61c:	popcnt %eax,%eax
 1f7e620:	kmovw  %k0,%ecx
 1f7e624:	popcnt %ecx,%ecx
 1f7e628:	kmovw  %k1,%edx
 1f7e62c:	popcnt %edx,%edx
 1f7e630:	add    %rdx,%r10
 1f7e633:	add    %rax,%r10
 1f7e636:	add    %rcx,%r10
 1f7e639:	mov    %r10,0x10(%rsp)
 1f7e63e:	mov    0x28(%rsp),%r13
 1f7e643:	jmp    1f7dd5c <node_facts_window_run+0x8cc>
 1f7e648:	kandw  %k0,%k7,%k0
 1f7e64c:	vmovdqa %xmm10,0x270(%rsp)
 1f7e655:	vmovdqu64 %zmm11,0x370(%rsp)
 1f7e660:	vmovdqu64 %ymm19,0x2b0(%rsp)
 1f7e66b:	vmovdqu64 %zmm20,0x530(%rsp)
 1f7e676:	vmovdqu64 %ymm21,0x430(%rsp)
 1f7e681:	vmovdqu64 %zmm7,0x4f0(%rsp)
 1f7e68c:	vmovdqu %ymm13,0x3f0(%rsp)
 1f7e695:	vmovdqu64 %zmm22,0x570(%rsp)
 1f7e6a0:	vmovdqu64 %ymm23,0x650(%rsp)
 1f7e6ab:	vmovdqu64 %zmm5,0x610(%rsp)
 1f7e6b6:	vmovdqu %ymm6,0x4b0(%rsp)
 1f7e6bf:	vmovdqu64 %zmm24,0x5d0(%rsp)
 1f7e6ca:	vmovdqu64 %ymm25,0x6c0(%rsp)
 1f7e6d2:	vmovdqu64 %zmm4,0x780(%rsp)
 1f7e6da:	vmovdqu64 %ymm26,0x490(%rsp)
 1f7e6e5:	vmovdqu64 %zmm27,0x740(%rsp)
 1f7e6ed:	vmovdqu64 %ymm28,0x470(%rsp)
 1f7e6f8:	vmovdqu64 %zmm0,0x820(%rsp)
 1f7e703:	kmovd  %k6,0x2f0(%rsp)
 1f7e70d:	kmovw  %k7,0x3b0(%rsp)
 1f7e716:	kmovd  %k0,%eax
 1f7e71a:	movzwl %ax,%eax
 1f7e71d:	jmp    1f7e8cb <node_facts_window_run+0x143b>
 1f7e722:	mov    0x40(%rsp),%rsi
 1f7e727:	mov    (%r12,%r13,4),%r9d
 1f7e72b:	mov    0xca8(%rdi),%rdx
 1f7e732:	shl    $0x6,%rax
 1f7e736:	mov    %r8b,0x1f0(%rsp)
 1f7e73e:	mov    0x20(%r11),%rcx
 1f7e742:	cmpb   $0x1,(%rdx,%r9,1)
 1f7e747:	mov    %r9,0x230(%rsp)
 1f7e74f:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7e754:	adc    $0x0,%rsi
 1f7e758:	and    $0x1,%edx
 1f7e75b:	mov    %rsi,0x40(%rsp)
 1f7e760:	mov    0x98(%rsp),%r14
 1f7e768:	mov    (%r14,%r13,4),%esi
 1f7e76c:	vzeroupper
 1f7e76f:	call   1f939b0 <node_tests_window_line>
 1f7e774:	mov    %al,0x1b0(%rsp)
 1f7e77b:	mov    (%r14,%r13,4),%esi
 1f7e77f:	mov    0x18(%rsp),%rdi
 1f7e784:	call   1f93b00 <node_tests_window_returns>
 1f7e789:	mov    0x18(%rsp),%rdi
 1f7e78e:	or     0x1f0(%rsp),%al
 1f7e795:	mov    0x230(%rsp),%rdx
 1f7e79d:	vpbroadcastd -0x19ad873(%rip),%zmm14        # 5d0f34 <.LCPI3_5>
 1f7e7a7:	vpbroadcastb -0x1ac7a70(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e7b0:	vpbroadcastb -0x1ac7a79(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e7ba:	vpbroadcastd -0x19ad888(%rip),%zmm17        # 5d0f3c <.LCPI3_11>
 1f7e7c4:	vpbroadcastd -0x19ad88a(%rip),%zmm18        # 5d0f44 <.LCPI3_13>
 1f7e7ce:	vmovdqa 0x270(%rsp),%xmm10
 1f7e7d7:	vmovdqu64 0x370(%rsp),%zmm11
 1f7e7e2:	vmovdqu64 0x2b0(%rsp),%ymm19
 1f7e7ed:	vmovdqu64 0x530(%rsp),%zmm20
 1f7e7f8:	vmovdqu64 0x430(%rsp),%ymm21
 1f7e803:	vmovdqu64 0x4f0(%rsp),%zmm7
 1f7e80e:	vmovdqu 0x3f0(%rsp),%ymm13
 1f7e817:	vmovdqu64 0x570(%rsp),%zmm22
 1f7e822:	vmovdqu64 0x650(%rsp),%ymm23
 1f7e82d:	vmovdqu64 0x610(%rsp),%zmm5
 1f7e838:	vmovdqu 0x4b0(%rsp),%ymm6
 1f7e841:	vmovdqu64 0x5d0(%rsp),%zmm24
 1f7e84c:	vmovdqu64 0x6c0(%rsp),%ymm25
 1f7e854:	vmovdqu64 0x780(%rsp),%zmm4
 1f7e85c:	vmovdqu64 0x490(%rsp),%ymm26
 1f7e867:	vmovdqu64 0x740(%rsp),%zmm27
 1f7e86f:	vmovdqu64 0x470(%rsp),%ymm28
 1f7e87a:	vmovdqu64 0x820(%rsp),%zmm0
 1f7e885:	mov    0x8(%rsp),%r11
 1f7e88a:	mov    0x38(%rsp),%rsi
 1f7e88f:	mov    0x150(%rsp),%r8
 1f7e897:	mov    0x20(%rsp),%r9
 1f7e89c:	kmovd  0x2f0(%rsp),%k6
 1f7e8a6:	kmovw  0x3b0(%rsp),%k7
 1f7e8af:	or     0x1b0(%rsp),%al
 1f7e8b6:	mov    0xca8(%rdi),%rcx
 1f7e8bd:	mov    %al,(%rcx,%rdx,1)
 1f7e8c0:	mov    0x50(%rsp),%eax
 1f7e8c4:	blsr   %eax,%eax
 1f7e8c9:	je     1f7e93b <node_facts_window_run+0x14ab>
 1f7e8cb:	tzcnt  %eax,%r13d
 1f7e8d0:	mov    %eax,0x50(%rsp)
 1f7e8d4:	mov    0x60(%r11),%edx
 1f7e8d8:	mov    $0x1,%r8b
 1f7e8db:	add    %rbx,%r13
 1f7e8de:	mov    %r13,%rcx
 1f7e8e1:	shl    $0x6,%rcx
 1f7e8e5:	mov    (%r9,%rcx,1),%eax
 1f7e8e9:	mov    0xc(%r9,%rcx,1),%ecx
 1f7e8ee:	shr    $0x3,%eax
 1f7e8f1:	cmp    %edx,%eax
 1f7e8f3:	cmovae %edx,%eax
 1f7e8f6:	test   %rcx,%rcx
 1f7e8f9:	je     1f7e722 <node_facts_window_run+0x1292>
 1f7e8ff:	mov    0x90(%rsp),%rdx
 1f7e907:	mov    0x40(%rsp),%rsi
 1f7e90c:	cmp    0x3b8(%rdx),%ecx
 1f7e912:	jae    1f7e727 <node_facts_window_run+0x1297>
 1f7e918:	mov    0x90(%rsp),%rdx
 1f7e920:	mov    0x3a8(%rdx),%rdx
 1f7e927:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7e92b:	setne  %r8b
 1f7e92f:	shl    $0x5,%r8b
 1f7e933:	inc    %r8b
 1f7e936:	jmp    1f7e727 <node_facts_window_run+0x1297>
 1f7e93b:	mov    0xca8(%rdi),%rax
 1f7e942:	kmovq  %k7,%k1
 1f7e947:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e94c:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7e953:	jmp    1f7df0e <node_facts_window_run+0xa7e>
 1f7e958:	cmpq   $0x0,0xb40(%r11)
 1f7e960:	je     1f80062 <node_facts_window_run+0x2bd2>
 1f7e966:	test   %eax,%eax
 1f7e968:	je     1f808b7 <node_facts_window_run+0x3427>
 1f7e96e:	vpbroadcastd -0x19ada44(%rip),%zmm10        # 5d0f34 <.LCPI3_5>
 1f7e978:	vpbroadcastb -0x1ac7c41(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e981:	vpbroadcastb -0x1ac7c49(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e98a:	vpbroadcastd -0x19ada58(%rip),%zmm13        # 5d0f3c <.LCPI3_11>
 1f7e994:	vpbroadcastd -0x19ada5a(%rip),%zmm14        # 5d0f44 <.LCPI3_13>
 1f7e99e:	mov    (%r11),%rcx
 1f7e9a1:	lea    0x69454(%r13),%r10
 1f7e9a8:	lea    0x422c(%r13),%rdx
 1f7e9af:	mov    %eax,%r15d
 1f7e9b2:	xor    %r14d,%r14d
 1f7e9b5:	mov    %rcx,0x5d0(%rsp)
 1f7e9bd:	mov    %r10,0x650(%rsp)
 1f7e9c5:	mov    %rdx,0x610(%rsp)
 1f7e9cd:	movq   $0x0,0x40(%rsp)
 1f7e9d6:	movq   $0x0,0x110(%rsp)
 1f7e9e2:	movq   $0x0,0x10(%rsp)
 1f7e9eb:	mov    %r15,0x4b0(%rsp)
 1f7e9f3:	jmp    1f7ea83 <node_facts_window_run+0x15f3>
 1f7e9f8:	nopl   0x0(%rax,%rax,1)
 1f7ea00:	vpxor  %xmm1,%xmm1,%xmm1
 1f7ea04:	vpxor  %xmm3,%xmm3,%xmm3
 1f7ea08:	vpxor  %xmm4,%xmm4,%xmm4
 1f7ea0c:	vpxor  %xmm5,%xmm5,%xmm5
 1f7ea10:	vpxor  %xmm0,%xmm0,%xmm0
 1f7ea14:	vpxord %xmm16,%xmm16,%xmm16
 1f7ea1a:	mov    0xc70(%rdi),%rax
 1f7ea21:	vmovdqu64 %xmm16,(%rax,%r14,1)
 1f7ea28:	mov    0xc78(%rdi),%rax
 1f7ea2f:	vmovdqu %xmm0,(%rax,%r14,1)
 1f7ea35:	mov    0xb88(%r11),%rax
 1f7ea3c:	vmovdqu %xmm5,(%rax,%r14,1)
 1f7ea42:	mov    0xb90(%r11),%rax
 1f7ea49:	vmovdqu %xmm4,(%rax,%r14,1)
 1f7ea4f:	mov    0xb98(%r11),%rax
 1f7ea56:	vmovdqu %xmm3,(%rax,%r14,1)
 1f7ea5c:	mov    0xba0(%r11),%rax
 1f7ea63:	vmovdqu %xmm1,(%rax,%r14,1)
 1f7ea69:	mov    0xba8(%r11),%rax
 1f7ea70:	vmovdqu %xmm2,(%rax,%r14,1)
 1f7ea76:	add    $0x10,%r14
 1f7ea7a:	cmp    %r15,%r14
 1f7ea7d:	jae    1f808d5 <node_facts_window_run+0x3445>
 1f7ea83:	vpxor  %xmm2,%xmm2,%xmm2
 1f7ea87:	cmp    %r8,%r14
 1f7ea8a:	jae    1f7ea00 <node_facts_window_run+0x1570>
 1f7ea90:	mov    %r8d,%eax
 1f7ea93:	sub    %r14d,%eax
 1f7ea96:	mov    $0x10,%ecx
 1f7ea9b:	mov    $0xffffffff,%edx
 1f7eaa0:	mov    %r14,%rbp
 1f7eaa3:	vpxord %xmm18,%xmm18,%xmm18
 1f7eaa9:	cmp    $0x10,%eax
 1f7eaac:	cmovae %ecx,%eax
 1f7eaaf:	mov    0x9b8(%r11),%rcx
 1f7eab6:	shl    $0x6,%rbp
 1f7eaba:	shlx   %eax,%edx,%eax
 1f7eabf:	vmovdqu (%r9,%rbp,1),%ymm0
 1f7eac5:	vmovdqu 0x180(%r9,%rbp,1),%ymm3
 1f7eacf:	vmovdqu 0x80(%r9,%rbp,1),%ymm1
 1f7ead9:	vmovdqu 0x100(%r9,%rbp,1),%ymm2
 1f7eae3:	not    %eax
 1f7eae5:	vinserti64x4 $0x1,0x40(%r9,%rbp,1),%zmm0,%zmm6
 1f7eaee:	vmovdqu 0x200(%r9,%rbp,1),%ymm0
 1f7eaf8:	vinserti64x4 $0x1,0x1c0(%r9,%rbp,1),%zmm3,%zmm7
 1f7eb01:	vinserti64x4 $0x1,0xc0(%r9,%rbp,1),%zmm1,%zmm1
 1f7eb0a:	vinserti64x4 $0x1,0x140(%r9,%rbp,1),%zmm2,%zmm2
 1f7eb13:	kmovd  %eax,%k1
 1f7eb17:	vinserti64x4 $0x1,0x240(%r9,%rbp,1),%zmm0,%zmm3
 1f7eb20:	vmovdqu 0x280(%r9,%rbp,1),%ymm0
 1f7eb2a:	mov    0xca8(%rdi),%rax
 1f7eb31:	vinserti64x4 $0x1,0x2c0(%r9,%rbp,1),%zmm0,%zmm9
 1f7eb3a:	vmovdqu 0x300(%r9,%rbp,1),%ymm0
 1f7eb44:	vmovdqu8 (%rcx,%r14,1),%xmm4{%k1}{z}
 1f7eb4b:	mov    0x650(%rsp),%rcx
 1f7eb53:	vinserti64x4 $0x1,0x340(%r9,%rbp,1),%zmm0,%zmm8
 1f7eb5c:	vmovdqu 0x380(%r9,%rbp,1),%ymm0
 1f7eb66:	vinserti64x4 $0x1,0x3c0(%r9,%rbp,1),%zmm0,%zmm15
 1f7eb6f:	vmovdqu8 (%rcx,%r14,1),%xmm5{%k1}{z}
 1f7eb76:	vptestmb %xmm4,%xmm4,%k6
 1f7eb7c:	vpcmpeqb -0x19b6e76(%rip),%xmm5,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7eb86:	vmovdqu32 (%r12,%r14,4),%zmm0{%k7}{z}
 1f7eb8d:	kmovq  %k7,%k1
 1f7eb92:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7eb99:	vptestnmd %zmm13,%zmm18,%k0
 1f7eb9f:	ktestw %k0,%k7
 1f7eba3:	jne    1f7f16e <node_facts_window_run+0x1cde>
 1f7eba9:	vmovdqa64 -0x1ac8473(%rip),%zmm0        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7ebb3:	vptestmd -0x19adc7d(%rip){1to16},%zmm18,%k0        # 5d0f40 <.LCPI3_12>
 1f7ebbd:	kmovd  %k6,%edx
 1f7ebc1:	vpermt2d %zmm1,%zmm0,%zmm6
 1f7ebc7:	vpermt2d %zmm7,%zmm0,%zmm2
 1f7ebcd:	vpermt2d %zmm9,%zmm0,%zmm3
 1f7ebd3:	vpermt2d %zmm15,%zmm0,%zmm8
 1f7ebd9:	kmovd  %k0,%r13d
 1f7ebdd:	vptestmd %zmm14,%zmm18,%k0
 1f7ebe3:	vshufi64x2 $0x44,%zmm2,%zmm6,%zmm0
 1f7ebea:	vshufi64x2 $0x44,%zmm8,%zmm3,%zmm1
 1f7ebf1:	vshufi64x2 $0xee,%zmm2,%zmm6,%zmm2
 1f7ebf8:	vshufi64x2 $0xee,%zmm8,%zmm3,%zmm3
 1f7ebff:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm15{%k6}{z}
 1f7ec06:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7ec0d:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm17{%k6}{z}
 1f7ec14:	vshufi64x2 $0x88,%zmm3,%zmm2,%zmm7
 1f7ec1b:	vpsrld $0x19,%zmm15,%zmm0
 1f7ec22:	vpandd -0x19adcfc(%rip){1to16},%zmm0,%zmm0        # 5d0f30 <.LCPI3_4>
 1f7ec2c:	vpsrld $0x18,%zmm15,%zmm1
 1f7ec33:	vpsrld $0x1a,%zmm15,%zmm6
 1f7ec3a:	vpternlogd $0xec,%zmm10,%zmm0,%zmm1
 1f7ec41:	vpandd -0x19adccf(%rip){1to16},%zmm15,%zmm0        # 5d0f7c <.LCPI3_75>
 1f7ec4b:	vpmovdb %zmm1,%xmm16
 1f7ec51:	vpsrld $0xc,%zmm17,%zmm1
 1f7ec58:	vpmovdb %zmm1,%xmm20
 1f7ec5e:	vpcmpeqd -0x19add30(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f38 <.LCPI3_7>
 1f7ec68:	vporq  %xmm11,%xmm16,%xmm0
 1f7ec6e:	vmovdqu8 %xmm0,%xmm16{%k1}
 1f7ec74:	vpcmpeqb %xmm11,%xmm5,%k1{%k6}
 1f7ec7a:	vpternlogq $0xf8,%xmm12,%xmm20,%xmm16
 1f7ec81:	kmovd  %k1,%eax
 1f7ec85:	kmovw  %k1,0x50(%rsp)
 1f7ec8b:	korw   %k0,%k1,%k1
 1f7ec8f:	kmovw  %k1,0x230(%rsp)
 1f7ec98:	test   %ax,%ax
 1f7ec9b:	je     1f7ee2e <node_facts_window_run+0x199e>
 1f7eca1:	vmovdqu64 %zmm7,0x570(%rsp)
 1f7ecac:	vmovdqu64 %zmm6,0x3f0(%rsp)
 1f7ecb7:	vmovdqa64 %xmm20,0x4f0(%rsp)
 1f7ecbf:	vmovdqu64 %zmm19,0x430(%rsp)
 1f7ecca:	vmovdqu64 %zmm18,0x530(%rsp)
 1f7ecd5:	vmovdqu64 %zmm15,0x2b0(%rsp)
 1f7ece0:	vmovdqa %xmm4,0x270(%rsp)
 1f7ece9:	vmovdqu64 %zmm17,0x370(%rsp)
 1f7ecf4:	mov    %edx,0x3b0(%rsp)
 1f7ecfb:	vmovdqa64 %xmm16,0x2f0(%rsp)
 1f7ed03:	kmovw  %k7,0x1f0(%rsp)
 1f7ed0c:	kmovw  %k6,0x1b0(%rsp)
 1f7ed15:	movzwl %ax,%ebx
 1f7ed18:	movzwl %r13w,%r13d
 1f7ed1c:	mov    0x610(%rsp),%rax
 1f7ed24:	lea    (%rax,%r14,4),%r15
 1f7ed28:	nopl   0x0(%rax,%rax,1)
 1f7ed30:	xor    %r12d,%r12d
 1f7ed33:	tzcnt  %ebx,%r12d
 1f7ed38:	xor    %edx,%edx
 1f7ed3a:	mov    (%r15,%r12,4),%esi
 1f7ed3e:	vzeroupper
 1f7ed41:	call   1f939b0 <node_tests_window_line>
 1f7ed46:	mov    0x18(%rsp),%rdi
 1f7ed4b:	mov    $0x1,%edx
 1f7ed50:	xor    %ecx,%ecx
 1f7ed52:	test   $0x2,%al
 1f7ed54:	shlx   %r12d,%edx,%eax
 1f7ed59:	cmove  %ecx,%eax
 1f7ed5c:	or     %eax,%r13d
 1f7ed5f:	blsr   %ebx,%ebx
 1f7ed64:	jne    1f7ed30 <node_facts_window_run+0x18a0>
 1f7ed66:	vpbroadcastd -0x19ade3c(%rip),%zmm10        # 5d0f34 <.LCPI3_5>
 1f7ed70:	vpbroadcastb -0x1ac8039(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7ed79:	vpbroadcastb -0x1ac8041(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7ed82:	vpbroadcastd -0x19ade50(%rip),%zmm13        # 5d0f3c <.LCPI3_11>
 1f7ed8c:	vpbroadcastd -0x19ade52(%rip),%zmm14        # 5d0f44 <.LCPI3_13>
 1f7ed96:	vmovdqa64 0x2f0(%rsp),%xmm16
 1f7ed9e:	vmovdqu64 0x370(%rsp),%zmm17
 1f7eda9:	vmovdqa 0x270(%rsp),%xmm4
 1f7edb2:	vmovdqu64 0x2b0(%rsp),%zmm15
 1f7edbd:	vmovdqu64 0x530(%rsp),%zmm18
 1f7edc8:	vmovdqu64 0x430(%rsp),%zmm19
 1f7edd3:	vmovdqa64 0x4f0(%rsp),%xmm20
 1f7eddb:	vmovdqu64 0x3f0(%rsp),%zmm6
 1f7ede6:	vmovdqu64 0x570(%rsp),%zmm7
 1f7edf1:	mov    0x8(%rsp),%r11
 1f7edf6:	mov    0x38(%rsp),%rsi
 1f7edfb:	mov    0x30(%rsp),%r12
 1f7ee00:	mov    0x150(%rsp),%r8
 1f7ee08:	mov    0x20(%rsp),%r9
 1f7ee0d:	mov    0x4b0(%rsp),%r15
 1f7ee15:	kmovw  0x1b0(%rsp),%k6
 1f7ee1e:	kmovw  0x1f0(%rsp),%k7
 1f7ee27:	mov    0x3b0(%rsp),%edx
 1f7ee2e:	vpsrld $0x2,%zmm17,%zmm0
 1f7ee35:	vpandd -0x19adef7(%rip){1to16},%zmm0,%zmm0        # 5d0f48 <.LCPI3_14>
 1f7ee3f:	vptestmd -0x19adef9(%rip){1to16},%zmm17,%k2        # 5d0f50 <.LCPI3_16>
 1f7ee49:	vpandd -0x19aded3(%rip){1to16},%zmm15,%zmm3        # 5d0f80 <.LCPI3_78>
 1f7ee53:	vptestnmb %xmm4,%xmm4,%k0
 1f7ee59:	vpbroadcastd -0x19adf07(%rip),%zmm4        # 5d0f5c <.LCPI3_21>
 1f7ee63:	vptestmd -0x19adf19(%rip){1to16},%zmm19,%k3        # 5d0f54 <.LCPI3_17>
 1f7ee6d:	vpandd %zmm14,%zmm19,%zmm1
 1f7ee73:	vpbroadcastb -0x1ac8138(%rip),%xmm8        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7ee7c:	vpbroadcastb -0x1ac8143(%rip),%xmm5        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7ee85:	vpbroadcastb -0x1ac814b(%rip),%xmm9        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7ee8e:	vpcmpneqd -0x19adf4d(%rip){1to16},%zmm0,%k1        # 5d0f4c <.LCPI3_15>
 1f7ee99:	vpaddd -0x19adf4b(%rip){1to16},%zmm3,%zmm3        # 5d0f58 <.LCPI3_20>
 1f7eea3:	vpcmpeqd %zmm4,%zmm6,%k5{%k6}
 1f7eea9:	vpsrld $0x10,%zmm17,%zmm6
 1f7eeb0:	korw   %k1,%k2,%k1
 1f7eeb4:	vptestnmd %zmm7,%zmm7,%k2
 1f7eeba:	korw   %k2,%k0,%k2
 1f7eebe:	vptestnmd %zmm1,%zmm1,%k0
 1f7eec4:	korw   %k1,%k2,%k1
 1f7eec8:	kmovd  %k0,%eax
 1f7eecc:	vpcmpltud %zmm4,%zmm3,%k0
 1f7eed3:	vpslld $0x1f,%zmm3,%zmm3
 1f7eeda:	vpxor  %xmm4,%xmm4,%xmm4
 1f7eede:	vptestmd %zmm0,%zmm0,%k1{%k1}
 1f7eee4:	kmovd  %k0,%ecx
 1f7eee8:	and    %eax,%ecx
 1f7eeea:	mov    %edx,%eax
 1f7eeec:	and    %ecx,%eax
 1f7eeee:	kmovd  %eax,%k4
 1f7eef2:	vmovdqu8 %xmm11,%xmm2{%k1}{z}
 1f7eef8:	kmovd  %r13d,%k1
 1f7eefd:	korw   %k3,%k1,%k3
 1f7ef01:	vpcmpeqd %zmm13,%zmm0,%k1{%k4}
 1f7ef07:	vmovdqu8 %xmm8,%xmm0{%k5}{z}
 1f7ef0d:	vmovdqu8 -0x19b71d7(%rip),%xmm0{%k4}        # 5c7d40 <.LCPI3_25>
 1f7ef17:	knotw  %k1,%k0
 1f7ef1b:	kmovd  %k0,%ecx
 1f7ef1f:	and    %eax,%ecx
 1f7ef21:	kmovd  %ecx,%k4
 1f7ef25:	vpcmpgtd %zmm3,%zmm4,%k4{%k4}
 1f7ef2b:	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
 1f7ef32:	vpaddd %zmm3,%zmm6,%zmm7
 1f7ef38:	vpbroadcastb -0x1ac81fc(%rip),%xmm3        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7ef41:	vmovdqu8 -0x19b71fb(%rip),%xmm0{%k4}        # 5c7d50 <.LCPI3_26>
 1f7ef4b:	vptestnmd %zmm7,%zmm7,%k4
 1f7ef51:	vpblendmb -0x19b71eb(%rip),%xmm3,%xmm3{%k4}        # 5c7d70 <.LCPI3_28>
 1f7ef5b:	vpcmpnleud -0x19ae006(%rip){1to16},%zmm7,%k4        # 5d0f60 <.LCPI3_22>
 1f7ef66:	cmpb   $0x0,0xcf0(%rdi)
 1f7ef6d:	vmovdqu8 -0x19b71f7(%rip),%xmm3{%k4}        # 5c7d80 <.LCPI3_29>
 1f7ef77:	vpcmpnleud -0x19ae01e(%rip){1to16},%zmm7,%k4        # 5d0f64 <.LCPI3_23>
 1f7ef82:	vmovdqu8 -0x19b71fc(%rip),%xmm3{%k4}        # 5c7d90 <.LCPI3_30>
 1f7ef8c:	vptestmd %zmm1,%zmm1,%k4
 1f7ef92:	vpor   %xmm5,%xmm2,%xmm1
 1f7ef96:	vmovdqu8 %xmm1,%xmm2{%k4}
 1f7ef9c:	kmovw  0x230(%rsp),%k4
 1f7efa5:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f7efab:	vpor   %xmm0,%xmm2,%xmm0
 1f7efaf:	vpord  -0x19ae035(%rip){1to4},%xmm0,%xmm1        # 5d0f84 <.LCPI3_81>
 1f7efb9:	vpbroadcastb -0x1ac827c(%rip),%xmm3        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7efc2:	vmovdqu8 %xmm1,%xmm0{%k4}
 1f7efc8:	vpor   %xmm3,%xmm0,%xmm1
 1f7efcc:	vmovdqu8 %xmm1,%xmm0{%k3}
 1f7efd2:	vpmovdb %zmm17,%xmm1
 1f7efd8:	kmovw  0x50(%rsp),%k3
 1f7efde:	vpor   %xmm1,%xmm9,%xmm2
 1f7efe2:	vmovdqu8 %xmm2,%xmm1{%k3}
 1f7efe8:	vptestmd -0x19ae08a(%rip){1to16},%zmm18,%k3{%k7}        # 5d0f68 <.LCPI3_32>
 1f7eff2:	vmovdqu8 %xmm8,%xmm2{%k3}{z}
 1f7eff8:	vpor   %xmm3,%xmm2,%xmm3
 1f7effc:	vpsrld $0x8,%zmm15,%zmm8
 1f7f003:	vmovdqu8 %xmm2,%xmm3{%k2}
 1f7f009:	vpandd -0x19ae08b(%rip){1to4},%xmm20,%xmm2        # 5d0f88 <.LCPI3_83>
 1f7f013:	vptestmd -0x19ae0b1(%rip){1to16},%zmm19,%k2        # 5d0f6c <.LCPI3_33>
 1f7f01d:	vpor   %xmm2,%xmm12,%xmm4
 1f7f021:	vmovdqu8 %xmm4,%xmm2{%k6}
 1f7f027:	vpmovdb %zmm19,%xmm4
 1f7f02d:	vgf2p8affineqb $0x0,-0x19b0ae0(%rip){1to2},%xmm4,%xmm4        # 5ce558 <.LCPI3_84>
 1f7f038:	vpternlogq $0xf8,%xmm9,%xmm4,%xmm2
 1f7f03f:	vpor   %xmm2,%xmm11,%xmm4
 1f7f043:	vmovdqu8 %xmm4,%xmm2{%k2}
 1f7f049:	vpsrld $0xb,%zmm19,%zmm4
 1f7f050:	vpmovdb %zmm4,%xmm4
 1f7f056:	vpand  %xmm5,%xmm4,%xmm4
 1f7f05a:	vpmovdb %zmm15,%xmm5
 1f7f060:	vpternlogq $0xfe,%xmm4,%xmm3,%xmm2
 1f7f067:	vpsrld $0x10,%zmm15,%zmm3
 1f7f06e:	vpmovdb %zmm8,%xmm4
 1f7f074:	vpmovdb %zmm3,%xmm3
 1f7f07a:	je     1f7f164 <node_facts_window_run+0x1cd4>
 1f7f080:	vmovdqa64 -0x1ac888a(%rip),%zmm15        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7f08a:	vptestmd %zmm6,%zmm6,%k1{%k1}
 1f7f090:	add    %r9,%rbp
 1f7f093:	vpxor  %xmm8,%xmm8,%xmm8
 1f7f098:	vpxor  %xmm9,%xmm9,%xmm9
 1f7f09d:	vpcmpneqd -0x19ae138(%rip){1to16},%zmm6,%k0{%k1}        # 5d0f70 <.LCPI3_38>
 1f7f0a8:	vmovdqa %xmm3,%xmm6
 1f7f0ac:	vpternlogq $0xfe,%xmm5,%xmm1,%xmm6
 1f7f0b3:	kmovq  %k1,%k2
 1f7f0b8:	kmovw  %k1,%eax
 1f7f0bc:	popcnt %eax,%ecx
 1f7f0c0:	vpgatherdd 0x10(%rbp,%zmm15,1),%zmm8{%k2}
 1f7f0c8:	kmovq  %k1,%k2
 1f7f0cd:	vpcmpnleud -0x19ae164(%rip){1to16},%zmm8,%k3        # 5d0f74 <.LCPI3_39>
 1f7f0d8:	vpgatherdd 0x14(%rbp,%zmm15,1),%zmm9{%k2}
 1f7f0e0:	add    %rcx,0x110(%rsp)
 1f7f0e8:	mov    0x10(%rsp),%r10
 1f7f0ed:	vpcmpeqd %zmm7,%zmm8,%k2
 1f7f0f3:	vmovdqa64 %xmm16,%xmm7
 1f7f0f9:	vpternlogq $0xfe,%xmm4,%xmm6,%xmm7
 1f7f100:	vptestnmd %zmm9,%zmm9,%k2{%k2}
 1f7f106:	vptestmd %zmm9,%zmm9,%k4
 1f7f10c:	vpternlogq $0xfe,%xmm2,%xmm0,%xmm7
 1f7f113:	korw   %k4,%k3,%k3
 1f7f117:	kandw  %k2,%k0,%k2
 1f7f11b:	knotw  %k0,%k0
 1f7f11f:	kandd  %k1,%k0,%k0
 1f7f124:	kandw  %k0,%k3,%k0
 1f7f128:	korw   %k0,%k2,%k2
 1f7f12c:	vptestnmd %zmm10,%zmm17,%k0{%k2}
 1f7f132:	kandw  %k0,%k1,%k0
 1f7f136:	kmovd  %k0,%ecx
 1f7f13a:	vptestmb %xmm7,%xmm7,%k0
 1f7f140:	andn   %eax,%ecx,%eax
 1f7f145:	kmovd  %k0,%ecx
 1f7f149:	andn   %ecx,%edx,%ecx
 1f7f14e:	popcnt %eax,%eax
 1f7f152:	movzwl %cx,%ecx
 1f7f155:	popcnt %ecx,%ecx
 1f7f159:	add    %rcx,%r10
 1f7f15c:	add    %rax,%r10
 1f7f15f:	mov    %r10,0x10(%rsp)
 1f7f164:	mov    0x28(%rsp),%r13
 1f7f169:	jmp    1f7ea1a <node_facts_window_run+0x158a>
 1f7f16e:	kandw  %k0,%k7,%k0
 1f7f172:	vmovdqa %xmm5,0x230(%rsp)
 1f7f17b:	vmovdqu64 %zmm6,0x2f0(%rsp)
 1f7f186:	vmovdqu64 %zmm2,0x3b0(%rsp)
 1f7f191:	vmovdqu64 %zmm3,0x370(%rsp)
 1f7f19c:	vmovdqu64 %zmm1,0x2b0(%rsp)
 1f7f1a7:	vmovdqu64 %zmm7,0x530(%rsp)
 1f7f1b2:	vmovdqu64 %zmm8,0x430(%rsp)
 1f7f1bd:	vmovdqu64 %zmm9,0x4f0(%rsp)
 1f7f1c8:	vmovdqu64 %zmm15,0x3f0(%rsp)
 1f7f1d3:	vmovdqu64 %zmm0,0x570(%rsp)
 1f7f1de:	kmovw  %k6,0x1b0(%rsp)
 1f7f1e7:	kmovw  %k7,0x1f0(%rsp)
 1f7f1f0:	vmovdqa %xmm4,0x270(%rsp)
 1f7f1f9:	kmovd  %k0,%eax
 1f7f1fd:	movzwl %ax,%r13d
 1f7f201:	jmp    1f7f32f <node_facts_window_run+0x1e9f>
 1f7f206:	mov    (%r12,%rax,4),%r9d
 1f7f20a:	mov    0xca8(%rdi),%rsi
 1f7f211:	shl    $0x6,%rcx
 1f7f215:	mov    0x20(%r11),%rdx
 1f7f219:	cmpb   $0x1,(%rsi,%r9,1)
 1f7f21e:	mov    %r9,0x50(%rsp)
 1f7f223:	movzbl 0x30(%rdx,%rcx,1),%edx
 1f7f228:	adcq   $0x0,0x40(%rsp)
 1f7f22e:	and    $0x1,%edx
 1f7f231:	mov    0x610(%rsp),%rsi
 1f7f239:	mov    (%rsi,%rax,4),%esi
 1f7f23c:	vzeroupper
 1f7f23f:	call   1f939b0 <node_tests_window_line>
 1f7f244:	mov    0x18(%rsp),%rdi
 1f7f249:	vpbroadcastd -0x19ae31f(%rip),%zmm10        # 5d0f34 <.LCPI3_5>
 1f7f253:	vpbroadcastb -0x1ac851c(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f25c:	vpbroadcastb -0x1ac8524(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f265:	vpbroadcastd -0x19ae333(%rip),%zmm13        # 5d0f3c <.LCPI3_11>
 1f7f26f:	vpbroadcastd -0x19ae335(%rip),%zmm14        # 5d0f44 <.LCPI3_13>
 1f7f279:	vmovdqa 0x270(%rsp),%xmm4
 1f7f282:	vmovdqa 0x230(%rsp),%xmm5
 1f7f28b:	vmovdqu64 0x2f0(%rsp),%zmm6
 1f7f296:	vmovdqu64 0x3b0(%rsp),%zmm2
 1f7f2a1:	vmovdqu64 0x370(%rsp),%zmm3
 1f7f2ac:	vmovdqu64 0x2b0(%rsp),%zmm1
 1f7f2b7:	vmovdqu64 0x530(%rsp),%zmm7
 1f7f2c2:	vmovdqu64 0x430(%rsp),%zmm8
 1f7f2cd:	vmovdqu64 0x4f0(%rsp),%zmm9
 1f7f2d8:	vmovdqu64 0x3f0(%rsp),%zmm15
 1f7f2e3:	vmovdqu64 0x570(%rsp),%zmm0
 1f7f2ee:	mov    0x8(%rsp),%r11
 1f7f2f3:	mov    0x50(%rsp),%rdx
 1f7f2f8:	mov    0x38(%rsp),%rsi
 1f7f2fd:	mov    0x150(%rsp),%r8
 1f7f305:	mov    0x20(%rsp),%r9
 1f7f30a:	kmovw  0x1b0(%rsp),%k6
 1f7f313:	kmovw  0x1f0(%rsp),%k7
 1f7f31c:	or     %bl,%al
 1f7f31e:	blsr   %r13d,%r13d
 1f7f323:	mov    0xca8(%rdi),%rcx
 1f7f32a:	mov    %al,(%rcx,%rdx,1)
 1f7f32d:	je     1f7f394 <node_facts_window_run+0x1f04>
 1f7f32f:	xor    %eax,%eax
 1f7f331:	tzcnt  %r13d,%eax
 1f7f336:	mov    0x60(%r11),%esi
 1f7f33a:	mov    $0x1,%bl
 1f7f33c:	add    %r14,%rax
 1f7f33f:	mov    %rax,%rdx
 1f7f342:	shl    $0x6,%rdx
 1f7f346:	mov    (%r9,%rdx,1),%ecx
 1f7f34a:	mov    0xc(%r9,%rdx,1),%edx
 1f7f34f:	shr    $0x3,%ecx
 1f7f352:	cmp    %esi,%ecx
 1f7f354:	cmovae %esi,%ecx
 1f7f357:	test   %rdx,%rdx
 1f7f35a:	je     1f7f206 <node_facts_window_run+0x1d76>
 1f7f360:	mov    0x5d0(%rsp),%rsi
 1f7f368:	cmp    0x3b8(%rsi),%edx
 1f7f36e:	jae    1f7f206 <node_facts_window_run+0x1d76>
 1f7f374:	mov    0x5d0(%rsp),%rsi
 1f7f37c:	mov    0x3a8(%rsi),%rsi
 1f7f383:	cmpl   $0x0,(%rsi,%rdx,4)
 1f7f387:	setne  %bl
 1f7f38a:	shl    $0x5,%bl
 1f7f38d:	inc    %bl
 1f7f38f:	jmp    1f7f206 <node_facts_window_run+0x1d76>
 1f7f394:	mov    0xca8(%rdi),%rax
 1f7f39b:	kmovq  %k7,%k1
 1f7f3a0:	vpxord %xmm18,%xmm18,%xmm18
 1f7f3a6:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7f3ad:	jmp    1f7eba9 <node_facts_window_run+0x1719>
 1f7f3b2:	test   %eax,%eax
 1f7f3b4:	je     1f808b7 <node_facts_window_run+0x3427>
 1f7f3ba:	vpbroadcastd -0x19ae490(%rip),%zmm13        # 5d0f34 <.LCPI3_5>
 1f7f3c4:	vpbroadcastb -0x1ac868d(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f3cd:	vpbroadcastb -0x1ac8695(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f3d6:	vpbroadcastd -0x19ae4a4(%rip),%zmm16        # 5d0f3c <.LCPI3_11>
 1f7f3e0:	vpbroadcastd -0x19ae4a6(%rip),%zmm17        # 5d0f44 <.LCPI3_13>
 1f7f3ea:	mov    (%r11),%rcx
 1f7f3ed:	lea    0x69454(%r13),%r10
 1f7f3f4:	lea    0x422c(%r13),%rdx
 1f7f3fb:	mov    %eax,%r14d
 1f7f3fe:	xor    %r15d,%r15d
 1f7f401:	mov    %rcx,0x90(%rsp)
 1f7f409:	mov    %r10,0xb0(%rsp)
 1f7f411:	mov    %rdx,0x98(%rsp)
 1f7f419:	movq   $0x0,0x40(%rsp)
 1f7f422:	movq   $0x0,0x110(%rsp)
 1f7f42e:	movq   $0x0,0x10(%rsp)
 1f7f437:	mov    %r14,0xa8(%rsp)
 1f7f43f:	jmp    1f7f50b <node_facts_window_run+0x207b>
 1f7f444:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7f450:	vpxor  %xmm1,%xmm1,%xmm1
 1f7f454:	vpxor  %xmm0,%xmm0,%xmm0
 1f7f458:	vpxor  %xmm5,%xmm5,%xmm5
 1f7f45c:	vpxor  %xmm3,%xmm3,%xmm3
 1f7f460:	vpxor  %xmm6,%xmm6,%xmm6
 1f7f464:	vpxor  %xmm7,%xmm7,%xmm7
 1f7f468:	vpxor  %xmm8,%xmm8,%xmm8
 1f7f46d:	vpxor  %xmm2,%xmm2,%xmm2
 1f7f471:	vpxord %xmm19,%xmm19,%xmm19
 1f7f477:	mov    0xc70(%rdi),%rax
 1f7f47e:	vmovdqu64 %xmm19,(%rax,%r15,1)
 1f7f485:	mov    0xc78(%rdi),%rax
 1f7f48c:	vmovdqu %xmm2,(%rax,%r15,1)
 1f7f492:	mov    0xb88(%r11),%rax
 1f7f499:	vmovdqu %xmm8,(%rax,%r15,1)
 1f7f49f:	mov    0xb90(%r11),%rax
 1f7f4a6:	vmovdqu %xmm7,(%rax,%r15,1)
 1f7f4ac:	mov    0xb98(%r11),%rax
 1f7f4b3:	vmovdqu %xmm6,(%rax,%r15,1)
 1f7f4b9:	mov    0xba0(%r11),%rax
 1f7f4c0:	vmovdqu %xmm3,(%rax,%r15,1)
 1f7f4c6:	mov    0xba8(%r11),%rax
 1f7f4cd:	vmovdqu %xmm4,(%rax,%r15,1)
 1f7f4d3:	mov    0xc28(%r11),%rax
 1f7f4da:	vmovdqu64 %zmm5,(%rax,%r15,4)
 1f7f4e1:	mov    0xcd8(%r11),%rax
 1f7f4e8:	vmovdqu64 %zmm0,(%rax,%r15,8)
 1f7f4ef:	mov    0xcd8(%r11),%rax
 1f7f4f6:	vmovdqu64 %zmm1,0x40(%rax,%r15,8)
 1f7f4fe:	add    $0x10,%r15
 1f7f502:	cmp    %r14,%r15
 1f7f505:	jae    1f808d5 <node_facts_window_run+0x3445>
 1f7f50b:	vpxor  %xmm4,%xmm4,%xmm4
 1f7f50f:	cmp    %r8,%r15
 1f7f512:	jae    1f7f450 <node_facts_window_run+0x1fc0>
 1f7f518:	mov    %r8d,%eax
 1f7f51b:	sub    %r15d,%eax
 1f7f51e:	mov    $0x10,%ecx
 1f7f523:	mov    $0xffffffff,%edx
 1f7f528:	mov    %r15,%rbp
 1f7f52b:	vpxor  %xmm12,%xmm12,%xmm12
 1f7f530:	cmp    $0x10,%eax
 1f7f533:	cmovae %ecx,%eax
 1f7f536:	mov    0x9b8(%r11),%rcx
 1f7f53d:	shl    $0x6,%rbp
 1f7f541:	shlx   %eax,%edx,%eax
 1f7f546:	vmovdqu (%r9,%rbp,1),%ymm4
 1f7f54c:	vmovdqu64 0x40(%r9,%rbp,1),%ymm26
 1f7f554:	vmovdqu64 0x80(%r9,%rbp,1),%ymm27
 1f7f55c:	vmovdqu64 0xc0(%r9,%rbp,1),%ymm28
 1f7f564:	vmovdqu 0x100(%r9,%rbp,1),%ymm5
 1f7f56e:	vmovdqu 0x140(%r9,%rbp,1),%ymm6
 1f7f578:	vmovdqu64 0x180(%r9,%rbp,1),%ymm24
 1f7f580:	vmovdqu64 0x1c0(%r9,%rbp,1),%ymm25
 1f7f588:	vmovdqu 0x200(%r9,%rbp,1),%ymm7
 1f7f592:	vmovdqu64 0x240(%r9,%rbp,1),%ymm18
 1f7f59a:	vmovdqu64 0x280(%r9,%rbp,1),%ymm22
 1f7f5a2:	vmovdqu64 0x2c0(%r9,%rbp,1),%ymm23
 1f7f5aa:	vmovdqu 0x300(%r9,%rbp,1),%ymm11
 1f7f5b4:	vmovdqu64 0x340(%r9,%rbp,1),%ymm19
 1f7f5bc:	vmovdqu64 0x380(%r9,%rbp,1),%ymm20
 1f7f5c4:	vmovdqu64 0x3c0(%r9,%rbp,1),%ymm21
 1f7f5cc:	not    %eax
 1f7f5ce:	kmovd  %eax,%k1
 1f7f5d2:	mov    0xca8(%rdi),%rax
 1f7f5d9:	vmovdqu8 (%rcx,%r15,1),%xmm0{%k1}{z}
 1f7f5e0:	mov    0xb0(%rsp),%rcx
 1f7f5e8:	vmovdqu8 (%rcx,%r15,1),%xmm10{%k1}{z}
 1f7f5ef:	vptestmb %xmm0,%xmm0,%k6
 1f7f5f5:	vpcmpeqb -0x19b78ef(%rip),%xmm10,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7f5ff:	vmovdqu32 (%r12,%r15,4),%zmm0{%k7}{z}
 1f7f606:	kmovq  %k7,%k1
 1f7f60b:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7f612:	vptestnmd %zmm16,%zmm12,%k0
 1f7f618:	ktestw %k0,%k7
 1f7f61c:	jne    1f7fd4f <node_facts_window_run+0x28bf>
 1f7f622:	vpmovsxbd -0x19ae6b3(%rip),%xmm3        # 5d0f78 <.LCPI3_74>
 1f7f62b:	vmovdqa64 -0x1ac8ef5(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7f635:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7f63c:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7f643:	vptestmd -0x19ae70d(%rip){1to16},%zmm12,%k0        # 5d0f40 <.LCPI3_12>
 1f7f64d:	vmovdqa64 %zmm0,%zmm2
 1f7f653:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7f659:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7f65f:	vmovdqa64 %zmm3,%zmm9
 1f7f665:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7f66b:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7f671:	kmovd  %k0,%r13d
 1f7f675:	vptestmd %zmm17,%zmm12,%k0
 1f7f67b:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7f681:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7f688:	vmovdqu64 %zmm1,0x230(%rsp)
 1f7f693:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7f69a:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7f69e:	vmovdqa64 %zmm1,%zmm4
 1f7f6a4:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7f6aa:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7f6b0:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7f6b6:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7f6bc:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7f6c3:	vmovdqu %ymm3,0x1f0(%rsp)
 1f7f6cc:	vinserti64x4 $0x1,%ymm18,%zmm7,%zmm3
 1f7f6d3:	vpunpcklqdq %ymm18,%ymm7,%ymm7
 1f7f6d9:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm18
 1f7f6e0:	vmovdqa64 %zmm3,%zmm6
 1f7f6e6:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7f6ec:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7f6f2:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7f6f8:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7f6fe:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7f704:	vmovdqa64 %zmm18,%zmm7
 1f7f70a:	vmovdqu64 %zmm5,0x270(%rsp)
 1f7f715:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7f71c:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7f722:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7f729:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7f730:	vpermt2d %zmm5,%zmm9,%zmm18
 1f7f736:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7f73c:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7f743:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7f749:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7f74f:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7f756:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7f75d:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm21{%k6}{z}
 1f7f764:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7f76b:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm20{%k6}{z}
 1f7f772:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7f779:	vpsrld $0x19,%zmm21,%zmm0
 1f7f780:	vpandd -0x19ae85a(%rip){1to16},%zmm0,%zmm0        # 5d0f30 <.LCPI3_4>
 1f7f78a:	vpsrld $0x18,%zmm21,%zmm1
 1f7f791:	vpsrld $0x1a,%zmm21,%zmm7
 1f7f798:	vpternlogd $0xec,%zmm13,%zmm0,%zmm1
 1f7f79f:	vpandd -0x19ae82d(%rip){1to16},%zmm21,%zmm0        # 5d0f7c <.LCPI3_75>
 1f7f7a9:	vpmovdb %zmm1,%xmm19
 1f7f7af:	vpsrld $0xc,%zmm20,%zmm1
 1f7f7b6:	vpmovdb %zmm1,%xmm24
 1f7f7bc:	vpcmpeqd -0x19ae88e(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f38 <.LCPI3_7>
 1f7f7c6:	vporq  %xmm14,%xmm19,%xmm0
 1f7f7cc:	vmovdqu8 %xmm0,%xmm19{%k1}
 1f7f7d2:	vpcmpeqb %xmm14,%xmm10,%k1{%k6}
 1f7f7d8:	vpternlogq $0xf8,%xmm15,%xmm24,%xmm19
 1f7f7df:	kmovd  %k1,%eax
 1f7f7e3:	kmovw  %k1,0x50(%rsp)
 1f7f7e9:	korw   %k0,%k1,%k1
 1f7f7ed:	kmovw  %k1,0x1b0(%rsp)
 1f7f7f6:	test   %ax,%ax
 1f7f7f9:	je     1f7f9b1 <node_facts_window_run+0x2521>
 1f7f7ff:	vmovdqu64 %zmm4,0x6c0(%rsp)
 1f7f807:	vmovdqu %ymm5,0x5d0(%rsp)
 1f7f810:	vmovdqu64 %zmm7,0x4b0(%rsp)
 1f7f81b:	vmovdqa64 %xmm24,0x610(%rsp)
 1f7f823:	vmovdqu64 %zmm23,0x650(%rsp)
 1f7f82e:	vmovdqu64 %zmm22,0x570(%rsp)
 1f7f839:	vmovdqu64 %zmm21,0x3f0(%rsp)
 1f7f844:	vmovdqu64 %zmm18,0x4f0(%rsp)
 1f7f84f:	vmovdqu64 %zmm20,0x430(%rsp)
 1f7f85a:	vmovdqu64 %zmm12,0x530(%rsp)
 1f7f865:	vmovdqa64 %xmm19,0x2b0(%rsp)
 1f7f86d:	kmovw  %k7,0x3b0(%rsp)
 1f7f876:	mov    %rbp,0x370(%rsp)
 1f7f87e:	kmovd  %k6,0x2f0(%rsp)
 1f7f888:	movzwl %ax,%r14d
 1f7f88c:	movzwl %r13w,%r13d
 1f7f890:	xor    %ebp,%ebp
 1f7f892:	mov    0x98(%rsp),%rax
 1f7f89a:	lea    (%rax,%r15,4),%rbx
 1f7f89e:	xchg   %ax,%ax
 1f7f8a0:	xor    %r12d,%r12d
 1f7f8a3:	tzcnt  %r14d,%r12d
 1f7f8a8:	xor    %edx,%edx
 1f7f8aa:	mov    (%rbx,%r12,4),%esi
 1f7f8ae:	vzeroupper
 1f7f8b1:	call   1f939b0 <node_tests_window_line>
 1f7f8b6:	mov    0x18(%rsp),%rdi
 1f7f8bb:	mov    $0x1,%ecx
 1f7f8c0:	test   $0x2,%al
 1f7f8c2:	shlx   %r12d,%ecx,%eax
 1f7f8c7:	cmove  %ebp,%eax
 1f7f8ca:	or     %eax,%r13d
 1f7f8cd:	blsr   %r14d,%r14d
 1f7f8d2:	jne    1f7f8a0 <node_facts_window_run+0x2410>
 1f7f8d4:	vpbroadcastd -0x19ae9aa(%rip),%zmm13        # 5d0f34 <.LCPI3_5>
 1f7f8de:	vpbroadcastb -0x1ac8ba7(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f8e7:	vpbroadcastb -0x1ac8baf(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f8f0:	vpbroadcastd -0x19ae9be(%rip),%zmm16        # 5d0f3c <.LCPI3_11>
 1f7f8fa:	vpbroadcastd -0x19ae9c0(%rip),%zmm17        # 5d0f44 <.LCPI3_13>
 1f7f904:	vmovdqa64 0x2b0(%rsp),%xmm19
 1f7f90c:	vmovdqu64 0x530(%rsp),%zmm12
 1f7f917:	vmovdqu64 0x430(%rsp),%zmm20
 1f7f922:	vmovdqu64 0x4f0(%rsp),%zmm18
 1f7f92d:	vmovdqu64 0x3f0(%rsp),%zmm21
 1f7f938:	vmovdqu64 0x570(%rsp),%zmm22
 1f7f943:	vmovdqu64 0x650(%rsp),%zmm23
 1f7f94e:	vmovdqa64 0x610(%rsp),%xmm24
 1f7f956:	vmovdqu64 0x4b0(%rsp),%zmm7
 1f7f961:	vmovdqu 0x5d0(%rsp),%ymm5
 1f7f96a:	vmovdqu64 0x6c0(%rsp),%zmm4
 1f7f972:	mov    0x8(%rsp),%r11
 1f7f977:	mov    0x38(%rsp),%rsi
 1f7f97c:	mov    0x30(%rsp),%r12
 1f7f981:	mov    0x150(%rsp),%r8
 1f7f989:	mov    0x20(%rsp),%r9
 1f7f98e:	mov    0xa8(%rsp),%r14
 1f7f996:	kmovd  0x2f0(%rsp),%k6
 1f7f9a0:	mov    0x370(%rsp),%rbp
 1f7f9a8:	kmovw  0x3b0(%rsp),%k7
 1f7f9b1:	vpsrld $0x2,%zmm20,%zmm0
 1f7f9b8:	vpandd -0x19aea7a(%rip){1to16},%zmm0,%zmm2        # 5d0f48 <.LCPI3_14>
 1f7f9c2:	vpbroadcastd -0x19aea80(%rip),%zmm0        # 5d0f4c <.LCPI3_15>
 1f7f9cc:	vptestmd -0x19aea86(%rip){1to16},%zmm20,%k3        # 5d0f50 <.LCPI3_16>
 1f7f9d6:	vmovdqu64 0x270(%rsp),%zmm1
 1f7f9e1:	vptestnmd %zmm4,%zmm4,%k1
 1f7f9e7:	vpbroadcastd -0x19aea95(%rip),%zmm6        # 5d0f5c <.LCPI3_21>
 1f7f9f1:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7f9f8:	kmovd  %r13d,%k4
 1f7f9fd:	vpsrld $0x10,%zmm20,%zmm9
 1f7fa04:	vpbroadcastb -0x1ac8ccb(%rip),%xmm8        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7fa0d:	vpbroadcastb -0x1ac8cd3(%rip),%xmm11        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7fa16:	kmovw  %k1,%eax
 1f7fa1a:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7fa20:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7fa27:	vmovdqu64 0x230(%rsp),%zmm0
 1f7fa32:	korw   %k1,%k3,%k3
 1f7fa36:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7fa3d:	vpandd -0x19aeac7(%rip){1to16},%zmm21,%zmm5        # 5d0f80 <.LCPI3_78>
 1f7fa47:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7fa4d:	vpbroadcastb -0x1ac8d12(%rip),%xmm7        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7fa56:	vinserti64x4 $0x1,0x1f0(%rsp),%zmm0,%zmm0
 1f7fa62:	kmovw  %k0,%ecx
 1f7fa66:	korw   %k2,%k3,%k2
 1f7fa6a:	vpaddd -0x19aeb1c(%rip){1to16},%zmm5,%zmm5        # 5d0f58 <.LCPI3_20>
 1f7fa74:	andn   %ecx,%eax,%eax
 1f7fa79:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7fa7f:	kmovd  %eax,%k3
 1f7fa83:	shr    $0x8,%eax
 1f7fa86:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7fa8c:	kmovd  %eax,%k3
 1f7fa90:	vmovdqu8 %xmm14,%xmm4{%k2}{z}
 1f7fa96:	vpcmpltud %zmm6,%zmm5,%k2
 1f7fa9d:	vpslld $0x1f,%zmm5,%zmm5
 1f7faa4:	vpxor  %xmm6,%xmm6,%xmm6
 1f7faa8:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7faae:	vptestmd -0x19aeb64(%rip){1to16},%zmm23,%k3        # 5d0f54 <.LCPI3_17>
 1f7fab8:	vpandd %zmm17,%zmm23,%zmm3
 1f7fabe:	vptestnmd %zmm3,%zmm3,%k0
 1f7fac4:	kandd  %k6,%k0,%k0
 1f7fac9:	korw   %k3,%k4,%k3
 1f7facd:	kandd  %k2,%k0,%k4
 1f7fad2:	vpcmpeqd %zmm16,%zmm2,%k2{%k4}
 1f7fad8:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7fade:	vmovdqu8 -0x19b7da8(%rip),%xmm2{%k4}        # 5c7d40 <.LCPI3_25>
 1f7fae8:	knotw  %k2,%k0
 1f7faec:	kandd  %k0,%k4,%k5
 1f7faf1:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7faf7:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7fafe:	vpaddd %zmm5,%zmm9,%zmm10
 1f7fb04:	vpbroadcastb -0x1ac8dc8(%rip),%xmm5        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7fb0d:	vmovdqu8 -0x19b7dc7(%rip),%xmm2{%k4}        # 5c7d50 <.LCPI3_26>
 1f7fb17:	vptestnmd %zmm10,%zmm10,%k4
 1f7fb1d:	vpblendmb -0x19b7db7(%rip),%xmm5,%xmm5{%k4}        # 5c7d70 <.LCPI3_28>
 1f7fb27:	vpcmpnleud -0x19aebd2(%rip){1to16},%zmm10,%k4        # 5d0f60 <.LCPI3_22>
 1f7fb32:	cmpb   $0x0,0xcf0(%rdi)
 1f7fb39:	vmovdqu8 -0x19b7dc3(%rip),%xmm5{%k4}        # 5c7d80 <.LCPI3_29>
 1f7fb43:	vpcmpnleud -0x19aebea(%rip){1to16},%zmm10,%k4        # 5d0f64 <.LCPI3_23>
 1f7fb4e:	vmovdqu8 -0x19b7dc8(%rip),%xmm5{%k4}        # 5c7d90 <.LCPI3_30>
 1f7fb58:	vptestmd %zmm3,%zmm3,%k4
 1f7fb5e:	vpor   %xmm4,%xmm8,%xmm3
 1f7fb62:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7fb68:	kmovw  0x1b0(%rsp),%k4
 1f7fb71:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7fb77:	vpor   %xmm2,%xmm4,%xmm2
 1f7fb7b:	vpord  -0x19aec01(%rip){1to4},%xmm2,%xmm3        # 5d0f84 <.LCPI3_81>
 1f7fb85:	vpbroadcastb -0x1ac8e48(%rip),%xmm5        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7fb8e:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7fb94:	vpor   %xmm5,%xmm2,%xmm3
 1f7fb98:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7fb9e:	vpmovdb %zmm20,%xmm3
 1f7fba4:	kmovw  0x50(%rsp),%k3
 1f7fbaa:	vpor   %xmm3,%xmm11,%xmm4
 1f7fbae:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7fbb4:	vptestmd -0x19aec56(%rip){1to16},%zmm12,%k3{%k7}        # 5d0f68 <.LCPI3_32>
 1f7fbbe:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7fbc4:	vpor   %xmm5,%xmm4,%xmm6
 1f7fbc8:	vpsrld $0xb,%zmm23,%zmm7
 1f7fbcf:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7fbd5:	vpandd -0x19aec57(%rip){1to4},%xmm24,%xmm4        # 5d0f88 <.LCPI3_83>
 1f7fbdf:	vptestmd -0x19aec7d(%rip){1to16},%zmm23,%k1        # 5d0f6c <.LCPI3_33>
 1f7fbe9:	vpmovdb %zmm7,%xmm7
 1f7fbef:	vpand  %xmm7,%xmm8,%xmm7
 1f7fbf3:	vpmovdb %zmm21,%xmm8
 1f7fbf9:	vpor   %xmm4,%xmm15,%xmm5
 1f7fbfd:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7fc03:	vpmovdb %zmm23,%xmm5
 1f7fc09:	vgf2p8affineqb $0x0,-0x19b16bc(%rip){1to2},%xmm5,%xmm5        # 5ce558 <.LCPI3_84>
 1f7fc14:	vpternlogq $0xf8,%xmm11,%xmm5,%xmm4
 1f7fc1b:	vpsrld $0x8,%zmm21,%zmm11
 1f7fc22:	vpor   %xmm4,%xmm14,%xmm5
 1f7fc26:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7fc2c:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7fc33:	vpsrld $0x10,%zmm21,%zmm6
 1f7fc3a:	vpmovdb %zmm11,%xmm7
 1f7fc40:	vinserti32x4 $0x3,%xmm18,%zmm22,%zmm5{%k6}{z}
 1f7fc47:	vpmovdb %zmm6,%xmm6
 1f7fc4d:	je     1f7fd45 <node_facts_window_run+0x28b5>
 1f7fc53:	vmovdqa64 -0x1ac945d(%rip),%zmm18        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7fc5d:	vptestmd %zmm9,%zmm9,%k1{%k2}
 1f7fc63:	add    %r9,%rbp
 1f7fc66:	vpxor  %xmm11,%xmm11,%xmm11
 1f7fc6b:	vpxor  %xmm12,%xmm12,%xmm12
 1f7fc70:	vpcmpneqd -0x19aed0b(%rip){1to16},%zmm9,%k0{%k1}        # 5d0f70 <.LCPI3_38>
 1f7fc7b:	vmovdqa %xmm6,%xmm9
 1f7fc7f:	vpternlogq $0xfe,%xmm8,%xmm3,%xmm9
 1f7fc86:	kmovq  %k1,%k2
 1f7fc8b:	kmovw  %k1,%eax
 1f7fc8f:	popcnt %eax,%ecx
 1f7fc93:	vpgatherdd 0x10(%rbp,%zmm18,1),%zmm11{%k2}
 1f7fc9b:	kmovq  %k1,%k2
 1f7fca0:	vpcmpnleud -0x19aed37(%rip){1to16},%zmm11,%k3        # 5d0f74 <.LCPI3_39>
 1f7fcab:	vpgatherdd 0x14(%rbp,%zmm18,1),%zmm12{%k2}
 1f7fcb3:	add    %rcx,0x110(%rsp)
 1f7fcbb:	mov    0x10(%rsp),%r10
 1f7fcc0:	vpcmpeqd %zmm10,%zmm11,%k2
 1f7fcc6:	vmovdqa64 %xmm19,%xmm10
 1f7fccc:	vpternlogq $0xfe,%xmm7,%xmm9,%xmm10
 1f7fcd3:	vptestnmd %zmm12,%zmm12,%k2{%k2}
 1f7fcd9:	vptestmd %zmm12,%zmm12,%k4
 1f7fcdf:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm10
 1f7fce6:	korw   %k4,%k3,%k3
 1f7fcea:	kandw  %k2,%k0,%k2
 1f7fcee:	knotw  %k0,%k0
 1f7fcf2:	kandd  %k1,%k0,%k0
 1f7fcf7:	kandw  %k0,%k3,%k0
 1f7fcfb:	korw   %k0,%k2,%k2
 1f7fcff:	vptestnmd %zmm13,%zmm20,%k0{%k2}
 1f7fd05:	kandw  %k0,%k1,%k0
 1f7fd09:	knotd  %k6,%k1
 1f7fd0e:	kmovd  %k0,%ecx
 1f7fd12:	vptestmb %xmm10,%xmm10,%k0{%k1}
 1f7fd18:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7fd1e:	andn   %eax,%ecx,%eax
 1f7fd23:	popcnt %eax,%eax
 1f7fd27:	kmovw  %k0,%ecx
 1f7fd2b:	popcnt %ecx,%ecx
 1f7fd2f:	kmovw  %k1,%edx
 1f7fd33:	popcnt %edx,%edx
 1f7fd37:	add    %rdx,%r10
 1f7fd3a:	add    %rax,%r10
 1f7fd3d:	add    %rcx,%r10
 1f7fd40:	mov    %r10,0x10(%rsp)
 1f7fd45:	mov    0x28(%rsp),%r13
 1f7fd4a:	jmp    1f7f477 <node_facts_window_run+0x1fe7>
 1f7fd4f:	kandw  %k0,%k7,%k0
 1f7fd53:	vmovdqa %xmm10,0x270(%rsp)
 1f7fd5c:	vmovdqu64 %zmm11,0x370(%rsp)
 1f7fd67:	vmovdqu64 %ymm19,0x2b0(%rsp)
 1f7fd72:	vmovdqu64 %zmm20,0x530(%rsp)
 1f7fd7d:	vmovdqu64 %ymm21,0x430(%rsp)
 1f7fd88:	vmovdqu64 %zmm7,0x4f0(%rsp)
 1f7fd93:	vmovdqu64 %ymm18,0x3f0(%rsp)
 1f7fd9e:	vmovdqu64 %zmm22,0x570(%rsp)
 1f7fda9:	vmovdqu64 %ymm23,0x650(%rsp)
 1f7fdb4:	vmovdqu64 %zmm5,0x610(%rsp)
 1f7fdbf:	vmovdqu %ymm6,0x4b0(%rsp)
 1f7fdc8:	vmovdqu64 %zmm24,0x5d0(%rsp)
 1f7fdd3:	vmovdqu64 %ymm25,0x6c0(%rsp)
 1f7fddb:	vmovdqu64 %zmm4,0x780(%rsp)
 1f7fde3:	vmovdqu64 %ymm26,0x490(%rsp)
 1f7fdee:	vmovdqu64 %zmm27,0x740(%rsp)
 1f7fdf6:	vmovdqu64 %ymm28,0x470(%rsp)
 1f7fe01:	vmovdqu64 %zmm0,0x820(%rsp)
 1f7fe0c:	kmovd  %k6,0x2f0(%rsp)
 1f7fe16:	kmovw  %k7,0x3b0(%rsp)
 1f7fe1f:	kmovd  %k0,%eax
 1f7fe23:	movzwl %ax,%eax
 1f7fe26:	jmp    1f7ffd5 <node_facts_window_run+0x2b45>
 1f7fe2b:	mov    0x40(%rsp),%rsi
 1f7fe30:	mov    (%r12,%r13,4),%r9d
 1f7fe34:	mov    0xca8(%rdi),%rdx
 1f7fe3b:	shl    $0x6,%rax
 1f7fe3f:	mov    %r8b,0x1f0(%rsp)
 1f7fe47:	mov    0x20(%r11),%rcx
 1f7fe4b:	cmpb   $0x1,(%rdx,%r9,1)
 1f7fe50:	mov    %r9,0x230(%rsp)
 1f7fe58:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7fe5d:	adc    $0x0,%rsi
 1f7fe61:	and    $0x1,%edx
 1f7fe64:	mov    %rsi,0x40(%rsp)
 1f7fe69:	mov    0x98(%rsp),%rbx
 1f7fe71:	mov    (%rbx,%r13,4),%esi
 1f7fe75:	vzeroupper
 1f7fe78:	call   1f939b0 <node_tests_window_line>
 1f7fe7d:	mov    %al,0x1b0(%rsp)
 1f7fe84:	mov    (%rbx,%r13,4),%esi
 1f7fe88:	mov    0x18(%rsp),%rdi
 1f7fe8d:	call   1f93b00 <node_tests_window_returns>
 1f7fe92:	mov    0x18(%rsp),%rdi
 1f7fe97:	or     0x1f0(%rsp),%al
 1f7fe9e:	mov    0x230(%rsp),%rdx
 1f7fea6:	vpbroadcastd -0x19aef7c(%rip),%zmm13        # 5d0f34 <.LCPI3_5>
 1f7feb0:	vpbroadcastb -0x1ac9179(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7feb9:	vpbroadcastb -0x1ac9181(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7fec2:	vpbroadcastd -0x19aef90(%rip),%zmm16        # 5d0f3c <.LCPI3_11>
 1f7fecc:	vpbroadcastd -0x19aef92(%rip),%zmm17        # 5d0f44 <.LCPI3_13>
 1f7fed6:	vmovdqa 0x270(%rsp),%xmm10
 1f7fedf:	vmovdqu64 0x370(%rsp),%zmm11
 1f7feea:	vmovdqu64 0x2b0(%rsp),%ymm19
 1f7fef5:	vmovdqu64 0x530(%rsp),%zmm20
 1f7ff00:	vmovdqu64 0x430(%rsp),%ymm21
 1f7ff0b:	vmovdqu64 0x4f0(%rsp),%zmm7
 1f7ff16:	vmovdqu64 0x3f0(%rsp),%ymm18
 1f7ff21:	vmovdqu64 0x570(%rsp),%zmm22
 1f7ff2c:	vmovdqu64 0x650(%rsp),%ymm23
 1f7ff37:	vmovdqu64 0x610(%rsp),%zmm5
 1f7ff42:	vmovdqu 0x4b0(%rsp),%ymm6
 1f7ff4b:	vmovdqu64 0x5d0(%rsp),%zmm24
 1f7ff56:	vmovdqu64 0x6c0(%rsp),%ymm25
 1f7ff5e:	vmovdqu64 0x780(%rsp),%zmm4
 1f7ff66:	vmovdqu64 0x490(%rsp),%ymm26
 1f7ff71:	vmovdqu64 0x740(%rsp),%zmm27
 1f7ff79:	vmovdqu64 0x470(%rsp),%ymm28
 1f7ff84:	vmovdqu64 0x820(%rsp),%zmm0
 1f7ff8f:	mov    0x8(%rsp),%r11
 1f7ff94:	mov    0x38(%rsp),%rsi
 1f7ff99:	mov    0x150(%rsp),%r8
 1f7ffa1:	mov    0x20(%rsp),%r9
 1f7ffa6:	kmovd  0x2f0(%rsp),%k6
 1f7ffb0:	kmovw  0x3b0(%rsp),%k7
 1f7ffb9:	or     0x1b0(%rsp),%al
 1f7ffc0:	mov    0xca8(%rdi),%rcx
 1f7ffc7:	mov    %al,(%rcx,%rdx,1)
 1f7ffca:	mov    0x50(%rsp),%eax
 1f7ffce:	blsr   %eax,%eax
 1f7ffd3:	je     1f80045 <node_facts_window_run+0x2bb5>
 1f7ffd5:	tzcnt  %eax,%r13d
 1f7ffda:	mov    %eax,0x50(%rsp)
 1f7ffde:	mov    0x60(%r11),%edx
 1f7ffe2:	mov    $0x1,%r8b
 1f7ffe5:	add    %r15,%r13
 1f7ffe8:	mov    %r13,%rcx
 1f7ffeb:	shl    $0x6,%rcx
 1f7ffef:	mov    (%r9,%rcx,1),%eax
 1f7fff3:	mov    0xc(%r9,%rcx,1),%ecx
 1f7fff8:	shr    $0x3,%eax
 1f7fffb:	cmp    %edx,%eax
 1f7fffd:	cmovae %edx,%eax
 1f80000:	test   %rcx,%rcx
 1f80003:	je     1f7fe2b <node_facts_window_run+0x299b>
 1f80009:	mov    0x90(%rsp),%rdx
 1f80011:	mov    0x40(%rsp),%rsi
 1f80016:	cmp    0x3b8(%rdx),%ecx
 1f8001c:	jae    1f7fe30 <node_facts_window_run+0x29a0>
 1f80022:	mov    0x90(%rsp),%rdx
 1f8002a:	mov    0x3a8(%rdx),%rdx
 1f80031:	cmpl   $0x0,(%rdx,%rcx,4)
 1f80035:	setne  %r8b
 1f80039:	shl    $0x5,%r8b
 1f8003d:	inc    %r8b
 1f80040:	jmp    1f7fe30 <node_facts_window_run+0x29a0>
 1f80045:	mov    0xca8(%rdi),%rax
 1f8004c:	kmovq  %k7,%k1
 1f80051:	vpxor  %xmm12,%xmm12,%xmm12
 1f80056:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f8005d:	jmp    1f7f622 <node_facts_window_run+0x2192>
 1f80062:	test   %eax,%eax
 1f80064:	je     1f808b7 <node_facts_window_run+0x3427>
 1f8006a:	vpbroadcastd -0x19af140(%rip),%zmm6        # 5d0f34 <.LCPI3_5>
 1f80074:	vpbroadcastb -0x1ac933b(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f8007d:	vpbroadcastd -0x19af14b(%rip),%zmm8        # 5d0f3c <.LCPI3_11>
 1f80087:	vpbroadcastd -0x19af14d(%rip),%zmm9        # 5d0f44 <.LCPI3_13>
 1f80091:	lea    0x69454(%r13),%rcx
 1f80098:	lea    0x422c(%r13),%r14
 1f8009f:	mov    %eax,%r10d
 1f800a2:	xor    %r15d,%r15d
 1f800a5:	mov    %rcx,0x530(%rsp)
 1f800ad:	movq   $0x0,0x40(%rsp)
 1f800b6:	movq   $0x0,0x110(%rsp)
 1f800c2:	movq   $0x0,0x10(%rsp)
 1f800cb:	mov    %r10,0x430(%rsp)
 1f800d3:	mov    %r14,0x4f0(%rsp)
 1f800db:	jmp    1f8010c <node_facts_window_run+0x2c7c>
 1f800dd:	nopl   (%rax)
 1f800e0:	vpxor  %xmm11,%xmm11,%xmm11
 1f800e5:	mov    0xc70(%rdi),%rax
 1f800ec:	vmovdqu %xmm11,(%rax,%r15,1)
 1f800f2:	mov    0xc78(%rdi),%rax
 1f800f9:	vmovdqu %xmm0,(%rax,%r15,1)
 1f800ff:	add    $0x10,%r15
 1f80103:	cmp    %r10,%r15
 1f80106:	jae    1f808d5 <node_facts_window_run+0x3445>
 1f8010c:	vpxor  %xmm0,%xmm0,%xmm0
 1f80110:	cmp    %r8,%r15
 1f80113:	jae    1f800e0 <node_facts_window_run+0x2c50>
 1f80115:	mov    %r8d,%eax
 1f80118:	sub    %r15d,%eax
 1f8011b:	mov    $0x10,%ecx
 1f80120:	mov    $0xffffffff,%edx
 1f80125:	mov    %r15,%rbp
 1f80128:	cmp    $0x10,%eax
 1f8012b:	cmovae %ecx,%eax
 1f8012e:	mov    0x9b8(%r11),%rcx
 1f80135:	shl    $0x6,%rbp
 1f80139:	shlx   %eax,%edx,%eax
 1f8013e:	vmovdqu 0x100(%r9,%rbp,1),%ymm2
 1f80148:	vmovdqu 0x180(%r9,%rbp,1),%ymm3
 1f80152:	vmovdqu (%r9,%rbp,1),%ymm0
 1f80158:	vmovdqu 0x80(%r9,%rbp,1),%ymm1
 1f80162:	not    %eax
 1f80164:	vinserti64x4 $0x1,0x140(%r9,%rbp,1),%zmm2,%zmm5
 1f8016d:	vinserti64x4 $0x1,0x1c0(%r9,%rbp,1),%zmm3,%zmm2
 1f80176:	vinserti64x4 $0x1,0x40(%r9,%rbp,1),%zmm0,%zmm4
 1f8017f:	vmovdqu 0x200(%r9,%rbp,1),%ymm0
 1f80189:	vinserti64x4 $0x1,0xc0(%r9,%rbp,1),%zmm1,%zmm12
 1f80192:	kmovd  %eax,%k1
 1f80196:	vinserti64x4 $0x1,0x240(%r9,%rbp,1),%zmm0,%zmm11
 1f8019f:	vmovdqu 0x280(%r9,%rbp,1),%ymm0
 1f801a9:	mov    0xca8(%rdi),%rax
 1f801b0:	vinserti64x4 $0x1,0x2c0(%r9,%rbp,1),%zmm0,%zmm14
 1f801b9:	vmovdqu 0x300(%r9,%rbp,1),%ymm0
 1f801c3:	vmovdqu8 (%rcx,%r15,1),%xmm10{%k1}{z}
 1f801ca:	mov    0x530(%rsp),%rcx
 1f801d2:	vinserti64x4 $0x1,0x340(%r9,%rbp,1),%zmm0,%zmm13
 1f801db:	vmovdqu 0x380(%r9,%rbp,1),%ymm0
 1f801e5:	vinserti64x4 $0x1,0x3c0(%r9,%rbp,1),%zmm0,%zmm15
 1f801ee:	vmovdqu8 (%rcx,%r15,1),%xmm3{%k1}{z}
 1f801f5:	vptestmb %xmm10,%xmm10,%k2
 1f801fb:	vpxor  %xmm0,%xmm0,%xmm0
 1f801ff:	vpcmpeqb %xmm7,%xmm3,%k3{%k2}
 1f80205:	vmovdqu32 (%r12,%r15,4),%zmm1{%k3}{z}
 1f8020c:	kmovq  %k3,%k1
 1f80211:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f80218:	vptestnmd %zmm8,%zmm0,%k0
 1f8021e:	ktestw %k0,%k3
 1f80222:	jne    1f806c7 <node_facts_window_run+0x3237>
 1f80228:	vmovdqa64 -0x1ac9af2(%rip),%zmm1        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f80232:	kmovd  %k2,%edx
 1f80236:	vpermt2d %zmm12,%zmm1,%zmm4
 1f8023c:	vpermt2d %zmm2,%zmm1,%zmm5
 1f80242:	vpermt2d %zmm14,%zmm1,%zmm11
 1f80248:	vpermt2d %zmm15,%zmm1,%zmm13
 1f8024e:	vshufi64x2 $0x44,%zmm13,%zmm11,%zmm2
 1f80255:	vshufi64x2 $0x44,%zmm5,%zmm4,%zmm1
 1f8025c:	vshufi64x2 $0xee,%zmm5,%zmm4,%zmm14
 1f80263:	vshufi64x2 $0xee,%zmm13,%zmm11,%zmm13
 1f8026a:	vshufi32x4 $0x88,%zmm2,%zmm1,%zmm4{%k2}{z}
 1f80271:	vshufi32x4 $0xdd,%zmm2,%zmm1,%zmm5{%k2}{z}
 1f80278:	vshufi32x4 $0xdd,%zmm13,%zmm14,%zmm12{%k2}{z}
 1f8027f:	vpsrld $0x19,%zmm4,%zmm1
 1f80286:	vpandd -0x19af360(%rip){1to16},%zmm1,%zmm1        # 5d0f30 <.LCPI3_4>
 1f80290:	vpsrld $0x18,%zmm4,%zmm2
 1f80297:	vpternlogd $0xec,%zmm6,%zmm1,%zmm2
 1f8029e:	vpandd -0x19af32c(%rip){1to16},%zmm4,%zmm1        # 5d0f7c <.LCPI3_75>
 1f802a8:	vpmovdb %zmm2,%xmm11
 1f802ae:	vpbroadcastb -0x1ac9577(%rip),%xmm2        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f802b7:	vpcmpeqd -0x19af389(%rip){1to16},%zmm1,%k1{%k2}        # 5d0f38 <.LCPI3_7>
 1f802c1:	vpor   %xmm2,%xmm11,%xmm1
 1f802c5:	vpcmpeqb %xmm2,%xmm3,%k0{%k2}
 1f802cb:	kmovd  %k0,%eax
 1f802cf:	vmovdqu8 %xmm1,%xmm11{%k1}
 1f802d5:	vptestmd %zmm9,%zmm0,%k1
 1f802db:	korw   %k1,%k0,%k5
 1f802df:	vptestmd -0x19af3a9(%rip){1to16},%zmm0,%k0        # 5d0f40 <.LCPI3_12>
 1f802e9:	kmovd  %k0,%r13d
 1f802ed:	test   %ax,%ax
 1f802f0:	je     1f8043f <node_facts_window_run+0x2faf>
 1f802f6:	lea    (%r14,%r15,4),%r14
 1f802fa:	movzwl %r13w,%r13d
 1f802fe:	movzwl %ax,%ebx
 1f80301:	vmovdqu64 %zmm13,0x2b0(%rsp)
 1f8030c:	vmovdqu64 %zmm14,0x370(%rsp)
 1f80317:	vmovdqu64 %zmm5,0x3b0(%rsp)
 1f80322:	vmovdqu64 %zmm4,0x2f0(%rsp)
 1f8032d:	kmovw  %k5,0x270(%rsp)
 1f80336:	vmovdqu64 %zmm12,0x1f0(%rsp)
 1f80341:	mov    %edx,0x1b0(%rsp)
 1f80348:	vmovdqa %xmm11,0x230(%rsp)
 1f80351:	vmovdqa %xmm10,0x50(%rsp)
 1f80357:	nopw   0x0(%rax,%rax,1)
 1f80360:	xor    %r12d,%r12d
 1f80363:	tzcnt  %ebx,%r12d
 1f80368:	xor    %edx,%edx
 1f8036a:	mov    (%r14,%r12,4),%esi
 1f8036e:	vzeroupper
 1f80371:	call   1f939b0 <node_tests_window_line>
 1f80376:	mov    0x18(%rsp),%rdi
 1f8037b:	mov    $0x1,%edx
 1f80380:	xor    %ecx,%ecx
 1f80382:	test   $0x2,%al
 1f80384:	shlx   %r12d,%edx,%eax
 1f80389:	cmove  %ecx,%eax
 1f8038c:	or     %eax,%r13d
 1f8038f:	blsr   %ebx,%ebx
 1f80394:	jne    1f80360 <node_facts_window_run+0x2ed0>
 1f80396:	vpbroadcastd -0x19af46c(%rip),%zmm6        # 5d0f34 <.LCPI3_5>
 1f803a0:	vpbroadcastb -0x1ac9667(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f803a9:	vpbroadcastd -0x19af477(%rip),%zmm8        # 5d0f3c <.LCPI3_11>
 1f803b3:	vpbroadcastd -0x19af479(%rip),%zmm9        # 5d0f44 <.LCPI3_13>
 1f803bd:	vmovdqa 0x50(%rsp),%xmm10
 1f803c3:	vmovdqa 0x230(%rsp),%xmm11
 1f803cc:	vmovdqu64 0x1f0(%rsp),%zmm12
 1f803d7:	vmovdqu64 0x2f0(%rsp),%zmm4
 1f803e2:	vmovdqu64 0x3b0(%rsp),%zmm5
 1f803ed:	vmovdqu64 0x370(%rsp),%zmm14
 1f803f8:	vmovdqu64 0x2b0(%rsp),%zmm13
 1f80403:	mov    0x8(%rsp),%r11
 1f80408:	mov    0x38(%rsp),%rsi
 1f8040d:	mov    0x30(%rsp),%r12
 1f80412:	mov    0x150(%rsp),%r8
 1f8041a:	mov    0x20(%rsp),%r9
 1f8041f:	mov    0x4f0(%rsp),%r14
 1f80427:	mov    0x430(%rsp),%r10
 1f8042f:	mov    0x1b0(%rsp),%edx
 1f80436:	kmovw  0x270(%rsp),%k5
 1f8043f:	vpsrld $0x2,%zmm12,%zmm2
 1f80446:	vpandd -0x19af508(%rip){1to16},%zmm2,%zmm2        # 5d0f48 <.LCPI3_14>
 1f80450:	vptestmd -0x19af50a(%rip){1to16},%zmm12,%k2        # 5d0f50 <.LCPI3_16>
 1f8045a:	vshufi64x2 $0x88,%zmm13,%zmm14,%zmm0
 1f80461:	vptestnmb %xmm10,%xmm10,%k0
 1f80467:	vpsrld $0x1a,%zmm4,%zmm1
 1f8046e:	vpandd -0x19af4f8(%rip){1to16},%zmm4,%zmm4        # 5d0f80 <.LCPI3_78>
 1f80478:	kmovd  %r13d,%k3
 1f8047d:	vpcmpneqd -0x19af53c(%rip){1to16},%zmm2,%k1        # 5d0f4c <.LCPI3_15>
 1f80488:	vpaddd -0x19af53a(%rip){1to16},%zmm4,%zmm4        # 5d0f58 <.LCPI3_20>
 1f80492:	korw   %k1,%k2,%k1
 1f80496:	vptestnmd %zmm0,%zmm0,%k2
 1f8049c:	vpandd %zmm9,%zmm5,%zmm0
 1f804a2:	korw   %k2,%k0,%k0
 1f804a6:	vptestmd -0x19af55c(%rip){1to16},%zmm5,%k2        # 5d0f54 <.LCPI3_17>
 1f804b0:	vpbroadcastd -0x19af55e(%rip),%zmm5        # 5d0f5c <.LCPI3_21>
 1f804ba:	korw   %k1,%k0,%k1
 1f804be:	vptestnmd %zmm0,%zmm0,%k0
 1f804c4:	kmovd  %k0,%eax
 1f804c8:	vptestmd %zmm2,%zmm2,%k1{%k1}
 1f804ce:	vmovdqu8 -0x19b87e8(%rip),%xmm3{%k1}{z}        # 5c7cf0 <.LCPI3_8>
 1f804d8:	vpcmpeqd %zmm5,%zmm1,%k4
 1f804de:	vpcmpltud %zmm5,%zmm4,%k0
 1f804e5:	korw   %k2,%k3,%k1
 1f804e9:	vpslld $0x1f,%zmm4,%zmm1
 1f804f0:	vpbroadcastb -0x1ac97b4(%rip),%xmm4        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f804f9:	vptestmb %xmm10,%xmm10,%k4{%k4}
 1f804ff:	kmovd  %k0,%ecx
 1f80503:	and    %eax,%ecx
 1f80505:	mov    %edx,%eax
 1f80507:	and    %ecx,%eax
 1f80509:	vmovdqu8 -0x19b87e3(%rip),%xmm5{%k4}{z}        # 5c7d30 <.LCPI3_24>
 1f80513:	kmovd  %eax,%k3
 1f80517:	vpcmpeqd %zmm8,%zmm2,%k2{%k3}
 1f8051d:	vpxor  %xmm2,%xmm2,%xmm2
 1f80521:	knotw  %k2,%k0
 1f80525:	kmovd  %k0,%ecx
 1f80529:	and    %eax,%ecx
 1f8052b:	vmovdqu8 -0x19b87f5(%rip),%xmm5{%k3}        # 5c7d40 <.LCPI3_25>
 1f80535:	kmovd  %ecx,%k3
 1f80539:	vpcmpgtd %zmm1,%zmm2,%k3{%k3}
 1f8053f:	vpsrld $0x10,%zmm12,%zmm1
 1f80546:	vpternlogd $0xff,%zmm2,%zmm2,%zmm2
 1f8054d:	vpaddd %zmm2,%zmm1,%zmm2
 1f80553:	vmovdqu8 -0x19b880d(%rip),%xmm5{%k3}        # 5c7d50 <.LCPI3_26>
 1f8055d:	vptestnmd %zmm2,%zmm2,%k3
 1f80563:	vpblendmb -0x19b87fd(%rip),%xmm4,%xmm4{%k3}        # 5c7d70 <.LCPI3_28>
 1f8056d:	vpcmpnleud -0x19af618(%rip){1to16},%zmm2,%k3        # 5d0f60 <.LCPI3_22>
 1f80578:	cmpb   $0x0,0xcf0(%rdi)
 1f8057f:	vmovdqu8 -0x19b8809(%rip),%xmm4{%k3}        # 5c7d80 <.LCPI3_29>
 1f80589:	vpcmpnleud -0x19af630(%rip){1to16},%zmm2,%k3        # 5d0f64 <.LCPI3_23>
 1f80594:	vmovdqu8 -0x19b880e(%rip),%xmm4{%k3}        # 5c7d90 <.LCPI3_30>
 1f8059e:	vptestmd %zmm0,%zmm0,%k3
 1f805a4:	vpor   %xmm7,%xmm3,%xmm0
 1f805a8:	vmovdqu8 %xmm0,%xmm3{%k3}
 1f805ae:	vmovdqu8 %xmm4,%xmm5{%k2}
 1f805b4:	vpor   %xmm5,%xmm3,%xmm0
 1f805b8:	vpord  -0x19af63e(%rip){1to4},%xmm0,%xmm3        # 5d0f84 <.LCPI3_81>
 1f805c2:	vmovdqu8 %xmm3,%xmm0{%k5}
 1f805c8:	vpord  -0x19af646(%rip){1to4},%xmm0,%xmm3        # 5d0f8c <.LCPI3_85>
 1f805d2:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f805d8:	vpsrld $0xc,%zmm12,%zmm3
 1f805df:	vpmovdb %zmm3,%xmm3
 1f805e5:	vpternlogd $0xf8,-0x19af660(%rip){1to4},%xmm3,%xmm11        # 5d0f90 <.LCPI3_86>
 1f805f0:	je     1f806bd <node_facts_window_run+0x322d>
 1f805f6:	vmovdqa64 -0x1ac9e00(%rip),%zmm5        # 4b6800 <abi_test_hex.digits+0xb480>
 1f80600:	vptestmd %zmm1,%zmm1,%k1{%k2}
 1f80606:	add    %r9,%rbp
 1f80609:	vpxor  %xmm3,%xmm3,%xmm3
 1f8060d:	vpxor  %xmm4,%xmm4,%xmm4
 1f80611:	vpcmpneqd -0x19af6ac(%rip){1to16},%zmm1,%k0{%k1}        # 5d0f70 <.LCPI3_38>
 1f8061c:	vpor   %xmm0,%xmm11,%xmm1
 1f80620:	kmovq  %k1,%k2
 1f80625:	kmovw  %k1,%eax
 1f80629:	popcnt %eax,%ecx
 1f8062d:	vpgatherdd 0x10(%rbp,%zmm5,1),%zmm3{%k2}
 1f80635:	kmovq  %k1,%k2
 1f8063a:	vpcmpnleud -0x19af6d1(%rip){1to16},%zmm3,%k3        # 5d0f74 <.LCPI3_39>
 1f80645:	vpgatherdd 0x14(%rbp,%zmm5,1),%zmm4{%k2}
 1f8064d:	add    %rcx,0x110(%rsp)
 1f80655:	mov    0x10(%rsp),%rbx
 1f8065a:	vpcmpeqd %zmm2,%zmm3,%k2
 1f80660:	vptestnmd %zmm4,%zmm4,%k2{%k2}
 1f80666:	vptestmd %zmm4,%zmm4,%k4
 1f8066c:	korw   %k4,%k3,%k3
 1f80670:	kandw  %k2,%k0,%k2
 1f80674:	knotw  %k0,%k0
 1f80678:	kandd  %k1,%k0,%k0
 1f8067d:	kandw  %k0,%k3,%k0
 1f80681:	korw   %k0,%k2,%k2
 1f80685:	vptestnmd %zmm6,%zmm12,%k0{%k2}
 1f8068b:	kandw  %k0,%k1,%k0
 1f8068f:	kmovd  %k0,%ecx
 1f80693:	vptestmb %xmm1,%xmm1,%k0
 1f80699:	andn   %eax,%ecx,%eax
 1f8069e:	kmovd  %k0,%ecx
 1f806a2:	andn   %ecx,%edx,%ecx
 1f806a7:	popcnt %eax,%eax
 1f806ab:	movzwl %cx,%ecx
 1f806ae:	add    %rax,%rbx
 1f806b1:	popcnt %ecx,%ecx
 1f806b5:	add    %rcx,%rbx
 1f806b8:	mov    %rbx,0x10(%rsp)
 1f806bd:	mov    0x28(%rsp),%r13
 1f806c2:	jmp    1f800e5 <node_facts_window_run+0x2c55>
 1f806c7:	vmovdqu64 %zmm1,0x4b0(%rsp)
 1f806d2:	vmovdqu64 %zmm15,0x650(%rsp)
 1f806dd:	vmovdqu64 %zmm14,0x570(%rsp)
 1f806e8:	vmovdqu64 %zmm13,0x3f0(%rsp)
 1f806f3:	vmovdqu64 %zmm2,0x2b0(%rsp)
 1f806fe:	vmovdqu64 %zmm12,0x370(%rsp)
 1f80709:	vmovdqu64 %zmm11,0x3b0(%rsp)
 1f80714:	vmovdqa %xmm3,0x2f0(%rsp)
 1f8071d:	vmovdqu64 %zmm5,0x270(%rsp)
 1f80728:	kmovw  %k2,0x1f0(%rsp)
 1f80731:	vmovdqu64 %zmm4,0x1b0(%rsp)
 1f8073c:	vmovdqa %xmm10,0x50(%rsp)
 1f80742:	kmovw  %k3,0x610(%rsp)
 1f8074b:	kandw  %k0,%k3,%k0
 1f8074f:	mov    0x40(%rsp),%rbx
 1f80754:	kmovd  %k0,%eax
 1f80758:	movzwl %ax,%r13d
 1f8075c:	xor    %eax,%eax
 1f8075e:	tzcnt  %r13d,%eax
 1f80763:	mov    0x60(%r11),%edx
 1f80767:	mov    0x20(%r11),%rcx
 1f8076b:	add    %r15,%rax
 1f8076e:	mov    (%r12,%rax,4),%r8d
 1f80772:	mov    (%r14,%rax,4),%esi
 1f80776:	shl    $0x6,%rax
 1f8077a:	mov    (%r9,%rax,1),%eax
 1f8077e:	mov    %r8,0x230(%rsp)
 1f80786:	shr    $0x3,%eax
 1f80789:	cmp    %edx,%eax
 1f8078b:	cmovae %edx,%eax
 1f8078e:	shl    $0x6,%rax
 1f80792:	mov    0x30(%rcx,%rax,1),%edx
 1f80796:	mov    0xca8(%rdi),%rax
 1f8079d:	cmpb   $0x1,(%rax,%r8,1)
 1f807a2:	adc    $0x0,%rbx
 1f807a6:	and    $0x1,%edx
 1f807a9:	vzeroupper
 1f807ac:	call   1f939b0 <node_tests_window_line>
 1f807b1:	mov    0x18(%rsp),%rdi
 1f807b6:	mov    0x20(%rsp),%r9
 1f807bb:	mov    0x8(%rsp),%r11
 1f807c0:	mov    0x230(%rsp),%rdx
 1f807c8:	or     $0x1,%al
 1f807ca:	blsr   %r13d,%r13d
 1f807cf:	mov    0xca8(%rdi),%rcx
 1f807d6:	mov    %al,(%rcx,%rdx,1)
 1f807d9:	jne    1f8075c <node_facts_window_run+0x32cc>
 1f807db:	mov    %rbx,0x40(%rsp)
 1f807e0:	mov    0xca8(%rdi),%rax
 1f807e7:	vpbroadcastd -0x19af8bd(%rip),%zmm6        # 5d0f34 <.LCPI3_5>
 1f807f1:	vpbroadcastb -0x1ac9ab8(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f807fa:	vpbroadcastd -0x19af8c8(%rip),%zmm8        # 5d0f3c <.LCPI3_11>
 1f80804:	vpbroadcastd -0x19af8ca(%rip),%zmm9        # 5d0f44 <.LCPI3_13>
 1f8080e:	vpxor  %xmm0,%xmm0,%xmm0
 1f80812:	vmovdqu64 0x4b0(%rsp),%zmm1
 1f8081d:	kmovw  0x610(%rsp),%k1
 1f80826:	vmovdqa 0x50(%rsp),%xmm10
 1f8082c:	vmovdqu64 0x1b0(%rsp),%zmm4
 1f80837:	vmovdqu64 0x270(%rsp),%zmm5
 1f80842:	vmovdqa 0x2f0(%rsp),%xmm3
 1f8084b:	vmovdqu64 0x3b0(%rsp),%zmm11
 1f80856:	vmovdqu64 0x370(%rsp),%zmm12
 1f80861:	vmovdqu64 0x2b0(%rsp),%zmm2
 1f8086c:	vmovdqu64 0x3f0(%rsp),%zmm13
 1f80877:	vmovdqu64 0x570(%rsp),%zmm14
 1f80882:	vmovdqu64 0x650(%rsp),%zmm15
 1f8088d:	mov    0x38(%rsp),%rsi
 1f80892:	mov    0x150(%rsp),%r8
 1f8089a:	mov    0x430(%rsp),%r10
 1f808a2:	kmovw  0x1f0(%rsp),%k2
 1f808ab:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f808b2:	jmp    1f80228 <node_facts_window_run+0x2d98>
 1f808b7:	movq   $0x0,0x40(%rsp)
 1f808c0:	movq   $0x0,0x110(%rsp)
 1f808cc:	movq   $0x0,0x10(%rsp)
 1f808d5:	mov    0x40(%rsp),%rax
 1f808da:	mov    0x110(%rsp),%rcx
 1f808e2:	add    %rax,0xa90(%rsi)
 1f808e9:	mov    0xc30(%rdi),%rax
 1f808f0:	add    %rcx,0x868(%rax)
 1f808f7:	mov    0x10(%rsp),%rcx
 1f808fc:	mov    0xc30(%rdi),%rax
 1f80903:	add    %rcx,0x870(%rax)
 1f8090a:	rdtsc
 1f8090c:	mov    0x8(%r13),%esi
 1f80910:	cmpq   $0x0,0xc20(%r11)
 1f80918:	mov    %rsi,0x20(%rsp)
 1f8091d:	mov    %rax,0x780(%rsp)
 1f80925:	mov    %rdx,0x490(%rsp)
 1f8092d:	je     1f81109 <node_facts_window_run+0x3c79>
 1f80933:	cmpb   $0x1,0xd58(%r11)
 1f8093b:	jne    1f81109 <node_facts_window_run+0x3c79>
 1f80941:	mov    0xc30(%rdi),%rcx
 1f80948:	cmpq   $0x0,0x1a0(%rcx)
 1f80950:	sete   %cl
 1f80953:	test   %rsi,%rsi
 1f80956:	je     1f817df <node_facts_window_run+0x434f>
 1f8095c:	vpbroadcastb %ecx,%zmm1
 1f80962:	vgf2p8affineqb $0x0,-0x19b240d(%rip){1to8},%zmm1,%zmm1        # 5ce560 <.LCPI3_87>
 1f8096d:	vmovdqu64 0x3c0(%rdi),%zmm0
 1f80974:	vbroadcasti32x4 -0x19b8b6e(%rip),%zmm2        # 5c7e10 <.LCPI3_88>
 1f8097e:	vpbroadcastq -0x19b2478(%rip),%zmm3        # 5ce510 <.LCPI3_42>
 1f80988:	vpbroadcastq -0x19b247a(%rip),%zmm4        # 5ce518 <.LCPI3_43>
 1f80992:	vmovdqa64 -0x1aca0dc(%rip),%zmm6        # 4b68c0 <abi_test_hex.digits+0xb540>
 1f8099c:	vbroadcasti32x4 -0x19b8b86(%rip),%zmm7        # 5c7e20 <.LCPI3_89>
 1f809a6:	vbroadcasti32x4 -0x19b8b80(%rip),%zmm16        # 5c7e30 <.LCPI3_90>
 1f809b0:	vbroadcasti32x4 -0x19b8b7a(%rip),%zmm17        # 5c7e40 <.LCPI3_91>
 1f809ba:	vbroadcasti32x4 -0x19b8ca4(%rip),%zmm21        # 5c7d20 <.LCPI3_18>
 1f809c4:	vbroadcasti32x4 -0x19b8b7e(%rip),%zmm24        # 5c7e50 <.LCPI3_92>
 1f809ce:	movzbl 0x600(%rdi),%r10d
 1f809d6:	mov    %r11,%rcx
 1f809d9:	mov    0xd78(%rcx),%rbx
 1f809e0:	mov    0xd60(%r11),%r11
 1f809e7:	xor    %r14d,%r14d
 1f809ea:	vpxord %xmm25,%xmm25,%xmm25
 1f809f0:	vpxor  %xmm9,%xmm9,%xmm9
 1f809f5:	vpxor  %xmm14,%xmm14,%xmm14
 1f809fa:	vpxor  %xmm8,%xmm8,%xmm8
 1f809ff:	mov    %rdi,%rax
 1f80a02:	xor    %r9d,%r9d
 1f80a05:	xor    %ecx,%ecx
 1f80a07:	xor    %edx,%edx
 1f80a09:	xor    %esi,%esi
 1f80a0b:	xor    %r8d,%r8d
 1f80a0e:	vpxord %xmm29,%xmm29,%xmm29
 1f80a14:	neg    %r10
 1f80a17:	vmovdqu64 %zmm0,0x150(%rsp)
 1f80a22:	movq   $0x0,0x30(%rsp)
 1f80a2b:	nopl   0x0(%rax,%rax,1)
 1f80a30:	mov    0xc70(%rax),%rdi
 1f80a37:	vmovdqu64 0x2c(%r13,%r14,1),%zmm11
 1f80a42:	vmovdqa64 %zmm9,%zmm20
 1f80a48:	vmovdqa64 0x140(%rax),%zmm9
 1f80a4f:	vmovdqa64 0x340(%rax),%zmm12
 1f80a56:	vmovdqa64 0xc0(%rax),%zmm15
 1f80a5d:	vmovdqa64 0x1c0(%rax),%zmm23
 1f80a64:	vmovdqa64 0x240(%rax),%zmm31
 1f80a6b:	vmovdqa64 0x2c0(%rax),%zmm22
 1f80a72:	vmovdqa64 0x480(%rax),%zmm0
 1f80a79:	vmovdqa64 0x500(%rax),%zmm10
 1f80a80:	vmovdqa64 %zmm29,%zmm5
 1f80a86:	vmovdqa64 %zmm25,%zmm29
 1f80a8c:	vmovdqa64 0x400(%rax),%zmm25
 1f80a93:	vmovdqu64 (%rdi,%r14,1),%zmm18
 1f80a9a:	mov    0xc78(%rax),%rdi
 1f80aa1:	vpermt2b 0x180(%rax),%zmm11,%zmm9
 1f80aa8:	vpandq %zmm2,%zmm11,%zmm13
 1f80aae:	vpermt2b 0x380(%rax),%zmm11,%zmm12
 1f80ab5:	vpermt2b 0x100(%rax),%zmm11,%zmm15
 1f80abc:	vpermt2b 0x200(%rax),%zmm11,%zmm23
 1f80ac3:	vpermt2b 0x280(%rax),%zmm11,%zmm31
 1f80aca:	vpermt2b 0x300(%rax),%zmm11,%zmm22
 1f80ad1:	vpermt2b 0x440(%rax),%zmm11,%zmm25
 1f80ad8:	vpermt2b 0x4c0(%rax),%zmm11,%zmm0
 1f80adf:	vpermt2b 0x540(%rax),%zmm11,%zmm10
 1f80ae6:	vmovdqu64 (%rdi,%r14,1),%zmm30
 1f80aed:	mov    0xc80(%rax),%rdi
 1f80af4:	vpsrlw $0x2,%zmm18,%zmm26
 1f80afb:	vpsrlw $0x3,%zmm18,%zmm11
 1f80b02:	vpternlogq $0xf8,%zmm3,%zmm30,%zmm9
 1f80b09:	vpternlogq $0xf8,%zmm4,%zmm26,%zmm9
 1f80b10:	vpternlogq $0xf8,-0x19b25fb(%rip){1to8},%zmm11,%zmm9        # 5ce520 <.LCPI3_44>
 1f80b1b:	vmovdqu64 %zmm9,(%rdi,%r14,1)
 1f80b22:	vmovdqu64 0x6b554(%r13,%r14,2),%zmm11
 1f80b2d:	vmovdqu64 0x6b594(%r13,%r14,2),%zmm19
 1f80b38:	vmovdqu64 0x6d614(%r13,%r14,2),%zmm27
 1f80b43:	vpmovuswb %zmm11,%ymm11
 1f80b49:	vpmovuswb %zmm19,%ymm19
 1f80b4f:	vpmovuswb %zmm27,%ymm27
 1f80b55:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm11
 1f80b5c:	vptestmb %zmm11,%zmm11,%k1
 1f80b62:	vpcmpnltub %zmm11,%zmm6,%k0
 1f80b69:	vpsubb %zmm11,%zmm6,%zmm19
 1f80b6f:	vpcmpltub %zmm11,%zmm6,%k3{%k1}
 1f80b76:	vmovdqu64 0x6d5d4(%r13,%r14,2),%zmm11
 1f80b81:	kmovq  %k1,%rdi
 1f80b86:	kmovq  %k0,%r12
 1f80b8b:	and    %rdi,%r12
 1f80b8e:	mov    0xc88(%rax),%rdi
 1f80b95:	kmovq  %r12,%k1
 1f80b9a:	vpermt2b %zmm25,%zmm19,%zmm29{%k1}{z}
 1f80ba0:	knotq  %k1,%k5
 1f80ba5:	vpmovuswb %zmm11,%ymm11
 1f80bab:	vptestmb %zmm0,%zmm29,%k4
 1f80bb1:	kmovq  %k4,%r15
 1f80bb6:	vinserti64x4 $0x1,%ymm27,%zmm11,%zmm28
 1f80bbd:	vmovdqa64 %zmm20,%zmm11
 1f80bc3:	vpermt2b %zmm9,%zmm19,%zmm11{%k1}{z}
 1f80bc9:	vptestmb %zmm28,%zmm28,%k2
 1f80bcf:	vpsubb %zmm28,%zmm6,%zmm27
 1f80bd5:	vpcmpltub %zmm28,%zmm6,%k0{%k2}
 1f80bdc:	vpcmpnltub %zmm28,%zmm6,%k2{%k2}
 1f80be3:	vpermt2b %zmm9,%zmm27,%zmm20{%k2}{z}
 1f80be9:	vporq  %zmm11,%zmm20,%zmm28
 1f80bef:	vmovdqu64 %zmm28,(%rdi,%r14,1)
 1f80bf6:	mov    %r14,%rdi
 1f80bf9:	shr    $0x3,%rdi
 1f80bfd:	kortestq %k3,%k0
 1f80c02:	vpandq (%r11,%r14,1),%zmm1,%zmm29
 1f80c09:	vpermt2b %zmm29,%zmm19,%zmm5
 1f80c0f:	vptestnmb %zmm5,%zmm5,%k4
 1f80c15:	korq   %k4,%k5,%k4
 1f80c1a:	vpcmpeqb %zmm7,%zmm13,%k4{%k4}
 1f80c20:	kmovq  %k4,(%rbx,%rdi,1)
 1f80c26:	jne    1f80f24 <node_facts_window_run+0x3a94>
 1f80c2c:	vpsrlw $0x2,%zmm15,%zmm0
 1f80c33:	vpaddw %zmm18,%zmm18,%zmm5
 1f80c39:	vpermi2b %zmm30,%zmm14,%zmm27{%k2}{z}
 1f80c3f:	mov    0x18(%rsp),%rax
 1f80c44:	vptestmb %zmm21,%zmm15,%k0
 1f80c4a:	vpcmpeqb -0x1aca154(%rip),%zmm13,%k6        # 4b6b00 <abi_test_hex.digits+0xb780>
 1f80c54:	vpandq %zmm4,%zmm0,%zmm0
 1f80c5a:	vpternlogq $0xf8,%zmm3,%zmm15,%zmm0
 1f80c61:	vpternlogq $0xf8,-0x19b2744(%rip){1to8},%zmm5,%zmm0        # 5ce528 <.LCPI3_47>
 1f80c6c:	vpternlogq $0xf8,-0x19b2747(%rip){1to8},%zmm26,%zmm0        # 5ce530 <.LCPI3_48>
 1f80c77:	vpandq %zmm23,%zmm18,%zmm26
 1f80c7d:	vpsllw $0x3,%zmm30,%zmm23
 1f80c84:	vpaddw %zmm26,%zmm26,%zmm5
 1f80c8a:	vpsllw $0x4,%zmm30,%zmm26
 1f80c91:	vpternlogq $0xf8,-0x19b2764(%rip){1to8},%zmm5,%zmm0        # 5ce538 <.LCPI3_49>
 1f80c9c:	mov    0xc90(%rax),%rdi
 1f80ca3:	vpternlogq $0xf8,-0x19b276e(%rip){1to8},%zmm23,%zmm0        # 5ce540 <.LCPI3_50>
 1f80cae:	vpternlogq $0xf8,-0x19b2771(%rip){1to8},%zmm26,%zmm0        # 5ce548 <.LCPI3_51>
 1f80cb9:	vmovdqa64 %zmm14,%zmm26
 1f80cbf:	vpermt2b %zmm30,%zmm19,%zmm26{%k1}{z}
 1f80cc5:	vpandq %zmm16,%zmm27,%zmm14
 1f80ccb:	vpcmpeqb %zmm17,%zmm14,%k4
 1f80cd1:	vpandq %zmm22,%zmm28,%zmm14
 1f80cd7:	vpcmpeqb -0x1aca3a1(%rip),%zmm14,%k2        # 4b6940 <abi_test_hex.digits+0xb5c0>
 1f80ce1:	vpsrlw $0x3,%zmm26,%zmm23
 1f80ce8:	vpandq %zmm16,%zmm26,%zmm5
 1f80cee:	vpternlogq $0xe4,-0x19b27a9(%rip){1to8},%zmm27,%zmm23        # 5ce550 <.LCPI3_52>
 1f80cf9:	vpcmpeqb %zmm17,%zmm5,%k3
 1f80cff:	vpermb 0x150(%rsp),%zmm23,%zmm5
 1f80d0a:	kmovq  %k0,0x10(%rsp)
 1f80d11:	vpcmpeqb %zmm7,%zmm13,%k0
 1f80d17:	kmovq  %k0,%r13
 1f80d1c:	vptestmb -0x1aca2e6(%rip),%zmm18,%k0        # 4b6a40 <abi_test_hex.digits+0xb6c0>
 1f80d26:	korq   %k4,%k3,%k3
 1f80d2b:	vpcmpeqb -0x1aca335(%rip),%zmm13,%k3{%k3}        # 4b6a00 <abi_test_hex.digits+0xb680>
 1f80d35:	vptestmb %zmm14,%zmm14,%k4
 1f80d3b:	vmovdqu64 %zmm0,(%rdi,%r14,1)
 1f80d42:	vpandd -0x19afdc8(%rip){1to16},%zmm26,%zmm0        # 5d0f84 <.LCPI3_81>
 1f80d4c:	and    %r10,%r13
 1f80d4f:	vptestnmb %zmm31,%zmm31,%k2{%k2}
 1f80d55:	vpternlogq $0xe0,%zmm2,%zmm30,%zmm5
 1f80d5c:	vptestmb %zmm12,%zmm5,%k5{%k2}
 1f80d62:	vpandq %zmm21,%zmm18,%zmm5
 1f80d68:	kmovq  %k0,%rbp
 1f80d6d:	knotq  %k3,%k3
 1f80d72:	vpternlogq $0xfe,%zmm0,%zmm14,%zmm5
 1f80d79:	and    %rbp,%r13
 1f80d7c:	vpsllw $0x7,%zmm18,%zmm0
 1f80d83:	vptestnmb %zmm5,%zmm5,%k7
 1f80d89:	vpmovb2m %zmm0,%k2
 1f80d8f:	vmovdqa64 %zmm31,%zmm0
 1f80d95:	vpternlogd $0xf8,-0x19afe0c(%rip){1to16},%zmm14,%zmm0        # 5d0f94 <.LCPI3_93>
 1f80da0:	kmovq  %k7,%rbp
 1f80da5:	vptestmb -0x1aca26f(%rip),%zmm18,%k7{%k4}        # 4b6b40 <abi_test_hex.digits+0xb7c0>
 1f80daf:	and    %r13,%rbp
 1f80db2:	mov    %r9d,%r13d
 1f80db5:	and    %r12,%rbp
 1f80db8:	kmovq  %k5,%rdi
 1f80dbd:	vptestmb %zmm24,%zmm11,%k5
 1f80dc3:	vptestmb -0x1aca20d(%rip),%zmm12,%k5{%k5}        # 4b6bc0 <abi_test_hex.digits+0xb840>
 1f80dcd:	mov    0xca0(%rax),%r12
 1f80dd4:	kmovq  %rbp,%k0
 1f80dd9:	vpmovm2b %k0,%zmm13
 1f80ddf:	vpermt2b %zmm13,%zmm19,%zmm8
 1f80de5:	vptestmb %zmm8,%zmm8,%k0{%k1}
 1f80deb:	vpbroadcastw %r14d,%zmm8
 1f80df1:	vporq  -0x1aca1bb(%rip),%zmm8,%zmm5        # 4b6c40 <abi_test_hex.digits+0xb8c0>
 1f80dfb:	kandq  %k7,%k6,%k1
 1f80e00:	kandq  %k2,%k6,%k6
 1f80e05:	vptestmb %zmm10,%zmm28,%k7
 1f80e0b:	vptestmb %zmm24,%zmm20,%k5{%k5}
 1f80e11:	kandq  %k0,%k6,%k6
 1f80e16:	vptestnmb %zmm0,%zmm0,%k5{%k5}
 1f80e1c:	vporq  -0x1aca1a6(%rip),%zmm8,%zmm0        # 4b6c80 <abi_test_hex.digits+0xb900>
 1f80e26:	vmovdqa64 %zmm13,%zmm8
 1f80e2c:	vpcompressw %zmm5,%zmm5{%k6}{z}
 1f80e32:	kandq  %k5,%k4,%k4
 1f80e37:	korq   %k1,%k4,%k0
 1f80e3c:	vmovdqu64 %zmm5,(%r12,%r13,2)
 1f80e43:	kmovd  %k6,%r12d
 1f80e47:	kshiftrq $0x20,%k6,%k6
 1f80e4d:	kmovq  %k3,%r13
 1f80e52:	kmovq  0x10(%rsp),%k3
 1f80e59:	popcnt %r12d,%r12d
 1f80e5e:	vpcompressw %zmm0,%zmm0{%k6}{z}
 1f80e64:	and    %rdi,%r13
 1f80e67:	kmovq  %k7,%rdi
 1f80e6c:	add    %r9d,%r12d
 1f80e6f:	mov    0xca0(%rax),%r9
 1f80e76:	or     %r15,%rdi
 1f80e79:	vmovdqu64 %zmm0,(%r9,%r12,2)
 1f80e80:	kmovq  %k0,%r9
 1f80e85:	vporq  %zmm31,%zmm14,%zmm0
 1f80e8b:	vmovdqa64 %zmm30,%zmm14
 1f80e91:	mov    0xc98(%rax),%r15
 1f80e98:	or     %rbp,%r9
 1f80e9b:	vptestmb %zmm0,%zmm0,%k0
 1f80ea1:	or     %r13,%r9
 1f80ea4:	mov    %rdi,0x8(%r15,%r14,1)
 1f80ea9:	kmovq  %k0,%rdi
 1f80eae:	korq   %k2,%k3,%k0
 1f80eb3:	mov    %r9,(%r15,%r14,1)
 1f80eb7:	andn   %rdi,%r9,%rdi
 1f80ebc:	mov    %rdi,0x10(%r15,%r14,1)
 1f80ec1:	kmovq  %k0,%rdi
 1f80ec6:	kmovq  %k3,0x18(%r15,%r14,1)
 1f80ecd:	or     %rbp,%rdi
 1f80ed0:	mov    %rdi,0x20(%r15,%r14,1)
 1f80ed5:	kmovd  %k6,%edi
 1f80ed9:	popcnt %rbp,%r15
 1f80ede:	add    $0x40,%r14
 1f80ee2:	popcnt %edi,%r9d
 1f80ee7:	add    %r15,%rdx
 1f80eea:	kmovq  %k4,%r15
 1f80eef:	add    %r12d,%r9d
 1f80ef2:	popcnt %r13,%r12
 1f80ef7:	mov    0x28(%rsp),%r13
 1f80efc:	add    %r12,%rcx
 1f80eff:	kmovq  %k1,%r12
 1f80f04:	popcnt %r12,%rdi
 1f80f09:	add    %rdi,%rsi
 1f80f0c:	popcnt %r15,%rdi
 1f80f11:	add    %rdi,%r8
 1f80f14:	cmp    0x20(%rsp),%r14
 1f80f19:	jb     1f80a30 <node_facts_window_run+0x35a0>
 1f80f1f:	jmp    1f817f4 <node_facts_window_run+0x4364>
 1f80f24:	kmovq  %k3,%rax
 1f80f29:	mov    %rax,%rdi
 1f80f2c:	mov    %rax,0x270(%rsp)
 1f80f34:	test   %rax,%rax
 1f80f37:	je     1f81069 <node_facts_window_run+0x3bd9>
 1f80f3d:	xor    %eax,%eax
 1f80f3f:	tzcnt  %rdi,%rax
 1f80f44:	mov    %rdi,0x10(%rsp)
 1f80f49:	lea    (%rax,%r14,1),%rbp
 1f80f4d:	mov    %rax,0x110(%rsp)
 1f80f55:	mov    %rbp,0x50(%rsp)
 1f80f5a:	mov    %ebp,%edi
 1f80f5c:	mov    0x28(%rsp),%rax
 1f80f61:	movzwl 0x6b554(%rax,%rdi,2),%r13d
 1f80f6a:	sub    %r13d,%ebp
 1f80f6d:	mov    0x18(%rsp),%r13
 1f80f72:	mov    0xc80(%r13),%r13
 1f80f79:	mov    %r13,0x230(%rsp)
 1f80f81:	mov    0x18(%rsp),%r13
 1f80f86:	mov    0xc88(%r13),%rax
 1f80f8d:	mov    %rax,0x1b0(%rsp)
 1f80f95:	mov    0x230(%rsp),%r13
 1f80f9d:	mov    0x1b0(%rsp),%rax
 1f80fa5:	movzbl 0x0(%r13,%rbp,1),%r13d
 1f80fab:	or     %r13b,(%rax,%rdi,1)
 1f80faf:	mov    0x28(%rsp),%r13
 1f80fb4:	movzbl 0x2c(%r13,%rdi,1),%edi
 1f80fba:	and    $0x7f,%edi
 1f80fbd:	mov    %rdi,0x230(%rsp)
 1f80fc5:	movzbl 0x2c(%r13,%rbp,1),%edi
 1f80fcb:	mov    0x18(%rsp),%rax
 1f80fd0:	and    $0x7f,%edi
 1f80fd3:	mov    %rdi,0x1b0(%rsp)
 1f80fdb:	movzbl 0x400(%rax,%rdi,1),%edi
 1f80fe3:	mov    %dil,0x1f0(%rsp)
 1f80feb:	mov    0x230(%rsp),%r13
 1f80ff3:	movzbl 0x1f0(%rsp),%edi
 1f80ffb:	test   %dil,0x480(%rax,%r13,1)
 1f81003:	mov    0x110(%rsp),%rax
 1f8100b:	mov    $0x0,%edi
 1f81010:	setne  %dil
 1f81014:	shlx   %rax,%rdi,%rdi
 1f81019:	mov    0x50(%rsp),%rax
 1f8101e:	or     %rdi,%r15
 1f81021:	cmp    %eax,0x20(%rsp)
 1f81025:	mov    0x18(%rsp),%rax
 1f8102a:	seta   %dil
 1f8102e:	cmpq   $0x22,0x1b0(%rsp)
 1f81037:	mov    0xc98(%rax),%rax
 1f8103e:	sete   %r13b
 1f81042:	and    %dil,%r13b
 1f81045:	movzbl %r13b,%edi
 1f81049:	shlx   %rbp,%rdi,%rdi
 1f8104e:	and    $0xffffffc0,%ebp
 1f81051:	not    %rdi
 1f81054:	and    %rdi,0x20(%rax,%rbp,1)
 1f81059:	mov    0x10(%rsp),%rdi
 1f8105e:	blsr   %rdi,%rdi
 1f81063:	jne    1f80f3d <node_facts_window_run+0x3aad>
 1f81069:	kmovq  %k0,%rax
 1f8106e:	mov    %rax,%r13
 1f81071:	mov    %rax,0x50(%rsp)
 1f81076:	test   %rax,%rax
 1f81079:	je     1f810d3 <node_facts_window_run+0x3c43>
 1f8107b:	xor    %ebp,%ebp
 1f8107d:	tzcnt  %r13,%rbp
 1f81082:	or     %r14,%rbp
 1f81085:	mov    %ebp,%eax
 1f81087:	mov    %rax,0x10(%rsp)
 1f8108c:	mov    0x28(%rsp),%rdi
 1f81091:	movzwl 0x6d5d4(%rdi,%rax,2),%edi
 1f81099:	mov    0x18(%rsp),%rax
 1f8109e:	sub    %edi,%ebp
 1f810a0:	mov    0xc80(%rax),%rdi
 1f810a7:	mov    0xc88(%rax),%rax
 1f810ae:	mov    %rax,0x110(%rsp)
 1f810b6:	movzbl (%rdi,%rbp,1),%edi
 1f810ba:	mov    0x10(%rsp),%rax
 1f810bf:	mov    0x110(%rsp),%rbp
 1f810c7:	or     %dil,0x0(%rbp,%rax,1)
 1f810cc:	blsr   %r13,%r13
 1f810d1:	jne    1f8107b <node_facts_window_run+0x3beb>
 1f810d3:	mov    0x18(%rsp),%rax
 1f810d8:	popcnt 0x270(%rsp),%r13
 1f810e2:	popcnt 0x50(%rsp),%rdi
 1f810e9:	add    0x30(%rsp),%r13
 1f810ee:	mov    0xc88(%rax),%rax
 1f810f5:	add    %rdi,%r13
 1f810f8:	mov    %r13,0x30(%rsp)
 1f810fd:	vmovdqu64 (%rax,%r14,1),%zmm28
 1f81104:	jmp    1f80c2c <node_facts_window_run+0x379c>
 1f81109:	test   %rsi,%rsi
 1f8110c:	je     1f817df <node_facts_window_run+0x434f>
 1f81112:	vmovdqu64 0x3c0(%rdi),%zmm0
 1f81119:	vbroadcasti32x4 -0x19b9313(%rip),%zmm1        # 5c7e10 <.LCPI3_88>
 1f81123:	vpbroadcastq -0x19b2c1d(%rip),%zmm2        # 5ce510 <.LCPI3_42>
 1f8112d:	vpbroadcastq -0x19b2c1f(%rip),%zmm3        # 5ce518 <.LCPI3_43>
 1f81137:	vmovdqa64 -0x1aca881(%rip),%zmm5        # 4b68c0 <abi_test_hex.digits+0xb540>
 1f81141:	vbroadcasti32x4 -0x19b931b(%rip),%zmm14        # 5c7e30 <.LCPI3_90>
 1f8114b:	vbroadcasti32x4 -0x19b9315(%rip),%zmm15        # 5c7e40 <.LCPI3_91>
 1f81155:	vbroadcasti32x4 -0x19b943f(%rip),%zmm20        # 5c7d20 <.LCPI3_18>
 1f8115f:	vbroadcasti32x4 -0x19b9319(%rip),%zmm23        # 5c7e50 <.LCPI3_92>
 1f81169:	vmovdqa64 -0x1aca533(%rip),%zmm27        # 4b6c40 <abi_test_hex.digits+0xb8c0>
 1f81173:	vmovdqa64 -0x1aca4fd(%rip),%zmm28        # 4b6c80 <abi_test_hex.digits+0xb900>
 1f8117d:	movzbl 0x600(%rdi),%r10d
 1f81185:	mov    %rdi,%rax
 1f81188:	xor    %r9d,%r9d
 1f8118b:	vpxord %xmm24,%xmm24,%xmm24
 1f81191:	vpxor  %xmm8,%xmm8,%xmm8
 1f81196:	xor    %r11d,%r11d
 1f81199:	vpxor  %xmm11,%xmm11,%xmm11
 1f8119e:	vpxord %xmm31,%xmm31,%xmm31
 1f811a4:	movq   $0x0,0x30(%rsp)
 1f811ad:	xor    %ecx,%ecx
 1f811af:	xor    %edx,%edx
 1f811b1:	xor    %esi,%esi
 1f811b3:	xor    %r8d,%r8d
 1f811b6:	neg    %r10
 1f811b9:	nopl   0x0(%rax)
 1f811c0:	vmovdqu64 0x2c(%r13,%r11,1),%zmm6
 1f811cb:	mov    0xc70(%rax),%rdi
 1f811d2:	mov    0xc78(%rax),%rbx
 1f811d9:	vmovdqa64 %zmm8,%zmm16
 1f811df:	vmovdqa64 0x140(%rax),%zmm8
 1f811e6:	vmovdqa64 0x340(%rax),%zmm7
 1f811ed:	vmovdqa64 0xc0(%rax),%zmm10
 1f811f4:	vmovdqa64 0x1c0(%rax),%zmm18
 1f811fb:	vmovdqa64 0x240(%rax),%zmm30
 1f81202:	vmovdqa64 0x2c0(%rax),%zmm17
 1f81209:	vmovdqa64 0x480(%rax),%zmm26
 1f81210:	vmovdqa64 0x500(%rax),%zmm4
 1f81217:	vmovdqa64 %zmm24,%zmm25
 1f8121d:	vmovdqa64 0x400(%rax),%zmm24
 1f81224:	vmovdqu64 (%rdi,%r11,1),%zmm12
 1f8122b:	vmovdqu64 (%rbx,%r11,1),%zmm29
 1f81232:	mov    0xc80(%rax),%rdi
 1f81239:	vpermt2b 0x180(%rax),%zmm6,%zmm8
 1f81240:	vpandq %zmm1,%zmm6,%zmm9
 1f81246:	vpermt2b 0x380(%rax),%zmm6,%zmm7
 1f8124d:	vpermt2b 0x100(%rax),%zmm6,%zmm10
 1f81254:	vpermt2b 0x200(%rax),%zmm6,%zmm18
 1f8125b:	vpermt2b 0x280(%rax),%zmm6,%zmm30
 1f81262:	vpermt2b 0x300(%rax),%zmm6,%zmm17
 1f81269:	vpermt2b 0x440(%rax),%zmm6,%zmm24
 1f81270:	vpermt2b 0x4c0(%rax),%zmm6,%zmm26
 1f81277:	vpermt2b 0x540(%rax),%zmm6,%zmm4
 1f8127e:	vpsrlw $0x2,%zmm12,%zmm19
 1f81285:	vpsrlw $0x3,%zmm12,%zmm6
 1f8128c:	vpternlogq $0xf8,%zmm2,%zmm29,%zmm8
 1f81293:	vpternlogq $0xf8,%zmm3,%zmm19,%zmm8
 1f8129a:	vpternlogq $0xf8,-0x19b2d85(%rip){1to8},%zmm6,%zmm8        # 5ce520 <.LCPI3_44>
 1f812a5:	vmovdqu64 %zmm8,(%rdi,%r11,1)
 1f812ac:	vmovdqu64 0x6b554(%r13,%r11,2),%zmm6
 1f812b7:	vmovdqu64 0x6b594(%r13,%r11,2),%zmm13
 1f812c2:	vmovdqu64 0x6d614(%r13,%r11,2),%zmm21
 1f812cd:	vpmovuswb %zmm6,%ymm6
 1f812d3:	vpmovuswb %zmm13,%ymm13
 1f812d9:	vpmovuswb %zmm21,%ymm21
 1f812df:	vinserti64x4 $0x1,%ymm13,%zmm6,%zmm6
 1f812e6:	vptestmb %zmm6,%zmm6,%k1
 1f812ec:	vpcmpnltub %zmm6,%zmm5,%k0
 1f812f3:	vpsubb %zmm6,%zmm5,%zmm13
 1f812f9:	vpcmpltub %zmm6,%zmm5,%k3{%k1}
 1f81300:	vmovdqu64 0x6d5d4(%r13,%r11,2),%zmm6
 1f8130b:	kmovq  %k1,%rdi
 1f81310:	kmovq  %k0,%r14
 1f81315:	and    %rdi,%r14
 1f81318:	mov    0xc88(%rax),%rdi
 1f8131f:	kmovq  %r14,%k1
 1f81324:	vpermt2b %zmm24,%zmm13,%zmm25{%k1}{z}
 1f8132a:	vpmovuswb %zmm6,%ymm6
 1f81330:	vptestmb %zmm26,%zmm25,%k4
 1f81336:	kmovq  %k4,%rbx
 1f8133b:	vinserti64x4 $0x1,%ymm21,%zmm6,%zmm22
 1f81342:	vmovdqa64 %zmm16,%zmm6
 1f81348:	vpermt2b %zmm8,%zmm13,%zmm6{%k1}{z}
 1f8134e:	vptestmb %zmm22,%zmm22,%k2
 1f81354:	vpsubb %zmm22,%zmm5,%zmm21
 1f8135a:	vpcmpltub %zmm22,%zmm5,%k0{%k2}
 1f81361:	vpcmpnltub %zmm22,%zmm5,%k2{%k2}
 1f81368:	vpermt2b %zmm8,%zmm21,%zmm16{%k2}{z}
 1f8136e:	kortestq %k3,%k0
 1f81373:	vporq  %zmm6,%zmm16,%zmm22
 1f81379:	vmovdqu64 %zmm22,(%rdi,%r11,1)
 1f81380:	jne    1f81674 <node_facts_window_run+0x41e4>
 1f81386:	vpsrlw $0x2,%zmm10,%zmm25
 1f8138d:	vpaddw %zmm12,%zmm12,%zmm26
 1f81393:	vpandq %zmm18,%zmm12,%zmm18
 1f81399:	mov    0x18(%rsp),%rax
 1f8139e:	vpermi2b %zmm29,%zmm11,%zmm21{%k2}{z}
 1f813a4:	vpcmpeqb -0x1aca8ae(%rip),%zmm9,%k6        # 4b6b00 <abi_test_hex.digits+0xb780>
 1f813ae:	vptestmb %zmm20,%zmm10,%k0
 1f813b4:	vpandq %zmm3,%zmm25,%zmm25
 1f813ba:	vpaddw %zmm18,%zmm18,%zmm18
 1f813c0:	kmovq  %k0,0x10(%rsp)
 1f813c7:	vpternlogq $0xf8,%zmm2,%zmm10,%zmm25
 1f813ce:	vpternlogq $0xf8,-0x19b2eb1(%rip){1to8},%zmm26,%zmm25        # 5ce528 <.LCPI3_47>
 1f813d9:	vpsllw $0x3,%zmm29,%zmm26
 1f813e0:	vpsllw $0x7,%zmm12,%zmm10
 1f813e7:	vpternlogq $0xf8,-0x19b2ec2(%rip){1to8},%zmm19,%zmm25        # 5ce530 <.LCPI3_48>
 1f813f2:	vpsllw $0x4,%zmm29,%zmm19
 1f813f9:	vpternlogq $0xf8,-0x19b2ecc(%rip){1to8},%zmm18,%zmm25        # 5ce538 <.LCPI3_49>
 1f81404:	vpandq %zmm20,%zmm12,%zmm18
 1f8140a:	vpternlogq $0xf8,-0x19b2ed5(%rip){1to8},%zmm26,%zmm25        # 5ce540 <.LCPI3_50>
 1f81415:	vmovdqa64 %zmm11,%zmm26
 1f8141b:	vpermt2b %zmm29,%zmm13,%zmm26{%k1}{z}
 1f81421:	mov    0xc90(%rax),%rdi
 1f81428:	vpternlogq $0xf8,-0x19b2eeb(%rip){1to8},%zmm19,%zmm25        # 5ce548 <.LCPI3_51>
 1f81433:	vpandq %zmm14,%zmm21,%zmm19
 1f81439:	vpcmpeqb %zmm15,%zmm19,%k4
 1f8143f:	vpandq %zmm14,%zmm26,%zmm11
 1f81445:	vpcmpeqb %zmm15,%zmm11,%k3
 1f8144b:	vmovdqa64 %zmm29,%zmm11
 1f81451:	korq   %k4,%k3,%k3
 1f81456:	vpcmpeqb -0x1acab60(%rip),%zmm9,%k4        # 4b6900 <abi_test_hex.digits+0xb580>
 1f81460:	vpcmpeqb -0x1acaa6a(%rip),%zmm9,%k3{%k3}        # 4b6a00 <abi_test_hex.digits+0xb680>
 1f8146a:	vmovdqu64 %zmm25,(%rdi,%r11,1)
 1f81471:	vpsrlw $0x3,%zmm26,%zmm25
 1f81478:	vpternlogq $0xe4,-0x19b2f33(%rip){1to8},%zmm21,%zmm25        # 5ce550 <.LCPI3_52>
 1f81483:	vpandq %zmm17,%zmm22,%zmm21
 1f81489:	vpcmpeqb -0x1acab53(%rip),%zmm21,%k2        # 4b6940 <abi_test_hex.digits+0xb5c0>
 1f81493:	vpandd -0x19b0519(%rip){1to16},%zmm26,%zmm17        # 5d0f84 <.LCPI3_81>
 1f8149d:	kmovq  %k4,%r12
 1f814a2:	vptestmb -0x1acaa6c(%rip),%zmm12,%k4        # 4b6a40 <abi_test_hex.digits+0xb6c0>
 1f814ac:	knotq  %k3,%k3
 1f814b1:	and    %r10,%r12
 1f814b4:	vpermb %zmm0,%zmm25,%zmm19
 1f814ba:	vptestnmb %zmm30,%zmm30,%k2{%k2}
 1f814c0:	vpternlogq $0xfe,%zmm17,%zmm21,%zmm18
 1f814c7:	vptestnmb %zmm18,%zmm18,%k7
 1f814cd:	vpternlogq $0xe0,%zmm1,%zmm29,%zmm19
 1f814d4:	vptestmb %zmm7,%zmm19,%k5{%k2}
 1f814da:	kmovq  %k4,%r15
 1f814df:	vptestmb %zmm21,%zmm21,%k4
 1f814e5:	vpmovb2m %zmm10,%k2
 1f814eb:	and    %r15,%r12
 1f814ee:	kmovq  %k7,%r15
 1f814f3:	vptestmb -0x1aca9bd(%rip),%zmm12,%k7{%k4}        # 4b6b40 <abi_test_hex.digits+0xb7c0>
 1f814fd:	and    %r12,%r15
 1f81500:	mov    %r9d,%r12d
 1f81503:	and    %r14,%r15
 1f81506:	mov    0xca0(%rax),%r14
 1f8150d:	kmovq  %k5,%rdi
 1f81512:	kmovq  %r15,%k5
 1f81517:	vpmovm2b %k5,%zmm9
 1f8151d:	vptestmb %zmm23,%zmm6,%k5
 1f81523:	vptestmb -0x1aca96d(%rip),%zmm7,%k5{%k5}        # 4b6bc0 <abi_test_hex.digits+0xb840>
 1f8152d:	vpermt2b %zmm9,%zmm13,%zmm31
 1f81533:	vmovdqa64 %zmm30,%zmm6
 1f81539:	vpternlogd $0xf8,-0x19b05b0(%rip){1to16},%zmm21,%zmm6        # 5d0f94 <.LCPI3_93>
 1f81544:	vptestmb %zmm31,%zmm31,%k0{%k1}
 1f8154a:	kandq  %k7,%k6,%k1
 1f8154f:	kandq  %k2,%k6,%k6
 1f81554:	vptestmb %zmm4,%zmm22,%k7
 1f8155a:	vpbroadcastw %r11d,%zmm4
 1f81560:	vmovdqa64 %zmm9,%zmm31
 1f81566:	vporq  %zmm27,%zmm4,%zmm7
 1f8156c:	vporq  %zmm28,%zmm4,%zmm4
 1f81572:	vptestmb %zmm23,%zmm16,%k5{%k5}
 1f81578:	kandq  %k0,%k6,%k6
 1f8157d:	kmovd  %k6,%ebp
 1f81581:	vptestnmb %zmm6,%zmm6,%k5{%k5}
 1f81587:	vpxor  %xmm6,%xmm6,%xmm6
 1f8158b:	vpcompressw %zmm7,%zmm6{%k6}{z}
 1f81591:	kshiftrq $0x20,%k6,%k6
 1f81597:	vpcompressw %zmm4,%zmm4{%k6}{z}
 1f8159d:	vmovdqu64 %zmm6,(%r14,%r12,2)
 1f815a4:	popcnt %ebp,%r14d
 1f815a9:	kmovq  %k3,%r12
 1f815ae:	kmovq  0x10(%rsp),%k3
 1f815b5:	kandq  %k5,%k4,%k4
 1f815ba:	kmovd  %k6,%ebp
 1f815be:	add    %r9d,%r14d
 1f815c1:	mov    0xca0(%rax),%r9
 1f815c8:	and    %rdi,%r12
 1f815cb:	kmovq  %k7,%rdi
 1f815d0:	korq   %k1,%k4,%k0
 1f815d5:	or     %rbx,%rdi
 1f815d8:	vmovdqu64 %zmm4,(%r9,%r14,2)
 1f815df:	kmovq  %k0,%r9
 1f815e4:	vporq  %zmm30,%zmm21,%zmm4
 1f815ea:	mov    0xc98(%rax),%rbx
 1f815f1:	or     %r15,%r9
 1f815f4:	vptestmb %zmm4,%zmm4,%k0
 1f815fa:	or     %r12,%r9
 1f815fd:	mov    %rdi,0x8(%rbx,%r11,1)
 1f81602:	kmovq  %k0,%rdi
 1f81607:	korq   %k2,%k3,%k0
 1f8160c:	mov    %r9,(%rbx,%r11,1)
 1f81610:	andn   %rdi,%r9,%rdi
 1f81615:	kmovq  %k0,%r9
 1f8161a:	or     %r15,%r9
 1f8161d:	mov    %rdi,0x10(%rbx,%r11,1)
 1f81622:	kmovq  %k3,0x18(%rbx,%r11,1)
 1f81629:	mov    %r9,0x20(%rbx,%r11,1)
 1f8162e:	popcnt %ebp,%r9d
 1f81633:	popcnt %r15,%rbx
 1f81638:	add    $0x40,%r11
 1f8163c:	add    %r14d,%r9d
 1f8163f:	popcnt %r12,%r14
 1f81644:	add    %rbx,%rdx
 1f81647:	kmovq  %k4,%rbx
 1f8164c:	add    %r14,%rcx
 1f8164f:	kmovq  %k1,%r14
 1f81654:	popcnt %r14,%rdi
 1f81659:	add    %rdi,%rsi
 1f8165c:	popcnt %rbx,%rdi
 1f81661:	add    %rdi,%r8
 1f81664:	cmp    0x20(%rsp),%r11
 1f81669:	jb     1f811c0 <node_facts_window_run+0x3d30>
 1f8166f:	jmp    1f817f4 <node_facts_window_run+0x4364>
 1f81674:	kmovq  %k3,%rax
 1f81679:	mov    %r13,%r15
 1f8167c:	mov    %rax,0x50(%rsp)
 1f81681:	mov    %rax,%rdi
 1f81684:	test   %rax,%rax
 1f81687:	mov    0x18(%rsp),%rax
 1f8168c:	je     1f8175f <node_facts_window_run+0x42cf>
 1f81692:	mov    %rdi,0x10(%rsp)
 1f81697:	tzcnt  %rdi,%rdi
 1f8169c:	mov    0xc88(%rax),%r13
 1f816a3:	lea    (%rdi,%r11,1),%r12
 1f816a7:	mov    %rdi,0x150(%rsp)
 1f816af:	mov    %r12d,%edi
 1f816b2:	movzwl 0x6b554(%r15,%rdi,2),%ebp
 1f816bb:	mov    %r12,0x110(%rsp)
 1f816c3:	sub    %ebp,%r12d
 1f816c6:	mov    0xc80(%rax),%rbp
 1f816cd:	movzbl 0x0(%rbp,%r12,1),%ebp
 1f816d3:	or     %bpl,0x0(%r13,%rdi,1)
 1f816d8:	movzbl 0x2c(%r15,%r12,1),%r13d
 1f816de:	movzbl 0x2c(%r15,%rdi,1),%edi
 1f816e4:	xor    %r15d,%r15d
 1f816e7:	and    $0x7f,%r13d
 1f816eb:	and    $0x7f,%edi
 1f816ee:	movzbl 0x400(%rax,%r13,1),%ebp
 1f816f7:	test   %bpl,0x480(%rax,%rdi,1)
 1f816ff:	mov    0x150(%rsp),%rdi
 1f81707:	setne  %r15b
 1f8170b:	shlx   %rdi,%r15,%rdi
 1f81710:	mov    0xc98(%rax),%r15
 1f81717:	or     %rdi,%rbx
 1f8171a:	mov    0x110(%rsp),%rdi
 1f81722:	cmp    %edi,0x20(%rsp)
 1f81726:	seta   %dil
 1f8172a:	cmp    $0x22,%r13
 1f8172e:	sete   %bpl
 1f81732:	and    %dil,%bpl
 1f81735:	movzbl %bpl,%edi
 1f81739:	shlx   %r12,%rdi,%rdi
 1f8173e:	and    $0xffffffc0,%r12d
 1f81742:	not    %rdi
 1f81745:	and    %rdi,0x20(%r15,%r12,1)
 1f8174a:	mov    0x10(%rsp),%rdi
 1f8174f:	mov    0x28(%rsp),%r15
 1f81754:	blsr   %rdi,%rdi
 1f81759:	jne    1f81692 <node_facts_window_run+0x4202>
 1f8175f:	kmovq  %k0,%rdi
 1f81764:	mov    %rdi,%r12
 1f81767:	mov    %rdi,0x10(%rsp)
 1f8176c:	test   %rdi,%rdi
 1f8176f:	je     1f817ac <node_facts_window_run+0x431c>
 1f81771:	mov    0x28(%rsp),%r15
 1f81776:	xor    %edi,%edi
 1f81778:	tzcnt  %r12,%rdi
 1f8177d:	or     %r11,%rdi
 1f81780:	mov    %edi,%r13d
 1f81783:	movzwl 0x6d5d4(%r15,%r13,2),%ebp
 1f8178c:	mov    0xc88(%rax),%r15
 1f81793:	sub    %ebp,%edi
 1f81795:	mov    0xc80(%rax),%rbp
 1f8179c:	movzbl 0x0(%rbp,%rdi,1),%edi
 1f817a1:	or     %dil,(%r15,%r13,1)
 1f817a5:	blsr   %r12,%r12
 1f817aa:	jne    1f81771 <node_facts_window_run+0x42e1>
 1f817ac:	popcnt 0x50(%rsp),%rdi
 1f817b3:	mov    0xc88(%rax),%rax
 1f817ba:	popcnt 0x10(%rsp),%r15
 1f817c1:	add    0x30(%rsp),%rdi
 1f817c6:	vmovdqu64 (%rax,%r11,1),%zmm22
 1f817cd:	add    %r15,%rdi
 1f817d0:	mov    %rdi,0x30(%rsp)
 1f817d5:	mov    0x28(%rsp),%r13
 1f817da:	jmp    1f81386 <node_facts_window_run+0x3ef6>
 1f817df:	movq   $0x0,0x30(%rsp)
 1f817e8:	xor    %ecx,%ecx
 1f817ea:	xor    %edx,%edx
 1f817ec:	xor    %esi,%esi
 1f817ee:	xor    %r8d,%r8d
 1f817f1:	xor    %r9d,%r9d
 1f817f4:	mov    0x38(%rsp),%rdi
 1f817f9:	mov    0x30(%rsp),%rax
 1f817fe:	movq   $0x0,0x2b0(%rsp)
 1f8180a:	add    %rax,0xa88(%rdi)
 1f81811:	add    %rcx,0x7e8(%rdi)
 1f81818:	add    %rdx,0x800(%rdi)
 1f8181f:	add    %rsi,0x838(%rdi)
 1f81826:	add    %r8,0x850(%rdi)
 1f8182d:	test   %r9d,%r9d
 1f81830:	je     1f818ff <node_facts_window_run+0x446f>
 1f81836:	mov    %r9d,%r14d
 1f81839:	mov    0x18(%rsp),%r9
 1f8183e:	mov    $0x8,%ebp
 1f81843:	xor    %r12d,%r12d
 1f81846:	xor    %r13d,%r13d
 1f81849:	xor    %r15d,%r15d
 1f8184c:	nopl   0x0(%rax)
 1f81850:	mov    0xca0(%r9),%rax
 1f81857:	mov    0x28(%rsp),%rsi
 1f8185c:	mov    0xca8(%r9),%rcx
 1f81863:	movzwl (%rax,%r13,2),%ebx
 1f81868:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f81870:	sub    %eax,%ebx
 1f81872:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f8187a:	mov    %ebx,%edx
 1f8187c:	sub    %eax,%edx
 1f8187e:	cmpb   $0x2,0x69454(%rsi,%rdx,1)
 1f81886:	mov    0x757d4(%rsi,%rdx,4),%eax
 1f8188d:	cmovne %r12,%rax
 1f81891:	movzbl (%rcx,%rax,1),%eax
 1f81895:	cmovne %ebp,%eax
 1f81898:	test   $0x8,%al
 1f8189a:	je     1f818ad <node_facts_window_run+0x441d>
 1f8189c:	movzbl %al,%eax
 1f8189f:	test   $0x10,%al
 1f818a1:	jne    1f818d1 <node_facts_window_run+0x4441>
 1f818a3:	inc    %r13
 1f818a6:	cmp    %r13,%r14
 1f818a9:	jne    1f81850 <node_facts_window_run+0x43c0>
 1f818ab:	jmp    1f818f8 <node_facts_window_run+0x4468>
 1f818ad:	mov    0x28(%rsp),%rsi
 1f818b2:	mov    %r9,%rdi
 1f818b5:	vzeroupper
 1f818b8:	call   1f93c80 <node_tests_window_wants>
 1f818bd:	mov    0x18(%rsp),%r9
 1f818c2:	mov    0x38(%rsp),%rdi
 1f818c7:	movzbl %al,%eax
 1f818ca:	inc    %r15
 1f818cd:	test   $0x10,%al
 1f818cf:	je     1f818a3 <node_facts_window_run+0x4413>
 1f818d1:	mov    0xc98(%r9),%rdx
 1f818d8:	mov    %ebx,%ecx
 1f818da:	mov    $0xfffffffffffffffe,%rax
 1f818e1:	and    $0xffffffc0,%ebx
 1f818e4:	rol    %cl,%rax
 1f818e7:	and    %rax,0x20(%rdx,%rbx,1)
 1f818ec:	inc    %r13
 1f818ef:	cmp    %r13,%r14
 1f818f2:	jne    1f81850 <node_facts_window_run+0x43c0>
 1f818f8:	mov    0x28(%rsp),%r13
 1f818fd:	jmp    1f8190a <node_facts_window_run+0x447a>
 1f818ff:	mov    0x18(%rsp),%r9
 1f81904:	xor    %r14d,%r14d
 1f81907:	xor    %r15d,%r15d
 1f8190a:	add    %r15,0x828(%rdi)
 1f81911:	rdtsc
 1f81913:	add    %r14,0x820(%rdi)
 1f8191a:	mov    %rax,0x740(%rsp)
 1f81922:	mov    %rdx,0x470(%rsp)
 1f8192a:	mov    0x8(%rsp),%rax
 1f8192f:	mov    0x68(%rsp),%rbp
 1f81934:	mov    0x80(%rsp),%r12
 1f8193c:	cmpl   $0x0,0xa90(%rax)
 1f81943:	je     1f8282a <node_facts_window_run+0x539a>
 1f81949:	movzbl 0x88(%rsp),%eax
 1f81951:	lea    0x42ec(%r13),%rdx
 1f81958:	mov    $0xffffffffffffffff,%r14
 1f8195f:	xor    %r8d,%r8d
 1f81962:	xor    %r15d,%r15d
 1f81965:	mov    %eax,0x6c0(%rsp)
 1f8196c:	movzbl 0x40(%r9),%eax
 1f81971:	shl    $0x1b,%rax
 1f81975:	mov    %rax,0xb0(%rsp)
 1f8197d:	mov    0xc0(%rsp),%rax
 1f81985:	mov    (%rax),%rax
 1f81988:	mov    0x6c8(%rax),%ecx
 1f8198e:	mov    0x6e8(%rax),%eax
 1f81994:	mov    %ecx,0x40(%rsp)
 1f81998:	mov    %eax,0x820(%rsp)
 1f8199f:	movzbl 0x3a(%r9),%eax
 1f819a4:	lea    0x422c(%r13),%rcx
 1f819ab:	mov    %eax,0x98(%rsp)
 1f819b2:	movzbl 0x3c(%r9),%eax
 1f819b7:	mov    %eax,0xa8(%rsp)
 1f819be:	mov    0xb8(%rsp),%eax
 1f819c5:	mov    %rdx,0x70(%rsp)
 1f819ca:	mov    %rcx,0x108(%rsp)
 1f819d2:	movl   $0x0,0x270(%rsp)
 1f819dd:	movq   $0x0,0x2b0(%rsp)
 1f819e9:	vpbroadcastd %eax,%zmm3
 1f819ef:	jmp    1f81a1b <node_facts_window_run+0x458b>
 1f819f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81a00:	movb   $0x0,0x61(%rdx)
 1f81a04:	mov    0x8(%rsp),%rax
 1f81a09:	inc    %r15
 1f81a0c:	mov    0xa90(%rax),%eax
 1f81a12:	cmp    %rax,%r15
 1f81a15:	jae    1f8282a <node_facts_window_run+0x539a>
 1f81a1b:	mov    0x8(%rsp),%rax
 1f81a20:	imul   $0x68,%r15,%rdx
 1f81a24:	add    %rbp,%rdx
 1f81a27:	mov    0xa88(%rax),%rax
 1f81a2e:	cmpb   $0x0,(%rax,%r15,1)
 1f81a33:	je     1f81a00 <node_facts_window_run+0x4570>
 1f81a35:	mov    0x8(%rsp),%rax
 1f81a3a:	mov    0xa50(%rax),%rax
 1f81a41:	mov    (%rax,%r15,4),%eax
 1f81a45:	cmp    0x20(%rdi),%eax
 1f81a48:	jae    1f81a00 <node_facts_window_run+0x4570>
 1f81a4a:	mov    0x18(%rdi),%rcx
 1f81a4e:	movzbl (%rcx,%rax,1),%eax
 1f81a52:	shr    $0x5,%al
 1f81a55:	and    $0x1,%al
 1f81a57:	mov    %al,0x61(%rdx)
 1f81a5a:	je     1f81a04 <node_facts_window_run+0x4574>
 1f81a5c:	mov    %rdx,0x2f0(%rsp)
 1f81a64:	mov    0xc90(%r9),%rcx
 1f81a6b:	mov    0x8(%rsp),%rax
 1f81a70:	mov    0xa70(%rax),%rax
 1f81a77:	mov    (%rax,%r15,4),%eax
 1f81a7b:	mov    0x651b8(%r13,%rax,4),%r12d
 1f81a83:	mov    %eax,%ebp
 1f81a85:	mov    %rax,0x570(%rsp)
 1f81a8d:	sub    %r12d,%ebp
 1f81a90:	inc    %ebp
 1f81a92:	mov    %ebp,%eax
 1f81a94:	mov    %rax,0x1f0(%rsp)
 1f81a9c:	test   %r12,%r12
 1f81a9f:	je     1f81ac6 <node_facts_window_run+0x4636>
 1f81aa1:	lea    -0x1(%r12),%rdx
 1f81aa6:	shr    $0x6,%rdx
 1f81aaa:	inc    %rdx
 1f81aad:	mov    %edx,%eax
 1f81aaf:	and    $0x7,%eax
 1f81ab2:	cmp    $0x1c1,%r12d
 1f81ab9:	jae    1f81acd <node_facts_window_run+0x463d>
 1f81abb:	vpxor  %xmm0,%xmm0,%xmm0
 1f81abf:	xor    %esi,%esi
 1f81ac1:	jmp    1f81c2a <node_facts_window_run+0x479a>
 1f81ac6:	xor    %eax,%eax
 1f81ac8:	jmp    1f81ca6 <node_facts_window_run+0x4816>
 1f81acd:	mov    0x1f0(%rsp),%rsi
 1f81ad5:	and    $0xfffffffffffffff8,%rdx
 1f81ad9:	vpxor  %xmm0,%xmm0,%xmm0
 1f81add:	lea    0x1c0(%rcx,%rsi,1),%rdi
 1f81ae5:	xor    %esi,%esi
 1f81ae7:	nopw   0x0(%rax,%rax,1)
 1f81af0:	lea    (%r12,%rsi,1),%r9
 1f81af4:	mov    %r9d,%r8d
 1f81af7:	sub    $0x40,%r9
 1f81afb:	shlx   %r8,%r14,%r8
 1f81b00:	not    %r8
 1f81b03:	mov    %r8,%r10
 1f81b06:	cmovae %r14,%r10
 1f81b0a:	cmp    $0x40,%r9
 1f81b0e:	shlx   %r9,%r14,%r9
 1f81b13:	not    %r9
 1f81b16:	kmovq  %r10,%k1
 1f81b1b:	cmovae %r14,%r9
 1f81b1f:	vmovdqu8 -0x1c0(%rdi),%zmm1{%k1}{z}
 1f81b26:	kmovq  %r9,%k1
 1f81b2b:	lea    -0x80(%r12,%rsi,1),%r9
 1f81b30:	vmovdqu8 -0x180(%rdi),%zmm2{%k1}{z}
 1f81b37:	cmp    $0x40,%r9
 1f81b3b:	mov    %r8,%r9
 1f81b3e:	cmovae %r14,%r9
 1f81b42:	kmovq  %r9,%k1
 1f81b47:	lea    -0xc0(%r12,%rsi,1),%r9
 1f81b4f:	cmp    $0x40,%r9
 1f81b53:	mov    %r8,%r9
 1f81b56:	cmovae %r14,%r9
 1f81b5a:	vpternlogq $0xfe,%zmm1,%zmm0,%zmm2
 1f81b61:	vmovdqu8 -0x140(%rdi),%zmm0{%k1}{z}
 1f81b68:	kmovq  %r9,%k1
 1f81b6d:	lea    -0x100(%r12,%rsi,1),%r9
 1f81b75:	vmovdqu8 -0x100(%rdi),%zmm1{%k1}{z}
 1f81b7c:	cmp    $0x40,%r9
 1f81b80:	mov    %r8,%r9
 1f81b83:	cmovae %r14,%r9
 1f81b87:	kmovq  %r9,%k1
 1f81b8c:	lea    -0x140(%r12,%rsi,1),%r9
 1f81b94:	cmp    $0x40,%r9
 1f81b98:	mov    %r8,%r9
 1f81b9b:	cmovae %r14,%r9
 1f81b9f:	vpternlogq $0xfe,%zmm0,%zmm2,%zmm1
 1f81ba6:	vmovdqu8 -0xc0(%rdi),%zmm0{%k1}{z}
 1f81bad:	kmovq  %r9,%k1
 1f81bb2:	lea    -0x180(%r12,%rsi,1),%r9
 1f81bba:	vmovdqu8 -0x80(%rdi),%zmm2{%k1}{z}
 1f81bc1:	cmp    $0x40,%r9
 1f81bc5:	mov    %r8,%r9
 1f81bc8:	cmovae %r14,%r9
 1f81bcc:	kmovq  %r9,%k1
 1f81bd1:	lea    -0x1c0(%r12,%rsi,1),%r9
 1f81bd9:	vmovdqu8 -0x40(%rdi),%zmm4{%k1}{z}
 1f81be0:	cmp    $0x40,%r9
 1f81be4:	cmovae %r14,%r8
 1f81be8:	add    $0xfffffffffffffe00,%rsi
 1f81bef:	kmovq  %r8,%k1
 1f81bf4:	vpternlogq $0xfe,%zmm0,%zmm1,%zmm2
 1f81bfb:	vmovdqu8 (%rdi),%zmm0{%k1}{z}
 1f81c01:	add    $0x200,%rdi
 1f81c08:	add    $0xfffffffffffffff8,%rdx
 1f81c0c:	vpternlogq $0xfe,%zmm4,%zmm2,%zmm0
 1f81c13:	jne    1f81af0 <node_facts_window_run+0x4660>
 1f81c19:	test   %rax,%rax
 1f81c1c:	je     1f82749 <node_facts_window_run+0x52b9>
 1f81c22:	mov    0x18(%rsp),%r9
 1f81c27:	neg    %rsi
 1f81c2a:	mov    0x1f0(%rsp),%rdi
 1f81c32:	lea    (%rcx,%rsi,1),%rdx
 1f81c36:	shl    $0x6,%eax
 1f81c39:	add    %rdi,%rdx
 1f81c3c:	mov    %r12,%rdi
 1f81c3f:	sub    %rsi,%rdi
 1f81c42:	xor    %esi,%esi
 1f81c44:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81c50:	mov    %edi,%r8d
 1f81c53:	sub    $0x40,%rdi
 1f81c57:	shlx   %r8,%r14,%r8
 1f81c5c:	not    %r8
 1f81c5f:	cmovae %r14,%r8
 1f81c63:	kmovq  %r8,%k1
 1f81c68:	vmovdqu8 (%rdx,%rsi,1),%zmm1{%k1}{z}
 1f81c6f:	add    $0x40,%rsi
 1f81c73:	vporq  %zmm1,%zmm0,%zmm0
 1f81c79:	cmp    %rsi,%rax
 1f81c7c:	jne    1f81c50 <node_facts_window_run+0x47c0>
 1f81c7e:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f81c85:	xor    %r8d,%r8d
 1f81c88:	vporq  %zmm1,%zmm0,%zmm0
 1f81c8e:	vextracti128 $0x1,%ymm0,%xmm1
 1f81c94:	vpor   %xmm1,%xmm0,%xmm0
 1f81c98:	vpshufd $0xee,%xmm0,%xmm1
 1f81c9d:	vpor   %xmm1,%xmm0,%xmm0
 1f81ca1:	vmovq  %xmm0,%rax
 1f81ca6:	mov    0x8(%rsp),%rsi
 1f81cab:	mov    0xa58(%rsi),%rdx
 1f81cb2:	mov    0xa68(%rsi),%rsi
 1f81cb9:	mov    (%rdx,%r15,4),%edi
 1f81cbd:	mov    %rax,%rdx
 1f81cc0:	shr    $0x20,%rdx
 1f81cc4:	mov    (%rsi,%r15,4),%r10d
 1f81cc8:	or     %rax,%rdx
 1f81ccb:	mov    %rdx,%rsi
 1f81cce:	shr    $0x10,%rsi
 1f81cd2:	or     %edx,%esi
 1f81cd4:	mov    %esi,%eax
 1f81cd6:	shr    $0x8,%eax
 1f81cd9:	or     %esi,%eax
 1f81cdb:	mov    %edi,0x3b0(%rsp)
 1f81ce2:	cmp    %r12d,%edi
 1f81ce5:	jbe    1f81ceb <node_facts_window_run+0x485b>
 1f81ce7:	or     (%rcx,%r10,1),%al
 1f81ceb:	movzbl %al,%esi
 1f81cee:	lea    0x0(,%rsi,8),%edx
 1f81cf5:	lea    0x0(,%rsi,4),%ecx
 1f81cfc:	mov    %edx,%eax
 1f81cfe:	mov    %ecx,0x370(%rsp)
 1f81d05:	and    $0x8,%eax
 1f81d08:	and    $0x10,%ecx
 1f81d0b:	and    $0x40,%edx
 1f81d0e:	or     %eax,%ecx
 1f81d10:	mov    %esi,%eax
 1f81d12:	and    $0x10,%eax
 1f81d15:	lea    (%rcx,%rax,2),%eax
 1f81d18:	or     %eax,%edx
 1f81d1a:	mov    %esi,%eax
 1f81d1c:	and    $0x2,%eax
 1f81d1f:	mov    %rdx,0x1b0(%rsp)
 1f81d27:	mov    %rsi,0x650(%rsp)
 1f81d2f:	mov    %eax,0x610(%rsp)
 1f81d36:	mov    %r10,0x4b0(%rsp)
 1f81d3e:	je     1f81d57 <node_facts_window_run+0x48c7>
 1f81d40:	cmpb   $0x1,0x26(%r9)
 1f81d45:	jne    1f81d57 <node_facts_window_run+0x48c7>
 1f81d47:	movzbl 0x54(%r9),%eax
 1f81d4c:	shl    $0x11,%eax
 1f81d4f:	add    %rax,0x1b0(%rsp)
 1f81d57:	mov    0xcd0(%r9),%rax
 1f81d5e:	mov    0x270(%rsp),%edx
 1f81d65:	mov    0xcd8(%r9),%rcx
 1f81d6c:	mov    %ebp,%r11d
 1f81d6f:	mov    %r12d,%edi
 1f81d72:	shr    $0x6,%edi
 1f81d75:	and    $0x3f,%ebp
 1f81d78:	shr    $0x6,%r11d
 1f81d7c:	lea    (%rax,%rdx,8),%rsi
 1f81d80:	lea    (%rcx,%rdx,8),%r10
 1f81d84:	mov    %rsi,0x530(%rsp)
 1f81d8c:	mov    %r10,0x430(%rsp)
 1f81d94:	mov    %ebp,%r10d
 1f81d97:	xor    $0x3f,%r10d
 1f81d9b:	lea    0x1(%rdi),%rsi
 1f81d9f:	mov    %rbp,0x110(%rsp)
 1f81da7:	mov    %rdi,0x4f0(%rsp)
 1f81daf:	mov    %r12,0x10(%rsp)
 1f81db4:	mov    %rsi,0x3f0(%rsp)
 1f81dbc:	cmp    $0x40,%r12d
 1f81dc0:	jae    1f81dde <node_facts_window_run+0x494e>
 1f81dc2:	mov    %r12,%r13
 1f81dc5:	mov    $0xffffffff,%r14d
 1f81dcb:	xor    %esi,%esi
 1f81dcd:	movq   $0x0,0x20(%rsp)
 1f81dd6:	xor    %r12d,%r12d
 1f81dd9:	jmp    1f82062 <node_facts_window_run+0x4bd2>
 1f81dde:	shr    $1,%esi
 1f81de0:	lea    0x8(%rax,%rdx,8),%rax
 1f81de5:	lea    0x8(%rcx,%rdx,8),%rcx
 1f81dea:	mov    %r15,0x5d0(%rsp)
 1f81df2:	mov    %r11,0x90(%rsp)
 1f81dfa:	shl    $0x6,%r11d
 1f81dfe:	mov    $0xffffffff,%r14d
 1f81e04:	xor    %r9d,%r9d
 1f81e07:	mov    %r12d,%r8d
 1f81e0a:	xor    %ebp,%ebp
 1f81e0c:	shl    $0x7,%rsi
 1f81e10:	mov    %rax,0x50(%rsp)
 1f81e15:	mov    %r11,0x150(%rsp)
 1f81e1d:	mov    %rcx,0x30(%rsp)
 1f81e22:	mov    %rsi,0x230(%rsp)
 1f81e2a:	xor    %esi,%esi
 1f81e2c:	movq   $0x0,0x20(%rsp)
 1f81e35:	data16 cs nopw 0x0(%rax,%rax,1)
 1f81e40:	mov    0x18(%rsp),%rdi
 1f81e45:	mov    %r8d,%r13d
 1f81e48:	sub    $0x40,%r13d
 1f81e4c:	mov    $0x40,%edx
 1f81e51:	mov    0x150(%rsp),%r11
 1f81e59:	mov    $0x0,%eax
 1f81e5e:	mov    0x50(%rsp),%r12
 1f81e63:	cmovb  %r8d,%edx
 1f81e67:	cmp    0x10(%rsp),%r9
 1f81e6c:	mov    0xc98(%rdi),%r15
 1f81e73:	cmovae %eax,%edx
 1f81e76:	mov    $0xffffffffffffffff,%rax
 1f81e7d:	add    %r11,%r15
 1f81e80:	cmp    $0x40,%edx
 1f81e83:	shlx   %rdx,%rax,%rdx
 1f81e88:	not    %rdx
 1f81e8b:	mov    0x58(%r9,%r15,1),%rbx
 1f81e90:	cmove  %rax,%rdx
 1f81e94:	mov    0x110(%rsp),%rax
 1f81e9c:	add    %rbx,%rbx
 1f81e9f:	shrx   %rax,0x18(%r9,%r15,1),%rcx
 1f81ea6:	shlx   %r10,%rbx,%rbx
 1f81eab:	or     %rcx,%rbx
 1f81eae:	mov    0x48(%r9,%r15,1),%rcx
 1f81eb3:	shrx   %rax,0x8(%r9,%r15,1),%r15
 1f81eba:	and    %rdx,%rbx
 1f81ebd:	add    %rcx,%rcx
 1f81ec0:	shlx   %r10,%rcx,%rcx
 1f81ec5:	or     %r15,%rcx
 1f81ec8:	and    %rdx,%rcx
 1f81ecb:	mov    %rcx,-0x8(%r12,%rsi,8)
 1f81ed0:	mov    0xc98(%rdi),%rcx
 1f81ed7:	mov    %r14d,%edi
 1f81eda:	mov    %r11,%r14
 1f81edd:	add    %r11,%rcx
 1f81ee0:	shrx   %rax,0x10(%r9,%rcx,1),%r11
 1f81ee7:	mov    0x50(%r9,%rcx,1),%rcx
 1f81eec:	add    %rcx,%rcx
 1f81eef:	shlx   %r10,%rcx,%r15
 1f81ef4:	mov    0x30(%rsp),%rcx
 1f81ef9:	or     %r11,%r15
 1f81efc:	mov    %r9d,%r11d
 1f81eff:	and    %rdx,%r15
 1f81f02:	mov    0x20(%rsp),%rdx
 1f81f07:	mov    %r15,-0x8(%rcx,%rsi,8)
 1f81f0c:	popcnt %rbx,%rcx
 1f81f11:	add    %ecx,%edx
 1f81f13:	lzcnt  %rbx,%rcx
 1f81f18:	sub    %ecx,%r11d
 1f81f1b:	lea    0x40(%r9),%rcx
 1f81f1f:	add    $0x3f,%r11d
 1f81f23:	test   %rbx,%rbx
 1f81f26:	mov    %edi,%ebx
 1f81f28:	mov    $0x40,%edi
 1f81f2d:	cmovne %r11d,%ebx
 1f81f31:	or     -0x8(%r12,%rsi,8),%rbp
 1f81f36:	cmp    $0x40,%r13d
 1f81f3a:	mov    $0xffffffffffffffff,%r11
 1f81f41:	cmovae %edi,%r13d
 1f81f45:	cmp    0x10(%rsp),%rcx
 1f81f4a:	mov    0x18(%rsp),%rdi
 1f81f4f:	mov    $0x0,%ecx
 1f81f54:	cmovae %ecx,%r13d
 1f81f58:	mov    0xc98(%rdi),%rcx
 1f81f5f:	add    %r14,%rcx
 1f81f62:	shlx   %r13,%r11,%r14
 1f81f67:	cmp    $0x40,%r13d
 1f81f6b:	mov    0x98(%r9,%rcx,1),%r13
 1f81f73:	not    %r14
 1f81f76:	cmove  %r11,%r14
 1f81f7a:	shrx   %rax,0x58(%r9,%rcx,1),%r11
 1f81f81:	add    %r13,%r13
 1f81f84:	shlx   %r10,%r13,%r13
 1f81f89:	or     %r11,%r13
 1f81f8c:	mov    0x88(%r9,%rcx,1),%r11
 1f81f94:	shrx   %rax,0x48(%r9,%rcx,1),%rcx
 1f81f9b:	and    %r14,%r13
 1f81f9e:	add    %r11,%r11
 1f81fa1:	shlx   %r10,%r11,%r11
 1f81fa6:	or     %rcx,%r11
 1f81fa9:	and    %r14,%r11
 1f81fac:	mov    %r11,(%r12,%rsi,8)
 1f81fb0:	mov    0xc98(%rdi),%rcx
 1f81fb7:	add    0x150(%rsp),%rcx
 1f81fbf:	shrx   %rax,0x50(%r9,%rcx,1),%r11
 1f81fc6:	mov    0x90(%r9,%rcx,1),%rcx
 1f81fce:	popcnt %r13,%rax
 1f81fd3:	add    %edx,%eax
 1f81fd5:	lzcnt  %r13,%rdx
 1f81fda:	mov    %rax,0x20(%rsp)
 1f81fdf:	mov    0x30(%rsp),%rax
 1f81fe4:	add    %rcx,%rcx
 1f81fe7:	shlx   %r10,%rcx,%rcx
 1f81fec:	or     %r11,%rcx
 1f81fef:	and    %r14,%rcx
 1f81ff2:	mov    %r9d,%r14d
 1f81ff5:	sub    %edx,%r14d
 1f81ff8:	add    $0x7f,%r14d
 1f81ffc:	test   %r13,%r13
 1f81fff:	mov    %rcx,(%rax,%rsi,8)
 1f82003:	cmove  %ebx,%r14d
 1f82007:	or     (%r12,%rsi,8),%rbp
 1f8200b:	add    $0x2,%rsi
 1f8200f:	sub    $0xffffffffffffff80,%r9
 1f82013:	add    $0xffffff80,%r8d
 1f82017:	or     %r15,%rbp
 1f8201a:	or     %rcx,%rbp
 1f8201d:	cmp    %r9,0x230(%rsp)
 1f82025:	jne    1f81e40 <node_facts_window_run+0x49b0>
 1f8202b:	mov    0x4f0(%rsp),%rcx
 1f82033:	mov    0x18(%rsp),%r9
 1f82038:	mov    0x5d0(%rsp),%r15
 1f82040:	mov    0x10(%rsp),%r13
 1f82045:	mov    0x90(%rsp),%r11
 1f8204d:	mov    $0x0,%r8d
 1f82053:	mov    %rbp,%r12
 1f82056:	inc    %rcx
 1f82059:	test   $0x1,%cl
 1f8205c:	je     1f82152 <node_facts_window_run+0x4cc2>
 1f82062:	mov    %rsi,%rbx
 1f82065:	shl    $0x6,%rbx
 1f82069:	mov    %r13d,%ecx
 1f8206c:	mov    0xc98(%r9),%rdi
 1f82073:	mov    $0x40,%eax
 1f82078:	mov    $0xffffffffffffffff,%rdx
 1f8207f:	sub    %ebx,%ecx
 1f82081:	cmp    $0x40,%ecx
 1f82084:	cmovae %eax,%ecx
 1f82087:	cmp    %r13,%rbx
 1f8208a:	mov    0x110(%rsp),%rax
 1f82092:	cmovae %r8d,%ecx
 1f82096:	add    %rsi,%r11
 1f82099:	shl    $0x6,%r11
 1f8209d:	cmp    $0x40,%ecx
 1f820a0:	shlx   %rcx,%rdx,%rcx
 1f820a5:	mov    0x58(%rdi,%r11,1),%rbp
 1f820aa:	not    %rcx
 1f820ad:	cmove  %rdx,%rcx
 1f820b1:	shrx   %rax,0x18(%rdi,%r11,1),%r8
 1f820b8:	add    %rbp,%rbp
 1f820bb:	shlx   %r10,%rbp,%rdx
 1f820c0:	mov    0x48(%rdi,%r11,1),%rbp
 1f820c5:	shrx   %rax,0x8(%rdi,%r11,1),%rdi
 1f820cc:	or     %r8,%rdx
 1f820cf:	and    %rcx,%rdx
 1f820d2:	add    %rbp,%rbp
 1f820d5:	shlx   %r10,%rbp,%r8
 1f820da:	mov    0x530(%rsp),%rbp
 1f820e2:	or     %rdi,%r8
 1f820e5:	and    %rcx,%r8
 1f820e8:	mov    %r8,0x0(%rbp,%rsi,8)
 1f820ed:	mov    0xc98(%r9),%rdi
 1f820f4:	shrx   %rax,0x10(%rdi,%r11,1),%r8
 1f820fb:	mov    0x20(%rsp),%rax
 1f82100:	mov    0x50(%rdi,%r11,1),%rdi
 1f82105:	mov    %eax,%r9d
 1f82108:	popcnt %rdx,%rax
 1f8210d:	add    %rdi,%rdi
 1f82110:	add    %r9d,%eax
 1f82113:	shlx   %r10,%rdi,%rdi
 1f82118:	mov    %rax,0x20(%rsp)
 1f8211d:	or     %r8,%rdi
 1f82120:	mov    %r14d,%r8d
 1f82123:	lea    0x3f(%rbx),%r14d
 1f82127:	mov    0x430(%rsp),%rax
 1f8212f:	and    %rcx,%rdi
 1f82132:	lzcnt  %rdx,%rcx
 1f82137:	mov    0x18(%rsp),%r9
 1f8213c:	sub    %ecx,%r14d
 1f8213f:	test   %rdx,%rdx
 1f82142:	cmove  %r8d,%r14d
 1f82146:	mov    %rdi,(%rax,%rsi,8)
 1f8214a:	or     0x0(%rbp,%rsi,8),%r12
 1f8214f:	or     %rdi,%r12
 1f82152:	test   %r13d,%r13d
 1f82155:	je     1f82184 <node_facts_window_run+0x4cf4>
 1f82157:	lea    -0x1(%r13),%rax
 1f8215b:	mov    $0xffffffff,%ebx
 1f82160:	shr    $0x4,%rax
 1f82164:	inc    %rax
 1f82167:	mov    %eax,%esi
 1f82169:	and    $0x3,%esi
 1f8216c:	cmp    $0x31,%r13d
 1f82170:	jae    1f8219e <node_facts_window_run+0x4d0e>
 1f82172:	vpxor  %xmm0,%xmm0,%xmm0
 1f82176:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f8217d:	xor    %ecx,%ecx
 1f8217f:	jmp    1f822e4 <node_facts_window_run+0x4e54>
 1f82184:	mov    0x4b0(%rsp),%r10
 1f8218c:	mov    0x28(%rsp),%r13
 1f82191:	xor    %r11d,%r11d
 1f82194:	mov    $0xffffffff,%ecx
 1f82199:	jmp    1f823b7 <node_facts_window_run+0x4f27>
 1f8219e:	mov    %r15,0x5d0(%rsp)
 1f821a6:	and    $0xfffffffffffffffc,%rax
 1f821aa:	lea    -0x30(%r13),%edi
 1f821ae:	lea    -0x20(%r13),%r8d
 1f821b2:	lea    -0x10(%r13),%r9d
 1f821b6:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f821bd:	mov    $0xffff,%r15d
 1f821c3:	vpxor  %xmm0,%xmm0,%xmm0
 1f821c7:	mov    0x70(%rsp),%rcx
 1f821cc:	mov    0x1f0(%rsp),%rdx
 1f821d4:	lea    (%rcx,%rdx,4),%rdx
 1f821d8:	xor    %ecx,%ecx
 1f821da:	nopw   0x0(%rax,%rax,1)
 1f821e0:	lea    0x0(%r13,%rcx,1),%r10
 1f821e5:	shlx   %r10d,%ebx,%r11d
 1f821ea:	sub    $0x10,%r10
 1f821ee:	not    %r11d
 1f821f1:	cmovae %r15d,%r11d
 1f821f5:	cmp    $0x10,%r10
 1f821f9:	kmovd  %r11d,%k1
 1f821fe:	lea    (%r9,%rcx,1),%r11d
 1f82202:	vmovdqu32 -0xc0(%rdx),%zmm2{%k1}{z}
 1f82209:	shlx   %r11d,%ebx,%r10d
 1f8220e:	lea    (%r8,%rcx,1),%r11d
 1f82212:	not    %r10d
 1f82215:	cmovae %r15d,%r10d
 1f82219:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82220:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f82226:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f8222c:	kmovd  %r10d,%k1
 1f82231:	lea    -0x20(%r13,%rcx,1),%r10
 1f82236:	vmovdqu32 -0x80(%rdx),%zmm2{%k1}{z}
 1f8223d:	cmp    $0x10,%r10
 1f82241:	shlx   %r11d,%ebx,%r10d
 1f82246:	lea    (%rdi,%rcx,1),%r11d
 1f8224a:	not    %r10d
 1f8224d:	cmovae %r15d,%r10d
 1f82251:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82258:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f8225e:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82264:	kmovd  %r10d,%k1
 1f82269:	lea    -0x30(%r13,%rcx,1),%r10
 1f8226e:	vmovdqu32 -0x40(%rdx),%zmm2{%k1}{z}
 1f82275:	cmp    $0x10,%r10
 1f82279:	shlx   %r11d,%ebx,%r10d
 1f8227e:	not    %r10d
 1f82281:	cmovae %r15d,%r10d
 1f82285:	add    $0xffffffffffffffc0,%rcx
 1f82289:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82290:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f82296:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f8229c:	kmovd  %r10d,%k1
 1f822a1:	vmovdqu32 (%rdx),%zmm2{%k1}{z}
 1f822a7:	add    $0x100,%rdx
 1f822ae:	add    $0xfffffffffffffffc,%rax
 1f822b2:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f822b9:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f822bf:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f822c5:	jne    1f821e0 <node_facts_window_run+0x4d50>
 1f822cb:	mov    0x18(%rsp),%r9
 1f822d0:	mov    0x5d0(%rsp),%r15
 1f822d8:	test   %rsi,%rsi
 1f822db:	je     1f82753 <node_facts_window_run+0x52c3>
 1f822e1:	neg    %rcx
 1f822e4:	mov    0x1f0(%rsp),%rax
 1f822ec:	mov    0x10(%rsp),%rdx
 1f822f1:	mov    0x4b0(%rsp),%r10
 1f822f9:	mov    0x28(%rsp),%r13
 1f822fe:	mov    $0xffff,%r8d
 1f82304:	shl    $0x4,%esi
 1f82307:	lea    0x0(,%rax,4),%rax
 1f8230f:	sub    %rcx,%rdx
 1f82312:	lea    (%rax,%rcx,4),%rax
 1f82316:	add    0x108(%rsp),%rax
 1f8231e:	xor    %ecx,%ecx
 1f82320:	mov    %edx,%edi
 1f82322:	sub    $0x10,%rdx
 1f82326:	shlx   %edi,%ebx,%edi
 1f8232b:	not    %edi
 1f8232d:	cmovae %r8d,%edi
 1f82331:	kmovd  %edi,%k1
 1f82335:	vmovdqu32 (%rax,%rcx,4),%zmm2{%k1}{z}
 1f8233c:	add    $0x10,%rcx
 1f82340:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82347:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f8234d:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82353:	cmp    %rcx,%rsi
 1f82356:	jne    1f82320 <node_facts_window_run+0x4e90>
 1f82358:	vextracti64x4 $0x1,%zmm1,%ymm2
 1f8235f:	vpminud %ymm2,%ymm1,%ymm1
 1f82364:	vextracti128 $0x1,%ymm1,%xmm2
 1f8236a:	vpminud %xmm2,%xmm1,%xmm1
 1f8236f:	vpshufd $0xee,%xmm1,%xmm2
 1f82374:	vpminud %xmm2,%xmm1,%xmm1
 1f82379:	vpshufd $0x55,%xmm1,%xmm2
 1f8237e:	vpminud %xmm2,%xmm1,%xmm1
 1f82383:	vmovd  %xmm1,%ecx
 1f82387:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f8238e:	vpmaxud %ymm1,%ymm0,%ymm0
 1f82393:	vextracti128 $0x1,%ymm0,%xmm1
 1f82399:	vpmaxud %xmm1,%xmm0,%xmm0
 1f8239e:	vpshufd $0xee,%xmm0,%xmm1
 1f823a3:	vpmaxud %xmm1,%xmm0,%xmm0
 1f823a8:	vpshufd $0x55,%xmm0,%xmm1
 1f823ad:	vpmaxud %xmm1,%xmm0,%xmm0
 1f823b2:	vmovd  %xmm0,%r11d
 1f823b7:	mov    0x370(%rsp),%eax
 1f823be:	and    $0x100,%eax
 1f823c3:	or     %rax,0x1b0(%rsp)
 1f823cb:	mov    0x3b0(%rsp),%eax
 1f823d2:	mov    0x570(%rsp),%rbp
 1f823da:	cmp    0x10(%rsp),%eax
 1f823de:	mov    %r10d,%eax
 1f823e1:	cmovbe %ebp,%eax
 1f823e4:	mov    0x422c(%r13,%rax,4),%edx
 1f823ec:	mov    %rdx,0x150(%rsp)
 1f823f4:	ja     1f823fc <node_facts_window_run+0x4f6c>
 1f823f6:	xor    %esi,%esi
 1f823f8:	xor    %edi,%edi
 1f823fa:	jmp    1f8241e <node_facts_window_run+0x4f8e>
 1f823fc:	mov    0xc98(%r9),%rdi
 1f82403:	mov    %r10d,%r8d
 1f82406:	and    $0xffffffc0,%r8d
 1f8240a:	shrx   %r10,0x8(%rdi,%r8,1),%rsi
 1f82411:	shrx   %r10,0x10(%rdi,%r8,1),%rdi
 1f82418:	and    $0x1,%esi
 1f8241b:	and    $0x1,%edi
 1f8241e:	mov    0x4f0(%rsp),%r13
 1f82426:	mov    0x10(%rsp),%r10
 1f8242b:	mov    0x530(%rsp),%rbx
 1f82433:	mov    0x150(%rsp),%rdx
 1f8243b:	or     %rsi,%r12
 1f8243e:	or     %rdi,%r12
 1f82441:	shlx   %r10,%rsi,%r8
 1f82446:	shl    $0x3,%r13d
 1f8244a:	mov    %ecx,%esi
 1f8244c:	or     %r8,(%rbx,%r13,1)
 1f82450:	shlx   %r10,%rdi,%r8
 1f82455:	mov    0x430(%rsp),%r10
 1f8245d:	mov    0x2f0(%rsp),%rdi
 1f82465:	or     %r8,(%r10,%r13,1)
 1f82469:	cmp    %ecx,%edx
 1f8246b:	mov    %r11d,%r8d
 1f8246e:	cmovb  %edx,%esi
 1f82471:	cmp    %r11d,%edx
 1f82474:	cmova  %edx,%r8d
 1f82478:	cmp    0xb8(%rsp),%edx
 1f8247f:	cmovae %ecx,%esi
 1f82482:	mov    0x1b0(%rsp),%rcx
 1f8248a:	cmovae %r11d,%r8d
 1f8248e:	mov    %esi,%r11d
 1f82491:	mov    0x1f0(%rsp),%rsi
 1f82499:	mov    %rcx,(%rdi)
 1f8249c:	mov    %rbx,0x8(%rdi)
 1f824a0:	mov    %r10,0x10(%rdi)
 1f824a4:	mov    0x3f0(%rsp),%r10
 1f824ac:	mov    %r10d,0x18(%rdi)
 1f824b0:	mov    0xc70(%r9),%rcx
 1f824b7:	add    %rsi,%rcx
 1f824ba:	mov    %rcx,0x20(%rdi)
 1f824be:	mov    0xc80(%r9),%rcx
 1f824c5:	add    %rsi,%rcx
 1f824c8:	mov    %rcx,0x28(%rdi)
 1f824cc:	mov    0x610(%rsp),%ecx
 1f824d3:	mov    %r8d,0x30(%rsp)
 1f824d8:	add    0xc88(%r9),%rsi
 1f824df:	shl    $0x2,%ecx
 1f824e2:	mov    %rsi,0x30(%rdi)
 1f824e6:	mov    0x20(%rsp),%rsi
 1f824eb:	mov    %r11d,0x38(%rdi)
 1f824ef:	mov    %r8d,0x3c(%rdi)
 1f824f3:	mov    $0x0,%r8d
 1f824f9:	mov    %esi,0x40(%rdi)
 1f824fc:	mov    0x370(%rsp),%esi
 1f82503:	mov    %r14d,0x44(%rdi)
 1f82507:	mov    %ecx,0x48(%rdi)
 1f8250a:	and    $0x80,%esi
 1f82510:	cmpl   $0x0,0x40(%rsp)
 1f82515:	mov    %esi,0x4c(%rdi)
 1f82518:	je     1f82551 <node_facts_window_run+0x50c1>
 1f8251a:	cmp    0xb8(%rsp),%edx
 1f82521:	mov    %edx,%ecx
 1f82523:	cmovae %r8d,%ecx
 1f82527:	jae    1f82551 <node_facts_window_run+0x50c1>
 1f82529:	mov    %r11d,%ebx
 1f8252c:	mov    0xc68(%r9),%r11
 1f82533:	mov    %ecx,%esi
 1f82535:	mov    $0x1,%edi
 1f8253a:	shr    $0x6,%ecx
 1f8253d:	mov    $0x6,%r13d
 1f82543:	shlx   %rsi,%rdi,%rsi
 1f82548:	and    (%r11,%rcx,8),%rsi
 1f8254c:	mov    %ebx,%r11d
 1f8254f:	jne    1f82577 <node_facts_window_run+0x50e7>
 1f82551:	mov    0xd0(%rsp),%rcx
 1f82559:	movzbl (%rcx,%rax,1),%eax
 1f8255d:	and    $0x7f,%eax
 1f82560:	cmpl   $0x0,0x820(%rsp)
 1f82568:	movzbl 0x580(%r9,%rax,1),%r13d
 1f82571:	jne    1f827c4 <node_facts_window_run+0x5334>
 1f82577:	mov    0x10(%rsp),%rsi
 1f8257c:	mov    0xc98(%r9),%rdx
 1f82583:	mov    %ebp,%ecx
 1f82585:	mov    0x650(%rsp),%rdi
 1f8258d:	mov    $0x0,%ebx
 1f82592:	cmp    %esi,0x3b0(%rsp)
 1f82599:	setbe  %al
 1f8259c:	and    $0xffffffc0,%ecx
 1f8259f:	inc    %r14d
 1f825a2:	and    $0x22,%edi
 1f825a5:	shrx   %rbp,0x20(%rdx,%rcx,1),%rcx
 1f825ac:	mov    0x20(%rsp),%rbp
 1f825b1:	xor    %esi,%r14d
 1f825b4:	mov    0x98(%rsp),%esi
 1f825bb:	mov    %ebp,%edx
 1f825bd:	xor    $0x1,%edx
 1f825c0:	cmp    $0x2,%r13d
 1f825c4:	cmovne %r8d,%esi
 1f825c8:	test   %edi,%edi
 1f825ca:	cmove  %edi,%esi
 1f825cd:	test   %r12,%r12
 1f825d0:	setne  %dil
 1f825d4:	or     %al,%dil
 1f825d7:	or     %r14d,%edx
 1f825da:	cmovne 0xa8(%rsp),%ebx
 1f825e2:	test   %ebp,%ebp
 1f825e4:	movzbl %dil,%eax
 1f825e8:	cmove  %ebp,%ebx
 1f825eb:	or     %eax,%ebx
 1f825ed:	xor    %eax,%eax
 1f825ef:	test   %r13d,%r13d
 1f825f2:	sete   %al
 1f825f5:	or     %esi,%ebx
 1f825f7:	andn   %eax,%ecx,%eax
 1f825fc:	mov    $0x101,%ecx
 1f82601:	or     %eax,%ebx
 1f82603:	mov    0x8(%rsp),%rax
 1f82608:	mov    %r13d,0x10(%rsp)
 1f8260d:	mov    0xb0(%rsp),%rdx
 1f82615:	mov    0xa88(%rax),%rax
 1f8261c:	movzbl (%rax,%r15,1),%eax
 1f82621:	bextr  %ecx,%eax,%eax
 1f82626:	or     %eax,%ebx
 1f82628:	xor    %eax,%eax
 1f8262a:	cmp    $0x6,%r13d
 1f8262e:	mov    0x28(%rsp),%r13
 1f82633:	sete   %al
 1f82636:	lea    (%rdx,%rax,4),%r14
 1f8263a:	or     0x1b0(%rsp),%r14
 1f82642:	cmpb   $0x1,0x3b(%r9)
 1f82647:	jne    1f826b4 <node_facts_window_run+0x5224>
 1f82649:	mov    0x68(%rsp),%rbp
 1f8264e:	mov    0x80(%rsp),%r12
 1f82656:	mov    0x38(%rsp),%rdi
 1f8265b:	test   %ebx,%ebx
 1f8265d:	jne    1f826c6 <node_facts_window_run+0x5236>
 1f8265f:	mov    0xc0(%rsp),%rax
 1f82667:	mov    0x150(%rsp),%rsi
 1f8266f:	mov    0x8(%rax),%rdx
 1f82673:	mov    0x78(%rdx),%eax
 1f82676:	cmp    %eax,%esi
 1f82678:	jae    1f826c6 <node_facts_window_run+0x5236>
 1f8267a:	mov    0x98(%rdx),%rcx
 1f82681:	movzbl (%rcx,%rsi,1),%esi
 1f82685:	cmp    $0x4a,%esi
 1f82688:	je     1f826ab <node_facts_window_run+0x521b>
 1f8268a:	cmp    $0x1e,%esi
 1f8268d:	jne    1f826c6 <node_facts_window_run+0x5236>
 1f8268f:	mov    0xa8(%rdx),%rdx
 1f82696:	mov    0x150(%rsp),%rsi
 1f8269e:	mov    (%rdx,%rsi,4),%edx
 1f826a1:	cmp    %eax,%edx
 1f826a3:	jae    1f826c6 <node_facts_window_run+0x5236>
 1f826a5:	cmpb   $0x4a,(%rcx,%rdx,1)
 1f826a9:	jne    1f826c6 <node_facts_window_run+0x5236>
 1f826ab:	or     $0x1000000,%r14
 1f826b2:	jmp    1f826c6 <node_facts_window_run+0x5236>
 1f826b4:	mov    0x68(%rsp),%rbp
 1f826b9:	mov    0x80(%rsp),%r12
 1f826c1:	mov    0x38(%rsp),%rdi
 1f826c6:	cmpl   $0x0,0xc60(%r9)
 1f826ce:	mov    0x2f0(%rsp),%rdx
 1f826d6:	mov    0x30(%rsp),%ecx
 1f826da:	jne    1f82765 <node_facts_window_run+0x52d5>
 1f826e0:	cmp    0xc48(%r9),%r11d
 1f826e7:	ja     1f826f2 <node_facts_window_run+0x5262>
 1f826e9:	cmp    0xc44(%r9),%ecx
 1f826f0:	jae    1f82765 <node_facts_window_run+0x52d5>
 1f826f2:	mov    0x10(%rsp),%eax
 1f826f6:	mov    %r14,0x50(%rdx)
 1f826fa:	add    0x270(%rsp),%r10d
 1f82702:	mov    $0xffffffffffffffff,%r14
 1f82709:	mov    %al,0x60(%rdx)
 1f8270c:	mov    %r11d,0x58(%rdx)
 1f82710:	mov    %ecx,0x5c(%rdx)
 1f82713:	mov    %bl,0x62(%rdx)
 1f82716:	mov    0x2b0(%rsp),%rdx
 1f8271e:	or     0x6c0(%rsp),%ebx
 1f82725:	mov    0xce8(%r9),%rax
 1f8272c:	mov    %edx,%ecx
 1f8272e:	add    %ebx,%edx
 1f82730:	mov    %rdx,0x2b0(%rsp)
 1f82738:	mov    %r15d,(%rax,%rcx,4)
 1f8273c:	mov    %r10d,0x270(%rsp)
 1f82744:	jmp    1f81a04 <node_facts_window_run+0x4574>
 1f82749:	mov    0x18(%rsp),%r9
 1f8274e:	jmp    1f81c7e <node_facts_window_run+0x47ee>
 1f82753:	mov    0x4b0(%rsp),%r10
 1f8275b:	mov    0x28(%rsp),%r13
 1f82760:	jmp    1f82358 <node_facts_window_run+0x4ec8>
 1f82765:	mov    0x150(%rsp),%rsi
 1f8276d:	vmovdqu64 %zmm3,0x110(%rsp)
 1f82778:	mov    %r9,%rdi
 1f8277b:	mov    %r11d,%edx
 1f8277e:	mov    %r11d,0x20(%rsp)
 1f82783:	vzeroupper
 1f82786:	call   1f6a0d0 <node_census_reader_marks>
 1f8278b:	vmovdqu64 0x110(%rsp),%zmm3
 1f82796:	mov    0x20(%rsp),%r11d
 1f8279b:	mov    0x3f0(%rsp),%r10
 1f827a3:	mov    0x2f0(%rsp),%rdx
 1f827ab:	mov    0x18(%rsp),%r9
 1f827b0:	mov    0x38(%rsp),%rdi
 1f827b5:	mov    0x30(%rsp),%ecx
 1f827b9:	or     %rax,%r14
 1f827bc:	xor    %r8d,%r8d
 1f827bf:	jmp    1f826f2 <node_facts_window_run+0x5262>
 1f827c4:	cmp    $0x2,%r13d
 1f827c8:	jne    1f82577 <node_facts_window_run+0x50e7>
 1f827ce:	mov    0xc0(%rsp),%rax
 1f827d6:	vmovdqu64 %zmm3,0x110(%rsp)
 1f827e1:	mov    %r11d,%ebx
 1f827e4:	mov    (%rax),%rax
 1f827e7:	mov    0x6e0(%rax),%rdi
 1f827ee:	mov    0x6e8(%rax),%esi
 1f827f4:	vzeroupper
 1f827f7:	call   1f69cb0 <node_census_cleans>
 1f827fc:	vmovdqu64 0x110(%rsp),%zmm3
 1f82807:	mov    0x3f0(%rsp),%r10
 1f8280f:	mov    0x18(%rsp),%r9
 1f82814:	movzbl %al,%eax
 1f82817:	mov    %ebx,%r11d
 1f8281a:	xor    %r8d,%r8d
 1f8281d:	lea    0x2(,%rax,4),%r13d
 1f82825:	jmp    1f82577 <node_facts_window_run+0x50e7>
 1f8282a:	rdtsc
 1f8282c:	mov    %rdx,0x20(%rsp)
 1f82831:	mov    %rax,0x150(%rsp)
 1f82839:	cmpb   $0x0,0x88(%rsp)
 1f82841:	je     1f829d1 <node_facts_window_run+0x5541>
 1f82847:	mov    0x8(%rsp),%rax
 1f8284c:	cmpl   $0x0,0xa90(%rax)
 1f82853:	je     1f829d1 <node_facts_window_run+0x5541>
 1f82859:	mov    $0xffffffffffffffff,%rdx
 1f82860:	xor    %esi,%esi
 1f82862:	jmp    1f82887 <node_facts_window_run+0x53f7>
 1f82864:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82870:	mov    0x8(%rsp),%rax
 1f82875:	inc    %rsi
 1f82878:	mov    0xa90(%rax),%eax
 1f8287e:	cmp    %rax,%rsi
 1f82881:	jae    1f829d1 <node_facts_window_run+0x5541>
 1f82887:	imul   $0x68,%rsi,%r10
 1f8288b:	cmpb   $0x0,0x61(%rbp,%r10,1)
 1f82891:	je     1f82870 <node_facts_window_run+0x53e0>
 1f82893:	mov    0x8(%rsp),%rax
 1f82898:	add    %rbp,%r10
 1f8289b:	mov    $0x40,%ecx
 1f828a0:	mov    0xa70(%rax),%r8
 1f828a7:	mov    0xa68(%rax),%rdi
 1f828ae:	mov    (%rdi,%rsi,4),%eax
 1f828b1:	mov    (%r8,%rsi,4),%r11d
 1f828b5:	mov    0x10(%r10),%r8
 1f828b9:	sub    0xcd8(%r9),%r8
 1f828c0:	add    0xce0(%r9),%r8
 1f828c7:	mov    %rax,0x10(%rsp)
 1f828cc:	xor    %eax,%eax
 1f828ce:	mov    0x651b8(%r13,%r11,4),%edi
 1f828d6:	cmpl   $0x0,0x18(%r10)
 1f828db:	je     1f82977 <node_facts_window_run+0x54e7>
 1f828e1:	sub    %edi,%r11d
 1f828e4:	mov    %edi,%r13d
 1f828e7:	xor    %r15d,%r15d
 1f828ea:	xor    %r12d,%r12d
 1f828ed:	mov    %edi,%ebp
 1f828ef:	inc    %r11d
 1f828f2:	mov    %r11d,%ebx
 1f828f5:	and    $0x3f,%r11d
 1f828f9:	and    $0xffffffc0,%ebx
 1f828fc:	mov    %r11d,%r14d
 1f828ff:	xor    $0x3f,%r14d
 1f82903:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82910:	mov    0x18(%rsp),%r9
 1f82915:	sub    $0x40,%ebp
 1f82918:	cmovae %ecx,%r13d
 1f8291c:	cmp    %r15d,%edi
 1f8291f:	cmovbe %eax,%r13d
 1f82923:	mov    0xc98(%r9),%r9
 1f8292a:	add    %rbx,%r9
 1f8292d:	cmp    $0x40,%r13d
 1f82931:	shlx   %r13,%rdx,%r13
 1f82936:	shrx   %r11,(%r15,%r9,1),%rax
 1f8293c:	mov    0x40(%r15,%r9,1),%r9
 1f82941:	not    %r13
 1f82944:	cmove  %rdx,%r13
 1f82948:	add    $0x40,%r15
 1f8294c:	add    %r9,%r9
 1f8294f:	shlx   %r14,%r9,%r9
 1f82954:	or     %rax,%r9
 1f82957:	and    %r13,%r9
 1f8295a:	mov    %ebp,%r13d
 1f8295d:	mov    %r9,(%r8,%r12,8)
 1f82961:	mov    0x18(%rsp),%r9
 1f82966:	inc    %r12
 1f82969:	mov    0x18(%r10),%eax
 1f8296d:	cmp    %rax,%r12
 1f82970:	mov    $0x0,%eax
 1f82975:	jb     1f82910 <node_facts_window_run+0x5480>
 1f82977:	mov    0x8(%rsp),%rax
 1f8297c:	mov    0x28(%rsp),%r13
 1f82981:	mov    0x68(%rsp),%rbp
 1f82986:	mov    0x80(%rsp),%r12
 1f8298e:	mov    0xa58(%rax),%r10
 1f82995:	cmp    %edi,(%r10,%rsi,4)
 1f82999:	jbe    1f82870 <node_facts_window_run+0x53e0>
 1f8299f:	mov    0x10(%rsp),%rcx
 1f829a4:	mov    0xc98(%r9),%rax
 1f829ab:	mov    %ecx,%r9d
 1f829ae:	and    $0xffffffc0,%r9d
 1f829b2:	shrx   %rcx,(%rax,%r9,1),%rax
 1f829b8:	mov    0x18(%rsp),%r9
 1f829bd:	and    $0x1,%eax
 1f829c0:	shlx   %rdi,%rax,%rax
 1f829c5:	shr    $0x6,%edi
 1f829c8:	or     %rax,(%r8,%rdi,8)
 1f829cc:	jmp    1f82870 <node_facts_window_run+0x53e0>
 1f829d1:	shlq   $0x20,0xe8(%rsp)
 1f829da:	shlq   $0x20,0x490(%rsp)
 1f829e3:	shlq   $0x20,0x470(%rsp)
 1f829ec:	shlq   $0x20,0x20(%rsp)
 1f829f2:	lea    0x8f0(%rsp),%rdi
 1f829fa:	mov    $0x418,%edx
 1f829ff:	mov    %r12,%rsi
 1f82a02:	vzeroupper
 1f82a05:	call   355ebf0 <memcpy>
 1f82a0a:	mov    0x2b0(%rsp),%rax
 1f82a12:	movb   $0x0,0x5b(%r12)
 1f82a18:	test   %eax,%eax
 1f82a1a:	je     1f82cec <node_facts_window_run+0x585c>
 1f82a20:	mov    0x8(%rsp),%rdi
 1f82a25:	mov    0x18(%rsp),%r9
 1f82a2a:	mov    %eax,%eax
 1f82a2c:	xor    %r15d,%r15d
 1f82a2f:	mov    %rax,0x10(%rsp)
 1f82a34:	jmp    1f82a93 <node_facts_window_run+0x5603>
 1f82a36:	cs nopw 0x0(%rax,%rax,1)
 1f82a40:	movzbl 0x7c0(%rsp),%ecx
 1f82a48:	mov    0x8(%rsp),%rdi
 1f82a4d:	mov    0x18(%rsp),%r9
 1f82a52:	mov    0x68(%rsp),%rbp
 1f82a57:	xor    %edx,%edx
 1f82a59:	add    %rdx,0x8a0(%r8)
 1f82a60:	mov    %rax,0x50(%r12)
 1f82a65:	mov    %cl,0x60(%r12)
 1f82a6a:	mov    0x10(%rsp),%rcx
 1f82a6f:	inc    %r15
 1f82a72:	mov    0x66c(%r9),%eax
 1f82a79:	mov    %eax,0x58(%r12)
 1f82a7e:	mov    0x670(%r9),%eax
 1f82a85:	mov    %eax,0x5c(%r12)
 1f82a8a:	cmp    %r15,%rcx
 1f82a8d:	je     1f82c8d <node_facts_window_run+0x57fd>
 1f82a93:	mov    0xce8(%r9),%rax
 1f82a9a:	mov    0xa68(%rdi),%r8
 1f82aa1:	mov    0xa70(%rdi),%rcx
 1f82aa8:	mov    %r13,%r14
 1f82aab:	mov    (%rax,%r15,4),%r12d
 1f82aaf:	mov    0xa58(%rdi),%rax
 1f82ab6:	mov    (%r8,%r12,4),%ebp
 1f82aba:	mov    (%rcx,%r12,4),%r13d
 1f82abe:	mov    0xa48(%rdi),%r8
 1f82ac5:	mov    0xa50(%rdi),%rcx
 1f82acc:	mov    0x80(%rsp),%rdi
 1f82ad4:	mov    (%rcx,%r12,4),%ebx
 1f82ad8:	mov    (%r8,%r12,4),%esi
 1f82adc:	mov    (%rax,%r12,4),%ecx
 1f82ae0:	mov    %ebx,%edx
 1f82ae2:	call   1f53190 <node_machine_type>
 1f82ae7:	mov    0x8(%rsp),%rax
 1f82aec:	mov    0xa58(%rax),%rax
 1f82af3:	mov    (%rax,%r12,4),%eax
 1f82af7:	cmp    0x651b8(%r14,%r13,4),%eax
 1f82aff:	jbe    1f82b3c <node_facts_window_run+0x56ac>
 1f82b01:	inc    %r13d
 1f82b04:	cmp    %r13d,%ebp
 1f82b07:	je     1f82b3c <node_facts_window_run+0x56ac>
 1f82b09:	mov    0x18(%rsp),%rsi
 1f82b0e:	mov    %r13d,%eax
 1f82b11:	mov    0xc70(%rsi),%rdx
 1f82b18:	mov    0xc88(%rsi),%rcx
 1f82b1f:	mov    0xc80(%rsi),%rsi
 1f82b26:	movzbl (%rdx,%rbp,1),%edi
 1f82b2a:	mov    %dil,(%rdx,%rax,1)
 1f82b2e:	movzbl (%rsi,%rbp,1),%edx
 1f82b32:	mov    %dl,(%rsi,%rax,1)
 1f82b35:	movzbl (%rcx,%rbp,1),%edx
 1f82b39:	mov    %dl,(%rcx,%rax,1)
 1f82b3c:	mov    0x28(%rsp),%r13
 1f82b41:	xor    %r9d,%r9d
 1f82b44:	mov    0xc0(%rsp),%rdx
 1f82b4c:	mov    $0xffffffff,%r8d
 1f82b52:	mov    0x422c(%r13,%rbp,4),%ecx
 1f82b5a:	cmpb   $0x23,0x2c(%r13,%rbp,1)
 1f82b60:	jne    1f82b8d <node_facts_window_run+0x56fd>
 1f82b62:	cmp    0xb8(%rsp),%ecx
 1f82b69:	jae    1f82b8d <node_facts_window_run+0x56fd>
 1f82b6b:	mov    0x338(%rdx),%rax
 1f82b72:	mov    (%rdx),%rsi
 1f82b75:	mov    (%rax,%rcx,4),%r8d
 1f82b79:	cmp    0x764(%rsi),%r8d
 1f82b80:	jae    1f82b8d <node_facts_window_run+0x56fd>
 1f82b82:	mov    0x1e8(%rdx),%rax
 1f82b89:	mov    (%rax,%r8,4),%r9d
 1f82b8d:	imul   $0x68,%r12,%r12
 1f82b91:	add    0x68(%rsp),%r12
 1f82b96:	cmpb   $0x0,0x88(%rsp)
 1f82b9e:	movb   $0x0,0x7c0(%rsp)
 1f82ba6:	je     1f82bd0 <node_facts_window_run+0x5740>
 1f82ba8:	mov    0x18(%rsp),%rdi
 1f82bad:	mov    0x10(%r12),%rax
 1f82bb2:	sub    0xcd8(%rdi),%rax
 1f82bb9:	add    0xce0(%rdi),%rax
 1f82bc0:	jmp    1f82bd7 <node_facts_window_run+0x5747>
 1f82bc2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82bd0:	mov    0x18(%rsp),%rdi
 1f82bd5:	xor    %eax,%eax
 1f82bd7:	movzbl 0x88(%rsp),%edx
 1f82bdf:	mov    %rax,0x608(%rdi)
 1f82be6:	mov    0xd0(%rsp),%rax
 1f82bee:	mov    %ebx,%esi
 1f82bf0:	mov    %dl,0x610(%rdi)
 1f82bf6:	movzbl (%rax,%rbp,1),%edx
 1f82bfa:	push   %r12
 1f82bfc:	lea    0x7c8(%rsp),%rax
 1f82c04:	push   %rax
 1f82c05:	call   1f54a70 <node_census_reader_expression>
 1f82c0a:	add    $0x10,%rsp
 1f82c0e:	cmpb   $0x1,0x62(%r12)
 1f82c14:	mov    0x38(%rsp),%r8
 1f82c19:	adcq   $0x0,0x898(%r8)
 1f82c21:	cmpb   $0x0,0x62(%r12)
 1f82c27:	jne    1f82a40 <node_facts_window_run+0x55b0>
 1f82c2d:	movzbl 0x7c0(%rsp),%ecx
 1f82c35:	mov    0x8(%rsp),%rdi
 1f82c3a:	mov    0x68(%rsp),%rbp
 1f82c3f:	mov    $0x1,%edx
 1f82c44:	cmp    0x50(%r12),%rax
 1f82c49:	jne    1f82c83 <node_facts_window_run+0x57f3>
 1f82c4b:	mov    0x18(%rsp),%r9
 1f82c50:	cmp    0x60(%r12),%cl
 1f82c55:	jne    1f82a59 <node_facts_window_run+0x55c9>
 1f82c5b:	mov    0x66c(%r9),%esi
 1f82c62:	cmp    0x58(%r12),%esi
 1f82c67:	jne    1f82a59 <node_facts_window_run+0x55c9>
 1f82c6d:	mov    0x670(%r9),%esi
 1f82c74:	xor    %edx,%edx
 1f82c76:	cmp    0x5c(%r12),%esi
 1f82c7b:	setne  %dl
 1f82c7e:	jmp    1f82a59 <node_facts_window_run+0x55c9>
 1f82c83:	mov    0x18(%rsp),%r9
 1f82c88:	jmp    1f82a59 <node_facts_window_run+0x55c9>
 1f82c8d:	rdtsc
 1f82c8f:	xor    %ebx,%ebx
 1f82c91:	mov    %rdi,%r15
 1f82c94:	mov    %r9,%r14
 1f82c97:	shl    $0x20,%rdx
 1f82c9b:	or     %rax,%rdx
 1f82c9e:	mov    %rdx,0x30(%rsp)
 1f82ca3:	mov    0x80(%rsp),%r12
 1f82cab:	nopl   0x0(%rax,%rax,1)
 1f82cb0:	mov    0xce8(%r14),%rax
 1f82cb7:	mov    0xa48(%r15),%rcx
 1f82cbe:	mov    0xa50(%r15),%rdx
 1f82cc5:	mov    %r12,%rdi
 1f82cc8:	mov    (%rax,%rbx,4),%eax
 1f82ccb:	mov    (%rcx,%rax,4),%esi
 1f82cce:	mov    0xa58(%r15),%rcx
 1f82cd5:	mov    (%rdx,%rax,4),%edx
 1f82cd8:	mov    (%rcx,%rax,4),%ecx
 1f82cdb:	call   1f53190 <node_machine_type>
 1f82ce0:	inc    %rbx
 1f82ce3:	cmp    %rbx,0x10(%rsp)
 1f82ce8:	jne    1f82cb0 <node_facts_window_run+0x5820>
 1f82cea:	jmp    1f82cfa <node_facts_window_run+0x586a>
 1f82cec:	rdtsc
 1f82cee:	shl    $0x20,%rdx
 1f82cf2:	or     %rax,%rdx
 1f82cf5:	mov    %rdx,0x30(%rsp)
 1f82cfa:	mov    0xe8(%rsp),%rax
 1f82d02:	lea    0x8f0(%rsp),%rsi
 1f82d0a:	mov    %r12,%rdi
 1f82d0d:	or     %rax,0xf0(%rsp)
 1f82d15:	mov    0x490(%rsp),%rax
 1f82d1d:	or     %rax,0x780(%rsp)
 1f82d25:	rdtsc
 1f82d27:	mov    0x470(%rsp),%rcx
 1f82d2f:	shl    $0x20,%rdx
 1f82d33:	or     %rcx,0x740(%rsp)
 1f82d3b:	mov    0x20(%rsp),%rcx
 1f82d40:	or     %rcx,0x150(%rsp)
 1f82d48:	or     %rax,%rdx
 1f82d4b:	mov    %rdx,0x110(%rsp)
 1f82d53:	mov    $0x418,%edx
 1f82d58:	call   355ebf0 <memcpy>
 1f82d5d:	mov    0x8(%rsp),%r11
 1f82d62:	cmpl   $0x0,0xa90(%r11)
 1f82d6a:	je     1f82fde <node_facts_window_run+0x5b4e>
 1f82d70:	xorb   $0x1,0x88(%rsp)
 1f82d78:	add    $0x62,%rbp
 1f82d7c:	xor    %r14d,%r14d
 1f82d7f:	xor    %eax,%eax
 1f82d81:	mov    0x38(%rsp),%r8
 1f82d86:	mov    0x18(%rsp),%rdi
 1f82d8b:	jmp    1f82dad <node_facts_window_run+0x591d>
 1f82d8d:	nopl   (%rax)
 1f82d90:	mov    %rax,%r15
 1f82d93:	mov    0xa90(%r11),%ecx
 1f82d9a:	inc    %r14
 1f82d9d:	add    $0x68,%rbp
 1f82da1:	mov    %r15,%rax
 1f82da4:	cmp    %rcx,%r14
 1f82da7:	jae    1f82fe6 <node_facts_window_run+0x5b56>
 1f82dad:	cmpb   $0x0,-0x1(%rbp)
 1f82db1:	je     1f82d90 <node_facts_window_run+0x5900>
 1f82db3:	xor    %edx,%edx
 1f82db5:	cmpb   $0x0,0x0(%rbp)
 1f82db9:	mov    0xa70(%r11),%rcx
 1f82dc0:	sete   %dl
 1f82dc3:	mov    (%rcx,%r14,4),%ecx
 1f82dc7:	add    %rdx,0x890(%r8)
 1f82dce:	and    0x88(%rsp),%dl
 1f82dd5:	movzbl %dl,%edx
 1f82dd8:	add    %rdx,0x690(%r8)
 1f82ddf:	cmp    $0x1,%dl
 1f82de2:	jne    1f82e00 <node_facts_window_run+0x5970>
 1f82de4:	mov    0xa58(%r11),%rdx
 1f82deb:	mov    (%rdx,%r14,4),%edx
 1f82def:	jmp    1f82e02 <node_facts_window_run+0x5972>
 1f82df1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82e00:	xor    %edx,%edx
 1f82e02:	add    %rdx,0x698(%r8)
 1f82e09:	mov    0xa58(%r11),%rdx
 1f82e10:	mov    (%rdx,%r14,4),%edx
 1f82e14:	cmp    0x651b8(%r13,%rcx,4),%edx
 1f82e1c:	jbe    1f82e40 <node_facts_window_run+0x59b0>
 1f82e1e:	mov    0xa68(%r11),%rdx
 1f82e25:	inc    %ecx
 1f82e27:	xor    %r15d,%r15d
 1f82e2a:	cmp    %ecx,(%rdx,%r14,4)
 1f82e2e:	setne  %r15b
 1f82e32:	jmp    1f82e43 <node_facts_window_run+0x59b3>
 1f82e34:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82e40:	xor    %r15d,%r15d
 1f82e43:	mov    0xa50(%r11),%rcx
 1f82e4a:	mov    0x240(%r8),%rdx
 1f82e51:	mov    (%rcx,%r14,4),%ebx
 1f82e55:	mov    (%rdx,%rbx,8),%r12
 1f82e59:	cmp    %r12,-0x12(%rbp)
 1f82e5d:	jne    1f82e90 <node_facts_window_run+0x5a00>
 1f82e5f:	mov    0x248(%r8),%rdx
 1f82e66:	movzbl -0x2(%rbp),%ecx
 1f82e6a:	cmp    (%rdx,%rbx,1),%cl
 1f82e6d:	jne    1f82e90 <node_facts_window_run+0x5a00>
 1f82e6f:	mov    0xcb0(%rdi),%rdx
 1f82e76:	mov    -0xa(%rbp),%ecx
 1f82e79:	cmp    (%rdx,%rbx,4),%ecx
 1f82e7c:	jne    1f82e90 <node_facts_window_run+0x5a00>
 1f82e7e:	mov    0xcb8(%rdi),%rdx
 1f82e85:	mov    -0x6(%rbp),%ecx
 1f82e88:	cmp    (%rdx,%rbx,4),%ecx
 1f82e8b:	sete   %cl
 1f82e8e:	jmp    1f82e92 <node_facts_window_run+0x5a02>
 1f82e90:	xor    %ecx,%ecx
 1f82e92:	incq   0xa50(%r8)
 1f82e99:	add    %rax,%r15
 1f82e9c:	mov    %ecx,%edx
 1f82e9e:	mov    0xa58(%r11),%rax
 1f82ea5:	xor    $0x1,%dl
 1f82ea8:	vmovd  (%rax,%r14,4),%xmm0
 1f82eae:	movzbl %dl,%eax
 1f82eb1:	vmovd  %eax,%xmm1
 1f82eb5:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f82eb9:	vpaddq 0xa58(%r8),%xmm0,%xmm0
 1f82ec2:	vmovdqu %xmm0,0xa58(%r8)
 1f82ecb:	test   %cl,%cl
 1f82ecd:	jne    1f82d93 <node_facts_window_run+0x5903>
 1f82ed3:	mov    0x12e4(%r8),%eax
 1f82eda:	cmp    0x50059c4(%rip),%eax        # 6f888a4 <node_census_list>
 1f82ee0:	jae    1f82d93 <node_facts_window_run+0x5903>
 1f82ee6:	inc    %eax
 1f82ee8:	xor    %esi,%esi
 1f82eea:	mov    %eax,0x12e4(%r8)
 1f82ef1:	mov    0xa68(%r11),%rcx
 1f82ef8:	mov    (%rdi),%rax
 1f82efb:	mov    (%rcx,%r14,4),%ecx
 1f82eff:	mov    0x18(%rax),%rax
 1f82f03:	mov    0x422c(%r13,%rcx,4),%ecx
 1f82f0b:	cmp    0x78(%rax),%ecx
 1f82f0e:	jae    1f82f53 <node_facts_window_run+0x5ac3>
 1f82f10:	mov    0x68(%rax),%rax
 1f82f14:	mov    0x8(%rdi),%rdi
 1f82f18:	mov    (%rax,%rcx,4),%eax
 1f82f1b:	cmp    0x1538(%rdi),%eax
 1f82f21:	jae    1f82f53 <node_facts_window_run+0x5ac3>
 1f82f23:	mov    0x1530(%rdi),%rcx
 1f82f2a:	test   %rcx,%rcx
 1f82f2d:	je     1f82f53 <node_facts_window_run+0x5ac3>
 1f82f2f:	mov    (%rcx,%rax,4),%esi
 1f82f32:	lea    0x7c0(%rsp),%rdx
 1f82f3a:	lea    0x5b0(%rsp),%rcx
 1f82f42:	call   111f9b0 <pp_presumed>
 1f82f47:	mov    0x38(%rsp),%r8
 1f82f4c:	mov    0x8(%rsp),%r11
 1f82f51:	mov    %eax,%esi
 1f82f53:	mov    0xa58(%r11),%rax
 1f82f5a:	mov    -0x12(%rbp),%rcx
 1f82f5e:	movzbl -0x2(%rbp),%r9d
 1f82f63:	mov    -0x6(%rbp),%r10d
 1f82f67:	mov    %rbp,%r11
 1f82f6a:	mov    (%rax,%r14,4),%edx
 1f82f6e:	mov    0x248(%r8),%rax
 1f82f75:	movzbl (%rax,%rbx,1),%eax
 1f82f79:	mov    %rax,0x10(%rsp)
 1f82f7e:	mov    -0xa(%rbp),%eax
 1f82f81:	mov    %rax,0x20(%rsp)
 1f82f86:	mov    0x18(%rsp),%r13
 1f82f8b:	mov    0xcb0(%r13),%rax
 1f82f92:	mov    0xcb8(%r13),%rdi
 1f82f99:	mov    (%rax,%rbx,4),%ebp
 1f82f9c:	mov    (%rdi,%rbx,4),%ebx
 1f82f9f:	sub    $0x8,%rsp
 1f82fa3:	lea    -0x196218a(%rip),%rdi        # 620e20 <.str.11115>
 1f82faa:	mov    %r12,%r8
 1f82fad:	xor    %eax,%eax
 1f82faf:	push   %rbx
 1f82fb0:	push   %rbp
 1f82fb1:	mov    %r11,%rbp
 1f82fb4:	push   %r10
 1f82fb6:	push   0x40(%rsp)
 1f82fba:	push   0x38(%rsp)
 1f82fbe:	call   34ef310 <_IO_printf>
 1f82fc3:	mov    0x68(%rsp),%r8
 1f82fc8:	mov    0x38(%rsp),%r11
 1f82fcd:	mov    %r13,%rdi
 1f82fd0:	add    $0x30,%rsp
 1f82fd4:	mov    0x28(%rsp),%r13
 1f82fd9:	jmp    1f82d93 <node_facts_window_run+0x5903>
 1f82fde:	mov    0x38(%rsp),%r8
 1f82fe3:	xor    %r15d,%r15d
 1f82fe6:	vpmovsxbq -0x1acc2a8(%rip),%xmm0        # 4b6d47 <abi_test_hex.digits+0xb9c7>
 1f82fef:	vmovd  0x8(%r13),%xmm2
 1f82ff5:	mov    0x30(%rsp),%rcx
 1f82ffa:	mov    0x110(%rsp),%r9
 1f83002:	mov    0x150(%rsp),%rdi
 1f8300a:	vmovq  %r15,%xmm1
 1f8300f:	xor    %eax,%eax
 1f83011:	mov    0x780(%rsp),%rdx
 1f83019:	mov    0x740(%rsp),%rsi
 1f83021:	mov    0xc8(%rsp),%r15
 1f83029:	sub    %rcx,%r9
 1f8302c:	sub    %rdi,%rcx
 1f8302f:	sub    %r9,%rcx
 1f83032:	cmovae %rcx,%rax
 1f83036:	mov    0xf0(%rsp),%rcx
 1f8303e:	sub    %rdx,%rsi
 1f83041:	vpinsrq $0x0,%r9,%xmm0,%xmm0
 1f83047:	vpunpcklqdq %xmm1,%xmm2,%xmm1
 1f8304b:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f83051:	vpaddq 0xa98(%r8),%ymm0,%ymm0
 1f8305a:	vmovq  %rsi,%xmm1
 1f8305f:	sub    %rcx,%rdi
 1f83062:	sub    %rcx,%rdx
 1f83065:	add    %rax,%rdi
 1f83068:	vmovq  %rdx,%xmm2
 1f8306d:	vmovdqu %ymm0,0xa98(%r8)
 1f83076:	vmovq  %rax,%xmm0
 1f8307b:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f8307f:	vmovq  %rdi,%xmm1
 1f83084:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f83088:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f8308e:	vpaddq 0xa68(%r8),%ymm0,%ymm0
 1f83097:	vmovdqu %ymm0,0xa68(%r8)
 1f830a0:	cmpq   $0x0,0xb40(%r11)
 1f830a8:	je     1f84d90 <node_facts_window_run+0x7900>
 1f830ae:	mov    0x940(%r11),%r12
 1f830b5:	mov    0x8(%r13),%ebx
 1f830b9:	rdtsc
 1f830bb:	lea    0x8f0(%rsp),%rcx
 1f830c3:	vpxor  %xmm0,%xmm0,%xmm0
 1f830c7:	vmovdqu64 %zmm0,0x910(%rsp)
 1f830d2:	vmovdqu64 %zmm0,0x8f0(%rsp)
 1f830dd:	mov    %r11,%rdi
 1f830e0:	mov    %r13,%rsi
 1f830e3:	shl    $0x20,%rdx
 1f830e7:	or     %rax,%rdx
 1f830ea:	mov    %rdx,0x68(%rsp)
 1f830ef:	mov    %ebx,%edx
 1f830f1:	vzeroupper
 1f830f4:	call   1f93d80 <node_contexts_window_loop>
 1f830f9:	vmovups 0x918(%rsp),%ymm0
 1f83102:	vmovdqu 0x918(%rsp),%xmm1
 1f8310b:	mov    %r13,%rsi
 1f8310e:	vmovups %ymm0,0x230(%rsp)
 1f83117:	vpbroadcastq 0x928(%rsp),%ymm0
 1f83121:	mov    0x8(%rsp),%rax
 1f83126:	vpsubq %xmm0,%xmm1,%xmm0
 1f8312a:	vpaddq 0x928(%rsp),%xmm0,%xmm0
 1f83133:	vpblendd $0xc,%xmm0,%xmm1,%xmm0
 1f83139:	vmovdqu %xmm0,0xc08(%rax)
 1f83141:	rdtsc
 1f83143:	shl    $0x20,%rdx
 1f83147:	or     %rax,%rdx
 1f8314a:	mov    %rdx,0x38(%rsp)
 1f8314f:	mov    %ebx,%edx
 1f83151:	mov    0x8(%rsp),%rdi
 1f83156:	vzeroupper
 1f83159:	call   1f95d30 <node_contexts_window_targets>
 1f8315e:	rdtsc
 1f83160:	mov    %r13,%rsi
 1f83163:	shl    $0x20,%rdx
 1f83167:	or     %rax,%rdx
 1f8316a:	mov    %rdx,0xd0(%rsp)
 1f83172:	mov    0x8(%rsp),%rdi
 1f83177:	call   1f960c0 <node_contexts_window_part>
 1f8317c:	rdtsc
 1f8317e:	lea    0x7c0(%rsp),%rcx
 1f83186:	vpxor  %xmm0,%xmm0,%xmm0
 1f8318a:	vmovdqu64 %zmm0,0x7e0(%rsp)
 1f83195:	vmovdqu64 %zmm0,0x7c0(%rsp)
 1f8319d:	mov    %r13,%rsi
 1f831a0:	shl    $0x20,%rdx
 1f831a4:	or     %rax,%rdx
 1f831a7:	mov    %rdx,0x80(%rsp)
 1f831af:	mov    %ebx,%edx
 1f831b1:	mov    0x8(%rsp),%rdi
 1f831b6:	vzeroupper
 1f831b9:	call   1f93d80 <node_contexts_window_loop>
 1f831be:	rdtsc
 1f831c0:	mov    %r13,%rsi
 1f831c3:	shl    $0x20,%rdx
 1f831c7:	or     %rax,%rdx
 1f831ca:	mov    %rdx,0xc0(%rsp)
 1f831d2:	mov    %ebx,%edx
 1f831d4:	mov    0x8(%rsp),%rdi
 1f831d9:	call   1f95d30 <node_contexts_window_targets>
 1f831de:	rdtsc
 1f831e0:	mov    %r13,%rsi
 1f831e3:	shl    $0x20,%rdx
 1f831e7:	or     %rax,%rdx
 1f831ea:	mov    %rdx,0xb8(%rsp)
 1f831f2:	mov    0x8(%rsp),%rdi
 1f831f7:	call   1f960c0 <node_contexts_window_part>
 1f831fc:	mov    0x8(%rsp),%r11
 1f83201:	rdtsc
 1f83203:	shl    $0x20,%rdx
 1f83207:	or     %rax,%rdx
 1f8320a:	cmpl   $0x0,0xa90(%r11)
 1f83212:	mov    %rdx,0x1b0(%rsp)
 1f8321a:	mov    %rbx,0x1f0(%rsp)
 1f83222:	je     1f83776 <node_facts_window_run+0x62e6>
 1f83228:	vpbroadcastq -0x19b4d29(%rip),%xmm0        # 5ce508 <.LCPI3_1>
 1f83231:	xor    %ebx,%ebx
 1f83233:	xor    %edi,%edi
 1f83235:	mov    %r12,0x150(%rsp)
 1f8323d:	jmp    1f83261 <node_facts_window_run+0x5dd1>
 1f8323f:	mov    0x8(%rsp),%r11
 1f83244:	xor    %esi,%esi
 1f83246:	incq   0x12e8(%r12,%rsi,8)
 1f8324e:	mov    0xa90(%r11),%eax
 1f83255:	inc    %rdi
 1f83258:	cmp    %rax,%rdi
 1f8325b:	jae    1f83778 <node_facts_window_run+0x62e8>
 1f83261:	mov    0xb80(%r11),%rax
 1f83268:	movzbl (%rax,%rdi,1),%r8d
 1f8326d:	test   %r8b,%r8b
 1f83270:	je     1f8324e <node_facts_window_run+0x5dbe>
 1f83272:	mov    0xa70(%r11),%rcx
 1f83279:	mov    0xa68(%r11),%rax
 1f83280:	mov    (%rcx,%rdi,4),%ecx
 1f83283:	mov    (%rax,%rdi,4),%ebp
 1f83286:	mov    0x651b8(%r13,%rcx,4),%esi
 1f8328e:	incq   0xab8(%r12)
 1f83296:	mov    0xa58(%r11),%rax
 1f8329d:	mov    (%rax,%rdi,4),%eax
 1f832a0:	add    %rax,0xac0(%r12)
 1f832a8:	cmp    $0x1,%r8b
 1f832ac:	jne    1f83300 <node_facts_window_run+0x5e70>
 1f832ae:	mov    0xa58(%r11),%rax
 1f832b5:	mov    (%rax,%rdi,4),%r10d
 1f832b9:	test   %r10d,%r10d
 1f832bc:	je     1f83244 <node_facts_window_run+0x5db4>
 1f832be:	mov    0xbe8(%r11),%rax
 1f832c5:	sub    %esi,%ecx
 1f832c7:	xor    %r11d,%r11d
 1f832ca:	inc    %ecx
 1f832cc:	nopl   0x0(%rax)
 1f832d0:	lea    (%rcx,%r11,1),%r9d
 1f832d4:	cmp    %esi,%r11d
 1f832d7:	cmovae %ebp,%r9d
 1f832db:	mov    %r9d,%edx
 1f832de:	shr    $0x3,%edx
 1f832e1:	and    $0xfffffff8,%edx
 1f832e4:	mov    0x10(%rax,%rdx,8),%r8
 1f832e9:	bt     %r9,%r8
 1f832ed:	jb     1f83382 <node_facts_window_run+0x5ef2>
 1f832f3:	inc    %r11d
 1f832f6:	cmp    %r11d,%r10d
 1f832f9:	jne    1f832d0 <node_facts_window_run+0x5e40>
 1f832fb:	jmp    1f8323f <node_facts_window_run+0x5daf>
 1f83300:	mov    0xa58(%r11),%rcx
 1f83307:	mov    0xb68(%r11),%rdx
 1f8330e:	cmp    $0x3,%r8b
 1f83312:	sete   %al
 1f83315:	mov    (%rcx,%rdi,4),%r9d
 1f83319:	movzbl (%rdx,%rdi,1),%r10d
 1f8331e:	test   %r9,%r9
 1f83321:	sete   %cl
 1f83324:	cmp    $0x2,%r10b
 1f83328:	sete   %dl
 1f8332b:	or     %al,%dl
 1f8332d:	or     %cl,%dl
 1f8332f:	je     1f83339 <node_facts_window_run+0x5ea9>
 1f83331:	xor    %r14d,%r14d
 1f83334:	jmp    1f83687 <node_facts_window_run+0x61f7>
 1f83339:	mov    0xa70(%r11),%rdx
 1f83340:	mov    0xa68(%r11),%rax
 1f83347:	mov    %rbp,0x20(%rsp)
 1f8334c:	mov    %r13,%rcx
 1f8334f:	mov    0xbe8(%r11),%r12
 1f83356:	mov    %rbx,0x10(%rsp)
 1f8335b:	mov    (%rdx,%rdi,4),%edx
 1f8335e:	mov    (%rax,%rdi,4),%r13d
 1f83362:	mov    0xb48(%r11),%rax
 1f83369:	mov    0x651b8(%rcx,%rdx,4),%ebp
 1f83370:	sub    %ebp,%edx
 1f83372:	cmp    $0x1,%r9d
 1f83376:	jne    1f833d2 <node_facts_window_run+0x5f42>
 1f83378:	xor    %r14d,%r14d
 1f8337b:	xor    %ebx,%ebx
 1f8337d:	jmp    1f835d7 <node_facts_window_run+0x6147>
 1f83382:	mov    0x8(%rsp),%r11
 1f83387:	mov    %r9d,%esi
 1f8338a:	mov    0xbd0(%r11),%rcx
 1f83391:	movzbl (%rcx,%rsi,1),%ecx
 1f83395:	mov    $0x1,%esi
 1f8339a:	cmp    $0xd,%ecx
 1f8339d:	je     1f83246 <node_facts_window_run+0x5db6>
 1f833a3:	lea    -0xf(%rcx),%r8d
 1f833a7:	mov    $0x2,%esi
 1f833ac:	cmp    $0x2,%r8b
 1f833b0:	jb     1f83246 <node_facts_window_run+0x5db6>
 1f833b6:	cmp    $0xe,%ecx
 1f833b9:	je     1f83730 <node_facts_window_run+0x62a0>
 1f833bf:	cmp    $0x11,%ecx
 1f833c2:	jne    1f8373a <node_facts_window_run+0x62aa>
 1f833c8:	mov    $0x4,%esi
 1f833cd:	jmp    1f83246 <node_facts_window_run+0x5db6>
 1f833d2:	mov    %r9d,%ecx
 1f833d5:	and    $0xfffffffe,%ecx
 1f833d8:	mov    %r10b,0x110(%rsp)
 1f833e0:	mov    %r8b,0x30(%rsp)
 1f833e5:	mov    %r9,0x88(%rsp)
 1f833ed:	xor    %r14d,%r14d
 1f833f0:	xor    %r15d,%r15d
 1f833f3:	mov    %ecx,0x18(%rsp)
 1f833f7:	mov    %rdx,0x50(%rsp)
 1f833fc:	add    $0x2,%edx
 1f833ff:	jmp    1f8342a <node_facts_window_run+0x5f9a>
 1f83401:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f83410:	xor    %r11d,%r11d
 1f83413:	add    %r10,%r14
 1f83416:	add    $0x2,%edx
 1f83419:	inc    %r15d
 1f8341c:	add    %r11,%r14
 1f8341f:	cmp    0x18(%rsp),%r15d
 1f83424:	je     1f83575 <node_facts_window_run+0x60e5>
 1f8342a:	mov    %r15d,%ebx
 1f8342d:	lea    -0x1(%rdx),%r15d
 1f83431:	cmp    %ebp,%ebx
 1f83433:	mov    $0x1,%r11d
 1f83439:	mov    $0x1,%r10d
 1f8343f:	cmovae %r13d,%r15d
 1f83443:	mov    %r15d,%esi
 1f83446:	and    $0xffffffc0,%esi
 1f83449:	movzbl (%rax,%r15,1),%r8d
 1f8344e:	shrx   %r15,(%r12,%rsi,1),%rsi
 1f83454:	and    $0x1,%r8d
 1f83458:	mov    %esi,%r9d
 1f8345b:	and    $0x1,%r9d
 1f8345f:	cmp    %r8d,%r9d
 1f83462:	jne    1f834d3 <node_facts_window_run+0x6043>
 1f83464:	test   $0x1,%sil
 1f83468:	je     1f834d0 <node_facts_window_run+0x6040>
 1f8346a:	mov    0x8(%rsp),%rcx
 1f8346f:	mov    0xbb0(%rcx),%r8
 1f83476:	mov    0xb58(%rcx),%rsi
 1f8347d:	movzbl (%r8,%r15,1),%r8d
 1f83482:	cmp    (%rsi,%r15,1),%r8b
 1f83486:	jne    1f834d3 <node_facts_window_run+0x6043>
 1f83488:	mov    0x8(%rsp),%rcx
 1f8348d:	mov    0xbc0(%rcx),%r8
 1f83494:	mov    0xb50(%rcx),%rsi
 1f8349b:	movzbl (%r8,%r15,1),%r8d
 1f834a0:	cmp    (%rsi,%r15,1),%r8b
 1f834a4:	jne    1f834d3 <node_facts_window_run+0x6043>
 1f834a6:	mov    0x8(%rsp),%rcx
 1f834ab:	xor    %r10d,%r10d
 1f834ae:	mov    0xbd8(%rcx),%r8
 1f834b5:	mov    0xb60(%rcx),%rsi
 1f834bc:	mov    (%r8,%r15,4),%r8d
 1f834c0:	cmp    (%rsi,%r15,4),%r8d
 1f834c4:	setne  %r10b
 1f834c8:	jmp    1f834d3 <node_facts_window_run+0x6043>
 1f834ca:	nopw   0x0(%rax,%rax,1)
 1f834d0:	xor    %r10d,%r10d
 1f834d3:	lea    0x1(%rbx),%r15d
 1f834d7:	mov    %r13d,%esi
 1f834da:	cmp    %ebp,%r15d
 1f834dd:	cmovb  %edx,%esi
 1f834e0:	mov    %esi,%r8d
 1f834e3:	and    $0xffffffc0,%r8d
 1f834e7:	movzbl (%rax,%rsi,1),%r9d
 1f834ec:	shrx   %rsi,(%r12,%r8,1),%r8
 1f834f2:	and    $0x1,%r9d
 1f834f6:	mov    %r8d,%ecx
 1f834f9:	and    $0x1,%ecx
 1f834fc:	cmp    %r9d,%ecx
 1f834ff:	jne    1f83413 <node_facts_window_run+0x5f83>
 1f83505:	test   $0x1,%r8b
 1f83509:	je     1f83410 <node_facts_window_run+0x5f80>
 1f8350f:	mov    0x8(%rsp),%r9
 1f83514:	mov    0xbb0(%r9),%r8
 1f8351b:	mov    0xb58(%r9),%rcx
 1f83522:	movzbl (%r8,%rsi,1),%r8d
 1f83527:	cmp    (%rcx,%rsi,1),%r8b
 1f8352b:	jne    1f83413 <node_facts_window_run+0x5f83>
 1f83531:	mov    0xbc0(%r9),%r8
 1f83538:	mov    0xb50(%r9),%rcx
 1f8353f:	movzbl (%r8,%rsi,1),%r8d
 1f83544:	cmp    (%rcx,%rsi,1),%r8b
 1f83548:	jne    1f83413 <node_facts_window_run+0x5f83>
 1f8354e:	mov    0x8(%rsp),%r8
 1f83553:	xor    %r11d,%r11d
 1f83556:	mov    0xb60(%r8),%rcx
 1f8355d:	mov    0xbd8(%r8),%r8
 1f83564:	mov    (%r8,%rsi,4),%r8d
 1f83568:	cmp    (%rcx,%rsi,4),%r8d
 1f8356c:	setne  %r11b
 1f83570:	jmp    1f83413 <node_facts_window_run+0x5f83>
 1f83575:	mov    0x88(%rsp),%r9
 1f8357d:	mov    0xc8(%rsp),%r15
 1f83585:	test   $0x1,%r9b
 1f83589:	jne    1f835bb <node_facts_window_run+0x612b>
 1f8358b:	mov    0x8(%rsp),%r11
 1f83590:	mov    0x28(%rsp),%r13
 1f83595:	mov    0x150(%rsp),%r12
 1f8359d:	mov    0x10(%rsp),%rbx
 1f835a2:	mov    0x20(%rsp),%rbp
 1f835a7:	movzbl 0x30(%rsp),%r8d
 1f835ad:	movzbl 0x110(%rsp),%r10d
 1f835b6:	jmp    1f83687 <node_facts_window_run+0x61f7>
 1f835bb:	mov    0x8(%rsp),%r11
 1f835c0:	movzbl 0x30(%rsp),%r8d
 1f835c6:	movzbl 0x110(%rsp),%r10d
 1f835cf:	mov    0x50(%rsp),%rdx
 1f835d4:	add    $0x2,%ebx
 1f835d7:	inc    %edx
 1f835d9:	add    %ebx,%edx
 1f835db:	cmp    %ebp,%ebx
 1f835dd:	cmovb  %edx,%r13d
 1f835e1:	mov    %r13d,%ecx
 1f835e4:	and    $0xffffffc0,%ecx
 1f835e7:	movzbl (%rax,%r13,1),%edx
 1f835ec:	mov    $0x1,%eax
 1f835f1:	shrx   %r13,(%r12,%rcx,1),%rcx
 1f835f7:	and    $0x1,%edx
 1f835fa:	mov    %ecx,%esi
 1f835fc:	and    $0x1,%esi
 1f835ff:	cmp    %edx,%esi
 1f83601:	jne    1f83669 <node_facts_window_run+0x61d9>
 1f83603:	mov    0x150(%rsp),%r12
 1f8360b:	mov    0x10(%rsp),%rbx
 1f83610:	mov    0x20(%rsp),%rbp
 1f83615:	test   $0x1,%cl
 1f83618:	je     1f8367d <node_facts_window_run+0x61ed>
 1f8361a:	mov    0xbb0(%r11),%rdx
 1f83621:	mov    0xb58(%r11),%rcx
 1f83628:	movzbl (%rdx,%r13,1),%edx
 1f8362d:	cmp    (%rcx,%r13,1),%dl
 1f83631:	jne    1f8367f <node_facts_window_run+0x61ef>
 1f83633:	mov    0xbc0(%r11),%rdx
 1f8363a:	mov    0xb50(%r11),%rcx
 1f83641:	movzbl (%rdx,%r13,1),%edx
 1f83646:	cmp    (%rcx,%r13,1),%dl
 1f8364a:	jne    1f8367f <node_facts_window_run+0x61ef>
 1f8364c:	mov    0xbd8(%r11),%rax
 1f83653:	mov    0xb60(%r11),%rcx
 1f8365a:	mov    (%rax,%r13,4),%edx
 1f8365e:	xor    %eax,%eax
 1f83660:	cmp    (%rcx,%r13,4),%edx
 1f83664:	setne  %al
 1f83667:	jmp    1f8367f <node_facts_window_run+0x61ef>
 1f83669:	mov    0x150(%rsp),%r12
 1f83671:	mov    0x10(%rsp),%rbx
 1f83676:	mov    0x20(%rsp),%rbp
 1f8367b:	jmp    1f8367f <node_facts_window_run+0x61ef>
 1f8367d:	xor    %eax,%eax
 1f8367f:	mov    0x28(%rsp),%r13
 1f83684:	add    %rax,%r14
 1f83687:	cmp    $0x2,%r10b
 1f8368b:	sete   %al
 1f8368e:	cmp    $0x3,%r8b
 1f83692:	sete   %cl
 1f83695:	xor    %cl,%al
 1f83697:	test   %r14,%r14
 1f8369a:	vmovd  %ecx,%xmm1
 1f8369e:	setne  %dl
 1f836a1:	incq   0xac8(%r12)
 1f836a9:	add    %r9,%rbx
 1f836ac:	or     %al,%dl
 1f836ae:	vpinsrb $0x1,%edx,%xmm1,%xmm1
 1f836b4:	vpmovzxbq %xmm1,%xmm1
 1f836b9:	vptestmq %xmm0,%xmm1,%k0
 1f836bf:	vmovdqu 0xad8(%r12),%xmm1
 1f836c9:	vpmovm2q %k0,%xmm2
 1f836cf:	vpsubq %xmm2,%xmm1,%xmm1
 1f836d3:	vmovdqu %xmm1,0xad8(%r12)
 1f836dd:	add    %r14,0xae8(%r12)
 1f836e5:	mov    0xb78(%r11),%rax
 1f836ec:	mov    (%rax,%rdi,8),%rax
 1f836f0:	add    %rax,0xb30(%r12)
 1f836f8:	cmp    $0x1,%dl
 1f836fb:	jne    1f8324e <node_facts_window_run+0x5dbe>
 1f83701:	mov    0x1368(%r12),%eax
 1f83709:	cmp    $0xf,%rax
 1f8370d:	ja     1f8324e <node_facts_window_run+0x5dbe>
 1f83713:	mov    0x422c(%r13,%rbp,4),%ecx
 1f8371b:	mov    %ecx,0x1328(%r12,%rax,4)
 1f83723:	incl   0x1368(%r12)
 1f8372b:	jmp    1f8324e <node_facts_window_run+0x5dbe>
 1f83730:	mov    $0x3,%esi
 1f83735:	jmp    1f83246 <node_facts_window_run+0x5db6>
 1f8373a:	mov    $0x1,%esi
 1f8373f:	shlx   %r9,%rsi,%r8
 1f83744:	mov    $0x5,%esi
 1f83749:	test   %r8,0x18(%rax,%rdx,8)
 1f8374e:	jne    1f83246 <node_facts_window_run+0x5db6>
 1f83754:	mov    $0x6,%esi
 1f83759:	test   %r8,0x20(%rax,%rdx,8)
 1f8375e:	jne    1f83246 <node_facts_window_run+0x5db6>
 1f83764:	xor    %eax,%eax
 1f83766:	cmp    $0x7,%ecx
 1f83769:	setne  %al
 1f8376c:	lea    0x2(%rax,%rax,4),%rsi
 1f83771:	jmp    1f83246 <node_facts_window_run+0x5db6>
 1f83776:	xor    %ebx,%ebx
 1f83778:	add    %rbx,0xad0(%r12)
 1f83780:	mov    0x80(%rsp),%rdx
 1f83788:	mov    0xd0(%rsp),%rsi
 1f83790:	mov    0x38(%rsp),%rcx
 1f83795:	vmovd  0x1f0(%rsp),%xmm4
 1f8379e:	vmovdqu 0xb78(%r12),%xmm0
 1f837a8:	vmovq  0x910(%rsp),%xmm1
 1f837b1:	vpaddq 0x938(%rsp),%xmm0,%xmm0
 1f837ba:	vmovdqu %xmm0,0xb78(%r12)
 1f837c4:	mov    0x948(%rsp),%rax
 1f837cc:	add    %rax,0xb88(%r12)
 1f837d4:	mov    %rdx,%rax
 1f837d7:	sub    %rsi,%rax
 1f837da:	sub    %rcx,%rsi
 1f837dd:	sub    0x68(%rsp),%rcx
 1f837e2:	vmovdqu64 0x8f0(%rsp),%zmm0
 1f837ed:	vmovq  %rax,%xmm2
 1f837f2:	vmovq  %rsi,%xmm3
 1f837f7:	mov    0x1b0(%rsp),%rsi
 1f837ff:	mov    0xc0(%rsp),%rax
 1f83807:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f8380b:	vmovq  %rcx,%xmm3
 1f83810:	mov    0xb8(%rsp),%rcx
 1f83818:	vpunpcklqdq %xmm3,%xmm4,%xmm3
 1f8381c:	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
 1f83822:	vshufi64x2 $0x44,%zmm2,%zmm0,%zmm0
 1f83829:	vpaddq 0xaf0(%r12),%zmm0,%zmm0
 1f83834:	sub    %rcx,%rsi
 1f83837:	sub    %rax,%rcx
 1f8383a:	sub    %rdx,%rax
 1f8383d:	vmovq  %rsi,%xmm3
 1f83842:	vmovq  %rax,%xmm2
 1f83847:	vpunpcklqdq %xmm1,%xmm3,%xmm1
 1f8384b:	vmovdqu64 %zmm0,0xaf0(%r12)
 1f83856:	vmovq  %rcx,%xmm0
 1f8385b:	vpunpcklqdq %xmm0,%xmm2,%xmm0
 1f8385f:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f83865:	vinserti64x4 $0x1,0x230(%rsp),%zmm0,%zmm0
 1f83871:	vpaddq 0xb38(%r12),%zmm0,%zmm0
 1f8387c:	vmovdqu64 %zmm0,0xb38(%r12)
 1f83887:	cmpq   $0x0,0xc20(%r11)
 1f8388f:	je     1f84d90 <node_facts_window_run+0x7900>
 1f83895:	mov    0x8(%r13),%r15d
 1f83899:	mov    0x940(%r11),%r14
 1f838a0:	vpxor  %xmm0,%xmm0,%xmm0
 1f838a4:	vmovdqu %ymm0,0x8f0(%rsp)
 1f838ad:	movq   $0x0,0x910(%rsp)
 1f838b9:	rdtsc
 1f838bb:	mov    %r11,%rdi
 1f838be:	mov    %rdx,0x430(%rsp)
 1f838c6:	lea    0x8f0(%rsp),%rdx
 1f838ce:	mov    %r15d,%esi
 1f838d1:	mov    %rax,0x78(%rsp)
 1f838d6:	vzeroupper
 1f838d9:	call   1f964a0 <node_rows_window_reads>
 1f838de:	rdtsc
 1f838e0:	mov    %r13,%rsi
 1f838e3:	mov    %rdx,0x4f0(%rsp)
 1f838eb:	mov    %r15d,%edx
 1f838ee:	mov    %rax,0x338(%rsp)
 1f838f6:	mov    0x8(%rsp),%rdi
 1f838fb:	call   1f96bc0 <node_rows_window_shapes>
 1f83900:	mov    0x8(%rsp),%rdi
 1f83905:	rdtsc
 1f83907:	mov    0xc10(%rdi),%rcx
 1f8390e:	or     0xc08(%rdi),%rcx
 1f83915:	mov    %rax,0x70(%rsp)
 1f8391a:	mov    %rdx,0x3f0(%rsp)
 1f83922:	je     1f8393c <node_facts_window_run+0x64ac>
 1f83924:	lea    0x8f0(%rsp),%rcx
 1f8392c:	mov    %r13,%rsi
 1f8392f:	mov    %r15d,%edx
 1f83932:	call   1f96ff0 <node_rows_window_updates>
 1f83937:	mov    0x8(%rsp),%rdi
 1f8393c:	rdtsc
 1f8393e:	mov    %r13,%rsi
 1f83941:	mov    %rdx,0x570(%rsp)
 1f83949:	mov    %r15d,%edx
 1f8394c:	mov    %rax,0x370(%rsp)
 1f83954:	call   1f97800 <node_rows_window_write>
 1f83959:	mov    %eax,%ecx
 1f8395b:	rdtsc
 1f8395d:	mov    0x900(%rsp),%r8
 1f83965:	mov    0x910(%rsp),%r9d
 1f8396d:	vpxor  %xmm0,%xmm0,%xmm0
 1f83971:	vmovdqu %xmm0,0x5bc(%rsp)
 1f8397a:	vmovdqa %xmm0,0x5b0(%rsp)
 1f83983:	movl   $0x0,0xfc(%rsp)
 1f8398e:	movq   $0x0,0x368(%rsp)
 1f8399a:	mov    %rax,0x3b0(%rsp)
 1f839a2:	mov    %rdx,0x650(%rsp)
 1f839aa:	sub    $0x8,%rsp
 1f839ae:	mov    0x10(%rsp),%rdi
 1f839b3:	lea    0x370(%rsp),%rax
 1f839bb:	lea    0x104(%rsp),%r10
 1f839c3:	lea    0x5b8(%rsp),%r11
 1f839cb:	mov    %r13,%rsi
 1f839ce:	mov    %r15d,%edx
 1f839d1:	mov    %ecx,0x2f8(%rsp)
 1f839d8:	push   %rax
 1f839d9:	push   %r10
 1f839db:	push   %r11
 1f839dd:	call   1f97e20 <node_rows_window_values>
 1f839e2:	add    $0x20,%rsp
 1f839e6:	rdtsc
 1f839e8:	mov    %r13,%rsi
 1f839eb:	mov    %rdx,0x610(%rsp)
 1f839f3:	mov    %rax,0x2b0(%rsp)
 1f839fb:	mov    0x8(%rsp),%rdi
 1f83a00:	call   1f98cc0 <node_rows_window_part>
 1f83a05:	mov    0x8(%rsp),%rdi
 1f83a0a:	rdtsc
 1f83a0c:	movl   $0x0,0xe0(%rsp)
 1f83a17:	movq   $0x0,0xd8(%rsp)
 1f83a23:	cmpb   $0x1,0xd58(%rdi)
 1f83a2a:	mov    %rax,0x530(%rsp)
 1f83a32:	mov    %rdx,0x4b0(%rsp)
 1f83a3a:	jne    1f83a54 <node_facts_window_run+0x65c4>
 1f83a3c:	lea    0xd8(%rsp),%rcx
 1f83a44:	mov    %r13,%rsi
 1f83a47:	mov    %r15d,%edx
 1f83a4a:	call   1f98dd0 <node_rows_window_summary>
 1f83a4f:	mov    0x8(%rsp),%rdi
 1f83a54:	rdtsc
 1f83a56:	mov    0xdc0(%rdi),%ecx
 1f83a5c:	movl   $0x0,0xdc0(%rdi)
 1f83a66:	mov    0xa90(%rdi),%r12d
 1f83a6d:	cmpb   $0x0,0xdc4(%rdi)
 1f83a74:	mov    %rcx,0x340(%rsp)
 1f83a7c:	mov    %rax,0xa0(%rsp)
 1f83a84:	mov    %rdx,0x5d0(%rsp)
 1f83a8c:	je     1f83abd <node_facts_window_run+0x662d>
 1f83a8e:	mov    0xdcc(%rdi),%ecx
 1f83a94:	mov    $0x1,%esi
 1f83a99:	mov    %ecx,%ebx
 1f83a9b:	inc    %ecx
 1f83a9d:	and    $0x3,%ebx
 1f83aa0:	mov    %ecx,0xdcc(%rdi)
 1f83aa6:	mov    0xd8(%rsp),%ebp
 1f83aad:	cmp    $0x2,%ebx
 1f83ab0:	jne    1f849b5 <node_facts_window_run+0x7525>
 1f83ab6:	mov    $0x2,%ebx
 1f83abb:	jmp    1f83ad6 <node_facts_window_run+0x6646>
 1f83abd:	mov    0xd8(%rsp),%ebp
 1f83ac4:	mov    $0xffffffff,%ebx
 1f83ac9:	mov    %ebx,%eax
 1f83acb:	xor    $0x3,%eax
 1f83ace:	xor    %esi,%esi
 1f83ad0:	or     %ebp,%eax
 1f83ad2:	sete   %sil
 1f83ad6:	cmpb   $0x1,0xd58(%rdi)
 1f83add:	mov    %esi,0x1a4(%rsp)
 1f83ae4:	mov    %r14,0x1b0(%rsp)
 1f83aec:	jne    1f83baf <node_facts_window_run+0x671f>
 1f83af2:	mov    0xd98(%rdi),%rsi
 1f83af9:	mov    0xda8(%rdi),%rdi
 1f83b00:	lea    (%r15,%r15,1),%rdx
 1f83b04:	call   355ebf0 <memcpy>
 1f83b09:	mov    0x8(%rsp),%rax
 1f83b0e:	mov    0x8(%rsp),%rcx
 1f83b13:	mov    %r12,%rdx
 1f83b16:	mov    0xda0(%rax),%rsi
 1f83b1d:	mov    0xdb0(%rcx),%rdi
 1f83b24:	call   355ebf0 <memcpy>
 1f83b29:	mov    0x8(%rsp),%rax
 1f83b2e:	mov    0x8(%rsp),%rcx
 1f83b33:	mov    %ebp,%edx
 1f83b35:	shl    $0x2,%rdx
 1f83b39:	mov    0xd90(%rax),%rsi
 1f83b40:	mov    0xdb8(%rcx),%rdi
 1f83b47:	call   355ebf0 <memcpy>
 1f83b4c:	mov    0x8(%rsp),%rdi
 1f83b51:	xor    %eax,%eax
 1f83b53:	mov    %r15d,%ecx
 1f83b56:	sub    $0x1,%ecx
 1f83b59:	cmovb  %eax,%ecx
 1f83b5c:	test   %ebx,%ebx
 1f83b5e:	sete   %dl
 1f83b61:	cmp    $0x1,%ebx
 1f83b64:	sete   %sil
 1f83b68:	test   %r12d,%r12d
 1f83b6b:	sete   %r8b
 1f83b6f:	mov    0xda8(%rdi),%rax
 1f83b76:	and    %sil,%r8b
 1f83b79:	or     %dl,%r8b
 1f83b7c:	movzbl %r8b,%edx
 1f83b80:	xor    %dx,(%rax,%rcx,2)
 1f83b84:	test   %r12d,%r12d
 1f83b87:	mov    0xdb0(%rdi),%rax
 1f83b8e:	setne  %cl
 1f83b91:	and    %sil,%cl
 1f83b94:	xor    %cl,(%rax)
 1f83b96:	cmp    $0x3,%ebx
 1f83b99:	mov    0xdb8(%rdi),%rdx
 1f83ba0:	sete   %al
 1f83ba3:	test   %ebp,%ebp
 1f83ba5:	setne  %cl
 1f83ba8:	and    %al,%cl
 1f83baa:	movzbl %cl,%eax
 1f83bad:	xor    %eax,(%rdx)
 1f83baf:	mov    %ebp,0x1a8(%rsp)
 1f83bb6:	mov    %r12,0x690(%rsp)
 1f83bbe:	mov    0xca8(%rdi),%rsi
 1f83bc5:	mov    0xcb8(%rdi),%rdi
 1f83bcc:	mov    0x2f0(%rsp),%ebx
 1f83bd3:	mov    %ebx,%r14d
 1f83bd6:	mov    %r14,%rdx
 1f83bd9:	call   355ebf0 <memcpy>
 1f83bde:	mov    0x8(%rsp),%rax
 1f83be3:	mov    0x8(%rsp),%rcx
 1f83be8:	mov    %r14,%rdx
 1f83beb:	mov    0xcb0(%rax),%rsi
 1f83bf2:	mov    0xcc0(%rcx),%rdi
 1f83bf9:	call   355ebf0 <memcpy>
 1f83bfe:	mov    0x8(%rsp),%rax
 1f83c03:	mov    0x8(%rsp),%rcx
 1f83c08:	lea    0x0(,%r14,8),%rdx
 1f83c10:	mov    %r14,0x6a8(%rsp)
 1f83c18:	mov    %rdx,0x698(%rsp)
 1f83c20:	mov    0xcc8(%rax),%rsi
 1f83c27:	mov    0xcd0(%rcx),%rdi
 1f83c2e:	call   355ebf0 <memcpy>
 1f83c33:	mov    0x8(%rsp),%rax
 1f83c38:	mov    $0xffffffff,%edi
 1f83c3d:	movzbl 0xdd0(%rax),%ecx
 1f83c44:	mov    0x8(%rsp),%rax
 1f83c49:	mov    0xdd8(%rax),%edx
 1f83c4f:	imul   $0x4ec4ec4f,%rdx,%rax
 1f83c56:	shr    $0x22,%rax
 1f83c5a:	lea    (%rax,%rax,2),%esi
 1f83c5d:	lea    (%rax,%rsi,4),%eax
 1f83c60:	mov    %edx,%esi
 1f83c62:	sub    %eax,%esi
 1f83c64:	test   %ecx,%ecx
 1f83c66:	cmovne %esi,%edi
 1f83c69:	xor    %eax,%eax
 1f83c6b:	lea    -0x1(%rdi),%esi
 1f83c6e:	cmp    $0x3,%esi
 1f83c71:	mov    %r15d,%esi
 1f83c74:	cmovae %edi,%eax
 1f83c77:	test   %ebx,%ebx
 1f83c79:	cmovne %edi,%eax
 1f83c7c:	add    %edx,%ecx
 1f83c7e:	mov    0x8(%rsp),%rdx
 1f83c83:	mov    0x8(%rsp),%rdi
 1f83c88:	cmp    $0x1,%eax
 1f83c8b:	vpbroadcastd %eax,%xmm0
 1f83c91:	vpcmpeqd -0x19bbea9(%rip),%xmm0,%xmm1        # 5c7df0 <.LCPI3_68>
 1f83c99:	vpcmpeqd -0x19bbea1(%rip),%xmm0,%xmm0        # 5c7e00 <.LCPI3_69>
 1f83ca1:	mov    %ecx,0xdd8(%rdx)
 1f83ca7:	mov    0x8(%rsp),%rcx
 1f83cac:	sete   %dl
 1f83caf:	vpsrld $0x1f,%xmm1,%xmm1
 1f83cb4:	vpsrld $0x1f,%xmm0,%xmm0
 1f83cb9:	mov    0xcb8(%rcx),%rcx
 1f83cc0:	xor    %dl,(%rcx)
 1f83cc2:	mov    0x8(%rsp),%rcx
 1f83cc7:	cmp    $0x2,%eax
 1f83cca:	sete   %dl
 1f83ccd:	mov    0xcc0(%rcx),%rcx
 1f83cd4:	xor    %dl,(%rcx)
 1f83cd6:	xor    %ecx,%ecx
 1f83cd8:	cmp    $0x3,%eax
 1f83cdb:	mov    0xcd0(%rdi),%rdx
 1f83ce2:	sete   %cl
 1f83ce5:	xor    %rcx,(%rdx)
 1f83ce8:	mov    0xfc(%rsp),%ecx
 1f83cef:	vmovsd 0x5b0(%rsp),%xmm2
 1f83cf8:	vmovups 0x5bc(%rsp),%xmm3
 1f83d01:	mov    %rcx,0x350(%rsp)
 1f83d09:	mov    0x368(%rsp),%rcx
 1f83d11:	mov    %rcx,0x348(%rsp)
 1f83d19:	mov    0x5b8(%rsp),%ecx
 1f83d20:	vmovups %ymm2,0x890(%rsp)
 1f83d29:	vshufps $0x24,%xmm3,%xmm2,%xmm2
 1f83d2e:	mov    %rcx,0x6b0(%rsp)
 1f83d36:	vpinsrd $0x2,%ecx,%xmm2,%xmm2
 1f83d3c:	xor    %ecx,%ecx
 1f83d3e:	cmp    $0xc,%eax
 1f83d41:	vmovaps %xmm3,0x860(%rsp)
 1f83d4a:	sete   %cl
 1f83d4d:	xor    0x5c8(%rsp),%ecx
 1f83d54:	vpxor  %xmm1,%xmm2,%xmm1
 1f83d58:	xor    %ebx,%ebx
 1f83d5a:	test   %eax,%eax
 1f83d5c:	vmovdqa %xmm1,0x720(%rsp)
 1f83d65:	vshufps $0xe9,%xmm3,%xmm3,%xmm1
 1f83d6a:	sete   %bpl
 1f83d6e:	cmp    $0x4,%eax
 1f83d71:	vxorps %xmm0,%xmm1,%xmm0
 1f83d75:	sete   0x4f(%rsp)
 1f83d7a:	cmp    $0x5,%eax
 1f83d7d:	vmovlps %xmm0,0x730(%rsp)
 1f83d86:	vxorps %xmm0,%xmm0,%xmm0
 1f83d8a:	mov    %ecx,0x738(%rsp)
 1f83d91:	rdtsc
 1f83d93:	vmovups %ymm0,0x7c0(%rsp)
 1f83d9c:	movq   $0x0,0x7e0(%rsp)
 1f83da8:	mov    %rax,0x6c0(%rsp)
 1f83db0:	mov    %rdx,0xe8(%rsp)
 1f83db8:	sete   0x4e(%rsp)
 1f83dbd:	lea    0x7c0(%rsp),%rdx
 1f83dc5:	mov    0x8(%rsp),%rdi
 1f83dca:	vzeroupper
 1f83dcd:	call   1f964a0 <node_rows_window_reads>
 1f83dd2:	rdtsc
 1f83dd4:	mov    %r13,%rsi
 1f83dd7:	mov    %rdx,0x780(%rsp)
 1f83ddf:	mov    %r15d,%edx
 1f83de2:	mov    %rax,0xb0(%rsp)
 1f83dea:	mov    0x8(%rsp),%rdi
 1f83def:	call   1f96bc0 <node_rows_window_shapes>
 1f83df4:	mov    0x8(%rsp),%rdi
 1f83df9:	rdtsc
 1f83dfb:	mov    0xc10(%rdi),%rcx
 1f83e02:	or     0xc08(%rdi),%rcx
 1f83e09:	mov    %rax,0x40(%rsp)
 1f83e0e:	mov    %rdx,0x490(%rsp)
 1f83e16:	je     1f83e30 <node_facts_window_run+0x69a0>
 1f83e18:	lea    0x7c0(%rsp),%rcx
 1f83e20:	mov    %r13,%rsi
 1f83e23:	mov    %r15d,%edx
 1f83e26:	call   1f96ff0 <node_rows_window_updates>
 1f83e2b:	mov    0x8(%rsp),%rdi
 1f83e30:	rdtsc
 1f83e32:	mov    %bpl,%bl
 1f83e35:	mov    %r13,%rsi
 1f83e38:	mov    %rax,0x98(%rsp)
 1f83e40:	mov    %rdx,0x740(%rsp)
 1f83e48:	mov    %r15d,%edx
 1f83e4b:	call   1f97800 <node_rows_window_write>
 1f83e50:	mov    %eax,%ecx
 1f83e52:	rdtsc
 1f83e54:	mov    0x7d0(%rsp),%r8
 1f83e5c:	mov    0x7e0(%rsp),%r9d
 1f83e64:	vxorps %xmm0,%xmm0,%xmm0
 1f83e68:	vmovups %xmm0,0x70c(%rsp)
 1f83e71:	vmovaps %xmm0,0x700(%rsp)
 1f83e7a:	movl   $0x0,0xf8(%rsp)
 1f83e85:	movq   $0x0,0x360(%rsp)
 1f83e91:	mov    %rax,0xa8(%rsp)
 1f83e99:	mov    %rdx,0x470(%rsp)
 1f83ea1:	sub    $0x8,%rsp
 1f83ea5:	mov    0x10(%rsp),%rdi
 1f83eaa:	lea    0x368(%rsp),%rax
 1f83eb2:	lea    0x708(%rsp),%r11
 1f83eba:	lea    0x100(%rsp),%r10
 1f83ec2:	mov    %r13,%rsi
 1f83ec5:	mov    %r15d,%edx
 1f83ec8:	mov    %ecx,0x1b4(%rsp)
 1f83ecf:	push   %rax
 1f83ed0:	push   %r10
 1f83ed2:	push   %r11
 1f83ed4:	call   1f97e20 <node_rows_window_values>
 1f83ed9:	add    $0x20,%rsp
 1f83edd:	rdtsc
 1f83edf:	mov    %r13,%rsi
 1f83ee2:	mov    %rdx,0x820(%rsp)
 1f83eea:	mov    %rax,0x90(%rsp)
 1f83ef2:	mov    0x8(%rsp),%rdi
 1f83ef7:	call   1f98cc0 <node_rows_window_part>
 1f83efc:	mov    0x8(%rsp),%r11
 1f83f01:	rdtsc
 1f83f03:	movl   $0x0,0x198(%rsp)
 1f83f0e:	movq   $0x0,0x190(%rsp)
 1f83f1a:	cmpb   $0x1,0xd58(%r11)
 1f83f22:	mov    %rax,0xf0(%rsp)
 1f83f2a:	mov    %rdx,0x108(%rsp)
 1f83f32:	jne    1f83f4f <node_facts_window_run+0x6abf>
 1f83f34:	lea    0x190(%rsp),%rcx
 1f83f3c:	mov    %r11,%rdi
 1f83f3f:	mov    %r13,%rsi
 1f83f42:	mov    %r15d,%edx
 1f83f45:	call   1f98dd0 <node_rows_window_summary>
 1f83f4a:	mov    0x8(%rsp),%r11
 1f83f4f:	mov    %r15,0x358(%rsp)
 1f83f57:	rdtsc
 1f83f59:	mov    0xdc0(%r11),%ecx
 1f83f60:	movl   $0x0,0xdc0(%r11)
 1f83f6b:	mov    %rax,0x100(%rsp)
 1f83f73:	mov    %rdx,0x6a0(%rsp)
 1f83f7b:	xor    %ebx,0x2f0(%rsp)
 1f83f82:	mov    %ecx,0x1a0(%rsp)
 1f83f89:	cmpl   $0x0,0xa90(%r11)
 1f83f91:	mov    0x1b0(%rsp),%rbp
 1f83f99:	je     1f8486b <node_facts_window_run+0x73db>
 1f83f9f:	vpbroadcastq -0x19b5aa0(%rip),%xmm2        # 5ce508 <.LCPI3_1>
 1f83fa8:	xor    %r15d,%r15d
 1f83fab:	jmp    1f83fcd <node_facts_window_run+0x6b3d>
 1f83fad:	mov    0x8(%rsp),%r11
 1f83fb2:	incq   0xbb8(%rbp,%rsi,8)
 1f83fba:	mov    0xa90(%r11),%eax
 1f83fc1:	inc    %r15
 1f83fc4:	cmp    %rax,%r15
 1f83fc7:	jae    1f8486b <node_facts_window_run+0x73db>
 1f83fcd:	mov    0xd40(%r11),%rax
 1f83fd4:	movzbl (%rax,%r15,1),%eax
 1f83fd9:	test   %al,%al
 1f83fdb:	je     1f83fba <node_facts_window_run+0x6b2a>
 1f83fdd:	mov    0xa70(%r11),%rdx
 1f83fe4:	mov    0xa68(%r11),%rcx
 1f83feb:	mov    (%rdx,%r15,4),%edx
 1f83fef:	mov    (%rcx,%r15,4),%r14d
 1f83ff3:	mov    0x651b8(%r13,%rdx,4),%edi
 1f83ffb:	incq   0xb90(%rbp)
 1f84002:	mov    0xa58(%r11),%rcx
 1f84009:	mov    (%rcx,%r15,4),%ecx
 1f8400d:	add    %rcx,0xb98(%rbp)
 1f84014:	cmp    $0x1,%al
 1f84016:	jne    1f84080 <node_facts_window_run+0x6bf0>
 1f84018:	mov    0xa58(%r11),%rax
 1f8401f:	mov    $0x1,%esi
 1f84024:	mov    (%rax,%r15,4),%r10d
 1f84028:	test   %r10d,%r10d
 1f8402b:	je     1f83fb2 <node_facts_window_run+0x6b22>
 1f8402d:	mov    0xbe8(%r11),%rax
 1f84034:	sub    %edi,%edx
 1f84036:	xor    %ecx,%ecx
 1f84038:	xor    %r11d,%r11d
 1f8403b:	inc    %edx
 1f8403d:	nopl   (%rax)
 1f84040:	lea    (%rdx,%r11,1),%r9d
 1f84044:	cmp    %edi,%r11d
 1f84047:	cmovae %r14d,%r9d
 1f8404b:	mov    %r9d,%r8d
 1f8404e:	shr    $0x3,%r8d
 1f84052:	and    $0xfffffff8,%r8d
 1f84056:	mov    0x28(%rax,%r8,8),%rbx
 1f8405b:	bt     %r9,%rbx
 1f8405f:	jb     1f843e8 <node_facts_window_run+0x6f58>
 1f84065:	inc    %r11d
 1f84068:	cmp    %r11d,%r10d
 1f8406b:	jne    1f84040 <node_facts_window_run+0x6bb0>
 1f8406d:	jmp    1f83fad <node_facts_window_run+0x6b1d>
 1f84072:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f84080:	mov    0xa68(%r11),%rcx
 1f84087:	mov    0xa70(%r11),%rdx
 1f8408e:	mov    0xa58(%r11),%rax
 1f84095:	xor    %r9d,%r9d
 1f84098:	mov    (%rcx,%r15,4),%ecx
 1f8409c:	mov    %rcx,0x18(%rsp)
 1f840a1:	mov    (%rdx,%r15,4),%ecx
 1f840a5:	mov    0xc40(%r11),%rdx
 1f840ac:	mov    0x651b8(%r13,%rcx,4),%esi
 1f840b4:	cmp    %esi,(%rax,%r15,4)
 1f840b8:	jbe    1f840c4 <node_facts_window_run+0x6c34>
 1f840ba:	mov    0x18(%rsp),%rax
 1f840bf:	movzbl (%rdx,%rax,1),%r9d
 1f840c4:	mov    0xc60(%r11),%r8
 1f840cb:	mov    0xc80(%r11),%r10
 1f840d2:	mov    %ecx,%edi
 1f840d4:	sub    %esi,%edi
 1f840d6:	mov    %ecx,%esi
 1f840d8:	shr    $0x3,%esi
 1f840db:	mov    0x940(%r11),%rax
 1f840e2:	inc    %edi
 1f840e4:	movzbl (%r8,%rdi,1),%ebx
 1f840e9:	shr    $0x3,%edi
 1f840ec:	mov    (%r10,%rsi,4),%r12d
 1f840f0:	mov    0xa50(%r11),%rsi
 1f840f7:	mov    %r10,0x150(%rsp)
 1f840ff:	mov    %r8,0x20(%rsp)
 1f84104:	add    (%r10,%rdi,4),%ebx
 1f84108:	movzbl (%r8,%rcx,1),%edi
 1f8410d:	movzbl (%rdx,%rcx,1),%r10d
 1f84112:	mov    %r12d,%ecx
 1f84115:	mov    (%rsi,%r15,4),%esi
 1f84119:	mov    %rbx,0x10(%rsp)
 1f8411e:	sub    %ebx,%ecx
 1f84120:	mov    0x130(%rax),%rbx
 1f84127:	add    %edi,%ecx
 1f84129:	add    %r10d,%ecx
 1f8412c:	add    %ecx,%r9d
 1f8412f:	mov    (%rbx,%rsi,4),%r8d
 1f84133:	cmp    $0xffffffff,%r8d
 1f84137:	je     1f843dd <node_facts_window_run+0x6f4d>
 1f8413d:	mov    %r12d,0x270(%rsp)
 1f84145:	mov    %r10,0x1f0(%rsp)
 1f8414d:	mov    %rdi,0x68(%rsp)
 1f84152:	mov    0xdd4(%r11),%r10d
 1f84159:	movzbl 0xdd0(%r11),%edi
 1f84161:	mov    $0x4,%edx
 1f84166:	mov    %r14,0xd0(%rsp)
 1f8416e:	mov    %r10d,%ebx
 1f84171:	and    $0x3,%ebx
 1f84174:	test   %edi,%edi
 1f84176:	mov    %r10d,0x80(%rsp)
 1f8417e:	cmove  %edx,%ebx
 1f84181:	test   $0x4,%r10b
 1f84185:	movabs $0x8000000000000000,%r10
 1f8418f:	mov    $0x1,%edx
 1f84194:	cmove  %rdx,%r10
 1f84198:	test   %r8d,%r8d
 1f8419b:	sete   %dl
 1f8419e:	mov    %r10,0x30(%rsp)
 1f841a3:	mov    %edi,0xb8(%rsp)
 1f841aa:	mov    %r8d,0xc0(%rsp)
 1f841b2:	mov    %r9,0x38(%rsp)
 1f841b7:	and    %dil,%dl
 1f841ba:	cmp    $0x2,%ebx
 1f841bd:	sete   %dil
 1f841c1:	or     %dl,%dil
 1f841c4:	movzbl %dil,%edx
 1f841c8:	add    %r8d,%edx
 1f841cb:	mov    0x110(%rax),%r8
 1f841d2:	cmp    $0x3,%ebx
 1f841d5:	sete   %dil
 1f841d9:	cmpb   $0x0,(%r8,%rsi,1)
 1f841de:	setne  %r8b
 1f841e2:	cmp    %edx,%r9d
 1f841e5:	setne  %r12b
 1f841e9:	xor    %r10d,%r10d
 1f841ec:	or     %r8b,%r12b
 1f841ef:	jne    1f84546 <node_facts_window_run+0x70b6>
 1f841f5:	test   %edx,%edx
 1f841f7:	je     1f84546 <node_facts_window_run+0x70b6>
 1f841fd:	mov    0x128(%rax),%rdx
 1f84204:	mov    0x140(%rax),%rbp
 1f8420b:	mov    %ecx,%ecx
 1f8420d:	mov    (%rdx,%rsi,4),%edx
 1f84210:	mov    0x148(%rax),%rsi
 1f84217:	add    %rdx,%rsi
 1f8421a:	add    %rdx,%rbp
 1f8421d:	shl    $0x3,%rdx
 1f84221:	add    0x150(%rax),%rdx
 1f84228:	cmp    $0x1,%ebx
 1f8422b:	mov    %rsi,0x110(%rsp)
 1f84233:	sete   %al
 1f84236:	cmp    $0x3,%ebx
 1f84239:	mov    %rdx,0x88(%rsp)
 1f84241:	sete   %dl
 1f84244:	mov    0x38(%rsp),%r8
 1f84249:	cmp    $0x2,%r8d
 1f8424d:	lea    -0x1(%r8),%r9d
 1f84251:	mov    %r8d,%r8d
 1f84254:	setae  %sil
 1f84258:	and    %al,%sil
 1f8425b:	mov    0x18(%rsp),%rax
 1f84260:	shr    $0x3,%eax
 1f84263:	mov    %rax,0x230(%rsp)
 1f8426b:	or     %dl,%sil
 1f8426e:	mov    0x8(%rsp),%rax
 1f84273:	mov    0xca8(%rax),%r11
 1f8427a:	test   %sil,%sil
 1f8427d:	je     1f8444e <node_facts_window_run+0x6fbe>
 1f84283:	mov    0x80(%rsp),%eax
 1f8428a:	xor    %esi,%esi
 1f8428c:	and    $0x8,%eax
 1f8428f:	shr    $0x3,%eax
 1f84292:	and    %al,%dil
 1f84295:	mov    $0x0,%edi
 1f8429a:	mov    0x10(%rsp),%rax
 1f8429f:	cmovne %r9,%rdi
 1f842a3:	sub    0x270(%rsp),%eax
 1f842aa:	neg    %r9
 1f842ad:	xor    %r14d,%r14d
 1f842b0:	sub    0x1f0(%rsp),%eax
 1f842b7:	neg    %rdi
 1f842ba:	sub    0x68(%rsp),%eax
 1f842be:	mov    %rax,0x68(%rsp)
 1f842c3:	mov    $0x1,%eax
 1f842c8:	mov    %r9,0x50(%rsp)
 1f842cd:	jmp    1f842ef <node_facts_window_run+0x6e5f>
 1f842cf:	nop
 1f842d0:	mov    0x28(%rsp),%r13
 1f842d5:	inc    %rsi
 1f842d8:	cmp    %r8,%rax
 1f842db:	mov    %r10d,%r14d
 1f842de:	setae  %dl
 1f842e1:	inc    %rax
 1f842e4:	or     %r12b,%dl
 1f842e7:	test   %dl,%dl
 1f842e9:	jne    1f84546 <node_facts_window_run+0x70b6>
 1f842ef:	lea    -0x1(%rax),%rdx
 1f842f3:	cmp    %rcx,%rdx
 1f842f6:	jae    1f84310 <node_facts_window_run+0x6e80>
 1f842f8:	mov    0x10(%rsp),%rdx
 1f842fd:	lea    (%rdx,%rsi,1),%r9d
 1f84301:	mov    %esi,%edx
 1f84303:	jmp    1f84344 <node_facts_window_run+0x6eb4>
 1f84305:	data16 cs nopw 0x0(%rax,%rax,1)
 1f84310:	mov    0x18(%rsp),%rdx
 1f84315:	mov    0x20(%rsp),%r9
 1f8431a:	mov    0x150(%rsp),%r12
 1f84322:	mov    0x230(%rsp),%r10
 1f8432a:	movzbl (%r9,%rdx,1),%r9d
 1f8432f:	mov    0x68(%rsp),%rdx
 1f84334:	add    (%r12,%r10,4),%r9d
 1f84338:	lea    (%rdx,%rax,1),%r10d
 1f8433c:	lea    -0x1(%rax),%edx
 1f8433f:	lea    -0x1(%r10,%r9,1),%r9d
 1f84344:	or     %ebx,%edx
 1f84346:	lea    (%rdi,%rax,1),%r10
 1f8434a:	mov    $0x0,%edx
 1f8434f:	mov    $0x1,%r12b
 1f84352:	mov    %r9d,%r9d
 1f84355:	sete   %r13b
 1f84359:	xor    -0x1(%rbp,%rax,1),%r13b
 1f8435e:	cmp    $0x1,%r10
 1f84362:	mov    $0x1,%r10b
 1f84365:	cmove  0x30(%rsp),%rdx
 1f8436b:	cmp    %r13b,(%r11,%r9,1)
 1f8436f:	jne    1f843ad <node_facts_window_run+0x6f1d>
 1f84371:	mov    0x50(%rsp),%r12
 1f84376:	cmp    $0x1,%ebx
 1f84379:	sete   %r13b
 1f8437d:	add    %rax,%r12
 1f84380:	cmp    $0x1,%r12
 1f84384:	sete   %r12b
 1f84388:	and    %r13b,%r12b
 1f8438b:	mov    0x110(%rsp),%r13
 1f84393:	xor    -0x1(%r13,%rax,1),%r12b
 1f84398:	mov    0x8(%rsp),%r13
 1f8439d:	mov    0xcb0(%r13),%r13
 1f843a4:	cmp    %r12b,0x0(%r13,%r9,1)
 1f843a9:	setne  %r12b
 1f843ad:	test   $0x1,%r14b
 1f843b1:	jne    1f842d0 <node_facts_window_run+0x6e40>
 1f843b7:	mov    0x88(%rsp),%r10
 1f843bf:	mov    0x8(%rsp),%r14
 1f843c4:	xor    -0x8(%r10,%rax,8),%rdx
 1f843c9:	mov    0xcc8(%r14),%r10
 1f843d0:	cmp    %rdx,(%r10,%r9,8)
 1f843d4:	setne  %r10b
 1f843d8:	jmp    1f842d0 <node_facts_window_run+0x6e40>
 1f843dd:	xor    %r10d,%r10d
 1f843e0:	xor    %r12d,%r12d
 1f843e3:	jmp    1f8457d <node_facts_window_run+0x70ed>
 1f843e8:	mov    0x8(%rsp),%r11
 1f843ed:	mov    %r9d,%edx
 1f843f0:	mov    0xbb0(%r11),%rsi
 1f843f7:	movzbl (%rsi,%rdx,1),%esi
 1f843fb:	and    $0x3f,%sil
 1f843ff:	cmp    $0x14,%sil
 1f84403:	je     1f84415 <node_facts_window_run+0x6f85>
 1f84405:	mov    0xc30(%r11),%rsi
 1f8440c:	xor    %ecx,%ecx
 1f8440e:	cmpb   $0x7f,(%rsi,%rdx,1)
 1f84412:	setne  %cl
 1f84415:	and    $0x3f,%r9d
 1f84419:	mov    $0x1,%edx
 1f8441e:	mov    $0x2,%esi
 1f84423:	shlx   %r9,%rdx,%rdx
 1f84428:	test   %rdx,0x30(%rax,%r8,8)
 1f8442d:	jne    1f83fb2 <node_facts_window_run+0x6b22>
 1f84433:	test   %rdx,0x38(%rax,%r8,8)
 1f84438:	mov    $0x3,%eax
 1f8443d:	cmovne %rax,%rcx
 1f84441:	incq   0xbb8(%rbp,%rcx,8)
 1f84449:	jmp    1f83fba <node_facts_window_run+0x6b2a>
 1f8444e:	mov    %r9,0x50(%rsp)
 1f84453:	xor    %esi,%esi
 1f84455:	xor    %edi,%edi
 1f84457:	mov    0x10(%rsp),%rax
 1f8445c:	sub    0x270(%rsp),%eax
 1f84463:	sub    0x1f0(%rsp),%eax
 1f8446a:	sub    0x68(%rsp),%eax
 1f8446e:	jmp    1f84488 <node_facts_window_run+0x6ff8>
 1f84470:	inc    %rsi
 1f84473:	mov    %r10d,%edi
 1f84476:	cmp    %r8,%rsi
 1f84479:	setae  %dl
 1f8447c:	or     %r12b,%dl
 1f8447f:	cmp    $0x1,%dl
 1f84482:	je     1f84546 <node_facts_window_run+0x70b6>
 1f84488:	cmp    %rcx,%rsi
 1f8448b:	jae    1f844a0 <node_facts_window_run+0x7010>
 1f8448d:	mov    0x10(%rsp),%rdx
 1f84492:	add    %esi,%edx
 1f84494:	jmp    1f844c7 <node_facts_window_run+0x7037>
 1f84496:	cs nopw 0x0(%rax,%rax,1)
 1f844a0:	mov    0x18(%rsp),%rdx
 1f844a5:	mov    0x20(%rsp),%r9
 1f844aa:	mov    0x230(%rsp),%r10
 1f844b2:	movzbl (%r9,%rdx,1),%edx
 1f844b7:	mov    0x150(%rsp),%r9
 1f844bf:	add    (%r9,%r10,4),%edx
 1f844c3:	add    %eax,%edx
 1f844c5:	add    %esi,%edx
 1f844c7:	mov    %esi,%r9d
 1f844ca:	or     %ebx,%r9d
 1f844cd:	mov    $0x1,%r10b
 1f844d0:	mov    $0x1,%r12b
 1f844d3:	mov    %edx,%edx
 1f844d5:	sete   %r9b
 1f844d9:	xor    0x0(%rbp,%rsi,1),%r9b
 1f844de:	cmp    %r9b,(%r11,%rdx,1)
 1f844e2:	jne    1f84517 <node_facts_window_run+0x7087>
 1f844e4:	cmp    $0x1,%ebx
 1f844e7:	sete   %r9b
 1f844eb:	cmp    %rsi,0x50(%rsp)
 1f844f0:	sete   %r14b
 1f844f4:	and    %r9b,%r14b
 1f844f7:	mov    0x110(%rsp),%r9
 1f844ff:	xor    (%r9,%rsi,1),%r14b
 1f84503:	mov    0x8(%rsp),%r9
 1f84508:	mov    0xcb0(%r9),%r9
 1f8450f:	cmp    %r14b,(%r9,%rdx,1)
 1f84513:	setne  %r12b
 1f84517:	test   $0x1,%dil
 1f8451b:	jne    1f84470 <node_facts_window_run+0x6fe0>
 1f84521:	mov    0x88(%rsp),%rdi
 1f84529:	mov    0x8(%rsp),%r9
 1f8452e:	mov    (%rdi,%rsi,8),%rdi
 1f84532:	mov    0xcc8(%r9),%r9
 1f84539:	cmp    %rdi,(%r9,%rdx,8)
 1f8453d:	setne  %r10b
 1f84541:	jmp    1f84470 <node_facts_window_run+0x6fe0>
 1f84546:	mov    0x80(%rsp),%eax
 1f8454d:	mov    0x8(%rsp),%r11
 1f84552:	mov    0x1b0(%rsp),%rbp
 1f8455a:	mov    0xd0(%rsp),%r14
 1f84562:	mov    0x38(%rsp),%r9
 1f84567:	mov    0xc0(%rsp),%r8d
 1f8456f:	add    0xb8(%rsp),%eax
 1f84576:	mov    %eax,0xdd4(%r11)
 1f8457d:	cmp    $0xffffffff,%r8d
 1f84581:	vmovd  %r9d,%xmm1
 1f84586:	mov    %r12d,%ecx
 1f84589:	sete   %al
 1f8458c:	incq   0xba0(%rbp)
 1f84593:	or     %r10b,%r12b
 1f84596:	xor    $0x1,%cl
 1f84599:	mov    0xa58(%r11),%rdx
 1f845a0:	and    %r10b,%cl
 1f845a3:	vmovd  (%rdx,%r15,4),%xmm0
 1f845a9:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f845ad:	vpaddq 0xba8(%rbp),%xmm0,%xmm0
 1f845b5:	vmovdqu %xmm0,0xba8(%rbp)
 1f845bd:	vmovd  %r12d,%xmm0
 1f845c2:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f845c8:	movzbl %cl,%eax
 1f845cb:	vpmovzxbq %xmm0,%xmm0
 1f845d0:	vptestmq %xmm2,%xmm0,%k0
 1f845d6:	vmovdqu 0xbd8(%rbp),%xmm0
 1f845de:	vpmovm2q %k0,%xmm1
 1f845e4:	vpsubq %xmm1,%xmm0,%xmm0
 1f845e8:	vmovdqu %xmm0,0xbd8(%rbp)
 1f845f0:	add    %rax,0xcc0(%rbp)
 1f845f7:	mov    0xd48(%r11),%rax
 1f845fe:	mov    (%rax,%r15,8),%rax
 1f84602:	add    %rax,0xc48(%rbp)
 1f84609:	test   $0x1,%r12b
 1f8460d:	je     1f84639 <node_facts_window_run+0x71a9>
 1f8460f:	mov    0x13ac(%rbp),%eax
 1f84615:	cmp    $0xf,%rax
 1f84619:	ja     1f83fba <node_facts_window_run+0x6b2a>
 1f8461f:	mov    0x422c(%r13,%r14,4),%ecx
 1f84627:	mov    %ecx,0x136c(%rbp,%rax,4)
 1f8462e:	incl   0x13ac(%rbp)
 1f84634:	jmp    1f83fba <node_facts_window_run+0x6b2a>
 1f84639:	cmpb   $0x1,0xd58(%r11)
 1f84641:	jne    1f83fba <node_facts_window_run+0x6b2a>
 1f84647:	mov    0xda0(%r11),%rax
 1f8464e:	mov    $0x4,%r12d
 1f84654:	movzbl (%rax,%r15,1),%r14d
 1f84659:	incq   0xce8(%rbp)
 1f84660:	mov    0xa70(%r11),%rax
 1f84667:	mov    0xd98(%r11),%rcx
 1f8466e:	mov    (%rax,%r15,4),%eax
 1f84672:	lea    0x1(%rax),%edx
 1f84675:	movzwl -0x2(%rcx,%rdx,2),%ebp
 1f8467a:	sub    0x651b8(%r13,%rax,4),%edx
 1f84682:	cmpb   $0x1,0xdc4(%r11)
 1f8468a:	movzwl -0x2(%rcx,%rdx,2),%eax
 1f8468f:	jne    1f846a2 <node_facts_window_run+0x7212>
 1f84691:	mov    0xdc8(%r11),%r12d
 1f84698:	and    $0x3,%r12d
 1f8469c:	je     1f84771 <node_facts_window_run+0x72e1>
 1f846a2:	cmp    $0x1,%r12d
 1f846a6:	mov    $0xffffffff,%r8d
 1f846ac:	sete   %cl
 1f846af:	cmp    %ax,%bp
 1f846b2:	sete   %bl
 1f846b5:	and    %cl,%bl
 1f846b7:	mov    0x940(%r11),%r13
 1f846be:	sub    %eax,%ebp
 1f846c0:	cmpq   $0x0,0x168(%r13)
 1f846c8:	je     1f84828 <node_facts_window_run+0x7398>
 1f846ce:	mov    0xa50(%r11),%rcx
 1f846d5:	mov    (%rcx,%r15,4),%edx
 1f846d9:	cmp    0x20(%r13),%edx
 1f846dd:	jae    1f84828 <node_facts_window_run+0x7398>
 1f846e3:	mov    0x188(%r13),%rdi
 1f846ea:	movzbl %bl,%esi
 1f846ed:	mov    %ebp,%r9d
 1f846f0:	lea    (%rsi,%rdi,1),%rcx
 1f846f4:	add    %r9,%rcx
 1f846f7:	cmp    0x190(%r13),%rcx
 1f846fe:	ja     1f84795 <node_facts_window_run+0x7305>
 1f84704:	cmp    $0xfffe,%ebp
 1f8470a:	ja     1f84795 <node_facts_window_run+0x7305>
 1f84710:	shl    $0x2,%rdi
 1f84714:	mov    %r8d,0x150(%rsp)
 1f8471c:	mov    %rsi,0x10(%rsp)
 1f84721:	lea    0x0(,%rax,4),%esi
 1f84728:	add    0x180(%r13),%rdi
 1f8472f:	add    0xd90(%r11),%rsi
 1f84736:	mov    %rdx,0x18(%rsp)
 1f8473b:	lea    0x0(,%r9,4),%rdx
 1f84743:	mov    %rdi,0x20(%rsp)
 1f84748:	mov    %r9,0x30(%rsp)
 1f8474d:	call   355ebf0 <memcpy>
 1f84752:	test   %bl,%bl
 1f84754:	je     1f8479e <node_facts_window_run+0x730e>
 1f84756:	mov    0x150(%rsp),%eax
 1f8475d:	mov    0x20(%rsp),%rcx
 1f84762:	mov    0x30(%rsp),%rdx
 1f84767:	mov    0x18(%rsp),%rsi
 1f8476c:	mov    %eax,(%rcx,%rdx,4)
 1f8476f:	jmp    1f847b4 <node_facts_window_run+0x7324>
 1f84771:	xor    %r8d,%r8d
 1f84774:	mov    $0x1,%bl
 1f84776:	xor    %r12d,%r12d
 1f84779:	mov    0x940(%r11),%r13
 1f84780:	sub    %eax,%ebp
 1f84782:	cmpq   $0x0,0x168(%r13)
 1f8478a:	jne    1f846ce <node_facts_window_run+0x723e>
 1f84790:	jmp    1f84828 <node_facts_window_run+0x7398>
 1f84795:	incq   0x198(%r13)
 1f8479c:	jmp    1f84819 <node_facts_window_run+0x7389>
 1f8479e:	mov    0x20(%rsp),%rax
 1f847a3:	mov    0x18(%rsp),%rsi
 1f847a8:	cmp    $0x1,%r12d
 1f847ac:	jne    1f847b4 <node_facts_window_run+0x7324>
 1f847ae:	movl   $0x0,(%rax)
 1f847b4:	mov    0x188(%r13),%eax
 1f847bb:	mov    0x168(%r13),%rcx
 1f847c2:	mov    0x10(%rsp),%rdi
 1f847c7:	mov    0x8(%rsp),%r11
 1f847cc:	mov    $0x1,%edx
 1f847d1:	vpbroadcastq -0x19b62d2(%rip),%xmm2        # 5ce508 <.LCPI3_1>
 1f847da:	mov    %eax,(%rcx,%rsi,4)
 1f847dd:	add    %ebp,%edi
 1f847df:	cmp    $0x3,%r12d
 1f847e3:	mov    0x170(%r13),%rax
 1f847ea:	sete   %cl
 1f847ed:	add    %cl,%cl
 1f847ef:	cmp    $0x2,%r12d
 1f847f3:	movzbl %cl,%ecx
 1f847f6:	cmove  %edx,%ecx
 1f847f9:	mov    %di,(%rax,%rsi,2)
 1f847fd:	mov    0xda0(%r11),%rax
 1f84804:	mov    0x178(%r13),%rdx
 1f8480b:	xor    (%rax,%r15,1),%cl
 1f8480f:	mov    %cl,(%rdx,%rsi,1)
 1f84812:	add    %rdi,0x188(%r13)
 1f84819:	movzbl 0xdc4(%r11),%eax
 1f84821:	add    %eax,0xdc8(%r11)
 1f84828:	vmovd  %ebp,%xmm1
 1f8482c:	mov    0x1b0(%rsp),%rbp
 1f84834:	mov    $0x101,%eax
 1f84839:	mov    0x28(%rsp),%r13
 1f8483e:	bextr  %eax,%r14d,%eax
 1f84843:	and    $0x1,%r14d
 1f84847:	vmovd  %eax,%xmm0
 1f8484b:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f8484f:	vpaddq 0xcf0(%rbp),%xmm0,%xmm0
 1f84857:	vmovdqu %xmm0,0xcf0(%rbp)
 1f8485f:	add    %r14,0xd00(%rbp)
 1f84866:	jmp    1f83fba <node_facts_window_run+0x6b2a>
 1f8486b:	shlq   $0x20,0x430(%rsp)
 1f84874:	shlq   $0x20,0x4f0(%rsp)
 1f8487d:	shlq   $0x20,0x3f0(%rsp)
 1f84886:	shlq   $0x20,0x570(%rsp)
 1f8488f:	shlq   $0x20,0x650(%rsp)
 1f84898:	shlq   $0x20,0x610(%rsp)
 1f848a1:	shlq   $0x20,0x4b0(%rsp)
 1f848aa:	shlq   $0x20,0x5d0(%rsp)
 1f848b3:	shlq   $0x20,0xe8(%rsp)
 1f848bc:	shlq   $0x20,0x780(%rsp)
 1f848c5:	shlq   $0x20,0x490(%rsp)
 1f848ce:	shlq   $0x20,0x740(%rsp)
 1f848d7:	shlq   $0x20,0x470(%rsp)
 1f848e0:	shlq   $0x20,0x820(%rsp)
 1f848e9:	shlq   $0x20,0x108(%rsp)
 1f848f2:	mov    $0x1,%r8d
 1f848f8:	vmovd  0x358(%rsp),%xmm1
 1f84901:	mov    0x6a8(%rsp),%rbx
 1f84909:	mov    0x6a0(%rsp),%r12
 1f84911:	mov    0x1ac(%rsp),%eax
 1f84918:	vmovd  %ebx,%xmm0
 1f8491c:	shl    $0x20,%r12
 1f84920:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84924:	vpaddq 0xbe8(%rbp),%xmm0,%xmm0
 1f8492c:	vmovdqu %xmm0,0xbe8(%rbp)
 1f84934:	cmp    %eax,0x2f0(%rsp)
 1f8493b:	jne    1f84989 <node_facts_window_run+0x74f9>
 1f8493d:	mov    0xca8(%r11),%rsi
 1f84944:	mov    0xcb8(%r11),%rdi
 1f8494b:	mov    %rbx,%rdx
 1f8494e:	mov    %r11,%r14
 1f84951:	call   355ebe0 <strlen+0x10>
 1f84956:	mov    0xc8(%rsp),%r15
 1f8495e:	mov    0x78(%rsp),%rsi
 1f84963:	mov    0x338(%rsp),%r13
 1f8496b:	test   %eax,%eax
 1f8496d:	je     1f849cb <node_facts_window_run+0x753b>
 1f8496f:	mov    %r14,%r11
 1f84972:	mov    0x70(%rsp),%rax
 1f84977:	mov    0xa0(%rsp),%rcx
 1f8497f:	mov    0x100(%rsp),%r14
 1f84987:	jmp    1f84a06 <node_facts_window_run+0x7576>
 1f84989:	mov    0xc8(%rsp),%r15
 1f84991:	mov    0x78(%rsp),%rsi
 1f84996:	mov    0x338(%rsp),%r13
 1f8499e:	mov    0x70(%rsp),%rax
 1f849a3:	mov    0xa0(%rsp),%rcx
 1f849ab:	mov    0x100(%rsp),%r14
 1f849b3:	jmp    1f84a0c <node_facts_window_run+0x757c>
 1f849b5:	setb   %al
 1f849b8:	test   %r15d,%r15d
 1f849bb:	sete   %cl
 1f849be:	test   %cl,%al
 1f849c0:	je     1f83ac9 <node_facts_window_run+0x6639>
 1f849c6:	jmp    1f83ad6 <node_facts_window_run+0x6646>
 1f849cb:	mov    0xcb0(%r14),%rsi
 1f849d2:	mov    0xcc0(%r14),%rdi
 1f849d9:	mov    %rbx,%rdx
 1f849dc:	call   355ebe0 <strlen+0x10>
 1f849e1:	test   %eax,%eax
 1f849e3:	je     1f84e65 <node_facts_window_run+0x79d5>
 1f849e9:	mov    %r14,%r11
 1f849ec:	mov    0x70(%rsp),%rax
 1f849f1:	mov    0xa0(%rsp),%rcx
 1f849f9:	mov    0x100(%rsp),%r14
 1f84a01:	mov    0x78(%rsp),%rsi
 1f84a06:	mov    $0x1,%r8d
 1f84a0c:	mov    0x570(%rsp),%rdx
 1f84a14:	or     0x430(%rsp),%rsi
 1f84a1c:	or     0x4f0(%rsp),%r13
 1f84a24:	or     0x3f0(%rsp),%rax
 1f84a2c:	add    %r8,0xbf8(%rbp)
 1f84a33:	or     %r12,%r14
 1f84a36:	or     %rdx,0x370(%rsp)
 1f84a3e:	mov    0x650(%rsp),%rdx
 1f84a46:	or     %rdx,0x3b0(%rsp)
 1f84a4e:	mov    0x610(%rsp),%rdx
 1f84a56:	or     %rdx,0x2b0(%rsp)
 1f84a5e:	mov    0x4b0(%rsp),%rdx
 1f84a66:	or     %rdx,0x530(%rsp)
 1f84a6e:	mov    0xe8(%rsp),%rdx
 1f84a76:	or     0x5d0(%rsp),%rcx
 1f84a7e:	or     %rdx,0x6c0(%rsp)
 1f84a86:	mov    0x780(%rsp),%rdx
 1f84a8e:	or     %rdx,0xb0(%rsp)
 1f84a96:	mov    0x490(%rsp),%rdx
 1f84a9e:	or     %rdx,0x40(%rsp)
 1f84aa3:	mov    0x740(%rsp),%rdx
 1f84aab:	or     %rdx,0x98(%rsp)
 1f84ab3:	mov    0x470(%rsp),%rdx
 1f84abb:	or     %rdx,0xa8(%rsp)
 1f84ac3:	mov    0x820(%rsp),%rdx
 1f84acb:	or     %rdx,0x90(%rsp)
 1f84ad3:	mov    0x108(%rsp),%rdx
 1f84adb:	or     %rdx,0xf0(%rsp)
 1f84ae3:	cmpb   $0x1,0xd58(%r11)
 1f84aeb:	jne    1f84b80 <node_facts_window_run+0x76f0>
 1f84af1:	mov    0x1a4(%rsp),%edx
 1f84af8:	mov    $0x1,%ebx
 1f84afd:	xor    0x1a8(%rsp),%edx
 1f84b04:	cmp    0x190(%rsp),%edx
 1f84b0b:	jne    1f84b89 <node_facts_window_run+0x76f9>
 1f84b0d:	mov    0xdc(%rsp),%edx
 1f84b14:	mov    %rax,0x70(%rsp)
 1f84b19:	cmp    0x194(%rsp),%edx
 1f84b20:	jne    1f84b84 <node_facts_window_run+0x76f4>
 1f84b22:	mov    0xe0(%rsp),%eax
 1f84b29:	cmp    0x198(%rsp),%eax
 1f84b30:	jne    1f84b84 <node_facts_window_run+0x76f4>
 1f84b32:	mov    %rsi,0x78(%rsp)
 1f84b37:	mov    %rcx,0xa0(%rsp)
 1f84b3f:	mov    0xd98(%r11),%rsi
 1f84b46:	mov    0xda8(%r11),%rdi
 1f84b4d:	mov    %r11,%r12
 1f84b50:	mov    0x358(%rsp),%rax
 1f84b58:	lea    (%rax,%rax,1),%rdx
 1f84b5c:	call   355ebe0 <strlen+0x10>
 1f84b61:	test   %eax,%eax
 1f84b63:	je     1f84f36 <node_facts_window_run+0x7aa6>
 1f84b69:	mov    0x70(%rsp),%rax
 1f84b6e:	mov    0xa0(%rsp),%rcx
 1f84b76:	mov    0x78(%rsp),%rsi
 1f84b7b:	mov    %r12,%r11
 1f84b7e:	jmp    1f84b89 <node_facts_window_run+0x76f9>
 1f84b80:	xor    %ebx,%ebx
 1f84b82:	jmp    1f84b89 <node_facts_window_run+0x76f9>
 1f84b84:	mov    0x70(%rsp),%rax
 1f84b89:	vmovd  0x340(%rsp),%xmm1
 1f84b92:	mov    0x530(%rsp),%rdx
 1f84b9a:	vmovd  %ebx,%xmm2
 1f84b9e:	mov    0xf0(%rsp),%rdi
 1f84ba6:	vpmovzxdq 0x860(%rsp),%ymm7
 1f84bb0:	vmovq  0x370(%rsp),%xmm4
 1f84bb9:	vmovq  %r13,%xmm3
 1f84bbe:	vmovq  %rsi,%xmm5
 1f84bc3:	mov    0x90(%rsp),%rsi
 1f84bcb:	mov    0xa8(%rsp),%r8
 1f84bd3:	sub    %rdx,%rcx
 1f84bd6:	sub    %rdi,%r14
 1f84bd9:	vmovq  %rcx,%xmm0
 1f84bde:	mov    0x2b0(%rsp),%rcx
 1f84be6:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84bea:	vmovd  0xe0(%rsp),%xmm1
 1f84bf3:	sub    %rcx,%rdx
 1f84bf6:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f84bfa:	vmovq  %rax,%xmm2
 1f84bff:	mov    0x3b0(%rsp),%rax
 1f84c07:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f84c0d:	vpaddq 0xd08(%rbp),%ymm0,%ymm0
 1f84c15:	vmovd  0x350(%rsp),%xmm1
 1f84c1e:	vpbroadcastq %rax,%ymm6
 1f84c24:	sub    %rax,%rcx
 1f84c27:	mov    %rsi,%rax
 1f84c2a:	sub    %r8,%rax
 1f84c2d:	vmovdqu %ymm0,0xd08(%rbp)
 1f84c35:	add    %r14,0xd28(%rbp)
 1f84c3c:	vmovq  0x348(%rsp),%xmm0
 1f84c45:	vpaddq 0xc90(%rbp),%ymm7,%ymm7
 1f84c4d:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84c51:	vmovdqu %ymm7,0xc90(%rbp)
 1f84c59:	vpaddq 0xcb0(%rbp),%xmm0,%xmm0
 1f84c61:	vmovdqu %xmm0,0xcb0(%rbp)
 1f84c69:	vpunpcklqdq %xmm2,%xmm3,%xmm0
 1f84c6d:	vmovq  0x98(%rsp),%xmm2
 1f84c76:	vmovq  0x40(%rsp),%xmm3
 1f84c7c:	vinserti128 $0x1,%xmm4,%ymm0,%ymm0
 1f84c82:	vpbroadcastq %r8,%ymm4
 1f84c88:	vpblendd $0xc0,%ymm6,%ymm0,%ymm1
 1f84c8e:	vpermq $0x90,%ymm0,%ymm0
 1f84c94:	vpbroadcastq %rsi,%ymm6
 1f84c9a:	vpblendd $0x3,%ymm5,%ymm0,%ymm0
 1f84ca0:	vpbroadcastq %rdi,%ymm5
 1f84ca6:	vpsubq %ymm0,%ymm1,%ymm0
 1f84caa:	vmovdqu 0x8f0(%rsp),%ymm1
 1f84cb3:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f84cb7:	vpblendd $0x30,%ymm4,%ymm2,%ymm3
 1f84cbd:	vpermq $0xd0,%ymm2,%ymm2
 1f84cc3:	vmovdqa64 -0x1acdfcd(%rip),%zmm4        # 4b6d00 <abi_test_hex.digits+0xb980>
 1f84ccd:	vpblendd $0xc0,%ymm5,%ymm3,%ymm3
 1f84cd3:	vpmovzxdq 0x890(%rsp),%zmm5
 1f84cde:	vinserti64x4 $0x1,%ymm0,%zmm1,%zmm0
 1f84ce5:	vpaddq 0xc00(%rbp),%zmm0,%zmm0
 1f84cec:	vmovq  %rcx,%xmm1
 1f84cf1:	vmovdqu64 %zmm0,0xc00(%rbp)
 1f84cf8:	vmovq  %rax,%xmm0
 1f84cfd:	mov    0xb0(%rsp),%rax
 1f84d05:	add    %rdx,0xc40(%rbp)
 1f84d0c:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84d10:	vpmovzxdq 0xd8(%rsp),%xmm1
 1f84d1a:	vmovq  %rax,%xmm7
 1f84d1f:	sub    0x6c0(%rsp),%rax
 1f84d27:	vpblendd $0x3,%ymm7,%ymm2,%ymm2
 1f84d2d:	vpblendd $0xc0,%ymm6,%ymm2,%ymm2
 1f84d33:	vmovdqa64 -0x1ace07d(%rip),%zmm6        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f84d3d:	vpsubq %ymm2,%ymm3,%ymm2
 1f84d41:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f84d47:	vpaddq 0xcc8(%rbp),%ymm0,%ymm0
 1f84d4f:	vmovq  %rax,%xmm8
 1f84d54:	mov    $0x80,%al
 1f84d56:	kmovd  %eax,%k1
 1f84d5a:	mov    0x6b0(%rsp),%rax
 1f84d62:	vpermi2q %zmm8,%zmm2,%zmm6
 1f84d68:	vmovdqu %ymm0,0xcc8(%rbp)
 1f84d70:	vpermi2q %zmm5,%zmm6,%zmm4
 1f84d76:	vpbroadcastq %rax,%zmm4{%k1}
 1f84d7c:	vpaddq 0xc50(%rbp),%zmm4,%zmm0
 1f84d86:	vmovdqu64 %zmm0,0xc50(%rbp)
 1f84d90:	vmovups 0x9d0(%r11),%zmm0
 1f84d9a:	vmovups 0x268(%r11),%zmm1
 1f84da4:	vmovups 0x8b0(%rsp),%zmm3
 1f84daf:	vmovaps 0x880(%rsp),%xmm2
 1f84db8:	xor    %esi,%esi
 1f84dba:	mov    %r15,%rdx
 1f84dbd:	vmovups %zmm0,0x268(%r11)
 1f84dc7:	vmovups %zmm1,0x9d0(%r11)
 1f84dd1:	vmovups 0xa10(%r11),%xmm0
 1f84dda:	vmovups 0x2a8(%r11),%xmm1
 1f84de3:	vmovups %xmm0,0x2a8(%r11)
 1f84dec:	vmovups %xmm1,0xa10(%r11)
 1f84df5:	vmovaps 0x870(%rsp),%xmm1
 1f84dfe:	mov    0x2b8(%r11),%rax
 1f84e05:	mov    0xa20(%r11),%rcx
 1f84e0c:	mov    %rcx,0x2b8(%r11)
 1f84e13:	mov    %rax,0xa20(%r11)
 1f84e1a:	mov    0x6b8(%rsp),%rax
 1f84e22:	vmovups %zmm3,0x1f0(%r11)
 1f84e2c:	mov    %rax,0x230(%r11)
 1f84e33:	vmovups %xmm2,0x240(%r11)
 1f84e3c:	vmovlps %xmm1,0x258(%r11)
 1f84e45:	mov    0x9b8(%r11),%rdi
 1f84e4c:	add    $0xd08,%rsp
 1f84e53:	pop    %rbx
 1f84e54:	pop    %r12
 1f84e56:	pop    %r13
 1f84e58:	pop    %r14
 1f84e5a:	pop    %r15
 1f84e5c:	pop    %rbp
 1f84e5d:	vzeroupper
 1f84e60:	jmp    355ec60 <memset>
 1f84e65:	mov    0xcc8(%r14),%rsi
 1f84e6c:	mov    0xcd0(%r14),%rdi
 1f84e73:	mov    0x698(%rsp),%rdx
 1f84e7b:	call   355ebe0 <strlen+0x10>
 1f84e80:	mov    0x100(%rsp),%r14
 1f84e88:	test   %eax,%eax
 1f84e8a:	jne    1f84fbb <node_facts_window_run+0x7b2b>
 1f84e90:	movzbl 0x4f(%rsp),%ecx
 1f84e95:	xor    %eax,%eax
 1f84e97:	mov    $0x1,%r8d
 1f84e9d:	mov    %cl,%al
 1f84e9f:	xor    0x350(%rsp),%eax
 1f84ea6:	mov    0xa0(%rsp),%rcx
 1f84eae:	cmp    0xf8(%rsp),%eax
 1f84eb5:	mov    0x70(%rsp),%rax
 1f84eba:	jne    1f84fd2 <node_facts_window_run+0x7b42>
 1f84ec0:	movzbl 0x4e(%rsp),%esi
 1f84ec5:	mov    0x8(%rsp),%r11
 1f84eca:	xor    %edx,%edx
 1f84ecc:	mov    %sil,%dl
 1f84ecf:	xor    0x348(%rsp),%rdx
 1f84ed7:	cmp    0x360(%rsp),%rdx
 1f84edf:	jne    1f84fb1 <node_facts_window_run+0x7b21>
 1f84ee5:	vmovdqu 0x72c(%rsp),%xmm1
 1f84eee:	vmovdqa 0x720(%rsp),%xmm0
 1f84ef7:	mov    0x78(%rsp),%rsi
 1f84efc:	vpxor  0x700(%rsp),%xmm0,%xmm0
 1f84f05:	vpternlogq $0xf6,0x70c(%rsp),%xmm1,%xmm0
 1f84f11:	vptest %xmm0,%xmm0
 1f84f16:	jne    1f84a0c <node_facts_window_run+0x757c>
 1f84f1c:	mov    0x1a0(%rsp),%edx
 1f84f23:	xor    %r8d,%r8d
 1f84f26:	cmp    %edx,0x340(%rsp)
 1f84f2d:	setne  %r8b
 1f84f31:	jmp    1f84a0c <node_facts_window_run+0x757c>
 1f84f36:	mov    0xda0(%r12),%rsi
 1f84f3e:	mov    0xdb0(%r12),%rdi
 1f84f46:	mov    0x690(%rsp),%rdx
 1f84f4e:	call   355ebe0 <strlen+0x10>
 1f84f53:	mov    %r12,%r11
 1f84f56:	mov    0xa0(%rsp),%rcx
 1f84f5e:	mov    0x78(%rsp),%rsi
 1f84f63:	test   %eax,%eax
 1f84f65:	mov    0x70(%rsp),%rax
 1f84f6a:	jne    1f84b89 <node_facts_window_run+0x76f9>
 1f84f70:	mov    0xd8(%rsp),%edx
 1f84f77:	mov    0xd90(%r11),%rsi
 1f84f7e:	mov    0xdb8(%r11),%rdi
 1f84f85:	shl    $0x2,%rdx
 1f84f89:	call   355ebe0 <strlen+0x10>
 1f84f8e:	xor    %ebx,%ebx
 1f84f90:	test   %eax,%eax
 1f84f92:	mov    0x78(%rsp),%rsi
 1f84f97:	mov    0xa0(%rsp),%rcx
 1f84f9f:	mov    0x8(%rsp),%r11
 1f84fa4:	mov    0x70(%rsp),%rax
 1f84fa9:	setne  %bl
 1f84fac:	jmp    1f84b89 <node_facts_window_run+0x76f9>
 1f84fb1:	mov    0x78(%rsp),%rsi
 1f84fb6:	jmp    1f84a0c <node_facts_window_run+0x757c>
 1f84fbb:	mov    0x8(%rsp),%r11
 1f84fc0:	mov    0x70(%rsp),%rax
 1f84fc5:	mov    0xa0(%rsp),%rcx
 1f84fcd:	jmp    1f84a01 <node_facts_window_run+0x7571>
 1f84fd2:	mov    0x8(%rsp),%r11
 1f84fd7:	mov    0x78(%rsp),%rsi
 1f84fdc:	jmp    1f84a0c <node_facts_window_run+0x757c>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
