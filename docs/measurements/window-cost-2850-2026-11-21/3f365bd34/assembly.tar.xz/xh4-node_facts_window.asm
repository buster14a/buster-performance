
results/xh4/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f7be00 <node_facts_window>:
 1f7be00:	push   %rbp
 1f7be01:	push   %r15
 1f7be03:	push   %r14
 1f7be05:	push   %r13
 1f7be07:	push   %r12
 1f7be09:	push   %rbx
 1f7be0a:	sub    $0xa8,%rsp
 1f7be11:	mov    0x248(%rdi),%rax
 1f7be18:	mov    %ecx,%ebp
 1f7be1a:	mov    %esi,%ecx
 1f7be1c:	inc    %esi
 1f7be1e:	mov    %edx,0xc(%rsp)
 1f7be22:	mov    %rdi,%r12
 1f7be25:	mov    (%rax,%rcx,4),%r13d
 1f7be29:	mov    (%rax,%rsi,4),%r8d
 1f7be2d:	test   %ebp,%ebp
 1f7be2f:	je     1f7c06f <node_facts_window+0x26f>
 1f7be35:	rdtsc
 1f7be37:	shl    $0x20,%rdx
 1f7be3b:	or     %rax,%rdx
 1f7be3e:	mov    %rdx,0x60(%rsp)
 1f7be43:	mov    %r12,0x20(%rsp)
 1f7be48:	mov    %r13,0x30(%rsp)
 1f7be4d:	cmp    %r13d,%r8d
 1f7be50:	je     1f7c08b <node_facts_window+0x28b>
 1f7be56:	vmovdqa64 -0x1ac57a0(%rip),%zmm1        # 4b66c0 <abi_test_hex.digits+0xb340>
 1f7be60:	vpbroadcastb -0x1ac5769(%rip),%xmm2        # 4b6700 <abi_test_hex.digits+0xb380>
 1f7be69:	vpbroadcastb -0x1ac5771(%rip),%xmm3        # 4b6701 <abi_test_hex.digits+0xb381>
 1f7be72:	vpbroadcastq -0x19ad97b(%rip),%xmm4        # 5ce500 <.LCPI0_8>
 1f7be7b:	vpbroadcastd -0x19aaf5d(%rip),%zmm5        # 5d0f28 <.LCPI0_4>
 1f7be85:	vpbroadcastd -0x19aaf63(%rip),%zmm6        # 5d0f2c <.LCPI0_5>
 1f7be8f:	mov    0x1f8(%r12),%rsi
 1f7be97:	mov    0x200(%r12),%rdi
 1f7be9f:	mov    0x2c8(%r12),%rax
 1f7bea7:	mov    0x2d0(%r12),%rcx
 1f7beaf:	mov    0x2d8(%r12),%rdx
 1f7beb7:	mov    %r13,%r9
 1f7beba:	sub    %r9d,%r8d
 1f7bebd:	mov    $0x10,%r10d
 1f7bec3:	mov    $0xffffffff,%r11d
 1f7bec9:	mov    %ebp,%r13d
 1f7becc:	vpxor  %xmm0,%xmm0,%xmm0
 1f7bed0:	xor    %r12d,%r12d
 1f7bed3:	xor    %ebx,%ebx
 1f7bed5:	xor    %r15d,%r15d
 1f7bed8:	mov    %r8d,%ebp
 1f7bedb:	add    %r9,%rsi
 1f7bede:	add    %r9,%rdi
 1f7bee1:	mov    %r8d,%r9d
 1f7bee4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7bef0:	sub    $0x10,%ebp
 1f7bef3:	mov    %r15d,%r14d
 1f7bef6:	mov    %r12d,%r15d
 1f7bef9:	cmovae %r10d,%r8d
 1f7befd:	shlx   %r8d,%r11d,%r8d
 1f7bf02:	not    %r8d
 1f7bf05:	kmovd  %r8d,%k1
 1f7bf0a:	mov    %r12d,%r8d
 1f7bf0d:	vmovdqu8 (%rsi,%rbx,1),%xmm7{%k1}{z}
 1f7bf14:	vpand  %xmm2,%xmm7,%xmm7
 1f7bf18:	vpcmpeqb %xmm3,%xmm7,%k2{%k1}
 1f7bf1e:	vpcmpeqb %xmm2,%xmm7,%k1{%k1}
 1f7bf24:	vmovdqu8 (%rdi,%rbx,1),%xmm7{%k1}{z}
 1f7bf2b:	vpxor  %xmm8,%xmm8,%xmm8
 1f7bf30:	vpcompressd %zmm1,%zmm8{%k2}{z}
 1f7bf36:	vpxor  %xmm10,%xmm10,%xmm10
 1f7bf3b:	vpcompressd %zmm1,%zmm10{%k1}{z}
 1f7bf41:	vpaddd %zmm6,%zmm1,%zmm1
 1f7bf47:	add    $0x10,%rbx
 1f7bf4b:	vmovdqu64 %zmm8,(%rax,%r8,4)
 1f7bf52:	mov    %r14d,%r8d
 1f7bf55:	vmovdqu64 %zmm10,(%rcx,%r8,4)
 1f7bf5c:	vxorps %xmm9,%xmm9,%xmm9
 1f7bf61:	vpcompressb %xmm7,%xmm9{%k1}{z}
 1f7bf67:	vgf2p8affineqb $0x0,%xmm4,%xmm7,%xmm7
 1f7bf6d:	vmovdqu %xmm9,(%rdx,%r8,1)
 1f7bf73:	kmovw  %k2,%r8d
 1f7bf77:	vpmovzxbd %xmm7,%zmm7
 1f7bf7d:	popcnt %r8d,%r12d
 1f7bf82:	kmovw  %k1,%r8d
 1f7bf86:	add    %r15d,%r12d
 1f7bf89:	popcnt %r8d,%r15d
 1f7bf8e:	mov    %ebp,%r8d
 1f7bf91:	add    %r14d,%r15d
 1f7bf94:	vpsllvd %zmm7,%zmm5,%zmm7{%k1}{z}
 1f7bf9a:	vporq  %zmm7,%zmm0,%zmm0
 1f7bfa0:	cmp    %r9,%rbx
 1f7bfa3:	jb     1f7bef0 <node_facts_window+0xf0>
 1f7bfa9:	mov    %r12,0x38(%rsp)
 1f7bfae:	mov    0x20(%rsp),%r12
 1f7bfb3:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f7bfba:	vporq  %zmm1,%zmm0,%zmm0
 1f7bfc0:	vextracti128 $0x1,%ymm0,%xmm1
 1f7bfc6:	vpor   %xmm1,%xmm0,%xmm0
 1f7bfca:	vpshufd $0xee,%xmm0,%xmm1
 1f7bfcf:	mov    0x2d0(%r12),%rdi
 1f7bfd7:	mov    0x2d8(%r12),%rax
 1f7bfdf:	vpor   %xmm1,%xmm0,%xmm0
 1f7bfe3:	lea    0x2e0(%r12),%rcx
 1f7bfeb:	movl   $0x0,0x3e8(%r12)
 1f7bff7:	vpshufd $0x55,%xmm0,%xmm1
 1f7bffc:	mov    %rcx,0x68(%rsp)
 1f7c001:	vpor   %xmm1,%xmm0,%xmm0
 1f7c005:	vmovd  %xmm0,0x2c(%rsp)
 1f7c00b:	vpxor  %xmm0,%xmm0,%xmm0
 1f7c00f:	vmovdqu64 %zmm0,0x2e8(%r12)
 1f7c01a:	vmovdqu64 %zmm0,0x328(%r12)
 1f7c025:	vmovdqu64 %zmm0,0x368(%r12)
 1f7c030:	vmovdqu64 %zmm0,0x3a8(%r12)
 1f7c03b:	test   %r15d,%r15d
 1f7c03e:	je     1f7c121 <node_facts_window+0x321>
 1f7c044:	mov    0x2e0(%r12),%rdx
 1f7c04c:	mov    %r15d,%r8d
 1f7c04f:	mov    %r8d,%esi
 1f7c052:	lea    0x2e8(%r12),%rcx
 1f7c05a:	and    $0x7,%esi
 1f7c05d:	cmp    $0x8,%r15d
 1f7c061:	jae    1f7c129 <node_facts_window+0x329>
 1f7c067:	xor    %r9d,%r9d
 1f7c06a:	jmp    1f7c2d1 <node_facts_window+0x4d1>
 1f7c06f:	movq   $0x0,0x60(%rsp)
 1f7c078:	mov    %r12,0x20(%rsp)
 1f7c07d:	mov    %r13,0x30(%rsp)
 1f7c082:	cmp    %r13d,%r8d
 1f7c085:	jne    1f7be56 <node_facts_window+0x56>
 1f7c08b:	lea    0x2e0(%r12),%rax
 1f7c093:	vpxor  %xmm0,%xmm0,%xmm0
 1f7c097:	vmovdqu64 %zmm0,0x3a8(%r12)
 1f7c0a2:	vmovdqu64 %zmm0,0x368(%r12)
 1f7c0ad:	vmovdqu64 %zmm0,0x328(%r12)
 1f7c0b8:	vmovdqu64 %zmm0,0x2e8(%r12)
 1f7c0c3:	movl   $0x0,0x3e8(%r12)
 1f7c0cf:	movq   $0x0,0x38(%rsp)
 1f7c0d8:	xor    %r15d,%r15d
 1f7c0db:	movl   $0x0,0x2c(%rsp)
 1f7c0e3:	mov    %rax,0x68(%rsp)
 1f7c0e8:	cmpl   $0x0,0xc(%rsp)
 1f7c0ed:	jne    1f7c336 <node_facts_window+0x536>
 1f7c0f3:	mov    0x38(%rsp),%rdx
 1f7c0f8:	mov    %r12,%rdi
 1f7c0fb:	mov    %r13d,%esi
 1f7c0fe:	vzeroupper
 1f7c101:	call   1f850b0 <node_facts_leaves>
 1f7c106:	test   %bpl,%bpl
 1f7c109:	jne    1f7c352 <node_facts_window+0x552>
 1f7c10f:	xor    %ebx,%ebx
 1f7c111:	cmpl   $0x0,0x2c(%rsp)
 1f7c116:	jne    1f7c369 <node_facts_window+0x569>
 1f7c11c:	jmp    1f7c9c9 <node_facts_window+0xbc9>
 1f7c121:	xor    %r15d,%r15d
 1f7c124:	jmp    1f7ca2f <node_facts_window+0xc2f>
 1f7c129:	and    $0xfffffff8,%r8d
 1f7c12d:	mov    $0x40,%r10d
 1f7c133:	xor    %r9d,%r9d
 1f7c136:	cs nopw 0x0(%rax,%rax,1)
 1f7c140:	movzbl (%rax,%r9,1),%r11d
 1f7c145:	mov    (%rdi,%r9,4),%ebp
 1f7c149:	cmp    $0x40,%r11b
 1f7c14d:	cmovae %r10d,%r11d
 1f7c151:	movzbl %r11b,%r11d
 1f7c155:	mov    (%rcx,%r11,4),%ebx
 1f7c159:	mov    %r11d,%r14d
 1f7c15c:	shl    $0xe,%r14d
 1f7c160:	add    %rdx,%r14
 1f7c163:	mov    %ebp,(%r14,%rbx,4)
 1f7c167:	inc    %ebx
 1f7c169:	mov    %ebx,(%rcx,%r11,4)
 1f7c16d:	movzbl 0x1(%rax,%r9,1),%r11d
 1f7c173:	mov    0x4(%rdi,%r9,4),%ebp
 1f7c178:	cmp    $0x40,%r11b
 1f7c17c:	cmovae %r10d,%r11d
 1f7c180:	movzbl %r11b,%r11d
 1f7c184:	mov    (%rcx,%r11,4),%ebx
 1f7c188:	mov    %r11d,%r14d
 1f7c18b:	shl    $0xe,%r14d
 1f7c18f:	add    %rdx,%r14
 1f7c192:	mov    %ebp,(%r14,%rbx,4)
 1f7c196:	inc    %ebx
 1f7c198:	mov    %ebx,(%rcx,%r11,4)
 1f7c19c:	movzbl 0x2(%rax,%r9,1),%r11d
 1f7c1a2:	mov    0x8(%rdi,%r9,4),%ebp
 1f7c1a7:	cmp    $0x40,%r11b
 1f7c1ab:	cmovae %r10d,%r11d
 1f7c1af:	movzbl %r11b,%r11d
 1f7c1b3:	mov    (%rcx,%r11,4),%ebx
 1f7c1b7:	mov    %r11d,%r14d
 1f7c1ba:	shl    $0xe,%r14d
 1f7c1be:	add    %rdx,%r14
 1f7c1c1:	mov    %ebp,(%r14,%rbx,4)
 1f7c1c5:	inc    %ebx
 1f7c1c7:	mov    %ebx,(%rcx,%r11,4)
 1f7c1cb:	movzbl 0x3(%rax,%r9,1),%r11d
 1f7c1d1:	mov    0xc(%rdi,%r9,4),%ebp
 1f7c1d6:	cmp    $0x40,%r11b
 1f7c1da:	cmovae %r10d,%r11d
 1f7c1de:	movzbl %r11b,%r11d
 1f7c1e2:	mov    (%rcx,%r11,4),%ebx
 1f7c1e6:	mov    %r11d,%r14d
 1f7c1e9:	shl    $0xe,%r14d
 1f7c1ed:	add    %rdx,%r14
 1f7c1f0:	mov    %ebp,(%r14,%rbx,4)
 1f7c1f4:	inc    %ebx
 1f7c1f6:	mov    %ebx,(%rcx,%r11,4)
 1f7c1fa:	movzbl 0x4(%rax,%r9,1),%r11d
 1f7c200:	mov    0x10(%rdi,%r9,4),%ebp
 1f7c205:	cmp    $0x40,%r11b
 1f7c209:	cmovae %r10d,%r11d
 1f7c20d:	movzbl %r11b,%r11d
 1f7c211:	mov    (%rcx,%r11,4),%ebx
 1f7c215:	mov    %r11d,%r14d
 1f7c218:	shl    $0xe,%r14d
 1f7c21c:	add    %rdx,%r14
 1f7c21f:	mov    %ebp,(%r14,%rbx,4)
 1f7c223:	inc    %ebx
 1f7c225:	mov    %ebx,(%rcx,%r11,4)
 1f7c229:	movzbl 0x5(%rax,%r9,1),%r11d
 1f7c22f:	mov    0x14(%rdi,%r9,4),%ebp
 1f7c234:	cmp    $0x40,%r11b
 1f7c238:	cmovae %r10d,%r11d
 1f7c23c:	movzbl %r11b,%r11d
 1f7c240:	mov    (%rcx,%r11,4),%ebx
 1f7c244:	mov    %r11d,%r14d
 1f7c247:	shl    $0xe,%r14d
 1f7c24b:	add    %rdx,%r14
 1f7c24e:	mov    %ebp,(%r14,%rbx,4)
 1f7c252:	inc    %ebx
 1f7c254:	mov    %ebx,(%rcx,%r11,4)
 1f7c258:	movzbl 0x6(%rax,%r9,1),%r11d
 1f7c25e:	mov    0x18(%rdi,%r9,4),%ebp
 1f7c263:	cmp    $0x40,%r11b
 1f7c267:	cmovae %r10d,%r11d
 1f7c26b:	movzbl %r11b,%r11d
 1f7c26f:	mov    (%rcx,%r11,4),%ebx
 1f7c273:	mov    %r11d,%r14d
 1f7c276:	shl    $0xe,%r14d
 1f7c27a:	add    %rdx,%r14
 1f7c27d:	mov    %ebp,(%r14,%rbx,4)
 1f7c281:	inc    %ebx
 1f7c283:	mov    %ebx,(%rcx,%r11,4)
 1f7c287:	movzbl 0x7(%rax,%r9,1),%r11d
 1f7c28d:	mov    0x1c(%rdi,%r9,4),%ebp
 1f7c292:	cmp    $0x40,%r11b
 1f7c296:	cmovae %r10d,%r11d
 1f7c29a:	add    $0x8,%r9
 1f7c29e:	movzbl %r11b,%r11d
 1f7c2a2:	mov    (%rcx,%r11,4),%ebx
 1f7c2a6:	mov    %r11d,%r14d
 1f7c2a9:	shl    $0xe,%r14d
 1f7c2ad:	add    %rdx,%r14
 1f7c2b0:	mov    %ebp,(%r14,%rbx,4)
 1f7c2b4:	inc    %ebx
 1f7c2b6:	mov    %ebx,(%rcx,%r11,4)
 1f7c2ba:	cmp    %r9,%r8
 1f7c2bd:	jne    1f7c140 <node_facts_window+0x340>
 1f7c2c3:	mov    0x20(%rsp),%r12
 1f7c2c8:	test   %rsi,%rsi
 1f7c2cb:	je     1f7ca2f <node_facts_window+0xc2f>
 1f7c2d1:	lea    (%rdi,%r9,4),%rdi
 1f7c2d5:	add    %r9,%rax
 1f7c2d8:	mov    $0x40,%r9d
 1f7c2de:	xor    %r8d,%r8d
 1f7c2e1:	mov    %r13d,%ebp
 1f7c2e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c2f0:	movzbl (%rax,%r8,1),%r10d
 1f7c2f5:	mov    (%rdi,%r8,4),%ebx
 1f7c2f9:	cmp    $0x40,%r10b
 1f7c2fd:	cmovae %r9d,%r10d
 1f7c301:	inc    %r8
 1f7c304:	movzbl %r10b,%r10d
 1f7c308:	mov    (%rcx,%r10,4),%r11d
 1f7c30c:	mov    %r10d,%r14d
 1f7c30f:	shl    $0xe,%r14d
 1f7c313:	add    %rdx,%r14
 1f7c316:	mov    %ebx,(%r14,%r11,4)
 1f7c31a:	inc    %r11d
 1f7c31d:	mov    %r11d,(%rcx,%r10,4)
 1f7c321:	cmp    %r8,%rsi
 1f7c324:	jne    1f7c2f0 <node_facts_window+0x4f0>
 1f7c326:	mov    0x30(%rsp),%r13
 1f7c32b:	cmpl   $0x0,0xc(%rsp)
 1f7c330:	je     1f7c0f3 <node_facts_window+0x2f3>
 1f7c336:	mov    0x38(%rsp),%rdx
 1f7c33b:	mov    %r12,%rdi
 1f7c33e:	mov    %r13d,%esi
 1f7c341:	vzeroupper
 1f7c344:	call   1f85180 <node_facts_leaves_lean>
 1f7c349:	test   %bpl,%bpl
 1f7c34c:	je     1f7c10f <node_facts_window+0x30f>
 1f7c352:	rdtsc
 1f7c354:	mov    %rdx,%rbx
 1f7c357:	shl    $0x20,%rbx
 1f7c35b:	or     %rax,%rbx
 1f7c35e:	cmpl   $0x0,0x2c(%rsp)
 1f7c363:	je     1f7c9c9 <node_facts_window+0xbc9>
 1f7c369:	lea    0x2e8(%r12),%r14
 1f7c371:	mov    %r15d,0x44(%rsp)
 1f7c376:	mov    %rbx,0x78(%rsp)
 1f7c37b:	mov    %ebp,0x48(%rsp)
 1f7c37f:	xor    %ecx,%ecx
 1f7c381:	xor    %r15d,%r15d
 1f7c384:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c390:	mov    %rcx,0x70(%rsp)
 1f7c395:	mov    (%r14),%ecx
 1f7c398:	mov    0x4(%r14),%ebp
 1f7c39c:	mov    0x8(%r14),%eax
 1f7c3a0:	mov    0xc(%r14),%edx
 1f7c3a4:	mov    0x10(%r14),%esi
 1f7c3a8:	vmovups 0x1c(%r14),%ymm0
 1f7c3ae:	test   %ecx,%ecx
 1f7c3b0:	mov    %edx,0x50(%rsp)
 1f7c3b4:	mov    %esi,0x54(%rsp)
 1f7c3b8:	mov    %eax,0x4c(%rsp)
 1f7c3bc:	setne  0x1b(%rsp)
 1f7c3c1:	test   %ebp,%ebp
 1f7c3c3:	setne  0x1a(%rsp)
 1f7c3c8:	test   %eax,%eax
 1f7c3ca:	setne  0x1c(%rsp)
 1f7c3cf:	test   %edx,%edx
 1f7c3d1:	mov    0x14(%r14),%edx
 1f7c3d5:	vmovups %ymm0,0x80(%rsp)
 1f7c3de:	setne  0x1f(%rsp)
 1f7c3e3:	test   %esi,%esi
 1f7c3e5:	mov    0x18(%r14),%esi
 1f7c3e9:	setne  0x19(%rsp)
 1f7c3ee:	xor    %ebx,%ebx
 1f7c3f0:	test   %edx,%edx
 1f7c3f2:	mov    %edx,0x58(%rsp)
 1f7c3f6:	mov    0x68(%rsp),%rdx
 1f7c3fb:	setne  0x1e(%rsp)
 1f7c400:	xor    %r12d,%r12d
 1f7c403:	test   %esi,%esi
 1f7c405:	mov    %esi,0x5c(%rsp)
 1f7c409:	setne  0x1d(%rsp)
 1f7c40e:	mov    (%rdx),%rax
 1f7c411:	mov    %rax,0x10(%rsp)
 1f7c416:	test   %ecx,%ecx
 1f7c418:	je     1f7c440 <node_facts_window+0x640>
 1f7c41a:	mov    0x10(%rsp),%rax
 1f7c41f:	lea    (%rax,%r15,1),%rdx
 1f7c423:	mov    0xc(%rsp),%eax
 1f7c427:	test   %eax,%eax
 1f7c429:	je     1f7c450 <node_facts_window+0x650>
 1f7c42b:	cmp    $0x1,%eax
 1f7c42e:	jne    1f7c48c <node_facts_window+0x68c>
 1f7c430:	mov    0x20(%rsp),%rdi
 1f7c435:	mov    %r13d,%esi
 1f7c438:	vzeroupper
 1f7c43b:	call   1f85500 <node_facts_arrows_lean>
 1f7c440:	test   %ebp,%ebp
 1f7c442:	mov    0x20(%rsp),%rbp
 1f7c447:	jne    1f7c4a5 <node_facts_window+0x6a5>
 1f7c449:	jmp    1f7c4ee <node_facts_window+0x6ee>
 1f7c44e:	xchg   %ax,%ax
 1f7c450:	mov    0x20(%rsp),%r13
 1f7c455:	mov    0x30(%rsp),%rsi
 1f7c45a:	mov    %r13,%rdi
 1f7c45d:	vzeroupper
 1f7c460:	call   1f85230 <node_facts_arrows>
 1f7c465:	test   %ebp,%ebp
 1f7c467:	mov    %r13,%rbp
 1f7c46a:	mov    0x30(%rsp),%r13
 1f7c46f:	je     1f7c4ee <node_facts_window+0x6ee>
 1f7c471:	mov    0x70(%rsp),%rdx
 1f7c476:	mov    0x4(%r14),%ecx
 1f7c47a:	shl    $0x12,%rdx
 1f7c47e:	add    0x10(%rsp),%rdx
 1f7c483:	add    $0x4000,%rdx
 1f7c48a:	jmp    1f7c4e0 <node_facts_window+0x6e0>
 1f7c48c:	mov    0x20(%rsp),%rdi
 1f7c491:	mov    %r13d,%esi
 1f7c494:	vzeroupper
 1f7c497:	call   1f85780 <node_facts_arrows_loads>
 1f7c49c:	test   %ebp,%ebp
 1f7c49e:	mov    0x20(%rsp),%rbp
 1f7c4a3:	je     1f7c4ee <node_facts_window+0x6ee>
 1f7c4a5:	mov    0x10(%rsp),%rax
 1f7c4aa:	mov    0x4(%r14),%ecx
 1f7c4ae:	lea    0x4000(%rax,%r15,1),%rdx
 1f7c4b6:	mov    0xc(%rsp),%eax
 1f7c4ba:	test   %eax,%eax
 1f7c4bc:	je     1f7c4e0 <node_facts_window+0x6e0>
 1f7c4be:	mov    %rbp,%rdi
 1f7c4c1:	mov    %r13d,%esi
 1f7c4c4:	cmp    $0x1,%eax
 1f7c4c7:	jne    1f7c544 <node_facts_window+0x744>
 1f7c4c9:	vzeroupper
 1f7c4cc:	call   1f85de0 <node_facts_subscripts_lean>
 1f7c4d1:	cmpl   $0x0,0x4c(%rsp)
 1f7c4d6:	jne    1f7c4f5 <node_facts_window+0x6f5>
 1f7c4d8:	jmp    1f7c560 <node_facts_window+0x760>
 1f7c4dd:	nopl   (%rax)
 1f7c4e0:	mov    %rbp,%rdi
 1f7c4e3:	mov    %r13d,%esi
 1f7c4e6:	vzeroupper
 1f7c4e9:	call   1f85960 <node_facts_subscripts>
 1f7c4ee:	cmpl   $0x0,0x4c(%rsp)
 1f7c4f3:	je     1f7c560 <node_facts_window+0x760>
 1f7c4f5:	mov    0x10(%rsp),%rax
 1f7c4fa:	mov    0x8(%r14),%ecx
 1f7c4fe:	mov    %rbp,%rdi
 1f7c501:	mov    %r13d,%esi
 1f7c504:	lea    0x8000(%rax,%r15,1),%rdx
 1f7c50c:	mov    0xc(%rsp),%eax
 1f7c510:	test   %eax,%eax
 1f7c512:	je     1f7c530 <node_facts_window+0x730>
 1f7c514:	cmp    $0x1,%eax
 1f7c517:	jne    1f7c53a <node_facts_window+0x73a>
 1f7c519:	vzeroupper
 1f7c51c:	call   1f867b0 <node_facts_dots_lean>
 1f7c521:	jmp    1f7c560 <node_facts_window+0x760>
 1f7c523:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c530:	vzeroupper
 1f7c533:	call   1f86480 <node_facts_dots>
 1f7c538:	jmp    1f7c560 <node_facts_window+0x760>
 1f7c53a:	vzeroupper
 1f7c53d:	call   1f86ab0 <node_facts_dots_loads>
 1f7c542:	jmp    1f7c560 <node_facts_window+0x760>
 1f7c544:	vzeroupper
 1f7c547:	call   1f861c0 <node_facts_subscripts_loads>
 1f7c54c:	cmpl   $0x0,0x4c(%rsp)
 1f7c551:	jne    1f7c4f5 <node_facts_window+0x6f5>
 1f7c553:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c560:	cmpl   $0x0,0x50(%rsp)
 1f7c565:	je     1f7c592 <node_facts_window+0x792>
 1f7c567:	mov    0x10(%rsp),%rax
 1f7c56c:	xor    %r8d,%r8d
 1f7c56f:	cmpl   $0x0,0xc(%rsp)
 1f7c574:	mov    0xc(%r14),%ecx
 1f7c578:	mov    %rbp,%rdi
 1f7c57b:	mov    %r13d,%esi
 1f7c57e:	lea    0xc000(%rax,%r15,1),%rdx
 1f7c586:	setne  %r8b
 1f7c58a:	vzeroupper
 1f7c58d:	call   1f86ca0 <node_facts_addresses_made>
 1f7c592:	cmpl   $0x0,0x54(%rsp)
 1f7c597:	je     1f7c5c4 <node_facts_window+0x7c4>
 1f7c599:	mov    0x10(%rsp),%rax
 1f7c59e:	xor    %r8d,%r8d
 1f7c5a1:	cmpl   $0x0,0xc(%rsp)
 1f7c5a6:	mov    0x10(%r14),%ecx
 1f7c5aa:	mov    %rbp,%rdi
 1f7c5ad:	mov    %r13d,%esi
 1f7c5b0:	lea    0x10000(%rax,%r15,1),%rdx
 1f7c5b8:	setne  %r8b
 1f7c5bc:	vzeroupper
 1f7c5bf:	call   1f86eb0 <node_facts_casts>
 1f7c5c4:	cmpl   $0x0,0x58(%rsp)
 1f7c5c9:	je     1f7c5ea <node_facts_window+0x7ea>
 1f7c5cb:	mov    0x10(%rsp),%rax
 1f7c5d0:	mov    0x14(%r14),%ecx
 1f7c5d4:	mov    %rbp,%rdi
 1f7c5d7:	mov    %r13d,%esi
 1f7c5da:	lea    0x14000(%rax,%r15,1),%rdx
 1f7c5e2:	vzeroupper
 1f7c5e5:	call   1f87470 <node_facts_slow_list>
 1f7c5ea:	cmpl   $0x0,0x5c(%rsp)
 1f7c5ef:	je     1f7c61c <node_facts_window+0x81c>
 1f7c5f1:	mov    0x10(%rsp),%rax
 1f7c5f6:	xor    %r8d,%r8d
 1f7c5f9:	cmpl   $0x0,0xc(%rsp)
 1f7c5fe:	mov    0x18(%r14),%ecx
 1f7c602:	mov    %rbp,%rdi
 1f7c605:	mov    %r13d,%esi
 1f7c608:	lea    0x18000(%rax,%r15,1),%rdx
 1f7c610:	setne  %r8b
 1f7c614:	vzeroupper
 1f7c617:	call   1f874b0 <node_facts_rows_made>
 1f7c61c:	movzbl 0x1b(%rsp),%ecx
 1f7c621:	movzbl 0x1a(%rsp),%edx
 1f7c626:	xor    %eax,%eax
 1f7c628:	movzbl 0x1f(%rsp),%esi
 1f7c62d:	vmovdqu 0x80(%rsp),%ymm0
 1f7c636:	mov    %cl,%al
 1f7c638:	xor    %ecx,%ecx
 1f7c63a:	mov    %dl,%cl
 1f7c63c:	movzbl 0x1c(%rsp),%edx
 1f7c641:	lea    (%rax,%rcx,2),%eax
 1f7c644:	xor    %ecx,%ecx
 1f7c646:	vptestnmd %ymm0,%ymm0,%k1
 1f7c64c:	mov    %dl,%cl
 1f7c64e:	xor    %edx,%edx
 1f7c650:	lea    (%rax,%rcx,4),%eax
 1f7c653:	movzbl 0x19(%rsp),%ecx
 1f7c658:	kshiftrb $0x1,%k1,%k0
 1f7c65e:	kmovw  %k1,0x80(%rsp)
 1f7c667:	mov    %cl,%dl
 1f7c669:	xor    %ecx,%ecx
 1f7c66b:	mov    %sil,%cl
 1f7c66e:	lea    (%rax,%rcx,8),%eax
 1f7c671:	movzbl 0x1e(%rsp),%ecx
 1f7c676:	shl    $0x4,%edx
 1f7c679:	or     %edx,%eax
 1f7c67b:	mov    %cl,%bl
 1f7c67d:	kmovd  %k1,%ecx
 1f7c681:	shl    $0x5,%ebx
 1f7c684:	not    %cl
 1f7c686:	or     %eax,%ebx
 1f7c688:	movzbl 0x1d(%rsp),%eax
 1f7c68d:	movzbl %cl,%ecx
 1f7c690:	and    $0x1,%ecx
 1f7c693:	shl    $0x7,%ecx
 1f7c696:	mov    %al,%r12b
 1f7c699:	kmovd  %k0,%eax
 1f7c69d:	shl    $0x6,%r12d
 1f7c6a1:	not    %al
 1f7c6a3:	or     %ebx,%r12d
 1f7c6a6:	movzbl %al,%ebx
 1f7c6a9:	and    $0x1,%ebx
 1f7c6ac:	shl    $0x8,%ebx
 1f7c6af:	or     %ecx,%ebx
 1f7c6b1:	or     %r12d,%ebx
 1f7c6b4:	mov    0xc(%rsp),%r12d
 1f7c6b9:	test   %bl,%bl
 1f7c6bb:	jns    1f7c700 <node_facts_window+0x900>
 1f7c6bd:	mov    0x10(%rsp),%rax
 1f7c6c2:	mov    0x1c(%r14),%ecx
 1f7c6c6:	mov    %rbp,%rdi
 1f7c6c9:	mov    %r13d,%esi
 1f7c6cc:	lea    0x1c000(%rax,%r15,1),%rdx
 1f7c6d4:	test   %r12d,%r12d
 1f7c6d7:	je     1f7c6f5 <node_facts_window+0x8f5>
 1f7c6d9:	cmp    $0x1,%r12d
 1f7c6dd:	jne    1f7c7e3 <node_facts_window+0x9e3>
 1f7c6e3:	vzeroupper
 1f7c6e6:	call   1f88200 <node_facts_calls_lean>
 1f7c6eb:	test   $0x100,%ebx
 1f7c6f1:	jne    1f7c708 <node_facts_window+0x908>
 1f7c6f3:	jmp    1f7c731 <node_facts_window+0x931>
 1f7c6f5:	vzeroupper
 1f7c6f8:	call   1f87850 <node_facts_calls>
 1f7c6fd:	nopl   (%rax)
 1f7c700:	test   $0x100,%ebx
 1f7c706:	je     1f7c731 <node_facts_window+0x931>
 1f7c708:	mov    0x10(%rsp),%rax
 1f7c70d:	mov    0x20(%r14),%ecx
 1f7c711:	xor    %r8d,%r8d
 1f7c714:	test   %r12d,%r12d
 1f7c717:	mov    %rbp,%rdi
 1f7c71a:	mov    %r13d,%esi
 1f7c71d:	setne  %r8b
 1f7c721:	lea    0x20000(%rax,%r15,1),%rdx
 1f7c729:	vzeroupper
 1f7c72c:	call   1f88dc0 <node_facts_logics>
 1f7c731:	kmovw  0x80(%rsp),%k1
 1f7c73a:	kshiftrb $0x3,%k1,%k0
 1f7c740:	kmovd  %k0,%eax
 1f7c744:	kshiftrb $0x2,%k1,%k0
 1f7c74a:	kmovd  %k0,%ecx
 1f7c74e:	not    %al
 1f7c750:	not    %cl
 1f7c752:	movzbl %al,%ebp
 1f7c755:	movzbl %cl,%ecx
 1f7c758:	and    $0x1,%ebp
 1f7c75b:	and    $0x1,%ecx
 1f7c75e:	shl    $0xa,%ebp
 1f7c761:	shl    $0x9,%ecx
 1f7c764:	or     %ecx,%ebp
 1f7c766:	or     %ebx,%ebp
 1f7c768:	test   $0x200,%ebp
 1f7c76e:	je     1f7c79b <node_facts_window+0x99b>
 1f7c770:	mov    0x10(%rsp),%rax
 1f7c775:	mov    0x24(%r14),%ecx
 1f7c779:	mov    0x20(%rsp),%rdi
 1f7c77e:	xor    %r8d,%r8d
 1f7c781:	test   %r12d,%r12d
 1f7c784:	mov    %r13d,%esi
 1f7c787:	setne  %r8b
 1f7c78b:	lea    0x24000(%rax,%r15,1),%rdx
 1f7c793:	vzeroupper
 1f7c796:	call   1f89080 <node_facts_updates>
 1f7c79b:	test   $0x400,%ebp
 1f7c7a1:	je     1f7c810 <node_facts_window+0xa10>
 1f7c7a3:	mov    0x10(%rsp),%rax
 1f7c7a8:	mov    0x28(%r14),%ecx
 1f7c7ac:	lea    0x28000(%rax,%r15,1),%rdx
 1f7c7b4:	test   %r12d,%r12d
 1f7c7b7:	je     1f7c7d1 <node_facts_window+0x9d1>
 1f7c7b9:	cmp    $0x1,%r12d
 1f7c7bd:	jne    1f7c7fc <node_facts_window+0x9fc>
 1f7c7bf:	mov    0x20(%rsp),%rdi
 1f7c7c4:	mov    %r13d,%esi
 1f7c7c7:	vzeroupper
 1f7c7ca:	call   1f89cb0 <node_facts_dereferences_lean>
 1f7c7cf:	jmp    1f7c810 <node_facts_window+0xa10>
 1f7c7d1:	mov    0x20(%rsp),%rdi
 1f7c7d6:	mov    %r13d,%esi
 1f7c7d9:	vzeroupper
 1f7c7dc:	call   1f89a60 <node_facts_dereferences>
 1f7c7e1:	jmp    1f7c810 <node_facts_window+0xa10>
 1f7c7e3:	vzeroupper
 1f7c7e6:	call   1f88b10 <node_facts_calls_loads>
 1f7c7eb:	test   $0x100,%ebx
 1f7c7f1:	jne    1f7c708 <node_facts_window+0x908>
 1f7c7f7:	jmp    1f7c731 <node_facts_window+0x931>
 1f7c7fc:	mov    0x20(%rsp),%rdi
 1f7c801:	mov    %r13d,%esi
 1f7c804:	vzeroupper
 1f7c807:	call   1f89ea0 <node_facts_dereferences_loads>
 1f7c80c:	nopl   0x0(%rax)
 1f7c810:	kmovw  0x80(%rsp),%k1
 1f7c819:	mov    0x20(%rsp),%r12
 1f7c81e:	kshiftrb $0x5,%k1,%k0
 1f7c824:	kmovd  %k0,%eax
 1f7c828:	kshiftrb $0x4,%k1,%k0
 1f7c82e:	kmovd  %k0,%ecx
 1f7c832:	not    %al
 1f7c834:	not    %cl
 1f7c836:	movzbl %al,%ebx
 1f7c839:	movzbl %cl,%ecx
 1f7c83c:	and    $0x1,%ebx
 1f7c83f:	and    $0x1,%ecx
 1f7c842:	shl    $0xc,%ebx
 1f7c845:	shl    $0xb,%ecx
 1f7c848:	or     %ecx,%ebx
 1f7c84a:	or     %ebp,%ebx
 1f7c84c:	test   $0x800,%ebx
 1f7c852:	je     1f7c87f <node_facts_window+0xa7f>
 1f7c854:	mov    0x10(%rsp),%rax
 1f7c859:	xor    %r8d,%r8d
 1f7c85c:	cmpl   $0x0,0xc(%rsp)
 1f7c861:	mov    0x2c(%r14),%ecx
 1f7c865:	mov    %r12,%rdi
 1f7c868:	mov    %r13d,%esi
 1f7c86b:	lea    0x2c000(%rax,%r15,1),%rdx
 1f7c873:	setne  %r8b
 1f7c877:	vzeroupper
 1f7c87a:	call   1f8a060 <node_facts_stores>
 1f7c87f:	test   $0x1000,%ebx
 1f7c885:	je     1f7c8b2 <node_facts_window+0xab2>
 1f7c887:	mov    0x10(%rsp),%rax
 1f7c88c:	xor    %r8d,%r8d
 1f7c88f:	cmpl   $0x0,0xc(%rsp)
 1f7c894:	mov    0x30(%r14),%ecx
 1f7c898:	mov    %r12,%rdi
 1f7c89b:	mov    %r13d,%esi
 1f7c89e:	lea    0x30000(%rax,%r15,1),%rdx
 1f7c8a6:	setne  %r8b
 1f7c8aa:	vzeroupper
 1f7c8ad:	call   1f8a650 <node_facts_converts>
 1f7c8b2:	kmovw  0x80(%rsp),%k1
 1f7c8bb:	kshiftrb $0x7,%k1,%k0
 1f7c8c1:	kmovd  %k0,%eax
 1f7c8c5:	kshiftrb $0x6,%k1,%k0
 1f7c8cb:	kmovd  %k0,%ecx
 1f7c8cf:	not    %al
 1f7c8d1:	not    %cl
 1f7c8d3:	movzbl %al,%ebp
 1f7c8d6:	movzbl %cl,%ecx
 1f7c8d9:	and    $0x1,%ebp
 1f7c8dc:	and    $0x1,%ecx
 1f7c8df:	shl    $0xe,%ebp
 1f7c8e2:	shl    $0xd,%ecx
 1f7c8e5:	or     %ecx,%ebp
 1f7c8e7:	or     %ebx,%ebp
 1f7c8e9:	test   $0x2000,%ebp
 1f7c8ef:	jne    1f7c910 <node_facts_window+0xb10>
 1f7c8f1:	mov    0x20(%rsp),%r12
 1f7c8f6:	cmp    $0x4000,%ebp
 1f7c8fc:	jae    1f7c93e <node_facts_window+0xb3e>
 1f7c8fe:	mov    0x70(%rsp),%rcx
 1f7c903:	cmp    $0x2,%rcx
 1f7c907:	jbe    1f7c974 <node_facts_window+0xb74>
 1f7c909:	jmp    1f7c991 <node_facts_window+0xb91>
 1f7c90e:	xchg   %ax,%ax
 1f7c910:	mov    0x10(%rsp),%rax
 1f7c915:	mov    0x34(%r14),%ecx
 1f7c919:	mov    0x20(%rsp),%rdi
 1f7c91e:	mov    %r13d,%esi
 1f7c921:	lea    0x34000(%rax,%r15,1),%rdx
 1f7c929:	vzeroupper
 1f7c92c:	call   1f8abd0 <node_facts_discards>
 1f7c931:	mov    0x20(%rsp),%r12
 1f7c936:	cmp    $0x4000,%ebp
 1f7c93c:	jb     1f7c8fe <node_facts_window+0xafe>
 1f7c93e:	mov    0x10(%rsp),%rax
 1f7c943:	xor    %r8d,%r8d
 1f7c946:	cmpl   $0x0,0xc(%rsp)
 1f7c94b:	mov    0x38(%r14),%ecx
 1f7c94f:	mov    %r12,%rdi
 1f7c952:	mov    %r13d,%esi
 1f7c955:	lea    0x38000(%rax,%r15,1),%rdx
 1f7c95d:	setne  %r8b
 1f7c961:	vzeroupper
 1f7c964:	call   1f8ad80 <node_facts_truths>
 1f7c969:	mov    0x70(%rsp),%rcx
 1f7c96e:	cmp    $0x2,%rcx
 1f7c972:	ja     1f7c991 <node_facts_window+0xb91>
 1f7c974:	inc    %rcx
 1f7c977:	add    $0x40000,%r15
 1f7c97e:	add    $0x40,%r14
 1f7c982:	shrx   %ecx,0x2c(%rsp),%eax
 1f7c989:	test   %eax,%eax
 1f7c98b:	jne    1f7c390 <node_facts_window+0x590>
 1f7c991:	testb  $0x10,0x2c(%rsp)
 1f7c996:	mov    0x48(%rsp),%ebp
 1f7c99a:	mov    0x44(%rsp),%r15d
 1f7c99f:	mov    0x78(%rsp),%rbx
 1f7c9a4:	je     1f7c9c9 <node_facts_window+0xbc9>
 1f7c9a6:	mov    $0x100000,%edx
 1f7c9ab:	add    0x2e0(%r12),%rdx
 1f7c9b3:	mov    0x3e8(%r12),%ecx
 1f7c9bb:	mov    %r12,%rdi
 1f7c9be:	mov    %r13d,%esi
 1f7c9c1:	vzeroupper
 1f7c9c4:	call   1f87470 <node_facts_slow_list>
 1f7c9c9:	test   %bpl,%bpl
 1f7c9cc:	je     1f7c9d9 <node_facts_window+0xbd9>
 1f7c9ce:	rdtsc
 1f7c9d0:	shl    $0x20,%rdx
 1f7c9d4:	or     %rax,%rdx
 1f7c9d7:	jmp    1f7c9db <node_facts_window+0xbdb>
 1f7c9d9:	xor    %edx,%edx
 1f7c9db:	sub    %rbx,%rdx
 1f7c9de:	sub    0x60(%rsp),%rbx
 1f7c9e3:	mov    0x38(%rsp),%rax
 1f7c9e8:	vmovq  %rdx,%xmm0
 1f7c9ed:	vmovq  %rbx,%xmm1
 1f7c9f2:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f7c9f6:	vpaddq 0x910(%r12),%xmm0,%xmm0
 1f7ca00:	vmovdqu %xmm0,0x910(%r12)
 1f7ca0a:	mov    %eax,0x930(%r12)
 1f7ca12:	mov    %r15d,0x934(%r12)
 1f7ca1a:	add    $0xa8,%rsp
 1f7ca21:	pop    %rbx
 1f7ca22:	pop    %r12
 1f7ca24:	pop    %r13
 1f7ca26:	pop    %r14
 1f7ca28:	pop    %r15
 1f7ca2a:	pop    %rbp
 1f7ca2b:	vzeroupper
 1f7ca2e:	ret
 1f7ca2f:	mov    %r13d,%ebp
 1f7ca32:	mov    0x30(%rsp),%r13
 1f7ca37:	cmpl   $0x0,0xc(%rsp)
 1f7ca3c:	jne    1f7c336 <node_facts_window+0x536>
 1f7ca42:	jmp    1f7c0f3 <node_facts_window+0x2f3>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
