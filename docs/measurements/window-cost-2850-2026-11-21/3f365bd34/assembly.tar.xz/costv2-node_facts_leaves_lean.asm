
results/costv2/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f85020 <node_facts_leaves_lean>:
 1f85020:	test   %edx,%edx
 1f85022:	je     1f850c9 <node_facts_leaves_lean+0xa9>
 1f85028:	push   %rbp
 1f85029:	push   %r15
 1f8502b:	push   %r14
 1f8502d:	push   %r13
 1f8502f:	push   %r12
 1f85031:	push   %rbx
 1f85032:	sub    $0x18,%rsp
 1f85036:	mov    0x2c0(%rdi),%rax
 1f8503d:	mov    0x2c8(%rdi),%r15
 1f85044:	mov    0x28(%rdi),%rbp
 1f85048:	mov    %rdi,%rbx
 1f8504b:	mov    %edx,%r14d
 1f8504e:	xor    %r12d,%r12d
 1f85051:	mov    %rax,0x10(%rsp)
 1f85056:	mov    %esi,%eax
 1f85058:	lea    0x0(,%rax,4),%r13
 1f85060:	add    0x220(%rdi),%r13
 1f85067:	mov    %rax,0x8(%rsp)
 1f8506c:	jmp    1f8508c <node_facts_leaves_lean+0x6c>
 1f8506e:	xchg   %ax,%ax
 1f85070:	vmovups 0x0(%rbp,%rax,1),%ymm0
 1f85076:	mov    0x10(%rsp),%rax
 1f8507b:	shl    $0x6,%rdx
 1f8507f:	vmovups %ymm0,(%rax,%rdx,1)
 1f85084:	inc    %r12
 1f85087:	cmp    %r12,%r14
 1f8508a:	je     1f850bb <node_facts_leaves_lean+0x9b>
 1f8508c:	mov    (%r15,%r12,4),%edx
 1f85090:	mov    0x0(%r13,%rdx,4),%eax
 1f85095:	shl    $0x5,%rax
 1f85099:	cmpl   $0x0,0x1c(%rbp,%rax,1)
 1f8509e:	je     1f85070 <node_facts_leaves_lean+0x50>
 1f850a0:	mov    %rdx,%rsi
 1f850a3:	add    0x8(%rsp),%rsi
 1f850a8:	mov    %rbx,%rdi
 1f850ab:	vzeroupper
 1f850ae:	call   1f8adf0 <node_facts_leave>
 1f850b3:	inc    %r12
 1f850b6:	cmp    %r12,%r14
 1f850b9:	jne    1f8508c <node_facts_leaves_lean+0x6c>
 1f850bb:	add    $0x18,%rsp
 1f850bf:	pop    %rbx
 1f850c0:	pop    %r12
 1f850c2:	pop    %r13
 1f850c4:	pop    %r14
 1f850c6:	pop    %r15
 1f850c8:	pop    %rbp
 1f850c9:	vzeroupper
 1f850cc:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
