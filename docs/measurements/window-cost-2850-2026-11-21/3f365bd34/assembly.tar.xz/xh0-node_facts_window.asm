
results/xh0/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f7ae80 <node_facts_window>:
 1f7ae80:	push   %rbp
 1f7ae81:	push   %r15
 1f7ae83:	push   %r14
 1f7ae85:	push   %r13
 1f7ae87:	push   %r12
 1f7ae89:	push   %rbx
 1f7ae8a:	sub    $0xa8,%rsp
 1f7ae91:	mov    0x248(%rdi),%rax
 1f7ae98:	mov    %ecx,%ebp
 1f7ae9a:	mov    %esi,%ecx
 1f7ae9c:	inc    %esi
 1f7ae9e:	mov    %edx,0xc(%rsp)
 1f7aea2:	mov    %rdi,%r12
 1f7aea5:	mov    (%rax,%rcx,4),%r13d
 1f7aea9:	mov    (%rax,%rsi,4),%r8d
 1f7aead:	test   %ebp,%ebp
 1f7aeaf:	je     1f7b0ef <node_facts_window+0x26f>
 1f7aeb5:	rdtsc
 1f7aeb7:	shl    $0x20,%rdx
 1f7aebb:	or     %rax,%rdx
 1f7aebe:	mov    %rdx,0x60(%rsp)
 1f7aec3:	mov    %r12,0x20(%rsp)
 1f7aec8:	mov    %r13,0x30(%rsp)
 1f7aecd:	cmp    %r13d,%r8d
 1f7aed0:	je     1f7b10b <node_facts_window+0x28b>
 1f7aed6:	vmovdqa64 -0x1ac47e0(%rip),%zmm1        # 4b6700 <abi_test_hex.digits+0xb380>
 1f7aee0:	vpbroadcastb -0x1ac47a9(%rip),%xmm2        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7aee9:	vpbroadcastb -0x1ac47b1(%rip),%xmm3        # 4b6741 <abi_test_hex.digits+0xb3c1>
 1f7aef2:	vpbroadcastq -0x19aee3b(%rip),%xmm4        # 5cc0c0 <.LCPI0_8>
 1f7aefb:	vpbroadcastd -0x19ac421(%rip),%zmm5        # 5ceae4 <.LCPI0_4>
 1f7af05:	vpbroadcastd -0x19ac427(%rip),%zmm6        # 5ceae8 <.LCPI0_5>
 1f7af0f:	mov    0x1f8(%r12),%rsi
 1f7af17:	mov    0x200(%r12),%rdi
 1f7af1f:	mov    0x2c8(%r12),%rax
 1f7af27:	mov    0x2d0(%r12),%rcx
 1f7af2f:	mov    0x2d8(%r12),%rdx
 1f7af37:	mov    %r13,%r9
 1f7af3a:	sub    %r9d,%r8d
 1f7af3d:	mov    $0x10,%r10d
 1f7af43:	mov    $0xffffffff,%r11d
 1f7af49:	mov    %ebp,%r13d
 1f7af4c:	vpxor  %xmm0,%xmm0,%xmm0
 1f7af50:	xor    %r12d,%r12d
 1f7af53:	xor    %ebx,%ebx
 1f7af55:	xor    %r15d,%r15d
 1f7af58:	mov    %r8d,%ebp
 1f7af5b:	add    %r9,%rsi
 1f7af5e:	add    %r9,%rdi
 1f7af61:	mov    %r8d,%r9d
 1f7af64:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7af70:	sub    $0x10,%ebp
 1f7af73:	mov    %r15d,%r14d
 1f7af76:	mov    %r12d,%r15d
 1f7af79:	cmovae %r10d,%r8d
 1f7af7d:	shlx   %r8d,%r11d,%r8d
 1f7af82:	not    %r8d
 1f7af85:	kmovd  %r8d,%k1
 1f7af8a:	mov    %r12d,%r8d
 1f7af8d:	vmovdqu8 (%rsi,%rbx,1),%xmm7{%k1}{z}
 1f7af94:	vpand  %xmm2,%xmm7,%xmm7
 1f7af98:	vpcmpeqb %xmm3,%xmm7,%k2{%k1}
 1f7af9e:	vpcmpeqb %xmm2,%xmm7,%k1{%k1}
 1f7afa4:	vmovdqu8 (%rdi,%rbx,1),%xmm7{%k1}{z}
 1f7afab:	vpxor  %xmm8,%xmm8,%xmm8
 1f7afb0:	vpcompressd %zmm1,%zmm8{%k2}{z}
 1f7afb6:	vpxor  %xmm10,%xmm10,%xmm10
 1f7afbb:	vpcompressd %zmm1,%zmm10{%k1}{z}
 1f7afc1:	vpaddd %zmm6,%zmm1,%zmm1
 1f7afc7:	add    $0x10,%rbx
 1f7afcb:	vmovdqu64 %zmm8,(%rax,%r8,4)
 1f7afd2:	mov    %r14d,%r8d
 1f7afd5:	vmovdqu64 %zmm10,(%rcx,%r8,4)
 1f7afdc:	vxorps %xmm9,%xmm9,%xmm9
 1f7afe1:	vpcompressb %xmm7,%xmm9{%k1}{z}
 1f7afe7:	vgf2p8affineqb $0x0,%xmm4,%xmm7,%xmm7
 1f7afed:	vmovdqu %xmm9,(%rdx,%r8,1)
 1f7aff3:	kmovw  %k2,%r8d
 1f7aff7:	vpmovzxbd %xmm7,%zmm7
 1f7affd:	popcnt %r8d,%r12d
 1f7b002:	kmovw  %k1,%r8d
 1f7b006:	add    %r15d,%r12d
 1f7b009:	popcnt %r8d,%r15d
 1f7b00e:	mov    %ebp,%r8d
 1f7b011:	add    %r14d,%r15d
 1f7b014:	vpsllvd %zmm7,%zmm5,%zmm7{%k1}{z}
 1f7b01a:	vporq  %zmm7,%zmm0,%zmm0
 1f7b020:	cmp    %r9,%rbx
 1f7b023:	jb     1f7af70 <node_facts_window+0xf0>
 1f7b029:	mov    %r12,0x38(%rsp)
 1f7b02e:	mov    0x20(%rsp),%r12
 1f7b033:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f7b03a:	vporq  %zmm1,%zmm0,%zmm0
 1f7b040:	vextracti128 $0x1,%ymm0,%xmm1
 1f7b046:	vpor   %xmm1,%xmm0,%xmm0
 1f7b04a:	vpshufd $0xee,%xmm0,%xmm1
 1f7b04f:	mov    0x2d0(%r12),%rdi
 1f7b057:	mov    0x2d8(%r12),%rax
 1f7b05f:	vpor   %xmm1,%xmm0,%xmm0
 1f7b063:	lea    0x2e0(%r12),%rcx
 1f7b06b:	movl   $0x0,0x3e8(%r12)
 1f7b077:	vpshufd $0x55,%xmm0,%xmm1
 1f7b07c:	mov    %rcx,0x68(%rsp)
 1f7b081:	vpor   %xmm1,%xmm0,%xmm0
 1f7b085:	vmovd  %xmm0,0x2c(%rsp)
 1f7b08b:	vpxor  %xmm0,%xmm0,%xmm0
 1f7b08f:	vmovdqu64 %zmm0,0x2e8(%r12)
 1f7b09a:	vmovdqu64 %zmm0,0x328(%r12)
 1f7b0a5:	vmovdqu64 %zmm0,0x368(%r12)
 1f7b0b0:	vmovdqu64 %zmm0,0x3a8(%r12)
 1f7b0bb:	test   %r15d,%r15d
 1f7b0be:	je     1f7b1a1 <node_facts_window+0x321>
 1f7b0c4:	mov    0x2e0(%r12),%rdx
 1f7b0cc:	mov    %r15d,%r8d
 1f7b0cf:	mov    %r8d,%esi
 1f7b0d2:	lea    0x2e8(%r12),%rcx
 1f7b0da:	and    $0x7,%esi
 1f7b0dd:	cmp    $0x8,%r15d
 1f7b0e1:	jae    1f7b1a9 <node_facts_window+0x329>
 1f7b0e7:	xor    %r9d,%r9d
 1f7b0ea:	jmp    1f7b351 <node_facts_window+0x4d1>
 1f7b0ef:	movq   $0x0,0x60(%rsp)
 1f7b0f8:	mov    %r12,0x20(%rsp)
 1f7b0fd:	mov    %r13,0x30(%rsp)
 1f7b102:	cmp    %r13d,%r8d
 1f7b105:	jne    1f7aed6 <node_facts_window+0x56>
 1f7b10b:	lea    0x2e0(%r12),%rax
 1f7b113:	vpxor  %xmm0,%xmm0,%xmm0
 1f7b117:	vmovdqu64 %zmm0,0x3a8(%r12)
 1f7b122:	vmovdqu64 %zmm0,0x368(%r12)
 1f7b12d:	vmovdqu64 %zmm0,0x328(%r12)
 1f7b138:	vmovdqu64 %zmm0,0x2e8(%r12)
 1f7b143:	movl   $0x0,0x3e8(%r12)
 1f7b14f:	movq   $0x0,0x38(%rsp)
 1f7b158:	xor    %r15d,%r15d
 1f7b15b:	movl   $0x0,0x2c(%rsp)
 1f7b163:	mov    %rax,0x68(%rsp)
 1f7b168:	cmpl   $0x0,0xc(%rsp)
 1f7b16d:	jne    1f7b3b6 <node_facts_window+0x536>
 1f7b173:	mov    0x38(%rsp),%rdx
 1f7b178:	mov    %r12,%rdi
 1f7b17b:	mov    %r13d,%esi
 1f7b17e:	vzeroupper
 1f7b181:	call   1f83da0 <node_facts_leaves>
 1f7b186:	test   %bpl,%bpl
 1f7b189:	jne    1f7b3d2 <node_facts_window+0x552>
 1f7b18f:	xor    %ebx,%ebx
 1f7b191:	cmpl   $0x0,0x2c(%rsp)
 1f7b196:	jne    1f7b3e9 <node_facts_window+0x569>
 1f7b19c:	jmp    1f7ba49 <node_facts_window+0xbc9>
 1f7b1a1:	xor    %r15d,%r15d
 1f7b1a4:	jmp    1f7baaf <node_facts_window+0xc2f>
 1f7b1a9:	and    $0xfffffff8,%r8d
 1f7b1ad:	mov    $0x40,%r10d
 1f7b1b3:	xor    %r9d,%r9d
 1f7b1b6:	cs nopw 0x0(%rax,%rax,1)
 1f7b1c0:	movzbl (%rax,%r9,1),%r11d
 1f7b1c5:	mov    (%rdi,%r9,4),%ebp
 1f7b1c9:	cmp    $0x40,%r11b
 1f7b1cd:	cmovae %r10d,%r11d
 1f7b1d1:	movzbl %r11b,%r11d
 1f7b1d5:	mov    (%rcx,%r11,4),%ebx
 1f7b1d9:	mov    %r11d,%r14d
 1f7b1dc:	shl    $0xe,%r14d
 1f7b1e0:	add    %rdx,%r14
 1f7b1e3:	mov    %ebp,(%r14,%rbx,4)
 1f7b1e7:	inc    %ebx
 1f7b1e9:	mov    %ebx,(%rcx,%r11,4)
 1f7b1ed:	movzbl 0x1(%rax,%r9,1),%r11d
 1f7b1f3:	mov    0x4(%rdi,%r9,4),%ebp
 1f7b1f8:	cmp    $0x40,%r11b
 1f7b1fc:	cmovae %r10d,%r11d
 1f7b200:	movzbl %r11b,%r11d
 1f7b204:	mov    (%rcx,%r11,4),%ebx
 1f7b208:	mov    %r11d,%r14d
 1f7b20b:	shl    $0xe,%r14d
 1f7b20f:	add    %rdx,%r14
 1f7b212:	mov    %ebp,(%r14,%rbx,4)
 1f7b216:	inc    %ebx
 1f7b218:	mov    %ebx,(%rcx,%r11,4)
 1f7b21c:	movzbl 0x2(%rax,%r9,1),%r11d
 1f7b222:	mov    0x8(%rdi,%r9,4),%ebp
 1f7b227:	cmp    $0x40,%r11b
 1f7b22b:	cmovae %r10d,%r11d
 1f7b22f:	movzbl %r11b,%r11d
 1f7b233:	mov    (%rcx,%r11,4),%ebx
 1f7b237:	mov    %r11d,%r14d
 1f7b23a:	shl    $0xe,%r14d
 1f7b23e:	add    %rdx,%r14
 1f7b241:	mov    %ebp,(%r14,%rbx,4)
 1f7b245:	inc    %ebx
 1f7b247:	mov    %ebx,(%rcx,%r11,4)
 1f7b24b:	movzbl 0x3(%rax,%r9,1),%r11d
 1f7b251:	mov    0xc(%rdi,%r9,4),%ebp
 1f7b256:	cmp    $0x40,%r11b
 1f7b25a:	cmovae %r10d,%r11d
 1f7b25e:	movzbl %r11b,%r11d
 1f7b262:	mov    (%rcx,%r11,4),%ebx
 1f7b266:	mov    %r11d,%r14d
 1f7b269:	shl    $0xe,%r14d
 1f7b26d:	add    %rdx,%r14
 1f7b270:	mov    %ebp,(%r14,%rbx,4)
 1f7b274:	inc    %ebx
 1f7b276:	mov    %ebx,(%rcx,%r11,4)
 1f7b27a:	movzbl 0x4(%rax,%r9,1),%r11d
 1f7b280:	mov    0x10(%rdi,%r9,4),%ebp
 1f7b285:	cmp    $0x40,%r11b
 1f7b289:	cmovae %r10d,%r11d
 1f7b28d:	movzbl %r11b,%r11d
 1f7b291:	mov    (%rcx,%r11,4),%ebx
 1f7b295:	mov    %r11d,%r14d
 1f7b298:	shl    $0xe,%r14d
 1f7b29c:	add    %rdx,%r14
 1f7b29f:	mov    %ebp,(%r14,%rbx,4)
 1f7b2a3:	inc    %ebx
 1f7b2a5:	mov    %ebx,(%rcx,%r11,4)
 1f7b2a9:	movzbl 0x5(%rax,%r9,1),%r11d
 1f7b2af:	mov    0x14(%rdi,%r9,4),%ebp
 1f7b2b4:	cmp    $0x40,%r11b
 1f7b2b8:	cmovae %r10d,%r11d
 1f7b2bc:	movzbl %r11b,%r11d
 1f7b2c0:	mov    (%rcx,%r11,4),%ebx
 1f7b2c4:	mov    %r11d,%r14d
 1f7b2c7:	shl    $0xe,%r14d
 1f7b2cb:	add    %rdx,%r14
 1f7b2ce:	mov    %ebp,(%r14,%rbx,4)
 1f7b2d2:	inc    %ebx
 1f7b2d4:	mov    %ebx,(%rcx,%r11,4)
 1f7b2d8:	movzbl 0x6(%rax,%r9,1),%r11d
 1f7b2de:	mov    0x18(%rdi,%r9,4),%ebp
 1f7b2e3:	cmp    $0x40,%r11b
 1f7b2e7:	cmovae %r10d,%r11d
 1f7b2eb:	movzbl %r11b,%r11d
 1f7b2ef:	mov    (%rcx,%r11,4),%ebx
 1f7b2f3:	mov    %r11d,%r14d
 1f7b2f6:	shl    $0xe,%r14d
 1f7b2fa:	add    %rdx,%r14
 1f7b2fd:	mov    %ebp,(%r14,%rbx,4)
 1f7b301:	inc    %ebx
 1f7b303:	mov    %ebx,(%rcx,%r11,4)
 1f7b307:	movzbl 0x7(%rax,%r9,1),%r11d
 1f7b30d:	mov    0x1c(%rdi,%r9,4),%ebp
 1f7b312:	cmp    $0x40,%r11b
 1f7b316:	cmovae %r10d,%r11d
 1f7b31a:	add    $0x8,%r9
 1f7b31e:	movzbl %r11b,%r11d
 1f7b322:	mov    (%rcx,%r11,4),%ebx
 1f7b326:	mov    %r11d,%r14d
 1f7b329:	shl    $0xe,%r14d
 1f7b32d:	add    %rdx,%r14
 1f7b330:	mov    %ebp,(%r14,%rbx,4)
 1f7b334:	inc    %ebx
 1f7b336:	mov    %ebx,(%rcx,%r11,4)
 1f7b33a:	cmp    %r9,%r8
 1f7b33d:	jne    1f7b1c0 <node_facts_window+0x340>
 1f7b343:	mov    0x20(%rsp),%r12
 1f7b348:	test   %rsi,%rsi
 1f7b34b:	je     1f7baaf <node_facts_window+0xc2f>
 1f7b351:	lea    (%rdi,%r9,4),%rdi
 1f7b355:	add    %r9,%rax
 1f7b358:	mov    $0x40,%r9d
 1f7b35e:	xor    %r8d,%r8d
 1f7b361:	mov    %r13d,%ebp
 1f7b364:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7b370:	movzbl (%rax,%r8,1),%r10d
 1f7b375:	mov    (%rdi,%r8,4),%ebx
 1f7b379:	cmp    $0x40,%r10b
 1f7b37d:	cmovae %r9d,%r10d
 1f7b381:	inc    %r8
 1f7b384:	movzbl %r10b,%r10d
 1f7b388:	mov    (%rcx,%r10,4),%r11d
 1f7b38c:	mov    %r10d,%r14d
 1f7b38f:	shl    $0xe,%r14d
 1f7b393:	add    %rdx,%r14
 1f7b396:	mov    %ebx,(%r14,%r11,4)
 1f7b39a:	inc    %r11d
 1f7b39d:	mov    %r11d,(%rcx,%r10,4)
 1f7b3a1:	cmp    %r8,%rsi
 1f7b3a4:	jne    1f7b370 <node_facts_window+0x4f0>
 1f7b3a6:	mov    0x30(%rsp),%r13
 1f7b3ab:	cmpl   $0x0,0xc(%rsp)
 1f7b3b0:	je     1f7b173 <node_facts_window+0x2f3>
 1f7b3b6:	mov    0x38(%rsp),%rdx
 1f7b3bb:	mov    %r12,%rdi
 1f7b3be:	mov    %r13d,%esi
 1f7b3c1:	vzeroupper
 1f7b3c4:	call   1f83e70 <node_facts_leaves_lean>
 1f7b3c9:	test   %bpl,%bpl
 1f7b3cc:	je     1f7b18f <node_facts_window+0x30f>
 1f7b3d2:	rdtsc
 1f7b3d4:	mov    %rdx,%rbx
 1f7b3d7:	shl    $0x20,%rbx
 1f7b3db:	or     %rax,%rbx
 1f7b3de:	cmpl   $0x0,0x2c(%rsp)
 1f7b3e3:	je     1f7ba49 <node_facts_window+0xbc9>
 1f7b3e9:	lea    0x2e8(%r12),%r14
 1f7b3f1:	mov    %r15d,0x44(%rsp)
 1f7b3f6:	mov    %rbx,0x78(%rsp)
 1f7b3fb:	mov    %ebp,0x48(%rsp)
 1f7b3ff:	xor    %ecx,%ecx
 1f7b401:	xor    %r15d,%r15d
 1f7b404:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7b410:	mov    %rcx,0x70(%rsp)
 1f7b415:	mov    (%r14),%ecx
 1f7b418:	mov    0x4(%r14),%ebp
 1f7b41c:	mov    0x8(%r14),%eax
 1f7b420:	mov    0xc(%r14),%edx
 1f7b424:	mov    0x10(%r14),%esi
 1f7b428:	vmovups 0x1c(%r14),%ymm0
 1f7b42e:	test   %ecx,%ecx
 1f7b430:	mov    %edx,0x50(%rsp)
 1f7b434:	mov    %esi,0x54(%rsp)
 1f7b438:	mov    %eax,0x4c(%rsp)
 1f7b43c:	setne  0x1b(%rsp)
 1f7b441:	test   %ebp,%ebp
 1f7b443:	setne  0x1a(%rsp)
 1f7b448:	test   %eax,%eax
 1f7b44a:	setne  0x1c(%rsp)
 1f7b44f:	test   %edx,%edx
 1f7b451:	mov    0x14(%r14),%edx
 1f7b455:	vmovups %ymm0,0x80(%rsp)
 1f7b45e:	setne  0x1f(%rsp)
 1f7b463:	test   %esi,%esi
 1f7b465:	mov    0x18(%r14),%esi
 1f7b469:	setne  0x19(%rsp)
 1f7b46e:	xor    %ebx,%ebx
 1f7b470:	test   %edx,%edx
 1f7b472:	mov    %edx,0x58(%rsp)
 1f7b476:	mov    0x68(%rsp),%rdx
 1f7b47b:	setne  0x1e(%rsp)
 1f7b480:	xor    %r12d,%r12d
 1f7b483:	test   %esi,%esi
 1f7b485:	mov    %esi,0x5c(%rsp)
 1f7b489:	setne  0x1d(%rsp)
 1f7b48e:	mov    (%rdx),%rax
 1f7b491:	mov    %rax,0x10(%rsp)
 1f7b496:	test   %ecx,%ecx
 1f7b498:	je     1f7b4c0 <node_facts_window+0x640>
 1f7b49a:	mov    0x10(%rsp),%rax
 1f7b49f:	lea    (%rax,%r15,1),%rdx
 1f7b4a3:	mov    0xc(%rsp),%eax
 1f7b4a7:	test   %eax,%eax
 1f7b4a9:	je     1f7b4d0 <node_facts_window+0x650>
 1f7b4ab:	cmp    $0x1,%eax
 1f7b4ae:	jne    1f7b50c <node_facts_window+0x68c>
 1f7b4b0:	mov    0x20(%rsp),%rdi
 1f7b4b5:	mov    %r13d,%esi
 1f7b4b8:	vzeroupper
 1f7b4bb:	call   1f841f0 <node_facts_arrows_lean>
 1f7b4c0:	test   %ebp,%ebp
 1f7b4c2:	mov    0x20(%rsp),%rbp
 1f7b4c7:	jne    1f7b525 <node_facts_window+0x6a5>
 1f7b4c9:	jmp    1f7b56e <node_facts_window+0x6ee>
 1f7b4ce:	xchg   %ax,%ax
 1f7b4d0:	mov    0x20(%rsp),%r13
 1f7b4d5:	mov    0x30(%rsp),%rsi
 1f7b4da:	mov    %r13,%rdi
 1f7b4dd:	vzeroupper
 1f7b4e0:	call   1f83f20 <node_facts_arrows>
 1f7b4e5:	test   %ebp,%ebp
 1f7b4e7:	mov    %r13,%rbp
 1f7b4ea:	mov    0x30(%rsp),%r13
 1f7b4ef:	je     1f7b56e <node_facts_window+0x6ee>
 1f7b4f1:	mov    0x70(%rsp),%rdx
 1f7b4f6:	mov    0x4(%r14),%ecx
 1f7b4fa:	shl    $0x12,%rdx
 1f7b4fe:	add    0x10(%rsp),%rdx
 1f7b503:	add    $0x4000,%rdx
 1f7b50a:	jmp    1f7b560 <node_facts_window+0x6e0>
 1f7b50c:	mov    0x20(%rsp),%rdi
 1f7b511:	mov    %r13d,%esi
 1f7b514:	vzeroupper
 1f7b517:	call   1f84470 <node_facts_arrows_loads>
 1f7b51c:	test   %ebp,%ebp
 1f7b51e:	mov    0x20(%rsp),%rbp
 1f7b523:	je     1f7b56e <node_facts_window+0x6ee>
 1f7b525:	mov    0x10(%rsp),%rax
 1f7b52a:	mov    0x4(%r14),%ecx
 1f7b52e:	lea    0x4000(%rax,%r15,1),%rdx
 1f7b536:	mov    0xc(%rsp),%eax
 1f7b53a:	test   %eax,%eax
 1f7b53c:	je     1f7b560 <node_facts_window+0x6e0>
 1f7b53e:	mov    %rbp,%rdi
 1f7b541:	mov    %r13d,%esi
 1f7b544:	cmp    $0x1,%eax
 1f7b547:	jne    1f7b5c4 <node_facts_window+0x744>
 1f7b549:	vzeroupper
 1f7b54c:	call   1f84ad0 <node_facts_subscripts_lean>
 1f7b551:	cmpl   $0x0,0x4c(%rsp)
 1f7b556:	jne    1f7b575 <node_facts_window+0x6f5>
 1f7b558:	jmp    1f7b5e0 <node_facts_window+0x760>
 1f7b55d:	nopl   (%rax)
 1f7b560:	mov    %rbp,%rdi
 1f7b563:	mov    %r13d,%esi
 1f7b566:	vzeroupper
 1f7b569:	call   1f84650 <node_facts_subscripts>
 1f7b56e:	cmpl   $0x0,0x4c(%rsp)
 1f7b573:	je     1f7b5e0 <node_facts_window+0x760>
 1f7b575:	mov    0x10(%rsp),%rax
 1f7b57a:	mov    0x8(%r14),%ecx
 1f7b57e:	mov    %rbp,%rdi
 1f7b581:	mov    %r13d,%esi
 1f7b584:	lea    0x8000(%rax,%r15,1),%rdx
 1f7b58c:	mov    0xc(%rsp),%eax
 1f7b590:	test   %eax,%eax
 1f7b592:	je     1f7b5b0 <node_facts_window+0x730>
 1f7b594:	cmp    $0x1,%eax
 1f7b597:	jne    1f7b5ba <node_facts_window+0x73a>
 1f7b599:	vzeroupper
 1f7b59c:	call   1f854a0 <node_facts_dots_lean>
 1f7b5a1:	jmp    1f7b5e0 <node_facts_window+0x760>
 1f7b5a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7b5b0:	vzeroupper
 1f7b5b3:	call   1f85170 <node_facts_dots>
 1f7b5b8:	jmp    1f7b5e0 <node_facts_window+0x760>
 1f7b5ba:	vzeroupper
 1f7b5bd:	call   1f857a0 <node_facts_dots_loads>
 1f7b5c2:	jmp    1f7b5e0 <node_facts_window+0x760>
 1f7b5c4:	vzeroupper
 1f7b5c7:	call   1f84eb0 <node_facts_subscripts_loads>
 1f7b5cc:	cmpl   $0x0,0x4c(%rsp)
 1f7b5d1:	jne    1f7b575 <node_facts_window+0x6f5>
 1f7b5d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7b5e0:	cmpl   $0x0,0x50(%rsp)
 1f7b5e5:	je     1f7b612 <node_facts_window+0x792>
 1f7b5e7:	mov    0x10(%rsp),%rax
 1f7b5ec:	xor    %r8d,%r8d
 1f7b5ef:	cmpl   $0x0,0xc(%rsp)
 1f7b5f4:	mov    0xc(%r14),%ecx
 1f7b5f8:	mov    %rbp,%rdi
 1f7b5fb:	mov    %r13d,%esi
 1f7b5fe:	lea    0xc000(%rax,%r15,1),%rdx
 1f7b606:	setne  %r8b
 1f7b60a:	vzeroupper
 1f7b60d:	call   1f85990 <node_facts_addresses_made>
 1f7b612:	cmpl   $0x0,0x54(%rsp)
 1f7b617:	je     1f7b644 <node_facts_window+0x7c4>
 1f7b619:	mov    0x10(%rsp),%rax
 1f7b61e:	xor    %r8d,%r8d
 1f7b621:	cmpl   $0x0,0xc(%rsp)
 1f7b626:	mov    0x10(%r14),%ecx
 1f7b62a:	mov    %rbp,%rdi
 1f7b62d:	mov    %r13d,%esi
 1f7b630:	lea    0x10000(%rax,%r15,1),%rdx
 1f7b638:	setne  %r8b
 1f7b63c:	vzeroupper
 1f7b63f:	call   1f85ba0 <node_facts_casts>
 1f7b644:	cmpl   $0x0,0x58(%rsp)
 1f7b649:	je     1f7b66a <node_facts_window+0x7ea>
 1f7b64b:	mov    0x10(%rsp),%rax
 1f7b650:	mov    0x14(%r14),%ecx
 1f7b654:	mov    %rbp,%rdi
 1f7b657:	mov    %r13d,%esi
 1f7b65a:	lea    0x14000(%rax,%r15,1),%rdx
 1f7b662:	vzeroupper
 1f7b665:	call   1f86160 <node_facts_slow_list>
 1f7b66a:	cmpl   $0x0,0x5c(%rsp)
 1f7b66f:	je     1f7b69c <node_facts_window+0x81c>
 1f7b671:	mov    0x10(%rsp),%rax
 1f7b676:	xor    %r8d,%r8d
 1f7b679:	cmpl   $0x0,0xc(%rsp)
 1f7b67e:	mov    0x18(%r14),%ecx
 1f7b682:	mov    %rbp,%rdi
 1f7b685:	mov    %r13d,%esi
 1f7b688:	lea    0x18000(%rax,%r15,1),%rdx
 1f7b690:	setne  %r8b
 1f7b694:	vzeroupper
 1f7b697:	call   1f861a0 <node_facts_rows_made>
 1f7b69c:	movzbl 0x1b(%rsp),%ecx
 1f7b6a1:	movzbl 0x1a(%rsp),%edx
 1f7b6a6:	xor    %eax,%eax
 1f7b6a8:	movzbl 0x1f(%rsp),%esi
 1f7b6ad:	vmovdqu 0x80(%rsp),%ymm0
 1f7b6b6:	mov    %cl,%al
 1f7b6b8:	xor    %ecx,%ecx
 1f7b6ba:	mov    %dl,%cl
 1f7b6bc:	movzbl 0x1c(%rsp),%edx
 1f7b6c1:	lea    (%rax,%rcx,2),%eax
 1f7b6c4:	xor    %ecx,%ecx
 1f7b6c6:	vptestnmd %ymm0,%ymm0,%k1
 1f7b6cc:	mov    %dl,%cl
 1f7b6ce:	xor    %edx,%edx
 1f7b6d0:	lea    (%rax,%rcx,4),%eax
 1f7b6d3:	movzbl 0x19(%rsp),%ecx
 1f7b6d8:	kshiftrb $0x1,%k1,%k0
 1f7b6de:	kmovw  %k1,0x80(%rsp)
 1f7b6e7:	mov    %cl,%dl
 1f7b6e9:	xor    %ecx,%ecx
 1f7b6eb:	mov    %sil,%cl
 1f7b6ee:	lea    (%rax,%rcx,8),%eax
 1f7b6f1:	movzbl 0x1e(%rsp),%ecx
 1f7b6f6:	shl    $0x4,%edx
 1f7b6f9:	or     %edx,%eax
 1f7b6fb:	mov    %cl,%bl
 1f7b6fd:	kmovd  %k1,%ecx
 1f7b701:	shl    $0x5,%ebx
 1f7b704:	not    %cl
 1f7b706:	or     %eax,%ebx
 1f7b708:	movzbl 0x1d(%rsp),%eax
 1f7b70d:	movzbl %cl,%ecx
 1f7b710:	and    $0x1,%ecx
 1f7b713:	shl    $0x7,%ecx
 1f7b716:	mov    %al,%r12b
 1f7b719:	kmovd  %k0,%eax
 1f7b71d:	shl    $0x6,%r12d
 1f7b721:	not    %al
 1f7b723:	or     %ebx,%r12d
 1f7b726:	movzbl %al,%ebx
 1f7b729:	and    $0x1,%ebx
 1f7b72c:	shl    $0x8,%ebx
 1f7b72f:	or     %ecx,%ebx
 1f7b731:	or     %r12d,%ebx
 1f7b734:	mov    0xc(%rsp),%r12d
 1f7b739:	test   %bl,%bl
 1f7b73b:	jns    1f7b780 <node_facts_window+0x900>
 1f7b73d:	mov    0x10(%rsp),%rax
 1f7b742:	mov    0x1c(%r14),%ecx
 1f7b746:	mov    %rbp,%rdi
 1f7b749:	mov    %r13d,%esi
 1f7b74c:	lea    0x1c000(%rax,%r15,1),%rdx
 1f7b754:	test   %r12d,%r12d
 1f7b757:	je     1f7b775 <node_facts_window+0x8f5>
 1f7b759:	cmp    $0x1,%r12d
 1f7b75d:	jne    1f7b863 <node_facts_window+0x9e3>
 1f7b763:	vzeroupper
 1f7b766:	call   1f86ef0 <node_facts_calls_lean>
 1f7b76b:	test   $0x100,%ebx
 1f7b771:	jne    1f7b788 <node_facts_window+0x908>
 1f7b773:	jmp    1f7b7b1 <node_facts_window+0x931>
 1f7b775:	vzeroupper
 1f7b778:	call   1f86540 <node_facts_calls>
 1f7b77d:	nopl   (%rax)
 1f7b780:	test   $0x100,%ebx
 1f7b786:	je     1f7b7b1 <node_facts_window+0x931>
 1f7b788:	mov    0x10(%rsp),%rax
 1f7b78d:	mov    0x20(%r14),%ecx
 1f7b791:	xor    %r8d,%r8d
 1f7b794:	test   %r12d,%r12d
 1f7b797:	mov    %rbp,%rdi
 1f7b79a:	mov    %r13d,%esi
 1f7b79d:	setne  %r8b
 1f7b7a1:	lea    0x20000(%rax,%r15,1),%rdx
 1f7b7a9:	vzeroupper
 1f7b7ac:	call   1f87ab0 <node_facts_logics>
 1f7b7b1:	kmovw  0x80(%rsp),%k1
 1f7b7ba:	kshiftrb $0x3,%k1,%k0
 1f7b7c0:	kmovd  %k0,%eax
 1f7b7c4:	kshiftrb $0x2,%k1,%k0
 1f7b7ca:	kmovd  %k0,%ecx
 1f7b7ce:	not    %al
 1f7b7d0:	not    %cl
 1f7b7d2:	movzbl %al,%ebp
 1f7b7d5:	movzbl %cl,%ecx
 1f7b7d8:	and    $0x1,%ebp
 1f7b7db:	and    $0x1,%ecx
 1f7b7de:	shl    $0xa,%ebp
 1f7b7e1:	shl    $0x9,%ecx
 1f7b7e4:	or     %ecx,%ebp
 1f7b7e6:	or     %ebx,%ebp
 1f7b7e8:	test   $0x200,%ebp
 1f7b7ee:	je     1f7b81b <node_facts_window+0x99b>
 1f7b7f0:	mov    0x10(%rsp),%rax
 1f7b7f5:	mov    0x24(%r14),%ecx
 1f7b7f9:	mov    0x20(%rsp),%rdi
 1f7b7fe:	xor    %r8d,%r8d
 1f7b801:	test   %r12d,%r12d
 1f7b804:	mov    %r13d,%esi
 1f7b807:	setne  %r8b
 1f7b80b:	lea    0x24000(%rax,%r15,1),%rdx
 1f7b813:	vzeroupper
 1f7b816:	call   1f87d70 <node_facts_updates>
 1f7b81b:	test   $0x400,%ebp
 1f7b821:	je     1f7b890 <node_facts_window+0xa10>
 1f7b823:	mov    0x10(%rsp),%rax
 1f7b828:	mov    0x28(%r14),%ecx
 1f7b82c:	lea    0x28000(%rax,%r15,1),%rdx
 1f7b834:	test   %r12d,%r12d
 1f7b837:	je     1f7b851 <node_facts_window+0x9d1>
 1f7b839:	cmp    $0x1,%r12d
 1f7b83d:	jne    1f7b87c <node_facts_window+0x9fc>
 1f7b83f:	mov    0x20(%rsp),%rdi
 1f7b844:	mov    %r13d,%esi
 1f7b847:	vzeroupper
 1f7b84a:	call   1f889a0 <node_facts_dereferences_lean>
 1f7b84f:	jmp    1f7b890 <node_facts_window+0xa10>
 1f7b851:	mov    0x20(%rsp),%rdi
 1f7b856:	mov    %r13d,%esi
 1f7b859:	vzeroupper
 1f7b85c:	call   1f88750 <node_facts_dereferences>
 1f7b861:	jmp    1f7b890 <node_facts_window+0xa10>
 1f7b863:	vzeroupper
 1f7b866:	call   1f87800 <node_facts_calls_loads>
 1f7b86b:	test   $0x100,%ebx
 1f7b871:	jne    1f7b788 <node_facts_window+0x908>
 1f7b877:	jmp    1f7b7b1 <node_facts_window+0x931>
 1f7b87c:	mov    0x20(%rsp),%rdi
 1f7b881:	mov    %r13d,%esi
 1f7b884:	vzeroupper
 1f7b887:	call   1f88b90 <node_facts_dereferences_loads>
 1f7b88c:	nopl   0x0(%rax)
 1f7b890:	kmovw  0x80(%rsp),%k1
 1f7b899:	mov    0x20(%rsp),%r12
 1f7b89e:	kshiftrb $0x5,%k1,%k0
 1f7b8a4:	kmovd  %k0,%eax
 1f7b8a8:	kshiftrb $0x4,%k1,%k0
 1f7b8ae:	kmovd  %k0,%ecx
 1f7b8b2:	not    %al
 1f7b8b4:	not    %cl
 1f7b8b6:	movzbl %al,%ebx
 1f7b8b9:	movzbl %cl,%ecx
 1f7b8bc:	and    $0x1,%ebx
 1f7b8bf:	and    $0x1,%ecx
 1f7b8c2:	shl    $0xc,%ebx
 1f7b8c5:	shl    $0xb,%ecx
 1f7b8c8:	or     %ecx,%ebx
 1f7b8ca:	or     %ebp,%ebx
 1f7b8cc:	test   $0x800,%ebx
 1f7b8d2:	je     1f7b8ff <node_facts_window+0xa7f>
 1f7b8d4:	mov    0x10(%rsp),%rax
 1f7b8d9:	xor    %r8d,%r8d
 1f7b8dc:	cmpl   $0x0,0xc(%rsp)
 1f7b8e1:	mov    0x2c(%r14),%ecx
 1f7b8e5:	mov    %r12,%rdi
 1f7b8e8:	mov    %r13d,%esi
 1f7b8eb:	lea    0x2c000(%rax,%r15,1),%rdx
 1f7b8f3:	setne  %r8b
 1f7b8f7:	vzeroupper
 1f7b8fa:	call   1f88d50 <node_facts_stores>
 1f7b8ff:	test   $0x1000,%ebx
 1f7b905:	je     1f7b932 <node_facts_window+0xab2>
 1f7b907:	mov    0x10(%rsp),%rax
 1f7b90c:	xor    %r8d,%r8d
 1f7b90f:	cmpl   $0x0,0xc(%rsp)
 1f7b914:	mov    0x30(%r14),%ecx
 1f7b918:	mov    %r12,%rdi
 1f7b91b:	mov    %r13d,%esi
 1f7b91e:	lea    0x30000(%rax,%r15,1),%rdx
 1f7b926:	setne  %r8b
 1f7b92a:	vzeroupper
 1f7b92d:	call   1f89340 <node_facts_converts>
 1f7b932:	kmovw  0x80(%rsp),%k1
 1f7b93b:	kshiftrb $0x7,%k1,%k0
 1f7b941:	kmovd  %k0,%eax
 1f7b945:	kshiftrb $0x6,%k1,%k0
 1f7b94b:	kmovd  %k0,%ecx
 1f7b94f:	not    %al
 1f7b951:	not    %cl
 1f7b953:	movzbl %al,%ebp
 1f7b956:	movzbl %cl,%ecx
 1f7b959:	and    $0x1,%ebp
 1f7b95c:	and    $0x1,%ecx
 1f7b95f:	shl    $0xe,%ebp
 1f7b962:	shl    $0xd,%ecx
 1f7b965:	or     %ecx,%ebp
 1f7b967:	or     %ebx,%ebp
 1f7b969:	test   $0x2000,%ebp
 1f7b96f:	jne    1f7b990 <node_facts_window+0xb10>
 1f7b971:	mov    0x20(%rsp),%r12
 1f7b976:	cmp    $0x4000,%ebp
 1f7b97c:	jae    1f7b9be <node_facts_window+0xb3e>
 1f7b97e:	mov    0x70(%rsp),%rcx
 1f7b983:	cmp    $0x2,%rcx
 1f7b987:	jbe    1f7b9f4 <node_facts_window+0xb74>
 1f7b989:	jmp    1f7ba11 <node_facts_window+0xb91>
 1f7b98e:	xchg   %ax,%ax
 1f7b990:	mov    0x10(%rsp),%rax
 1f7b995:	mov    0x34(%r14),%ecx
 1f7b999:	mov    0x20(%rsp),%rdi
 1f7b99e:	mov    %r13d,%esi
 1f7b9a1:	lea    0x34000(%rax,%r15,1),%rdx
 1f7b9a9:	vzeroupper
 1f7b9ac:	call   1f898c0 <node_facts_discards>
 1f7b9b1:	mov    0x20(%rsp),%r12
 1f7b9b6:	cmp    $0x4000,%ebp
 1f7b9bc:	jb     1f7b97e <node_facts_window+0xafe>
 1f7b9be:	mov    0x10(%rsp),%rax
 1f7b9c3:	xor    %r8d,%r8d
 1f7b9c6:	cmpl   $0x0,0xc(%rsp)
 1f7b9cb:	mov    0x38(%r14),%ecx
 1f7b9cf:	mov    %r12,%rdi
 1f7b9d2:	mov    %r13d,%esi
 1f7b9d5:	lea    0x38000(%rax,%r15,1),%rdx
 1f7b9dd:	setne  %r8b
 1f7b9e1:	vzeroupper
 1f7b9e4:	call   1f89a80 <node_facts_truths>
 1f7b9e9:	mov    0x70(%rsp),%rcx
 1f7b9ee:	cmp    $0x2,%rcx
 1f7b9f2:	ja     1f7ba11 <node_facts_window+0xb91>
 1f7b9f4:	inc    %rcx
 1f7b9f7:	add    $0x40000,%r15
 1f7b9fe:	add    $0x40,%r14
 1f7ba02:	shrx   %ecx,0x2c(%rsp),%eax
 1f7ba09:	test   %eax,%eax
 1f7ba0b:	jne    1f7b410 <node_facts_window+0x590>
 1f7ba11:	testb  $0x10,0x2c(%rsp)
 1f7ba16:	mov    0x48(%rsp),%ebp
 1f7ba1a:	mov    0x44(%rsp),%r15d
 1f7ba1f:	mov    0x78(%rsp),%rbx
 1f7ba24:	je     1f7ba49 <node_facts_window+0xbc9>
 1f7ba26:	mov    $0x100000,%edx
 1f7ba2b:	add    0x2e0(%r12),%rdx
 1f7ba33:	mov    0x3e8(%r12),%ecx
 1f7ba3b:	mov    %r12,%rdi
 1f7ba3e:	mov    %r13d,%esi
 1f7ba41:	vzeroupper
 1f7ba44:	call   1f86160 <node_facts_slow_list>
 1f7ba49:	test   %bpl,%bpl
 1f7ba4c:	je     1f7ba59 <node_facts_window+0xbd9>
 1f7ba4e:	rdtsc
 1f7ba50:	shl    $0x20,%rdx
 1f7ba54:	or     %rax,%rdx
 1f7ba57:	jmp    1f7ba5b <node_facts_window+0xbdb>
 1f7ba59:	xor    %edx,%edx
 1f7ba5b:	sub    %rbx,%rdx
 1f7ba5e:	sub    0x60(%rsp),%rbx
 1f7ba63:	mov    0x38(%rsp),%rax
 1f7ba68:	vmovq  %rdx,%xmm0
 1f7ba6d:	vmovq  %rbx,%xmm1
 1f7ba72:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f7ba76:	vpaddq 0x908(%r12),%xmm0,%xmm0
 1f7ba80:	vmovdqu %xmm0,0x908(%r12)
 1f7ba8a:	mov    %eax,0x928(%r12)
 1f7ba92:	mov    %r15d,0x92c(%r12)
 1f7ba9a:	add    $0xa8,%rsp
 1f7baa1:	pop    %rbx
 1f7baa2:	pop    %r12
 1f7baa4:	pop    %r13
 1f7baa6:	pop    %r14
 1f7baa8:	pop    %r15
 1f7baaa:	pop    %rbp
 1f7baab:	vzeroupper
 1f7baae:	ret
 1f7baaf:	mov    %r13d,%ebp
 1f7bab2:	mov    0x30(%rsp),%r13
 1f7bab7:	cmpl   $0x0,0xc(%rsp)
 1f7babc:	jne    1f7b3b6 <node_facts_window+0x536>
 1f7bac2:	jmp    1f7b173 <node_facts_window+0x2f3>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
