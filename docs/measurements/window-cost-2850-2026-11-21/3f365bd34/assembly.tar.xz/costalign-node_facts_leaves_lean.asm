
results/costalign/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f850c0 <node_facts_leaves_lean>:
 1f850c0:	test   %edx,%edx
 1f850c2:	je     1f85169 <node_facts_leaves_lean+0xa9>
 1f850c8:	push   %rbp
 1f850c9:	push   %r15
 1f850cb:	push   %r14
 1f850cd:	push   %r13
 1f850cf:	push   %r12
 1f850d1:	push   %rbx
 1f850d2:	sub    $0x18,%rsp
 1f850d6:	mov    0x2c0(%rdi),%rax
 1f850dd:	mov    0x2c8(%rdi),%r15
 1f850e4:	mov    0x28(%rdi),%rbp
 1f850e8:	mov    %rdi,%rbx
 1f850eb:	mov    %edx,%r14d
 1f850ee:	xor    %r12d,%r12d
 1f850f1:	mov    %rax,0x10(%rsp)
 1f850f6:	mov    %esi,%eax
 1f850f8:	lea    0x0(,%rax,4),%r13
 1f85100:	add    0x220(%rdi),%r13
 1f85107:	mov    %rax,0x8(%rsp)
 1f8510c:	jmp    1f8512c <node_facts_leaves_lean+0x6c>
 1f8510e:	xchg   %ax,%ax
 1f85110:	vmovups 0x0(%rbp,%rax,1),%ymm0
 1f85116:	mov    0x10(%rsp),%rax
 1f8511b:	shl    $0x6,%rdx
 1f8511f:	vmovups %ymm0,(%rax,%rdx,1)
 1f85124:	inc    %r12
 1f85127:	cmp    %r12,%r14
 1f8512a:	je     1f8515b <node_facts_leaves_lean+0x9b>
 1f8512c:	mov    (%r15,%r12,4),%edx
 1f85130:	mov    0x0(%r13,%rdx,4),%eax
 1f85135:	shl    $0x5,%rax
 1f85139:	cmpl   $0x0,0x1c(%rbp,%rax,1)
 1f8513e:	je     1f85110 <node_facts_leaves_lean+0x50>
 1f85140:	mov    %rdx,%rsi
 1f85143:	add    0x8(%rsp),%rsi
 1f85148:	mov    %rbx,%rdi
 1f8514b:	vzeroupper
 1f8514e:	call   1f8ae90 <node_facts_leave>
 1f85153:	inc    %r12
 1f85156:	cmp    %r12,%r14
 1f85159:	jne    1f8512c <node_facts_leaves_lean+0x6c>
 1f8515b:	add    $0x18,%rsp
 1f8515f:	pop    %rbx
 1f85160:	pop    %r12
 1f85162:	pop    %r13
 1f85164:	pop    %r14
 1f85166:	pop    %r15
 1f85168:	pop    %rbp
 1f85169:	vzeroupper
 1f8516c:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
