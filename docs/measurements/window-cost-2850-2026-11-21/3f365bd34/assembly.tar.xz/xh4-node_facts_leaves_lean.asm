
results/xh4/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f85180 <node_facts_leaves_lean>:
 1f85180:	test   %edx,%edx
 1f85182:	je     1f85229 <node_facts_leaves_lean+0xa9>
 1f85188:	push   %rbp
 1f85189:	push   %r15
 1f8518b:	push   %r14
 1f8518d:	push   %r13
 1f8518f:	push   %r12
 1f85191:	push   %rbx
 1f85192:	sub    $0x18,%rsp
 1f85196:	mov    0x2c0(%rdi),%rax
 1f8519d:	mov    0x2c8(%rdi),%r15
 1f851a4:	mov    0x28(%rdi),%rbp
 1f851a8:	mov    %rdi,%rbx
 1f851ab:	mov    %edx,%r14d
 1f851ae:	xor    %r12d,%r12d
 1f851b1:	mov    %rax,0x10(%rsp)
 1f851b6:	mov    %esi,%eax
 1f851b8:	lea    0x0(,%rax,4),%r13
 1f851c0:	add    0x220(%rdi),%r13
 1f851c7:	mov    %rax,0x8(%rsp)
 1f851cc:	jmp    1f851ec <node_facts_leaves_lean+0x6c>
 1f851ce:	xchg   %ax,%ax
 1f851d0:	vmovups 0x0(%rbp,%rax,1),%ymm0
 1f851d6:	mov    0x10(%rsp),%rax
 1f851db:	shl    $0x6,%rdx
 1f851df:	vmovups %ymm0,(%rax,%rdx,1)
 1f851e4:	inc    %r12
 1f851e7:	cmp    %r12,%r14
 1f851ea:	je     1f8521b <node_facts_leaves_lean+0x9b>
 1f851ec:	mov    (%r15,%r12,4),%edx
 1f851f0:	mov    0x0(%r13,%rdx,4),%eax
 1f851f5:	shl    $0x5,%rax
 1f851f9:	cmpl   $0x0,0x1c(%rbp,%rax,1)
 1f851fe:	je     1f851d0 <node_facts_leaves_lean+0x50>
 1f85200:	mov    %rdx,%rsi
 1f85203:	add    0x8(%rsp),%rsi
 1f85208:	mov    %rbx,%rdi
 1f8520b:	vzeroupper
 1f8520e:	call   1f8af50 <node_facts_leave>
 1f85213:	inc    %r12
 1f85216:	cmp    %r12,%r14
 1f85219:	jne    1f851ec <node_facts_leaves_lean+0x6c>
 1f8521b:	add    $0x18,%rsp
 1f8521f:	pop    %rbx
 1f85220:	pop    %r12
 1f85222:	pop    %r13
 1f85224:	pop    %r14
 1f85226:	pop    %r15
 1f85228:	pop    %rbp
 1f85229:	vzeroupper
 1f8522c:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
