
results/costv2/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f7bd00 <node_facts_window>:
 1f7bd00:	push   %rbp
 1f7bd01:	push   %r15
 1f7bd03:	push   %r14
 1f7bd05:	push   %r13
 1f7bd07:	push   %r12
 1f7bd09:	push   %rbx
 1f7bd0a:	sub    $0xa8,%rsp
 1f7bd11:	mov    0x248(%rdi),%rax
 1f7bd18:	mov    %ecx,%ebp
 1f7bd1a:	mov    %esi,%ecx
 1f7bd1c:	inc    %esi
 1f7bd1e:	mov    %edx,0xc(%rsp)
 1f7bd22:	mov    %rdi,%r12
 1f7bd25:	mov    (%rax,%rcx,4),%r13d
 1f7bd29:	mov    (%rax,%rsi,4),%r8d
 1f7bd2d:	test   %ebp,%ebp
 1f7bd2f:	je     1f7bf6f <node_facts_window+0x26f>
 1f7bd35:	rdtsc
 1f7bd37:	shl    $0x20,%rdx
 1f7bd3b:	or     %rax,%rdx
 1f7bd3e:	mov    %rdx,0x60(%rsp)
 1f7bd43:	mov    %r12,0x20(%rsp)
 1f7bd48:	mov    %r13,0x30(%rsp)
 1f7bd4d:	cmp    %r13d,%r8d
 1f7bd50:	je     1f7bf8b <node_facts_window+0x28b>
 1f7bd56:	vmovdqa64 -0x1ac56a0(%rip),%zmm1        # 4b66c0 <abi_test_hex.digits+0xb340>
 1f7bd60:	vpbroadcastb -0x1ac5669(%rip),%xmm2        # 4b6700 <abi_test_hex.digits+0xb380>
 1f7bd69:	vpbroadcastb -0x1ac5671(%rip),%xmm3        # 4b6701 <abi_test_hex.digits+0xb381>
 1f7bd72:	vpbroadcastq -0x19ad84b(%rip),%xmm4        # 5ce530 <.LCPI0_8>
 1f7bd7b:	vpbroadcastd -0x19aae25(%rip),%zmm5        # 5d0f60 <.LCPI0_4>
 1f7bd85:	vpbroadcastd -0x19aae2b(%rip),%zmm6        # 5d0f64 <.LCPI0_5>
 1f7bd8f:	mov    0x1f8(%r12),%rsi
 1f7bd97:	mov    0x200(%r12),%rdi
 1f7bd9f:	mov    0x2c8(%r12),%rax
 1f7bda7:	mov    0x2d0(%r12),%rcx
 1f7bdaf:	mov    0x2d8(%r12),%rdx
 1f7bdb7:	mov    %r13,%r9
 1f7bdba:	sub    %r9d,%r8d
 1f7bdbd:	mov    $0x10,%r10d
 1f7bdc3:	mov    $0xffffffff,%r11d
 1f7bdc9:	mov    %ebp,%r13d
 1f7bdcc:	vpxor  %xmm0,%xmm0,%xmm0
 1f7bdd0:	xor    %r12d,%r12d
 1f7bdd3:	xor    %ebx,%ebx
 1f7bdd5:	xor    %r15d,%r15d
 1f7bdd8:	mov    %r8d,%ebp
 1f7bddb:	add    %r9,%rsi
 1f7bdde:	add    %r9,%rdi
 1f7bde1:	mov    %r8d,%r9d
 1f7bde4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7bdf0:	sub    $0x10,%ebp
 1f7bdf3:	mov    %r15d,%r14d
 1f7bdf6:	mov    %r12d,%r15d
 1f7bdf9:	cmovae %r10d,%r8d
 1f7bdfd:	shlx   %r8d,%r11d,%r8d
 1f7be02:	not    %r8d
 1f7be05:	kmovd  %r8d,%k1
 1f7be0a:	mov    %r12d,%r8d
 1f7be0d:	vmovdqu8 (%rsi,%rbx,1),%xmm7{%k1}{z}
 1f7be14:	vpand  %xmm2,%xmm7,%xmm7
 1f7be18:	vpcmpeqb %xmm3,%xmm7,%k2{%k1}
 1f7be1e:	vpcmpeqb %xmm2,%xmm7,%k1{%k1}
 1f7be24:	vmovdqu8 (%rdi,%rbx,1),%xmm7{%k1}{z}
 1f7be2b:	vpxor  %xmm8,%xmm8,%xmm8
 1f7be30:	vpcompressd %zmm1,%zmm8{%k2}{z}
 1f7be36:	vpxor  %xmm10,%xmm10,%xmm10
 1f7be3b:	vpcompressd %zmm1,%zmm10{%k1}{z}
 1f7be41:	vpaddd %zmm6,%zmm1,%zmm1
 1f7be47:	add    $0x10,%rbx
 1f7be4b:	vmovdqu64 %zmm8,(%rax,%r8,4)
 1f7be52:	mov    %r14d,%r8d
 1f7be55:	vmovdqu64 %zmm10,(%rcx,%r8,4)
 1f7be5c:	vxorps %xmm9,%xmm9,%xmm9
 1f7be61:	vpcompressb %xmm7,%xmm9{%k1}{z}
 1f7be67:	vgf2p8affineqb $0x0,%xmm4,%xmm7,%xmm7
 1f7be6d:	vmovdqu %xmm9,(%rdx,%r8,1)
 1f7be73:	kmovw  %k2,%r8d
 1f7be77:	vpmovzxbd %xmm7,%zmm7
 1f7be7d:	popcnt %r8d,%r12d
 1f7be82:	kmovw  %k1,%r8d
 1f7be86:	add    %r15d,%r12d
 1f7be89:	popcnt %r8d,%r15d
 1f7be8e:	mov    %ebp,%r8d
 1f7be91:	add    %r14d,%r15d
 1f7be94:	vpsllvd %zmm7,%zmm5,%zmm7{%k1}{z}
 1f7be9a:	vporq  %zmm7,%zmm0,%zmm0
 1f7bea0:	cmp    %r9,%rbx
 1f7bea3:	jb     1f7bdf0 <node_facts_window+0xf0>
 1f7bea9:	mov    %r12,0x38(%rsp)
 1f7beae:	mov    0x20(%rsp),%r12
 1f7beb3:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f7beba:	vporq  %zmm1,%zmm0,%zmm0
 1f7bec0:	vextracti128 $0x1,%ymm0,%xmm1
 1f7bec6:	vpor   %xmm1,%xmm0,%xmm0
 1f7beca:	vpshufd $0xee,%xmm0,%xmm1
 1f7becf:	mov    0x2d0(%r12),%rdi
 1f7bed7:	mov    0x2d8(%r12),%rax
 1f7bedf:	vpor   %xmm1,%xmm0,%xmm0
 1f7bee3:	lea    0x2e0(%r12),%rcx
 1f7beeb:	movl   $0x0,0x3e8(%r12)
 1f7bef7:	vpshufd $0x55,%xmm0,%xmm1
 1f7befc:	mov    %rcx,0x68(%rsp)
 1f7bf01:	vpor   %xmm1,%xmm0,%xmm0
 1f7bf05:	vmovd  %xmm0,0x2c(%rsp)
 1f7bf0b:	vpxor  %xmm0,%xmm0,%xmm0
 1f7bf0f:	vmovdqu64 %zmm0,0x2e8(%r12)
 1f7bf1a:	vmovdqu64 %zmm0,0x328(%r12)
 1f7bf25:	vmovdqu64 %zmm0,0x368(%r12)
 1f7bf30:	vmovdqu64 %zmm0,0x3a8(%r12)
 1f7bf3b:	test   %r15d,%r15d
 1f7bf3e:	je     1f7c021 <node_facts_window+0x321>
 1f7bf44:	mov    0x2e0(%r12),%rdx
 1f7bf4c:	mov    %r15d,%r8d
 1f7bf4f:	mov    %r8d,%esi
 1f7bf52:	lea    0x2e8(%r12),%rcx
 1f7bf5a:	and    $0x7,%esi
 1f7bf5d:	cmp    $0x8,%r15d
 1f7bf61:	jae    1f7c029 <node_facts_window+0x329>
 1f7bf67:	xor    %r9d,%r9d
 1f7bf6a:	jmp    1f7c1d1 <node_facts_window+0x4d1>
 1f7bf6f:	movq   $0x0,0x60(%rsp)
 1f7bf78:	mov    %r12,0x20(%rsp)
 1f7bf7d:	mov    %r13,0x30(%rsp)
 1f7bf82:	cmp    %r13d,%r8d
 1f7bf85:	jne    1f7bd56 <node_facts_window+0x56>
 1f7bf8b:	lea    0x2e0(%r12),%rax
 1f7bf93:	vpxor  %xmm0,%xmm0,%xmm0
 1f7bf97:	vmovdqu64 %zmm0,0x3a8(%r12)
 1f7bfa2:	vmovdqu64 %zmm0,0x368(%r12)
 1f7bfad:	vmovdqu64 %zmm0,0x328(%r12)
 1f7bfb8:	vmovdqu64 %zmm0,0x2e8(%r12)
 1f7bfc3:	movl   $0x0,0x3e8(%r12)
 1f7bfcf:	movq   $0x0,0x38(%rsp)
 1f7bfd8:	xor    %r15d,%r15d
 1f7bfdb:	movl   $0x0,0x2c(%rsp)
 1f7bfe3:	mov    %rax,0x68(%rsp)
 1f7bfe8:	cmpl   $0x0,0xc(%rsp)
 1f7bfed:	jne    1f7c236 <node_facts_window+0x536>
 1f7bff3:	mov    0x38(%rsp),%rdx
 1f7bff8:	mov    %r12,%rdi
 1f7bffb:	mov    %r13d,%esi
 1f7bffe:	vzeroupper
 1f7c001:	call   1f84f50 <node_facts_leaves>
 1f7c006:	test   %bpl,%bpl
 1f7c009:	jne    1f7c252 <node_facts_window+0x552>
 1f7c00f:	xor    %ebx,%ebx
 1f7c011:	cmpl   $0x0,0x2c(%rsp)
 1f7c016:	jne    1f7c269 <node_facts_window+0x569>
 1f7c01c:	jmp    1f7c8c9 <node_facts_window+0xbc9>
 1f7c021:	xor    %r15d,%r15d
 1f7c024:	jmp    1f7c92f <node_facts_window+0xc2f>
 1f7c029:	and    $0xfffffff8,%r8d
 1f7c02d:	mov    $0x40,%r10d
 1f7c033:	xor    %r9d,%r9d
 1f7c036:	cs nopw 0x0(%rax,%rax,1)
 1f7c040:	movzbl (%rax,%r9,1),%r11d
 1f7c045:	mov    (%rdi,%r9,4),%ebp
 1f7c049:	cmp    $0x40,%r11b
 1f7c04d:	cmovae %r10d,%r11d
 1f7c051:	movzbl %r11b,%r11d
 1f7c055:	mov    (%rcx,%r11,4),%ebx
 1f7c059:	mov    %r11d,%r14d
 1f7c05c:	shl    $0xe,%r14d
 1f7c060:	add    %rdx,%r14
 1f7c063:	mov    %ebp,(%r14,%rbx,4)
 1f7c067:	inc    %ebx
 1f7c069:	mov    %ebx,(%rcx,%r11,4)
 1f7c06d:	movzbl 0x1(%rax,%r9,1),%r11d
 1f7c073:	mov    0x4(%rdi,%r9,4),%ebp
 1f7c078:	cmp    $0x40,%r11b
 1f7c07c:	cmovae %r10d,%r11d
 1f7c080:	movzbl %r11b,%r11d
 1f7c084:	mov    (%rcx,%r11,4),%ebx
 1f7c088:	mov    %r11d,%r14d
 1f7c08b:	shl    $0xe,%r14d
 1f7c08f:	add    %rdx,%r14
 1f7c092:	mov    %ebp,(%r14,%rbx,4)
 1f7c096:	inc    %ebx
 1f7c098:	mov    %ebx,(%rcx,%r11,4)
 1f7c09c:	movzbl 0x2(%rax,%r9,1),%r11d
 1f7c0a2:	mov    0x8(%rdi,%r9,4),%ebp
 1f7c0a7:	cmp    $0x40,%r11b
 1f7c0ab:	cmovae %r10d,%r11d
 1f7c0af:	movzbl %r11b,%r11d
 1f7c0b3:	mov    (%rcx,%r11,4),%ebx
 1f7c0b7:	mov    %r11d,%r14d
 1f7c0ba:	shl    $0xe,%r14d
 1f7c0be:	add    %rdx,%r14
 1f7c0c1:	mov    %ebp,(%r14,%rbx,4)
 1f7c0c5:	inc    %ebx
 1f7c0c7:	mov    %ebx,(%rcx,%r11,4)
 1f7c0cb:	movzbl 0x3(%rax,%r9,1),%r11d
 1f7c0d1:	mov    0xc(%rdi,%r9,4),%ebp
 1f7c0d6:	cmp    $0x40,%r11b
 1f7c0da:	cmovae %r10d,%r11d
 1f7c0de:	movzbl %r11b,%r11d
 1f7c0e2:	mov    (%rcx,%r11,4),%ebx
 1f7c0e6:	mov    %r11d,%r14d
 1f7c0e9:	shl    $0xe,%r14d
 1f7c0ed:	add    %rdx,%r14
 1f7c0f0:	mov    %ebp,(%r14,%rbx,4)
 1f7c0f4:	inc    %ebx
 1f7c0f6:	mov    %ebx,(%rcx,%r11,4)
 1f7c0fa:	movzbl 0x4(%rax,%r9,1),%r11d
 1f7c100:	mov    0x10(%rdi,%r9,4),%ebp
 1f7c105:	cmp    $0x40,%r11b
 1f7c109:	cmovae %r10d,%r11d
 1f7c10d:	movzbl %r11b,%r11d
 1f7c111:	mov    (%rcx,%r11,4),%ebx
 1f7c115:	mov    %r11d,%r14d
 1f7c118:	shl    $0xe,%r14d
 1f7c11c:	add    %rdx,%r14
 1f7c11f:	mov    %ebp,(%r14,%rbx,4)
 1f7c123:	inc    %ebx
 1f7c125:	mov    %ebx,(%rcx,%r11,4)
 1f7c129:	movzbl 0x5(%rax,%r9,1),%r11d
 1f7c12f:	mov    0x14(%rdi,%r9,4),%ebp
 1f7c134:	cmp    $0x40,%r11b
 1f7c138:	cmovae %r10d,%r11d
 1f7c13c:	movzbl %r11b,%r11d
 1f7c140:	mov    (%rcx,%r11,4),%ebx
 1f7c144:	mov    %r11d,%r14d
 1f7c147:	shl    $0xe,%r14d
 1f7c14b:	add    %rdx,%r14
 1f7c14e:	mov    %ebp,(%r14,%rbx,4)
 1f7c152:	inc    %ebx
 1f7c154:	mov    %ebx,(%rcx,%r11,4)
 1f7c158:	movzbl 0x6(%rax,%r9,1),%r11d
 1f7c15e:	mov    0x18(%rdi,%r9,4),%ebp
 1f7c163:	cmp    $0x40,%r11b
 1f7c167:	cmovae %r10d,%r11d
 1f7c16b:	movzbl %r11b,%r11d
 1f7c16f:	mov    (%rcx,%r11,4),%ebx
 1f7c173:	mov    %r11d,%r14d
 1f7c176:	shl    $0xe,%r14d
 1f7c17a:	add    %rdx,%r14
 1f7c17d:	mov    %ebp,(%r14,%rbx,4)
 1f7c181:	inc    %ebx
 1f7c183:	mov    %ebx,(%rcx,%r11,4)
 1f7c187:	movzbl 0x7(%rax,%r9,1),%r11d
 1f7c18d:	mov    0x1c(%rdi,%r9,4),%ebp
 1f7c192:	cmp    $0x40,%r11b
 1f7c196:	cmovae %r10d,%r11d
 1f7c19a:	add    $0x8,%r9
 1f7c19e:	movzbl %r11b,%r11d
 1f7c1a2:	mov    (%rcx,%r11,4),%ebx
 1f7c1a6:	mov    %r11d,%r14d
 1f7c1a9:	shl    $0xe,%r14d
 1f7c1ad:	add    %rdx,%r14
 1f7c1b0:	mov    %ebp,(%r14,%rbx,4)
 1f7c1b4:	inc    %ebx
 1f7c1b6:	mov    %ebx,(%rcx,%r11,4)
 1f7c1ba:	cmp    %r9,%r8
 1f7c1bd:	jne    1f7c040 <node_facts_window+0x340>
 1f7c1c3:	mov    0x20(%rsp),%r12
 1f7c1c8:	test   %rsi,%rsi
 1f7c1cb:	je     1f7c92f <node_facts_window+0xc2f>
 1f7c1d1:	lea    (%rdi,%r9,4),%rdi
 1f7c1d5:	add    %r9,%rax
 1f7c1d8:	mov    $0x40,%r9d
 1f7c1de:	xor    %r8d,%r8d
 1f7c1e1:	mov    %r13d,%ebp
 1f7c1e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c1f0:	movzbl (%rax,%r8,1),%r10d
 1f7c1f5:	mov    (%rdi,%r8,4),%ebx
 1f7c1f9:	cmp    $0x40,%r10b
 1f7c1fd:	cmovae %r9d,%r10d
 1f7c201:	inc    %r8
 1f7c204:	movzbl %r10b,%r10d
 1f7c208:	mov    (%rcx,%r10,4),%r11d
 1f7c20c:	mov    %r10d,%r14d
 1f7c20f:	shl    $0xe,%r14d
 1f7c213:	add    %rdx,%r14
 1f7c216:	mov    %ebx,(%r14,%r11,4)
 1f7c21a:	inc    %r11d
 1f7c21d:	mov    %r11d,(%rcx,%r10,4)
 1f7c221:	cmp    %r8,%rsi
 1f7c224:	jne    1f7c1f0 <node_facts_window+0x4f0>
 1f7c226:	mov    0x30(%rsp),%r13
 1f7c22b:	cmpl   $0x0,0xc(%rsp)
 1f7c230:	je     1f7bff3 <node_facts_window+0x2f3>
 1f7c236:	mov    0x38(%rsp),%rdx
 1f7c23b:	mov    %r12,%rdi
 1f7c23e:	mov    %r13d,%esi
 1f7c241:	vzeroupper
 1f7c244:	call   1f85020 <node_facts_leaves_lean>
 1f7c249:	test   %bpl,%bpl
 1f7c24c:	je     1f7c00f <node_facts_window+0x30f>
 1f7c252:	rdtsc
 1f7c254:	mov    %rdx,%rbx
 1f7c257:	shl    $0x20,%rbx
 1f7c25b:	or     %rax,%rbx
 1f7c25e:	cmpl   $0x0,0x2c(%rsp)
 1f7c263:	je     1f7c8c9 <node_facts_window+0xbc9>
 1f7c269:	lea    0x2e8(%r12),%r14
 1f7c271:	mov    %r15d,0x44(%rsp)
 1f7c276:	mov    %rbx,0x78(%rsp)
 1f7c27b:	mov    %ebp,0x48(%rsp)
 1f7c27f:	xor    %ecx,%ecx
 1f7c281:	xor    %r15d,%r15d
 1f7c284:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c290:	mov    %rcx,0x70(%rsp)
 1f7c295:	mov    (%r14),%ecx
 1f7c298:	mov    0x4(%r14),%ebp
 1f7c29c:	mov    0x8(%r14),%eax
 1f7c2a0:	mov    0xc(%r14),%edx
 1f7c2a4:	mov    0x10(%r14),%esi
 1f7c2a8:	vmovups 0x1c(%r14),%ymm0
 1f7c2ae:	test   %ecx,%ecx
 1f7c2b0:	mov    %edx,0x50(%rsp)
 1f7c2b4:	mov    %esi,0x54(%rsp)
 1f7c2b8:	mov    %eax,0x4c(%rsp)
 1f7c2bc:	setne  0x1b(%rsp)
 1f7c2c1:	test   %ebp,%ebp
 1f7c2c3:	setne  0x1a(%rsp)
 1f7c2c8:	test   %eax,%eax
 1f7c2ca:	setne  0x1c(%rsp)
 1f7c2cf:	test   %edx,%edx
 1f7c2d1:	mov    0x14(%r14),%edx
 1f7c2d5:	vmovups %ymm0,0x80(%rsp)
 1f7c2de:	setne  0x1f(%rsp)
 1f7c2e3:	test   %esi,%esi
 1f7c2e5:	mov    0x18(%r14),%esi
 1f7c2e9:	setne  0x19(%rsp)
 1f7c2ee:	xor    %ebx,%ebx
 1f7c2f0:	test   %edx,%edx
 1f7c2f2:	mov    %edx,0x58(%rsp)
 1f7c2f6:	mov    0x68(%rsp),%rdx
 1f7c2fb:	setne  0x1e(%rsp)
 1f7c300:	xor    %r12d,%r12d
 1f7c303:	test   %esi,%esi
 1f7c305:	mov    %esi,0x5c(%rsp)
 1f7c309:	setne  0x1d(%rsp)
 1f7c30e:	mov    (%rdx),%rax
 1f7c311:	mov    %rax,0x10(%rsp)
 1f7c316:	test   %ecx,%ecx
 1f7c318:	je     1f7c340 <node_facts_window+0x640>
 1f7c31a:	mov    0x10(%rsp),%rax
 1f7c31f:	lea    (%rax,%r15,1),%rdx
 1f7c323:	mov    0xc(%rsp),%eax
 1f7c327:	test   %eax,%eax
 1f7c329:	je     1f7c350 <node_facts_window+0x650>
 1f7c32b:	cmp    $0x1,%eax
 1f7c32e:	jne    1f7c38c <node_facts_window+0x68c>
 1f7c330:	mov    0x20(%rsp),%rdi
 1f7c335:	mov    %r13d,%esi
 1f7c338:	vzeroupper
 1f7c33b:	call   1f853a0 <node_facts_arrows_lean>
 1f7c340:	test   %ebp,%ebp
 1f7c342:	mov    0x20(%rsp),%rbp
 1f7c347:	jne    1f7c3a5 <node_facts_window+0x6a5>
 1f7c349:	jmp    1f7c3ee <node_facts_window+0x6ee>
 1f7c34e:	xchg   %ax,%ax
 1f7c350:	mov    0x20(%rsp),%r13
 1f7c355:	mov    0x30(%rsp),%rsi
 1f7c35a:	mov    %r13,%rdi
 1f7c35d:	vzeroupper
 1f7c360:	call   1f850d0 <node_facts_arrows>
 1f7c365:	test   %ebp,%ebp
 1f7c367:	mov    %r13,%rbp
 1f7c36a:	mov    0x30(%rsp),%r13
 1f7c36f:	je     1f7c3ee <node_facts_window+0x6ee>
 1f7c371:	mov    0x70(%rsp),%rdx
 1f7c376:	mov    0x4(%r14),%ecx
 1f7c37a:	shl    $0x12,%rdx
 1f7c37e:	add    0x10(%rsp),%rdx
 1f7c383:	add    $0x4000,%rdx
 1f7c38a:	jmp    1f7c3e0 <node_facts_window+0x6e0>
 1f7c38c:	mov    0x20(%rsp),%rdi
 1f7c391:	mov    %r13d,%esi
 1f7c394:	vzeroupper
 1f7c397:	call   1f85620 <node_facts_arrows_loads>
 1f7c39c:	test   %ebp,%ebp
 1f7c39e:	mov    0x20(%rsp),%rbp
 1f7c3a3:	je     1f7c3ee <node_facts_window+0x6ee>
 1f7c3a5:	mov    0x10(%rsp),%rax
 1f7c3aa:	mov    0x4(%r14),%ecx
 1f7c3ae:	lea    0x4000(%rax,%r15,1),%rdx
 1f7c3b6:	mov    0xc(%rsp),%eax
 1f7c3ba:	test   %eax,%eax
 1f7c3bc:	je     1f7c3e0 <node_facts_window+0x6e0>
 1f7c3be:	mov    %rbp,%rdi
 1f7c3c1:	mov    %r13d,%esi
 1f7c3c4:	cmp    $0x1,%eax
 1f7c3c7:	jne    1f7c444 <node_facts_window+0x744>
 1f7c3c9:	vzeroupper
 1f7c3cc:	call   1f85c80 <node_facts_subscripts_lean>
 1f7c3d1:	cmpl   $0x0,0x4c(%rsp)
 1f7c3d6:	jne    1f7c3f5 <node_facts_window+0x6f5>
 1f7c3d8:	jmp    1f7c460 <node_facts_window+0x760>
 1f7c3dd:	nopl   (%rax)
 1f7c3e0:	mov    %rbp,%rdi
 1f7c3e3:	mov    %r13d,%esi
 1f7c3e6:	vzeroupper
 1f7c3e9:	call   1f85800 <node_facts_subscripts>
 1f7c3ee:	cmpl   $0x0,0x4c(%rsp)
 1f7c3f3:	je     1f7c460 <node_facts_window+0x760>
 1f7c3f5:	mov    0x10(%rsp),%rax
 1f7c3fa:	mov    0x8(%r14),%ecx
 1f7c3fe:	mov    %rbp,%rdi
 1f7c401:	mov    %r13d,%esi
 1f7c404:	lea    0x8000(%rax,%r15,1),%rdx
 1f7c40c:	mov    0xc(%rsp),%eax
 1f7c410:	test   %eax,%eax
 1f7c412:	je     1f7c430 <node_facts_window+0x730>
 1f7c414:	cmp    $0x1,%eax
 1f7c417:	jne    1f7c43a <node_facts_window+0x73a>
 1f7c419:	vzeroupper
 1f7c41c:	call   1f86650 <node_facts_dots_lean>
 1f7c421:	jmp    1f7c460 <node_facts_window+0x760>
 1f7c423:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c430:	vzeroupper
 1f7c433:	call   1f86320 <node_facts_dots>
 1f7c438:	jmp    1f7c460 <node_facts_window+0x760>
 1f7c43a:	vzeroupper
 1f7c43d:	call   1f86950 <node_facts_dots_loads>
 1f7c442:	jmp    1f7c460 <node_facts_window+0x760>
 1f7c444:	vzeroupper
 1f7c447:	call   1f86060 <node_facts_subscripts_loads>
 1f7c44c:	cmpl   $0x0,0x4c(%rsp)
 1f7c451:	jne    1f7c3f5 <node_facts_window+0x6f5>
 1f7c453:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c460:	cmpl   $0x0,0x50(%rsp)
 1f7c465:	je     1f7c492 <node_facts_window+0x792>
 1f7c467:	mov    0x10(%rsp),%rax
 1f7c46c:	xor    %r8d,%r8d
 1f7c46f:	cmpl   $0x0,0xc(%rsp)
 1f7c474:	mov    0xc(%r14),%ecx
 1f7c478:	mov    %rbp,%rdi
 1f7c47b:	mov    %r13d,%esi
 1f7c47e:	lea    0xc000(%rax,%r15,1),%rdx
 1f7c486:	setne  %r8b
 1f7c48a:	vzeroupper
 1f7c48d:	call   1f86b40 <node_facts_addresses_made>
 1f7c492:	cmpl   $0x0,0x54(%rsp)
 1f7c497:	je     1f7c4c4 <node_facts_window+0x7c4>
 1f7c499:	mov    0x10(%rsp),%rax
 1f7c49e:	xor    %r8d,%r8d
 1f7c4a1:	cmpl   $0x0,0xc(%rsp)
 1f7c4a6:	mov    0x10(%r14),%ecx
 1f7c4aa:	mov    %rbp,%rdi
 1f7c4ad:	mov    %r13d,%esi
 1f7c4b0:	lea    0x10000(%rax,%r15,1),%rdx
 1f7c4b8:	setne  %r8b
 1f7c4bc:	vzeroupper
 1f7c4bf:	call   1f86d50 <node_facts_casts>
 1f7c4c4:	cmpl   $0x0,0x58(%rsp)
 1f7c4c9:	je     1f7c4ea <node_facts_window+0x7ea>
 1f7c4cb:	mov    0x10(%rsp),%rax
 1f7c4d0:	mov    0x14(%r14),%ecx
 1f7c4d4:	mov    %rbp,%rdi
 1f7c4d7:	mov    %r13d,%esi
 1f7c4da:	lea    0x14000(%rax,%r15,1),%rdx
 1f7c4e2:	vzeroupper
 1f7c4e5:	call   1f87310 <node_facts_slow_list>
 1f7c4ea:	cmpl   $0x0,0x5c(%rsp)
 1f7c4ef:	je     1f7c51c <node_facts_window+0x81c>
 1f7c4f1:	mov    0x10(%rsp),%rax
 1f7c4f6:	xor    %r8d,%r8d
 1f7c4f9:	cmpl   $0x0,0xc(%rsp)
 1f7c4fe:	mov    0x18(%r14),%ecx
 1f7c502:	mov    %rbp,%rdi
 1f7c505:	mov    %r13d,%esi
 1f7c508:	lea    0x18000(%rax,%r15,1),%rdx
 1f7c510:	setne  %r8b
 1f7c514:	vzeroupper
 1f7c517:	call   1f87350 <node_facts_rows_made>
 1f7c51c:	movzbl 0x1b(%rsp),%ecx
 1f7c521:	movzbl 0x1a(%rsp),%edx
 1f7c526:	xor    %eax,%eax
 1f7c528:	movzbl 0x1f(%rsp),%esi
 1f7c52d:	vmovdqu 0x80(%rsp),%ymm0
 1f7c536:	mov    %cl,%al
 1f7c538:	xor    %ecx,%ecx
 1f7c53a:	mov    %dl,%cl
 1f7c53c:	movzbl 0x1c(%rsp),%edx
 1f7c541:	lea    (%rax,%rcx,2),%eax
 1f7c544:	xor    %ecx,%ecx
 1f7c546:	vptestnmd %ymm0,%ymm0,%k1
 1f7c54c:	mov    %dl,%cl
 1f7c54e:	xor    %edx,%edx
 1f7c550:	lea    (%rax,%rcx,4),%eax
 1f7c553:	movzbl 0x19(%rsp),%ecx
 1f7c558:	kshiftrb $0x1,%k1,%k0
 1f7c55e:	kmovw  %k1,0x80(%rsp)
 1f7c567:	mov    %cl,%dl
 1f7c569:	xor    %ecx,%ecx
 1f7c56b:	mov    %sil,%cl
 1f7c56e:	lea    (%rax,%rcx,8),%eax
 1f7c571:	movzbl 0x1e(%rsp),%ecx
 1f7c576:	shl    $0x4,%edx
 1f7c579:	or     %edx,%eax
 1f7c57b:	mov    %cl,%bl
 1f7c57d:	kmovd  %k1,%ecx
 1f7c581:	shl    $0x5,%ebx
 1f7c584:	not    %cl
 1f7c586:	or     %eax,%ebx
 1f7c588:	movzbl 0x1d(%rsp),%eax
 1f7c58d:	movzbl %cl,%ecx
 1f7c590:	and    $0x1,%ecx
 1f7c593:	shl    $0x7,%ecx
 1f7c596:	mov    %al,%r12b
 1f7c599:	kmovd  %k0,%eax
 1f7c59d:	shl    $0x6,%r12d
 1f7c5a1:	not    %al
 1f7c5a3:	or     %ebx,%r12d
 1f7c5a6:	movzbl %al,%ebx
 1f7c5a9:	and    $0x1,%ebx
 1f7c5ac:	shl    $0x8,%ebx
 1f7c5af:	or     %ecx,%ebx
 1f7c5b1:	or     %r12d,%ebx
 1f7c5b4:	mov    0xc(%rsp),%r12d
 1f7c5b9:	test   %bl,%bl
 1f7c5bb:	jns    1f7c600 <node_facts_window+0x900>
 1f7c5bd:	mov    0x10(%rsp),%rax
 1f7c5c2:	mov    0x1c(%r14),%ecx
 1f7c5c6:	mov    %rbp,%rdi
 1f7c5c9:	mov    %r13d,%esi
 1f7c5cc:	lea    0x1c000(%rax,%r15,1),%rdx
 1f7c5d4:	test   %r12d,%r12d
 1f7c5d7:	je     1f7c5f5 <node_facts_window+0x8f5>
 1f7c5d9:	cmp    $0x1,%r12d
 1f7c5dd:	jne    1f7c6e3 <node_facts_window+0x9e3>
 1f7c5e3:	vzeroupper
 1f7c5e6:	call   1f880a0 <node_facts_calls_lean>
 1f7c5eb:	test   $0x100,%ebx
 1f7c5f1:	jne    1f7c608 <node_facts_window+0x908>
 1f7c5f3:	jmp    1f7c631 <node_facts_window+0x931>
 1f7c5f5:	vzeroupper
 1f7c5f8:	call   1f876f0 <node_facts_calls>
 1f7c5fd:	nopl   (%rax)
 1f7c600:	test   $0x100,%ebx
 1f7c606:	je     1f7c631 <node_facts_window+0x931>
 1f7c608:	mov    0x10(%rsp),%rax
 1f7c60d:	mov    0x20(%r14),%ecx
 1f7c611:	xor    %r8d,%r8d
 1f7c614:	test   %r12d,%r12d
 1f7c617:	mov    %rbp,%rdi
 1f7c61a:	mov    %r13d,%esi
 1f7c61d:	setne  %r8b
 1f7c621:	lea    0x20000(%rax,%r15,1),%rdx
 1f7c629:	vzeroupper
 1f7c62c:	call   1f88c60 <node_facts_logics>
 1f7c631:	kmovw  0x80(%rsp),%k1
 1f7c63a:	kshiftrb $0x3,%k1,%k0
 1f7c640:	kmovd  %k0,%eax
 1f7c644:	kshiftrb $0x2,%k1,%k0
 1f7c64a:	kmovd  %k0,%ecx
 1f7c64e:	not    %al
 1f7c650:	not    %cl
 1f7c652:	movzbl %al,%ebp
 1f7c655:	movzbl %cl,%ecx
 1f7c658:	and    $0x1,%ebp
 1f7c65b:	and    $0x1,%ecx
 1f7c65e:	shl    $0xa,%ebp
 1f7c661:	shl    $0x9,%ecx
 1f7c664:	or     %ecx,%ebp
 1f7c666:	or     %ebx,%ebp
 1f7c668:	test   $0x200,%ebp
 1f7c66e:	je     1f7c69b <node_facts_window+0x99b>
 1f7c670:	mov    0x10(%rsp),%rax
 1f7c675:	mov    0x24(%r14),%ecx
 1f7c679:	mov    0x20(%rsp),%rdi
 1f7c67e:	xor    %r8d,%r8d
 1f7c681:	test   %r12d,%r12d
 1f7c684:	mov    %r13d,%esi
 1f7c687:	setne  %r8b
 1f7c68b:	lea    0x24000(%rax,%r15,1),%rdx
 1f7c693:	vzeroupper
 1f7c696:	call   1f88f20 <node_facts_updates>
 1f7c69b:	test   $0x400,%ebp
 1f7c6a1:	je     1f7c710 <node_facts_window+0xa10>
 1f7c6a3:	mov    0x10(%rsp),%rax
 1f7c6a8:	mov    0x28(%r14),%ecx
 1f7c6ac:	lea    0x28000(%rax,%r15,1),%rdx
 1f7c6b4:	test   %r12d,%r12d
 1f7c6b7:	je     1f7c6d1 <node_facts_window+0x9d1>
 1f7c6b9:	cmp    $0x1,%r12d
 1f7c6bd:	jne    1f7c6fc <node_facts_window+0x9fc>
 1f7c6bf:	mov    0x20(%rsp),%rdi
 1f7c6c4:	mov    %r13d,%esi
 1f7c6c7:	vzeroupper
 1f7c6ca:	call   1f89b50 <node_facts_dereferences_lean>
 1f7c6cf:	jmp    1f7c710 <node_facts_window+0xa10>
 1f7c6d1:	mov    0x20(%rsp),%rdi
 1f7c6d6:	mov    %r13d,%esi
 1f7c6d9:	vzeroupper
 1f7c6dc:	call   1f89900 <node_facts_dereferences>
 1f7c6e1:	jmp    1f7c710 <node_facts_window+0xa10>
 1f7c6e3:	vzeroupper
 1f7c6e6:	call   1f889b0 <node_facts_calls_loads>
 1f7c6eb:	test   $0x100,%ebx
 1f7c6f1:	jne    1f7c608 <node_facts_window+0x908>
 1f7c6f7:	jmp    1f7c631 <node_facts_window+0x931>
 1f7c6fc:	mov    0x20(%rsp),%rdi
 1f7c701:	mov    %r13d,%esi
 1f7c704:	vzeroupper
 1f7c707:	call   1f89d40 <node_facts_dereferences_loads>
 1f7c70c:	nopl   0x0(%rax)
 1f7c710:	kmovw  0x80(%rsp),%k1
 1f7c719:	mov    0x20(%rsp),%r12
 1f7c71e:	kshiftrb $0x5,%k1,%k0
 1f7c724:	kmovd  %k0,%eax
 1f7c728:	kshiftrb $0x4,%k1,%k0
 1f7c72e:	kmovd  %k0,%ecx
 1f7c732:	not    %al
 1f7c734:	not    %cl
 1f7c736:	movzbl %al,%ebx
 1f7c739:	movzbl %cl,%ecx
 1f7c73c:	and    $0x1,%ebx
 1f7c73f:	and    $0x1,%ecx
 1f7c742:	shl    $0xc,%ebx
 1f7c745:	shl    $0xb,%ecx
 1f7c748:	or     %ecx,%ebx
 1f7c74a:	or     %ebp,%ebx
 1f7c74c:	test   $0x800,%ebx
 1f7c752:	je     1f7c77f <node_facts_window+0xa7f>
 1f7c754:	mov    0x10(%rsp),%rax
 1f7c759:	xor    %r8d,%r8d
 1f7c75c:	cmpl   $0x0,0xc(%rsp)
 1f7c761:	mov    0x2c(%r14),%ecx
 1f7c765:	mov    %r12,%rdi
 1f7c768:	mov    %r13d,%esi
 1f7c76b:	lea    0x2c000(%rax,%r15,1),%rdx
 1f7c773:	setne  %r8b
 1f7c777:	vzeroupper
 1f7c77a:	call   1f89f00 <node_facts_stores>
 1f7c77f:	test   $0x1000,%ebx
 1f7c785:	je     1f7c7b2 <node_facts_window+0xab2>
 1f7c787:	mov    0x10(%rsp),%rax
 1f7c78c:	xor    %r8d,%r8d
 1f7c78f:	cmpl   $0x0,0xc(%rsp)
 1f7c794:	mov    0x30(%r14),%ecx
 1f7c798:	mov    %r12,%rdi
 1f7c79b:	mov    %r13d,%esi
 1f7c79e:	lea    0x30000(%rax,%r15,1),%rdx
 1f7c7a6:	setne  %r8b
 1f7c7aa:	vzeroupper
 1f7c7ad:	call   1f8a4f0 <node_facts_converts>
 1f7c7b2:	kmovw  0x80(%rsp),%k1
 1f7c7bb:	kshiftrb $0x7,%k1,%k0
 1f7c7c1:	kmovd  %k0,%eax
 1f7c7c5:	kshiftrb $0x6,%k1,%k0
 1f7c7cb:	kmovd  %k0,%ecx
 1f7c7cf:	not    %al
 1f7c7d1:	not    %cl
 1f7c7d3:	movzbl %al,%ebp
 1f7c7d6:	movzbl %cl,%ecx
 1f7c7d9:	and    $0x1,%ebp
 1f7c7dc:	and    $0x1,%ecx
 1f7c7df:	shl    $0xe,%ebp
 1f7c7e2:	shl    $0xd,%ecx
 1f7c7e5:	or     %ecx,%ebp
 1f7c7e7:	or     %ebx,%ebp
 1f7c7e9:	test   $0x2000,%ebp
 1f7c7ef:	jne    1f7c810 <node_facts_window+0xb10>
 1f7c7f1:	mov    0x20(%rsp),%r12
 1f7c7f6:	cmp    $0x4000,%ebp
 1f7c7fc:	jae    1f7c83e <node_facts_window+0xb3e>
 1f7c7fe:	mov    0x70(%rsp),%rcx
 1f7c803:	cmp    $0x2,%rcx
 1f7c807:	jbe    1f7c874 <node_facts_window+0xb74>
 1f7c809:	jmp    1f7c891 <node_facts_window+0xb91>
 1f7c80e:	xchg   %ax,%ax
 1f7c810:	mov    0x10(%rsp),%rax
 1f7c815:	mov    0x34(%r14),%ecx
 1f7c819:	mov    0x20(%rsp),%rdi
 1f7c81e:	mov    %r13d,%esi
 1f7c821:	lea    0x34000(%rax,%r15,1),%rdx
 1f7c829:	vzeroupper
 1f7c82c:	call   1f8aa70 <node_facts_discards>
 1f7c831:	mov    0x20(%rsp),%r12
 1f7c836:	cmp    $0x4000,%ebp
 1f7c83c:	jb     1f7c7fe <node_facts_window+0xafe>
 1f7c83e:	mov    0x10(%rsp),%rax
 1f7c843:	xor    %r8d,%r8d
 1f7c846:	cmpl   $0x0,0xc(%rsp)
 1f7c84b:	mov    0x38(%r14),%ecx
 1f7c84f:	mov    %r12,%rdi
 1f7c852:	mov    %r13d,%esi
 1f7c855:	lea    0x38000(%rax,%r15,1),%rdx
 1f7c85d:	setne  %r8b
 1f7c861:	vzeroupper
 1f7c864:	call   1f8ac20 <node_facts_truths>
 1f7c869:	mov    0x70(%rsp),%rcx
 1f7c86e:	cmp    $0x2,%rcx
 1f7c872:	ja     1f7c891 <node_facts_window+0xb91>
 1f7c874:	inc    %rcx
 1f7c877:	add    $0x40000,%r15
 1f7c87e:	add    $0x40,%r14
 1f7c882:	shrx   %ecx,0x2c(%rsp),%eax
 1f7c889:	test   %eax,%eax
 1f7c88b:	jne    1f7c290 <node_facts_window+0x590>
 1f7c891:	testb  $0x10,0x2c(%rsp)
 1f7c896:	mov    0x48(%rsp),%ebp
 1f7c89a:	mov    0x44(%rsp),%r15d
 1f7c89f:	mov    0x78(%rsp),%rbx
 1f7c8a4:	je     1f7c8c9 <node_facts_window+0xbc9>
 1f7c8a6:	mov    $0x100000,%edx
 1f7c8ab:	add    0x2e0(%r12),%rdx
 1f7c8b3:	mov    0x3e8(%r12),%ecx
 1f7c8bb:	mov    %r12,%rdi
 1f7c8be:	mov    %r13d,%esi
 1f7c8c1:	vzeroupper
 1f7c8c4:	call   1f87310 <node_facts_slow_list>
 1f7c8c9:	test   %bpl,%bpl
 1f7c8cc:	je     1f7c8d9 <node_facts_window+0xbd9>
 1f7c8ce:	rdtsc
 1f7c8d0:	shl    $0x20,%rdx
 1f7c8d4:	or     %rax,%rdx
 1f7c8d7:	jmp    1f7c8db <node_facts_window+0xbdb>
 1f7c8d9:	xor    %edx,%edx
 1f7c8db:	sub    %rbx,%rdx
 1f7c8de:	sub    0x60(%rsp),%rbx
 1f7c8e3:	mov    0x38(%rsp),%rax
 1f7c8e8:	vmovq  %rdx,%xmm0
 1f7c8ed:	vmovq  %rbx,%xmm1
 1f7c8f2:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f7c8f6:	vpaddq 0x910(%r12),%xmm0,%xmm0
 1f7c900:	vmovdqu %xmm0,0x910(%r12)
 1f7c90a:	mov    %eax,0x930(%r12)
 1f7c912:	mov    %r15d,0x934(%r12)
 1f7c91a:	add    $0xa8,%rsp
 1f7c921:	pop    %rbx
 1f7c922:	pop    %r12
 1f7c924:	pop    %r13
 1f7c926:	pop    %r14
 1f7c928:	pop    %r15
 1f7c92a:	pop    %rbp
 1f7c92b:	vzeroupper
 1f7c92e:	ret
 1f7c92f:	mov    %r13d,%ebp
 1f7c932:	mov    0x30(%rsp),%r13
 1f7c937:	cmpl   $0x0,0xc(%rsp)
 1f7c93c:	jne    1f7c236 <node_facts_window+0x536>
 1f7c942:	jmp    1f7bff3 <node_facts_window+0x2f3>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
