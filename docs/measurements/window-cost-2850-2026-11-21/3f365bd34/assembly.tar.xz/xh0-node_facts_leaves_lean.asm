
results/xh0/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f83e70 <node_facts_leaves_lean>:
 1f83e70:	test   %edx,%edx
 1f83e72:	je     1f83f19 <node_facts_leaves_lean+0xa9>
 1f83e78:	push   %rbp
 1f83e79:	push   %r15
 1f83e7b:	push   %r14
 1f83e7d:	push   %r13
 1f83e7f:	push   %r12
 1f83e81:	push   %rbx
 1f83e82:	sub    $0x18,%rsp
 1f83e86:	mov    0x2c0(%rdi),%rax
 1f83e8d:	mov    0x2c8(%rdi),%r15
 1f83e94:	mov    0x28(%rdi),%rbp
 1f83e98:	mov    %rdi,%rbx
 1f83e9b:	mov    %edx,%r14d
 1f83e9e:	xor    %r12d,%r12d
 1f83ea1:	mov    %rax,0x10(%rsp)
 1f83ea6:	mov    %esi,%eax
 1f83ea8:	lea    0x0(,%rax,4),%r13
 1f83eb0:	add    0x220(%rdi),%r13
 1f83eb7:	mov    %rax,0x8(%rsp)
 1f83ebc:	jmp    1f83edc <node_facts_leaves_lean+0x6c>
 1f83ebe:	xchg   %ax,%ax
 1f83ec0:	vmovups 0x0(%rbp,%rax,1),%ymm0
 1f83ec6:	mov    0x10(%rsp),%rax
 1f83ecb:	shl    $0x6,%rdx
 1f83ecf:	vmovups %ymm0,(%rax,%rdx,1)
 1f83ed4:	inc    %r12
 1f83ed7:	cmp    %r12,%r14
 1f83eda:	je     1f83f0b <node_facts_leaves_lean+0x9b>
 1f83edc:	mov    (%r15,%r12,4),%edx
 1f83ee0:	mov    0x0(%r13,%rdx,4),%eax
 1f83ee5:	shl    $0x5,%rax
 1f83ee9:	cmpl   $0x0,0x1c(%rbp,%rax,1)
 1f83eee:	je     1f83ec0 <node_facts_leaves_lean+0x50>
 1f83ef0:	mov    %rdx,%rsi
 1f83ef3:	add    0x8(%rsp),%rsi
 1f83ef8:	mov    %rbx,%rdi
 1f83efb:	vzeroupper
 1f83efe:	call   1f89c50 <node_facts_leave>
 1f83f03:	inc    %r12
 1f83f06:	cmp    %r12,%r14
 1f83f09:	jne    1f83edc <node_facts_leaves_lean+0x6c>
 1f83f0b:	add    $0x18,%rsp
 1f83f0f:	pop    %rbx
 1f83f10:	pop    %r12
 1f83f12:	pop    %r13
 1f83f14:	pop    %r14
 1f83f16:	pop    %r15
 1f83f18:	pop    %rbp
 1f83f19:	vzeroupper
 1f83f1c:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
