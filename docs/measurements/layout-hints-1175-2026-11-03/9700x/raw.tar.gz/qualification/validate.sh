set -euo pipefail
validate_jobs() {
    jq -e '
      [.[].jobs[]] as $jobs |
      [$jobs[] | select(.name | startswith("Tests on Ubuntu "))] as $tests |
      [$jobs[] | select(.name | startswith("libFuzzer ("))] as $fuzz |
      ([ ["x86-64", "native"][] as $arch |
         ["none", "address", "undefined", "thread", "memory"][] as $san |
         range(1; 5) as $shard |
         "Tests on Ubuntu 26.04 (Clang 23, \($arch), \($san), O3, shard \($shard) of 4)" ] +
       [ ["x86-64", "native"][] as $arch | range(1; 5) as $shard |
         "Tests on Ubuntu 26.04 (Clang 23, \($arch), address, O1, shard \($shard) of 4)" ]) as $expected |
      all($expected[]; . as $name | any($tests[]; .name == $name and .conclusion == "success")) and
      all($tests[]; .conclusion == "success") and
      all(["frontend", "crash-replay-proof", "elf-override"][];
          . as $entry | any($fuzz[]; .name == ("libFuzzer (ASan + UBSan + leaks, " + $entry + ")") and .conclusion == "success")) and
      ($fuzz | length == 3) and all($fuzz[]; .conclusion == "success") and
      any($jobs[]; .name == "Native tests and benchmarks on Benchpress (Ryzen 7 9700X)" and .conclusion == "success" and
          any(.steps[]?; .name == "Run complete native vector correctness before benchmarks" and .conclusion == "success"))
    ' "$1" > /dev/null
}

validate_jobs "$1"
