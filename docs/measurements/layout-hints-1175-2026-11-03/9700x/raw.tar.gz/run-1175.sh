#!/usr/bin/env bash
set -euo pipefail
task_root="$HOME/buster-fast-bench/1296-codex-20261105"
source_tree="$task_root/source"
record="$task_root/harness/docs/measurements/layout-hints-1175-2026-11-03"
export CAMPAIGN_DIRECTORY="$task_root/campaign"
export CAMPAIGN_CORPUS="$task_root/corpus"
export CAMPAIGN_HOST_ARCH=znver5 CAMPAIGN_CPU=2 CAMPAIGN_RUNS=11 CAMPAIGN_LANES=''
export CAMPAIGN_EVENTS=instructions:u,cycles:u,ex_ret_brn_tkn:u
export EXCLUSIVE_OWNER=codex-1296 EXCLUSIVE_TITLE='One-off checker layout acceptance #1175'
export EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1296
export BUSTER_CI_CACHE="${XDG_CACHE_HOME:-$HOME/.cache}/buster/ci"
export GITHUB_PATH="$task_root/tool-paths" GITHUB_ENV="$task_root/tool-env"
unset CAMPAIGN_LOCK BUSTER_9700X_HELD
mkdir -p "$CAMPAIGN_DIRECTORY/logs"
phase=setup
trap 'result=$?; printf "phase=%s\nexit=%s\n" "$phase" "$result" > "$task_root/status.txt"' EXIT
test "$(uname -s)" = Linux
test "$(uname -m)" = x86_64
grep -Eq '^model name[[:space:]]*:[[:space:]]*AMD Ryzen 7 9700X([[:space:]]|$)' /proc/cpuinfo
test "$(cat /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor)" = performance
test "$(git -C "$task_root/harness" rev-parse HEAD)" = 961e2893fe13ac4c30547ff86f1e2e279e09b06b
test "$(git -C "$source_tree" rev-parse c79fd0076fc8ee3ba0a43d02f94dca417a7557ea^1)" = e36740b8f70cf5755cabff9b2a9a998b173c2878
git -C "$source_tree" merge-base --is-ancestor c79fd0076fc8ee3ba0a43d02f94dca417a7557ea refs/remotes/origin/main
: > "$GITHUB_PATH"
: > "$GITHUB_ENV"
bash -n "$record/scripts/campaign-9700x.sh"
"$HOME/buster-fast-bench/exclusive.sh" bash "$source_tree/tools/ci/setup-benchpress.sh"
while IFS= read -r directory; do export PATH="$directory:$PATH"; done < "$GITHUB_PATH"
while IFS= read -r assignment; do export "$assignment"; done < "$GITHUB_ENV"
"$HOME/buster-fast-bench/exclusive.sh" bash "$source_tree/tools/ci/fetch-corpus.sh" "$CAMPAIGN_CORPUS" 2>&1 | tee "$CAMPAIGN_DIRECTORY/logs/corpus-verification.txt"
printf 'base=%s\nhead=%s\nharness=%s\nexecution=tailscale-ssh\nlock=exclusive.sh-per-run\n' e36740b8f70cf5755cabff9b2a9a998b173c2878 c79fd0076fc8ee3ba0a43d02f94dca417a7557ea 961e2893fe13ac4c30547ff86f1e2e279e09b06b > "$CAMPAIGN_DIRECTORY/logs/identity.txt"
phase=campaign
bash "$record/scripts/campaign-9700x.sh" "$source_tree" main=e36740b8f70cf5755cabff9b2a9a998b173c2878 head=c79fd0076fc8ee3ba0a43d02f94dca417a7557ea 2>&1 | tee "$CAMPAIGN_DIRECTORY/logs/campaign.txt"
phase=verification
bash "$task_root/verify-1175.sh"
phase=complete
