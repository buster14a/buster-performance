#!/usr/bin/env bash
set -euo pipefail
R="$CAMPAIGN_DIRECTORY"
declare -A first_offset
for name in main head; do
    for placement in 0:0 688:256 1376:512 2064:768; do
        skip=${placement%%:*}
        shift=${placement#*:}
        tag="$name-$skip-$shift"
        binary="$R/shifts/$name/compiler-$skip-$shift"
        sha256sum "$binary" >> "$R/logs/executables.sha256"
        nm --defined-only "$binary" > "$R/logs/$tag.nm"
        for symbol in check_input_resolve_range check_graph_run main; do
            address=$(awk -v symbol="$symbol" '$2 ~ /^[tT]$/ && $3 == symbol && !seen++ { print $1 }' "$R/logs/$tag.nm")
            [[ "$address" =~ ^[[:xdigit:]]+$ ]]
            offset=$((16#$address % 4096))
            if [ "$skip" -eq 0 ]; then first_offset["$name/$symbol"]=$offset; fi
            initial=${first_offset["$name/$symbol"]}
            actual=$(((offset - initial + 4096) % 4096))
            expected=$skip
            if [ "$symbol" = main ]; then expected=$shift; fi
            printf '%s %s offset=%s displacement=%s expected=%s\n' "$tag" "$symbol" "$offset" "$actual" "$expected" >> "$R/logs/placements.txt"
            test "$actual" -eq "$expected"
        done
        objects="$R/objects/$tag"
        test "$(find "$objects" -type f -name '*.o' | wc -l)" -eq 140
        (cd "$objects" && find . -type f -name '*.o' -print0 | LC_ALL=C sort -z | xargs -0 sha256sum) > "$R/logs/objects-$tag.sha256"
        cmp "$R/logs/objects-main-0-0.sha256" "$R/logs/objects-$tag.sha256"
    done
done
test "$(wc -l < "$R/logs/counters-expected.txt")" -eq 216
test "$(wc -l < "$R/logs/counters.txt")" -eq 216
test "$(find "$R/logs" -maxdepth 1 -type f -name 'perf-*.csv' | wc -l)" -eq 72
"$R/counters" "$R/logs/counters-expected.txt" < "$R/logs/counters.txt" > "$R/logs/counters-verified.txt"
cmp "$R/logs/counters-summary.txt" "$R/logs/counters-verified.txt"
test -s "$R/logs/time-runs.txt"
printf '%s\n' 'Collection complete. Review cycles, taken branches and timings before accepting #1175.' > "$R/logs/collection-complete.txt"
