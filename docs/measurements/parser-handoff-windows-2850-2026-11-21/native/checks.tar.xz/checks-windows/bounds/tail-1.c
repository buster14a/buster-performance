int f(void) {; return (1 + (2 * (3 + 4))); }
