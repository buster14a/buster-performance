;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;typedef int I; int (*p)(I); int f(int (*a)(I), int b) { int local(int); return a(b) + local(b); }
int (*g(void))(int) {return p;} int use(void) {return g()(2);}
struct S { int x; } __attribute__((aligned(8))); int done;
