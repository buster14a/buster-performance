int g(int x) { [[clang::likely]] switch (x) { case 1: x++; [[fallthrough]]; case 2: break; default: break; } return x; }
