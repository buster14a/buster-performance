int g(int x) { [[clang::likely]] for (;;) { [[clang::unlikely]] switch (x) { case 0: [[fallthrough]]; case 1: continue; } break; } return x; }
