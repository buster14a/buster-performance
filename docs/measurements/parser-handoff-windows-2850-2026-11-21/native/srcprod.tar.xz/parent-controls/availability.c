int available(void) { if (__builtin_available(macos 1.2_3, *)) return 1; return 0; }
