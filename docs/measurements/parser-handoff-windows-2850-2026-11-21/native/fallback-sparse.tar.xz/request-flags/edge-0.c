typedef int I; int proto(I); int a; int b, c; int (*ptr)(int);
int first(I x) { return x; }
struct S { int a; struct { int z; } s; }; int (*f(void))(int) {return ptr;}
int second(int (*g)(int), int x) { return g(x) + f()(x); } int final;
