from pathlib import Path
p=Path(__file__).parent
build='/tmp/buster-main-5f530282-6b097f86/source/build/pp-branch-parent'
head='/tmp/buster-branch-smallfront-6b097f86/source/build/compiler'
s=(p/'coldwork-objects').read_text().replace('coldwork','smallfront').replace('/dev/shm/buster-unroll-6b097f86/src/build/unroll-base',build).replace('/dev/shm/buster-unroll-6b097f86/src/build/branch-smallfront',head)
(p/'smallfront-objects').write_text(s)
s=(p/'bench-coldwork').read_text().replace('coldwork','smallfront').replace('coldfull','smallfull').replace('$build/unroll-base',build).replace('$build/branch-smallfront',head)
(p/'bench-smallfront').write_text(s)
s=(p/'build-coldwork-retry').read_text();a=s.index('previous=');b=s.index('for seed in',a)
s=s[:a]+'''d=/tmp/buster-branch-smallfront-6b097f86/source
main=/tmp/buster-main-5f530282-6b097f86
cd "$d"
export BUSTER_HOST_ARCH=znver5
if [[ ! -e "$main/source/build/pp-branch-parent" ]];then ln "$main/images/main" "$main/source/build/pp-branch-parent";fi
git apply "$root/smallfront.patch"
"$lock" timeout 1200 ./build.sh --config Release --jobs 4 >"$root/smallfront-compiler-build.log" 2>&1
touch "$root/smallfront-compiler-built.ok"
'''+s[b:].replace('coldwork','smallfront').replace('"$ir/src/build/branch-smallfront"','"$d/build/compiler"')
(p/'build-smallfront').write_text(s)
