from pathlib import Path
import runpy
p=Path(__file__).resolve().parent
m=runpy.run_path(str(p/'record-compiler-boundaries.py'))
t,counts=m['table']([('smallfull','smallfront')])
assert counts['smallfront']==[11,11]
for n in (1,133,789): assert '404 compared, 404 the same' in (m['r']/f'smallfront-compiler-cross-{n}.log').read_text()
cs=m['corpus']('smallfront')
title='Branch sizing with a small entry function in the complete compiler'
body='The complete compiler retains paired branch ranks and keeps the table-based rank builder and vector offset writer out of line. Three interleaved parent/candidate pairs on the locked 9700X used seeds 1, 133 and 789. The emitted bytes matched GNU as for all 404 functions at each seed. The candidate improved sizing alone and sizing followed by encoding in all eleven workloads. Changes are median paired ratios.\n\n| Workload | Sizing cycles/branch | With encoding |\n| --- | ---: | ---: |\n'+'\n'.join(t)+'\n\nFive paired rounds of three whole compiler processes under the same lock produced the same 2,742 debug objects, standard output and diagnostics. Five whole-compilation medians improved. Tier 0 SQLite took 0.063% more user cycles.\n\n| Corpus | Tier 0 user cycles | Tier 1 user cycles |\n| --- | ---: | ---: |\n'+'\n'.join(cs)
from score import rows,phase,d
from statistics import median
ph=[]
for row in rows:
    old=[];new=[]
    for i,seed in enumerate((1,133,789),1):
        text=(d/f'bench-{i}.log').read_text()
        old.append(phase(text[text.index('\n'+row+':'):],'scalar'))
        new.append(phase((m['r']/f'smallfull-smallfront-{seed}-{row}.log').read_text(),'vector'))
    vals=[median(x[i]for x in group)for i in (2,5)for group in (old,new)]
    ph.append('| '+row+' | '+' | '.join(f'{v:.2f}'for v in vals)+' |')
body+='\n\nThe historical scalar phase measurements used three processes on the same CPU. Ranks and write are differences between benchmark phases, in core cycles per branch.\n\n| Workload | Scalar ranks | Candidate ranks | Scalar write | Candidate write |\n| --- | ---: | ---: | ---: | ---: |\n'+'\n'.join(ph)
print(*ph,sep='\n')
m['save'](title,body,'full-compiler-small-front',['record-smallfront.py','smallfront','smallfront.patch','smallfront-current.py','build-smallfront','bench-smallfront','smallfront-objects'],['smallfull-*.log','smallfront-objects-*.sha','smallfront-compile-*.log','smallfront-compiler-cross-*.log'])
