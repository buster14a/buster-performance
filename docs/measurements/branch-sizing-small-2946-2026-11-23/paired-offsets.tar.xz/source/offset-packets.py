from pathlib import Path
p=Path(__file__).parent
for name in ('pairedranks','ranklanes','markscan','byteadd'):
 out=p/name/'buster/compiler';out.mkdir(exist_ok=True,parents=True)
 (out/'branch_sizing_benchmark.c').write_text((p/'roundcount/buster/compiler/branch_sizing_benchmark.c').read_text())
 s=(p/'roundcount/buster/compiler/branch_sizing.c').read_text()
 a=s.index('        for (uint64_t i = start;',s.index('static void branch_sizing_offsets_vector'));b=s.index('\n        }',a)+10
 if name=='pairedranks':
  t='''        for (uint64_t i = start; i < count; i += BUSTER_BRANCH_SIZING_RANK_RECORDS)
        {
            const uint64_t entry = columns->ranks[i / BUSTER_BRANCH_SIZING_RANK_RECORDS];
            const uint64_t k = entry >> 32;
            const uint32_t bits = (uint32_t)entry;
            for (uint32_t part = 0; part < BUSTER_BRANCH_SIZING_RANK_RECORDS && i + part < count; part += BUSTER_BRANCH_SIZING_LANES)
            {
                const __mmask16 lanes = branch_sizing_lanes(i + part, count);
                const uint32_t marks = bits >> part;
                const uint64_t rank = part ? k + (uint32_t)__builtin_popcount(bits & 0xffffu) : k;
                const __m512i local = _mm512_popcnt_epi32(_mm512_and_si512(_mm512_set1_epi32((int32_t)marks), below));
                const __m512i growth = _mm512_permutexvar_epi32(local, _mm512_loadu_si512(prefix + rank));
                const __m512i offset = _mm512_maskz_loadu_epi32(lanes, offsets + i + part);
                _mm512_mask_storeu_epi32(offsets + i + part, lanes, _mm512_add_epi32(offset, growth));
            }
        }'''
 elif name=='ranklanes':
  t='''        for (uint64_t i = start; i < count; i += BUSTER_BRANCH_SIZING_RANK_RECORDS)
        {
            const uint64_t entry = columns->ranks[i / BUSTER_BRANCH_SIZING_RANK_RECORDS];
            const uint32_t bits = (uint32_t)entry;
            const uint32_t* row = prefix + (entry >> 32);
            const __mmask16 lanes = branch_sizing_lanes(i, count);
            const __m512i low = _mm512_popcnt_epi32(_mm512_and_si512(_mm512_set1_epi32((int32_t)bits), below));
            const __m512i sums = _mm512_loadu_si512(row);
            const __m512i growth = _mm512_permutexvar_epi32(low, sums);
            const __m512i offsets0 = _mm512_maskz_loadu_epi32(lanes, offsets + i);
            _mm512_mask_storeu_epi32(offsets + i, lanes, _mm512_add_epi32(offsets0, growth));
            if (i + BUSTER_BRANCH_SIZING_LANES < count)
            {
                const uint32_t before = (uint32_t)__builtin_popcount(bits & 0xffffu);
                const __mmask16 last = branch_sizing_lanes(i + BUSTER_BRANCH_SIZING_LANES, count);
                const __m512i high = _mm512_popcnt_epi32(_mm512_and_si512(_mm512_set1_epi32((int32_t)(bits >> 16)), below));
                const __m512i grown = _mm512_permutexvar_epi32(high, _mm512_loadu_si512(row + before));
                const __m512i offsets1 = _mm512_maskz_loadu_epi32(last, offsets + i + BUSTER_BRANCH_SIZING_LANES);
                _mm512_mask_storeu_epi32(offsets + i + BUSTER_BRANCH_SIZING_LANES, last, _mm512_add_epi32(offsets1, grown));
            }
        }'''
 elif name=='markscan':
  t='''        for (uint64_t i = start; i < count; i += BUSTER_BRANCH_SIZING_LANES)
        {
            const uint64_t entry = columns->ranks[i / BUSTER_BRANCH_SIZING_RANK_RECORDS];
            const uint32_t part = (uint32_t)(i % BUSTER_BRANCH_SIZING_RANK_RECORDS);
            const uint32_t marks = (uint32_t)entry >> part;
            const uint64_t rank = (entry >> 32) + (part ? (uint32_t)__builtin_popcount((uint32_t)entry & 0xffffu) : 0);
            const __mmask16 lanes = branch_sizing_lanes(i, count);
            // Each marked record grows the offset of the next record and all records after it.
            const __m512i deltas = _mm512_maskz_expandloadu_epi32((__mmask16)(marks << 1), columns->growth + rank);
            const __m512i growth = _mm512_add_epi32(_mm512_set1_epi32((int32_t)prefix[rank]), branch_sizing_scan(deltas));
            const __m512i offset = _mm512_maskz_loadu_epi32(lanes, offsets + i);
            _mm512_mask_storeu_epi32(offsets + i, lanes, _mm512_add_epi32(offset, growth));
        }'''
 else:
  # Consume sorted branches in their original order and update the prefix at each vector of 16 offsets.
  t='''        uint64_t k = first;
        uint32_t total = 0;
        for (uint64_t i = start; i < count; i += BUSTER_BRANCH_SIZING_LANES)
        {
            const uint64_t entry = columns->ranks[i / BUSTER_BRANCH_SIZING_RANK_RECORDS];
            const uint32_t shift = (uint32_t)(i % BUSTER_BRANCH_SIZING_RANK_RECORDS);
            const uint32_t marks = (uint32_t)(entry >> shift) & 0xffff;
            const uint64_t rank = (entry >> 32) + (shift ? (uint32_t)__builtin_popcount((uint32_t)entry & 0xffff) : 0);
            const __mmask16 lanes = branch_sizing_lanes(i, count);
            const __m512i all = _mm512_maskz_expandloadu_epi32((__mmask16)marks, columns->growth + rank);
            const __m512i adjusted = _mm512_add_epi32(_mm512_set1_epi32((int32_t)prefix[rank]), _mm512_sub_epi32(branch_sizing_scan(all), all));
            const __m512i offset = _mm512_maskz_loadu_epi32(lanes, offsets + i);
            _mm512_mask_storeu_epi32(offsets + i, lanes, _mm512_add_epi32(offset, adjusted));
        }'''
  t=t.replace('        uint64_t k = first;\n        uint32_t total = 0;\n','')
 s=s[:a]+t+s[b:]
 (out/'branch_sizing.c').write_text(s)
s=(p/'compare-counts').read_text().replace('roundcount stablecount','pairedranks ranklanes markscan byteadd').replace('"count-$name-', '"offset-$name-').replace('touch count-rounds.ok','touch offset-rounds.ok')
# Check writes and offsets against the independent full-function oracle before any measurements.
i=s.index('for seed in 1 133 789;')
s=s[:i]+'''for name in pairedranks ranklanes markscan byteadd;do
 "$lock" "$cc" -O3 -march=native -fwrapv -funsigned-char -fno-strict-aliasing -ffunction-sections -Wl,--gc-sections -I"$PWD/$name" -I"$src" -I"$src/buster/compiler" correct.c -o "offset-check-$name" >"offset-check-build-$name.log" 2>&1
 for seed in 1 133 789;do "$lock" taskset -c 2 "./offset-check-$name" --seed "$seed" >"offset-check-$name-$seed.log" 2>&1;done
done
touch offset-checked.ok
'''+s[i:]
(p/'compare-offsets').write_text(s)
