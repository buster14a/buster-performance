from pathlib import Path
from statistics import median
import re,tarfile
from score import rows,rowres,phase,d
p=Path(__file__).parent;r=p/'full-results';out=Path('/workspace/buster-performance/docs/measurements/branch-sizing-small-2946-2026-11-23')
def pct(xs):return f'{(median(xs)-1)*100:+.3f}%'
production=[];stand=[];tallies={}
for row in rows:
 pairs={}
 arch=[]
 for i in (1,2,3):
  s=(d/f'bench-{i}.log').read_text();arch.append(phase(s[s.index('\n'+row+':'):],'scalar'))
 for prefix,head in [('offsetfull','ranklanes')]+[('offset',n) for n in ('pairedranks','ranklanes','markscan','byteadd')]:
  base=[];new=[]
  for seed in (1,133,789):
   for side,ls in [('base',base),(head,new)]:
    file=r/(f'{prefix}-{side}-{seed}-{row}.log' if prefix=='offsetfull' else f'{prefix}-{side}-{row}-{seed}.log')
    s=file.read_text();assert re.search(r'^  window .*ns per branch\); whole',s,re.M);ls.append(rowres(s))
  ratios=[median(h[i]/b[i]for h,b in zip(new,base))for i in range(2)]
  pairs[prefix,head]=ratios
  if prefix=='offsetfull':
   vals=[median(x[i]for x in new) for i in (4,7)];old=[median(x[i]for x in arch)for i in (2,5)]
   production.append('| '+row+' | '+' | '.join([pct([q])for q in ratios]+[f'{q:.2f}'for q in [vals[0],old[0],vals[1],old[1]]])+' |')
 for k,v in pairs.items():tallies.setdefault(k,[]).append(v)
 stand.append('| '+row+' | '+' | '.join(pct([q])for v in ('pairedranks','ranklanes','markscan','byteadd')for q in pairs['offset',v])+' |')
src=(p/'record-round.py').read_text();exec(src[src.index('corpus=[]'):src.index("body='''")].replace('round-objects','offset-objects').replace('round-compile','offset-compile'))
body='''## Offset updates from the paired rank table

Four further implementations use the recorded branch ranks while applying prefix growths to the final offsets. A complete compiler build used the rank-lane implementation, which loads the compact entry spanning two sixteen-record packets. Each value below comes from three locked 9700X pairs with seeds 1, 133 and 789. Ranks and write give cycles per branch from the benchmark’s phase subtraction. The original archived scalar columns use three measurements of the same workload.

| Workload | Sizing change | Sizing and encoding change | Ranks | Archived scalar ranks | Write | Archived scalar write |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(production)+'''

The standalone values compare each implementation and its same-binary-layout harness parent. Each pair of columns gives sizing followed by sizing plus encoding.

| Workload | Paired ranks size | With encode | Rank lanes size | With encode | Mark scan size | With encode | Byte adds size | With encode |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(stand)+'''

Complete debug compilations ran five paired rounds of three processes. Both output streams and all 1,371 object hashes matched per tier. The complete compiler passed 17,667 branch-sizing checks and 4,609 further checks, with all 404 generated functions matching GNU as at each of three seeds.

| Workload | Tier 0 | Tier 1 |
| --- | ---: | ---: |
'''+'\n'.join(corpus)+'''

[Source variants, build commands, all raw timings, GNU results and object hashes](paired-offsets.tar.xz)
'''
with tarfile.open(out/'paired-offsets.tar.xz','w:xz',preset=2)as t:
 for name in ('pairedranks','ranklanes','markscan','byteadd','ranklanes.patch','offset-packets.py','integrate-offsets','compare-offsets','offset-objects','integrated-offsets','score.py','record-round.py','record-offsets.py'):t.add(p/name,arcname='source/'+name)
 for f in sorted(r.glob('offset*')):
  if f.is_file()and f.suffix in ['.sha','.log']:t.add(f,arcname='native/'+f.name)
file=out/'README.md';file.write_text(file.read_text().split('\n## Offset updates from the paired rank table')[0].rstrip()+'\n\n'+body)
print(*production,*corpus,sep='\n');print([(k,[sum(v[i]<=1 for v in vs)for i in (0,1)])for k,vs in tallies.items()])
