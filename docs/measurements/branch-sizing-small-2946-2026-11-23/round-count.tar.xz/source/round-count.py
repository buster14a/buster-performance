from pathlib import Path
p=Path(__file__).parent
src=p/'popwhole/buster/compiler'
for label in ('roundcount','stablecount'):
 for f in ('branch_sizing.c','branch_sizing_benchmark.c'):
  s=(src/f).read_text()
  bench=f.endswith('benchmark.c')
  func='branch_sizing_benchmark_round_window' if bench else 'branch_sizing_round_vector'
  a=s.index('static bool '+func+'(');b=s.index('\n}',a)+2;t=s[a:b]
  t=t.replace(')\n{',', uint64_t* long_count)\n{')
  t=t.replace('    after[0] = 0;', '    uint64_t long_branches = 0;\n    after[0] = 0;')
  t=t.replace('        const __mmask16 grows = _mm512_test_epi32_mask(old, old) |', '''        const __mmask16 long_lanes = _mm512_test_epi32_mask(old, old);
        long_branches += (uint32_t)__builtin_popcount(long_lanes);
        const __mmask16 grows = long_lanes |''')
  assert 'long_branches +=' in t
  t=t.replace('    return changed != 0;', '    *long_count = long_branches;\n    return changed != 0;')
  s=s[:a]+t+s[b:]
  if not bench:
   a=s.index('static uint64_t branch_sizing_write(');b=s.index('\n}',a)+2;t=s[a:b];x=t.index('    uint64_t result');y=t.index('    for (uint64_t k = 0; k < branch_count; k += 1)')
   t=t[:x]+t[y:];t=t.replace('static uint64_t','static void').replace('    return result;\n','')
   if label=='stablecount':
    t=t.replace('    for (uint64_t k = 0; k < branch_count; k += 1)','''    const __m512i ones = _mm512_set1_epi32(1);
    for (uint64_t k = 0; k < branch_count; k += 16)''')
    x=t.index('        X86Instruction* record');y=t.index('\n    }',x)
    t=t[:x]+'''        const __mmask16 lanes = branch_sizing_lanes(k, branch_count);
        const __m512i records_k = _mm512_maskz_loadu_epi32(lanes, branches + k);
        const __m512i address = _mm512_slli_epi32(records_k, 1);
        const __m512i disps = _mm512_load_si512(displacements + k);
        _mm512_mask_i32scatter_epi32(&records[0].displacement, lanes, address, disps, 8);
        const __m512i growth = _mm512_load_si512(columns->growth + k);
        const __mmask16 long_lanes = _mm512_test_epi32_mask(growth,growth);
        if (long_lanes != 0)
        {
            // Form is the low half of its dword; promoting it by one preserves the adjacent fields.
            const __m512i forms = _mm512_mask_i32gather_epi32(_mm512_setzero_si512(), long_lanes, address, &records[0].form, 8);
            _mm512_mask_i32scatter_epi32(&records[0].form, long_lanes, address, _mm512_add_epi32(forms, ones), 8);
        }'''+t[y:]
   s=s[:a]+t+s[b:]
  s=s.replace('result.long_branches = branch_sizing_write(', 'branch_sizing_write(')
  s=s.replace('branch_sizing_round_vector(branches, targets, branch_count, &columns, current, spans);','branch_sizing_round_vector(branches, targets, branch_count, &columns, current, spans, &result.long_branches);')
  s=s.replace('branch_sizing_benchmark_round_window(branch_count, &columns, current);','branch_sizing_benchmark_round_window(branch_count, &columns, current, &result.long_branches);')
  d=p/label/'buster/compiler';d.mkdir(parents=True,exist_ok=True);(d/f).write_text(s)
s=(p/'compare-pops').read_text();s=s.replace('popgrowth popwhole unchanged','base roundcount stablecount').replace('tier0-40 optimized-40 tier0-250 optimized-2000 optimized-10000','tier0-40 optimized-40 tier0-250 optimized-250 tier0-2000 optimized-2000 tier0-10000 optimized-10000 tier0-mix chain-forward chain-backward');s=s.replace('>"$name-$row', '>"count-$name-$row').replace('touch pops.ok','touch count-rounds.ok')
(p/'compare-counts').write_text(s)
