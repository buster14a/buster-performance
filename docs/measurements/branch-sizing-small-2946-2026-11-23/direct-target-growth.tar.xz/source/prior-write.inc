static uint64_t prior_write(X86Instruction* records, const uint32_t* branches, uint64_t branch_count, const BranchSizingColumns* columns,
                                    const int32_t* displacements)
{
    uint64_t result = 0;
    for (uint64_t k = 0; k < branch_count; k += 1)
    {
        X86Instruction* record = &records[branches[k]];
        const bool grown = columns->growth[k] != 0;
        record->displacement = displacements[k];
        record->form = (uint16_t)(record->form + grown);
        result += grown;
    }
    return result;
}
