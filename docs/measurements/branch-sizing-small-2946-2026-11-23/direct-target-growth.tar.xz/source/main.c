int run_branch_sizing_benchmark(int, char**);
int main(int argc, char** argv)
{
    return run_branch_sizing_benchmark(argc, argv);
}
