#include "buster/compiler/branch_sizing_benchmark.c"
#include "prior-write.inc"

typedef struct {
    BranchSizingColumns columns;
    int32_t* displacement;
    bool all_short;
} Saved;
typedef uint64_t Writer(X86Instruction*, const uint32_t*, uint64_t, const Saved*);
static uint64_t before(X86Instruction* records,const uint32_t* branches,uint64_t n,const Saved* state)
{
    return prior_write(records,branches,n,&state->columns,state->displacement);
}
static uint64_t after(X86Instruction* records,const uint32_t* branches,uint64_t n,const Saved* state)
{
    // Setup already has the record indices, displacements and growth decision in registers in the compiler.
    // This separate replay also pays to load them, with exactly the same prepared input as the previous writer.
    if (!n) return 0;
    if (n <= BUSTER_BRANCH_SIZING_LANES && state->all_short) {
        const __mmask16 lanes=branch_sizing_lanes(0,n);
        const __m512i record=_mm512_maskz_loadu_epi32(lanes,branches);
        const __m512i disp=_mm512_load_si512(state->displacement);
        _mm512_mask_i32scatter_epi32(&records[0].displacement,lanes,_mm512_slli_epi32(record,1),disp,8);
        return 0;
    }
    return branch_sizing_write(records,branches,n,&state->columns,state->displacement);
}
static Writer* volatile writers[]={before,after};
int main(int argc,char**argv)
{
    if (argc != 2 || !x86_encoder_initialize()) return 1;
    const uint64_t seed = strtoull(argv[1], NULL, 0);
    Arena arena = arena_reserve(BUSTER_BRANCH_SIZING_BENCHMARK_ARENA_BYTES);
    BranchSizingBenchmarkCounters counters = branch_sizing_benchmark_open_counters();
    for (unsigned n = 0; n < BUSTER_ARRAY_LENGTH(branch_sizing_benchmark_rows); n += 1)
    {
        const uint64_t mark = arena.length;
        BranchSizingBenchmarkPool pool = branch_sizing_benchmark_pool(&arena, &branch_sizing_benchmark_rows[n], seed + n);
        BranchSizingBenchmarkStatistics stats;
        if (!pool.valid || !branch_sizing_benchmark_check(&arena, &pool, 4, &stats)) return 2;
        Saved* saved = BUSTER_ARENA_PUSH_ARRAY(&arena,Saved,pool.functions);
        if (!saved) return 3;
        for (uint64_t f = 0; f < pool.functions; f += 1)
        {
            const uint64_t start = pool.branch_starts[f];
            const uint64_t count = pool.branch_starts[f+1] - start;
            const uint64_t bytes = ((count+15)/16 + 1)*64;
            saved[f].columns = (BranchSizingColumns){.growth = arena_push(&arena,bytes,64)};
            saved[f].displacement = arena_push(&arena,bytes,64);
            if (!saved[f].displacement || !saved[f].columns.growth) return 3;
            memset(saved[f].columns.growth,0,bytes);
            memset(saved[f].displacement,0,bytes);
            saved[f].all_short=true;
            for (uint64_t j=0;j<count;j+=1)
            {
                if (pool.sized_forms[start+j] != pool.forms[start+j])
                    saved[f].columns.growth[j] = pool.forms[start+j] == X86_FORM_JMP_REL8 ? 3 : 4;
                if(saved[f].columns.growth[j]) saved[f].all_short=false;
                saved[f].displacement[j] = pool.sized_displacements[start+j];
            }
        }
        for (unsigned round=0;round<9;round+=1)
        {
            for (unsigned side=0;side<2;side+=1)
            {
                unsigned kind = (round+side)%2;
                uint64_t cyc=0, ins=0, total=0;
                Writer* write = writers[kind];
                for (uint64_t g=0;g<pool.groups;g+=1)
                {
                    volatile uint32_t touch=branch_sizing_benchmark_prepare(&pool,g,false);
                    (void)touch;
                    uint64_t first=pool.group_starts[g],end=pool.group_starts[g+1];
                    // Both routines see the same stored growth and displacement arrays and the same record bytes.
                    _mm_lfence();
                    uint64_t i0=branch_sizing_benchmark_read_counter(&counters,1),c0=branch_sizing_benchmark_read_counter(&counters,0);
                    _mm_lfence();
                    for (uint64_t f=first;f<end;f+=1) {
                        uint64_t j=pool.branch_starts[f], count=pool.branch_starts[f+1]-j;
                        total+=write(pool.records+pool.record_starts[f],pool.branches+j,count,saved+f);
                    }
                    _mm_lfence();
                    uint64_t c1=branch_sizing_benchmark_read_counter(&counters,0),i1=branch_sizing_benchmark_read_counter(&counters,1);
                    cyc+=c1-c0;ins+=i1-i0;
                    for (uint64_t f=first;f<end;f+=1)
                        for (uint64_t j=pool.branch_starts[f];j<pool.branch_starts[f+1];j+=1) {
                            const X86Instruction* out=pool.records+pool.record_starts[f]+pool.branches[j];
                            if (out->form!=pool.sized_forms[j] || out->displacement!=pool.sized_displacements[j]) return 4;
                        }
                }
                if (total!=stats.long_branches || !cyc || !ins) return 5;
                printf("%s %u %u %lu %lu %lu %lu\n",branch_sizing_benchmark_rows[n].name,round,kind,pool.branches_total,cyc,ins,total);
            }
        }
        arena_pop_to(&arena,mark);
    }
    branch_sizing_benchmark_close_counters(&counters);
    arena_release(&arena);
    return 0;
}
