from pathlib import Path
from statistics import median
from collections import defaultdict
import re, tarfile
from score import rows, rowres, phase

p=Path(__file__).parent
r=p/'full-results'
out=Path('/workspace/buster-performance/docs/measurements/branch-sizing-small-2946-2026-11-23')
old=out.parent/'scalar-paths-removal-2924-2026-11-17/c-branch-sizing-gate/logs'
seeds=(1,133,789)
def pairs(prefix,head,row):
    values=[]
    for seed in seeds:
        pair=[]
        for side in ['base',head]:
            s=(r/f'{prefix}-{side}-{seed}-{row}.log').read_text()
            assert re.search(r'^  window .*ns per branch\); whole',s,re.M)
            pair.append(rowres(s))
        values.append(pair)
    return values
def pct(v):
    return f'{100*(median(v)-1):+.3f}%'
def write_ratios(prefix,variant,row):
    by_round=defaultdict(dict)
    for seed in seeds:
        for line in (r/f'{prefix}-{variant}-{seed}.tsv').read_text().splitlines():
            name,rep,side,n,cy,ins,count=line.split()
            if name==row:
                assert int(n)>0 and int(ins)>0 and int(count)>0 and int(cy)>0
                by_round[seed,rep][int(side)]=int(cy)
    assert len(by_round)==27 and all(len(v)==2 for v in by_round.values())
    return pct(x[1]/x[0] for x in by_round.values())
main=[];write=[];alternate=[];corpus=[]
for row in rows:
    current=pairs('integratedfull','popwhole',row)
    prior=[]
    for index in (1,2,3):
        s=(old/f'bench-{index}.log').read_text().split('\n'+row+':',1)[1]
        prior.append(phase(s,'scalar'))
    ranks=median(h[4] for b,h in current)
    assert ranks<=median(v[2]for v in prior)
    main.append(f'| {row} | {median(v[2]for v in prior):.2f} | {ranks:.2f} | {median(v[5]for v in prior):.2f} | {median(h[7]for b,h in current):.2f} | '+ ' | '.join(pct(h[i]/b[i] for b,h in current)for i in (0,1))+' |')
    write.append('| '+row+' | '+' | '.join(write_ratios(prefix,group,row) for prefix,group in [('isolate','base'),('isolate','clean'),('isolate','popwhole'),('materialize','clean'),('materialize','popwhole')])+' |')
    alternate.append('| '+row+' | '+' | '.join(pct(h[i]/b[i]for b,h in pairs(pre,variant,row))for pre,variant in [('cleanfull','clean'),('popfull','popwhole')]for i in (0,1))+' |')
for group,n in [('lua',34),('sqlite',1),('musl',1336)]:
    cols=[]
    for tag in ['production','pop']:
        for mode in ['tier0','tier1']:
            base,head=[(r/f'{tag}-objects-{mode}-{group}-{v}.sha').read_bytes()for v in ['base','ranked']]
            assert base==head and len(base.splitlines())==n+2
            s=(r/f'{tag}-compile-{mode}-{group}.log').read_text();assert s.rstrip().endswith('ab: done, 0 failed runs')
            times=[]
            for block in s.split('time-runs: done, 0 failed processes')[:-1]:
                ticks={k:int(c)for k,c in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',block,re.M)}
                assert len(ticks)==2;times.append(ticks['head']/ticks['base'])
            assert len(times)==5;cols.append(pct(times))
    corpus.append('| '+group+' | '+str(n)+' | '+' | '.join(cols)+' |')
for kind in ['compiler','pop-compiler']:
    for seed in seeds:
        s=(r/f'{kind}-cross-{seed}.log').read_text();assert '404 compared, 404 the same' in s and '17667 checks, 0 failed' in s and '4609 checks, 0 failed' in s and not re.search(r'\b[1-9][0-9]* failed',s)
body='''## Direct target growth and isolated record writes

The complete compiler uses 16-lane target comparisons for functions with fewer than 512 records and at most 16 branches. It computes each target’s growth directly from the long branches. Only entry to the worklist requires numerical ranks. All-short functions with one packet scatter their final displacements during setup. The other functions count their long branches by packet and publish the final records in branch order.

The table gives the production benchmark’s median phase differences in cycles per branch. Each whole-path change divides candidate cycles by parent cycles for the same seed and takes the median of the three paired ratios. The archived scalar columns are the original three-process measurements. The executable baseline is cc7d4ffb4. Negative near-zero phase differences occur because two separate benchmark runs estimate each phase.

| Row | Scalar ranks | New ranks | Scalar write | New write | Sizing | Sizing and encoding |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(main)+'''

The first replay runs both writers on identical prepared columns for every function. Its same-binary control uses the parent writer for both labels. The second replay also models the one-packet scatter for all-short functions, loading the already prepared record indices and displacements from memory. In the compiler these values are already in registers. Each replay resets the records, alternates order nine times per seed, validates every final form and displacement, checks the total long branches and records user cycles and instructions. The “packet” writer extracts form changes from a packet mask. The submitted “separate count” writer counts masks before storing.

| Row | Identical writer control | Both writers called, packet | Both writers called, separate count | With all-short scatter, packet | With all-short scatter, separate count |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(write)+'''

The standalone builds use the production benchmark source with the same two candidate implementations. They measure how much whole-path results vary between the standalone and completely linked executables.

| Row | Packet sizing | Packet sizing and encoding | Separate count sizing | Separate count sizing and encoding |
| --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(alternate)+'''

Five paired rounds measured three fresh full debug compilations per executable in every round. Each candidate produced the same 1,371 debug objects, stdout and diagnostics at each tier. Each passed three seeded branch suites, including the GNU assembler byte comparison on 404 functions per seed, forced worklists, guarded inputs and scratch exhaustion.

| Corpus | Objects | Packet Tier 0 | Packet Tier 1 | Separate count Tier 0 | Separate count Tier 1 |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(corpus)+'''

All eleven rank phases cleared the archived scalar values. On both 40-record rows the isolated final write and the complete sizing-and-encoding path improved. The 2,000-record rows used more cycles for sizing and encoding in the shipping compiler, and all three whole Tier 1 compiles used more cycles. The direct-span change remains under qualification.

[Compiler patch, benchmark sources, GNU checks, object hashes and raw native samples](direct-target-growth.tar.xz)
'''
with tarfile.open(out/'direct-target-growth.tar.xz','w:xz') as archive:
    for d in ['base','clean','popwhole']:
        archive.add(p/d,arcname='source/'+d)
    for name in ['candidate-pop.patch','change.patch','pop-change.patch','prior-write.inc','materialize.c','isolated.c','main.c','full-pop','integrated-full','materialize','isolate-pop','branch-objects','pop-objects','score.py','record-native.py','integrated-full-recover','full-pop-recover','recover-objects','check-direct','correct.c']:
        archive.add(p/name,arcname='source/'+name)
    for pat in ['integratedfull-*.log','cleanfull-*.log','popfull-*.log','isolate-*.tsv','materialize-*.tsv','*compiler-cross-*.log','production-*.sha','production-compile-*.log','pop-objects-*.sha','pop-compile-*.log']:
        for file in sorted(r.glob(pat)):
            if 'job.log' not in file.name:archive.add(file,arcname='native/'+file.name)
f=out/'README.md';s=f.read_text();assert '## Direct target growth' not in s;f.write_text(s.rstrip()+'\n\n'+body)
print(*main,*corpus,sep='\n')
