from pathlib import Path
from statistics import median
import tarfile,re
from score import rows,rowres
p=Path(__file__).parent;r=p/'full-results';out=Path('/workspace/buster-performance/docs/measurements/branch-sizing-small-2946-2026-11-23')
def pct(a):return f'{100*(median(a)-1):+.3f}%'
def scores(prefix,head,row,stand=False):
 rr=[]
 for seed in (1,133,789):
  vals=[]
  for name in ('base',head):
   file=r/(f'{prefix}-{name}-{row}-{seed}.log' if stand else f'{prefix}-{name}-{seed}-{row}.log')
   s=file.read_text();assert re.search(r'^  window .*ns per branch\); whole',s,re.M);vals.append(rowres(s))
  rr.append([vals[1][j]/vals[0][j]for j in (0,1)])
 return [median(x[i]for x in rr)for i in (0,1)]
def corpus(tag):
 code=(p/'record-round.py').read_text()
 scope={'r':r,'pct':pct,'re':re}
 exec(code[code.index('corpus=[]'):code.index("body='''")].replace('round-objects',tag+'-objects').replace('round-compile',tag+'-compile'),scope)
 return scope['corpus']
def table(pairs,stand=False):
 lines=[];counts={head:[0,0]for prefix,head in pairs}
 for row in rows:
  vals=[]
  for prefix,head in pairs:
   rr=scores(prefix,head,row,stand);vals.extend(pct([x])for x in rr)
   for i in (0,1):counts[head][i]+=rr[i]<=1
  lines.append('| '+row+' | '+' | '.join(vals)+' |')
 return lines,counts
def save(title,body,archive,files,masks):
 doc=out/'README.md';s=doc.read_text();assert title not in s;doc.write_text(s.rstrip()+'\n\n## '+title+'\n\n'+body+'\n\n[Source, native checks and every raw timing]('+archive+'.tar.xz)\n')
 with tarfile.open(out/(archive+'.tar.xz'),'w:xz',preset=2)as t:
  for n in files+['record-compiler-boundaries.py','score.py','record-round.py']:t.add(p/n,'source/'+n)
  for mask in masks:
   for n in sorted(r.glob(mask)):
    if n.suffix in ['.log','.sha']:t.add(n,'native/'+n.name)
if __name__=='__main__':
 import sys
 if 'stand' in sys.argv:
  names=['coldwork','outlinework','smallfront','slimround'];lines,counts=table([('outlined',n)for n in names],True)
  for n in names:
   for seed in (1,133,789):assert '404 compared, 404 the same' in (r/f'outlined-check-{n}-{seed}.log').read_text()
  body='Four function-boundary arrangements were checked at three seeds against GNU as. All 404 functions at each seed matched for every variant. Each pair of columns below shows the change in sizing alone and in sizing immediately followed by encoding.\n\n| Workload | Cold work size | With encode | Helper size | With encode | Small front size | With encode | Slim round size | With encode |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n'+'\n'.join(lines)
  save('Function boundaries in the isolated sizing harness',body,'sizing-outlined',names+['outlines.py','compare-outlining','correct.c'],['outlined-*'])
 else:
  lines,counts=table([('pairedfull','pairedranks'),('coldfull','coldwork')])
  for n in ['paired','coldwork']:
   for seed in (1,133,789):assert '404 compared, 404 the same' in (r/f'{n}-compiler-cross-{seed}.log').read_text()
  aa,bb=corpus('paired'),corpus('coldwork')
  body='The first complete compiler uses paired branch ranks. The second keeps those ranks and moves the uncommon expansion work out of the ordinary path. The benchmark runs the same seed on the same input for each executable, in alternating order, under the 9700X lock. Each change below is the median of three paired ratios.\n\n| Workload | Paired ranks, size | With encoding | Outlined work, size | With encoding |\n| --- | ---: | ---: | ---: | ---: |\n'+'\n'.join(lines)+'\n\nThe whole builds used five rounds of three processes. Both compilers produced the same debug objects, standard output and diagnostics on all six workloads.\n\n| Corpus | Paired Tier 0 | Paired Tier 1 | Outlined Tier 0 | Outlined Tier 1 |\n| --- | ---: | ---: | ---: | ---: |\n'+'\n'.join(a.rstrip()+' '+b.split('|',2)[2].strip()for a,b in zip(aa,bb))+f'\n\nSizing followed by encoding matched or improved in {counts["pairedranks"][1]} of eleven cells with paired ranks and {counts["coldwork"][1]} of eleven after outlining. Both complete binaries matched all 404 GNU as functions at each of three seeds and passed the protected-page column tests.'
  save('Paired ranks and cold expansion in complete compilers',body,'sizing-compiler-boundaries',['coldwork','pairedranks','coldwork.patch','pairedranks.patch','build-paired','build-coldwork','build-coldwork-retry','bench-paired','bench-coldwork','coldwork-objects','paired-objects','outlines.py'],['pairedfull-*','coldfull-*','paired-objects-*','paired-compile-*','coldwork-objects-*','coldwork-compile-*','paired-compiler-cross-*','coldwork-compiler-cross-*'])
 print(counts);print(*lines,sep='\n')
