#define _GNU_SOURCE
#include "buster/compiler/lane.c"
#include "buster/compiler/x86_64_encoder.c"
#include "buster/compiler/x86_64_encoder_test.c"
#include "buster/compiler/branch_sizing.c"
#include "buster/compiler/branch_sizing_generate.c"
#include "buster/compiler/branch_sizing_test.c"
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];
int main(int argc,char**argv) {return run_branch_sizing_tests(argc-1,argv+1);}
