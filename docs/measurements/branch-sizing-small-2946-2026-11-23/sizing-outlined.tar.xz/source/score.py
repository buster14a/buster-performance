from pathlib import Path
from statistics import median
import re
p=Path(__file__).parent;r=p/'full-results'
rows=['tier0-40','optimized-40','tier0-250','optimized-250','tier0-2000','optimized-2000','tier0-10000','optimized-10000','tier0-mix','chain-forward','chain-backward']
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/c-branch-sizing-gate/logs')
def phase(s,path):
 m=re.search(r'^  '+path+r' +lengths ([-\d.]+) setup ([-\d.]+) ranks ([-\d.]+) rounds ([-\d.]+) offsets ([-\d.]+) write ([-\d.]+) \(cycles per branch\)',s,re.M)
 return list(map(float,m.groups()))
def rowres(s):
 return [float(re.search(r'^  '+key+r' +(\S+) cycles per branch',s,re.M)[1]) for key in ('size_branches','size_encode')]+phase(s,'vector')
def scores():
 result=[]
 for row in rows:
  s=[]
  for i in range(1,4):
   t=(d/f'bench-{i}.log').read_text();t=t[t.index('\n'+row+':'):];s.append(phase(t,'scalar'))
  base=[];cand=[]
  for seed in (1,133,789):
   for v,to in [('base',base),('direct',cand)]:
    f=r/f'full-{v}-{seed}-{row}.log';to.append(rowres(f.read_text()))
  times=[100*(median(h[i]/b[i]for b,h in zip(base,cand))-1)for i in (0,1)];ph=[median(h[i]for h in cand) for i in (4,7)]
  result.append((row,*ph,*[median(h[i]for h in s)for i in (2,5)],*times))
 return result
if __name__=='__main__':
 for v in scores():print(v[0],*[round(x,3)for x in v[1:]])
