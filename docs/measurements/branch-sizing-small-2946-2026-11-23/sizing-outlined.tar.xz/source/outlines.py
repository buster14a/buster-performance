from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
p=Path(__file__).parent;f='buster/compiler/branch_sizing.c';g='buster/compiler/branch_sizing_benchmark.c'
for n in ['coldwork','outlinework','smallfront','slimround']:
 s=(p/'pairedranks'/f).read_text();b=(p/'pairedranks'/g).read_text()
 if n in ['coldwork','outlinework']:
  a=s.index('                    // After setup alone');z=s.index('                    listed = true;',a)
  body=s[a:z];q=body.index('                    result.evaluations =');body=body[:q]+body[q:].replace('result.evaluations =','const uint64_t evaluations =').replace('                    current ^= 1;','                    return evaluations;')
  body=body.replace('&columns','columns').replace('columns.','columns->').replace('result.rounds','rounds')
  body='\n'.join(x[16:] if x.startswith(' '*16)else x for x in body.splitlines())+'\n'
  defn='''// Transfer the unsettled branches to the bounded worklist after the synchronous round limit.
static __attribute__((ATTR)) uint64_t branch_sizing_finish_worklist(uint64_t branch_count, const uint32_t* branches, const uint32_t* targets,
                                                                   BranchSizingColumns* columns, uint32_t current, uint32_t rounds, bool spans)
{
'''.replace('ATTR','cold, noinline'if n=='coldwork'else'noinline')+body+'}\n\n'
  s=s[:a]+'''                    result.evaluations = branch_sizing_finish_worklist(branch_count, branches, targets, &columns, current, result.rounds, spans);
                    current ^= 1;
'''+s[z:]
  a=s.index('static BranchSizing branch_sizing_run(');s=s[:a]+defn+s[a:]
 if n=='smallfront':
  for name in ['branch_sizing_ranks_table','branch_sizing_offsets_vector']:s=s.replace('static void '+name+'(','static __attribute__((noinline)) void '+name+'(')
 if n=='slimround':
  s=s.replace('static bool branch_sizing_round_vector(','static __attribute__((noinline)) bool branch_sizing_round_vector(')
 d=p/n/f;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(s);(p/n/g).write_text(b)
 diff=[]
 for path,t in [(f,s),(g,b)]:
  file='src/'+path;o=check_output(['git','show','cc7d4ffb4:'+file],cwd=p/'tree').decode();diff.extend(unified_diff(o.splitlines(True),t.splitlines(True),'a/'+file,'b/'+file))
 (p/(n+'.patch')).write_text(''.join(diff))
s=(p/'compare-offsets').read_text()
for a,b in [('pairedranks','coldwork'),('ranklanes','outlinework'),('markscan','smallfront'),('byteadd','slimround'),('offset-','outlined-')]:s=s.replace(a,b)
(p/'compare-outlining').write_text(s)
for a,b in [('build-paired','build-coldwork'),('paired-objects','coldwork-objects'),('bench-paired','bench-coldwork')]:
 s=(p/a).read_text().replace('branch-paired','branch-coldwork').replace('paired-','coldwork-').replace('pairedfull','coldfull').replace('pairedranks','coldwork')
 if a=='build-paired':
  z=s.index('previous=');q=s.index('git diff --exit-code',z)
  s=s[:z]+'''previous=/dev/shm/buster-lexer-dollars-6b097f86
until [[ -f "$previous/common-built.ok" ]];do sleep 2;done
cd "$ir/src"
git apply -R "$previous/common.patch"
'''+s[q:]
 (p/b).write_text(s)
