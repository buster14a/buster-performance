from pathlib import Path
from score import rows,rowres
from statistics import median
import re,tarfile
p=Path(__file__).parent;r=p/'full-results';out=Path('/workspace/buster-performance/docs/measurements/branch-sizing-small-2946-2026-11-23')
def pct(a):return f'{100*(median(a)-1):+.3f}%'
table=[]
for row in rows:
 cols=[]
 for prefix,vs in [('roundfull','roundcount'),('count','roundcount'),('count','stablecount')]:
  ratios=[]
  for seed in (1,133,789):
   xs=[]
   for side in ('base',vs):
    f=r/(f'{prefix}-{side}-{seed}-{row}.log' if prefix=='roundfull' else f'{prefix}-{side}-{row}-{seed}.log')
    s=f.read_text();assert re.search(r'^  window .*ns per branch\); whole',s,re.M);xs.append(rowres(s))
   ratios.append([xs[1][i]/xs[0][i]for i in(0,1)])
  cols.extend(pct(x[i]for x in ratios)for i in(0,1))
 table.append('| '+row+' | '+' | '.join(cols)+' |')
corpus=[]
for group,n in [('lua',34),('sqlite',1),('musl',1336)]:
 cols=[]
 for mode in ('tier0','tier1'):
  fs=[(r/f'round-objects-{mode}-{group}-{side}.sha').read_bytes()for side in ('base','ranked')];assert fs[0]==fs[1] and len(fs[0].splitlines())==n+2
  s=(r/f'round-compile-{mode}-{group}.log').read_text();assert s.rstrip().endswith('ab: done, 0 failed runs')
  rr=[]
  for t in s.split('time-runs: done, 0 failed processes')[:-1]:
   cs={k:int(v)for k,v in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',t,re.M)};rr.append(cs['head']/cs['base'])
  assert len(rr)==5;cols.append(pct(rr))
 corpus.append('| '+group+' | '+' | '.join(cols)+' |')
for seed in (1,133,789):
 s=(r/f'round-compiler-cross-{seed}.log').read_text();assert '404 compared, 404 the same' in s and '17667 checks, 0 failed' in s and '4609 checks, 0 failed' in s
body='''## Counting long branches in the relaxation round

The stable round already has the mask of promoted branches for every packet. Counting the mask there removes a pass over growths before the final record stores. The complete compiler and two standalone builds measured the same eleven workloads against their respective parent. All percentages are medians of three paired seed ratios. The second standalone implementation also scatters final displacements and promotes the long record forms by masked gather and scatter.

| Row | Compiler sizing | Compiler sizing and encoding | Standalone sizing | Standalone sizing and encoding | Standalone scatter sizing | Standalone scatter sizing and encoding |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(table)+'''

The complete compiler improved sizing on every row. Sizing plus encoding still took more cycles on both 2,000-record rows. The six production comparisons below used five paired rounds of three processes and verified every debug object, stdout and stderr. The three GNU assembler comparisons matched on all 404 functions per seed.

| Corpus | Tier 0 | Tier 1 |
| --- | ---: | ---: |
'''+ '\n'.join(corpus)+'''

[Round-count changes, benchmark commands, GNU comparisons, object hashes and raw timing logs](round-count.tar.xz)
'''
with tarfile.open(out/'round-count.tar.xz','w:xz') as t:
 for f in ('roundcount','stablecount','roundcount.patch','round-count.py','compare-counts','integrate-round','integrated-round','round-objects','score.py','record-round.py'):t.add(p/f,arcname='source/'+f)
 for pat in ('roundfull-*.log','count-*.log','round-compile-*.log','round-objects-*.sha','round-compiler-cross-*.log'):
  for f in r.glob(pat):
   if 'job' not in f.name:t.add(f,arcname='native/'+f.name)
path=out/'README.md';s=path.read_text().split('\n## Counting long branches in the relaxation round')[0];path.write_text(s.rstrip()+'\n\n'+body)
print(*table,*corpus,sep='\n')
