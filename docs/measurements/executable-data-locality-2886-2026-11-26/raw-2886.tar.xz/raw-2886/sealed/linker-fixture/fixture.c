/* Linker selector fixture: compile once for each object name in commands.txt. */
#define JOIN_(a, b) a##b
#define JOIN(a, b) JOIN_(a, b)
#define SYMBOL(suffix) JOIN(FIXTURE_OWNER, suffix)
extern const unsigned long fixture_target;

__attribute__((section(".data.rel.ro"), used, aligned(16)))
const unsigned long *const SYMBOL(_base) = &fixture_target;
__attribute__((section(".data.rel.ro.fixture"), used, aligned(8)))
const unsigned long *const SYMBOL(_suffix) = &fixture_target;

#ifdef FIXTURE_DRIVER
const unsigned long fixture_target = 0x123;
__attribute__((section(".text.fixture_start"), used))
void fixture_start(void) {}
__attribute__((section("buster_baked"), used))
unsigned long baked_sentinel = 0x789;
unsigned long bss_sentinel;
#endif
