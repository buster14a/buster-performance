/* Verify the small C fixture's ELF placement and payload without executing it. */
#include <elf.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned char *file;
static size_t file_size;
static Elf64_Ehdr *header;
static Elf64_Shdr *sections;
static const char *section_names;

static void check(int okay, const char *what) {
    if (!okay) {
        fprintf(stderr, "FAIL: %s\n", what);
        exit(1);
    }
}

static void *contents(const Elf64_Shdr *section) {
    check(section->sh_offset <= file_size &&
              section->sh_size <= file_size - section->sh_offset,
          "section file bounds");
    return file + section->sh_offset;
}

static unsigned section_index(const char *name) {
    for (unsigned i = 0; i < header->e_shnum; ++i)
        if (strcmp(section_names + sections[i].sh_name, name) == 0) return i;
    check(0, name);
    return 0;
}

static Elf64_Sym symbol(const char *name) {
    for (unsigned i = 0; i < header->e_shnum; ++i) {
        if (sections[i].sh_type != SHT_SYMTAB) continue;
        check(sections[i].sh_link < header->e_shnum, "symbol string table index");
        const char *names = contents(&sections[sections[i].sh_link]);
        const Elf64_Sym *symbols = contents(&sections[i]);
        size_t count = sections[i].sh_size / sizeof(*symbols);
        for (size_t j = 0; j < count; ++j)
            if (strcmp(names + symbols[j].st_name, name) == 0) return symbols[j];
    }
    check(0, name);
    return (Elf64_Sym){0};
}

int main(int argc, char **argv) {
    check(argc == 2, "usage: check FIXTURE_ELF");
    FILE *input = fopen(argv[1], "rb");
    check(input != NULL, "open fixture");
    check(fseek(input, 0, SEEK_END) == 0, "seek fixture");
    long length = ftell(input);
    check(length >= (long)sizeof(Elf64_Ehdr), "ELF header size");
    file_size = (size_t)length;
    file = malloc(file_size);
    check(file != NULL, "allocate fixture");
    rewind(input);
    check(fread(file, 1, file_size, input) == file_size, "read fixture");
    fclose(input);
    header = (Elf64_Ehdr *)file;
    check(memcmp(header->e_ident, ELFMAG, SELFMAG) == 0 &&
              header->e_ident[EI_CLASS] == ELFCLASS64 &&
              header->e_ident[EI_DATA] == ELFDATA2LSB,
          "little-endian ELF64 fixture");
    check(header->e_shentsize == sizeof(Elf64_Shdr) &&
              header->e_shoff <= file_size &&
              header->e_shnum <= (file_size - header->e_shoff) / sizeof(Elf64_Shdr),
          "section table bounds");
    sections = (Elf64_Shdr *)(file + header->e_shoff);
    check(header->e_shstrndx < header->e_shnum, "section name table index");
    section_names = contents(&sections[header->e_shstrndx]);
    unsigned sealed = section_index(".data.rel.ro.buster");
    unsigned external = section_index(".data.rel.ro");
    unsigned baked = section_index("buster_baked");
    const char *order[] = {"direct_normal", "direct_native", "frontend_normal",
                          "frontend_native", "checker_normal", "checker_native",
                          "cold_normal", "driver", "cold_native"};
    const Elf64_Shdr *data = &sections[sealed];
    unsigned char *expected = calloc(1, data->sh_size);
    check(expected != NULL, "allocate expected data");
    uint64_t target = symbol("fixture_target").st_value;
    uint64_t last = 0;
    for (unsigned i = 0; i < sizeof(order) / sizeof(order[0]); ++i) {
        char name[80];
        snprintf(name, sizeof(name), "%s_base", order[i]);
        Elf64_Sym base = symbol(name);
        snprintf(name, sizeof(name), "%s_suffix", order[i]);
        Elf64_Sym suffix = symbol(name);
        check(base.st_shndx == sealed && suffix.st_shndx == sealed,
              "compiler base and suffixed sections are sealed");
        check(base.st_size == 8 && suffix.st_size == 8 &&
                  suffix.st_value == base.st_value + 8,
              "both input payloads are preserved");
        check(base.st_value >= last, "selected and fallback object order");
        if (i == 0 || i == 2 || i == 4)
            check(base.st_value % 65536 == 0, "selected group is 64 KB aligned");
        check(base.st_value >= data->sh_addr &&
                  base.st_value - data->sh_addr + 16 <= data->sh_size,
              "compiler payload lies inside sealed section");
        size_t offset = base.st_value - data->sh_addr;
        memcpy(expected + offset, &target, sizeof(target));
        memcpy(expected + offset + 8, &target, sizeof(target));
        last = suffix.st_value + suffix.st_size;
        printf("%s: 0x%llx\n", order[i], (unsigned long long)base.st_value);
    }
    check(memcmp(contents(data), expected, data->sh_size) == 0,
          "sealed payload consists of exactly the selected inputs plus zero padding");
    check(symbol("external_base").st_shndx == external &&
              symbol("external_suffix").st_shndx == external &&
              sections[external].sh_size == 16,
          "external relocated data stays outside the sealed compiler section");
    check(sections[baked].sh_addr % 2097152 == 0 && sections[baked].sh_size == 8 &&
              symbol("baked_sentinel").st_shndx == baked,
          "baked section preserves its payload and 2 MB alignment");
    printf("PASS: 3 aligned groups, 9 compiler objects placed once, 144 payload bytes, "
           "%llu padding bytes, external relro isolated, baked unchanged.\n",
           (unsigned long long)(data->sh_size - 144));
    free(expected);
    free(file);
    return 0;
}
