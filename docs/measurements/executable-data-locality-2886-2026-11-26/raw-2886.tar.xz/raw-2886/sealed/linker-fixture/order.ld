/* The start's code order (cmake/BusterStartOrder.cmake), from order.txt. */
SECTIONS
{
    buster_baked : ALIGN(0x200000)
    {
        *(buster_baked)
    }
    .data.rel.ro.buster :
    {
        . = ALIGN(0x10000);
        */c_direct.c.o(.data.rel.ro .data.rel.ro.*)
        */c_direct/native.o(.data.rel.ro .data.rel.ro.*)
        . = ALIGN(0x10000);
        */main_unit_frontend.c.o(.data.rel.ro .data.rel.ro.*)
        */main_unit_frontend/native.o(.data.rel.ro .data.rel.ro.*)
        . = ALIGN(0x10000);
        */main_unit_checker.c.o(.data.rel.ro .data.rel.ro.*)
        */main_unit_checker/native.o(.data.rel.ro .data.rel.ro.*)
        *.c.o(.data.rel.ro .data.rel.ro.*)
        */native.o(.data.rel.ro .data.rel.ro.*)
    }
    .text.buster_start : ALIGN(0x200000)
    {
        buster_start_probe = .;
        . += 0x20000;
        */main.c.o(.text.fixture_start .text.unlikely.fixture_start .text.hot.fixture_start)
        */main/native.o(.text.fixture_start .text.unlikely.fixture_start .text.hot.fixture_start .text.fixture_start.buster_split .text.unlikely.fixture_start.buster_split .text.hot.fixture_start.buster_split)
    }
    ASSERT(SIZEOF(.text.buster_start) > 0x20000, "the start's code order placed no function: the units' objects or sections aren't the link's")
    .text.buster_checker :
    {
        *(.text.buster_checker)
        buster_start_end = .;
    }
}
INSERT BEFORE .text;
SECTIONS
{
    .bss.buster_start (NOLOAD) : ALIGN(4096)
    {
        buster_start_data_begin = .;
        *(.bss.buster_start)
        buster_start_data_end = .;
    }
    ASSERT(SIZEOF(.bss.buster_start) <= 4096, "the compile's small writable state no longer fits in one page")
}
INSERT AFTER .bss;
