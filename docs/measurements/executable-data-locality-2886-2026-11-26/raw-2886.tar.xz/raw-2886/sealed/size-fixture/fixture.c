/* Approximate complete input spans from main 8e4d3287's ELF, preserving its gaps. */
#define JOIN_(a, b) a##b
#define JOIN(a, b) JOIN_(a, b)
#ifndef FIXTURE_ALIGN
#define FIXTURE_ALIGN 16
#endif
extern const unsigned long fixture_target;
__attribute__((section(".data.rel.ro"), used, aligned(FIXTURE_ALIGN)))
const void *const JOIN(FIXTURE_OWNER, _payload)[FIXTURE_BYTES / sizeof(void *)] = {&fixture_target};
#ifdef FIXTURE_DRIVER
const unsigned long fixture_target = 0x123;
const unsigned char preceding_rodata[0xa2bb23] = {1};
__attribute__((section("buster_baked"), used, aligned(64)))
unsigned char baked_payload[0x664300] = {2};
__attribute__((section(".text.fixture_start"), used))
void fixture_start(void) {}
unsigned long bss_sentinel;
#endif
