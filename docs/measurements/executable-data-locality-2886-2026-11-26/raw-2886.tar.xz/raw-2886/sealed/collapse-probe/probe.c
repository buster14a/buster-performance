#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/utsname.h>
#include <unistd.h>

#define HUGE_BYTES (2u * 1024u * 1024u)
#define PAGE_BYTES 4096u
#define SCAN_REQUEST UINT64_C(0xc0606610)
#define PAGE_PRESENT (UINT64_C(1) << 3)
#define PAGE_HUGE (UINT64_C(1) << 6)
#define COLLAPSE 25
struct region { uint64_t start, end, categories; };
struct scan_arg {
    uint64_t size, flags, start, end, walk_end, vector, vector_length, max_pages;
    uint64_t category_inverted, category_mask, category_anyof_mask, return_mask;
};
_Static_assert(sizeof(struct scan_arg) == 96 && sizeof(struct region) == 24, "scan ABI");

static void fail(const char *what) { perror(what); exit(1); }
static int scan_pages(void *mapping, const char *label) {
    struct region regions[64] = {0};
    struct scan_arg scan = {.size = sizeof(scan), .start = (uintptr_t)mapping,
        .end = (uintptr_t)mapping + HUGE_BYTES, .vector = (uintptr_t)regions,
        .vector_length = 64, .category_mask = PAGE_PRESENT,
        .return_mask = PAGE_PRESENT | PAGE_HUGE};
    int pagemap = open("/proc/self/pagemap", O_RDONLY | O_CLOEXEC);
    if (pagemap < 0) fail("open pagemap");
    errno = 0;
    long found = ioctl(pagemap, SCAN_REQUEST, &scan);
    int error = errno;
    close(pagemap);
    unsigned long base = 0, huge = 0;
    for (long i = 0; i < found; ++i) {
        unsigned long pages = (regions[i].end - regions[i].start) / PAGE_BYTES;
        if (regions[i].categories & PAGE_HUGE) huge += pages;
        else base += pages;
    }
    printf("SCAN %s result=%ld errno=%d(%s) base_pages=%lu huge_pages=%lu complete=%d\n",
           label, found, error, strerror(error), base, huge,
           scan.walk_end == scan.end);
    return found >= 0 && scan.walk_end == scan.end;
}

static void create_copy(const char *source, const char *destination, off_t offset) {
    int input = open(source, O_RDONLY | O_CLOEXEC);
    if (input < 0) fail("open source");
    int output = open(destination, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0700);
    if (output < 0) fail("create fresh destination");
    unsigned char bytes[16384];
    size_t copied = 0;
    while (copied < HUGE_BYTES) {
        ssize_t n = pread(input, bytes, sizeof(bytes), offset + (off_t)copied);
        if (n <= 0) fail("read source range");
        size_t done = 0;
        while (done < (size_t)n) {
            ssize_t written = write(output, bytes + done, (size_t)n - done);
            if (written <= 0) fail("write fresh destination");
            done += (size_t)written;
        }
        copied += (size_t)n;
    }
    if (fsync(output) || fchmod(output, 0500)) fail("seal fresh destination");
    if (close(output) || close(input)) fail("close copied files");
}

int main(int argc, char **argv) {
    if (argc != 5) {
        fprintf(stderr, "usage: probe SOURCE FRESH_DESTINATION SOURCE_OFFSET r|rx\n");
        return 1;
    }
    off_t offset = (off_t)strtoull(argv[3], NULL, 0);
    int protection = PROT_READ | (strcmp(argv[4], "rx") == 0 ? PROT_EXEC : 0);
    struct utsname kernel;
    if (uname(&kernel)) fail("uname");
    printf("KERNEL %s %s\n", kernel.sysname, kernel.release);
    int inherited = prctl(PR_GET_THP_DISABLE, 0, 0, 0, 0);
    if (prctl(PR_SET_THP_DISABLE, 0, 0, 0, 0)) fail("enable process THP");
    printf("PROCESS inherited_thp_disable=%d active_thp_disable=%d\n", inherited,
           prctl(PR_GET_THP_DISABLE, 0, 0, 0, 0));
    create_copy(argv[1], argv[2], offset);
    int descriptor = open(argv[2], O_RDONLY | O_CLOEXEC);
    if (descriptor < 0) fail("open fresh file");
    struct stat status;
    struct statfs filesystem;
    if (fstat(descriptor, &status) || fstatfs(descriptor, &filesystem)) fail("file info");
    printf("FILE inode=%ju bytes=%jd filesystem=0x%jx protection=%s source_offset=0x%jx\n",
           (uintmax_t)status.st_ino, (intmax_t)status.st_size,
           (uintmax_t)filesystem.f_type, argv[4], (uintmax_t)offset);
    void *reserve = mmap(NULL, 2 * HUGE_BYTES, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (reserve == MAP_FAILED) fail("reserve aligned mapping");
    void *address = (void *)(((uintptr_t)reserve + HUGE_BYTES - 1) & ~(uintptr_t)(HUGE_BYTES - 1));
    void *mapping = mmap(address, HUGE_BYTES, protection, MAP_PRIVATE | MAP_FIXED, descriptor, 0);
    if (mapping == MAP_FAILED) fail("map fresh file");
    close(descriptor);
    volatile const unsigned char *bytes = mapping;
    volatile unsigned char sum = 0;
    for (size_t i = 0; i < 64; ++i) sum ^= bytes[i * PAGE_BYTES];
    int scan_ok = scan_pages(mapping, "before");
    errno = 0;
    int result = madvise(mapping, HUGE_BYTES, COLLAPSE);
    int error = errno;
    printf("MADV_COLLAPSE result=%d errno=%d(%s)\n", result, error, strerror(error));
    scan_ok &= scan_pages(mapping, "after");
    if (munmap(reserve, 2 * HUGE_BYTES)) fail("unmap first mapping");
    reserve = mmap(NULL, 2 * HUGE_BYTES, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (reserve == MAP_FAILED) fail("reserve second mapping");
    address = (void *)(((uintptr_t)reserve + HUGE_BYTES - 1) & ~(uintptr_t)(HUGE_BYTES - 1));
    descriptor = open(argv[2], O_RDONLY | O_CLOEXEC);
    if (descriptor < 0) fail("reopen fresh file");
    mapping = mmap(address, HUGE_BYTES, protection, MAP_PRIVATE | MAP_FIXED, descriptor, 0);
    if (mapping == MAP_FAILED) fail("remap fresh file");
    close(descriptor);
    sum ^= *(volatile unsigned char *)mapping;
    scan_ok &= scan_pages(mapping, "remap_one_byte");
    printf("CHECKSUM %u\n", (unsigned)sum);
    if (munmap(reserve, 2 * HUGE_BYTES)) fail("unmap second mapping");
    return scan_ok ? 0 : 2;
}
