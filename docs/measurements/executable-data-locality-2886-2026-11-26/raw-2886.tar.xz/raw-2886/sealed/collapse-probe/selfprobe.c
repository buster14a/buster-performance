/* Test an actually executed ELF's read-only data and an anonymous control. */
#define main file_probe_main
#include "probe.c"
#undef main

static const unsigned char self_data[HUGE_BYTES]
    __attribute__((aligned(HUGE_BYTES), used)) = {1};

static int collapse(void *mapping, const char *label) {
    int okay = scan_pages(mapping, label);
    errno = 0;
    int result = madvise(mapping, HUGE_BYTES, COLLAPSE);
    int error = errno;
    printf("MADV_COLLAPSE %s result=%d errno=%d(%s)\n", label, result, error, strerror(error));
    okay &= scan_pages(mapping, "after");
    return okay;
}

int main(void) {
    struct utsname kernel;
    if (uname(&kernel)) fail("uname");
    printf("KERNEL %s %s\n", kernel.sysname, kernel.release);
    int inherited = prctl(PR_GET_THP_DISABLE, 0, 0, 0, 0);
    if (prctl(PR_SET_THP_DISABLE, 0, 0, 0, 0)) fail("enable process THP");
    printf("PROCESS inherited_thp_disable=%d active_thp_disable=%d\n", inherited,
           prctl(PR_GET_THP_DISABLE, 0, 0, 0, 0));
    int descriptor = open("/proc/self/exe", O_RDONLY | O_CLOEXEC);
    if (descriptor < 0 || fsync(descriptor)) fail("sync own ELF");
    close(descriptor);
    printf("SELF read_only_address=0x%jx aligned=%d\n", (uintmax_t)(uintptr_t)self_data,
           (uintptr_t)self_data % HUGE_BYTES == 0);
    volatile unsigned char sum = 0;
    for (size_t i = 0; i < 64; ++i) sum ^= ((volatile const unsigned char *)self_data)[i * PAGE_BYTES];
    int scan_ok = collapse((void *)self_data, "executed_ELF_readonly");
    void *reserve = mmap(NULL, 2 * HUGE_BYTES, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (reserve == MAP_FAILED) fail("reserve anonymous mapping");
    void *address = (void *)(((uintptr_t)reserve + HUGE_BYTES - 1) & ~(uintptr_t)(HUGE_BYTES - 1));
    void *mapping = mmap(address, HUGE_BYTES, PROT_READ | PROT_WRITE,
                         MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (mapping == MAP_FAILED) fail("map anonymous control");
    for (size_t i = 0; i < 64; ++i) ((volatile unsigned char *)mapping)[i * PAGE_BYTES] = (unsigned char)(i + 1);
    scan_ok &= collapse(mapping, "anonymous");
    printf("CHECKSUM %u\n", (unsigned)sum);
    if (munmap(reserve, 2 * HUGE_BYTES)) fail("unmap anonymous control");
    return scan_ok ? 0 : 2;
}
