#!/usr/bin/env bash
set -euo pipefail
workdir="$HOME/buster-fast-bench/1453-codex-20261106-perf"
sqlite="$HOME/buster-fast-bench/1296-codex-20261105/corpus/sqlite"
export EXCLUSIVE_OWNER=codex-1453 EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1453 LC_ALL=C
cd "$workdir/repo"
git fetch "$workdir/candidate9.bundle" HEAD
git worktree add --detach "$workdir/debug9" FETCH_HEAD
export EXCLUSIVE_TITLE='PR 1453 candidate9 debug-info profile build'
"$HOME/buster-fast-bench/exclusive.sh" env BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=1 "$workdir/debug9/build.sh" --jobs 4 > "$workdir/debug9-build.log" 2>&1
sha256sum "$workdir/debug9/build/compiler" > "$workdir/debug9.sha256"
export EXCLUSIVE_TITLE='PR 1453 candidate9 debug-info instruction profile'
"$HOME/buster-fast-bench/exclusive.sh" bash -c '
  set -euo pipefail
  test "${BUSTER_9700X_HELD:-}" = 1
  workdir="$1"; sqlite="$2"
  { printf "held=%s\n" "$BUSTER_9700X_HELD"; cat /var/lib/buster-9700x/owner; sha256sum "$workdir/debug9/build/compiler"; } > "$workdir/debug9-profile.receipt"
  taskset -c 2 perf record -q -e instructions:u -c 50000 -o "$workdir/debug9-profile.data" -- "$workdir/debug9/build/compiler" -fsyntax-only -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$sqlite" "$sqlite/sqlite3.c" > "$workdir/debug9-profile.out" 2> "$workdir/debug9-profile.err"
  { printf "status=0\n"; cat /var/lib/buster-9700x/owner; sha256sum "$workdir/debug9-profile.out" "$workdir/debug9-profile.err"; } >> "$workdir/debug9-profile.receipt"
' -- "$workdir" "$sqlite"
perf report --stdio -i "$workdir/debug9-profile.data" --sort symbol --percent-limit 0.3 > "$workdir/debug9-report.txt"
for symbol in check_driver_common_warnings check_input_run check_program_return_flow; do perf annotate --stdio -i "$workdir/debug9-profile.data" --symbol "$symbol" > "$workdir/debug9-$symbol.txt"; done
