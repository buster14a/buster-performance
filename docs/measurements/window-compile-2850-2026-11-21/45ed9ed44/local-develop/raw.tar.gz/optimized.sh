#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d=$PWD; cd ../all-local-residency
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >"$d/matched-build.log" 2>&1
cp ../buster/build/predefines.h build/predefines.h
bin=$PWD/build/compiler
cd ../switch-inputs;source ../switch-local-args.sh
tree=$PWD/../pregraph-warning-study/compiler-source; main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
mkdir -p "$d/normal"
for g in sqlite main;do v=${g}_arguments;eval "args=(${!v})"
 for r in 1 2 3 4 5;do
  if ((r%2));then order=(dense batch batch dense);else order=(batch dense dense batch);fi
  for i in 0 1 2 3;do mode=${order[i]}; marks=()
   if [[ $mode == batch ]];then marks=(BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_SOURCE_WRITE_COLUMNS=1 BUSTER_SOURCE_RETIRE_LISTS=1 BUSTER_SOURCE_GROW_GRAPH=1 BUSTER_SOURCE_FILE_DATA=1);fi
   stem=$d/normal/$g-1024-$r-$i-$mode
   python3 "$d/../batched-source-study/measure.py" "$stem.time" env "${marks[@]}" "$bin" --lanes 1 -c "${args[@]}" -o "$d/normal/$g-$mode.o" >"$stem.stdout" 2>"$stem.stderr"
  done
 done
 cmp "$d/normal/$g-dense.o" "$d/normal/$g-batch.o"
 for mode in dense batch;do marks=(); if [[ $mode == batch ]];then marks=(BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_SOURCE_WRITE_COLUMNS=1 BUSTER_SOURCE_RETIRE_LISTS=1 BUSTER_SOURCE_GROW_GRAPH=1 BUSTER_SOURCE_FILE_DATA=1);fi
    env "${marks[@]}" "$bin" --lanes 1 --time-stages -c "${args[@]}" -o "$d/normal/$g-$mode.o" > "$d/normal/$g.$mode.stages" 2>&1
    if [[ $g == sqlite ]];then
       perf record -o "$d/normal/$g.$mode.data" -e cycles:u -F 4093 -- env "${marks[@]}" "$bin" --lanes 1 -c "${args[@]}" -o "$d/normal/$g-$mode.o" >"$d/normal/$g.$mode.capture" 2>&1
       perf report --stdio -i "$d/normal/$g.$mode.data" --no-children --sort symbol >"$d/normal/$g.$mode.profile"
    fi
 done
done
python3 "$d/../batched-source-study/native-report.py" "$d/normal"
