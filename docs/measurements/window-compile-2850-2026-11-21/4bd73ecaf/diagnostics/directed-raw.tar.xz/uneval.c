int f(void){return sizeof(1/0);}
