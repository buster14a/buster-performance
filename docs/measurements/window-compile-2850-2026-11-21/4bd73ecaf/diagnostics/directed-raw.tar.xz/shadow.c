int i;int f(int i){int x=i;{int i=x;return i;}}
