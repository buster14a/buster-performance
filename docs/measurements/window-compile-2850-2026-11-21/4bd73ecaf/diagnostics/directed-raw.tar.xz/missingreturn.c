int f(int x){if(x)return 1;}
