int f(int b){int x;if(b)x=3;return x;}
