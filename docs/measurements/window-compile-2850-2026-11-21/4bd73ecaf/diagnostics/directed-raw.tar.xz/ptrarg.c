int x(int*); int f(void){return x(3);}
