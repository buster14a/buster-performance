int old(void) __attribute__((deprecated)); int f(void){return old();}
