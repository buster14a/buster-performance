struct S {int a;}; int f(struct S s){return s+1;}
