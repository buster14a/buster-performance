int printf(const char *,...) __attribute__((format(printf,1,2)));int f(void){return printf("%s",15);}
