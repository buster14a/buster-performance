int f(int a){return a+1;} int g(void){return f(3);}
