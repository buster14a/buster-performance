int f(void){if(0){return 1/0;}return 1;}
