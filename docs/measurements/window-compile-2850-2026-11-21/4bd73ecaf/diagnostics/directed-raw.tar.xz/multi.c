int f(int a, int b){return a+b<<1;} int g(void){return 2147483647+1;}
