int f(void){int v[2]={0};return v[5];}
