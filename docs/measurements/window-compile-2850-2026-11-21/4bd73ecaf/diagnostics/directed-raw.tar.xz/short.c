int f(void){return 0 && (1/0);}
