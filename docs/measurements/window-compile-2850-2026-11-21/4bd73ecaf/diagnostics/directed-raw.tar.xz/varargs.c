#include <stdarg.h>
int f(int x,...){return x;}
