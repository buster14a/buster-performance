int f(int*) __attribute__((nonnull)); int g(void){return f((void*)0);}
