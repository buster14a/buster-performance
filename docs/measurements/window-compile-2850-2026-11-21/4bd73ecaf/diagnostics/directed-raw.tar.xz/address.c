int f(void){int i=0;return &i;}
