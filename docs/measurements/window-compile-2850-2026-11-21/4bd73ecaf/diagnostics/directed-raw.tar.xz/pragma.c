#pragma clang diagnostic ignored "-Wshift-op-parentheses"
int f(int x){return x+1<<2;}
