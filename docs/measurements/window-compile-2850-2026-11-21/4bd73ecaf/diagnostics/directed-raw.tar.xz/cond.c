int f(void){return 1 ? 1 : 1/0;}
