_Static_assert(1==2,"assertion diagnostic"); int f(void){return 0;}
