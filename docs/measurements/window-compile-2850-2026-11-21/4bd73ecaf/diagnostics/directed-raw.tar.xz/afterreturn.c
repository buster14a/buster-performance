int f(void){return 1;return 1/0;}
