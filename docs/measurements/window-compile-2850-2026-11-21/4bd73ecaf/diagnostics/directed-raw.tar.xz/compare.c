int f(void){return 0.5==0.5;}
