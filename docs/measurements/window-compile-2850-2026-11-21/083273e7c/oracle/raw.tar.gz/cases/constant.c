_Static_assert(2*4==8, "eight");int f(int a){return (a + 0) < (3*4);}
