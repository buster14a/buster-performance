constexpr int a=12;int f(int b){int c=3+4;return b+c+(b%a);}
