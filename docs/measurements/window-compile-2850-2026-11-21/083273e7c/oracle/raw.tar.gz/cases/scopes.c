int f(int x){int y=x;{volatile int x=2;y+=x;}return (x+y)^(x-4);}
