enum{A=1<<-1};int f(int n){return n+A;}
