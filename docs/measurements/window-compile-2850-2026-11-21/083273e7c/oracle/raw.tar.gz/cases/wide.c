unsigned __int128 f(unsigned __int128 a,unsigned b){return a+b+(a<3);}
