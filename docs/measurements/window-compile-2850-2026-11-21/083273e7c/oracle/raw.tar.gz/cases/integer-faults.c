int f(int v){return (v & (1/0)) + ((1<<-1) + v) + (v >> 129) + (v/0) + (v%0);}
