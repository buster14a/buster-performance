int f(int a,int b){int c=a+b;return (c<b)+(a^b)+(a*3)+(a>>3)+(b!=0)+(b&5);}
