#pragma STDC FENV_ACCESS ON
int f(int a,float b){return (a*2)+(b!=0)+(int)(b+2);}
