int f(int a){return ((1<<-2)+a) ^ ((1/0) | a);}
