int f(int x,int y){int r;return __builtin_add_overflow(x,y,&r)?-1:r;}
