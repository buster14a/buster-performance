int q;int f(int b){static int v;volatile int x=b;const int c=4;q=b;v=c;return (q=v) + (x=q);}
