unsigned long f(signed char a, unsigned b, int c, long d){return a+b+c+d+(b<c)+(c>=d);}
