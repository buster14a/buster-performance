struct S{int x;};int f(struct S a,int b){return a+b;}
