int f(int a,int b){return (a=3) + (b-=2);}
