struct S{int a; unsigned b; char c; volatile short d; int e:5;};int f(struct S *s,int v){ return (s->a + s->b) ^ (s->c < v) ^ (s->d < v) ^ (s->e+v);}
