struct R{int *p;};int f(int *p, int **q, struct R r){return !p + (!!*q) + (!r.p) + (!!(void*)0) + ((p!=0) && q!=0);}
