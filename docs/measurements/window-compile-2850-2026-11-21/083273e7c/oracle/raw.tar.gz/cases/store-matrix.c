_Bool s0_0(_Bool *p,_Bool b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_1(_Bool *p,char b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_2(_Bool *p,signed char b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_3(_Bool *p,unsigned char b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_4(_Bool *p,short b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_5(_Bool *p,unsigned short b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_6(_Bool *p,int b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_7(_Bool *p,unsigned int b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_8(_Bool *p,long b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_9(_Bool *p,unsigned long b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_10(_Bool *p,long long b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_11(_Bool *p,unsigned long long b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_12(_Bool *p,__int128 b){_Bool value=b;value=(*p=value)+b;return value;}
_Bool s0_13(_Bool *p,unsigned __int128 b){_Bool value=b;value=(*p=value)+b;return value;}
char s1_0(char *p,_Bool b){char value=b;value=(*p=value)+b;return value;}
char s1_1(char *p,char b){char value=b;value=(*p=value)+b;return value;}
char s1_2(char *p,signed char b){char value=b;value=(*p=value)+b;return value;}
char s1_3(char *p,unsigned char b){char value=b;value=(*p=value)+b;return value;}
char s1_4(char *p,short b){char value=b;value=(*p=value)+b;return value;}
char s1_5(char *p,unsigned short b){char value=b;value=(*p=value)+b;return value;}
char s1_6(char *p,int b){char value=b;value=(*p=value)+b;return value;}
char s1_7(char *p,unsigned int b){char value=b;value=(*p=value)+b;return value;}
char s1_8(char *p,long b){char value=b;value=(*p=value)+b;return value;}
char s1_9(char *p,unsigned long b){char value=b;value=(*p=value)+b;return value;}
char s1_10(char *p,long long b){char value=b;value=(*p=value)+b;return value;}
char s1_11(char *p,unsigned long long b){char value=b;value=(*p=value)+b;return value;}
char s1_12(char *p,__int128 b){char value=b;value=(*p=value)+b;return value;}
char s1_13(char *p,unsigned __int128 b){char value=b;value=(*p=value)+b;return value;}
signed char s2_0(signed char *p,_Bool b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_1(signed char *p,char b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_2(signed char *p,signed char b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_3(signed char *p,unsigned char b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_4(signed char *p,short b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_5(signed char *p,unsigned short b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_6(signed char *p,int b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_7(signed char *p,unsigned int b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_8(signed char *p,long b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_9(signed char *p,unsigned long b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_10(signed char *p,long long b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_11(signed char *p,unsigned long long b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_12(signed char *p,__int128 b){signed char value=b;value=(*p=value)+b;return value;}
signed char s2_13(signed char *p,unsigned __int128 b){signed char value=b;value=(*p=value)+b;return value;}
unsigned char s3_0(unsigned char *p,_Bool b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_1(unsigned char *p,char b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_2(unsigned char *p,signed char b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_3(unsigned char *p,unsigned char b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_4(unsigned char *p,short b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_5(unsigned char *p,unsigned short b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_6(unsigned char *p,int b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_7(unsigned char *p,unsigned int b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_8(unsigned char *p,long b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_9(unsigned char *p,unsigned long b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_10(unsigned char *p,long long b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_11(unsigned char *p,unsigned long long b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_12(unsigned char *p,__int128 b){unsigned char value=b;value=(*p=value)+b;return value;}
unsigned char s3_13(unsigned char *p,unsigned __int128 b){unsigned char value=b;value=(*p=value)+b;return value;}
short s4_0(short *p,_Bool b){short value=b;value=(*p=value)+b;return value;}
short s4_1(short *p,char b){short value=b;value=(*p=value)+b;return value;}
short s4_2(short *p,signed char b){short value=b;value=(*p=value)+b;return value;}
short s4_3(short *p,unsigned char b){short value=b;value=(*p=value)+b;return value;}
short s4_4(short *p,short b){short value=b;value=(*p=value)+b;return value;}
short s4_5(short *p,unsigned short b){short value=b;value=(*p=value)+b;return value;}
short s4_6(short *p,int b){short value=b;value=(*p=value)+b;return value;}
short s4_7(short *p,unsigned int b){short value=b;value=(*p=value)+b;return value;}
short s4_8(short *p,long b){short value=b;value=(*p=value)+b;return value;}
short s4_9(short *p,unsigned long b){short value=b;value=(*p=value)+b;return value;}
short s4_10(short *p,long long b){short value=b;value=(*p=value)+b;return value;}
short s4_11(short *p,unsigned long long b){short value=b;value=(*p=value)+b;return value;}
short s4_12(short *p,__int128 b){short value=b;value=(*p=value)+b;return value;}
short s4_13(short *p,unsigned __int128 b){short value=b;value=(*p=value)+b;return value;}
unsigned short s5_0(unsigned short *p,_Bool b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_1(unsigned short *p,char b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_2(unsigned short *p,signed char b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_3(unsigned short *p,unsigned char b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_4(unsigned short *p,short b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_5(unsigned short *p,unsigned short b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_6(unsigned short *p,int b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_7(unsigned short *p,unsigned int b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_8(unsigned short *p,long b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_9(unsigned short *p,unsigned long b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_10(unsigned short *p,long long b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_11(unsigned short *p,unsigned long long b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_12(unsigned short *p,__int128 b){unsigned short value=b;value=(*p=value)+b;return value;}
unsigned short s5_13(unsigned short *p,unsigned __int128 b){unsigned short value=b;value=(*p=value)+b;return value;}
int s6_0(int *p,_Bool b){int value=b;value=(*p=value)+b;return value;}
int s6_1(int *p,char b){int value=b;value=(*p=value)+b;return value;}
int s6_2(int *p,signed char b){int value=b;value=(*p=value)+b;return value;}
int s6_3(int *p,unsigned char b){int value=b;value=(*p=value)+b;return value;}
int s6_4(int *p,short b){int value=b;value=(*p=value)+b;return value;}
int s6_5(int *p,unsigned short b){int value=b;value=(*p=value)+b;return value;}
int s6_6(int *p,int b){int value=b;value=(*p=value)+b;return value;}
int s6_7(int *p,unsigned int b){int value=b;value=(*p=value)+b;return value;}
int s6_8(int *p,long b){int value=b;value=(*p=value)+b;return value;}
int s6_9(int *p,unsigned long b){int value=b;value=(*p=value)+b;return value;}
int s6_10(int *p,long long b){int value=b;value=(*p=value)+b;return value;}
int s6_11(int *p,unsigned long long b){int value=b;value=(*p=value)+b;return value;}
int s6_12(int *p,__int128 b){int value=b;value=(*p=value)+b;return value;}
int s6_13(int *p,unsigned __int128 b){int value=b;value=(*p=value)+b;return value;}
unsigned int s7_0(unsigned int *p,_Bool b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_1(unsigned int *p,char b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_2(unsigned int *p,signed char b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_3(unsigned int *p,unsigned char b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_4(unsigned int *p,short b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_5(unsigned int *p,unsigned short b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_6(unsigned int *p,int b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_7(unsigned int *p,unsigned int b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_8(unsigned int *p,long b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_9(unsigned int *p,unsigned long b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_10(unsigned int *p,long long b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_11(unsigned int *p,unsigned long long b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_12(unsigned int *p,__int128 b){unsigned int value=b;value=(*p=value)+b;return value;}
unsigned int s7_13(unsigned int *p,unsigned __int128 b){unsigned int value=b;value=(*p=value)+b;return value;}
long s8_0(long *p,_Bool b){long value=b;value=(*p=value)+b;return value;}
long s8_1(long *p,char b){long value=b;value=(*p=value)+b;return value;}
long s8_2(long *p,signed char b){long value=b;value=(*p=value)+b;return value;}
long s8_3(long *p,unsigned char b){long value=b;value=(*p=value)+b;return value;}
long s8_4(long *p,short b){long value=b;value=(*p=value)+b;return value;}
long s8_5(long *p,unsigned short b){long value=b;value=(*p=value)+b;return value;}
long s8_6(long *p,int b){long value=b;value=(*p=value)+b;return value;}
long s8_7(long *p,unsigned int b){long value=b;value=(*p=value)+b;return value;}
long s8_8(long *p,long b){long value=b;value=(*p=value)+b;return value;}
long s8_9(long *p,unsigned long b){long value=b;value=(*p=value)+b;return value;}
long s8_10(long *p,long long b){long value=b;value=(*p=value)+b;return value;}
long s8_11(long *p,unsigned long long b){long value=b;value=(*p=value)+b;return value;}
long s8_12(long *p,__int128 b){long value=b;value=(*p=value)+b;return value;}
long s8_13(long *p,unsigned __int128 b){long value=b;value=(*p=value)+b;return value;}
unsigned long s9_0(unsigned long *p,_Bool b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_1(unsigned long *p,char b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_2(unsigned long *p,signed char b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_3(unsigned long *p,unsigned char b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_4(unsigned long *p,short b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_5(unsigned long *p,unsigned short b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_6(unsigned long *p,int b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_7(unsigned long *p,unsigned int b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_8(unsigned long *p,long b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_9(unsigned long *p,unsigned long b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_10(unsigned long *p,long long b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_11(unsigned long *p,unsigned long long b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_12(unsigned long *p,__int128 b){unsigned long value=b;value=(*p=value)+b;return value;}
unsigned long s9_13(unsigned long *p,unsigned __int128 b){unsigned long value=b;value=(*p=value)+b;return value;}
long long s10_0(long long *p,_Bool b){long long value=b;value=(*p=value)+b;return value;}
long long s10_1(long long *p,char b){long long value=b;value=(*p=value)+b;return value;}
long long s10_2(long long *p,signed char b){long long value=b;value=(*p=value)+b;return value;}
long long s10_3(long long *p,unsigned char b){long long value=b;value=(*p=value)+b;return value;}
long long s10_4(long long *p,short b){long long value=b;value=(*p=value)+b;return value;}
long long s10_5(long long *p,unsigned short b){long long value=b;value=(*p=value)+b;return value;}
long long s10_6(long long *p,int b){long long value=b;value=(*p=value)+b;return value;}
long long s10_7(long long *p,unsigned int b){long long value=b;value=(*p=value)+b;return value;}
long long s10_8(long long *p,long b){long long value=b;value=(*p=value)+b;return value;}
long long s10_9(long long *p,unsigned long b){long long value=b;value=(*p=value)+b;return value;}
long long s10_10(long long *p,long long b){long long value=b;value=(*p=value)+b;return value;}
long long s10_11(long long *p,unsigned long long b){long long value=b;value=(*p=value)+b;return value;}
long long s10_12(long long *p,__int128 b){long long value=b;value=(*p=value)+b;return value;}
long long s10_13(long long *p,unsigned __int128 b){long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_0(unsigned long long *p,_Bool b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_1(unsigned long long *p,char b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_2(unsigned long long *p,signed char b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_3(unsigned long long *p,unsigned char b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_4(unsigned long long *p,short b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_5(unsigned long long *p,unsigned short b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_6(unsigned long long *p,int b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_7(unsigned long long *p,unsigned int b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_8(unsigned long long *p,long b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_9(unsigned long long *p,unsigned long b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_10(unsigned long long *p,long long b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_11(unsigned long long *p,unsigned long long b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_12(unsigned long long *p,__int128 b){unsigned long long value=b;value=(*p=value)+b;return value;}
unsigned long long s11_13(unsigned long long *p,unsigned __int128 b){unsigned long long value=b;value=(*p=value)+b;return value;}
__int128 s12_0(__int128 *p,_Bool b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_1(__int128 *p,char b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_2(__int128 *p,signed char b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_3(__int128 *p,unsigned char b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_4(__int128 *p,short b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_5(__int128 *p,unsigned short b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_6(__int128 *p,int b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_7(__int128 *p,unsigned int b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_8(__int128 *p,long b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_9(__int128 *p,unsigned long b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_10(__int128 *p,long long b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_11(__int128 *p,unsigned long long b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_12(__int128 *p,__int128 b){__int128 value=b;value=(*p=value)+b;return value;}
__int128 s12_13(__int128 *p,unsigned __int128 b){__int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_0(unsigned __int128 *p,_Bool b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_1(unsigned __int128 *p,char b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_2(unsigned __int128 *p,signed char b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_3(unsigned __int128 *p,unsigned char b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_4(unsigned __int128 *p,short b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_5(unsigned __int128 *p,unsigned short b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_6(unsigned __int128 *p,int b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_7(unsigned __int128 *p,unsigned int b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_8(unsigned __int128 *p,long b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_9(unsigned __int128 *p,unsigned long b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_10(unsigned __int128 *p,long long b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_11(unsigned __int128 *p,unsigned long long b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_12(unsigned __int128 *p,__int128 b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
unsigned __int128 s13_13(unsigned __int128 *p,unsigned __int128 b){unsigned __int128 value=b;value=(*p=value)+b;return value;}
