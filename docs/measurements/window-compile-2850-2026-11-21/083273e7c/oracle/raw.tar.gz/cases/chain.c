int f(int a,int b,int c,short d){return ((((a+b) ^ (b-c))*(int)d) + (a<=b)) != ((c & (a-b)) + (c||d));}
