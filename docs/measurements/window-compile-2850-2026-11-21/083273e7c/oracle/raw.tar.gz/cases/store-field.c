struct S{unsigned a;int b;short c;int x:4;volatile int v;};int f(struct S*p,int b){p->a=p->b;p->c=b;return (p->x=p->v) + (p->b=b);}
