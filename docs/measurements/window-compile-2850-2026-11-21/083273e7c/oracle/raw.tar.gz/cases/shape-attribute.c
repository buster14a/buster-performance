typedef int Aligned __attribute__((aligned(16))); int f(Aligned *p,int q){volatile int v=*p;return (v+q)+(*p>q);}
