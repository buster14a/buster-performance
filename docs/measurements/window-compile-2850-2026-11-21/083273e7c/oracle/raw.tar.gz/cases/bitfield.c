struct S{unsigned x:5;int z:11;};int f(struct S v,int b){return (v.z+b) | (v.x+b);}
