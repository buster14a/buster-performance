int f(int *p,int *q,int i){return p==q || p+i<q || *(p+i)==4;}
