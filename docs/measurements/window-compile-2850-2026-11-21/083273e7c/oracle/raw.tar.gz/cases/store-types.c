int f(int b){enum K{K0,K1};enum K k=K0;_Atomic(int) a=b;register int c=b;_Bool p=b;k=(enum K)(a=c);return p+k;}
