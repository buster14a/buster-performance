int f(int a){const int b=3; b=a;return b;}
