int f(int x,int y){return (0 && (x/y)) + (1 || ++x) + (x&&y) + (!x||y);}
