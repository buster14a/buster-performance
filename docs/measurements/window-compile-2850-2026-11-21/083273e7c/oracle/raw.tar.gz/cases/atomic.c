struct S{_Atomic(int) c;};int f(struct S*p,int x){return (p->c+3)^(x-5);}
