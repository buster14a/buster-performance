struct S{int a;}; int f(struct S a,int b){return (b+1)+(a+b);}
