int f(int a,int b){return !(a++) + ((a+=b)&&(b+=a)) + ((a-=b)||(b-=a)) + (b ? ++a : a--);}
