from pathlib import Path
from collections import Counter
import csv,sys
d=Path(__file__).resolve().parent;case,variant=sys.argv[1:3];src=d/(f'{case}-{variant}.source' if variant else case+'.source'); ref=d/(case+'.ref')
read=lambda f,tag:{int(r[1]):r[2:] for l in f.read_text().splitlines() if (r:=l.split('\t'))[0]=='control-native-'+tag}
a=read(src,'local');b=read(ref,'ordinary');counts=Counter();failed=[]
with (d/(case+'-'+variant+'.tsv')).open('w') as out:
 w=csv.writer(out,delimiter='\t',lineterminator='\n');w.writerow(['close','entries','machine-bytes','branches','relocations','ordinary','typed','calls','records','reference-records','bytes','fixups'])
 for c,v in a.items():
  nbytes=len(v[6])//2;branches=int(v[4].split(':')[-1]);refs=v[7].count(',');cnt=int(v[1]);counts['produced']+=1
  if c not in b:w.writerow([c,cnt,nbytes,branches,refs,0]);continue
  other=b[c];same=[v[i]==other[i] for i in (2,3,4,5,6,7)];w.writerow([c,cnt,nbytes,branches,refs,1,*[int(x) for x in same]])
  counts['selected']+=1;counts['exact']+=all(same);counts['typed']+=same[0] and same[1];counts['native_bytes']+=same[4];counts['fixups']+=same[5]
  if all(same):
   counts['exact_entries']+=cnt;counts['exact_branch_bodies']+=branches>0; counts['exact_branches']+=branches;counts['exact_relocations']+=refs;counts['exact_bytes']+=nbytes
  else:failed.append((c,[i for i,k in enumerate(same) if not k]))
print(dict(counts),'first misses',failed[:14],flush=True)
