extern int consume(int);
extern int unreachable(void);
extern int global;
static int helper(int x) { return x + 3; }
int immediate(void) { return 19; }
int simple(int x) { consume(x); return helper(x - 1); }
int conditional(int x) { if (x < 4) return helper(x); return consume(x + global); }
int alternative(int x) { if (x) consume(x); else consume(global); return x; }
int folded(int x) { if (0) return unreachable(); return helper(x); }
int iteration(int x) { while (x > 10) { if (x == 12) break; --x; } return x; }
int repeated(int x) { do { --x; if (x > 16) continue; consume(x); } while (x > 0); return x; }
int indices(int x) { for (; x > 0; --x) consume(x); return x; }
int local_init(int x) { int n = x + 1; return n; }
int cases(int x) { switch (x) { case 0: return 7; default: return x; } }
