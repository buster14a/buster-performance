#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD
./compiler --lanes 1 -c -nostdinc "$d/fixtures.c" -o ref.o >fixture.ref.out 2>fixture.ref
BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_SOURCE_AUDIT=1 ./compiler --lanes 1 -c -nostdinc "$d/fixtures.c" -o native.o >fixture.native.out 2>fixture.native
cmp ref.o native.o
clang=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$clang" -O0 -c fixtures.c -o clang.o
for v in ref native clang;do "$clang" driver.c "$v.o" -o "$v.run";"./$v.run" >"$v.result";cmp ref.result "$v.result";done
sha256sum ref.o native.o
cat ref.result
