set pagination off
set debuginfod enabled off
set confirm off
python
import gdb
class Observe(gdb.Breakpoint):
 def stop(self):
  k=int(gdb.parse_and_eval('$rdi'));n=int(gdb.parse_and_eval('$esi'))
  def read(o):return int.from_bytes(gdb.selected_inferior().read_memory(k+o,8).tobytes(),'little')
  if n>=8192:
   print('k4-input',n)
   for ext,off in [('roles',56),('depths',8)]:
    with open('fixed-parents-study/key-blocks/sqlite.'+ext,'wb') as f:f.write(gdb.selected_inferior().read_memory(read(off),n).tobytes())
  return False
Observe("*'parse_parents_vector.buster_split'")
end
run
