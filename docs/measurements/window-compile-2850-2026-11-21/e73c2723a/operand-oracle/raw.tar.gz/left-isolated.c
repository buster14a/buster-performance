typedef int V __attribute__((vector_size(128)));int f(V v,int i){return v[i];}
