set pagination off
set confirm off
set debuginfod enabled off
python cfg={'CheckProgram.input': 0, 'CheckProgram.stream': 8, 'CheckProgram.types': 16, 'CheckInput.graph': 0, 'CheckGraph.count': 236, 'CheckGraph.ops': 32, 'CheckGraph.operand0': 48, 'CheckStream.conversions': 120, 'TypeColumns.count': 72, 'TypeColumns.kind': 0, 'TypeColumns.size': 56, 'entry': 19681088, 'scalar': 22579296, 'stride': 32, 'conversion_size': 8, 'add': 5, 'subscript': 29};which='left-isolated';scalar=True;perturb=True
source /home/david/Documents/Codex/2026-11-21/g/work/main-typed-reserve-study/mutate-breakpoints.py
run
python print("HITS",hits)
