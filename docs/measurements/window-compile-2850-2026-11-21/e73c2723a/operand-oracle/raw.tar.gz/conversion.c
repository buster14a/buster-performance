typedef int V __attribute__((vector_size(128)));V object; int f(int a){return a+1;}
