#!/bin/bash
exec /home/david/Documents/Codex/2026-11-21/g/work/main-typed-reserve-study/../main-typed-reserve-base/build/compiler "$@"
