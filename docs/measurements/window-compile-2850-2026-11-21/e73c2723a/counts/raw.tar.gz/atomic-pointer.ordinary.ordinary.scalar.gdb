set pagination off
set confirm off
set debuginfod enabled off
python entry_addr=19681088; scalar_addr=22579296;replacement=True;layout=(16, 0, 72)
source /home/david/Documents/Codex/2026-11-21/g/work/main-typed-reserve-study/reserve-breakpoints.py
run
python print("RESERVE finished",observations,len(pending))
