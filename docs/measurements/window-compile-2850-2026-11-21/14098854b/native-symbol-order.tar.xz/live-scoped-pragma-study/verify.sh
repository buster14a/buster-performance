#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d="$PWD"
cd ../live-scoped-pragma
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/
cd "$d"
python3 verify.py >verify.log 2>&1
wc -l trace.tsv pulsed.tsv
