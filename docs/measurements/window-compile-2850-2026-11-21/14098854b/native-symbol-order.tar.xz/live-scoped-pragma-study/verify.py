"""Compare the native final resolver with the ordinary and uncorrected frozen captures."""
import csv
import hashlib
import os
from pathlib import Path
import subprocess
import sys
study=Path(__file__).resolve().parent
work=study.parent
sys.path.insert(0,str(work/'live-scoped-bindings-study'))
from common import environ, fields, semantic, workloads
tree=work/'live-scoped-pragma'
first=work/'live-prefix-bindings-study'
fixed=work/'live-pragma-parity-study'
old=work/'live-scoped-bindings-study'
exes={'ordinary':work/'default-integer-control','uncorrected':work/'live-scoped-bindings',
      'fixed-parent':work/'live-symbol-pragma-order','candidate':tree}
def sha(b):return hashlib.sha256(b).hexdigest()
def run(exe,args,mode,window=1):
    out=study/'unit.o';out.unlink(missing_ok=True)
    result=subprocess.run([exe/'build/compiler','--lanes','1','-c',*args,'-o',out],
                          env=environ(mode,window),capture_output=True,timeout=120)
    return result, out.read_bytes() if out.is_file() else b''
def write_trace():
    with (study/'trace.tsv').open('w',buffering=1) as log:
        writer=csv.writer(log,delimiter='\t',lineterminator='\n')
        writer.writerow(['source','mode','event_bytes','event_sha','answer_bytes','answer_sha','elf_sha'])
        for name,nt in [('sqlite',716136),('buster',2433563)]:
            oracle=first/('trace-'+name+'-ordinary')
            for key,mode in [('uncorrected','consumer'),('candidate','consumer'),('candidate','mismatch')]:
                dest=study/('trace-'+name+'-'+key+'-'+mode)
                env=environ(mode,24);env['LIVE_BINDING_TRACE_TOKENS']=str(nt)
                args=[arg for arg in workloads[name]]
                with (Path(str(dest)+'.log')).open('wb') as gdb:
                    subprocess.run([sys.executable,old/'replay-gdb.py',exes[key],dest,'--',*args],
                                   stdout=gdb,stderr=subprocess.STDOUT,env=env,timeout=320,check=True)
                result=[]
                for ext in ['events','answers','o']:
                    p=Path(str(dest)+'.'+ext).read_bytes()
                    assert p==Path(str(oracle)+'.'+ext).read_bytes(),(name,key,mode,ext)
                    if ext!='o':result.append(len(p))
                    result.append(sha(p))
                writer.writerow([name,key+'-'+mode,*result])
def write_pulsed():
    with (study/'pulsed.tsv').open('w',buffering=1) as log:
        wr=csv.writer(log,delimiter='\t',lineterminator='\n')
        wr.writerow(['source','policy','arm','status','retained','taken','answers','elf_sha','diagnostics_sha'])
        sources=sorted((first/'binding-pulsed').glob('*.c'))
        assert len(sources)==35,len(sources)
        for src in sources:
            for policy,flags in {'default':[],'warnings':['-Wall','-Wextra','-ferror-limit=0'],'debug':['-g'],'scalar':['--scalar']}.items():
                want=None
                for arm,mode in [('ordinary','ordinary'),('uncorrected','consumer'),('fixed-parent','prefix-parent'),('candidate','consumer'),('candidate','mismatch')]:
                    r,elf=run(exes[arm],[*flags,src],mode)
                    answer=r.returncode,r.stdout,semantic(r.stderr),sha(elf)
                    counts=fields(rb'^pre-eof-bindings-consumed\tcaptured=(\d+)\tordinary-source-uses=(\d+)\tfinal-answers=(\d+)',r.stderr)
                    wr.writerow([src.stem,policy,arm+'-'+mode,answer[0],*(counts or (0,0,0)),answer[-1],sha(answer[2])])
                    if want is None:want=answer
                    if arm!='uncorrected':assert want==answer,(src,policy,arm,answer[:3],want[:3])
write_trace()
write_pulsed()
