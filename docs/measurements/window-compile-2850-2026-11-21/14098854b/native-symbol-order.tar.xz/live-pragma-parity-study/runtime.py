"""Relocate and run distinct symbol providers, plus a missing weak/strong link oracle."""
from pathlib import Path
import csv,os,subprocess,sys
study=Path(__file__).resolve().parent;w=study.parent
sys.path.insert(0,str(w/'live-prefix-bindings-study'))
from common import environ
clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
rd=study/'linked';rd.mkdir(exist_ok=True)
inputs={'both-providers':('extern int renamed,weakened;int earlier(void){return renamed+weakened;}\n#pragma redefine_extname renamed other_symbol\n#pragma weak weakened\n','int renamed=7, other_symbol=51, weakened=4;int earlier(void);int main(void){return earlier();}\n'),
        'missing-strong':('extern int renamed,weakened;int earlier(void){return renamed+weakened;}\n#pragma redefine_extname renamed other_symbol\n#pragma weak weakened\n','int renamed=7,other_symbol=51;int earlier(void);int main(void){return 0;}\n'),
        'weak-alias':('int target=7;\n#pragma weak another = target\nextern int another;int earlier(void){return another;}\n','int earlier(void);int main(void){return earlier();}\n')}
arms=[('clang',clang,'ordinary'),('ordinary',w/'default-integer-control/build/compiler','ordinary'),('parent-ordinary',w/'live-native-typed/build/compiler','ordinary'),('parent-source',w/'live-native-typed/build/compiler','prefix-parent'),('fixed-source',w/'live-symbol-pragma-order/build/compiler','prefix-parent')]
with (study/'runtime.tsv').open('w',buffering=1) as f:
 wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['case','mode','compile_status','link_status','program_status'])
 for name,(module,provider) in inputs.items():
  src=rd/(name+'.c');src.write_text(module);partner=rd/(name+'-provider.c');partner.write_text(provider)
  for label,exe,mode in arms:
   obj=rd/(name+'-'+label+'.o');prog=rd/(name+'-'+label+'.exe')
   q=subprocess.run([exe,'-c',src,'-o',obj],env=environ(mode,1,False),capture_output=True)
   link=rc=None
   if q.returncode==0:
    lk=subprocess.run([clang,'-no-pie',obj,partner,'-o',prog],capture_output=True)
    link=lk.returncode
    if link==0:rc=subprocess.run([prog],capture_output=True).returncode
   got=(q.returncode,link,rc)
   if label=='parent-source':want={'both-providers':(0,0,55),'missing-strong':(0,0,0),'weak-alias':(1,None,None)}[name]
   else:want={'both-providers':(0,0,11),'missing-strong':(0,1,None),'weak-alias':(0,0,7)}[name]
   wr.writerow([name,label,*got]);assert got==want,(name,label,got,want,q.stderr)
