int target=7;
#pragma weak another = target
extern int another;int earlier(void){return another;}
