int earlier(void);int main(void){return earlier();}
