int renamed=7, other_symbol=51, weakened=4;int earlier(void);int main(void){return earlier();}
