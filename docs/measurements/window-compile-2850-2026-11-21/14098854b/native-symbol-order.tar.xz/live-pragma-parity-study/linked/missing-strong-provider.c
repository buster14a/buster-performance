int renamed=7,other_symbol=51;int earlier(void);int main(void){return 0;}
