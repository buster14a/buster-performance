#pragma redefine_extname renamed other_symbol
extern int renamed;
int later(void){return renamed;}
