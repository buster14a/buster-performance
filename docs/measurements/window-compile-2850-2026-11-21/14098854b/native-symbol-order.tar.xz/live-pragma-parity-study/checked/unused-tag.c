int extra;
#pragma redefine_extname absent other_symbol
int tail;
