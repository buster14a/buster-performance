extern int renamed;
#pragma redefine_extname renamed other_symbol
int later(void){return renamed;}
