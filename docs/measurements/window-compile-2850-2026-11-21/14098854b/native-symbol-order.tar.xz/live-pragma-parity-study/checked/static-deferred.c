extern int renamed,weakened;static int hidden(void){return renamed+weakened;}
#pragma redefine_extname renamed other_symbol
#pragma weak weakened
int use(void){return hidden();}
