extern int renamed,weakened;int earlier(void){return renamed+weakened;}
_Pragma("redefine_extname renamed other_symbol")
_Pragma("weak weakened")
