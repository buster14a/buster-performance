extern int renamed;
int later(int x){return renamed+x;}
#pragma redefine_extname renamed other_symbol
