extern int renamed,weakened;int f(void){return sizeof(renamed)+sizeof(weakened);}
#pragma redefine_extname renamed other_symbol
#pragma weak weakened
int later(void){return renamed+weakened;}
