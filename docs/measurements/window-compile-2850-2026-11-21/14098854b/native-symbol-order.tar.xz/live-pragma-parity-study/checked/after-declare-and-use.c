extern int renamed;
int later(void){return renamed;}
#pragma redefine_extname renamed other_symbol
int again(void){return renamed;}
