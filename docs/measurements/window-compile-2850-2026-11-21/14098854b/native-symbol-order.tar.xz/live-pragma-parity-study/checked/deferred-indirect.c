extern int renamed,weakened;static int helper(void){return renamed+weakened;}static int outer(void){return helper();}int force(void){return outer();}
#pragma redefine_extname renamed other_symbol
#pragma weak weakened
