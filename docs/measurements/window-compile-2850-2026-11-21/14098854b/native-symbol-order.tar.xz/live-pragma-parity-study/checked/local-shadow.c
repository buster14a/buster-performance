extern int renamed,weakened;int f(void){int renamed=3,weakened=4;return renamed+weakened;}
#pragma redefine_extname renamed other_symbol
#pragma weak weakened
int later(void){return renamed+weakened;}
