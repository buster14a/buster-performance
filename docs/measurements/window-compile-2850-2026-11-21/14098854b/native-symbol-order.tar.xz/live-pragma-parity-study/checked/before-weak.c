extern int renamed;
int later(void){return renamed;}
#pragma weak renamed
