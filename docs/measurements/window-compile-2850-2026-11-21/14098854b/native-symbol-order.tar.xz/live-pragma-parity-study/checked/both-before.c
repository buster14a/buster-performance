#pragma redefine_extname renamed other_symbol
#pragma weak weakened
extern int renamed,weakened;int f(void){return renamed+weakened;}
