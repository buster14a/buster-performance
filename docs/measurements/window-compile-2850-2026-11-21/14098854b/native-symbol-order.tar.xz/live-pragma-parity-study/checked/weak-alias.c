int target;
#pragma weak another = target
extern int another;int f(void){return another;}
