extern int renamed,weakened;int *refs[]={&renamed,&weakened};
#pragma redefine_extname renamed other_symbol
#pragma weak weakened
