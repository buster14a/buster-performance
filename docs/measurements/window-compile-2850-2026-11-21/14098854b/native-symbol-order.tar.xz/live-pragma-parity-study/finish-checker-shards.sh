#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d="$PWD"; cd ../live-symbol-pragma-order
clang=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
export PATH="$(dirname "$clang"):$PATH"
# Deal indices also advance inside several suites. Test the permanent assertion through the actual deal.
got=0
for i in 1 3 4 5 6 7 8; do
 ./build/compiler test-checker-driver --clang "$clang" --part "$i/8" --executable "$PWD/build/compiler" >"$d/driver-$i.log" 2>&1
 if ((got == 0)); then
  history=0
  ./build/compiler test-checker-driver --clang "$clang" --part "$i/8" --executable "$PWD/../live-native-typed/build/compiler" >"$d/historical-driver-$i.log" 2>&1 || history=$?
  if grep -Fq 'a prior emitted use keeps its original name and strong undefined binding before late pragmas' "$d/historical-driver-$i.log"; then
   test "$history" -ne 0
   echo "Permanent assertion reproduces the historical failure on checker-driver part $i/8"
   got=1
  fi
 fi
done
test "$got" -eq 1
