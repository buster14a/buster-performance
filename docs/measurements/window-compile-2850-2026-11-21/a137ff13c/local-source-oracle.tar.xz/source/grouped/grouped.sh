#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/../switch-inputs"
w=$(cd .. && pwd)
d="$w/packed-main-study/grouped"
mkdir -p "$d"
source "$w/switch-local-args.sh"
tree="$w/pregraph-warning-study/compiler-source"
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $w/proof-predefines.h $tree/src/buster/compiler/main.c"
scratch=$(mktemp -d)
trap 'rm -f -- "$scratch"/*.o; rmdir "$scratch"' EXIT
cd "$scratch"
for group in sqlite main lua musl; do
 value=${group}_arguments
 eval "args=(${!value})"
 case $group in sqlite|main) sz=1; args+=(-o unit.o);; lua) sz=34;; musl) sz=1336;; esac
 for mode in default off;do
  options=();[[ $mode != off ]] || options+=(--attested=off)
  for policy in plain strict; do
   warnings=();[[ $policy != strict ]] || warnings+=(-Wall -Wextra)
   for img in base candidate; do
    cc="$w/default-integer-control/build/compiler"; [[ $img != candidate ]] || cc="$w/packed-declarations-main/build/compiler"
    stem="$d/$group-$mode-$policy-$img"
    "$cc" "${options[@]}" --lanes 1 -c "${warnings[@]}" "${args[@]}" >"$stem.stdout" 2>"$stem.stderr"
    python3 "$w/bench-local/full-chain-manifest.py" "$stem.objects" "$sz"
    rm -f -- "$scratch"/*.o
   done
   for ending in stdout stderr objects; do cmp "$d/$group-$mode-$policy-base.$ending" "$d/$group-$mode-$policy-candidate.$ending";done
  done
  stem="$d/$group-$mode-census"
  BUSTER_DECLARATION_CENSUS=1 "$w/packed-declarations-main/build/compiler" "${options[@]}" --lanes 1 -c "${args[@]}" >"$stem.stdout" 2>"$stem.stderr"
  python3 "$w/bench-local/full-chain-manifest.py" "$stem.objects" "$sz"
  cmp "$stem.objects" "$d/$group-$mode-plain-base.objects"
  rm -f -- "$scratch"/*.o
 done
done
python3 - "$d" <<'PY'
from pathlib import Path
import csv,sys,re,hashlib
folder=Path(sys.argv[1]);rx=re.compile(r'^named-declarations definitions=(\d+)/(\d+) locals=(\d+)/(\d+) definition-parameters=(\d+)/(\d+) prototype-parameters=(\d+)/(\d+) derived=(\d+)$',re.M)
with (folder/'results.tsv').open('w') as out:
 w=csv.writer(out,delimiter='\t',lineterminator='\n');w.writerow(['group','attested','policy','files','manifest','diagnostics','eligible_units','declarations','tokens'])
 for group in ('sqlite','main','lua','musl'):
  for mode in ('default','off'):
   rows=rx.findall((folder/f'{group}-{mode}-census.stderr').read_text());total=[sum(int(r[i]) for r in rows) for i in range(9)]
   for policy in ('plain','strict'):
    stem=f'{group}-{mode}-{policy}-base.';obj=(folder/(stem+'objects')).read_bytes();err=(folder/(stem+'stderr')).read_bytes()
    w.writerow([group,mode,policy,len(obj.splitlines()),hashlib.sha256(obj).hexdigest(),hashlib.sha256(err).hexdigest(),len(rows),sum(total[0:8:2]),sum(total[1:8:2])])
PY
