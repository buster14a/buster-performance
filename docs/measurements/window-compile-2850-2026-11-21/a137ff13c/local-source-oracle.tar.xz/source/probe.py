from pathlib import Path
from collections import Counter
import gzip,re
w=Path(__file__).resolve().parent.parent
rx=re.compile(r'^\s*(\d+)\s+\d+  (.*?)\s+(\S+)\s+\| (\S+)\s+(\d+)\s+(-?\d+)$')
text=[];kinds=[];roles=[]
with gzip.open(w/'fresh-file-study/sqlite-tree.gz','rt',errors='replace') as f:
 for line in f:
  m=rx.match(line.rstrip('\n'))
  if m:
   text.append(m[2].strip());kinds.append(m[3]);roles.append(m[4])
counts=Counter();codes=bytearray(len(roles));grammar=Counter()
for i in range(1,len(roles)-1):
 if roles[i]!='OPERAND' or kinds[i]!='IDENTIFIER' or (kinds[i+1] not in ('COMMA','EQUAL','SEMI','R_PAREN') and roles[i+1]!='OPEN_FUNCTION'): continue
 j=i
 while j>0 and i-j<2 and kinds[j-1]=='STAR':j-=1
 k=j
 while k>0 and j-k<4 and roles[k-1]=='SPECIFIER':k-=1
 if k==j or (k>0 and roles[k-1]=='SPECIFIER'):continue
 code=(j-k) | (i-j)<<3
 assert not codes[k];codes[k]=code
 counts[kinds[i+1]]+=1;grammar[(j-k,i-j)]+=1
path=w/'packed-main-study/sqlite-recipes.bin';path.write_bytes(codes)
print('parsed',len(roles),'shapes',sum(counts.values()),'syntax',counts,'recipe histogram',grammar)
