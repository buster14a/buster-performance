#!/bin/bash
set -eu
cd "$(dirname "$0")/../packed-declarations-main"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >../packed-main-study/build.log 2>&1
cp ../default-integer-control/build/predefines.h build/predefines.h
cd ../switch-inputs
source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
BUSTER_DECLARATION_CENSUS=1 ../packed-declarations-main/build/compiler -c -o ../packed-main-study/sqlite.candidate.o "${args[@]}" >../packed-main-study/sqlite.out 2>../packed-main-study/counter.txt
../default-integer-control/build/compiler -c -o ../packed-main-study/sqlite.parent.o "${args[@]}" >../packed-main-study/parent.out 2>../packed-main-study/parent.err
cmp ../packed-main-study/sqlite.candidate.o ../packed-main-study/sqlite.parent.o
python3 ../packed-main-study/oracle.py >../packed-main-study/oracle.log 2>&1
python3 ../packed-main-study/local_pairs.py >../packed-main-study/pairs.log 2>&1
python3 ../packed-main-study/target_pairs.py >../packed-main-study/target.log 2>&1
parent=$PWD/../default-integer-control/build/compiler
new=$PWD/../packed-declarations-main/build/compiler
out=$PWD/../packed-main-study/corpus
mkdir -p "$out"
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main lua musl; do var=${g}_arguments; eval "args=(${!var})"; python3 ../default-object-qa/pair.py "$out" "$g" "$parent" "$new" "${args[@]}"; done
python3 ../packed-main-study/pmu.py >../packed-main-study/pmu.log 2>&1
cd ../packed-declarations-main
for part in {1..8}; do ./build/compiler test-checker --seed 2850 --part "$part/8" >"../packed-main-study/checker-$part.log" 2>&1; done
