from pathlib import Path
import re,csv,gzip,subprocess as sp,hashlib
s=Path(__file__).resolve().parent;w=s.parent;t=w/'packed-declarations-main';headers=(t/'src/buster/compiler/c_parser.c').read_text();impl=(t/'src/buster/compiler/c_check_input.c').read_text()
def ids(macro,enum):
 a=headers.index('#define '+macro+'(X)');b=headers.index('typedef enum '+enum,a);return {n:i for i,n in enumerate(re.findall(r'^\s+X\(([A-Za-z0-9_]+)(?:,|\))',headers[a:b],re.M))}
ks=ids('BUSTER_PARSE_KINDS','ParseKind');rs=ids('BUSTER_PARSE_ROLES','ParseRole')
rx=re.compile(r'^\s*(\d+)\s+\d+  (.*?)\s+(\S+)\s+\| (\S+)\s+(\d+)\s+(-?\d+)$');kinds=bytearray();roles=bytearray()
with gzip.open(w/'fresh-file-study/sqlite-tree.gz','rt',errors='replace') as f:
 for line in f:
  m=rx.match(line.rstrip('\n'))
  if m: kinds.append(ks[m[3]]);roles.append(rs[m[4]])
assert bytes(roles)==(w/'byte-depth-study/source-depths/baseline-sqlite.bin.roles').read_bytes()
(s/'sqlite-kinds.bin').write_bytes(kinds);(s/'sqlite-roles.bin').write_bytes(roles)
a=impl.index('static void check_input_named_prefixes(');b=impl.index('// Read a complete scalar',a);func=impl[a:b]
a=impl.index('static uint64_t check_input_scan_all(');b=impl.index('// The tokens whose byte',a);scan=impl[a:b]
source='''#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>
#include <sys/mman.h>
#include <unistd.h>
typedef struct { struct { const uint8_t *kinds; uint32_t count; } tokens; struct { const uint8_t *roles; } tree; } Parser;
'''+''.join(f'#define PARSE_KIND_{n} {i}\n' for n,i in ks.items())+''.join(f'#define PARSE_ROLE_{n} {i}\n' for n,i in rs.items())+scan+func+r'''
static uint8_t scalar(const uint8_t* kinds, const uint8_t* roles, uint32_t at, uint32_t count) {
 uint32_t j=at;while(j<count && j-at<4 && roles[j]==PARSE_ROLE_SPECIFIER)j++;
 if(j==at)return 0;
 uint32_t k=j;while(k<count && k-j<2 && kinds[k]==PARSE_KIND_STAR)k++;
 if(k+1>=count || kinds[k]!=PARSE_KIND_IDENTIFIER || roles[k]!=PARSE_ROLE_OPERAND)return 0;
 const uint8_t next=kinds[k+1];
 return next==PARSE_KIND_COMMA || next==PARSE_KIND_SEMI || next==PARSE_KIND_R_PAREN || next==PARSE_KIND_EQUAL || roles[k+1]==PARSE_ROLE_OPEN_FUNCTION ? ((j-at)|((k-j)<<3)):0;
}
static uint8_t *guard(uint32_t n) {
 size_t p=sysconf(_SC_PAGESIZE),room=((n+p-1)/p)*p;
 uint8_t *base=mmap(NULL,room+p,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 if(base==MAP_FAILED || mprotect(base+room,p,PROT_NONE))abort();
 return base+room-n;
}
static void unguard(uint8_t *ptr,uint32_t n) {
 size_t p=sysconf(_SC_PAGESIZE),room=((n+p-1)/p)*p;munmap(ptr+n-room,room+p);
}
static uint32_t verified;
static uint32_t verify(const uint8_t*k,const uint8_t*r,uint32_t n) {
 uint8_t *kk=guard(n),*rr=guard(n),*out=guard(n);
 memcpy(kk,k,n);memcpy(rr,r,n);memset(out,255,n);
 Parser p={.tokens={.kinds=kk,.count=n},.tree={.roles=rr}};check_input_named_prefixes(&p,out);
 uint32_t emits=0;
 for(uint32_t j=0;j<n;j++){
  const uint8_t want=scalar(kk,rr,j,n);
  if(out[j]!=want){fprintf(stderr,"mismatch count=%u at=%u got=%u want=%u\n",n,j,out[j],want);abort();}
  emits+=out[j]!=0;
 }
 unguard(kk,n);unguard(rr,n);unguard(out,n);verified+=n;return emits;
}
int main(int argc,char**argv) {
 if(argc!=4)return 2;
 uint32_t n=strtoul(argv[3],NULL,10);uint8_t*k=malloc(n),*r=malloc(n);
 FILE *kf=fopen(argv[1],"rb"),*rf=fopen(argv[2],"rb");if(!kf||!rf||fread(k,1,n,kf)!=n||fread(r,1,n,rf)!=n)return 1;
 printf("sqlite tokens=%u emitted-prefix-bytes=%u\n",n,verify(k,r,n));
 uint8_t ks[200],rs[200];unsigned cases=0;
 for(unsigned shift=0;shift<64;shift++){for(unsigned sp=1;sp<=4;sp++){for(unsigned ptr=0;ptr<=2;ptr++){for(unsigned tail=0;tail<=8;tail++){
   memset(ks,0,sizeof ks);memset(rs,0,sizeof rs);unsigned i=shift;for(unsigned t=0;t<sp;t++)rs[i++]=PARSE_ROLE_SPECIFIER;for(unsigned t=0;t<ptr;t++)ks[i++]=PARSE_KIND_STAR;
   ks[i]=PARSE_KIND_IDENTIFIER;rs[i++]=PARSE_ROLE_OPERAND;ks[i++]=PARSE_KIND_SEMI;
   unsigned len=i+tail;if(tail<3)len=i-2+tail;verify(ks,rs,len);cases++;
 }}}}
 printf("alignment-shape-tail-cases=%u scalar-checked-output-bytes=%u guard-pages=both-inputs-and-output\n",cases,verified);return 0;
}
'''
c=s/'prefix-oracle.c';c.write_text(source)
clang='/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang';exe=s/'prefix-oracle';sp.run([clang,'-march=native','-O3','-Wall','-Wextra','-Werror',c,'-o',exe],check=True)
print('production-producer-sha256',hashlib.sha256(func.encode()).hexdigest(),flush=True)
sp.run([exe,s/'sqlite-kinds.bin',s/'sqlite-roles.bin',str(len(roles))],check=True)
