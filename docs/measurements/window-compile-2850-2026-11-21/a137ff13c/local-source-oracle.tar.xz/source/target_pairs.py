from pathlib import Path
import csv,subprocess as sp,random,time,statistics,re,os,hashlib
w=Path(__file__).resolve().parent.parent;d=w/'packed-main-study';c=[('base',w/'default-integer-control/build/compiler'),('candidate',w/'packed-declarations-main/build/compiler')];rng=random.Random(2850);metric=re.compile(rb'^time-stage\tcheck-input\t([0-9.]+)',re.M)
forms={'admitted':lambda i:f'static int p{i}(const S *s, T t, int n, char **p){{ T x=t; int y=n; const S *v=s; return (int)x+y+v->k+**p; }}', 'named':lambda i:f'extern int q{i}(const S*,T,int,char**);', 'mixed':lambda i:f'extern int q{i}(S*,int); static int p{i}(S *s,int n){{int x=n; return q{i}(s,x);}}' };num=1200
with (d/'target-pairs.tsv').open('w',buffering=1) as stream:
 wr=csv.writer(stream,delimiter='\t');wr.writerow(['mode','pair','order','base_ms','candidate_ms','base_input_ms','candidate_input_ms']);
 for mode,form in forms.items():
  f=d/('prototypes-'+mode+'.c');f.write_text('typedef struct S { int k; } S; typedef unsigned long T;\n'+'\n'.join(form(i) for i in range(num))+'\nint main(void){return 0;}\n');data=[];args=['-c',f,'-o',d/'synth.o']
  reference=sp.run([c[0][1],*args],capture_output=True,timeout=60);assert reference.returncode==0,reference.stderr
  ref_object=(d/'synth.o').read_bytes()
  ordinary=sp.run([c[1][1],*args],env=dict(os.environ,BUSTER_DECLARATION_CENSUS="1"),capture_output=True,timeout=60);assert ordinary.returncode==0 and ref_object==(d/'synth.o').read_bytes(),ordinary.stderr
  print(mode, 'native-hash',hashlib.sha256(ref_object).hexdigest(),ordinary.stderr.decode().strip(),flush=True)
  for j in range(19):
   order=c.copy();rng.shuffle(order);v={}
   for label,cc in order:
    st=time.perf_counter_ns();r=sp.run([cc,'--time-stages',*args],capture_output=True,timeout=60);elapsed=(time.perf_counter_ns()-st)/1e6;assert r.returncode==0,r.stderr;rs=metric.search(r.stderr);assert rs,r.stderr;v[label]=(elapsed,float(rs[1]));
   if j>0:
    a,b=v['base'],v['candidate'];wr.writerow([mode,j,','.join(x[0] for x in order),a[0],b[0],a[1],b[1]]);data.append((b[0]-a[0],b[1]-a[1]))
  print(mode,'n',len(data),'paired-delta-wall-ms',statistics.median(x[0] for x in data),'paired-delta-check-input-ms',statistics.median(x[1] for x in data),flush=True)
