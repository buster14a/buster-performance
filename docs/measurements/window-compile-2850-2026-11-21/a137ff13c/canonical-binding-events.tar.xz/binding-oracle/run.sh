#!/bin/bash
set -eu
cd "$(dirname "$0")"
for pair in 'packed-declarations-main a137ff13c' 'ordered-parameter-runs 5d79daa6e'; do
 read -r tree label <<<"$pair"
 python3 gdb-events.py "$tree" "$label" >"$label.log" 2>&1
 for group in sqlite buster; do
  cmp "$group-$label.events" "../source-use-run-study/$group-upstream.events"
 done
done
sha256sum ./*.events
