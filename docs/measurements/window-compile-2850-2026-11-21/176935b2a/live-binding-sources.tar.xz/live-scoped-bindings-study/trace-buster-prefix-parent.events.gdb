set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
break check_input_resolve_range.buster_split if *(unsigned int*)(*(unsigned long*)($rdi+8)+1940)==2433563
run
set $reader=$rdi
finish
python
import struct, gdb
p=gdb.selected_inferior()
rd=int(gdb.parse_and_eval('$reader'))
def mem(addr,n): return bytes(p.read_memory(addr,n)) if n else b''
def num(addr,n): return int.from_bytes(mem(addr,n),'little')
base=rd+408
offset={'heads': 0, 'name_capacity': 8, 'active': 24, 'active_count': 32, 'count': 16, 'operation': 88, 'kind': 96, 'key': 40, 'declaration': 48, 'point': 56, 'end': 64, 'previous': 72, 'depth': 80}
def val(k,width):return num(base+offset[k],width)
out=num(rd+8,8)
visits=num(out+2064,4)
events=val('count',4)
names=val('name_capacity',4)
active=val('active_count',4)
with open('/home/david/Documents/Codex/2026-11-21/g/work/live-scoped-bindings-study/trace-buster-prefix-parent.events','wb') as f:
 f.write(struct.pack('<4I',visits,events,names,active))
 for k,sz in [('heads',4*names*3),('active',4*active)]+[(name,4*events) for name in ('key','declaration','point','end','previous','depth')]+[(name,events) for name in ('operation','kind')]:
  f.write(mem(val(k,8),sz))
end
continue
quit
