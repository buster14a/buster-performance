from common import *
from statistics import median
import csv,time
# Capture the full final reader in GDB after passing over the shorter pre-EOF reader.
with (s/'trace.tsv').open('w',buffering=1) as log:
 wr=csv.writer(log,delimiter='\t',lineterminator='\n');wr.writerow(['source','mode','events_bytes','events_sha','answer_bytes','answers_sha','elf_sha'])
 for name,args in workloads.items():
    seen={}
    for mode,tree in [('ordinary',w/'default-integer-control'),('prefix-parent',w/'live-native-typed'),('consumer',w/'live-scoped-bindings')]:
        env=environ(mode,24,False)
        env['LIVE_BINDING_TRACE_TOKENS']=str(716136 if name=='sqlite' else 2433563)
        pref=s/('trace-'+name+'-'+mode)
        proc=subprocess.run(['python3',s/'replay-gdb.py',tree,pref,'--','--lanes','1',*args],env=env,capture_output=True,timeout=240)
        (s/(pref.name+'.replay.log')).write_bytes(proc.stdout+proc.stderr)
        assert proc.returncode==0,(name,mode,proc.stderr.decode()[-1700:])
        raw=Path(str(pref)+'.events').read_bytes();a=Path(str(pref)+'.answers').read_bytes();elf=Path(str(pref)+'.o').read_bytes()
        got=[len(raw),sha(raw),len(a),sha(a),sha(elf)]
        seen[mode]=got
        wr.writerow([name,mode,*got])
        print(name,mode,*got,flush=True)
    assert seen['prefix-parent']==seen['consumer'],(name,seen)
    print(name,'ordinary matches source pipeline',seen['ordinary']==seen['prefix-parent'],flush=True)
# Matched local instrument-off timing, with one compiler child per observation.
def timed(mode,exe,metric,args,obj):
    command=[exe,'--lanes','1','-c',*args,'-o',obj]
    if metric=='pmu':command=['perf','stat','--no-big-num','-x,','-e','{instructions:u,cycles:u}','--',*command]
    start=time.perf_counter_ns()
    r=subprocess.run(command,capture_output=True,env=environ(mode,24,False),timeout=120)
    wall=(time.perf_counter_ns()-start)/1000000
    assert r.returncode==0,r.stderr
    counters={}
    if metric=='pmu':
        for line in r.stderr.decode().splitlines():
            fields=line.split(',')
            if len(fields)>2 and fields[2] in ('instructions:u','cycles:u'):counters[fields[2]]=int(fields[0])
    return wall,counters.get('instructions:u',''),counters.get('cycles:u','')
arms=[('prefix-parent',parent),('reference',cc),('consumer',cc),('per-use',w/'live-prefix-bindings/build/compiler')]
orders=[[0,1,3,2],[1,2,0,3],[2,3,1,0],[3,0,2,1],[2,3,1,0],[3,0,2,1],[0,1,3,2],[1,2,0,3]]
with (s/'paired.tsv').open('w',buffering=1) as f:
 wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['source','metric','round','position','mode','wall_ms','instructions','cycles'])
 for name,args in workloads.items():
    for metric,n in [('wall',18 if name=='sqlite' else 6),('pmu',12 if name=='sqlite' else 6)]:
        data={}
        for r in range(n):
            for pos,k in enumerate(orders[r%len(orders)]):
                mode,exe=arms[k];row=timed(mode,exe,metric,args,s/'timed.o')
                wr.writerow([name,metric,r,pos,mode,*row]);data[r,mode]=row
        for column,what in ([(0,'wall ms')] if metric=='wall' else [(1,'user instructions'),(2,'user cycles')]):
            for mode,_ in [arms[0],arms[1],arms[3]]:
                delta=[data[r,'consumer'][column]-data[r,mode][column] for r in range(n)]
                print(name,what,'consumer minus',mode,median(delta),sum(x<0 for x in delta),'of',n,flush=True)
