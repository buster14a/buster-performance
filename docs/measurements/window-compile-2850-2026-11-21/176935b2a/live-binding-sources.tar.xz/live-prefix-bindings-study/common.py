from pathlib import Path
import os,re,hashlib,subprocess
s=Path(__file__).resolve().parent;w=s.parent
cc=w/'live-prefix-bindings/build/compiler';parent=w/'live-native-typed/build/compiler';stock=w/'default-integer-control/build/compiler'
sqlite=w/'switch-inputs/sqlite/sqlite3.c';cs=w/'pregraph-warning-study/compiler-source'
workloads={'sqlite':['-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I'+str(sqlite.parent),sqlite],
           'buster':['-march=native','-I'+str(cs/'src'),'-fwrapv','-funsigned-char','--predefines',w/'proof-predefines.h',cs/'src/buster/compiler/main.c']}
# Frozen source checker and parser gates from the prefix-emission control.
toggles='CONTROL_EARLY_RELEASE CONTROL_EARLY_NATIVE SOURCE_ROOT_CURSOR SOURCE_BORROW_CHILDREN SOURCE_FIRST_NODE SOURCE_WRITE_COLUMNS SOURCE_GROW_GRAPH SOURCE_RETIRE_LISTS SOURCE_FILE_DATA SOURCE_CONTROL_MASKS SOURCE_DIRTY_DIAGNOSTICS SOURCE_WARNING_INDEX SOURCE_CLOSE_CONTEXTS SOURCE_CLASS_CONSUMER CONTROL_SOURCE_NATIVE PARSE_LIVE_FOREST LIVE_CHECKED_INPUT'.split()
def environ(mode,window,audit=True):
    env={k:v for k,v in os.environ.items() if not k.startswith('BUSTER_')}
    if mode=='ordinary':return env
    env.update({'BUSTER_'+k:'1' for k in toggles})
    env['BUSTER_PRE_EOF_NATIVE_WINDOW']=str(window)
    if audit:env['BUSTER_PARSE_LIVE_AUDIT']='1'
    if mode in ('reference','consumer'):env['BUSTER_PRE_EOF_BINDINGS']='1'
    if mode=='reference':env['BUSTER_PRE_EOF_BINDING_REFERENCE']='1'
    return env
def semantic(msg):
    return b''.join(line for line in msg.splitlines(keepends=True) if not line.startswith((b'live-',b'pre-eof-',b'control-',b'source-')))
def sha(x):return hashlib.sha256(x).hexdigest()
def compile_call(exe,args,mode,window,audit=True,out='unit.o'):
    out=s/out;out.unlink(missing_ok=True)
    r=subprocess.run([exe,'--lanes','1','-c',*args,'-o',out],env=environ(mode,window,audit),capture_output=True,timeout=120)
    return r.returncode,r.stdout,r.stderr,out.read_bytes() if out.is_file() else b''
def fields(pattern,stderr):
    found=re.search(pattern,stderr,re.M)
    return tuple(map(int,found.groups())) if found else ()
