"""Measure successive true preprocessor checkpoints and the deliberate absence of a reachable checkpoint."""
from common import *
import csv
with (s/'frontiers.tsv').open('w',buffering=1) as f:
 out=csv.writer(f,delimiter='\t',lineterminator='\n')
 out.writerow(['source','window','ready','active_pp_contexts','prefix_tokens','retained','bytes','source_uses','answers','output_sha'])
 for corpus,args in workloads.items():
    want=sha((s/(corpus+'.ordinary.o')).read_bytes())
    choices=(1,4,8,16,24,32,40,1000) if corpus=='sqlite' else (1,8,16,24,40,60,80,1000)
    for win in choices:
        rc,stdout,stderr,elf=compile_call(cc,args,'consumer',win,out='frontier.o')
        assert rc==0 and not semantic(stderr) and sha(elf)==want,(corpus,win,rc,semantic(stderr)[:200])
        match=fields(rb'^pre-eof-bindings-captured\trows=(\d+)\tcontexts=(\d+)\tready=(\d+)\tuses=(\d+)\tbytes=(\d+)',stderr)
        takes=fields(rb'^pre-eof-bindings-consumed\tcaptured=(\d+)\tordinary-source-uses=(\d+)\tfinal-answers=(\d+)',stderr)
        if win==1000:assert not match and not any(takes),(corpus,win,match,takes)
        if takes and takes[1]:assert match and match[1]>0 and match[2]==1 and takes[2]<=takes[1]<=match[3]
        row=[corpus,win,match[2] if match else 0,match[1] if match else 0,match[0] if match else 0,match[3] if match else 0,
             match[4] if match else 0,takes[1] if takes else 0,takes[2] if takes else 0,sha(elf)]
        out.writerow(row);print(*row,flush=True)
