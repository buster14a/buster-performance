from common import *
import csv
d=s/'directed';d.mkdir(exist_ok=True)
checkcases={
'shadow':'int x=n;{int n=3;x+=n;}{double n=4;x+=(int)n;}return x+n;',
'sibling':'int x=n;{int y=x; x+=y;}{long y=x; x+=(int)y;}return x;',
'local-extern':'int x=n;{extern int named; x+=named;}return x+n;',
'local-static':'static int s=2;int x=n;s+=x;return s+x;',
'address':'int x=n,*p=&x;*p+=x;return x+*p;',
'array':'int a[3]={n,2,3};int x=n;return a[x&1]+x;',
'volatile':'volatile int x=n;int y=x++;return x+y;',
'typeof':'int x=n;typeof(x+n) y=x+n;return ((int)y)+x;',
'inference':'int x=n;__auto_type y=(x+n);return y+x;',
'vla':'int x=(n&3)+1;int a[x];a[x-1]=x;return a[x-1]+(int)sizeof a;',
'query':'int x=n,y=n+1;return _Generic((x+y),int:x+y,default:9);',
'intrinsic-shadow':'int _mm_sfence=n; int __builtin_not_a_catalog_function=2;return _mm_sfence+__builtin_not_a_catalog_function;',
'functionpointer':'int (*local)(int)=helper;int x=n;return local(x)+x;',
'prototype':'extern int helper(int);int x=n;return helper(x)+x;',
'label':'int x=n;goto label;label:return x+n;',
'statement-expression':'int x=n;return ({int n=x+1;n+x;})+x;',
'array-compound':'int x=n;int *p=(int[]){x,n,3};return p[0]+x;',
'unsigned':'unsigned long x=n;float f=(float)n;char c=(char)n;return (int)(x+f+c);',
'unused':'int x=n;int set;set=x;int un=n;return x;',
'unknown':'int x=n;return x+misspelled_value;',
'late-typo':'int sample=n;return semple+n;',
'duplicate':'int x=n;long x=n;return (int)x;',
'goto-miss':'int x=n;goto nowhere;return x;',
'bad-type':'struct A{int a;};struct A a={n};int x=n;return a+x;',
'weak-after':'int x=n; return named+x;',
}
late={
    'late-misspelling':'int later(int arg){int sample=arg;return semple+named;}',
    'late-duplicate':'int later(int x){long x;return (int)x;}',
    'late-invalid-object':'extern int named;extern double named;',
    'late-fn-attrs':'extern int callback(int);int call_late(int x){return callback(x);}',
    'late-pragma-rename':'extern int renamed;int later(int x){return renamed+x;}\n#pragma redefine_extname renamed other_symbol\n',
    'late-asm-label':'extern int renamed __asm__("alt_late");int addr(void){return renamed;}',
    'late-query':'int later(int x){__auto_type v=x; typeof(v) another=v;return another;}',
    'late-goto':'int later(int x){goto unknown;return x;}',
    'late-array':'extern int tail[];int tail[]={2,3};int later(int x){return x+tail[1];}',
    'late-macro':'#define LATE(q) ((q)+(q))\nint late(int x){return LATE(x);}',
}
for key in late:checkcases[key]='int local=n+1;{int n=local;local+=n;}return local+named;'
common='extern int named;static int helper(int x){return x+1;}\n'
helpers=''.join('static int earlier_%d(int a,int b){int x=a+b,y=a-b; x+=y; {int a=x; x+=a;} return x+y+b;}\n'%i for i in range(620))
policies={'default':[],'strict':['-Wall','-Wextra','-ferror-limit=0'],'debug':['-g'],'scalar':['--scalar']}
with (s/'directed.tsv').open('w',buffering=1) as log:
 wr=csv.writer(log,delimiter='\t',lineterminator='\n');wr.writerow(['source','policy','status','baseline_matches_parent','parent_matches_reference','reference_matches_consumer','captured','consumed','answers','elf_sha','diagnostics_sha'])
 for name,body in checkcases.items():
    path=d/(name+'.c')
    # Include the directed function in the first closed source window and a late post-EOF suffix.
    path.write_text(common+'static int early(int n){'+body+'}\n'+helpers+'int named=3;int main(void){return early(4)+earlier_619(2,1);}\n'+('#pragma weak named\n' if name=='weak-after' else '')+late.get(name,'')+'\n')
    for policy,opts in policies.items():
        rows=[]
        for mode,exe in [('ordinary',stock),('prefix-parent',parent),('reference',cc),('consumer',cc)]:
            rc,stdout,stderr,elf=compile_call(exe,[*opts,path],mode,1,out='directed/unit.o')
            rows.append((rc,stdout,semantic(stderr),sha(elf)))
            if mode=='consumer':
                capture=fields(rb'^pre-eof-bindings-captured.*?uses=(\d+)\tbytes=(\d+)',stderr)
                takes=fields(rb'^pre-eof-bindings-consumed\tcaptured=(\d+)\tordinary-source-uses=(\d+)\tfinal-answers=(\d+)',stderr)
        exact=[int(rows[i]==rows[i+1]) for i in range(3)]
        wr.writerow([name,policy,rows[-1][0],*exact,capture[0] if capture else 0,takes[1] if takes else 0,takes[2] if takes else 0,rows[-1][-1],sha(rows[-1][2])])
        if not all(exact):
            for mode,row in zip(['ordinary','prefix-parent','reference','consumer'],rows):
                (d/(name+'.'+policy+'.'+mode+'.diag')).write_bytes(row[2])
        assert rows[1]==rows[2]==rows[3],(name,policy,exact)
print(len(checkcases)*len(policies),'four-arm comparisons',flush=True)
