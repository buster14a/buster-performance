from common import *
import csv
with (s/'full.tsv').open('w',buffering=1) as log:
    writer=csv.writer(log,delimiter='\t',lineterminator='\n')
    writer.writerow(['source','mode','window','status','source_contexts','prefix_tokens','retained_rows','retained_bytes','accepted_name_uses','accepted_answers','elf_sha256','diagnostics_sha256'])
    for name,args in workloads.items():
        base=None
        for mode,exe in [('ordinary',stock),('prefix-parent',parent),('reference',cc),('consumer',cc)]:
            window=24
            rc,stdout,stderr,elf=compile_call(exe,args,mode,window,out=name+'.'+mode+'.o')
            (s/(name+'.'+mode+'.stderr')).write_bytes(stderr)
            expected=(rc,stdout,semantic(stderr),sha(elf))
            if base is None:base=expected
            assert expected==base,(name,mode,base[0],rc,base[-1],sha(elf),semantic(stderr)[:260])
            assert rc==0
            got=fields(rb'^pre-eof-bindings-captured\trows=(\d+)\tcontexts=(\d+)\tready=(\d+)\tuses=(\d+)\tbytes=(\d+)',stderr)
            takes=fields(rb'^pre-eof-bindings-consumed\tcaptured=(\d+)\tordinary-source-uses=(\d+)\tfinal-answers=(\d+)',stderr)
            if mode in ('reference','consumer'):assert got and got[2:4][0]==1 and got[1]>0 and got[3]>0,(name,mode,got,stderr[:400])
            if mode=='consumer':assert takes and takes[1] and takes[2],(name,mode,takes)
            row=[name,mode,window,rc,got[1] if got else 0,got[0] if got else 0,got[3] if got else 0,got[4] if got else 0,takes[1] if takes else 0,takes[2] if takes else 0,sha(elf),sha(semantic(stderr))]
            writer.writerow(row);print(*row,flush=True)
