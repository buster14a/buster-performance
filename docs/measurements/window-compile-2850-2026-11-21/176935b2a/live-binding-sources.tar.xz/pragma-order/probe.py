from pathlib import Path
import csv,hashlib,os,subprocess,sys
s=Path(__file__).resolve().parent;w=s.parent
import fcntl
lock=(s/'probe.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX)
if (s/'probe.done').exists():
    import subprocess
    sys.exit(subprocess.run(['bash',s/'verify.sh']).returncode)
sys.path.insert(0,str(w/'live-prefix-bindings-study'))
from common import environ
padded=w/'live-prefix-bindings-study/directed/late-pragma-rename.c'
small=s/'late.c'
small.write_text('extern int renamed;\nint later(int x){return renamed+x;}\n#pragma redefine_extname renamed other_symbol\n')
more={
 'before-declare':'#pragma redefine_extname renamed other_symbol\nextern int renamed;\nint later(void){return renamed;}\n',
 'after-declare':'extern int renamed;\n#pragma redefine_extname renamed other_symbol\nint later(void){return renamed;}\n',
 'after-declare-and-use':'extern int renamed;\nint later(void){return renamed;}\n#pragma redefine_extname renamed other_symbol\nint again(void){return renamed;}\n',
 'before-weak':'extern int renamed;\nint later(void){return renamed;}\n#pragma weak renamed\n',
 'unused-tag':'int extra;\n#pragma redefine_extname absent other_symbol\nint tail;\n'}
for key,text in more.items():(s/(key+'.c')).write_text(text)
clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
stock=w/'default-integer-control/build/compiler';parent=w/'live-native-typed/build/compiler';cc=w/'live-prefix-bindings/build/compiler'
arms=[('clang',clang,'ordinary'),('40ae',stock,'ordinary'),('b769-plain',parent,'ordinary'),('b769-live',parent,'prefix-parent'),('b769-window-only',parent,'window-only'),('b769-forest-only',parent,'forest-only'),('b769-checker-only',parent,'source-checker'),('979-plain',cc,'ordinary'),('979-consume',cc,'consumer')]
trace=s/'objects';trace.mkdir(exist_ok=True)
with (s/'probes.tsv').open('w',buffering=1) as f:
 wr=csv.writer(f,delimiter='\t',lineterminator='\n')
 wr.writerow(['source','policy','mode','rc','rename_symbol','other_symbol','elf_sha','diag_sha'])
 for src in [small,padded,*[s/(x+'.c') for x in more]]:
  for mode,opts in [('default',[]),('strict',['-Wall','-Wextra']),('scalar',['--scalar'])]:
   for label,image,arm in arms:
    if label=='clang' and mode=='scalar':continue
    stem=trace/(src.stem+'.'+mode+'.'+label);out=Path(str(stem)+'.o')
    env=environ(arm,1,False)
    if arm=='window-only':env=environ('ordinary',1);env['BUSTER_PRE_EOF_NATIVE_WINDOW']='1'
    if arm=='forest-only':env=environ('ordinary',1);env['BUSTER_PARSE_LIVE_FOREST']='1'
    if arm=='source-checker':env.pop('BUSTER_PRE_EOF_NATIVE_WINDOW');env.pop('BUSTER_PARSE_LIVE_FOREST')
    flags=['-std=gnu23'] if label=='clang' else ['--lanes','1']
    r=subprocess.run([image,*flags,*opts,'-c',src,'-o',out],env=env,capture_output=True,timeout=40)
    Path(str(stem)+'.stderr').write_bytes(r.stderr)
    elf=out.read_bytes() if out.is_file() else b''
    nm=subprocess.check_output(['nm',out]) if elf else b''
    Path(str(stem)+'.nm').write_bytes(nm)
    syms={line.split()[-1] for line in nm.splitlines() if line.split()}
    wr.writerow([src.stem,mode,label,r.returncode,int(b'renamed' in syms),int(b'other_symbol' in syms),hashlib.sha256(elf).hexdigest(),hashlib.sha256(r.stderr).hexdigest()])

(s/'probe.done').write_text('complete\n')
