import sys,csv,hashlib,os,subprocess
from pathlib import Path
s=Path(__file__).resolve().parent;w=s.parent
sys.path.insert(0,str(w/'live-prefix-bindings-study'))
from common import environ,toggles,semantic
parent=w/'live-native-typed/build/compiler';out=s/'switch.o'
both=s/'permanent.c';both.write_text('extern int renamed, weakened;\nint earlier(void){return renamed+weakened;}\n#pragma redefine_extname renamed other_symbol\n#pragma weak weakened\n')
groups={'ordinary':[],'connected-core':['CONTROL_SOURCE_NATIVE'],'permanent':['CONTROL_SOURCE_NATIVE','CONTROL_EARLY_RELEASE','CONTROL_EARLY_NATIVE'],
'early-release':['CONTROL_SOURCE_NATIVE','CONTROL_EARLY_RELEASE'],'native-encode':['CONTROL_SOURCE_NATIVE','CONTROL_EARLY_NATIVE'],
'compiler-connected':[t for t in toggles if t not in ('PARSE_LIVE_FOREST','LIVE_CHECKED_INPUT')]}
groups.update({'without-'+k:[v for v in groups['compiler-connected'] if v!=k] for k in groups['compiler-connected']})
with (s/'switches.tsv').open('w') as f:
 wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['mode','status','renamed','other_symbol','weakened_binding','elf_sha'])
 for mode,ss in groups.items():
    env=environ('ordinary',1);env.update({'BUSTER_'+k:'1' for k in ss})
    q=subprocess.run([parent,'-c',both,'-o',out],capture_output=True,env=env);assert q.returncode==0,q.stderr
    syms=subprocess.check_output(['readelf','-Ws',out],text=True)
    b={f[-1]:f[4] for line in syms.splitlines() if (f:=line.split()) and len(f)>=8}
    wr.writerow([mode,q.returncode,int('renamed' in b),int('other_symbol'in b),b['weakened'],hashlib.sha256(out.read_bytes()).hexdigest()])
