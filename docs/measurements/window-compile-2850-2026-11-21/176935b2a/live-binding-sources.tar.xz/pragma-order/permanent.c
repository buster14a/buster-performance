extern int renamed, weakened;
int earlier(void){return renamed+weakened;}
#pragma redefine_extname renamed other_symbol
#pragma weak weakened
