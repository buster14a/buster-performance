from pathlib import Path
import sys,csv,os,subprocess,hashlib
s=Path(__file__).resolve().parent;w=s.parent
sys.path.insert(0,str(w/'live-prefix-bindings-study'))
from common import environ,semantic,workloads
fixed=w/'live-symbol-pragma-order/build/compiler';parent=w/'live-native-typed/build/compiler';stock=w/'default-integer-control/build/compiler'
clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
p=s/'checked';p.mkdir(exist_ok=True)
src={
 'both-late':'extern int renamed, weakened;\nint earlier(void){return renamed+weakened;}\n#pragma redefine_extname renamed other_symbol\n#pragma weak weakened\n',
 'both-before':'#pragma redefine_extname renamed other_symbol\n#pragma weak weakened\nextern int renamed,weakened;int f(void){return renamed+weakened;}\n',
 'static-deferred':'extern int renamed,weakened;static int hidden(void){return renamed+weakened;}\n#pragma redefine_extname renamed other_symbol\n#pragma weak weakened\nint use(void){return hidden();}\n',
 'unused-static':'extern int renamed,weakened;static int hidden(void){return renamed+weakened;}\n#pragma redefine_extname renamed other_symbol\n#pragma weak weakened\nint use(void){return renamed+weakened;}\n',
 'deferred-indirect':'extern int renamed,weakened;static int helper(void){return renamed+weakened;}static int outer(void){return helper();}int force(void){return outer();}\n#pragma redefine_extname renamed other_symbol\n#pragma weak weakened\n',
 'late-initializer':'extern int renamed,weakened;int *refs[]={&renamed,&weakened};\n#pragma redefine_extname renamed other_symbol\n#pragma weak weakened\n',
 'unevaluated':'extern int renamed,weakened;int f(void){return sizeof(renamed)+sizeof(weakened);}\n#pragma redefine_extname renamed other_symbol\n#pragma weak weakened\nint later(void){return renamed+weakened;}\n',
 'weak-alias':'int target;\n#pragma weak another = target\nextern int another;int f(void){return another;}\n',
 'local-shadow':'extern int renamed,weakened;int f(void){int renamed=3,weakened=4;return renamed+weakened;}\n#pragma redefine_extname renamed other_symbol\n#pragma weak weakened\nint later(void){return renamed+weakened;}\n',
 'macro-pragma':'extern int renamed,weakened;int earlier(void){return renamed+weakened;}\n_Pragma("redefine_extname renamed other_symbol")\n_Pragma("weak weakened")\n',
}
base_src=(w/'live-prefix-bindings-study/directed/late-pragma-rename.c').read_text()
src['original-padded']=base_src
for f in s.glob('*.c'):src[f.stem]=f.read_text()
cases={'default':[],'strict':['-Wall','-Wextra'],'debug':['-g'],'scalar':['--scalar']}
def h(x):return hashlib.sha256(x).hexdigest()
def symtab(out):
    sym=subprocess.check_output(['readelf','-Ws',out],text=True)
    watch={'renamed','other_symbol','weakened','target','another'}
    return '|'.join(sorted(':'.join([x.split()[-1],x.split()[4],x.split()[6]]) for x in sym.splitlines() if x.split() and x.split()[-1] in watch))
arms=[('clang',clang,'ordinary'),('stock',stock,'ordinary'),('parent-base',parent,'ordinary'),('parent-source',parent,'prefix-parent'),('fixed-base',fixed,'ordinary'),('fixed-source',fixed,'prefix-parent')]
summary=[]
with (s/'fixed.tsv').open('w',buffering=1) as fh:
 wr=csv.writer(fh,delimiter='\t',lineterminator='\n');wr.writerow(['source','policy','mode','status','symbols','elf_sha','diagnostics_sha'])
 for n,source in src.items():
    f=p/(n+'.c');f.write_text(source)
    for pol,flags in cases.items():
        rows={}
        for label,exe,mode in arms:
            if label=='clang' and pol=='scalar':continue
            out=p/(n+'.'+pol+'.'+label+'.o')
            out.unlink(missing_ok=True)
            args=['-std=gnu23'] if label=='clang' else ['--lanes','1']
            q=subprocess.run([exe,*args,*flags,'-c',f,'-o',out],capture_output=True,env=environ(mode,1,False))
            if q.returncode != 0:
                assert label=='parent-source' and n=='weak-alias' and b'Tier 0 failed' in q.stderr,(n,pol,label,q.stderr)
                (p/(n+'.'+pol+'.'+label+'.stderr')).write_bytes(q.stderr)
            sym=symtab(out) if q.returncode==0 else ''
            row=[q.returncode,sym,h(out.read_bytes()) if q.returncode==0 else h(b''),h(semantic(q.stderr))]
            wr.writerow([n,pol,label,*row]);rows[label]=row
        assert rows['fixed-source']==rows['fixed-base']==rows['parent-base']==rows['stock'],(n,pol,rows)
        if 'clang' in rows:
            # The independently implemented compiler emits a different section index for defined symbols.
            def names(r):return [':'.join(e.split(':')[:2]+[('UND' if e.endswith(':UND') else 'defined')]) for e in r[1].split('|') if e]
            assert names(rows['clang'])==names(rows['fixed-source']),(n,pol,rows)
        summary.append((n,pol,rows['parent-source']!=rows['fixed-source']))
print('focused:',len(summary),'cases; inherited different outputs:',sum(x[2] for x in summary),flush=True)
with (s/'fixed-full.tsv').open('w',buffering=1) as fh:
 wr=csv.writer(fh,delimiter='\t',lineterminator='\n');wr.writerow(['workload','mode','status','elf_sha','diagnostics_sha'])
 for name,srcargs in workloads.items():
    want=None
    for label,exe,mode in arms[1:]:
        out=p/('full-'+name+'.o')
        q=subprocess.run([exe,'--lanes','1','-c',*srcargs,'-o',out],capture_output=True,env=environ(mode,24,False),timeout=120)
        assert q.returncode==0,(name,label,q.stderr[:300])
        row=[q.returncode,h(out.read_bytes()),h(semantic(q.stderr))]
        wr.writerow([name,label,*row])
        if want is None:want=row
        assert row==want,(name,label,row,want)
print('two complete native corpora passed in five arms',flush=True)
