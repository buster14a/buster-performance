#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
top=$PWD
g=$1
source corpora.sh
main_arguments="-march=native -I$top/pooled-main-source/src -fwrapv -funsigned-char --predefines $top/proof-predefines.h $top/pooled-main-source/src/buster/compiler/main.c"
v=${g}_arguments; eval "args=(${!v})"
base=results/factsmain0e1d/compiler
bin=results/allb352/compiler
d=results/allb352-individual/$g
mkdir -p "$d"
for b in base bin;do ./lock.sh bash capture2850.sh "$d/$b.stdout" "$d/$b.stderr" taskset -c 2 "${!b}" --lanes 1 -c "${args[@]}" -o "$d/$b.o";done
cmp "$d/base.o" "$d/bin.o";cmp "$d/base.stderr" "$d/bin.stderr";cmp "$d/base.stdout" "$d/bin.stdout"
sha256sum "$d/base.o" "$d/bin.o" >"$d/objects.tsv"
./lock.sh bash capture2850.sh "$d/source.stdout" "$d/source.stderr" taskset -c 2 env BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_SOURCE_AUDIT=1 "$bin" --lanes 1 -c "${args[@]}" -o "$d/source.o"
cmp "$d/bin.o" "$d/source.o"
for r in 1 2 3 4 5;do
 if ((r%2));then order=(dense batch batch dense);else order=(batch dense dense batch);fi
 for i in 0 1 2 3;do mode=${order[i]}
  if [[ $mode == dense ]];then marks=();else marks=(BUSTER_CONTROL_SOURCE_NATIVE=1);fi
  stem=$d/$g-1024-$r-$i-$mode
  ./lock.sh bash capture2850.sh "$stem.stdout" "$stem.stderr" taskset -c 2 python3 allb352-time.py "$stem.time" env  "${marks[@]}" "$bin" --lanes 1 -c "${args[@]}" -o "$d/$mode.o"
  if ((r<=3));then
   ./lock.sh bash capture2850.sh "$stem.pmu.stdout" "$stem.pmu.stderr" taskset -c 2 perf stat -x ';' -e cycles,cycles:u,instructions:u,minor-faults -o "$stem.pmu" -- env  "${marks[@]}" "$bin" --lanes 1 -c "${args[@]}" -o "$d/$mode.o"
  fi
 done
done

for arm in dense batch; do cmp "$d/$arm.o" "$d/bin.o"; done
