#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
top=$PWD
source corpora.sh
eval "args=($sqlite_arguments)"
bin=results/resident3c81/compiler
d=results/resident3c81-profiles
mkdir -p "$d"
for mode in ordinary source; do
 marks=()
 if [[ $mode == source ]]; then
  marks=(BUSTER_SOURCE_BORROW_CHILDREN=1 BUSTER_SOURCE_FIRST_NODE=1 BUSTER_CONTROL_EARLY_RELEASE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_SOURCE_WRITE_COLUMNS=1 BUSTER_SOURCE_FILE_DATA=1 BUSTER_SOURCE_GROW_GRAPH=1 BUSTER_SOURCE_RETIRE_LISTS=1 BUSTER_CONTROL_SOURCE_NATIVE=1)
 fi
 ./lock.sh bash capture2850.sh "$d/$mode.stages.stdout" "$d/$mode.stages.stderr" taskset -c 2 env "${marks[@]}" "$bin" --lanes 1 --time-stages -c "${args[@]}" -o "$d/$mode.o"
 for event in instructions cycles; do
  stem=$d/$mode.$event
  ./lock.sh bash capture2850.sh "$stem.stdout" "$stem.stderr" taskset -c 2 perf record -q -c 37003 -e "$event:u" -o "$stem.data" -- env "${marks[@]}" "$bin" --lanes 1 -c "${args[@]}" -o "$d/$mode.o"
  ./lock.sh bash capture2850.sh "$stem.symbols" "$stem.report.stderr" taskset -c 2 perf report -i "$stem.data" --stdio --no-children -F overhead,sample,symbol
  ./lock.sh bash capture2850.sh "$stem.ips" "$stem.script.stderr" taskset -c 2 perf script -i "$stem.data" -F ip,sym,symoff
 done
done
cmp "$d/ordinary.o" "$d/source.o"
cmp "$d/source.o" results/resident3c81-individual/sqlite/base.o
sha256sum "$d/"{ordinary,source}.o >"$d/objects.tsv"
echo COMPLETE
