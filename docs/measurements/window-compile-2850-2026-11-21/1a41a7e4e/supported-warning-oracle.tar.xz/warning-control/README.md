# Directed source warnings

The earlier directed suite recorded 387 identical command-line rejections for the unsupported composite option `-Wconversion`. This supplement checks each of those sources with supported `-Wall -Wextra -ferror-limit=0`. All 387 paired source invocations matched in exit status, standard streams and complete emitted bytes. The separately retained severe and frozen warning policies already exercised the source checker.

Run `python3 replay.py /path/to/reference/compiler /path/to/candidate/compiler` after unpacking. The exact original outputs depend on the diagnostic source path. The script compares both compilers at the same source path. `results.tsv` records the measured hashes and compiler statuses. `revisions.tsv` records compiled sources and images on the Ryzen 9 7940HS.
