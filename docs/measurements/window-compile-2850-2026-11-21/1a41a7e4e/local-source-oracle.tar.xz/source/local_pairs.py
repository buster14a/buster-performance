from pathlib import Path
import csv,random,statistics,time,subprocess as sp,sys,hashlib
w=Path(__file__).resolve().parent.parent;d=w/'direct-declaration-study';base=w/'main-fbef-clean/build/compiler';new=w/'direct-declaration-records/build/compiler';sqlite=w/'switch-inputs/sqlite/sqlite3.c';args=['-c','-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I'+str(sqlite.parent),sqlite,'-o',d/'timed.o'];order=random.Random(2850);data=[]
for label,cmd in [('base',base),('candidate',new)]:
 r=sp.run([cmd,'--time-stages',*args],capture_output=True,timeout=60);assert r.returncode==0,r.stderr;(d/f'{label}.stages').write_bytes(r.stderr);(d/f'{label}.stages.out').write_bytes(r.stdout)
with (d/'local-ab.tsv').open('w',buffering=1) as s:
 out=csv.writer(s,delimiter='\t');out.writerow(['pair','order','base_ms','candidate_ms','delta_ms']);
 for i in range(36):
  runs=[('base',base),('candidate',new)];order.shuffle(runs);ms={}
  for label,cc in runs:
   start=time.perf_counter_ns();r=sp.run([cc,*args],capture_output=True,timeout=60);ms[label]=(time.perf_counter_ns()-start)/1e6;assert r.returncode==0,r.stderr
  data.append((ms['base'],ms['candidate']));out.writerow([i,','.join(n for n,_ in runs),ms['base'],ms['candidate'],ms['candidate']-ms['base']]);
 a,b=zip(*data);print('BASE',statistics.median(a),'CAND',statistics.median(b),'PAIR',statistics.median(y-x for x,y in data),'wins',sum(y<x for x,y in data),'n',len(data),flush=True)
import re
from collections import defaultdict
with (d/'sqlite-stage-pairs.tsv').open('w',buffering=1) as s:
 out=csv.writer(s,delimiter='\t');out.writerow(['pair','stage','base_ms','candidate_ms','delta_ms']);stages=defaultdict(list)
 for i in range(24):
  runs=[('base',base),('candidate',new)];order.shuffle(runs);timings={}
  for label,cc in runs:
   r=sp.run([cc,'--time-stages',*args],capture_output=True,timeout=60);assert r.returncode==0,r.stderr;timings[label]={m[1].decode():float(m[2]) for m in re.finditer(rb'^time-stage\t([^\t]+)\t([0-9.]+)',r.stderr,re.M)}
  for k in ['check-input','check-declarations','total']:
   if k not in timings['base']:continue
   a=timings['base'][k];b=timings['candidate'][k];out.writerow([i,k,a,b,b-a]);stages[k].append(b-a)
 for k,ds in stages.items():print('stage',k,'n',len(ds),'med delta',statistics.median(ds),'wins',sum(x<0 for x in ds),flush=True)
