import csv,os,re,subprocess,sys,tempfile
from pathlib import Path
out=Path(sys.argv[1]);group=sys.argv[2];compiler=Path(sys.argv[3]);flags=[];files=[];take_next=False
for v in sys.argv[4:]:
 if v.endswith('.c') and not take_next:files.append(v)
 else:flags.append(v)
 take_next=v in ('--predefines','-I','-isystem','-include')
rx=re.compile(rb'^named-declarations definitions=(\d+)/(\d+) locals=(\d+)/(\d+) definition-parameters=(\d+)/(\d+) prototype-parameters=(\d+)/(\d+) derived=(\d+)$',re.M)
assert files
with (out/f'single-{group}.tsv').open('w') as f,tempfile.TemporaryDirectory() as tmp:
 w=csv.writer(f,delimiter='\t');w.writerow(['source','status','unit-reported','definitions','definition-tokens','locals','local-tokens','definition-params','definition-param-tokens','prototype-params','prototype-param-tokens','derived','total-declarations','total-tokens']);obj=Path(tmp)/'census.o'
 for file in files:
  res=subprocess.run([compiler,'-c',*flags,file,'-o',obj],capture_output=True,env=dict(os.environ,BUSTER_DECLARATION_CENSUS='1'),timeout=90);m=rx.findall(res.stderr);assert res.returncode==0,(file,res.stderr[:150]);assert len(m)<=1;v=list(map(int,m[0])) if m else [0]*9
  w.writerow([file,res.returncode,len(m),*v,sum(v[:8:2]),sum(v[1:8:2])])
