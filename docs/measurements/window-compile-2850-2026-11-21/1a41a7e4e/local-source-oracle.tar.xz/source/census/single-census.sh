#!/bin/bash
set -eu
cd "$(dirname "$0")/../switch-inputs"
w=$(cd .. && pwd)
s="$w/direct-declaration-study"
d="$s/census"
mkdir -p "$d"
source "$w/switch-local-args.sh"
tree="$w/pregraph-warning-study/compiler-source"
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $w/proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main lua musl; do
 var=${g}_arguments;eval "args=(${!var})"
 python3 "$s/single-census.py" "$d" "$g" "$w/direct-declaration-records/build/compiler" "${args[@]}"
done
python3 - "$d" <<'PY'
from pathlib import Path
import csv,sys
d=Path(sys.argv[1])
with (d/'single-admissions.tsv').open('w') as f:
 writer=csv.writer(f,delimiter='\t');cols=None
 for name in ['sqlite','main','lua','musl']:
  with (d/f'single-{name}.tsv').open() as src:
   r=csv.DictReader(src,delimiter='\t')
   if cols is None:cols=r.fieldnames[2:];writer.writerow(['corpus','units',*cols])
   rows=list(r);writer.writerow([name,len(rows),*(sum(int(row[k]) for row in rows) for k in cols)])
PY

bash "$s/census-off.sh"
