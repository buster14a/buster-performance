set debuginfod enabled off
set pagination off
set print thread-events off
break *check_input_run
commands
silent
printf "check_input_run fresh=%d complete=%d deferred=%p mask=%p attested=%p\n", *(char*)($rsp+64),*(char*)($rsp+8),*(void**)($rsp+40),*(void**)($rsp+24),*(void**)($rsp+72)
bt 5
continue
end
run
