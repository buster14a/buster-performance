int f(int p){int x=p;return x+1;}
