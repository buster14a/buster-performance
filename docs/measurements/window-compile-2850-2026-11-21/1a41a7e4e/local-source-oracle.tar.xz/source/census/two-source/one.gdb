Breakpoint 1 at 0xf51d90: file /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_check_input.c, line 17315.
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/usr/lib/libthread_db.so.1".
check_input_run fresh=1 complete=1 deferred=(nil) mask=(nil) attested=(nil)
#0  check_input_run () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_check_input.c:17315
#1  0x0000000000f9f25b in check_driver_unit () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_checker_driver.c:12746
#2  0x0000000000f943c3 in check_driver_one_unit () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_checker_driver.c:13988
#3  check_driver_flow () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_checker_driver.c:14083
#4  0x0000000000e5c7ec in lane_session_run () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/lane.c:3388
[Inferior 1 (process 1412806) exited normally]
