int g(int p){int x=p;return x-1;}
