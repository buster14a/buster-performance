Breakpoint 1 at 0xf51d90: file /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_check_input.c, line 17315.
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/usr/lib/libthread_db.so.1".
check_input_run fresh=1 complete=1 deferred=(nil) mask=(nil) attested=0x9024080
#0  check_input_run () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_check_input.c:17315
#1  0x00000000011a47e6 in check_attested_read () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_check_attested.c:3230
#2  0x0000000000f9f170 in check_driver_unit () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_checker_driver.c:12735
#3  0x00000000012d1c23 in check_units_compile () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_checker_units.c:2326
#4  0x00000000012d0bd8 in check_units_lane () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_checker_units.c:2481
check_input_run fresh=1 complete=1 deferred=(nil) mask=(nil) attested=0x9024080
#0  check_input_run () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_check_input.c:17315
#1  0x00000000011a47e6 in check_attested_read () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_check_attested.c:3230
#2  0x0000000000f9f170 in check_driver_unit () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_checker_driver.c:12735
#3  0x00000000012d1c23 in check_units_compile () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_checker_units.c:2326
#4  0x00000000012d0bd8 in check_units_lane () at /home/david/Documents/Codex/2026-11-21/g/work/direct-declaration-records/src/buster/compiler/c_checker_units.c:2481
[Inferior 1 (process 1412565) exited normally]
