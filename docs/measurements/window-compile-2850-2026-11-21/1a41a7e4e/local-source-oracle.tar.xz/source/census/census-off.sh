#!/bin/bash
set -eu
cd "$(dirname "$0")/../switch-inputs"
w=$(cd .. && pwd)
d="$w/direct-declaration-study/census/group-attested-off"
mkdir -p "$d"
source "$w/switch-local-args.sh"
tree="$w/pregraph-warning-study/compiler-source"
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $w/proof-predefines.h $tree/src/buster/compiler/main.c"
scratch=$(mktemp -d)
trap 'rm -f -- "$scratch"/*.o; rmdir "$scratch"' EXIT
cd "$scratch"
for g in sqlite main lua musl; do
 var=${g}_arguments
 eval "args=(${!var})"
 BUSTER_DECLARATION_CENSUS=1 "$w/direct-declaration-records/build/compiler" --attested=off --lanes 1 -c "${args[@]}" > "$d/$g.stdout" 2> "$d/$g.stderr"
 rm -f -- "$scratch"/*.o
done
python3 - "$d" <<'PY'
import sys,re,csv
from pathlib import Path
d=Path(sys.argv[1]);rx=re.compile(r'^named-declarations definitions=(\d+)/(\d+) locals=(\d+)/(\d+) definition-parameters=(\d+)/(\d+) prototype-parameters=(\d+)/(\d+) derived=(\d+)$',re.M)
with (d/'admissions.tsv').open('w') as out:
 w=csv.writer(out,delimiter='\t');w.writerow(['corpus','units-reporting','definitions','definition-tokens','locals','local-tokens','definition-params','definition-param-tokens','prototype-params','prototype-param-tokens','derived','total-declarations','total-tokens'])
 for corpus in ['sqlite','main','lua','musl']:
  rows=rx.findall((d/(corpus+'.stderr')).read_text()); totals=[sum(int(r[i]) for r in rows) for i in range(9)]
  w.writerow([corpus,len(rows),*totals,sum(totals[:8:2]),sum(totals[1:8:2])])
PY
