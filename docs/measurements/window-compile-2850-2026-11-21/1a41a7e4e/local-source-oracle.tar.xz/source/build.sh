#!/bin/bash
set -eu
cd "$(dirname "$0")/../direct-declaration-records"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >../direct-declaration-study/build.log 2>&1
cp ../main-fbef-clean/build/predefines.h build/predefines.h
cd ../switch-inputs
source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
BUSTER_DECLARATION_CENSUS=1 ../direct-declaration-records/build/compiler -c -o ../direct-declaration-study/sqlite.candidate.o "${args[@]}" >../direct-declaration-study/sqlite.out 2>../direct-declaration-study/counter.txt
../main-fbef-clean/build/compiler -c -o ../direct-declaration-study/sqlite.parent.o "${args[@]}" >../direct-declaration-study/parent.out 2>../direct-declaration-study/parent.err
cmp ../direct-declaration-study/sqlite.candidate.o ../direct-declaration-study/sqlite.parent.o
python3 ../direct-declaration-study/oracle.py >../direct-declaration-study/oracle.log 2>&1
python3 ../direct-declaration-study/local_pairs.py >../direct-declaration-study/pairs.log 2>&1
python3 ../direct-declaration-study/target_pairs.py >../direct-declaration-study/target.log 2>&1
parent=$PWD/../main-fbef-clean/build/compiler
new=$PWD/../direct-declaration-records/build/compiler
out=$PWD/../direct-declaration-study/corpus
mkdir -p "$out"
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main lua musl; do var=${g}_arguments; eval "args=(${!var})"; python3 ../default-object-qa/pair.py "$out" "$g" "$parent" "$new" "${args[@]}"; done
python3 ../direct-declaration-study/pmu.py >../direct-declaration-study/pmu.log 2>&1
cd ../direct-declaration-records
for part in {1..8}; do ./build/compiler test-checker --seed 2850 --part "$part/8" >"../direct-declaration-study/checker-$part.log" 2>&1; done
