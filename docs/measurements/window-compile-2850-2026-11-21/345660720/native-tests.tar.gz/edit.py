from pathlib import Path
d=Path(__file__).resolve().parent.parent/'source-literal-records/src/buster/compiler'
p=d/'c_check_input.c';s=p.read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
anchor='typedef struct CheckInputReader CheckInputReader;'
rep(anchor,'''typedef struct CheckSourceLiteralBlock
{
    uint64_t mask;
    const uint32_t* values;
} CheckSourceLiteralBlock;

typedef struct CheckSourceLiterals
{
    CheckSourceLiteralBlock* blocks;
    uint32_t covered, produced, before_eof, read, slow;
    bool audit, oracle;
} CheckSourceLiterals;

'''+anchor)
rep('    uint8_t* expression_commas;', '    uint8_t* expression_commas;\n    CheckSourceLiterals* source_literals;')
rep('    bool used, failed, keep_boundaries, preparation;', '''    CheckSourceLiterals literals;
    bool literal_records;
    bool used, failed, keep_boundaries, preparation;''')
rep('        live->owner = parser;', '''        if (live->literal_records)
            live->literals.blocks = BUSTER_ARENA_PUSH_ARRAY(&parser->live_rows, CheckSourceLiteralBlock, ((uint64_t)tokens->capacity >> 6) + 1);
        live->owner = parser;''')
rep('    CheckInputTokenCounts* counts = &live->counts;', '''    if (live->literals.blocks && !check_input_publish_literals(&parser->live_rows, &live->literals, tokens, pp, end))
        live->literals.blocks = NULL;
    CheckInputTokenCounts* counts = &live->counts;''')
rep('        .grow_on_first_node = first_node,','''        .source_literals = published && live->literals.blocks ? &live->literals : NULL,
        .grow_on_first_node = first_node,''')
rep('        // Where the reader ended early, its recovered reports are still the unit\'s.', '''        if (reader.source_literals && reader.source_literals->audit)
            fprintf(stderr, "source-literals\\tcovered=%u\\tproduced=%u\\tbefore-eof=%u\\tconsumed=%u\\tfallback=%u\\n",
                    live->literals.covered, live->literals.produced, live->literals.before_eof, live->literals.read, live->literals.slow);
        // Where the reader ended early, its recovered reports are still the unit's.''')
p.write_text(s)
p=d/'c_checker_driver.c';s=p.read_text()
rep('.preparation = getenv("BUSTER_LIVE_PREPARE_DECLARATIONS") != NULL }','''.preparation = getenv("BUSTER_LIVE_PREPARE_DECLARATIONS") != NULL,
                        .literal_records = getenv("BUSTER_LIVE_LITERAL_RECORDS") != NULL,
                        .literals = { .audit = getenv("BUSTER_PARSE_LIVE_AUDIT") != NULL,
                                      .oracle = getenv("BUSTER_LIVE_CHECKED_ORACLE") != NULL } }''');p.write_text(s)
p=d/'c_check_attested_test.c';s=p.read_text();pos='    { "expression_commas",'
assert s.count(pos)==1
s=s.replace(pos,'    { "source_literals", CHECK_ATTESTED_FIELD_TRANSIENT },\n'+pos);p.write_text(s)
p=d/'c_check_expression_input.c';s=p.read_text()
a=s.index('static uint32_t check_input_literal_plain(');b=s.index('// The spellings of four tokens',a)
v=s[a:b].replace('const CheckInputReader* reader','const ParseTokens* tokens, const Preprocessor* pp').replace('    const Parser* parser = reader->parser;\n    const Preprocessor* pp = reader->pp;\n','').replace('&parser->tokens','tokens').replace('parser->tokens.','tokens->')
s=s[:a]+v+s[b:]
a=s.index('static uint32_t check_input_expression_literals(');b=s.index('\n}',a)+2
v=s[a:b].replace('check_input_expression_literals(const CheckInputReader* reader','check_input_decode_literals(const ParseTokens* input, const Preprocessor* pp').replace('    const Parser* parser = reader->parser;\n    const Preprocessor* pp = reader->pp;\n','').replace('&parser->tokens','input').replace('parser->tokens.','input->').replace('check_input_literal_plain(reader,','check_input_literal_plain(input, pp,')
assert 'reader' not in v
v+='''
// Pack complete physical token blocks. The next window owns a partial block left by its predecessor.
// Character and non-decimal spellings retain the ordinary slow-path marker.
static bool check_input_publish_literals(Arena* arena, CheckSourceLiterals* published, const ParseTokens* input, Preprocessor* pp, uint32_t end)
{
    const uint32_t literal = BUSTER_CHECK_EXPRESSION_ACTS | CHECK_INPUT_CODE_LITERAL << BUSTER_CHECK_EXPRESSION_CODE_SHIFT;
    uint32_t tokens[64], classes[64];
    CheckInputLiterals decoded;
    for (uint32_t at = published->covered; end - at >= 64; at += 64)
    {
        const __m512i kinds = _mm512_loadu_si512(input->kinds + at);
        const uint64_t mask = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PARSE_KIND_NUMBER)) |
                              _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PARSE_KIND_CHARACTER));
        const uint32_t n = (uint32_t)__builtin_popcountll(mask);
        uint32_t* values = n ? BUSTER_ARENA_PUSH_ARRAY(arena, uint32_t, n) : NULL;
        if (n && !values) return false;
        published->blocks[at >> 6] = (CheckSourceLiteralBlock){ .mask = mask, .values = values };
        if (n)
        {
            uint32_t j = 0;
            for (uint64_t bits = mask; bits; bits &= bits - 1)
            {
                tokens[j] = at + (uint32_t)__builtin_ctzll(bits);
                classes[j++] = literal;
            }
            check_input_decode_literals(input, pp, tokens, classes, n, &decoded);
            memcpy(values, decoded.values, (size_t)n * sizeof(*values));
            published->produced += n;
        }
        published->covered = at + 64;
    }
    if (pp->context_count) published->before_eof = published->produced;
    return true;
}

static uint32_t check_input_expression_literals(const CheckInputReader* reader, const uint32_t* tokens, const uint32_t* classes, uint32_t acting,
                                               CheckInputLiterals* literals)
{
    CheckSourceLiterals* source = reader->source_literals;
    const ParseTokens* input = &reader->parser->tokens;
    if (!source) return check_input_decode_literals(input, reader->pp, tokens, classes, acting, literals);
    const uint32_t literal = BUSTER_CHECK_EXPRESSION_ACTS | CHECK_INPUT_CODE_LITERAL << BUSTER_CHECK_EXPRESSION_CODE_SHIFT;
    uint32_t found = 0, supplied = 0, cursor = BUSTER_PP_NONE;
    for (uint32_t at = 0; at < acting; at += 16)
    {
        const __mmask16 lanes = (__mmask16)_bzhi_u32(UINT32_MAX, acting - at < 16 ? acting - at : 16);
        uint32_t bits = _mm512_mask_cmpeq_epi32_mask(lanes, _mm512_maskz_loadu_epi32(lanes, classes + at), _mm512_set1_epi32((int32_t)literal));
        for (; bits; bits &= bits - 1)
        {
            const uint32_t token = tokens[at + (uint32_t)__builtin_ctz(bits)];
            const CheckSourceLiteralBlock* block = token < source->covered ? source->blocks + (token >> 6) : NULL;
            const uint64_t bit = UINT64_C(1) << (token & 63);
            const bool known = block && (block->mask & bit);
            const uint32_t value = known ? block->values[__builtin_popcountll(block->mask & (bit - 1))] :
                                           check_input_literal_plain(input, reader->pp, token, &cursor);
            if (source->oracle && value != check_input_literal_plain(input, reader->pp, token, &cursor)) abort();
            literals->values[found++] = value;
            supplied += known;
        }
    }
    if (source->audit) { source->read += supplied; source->slow += found - supplied; }
    return found;
}
'''
s=s[:a]+v+s[b:];p.write_text(s)
