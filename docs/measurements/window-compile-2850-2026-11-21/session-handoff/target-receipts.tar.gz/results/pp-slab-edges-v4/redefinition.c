#include "api.h"
#undef NEXT
#define NEXT(v) ((v)+9)
struct Record { long q; }; int f(struct Record *p){return NEXT(p->q);}
