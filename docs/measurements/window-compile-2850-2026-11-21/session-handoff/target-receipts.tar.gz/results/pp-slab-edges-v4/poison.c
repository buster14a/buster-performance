#pragma GCC poison forbidden
int f(void){int forbidden=1;return forbidden;}
