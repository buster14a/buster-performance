int caf\u00e9; int f(void){return caf\u00e9;}
