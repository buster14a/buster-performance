%:define A 7
int f(void)<%return A;%>
