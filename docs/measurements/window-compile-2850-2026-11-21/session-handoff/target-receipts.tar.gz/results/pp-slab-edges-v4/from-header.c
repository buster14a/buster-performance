#include "api.h"
int t(int a){return REG(a).q + NEXT(a);}
