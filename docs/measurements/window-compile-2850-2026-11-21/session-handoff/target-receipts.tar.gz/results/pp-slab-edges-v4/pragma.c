#pragma pack(push,1)
struct p{char a;int b;};
#pragma pack(pop)
int t(void){return sizeof(struct p);}
