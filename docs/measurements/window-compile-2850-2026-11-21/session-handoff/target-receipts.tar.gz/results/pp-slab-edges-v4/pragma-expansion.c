#define P(x) _Pragma(#x)
P(pack(push,1))
struct p {char a;int b;};
P(pack(pop))
int t(void){return sizeof(struct p);}
