#define S(x) #x
#define P(a,b) a##b
int P(ab,cd); const char *p=S(ab cd);
