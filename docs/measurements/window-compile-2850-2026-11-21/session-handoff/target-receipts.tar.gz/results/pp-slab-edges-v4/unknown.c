#include "api.h"
#line 31 "mapped-source.c"
int f(struct H *p){return p->missing;}
