#define SUM(x,y) ((x) \
+(y))
int f(void){return SUM(3,4);}
