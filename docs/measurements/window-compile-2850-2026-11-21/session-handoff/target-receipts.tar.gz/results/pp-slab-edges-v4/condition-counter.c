#define S(x) (x)
int pre=__COUNTER__;
#if __COUNTER__==1
int f(void){return S(__COUNTER__);}
#endif
