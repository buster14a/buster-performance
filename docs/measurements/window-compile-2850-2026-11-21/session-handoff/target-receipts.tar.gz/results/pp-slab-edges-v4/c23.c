[[maybe_unused]] static int a;
int f(void){return 42;}
