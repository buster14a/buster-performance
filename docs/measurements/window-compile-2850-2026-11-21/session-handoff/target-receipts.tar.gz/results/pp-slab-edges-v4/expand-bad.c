#define X(y) (*(y))
int f(void){return X(1);}
