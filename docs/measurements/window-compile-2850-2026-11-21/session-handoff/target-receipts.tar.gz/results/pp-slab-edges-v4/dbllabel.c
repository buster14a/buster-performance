int f(int x){asm volatile("" :: "r" (x));return x;}
