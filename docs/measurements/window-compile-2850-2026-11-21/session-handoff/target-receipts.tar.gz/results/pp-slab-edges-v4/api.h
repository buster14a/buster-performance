#pragma once
#define NEXT(v) ((v)+3)
struct H { int q; };
#define REG(x) ((struct H){.q=(x)})
