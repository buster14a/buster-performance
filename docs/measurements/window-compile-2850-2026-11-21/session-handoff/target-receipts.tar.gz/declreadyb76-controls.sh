#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2
label=declreadyb76
test -s results/$label/.built
for corpus in main lua musl; do
 bash "$label.sh" "$label" "$corpus" 1 7
done
echo ALL_CONTROLS_COMPLETE
