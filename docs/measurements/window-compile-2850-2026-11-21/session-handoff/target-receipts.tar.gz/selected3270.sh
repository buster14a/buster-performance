#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
top=$PWD
base=results/main40ae/compiler
head=results/selected3270/compiler
test "$(head -1 results/main40ae/revision.txt)" = 40ae34f9d77afc42face58eff3338b7b1d1ba469
if [[ ! -f results/selected3270/.built ]];then bash build-label.sh selected3270 6835c375c10f530689e104c67e014caa0a999597;fi
test "$(head -1 results/selected3270/revision.txt)" = 6835c375c10f530689e104c67e014caa0a999597
source corpora.sh
main_arguments="-march=native -I$top/pooled-main-source/src -fwrapv -funsigned-char --predefines $top/proof-predefines.h $top/pooled-main-source/src/buster/compiler/main.c"
for u in sqlite main;do
 d=results/selected3270-paired/$u;mkdir -p "$d"
 key=${u}_arguments;eval "args=(${!key})"
 for arm in base head;do
  ./lock.sh bash capture2850.sh "$d/$arm.stdout" "$d/$arm.stderr" taskset -c 2 "${!arm}" --lanes 1 -c "${args[@]}" -o "$d/$arm.o"
 done
 cmp "$d/base.o" "$d/head.o";cmp "$d/base.stderr" "$d/head.stderr";cmp "$d/base.stdout" "$d/head.stdout"
 sha256sum "$d/base.o" "$d/head.o" > "$d/objects.tsv"
 for round in 1 2 3 4 5;do
  if ((round%2));then order=(base head head base);else order=(head base base head);fi
  for p in 0 1 2 3;do arm=${order[p]};stem=$d/wall-$round-$p-$arm
   ./lock.sh bash capture2850.sh "$stem.stdout" "$stem.stderr" taskset -c 2 python3 source966a-time.py "$stem.json" "${!arm}" --lanes 1 -c "${args[@]}" -o "$d/timed.o"
   cmp "$d/timed.o" "$d/base.o";cmp "$stem.stdout" "$d/base.stdout";cmp "$stem.stderr" "$d/base.stderr"
  done
 done
 for round in 1 2 3;do
  if ((round%2));then order=(head base);else order=(base head);fi
  for arm in "${order[@]}";do stem=$d/pmu-$round-$arm
   ./lock.sh bash capture2850.sh "$stem.stdout" "$stem.stderr" taskset -c 2 perf stat --no-big-num -x ';' -e cycles,cycles:u,instructions:u,minor-faults -o "$stem.stat" -- "${!arm}" --lanes 1 -c "${args[@]}" -o "$d/timed.o"
   cmp "$d/timed.o" "$d/base.o";cmp "$stem.stdout" "$d/base.stdout";cmp "$stem.stderr" "$d/base.stderr"
  done
 done
 date -u +%FT%TZ >"$d/complete"
done
