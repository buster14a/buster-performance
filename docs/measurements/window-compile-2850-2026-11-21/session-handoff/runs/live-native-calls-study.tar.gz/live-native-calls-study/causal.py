from pathlib import Path
import subprocess,struct,csv,os,sys,hashlib
d=Path(__file__).resolve().parent;w=d.parent;p=w/'live-native-calls-poison';f=p/'src/buster/compiler/c_check_live_native.c';s=subprocess.check_output(['git','show','HEAD:src/buster/compiler/c_check_live_native.c'],cwd=p,text=True)
key='            tbl->plans[tbl->count++] = plan;'
s=s.replace(key,'''            if (getenv("BUSTER_LIVE_TEST_SWAP_CALLEES") && open==158189 && plan.encoded->reference_count==2) {
                LinkReference* fields=(LinkReference*)plan.encoded->references;
                if(fields[0].target!=1 || fields[1].target!=2 || fields[0].instruction!=11 || fields[1].instruction!=26) abort();
                fields[0].target=2;
                fields[1].target=1;
            }
            if (scratch.peak) memset(scratch.base,0xbd,(size_t)scratch.peak);
'''+key)
f.write_text(s);(d/'causal.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=p));(d/'build-causal.py').write_text((d/'iterate.py').read_text().replace("../live-native-calls'","../live-native-calls-poison'").replace("'probe.o'","'causal.o'").replace("exe=d/'compiler'","exe=d/'causal-compiler'"));subprocess.run(['python',d/'build-causal.py'],check=True)
src=w/'switch-inputs';args=[os.fsdecode(v) for v in subprocess.check_output(['bash','-c','source ../switch-local-args.sh; eval "args=($sqlite_arguments)"; printf "%s\\0" "${args[@]}"'],cwd=src).split(b'\0')[:-1]]
env=os.environ|dict(BUSTER_PARSE_LIVE_FOREST='1',BUSTER_LIVE_CHECKED_INPUT='1',BUSTER_LIVE_NATIVE_PROGRAMS='1',BUSTER_LIVE_OWN_PROGRAMS='1',BUSTER_CONTROL_SOURCE_AUDIT='1',BUSTER_PARSE_LIVE_AUDIT='1')
# Let Clang lay out the exact source structures in the frozen compilation. Only the tiny function containing sizeof/offsetof is linked into the test driver.
fixture=d/'layout.c';fixture.write_text('#include <stddef.h>\n#include "'+str(src/'sqlite/sqlite3.c')+'"\nvoid test_offsets(unsigned*x){x[0]=sizeof(Pager);x[1]=sizeof(PgHdr);x[2]=offsetof(PgHdr,pPager);x[3]=offsetof(Pager,journalMode);x[4]=offsetof(Pager,nSubRec);x[5]=PAGER_JOURNALMODE_OFF;}\n')
clangflags=[x for x in args if x.startswith('-D')];subprocess.run(['clang','-O0','-w','-ffunction-sections','-fdata-sections',*clangflags,'-c',fixture,'-o',d/'layout.o'],check=True)
subprocess.run(['objcopy','--only-section=.text.test_offsets','--keep-symbol=test_offsets',d/'layout.o',d/'layout-only.o'],check=True)
h=d/'causal-main.c';h.write_text('''#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void test_offsets(unsigned*);int subjournalPageIfRequired(void*);
int main(void){unsigned off[6],n=0;test_offsets(off);unsigned char *pager=calloc(1,off[0]),*pg=calloc(1,off[1]);pager[off[3]]=off[5];memcpy(pg+off[2],&pager,sizeof(pager));int rc=subjournalPageIfRequired(pg);memcpy(&n,pager+off[4],4);printf("%d %u\\n",rc,n);free(pg);free(pager);return 0;}
''')
ref=w/'source-typed-study/sqlite.o';baseline=ref.read_bytes();out=[]
for label in ['ordinary','clang','poison','swapped']:
 obj=ref if label=='ordinary' else (w/'pending-native-study/runtime/clang.o' if label=='clang' else d/f'causal-{label}.o')
 g=t=''
 if label in ['poison','swapped']:
  with (d/f'causal-{label}.stderr').open('wb') as e:subprocess.run([d/'causal-compiler','--lanes','1','-c',*args,'-o',obj],cwd=src,env=env|({'BUSTER_LIVE_TEST_SWAP_CALLEES':'1'} if label=='swapped' else {}),stderr=e,check=True)
  rows=[x.split() for x in (d/f'causal-{label}.stderr').read_text().splitlines()]
  g=next(x[2] for x in rows if x[0]=='early-native-body-graph' and x[1]=='158189');t=next(x[2] for x in rows if x[0]=='control-source-function' and x[1]=='158189');assert g==t=='0'
 pro=d/f'causal-{label}-global.o';subprocess.run(['objcopy','--globalize-symbol=subjournalPageIfRequired',obj,pro],check=True)
 exe=d/f'run-{label}';subprocess.run(['clang','-Wl,-z,noexecstack','-no-pie',h,d/'layout-only.o',pro,'-ldl','-lpthread','-lm','-o',exe],check=True)
 stdout=subprocess.check_output([exe]).decode().strip();raw=obj.read_bytes();diff=[i for i,(a,b) in enumerate(zip(raw,baseline)) if a!=b] if label!='clang' else []
 if label=='poison':assert raw==baseline
 if label=='swapped':
  assert raw!=baseline and len(raw)==len(baseline)
  defs=[];off=struct.unpack_from('<Q',raw,40)[0];ss,n=struct.unpack_from('<HH',raw,58)
  for i in range(n):
   sec=struct.unpack_from('<IIQQQQIIQQ',raw,off+i*ss)
   if sec[1]!=4:continue
   for at in range(sec[4],sec[4]+sec[5],sec[9]):
    if raw[at:at+24]!=baseline[at:at+24]:
     ra=struct.unpack_from('<QQq',raw,at);rb=struct.unpack_from('<QQq',baseline,at);assert ra[:2]==rb[:2];defs.append((ra[0],rb[2],ra[2]))
  assert len(defs)==2 and defs[0][1:]==defs[1][1:][::-1];(d/'changed-relocations.txt').write_text(repr(defs)+'\n')
 out.append([label,hashlib.sha256(raw).hexdigest(),','.join(map(str,diff)),g,t,stdout]);assert stdout==('0 1' if label=='swapped' else '0 0'),(label,stdout)
with (d/'causal.tsv').open('w') as f:
 wr=csv.writer(f,delimiter='\t');wr.writerow(['arm','elf-sha256','changed-file-bytes','final-graph','final-typed','linked-result-and-modified-journal-record-count']);wr.writerows(out)
print(out)
