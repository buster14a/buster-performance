from pathlib import Path
f=Path(__file__).resolve().parent.parent/'live-native-calls/src/buster/compiler/c_check_live_native.c';s=f.read_text().replace('    bool pointer;','    bool pointer, is_void;').replace(' bool narrow = false,',' bool void_type = false;\n    bool narrow = false,').replace('else if (check_live_word(b, i, "void"))\n                opaque = true;','else if (check_live_word(b, i, "void"))\n            {\n                opaque = true;\n                void_type = true;\n            }').replace('    if (record && !alias.pointer)','    if (void_type && !ptr && !record) return (CheckLiveType){.is_void=true};\n    if (record && !alias.pointer)').replace('    if (!p->result.cls)\n','    if (!p->result.cls && !p->result.is_void)\n').replace('if (!proto.name || !proto.result.cls || params+1 == end-1)','if (!proto.name || (!proto.result.cls && !proto.result.is_void) || params+1 == end-1)')
s=s.replace('    uint32_t id = check_live_expression(b, t, stop);', '''    if (b->plan->result.is_void)
    {
        if (t!=stop) return 0;
        check_live_obligation(b->plan,CHECK_LIVE_RETURN,t-1,0,0);
        return check_live_put(b->plan,BUSTER_TYPED_RETURN,BUSTER_TYPED_CLASS_VOID,0) ? stop+1 : 0;
    }
    uint32_t id = check_live_expression(b, t, stop);''')
s=s.replace('    return check_live_value(b, id, cls) && check_live_put(p, BUSTER_TYPED_DISCARD, cls, 0);','    return check_live_value(b, id, cls) && (b->expr[id].type.is_void || check_live_put(p, BUSTER_TYPED_DISCARD, cls, 0));')
s=s.replace('    return terminal;\n}', '''    if (b->plan->result.is_void)
    {
        // The ordinary lowered body carries an implicit void return even after an explicit return.
        check_live_obligation(b->plan,CHECK_LIVE_RETURN,b->plan->closing,0,0);
        return check_live_put(b->plan,BUSTER_TYPED_RETURN,BUSTER_TYPED_CLASS_VOID,0);
    }
    return terminal;
}''',1)
pos=s.index('static bool check_live_plan_encode(')
s=s[:pos]+'''static AbiReturn check_live_return_abi(CheckLiveType type)
{
    if (type.is_void)
        return (AbiReturn){.kind=BUSTER_ABI_RESULT_IGNORE,.registers={UINT8_MAX,UINT8_MAX,UINT8_MAX,UINT8_MAX}};
    return (AbiReturn){.kind=BUSTER_ABI_RESULT_REGISTERS,.part_bytes=8,.registers={0,UINT8_MAX,UINT8_MAX,UINT8_MAX},
                       .flags=check_live_abi_flags(type.cls)};
}

'''+s[pos:]
s=s.replace('''            .result={.kind=BUSTER_ABI_RESULT_REGISTERS,.part_bytes=8,.registers={0,UINT8_MAX,UINT8_MAX,UINT8_MAX},
            .flags=check_live_abi_flags(proto->result.cls)}};''','''            .result=check_live_return_abi(proto->result)};''')
s=s.replace('''                              .result = {.kind = BUSTER_ABI_RESULT_REGISTERS,
                                         .part_bytes = 8,
                                         .registers = {0, UINT8_MAX, UINT8_MAX, UINT8_MAX},
                                         .flags = check_live_abi_flags(p->result.cls)}};''','''                              .result=check_live_return_abi(p->result)};''')
s=s.replace('''            .result={.kind=BUSTER_ABI_RESULT_REGISTERS,.part_bytes=8,.registers={0,UINT8_MAX,UINT8_MAX,UINT8_MAX},
                     .flags=check_live_abi_flags(call->prototype.result.cls)}};''','''            .result=check_live_return_abi(call->prototype.result)};''')
s=s.replace('''    AbiReturn result = {.kind = BUSTER_ABI_RESULT_REGISTERS,
                        .part_bytes = 8,
                        .registers = {0, UINT8_MAX, UINT8_MAX, UINT8_MAX},
                        .flags = check_live_abi_flags(p->result.cls)};''','''    AbiReturn result=check_live_return_abi(p->result);''')
s=s.replace('    return check_live_owned_class(types, type) == e->type.cls &&','    if (e->type.is_void) return type==BUSTER_TYPE_VOID ? type : 0;\n    return check_live_owned_class(types, type) == e->type.cls &&')
s=s.replace('    if (check_live_owned_class(types, ret) != p->result.cls)','    if ((ret==BUSTER_TYPE_VOID)!=p->result.is_void || check_live_owned_class(types, ret) != p->result.cls)')
s=s.replace('''        if (row.kind == CHECK_LIVE_DISCARD)
            return false; // unused-value diagnostics need their ordinary expression.''','''        if (row.kind == CHECK_LIVE_DISCARD)
        {
            if (p->proof[row.first].op!=BUSTER_TYPED_CALL || !check_live_owned_expr(r,p,decl,row.first)) return false;
            continue;
        }
        if (row.kind==CHECK_LIVE_RETURN && !row.first && ret==BUSTER_TYPE_VOID)
        {
            returned=true;
            continue;
        }''')
f.write_text(s)
