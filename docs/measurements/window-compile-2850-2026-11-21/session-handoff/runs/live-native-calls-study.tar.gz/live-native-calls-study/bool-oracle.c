typedef _Bool B; extern B t(B,int); extern void emit(B);
B pure(B a){return a;}
B proxy(B a,int b){return t(a,b);}
B conv(int a){return a;}
B yes(int x,int y){return x<y;}
void side(B x){emit(x);}
