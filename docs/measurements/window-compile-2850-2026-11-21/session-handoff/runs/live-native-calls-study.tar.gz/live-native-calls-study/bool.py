from pathlib import Path
p=Path(__file__).resolve().parent.parent/'live-native-calls/src/buster/compiler/c_check_live_native.c';s=p.read_text().replace('bool pointer, is_void;', 'bool pointer, is_void, is_bool;').replace('bool void_type = false;', 'bool void_type = false, bool_type = false;')
s=s.replace('''            if (check_live_word(b, i, "char"))
''','''            if (check_live_word(b,i,"_Bool") || check_live_word(b,i,"bool"))
            {
                integer = true;
                bool_type = true;
            }
            else if (check_live_word(b, i, "char"))
''').replace('    if (narrow)\n        cls', '    if (bool_type) cls=BUSTER_TYPED_CLASS_U8;\n    if (narrow)\n        cls').replace('alias : (CheckLiveType){.cls = cls})','alias : (CheckLiveType){.cls = cls,.is_bool=bool_type})')
s=s.replace('static bool check_live_truth(CheckLiveBuild* b, uint32_t id)', 'static bool check_live_argument_value(CheckLiveBuild* b,uint32_t id,CheckLiveType target);\nstatic bool check_live_truth(CheckLiveBuild* b, uint32_t id)',1)
s=s.replace('check_live_value(b,call->arguments[i],call->prototype.parameters[i].cls)','check_live_argument_value(b,call->arguments[i],call->prototype.parameters[i])')
loc=s.index('static void check_live_obligation(');s=s[:loc]+'''// Integer/pointer to _Bool is its nonzero test even when both use an 8-bit scalar class.
static bool check_live_argument_value(CheckLiveBuild* b,uint32_t id,CheckLiveType target)
{
    return target.is_bool && !b->expr[id].type.is_bool
        ? check_live_truth(b,id) && check_live_put(b->plan,BUSTER_TYPED_CONVERT,BUSTER_TYPED_CLASS_U8,0)
        : check_live_value(b,id,target.cls);
}
'''+s[loc:]
s=s.replace('return id && check_live_value(b, id, cls) && check_live_put(b->plan, BUSTER_TYPED_RETURN, cls, 0)','return id && check_live_argument_value(b,id,b->plan->result) && check_live_put(b->plan, BUSTER_TYPED_RETURN, cls, 0)')
s=s.replace('    if (type == BUSTER_TYPE_UCHAR)','    if (type == BUSTER_TYPE_BOOL) return BUSTER_TYPED_CLASS_U8;\n    if (type == BUSTER_TYPE_UCHAR)')
s=s.replace('    if (e->type.is_void) return type==BUSTER_TYPE_VOID ? type : 0;', '''    if (e->type.is_void) return type==BUSTER_TYPE_VOID ? type : 0;
    if ((type_unqualified(type)==BUSTER_TYPE_BOOL)!=e->type.is_bool) return 0;''')
s=s.replace('check_live_owned_class(types,params[i])!=call->prototype.parameters[i].cls)', 'check_live_owned_class(types,params[i])!=call->prototype.parameters[i].cls || (type_unqualified(params[i])==BUSTER_TYPE_BOOL)!=call->prototype.parameters[i].is_bool)')
s=s.replace('if ((ret==BUSTER_TYPE_VOID)!=p->result.is_void ||','if ((ret==BUSTER_TYPE_VOID)!=p->result.is_void || (type_unqualified(ret)==BUSTER_TYPE_BOOL)!=p->result.is_bool ||')
s=s.replace('''            if (type_unqualified(ret) != type_unqualified(a) &&
''','''            if (type_unqualified(ret) != type_unqualified(a) && !(type_unqualified(ret)==BUSTER_TYPE_BOOL &&
                p->proof[row.first].op!=BUSTER_TYPED_CONST && check_live_owned_class(types,a)!=0) &&
''')
s=s.replace('            check_live_owned_class(types, params[i]) != p->types[i].cls ||','            (type_unqualified(params[i])==BUSTER_TYPE_BOOL)!=p->types[i].is_bool || check_live_owned_class(types, params[i]) != p->types[i].cls ||')
p.write_text(s)
