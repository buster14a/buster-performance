extern void set(int);
extern int calc(int);
void v(int x){set(x);}
void early(int x){set(x);return;}
void unused(int x){calc(x);}
int both(int x){set(x);return calc(x);}
void route(int x){if(x){set(x);}else{set(x+1);}}
void bare(void){}
void local(int*p,int x){*p=x;}
void explicit_void(int x){return set(x);}
