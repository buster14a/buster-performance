#include <stddef.h>
#include "/home/david/Documents/Codex/2026-11-21/g/work/switch-inputs/sqlite/sqlite3.c"
void test_offsets(unsigned*x){x[0]=sizeof(Pager);x[1]=sizeof(PgHdr);x[2]=offsetof(PgHdr,pPager);x[3]=offsetof(Pager,journalMode);x[4]=offsetof(Pager,nSubRec);x[5]=PAGER_JOURNALMODE_OFF;}
