from pathlib import Path
p=Path(__file__).resolve().parent;w=p.parent
(p/'optimized.py').write_text((w/'live-owned-native-study/optimized.py').read_text().replace("target=(d/'../live-owned-native').resolve()","target=(d/'../live-native-calls').resolve()"))
(p/'timing.py').write_text((w/'live-owned-native-study/timing.py').read_text())
(p/'corpus.py').write_text((w/'live-owned-native-study/corpus.py').read_text())
(p/'corpus.sh').write_text((w/'live-owned-native-study/corpus.sh').read_text().replace('CHAIN_COMPILER="$d/compiler-develop"','CHAIN_COMPILER="${CALL_CORPUS_COMPILER:-$d/compiler-develop}"'))
