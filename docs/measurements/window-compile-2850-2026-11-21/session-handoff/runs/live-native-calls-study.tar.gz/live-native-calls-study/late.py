from pathlib import Path
p=Path(__file__).resolve().parent.parent/'live-native-calls/src/buster/compiler/c_check_live_native.c';s=p.read_text()
pos=s.index('static bool check_live_native_body(')
s=s[:pos]+'''// A late consumer still has the ordinary call signatures. Authenticate every source call
// against them before resolving its physically emitted field to the unit's symbol order.
static bool check_live_call_targets(const CheckProgram* program, const CheckLivePlan* p, const Tier0Function* fn)
{
    const CheckInput* in=program->input;
    if (p->call_count!=fn->call_count) return false;
    uint32_t first=0;
    for (uint32_t c=0;c<p->call_count;c++) {
        const CheckLiveCall* call=p->calls+c;
        const uint32_t d=in->declarations[call->token],prior=call->prototype.token;
        if (d>=in->token_count || prior>=in->token_count || !in->objects[d] || in->objects[d]!=in->objects[prior] ||
            in->objects[d]>=program->object_count || !fn->call_targets[c] || program->object_symbols[in->objects[d]]!=fn->call_targets[c] ||
            fn->call_first[c]!=first || fn->call_argument_counts[c]!=call->prototype.count ||
            fn->call_variadic[c] || (fn->call_asm && fn->call_asm[c]) || (fn->call_tails && fn->call_tails[c]) ||
            (fn->call_result_objects && fn->call_result_objects[c])) return false;
        const AbiCall abi={.stack_alignment_log2=4,.integer_registers=(uint8_t)call->prototype.count,
            .result={.kind=BUSTER_ABI_RESULT_REGISTERS,.part_bytes=8,.registers={0,UINT8_MAX,UINT8_MAX,UINT8_MAX},
                     .flags=check_live_abi_flags(call->prototype.result.cls)}};
        if (memcmp(&abi,fn->calls+c,sizeof(abi))) return false;
        for (uint32_t i=0;i<call->prototype.count;i++,first++) {
            const uint8_t cls=call->prototype.parameters[i].cls;
            const AbiLocation location={.kind=BUSTER_ABI_LOCATION_REGISTERS,.registers={abi_integer_arguments[i],UINT8_MAX},
                .flags=check_live_abi_flags(cls)};
            if (first>=fn->argument_count || fn->argument_classes[first]!=cls || (fn->argument_sizes && fn->argument_sizes[first]) ||
                memcmp(&location,fn->argument_locations+first,sizeof(location))) return false;
        }
    }
    return fn->argument_count==first;
}

'''+s[pos:]
s=s.replace('fn->incoming_variadic || fn->call_count ||\n        fn->argument_count || fn->label_count', 'fn->incoming_variadic ||\n        !check_live_call_targets(run->program,p,fn) || fn->label_count')
loc=s.index('    run->bodies[b] = (CheckEmitBody)',s.index('static bool check_live_native_body('))
s=s[:loc]+'''    LinkReference* fields=NULL;
    if (enc->reference_count)
    {
        fields=BUSTER_ARENA_PUSH_ARRAY(lane->scratch,LinkReference,enc->reference_count);
        if (!fields) return false;
        for (uint32_t i=0;i<enc->reference_count;i++)
        {
            fields[i]=enc->references[i];
            fields[i].target=fn->call_targets[fields[i].target-1];
        }
    }
'''+s[loc:]
s=s.replace('run->codes[b] = (EmittedCode){.label_count = enc->label_count};','run->codes[b] = (EmittedCode){.label_count = enc->label_count,.references=fields,.reference_count=enc->reference_count};')
p.write_text(s)
