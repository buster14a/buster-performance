from pathlib import Path
import csv,os,hashlib,subprocess
d=Path(__file__).resolve().parent;case=d/'edges';case.mkdir(exist_ok=True)
base=d.parent/'main-fbef-clean/build/compiler'; cc=Path(os.environ.get('LIVE_QA_COMPILER',d/'compiler-develop'))
pad=(d/'padded.c').read_text().split('extern int u0;',1)[1];pad='extern int u0;'+pad
forms={}
old=d.parent/'live-source-leaf-study/edges.py';s=old.read_text();exec(s[s.index('forms={'):s.index("(base/'prefix.h')")],forms)
cases={n:(p+'\n'+x+'\n') for n,(p,x) in forms['forms'].items()}
cases.update({
  'scalar':(d/'padded.c').read_text().split('extern int u0;',1)[0],
  'subword':(d/'primitive.c').read_text(),
  'unsigneds':'unsigned long f(unsigned long x,unsigned long y){return (x^0xffUL)+(y*7UL);} unsigned g(unsigned x){return x>>2;}',
  'if-args':'int f(int x,int y){if(x>y){return x-y;}else{return x+y;}}',
  'six-args':'long f(long a,long b,long c,long d,long e,long f){return (a+b)*(c-d)+(e^f);}',
  'seven-args':'int f(int a,int b,int c,int d,int e,int f,int g){return a+b+c+d+e+f+g;}',
  'array-arg':'int f(const int a[],int i){return a[i];}',
  'typed-field':'typedef unsigned U; typedef struct S{char h;U x;long tag;}S; U f(const S*s){return s?s->x:0U;}',
  'linked-record':'typedef struct N{int n;struct N *next;} N;int f(N*p){return p->next->n;}',
  'array-layout':'struct S{char x[17];int y;};int f(struct S*p){return p->y+1;}',
  'flex':'struct S{int h;int v[];};int f(struct S*p,int n){return p->v[n];}',
  'bit':'struct S{int a:4;int b;};int f(struct S*p){return p->b;}',
  'anonymous':'struct S{struct{long x;};int y;};int f(struct S*p){return p->y;}',
  'volatile':'struct S{volatile int x;};int f(struct S*p){return p->x;}',
  'packed':'#pragma pack(push,1)\nstruct S{char b;int x;};int f(struct S*p){return p->x;}\n#pragma pack(pop)',
  'attribute-packed':'struct __attribute__((packed)) S{char b;int x;};int f(struct S*p){return p->x;}',
  'atomic':'struct S{_Atomic int x;};int f(struct S*p){return p->x;}',
  'interrupt':'__attribute__((interrupt)) void h(void*p){} int f(int x){return x+2;}',
  'frame':'__attribute__((patchable_function_entry(3))) int f(int x){return x+2;}',
  'pointer-eq':'int f(const char*p){return p==0;}',
  'shortcircuit':'int f(int x,int*p){return x&&*p;} int g(int x,int*p){return x||*p;}',
  'float':'double f(double x){return x+1.0;}',
  'redeclaration':'int f(int);int f(unsigned x){return x;}',
  'undeclared-field':'struct S{int n;};int f(struct S*p){return p->oops;}',
  'warning-shift':'int f(int x){return x<<50;} int g(int x){return x/0;}',
  'pragma-diag':'#pragma clang diagnostic push\n#pragma clang diagnostic ignored "-Wshift-count-overflow"\nint f(int x){return x<<40;}\n#pragma clang diagnostic pop\n',
  'macro':'#define PLUS(a,b) ((a)+(b))\nint f(int a,int b){return PLUS(a,b);}',
})
cases.update({
 'void-cast-return':'int f(int x){return (void)x;}',
 'ptr-int-mismatch':'int f(int*p){return p;}',
 'different-pointer':'struct S{int a;};int*f(struct S*p){return p;}',
 'same-parameter-compare':'int f(int a){return a==a;}',
 'const-local-store':'int f(const int a){a=4;return a;}',
 'const-record-store':'struct S{int a;};int f(const struct S*p){p->a=1;return p->a;}',
 'const-pointer':'int f(int*const p){*p=1;return *p;}',
 'self-assignment':'int f(int a){a=a;return a;}',
 'uninitialized':'int f(int a){int x;return x+a;}',
 'self-initialized':'int f(int a){int x=x+a;return x;}',
 'scalar-stores':'unsigned f(unsigned x){x^=x<<13;x^=x>>7;return x;}',
 'repeated-effects':'unsigned f(unsigned*p){unsigned x=*p;x^=x<<13;x^=x>>7;x^=x<<17;*p=x;return x;}',
 'list-walk':'struct Node{struct Node*next;};struct Node*f(struct Node*p){while(p->next)p=p->next;return p;}',
 'local-break':'int f(int n){int x=0;while(n>0){x+=n;n-=1;}return x;}',
 'condition-pointer':'int f(void*p){if(p)return 2;return 3;}',
 'conversion-narrow':'short f(int x){return x;}',
 'enum-const':'enum E{Z};int f(int a){return a+Z;}',
 'range-suffix':'unsigned f(unsigned x){return x+0x123456789abcdef0123ULL;}',
 'bad-suffix':'int f(int x){return x+2uu;}',
 'shortcircuit-zero':'int f(int x){return 0&&(x/0);}',
 'assigned-pointer':'int f(const int*p,int*x){p=x;return *p;}',
 'attrib-redecl':'int f(int);int f(int) __attribute__((patchable_function_entry(3)));int f(int x){return x+2;}',
 'global-register':'register int x __asm__("r12");int f(int q){return q+x;}',
 'const-shift-error':'int f(int x){return x<<-3;}',
 'fixed-width':'unsigned long f(unsigned long x){x=(x^(x>>30))*0xBF58476D1CE4E5B9ull;return x^(x>>31);}',
 'noreturn':'_Noreturn int f(int a){return a;}',
 'attribute-param':'int f(int q __attribute__((unused))){return q+1;}',
 'implicit-signed-long':'long f(unsigned long a){return a;}',
 'diagnostic-scope':'#pragma clang diagnostic error "-Wsign-conversion"\nint f(unsigned a){return a;}',
 'readonly-typedef':'typedef const int T;int f(T*p){*p=3;return *p;}',
 'shadow-decl':'int f(int x){int y=x;{int x=7;y=x;}return y;}',
})
cases.update({
 'scalar-prototype':'extern int e(int,int);int f(int a,int b){return e(a+b,b);}',
 'separate-prototypes':'int x(int);int y(int);int f(int a){return x(a)+y(a);}',
 'nested-callees':'int x(int,int); int y(int,int); int f(int a,int b){return x(y(a,b),y(b,a));}',
 'repeated-target':'extern int e(int); int f(int a){return e(a)+e(e(a));}',
 'discarded-call':'extern int e(int); int f(int a){e(a);return a;}',
 'void-call':'extern void e(int);void f(int a){e(a);}',
 'void-early':'extern void e(int);void f(int a){if(a){e(a);return;}e(a+1);}',
 'init-call':'extern long e(long,long); long f(long a){long t=e(a,3L);return t*a;}',
 'conditional-target':'int x(int);int y(int);int f(int a){if(a)return x(a);else return y(a);}',
 'six-scalar-args':'int e(int,int,int,int,int,int);int f(int a,int b){return e(a,b,a,b,a,b);}',
 'narrow-abi':'short e(short);short f(short a){return e(a);}',
 'implicit-forward':'int f(int a){return foo(a);}',
 'missing-argument':'int e(int,int);int f(int a){return e(a);}',
 'more-arguments':'int e(int);int f(int a){return e(a,a);}',
 'variadic-fallback':'int e(int,...);int f(int a){return e(a,a);}',
 'old-style-fallback':'int e();int f(int a){return e(a);}',
 'kr-fallback':'int e(a)int a;{return a;}int f(int a){return e(a);}',
 'noreturn-callee':'_Noreturn int e(int);int f(int a){return e(a);}',
 'later-attribute':'int e(int);int f(int a){return e(a);}int e(int) __attribute__((deprecated));',
 'early-attribute':'int e(int) __attribute__((deprecated));int f(int a){return e(a);}',
 'callee-asm':'int e(int) __asm__("renamed");int f(int a){return e(a);}',
 'callee-asm-redeclaration':'int e(int);int e(int) __asm__("renamed");int f(int a){return e(a);}',
 'local-shadow':'int e(int);int f(int a){int e=a;return e(a);}',
 'pointer-shadow':'int e(int);int f(int(*e)(int),int a){return e(a);}',
 'future-typedef':'struct S;int e(struct S*);int f(unsigned a){return e(a);}',
 'proto-qualified':'int e(int*);int f(const int *p){return e(p);}',
 'nonnull-callee':'int e(int*) __attribute__((nonnull));int f(int a){return e(0);}',
 'future-inline':'static int e(int);int f(int a){return e(a);}static __attribute__((always_inline)) inline int e(int x){return x+1;}',
 'inline-ordinary':'static int e(int);int f(int a){return e(a);}static inline int e(int x){return x+1;}',
 'asm-callee-late':'int alt(int); int f(int a){return alt(a);} int alt(int) __asm__("foo_alias");',
 'macro-calls':'extern int e(int a);\n#define INVOKE(X) e(X)\nint f(int a){return INVOKE(a);}',
 'used-attribute':'extern int e(int) __attribute__((warn_unused_result));void f(int a){e(a);}',
 'condition-call':'int e(int);int f(int n){while(e(n)){n=n-1;}return n;}',
 'bad-arg-pointer':'int e(int*);int f(int a){return e(a);}',
 'nonvoid-no-return':'int e(int);int q(int x){e(x);}',
 'callee-side-effects':'int e(int,int);int f(int a){return e(a++,a++);}',
 'ignored-extra-warning':'extern int e(int a) __attribute__((pure));void f(int a){e(a);}',
 'call-weak':'int e(int) __attribute__((weak));int f(int a){return e(a);}',
 'callee-section':'int e(int) __attribute__((section(".text.foo")));int f(int a){return e(a);}',
 'callee-ms-abi':'int e(int) __attribute__((ms_abi));int f(int a){return e(a);}',
 'ptr-to-array':'struct A{int x[6];};int e(int*);int f(struct A*p){return e(p->x);}',
 'scalar-division':'int e(int);int f(int a){return e(a/0);}',
})
(case/'prefix.h').write_text('typedef int H;\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else ''
env=os.environ|dict(BUSTER_PARSE_LIVE_FOREST='1', BUSTER_LIVE_CHECKED_INPUT='1',BUSTER_LIVE_NATIVE_PROGRAMS='1',BUSTER_LIVE_OWN_PROGRAMS='1')
with (d/'edges.tsv').open('w',buffering=1) as f:
 w=csv.writer(f,delimiter='\t');w.writerow(['case','policy','clean-exit','candidate-exit','object-equal','stdout-equal','stderr-equal','source-fragments-used'])
 for name,source in cases.items():
  file=case/(name+'.c');file.write_text(source+'\n'+pad)
  for opt,flags in [('default',[]),('wall',['-Wall','-Wextra']),('strict',['-Wall','-Wextra','-Werror']),('quiet',['-w']),('all',['-Weverything'])]+([('debug',['-g']),('asm',['-S']),('frame',['-fno-omit-frame-pointer']),('patchable',['-fpatchable-function-entry=4'])] if name in ('scalar','subword','if-args','typed-field') else []):
   samples=[]
   for arm,driver,envv in [('clean',base,os.environ),('native',cc,env)]:
    out=case/(name+'.'+opt+'.'+arm+('.s' if opt=='asm' else '.o'));out.unlink(missing_ok=True)
    r=subprocess.run([driver,'--lanes','1','-std=gnu17','-c',*flags,file,'-o',out],env=envv,capture_output=True,timeout=15)
    (case/(name+'.'+opt+'.'+arm+'.stderr')).write_bytes(r.stderr)
    samples.append((r.returncode,sha(out),r.stdout,r.stderr))
   a,b=samples;hits=''
   if opt=='default' and b[0]==0:
    r=subprocess.run([cc,'--lanes','1','-std=gnu17','-c',file,'-o',case/'audit.o'],env=env|{'BUSTER_PARSE_LIVE_AUDIT':'1'},capture_output=True)
    (case/(name+'.audit.stderr')).write_bytes(r.stderr);hits=r.stderr.count(b'early-native-owned\t')
   w.writerow([name,opt,a[0],b[0],*[int(a[i]==b[i]) for i in range(1,4)],hits])
