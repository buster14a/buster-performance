from pathlib import Path
f=Path(__file__).resolve().parent/'../live-native-calls/src/buster/compiler/c_check_live_native.c'
s=f.read_text().replace('#define CHECK_LIVE_EXPRS 64u','#define CHECK_LIVE_EXPRS 64u\n#define CHECK_LIVE_CALLS 8u')
pos=s.index('typedef enum CheckLiveObligationKind')
s=s[:pos]+'''typedef struct CheckLivePrototype
{
    uint32_t name, token, count;
    CheckLiveType result, parameters[CHECK_LIVE_PARAMETERS];
} CheckLivePrototype;
typedef struct CheckLiveCall
{
    CheckLivePrototype prototype;
    uint32_t token;
    uint8_t arguments[CHECK_LIVE_PARAMETERS];
} CheckLiveCall;
'''+s[pos:]
s=s.replace('const struct CheckLiveExpr* proof;', '''uint32_t call_count;
    CheckLiveCall calls[CHECK_LIVE_CALLS];
    const struct CheckLiveExpr* proof;''').replace('CheckLiveRecord records[2048];','CheckLiveRecord records[2048];\n    CheckLivePrototype prototypes[4096];')
after=s.index('// Retain the closed source coordinates')
s=s[:after]+'''// Only complete, fixed, scalar prototypes participate. A later shadow or incompatible
// declaration is checked against this exact declaration token before the graph can be retired.
static void check_live_prototype(CheckLiveBuild* b, uint32_t first, uint32_t end)
{
    const uint8_t* k = b->tokens->kinds;
    if (end < first + 4 || k[end - 1] != PARSE_KIND_R_PAREN)
        return;
    uint32_t params = first;
    while (params < end && !(k[params] == PARSE_KIND_L_PAREN && b->tree->parents[params] == end - 1))
        params++;
    if (params < first + 2 || params == end || k[params - 1] != PARSE_KIND_IDENTIFIER)
        return;
    CheckLivePrototype proto = {.name=b->tokens->names[params-1], .token=params-1, .result=check_live_decl_type(b,first,params-1)};
    if (!proto.name || !proto.result.cls || params+1 == end-1)
        return;
    if (!(params+2 == end-1 && check_live_word(b,params+1,"void")))
    {
        for (uint32_t a=params+1; a<end-1;)
        {
            uint32_t stop=a;
            while (stop<end-1 && k[stop]!=PARSE_KIND_COMMA) stop++;
            if (a==stop || proto.count==CHECK_LIVE_PARAMETERS) return;
            CheckLiveType type={0};
            if (stop>a+1 && k[stop-1]==PARSE_KIND_IDENTIFIER)
                type=check_live_decl_type(b,a,stop-1);
            if (!type.cls) type=check_live_decl_type(b,a,stop);
            if (!type.cls) return;
            proto.parameters[proto.count++]=type;
            a=stop+1;
        }
    }
    b->programs->prototypes[proto.name & 4095]=proto;
}

'''+s[after:]
after=s.index('    if (b->tree->roles[root] == PARSE_ROLE_CLOSE_CAST')
s=s[:after]+'''    if (b->tree->roles[root] == PARSE_ROLE_CLOSE_CALL && root+1==end && k[lo]==PARSE_KIND_IDENTIFIER &&
        lo+1<root && b->tree->roles[lo+1]==PARSE_ROLE_OPEN_CALL && b->tree->parents[lo+1]==root)
    {
        const uint32_t name=b->tokens->names[lo];
        const CheckLivePrototype* proto=b->programs->prototypes+(name & 4095);
        CheckLivePlan* p=b->plan;
        if (!name || proto->name!=name || proto->token>=lo || p->call_count==CHECK_LIVE_CALLS) return 0;
        const uint32_t c=p->call_count++;
        CheckLiveCall* call=p->calls+c;
        call->prototype=*proto;
        call->token=lo;
        uint32_t a=lo+2;
        for (uint32_t i=0;i<proto->count;i++)
        {
            uint32_t stop=a, depth=0;
            while (stop<root)
            {
                const uint8_t kind=k[stop];
                if (kind==PARSE_KIND_COMMA && !depth) break;
                if (kind==PARSE_KIND_L_PAREN || kind==PARSE_KIND_L_SQUARE) depth++;
                if (kind==PARSE_KIND_R_PAREN || kind==PARSE_KIND_R_SQUARE) {if (!depth) return 0; depth--;}
                stop++;
            }
            const uint32_t arg=check_live_expression(b,a,stop);
            if (!arg || (stop==root)!=(i+1==proto->count)) return 0;
            call->arguments[i]=(uint8_t)arg;
            a=stop+(stop<root);
        }
        if (a!=root) return 0;
        e->op=BUSTER_TYPED_CALL;
        e->value=c;
        e->type=proto->result;
        return idx;
    }
'''+s[after:]
s=s.replace('    if (e->op == CHECK_LIVE_CAST)\n', '''    if (e->op == BUSTER_TYPED_CALL)
    {
        const CheckLiveCall* call=p->calls+e->value;
        for (uint32_t i=0;i<call->prototype.count;i++)
            if (!check_live_value(b,call->arguments[i],call->prototype.parameters[i].cls)) return false;
        if (!check_live_put(p,e->op,cls,e->value)) return false;
    }
    else if (e->op == CHECK_LIVE_CAST)
''',1)
after=s.index('    Tier0Function function =')
s=s[:after]+'''    AbiCall calls[CHECK_LIVE_CALLS]={0};
    AbiLocation outgoing[CHECK_LIVE_CALLS*CHECK_LIVE_PARAMETERS];
    uint32_t targets[CHECK_LIVE_CALLS], first[CHECK_LIVE_CALLS], counts[CHECK_LIVE_CALLS], declarations[CHECK_LIVE_CALLS+1];
    uint8_t classes[CHECK_LIVE_CALLS*CHECK_LIVE_PARAMETERS], variadic[CHECK_LIVE_CALLS]={0};
    uint32_t arguments=0;
    for (uint32_t c=0;c<p->call_count;c++)
    {
        const CheckLivePrototype* proto=&p->calls[c].prototype;
        targets[c]=c+1;
        declarations[c+1]=BUSTER_CHECK_NONE;
        first[c]=arguments;
        counts[c]=proto->count;
        calls[c]=(AbiCall){.stack_alignment_log2=4,.integer_registers=(uint8_t)proto->count,
            .result={.kind=BUSTER_ABI_RESULT_REGISTERS,.part_bytes=8,.registers={0,UINT8_MAX,UINT8_MAX,UINT8_MAX},
            .flags=check_live_abi_flags(proto->result.cls)}};
        for (uint32_t i=0;i<proto->count;i++,arguments++)
        {
            classes[arguments]=proto->parameters[i].cls;
            outgoing[arguments]=(AbiLocation){.kind=BUSTER_ABI_LOCATION_REGISTERS,.registers={gp[i],UINT8_MAX},
                .flags=check_live_abi_flags(classes[arguments])};
        }
    }
'''+s[after:]
s=s.replace('                              .local_classes = local,','''                              .calls=calls, .call_count=p->call_count, .call_targets=targets, .call_first=first,
                              .call_argument_counts=counts, .call_variadic=variadic, .argument_locations=outgoing,
                              .argument_classes=classes, .argument_count=arguments,
                              .local_classes = local,''',1).replace('CheckProgram program = {.parser = parser, .input = &input, .bodies = &body, .body_count = 1};','''CheckProgram program = {.parser=parser,.input=&input,.bodies=&body,.body_count=1,.symbol_objects=targets,
                            .object_declarations=declarations,.symbol_count=p->call_count};''')
s=s.replace('    return p->encoded != NULL && p->encoded->reference_count == 0;','''    if (!p->encoded || p->encoded->reference_count!=p->call_count) return false;
    for (uint32_t i=0;i<p->encoded->reference_count;i++)
    {
        const LinkReference ref=p->encoded->references[i];
        if (!ref.target || ref.target>p->call_count || ref.kind!=BUSTER_LINK_FIXUP_CALL || ref.addend!=-4) return false;
    }
    return true;''')
s=s.replace('        if (close - start > 144)\n            continue;','''        if (tokens->kinds[close]==PARSE_KIND_SEMI && close-start<=100)
            check_live_prototype(&b,start,close);''')
s=s.replace('        plan.opening = open;\n        if (open == close', '''        if (open<close && open-start<=100) check_live_prototype(&b,start,open);
        if (close-start>144) continue;
        plan.opening = open;
        if (open == close''',1)
s=s.replace('                fputc(\'\\n\', stderr);','''                fputc('\\n', stderr);
                for(uint32_t i=0;i<plan.encoded->reference_count;i++)
                {
                    const LinkReference ref=plan.encoded->references[i];
                    const CheckLiveCall call=plan.calls[ref.target-1];
                    const uint32_t row=parse_source_index(tokens,call.token);
                    const uint32_t length=pp_spelling(pp,pp->output.kinds[row],pp->output.values[row],pp->output.locations[row],buf,&name);
                    fprintf(stderr,"early-native-call-field\\t%u\\t%u\\t%u\\t%u\\t%u\\t%.*s\\t%u\\t%lld\\n",
                            open,plan.emitted_at,call.token,call.prototype.token,ref.target,(int)length,name,ref.instruction,(long long)ref.addend);
                }''')
s=s.replace('    else if (e->op == BUSTER_TYPED_CONST)\n    {\n        const uint8_t* bytes;', '''    else if (e->op == BUSTER_TYPED_CALL)
    {
        const CheckLiveCall* call=p->calls+e->value;
        const uint32_t use=in->declarations[call->token];
        if (use>=in->token_count || !in->objects[use] || in->objects[use]!=in->objects[call->prototype.token]) return 0;
        const TypeId fn=in->declared_types[use];
        if (type_kind(types,fn)!=BUSTER_TYPE_KIND_FUNCTION || type_function_abi_kind(types,fn)!=TYPE_FUNCTION_ABI_SYSV ||
            type_function_keeps_registers(types,fn) || type_function_has_parameter_abis(types,fn) ||
            (types->types.flags[type_index(fn)] & (BUSTER_TYPE_FLAG_PROTOTYPE|BUSTER_TYPE_FLAG_VARIADIC))!=BUSTER_TYPE_FLAG_PROTOTYPE) return 0;
        uint32_t count=0;
        const TypeId* params=type_parameters(types,fn,&count);
        if (count!=call->prototype.count) return 0;
        for (uint32_t i=0;i<count;i++)
        {
            const TypeId arg=check_live_owned_expr(r,p,decl,call->arguments[i]);
            if (!arg || type_unqualified(arg)!=type_unqualified(params[i]) || check_live_owned_class(types,params[i])!=call->prototype.parameters[i].cls) return 0;
        }
        type=type_return(types,fn);
    }
    else if (e->op == BUSTER_TYPED_CONST)
    {
        const uint8_t* bytes;''')
s=s.replace('|| p->encoded->reference_count || d != p->name_token','|| p->encoded->reference_count != p->call_count || d != p->name_token')
after=s.index('    for (uint32_t h = d + 1;')
s=s[:after]+'''    for (uint32_t c=0;c<p->call_count;c++)
    {
        const CheckLiveCall* call=p->calls+c;
        const uint32_t use=in->declarations[call->token], prior=call->prototype.token;
        if (use>=in->token_count || prior>=in->token_count || !in->objects[use] || in->objects[use]!=in->objects[prior] ||
            in->objects[use]>in->token_count || (attributed && attributed[in->objects[use]]) ||
            check_input_builtin_named(r,call->prototype.name) || check_constant_builtin_name(r,call->prototype.name)!=CBUILTIN_NONE ||
            (in->function_flags && ((in->function_flags[use]|in->function_flags[prior]) &
             (CHECK_INPUT_FUNCTION_INLINE|CHECK_INPUT_FUNCTION_KR|CHECK_INPUT_FUNCTION_NAKED|CHECK_INPUT_FUNCTION_NORETURN|CHECK_INPUT_FUNCTION_IMPLICIT|CHECK_INPUT_FUNCTION_IMPLICIT_LIBRARY))))
            return false;
        const InternSpan span=r->pp->table->spans[call->prototype.name];
        if (builtin_intrinsic_lookup((const char*)r->pp->table->records+span.offset,span.length)) return false;
    }
'''+s[after:]
s=s.replace('        if (!check_input_source_add(\n                bodies, (CheckSourceBody){.encoded = (CheckSourceEncoded*)p->encoded, .opening = p->opening, .closing = p->closing}, r->arena))','''        uint32_t* objects=NULL;
        if (p->call_count)
        {
            objects=BUSTER_ARENA_PUSH_ARRAY(r->arena,uint32_t,p->call_count);
            if (!objects) return;
            for (uint32_t c=0;c<p->call_count;c++) objects[c]=in->objects[in->declarations[p->calls[c].token]];
        }
        if (!check_input_source_add(
                bodies, (CheckSourceBody){.encoded = (CheckSourceEncoded*)p->encoded, .opening = p->opening, .closing = p->closing,
                        .symbols=p->call_count,.references=p->call_count,.objects=objects}, r->arena))''')
f.write_text(s)
