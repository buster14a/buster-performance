from pathlib import Path
p=Path(__file__).resolve().parent.parent/'live-native-calls/src/buster/compiler/c_check_live_native.c';s=p.read_text()
loc=s.index('static TypeId check_live_owned_expr(')
s=s[:loc]+'''// A compatible object pointer takes the same machine value. Ask the normal C
// assignment action to discharge pointee types and qualifiers at the use, including void *.
static bool check_live_passable(CheckInputReader* r, TypeId to, TypeId from,const CheckLiveExpr* value)
{
    if (!from || !to) return false;
    if (type_unqualified(from)==type_unqualified(to)) return true;
    if (type_kind(r->types,to)==BUSTER_TYPE_KIND_POINTER)
    {
        if (value->op==BUSTER_TYPED_CONST && value->imm==0) return true;
        if (type_kind(r->types,from)!=BUSTER_TYPE_KIND_POINTER) return false;
        const CheckAction action={.context={.tag_completions=r->tag_completions,.tag_completion_count=r->types->tags.count,.source_position=value->token}};
        CheckActionResult result={0};
        return check_action_pointer_assignable(r->types,type_element(r->types,to),type_element(r->types,from),&action,&result,true,NULL) &&
               result.diagnostic==CHECK_DIAG_NONE && !result.warnings;
    }
    const uint8_t cls=check_live_owned_class(r->types,to);
    if (value->op==BUSTER_TYPED_CONST && cls>=BUSTER_TYPED_CLASS_I8 && cls<=BUSTER_TYPED_CLASS_U64 && to!=BUSTER_TYPE_BOOL)
    {
        const uint32_t bits=check_live_width((CheckLiveType){.cls=cls})*8;
        const uint32_t magnitude=bits-((cls&1)!=0);
        return magnitude==64 || value->imm<(UINT64_C(1)<<magnitude);
    }
    return false;
}

'''+s[loc:]
s=s.replace('if (!arg || type_unqualified(arg)!=type_unqualified(params[i]) ||','if (!check_live_passable(r,params[i],arg,p->proof+call->arguments[i]) ||').replace('if (type_unqualified(ret) != type_unqualified(a) && !(type_unqualified(ret)==BUSTER_TYPE_BOOL &&','if (!check_live_passable(r,ret,a,p->proof+row.first) && !(type_unqualified(ret)==BUSTER_TYPE_BOOL &&')
p.write_text(s)
