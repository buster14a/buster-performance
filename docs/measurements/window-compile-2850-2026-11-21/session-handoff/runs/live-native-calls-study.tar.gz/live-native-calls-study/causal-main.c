#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void test_offsets(unsigned*);int subjournalPageIfRequired(void*);
int main(void){unsigned off[6],n=0;test_offsets(off);unsigned char *pager=calloc(1,off[0]),*pg=calloc(1,off[1]);pager[off[3]]=off[5];memcpy(pg+off[2],&pager,sizeof(pager));int rc=subjournalPageIfRequired(pg);memcpy(&n,pager+off[4],4);printf("%d %u\n",rc,n);free(pg);free(pager);return 0;}
