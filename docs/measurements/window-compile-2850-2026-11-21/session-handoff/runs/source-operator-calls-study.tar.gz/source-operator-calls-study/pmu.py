from pathlib import Path
import csv,subprocess,random,os,sys,hashlib,statistics
d=Path(sys.argv[1]).resolve();cc=d.parent/'source-operator-calls/build/compiler';args=sys.argv[2:]
modes={'ordinary':{},'source_statements':{'BUSTER_DIRECT_SOURCE_STATEMENTS':'1'}}
modes['operators']=modes['source_statements']|{'BUSTER_DIRECT_OPERATOR_PROGRAM':'1'}
modes['nested']=modes['operators']|{'BUSTER_DIRECT_OPERATOR_CALLS':'1'}
base={k:v for k,v in os.environ.items() if k not in ('BUSTER_SOURCE_MASK_ADMISSION','BUSTER_DIRECT_SOURCE_STATEMENTS','BUSTER_DIRECT_CALL_ASSIGNMENTS','BUSTER_DIRECT_SOURCE_CONDITIONS','BUSTER_SOURCE_EVENT_STATEMENTS','BUSTER_SOURCE_USE_REFERENCE')}
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});records={m:{} for m in modes}
baseline=hashlib.sha256((d/'optimized-run/sqlite.ordinary.o').read_bytes()).hexdigest()
with (d/'sqlite-pmu.tsv').open('w',buffering=1) as f:
 w=csv.writer(f,delimiter='\t');events=['instructions','cycles','branches','branch-misses'];w.writerow(['round','position','mode',*events,'sha256','exact'])
 for r in range(12):
  order=list(modes);random.Random(7300+r).shuffle(order)
  for i,m in enumerate(order):
   dest=d/'pmu-sqlite.o'; p=subprocess.run(['perf','stat','-x,','--no-big-num','-e','{'+','.join(e+':u' for e in events)+'}','--',cc,'--lanes','1','-c',*args,'-o',dest],env=base|modes[m],capture_output=True);assert p.returncode==0,p.stderr
   vals={s[2].partition(':')[0]:int(s[0]) for line in p.stderr.decode().splitlines() if len(s:=line.split(','))>2 and s[2].partition(':')[0] in events};assert all(e in vals for e in events),(vals,p.stderr)
   sha=hashlib.sha256(dest.read_bytes()).hexdigest();w.writerow([r,i,m,*[vals[e] for e in events],sha,sha==baseline]);records[m][r]=vals
for m,R in records.items():
 for e in events:
  deltas=[R[r][e]-records['ordinary'][r][e] for r in R];print(m,e,'median',statistics.median(z[e] for z in R.values()),'paired delta',statistics.median(deltas),'wins',sum(x<0 for x in deltas))
