from pathlib import Path
import csv
d=Path(__file__).resolve().parent/'optimized-run'
def rows(p,k):return [x.rstrip().split('\t')[1:] for x in p.open() if x.startswith(k+'\t')]
for unit in ['whole','nested','callees','forest','challenge','random','sqlite','main']:
 for old,new in [('graphless','scope0'),('bounded32','scope32'),('bounded128','scope128')]:
  a=d/(unit+'.'+old+'.log');b=d/(unit+'.'+new+'.log');x=rows(a,'source-metadata-window');y=rows(b,'source-metadata-window');print(unit,new,'equal',x==y,'windows',len(x),'declaration rows',sum(int(v[2]) for v in x),'tokens in selected windows',sum(int(v[1])-int(v[0])+1 for v in x),'old setup object,decl,definition reads',rows(a,'source-metadata-setup'),'new',rows(b,'source-metadata-setup'));assert x==y
