#!/bin/bash
set -eu
study=$1
cd "$(dirname "$0")/../switch-inputs"
source "$study/switch-local-args.sh"
eval "args=($sqlite_arguments)"
python3 "$study/pmu.py" "$study" "${args[@]}"
