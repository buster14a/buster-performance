#include <stdint.h>
#include <stdio.h>
struct State { unsigned value; unsigned other; };
extern unsigned affine(struct State *,unsigned,unsigned);
extern unsigned predicate(struct State *,unsigned,unsigned);
extern void notify(unsigned);
extern unsigned lookup(unsigned*,unsigned);
static uint32_t trace=2850, called[3];
unsigned rotate_mix(unsigned a,unsigned b) {called[0]++;return (a<<13 | a>>19) ^ b;}
unsigned tick(unsigned a){called[1]++;trace=(trace+a)*16777619u;return trace;}
void observe(unsigned a){called[2]++;trace=trace*33u+a;}
int main(void){struct State s={7,19};unsigned v[4]={8,9,1,2}; unsigned h=3;
for(unsigned i=0;i<2048;i++){h^=affine(&s,i,h);h+=predicate(&s,h,i);notify(i);h+=lookup(v,h);s.other+=3;}
printf("%u %u %u %u %u %u\n",h,trace,called[0],called[1],called[2],s.value);}
