extern void g();void f(int x,int b){g((x^b)+3);}
