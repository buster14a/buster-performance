from pathlib import Path
import csv,ast,collections
d=Path(__file__).resolve().parent;w=d.parent
for u in ['sqlite','main']:
 registry=w/'source-root-bodies-study/debug-run'/(u+'.owned.ownership.tsv')
 intervals=w/'source-operator-calls-study'/(u+'-intervals.tsv')
 roots={int(x['closing-token'])-1 for x in csv.DictReader(intervals.open(),delimiter='\t')}
 fs={}
 for line in (w/'source-operator-calls-study/optimized-run'/(u+'.composed.log')).open():
  r=line.strip().split('\t')
  if r[0]=='source-native-fragment':fs[int(r[1])]=(int(r[2]),int(r[3]))
 total=sum(a for a,b in fs.values()); print(u,'known complete real encoded functions',len(fs),'bytes',total)
 rows=list(csv.DictReader(registry.open(),delimiter='\t'))
 for cap in [0,8,32,64,128]:
  subset=[x for x in rows if int(x['close']) in roots and sum(ast.literal_eval(x['remaining']).values())<=cap]
  b=[fs[int(x['close'])] for x in subset if int(x['close']) in fs]
  print(u,cap,len(subset),len(b),sum(a for a,r in b),round(100*sum(a for a,r in b)/total,2),'percent',sum(r for a,r in b),'native relocation fields')
