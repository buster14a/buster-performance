#include <stdint.h>
#include <stdio.h>
struct R { int x; unsigned mask; struct R* q; };
extern int sample(struct R*, int, int, unsigned);
extern unsigned mixed(unsigned, int, long, unsigned long, struct R*);
static uint32_t h;
int foo(int a,int b) {h=(h ^ (uint32_t)a) * 16777619u + (uint32_t)b; return (int)h;}
int main(void) {
 struct R a={0,0,0}, b={0,0,0};a.q=&b;b.q=&a;
 for (int i=-125;i<126;i++) for (int j=-16;j<17;j++) {
  a.x=(i^j)&127; a.mask=(uint32_t)(i+j); b.x=i-j;
  h ^= (uint32_t)sample(&a,i,j,(unsigned)i);
  h ^= mixed(h,i,(long)j,(uint32_t)(j*7919),&a);
 }
 printf("%08x\n",h);
}
