from pathlib import Path
import csv,subprocess,os,hashlib,sys
d=Path(__file__).resolve().parent;out=d/'real';out.mkdir(exist_ok=True)
g=sys.argv[1];opts=[s for s in sys.argv[2:] if not s.endswith('.c')];files=[s for s in sys.argv[2:] if s.endswith('.c')]
exe=d.parent/'source-scoped-metadata/build/compiler'
sha=lambda s:hashlib.sha256(s).hexdigest()
with (out/(g+'.tsv')).open('w',buffering=1) as f:
 w=csv.writer(f,delimiter='\t');w.writerow('file policy ref-exit local-exit obj-equal stdout-equal stderr-equal bytes ref-sha source-sha'.split())
 for i,s in enumerate(files):
  for policy,flags in [('default',[])]:
   rr=[]
   for arm in ('clean','roles','source'):
    obj=out/(g+'-unit.o');obj.unlink(missing_ok=True)
    r=subprocess.run([exe,'--lanes','1','-c',*opts,*flags,s,'-o',obj],env={k:v for k,v in os.environ.items() if k not in ('BUSTER_SOURCE_EVENT_STATEMENTS','BUSTER_DIRECT_SOURCE_STATEMENTS')}|({'BUSTER_DIRECT_SOURCE_STATEMENTS':'1','BUSTER_DIRECT_OPERATOR_PROGRAM':'1','BUSTER_DIRECT_OPERATOR_CALLS':'1','BUSTER_SOURCE_ROOT_BODIES':'1','BUSTER_SOURCE_ROOT_BUDGET':'32','BUSTER_SOURCE_SCOPED_METADATA':'1','BUSTER_SOURCE_LINEAR_BODIES':'1','BUSTER_COMPOSE_SOURCE_STATEMENTS':'1','BUSTER_CONTROL_SOURCE_NATIVE':'1','BUSTER_CONTROL_EARLY_NATIVE':'1','BUSTER_CONTROL_EARLY_RELEASE':'1'} if arm=='source' else {'BUSTER_DIRECT_SOURCE_STATEMENTS':'1'} if arm=='roles' else {}),capture_output=True,timeout=90)
    data=obj.read_bytes() if obj.exists() else None
    rr.append((r.returncode,sha(data) if data is not None else '',r.stdout,r.stderr,len(data) if data is not None else 0))
    if (g in ('main','sqlite')):(out/f'{g}-{policy}-{arm}.stderr').write_bytes(r.stderr)
   a,roles,b=rr; assert a==roles,(s,"role scanner differs",a[:2],roles[:2]);w.writerow((s,policy,a[0],b[0],*(int(a[j]==b[j]) for j in range(1,4)),a[4],a[1],b[1]))
   if a!=b:
    for arm,row in zip(('clean','roles','source'),rr):(out/f'{g}-{i}-{policy}-{arm}.stderr').write_bytes(row[3])
