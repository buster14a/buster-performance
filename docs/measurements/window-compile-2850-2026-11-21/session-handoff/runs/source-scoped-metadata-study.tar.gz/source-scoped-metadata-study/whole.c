struct State { unsigned value; unsigned other; };
extern unsigned rotate_mix(unsigned, unsigned);
extern unsigned tick(unsigned);
extern void observe(unsigned);
unsigned affine(struct State *p, unsigned x, unsigned y) {
  x = (x ^ y) + p->other;
  p->value = tick(x + y);
  observe(p->value);
  return rotate_mix(tick(y), x ^ p->value);
}
unsigned predicate(struct State *p, unsigned x, unsigned y) {
  if (x < y) { p->value = y; }
  return p->value + x;
}
void notify(unsigned x) {
  observe(x ^ 7);
  observe(tick(x));
}
unsigned lookup(unsigned *p, unsigned i) { return p[i & 3]; }
