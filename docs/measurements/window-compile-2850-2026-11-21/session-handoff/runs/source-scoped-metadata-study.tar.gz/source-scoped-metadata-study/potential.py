from pathlib import Path
import csv,collections,bisect
d=Path(__file__).resolve().parent;w=d.parent
for g,fn in [('sqlite','sqlite.bodies.tsv'),('main','buster-canonical.bodies.tsv')]:
 old=w/'source-control-detail-study/complete'/(g+'.whole.log')
 roots=list(csv.DictReader((w/'source-operator-calls-study'/(g+'-intervals.tsv')).open(),delimiter='\t'));b=list(csv.DictReader((w/'source-local-composed-study'/fn).open(),delimiter='\t'))
 begins={int(x['end'])-1:int(x['body']) for x in b};by=collections.defaultdict(set)
 for r in roots:by[int(r['closing-token'])-1].add(int(r['begin'] if r['class']=='return' else r['end']))
 controls={};nodes={}
 for l in old.open():
  t=l.strip().split('\t')
  if t[0]=='source-control-whole':controls[int(t[1])]=[list(map(int,x.split(','))) for x in t[4:-1]]
  if t[0]=='body-whole-row':nodes[int(t[1])]=int(t[2])
 print(g,'function records',len(begins),len(controls))
 data=[]
 for close,ctrl in controls.items():
  if close not in begins or close not in by:continue
  rest=[(k,t) for k,t,n,trg in ctrl if (n!=4294967295 or k==1) and t not in by[close]]
  data.append((close,rest,close-begins[close]+1,nodes[close]))
 for n in [0,1,2,4]:
  kept=[x for x in data if len(x[1])<=n]
  print(g,'uncovered control roots <=',n,'functions',len(kept),'tokens',sum(a[2] for a in kept),'original graph',sum(a[3] for a in kept),'first remaining kinds',collections.Counter(v[0] for _,r,_,_ in kept for v in r).most_common(3))
