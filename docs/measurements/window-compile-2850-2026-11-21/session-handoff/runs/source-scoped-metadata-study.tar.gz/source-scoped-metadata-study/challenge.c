struct R { int x; unsigned mask; struct R *q; };
extern int foo(int,int);
int sample(struct R *p,int a,int b,unsigned u) {
 int r=a;
 r=-(a+b)*(p->x|2);
 p->x=a+(b^3);
 r+=p->q->x-b;
 foo(r+a,p->x|b);
 if((a&3)!=b){r=r+1;}
 while((b&7)>3){b=b-1;}
 r=r+(int)u;
 return r^(b+p->x);
}
unsigned mixed(unsigned x, int a, long t, unsigned long b, struct R *p) {
 x = (x ^ (a + 7)) + (p->mask & b);
 p->mask = ((a != t) | (x < b));
 x = ((x << 3) | (x >> 29)) ^ (a & t);
 foo(x ^ (a + 1), p->q->x + (a & 2));
 if (!((a^7) & p->mask)){x=x+19;}
 return x;
}
