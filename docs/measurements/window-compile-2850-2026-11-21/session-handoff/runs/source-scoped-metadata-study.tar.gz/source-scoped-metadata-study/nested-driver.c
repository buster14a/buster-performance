#include <stdio.h>
struct R { unsigned v; unsigned w; };
static unsigned a,b,c,d,m,n;
unsigned one(unsigned x){a++;return 5u*x+11u;}
unsigned two(unsigned x,unsigned y){b++;return (x^7u)*(y+2u);}
unsigned three(unsigned x,unsigned y,unsigned z){c++;return x+(y^z);}
unsigned get(struct R*p){d++;return p->w+(p->v<<2);}
void mark(unsigned x,unsigned y){m+=x;n+=y;}
extern unsigned run(struct R *,unsigned,unsigned);
int main(void){unsigned h=0x52369A1u;struct R p;for(unsigned i=0;i<1999;i++){p.v=h^i;p.w=h>>7;h=run(&p,h,i)+23u*p.v;}printf("%08x %u %u %u %u %u %u\n",h,a,b,c,d,m,n);}
