#!/bin/bash
set -eu
cd "$(dirname "$0")"
d=$PWD
cd ../source-scoped-metadata
: > "$d/checker-status.txt"
for i in 1 2 3 4 5 6 7 8;do
 ./build/compiler test-checker --seed 2850 --part "$i/8" > "$d/checker-$i.log" 2>&1 && rc=0 || rc=$?
 echo "$i $rc" >> "$d/checker-status.txt"
done
