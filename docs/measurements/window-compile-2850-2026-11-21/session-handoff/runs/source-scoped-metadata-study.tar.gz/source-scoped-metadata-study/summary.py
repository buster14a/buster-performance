from pathlib import Path
import csv,collections,statistics as st
d=Path(__file__).resolve().parent
def read(p):return list(csv.DictReader(p.open(),delimiter='\t'))
for unit in ['sqlite','main']:
 path=d/(unit+'-four.tsv')
 if not path.exists():continue
 rows=read(path)
 for stage in ['ordinary','total','check-input.expressions','check.program','check-program.emit','check.program-lowering','check.program-emission']:
  vals=collections.defaultdict(dict)
  for r in rows:
   assert r['equal']=='True'
   if r['stage']==stage:vals[r['policy']][int(r['round'])]=int(r['ns'])/1e6
  if not vals:continue
  print(unit,stage,'medians',{k:round(st.median(v.values()),3) for k,v in vals.items()})
  for k,v in vals.items():
   if k=='ordinary':continue
   for base in ['ordinary','graphless','bounded32','bounded128']:
    if base not in vals or k==base:continue
    pairs=[ms-vals[base][r] for r,ms in v.items() if r in vals[base]]
    print(unit,stage,k,'vs',base,round(st.median(pairs),3),sum(x<0 for x in pairs),'of',len(pairs))
for p in sorted((d/'optimized-run').glob('*.log')):
 if not p.name.startswith(('sqlite.','main.','whole.')):continue
 marks=collections.Counter();rows={}
 for line in p.open():
  t=line.rstrip().split('\t')
  if t[0]=='source-root-body':
   o,c,encoded,typed=map(int,t[1:5]);rows[c]=['zero',c-o+1,0,0];marks['graphless']+=1
  elif t[0]=='source-partial-body':
   o,c,actions,residual=map(int,t[1:5]);rows[c]=['partial',c-o+1,actions,residual];marks['partial']+=1;marks['residual nodes']+=residual
  elif t[0]=='source-linear-body':marks['direct linear']+=1
  elif t[0]=='source-root-candidates':marks['candidates']=int(t[1]);marks['candidate tokens']=int(t[2])
  elif t[0]=='source-native-fragment':
   c,n,fix=map(int,t[1:4])
   if c in rows:marks['injected '+rows[c][0]]+=1;marks['injected text bytes']+=n;marks['injected references']+=fix
 if rows:
  marks['published tokens']=sum(v[1] for v in rows.values());marks['peak residual nodes']=max(v[3] for v in rows.values())
  print(p.name,dict(marks))
