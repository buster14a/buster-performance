#!/bin/bash
set -eu
cd "$(dirname "$0")"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
python3 optimized.py >optimized.log 2>&1
cp predefines.h ../source-scoped-metadata/build/
python3 validate.py ../source-scoped-metadata/build/compiler optimized-run >validate.log
python3 residuals.py >residuals.txt
python3 metadata.py >metadata.txt
python3 - <<'PY'
import csv
for file in ['objects','runtime']:
 rows=list(csv.DictReader(open('optimized-run/'+file+'.tsv'),delimiter='\t'))
 assert rows and all(x['exact']=='True' for x in rows),[x for x in rows if x['exact']!='True']
PY
bash four.sh >four.log 2>&1
python3 boundary.py >boundary.log 2>&1
bash corpus.sh sqlite main lua musl >corpus.log 2>&1
bash sql-runtime.sh >sql-runtime.log 2>&1
bash checker.sh
bash pmu.sh "$PWD" >pmu.log 2>&1
python3 summary.py >summary.txt
python3 package.py >archive.log
