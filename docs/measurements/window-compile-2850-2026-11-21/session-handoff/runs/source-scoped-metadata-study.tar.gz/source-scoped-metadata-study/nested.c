struct R { unsigned v; unsigned w; };
extern unsigned one(unsigned);
extern unsigned two(unsigned,unsigned);
extern unsigned three(unsigned,unsigned,unsigned);
extern unsigned get(struct R*);
extern void mark(unsigned,unsigned);
unsigned run(struct R *p,unsigned x,unsigned y) {
 unsigned r=x;
 r=one(two(x^(y+7),p->w)) + (y & three(x,y,p->v));
 p->v=three(two(x,y),one(r),get(p));
 mark(one(r+3)^p->v,two(one(x),y));
 if (two(x^3,y)>17u) { r=one(r^(y+1)); }
 if (one(x)) { r=r+p->w; }
 return three(get(p),one(two(x,y)),r);
}
