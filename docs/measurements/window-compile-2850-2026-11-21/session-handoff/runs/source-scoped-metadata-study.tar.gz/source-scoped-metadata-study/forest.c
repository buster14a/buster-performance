struct R { int x; unsigned mask; struct R *q; };
extern int foo(int,int);
int sample(struct R *p,int a,int b,unsigned u) {
 int r=a;
 r=-(a+b)*(p->x|2);
 p->x=a+(b^3);
 r+=p->q->x - b;
 foo(r+a,p->x|b);
 if((a&3) != b) {r=r+1;}
 return r^b;
}
