#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs
root=${d%/*};tree=$root/pregraph-warning-study/compiler-source
source "$d/switch-local-args.sh"
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $root/proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main;do name=${g}_arguments;eval "args=(${!name})"; python3 "$d/four.py" "$g" "${args[@]}";done
