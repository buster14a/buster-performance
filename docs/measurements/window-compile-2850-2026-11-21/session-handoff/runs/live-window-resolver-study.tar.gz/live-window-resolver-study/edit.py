from pathlib import Path
src=Path(__file__).resolve().parents[1]/'live-window-resolver/src/buster/compiler';f=src/'c_check_input.c';s=f.read_text()
needle='static void check_input_resolve_range(CheckInputReader* reader, uint32_t begin, uint32_t end)';assert s.count(needle)==1
s=s.replace(needle,'''// All reader state survives a publication boundary. Only the real end of the input or a
// deferred lane finishes initializers and restores the last scope as an end sentinel.
static uint32_t check_input_resolve_window(CheckInputReader* reader, uint32_t begin, uint32_t end, uint32_t stop, bool resume)''')
s=s.replace('for (uint32_t i = begin; i <= end && reader->output->report_count == 0 && !reader->output->resource; i = check_input_resolve_next(reader, i, end))','''const uint32_t scan_end = stop < end ? stop : end;
    uint32_t i = resume && begin < end && begin != reader->resolve_limit && !reader->visits[begin] ?
                 check_input_resolve_next(reader, begin, scan_end) : begin;
    for (; i < stop && i <= end && reader->output->report_count == 0 && !reader->output->resource; i = check_input_resolve_next(reader, i, scan_end))''')
s=s.replace('    reader->output->resolve_visits += visits;\n}', '''    reader->output->resolve_visits += visits;
    return i >= stop ? i : end + 1;
}

static void check_input_resolve_range(CheckInputReader* reader, uint32_t begin, uint32_t end)
{
    check_input_resolve_window(reader, begin, end, end + 1, false);
}''')
s=s.replace('typedef struct CheckLiveInput\n', '''typedef struct CheckLiveBoundary CheckLiveBoundary;
struct CheckLiveBoundary
{
    CheckLiveBoundary* next;
    uint32_t end;
};

typedef struct CheckLiveInput
''')
s=s.replace('    bool used, failed;\n} CheckLiveInput;', '''    bool used, failed, keep_boundaries;
    CheckLiveBoundary* first;
    CheckLiveBoundary* last;
} CheckLiveInput;''')
s=s.replace('    live->rows = end;\n    live->windows', '''    if (live->keep_boundaries && pp->context_count != 0)
    {
        CheckLiveBoundary* boundary = BUSTER_ARENA_PUSH_ARRAY(&parser->live_rows, CheckLiveBoundary, 1);
        if (!boundary)
        {
            live->failed = true;
            return;
        }
        *boundary = (CheckLiveBoundary){ .end = end };
        if (live->last) live->last->next = boundary;
        else live->first = boundary;
        live->last = boundary;
    }
    live->rows = end;
    live->windows''')
s=s.replace('                check_input_resolve_range(&reader, 0, count);', '''                if (live != NULL && live->used && live->owner == parser && live->first != NULL && deferred == NULL)
                {
                    uint32_t cursor = 0;
                    uint32_t windows = 0;
                    for (const CheckLiveBoundary* cut = live->first; cut && cursor < count && !input->resource && !input->report_count; cut = cut->next)
                    {
                        if (cut->end < cursor || cut->end > count) abort();
                        cursor = check_input_resolve_window(&reader, cursor, count, cut->end, windows != 0);
                        windows += 1;
                    }
                    if (cursor <= count && !input->resource && !input->report_count)
                        check_input_resolve_window(&reader, cursor, count, count + 1, windows != 0);
                    if (getenv("BUSTER_PARSE_LIVE_AUDIT") != NULL)
                        fprintf(stderr, "source-resolver\\twindows=%u\\tvisits=%u\\tlast=%u\\trows=%u\\n", windows, input->resolve_visits, cursor, count);
                }
                else check_input_resolve_range(&reader, 0, count);''')
f.write_text(s);f=src/'c_checker_driver.c';s=f.read_text().replace('*records = (CheckLiveInput){ 0 };','*records = (CheckLiveInput){ .keep_boundaries = getenv("BUSTER_LIVE_RESOLVE_WINDOWS") != NULL };');f.write_text(s)
