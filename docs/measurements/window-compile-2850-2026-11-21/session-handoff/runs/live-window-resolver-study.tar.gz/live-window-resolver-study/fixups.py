from pathlib import Path
d=Path(__file__).resolve().parents[1]/'live-window-resolver/src/buster/compiler'
p=d/'c_check_program_emit.c';s=p.read_text()
s=s.replace('uint32_t* fields = BUSTER_ARENA_PUSH_ARRAY(state->storage, uint32_t, (uint64_t)code->reference_count + 1);','''uint32_t marked = 0;
        if (code->reference_count != 0)
            for (uint32_t i = 0; i < code->count; i += 1) marked += (code->records[i].form & BUSTER_X86_FORM_FIXUP) != 0;
        if (marked > code->reference_count) return size;
        uint32_t* fields = BUSTER_ARENA_PUSH_ARRAY(state->storage, uint32_t, (uint64_t)marked + 1);''')
s=s.replace('if (code->reference_count) memcpy(fields, ends, (size_t)code->reference_count * sizeof(*fields));','if (marked) memcpy(fields, ends, (size_t)marked * sizeof(*fields));')
s=s.replace('(CheckLiveFragment){opening, code->count, code->reference_count, (uint32_t)size, instructions, fields, bytes}', '''(CheckLiveFragment){ .opening = opening, .count = code->count, .references = code->reference_count,
            .size = (uint32_t)size, .instructions = instructions, .ends = fields, .bytes = bytes, .marked = marked }''')
s=s.replace('if (early->references) memcpy(ends, early->ends, (size_t)early->references * sizeof(*ends));','if (early->marked) memcpy(ends, early->ends, (size_t)early->marked * sizeof(*ends));');p.write_text(s)
p=d/'c_check_input.c';s=p.read_text().replace('    void* native;\n} CheckLiveFragment;','    void* native;\n    uint32_t marked;\n} CheckLiveFragment;');p.write_text(s)
