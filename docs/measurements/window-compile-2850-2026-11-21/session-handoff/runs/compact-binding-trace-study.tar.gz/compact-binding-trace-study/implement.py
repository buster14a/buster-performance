from pathlib import Path
w=Path(__file__).resolve().parent.parent
root=w/'implicit-bound-use-rows/src/buster/compiler'
def edit(file, old, new):
    p=root/file
    s=p.read_text()
    assert s.count(old)==1,(file,old)
    p.write_text(s.replace(old,new))
edit('c_bindings.c','    bool valid;\n','''    bool valid;
    // An ordinary reader's use has the bound declaration's key, object kind, no depth and no visibility end.
    // The source token, ordering point and previous handle are explicit even on that reader's short row.
    bool implicit_use_rows;
''')
edit('c_bindings.c','''        bindings->key[event] = key;
        bindings->declaration[event] = token;
        bindings->point[event] = point;
        bindings->end[event] = BUSTER_C_BINDING_NONE;
        bindings->depth[event] = depth;
        bindings->operation[event] = operation;
        bindings->kind[event] = kind;
        const uint32_t previous = bindings->heads[key];''','''        const uint32_t previous = bindings->heads[key];
        if (operation != C_BINDING_USE || !bindings->implicit_use_rows)
        {
            bindings->key[event] = key;
            bindings->end[event] = BUSTER_C_BINDING_NONE;
            bindings->depth[event] = depth;
            bindings->kind[event] = kind;
        }
        else if (previous == 0)
        {
            bindings->key[event] = key;
        }
        bindings->declaration[event] = token;
        bindings->point[event] = point;
        bindings->operation[event] = operation;''')
marker='static uint32_t c_bindings_lookup('
edit('c_bindings.c',marker,'''// The logical key of a use. A bound short row and its live declaration name the same namespace and identifier.
static inline uint32_t c_bindings_use_key(const CBindings* bindings, uint32_t event)
{
    const uint32_t handle = bindings->implicit_use_rows ? bindings->previous[event] : 0;
    return handle != 0 ? bindings->key[handle - 1] : bindings->key[event];
}

'''+marker)
p=root/'c_bindings.c'
s=p.read_text();assert s.count('const uint32_t key = bindings->key[i];')==2
p.write_text(s.replace('const uint32_t key = bindings->key[i];','const uint32_t key = bindings->operation[i] == C_BINDING_USE ? c_bindings_use_key(bindings, i) : bindings->key[i];'))
p=root/'c_check_symbol_pragma_input.c'
s=p.read_text();assert s.count('bindings->operation[event] == C_BINDING_USE && bindings->key[event]')==3
p.write_text(s.replace('bindings->operation[event] == C_BINDING_USE && bindings->key[event]','bindings->operation[event] == C_BINDING_USE && c_bindings_use_key(bindings, event)'))
edit('c_check_target_versions.c','bindings->operation[event] == C_BINDING_USE && bindings->key[event]','bindings->operation[event] == C_BINDING_USE && c_bindings_use_key(bindings, event)')
p=root/'c_check_binding.c'
s=p.read_text()
# This reader emits uses only for the ordinary namespace. General callers may supply label and tag use events.
s=s.replace('const bool value = events->key[event] / events->name_capacity == C_BINDING_ORDINARY;','const bool value = events->implicit_use_rows || events->key[event] < events->name_capacity;')
s=s.replace('if (events->key[event] / events->name_capacity == C_BINDING_ORDINARY)','if (value)')
p.write_text(s)
edit('c_check_fp_input.c','''        const uint32_t name = bindings->key[event];''','''        if (bindings->operation[event] != C_BINDING_DECLARE)
        {
            continue;
        }
        const uint32_t name = bindings->key[event];''')
edit('c_check_fp_input.c','if (bindings->operation[event] == C_BINDING_DECLARE && bindings->kind[event] == C_BINDING_TYPEDEF && bindings->depth[event] == 0 &&','if (bindings->kind[event] == C_BINDING_TYPEDEF && bindings->depth[event] == 0 &&')
p=root/'c_check_binding.c'
s=p.read_text();start=s.index('        const uint32_t kind = events->kind[event];')
s=s[:start]+'''        if (events->operation[event] != C_BINDING_DECLARE)
        {
            continue;
        }
'''+s[start:]
p.write_text(s)
p=root/'c_check_input.c'
s=p.read_text()
old='                check_input_resolve_range(&reader, 0, count);'
assert s.count(old)==1
s=s.replace(old,'''                reader.bindings.implicit_use_rows = fresh_output && complete_translation_unit && count >= 8192 && parser->errors == 0 &&
                    parser->recovered_types == NULL && !parser->options.scalar && !parser->prefix_view && !parser->whole_view &&
                    pp->options.published_unused_only && !pp->options.predefines.debug && !pp->options.predefines.debug_modules &&
                    !pp->options.node_window && !pp->options.node_window_constants && deferred == NULL && deferred_tokens == NULL &&
                    attested == NULL && binding_mode == CHECK_INPUT_BINDINGS_DEFAULT && getenv("BUSTER_SOURCE_USE_REFERENCE") == NULL;
'''+old+'''
                if (getenv("BUSTER_SOURCE_USE_CENSUS") != NULL)
                {
                    uint32_t uses = 0;
                    for (uint32_t e = 0; reader.bindings.implicit_use_rows && e < reader.bindings.count; e += 1)
                    {
                        uses += reader.bindings.operation[e] == C_BINDING_USE && reader.bindings.previous[e] != 0;
                    }
                    fprintf(stderr, "source-use-runs runs=%u uses=%u events=%u visits=%u\\n", (unsigned)reader.bindings.implicit_use_rows,
                            uses, reader.bindings.count, input->resolve_visits);
                }''')
other=(w/'unpublished-source-bindings/src/buster/compiler/c_check_input.c').read_text()
dump=other[other.index('            const char* event_file ='):other.index('            check_input_builtin_uses_publish(&reader);')]
for col,expr in dict(key='c_bindings_use_key(bindings, e)',end='BUSTER_C_BINDING_NONE',depth='0',kind='C_BINDING_OBJECT').items():
    ctype='uint8_t' if col=='kind' else 'uint32_t'
    old=f'                fwrite(bindings->{col}, sizeof({ctype}), bindings->count, file);'
    assert old in dump
    dump=dump.replace(old, f'''                for (uint32_t e = 0; e < bindings->count; e += 1)
                {{
                    const {ctype} value = bindings->implicit_use_rows && bindings->operation[e] == C_BINDING_USE ?
                        {expr} : bindings->{col}[e];
                    fwrite(&value, sizeof(value), 1, file);
                }}''')
old='            check_input_bindings(&reader, binding_mode);\n'
assert s.count(old)==1
p.write_text(s.replace(old,dump))
