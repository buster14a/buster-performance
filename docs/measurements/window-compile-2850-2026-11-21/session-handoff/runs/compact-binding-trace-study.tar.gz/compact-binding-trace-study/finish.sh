#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
until grep -q 'checks, 0 failures' checker-8.log 2>/dev/null; do sleep 8; done
python3 package.py
