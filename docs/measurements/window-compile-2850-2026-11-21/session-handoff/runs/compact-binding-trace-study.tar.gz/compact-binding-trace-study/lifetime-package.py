from pathlib import Path
from io import BytesIO
import hashlib,tarfile
s=Path(__file__).resolve().parent;w=s.parent
d=w/'public-declaration-evidence/docs/measurements/window-compile-2850-2026-11-21/138b49582'
files={'source-use-run-study/'+k+'-upstream.events':w/'source-use-run-study'/(k+'-upstream.events') for k in ['sqlite','buster']}
for name in ['sqlite.bodies.tsv','buster-canonical.bodies.tsv']:
    files['binding-close-study/'+name]=w/'binding-close-study'/name
for name in ['census.py','codec.py','close-lifetimes.py','close-lifetimes.log','sqlite.close-lifetimes.tsv','buster.close-lifetimes.tsv','corpus.tsv']:
    files['compact-binding-trace-study/'+name]=s/name
readme='''# Post-restore binding row lifetimes

The ordinary checker on upstream `40ae34f9d77afc42face58eff3338b7b1d1ba469` produced the complete native scoped event streams. The instrumented observer `138b49582102b50eb1e5df1433fde82cb2fabc65` supplied actual per-body first and one-past-last event offsets at its function-close callback. The Buster rows use the corrected same-source-path replay. The raw captures identify the file-scope and function-local declaration targets at their exact logical ordinals. All positions and target handles are retained in the supplied inputs.

After extraction, run `python3 work/compact-binding-trace-study/close-lifetimes.py` from this directory. It checks every previous-handle target from every future source event, every scope-pop endpoint, the final active stack, and the final per-name heads. On SQLite 138,671 of 167,474 events were created in the measured function spans. On Buster 259,471 of 357,701 were. No subsequent source event referred to a declaration made in those spans. 11,749 and 33,997 respectively remained active at the callback. Every one was restored in the first event after its span. The final binding oracles, deferred warnings and typo correction still need a witness when they run later in the compilation.

The independent Python encoding describes bound identifier uses by their target handle and source token. A missing use carries its original key and a displaced use additionally records its source ordering point. Declaration and restore records reconstruct the visibility endpoints, the exact logical previous handles, the active scope stack and the per-name heads. Run `python3 work/compact-binding-trace-study/codec.py work/source-use-run-study/sqlite-upstream.events work/source-use-run-study/buster-upstream.events` for the byte-for-byte comparison. The representation used 1,783,518 of 4,666,856 canonical bytes on SQLite and 4,022,177 of 10,281,578 canonical bytes on Buster. These are uncompressed representation sizes, including headers, for a whole fresh source unit. This capture measures serialization size and reference lifetime. A native compiler timing is a separate experiment.
'''
archive=d/'post-restore-binding-lifetimes.tar.xz'
with tarfile.open(archive,'w:xz',preset=2) as tar:
    def add(name,data):
        info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,BytesIO(data))
    add('README.md',readme.encode())
    for k,v in sorted(files.items()):add('work/'+k,v.read_bytes())
h=hashlib.sha256(archive.read_bytes()).hexdigest()
paragraph=f'''The [post-restore row lifetime and complete event reconstruction](post-restore-binding-lifetimes.tar.xz) joins the observer’s exact function-close offsets with all canonical upstream event rows. SQLite produced 138,671 body rows and Buster produced 259,471. Later source events referenced zero declaration handles created inside those windows. At the callback 11,749 SQLite and 33,997 Buster declarations still occupied the undo stack. Every one was popped in the immediately following restore. The archive also reconstructs both whole-unit logical event streams from representations of 38.22% and 39.12% of the original serialized size. Source, raw inputs and exact comparison outputs have SHA-256 `{h}`.'''
p=d/'README.md';assert 'post-restore row lifetime' not in p.read_text()
p.write_text(p.read_text().rstrip()+'\n\n'+paragraph+'\n')
print(h)
