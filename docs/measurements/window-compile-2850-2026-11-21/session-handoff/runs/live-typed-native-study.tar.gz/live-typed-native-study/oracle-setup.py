from pathlib import Path
p=Path(__file__).resolve().parent.parent/'live-typed-native/src/buster/compiler'
q=p/'c_check_input.c';s=q.read_text();v='    if (!state->native_leaves || !x86_encoder_initialized || pp->context_count == 0) return;';i=s.index(v)+len(v);s=s[:i]+'''
    const char* captured = getenv("BUSTER_LIVE_WINDOW_FILE");
    if (captured != NULL)
    {
        FILE* file = fopen(captured, "a");
        if (file == NULL) abort();
        for (uint32_t t = begin; t < end; ++t)
        {
            const uint32_t src=parse_source_index(tokens,t), loc=pp->output.locations[src];
            uint8_t tmp[32]; const uint8_t* text=NULL;
            uint32_t n=pp_spelling(pp,pp->output.kinds[src],pp->output.values[src],loc,tmp,&text);
            fprintf(file,"%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%.*s\\n",begin,end,t,tokens->kinds[t],tree->roles[t],tree->parents[t],tokens->names[t],pp->context_count,(int)n,(const char*)text);
        }
        fclose(file);
    }'''+s[i:];q.write_text(s)
q=p/'c_check_program_emit.c';s=q.read_text();v='                Tier0Code compiled = naked != 0 ?';i=s.index(v);s=s[:i]+'''                if (getenv("BUSTER_LIVE_NATIVE_DETAIL") != NULL)
                {
                    const Tier0Function* f=source; uint64_t res; memcpy(&res,&f->result,sizeof(res));
                    fprintf(stderr,"live-oracle-body\\t%u\\t%u\\t%u\\t%u\\t%u\\t%llu\\t%u\\t%u\\t%u\\n",run->program->bodies[b].opening,f->count,f->parameter_count,f->local_count,f->result_size,(unsigned long long)res,f->frame_pointer,f->probe_stack,f->entry_records);
                    for(uint32_t j=0;j<f->local_count;++j)
                        fprintf(stderr,"live-oracle-local\\t%u\\t%u\\t%u\\t%u\\t%u\\n",j,f->local_classes[j],f->local_flags?f->local_flags[j]:0,f->local_sizes?f->local_sizes[j]:0,f->local_alignments?f->local_alignments[j]:0);
                    for(uint32_t j=0;j<f->parameter_count;++j)
                    {const uint8_t* row=(const uint8_t*)&f->parameters[j];fprintf(stderr,"live-oracle-param\\t%u\\t",j);
                     for(uint32_t k=0;k<sizeof(AbiLocation);++k)fprintf(stderr,"%02x",row[k]);fputc('\\n',stderr);}
                    for(uint32_t j=0;j<f->count;++j)
                        fprintf(stderr,"live-oracle-op\\t%u\\t%u\\t%llu\\n",f->kinds[j],f->classes[j],(unsigned long long)f->values[j]);
                }
'''+s[i:];q.write_text(s)
