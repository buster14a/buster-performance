#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cc=${LIVE_COMPILER:-$PWD/compiler};cd ../switch-inputs;source ../switch-local-args.sh
for item in "$@";do
 case $item in sqlite)eval "args=($sqlite_arguments)";;main)t=$PWD/../pregraph-warning-study/compiler-source; args=(-march=native -I"$t/src" -fwrapv -funsigned-char --predefines "$PWD/../proof-predefines.h" "$t/src/buster/compiler/main.c");;padded) args=("$d/padded.c");;esac
 for arm in ordinary live audit;do
  opts=();if [[ $arm != ordinary ]];then opts+=(BUSTER_PARSE_LIVE_FOREST=1 BUSTER_LIVE_CHECKED_INPUT=1 BUSTER_LIVE_NATIVE_PROGRAMS=1);fi
  if [[ $arm == audit ]];then opts+=(BUSTER_PARSE_LIVE_AUDIT=1);fi
  pre="$d/$item.${RUN_MODE:-v1}.$arm"
  env "${opts[@]}" "$cc" --lanes 1 -c "${args[@]}" -o "$pre.o" >"$pre.stdout" 2>"$pre.stderr"
 done
 rm -f "$d/$item.${RUN_MODE:-v1}.diff"
 for arm in live audit;do cmp "$d/$item.${RUN_MODE:-v1}.ordinary.o" "$d/$item.${RUN_MODE:-v1}.$arm.o";done
 cmp "$d/$item.${RUN_MODE:-v1}.ordinary.stderr" "$d/$item.${RUN_MODE:-v1}.live.stderr"
 if [[ $item != padded ]];then cmp "$d/$item.${RUN_MODE:-v1}.ordinary.o" "$d/../source-typed-study/$item.o";fi
done
