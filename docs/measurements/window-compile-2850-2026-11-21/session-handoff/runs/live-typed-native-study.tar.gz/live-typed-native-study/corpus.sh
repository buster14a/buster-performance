#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs;source ../switch-local-args.sh
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
export CHAIN_COMPILER="$d/compiler-develop" CHAIN_CORPUS_OUTPUT="$d/corpus"
for g in "$@";do v=${g}_arguments;eval "args=(${!v})";python "$d/corpus.py" "$g" "${args[@]}";done
