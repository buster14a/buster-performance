from pathlib import Path
import os,subprocess,shutil,csv
from proofs import syms
d=Path(__file__).resolve().parent; tree=d/'../live-typed-native';new=d/'../live-typed-native-poison'
if not new.exists():subprocess.run(['git','worktree','add','--detach',new,'13e508849'],cwd=tree,check=True)
p=new/'src/buster/compiler/c_check_live_native.c';text=p.read_text()
needle='            tbl->plans[tbl->count++] = plan;';pos=text.index(needle)
text=text[:pos]+'''            if (getenv("BUSTER_PROOF_FLIP") != NULL && open==0xOPENu && plan.encoded->length==LENGTH &&
                plan.encoded->bytes[OFFSET] == 0x07) plan.encoded->bytes[OFFSET]=0x08;
            if(scratch.peak) memset(scratch.base,0x9b,(size_t)scratch.peak);
'''+text[pos:]
with (d/'padded-native-symbols.tsv').open() as f:
 row=next(r for r in csv.DictReader(f,delimiter='\t') if r['name']=='e')
blob=bytes.fromhex(row['native-hex']);assert blob.count(7)==1,blob
p.write_text(text.replace('0xOPENu',row['opening']+'u').replace('LENGTH',str(len(blob))).replace('OFFSET',str(blob.index(7))))
with (d/'poison-mutation.patch').open('w') as f:subprocess.run(['git','diff'],cwd=new,stdout=f,check=True)
src=(d/'iterate.py').read_text().replace("target=(d/'../live-typed-native').resolve()", "target=(d/'../live-typed-native-poison').resolve()").replace("ref=d/'probe.o';exe=d/'compiler'","ref=d/'poison.o';exe=d/'poison-compiler'")
(d/'iterate-poison.py').write_text(src);subprocess.run(['python',d/'iterate-poison.py'],check=True)
env=os.environ|dict(BUSTER_PARSE_LIVE_FOREST='1',BUSTER_LIVE_CHECKED_INPUT='1',BUSTER_LIVE_NATIVE_PROGRAMS='1')
padded=d/'padded.c';ref=d/'padded.final.ordinary.o'
(d/'runtime.c').write_text('''#include <stdio.h>
int e(int),b(int,int),f(int,int),g(int,int),both(int,int),load(int*),slot(int*,int);
int main(void) {int v[]={2,6,14};int sum=0;for(int i=0;i<37;i++)sum+=b(i,7)+e(i)+f(i,7)+g(i,7)+both(i,7)+load(v)+slot(v,i%3);
printf("%d %d %d\\n",sum,e(0),e(3));return 0;}
''')
out={}
for mode in ['ordinary','clang','poison','mutation']:
 obj=ref if mode=='ordinary' else d/(mode+'-padded.o')
 if mode=='clang':subprocess.run(['clang','-c',padded,'-o',obj],check=True)
 if mode in ('poison','mutation'):subprocess.run([d/'poison-compiler','--lanes','1','-c',padded,'-o',obj],env=env|({'BUSTER_PROOF_FLIP':'1'} if mode=='mutation' else {}),check=True)
 exe=d/('runtime-'+mode);subprocess.run(['clang',d/'runtime.c',obj,'-o',exe],check=True);out[mode]=subprocess.check_output([exe]).decode().strip()
 if mode=='poison':assert obj.read_bytes()==ref.read_bytes()
 if mode=='mutation':
  good=ref.read_bytes();bad=obj.read_bytes();assert len(good)==len(bad);diff=[(i,a,b) for i,(a,b) in enumerate(zip(good,bad)) if a!=b]
  assert diff==[(int(row['file-offset'])+blob.index(7),7,8)],diff
assert out['clang']==out['ordinary']==out['poison']!=out['mutation'],out
(d/'mutation-results.txt').write_text(f'physical PP opening {row["opening"]}; native e at ELF {row["file-offset"]}; entire ELF delta {diff}\n'+str(out)+'\n')
print((d/'mutation-results.txt').read_text())
