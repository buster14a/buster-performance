from pathlib import Path
p=Path(__file__).resolve().parent.parent/'live-typed-native/src/buster/compiler'
q=p/'c_check_input.c';s=q.read_text();needle='    CheckLiveLeaf* leaves;\n} CheckLiveInput;';assert needle in s;s=s.replace(needle,'''    CheckLiveLeaf* leaves;
    struct CheckLivePrograms* programs;
    bool native_programs;
} CheckLiveInput;

static void check_live_native_window(CheckLiveInput* live, Parser* parser, Preprocessor* pp, const ParseTokens* tokens,
                                     const ParseTree* tree, uint32_t begin, uint32_t end);
''');s=s.replace('    check_live_leaf_window(live, parser, pp, tokens, tree, begin, end);','''    check_live_leaf_window(live, parser, pp, tokens, tree, begin, end);
    if (live->native_programs && pp->context_count != 0)
        check_live_native_window(live, parser, pp, tokens, tree, begin, end);''');q.write_text(s)
q=p/'c_checker_driver.c';s=q.read_text().replace('.native_leaves = getenv("BUSTER_LIVE_NATIVE_LEAVES") != NULL,','.native_leaves = getenv("BUSTER_LIVE_NATIVE_LEAVES") != NULL,\n                                                  .native_programs = getenv("BUSTER_LIVE_NATIVE_PROGRAMS") != NULL,');s=s.replace('if ((getenv("BUSTER_LIVE_NATIVE_LEAVES") != NULL ||','if ((getenv("BUSTER_LIVE_NATIVE_PROGRAMS") != NULL || getenv("BUSTER_LIVE_NATIVE_LEAVES") != NULL ||');q.write_text(s)
q=p/'c_check_program_emit.c';s=q.read_text();i=s.index('static bool check_program_emit_code_half(');s=s[:i]+'''static bool check_live_native_body(CheckEmitRun* run, CheckEmitLane* lane, uint32_t b, const Tier0Function* function);

'''+s[i:];i=s.index('                Tier0Code compiled = naked != 0 ?');s=s[:i]+'''                if (!spliced && naked == NULL && run->program->parser != NULL && run->program->parser->live_consumer != NULL &&
                    check_live_native_body(run,lane,b,source))
                {
                    if (window_mark != UINT64_MAX) check_program_emit_window_pop(lane->code,code_mark,run->poison_windows);
                    continue;
                }
'''+s[i:];i=s.index('// How Tier 0 reaches each symbol of a lowered program');s=s[:i]+'#include "c_check_live_native.c"\n\n'+s[i:];q.write_text(s)
