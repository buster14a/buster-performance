int d(int x){(void)(x);return 2;}
int e(int x){((void)(0));return x+2;}
int ep(int *x){(void)(x);return 0;}
int f(long n){return (int)(n>>4);}
long g(unsigned char n){return (long)n;}
int w(int x){while(x<4)x+=2;return x;}
