from pathlib import Path
d=Path(__file__).resolve().parent
p=d/'../live-typed-native/src/buster/compiler/c_check_live_native.c';s=p.read_text()
s=s.replace('uint32_t opening, closing, name, count, parameters;', 'uint32_t opening, closing, name, name_token, count, parameters;')
s=s.replace('p->name=b->tokens->names[params-1];','p->name=b->tokens->names[params-1]; p->name_token=params-1;')
s=s.replace('(run->lanes && run->lanes->assembly) || check_program_patchable(run->program,b).count)', '(run->lanes && run->lanes->assembly))')
s=s.replace('if(lo==t->count || t->plans[lo].opening!=open)return false;', '''if(lo==t->count || t->plans[lo].opening!=open)return false;
    if((run->program->patchable_key_count || run->program->patchable_count) && check_program_patchable(run->program,b).count)return false;''')
s=s.replace('            tbl->plans[tbl->count++]=plan;', '''            tbl->plans[tbl->count++]=plan;
            if(live->audit_leaves)
            {
                const uint32_t source=parse_source_index(tokens,plan.name_token);
                uint8_t buf[32];const uint8_t* name=NULL;
                const uint32_t n=pp_spelling(pp,pp->output.kinds[source],pp->output.values[source],pp->output.locations[source],buf,&name);
                fprintf(stderr,"early-native-bytes\\t%u\\t%.*s\\t%u\\t%u\\t",open,(int)n,name,plan.context_count,plan.emitted_at);
                for(uint64_t i=0;i<plan.encoded->length;i++)fprintf(stderr,"%02x",plan.encoded->bytes[i]);
                fputc('\\n',stderr);
            }''')
marker='typedef struct CheckLiveExpr'
s=s.replace(marker,'''// Source-only operations have no Tier 0 instruction value.
enum { CHECK_LIVE_LOGICAL_NOT = 205, CHECK_LIVE_CONDITIONAL, CHECK_LIVE_MEMBER, CHECK_LIVE_SUBSCRIPT, CHECK_LIVE_AND, CHECK_LIVE_OR };
'''+marker)
import re
for x,k in enumerate(['LOGICAL_NOT','CONDITIONAL','MEMBER','SUBSCRIPT','AND','OR'],205):
 a=s.index('static bool check_live_word')
 s=s[:a]+re.sub(r'(?<!\d)'+str(x)+r'(?!\d)','CHECK_LIVE_'+k,s[a:])
s=s.replace('else\n    if(e->op==CHECK_LIVE_MEMBER)', 'else if(e->op==CHECK_LIVE_MEMBER)')
p.write_text(s)
