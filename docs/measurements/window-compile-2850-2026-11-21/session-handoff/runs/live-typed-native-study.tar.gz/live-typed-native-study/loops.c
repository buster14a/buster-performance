int step(int x){x+=2;return x;}
int while1(int x,int y){while(x<y)x+=2;return x;}
int while2(int n){int x=0;while(n>0){x+=n;n-=1;}return x;}
int if1(int x,int y){if(x>0)x=y;return x+1;}
int z(int x){int a=x+3;return a;}
int write(int *p,int x){*p=x;return x;}
int add(int*p,int x){*p+=x;return *p;}
int t(int x,int y){return x>0?x:y;}
