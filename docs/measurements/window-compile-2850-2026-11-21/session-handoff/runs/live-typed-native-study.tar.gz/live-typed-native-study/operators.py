from pathlib import Path
q=Path(__file__).resolve().parent.parent/'live-typed-native/src/buster/compiler/c_check_live_native.c';s=q.read_text()
s=s.replace('    uint32_t value;\n    CheckLiveType type;', '    uint32_t value;\n    uint64_t imm;\n    CheckLiveType type;')
s=s.replace('bool narrow=false,short_value=false;','bool narrow=false,short_value=false,explicit_sign=false;').replace('else if(check_live_word(b,i,"int")||check_live_word(b,i,"signed"))integer=true;','else if(check_live_word(b,i,"signed")){integer=true;explicit_sign=true;}\n            else if(check_live_word(b,i,"int"))integer=true;').replace('if(narrow)cls=uns?', 'if(narrow)cls=(uns||(!explicit_sign&&b->pp->options.predefines.char_unsigned))?')
s=s.replace('if(p->result.cls<BUSTER_TYPED_CLASS_I32)return false;','if(!p->result.cls)return false;')
a=s.index('        if(stop<=a+1 || p->parameters');b=s.index('a=stop+1;',a)
s=s[:a]+'''        if(stop<=a+1 || p->parameters==CHECK_LIVE_PARAMETERS)return false;
        uint32_t name=stop-1; bool array=k[name]==PARSE_KIND_R_SQUARE;
        if(array)
        {
            while(name>a && k[name]!=PARSE_KIND_L_SQUARE)name--;
            if(name<=a+1)return false;
            name--;
        }
        if(k[name]!=PARSE_KIND_IDENTIFIER)return false;
        CheckLiveType type=check_live_decl_type(b,a,name);
        if(array)type=(CheckLiveType){.cls=BUSTER_TYPED_CLASS_U64,.element=type.pointer?0:type.cls,.pointer=true,.record=type.pointer?0:type.record};
        if(!type.cls)return false;
        p->names[p->parameters]=b->tokens->names[name];p->types[p->parameters++]=type;'''+s[b:]
i=s.index('static uint32_t check_live_expression(')
s=s[:i]+'''static bool check_live_literal(CheckLiveBuild* b,uint32_t token,CheckLiveExpr* e)
{
    uint32_t src=parse_source_index(b->tokens,token);
    if(src>=b->pp->output.count)return false;
    uint8_t buf[32];const uint8_t* spelling=NULL;
    uint32_t n=pp_spelling(b->pp,b->pp->output.kinds[src],b->pp->output.values[src],b->pp->output.locations[src],buf,&spelling);
    if(!n||n>30)return false;
    uint32_t i=0,base=10;bool uns=false,wide=false;
    if(n>1&&spelling[0]=='0')
    {
        base=8;
        if(spelling[1]=='x'||spelling[1]=='X'){base=16;i=2;}
    }
    uint32_t digits=0;uint64_t value=0;
    for(;i<n;i++)
    {
        uint8_t ch=spelling[i];
        unsigned d=ch>='0'&&ch<='9'?ch-'0':ch>='a'&&ch<='f'?ch-'a'+10:ch>='A'&&ch<='F'?ch-'A'+10:16;
        if(d>=base)break;
        if(value>(UINT64_MAX-d)/base)return false;
        value=value*base+d;digits++;
    }
    if(!digits)return false;
    for(;i<n;i++)
    {
        if(spelling[i]=='u'||spelling[i]=='U')uns=true;
        else if(spelling[i]=='L'||spelling[i]=='l')wide=true;
        else return false;
    }
    if(value>UINT32_MAX || (base==10 && !uns && value>INT32_MAX))wide=true;
    if((!wide && value>INT32_MAX) || (wide&&value>INT64_MAX))uns=true;
    e->op=BUSTER_TYPED_CONST;e->imm=value;e->type.cls=wide?(uns?BUSTER_TYPED_CLASS_U64:BUSTER_TYPED_CLASS_I64):(uns?BUSTER_TYPED_CLASS_U32:BUSTER_TYPED_CLASS_I32);
    return true;
}

'''+s[i:]
s=s.replace('if(k[root]==PARSE_KIND_NUMBER && check_live_integer(b->pp,b->tokens,root,&e->value) && e->value<=INT32_MAX)\n        {e->op=BUSTER_TYPED_CONST;e->type.cls=BUSTER_TYPED_CLASS_I32;return idx;}','if(k[root]==PARSE_KIND_NUMBER && check_live_literal(b,root,e))return idx;')
i=s.index('    if(k[root]==PARSE_KIND_ARROW')
s=s[:i]+'''    if(k[root]==PARSE_KIND_R_SQUARE && root+1==end)
    {
        uint32_t o=lo;while(o<root && !(k[o]==PARSE_KIND_L_SQUARE&&b->tree->parents[o]==root))o++;
        e->a=(uint8_t)check_live_expression(b,lo,o);e->b=(uint8_t)check_live_expression(b,o+1,root);
        if(!e->a||!e->b||!b->expr[e->a].type.pointer||!b->expr[e->a].type.element||b->expr[e->b].type.pointer)return 0;
        e->type.cls=b->expr[e->a].type.element;e->op=208;return idx;
    }
'''+s[i:];s=s.replace('    e->op=check_live_op(k[root]);','''    if(k[root]==PARSE_KIND_AMPAMP || k[root]==PARSE_KIND_PIPEPIPE)
    {
        e->op=k[root]==PARSE_KIND_AMPAMP?209:210;e->type.cls=BUSTER_TYPED_CLASS_I32;
        e->a=(uint8_t)check_live_expression(b,lo,root);e->b=(uint8_t)check_live_expression(b,root+1,end);return e->a&&e->b?idx:0;
    }
    e->op=check_live_op(k[root]);''')
s=s.replace('a->op!=BUSTER_TYPED_CONST||a->value','a->op!=BUSTER_TYPED_CONST||a->imm').replace('v->op!=BUSTER_TYPED_CONST||v->value','v->op!=BUSTER_TYPED_CONST||v->imm')
s=s.replace('    if(e->op==BUSTER_TYPED_SHL||e->op==BUSTER_TYPED_SHR)e->value=a->type.cls;','    if(e->op==BUSTER_TYPED_SHL||e->op==BUSTER_TYPED_SHR)e->value=a->type.cls;\n    if(e->value<BUSTER_TYPED_CLASS_I32)e->value=BUSTER_TYPED_CLASS_I32;')
s=s.replace('if(e->op==BUSTER_TYPED_CONST)return check_live_put(p,e->op,want,e->value);','''if(e->op==BUSTER_TYPED_CONST)return check_live_put(p,e->op,want,e->imm);
    if(e->op==208)
    {
        if(!check_live_value(b,e->a,BUSTER_TYPED_CLASS_U64)||!check_live_value(b,e->b,BUSTER_TYPED_CLASS_I64)||
           !check_live_put(p,BUSTER_TYPED_PTR_ADD,BUSTER_TYPED_CLASS_U64,check_live_width(e->type))||!check_live_put(p,BUSTER_TYPED_LOAD,cls,0))return false;
    }
    else if(e->op==209 || e->op==210)
    {
        bool either=e->op==210;
        if(!check_live_truth(b,e->a))return false;
        uint32_t branch=p->count;
        if(!check_live_put(p,either?BUSTER_TYPED_BRANCH_TRUE:BUSTER_TYPED_BRANCH_FALSE,BUSTER_TYPED_CLASS_I32,0)||!check_live_truth(b,e->b))return false;
        uint32_t jump=p->count;
        if(!check_live_put(p,BUSTER_TYPED_JUMP_VALUE,BUSTER_TYPED_CLASS_I32,0))return false;
        p->values[branch]=p->count;if(!check_live_put(p,BUSTER_TYPED_CONST,BUSTER_TYPED_CLASS_I32,either?1:0))return false;
        p->values[jump]=p->count;
    }
    else''')
s=s.replace('static bool check_live_plan_encode(','''static uint8_t check_live_abi_flags(uint8_t cls)
{
    return cls>=BUSTER_TYPED_CLASS_I8&&cls<=BUSTER_TYPED_CLASS_U16?((cls&1)?BUSTER_ABI_FLAG_SIGN:BUSTER_ABI_FLAG_ZERO):0;
}

static bool check_live_plan_encode(''')
s=s.replace('.registers={gp[i],UINT8_MAX}};', '.registers={gp[i],UINT8_MAX},.flags=check_live_abi_flags(p->types[i].cls)};').replace('.part_bytes=8,.registers={0,UINT8_MAX,UINT8_MAX,UINT8_MAX}', '.part_bytes=8,.registers={0,UINT8_MAX,UINT8_MAX,UINT8_MAX},.flags=check_live_abi_flags(p->result.cls)')
# Conservative source ownership for active packing. The ordinary checker still proves the full layout.
s=s.replace('    CheckLiveRecord records[2048];','    CheckLiveRecord records[2048];\n    uint32_t pack_position, pragmas;')
s=s.replace('    if(t>=close || k[t]!=PARSE_KIND_STRUCT)return;', '    if(b->programs->pack_position && close>=b->programs->pack_position-1)return;\n    if(t>=close || k[t]!=PARSE_KIND_STRUCT)return;')
s=s.replace('    CheckLivePrograms* tbl=live->programs;Arena scratch={0};uint32_t first=begin;', '''    CheckLivePrograms* tbl=live->programs;Arena scratch={0};uint32_t first=begin;
    while(tbl->pragmas<tokens->pragma_count && !tbl->pack_position)
    {
        uint32_t i=tbl->pragmas++,src=tokens->pragma_sources[i];
        if(src+2<pp->output.count && pp_token_is_name(pp,&pp->output,src+2,pp->output.count,"pack"))tbl->pack_position=tokens->pragma_positions[i]+1;
    }''')
s=s.replace('        CheckLivePlan plan={.closing=close,.context_count=pp->context_count,.emitted_at=pp->output.count};\n        CheckLiveBuild b={.tokens=tokens,.tree=tree,.pp=pp,.programs=tbl,.plan=&plan};','''        CheckLivePlan plan; CheckLiveBuild b;
        b.tokens=tokens;b.tree=tree;b.pp=pp;b.programs=tbl;b.plan=&plan;b.expressions=0;''')
s=s.replace('        uint32_t open=start;','        plan=(CheckLivePlan){.closing=close,.context_count=pp->context_count,.emitted_at=pp->output.count};\n        uint32_t open=start;')
q.write_text(s)
