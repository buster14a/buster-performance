from pathlib import Path
import csv,collections,re
d=Path(__file__).resolve().parent
arr=[];n=0;forms=[]
for ln in (d/'sqlite.window').open():
 x=ln.rstrip('\n').split('\t',8)
 if len(x)<9:continue
 i,k,r,p,name=map(int,x[2:7]);word=x[8];arr.append((i,k,r,p,word))
 if p!=4294967295:continue
 if r==77:
  body=next((j for j,row in enumerate(arr) if row[2]==53 and row[3]==i),None)
  if body is None:body=next((j for j,row in enumerate(arr) if row[4]=='{' and row[3]==i),None)
  if body is not None:
   n+=1;a=[x[4] for x in arr];op=arr[body][0]
   if len(a)<=144 and 'return' in a and not any(x in a[body:] for x in ['for','switch','goto','case','asm','__asm__']):
    sig=' '.join(a[:body]);line=' '.join(a[body:]);forms.append((op,sig,line))
 arr=[]
print('functions',n,'eligible small',len(forms))
opens={int(l.split('\t')[1]) for l in (d/'sqlite.ops.audit.stderr').open() if l.startswith('early-native-used')}
with (d/'small-source-functions.tsv').open('w') as f:
 w=csv.writer(f,delimiter='\t');w.writerow(['opening','current','signature','body'])
 for a,s,b in forms:w.writerow((a,int(a in opens),s,b))
for a,s,b in forms:
 if a in opens or len(b)>210 or b.count(';')<2 or any(x in b.split(' ') for x in ['(', '.', '++']):continue
 print(s,b)
