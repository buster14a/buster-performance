from pathlib import Path
p=Path(__file__).resolve().parent.parent/'live-typed-native/src/buster/compiler/c_check_live_native.c'
s=p.read_text().replace('uint8_t cls, element; bool pointer;', 'uint8_t cls, element; bool pointer; uint32_t record;')
s=s.replace('typedef struct CheckLivePrograms\n{','''typedef struct CheckLiveRecord
{
    uint32_t name, first, end;
    bool is_union;
} CheckLiveRecord;
typedef struct CheckLivePrograms
{''').replace('CheckLiveAlias aliases[256];','CheckLiveAlias aliases[4096];\n    CheckLiveRecord records[2048];')
s=s.replace('bool integer=false,wide=false,uns=false,ptr=false,opaque=false,tag=false;','bool integer=false,wide=false,uns=false,ptr=false,opaque=false,tag=false;\n    bool narrow=false,short_value=false; uint32_t record=0;')
s=s.replace('if(check_live_word(b,i,"unsigned"))','if(check_live_word(b,i,"char")){integer=true;narrow=true;}\n            else if(check_live_word(b,i,"short")){integer=true;short_value=true;}\n            else if(check_live_word(b,i,"unsigned"))')
s=s.replace('if(tag){tag=false;continue;}','if(tag){tag=false;record=id;continue;}')
s=s.replace('b->programs->aliases+(id&255)','b->programs->aliases+(id&4095)')
s=s.replace('uint8_t cls=integer?', 'uint8_t cls=integer?').replace('    if(ptr)return (CheckLiveType){.cls=BUSTER_TYPED_CLASS_U64,.element=opaque||alias.pointer?0:cls,.pointer=true};\n    return !opaque?', '''    if(narrow)cls=uns?BUSTER_TYPED_CLASS_U8:BUSTER_TYPED_CLASS_I8;
    if(short_value)cls=uns?BUSTER_TYPED_CLASS_U16:BUSTER_TYPED_CLASS_I16;
    if(!record)record=alias.record;
    if(ptr)return (CheckLiveType){.cls=BUSTER_TYPED_CLASS_U64,.element=opaque||alias.pointer?0:cls,.pointer=true,.record=alias.pointer?0:record};
    if(record&&!alias.pointer)return (CheckLiveType){.record=record};
    return !opaque?''')
s=s.replace('p->result=check_live_decl_type(b,first,params-1);','p->result=check_live_decl_type(b,first,params-1);').replace('if(!p->result.cls)return false;', 'if(p->result.cls<BUSTER_TYPED_CLASS_I32)return false;').replace('if(!type.cls)return false;', 'if(type.cls<BUSTER_TYPED_CLASS_I32)return false;')
i=s.index('static uint8_t check_live_op(')
s=s[:i]+'''// Retain the closed source coordinates, including field order. A supported field needs only
// the preceding layout. Later unsupported members cannot change earlier offsets in an unpacked record.
static void check_live_decl_record(CheckLiveBuild* b,uint32_t start,uint32_t close)
{
    const uint8_t* k=b->tokens->kinds;
    bool alias=k[start]==PARSE_KIND_TYPEDEF;uint32_t t=start+(alias?1:0);
    if(t>=close || k[t]!=PARSE_KIND_STRUCT)return;
    bool is_union=check_live_word(b,t,"union");t++;
    uint32_t name=0;
    if(t<close && k[t]==PARSE_KIND_IDENTIFIER)name=b->tokens->names[t++];
    if(t>=close || k[t]!=PARSE_KIND_L_BRACE)return;
    uint32_t end=b->tree->parents[t];
    if(end>=close || k[end]!=PARSE_KIND_R_BRACE)return;
    if((!alias && end+1!=close)||(alias && (end+2!=close||k[end+1]!=PARSE_KIND_IDENTIFIER)))return;
    for(uint32_t i=start;i<close;i++)if(k[i]==PARSE_KIND_ATTRIBUTE || k[i]==PARSE_KIND_ALIGNAS)return;
    const uint32_t key=name?name:(UINT32_C(0x80000000)|start);
    b->programs->records[key&2047]=(CheckLiveRecord){.name=key,.first=t+1,.end=end,.is_union=is_union};
    if(alias)
    {
        uint32_t id=b->tokens->names[end+1];b->programs->aliases[id&4095]=(CheckLiveAlias){.name=id,.type={.record=key}};
    }
}

static uint32_t check_live_width(CheckLiveType type)
{
    return type.cls>=BUSTER_TYPED_CLASS_I8 && type.cls<=BUSTER_TYPED_CLASS_U64?1u<<((type.cls-1)/2):0;
}

static bool check_live_field(CheckLiveBuild* b,uint32_t tag,uint32_t name,CheckLiveType* result,uint32_t* offset)
{
    CheckLiveRecord* r=b->programs->records+(tag&2047);
    if(!tag||r->name!=tag)return false;
    const uint8_t* k=b->tokens->kinds;uint64_t bytes=0;
    for(uint32_t start=r->first;start<r->end;)
    {
        uint32_t stop=start;
        while(stop<r->end && k[stop]!=PARSE_KIND_SEMI)stop++;
        if(stop==r->end || start==stop)return false;
        uint32_t at=start;uint32_t decl=start;
        while(at<stop && k[at]!=PARSE_KIND_COMMA)
        {
            if(k[at]==PARSE_KIND_IDENTIFIER && at>start &&
               (at+1==stop || k[at+1]==PARSE_KIND_COMMA || k[at+1]==PARSE_KIND_L_SQUARE))break;
            at++;
        }
        if(at>=stop||k[at]!=PARSE_KIND_IDENTIFIER)return false;
        uint32_t common=at;while(common>start && k[common-1]==PARSE_KIND_STAR)common--;
        for(;;)
        {
            uint32_t var=at,dim=1;
            CheckLiveType type=check_live_decl_type(b,start,decl==start?at:common);
            if(decl!=start && at>decl)
            {
                if(at!=decl+1||k[decl]!=PARSE_KIND_STAR)return false;
                type=(CheckLiveType){.cls=BUSTER_TYPED_CLASS_U64,.element=type.pointer?0:type.cls,.pointer=true,.record=type.pointer?0:type.record};
            }
            uint32_t width=check_live_width(type);if(!width)return false;
            uint64_t field=r->is_union?0:(bytes+width-1)&~((uint64_t)width-1);at++;
            bool array=false;
            while(at<stop && k[at]==PARSE_KIND_L_SQUARE)
            {
                uint32_t n=0;
                if(at+2>=stop||k[at+2]!=PARSE_KIND_R_SQUARE||!check_live_integer(b->pp,b->tokens,at+1,&n)||!n||n>UINT32_MAX/dim)return false;
                dim*=n;at+=3;array=true;
            }
            if(at<stop && k[at]!=PARSE_KIND_COMMA)return false;
            if(b->tokens->names[var]==name)
            {
                if(array||field>UINT32_MAX)return false;
                *result=type;*offset=(uint32_t)field;return true;
            }
            if(!r->is_union)bytes=field+(uint64_t)width*dim;
            if(at==stop)break;
            decl=++at;while(at<stop && k[at]==PARSE_KIND_STAR)at++;
            if(at==stop||k[at]!=PARSE_KIND_IDENTIFIER)return false;
        }
        start=stop+1;
    }
    return false;
}

'''+s[i:]
i=s.index('    if(root==lo)');s=s[:i]+'''    if(k[root]==PARSE_KIND_ARROW && root+2==end && k[root+1]==PARSE_KIND_IDENTIFIER)
    {
        e->a=(uint8_t)check_live_expression(b,lo,root);
        if(!e->a || !b->expr[e->a].type.pointer ||
           !check_live_field(b,b->expr[e->a].type.record,b->tokens->names[root+1],&e->type,&e->value))return 0;
        e->op=207;return idx;
    }
'''+s[i:]
i=s.index('    if(e->op==206)');s=s[:i]+'''    if(e->op==207)
    {
        if(!check_live_value(b,e->a,BUSTER_TYPED_CLASS_U64))return false;
        if(e->value && (!check_live_put(p,BUSTER_TYPED_CONST,BUSTER_TYPED_CLASS_U64,e->value) || !check_live_put(p,BUSTER_TYPED_PTR_ADD,BUSTER_TYPED_CLASS_U64,1)))return false;
        if(!check_live_put(p,BUSTER_TYPED_LOAD,cls,0))return false;
    }
    else '''+s[i:].lstrip()
s=s.replace('        if(close<=start || close-start>144)continue;', '        if(close<=start)continue;')
s=s.replace('        if(tokens->kinds[start]==PARSE_KIND_TYPEDEF', '''        if(tokens->kinds[close]==PARSE_KIND_SEMI && (tokens->kinds[start]==PARSE_KIND_STRUCT || tokens->kinds[start]==PARSE_KIND_TYPEDEF))
            check_live_decl_record(&b,start,close);
        if(close-start>144)continue;
        if(tokens->kinds[start]==PARSE_KIND_TYPEDEF''').replace('if(name)tbl->aliases[name&255]','if(name && (type.cls || type.record))tbl->aliases[name&4095]')
p.write_text(s)
