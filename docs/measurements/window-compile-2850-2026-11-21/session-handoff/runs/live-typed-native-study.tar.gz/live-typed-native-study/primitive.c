unsigned char uc(unsigned char x){return x;}
signed char sc(signed char x){return x;}
unsigned short us(unsigned short x){return x;}
int sn(int x,unsigned char y){return y;}
int loadn(const unsigned char *p,int i){return p[i];}
int boolx(_Bool x){return x;}
int both(int x,int y){return x&&y;}
int either(int x,int y){return x||y;}
int zero(int x){return !x;}
int eqnull(void *x){return x!=0;}
