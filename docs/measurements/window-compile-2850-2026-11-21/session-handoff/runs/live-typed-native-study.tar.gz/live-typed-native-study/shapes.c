int a(int x){return x;}
int b(int x,int y){return x+y;}
unsigned c(unsigned x,unsigned y){return (x^y)+3;}
long d(long x,long y){return x<y;}
int e(int x){if(x)return 1;return 7;}
int f(int x,int y){return x?x:y;}
int g(int x,int y){if(x<y)return x;return y;}
static int h1(int x){return x-8;}
int h(int v){return h1(v);}
int neg(int x){return -x;}
int both(int x,int y){return (x>>3)&y;}
int same(int x,int y){return x==y;}
void *p(void *x){return x;}
int isnull(const void *x){return x==0;}
int load(int *x){return *x;}
int slot(int *x,int i){return x[i];}
int cst(void){return 2;}
