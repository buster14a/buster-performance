#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d="$PWD"; cd ../live-binding-event-stream
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/
cd "$d"; python3 qualify.py >qualify.log 2>&1
