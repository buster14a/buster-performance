from pathlib import Path
tree=Path(__file__).resolve().parent.parent/'live-binding-event-stream/src/buster/compiler'
def apply(name, pairs):
 p=tree/name;s=p.read_text()
 for before,after in pairs:
    assert s.count(before)==1,(name,before)
    s=s.replace(before,after)
 p.write_text(s)
append='''        bindings->key[event] = key;
        bindings->declaration[event] = token;
        bindings->point[event] = point;
        bindings->end[event] = BUSTER_C_BINDING_NONE;
        bindings->depth[event] = depth;
        bindings->operation[event] = operation;
        bindings->kind[event] = kind;
        const uint32_t previous = supplied ? target : bindings->heads[key];
        bindings->previous[event] = previous;'''
restore='''        bindings->operation[event] = C_BINDING_RESTORE;
        bindings->declaration[event] = mark;
        bindings->point[event] = point;
        // A restore names no declaration: its other fields are written all the same, so that the stream's columns
        // don't keep whatever its slot held (#113's lanes reuse their slots from body to body).
        bindings->key[event] = 0;
        bindings->end[event] = BUSTER_C_BINDING_NONE;
        bindings->previous[event] = 0;
        bindings->depth[event] = 0;
        bindings->kind[event] = 0;'''
func='''// Every checked source transition before cursor has the same identifier stack and undo
// stack. The shared pre-EOF row records the next canonical transition, including its prior
// handle. The final reader keeps a fresh name space and uses its own normalized key.
static bool c_bindings_published_event(CBindings* bindings, uint32_t e, CBindingNamespace space, uint32_t name,
                                       uint32_t token, uint32_t point, uint32_t depth, CBindingOperation op, CBindingKind kind)
{
    CBindingPublished* source = bindings->published;
    if (source->failed || e >= source->count) return false;
    const uint32_t old_key = (uint32_t)space * source->names + name;
    if (e != source->cursor || bindings->operation[e] != op || bindings->declaration[e] != token ||
        bindings->point[e] != point || bindings->key[e] != old_key || bindings->depth[e] != depth || bindings->kind[e] != kind)
    {
        source->failed = true;
        return false;
    }
    source->cursor += 1;
    source->rows[op] += 1;
    if (source->oracle && op != C_BINDING_RESTORE)
    {
        const uint32_t current_key = (uint32_t)space * bindings->name_capacity + name;
        if (bindings->heads[current_key] != bindings->previous[e]) abort();
    }
    return !source->rewrite;
}

'''
apply('c_bindings.c',[
 ('typedef struct CBindings CBindings;', '''typedef struct CBindingPublished
{
    uint32_t names, count, cursor, rekeyed;
    uint32_t rows[3];
    bool failed, rewrite, oracle;
} CBindingPublished;

typedef struct CBindings CBindings;'''),
 ('    uint32_t* heads;\n    uint32_t name_capacity;', '    CBindingPublished* published;\n    uint32_t* heads;\n    uint32_t name_capacity;'),
 ('// Always inlined (#880), as profile-guided builds do; hot caller: check_input_resolve_range, once per declaration.',func+'// Always inlined (#880), as profile-guided builds do; hot caller: check_input_resolve_range, once per declaration.'),
 (append,'''        const bool retained = bindings->published && c_bindings_published_event(bindings, event, space, name, token, point, depth, operation, kind);
        if (!retained)
        {
'''+ '\n'.join('    '+l for l in append.splitlines())+'''
        }
        else
        {
            if (bindings->key[event] != key)
            {
                bindings->key[event] = key;
                bindings->published->rekeyed += 1;
            }
            // A declaration is live now. Its prefix visibility end may be known from a future restore.
            if (operation == C_BINDING_DECLARE) bindings->end[event] = BUSTER_C_BINDING_NONE;
        }'''),
 (restore, '''        const bool retained = bindings->published && c_bindings_published_event(bindings, event, C_BINDING_ORDINARY, 0, mark, point, 0, C_BINDING_RESTORE, 0);
        if (!retained)
        {
'''+ '\n'.join('    '+l for l in restore.splitlines())+'''
        }''')])
apply('c_check_input.c',[
 ('    Arena* pages;\n    CBindings columns;', '    Arena* pages;\n    CBindingPublished stream;\n    bool stream_enabled, corrupt_stream;\n    CBindings columns;'),
 ('    current->kind = state->columns.kind;','''    current->kind = state->columns.kind;
    if (!state->capture && state->stream_enabled)
    {
        current->published = &state->stream;
        if (state->corrupt_stream && state->stream.count) current->point[0] ^= 1u;
    }'''),
 ('    const CBindings* events = &reader->bindings;\n    uint32_t count = 0;','''    const CBindings* events = &reader->bindings;
    if (state->stream_enabled)
    {
        state->captured_events = events->count;
        state->stream = (CBindingPublished){ .names = events->name_capacity, .count = events->count,
            .rewrite = state->rewrite_pages, .oracle = state->audit_pages };
        return;
    }
    uint32_t count = 0;'''),
 ('    if (row->name != identifier || row->prefix_event != bindings->count || !check_live_scope_matches(reader)) return false;', '''    if (row->name != identifier || row->prefix_event != bindings->count) return false;
    if (state->stream_enabled)
    {
        const CBindingPublished* stream = bindings->published;
        if (stream == NULL || stream->failed || stream->cursor != bindings->count || stream->cursor >= stream->count) return false;
    }
    else if (!check_live_scope_matches(reader)) return false;'''),
 ('    if (state->pages_taken && bindings->operation == state->columns.operation && !state->rewrite_pages)', '    if (!state->stream_enabled && state->pages_taken && bindings->operation == state->columns.operation && !state->rewrite_pages)'),
 ('                if (reader.live_bindings->pages != NULL)\n                    fprintf(stderr, "pre-eof-binding-pages', '''                if (reader.live_bindings->stream_enabled)
                {
                    const CBindingPublished* st = &reader.live_bindings->stream;
                    fprintf(stderr, "pre-eof-event-stream\\tcaptured=%u\\tmatched=%u\\tdeclares=%u\\tuses=%u\\trestores=%u\\trekeyed=%u\\tdiverged=%u\\tscope-copy=0\\n",
                            st->count, st->cursor, st->rows[C_BINDING_DECLARE], st->rows[C_BINDING_USE], st->rows[C_BINDING_RESTORE], st->rekeyed, st->failed);
                }
                if (reader.live_bindings->pages != NULL)
                    fprintf(stderr, "pre-eof-binding-pages''')])
apply('c_checker_driver.c',[('                                bindings->pages = &parser->live_binding_pages;','''                                bindings->pages = &parser->live_binding_pages;
                                bindings->stream_enabled = getenv("BUSTER_PRE_EOF_EVENT_STREAM") != NULL;
                                bindings->corrupt_stream = getenv("BUSTER_PRE_EOF_SCOPE_MISMATCH") != NULL;''')])
