from pathlib import Path
import re
d=Path(__file__).resolve().parents[1]/'lower-cost-source-backend/src/buster/compiler'
s=(d/'c_check_input.c').read_text()
test=(d/'c_check_attested_test.c').read_text()
new={}
for k, names in {
  'OWN':'source_controls early_classes closed_contexts closed_ignored early_masks projected_facts',
  'TRANSIENT':'closed_position context_assertion_end projected project_after value_base pending_root_begin pending_root_end',
  'MEASURE':'closed_roots snapshots roots_with_nodes',
  'AMBIENT':'context_ineligible consume_classes audit_classes grow_graph_limit grow_on_first_node grow_argument_limit',
}.items():
 for name in names.split():new[name]=k
for struct,group in [('CheckInput','input'),('CheckInputReader','reader')]:
 block=s.split('struct '+struct+'\n{\n',1)[1].split('\n};',1)[0]
 without=re.sub(r'//[^\n]*|/\*.*?\*/','',block,flags=re.S)
 fields=[]
 for line in without.split(';'):
  line=line.strip()
  if line and re.search(r'\w',line):
   m=re.search(r'(\w+)\s*(?:\[[^]]*\]\s*)*$',line)
   if m: fields.append(m.group(1))
 old=test.split('const CheckAttestedField check_attested_'+group+'_fields[] =\n{',1)[1].split('\n};',1)[0]
 klass=dict(re.findall(r'\{ "(\w+)", CHECK_ATTESTED_FIELD_(\w+) \}',old))
 print(struct,'actual',len(fields),'listed',len(klass),'missing:',[f for f in fields if f not in klass],'parser could not see:',[f for f in klass if f not in fields])
 if group=="reader":
  assert set(fields)==set(klass)|set(new)
  updated="\n".join('    { "'+name+'", CHECK_ATTESTED_FIELD_'+(klass[name] if name in klass else new[name])+' },' for name in fields)
  test=test.replace(old,"\n"+updated)
(d/'c_check_attested_test.c').write_text(test)
