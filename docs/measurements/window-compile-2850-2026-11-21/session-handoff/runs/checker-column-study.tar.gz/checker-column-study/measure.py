from pathlib import Path
import hashlib,json,os,re,shlex,subprocess,tempfile
d=Path(__file__).resolve().parent; w=d.parent; tree=w/'live-native-combined'; c=tree/'src/buster/compiler/c_check_input.c'; code=c.read_text()
cmd=next(v for v in json.loads((tree/'build/compile_commands.json').read_text()) if v['file'].endswith('/main_unit_checker.c'))
args=shlex.split(cmd['command']);args=[a for a in args[:args.index('-Xclang')] if not a.startswith('-DCMAKE_INTDIR')]
layout=subprocess.check_output([*args,'-Xclang','-fdump-record-layouts','-fsyntax-only',cmd['file']],cwd=cmd['directory'],stderr=subprocess.PIPE,text=True)
def offset(s,name):
 desc=re.search(r'^\s*0 \| struct '+s+r'\n(.*?)\[sizeof=',layout,re.S|re.M)[1]
 return int(re.search(r'^\s*(\d+) \|   \S[^\n]*?\b'+name+r'$',desc,re.M)[1])
width={'uint8_t':1,'uint16_t':2,'uint32_t':4,'TypeId':4,'uint64_t':8,'int32_t':4}
columns={}
for side,field,typename in re.findall(r'BUSTER_CHECK_(INPUT|OUTPUT)_ARRAY\((\w+), (\w+)\);',code):
 if typename in width:columns[(side,field)]=width[typename]
for name,n in [('syntax',1),('visits',1),('ends',4),('first_child',4),('next_child',4),('closed_ignored',1),('closed_contexts',1),('early_classes',1)]:columns['INPUT',name]=n
fs=[(s,n,offset('CheckInputReader' if s=='INPUT' else 'CheckInput',n),z) for (s,n),z in sorted(columns.items())]
prefix=(w/'sizeof-expression-study/source-regions.py').read_text();srcargs=prefix.split("srcargs='''")[1].split("'''")[0].replace('\\\\0','\\0').replace('$1/pregraph-warning-study', '$1/switch-inputs/../pregraph-warning-study').replace('$1/proof-predefines.h', '$1/switch-inputs/../proof-predefines.h')
with tempfile.TemporaryDirectory(dir=d) as tmp:
 temp=Path(tmp)
 for unit in os.environ.get('COLUMN_UNITS','sqlite main').split():
  inputs=subprocess.check_output(['bash','-c',srcargs,'_',str(w),unit]).decode().strip('\0').split('\0')
  for arm in ['ordinary','source']:
   result=d/(unit+'-'+arm+'.tsv')
   g=temp/'run.gdb';g.write_text(f"""set pagination off
set debuginfod enabled off
set confirm off
python
import gdb,os,struct
cols={fs!r}
seen=set()
def word(addr,n):return int.from_bytes(gdb.selected_inferior().read_memory(addr,n).tobytes(),'little')
out=open('{result}','w',buffering=1)
out.write('stage\\tside\\tfield\\ttokens\\twidth\\tinterior_pages\\tpresent\\texclusive\\tzero_pages\\tff_pages\\tmixed_pages\\tnonzero_values\\tnon_ff_values\\n')
class Observe(gdb.Breakpoint):
 def stop(self):
  reader=int(gdb.parse_and_eval('$rdi'));input=word(reader+{offset('CheckInputReader','output')},8);count=word(input+{offset('CheckInput','token_count')},4)
  if count < 10000 or self.location in seen:return False
  seen.add(self.location)
  inf=gdb.selected_inferior();pm=open('/proc/%d/pagemap'%inf.pid,'rb',buffering=0)
  for s,n,off,z in cols:
   addr=word((reader if s=='INPUT' else input)+off,8)
   if not addr:continue
   lo=(addr+4095)//4096;hi=(addr+(count+1)*z)//4096
   if hi<=lo:continue
   pm.seek(lo*8);entries=struct.unpack('<%dQ'%(hi-lo),pm.read((hi-lo)*8))
   present=exclusive=zero=ff=mixed=nonzero=nonff=0
   for i,flags in enumerate(entries):
    if not flags>>63:continue
    present+=1;exclusive+=(flags>>56)&1
    data=inf.read_memory((lo+i)*4096,4096).tobytes()
    if data==bytes(4096):zero+=1;nonff+=4096//z;continue
    if data==b'\\xff'*4096:ff+=1;nonzero+=4096//z;continue
    mixed+=1
    vals=memoryview(data).cast({{1:'B',2:'H',4:'I',8:'Q'}}[z]);mx=(1<<(8*z))-1
    nonzero+=len(vals)-list(vals).count(0);nonff+=len(vals)-list(vals).count(mx)
   out.write('\\t'.join(map(str,[self.location,s,n,count,z,len(entries),present,exclusive,zero,ff,mixed,nonzero,nonff]))+'\\n')
  pm.close()
  return False
for sym in ['check_input_resolve_range.buster_split','check_input_controls.buster_split','check_input_expressions']:Observe("*'%s'"%sym)
end
run
"""); flags={}
   if arm=='source':
    flags.update({n:'1' for n in 'BUSTER_SOURCE_ROOT_CURSOR BUSTER_SOURCE_CONTROL_MASKS BUSTER_SOURCE_DIRTY_DIAGNOSTICS BUSTER_SOURCE_WARNING_INDEX BUSTER_SOURCE_CLOSE_CONTEXTS BUSTER_SOURCE_CLASS_CONSUMER BUSTER_SOURCE_BORROW_CHILDREN BUSTER_SOURCE_FIRST_NODE BUSTER_CONTROL_EARLY_RELEASE BUSTER_CONTROL_EARLY_NATIVE BUSTER_SOURCE_WRITE_COLUMNS BUSTER_SOURCE_FILE_DATA BUSTER_SOURCE_GROW_GRAPH BUSTER_SOURCE_RETIRE_LISTS BUSTER_CONTROL_SOURCE_NATIVE'.split()})
   obj=temp/'unit.o';obj.unlink(missing_ok=True)
   proc=subprocess.run(['gdb','--batch','-q','-x',g,'--args',tree/'build/compiler','--lanes','1','-c',*inputs,'-o',obj],capture_output=True,env=os.environ|flags,timeout=240)
   (d/(unit+'-'+arm+'.log')).write_bytes(proc.stdout+proc.stderr)
   assert obj.read_bytes()==(w/'source-typed-study'/(unit+'.o')).read_bytes() and len(result.read_text().splitlines())>60
