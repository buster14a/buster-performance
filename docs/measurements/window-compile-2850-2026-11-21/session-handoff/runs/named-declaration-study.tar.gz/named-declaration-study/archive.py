from pathlib import Path
import csv,gzip,hashlib,shutil,subprocess as sp,tarfile,sys,collections
w=Path(__file__).resolve().parent.parent
tree,study,sha=sys.argv[1:4];s=w/study;t=w/tree;a=s/'source-package';a.mkdir(exist_ok=True);base='0e1d5b825801135bf50e79da9d546bc95209ab30'
def digest(b):return hashlib.sha256(b).hexdigest()
def compressed(src,dest):dest.write_bytes(gzip.compress(src.read_bytes(),mtime=0))
for name in ['oracle.py','local_pairs.py','target_pairs.py','pmu.py','build.sh','counter.txt','oracle.tsv','local-ab.tsv','pairs.log','sqlite-stage-pairs.tsv','target-pairs.tsv','target.log','pmu.tsv','pmu.log','probe.py','probe.log','source_counts.py','source-counts.txt','verify-prefixes.py','prefix-oracle.log','prefix-oracle.c']:
 f=s/name
 if f.exists():
  if name.endswith('.tsv'):compressed(f,a/(name+'.gz'))
  else:shutil.copy2(f,a/name)
for name in ['base.stages','candidate.stages','build.log','sqlite-kinds.bin','sqlite-roles.bin']:
 f=s/name
 if f.exists():compressed(f,a/(name+'.gz'))
for name in ['c_check_input.c','c_check_attested_test.c']:
 compressed(t/'src/buster/compiler'/name,a/(name+'.gz'))
(a/'implementation.patch').write_bytes(sp.check_output(['git','-C',t,'diff','--binary',base,sha]));(a/'dco.txt').write_bytes(sp.check_output([w/'buster/build/dco','audit','--base',base,'--head',sha],cwd=t))
dest=a/'corpus';dest.mkdir(exist_ok=True);n=0
for f in sorted((s/'corpus').glob('*.tsv')):
 rows=list(csv.DictReader(f.open(),delimiter='\t'));assert all(r['same']=='1' for r in rows);n+=len(rows);compressed(f,dest/(f.name+'.gz'))
rows=list(csv.DictReader((s/'oracle.tsv').open(),delimiter='\t'));assert all(r['same']=='1' for r in rows); assert len(rows)>=3096 and n==4116
clang=sum(r['mode']=='default' and r['clang_runtime']=='0' for r in rows)
info=[f'parent\t{base}',f'candidate\t{sha}',f'patch-sha256\t{digest((a/"implementation.patch").read_bytes())}',f'local-reference-compiler-sha256\t{digest((w/"main-fbef-clean/build/compiler").read_bytes())}',f'local-candidate-compiler-sha256\t{digest((t/"build/compiler").read_bytes())}',f'local-sqlite-object-sha256\t{digest((s/"sqlite.candidate.o").read_bytes())}',f'local-sqlite-reference-object-sha256\t{digest((s/"sqlite.parent.o").read_bytes())}',f'directed-source-policy-comparisons\t{len(rows)}',f'clang-native-programs\t{clang}',f'frozen-source-policy-comparisons\t{n}'];(a/'revisions.tsv').write_text('\n'.join(info)+'\n')
dest=a/'checker';dest.mkdir(exist_ok=True)
for f in sorted(s.glob('checker-*.log')):
 if 'checks, 0 failures' in f.read_text():compressed(f,dest/(f.name+'.gz'))
if (s/'census').exists():
 census=a/'census';census.mkdir(exist_ok=True)
 for f in (s/'census').glob('*.tsv'):
  compressed(f,census/(f.name+'.gz'))
 for name in ['single-census.py','single-census.sh','census.sh','census-off.sh']:
  if (s/name).exists():shutil.copy2(s/name,census/name)
 grouped=s/'census/group-attested-off/admissions.tsv'
 if grouped.is_file():shutil.copy2(grouped,census/'group-attested-off.tsv')
 mini=census/'two-source';mini.mkdir(exist_ok=True)
 for name in ['one.gdb','two.gdb','route.gdb','a.c','b.c','one.stderr','two.stderr','two-attested-off.stderr','run-two.strace']:
  f=s/'census/mini'/name
  if f.is_file():shutil.copy2(f,mini/name)
(s/'source-package/README.md').write_text(f'''# Named declaration records

`implementation.patch` applies to `{base}`. `revisions.tsv` identifies the signed result `{sha}`, source patch, local compilers and SQLite objects. The local reference was built at `fbef2d68dfc952c269d7a2fd008220341428e727`, which differs from the indicated parent only in `docs/one-core-path.md`. Build the compilers with the repository's pinned Clang 23.1.4 toolchain and `./build.sh`.

The ordinary checker identifies named function definitions, local objects and named parameters. The declaration reader uses source-position typedef bindings and parser-supplied declaration boundaries. It retains existing declaration, binding, initializer and function-body ownership. The admission counts in `counter.txt` come from the private `BUSTER_DECLARATION_CENSUS=1` diagnostic on the SQLite source. The paired raw stage, elapsed and PMU tables and the accepted/refused/mixed control generators are preserved here. The local measurements ran on a Ryzen 9 7940HS under an exclusive physical-core lease. The full SQLite object, statuses and diagnostic streams matched.

The directed corpus has {len(rows):,} paired policy invocations; {clang:,} programs also ran with the same native result as pinned Clang. The frozen SQLite/Buster/Lua/musl corpus contributes {n:,} additional source/policy comparisons, with per-file manifests in `corpus/`. Available successful `test-checker --seed 2850 --part N/8` reports are preserved in `checker/`.

For replay put the scripts in a folder named `{study}`, alongside the baseline checkout `main-fbef-clean`, the candidate checkout `{tree}`, and `switch-inputs/sqlite/sqlite3.c`. `build.sh` preserves the local environment paths and frozen preprocessing flags. `oracle.py` generates sources and compares statuses, streams and complete output bytes. `target_pairs.py` constructs the source-positive, source-negative and mixed controls before `pmu.py` reads them.
''')
if (s/'census/single-admissions.tsv').exists():
 with (a/'README.md').open('a') as f:f.write("\nFresh individual-source admission was 20,864 declarations across 55,570 SQLite tokens, 38,099 across 102,415 Buster tokens, 28,347 across 77,281 Lua tokens and 45,853 across 100,352 musl tokens. Grouped `--attested=off --lanes 1 -c` reproduced these counts across all 1,372 inputs. Grouped multi-source compilation with default attestation takes a different reader, as the two-source GDB control records. See `census/`.\n")
(a/'SHA256SUMS').write_text(''.join(f'{digest(f.read_bytes())}  {f.relative_to(a)}\n' for f in sorted(a.rglob('*')) if f.is_file() and f.name!='SHA256SUMS'))
f=s/'local-source-oracle.tar.xz'
with tarfile.open(f,'w:xz',preset=3) as archive:archive.add(a,arcname='source')
print(f,'sha256',digest(f.read_bytes()))
