from pathlib import Path
w=Path(__file__).resolve().parent.parent;p=w/'named-declaration-records/src/buster/compiler/c_check_input.c';s=p.read_text();i=s.index('struct CheckInputReader\n{');s=s[:i]+'''// An ordinary named declarator whose specifier and optional unqualified pointer levels the parser has delimited.
typedef struct CheckInputPlainDeclaration CheckInputPlainDeclaration;
struct CheckInputPlainDeclaration
{
    uint32_t first;
    uint32_t name;
    TypeId base;
    uint8_t pointers;
};

'''+s[i:];i=s.index('    uint32_t scope_count;',i);s=s[:i]+'''    bool plain_declarations;
    CheckInputPlainDeclaration plain_declaration;
    uint32_t plain_counts[4];
    uint32_t plain_tokens[4];
    uint32_t plain_derivations;
'''+s[i:];i=s.index('        .output = input,',s.index('static bool check_input_run(CheckInput* input'));s=s[:i]+'''        .plain_declarations = fresh_output && complete_translation_unit && deferred == NULL && deferred_tokens == NULL && attested == NULL && parser->errors == 0 &&
                              parser->recovered_types == NULL && !parser->options.scalar && pp->options.published_unused_only && !pp->options.predefines.debug &&
                              !pp->options.predefines.debug_modules && !pp->options.node_window && !pp->options.node_window_constants,
'''+s[i:];idx=s.index('static TypeId check_input_specifiers(CheckInputReader* reader');s=s[:idx]+'''// Read a complete scalar or alias prefix through its name. Declaration registration, prototype scope, initializers,
// redeclarations, and warnings retain their existing source-order entry points. Refusal publishes no semantic facts.
static TypeId check_input_named_specifiers(CheckInputReader* reader, uint32_t* cursor, uint32_t end, bool parameter, uint32_t* storage)
{
    const Parser* parser = reader->parser;
    const uint32_t first = *cursor;
    uint32_t at = first;
    uint32_t storage_name = 0;
    const bool formal = parameter && reader->prototype_depth == 1 && end + 1 < parser->tokens.count && parser->tree.roles[end] == PARSE_ROLE_CLOSE_FUNCTION && parser->tree.depths[end] == 0;
    const bool own = !parameter && reader->specifier_owner == first;
    bool valid = (formal || own) && first < end && parser->tree.roles[first] == PARSE_ROLE_SPECIFIER;
    if (valid && !parameter && (parser->tokens.names[at] == C_NAME_STATIC || parser->tokens.names[at] == C_NAME_EXTERN))
    {
        storage_name = parser->tokens.names[at++];
    }
    const bool qualified = valid && at < end && parser->tokens.names[at] == C_NAME_CONST;
    at += qualified;
    const uint32_t word = at;
    uint32_t declaration = BUSTER_CHECK_NONE;
    TypeId base = 0;
    if (valid && at < end && parser->tree.roles[at] == PARSE_ROLE_SPECIFIER)
    {
        const uint32_t name = parser->tokens.names[at++];
        switch (name)
        {
            case C_NAME_VOID: base = BUSTER_TYPE_VOID; break;
            case C_NAME_BOOL: case C_NAME_BOOL_C99: base = BUSTER_TYPE_BOOL; break;
            case C_NAME_CHAR: base = BUSTER_TYPE_CHAR; break;
            case C_NAME_INT: base = BUSTER_TYPE_INT; break;
            case C_NAME_SHORT: base = BUSTER_TYPE_SHORT; break;
            case C_NAME_LONG: base = BUSTER_TYPE_LONG; break;
            case C_NAME_FLOAT: base = BUSTER_TYPE_FLOAT; break;
            case C_NAME_DOUBLE: base = BUSTER_TYPE_DOUBLE; break;
            case C_NAME_SIGNED: case C_NAME_UNSIGNED:
            {
                const bool unsign = name == C_NAME_UNSIGNED;
                const uint32_t width = at < end && parser->tree.roles[at] == PARSE_ROLE_SPECIFIER ? parser->tokens.names[at] : 0;
                base = width == C_NAME_CHAR ? (unsign ? BUSTER_TYPE_UCHAR : BUSTER_TYPE_SCHAR) : width == C_NAME_SHORT ? (unsign ? BUSTER_TYPE_USHORT : BUSTER_TYPE_SHORT) :
                       width == C_NAME_LONG ? (unsign ? BUSTER_TYPE_ULONG : BUSTER_TYPE_LONG) : (unsign ? BUSTER_TYPE_UINT : BUSTER_TYPE_INT);
                at += width == C_NAME_CHAR || width == C_NAME_SHORT || width == C_NAME_LONG || width == C_NAME_INT;
                break;
            }
            default:
                if (parser->tokens.kinds[word] == PARSE_KIND_IDENTIFIER)
                {
                    const uint32_t handle = c_bindings_lookup(&reader->bindings, C_BINDING_ORDINARY, name);
                    if (handle != 0 && reader->bindings.kind[handle - 1] == C_BINDING_TYPEDEF)
                    {
                        declaration = reader->bindings.declaration[handle - 1];
                        base = reader->declared_types[declaration];
                        valid = base != 0 && reader->output->explicit_abis[declaration] == 0 && check_input_noderef_at(reader->output, declaration) == NULL &&
                                type_qualifiers(base) == 0 && type_extended_qualifiers(reader->types, base) == 0 && type_strip_aligned(reader->types, base) == base;
                    }
                }
                break;
        }
    }
    const uint32_t specifier_end = at;
    while (valid && at < end && at - specifier_end < 2 && parser->tokens.kinds[at] == PARSE_KIND_STAR)
    {
        at += 1;
    }
    const uint8_t kind = base != 0 ? type_kind(reader->types, base) : BUSTER_TYPE_KIND_NONE;
    valid = valid && (kind == BUSTER_TYPE_KIND_INTEGER || kind == BUSTER_TYPE_KIND_FLOATING || kind == BUSTER_TYPE_KIND_VOID ||
                      kind == BUSTER_TYPE_KIND_STRUCT || kind == BUSTER_TYPE_KIND_UNION || kind == BUSTER_TYPE_KIND_POINTER || kind == BUSTER_TYPE_KIND_ENUM) &&
            at < end && at + 1 < parser->tokens.count && parser->tokens.kinds[at] == PARSE_KIND_IDENTIFIER && parser->tree.roles[at] == PARSE_ROLE_OPERAND;
    const uint32_t next = valid ? at + 1 : 0;
    const uint8_t delimiter = valid ? parser->tokens.kinds[next] : 0;
    const bool local = own && reader->scope_count != 0 && (delimiter == PARSE_KIND_SEMI || delimiter == PARSE_KIND_COMMA || delimiter == PARSE_KIND_EQUAL);
    const uint32_t close = valid && parser->tree.roles[next] == PARSE_ROLE_OPEN_FUNCTION ? parser->tree.parents[next] : BUSTER_CHECK_NONE;
    const bool definition = own && reader->scope_count == 0 && close < parser->tokens.count - 1 && parser->tree.roles[close + 1] == PARSE_ROLE_OPEN_BODY;
    valid = valid && (definition || ((base != BUSTER_TYPE_VOID || at != specifier_end) && (local || (formal && (next == end || delimiter == PARSE_KIND_COMMA)))));
    if (valid)
    {
        if (declaration != BUSTER_CHECK_NONE)
        {
            reader->output->declarations[word] = declaration;
            reader->declared_types[word] = base;
            reader->output->explicit_abis[word] = 0;
        }
        memset(reader->ignored + first, 1, specifier_end - first);
        base = type_qualify(reader->types, base, qualified ? BUSTER_TYPE_CONST : 0);
        reader->specifier_c23_auto = BUSTER_CHECK_NONE;
        reader->specifier_constexpr = BUSTER_CHECK_NONE;
        reader->specifier_restrict = BUSTER_CHECK_NONE;
        reader->specifier_attributes = NULL;
        reader->specifier_abi_origin = 0;
        reader->specifier_noderef = NULL;
        reader->specifier_thread_local = false;
        reader->plain_declaration = (CheckInputPlainDeclaration){ .first = specifier_end, .name = at, .base = definition ? 0 : base, .pointers = at - specifier_end };
        const uint32_t family = definition ? 0 : local ? 1 : parser->tree.roles[end + 1] == PARSE_ROLE_OPEN_BODY ? 2 : 3;
        reader->plain_counts[family] += 1;
        reader->plain_tokens[family] += at + 1 - first;
        *storage = storage_name;
        *cursor = specifier_end;
    }
    return valid ? base : 0;
}

'''+s[idx:];idx=s.index('    const Parser* parser = reader->parser;',s.index('static TypeId check_input_specifiers(CheckInputReader* reader'));s=s[:idx]+'''    if (reader->plain_declarations)
    {
        const TypeId prepared = check_input_named_specifiers(reader, cursor, end, parameter, storage_class);
        if (prepared != 0)
        {
            *is_typedef = false;
            *is_inline = false;
            return prepared;
        }
    }
'''+s[idx:];needle='''        if (frame->state == 0)
        {''';idx=s.index(needle,s.index('static void check_input_declarator_step(CheckInputReader* reader, CheckDeclaratorRun* run)\n{'));s=s[:idx]+s[idx:].replace(needle,'''        const CheckInputPlainDeclaration* record = &reader->plain_declaration;
        if (frame->state == 0 && record->base != 0 && record->first == i && record->base == frame->base && !reader->padding_sugar && !reader->objc_attributes &&
            frame->common_attributes == NULL && run->common_attributes == NULL && !frame->group && record->name < frame->end)
        {
            for (uint32_t p = 0; p < record->pointers; p += 1)
            {
                frame->base = check_input_type_result(reader, type_pointer(reader->types, frame->base));
            }
            frame->missing_name = record->name;
            frame->name = record->name;
            frame->state = 1;
            frame->cursor = record->name + 1;
            memset(reader->ignored + i, 1, frame->cursor - i);
            reader->plain_derivations += 1;
            reader->plain_declaration.base = 0;
        }
        else if (frame->state == 0)
        {''',1);idx=s.index('    return valid;\n}',s.index('input->visit_misses += check_input_rare_verify'));s=s[:idx]+'''    if (reader.plain_declarations && getenv("BUSTER_DECLARATION_CENSUS") != NULL)
    {
        fprintf(stderr, "named-declarations definitions=%u/%u locals=%u/%u definition-parameters=%u/%u prototype-parameters=%u/%u derived=%u\\n",
                reader.plain_counts[0], reader.plain_tokens[0], reader.plain_counts[1], reader.plain_tokens[1], reader.plain_counts[2], reader.plain_tokens[2],
                reader.plain_counts[3], reader.plain_tokens[3], reader.plain_derivations);
    }
'''+s[idx:];p.write_text(s)
