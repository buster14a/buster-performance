#!/bin/bash
set -eu -o pipefail
cd "$(dirname "$0")"
mkdir -p hardware-capture
remote='cd ~/buster-fast-bench/2850-codex-step2'
tailscale ssh david@benchpress "$remote && grep -qx COMPLETE declrec1f9-job.log && tar czf - corpora.sh results/ordinary-pair-declrec1f9-sqlite results/factsmain0e1d/revision.txt results/factsmain0e1d/compiler.sha256 results/declrec1f9/revision.txt results/declrec1f9/compiler.sha256 declrec1f9-job.log" | tar -xzf - -C hardware-capture
cd public-root
python3 bench-local/public-compile-record.py declrec1f9 1f985149bc6d6a08de102e8d4c716ce34fb3cffb 7 sqlite
