import csv
import hashlib
import io
from pathlib import Path
import re
import shutil
import statistics
import sys
import tarfile

label, sha, rounds_text, *corpora = sys.argv[1:]
rounds = int(rounds_text)
source = Path("bench-local")
results = source / "raw/results"
out = Path("perf/docs/measurements/window-compile-2850-2026-11-21") / sha[:9]
out.mkdir(parents=True,exist_ok=True)
names = {"sqlite":"SQLite","main":"Buster","lua":"Lua","musl":"musl"}
units = {"sqlite":1,"main":1,"lua":34,"musl":1336}
tokens = {"sqlite":716136,"main":2433922,"lua":571543,"musl":5039639}
parent_label,base,public={
    "selstorage":("main5d880","5d880269932b70962e31bbcdaf71330fa263c423",True),
    "commawords":("main5d880","5d880269932b70962e31bbcdaf71330fa263c423",True),
    "availnatural":("mainfbef","fbef2d68dfc952c269d7a2fd008220341428e727",False),
    "warnquarters":("mainfbef","fbef2d68dfc952c269d7a2fd008220341428e727",False),
    "boundleaves":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "controlroots":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "parseinput":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "discardevents":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "discardcalls":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "demandpure":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "stmtheads":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "smallleaves":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "pendingwins":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "keepcontrol":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "memberfacts":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "stagedense":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "bodyfields":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "pendingnative":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "tierfusion":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "phaselists":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "validleaves":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "tierwidth":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "resolvemasks":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "graphbytes":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "filepages":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "stmtpr3267":("main63a709","63a709e0d4a67e71e86ffb15fb8382124fac3570",True),
    "stmtfinal":("main63a709","63a709e0d4a67e71e86ffb15fb8382124fac3570",True),
    "tierslab":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "bindpub":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "structfacts":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "nearedges":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "closedparse":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "staticterms":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "rareedges":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "staticints":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "bytedepth":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "mainleaves":("main63a709","63a709e0d4a67e71e86ffb15fb8382124fac3570",False),
    "restorededges":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "parenttiles":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "directdepth":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "rankleaves":("main63a709","63a709e0d4a67e71e86ffb15fb8382124fac3570",False),
    "allgraphbytes":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "checkedresolve":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "chartables":("main63a709","63a709e0d4a67e71e86ffb15fb8382124fac3570",False),
    "declrec1f9":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "readertyped":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "postchain":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "discardbits":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "parseedges":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "edgecolumns":("factsmain0e1d","0e1d5b825801135bf50e79da9d546bc95209ab30",False),
    "declname":("mainfbef","fbef2d68dfc952c269d7a2fd008220341428e727",False),
    "availkeys":("mainfbef","fbef2d68dfc952c269d7a2fd008220341428e727",False),
    "actionwrite":("mainfbef","fbef2d68dfc952c269d7a2fd008220341428e727",False),
    "assigndirect":("mainfbef","fbef2d68dfc952c269d7a2fd008220341428e727",False),
    "availexact":("mainfbef","fbef2d68dfc952c269d7a2fd008220341428e727",False),
    "initowner":("mainfbef","fbef2d68dfc952c269d7a2fd008220341428e727",False),
    "selce679":("mainfbef","fbef2d68dfc952c269d7a2fd008220341428e727",False),
}[label]
modes = ["baseline","candidate"]

def rows(path):
    with path.open() as f:
        return list(csv.DictReader(f,delimiter="\t"))

def archive_bytes(archive,filename,data):
    info=tarfile.TarInfo(filename)
    info.size=len(data)
    archive.addfile(info,io.BytesIO(data))

def writer(path,head):
    f=path.open("w")
    w=csv.writer(f,delimiter="\t",lineterminator="\n")
    w.writerow(head)
    return f,w

def deltas(values,metric):
    return [statistics.mean(values["candidate",n,metric])-statistics.mean(values["baseline",n,metric]) for n in range(1,rounds+1)]

def span(seq,digits=4):
    return f'{statistics.median(seq):+,.{digits}f} [{min(seq):+,.{digits}f}, {max(seq):+,.{digits}f}]'.replace('-','−')

def qualifier():
    return (source/f'{label}-ordinary-summary.md').read_text().strip()

table=[qualifier(),"",f"Ryzen 7 9700X CPU 2 compiled each workload in a fresh process on each observation. The earlier compiler used public main `{base}`. The candidate used `{sha}`. The [build receipts](builds.tsv) and [source patch](implementation.patch) identify both native Release executables.","","| Input | Total cycles/token, median [min, max] | User instructions, median | True elapsed ms, median [min, max] | Faster elapsed pairs |","| --- | ---: | ---: | ---: | ---: |"]
for name in corpora:
    raw=results/f'ordinary-pair-{label}-{name}'
    folder=out/name
    folder.mkdir(exist_ok=True)
    order=rows(raw/'order.tsv')
    assert len(order)==8*rounds
    for kind in ["pmu","wall"]:
        for n in range(1,rounds+1):
            grp=[x["mode"] for x in order if x["series"]==kind and int(x["round"])==n]
            assert grp==grp[::-1] and sorted(grp)==sorted(modes*2)
    manifests=sorted(raw.glob("*.objects"))
    objects=(raw/"preflight-baseline.objects").read_bytes()
    assert len(objects.splitlines())==units[name] and len(manifests)==6+8*rounds and all(f.read_bytes()==objects for f in manifests)
    shutil.copy(raw/"preflight-baseline.objects",folder/"objects.tsv")
    shutil.copy(raw/"order.tsv",folder)
    checksum=hashlib.sha256(objects).hexdigest()
    from collections import defaultdict
    values=defaultdict(list)
    checks, cw = writer(folder/"checks.tsv",["run","bytes","sha256"])
    samples, sw = writer(folder/"samples.tsv",["series","round","position","mode","user-cycles","kernel-cycles","user-instructions","kernel-instructions","faults","wall-ms"])
    for path in manifests:
        cw.writerow([path.name,len(objects),checksum])
    with tarfile.open(folder/"reports.tar.xz","w:xz") as arc:
        for mode in modes:
            for kind in ["stage","policy","preflight"]:
                for stream in ["stdout","stderr"]:
                    path=raw/f'{kind}-{mode}.{stream}'
                    blob=path.read_bytes()
                    if kind!="stage":
                        assert blob==(raw/f'{kind}-baseline.{stream}').read_bytes()
                    if kind=="stage" or mode=="baseline":
                        archive_bytes(arc,path.name,blob)
                    cw.writerow([path.name,len(blob),hashlib.sha256(blob).hexdigest()])
        for row in order:
            kind=row['series']; n=int(row['round']); pos=int(row['position']); mode=row['mode']
            stem=raw/f'{kind}-{n}-{pos}'
            if kind=="pmu":
                for stream in ["stdout","stderr"]:
                    assert stem.with_suffix("."+stream).read_bytes()==(raw/f'preflight-baseline.{stream}').read_bytes()
                path=stem.with_suffix(".perf"); b=path.read_bytes(); archive_bytes(arc,path.name,b)
                events=[x for x in csv.reader(b.decode().splitlines()) if len(x)>=5]
                assert len(events)==8 and all(float(x[4])==100 for x in events)
                by={x[2]:int(float(x[0])) for x in events}
                u,k,ui,ki,f=[by[x] for x in ['cycles:u','cycles:k','instructions:u','instructions:k','page-faults']]
                sw.writerow([kind,n,pos,mode,u,k,ui,ki,f,""])
                data={'cycles/token':(u+k)/tokens[name],'user cycles/token':u/tokens[name],'kernel cycles/token':k/tokens[name],'user instructions':ui,'kernel instructions':ki,'PMU process faults':f}
            else:
                path=stem.with_suffix(".wall"); s=path.read_text()
                a=re.search(r'^run 1 list 1.*?: ([\d.]+) ms wall, [\d.]+ ms user, [\d.]+ ms system, \d+ KiB wait4 peak, (\d+) minor faults, (\d+) major,.*status 0$',s,re.M)
                assert a and "time-runs: done, 0 failed processes" in s
                archive_bytes(arc,path.name,("\n".join(l for l in s.splitlines() if l.startswith(("run 1 list","time-runs:")))+"\n").encode())
                data={'wall ms':float(a[1]),'wall minor faults':int(a[2]),'wall major faults':int(a[3])}
                sw.writerow([kind,n,pos,mode,"","","","",a[2],a[1]])
            for key,v in data.items():
                values[mode,n,key].append(v)
    samples.close();checks.close()
    pair, pw = writer(folder/"paired.tsv",["metric","round","candidate-mean","baseline-mean","difference"])
    summary, uw = writer(folder/"paired-summary.tsv",["metric","median-absolute-baseline","median-absolute-candidate","paired-median-difference","min-difference","max-difference","rounds-below-zero"])
    for metric in dict.fromkeys(z[2] for z in values):
        delta=deltas(values,metric)
        for i,v in enumerate(delta,1):
            pw.writerow([metric,i,statistics.mean(values['candidate',i,metric]),statistics.mean(values['baseline',i,metric]),v])
        absolute=lambda m:statistics.median(statistics.mean(values[m,n,metric]) for n in range(1,rounds+1))
        uw.writerow([metric,absolute('baseline'),absolute('candidate'),statistics.median(delta),min(delta),max(delta),sum(x<0 for x in delta)])
    pair.close();summary.close()
    cyc=deltas(values,"cycles/token");w=deltas(values,"wall ms");i=deltas(values,"user instructions")
    row=f'| [{names[name]}]({name}/paired-summary.tsv) | {span(cyc)} | {statistics.median(i):+,.1f} | {span(w)} | {sum(x<0 for x in w)}/{rounds} |'
    table.append(row)
    print(row,flush=True)
    (folder/'README.md').write_text(f'# {names[name]}\n\nEach timed command compiled all {units[name]:,} sources containing {tokens[name]:,} preprocessed tokens. Across {len(manifests)} filesystem checks the candidate and baseline emitted identical complete [ELF object manifests](objects.tsv). [Invocation results](checks.tsv), [order](order.tsv), [individual samples](samples.tsv), [paired means](paired.tsv), [summary](paired-summary.tsv) and [native PMU, warning and timing reports](reports.tar.xz) preserve the observations.\n')
table.extend(["",f"Each independent round used a symmetric ABBA or BAAB order, alternating which compiler started. Each compiler ran twice per round in the PMU series and twice in a separate elapsed-time series with fresh processes. The table's denominator gives the number of rounds for each input. Six additional qualification processes checked each workload. Full Lua and musl in each of these processes compile all source files together. SQLite used ordinary `-c` on CPU 2, and the other corpora used `--lanes 1 -c`. PMU cycles include user and kernel and use the independently established preprocessed tokens for the frozen inputs. Every counter ran 100% of enabled time. Each whole-workload output manifest checked default policy, `-Wall -Wextra`, the `--time-stages` audit and each timed observation. Default and warning-enabled diagnostics were byte-identical between the two compilers for each workload.","","The [experiment command](ordinary-compare-one.sh), [schedule](ordinary-compare.sh), [frozen inputs](corpora.sh) and [object manifest verification](full-chain-manifest.py) reproduce this experiment."])
(out/'README.md').write_text('\n'.join(table)+'\n')
for f in ['ordinary-compare-one.sh','ordinary-compare.sh','full-chain-manifest.py']:
    shutil.copy(source/({'ordinary-compare-one.sh':f'{label}-one.sh','ordinary-compare.sh':f'{label}.sh'}.get(f,f)),out/f)
(out/'ordinary-compare.sh').write_text((out/'ordinary-compare.sh').read_text().replace(f'{label}-one.sh','ordinary-compare-one.sh'))
shutil.copy(source/'raw/corpora.sh',out);shutil.copy('proof-predefines.h',out)
shutil.copy(source/f'{label}.patch',out/'implementation.patch')
bf,bw=writer(out/'builds.tsv',['mode','source','base','applied-patch-sha256','compiler-sha256'])
for mode,lab,rev in [('baseline',parent_label,base),('candidate',label,sha)]:
    proof=(results/lab/'revision.txt').read_text().splitlines()
    patch=proof[1].split()[0] if len(proof)>1 else 'none'
    if mode=="candidate" and not public:
        assert patch==hashlib.sha256((out/'implementation.patch').read_bytes()).hexdigest()
        assert proof[0]==base
    else:
        assert proof==[rev], (proof,rev)
    import subprocess
    if mode=="candidate":
        expected=subprocess.check_output(['git','-C','buster','diff','--binary',base,rev])
        assert expected==(out/'implementation.patch').read_bytes()
    bw.writerow([mode,rev,base,patch,(results/lab/'compiler.sha256').read_text().split()[0]])
bf.close()
