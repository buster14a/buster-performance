#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/../bench-local"
label=declrec1f9
sha256sum "$label.patch" "$label.sh" "$label-one.sh" > "$label.sha256"
remote='cd ~/buster-fast-bench/2850-codex-step2'
tar -cf - "$label.patch" "$label.sh" "$label-one.sh" "$label.sha256" | tailscale ssh david@benchpress "$remote && test ! -e results/$label && test ! -e $label.patch && tar xf - && sha256sum -c $label.sha256 && (setsid nohup bash -c 'bash build-label.sh $label 0e1d5b825801135bf50e79da9d546bc95209ab30 $label.patch && bash $label.sh $label sqlite 1 7' >$label-job.log 2>&1 </dev/null &)"
