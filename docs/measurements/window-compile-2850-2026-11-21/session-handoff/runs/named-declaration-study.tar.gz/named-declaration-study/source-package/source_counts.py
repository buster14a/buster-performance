from pathlib import Path
import gzip,re,collections
w=Path(__file__).resolve().parent.parent;p=w/'fresh-file-study/sqlite-tree.gz';rx=re.compile(r'^\s*(\d+)\s+\d+  (.*?)\s+(\S+)\s+\| (\S+)\s+(\d+)\s+(-?\d+)$');tok=[]
for line in gzip.open(p,'rt',errors='replace'):
 m=rx.match(line.rstrip('\n'))
 if m:tok.append((m[2].strip(),m[3],m[4],int(m[5]),int(m[6])))
counts=collections.Counter();body=-1;groups=collections.Counter();ends=set();primitive={'void','int','signed','unsigned','char','float','double','short','long','_Bool','bool'}
for i,(txt,k,r,dep,par) in enumerate(tok):
 if r=='OPEN_BODY' and dep==0:body=par
 if r!='SPECIFIER' or i and tok[i-1][2]=='SPECIFIER':continue
 j=i
 if tok[j][0] in ('static','extern','register'):j+=1
 if tok[j][0]=='const':j+=1
 base=tok[j];j+=1
 if base[1]!='IDENTIFIER' and base[0] not in primitive:continue
 if base[0] in ('unsigned','signed') and tok[j][0] in ('char','short','long','int'):j+=1
 pref=j
 while j<len(tok) and tok[j][0]=='*' and j-pref<2:j+=1
 if j+1>=len(tok) or tok[j][1]!='IDENTIFIER' or tok[j][2]!='OPERAND':continue
 after=tok[j+1]
 if after[2]=='OPEN_FUNCTION' and dep==0:
  close=after[4];group='function-definition' if tok[close+1][2]=='OPEN_BODY' else 'function-prototype'
 elif par>=0 and tok[par][2]=='CLOSE_FUNCTION' or (par>=0 and tok[par][2]=='SEPARATOR' and tok[tok[par][4]][2]=='CLOSE_FUNCTION'):
  group='parameter'
 elif i<body and after[0] in (',','=',';'):group='local'
 elif after[0] in (',','=',';'):group='global/member'
 else:continue
 groups[group]+=1;counts[group]+=j+1-i
print('parser tokens',len(tok));print('specifiers+declarator names',groups);print('tokens',counts)
