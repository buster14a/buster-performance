from pathlib import Path
import sys,subprocess as sp,shutil
w=Path(__file__).resolve().parent.parent
tree,study,label,sha=sys.argv[1:5]
s=w/study
bench=w/'bench-local'
base='0e1d5b825801135bf50e79da9d546bc95209ab30'
for suffix in ['.sh','-one.sh']:
 f=bench/('filesigf4c'+suffix); (bench/(label+suffix)).write_text(f.read_text().replace('filesigf4c',label));(bench/(label+suffix)).chmod(0o755)
(bench/(label+'.patch')).write_bytes(sp.check_output(['git','-C',w/tree,'diff','--binary',base,sha]))
(s/'submit-sqlite.sh').write_text((w/'fresh-file-study/submit-sqlite.sh').read_text().replace('filesigf4c',label))
(s/'capture-sqlite.sh').write_text((w/'fresh-file-study/capture-sqlite.sh').read_text().replace('filesigf4c',label).replace('f4c75336d7fe1792d053f2385289ca1ce2ade222',sha))
pub=s/'public-root';b=pub/'bench-local';b.mkdir(parents=True,exist_ok=True)
for fn,tgt in [(pub/'buster',w/tree),(pub/'proof-predefines.h',w/'proof-predefines.h'),(b/'raw',s/'hardware-capture')]:
 if not fn.is_symlink():fn.symlink_to(tgt)
for f in [label+'.patch',label+'-one.sh',label+'.sh','full-chain-manifest.py']:
 shutil.copy2(bench/f,b/f)
(b/(label+'-ordinary-summary.md')).write_text('A fresh ordinary reader resolves the specifier, name and pointer shape of bounded named C declarations using source-position bindings. The canonical checker retains declaration and function-body ownership.\n')
(b/'public-compile-record.py').write_text((bench/'public-compile-record.py').read_text().replace('    "readertyped":',f'    "{label}":("factsmain0e1d","{base}",False),\n    "readertyped":'))
print(label,sha)
