from pathlib import Path
p=Path(__file__).resolve().parents[1]/'live-native-references/src/buster/compiler/c_check_program_emit.c';s=p.read_text()
start=s.index('static bool check_live_scalar_key(');stop=s.index('    *key =',start)
s=s[:start]+'''static bool check_live_scalar_key(CheckLiveScalarKey* key, const Tier0Function* f, const CheckProgramLowered* lowered, uint32_t symbols)
{
    // Assembly bodies own separately sized templates and branches.
    if (f->asm_body_count != 0) return false;
'''+s[stop:]
fields=[('call_targets','f->call_count'),('call_first','f->call_count'),('call_argument_counts','f->call_count'),('call_variadic','f->call_count'),('calls','f->call_count'),('argument_locations','f->argument_count'),('argument_classes','f->argument_count'),('argument_sizes','f->argument_count'),('call_result_objects','f->call_count'),('incoming_variadic','f->incoming_variadic != NULL'),('symbol_access','f->symbol_count'),('x87_constants','(uint64_t)f->x87_constant_count * 2'),('vector_constants','(uint64_t)f->vector_constant_count * 8'),('vector_constant_bytes','f->vector_constant_count'),('operations','f->operation_count'),('call_asm','f->call_count'),('label_entries','f->label_count'),('label_tables','f->label_count'),('table_jumps','f->table_count'),('table_addresses','f->table_count'),('call_tails','f->call_count'),('lifetime_entries','f->lifetime_count'),('lifetime_locals','f->lifetime_count')]
n=8+len(fields)
s=s.replace('fields[8];','fields['+str(n+1)+'];\n    uint32_t object_symbols;')
s=s[:s.index('#undef LIVE_FIELD')]+''.join(f'    LIVE_FIELD({j}, {member}, {num});\n' for j,(member,num) in enumerate(fields,8))+f'''#undef LIVE_FIELD
    key->fields[{n}].data = lowered->runtime_order;
    key->fields[{n}].bytes = (size_t)lowered->runtime_symbol_count * sizeof(lowered->runtime_order[0]);
    key->object_symbols = symbols;
    shape->asm_bodies = NULL;
'''+s[s.index('    return true;',s.index('#undef LIVE_FIELD')):]
s=s.replace('const Tier0Function* function, const CheckSourceEncoded* saved)','const Tier0Function* function, const CheckProgramLowered* lowered, uint32_t symbols, const CheckSourceEncoded* saved)')
s=s.replace('if (saved->reference_count || !check_live_scalar_key(&key, function))','if (!check_live_scalar_key(&key, function, lowered, symbols))')
s=s.replace('native->bytes = row->bytes;\n    native->references = NULL;\n    native->access = NULL;','''native->bytes = row->size == saved->length && memcmp(saved->bytes, row->bytes, row->size) == 0 ? row->bytes :
                    check_live_duplicate(state->storage, saved->bytes, saved->length);
    native->references = check_live_duplicate(state->storage, saved->references, (size_t)saved->reference_count * sizeof(*saved->references));
    native->access = check_live_duplicate(state->storage, saved->access, (size_t)symbols + 1);
    if (!native->access || (saved->reference_count && !native->references) || (saved->length && !native->bytes)) return;''')
s=s.replace('const Tier0Function* f, uint32_t symbols, Arena* output)','const Tier0Function* f, const CheckProgramLowered* lowered, uint32_t symbols)')
s=s.replace('if (!check_live_scalar_key(&key, f) || memcmp','if (!check_live_scalar_key(&key, f, lowered, symbols) || symbols != frozen->object_symbols || memcmp')
start=s.index('    CheckSourceEncoded* result = BUSTER_ARENA_PUSH_ARRAY(output, CheckSourceEncoded, 1);',s.index('static CheckSourceEncoded* check_live_take_scalar'))
end=s.index('    return result;',start)
s=s[:start]+'''    CheckSourceEncoded* result = row->native;
    if (state->audit) fprintf(stderr, "pre-eof-tier0-skipped\\t%u\\t%u\\t%llu\\t%u\\t%u\\t%u\\n", opening, f->count,
                              (unsigned long long)result->length, result->reference_count, f->call_count, f->label_count);
'''+s[end:]
s=s.replace('check_live_take_scalar(prefix, program->bodies[0].opening, &function, symbols, output)','check_live_take_scalar(prefix, program->bodies[0].opening, &function, lowered, symbols)')
s=s.replace('check_live_keep_scalar(prefix, program->bodies[0].opening, &function, saved)','check_live_keep_scalar(prefix, program->bodies[0].opening, &function, lowered, symbols, saved)')
s=s.replace('// For an auxiliary-free function, the typed columns, locals, argument locations and scalar\n// settings completely describe selection. Explicitly exclude operations that read symbol access.','// Capture every selection input including the local symbol space and runtime ordering for the final reference remap.')
s=s.replace('    // Exact scalar settings and ABI result remain in shape. These eight pointed-to columns are\n    // compared by value. Other pointed-to arrays have zero length under the guards above.','    // Scalar settings and result ABI stay in shape. Snapshot each pointed-to column at its real extent.')
p.write_text(s)
