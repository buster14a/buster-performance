from pathlib import Path
root=Path('src/buster/compiler')
p=root/'c_checker.c';s=p.read_text();start=s.index('// Four leaves share');end=s.index('typedef struct CheckConstWarning',start);s=s[:start]+'''// An ordinary source identifier holds an object and an ordinary integer constant holds its bits. Both carry their
// exact TypeId. The high nibble gives the category and flags shared by values from the C input producer.
typedef struct CheckGraphSmallLeaf CheckGraphSmallLeaf;
struct CheckGraphSmallLeaf
{
    TypeId type;
    uint32_t detail;
};
#define BUSTER_CHECK_LEAF_DATA UINT32_C(0x0fffffff)
#define BUSTER_CHECK_LEAF_EXTENDED UINT32_C(0xf0000000)
#define BUSTER_CHECK_STREAM_IMMEDIATE UINT32_C(0x80000000)
_Static_assert(sizeof(CheckGraphSmallLeaf) == 8, "eight ordinary graph leaves per cache line");

'''+s[end:]
ix=s.index('static inline __attribute__((always_inline)) const CheckGraphLeaf* check_graph_record_at');s=s[:ix]+'''// For an address, the low shape bits stand for function, static storage and a known non-null address. Integer shapes
// retain ICE and the numeric-zero provenance independently. All remaining field combinations use their ordinary row.
static inline uint32_t check_graph_source_detail(const CheckValue* value)
{
    uint32_t result = BUSTER_CHECK_LEAF_EXTENDED;
    if (value->overload_head == 0 && !check_graph_leaf_rest(value))
    {
        const uint32_t flags = value->flags;
        if (value->constant_kind == CHECK_CONSTANT_ADDRESS && (value->category == CHECK_LVALUE || value->category == CHECK_FUNCTION) &&
            (flags & ~(BUSTER_CHECK_STATIC_OBJECT | BUSTER_CHECK_NONNULL_ADDRESS)) == 0 && value->integer == 0 && value->object <= BUSTER_CHECK_LEAF_DATA)
        {
            const uint32_t shape = (value->category == CHECK_FUNCTION) | ((flags & BUSTER_CHECK_STATIC_OBJECT) != 0) << 1 |
                                   ((flags & BUSTER_CHECK_NONNULL_ADDRESS) != 0) << 2;
            result = (shape << 28) | value->object;
        }
        else if (value->constant_kind == CHECK_CONSTANT_INTEGER && value->category == CHECK_RVALUE && value->object == 0 &&
                 (flags & ~(BUSTER_CHECK_ICE | BUSTER_CHECK_LITERAL_ZERO)) == 0 && value->integer <= BUSTER_CHECK_LEAF_DATA)
        {
            const uint32_t shape = 8 | ((flags & BUSTER_CHECK_ICE) != 0) | ((flags & BUSTER_CHECK_LITERAL_ZERO) != 0) << 1;
            result = (shape << 28) | (uint32_t)value->integer;
        }
    }
    return result;
}

static inline CheckGraphLeaf check_graph_source_record(CheckGraphSmallLeaf leaf)
{
    const uint32_t shape = leaf.detail >> 28;
    const uint32_t data = leaf.detail & BUSTER_CHECK_LEAF_DATA;
    const bool integer = shape >= 8;
    return (CheckGraphLeaf){
        .type = leaf.type,
        .flags = integer ? ((shape & 1) ? BUSTER_CHECK_ICE : 0) | ((shape & 2) ? BUSTER_CHECK_LITERAL_ZERO : 0) :
                           ((shape & 2) ? BUSTER_CHECK_STATIC_OBJECT : 0) | ((shape & 4) ? BUSTER_CHECK_NONNULL_ADDRESS : 0),
        .object = integer ? 0 : data,
        .integer = integer ? data : 0,
        .category = integer ? CHECK_RVALUE : (shape & 1) ? CHECK_FUNCTION : CHECK_LVALUE,
        .constant_kind = integer ? CHECK_CONSTANT_INTEGER : CHECK_CONSTANT_ADDRESS,
    };
}

'''+s[ix:]
a=s.index('if ((leaf.detail & BUSTER_CHECK_LEAF_EXTENDED)');b=s.index('    return decoded;',a);s=s[:a]+'''if (leaf.detail >= BUSTER_CHECK_LEAF_EXTENDED)
    {
        return graph->leaf_records + (leaf.detail & BUSTER_CHECK_LEAF_DATA);
    }
    *decoded = check_graph_source_record(leaf);
'''+s[b:]
for nm in ['flags','object']:
 a=s.index('    return graph->dense_leaves',s.index('static inline uint32_t check_graph_leaf_'+nm+'('));b=s.index('\n}',a);s=s[:a]+f'''    CheckGraphLeaf decoded;
    return graph->dense_leaves != NULL ? graph->dense_leaves[slot].{nm} : check_graph_record_at(graph, slot, &decoded)->{nm};'''+s[b:]
s=s.replace('if ((key & BUSTER_CHECK_LEAF_EXTENDED) != 0 && (key & ~BUSTER_CHECK_LEAF_EXTENDED) >= graph->extended_leaf_count)','if ((key >> 28) >= 12 && (key < BUSTER_CHECK_LEAF_EXTENDED || (key & BUSTER_CHECK_LEAF_DATA) >= graph->extended_leaf_count ||\n            graph->leaf_records[key & BUSTER_CHECK_LEAF_DATA].type != graph->small_leaves[slot].type))')
a=s.index('            const bool extended =');b=s.index('            keep &= extended;',a);s=s[:a]+'''            const bool extended = previous >= BUSTER_CHECK_LEAF_EXTENDED;
            const uint32_t detail = extended ? BUSTER_CHECK_LEAF_EXTENDED : check_graph_source_detail(value);
            if (detail < BUSTER_CHECK_LEAF_EXTENDED)
            {
                *small = (CheckGraphSmallLeaf){ value->type, detail };
                return;
            }
            // A widened slot retains its row through rewrites and speculative graph reuse.
            slot = extended ? previous & BUSTER_CHECK_LEAF_DATA : graph->extended_leaf_count++;
            *small = (CheckGraphSmallLeaf){ value->type, BUSTER_CHECK_LEAF_EXTENDED | slot };
'''+s[b:]
ix=s.index('// A node\'s value in a typed stream');s=s[:ix]+'''// An inline positive integer shares the sparse row index with ordinary CheckValue rows. The producer enables this
// representation only for a bounded graph with fewer than 2^28 nodes.
static inline uint32_t check_stream_immediate(uint32_t row)
{
    return (int32_t)row < 0 ? row & ~BUSTER_CHECK_STREAM_IMMEDIATE : 0;
}

'''+s[ix:]
a=s.index('    const CheckValue* whole = NULL;');s=s[:a]+s[a:].replace('    const CheckValue* whole = NULL;', '    const CheckValue* whole = NULL;\n    uint32_t immediate = 0;',1).replace('        whole = row != 0','        immediate = check_stream_immediate(row);\n        whole = row != 0',1).replace('_mm512_storeu_si512(bytes, _mm512_zextsi128_si512(header));','_mm512_storeu_si512(bytes, _mm512_inserti32x4(_mm512_zextsi128_si512(header), _mm_cvtsi32_si128((int)immediate), 1));',1).replace('.object = stream->value_objects[node],','.object = stream->value_objects[node],\n                .integer = check_stream_immediate(row),',1)
ix=s.index('    CheckGraphLeaf decoded;',s.index('void check_graph_leaf(const TypeTable*'));s=s[:ix]+'''    if (graph->small_leaves != NULL && stream->zero_columns && graph->small_leaves[slot].detail < BUSTER_CHECK_LEAF_EXTENDED)
    {
        const CheckGraphLeaf leaf = check_graph_source_record(graph->small_leaves[slot]);
        stream->conversions[node].operands[0].type = leaf.type;
        if (type_is_valid(types, leaf.type))
        {
            stream->value_types[node] = leaf.type;
            stream->value_categories[node] = leaf.category;
            stream->value_flags[node] = leaf.flags;
            stream->value_constants[node] = leaf.constant_kind;
            stream->value_objects[node] = leaf.object;
            if (leaf.integer != 0)
            {
                stream->payload_rows[node] = BUSTER_CHECK_STREAM_IMMEDIATE | (uint32_t)leaf.integer;
            }
        }
        else
        {
            stream->diagnostics[node] = CHECK_DIAG_INVALID_TYPE;
        }
        stream->statistics.vector_nodes += 1;
        return;
    }
'''+s[ix:];p.write_text(s)
p=root/'c_check_program_templates.c';s=p.read_text().replace('        value.type = stream->value_types[node];','        value.integer = check_stream_immediate(row);\n        value.type = stream->value_types[node];',1).replace('const bool payloaded = row == 0 || payload != NULL;', 'const bool payloaded = row == 0 || check_stream_immediate(row) != 0 || payload != NULL;').replace('uint64_t bits = payload != NULL ? (uint64_t)payload->integer : 0;', 'uint64_t bits = payload != NULL ? (uint64_t)payload->integer : check_stream_immediate(row);');p.write_text(s)
p=root/'c_check_transitions.c';s=p.read_text().replace('    const CheckValue* payload = row != 0 ? stream->payloads + row - 1 : NULL;', '''    CheckValue immediate;
    const CheckValue* payload = row != 0 && row <= stream->payload_count ? stream->payloads + row - 1 : NULL;
    if (check_stream_immediate(row) != 0)
    {
        immediate = check_stream_value(stream, node);
        payload = &immediate;
    }''');p.write_text(s)
p=root/'c_check_common_warnings.c';s=p.read_text().replace('result = payload ? stream->payloads[row - 1].integer : 0;', 'result = payload ? stream->payloads[row - 1].integer : check_stream_immediate(row);').replace('const __mmask16 rowed = _mm512_mask_cmpneq_epu32_mask(int_constant, rows, _mm512_setzero_si512());', '''const __mmask16 rowed = _mm512_mask_cmpgt_epi32_mask(int_constant, rows, _mm512_setzero_si512());
            const __m512i immediates = _mm512_and_si512(rows, _mm512_set1_epi32(INT32_MAX));''').replace('const __m512i values = _mm512_mask_i32gather_epi32(_mm512_setzero_si512(), rowed, offsets,','const __m512i values = _mm512_mask_i32gather_epi32(immediates, rowed, offsets,');p.write_text(s)
