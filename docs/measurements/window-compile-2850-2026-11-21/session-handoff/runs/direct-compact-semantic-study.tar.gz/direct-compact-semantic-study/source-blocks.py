from pathlib import Path
p=Path('src/buster/compiler/c_checker.c');s=p.read_text();ix=s.index('// Count/place/fill a stable level order');s=s[:ix]+'''// VALUE has no operands and does not intern a type. Check sixteen source operators together, publishing the valid
// compact leaves without allocating a payload or an action. All other lanes retain their order, including a type
// that wasn't valid at block entry. The sparse integer remains in its node's payload word through later operations.
static uint32_t check_graph_source_blocks(TypeTable* types, const CheckGraph* graph, CheckStream* stream, CheckValue* arguments, Arena* scratch)
{
    uint32_t node = 0;
    const __m512i zero = _mm512_setzero_si512();
    for (; graph->count - node >= 16; node += 16)
    {
        const __m512i ops = _mm512_loadu_si512(graph->ops + node);
        const __mmask16 leaves = _mm512_cmpeq_epi32_mask(ops, _mm512_set1_epi32(CHECK_OP_VALUE));
        uint32_t pending = UINT16_MAX;
        if (leaves != 0)
        {
            const __m512i slots = _mm512_loadu_si512(graph->leaf_slots + node);
            const __m512i detail = _mm512_mask_i32gather_epi32(zero, leaves, slots, &graph->small_leaves[0].detail, 8);
            const __m512i shape = _mm512_srli_epi32(detail, 28);
            const __mmask16 compact = _mm512_mask_cmplt_epu32_mask(leaves, shape, _mm512_set1_epi32(12));
            const __m512i type = _mm512_mask_i32gather_epi32(zero, compact, slots, &graph->small_leaves[0].type, 8);
            const __m512i index = _mm512_srli_epi32(type, BUSTER_TYPE_INDEX_SHIFT);
            // type_is_valid checks the kind byte as well as its bound. Leave the last up to three kinds to the
            // ordinary checker so that a dword gather cannot cross the end of the type table.
            const __m512i limit = _mm512_set1_epi32((int)(types->types.count >= 3 ? types->types.count - 3 : 0));
            const __mmask16 bounded = _mm512_mask_cmpneq_epi32_mask(compact, index, zero) & _mm512_cmplt_epu32_mask(index, limit);
            const __m512i kind = _mm512_and_si512(_mm512_mask_i32gather_epi32(zero, bounded, index, types->types.kind, 1), _mm512_set1_epi32(255));
            const __mmask16 valid = _mm512_mask_cmpneq_epi32_mask(bounded, kind, _mm512_set1_epi32(BUSTER_TYPE_KIND_NONE));
            const __mmask16 integer = _mm512_mask_cmpge_epi32_mask(valid, shape, _mm512_set1_epi32(8));
            const __mmask16 address = valid & (__mmask16)~integer;
            const __m512i data = _mm512_and_si512(detail, _mm512_set1_epi32(BUSTER_CHECK_LEAF_DATA));
            const __mmask16 bit0 = _mm512_test_epi32_mask(shape, _mm512_set1_epi32(1));
            const __mmask16 bit1 = _mm512_test_epi32_mask(shape, _mm512_set1_epi32(2));
            const __mmask16 bit2 = _mm512_test_epi32_mask(shape, _mm512_set1_epi32(4));
            const __m512i address_flags = _mm512_or_si512(_mm512_maskz_set1_epi32(bit1, BUSTER_CHECK_STATIC_OBJECT), _mm512_maskz_set1_epi32(bit2, BUSTER_CHECK_NONNULL_ADDRESS));
            const __m512i integer_flags = _mm512_or_si512(_mm512_maskz_set1_epi32(bit0, BUSTER_CHECK_ICE), _mm512_maskz_set1_epi32(bit1, BUSTER_CHECK_LITERAL_ZERO));
            const __m512i categories = _mm512_mask_blend_epi32(bit0, _mm512_set1_epi32(CHECK_LVALUE), _mm512_set1_epi32(CHECK_FUNCTION));
            const __m512i constants = _mm512_mask_blend_epi32(integer, _mm512_set1_epi32(CHECK_CONSTANT_ADDRESS), _mm512_set1_epi32(CHECK_CONSTANT_INTEGER));
            _mm512_mask_storeu_epi32(stream->value_types + node, valid, type);
            _mm512_mask_storeu_epi32(stream->value_flags + node, valid, _mm512_mask_blend_epi32(integer, address_flags, integer_flags));
            _mm512_mask_storeu_epi32(stream->value_objects + node, address, data);
            _mm_mask_storeu_epi8(stream->value_categories + node, address, _mm512_cvtepi32_epi8(categories));
            _mm_mask_storeu_epi8(stream->value_constants + node, valid, _mm512_cvtepi32_epi8(constants));
            const __mmask16 immediate = _mm512_mask_cmpneq_epi32_mask(integer, data, zero);
            _mm512_mask_storeu_epi32(stream->payload_rows + node, immediate, _mm512_or_si512(data, _mm512_set1_epi32((int)BUSTER_CHECK_STREAM_IMMEDIATE)));
            const __m512i iota = _mm512_setr_epi32(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15);
            const __m512i offsets = _mm512_mullo_epi32(iota, _mm512_set1_epi32(sizeof(CheckNodeConversions)));
            _mm512_mask_i32scatter_epi32(&stream->conversions[node].operands[0].type, valid, offsets, type, 1);
            stream->statistics.vector_nodes += (uint32_t)__builtin_popcount(valid);
            pending ^= valid;
        }
        while (pending != 0)
        {
            const uint32_t at = node + (uint32_t)__builtin_ctz(pending);
            if (graph->ops[at] == CHECK_OP_VALUE)
            {
                check_graph_leaf(types, graph, stream, at);
            }
            else
            {
                check_graph_scalar_node(types, graph, stream, at, arguments, scratch);
            }
            pending &= pending - 1;
        }
    }
    return node;
}

'''+s[ix:];q='        const bool regions = options->regions || options->level_order;';s=s.replace(q,q+'''
        if (!transitions && !regions && zero_output && graph->small_leaves != NULL && graph->overload_candidate_count == 0 &&
            !BUSTER_SCALAR_PATH(options->scalar) && getenv("BUSTER_COMPACT_SCALAR") == NULL)
        {
            node = check_graph_source_blocks(types, graph, stream, arguments, scratch);
        }''');p.write_text(s)
