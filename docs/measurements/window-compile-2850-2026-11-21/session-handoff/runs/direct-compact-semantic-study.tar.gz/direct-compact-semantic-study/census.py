from pathlib import Path
import sys
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parent/'main-typed-reserve-study'))
from common import CC,ROOT,args,env,native
import csv,gzip,hashlib,json,re,shlex,subprocess
tree=CC.parent.parent;db=json.loads((tree/'build/cmake/native/compile_commands.json').read_text());e=next(x for x in db if x['file'].endswith('main_unit_checker.c') and 'Release' in x['output']);av=shlex.split(e['command']);blocks=subprocess.run([av[0],*[a for a in av if a.startswith(('-I','-D','-march'))],'-fsyntax-only','-Xclang','-fdump-record-layouts',e['file']],cwd=e['directory'],capture_output=True,check=True).stdout.decode().split('*** Dumping AST Record Layout')
def block(k):return next(b for b in blocks if re.search(r'^\s*0 \| struct '+k+r'\s*$',b,re.M))
def off(t,m):return int(re.search(r'^\s*(\d+) \|   [^ \n][^\n]*?\b'+m+r'\s*$',block(t),re.M)[1])
def sz(t):return int(re.search(r'\[sizeof=(\d+)',block(t))[1])
cfg={t+'.'+k:off(t,k) for t,ff in [('CheckProgram',['input','stream']),('CheckInput',['graph']),('CheckGraph',['count','ops','operand0','operand1','leaf_count','leaf_records','leaf_slots']),('CheckStream',['value_types','value_flags','value_categories','value_constants','value_objects','payload_rows','payloads','payload_count']),('CheckGraphLeaf',['type','flags','integer','row','category','constant_kind','object','overload_head'])] for k in ff}
cfg['stride']=sz('CheckGraphLeaf');cfg['entry']=int(re.search(r'^([0-9a-f]+) [tT] check_lower_node_counts(?:\.buster_split)?$',subprocess.check_output(['nm','-an',CC],text=True),re.M)[1],16)
for n in ('sqlite','main'):
 d=D/'census';d.mkdir(exist_ok=True);scr=d/(n+'.gdb');scr.write_text(f'set pagination off\nset debuginfod enabled off\npython cfg={cfg!r};prefix={str(d/n)!r}\nsource {D}/census-breakpoints.py\nrun\n');obj=d/(n+'.o')
 q=subprocess.run(['gdb','-q','-nx','--batch','-x',scr,'--args',CC,'--lanes','1','-c',*args[n],'-o',obj],env=env,cwd=ROOT,capture_output=True,timeout=210)
 for k,v in [('stdout',q.stdout),('stderr',q.stderr)]:(d/(n+'.'+k+'.gz')).write_bytes(gzip.compress(v,mtime=0))
 assert (d/(n+'.tsv')).exists() and obj.exists(),(n,q.stdout[-400:],q.stderr[-400:]);print(n,hashlib.sha256(obj.read_bytes()).hexdigest(),flush=True);obj.unlink()
