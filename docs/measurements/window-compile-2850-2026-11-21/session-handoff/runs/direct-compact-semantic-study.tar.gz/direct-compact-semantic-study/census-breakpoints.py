import gdb
from collections import Counter
def rd(a,n):return bytes(gdb.selected_inferior().read_memory(a,n))
def val(a,n):return int.from_bytes(rd(a,n),'little')
def col(a,s,n=8):return val(a+cfg[s],n)
class Entry(gdb.Breakpoint):
 def stop(self):
  p=int(gdb.parse_and_eval('$rsi'));g=col(p,'CheckProgram.input')+cfg['CheckInput.graph'];s=col(p,'CheckProgram.stream');n=col(g,'CheckGraph.leaf_count',4);nodes=col(g,'CheckGraph.count',4);buf=rd(col(g,'CheckGraph.leaf_records'),cfg['stride']*n);M=Counter();wide=Counter()
  def get(i,field,m):s=i*cfg['stride']+cfg['CheckGraphLeaf.'+field];return int.from_bytes(buf[s:s+m],'little')
  for i in range(n):
   t,fl,obj,hd,integer,r,cat,k=[get(i,f,h) for f,h in [('type',4),('flags',4),('object',4),('overload_head',4),('integer',8),('row',4),('category',1),('constant_kind',1)]]
   M[cat,k,fl, bool(obj),bool(hd),min(33,integer.bit_length()),bool(r)]+=1;wide[cat,k,fl,bool(obj),bool(hd),integer>0xffffffff,bool(r)]+=1
  for suf,tab in [('detail',M),('tsv',wide)]:
   with open(prefix+'.'+suf,'w') as f:
    f.write('category\tconstant\tflags\tobject\toverload\tinteger\tpayload\tcount\n')
    for key,count in tab.most_common():f.write('\t'.join(str(int(x)) for x in (*key,count))+'\n')
  print('CENSUS',nodes,n);self.enabled=False;return False
Entry('*0x%x'%cfg['entry'],internal=True)
