from pathlib import Path
root=Path('src/buster/compiler');p=root/'c_check_program.c';s=p.read_text();a=s.index('        const void* records = graph->small_leaves');b=s.index('        const bool gathered',a);s=s[:a]+s[b:];a=s.index('            // Each record\'s flags and object, adjacent');b=s.index('            __mmask16 named',a);s=s[:a]+'''            __m512i flags, objects;
            if (graph->small_leaves != NULL)
            {
                const __m512i detail = _mm512_mask_i32gather_epi32(zero, leaves, slots, &graph->small_leaves[0].detail, 8);
                const __m512i shape = _mm512_srli_epi32(detail, 28);
                const __m512i data = _mm512_and_si512(detail, _mm512_set1_epi32(BUSTER_CHECK_LEAF_DATA));
                const __mmask16 address = _mm512_mask_cmplt_epu32_mask(leaves, shape, _mm512_set1_epi32(8));
                const __mmask16 extended = _mm512_mask_cmpeq_epi32_mask(leaves, shape, _mm512_set1_epi32(15));
                const __mmask16 fixed_address = _mm512_mask_test_epi32_mask(address, shape, _mm512_set1_epi32(2));
                const __m512i wide = _mm512_slli_epi32(data, 3);
                flags = _mm512_mask_i32gather_epi32(_mm512_maskz_set1_epi32(fixed_address, BUSTER_CHECK_STATIC_OBJECT), extended, wide, &graph->leaf_records[0].flags, 4);
                objects = _mm512_mask_i32gather_epi32(_mm512_maskz_mov_epi32(address, data), extended, wide, &graph->leaf_records[0].object, 4);
            }
            else
            {
                // Each record's flags and object, adjacent, as one qword: 8 lanes a gather, then the halves apart.
                const __m512i offsets = _mm512_add_epi32(_mm512_slli_epi32(slots, 5), _mm512_set1_epi32((int)offsetof(CheckGraphLeaf, flags)));
                const __m512i low = _mm512_mask_i32gather_epi64(zero, (__mmask8)leaves, _mm512_castsi512_si256(offsets), graph->leaf_records, 1);
                const __m512i high = _mm512_mask_i32gather_epi64(zero, (__mmask8)(leaves >> 8), _mm512_extracti64x4_epi64(offsets, 1), graph->leaf_records, 1);
                flags = _mm512_permutex2var_epi32(low, _mm512_set_epi32(30, 28, 26, 24, 22, 20, 18, 16, 14, 12, 10, 8, 6, 4, 2, 0), high);
                objects = _mm512_permutex2var_epi32(low, _mm512_set_epi32(31, 29, 27, 25, 23, 21, 19, 17, 15, 13, 11, 9, 7, 5, 3, 1), high);
            }
'''+s[b:];p.write_text(s)
p=root/'c_check_expression_input.c';s=p.read_text();a=s.index('    const __m512i words = _mm512_slli_epi32(slots, 3);');b=s.index('    const __mmask16 leaf_pure',a);s=s[:a]+'''    __m512i leaf_types, heads;
    if (graph->small_leaves != NULL)
    {
        leaf_types = _mm512_mask_i32gather_epi32(zero, leaves, slots, &graph->small_leaves[0].type, 8);
        heads = zero;
        if (graph->overload_candidate_count != 0)
        {
            const __m512i detail = _mm512_mask_i32gather_epi32(zero, leaves, slots, &graph->small_leaves[0].detail, 8);
            const __mmask16 extended = _mm512_mask_cmpge_epu32_mask(leaves, detail, _mm512_set1_epi32((int32_t)BUSTER_CHECK_LEAF_EXTENDED));
            const __m512i wide = _mm512_slli_epi32(_mm512_and_si512(detail, _mm512_set1_epi32(BUSTER_CHECK_LEAF_DATA)), 3);
            heads = _mm512_mask_i32gather_epi32(zero, extended, wide, &graph->leaf_records[0].overload_head, 4);
        }
    }
    else
    {
        const __m512i words = _mm512_slli_epi32(slots, 3);
        leaf_types = _mm512_mask_i32gather_epi32(zero, leaves, words, graph->leaf_records, 4);
        heads = _mm512_mask_i32gather_epi32(zero, leaves, _mm512_add_epi32(words, _mm512_set1_epi32(3)), graph->leaf_records, 4);
    }
'''+s[b:];s=s.replace('graph->recorded_pure != NULL && graph->small_leaves == NULL && graph->leaf_records','graph->recorded_pure != NULL && graph->leaf_records');p.write_text(s)
