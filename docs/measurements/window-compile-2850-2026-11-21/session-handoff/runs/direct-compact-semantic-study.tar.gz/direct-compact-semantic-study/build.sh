#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/../direct-compact-semantic-input"
export CMAKE_BUILD_PARALLEL_LEVEL=1
./build.sh --config Release --target compiler
cp ../proof-predefines.h build/predefines.h
