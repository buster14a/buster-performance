set pagination off
set confirm off
set debuginfod enabled off
python entry_addr=17072704; scalar_addr=19370416;replacement=False;layout=(48, 0, 72, 24, 312, 0, 16, 20, 24, 32, 0, 3, 192, 260, 8, 28, 316)
source /home/david/Documents/Codex/2026-11-21/g/work/source-reserve-kind-census-study/reserve-breakpoints.py
run
python print("RESERVE finished",observations,len(pending))
