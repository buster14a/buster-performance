#!/bin/bash
export BUSTER_CONTROL_SOURCE_NATIVE=1
exec /home/david/Documents/Codex/2026-11-21/g/work/source-reserve-kind-census-study/../source-reserve-kind-census/build/compiler "$@"
