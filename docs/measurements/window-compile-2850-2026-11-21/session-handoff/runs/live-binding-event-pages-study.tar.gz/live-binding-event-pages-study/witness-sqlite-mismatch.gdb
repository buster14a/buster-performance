set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
break check_input_resolve_range.buster_split
run
set $prefix_count=*(unsigned int*)(*(unsigned long*)($rdi+16)+1940)
set $early=*(unsigned long*)($rdi+496)
condition 1 *(unsigned int*)(*(unsigned long*)($rdi+16)+1940)==716136
continue
set $reader=$rdi
set $late=*(unsigned long*)($reader+496)
set $state=*(unsigned long*)($reader+8)
set $arena=*(unsigned long*)($state+80)
set $begin=*(unsigned long*)($arena+0)
set $length=*(unsigned long*)($arena+8)
python
import gdb,os,struct
def count_present():
    process=gdb.selected_inferior()
    begin=int(gdb.parse_and_eval('$begin'));length=int(gdb.parse_and_eval('$length'))
    size=os.sysconf('SC_PAGE_SIZE');first=begin//size;end=(begin+length+size-1)//size
    with open('/proc/'+str(process.pid)+'/pagemap','rb') as source:
        source.seek(8*first)
        return sum((x[0]>>63)&1 for x in struct.iter_unpack('<Q',source.read((end-first)*8))) * size
before=count_present()
end
set $block=*(unsigned long*)($state+8)
set $event=*(unsigned int*)($block+24)
set $old=*(unsigned int*)($early+4*$event)
set *(unsigned int*)($early+4*$event)=1234567
set $marked=*(unsigned int*)($late+4*$event)
finish
printf "physical-witness %u %lx %lx %u %u %u %u\n",$prefix_count,$early,$late,$event,$old,$marked,*(unsigned int*)($late+4*$event)
python
print('resident-witness',int(gdb.parse_and_eval('$length')),before,count_present())
end
set *(unsigned int*)($late+4*$event)=0
continue
quit
