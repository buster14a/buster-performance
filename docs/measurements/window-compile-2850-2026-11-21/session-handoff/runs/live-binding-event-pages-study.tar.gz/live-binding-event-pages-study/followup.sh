#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 physical-witness.py >physical-witness.log 2>&1
python3 local-controls.py >local-controls.log 2>&1
