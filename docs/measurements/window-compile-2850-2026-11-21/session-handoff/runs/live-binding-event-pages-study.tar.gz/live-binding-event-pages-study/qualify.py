import csv,os,sys,hashlib,re,subprocess
from pathlib import Path
study=Path(__file__).resolve().parent;work=study.parent
sys.path.insert(0,str(work/'live-scoped-bindings-study'))
from common import workloads,environ,semantic,sha
tree=work/'live-binding-event-pages';baseline=work/'default-integer-control';reader=work/'live-scoped-bindings'
def env(mode,window,audit):
    e=environ('ordinary' if mode=='ordinary' else 'mismatch' if mode=='mismatch' else 'consumer',window,audit)
    if mode not in ('ordinary','scoped'):
        e['BUSTER_PRE_EOF_BINDING_PAGES']='1'
        if audit:e['BUSTER_PRE_EOF_PAGE_ORACLE']='1'
    if mode=='rewrite':e['BUSTER_PRE_EOF_REWRITE_PAGES']='1'
    if mode=='short':e['BUSTER_PRE_EOF_SHORT_RESERVE']='1'
    return e
def comp(mode,args,window,audit=True):
    cc=(baseline if mode=='ordinary' else reader if mode=='scoped' else tree)/'build/compiler'
    p=study/'unit.o';p.unlink(missing_ok=True)
    q=subprocess.run([cc,'--lanes','1','-c',*args,'-o',p],capture_output=True,env=env(mode,window,audit),timeout=150)
    return q.returncode,q.stdout,semantic(q.stderr),sha(p.read_bytes() if p.exists() else b''),q.stderr
def checks():
    with (study/'full.tsv').open('w',buffering=1) as f:
        wr=csv.writer(f,delimiter='\t',lineterminator='\n')
        wr.writerow(['source','window','mode','status','source_events','capacity','reserved_bytes','adopted','shared_uses','physical_bytes','elf_sha','diag_sha'])
        for name,args in workloads.items():
            oracle=comp('ordinary',args,24)[:4]
            for window in ([1,12,24,40,1000] if name=='sqlite' else [1,12,24,60,80,1000]):
                for mode in ['pages','short','mismatch','rewrite']:
                    got=comp(mode,args,window)
                    (study/(name+'-'+str(window)+'-'+mode+'.stderr')).write_bytes(got[-1])
                    assert oracle==got[:4],(name,window,mode,got[:3])
                    met=re.search(rb'^pre-eof-binding-pages\tcaptured=(\d+)\tcapacity=(\d+)\treserved=(\d+)\tadopted=(\d+)\tshared-uses=(\d+)\tshared-bytes=(\d+)',got[-1],re.M)
                    counts=tuple(map(int,met.groups())) if met else (0,)*6
                    wr.writerow([name,window,mode,got[0],*counts,got[3],sha(got[2])])
                    if window==24 and mode=='pages':assert counts[3]==1 and counts[4]==(40058 if name=='sqlite' else 12743),(name,counts)
                    if mode in ('mismatch','rewrite') or (mode=='short' and window==24):assert counts[4]==0,(name,window,mode,counts)
def trace():
    with (study/'trace.tsv').open('w',buffering=1) as f:
        wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['source','mode','events_sha','answers_sha','elf_sha'])
        for name,args in workloads.items():
            for mode in ['pages','rewrite','mismatch']:
                dest=study/('trace-'+name+'-'+mode);e=env(mode,24,True)
                e['LIVE_BINDING_TRACE_TOKENS']=str(716136 if name=='sqlite' else 2433563)
                with Path(str(dest)+'.log').open('wb') as log:
                    subprocess.run([sys.executable,work/'live-scoped-bindings-study/replay-gdb.py',tree,dest,'--','--lanes','1',*args],env=e,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=250)
                shas=[]
                for ext in ['events','answers','o']:
                    actual=Path(str(dest)+'.'+ext).read_bytes()
                    want=(work/'live-prefix-bindings-study'/('trace-'+name+'-ordinary.'+ext)).read_bytes()
                    assert actual==want,(name,mode,ext)
                    shas.append(sha(actual))
                wr.writerow([name,mode,*shas])
if __name__=='__main__':checks();trace()
