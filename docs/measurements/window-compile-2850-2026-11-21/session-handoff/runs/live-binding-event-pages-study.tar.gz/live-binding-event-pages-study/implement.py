from pathlib import Path
s=Path(__file__).resolve().parent
tree=s.parent/'live-binding-event-pages/src/buster/compiler'
def replace(name,points):
 p=tree/name; src=p.read_text()
 for before,after in points:
    assert src.count(before)==1,(p,before)
    src=src.replace(before,after)
 p.write_text(src)
replace('c_parser.c',[('    Arena live_code;','    Arena live_code;\n    Arena live_binding_pages;'),
 ('    arena_release(&parser->live_code);','    arena_release(&parser->live_binding_pages);\n    arena_release(&parser->live_code);')])
replace('c_checker_driver.c',[('                            parser->live_bindings = bindings;','''                            if (getenv("BUSTER_PRE_EOF_BINDING_PAGES") != NULL)
                            {
                                bindings->pages = &parser->live_binding_pages;
                                bindings->rewrite_pages = getenv("BUSTER_PRE_EOF_REWRITE_PAGES") != NULL;
                                bindings->audit_pages = getenv("BUSTER_PRE_EOF_PAGE_ORACLE") != NULL;
                                bindings->short_reserve = getenv("BUSTER_PRE_EOF_SHORT_RESERVE") != NULL;
                            }
                            parser->live_bindings = bindings;''')])
attach='''// The prefix reader first writes its canonical event columns into this parser-owned mapping.
 // The final walk takes the same columns only if they cover its complete ordinary capacity.
 // Its lexical heads and undo stack always belong to that walk. Each ordinary declaration
 // initializes its own row again, so its visibility end can still change with later source.
static void check_live_event_pages(CheckInputReader* reader)
{
    CheckLiveBindings* state = reader->live_bindings;
    CBindings* current = &reader->bindings;
    if (state->pages == NULL || current->count != 0) return;
    if (state->capture)
    {
        if (state->pages->base != NULL) return;
        const uint64_t capacity = (uint64_t)current->capacity * (state->short_reserve ? 1u : 4u);
        if (capacity >= UINT32_MAX) return;
        const uint64_t bytes = (capacity + 1) * 26 + 8 * 63;
        *state->pages = arena_reserve_small(bytes, bytes);
        if (!state->pages->base) return;
        CBindings* columns = &state->columns;
        columns->capacity = (uint32_t)capacity;
#define BUSTER_LIVE_COLUMN(field) columns->field = arena_push_array(state->pages, capacity + 1, sizeof(*columns->field), 64);
        BUSTER_LIVE_COLUMN(key)
        BUSTER_LIVE_COLUMN(declaration)
        BUSTER_LIVE_COLUMN(point)
        BUSTER_LIVE_COLUMN(end)
        BUSTER_LIVE_COLUMN(previous)
        BUSTER_LIVE_COLUMN(depth)
        BUSTER_LIVE_COLUMN(operation)
        BUSTER_LIVE_COLUMN(kind)
#undef BUSTER_LIVE_COLUMN
        if (!columns->kind) { arena_release(state->pages); columns->capacity = 0; return; }
    }
    else
    {
        if (state->pages_taken || !state->pages->base || current->capacity > state->columns.capacity) return;
        state->pages_taken = true;
    }
    current->key = state->columns.key;
    current->declaration = state->columns.declaration;
    current->point = state->columns.point;
    current->end = state->columns.end;
    current->previous = state->columns.previous;
    current->depth = state->columns.depth;
    current->operation = state->columns.operation;
    current->kind = state->columns.kind;
}

'''
replace('c_check_input.c',[
 ('    CheckLiveScopeRow* scope;', '''    Arena* pages;
    CBindings columns;
    uint32_t page_uses, captured_events;
    bool pages_taken, rewrite_pages, audit_pages, short_reserve;
    CheckLiveScopeRow* scope;'''),
 ('static void check_live_keep_scope(CheckInputReader* reader)',attach.replace('\n //','\n//')+'static void check_live_keep_scope(CheckInputReader* reader)'),
 ('    state->scope = BUSTER_ARENA_PUSH_ARRAY(state->storage, CheckLiveScopeRow, count);','    state->captured_events = events->count;\n    state->scope = BUSTER_ARENA_PUSH_ARRAY(state->storage, CheckLiveScopeRow, count);'),
 ('    const uint32_t event = c_bindings_append_target(bindings, C_BINDING_ORDINARY, identifier, token, token, 0,\n                                                     C_BINDING_USE, C_BINDING_OBJECT, true, handle);',
'''    uint32_t event;
    if (state->pages_taken && bindings->operation == state->columns.operation && !state->rewrite_pages)
    {
        // The pointer shares the original prefix storage. This use neither updates heads nor
        // enters the undo stack. Its verified ordinal still owns all eight original fields.
        const uint32_t e = bindings->count;
        if (state->audit_pages && (bindings->key[e] != identifier || bindings->declaration[e] != token ||
            bindings->point[e] != token || bindings->end[e] != BUSTER_C_BINDING_NONE || bindings->previous[e] != handle ||
            bindings->depth[e] != 0 || bindings->operation[e] != C_BINDING_USE || bindings->kind[e] != C_BINDING_OBJECT)) abort();
        const bool ordered = e == bindings->base || token >= bindings->point[e - 1];
        bindings->valid = bindings->valid && e < bindings->capacity && ordered && identifier != 0 && identifier < bindings->name_capacity;
        event = bindings->valid ? ++bindings->count : 0;
        state->page_uses += event != 0;
    }
    else
    {
        event = c_bindings_append_target(bindings, C_BINDING_ORDINARY, identifier, token, token, 0,
                                         C_BINDING_USE, C_BINDING_OBJECT, true, handle);
    }'''),
 ('                    reader.live_bindings = binding_prefix;','                    reader.live_bindings = binding_prefix;\n                    check_live_event_pages(&reader);'),
 ('                fprintf(stderr, "pre-eof-scope-consumed', '''                if (reader.live_bindings->pages != NULL)
                    fprintf(stderr, "pre-eof-binding-pages\\tcaptured=%u\\tcapacity=%u\\treserved=%llu\\tadopted=%u\\tshared-uses=%u\\tshared-bytes=%llu\\n",
                            reader.live_bindings->captured_events, reader.live_bindings->columns.capacity,
                            (unsigned long long)reader.live_bindings->pages->length, reader.live_bindings->pages_taken, reader.live_bindings->page_uses,
                            (unsigned long long)reader.live_bindings->page_uses * 26);
                fprintf(stderr, "pre-eof-scope-consumed''')])
