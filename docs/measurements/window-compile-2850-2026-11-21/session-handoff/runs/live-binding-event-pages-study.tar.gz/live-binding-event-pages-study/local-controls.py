from qualify import *
import statistics
import time
def paired():
 modes=('scoped','rewrite','pages')
 orders=[(0,1,2),(1,2,0),(2,0,1),(2,1,0),(1,0,2),(0,2,1)]
 with (study/'paired.tsv').open('w',buffering=1) as f:
  wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['source','metric','round','arm','wall_ms','instructions_u','cycles_u'])
  for name,args in workloads.items():
   for metric,rounds in [('wall',18 if name=='sqlite' else 6),('pmu',12 if name=='sqlite' else 6)]:
    values={}
    for r in range(rounds):
     for which in orders[r%len(orders)]:
      mode=modes[which]
      exe=(reader if mode=='scoped' else tree)/'build/compiler'
      command=[exe,'--lanes','1','-c',*args,'-o',study/'timed.o']
      if metric=='pmu':command=['perf','stat','--no-big-num','-x,','-e','{instructions:u,cycles:u}','--',*command]
      start=time.perf_counter_ns();q=subprocess.run(command,capture_output=True,env=env(mode,24,False),timeout=150);elapsed=(time.perf_counter_ns()-start)*1e-6
      assert q.returncode==0,(name,mode,q.stderr[:450])
      counts={fields[2]:int(fields[0]) for line in q.stderr.decode().splitlines() if len(fields:=line.split(','))>2 and fields[2] in ('instructions:u','cycles:u')}
      val=(elapsed,counts.get('instructions:u',''),counts.get('cycles:u',''))
      wr.writerow([name,metric,r,mode,*val]);values[(r,mode)]=val
    for k,label in ([(0,'ms')] if metric=='wall' else [(1,'user instructions'),(2,'user cycles')]):
     for ref in ['scoped','rewrite']:
      d=[values[r,'pages'][k]-values[r,ref][k] for r in range(rounds)]
      print(name,label,'pages minus',ref,statistics.median(d),sum(v<0 for v in d),'of',rounds,flush=True)
def directed():
 d=work/'live-prefix-bindings-study/binding-pulsed';sources=sorted(d.glob('*.c'));assert len(sources)==35
 with (study/'pulsed.tsv').open('w',buffering=1) as f:
  wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['source','policy','mode','status','elf_sha','diagnostics_sha'])
  for src in sources:
   for policy,flags in [('default',[]),('warnings',['-Wall','-Wextra','-ferror-limit=0']),('scalar',['--scalar']),('debug',['-g'])]:
    ref=None
    for mode in ['ordinary','pages','mismatch','rewrite']:
     q=comp(mode,[*flags,src],1)
     if ref is None:ref=q[:4]
     assert ref==q[:4],(src,policy,mode,q[:3])
     wr.writerow([src.stem,policy,mode,q[0],q[3],sha(q[2])])
if __name__=='__main__':directed();paired()
