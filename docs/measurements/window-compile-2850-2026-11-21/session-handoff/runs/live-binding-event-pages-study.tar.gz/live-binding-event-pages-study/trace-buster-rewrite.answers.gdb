set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
break check_input_binding_events.buster_split if *(unsigned int*)(*(unsigned long*)($rdi+16)+1940)==2433563
run
set $reader=$rdi
finish
python
import struct, gdb
p=gdb.selected_inferior()
rd=int(gdb.parse_and_eval('$reader'))
def mem(addr,n): return bytes(p.read_memory(addr,n)) if n else b''
def num(addr,n): return int.from_bytes(mem(addr,n),'little')

out=num(rd+16,8)
n=num(out+1940,4)
declarations=num(out+1088,8)
types=num(rd+528,8)
with open('/home/david/Documents/Codex/2026-11-21/g/work/live-binding-event-pages-study/trace-buster-rewrite.answers','wb') as f:
 f.write(struct.pack('<I',n));f.write(mem(declarations,n*4));f.write(mem(types,n*4))
end
continue
quit
