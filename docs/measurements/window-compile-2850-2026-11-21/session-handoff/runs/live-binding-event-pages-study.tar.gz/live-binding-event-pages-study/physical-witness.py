"""Mark one prefix-created event in the debugger and observe which branch writes it again."""
import csv
import json
import shlex
from qualify import *
e=json.loads((tree/'build/compile_commands.json').read_text())
entry=next(row for row in e if 'main_unit_checker.c.o' in row['command'])
cmd=shlex.split(entry['command']);cmd=cmd[:cmd.index('-o')]+['-Xclang','-fdump-record-layouts','-fsyntax-only',cmd[-1]]
for flag in ['-emit-llvm','-disable-llvm-passes']:
 if flag in cmd:
    i=cmd.index(flag);del cmd[i]
    if i and cmd[i-1]=='-Xclang':del cmd[i-1]
wrapper=study/'witness-layout-input.c'
wrapper.write_text('#include "'+cmd[-1]+'"\n_Static_assert(sizeof(CheckLiveBindings)>0, "binding record layout");\n')
cmd[-1]=str(wrapper)
cache=study/'witness-complete-layout.txt'
if not cache.exists():
 q=subprocess.run(cmd,cwd=entry['directory'],capture_output=True,timeout=90,check=True)
 cache.write_bytes(q.stdout)
layouts=cache.read_text()
def offset(typename,key):
 begin=re.search(r'^\s*0 \| (?:struct )?'+re.escape(typename)+r'$',layouts,re.M)
 if begin is None:raise ValueError(typename)
 a=begin.start();b=layouts.index('[sizeof=',a)
 return int(re.search(r'^\s*(\d+) \|   \S.*?\b'+key+r'(?:\[\d+\])?$',layouts[a:b],re.M)[1])
B=offset('CheckInputReader','bindings');D=offset('CBindings','depth');V=offset('CheckInputReader','output');N=offset('CheckInput','token_count')
L=offset('CheckInputReader','live_bindings');F=offset('CheckLiveBindings','first');R=offset('CheckLiveUseBlock','rows');E=offset('CheckLiveUseRow','prefix_event')
G=offset('CheckLiveBindings','pages');A=offset('Arena','base');H=offset('Arena','length')
def ptr(at):return f'*(unsigned long*)({at})'
def ui(at):return f'*(unsigned int*)({at})'
with (study/'physical-witness.tsv').open('w',buffering=1) as file:
 wr=csv.writer(file,delimiter='\t',lineterminator='\n');wr.writerow(['source','mode','prefix_tokens','prefix_address','final_address','event_ordinal','initial_depth','marked_depth','after_final','reserved_bytes','resident_before_final','resident_after_final','elf_sha'])
 for name,args in workloads.items():
  for mode in ['pages','rewrite','mismatch']:
   prefix=study/('witness-'+name+'-'+mode);out=Path(str(prefix)+'.o')
   wanted=716136 if name=='sqlite' else 2433563
   script=f"""set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
break check_input_resolve_range.buster_split
run
set $prefix_count={ui(ptr(f'$rdi+{V}')+'+'+str(N))}
set $early={ptr(f'$rdi+{B+D}')}
condition 1 {ui(ptr(f'$rdi+{V}')+'+'+str(N))}=={wanted}
continue
set $reader=$rdi
set $late={ptr(f'$reader+{B+D}')}
set $state={ptr(f'$reader+{L}')}
set $arena={ptr(f'$state+{G}')}
set $begin={ptr(f'$arena+{A}')}
set $length={ptr(f'$arena+{H}')}
python
import gdb,os,struct
def count_present():
    process=gdb.selected_inferior()
    begin=int(gdb.parse_and_eval('$begin'));length=int(gdb.parse_and_eval('$length'))
    size=os.sysconf('SC_PAGE_SIZE');first=begin//size;end=(begin+length+size-1)//size
    with open('/proc/'+str(process.pid)+'/pagemap','rb') as source:
        source.seek(8*first)
        return sum((x[0]>>63)&1 for x in struct.iter_unpack('<Q',source.read((end-first)*8))) * size
before=count_present()
end
set $block={ptr(f'$state+{F}')}
set $event={ui(f'$block+{R+E}')}
set $old={ui('$early+4*$event')}
set {ui('$early+4*$event')}=1234567
set $marked={ui('$late+4*$event')}
finish
printf "physical-witness %u %lx %lx %u %u %u %u\\n",$prefix_count,$early,$late,$event,$old,$marked,{ui('$late+4*$event')}
python
print('resident-witness',int(gdb.parse_and_eval('$length')),before,count_present())
end
set {ui('$late+4*$event')}=0
continue
quit
"""
   scriptfile=Path(str(prefix)+'.gdb');scriptfile.write_text(script)
   environment=env(mode,24,False)
   p=subprocess.run(['gdb','-nx','-batch','-x',scriptfile,'--args',tree/'build/compiler','--lanes','1','-c',*args,'-o',out],capture_output=True,env=environment,timeout=200)
   Path(str(prefix)+'.log').write_bytes(p.stdout+p.stderr)
   assert p.returncode==0,(name,mode,p.stderr)
   match=re.search(rb'(?m)^physical-witness (\d+) ([a-f0-9]+) ([a-f0-9]+) (\d+) (\d+) (\d+) (\d+)$',p.stdout)
   assert match,(name,mode,p.stdout[-500:])
   count,early,late,ordinal,old,marked,after=[int(x,16 if i in [1,2] else 10) for i,x in enumerate(match.groups())]
   expect=1234567 if mode=='pages' else 0
   assert count<wanted and early==late and old==0 and marked==1234567 and after==expect,(name,mode,match.groups())
   elf=sha(out.read_bytes());want=sha((work/'live-prefix-bindings-study'/('trace-'+name+'-ordinary.o')).read_bytes())
   assert elf==want,(name,mode,elf,want)
   ram=re.search(rb'(?m)^resident-witness (\d+) (\d+) (\d+)$',p.stdout)
   assert ram
   wr.writerow([name,mode,count,hex(early),hex(late),ordinal,old,marked,after,*map(int,ram.groups()),elf])
