#!/bin/bash
set -eu -o pipefail
cd "$(dirname "$0")"; d="$PWD"; cd ../live-symbol-pragma-order
clang=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
export PATH="$(dirname "$clang"):$PATH"
./build/compiler test-checker-driver --clang "$clang" --part 2/8 --executable "$PWD/build/compiler" >"$d/driver-2.log" 2>&1
old=0
./build/compiler test-checker-driver --clang "$clang" --part 2/8 --executable "$PWD/../live-native-typed/build/compiler" >"$d/historical-driver-2.log" 2>&1 || old=$?
grep -F 'a prior emitted use keeps its original name and strong undefined binding before late pragmas' "$d/historical-driver-2.log"
test "$old" -ne 0
for i in 1 3 4 5 6 7 8; do
 ./build/compiler test-checker-driver --clang "$clang" --part "$i/8" --executable "$PWD/build/compiler" >"$d/driver-$i.log" 2>&1
done
