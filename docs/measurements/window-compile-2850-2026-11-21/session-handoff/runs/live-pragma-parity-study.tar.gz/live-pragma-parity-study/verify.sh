#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d="$PWD";exec 8>verify.lock;flock -n 8 || exit 0
test ! -f validation-complete || exit 0
python3 switches.py >switches.log 2>&1
cd ../live-symbol-pragma-order
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/
cd "$d"
python3 fixed.py >fixed.log 2>&1
python3 pulsed.py >pulsed.log 2>&1
touch validation-complete
