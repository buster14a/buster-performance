#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 fixed.py >fixed.log 2>&1
python3 pulsed.py >pulsed.log 2>&1
touch validation-complete
