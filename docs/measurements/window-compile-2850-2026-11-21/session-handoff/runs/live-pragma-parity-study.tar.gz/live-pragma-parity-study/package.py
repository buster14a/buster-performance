"""Package the independently reproduced and repaired weak/rename/alias source behavior."""
from pathlib import Path
import csv,hashlib,io,re,subprocess,tarfile
s=Path(__file__).resolve().parent;w=s.parent;joined=w/'live-scoped-pragma-study';e=w/'live-binding-evidence/public'
def rows(p):return list(csv.DictReader(p.open(),delimiter='\t'))
def sha(b):return hashlib.sha256(b).hexdigest()
def rev(t,spec='HEAD'):return subprocess.check_output(['git','-C',w/t,'rev-parse',spec],text=True).strip()
def git(t,*args):return subprocess.check_output(['git','-C',w/t,*args])
assert len(rows(s/'fixed.tsv'))==414 and len(rows(s/'pulsed.tsv'))==140 and len(rows(s/'runtime.tsv'))==15
assert len(rows(joined/'pulsed.tsv'))==700 and len(rows(joined/'trace.tsv'))==6
shards=sorted(s.glob('driver-[1-8].log'));assert len(shards)==8
assertions=sum(int(re.search(r'checker-driver: (\d+) checks, 0 failures',p.read_text())[1]) for p in shards)
message='a prior emitted use keeps its original name and strong undefined binding before late pragmas'
history=[p for p in s.glob('historical-driver-*.log') if message in p.read_text()];assert len(history)>=1
bad=history[0];bad_shard=bad.stem.split('-')[-1];fcount=re.search(r'checker-driver: (\d+) checks, (\d+) failures',bad.read_text());assert int(fcount[2])>=1
dest=e/'14098854b';dest.mkdir(parents=True,exist_ok=True)
arc=dest/'native-symbol-order.tar.xz'
readme='''# Source-order repair for weak, renamed and aliased object references

The ordinary backend uses typed expression controls to discover the first emitted reference to each symbol. A unit with retained symbol pragmas needs those controls when it determines external names and weak binding. Source-owned body retirement could discard them too soon. The corrected reader retains the ordinary controls for such units. The public ordinary route already produced the expected output.

Both distinct providers linked against the original connected reader return 55, because the earlier use of renamed was redirected to other_symbol. The ordinary and corrected readers and Clang return 11. With the strong provider removed, only the original connected reader links, having weakened the reference incorrectly. A legal weak alias that the original connected path rejected with a Tier 0 internal compiler error returns 7 through all the corrected and ordinary paths. The 15 native compile/link/runtime controls retain the actual outcomes.

The native source and symbol matrix has 72 source/policy cases and 414 actual compiler processes. The corrected connected reader matched the complete object and diagnostic output of ordinary Buster in all 72. Clang supplied independent symbol and binding checks in its supported modes. The original connected reader differed in 23 cases. Ordinary, original connected, corrected connected and the underlying public controls produced identical complete SQLite and Buster objects and diagnostics. Another 140 padded, directive-forced source/policy cases matched ordinary after the fix.

The actual registered checker-driver regression failed on the original compiler using shard SHARD/8. With the corrected compiler that shard passed, and all eight corrected checker-driver shards passed ASSERTIONS assertions. On the sibling combined scope-handoff head, the complete eight-column binding state, live scope heads, and exact final type and target arrays matched the ordinary native GDB capture on both real sources. Deliberate scope corruption declined the source binding fast path and still emitted the same oracle outputs. All 140 directive-forced source/policy cases (700 native compiler invocations including ordinary and corrupted controls) also preserved the corrected outputs.

The archive includes the literal sources, native compilation and linking scripts, original failing object and diagnostic evidence, exact statuses and symbol table results, complete checker-driver logs, incremental patches and the five-arm raw GDB comparison. The underlying connected source and public-base reconstruction are in ../176935b2a/live-binding-sources.tar.xz. Use its README to rebuild the original trees. The paths in the scripts identify the local worktree layout. The fixed verification's historical source failure for the alias is intentional.
'''.replace('SHARD',bad_shard).replace('ASSERTIONS',f'{assertions:,}')
def add(t,n,b):i=tarfile.TarInfo(n);i.size=len(b);t.addfile(i,io.BytesIO(b))
with tarfile.open(arc,'w:xz',preset=1) as t:
 add(t,'README.md',readme.encode())
 for n in ['permanent.c','probe.py','probes.tsv','fixed.py','fixed.tsv','fixed-full.tsv','fixed.log','runtime.py','runtime.tsv','pulsed.py','pulsed.tsv','pulsed.log','switches.py','switches.tsv','dco.txt','finish-checker-shards.sh']:
  add(t,'live-pragma-parity-study/'+n,(s/n).read_bytes())
 for p in [*shards,*history,*list((s/'checked').glob('*.c')),*list((s/'linked').glob('*.c')),*list((s/'checked').glob('*.stderr'))]:
  add(t,'live-pragma-parity-study/'+str(p.relative_to(s)),p.read_bytes())
 for p in (s/'checked').glob('*.o'):
  if p.name.startswith(('both-late.default.','weak-alias.default.','late-initializer.default.')):add(t,'native/'+p.name,p.read_bytes())
 for n in ['trace.tsv','pulsed.tsv','verify.py','verify.sh']:
  add(t,'live-scoped-pragma-study/'+n,(joined/n).read_bytes())
 for tname,par,n in [('live-symbol-pragma-order','b769ec80d','connected-symbol-pragma.patch'),('live-scoped-pragma','176935b2a','scoped-symbol-pragma.patch')]:
  add(t,n,git(tname,'diff','--binary',par,'HEAD'))
 builds='tree\trev\tgit_tree\tcompiler_sha\n'
 for tree in ['default-integer-control','live-native-typed','live-symbol-pragma-order','live-scoped-bindings','live-scoped-pragma']:
  builds+=tree+'\t'+rev(tree)+'\t'+rev(tree,'HEAD^{tree}')+'\t'+sha((w/tree/'build/compiler').read_bytes())+'\n'
 add(t,'builds.tsv',builds.encode())
h=sha(arc.read_bytes());(dest/'README.md').write_text(readme[:readme.index('The archive includes')]+'The [source, native symbol observations, complete driver suite, and corrected binding composition](native-symbol-order.tar.xz) have SHA-256 `'+h+'`. The [earlier connected implementation and frozen restore instructions](../176935b2a/live-binding-sources.tar.xz) document the public base.\n')
print(h,assertions,bad.name)
