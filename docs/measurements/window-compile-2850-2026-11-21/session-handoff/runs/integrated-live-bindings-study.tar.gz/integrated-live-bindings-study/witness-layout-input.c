#include "/home/david/Documents/Codex/2026-11-21/g/work/integrated-live-bindings/src/buster/compiler/main_unit_checker.c"
_Static_assert(sizeof(CheckLiveBindings)>0, "binding state");
