"""Physically distinguish original field retention, mutable end-point reset and hidden rewrites."""
from qualify import *
import shlex,json
e=json.loads((tree/'build/compile_commands.json').read_text());entry=next(x for x in e if 'main_unit_checker.c.o' in x['command'])
cmd=shlex.split(entry['command']);cmd=cmd[:cmd.index('-o')]+['-Xclang','-fdump-record-layouts','-fsyntax-only',cmd[-1]]
for o in ['-emit-llvm','-disable-llvm-passes']:
 if o in cmd:
  i=cmd.index(o);del cmd[i]
  if i and cmd[i-1]=='-Xclang':del cmd[i-1]
wrapper=study/'witness-layout-input.c'
wrapper.write_text('#include "'+cmd[-1]+'"\n_Static_assert(sizeof(CheckLiveBindings)>0, "binding state");\n')
cmd[-1]=str(wrapper)
p=subprocess.run(cmd,cwd=entry['directory'],capture_output=True,timeout=90,check=True);layouts=p.stdout.decode()
def off(t,f):
 start=re.search(r'^\s*0 \| (?:struct )?'+t+'$',layouts,re.M);assert start,t
 end=layouts.index('[sizeof=',start.start())
 return int(re.search(r'^\s*(\d+) \|   \S.*?\b'+f+'$',layouts[start.start():end],re.M)[1])
layout={k:off('CBindings',k) for k in ['operation','end','previous','depth']}
B=off('CheckInputReader','bindings');V=off('CheckInputReader','output');N=off('CheckInput','token_count')
L=off('CheckInputReader','live_bindings');C=off('CheckLiveBindings','captured_events');A=off('CheckLiveBindings','pages');AB=off('Arena','base');AL=off('Arena','length')
with (study/'event-mutation.tsv').open('w',buffering=1) as log:
 wr=csv.writer(log,delimiter='\t',lineterminator='\n')
 wr.writerow(['source','mode','prefix_tokens','same_addresses','declaration_ordinal','file_use_ordinal','restore_ordinal','declaration_end','use_end','restore_previous','virtual_bytes','resident_before','resident_after','elf_sha'])
 for name,args in workloads.items():
  for mode in ['candidate','rewrite','mismatch']:
   want=716136 if name=='sqlite' else 2433563
   dest=study/('mutation-'+name+'-'+mode);out=Path(str(dest)+'.o')
   gdb=f"""set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
break check_input_resolve_window.buster_split
run
python
import gdb,struct,os
inf=gdb.selected_inferior()
def rd(a,s): return int.from_bytes(inf.read_memory(a,s),'little')
def wr(a,v): inf.write_memory(a,v.to_bytes(4,'little'))
def ptr(a): return rd(a,8)
def rows(reader):return {{k:ptr(reader+{B}+off) for k,off in {layout!r}.items()}}
r=int(gdb.parse_and_eval('$rdi'));early=rows(r);prefix_tokens=rd(ptr(r+{V})+{N},4)
end
condition 1 *(unsigned int*)(*(unsigned long*)($rdi+{V})+{N})=={want}
continue
disable 1
python
r=int(gdb.parse_and_eval('$rdi'));late=rows(r);assert early==late,(early,late)
st=ptr(r+{L});n=rd(st+{C},4);assert n>1000
arena=ptr(st+{A});begin=ptr(arena+{AB});length=rd(arena+{AL},8)
def resident():
    size=os.sysconf('SC_PAGE_SIZE');first=begin//size;end=(begin+length+size-1)//size
    with open('/proc/'+str(inf.pid)+'/pagemap','rb') as p:
        p.seek(8*first);return size*sum((x[0]>>63)&1 for x in struct.iter_unpack('<Q',p.read((end-first)*8)))
before=resident()
ops=bytes(inf.read_memory(late['operation'],n))
depth=struct.unpack('<'+str(n)+'I',inf.read_memory(late['depth'],4*n))
prev=struct.unpack('<'+str(n)+'I',inf.read_memory(late['previous'],4*n))
ends=struct.unpack('<'+str(n)+'I',inf.read_memory(late['end'],4*n))
d=next(i for i in range(n) if ops[i]==0 and depth[i]==0 and ends[i]==4294967295)
u=next(i for i in range(n) if ops[i]==1 and prev[i] and depth[prev[i]-1]==0)
z=ops.index(bytes([2]))
assert ends[u]==4294967295 and prev[z]==0
wr(late['end']+4*d,1234569);wr(late['end']+4*u,1234567);wr(late['previous']+4*z,1234568)
end
break check_input_binding_events.buster_split if *(unsigned int*)(*(unsigned long*)($rdi+{V})+{N})=={want}
continue
python
x=rd(late['end']+4*d,4);y=rd(late['end']+4*u,4);v=rd(late['previous']+4*z,4)
print('source-event-witness',prefix_tokens,int(early==late),d,u,z,x,y,v,length,before,resident())
wr(late['end']+4*u,4294967295);wr(late['previous']+4*z,0)
end
disable 2
continue
quit
"""
   gf=Path(str(dest)+'.gdb');gf.write_text(gdb)
   q=subprocess.run(['gdb','-nx','-batch','-x',gf,'--args',tree/'build/compiler','--lanes','1','-c',*args,'-o',out],env=env(mode,24,False),capture_output=True,timeout=150)
   Path(str(dest)+'.log').write_bytes(q.stdout+q.stderr)
   assert q.returncode==0,(name,mode,q.stderr[-700:])
   m=re.search(rb'(?m)^source-event-witness ([0-9 ]+)$',q.stdout);assert m,(name,mode,q.stdout[-850:])
   fields=list(map(int,m[1].split()));assert fields[1]==1 and fields[5]==4294967295,fields
   assert fields[6:8]==([1234567,1234568] if mode=='candidate' else [4294967295,0]),fields
   actual=sha(out.read_bytes());assert actual==sha((work/'live-prefix-bindings-study'/('trace-'+name+'-ordinary.o')).read_bytes())
   wr.writerow([name,mode,*fields,actual])
