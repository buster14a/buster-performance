set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
break check_input_resolve_window.buster_split
run
python
import gdb,struct,os
inf=gdb.selected_inferior()
def rd(a,s): return int.from_bytes(inf.read_memory(a,s),'little')
def wr(a,v): inf.write_memory(a,v.to_bytes(4,'little'))
def ptr(a): return rd(a,8)
def rows(reader):return {k:ptr(reader+416+off) for k,off in {'operation': 96, 'end': 72, 'previous': 80, 'depth': 88}.items()}
r=int(gdb.parse_and_eval('$rdi'));early=rows(r);prefix_tokens=rd(ptr(r+16)+1940,4)
end
condition 1 *(unsigned int*)(*(unsigned long*)($rdi+16)+1940)==716136
continue
disable 1
python
r=int(gdb.parse_and_eval('$rdi'));late=rows(r);assert early==late,(early,late)
st=ptr(r+8);n=rd(st+252,4);assert n>1000
arena=ptr(st+80);begin=ptr(arena+0);length=rd(arena+8,8)
def resident():
    size=os.sysconf('SC_PAGE_SIZE');first=begin//size;end=(begin+length+size-1)//size
    with open('/proc/'+str(inf.pid)+'/pagemap','rb') as p:
        p.seek(8*first);return size*sum((x[0]>>63)&1 for x in struct.iter_unpack('<Q',p.read((end-first)*8)))
before=resident()
ops=bytes(inf.read_memory(late['operation'],n))
depth=struct.unpack('<'+str(n)+'I',inf.read_memory(late['depth'],4*n))
prev=struct.unpack('<'+str(n)+'I',inf.read_memory(late['previous'],4*n))
ends=struct.unpack('<'+str(n)+'I',inf.read_memory(late['end'],4*n))
d=next(i for i in range(n) if ops[i]==0 and depth[i]==0 and ends[i]==4294967295)
u=next(i for i in range(n) if ops[i]==1 and prev[i] and depth[prev[i]-1]==0)
z=ops.index(bytes([2]))
assert ends[u]==4294967295 and prev[z]==0
wr(late['end']+4*d,1234569);wr(late['end']+4*u,1234567);wr(late['previous']+4*z,1234568)
end
break check_input_binding_events.buster_split if *(unsigned int*)(*(unsigned long*)($rdi+16)+1940)==716136
continue
python
x=rd(late['end']+4*d,4);y=rd(late['end']+4*u,4);v=rd(late['previous']+4*z,4)
print('source-event-witness',prefix_tokens,int(early==late),d,u,z,x,y,v,length,before,resident())
wr(late['end']+4*u,4294967295);wr(late['previous']+4*z,0)
end
disable 2
continue
quit
