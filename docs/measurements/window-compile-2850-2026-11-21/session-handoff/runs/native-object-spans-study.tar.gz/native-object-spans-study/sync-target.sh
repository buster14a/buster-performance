#!/bin/bash
set -eu
cd "$(dirname "$0")"
d=$PWD
include=$1
out=$d/../native-object-evidence/docs/measurements/window-compile-2850-2026-11-21
case $include in
 writer) dest=$out/418ed8b06; jobs=(object1a55 object418e);;
 relo) dest=$out/83599c1e7; jobs=(objectrelas objectstandalone);;
esac
mkdir -p "$dest/target-reproduction" "$d/target"
for tag in "${jobs[@]}";do
 mkdir -p "$d/target/$tag"
 rsync -az --exclude '*.o' "david@benchpress:buster-fast-bench/2850-codex-step2/results/$tag-individual/" "$d/target/$tag/"
 ssh david@benchpress "cd ~/buster-fast-bench/2850-codex-step2 && cat $tag.log" >"$d/target/$tag/runner.log"
 if [[ $tag != objectstandalone ]];then
  ssh david@benchpress "cd ~/buster-fast-bench/2850-codex-step2 && tar cf - results/$tag/{compiler.sha256,revision.txt,build.log}" | tar xf - -C "$dest/target-reproduction"
 fi
 for unit in sqlite main;do
  [[ -s "$d/target/$tag/$unit/objects.tsv" ]] || exit 10
 done
 tail -1 "$d/target/$tag/runner.log" | grep -Fxq COMPLETE || exit 10
done
tar -cJf "$dest/target-raw.tar.xz" -C "$d/target" "${jobs[@]}"
mkdir -p "$d/expected-$include"
for tag in "${jobs[@]}";do ln -sfn "$d/target/$tag" "$d/expected-$include/$tag";done
python3 "$d/target-report.py" "$dest" "$d/expected-$include"
cp -p "$d/target-report.py" "$dest/target-reproduction/"
