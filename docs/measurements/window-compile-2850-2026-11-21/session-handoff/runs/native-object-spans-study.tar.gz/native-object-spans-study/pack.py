from pathlib import Path
p=Path('src/buster/compiler/c_check_body_source.c')
s=p.read_text().replace('    Arena native_types;', '    Arena native_text_run;\n    Arena native_types;',1);p.write_text(s)
p=Path('src/buster/compiler/c_check_program_emit.c');s=p.read_text()
s=s.replace('    uint32_t unit_atom_count;', '    uint32_t unit_atom_count;\n    uint8_t** text_runs;',1)
s=s.replace('    const CheckSourceBody* source_fields;', '    const CheckSourceBody* source_fields;\n    uint8_t* text_run;',1)
s=s.replace('    CheckSourceField* fields;\n    uint32_t reference_count;', '    CheckSourceField* fields;\n    uint8_t* text_run;\n    uint32_t reference_count;',1)
s=s.replace('''    const uint64_t mark=output->length;
    if (!check_program_emit_code(&run,&lane,0)) return NULL;''','''    const uint64_t mark=output->length;
    Arena packed = unit->native_text_run;
    if (getenv("BUSTER_OBJECT_TEXT_RUNS") != NULL)
    {
        const uint64_t room = BUSTER_X86_ENCODER_CAPACITY(code.count) + 16;
        if (room > packed.capacity - packed.length)
        {
            const uint64_t capacity = room > 262144 ? room : 262144;
            uint8_t* block = arena_push(output, capacity, 16);
            if (block != NULL) packed = (Arena){ .base=block, .capacity=capacity };
            else packed = (Arena){0};
        }
        if (packed.base != NULL) lane.bytes = &packed;
    }
    const uint64_t prior = packed.length;
    if (!check_program_emit_code(&run,&lane,0)) { arena_pop_to(output,mark); return NULL; }''',1)
s=s.replace('    *saved=(CheckSourceEncoded){.bytes=body.bytes,', '''    if (lane.bytes == &packed)
    {
        const uint64_t offset = (uint64_t)(body.bytes - packed.base);
        memset(packed.base + prior, BUSTER_OBJECT_INT3, offset - prior);
        unit->native_text_run = packed;
    }
    *saved=(CheckSourceEncoded){.text_run=lane.bytes == &packed ? packed.base : NULL,.bytes=body.bytes,''',1)
s=s.replace('.resolved_fields=true,.early_source=true,.source_fields=', '.resolved_fields=true,.early_source=true,.text_run=encoded->text_run,.source_fields=',1)
needle='    valid = valid && link_initialize(&result->link, output, output, capacity);'
s=s.replace(needle,needle+'''
    if (valid && getenv("BUSTER_OBJECT_TEXT_RUNS") != NULL)
    {
        result->text_runs = BUSTER_ARENA_PUSH_ARRAY(output, uint8_t*, result->link.atoms.capacity);
        if (result->text_runs != NULL) memset(result->text_runs, 0, (uint64_t)result->link.atoms.capacity * sizeof(*result->text_runs));
    }''',1)
needle='            valid = atom != 0 && symbol != 0 && link_define_symbol(&result->link, symbol, atom, body->prefix, body->length - body->prefix);'
s=s.replace(needle,needle+'\n            if (valid && result->text_runs != NULL) result->text_runs[atom] = body->text_run;',1)
p.write_text(s)
p=Path('src/buster/compiler/object_writer.c');s=p.read_text().replace('struct ObjectOptions\n{','struct ObjectOptions\n{\n    uint8_t* const* text_runs;',1)
i=s.index('static void object_fill_sections(')
s=s[:i]+s[i:].replace('            uint64_t end = 0;', '            const uint8_t* prior_run = NULL;\n            uint64_t end = 0;',1)
i=s.index('                    // Most x86 functions start at 16-byte alignment.')
s=s[:i]+'''                    const uint8_t* run = builder->options.text_runs != NULL ? builder->options.text_runs[atom] : NULL;
                    struct iovec* last = stream->count != 0 ? stream->spans + stream->count - 1 : NULL;
                    if (run != NULL && run == prior_run && last != NULL &&
                        (uintptr_t)last->iov_base + last->iov_len + padding == (uintptr_t)atoms->bytes[atom])
                    {
                        last->iov_len += padding + atoms->size[atom];
                        stream->borrowed += atoms->size[atom];
                        end = offset + atoms->size[atom];
                        continue;
                    }
                    prior_run = run;
'''+s[i:]
p.write_text(s)
p=Path('src/buster/compiler/c_checker_driver.c');s=p.read_text()
i=s.index('static Object check_driver_object_build_file(')
s=s[:i]+s[i:].replace('const ObjectOptions options = {','const ObjectOptions options = {\n            .text_runs = code->text_runs,',1);p.write_text(s)
