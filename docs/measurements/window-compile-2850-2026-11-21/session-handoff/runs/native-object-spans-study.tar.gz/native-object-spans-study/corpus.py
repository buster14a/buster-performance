"""Compare fresh source-owned processes to a previous independent ordinary measurement on identical frozen inputs."""
import csv,hashlib,os,subprocess,sys
from pathlib import Path
d=Path(__file__).resolve().parent;g=sys.argv[1];opts=[a for a in sys.argv[2:] if not a.endswith('.c')];paths=[a for a in sys.argv[2:] if a.endswith('.c')]
prior=(d/'../full-source-diagnostics-study/real-4d6e3d6ce'/(g+'.tsv')).open();expected=iter(csv.DictReader(prior,delimiter='\t'))
env={k:v for k,v in os.environ.items() if not k.startswith(('BUSTER_CONTROL_','BUSTER_BODY_','BUSTER_CHECK_BODY_'))}|{k:'1' for k in ('BUSTER_SOURCE_ROOT_CURSOR','BUSTER_SOURCE_CONTROL_MASKS','BUSTER_SOURCE_DIRTY_DIAGNOSTICS','BUSTER_SOURCE_WARNING_INDEX','BUSTER_SOURCE_CLOSE_CONTEXTS','BUSTER_SOURCE_CLASS_CONSUMER','BUSTER_SOURCE_BORROW_CHILDREN','BUSTER_SOURCE_FIRST_NODE','BUSTER_CONTROL_EARLY_RELEASE','BUSTER_CONTROL_EARLY_NATIVE','BUSTER_SOURCE_WRITE_COLUMNS','BUSTER_SOURCE_FILE_DATA','BUSTER_SOURCE_GROW_GRAPH','BUSTER_SOURCE_RETIRE_LISTS','BUSTER_CONTROL_SOURCE_NATIVE','BUSTER_CONTROL_OBJECT_FIELDS','BUSTER_OBJECT_TEXT_STREAM','BUSTER_OBJECT_TEXT_RUNS')}
out=d/'real';out.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
with (out/(g+'.tsv')).open('w',buffering=1) as f:
 t=csv.writer(f,delimiter='\t');t.writerow('file policy ref-exit source-exit same-object same-stdout same-stderr ref-stderr-size ref-stderr-sha source-stderr-sha ref-object-sha source-object-sha ref-stdout-sha source-stdout-sha'.split())
 for path in paths:
  for policy,flags in [('default',[]),('wall',['-Wall','-Wextra']),('strict',['-Wall','-Wextra','-Werror']),('quiet',['-w']),('everything',['-Weverything'])]:
   a=next(expected);assert (path,policy)==(a['file'],a['policy'])
   obj=out/(g+'-source.o');obj.unlink(missing_ok=True)
   r=subprocess.run([d/'compiler','--lanes','1','-c',*opts,*flags,path,'-o',obj],env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=180)
   o=sha(obj.read_bytes()) if obj.exists() else '';so=sha(r.stdout);se=sha(r.stderr)
   t.writerow((path,policy,a['ref-exit'],r.returncode,int(o==a['ref-object-sha']),int(so==a['ref-stdout-sha']),int(se==a['ref-stderr-sha']),a['ref-stderr-size'],a['ref-stderr-sha'],se,a['ref-object-sha'],o,a['ref-stdout-sha'],so))
   if str(r.returncode)!=a['ref-exit'] or (o,so,se)!=(a['ref-object-sha'],a['ref-stdout-sha'],a['ref-stderr-sha']): (out/(Path(path).name+'-'+policy+'.stderr')).write_bytes(r.stderr)
assert next(expected,None) is None
