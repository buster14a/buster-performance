#!/bin/bash
set -eu
cd "$(dirname "$0")"
d=$PWD
bin=$d/compiler
cd ../switch-inputs
source ../switch-local-args.sh
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main;do
 options=${g}_arguments
 eval "args=(${!options})"
 for mode in spans runs;do
  flags=()
  if [[ $mode == runs ]];then flags+=('BUSTER_OBJECT_TEXT_RUNS=1');fi
  strace -qq -c -e trace=write,pwrite64,writev,pwritev -o "$d/$g-$mode.syscalls" env BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1 BUSTER_SOURCE_WRITE_COLUMNS=1 BUSTER_SOURCE_GROW_GRAPH=1 BUSTER_SOURCE_RETIRE_LISTS=1 BUSTER_SOURCE_FILE_DATA=1 BUSTER_CONTROL_OBJECT_FIELDS=1 BUSTER_OBJECT_TEXT_STREAM=1 BUSTER_OBJECT_STREAM_AUDIT=1 "${flags[@]}" "$bin" --lanes 1 -c "${args[@]}" -o "$d/$g-$mode.o" >"$d/$g-$mode.out" 2>"$d/$g-$mode.audit"
  cmp "$d/$g-$mode.o" "$d/../source-typed-study/$g.o"
  rg 'object-text-stream' "$d/$g-$mode.audit"
 done
done
