from pathlib import Path
import csv,gzip,hashlib,io,json,lzma,os,re,shutil,statistics,subprocess,tarfile,tempfile
d=Path(__file__).resolve().parent
w=d.parent
f=w/"native-object-fields-study"
repo=w/"native-object-spans"
out=w/"native-object-evidence/docs/measurements/window-compile-2850-2026-11-21/418ed8b06"
out.mkdir(exist_ok=True)
def git(*args,env=None):
 return subprocess.check_output(["git",*args],cwd=repo,env=env)
def value(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,header,rows):
 with path.open("w",newline="") as a:
  c=csv.writer(a,delimiter="\t");c.writerow(header);c.writerows(rows)
def packed(src,dest):
 (out/dest).write_bytes(lzma.compress(src.read_bytes()))
chain=["0e1d5b825","966a95df3","86f494bcc","1a552aaf7","418ed8b06"]
write(out/"sources.tsv",("revision","tree","subject"),[git("show","-s","--format=%H%x09%T%x09%s",s).decode().strip().split("\t") for s in chain])
patches=[]
for left,right,name in ((chain[0],chain[-1],"all-from-live-base.patch.xz"),(chain[1],chain[2],"native-fields.patch"),(chain[2],chain[3],"scatter-write.patch"),(chain[3],chain[4],"packed-text.patch")):
 data=git("diff","--binary",left,right)
 with tempfile.TemporaryDirectory() as tmp:
  path=Path(tmp)/"patch";path.write_bytes(data)
  env=dict(os.environ,GIT_INDEX_FILE=str(Path(tmp)/"index"))
  git("read-tree",left,env=env);git("apply","--cached",str(path),env=env)
  result=git("write-tree",env=env).decode().strip();assert result==git("rev-parse",right+"^{tree}").decode().strip()
 (out/name).write_bytes(lzma.compress(data) if name.endswith(".xz") else data)
 patches.append((left,right,name,result))
write(out/"patch-verification.tsv",("base","candidate","patch","verified-git-tree"),patches)
shutil.copy(f/"file-targets.py",out/"compare-writer.py");shutil.copy(d/"file-targets.py",out/"compare-packed-writer.py")
shutil.copy(d/"short-write.gdb",out);shutil.copy(d/"partial-write.log",out)
shutil.copy(d/"interrupted.log",out/"interrupted-syscall.log")
shutil.copy(d/"elf-components.tsv",out)
shutil.copy(d/"oracle.log",out/"packed-output-audit.log")
for study,ref in ((f,"1a552aaf7"),(d,"418ed8b06")):
 packed(study/"targets/cases.tsv",ref+"-compiler-files.tsv.xz")
 shutil.copy(study/"targets/destinations.tsv",out/(ref+"-destinations.tsv"))
packed(f/"sqlite-fields.audit","sqlite-native-fields.log.xz");packed(f/"main-fields.audit","buster-native-fields.log.xz")
records=[]
for group in ("sqlite","main"):
 lines=(f/(group+"-fields.audit")).read_text().splitlines()
 native=[l.split("\t") for l in lines if l.startswith("source-native-fragment\t")]
 for mode in ("spans","runs"):
  match=re.search(r'object-text-stream\tbytes=(\d+)\tspans=(\d+)\tfile=(\d+)',(d/(group+"-"+mode+".audit")).read_text())
  counts=re.search(r'^\s*\S+\s+\S+\s+\S+\s+(\d+)\s+pwritev\s*$',(d/(group+"-"+mode+".syscalls")).read_text(),re.M)
  assert counts
  shutil.copy(d/(group+"-"+mode+".syscalls"),out/(group+"-"+mode+".syscalls"))
  records.append((group,mode,len(native),sum(int(x[2]) for x in native),sum(int(x[3]) for x in native),*map(int,match.groups()),int(counts[1])))
write(out/"native-output.tsv",("input","mode","early-fragments","early-bytes","early-relocations","whole-text-bytes-borrowed","output-spans","total-elf-bytes","pwritev-syscalls"),records)
write(out/"syscall-object-check.tsv",("case","sha256"),[(n,value(d/(n+".o"))) for n in ("raw-reference","partial","interrupted")])
local=[]
for rev,binary,name in (("1a552aaf7",f/"compiler","functional"),("418ed8b06",d/"compiler","functional"),(subprocess.check_output(["git","-C",str(w/"main-fbef-clean"),"rev-parse","HEAD"],text=True).strip(),w/"main-fbef-clean/build/compiler","independent Develop"),("1a552aaf7",w/"native-object-fields/build/compiler","full Develop")):
 if binary.is_file():local.append((rev,name,value(binary)))
write(out/"local-executables.tsv",("revision","role","sha256"),local)
corpora=[]
for name in ("sqlite","main","lua","musl"):
 src=d/"real"/(name+".tsv")
 if src.exists():
  cases=list(csv.DictReader(src.open(),delimiter="\t"))
  if len(cases)=={"sqlite":5,"main":5,"lua":170,"musl":6680}[name]:
   good=sum(r["source-exit"]==r["ref-exit"] and all(r[k]=="1" for k in ("same-object","same-stdout","same-stderr")) for r in cases)
   corpora.append((name,len(cases),good,sum(r["ref-exit"]!="0" for r in cases)))
   packed(src,"corpus-"+name+".tsv.xz")
write(out/"corpus.tsv",("input","observations","exact","ordinary-nonzero"),corpora)
for study,tag in ((f,"object1a55"),(d,"object418e")):
 for suffix in ("-one.sh","-submit.sh"):
  shutil.copy(study/(tag+suffix),out)
timing=f/"timing"
if timing.exists():
 for p in timing.glob("*.tsv"):shutil.copy(p,out/("local-"+p.name))
