#!/bin/bash
set -eu
study=$1
if [[ ! -f "$study/boundary-recheck.log" ]]; then python3 "$study/boundary.py" >"$study/boundary-recheck.log" 2>&1; fi
cd "$(dirname "$0")/../switch-inputs"
source "$study/switch-local-args.sh"
eval "args=($sqlite_arguments)"
python3 "$study/pmu.py" "$study" "${args[@]}"
