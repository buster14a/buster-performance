#!/bin/bash
set -eu
cd "$(dirname "$0")"
python3 boundary.py >boundary-recheck.log 2>&1
bash pmu.sh "$PWD" >pmu.log 2>&1
python3 summary.py >summary.txt
python3 package.py >archive.log
