#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
d=$PWD/runtime
mkdir -p "$d"
root=${PWD%/*}
cd "$root/switch-inputs"
source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
clang=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
cp "$root/pending-native-study/runtime/shell.o" "$d/shell.o"
cp "$root/pending-native-study/runtime/clang.o" "$d/clang.o"
cp "$root/source-linear-roots-study/optimized-run/sqlite.ordinary.o" "$d/ordinary.o"
cp "$root/source-linear-roots-study/optimized-run/sqlite.nested.o" "$d/source.o"
cmp "$d/ordinary.o" "$d/source.o"
for source in clang ordinary source; do
 "$clang" -no-pie "$d/shell.o" "$d/$source.o" -ldl -lpthread -lm -o "$d/$source.bin"
 for test in core dotcommands files queries; do
  cwd=$(mktemp -d "$d/$test.XXXXXXXX")
  sql="$root/pending-native-windows/tests/sqlite/$test.sql"
  if [[ $test == queries ]]; then sql=$root/pending-native-study/queries.sql; fi
  (cd "$cwd" && timeout 30 "$d/$source.bin" -batch :memory: < "$sql") > "$d/$source.$test.stdout" 2> "$d/$source.$test.stderr" && status=0 || status=$?
  echo "$status" > "$d/$source.$test.status"
 done
done
for test in core dotcommands files queries; do
 for f in stdout stderr status; do
  for source in ordinary source; do cmp "$d/$source.$test.$f" "$d/clang.$test.$f"; done
 done
 wc -c "$d/clang.$test.stdout"; cat "$d/clang.$test.status"
done
