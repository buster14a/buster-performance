import csv,hashlib,os,random,subprocess,sys,time
from pathlib import Path
d=Path(__file__).resolve().parent;cc=d.parent/'source-linear-roots/build/compiler';group=sys.argv[1]
flags=sys.argv[2:];os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
native={'BUSTER_CONTROL_SOURCE_NATIVE':'1','BUSTER_CONTROL_EARLY_NATIVE':'1','BUSTER_CONTROL_EARLY_RELEASE':'1'}
roles={'BUSTER_DIRECT_SOURCE_STATEMENTS':'1'}
op=roles|{'BUSTER_DIRECT_OPERATOR_PROGRAM':'1'}
nested=op|{'BUSTER_DIRECT_OPERATOR_CALLS':'1'}
policies={'ordinary':{},'operators':op,'nested':nested,'masked':nested|{'BUSTER_OPERATOR_MASKED_ROOTS':'1'},'native':native,'composed':nested|native|{'BUSTER_COMPOSE_SOURCE_STATEMENTS':'1'}}
owned=policies['composed']|{'BUSTER_SOURCE_ROOT_BODIES':'1'}
policies={'ordinary':{},'nested':policies['nested'],'composed':policies['composed'],'owned':owned,'restricted':owned|{'BUSTER_SOURCE_ROOT_ONLY_SCAN':'1'}}
policies['linear']=policies['owned']|{'BUSTER_SOURCE_LINEAR_BODIES':'1'}
policies['selective']=policies['restricted']|{'BUSTER_SOURCE_LINEAR_BODIES':'1'}
refhash=hashlib.sha256((d/'optimized-run'/(group+'.ordinary.o')).read_bytes()).hexdigest()
fixed={k:v for k,v in os.environ.items() if not k.startswith(('BUSTER_DIRECT_','BUSTER_SOURCE_','BUSTER_CONTROL_','BUSTER_COMPOSE_'))}
with (d/(group+'-four.tsv')).open('w',buffering=1) as out:
 w=csv.writer(out,delimiter='\t');w.writerow(('round','position','policy','stage','ns','sha256','equal'))
 for traced in [False,True]:
  for r in range(8):
   order=list(policies);random.Random(331+r).shuffle(order)
   for i,m in enumerate(order):
    dest=d/(group+'-four.o')
    t=time.perf_counter_ns();p=subprocess.run([cc,'--lanes','1',*(['--time-stages'] if traced else []),'-c',*flags,'-o',dest],capture_output=True,env=fixed|policies[m]);ns=time.perf_counter_ns()-t
    if p.returncode:raise RuntimeError((m,p.stderr[-4096:]))
    h=hashlib.sha256(dest.read_bytes()).hexdigest()
    if not traced:w.writerow((r,i,m,'ordinary',ns,h,h==refhash))
    else:
     for line in p.stderr.decode().splitlines():
      bits=line.split('\t')
      if len(bits)>2 and bits[0]=='time-stage' and bits[1]!='stage':w.writerow((r,i,m,bits[1],round(1e6*float(bits[2])),h,h==refhash))
