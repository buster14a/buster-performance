import gdb
def read(a,n):return int.from_bytes(bytes(gdb.selected_inferior().read_memory(a,n)),'little')
def put(a,n,v):gdb.selected_inferior().write_memory(a,int(v).to_bytes(n,'little'))
def reg(n):return int(gdb.parse_and_eval('$'+n))
calls=0;hits=0
class Returned(gdb.Breakpoint):
 def stop(self):
  put(marker,1,oldmark);put(slot,4,old);print('ATOMIC',selected,read(sret+8,4));self.enabled=False;return False
class Entry(gdb.Breakpoint):
 def stop(self):
  global calls,hits,slot,old,marker,oldmark,sret
  i=calls;calls+=1
  if i==selected:
   p=reg('rsi');sret=reg('rdi');graph=read(p+cfg['CheckProgram.input'],8)+cfg['CheckInput.graph'];slot=graph+cfg['CheckGraph.recorded']+cfg['CheckGraphValidation.builtins']+3*4;marker=graph+cfg['CheckGraph.recorded_ready'];oldmark=read(marker,1);old=read(slot,4);hits+=1
   print('SELECTED',selected,oldmark,old,read(graph+cfg['CheckGraph.count'],4))
   if mode in ('perturb','fallback'):put(slot,4,old+1)
   if mode=='fallback':put(marker,1,0)
   Returned('*0x%x'%read(reg('rsp'),8),internal=True)
  return False
Entry('*0x%x'%cfg['entry'],internal=True)
