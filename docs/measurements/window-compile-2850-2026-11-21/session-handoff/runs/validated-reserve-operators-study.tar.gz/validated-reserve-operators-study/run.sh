#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
d=$PWD
python3 ../body-reserve-eligibility/run.py > ../body-reserve-eligibility/retry.log 2>&1
cd ../validated-reserve-operators
./build.sh --config Develop --target compiler > "$d/build.log" 2>&1
cp ../proof-predefines.h build/predefines.h
cd "$d"
python3 numerical.py --smoke
python3 stage.py
python3 qualify.py
python3 numerical.py
python3 validated-operator-dataflow.py
python3 suites.py
python3 profile.py
bash per-file.sh
python3 package.py
