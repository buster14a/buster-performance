set pagination off
set debuginfod enabled off
python cfg={'CheckProgram.input': 32, 'CheckInput.graph': 16, 'CheckGraph.count': 236, 'CheckGraph.recorded': 448, 'CheckGraph.recorded_ready': 520, 'CheckGraphValidation.builtins': 12, 'entry': 17072752};mode='fallback';selected=50
source /home/david/Documents/Codex/2026-11-21/g/work/validated-reserve-operators-study/validated-operator-breakpoints.py
run
python print("TOTAL",calls,hits)
