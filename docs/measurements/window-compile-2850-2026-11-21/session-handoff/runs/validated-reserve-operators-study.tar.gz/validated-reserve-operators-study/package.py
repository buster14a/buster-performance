from common import *
import csv,gzip,hashlib,json,re,shutil,subprocess,tarfile
def table(k):return list(csv.DictReader((D/k).open(),delimiter='\t'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
tree=CC.parent.parent;git=lambda *args:subprocess.check_output(['git','-C',tree,*args],text=True).strip();head=git('rev-parse','HEAD');base=git('rev-parse','HEAD^')
out=W/'perf/docs/measurements/window-compile-2850-2026-11-21'/head[:9];out.mkdir(exist_ok=True)
for f in [*D.glob('*.py'),D/'run.sh',D/'per-file.sh',D/'build.log',D/'exact-build.log']:shutil.copy(f,out/f.name)
for key in ('stage','oracle','counts','validated-operator-dataflow','suites','per-file','profile'):
 p=D/key;dst=out/key;dst.mkdir(exist_ok=True)
 for f in p.iterdir():
  if f.suffix in ['.tsv','.json']:shutil.copy(f,dst/f.name)
 with tarfile.open(dst/'raw.tar.gz','w:gz') as t:
  for f in p.iterdir():
   if f.suffix not in ['.tsv','.json','.o'] and f.name!='app':t.add(f,arcname=f.name)
(out/'implementation.patch').write_text(git('diff',base,head)+'\n')
el=W/'body-reserve-eligibility';ed=out/'operand-eligibility';ed.mkdir(exist_ok=True)
for f in [el/'run.py',el/'observe.py',el/'results.tsv',el/'retry.log']:
 if f.exists():shutil.copy(f,ed/f.name)
n=table('counts/outcomes.tsv');p=table('stage/paired.tsv');q=table('oracle/outcomes.tsv');s=table('suites/status.tsv');r=sum([table('per-file/'+g+'.tsv') for g in ['sqlite','main','lua','musl']],[]);o=table('validated-operator-dataflow/outcomes.tsv')
summary={'revision':head,'parent':base,'binaries':{'parent':sha(PRIOR),'candidate':sha(CC)},'reserve-calls':sum(int(e['call-count']) for e in n),'unequal-inputs':sum(e['same-ELF']!=e['equal-parent'] or e['same-ELF']!=e['equal-scalar'] or e['equal-scalar']!='1' for e in n),'process-observations':len(q),'changed-process-observations':sum(e['same-prior']!='1' for e in q),'corpus-pairs':len(r),'changed-corpus-pairs':sum(e['same']!='1' for e in r),'suite-codes':{e['suite']:int(e['status']) for e in s},'mutations':o}
(out/'summary.json').write_text(json.dumps(summary,indent=2))
text=['# Use validated source operators for the body lowering reserve','',f'Experimental revision `{head}` compared with `{base}` on the same frozen inputs. Complete graph validation records the unary builtins alongside its overflow effects, library builtins and atomics. The lowering can use these numerical capacities directly when the producer has recorded the entire graph and both its vector builtins and the translation unit’s vector and atomic types are absent. [Implementation](implementation.patch).','',f"The complete scalar reserve and both source revisions matched on {summary['reserve-calls']:,} complete invocations, with {summary['unequal-inputs']} differing input results or objects. The candidate matched its parent on {len(q)-summary['changed-process-observations']} of {len(q)} native and diagnostic observations and {len(r)-summary['changed-corpus-pairs']:,} of {len(r):,} file-policy comparisons. The new checked-operator fixture adds 31 successful checks to shard 1 (305,454 total). The source-local baseline’s inherited checker shard 6 fault is recorded separately. [All reserve tuples](counts/tuples.tsv), [process matrix](oracle/outcomes.tsv), [corpus outputs](per-file), [checker shard outcomes](suites/status.tsv).",'','A debugger changes exactly one validated atomic-builtin count while lowering the real SQLite or Buster compilation. SQLite consumes the perturbation. Suppressing the checked marker restores the independent result, and Buster with transport vectors uses its full typed rule. The debugger restores the original stream before continuing, and all four configurations produce their original ELF. [Twelve dataflow observations](validated-operator-dataflow/outcomes.tsv).','','| Workload | Path | Counter | Paired change | Lower |','| --- | --- | --- | ---: | ---: |']
for e in p:text.append(f"| {e['input']} | {e['scope']} | {e['metric']} | {float(e['median-delta']):,.0f} | {e['faster']}/{e['rounds']} |")
text+=['','[Every local wall and PMU sample](stage/samples.tsv), [sampled instruction sites](profile), [observed checked operand populations](operand-eligibility/results.tsv).']
(out/'README.md').write_text('\n'.join(text)+'\n');print(out,flush=True);print(json.dumps({k:v for k,v in summary.items() if k not in ['mutations','binaries']}),flush=True)
