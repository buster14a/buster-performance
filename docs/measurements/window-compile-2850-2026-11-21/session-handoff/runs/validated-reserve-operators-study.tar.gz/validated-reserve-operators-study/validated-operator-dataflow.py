from pathlib import Path
import sys
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D))
from common import CC,ROOT,args,env,native
import csv,gzip,hashlib,json,re,shlex,subprocess
tree=CC.parent.parent;db=json.loads((tree/'build/cmake/native/compile_commands.json').read_text());e=next(x for x in db if x['file'].endswith('main_unit_checker.c') and 'Develop' in x['output']);av=shlex.split(e['command']);blocks=subprocess.run([av[0],*[a for a in av if a.startswith(('-I','-D','-march'))],'-fsyntax-only','-Xclang','-fdump-record-layouts',e['file']],cwd=e['directory'],capture_output=True,check=True).stdout.decode().split('*** Dumping AST Record Layout')
def block(k):return next(b for b in blocks if re.search(r'^\s*0 \| struct '+k+r'\s*$',b,re.M))
def off(t,m):return int(re.search(r'^\s*(\d+) \|   [^ \n][^\n]*?\b'+m+r'\s*$',block(t),re.M)[1])
def sz(t):return int(re.search(r'\[sizeof=(\d+)',block(t))[1])
cfg={t+'.'+k:off(t,k) for t,ff in [('CheckProgram',['input']),('CheckInput',['graph']),('CheckGraph',['count','recorded','recorded_ready']),('CheckGraphValidation',['builtins'])] for k in ff}
syms=subprocess.check_output(['nm','-an',CC],text=True);cfg['entry']=int(re.search(r'^([0-9a-f]+) [tT] check_lower_node_counts(?:\.buster_split)?$',syms,re.M)[1],16)
res=D/'validated-operator-dataflow';res.mkdir(exist_ok=True)
with (res/'outcomes.tsv').open('w') as f:
 t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow(['input','scope','mode','mutation-hits','reserve-calls','selected-sequence','reserve-atomics','ELF'])
 for n in ('sqlite','main'):
  for scope,ov in [('ordinary',{}),('source',native)]:
   vals={}
   for mode in ('ordinary','perturb','fallback'):
    pre=res/(n+'.'+scope+'.'+mode);scr=Path(str(pre)+'.gdb');scr.write_text(f'set pagination off\nset debuginfod enabled off\npython cfg={cfg!r};mode={mode!r};selected={0 if scope=="ordinary" else 50}\nsource {D}/validated-operator-breakpoints.py\nrun\npython print("TOTAL",calls,hits)\n');obj=Path(str(pre)+'.o')
    x=subprocess.run(['gdb','-q','-nx','--batch','-x',scr,'--args',CC,'--lanes','1','-c',*args[n],'-o',obj],env=env|ov,cwd=ROOT,capture_output=True,timeout=500)
    for k,raw in [('stdout',x.stdout),('stderr',x.stderr)]:Path(str(pre)+'.'+k+'.gz').write_bytes(gzip.compress(raw,mtime=0))
    v=re.findall(rb'^ATOMIC (\d+) (\d+)$',x.stdout,re.M);end=re.findall(rb'^TOTAL (\d+) (\d+)$',x.stdout,re.M);assert len(v)==len(end)==1 and obj.exists(),(n,scope,mode,x.stderr[-400:],x.stdout[-400:])
    v=list(map(int,v[0]));calls,hits=map(int,end[0]);assert hits==1 and calls==({'sqlite':2675,'main':3108}[n] if scope=='source' else 1)
    digest=hashlib.sha256(obj.read_bytes()).hexdigest();obj.unlink();vals[mode]=(v[1],digest);t.writerow([n,scope,mode,hits,calls,*v,digest]);f.flush()
   original,h=vals['ordinary'];plus,ph=vals['perturb'];fallback,fh=vals['fallback'];assert h==ph==fh and original==fallback and plus==original+int(n=='sqlite'),(n,scope,vals)
   print(n,scope,vals,flush=True)
