typedef _Atomic(int) A __attribute__((aligned(8))); int f(A *p,int a){*p=a;return *p;}
