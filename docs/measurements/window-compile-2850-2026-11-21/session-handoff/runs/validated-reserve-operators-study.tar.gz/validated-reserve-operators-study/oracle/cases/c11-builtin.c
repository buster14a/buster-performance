int f(_Atomic(int)*a,int b){return __c11_atomic_fetch_add(a,b,5);}
