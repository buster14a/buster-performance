struct A{_Atomic(int) n;}; int f(int a){return a*3+2;}
