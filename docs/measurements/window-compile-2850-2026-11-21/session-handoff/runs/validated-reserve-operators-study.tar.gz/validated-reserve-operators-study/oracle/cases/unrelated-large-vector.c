typedef int V __attribute__((vector_size(128))); V v; int f(int value){return value/2 + value*4;}
