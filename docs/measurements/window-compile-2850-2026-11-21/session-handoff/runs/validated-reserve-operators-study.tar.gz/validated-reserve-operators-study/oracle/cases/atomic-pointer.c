struct S { _Atomic(int*) p; }; int f(struct S *s,int *q){s->p=q;return *s->p;}
