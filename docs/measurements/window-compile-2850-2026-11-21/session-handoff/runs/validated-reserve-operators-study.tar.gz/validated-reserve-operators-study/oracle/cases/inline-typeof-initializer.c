struct I; int f(void){__typeof__(struct {int n;struct I*p __attribute__((counted_by(n)));}) v={1};return v.n;}
