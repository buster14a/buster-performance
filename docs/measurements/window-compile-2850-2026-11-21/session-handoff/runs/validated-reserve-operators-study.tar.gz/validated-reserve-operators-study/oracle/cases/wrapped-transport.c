typedef int V __attribute__((ext_vector_type(32)));typedef V A __attribute__((aligned(64))); A f(A a,A b){return (!a)||(a&&b);}
