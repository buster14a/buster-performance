typedef int V __attribute__((vector_size(16))); V f(_Atomic(V)*p,V a){*p=a;return *p;}
