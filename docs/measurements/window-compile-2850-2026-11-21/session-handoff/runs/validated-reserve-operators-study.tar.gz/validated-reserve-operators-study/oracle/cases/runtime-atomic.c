int main(void){_Atomic(int) v=3;int a=v++;v+=4;return a+v;}
