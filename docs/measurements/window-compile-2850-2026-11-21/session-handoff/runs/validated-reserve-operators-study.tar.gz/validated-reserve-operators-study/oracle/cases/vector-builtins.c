typedef unsigned V __attribute__((ext_vector_type(32)));V f(V a,V b){return __builtin_elementwise_add_sat(a,b)+__builtin_elementwise_popcount(a);}
