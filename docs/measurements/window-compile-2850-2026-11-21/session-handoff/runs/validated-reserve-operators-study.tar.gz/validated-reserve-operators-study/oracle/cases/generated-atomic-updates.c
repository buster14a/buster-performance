typedef _Atomic(unsigned char) atomic_0;
unsigned char read_0(atomic_0 *p){return *p;}
unsigned char update_0(atomic_0 *p,unsigned char x){return (*p+=x);}
unsigned char bump_0(atomic_0 *p){return (*p)++;}
unsigned char swap_0(atomic_0 *p,unsigned char v){return __c11_atomic_exchange(p,v,5);}
typedef _Atomic(short) atomic_1;
short read_1(atomic_1 *p){return *p;}
short update_1(atomic_1 *p,short x){return (*p+=x);}
short bump_1(atomic_1 *p){return (*p)++;}
short swap_1(atomic_1 *p,short v){return __c11_atomic_exchange(p,v,5);}
typedef _Atomic(int) atomic_2;
int read_2(atomic_2 *p){return *p;}
int update_2(atomic_2 *p,int x){return (*p+=x);}
int bump_2(atomic_2 *p){return (*p)++;}
int swap_2(atomic_2 *p,int v){return __c11_atomic_exchange(p,v,5);}
typedef _Atomic(long long) atomic_3;
long long read_3(atomic_3 *p){return *p;}
long long update_3(atomic_3 *p,long long x){return (*p+=x);}
long long bump_3(atomic_3 *p){return (*p)++;}
long long swap_3(atomic_3 *p,long long v){return __c11_atomic_exchange(p,v,5);}
