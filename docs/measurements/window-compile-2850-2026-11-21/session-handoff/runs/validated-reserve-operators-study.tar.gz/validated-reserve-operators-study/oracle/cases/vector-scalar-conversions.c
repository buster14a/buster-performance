typedef int V __attribute__((ext_vector_type(32))); V f(V a,int b){return a+b;} void g(V*p,int n){*p+=n;}
