typedef int V __attribute__((ext_vector_type(32)));V f(V a,V b){return (a<b)?a:b;}
