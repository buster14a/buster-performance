typedef int V __attribute__((vector_size(16)));typedef _Atomic(int) A; V f(V a,V b){return a*b+(a>>b);} int g(V x,int i){return x[i];}
