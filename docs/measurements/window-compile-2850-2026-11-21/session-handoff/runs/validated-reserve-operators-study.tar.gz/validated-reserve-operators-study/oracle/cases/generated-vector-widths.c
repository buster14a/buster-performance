typedef unsigned char v0_8 __attribute__((ext_vector_type(8)));
v0_8 add_v0_8(v0_8 a,v0_8 b){return a+b;}
unsigned char sub_v0_8(v0_8 a,int index){return a[index];}
void store_v0_8(v0_8 *p,int i,unsigned char x){(*p)[i]=x;}
v0_8 scalar_v0_8(v0_8 p,unsigned char x){return p+x;}
v0_8 logic_v0_8(v0_8 a,v0_8 b){return (a>b)?a:b;}
v0_8 sat_v0_8(v0_8 a,v0_8 b){return __builtin_elementwise_add_sat(a,b);}
typedef unsigned char v0_16 __attribute__((ext_vector_type(16)));
v0_16 add_v0_16(v0_16 a,v0_16 b){return a+b;}
unsigned char sub_v0_16(v0_16 a,int index){return a[index];}
void store_v0_16(v0_16 *p,int i,unsigned char x){(*p)[i]=x;}
v0_16 scalar_v0_16(v0_16 p,unsigned char x){return p+x;}
v0_16 logic_v0_16(v0_16 a,v0_16 b){return (a>b)?a:b;}
v0_16 sat_v0_16(v0_16 a,v0_16 b){return __builtin_elementwise_add_sat(a,b);}
typedef unsigned char v0_32 __attribute__((ext_vector_type(32)));
v0_32 add_v0_32(v0_32 a,v0_32 b){return a+b;}
unsigned char sub_v0_32(v0_32 a,int index){return a[index];}
void store_v0_32(v0_32 *p,int i,unsigned char x){(*p)[i]=x;}
v0_32 scalar_v0_32(v0_32 p,unsigned char x){return p+x;}
v0_32 logic_v0_32(v0_32 a,v0_32 b){return (a>b)?a:b;}
v0_32 sat_v0_32(v0_32 a,v0_32 b){return __builtin_elementwise_add_sat(a,b);}
typedef unsigned char v0_64 __attribute__((ext_vector_type(64)));
v0_64 add_v0_64(v0_64 a,v0_64 b){return a+b;}
unsigned char sub_v0_64(v0_64 a,int index){return a[index];}
void store_v0_64(v0_64 *p,int i,unsigned char x){(*p)[i]=x;}
v0_64 scalar_v0_64(v0_64 p,unsigned char x){return p+x;}
v0_64 logic_v0_64(v0_64 a,v0_64 b){return (a>b)?a:b;}
v0_64 sat_v0_64(v0_64 a,v0_64 b){return __builtin_elementwise_add_sat(a,b);}
typedef unsigned char v0_128 __attribute__((ext_vector_type(128)));
v0_128 add_v0_128(v0_128 a,v0_128 b){return a+b;}
unsigned char sub_v0_128(v0_128 a,int index){return a[index];}
void store_v0_128(v0_128 *p,int i,unsigned char x){(*p)[i]=x;}
v0_128 scalar_v0_128(v0_128 p,unsigned char x){return p+x;}
v0_128 logic_v0_128(v0_128 a,v0_128 b){return (a>b)?a:b;}
v0_128 sat_v0_128(v0_128 a,v0_128 b){return __builtin_elementwise_add_sat(a,b);}
typedef unsigned char v0_256 __attribute__((ext_vector_type(256)));
v0_256 add_v0_256(v0_256 a,v0_256 b){return a+b;}
unsigned char sub_v0_256(v0_256 a,int index){return a[index];}
void store_v0_256(v0_256 *p,int i,unsigned char x){(*p)[i]=x;}
v0_256 scalar_v0_256(v0_256 p,unsigned char x){return p+x;}
v0_256 logic_v0_256(v0_256 a,v0_256 b){return (a>b)?a:b;}
v0_256 sat_v0_256(v0_256 a,v0_256 b){return __builtin_elementwise_add_sat(a,b);}
typedef short v1_8 __attribute__((ext_vector_type(4)));
v1_8 add_v1_8(v1_8 a,v1_8 b){return a+b;}
short sub_v1_8(v1_8 a,int index){return a[index];}
void store_v1_8(v1_8 *p,int i,short x){(*p)[i]=x;}
v1_8 scalar_v1_8(v1_8 p,short x){return p+x;}
v1_8 logic_v1_8(v1_8 a,v1_8 b){return (a>b)?a:b;}
v1_8 sat_v1_8(v1_8 a,v1_8 b){return __builtin_elementwise_add_sat(a,b);}
typedef short v1_16 __attribute__((ext_vector_type(8)));
v1_16 add_v1_16(v1_16 a,v1_16 b){return a+b;}
short sub_v1_16(v1_16 a,int index){return a[index];}
void store_v1_16(v1_16 *p,int i,short x){(*p)[i]=x;}
v1_16 scalar_v1_16(v1_16 p,short x){return p+x;}
v1_16 logic_v1_16(v1_16 a,v1_16 b){return (a>b)?a:b;}
v1_16 sat_v1_16(v1_16 a,v1_16 b){return __builtin_elementwise_add_sat(a,b);}
typedef short v1_32 __attribute__((ext_vector_type(16)));
v1_32 add_v1_32(v1_32 a,v1_32 b){return a+b;}
short sub_v1_32(v1_32 a,int index){return a[index];}
void store_v1_32(v1_32 *p,int i,short x){(*p)[i]=x;}
v1_32 scalar_v1_32(v1_32 p,short x){return p+x;}
v1_32 logic_v1_32(v1_32 a,v1_32 b){return (a>b)?a:b;}
v1_32 sat_v1_32(v1_32 a,v1_32 b){return __builtin_elementwise_add_sat(a,b);}
typedef short v1_64 __attribute__((ext_vector_type(32)));
v1_64 add_v1_64(v1_64 a,v1_64 b){return a+b;}
short sub_v1_64(v1_64 a,int index){return a[index];}
void store_v1_64(v1_64 *p,int i,short x){(*p)[i]=x;}
v1_64 scalar_v1_64(v1_64 p,short x){return p+x;}
v1_64 logic_v1_64(v1_64 a,v1_64 b){return (a>b)?a:b;}
v1_64 sat_v1_64(v1_64 a,v1_64 b){return __builtin_elementwise_add_sat(a,b);}
typedef short v1_128 __attribute__((ext_vector_type(64)));
v1_128 add_v1_128(v1_128 a,v1_128 b){return a+b;}
short sub_v1_128(v1_128 a,int index){return a[index];}
void store_v1_128(v1_128 *p,int i,short x){(*p)[i]=x;}
v1_128 scalar_v1_128(v1_128 p,short x){return p+x;}
v1_128 logic_v1_128(v1_128 a,v1_128 b){return (a>b)?a:b;}
v1_128 sat_v1_128(v1_128 a,v1_128 b){return __builtin_elementwise_add_sat(a,b);}
typedef short v1_256 __attribute__((ext_vector_type(128)));
v1_256 add_v1_256(v1_256 a,v1_256 b){return a+b;}
short sub_v1_256(v1_256 a,int index){return a[index];}
void store_v1_256(v1_256 *p,int i,short x){(*p)[i]=x;}
v1_256 scalar_v1_256(v1_256 p,short x){return p+x;}
v1_256 logic_v1_256(v1_256 a,v1_256 b){return (a>b)?a:b;}
v1_256 sat_v1_256(v1_256 a,v1_256 b){return __builtin_elementwise_add_sat(a,b);}
typedef int v2_8 __attribute__((ext_vector_type(2)));
v2_8 add_v2_8(v2_8 a,v2_8 b){return a+b;}
int sub_v2_8(v2_8 a,int index){return a[index];}
void store_v2_8(v2_8 *p,int i,int x){(*p)[i]=x;}
v2_8 scalar_v2_8(v2_8 p,int x){return p+x;}
v2_8 logic_v2_8(v2_8 a,v2_8 b){return (a>b)?a:b;}
v2_8 sat_v2_8(v2_8 a,v2_8 b){return __builtin_elementwise_add_sat(a,b);}
typedef int v2_16 __attribute__((ext_vector_type(4)));
v2_16 add_v2_16(v2_16 a,v2_16 b){return a+b;}
int sub_v2_16(v2_16 a,int index){return a[index];}
void store_v2_16(v2_16 *p,int i,int x){(*p)[i]=x;}
v2_16 scalar_v2_16(v2_16 p,int x){return p+x;}
v2_16 logic_v2_16(v2_16 a,v2_16 b){return (a>b)?a:b;}
v2_16 sat_v2_16(v2_16 a,v2_16 b){return __builtin_elementwise_add_sat(a,b);}
typedef int v2_32 __attribute__((ext_vector_type(8)));
v2_32 add_v2_32(v2_32 a,v2_32 b){return a+b;}
int sub_v2_32(v2_32 a,int index){return a[index];}
void store_v2_32(v2_32 *p,int i,int x){(*p)[i]=x;}
v2_32 scalar_v2_32(v2_32 p,int x){return p+x;}
v2_32 logic_v2_32(v2_32 a,v2_32 b){return (a>b)?a:b;}
v2_32 sat_v2_32(v2_32 a,v2_32 b){return __builtin_elementwise_add_sat(a,b);}
typedef int v2_64 __attribute__((ext_vector_type(16)));
v2_64 add_v2_64(v2_64 a,v2_64 b){return a+b;}
int sub_v2_64(v2_64 a,int index){return a[index];}
void store_v2_64(v2_64 *p,int i,int x){(*p)[i]=x;}
v2_64 scalar_v2_64(v2_64 p,int x){return p+x;}
v2_64 logic_v2_64(v2_64 a,v2_64 b){return (a>b)?a:b;}
v2_64 sat_v2_64(v2_64 a,v2_64 b){return __builtin_elementwise_add_sat(a,b);}
typedef int v2_128 __attribute__((ext_vector_type(32)));
v2_128 add_v2_128(v2_128 a,v2_128 b){return a+b;}
int sub_v2_128(v2_128 a,int index){return a[index];}
void store_v2_128(v2_128 *p,int i,int x){(*p)[i]=x;}
v2_128 scalar_v2_128(v2_128 p,int x){return p+x;}
v2_128 logic_v2_128(v2_128 a,v2_128 b){return (a>b)?a:b;}
v2_128 sat_v2_128(v2_128 a,v2_128 b){return __builtin_elementwise_add_sat(a,b);}
typedef int v2_256 __attribute__((ext_vector_type(64)));
v2_256 add_v2_256(v2_256 a,v2_256 b){return a+b;}
int sub_v2_256(v2_256 a,int index){return a[index];}
void store_v2_256(v2_256 *p,int i,int x){(*p)[i]=x;}
v2_256 scalar_v2_256(v2_256 p,int x){return p+x;}
v2_256 logic_v2_256(v2_256 a,v2_256 b){return (a>b)?a:b;}
v2_256 sat_v2_256(v2_256 a,v2_256 b){return __builtin_elementwise_add_sat(a,b);}
typedef double v3_8 __attribute__((ext_vector_type(1)));
v3_8 add_v3_8(v3_8 a,v3_8 b){return a+b;}
double sub_v3_8(v3_8 a,int index){return a[index];}
void store_v3_8(v3_8 *p,int i,double x){(*p)[i]=x;}
v3_8 scalar_v3_8(v3_8 p,double x){return p+x;}
typedef double v3_16 __attribute__((ext_vector_type(2)));
v3_16 add_v3_16(v3_16 a,v3_16 b){return a+b;}
double sub_v3_16(v3_16 a,int index){return a[index];}
void store_v3_16(v3_16 *p,int i,double x){(*p)[i]=x;}
v3_16 scalar_v3_16(v3_16 p,double x){return p+x;}
typedef double v3_32 __attribute__((ext_vector_type(4)));
v3_32 add_v3_32(v3_32 a,v3_32 b){return a+b;}
double sub_v3_32(v3_32 a,int index){return a[index];}
void store_v3_32(v3_32 *p,int i,double x){(*p)[i]=x;}
v3_32 scalar_v3_32(v3_32 p,double x){return p+x;}
typedef double v3_64 __attribute__((ext_vector_type(8)));
v3_64 add_v3_64(v3_64 a,v3_64 b){return a+b;}
double sub_v3_64(v3_64 a,int index){return a[index];}
void store_v3_64(v3_64 *p,int i,double x){(*p)[i]=x;}
v3_64 scalar_v3_64(v3_64 p,double x){return p+x;}
typedef double v3_128 __attribute__((ext_vector_type(16)));
v3_128 add_v3_128(v3_128 a,v3_128 b){return a+b;}
double sub_v3_128(v3_128 a,int index){return a[index];}
void store_v3_128(v3_128 *p,int i,double x){(*p)[i]=x;}
v3_128 scalar_v3_128(v3_128 p,double x){return p+x;}
typedef double v3_256 __attribute__((ext_vector_type(32)));
v3_256 add_v3_256(v3_256 a,v3_256 b){return a+b;}
double sub_v3_256(v3_256 a,int index){return a[index];}
void store_v3_256(v3_256 *p,int i,double x){(*p)[i]=x;}
v3_256 scalar_v3_256(v3_256 p,double x){return p+x;}
