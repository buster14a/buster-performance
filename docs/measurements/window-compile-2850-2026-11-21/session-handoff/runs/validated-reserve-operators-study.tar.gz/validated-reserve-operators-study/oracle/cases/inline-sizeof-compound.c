struct I; int f(void){return sizeof((struct {int n;struct I*p __attribute__((counted_by_or_null(n)));}){1});}
