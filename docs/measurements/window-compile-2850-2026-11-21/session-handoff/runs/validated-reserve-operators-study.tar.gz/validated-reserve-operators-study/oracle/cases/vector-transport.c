typedef int V __attribute__((vector_size(128)));V f(V a,V b){return a*b+(a>>b);} int g(V x,int i){return x[i];}
