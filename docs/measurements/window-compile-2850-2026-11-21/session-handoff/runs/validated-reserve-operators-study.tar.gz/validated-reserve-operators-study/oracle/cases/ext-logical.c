typedef int V __attribute__((ext_vector_type(4))); typedef _Atomic(int) A; V f(V x,V y){return (!x)||(x&&y);}
