typedef _Atomic(int) A; unsigned f(unsigned x){return __builtin_elementwise_popcount(x);}
