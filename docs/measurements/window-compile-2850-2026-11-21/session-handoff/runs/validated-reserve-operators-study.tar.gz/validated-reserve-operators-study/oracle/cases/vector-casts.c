typedef int I __attribute__((ext_vector_type(32)));typedef float F __attribute__((ext_vector_type(32)));F f(I i){return __builtin_convertvector(i,F);}
