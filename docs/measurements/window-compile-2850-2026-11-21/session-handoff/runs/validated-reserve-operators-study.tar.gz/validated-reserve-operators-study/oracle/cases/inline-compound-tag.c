struct I; int f(void){return ((struct B {int n;struct I*p __attribute__((counted_by(n)));}){1}).n;}
