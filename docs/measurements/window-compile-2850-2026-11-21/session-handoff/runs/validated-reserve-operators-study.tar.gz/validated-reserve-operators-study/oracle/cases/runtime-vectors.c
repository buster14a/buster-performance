typedef int V __attribute__((vector_size(16)));typedef int W __attribute__((vector_size(128)));int main(void){V a={1,2,3,4};V b={4,3,2,1};W w={5,6};return (a*b)[2]+w[1];}
