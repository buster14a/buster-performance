typedef int V __attribute__((ext_vector_type(32)));int f(V a){return a.foo;}
