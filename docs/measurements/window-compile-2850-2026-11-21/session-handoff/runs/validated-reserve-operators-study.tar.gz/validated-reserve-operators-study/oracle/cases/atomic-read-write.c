int f(int a){_Atomic(int) n=2; n+=a; ++n; return n;}
