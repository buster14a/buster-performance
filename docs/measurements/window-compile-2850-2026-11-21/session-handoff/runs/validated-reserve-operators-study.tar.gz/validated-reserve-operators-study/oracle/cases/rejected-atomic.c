int f(void){_Atomic(int[3]) a;return 0;}
