from common import *
import csv,subprocess
d=D/'suites';d.mkdir(exist_ok=True);clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
with (d/'status.tsv').open('w',buffering=1) as f:
 t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow(['suite','status'])
 for i in range(1,9):
  with (d/f'checker-{i}.log').open('wb') as l:r=subprocess.run([CC,'test-checker','--part',f'{i}/8','--seed','2850'],env=env|{'PATH':str(clang.parent)+':'+env['PATH']},cwd=CC.parent.parent,stdout=l,stderr=subprocess.STDOUT)
  t.writerow([f'checker-{i}',r.returncode])
