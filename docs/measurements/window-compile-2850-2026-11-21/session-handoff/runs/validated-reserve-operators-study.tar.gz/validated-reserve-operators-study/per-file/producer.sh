#!/bin/bash
export BUSTER_CONTROL_SOURCE_NATIVE=1
exec /home/david/Documents/Codex/2026-11-21/g/work/validated-reserve-operators-study/../validated-reserve-operators/build/compiler "$@"
