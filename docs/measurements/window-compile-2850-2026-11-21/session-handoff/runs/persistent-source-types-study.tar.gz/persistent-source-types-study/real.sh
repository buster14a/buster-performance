#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs;source ../switch-local-args.sh
case $1 in sqlite) eval "args=($sqlite_arguments)";;
main) tree=$PWD/../pregraph-warning-study/compiler-source;args=(-march=native -I"$tree/src" -fwrapv -funsigned-char --predefines "$PWD/../proof-predefines.h" "$tree/src/buster/compiler/main.c");;esac
BUSTER_PARSE_LIVE_FOREST=1 BUSTER_LIVE_CHECKED_INPUT=1 BUSTER_PARSE_LIVE_AUDIT=1 BUSTER_PRE_EOF_NATIVE_WINDOW=24 BUSTER_LIVE_ORDINARY_HANDOFF=1 BUSTER_PRE_EOF_CONTINUE_TYPES=1 BUSTER_LIVE_RESOLVE_WINDOWS=1 "$d/compiler" --lanes 1 -c "${args[@]}" -o "$d/$1.$2.o" > "$d/$1.$2.out" 2>"$d/$1.$2.stderr"
cmp "$d/$1.$2.o" "$d/../source-typed-study/$1.o"
