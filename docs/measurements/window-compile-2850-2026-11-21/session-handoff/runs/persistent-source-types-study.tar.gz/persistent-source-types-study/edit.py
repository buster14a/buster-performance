from pathlib import Path
d=Path(__file__).resolve().parent.parent/'persistent-source-types/src/buster/compiler'
def change(p,a,b):
 s=p.read_text();assert s.count(a)==1,(p,a[:70],s.count(a));p.write_text(s.replace(a,b))
p=d/'c_parser.c'
change(p,'    Arena live_code;','    Arena live_code;\n    Arena live_type_storage;\n    Arena live_type_index;')
change(p,'    arena_release(&parser->live_code);','    arena_release(&parser->live_type_index);\n    arena_release(&parser->live_type_storage);\n    arena_release(&parser->live_code);')
p=d/'c_check_input.c'
change(p,'    bool capture, audit, ordinary;','''    bool capture, audit, ordinary, continue_types;
    uint32_t type_boundary;
    TypeTable source_types;''')
fields={'types':'kind code flags alignment_log2 base index extent size hash','parameters':'type','tags':'type name member_begin member_count completion packed ms_struct pack_log2 alignment_log2 lookup lookup_log2','members':'name type bit_width alignment_log2 flags offset count_name','lookup':'buckets'}
f='''// Compare every occupied row and the lookup indices before transferring ownership to the
// ordinary reader. The snapshot stops before the prefix EOF event, exactly where the ordinary
// reader resumes. The source arena remains live until the parser releases the unit.
static bool check_transfer_source_types(CheckLiveNative* live, TypeTable* final)
{
    TypeTable* source = &live->source_types;
    if (source->changes || final->changes || source->last_error != final->last_error ||
        source->hidden_begin != final->hidden_begin || source->hidden_end != final->hidden_end ||
        source->char_unsigned != final->char_unsigned || source->atomic_inline_16 != final->atomic_inline_16 ||
        source->extended != final->extended || source->ext_vectors != final->ext_vectors ||
        source->atomic_records != final->atomic_records || source->tags.completions != final->tags.completions ||
        source->members.first_counted_pointer != final->members.first_counted_pointer ||
        source->index.count != final->index.count || source->index.bucket_count != final->index.bucket_count)
        return false;
'''
for n in fields:
 f+=f'    if (source->{n}.count != final->{n}.count || source->{n}.capacity < final->{n}.capacity) return false;\n'
f+='''#define BUSTER_COMPARE_SOURCE_COLUMN(group, field) \\
    if (memcmp(source->group.field, final->group.field, (size_t)source->group.count * sizeof(*source->group.field))) return false;
'''
for n,names in fields.items():
 for name in names.split():f+=f'    BUSTER_COMPARE_SOURCE_COLUMN({n}, {name})\n'
f+='''#undef BUSTER_COMPARE_SOURCE_COLUMN
    if (memcmp(source->index.slots, final->index.slots,
               (size_t)source->index.bucket_count * BUSTER_TYPE_BUCKET_SLOTS * sizeof(TypeSlot))) return false;
    TypeTable transferred = *source;
'''
for n in fields:f+=f'    transferred.{n}.capacity = final->{n}.capacity;\n'
f+='''    *final = transferred;
    return true;
}

'''
change(p,'typedef struct CheckLiveBoundary CheckLiveBoundary;',f+'typedef struct CheckLiveBoundary CheckLiveBoundary;')
a='                if (live != NULL && live->used && live->owner == parser && live->first != NULL && deferred == NULL)'
change(p,a,'''                CheckLiveNative* transfer = parser->live_native;
                if (transfer && transfer->continue_types && transfer->capture && deferred == NULL)
                {
                    const uint32_t cut = check_input_resolve_window(&reader, 0, count, count, false);
                    if (cut == count && !input->report_count && !input->resource && !types->changes)
                        transfer->type_boundary = count;
                    goto release_reader;
                }
'''+a)
a='                        windows += 1;'
change(p,a,'''                        if (transfer && transfer->continue_types && transfer->type_boundary &&
                            cursor == transfer->type_boundary && !input->report_count && !input->resource)
                        {
                            const bool adopted = check_transfer_source_types(transfer, types);
                            if (transfer->audit) fprintf(stderr, "source-type-continuation\\tadopted=%u\\trows=%u\\ttypes=%u\\ttags=%u\\tmembers=%u\\tparameters=%u\\n",
                                adopted, cursor, types->types.count, types->tags.count, types->members.count, types->parameters.count);
                            transfer->type_boundary = 0;
                        }
'''+a)
change(p,'    arena_pop_to(scratch, mark);\n    arena_release(&sparse);','release_reader:\n    arena_pop_to(scratch, mark);\n    arena_release(&sparse);')
p=d/'c_checker_driver.c'
change(p,'    const TypeCapacity cap = { .types = 4 * count + 64, .parameters = count, .tags = count, .members = count };','''    const uint32_t room = state->continue_types ? prefix->tokens.capacity : count;
    const TypeCapacity cap = { .types = 4 * room + 64, .parameters = room, .tags = room, .members = room };''')
a='    const CheckSourceBodies* bodies = input.source_bodies;'
# This lineage has no seal loop.
if a not in p.read_text():a='    if (state->audit)\n        fprintf(stderr, "pre-eof-native-prefix'
change(p,a,'''    if (state->continue_types && ready && state->type_boundary)
    {
        owner->live_type_storage = type_memory;
        owner->live_type_index = index_memory;
        type_memory = (Arena){ 0 };
        index_memory = (Arena){ 0 };
        types.index.arena = &owner->live_type_index;
        state->source_types = types;
        if (state->audit) fprintf(stderr,"pre-eof-type-table\\tboundary=%u\\tactive-contexts=%u\\ttypes=%u\\ttags=%u\\tmembers=%u\\tparameters=%u\\n",
                                  state->type_boundary, pp->context_count, types.types.count, types.tags.count, types.members.count, types.parameters.count);
    }
'''+a)
a='                    parser->live_native = fragments;'
change(p,a,'''                    fragments->continue_types = getenv("BUSTER_PRE_EOF_CONTINUE_TYPES") && command->emit_object && !command->link &&
                        !command->tier1 && !command->verify && !command->dump && !command->scalar && !command->assembly;
'''+a)
