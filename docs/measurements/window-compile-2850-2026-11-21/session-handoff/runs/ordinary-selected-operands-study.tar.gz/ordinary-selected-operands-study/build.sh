#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; cd ../ordinary-selected-operands
exec 9>"$d/build.lock"
flock 9
test ! -x "$d/compiler" || exit 0
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/
ln -sf ../ordinary-selected-operands/build/compiler "$d/compiler"
