The source-local path now handles all 2,674 definitions in frozen SQLite 3.53.2. Ordinary symbol selection emitted 2,668 functions. Their local graphs supplied all 381,191 typed entries and 11,162 symbol references. The resulting 2,061,200-byte ELF matches the ordinary compiler byte for byte, including relocations and unwind data. Its SHA-256 is `2238999c41e256cc9c14ddbe21e379f0b3c09df25fb642b056e18b8a7ea773a0`. Four linked SQLite shell comparisons matched Clang in stdout, stderr and exit status. [Coverage, complete source, runtime and raw records](https://github.com/buster14a/buster-performance/tree/b9c1ee1c094bab25f97e30917699a6591d47485e/docs/measurements/window-compile-2850-2026-11-21/58ac5af4b)

This is still short of the 9.507 ms goal. In five local Ryzen 7940HS rounds the first full-coverage path took 651.690 ms against 312.264 ms for ordinary compilation, with repeated x86 initialization accounting for 26.14% of sampled user cycles. In a separate matched optimized build, reusing instruction semantics, ABI classifications and lowerer type facts brought the candidate to 323.47 ms against 282.39 ms ordinary. The controlled 9700X native Release comparison for that revision is in progress. The last merged 9700X ordinary measurement was 112.119 ms.

One overridden-initializer warning was missing in the first full-coverage revision. The fix now matches every status, ELF and diagnostic in 92 directed case/policy comparisons, including warning promotion. A subsequent file-scope producer has also removed 4,319 of SQLite’s remaining 4,343 unit expression nodes. The exact object still matches. Work continues on retiring checked and typed storage earlier and reducing frontend work within the same fresh compiler process.

---

Agent session: 01a1fd72-c69a-7aa3-9540-11ff6816d868 (Codex session ID, no share URL is exposed)
Model: OpenAI / GPT-6
