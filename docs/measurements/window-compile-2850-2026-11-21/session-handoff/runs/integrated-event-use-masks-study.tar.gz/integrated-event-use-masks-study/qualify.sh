#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d="$PWD"; cd ../integrated-event-use-masks
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/
cd "$d"
python3 qualify.py >qualify.log 2>&1
bash runtime.sh >runtime.log 2>&1
