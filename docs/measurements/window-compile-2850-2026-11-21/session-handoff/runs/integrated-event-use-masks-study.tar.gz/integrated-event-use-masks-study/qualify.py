import sys,subprocess,os,csv,re,hashlib
from pathlib import Path
study=Path(__file__).resolve().parent;work=study.parent
sys.path.insert(0,str(work/'live-scoped-bindings-study'))
from common import workloads,sha
tree=work/'integrated-event-use-masks'
parent=work/'source-verified-handoff'
stock=work/'default-integer-control'
def env(mode,window,audit):
 e={k:v for k,v in os.environ.items() if not k.startswith('BUSTER_')}
 if mode=='ordinary':return e
 for k in ['PARSE_LIVE_FOREST','LIVE_CHECKED_INPUT','LIVE_ORDINARY_HANDOFF','LIVE_RESOLVE_WINDOWS']:e['BUSTER_'+k]='1'
 e['BUSTER_PRE_EOF_NATIVE_WINDOW']=str(window)
 if mode!='parent':
  for k in ['PRE_EOF_BINDINGS','PRE_EOF_BINDING_PAGES','PRE_EOF_EVENT_STREAM']:e['BUSTER_'+k]='1'
 if mode not in ['ordinary','parent','tuples']:e['BUSTER_PRE_EOF_EVENT_MASKS']='1'
 if mode=='mismatch':e['BUSTER_PRE_EOF_SCOPE_MISMATCH']='1'
 if mode=='rewrite':e['BUSTER_PRE_EOF_REWRITE_PAGES']='1'
 if audit:
  e['BUSTER_PARSE_LIVE_AUDIT']='1';e['BUSTER_PRE_EOF_PAGE_ORACLE']='1'
 return e
def compiler(mode):return (stock if mode=='ordinary' else parent if mode=='parent' else tree)/'build/compiler'
def call(mode,args,out,window=24,audit=False):
 out.unlink(missing_ok=True);p=subprocess.run([compiler(mode),'--lanes','1','-c',*args,'-o',out],capture_output=True,env=env(mode,window,audit),timeout=150)
 return p.returncode,p.stdout,p.stderr,sha(out.read_bytes() if out.is_file() else b'')
def full():
 with (study/'full.tsv').open('w',buffering=1) as f:
  wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['source','mode','window','status','matched_events','source_evidence_bytes','source_name_uses','final_answers','ordinary_native_functions','resolver_windows','elf_sha','diag_sha'])
  for name,args in workloads.items():
   for window in [12,24,40] if name=='sqlite' else [12,24,80]:
    ref=None
    for mode in ['ordinary','parent','tuples','candidate','rewrite','mismatch']:
     out=study/(name+'.'+mode+'.o');q=call(mode,args,out,window)
     if ref is None:ref=q
     assert q==ref and q[0]==0,(name,window,mode,ref,q)
     audit=call(mode,args,out,window,True);assert audit[0]==0 and audit[3]==q[3]
     (study/(name+'-'+str(window)+'-'+mode+'.stderr')).write_bytes(audit[2])
     def fields(pattern):
      m=re.search(pattern,audit[2],re.M);return tuple(map(int,m.groups())) if m else ()
     allrows=fields(rb'^pre-eof-event-stream\tcaptured=\d+\tmatched=(\d+)')
     counts=fields(rb'^pre-eof-bindings-consumed\tcaptured=\d+\tordinary-source-uses=(\d+)\tfinal-answers=(\d+)') or (0,0)
     natives=sum(l.startswith(b'ordinary-native-handoff\t') for l in audit[2].splitlines())
     win=fields(rb'^source-resolver\twindows=(\d+)') or (0,)
     held=fields(rb'^pre-eof-bindings-captured.*?uses=\d+\tbytes=(\d+)') or (0,)
     wr.writerow([name,mode,window,q[0],*(allrows or (0,)),held[0],*counts,natives,win[0],q[3],sha(q[2])])
     if window==24 and mode in ('candidate','rewrite'):assert allrows and allrows[0]>50000 and counts[0]>10000 and natives>100 and win[0]>1,(name,mode,allrows,counts,natives,win)
     if mode=='mismatch':assert not any(allrows) and not any(counts)
def trace():
 with (study/'trace.tsv').open('w',buffering=1) as f:
  wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['source','mode','event_sha','answers_sha','elf_sha'])
  for name,args in workloads.items():
   for mode in ['parent','candidate','mismatch']:
    dest=study/('trace-'+name+'-'+mode);environment=env(mode,24,True);environment['LIVE_BINDING_TRACE_TOKENS']=str(716136 if name=='sqlite' else 2433563)
    with Path(str(dest)+'.log').open('wb') as fl:
     subprocess.run([sys.executable,study/'replay-gdb.py',compiler(mode).parent.parent,dest,'--','--lanes','1',*args],env=environment,stdout=fl,stderr=subprocess.STDOUT,check=True,timeout=240)
    shas=[]
    for ext in ['events','answers','o']:
     data=Path(str(dest)+'.'+ext).read_bytes();old=(work/'live-prefix-bindings-study'/('trace-'+name+'-ordinary.'+ext)).read_bytes()
     assert data==old,(name,mode,ext,sha(data),sha(old));shas.append(sha(data))
    wr.writerow([name,mode,*shas])
if __name__=='__main__':full();trace()
