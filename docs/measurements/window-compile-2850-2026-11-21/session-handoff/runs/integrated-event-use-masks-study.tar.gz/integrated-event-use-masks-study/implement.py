from pathlib import Path
tree=Path(__file__).resolve().parent.parent/'integrated-event-use-masks/src/buster/compiler'
def setin(p,pairs):
 f=tree/p;s=f.read_text()
 for a,b in pairs:
  assert s.count(a)==1,(f,a)
  s=s.replace(a,b)
 f.write_text(s)
fields='''// The canonical source event owns its target, name and source position. Only eligibility
// and successful admission have no canonical binding column of their own.
typedef struct CheckLiveUseMask CheckLiveUseMask;
struct CheckLiveUseMask
{
    CheckLiveUseMask* next;
    uint32_t group;
    uint64_t eligible[16], accepted[16];
};

'''
seek='''static CheckLiveUseMask* check_live_find_mask(CheckLiveUseMask** at, uint32_t event)
{
    const uint32_t group = event / 1024u;
    while (*at != NULL && (*at)->group < group) *at = (*at)->next;
    return *at != NULL && (*at)->group == group ? *at : NULL;
}

static bool check_live_event_use(const CheckInputReader* reader, uint32_t e, CheckLiveUseRow* row)
{
    const CBindings* b = &reader->bindings;
    const CBindingPublished* st = b->published;
    if (st == NULL || e >= st->count || b->operation[e] != C_BINDING_USE) return false;
    const uint32_t handle = b->previous[e];
    if (handle == 0 || handle > e) return false;
    *row = (CheckLiveUseRow){ .token = b->declaration[e], .name = b->key[e], .declaration = b->declaration[handle - 1],
        .handle = handle, .prefix_event = e, .final_event = e };
    return true;
}

'''
capture='''    if (state->use_masks)
    {
        const uint32_t group = event / 1024u;
        if (state->last_mask == NULL || state->last_mask->group != group)
        {
            CheckLiveUseMask* block = BUSTER_ARENA_PUSH_ARRAY(state->storage, CheckLiveUseMask, 1);
            if (block == NULL) { state->failed = true; return; }
            *block = (CheckLiveUseMask){ .group = group };
            if (state->last_mask != NULL) state->last_mask->next = block;
            else state->first_mask = block;
            state->last_mask = block;
            state->mask_count += 1;
        }
        state->last_mask->eligible[(event >> 6) & 15u] |= UINT64_C(1) << (event & 63u);
        state->last_token = token;
        state->captured += 1;
        return;
    }
'''
start='''    CheckLiveUseRow* row = check_live_use_next(&state->source);
    while (row != NULL && row->token < token)
    {
        state->source.index += 1;
        row = check_live_use_next(&state->source);
    }
    if (row == NULL || row->token != token) return false;
    state->source.index += 1;'''
answer='''    CheckLiveUseRow* row = check_live_use_next(&state->answers);
    while (row != NULL && (row->final_event == BUSTER_CHECK_NONE || row->final_event < event))
    {
        state->answers.index += 1;
        row = check_live_use_next(&state->answers);
    }
    if (row == NULL || row->final_event != event) return false;
    state->answers.index += 1;'''
setin('c_check_input.c',[
 ('typedef struct CheckLiveBindings\n',fields+'typedef struct CheckLiveBindings\n'),
 ('    bool stream_enabled, corrupt_stream;', '''    bool stream_enabled, corrupt_stream, use_masks;
    CheckLiveUseMask* first_mask;
    CheckLiveUseMask* last_mask;
    CheckLiveUseMask* lookup_mask;
    CheckLiveUseMask* publish_mask;
    uint32_t mask_count;'''),
 ('    if (state->last == NULL || state->last->count == 128)',capture+'    if (state->last == NULL || state->last->count == 128)'),
 ('// Reuse the pre-EOF classification in the final walk.', seek+'// Reuse the pre-EOF classification in the final walk.'),
 (start,'''    const uint32_t ordinal = reader->bindings.count;
    CheckLiveUseMask* mask = NULL;
    CheckLiveUseRow implicit;
    CheckLiveUseRow* row = &implicit;
    if (state->use_masks)
    {
        mask = check_live_find_mask(&state->lookup_mask, ordinal);
        if (mask == NULL || !(mask->eligible[(ordinal >> 6) & 15u] & (UINT64_C(1) << (ordinal & 63u))) ||
            !check_live_event_use(reader, ordinal, row) || row->token != token) return false;
    }
    else
    {
'''+ '\n'.join('    '+x.replace('CheckLiveUseRow* row = check_live_use_next', 'row = check_live_use_next') for x in start.splitlines())+'''
    }'''),
 ('        row->final_event = event - 1;', '''        if (mask != NULL) mask->accepted[(ordinal >> 6) & 15u] |= UINT64_C(1) << (ordinal & 63u);
        else row->final_event = event - 1;'''),
 (answer,'''    CheckLiveUseRow implicit;
    CheckLiveUseRow* row = &implicit;
    if (state->use_masks)
    {
        CheckLiveUseMask* mask = check_live_find_mask(&state->publish_mask, event);
        if (mask == NULL || !(mask->accepted[(event >> 6) & 15u] & (UINT64_C(1) << (event & 63u))) ||
            !check_live_event_use(reader, event, row)) return false;
    }
    else
    {
'''+ '\n'.join('    '+x.replace('CheckLiveUseRow* row = check_live_use_next', 'row = check_live_use_next') for x in answer.splitlines())+'''
    }''')])
setin('c_checker_driver.c',[
 ('                                bindings->corrupt_stream = getenv("BUSTER_PRE_EOF_SCOPE_MISMATCH") != NULL;',
  '''                                bindings->corrupt_stream = getenv("BUSTER_PRE_EOF_SCOPE_MISMATCH") != NULL;
                                bindings->use_masks = bindings->stream_enabled && getenv("BUSTER_PRE_EOF_EVENT_MASKS") != NULL;'''),
 ('        bindings->source = (CheckLiveUseCursor){ bindings->first, 0 };','''        bindings->lookup_mask = bindings->first_mask;
        bindings->publish_mask = bindings->first_mask;
        bindings->source = (CheckLiveUseCursor){ bindings->first, 0 };'''),
 ('(size_t)bindings->scope_count * sizeof(CheckLiveScopeRow));','''(size_t)bindings->scope_count * sizeof(CheckLiveScopeRow) +
                    (size_t)bindings->mask_count * sizeof(CheckLiveUseMask));''')])
