"""Read canonical binding rows directly from the untouched upstream compiler in GDB."""
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import argparse
arguments=argparse.ArgumentParser(description=__doc__)
arguments.add_argument('tree',type=Path,help="Buster source tree including build/compiler and build/compile_commands.json")
arguments.add_argument('output',type=Path,help="destination prefix for both binary columns and GDB logs")
arguments.add_argument('compiler_args',nargs=argparse.REMAINDER,help="ordinary source arguments; -c and the output path are supplied")
options=arguments.parse_args()
tree=options.tree.resolve()
prefix=options.output.resolve()
prefix.parent.mkdir(parents=True,exist_ok=True)
args=options.compiler_args[1:] if options.compiler_args[:1]==['--'] else options.compiler_args
if not args:arguments.error('source arguments required')
commands=json.loads((tree/'build/compile_commands.json').read_text())
entry=next(x for x in commands if 'main_unit_checker.c.o' in x['command'])
cmd=shlex.split(entry['command']);i=cmd.index('-o')
cmd=cmd[:i]+['-Xclang','-fdump-record-layouts','-fsyntax-only',cmd[-1]]
for al in ['-emit-llvm','-Xclang','-disable-llvm-passes']:
 if al=='-Xclang':continue
 if al in cmd:
  i=cmd.index(al);del cmd[i]
  if i and cmd[i-1]=='-Xclang':del cmd[i-1]
p=subprocess.run(cmd,cwd=entry['directory'],capture_output=True,timeout=60)
assert p.returncode==0,p.stderr.decode()[:1500]
layouts=p.stdout.decode()
def field_offset(struct,field):
 start=layouts.index(' | struct '+struct+'\n');end=layouts.index('[sizeof=',start)
 return int(re.search(r'^\s*(\d+) \|   \S.*?\b'+field+'$',layouts[start:end],re.M)[1])
reader_output=field_offset('CheckInputReader','output')
reader_bindings=field_offset('CheckInputReader','bindings')
output_visits=field_offset('CheckInput','resolve_visits')
fields=['heads','name_capacity','active','active_count','count','operation','kind','key','declaration','point','end','previous','depth']
offset={k:field_offset('CBindings',k) for k in fields}
print('layout offsets',reader_bindings,output_visits,offset,flush=True)
gdb_program="""set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
break check_input_binding_events.buster_split
run
set $reader=$rdi
finish
python
import struct, gdb
p=gdb.selected_inferior()
rd=int(gdb.parse_and_eval('$reader'))
def mem(addr,n): return bytes(p.read_memory(addr,n)) if n else b''
def num(addr,n): return int.from_bytes(mem(addr,n),'little')
base=rd+READER_BINDINGS
offset=OFFSETS
def val(k,width):return num(base+offset[k],width)
out=num(rd,8)
visits=num(out+OUTPUT_VISITS,4)
events=val('count',4)
names=val('name_capacity',4)
active=val('active_count',4)
with open(DEST,'wb') as f:
 f.write(struct.pack('<4I',visits,events,names,active))
 for k,sz in [('heads',4*names*3),('active',4*active)]+[(name,4*events) for name in ('key','declaration','point','end','previous','depth')]+[(name,events) for name in ('operation','kind')]:
  f.write(mem(val(k,8),sz))
end
continue
quit
"""
gdb_program=gdb_program.replace('out=num(rd,8)',f'out=num(rd+{reader_output},8)')
event_program=gdb_program.replace('READER_BINDINGS',str(reader_bindings)).replace('OUTPUT_VISITS',str(output_visits)).replace('OFFSETS',repr(offset))
reader_types=field_offset('CheckInputReader','declared_types')
out_declarations=field_offset('CheckInput','declarations')
out_count=field_offset('CheckInput','token_count')
answer_program=gdb_program[:gdb_program.index('base=rd+READER_BINDINGS')].replace('check_input_resolve_range.buster_split','check_input_binding_events.buster_split')+"""
out=num(rd+READER_OUTPUT,8)
n=num(out+OUTPUT_COUNT,4)
declarations=num(out+OUTPUT_DECLARATIONS,8)
types=num(rd+READER_TYPES,8)
with open(DEST,'wb') as f:
 f.write(struct.pack('<I',n));f.write(mem(declarations,n*4));f.write(mem(types,n*4))
end
continue
quit
"""
answer_program=answer_program.replace('READER_OUTPUT',str(reader_output)).replace('OUTPUT_COUNT',str(out_count)).replace('OUTPUT_DECLARATIONS',str(out_declarations)).replace('READER_TYPES',str(reader_types))
for name,script in [('events',event_program),('answers',answer_program)]:
 data=Path(str(prefix)+'.'+name)
 gdbfile=Path(str(data)+'.gdb')
 import os
 wanted=int(os.environ['LIVE_BINDING_TRACE_TOKENS'])
 condition=f" if *(unsigned int*)(*(unsigned long*)($rdi+{reader_output})+{out_count})=={wanted}"
 script=re.sub(r'(?m)^break ([^\n]+)$',lambda m:'break '+m[1]+condition,script)
 gdbfile.write_text(script.replace('DEST',repr(str(data))))
 result=subprocess.run(['gdb','-nx','-batch','-x',gdbfile,'--args',tree/'build/compiler','-c',*args,'-o',str(prefix)+'.o'],capture_output=True,timeout=120)
 Path(str(data)+'.log').write_bytes(result.stdout+result.stderr)
 assert result.returncode==0 and data.is_file(),result.stderr.decode(errors='replace')[:1000]
 print(name,data.stat().st_size,hashlib.sha256(data.read_bytes()).hexdigest(),flush=True)
