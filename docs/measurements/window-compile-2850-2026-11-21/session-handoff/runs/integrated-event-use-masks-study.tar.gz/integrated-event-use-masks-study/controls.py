"""Check both actual ordinary-backend compositions on forced source suffixes and matched fresh compiler processes."""
from qualify import *
import statistics,time
prior=work/'integrated-live-bindings'
def directed():
 sources=sorted((work/'live-prefix-bindings-study/binding-pulsed').glob('*.c'));assert len(sources)==35
 with (study/'pulsed.tsv').open('w',buffering=1) as f:
  wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['source','policy','mode','status','elf_sha','diagnostics_sha'])
  for src in sources:
   for policy,flags in [('default',[]),('warnings',['-Wall','-Wextra','-ferror-limit=0']),('scalar',['--scalar']),('debug',['-g'])]:
    oracle=None
    for mode,exe in [('ordinary',stock),('parent',parent),('tuples',prior),('candidate',tree),('mismatch',tree),('rewrite',tree)]:
     out=study/'checked.o';out.unlink(missing_ok=True)
     q=subprocess.run([exe/'build/compiler','--lanes','1','-c',*flags,src,'-o',out],env=env(mode,1,False),capture_output=True,timeout=120)
     row=(q.returncode,q.stdout,q.stderr,sha(out.read_bytes() if out.is_file() else b''))
     if oracle is None:oracle=row
     assert row==oracle,(src,policy,mode,row,oracle)
     wr.writerow([src.stem,policy,mode,q.returncode,row[-1],sha(q.stderr)])
def timing():
 arms=[('parent',parent),('prior-tuples',prior),('tuples',tree),('candidate',tree)]
 schedule=[(0,1,3,2),(1,2,0,3),(2,3,1,0),(3,0,2,1),(2,3,1,0),(1,0,2,3),(0,3,1,2),(3,2,0,1)]
 with (study/'paired.tsv').open('w',buffering=1) as f:
  wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['source','metric','round','mode','wall_ms','instructions_u','cycles_u'])
  for name,args in workloads.items():
   for metric,rounds in [('wall',18 if name=='sqlite' else 6),('pmu',12 if name=='sqlite' else 6)]:
    observations={}
    for r in range(rounds):
     for number in schedule[r%len(schedule)]:
      mode,exe=arms[number]
      command=[exe/'build/compiler','--lanes','1','-c',*args,'-o',study/'timed.o']
      if metric=='pmu':command=['perf','stat','--no-big-num','-x,','-e','{instructions:u,cycles:u}','--',*command]
      start=time.perf_counter_ns();q=subprocess.run(command,env=env('tuples' if mode=='prior-tuples' else mode,24,False),capture_output=True,timeout=150);ms=(time.perf_counter_ns()-start)*1e-6
      assert q.returncode==0,(name,mode,q.stderr[:500])
      counters={fields[2]:int(fields[0]) for line in q.stderr.decode().splitlines() if len(fields:=line.split(','))>2 and fields[2] in ('instructions:u','cycles:u')}
      result=(ms,counters.get('instructions:u',''),counters.get('cycles:u',''));observations[(r,mode)]=result;wr.writerow([name,metric,r,mode,*result])
    for k,label in ([(0,'ms')] if metric=='wall' else [(1,'user instructions'),(2,'user cycles')]):
     for ref,exe in arms[:-1]:
      delta=[observations[r,'candidate'][k]-observations[r,ref][k] for r in range(rounds)]
      print(name,label,'event masks minus',ref,statistics.median(delta),sum(x<0 for x in delta),'of',rounds,flush=True)
if __name__=='__main__':directed();timing()
