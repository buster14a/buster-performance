set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
break check_input_binding_events.buster_split if *(unsigned int*)(*(unsigned long*)($rdi+16)+1940)==716136
run
set $reader=$rdi
finish
python
import struct, gdb
p=gdb.selected_inferior()
rd=int(gdb.parse_and_eval('$reader'))
def mem(addr,n): return bytes(p.read_memory(addr,n)) if n else b''
def num(addr,n): return int.from_bytes(mem(addr,n),'little')
base=rd+416
offset={'heads': 8, 'name_capacity': 16, 'active': 32, 'active_count': 40, 'count': 24, 'operation': 96, 'kind': 104, 'key': 48, 'declaration': 56, 'point': 64, 'end': 72, 'previous': 80, 'depth': 88}
def val(k,width):return num(base+offset[k],width)
out=num(rd+16,8)
visits=num(out+2064,4)
events=val('count',4)
names=val('name_capacity',4)
active=val('active_count',4)
with open('/home/david/Documents/Codex/2026-11-21/g/work/integrated-event-use-masks-study/trace-sqlite-candidate.events','wb') as f:
 f.write(struct.pack('<4I',visits,events,names,active))
 for k,sz in [('heads',4*names*3),('active',4*active)]+[(name,4*events) for name in ('key','declaration','point','end','previous','depth')]+[(name,events) for name in ('operation','kind')]:
  f.write(mem(val(k,8),sz))
end
continue
quit
