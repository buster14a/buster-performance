#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d="$PWD"
for name in live-binding-event-pages live-binding-event-stream integrated-live-bindings integrated-event-use-masks; do
 (cd "../$name" && ./build/compiler test-bindings) >"$d/test-bindings-$name.log" 2>&1
done
cd ../integrated-event-use-masks
for i in {1..8}; do
 ./build/compiler test-checker --seed 2850 --part "$i/8" >"$d/checker-$i.log" 2>&1
done
