#!/bin/bash
set -eu
cd "$(dirname "$0")"
root='cd ~/buster-fast-bench/2850-codex-step2'
until ssh benchpress "$root && grep -q '^COMPLETE$' sizeofspan7f-wall-repeat.log"; do sleep 20; done
ssh benchpress "$root && tar cf - sizeofspan7f-wall-repeat.log results/sizeofspan7f-wall-repeat" | tar xf - -C hardware
python3 repeat.py
