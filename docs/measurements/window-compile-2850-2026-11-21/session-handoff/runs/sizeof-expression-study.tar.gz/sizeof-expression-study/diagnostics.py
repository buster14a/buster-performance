from pathlib import Path
import csv, hashlib, subprocess
here=Path(__file__).resolve().parent; w=here.parent; dst=here/'diagnostics'; dst.mkdir(exist_ok=True)
clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
base=w/'default-integer-control/build/compiler'; cand=w/'sizeof-expression-spans/build/compiler'
common=['-std=gnu17','-fno-caret-diagnostics']
hashv=lambda data: hashlib.sha256(data).hexdigest()
cases={
    'nested':(here/'nested.c').read_text(),
    'both':'''int a[4], b[5]; unsigned long f(void){return sizeof((a,b)) + sizeof(((b,a)));}''',
    'array-pointer':'''int a[4]; void f(int (*p)[4]){ (void)sizeof(*p+1); (void)sizeof((a)+1); (void)__alignof__(a+1); (void)sizeof a; }''',
    'side-effect':'''int a[7]; unsigned long f(int n){return sizeof((a+n++));}''',
    'conditional':'''int a[9]; unsigned long f(int n){return sizeof((n ? a : a)+1) + sizeof((a+1)[0]);}''',
    'no-query':'''int a[5]; int f(int n){int *p=a; p+=n; return p-a;}''',
    'outer-type':'''int a[5]; unsigned long f(void){return sizeof(int[1 + !!sizeof(a+1)]);}''',
    'negative':'''int a[3]; int f(void){return sizeof(a+1);} int broken(void){return (1+; }''',
    'bad-function':'''int a[5]; int f(int n){ int x=sizeof(a+1); int y=undeclared; return sizeof((a+1))+x+y; }''',
    'recovered-operand':'''int a[4]; int f(void){return sizeof(a+1) + sizeof(undeclared+1) + sizeof(a+1);}''',
    'pragma':'''int a[2];\n#pragma clang diagnostic push\n#pragma clang diagnostic ignored "-Wsizeof-array-decay"\nint x=sizeof(a+1);\n#pragma clang diagnostic pop\nint y=sizeof(a+1);\n''',
    'nongrouped':'''int a[3]; unsigned long f(void){return sizeof *a + sizeof a + sizeof(int) + __alignof__(a+1);}''',
}
for shift in range(64):
    cases[f'align-{shift:02d}']=';'*shift+'int a[2]; int f(void){return sizeof((a + sizeof(a+1))) + sizeof(a+1);}'
policies=[('normal',[]),('error',['-Werror']),('quiet',['-w']),('ignored',['-Wno-sizeof-array-decay'])]
with (here/'diagnostics.tsv').open('w') as file:
    wr=csv.writer(file,delimiter='\t',lineterminator='\n')
    wr.writerow(['case','policy','action','baseline-rc','candidate-rc','clang-rc','candidate=baseline-all','candidate=clang-diagnostics','baseline-stderr-sha256','clang-stderr-sha256','native-elf-sha256'])
    for name,code in cases.items():
        src=dst/(name+'.c');src.write_text(code+'\n')
        for policy,extra in policies:
            for action in ['-c','-fsyntax-only']:
                records=[]
                for who,exe in [('old',base),('candidate',cand),('clang',clang)]:
                    obj=dst/'one.o';obj.unlink(missing_ok=True)
                    opt= ['-o',str(obj)] if action=='-c' else []
                    x=subprocess.run([exe,*common,*extra,action,src,*opt],capture_output=True,timeout=45)
                    records.append((x.returncode,x.stdout,x.stderr,hashv(obj.read_bytes()) if obj.exists() else '-'))
                old,new,external=records
                same=old==new
                clang_match=external[:3]==new[:3]
                if not same or not clang_match:
                    for who,rec in zip(('old','candidate','clang'),records):
                        (dst/(name+'-'+policy+'-'+action+'-'+who+'.stderr')).write_bytes(rec[2])
                wr.writerow([name,policy,action,old[0],new[0],external[0],int(same),int(clang_match),hashv(old[2]),hashv(external[2]),new[3]])
                if not same: raise RuntimeError((name,policy,action))
        file.flush()
