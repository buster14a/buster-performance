#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; w=${d%/*}; src=$w/sizeof-expression-spans; baseline=$w/default-integer-control/build/compiler
while [[ ! -s "$d/7f31573fd.built" || ! -x "$src/build/compiler" || ! -s "$src/build/predefines.h" ]]; do sleep 5; done
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
export CORES_TITLE='2850 sizeof expression spans native, diagnostic and corpus qualification'
export CORES_LINK=https://github.com/buster14a/buster/issues/2850
cores -n 1 -- python3 "$d/diagnostics.py" >"$d/diagnostic-matrix.log" 2>&1
cores -n 1 -- python3 "$d/source-regions.py" >"$d/source-regions.log" 2>&1
cd "$w/switch-inputs"
source ../switch-local-args.sh
tree=$w/pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $w/proof-predefines.h $tree/src/buster/compiler/main.c"
mkdir -p "$d/corpus"
for group in sqlite main lua musl; do
 v=${group}_arguments; eval "args=(${!v})"
 cores -n 1 -- python3 "$w/default-object-qa/pair.py" "$d/corpus" "$group" "$baseline" "$src/build/compiler" "${args[@]}" >"$d/$group.log" 2>&1
done
