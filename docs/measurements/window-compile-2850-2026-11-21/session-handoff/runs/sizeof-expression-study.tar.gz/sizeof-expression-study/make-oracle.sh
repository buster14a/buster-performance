#!/bin/bash
set -eu
cd "$(dirname "$0")"
{
 cat <<'HEADER'
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
enum { PARSE_ROLE_CLOSE_SIZEOF = 1, PARSE_ROLE_OPEN_SIZEOF = 2, PARSE_ROLE_CLOSE_GROUP = 3 };
typedef struct { uint32_t first, end; } CheckSizeofSpan;
typedef struct { struct {uint32_t count;} tokens; struct {uint8_t* roles; uint32_t* parents;} tree; } Parser;
typedef struct { CheckSizeofSpan* sizeof_spans; uint32_t sizeof_span_count; } CheckInput;
typedef struct { CheckInput* output; const Parser* parser; const uint32_t* ends; } CheckInputReader;
HEADER
 sed -n '/^static CheckSizeofSpan check_sizeof_decay_span(/,/^static void check_input_sizeof_prepare(/{ /^static void check_input_sizeof_prepare(/!p; }' ../sizeof-expression-spans/src/buster/compiler/c_check_sizeof_input.c
 cat ranges.c
} >ranges-oracle.c
cc -O2 -std=c17 -Wall -Wextra -Werror ranges-oracle.c -o ranges-oracle
./ranges-oracle >ranges.tsv
