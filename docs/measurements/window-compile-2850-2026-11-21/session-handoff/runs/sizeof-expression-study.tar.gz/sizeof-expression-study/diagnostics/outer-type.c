int a[5]; unsigned long f(void){return sizeof(int[1 + !!sizeof(a+1)]);}
