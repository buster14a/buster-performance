int a[9]; unsigned long f(int n){return sizeof((n ? a : a)+1) + sizeof((a+1)[0]);}
