int a[4], b[5]; unsigned long f(void){return sizeof((a,b)) + sizeof(((b,a)));}
