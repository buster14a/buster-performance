int a[8], b[4];
#define ADD(v) ((v) + 1)
#define N8(n) ((n)+(n)+(n)+(n)+(n)+(n)+(n)+(n))
unsigned long f(int n) {
    return sizeof((a + sizeof((b + (N8(n) + N8(n)))))) + sizeof(ADD(a)) + sizeof b;
}

