int a[3]; unsigned long f(void){return sizeof *a + sizeof a + sizeof(int) + __alignof__(a+1);}
