int a[3]; int f(void){return sizeof(a+1);} int broken(void){return (1+; }
