int a[4]; int f(void){return sizeof(a+1) + sizeof(undeclared+1) + sizeof(a+1);}
