int a[5]; int f(int n){int *p=a; p+=n; return p-a;}
