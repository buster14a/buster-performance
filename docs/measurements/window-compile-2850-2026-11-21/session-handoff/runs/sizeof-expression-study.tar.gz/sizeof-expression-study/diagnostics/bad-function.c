int a[5]; int f(int n){ int x=sizeof(a+1); int y=undeclared; return sizeof((a+1))+x+y; }
