int a[7]; unsigned long f(int n){return sizeof((a+n++));}
