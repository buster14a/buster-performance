int a[2];
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wsizeof-array-decay"
int x=sizeof(a+1);
#pragma clang diagnostic pop
int y=sizeof(a+1);

