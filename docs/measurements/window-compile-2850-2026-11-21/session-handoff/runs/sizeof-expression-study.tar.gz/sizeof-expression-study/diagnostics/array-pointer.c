int a[4]; void f(int (*p)[4]){ (void)sizeof(*p+1); (void)sizeof((a)+1); (void)__alignof__(a+1); (void)sizeof a; }
