;;;;;;;;;;;;int a[2]; int f(void){return sizeof((a + sizeof(a+1))) + sizeof(a+1);}
