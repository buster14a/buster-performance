#!/bin/bash
set -eu
cd "$(dirname "$0")/../sizeof-expression-spans"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh --config Develop --target compiler --jobs 1 >../sizeof-expression-study/build.log 2>&1
cp ../default-integer-control/build/predefines.h build/predefines.h
git rev-parse HEAD >../sizeof-expression-study/7f31573fd.built
