from pathlib import Path
import csv,statistics
p=Path(__file__).resolve().parent/'hardware';raw=p/'results/sizeofspan7f-wall-repeat'
rows=list(csv.DictReader((raw/'order.tsv').open(),delimiter='\t'));assert len(rows)==56
with (p/'sqlite-wall-repeat-samples.tsv').open('w') as out,(p/'sqlite-wall-repeat-paired.tsv').open('w') as paired:
    wr=csv.writer(out,delimiter='\t',lineterminator='\n');wr.writerow(['round','position','mode','wall-ms','minor-faults','major-faults'])
    wp=csv.writer(paired,delimiter='\t',lineterminator='\n');wp.writerow(['round','baseline-ms','candidate-ms','paired-difference-ms'])
    ds=[];old=[];new=[]
    for r in range(1,15):
        seq=[x for x in rows if int(x['round'])==r]
        arms=[x['mode'] for x in seq];assert len(seq)==4 and arms==arms[::-1] and arms.count('candidate')==2
        vals={}
        for x in seq:
            stem=f"wall-{r}-{x['position']}"
            a=next(csv.DictReader((raw/(stem+'.wall')).open(),delimiter='\t'));assert int(a['status'])==0
            t=int(a['wall-ns'])/1e6;vals.setdefault(x['mode'],[]).append(t)
            assert (raw/(stem+'.objects')).read_bytes()==(p/'results/ordinary-pair-sizeofspan7f-sqlite/preflight-baseline.objects').read_bytes()
            for e in ['stdout','stderr']:assert (raw/(stem+'.'+e)).read_bytes()==(p/('results/ordinary-pair-sizeofspan7f-sqlite/preflight-baseline.'+e)).read_bytes()
            wr.writerow([r,x['position'],x['mode'],t,a['minor-faults'],a['major-faults']])
        a=statistics.mean(vals['baseline']);b=statistics.mean(vals['candidate']);old.append(a);new.append(b);ds.append(b-a);wp.writerow([r,a,b,b-a])
with (p/'sqlite-wall-repeat-summary.tsv').open('w') as f:
    s=csv.writer(f,delimiter='\t',lineterminator='\n');s.writerow(['rounds','faster','baseline-median-ms','candidate-median-ms','paired-median-ms','paired-min-ms','paired-max-ms']);s.writerow([len(ds),sum(x<0 for x in ds),statistics.median(old),statistics.median(new),statistics.median(ds),min(ds),max(ds)])
