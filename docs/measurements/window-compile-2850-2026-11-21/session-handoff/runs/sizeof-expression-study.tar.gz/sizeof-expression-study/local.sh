#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; w=${d%/*}
while [[ ! -s "$d/7f31573fd.built" || ! -x "$w/sizeof-expression-spans/build/compiler" || ! -s "$w/sizeof-expression-spans/build/predefines.h" ]]; do sleep 8; done
cd "$w/switch-inputs"; source ../switch-local-args.sh; eval "args=($sqlite_arguments)"
export CORES_TITLE='2850 local same-head ordinary SQLite counters for sizeof operand scans'
export CORES_LINK=https://github.com/buster14a/buster/issues/2850
for r in {1..3}; do
 if ((r%2)); then labels=(default-integer-control sizeof-expression-spans); else labels=(sizeof-expression-spans default-integer-control); fi
 for label in "${labels[@]}"; do
  stem="$d/local-$r-$label"
  cores -n 1 -- perf stat --no-big-num -x, -o "$stem.perf" -e instructions:u,cycles:u,duration_time,minor-faults -- "$w/$label/build/compiler" -c "${args[@]}" -o "$d/local.o" >"$stem.stdout" 2>"$stem.stderr"
  sha256sum "$d/local.o" >"$stem.object"
 done
done
