#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; cd ../sizeof-expression-spans
while [[ ! -s "$d/7f31573fd.built" || ! -x build/compiler || ! -s build/predefines.h ]]; do sleep 8; done
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
export CORES_TITLE='2850 permanent checker and diagnostic source suites for sizeof ranges'
export CORES_LINK=https://github.com/buster14a/buster/issues/2850
cores -n 1 -- ./build/compiler test-checker --attested --seed 2850 >"$d/attested.log" 2>&1
cores -n 1 -- ./build/compiler test-checker --seed 2850 >"$d/checker-all.log" 2>&1
cores -n 1 -- ./build/compiler test-checker-driver --executable ./build/compiler >"$d/checker-driver-all.log" 2>&1
