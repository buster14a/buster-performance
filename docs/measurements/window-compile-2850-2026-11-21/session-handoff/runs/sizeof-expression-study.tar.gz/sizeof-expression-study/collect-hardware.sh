#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD
mkdir -p "$d/hardware"
root='cd ~/buster-fast-bench/2850-codex-step2'
while ! ssh benchpress "$root && grep -q '^SQLITE_COMPLETE$' sizeofspan7f-job.log"; do sleep 20; done
ssh benchpress "$root && tar cf - corpora.sh sizeofspan7f-job.log results/main40ae/{revision.txt,compiler.sha256} results/sizeofspan7f/{revision.txt,compiler.sha256,build.log,build-clock.log} results/ordinary-pair-sizeofspan7f-sqlite" | tar xf - -C "$d/hardware"
python3 "$d/paired.py" "$d/hardware" sqlite >"$d/hardware/sqlite-verified.txt"
while ! ssh benchpress "$root && grep -q '^ALL_COMPLETE$' sizeofspan7f-job.log"; do sleep 20; done
ssh benchpress "$root && tar cf - sizeofspan7f-job.log results/ordinary-pair-sizeofspan7f-{main,lua,musl}" | tar xf - -C "$d/hardware"
for group in main lua musl; do python3 "$d/paired.py" "$d/hardware" "$group" >"$d/hardware/$group-verified.txt"; done
