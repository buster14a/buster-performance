from pathlib import Path
import csv,hashlib,shutil,statistics,subprocess,tarfile
d=Path(__file__).resolve().parent;w=d.parent
pub=w/'sizeof-spans-evidence/docs/measurements/sizeof-array-decay-spans-2850-2026-11-22'
pub.mkdir(parents=True,exist_ok=True)
def rows(f):return list(csv.DictReader(f.open(),delimiter='\t'))
for n in ['diagnostics.tsv','source-regions.tsv','ranges.tsv','typed.tsv','corpus-summary.tsv','local-summary.tsv']:
    shutil.copy(d/n,pub/n)
for g in ['sqlite','main','lua','musl']:
    for k in ['summary','samples','paired']:shutil.copy(d/'hardware'/(g+'-'+k+'.tsv'),pub/(g+'-'+k+'.tsv'))
for k in ['summary','samples','paired']:shutil.copy(d/'hardware'/('sqlite-wall-repeat-'+k+'.tsv'),pub/('sqlite-wall-repeat-'+k+'.tsv'))
patch=d/'host/sizeofspan7f.patch'
rev=(d/'hardware/results/sizeofspan7f/revision.txt').read_text()
assert rev.splitlines()[0]=='40ae34f9d77afc42face58eff3338b7b1d1ba469'
assert hashlib.sha256(patch.read_bytes()).hexdigest() in rev
assert subprocess.check_output(['git','-C',w/'sizeof-expression-spans','diff','--binary','40ae34f9d','7f31573fd'])==patch.read_bytes()
shutil.copy(patch,pub/'implementation.patch')
with tarfile.open(pub/'reproduce.tar.xz','w:xz') as t:
    for n in ['host','build.sh','make-oracle.sh','ranges.c','nested.c','diagnostics.py','source-regions.py','source-qa.sh','suites.sh','local.sh','collect-hardware.sh','collect-repeat.sh','paired.py','repeat.py','package.py']:
        t.add(d/n,arcname=n)
    t.add(w/'default-object-qa/pair.py',arcname='per-source-object-pairs.py')
    for n in ['live-fallback.py','nested.c','long-mask.c','warning-error.c']:
        t.add(w/'sizeof-mask-study'/n,arcname='fallback/'+n)
with tarfile.open(pub/'hardware.tar.xz','w:xz') as t:
    for b in ['main40ae','sizeofspan7f']:
        for n in ['compiler.sha256','revision.txt']:
            t.add(d/'hardware/results'/b/n,arcname=b+'/'+n)
    t.add(d/'hardware/results/main40ae/build.log',arcname='main40ae/build.log')
    for n in ['build.log','build-clock.log','inputs.tsv','inputs.lock']:t.add(d/'hardware/results/sizeofspan7f'/n,arcname='sizeofspan7f/'+n)
    t.add(d/'hardware/proof-predefines.h',arcname='proof-predefines.h');t.add(d/'hardware/corpora.sh',arcname='corpora.sh');t.add(d/'hardware/sizeofspan7f-job.log',arcname='job.log')
    t.add(d/'hardware/results/sizeofspan7f-wall-repeat',arcname='sqlite-wall-repeat');t.add(d/'hardware/sizeofspan7f-wall-repeat.log',arcname='sqlite-wall-repeat.log')
    for g in ['sqlite','main','lua','musl']:
        base=d/'hardware/results'/('ordinary-pair-sizeofspan7f-'+g)
        for f in sorted(base.iterdir()):t.add(f,arcname=g+'/'+f.name)
with tarfile.open(pub/'source-controls.tar.xz','w:xz') as t:
    for n in ['diagnostics','corpus','source-observations','dco.tsv','ranges-oracle.c','build.log','attested.log','sqlite-source-regions.log','main-source-regions.log']:
        t.add(d/n,arcname=n)
    for p in sorted(d.glob('checker*.log')):t.add(p,arcname=p.name)
    for p in sorted(d.glob('local-*')):t.add(p,arcname=p.name)
    views=w/'sizeof-mask-study/view-controls-sizeof-expression-spans'
    assert len(rows(views/'results.tsv'))==18
    for pattern in ['results.tsv','*.gdb','*.stderr']:
        for entry in sorted(views.glob(pattern)):t.add(entry,arcname='fallback/'+entry.name)
diagnostics=rows(d/'diagnostics.tsv');assert all(r['candidate=baseline-all']=='1' for r in diagnostics)
corpus=[]
for g in ['sqlite','main','lua','musl']:
    v=rows(d/'corpus'/(g+'.tsv'));assert len(v)=={'sqlite':3,'main':3,'lua':102,'musl':4008}[g] and all(x['same']=='1' and x['code']=='0' and x['object']!='-' for x in v),g;corpus.append((g,len(v)))
assert 'checks, 0 failures' in (d/'attested.log').read_text()
for suite in ['checker','checker-driver']:
    f=d/(suite+'-all.log');assert 'checks, 0 failures' in f.read_text(),f
local=[]
for rd in [1,2,3]:
    counts=[]
    for ref in ['default-integer-control','sizeof-expression-spans']:
        st=d/f'local-{rd}-{ref}'
        with (d/(st.name+'.perf')).open() as perf:
            counters={x[2]:(int(x[0]),float(x[4])) for x in csv.reader(perf) if len(x)>=5}
        assert counters['instructions:u'][1]==100
        counts.append(counters['instructions:u'][0])
    local.append((rd,*counts,counts[1]-counts[0]))
with (pub/'local-counter-pairs.tsv').open('w') as f:
    writer=csv.writer(f,delimiter='\t',lineterminator='\n');writer.writerow(['round','ordinary-user-instructions','candidate-user-instructions','difference']);writer.writerows(local)
text=['# Source ranges for the sizeof array decay warning','',
'Ordinary compilation in the parent checked additive, assignment and comma operators throughout the unit, then followed each candidate’s parents to look for a parenthesized `sizeof`. The source reader already visits every size-query keyword and owns the exact subtree ends. It now retains the union of possible operand intervals before releasing the traversal. The diagnostic pass checks its usual operators inside that union in the original order. [Measured implementation](implementation.patch)','',
'An operator that could report has a preceding `sizeof` opener and reaches that opener’s closing node through zero or more parentheses. Its token therefore follows the opener and is bounded by the last token in the closer’s subtree. Each recorded interval starts after the opener and ends one token past that subtree. Taking their union preserves every reporting candidate, including nested expressions and recovered trees with a descendant beyond the closing token. The original warning logic still verifies the nearest opener, source spelling, operand and result types, messages and publication location. A view with its own traversal can recover the same bounds directly. A view without either source of complete intervals uses the original operator scan.','',
'## Performance','',
'The Buster source workload uses commit `84a7d3d76891d6c393497e62e6aff38f2b162fc2`. The input manifest records every source path, byte count and SHA-256. The baseline used the native Release compiler at `40ae34f9d77afc42face58eff3338b7b1d1ba469`. The candidate applied the complete source diff through `7f31573fd00a095e9e19de1a583c7ae7c94a2037` to that same base before its native Release build. The stored patch matches the build record’s SHA-256. Each measured compiler process used one Ryzen 7 9700X physical core, CPU 2. Each process individually acquired and released the machine lock. The native monotonic clock forked and waited for one compiler. Separately admitted `perf stat` invocations collected user and kernel counters. Each round used ABBA or BAAB order. Absolute columns are medians across rounds of the two observations per compiler. Differences are medians of the paired round differences. [Exact commands, build IDs, individual reports and complete object manifests](hardware.tar.xz)','',
'| Source | Ordinary ms | Candidate ms | Paired elapsed ms [min, max] | Faster rounds | Paired user instructions | Paired total cycles |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for g in ['sqlite','main','lua','musl']:
    rs={x['metric']:x for x in rows(pub/(g+'-summary.tsv'))};r=rs['wall-ms']
    text.append(f"| [{g}]({g}-summary.tsv) | {float(r['baseline-median']):.3f} | {float(r['candidate-median']):.3f} | {float(r['paired-median']):+.3f} [{float(r['paired-min']):+.3f}, {float(r['paired-max']):+.3f}] | {r['faster-rounds']}/{r['rounds']} | {float(rs['user-instructions']['paired-median']):+,.0f} | {float(rs['total-cycles']['paired-median']):+,.0f} |")
wall=next(r for r in rows(pub/'sqlite-summary.tsv') if r['metric']=='wall-ms')
text+=['',f"The {9507037:,}-byte SQLite source requires 9.507 ms at 1 GB/s. The original seven-round candidate median corresponds to {9507037/(1000*float(wall['candidate-median'])):.2f} MB/s. [Seven-round SQLite measurements](sqlite-summary.tsv)"]
text+=['',f"Three independently admitted local Develop pairs on the Ryzen 9 7940HS changed user instructions by a median {statistics.median(r[-1] for r in local):+,.0f}. The local duration counter returned zero, so the elapsed results above come from the controlled Ryzen 7 9700X. [Local counters](local-counter-pairs.tsv)"]
repeat=rows(pub/'sqlite-wall-repeat-summary.tsv')[0]
text+=['',f"A separately scheduled SQLite elapsed-only replication used 14 additional alternating rounds of four fresh processes. Its median paired difference was {float(repeat['paired-median-ms']):+.3f} ms, with {repeat['faster']} shorter rounds out of 14. [Replicated elapsed measurements](sqlite-wall-repeat-summary.tsv)"]
if float(wall['paired-median'])>=0 and float(repeat['paired-median-ms'])>=0:
    text+=['','Both SQLite elapsed series had longer median paired times for the new code. The elapsed measurements favor the ordinary implementation for this workload.']
r=rows(d/'ranges.tsv')[0]; text+=['','## Source and diagnostic qualification','',
f"The independent tree oracle tested {int(r['forests']):,} generated forests with arbitrary parent/source order. Every operator with a qualifying opener and closing ancestor belonged to the union. This included {int(r['qualified-after-close']):,} after the closer itself. The test extracted the two exact production range functions. [Forest checks](ranges.tsv) · [Reproduction source](reproduce.tar.xz)",'',
f"All {len(diagnostics):,} source, warning-policy and action combinations matched the earlier compiler’s entire diagnostics, exit status, standard output and native ELF when created. {sum(x['candidate=clang-diagnostics']=='1' for x in diagnostics):,} also matched independent Clang diagnostics and status exactly. Both Buster builds omit the inner decay warning in a type-name array bound and the sibling decay warnings surrounding an undeclared operand. Clang also emits an additional closing-parenthesis diagnostic in one invalid function. All 18 live parser-view controls forced the stored index, a foreign input with independently derived complete subtree ends, or the whole-unit fallback. The exact diagnostics, exit codes and ELF matched in each case, including a 2,339-token gap before the warning operator and pragma promotion to an error. The dedicated attested schema checks and both complete checker and checker-driver suites passed. The source matrix contains nested macros, all 64 starting alignments, invalid operands and recovered declarations. [Diagnostic comparisons](diagnostics.tsv) · [Sources, corpus manifests, complete output differences against Clang, and suite logs](source-controls.tar.xz)",'',
f"Default, `-Wall -Wextra` and `-Weverything -Wno-c++-compat` controls compiled {sum(v for _,v in corpus):,} workload source/policy combinations on the local native host. Every complete object, diagnostic stream and exit status matched the parent. The complete typed dumps for ordinary SQLite and Buster also matched the parent byte for byte. Fresh GDB captures measured the union of source intervals directly in the ordinary warning pass. [Typed output and object hashes](typed.tsv) · [Source ranges and selected operator counts](source-regions.tsv)",'']
(pub/'README.md').write_text('\n'.join(text))
