#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; group=$1
case "$group" in main|lua|musl) ;; *) exit 2;; esac
root='cd ~/buster-fast-bench/2850-codex-step2'
until ssh benchpress "$root && test -s results/ordinary-pair-sizeofspan7f-$group/order.tsv && test \"\$(wc -l < results/ordinary-pair-sizeofspan7f-$group/order.tsv)\" = 25"; do sleep 20; done
tmp=$(mktemp -d "$d/early-$group-XXXXXXXX")
mkdir -p "$tmp/results"
ssh benchpress "$root && tar cf - results/ordinary-pair-sizeofspan7f-$group" | tar xf - -C "$tmp"
python3 "$d/paired.py" "$tmp" "$group" >"$tmp/$group-verified.txt"
cat "$tmp/$group-summary.tsv"
