// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Time one ordinary compiler process and retain its wait4 resource counters.
#define _DEFAULT_SOURCE
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static int64_t nanoseconds(struct timespec moment)
{
    return (int64_t)moment.tv_sec * 1000000000 + moment.tv_nsec;
}

int main(int argc, char** argv)
{
    if (argc < 3)
    {
        return 2;
    }
    struct timespec before, after;
    struct rusage usage;
    int status = 0;
    if (clock_gettime(CLOCK_MONOTONIC, &before) != 0)
    {
        return 1;
    }
    const pid_t pid = fork();
    if (pid == 0)
    {
        execv(argv[2], argv + 2);
        _exit(127);
    }
    if (pid < 0 || wait4(pid, &status, 0, &usage) != pid || clock_gettime(CLOCK_MONOTONIC, &after) != 0)
    {
        return 1;
    }
    FILE* out = fopen(argv[1], "w");
    if (out == NULL)
    {
        return 1;
    }
    const int rc = WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
    fprintf(out, "wall-ns\tminor-faults\tmajor-faults\tuser-us\tsystem-us\tmaxrss-kib\tstatus\n");
    fprintf(out, "%" PRId64 "\t%ld\t%ld\t%ld\t%ld\t%ld\t%d\n", nanoseconds(after) - nanoseconds(before), usage.ru_minflt, usage.ru_majflt,
            usage.ru_utime.tv_sec * 1000000 + usage.ru_utime.tv_usec, usage.ru_stime.tv_sec * 1000000 + usage.ru_stime.tv_usec, usage.ru_maxrss, rc);
    return fclose(out) == 0 ? rc : 1;
}
