#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2
source corpora.sh
main_arguments="-march=native -I$PWD/pooled-main-source/src -fwrapv -funsigned-char --predefines $PWD/proof-predefines.h $PWD/pooled-main-source/src/buster/compiler/main.c"
printf 'unit\tbytes\tsha256\tpath\n'
for group in sqlite main lua musl; do
    v=${group}_arguments; eval "args=(${!v})"
    for arg in "${args[@]}"; do
        if [[ $arg == *.c || $arg == */proof-predefines.h ]]; then
            h=$(sha256sum "$arg");printf '%s\t%s\t%s\t%s\n' "$group" "$(stat -c %s "$arg")" "${h%% *}" "$arg"
        fi
    done
done
