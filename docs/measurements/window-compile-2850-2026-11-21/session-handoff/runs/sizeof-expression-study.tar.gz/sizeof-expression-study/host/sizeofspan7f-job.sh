#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2
base=40ae34f9d77afc42face58eff3338b7b1d1ba469
label=sizeofspan7f
./build-label.sh "$label" "$base" "$label.patch"
./lock.sh cc -O2 -std=c17 sizeofspan-wall.c -o "results/$label/one-process-clock" > "results/$label/build-clock.log" 2>&1
while [[ ! -s results/main40ae/.built ]]; do if grep -q 'build failed' main40ae-job.log; then exit 1; fi; sleep 15; done
bash "$label.sh" "$label" sqlite 1 7
echo SQLITE_COMPLETE
for corpus in main lua musl; do bash "$label.sh" "$label" "$corpus" 1 3; done
echo ALL_COMPLETE
