#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2
label=sizeofspan7f
until grep -q '^SQLITE_COMPLETE$' "$label-job.log"; do sleep 15; done
out=$PWD/results/$label-wall-repeat
mkdir -p "$out"
test ! -e "$out/order.tsv"
printf 'round\tposition\tmode\n' >"$out/order.tsv"
scratch=$(mktemp -d /dev/shm/buster2850-sizeof-repeat.XXXXXXXX)
trap 'rm -f -- "$scratch"/*.o; rmdir "$scratch"' EXIT
exec 8>our-timing.lock
for n in {1..14}; do
 if ((n%2)); then arms=(candidate baseline baseline candidate); else arms=(baseline candidate candidate baseline); fi
 flock -x 8
 pos=0
 for arm in "${arms[@]}"; do
  pos=$((pos+1));stem="$out/wall-$n-$pos"
  ./lock.sh taskset -c 2 bash "$label-one.sh" "$label" sqlite "$arm" wall "$stem" "$scratch" >"$stem.lock" 2>&1
  cmp "$stem.objects" "results/ordinary-pair-$label-sqlite/preflight-baseline.objects"
  for stream in stdout stderr; do cmp "$stem.$stream" "results/ordinary-pair-$label-sqlite/preflight-baseline.$stream"; done
  printf '%d\t%d\t%s\n' "$n" "$pos" "$arm" >>"$out/order.tsv"
 done
 flock -u 8
done
echo COMPLETE
