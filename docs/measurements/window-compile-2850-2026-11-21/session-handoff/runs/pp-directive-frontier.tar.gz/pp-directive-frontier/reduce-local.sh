#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD
python3 reduce-macros.py
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";input=${args[-1]}
for f in single erasing all assert empty;do
 PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$d/macro-$f.c" PP_PRINT="$d/macro-$f.i" "$d/../pp-structural-study/probe" "${args[@]}" >"$d/macro-$f.preflight" || true
 cmp -s "$d/macro-$f.i" "$d/../pp-structural-study/original.i" && a=identical || a=differs
 echo "$f $a"
done
