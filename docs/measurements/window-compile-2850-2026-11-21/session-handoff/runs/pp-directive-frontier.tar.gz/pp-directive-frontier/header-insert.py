from pathlib import Path
d=Path(__file__).resolve().parent;dir=d.parent/'pp-header-front/src/buster/compiler'
p=dir/'c_preprocessor.c';s=p.read_text();k=s.index('    uint32_t directive_count;',s.index('struct PPFileData\n{'));s=s[:k]+'#ifdef BUSTER_PP_HEADER_SOURCE\n    uint32_t* header_excluded;\n#endif\n'+s[k:];k=s.index('    uint32_t range;',s.index('struct PPContext\n{'));s=s[:k]+'#ifdef BUSTER_PP_HEADER_SOURCE\n    uint32_t header_confirmed;\n#endif\n'+s[k:];p.write_text(s)
p=dir/'c_preprocessor_impl.c';s=p.read_text();k=s.index('static bool pp_prepare_data(');s=s[:k]+'#ifdef BUSTER_PP_HEADER_SOURCE\n#include "buster/compiler/c_pp_header_source.c"\n#endif\n'+s[k:];needle='    if (data->record == BUSTER_PP_NONE)';k=s.index(needle,k);s=s[:k]+'''#ifdef BUSTER_PP_HEADER_SOURCE
    if(header_project(pp,data,path))status=PP_PREPARE_DONE;
    else
#endif
'''+s[k:];k=s.index('    const bool relexed = context->relexed;',s.index('void pp_pop_context('));s=s[:k]+'''#ifdef BUSTER_PP_HEADER_SOURCE
    if(pp_header && context->kind==BUSTER_PP_CONTEXT_FILE)
    {
        const PPFileData* d=&pp->datas[context->data];
        if(d->header_excluded)
        {
            pp_header->entries++;
            const uint32_t omitted=d->header_excluded[d->directive_count+1];
            pp_header->confirmed+=context->header_confirmed;
            if(context->header_confirmed!=omitted)
            {
                if(getenv("HEADER_MISSES"))fprintf(stderr,"header skip mismatch %u/%u %s\\n",context->header_confirmed,omitted,pp->files[context->file].path);
                pp_header->failed=true;pp_header->misses++;
            }
        }
    }
#endif
'''+s[k:];k=s.index('    if (pp->conditional_count > context->conditional_base)',s.index('const uint32_t next = context->hidden_directives ? pp_skip_relexed_group'));s=s[:k]+'''#ifdef BUSTER_PP_HEADER_SOURCE
    if(pp_header && data->header_excluded)
    {
        const uint32_t next_d=context->next_directive;
        if(context->hidden_directives || next_d<d || next_d>data->directive_count)pp_header->failed=true;
        else context->header_confirmed+=data->header_excluded[next_d+1]-data->header_excluded[d+1];
    }
#endif
'''+s[k:];p.write_text(s)
(dir/'c_pp_header_source.c').write_bytes((d/'header-front.inc').read_bytes())
s=(d.parent/'pp-structural-study/single-gap.c').read_text();s='#define BUSTER_PP_HEADER_SOURCE 1\n'+s[s.index('#include'):];a=s.index('    PPProjection plan=');b=s.index('    pp_diagnostic_publish(&pp);',a)
s=s[:a]+'''    PPHeaderTrial trial_state={.main_path=input,.loose=getenv("HEADER_LOOSE")!=NULL};
    const bool selected=getenv("PP_EAGER")==NULL && !options.assembly && !options.preprocessed;
    pp_header=selected?&trial_state:NULL;
    if(!projected_init(&pp,&table,&options))return 1;
    bool okay=pp_run(&pp,input);
    const bool verified=selected && okay && !pp.errors && !pp.warnings && !trial_state.failed;
    pp_header=NULL;
    if(selected && !verified)
    {
        projected_release(&pp,&table);
        if(!projected_init(&pp,&table,&options))return 1;
        okay=pp_run(&pp,input);
    }
    clocks[3]=pp_benchmark_nanoseconds();
    if(getenv("PP_DEBUG"))fprintf(stderr,"headers inspected %u projected %u entries %u misses %u bytes %lu excluded %lu gaps %lu confirmed %u directives %lu\\n",trial_state.inspected,trial_state.projected,trial_state.entries,trial_state.misses,trial_state.bytes,trial_state.excluded,trial_state.gaps,trial_state.confirmed,trial_state.physical_directives);
'''+s[b:];a=s.index('    printf(');b=s.index('    if(getenv("PP_PRINT"))',a);s=s[:a]+'    printf("%lu %u %u %u %u %lu %lu\\n",clocks[3]-begin,pp.output.count,verified,trial_state.projected,trial_state.entries,trial_state.excluded,trial_state.gaps);\n'+s[b:];a=s.index('    if(raw!=MAP_FAILED)');s=s[:a]+'    return 0;\n}\n';(d/'header-front.c').write_text(s)
s=(d/'conditional-batches-local.sh').read_text().replace('pp-conditional-batches/src','pp-header-front/src').replace('conditional-batches','header-front').replace('conditional-batch-local','header-front-local').replace('PP_DEBUG=1','HEADER_MISSES=1 PP_DEBUG=1');(d/'header-front-local.sh').write_text(s)
