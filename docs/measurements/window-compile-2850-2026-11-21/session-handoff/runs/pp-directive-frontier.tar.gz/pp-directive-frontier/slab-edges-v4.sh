#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;cc=$root/trees/pp-source-slabs-v4/build/compiler;out=$root/results/pp-slab-edges-v4;mkdir -p "$out";paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage);python3 pp-frontier/slab-edges.py "$out"
for ((n=0;n<800;n++));do [[ -x $cc ]] && break;sleep 2;done;test -x "$cc"
while read -r c;do
 for a in ordinary slabs clang;do f=$out/$c-$a;vars=();flags=(--poison-arenas);tool=$cc
 [[ $a != slabs ]] || vars=(BUSTER_SOURCE_TOKEN_SLABS=1 BUSTER_SLAB_STREAM_ONLY=1)
 if [[ $a == clang ]];then tool=clang;flags=();vars=(PATH="$paths:$PATH");fi
 ./lock.sh taskset -c 2 bash -c 'f=$1;shift;set +e;"$@" >"$f.out" 2>"$f.err";echo $? >"$f.rc"' _ "$f" env "${vars[@]}" "$tool" "${flags[@]}" -std=gnu23 -c "$out/$c.c" -o "$f.o" >"$f.lease" 2>&1
 done
 for x in rc out err;do cmp "$out/$c-ordinary.$x" "$out/$c-slabs.$x";done
 cmp "$out/$c-ordinary.rc" "$out/$c-clang.rc";if [[ $(cat "$out/$c-ordinary.rc") == 0 ]];then cmp "$out/$c-ordinary.o" "$out/$c-slabs.o";fi
 echo "$c $(cat "$out/$c-ordinary.rc")" >>"$out/results"
done <"$out/names"
