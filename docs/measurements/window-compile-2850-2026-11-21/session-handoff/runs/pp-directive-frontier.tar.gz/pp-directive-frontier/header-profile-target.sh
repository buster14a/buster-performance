#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;o=$root/results/pp-fresh-header-frontier;mkdir -p "$o";paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage);src=$root/trees/factsmain0e1d/src
./lock.sh taskset -c 2 env PATH="$paths:$PATH" clang -O3 -march=native -std=gnu17 -funsigned-char -fwrapv -I"$src" -I"$src/buster/compiler" pp-frontier/header-profile.c pp-frontier/overlay.c -Wl,--wrap=open -o "$o/probe" >"$o/build" 2>&1
source corpora.sh;eval "args=($sqlite_arguments)";input=${args[-1]}
for a in original macro-all macro-header-complete;do v=();[[ $a == original ]] || v=(PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$root/pp-frontier/$a.c")
 ./lock.sh taskset -c 2 env "${v[@]}" HEADER_TIMING=1 HEADER_FILES="$o/$a-files.tsv" PP_PRINT="$o/$a.i" "$o/probe" "${args[@]}" >"$o/$a-counts" 2>"$o/$a.lease"
 cmp "$o/$a.i" "$root/results/active-source-profile/ordinary.i"
done
for r in 0 1 2;do arms=(original macro-all macro-header-complete macro-header-complete macro-all original);[[ $r != 1 ]] || arms=(macro-header-complete original macro-all macro-all original macro-header-complete)
 for i in {0..5};do a=${arms[i]};v=();[[ $a == original ]] || v=(PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$root/pp-frontier/$a.c")
 ./lock.sh taskset -c 2 env "${v[@]}" HEADER_TIMING=1 "$o/probe" "${args[@]}" >"$o/$r-$i-$a.time" 2>"$o/$r-$i-$a.lease"
 done
done
(cd "$o" && sha256sum *.i >hashes)
