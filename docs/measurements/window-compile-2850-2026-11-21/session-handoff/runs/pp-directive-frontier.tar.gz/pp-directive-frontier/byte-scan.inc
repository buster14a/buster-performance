static bool pp_byte_line(const Preprocessor* pp,const uint8_t* source,uint32_t a,uint32_t b,uint32_t* first)
{
    uint32_t p=a;*first=b;
    while(p<b)
    {
        const uint8_t c=source[p];const bool alpha=(uint8_t)((c|32)-'a')<26 || c=='_';
        if(c==' ' || c=='\t' || c=='\r' || c=='\n'){p++;continue;}
        if(*first==b){*first=p;if(c=='(')return false;}
        if(alpha)
        {
            const uint32_t start=p++;
            while(p<b)
            {
                const uint8_t k=source[p];
                if(!((uint8_t)((k|32)-'a')<26 || (uint8_t)(k-'0')<10 || k=='_'))break;
                p++;
            }
            const IdentId id=intern_find(pp->table,source+start,p-start);
            if(id && ((pp->is_macro[id/64]>>(id%64))&1))return false;
        }
        else
        {
            if(!((uint8_t)(c-'0')<10 || strchr("+-.*:<>=!&|,;{}()[]^~",c)))return false;
            p++;
        }
    }
    return *first<b;
}

static uint8_t* pp_byte_mask(Preprocessor* pp,PPProjection* plan,uint32_t begin,uint32_t end)
{
    if(!plan->groups || begin==end)return NULL;
    const uint8_t* source=plan->primary->bytes;uint8_t* bytes=NULL;
    uint32_t first_group=plan->group_count,at=begin,comment=plan->comment_cursor;
    while(comment<plan->index.comments && plan->index.comment_spans[comment].end<=begin)comment++;
    bool continued=false;
    while(at<end)
    {
        const uint8_t* nl=memchr(source+at,'\n',end-at);const uint32_t next=nl?(uint32_t)(nl-source)+1:end;
        while(comment<plan->index.comments && plan->index.comment_spans[comment].end<=at)comment++;
        const bool protected=comment<plan->index.comments && plan->index.comment_spans[comment].hash<next;
        uint32_t first=next,p=next;
        while(p>at && (source[p-1]=='\n'||source[p-1]=='\r'||source[p-1]==' '||source[p-1]=='\t'))p--;
        const bool splice=p>at && source[p-1]=='\\';
        const bool eligible=!continued && !protected && nl && !splice && next-at>=8 && pp_byte_line(pp,source,at,next,&first);
        if(eligible)
        {
            if(plan->group_count>first_group && plan->groups[plan->group_count-1].end==at)
                plan->groups[plan->group_count-1].end=next;
            else if(plan->group_count<plan->group_capacity)
                plan->groups[plan->group_count++]=(PPByteGroup){.begin=at,.end=next,.marker=first,.output=BUSTER_PP_NONE};
        }
        continued=splice;at=next;
    }
    plan->comment_cursor=comment;
    if(first_group==plan->group_count)return NULL;
    bytes=calloc((size_t)(end-begin)+64,1);
    if(!bytes){plan->group_count=first_group;return NULL;}
    memcpy(bytes,source+begin,end-begin);
    for(uint32_t g=first_group;g<plan->group_count;g++)
    {
        const PPByteGroup r=plan->groups[g];memset(bytes+r.begin-begin,' ',r.end-r.begin);
        bytes[r.marker-begin]='0';bytes[r.end-1-begin]='\n';
    }
    return bytes;
}

static void pp_byte_observe(const PPFileData* data,uint32_t base,uint32_t source,uint32_t count,uint32_t output)
{
    PPProjection* plan=pp_projection;
    if(!plan || !plan->groups || !plan->gap_context || !count)return;
    const uint32_t idx=plan->gap_context->data;
    if(plan->group_observed==plan->group_count || plan->groups[plan->group_observed].data!=idx)return;
    if(data->bytes!=plan->primary->bytes)return;
    while(plan->group_observed<plan->group_count)
    {
        PPByteGroup* r=plan->groups+plan->group_observed;
        if(r->data!=idx || r->row>=source+count)break;
        if(r->row<source || data->starts[r->row]!=r->marker){plan->failed=true;return;}
        r->output=output+(r->row-source);
        plan->group_observed++;
    }
}
