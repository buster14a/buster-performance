#include "buster/compiler/c_pp_structure.c"

typedef struct PPHeaderTrial {
    const char* main_path;
    uint32_t inspected, projected, entries, confirmed, misses, modeled;
    uint64_t bytes, excluded, gaps, physical_directives;
    bool failed, loose;
} PPHeaderTrial;
static _Thread_local PPHeaderTrial* pp_header;
typedef struct PPHeaderPiece {uint32_t from,to,length;} PPHeaderPiece;
typedef struct HeaderBranch {bool had_else,possible,remaining,parent;} HeaderBranch;

static bool header_space(uint8_t c) {return c==' ' || c=='\t' || c=='\r' || c=='\v' || c=='\f' || c=='\n';}
static bool header_ident(uint8_t c) {return (c>='a'&&c<='z') || (c>='A'&&c<='Z') || (c>='0'&&c<='9') || c=='_';}
static bool header_word(const uint8_t* s,uint32_t lo,uint32_t hi,const char* name)
{
    return hi-lo==strlen(name) && !memcmp(s+lo,name,hi-lo);
}
static void header_trim(const uint8_t* s,uint32_t* lo,uint32_t* hi)
{
    while(*lo<*hi && header_space(s[*lo]))(*lo)++;
    while(*hi>*lo && header_space(s[*hi-1]))(*hi)--;
}
static int header_predicate(const Preprocessor* pp,const uint8_t* s,uint32_t lo,uint32_t hi,int kind,bool unstable,const uint8_t* touched)
{
    header_trim(s,&lo,&hi);
    if(!kind && hi-lo==1 && (s[lo]=='0' || s[lo]=='1'))return s[lo]-'0';
    bool negative=kind==2;
    if(!kind)
    {
        if(lo<hi && s[lo]=='!'){negative=true;lo++;header_trim(s,&lo,&hi);}
        if(hi-lo<7 || memcmp(s+lo,"defined",7))return -1;
        lo+=7;header_trim(s,&lo,&hi);
        if(lo<hi && s[lo]=='(' && s[hi-1]==')'){lo++;hi--;header_trim(s,&lo,&hi);}
    }
    if(unstable || lo==hi || (s[lo]>='0' && s[lo]<='9'))return -1;
    for(uint32_t i=lo;i<hi;i++)if(!header_ident(s[i]))return -1;
    const uint16_t h=(uint16_t)intern_hash_bytes(s+lo,hi-lo);
    if(touched[h/8]&(1u<<(h%8)))return -1;
    IdentId id=intern_find(pp->table,s+lo,hi-lo);
    bool present=false;
    if(id && (pp->is_macro[id/64]>>(id%64)&1))
    {
        const uint8_t builtin=pp->macros[pp->macro_of[id]].builtin;
        present=builtin!=PP_BUILTIN_POISONED && builtin!=PP_BUILTIN_DEFINED;
    }
    return present!=negative;
}

static void header_piece(const uint8_t* original,uint8_t* bytes,PPHeaderPiece* pieces,uint32_t* count,uint32_t* pos,uint32_t begin,uint32_t end)
{
    if(begin==end)return;
    if(*count && pieces[*count-1].from+pieces[*count-1].length==begin && pieces[*count-1].to+pieces[*count-1].length==*pos)
        pieces[*count-1].length+=end-begin;
    else pieces[(*count)++]=(PPHeaderPiece){begin,*pos,end-begin};
    memcpy(bytes+*pos,original+begin,end-begin);*pos+=end-begin;
}

// A decision here forecasts which ordinary byte ranges the real preprocessor
// will skip. Its own forward jumps must certify each omission on each inclusion.
static bool header_project(Preprocessor* pp,PPFileData* data,const char* path)
{
    PPHeaderTrial* trial=pp_header;
    if(!trial || !strcmp(path,trial->main_path) || data->length<2048 || data->length>(4u<<20))return false;
    trial->inspected++;
    const uint32_t n=data->length,cap=n/2+3;
    const uint8_t* s=data->bytes;
    PPSourceStructure index={.capacity=cap,.trigraphs=pp->options.trigraphs,
        .digit_separators=!(c_language_lexer_flags(pp->options.language)&C_TOKENIZER_NO_DIGIT_SEPARATORS)};
    index.directives=malloc(cap*sizeof(*index.directives));
    if(!index.directives)return false;
    bool ok=pp_structure_scan(s,n,&index);
    const uint32_t count=index.count;
    uint8_t* bytes=ok?malloc((size_t)n+count+128):0;
    PPHeaderPiece* pieces=ok?malloc((2*(size_t)count+2)*sizeof(*pieces)):0;
    uint32_t* prefix=ok?calloc(count+2,sizeof(uint32_t)):0;
    HeaderBranch* stack=ok?calloc(count+1,sizeof(*stack)):0;
    uint8_t touched[8192]={0};
    uint32_t depth=0,last=0,used=0,piece_count=0,omitted=0,excluded=0;
    bool live=true,unstable=false;
    if(!bytes || !pieces || !prefix || !stack)ok=false;
    for(uint32_t d=0;ok && d<=count;d++)
    {
        const uint32_t a=d<count?index.directives[d].hash:n,b=d<count?index.directives[d].end:n;
        if(live || a-last<16)header_piece(s,bytes,pieces,&piece_count,&used,last,a);
        else {bytes[used++]='\n';excluded+=a-last;omitted++;}
        prefix[d+1]=omitted;
        if(d==count)break;
        header_piece(s,bytes,pieces,&piece_count,&used,a,b);
        uint32_t word=a+1,end=b;header_trim(s,&word,&end);uint32_t p=word;while(p<end && header_ident(s[p]))p++;
#define HEADER_IS(name) header_word(s,word,p,name)
        const bool ifdef=HEADER_IS("ifdef"),ifndef=HEADER_IS("ifndef"),elifdef=HEADER_IS("elifdef"),elifndef=HEADER_IS("elifndef");
        if(ifdef || ifndef || HEADER_IS("if"))
        {
            const int pred=header_predicate(pp,s,p,end,ifdef?1:ifndef?2:0,unstable,touched);
            stack[depth++]=(HeaderBranch){.parent=live,.possible=live && pred!=0,.remaining=live && pred!=1};
            live=stack[depth-1].possible;
        }
        else if(elifdef || elifndef || HEADER_IS("elif") || HEADER_IS("else"))
        {
            if(!depth || stack[depth-1].had_else){ok=false;break;}
            HeaderBranch* h=stack+depth-1;
            const bool last_branch=HEADER_IS("else");
            int pred=last_branch?1:header_predicate(pp,s,p,end,elifdef?1:elifndef?2:0,unstable,touched);
            h->possible=h->remaining && pred!=0;
            h->remaining=h->remaining && pred!=1;
            h->had_else=last_branch;live=h->possible;
        }
        else if(HEADER_IS("endif"))
        {
            if(!depth){ok=false;break;}
            live=stack[--depth].parent;
        }
        else if(live && (HEADER_IS("define") || HEADER_IS("undef")))
        {
            uint32_t name=p;header_trim(s,&name,&end);uint32_t e=name;while(e<end && header_ident(s[e]))e++;
            if(e>name){const uint16_t h=(uint16_t)intern_hash_bytes(s+name,e-name);touched[h/8]|=1u<<(h%8);}
        }
        else if(live && (HEADER_IS("include") || HEADER_IS("include_next") || HEADER_IS("import") || HEADER_IS("pragma"))) unstable|=!trial->loose;
        last=b;
#undef HEADER_IS
    }
    ok=ok && !depth && excluded>=512;
    if(ok)
    {
        PPFileData part=*data;part.bytes=bytes;part.length=used;
        const PPPrepare conf=pp_prepare_config(pp);
        ok=pp_prepare_into(&conf,pp->table,pp->columns,&pp->arena,&part,NULL)==PP_PREPARE_DONE &&
            !part.raw_error_count && !part.unterminated_comment && part.directive_count==count;
        uint32_t row=0;
        for(uint32_t i=0;ok && i<piece_count;i++)
        {
            const PPHeaderPiece r=pieces[i];const uint32_t lim=r.to+r.length;
            const __m512i delta=_mm512_set1_epi32((int32_t)(r.from-r.to));
            while(row<part.token_count && part.starts[row]<lim)
            {
                const uint32_t nrows=part.token_count-row;
                const __mmask16 valid=nrows>=16?0xffff:(__mmask16)_bzhi_u32(0xffff,nrows);
                const __m512i starts=_mm512_maskz_loadu_epi32(valid,part.starts+row);
                const __mmask16 mask=_mm512_mask_cmplt_epu32_mask(valid,starts,_mm512_set1_epi32((int32_t)lim));
                const __m128i kinds=_mm_maskz_loadu_epi8(mask,part.kinds+row);
                const __mmask16 ends=_mm_mask_cmpneq_epi8_mask(mask,_mm_and_si128(kinds,_mm_set1_epi8(127)),_mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
                _mm512_mask_storeu_epi32(part.starts+row,mask,_mm512_add_epi32(starts,delta));
                _mm512_mask_storeu_epi32(part.values+row,ends,_mm512_add_epi32(_mm512_maskz_loadu_epi32(ends,part.values+row),delta));
                row+=(uint32_t)__builtin_popcount(mask);
            }
        }
        for(uint32_t d=0;ok && d<count;d++)ok=part.starts[part.directive_hash[d]]==index.directives[d].hash;
        if(ok)
        {
            uint32_t* checked=arena_push_array(&pp->arena,count+2,sizeof(uint32_t),4);
            if(checked)
            {
                memcpy(checked,prefix,(count+2)*sizeof(uint32_t));
                part.header_excluded=checked;part.bytes=s;part.length=n;part.line_pages=NULL;
                *data=part;trial->projected++;trial->bytes+=n;trial->excluded+=excluded;trial->gaps+=omitted;trial->physical_directives+=count;
            }else ok=false;
        }
    }
    free(bytes);free(prefix);free(pieces);free(stack);free(index.directives);
    return ok;
}
