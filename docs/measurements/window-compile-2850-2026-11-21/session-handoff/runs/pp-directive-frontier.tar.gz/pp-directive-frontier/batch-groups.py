from pathlib import Path
from bisect import bisect_left
from array import array
from collections import Counter
import csv
d=Path(__file__).resolve().parent;ss=d.parent/'pp-structural-study';s=(d.parent/'switch-inputs/sqlite/sqlite3.c').read_bytes();v=array('I');v.frombytes((ss/'raw.ledger').read_bytes());ks=v[::3];ps=v[1::3];es=v[2::3];skip=bytearray(len(ks))
for row in (d.parent/'inactive-source-study/sqlite.stderr').read_text().splitlines():
 f=row.split('\t')
 if f[0]=='pp-group-skip' and int(f[1])==len(s):
  b,e=map(int,f[3:5]);skip[b:e]=b'\1'*(e-b)
dirs=[(bisect_left(ps,x),bisect_left(ps,y)) for x,y in (map(int,l.split()) for l in (d/'dirs.tsv').read_text().splitlines())]
mac={r[0].encode() for r in csv.reader((ss/'macro-defs.tsv').open(),delimiter='\t')}
simple={b'ifdef',b'ifndef',b'else',b'endif',b'elifdef',b'elifndef'}
for mode in ('simple','all-conditions','all-conditions-safe-end','without-macros','no-conditional-glue'):
 spans=[];pending=0;ngaps=0;glued=0;grouped=0;last=0;muts=Counter()
 for b,e in dirs+[(len(ps),len(ps))]:
  inds=[i for i in range(last,b) if not skip[i]];n=len(inds);ngaps+=bool(n);pending+=n
  last=e;endkind=s[ps[inds[-1]]:es[inds[-1]]] if inds else b''
  name=s[ps[b+1]:es[b+1]] if b+1<len(ps) else b''
  if b<len(ps) and skip[b]:continue
  live_name=name in simple or (mode!='simple' and name in (b'if',b'elif'))
  if mode=='all-conditions-safe-end':live_name=live_name and (not n or endkind in (b';',b'{',b'}'))
  if mode=='without-macros':live_name=live_name and not any(ks[i]&127==1 and s[ps[i]:es[i]] in mac for i in inds)
  if mode=='no-conditional-glue':live_name=False
  if live_name:
   glued+=bool(n);grouped+=n;continue
  if pending:spans.append(pending);muts[name]+=1;pending=0
 print(mode,'nonempty-active-gaps',ngaps,'raw-rows',sum(spans),'batch preps',len(spans),'deferred gaps',glued,'newly retained raw',grouped,'largest',max(spans),'boundaries',muts.most_common(7))
