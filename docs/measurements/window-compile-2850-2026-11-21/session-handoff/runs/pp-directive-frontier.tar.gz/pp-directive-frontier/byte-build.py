from pathlib import Path
d=Path(__file__).resolve().parent;src=d.parent/'pp-byte-slabs/src/buster/compiler'
p=src/'c_pp_structure.c';s=p.read_text().replace('    PPSourceDirective* directives;','    PPSourceDirective* directives;\n    PPSourceDirective* comment_spans;')
s=s.replace('result->comments++;result->comment_bytes+=pos+2-comment;', 'if(result->comment_spans)result->comment_spans[result->comments]=(PPSourceDirective){comment,pos+2};result->comments++;result->comment_bytes+=pos+2-comment;')
s=s.replace('result->comments++;result->comment_bytes+=pos-comment;', 'if(result->comment_spans)result->comment_spans[result->comments]=(PPSourceDirective){comment,pos};result->comments++;result->comment_bytes+=pos-comment;')
s=s.replace('result->comments++;result->comment_bytes+=length-comment;', 'if(result->comment_spans)result->comment_spans[result->comments]=(PPSourceDirective){comment,length};result->comments++;result->comment_bytes+=length-comment;');p.write_text(s)
p=src/'c_pp_structural_prepare.c';s=p.read_text().replace('typedef struct PPProjection\n', (d/'byte-predict.inc').read_text()+'\ntypedef struct PPProjection\n').replace('    PPSourceStructure index;','''    PPSourceStructure index;
    PPByteGroup* groups;
    uint32_t group_count,group_capacity,group_observed,comment_cursor,byte_rows,byte_bytes;''')
i=s.index('static bool pp_projection_gap(');s=s[:i]+(d/'byte-scan.inc').read_text()+'\n'+s[i:]
needle='''    if (pp_prepare_into(&config,pp->table,pp->columns,&pp->arena,&part,NULL)!=PP_PREPARE_DONE || part.directive_count || part.raw_error_count || part.unterminated_comment) return false;'''
assert needle in s
s=s.replace(needle,'''    const uint32_t first_group=plan->group_count;
    uint8_t* masked=pp_byte_mask(pp,plan,begin,end);
    if(masked)part.bytes=masked;
    const bool prepared=pp_prepare_into(&config,pp->table,pp->columns,&pp->arena,&part,NULL)==PP_PREPARE_DONE;
    free(masked);
    if (!prepared || part.directive_count || part.raw_error_count || part.unterminated_comment) return false;
    uint32_t cursor=0;
    for(uint32_t j=first_group;j<plan->group_count;j++)
    {
        PPByteGroup* r=plan->groups+j;
        while(cursor<part.token_count && part.starts[cursor]<r->marker-begin)cursor++;
        if(cursor==part.token_count || part.starts[cursor]!=r->marker-begin || (part.kinds[cursor]&127)!=C_TOKEN_NUMERIC_CONSTANT)return false;
        r->data=pp->data_count;r->row=cursor;
    }''')
p.write_text(s)
p=src/'c_preprocessor_impl.c';s=p.read_text();needle='''            pp_store_file_tokens(out, out->count, data, base, p, available, take, kinds, false);''';assert s.count(needle)==1;s=s.replace(needle,needle+'''
#ifdef BUSTER_PP_STRUCTURAL_EXPERIMENT
            pp_byte_observe(data,base,p,take,out->count);
#endif''');p.write_text(s)
p=d/'byte-probe.c';s=(d.parent/'pp-structural-study/single-gap.c').read_text();i=s.index('static bool projected_init');s=s[:i]+(d/'byte-rebuild.inc').read_text()+'\n'+s[i:]
s=s.replace('plan.index.trigraphs=options.trigraphs;','''if(getenv("BUSTER_SOURCE_BYTE_SLABS"))
        {
            plan.group_capacity=length/8+8;
            plan.groups=calloc(plan.group_capacity,sizeof(*plan.groups));
            plan.index.comment_spans=calloc((size_t)length/2+1,sizeof(*plan.index.comment_spans));
            if(!plan.groups || !plan.index.comment_spans)return 3;
        }
        plan.index.trigraphs=options.trigraphs;''')
s=s.replace('bool okay=pp_run(&pp,input);','''bool okay=pp_run(&pp,input);
    const uint64_t segmented=pp_benchmark_nanoseconds()-begin;
    if(possible && okay && plan.groups && !pp_byte_rebuild(&pp,&plan))plan.failed=true;''')
s=s.replace('    if (getenv("PP_DEBUG"))','    if(getenv("PP_BYTE_STATS"))fprintf(stderr,"bytes %u groups %u observed %u rows %u segmented %lu\\n",plan.byte_bytes,plan.group_count,plan.group_observed,plan.byte_rows,(unsigned long)segmented);\n    if (getenv("PP_DEBUG"))')
s=s.replace('free(plan.index.directives);','free(plan.groups);free(plan.index.comment_spans);free(plan.index.directives);');p.write_text(s)
