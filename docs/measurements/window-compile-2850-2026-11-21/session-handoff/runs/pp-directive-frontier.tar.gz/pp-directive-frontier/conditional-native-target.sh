#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;arm=$1;o=$root/results/pp-$arm;tree=$root/trees/pp-$arm;mkdir -p "$o"
if [[ ! -d $tree ]];then git -C src worktree add -q --detach "$tree" 0e1d5b825;git -C "$tree" apply "$root/pp-frontier/$arm.patch";fi
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage);src=$tree/src
./lock.sh taskset -c 2 env PATH="$paths:$PATH" clang -O2 -g -march=native -std=gnu17 -fwrapv -funsigned-char -I"$src" -I"$src/buster/compiler" "pp-frontier/$arm.c" -o "$o/probe" >"$o/build" 2>&1
source corpora.sh;eval "args=($sqlite_arguments)"
for hist in deferred full;do for a in ordinary projected;do vars=();[[ $a != ordinary ]] || vars+=(PP_EAGER=1);[[ $hist != full ]] || vars+=(PP_RECORD_HISTORY=1);f=$o/$hist-$a
 ./lock.sh taskset -c 2 env PP_DEBUG=1 HEADER_MISSES=1 "${vars[@]}" PP_ROWS="$f.rows" PP_PRINT="$f.i" "$o/probe" "${args[@]}" >"$f.tsv" 2>"$f.lease"
 done
 for x in rows i;do cmp "$o/$hist-ordinary.$x" "$o/$hist-projected.$x";done
done
(cd "$o" && sha256sum *.i *.rows >preflight)
test "$(awk '{print $3}' "$o/deferred-projected.tsv")" = 1
for r in 0 1 2;do arms=(ordinary projected projected ordinary);[[ $r != 1 ]] || arms=(projected ordinary ordinary projected)
 for i in {0..3};do a=${arms[i]};vars=();[[ $a != ordinary ]] || vars+=(PP_EAGER=1)
 ./lock.sh taskset -c 2 env "${vars[@]}" "$o/probe" "${args[@]}" >"$o/$r-$i-$a.time" 2>"$o/$r-$i-$a.lease"
 done
done
(cd "$o" && sha256sum *.time >hashes)
