static const uint8_t pp_byte_classes[128] __attribute__((aligned(64)))={
    [' ']=1,['\t']=1,['\n']=1,['\r']=1,
    ['A' ... 'Z']=2,['a' ... 'z']=2,['_']=2,['0' ... '9']=3,
    ['+']=4,['-']=4,['.']=4,['*']=4,[':']=4,['<']=4,['>']=4,['=']=4,['!']=4,['&']=4,['|']=4,
    [',']=4,[';']=4,['{']=4,['}']=4,['(']=4,[')']=4,['[']=4,[']']=4,['^']=4,['~']=4
};

static uint32_t pp_byte_signature(const uint8_t* s,uint32_t n)
{
    return s[0]|((uint32_t)(n>1?s[1]:0)<<8);
}
static void pp_byte_defined(const Preprocessor* pp,IdentId name)
{
    PPProjection* p=pp_projection;
    if(!p || !p->macro_signatures)return;
    const uint8_t* s=intern_bytes(pp->table,name);const uint32_t n=intern_length(pp->table,name);
    if(n)p->macro_signatures[pp_byte_signature(s,n)]|=UINT64_C(1)<<(n%64);
}

static bool pp_byte_line(const Preprocessor* pp,const uint8_t* s,uint32_t a,uint32_t b,uint32_t* first)
{
    const PPProjection* plan=pp_projection;const __m512i lower=_mm512_load_si512(pp_byte_classes),upper=_mm512_load_si512(pp_byte_classes+64);
    uint64_t prior=0;*first=b;
    for(uint32_t p=a;p<b;p+=64)
    {
        const uint32_t n=b-p<64?b-p:64;const uint64_t live=_bzhi_u64(UINT64_MAX,n);
        const __m512i bytes=_mm512_maskz_loadu_epi8(live,s+p);
        const __m512i cls=_mm512_permutex2var_epi8(lower,bytes,upper);
        if(live&(_mm512_movepi8_mask(bytes)|_mm512_cmpeq_epi8_mask(cls,_mm512_setzero_si512())))return false;
        const uint64_t real=live&~_mm512_cmpeq_epi8_mask(cls,_mm512_set1_epi8(1));
        if(*first==b && real){*first=p+(uint32_t)__builtin_ctzll(real);if(s[*first]=='(')return false;}
        const uint64_t letters=live&_mm512_cmpeq_epi8_mask(cls,_mm512_set1_epi8(2));
        const uint64_t word=letters|(live&_mm512_cmpeq_epi8_mask(cls,_mm512_set1_epi8(3)));
        const uint64_t heads=letters&~((word<<1)|prior);prior=word>>63;
        for(uint64_t bits=heads;bits;bits&=bits-1)
        {
            const uint32_t j=(uint32_t)__builtin_ctzll(bits),start=p+j;
            const uint64_t stops=(~word)&(UINT64_MAX<<j);
            uint32_t end=stops?p+(uint32_t)__builtin_ctzll(stops):p+64;
            while(end<b && pp_byte_classes[s[end]&127]>=2 && pp_byte_classes[s[end]&127]<=3 && s[end]<128)end++;
            const uint32_t len=end-start;
            if((plan->macro_signatures[pp_byte_signature(s+start,len)]>>(len%64))&1u)
            {
                const IdentId id=intern_find(pp->table,s+start,len);
                if(id && ((pp->is_macro[id/64]>>(id%64))&1))return false;
            }
        }
    }
    return *first<b;
}
