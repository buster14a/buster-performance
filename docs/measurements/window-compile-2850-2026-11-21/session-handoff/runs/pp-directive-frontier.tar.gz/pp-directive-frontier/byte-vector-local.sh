#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;ss=$d/../pp-structural-study;src=$d/../pp-byte-slabs/src
cc=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$cc" -O2 -g -fno-omit-frame-pointer -march=native -fwrapv -funsigned-char -std=gnu17 -I"$src" -I"$src/buster/compiler" "$d/byte-probe-vector.c" -o "$d/byte-probe-vector"
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";cd "$d"
PP_DEBUG=1 PP_BYTE_STATS=1 BUSTER_SOURCE_BYTE_SLABS=1 PP_PRINT="$d/byte.i" PP_ROWS="$d/byte.rows" "$d/byte-probe-vector" "${args[@]}" >byte-vector.tsv 2>byte-vector.info
cmp "$ss/original.i" "$d/byte.i";python3 "$d/../active-source-study/origin-diff.py" "$d/../active-source-study/local-origins/eager.rows" "$d/byte.rows"
