#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;python3 prune.py
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";input=${args[-1]}
PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$d/macro-live-defs.c" PP_PRINT="$d/macro-live-defs.i" "$d/../pp-structural-study/probe" "${args[@]}" >"$d/macro-live-defs.preflight"
cmp "$d/../pp-structural-study/original.i" "$d/macro-live-defs.i"
