from pathlib import Path
from array import array
import json,re,bisect
d=Path(__file__).resolve().parent
ss=d.parent/'pp-structural-study'
s=(d.parent/'switch-inputs/sqlite/sqlite3.c').read_bytes()
raw=array('I');raw.frombytes((ss/'raw.ledger').read_bytes());kf=raw[::3];starts=raw[1::3];ends=raw[2::3];N=len(kf)
skip=bytearray(N)
for line in (d.parent/'inactive-source-study/sqlite.stderr').read_text().splitlines():
 f=line.split('\t')
 if f[0]=='pp-group-skip' and int(f[1])==len(s):
  b,e=map(int,f[3:5]);skip[b:e]=b'\1'*(e-b)
dirs=d/'dirs.tsv'
if not dirs.exists():
 import subprocess
 subprocess.run([ss/'scan',d.parent/'switch-inputs/sqlite/sqlite3.c',dirs],check=True)
conditional=bytearray(N);all_dir=bytearray(N);counts={}
for line in dirs.read_text().splitlines():
 h,p=map(int,line.split());b=bisect.bisect_left(starts,h);e=bisect.bisect_left(starts,p);assert starts[b]==h
 name=s[starts[b+1]:ends[b+1]] if starts[b+1]<p else b''
 counts[name]=counts.get(name,0)+1
 all_dir[b:e]=b'\1'*(e-b)
 if name in (b'if',b'ifdef',b'ifndef',b'elif',b'elifdef',b'elifndef',b'else',b'endif'): conditional[b:e]=b'\1'*(e-b)
preserved={}
for label,cond,compact in [('no-conditional-entire-live',True,False),('no-conditional-compact',True,True),('compact-reference',False,True)]:
 out=bytearray();previous=0;live=0
 for i,kind in enumerate(kf):
  if skip[i] or (cond and conditional[i]):continue
  start=starts[i];end=ends[i];gap=s[previous:start]
  if not compact and (not i or (not skip[i-1] and (not cond or not conditional[i-1]))): out+=gap
  else:
   lines=gap.count(b'\n')+gap.count(b'\r')-gap.count(b'\r\n')
   if kind&128:out+=b'\n'*lines
   else:
    if kind&256:out+=b' '
    out+=b'\\\n'*lines
  out+=s[start:end];previous=end;live+=1
 out+=b'\n'*s[previous:].count(b'\n');(d/(label+'.c')).write_bytes(out);preserved[label]=[len(out),live]
assert (d/'compact-reference.c').read_bytes()==(ss/'both.c').read_bytes()
(d/'conditions.json').write_text(json.dumps({'raw_primary':N,'directives_by_kind':{n.decode():v for n,v in counts.items()},'all_primary_directive_rows':sum(all_dir),'conditional_rows':sum(conditional),'surviving_controlling_rows':sum(not skip[i] and conditional[i] for i in range(N)),'forms':preserved},indent=2)+'\n')
