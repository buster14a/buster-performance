#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d=$PWD;src=$d/../pp-header-front/src
cc=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$cc" -O2 -g -march=native -std=gnu17 -fwrapv -funsigned-char -I"$src" -I"$src/buster/compiler" header-front.c -o header-front
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";cd "$d";mkdir -p header-front-local
for hist in deferred full;do for a in ordinary projected;do v=();[[ $a != ordinary ]] || v+=(PP_EAGER=1);[[ $hist != full ]] || v+=(PP_RECORD_HISTORY=1);stem=$d/header-front-local/$hist-$a
 env "${v[@]}" HEADER_MISSES=1 PP_DEBUG=1 PP_PRINT="$stem.i" PP_ROWS="$stem.rows" "$d/header-front" "${args[@]}" >"$stem.time" 2>"$stem.log"
done;for x in i rows;do cmp "header-front-local/$hist-ordinary.$x" "header-front-local/$hist-projected.$x";done;done
