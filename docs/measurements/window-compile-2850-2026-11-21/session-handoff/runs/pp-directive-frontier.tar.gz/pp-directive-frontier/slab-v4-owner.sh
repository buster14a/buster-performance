#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;tree=$root/trees/pp-source-slabs-v4
if [[ ! -d $tree ]];then git -C src worktree add -q --detach "$tree" 0e1d5b825;git -C "$tree" apply "$root/pp-frontier/slabs-v4.patch";fi
bash pp-frontier/slabs-full-v4.sh & build=$!
bash pp-frontier/slab-edges-v4.sh & edges=$!
bash pp-frontier/cycles-target-v4.sh & perf=$!
bash pp-frontier/whole-wall-v4.sh slabs & wall=$!
wait "$build";wait "$edges";wait "$perf";wait "$wall"
