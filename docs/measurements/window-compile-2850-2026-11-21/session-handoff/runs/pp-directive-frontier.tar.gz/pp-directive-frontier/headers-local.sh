#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;src=$d/../pp-member-declarations/src;ss=$d/../pp-structural-study
cc=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$cc" -O2 -march=native -std=gnu17 -fwrapv -funsigned-char -I"$src" -I"$src/buster/compiler" "$d/header-slices.c" "$ss/overlay.c" -Wl,--wrap=open -o header-probe
mkdir -p "$d/header-slices";cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";input=${args[-1]}
PP_HEADER_SLICES="$d/header-slices" PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$d/macro-all.c" "$d/header-probe" "${args[@]}" >"$d/header-slices.tsv" 2>"$d/header-slices.info"
"$ss/scan" "$d/macro-all.c" "$d/header-directives.tsv" >"$d/header-scan.txt";python3 "$d/replace-headers.py"
PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$d/macro-supplied-headers.c" PP_PRINT="$d/macro-supplied-headers.i" "$ss/probe" "${args[@]}" >"$d/macro-supplied-headers.preflight"
cmp "$ss/original.i" "$d/macro-supplied-headers.i"
