#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;suffix=$1;shift;arms=("$@");if [[ $suffix == complete && ${arms[0]} == macro-header-complete ]];then suffix=headerspruned;fi;out=$root/results/pp-macro-supply-$suffix;mkdir -p "$out";source corpora.sh;eval "args=($sqlite_arguments)";input=${args[-1]};probe=$root/results/structural-single-ideal/probe
for a in "${arms[@]}";do
 sample=$root/pp-frontier/$a.c
 ./lock.sh taskset -c 2 env PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$sample" PP_PRINT="$out/$a.i" "$probe" "${args[@]}" >"$out/$a.preflight" 2>"$out/$a.lease"
 cmp "$out/$a.i" "$root/results/active-source-profile/ordinary.i"
done
for r in 0 1 2;do n=${#arms[@]}
 for ((i=0;i<2*n;i++));do ((i<n))&&k=$i||k=$((2*n-i-1));a=${arms[(k+r)%n]};sample=$root/pp-frontier/$a.c
 ./lock.sh taskset -c 2 env PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$sample" "$probe" "${args[@]}" >"$out/$r-$i-$a.time" 2>"$out/$r-$i-$a.lease"
 done
done
(cd "$out" && sha256sum *.i >hashes)
