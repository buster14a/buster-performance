#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;design=$1
case $design in
 bytes) cc=$root/trees/pp-byte-ordinary-v1/build/compiler;q=$root/results/pp-byte-ordinary-v1;tag=projected;flags=(BUSTER_SOURCE_BYTE_SLABS=1);;
 slabs) cc=$root/trees/pp-source-slabs-v3/build/compiler;q=$root/results/pp-source-slabs-objects-v3;tag=slabs;flags=(BUSTER_SOURCE_TOKEN_SLABS=1 BUSTER_SLAB_STREAM_ONLY=1);;
esac
for ((i=0;i<500;i++));do [[ -s $q/sqlite-max-$tag.o ]] && break;sleep 2;done
test -s "$q/sqlite-max-$tag.o";cmp "$q/sqlite-max-ordinary.o" "$q/sqlite-max-$tag.o"
source corpora.sh;eval "args=($sqlite_arguments)";d=$root/results/pp-ordinary-wall-$design;mkdir -p "$d"
for r in 0 1 2;do arms=(ordinary "$tag" "$tag" ordinary);[[ $r != 1 ]] || arms=("$tag" ordinary ordinary "$tag")
for i in 0 1 2 3;do a=${arms[i]};v=();[[ $a == ordinary ]] || v=("${flags[@]}");f=$d/$r-$i-$a
 ./lock.sh taskset -c 2 env "${v[@]}" python3 - "$cc" --lanes 1 -c "${args[@]}" -o "$f.o" >"$f.time" 2>"$f.lease" <<'PY'
import subprocess,sys,time
a=time.monotonic_ns();p=subprocess.run(sys.argv[1:]);print(time.monotonic_ns()-a);sys.exit(p.returncode)
PY
cmp "$q/sqlite-default-ordinary.o" "$f.o"
done;done
(cd "$d" && sha256sum *.o >hashes)
