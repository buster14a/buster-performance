#include "buster/compiler/c_preprocessor_benchmark.c"
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];
int main(int argc,char**argv)
{
    Arena arena=arena_reserve(UINT64_C(1)<<30);PPOptions opts;const char* input,*output;bool markers;
    if(!pp_parse_options(argc-1,argv+1,&opts,&arena,&input,&output,&markers))return 1;
    opts.defer_history=1;opts.timing=getenv("HEADER_TIMING")!=NULL;
    static Preprocessor pp;static InternTable table;
    const uint64_t a=pp_benchmark_nanoseconds(),tick_start=__rdtsc();
    if(!intern_initialize(&table) || !pp_initialize(&pp,&opts,&table) || !pp_run(&pp,input))return 2;
    const uint64_t ticks=__rdtsc()-tick_start,ns=pp_benchmark_nanoseconds()-a;
    const PPStatistics s=pp.statistics;const FileCacheCounts c=pp.probes;
    printf("total ns %lu ticks %lu rows %u paths %u data %u ranges %u\n",ns,ticks,pp.output.count,pp.file_count,pp.data_count,pp.range_count);
    printf("file opens %lu fstat %lu mmap %lu pread %lu directories %lu listed-absent %lu component-asks %lu\n",c.opens,c.fstats,c.maps,c.reads,c.listings,c.listed,c.asks);
    printf("macro object %lu buffered %lu calls %lu args %lu expanded-args %lu pasted %lu builtins %lu conditions %lu condition-tokens %lu directives %lu\n",s.direct_expansions,s.buffered_expansions,s.invocations,s.arguments,s.expanded_arguments,s.pastes,s.builtins,s.conditions,s.condition_tokens,s.directives);
    printf("includes searches %lu found %lu open %lu fstat %lu ticks %lu guarded %lu once %lu\n",s.include_searches,s.include_found,s.include_opens,s.include_fstats,s.include_ticks,s.skipped_guards,s.skipped_once);
    for(uint32_t k=0;k<PP_PHASE_COUNT;k++)printf("phase %u ticks %lu estimated-ns %.0f\n",k,pp.ticks[k],(double)pp.ticks[k]*ns/ticks);
    uint32_t* entered=calloc(pp.data_count,sizeof(uint32_t));
    for(uint32_t r=0;r<pp.range_count;r++)if(pp.ranges[r].file<pp.file_count){const uint32_t d=pp.files[pp.ranges[r].file].data;if(d<pp.data_count)entered[d]++;}
    const char* fp=getenv("HEADER_FILES");if(fp)
    {
        FILE* f=fopen(fp,"w");if(!f)return 3;
        fputs("path\tbytes\traw-tokens\tdirectives\tdirective-tokens\tconditional\tdefine\tinclude\tentered\tguard\tonce\tprepared\n",f);
        for(uint32_t i=0;i<pp.file_count;i++)
        {
            const PPFile file=pp.files[i];if(file.data>=pp.data_count)continue;
            const PPFileData data=pp.datas[file.data];uint32_t dt=0,co=0,de=0,inc=0;
            for(uint32_t j=0;j<data.directive_count;j++)
            {
                dt+=data.directive_end[j]-data.directive_hash[j];
                const uint8_t k=data.directive_kind[j];co+=k>=PP_DIRECTIVE_IF && k<=PP_DIRECTIVE_ENDIF;
                de+=k==PP_DIRECTIVE_DEFINE;inc+=k==PP_DIRECTIVE_INCLUDE || k==PP_DIRECTIVE_INCLUDE_NEXT;
            }
            fprintf(f,"%s\t%u\t%u\t%u\t%u\t%u\t%u\t%u\t%u\t%u\t%u\t%u\n",file.path,data.length,data.token_count,data.directive_count,dt,co,de,inc,entered[file.data],data.guard!=0,data.once,data.prepared);
        }fclose(f);
    }
    if(getenv("PP_PRINT")){FILE* f=fopen(getenv("PP_PRINT"),"w");if(!f || !pp_print(&pp,f,false) || fclose(f))return 4;}
    free(entered);pp_release(&pp);intern_release(&table);arena_release(&arena);return 0;
}
