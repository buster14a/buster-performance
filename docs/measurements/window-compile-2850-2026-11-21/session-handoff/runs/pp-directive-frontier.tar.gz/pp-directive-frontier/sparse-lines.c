#define _GNU_SOURCE 1
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "buster/compiler/c_pp_structure.c"
typedef struct LineSpan {uint32_t original,virtual,length;} LineSpan;
typedef struct SourceLines {uint8_t* bytes;LineSpan* spans;uint32_t count,used,kept;} SourceLines;
static bool source_candidate_lines(const uint8_t* s,uint32_t length,SourceLines* v)
{
    if(length>=3 && s[0]==0xef && s[1]==0xbb && s[2]==0xbf)return false;
    uint32_t consumed=0;v->bytes=malloc((size_t)length+64);v->spans=malloc(((size_t)length/2+2)*sizeof(LineSpan));
    if(!v->bytes || !v->spans)return false;
    for(uint32_t base=0;base<length;base+=64)
    {
        const uint32_t n=length-base<64?length-base:64;const uint64_t live=_bzhi_u64(UINT64_MAX,n);
        const __m512i b=_mm512_maskz_loadu_epi8(live,s+base);
#define MASK(c) _mm512_cmpeq_epi8_mask(b,_mm512_set1_epi8(c))
        const uint64_t slash=MASK('/'),star=MASK('*');
        const uint8_t next=base+n<length?s[base+n]:0;
        const uint64_t right_slash=(slash>>1)|((uint64_t)(next=='/')<<63),right_star=(star>>1)|((uint64_t)(next=='*')<<63);
        if(MASK('\r')&live)return false;
        const uint64_t rare=MASK('#')|MASK('"')|MASK('\'')|MASK('\\')|MASK('%')|MASK('?')|(_mm512_cmplt_epu8_mask(b,_mm512_set1_epi8(32))&~(MASK('\n')|MASK('\t')|MASK('\v')|MASK('\f')))|MASK(127);
        uint64_t marks=live&(rare|(slash&(right_slash|right_star))|(star&right_slash));
        while(marks)
        {
            const uint32_t event=base+(uint32_t)__builtin_ctzll(marks);
            if(event>=consumed)
            {
                uint32_t start=event;while(start>consumed && s[start-1]!='\n')start--;
                uint32_t end=event;
                for(;;)
                {
                    const uint8_t* p=memchr(s+end,'\n',length-end);
                    const uint32_t e=p?(uint32_t)(p-s)+1:length;
                    const bool extend=e<length && memchr(s+end,'\\',e-end)!=NULL;
                    end=e;if(!extend)break;
                }
                if(start>consumed)v->bytes[v->used++]='\n';
                if(v->count && start==consumed)v->spans[v->count-1].length+=end-start;
                else v->spans[v->count++]=(LineSpan){start,v->used,end-start};
                memcpy(v->bytes+v->used,s+start,end-start);v->used+=end-start;v->kept+=end-start;consumed=end;
            }
            marks&=~_bzhi_u64(UINT64_MAX,consumed>=base+n?64:consumed-base);
        }
#undef MASK
    }
    if(consumed<length)v->bytes[v->used++]='\n';
    return true;
}
static uint32_t source_line_map(const SourceLines* v,uint32_t p,bool end)
{
    uint32_t lo=0,hi=v->count;
    while(lo<hi){const uint32_t m=lo+(hi-lo)/2;if(v->spans[m].virtual<=p-(end&&p>0))lo=m+1;else hi=m;}
    if(!lo)return UINT32_MAX;const LineSpan r=v->spans[lo-1];
    return p>=r.virtual && p<=r.virtual+r.length?r.original+p-r.virtual:UINT32_MAX;
}
static bool sparse_index(const uint8_t* s,uint32_t n,PPSourceStructure* dest,SourceLines* v)
{
    if(!source_candidate_lines(s,n,v) || !pp_structure_scan(v->bytes,v->used,dest))return false;
    for(uint32_t i=0;i<dest->count;i++)
    {
        PPSourceDirective* d=dest->directives+i;
        d->hash=source_line_map(v,d->hash,false);d->end=source_line_map(v,d->end,true);
        if(d->hash>=n || d->end>n || s[d->hash]!='#')return false;
    }
    return true;
}
static uint64_t stamp(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
int main(int argc,char**argv)
{
    if(argc!=2)return 1;int fd=open(argv[1],O_RDONLY);struct stat st;if(fd<0||fstat(fd,&st)||st.st_size<=0||st.st_size>UINT32_MAX/2)return 1;
    uint8_t* s=mmap(NULL,st.st_size,PROT_READ,MAP_PRIVATE|MAP_POPULATE,fd,0);close(fd);if(s==MAP_FAILED)return 1;
    uint32_t n=(uint32_t)st.st_size;PPSourceStructure r={.capacity=n/2+2};r.directives=calloc(r.capacity,sizeof(*r.directives));
    SourceLines v={0};uint64_t a=stamp();bool sparse=getenv("SPARSE_PHYSICAL_LINES")!=NULL,ok=sparse?sparse_index(s,n,&r,&v):pp_structure_scan(s,n,&r);
    uint64_t b=stamp();
    if(getenv("PRINT_DIRECTIVES"))for(uint32_t j=0;j<r.count;j++)printf("%u %u\n",r.directives[j].hash,r.directives[j].end);
    fprintf(stderr,"%s ok=%d directives=%u source=%u retained=%u spans=%u ns=%lu\n",sparse?"sparse":"original",ok,r.count,n,v.kept,v.count,(unsigned long)(b-a));
    return !ok;
}
