from pathlib import Path
from collections import defaultdict
from bisect import bisect_right
import struct,csv,re
d=Path(__file__).resolve().parent;source=(d/'macro-all.c').read_bytes();directives=[tuple(map(int,l.split())) for l in (d/'header-directives.tsv').read_text().splitlines()];hashes=[a for a,b in directives];replacements=[]
for f in (d/'header-slices').glob('*.inc'):
 p=int(f.stem);a,b=directives[bisect_right(hashes,p)-1];replacements.append((a,b,f.read_bytes()+b'\n'*source[a:b].count(b'\n')))
present={a for a,b,_ in replacements}
for a,b in directives:
 words=re.findall(rb'[A-Za-z_$][A-Za-z_$0-9]*',source[a:b])
 if words and words[0]==b'include' and a not in present:replacements.append((a,b,b'\n'*source[a:b].count(b'\n')))
r=d/'residual-macros';inv={int(key):(int(a),int(b),name.encode()) for key,a,b,name in csv.reader((r/'invocations.tsv').open(),delimiter='\t')}
rows=defaultdict(list);buf=(r/'invocation-tokens.bin').read_bytes();i=0
while i<len(buf):
 key,out,kind,flags,n=struct.unpack_from('<IIIII',buf,i);i+=20;rows[key].append((out,flags,buf[i:i+n]));i+=n
closed=-1;counts=defaultdict(int)
for key,(a,b,name) in sorted(inv.items(),key=lambda it:(it[1][0],-it[1][1])):
 if a<=closed:continue
 closed=b
 if not source.startswith(name,a):continue
 directive=bisect_right(hashes,a)-1
 if directive>=0 and a<directives[directive][1]:continue
 v=rows[key]
 if not v or not all(k==v[0][0]+j and s for j,(k,f,s) in enumerate(v)):continue
 if not any(s==name for _,_,s in v):continue
 e=b+1 if b>a and source[b:b+1]==b')' else a+len(name) if a==b else None
 if e is None:continue
 text=b''.join((b' ' if j and fl&1 else b'')+s for j,(_,fl,s) in enumerate(v))+b'\\\n'*source[a:e].count(b'\n')
 replacements.append((a,e,text));counts[name]+=1
out=bytearray();prev=0
for a,b,s in sorted(replacements):
 assert prev<=a;out+=source[prev:a]+s;prev=b
out+=source[prev:];(d/'macro-header-complete.c').write_bytes(out)
print('self-referential macro results supplied',dict(counts),'file bytes',len(out))
