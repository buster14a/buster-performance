#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;src=$d/../pp-sparse-front/src;ss=$d/../pp-structural-study;o=$d/sparse-compare
cc=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$cc" -O3 -march=native -std=gnu17 -fwrapv -funsigned-char -I"$src" -I"$src/buster/compiler" "$ss/raw-oracle.c" "$ss/overlay.c" -Wl,--wrap=open -o "$o/probe"
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
for a in ordinary sparse;do mkdir -p "$o/$a";cd "$o/$a";vars=();[[ $a != sparse ]] || vars=(BUSTER_SOURCE_MACRO_EVENTS=1)
 env "${vars[@]}" PP_DUMP_FORM=1 PP_PRINT="$o/$a.i" "$o/probe" "${args[@]}" >"$o/$a.tsv" 2>"$o/$a.err"
done
for f in primary.raw output.rows;do cmp "$o/ordinary/$f" "$o/sparse/$f";done;cmp "$o/ordinary.i" "$o/sparse.i";sha256sum "$o"/{ordinary,sparse}.i
