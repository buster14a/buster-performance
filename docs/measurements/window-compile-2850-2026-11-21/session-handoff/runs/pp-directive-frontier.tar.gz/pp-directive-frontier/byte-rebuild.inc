static bool pp_byte_rebuild(Preprocessor* pp,PPProjection* plan)
{
    if(!plan->groups || !plan->group_count)return true;
    if(plan->group_observed!=plan->group_count || plan->main_range>=pp->range_count)return false;
    uint64_t bytes=0;
    for(uint32_t j=0;j<plan->group_count;j++)bytes+=plan->groups[j].end-plan->groups[j].begin+1;
    if(bytes>UINT32_MAX-64)return false;
    uint8_t* batch=calloc((size_t)bytes+64,1);if(!batch)return false;
    const uint8_t* source=plan->primary->bytes;uint32_t pos=0;
    for(uint32_t j=0;j<plan->group_count;j++)
    {
        PPByteGroup* r=plan->groups+j;r->batch=pos;
        memcpy(batch+pos,source+r->begin,r->end-r->begin);pos+=r->end-r->begin;batch[pos++]='\n';
    }
    PPFileData d={.bytes=batch,.length=pos,.record=BUSTER_PP_NONE};
    const PPPrepare config=pp_prepare_config(pp);
    if(pp_prepare_into(&config,pp->table,pp->columns,&pp->arena,&d,NULL)!=PP_PREPARE_DONE || d.directive_count || d.raw_error_count)
    {free(batch);return false;}
    PPTokens* out=&pp->output;uint32_t row=0;const uint32_t base=pp->ranges[plan->main_range].base;
    for(uint32_t j=0;j<plan->group_count;j++)
    {
        PPByteGroup* r=plan->groups+j;r->first=row;
        const uint32_t end=r->batch+r->end-r->begin;
        while(row<d.token_count && d.starts[row]<end)row++;
        r->limit=row;
        if(row==r->first || out->locations[r->output]!=base+r->marker || out->kinds[r->output]!=C_TOKEN_NUMERIC_CONSTANT ||
           (out->flags[r->output]&BUSTER_PP_FROM_MACRO)){free(batch);return false;}
    }
    if(row!=d.token_count || !pp_room(pp,out,row-plan->group_count)){free(batch);return false;}
    uint32_t old=out->count,dst=old+row-plan->group_count;
    plan->byte_rows=row;plan->byte_bytes=pos-plan->group_count;out->count=dst;
    for(uint32_t j=plan->group_count;j>0;j--)
    {
        const PPByteGroup r=plan->groups[j-1];const uint32_t tail=old-r.output-1;
        dst-=tail;
        memmove(out->kinds+dst,out->kinds+r.output+1,tail);memmove(out->flags+dst,out->flags+r.output+1,tail);
        memmove(out->values+dst,out->values+r.output+1,(size_t)tail*4);memmove(out->locations+dst,out->locations+r.output+1,(size_t)tail*4);
        dst-=r.limit-r.first;const uint32_t delta=base+r.begin-r.batch;
        const uint8_t first_flags=out->flags[r.output];
        for(uint32_t i=r.first;i<r.limit;i++)
        {
            const uint32_t w=dst+i-r.first;const uint8_t raw=d.kinds[i],k=raw&127;const uint32_t v=d.values[i];const bool name=k==C_TOKEN_RAW_IDENTIFIER;
            out->kinds[w]=name && v<BUSTER_PP_KEYWORD_TABLE?pp->keyword_kinds[v]:k;
            out->flags[w]=i==r.first?first_flags:(raw&128?BUSTER_PP_START_OF_LINE:0)|(((d.space[i/64]>>(i%64))&1)?BUSTER_PP_SPACE:0);
            out->locations[w]=d.starts[i]+delta;out->values[w]=name?v:v+delta;
        }
        old=r.output;
    }
    pp->keywords_resolved=out->count;free(batch);return old==dst;
}
