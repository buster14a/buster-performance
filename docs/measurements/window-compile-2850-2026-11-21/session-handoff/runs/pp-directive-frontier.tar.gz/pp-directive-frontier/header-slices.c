#include "buster/compiler/c_preprocessor_benchmark.c"
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];
static uint32_t top_header(Preprocessor* pp,uint32_t row,uint32_t main)
{
    const uint32_t origin=pp_history_at(pp,row);
    const uint32_t loc=pp_output_expansion_begin(pp,row,origin);
    uint32_t range=pp_find_range(pp,loc);
    for(uint32_t n=0;range<pp->range_count && range!=main && n<256;n++)
    {
        const PPRange* r=pp->ranges+range;
        if(r->parent==main)return r->include_location-pp->ranges[main].base;
        range=r->parent;
    }
    return BUSTER_PP_NONE;
}
int main(int argc,char** argv)
{
    Arena arena=arena_reserve(UINT64_C(1)<<30);PPOptions options;const char* in,*out;bool markers;
    if(!pp_parse_options(argc-1,argv+1,&options,&arena,&in,&out,&markers))return 1;
    options.defer_history=false;
    static Preprocessor pp;static InternTable table;
    if(!intern_initialize(&table) || !pp_initialize(&pp,&options,&table) || !pp_run(&pp,in))return 2;
    uint32_t main=BUSTER_PP_NONE;for(uint32_t i=0;i<pp.range_count;i++)if(pp.ranges[i].file==pp.main_file)main=i;
    if(main==BUSTER_PP_NONE)return 3;
    const PPTokens original=pp.output;uint32_t first=0;const char* dir=getenv("PP_HEADER_SLICES");if(!dir)return 4;
    uint32_t total=0,part=0;
    while(first<original.count)
    {
        const uint32_t anchor=top_header(&pp,first,main);uint32_t end=first+1;
        while(end<original.count && top_header(&pp,end,main)==anchor)end++;
        if(anchor!=BUSTER_PP_NONE)
        {
            char path[4096];snprintf(path,sizeof(path),"%s/%u.inc",dir,anchor);FILE* f=fopen(path,"a");if(!f)return 5;
            pp.output=original;pp.output.count=end-first;pp.output.kinds+=first;pp.output.flags+=first;pp.output.values+=first;pp.output.locations+=first;
            if(!pp_print(&pp,f,false) || fclose(f))return 6;
            pp.output=original;printf("%u\t%u\t%u\n",anchor,first,end);total+=end-first;part++;
        }
        first=end;
    }
    fprintf(stderr,"headers %u output tokens %u spans %u\n",pp.file_count,total,part);
    return 0;
}
