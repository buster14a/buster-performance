struct Payload { int n; };
#define SET(x) ((x)+4)
