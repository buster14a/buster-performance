#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";arm=$1;tree=$2;local_k=$3
until [[ -s $local_k/full-projected.rows && -s $local_k/full-projected.i ]] && [[ $(stat -c %s "$local_k/full-projected.rows") == $(stat -c %s "$local_k/full-ordinary.rows") ]];do sleep 2;done
cmp "$local_k/full-projected.rows" "$local_k/full-ordinary.rows";cmp "$local_k/full-projected.i" "$local_k/full-ordinary.i"
git -C "$tree" diff 0e1d5b825 >"$arm.patch"
scp "$arm.patch" "$arm.c" conditional-native-target.sh david@benchpress:~/buster-fast-bench/2850-codex-step2/pp-frontier/
ssh david@benchpress "cd ~/buster-fast-bench/2850-codex-step2 && bash pp-frontier/conditional-native-target.sh $arm"
