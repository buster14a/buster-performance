#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;v=$1;o=$root/results/pp-byte-ordinary-$v;tree=$root/trees/pp-byte-ordinary-$v;mkdir -p "$o"
if [[ ! -d $tree ]];then git -C src worktree add -q --detach "$tree" 0e1d5b825;git -C "$tree" apply "$root/pp-frontier/byte-compiler-$v.patch";fi
./lock.sh bash -c 'cd "$1" && ./build.sh --config Release' _ "$tree" >"$o/build" 2>&1
source corpora.sh;main_arguments="-march=native -I$root/pooled-main-source/src -fwrapv -funsigned-char --predefines $root/proof-predefines.h $root/pooled-main-source/src/buster/compiler/main.c"
for c in sqlite main;do n=${c}_arguments;eval "args=(${!n})"
 for warn in default max;do [[ $c != main || $warn == default ]] || continue
  w=();[[ $warn == default ]] || w=(-Weverything)
  for a in ordinary projected;do vars=();[[ $a == ordinary ]] || vars=(BUSTER_SOURCE_BYTE_SLABS=1 BUSTER_SOURCE_BYTE_REPORT=1);stem=$o/$c-$warn-$a
   ./lock.sh taskset -c 2 bash -c 'f=$1;shift;set +e;"$@" >"$f.out" 2>"$f.err"; echo $? >"$f.rc"' _ "$stem" env "${vars[@]}" "$tree/build/compiler" --lanes 1 -c "${w[@]}" "${args[@]}" -o "$stem.o" >"$stem.lease" 2>&1
   sed '/^physical-byte-source /d' "$stem.err" >"$stem.diag"
  done
  for x in rc out diag o;do cmp "$o/$c-$warn-ordinary.$x" "$o/$c-$warn-projected.$x";done
 done
done
test "$(cat "$o/sqlite-default-projected.rc")" = 0;grep -q 'confirmed=1' "$o/sqlite-default-projected.err"
source corpora.sh;eval "args=($sqlite_arguments)"
for round in 1 2 3;do arms=(ordinary projected projected ordinary);[[ $round != 2 ]] || arms=(projected ordinary ordinary projected)
 for i in 0 1 2 3;do a=${arms[i]};v=();[[ $a == ordinary ]] || v=(BUSTER_SOURCE_BYTE_SLABS=1);stem=$o/$round-$i-$a
 ./lock.sh taskset -c 2 perf stat --no-big-num -x, -o "$stem.perf" -e cycles:u,instructions:u,minor-faults,duration_time -- env "${v[@]}" "$tree/build/compiler" --lanes 1 -c "${args[@]}" -o "$stem.o" >"$stem.out" 2>"$stem.lease"
 cmp "$stem.o" "$o/sqlite-default-ordinary.o"
 done
done
(cd "$o" && sha256sum *.o *.diag >hashes)
