from pathlib import Path
d=Path(__file__).resolve().parent;src=d.parent/'pp-sparse-front/src/buster/compiler'
p=src/'c_preprocessor.c';s=p.read_text().replace('    PPMacroId* macro_of;','''    PPMacroId* macro_of;
    const uint8_t* sparse_source;
    uint32_t sparse_name_count;
    uint32_t* sparse_heads;
    uint32_t* sparse_next;
    uint64_t* sparse_rows;
    uint64_t sparse_candidates, sparse_initial_names, sparse_updates;''');p.write_text(s)
p=src/'c_preprocessor_impl.c';s=p.read_text()
x=s.index('static bool pp_prepare_data(')
s=s[:x]+'''// Source-indexed macro candidates. An actual definition or undef updates only the
// raw source positions with this spelling. Header definitions use the same writer.
static void pp_sparse_set(Preprocessor* pp,IdentId name,bool defined)
{
    if(name>=pp->sparse_name_count)return;
    for(uint32_t row=pp->sparse_heads[name];row;row=pp->sparse_next[row-1])
    {
        const uint32_t i=row-1;const uint64_t bit=UINT64_C(1)<<(i%64);
        uint64_t* word=pp->sparse_rows+i/64;
        *word=defined?*word|bit:*word&~bit;
    }
}

static void pp_sparse_prepare(Preprocessor* pp,const PPFileData* d)
{
    if(pp->sparse_source || d->length<(1u<<20) || !getenv("BUSTER_SOURCE_MACRO_EVENTS"))return;
    const uint32_t n=d->token_count,count=pp->table->count;
    uint32_t* heads=BUSTER_ARENA_PUSH_ARRAY(&pp->arena,uint32_t,count);
    uint32_t* next=BUSTER_ARENA_PUSH_ARRAY(&pp->arena,uint32_t,n+1);
    uint64_t* rows=BUSTER_ARENA_PUSH_ARRAY(&pp->arena,uint64_t,(n+63)/64+2);
    if(!heads || !next || !rows)return;
    memset(heads,0,(size_t)count*sizeof(*heads));memset(rows,0,((n+63)/64+2)*sizeof(*rows));
    for(uint32_t base=0;base<n;base+=64)
    {
        const uint32_t length=n-base<64?n-base:64;
        const uint64_t lanes=_bzhi_u64(UINT64_MAX,length);
        const __m512i kinds=_mm512_and_si512(_mm512_maskz_loadu_epi8(lanes,d->kinds+base),_mm512_set1_epi8(127));
        for(uint64_t bits=_mm512_mask_cmpeq_epi8_mask(lanes,kinds,_mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));bits;bits&=bits-1)
        {
            const uint32_t i=base+(uint32_t)__builtin_ctzll(bits),id=d->values[i];
            next[i]=heads[id];heads[id]=i+1;
        }
    }
    pp->sparse_heads=heads;pp->sparse_next=next;pp->sparse_rows=rows;pp->sparse_name_count=count;pp->sparse_source=d->kinds;
    for(uint32_t id=1;id<count;id++)if((pp->is_macro[id/64]>>(id%64))&1u)pp_sparse_set(pp,id,true);
}
static inline uint64_t pp_sparse_at(const Preprocessor* pp,uint32_t p)
{
    const uint32_t shift=p%64;const uint64_t* row=pp->sparse_rows+p/64;
    return shift?(row[0]>>shift)|(row[1]<<(64-shift)):row[0];
}

'''+s[x:]
s=s.replace('        pp->input_tokens += data->token_count;', '        pp_sparse_prepare(pp,data);\n        pp->input_tokens += data->token_count;',1)
s=s.replace('    pp->macro_of[name] = id;','    pp_sparse_set(pp,name,id!=0);\n    pp->macro_of[name] = id;',1)
i=s.index('static uint32_t pp_copy_file_run_vector(');j=s.index('        uint32_t take = available;',i)
s=s[:i]+s[i:j].replace('const uint64_t identifiers = _mm512_mask_cmpeq_epi8_mask(valid, plain, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));','const uint64_t identifiers = data->kinds==pp->sparse_source ? valid & pp_sparse_at(pp,p) : _mm512_mask_cmpeq_epi8_mask(valid, plain, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));')+s[j:]
i=s.index('static uint32_t pp_copy_file_text_vector(');j=s.index('        uint32_t take = available;',i)
s=s[:i]+s[i:j].replace('const uint64_t identifiers = _mm512_mask_cmpeq_epi8_mask(valid, plain, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));','const uint64_t identifiers = data->kinds==pp->sparse_source ? valid & pp_sparse_at(pp,p) : _mm512_mask_cmpeq_epi8_mask(valid, plain, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));')+s[j:]
p.write_text(s)
