#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;tree=$root/trees/pp-source-slabs-v4;out=$root/results/pp-source-slabs-objects-v4;mkdir -p "$out"
for ((i=0;i<120;i++));do [[ -e $tree/src/buster/compiler/c_parser_impl.c ]] && break;sleep 1;done
./lock.sh bash -c 'cd "$1" && ./build.sh --config Release' _ "$tree" >"$out/build" 2>&1
source corpora.sh;main_arguments="-march=native -I$root/pooled-main-source/src -fwrapv -funsigned-char --predefines $root/proof-predefines.h $root/pooled-main-source/src/buster/compiler/main.c"
for c in sqlite main;do name=${c}_arguments;eval "args=(${!name})"
 for warn in default max;do [[ $c != main || $warn != max ]] || continue
  w=();[[ $warn == default ]] || w=(-Weverything)
  for a in ordinary slabs;do v=();[[ $a == ordinary ]] || v=(BUSTER_SOURCE_TOKEN_SLABS=1 BUSTER_SLAB_STREAM_ONLY=1)
   f=$out/$c-$warn-$a
   ./lock.sh taskset -c 2 bash -c 'f=$1;shift;"$@" >"$f.out" 2>"$f.err"' _ "$f" env "${v[@]}" "$tree/build/compiler" --lanes 1 -c "${w[@]}" "${args[@]}" -o "$f.o" >"$f.lease" 2>&1
  done
  for x in o out err;do cmp "$out/$c-$warn-ordinary.$x" "$out/$c-$warn-slabs.$x";done
 done
done
(cd "$out" && sha256sum *.o *.err >hashes)
