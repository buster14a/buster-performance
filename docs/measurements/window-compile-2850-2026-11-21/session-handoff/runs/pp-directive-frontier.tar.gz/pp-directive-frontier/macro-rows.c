#include "buster/compiler/c_preprocessor_benchmark.c"
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];
int main(int argc,char** argv)
{
    Arena arena=arena_reserve(UINT64_C(1)<<30);const char *path,*unused;bool markers;PPOptions opts;
    static Preprocessor pp;static InternTable names;
    if(!pp_parse_options(argc-1,argv+1,&opts,&arena,&path,&unused,&markers))return 1;
    opts.defer_history=false;
    if(!intern_initialize(&names) || !pp_initialize(&pp,&opts,&names) || !pp_run(&pp,path))return 2;
    uint32_t primary=BUSTER_PP_NONE;uint32_t room=64;
    for(uint32_t i=0;i<pp.range_count;i++)
    {
        if(pp.ranges[i].file==pp.main_file)primary=i;
        if(pp.ranges[i].length>room)room=pp.ranges[i].length;
    }
    if(primary==BUSTER_PP_NONE)return 3;
    const PPRange* main=pp.ranges+primary;uint8_t* scratch=malloc((size_t)room+64);
    uint32_t* roots=calloc((size_t)pp.history_count+1,sizeof(uint32_t));
    FILE* inv=fopen("invocations.tsv","w"),*rows=fopen("invocation-tokens.bin","wb");
    if(!inv || !rows || !scratch || !roots)return 3;
    for(uint32_t i=1;i<=pp.history_count;i++)
    {
        const PPExpansion e=pp.history[i-1];
        uint32_t parent=e.parent;
        while(parent & ~BUSTER_PP_ORIGIN_INDEX) {
            const uint32_t slot=(parent&BUSTER_PP_ORIGIN_INDEX)-1;
            parent=(parent & BUSTER_PP_ORIGIN_ARGUMENT) ? pp.substitutions[slot].expansion : pp.generated[slot].expansion;
        }
        if(parent>=i)return 4;
        roots[i]=parent?roots[parent]:i;
        if(e.parent || e.begin<main->base || e.end<e.begin || e.end-main->base>=main->length)continue;
        fprintf(inv,"%u\t%u\t%u\t%.*s\n",i,e.begin-main->base,e.end-main->base,(int)intern_length(&names,e.name),intern_bytes(&names,e.name));
    }
    uint32_t next=0,origin=0;
    for(uint32_t i=0;i<pp.output.count;i++)
    {
        while(next<pp.history_run_count && pp.history_runs[next].token<=i)origin=pp.history_runs[next++].origin;
        if(!origin)continue;
        uint32_t x=origin;
        while(x & ~BUSTER_PP_ORIGIN_INDEX) {
            const uint32_t slot=(x&BUSTER_PP_ORIGIN_INDEX)-1;
            x=(x & BUSTER_PP_ORIGIN_ARGUMENT) ? pp.substitutions[slot].expansion : pp.generated[slot].expansion;
        }
        if(!x)continue;
        const uint32_t root=roots[x];const PPExpansion e=pp.history[root-1];
        if(e.begin<main->base || e.end<e.begin || e.end-main->base>=main->length)continue;
        const uint8_t kind=pp.output.kinds[i];const uint8_t* text=NULL;
        
        const uint32_t n=(kind==BUSTER_PP_KIND_EMBED || kind==BUSTER_PP_KIND_PRAGMA_END) ? 0 : pp_spelling(&pp,kind,pp.output.values[i],pp.output.locations[i],scratch,&text);
        uint32_t row[]={root,i,kind,pp.output.flags[i],n};
        if(fwrite(row,sizeof(uint32_t),5,rows)!=5 || fwrite(text,1,n,rows)!=n)return 6;
    }
    return fclose(inv) || fclose(rows);
}
