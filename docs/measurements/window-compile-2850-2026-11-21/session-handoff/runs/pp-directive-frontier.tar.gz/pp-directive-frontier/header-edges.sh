#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;arm=$1;out=$d/$arm-semantic-edges;python3 header-edges.py "$out"
cc=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
while read -r test;do
 src=$out/$test.c;flags=();[[ $test != tri ]] || flags+=(-trigraphs)
 for a in ordinary projected;do
 f=$out/$test-$a;opt=();[[ $a != ordinary ]] || opt=(PP_EAGER=1);set +e
 env "${opt[@]}" HEADER_MISSES=1 PP_DEBUG=1 PP_ROWS="$f.rows" PP_PRINT="$f.i" "$d/$arm" "${flags[@]}" "$src" >"$f.tsv" 2>"$f.err"; echo $? >"$f.rc"
 set -e
 sed -E '/^(headers inspected|structural rejection|batch oracle|header skip mismatch)/d' "$f.err" >"$f.diag"
 done
 for x in rc diag;do cmp "$out/$test-ordinary.$x" "$out/$test-projected.$x";done
 if [[ $(cat "$out/$test-ordinary.rc") == 0 ]];then
  for x in i rows;do cmp "$out/$test-ordinary.$x" "$out/$test-projected.$x";done
  for a in original projected;do in=$src;[[ $a != projected ]] || in=$out/$test-projected.i
   "$cc" "${flags[@]}" "$in" -o "$out/$test-$a.elf" >"$out/$test-$a.clang-out" 2>"$out/$test-$a.clang-err"
   set +e;"$out/$test-$a.elf";echo $? >"$out/$test-$a.run";set -e
  done
  cmp "$out/$test-original.run" "$out/$test-projected.run"
 fi
 echo "$test $(cat "$out/$test-ordinary.rc")" >>"$out/results"
done <"$out/names"
