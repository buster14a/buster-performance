from pathlib import Path
from collections import Counter,defaultdict
from array import array
from bisect import bisect_left
import re,struct,csv
d=Path(__file__).resolve().parent;ss=d.parent/'pp-structural-study';s=(d.parent/'switch-inputs/sqlite/sqlite3.c').read_bytes()
v=array('I');v.frombytes((ss/'raw.ledger').read_bytes());ks=v[::3];ps=v[1::3];es=v[2::3];n=len(ks)
skip=bytearray(n);dr=bytearray(n);cond=bytearray(n)
for row in (d.parent/'inactive-source-study/sqlite.stderr').read_text().splitlines():
 f=row.split('\t')
 if f[0]=='pp-group-skip' and int(f[1])==len(s):
  lo,hi=map(int,f[3:5]);skip[lo:hi]=b'\1'*(hi-lo)
for row in (d/'dirs.tsv').read_text().splitlines():
 b,e=map(int,row.split());lo=bisect_left(ps,b);hi=bisect_left(ps,e);dr[lo:hi]=b'\1'*(hi-lo)
 if s[ps[lo+1]:es[lo+1]] in (b'if',b'ifdef',b'ifndef',b'elif',b'elifdef',b'elifndef',b'else',b'endif'):cond[lo:hi]=b'\1'*(hi-lo)
inv={int(i):(int(b),int(e),name) for i,b,e,name in csv.reader((d/'invocations.tsv').open(),delimiter='\t')};by=defaultdict(list);data=(d/'invocation-tokens.bin').read_bytes();i=0
while i<len(data):
 root,pos,kind,flags,length=struct.unpack_from('<IIIII',data,i);i+=20;by[root].append((pos,kind,flags,data[i:i+length]));i+=length
defs={r[0].encode() for r in csv.reader((ss/'macro-defs.tsv').open(),delimiter='\t')};defs.update((b'_Pragma',b'__pragma'))
# Argument prescan may create a root with no parent while a physical enclosing
# invocation is collecting arguments. Never rewrite a nested physical call in
# place: stringify, paste and contextual expansion belong to the outer call.
enclosed=set();outer_end=-1
for key,(start,end,name) in sorted(inv.items(),key=lambda x:(x[1][0],-x[1][1])):
 if start<=outer_end:enclosed.add(key)
 else:outer_end=end
units={};frequency=Counter();measures=defaultdict(Counter)
for key,(start,end,name) in inv.items():
 if key in enclosed:continue
 b=bisect_left(ps,start);e=bisect_left(ps,end)+1
 if not b<n or e>n or ps[b]!=start or ps[e-1]!=end or dr[b] or skip[b] or s[ps[b]:es[b]].decode('ascii','replace')!=name:continue
 if any(dr[b:e]) or any(skip[b:e]):continue
 rows=by[key]
 if rows and (not all(rows[k][0]==rows[0][0]+k for k in range(len(rows))) or any(not r[3] or r[3] in defs for r in rows)):continue
 result=b''.join((b' ' if j and fl&1 else b'')+spell for j,(rid,k,fl,spell) in enumerate(rows))
 if b in units:continue
 units[b]=(e,name,result,rows);frequency[name]+=1;measures[name]['initial']+=e-b;measures[name]['output']+=len(rows)
def gap(out,prev,start,kind):
 z=s[prev:start];lines=z.count(b'\n')+z.count(b'\r')-z.count(b'\r\n')
 if kind&128:out+=b'\n'*lines
 else:
  if kind&256:out+=b' '
  out+=b'\\\n'*lines
for mode in ['single','erasing','all','assert','empty']:
 out=bytearray();previous=0;i=0;calls=raw=outputs=0
 while i<n:
  if skip[i] or cond[i]:i+=1;continue
  if i in units:
   e,name,result,rows=units[i]
   accept={'single':len(rows)==1 and e==i+1,'erasing':name in ('assert','testcase','ALWAYS','NEVER','VVA_ONLY'), 'assert':name=='assert','empty':not rows,'all':True}[mode]
   if accept:
    gap(out,previous,ps[i],ks[i]);out+=result
    for z in range(s[ps[i]:es[e-1]].count(b'\n')):out+=b'\\\n'
    raw+=e-i;previous=es[e-1];i=e;calls+=1;outputs+=len(rows)
    continue
  gap(out,previous,ps[i],ks[i]);out+=s[ps[i]:es[i]];previous=es[i];i+=1
 out+=b'\n'*s[previous:].count(b'\n');(d/('macro-'+mode+'.c')).write_bytes(out);print(mode,'calls',calls,'output',outputs,'raw',raw,'bytes',len(out))
print('top',[(k,v,dict(measures[k])) for k,v in frequency.most_common(18)])
