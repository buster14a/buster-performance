#define BUSTER_PP_HEADER_SOURCE 1
#include "buster/compiler/c_preprocessor_benchmark.c"
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];
static bool projected_init(Preprocessor* pp,InternTable* table,const PPOptions* options)
{
 return intern_initialize(table) && pp_initialize(pp,options,table);
}
static void projected_release(Preprocessor* pp,InternTable* table)
{
 pp_release(pp);intern_release(table);
}
int main(int argc,char** argv)
{
    Arena arena=arena_reserve(1ull<<30);
    const char *input,*output;bool markers;PPOptions options;
    if(!pp_parse_options(argc-1,argv+1,&options,&arena,&input,&output,&markers))return 2;
    options.defer_history=getenv("PP_RECORD_HISTORY")==NULL;
    options.collect_diagnostics=true;
    static Preprocessor pre,pp;
    static InternTable trial,table;
    uint64_t begin=pp_benchmark_nanoseconds(), clocks[5]={begin};
    PPHeaderTrial trial_state={.main_path=input,.loose=getenv("HEADER_LOOSE")!=NULL};
    const bool selected=getenv("PP_EAGER")==NULL && !options.assembly && !options.preprocessed;
    pp_header=selected?&trial_state:NULL;
    if(!projected_init(&pp,&table,&options))return 1;
    bool okay=pp_run(&pp,input);
    const bool verified=selected && okay && !pp.errors && !pp.warnings && !trial_state.failed;
    pp_header=NULL;
    if(selected && !verified)
    {
        projected_release(&pp,&table);
        if(!projected_init(&pp,&table,&options))return 1;
        okay=pp_run(&pp,input);
    }
    clocks[3]=pp_benchmark_nanoseconds();
    if(getenv("PP_DEBUG"))fprintf(stderr,"headers inspected %u projected %u entries %u misses %u bytes %lu excluded %lu gaps %lu confirmed %u directives %lu\n",trial_state.inspected,trial_state.projected,trial_state.entries,trial_state.misses,trial_state.bytes,trial_state.excluded,trial_state.gaps,trial_state.confirmed,trial_state.physical_directives);
    pp_diagnostic_publish(&pp);
    if(!okay)return 1;
    printf("%lu %u %u %u %u %lu %lu\n",clocks[3]-begin,pp.output.count,verified,trial_state.projected,trial_state.entries,trial_state.excluded,trial_state.gaps);
    if(getenv("PP_PRINT"))
    {
        FILE* f=fopen(getenv("PP_PRINT"),"w");
        if(!f || !pp_print(&pp,f,false) || fclose(f)!=0)return 6;
    }
    if(getenv("PP_ROWS"))
    {
        FILE* f=fopen(getenv("PP_ROWS"),"wb");if(!f)return 7;
        for(uint32_t i=0;i<pp.output.count;i++)
        {
            const uint8_t kind=pp.output.kinds[i];const uint32_t val=pp.output.values[i];
            bool named=kind==C_TOKEN_RAW_IDENTIFIER || (kind>=BUSTER_PP_KIND_KEYWORD && kind<BUSTER_PP_KIND_PRAGMA_END);
            const uint32_t v=named?intern_length(&table,val):val;
            const uint8_t k[2]={kind,pp.output.flags[i]};
            fwrite(k,1,2,f);fwrite(pp.output.locations+i,4,1,f);fwrite(&v,4,1,f);
            if(named)fwrite(intern_bytes(&table,val),1,v,f);
        }
        fclose(f);
    }
    projected_release(&pp,&table);arena_release(&arena);
    return 0;
}
