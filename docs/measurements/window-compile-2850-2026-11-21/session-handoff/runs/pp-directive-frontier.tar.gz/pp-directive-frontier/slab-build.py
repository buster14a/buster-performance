from pathlib import Path
d=Path(__file__).resolve().parent;src=d.parent/'pp-borrowed-slabs/src/buster/compiler'
p=src/'c_preprocessor.c';s=p.read_text().replace('struct Preprocessor\n{','''typedef struct PPSourceSlab
{
    uint32_t data,base,source,output,length;
} PPSourceSlab;

struct Preprocessor
{
    PPSourceSlab* source_slabs;
    uint32_t source_slab_count, source_slab_total, source_slab_rows;
    bool hold_source_slabs;''');p.write_text(s)
p=src/'c_preprocessor_impl.c';s=p.read_text();i=s.index('static uint32_t pp_copy_file_text_vector(')
s=s[:i]+'''// Ordinary file tokens already have an immutable raw producer. Retain a
// source-to-output run until a consumer requests normalized token columns.
static inline bool pp_slab_borrow(Preprocessor* pp,const PPFileData* data,uint32_t base,uint32_t source,uint32_t output,uint32_t length)
{
    if(!pp->source_slabs || !length)return false;
    const uint32_t file=(uint32_t)(data-pp->datas);
    if(pp->source_slab_count)
    {
        PPSourceSlab* last=pp->source_slabs+pp->source_slab_count-1;
        if(last->data==file && last->base==base && last->source+last->length==source && last->output+last->length==output)
        {last->length+=length;pp->source_slab_rows+=length;return true;}
    }
    if(pp->source_slab_count==65536)return false;
    pp->source_slabs[pp->source_slab_count++]=(PPSourceSlab){file,base,source,output,length};
    pp->source_slab_total++;pp->source_slab_rows+=length;return true;
}

static void pp_slab_materialize(Preprocessor* pp)
{
    PPTokens* out=&pp->output;
    for(uint32_t j=0;j<pp->source_slab_count;j++)
    {
        const PPSourceSlab r=pp->source_slabs[j];const PPFileData* d=pp->datas+r.data;
        for(uint32_t n=0;n<r.length;n+=64)
        {
            const uint32_t i=r.source+n,o=r.output+n,count=r.length-n<64?r.length-n:64;
            const __mmask64 valid=_bzhi_u64(UINT64_MAX,count);const __m512i kinds=_mm512_maskz_loadu_epi8(valid,d->kinds+i);
            const __m512i plain=_mm512_and_si512(kinds,_mm512_set1_epi8(127));
            const uint64_t names=_mm512_mask_cmpeq_epi8_mask(valid,plain,_mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            const uint32_t shift=i%64;const uint64_t* bits=d->space+i/64;
            const uint64_t spaces=shift?bits[0]>>shift|bits[1]<<(64-shift):bits[0];
            const __m512i flags=_mm512_or_si512(_mm512_maskz_mov_epi8(spaces,_mm512_set1_epi8(BUSTER_PP_SPACE)),
                _mm512_maskz_mov_epi8(_mm512_movepi8_mask(kinds),_mm512_set1_epi8(BUSTER_PP_START_OF_LINE)));
            _mm512_mask_storeu_epi8(out->kinds+o,valid,plain);_mm512_mask_storeu_epi8(out->flags+o,valid,flags);
            const __m512i base=_mm512_set1_epi32((int)r.base);
            for(uint32_t q=0;q<count;q+=16)
            {
                const __mmask16 lanes=(__mmask16)(valid>>q);const __m512i val=_mm512_maskz_loadu_epi32(lanes,d->values+i+q);
                _mm512_mask_storeu_epi32(out->values+o+q,lanes,_mm512_mask_add_epi32(val,(__mmask16)~(names>>q),val,base));
                _mm512_mask_storeu_epi32(out->locations+o+q,lanes,_mm512_add_epi32(_mm512_maskz_loadu_epi32(lanes,d->starts+i+q),base));
            }
        }
    }
    pp->source_slab_count=0;
}

'''+s[i:]
needle='''        if (take != 0)
        {
            pp_store_file_tokens(out, out->count, data, base, p, available, take, kinds, false);
        }'''
assert s.count(needle)==1
s=s.replace(needle,'''        if (take != 0 && (replaced || !pp_slab_borrow(pp,data,base,p,out->count,take)))
        {
            pp_store_file_tokens(out, out->count, data, base, p, available, take, kinds, false);
        }''')
s=s.replace('if (pp->output.count - pp->keywords_resolved >= BUSTER_PP_KEYWORD_CHUNK)','if (!pp->hold_source_slabs && pp->output.count - pp->keywords_resolved >= BUSTER_PP_KEYWORD_CHUNK)')
s=s.replace('    pp->main_file = file;','''    if(getenv("BUSTER_SOURCE_TOKEN_SLABS"))
    {
        pp->source_slabs=BUSTER_ARENA_PUSH_ARRAY(&pp->arena,PPSourceSlab,65536);
        pp->hold_source_slabs=pp->source_slabs && getenv("BUSTER_SLAB_STREAM_ONLY");
    }
    pp->main_file = file;''',1)
s=s.replace('    pp_resolve_keywords(pp);\n    return pp->errors == 0 && !pp->fatal;','    if(!pp->hold_source_slabs)pp_resolve_keywords(pp);\n    return pp->errors == 0 && !pp->fatal;',1)
s=s.replace('static void pp_resolve_keywords_range(Preprocessor* pp, uint32_t begin, uint32_t end)\n{','static void pp_resolve_keywords_range(Preprocessor* pp, uint32_t begin, uint32_t end)\n{\n    if(pp->source_slab_count)pp_slab_materialize(pp);')
p.write_text(s)
p=d/'slab-probe.c';s=(d.parent/'pp-structural-study/raw-oracle.c').read_text();j=s.index('    const char* path = getenv("PP_PRINT");')
s=s[:j]+'''    const uint64_t ready=pp_benchmark_nanoseconds();
    if(pp.hold_source_slabs)pp_resolve_keywords(&pp);
    const uint64_t complete=pp_benchmark_nanoseconds();
    if(getenv("PP_SLAB_STATS")) fprintf(stderr,"slabs %u rows %u segmented-ready %lu complete %lu flatten %lu\\n",pp.source_slab_total,pp.source_slab_rows,(unsigned long)elapsed,(unsigned long)(complete-begin),(unsigned long)(complete-ready));
'''+s[j:];p.write_text(s)
