#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;ss=$d/../pp-structural-study;mkdir -p residual-macros
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";input=${args[-1]};cd "$d/residual-macros"
args[-1]="$d/macro-all.c"; "$d/macro-rows" "${args[@]}" >summary
args[-1]="$input";python3 "$d/replace-headers-final.py"
PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$d/macro-header-complete.c" PP_PRINT="$d/macro-header-complete.i" "$ss/probe" "${args[@]}" >"$d/macro-header-complete.preflight"
cmp "$ss/original.i" "$d/macro-header-complete.i"
