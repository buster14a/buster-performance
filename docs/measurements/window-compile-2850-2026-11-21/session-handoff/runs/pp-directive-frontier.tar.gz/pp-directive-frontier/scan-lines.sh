#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;src=$d/../pp-structural-gap/src
cc=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$cc" -O3 -march=native -std=gnu17 -I"$src" sparse-lines.c -o sparse-lines
for a in ordinary sparse;do v=();[[ $a == ordinary ]]||v=(SPARSE_PHYSICAL_LINES=1);env "${v[@]}" PRINT_DIRECTIVES=1 ./sparse-lines ../switch-inputs/sqlite/sqlite3.c >"$a-candidate-lines.tsv" 2>"$a-candidate-lines.info";done
cmp ordinary-candidate-lines.tsv sparse-candidate-lines.tsv
