#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;out=$root/results/pp-source-slabs-cycles-v2;mkdir -p "$out";cc=$root/trees/pp-source-slabs-v2/build/compiler;sqlite_ref=$root/results/pp-source-slabs-objects-v2/sqlite-default-ordinary.o
for ((i=0;i<800;i++));do [[ -s "$root/results/pp-source-slabs-objects-v2/hashes" ]] && break;sleep 2;done
test -s "$root/results/pp-source-slabs-objects-v2/hashes"
source corpora.sh;eval "args=($sqlite_arguments)";src=$root/trees/pp-source-slabs-v2/src;paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
./lock.sh taskset -c 2 env PATH="$paths:$PATH" clang -O3 -gline-tables-only -fno-omit-frame-pointer -march=native -std=gnu17 -fwrapv -funsigned-char -I"$src" -I"$src/buster/compiler" pp-frontier/slab-probe.c -o "$out/pp" >"$out/build" 2>&1
for mode in pp compile;do
 for r in 0 1 2;do arms=(ordinary slabs slabs ordinary);[[ $r != 1 ]] || arms=(slabs ordinary ordinary slabs)
  for i in 0 1 2 3;do a=${arms[i]};flags=();[[ $a == ordinary ]] || flags=(BUSTER_SOURCE_TOKEN_SLABS=1 BUSTER_SLAB_STREAM_ONLY=1)
   f=$out/$mode-$r-$i-$a;cmd=("$out/pp" "${args[@]}");[[ $mode != compile ]] || cmd=("$cc" --lanes 1 -c "${args[@]}" -o "$f.o")
   ./lock.sh taskset -c 2 perf stat --no-big-num -x, -o "$f.perf" -e cycles:u,instructions:u,minor-faults,duration_time -- env "${flags[@]}" "${cmd[@]}" >"$f.out" 2>"$f.lease"
   if [[ $mode == compile ]];then cmp "$f.o" "$sqlite_ref";fi
  done
 done
done
(cd "$out" && sha256sum *.o >hashes)
