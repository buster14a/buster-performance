from pathlib import Path
from collections import defaultdict,Counter
import re,subprocess,os,json
d=Path(__file__).resolve().parent;ss=d.parent/'pp-structural-study';root=d.parent/'switch-inputs/sqlite'
s=(d/'macro-all.c').read_bytes()
clang='/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang'
subprocess.run([ss/'scan',d/'macro-all.c',d/'macro-all-directives.tsv'],check=True,stdout=subprocess.DEVNULL)
deps=subprocess.check_output([clang,'-M','-I',root,d/'macro-all.c']).replace(b'\\\n',b' ').split()[1:]
hdr=set();word=re.compile(rb'[A-Za-z_$][A-Za-z_$0-9]*')
for path in deps:
 f=Path(os.fsdecode(path))
 if f.is_file() and f.name!='macro-all.c':hdr.update(word.findall(f.read_bytes()))
(d/'all-headers.txt').write_text('\n'.join(os.fsdecode(p) for p in deps)+'\n')
defs=defaultdict(set);records=[];use=set();previous=0
for line in (d/'macro-all-directives.tsv').read_text().splitlines():
 h,e=map(int,line.split());use.update(word.findall(s[previous:h]));body=re.sub(rb'\\[\r]?\n',b'',s[h:e]);ids=word.findall(body)
 if len(ids)>1 and ids[0] in (b'define',b'undef'):
  name=ids[1];defs[name].update(ids[2:]);records.append((h,e,name))
 else:use.update(ids)
 previous=e
use.update(word.findall(s[previous:]));live=set(defs).intersection(use|hdr)
while True:
 extra=set.union(set(),*(defs[name] for name in live))&defs.keys()-live
 if not extra:break
 live.update(extra)
out=bytearray();previous=0;kept=removed=0
for h,e,name in records:
 if name not in live:
  out+=s[previous:h]+b'\n'*s[h:e].count(b'\n');previous=e;removed+=1
 else:kept+=1
out+=s[previous:];(d/'macro-live-defs.c').write_bytes(out)
print('header files',len(deps)-1,'different primary definition names',len(defs),'retained primary names',len(live),'kept',kept,'removed directive records',removed,'bytes',len(out))
