#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;v=$1;o=$root/results/pp-live-byte-$v;tree=$root/trees/pp-live-byte-$v;mkdir -p "$o"
if [[ ! -d $tree ]];then git -C src worktree add -q --detach "$tree" 0e1d5b825;git -C "$tree" apply "$root/pp-frontier/bytes-$v.patch";fi
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage);src=$tree/src
./lock.sh taskset -c 2 env PATH="$paths:$PATH" clang -O2 -g -fno-omit-frame-pointer -march=native -std=gnu17 -fwrapv -funsigned-char -I"$src" -I"$src/buster/compiler" "pp-frontier/bytes-$v.c" -o "$o/probe" >"$o/build" 2>&1
source corpora.sh;eval "args=($sqlite_arguments)"
for h in deferred full;do for a in ordinary projected;do
 v=();[[ $a == ordinary ]] && v=(PP_EAGER=1) || v=(BUSTER_SOURCE_BYTE_SLABS=1 PP_BYTE_STATS=1 PP_DEBUG=1);[[ $h != full ]] || v+=(PP_RECORD_HISTORY=1)
 f=$o/$h-$a
 ./lock.sh taskset -c 2 env "${v[@]}" PP_ROWS="$f.rows" PP_PRINT="$f.i" "$o/probe" "${args[@]}" >"$f.preflight" 2>"$f.lease"
 done
 cmp "$o/$h-ordinary.rows" "$o/$h-projected.rows";cmp "$o/$h-ordinary.i" "$o/$h-projected.i"
done
(cd "$o" && sha256sum *.i *.rows >preflight-hashes)
test "$(awk '{print $3}' "$o/deferred-projected.preflight")" = 1
for r in 0 1 2;do arms=(ordinary projected projected ordinary);[[ $r != 1 ]] || arms=(projected ordinary ordinary projected)
 for i in 0 1 2 3;do a=${arms[i]};v=(PP_EAGER=1);[[ $a == ordinary ]] || v=(BUSTER_SOURCE_BYTE_SLABS=1)
 f=$o/$r-$i-$a
 ./lock.sh taskset -c 2 perf stat --no-big-num -x, -o "$f.perf" -e cycles:u,instructions:u,duration_time -- env "${v[@]}" "$o/probe" "${args[@]}" >"$f.time" 2>"$f.lease"
 done
done
(cd "$o" && sha256sum *.perf *.time >hashes)
