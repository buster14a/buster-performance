#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;o=$root/results/pp-source-linked-v6;mkdir -p "$o";source corpora.sh;eval "args=($sqlite_arguments)";input=${args[-1]};paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
for a in clang byte slabs;do f=$o/$a
 if [[ $a == clang ]];then ./lock.sh taskset -c 2 env PATH="$paths:$PATH" clang -c "${args[@]}" -o "$f.o" >"$f.compile" 2>&1;obj=$f.o
 elif [[ $a == byte ]];then obj=$root/results/pp-byte-ordinary-v1/sqlite-default-projected.o
 else obj=$root/results/pp-source-slabs-objects-v4/sqlite-default-slabs.o;for ((i=0;i<400;i++));do [[ -s $obj ]] && break;sleep 2;done;fi
 ./lock.sh taskset -c 2 env PATH="$paths:$PATH" clang -I"$(dirname "$input")" pp-frontier/sqlite-driver.c "$obj" -lm -ldl -pthread -o "$f.exe" >"$f.link" 2>&1
 ./lock.sh taskset -c 2 bash -c '"$1" >"$2" 2>"$3"' _ "$f.exe" "$f.out" "$f.err" >"$f.lease" 2>&1
 cmp "$o/clang.out" "$f.out";cmp "$o/clang.err" "$f.err";sha256sum "$obj" >"$f.sha"
done
(cd "$o" && sha256sum *.out *.err >hashes)
