from pathlib import Path
d=Path(__file__).resolve().parent
files=d.parent/'pp-conditional-batches/src/buster/compiler'
p=files/'c_pp_structural_prepare.c'
s=p.read_text()
s=s.replace('    PPContext* gap_context;', '''    uint32_t queued, batch_count, biggest, delimiters, delayed_epoch;
    bool changed_conditions;
    PPContext* gap_context;''')
b=s.index('    uint32_t token=0;');e=s.index('    part.bytes=original;',b)
remap=s[b:e].replace('plan->segment_count','count').replace('plan->segments[seg]','segments[seg]').replace('part.','part->')
remap=remap.replace('        while (token<part->token_count', '''        if (leading_space && piece.from && token<part->token_count && part->starts[token]<limit) part->space[token]|=1;
        while (token<part->token_count''')
s=s[:b]+'    pp_projection_rebase(&part,plan->segments,plan->segment_count,false);\n'+s[e:]
at=s.index('static PPPrepareStatus pp_projection_prepare')
s=s[:at]+'''static void pp_projection_rebase(PPFileData* part, const PPStructSegment* segments,uint32_t count,bool leading_space)
{
'''+remap+'}\n\n'+s[at:]
at=s.index('// A gap contains no directive.')
s=s[:at]+'''// Non-expanding conditional directives preserve the macro table. Their active gaps
// may share one lexer invocation. If ordinary macro expansion would have affected
// an earlier decision (e.g. a replacement that produces _Pragma), replay the TU.
static bool pp_batch_condition(uint32_t kind)
{
    return kind==PP_DIRECTIVE_IFDEF || kind==PP_DIRECTIVE_IFNDEF || kind==PP_DIRECTIVE_ELIFDEF ||
           kind==PP_DIRECTIVE_ELIFNDEF || kind==PP_DIRECTIVE_ELSE || kind==PP_DIRECTIVE_ENDIF;
}

static void pp_batch_append(PPProjection* plan, uint32_t gap)
{
    const PPFileData* file=plan->primary;
    uint32_t begin=gap?plan->index.directives[gap-1].end:0;
    const uint32_t end=gap<plan->index.count?plan->index.directives[gap].hash:file->length;
    uint32_t p=begin;
    while(p<end && (file->bytes[p]==' ' || file->bytes[p]=='\\t' || file->bytes[p]=='\\n' ||
                    file->bytes[p]=='\\r' || file->bytes[p]=='\\v' || file->bytes[p]=='\\f')) p++;
    if(p==end) return;
    plan->segments[plan->queued++]=(PPStructSegment){.from=begin,.length=end-begin};
    plan->reached++;
    plan->reached_bytes+=end-begin;
}

// Virtual source lasts only through tokenization. Every stored raw token and
// macro replacement afterward points back to its original file bytes.
static bool pp_batch_flush(Preprocessor* pp,PPContext* context,PPProjection* plan)
{
    if(!plan->queued) return true;
    if(pp->data_count >= (BUSTER_PP_MAX_FILES >> pp->capacity_shift)) return false;
    const PPFileData* source=plan->primary;
    const uint32_t count=plan->queued;
    uint32_t bytes=0;
    for(uint32_t i=0;i<count;i++)
    {
        PPStructSegment* seg=&plan->segments[i];
        seg->to=bytes;
        if(count>1)
        {
            memcpy(plan->virtual_bytes+bytes,source->bytes+seg->from,seg->length);
            plan->virtual_bytes[bytes+seg->length]='\\n';
        }
        bytes+=seg->length+(count>1);
    }
    PPFileData part={.bytes=count==1?source->bytes+plan->segments[0].from:plan->virtual_bytes,
        .length=bytes,.record=source->record,.device=source->device,.inode=source->inode,
        .modified=source->modified,.has_modified=source->has_modified};
    const PPPrepare config=pp_prepare_config(pp);
    if(pp_prepare_into(&config,pp->table,pp->columns,&pp->arena,&part,NULL)!=PP_PREPARE_DONE ||
       part.directive_count || part.raw_error_count || part.unterminated_comment) return false;
    plan->queued=0;
    plan->batch_count++;
    if(count>plan->biggest) plan->biggest=count;
    plan->reached_rows+=part.token_count;
    pp->input_tokens+=part.token_count;
    if(!part.token_count) {plan->changed_conditions=false;return true;}
    pp_projection_rebase(&part,plan->segments,count,true);
    part.bytes=source->bytes;part.length=source->length;part.line_pages=source->line_pages;
    const uint32_t index=pp->data_count++;
    pp->datas[index]=part;
    plan->gap_context=context;
    plan->resume=*context;
    context->data=index;
    context->position=0;
    context->end=part.token_count;
    context->next_directive=0;
    plan->delayed_epoch=pp->macro_epoch;
    return true;
}

static void pp_projection_live_step(Preprocessor* pp,PPContext* context)
{
    PPProjection* plan=pp_projection;
    if(plan==NULL || !plan->live || context->kind!=BUSTER_PP_CONTEXT_FILE) return;
    if(plan->gap_context==context)
    {
        if(context->position<context->end) return;
        if(plan->changed_conditions && pp->macro_epoch!=plan->delayed_epoch)
        { pp->fatal=plan->failed=true;return; }
        const uint8_t pending=context->pending_flags;
        *context=plan->resume;
        context->pending_flags=pending;
        plan->gap_context=NULL;
        plan->changed_conditions=false;
    }
    if(&pp->datas[context->data]!=plan->primary) return;
    const PPFileData* source=plan->primary;
    const uint32_t gap=context->next_directive;
    if(gap>source->directive_count) return;
    const uint32_t anchor=gap<source->directive_count?source->directive_hash[gap]:source->token_count;
    if(context->position!=anchor) return;
    if(plan->main_range!=BUSTER_PP_NONE && plan->main_range!=context->range)
    {pp->fatal=plan->failed=true;return;}
    plan->main_range=context->range;
    if(gap!=plan->handled)
    {
        plan->handled=gap;
        if(!pp->conditional_count || !pp->conditionals[pp->conditional_count-1].skipping) pp_batch_append(plan,gap);
    }
    if(!plan->queued) return;
    if(gap<source->directive_count && pp_batch_condition(source->directive_kind[gap]) &&
       pp->capture_count==0 && pp->invocation_count==0)
    {
        plan->delimiters++;
        plan->changed_conditions=true;
        return;
    }
    if(!pp_batch_flush(pp,context,plan)) pp->fatal=plan->failed=true;
}
'''
p.write_text(s)
p=files/'c_preprocessor_impl.c';s=p.read_text();a=s.index('    const PPTokens* tokens',s.index('static bool pp_pragma(Preprocessor* pp, uint32_t begin, uint32_t end, uint32_t location, bool from_operator, bool ident, uint32_t restore)\n{'));s=s[:a]+'''#ifdef BUSTER_PP_STRUCTURAL_EXPERIMENT
    if(pp_projection && pp_projection->changed_conditions && from_operator)
    {
        pp->fatal=pp_projection->failed=true;
        return false;
    }
#endif
'''+s[a:];p.write_text(s)
p=d.parent/'pp-structural-study/single-gap.c';s=p.read_text().replace('st.st_size>=(1u<<20)','st.st_size>0').replace('if (!okay || plan.failed','if (!okay || pp.errors || pp.warnings || plan.failed');s=s.replace('    pp_diagnostic_publish(&pp);','    if(getenv("PP_DEBUG")) fprintf(stderr,"batch oracle: reached %u batches %u largest %u crossed %u pending %u macro-epoch %u\\n",plan.reached,plan.batch_count,plan.biggest,plan.delimiters,plan.queued,pp.macro_epoch);\n    pp_diagnostic_publish(&pp);')
(d/'conditional-batches.c').write_text(s)
