// A group selected from an actually reached gap represents physical source
// until the PP reader has proved that its marker was emitted as ordinary text.
typedef struct PPByteGroup
{
    uint32_t begin,end,marker,row,data,output,batch,first,limit;
} PPByteGroup;
