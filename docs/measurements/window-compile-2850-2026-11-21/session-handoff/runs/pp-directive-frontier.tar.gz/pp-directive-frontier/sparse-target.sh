#!/usr/bin/env bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;out=$root/results/pp-sparse-front-v1;tree=$root/trees/pp-sparse-front-v1;mkdir -p "$out"
if [[ ! -d $tree ]];then git -C src worktree add -q --detach "$tree" 0e1d5b825;git -C "$tree" apply "$root/pp-frontier/sparse.patch";fi
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage);src=$tree/src
./lock.sh taskset -c 2 env PATH="$paths:$PATH" clang -O3 -gline-tables-only -fno-omit-frame-pointer -march=native -fwrapv -funsigned-char -std=gnu17 -I"$src" -I"$src/buster/compiler" pp-frontier/raw-oracle.c pp-frontier/overlay.c -Wl,--wrap=open -o "$out/probe" >"$out/build" 2>&1
source corpora.sh;eval "args=($sqlite_arguments)"
for hist in deferred full;do
 for a in ordinary sparse;do
  v=();[[ $a != sparse ]] || v+=(BUSTER_SOURCE_MACRO_EVENTS=1);[[ $hist != full ]] || v+=(PP_RECORD_HISTORY=1)
  path=$out/$hist-$a;mkdir -p "$path";(cd "$path";"$root/lock.sh" taskset -c 2 env "${v[@]}" PP_DUMP_FORM=1 PP_PRINT="$path/sqlite.i" "$out/probe" "${args[@]}" >"$path/measure" 2>"$path/lease")
 done
 for f in primary.raw output.rows sqlite.i;do cmp "$out/$hist-ordinary/$f" "$out/$hist-sparse/$f";done
done
for round in 1 2 3;do arms=(ordinary sparse sparse ordinary);[[ $round != 2 ]] || arms=(sparse ordinary ordinary sparse)
 for i in 0 1 2 3;do a=${arms[i]};v=();[[ $a != sparse ]] || v+=(BUSTER_SOURCE_MACRO_EVENTS=1);"$root/lock.sh" taskset -c 2 env "${v[@]}" "$out/probe" "${args[@]}" >"$out/$round-$i-$a.time" 2>"$out/$round-$i-$a.lease";done
done
(cd "$out" && sha256sum *-*/*.i *-*/output.rows >hashes)
