#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;ss=$d/../pp-structural-study
python3 prune-mode.py macro-header-complete macro-header-pruned
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";input=${args[-1]};cd "$d"
PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$d/macro-header-pruned.c" PP_PRINT="$d/macro-header-pruned.i" "$ss/probe" "${args[@]}" >macro-header-pruned.preflight
cmp "$ss/original.i" "$d/macro-header-pruned.i"
