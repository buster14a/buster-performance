from pathlib import Path
d=Path(__file__).resolve().parent
p=d.parent/'pp-byte-compact/src/buster/compiler/c_pp_structural_prepare.c';s=p.read_text().replace('begin,end,marker,row,data,output,batch,first,limit;', 'begin,end,marker,row,data,output,batch,first,limit,compact;').replace('    PPByteGroup* groups;', '    PPByteGroup* groups;\n    uint64_t shortened;')
s=s.replace('return s[0]|((uint32_t)(n>1?s[1]:0)<<8);', '''uint32_t first=s[0]|((uint32_t)(n>1?s[1]:0)<<8);
    uint32_t last=s[n-1]|((uint32_t)(n>1?s[n-2]:0)<<8);
    return ((first*UINT32_C(0x9e3779b1))^(last*UINT32_C(0x85ebca77)))>>16;''')
s=s.replace('uint32_t begin,uint32_t end)\n{\n    if(!plan->groups', 'uint32_t begin,uint32_t end,uint32_t* size)\n{\n    if(!plan->groups')
b=s.index('    memcpy(bytes,source+begin,end-begin);');e=s.index('    return bytes;',b)
s=s[:b]+'''    uint32_t physical=begin,virtual=0;
    for(uint32_t g=first_group;g<plan->group_count;g++)
    {
        PPByteGroup* r=plan->groups+g;
        const uint32_t count=r->begin-physical;
        memcpy(bytes+virtual,source+physical,count);
        virtual+=count;
        if(r->marker>r->begin)bytes[virtual++]=' ';
        r->compact=virtual;
        bytes[virtual++]='0';
        bytes[virtual++]='\\n';
        physical=r->end;
    }
    memcpy(bytes+virtual,source+physical,end-physical);
    *size=virtual+end-physical;
    plan->shortened+=end-begin-*size;
'''+s[e:]
i=s.index('static bool pp_projection_gap(')
s=s[:i]+'''// Raw rows are monotonic in virtual byte order. Rebase each ordinary source
// interval with one offset, then bind its one marker to the exact source owner.
static void pp_compact_rows(PPFileData* part,uint32_t* cursor,uint32_t stop,uint32_t delta)
{
    uint32_t i=*cursor;
    while(i<part->token_count && part->starts[i]<stop)
    {
        const uint32_t n=part->token_count-i;
        const __mmask16 valid=n>=16?0xffffu:(__mmask16)_bzhi_u32(0xffff,n);
        const __m512i starts=_mm512_maskz_loadu_epi32(valid,part->starts+i);
        const __mmask16 take=_mm512_mask_cmplt_epu32_mask(valid,starts,_mm512_set1_epi32((int32_t)stop));
        const __m128i kinds=_mm_maskz_loadu_epi8(take,part->kinds+i);
        const __mmask16 ends=_mm_mask_cmpneq_epi8_mask(take,_mm_and_si128(kinds,_mm_set1_epi8(127)),_mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
        const __m512i add=_mm512_set1_epi32((int32_t)delta);
        _mm512_mask_storeu_epi32(part->starts+i,take,_mm512_add_epi32(starts,add));
        _mm512_mask_storeu_epi32(part->values+i,ends,_mm512_add_epi32(_mm512_maskz_loadu_epi32(ends,part->values+i),add));
        i+=(uint32_t)__builtin_popcount(take);
    }
    *cursor=i;
}

'''+s[i:]
s=s.replace('pp_byte_mask(pp,plan,begin,end);','pp_byte_mask(pp,plan,begin,end,&part.length);')
b=s.index('    uint32_t cursor=0;',s.index('static bool pp_projection_gap('));e=s.index('    if(begin) part.space',b)
s=s[:b]+'''    uint32_t cursor=0,delta=begin;
    for(uint32_t j=first_group;j<plan->group_count;j++)
    {
        PPByteGroup* r=plan->groups+j;
        pp_compact_rows(&part,&cursor,r->compact,delta);
        if(cursor==part.token_count || part.starts[cursor]!=r->compact || (part.kinds[cursor]&127)!=C_TOKEN_NUMERIC_CONSTANT)return false;
        r->data=pp->data_count;r->row=cursor;
        part.starts[cursor]=r->marker;part.values[cursor]=r->marker+1;
        cursor++;
        delta=r->end-(r->compact+2);
    }
    pp_compact_rows(&part,&cursor,UINT32_MAX,delta);
    plan->reached++;
    plan->reached_bytes+=end-begin;
    plan->reached_rows+=part.token_count;
    pp->input_tokens+=part.token_count;
    if(!part.token_count)return true;
'''+s[e:]
p.write_text(s)
p=d/'bytes-v3.c';s=p.read_text().replace('    pp_diagnostic_publish(&pp);','    if(getenv("PP_DEBUG"))fprintf(stderr,"compact active source bytes excluded %lu\\n",(unsigned long)plan.shortened);\n    pp_diagnostic_publish(&pp);');(d/'bytes-v4.c').write_text(s)
s=(d/'byte-vector-local.sh').read_text().replace('pp-byte-slabs/src','pp-byte-compact/src').replace('byte-probe-vector.c','bytes-v4.c').replace('byte-probe-vector','byte-compact-probe').replace('byte-vector.tsv','byte-compact.tsv').replace('byte-vector.info','byte-compact.info').replace('d/byte.rows','d/byte-compact.rows').replace('d/byte.i','d/byte-compact.i');(d/'byte-compact-local.sh').write_text(s)
