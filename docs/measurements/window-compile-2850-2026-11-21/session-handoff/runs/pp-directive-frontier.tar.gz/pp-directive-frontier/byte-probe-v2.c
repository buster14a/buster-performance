#define BUSTER_PP_STRUCTURAL_EXPERIMENT 1
#include "buster/compiler/c_preprocessor_benchmark.c"
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];
static bool pp_byte_rebuild(Preprocessor* pp,PPProjection* plan)
{
    if(!plan->groups || !plan->group_count)return true;
    if(plan->group_observed!=plan->group_count || plan->main_range>=pp->range_count)return false;
    uint64_t bytes=0;
    for(uint32_t j=0;j<plan->group_count;j++)bytes+=plan->groups[j].end-plan->groups[j].begin+1;
    if(bytes>UINT32_MAX-64)return false;
    uint8_t* batch=calloc((size_t)bytes+64,1);if(!batch)return false;
    const uint8_t* source=plan->primary->bytes;uint32_t pos=0;
    for(uint32_t j=0;j<plan->group_count;j++)
    {
        PPByteGroup* r=plan->groups+j;r->batch=pos;
        memcpy(batch+pos,source+r->begin,r->end-r->begin);pos+=r->end-r->begin;batch[pos++]='\n';
    }
    PPFileData d={.bytes=batch,.length=pos,.record=BUSTER_PP_NONE};
    const PPPrepare config=pp_prepare_config(pp);
    if(pp_prepare_into(&config,pp->table,pp->columns,&pp->arena,&d,NULL)!=PP_PREPARE_DONE || d.directive_count || d.raw_error_count)
    {free(batch);return false;}
    PPTokens* out=&pp->output;uint32_t row=0;const uint32_t base=pp->ranges[plan->main_range].base;
    for(uint32_t j=0;j<plan->group_count;j++)
    {
        PPByteGroup* r=plan->groups+j;r->first=row;
        const uint32_t end=r->batch+r->end-r->begin;
        while(row<d.token_count && d.starts[row]<end)row++;
        r->limit=row;
        if(row==r->first || out->locations[r->output]!=base+r->marker || out->kinds[r->output]!=C_TOKEN_NUMERIC_CONSTANT ||
           (out->flags[r->output]&BUSTER_PP_FROM_MACRO)){free(batch);return false;}
    }
    if(row!=d.token_count || !pp_room(pp,out,row-plan->group_count)){free(batch);return false;}
    uint32_t old=out->count,dst=old+row-plan->group_count;
    plan->byte_rows=row;plan->byte_bytes=pos-plan->group_count;out->count=dst;
    for(uint32_t j=plan->group_count;j>0;j--)
    {
        const PPByteGroup r=plan->groups[j-1];const uint32_t tail=old-r.output-1;
        dst-=tail;
        memmove(out->kinds+dst,out->kinds+r.output+1,tail);memmove(out->flags+dst,out->flags+r.output+1,tail);
        memmove(out->values+dst,out->values+r.output+1,(size_t)tail*4);memmove(out->locations+dst,out->locations+r.output+1,(size_t)tail*4);
        dst-=r.limit-r.first;const uint32_t delta=base+r.begin-r.batch;
        const uint8_t first_flags=out->flags[r.output];
        for(uint32_t i=r.first;i<r.limit;i++)
        {
            const uint32_t w=dst+i-r.first;const uint8_t raw=d.kinds[i],k=raw&127;const uint32_t v=d.values[i];const bool name=k==C_TOKEN_RAW_IDENTIFIER;
            out->kinds[w]=name && v<BUSTER_PP_KEYWORD_TABLE?pp->keyword_kinds[v]:k;
            out->flags[w]=i==r.first?first_flags:(raw&128?BUSTER_PP_START_OF_LINE:0)|(((d.space[i/64]>>(i%64))&1)?BUSTER_PP_SPACE:0);
            out->locations[w]=d.starts[i]+delta;out->values[w]=name?v:v+delta;
        }
        old=r.output;
    }
    pp->keywords_resolved=out->count;free(batch);return old==dst;
}

static bool projected_init(Preprocessor* pp,InternTable* table,const PPOptions* options)
{
 return intern_initialize(table) && pp_initialize(pp,options,table);
}
static void projected_release(Preprocessor* pp,InternTable* table)
{
 pp_release(pp);intern_release(table);
}
int main(int argc,char** argv)
{
    Arena arena=arena_reserve(1ull<<30);
    const char *input,*output;bool markers;PPOptions options;
    if(!pp_parse_options(argc-1,argv+1,&options,&arena,&input,&output,&markers))return 2;
    options.defer_history=getenv("PP_RECORD_HISTORY")==NULL;
    options.collect_diagnostics=true;
    static Preprocessor pre,pp;
    static InternTable trial,table;
    uint64_t begin=pp_benchmark_nanoseconds(), clocks[5]={begin};
    PPProjection plan={.path=input,.forecast=true,.live=true,.handled=BUSTER_PP_NONE,.main_range=BUSTER_PP_NONE};
    const bool eager=getenv("PP_EAGER")!=NULL;
    int fd=eager?-1:open(input,O_RDONLY);struct stat st={0};
    bool possible=fd>=0 && fstat(fd,&st)==0 && st.st_size>=(1u<<20) && st.st_size<UINT32_MAX/2 && !options.assembly && !options.preprocessed &&
        !(c_language_lexer_flags(options.language)&(C_TOKENIZER_NO_LINE_COMMENTS|C_TOKENIZER_CPLUSPLUS));
    uint32_t length=possible?(uint32_t)st.st_size:0;
    uint8_t* raw=possible?mmap(NULL,length,PROT_READ,MAP_PRIVATE,fd,0):MAP_FAILED;
    if(fd>=0)close(fd);
    possible=possible && raw!=MAP_FAILED;
    if(possible)
    {
        plan.original_length=length;plan.device=(uint64_t)st.st_dev;plan.inode=(uint64_t)st.st_ino;
        plan.index.capacity=length/8+8;
        plan.index.directives=malloc((size_t)plan.index.capacity*sizeof(*plan.index.directives));
        if(getenv("BUSTER_SOURCE_BYTE_SLABS"))
        {
            plan.group_capacity=length/8+8;
            plan.groups=calloc(plan.group_capacity,sizeof(*plan.groups));
            plan.index.comment_spans=calloc((size_t)length/2+1,sizeof(*plan.index.comment_spans));
            if(!plan.groups || !plan.index.comment_spans)return 3;
        }
        plan.index.trigraphs=options.trigraphs;
        plan.index.digit_separators=(c_language_lexer_flags(options.language)&C_TOKENIZER_NO_DIGIT_SEPARATORS)==0;
        possible=plan.index.directives && pp_structure_scan(raw,length,&plan.index);
    }
    clocks[1]=pp_benchmark_nanoseconds();
    if(possible)
    {
        size_t count=plan.index.count+1;
        plan.virtual_bytes=malloc((size_t)length+count+128);
        plan.segments=malloc(2*count*sizeof(*plan.segments));
        plan.predicted=calloc(count,1);plan.observed=calloc(count,1);
        possible=plan.virtual_bytes && plan.segments && plan.predicted && plan.observed;
    }
    uint32_t total_skipped=0, omitted=0,unverified=0,predict_bytes=0,live_bytes=0;
    clocks[2]=pp_benchmark_nanoseconds();
    plan.prepared=0;plan.primary=NULL;
    pp_projection=possible?&plan:NULL;
    if(!projected_init(&pp,&table,&options))return 1;
    bool okay=pp_run(&pp,input);
    const uint64_t segmented=pp_benchmark_nanoseconds()-begin;
    if(possible && okay && plan.groups && !pp_byte_rebuild(&pp,&plan))plan.failed=true;
    if (possible)
    {
        predict_bytes=plan.virtual_length;live_bytes=plan.reached_bytes;
        total_skipped=plan.reached;omitted=plan.reached_rows;
        for(uint32_t i=0;i<=plan.index.count;i++)
        {
            const uint32_t a=i?plan.index.directives[i-1].end:0;
            const uint32_t b=i<plan.index.count?plan.index.directives[i].hash:length;
            unverified+=(b>a && plan.predicted[i] && !plan.observed[i]);
        }
        if (!okay || plan.failed || plan.prepared!=1 || unverified)
        {
            projected_release(&pp,&table);possible=false;pp_projection=NULL;
            if(!projected_init(&pp,&table,&options))return 1;
            okay=pp_run(&pp,input);
        }
    }
    clocks[3]=pp_benchmark_nanoseconds();pp_projection=NULL;
    if(getenv("PP_BYTE_STATS"))fprintf(stderr,"bytes %u groups %u observed %u rows %u segmented %lu\n",plan.byte_bytes,plan.group_count,plan.group_observed,plan.byte_rows,(unsigned long)segmented);
    if(getenv("PP_BYTE_STATS") && plan.groups && plan.group_observed<plan.group_count)
    {
        uint32_t n=0;while(n<plan.group_count && plan.groups[n].output!=BUSTER_PP_NONE)n++;
        const PPByteGroup g=plan.groups[n];
        fprintf(stderr,"first unproved %u begin %u end %u marker %u raw %u data %u\n",n,g.begin,g.end,g.marker,g.row,g.data);
    }
    if (getenv("PP_DEBUG")) fprintf(stderr,"structural rejection byte %u; failed %u; prepared %u; physical rows %u\n",plan.index.unsafe,plan.failed,plan.prepared,plan.index.count);
    pp_diagnostic_publish(&pp);
    if(!okay)return 1;
    printf("%lu %u %u %u %u %u %u %u %u %lu %lu %lu\n",clocks[3]-begin,pp.output.count,possible,plan.index.count,total_skipped,omitted,unverified,predict_bytes,live_bytes,clocks[1]-begin,clocks[2]-clocks[1],clocks[3]-clocks[2]);
    if(getenv("PP_PRINT"))
    {
        FILE* f=fopen(getenv("PP_PRINT"),"w");
        if(!f || !pp_print(&pp,f,false) || fclose(f)!=0)return 6;
    }
    if(getenv("PP_ROWS"))
    {
        FILE* f=fopen(getenv("PP_ROWS"),"wb");if(!f)return 7;
        for(uint32_t i=0;i<pp.output.count;i++)
        {
            const uint8_t kind=pp.output.kinds[i];const uint32_t val=pp.output.values[i];
            bool named=kind==C_TOKEN_RAW_IDENTIFIER || (kind>=BUSTER_PP_KIND_KEYWORD && kind<BUSTER_PP_KIND_PRAGMA_END);
            const uint32_t v=named?intern_length(&table,val):val;
            const uint8_t k[2]={kind,pp.output.flags[i]};
            fwrite(k,1,2,f);fwrite(pp.output.locations+i,4,1,f);fwrite(&v,4,1,f);
            if(named)fwrite(intern_bytes(&table,val),1,v,f);
        }
        fclose(f);
    }
    projected_release(&pp,&table);arena_release(&arena);
    if(raw!=MAP_FAILED)munmap(raw,length);
    free(plan.groups);free(plan.index.comment_spans);free(plan.index.directives);free(plan.virtual_bytes);free(plan.segments);free(plan.predicted);free(plan.observed);
    return 0;
}
