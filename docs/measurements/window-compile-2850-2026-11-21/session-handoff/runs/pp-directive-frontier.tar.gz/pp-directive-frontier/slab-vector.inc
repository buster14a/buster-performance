// Convert the common prefix of a physical slab (or a macro output segment)
// straight into the parser's final columns using the live keyword vocabulary.
static inline uint32_t parse_slab_vector(const Preprocessor* pp,const PPSourceSlab* slab,uint32_t i,uint32_t end,
                                         ParseTokens* tokens,uint32_t w,const uint8_t* keyword)
{
    const uint32_t n=end-i<64?end-i:64;
    const __mmask64 valid=_bzhi_u64(UINT64_MAX,n);
    const bool raw=slab!=NULL;
    const PPFileData* f=raw?pp->datas+slab->data:NULL;
    const uint32_t p=raw?slab->source+i-slab->output:i;
    const uint8_t* kc=raw?f->kinds:pp->output.kinds;
    const uint32_t* vc=raw?f->values:pp->output.values;
    const __m512i source=_mm512_maskz_loadu_epi8(valid,kc+p);
    const __m512i kinds=raw?_mm512_and_si512(source,_mm512_set1_epi8(127)):source;
    const uint64_t special=valid&(_mm512_cmpeq_epi8_mask(kinds,_mm512_set1_epi8(C_TOKEN_HASH))|
                    _mm512_cmpeq_epi8_mask(kinds,_mm512_set1_epi8((char)BUSTER_PP_KIND_PRAGMA_END))|
                    _mm512_cmpeq_epi8_mask(kinds,_mm512_set1_epi8(C_TOKEN_COLONCOLON)));
    const uint32_t run=special?(uint32_t)__builtin_ctzll(special):n;
    if(!run)return 0;
    const uint64_t keep=_bzhi_u64(UINT64_MAX,run);
    __m512i flags;
    if(raw)
    {
        const uint32_t shift=p%64;const uint64_t* spaces=f->space+p/64;
        const uint64_t bits=shift?spaces[0]>>shift|spaces[1]<<(64-shift):spaces[0];
        flags=_mm512_or_si512(_mm512_maskz_mov_epi8(bits,_mm512_set1_epi8(BUSTER_PP_SPACE)),
                             _mm512_maskz_mov_epi8(_mm512_movepi8_mask(source),_mm512_set1_epi8(BUSTER_PP_START_OF_LINE)));
    }
    else flags=_mm512_maskz_loadu_epi8(keep,pp->output.flags+i);
    _mm512_mask_storeu_epi8(tokens->flags+w,keep,_mm512_and_si512(flags,_mm512_set1_epi8(BUSTER_PARSE_PP_FLAGS)));
    const __m512i low=_mm512_permutex2var_epi8(_mm512_load_si512(parse_kind_table),kinds,_mm512_load_si512(parse_kind_table+64));
    const __m512i high=_mm512_permutex2var_epi8(_mm512_load_si512(parse_kind_table+128),kinds,_mm512_load_si512(parse_kind_table+192));
    _mm512_mask_storeu_epi8(tokens->kinds+w,keep,_mm512_mask_blend_epi8(_mm512_movepi8_mask(kinds),low,high));
    const uint64_t ids=keep&_mm512_cmpeq_epi8_mask(kinds,_mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
    const uint64_t named=ids|(keep&_mm512_cmpge_epu8_mask(kinds,_mm512_set1_epi8(BUSTER_PP_KIND_KEYWORD))&_mm512_cmplt_epu8_mask(kinds,_mm512_set1_epi8((char)BUSTER_PP_KIND_PRAGMA_END)));
    const __m512i offset=_mm512_set_epi32(15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0);
    for(uint32_t q=0;q<run;q+=16)
    {
        const __mmask16 ok=(__mmask16)(keep>>q);const __m512i val=_mm512_maskz_loadu_epi32((__mmask16)(named>>q),vc+p+q);
        _mm512_mask_storeu_epi32(tokens->names+w+q,ok,val);
        _mm512_mask_storeu_epi32(tokens->sources+w+q,ok,_mm512_add_epi32(offset,_mm512_set1_epi32((int)(i+q))));
        const __mmask16 small=_mm512_mask_cmplt_epu32_mask((__mmask16)(ids>>q),val,_mm512_set1_epi32(256));
        if(small)
        {
            const __m128i ix=_mm512_cvtepi32_epi8(val);const __m512i wide=_mm512_zextsi128_si512(ix);
            const __m128i first=_mm512_castsi512_si128(_mm512_permutex2var_epi8(_mm512_load_si512(keyword),wide,_mm512_load_si512(keyword+64)));
            const __m128i last=_mm512_castsi512_si128(_mm512_permutex2var_epi8(_mm512_load_si512(keyword+128),wide,_mm512_load_si512(keyword+192)));
            _mm_mask_storeu_epi8(tokens->kinds+w+q,small,_mm_mask_blend_epi8(_mm_movepi8_mask(ix),first,last));
        }
    }
    return run;
}
