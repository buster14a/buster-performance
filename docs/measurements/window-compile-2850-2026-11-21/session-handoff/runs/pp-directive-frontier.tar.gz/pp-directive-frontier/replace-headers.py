from pathlib import Path
from bisect import bisect_right
import re
d=Path(__file__).resolve().parent;src=(d/'macro-all.c').read_bytes();hdr=d/'header-slices';directives=[tuple(map(int,line.split())) for line in (d/'header-directives.tsv').read_text().splitlines()];hs=[a for a,b in directives]
pieces={}
for f in hdr.glob('*.inc'):
 p=int(f.stem);k=bisect_right(hs,p)-1;a,b=directives[k];assert a<=p<b,(p,a,b);pieces[a]=f.read_bytes()
out=bytearray();prev=0;count=supplied=0
for a,b in directives:
 words=re.findall(rb'[A-Za-z_$][A-Za-z_$0-9]*',src[a:b])
 if not words or words[0]!=b'include':continue
 out+=src[prev:a];piece=pieces.pop(a,b'');out+=piece+b'\n'*src[a:b].count(b'\n');prev=b;count+=1;supplied+=len(piece)
assert not pieces;out+=src[prev:];(d/'macro-supplied-headers.c').write_bytes(out);print(count,'direct primary includes, inserted',supplied,'header bytes')
