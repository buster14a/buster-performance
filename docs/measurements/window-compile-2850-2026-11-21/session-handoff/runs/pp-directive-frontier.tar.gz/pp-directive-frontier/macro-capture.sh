#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;src=$d/../pp-member-declarations/src
cc=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$cc" -O2 -march=native -std=gnu17 -fwrapv -funsigned-char -I"$src" -I"$src/buster/compiler" macro-rows.c -o macro-rows
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";cd "$d";./macro-rows "${args[@]}";sha256sum invocations.tsv invocation-tokens.bin
