#define STATE
#pragma push_macro("STATE")
#undef STATE
#define Q _Pragma("pop_macro(\"STATE\")")
int before; Q
#ifdef STATE
int yes=7;
#endif
int main(void){return yes!=7;}
