#include "bad.h"
int main(void){return 0;}
