#include "once.h"
#include "once.h"
int main(void){struct H h={8};return FIELD(&h)!=8;}
