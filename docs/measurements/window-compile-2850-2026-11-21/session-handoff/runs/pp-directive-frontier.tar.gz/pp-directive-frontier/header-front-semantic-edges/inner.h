#define NEW_NAME 42
