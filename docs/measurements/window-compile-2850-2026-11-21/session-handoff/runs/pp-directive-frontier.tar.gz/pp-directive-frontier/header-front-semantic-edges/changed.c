#define LIVE
#include "vary.h"
#undef LIVE
#include "vary.h"
int main(void){return 0;}
