#include "nested.h"
int main(void){return NEW_NAME!=42;}
