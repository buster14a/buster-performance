??=define Q 71
int main(void){return Q!=71;}
