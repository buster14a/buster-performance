#define FUN(x,y) ((x)+(y))
#define ON
int main(void){return FUN(
#ifdef ON
4,
#else
7,
#endif
5)!=9;}
