#include "always.h"
int main(void){return ANSWER!=13;}
