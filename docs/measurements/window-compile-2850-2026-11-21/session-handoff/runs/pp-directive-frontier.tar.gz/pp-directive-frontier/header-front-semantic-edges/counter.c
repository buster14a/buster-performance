#define F(x) ((x)+1)
int pre=__COUNTER__;
#if __COUNTER__ == 1
int test=F(__COUNTER__);
#endif
int main(void){return test!=3;}
