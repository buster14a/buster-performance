%:define Q 33
int main(void)<%return Q!=33;%>
