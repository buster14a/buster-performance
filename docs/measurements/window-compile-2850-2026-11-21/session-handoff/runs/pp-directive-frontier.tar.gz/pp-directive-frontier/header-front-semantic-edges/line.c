#include "location.h"
#line 209 "changed.c"
int main(void){return HERELINE!=209 || header_line!=144;}
