from pathlib import Path
from statistics import median
from collections import defaultdict
import re
d=Path(__file__).resolve().parent
for name in ('conditional-native','sparse-native','slabs-native','macro-native','macro-complete-native','pruning-native','simd-slabs-native','byte-native'):
 folder=d/name;data=defaultdict(list)
 for p in sorted(folder.glob('*')):
  m=re.match(r'^\d+-\d+-(.*)\.(time|tsv)$',p.name)
  if not m or not p.stat().st_size:continue
  try:v=int(p.read_text().split()[0])
  except ValueError:continue
  a=m[1];data[a].append(v/1e6)
  lease=p.with_suffix('.lease').read_text()
  if pp:=re.search(r'after parser before conventional demand (\d+) retained rows (\d+) ready (\d+) parse (\d+)',lease):
   _,_,prep,parse=map(int,pp.groups());data[a+'-PP-plus-parser'].append((prep+parse)/1e6)
  if pp:=re.search(r'slabs (\d+) rows (\d+) segmented-ready (\d+) complete (\d+) flatten (\d+)',lease):
   _,_,prep,complete,flat=map(int,pp.groups());data[a+'-flatten'].append(flat/1e6)
 for arm,t in sorted(data.items()):print(name,arm,len(t),f'{median(t):.3f}',f'{min(t):.3f}–{max(t):.3f}')
