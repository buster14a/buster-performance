from pathlib import Path
import sys
p=Path(sys.argv[1]);p.mkdir(exist_ok=True)
(p/'api.h').write_text('''#pragma once
#define NEXT(v) ((v)+3)
struct H { int q; };
#define REG(x) ((struct H){.q=(x)})
''')
s={
'from-header':'#include "api.h"\nint t(int a){return REG(a).q + NEXT(a);}\n',
'pragma':'#pragma pack(push,1)\nstruct p{char a;int b;};\n#pragma pack(pop)\nint t(void){return sizeof(struct p);}\n',
'pragma-expansion':'#define P(x) _Pragma(#x)\nP(pack(push,1))\nstruct p {char a;int b;};\nP(pack(pop))\nint t(void){return sizeof(struct p);}\n',
'condition-counter':'#define S(x) (x)\nint pre=__COUNTER__;\n#if __COUNTER__==1\nint f(void){return S(__COUNTER__);}\n#endif\n',
'poison':'#pragma GCC poison forbidden\nint f(void){int forbidden=1;return forbidden;}\n',
'unknown':'#include "api.h"\n#line 31 "mapped-source.c"\nint f(struct H *p){return p->missing;}\n',
'expand-bad':'#define X(y) (*(y))\nint f(void){return X(1);}\n',
'ucn':'int caf\\u00e9; int f(void){return caf\\u00e9;}\n',
'c23':'[[maybe_unused]] static int a;\nint f(void){return 42;}\n',
'digraph':'%:define A 7\nint f(void)<%return A;%>\n',
'continued':'#define SUM(x,y) ((x) \\\n+(y))\nint f(void){return SUM(3,4);}\n',
'dbllabel':'int f(int x){asm volatile("" :: "r" (x));return x;}\n',
'stringify':'#define S(x) #x\n#define P(a,b) a##b\nint P(ab,cd); const char *p=S(ab cd);\n',
'redefinition':'#include "api.h"\n#undef NEXT\n#define NEXT(v) ((v)+9)\nstruct Record { long q; }; int f(struct Record *p){return NEXT(p->q);}\n'
}
for name,src in s.items():(p/(name+'.c')).write_text(src)
(p/'names').write_text('\n'.join(s)+'\n')
