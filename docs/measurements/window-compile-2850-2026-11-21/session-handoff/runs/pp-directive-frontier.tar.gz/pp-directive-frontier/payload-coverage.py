from pathlib import Path
from collections import Counter,defaultdict
from array import array
from bisect import bisect_left,bisect_right
import re,csv,json
d=Path(__file__).resolve().parent;ss=d.parent/'pp-structural-study';s=(d.parent/'switch-inputs/sqlite/sqlite3.c').read_bytes()
raw=array('I');raw.frombytes((ss/'raw.ledger').read_bytes());ks=raw[::3];ps=raw[1::3];es=raw[2::3];n=len(ks)
def diffs():return bytearray(n)
skip=diffs();dr=diffs()
for row in (d.parent/'inactive-source-study/sqlite.stderr').read_text().splitlines():
 f=row.split('\t')
 if f[0]=='pp-group-skip' and int(f[1])==len(s):
  b,e=map(int,f[3:5]);skip[b:e]=b'\1'*(e-b)
for row in (d/'dirs.tsv').read_text().splitlines():
 b,e=map(int,row.split());lo=bisect_left(ps,b);hi=bisect_left(ps,e);dr[lo:hi]=b'\1'*(hi-lo)
defs={r[0].encode() for r in csv.reader((ss/'macro-defs.tsv').open(),delimiter='\t')};defs.update([b'_Pragma',b'__pragma',b'defined'])
digraph=fs=0
lines=s.splitlines(keepends=True); groups={mode:[] for mode in ['lexical','any-bytes','no-trivia-crossing','direct-provenance']}; base=int((ss/'macro-range').read_text().split()[1]);match=Counter()
a=d.parent/'active-source-study/target';v=(a/'output.rows').read_bytes();W=len(v)//10;fl=v[W:2*W];lo=array('I');lo.frombytes(v[2*W:6*W]);direct={p-base for p,f in zip(lo,fl) if not f&8 and 0<=p-base<len(s)}
total=Counter(); off=0; i=0
for num,line in enumerate(lines):
 start=off;off+=len(line);b=i
 while i<n and ps[i]<off:i+=1
 if i==b or any(dr[b:i]) or any(skip[b:i]):continue
 total['rows']+=i-b;total['lines']+=1
 names=[s[ps[j]:es[j]] for j in range(b,i) if ks[j]&127==1]
 allplain=all(p in direct for p in ps[b:i])
 nameset=any(w in defs for w in names); trivial=not any(c in line for c in (b'/',b'\\',b'"',b"'",b'%',b'#',b'?',b'$')) and line.isascii()
 for mode,yes in [('lexical',not nameset),('any-bytes',not nameset and trivial),('no-trivia-crossing',not nameset and b'\\' not in line),('direct-provenance',allplain)]:
  if yes:
   gs=groups[mode]
   if gs and gs[-1][3]==num and gs[-1][2]==b:
    gs[-1][1]=off;gs[-1][2]=i;gs[-1][3]=num+1
   else: gs.append([start,off,i,num+1,b])
result={}
for mode,gs in groups.items():
 result[mode]={}
 for threshold in [1,8,16,32,64,128,256]:
  subset=[g for g in gs if g[2]-g[4]>=threshold]
  result[mode][threshold]=[len(subset),sum(g[2]-g[4] for g in subset),sum(g[1]-g[0] for g in subset)]
print(json.dumps({'eligible':total,'counts-groups-rows-bytes':result},indent=2))
