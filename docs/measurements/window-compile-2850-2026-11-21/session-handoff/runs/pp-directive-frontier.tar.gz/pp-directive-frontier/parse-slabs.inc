// Convert raw source slabs directly into the actual parser's token columns.
// Macro results and pragma records are the ordinary PP's dense exceptions.
static bool parse_from_source_slabs(Preprocessor* pp,ParseTokens* tokens)
{
    const PPTokens* output=&pp->output;
    uint32_t written=0,j=0;
    bool identity=true;
    tokens->pragma_count=0;
    for(uint32_t i=0;i<output->count;)
    {
        while(j<pp->source_slab_count && pp->source_slabs[j].output+pp->source_slabs[j].length<=i)j++;
        const PPSourceSlab* slab=j<pp->source_slab_count?pp->source_slabs+j:NULL;
        const bool raw=slab && i>=slab->output;
        const uint32_t end=raw?slab->output+slab->length:slab?slab->output:output->count;
        const PPFileData* file=raw?pp->datas+slab->data:NULL;
        for(;i<end;)
        {
            uint8_t k,flags;uint32_t v;
            if(raw)
            {
                const uint32_t p=slab->source+(i-slab->output);
                const uint8_t source=file->kinds[p];
                k=source&127;v=file->values[p];
                flags=((source&128)?BUSTER_PP_START_OF_LINE:0)|(((file->space[p/64]>>(p%64))&1)?BUSTER_PP_SPACE:0);
            }
            else{k=output->kinds[i];v=output->values[i];flags=output->flags[i];}
            if(k==C_TOKEN_RAW_IDENTIFIER && v<BUSTER_PP_KEYWORD_TABLE)k=pp->keyword_kinds[v];
            if(k==C_TOKEN_HASH || k==BUSTER_PP_KIND_PRAGMA_END || k==C_TOKEN_COLONCOLON)
            {
                if(raw)return false;
                identity=false;
                const uint32_t next=parse_convert_token(output,i,tokens,&written);
                if(next>end)return false;
                i=next;continue;
            }
            tokens->kinds[written]=parse_kind_table[k];
            tokens->names[written]=k==C_TOKEN_RAW_IDENTIFIER || (k>=BUSTER_PP_KIND_KEYWORD && k<BUSTER_PP_KIND_PRAGMA_END)?v:0;
            tokens->flags[written]=flags&BUSTER_PARSE_PP_FLAGS;
            tokens->sources[written++]=i++;
        }
    }
    tokens->count=written;tokens->identity_sources=identity;parse_tokens_pad(tokens);return true;
}
