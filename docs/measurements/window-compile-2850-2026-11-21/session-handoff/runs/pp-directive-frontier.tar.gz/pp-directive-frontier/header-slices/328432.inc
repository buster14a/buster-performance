struct flock
{
short int l_type;
short int l_whence;
__off64_t l_start;
__off64_t l_len;
__pid_t l_pid;
};
struct flock64
{
short int l_type;
short int l_whence;
__off64_t l_start;
__off64_t l_len;
__pid_t l_pid;
};
struct iovec
{
void *iov_base;
size_t iov_len;
};
enum __pid_type
{
F_OWNER_TID = 0,
F_OWNER_PID,
F_OWNER_PGRP,
F_OWNER_GID = F_OWNER_PGRP
};
struct f_owner_ex
{
enum __pid_type type;
__pid_t pid;
};
struct file_handle
{
unsigned int handle_bytes;
int handle_type;
unsigned char f_handle[0];
};
extern __ssize_t readahead (int __fd, __off64_t __offset, size_t __count)
__attribute__ ((__nothrow__ ));
extern int sync_file_range (int __fd, __off64_t __offset, __off64_t __count,
unsigned int __flags);
extern __ssize_t vmsplice (int __fdout, const struct iovec *__iov,
size_t __count, unsigned int __flags);
extern __ssize_t splice (int __fdin, __off64_t *__offin, int __fdout,
__off64_t *__offout, size_t __len,
unsigned int __flags);
extern __ssize_t tee (int __fdin, int __fdout, size_t __len,
unsigned int __flags);
extern int fallocate (int __fd, int __mode, __off64_t __offset, __off64_t __len) __asm__ ("" "fallocate64");
extern int fallocate64 (int __fd, int __mode, __off64_t __offset,
__off64_t __len);
extern int name_to_handle_at (int __dfd, const char *__name,
struct file_handle *__handle, int *__mnt_id,
int __flags) __attribute__ ((__nothrow__ ));
extern int open_by_handle_at (int __mountdirfd, struct file_handle *__handle,
int __flags);
struct open_how {
__u64 flags;
__u64 mode;
__u64 resolve;
};
extern int openat2 (int __dfd, const char * __filename,
const struct open_how * __how,
long unsigned int __usize)
__attribute__ ((__nonnull__ (3)));
extern int fcntl (int __fd, int __cmd, ...) __asm__ ("" "fcntl64");
extern int fcntl64 (int __fd, int __cmd, ...);
extern int open (const char *__file, int __oflag, ...) __asm__ ("" "open64")
__attribute__ ((__nonnull__ (1)));
extern int open64 (const char *__file, int __oflag, ...) __attribute__ ((__nonnull__ (1)));
extern int openat (int __fd, const char *__file, int __oflag, ...) __asm__ ("" "openat64");
extern int openat64 (int __fd, const char *__file, int __oflag, ...);
extern int creat (const char *__file, mode_t __mode) __asm__ ("" "creat64") __attribute__ ((__nonnull__ (1)));
extern int creat64 (const char *__file, mode_t __mode) __attribute__ ((__nonnull__ (1)));
extern int lockf (int __fd, int __cmd, __off64_t __len) __asm__ ("" "lockf64") ;
extern int lockf64 (int __fd, int __cmd, off64_t __len) ;
extern int posix_fadvise (int __fd, __off64_t __offset, __off64_t __len, int __advise) __asm__ ("" "posix_fadvise64") __attribute__ ((__nothrow__ ));
extern int posix_fadvise64 (int __fd, off64_t __offset, off64_t __len,
int __advise) __attribute__ ((__nothrow__ ));
extern int posix_fallocate (int __fd, __off64_t __offset, __off64_t __len) __asm__ ("" "posix_fallocate64");
extern int posix_fallocate64 (int __fd, off64_t __offset, off64_t __len);
