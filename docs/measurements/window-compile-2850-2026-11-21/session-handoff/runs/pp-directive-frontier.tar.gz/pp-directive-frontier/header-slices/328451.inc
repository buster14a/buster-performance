struct winsize
{
unsigned short int ws_row;
unsigned short int ws_col;
unsigned short int ws_xpixel;
unsigned short int ws_ypixel;
};
extern int ioctl (int __fd, unsigned long int __request, ...) __attribute__ ((__nothrow__ ));
