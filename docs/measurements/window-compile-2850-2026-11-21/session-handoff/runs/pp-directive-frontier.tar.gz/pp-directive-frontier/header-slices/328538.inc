int memfd_create (const char *__name, unsigned int __flags) __attribute__ ((__nothrow__ ));
int mlock2 (const void *__addr, size_t __length, unsigned int __flags) __attribute__ ((__nothrow__ ))
;
int pkey_alloc (unsigned int __flags, unsigned int __access_restrictions) __attribute__ ((__nothrow__ ));
int pkey_set (int __key, unsigned int __access_restrictions) __attribute__ ((__nothrow__ ));
int pkey_get (int __key) __attribute__ ((__nothrow__ ));
int pkey_free (int __key) __attribute__ ((__nothrow__ ));
int pkey_mprotect (void *__addr, size_t __len, int __prot, int __pkey) __attribute__ ((__nothrow__ ));
int mseal (void *__addr, size_t __len, unsigned long flags) __attribute__ ((__nothrow__ ));
extern void * mmap (void *__addr, size_t __len, int __prot, int __flags, int __fd, __off64_t __offset) __asm__ ("" "mmap64") __attribute__ ((__nothrow__ ));
extern void *mmap64 (void *__addr, size_t __len, int __prot,
int __flags, int __fd, __off64_t __offset) __attribute__ ((__nothrow__ ));
extern int munmap (void *__addr, size_t __len) __attribute__ ((__nothrow__ ));
extern int mprotect (void *__addr, size_t __len, int __prot) __attribute__ ((__nothrow__ ));
extern int msync (void *__addr, size_t __len, int __flags);
extern int madvise (void *__addr, size_t __len, int __advice) __attribute__ ((__nothrow__ ));
extern int posix_madvise (void *__addr, size_t __len, int __advice) __attribute__ ((__nothrow__ ));
extern int mlock (const void *__addr, size_t __len) __attribute__ ((__nothrow__ ))
;
extern int munlock (const void *__addr, size_t __len) __attribute__ ((__nothrow__ ))
;
extern int mlockall (int __flags) __attribute__ ((__nothrow__ ));
extern int munlockall (void) __attribute__ ((__nothrow__ ));
extern int mincore (void *__start, size_t __len, unsigned char *__vec)
__attribute__ ((__nothrow__ ));
extern void *mremap (void *__addr, size_t __old_len, size_t __new_len,
int __flags, ...) __attribute__ ((__nothrow__ ));
extern int remap_file_pages (void *__start, size_t __size, int __prot,
size_t __pgoff, int __flags) __attribute__ ((__nothrow__ ));
extern int shm_open (const char *__name, int __oflag, mode_t __mode);
extern int shm_unlink (const char *__name);
struct iovec;
extern __ssize_t process_madvise (int __pid_fd, const struct iovec *__iov,
size_t __count, int __advice,
unsigned __flags)
__attribute__ ((__nothrow__ ));
extern int process_mrelease (int pidfd, unsigned int flags) __attribute__ ((__nothrow__ ));
