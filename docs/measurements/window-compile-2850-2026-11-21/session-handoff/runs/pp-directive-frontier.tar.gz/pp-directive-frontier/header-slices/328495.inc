struct timezone
{
int tz_minuteswest;
int tz_dsttime;
};
extern int gettimeofday (struct timeval *__restrict __tv,
void *__restrict __tz) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int settimeofday (const struct timeval *__tv,
const struct timezone *__tz)
__attribute__ ((__nothrow__ ));
extern int adjtime (const struct timeval *__delta,
struct timeval *__olddelta) __attribute__ ((__nothrow__ ));
enum __itimer_which
{
ITIMER_REAL = 0,
ITIMER_VIRTUAL = 1,
ITIMER_PROF = 2
};
struct itimerval
{
struct timeval it_interval;
struct timeval it_value;
};
typedef enum __itimer_which __itimer_which_t;
extern int getitimer (__itimer_which_t __which,
struct itimerval *__value) __attribute__ ((__nothrow__ ));
extern int setitimer (__itimer_which_t __which,
const struct itimerval *__restrict __new,
struct itimerval *__restrict __old) __attribute__ ((__nothrow__ ));
extern int utimes (const char *__file, const struct timeval __tvp[2])
__attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int lutimes (const char *__file, const struct timeval __tvp[2])
__attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int futimes (int __fd, const struct timeval __tvp[2]) __attribute__ ((__nothrow__ ));
extern int futimesat (int __fd, const char *__file,
const struct timeval __tvp[2]) __attribute__ ((__nothrow__ ));
