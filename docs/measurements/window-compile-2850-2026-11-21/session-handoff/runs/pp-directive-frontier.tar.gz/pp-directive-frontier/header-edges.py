from pathlib import Path
import sys
p=Path(sys.argv[1]);p.mkdir(exist_ok=True)
body='\n'.join('extern int inactive_name_%03d;'%i for i in range(140))+'\n'
files={
'always.h':'#if 0\n'+body+'#endif\n#define ANSWER 13\nextern int typed(int);\n',
'vary.h':'#ifndef LIVE\n'+body+'#endif\n',
'once.h':'#pragma once\n#if 0\n'+body+'#endif\nstruct H { int x; };\n#define FIELD(p) ((p)->x)\n',
'inner.h':'#define NEW_NAME 42\n',
'nested.h':'#include "inner.h"\n#ifdef NEW_NAME\n'+body+'#endif\n',
'location.h':'#if 0\n'+body+'#endif\n#define HERELINE __LINE__\nstatic int header_line=__LINE__;\n',
'stack.h':'#pragma push_macro("FLIP")\n#define FLIP\n_Pragma("pop_macro(\\"FLIP\\")")\n#ifdef FLIP\n'+body+'#endif\n',
'bad.h':'#if 0\n'+body+'#else\n#error targeted_failure\n#endif\n'}
for n,s in files.items():(p/n).write_text(s)
sources={
'constant':'#include "always.h"\nint main(void){return ANSWER!=13;}\n',
'changed':'#define LIVE\n#include "vary.h"\n#undef LIVE\n#include "vary.h"\nint main(void){return 0;}\n',
'guard':'#include "once.h"\n#include "once.h"\nint main(void){struct H h={8};return FIELD(&h)!=8;}\n',
'transitive':'#include "nested.h"\nint main(void){return NEW_NAME!=42;}\n',
'line':'#include "location.h"\n#line 209 "changed.c"\nint main(void){return HERELINE!=209 || header_line!=144;}\n',
'pragma':'#include "stack.h"\nint main(void){return 0;}\n',
'error':'#include "bad.h"\nint main(void){return 0;}\n',
'counter':'#define F(x) ((x)+1)\nint pre=__COUNTER__;\n#if __COUNTER__ == 1\nint test=F(__COUNTER__);\n#endif\nint main(void){return test!=3;}\n',
'conditional-macros':'#define FUN(x,y) ((x)+(y))\n#define ON\nint main(void){return FUN(\n#ifdef ON\n4,\n#else\n7,\n#endif\n5)!=9;}\n',
'operator-restores':'#define STATE\n#pragma push_macro("STATE")\n#undef STATE\n#define Q _Pragma("pop_macro(\\"STATE\\")")\nint before; Q\n#ifdef STATE\nint yes=7;\n#endif\nint main(void){return yes!=7;}\n',
'tri':'??=define Q 71\nint main(void){return Q!=71;}\n',
'digraph':'%:define Q 33\nint main(void)<%return Q!=33;%>\n'}
for n,s in sources.items():(p/(n+'.c')).write_text(s)
(p/'names').write_text('\n'.join(sources)+'\n')
