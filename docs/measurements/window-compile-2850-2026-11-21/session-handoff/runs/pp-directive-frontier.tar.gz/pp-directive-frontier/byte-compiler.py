from pathlib import Path
d=Path(__file__).resolve().parent;src=d.parent/'pp-byte-slabs-compiler/src/buster/compiler';p=src/'c_pp_structural_prepare.c';s=p.read_text().replace('    bool forecast, failed, live;','    bool forecast, failed, live,initialize;')
a=s.index('static bool pp_projection_gap(')
s=s[:a]+'''static bool pp_byte_primary(Preprocessor* pp,PPFileData* data,PPProjection* plan)
{
    if(!plan->initialize)return true;
    plan->initialize=false;
    const uint32_t length=data->length;
    if(length<(1u<<20) || length>=UINT32_MAX/2)return false;
    plan->original_length=length;plan->device=data->device;plan->inode=data->inode;
    plan->group_capacity=length/8+8;
    plan->index.capacity=length/8+8;
    plan->index.directives=calloc(plan->index.capacity,sizeof(*plan->index.directives));
    plan->index.comment_spans=calloc((size_t)length/2+1,sizeof(*plan->index.comment_spans));
    plan->index.parens=calloc((size_t)length+1,sizeof(uint32_t));
    plan->macro_signatures=calloc(65536,sizeof(uint64_t));
    plan->groups=calloc(plan->group_capacity,sizeof(*plan->groups));
    if(!plan->index.directives || !plan->index.comment_spans || !plan->index.parens || !plan->macro_signatures || !plan->groups)return false;
    for(uint32_t i=1;i<=pp->macro_count;i++)if(pp->macros[i].name)pp_byte_defined(pp,pp->macros[i].name);
    plan->index.trigraphs=pp->options.trigraphs;
    plan->index.digit_separators=(c_language_lexer_flags(pp->options.language)&C_TOKENIZER_NO_DIGIT_SEPARATORS)==0;
    if(!pp_structure_scan(data->bytes,length,&plan->index))return false;
    const size_t count=(size_t)plan->index.count+1;
    plan->virtual_bytes=malloc(length+count+128);
    plan->segments=malloc(2*count*sizeof(*plan->segments));
    plan->predicted=calloc(count,1);plan->observed=calloc(count,1);
    return plan->virtual_bytes && plan->segments && plan->predicted && plan->observed;
}
static void pp_byte_close(PPProjection* plan)
{
    free(plan->groups);free(plan->macro_signatures);free(plan->index.parens);free(plan->index.comment_spans);free(plan->index.directives);
    free(plan->virtual_bytes);free(plan->segments);free(plan->predicted);free(plan->observed);
}

'''+s[a:];p.write_text(s)
p=src/'c_preprocessor_impl.c';s=p.read_text();s=s.replace('#ifdef BUSTER_PP_STRUCTURAL_EXPERIMENT\n#include "buster/compiler/c_pp_structural_prepare.c"', '#ifndef BUSTER_PP_STRUCTURAL_EXPERIMENT\n#define BUSTER_PP_STRUCTURAL_EXPERIMENT 1\n#endif\n#ifdef BUSTER_PP_STRUCTURAL_EXPERIMENT\n#include "buster/compiler/c_pp_structural_prepare.c"',1)
s=s.replace('''    if (pp_projection != NULL && strcmp(path, pp_projection->path)==0)
    {
        status=pp_projection_prepare(pp,data,ticks);
    }''','''    if(pp_projection && strcmp(path,pp_projection->path)==0 && !pp_byte_primary(pp,data,pp_projection))pp_projection=NULL;
    if (pp_projection != NULL && strcmp(path, pp_projection->path)==0)
    {
        status=pp_projection_prepare(pp,data,ticks);
    }''')
probe=(d/'byte-probe-vector.c').read_text();f=probe[probe.index('static uint32_t pp_byte_boundary('):probe.index('static bool projected_init(')]
idx=s.index('BUSTER_PREPROCESSOR_ENTRY bool pp_run(Preprocessor* pp, const char* main_path)\n');s=s[:idx]+f+'\n'+s[idx:]
needle='''    const bool result = pp_preprocess_file(pp, main_path);
    pp_history_report(pp, result);'''
assert s.count(needle)==1
s=s.replace(needle,'''    const bool trial=getenv("BUSTER_SOURCE_BYTE_SLABS") && !pp_projection && !pp->options.assembly && !pp->options.preprocessed &&
        !pp->options.show_includes && !(c_language_lexer_flags(pp->options.language)&(C_TOKENIZER_NO_LINE_COMMENTS|C_TOKENIZER_CPLUSPLUS));
    PPProjection unit={.path=main_path,.initialize=true,.forecast=true,.live=true,.handled=BUSTER_PP_NONE,.main_range=BUSTER_PP_NONE};
    PPOptions original=pp->options;original.quiet=pp->history_quiet;
    if(pp->history_deferred)original.no_history=false;
    const bool quiet=pp->options.quiet;
    if(trial){pp_projection=&unit;pp->options.quiet=true;}
    bool result=pp_preprocess_file(pp, main_path);
    if(trial)
    {
        const bool exercised=pp_projection==&unit && unit.prepared!=0;
        const bool confirmed=exercised && result && !unit.failed && unit.prepared==1 && !pp->errors && !pp->warnings && pp_byte_rebuild(pp,&unit);
        if(getenv("BUSTER_SOURCE_BYTE_REPORT"))
        {
            uint32_t missed=0;while(missed<unit.group_count && unit.groups[missed].output!=BUSTER_PP_NONE)missed++;
            fprintf(stderr,"physical-byte-source confirmed=%u groups=%u observed=%u original-rows=%u source-bytes=%u first-miss=%u\\n",
                confirmed,unit.group_count,unit.group_observed,unit.byte_rows,unit.byte_bytes,missed<unit.group_count?unit.groups[missed].marker:0);
        }
        pp_projection=NULL;pp->options.quiet=quiet;pp_byte_close(&unit);
        if((exercised && !confirmed) || ((!result || pp->errors || pp->warnings) && !quiet))
        {
            InternTable* table=pp->table;
            pp_release(pp);
            if(!pp_initialize(pp,&original,table))return false;
            pp->history_path=main_path;pp->options.quiet|=pp->history_deferred;
            result=pp_preprocess_file(pp,main_path);
        }
    }
    pp_history_report(pp, result);''');p.write_text(s)
