#include "buster/compiler/c_preprocessor_benchmark.c"
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];

int main(int argc, char** argv)
{
    Arena arena = arena_reserve(1ull << 30);
    const char *input, *output;
    bool markers;
    PPOptions options;
    static InternTable table;
    static Preprocessor pp;
    if (!pp_parse_options(argc - 1, argv + 1, &options, &arena, &input, &output, &markers)) return 2;
    options.defer_history = getenv("PP_RECORD_HISTORY") == NULL;
    options.timing = getenv("PP_STAGE_TIMING") != NULL;
    const uint64_t begin = pp_benchmark_nanoseconds();
    if (!intern_initialize(&table) || !pp_initialize(&pp, &options, &table) || !pp_run(&pp, input)) return 1;
    const uint64_t elapsed = pp_benchmark_nanoseconds() - begin;
    printf("%lu %u %lu %u %u %u\n",(unsigned long)elapsed, pp.output.count,(unsigned long)pp.input_tokens,table.count,pp.history_count,pp.history_run_count);
    const uint64_t ready=pp_benchmark_nanoseconds();
    if(pp.hold_source_slabs)pp_resolve_keywords(&pp);
    const uint64_t complete=pp_benchmark_nanoseconds();
    if(getenv("PP_SLAB_STATS")) fprintf(stderr,"slabs %u rows %u segmented-ready %lu complete %lu flatten %lu\n",pp.source_slab_total,pp.source_slab_rows,(unsigned long)elapsed,(unsigned long)(complete-begin),(unsigned long)(complete-ready));
    const char* path = getenv("PP_PRINT");
    if (path != NULL)
    {
        FILE* file = fopen(path, "w");
        if (file == NULL || !pp_print(&pp, file, false) || fclose(file) != 0) return 4;
    }
    if (getenv("PP_DUMP_FORM") != NULL)
    {
        const PPFileData* data = &pp.datas[pp.files[pp.main_file].data];
        fprintf(stderr, "raw %u bytes %u idkind %u\n", data->token_count, data->length, C_TOKEN_RAW_IDENTIFIER);
        for (uint32_t i = 0; i < pp.range_count; i += 1)
            if (pp.ranges[i].file == pp.main_file) fprintf(stderr, "range %u base %u length %u\n", i, pp.ranges[i].base, pp.ranges[i].length);
        FILE* f = fopen("primary.raw", "wb");
        if (!f || fwrite(data->kinds,1,data->token_count,f)!=data->token_count ||
            fwrite(data->starts,4,data->token_count,f)!=data->token_count || fwrite(data->values,4,data->token_count,f)!=data->token_count || fclose(f)) return 3;
        f = fopen("output.rows", "wb");
        if (!f || fwrite(pp.output.kinds,1,pp.output.count,f)!=pp.output.count || fwrite(pp.output.flags,1,pp.output.count,f)!=pp.output.count ||
            fwrite(pp.output.locations,4,pp.output.count,f)!=pp.output.count || fwrite(pp.output.values,4,pp.output.count,f)!=pp.output.count || fclose(f)) return 3;
    }
    if (getenv("PP_RAW_LEDGER") != NULL)
    {
        const PPFileData* data=&pp.datas[pp.files[pp.main_file].data];
        FILE* f=fopen(getenv("PP_RAW_LEDGER"),"wb");
        if (!f) return 7;
        for (uint32_t i=0;i<data->token_count;i++)
        {
            const uint32_t k=data->kinds[i], start=data->starts[i];
            const uint32_t end=(k&127)==C_TOKEN_RAW_IDENTIFIER ? pp_identifier_end(&pp,data->bytes,data->length,start):data->values[i];
            const uint32_t row[3]={k|(((data->space[i/64]>>(i%64))&1u)<<8), start, end};
            if (fwrite(row,sizeof(row),1,f)!=1) return 7;
        }
        fclose(f);
    }
    pp_release(&pp);
    intern_release(&table);
    arena_release(&arena);
    return 0;
}
