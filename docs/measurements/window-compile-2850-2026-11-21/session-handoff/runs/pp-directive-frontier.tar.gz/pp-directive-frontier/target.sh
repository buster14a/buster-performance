#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;out=$root/results/pp-conditional-frontier;mkdir -p "$out";source corpora.sh;eval "args=($sqlite_arguments)";input=${args[-1]};tool=$root/results/structural-single-ideal/probe
for f in compact-reference no-conditional-compact no-conditional-entire-live;do
 sample=$root/pp-frontier/$f.c
 ./lock.sh taskset -c 2 env PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$sample" PP_PRINT="$out/$f.i" "$tool" "${args[@]}" >"$out/$f.preflight" 2>"$out/$f.lease"
 cmp "$out/$f.i" "$root/results/active-source-profile/ordinary.i"
done
for r in 1 2 3;do
 case $r in 1) arms=(compact-reference no-conditional-compact no-conditional-entire-live no-conditional-entire-live no-conditional-compact compact-reference);;2)arms=(no-conditional-compact no-conditional-entire-live compact-reference compact-reference no-conditional-entire-live no-conditional-compact);;3)arms=(no-conditional-entire-live compact-reference no-conditional-compact no-conditional-compact compact-reference no-conditional-entire-live);;esac
 for i in {0..5};do f=${arms[i]};./lock.sh taskset -c 2 env PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$root/pp-frontier/$f.c" "$tool" "${args[@]}" >"$out/$r-$i-$f.tsv" 2>"$out/$r-$i-$f.lease";done
done
(cd "$out" && sha256sum *.i >hashes)
