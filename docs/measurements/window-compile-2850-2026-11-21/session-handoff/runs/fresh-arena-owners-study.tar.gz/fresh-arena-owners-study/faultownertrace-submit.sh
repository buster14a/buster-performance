#!/bin/bash
set -eu
cd "$(dirname "$0")"
bash build-label.sh faultownertrace 40ae34f9d77afc42face58eff3338b7b1d1ba469 faultownertrace.patch
bash faultownertrace-one.sh
