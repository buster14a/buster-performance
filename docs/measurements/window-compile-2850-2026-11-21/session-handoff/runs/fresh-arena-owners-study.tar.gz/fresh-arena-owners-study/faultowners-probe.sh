#!/bin/bash
set -eu
cd "$(dirname "$0")"
top=$PWD
source corpora.sh
main_arguments="-march=native -I$top/pooled-main-source/src -fwrapv -funsigned-char --predefines $top/proof-predefines.h $top/pooled-main-source/src/buster/compiler/main.c"
bin=$PWD/results/main40ae/compiler
out=$PWD/results/faultowners40ae
mkdir -p "$out"
for group in sqlite main;do
 opts=${group}_arguments
 eval "args=(${!opts})"
 ./lock.sh bash capture2850.sh "$out/$group.normal.out" "$out/$group.normal.err" taskset -c 2 "$bin" --lanes 1 -c "${args[@]}" -o "$out/$group.normal.o"
 for mode in default base;do
  setenv=();period=1
  if [[ $mode == base ]];then setenv+=(BUSTER_HUGE_PAGES=0);period=8;fi
  prefix="$out/$group.$mode"
  ./lock.sh bash capture2850.sh "$prefix.out" "$prefix.err" taskset -c 2 perf record -q -m 1024 -e minor-faults:u -c "$period" -d --call-graph dwarf,3072 -o "$prefix.perf" -- env "${setenv[@]}" "$bin" --lanes 1 -c "${args[@]}" -o "$prefix.o"
  cmp "$out/$group.normal.o" "$prefix.o"
  cmp "$out/$group.normal.out" "$prefix.out"
  ./lock.sh bash -c 'perf script -i "$1.perf" -F comm,pid,tid,time,event,ip,sym,addr | gzip -1 >"$1.samples.gz"' _ "$prefix"
  sha256sum "$prefix.o" >"$prefix.sha256"
 done
done
echo COMPLETE
