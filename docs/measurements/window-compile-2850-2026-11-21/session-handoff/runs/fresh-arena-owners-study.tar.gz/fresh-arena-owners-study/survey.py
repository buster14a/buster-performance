from pathlib import Path
d=Path(__file__).resolve().parent
tree=d.parent/'fresh-arena-owners/src/buster/compiler'
p=tree/'lane.c';s=p.read_text();at=s.index('static void arena_pop_to(Arena* arena, uint64_t length)\n{',s.index('static void* arena_push_array(Arena* arena, uint64_t count, uint64_t element_bytes, uint64_t alignment)\n{'))
probe=r'''
// Diagnostic only. The records join actual tracked slices to anonymous resident page extents.
static void* arena_audit_slice(void* result, Arena* arena, uint64_t size, const char* file, int line)
{
    if (result != NULL && size >= 2048 && getenv("BUSTER_PAGE_OWNER_AUDIT") != NULL)
    {
        const char* name = strrchr(file,'/');
        name = name == NULL ? file : name + 1;
        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        fprintf(stderr, "alloc-site\t%lld.%09ld\t%lx\t%llu\t%lx\t%llu\t%llu\t%llu\t%s\t%d\n",
                (long long)now.tv_sec, now.tv_nsec, (unsigned long)result, (unsigned long long)size,
                (unsigned long)arena->base, (unsigned long long)arena->small,
                (unsigned long long)arena->capacity, (unsigned long long)arena->committed, name, line);
    }
    return result;
}
static void* arena_audit_push(Arena* arena, uint64_t size, uint64_t alignment, const char* file, int line)
{
    return arena_audit_slice(arena_push(arena,size,alignment),arena,size,file,line);
}
static void* arena_audit_array(Arena* arena, uint64_t count, uint64_t size, uint64_t alignment, const char* file, int line)
{
    return arena_audit_slice(arena_push_array(arena,count,size,alignment),arena,count*size,file,line);
}
#define arena_push(a,s,b) arena_audit_push((a),(s),(b),__FILE__,__LINE__)
#define arena_push_array(a,n,s,b) arena_audit_array((a),(n),(s),(b),__FILE__,__LINE__)

'''
s=s[:at]+probe+s[at:];p.write_text(s)
p=tree/'c_check_clock.c';s=p.read_text()
at=s.index('static void check_clock_mark(CheckClock* stage_clock, CheckStage stage)\n{')
probe=r'''
static void check_clock_page_owners(CheckStage stage)
{
    if (getenv("BUSTER_PAGE_OWNER_AUDIT") == NULL) return;
    const char* name=check_stage_names[stage];
    if (!(stage == CHECK_STAGE_PREPROCESS || stage == CHECK_STAGE_PARSE || stage == CHECK_STAGE_CHECK_INPUT ||
          stage == CHECK_STAGE_CHECK_EXPRESSIONS || stage == CHECK_STAGE_CHECK_PROGRAM || stage==CHECK_STAGE_OBJECT_BUILD)) return;
    FILE* maps=fopen("/proc/self/maps","r");
    if (maps == NULL) return;
    const int fd=open("/proc/self/pagemap",O_RDONLY);
    char line[1024];
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC,&now);
    fprintf(stderr,"owner-stage\t%lld.%09ld\t%s\n",(long long)now.tv_sec,now.tv_nsec,name);
    while (fd>=0 && fgets(line,sizeof(line),maps)!=NULL)
    {
        unsigned long begin=0,end=0;
        char perms[8]={0};
        if (sscanf(line,"%lx-%lx %7s",&begin,&end,perms)!=3 || perms[0]!='r' || perms[1]!='w') continue;
        LaneExitRegion ranges[256];
        while(begin<end)
        {
            LaneExitScan scan = { .size=sizeof(scan), .start=begin, .end=end, .vector=(uintptr_t)ranges,
                .vector_length=256, .category_mask=BUSTER_LANE_EXIT_PAGE_PRESENT, .return_mask=0x7fc };
            const long rc=syscall(SYS_ioctl,fd,BUSTER_LANE_EXIT_PAGEMAP_SCAN,&scan);
            if (rc<0) { fprintf(stderr,"owner-ioctl-error\t%s\t%lu\t%d\n",name,begin,errno); break; }
            for (long i=0;i<rc;i++)
                fprintf(stderr,"owner-page\t%s\t%lx\t%lx\t%lx\n",name,(unsigned long)ranges[i].start,(unsigned long)ranges[i].end,(unsigned long)ranges[i].categories);
            if (scan.walk_end<=begin) break;
            begin=scan.walk_end;
        }
    }
    if (fd>=0) close(fd);
    fclose(maps);
}
'''
s=s[:at]+probe+s[at:];s=s.replace('    check_clock_lap(stage_clock, stage);\n    if (stage_clock != NULL)\n    {\n        uint64_t system_us','    check_clock_lap(stage_clock, stage);\n    if (stage_clock != NULL)\n    {\n        check_clock_page_owners(stage);\n        uint64_t system_us',1);p.write_text(s)
