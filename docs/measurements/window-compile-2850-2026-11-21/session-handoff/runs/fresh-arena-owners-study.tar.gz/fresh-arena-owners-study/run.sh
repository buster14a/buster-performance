#!/bin/bash
set -eu
cd "$(dirname "$0")"
d=$PWD
python3 iterate.py >build.log 2>&1
cd ../switch-inputs
source ../switch-local-args.sh
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for unit in sqlite main;do
 variable=${unit}_arguments
 eval "args=(${!variable})"
 for arm in default base;do
  flags=()
  if [[ $arm == base ]];then flags+=(BUSTER_HUGE_PAGES=0);fi
  prefix="$d/$unit-$arm"
  env BUSTER_PAGE_OWNER_AUDIT=1 "${flags[@]}" "$d/compiler" --time-stages --lanes 1 -c "${args[@]}" -o "$prefix.o" >"$prefix.out" 2>"$prefix.audit"
  cmp "$prefix.o" "$d/../source-typed-study/$unit.o"
 done
done
