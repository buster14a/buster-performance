"""Attribute present private bytes at each observed marker to the most recently assigned containing slice."""
from collections import Counter,defaultdict
from pathlib import Path
import bisect,csv,heapq,sys
d=Path(__file__).resolve().parent
def write(name,header,rows):
 with (d/name).open('w',newline='') as f:
  w=csv.writer(f,delimiter='\t');w.writerow(header);w.writerows(rows)
def map_pages(slices,ranges):
 spans=[]
 arena={}
 for i,(start,size,base,capacity,site) in enumerate(slices):
  if size:
   spans.append((start,start+size,i,site))
  arena[base]=max(capacity,arena.get(base,0))
 # Group unowned padding with its arena's first large purpose. This is always a secondary attribution.
 first_owner={}
 for at,size,base,capacity,site in slices:
  first_owner.setdefault(base,site)
 for base,cap in arena.items():
  spans.append((base,base+cap,-2,'arena unused @ '+first_owner[base]))
 for index,(lo,hi,flags) in enumerate(ranges):
  spans.append((lo,hi,-1,''))
 points=set(); additions=defaultdict(list); resident={}
 for lo,hi,rank,site in spans:
  points.add(lo);points.add(hi)
  if rank!=-1:additions[lo].append((-rank,hi,site))
 for lo,hi,flags in ranges:resident[lo]=(hi,flags)
 ends=[]; active_end=0; cat=0; totals=Counter()
 prev=0
 for x in sorted(points):
  if prev<x and prev<active_end and cat&8:
   while ends and ends[0][1]<=prev:heapq.heappop(ends)
   site=ends[0][2] if ends else 'outside tracked arenas'
   page='file' if cat&4 else 'shared-zero' if cat&32 else 'huge-anon' if cat&64 else 'base-anon'
   totals[site,page]+=min(x,active_end)-prev
  if x in resident:active_end,cat=resident[x]
  for add in additions[x]:heapq.heappush(ends,add)
  while ends and ends[0][1]<=x:heapq.heappop(ends)
  prev=x
 return totals
def snapshot_file(path):
 # Finish the prior stage before collecting new allocations. Snapshots are contiguous in one-lane mode.
 raw=[]; slices=[];current=None;pages=[];occ=Counter();groups={};errs=Counter()
 for line in path.open(errors='replace'):
  f=line.rstrip('\n').split('\t');what=f[0]
  if current and what not in ('owner-page','owner-ioctl-error'):
   groups[current]=map_pages(slices,pages);current=None;pages=[]
  if what=='owner-stage':
   occ[f[2]]+=1;current=f[2]+'-'+str(occ[f[2]])
  elif what=='alloc-site':
   slices.append((int(f[2],16),int(f[3]),int(f[4],16),int(f[6]),f[8]+':'+f[9]))
  elif what=='owner-page':pages.append((int(f[2],16),int(f[3],16),int(f[4],16)))
  elif what=='owner-ioctl-error':errs[f[-1]]+=1
 if current:groups[current]=map_pages(slices,pages)
 return groups,errs
all_rows=[];stage_stats=[];delta=[]
for unit in ('sqlite','main'):
 arms={}
 for arm in ('default','base'):
  path=d/f'{unit}-{arm}.audit'
  if not path.exists():continue
  groups,errors=snapshot_file(path)
  if errors:raise ValueError((path,errors))
  for stage,c in groups.items():
   names={key[0] for key in c}
   for site in names:
    all_rows.append((unit,arm,stage,site,*(c[site,col] for col in ('huge-anon','base-anon','shared-zero','file'))))
   vals=[sum(v for (_,col),v in c.items() if col==k) for k in ('huge-anon','base-anon','shared-zero','file')]
   stage_stats.append((unit,arm,stage,*vals))
  arms[arm]=groups
 if len(arms)==2:
  for st in arms['default']:
   if st not in arms['base']:continue
   a,b=arms['default'][st],arms['base'][st]
   for site in {k[0] for k in list(a)+list(b)}:
    ah,ab=a[site,'huge-anon'],a[site,'base-anon']
    bh,bb=b[site,'huge-anon'],b[site,'base-anon']
    delta.append((unit,st,site,ah+ab,bh+bb,ah+ab-bh-bb,ah))
write('owners.tsv',['unit','policy','stage','source','huge-anonymous-bytes','base-anonymous-bytes','shared-zero-bytes','file-bytes'],sorted(all_rows))
write('residency.tsv',['unit','policy','stage','huge-anonymous-bytes','base-anonymous-bytes','shared-zero-bytes','file-bytes'],stage_stats)
write('page-deltas.tsv',['unit','stage','source','default-private','base-private','extra-default','default-huge'],sorted(delta,key=lambda v:(v[0],v[1],-v[5])))
