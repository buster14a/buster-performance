from pathlib import Path
import shlex,subprocess,sys
d=Path(__file__).resolve().parent; template=(d/'../main-typed-reserve-base').resolve(); target=(d/'../fresh-arena-owners').resolve(); b=(d/'../main-typed-reserve-base/build/cmake/native').resolve()
ref=d/'probe.o';exe=d/'compiler'; lib=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin')
ninja=(template/'build/cmake/native/CMakeFiles/impl-Release.ninja').read_text()
sec=ninja.split('build CMakeFiles/buster_main_unit_checker.dir/Release',1)[1].split('  FLAGS = ',1)[1].splitlines()[0]
flags=shlex.split(sec.replace(str(template),str(target)).replace('-Xclang -disable-llvm-passes -emit-llvm','').replace('-O3','-O0 -g1'))
subprocess.run([lib/'clang',*flags,'-c',target/'src/buster/compiler/main_unit_checker.c','-o',ref],check=True)
link=shlex.split(subprocess.check_output(['ninja','-f','build-Release.ninja','-t','commands','Release/compiler.link'],cwd=b,text=True).splitlines()[-1])
link=link[2:-2];link[link.index('Release/codegen/main_unit_checker/native.o')]=str(ref);link[link.index('Release/compiler.link')]=str(exe)
if any('clang' in e for e in link[:1]): link.insert(1,'-Wl,--threads=1')
subprocess.run(link,cwd=b,check=True)
