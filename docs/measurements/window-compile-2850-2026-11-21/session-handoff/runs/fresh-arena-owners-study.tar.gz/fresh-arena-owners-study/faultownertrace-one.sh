#!/bin/bash
set -eu
cd "$(dirname "$0")"
top=$PWD
source corpora.sh
main_arguments="-march=native -I$top/pooled-main-source/src -fwrapv -funsigned-char --predefines $top/proof-predefines.h $top/pooled-main-source/src/buster/compiler/main.c"
bin=$PWD/results/faultownertrace/compiler
out=$PWD/results/faultownertrace-audit
mkdir -p "$out"
for group in sqlite main;do
 opts=${group}_arguments
 eval "args=(${!opts})"
 for arm in default base huge;do
  flags=()
  if [[ $arm == base ]];then flags+=(BUSTER_HUGE_PAGES=0);elif [[ $arm == huge ]];then flags+=(BUSTER_HUGE_PAGES=1);fi
  prefix="$out/$group-$arm"
  ./lock.sh bash capture2850.sh "$prefix.out" "$prefix.audit" taskset -c 2 env BUSTER_PAGE_OWNER_AUDIT=1 "${flags[@]}" "$bin" --time-stages --lanes 1 -c "${args[@]}" -o "$prefix.o"
  cmp "$top/results/faultowners40ae/$group.normal.o" "$prefix.o"
  if grep -q '^owner-ioctl-error' "$prefix.audit";then echo "kernel pagemap refused";exit 1;fi
  grep -qm1 '^owner-page' "$prefix.audit"
  ./lock.sh gzip -1 -kf "$prefix.audit"
 done
done
echo COMPLETE
