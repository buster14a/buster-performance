#!/bin/bash
set -eu
cd "$(dirname "$0")"
out=$PWD/results/faultowners40ae
for group in sqlite main;do
 for arm in default base;do
  prefix=$out/$group.$arm
  ./lock.sh bash -e -o pipefail -c 'perf script -G --ns -i "$1.perf" -F comm,pid,tid,time,ip,sym,addr | gzip -1 > "$1.owners.gz"' _ "$prefix"
 done
done
echo COMPLETE
