extern int printf(const char*,...);extern int chosen(int);int one(int x){return x*3;}int other(int x){return x*5;}int main(void){printf("%d %d\n",chosen(2),chosen(7));return 0;}
