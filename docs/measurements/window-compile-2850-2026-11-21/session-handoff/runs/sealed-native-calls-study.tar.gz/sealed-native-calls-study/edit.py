from pathlib import Path
d=Path(__file__).resolve().parent.parent/'sealed-native-calls/src/buster/compiler'
def replace(a,b):
 global s
 assert s.count(a)==1, a
 s=s.replace(a,b)
p=d/'c_check_input.c';s=p.read_text()
replace('    bool seal_emitted;', '''    bool seal_emitted;
    uint32_t* seal_objects;
    uint32_t seal_symbols, seal_references;''');p.write_text(s)
p=d/'c_checker_driver.c';s=p.read_text()
replace('''            if (fragment && !body->references && !body->runtime_count && !body->table_count && !body->return_warning)
                fragment->seal_emitted = true;''','''            if (fragment && !body->runtime_count && !body->table_count && !body->return_warning && body->references <= body->symbols)
            {
                fragment->seal_objects = check_live_duplicate(state->storage, body->objects, (size_t)body->symbols * sizeof(uint32_t));
                fragment->seal_symbols = body->symbols;
                fragment->seal_references = body->references;
                fragment->seal_emitted = !body->symbols || fragment->seal_objects;
            }''')
p.write_text(s)
p=d/'c_check_program_emit.c';s=p.read_text()
replace('    TypeId type, query;\n    uint32_t declaration, object, initializer, begin, end;', '''    uint64_t callee_abi;
    TypeId type, query;
    uint32_t declaration, object, initializer, begin, end, callee_object;''')
# All other members total 40 bytes with callee_abi, plus 4 bytes at the end. Explicitly fill this
# otherwise unspecified struct padding, as comparisons are byte-exact.
replace('    uint8_t class, ignored, context, bits;', '    uint8_t class, ignored, context, bits;\n    uint32_t padding;')
pos='static bool check_seal_token('
replace(pos,'''static uint64_t check_seal_callee_abi(const TypeTable* types, TypeId type)
{
    if (!type || type_kind(types, type) != BUSTER_TYPE_KIND_FUNCTION || type_function_abi_kind(types, type) != TYPE_FUNCTION_ABI_SYSV ||
        type_function_keeps_registers(types, type) || type_function_has_parameter_abis(types, type) ||
        (types->types.flags[type_index(type)] & (BUSTER_TYPE_FLAG_PROTOTYPE | BUSTER_TYPE_FLAG_VARIADIC)) != BUSTER_TYPE_FLAG_PROTOTYPE) return 0;
    uint32_t count = 0;
    const TypeId* params = type_parameters(types, type, &count);
    if (count > 8) return 0;
    uint64_t key = (uint64_t)(count + 1) << 56;
    for (uint32_t i = 0; i <= count; i += 1)
    {
        const uint32_t value = check_seal_type(types, i ? params[i - 1] : type_return(types, type));
        const uint32_t base = value & UINT32_C(0x7fffffff);
        if (value == UINT32_MAX || base != type_unqualified(base) || type_index(base) > 31) return 0;
        key |= (uint64_t)(type_index(base) | (value >> 31) << 5) << (6 * i);
    }
    return key;
}

'''+pos)
replace('    if (!simple || role == PARSE_ROLE_OPEN_CALL || check_input_attributes_at(in, token)) return false;', '''    if (!simple || check_input_attributes_at(in, token)) return false;
    if (role == PARSE_ROLE_OPEN_CALL && (!token || p->tokens.kinds[token - 1] != PARSE_KIND_IDENTIFIER)) return false;''')
replace('    if (k == PARSE_KIND_IDENTIFIER && (declaration <= name', '''    const bool direct = k == PARSE_KIND_IDENTIFIER && token + 1 < in->token_count && p->tree.roles[token + 1] == PARSE_ROLE_OPEN_CALL;
    const uint64_t callee = direct ? check_seal_callee_abi(r->types, in->declared_types[token]) : 0;
    if (direct && (!callee || declaration >= name || !in->objects[declaration] ||
        check_input_bit(in->declaration_bits, declaration, BUSTER_CHECK_BITS_STATIC) && !in->function_flags ||
        (in->function_flags && (in->function_flags[declaration] & (CHECK_INPUT_FUNCTION_INLINE | CHECK_INPUT_FUNCTION_NAKED | CHECK_INPUT_FUNCTION_NORETURN))) ||
        check_input_attributes_at(in, declaration))) return false;
    if (k == PARSE_KIND_IDENTIFIER && !direct && (declaration <= name''')
# The final defined-object and attribute maps establish external linkage for each callee.
s=s.replace('        check_input_bit(in->declaration_bits, declaration, BUSTER_CHECK_BITS_STATIC) && !in->function_flags ||\n','')
replace('    *out = (CheckClosedToken){ .type = check_seal_type(r->types, in->declared_types[token]),','''    *out = (CheckClosedToken){ .callee_abi = callee, .callee_object = direct ? in->objects[declaration] : 0,
        .type = direct ? 0 : check_seal_type(r->types, in->declared_types[token]),''')
pos='    for (CheckClosedSeal* seal = state->seal_first; seal; seal = seal->next)'
replace(pos,'''    uint8_t* defined = BUSTER_ARENA_PUSH_ARRAY(r->scratch, uint8_t, (uint64_t)in->token_count + 1);
    if (!defined) return;
    memset(defined, 0, (size_t)in->token_count + 1);
    for (uint32_t i = 0; i < in->token_count; i += 1)
        if (r->parser->tree.roles[i] == PARSE_ROLE_OPEN_BODY)
        {
            const uint32_t decl = check_sparse_get(in->body_declarations, i);
            if (decl < in->token_count && in->objects[decl] <= in->token_count) defined[in->objects[decl]] = 1;
        }
'''+pos)
replace('!row->typed || row->references ||','!row->typed ||')
replace('        if (encoded->reference_count || key->shape.call_count || key->shape.table_count) continue;', '''        if (key->shape.table_count || in->objects[seal->name] > in->token_count) continue;
        bool matched = true;
        uint32_t calls = 0;
        for (uint32_t i = 0; i <= seal->closing - seal->opening; i += 1)
        {
            const uint32_t object = seal->tokens[i].callee_object;
            if (!object) continue;
            calls += 1;
            if (object > in->token_count || defined[object] || (attributed && attributed[object])) matched = false;
        }
        for (uint32_t slot = 0; matched && slot < row->seal_symbols; slot += 1)
        {
            const uint32_t object = row->seal_objects[slot];
            if (object > in->token_count) { matched = false; break; }
            if (slot >= row->seal_references && encoded->access[slot + 1] == UINT8_MAX) continue;
            bool found = false;
            for (uint32_t i = 0; !found && i <= seal->closing - seal->opening; i += 1) found = object && seal->tokens[i].callee_object == object;
            matched = found || (object == in->objects[seal->name] && slot >= row->seal_references);
        }
        for (uint32_t j = 0; matched && j < encoded->reference_count; j += 1)
        {
            const SymbolId target = encoded->references[j].target;
            matched = target && target <= row->seal_symbols;
        }
        if (!matched) continue;''')
replace('            .encoded = row->native }, r->arena)) return;', '''            .encoded = row->native, .objects = row->seal_objects, .symbols = row->seal_symbols, .references = row->seal_references }, r->arena)) return;''')
replace('"sealed-body-consumed\\t%u\\t%u\\t%u\\t%llu\\n", seal->opening, seal->closing,\n                                  key->shape.count,(unsigned long long)encoded->length);', '''"sealed-body-consumed\\t%u\\t%u\\t%u\\t%llu\\t%u\\t%u\\n", seal->opening, seal->closing,
                                  key->shape.count,(unsigned long long)encoded->length,calls,encoded->reference_count);''')
# Every pointer used before a bound check must be constrained by the current unit, as well as by the raw prefix.
replace('(attributed && attributed[in->objects[seal->name]]) ||', '(in->objects[seal->name] > in->token_count || (attributed && attributed[in->objects[seal->name]])) ||')
p.write_text(s)
