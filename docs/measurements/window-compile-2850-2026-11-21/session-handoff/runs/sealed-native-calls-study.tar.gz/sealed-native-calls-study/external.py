from pathlib import Path
import csv,hashlib,os,re,subprocess
d=Path(__file__).resolve().parent
w=d.parent
f=d/'external-control'
f.mkdir(exist_ok=True)
base=w/'default-integer-control/build/compiler'
candidate=d/'compiler'
clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
options={k:'1' for k in 'BUSTER_PARSE_LIVE_FOREST BUSTER_LIVE_CHECKED_INPUT BUSTER_PARSE_LIVE_AUDIT BUSTER_LIVE_ORDINARY_HANDOFF BUSTER_PRE_EOF_SEAL_BODIES BUSTER_PRE_EOF_NATIVE_WINDOW'.split()}
pads=''.join('extern int padding_%d;\n'%i+('#define NEXT_%d 1\n'%i if i%256==255 else '') for i in range(9200))
(f/'stub.c').write_text('extern int printf(const char*,...);extern int chosen(int);int one(int x){return x*3;}int other(int x){return x*5;}int main(void){printf("%d %d\\n",chosen(2),chosen(7));return 0;}\n')
subprocess.run([clang,'-c',f/'stub.c','-o',f/'stub.o'],check=True)
cases={
 'ordinary':('return one(x)+17;',''),
 'two-calls':('return other(x)+one(x);',''),
 'late-body':('return one(x)+17;','static int spare(int n){return n;}'),
 'rename':('return one(x)+17;','#pragma redefine_extname one other'),
 'weak':('return one(x)+17;','#pragma weak one'),
}
with (f/'results.tsv').open('w') as out:
 writer=csv.writer(out,delimiter='\t');writer.writerow(['case','compiler','return','object_sha256','before_eof_bodies','consumed_bodies','consumed_calls','runtime','runtime_stderr'])
 for case,(body,tail) in cases.items():
  src=f/(case+'.c');src.write_text('extern int one(int);extern int other(int);int chosen(int x){'+body+'}\n'+pads+tail+'\n')
  runs={}
  for label,compiler,options2 in [('ordinary',base,{}),('source',candidate,options),('clang',clang,{})]:
   stem=f/(case+'-'+label);obj=stem.with_suffix('.o')
   r=subprocess.run([compiler,*([] if label=='clang' else ['--lanes','1']),'-c',src,'-o',obj],capture_output=True,env=os.environ|options2)
   (f/(stem.name+'.stderr')).write_bytes(r.stderr);assert r.returncode==0 and obj.exists(),(case,label)
   link=subprocess.run([clang,'-no-pie',f/'stub.o',obj,'-o',stem],capture_output=True);assert link.returncode==0,link.stderr
   run=subprocess.run([stem],capture_output=True)
   events=[s.split('\t') for s in r.stderr.decode().splitlines() if s.startswith('sealed-body-consumed')]
   pref=re.search(rb'pre-eof-native-prefix\trows=(\d+)',r.stderr)
   runs[label]=(obj.read_bytes(),run.stdout,run.stderr,run.returncode,events)
   writer.writerow([case,label,r.returncode,hashlib.sha256(runs[label][0]).hexdigest(),bool(pref),len(events),sum(int(x[5]) for x in events),run.stdout.decode().strip(),run.stderr.decode()]);out.flush()
  assert runs['ordinary'][:4]==runs['source'][:4],case
  if case!='rename':assert runs['source'][1:4]==runs['clang'][1:4],case
  if case in ('ordinary','two-calls'):
   assert len(runs['source'][4])==1 and sum(int(x[5]) for x in runs['source'][4])==(2 if case=='two-calls' else 1),(case,runs['source'][4])
  if case in ('weak','rename'):assert not runs['source'][4],case
