from pathlib import Path
root=Path(__file__).resolve().parent/'../pp-member-owner-fix/src/buster/compiler'
p=root/'c_checker_driver.c';s=p.read_text().replace('.source_member_views = getenv("BUSTER_CONNECTED_MEMBER_VIEWS") != NULL', '''.source_member_views = getenv("BUSTER_CONNECTED_MEMBER_VIEWS") != NULL && getenv("BUSTER_CONTROL_SOURCE_NATIVE") != NULL &&
                                  getenv("BUSTER_SOURCE_PHYSICAL_MEMBERS") != NULL && !source_rows''');p.write_text(s)
p=root/'c_parser_impl.c';s=p.read_text().replace('''            if(!(body && role==PARSE_ROLE_MEMBER && parser->tree.roles[t-1]==PARSE_ROLE_MEMBER_OPERATOR))''','''            // Included-file copies already received a canonical ID in ordinary file preparation.
            // Only a truly uninterned name from this primary producer can gain a first identity here.
            const bool primary=plan->primary && pp_find_range(pp,pp->output.locations[row])==plan->range;
            if(!(primary && body && role==PARSE_ROLE_MEMBER && parser->tree.roles[t-1]==PARSE_ROLE_MEMBER_OPERATOR))''');p.write_text(s)
p=root/'c_check_input.c';s=p.read_text();k='static void check_input_expressions(CheckInputReader* reader)\n{';i=s.index(k);s=s[:i]+'''// Return unresolved member spellings to the ordinary owner before it builds a graph for this region.
static void check_materialize_source_selectors(CheckInputReader* reader,uint32_t begin,uint32_t end)
{
    PPNameViews* plan=reader->pp?reader->pp->name_views:NULL;
    if(!plan || !plan->selector_count || begin>=end)return;
    const ParseTokens* tokens=&reader->parser->tokens;
    uint32_t first=0,stop=plan->selector_count;
    while(first<stop)
    {
        const uint32_t m=first+(stop-first)/2;
        if(plan->selectors[m].parser_token<begin)first=m+1;else stop=m;
    }
    for(uint32_t i=first;i<plan->selector_count && plan->selectors[i].parser_token<end;i++)
    {
        PPBorrowedSelector* field=plan->selectors+i;
        const uint32_t t=field->parser_token;
        if(t>=tokens->count || tokens->names[t] || parse_source_index(tokens,t)!=field->row)continue;
        const IdentId id=field->declaration?field->declaration:intern_find_or_add(reader->pp->table,field->bytes,field->length);
        if(!id){reader->output->resource=true;return;}
        tokens->names[t]=id;
        if(!reader->pp->output_released)reader->pp->output.values[field->row]=id;
    }
}

'''+s[i:]
s=s.replace('''    if (getenv("BUSTER_CHECK_BODY_SOURCE_ONLY") != NULL)
    {
        check_body_source_run(reader);''','''    check_materialize_source_selectors(reader,0,reader->parser->tokens.count);
    if (getenv("BUSTER_CHECK_BODY_SOURCE_ONLY") != NULL)
    {
        check_body_source_run(reader);''');p.write_text(s)
p=root/'c_check_body_source.c';s=p.read_text().replace('''        bool done=false;
        if (parser->tree.roles[t]==PARSE_ROLE_CLOSE_BODY)''','''        bool done=false;
        uint32_t source_begin=t;
        if (parser->tree.roles[t]==PARSE_ROLE_CLOSE_BODY)''').replace('''            bool shape = open != 0 && getenv("BUSTER_CONTROL_SKIP_TRIAL") == NULL;''','''            source_begin=open;
            bool shape = open != 0 && getenv("BUSTER_CONTROL_SKIP_TRIAL") == NULL;''').replace('''        if (!done) check_input_expressions_coded_range(reader,begin,i+1);''','''        if (!done)
        {
            check_materialize_source_selectors(reader,source_begin,t+1);
            check_input_expressions_coded_range(reader,begin,i+1);
        }''');p.write_text(s)
