from pathlib import Path
import subprocess,os,sys
d=Path(__file__).resolve().parent
t=d/'declined-fixture';t.mkdir(exist_ok=True)
if not (t/'nested.c').exists():subprocess.run([sys.executable,d/'edges.py',t],check=True)
for label,root,extra in [(a,b,c) for a,b,c in [('ordinary','indexed-local',{}),('unfixed','indexed-local',{'BUSTER_CONTROL_SKIP_TRIAL':'1'}),('fixed','owner-local',{'BUSTER_CONTROL_SKIP_TRIAL':'1'})] if (d/b/'compiler').exists()]:
 env=dict(os.environ)
 if label!='ordinary':env.update(BUSTER_CONTROL_SOURCE_NATIVE='1',BUSTER_CONTROL_EARLY_NATIVE='1',BUSTER_CONTROL_EARLY_RELEASE='1',BUSTER_EXPERIMENT_PP_SOURCE_NAMES='1',BUSTER_SOURCE_PHYSICAL_MEMBERS='1',BUSTER_CONNECTED_MEMBER_VIEWS='1',**extra)
 r=subprocess.run([d/root/'compiler','-c','-std=gnu17',t/'nested.c','-o',t/(label+'.o')],env=env,capture_output=True)
 print(label,'status',r.returncode,'blank field diagnostics',r.stderr.count(b"no member named ''"))
 (t/(label+'.rc')).write_text(str(r.returncode)+'\n');(t/(label+'.err')).write_bytes(r.stderr);(t/(label+'.out')).write_bytes(r.stdout)
 if label=='ordinary':assert r.returncode==0
 if label=='unfixed':assert r.returncode!=0 and b"no member named ''" in r.stderr
 if label=='fixed':assert r.returncode==0 and (t/'fixed.o').read_bytes()==(t/'ordinary.o').read_bytes() and r.stderr==(t/'ordinary.err').read_bytes()
