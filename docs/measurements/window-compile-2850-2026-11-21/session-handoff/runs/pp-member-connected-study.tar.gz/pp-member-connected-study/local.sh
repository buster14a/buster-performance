#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;out=$d/$2
python local.py "$1" "$2"
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
for mode in ordinary connected;do
 vars=();[[ $mode != connected ]] || vars=(BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1 BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONNECTED_MEMBER_VIEWS=1 BUSTER_SOURCE_PHYSICAL_MEMBER_LOG="$out/semantic.tsv")
 env "${vars[@]}" "$out/compiler" --lanes 1 -c "${args[@]}" -o "$out/$mode.o" >"$out/$mode.out" 2>"$out/$mode.err"
done
for ext in out err o;do cmp "$out/ordinary.$ext" "$out/connected.$ext";done
cmp "$out/connected.o" "$d/../source-typed-study/sqlite.o"
cd "$d";python check-result.py "$out/semantic.tsv"
