#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;v=$1;out=$root/results/physical-member-edges-$v
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
for c in nested mapped const unknown incomplete nonrecord;do
 f=$out/$c.clang-pinned
 ./lock.sh taskset -c 2 bash -c 'f=$1;shift;set +e;"$@" >"$f.out" 2>"$f.err";echo $? >"$f.rc"' _ "$f" env PATH="$paths:$PATH" clang -std=gnu17 -c "$out/$c.c" -o "$f.o" >"$f.lease" 2>&1
done
for c in nested mapped const unknown incomplete nonrecord;do
 for n in {1..900};do test ! -f "$out/$c.connected.rc" || break;sleep 2;done
 same=yes
 for ext in rc err out;do cmp -s "$out/$c.original.$ext" "$out/$c.connected.$ext" || same=no;done
 cmp -s "$out/$c.original.rc" "$out/$c.clang-pinned.rc" || same=no
 if [[ $(cat "$out/$c.original.rc") == 0 ]];then cmp -s "$out/$c.original.o" "$out/$c.connected.o" || same=no;fi
 n=0;[[ ! -f "$out/$c.semantic.tsv" ]] || n=$(wc -l <"$out/$c.semantic.tsv")
 printf '%s match=%s original=%s connected=%s clang=%s actual-physical-queries=%s\n' "$c" "$same" "$(cat "$out/$c.original.rc")" "$(cat "$out/$c.connected.rc")" "$(cat "$out/$c.clang-pinned.rc")" "$n" >>"$out/oracle"
done
