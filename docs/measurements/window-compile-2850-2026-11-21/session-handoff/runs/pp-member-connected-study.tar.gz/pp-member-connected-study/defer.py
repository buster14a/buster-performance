from pathlib import Path
root=Path(__file__).resolve().parent/'../pp-member-final-demand/src/buster/compiler'
p=root/'c_preprocessor.c';s=p.read_text().replace('    uint32_t length;\n} PPBorrowedSelector;', '    uint32_t length;\n    uint32_t parser_token;\n    uint32_t declaration;\n} PPBorrowedSelector;');p.write_text(s)
p=root/'c_parser_impl.c';s=p.read_text().replace('''        plan->selector_count=0;
        for(uint32_t t=1;''','''        plan->selector_count=0;
        uint32_t body=0;
        for(uint32_t t=1;''')
s=s.replace('''            const uint8_t* spelling;uint32_t length;
            if(!pp_span_spelling(pp,row,&spelling,&length))continue;''','''            const uint8_t role=parser->tree.roles[t];
            if(role==PARSE_ROLE_OPEN_BODY)body++;
            if(role==PARSE_ROLE_CLOSE_BODY && body)body--;
            const uint8_t* spelling;uint32_t length;
            if(!pp_span_spelling(pp,row,&spelling,&length))continue;''')
s=s.replace('(PPBorrowedSelector){spelling,row,length}', '(PPBorrowedSelector){spelling,row,length,t,0}').replace('if(!parse_demand_member(parser,pp,t))return false;', '''if(!(body && role==PARSE_ROLE_MEMBER && parser->tree.roles[t-1]==PARSE_ROLE_MEMBER_OPERATOR))
                if(!parse_demand_member(parser,pp,t))return false;''');p.write_text(s)
p=root/'c_check_body_source.c';s=p.read_text();i=s.index('static bool check_member_physical(');j=s.index('static uint32_t check_member_spelling(',i)
s=s[:i]+'''static PPBorrowedSelector* check_selector(uint32_t row)
{
    PPNameViews* plan=check_member_source_pp->name_views;
    if(!plan)return NULL;
    uint32_t lo=0,hi=plan->selector_count;
    while(lo<hi)
    {
        const uint32_t m=lo+(hi-lo)/2;
        if(plan->selectors[m].row<row)lo=m+1;
        else hi=m;
    }
    if(lo==plan->selector_count || plan->selectors[lo].row!=row)return NULL;
    return plan->selectors+lo;
}

static bool check_member_physical(uint32_t row,const uint8_t** spelling,uint32_t* length)
{
    PPBorrowedSelector* selector=check_selector(row);
    if(!selector)return false;
    *spelling=selector->bytes;*length=selector->length;
    return true;
}

static IdentId check_selector_identity(const CheckInputReader* reader,PPBorrowedSelector* selector)
{
    const uint32_t token=selector->parser_token,row=selector->row;
    const IdentId id=selector->declaration?selector->declaration:
        intern_find_or_add(reader->pp->table,selector->bytes,selector->length);
    reader->parser->tokens.names[token]=id;
    if(!reader->pp->output_released)reader->pp->output.values[row]=id;
    return id;
}

'''+s[j:]
s=s.replace('    if(check_member_source_log)\n        fprintf(','''    if(member)check_selector(row)->declaration=types->members.name[member];
    if(check_member_source_log)
        fprintf(''')
s=s.replace('''        fprintf(stderr,"body-source-decline\\tclose=%u\\tstatus=%u\\tnode=%u\\n",close,stream.status,stream.failed_node);''','''        if(physical)
        {
            PPNameViews* plan=reader.pp->name_views;
            if(plan)for(uint32_t i=0;i<plan->selector_count;i++)check_selector_identity(&reader,&plan->selectors[i]);
            type_source_member=NULL;
            check_member_source_pp=NULL;
            if(check_member_source_log)fclose(check_member_source_log);
            check_member_source_log=NULL;
        }
        fprintf(stderr,"body-source-decline\\tclose=%u\\tstatus=%u\\tnode=%u\\n",close,stream.status,stream.failed_node);''')
s=s.replace('''                input.graph.members[n]=reader.parser->tokens.names[input.graph.tokens[n]+1];''','''                input.graph.members[n]=check_selector_identity(&reader,check_selector(input.graph.members[n]&~CHECK_SOURCE_NAME_ROW));''')
p.write_text(s)
