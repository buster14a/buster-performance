from pathlib import Path
root=Path(__file__).resolve().parent/'../pp-member-rank/src/buster/compiler'
p=root/'c_preprocessor.c';s=p.read_text().replace('    PPBorrowedSelector* selectors;','''    PPBorrowedSelector* selectors;
    uint64_t* selector_bits;
    uint32_t* selector_rank;
    uint32_t selector_words;''');p.write_text(s)
p=root/'c_parser_impl.c';s=p.read_text().replace('''        if(!plan->selectors)return false;
        plan->selector_count=0;''','''        plan->selector_words=(pp->output.count+63u)/64u;
        plan->selector_bits=BUSTER_ARENA_PUSH_ARRAY(&pp->arena,uint64_t,plan->selector_words+1);
        plan->selector_rank=BUSTER_ARENA_PUSH_ARRAY(&pp->arena,uint32_t,plan->selector_words+1);
        if(!plan->selectors || !plan->selector_bits || !plan->selector_rank)return false;
        memset(plan->selector_bits,0,(uint64_t)plan->selector_words*8);
        plan->selector_count=0;''').replace('''            plan->selectors[plan->selector_count++]=(PPBorrowedSelector){spelling,row,length,t,0};''','''            plan->selectors[plan->selector_count++]=(PPBorrowedSelector){spelling,row,length,t,0};
            plan->selector_bits[row>>6]|=UINT64_C(1)<<(row&63);
''')
text='''                if(!parse_demand_member(parser,pp,t))return false;
        }
''';assert s.count(text)==1;s=s.replace(text,text+'''        uint32_t rank=0;
        for(uint32_t w=0;w<plan->selector_words;w++)
        {
            plan->selector_rank[w]=rank;
            rank+=(uint32_t)__builtin_popcountll(plan->selector_bits[w]);
        }
        if(rank!=plan->selector_count)return false;
''');p.write_text(s)
p=root/'c_check_body_source.c';s=p.read_text();lo=s.index('    if(!plan)return NULL;');hi=s.index('\n}',lo)
s=s[:lo]+'''    const uint32_t word=row>>6;
    if(!plan || word>=plan->selector_words)return NULL;
    const uint64_t mask=UINT64_C(1)<<(row&63);
    const uint64_t bits=plan->selector_bits[word];
    if(!(bits&mask))return NULL;
    const uint32_t ordinal=plan->selector_rank[word]+(uint32_t)__builtin_popcountll(bits&(mask-1));
    return plan->selectors+ordinal;'''+s[hi:]
p.write_text(s)
