from pathlib import Path
import hashlib,re,shutil,subprocess,tarfile
d=Path(__file__).resolve().parent; pp=d.parent/'pp-structural-study';r=pp/'stable/connected';r.mkdir(exist_ok=True)
for n in ['source','reproduce','receipts']:(r/n).mkdir(exist_ok=True)
for tree,base,fn in [('pp-name-replay','0e1d5b825','replay'),('pp-member-connected','0e1d5b825','connected'),('pp-member-final-demand','0e1d5b825','field-first'),('pp-member-physical-check','a07469363','physical')]:
 repo=d.parent/tree
 h=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
 with (r/'source'/(fn+'.patch')).open('wb') as f:subprocess.run(['git','diff',base,h],cwd=repo,stdout=f,check=True)
for f in ['target.sh','edges.sh','edges.py','edge-oracle.sh','times.sh','summarize.py','check-result.py','parser-roles.py']:
 shutil.copy2(d/f,r/'reproduce'/f)
for f in ['monolithic-object.sh','replay-target.sh','replay-edge-target.sh','replay-early-fixed.sh','make-replay-cases.py']:
 shutil.copy2(pp/f,r/'reproduce'/f)
for f in ['qualifications.txt','edge-qualification.txt','parser-roles.txt','v1-default.txt']:
 shutil.copy2(d/f,r/'receipts'/f)
for f in ['verified','capture.log']:
 shutil.copy2(d.parent/'pp-member-physical-study'/f,r/'receipts'/('physical-'+f))
def archive(label,*groups):
 with tarfile.open(r/'receipts'/label,'w:gz',compresslevel=1) as z:
  for root,prefix,skip in groups:
   for p in sorted(root.iterdir()):
    if p.is_file() and not skip(p):z.add(p,prefix+'/'+p.name)
none=lambda p:False
archive('connected-runs.tar.gz',(d/'native-v1','v1',none),(d/'native-v2','v2',none),(d/'times-v2','wall',none))
archive('diagnostic-cases.tar.gz',(d/'edges-v1','v1',lambda p:p.suffix=='.c'),(d/'edges-v2','v2',lambda p:p.suffix=='.c'))
archive('warning-replay.tar.gz',(pp/'structural-single-replay-edges-v3','before',lambda p:p.suffix=='.c'),(pp/'structural-single-replay-edges-v8','fixed',lambda p:p.suffix=='.c'),(pp/'structural-single-replay-fixed-proof','same-source',none),(pp/'structural-single-source-names-v8','preflight',none),(pp/'structural-single-object-v8','objects',lambda p:p.suffix=='.o' and p.name not in ('basic-default.o','extended-default.o')))
archive('ordinary-pp-physical-check.tar.gz',(d.parent/'pp-member-physical-study','consumer',lambda p:p.name not in ['check.py','semantic.tsv','capture.log','capture.sh','run.sh','iterate.py','verified']))
