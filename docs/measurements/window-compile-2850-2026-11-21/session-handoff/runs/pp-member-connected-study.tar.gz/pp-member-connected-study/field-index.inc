// A per-translation-unit dictionary populated solely by declarations in the current
// TypeTable. Uses have physical spellings; lookup never interns an unknown field.
typedef struct CheckPhysicalFieldDictionary
{
    const TypeTable* owner;
    const uint32_t* member_names;
    uint32_t seen;
    uint32_t capacity;
    uint32_t* slots;
} CheckPhysicalFieldDictionary;

static uint32_t check_field_hash(const uint8_t* bytes,uint32_t n)
{
    uint32_t a=0,b=0;
    if(n>=4){memcpy(&a,bytes,4);memcpy(&b,bytes+n-4,4);}
    else for(uint32_t i=0;i<n;i++)a|=(uint32_t)bytes[i]<<(8*i);
    return _mm_crc32_u32(_mm_crc32_u32(n,a),b)*2654435761u;
}

static CheckPhysicalFieldDictionary* check_field_dictionary(const TypeTable* types)
{
    Preprocessor* pp=(Preprocessor*)check_member_source_pp;
    PPNameViews* plan=pp->name_views;
    CheckPhysicalFieldDictionary* fields=plan->field_dictionary;
    if(!fields)
    {
        fields=BUSTER_ARENA_PUSH_ARRAY(&pp->arena,CheckPhysicalFieldDictionary,1);
        if(!fields)return NULL;
        *fields=(CheckPhysicalFieldDictionary){0};
        plan->field_dictionary=fields;
    }
    const uint32_t count=types->members.count;
    if(fields->owner!=types || fields->member_names!=types->members.name || count<fields->seen ||
       (uint64_t)count*2>fields->capacity)
    {
        if(count>=(UINT32_C(1)<<29))return NULL;
        uint32_t capacity=32;
        while(capacity<count*2)capacity*=2;
        fields->slots=BUSTER_ARENA_PUSH_ARRAY(&pp->arena,uint32_t,capacity);
        if(!fields->slots)return NULL;
        memset(fields->slots,0,(size_t)capacity*sizeof(uint32_t));
        fields->capacity=capacity;fields->owner=types;fields->member_names=types->members.name;fields->seen=1;
    }
    for(;fields->seen<count;fields->seen++)
    {
        const IdentId id=types->members.name[fields->seen];
        if(!id)continue;
        const uint32_t len=intern_length(pp->table,id);
        uint32_t i=check_field_hash(intern_bytes(pp->table,id),len)&(fields->capacity-1);
        while(fields->slots[i] && fields->slots[i]!=id)i=(i+1)&(fields->capacity-1);
        fields->slots[i]=id;
    }
    return fields;
}

static uint32_t check_declared_field(const TypeTable* types,TypeId record,const uint8_t* spelling,uint32_t length,uint64_t* offset,uint32_t* qualifiers)
{
    const InternTable* table=check_member_source_pp->table;
    const CheckPhysicalFieldDictionary* fields=check_field_dictionary(types);
    if(!fields)return check_member_spelling(types,record,spelling,length,offset,qualifiers,0);
    uint32_t i=check_field_hash(spelling,length)&(fields->capacity-1);
    while(fields->slots[i])
    {
        const IdentId id=fields->slots[i];
        if(intern_length(table,id)==length && memcmp(intern_bytes(table,id),spelling,length)==0)
        {
            const uint32_t member=type_lookup_member(types,record,id,offset,qualifiers);
            if(member && member!=BUSTER_TYPE_MEMBER_UNKNOWN)return member;
            break;
        }
        i=(i+1)&(fields->capacity-1);
    }
    // A rolled-back local record may reuse an old slot before a larger member
    // count is observed. A lexical miss still searches the current declarations.
    return check_member_spelling(types,record,spelling,length,offset,qualifiers,0);
}
