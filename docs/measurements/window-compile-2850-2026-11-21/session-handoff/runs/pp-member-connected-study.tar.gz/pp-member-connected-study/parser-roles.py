from pathlib import Path
import csv,struct,re
d=Path(__file__).resolve().parent
src=(d/'../pp-member-connected/src/buster/compiler/c_parser.c').read_text()
roles=re.findall(r'^\s*X\((\w+),',src.split('#define BUSTER_PARSE_ROLES(X)',1)[1].split('typedef enum ParseRole',1)[0],re.M)
tree=(d/'../pp-structural-study/span.replayed.tree').read_bytes()
n,=struct.unpack('<I',tree[:4]);r=tree[4+n:4+2*n]
assert len(tree)==4+10*n
with (d/'../pp-structural-study/structural-single-member-census/members.tsv').open() as f: named={int(x['parser-token']) for x in csv.DictReader(f,delimiter='\t')}
from collections import Counter
counts=Counter();depth=0
for i in range(1,n):
 role=roles[r[i]]
 if role=='OPEN_BODY':depth+=1
 if role=='CLOSE_BODY' and depth:depth-=1
 if i in named:counts[(depth>0,role,roles[r[i-1]])]+=1
print(n,len(named),counts)
