from pathlib import Path
from collections import Counter,defaultdict
from statistics import median
root=Path(__file__).resolve().parent
def load(p):return {a[0]:a for a in (x.split('\t') for x in p.read_text().splitlines())}
a=load(root/'native-v1/default.semantic.tsv');b=load(root/'native-v2/default.semantic.tsv')
expected=set(a);assert expected==set(b)
maps=defaultdict(set);inverse=defaultdict(set);bad=Counter()
for row in a:
 bad[tuple(i for i in range(1,6) if a[row][i]!=b[row][i])]+=1
 maps[a[row][1]].add(b[row][1]);inverse[b[row][1]].add(a[row][1])
assert set(bad)<={(),(1,)} and all(len(v)==1 for v in maps.values()) and all(len(v)==1 for v in inverse.values())
print('v2 accesses',len(b),'all exact spelling/slot/offset/inherited qualifiers; numeric record equal',bad[()],'renumbered',bad[(1,)],'different record ids',sum({k}!=v for k,v in maps.items()),'all observed record ids',len(maps),'bijection both ways')
for p,arms in [(root/'times-v2',['ordinary','native','connected']),(root/'../pp-structural-study/structural-single-object-v8',['baseline','source'])]:
 for arm in arms:
  entries=sorted(p.glob('*-'+arm+'.time'));times=[int(f.read_text()) for f in entries]
  print(p.name,arm,'fresh processes',len(times),'median milliseconds',round(median(times)/1e6,6),'raw ns',*times)
