#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2
root=$PWD
label=${1:-v1};tree=$root/trees/physical-member-$label;out=$root/results/physical-member-$label
mkdir -p "$out"
if [[ ! -d $tree ]];then git -C src worktree add -q --detach "$tree" 0e1d5b825;git -C "$tree" apply "$root/pp-member-connected/$label.patch";fi
./lock.sh bash -c 'cd "$1" && ./build.sh --config Release' _ "$tree" >"$out/build" 2>&1
source corpora.sh;eval "args=($sqlite_arguments)"
cc=$tree/build/compiler
lock() { ./lock.sh taskset -c 2 "$@"; }
for mode in default max;do
 warnings=();[[ $mode != max ]] || warnings=(-Weverything)
 for arm in ordinary producer-connected;do
  vars=();[[ $arm != producer-connected ]] || vars=(BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1 BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONNECTED_MEMBER_VIEWS=1 BUSTER_SOURCE_PHYSICAL_MEMBER_LOG="$out/$mode.semantic.tsv")
  stem=$out/$mode-$arm
  lock bash -c 'stem=$1;shift;exec "$@" >"$stem.out" 2>"$stem.err"' _ "$stem" env "${vars[@]}" "$cc" --lanes 1 -c "${args[@]}" "${warnings[@]}" -o "$stem.o" >"$stem.lease" 2>&1
 done
 for kind in out err o;do cmp "$out/$mode-ordinary.$kind" "$out/$mode-producer-connected.$kind"; done
done
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
lock env PATH="$paths:$PATH" clang -no-pie "$root/results/active-source-native-oracles/driver.o" "$out/default-producer-connected.o" -lm -ldl -lpthread -o "$out/sql" >"$out/link.lease" 2>&1
lock bash -c 'exec "$1" >"$2" 2>"$3"' _ "$out/sql" "$out/sql.out" "$out/sql.err" >"$out/sql.lease" 2>&1
cmp "$out/sql.out" "$root/results/active-source-native-oracles/clang.sql"
cmp "$out/sql.err" "$root/results/active-source-native-oracles/clang.sqlerr"
(cd "$out" && sha256sum *.o *.semantic.tsv sql.out sql.err >hashes)
