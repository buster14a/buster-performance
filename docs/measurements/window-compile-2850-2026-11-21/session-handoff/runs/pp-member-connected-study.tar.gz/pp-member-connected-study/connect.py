from pathlib import Path
root=Path(__file__).resolve().parent/'../pp-member-connected/src/buster/compiler'
p=root/'c_preprocessor.c';s=p.read_text().replace('typedef struct PPNameViews\n{','''typedef struct PPBorrowedSelector
{
    const uint8_t* bytes;
    uint32_t row;
    uint32_t length;
} PPBorrowedSelector;
typedef struct PPNameViews
{
    PPBorrowedSelector* selectors;
    uint32_t selector_count;''');p.write_text(s)
p=root/'c_parser_impl.c';s=p.read_text();pos=s.index('    if(parser->options.source_member_views && (!result')
s=s[:pos]+'''    if(result && parser->options.source_member_views && pp->name_views && !parser->diagnostic_count && getenv("BUSTER_CONNECTED_MEMBER_VIEWS"))
    {
        uint32_t count=0;
        for(uint32_t t=1;t<parser->tokens.count;t++)
        {
            const uint32_t row=parse_source_index(&parser->tokens,t);
            if(pp->output.kinds[row]==C_TOKEN_RAW_IDENTIFIER && (pp->output.values[row]&BUSTER_SOURCE_NAME))count++;
        }
        PPNameViews* plan=pp->name_views;
        plan->selectors=BUSTER_ARENA_PUSH_ARRAY(&pp->arena,PPBorrowedSelector,count+1);
        if(!plan->selectors)return false;
        plan->selector_count=0;
        for(uint32_t t=1;t<parser->tokens.count;t++)
        {
            const uint32_t row=parse_source_index(&parser->tokens,t);
            const uint8_t* spelling;uint32_t length;
            if(!pp_span_spelling(pp,row,&spelling,&length))continue;
            if(plan->selector_count && plan->selectors[plan->selector_count-1].row>=row)return false;
            plan->selectors[plan->selector_count++]=(PPBorrowedSelector){spelling,row,length};
            // Legacy consumers still receive an ID. The real body member action receives only the
            // physical spelling issued above and its resolved left operand's record type.
            if(!parse_demand_member(parser,pp,t))return false;
        }
    }
'''+s[pos:];p.write_text(s)
p=root/'c_checker_driver.c';s=p.read_text().replace('const ParseOptions parser_options = { .scalar = scalar, .tree_only = true, .scratch = scratch };','const ParseOptions parser_options = { .scalar = scalar, .tree_only = true, .scratch = scratch, .source_member_views = getenv("BUSTER_CONNECTED_MEMBER_VIEWS") != NULL };');p.write_text(s)
p=root/'c_check_body_source.c';s=p.read_text();i=s.index('static bool check_member_ascii(');j=s.index('static uint32_t check_member_spelling(',i)
s=s[:i]+'''static bool check_member_physical(uint32_t row,const uint8_t** spelling,uint32_t* length)
{
    const PPNameViews* plan=check_member_source_pp->name_views;
    if(!plan)return false;
    uint32_t lo=0,hi=plan->selector_count;
    while(lo<hi)
    {
        const uint32_t m=lo+(hi-lo)/2;
        if(plan->selectors[m].row<row)lo=m+1;
        else hi=m;
    }
    if(lo==plan->selector_count || plan->selectors[lo].row!=row)return false;
    *spelling=plan->selectors[lo].bytes;*length=plan->selectors[lo].length;
    return true;
}

'''+s[j:];p.write_text(s)
