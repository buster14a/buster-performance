#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;version=$1
cc=$root/trees/physical-member-$version/build/compiler
test -x "$cc"
out=$root/results/physical-member-edges-$version;mkdir -p "$out"
python3 pp-member-connected/edges.py "$out"
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage);clang=clang
for c in nested mapped const unknown incomplete nonrecord;do
 for a in original connected clang;do
  exe=$cc;vars=()
  if [[ $a == connected ]];then vars=(BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1 BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONNECTED_MEMBER_VIEWS=1 BUSTER_SOURCE_PHYSICAL_MEMBER_LOG="$out/$c.semantic.tsv");fi
  if [[ $a == clang ]];then exe=$clang;vars=(PATH="$paths:$PATH");fi
  f=$out/$c.$a
  ./lock.sh taskset -c 2 bash -c 'f=$1;shift;set +e;"$@" >"$f.out" 2>"$f.err";echo $? >"$f.rc"' _ "$f" env "${vars[@]}" "$exe" -std=gnu17 -c "$out/$c.c" -o "$f.o" >"$f.lease" 2>&1
 done
 same=yes
 for ext in rc err out;do cmp -s "$out/$c.original.$ext" "$out/$c.connected.$ext" || same=no;done
 cmp -s "$out/$c.original.rc" "$out/$c.clang.rc" || same=no
 if [[ $(cat "$out/$c.original.rc") == 0 ]];then cmp -s "$out/$c.original.o" "$out/$c.connected.o" || same=no;fi
 n=0;[[ ! -f "$out/$c.semantic.tsv" ]] || n=$(wc -l <"$out/$c.semantic.tsv")
 printf '%s match=%s original=%s connected=%s clang=%s actual-physical-queries=%s\n' "$c" "$same" "$(cat "$out/$c.original.rc")" "$(cat "$out/$c.connected.rc")" "$(cat "$out/$c.clang.rc")" "$n" >>"$out/results"
done
