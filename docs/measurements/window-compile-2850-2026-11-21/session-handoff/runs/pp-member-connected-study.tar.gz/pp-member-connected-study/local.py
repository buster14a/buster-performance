from pathlib import Path
import shlex,subprocess,sys
d=Path(__file__).resolve().parent;template=d.parent/'body-source-resident';target=d.parent/sys.argv[1];out=d/sys.argv[2];out.mkdir(exist_ok=True);b=d.parent/'body-resident-slice/build/cmake/native'; lib=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin')
ninja=(template/'build/cmake/native/CMakeFiles/impl-Develop.ninja').read_text()
link=shlex.split(subprocess.check_output(['ninja','-f','build-Develop.ninja','-t','commands','Develop/compiler.link'],cwd=b,text=True).splitlines()[-1])[2:-2];link.insert(1,'-Wl,--threads=1')
for u in ['main_unit_checker','main_unit_frontend']:
 sec=ninja.split('build CMakeFiles/buster_'+u+'.dir/Develop',1)[1].split('  FLAGS = ',1)[1].splitlines()[0]
 flags=shlex.split(sec.replace(str(template),str(target)).replace('-Xclang -disable-llvm-passes -emit-llvm','').replace('-O3','-O0 -g1'))
 obj=out/(u+'.o')
 subprocess.run([lib/'clang',*flags,'-c',target/('src/buster/compiler/'+u+'.c'),'-o',obj],check=True)
 link[link.index('Develop/parts/'+u+'/native.o')]=str(obj)
link[link.index('Develop/compiler.link')]=str(out/'compiler')
subprocess.run(link,cwd=b,check=True)
