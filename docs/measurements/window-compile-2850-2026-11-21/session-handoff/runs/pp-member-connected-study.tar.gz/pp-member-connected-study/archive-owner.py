from pathlib import Path
import shutil,subprocess,hashlib,statistics
d=Path(__file__).resolve().parent;archive=d.parent/'pp-structural-study/stable';p=archive/'ownership'
for dest in ('source','reproduce','receipts'):(p/dest).mkdir(parents=True,exist_ok=True)
for f in ('ownership.patch','ranked.patch','restore-source-owner.patch'):shutil.copy2(d/f,p/'source'/f)
for f in ('main-owner-run.sh','old-owner.sh','absent.sh','corpora-local.sh','edges.py','main-local.sh','role-summary.py','remaining-census.py','retained-roles.c','remaining.sh','times.sh'):shutil.copy2(d/f,p/'reproduce'/f)
for f in ('declined-final.txt','role-summary.txt','remaining.tsv','parser-roles.txt'):shutil.copy2(d/f,p/'receipts'/f)
for f in ('physical-member-times-v4','physical-member-ownership-v5','physical-member-owner-before','physical-member-v4','physical-member-absent-v2'):shutil.copytree(d/f,p/'receipts'/f,dirs_exist_ok=True)
for f in (d/'corpus-owners').glob('*'):
 if f.is_dir():
  target=p/'receipts'/'corpus'/f.name;target.mkdir(parents=True,exist_ok=True)
  for name in ['rc','objects','stdout','stderr','diagnostics']:
   if (f/name).is_file():shutil.copy2(f/name,target/name)
shutil.copy2(d/'corpus-owners/summary',p/'receipts/corpus/summary')
for f in (d/'declined-fixture').glob('*'):
 if f.is_file() and f.suffix not in ('.o','.c'):dest=p/'receipts'/'declined-fixture';dest.mkdir(exist_ok=True);shutil.copy2(f,dest/f.name)
times={arm:statistics.median([int(i.read_text())/1e6 for i in (d/'physical-member-times-v4').glob('*-'+arm+'.time')])for arm in ['ordinary','native','connected']}
(p/'receipts'/'medians.txt').write_text(str(times)+'\n')
(p/'README.md').write_text('''# Source-backed member ownership and declaration lookup

On the Ryzen 7 9700X, an opt-in physical spelling index selected all 24,323 source-owned SQLite fields from record declarations. Its sparse token rank directory and declaration-populated spelling table preserved every field answer, the complete frozen SQLite ELF, maximum-warning diagnostic stream and independently linked SQL transcript at signed head `508ca9b36da46bd637ad42b90fcd61c9f07696e2`. Six fresh full ordinary object invocations per arm gave '''+', '.join(f'{name} {v:.3f} ms' for name,v in times.items())+'''. Every compiler or test child acquired and released its own hardware lease. [Native work counts and outcomes](receipts/physical-member-v4/hashes), [individual timing schedules](receipts/physical-member-times-v4), [complete rank implementation](source/ranked.patch).

## Recovering the original checker when a source body declines

At signed head `921845259`, ordinary compilation of Buster main.c succeeded while the control with physical member ownership and conventional bodies emitted 19 blank member diagnostics. The source-native configuration emitted 15. A generated large primary fixture with an included record declaration reproduced 19 blank field diagnostics under a forced body decline. [Original Buster run](receipts/physical-member-owner-before), [generated fixture outcome](receipts/declined-final.txt).

Signed correction `7f2b516b6e971e01c94cd55ae5919ef9c89d8cbf` requires a real downstream owner, retains canonical identities for header-derived tokens, and materializes a declined source body's unresolved fields before handing it to the ordinary checker. On the 9700X ordinary, conventional source mode, physical source-native and forced-decline configurations all produce the same complete 2,061,192-byte frozen SQLite ELF and Buster self-host ELF with empty compiler diagnostics. The native physical lookup trace records 24,323 SQLite and 36,925 Buster fields. A separate physically held, missing field `not_a_field` genuinely reaches the typed selector and returns no field, matching ordinary Buster's complete diagnostic and pinned Clang's rejection. [Fixed object/diagnostic/trace hashes](receipts/physical-member-ownership-v5/hashes), [actual missing-field receipts](receipts/physical-member-absent-v2), [ownership fix](source/restore-source-owner.patch).

Under default policy and `-Wall -Wextra`, the local frozen Lua 5.4.8 and musl controls reproduce all 34 and 1,336 complete ELF objects respectively and every diagnostic byte under the corrected source-body mode. Per-file SHA-256 manifests and the original compiler streams accompany the results. The comparison removed only the explicitly enabled research body's decision-trace records from stderr. [Corpus summary](receipts/corpus/summary), [per-configuration manifests and transcripts](receipts/corpus).

## Remaining source identities

The ordinary unprimed SQLite producer retained 124,895 physical identifiers across 8,481 spellings. Their eventual real parser roles include 89,997 operands, 24,323 record members, 10,100 specifiers, 375 tags and 100 right leaves. Within the 89,997 operands, 18,768 are children of a member operator. [Grammar role census](receipts/role-summary.txt), [source coordinates](receipts/remaining.tsv).

The ranked and ownership full-source patches apply independently to base `0e1d5b825801135bf50e79da9d546bc95209ab30`. The small restoration patch applies to `921845259`. The scope-binding and macro-preprocessor architecture experiments continue separately.
''')
archive_file=archive/'source-owner-and-record-index-v4.tar.gz'
subprocess.run(['tar','-czf',str(archive_file),'-C',str(archive),'ownership'],check=True)
print(hashlib.sha256(archive_file.read_bytes()).hexdigest(),archive_file)
