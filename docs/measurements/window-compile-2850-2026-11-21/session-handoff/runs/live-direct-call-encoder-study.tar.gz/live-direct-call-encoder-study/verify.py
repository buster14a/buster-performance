from pathlib import Path
import struct,hashlib,csv,sys,collections,os
d=Path(__file__).resolve().parent;w=d.parent;receipt=Path(os.environ.get('LIVE_LOG_DIR',d))
def table(f,head,rows):
 with f.open('w') as h:
  wr=csv.writer(h,delimiter='\t',lineterminator='\n');wr.writerow(head);wr.writerows(rows)
def elf(f):
 b=f.read_bytes();off=struct.unpack_from('<Q',b,40)[0];ss,n=struct.unpack_from('<HH',b,58);secs=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*ss) for i in range(n)]
 funcs={};symtabs={};rel={}
 for j,s in enumerate(secs):
  if s[1]!=2:continue
  t=secs[s[6]];names=b[t[4]:t[4]+t[5]];symtabs[j]=[]
  for i in range(s[4],s[4]+s[5],s[9]):
   ni,flags,other,k,pos,size=struct.unpack_from('<IBBHQQ',b,i);name=names[ni:names.index(0,ni)].decode();symtabs[j].append((name,k,pos,size,flags))
   if flags&15==2 and k and k<len(secs):funcs.setdefault(name,[]).append((k,pos,b[secs[k][4]+pos:secs[k][4]+pos+size]))
 for s in secs:
  if s[1]!=4:continue
  for i in range(s[4],s[4]+s[5],s[9]):
   pos,inf,add=struct.unpack_from('<QQq',b,i);rel[s[7],pos]=(inf&0xffffffff,symtabs[s[6]][inf>>32],add)
 return funcs,rel
def rows(p):return [x.split('\t') for x in p.read_text().splitlines()]
sums=[]
for job in sys.argv[1:] or ['smoke','sqlite','main']:
 smoke=job=='smoke'; audit=(d if smoke else receipt)/('native.stderr' if smoke else f'{job}.audit.stderr');ordinary=d/'clean.o' if smoke else w/'source-typed-study'/f'{job}.o'
 obj=d/('native.o' if smoke else f'{job}.audit.o')
 if not obj.exists():continue
 assert obj.read_bytes()==ordinary.read_bytes(),job
 ar=rows(audit);func,rel=elf(ordinary); built={int(x[1]):x for x in ar if x[0]=='early-native-bytes'}
 owned={int(x[1]):tuple(map(int,x[2:])) for x in ar if x[0]=='early-native-owned'}
 low={int(x[1]):int(x[2]) for x in ar if x[0]=='control-source-function'}
 graph={int(x[1]):int(x[2]) for x in ar if x[0]=='early-native-body-graph'}
 normal={int(x[1]):int(x[2]) for x in rows(receipt/f'{job}.graph.stderr') if x[0]=='early-native-body-graph'} if not smoke else {}
 fields=collections.defaultdict(list)
 for x in ar:
  if x[0]=='early-native-call-field':fields[int(x[1])].append(x)
 late={int(x[1]):tuple(map(int,x[2:])) for x in ar if x[0]=='early-native-used'}; original=dict(owned)
 if os.environ.get('LIVE_INCLUDE_LATE'):
  for k,(nc,size) in late.items():
   assert k not in owned
   owned[k]=(0,0,nc,size)
 records=[]; nref=verified=local=0;mismatches=[]
 for k,v in owned.items():
  if k in original:assert graph[k]==0 and low.get(k,0)==0
  if k not in fields:continue
  name=built[k][2]; depth,pp=map(int,built[k][3:5]);raw=bytes.fromhex(built[k][5]);assert depth
  emitted=func.get(name,[])
  for _,_,end,use,prior,symbol,callee,at,add in fields[k]:
   nref+=1;at=int(at);add=int(add); use=int(use); prior=int(prior);assert prior<use< int(end) and add==-4 and raw[at-1]==0xe8 and raw[at:at+4]==bytes(4),(name,at,raw.hex())
   row=[name,k,depth,pp,callee,use,prior,symbol,at,add,low.get(k, v[2] if k in late else "eliminated"),graph[k],normal.get(k,''),v[2],len(raw)]
   if not emitted:records.append(row+['eliminated-by-linker','','','','']);continue
   assert len(emitted)==1;sec,addr,text=emitted[0];ab=at+addr
   if (sec,ab) in rel:
    typ,(target,tk,tpos,_,flags),extra=rel[sec,ab]
    if flags&15==3:
     targetaddr=tpos+extra-add;assert typ==4 and any(k==tk and a==targetaddr for k,a,_ in func[callee]),(job,name,callee,rel[sec,ab])
     kind='R_X86_64_PLT32-section';local+=1
    else:
     assert (typ,target,extra)==(4,callee,add),(job,name,callee,rel[sec,ab]);kind='R_X86_64_PLT32-symbol';targetaddr=''
   else:
    targetaddr=ab+4+struct.unpack_from('<i',text,at)[0];poss=[n for n,possible in func.items() if any(s==sec and x==targetaddr for s,x,_ in possible)];assert callee in poss,(job,name,callee,poss,targetaddr)
    kind='resolved-local-rel32';local+=1
   fixed=bytearray(text)
   for ff in fields[k]:
    shift=int(ff[7]);fixed[shift:shift+4]=bytes(4)
   assert bytes(fixed)==raw,(job,name)
   records.append(row+[kind,sec,ab,targetaddr,1]);verified+=1
 table(receipt/f'{job}-{"used" if os.environ.get("LIVE_INCLUDE_LATE") else "owned"}-calls.tsv',['caller','opening','PP-depth','PP-row-count','callee','callee-use-token','prior-declaration-token','pre-EOF-symbol','field-offset-in-caller','addend','final-typed','final-graph','ordinary-graph','source-typed','text-bytes','ordinary-resolution','text-section','relocation-text-offset','target-position','all-other-bytes-equal'],records)
 ownfields=set(fields)&set(owned);sums.append([job,len(built),len(fields),sum(map(len,fields.values())),len(owned),len(ownfields),nref,verified,local,sum(normal.get(k,0) for k in ownfields),sum(owned[k][2] for k in ownfields),len(set(r[4] for r in records)),hashlib.sha256(obj.read_bytes()).hexdigest()])
cov=receipt/('used-coverage.tsv' if os.environ.get('LIVE_INCLUDE_LATE') else 'coverage.tsv');table(cov,['input','physical-all','physical-call-bodies','physical-call-fields','whole-owned','whole-call-bodies','whole-call-fields','verified-in-ordinary-ELF','resolved-internal','ordinary-call-body-graph-nodes-removed','ordinary-call-body-typed-entries-removed','distinct-targets','whole-ELF-SHA256'],sums)
print(cov.read_text())
