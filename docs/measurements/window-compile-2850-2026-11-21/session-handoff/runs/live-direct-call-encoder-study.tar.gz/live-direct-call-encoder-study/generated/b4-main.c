#include <stdio.h>
struct N{unsigned long before;struct N*next;unsigned n;};unsigned long seen=9;
void callee384(unsigned a0,unsigned long a1,unsigned a2,unsigned a3,unsigned long a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee385(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee386(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
void callee387(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
void callee388(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee389(unsigned a0,unsigned long a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee390(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee391(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee392(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee393(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
void callee394(unsigned long a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
void callee395(unsigned long a0,unsigned long a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee396(unsigned a0,unsigned long a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee397(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee398(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee399(void){seen=seen*1099511628211UL+17UL;}
void callee400(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned long callee401(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee402(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee403(unsigned a0,unsigned long a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee404(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee405(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee406(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee407(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee408(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee409(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee410(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee411(unsigned a0,unsigned long a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee412(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee413(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee414(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee415(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned long callee416(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee417(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee418(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee419(unsigned a0,unsigned a1,unsigned a2,unsigned long a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee420(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee421(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned long callee422(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
void callee423(unsigned a0,unsigned long a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee424(unsigned a0,unsigned a1,unsigned long a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee425(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee426(unsigned a0,unsigned a1,unsigned long a2,unsigned a3,unsigned long a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee427(void){seen=seen*1099511628211UL+17UL;}
void callee428(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned callee429(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee430(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee431(unsigned a0,unsigned long a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee432(unsigned a0,unsigned a1,unsigned a2,unsigned long a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee433(unsigned a0,unsigned a1,unsigned a2,unsigned long a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee434(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee435(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
void callee436(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned long callee437(unsigned a0,unsigned long a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee438(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee439(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee440(unsigned a0,unsigned long a1,unsigned a2,unsigned a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee441(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee442(unsigned long a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
void callee443(unsigned long a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned callee444(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee445(unsigned long a0,unsigned long a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee446(unsigned a0,unsigned a1,unsigned a2,unsigned long a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee447(unsigned long a0,unsigned long a1,unsigned a2,unsigned a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee448(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee449(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee450(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee451(unsigned a0,unsigned long a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee452(unsigned a0,unsigned a1,unsigned long a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee453(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee454(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee455(void){seen=seen*1099511628211UL+17UL;}
unsigned long callee456(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned long callee457(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee458(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee459(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee460(unsigned a0,unsigned long a1,unsigned a2,unsigned long a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee461(unsigned a0,unsigned long a1,unsigned a2,unsigned a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee462(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee463(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned long callee464(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned long callee465(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee466(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee467(unsigned a0,unsigned a1,unsigned long a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee468(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee469(void){seen=seen*1099511628211UL+17UL;}
unsigned callee470(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned long callee471(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned long callee472(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee473(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee474(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee475(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee476(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee477(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned callee478(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned long callee479(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void caller384(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3,unsigned long p4);
unsigned long caller385(unsigned p0,unsigned long p1,unsigned p2,unsigned long p3,unsigned p4,unsigned p5);
unsigned caller386(struct N* p0,unsigned long p1,unsigned p2,unsigned long p3,unsigned long p4,unsigned p5);
void caller387(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned long p4,unsigned long p5);
void caller388(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned long p4,unsigned p5);
unsigned caller389(struct N* p0,unsigned p1,unsigned long p2,unsigned p3,unsigned p4,unsigned p5);
unsigned long caller390(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned p4,unsigned long p5);
void caller391(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned p4,unsigned long p5);
unsigned long caller392(void);
unsigned long caller393(void);
void caller394(void);
void caller395(void);
unsigned caller396(void);
unsigned caller397(void);
unsigned caller398(void);
void caller399(unsigned p0);
void caller400(struct N* p0);
unsigned long caller401(struct N* p0);
unsigned caller402(struct N* p0);
void caller403(struct N* p0);
unsigned caller404(struct N* p0);
void caller405(struct N* p0);
unsigned long caller406(unsigned p0,unsigned p1);
unsigned caller407(struct N* p0,unsigned p1);
unsigned caller408(struct N* p0,unsigned long p1);
unsigned caller409(struct N* p0,unsigned p1);
unsigned long caller410(struct N* p0,unsigned p1);
void caller411(struct N* p0,unsigned p1);
unsigned caller412(struct N* p0,unsigned long p1);
unsigned long caller413(unsigned long p0,unsigned p1,unsigned long p2);
unsigned long caller414(struct N* p0,unsigned long p1,unsigned long p2);
unsigned caller415(struct N* p0,unsigned long p1,unsigned long p2);
unsigned long caller416(struct N* p0,unsigned p1,unsigned long p2);
void caller417(struct N* p0,unsigned long p1,unsigned long p2);
void caller418(struct N* p0,unsigned p1,unsigned p2);
unsigned long caller419(struct N* p0,unsigned p1,unsigned p2);
unsigned caller420(unsigned long p0,unsigned long p1,unsigned long p2,unsigned p3);
unsigned caller421(struct N* p0,unsigned p1,unsigned long p2,unsigned p3);
unsigned long caller422(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3);
void caller423(struct N* p0,unsigned long p1,unsigned p2,unsigned p3);
unsigned long caller424(struct N* p0,unsigned p1,unsigned p2,unsigned p3);
unsigned long caller425(struct N* p0,unsigned long p1,unsigned p2,unsigned p3);
unsigned caller426(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3);
void caller427(unsigned long p0,unsigned p1,unsigned p2,unsigned p3,unsigned p4);
void caller428(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned p4);
unsigned caller429(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned p4);
unsigned caller430(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned p4);
unsigned long caller431(struct N* p0,unsigned long p1,unsigned p2,unsigned long p3,unsigned p4);
unsigned long caller432(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3,unsigned long p4);
void caller433(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned long p4);
unsigned caller434(unsigned p0,unsigned long p1,unsigned p2,unsigned long p3,unsigned long p4,unsigned long p5);
unsigned caller435(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned p4,unsigned p5);
void caller436(struct N* p0,unsigned long p1,unsigned p2,unsigned long p3,unsigned p4,unsigned long p5);
unsigned long caller437(struct N* p0,unsigned long p1,unsigned long p2,unsigned long p3,unsigned p4,unsigned p5);
unsigned long caller438(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned long p4,unsigned p5);
unsigned caller439(struct N* p0,unsigned p1,unsigned p2,unsigned long p3,unsigned long p4,unsigned p5);
unsigned caller440(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned p4,unsigned long p5);
unsigned caller441(void);
void caller442(void);
void caller443(void);
unsigned caller444(void);
void caller445(void);
unsigned long caller446(void);
unsigned long caller447(void);
unsigned long caller448(unsigned long p0);
unsigned long caller449(struct N* p0);
unsigned caller450(struct N* p0);
unsigned caller451(struct N* p0);
unsigned long caller452(struct N* p0);
unsigned caller453(struct N* p0);
unsigned caller454(struct N* p0);
void caller455(unsigned p0,unsigned long p1);
unsigned long caller456(struct N* p0,unsigned p1);
unsigned long caller457(struct N* p0,unsigned p1);
unsigned caller458(struct N* p0,unsigned p1);
void caller459(struct N* p0,unsigned p1);
unsigned caller460(struct N* p0,unsigned p1);
unsigned caller461(struct N* p0,unsigned long p1);
unsigned caller462(unsigned long p0,unsigned p1,unsigned long p2);
unsigned long caller463(struct N* p0,unsigned long p1,unsigned long p2);
unsigned long caller464(struct N* p0,unsigned long p1,unsigned long p2);
unsigned long caller465(struct N* p0,unsigned p1,unsigned p2);
unsigned long caller466(struct N* p0,unsigned long p1,unsigned long p2);
unsigned long caller467(struct N* p0,unsigned long p1,unsigned p2);
void caller468(struct N* p0,unsigned p1,unsigned p2);
void caller469(unsigned p0,unsigned p1,unsigned p2,unsigned long p3);
unsigned caller470(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3);
unsigned long caller471(struct N* p0,unsigned p1,unsigned p2,unsigned p3);
unsigned long caller472(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3);
unsigned long caller473(struct N* p0,unsigned p1,unsigned p2,unsigned long p3);
unsigned caller474(struct N* p0,unsigned long p1,unsigned long p2,unsigned long p3);
unsigned long caller475(struct N* p0,unsigned long p1,unsigned p2,unsigned p3);
unsigned caller476(unsigned long p0,unsigned long p1,unsigned p2,unsigned long p3,unsigned long p4);
void caller477(struct N* p0,unsigned p1,unsigned long p2,unsigned p3,unsigned long p4);
unsigned caller478(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3,unsigned long p4);
unsigned long caller479(struct N* p0,unsigned long p1,unsigned p2,unsigned long p3,unsigned p4);
int main(void){struct N child={0,0,29},node={0,&child,11};caller384(&node,770,1155,1540,1925);
caller385(386,772,1158,1544,1930,2316);
caller386(&node,774,1161,1548,1935,2322);
caller387(&node,776,1164,1552,1940,2328);
caller388(&node,778,1167,1556,1945,2334);
caller389(&node,780,1170,1560,1950,2340);
caller390(&node,782,1173,1564,1955,2346);
caller391(&node,784,1176,1568,1960,2352);
caller392();
caller393();
caller394();
caller395();
caller396();
caller397();
caller398();
caller399(400);
caller400(&node);
caller401(&node);
caller402(&node);
caller403(&node);
caller404(&node);
caller405(&node);
caller406(407,814);
caller407(&node,816);
caller408(&node,818);
caller409(&node,820);
caller410(&node,822);
caller411(&node,824);
caller412(&node,826);
caller413(414,828,1242);
caller414(&node,830,1245);
caller415(&node,832,1248);
caller416(&node,834,1251);
caller417(&node,836,1254);
caller418(&node,838,1257);
caller419(&node,840,1260);
caller420(421,842,1263,1684);
caller421(&node,844,1266,1688);
caller422(&node,846,1269,1692);
caller423(&node,848,1272,1696);
caller424(&node,850,1275,1700);
caller425(&node,852,1278,1704);
caller426(&node,854,1281,1708);
caller427(428,856,1284,1712,2140);
caller428(&node,858,1287,1716,2145);
caller429(&node,860,1290,1720,2150);
caller430(&node,862,1293,1724,2155);
caller431(&node,864,1296,1728,2160);
caller432(&node,866,1299,1732,2165);
caller433(&node,868,1302,1736,2170);
caller434(435,870,1305,1740,2175,2610);
caller435(&node,872,1308,1744,2180,2616);
caller436(&node,874,1311,1748,2185,2622);
caller437(&node,876,1314,1752,2190,2628);
caller438(&node,878,1317,1756,2195,2634);
caller439(&node,880,1320,1760,2200,2640);
caller440(&node,882,1323,1764,2205,2646);
caller441();
caller442();
caller443();
caller444();
caller445();
caller446();
caller447();
caller448(449);
caller449(&node);
caller450(&node);
caller451(&node);
caller452(&node);
caller453(&node);
caller454(&node);
caller455(456,912);
caller456(&node,914);
caller457(&node,916);
caller458(&node,918);
caller459(&node,920);
caller460(&node,922);
caller461(&node,924);
caller462(463,926,1389);
caller463(&node,928,1392);
caller464(&node,930,1395);
caller465(&node,932,1398);
caller466(&node,934,1401);
caller467(&node,936,1404);
caller468(&node,938,1407);
caller469(470,940,1410,1880);
caller470(&node,942,1413,1884);
caller471(&node,944,1416,1888);
caller472(&node,946,1419,1892);
caller473(&node,948,1422,1896);
caller474(&node,950,1425,1900);
caller475(&node,952,1428,1904);
caller476(477,954,1431,1908,2385);
caller477(&node,956,1434,1912,2390);
caller478(&node,958,1437,1916,2395);
caller479(&node,960,1440,1920,2400);printf("%lu\n",seen);return 0;}