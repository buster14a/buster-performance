#include <stdio.h>
struct N{unsigned long before;struct N*next;unsigned n;};unsigned long seen=9;
unsigned long callee480(unsigned a0,unsigned long a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee481(unsigned a0,unsigned long a1,unsigned a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee482(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee483(void){seen=seen*1099511628211UL+17UL;}
unsigned long callee484(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee485(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee486(unsigned a0,unsigned long a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee487(unsigned a0,unsigned a1,unsigned a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee488(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee489(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee490(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee491(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee492(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned long callee493(unsigned long a0,unsigned long a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee494(unsigned a0,unsigned a1,unsigned a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee495(unsigned long a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee496(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3,unsigned long a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee497(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee498(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee499(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
void callee500(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee501(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee502(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee503(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee504(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee505(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
void callee506(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
void callee507(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee508(unsigned a0,unsigned a1,unsigned a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee509(unsigned a0,unsigned a1,unsigned a2,unsigned long a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee510(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee511(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee512(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned long callee513(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee514(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee515(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee516(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee517(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee518(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee519(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee520(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
void callee521(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee522(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee523(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee524(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee525(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee526(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned long callee527(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee528(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee529(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee530(unsigned a0,unsigned long a1,unsigned a2,unsigned long a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee531(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee532(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee533(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee534(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee535(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee536(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee537(unsigned a0,unsigned a1,unsigned long a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee538(unsigned a0,unsigned long a1,unsigned a2,unsigned long a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee539(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee540(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned callee541(unsigned long a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee542(unsigned a0,unsigned long a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee543(unsigned long a0,unsigned a1,unsigned a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee544(unsigned long a0,unsigned a1,unsigned long a2,unsigned long a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee545(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee546(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee547(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee548(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned long callee549(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee550(unsigned a0,unsigned long a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee551(unsigned a0,unsigned long a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee552(unsigned a0,unsigned long a1,unsigned a2,unsigned a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee553(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee554(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned callee555(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee556(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee557(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee558(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee559(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee560(void){seen=seen*1099511628211UL+17UL;}
void callee561(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned long callee562(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
void callee563(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee564(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee565(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee566(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned long a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee567(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee568(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
void callee569(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned callee570(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee571(unsigned a0,unsigned long a1,unsigned a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee572(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee573(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee574(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee575(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned long caller480(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned p4);
unsigned caller481(struct N* p0,unsigned p1,unsigned p2,unsigned long p3,unsigned p4);
unsigned caller482(struct N* p0,unsigned p1,unsigned long p2,unsigned p3,unsigned p4);
void caller483(unsigned p0,unsigned p1,unsigned long p2,unsigned p3,unsigned long p4,unsigned long p5);
unsigned long caller484(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned p4,unsigned p5);
unsigned caller485(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned p4,unsigned long p5);
unsigned caller486(struct N* p0,unsigned long p1,unsigned long p2,unsigned long p3,unsigned long p4,unsigned long p5);
void caller487(struct N* p0,unsigned p1,unsigned long p2,unsigned p3,unsigned p4,unsigned long p5);
void caller488(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned long p4,unsigned p5);
unsigned long caller489(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned p4,unsigned long p5);
unsigned long caller490(void);
unsigned long caller491(void);
unsigned caller492(void);
unsigned long caller493(void);
void caller494(void);
unsigned long caller495(void);
unsigned caller496(void);
unsigned long caller497(unsigned p0);
unsigned long caller498(struct N* p0);
unsigned caller499(struct N* p0);
void caller500(struct N* p0);
unsigned caller501(struct N* p0);
void caller502(struct N* p0);
unsigned caller503(struct N* p0);
unsigned caller504(unsigned p0,unsigned long p1);
void caller505(struct N* p0,unsigned long p1);
void caller506(struct N* p0,unsigned long p1);
void caller507(struct N* p0,unsigned long p1);
unsigned long caller508(struct N* p0,unsigned long p1);
unsigned long caller509(struct N* p0,unsigned long p1);
unsigned caller510(struct N* p0,unsigned long p1);
unsigned caller511(unsigned p0,unsigned long p1,unsigned p2);
void caller512(struct N* p0,unsigned long p1,unsigned long p2);
unsigned long caller513(struct N* p0,unsigned p1,unsigned long p2);
unsigned caller514(struct N* p0,unsigned p1,unsigned p2);
unsigned long caller515(struct N* p0,unsigned p1,unsigned long p2);
void caller516(struct N* p0,unsigned long p1,unsigned p2);
void caller517(struct N* p0,unsigned p1,unsigned long p2);
unsigned long caller518(unsigned long p0,unsigned long p1,unsigned p2,unsigned p3);
unsigned long caller519(struct N* p0,unsigned long p1,unsigned p2,unsigned long p3);
unsigned caller520(struct N* p0,unsigned p1,unsigned p2,unsigned long p3);
void caller521(struct N* p0,unsigned p1,unsigned p2,unsigned long p3);
unsigned caller522(struct N* p0,unsigned long p1,unsigned long p2,unsigned long p3);
unsigned caller523(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3);
void caller524(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3);
unsigned long caller525(unsigned p0,unsigned long p1,unsigned p2,unsigned p3,unsigned long p4);
unsigned caller526(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned long p4);
unsigned long caller527(struct N* p0,unsigned long p1,unsigned long p2,unsigned long p3,unsigned long p4);
unsigned caller528(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned p4);
unsigned long caller529(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned long p4);
void caller530(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3,unsigned long p4);
unsigned long caller531(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3,unsigned long p4);
unsigned long caller532(unsigned long p0,unsigned p1,unsigned long p2,unsigned p3,unsigned long p4,unsigned p5);
unsigned long caller533(struct N* p0,unsigned p1,unsigned long p2,unsigned p3,unsigned long p4,unsigned long p5);
unsigned caller534(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned p4,unsigned long p5);
unsigned caller535(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned p4,unsigned p5);
unsigned long caller536(struct N* p0,unsigned p1,unsigned p2,unsigned long p3,unsigned long p4,unsigned p5);
unsigned long caller537(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned long p4,unsigned p5);
unsigned long caller538(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned long p4,unsigned long p5);
unsigned long caller539(void);
void caller540(void);
unsigned caller541(void);
unsigned caller542(void);
unsigned caller543(void);
unsigned caller544(void);
unsigned caller545(void);
unsigned long caller546(unsigned p0);
unsigned caller547(struct N* p0);
unsigned caller548(struct N* p0);
unsigned long caller549(struct N* p0);
void caller550(struct N* p0);
void caller551(struct N* p0);
void caller552(struct N* p0);
unsigned long caller553(unsigned long p0,unsigned p1);
void caller554(struct N* p0,unsigned long p1);
unsigned caller555(struct N* p0,unsigned p1);
unsigned caller556(struct N* p0,unsigned long p1);
void caller557(struct N* p0,unsigned p1);
void caller558(struct N* p0,unsigned p1);
unsigned long caller559(struct N* p0,unsigned p1);
void caller560(unsigned long p0,unsigned long p1,unsigned long p2);
void caller561(struct N* p0,unsigned long p1,unsigned p2);
unsigned long caller562(struct N* p0,unsigned long p1,unsigned long p2);
void caller563(struct N* p0,unsigned long p1,unsigned long p2);
unsigned caller564(struct N* p0,unsigned p1,unsigned long p2);
unsigned long caller565(struct N* p0,unsigned long p1,unsigned long p2);
void caller566(struct N* p0,unsigned p1,unsigned p2);
unsigned long caller567(unsigned p0,unsigned long p1,unsigned p2,unsigned p3);
unsigned caller568(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3);
void caller569(struct N* p0,unsigned p1,unsigned p2,unsigned p3);
unsigned caller570(struct N* p0,unsigned long p1,unsigned p2,unsigned p3);
unsigned long caller571(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3);
unsigned caller572(struct N* p0,unsigned p1,unsigned p2,unsigned p3);
unsigned caller573(struct N* p0,unsigned p1,unsigned p2,unsigned long p3);
unsigned caller574(unsigned long p0,unsigned long p1,unsigned p2,unsigned p3,unsigned p4);
void caller575(struct N* p0,unsigned long p1,unsigned p2,unsigned long p3,unsigned long p4);
int main(void){struct N child={0,0,29},node={0,&child,11};caller480(&node,962,1443,1924,2405);
caller481(&node,964,1446,1928,2410);
caller482(&node,966,1449,1932,2415);
caller483(484,968,1452,1936,2420,2904);
caller484(&node,970,1455,1940,2425,2910);
caller485(&node,972,1458,1944,2430,2916);
caller486(&node,974,1461,1948,2435,2922);
caller487(&node,976,1464,1952,2440,2928);
caller488(&node,978,1467,1956,2445,2934);
caller489(&node,980,1470,1960,2450,2940);
caller490();
caller491();
caller492();
caller493();
caller494();
caller495();
caller496();
caller497(498);
caller498(&node);
caller499(&node);
caller500(&node);
caller501(&node);
caller502(&node);
caller503(&node);
caller504(505,1010);
caller505(&node,1012);
caller506(&node,1014);
caller507(&node,1016);
caller508(&node,1018);
caller509(&node,1020);
caller510(&node,1022);
caller511(512,1024,1536);
caller512(&node,1026,1539);
caller513(&node,1028,1542);
caller514(&node,1030,1545);
caller515(&node,1032,1548);
caller516(&node,1034,1551);
caller517(&node,1036,1554);
caller518(519,1038,1557,2076);
caller519(&node,1040,1560,2080);
caller520(&node,1042,1563,2084);
caller521(&node,1044,1566,2088);
caller522(&node,1046,1569,2092);
caller523(&node,1048,1572,2096);
caller524(&node,1050,1575,2100);
caller525(526,1052,1578,2104,2630);
caller526(&node,1054,1581,2108,2635);
caller527(&node,1056,1584,2112,2640);
caller528(&node,1058,1587,2116,2645);
caller529(&node,1060,1590,2120,2650);
caller530(&node,1062,1593,2124,2655);
caller531(&node,1064,1596,2128,2660);
caller532(533,1066,1599,2132,2665,3198);
caller533(&node,1068,1602,2136,2670,3204);
caller534(&node,1070,1605,2140,2675,3210);
caller535(&node,1072,1608,2144,2680,3216);
caller536(&node,1074,1611,2148,2685,3222);
caller537(&node,1076,1614,2152,2690,3228);
caller538(&node,1078,1617,2156,2695,3234);
caller539();
caller540();
caller541();
caller542();
caller543();
caller544();
caller545();
caller546(547);
caller547(&node);
caller548(&node);
caller549(&node);
caller550(&node);
caller551(&node);
caller552(&node);
caller553(554,1108);
caller554(&node,1110);
caller555(&node,1112);
caller556(&node,1114);
caller557(&node,1116);
caller558(&node,1118);
caller559(&node,1120);
caller560(561,1122,1683);
caller561(&node,1124,1686);
caller562(&node,1126,1689);
caller563(&node,1128,1692);
caller564(&node,1130,1695);
caller565(&node,1132,1698);
caller566(&node,1134,1701);
caller567(568,1136,1704,2272);
caller568(&node,1138,1707,2276);
caller569(&node,1140,1710,2280);
caller570(&node,1142,1713,2284);
caller571(&node,1144,1716,2288);
caller572(&node,1146,1719,2292);
caller573(&node,1148,1722,2296);
caller574(575,1150,1725,2300,2875);
caller575(&node,1152,1728,2304,2880);printf("%lu\n",seen);return 0;}