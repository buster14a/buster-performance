#include <stdio.h>
struct N{unsigned long before;struct N*next;unsigned n;};unsigned long seen=9;
void callee0(void){seen=seen*1099511628211UL+17UL;}
unsigned callee1(unsigned long a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee2(unsigned long a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned long callee3(unsigned a0,unsigned long a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee4(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee5(unsigned long a0,unsigned long a1,unsigned a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee6(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee7(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee8(unsigned long a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
void callee9(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned long callee10(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee11(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee12(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee13(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee14(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee15(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
void callee16(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned callee17(unsigned long a0,unsigned long a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee18(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee19(unsigned long a0,unsigned a1,unsigned long a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee20(unsigned long a0,unsigned long a1,unsigned long a2,unsigned long a3,unsigned long a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee21(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee22(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned long callee23(unsigned long a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee24(unsigned a0,unsigned long a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee25(unsigned a0,unsigned a1,unsigned a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee26(unsigned long a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee27(unsigned long a0,unsigned a1,unsigned a2,unsigned long a3,unsigned long a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee28(void){seen=seen*1099511628211UL+17UL;}
unsigned long callee29(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned long callee30(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
void callee31(unsigned long a0,unsigned long a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee32(unsigned a0,unsigned a1,unsigned a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee33(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee34(unsigned long a0,unsigned a1,unsigned a2,unsigned long a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee35(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee36(unsigned long a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned callee37(unsigned long a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
void callee38(unsigned long a0,unsigned long a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee39(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee40(unsigned long a0,unsigned a1,unsigned a2,unsigned long a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee41(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee42(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee43(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
void callee44(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned callee45(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee46(unsigned a0,unsigned long a1,unsigned a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee47(unsigned long a0,unsigned long a1,unsigned a2,unsigned long a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee48(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee49(void){seen=seen*1099511628211UL+17UL;}
unsigned callee50(unsigned long a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee51(unsigned long a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee52(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee53(unsigned a0,unsigned a1,unsigned a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee54(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee55(unsigned long a0,unsigned a1,unsigned a2,unsigned long a3,unsigned long a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee56(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee57(unsigned long a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned long callee58(unsigned long a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee59(unsigned long a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee60(unsigned long a0,unsigned long a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee61(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee62(unsigned a0,unsigned a1,unsigned long a2,unsigned a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee63(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee64(unsigned long a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee65(unsigned long a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
void callee66(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee67(unsigned a0,unsigned a1,unsigned a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee68(unsigned long a0,unsigned long a1,unsigned a2,unsigned long a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee69(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee70(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee71(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned long callee72(unsigned long a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
void callee73(unsigned long a0,unsigned long a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee74(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee75(unsigned long a0,unsigned a1,unsigned a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee76(unsigned long a0,unsigned a1,unsigned a2,unsigned a3,unsigned long a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee77(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee78(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
void callee79(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned callee80(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee81(unsigned a0,unsigned a1,unsigned a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee82(unsigned a0,unsigned a1,unsigned long a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee83(unsigned a0,unsigned long a1,unsigned a2,unsigned a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee84(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee85(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
void callee86(unsigned long a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned long callee87(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee88(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee89(unsigned long a0,unsigned long a1,unsigned a2,unsigned long a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee90(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee91(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee92(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned long callee93(unsigned long a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee94(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee95(unsigned long a0,unsigned a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void caller0(void);
unsigned caller1(void);
unsigned caller2(void);
unsigned long caller3(void);
void caller4(void);
void caller5(void);
void caller6(void);
unsigned long caller7(unsigned p0);
void caller8(unsigned long p0);
void caller9(unsigned long p0);
unsigned long caller10(unsigned p0);
unsigned caller11(unsigned p0);
void caller12(unsigned p0);
unsigned caller13(unsigned long p0);
unsigned caller14(unsigned long p0,unsigned long p1);
void caller15(unsigned long p0,unsigned p1);
void caller16(unsigned p0,unsigned p1);
unsigned caller17(unsigned long p0,unsigned long p1);
unsigned long caller18(unsigned p0,unsigned p1);
unsigned long caller19(unsigned long p0,unsigned p1);
unsigned caller20(unsigned long p0,unsigned long p1);
unsigned long caller21(unsigned p0,unsigned long p1,unsigned p2);
unsigned long caller22(unsigned p0,unsigned p1,unsigned long p2);
unsigned long caller23(unsigned p0,unsigned p1,unsigned p2);
unsigned caller24(unsigned p0,unsigned long p1,unsigned long p2);
unsigned long caller25(unsigned long p0,unsigned p1,unsigned p2);
void caller26(unsigned p0,unsigned long p1,unsigned p2);
unsigned long caller27(unsigned long p0,unsigned long p1,unsigned p2);
void caller28(unsigned p0,unsigned p1,unsigned p2,unsigned p3);
unsigned long caller29(unsigned p0,unsigned p1,unsigned p2,unsigned p3);
unsigned long caller30(unsigned p0,unsigned p1,unsigned long p2,unsigned long p3);
void caller31(unsigned p0,unsigned long p1,unsigned long p2,unsigned long p3);
unsigned long caller32(unsigned long p0,unsigned p1,unsigned p2,unsigned long p3);
unsigned caller33(unsigned long p0,unsigned long p1,unsigned p2,unsigned long p3);
void caller34(unsigned p0,unsigned long p1,unsigned p2,unsigned long p3);
unsigned long caller35(unsigned long p0,unsigned long p1,unsigned long p2,unsigned p3,unsigned long p4);
void caller36(unsigned long p0,unsigned p1,unsigned long p2,unsigned p3,unsigned p4);
unsigned caller37(unsigned long p0,unsigned long p1,unsigned long p2,unsigned p3,unsigned long p4);
void caller38(unsigned long p0,unsigned long p1,unsigned long p2,unsigned long p3,unsigned long p4);
unsigned long caller39(unsigned long p0,unsigned long p1,unsigned p2,unsigned long p3,unsigned p4);
void caller40(unsigned long p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned p4);
unsigned caller41(unsigned p0,unsigned long p1,unsigned p2,unsigned p3,unsigned long p4);
unsigned caller42(unsigned p0,unsigned p1,unsigned long p2,unsigned p3,unsigned p4,unsigned long p5);
void caller43(unsigned long p0,unsigned long p1,unsigned long p2,unsigned p3,unsigned p4,unsigned long p5);
void caller44(unsigned p0,unsigned p1,unsigned p2,unsigned p3,unsigned long p4,unsigned p5);
unsigned caller45(unsigned p0,unsigned p1,unsigned long p2,unsigned p3,unsigned long p4,unsigned long p5);
unsigned caller46(unsigned long p0,unsigned long p1,unsigned p2,unsigned p3,unsigned p4,unsigned p5);
unsigned long caller47(unsigned long p0,unsigned p1,unsigned long p2,unsigned p3,unsigned long p4,unsigned p5);
unsigned long caller48(unsigned p0,unsigned long p1,unsigned long p2,unsigned long p3,unsigned long p4,unsigned long p5);
void caller49(void);
unsigned caller50(void);
unsigned caller51(void);
unsigned caller52(void);
unsigned long caller53(void);
unsigned caller54(void);
unsigned long caller55(void);
unsigned caller56(unsigned p0);
unsigned caller57(unsigned long p0);
unsigned long caller58(unsigned long p0);
unsigned caller59(unsigned long p0);
unsigned caller60(unsigned long p0);
void caller61(unsigned p0);
unsigned long caller62(unsigned p0);
unsigned long caller63(unsigned long p0,unsigned p1);
unsigned caller64(unsigned p0,unsigned long p1);
unsigned caller65(unsigned long p0,unsigned long p1);
void caller66(unsigned p0,unsigned p1);
unsigned long caller67(unsigned p0,unsigned p1);
unsigned caller68(unsigned long p0,unsigned long p1);
void caller69(unsigned long p0,unsigned p1);
unsigned long caller70(unsigned p0,unsigned p1,unsigned long p2);
void caller71(unsigned p0,unsigned p1,unsigned p2);
unsigned long caller72(unsigned long p0,unsigned long p1,unsigned long p2);
void caller73(unsigned long p0,unsigned long p1,unsigned p2);
unsigned caller74(unsigned p0,unsigned long p1,unsigned p2);
unsigned long caller75(unsigned p0,unsigned long p1,unsigned p2);
void caller76(unsigned long p0,unsigned p1,unsigned p2);
unsigned caller77(unsigned p0,unsigned long p1,unsigned p2,unsigned p3);
unsigned caller78(unsigned p0,unsigned p1,unsigned p2,unsigned p3);
void caller79(unsigned long p0,unsigned p1,unsigned long p2,unsigned long p3);
unsigned caller80(unsigned long p0,unsigned p1,unsigned long p2,unsigned p3);
unsigned caller81(unsigned long p0,unsigned long p1,unsigned p2,unsigned p3);
unsigned caller82(unsigned long p0,unsigned long p1,unsigned long p2,unsigned p3);
void caller83(unsigned long p0,unsigned p1,unsigned p2,unsigned p3);
unsigned caller84(unsigned p0,unsigned long p1,unsigned p2,unsigned p3,unsigned long p4);
unsigned caller85(unsigned long p0,unsigned p1,unsigned p2,unsigned long p3,unsigned p4);
void caller86(unsigned p0,unsigned long p1,unsigned p2,unsigned p3,unsigned long p4);
unsigned long caller87(unsigned p0,unsigned long p1,unsigned long p2,unsigned p3,unsigned long p4);
void caller88(unsigned long p0,unsigned long p1,unsigned long p2,unsigned p3,unsigned p4);
unsigned long caller89(unsigned p0,unsigned p1,unsigned p2,unsigned long p3,unsigned p4);
void caller90(unsigned p0,unsigned p1,unsigned p2,unsigned p3,unsigned long p4);
unsigned long caller91(unsigned long p0,unsigned long p1,unsigned p2,unsigned long p3,unsigned p4,unsigned p5);
unsigned caller92(unsigned p0,unsigned p1,unsigned long p2,unsigned p3,unsigned p4,unsigned long p5);
unsigned long caller93(unsigned p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned long p4,unsigned p5);
unsigned caller94(unsigned p0,unsigned long p1,unsigned p2,unsigned p3,unsigned p4,unsigned p5);
void caller95(unsigned p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned long p4,unsigned long p5);
int main(void){struct N child={0,0,29},node={0,&child,11};caller0();
caller1();
caller2();
caller3();
caller4();
caller5();
caller6();
caller7(8);
caller8(9);
caller9(10);
caller10(11);
caller11(12);
caller12(13);
caller13(14);
caller14(15,30);
caller15(16,32);
caller16(17,34);
caller17(18,36);
caller18(19,38);
caller19(20,40);
caller20(21,42);
caller21(22,44,66);
caller22(23,46,69);
caller23(24,48,72);
caller24(25,50,75);
caller25(26,52,78);
caller26(27,54,81);
caller27(28,56,84);
caller28(29,58,87,116);
caller29(30,60,90,120);
caller30(31,62,93,124);
caller31(32,64,96,128);
caller32(33,66,99,132);
caller33(34,68,102,136);
caller34(35,70,105,140);
caller35(36,72,108,144,180);
caller36(37,74,111,148,185);
caller37(38,76,114,152,190);
caller38(39,78,117,156,195);
caller39(40,80,120,160,200);
caller40(41,82,123,164,205);
caller41(42,84,126,168,210);
caller42(43,86,129,172,215,258);
caller43(44,88,132,176,220,264);
caller44(45,90,135,180,225,270);
caller45(46,92,138,184,230,276);
caller46(47,94,141,188,235,282);
caller47(48,96,144,192,240,288);
caller48(49,98,147,196,245,294);
caller49();
caller50();
caller51();
caller52();
caller53();
caller54();
caller55();
caller56(57);
caller57(58);
caller58(59);
caller59(60);
caller60(61);
caller61(62);
caller62(63);
caller63(64,128);
caller64(65,130);
caller65(66,132);
caller66(67,134);
caller67(68,136);
caller68(69,138);
caller69(70,140);
caller70(71,142,213);
caller71(72,144,216);
caller72(73,146,219);
caller73(74,148,222);
caller74(75,150,225);
caller75(76,152,228);
caller76(77,154,231);
caller77(78,156,234,312);
caller78(79,158,237,316);
caller79(80,160,240,320);
caller80(81,162,243,324);
caller81(82,164,246,328);
caller82(83,166,249,332);
caller83(84,168,252,336);
caller84(85,170,255,340,425);
caller85(86,172,258,344,430);
caller86(87,174,261,348,435);
caller87(88,176,264,352,440);
caller88(89,178,267,356,445);
caller89(90,180,270,360,450);
caller90(91,182,273,364,455);
caller91(92,184,276,368,460,552);
caller92(93,186,279,372,465,558);
caller93(94,188,282,376,470,564);
caller94(95,190,285,380,475,570);
caller95(96,192,288,384,480,576);printf("%lu\n",seen);return 0;}