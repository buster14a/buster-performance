#include <stdio.h>
struct N{unsigned long before;struct N*next;unsigned n;};unsigned long seen=9;
unsigned callee288(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
void callee289(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned long callee290(unsigned a0,unsigned long a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee291(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee292(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee293(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3,unsigned long a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee294(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee295(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
void callee296(unsigned long a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned callee297(unsigned a0,unsigned long a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee298(unsigned long a0,unsigned long a1,unsigned long a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee299(unsigned a0,unsigned long a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee300(unsigned long a0,unsigned long a1,unsigned long a2,unsigned a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee301(void){seen=seen*1099511628211UL+17UL;}
void callee302(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned long callee303(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
void callee304(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee305(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee306(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee307(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee308(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee309(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
void callee310(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
void callee311(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee312(unsigned a0,unsigned a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee313(unsigned a0,unsigned long a1,unsigned a2,unsigned long a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee314(unsigned a0,unsigned a1,unsigned a2,unsigned long a3,unsigned a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee315(void){seen=seen*1099511628211UL+17UL;}
void callee316(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
void callee317(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned long callee318(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee319(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee320(unsigned a0,unsigned a1,unsigned long a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee321(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned callee322(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee323(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned long callee324(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned long callee325(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee326(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee327(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee328(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee329(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee330(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
void callee331(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
unsigned long callee332(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee333(unsigned a0,unsigned long a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee334(unsigned a0,unsigned a1,unsigned long a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee335(unsigned a0,unsigned a1,unsigned a2,unsigned long a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee336(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee337(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned long callee338(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee339(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee340(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee341(unsigned a0,unsigned long a1,unsigned long a2,unsigned long a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee342(unsigned a0,unsigned long a1,unsigned a2,unsigned long a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee343(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned long callee344(unsigned long a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
void callee345(unsigned long a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
void callee346(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee347(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee348(unsigned long a0,unsigned long a1,unsigned long a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee349(unsigned a0,unsigned long a1,unsigned a2,unsigned long a3,unsigned long a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee350(void){seen=seen*1099511628211UL+17UL;}
void callee351(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned long callee352(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
void callee353(unsigned a0,unsigned long a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee354(unsigned a0,unsigned a1,unsigned long a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned long callee355(unsigned a0,unsigned a1,unsigned long a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee356(unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee357(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee358(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned callee359(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned callee360(unsigned a0,unsigned long a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee361(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee362(unsigned a0,unsigned long a1,unsigned a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
void callee363(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3,unsigned long a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee364(void){seen=seen*1099511628211UL+17UL;return 17UL;}
unsigned callee365(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
unsigned callee366(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
void callee367(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned long callee368(unsigned a0,unsigned a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee369(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3,unsigned a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned long callee370(unsigned a0,unsigned long a1,unsigned a2,unsigned long a3,unsigned a4,unsigned a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
unsigned long callee371(void){seen=seen*1099511628211UL+17UL;return 17UL;}
void callee372(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;}
unsigned long callee373(unsigned a0,unsigned a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;return 17UL+9UL*a0+17UL*a1;}
unsigned long callee374(unsigned a0,unsigned a1,unsigned long a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;return 17UL+9UL*a0+17UL*a1+25UL*a2;}
void callee375(unsigned a0,unsigned a1,unsigned long a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
void callee376(unsigned a0,unsigned long a1,unsigned a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned callee377(unsigned a0,unsigned long a1,unsigned long a2,unsigned a3,unsigned long a4,unsigned long a5){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4+49UL*a5;}
void callee378(void){seen=seen*1099511628211UL+17UL;}
unsigned callee379(unsigned a0){seen=seen*1099511628211UL+17UL+9UL*a0;return 17UL+9UL*a0;}
void callee380(unsigned a0,unsigned long a1){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1;}
void callee381(unsigned a0,unsigned a1,unsigned a2){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2;}
unsigned callee382(unsigned a0,unsigned long a1,unsigned a2,unsigned a3){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3;}
unsigned callee383(unsigned a0,unsigned a1,unsigned long a2,unsigned a3,unsigned long a4){seen=seen*1099511628211UL+17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;return 17UL+9UL*a0+17UL*a1+25UL*a2+33UL*a3+41UL*a4;}
unsigned caller288(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned p4,unsigned long p5);
void caller289(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned long p4,unsigned long p5);
unsigned long caller290(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned p4,unsigned long p5);
unsigned long caller291(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned p4,unsigned long p5);
unsigned caller292(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3,unsigned long p4,unsigned long p5);
void caller293(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned p4,unsigned long p5);
unsigned caller294(void);
unsigned caller295(void);
void caller296(void);
unsigned caller297(void);
unsigned caller298(void);
unsigned caller299(void);
void caller300(void);
void caller301(unsigned long p0);
void caller302(struct N* p0);
unsigned long caller303(struct N* p0);
void caller304(struct N* p0);
unsigned caller305(struct N* p0);
void caller306(struct N* p0);
unsigned long caller307(struct N* p0);
unsigned caller308(unsigned p0,unsigned long p1);
unsigned caller309(struct N* p0,unsigned p1);
void caller310(struct N* p0,unsigned p1);
void caller311(struct N* p0,unsigned p1);
void caller312(struct N* p0,unsigned p1);
unsigned caller313(struct N* p0,unsigned long p1);
unsigned caller314(struct N* p0,unsigned long p1);
void caller315(unsigned long p0,unsigned p1,unsigned long p2);
void caller316(struct N* p0,unsigned p1,unsigned long p2);
void caller317(struct N* p0,unsigned p1,unsigned p2);
unsigned long caller318(struct N* p0,unsigned long p1,unsigned p2);
unsigned caller319(struct N* p0,unsigned p1,unsigned long p2);
void caller320(struct N* p0,unsigned p1,unsigned long p2);
unsigned long caller321(struct N* p0,unsigned long p1,unsigned long p2);
unsigned caller322(unsigned long p0,unsigned long p1,unsigned long p2,unsigned long p3);
unsigned long caller323(struct N* p0,unsigned long p1,unsigned p2,unsigned long p3);
unsigned long caller324(struct N* p0,unsigned p1,unsigned p2,unsigned long p3);
unsigned long caller325(struct N* p0,unsigned p1,unsigned p2,unsigned p3);
unsigned caller326(struct N* p0,unsigned p1,unsigned p2,unsigned p3);
void caller327(struct N* p0,unsigned long p1,unsigned p2,unsigned long p3);
unsigned caller328(struct N* p0,unsigned p1,unsigned p2,unsigned p3);
unsigned long caller329(unsigned p0,unsigned p1,unsigned p2,unsigned p3,unsigned p4);
void caller330(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned p4);
void caller331(struct N* p0,unsigned long p1,unsigned long p2,unsigned long p3,unsigned long p4);
unsigned long caller332(struct N* p0,unsigned long p1,unsigned long p2,unsigned long p3,unsigned p4);
unsigned caller333(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned long p4);
unsigned long caller334(struct N* p0,unsigned p1,unsigned p2,unsigned long p3,unsigned p4);
void caller335(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned long p4);
unsigned long caller336(unsigned p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned long p4,unsigned long p5);
unsigned long caller337(struct N* p0,unsigned p1,unsigned p2,unsigned long p3,unsigned long p4,unsigned long p5);
unsigned long caller338(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned p4,unsigned p5);
unsigned caller339(struct N* p0,unsigned p1,unsigned long p2,unsigned p3,unsigned p4,unsigned long p5);
void caller340(struct N* p0,unsigned long p1,unsigned long p2,unsigned long p3,unsigned long p4,unsigned long p5);
void caller341(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned long p4,unsigned long p5);
unsigned long caller342(struct N* p0,unsigned p1,unsigned long p2,unsigned p3,unsigned long p4,unsigned long p5);
unsigned long caller343(void);
unsigned long caller344(void);
void caller345(void);
void caller346(void);
unsigned long caller347(void);
unsigned long caller348(void);
void caller349(void);
void caller350(unsigned long p0);
void caller351(struct N* p0);
unsigned long caller352(struct N* p0);
void caller353(struct N* p0);
unsigned caller354(struct N* p0);
unsigned long caller355(struct N* p0);
void caller356(struct N* p0);
unsigned long caller357(unsigned long p0,unsigned p1);
void caller358(struct N* p0,unsigned p1);
unsigned caller359(struct N* p0,unsigned long p1);
unsigned caller360(struct N* p0,unsigned long p1);
unsigned caller361(struct N* p0,unsigned p1);
unsigned caller362(struct N* p0,unsigned p1);
void caller363(struct N* p0,unsigned long p1);
unsigned long caller364(unsigned long p0,unsigned long p1,unsigned p2);
unsigned caller365(struct N* p0,unsigned p1,unsigned long p2);
unsigned caller366(struct N* p0,unsigned long p1,unsigned p2);
void caller367(struct N* p0,unsigned p1,unsigned p2);
unsigned long caller368(struct N* p0,unsigned p1,unsigned long p2);
unsigned caller369(struct N* p0,unsigned p1,unsigned long p2);
unsigned long caller370(struct N* p0,unsigned long p1,unsigned long p2);
unsigned long caller371(unsigned p0,unsigned long p1,unsigned long p2,unsigned p3);
void caller372(struct N* p0,unsigned long p1,unsigned p2,unsigned long p3);
unsigned long caller373(struct N* p0,unsigned long p1,unsigned long p2,unsigned p3);
unsigned long caller374(struct N* p0,unsigned long p1,unsigned long p2,unsigned long p3);
void caller375(struct N* p0,unsigned long p1,unsigned long p2,unsigned long p3);
void caller376(struct N* p0,unsigned p1,unsigned long p2,unsigned p3);
unsigned caller377(struct N* p0,unsigned p1,unsigned long p2,unsigned long p3);
void caller378(unsigned long p0,unsigned p1,unsigned long p2,unsigned long p3,unsigned p4);
unsigned caller379(struct N* p0,unsigned p1,unsigned p2,unsigned p3,unsigned long p4);
void caller380(struct N* p0,unsigned long p1,unsigned p2,unsigned p3,unsigned long p4);
void caller381(struct N* p0,unsigned p1,unsigned long p2,unsigned p3,unsigned long p4);
unsigned caller382(struct N* p0,unsigned p1,unsigned p2,unsigned long p3,unsigned long p4);
unsigned caller383(struct N* p0,unsigned p1,unsigned long p2,unsigned p3,unsigned long p4);
int main(void){struct N child={0,0,29},node={0,&child,11};caller288(&node,578,867,1156,1445,1734);
caller289(&node,580,870,1160,1450,1740);
caller290(&node,582,873,1164,1455,1746);
caller291(&node,584,876,1168,1460,1752);
caller292(&node,586,879,1172,1465,1758);
caller293(&node,588,882,1176,1470,1764);
caller294();
caller295();
caller296();
caller297();
caller298();
caller299();
caller300();
caller301(302);
caller302(&node);
caller303(&node);
caller304(&node);
caller305(&node);
caller306(&node);
caller307(&node);
caller308(309,618);
caller309(&node,620);
caller310(&node,622);
caller311(&node,624);
caller312(&node,626);
caller313(&node,628);
caller314(&node,630);
caller315(316,632,948);
caller316(&node,634,951);
caller317(&node,636,954);
caller318(&node,638,957);
caller319(&node,640,960);
caller320(&node,642,963);
caller321(&node,644,966);
caller322(323,646,969,1292);
caller323(&node,648,972,1296);
caller324(&node,650,975,1300);
caller325(&node,652,978,1304);
caller326(&node,654,981,1308);
caller327(&node,656,984,1312);
caller328(&node,658,987,1316);
caller329(330,660,990,1320,1650);
caller330(&node,662,993,1324,1655);
caller331(&node,664,996,1328,1660);
caller332(&node,666,999,1332,1665);
caller333(&node,668,1002,1336,1670);
caller334(&node,670,1005,1340,1675);
caller335(&node,672,1008,1344,1680);
caller336(337,674,1011,1348,1685,2022);
caller337(&node,676,1014,1352,1690,2028);
caller338(&node,678,1017,1356,1695,2034);
caller339(&node,680,1020,1360,1700,2040);
caller340(&node,682,1023,1364,1705,2046);
caller341(&node,684,1026,1368,1710,2052);
caller342(&node,686,1029,1372,1715,2058);
caller343();
caller344();
caller345();
caller346();
caller347();
caller348();
caller349();
caller350(351);
caller351(&node);
caller352(&node);
caller353(&node);
caller354(&node);
caller355(&node);
caller356(&node);
caller357(358,716);
caller358(&node,718);
caller359(&node,720);
caller360(&node,722);
caller361(&node,724);
caller362(&node,726);
caller363(&node,728);
caller364(365,730,1095);
caller365(&node,732,1098);
caller366(&node,734,1101);
caller367(&node,736,1104);
caller368(&node,738,1107);
caller369(&node,740,1110);
caller370(&node,742,1113);
caller371(372,744,1116,1488);
caller372(&node,746,1119,1492);
caller373(&node,748,1122,1496);
caller374(&node,750,1125,1500);
caller375(&node,752,1128,1504);
caller376(&node,754,1131,1508);
caller377(&node,756,1134,1512);
caller378(379,758,1137,1516,1895);
caller379(&node,760,1140,1520,1900);
caller380(&node,762,1143,1524,1905);
caller381(&node,764,1146,1528,1910);
caller382(&node,766,1149,1532,1915);
caller383(&node,768,1152,1536,1920);printf("%lu\n",seen);return 0;}