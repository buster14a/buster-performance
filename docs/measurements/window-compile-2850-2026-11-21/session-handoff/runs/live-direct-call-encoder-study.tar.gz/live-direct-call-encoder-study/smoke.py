import os,subprocess,hashlib,sys
from pathlib import Path
d=Path(__file__).resolve().parent; allenv=dict(BUSTER_PARSE_LIVE_FOREST='1',BUSTER_LIVE_CHECKED_INPUT='1',BUSTER_LIVE_NATIVE_PROGRAMS='1',BUSTER_LIVE_OWN_PROGRAMS='1',BUSTER_PARSE_LIVE_AUDIT='1',BUSTER_CONTROL_SOURCE_AUDIT='1',BUSTER_CONTROL_EARLY_AUDIT='1')
f=d/'calls.c'
f.write_text('''extern int add(int,int);
extern int sub(int a,int b);
int forward(int a,int b){return add(a,b);}
int combo(int a,int b){return add(a,b)+sub(b,a);}
int nested(int a,int b){return add(a,sub(b,a));}
int controlled(int a,int b){if(a>b){return add(a,b);}else{return sub(a,b);}}
int localcall(int a,int b){int x=add(a,b);return x+b;}
int natural(int a,int b){return forward(a,b);}
'''+(d.parent/'live-owned-native-study/padded.c').read_text().split('#define CUT0',1)[1].join(['#define CUT0','']))
for name,env,cc in [('clean',{},d.parent/'main-fbef-clean/build/compiler'),('native',allenv,d/'compiler')]:
 r=subprocess.run([cc,'--lanes','1','-c',f,'-o',d/f'{name}.o'],capture_output=True,env=os.environ|env);(d/f'{name}.stderr').write_bytes(r.stderr); print(name,r.returncode,(hashlib.sha256((d/f'{name}.o').read_bytes()).hexdigest() if (d/f'{name}.o').exists() else ''),r.stderr[:100])
