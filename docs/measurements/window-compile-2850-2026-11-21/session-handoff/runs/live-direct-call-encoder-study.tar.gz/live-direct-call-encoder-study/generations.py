from pathlib import Path
import subprocess,os,sys,csv,random,hashlib,collections
d=Path(__file__).resolve().parent;w=d.parent;t=d/'generated';t.mkdir(exist_ok=True)
e=os.environ|dict(BUSTER_PARSE_LIVE_FOREST='1',BUSTER_LIVE_CHECKED_INPUT='1',BUSTER_LIVE_NATIVE_PROGRAMS='1',BUSTER_LIVE_OWN_PROGRAMS='1',BUSTER_PARSE_LIVE_AUDIT='1',BUSTER_LIVE_VERIFY_WRAPPERS='1',BUSTER_CONTROL_SOURCE_AUDIT='1')
pad='#define CUT0'+(w/'live-owned-native-study/padded.c').read_text().split('#define CUT0',1)[1]
rng=random.Random(285021);sums=[];fail=[];allforms=[]
for batch in range(6):
 funcs=[];defs=[];main=[];forms={}
 for ix in range(96):
  i=batch*96+ix;nn=i%7;np=(i//7)%7;types=[rng.choice(['unsigned','unsigned long']) for _ in range(np)]
  args=[];argtypes=[]
  for j in range(nn):
   field=(batch>=3 and np>0 and j==0)
   if field: ty='unsigned';arg='p0->n';types[0]='struct N*'
   elif np and rng.randrange(4):
    q=rng.randrange(np);ty=types[q]
    if ty=='struct N*':ty='unsigned';arg='p%d->n'%q
    else:arg=f'p{q}'
   else:
    ty=rng.choice(['unsigned','unsigned long']);arg=f"{rng.choice([0,1,17,5678])}{'UL' if 'long' in ty else 'U'}"
   args.append(arg);argtypes.append(ty)
  if 'struct N*' in types and ix%9==0 and nn:
   if args[0]=='p0->n':args[0]='p0->next->n'
  ret=rng.choice(['unsigned','unsigned long','void']);callee=f'callee{i}';caller=f'caller{i}'; at=','.join(f'{q} a{k}' for k,q in enumerate(argtypes)) or 'void';pt=','.join(f'{q} p{k}' for k,q in enumerate(types)) or 'void'
  proto=f'{ret} {callee}({at})';sig=f'{ret} {caller}({pt})';args_=', '.join(args)
  body=sig+'{'+('return ' if ret!='void' else '')+f'{callee}({args_});'+'}'
  funcs +=[proto+';',body];value='17UL'+''.join(f'+{8*k+9}UL*a{k}' for k in range(nn))
  defs +=[proto+'{seen=seen*1099511628211UL+'+value+';'+('return '+value+';' if ret!='void' else '')+'}']
  driverargs=','.join(('&node' if q=='struct N*' else str((i+1)*(k+1))) for k,q in enumerate(types));main.append(f'{caller}({driverargs});');forms[caller]=body;allforms.append([batch,caller,nn,np,body])
 normal=t/f'b{batch}.c';link=t/f'b{batch}-main.c';normal.write_text('struct N{unsigned long before;struct N*next;unsigned n;};\n'+'\n'.join(funcs)+'\n'+pad);protos=[v.split('{')[0]+';' for v in forms.values()];link.write_text('#include <stdio.h>\nstruct N{unsigned long before;struct N*next;unsigned n;};unsigned long seen=9;\n'+'\n'.join(defs+protos)+'\nint main(void){struct N child={0,0,29},node={0,&child,11};'+'\n'.join(main)+'printf("%lu\\n",seen);return 0;}')
 outputs={};objects={};data=[];crit=[]
 for arm,cc,flags,env in [('ordinary',w/'main-fbef-clean/build/compiler',['--lanes','1'],os.environ),('source',d/'compiler',['--lanes','1'],e),('clang','clang',[],os.environ)]:
  o=t/f'b{batch}.{arm}.o';r=subprocess.run([cc,*flags,'-c',normal,'-o',o],env=env,capture_output=True);(t/f'b{batch}.{arm}.stderr').write_bytes(r.stderr);assert r.returncode==0
  objs=o.read_bytes();objects[arm]=hashlib.sha256(objs).hexdigest();exe=t/f'b{batch}-{arm}';subprocess.run(['clang','-no-pie',link,o,'-o',exe],check=True);outputs[arm]=subprocess.check_output([exe]).decode().strip()
  if arm=='source':
   rows=[x.split() for x in r.stderr.decode().splitlines()];name={x[1]:x[2] for x in rows if x[0]=='early-native-bytes'};own={x[1] for x in rows if x[0]=='early-native-owned'};late={x[1] for x in rows if x[0]=='early-native-used'};data=[x for x in rows if x[0]=='early-direct-oracle'];crit=[x for x in data if x[1] in own|late]
   for x in data:
    if x[2]!='1':fail.append([batch,*x[1:],name[x[1]],forms[name[x[1]]],int(x[1] in own),int(x[1] in late)])
 sums.append([batch,len(funcs)//2,len(data),sum(x[2]=='1' for x in data),len(crit),int(objects['source']==objects['ordinary']),len(set(outputs.values()))==1,*[outputs[k] for k in ('ordinary','clang','source')]])
def put(f,rows):
 with (d/f).open('w') as fp:wr=csv.writer(fp,delimiter='\t');wr.writerows(rows)
put('generations.tsv',[['batch','wrappers','direct','typed-oracle-exact','direct-used','exact-ELF','exact-linked','ordinary','clang','source'],*sums]);put('generated-failures.tsv',[['batch','open','matches','normal-length','direct-length','caller','source','whole','late'],*fail]);put('forms.tsv',[['batch','caller','outgoing','incoming','source'],*allforms]);print(sums, len(fail))
