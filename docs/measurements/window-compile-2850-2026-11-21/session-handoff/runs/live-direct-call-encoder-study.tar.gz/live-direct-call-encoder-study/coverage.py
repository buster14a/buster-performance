from pathlib import Path
import sys,csv,collections,hashlib
d=Path(__file__).resolve().parent;w=d.parent;sys.path.insert(0,str(w/'live-native-cfg-study'));from proofs import syms
rows=[];unique=[]
for j in ['sqlite','main']:
 a=[x.split('\t') for x in (d/f'{j}.audit.stderr').read_text().splitlines()]
 before=[x.split('\t') for x in (d/f'{j}.graph.stderr').read_text().splitlines()]
 direct={int(x[1]):x for x in a if x[0]=='early-direct-call'}; proof={int(x[1]):x for x in a if x[0]=='early-direct-oracle'}
 assert direct.keys()==proof.keys() and all(x[2]=='1' for x in proof.values())
 whole={int(x[1]):x for x in a if x[0]=='early-native-owned'};late={int(x[1]):x for x in a if x[0]=='early-native-used'}
 lower={int(x[1]):int(x[2]) for x in a if x[0]=='control-source-function'};graph={int(x[1]):int(x[2]) for x in a if x[0]=='early-native-body-graph'}
 initialgraph={int(x[1]):int(x[2]) for x in before if x[0]=='early-native-body-graph'};initialtyped={int(x[1]):int(x[3]) for x in before if x[0]=='early-native-candidate'}
 sym={int(x[1]):x for x in a if x[0]=='early-native-bytes'}
 for k,r in direct.items():
  assert int(r[5])==0 and int(r[3])>0
  if k in whole:assert graph[k]==0 and lower.get(k,0)==0
  rows.append([j,sym[k][2],k,r[2],r[3],r[4],r[5],'entire-body' if k in whole else 'ordinary-typed-check' if k in late else 'declined',initialgraph[k],graph[k],initialtyped.get(k,''),lower.get(k,0) if k in whole else initialtyped.get(k,''),proof[k][2]])
 assert (d/f'{j}.live.o').read_bytes()==(w/'source-typed-study'/f'{j}.o').read_bytes()
 unique.append([j,len(direct),sum(k in whole for k in direct),sum(k in late for k in direct),sum(initialgraph[k] for k in direct if k in whole),sum(initialtyped.get(k,0) for k in direct if k in whole),sum(int(r[4]) for k,r in direct.items() if k in whole),sum(int(r[4]) for k,r in direct.items() if k in late)])
for out,head,data in [('direct-symbols.tsv',['input','symbol','opening','PP-rows','PP-depth','machine-bytes','pre-EOF-typed-entries','final-use','ordinary-graph','final-graph','ordinary-typed','final-typed','independent-tier0-oracle-byte-ref-CFI-match'],rows),('direct-coverage.tsv',['input','direct-native-bodies','whole-owned','late-retained','whole-graph-rows-removed','whole-typed-rows-removed','whole-native-bytes','late-native-bytes'],unique)]:
 with (d/out).open('w') as f:wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(head);wr.writerows(data)
print(unique)
