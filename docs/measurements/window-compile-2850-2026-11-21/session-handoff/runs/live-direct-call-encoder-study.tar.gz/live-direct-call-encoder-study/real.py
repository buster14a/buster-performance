from pathlib import Path
import subprocess,os,hashlib,sys
d=Path(__file__).resolve().parent;w=d.parent;src=w/'switch-inputs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prefix=(w/'live-owned-native-study/timing.py').read_text().split('arms=')[0].split('sqlite=',1)[1]
exec('sqlite='+prefix)
audit=dict(BUSTER_PARSE_LIVE_FOREST='1',BUSTER_LIVE_CHECKED_INPUT='1',BUSTER_LIVE_NATIVE_PROGRAMS='1',BUSTER_LIVE_OWN_PROGRAMS='1',BUSTER_PARSE_LIVE_AUDIT='1',BUSTER_CONTROL_SOURCE_AUDIT='1',BUSTER_CONTROL_EARLY_AUDIT='1')
for job in sys.argv[1:] or ['sqlite','main']:
 for arm,env in [('graph',audit.copy()),('audit',audit),('live',{k:v for k,v in audit.items() if 'AUDIT' not in k})]:
  if arm=='graph':env.pop('BUSTER_LIVE_OWN_PROGRAMS',None)
  stem=d/f'{job}.{arm}';obj=stem.with_suffix(f'.{arm}.o')
  with open(str(stem)+'.stderr','wb') as e,open(str(stem)+'.stdout','wb') as o:r=subprocess.run([d/'compiler','--lanes','1','-c',*jobs[job],'-o',obj],stdout=o,stderr=e,env=os.environ|env,cwd=src)
  ref=w/'source-typed-study'/f'{job}.o';print(job,arm,r.returncode,sha(obj) if obj.exists() else '',sha(ref),flush=True)
