// A seal describes a body that was actually checked, lowered and emitted by the prefix compiler.
// The second reader compares its ABI and every resolved local operand before omitting expression nodes.
typedef struct CheckClosedToken
{
    TypeId type, query;
    uint32_t declaration, object, initializer, begin, end;
    uint8_t class, ignored, context, bits;
} CheckClosedToken;

typedef struct CheckClosedSeal
{
    struct CheckClosedSeal* next;
    uint32_t opening, closing, name, parameters, signature[17];
    CheckClosedToken tokens[];
} CheckClosedSeal;

static uint32_t check_seal_type(const TypeTable* types, TypeId type)
{
    if (!type) return 0;
    if (type <= BUSTER_TYPE_ULLONG && type >= BUSTER_TYPE_VOID) return type;
    if (type != type_unqualified(type) || type_kind(types, type) != BUSTER_TYPE_KIND_POINTER) return UINT32_MAX;
    const TypeId base = types->types.base[type_index(type)];
    return base >= BUSTER_TYPE_VOID && base <= BUSTER_TYPE_ULLONG ? UINT32_C(0x80000000) | base : UINT32_MAX;
}

static bool check_seal_signature(CheckInputReader* r, uint32_t opening, uint32_t name, uint32_t* signature, uint32_t* count)
{
    CheckInput* in = r->output;
    TypeTable* types = r->types;
    const TypeId fn = in->declared_types[name];
    if (!fn || !in->objects[name] || type_kind(types, fn) != BUSTER_TYPE_KIND_FUNCTION ||
        type_function_abi_kind(types, fn) != TYPE_FUNCTION_ABI_SYSV || type_function_keeps_registers(types, fn) ||
        type_function_has_parameter_abis(types, fn) ||
        (types->types.flags[type_index(fn)] & (BUSTER_TYPE_FLAG_PROTOTYPE | BUSTER_TYPE_FLAG_VARIADIC)) != BUSTER_TYPE_FLAG_PROTOTYPE ||
        (in->function_flags && (in->function_flags[name] & (CHECK_INPUT_FUNCTION_INLINE | CHECK_INPUT_FUNCTION_KR | CHECK_INPUT_FUNCTION_NAKED | CHECK_INPUT_FUNCTION_NORETURN))))
        return false;
    const TypeId* params = type_parameters(types, fn, count);
    if (*count > 16) return false;
    signature[0] = check_seal_type(types, type_return(types, fn));
    for (uint32_t i = 0; i < *count; i += 1) signature[i + 1] = check_seal_type(types, params[i]);
    for (uint32_t i = 0; i <= *count; i += 1) if (signature[i] == UINT32_MAX) return false;
    for (uint32_t i = name; i < opening; i += 1)
        if (r->parser->tokens.kinds[i] == PARSE_KIND_L_SQUARE || check_input_attributes_at(in, i)) return false;
    return true;
}

static bool check_seal_token(CheckInputReader* r, uint32_t token, uint32_t name, CheckClosedToken* out)
{
    const Parser* p = r->parser;
    const CheckInput* in = r->output;
    const uint8_t k = p->tokens.kinds[token], role = p->tree.roles[token];
    const bool simple = (k >= PARSE_KIND_L_SQUARE && k <= PARSE_KIND_COMMA && k != PARSE_KIND_ARROW &&
                         k != PARSE_KIND_ELLIPSIS && k != PARSE_KIND_PERIOD) ||
                        k == PARSE_KIND_IDENTIFIER || k == PARSE_KIND_NUMBER || k == PARSE_KIND_CHARACTER ||
                        k == PARSE_KIND_TYPE || k == PARSE_KIND_IF || k == PARSE_KIND_ELSE || k == PARSE_KIND_WHILE ||
                        k == PARSE_KIND_DO || k == PARSE_KIND_FOR || k == PARSE_KIND_CONTINUE || k == PARSE_KIND_BREAK || k == PARSE_KIND_RETURN;
    if (!simple || role == PARSE_ROLE_OPEN_CALL || check_input_attributes_at(in, token)) return false;
    const uint32_t declaration = in->declarations[token];
    if (k == PARSE_KIND_IDENTIFIER && (declaration <= name || declaration >= in->token_count ||
        r->declaration_kinds[declaration] != C_BINDING_OBJECT ||
        check_input_bit(in->declaration_bits, declaration, BUSTER_CHECK_BITS_STATIC) || !in->declared_types[token])) return false;
    *out = (CheckClosedToken){ .type = check_seal_type(r->types, in->declared_types[token]), .query = check_seal_type(r->types, r->query_types[token]),
        .declaration = declaration, .object = in->objects[token], .initializer = r->initializer_declarations[token],
        .begin = check_sparse_get(in->initializer_begins, token), .end = check_sparse_get(in->initializer_ends, token),
        .class = r->visits[token], .ignored = r->ignored[token], .context = r->constant_contexts[token], .bits = in->declaration_bits[token] };
    return out->type != UINT32_MAX && out->query != UINT32_MAX;
}

static bool check_seal_verify(CheckInputReader* r, CheckClosedSeal* seal, bool capture)
{
    const uint32_t d = check_sparse_get(r->output->body_declarations, seal->opening);
    if (d != seal->name || r->parser->tree.parents[seal->opening] != seal->closing) return false;
    uint32_t signature[17], n = 0;
    if (!check_seal_signature(r, seal->opening, d, signature, &n)) return false;
    if (capture) { seal->parameters = n; memcpy(seal->signature, signature, (n + 1) * sizeof(uint32_t)); }
    else if (seal->parameters != n || memcmp(seal->signature, signature, (n + 1) * sizeof(uint32_t))) return false;
    for (uint32_t i = seal->opening; i <= seal->closing; i += 1)
    {
        CheckClosedToken current;
        if (!check_seal_token(r, i, d, &current)) return false;
        if (capture) seal->tokens[i - seal->opening] = current;
        else if (memcmp(seal->tokens + i - seal->opening, &current, sizeof(current))) return false;
    }
    return true;
}

static void check_input_sealed_bodies(CheckInputReader* r, bool complete)
{
    CheckLiveNative* state = r->parser->live_native;
    CheckInput* in = r->output;
    if (!state || !state->seal_bodies || !complete || r->lane || r->deferred || in->deferred_tokens || in->source_bodies ||
        in->report_count || in->recovered_count || in->diagnostic_limits || in->symbol_pragmas ||
        r->types->members.first_counted_pointer || !check_source_native_output(r->pp, r->parser)) return;
    if (state->capture)
    {
        for (uint32_t open = 0; open < in->token_count; open += 1)
        {
            if (r->parser->tree.roles[open] != PARSE_ROLE_OPEN_BODY) continue;
            const uint32_t close = r->parser->tree.parents[open], d = check_sparse_get(in->body_declarations, open);
            if (close <= open || close >= in->token_count || close - open > 1024 || d >= open) continue;
            const uint64_t mark = state->storage->length;
            const size_t size = sizeof(CheckClosedSeal) + (close - open + 1) * sizeof(CheckClosedToken);
            CheckClosedSeal* seal = arena_push(state->storage, size, _Alignof(CheckClosedSeal));
            if (!seal) return;
            *seal = (CheckClosedSeal){ .opening = open, .closing = close, .name = d };
            if (check_seal_verify(r, seal, true))
            {
                if (state->seal_last) state->seal_last->next = seal;
                else state->seal_first = seal;
                state->seal_last = seal;
                state->seal_count += 1;
            }
            else arena_pop_to(state->storage, mark);
            open = close;
        }
        if (state->audit) fprintf(stderr, "pre-eof-seals\tcount=%u\n", state->seal_count);
        return;
    }
    if (!state->seal_clean || !state->seal_first) return;
    uint8_t* attributed = NULL;
    for (uint32_t first = check_input_attributed_next(in->attributes, 0, in->token_count); first < in->token_count;
         first = check_input_attributed_next(in->attributes, first + 16, in->token_count))
        for (uint32_t bits = check_input_attributed_group(in->attributes, first, in->token_count); bits; bits &= bits - 1)
        {
            const uint32_t tok = first + (uint32_t)__builtin_ctz(bits), object = in->objects[tok];
            if (!object || object > in->token_count || in->declarations[tok] != tok) continue;
            if (!attributed)
            {
                attributed = BUSTER_ARENA_PUSH_ARRAY(r->scratch, uint8_t, (uint64_t)in->token_count + 1);
                if (!attributed) return;
                memset(attributed, 0, (size_t)in->token_count + 1);
            }
            attributed[object] = 1;
        }
    for (CheckClosedSeal* seal = state->seal_first; seal; seal = seal->next)
    {
        CheckLiveFragment* row = check_live_fragment_at(state, seal->opening);
        if (!row || !row->seal_emitted || !row->native || !row->typed || row->references ||
            (attributed && attributed[in->objects[seal->name]]) || !check_seal_verify(r, seal, false)) continue;
        const CheckSourceEncoded* encoded = row->native;
        const CheckLiveScalarKey* key = row->typed;
        if (encoded->reference_count || key->shape.call_count || key->shape.table_count) continue;
        CheckSourceBodies* bodies = in->source_bodies;
        if (!bodies)
        {
            bodies = BUSTER_ARENA_PUSH_ARRAY(r->arena, CheckSourceBodies, 1);
            if (!bodies) return;
            *bodies = (CheckSourceBodies){ 0 };
        }
        if (!check_input_source_add(bodies, (CheckSourceBody){ .opening = seal->opening, .closing = seal->closing,
            .encoded = row->native }, r->arena)) return;
        in->source_bodies = bodies;
        in->source_body_output = r->arena;
        for (uint32_t i = seal->opening; i <= seal->closing; i += 1)
            if (seal->tokens[i - seal->opening].begin != BUSTER_CHECK_NONE)
            {
                check_sparse_set(in->sparse_pool, in->initializer_begins, i, BUSTER_CHECK_NONE);
                check_sparse_set(in->sparse_pool, in->initializer_ends, i, BUSTER_CHECK_NONE);
                check_sparse_set(in->sparse_pool, in->initializer_nodes, i, BUSTER_CHECK_NONE);
            }
        memset(r->visits + seal->opening, 0, (size_t)seal->closing - seal->opening + 1);
        if (state->audit) fprintf(stderr,"sealed-body-consumed\t%u\t%u\t%u\t%llu\n", seal->opening, seal->closing,
                                  key->shape.count,(unsigned long long)encoded->length);
    }
}
