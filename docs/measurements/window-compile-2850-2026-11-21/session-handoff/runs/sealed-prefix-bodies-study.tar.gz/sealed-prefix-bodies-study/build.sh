#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; cd ../sealed-prefix-bodies
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/
ln -sf ../sealed-prefix-bodies/build/compiler "$d/compiler"
