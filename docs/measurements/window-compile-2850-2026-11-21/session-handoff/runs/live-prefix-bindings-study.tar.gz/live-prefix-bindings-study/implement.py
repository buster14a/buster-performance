from pathlib import Path
s=Path(__file__).resolve().parent
w=s.parent;t=w/'live-prefix-bindings/src/buster/compiler'
def add(file,old,new):
 p=t/file;data=p.read_text();assert data.count(old)==1,(file,old)
 p.write_text(data.replace(old,new))
add('c_parser.c','    void* live_native;','    void* live_native;\n    void* live_bindings;')
add('c_check_input.c','struct CheckInputReader\n{\n    CheckSourceControlMasks* source_controls;', '''// The prefix's type table is private and is released when preprocessing resumes. A reference
// therefore retains the declaration's source token rather than a pointer or TypeId from the prefix.
typedef struct CheckLiveUseRow
{
    uint32_t token, declaration, final_event;
} CheckLiveUseRow;

typedef struct CheckLiveUseBlock CheckLiveUseBlock;
struct CheckLiveUseBlock
{
    CheckLiveUseBlock* next;
    uint32_t count;
    CheckLiveUseRow rows[128];
};

typedef struct CheckLiveUseCursor
{
    CheckLiveUseBlock* block;
    uint32_t index;
} CheckLiveUseCursor;

typedef struct CheckLiveBindings
{
    Arena* storage;
    CheckLiveUseBlock* first;
    CheckLiveUseBlock* last;
    CheckLiveUseCursor source, answers;
    uint32_t captured, last_token, source_takes, answer_takes, blocks;
    bool capture, ready, failed, reference, audit;
} CheckLiveBindings;

struct CheckInputReader
{
    CheckSourceControlMasks* source_controls;
    CheckLiveBindings* live_bindings;''')
add('c_check_attested_test.c','    { "source_controls", CHECK_ATTESTED_FIELD_OWN },','    { "source_controls", CHECK_ATTESTED_FIELD_OWN },\n    { "live_bindings", CHECK_ATTESTED_FIELD_TRANSIENT },')
marker='// The walk in source order\'s step at a name (an identifier other than a member\'s, a tag\'s or a designator\'s) that no'
add('c_check_input.c',marker,'''static CheckLiveUseRow* check_live_use_next(CheckLiveUseCursor* cursor)
{
    while (cursor->block != NULL && cursor->index == cursor->block->count)
    {
        cursor->block = cursor->block->next;
        cursor->index = 0;
    }
    return cursor->block != NULL ? &cursor->block->rows[cursor->index] : NULL;
}

static bool check_live_simple_use_type(const CheckInputReader* reader, uint32_t declaration)
{
    const TypeId type = reader->declared_types[declaration];
    const uint8_t kind = type != 0 ? type_kind(reader->types, type) : BUSTER_TYPE_KIND_NONE;
    return kind == BUSTER_TYPE_KIND_INTEGER || kind == BUSTER_TYPE_KIND_FLOATING || kind == BUSTER_TYPE_KIND_POINTER;
}

// Record the ordinary path's actual lexical use before EOF, after builtin, intrinsic and
// implicit-function handling completed. Only non-linked objects in a completed source body qualify.
static void check_live_remember_use(CheckInputReader* reader, uint32_t token, uint32_t event)
{
    CheckLiveBindings* state = reader->live_bindings;
    const CBindings* bindings = &reader->bindings;
    const uint32_t handle = bindings->previous[event];
    if (state->failed || reader->function_body == BUSTER_CHECK_NONE || token > reader->function_end ||
        reader->specifier_query_depth != 0 || token < reader->inference_end || reader->output->overload_heads != NULL ||
        reader->declared_types[token] != 0 || handle == 0 || handle > event ||
        bindings->kind[handle - 1] != C_BINDING_OBJECT || bindings->depth[handle - 1] == 0 ||
        (state->captured && token <= state->last_token)) return;
    const uint32_t declaration = bindings->declaration[handle - 1];
    if (declaration >= reader->parser->tokens.count || check_input_linkage(reader->declaration_bits, declaration) != 0 ||
        !check_live_simple_use_type(reader, declaration)) return;
    if (state->last == NULL || state->last->count == 128)
    {
        CheckLiveUseBlock* block = BUSTER_ARENA_PUSH_ARRAY(state->storage, CheckLiveUseBlock, 1);
        if (block == NULL) { state->failed = true; return; }
        block->next = NULL;
        block->count = 0;
        if (state->last != NULL) state->last->next = block;
        else state->first = block;
        state->last = block;
        state->blocks += 1;
    }
    state->last->rows[state->last->count++] = (CheckLiveUseRow){ token, declaration, BUSTER_CHECK_NONE };
    state->last_token = token;
    state->captured += 1;
}

// Reuse the pre-EOF classification in the final walk. Confirm the final scope still maps the
// actual identifier to the same local source declaration. Fresh canonical events retain exact
// ordinals for subsequent warnings, typo correction and symbol pragmas.
static bool check_live_take_use(CheckInputReader* reader, uint32_t token, uint32_t identifier)
{
    CheckLiveBindings* state = reader->live_bindings;
    CheckLiveUseRow* row = check_live_use_next(&state->source);
    while (row != NULL && row->token < token)
    {
        state->source.index += 1;
        row = check_live_use_next(&state->source);
    }
    if (row == NULL || row->token != token) return false;
    state->source.index += 1;
    if (reader->function_body == BUSTER_CHECK_NONE || token > reader->function_end || reader->output->overload_heads != NULL ||
        reader->specifier_query_depth != 0 || token < reader->inference_end || reader->output->declarations[token] != BUSTER_CHECK_NONE ||
        reader->declared_types[token] != 0 || check_input_builtin_id(reader, token) != CBUILTIN_NONE) return false;
    CBindings* bindings = &reader->bindings;
    const uint32_t handle = c_bindings_lookup(bindings, C_BINDING_ORDINARY, identifier);
    if (handle == 0 || handle > bindings->count || bindings->kind[handle - 1] != C_BINDING_OBJECT ||
        bindings->depth[handle - 1] == 0 || bindings->declaration[handle - 1] != row->declaration ||
        check_input_linkage(reader->declaration_bits, row->declaration) != 0 || !check_live_simple_use_type(reader, row->declaration)) return false;
    const uint32_t event = c_bindings_use(bindings, C_BINDING_ORDINARY, identifier, token, token);
    if (event == 0) reader->output->resource = true;
    else
    {
        row->final_event = event - 1;
        state->source_takes += 1;
    }
    return true;
}

// The type comes from the final reader's own live declaration. Previously captured types and
// invalid or ambiguous declarations retain their ordinary diagnostic and redeclaration path.
static bool check_live_publish_use(CheckInputReader* reader, const uint32_t* resolved, uint32_t event)
{
    CheckLiveBindings* state = reader->live_bindings;
    CheckLiveUseRow* row = check_live_use_next(&state->answers);
    while (row != NULL && (row->final_event == BUSTER_CHECK_NONE || row->final_event < event))
    {
        state->answers.index += 1;
        row = check_live_use_next(&state->answers);
    }
    if (row == NULL || row->final_event != event) return false;
    state->answers.index += 1;
    if (resolved != reader->bindings.previous || reader->output->invalid_count || reader->ambiguous_count ||
        reader->output->declarations[row->token] != BUSTER_CHECK_NONE || reader->declared_types[row->token] != 0 ||
        !check_live_simple_use_type(reader, row->declaration)) return false;
    reader->output->declarations[row->token] = row->declaration;
    reader->declared_types[row->token] = reader->declared_types[row->declaration];
    state->answer_takes += 1;
    return true;
}

'''+marker)
p=t/'c_check_input.c';c=p.read_text();i=c.index('static inline __attribute__((always_inline)) void check_input_resolve_name(')
old='    const uint32_t identifier = parser->tokens.names[i];'
j=c.index(old,i)+len(old)
p.write_text(c[:j]+'''
    if (reader->live_bindings != NULL && reader->live_bindings->ready && role == PARSE_ROLE_OPERAND &&
        check_live_take_use(reader, i, identifier)) return;'''+c[j:])
add('c_check_input.c','''        else if (intrinsic == CHECK_INPUT_INTRINSIC_NOT_FOUND && reader->output->declarations[i] == BUSTER_CHECK_NONE &&
                 c_bindings_use(&reader->bindings, C_BINDING_ORDINARY, identifier, i, i) == 0)
        {
            reader->output->resource = true;
        }''','''        else if (intrinsic == CHECK_INPUT_INTRINSIC_NOT_FOUND && reader->output->declarations[i] == BUSTER_CHECK_NONE)
        {
            const uint32_t handle = c_bindings_use(&reader->bindings, C_BINDING_ORDINARY, identifier, i, i);
            reader->output->resource |= handle == 0;
            if (handle != 0 && reader->live_bindings != NULL && reader->live_bindings->capture && role == PARSE_ROLE_OPERAND &&
                builtin == CBUILTIN_NONE) check_live_remember_use(reader, i, handle - 1);
        }''')
add('c_check_input.c','                check_input_resolve_range(&reader, 0, count);','''                CheckLiveBindings* binding_prefix = parser->live_bindings;
                if (binding_prefix != NULL && (binding_prefix->capture || (binding_prefix->ready && !binding_prefix->reference)) &&
                    !parser->options.scalar && !parser->prefix_view && !parser->whole_view && parser->errors == 0 &&
                    parser->recovered_types == NULL && deferred == NULL && deferred_tokens == NULL && attested == NULL &&
                    complete_translation_unit && binding_mode == CHECK_INPUT_BINDINGS_DEFAULT)
                {
                    reader.live_bindings = binding_prefix;
                }
                check_input_resolve_range(&reader, 0, count);''')
add('c_check_binding.c','''    if (events->operation[event] == C_BINDING_USE)
    {
        const uint32_t token = events->declaration[event];''','''    if (events->operation[event] == C_BINDING_USE)
    {
        if (reader->live_bindings != NULL && reader->live_bindings->ready &&
            check_live_publish_use(reader, resolved, event)) return;
        const uint32_t token = events->declaration[event];''')
add('c_checker_driver.c','''    state->capture = true;
    if (ready)''','''    CheckLiveBindings* bindings = owner->live_bindings;
    if (bindings != NULL) bindings->capture = true;
    state->capture = true;
    if (ready)''')
add('c_checker_driver.c','''    state->capture = false;
    if (state->audit)''','''    state->capture = false;
    if (bindings != NULL)
    {
        bindings->capture = false;
        bindings->ready = ready && !bindings->failed;
        bindings->source = (CheckLiveUseCursor){ bindings->first, 0 };
        bindings->answers = (CheckLiveUseCursor){ bindings->first, 0 };
        if (bindings->audit)
            fprintf(stderr, "pre-eof-bindings-captured\\trows=%u\\tcontexts=%u\\tready=%u\\tuses=%u\\tbytes=%zu\\n",
                    count, pp->context_count, bindings->ready, bindings->captured, (size_t)bindings->blocks * sizeof(CheckLiveUseBlock));
    }
    if (state->audit)''')
add('c_checker_driver.c','''                    parser->live_native = fragments;
                    parser->native_window''','''                    parser->live_native = fragments;
                    if (getenv("BUSTER_PRE_EOF_BINDINGS") != NULL)
                    {
                        CheckLiveBindings* bindings = BUSTER_ARENA_PUSH_ARRAY(&parser->live_code, CheckLiveBindings, 1);
                        if (bindings != NULL)
                        {
                            *bindings = (CheckLiveBindings){ .storage = &parser->live_code, .audit = fragments->audit,
                                .reference = getenv("BUSTER_PRE_EOF_BINDING_REFERENCE") != NULL };
                            parser->live_bindings = bindings;
                        }
                    }
                    parser->native_window''')
add('c_check_input.c','''            check_input_bindings(&reader, binding_mode);
            check_input_builtin_uses_publish(&reader);''','''            check_input_bindings(&reader, binding_mode);
            if (reader.live_bindings != NULL && reader.live_bindings->ready && reader.live_bindings->audit)
            {
                fprintf(stderr, "pre-eof-bindings-consumed\\tcaptured=%u\\tordinary-source-uses=%u\\tfinal-answers=%u\\n",
                        reader.live_bindings->captured, reader.live_bindings->source_takes, reader.live_bindings->answer_takes);
            }
            check_input_builtin_uses_publish(&reader);''')
