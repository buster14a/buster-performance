#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
d="$PWD"
cd ../live-prefix-bindings
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/predefines.h
cd "$d"
python3 capture.py >capture.log 2>&1
python3 frontiers.py >frontiers.log 2>&1
python3 directed.py >directed.log 2>&1
python3 compare.py >compare.log 2>&1
python3 ../live-pragma-parity-study/probe.py >../live-pragma-parity-study/final-reader-probe.log 2>&1
