#!/bin/bash
set -eu
d=$(cd "$(dirname "$0")" && pwd);cd "$d/../switch-inputs";tree=$PWD/../pregraph-warning-study/compiler-source
rm -f "$d/main.window.tmp"
env BUSTER_PARSE_LIVE_FOREST=1 BUSTER_LIVE_CHECKED_INPUT=1 BUSTER_LIVE_NATIVE_LEAVES=1 BUSTER_LIVE_WINDOW_FILE="$d/main.window.tmp" "$d/../live-typed-native-study/oracle-compiler" --lanes 1 -c -march=native -I"$tree/src" -fwrapv -funsigned-char --predefines "$PWD/../proof-predefines.h" "$tree/src/buster/compiler/main.c" -o "$d/main.window.o"
cmp "$d/main.window.o" "$d/main.actions.ordinary.o"
mv "$d/main.window.tmp" "$d/main.window"
