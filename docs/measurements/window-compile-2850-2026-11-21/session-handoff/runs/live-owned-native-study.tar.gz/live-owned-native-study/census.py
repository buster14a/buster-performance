from pathlib import Path
import subprocess
D=Path(__file__).resolve().parent;W=D.parent;P=W/'live-closure-observer';q=P/'src/buster/compiler/c_check_input.c'
s=subprocess.check_output(['git','show','HEAD:src/buster/compiler/c_check_input.c'],cwd=P,text=True)
key='    check_live_leaf_window(live, parser, pp, tokens, tree, begin, end);'
src='''
    if(pp->context_count!=0 && getenv("BUSTER_INPUT_CLOSURE_POPULATION"))
    {
        uint32_t start=begin;
        for(uint32_t i=begin;i<end;i++)
        {
            if(tree->parents[i]!=UINT32_MAX) continue;
            if(tree->roles[i]==PARSE_ROLE_CLOSE_BODY)
            {
                uint32_t open=start;
                while(open<i && !(tree->roles[open]==PARSE_ROLE_OPEN_BODY && tree->parents[open]==i))open++;
                uint32_t calls=0,selectors=0,stores=0,loops=0,returns=0,branches=0,cast=0;
                for(uint32_t t=open+1;t<i;t++)
                {
                    calls+=tree->roles[t]==PARSE_ROLE_OPEN_CALL;
                    selectors+=tokens->kinds[t]==PARSE_KIND_ARROW || tokens->kinds[t]==PARSE_KIND_PERIOD;
                    stores+=tree->roles[t]==PARSE_ROLE_ASSIGN;
                    loops+=tokens->kinds[t]==PARSE_KIND_WHILE || tokens->kinds[t]==PARSE_KIND_DO || tokens->kinds[t]==PARSE_KIND_FOR;
                    returns+=tokens->kinds[t]==PARSE_KIND_RETURN;
                    branches+=tokens->kinds[t]==PARSE_KIND_IF || tokens->kinds[t]==PARSE_KIND_SWITCH;
                    cast+=tree->roles[t]==PARSE_ROLE_OPEN_CAST;
                }
                fprintf(stderr,"closure-function\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\n",start,open,i,
                        pp->context_count,pp->output.count,calls,selectors,stores,loops,returns,branches,cast);
            }
            start=i+1;
        }
    }
''';assert key in s;q.write_text(s.replace(key,src+key))
with (D/'closure-observer.patch').open('w') as f:subprocess.run(['git','diff'],cwd=P,stdout=f,check=True)
it=(D/'iterate.py').read_text().replace("target=(d/'../live-owned-native').resolve()", "target=(d/'../live-closure-observer').resolve()").replace("ref=d/'probe.o';exe=d/'compiler'","ref=d/'census.o';exe=d/'census-compiler'")
(D/'iterate-census.py').write_text(it);subprocess.run(['python',D/'iterate-census.py'],check=True)
