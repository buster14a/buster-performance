#include <stdio.h>
#include <stddef.h>
typedef struct Node {unsigned char fields[72];struct Node *prior,*next;} Node;
_Static_assert(offsetof(Node,next)==80,"layout");
extern Node *findRightmost(Node*);
int main(void){Node a[]={{0},{0},{0}}; a[0].next=a+1; a[1].next=a+2;
printf("%td %td %td\n",findRightmost(a)-a,findRightmost(a+1)-a,findRightmost(a+2)-a);return 0;}
