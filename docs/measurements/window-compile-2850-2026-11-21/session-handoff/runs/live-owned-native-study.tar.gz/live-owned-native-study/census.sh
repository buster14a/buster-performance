#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs;source ../switch-local-args.sh;tree=$PWD/../pregraph-warning-study/compiler-source
for item in sqlite main;do
 case $item in sqlite)eval "args=($sqlite_arguments)";;main)args=(-march=native "-I$tree/src" -fwrapv -funsigned-char --predefines "$PWD/../proof-predefines.h" "$tree/src/buster/compiler/main.c");;esac
 env BUSTER_PARSE_LIVE_FOREST=1 BUSTER_LIVE_CHECKED_INPUT=1 BUSTER_INPUT_CLOSURE_POPULATION=1 "$d/census-compiler" --lanes 1 -c "${args[@]}" -o "$d/$item.census.o" >"$d/$item.census.stdout" 2>"$d/$item.census.stderr"
 cmp "$d/$item.census.o" "$d/$item.actions.ordinary.o"
done
