// Validate only the declaration-dependent facts that were still provisional while preprocessing.
// The expression operators and bytes were already built at closure. This path constructs no
// conventional CheckGraph, CheckStream, or lowered Tier0Function for an owned body.
static uint8_t check_live_owned_class(const TypeTable* types,TypeId type)
{
    if(type_qualifiers(type)&~(uint32_t)BUSTER_TYPE_CONST)return 0;
    type=type_unqualified(type);
    if(type_kind(types,type)==BUSTER_TYPE_KIND_POINTER)return BUSTER_TYPED_CLASS_U64;
    if(type==BUSTER_TYPE_CHAR)return types->char_unsigned?BUSTER_TYPED_CLASS_U8:BUSTER_TYPED_CLASS_I8;
    if(type==BUSTER_TYPE_SCHAR)return BUSTER_TYPED_CLASS_I8;
    if(type==BUSTER_TYPE_UCHAR)return BUSTER_TYPED_CLASS_U8;
    if(type==BUSTER_TYPE_SHORT)return BUSTER_TYPED_CLASS_I16;
    if(type==BUSTER_TYPE_USHORT)return BUSTER_TYPED_CLASS_U16;
    if(type==BUSTER_TYPE_INT)return BUSTER_TYPED_CLASS_I32;
    if(type==BUSTER_TYPE_UINT)return BUSTER_TYPED_CLASS_U32;
    if(type==BUSTER_TYPE_LONG || type==BUSTER_TYPE_LLONG)return BUSTER_TYPED_CLASS_I64;
    if(type==BUSTER_TYPE_ULONG || type==BUSTER_TYPE_ULLONG)return BUSTER_TYPED_CLASS_U64;
    return 0;
}

static bool check_live_owned_pragma(const CheckInput* in,uint32_t open,uint32_t close)
{
    const CheckInputDiagnosticPragmas* h=in->diagnostic_pragmas;
    if(!h)return false;
    uint32_t lo=0,hi=h->count;
    while(lo<hi){uint32_t mid=lo+(hi-lo)/2;if(h->records[mid].token<open)lo=mid+1;else hi=mid;}
    return (lo && h->records[lo-1].state_after!=BUSTER_CHECK_NONE) || (lo<h->count && h->records[lo].token<=close);
}

static TypeId check_live_owned_expr(CheckInputReader* r,const CheckLivePlan* p,const uint32_t* decl,uint32_t id)
{
    const CheckLiveExpr* e=p->proof+id;
    const CheckInput* in=r->output;
    const TypeTable* types=r->types;
    TypeId type=0;
    if(e->op==BUSTER_TYPED_LOCAL)
    {
        if(e->value>=p->parameters||in->declarations[e->token]!=decl[e->value])return 0;
        type=in->declared_types[decl[e->value]];
    }
    else if(e->op==BUSTER_TYPED_CONST)
    {
        uint32_t val;
        if(e->type.cls!=BUSTER_TYPED_CLASS_I32||!check_live_integer(r->pp,&r->parser->tokens,e->token,&val)||val!=e->imm)return 0;
        type=BUSTER_TYPE_INT;
    }
    else
    {
        const TypeId a=e->a?check_live_owned_expr(r,p,decl,e->a):0;
        if(!a)return 0;
        const bool pointer=type_kind(types,a)==BUSTER_TYPE_KIND_POINTER;
        if(e->op==CHECK_LIVE_MEMBER)
        {
            if(!pointer || in->noderef_member_count || in->noderef_declaration_count)return 0;
            const TypeId record=type_element(types,a);const uint32_t kind=type_kind(types,record);
            const CheckContext where={.tag_completions=r->tag_completions,.tag_completion_count=types->tags.count,.source_position=e->token};
            if((type_qualifiers(record)&~(uint32_t)BUSTER_TYPE_CONST) || (kind!=BUSTER_TYPE_KIND_STRUCT && kind!=BUSTER_TYPE_KIND_UNION) ||
               !check_context_source_complete(types,record,&where))return 0;
            uint64_t offset=0;uint32_t qualifiers=0;
            const uint32_t member=type_lookup_member(types,record,r->parser->tokens.names[e->token+1],&offset,&qualifiers);
            if(!member || member>=types->members.count || offset!=(uint64_t)e->value*8 || (qualifiers&~(uint32_t)BUSTER_TYPE_CONST) ||
               (types->members.flags[member]&BUSTER_TYPE_MEMBER_BIT_FIELD) || (in->marked_member_count &&
               check_marked_member(in->marked_members,in->marked_member_count,member)))return 0;
            type=types->members.type[member];
        }
        else if(e->op==BUSTER_TYPED_LOAD)
        {
            if(!pointer || in->noderef_member_count || in->noderef_declaration_count)return 0;
            type=type_element(types,a);
        }
        else if(e->b)
        {
            const TypeId b=check_live_owned_expr(r,p,decl,e->b);
            if(!b||pointer||type_kind(types,b)==BUSTER_TYPE_KIND_POINTER||p->proof[e->a].op==BUSTER_TYPED_CONST ||
               e->type.cls<BUSTER_TYPED_CLASS_I32 || check_live_owned_class(types,a)<BUSTER_TYPED_CLASS_I32)return 0;
            if(e->op==BUSTER_TYPED_SHL || e->op==BUSTER_TYPED_SHR)
            {
                const CheckLiveExpr* shift=p->proof+e->b;
                if(b!=BUSTER_TYPE_INT || shift->op!=BUSTER_TYPED_CONST || shift->imm>=8*check_live_width(p->proof[e->a].type))return 0;
                type=a;
            }
            else if(type_unqualified(a)==type_unqualified(b) &&
                (e->op==BUSTER_TYPED_ADD||e->op==BUSTER_TYPED_SUB||e->op==BUSTER_TYPED_MUL||e->op==BUSTER_TYPED_AND||e->op==BUSTER_TYPED_OR||e->op==BUSTER_TYPED_XOR))
                type=a;
            else if(type_unqualified(a)==type_unqualified(b) && e->op>=BUSTER_TYPED_EQ && e->op<=BUSTER_TYPED_GE)
                type=BUSTER_TYPE_INT;
            else return 0;
        }
        else return 0;
    }
    return check_live_owned_class(types,type)==e->type.cls && (type_kind(types,type)==BUSTER_TYPE_KIND_POINTER)==e->type.pointer?type:0;
}

static bool check_live_owned_body(CheckInputReader* r,const CheckLivePlan* p,const uint8_t* attributed)
{
    const CheckInput* in=r->output;const TypeTable* types=r->types;const Parser* parser=r->parser;
    const uint32_t d=check_sparse_get(in->body_declarations,p->opening);
    if(!p->proof||!p->root||!p->encoded||p->encoded->reference_count||d!=p->name_token || d>=in->token_count ||
       !in->objects[d]||in->objects[d]>in->token_count||(attributed && attributed[in->objects[d]]) ||
       (in->function_flags && (in->function_flags[d]&(CHECK_INPUT_FUNCTION_INLINE|CHECK_INPUT_FUNCTION_KR|CHECK_INPUT_FUNCTION_NAKED|CHECK_INPUT_FUNCTION_NORETURN))) ||
       check_live_owned_pragma(in,p->opening,p->closing))return false;
    for(uint32_t h=d+1;h<p->opening;h++)if(parser->tokens.kinds[h]==PARSE_KIND_L_SQUARE)return false;
    const TypeId fn=in->declared_types[d];
    if(type_kind(types,fn)!=BUSTER_TYPE_KIND_FUNCTION || type_function_abi_kind(types,fn)!=TYPE_FUNCTION_ABI_SYSV ||
       type_function_keeps_registers(types,fn)||type_function_has_parameter_abis(types,fn)||
       (types->types.flags[type_index(fn)]&(BUSTER_TYPE_FLAG_PROTOTYPE|BUSTER_TYPE_FLAG_VARIADIC))!=BUSTER_TYPE_FLAG_PROTOTYPE)return false;
    uint32_t n=0;const TypeId* params=type_parameters(types,fn,&n);uint32_t decl[CHECK_LIVE_PARAMETERS];
    if(n!=p->parameters)return false;
    for(uint32_t i=0;i<n;i++)decl[i]=UINT32_MAX;
    for(uint32_t j=check_sparse_get(in->parameters,p->opening);j!=BUSTER_CHECK_NONE;j=check_sparse_get(in->parameter_next,j))
    {
        uint32_t i=check_sparse_get(in->parameters,j);
        if(i>=n || decl[i]!=UINT32_MAX || parser->tokens.names[j]!=p->names[i] || check_input_attributes_at(in,j) ||
           check_live_owned_class(types,params[i])!=p->types[i].cls || (type_kind(types,params[i])==BUSTER_TYPE_KIND_POINTER)!=p->types[i].pointer)return false;
        decl[i]=j;
    }
    for(uint32_t i=0;i<n;i++)if(decl[i]==UINT32_MAX)return false;
    const TypeId ret=type_return(types,fn),result=check_live_owned_expr(r,p,decl,p->root);
    if(!result||check_live_owned_class(types,ret)!=p->result.cls)return false;
    if(type_unqualified(ret)==type_unqualified(result))return true;
    // The ordinary integral promotion of a narrow integer has no narrowing or pointer-conversion diagnostic.
    return ret==BUSTER_TYPE_INT && check_live_owned_class(types,result)<=BUSTER_TYPED_CLASS_U16;
}

static void check_live_publish_owned(CheckInputReader* r)
{
    CheckLiveInput* live=r->parser->live_consumer;
    if(!live || !live->owned_programs||!live->used||live->owner!=r->parser||r->visits!=live->visits||!live->programs)return;
    const CheckLivePrograms* t=live->programs;CheckInput* in=r->output;
    if(!t->count || in->source_bodies!=NULL || in->report_count || in->recovered_count || in->diagnostic_limits)return;
    // Attribute metadata is sparse; bit each affected canonical entity once even if a middle redeclaration is the attributed one.
    const uint32_t count=in->token_count;
    uint8_t* attributes=NULL;
    for(uint32_t first=check_input_attributed_next(in->attributes,0,count);first<count;first=check_input_attributed_next(in->attributes,first+16,count))
    {
        for(uint32_t mask=check_input_attributed_group(in->attributes,first,count);mask;mask&=mask-1)
        {
            const uint32_t tok=first+(uint32_t)__builtin_ctz(mask),object=in->objects[tok];
            if(!object||object>count || in->declarations[tok]!=tok)continue;
            if(!attributes){attributes=BUSTER_ARENA_PUSH_ARRAY(r->scratch,uint8_t,(uint64_t)count+1);if(!attributes)return;memset(attributes,0,(size_t)count+1);}
            attributes[object]=1;
        }
    }
    for(uint32_t i=0;i<t->count;i++)
    {
        const CheckLivePlan* p=t->plans+i;
        if(!check_live_owned_body(r,p,attributes))continue;
        CheckSourceBodies* bodies=in->source_bodies;
        if(!bodies){bodies=BUSTER_ARENA_PUSH_ARRAY(r->arena,CheckSourceBodies,1);if(!bodies)return;*bodies=(CheckSourceBodies){0};}
        if(!check_input_source_add(bodies,(CheckSourceBody){.encoded=(CheckSourceEncoded*)p->encoded,.opening=p->opening,.closing=p->closing},r->arena))return;
        in->source_bodies=bodies;in->source_body_output=r->arena;
        uint32_t visits=0;
        if(live->audit_leaves)for(uint32_t j=p->opening;j<=p->closing;j++)visits+=r->visits[j]!=0;
        memset(r->visits+p->opening,0,(size_t)p->closing-p->opening+1);
        if(live->audit_leaves)fprintf(stderr,"early-native-owned\t%u\t%u\t%u\t%u\t%llu\n",p->opening,p->closing,visits,p->count,(unsigned long long)p->encoded->length);
    }
}
