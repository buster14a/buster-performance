from pathlib import Path
p=Path(__file__).resolve().parent.parent/'live-owned-native/src/buster/compiler/c_check_live_native.c';s=p.read_text()
k='typedef struct CheckLivePlan'
s=s.replace(k,'''typedef enum CheckLiveObligationKind { CHECK_LIVE_RETURN, CHECK_LIVE_TEST, CHECK_LIVE_INIT, CHECK_LIVE_ASSIGN, CHECK_LIVE_UPDATE, CHECK_LIVE_DISCARD } CheckLiveObligationKind;
typedef struct CheckLiveObligation { uint32_t token; uint8_t kind, first, second; } CheckLiveObligation;
'''+k)
s=s.replace('    uint32_t root;', '''    uint32_t root,obligation_count;
    uint32_t declarations[CHECK_LIVE_LOCALS];
    CheckLiveObligation obligations[CHECK_LIVE_EXPRS];''')
a=s.index('static uint32_t check_live_return(')
s=s[:a]+'''static void check_live_obligation(CheckLivePlan* p,CheckLiveObligationKind kind,uint32_t token,uint32_t first,uint32_t second)
{
    if(p->obligation_count<CHECK_LIVE_EXPRS)p->obligations[p->obligation_count]=(CheckLiveObligation){.kind=(uint8_t)kind,.token=token,.first=(uint8_t)first,.second=(uint8_t)second};
    p->obligation_count++;
}

'''+s[a:]
s=s.replace('    if (t == b->plan->opening + 2', '    check_live_obligation(b->plan,CHECK_LIVE_RETURN,t-1,id,0);\n    if (t == b->plan->opening + 2')
s=s.replace('            p->names[slot] =', '            p->declarations[slot]=name;\n            p->names[slot] =')
s=s.replace('            if (set == end)\n                return true;', '''            if (set == end){check_live_obligation(p,CHECK_LIVE_INIT,name,slot,0);return true;}''')
s=s.replace('            return rhs && check_live_value(b, rhs, type.cls)', '            check_live_obligation(p,CHECK_LIVE_INIT,name,slot,rhs);\n            return rhs && check_live_value(b, rhs, type.cls)')
s=s.replace('        CheckLiveExpr* l = b->expr + lhs;', '        check_live_obligation(p,k[set]==PARSE_KIND_EQUAL?CHECK_LIVE_ASSIGN:CHECK_LIVE_UPDATE,set,lhs,rhs);\n        CheckLiveExpr* l = b->expr + lhs;')
s=s.replace('    uint8_t cls = b->expr[id].type.cls;\n    return check_live_value(b, id, cls) && check_live_put(p, BUSTER_TYPED_DISCARD', '    check_live_obligation(p,CHECK_LIVE_DISCARD,first,id,0);\n    uint8_t cls = b->expr[id].type.cls;\n    return check_live_value(b, id, cls) && check_live_put(p, BUSTER_TYPED_DISCARD')
s=s.replace('        if (!condition || !check_live_truth', '        check_live_obligation(p,CHECK_LIVE_TEST,first,condition,0);\n        if (!condition || !check_live_truth')
s=s.replace('live->owned_programs && plan.root','live->owned_programs && plan.obligation_count && plan.obligation_count<=CHECK_LIVE_EXPRS')
s=s.replace('if (!p->proof || !p->root || !p->encoded','if (!p->proof || !p->obligation_count || !p->encoded')
s=s.replace('uint32_t decl[CHECK_LIVE_PARAMETERS];','uint32_t decl[CHECK_LIVE_LOCALS];')
s=s.replace('if (e->value >= p->parameters || in->declarations[e->token] != decl[e->value])','if (e->value >= p->locals || decl[e->value]>=in->token_count || in->declarations[e->token] != decl[e->value])')
a=s.index('        uint32_t val;',s.index('static TypeId check_live_owned_expr'));z=s.index('    }',a)
s=s[:a]+'''        const uint8_t* bytes;uint32_t length;CheckLiteral literal={0};CheckWarningEvent warn;
        if(!check_input_spelling(r,e->token,&bytes,&length))return 0;
        const uint64_t mark=r->scratch->length;
        check_literal_number(bytes,length,r->scratch,&literal);
        arena_pop_to(r->scratch,mark);
        if(!literal.valid || literal.real || literal.imaginary || literal.resource || literal.bit_width || literal.high || literal.integer!=e->imm ||
           check_literal_warning_event(&literal,e->token,&warn))return 0;
        type=literal.type;
'''+s[z:]
s=s.replace('            if (e->op == BUSTER_TYPED_SHL || e->op == BUSTER_TYPED_SHR)', '''            const TypeId usual=type_usual_arithmetic(r->types,a,b);
            if(e->op>=BUSTER_TYPED_EQ && e->op<=BUSTER_TYPED_GE && p->proof[e->a].op==BUSTER_TYPED_LOCAL &&
               p->proof[e->b].op==BUSTER_TYPED_LOCAL && p->proof[e->a].value==p->proof[e->b].value)return 0;
            if (e->op == BUSTER_TYPED_SHL || e->op == BUSTER_TYPED_SHR)''')
s=s.replace('else if (type_unqualified(a) == type_unqualified(b) &&\n                     (e->op', 'else if (usual && check_live_owned_class(types,usual)==e->value &&\n                     (e->op')
s=s.replace('e->op == BUSTER_TYPED_OR || e->op == BUSTER_TYPED_XOR))\n                type = a;', 'e->op == BUSTER_TYPED_OR || e->op == BUSTER_TYPED_XOR))\n                type = usual;')
a=s.index('    const TypeId ret = type_return(types, fn), result');z=s.index('\n}',a)
s=s[:a]+'''    for(uint32_t i=n;i<p->locals;i++)decl[i]=UINT32_MAX;
    const TypeId ret=type_return(types,fn);
    if(check_live_owned_class(types,ret)!=p->result.cls)return false;
    bool returned=false;
    for(uint32_t q=0;q<p->obligation_count;q++)
    {
        const CheckLiveObligation row=p->obligations[q];
        if(row.kind==CHECK_LIVE_DISCARD)return false; // unused-value diagnostics need their ordinary expression.
        if(row.kind==CHECK_LIVE_INIT)
        {
            if(row.first<n || row.first>=p->locals || !row.second || decl[row.first]!=UINT32_MAX || p->declarations[row.first]!=row.token ||
               check_input_attributes_at(in,row.token)||in->declarations[row.token]!=row.token)return false;
            // Only automatic scalar declarations with no storage or cleanup spelling are owned.
            for(uint32_t i=row.token;i>p->opening+1 && parser->tokens.kinds[i-1]!=PARSE_KIND_SEMI && parser->tokens.kinds[i-1]!=PARSE_KIND_L_BRACE;i--)
                if(parser->tokens.kinds[i-1]==PARSE_KIND_STORAGE || parser->tokens.kinds[i-1]==PARSE_KIND_ATTRIBUTE)return false;
            TypeId init=check_live_owned_expr(r,p,decl,row.second),type=in->declared_types[row.token];
            if(!init || type_unqualified(init)!=type_unqualified(type) || check_live_owned_class(types,type)!=p->types[row.first].cls)return false;
            decl[row.first]=row.token;continue;
        }
        TypeId a=check_live_owned_expr(r,p,decl,row.first);if(!a)return false;
        if(row.kind==CHECK_LIVE_RETURN)
        {
            if(type_unqualified(ret)!=type_unqualified(a) && !(ret==BUSTER_TYPE_INT && check_live_owned_class(types,a)<=BUSTER_TYPED_CLASS_U16))return false;
            returned=true;continue;
        }
        if(row.kind==CHECK_LIVE_TEST)
        {
            if(p->proof[row.first].op==BUSTER_TYPED_CONST)return false;
            continue;
        }
        if(row.kind!=CHECK_LIVE_ASSIGN && row.kind!=CHECK_LIVE_UPDATE)return false;
        const CheckLiveExpr lhs=p->proof[row.first];
        if(lhs.op!=BUSTER_TYPED_LOCAL && lhs.op!=CHECK_LIVE_MEMBER && lhs.op!=BUSTER_TYPED_LOAD)return false;
        if(type_qualifiers(a))return false;
        if(lhs.op==CHECK_LIVE_MEMBER)
        {
            TypeId base=check_live_owned_expr(r,p,decl,lhs.a);
            if(!base || type_qualifiers(type_element(types,base)))return false;
        }
        TypeId b=check_live_owned_expr(r,p,decl,row.second);
        if(!b || type_unqualified(a)!=type_unqualified(b))return false;
        if(row.kind==CHECK_LIVE_UPDATE && (lhs.op!=BUSTER_TYPED_LOCAL || check_live_owned_class(types,a)<BUSTER_TYPED_CLASS_I32 ||
          type_kind(types,a)==BUSTER_TYPE_KIND_POINTER))return false;
        if(row.kind==CHECK_LIVE_ASSIGN && lhs.op==BUSTER_TYPED_LOCAL && p->proof[row.second].op==BUSTER_TYPED_LOCAL && lhs.value==p->proof[row.second].value)return false;
    }
    return returned;
'''+s[z:];p.write_text(s)
