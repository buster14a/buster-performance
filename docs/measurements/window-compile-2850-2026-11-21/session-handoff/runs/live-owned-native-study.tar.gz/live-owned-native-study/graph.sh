#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs;source ../switch-local-args.sh;tree=$PWD/../pregraph-warning-study/compiler-source
for what in "$@";do
 case $what in sqlite)eval "args=($sqlite_arguments)";;main)args=(-march=native "-I$tree/src" -fwrapv -funsigned-char --predefines "$PWD/../proof-predefines.h" "$tree/src/buster/compiler/main.c");;padded)args=("$d/padded.c");;esac
 cc=${LIVE_COMPILER:-$d/compiler};stem="$d/$what.graph"
 env BUSTER_PARSE_LIVE_FOREST=1 BUSTER_LIVE_CHECKED_INPUT=1 BUSTER_LIVE_NATIVE_PROGRAMS=1 BUSTER_PARSE_LIVE_AUDIT=1 "$cc" --lanes 1 -c "${args[@]}" -o "$stem.o" > "$stem.stdout" 2> "$stem.stderr"
 cmp "$stem.o" "$d/$what.owned.ordinary.o"
done
