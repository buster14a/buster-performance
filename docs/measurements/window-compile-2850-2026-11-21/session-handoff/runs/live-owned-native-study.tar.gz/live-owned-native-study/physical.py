from pathlib import Path
import csv,os,subprocess,hashlib,sys
d=Path(__file__).resolve().parent;w=d.parent;t=w/'live-owned-native';p=w/'live-owned-native-poison'
if not p.exists():subprocess.run(['git','worktree','add','--detach',p,'7ee693bb6'],cwd=t,check=True)
src=p/'src/buster/compiler/c_check_live_native.c';s=subprocess.check_output(['git','show','HEAD:src/buster/compiler/c_check_live_native.c'],cwd=p,text=True)
needle='            tbl->plans[tbl->count++] = plan;';assert needle in s
# Decoder-verified before/after choices controlled by the independently extracted baseline function extent.
with (w/'live-native-cfg-study/sqlite-native-symbols.tsv').open() as f:row=next(x for x in csv.DictReader(f,delimiter='\t') if x['name']=='findRightmost')
before=bytes.fromhex(row['native-hex']);sig=bytes.fromhex('488b40504885c0');assert before.count(sig)==1
offset=before.index(sig)+3;elf_pos=int(row['file-offset'])+offset
proof=f'''            if (getenv("BUSTER_OWNED_PROOF_MUTATE") && open=={row['opening']} && plan.encoded->length=={len(before)} && plan.encoded->bytes[{offset}]==0x50)plan.encoded->bytes[{offset}]=0x48;
            if(scratch.peak) memset(scratch.base,0xce,(size_t)scratch.peak);
'''
src.write_text(s.replace(needle,proof+needle))
with (d/'physical.patch').open('w') as f:subprocess.run(['git','diff'],cwd=p,stdout=f,check=True)
it=(d/'iterate.py').read_text().replace("target=(d/'../live-owned-native').resolve()", "target=(d/'../live-owned-native-poison').resolve()").replace("ref=d/'probe.o';exe=d/'compiler'","ref=d/'physical.o';exe=d/'physical-compiler'")
(d/'iterate-physical.py').write_text(it);subprocess.run(['python',d/'iterate-physical.py'],check=True)
harness=d/'walk.c';harness.write_text('''#include <stdio.h>
#include <stddef.h>
typedef struct Node {unsigned char fields[72];struct Node *prior,*next;} Node;
_Static_assert(offsetof(Node,next)==80,"layout");
extern Node *findRightmost(Node*);
int main(void){Node a[]={{0},{0},{0}}; a[0].next=a+1; a[1].next=a+2;
printf("%td %td %td\\n",findRightmost(a)-a,findRightmost(a+1)-a,findRightmost(a+2)-a);return 0;}
''')
srcdir=w/'switch-inputs';flags=[os.fsdecode(x) for x in subprocess.check_output(['bash','-c','source ../switch-local-args.sh;eval "args=($sqlite_arguments)"; printf "%s\\0" "${args[@]}"'],cwd=srcdir).split(b'\0')[:-1]]
env=os.environ|dict(BUSTER_PARSE_LIVE_FOREST='1', BUSTER_LIVE_CHECKED_INPUT='1', BUSTER_LIVE_NATIVE_PROGRAMS='1',BUSTER_LIVE_OWN_PROGRAMS='1',BUSTER_PARSE_LIVE_AUDIT='1',BUSTER_CONTROL_SOURCE_AUDIT='1')
ref=d/'sqlite.actions.ordinary.o';reference=ref.read_bytes();res=[]
with (d/'physical.tsv').open('w',buffering=1) as f:
 out=csv.writer(f,delimiter='\t');out.writerow(['arm','ELF-sha256','ELF-changed-bytes','raw-file-offset','owned-graph-nodes','final-typed-entries','linked-result'])
 for arm in ['ordinary','clang','poison','mutation']:
  obj=ref if arm=='ordinary' else (w/'pending-native-study/runtime/clang.o' if arm=='clang' else d/f'physical-{arm}.o')
  graph=typed=''
  if arm in ('poison','mutation'):
   cmd=[d/'physical-compiler','--lanes','1','-c',*flags,'-o',obj]
   with (d/f'physical-{arm}.stderr').open('wb') as log:subprocess.run(cmd,env=env|({'BUSTER_OWNED_PROOF_MUTATE':'1'} if arm=='mutation' else {}),cwd=srcdir,stderr=log,check=True)
   records=[l.split() for l in (d/f'physical-{arm}.stderr').read_text().splitlines()]
   graph=next(int(r[2]) for r in records if r[0]=='early-native-body-graph' and r[1]==row['opening'])
   typed=next(int(r[2]) for r in records if r[0]=='control-source-function' and r[1]==row['opening'])
   assert graph==typed==0
  glob=d/f'walk-{arm}.o';subprocess.run(['objcopy','--globalize-symbol=findRightmost',obj,glob],check=True)
  exe=d/f'walk-{arm}';subprocess.run(['clang','-no-pie',harness,glob,'-ldl','-lpthread','-lm','-o',exe],check=True)
  printout=subprocess.check_output([exe]).decode().strip();res.append(printout)
  raw=obj.read_bytes();diff=None
  if arm!='clang':
   assert len(raw)==len(reference);diff=[(pos,u,v) for pos,(u,v) in enumerate(zip(reference,raw)) if u!=v]
   assert diff==([(elf_pos,80,72)] if arm=='mutation' else []),diff[:5]
  out.writerow([arm,hashlib.sha256(raw).hexdigest(),'' if diff is None else len(diff),elf_pos,graph,typed,printout])
assert res==['2 2 2','2 2 2','2 2 2','0 1 2'],res
