from pathlib import Path
import csv,sys,hashlib
d=Path(__file__).resolve().parent;sys.path.insert(0,str(d.parent/'live-native-cfg-study'));from proofs import syms
def read(p):return [x.split('\t') for x in p.read_text().splitlines() if x]
summary=[]
for job in ['padded','sqlite','main']:
 ref=d/f'{job}.actions.ordinary.o';source=d/f'{job}.actions.live.o';audit=d/f'{job}.actions.audit.o'
 assert ref.read_bytes()==source.read_bytes()==audit.read_bytes()
 s=read(d/f'{job}.actions.audit.stderr');ctrl=read(d/f'{job}.graph.stderr')
 current={int(x[1]):int(x[2]) for x in s if x[0]=='early-native-body-graph'}
 prior={int(x[1]):int(x[2]) for x in ctrl if x[0]=='early-native-body-graph'}
 low={int(x[1]):int(x[2]) for x in s if x[0]=='control-source-function'}
 owned={int(x[1]):[int(i) for i in x[2:]] for x in s if x[0]=='early-native-owned'}
 native={int(x[1]):int(x[2]) for x in s if x[0]=='source-native-fragment'}
 after={int(x[1]) for x in s if x[0]=='early-native-used'}
 built={int(x[1]):x for x in s if x[0]=='early-native-bytes'}
 normal=syms(ref);nbefore=next(int(x[1]) for x in ctrl if x[0]=='early-native-unit-graph');nnow=next(int(x[1]) for x in s if x[0]=='early-native-unit-graph')
 assert nbefore-nnow==sum(prior[k] for k in owned),(job,nbefore,nnow,owned)
 fields=['name','opening','closing','PP-depth','PP-produced','visits-cleared','ordinary-graph-nodes','owned-graph-nodes','pre-EOF-typed-entries','final-typed-entries','machine-bytes','ordinary-symbol-file-offset','native-hex']
 with (d/f'{job}-owned-symbols.tsv').open('w') as f:
  w=csv.writer(f,delimiter='\t');w.writerow(fields)
  for k,(close,vis,typed,size) in owned.items():
   _,_,name,depth,pp,body=built[k];blob=bytes.fromhex(body);matches=[(v,off,x) for v,off,x in normal[name] if x==blob]
   assert int(depth)>0 and len(matches)==1 and k not in after and current[k]==low[k]==0 and native[close]==len(blob)==size
   w.writerow([name,k,close,depth,pp,vis,prior[k],current[k],typed,low[k],size,matches[0][1],body])
 summary.append([job,len(built),len(after),len(owned),nbefore,nnow,nbefore-nnow,sum(v[2] for v in owned.values()),sum(v[3] for v in owned.values()),hashlib.sha256(ref.read_bytes()).hexdigest()])
with (d/'adoption.tsv').open('w') as f:
 w=csv.writer(f,delimiter='\t');w.writerow(['input','physical-programs-built','late-adopted','whole-owned','ordinary-graph','owned-graph','nodes-removed','typed-entries-removed','native-bytes-owned','elf-sha256']);w.writerows(summary)
print((d/'adoption.tsv').read_text())
