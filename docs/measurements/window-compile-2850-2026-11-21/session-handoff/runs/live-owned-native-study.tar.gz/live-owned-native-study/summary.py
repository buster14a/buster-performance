from pathlib import Path
import csv,collections
D=Path(__file__).resolve().parent
def table(p):return list(csv.DictReader(p.open(),delimiter='\t'))
def write(name,fields,rows):
 with (D/name).open('w') as f:
  w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(fields);w.writerows(rows)
def census():
 data=[]
 for job in ['sqlite','main']:
  lines=[list(map(int,x.split('\t')[1:])) for x in (D/f'{job}.census.stderr').read_text().splitlines() if x.startswith('closure-function\t')]
  a=table(D/f'{job}-owned-symbols.tsv');own={int(r['opening']) for r in a}
  assert all(row[3]>0 for row in lines) and len({r[1] for r in lines})==len(lines)
  sets={'all':lines,'within-144-token-bound':[r for r in lines if r[2]-r[0]<=144],
        'above-144-token-bound':[r for r in lines if r[2]-r[0]>144], 'no-calls':[r for r in lines if r[5]==0],
        'contains-call':[r for r in lines if r[5]],'contains-loop':[r for r in lines if r[8]],'whole-owned':[r for r in lines if r[1] in own]}
  assert len(sets['whole-owned'])==len(own)
  for label,rows in sets.items():data.append([job,label,len(rows),sum(r[2]-r[1]+1 for r in rows),*[sum(r[i] for r in rows) for i in range(5,12)]])
 write('population.tsv',['workload','population','bodies','body-tokens','calls','member-selectors','assignments','loops','returns','if-or-switch','casts'],data)
def qualification(dir_):
 c=dir_/'corpus'
 if not c.exists():return
 out=[]
 for f in sorted(c.glob('*.tsv')):
  rows=table(f);match=lambda r:r['ref-exit']==r['local-exit'] and all(r[k]=='1' for k in ['obj-equal','stdout-equal','stderr-equal'])
  out.append([f.stem,len(rows),sum(map(match,rows)),sum(r['ref-exit']!='0' for r in rows)])
 write(('cfg-' if dir_!=D else '')+'corpus-total.tsv',['workload','pairs','matched','reference-rejections'],out)
if __name__=='__main__':
 census();qualification(D.parent/'live-native-cfg-study');qualification(D)
