from pathlib import Path
import csv,hashlib,os,subprocess,tempfile
d=Path(__file__).resolve().parent;g=d/'generated';rt=d/'runtime';rt.mkdir(exist_ok=True);w=d.parent
with (d/'runtime.tsv').open('w',buffering=1) as f:
 out=csv.writer(f,delimiter='\t');out.writerow(['test','arm','exit','stdout-bytes','stdout-sha256','stderr-bytes','stderr-sha256'])
 def report(test,arm,row):
  out.writerow([test,arm,row.returncode,len(row.stdout),hashlib.sha256(row.stdout).hexdigest(),len(row.stderr),hashlib.sha256(row.stderr).hexdigest()])
 for j in range(5):
  stem=f'batch{j}';src=g/(stem+'.c');clang=g/(stem+'.clang.o');subprocess.run(['clang','-w','-c',src,'-o',clang],check=True)
  ids=list(range(63,126));lines=['#include <stdio.h>','#include <stdint.h>']+[f'unsigned f{i}(unsigned,unsigned,unsigned);' for i in ids]
  lines+=['int main(void){uint64_t h=0;unsigned v[]={0,1,7,31,333,0x7fffffffU,0xffffffffU};for(unsigned k=0;k<7;k++){unsigned x=v[k];']
  lines += [f'h=h*UINT64_C(0x9e3779b97f4a7c15)+f{i}(x,x,x);' for i in ids];lines+=['}printf("%016llx\\n",(unsigned long long)h);return 0;}']
  h=g/(stem+'.main.c');h.write_text('\n'.join(lines));controls=[]
  for arm,obj in [('clang',clang),('ordinary',g/(stem+'.ordinary.o')),('source',g/(stem+'.source.o'))]:
   exe=rt/(stem+'.'+arm);subprocess.run(['clang','-no-pie',h,obj,'-o',exe],check=True);r=subprocess.run([exe],capture_output=True,timeout=4,check=True)
   report(stem,arm,r);controls.append((r.returncode,r.stdout,r.stderr))
  assert len(set(controls))==1
 shell=w/'pending-native-study/runtime/shell.o';source=d/'sqlite.actions.live.o';ordinary=w/'source-typed-study/sqlite.o';clang=w/'pending-native-study/runtime/clang.o'
 assert ordinary.read_bytes()==source.read_bytes()
 for arm,obj in [('clang',clang),('ordinary',ordinary),('source',source)]:
  exe=rt/('sqlite-'+arm);subprocess.run(['clang','-no-pie',shell,obj,'-ldl','-lpthread','-lm','-o',exe],check=True)
 for test in ['core','dotcommands','files','queries']:
  sql=w/'pending-native-study/queries.sql' if test=='queries' else w/'pending-native-windows/tests/sqlite'/(test+'.sql')
  controls=[]
  for arm in ['clang','ordinary','source']:
   with tempfile.TemporaryDirectory(dir=rt) as wd:
    r=subprocess.run([rt/('sqlite-'+arm),'-batch',':memory:'],input=sql.read_bytes(),cwd=wd,capture_output=True,timeout=30)
   report(test,arm,r);controls.append((r.returncode,r.stdout,r.stderr))
   (rt/(test+'.'+arm+'.stdout')).write_bytes(r.stdout);(rt/(test+'.'+arm+'.stderr')).write_bytes(r.stderr)
  assert len(set(controls))==1,(test,str(controls)[:300])
