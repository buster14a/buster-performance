from pathlib import Path
import csv,os,random,subprocess,sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'live-native-cfg-study'));from proofs import syms
d=Path(__file__).resolve().parent;g=d/'generated';g.mkdir(exist_ok=True)
reference=d.parent/'main-fbef-clean/build/compiler';cc=Path(os.environ.get('LIVE_QA_COMPILER',d/'checker-7ee693bb6'))
seed=2850;rng=random.Random(seed)
with (d/'generative.tsv').open('w',buffering=1) as f:
 out=csv.writer(f,delimiter='\t');out.writerow(['batch','count','written','object-equal','stdout-equal','stderr-equal','owned','differing-symbols'])
 for batch in range(5):
  code=['typedef unsigned U;typedef unsigned long L;struct S{int x;unsigned y;long z;struct S*next;};'];shapes=[];idx=0
  for ty in ['int','unsigned','long','unsigned long']:
   for b in range(63):
    names=['x','y','z'];op=rng.choice(['+','-','*','|','^','&']);v=rng.choice(['0','1','2','7','41','126','0x4a','1u','0x12345ul','2147483647','0xffffffffU'])
    a=rng.choice(names);b0=rng.choice(names)
    expr=rng.choice([f'({a}{op}{b0}){op}({v})',f'({a}>>{rng.randrange(0,28)}){op}{b0}',f'{a}{op}({b0}{op}{v})',f'{a}{op}({a}>>{rng.randrange(4,22)})',f'{a} {rng.choice(["==","!=","<","<=",">",">="])} {b0}'])
    codepath=rng.choice([f'return {expr};',f'{ty} t={expr};return t;',f'if({a}<{b0})return {expr};return {b0};',f'{ty} t={a};t {rng.choice(["+=","^=","|="])} {b0};return t;',f'while({a}>{b0}){a}-=2;return {b0};',f'{a}={expr};return {a};'])
    name=f'f{idx}';src=f'{ty} {name}({ty} x,{ty} y,{ty} z){{{codepath}}}';code.append(src);shapes.append((name,src));idx+=1
  for b in range(20):
   name=f'f{idx}';src=rng.choice([f'struct S*{name}(struct S*p){{while(p->next)p=p->next;return p;}}',f'int {name}(const struct S*p){{return p->next->x;}}',f'long {name}(struct S*p){{long a=p->z;a^=a>>5;p->z=a;return a;}}',f'unsigned {name}(struct S*p){{if(p->y)return p->y;return 7U;}}'])
   code.append(src);shapes.append((name,src));idx+=1
  pad=(d/'padded.c').read_text().split('extern int u0;',1)[1];src=g/f'batch{batch}.c';src.write_text('\n'.join(code)+'\nextern int u0;'+pad)
  res=[]
  for mode,driver,extra in [('ordinary',reference,{}),('source',cc,{'BUSTER_PARSE_LIVE_FOREST':'1','BUSTER_LIVE_CHECKED_INPUT':'1','BUSTER_LIVE_NATIVE_PROGRAMS':'1','BUSTER_LIVE_OWN_PROGRAMS':'1'}),('audit',cc,{'BUSTER_PARSE_LIVE_FOREST':'1','BUSTER_LIVE_CHECKED_INPUT':'1','BUSTER_LIVE_NATIVE_PROGRAMS':'1','BUSTER_LIVE_OWN_PROGRAMS':'1','BUSTER_PARSE_LIVE_AUDIT':'1'})]:
   obj=g/f'batch{batch}.{mode}.o';result=subprocess.run([driver,'--lanes','1','-c',src,'-o',obj],env=os.environ|extra,capture_output=True,check=True);(g/f'batch{batch}.{mode}.stderr').write_bytes(result.stderr);res.append((obj,result.stdout,result.stderr))
  (a,ao,ae),(b,bo,be),(c,co,ce)=res;xs,ys=syms(a),syms(b);bad=[(n,s,xs[n][0][2].hex(),ys[n][0][2].hex()) for n,s in shapes if xs[n][0][2]!=ys[n][0][2]]
  if bad:
   with (g/f'batch{batch}.diff.tsv').open('w') as df:csv.writer(df,delimiter='\t').writerows(bad)
  out.writerow([batch,len(shapes),len(xs),int(a.read_bytes()==b.read_bytes()==c.read_bytes()),int(ao==bo),int(ae==be),ce.count(b'early-native-owned\t'),len(bad)])
