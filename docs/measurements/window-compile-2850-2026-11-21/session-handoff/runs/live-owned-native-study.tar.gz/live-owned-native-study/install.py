from pathlib import Path
d=Path(__file__).resolve().parent;c=d/'../live-owned-native/src/buster/compiler'
p=c/'c_check_input.c';s=p.read_text().replace('bool native_programs;','bool native_programs,owned_programs;')
needle='static void check_input_expressions(CheckInputReader* reader, bool complete_translation_unit)'
s=s.replace(needle,'static void check_live_publish_owned(CheckInputReader* reader);\n\n'+needle)
needle='    if (reader->grow_graph_limit != 0 && !check_source_grow_graph'
s=s.replace(needle,'''    if(complete_translation_unit && reader->parser->live_consumer!=NULL && reader->output->deferred_tokens==NULL &&
       reader->types->members.first_counted_pointer==0 && check_source_native_output(reader->pp,reader->parser))
        check_live_publish_owned(reader);
'''+needle);p.write_text(s)
p=c/'c_checker_driver.c';s=p.read_text();needle='.native_programs = getenv("BUSTER_LIVE_NATIVE_PROGRAMS") != NULL,'
s=s.replace(needle,needle+'''
                                                  .owned_programs = getenv("BUSTER_LIVE_OWN_PROGRAMS") != NULL && command->emit_object && !command->link &&
                                                   !command->assembly && !command->tier1 && !command->source_rows && !command->verify && !command->scalar &&
                                                   !command->dump && !command->dump_static && !command->lower_all && !command->provisional_selection && !command->windowed_loop &&
                                                   !pp->options.semantic_warning_option_count && !entry_count && !pp->options.predefines.stack_protector &&
                                                   !pp->options.predefines.sanitize_count && !predefines_frame_pointer(&pp->options.predefines),''');p.write_text(s)
p=c/'c_check_live_native.c';s=p.read_text().replace('    const CheckSourceEncoded* encoded;', '    uint32_t root;\n    const struct CheckLiveExpr* proof;\n    const CheckSourceEncoded* encoded;')
s=s.replace('    uint8_t op, a, b, c;', '    uint8_t op, a, b, c;\n    uint32_t token;')
s=s.replace('*e = (CheckLiveExpr){0};','*e = (CheckLiveExpr){.token=root};')
s=s.replace('uint32_t id = check_live_expression(b, t, stop);','''uint32_t id = check_live_expression(b, t, stop);
    if(t==b->plan->opening+2 && stop+1==b->plan->closing)b->plan->root=id;''')
k='        if (open == close || !check_live_signature'
s=s.replace(k,'        plan.opening=open;\n'+k)
k='            tbl->plans[tbl->count++] = plan;'
s=s.replace(k,'''            if(live->owned_programs && plan.root)
            {
                CheckLiveExpr* saved=BUSTER_ARENA_PUSH_ARRAY(&parser->live_rows,CheckLiveExpr,(uint64_t)b.expressions+1);
                if(saved){memcpy(saved+1,b.expr+1,(size_t)b.expressions*sizeof(*saved));plan.proof=saved;}
            }
'''+k)
p.write_text(s+'\n'+(d/'owned.c').read_text())
