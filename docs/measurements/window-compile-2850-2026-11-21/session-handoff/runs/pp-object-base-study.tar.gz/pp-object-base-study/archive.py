from pathlib import Path
from statistics import median
import shutil, subprocess,hashlib
d=Path(__file__).resolve().parent;st=d.parent/'pp-structural-study/stable';p=st/'object-bases'
for z in ['source','receipts','reproduce']:(p/z).mkdir(parents=True,exist_ok=True)
for name,head in [('first','cc7e21cb2'),('guard-free','09f7af87a'),('corrected','fcdda3580')]:
 (p/'source'/(name+'.patch')).write_bytes(subprocess.check_output(['git','-C',str(d.parent/'pp-object-bases'),'diff','0e1d5b825',head]))
for f in ['edges.py','edges-final.py','join.py','target.sh','qualify.sh','capture.sh','reevaluate.sh','implement.py','base.inc','verify.inc']:shutil.copy2(d/f,p/'reproduce'/f)
for f in ['coordinates.tsv','declaration-bound.tsv','declaration-bound.txt','clean-local.log','final-local.log']:shutil.copy2(d/f,p/'receipts'/f)
for f in ['target-first','target-final','target-extra','unknown-before']:shutil.copytree(d/f,p/'receipts'/f,dirs_exist_ok=True,ignore=shutil.ignore_patterns('*.o'))
shutil.copy2(d.parent/'member-chain-native-study/base-source-overlap.tsv',p/'receipts'/'source-native-chain-overlap.tsv')
e=p/'receipts/scope-tests';e.mkdir(exist_ok=True)
for f in (d/'scope-tests').iterdir():
 if f.suffix not in ('.o','.c'):shutil.copy2(f,e/f.name)
time_dir=d/'target-extra'
times={arm:median([int(i.read_text())/1e6 for i in time_dir.glob('*-'+arm+'.time')]) for arm in ('ordinary','fields','bases')}
(p/'README.md').write_text('''# Object base names from physical source and live C declarations

In a fresh, ordinary single-core SQLite object compilation, 17,486 bare names before an arrow stayed as physical source spellings throughout preprocessing and parsing. At the actual checker lookup every spelling selected a live C declaration and obtained the name identity published by that declaration. All 17,486 PP rows, parser positions, spellings and declaration tokens matched a separate completion trace from the conventional checker, with zero fallbacks. The Buster compiler and the frozen SQLite ELF were byte-identical to the control on the Ryzen 7 9700X. With maximum warnings, SQLite emitted the same 7,301 diagnostic bytes. Its linked SQL transcript matched the independent Clang build. Buster's main translation unit used the existing member path and required no borrowed primary bare bases. [Independent row-by-row scope comparison](receipts/target-final/sqlite-declaration-bound.tsv), [object hashes](receipts/target-final/hashes), [warnings, SQL and timing hashes](receipts/target-extra/hashes).

## Where the name first acquires an identity

Source names within a parsed function, bearing its operand role and followed by a member operator in the primary file, retain their PP row, parser position, source bytes and length. Once the real C binding reader reaches the use, it indexes only DECLARE events already published to that binding stream. It selects the active declaration through the standard C binding heads, preserving scope and shadowing, and reads its identifier from the declaration. A spelling with no in-scope declaration can demand a diagnostic name explicitly. [Signed final compiler](source/corrected.patch).

The first scope-qualified compiler, `cc7e21cb2`, checked for an existing global intern-table entry when deciding to withhold a spelling. Its terminal scope resolver independently selected all 17,486 declarations. Head `09f7af87a` removed that preliminary membership check. A newly seen unknown identifier then exposed the ordinary checker's fixed name-array size, producing a fatal capacity error instead of the undeclared-identifier diagnostic. Signed correction `fcdda3580` reserves room for later name demands. All nine generated programs now match conventional Buster stdout, stderr, exit status and every valid ELF, as well as pinned Clang accept/reject. The tests include parameter shadowing and restoration, a global with the same name, typedef scopes, source mapping, unknown fields, a scalar used as a pointer and a genuinely unknown spelling that reaches the source resolver and misses. [Intermediate failure](receipts/unknown-before), [corrected fixtures](receipts/scope-tests/results).

## Relation to native expression operands

A sibling compiler independently emitted 14,340 early native member operands. Exact source coordinates join 11,383 of them to a declaration selected by this resolver. Of those, 10,924 have physical spelling evidence for every member and 10,993 for at least one member. The two consumers ran in separate compiler experiments. [Source coordinate join](receipts/source-native-chain-overlap.tsv), [complete scoped use data](receipts/declaration-bound.tsv).

Six individually leased, fresh whole-process ordinary SQLite compilations per arm had median times of '''+', '.join(f'{a} {t:.3f} ms' for a,t in times.items())+'''. The field and base arms use the same pre-existing source-body compiler. Source binding increases elapsed time at this implementation. [Native individual runs](receipts/target-extra), [rotation](reproduce/qualify.sh).

Each full patch applies independently to `0e1d5b825801135bf50e79da9d546bc95209ab30`. The earlier packet records the native compatibility and corpus recovery on which all three heads build.
''')
a=st/'source-declared-object-bases-v5.tar.gz';subprocess.run(['tar','-czf',a,'-C',st,p.name],check=True);print(hashlib.sha256(a.read_bytes()).hexdigest(),a)
