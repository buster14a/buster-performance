#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;prefix=$d/../pp-member-connected-study
python3 "$prefix/local.py" pp-object-bases base-clean
python3 "$d/edges.py"
