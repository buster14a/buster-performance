from pathlib import Path
import csv,hashlib,os,subprocess
D=Path(__file__).resolve().parent; T=D.parent/'live-native-cfg'; P=D.parent/'live-native-cfg-poison'
if not P.exists():subprocess.run(['git','worktree','add','--detach',P,'de5ba936a'],cwd=T,check=True)
src=P/'src/buster/compiler/c_check_live_native.c'
orig=subprocess.check_output(['git','show','HEAD:src/buster/compiler/c_check_live_native.c'],cwd=P,text=True)
cases=[('padded','e',7,8),('sqlite','jsonHexToInt',9,8)]
lines={}
for what,sym,old,new in cases:
 with (D/(what+'-native-symbols.tsv')).open() as f:
  row=next(x for x in csv.DictReader(f,delimiter='\t') if x['name']==sym)
 blob=bytes.fromhex(row['native-hex'])
 marker=bytes([0xb8 if what=='padded' else 0xb9,old,0,0,0])
 assert blob.count(marker)==1
 lines[what]=(int(row['opening']),len(blob),blob.index(marker)+1,old,new,int(row['file-offset']))
proof='            if(scratch.peak)memset(scratch.base,0x9b,(size_t)scratch.peak);\n'
for what,(op,n,off,old,new,_) in lines.items():
 proof+=f'            if(getenv("EARLY_MUTATE_{what}") && open=={op}u && plan.encoded->length=={n} && plan.encoded->bytes[{off}]=={old})plan.encoded->bytes[{off}]={new};\n'
key='            tbl->plans[tbl->count++] = plan;';assert key in orig
src.write_text(orig.replace(key,proof+key,1))
with (D/'poison-mutation.patch').open('w') as f:subprocess.run(['git','diff'],cwd=P,stdout=f,check=True)
s=(D/'iterate.py').read_text().replace("target=(d/'../live-native-cfg').resolve()", "target=(d/'../live-native-cfg-poison').resolve()").replace("ref=d/'probe.o';exe=d/'compiler'","ref=d/'poison.o';exe=d/'poison-compiler'")
(D/'iterate-poison.py').write_text(s);subprocess.run(['python',D/'iterate-poison.py'],check=True)
env=os.environ|dict(BUSTER_PARSE_LIVE_FOREST='1',BUSTER_LIVE_CHECKED_INPUT='1',BUSTER_LIVE_NATIVE_PROGRAMS='1')
srcdir=D.parent/'switch-inputs';sargs=[os.fsdecode(v) for v in subprocess.check_output(['bash','-c','source ../switch-local-args.sh;eval "args=($sqlite_arguments)";printf "%s\\0" "${args[@]}"'],cwd=srcdir).split(b'\0')[:-1]]
(D/'runtime.c').write_text('''#include <stdio.h>
int e(int),while1(int,int),while2(int),z(int),if1(int,int),slot(int*,int);
int main(void){int v[]={5,11,17};int sum=0;for(int i=0;i<64;i++)sum+=e(i)+while1(i,66)+while2(i)+z(i)+if1(i,12)+slot(v,i%3);printf("%d %d %d\\n",sum,e(0),e(3));return 0;}\n''')
shell=D.parent/'pending-native-study/runtime/shell.o'
assert shell.exists()
sql=b"""SELECT hex(json_extract('"\\u00AF"', '$')),hex(json_extract('"\\uABCD"', '$'));\n"""
(D/'mutation-query.sql').write_bytes(sql)
with (D/'mutation-results.tsv').open('w',buffering=1) as f:
 w=csv.writer(f,delimiter='\t');w.writerow(['workload','build','symbol','opening','raw-file-offset','object-sha256','ELF-differences-from-ordinary','status','stdout','stderr'])
 for what,sym,old,new in cases:
  ref=D/f'{what}.cfg.ordinary.o';rraw=ref.read_bytes();args=sargs if what=='sqlite' else [D/'padded.c']
  opening,n,off,_,_,symoff=lines[what];results=[]
  for mode in ['ordinary','clang','poison','mutation']:
   obj=ref if mode=='ordinary' else D/(what+'-'+mode+'.o')
   if mode=='clang' and what=='padded':subprocess.run(['clang','-c',*args,'-o',obj],check=True)
   if mode=='clang' and what=='sqlite':obj=D.parent/'pending-native-study/runtime/clang.o'
   if mode in ('poison','mutation'):subprocess.run([D/'poison-compiler','--lanes','1','-c',*args,'-o',obj],cwd=srcdir,env=env|({'EARLY_MUTATE_'+what:'1'} if mode=='mutation' else {}),check=True)
   raw=obj.read_bytes();delta=''
   if mode!='clang':
    assert len(raw)==len(rraw);diff=[(i,a,b) for i,(a,b) in enumerate(zip(rraw,raw)) if a!=b]
    assert diff==([(symoff+off,old,new)] if mode=='mutation' else []),(what,mode,diff[:4]);delta=len(diff)
   program=D/(what+'-'+mode+'-exe')
   subprocess.run(['clang','-no-pie',*([shell,obj,'-ldl','-lpthread','-lm'] if what=='sqlite' else [D/'runtime.c',obj]),'-o',program],check=True)
   run=subprocess.run([program,*(['-batch',':memory:'] if what=='sqlite' else [])],input=sql if what=='sqlite' else None,capture_output=True,check=True)
   result=(run.returncode,run.stdout,run.stderr);results.append(result)
   w.writerow([what,mode,sym,opening,symoff+off,hashlib.sha256(raw).hexdigest(),delta,run.returncode,run.stdout.decode().strip(),run.stderr.decode().strip()])
  assert results[0]==results[1]==results[2] and results[0]!=results[3],(what,results)
