from pathlib import Path
import csv,os,hashlib,subprocess
d=Path(__file__).resolve().parent;case=d/'edges';case.mkdir(exist_ok=True)
base=d.parent/'main-fbef-clean/build/compiler'; cc=Path(os.environ.get('LIVE_QA_COMPILER',d/'compiler-develop'))
pad=(d/'padded.c').read_text().split('extern int u0;',1)[1];pad='extern int u0;'+pad
forms={}
old=d.parent/'live-source-leaf-study/edges.py';s=old.read_text();exec(s[s.index('forms={'):s.index("(base/'prefix.h')")],forms)
cases={n:(p+'\n'+x+'\n') for n,(p,x) in forms['forms'].items()}
cases.update({
  'scalar':(d/'padded.c').read_text().split('extern int u0;',1)[0],
  'subword':(d/'primitive.c').read_text(),
  'unsigneds':'unsigned long f(unsigned long x,unsigned long y){return (x^0xffUL)+(y*7UL);} unsigned g(unsigned x){return x>>2;}',
  'if-args':'int f(int x,int y){if(x>y){return x-y;}else{return x+y;}}',
  'six-args':'long f(long a,long b,long c,long d,long e,long f){return (a+b)*(c-d)+(e^f);}',
  'seven-args':'int f(int a,int b,int c,int d,int e,int f,int g){return a+b+c+d+e+f+g;}',
  'array-arg':'int f(const int a[],int i){return a[i];}',
  'typed-field':'typedef unsigned U; typedef struct S{char h;U x;long tag;}S; U f(const S*s){return s?s->x:0U;}',
  'linked-record':'typedef struct N{int n;struct N *next;} N;int f(N*p){return p->next->n;}',
  'array-layout':'struct S{char x[17];int y;};int f(struct S*p){return p->y+1;}',
  'flex':'struct S{int h;int v[];};int f(struct S*p,int n){return p->v[n];}',
  'bit':'struct S{int a:4;int b;};int f(struct S*p){return p->b;}',
  'anonymous':'struct S{struct{long x;};int y;};int f(struct S*p){return p->y;}',
  'volatile':'struct S{volatile int x;};int f(struct S*p){return p->x;}',
  'packed':'#pragma pack(push,1)\nstruct S{char b;int x;};int f(struct S*p){return p->x;}\n#pragma pack(pop)',
  'attribute-packed':'struct __attribute__((packed)) S{char b;int x;};int f(struct S*p){return p->x;}',
  'atomic':'struct S{_Atomic int x;};int f(struct S*p){return p->x;}',
  'interrupt':'__attribute__((interrupt)) void h(void*p){} int f(int x){return x+2;}',
  'frame':'__attribute__((patchable_function_entry(3))) int f(int x){return x+2;}',
  'pointer-eq':'int f(const char*p){return p==0;}',
  'shortcircuit':'int f(int x,int*p){return x&&*p;} int g(int x,int*p){return x||*p;}',
  'float':'double f(double x){return x+1.0;}',
  'redeclaration':'int f(int);int f(unsigned x){return x;}',
  'undeclared-field':'struct S{int n;};int f(struct S*p){return p->oops;}',
  'warning-shift':'int f(int x){return x<<50;} int g(int x){return x/0;}',
  'pragma-diag':'#pragma clang diagnostic push\n#pragma clang diagnostic ignored "-Wshift-count-overflow"\nint f(int x){return x<<40;}\n#pragma clang diagnostic pop\n',
  'macro':'#define PLUS(a,b) ((a)+(b))\nint f(int a,int b){return PLUS(a,b);}',
})
(case/'prefix.h').write_text('typedef int H;\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else ''
env=os.environ|dict(BUSTER_PARSE_LIVE_FOREST='1', BUSTER_LIVE_CHECKED_INPUT='1',BUSTER_LIVE_NATIVE_PROGRAMS='1')
with (d/'edges.tsv').open('w',buffering=1) as f:
 w=csv.writer(f,delimiter='\t');w.writerow(['case','policy','clean-exit','candidate-exit','object-equal','stdout-equal','stderr-equal','source-fragments-used'])
 for name,source in cases.items():
  file=case/(name+'.c');file.write_text(source+'\n'+pad)
  for opt,flags in [('default',[]),('wall',['-Wall','-Wextra']),('strict',['-Wall','-Wextra','-Werror']),('quiet',['-w']),('all',['-Weverything'])]+([('debug',['-g']),('asm',['-S']),('frame',['-fno-omit-frame-pointer']),('patchable',['-fpatchable-function-entry=4'])] if name in ('scalar','subword','if-args','typed-field') else []):
   samples=[]
   for arm,driver,envv in [('clean',base,os.environ),('native',cc,env)]:
    out=case/(name+'.'+opt+'.'+arm+('.s' if opt=='asm' else '.o'));out.unlink(missing_ok=True)
    r=subprocess.run([driver,'--lanes','1','-std=gnu17','-c',*flags,file,'-o',out],env=envv,capture_output=True,timeout=15)
    (case/(name+'.'+opt+'.'+arm+'.stderr')).write_bytes(r.stderr)
    samples.append((r.returncode,sha(out),r.stdout,r.stderr))
   a,b=samples;hits=''
   if opt=='default' and b[0]==0:
    r=subprocess.run([cc,'--lanes','1','-std=gnu17','-c',file,'-o',case/'audit.o'],env=env|{'BUSTER_PARSE_LIVE_AUDIT':'1'},capture_output=True)
    (case/(name+'.audit.stderr')).write_bytes(r.stderr);hits=r.stderr.count(b'early-native-used\t')
   w.writerow([name,opt,a[0],b[0],*[int(a[i]==b[i]) for i in range(1,4)],hits])
