from pathlib import Path
import csv,struct,re,hashlib
d=Path(__file__).resolve().parent
def syms(path):
 b=path.read_bytes(); off=struct.unpack_from('<Q',b,40)[0];slen,count=struct.unpack_from('<HH',b,58)
 secs=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*slen) for i in range(count)]
 funcs={}
 for s in secs:
  if s[1]!=2:continue
  st=secs[s[6]];names=b[st[4]:st[4]+st[5]]
  for i in range(s[4],s[4]+s[5],s[9]):
   n,flags,other,k,pos,size=struct.unpack_from('<IBBHQQ',b,i)
   if flags&15!=2 or not k or k>=len(secs):continue
   key=names[n:names.index(0,n)].decode();t=secs[k]
   full=b[t[4]+pos:t[4]+pos+size]
   funcs.setdefault(key,[]).append((pos,t[4]+pos,full))
 return funcs
def summary(job):
 buf=(d/f'{job}.cfg.audit.stderr').read_text().splitlines()
 funcs=syms(d/f'{job}.cfg.ordinary.o');info={};raw={};candidates=set();used=set()
 for line in buf:
  a=line.split('\t')
  if a[0]=='early-native-bytes':raw[int(a[1])]=(a[2],int(a[3]),int(a[4]),bytes.fromhex(a[5]))
  elif a[0]=='early-native-built':info[int(a[1])]=list(map(int,a[2:]))
  elif a[0]=='early-native-used':used.add(int(a[1]))
  elif a[0]=='early-native-candidate':candidates.add(int(a[1]))
  elif a[0]=='live-forest':final=int(re.search(r'tokens=(\d+)',line)[1])
 accu=[]
 with (d/f'{job}-native-symbols.tsv').open('w') as f:
  w=csv.writer(f,delimiter='\t');w.writerow(['opening','closing','name','PP-depth','PP-produced','final-parser-tokens','parameters','typed-entries','bytes','reached-final-selector','consumed','ordinary-symbol-offset','file-offset','ordinary-bytes-equal','native-hex'])
  for o,(name,depth,count,bytes_) in raw.items():
   close,id,params,entries,dprev,cprev,n=info[o];assert dprev==depth and cprev==count and depth>0 and len(bytes_)==n
   matches=[(p,q) for p,q,x in funcs.get(name,[]) if bytes_==x]
   if o in used:assert len(matches)==1,(job,name,bytes_.hex(),funcs.get(name))
   pos,fo=matches[0] if len(matches)==1 else ('','')
   w.writerow([o,close,name,depth,count,final,params,entries,n,int(o in candidates),int(o in used),pos,fo,int(bool(matches)),bytes_.hex()])
   if o in used:accu.append((params,entries,n))
 print(job,'built',len(info),'reached',len(candidates),'used',len(accu),'parameters',sum(x[0] for x in accu),'entries',sum(x[1] for x in accu),'native-bytes',sum(x[2] for x in accu),'actual ELF functions',sum(map(len,funcs.values())))
if __name__=='__main__':
 for job in ['padded','sqlite','main']:summary(job)
