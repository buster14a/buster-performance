static uint32_t check_live_slot(CheckLiveBuild* b, uint32_t t)
{
    if (b->tokens->kinds[t] != PARSE_KIND_IDENTIFIER) return UINT32_MAX;
    for (uint32_t i=0;i<b->plan->locals;i++)
        if (b->plan->names[i]==b->tokens->names[t]) return i;
    return UINT32_MAX;
}

static bool check_live_effect(CheckLiveBuild* b,uint32_t first,uint32_t end,bool declarations)
{
    if(first==end)return true;
    CheckLivePlan* p=b->plan;
    const uint8_t* k=b->tokens->kinds;
    uint32_t set=first;while(set<end && b->tree->roles[set]!=PARSE_ROLE_ASSIGN)set++;
    if(set==first)return false;
    uint32_t name=set<end?set-1:end-1;
    if(declarations && name>first && k[name]==PARSE_KIND_IDENTIFIER && (set==end||k[set]==PARSE_KIND_EQUAL))
    {
        CheckLiveType type=check_live_decl_type(b,first,name);
        if(type.cls)
        {
            if (p->locals==CHECK_LIVE_LOCALS || check_live_slot(b,name)!=UINT32_MAX)return false;
            uint32_t slot=p->locals++;
            p->names[slot]=b->tokens->names[name];p->types[slot]=type;
            if(set==end)return true;
            uint32_t rhs=check_live_expression(b,set+1,end);
            return rhs && check_live_value(b,rhs,type.cls) && check_live_put(p,BUSTER_TYPED_SET_LOCAL,type.cls,slot);
        }
    }
    if(set<end)
    {
        uint32_t lhs=check_live_expression(b,first,set),rhs=check_live_expression(b,set+1,end);
        if(!lhs || !rhs)return false;
        CheckLiveExpr* l=b->expr+lhs;uint8_t cls=l->type.cls;
        if(l->op==BUSTER_TYPED_LOCAL)
        {
            if(k[set]!=PARSE_KIND_EQUAL)
            {
                uint8_t op=0;
                switch(k[set]){
                    case PARSE_KIND_PLUSEQUAL:op=BUSTER_TYPED_ADD;break;case PARSE_KIND_MINUSEQUAL:op=BUSTER_TYPED_SUB;break;
                    case PARSE_KIND_STAREQUAL:op=BUSTER_TYPED_MUL;break;case PARSE_KIND_AMPEQUAL:op=BUSTER_TYPED_AND;break;
                    case PARSE_KIND_PIPEEQUAL:op=BUSTER_TYPED_OR;break;case PARSE_KIND_CARETEQUAL:op=BUSTER_TYPED_XOR;break;
                    default:return false;
                }
                if(l->type.pointer||cls<BUSTER_TYPED_CLASS_I32|| !check_live_value(b,lhs,cls) || !check_live_value(b,rhs,cls) || !check_live_put(p,op,cls,0))return false;
            }
            else if(!check_live_value(b,rhs,cls))return false;
            if(!check_live_put(p,BUSTER_TYPED_STORE_LOCAL,cls,l->value))return false;
        }
        else
        {
            if(k[set]!=PARSE_KIND_EQUAL || (l->op!=BUSTER_TYPED_LOAD && l->op!=CHECK_LIVE_MEMBER && l->op!=CHECK_LIVE_SUBSCRIPT))return false;
            if (!check_live_value(b,lhs,cls) || !p->count || p->kinds[p->count-1]!=BUSTER_TYPED_LOAD)return false;
            p->count--;
            if(!check_live_value(b,rhs,cls)|| !check_live_put(p,BUSTER_TYPED_STORE,cls,0))return false;
        }
        return check_live_put(p,BUSTER_TYPED_DISCARD,cls,0);
    }
    uint32_t id=check_live_expression(b,first,end);
    if(!id)return false;
    uint8_t cls=b->expr[id].type.cls;
    return check_live_value(b,id,cls) && check_live_put(p,BUSTER_TYPED_DISCARD,cls,0);
}

// A range consumes exactly one statement. The recursive calls follow the parsed block
// bounds. Waiting until both sides have emitted gives branches their final entry indices.
static uint32_t check_live_statement(CheckLiveBuild* b,uint32_t first,uint32_t end,uint32_t depth,bool* terminal)
{
    if(depth>12 || first>=end)return 0;
    const uint8_t* k=b->tokens->kinds;CheckLivePlan* p=b->plan;
    *terminal=false;
    if(k[first]==PARSE_KIND_L_BRACE)
    {
        uint32_t close=b->tree->parents[first], i=first+1;
        if(close>=end||k[close]!=PARSE_KIND_R_BRACE)return 0;
        while(i<close)
        {
            if(*terminal)return 0;
            i=check_live_statement(b,i,close,depth+1,terminal);
            if(!i)return 0;
        }
        return close+1;
    }
    if(k[first]==PARSE_KIND_RETURN)
    {
        *terminal=true;
        return check_live_return(b,first,end);
    }
    if(k[first]==PARSE_KIND_IF || k[first]==PARSE_KIND_WHILE)
    {
        if(first+3>=end || k[first+1]!=PARSE_KIND_L_PAREN)return 0;
        uint32_t close=b->tree->parents[first+1], head=p->count;
        if(close>=end || k[close]!=PARSE_KIND_R_PAREN)return 0;
        uint32_t condition=check_live_expression(b,first+2,close);
        if(!condition || !check_live_truth(b,condition))return 0;
        uint32_t branch=p->count;
        if(!check_live_put(p,BUSTER_TYPED_BRANCH_FALSE,BUSTER_TYPED_CLASS_I32,0))return 0;
        bool yes=false;uint32_t next=check_live_statement(b,close+1,end,depth+1,&yes);
        if(!next)return 0;
        if(k[first]==PARSE_KIND_WHILE)
        {
            if(yes || !check_live_put(p,BUSTER_TYPED_JUMP,BUSTER_TYPED_CLASS_VOID,head))return 0;
            p->values[branch]=p->count;return next;
        }
        if(next==end || k[next]!=PARSE_KIND_ELSE){p->values[branch]=p->count;return next;}
        uint32_t jump=p->count;
        if(!yes && !check_live_put(p,BUSTER_TYPED_JUMP,BUSTER_TYPED_CLASS_VOID,0))return 0;
        p->values[branch]=p->count;
        bool no=false;next=check_live_statement(b,next+1,end,depth+1,&no);
        if(!next)return 0;
        if(!yes)p->values[jump]=p->count;
        *terminal=yes&&no;return next;
    }
    uint32_t stop=first;while(stop<end && k[stop]!=PARSE_KIND_SEMI)stop++;
    return stop!=end && check_live_effect(b,first,stop,depth==0)?stop+1:0;
}

static bool check_live_statements(CheckLiveBuild* b,uint32_t first,uint32_t end)
{
    b->plan->locals=b->plan->parameters;
    bool terminal=false;
    while(first<end)
    {
        if(terminal)return false;
        first=check_live_statement(b,first,end,0,&terminal);
        if(!first)return false;
    }
    return terminal;
}
