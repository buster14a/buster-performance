from pathlib import Path
d=Path(__file__).resolve().parent;p=d/'../live-native-cfg/src/buster/compiler/c_check_live_native.c';s=p.read_text()
s=s.replace('#define CHECK_LIVE_PARAMETERS 6u','#define CHECK_LIVE_PARAMETERS 6u\n#define CHECK_LIVE_LOCALS 16u')
s=s.replace('count, parameters;','count, parameters, locals;').replace('result, types[CHECK_LIVE_PARAMETERS]','result, types[CHECK_LIVE_LOCALS]').replace('names[CHECK_LIVE_PARAMETERS]','names[CHECK_LIVE_LOCALS]')
s=s.replace('CHECK_LIVE_OR\n','CHECK_LIVE_OR, CHECK_LIVE_CAST\n')
start=s.index('    if (end == lo + 1)');s=s[:start]+'''    if(b->tree->roles[root]==PARSE_ROLE_CLOSE_CAST && b->tree->roles[lo]==PARSE_ROLE_OPEN_CAST && b->tree->parents[lo]==root && root+1<end)
    {
        e->a=(uint8_t)check_live_expression(b,root+1,end);
        if(!e->a)return 0;
        if(root==lo+2 && check_live_word(b,lo+1,"void"))return e->a;
        e->type=check_live_decl_type(b,lo+1,root);if(!e->type.cls)return 0;
        e->op=CHECK_LIVE_CAST;return idx;
    }
'''+s[start:]
s=s.replace('i < b->plan->parameters','i < b->plan->locals')
s=s.replace('if (e->op == CHECK_LIVE_SUBSCRIPT)','''if(e->op==CHECK_LIVE_CAST)
    {
        if(!check_live_value(b,e->a,cls))return false;
    }
    else if (e->op == CHECK_LIVE_SUBSCRIPT)''')
s=s.replace('!check_live_value(b, e->b, (uint8_t)e->value)', '!check_live_value(b, e->b, (e->op==BUSTER_TYPED_SHL||e->op==BUSTER_TYPED_SHR)?(b->expr[e->b].type.cls<BUSTER_TYPED_CLASS_I32?BUSTER_TYPED_CLASS_I32:b->expr[e->b].type.cls):(uint8_t)e->value)')
a=s.index('static bool check_live_statements(');z=s.index('static uint8_t check_live_abi_flags',a);s=s[:a]+(d/'blocks.c').read_text()+'\n'+s[z:]
a=s.index('uint8_t local[CHECK_LIVE_PARAMETERS]');z=s.index('AbiLocation params',a)
s=s[:a]+s[a:z].replace('CHECK_LIVE_PARAMETERS','CHECK_LIVE_LOCALS')+'for(uint32_t i=0;i<p->locals;i++)local[i]=p->types[i].cls;\n    '+s[z:]
s=s.replace('.local_count = p->parameters','.local_count = p->locals').replace('p->parameters != fn->local_count','p->locals != fn->local_count')
s=s.replace('    static const uint8_t gp[] =', '''    for(uint32_t i=p->parameters;i<p->locals;i++)
        if(!fn->local_classes||fn->local_classes[i]!=p->types[i].cls || (fn->local_flags&&fn->local_flags[i]) || (fn->local_sizes&&fn->local_sizes[i]) || (fn->local_alignments&&fn->local_alignments[i]))return false;
    static const uint8_t gp[] =''')
s=s.replace('!t || !live->used','run->scalar || !t || !live->used')
p.write_text(s)
