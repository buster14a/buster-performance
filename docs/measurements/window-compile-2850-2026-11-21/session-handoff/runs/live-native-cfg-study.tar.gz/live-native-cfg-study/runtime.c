#include <stdio.h>
int e(int),while1(int,int),while2(int),z(int),if1(int,int),slot(int*,int);
int main(void){int v[]={5,11,17};int sum=0;for(int i=0;i<64;i++)sum+=e(i)+while1(i,66)+while2(i)+z(i)+if1(i,12)+slot(v,i%3);printf("%d %d %d\n",sum,e(0),e(3));return 0;}
