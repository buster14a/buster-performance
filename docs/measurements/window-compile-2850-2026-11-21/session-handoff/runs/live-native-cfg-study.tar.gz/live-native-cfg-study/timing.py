from pathlib import Path
import csv,hashlib,itertools,os,statistics,subprocess,time
d=Path(__file__).resolve().parent;w=d.parent;src=w/'switch-inputs';cc=d/'compiler-develop'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sqlite=[os.fsdecode(v) for v in subprocess.check_output(['bash','-c','source ../switch-local-args.sh; eval "args=($sqlite_arguments)"; printf "%s\\0" "${args[@]}"'],cwd=src).split(b'\0')[:-1]]
tree=src/'../pregraph-warning-study/compiler-source'
jobs={'sqlite':sqlite,'main':['-march=native','-I'+str(tree/'src'),'-fwrapv','-funsigned-char','--predefines',src/'../proof-predefines.h',tree/'src/buster/compiler/main.c']}
arms={'ordinary':{},'forest':{'BUSTER_PARSE_LIVE_FOREST':'1','BUSTER_LIVE_CHECKED_INPUT':'1'},'native':{'BUSTER_PARSE_LIVE_FOREST':'1','BUSTER_LIVE_CHECKED_INPUT':'1','BUSTER_LIVE_NATIVE_PROGRAMS':'1'}}
base={k:v for k,v in os.environ.items() if not k.startswith(('BUSTER_PARSE_LIVE','BUSTER_LIVE_','BUSTER_CONTROL_'))}
fields=['workload','mode','round','position','arm','wall-ms','user-ms','sys-ms','rss-kib','faults','cycles','instructions','sha256']
rows=[];timed=d/'timed';timed.mkdir(exist_ok=True)
resume=os.environ.get('LIVE_RESUME_MAIN')=='1'
if resume:
 with (d/'timing.tsv').open() as f:
  for r in csv.DictReader(f,delimiter='\t'):
   if r['workload']!='sqlite':continue
   for k in ['round','position','user-ms','sys-ms','rss-kib','faults','wall-ms','cycles','instructions']:
    if r[k]:r[k]=float(r[k])
   rows.append(r)
 assert len(rows)==36
with (d/'timing.tsv').open('a' if resume else 'w',buffering=1) as f:
 out=csv.DictWriter(f,delimiter='\t',fieldnames=fields)
 if not resume:out.writeheader()
 for name,args in jobs.items():
  if resume and name=="sqlite":continue
  ref=sha(w/'source-typed-study'/f'{name}.o');obj=timed/f'{name}.o'
  for mode in ['wall','pmu']:
   for i,order in enumerate(itertools.permutations(arms)):
    for pos,arm in enumerate(order):
     env=base|arms[arm];cmd=[cc,'--lanes','1','-c',*args,'-o',obj];stem=timed/f'{name}-{mode}-{i}-{arm}'
     if mode=='pmu':cmd=['perf','stat','-x',';','-o',stem.with_suffix('.pmu'),'-e','cycles:u,instructions:u','--',*cmd]
     with stem.with_suffix('.stderr').open('wb') as st:
      start=time.perf_counter_ns();proc=subprocess.Popen(cmd,env=env,cwd=src,stderr=st,stdout=st);_,status,u=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status);elapsed=(time.perf_counter_ns()-start)/1e6
     assert proc.returncode==0 and not stem.with_suffix('.stderr').stat().st_size,(mode,i,arm)
     h=sha(obj);assert h==ref,(mode,i,arm,h,ref)
     counters={e[2]:int(e[0]) for line in stem.with_suffix('.pmu').read_text().splitlines() if len(e:=line.split(';'))>2} if mode=='pmu' else {}
     row=dict(zip(fields,[name,mode,i+1,pos+1,arm,round(elapsed,3),round(1000*u.ru_utime,3),round(1000*u.ru_stime,3),u.ru_maxrss,u.ru_minflt,counters.get('cycles:u',''),counters.get('instructions:u',''),h]))
     rows.append(row);out.writerow(row)
with (d/'timing-summary.tsv').open('w') as f:
 out=csv.writer(f,delimiter='\t');out.writerow(['workload','baseline','candidate','metric','baseline-median','candidate-median','paired-difference','paired-percent','n'])
 for name in jobs:
  for a,b in [('ordinary','native'),('forest','native'),('ordinary','forest')]:
   for mode,keys in [('wall',['wall-ms','user-ms','rss-kib','faults']),('pmu',['cycles','instructions'])]:
    for k in keys:
     pairs=[[r[k] for r in rows if r['workload']==name and r['mode']==mode and r['arm']==arm] for arm in [a,b]]
     out.writerow([name,a,b,k,*map(statistics.median,pairs),statistics.median(y-x for x,y in zip(*pairs)),100*statistics.median(y/x-1 for x,y in zip(*pairs)),len(pairs[0])])
print((d/'timing-summary.tsv').read_text())
