#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; cd ../live-native-typed
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/
ln -sf ../live-native-typed/build/compiler "$d/compiler"
