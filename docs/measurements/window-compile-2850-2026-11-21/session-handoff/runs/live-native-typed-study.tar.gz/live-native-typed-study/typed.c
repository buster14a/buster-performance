typedef struct CheckLiveScalarKey
{
    Tier0Function shape;
    struct { const void* data; size_t bytes; } fields[8];
} CheckLiveScalarKey;

// For an auxiliary-free function, the typed columns, locals, argument locations and scalar
// settings completely describe selection. Explicitly exclude operations that read symbol access.
static bool check_live_scalar_key(CheckLiveScalarKey* key, const Tier0Function* f)
{
    if (f->call_count || f->argument_count || f->incoming_variadic || f->x87_constant_count || f->vector_constant_count ||
        f->operation_count || f->asm_body_count || f->label_count || f->table_count || f->lifetime_count ||
        f->hidden_copy || f->x87 || f->int128 || f->vectors || f->masks) return false;
    for (uint32_t i = 0; i < f->count; i += 1)
        if (tier0_global_kind(f->kinds[i])) return false;

    *key = (CheckLiveScalarKey){ .shape = *f };
    // Exact scalar settings and ABI result remain in shape. These eight pointed-to columns are
    // compared by value. Other pointed-to arrays have zero length under the guards above.
    Tier0Function* shape = &key->shape;
#define LIVE_FIELD(index, member, count) do { \
    key->fields[index].data = f->member; \
    key->fields[index].bytes = ((size_t)(count)) * sizeof(*f->member); \
    shape->member = NULL; \
} while (0)
    LIVE_FIELD(0, kinds, f->count);
    LIVE_FIELD(1, classes, f->count);
    LIVE_FIELD(2, values, f->count);
    LIVE_FIELD(3, local_classes, f->local_count);
    LIVE_FIELD(4, local_flags, f->local_count);
    LIVE_FIELD(5, local_sizes, f->local_count);
    LIVE_FIELD(6, local_alignments, f->local_count);
    LIVE_FIELD(7, parameters, f->parameter_count);
#undef LIVE_FIELD
    shape->symbol_count = 0;
    shape->symbol_access = NULL;
    shape->call_targets = NULL;
    shape->call_first = NULL;
    shape->call_argument_counts = NULL;
    shape->call_variadic = NULL;
    shape->calls = NULL;
    shape->argument_locations = NULL;
    shape->argument_classes = NULL;
    shape->argument_sizes = NULL;
    shape->call_result_objects = NULL;
    shape->x87_constants = NULL;
    shape->vector_constants = NULL;
    shape->vector_constant_bytes = NULL;
    shape->operations = NULL;
    shape->call_asm = NULL;
    shape->asm_bodies = NULL;
    shape->label_entries = NULL;
    shape->label_tables = NULL;
    shape->table_jumps = NULL;
    shape->table_addresses = NULL;
    shape->call_tails = NULL;
    shape->lifetime_entries = NULL;
    shape->lifetime_locals = NULL;
    return true;
}

static CheckLiveFragment* check_live_fragment_at(CheckLiveNative* state, uint32_t opening)
{
    uint32_t low = 0, high = state->count;
    while (low < high)
    {
        const uint32_t middle = low + (high - low) / 2;
        if (state->rows[middle].opening < opening) low = middle + 1;
        else high = middle;
    }
    return low < state->count && state->rows[low].opening == opening ? state->rows + low : NULL;
}

static void* check_live_duplicate(Arena* arena, const void* data, size_t bytes)
{
    if (!data || !bytes) return NULL;
    void* copy = arena_push(arena, bytes, 16);
    if (copy != NULL) memcpy(copy, data, bytes);
    return copy;
}

static void check_live_keep_scalar(CheckLiveNative* state, uint32_t opening, const Tier0Function* function, const CheckSourceEncoded* saved)
{
    CheckLiveScalarKey key;
    if (saved->reference_count || !check_live_scalar_key(&key, function)) return;
    CheckLiveFragment* row = check_live_fragment_at(state, opening);
    if (row == NULL) return;
    CheckLiveScalarKey* frozen = BUSTER_ARENA_PUSH_ARRAY(state->storage, CheckLiveScalarKey, 1);
    CheckSourceEncoded* native = BUSTER_ARENA_PUSH_ARRAY(state->storage, CheckSourceEncoded, 1);
    if (!frozen || !native) return;
    *frozen = key;
    for (uint32_t j = 0; j < BUSTER_ARRAY_LENGTH(key.fields); j += 1)
    {
        frozen->fields[j].data = check_live_duplicate(state->storage, key.fields[j].data, key.fields[j].bytes);
        if (key.fields[j].bytes && key.fields[j].data && !frozen->fields[j].data) return;
    }
    *native = *saved;
    native->bytes = row->bytes;
    native->references = NULL;
    native->access = NULL;
    native->label_offsets = check_live_duplicate(state->storage, saved->label_offsets, (size_t)saved->label_count * sizeof(*saved->label_offsets));
    native->frame.tails = check_live_duplicate(state->storage, saved->frame.tails, (size_t)saved->frame.tail_count * sizeof(*saved->frame.tails));
    native->frame.rows = check_live_duplicate(state->storage, saved->frame.rows, (size_t)saved->frame.row_count * sizeof(*saved->frame.rows));
    if ((saved->label_count && !native->label_offsets) || (saved->frame.tail_count && !native->frame.tails) || (saved->frame.row_count && !native->frame.rows)) return;
    row->typed = frozen;
    row->native = native;
}

static CheckSourceEncoded* check_live_take_scalar(CheckLiveNative* state, uint32_t opening, const Tier0Function* f, uint32_t symbols, Arena* output)
{
    const CheckLiveFragment* row = check_live_fragment_at(state, opening);
    if (!row || !row->typed) return NULL;
    const CheckLiveScalarKey* frozen = row->typed;
    CheckLiveScalarKey key;
    if (!check_live_scalar_key(&key, f) || memcmp(&frozen->shape, &key.shape, sizeof(key.shape)) != 0) return NULL;
    for (uint32_t j = 0; j < BUSTER_ARRAY_LENGTH(key.fields); j += 1)
    {
        const size_t bytes = key.fields[j].bytes;
        if (bytes != frozen->fields[j].bytes ||
            (bytes && ((key.fields[j].data == NULL) != (frozen->fields[j].data == NULL) ||
                       (key.fields[j].data && memcmp(key.fields[j].data, frozen->fields[j].data, bytes) != 0)))) return NULL;
    }
    CheckSourceEncoded* result = BUSTER_ARENA_PUSH_ARRAY(output, CheckSourceEncoded, 1);
    uint8_t* access = BUSTER_ARENA_PUSH_ARRAY(output, uint8_t, (uint64_t)symbols + 1);
    if (!result || !access) return NULL;
    memset(access, UINT8_MAX, (size_t)symbols + 1);
    *result = *(const CheckSourceEncoded*)row->native;
    result->access = access;
    if (state->audit) fprintf(stderr, "pre-eof-tier0-skipped\t%u\t%u\t%u\n", opening, f->count, row->size);
    return result;
}

