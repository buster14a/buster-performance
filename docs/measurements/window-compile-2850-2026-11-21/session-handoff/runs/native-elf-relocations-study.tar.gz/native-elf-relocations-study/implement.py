from pathlib import Path
path=Path(__file__).resolve().parent.parent/'native-elf-relocations/src/buster/compiler/object_writer.c'
s=path.read_text()
def sub(a,b):
 global s
 assert s.count(a)==1,(s.count(a),a)
 s=s.replace(a,b)
sub("    uint32_t relocation_index;\n    uint32_t symbol;", "    uint32_t relocation_index;\n    Elf64_Rela* relocations;\n    uint32_t symbol;")
sub("    uint64_t borrowed;\n", "    uint64_t borrowed;\n    uint64_t relocation_bytes;\n")
sub("        const uint32_t atom_end = sections[s].atom_end;", "        Elf64_Rela* relocation = sections[s].relocations;\n        const uint32_t atom_end = sections[s].atom_end;")
sub("""                const uint32_t code = (uint32_t)entry;
                if ((code & BUSTER_OBJECT_SYMBOL_KIND) == BUSTER_OBJECT_SYMBOL_LOCAL)
                {
                    const uint8_t kind = kinds[fixup];
                    const int64_t addend = (kind & BUSTER_LINK_FIXUP_WIDE) != 0 ? wide_addends[(uint32_t)addends[fixup]] : addends[fixup];
                    if (object_uses_section_symbol(kind & BUSTER_LINK_FIXUP_KIND, code, addend))""","""                const uint32_t code = (uint32_t)entry;
                uint32_t place_code = code;
                const uint8_t kind = kinds[fixup];
                int64_t addend = (kind & BUSTER_LINK_FIXUP_WIDE) != 0 ? wide_addends[(uint32_t)addends[fixup]] : addends[fixup];
                if ((code & BUSTER_OBJECT_SYMBOL_KIND) == BUSTER_OBJECT_SYMBOL_LOCAL)
                {
                    if (object_uses_section_symbol(kind & BUSTER_LINK_FIXUP_KIND, code, addend))""")
sub("""                        sections[units->atom_section[target_atom]].symbol = 1;""","""                        const uint32_t section = units->atom_section[target_atom];
                        sections[section].symbol = 1;
                        place_code = BUSTER_OBJECT_SYMBOL_KIND | section;
                        addend = adjusted;""")
sub("""                        builder->local_places[code & BUSTER_OBJECT_SYMBOL_PLACE] = 1;
                    }
                }
""","""                        builder->local_places[code & BUSTER_OBJECT_SYMBOL_PLACE] = 1;
                    }
                }
                if (relocation != NULL)
                {
                    *relocation++ = (Elf64_Rela){
                        .r_offset = units->atom_offset[atom] + fixups->offset[fixup],
                        .r_info = ELF64_R_INFO(place_code, object_relocation_types[kind & BUSTER_LINK_FIXUP_KIND]),
                        .r_addend = addend,
                    };
                }
""")
sub("""                end = offset + atoms->size[atom];
            }
        }
    }
}

// The relocations of each""","""                end = offset + atoms->size[atom];
            }
        }
        if (stream != NULL && section->relocations != NULL)
        {
            const Elf64_Shdr* header = &builder->headers[section->relocation_index];
            object_file_span(stream, bytes + stream->covered, header->sh_offset - stream->covered);
            object_file_span(stream, section->relocations, header->sh_size);
            stream->covered = header->sh_offset + header->sh_size;
            stream->relocation_bytes += header->sh_size;
        }
    }
}

// The relocations of each""")
sub("static void object_fill_relocations(const ObjectBuilder* builder, uint8_t* bytes)","static void object_fill_relocations(const ObjectBuilder* builder, uint8_t* bytes, bool borrowed)")
sub("""            Elf64_Rela* relocation = (Elf64_Rela*)(bytes + builder->headers[section->relocation_index].sh_offset);
            for (uint32_t i""","""            Elf64_Rela* relocation = (Elf64_Rela*)(bytes + builder->headers[section->relocation_index].sh_offset);
            if (section->relocations != NULL)
            {
                // The classification pass already supplied the addend, field, relocation type and
                // symbol class. Layout has now assigned the three symbol bases and compact local places.
                for (uint64_t j = 0; j < section->fixup_count; j += 1)
                {
                    Elf64_Rela* row = section->relocations + j;
                    const uint32_t code = (uint32_t)ELF64_R_SYM(row->r_info);
                    const uint32_t kind = code >> BUSTER_OBJECT_SYMBOL_KIND_SHIFT;
                    const uint32_t place = code & BUSTER_OBJECT_SYMBOL_PLACE;
                    const uint64_t index = kind == 3 ? sections[place].symbol :
                                           kind == 0 && builder->local_places != NULL ? builder->local_base + builder->local_places[place] :
                                           bases[kind] + place;
                    row->r_info = ELF64_R_INFO(index, ELF64_R_TYPE(row->r_info));
                }
                if (!borrowed) memcpy(relocation, section->relocations, section->fixup_count * sizeof(*relocation));
                continue;
            }
            for (uint32_t i""")
sub("""    built = built && object_count_groups(&builder, scratch.arena);
    built = built && object_count_symbols(&builder, scratch.arena);""","""    built = built && object_count_groups(&builder, scratch.arena);
    if (built && stream != NULL && builder.fixup_count != 0 && builder.section_count <= BUSTER_OBJECT_SYMBOL_PLACE &&
        getenv("BUSTER_OBJECT_EARLY_RELOCATIONS") != NULL)
    {
        Elf64_Rela* rows = BUSTER_ARENA_PUSH_ARRAY(arena, Elf64_Rela, builder.fixup_count);
        for (uint32_t s = 0; rows != NULL && s < builder.section_count; s += 1)
        {
            ObjectSection* section = &builder.sections[s];
            if (section->fixup_count != 0)
            {
                section->relocations = rows;
                rows += section->fixup_count;
            }
        }
    }
    built = built && object_count_symbols(&builder, scratch.arena);""")
sub("((uint64_t)atoms*2", "((uint64_t)atoms*2") if False else None
sub("(uint64_t)atoms*2 + builder.section_count + 1","(uint64_t)atoms * 2 + (uint64_t)builder.section_count * 3 + 1")
sub("object_fill_relocations(&builder, bytes);","object_fill_relocations(&builder, bytes, stream != NULL);")
path.write_text(s)
path=path.with_name('c_checker_driver.c');s=path.read_text()
sub("            valid = valid && object_write_stream", """            if (spans.relocation_bytes != 0 && getenv("BUSTER_OBJECT_STREAM_AUDIT") != NULL)
                fprintf(stderr, "object-rela-stream\\tbytes=%llu\\n", (unsigned long long)spans.relocation_bytes);
            valid = valid && object_write_stream""")
path.write_text(s)
