from pathlib import Path
import csv,hashlib,lzma,os,re,shutil,subprocess,sys,tempfile
d=Path(__file__).resolve().parent
w=d.parent
s=w/'native-object-spans-study'
repo=w/'native-elf-relocations'
out=w/'native-object-evidence/docs/measurements/window-compile-2850-2026-11-21/83599c1e7'
out.mkdir(exist_ok=True)
def git(*a,env=None):
 return subprocess.check_output(['git',*a],cwd=repo,env=env)
def table(name,header,rows):
 with (out/name).open('w',newline='') as f:
  writer=csv.writer(f,delimiter='\t');writer.writerow(header);writer.writerows(rows)
patches=[]
for a,b,name in (('418ed8b06','ab12c0843','early-relocations.patch'),('ab12c0843','83599c1e7','large-data.patch'),('0e1d5b825','83599c1e7','all-from-live-base.patch.xz')):
 raw=git('diff','--binary',a,b)
 (out/name).write_bytes(lzma.compress(raw) if name.endswith('.xz') else raw)
 with tempfile.TemporaryDirectory() as tmp:
  env=dict(os.environ,GIT_INDEX_FILE=str(Path(tmp)/'index'));(Path(tmp)/'patch').write_bytes(raw)
  git('read-tree',a,env=env);git('apply','--cached',str(Path(tmp)/'patch'),env=env)
  tree=git('write-tree',env=env).decode().strip();assert tree==git('rev-parse',b+'^{tree}').decode().strip()
 patches.append((git('rev-parse',a).decode().strip(),git('rev-parse',b).decode().strip(),tree,name,hashlib.sha256(raw).hexdigest()))
table('verified-patches.tsv',('base','head','verified-tree','patch','uncompressed-sha256'),patches)
for file in ('qa.py','objectrelas-one.sh','objectrelas-submit.sh'):shutil.copy(d/file,out)
data=[]
for group in ('sqlite','main'):
 control=w/'source-typed-study'/(group+'.o')
 for arm in ('spans','runs','data'):
  obj=d/(group+'-'+arm+'.o');audit=d/(group+'-'+arm+'.audit')
  if not audit.exists() or not obj.exists():continue
  raw=audit.read_text()
  first=re.search(r'object-text-stream\tbytes=(\d+)\tspans=(\d+)\tfile=(\d+)',raw);assert first
  rela=re.search(r'object-rela-stream\tbytes=(\d+)',raw)
  static=re.search(r'object-data-stream\tbytes=(\d+)',raw)
  assert control.read_bytes()==obj.read_bytes()
  data.append((group,arm,*first.groups(),int(rela[1]) if rela else 0,int(static[1]) if static else 0,hashlib.sha256(obj.read_bytes()).hexdigest()))
table('frozen-layout.tsv',('input','mode','borrowed-text-bytes','total-spans','elf-bytes','borrowed-elf64-rela-bytes','borrowed-large-data-bytes','ordinary-and-candidate-sha256'),data)
for name in ('cases.tsv','destinations.tsv'):
 p=d/'targets'/name
 if p.exists():
  (out/(name+'.xz')).write_bytes(lzma.compress(p.read_bytes()))

corpus=[]
for name,count in (('sqlite',5),('main',5),('lua',170),('musl',6680)):
 path=d/'real'/(name+'.tsv')
 if not path.exists():continue
 cases=list(csv.DictReader(path.open(),delimiter='\t'))
 if len(cases)==count:
  eq=sum(r['ref-exit']==r['source-exit'] and all(r[k]=='1' for k in ('same-object','same-stdout','same-stderr')) for r in cases)
  corpus.append((name,count,eq,sum(r['ref-exit']!='0' for r in cases)))
  (out/('corpus-'+name+'.tsv.xz')).write_bytes(lzma.compress(path.read_bytes()))
table('corpus.tsv',('group','cases','exact','ordinary-nonzero'),corpus)
if (d/'compiler').exists():
 table('functional-compiler.tsv',('git-sha','sha256'),[(git('rev-parse','83599c1e7').decode().strip(),hashlib.sha256((d/'compiler').read_bytes()).hexdigest())])
for file in ('objectstandalone-one.sh','objectstandalone-submit.sh'):
 shutil.copy(d/file,out)
base=w/'native-object-evidence/docs/measurements/window-compile-2850-2026-11-21/418ed8b06'
portable=(base/'compare-corpus.py').read_text().replace('    "BUSTER_OBJECT_TEXT_RUNS",','    "BUSTER_OBJECT_TEXT_RUNS",\n    "BUSTER_OBJECT_DATA_SPANS",\n    "BUSTER_OBJECT_EARLY_RELOCATIONS",')
(out/'compare-corpus.py').write_text(portable)

fixtures=out/'decoded-fixtures'
fixtures.mkdir(exist_ok=True)
raw=[]
for name in ('comdat','signed-addends','tlsforms','large-mixed'):
 source=d/'targets'/(name+'.c');meta=d/(name+'.metadata')
 if not meta.exists():continue
 shutil.copy(source,fixtures);shutil.copy(meta,fixtures);shutil.copy(d/(name+'.audit'),fixtures)
 obj=d/(name+'-candidate.o');ref=d/(name+'-ordinary.o')
 assert obj.read_bytes()==ref.read_bytes()
 raw.append((name,obj.stat().st_size,hashlib.sha256(obj.read_bytes()).hexdigest()))
table('fixture-objects.tsv',('fixture','elf-bytes','sha256-both'),raw)

for name in ('sqlite','main'):
 src=d/(name+'-verified-data.syscalls')
 if src.exists():shutil.copy(src,out)
