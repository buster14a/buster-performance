from pathlib import Path
import csv
d=Path(__file__).resolve().parent
out=d.parent/'native-object-evidence/docs/measurements/window-compile-2850-2026-11-21/83599c1e7'
def read(name):
 path=out/name
 if not path.exists():return []
 with path.open() as f:return list(csv.DictReader(f,delimiter='\t'))
layout=read('frozen-layout.tsv')
paired=read('target-paired.tsv')
lines=[]
for build,label,pairs in [('objectrelas','Source-local',[('packed','rela'),('packed','data'),('packed','complete')]),('objectstandalone','Ordinary',[('ordinary','text'),('text','data'),('data','complete'),('ordinary','complete')])]:
 for inp,name in [('sqlite','SQLite'),('main','Buster')]:
  for a,b in pairs:
   r=next((r for r in paired if (r['build'],r['input'],r['before'],r['after'],r['metric'])==(build,inp,a,b,'wall_ms')),None)
   if r:
    lines.append(f"| {label} | {name} | {a} → {b} | {float(r['median-before']):.3f} | {float(r['median-after']):.3f} | {float(r['median-after-minus-before']):+.3f} | {r['lower-after']}/{r['paired-rounds']} |")
s="""# Carrying native data and complete ELF64 relocations to file publication

This extension of the [native fragment writer](../418ed8b06/README.md) borrows large static atoms directly from the final link and produces `Elf64_Rela` rows when the object builder first classifies their target symbols. Both mechanisms run at the ordinary ELF output boundary. Each works with the existing unit-wide compiler and with the experimental function-local native producer.

## File layout

During ELF symbol classification the fixup target is already known to be a local, global, undefined, or section-relative symbol. The producer records the final section-relative relocation offset, ABI relocation type and checked signed addend. It keeps just the symbol class and position in the row’s symbol slot. After section and symbol placement that slot becomes the final ELF symbol index. The file writer borrows the relocation array directly. The general linker still supplies the normalized source fixups and determines symbol and section order. [Verified patch against 418ed8b06](early-relocations.patch).

Previously each large file-backed non-text atom was copied to the object image just before a disk write. At `83599c1e7` the scatter writer borrows atoms of at least 4,096 bytes. Smaller atoms share the existing contiguous section buffer. This includes writable data, read-only literals and immutable unwind atoms such as .eh_frame. Virtual zero-fill sections consume no file bytes. [Large-data change](large-data.patch).

| Frozen input | Complete native ELF | Borrowed text bytes | Borrowed relocation bytes | Borrowed non-text atom bytes | Output spans |
| --- | ---: | ---: | ---: | ---: | ---: |
"""
for row in layout:
 if row['mode']=='data':
  keys=['elf-bytes','borrowed-text-bytes','borrowed-elf64-rela-bytes','borrowed-large-data-bytes','total-spans']
  s+='| '+('SQLite' if row['input']=='sqlite' else 'Buster')+' | '+' | '.join(f"{int(row[k]):,}" for k in keys)+' |\n'
s+="""
With source-local encoding active, strace counted one actual positional vectored write for the 36-span SQLite file and two for the 383-span Buster file. Both traced files matched the independent ordinary objects. With the ordinary unit-wide schedule the writer borrows the same byte classes, while independently encoded text atoms may require more spans. The target Buster ordinary audit reported 2,561 spans. [SQLite syscalls](sqlite-verified-data.syscalls) and [Buster syscalls](main-verified-data.syscalls). The remaining image consists of ELF and section headers, symbol tables, short atoms, alignment and other metadata. The file builder still reserves its full logical ELF range. The borrowed spans remove writes into the corresponding image pages, so the byte coverage measures copying at the final boundary. The flat in-memory builder continues to serve callers that require a complete contiguous ELF. [Equality and coverage](frozen-layout.tsv).

## One-core fresh compilation

The same Ryzen 7 9700X Release executable runs with the ordinary unit-wide compiler and separately with the experimental source-local path. In the ordinary experiment `ordinary` uses the existing contiguous output, `text` borrows native text, `data` also borrows static data, and `complete` additionally borrows preclassified ELF relocations. In the source-local experiment `packed` starts from the packed text and compact source fields, `rela` and `data` add the respective single feature, and `complete` adds both. Eight balanced rounds compare file-producing processes on CPU 2, with independent lock acquisitions and a fresh comparison to the ordinary reference object after every invocation. The first three rounds also measure hardware events in matched runs. [Individual observations](target-samples.tsv), [wall and PMU pairs](target-paired.tsv) and [stage census](target-stages.tsv).

| Source schedule | Input | Before → after | Before ms | After ms | Paired Δ ms | Faster pairs |
| --- | --- | --- | ---: | ---: | ---: | ---: |
"""+'\n'.join(lines)+'\n'
cases=read('corpus.tsv')
if cases:
 total=sum(int(r['cases']) for r in cases);exact=sum(int(r['exact']) for r in cases);nonzero=sum(int(r['ordinary-nonzero']) for r in cases)
 s+=f"\nFinal candidate qualification compared 1,372 frozen inputs under five warning policies. **{exact:,}/{total:,}** invocations matched all four observables, including {nonzero:,} ordinary failures. [Source and policy counts](corpus.tsv).\n"
s+="""
The directed file suite checks weak and external calls, data-to-function references, x86 TLS models, local section targets, wide positive and negative addends, an actual COMDAT group, custom alignment and a large object containing relocations. All 756 directed compiler cases matched across six source and writer combinations (510 zero and 246 nonzero exits). All 30 publication outcomes matched for existing files, hard links, pipes and failing destinations. [Candidate fixture runner](qa.py), [file comparisons](cases.tsv.xz) and [destination checks](destinations.tsv.xz). GNU readelf decoded both wide signed addends, GOTTPOFF and TPOFF32 TLS references, and a two-member COMDAT section group in the accepted objects. [Decoded ELF examples](decoded-fixtures), [whole-file hashes](fixture-objects.tsv). The system C driver linked both variants of each fixture with an independent runtime check. All eight executables exited successfully, and each pair also matched in linked executable bytes. [Runtime checks](linked-executables.tsv), [driver](link-roundtrip.py) and [link toolchain](linker-toolchain.txt).

Apply the uncompressed net patch to Buster `0e1d5b825801135bf50e79da9d546bc95209ab30`. Applying `early-relocations.patch` and `large-data.patch` in order to the preceding writer produces the same tree. Use `BUSTER_OBJECT_TEXT_STREAM=1` with `BUSTER_OBJECT_EARLY_RELOCATIONS=1`, `BUSTER_OBJECT_DATA_SPANS=1`, or both. No other switch is required for the ordinary compiler mode. `BUSTER_OBJECT_STREAM_AUDIT=1` prints the bytes the writer actually borrows. [Full source patch](all-from-live-base.patch.xz), [tree verification](verified-patches.tsv) and [complete target traces](target-raw.tar.xz).
"""
(out/'README.md').write_text(s)
