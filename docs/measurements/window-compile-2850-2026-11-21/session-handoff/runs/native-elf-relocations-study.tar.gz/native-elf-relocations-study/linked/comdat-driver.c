int external(void){return 37;}extern int use(void);int main(void){return use()!=37;}
