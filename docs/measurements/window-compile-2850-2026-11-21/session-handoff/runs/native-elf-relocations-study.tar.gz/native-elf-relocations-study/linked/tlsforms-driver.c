__thread int external=17;extern __thread int visible;extern int f(void);extern int *g(void);int main(void){visible=29;*g()=11;return f()!=57;}
