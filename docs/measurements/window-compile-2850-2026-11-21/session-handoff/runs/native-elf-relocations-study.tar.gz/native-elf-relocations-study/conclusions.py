"""Insert the complete paired whole-process results into the measurement note."""
from pathlib import Path
import csv
d=Path(__file__).resolve().parent
out=d.parent/'native-object-evidence/docs/measurements/window-compile-2850-2026-11-21/83599c1e7'
with (out/'target-paired.tsv').open() as f:rows=list(csv.DictReader(f,delimiter='\t'))
def get(build,unit,before,key):
 row=next(r for r in rows if (r['build'],r['input'],r['before'],r['after'],r['metric'])==(build,unit,before,'complete',key))
 assert int(row['paired-rounds'])==(3 if key.startswith('pmu-') else 8)
 return row
lines=[]
for build,before,schedule in [('objectstandalone','ordinary','ordinary unit-wide'),('objectrelas','packed','source-local')]:
 for unit,label in [('sqlite','SQLite'),('main','Buster')]:
  vals=get(build,unit,before,'wall_ms')
  counts=get(build,unit,before,'pmu-instructions:u')
  rss=get(build,unit,before,'peak_kib')
  lines.append(f"| {label}, {schedule} | {float(vals['median-after-minus-before']):+.3f} ms | {vals['lower-after']}/8 | {int(float(counts['median-after-minus-before'])):+,} | {int(float(rss['median-after-minus-before'])):+,} |")
ordinary=get('objectstandalone','sqlite','ordinary','wall_ms')
source=get('objectrelas','sqlite','packed','wall_ms')
q=lambda row: f"{float(row['median-after']):.3f}"
result=f"""The four-arm experiment completed all 128 wall measurements, 48 separate PMU measurements and 16 stage censuses on the controlled host. With all borrowing features enabled, SQLite’s ordinary process median was **{q(ordinary)} ms** ({9.507037/(float(ordinary['median-after'])/1000):.1f} MB/s) and its source-local median was {q(source)} ms. The 1 GB/s objective allows 9.507 ms for the complete source. The paired ordinary SQLite sample spans a −26.5 ms through +8.9 ms difference, including an outlier in the first balanced round.

| Complete writer vs schedule baseline | Paired whole wall Δ | Faster wall pairs | Paired user instructions Δ | Paired peak RSS Δ KiB |
| --- | ---: | ---: | ---: | ---: |
"""+'\n'.join(lines)+"""

One ordinary Buster stage sample reduced ELF construction from 1.301 to 0.973 ms while publication moved from 2.114 to 2.264 ms. The measurements bound file production to a small share of the observed whole-program gap. [Complete raw per-process observations](target-raw.tar.xz).
"""
p=out/'README.md';s=p.read_text().replace('Final candidate qualification',result+'\nFinal candidate qualification');p.write_text(s)
