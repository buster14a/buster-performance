static const char a[]="local"; static const char b[]="longer"; const char *act[] = {a,b+2}; const char *f(unsigned i){return act[i&1];}
