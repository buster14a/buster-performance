extern int f(void);extern int e; int data; int (*fn)(void)=f; struct Record{int*a,*b;void*fn;}; static struct Record r={&e,&data, f}; int g(void){return r.a==r.b || f();}
