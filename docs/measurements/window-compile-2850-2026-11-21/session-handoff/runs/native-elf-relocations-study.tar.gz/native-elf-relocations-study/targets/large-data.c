const unsigned char big[65537]={[3]=1,[32769]=2,[65536]=7}; unsigned char other[8511]={[4234]=6}; unsigned f(unsigned n){return big[n%65537]+other[n%8511];}
