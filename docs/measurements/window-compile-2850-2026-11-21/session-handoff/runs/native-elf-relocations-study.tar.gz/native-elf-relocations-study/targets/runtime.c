struct Big{int a[64];};struct Big f(struct Big x){struct Big a=x;return a;} int g(struct Big *x,struct Big *y){*x=*y;return x->a[0];}
