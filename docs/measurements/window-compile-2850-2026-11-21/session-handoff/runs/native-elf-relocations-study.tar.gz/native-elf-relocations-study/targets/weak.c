extern int ext(int) __attribute__((weak));int f(int i){return ext?ext(i):4;}
