int g(int);int f(int i){switch(i){case 0:return g(4);case 1:return g(3);case 2:return g(8);case 3:return g(1);case 4:return g(7);case 5:return g(5);default:return -1;}}
