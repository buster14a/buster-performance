extern int g(int);
