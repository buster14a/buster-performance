int a(void){return 1;} int b(int) __attribute__((aligned(512))); int b(int x){return x+1;} int c(void){return 2;}
