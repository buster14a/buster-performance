int ext(int);static const int a[]={4,1,3};int y;int f(int x){return ext(x)+a[x%3]+y;}
