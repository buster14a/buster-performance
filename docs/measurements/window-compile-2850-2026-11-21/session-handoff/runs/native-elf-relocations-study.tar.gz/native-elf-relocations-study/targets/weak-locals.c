static int s(void){return 1;} int f(void){return s();} extern __typeof(f) a __attribute__((weak,alias("f"))); int (*deps[])(void)={s,f,a};
