static int a;extern int b;extern __thread int tls;const void *refs[]={&a,&b};int f(void){return (a==b)+tls;}
