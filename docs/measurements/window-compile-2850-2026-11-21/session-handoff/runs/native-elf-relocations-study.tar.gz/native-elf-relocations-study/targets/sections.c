__attribute__((section(".text.one"),aligned(64))) int first(int x){return x+1;} __attribute__((section(".text.two"),aligned(128))) int second(int x){return first(x)-3;}
