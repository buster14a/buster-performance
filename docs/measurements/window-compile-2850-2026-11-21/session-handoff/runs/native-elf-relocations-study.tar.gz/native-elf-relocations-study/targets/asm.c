asm(".pushsection .text.asm_fragment,\"ax\"\n.globl extra\nextra: nop\nret\n.popsection");int f(int i){asm("" : "+r"(i));return i;}
