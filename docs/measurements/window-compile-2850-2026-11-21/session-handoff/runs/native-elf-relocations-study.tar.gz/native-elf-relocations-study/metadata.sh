#!/bin/bash
set -eu
cd "$(dirname "$0")"
for name in comdat signed-addends tlsforms large-mixed;do
 env BUSTER_OBJECT_TEXT_STREAM=1 BUSTER_OBJECT_DATA_SPANS=1 BUSTER_OBJECT_EARLY_RELOCATIONS=1 BUSTER_OBJECT_STREAM_AUDIT=1 ./compiler --lanes 1 -nostdinc -c "$PWD/targets/$name.c" -o "$name-candidate.o" >"$name.stdout" 2>"$name.audit"
 ../main-fbef-clean/build/compiler --lanes 1 -nostdinc -c "$PWD/targets/$name.c" -o "$name-ordinary.o"
 cmp "$name-candidate.o" "$name-ordinary.o"
 readelf -W -r -g -s "$name-candidate.o" >"$name.metadata"
done
