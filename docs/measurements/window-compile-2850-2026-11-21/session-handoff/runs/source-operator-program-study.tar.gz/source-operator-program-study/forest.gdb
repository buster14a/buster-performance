set pagination off
set debuginfod enabled off
set disable-randomization off
set environment BUSTER_DIRECT_SOURCE_STATEMENTS 1
break check_native_returns_run
run
python
r=gdb.parse_and_eval('reader');p=r['parser'];n=int(p['tokens']['count']); roles={int(f.enumval):f.name.removeprefix('PARSE_ROLE_') for f in gdb.lookup_type('ParseRole').fields()}; k={int(f.enumval):f.name.removeprefix('PARSE_KIND_') for f in gdb.lookup_type('ParseKind').fields()}
for i in range(n):
 j=int(r['postorder'][i]); print(i,j,k.get(int(p['tokens']['kinds'][j]),'?'),roles[int(p['tree']['roles'][j])],int(p['tree']['parents'][j]),int(r['ends'][j]),int(r['first_child'][j]),int(r['next_child'][j]),int(r['subtree_sizes'][i]))
end
