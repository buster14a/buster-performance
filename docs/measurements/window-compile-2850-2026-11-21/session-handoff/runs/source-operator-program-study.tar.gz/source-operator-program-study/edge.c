struct C {int n; int *p __attribute__((counted_by(n)));}; int f(int x, struct C*p){p->n=x;return p->n;}
