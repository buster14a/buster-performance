#!/bin/bash
set -eu
cd "$(dirname "$0")"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
python3 optimized.py > optimized.log 2>&1
cp predefines.h ../source-operator-program/build/
python3 validate.py ../source-operator-program/build/compiler optimized-run > validate.log
python3 - <<'PY'
import csv
from pathlib import Path
for file in ['objects.tsv','runtime.tsv']:
 rows=list(csv.DictReader((Path('optimized-run')/file).open(),delimiter='\t'))
 assert rows and all(r['exact']=='True' for r in rows),[(r['unit'],r['mode'],r['rc']) for r in rows if r['exact']!='True']
PY
bash four.sh > four.log 2>&1
python3 boundary.py > boundary.log 2>&1
bash corpus.sh sqlite main lua musl > corpus.log 2>&1
