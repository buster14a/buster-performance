from pathlib import Path
import random
d=Path(__file__).resolve().parent
rng=random.Random(2850)
head='struct R { unsigned int v; unsigned short flags; struct R* next; };\n'
def expr(n):
 if n<1 or rng.random()<.17:return rng.choice(['a','b','c','p->v','p->flags','p->next->v','7u','0x55u','137u'])
 o=rng.choice(['+','-','*','&','|','^','<<','>>','!=','>=','~','!'])
 if o in ('~','!'):return f'({o}{expr(n-1)})'
 if o in ('<<','>>'):return '(('+expr(n-1)+' | 0u) '+o+' 2u)'
 return '('+expr(n-1)+' '+o+' '+expr(n-1)+')'
funcs=[]
for i in range(140):
 a,b,c,e=expr(3),expr(3),expr(3),expr(4)
 funcs.append(f'unsigned f{i}(struct R *p,unsigned a,unsigned b,unsigned c) {{ unsigned x=a; x={a}; p->v={b}; if ({c}) {{ x=x^a; }} return x^({e}); }}')
(d/'random.c').write_text(head+'\n'.join(funcs)+'\n')
decl='\n'.join(f'extern unsigned f{i}(struct R*,unsigned,unsigned,unsigned);' for i in range(len(funcs)))
table=','.join(f'f{i}' for i in range(len(funcs)))
(d/'random-driver.c').write_text('#include <stdio.h>\n'+head+decl+'\ntypedef unsigned (*Fn)(struct R*,unsigned,unsigned,unsigned);\nstatic Fn functions[]={'+table+'''}; 
int main(void) {struct R a={0},b={0}; a.next=&b;b.next=&a; unsigned h=0x7385cb37u;
for(unsigned k=0;k<199;k++) for(unsigned i=0;i<sizeof functions/sizeof *functions;i++){
a.v=h; a.flags=(unsigned short)(h>>7); b.v=h^0x557cb310u;
unsigned x=functions[i](&a,h,h>>12,h<<1); h=(h^x)*8167499u+a.v+i;
} printf("%08x\\n",h);}
''')
