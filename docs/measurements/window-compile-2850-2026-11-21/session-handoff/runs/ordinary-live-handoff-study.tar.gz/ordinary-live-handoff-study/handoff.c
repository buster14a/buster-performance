// Infer the symbol renumbering from equal typed instructions. One early slot must consistently
// denote one destination. Each access mode must still select the same machine addressing form.
static bool check_live_symbol(const CheckLiveScalarKey* frozen, const Tier0Function* final, SymbolId* map, uint64_t from, uint64_t to)
{
    if (from == 0 || to == 0) return from == to;
    if (from >= frozen->shape.symbol_count || to >= final->symbol_count || (map[from] != 0 && map[from] != to)) return false;
    const uint8_t* early_access = frozen->fields[18].data;
    if (early_access == NULL || final->symbol_access == NULL || early_access[from] != final->symbol_access[to]) return false;
    map[from] = (SymbolId)to;
    return true;
}

static bool check_live_emit_ordinary(CheckEmitRun* run, CheckEmitLane* lane, uint32_t body, const Tier0Function* final)
{
    const Parser* parser = run->program->parser;
    CheckLiveNative* state = parser != NULL ? parser->live_native : NULL;
    if (!state || !state->ordinary || state->capture || !state->count || run->sources || run->verify || run->scalar ||
        lane->tier1 != NULL || (run->lanes && run->lanes->assembly) || check_program_patchable(run->program, body).count != 0 ||
        final->table_count || !run->program->input || run->program->input->source_bodies) return false;
    const uint32_t opening = run->program->bodies[body].opening;
    const CheckLiveFragment* row = check_live_fragment_at(state, opening);
    if (!row || !row->native || !row->typed) return false;
    const CheckLiveScalarKey* frozen = row->typed;
    const CheckSourceEncoded* early = row->native;
    CheckLiveScalarKey current;
    if (!check_live_scalar_key(&current, final, run->lowered, 0)) return false;
    Tier0Function shape = frozen->shape;
    shape.symbol_count = current.shape.symbol_count;
    shape.hidden_copy = current.shape.hidden_copy;
    if (memcmp(&shape, &current.shape, sizeof(shape)) != 0) return false;
    for (uint32_t k = 0; k < BUSTER_ARRAY_LENGTH(current.fields); k += 1)
    {
        if (k == 2 || k == 8 || k == 18 || k == 31) continue;
        const size_t n = current.fields[k].bytes;
        const void* a = frozen->fields[k].data;
        const void* b = current.fields[k].data;
        if (n != frozen->fields[k].bytes || (n && ((a == NULL) != (b == NULL) || (a && memcmp(a,b,n) != 0)))) return false;
    }
    const uint64_t scratch_mark = lane->scratch->length;
    SymbolId* symbols = BUSTER_ARENA_PUSH_ARRAY(lane->scratch, SymbolId, frozen->shape.symbol_count);
    if (!symbols) return false;
    memset(symbols, 0, (size_t)frozen->shape.symbol_count * sizeof(*symbols));
    bool valid = check_live_symbol(frozen, final, symbols, frozen->shape.hidden_copy, final->hidden_copy);
    const uint64_t* values = frozen->fields[2].data;
    for (uint32_t i = 0; valid && i < final->count; i += 1)
        valid = tier0_global_kind(final->kinds[i]) ? check_live_symbol(frozen, final, symbols, values[i], final->values[i]) : values[i] == final->values[i];
    const SymbolId* calls = frozen->fields[8].data;
    if (final->call_count && (!calls || !final->call_targets)) valid = false;
    for (uint32_t i = 0; valid && i < final->call_count; i += 1)
        valid = check_live_symbol(frozen, final, symbols, calls[i], final->call_targets[i]);
    for (uint32_t i = 0; valid && i < early->reference_count; i += 1)
    {
        const SymbolId target = early->references[i].target;
        valid = target > 0 && target < frozen->shape.symbol_count && symbols[target] != 0;
    }
    if (!valid)
    {
        arena_pop_to(lane->scratch, scratch_mark);
        return false;
    }
    LinkReference* refs = BUSTER_ARENA_PUSH_ARRAY(lane->scratch, LinkReference, (uint64_t)early->reference_count + 1);
    if (!refs) { arena_pop_to(lane->scratch, scratch_mark); return false; }
    for (uint32_t i = 0; i < early->reference_count; i += 1)
    {
        refs[i] = early->references[i];
        refs[i].target = symbols[refs[i].target];
    }
    run->bodies[body] = (CheckEmitBody){ .bytes = early->bytes, .length = early->length, .label_offsets = early->label_offsets,
                                         .status = CHECK_PROGRAM_OK, .token = BUSTER_CHECK_NONE, .resolved_fields = true, .early_source = true };
    run->codes[body] = (EmittedCode){ .references = refs, .reference_count = early->reference_count, .label_count = early->label_count };
    if (run->unwind) run->frames[body] = early->frame;
    if (state->audit) fprintf(stderr, "ordinary-native-handoff\t%u\t%u\t%llu\t%u\t%u\n", opening, final->count,
                              (unsigned long long)early->length, early->reference_count, final->call_count);
    return true;
}

