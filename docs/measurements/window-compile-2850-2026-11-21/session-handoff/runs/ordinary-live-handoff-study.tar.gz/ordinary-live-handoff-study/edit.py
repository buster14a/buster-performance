from pathlib import Path
d=Path(__file__).resolve().parent;p=d.parent/'ordinary-live-handoff/src/buster/compiler'
f=p/'c_check_input.c';s=f.read_text().replace('static _Thread_local bool check_source_requires_rows;','static _Thread_local bool check_source_requires_rows;\nstatic _Thread_local bool check_capture_native_prefix;')
s=s.replace('&& getenv("BUSTER_CONTROL_SOURCE_NATIVE") != NULL && reader->output->deferred_tokens', '&& (check_capture_native_prefix || getenv("BUSTER_CONTROL_SOURCE_NATIVE") != NULL) && reader->output->deferred_tokens')
s=s.replace('bool capture, audit;','bool capture, audit, ordinary;');f.write_text(s)
f=p/'c_check_live_control_native.c';s=f.read_text().replace('(discard || getenv("BUSTER_CONTROL_EARLY_NATIVE")','(discard || check_capture_native_prefix || getenv("BUSTER_CONTROL_EARLY_NATIVE")');f.write_text(s)
f=p/'c_checker_driver.c';s=f.read_text().replace('    state->capture = true;\n    if (ready)', '    state->capture = true;\n    check_capture_native_prefix = state->ordinary;\n    if (ready)').replace('    state->capture = false;\n    if (state->audit)', '    check_capture_native_prefix = false;\n    state->capture = false;\n    if (state->audit)')
s=s.replace('.storage = &parser->live_code, .audit =', '.storage = &parser->live_code, .ordinary = getenv("BUSTER_LIVE_ORDINARY_HANDOFF") != NULL, .audit =')
s=s.replace('if ((getenv("BUSTER_CONTROL_SOURCE_NATIVE") != NULL || getenv("BUSTER_LOCAL_CONTROL_NATIVE") != NULL)', 'if ((getenv("BUSTER_LIVE_ORDINARY_HANDOFF") != NULL || getenv("BUSTER_CONTROL_SOURCE_NATIVE") != NULL || getenv("BUSTER_LOCAL_CONTROL_NATIVE") != NULL)');f.write_text(s)
f=p/'c_check_program_emit.c';s=f.read_text().replace('static bool check_program_emit_code_half(CheckEmitRun* run,','static bool check_live_emit_ordinary(CheckEmitRun* run, CheckEmitLane* lane, uint32_t body, const Tier0Function* final);\nstatic bool check_program_emit_code_half(CheckEmitRun* run,',1)
s=s.replace('                Tier0Code compiled = naked != 0', '''                if (naked == NULL && !spliced && check_live_emit_ordinary(run, lane, b, source))
                {
                    if (window_mark != UINT64_MAX) check_program_emit_window_pop(lane->code, code_mark, run->poison_windows);
                    continue;
                }
                Tier0Code compiled = naked != 0''',1)
at=s.index('static CheckSourceEncoded* check_source_encode(');s=s[:at]+(d/'handoff.c').read_text()+s[at:];f.write_text(s)
