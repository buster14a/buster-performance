static void check_input_publish_declarators(const ParseTokens* tokens, const ParseTree* tree, uint8_t* shapes, uint32_t begin, uint32_t end)
{
    uint8_t next_shape = 0;
    uint32_t limit = end;
    while (limit > begin)
    {
        const uint32_t first = begin + ((limit - 1 - begin) & ~63u);
        const uint32_t size = limit - first;
        const __mmask64 lanes = _bzhi_u64(UINT64_MAX, size);
        const __mmask64 following = limit < end ? lanes : _bzhi_u64(lanes, size - 1);
        const __m512i kind = _mm512_maskz_loadu_epi8(lanes, tokens->kinds + first);
        const __m512i role = _mm512_maskz_loadu_epi8(lanes, tree->roles + first);
        const __m512i after = _mm512_maskz_loadu_epi8(following, tokens->kinds + first + 1);
        const uint64_t stop = _mm512_cmpeq_epi8_mask(after, _mm512_set1_epi8(PARSE_KIND_SEMI)) |
                              _mm512_cmpeq_epi8_mask(after, _mm512_set1_epi8(PARSE_KIND_EQUAL)) |
                              _mm512_cmpeq_epi8_mask(after, _mm512_set1_epi8(PARSE_KIND_COMMA)) |
                              _mm512_cmpeq_epi8_mask(after, _mm512_set1_epi8(PARSE_KIND_COLON)) |
                              _mm512_cmpeq_epi8_mask(after, _mm512_set1_epi8(PARSE_KIND_R_PAREN));
        const uint64_t names = stop & following & _mm512_cmpeq_epi8_mask(kind, _mm512_set1_epi8(PARSE_KIND_IDENTIFIER)) &
                               _mm512_cmpeq_epi8_mask(role, _mm512_set1_epi8(PARSE_ROLE_OPERAND));
        const uint64_t stars = _mm512_cmpeq_epi8_mask(kind, _mm512_set1_epi8(PARSE_KIND_STAR));
        const uint64_t one = stars & ((names >> 1) | ((uint64_t)(next_shape == 1) << 63));
        const uint64_t two = stars & ((one >> 1) | ((uint64_t)(next_shape == 2) << 63));
        const uint64_t three = stars & ((two >> 1) | ((uint64_t)(next_shape == 3) << 63));
        __m512i result = _mm512_maskz_set1_epi8(names, 1);
        result = _mm512_mask_mov_epi8(result, one, _mm512_set1_epi8(2));
        result = _mm512_mask_mov_epi8(result, two, _mm512_set1_epi8(3));
        result = _mm512_mask_mov_epi8(result, three, _mm512_set1_epi8(4));
        _mm512_mask_storeu_epi8(shapes + first, lanes, result);
        next_shape = (uint8_t)_mm_cvtsi128_si32(_mm512_castsi512_si128(result));
        limit = first;
    }
}
