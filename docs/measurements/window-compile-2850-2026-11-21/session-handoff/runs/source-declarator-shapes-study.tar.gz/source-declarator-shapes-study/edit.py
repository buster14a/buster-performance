from pathlib import Path
base=Path(__file__).resolve().parent.parent/'source-declarator-shapes/src/buster/compiler'
p=base/'c_check_input.c'
s=p.read_text()
def rep(old,new):
 global s
 assert s.count(old)==1,old
 s=s.replace(old,new)
rep('    bool declarator_recover;', '''    const uint8_t* source_declarators;
    uint32_t source_plain_names;
    uint32_t source_plain_pointers;
    bool declarator_recover;''')
rep('    bool used, failed, keep_boundaries;', '''    bool used, failed, keep_boundaries, prepare_declarators;
    uint8_t* declarators;''')
point='static void check_input_publish_window('
rep(point,'''static void check_input_publish_declarators(const ParseTokens* tokens, const ParseTree* tree, uint8_t* shapes, uint32_t begin, uint32_t end)
{
    memset(shapes + begin, 0, end - begin);
    for (uint32_t token = begin; token + 1 < end; token += 1)
    {
        if (tokens->kinds[token] != PARSE_KIND_IDENTIFIER || tree->roles[token] != PARSE_ROLE_OPERAND) continue;
        const uint8_t stop = tokens->kinds[token + 1];
        if (stop != PARSE_KIND_SEMI && stop != PARSE_KIND_EQUAL && stop != PARSE_KIND_COMMA &&
            stop != PARSE_KIND_COLON && stop != PARSE_KIND_R_PAREN) continue;
        shapes[token] = 1;
        for (uint32_t stars = 1; stars <= 3 && stars <= token - begin && tokens->kinds[token - stars] == PARSE_KIND_STAR; stars += 1)
            shapes[token - stars] = (uint8_t)(stars + 1);
    }
}

''' + point)
rep('        live->owner = parser;', '''        if (live->prepare_declarators)
            live->declarators = arena_push_array(&parser->live_rows, (uint64_t)tokens->capacity + 1, sizeof(uint8_t), 64);
        live->owner = parser;''')
rep('    CheckInputTokenCounts* counts = &live->counts;', '''    if (live->declarators) check_input_publish_declarators(tokens, tree, live->declarators, begin, end);
    CheckInputTokenCounts* counts = &live->counts;''')
rep('        .grow_on_first_node = first_node,','''        .source_declarators = published ? live->declarators : NULL,
        .grow_on_first_node = first_node,''')
rep('        // Where the reader ended early, its recovered reports are still the unit\'s.', '''        if (reader.source_declarators && getenv("BUSTER_PARSE_LIVE_AUDIT"))
            fprintf(stderr, "source-declarators\\tnames=%u\\tpointers=%u\\tbefore-eof=%u\\n",
                    reader.source_plain_names, reader.source_plain_pointers, live->before_eof);
        // Where the reader ended early, its recovered reports are still the unit's.''')
rep('    CheckDeclaratorRun* run = check_input_declarator_begin(reader, base, *cursor, end);','''    const uint32_t start = *cursor;
    const uint32_t length = reader->source_declarators && start < end ? reader->source_declarators[start] : 0;
    if (length != 0 && length <= end - start && base >= BUSTER_TYPE_VOID && base <= BUSTER_TYPE_LONG_DOUBLE &&
        !reader->declarator_common && !reader->declarator_overloadable && !reader->specifier_noderef && !reader->specifier_abi_origin &&
        !reader->objc_attributes && !reader->padding_sugar)
    {
        const uint32_t after = start + length;
        TypeId type = base;
        for (uint32_t star = start; star + 1 < after && type != 0; star += 1)
            type = check_input_type_result(reader, type_pointer(reader->types, type));
        memset(reader->ignored + start, 1, length);
        reader->attribute_completion = after;
        if (reader->output->sugar_entries != 0) check_input_set_sugar(reader, after - 1, 0);
        reader->source_plain_names += 1;
        reader->source_plain_pointers += length - 1;
        CheckDeclaratorRun simple = { .valid = type != 0, .result = type, .mark = reader->scratch->length,
            .binding_mark = c_bindings_mark(&reader->bindings), .prototype_depth = reader->prototype_depth, .stop = after,
            .cursor = after, .name = after - 1, .names = BUSTER_CHECK_NONE, .declarations = BUSTER_CHECK_NONE,
            .function_part = BUSTER_CHECK_NONE, .swift_part = BUSTER_CHECK_NONE };
        return check_input_declarator_end(reader, &simple, cursor, name, names);
    }
    CheckDeclaratorRun* run = check_input_declarator_begin(reader, base, *cursor, end);''')
p.write_text(s)
p=base/'c_checker_driver.c'
s=p.read_text()
rep('.keep_boundaries = getenv("BUSTER_LIVE_RESOLVE_WINDOWS") != NULL }', '''.keep_boundaries = getenv("BUSTER_LIVE_RESOLVE_WINDOWS") != NULL,
                                                 .prepare_declarators = getenv("BUSTER_LIVE_DECLARATOR_SHAPES") != NULL }''')
p.write_text(s)
p=base/'c_check_attested_test.c'
s=p.read_text();pos='    { "declarator_recover", CHECK_ATTESTED_FIELD_TRANSIENT },'
rep(pos,''.join('    { "%s", CHECK_ATTESTED_FIELD_TRANSIENT },\n'%key for key in ['source_declarators','source_plain_names','source_plain_pointers'])+pos);p.write_text(s)
