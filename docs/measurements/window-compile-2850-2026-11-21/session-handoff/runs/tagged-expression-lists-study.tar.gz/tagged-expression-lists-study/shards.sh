#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d=$PWD
mkdir -p "$d/shards"
cd "../$1"
for i in 1 2 3 4 5 6 7 8;do
 "$d/compiler" test-checker --seed 2850 --part "$i/8" >"$d/shards/$i.log" 2>&1 && rc=0 || rc=$?
 echo "$rc" >"$d/shards/$i.status"
done
