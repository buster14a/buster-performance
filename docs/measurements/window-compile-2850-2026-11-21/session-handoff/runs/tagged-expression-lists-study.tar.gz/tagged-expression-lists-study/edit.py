from pathlib import Path
p=Path(__file__).resolve().parents[1]/'tagged-expression-lists/src/buster/compiler';f=p/'c_check_expression_input.c';g=p/'c_check_input.c';s=f.read_text();t=g.read_text()
begin=s.index('typedef struct CheckInputValues');end=s.index('};',begin)+3;record=s[begin:end];s=s[:begin]+s[end:]
pos=t.index('typedef struct CheckInputReader CheckInputReader;');t=t[:pos]+record+'''
typedef struct CheckInputValueTail
{
    uint32_t last;
    uint32_t count;
} CheckInputValueTail;

'''+t[pos:]
needle='    uint32_t* value_counts;';assert t.count(needle)==1;t=t.replace(needle,needle+'\n    CheckInputValueTail* value_tails;')
pos=t.index('// A constant reading\'s failure evidence')
t=t[:pos]+'''// A single node describes its whole list. Only genuine multi-value tokens need tail and length.
static inline CheckInputValues check_input_values_at(const CheckInputReader* reader, uint32_t token)
{
    const uint32_t first = reader->first_value[token];
    if (first == BUSTER_CHECK_NONE) return (CheckInputValues){ BUSTER_CHECK_NONE, BUSTER_CHECK_NONE, 0 };
    if (reader->value_tails == NULL) return (CheckInputValues){ first, reader->last_value[token], reader->value_counts[token] };
    if ((first >> 31) == 0) return (CheckInputValues){ first, first, 1 };
    const CheckInputValueTail tail = reader->value_tails[token];
    return (CheckInputValues){ first & INT32_MAX, tail.last, tail.count };
}

static inline void check_input_values_write(CheckInputReader* reader, uint32_t token, uint32_t first, uint32_t last, uint32_t count)
{
    if (reader->value_tails == NULL)
    {
        reader->first_value[token] = first;
        reader->last_value[token] = last;
        reader->value_counts[token] = count;
    }
    else if (count > 1 && first != BUSTER_CHECK_NONE)
    {
        reader->first_value[token] = first | UINT32_C(0x80000000);
        reader->value_tails[token] = (CheckInputValueTail){ last, count };
    }
    else reader->first_value[token] = first;
}

'''+t[pos:]
import re
for name in ['t','s']:
 a=locals()[name]
 # Replace only the real writers below these helpers.
 start=a.index('// A constant reading\'s failure evidence') if name=='t' else 0
 b=a[start:]
 b=re.sub(r'reader->first_value\[token\] = (node|first|values.first);\n\s+reader->last_value\[token\] = (node|last|values.last);\n\s+reader->value_counts\[token\] = (1|count|values.count);',r'check_input_values_write(reader, token, \1, \2, \3);',b)
 b=b.replace('const uint32_t begin = reader->first_value[child];','const CheckInputValues child_values = check_input_values_at(reader, child);\n        const uint32_t begin = child_values.first;').replace('reader->last_value[child]','child_values.last').replace('reader->value_counts[child]','child_values.count')
 b=b.replace('chain = reader->first_value[token];\n                        chained = chain != BUSTER_CHECK_NONE ? reader->value_counts[token] : 0;', 'const CheckInputValues retained = check_input_values_at(reader, token);\n                        chain = retained.first;\n                        chained = retained.count;')
 if name=='t':t=a[:start]+b
 else:s=b
t=t.replace('    BUSTER_CHECK_INPUT_ARRAY(last_value, uint32_t);\n    BUSTER_CHECK_INPUT_ARRAY(value_counts, uint32_t);','''    if (deferred == NULL && graph_capacity < INT32_MAX && getenv("BUSTER_TAGGED_VALUES") != NULL)
    {
        BUSTER_CHECK_INPUT_ARRAY(value_tails, CheckInputValueTail);
    }
    else
    {
        BUSTER_CHECK_INPUT_ARRAY(last_value, uint32_t);
        BUSTER_CHECK_INPUT_ARRAY(value_counts, uint32_t);
    }''')
g.write_text(t);f.write_text(s)
f=p/'c_check_attested_test.c';s=f.read_text().replace('    { "value_counts", CHECK_ATTESTED_FIELD_OWN },','    { "value_counts", CHECK_ATTESTED_FIELD_OWN },\n    { "value_tails", CHECK_ATTESTED_FIELD_OWN },');f.write_text(s)
