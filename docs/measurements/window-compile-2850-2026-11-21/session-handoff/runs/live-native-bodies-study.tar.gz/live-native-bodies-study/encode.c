// Keep the first real encoded text and field positions beside the exact selected instruction
// records. Later layout supplies its own symbol identities and addends for these fields.
static int64_t check_program_live_encode(CheckEmitRun* run, uint32_t b, const EmittedCode* code,
                                         uint8_t* destination, uint64_t capacity, uint32_t* ends)
{
    CheckLiveNative* state = run->program->parser != NULL ? run->program->parser->live_native : NULL;
    if (state == NULL) return x86_encode(code->records, code->count, destination, capacity, NULL, ends);
    const uint32_t opening = run->program->bodies[b].opening;
    if (state->capture)
    {
        const int64_t size = x86_encode(code->records, code->count, destination, capacity, NULL, ends);
        if (size < 0 || size > UINT32_MAX || (state->count && opening <= state->rows[state->count - 1].opening)) return size;
        if (state->count == state->capacity)
        {
            const uint32_t room = state->capacity ? 2 * state->capacity : 64;
            CheckLiveFragment* next = BUSTER_ARENA_PUSH_ARRAY(state->storage, CheckLiveFragment, room);
            if (!next) return size;
            if (state->count) memcpy(next, state->rows, (size_t)state->count * sizeof(*next));
            state->rows = next;
            state->capacity = room;
        }
        X86Instruction* instructions = BUSTER_ARENA_PUSH_ARRAY(state->storage, X86Instruction, (uint64_t)code->count + 1);
        uint8_t* bytes = BUSTER_ARENA_PUSH_ARRAY(state->storage, uint8_t, (uint64_t)size + 1);
        uint32_t* fields = BUSTER_ARENA_PUSH_ARRAY(state->storage, uint32_t, (uint64_t)code->reference_count + 1);
        if (!bytes || !instructions || !fields) return size;
        memcpy(bytes, destination, (size_t)size);
        memcpy(instructions, code->records, (size_t)code->count * sizeof(*instructions));
        if (code->reference_count) memcpy(fields, ends, (size_t)code->reference_count * sizeof(*fields));
        state->rows[state->count++] = (CheckLiveFragment){opening, code->count, code->reference_count, (uint32_t)size, instructions, fields, bytes};
        state->bytes += size;
        return size;
    }
    uint32_t low = 0, high = state->count;
    while (low < high)
    {
        const uint32_t mid = low + (high - low) / 2;
        if (state->rows[mid].opening < opening) low = mid + 1;
        else high = mid;
    }
    if (low < state->count)
    {
        const CheckLiveFragment* early = state->rows + low;
        if (early->opening == opening && early->count == code->count && early->references == code->reference_count &&
            early->size <= capacity && memcmp(code->records, early->instructions, (size_t)code->count * sizeof(X86Instruction)) == 0)
        {
            memcpy(destination, early->bytes, early->size);
            if (early->references) memcpy(ends, early->ends, (size_t)early->references * sizeof(*ends));
            if (state->audit) fprintf(stderr, "pre-eof-native-consumed\t%u\t%u\t%u\n", opening, early->size, early->references);
            return early->size;
        }
    }
    return x86_encode(code->records, code->count, destination, capacity, NULL, ends);
}

