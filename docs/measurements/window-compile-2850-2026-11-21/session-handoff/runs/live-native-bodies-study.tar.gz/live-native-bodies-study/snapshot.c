// This speculative check sees only the immutable declaration prefix. Its own identifier table,
// diagnostics, type arena and checker storage are discarded before the original preprocessor resumes.
static void check_driver_live_native_prefix(Parser* owner, Preprocessor* pp, Parser* prefix, uint32_t source_end)
{
    CheckLiveNative* state = owner->live_native;
    const uint32_t count = prefix->tokens.count;
    if (!state || state->count || !count || pp->errors || pp->history_deferred || !pp->context_count ||
        source_end > pp->output.count || !check_source_native_output(pp, prefix)) return;
    InternTable* identifiers = calloc(1, sizeof(*identifiers));
    Preprocessor* overlay = malloc(sizeof(*overlay));
    if (!identifiers || !overlay) { free(identifiers); free(overlay); return; }
    *overlay = *pp;
    overlay->source_forest = NULL;
    overlay->source_range = NULL;
    overlay->context_count = 0;
    overlay->output.count = source_end;
    overlay->table = identifiers;
    overlay->diagnostic_first = NULL;
    overlay->diagnostic_last = NULL;
    overlay->diagnostic_source = true;
    overlay->arena = arena_reserve(UINT64_C(1) << 32);
    Arena facts = arena_reserve(UINT64_C(1) << 36);
    Arena scratch = arena_reserve(UINT64_C(1) << 36);
    const TypeCapacity cap = { .types = 4 * count + 64, .parameters = count, .tags = count, .members = count };
    const uint64_t tb = type_capacity_bytes(cap);
    Arena type_memory = arena_reserve_small(tb, tb);
    Arena index_memory = arena_reserve_small(type_index_capacity_bytes(cap), BUSTER_TYPE_INDEX_SMALL_BYTES);
    TypeTable types = { 0 };
    CheckInput input = { 0 };
    bool ready = facts.base && scratch.base && overlay->arena.base && type_memory.base && index_memory.base &&
                 type_initialize(&types, &type_memory, &index_memory, cap) && intern_initialize(identifiers);
    for (uint32_t i = 1; ready && i < pp->table->count; i += 1)
        ready = intern_find_or_add(identifiers, intern_bytes(pp->table, i), intern_length(pp->table, i)) == i;
    prefix->live_consumer = NULL;
    prefix->preprocessor = overlay;
    state->capture = true;
    if (ready) ready = check_input_compile(&input, prefix, overlay, &types, &facts, &scratch, true, count, NULL);
    state->capture = false;
    if (state->audit)
        fprintf(stderr, "pre-eof-native-prefix\trows=%u\tpp=%u\tactive-contexts=%u\tready=%u\tfragments=%u\tbytes=%llu\n",
                count, source_end, pp->context_count, ready, state->count, (unsigned long long)state->bytes);
    if (!ready) state->count = 0;
    intern_release(identifiers);
    arena_release(&type_memory);
    arena_release(&index_memory);
    arena_release(&scratch);
    arena_release(&facts);
    arena_release(&overlay->arena);
    free(identifiers);
    free(overlay);
}

