from pathlib import Path
d=Path(__file__).resolve().parent.parent/'prefix-leaf-dictionary/src/buster/compiler'
def rep(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
p=d/'c_check_input.c';s=p.read_text()
pos='typedef struct CheckInputReader CheckInputReader;'
rep(pos,'''typedef struct CheckPublishedLeaf
{
    uint64_t type, flags, object;
    uint32_t declaration, status;
    uint8_t verified;
} CheckPublishedLeaf;

typedef struct CheckPublishedLeaves
{
    CheckPublishedLeaf* slots;
    uint32_t capacity, produced, validated, reused, declined;
    bool capture, audit, oracle;
} CheckPublishedLeaves;

'''+pos)
rep('    uint8_t* expression_commas;', '    uint8_t* expression_commas;\n    CheckPublishedLeaves* published_leaves;')
rep('    bool capture, audit, ordinary;', '    bool capture, audit, ordinary, keep_leaves;\n    CheckPublishedLeaves leaves;')
rep('    CheckInputReader reader =\n', '''    CheckLiveNative* native = parser->live_native;
    CheckInputReader reader =
''')
rep('        .grow_on_first_node = first_node,','''        .published_leaves = native && native->leaves.slots ? &native->leaves : NULL,
        .grow_on_first_node = first_node,''')
rep("        // Where the reader ended early, its recovered reports are still the unit's.",'''        if (reader.published_leaves && native->audit)
            fprintf(stderr, "semantic-leaf-records\\tcapture=%u\\tproduced=%u\\tvalidated=%u\\tconsumed=%u\\tdeclined=%u\\n",
                    native->capture, native->leaves.produced, native->leaves.validated, native->leaves.reused, native->leaves.declined);
        // Where the reader ended early, its recovered reports are still the unit's.''')
p.write_text(s)
p=d/'c_checker_driver.c';s=p.read_text()
rep('.ordinary = getenv("BUSTER_LIVE_ORDINARY_HANDOFF") != NULL,', '.ordinary = getenv("BUSTER_LIVE_ORDINARY_HANDOFF") != NULL, .keep_leaves = getenv("BUSTER_PRE_EOF_LEAVES") != NULL,')
rep('    check_capture_native_prefix = state->ordinary;', '''    if (state->keep_leaves)
    {
        uint32_t capacity = 256;
        while (capacity < count / 16 && capacity < (1u << 20)) capacity *= 2;
        state->leaves = (CheckPublishedLeaves){ .slots = BUSTER_ARENA_PUSH_ARRAY(state->storage, CheckPublishedLeaf, capacity),
            .capacity = capacity, .capture = true, .audit = state->audit, .oracle = getenv("BUSTER_LIVE_CHECKED_ORACLE") != NULL };
        if (state->leaves.slots) memset(state->leaves.slots, 0, (size_t)capacity * sizeof(CheckPublishedLeaf));
    }
    check_capture_native_prefix = state->ordinary;''')
rep('    if (!ready) state->count = 0;', '''    state->leaves.capture = false;
    if (!ready) { state->count = 0; state->leaves.slots = NULL; }''')
p.write_text(s)
p=d/'c_check_attested_test.c';s=p.read_text();rep('    { "expression_commas",','    { "published_leaves", CHECK_ATTESTED_FIELD_TRANSIENT },\n    { "expression_commas",');p.write_text(s)
p=d/'c_check_expression_input.c';s=p.read_text()
a=s.index('static uint32_t check_input_expression_identifiers(');b=s.index('\n}',a)+2
v=s[a:b].replace('check_input_expression_identifiers(', 'check_input_decode_identifiers(')
v+='''
static CheckPublishedLeaf* check_input_leaf_slot(CheckPublishedLeaves* leaves, uint32_t declaration)
{
    return leaves->slots + ((declaration * UINT32_C(2654435761) >> 8) & (leaves->capacity - 1));
}

static bool check_input_leaf_equal(const CheckPublishedLeaf* leaf, const CheckInputIdentifiers* result, uint32_t at)
{
    return leaf->type == result->types[at] && leaf->flags == result->flags[at] &&
           leaf->object == result->objects[at] && leaf->status == result->status[at] &&
           leaf->declaration == result->declarations[at] + 1;
}

// A declaration supplies the same leaf to repeated uses when its type and binding agree. The first
// ordinary use validates everything that depends on the final translation unit. The admitted
// categories have no per-use register, enumerator, overload, or weak-symbol behavior.
static uint32_t check_input_expression_identifiers(const CheckInputReader* reader, const uint32_t* tokens, const uint32_t* classes, uint32_t acting,
                                                  CheckInputIdentifiers* result)
{
    CheckPublishedLeaves* leaves = reader->published_leaves;
    const CheckInput* out = reader->output;
    if (!leaves || out->overload_heads || out->weak_name_count || (out->symbol_pragmas && out->symbol_pragmas->count) ||
        out->kr_parameter_count || (!leaves->capture && reader->lane))
        return check_input_decode_identifiers(reader, tokens, classes, acting, result);
    const uint32_t identifier = BUSTER_CHECK_EXPRESSION_ACTS | CHECK_INPUT_CODE_IDENTIFIER << BUSTER_CHECK_EXPRESSION_CODE_SHIFT;
    if (leaves->capture) check_input_decode_identifiers(reader, tokens, classes, acting, result);
    uint32_t count = 0, missing = 0;
    uint32_t slow_tokens[BUSTER_CHECK_EXPRESSION_CHUNK], slow_classes[BUSTER_CHECK_EXPRESSION_CHUNK], indices[BUSTER_CHECK_EXPRESSION_CHUNK];
    for (uint32_t start = 0; start < acting; start += 16)
    {
        const __mmask16 lanes = (__mmask16)_bzhi_u32(UINT32_MAX, acting - start < 16 ? acting - start : 16);
        uint32_t bits = _mm512_mask_cmpeq_epi32_mask(lanes, _mm512_maskz_loadu_epi32(lanes, classes + start), _mm512_set1_epi32((int32_t)identifier));
        for (; bits; bits &= bits - 1)
        {
            const uint32_t token = tokens[start + (uint32_t)__builtin_ctz(bits)];
            const TypeId type = reader->declared_types[token];
            const uint32_t decl = out->declarations[token];
            CheckPublishedLeaf* leaf = check_input_leaf_slot(leaves, decl);
            if (leaves->capture)
            {
                const uint8_t kind = type ? type_kind(reader->types, type) : BUSTER_TYPE_KIND_NONE;
                if (!leaf->declaration && type && decl < reader->parser->tokens.count &&
                    result->status[count] == (BUSTER_CHECK_IDENTIFIER_ACTED | BUSTER_CHECK_IDENTIFIER_NODE) &&
                    !(result->flags[count] & BUSTER_CHECK_REGISTER) && kind != BUSTER_TYPE_KIND_ENUM && kind != BUSTER_TYPE_KIND_ALIGNED)
                {
                    *leaf = (CheckPublishedLeaf){ .type = result->types[count], .flags = result->flags[count],
                                                  .object = result->objects[count], .declaration = decl + 1, .status = result->status[count] };
                    leaves->produced += 1;
                }
            }
            else
            {
                bool known = type && decl != BUSTER_CHECK_NONE && leaf->declaration == decl + 1 && type == (TypeId)leaf->type;
                if (known && !leaf->verified)
                {
                    const uint8_t kind = type_kind(reader->types, type);
                    check_input_identifier_entry(reader, token, result, count);
                    leaf->verified = kind != BUSTER_TYPE_KIND_ENUM && kind != BUSTER_TYPE_KIND_ALIGNED && check_input_leaf_equal(leaf, result, count) ? 1 : 2;
                    leaves->validated += leaf->verified == 1;
                }
                if (known && leaf->verified == 1)
                {
                    if (leaves->oracle)
                    {
                        check_input_identifier_entry(reader, token, result, count);
                        if (!check_input_leaf_equal(leaf, result, count)) abort();
                    }
                    result->types[count] = leaf->type;
                    result->flags[count] = leaf->flags;
                    result->objects[count] = leaf->object;
                    result->declarations[count] = decl;
                    result->status[count] = leaf->status;
                    leaves->reused += leaves->audit;
                }
                else
                {
                    slow_tokens[missing] = token;
                    slow_classes[missing] = identifier;
                    indices[missing++] = count;
                }
            }
            count += 1;
        }
    }
    if (missing == count && missing)
    {
        leaves->declined += leaves->audit ? missing : 0;
        return check_input_decode_identifiers(reader, tokens, classes, acting, result);
    }
    if (missing)
    {
        CheckInputIdentifiers slow;
        check_input_decode_identifiers(reader, slow_tokens, slow_classes, missing, &slow);
        for (uint32_t i = 0; i < missing; i += 1)
        {
            const uint32_t at = indices[i];
            result->types[at] = slow.types[i];
            result->flags[at] = slow.flags[i];
            result->objects[at] = slow.objects[i];
            result->declarations[at] = slow.declarations[i];
            result->status[at] = slow.status[i];
        }
        leaves->declined += leaves->audit ? missing : 0;
    }
    return count;
}
'''
s=s[:a]+v+s[b:];p.write_text(s)
