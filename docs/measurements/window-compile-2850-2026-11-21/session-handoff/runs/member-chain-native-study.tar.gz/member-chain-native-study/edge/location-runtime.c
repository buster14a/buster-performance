
extern int printf(const char*,...);
struct Cell { unsigned short h; unsigned char bytes[7]; int val;};
struct All { struct Cell a,b; unsigned k; int *p; };
union Many { unsigned word; unsigned char chars[4]; };
static void bump(int *v, unsigned char *s){*v+=*s&7;}
static int consume(struct Cell c){return c.val+c.bytes[2];}
static unsigned run(struct All *z, union Many *u, unsigned j) {
  z->k += j; z->a.h=(z->a.h+z->k)&65535; z->a.bytes[j%7]=(unsigned char)(j*z->k);
  z->b=z->a;u->word=z->k;z->p=&z->b.val; bump(z->p, z->a.bytes+(j%7));
  return (unsigned)consume(z->b) ^ u->chars[j&3] ^ z->a.h;
}
int main(void){ struct All a={0},b={0};union Many m; unsigned long long h=3;
 for(unsigned j=0;j<4096;j++){h=h*131+run((j&1)?&a:&b,&m,j);}
 printf("%llu\n",h);return 0;}
