
extern int printf(const char*,...);
struct Wide { signed char a; unsigned short b; unsigned c; long d; char text; int *p; };
static unsigned fold(struct Wide *x, struct Wide *y, unsigned k){
 unsigned a=(unsigned)(x->a+y->b), b=(x->c & k) ^ (unsigned)(y->d - x->text);
 if((x->p!=0 && *x->p>0) || (y->a<0 && y->p!=0)){b^=x->b+y->b;}
 return a+b;
}
int main(void){ int cell=1;struct Wide x={-5,60000,51u,-81929,-16,&cell};
 struct Wide y={97,133,7400u,18183,23,0};unsigned long long h=17;
 for(unsigned j=0;j<4096;j++){x.c+=j;y.c^=j;h=h*131+fold((j&1)?&x:&y,(j&2)?&x:&y,j);}
 printf("%llu\n",h);return 0;}
