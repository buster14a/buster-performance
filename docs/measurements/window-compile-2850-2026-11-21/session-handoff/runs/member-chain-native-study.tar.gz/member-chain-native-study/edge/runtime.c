struct S{int lead; int x; unsigned bits:4; int tail;};
extern int printf(const char*,...);
static int read(struct S *p,struct S *q,unsigned m) {
  return (p->lead&m) ^ (q->x|m) ^ (p->tail ^ m) ^ (p->bits&m);
}
int main(void) {
  unsigned long long h=17;struct S a,b;
  for(unsigned i=0;i<4096;i++) {
    a.lead = i*119; a.x=i*35; a.tail=i+56; a.bits=i;
    b.lead=i+903; b.x=1701+i*179; b.tail=33-i; b.bits=i>>3;
    h = h*131 + (unsigned)read((i&1)?&a:&b,(i&4)?&a:&b,i*13);
  }
  printf("%llu\n",h);return 0;
}