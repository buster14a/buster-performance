from pathlib import Path
src=Path(__file__).resolve().parent.parent/'member-chain-native/src/buster/compiler'
p=src/'c_check_input.c';s=p.read_text().replace('#define BUSTER_CHECK_WINDOW_WRITE 0x04u','#define BUSTER_CHECK_WINDOW_WRITE 0x04u\n#define BUSTER_CHECK_WINDOW_FIELD_LOAD 0x08u\n#define BUSTER_CHECK_WINDOW_LAST_LOAD 0x10u');p.write_text(s)
p=src/'c_check_node_machine_rows.c';s=p.read_text();i=s.index('void check_node_window_member_pointer(');end=s.index('\n}',i)+2
s=s[:end]+'''

uint32_t check_node_window_member_step(CheckInputWindowRow* rows, uint32_t token, TypeId type, uint64_t offset, bool load, bool terminal)
{
    uint32_t count = 0;
    if (offset != 0)
    {
        rows[count++] = (CheckInputWindowRow){ .token=token, .kind=BUSTER_TYPED_CONST, .class=BUSTER_TYPED_CLASS_U64, .value=offset };
        rows[count++] = (CheckInputWindowRow){ .token=token, .kind=BUSTER_TYPED_PTR_ADD, .class=BUSTER_TYPED_CLASS_U64, .value=1 };
    }
    if (load)
    {
        rows[count++] = (CheckInputWindowRow){ .token=token, .kind=BUSTER_TYPED_LOAD, .value=type,
            .flags=BUSTER_CHECK_WINDOW_FIELD_LOAD | (terminal ? BUSTER_CHECK_WINDOW_LAST_LOAD : 0) };
    }
    return count;
}
'''+s[end:];p.write_text(s)
p=src/'c_check_program_lower.c';s=p.read_text();i=s.index('        uint64_t native_value = row->value;',s.index('void check_lower_window('));s=s[:i]+'''        if ((row->flags & BUSTER_CHECK_WINDOW_FIELD_LOAD) != 0)
        {
            if (load || (row->flags & BUSTER_CHECK_WINDOW_LAST_LOAD) == 0)
            {
                const TypeId field_type = (TypeId)row->value;
                const uint8_t field_class = check_lower_class(writer, field_type);
                writer->token = row->token;
                check_lower_source(writer, row->token);
                check_lower_emit(writer, BUSTER_TYPED_LOAD, field_class, check_lower_access(writer, field_class, field_type));
            }
            continue;
        }
'''+s[i:];s=s.replace('if (summary->member != 0 && writer->output->status == CHECK_PROGRAM_OK)','if (summary->member != 0 && writer->output->status == CHECK_PROGRAM_OK &&\n        (program->input->window_rows[summary->first + summary->count - 1].flags & BUSTER_CHECK_WINDOW_LAST_LOAD) == 0)');p.write_text(s)
p=src/'c_check_expression_input.c';s=p.read_text()
i=s.index('static bool check_input_window_local(')
s=s[:i]+'''uint32_t check_node_window_member_step(CheckInputWindowRow* rows, uint32_t token, TypeId type, uint64_t offset, bool load, bool terminal);

static bool check_input_chain_context(const CheckInputReader* reader, uint32_t token)
{
    const Parser* p = reader->parser;
    for (uint32_t steps = 0; token < p->tokens.count && steps < 64; steps += 1)
    {
        const uint32_t role = p->tree.roles[token];
        if ((reader->builtins != NULL && reader->builtins[token] != 0) ||
            (reader->constant_contexts != NULL && reader->constant_contexts[token] != 0))
            return false;
        if (role == PARSE_ROLE_RETURN || role == PARSE_ROLE_TERMINATOR || role == PARSE_ROLE_OPEN_CONDITION)
            return true;
        if (role == PARSE_ROLE_OPEN_BODY || role == PARSE_ROLE_OPEN_BLOCK) return false;
        token = p->tree.parents[token];
    }
    return false;
}

static uint32_t check_input_member_chain(CheckInputReader* reader, CheckInputBatch* batch, const uint32_t* tokens, const uint32_t* classes,
                                         uint32_t first, uint32_t end, const CheckInputIdentifiers* ids, uint32_t identifier)
{
    const Parser* p=reader->parser;
    CheckInput* input=reader->output;
    TypeTable* types=reader->types;
    const uint32_t base=tokens[first], op=tokens[first+1];
    const uint32_t declaration=ids->declarations[identifier];
    const TypeId base_type=(TypeId)ids->types[identifier];
    if (op != base+1 || p->tokens.kinds[op] != PARSE_KIND_ARROW || p->tree.parents[base] != op ||
        ids->status[identifier] != (BUSTER_CHECK_IDENTIFIER_ACTED | BUSTER_CHECK_IDENTIFIER_NODE) ||
        (ids->types[identifier] >> 32) != CHECK_LVALUE || ids->flags[identifier] != (((uint64_t)CHECK_CONSTANT_ADDRESS<<32)|BUSTER_CHECK_NONNULL_ADDRESS) ||
        declaration >= input->token_count || ids->objects[identifier] != (uint64_t)declaration+1 ||
        input->declaration_kinds[declaration] != C_BINDING_OBJECT || check_sparse_get(input->declaration_bodies,declaration) >= input->token_count ||
        check_input_bit(input->declaration_bits,declaration,BUSTER_CHECK_BITS_STATIC | BUSTER_CHECK_BITS_THREAD_LOCAL) ||
        check_input_attributes_at(input,declaration) != NULL || !type_is_valid(types,base_type) || type_qualifiers(base_type) != 0 ||
        type_kind(types,base_type) != BUSTER_TYPE_KIND_POINTER || reader->tag_completions == NULL)
        return 0;
    uint32_t stop=first+1, root=base;
    while (stop < end && check_input_window_code(classes,stop) == CHECK_INPUT_CODE_MEMBER &&
           tokens[stop] == (stop==first+1 ? base+1 : root+2) && p->tree.parents[root] == tokens[stop] &&
           tokens[stop]+1 < p->tokens.count && p->tree.roles[tokens[stop]+1] == PARSE_ROLE_MEMBER)
    {
        root=tokens[stop++];
    }
    const uint32_t parent=p->tree.parents[root];
    if (stop-first<2 || stop-first>17 || parent>=p->tokens.count ||
        ((p->tokens.kinds[parent]==PARSE_KIND_ARROW || p->tokens.kinds[parent]==PARSE_KIND_PERIOD) && p->tree.parents[root]==parent) ||
        !check_input_chain_context(reader,parent))
        return 0;
    CheckInputWindowRow rows[1+3*16];
    check_node_window_member_pointer(rows,(uint32_t)ids->objects[identifier],base);
    uint32_t count=1, member=0;
    TypeId type=base_type;
    for (uint32_t a=first+1; a<stop; a+=1)
    {
        const uint32_t t=tokens[a];
        const bool arrow=p->tokens.kinds[t]==PARSE_KIND_ARROW;
        if (arrow && type_kind(types,type)!=BUSTER_TYPE_KIND_POINTER) return 0;
        const TypeId record=arrow?type_element(types,type):type;
        const uint8_t kind=type_kind(types,record);
        if ((kind!=BUSTER_TYPE_KIND_STRUCT && kind!=BUSTER_TYPE_KIND_UNION) || type_qualifiers(record)!=0 ||
            !type_is_complete(types,record)) return 0;
        const uint32_t tag=types->types.index[type_index(record)];
        if (reader->tag_completions[tag]>t) return 0;
        uint64_t bits=0; uint32_t quals=0;
        const uint32_t name=p->tokens.names[t+1];
        member=type_lookup_member(types,record,name,&bits,&quals);
        if (member==0 || member==BUSTER_TYPE_MEMBER_UNKNOWN || member-types->tags.member_begin[tag]>=types->tags.member_count[tag] ||
            types->members.name[member]!=name || types->members.flags[member]!=0 || quals!=0 || (bits&7)!=0 ||
            check_marked_member(input->marked_members,input->marked_member_count,member)!=NULL) return 0;
        type=types->members.type[member];
        if (type_qualifiers(type)!=0) return 0;
        const bool last=a+1==stop;
        const bool load=last || p->tokens.kinds[tokens[a+1]]==PARSE_KIND_ARROW;
        if (last && !((type>=BUSTER_TYPE_BOOL && type<=BUSTER_TYPE_ULLONG) || type_kind(types,type)==BUSTER_TYPE_KIND_POINTER)) return 0;
        count+=check_node_window_member_step(rows+count,t,type,bits/8,load,last);
    }
    const CheckValue value={.type=type,.category=CHECK_LVALUE,.flags=BUSTER_CHECK_NONNULL_ADDRESS};
    const uint32_t node=check_input_window_publish(reader,batch,root,value,rows,count,stop-first);
    if (node==BUSTER_CHECK_NONE) return 0;
    input->window_summaries[input->window_count-1].member=member;
    check_input_expression_value(reader,root,node);
    if (getenv("BUSTER_CHAIN_AUDIT")!=NULL)
        fprintf(stderr,"source-chain\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\n",base,root,stop-first-1,count,node,type);
    return stop-first;
}

'''+s[i:]
needle='    const uint32_t dropped = BUSTER_CHECK_EXPRESSION_ACTS'
i=s.index(needle,s.index('static void check_input_expressions_coded_range('));s=s[:i]+'''    const bool member_chains = coded && getenv("BUSTER_CONTROL_MEMBER_OPERANDS") != NULL &&
        input->overload_heads == NULL && input->noderef_member_count == 0 && input->noderef_declaration_count == 0 &&
        !reader->pp->options.predefines.debug && !reader->pp->options.predefines.debug_modules && !reader->lane &&
        input->musttail_count == 0 && reader->expression_declined == NULL && reader->parser->errors == 0 &&
        input->graph.fp_environments == NULL && !reader->pp->options.expression_timing && reader->pp->options.node_front == 0;
'''+s[i:]
needle='        if (window)\n        {\n            i = reader->pp->options.node_window_constants ?'
s=s.replace(needle,'''        if (member_chains)
        {
            while (i < acting && !reader->output->resource)
            {
                if (i+1 < acting && check_input_window_code(classes,i)==CHECK_INPUT_CODE_IDENTIFIER && check_input_window_code(classes,i+1)==CHECK_INPUT_CODE_MEMBER)
                {
                    const uint32_t span=check_input_member_chain(reader,batch,tokens,classes,i,acting,&identifiers,identifier);
                    if (span != 0) { i+=span; identifier+=1; continue; }
                }
                check_input_expression_coded(reader,batch,tokens[i],(uint8_t)classes[i],coded,&identifiers,&identifier,&literals,&literal,visit_ticks);
                i+=1;
            }
        }
        else if (window)
        {
            i = reader->pp->options.node_window_constants ?''',1)
p.write_text(s)
