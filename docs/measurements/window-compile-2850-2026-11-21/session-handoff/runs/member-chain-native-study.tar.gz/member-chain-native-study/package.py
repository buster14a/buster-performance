from pathlib import Path
import os,subprocess,csv,json,collections,hashlib,shutil,gzip
p=Path(__file__).resolve().parent;w=p.parent;d=p/'evidence/b87dfaa84';d.mkdir(exist_ok=True,parents=True)
def cp(source,name=None):
 if source.exists():shutil.copy2(source,d/(name or source.name))
def gz(source,name=None):
 if source.exists():
  dest=d/(name or source.name+'.gz')
  if not dest.exists() or dest.stat().st_mtime<source.stat().st_mtime:
   with source.open('rb') as i, gzip.open(dest,'wb',compresslevel=1) as o:shutil.copyfileobj(i,o)
def patch(repo,a,b,name):
 with (d/name).open('wb') as o:subprocess.run(['git','-C',w/repo,'diff',a,b],stdout=o,check=True)
patch('member-chain-native','11e5912d8','b87dfaa84','member-batches.patch');patch('member-chain-spelling','921845259','350f3d039','connected-batches.patch')
patch('member-chain-record-root','44f9ce339','73e10f251','record-root.patch')
for n in ['run.sh','edge.py','edge.tsv','probe.c','probe-driver.c','mutation.sh','prove.sh','join.py','timing.py','timing.tsv','timing-summary.tsv','optimized.py','corpus.py','corpus.sh','probe-production.stdout','probe-poison.stdout','probe-mutation.stdout']:cp(p/n)
gz(p/'joined.tsv','source-member-join.tsv.gz')
for category in ['sqlite','main','lua','musl']:gz(p/'real'/(category+'.tsv'),category+'-policy.tsv.gz')
facts=w/'member-chain-lowering-proof-study'
for n in ['checked.py','capture.sh','setup.py','compare.py']:cp(facts/n,'oracle-'+n)
with (d/'raw.sha256').open('w') as o:
 for item in ['probe','sqlite','main']:
  cp(facts/(item+'.oracle.json'))
  for arm in ['base','chain']:
   for kind in ['graph','typed','stderr','o']:
    f=facts/(item+'.'+arm+'.'+kind)
    if not f.exists():continue
    print(hashlib.file_digest(f.open('rb'),'sha256').hexdigest(),f.name,file=o)
    if kind in ['graph','typed']:gz(f)
   if arm=='chain':gz(facts/(item+'.chain.stderr'),item+'.selected.tsv.gz')
for item in ['probe','sqlite','main']:
 for mode in ['ordinary','source','prior']:
  for arm in ['base','chain']:
   f=p/(f'{item}.{mode}.{arm}.stderr')
   if not f.exists():continue
   # Physical proof preserves event raw as well as independently observed graph counters.
   gz(f)
with (d/'scope.tsv').open('w') as o:
 out=csv.writer(o,delimiter='\t');out.writerow('input mode baseline-created candidate-created chains member-actions rows-emitted'.split())
 for item in ['probe','sqlite','main']:
  for mode in ['ordinary','source','prior']:
   stats=[]
   for arm in ['base','chain']:
    f=p/(f'{item}.{mode}.{arm}.stderr');graph=chains=hops=rows=0
    if not f.exists():continue
    for line in f.read_text().splitlines():
     v=line.split()
     if not v:continue
     if v[0]=='source-chain':chains+=1;hops+=int(v[3]);rows+=int(v[4])
     if v[0]=='chain-graph':graph+=int(v[4])-int(v[3])
    stats.append((graph,chains,hops,rows))
   if len(stats)==2:out.writerow([item,mode,stats[0][0],*stats[1]])
cp(w/'member-chain-record-root-study/edge.tsv','record-root-fixtures.tsv')
cp(w/'member-chain-spelling-study/prove.sh','connected.sh');cp(w/'member-chain-spelling-study/build.py','connected-build.py')

patch('member-chain-native','b87dfaa84','7844b9bd3','warning-typedef.patch')
patch('member-chain-compact','7844b9bd3','c637b0dc3','compact-offsets.patch')
for n in ['observables.py','observables.tsv','README.md']:cp(p/n)
sp=w/'member-chain-spelling-study'
for n in ['accepted.py','run.sh']:cp(sp/n,'connected-'+n)
gz(sp/'accepted.tsv','connected-declarations.tsv.gz')
for workload in ['sqlite','main','probe']:
 for arm in ['base','chain']:gz(sp/(workload+'.physical.'+arm+'.stderr'),'connected-'+workload+'.'+arm+'.stderr.gz')
compact=w/'member-chain-compact-study'
for n in ['timing.tsv','timing-summary.tsv','timing.py','optimized.py']:cp(compact/n,'compact-'+n)
for work,name in [(p,'original'),(compact,'compact')]:
 outdir=work/'timed'
 if outdir.exists():
  import tarfile
  with tarfile.open(d/(name+'-perf-counters.tar.gz'),'w:gz') as tar:
   for q in sorted(outdir.glob('*.pmu')):tar.add(q,arcname=q.name)

patch('member-chain-native','7844b9bd3','90a21788b','window-reserve.patch')
patch('member-chain-statements','a231dfa7a','6f4872937','compose-statements.patch')
for n in ['compose.py','overlap.tsv','overlap.py','limits.py','limits.tsv']:cp(p/n)
for n in ['dense-search.c','capacity-clean.err','capacity-after.err','capacity-before.err']:cp(p/'limits'/n)
cp(w/'member-chain-task-proof-study/tasks.py');cp(w/'member-chain-task-proof-study/tasks.tsv');cp(w/'member-chain-task-proof-study/observer.patch','lowering-task-observer.patch')
cp(w/'member-chain-statements-study/composition.tsv')

for n in ['attribution.py','profile.sh','instruction-samples.tsv','native-on.perf','native-off.perf','ordinary-on.perf','ordinary-off.perf','native-on.profile','native-off.profile','ordinary-on.profile','ordinary-off.profile']:cp(p/n)
for n in ['revision.txt','mutation.sh','probe-mutation.stdout','probe-poison.stdout']:cp(compact/n,'compact-'+n)
for item in ['probe','sqlite','main']:
 gz(w/'member-chain-task-proof-study'/(item+'.tasks.base.stderr'),item+'.lower-base.tsv.gz')
 gz(w/'member-chain-task-proof-study'/(item+'.tasks.chain.stderr'),item+'.lower-chain.tsv.gz')

patch('member-chain-record-root','7844b9bd3','38f8d46ef','record-root-integrated.patch')
for n in ['deep.c','deep-base.o','deep-chain.o','deep-chain.stderr']:cp(w/'member-chain-record-root-study'/n,'record-root-'+n)
for item in ['sqlite','main']:
 gz(compact/(item+'.compact.chain.stderr'),'compact-'+item+'-selected.tsv.gz')

cp(w/'member-chain-pure-record-study/edge.tsv','pure-record-policies.tsv')
patch('member-chain-pure-record','38f8d46ef','HEAD','pure-record-return.patch')
compactproof=w/'member-chain-compact-proof-study'
with (d/'compact-oracle.sha256').open('w') as o:
 for name in ['probe','sqlite','main']:
  for arm in ['base','chain']:
   f=compactproof/f'{name}.fresh.{arm}.typed'
   if f.exists():print(hashlib.file_digest(f.open('rb'),'sha256').hexdigest(),f.name,file=o)
cp(compactproof/'setup.py','compact-oracle-observer.py')
for n in ['instruction-samples.tsv','native-on.perf','native-off.perf','ordinary-on.perf','ordinary-off.perf']:cp(compact/n,'compact-'+n)

for n in ['sqlite-runtime.c','sqlite-runtime.sh','sqlite-runtime.log']:cp(p/n)
for q in p.glob('sqlite-runtime-*.stdout'):cp(q)
cp(p/'corpus-summary.py')
for group in ['sqlite','main','musl','lua']:
 gz(p/'final-real'/(group+'.tsv'),'capacity-final-'+group+'-policy.tsv.gz')
cp(p/'final-real'/'qualified-compiler.sha256')
with (d/'qualified-binaries.sha256').open('w') as o:
 for label,fn in [('ordinary timing b87dfaa84',p/'compiler-develop'),('pre-capacity diagnostics 7844b9bd3',p/'compiler-7844b9bd3'),('final diagnostics 90a21788b',p/'compiler-90a21788b'),('compact timing c637b0dc3',compact/'compiler-develop'),('physical retained selectors 350f3d039',sp/'compiler'),('native statement composition 1c77f4963',w/'member-chain-statements-study/compiler')]:
  if fn.exists():print(hashlib.file_digest(fn.open('rb'),'sha256').hexdigest(),label,file=o)

recordproof=w/'member-chain-record-proof-study';cp(recordproof/'probe.oracle.json','record-root.oracle.json')
for arm in ['base','chain']:
 for field in ['typed','graph']:
  gz(recordproof/f'probe.{arm}.{field}',f'record-root.{arm}.{field}.gz')
cp(p/'check-packet.py')
cp(p/'base-join.py')
gz(p/'base-source-overlap.tsv','base-source-overlap.tsv.gz')
