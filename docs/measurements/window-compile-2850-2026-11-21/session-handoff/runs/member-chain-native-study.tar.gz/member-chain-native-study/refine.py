from pathlib import Path
d=Path(__file__).resolve().parent.parent/'member-chain-native/src/buster/compiler'
p=d/'c_check_expression_input.c';s=p.read_text();a=s.index('uint32_t check_node_window_member_step(');b=s.index('static bool check_input_window_local(',a);new=s[a:b]
new=new.replace('uint32_t first, uint32_t end, const CheckInputIdentifiers* ids, uint32_t identifier)','uint32_t first, uint32_t end, const CheckInputIdentifiers* ids, uint32_t identifier, const CheckMemberChainOptions* options)')
new=new.replace('if (reader->tag_completions[tag]>t)', 'if (types->tags.packed[tag] != 0 || types->tags.ms_struct[tag] != 0 || reader->tag_completions[tag]>t)')
new=new.replace('count+=check_node_window_member_step(rows+count,t,type,bits/8,load,last);','if (options->mutate_token == t) bits += 8;\n        count+=check_node_window_member_step(rows+count,t,type,bits/8,load,last);')
new=new.replace('if (getenv("BUSTER_CHAIN_AUDIT")!=NULL)','if (options->audit)')
new='''typedef struct CheckMemberChainOptions
{
    bool enabled;
    bool audit;
    bool poison;
    uint32_t mutate_token;
} CheckMemberChainOptions;

'''+new
new+='''// Consume an entire postorder span before the base identifier or its selectors allocate ordinary nodes.
static uint32_t check_input_member_chain_span(CheckInputReader* reader, CheckInputBatch* batch, uint32_t* tokens, uint32_t* classes,
                                              uint32_t first, uint32_t end, CheckInputIdentifiers* ids, uint32_t* identifier,
                                              const CheckMemberChainOptions* options)
{
    if (first + 1 >= end || check_input_window_code(classes, first) != CHECK_INPUT_CODE_IDENTIFIER ||
        check_input_window_code(classes, first + 1) != CHECK_INPUT_CODE_MEMBER)
        return 0;
    const uint32_t before = reader->output->graph.count + batch->count;
    const uint32_t span = check_input_member_chain(reader, batch, tokens, classes, first, end, ids, *identifier, options);
    if (span != 0)
    {
        if (options->poison)
        {
            if (reader->output->graph.count + batch->count != before + 1) abort();
            // The surviving terminal VALUE is the sole handle read by ordinary enclosing expressions.
            // Destroy the skipped identifier result and all source action coordinates in this chunk.
            ids->status[*identifier] = UINT32_MAX;
            ids->types[*identifier] = UINT64_MAX;
            ids->flags[*identifier] = UINT64_MAX;
            ids->objects[*identifier] = UINT64_MAX;
            ids->declarations[*identifier] = UINT32_MAX;
            for (uint32_t i = first; i < first + span; i += 1)
            {
                tokens[i] = BUSTER_CHECK_NONE;
                classes[i] = UINT32_MAX;
            }
        }
        *identifier += 1;
    }
    return span;
}

'''
(d/'c_check_member_chain_input.c').write_text(new)
s=s[:a]+'#include "c_check_member_chain_input.c"\n\n'+s[b:]
s=s.replace('static __attribute__((noinline)) uint32_t check_input_window_actions(CheckInputReader* reader, CheckInputBatch* batch, const uint32_t* tokens, const uint32_t* classes,\n                                                                     uint32_t acting, const CheckInputIdentifiers* identifiers, const CheckInputLiterals* literals,\n                                                                     uint64_t* visited)','static __attribute__((noinline)) uint32_t check_input_window_actions(CheckInputReader* reader, CheckInputBatch* batch, uint32_t* tokens, uint32_t* classes,\n                                                                     uint32_t acting, CheckInputIdentifiers* identifiers, const CheckInputLiterals* literals,\n                                                                     uint64_t* visited, const CheckMemberChainOptions* chains)')
i=s.index('static __attribute__((noinline)) uint32_t check_input_window_actions(');j=s.index('            check_input_expression_coded(reader, batch, tokens[cursor]',i)
s=s[:j]+'''            const uint32_t span = chains->enabled ? check_input_member_chain_span(reader, batch, tokens, classes, cursor, first, identifiers, &identifier, chains) : 0;
            if (span != 0)
            {
                cursor += span - 1;
                continue;
            }
'''+s[j:]
needle='    const uint32_t dropped = BUSTER_CHECK_EXPRESSION_ACTS'
i=s.index(needle,s.index('static void check_input_expressions_coded_range('))
s=s[:i]+'''    const char* mutate = member_chains ? getenv("BUSTER_CHAIN_MUTATE_TOKEN") : NULL;
    const CheckMemberChainOptions chains = {
        .enabled = member_chains, .audit = member_chains && getenv("BUSTER_CHAIN_AUDIT") != NULL,
        .poison = member_chains && getenv("BUSTER_CHAIN_POISON") != NULL,
        .mutate_token = mutate != NULL ? (uint32_t)strtoul(mutate, NULL, 10) : BUSTER_CHECK_NONE
    };
'''+s[i:]
i=s.index('        if (member_chains)\n');j=s.index('        else if (!timed)',i)
s=s[:i]+'''        if (window)
        {
            i = reader->pp->options.node_window_constants ?
                check_integer_window_actions(reader, batch, tokens, classes, acting, &identifiers, &literals, visit_ticks) :
                check_input_window_actions(reader, batch, tokens, classes, acting, &identifiers, &literals, visit_ticks, &chains);
        }
        else if (member_chains)
        {
            while (i < acting && !reader->output->resource)
            {
                const uint32_t span = check_input_member_chain_span(reader, batch, tokens, classes, i, acting, &identifiers, &identifier, &chains);
                if (span != 0)
                {
                    i += span;
                    continue;
                }
                check_input_expression_coded(reader, batch, tokens[i], (uint8_t)classes[i], coded, &identifiers, &identifier, &literals, &literal, visit_ticks);
                i += 1;
            }
        }
'''+s[j:]
# Final range evidence with the existing graph counter, after its batch has been flushed.
i=s.index('\n}',s.index('        else if (member_chains)'))
s=s[:i]+'''\n    if (getenv("BUSTER_CHAIN_GRAPH") != NULL)
        fprintf(stderr, "chain-graph\\t%u\\t%u\\t%u\\t%u\\n", begin, stop, base, reader->output->graph.count);
'''+s[i:]
p.write_text(s)
