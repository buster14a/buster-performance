struct I{int v;}; struct A{struct I *i;}; struct B{struct A *a;}; unsigned f(struct B*b){return __builtin_object_size(&b->a->i->v,1);}
