struct C{char pad[0x100000000ULL]; int v;}; struct P{struct C*c;}; int f(struct P*p){return p->c->v;}
