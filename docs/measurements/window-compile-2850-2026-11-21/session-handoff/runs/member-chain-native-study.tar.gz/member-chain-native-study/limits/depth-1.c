struct C0{char padding;int leaf;};int f(struct C0*r){return r->leaf;}
