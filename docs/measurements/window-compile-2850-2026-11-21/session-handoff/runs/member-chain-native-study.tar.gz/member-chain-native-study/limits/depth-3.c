struct C0{char padding;int leaf;};struct C1{char padding;struct C0 *p;};struct C2{char padding;struct C1 *p;};int f(struct C2*r){return r->p->p->leaf;}
