typedef unsigned long Len;struct R{Len n;};struct Q{struct R *r;};
#define CMP(v,x) ((v)<(x)?(v):(x))
unsigned long f(struct Q*q,long d){return CMP(q->r->n,d);}
