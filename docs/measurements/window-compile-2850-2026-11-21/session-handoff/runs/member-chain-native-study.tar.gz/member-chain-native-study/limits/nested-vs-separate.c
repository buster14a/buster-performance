struct I{int v;}; struct A{struct I *i;}; struct B{struct A *a;}; int f(struct B*b,int g){return g+b->a->i->v+sizeof b->a->i->v;}
