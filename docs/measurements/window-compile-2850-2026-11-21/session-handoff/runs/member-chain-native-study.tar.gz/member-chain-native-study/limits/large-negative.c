struct C{char pad[-1]; int v;}; struct P{struct C*c;}; int f(struct P*p){return p->c->v;}
