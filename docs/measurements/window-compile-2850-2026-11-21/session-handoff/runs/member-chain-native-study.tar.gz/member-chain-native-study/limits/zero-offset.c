struct I{int v;}; struct A{struct I *i;}; struct B{struct A *a;}; int f(struct B*b){return b->a->i->v;}
