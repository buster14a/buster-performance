struct C0{char padding;int leaf;};struct C1{char padding;struct C0 *p;};int f(struct C1*r){return r->p->leaf;}
