#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; cd ../postorder-value-init
exec 9>"$d/build.lock"
flock 9
test ! -x "$d/compiler" || exit 0
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/
ln -sf ../postorder-value-init/build/compiler "$d/compiler"
