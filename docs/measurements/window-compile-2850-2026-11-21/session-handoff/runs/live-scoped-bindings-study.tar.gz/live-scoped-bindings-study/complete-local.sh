#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 frontiers.py >frontiers.log 2>&1
python3 ../live-prefix-bindings-study/pulsed-binding.py >../live-prefix-bindings-study/binding-pulsed.log 2>&1
python3 pulsed-binding.py >binding-pulsed.log 2>&1
python3 directed.py >directed.log 2>&1
python3 compare.py >compare.log 2>&1
