from pathlib import Path
s=Path(__file__).resolve().parent;t=s.parent/'live-scoped-bindings/src/buster/compiler'
def sub(file,old,new):
 p=t/file;x=p.read_text();assert x.count(old)==1,(file,old)
 p.write_text(x.replace(old,new))
p=t/'c_bindings.c';x=p.read_text()
i=x.index('static inline __attribute__((always_inline)) uint32_t c_bindings_append(')
j=x.index('\n{',i)
sig=x[i:j]
x=x[:i]+x[i:].replace(sig,sig.replace('c_bindings_append(', 'c_bindings_append_target(')[:-1]+', bool supplied, uint32_t target)',1)
x=x.replace('const uint32_t previous = bindings->heads[key];','const uint32_t previous = supplied ? target : bindings->heads[key];',1)
marker='static uint32_t c_bindings_declare('
x=x.replace(marker,sig+'\n{\n    return c_bindings_append_target(bindings, space, name, token, point, depth, operation, kind, false, 0);\n}\n\n'+marker,1)
p.write_text(x)
sub('c_check_input.c','    uint32_t token, declaration, final_event;','    uint32_t token, declaration, final_event, prefix_event, name, handle;')
sub('c_check_input.c','typedef struct CheckLiveBindings\n{','''// Source declarations and scope restores are the only events that change the lexical name
// stacks. Their original ordinal, normalized namespace/name, source point, token and kind
// certify a previous handle by induction across the prefix. Identifier uses do not change heads.
typedef struct CheckLiveScopeRow
{
    uint32_t event, token, point, name, depth;
    uint8_t operation, kind, space;
} CheckLiveScopeRow;

typedef struct CheckLiveBindings
{''')
sub('c_check_input.c','    uint32_t captured, last_token, source_takes, answer_takes, blocks;','''    uint32_t captured, last_token, source_takes, answer_takes, blocks;
    CheckLiveScopeRow* scope;
    uint32_t scope_count, action_cursor, event_cursor;
    bool scope_failed;''')
sub('c_check_input.c','''    state->last->rows[state->last->count++] = (CheckLiveUseRow){ token, declaration, BUSTER_CHECK_NONE };''','''    state->last->rows[state->last->count++] = (CheckLiveUseRow){
        .token = token, .declaration = declaration, .final_event = BUSTER_CHECK_NONE, .prefix_event = event,
        .name = bindings->key[event], .handle = handle };''')
marker='// Reuse the pre-EOF classification in the final walk.'
sub('c_check_input.c',marker,'''static void check_live_keep_scope(CheckInputReader* reader)
{
    CheckLiveBindings* state = reader->live_bindings;
    const CBindings* events = &reader->bindings;
    uint32_t count = 0;
    for (uint32_t e = 0; e < events->count; e += 1) count += events->operation[e] != C_BINDING_USE;
    state->scope = BUSTER_ARENA_PUSH_ARRAY(state->storage, CheckLiveScopeRow, count);
    if (state->scope == NULL) { state->failed = true; return; }
    for (uint32_t e = 0; e < events->count; e += 1)
    {
        if (events->operation[e] == C_BINDING_USE) continue;
        state->scope[state->scope_count++] = (CheckLiveScopeRow){ .event = e, .token = events->declaration[e],
            .point = events->point[e], .name = events->key[e] % events->name_capacity, .depth = events->depth[e],
            .operation = events->operation[e], .kind = events->kind[e], .space = (uint8_t)(events->key[e] / events->name_capacity) };
    }
    if (state->scope_count != 0 && getenv("BUSTER_PRE_EOF_SCOPE_MISMATCH") != NULL)
        state->scope[0].token ^= 1u;
}

static bool check_live_scope_matches(CheckInputReader* reader)
{
    const CBindings* events = &reader->bindings;
    CheckLiveBindings* state = reader->live_bindings;
    while (!state->scope_failed && state->event_cursor < events->count)
    {
        const uint32_t e = state->event_cursor++;
        if (events->operation[e] == C_BINDING_USE) continue;
        if (state->action_cursor == state->scope_count)
        {
            state->scope_failed = true;
            break;
        }
        const CheckLiveScopeRow* row = &state->scope[state->action_cursor++];
        const uint32_t key = (uint32_t)row->space * events->name_capacity + row->name;
        state->scope_failed = e != row->event || events->operation[e] != row->operation ||
            events->key[e] != key || events->declaration[e] != row->token || events->point[e] != row->point ||
            events->depth[e] != row->depth || events->kind[e] != row->kind;
    }
    // An expected activation replaced by an ordinary use has no action in the final stream.
    if (state->action_cursor < state->scope_count && state->scope[state->action_cursor].event < events->count)
        state->scope_failed = true;
    return !state->scope_failed;
}

'''+marker)
sub('c_check_input.c','''    const uint32_t handle = c_bindings_lookup(bindings, C_BINDING_ORDINARY, identifier);
    if (handle == 0 || handle > bindings->count || bindings->kind[handle - 1] != C_BINDING_OBJECT ||''','''    if (row->name != identifier || row->prefix_event != bindings->count || !check_live_scope_matches(reader)) return false;
    const uint32_t handle = row->handle;
    if (handle == 0 || handle > bindings->count || bindings->kind[handle - 1] != C_BINDING_OBJECT ||''')
sub('c_check_input.c','''    const uint32_t event = c_bindings_use(bindings, C_BINDING_ORDINARY, identifier, token, token);''','''    const uint32_t event = c_bindings_append_target(bindings, C_BINDING_ORDINARY, identifier, token, token, 0,
                                                     C_BINDING_USE, C_BINDING_OBJECT, true, handle);''')
sub('c_check_input.c','''            check_input_bindings(&reader, binding_mode);
            if (reader.live_bindings''','''            if (reader.live_bindings != NULL && reader.live_bindings->capture) check_live_keep_scope(&reader);
            check_input_bindings(&reader, binding_mode);
            if (reader.live_bindings''')
sub('c_check_input.c','''                fprintf(stderr, "pre-eof-bindings-consumed''','''                fprintf(stderr, "pre-eof-scope-consumed\\tevents=%u\\tactions=%u\\tdiverged=%u\\tlookup-free=%u\\n",
                        reader.live_bindings->event_cursor, reader.live_bindings->action_cursor, reader.live_bindings->scope_failed,
                        reader.live_bindings->source_takes);
                fprintf(stderr, "pre-eof-bindings-consumed''')
sub('c_checker_driver.c','''(size_t)bindings->blocks * sizeof(CheckLiveUseBlock));''','''(size_t)bindings->blocks * sizeof(CheckLiveUseBlock) + (size_t)bindings->scope_count * sizeof(CheckLiveScopeRow));''')
