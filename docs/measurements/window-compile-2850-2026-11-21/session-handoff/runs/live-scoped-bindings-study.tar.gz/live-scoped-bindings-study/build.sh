#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
d="$PWD"
cd ../live-scoped-bindings
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/predefines.h
cd "$d"
python3 capture.py >capture.log 2>&1 || capture_status=$?
bash ../live-pragma-parity-study/verify.sh >../live-pragma-parity-study/scoped-verify.log 2>&1
if ((${capture_status:-0} != 0)); then exit "$capture_status"; fi
python3 frontiers.py >frontiers.log 2>&1
python3 ../live-prefix-bindings-study/pulsed-binding.py >../live-prefix-bindings-study/binding-pulsed.log 2>&1
python3 pulsed-binding.py >binding-pulsed.log 2>&1
python3 directed.py >directed.log 2>&1
python3 compare.py >compare.log 2>&1
