#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; mkdir -p "$d/hardware"
cluster='cd ~/buster-fast-bench/2850-codex-step2'
for group in sqlite main; do
 until ssh benchpress "$cluster && test -s results/ordinary-pair-sizeofmaskb09-$group/order.tsv && test \"\$(wc -l < results/ordinary-pair-sizeofmaskb09-$group/order.tsv)\" = 25"; do sleep 20; done
 ssh benchpress "$cluster && tar cf - results/sizeofmaskb09/{revision.txt,compiler.sha256,build.log,build-clock.log} results/sizeofspan7f/{revision.txt,compiler.sha256} results/ordinary-pair-sizeofmaskb09-$group sizeofmaskb09-job.log" | tar xf - -C "$d/hardware"
 python3 "$d/paired-b09.py" "$d/hardware" "$group" >"$d/hardware/$group-verified.txt"
done
