#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;src=$d/../sizeof-mask-exact
cd "$src"
export CORES_TITLE='2850 build signed sparse sizeof operator source, including 2,339-token Clang regression'
export CORES_LINK=https://github.com/buster14a/buster/issues/2850
cores -n 1 -- ./build.sh --config Develop --jobs 1 >"$d/exact-build.log" 2>&1
sha256sum build/compiler >"$d/exact.compiler"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
cores -n 1 -- ./build/compiler test-checker --attested --seed 2850 >"$d/exact-attested.log" 2>&1
cores -n 1 -- ./build/compiler test-checker --seed 2850 >"$d/exact-checker.log" 2>&1
cores -n 1 -- ./build/compiler test-checker-driver --executable ./build/compiler >"$d/exact-checker-driver.log" 2>&1
