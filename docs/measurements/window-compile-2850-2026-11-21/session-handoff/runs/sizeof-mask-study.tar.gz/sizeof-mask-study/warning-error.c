#pragma clang diagnostic error "-Wsizeof-array-decay"
int a[3];
int f(void) { return sizeof(a + 1); }
