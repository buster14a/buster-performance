#define _POSIX_C_SOURCE 200809L
#include <immintrin.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define BUSTER_CHECK_NONE UINT32_MAX
typedef struct {struct {const uint8_t *roles;} tree; struct {const uint8_t *kinds;} tokens;} Parser;
typedef struct {uint32_t first, end;} Span;
enum {PARSE_ROLE_NONE, PARSE_ROLE_ERROR, PARSE_ROLE_OPERAND, PARSE_ROLE_MEMBER, PARSE_ROLE_STRING_NEXT, PARSE_ROLE_QUALIFIER_LEFT, PARSE_ROLE_LEAF_RIGHT, PARSE_ROLE_SPECIFIER, PARSE_ROLE_TAG, PARSE_ROLE_PREFIX, PARSE_ROLE_POSTFIX, PARSE_ROLE_MEMBER_OPERATOR, PARSE_ROLE_MULTIPLICATIVE, PARSE_ROLE_ADDITIVE, PARSE_ROLE_SHIFT, PARSE_ROLE_RELATIONAL, PARSE_ROLE_EQUALITY, PARSE_ROLE_BITWISE_AND, PARSE_ROLE_BITWISE_XOR, PARSE_ROLE_BITWISE_OR, PARSE_ROLE_LOGICAL_AND, PARSE_ROLE_LOGICAL_OR, PARSE_ROLE_ASSIGN, PARSE_ROLE_RANGE, PARSE_ROLE_BITFIELD, PARSE_ROLE_COMMA, PARSE_ROLE_RETURN, PARSE_ROLE_ASSOCIATION, PARSE_ROLE_SEPARATOR, PARSE_ROLE_ASM_COLON, PARSE_ROLE_TERMINATOR, PARSE_ROLE_ELSE, PARSE_ROLE_DO, PARSE_ROLE_LABEL, PARSE_ROLE_OPEN_GROUP, PARSE_ROLE_OPEN_CALL, PARSE_ROLE_OPEN_FUNCTION, PARSE_ROLE_OPEN_CAST, PARSE_ROLE_OPEN_COMPOUND, PARSE_ROLE_OPEN_SIZEOF, PARSE_ROLE_OPEN_SPECIFIER, PARSE_ROLE_OPEN_ATTRIBUTE, PARSE_ROLE_OPEN_ATTRIBUTE_SPECIFIER, PARSE_ROLE_OPEN_ATTRIBUTE_LEFT, PARSE_ROLE_OPEN_ATTRIBUTE_RIGHT, PARSE_ROLE_OPEN_ATTRIBUTE_LIST, PARSE_ROLE_OPEN_ASM, PARSE_ROLE_OPEN_KEYWORD, PARSE_ROLE_OPEN_CONDITION, PARSE_ROLE_OPEN_FOR, PARSE_ROLE_OPEN_SUBSCRIPT, PARSE_ROLE_OPEN_BLOCK, PARSE_ROLE_OPEN_BODY, PARSE_ROLE_OPEN_STRUCT, PARSE_ROLE_OPEN_ENUM, PARSE_ROLE_OPEN_INITIALIZER, PARSE_ROLE_OPEN_COMPOUND_BODY, PARSE_ROLE_OPEN_TERNARY, PARSE_ROLE_OPEN_CASE, PARSE_ROLE_CLOSE_GROUP, PARSE_ROLE_CLOSE_CALL, PARSE_ROLE_CLOSE_FUNCTION, PARSE_ROLE_CLOSE_CAST, PARSE_ROLE_CLOSE_COMPOUND, PARSE_ROLE_CLOSE_SIZEOF, PARSE_ROLE_CLOSE_SPECIFIER, PARSE_ROLE_CLOSE_ATTRIBUTE, PARSE_ROLE_CLOSE_ATTRIBUTE_SPECIFIER, PARSE_ROLE_CLOSE_ATTRIBUTE_LEFT, PARSE_ROLE_CLOSE_ATTRIBUTE_RIGHT, PARSE_ROLE_CLOSE_ATTRIBUTE_LIST, PARSE_ROLE_CLOSE_ASM, PARSE_ROLE_CLOSE_KEYWORD, PARSE_ROLE_CLOSE_CONDITION, PARSE_ROLE_CLOSE_FOR, PARSE_ROLE_CLOSE_SUBSCRIPT, PARSE_ROLE_CLOSE_BLOCK, PARSE_ROLE_CLOSE_BODY, PARSE_ROLE_CLOSE_STRUCT, PARSE_ROLE_CLOSE_ENUM, PARSE_ROLE_CLOSE_INITIALIZER, PARSE_ROLE_CLOSE_COMPOUND_BODY, PARSE_ROLE_CLOSE_TERNARY, PARSE_ROLE_CLOSE_CASE};
#define BUSTER_CHECK_SCAN_ITEMS 64u

// A pass's walk over the items its own test needs first (check_common_next_token, check_common_next_op and
// check_common_next_reach): a group of them at a time, each a bit of the group's mask until visited. Zeroed, it starts at 0.
typedef struct CheckCommonScan CheckCommonScan;
struct CheckCommonScan
{
    // The group's first item, and the next group's.
    uint32_t base;
    uint32_t next;
    // The group's items still to visit, a bit each.
    uint64_t pending;
    // The listed scans' (check_common_next_op's, _reach_op's, _root's and _token's): their groups' items, listed in order
    // (`listed` of them, room for a group past BUSTER_CHECK_SCAN_ITEMS), of which `taken` were visited. Each scan reads a
    // column no pass writes while it runs, the graph's operators, the parents or the tokens' roles and kinds, so it lists
    // items ahead of the pass.
    uint32_t taken;
    uint32_t listed;
    uint32_t items[BUSTER_CHECK_SCAN_ITEMS + 64];
};

// The listed scan's next item, or `count` where its groups are done.
static uint32_t check_common_scan_listed(CheckCommonScan* scan, uint32_t count)
{
    const bool left = scan->taken < scan->listed;
    const uint32_t result = left ? scan->items[scan->taken] : count;
    scan->taken += left;
    return result;
}

// Appends the items of `selected` from `first` (16 lanes) to the scan's list.
// Clang's MemorySanitizer expands the compress store with a temporary stack allocation.
// Release that allocation when the store returns, even during long runs with no matches.
#if __has_feature(memory_sanitizer)
__attribute__((noinline))
#endif
static void check_common_scan_list(CheckCommonScan* scan, uint32_t first, __mmask16 selected)
{
    const __m512i items = _mm512_add_epi32(_mm512_set1_epi32((int32_t)first), _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15));
    _mm512_storeu_si512(scan->items + scan->listed, _mm512_maskz_compress_epi32(selected, items));
    scan->listed += (uint32_t)__builtin_popcount(selected);
}

// The scan's group's lowest pending item, which it then takes off, or `count` where the groups are done.
static uint32_t check_common_scan_take(CheckCommonScan* scan, uint32_t count)
{
    const uint32_t result = scan->pending != 0 ? scan->base + (uint32_t)__builtin_ctzll(scan->pending) : count;
    scan->pending &= scan->pending - 1;
    return result;
}

// The scan's next token below `count` whose role is one of the `role_count` `roles` and, unless `kind` is BUSTER_CHECK_NONE,
// whose kind is `kind`, or `count`: what a token pass's own test needs first. It tests 64 tokens at a time and takes the
// tokens from the scan's list.
static uint32_t check_common_next_token(const Parser* parser, uint32_t count, uint32_t kind, const uint8_t* roles, uint32_t role_count,
                                        CheckCommonScan* scan)
{
    // Groups listed until BUSTER_CHECK_SCAN_ITEMS tokens or the end, once the list is taken (#892): a group at a time, the
    // test of whether the group's tokens were all visited was missed at most groups on the 9700X.
    if (scan->taken == scan->listed)
    {
        scan->taken = 0;
        scan->listed = 0;
        while (scan->listed < BUSTER_CHECK_SCAN_ITEMS && scan->next < count)
        {
            const uint32_t first = scan->next;
            const uint32_t live = count - first < 64 ? count - first : 64;
            const uint64_t lanes = live == 64 ? UINT64_MAX : (UINT64_C(1) << live) - 1;
            const __m512i role_bytes = _mm512_maskz_loadu_epi8((__mmask64)lanes, parser->tree.roles + first);
            uint64_t selected = 0;
            for (uint32_t r = 0; r < role_count; r += 1)
            {
                selected |= _mm512_mask_cmpeq_epi8_mask((__mmask64)lanes, role_bytes, _mm512_set1_epi8((char)roles[r]));
            }
            if (kind != BUSTER_CHECK_NONE)
            {
                const __m512i kind_bytes = _mm512_maskz_loadu_epi8((__mmask64)lanes, parser->tokens.kinds + first);
                selected &= _mm512_mask_cmpeq_epi8_mask((__mmask64)lanes, kind_bytes, _mm512_set1_epi8((char)kind));
            }
            scan->next = first + live;
            for (uint32_t part = 0; part < 64; part += 16)
            {
                check_common_scan_list(scan, first + part, (__mmask16)(selected >> part));
            }
        }
    }
    const uint32_t result = check_common_scan_listed(scan, count);
    return result;
}

static __attribute__((noinline)) uint64_t previous(const Parser *parser, const Span *spans, size_t count){
  uint64_t sum=0;
  static const uint8_t roles[]={PARSE_ROLE_ADDITIVE,PARSE_ROLE_ASSIGN,PARSE_ROLE_COMMA,PARSE_ROLE_SEPARATOR};
  for(size_t i=0;i<count;i++) {
    const uint32_t end=spans[i].end;
    CheckCommonScan scan={.next=spans[i].first};
    for(uint32_t token=check_common_next_token(parser,end,BUSTER_CHECK_NONE,roles,4,&scan);token<end;token=check_common_next_token(parser,end,BUSTER_CHECK_NONE,roles,4,&scan))sum+=token+1;
  }
  return sum;
}
static uint64_t check_input_scan_all(uint32_t first,uint32_t count){return _bzhi_u64(UINT64_MAX,count-first<64?count-first:64);}
static __attribute__((noinline)) uint64_t next(const Parser *parser,const Span *spans,size_t count){
    uint64_t sum=0;
    for(size_t i=0;i<count;i++){
        uint32_t first=spans[i].first,end=spans[i].end;
    for (uint32_t line = first; line < end;)
    {
        const uint32_t live = end - line < 64 ? end - line : 64;
        const __mmask64 lanes = check_input_scan_all(line, end);
        const __m512i roles = _mm512_maskz_loadu_epi8(lanes, parser->tree.roles + line);
        uint64_t operators = _mm512_cmpeq_epi8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_ADDITIVE)) |
                             _mm512_cmpeq_epi8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_ASSIGN)) |
                             _mm512_cmpeq_epi8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_COMMA)) |
                             _mm512_cmpeq_epi8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_SEPARATOR));
        for (; operators != 0; operators &= operators - 1)
        {
            const uint32_t token = line + (uint32_t)__builtin_ctzll(operators);
            sum+=token+1;
        }
        line += live;
    }
    }
    return sum;
}
static uint64_t tick(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000000000ull+t.tv_nsec;}
static void *load(const char *path,size_t *len){FILE *f=fopen(path,"rb");if(!f)abort();fseek(f,0,SEEK_END);long s=ftell(f);rewind(f);void *p=malloc(s);if(!p||fread(p,1,s,f)!=(size_t)s)abort();fclose(f);*len=s;return p;}
int main(int argc,char **argv){
  if(argc!=3)return 1;size_t bytes,room;uint8_t *roles=load(argv[1],&bytes);Span *spans=load(argv[2],&room);size_t n=room/sizeof(*spans);
  Parser p={.tree.roles=roles};uint64_t oracle=previous(&p,spans,n);if(oracle!=next(&p,spans,n))return 2;
  printf("round\tarm\tns-per-full-source-range-set\tpositions-checksum\n");
  for(unsigned round=1;round<=7;round++)for(unsigned pos=0;pos<4;pos++){unsigned arm=(round+((pos==1)||(pos==2)))%2;uint64_t start=tick(),out=0;
    for(unsigned r=0;r<128;r++){__asm__ volatile("":::"memory");out+=arm?next(&p,spans,n):previous(&p,spans,n);}
    uint64_t end=tick();if(out!=128*oracle)return 3;printf("%u\t%u\t%.3f\t%llu\n",round,arm,(end-start)/128.,(unsigned long long)oracle);
  }
  return 0;
}
