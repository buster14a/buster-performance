from pathlib import Path
import csv,hashlib,shutil,subprocess,tarfile
d=Path(__file__).resolve().parent;w=d.parent;pub=w/'sizeof-spans-evidence/docs/measurements/sizeof-array-decay-spans-2850-2026-11-22/sparse'
def rows(p):return list(csv.DictReader(p.open(),delimiter='\t'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent='7f31573fd00a095e9e19de1a583c7ae7c94a2037'
base='40ae34f9d77afc42face58eff3338b7b1d1ba469'
tip='b09b34dbd8f7ff96ecac6cc893563902b8739172'
assert subprocess.check_output(['git','-C',w/'sizeof-mask-exact','rev-parse','HEAD'],text=True).strip()==tip
patch=d/'host/sizeofmaskb09.patch'
assert subprocess.check_output(['git','-C',w/'sizeof-mask-exact','diff','--binary',base,tip])==patch.read_bytes()
assert sha(patch) in (d/'hardware/results/sizeofmaskb09/revision.txt').read_text()
qa=w/'sizeof-mask-b09-diagnostics/diagnostics.tsv';r=rows(qa)
assert len(r)==616 and all(z['candidate=baseline-all']=='1' for z in r)
assert len(rows(d/'view-controls-sizeof-mask-exact/results.tsv'))==18
assert len(rows(d/'runtime.tsv'))==3 and all(z['run-exit']=='0' for z in rows(d/'runtime.tsv'))
for name in ['exact-attested.log','exact-checker.log','exact-checker-driver.log']:
 assert 'checks, 0 failures' in (d/name).read_text()
for g,n in {'sqlite':3,'main':3,'lua':102,'musl':4008}.items():
 r=rows(d/'corpus'/(g+'.tsv'));assert len(r)==n and all(z['same']=='1' and z['code']=='0' for z in r)
assert (d/'hardware/sqlite-verified.txt').is_file() and (d/'hardware/main-verified.txt').is_file()
pub.mkdir(exist_ok=True,parents=True)
for name in ['source-regions.tsv','kernel-summary.tsv','ranges.tsv','runtime.tsv','typed.tsv','dco.tsv','local-records.tsv']:shutil.copy(d/name,pub/name)
for name,source in [('implementation.patch',patch),('diagnostics.tsv',qa),('fallback-views.tsv',d/'view-controls-sizeof-mask-exact/results.tsv')]:shutil.copy(source,pub/name)
for g in ['sqlite','main']:
 for typ in ['summary','samples','paired']:shutil.copy(d/'hardware'/(g+'-'+typ+'.tsv'),pub/(g+'-'+typ+'.tsv'))
with tarfile.open(pub/'native-records.tar.xz','w:xz') as t:
 t.add(d/'hardware',arcname='hardware')
 for p in [d/'host/sizeofmaskb09.sh',d/'host/sizeofmaskb09-one.sh',d/'host/sizeofmaskb09-job.sh',d/'paired-b09.py',d/'collect-b09.sh']:t.add(p,arcname='scripts/'+p.name)
with tarfile.open(pub/'source-records.tar.xz','w:xz') as t:
 for n in ['source-observations','corpus','source-regions.py','runtime.c','runtime.py','runtime.tsv','exact-corpus.sh','live-fallback.py','long-mask.c','nested.c','warning-error.c','long.tokens','long.clang','ranges.c','make-oracle.sh','make-kernel.py','mask-loop.c.inc','run.sh','main.tsv','sqlite.tsv','exact.compiler','exact-attested.log','exact-checker.log','exact-checker-driver.log','exact-pairs','local-pairs.py']:
  t.add(d/n,arcname=n)
 for pat in ['*.gdb','*.stderr','results.tsv']:
  for p in sorted((d/'view-controls-sizeof-mask-exact').glob(pat)):t.add(p,arcname='fallback/'+p.name)
 t.add(w/'sizeof-mask-b09-diagnostics/diagnostics.py',arcname='diagnostics.py')
 for p in sorted((w/'sizeof-mask-b09-diagnostics/diagnostics').glob('*.stderr')):t.add(p,arcname='clang-comparisons/'+p.name)
text=['# Retaining only possible sizeof warning operators','',f'Native Release control `{parent}` retained every parenthesized sizeof operand range. Revision `{tip}` retains a range only after its first additive, assignment, comma or separator token. The reader visits the newly covered part of overlapping intervals once. Warning generation consumes these in source order. [Source diff](implementation.patch) · [Source records and reproducer](source-records.tar.xz)','', 'Independent 9700X comparisons used separate, full native Release builds, CPU 2, one compiler per machine lock, and three alternating four-process rounds per source and measurement class. Each round’s elapsed time was read by a one-child wall clock in a different invocation from the hardware counters. All default and warning-policy objects and diagnostics matched. [Raw hardware and wrapper records](native-records.tar.xz)','', '| Source | Span control ms | Sparse ms | Median paired elapsed ms | Faster rounds | Median paired user instructions | Median paired total cycles |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for g in ['sqlite','main']:
 z={r['metric']:r for r in rows(pub/(g+'-summary.tsv'))};r=z['wall-ms'];text.append(f"| [{g}]({g}-summary.tsv) | {float(r['baseline-median']):.3f} | {float(r['candidate-median']):.3f} | {float(r['paired-median']):+.3f} | {r['faster-rounds']}/{r['rounds']} | {float(z['user-instructions']['paired-median']):+,.0f} | {float(z['total-cycles']['paired-median']):+,.0f} |")
text+=['','The exact sparse compiler kept zero of 975 prior ranges on SQLite. On local Buster it kept three of 32,024 prior ranges, spanning 31 source tokens for the three possible operators. The complete typed dumps and objects matched ordinary main. All 616 diagnostic/policy/action cases matched ordinary Buster and 600 also matched Clang exactly. All 4,116 frozen source/policy combinations emitted identical ELF and diagnostic bytes. All 18 combinations of source, parser-view representation and requested output matched. Executables built by Buster and Clang returned zero for nested unevaluated side effects and long-operand pointer sizing. The permanent long fixture places its only candidate operator 2,339 lexed tokens after the keyword. [Source ranges](source-regions.tsv) · [Typed dumps](typed.tsv) · [Live fallbacks](fallback-views.tsv) · [Runtime](runtime.tsv)','', 'The isolated equivalent scanning loop changed its median paired time by −7.29 μs on SQLite and −206.26 μs on Buster on the local Ryzen 9 7940HS. The whole-compiler measurements above include parsing, checking and native object emission. [Kernel controls](kernel-summary.tsv)','']
(pub/'README.md').write_text('\n'.join(text))
