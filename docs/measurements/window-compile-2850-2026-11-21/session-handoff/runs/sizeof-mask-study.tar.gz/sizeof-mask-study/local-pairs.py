from pathlib import Path
import hashlib, os, subprocess, tempfile
d=Path(__file__).resolve().parent;w=d.parent
params="""cd "$1/switch-inputs"; source ../switch-local-args.sh; tree="$1/pregraph-warning-study/compiler-source"; main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $1/proof-predefines.h $tree/src/buster/compiler/main.c"; var=${2}_arguments; eval "args=(${!var})"; printf '%s\\0' "${args[@]}" """
env={**os.environ,'CORES_TITLE':'2850 marginal frozen whole compiler counters for sparse sizeof operator filtering','CORES_LINK':'https://github.com/buster14a/buster/issues/2850'}
with tempfile.TemporaryDirectory(dir=d) as td:
    obj=Path(td)/'unit.o'
    for group in ['sqlite','main']:
        args=subprocess.check_output(['bash','-c',params,'_',str(w),group]).decode().strip('\0').split('\0')
        oracle=None
        for rd in [1,2,3]:
            labels=['sizeof-expression-spans','sizeof-mask-exact']
            if rd%2==0:labels.reverse()
            for label in labels:
                stem=d/'exact-pairs'/f'local-{group}-{rd}-{label}'; p=str(stem)
                with open(p+'.stderr','wb') as se,open(p+'.stdout','wb') as so:
                    subprocess.run(['cores','-n','1','--','perf','stat','--no-big-num','-x,','-o',p+'.perf','-e','cycles:u,instructions:u,minor-faults','--',w/label/'build/compiler','--lanes','1','-c',*args,'-o',obj],env=env,stdout=so,stderr=se,check=True,timeout=3600)
                h=hashlib.sha256(obj.read_bytes()).hexdigest()
                if oracle is None:oracle=h
                assert oracle==h
                Path(str(stem)+'.object').write_text(h+'\n')
