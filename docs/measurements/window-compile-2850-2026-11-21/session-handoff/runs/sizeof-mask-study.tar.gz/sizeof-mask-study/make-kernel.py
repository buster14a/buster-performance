from pathlib import Path
import re
d=Path(__file__).resolve().parent;w=d.parent
s=(w/'sizeof-expression-spans/src/buster/compiler/c_check_common_warnings.c').read_text()
cur=(w/'sizeof-operator-mask/src/buster/compiler/c_check_common_warnings.c').read_text()
ps=(w/'sizeof-expression-spans/src/buster/compiler/c_parser.c').read_text().split('#define BUSTER_PARSE_ROLES(X)',1)[1].split('typedef enum ParseRole',1)[0]
enum=', '.join('PARSE_ROLE_'+n for n in re.findall(r'^    X\((\w+),',ps,re.M))
gen='''#define _POSIX_C_SOURCE 200809L
#include <immintrin.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define BUSTER_CHECK_NONE UINT32_MAX
typedef struct {struct {const uint8_t *roles;} tree; struct {const uint8_t *kinds;} tokens;} Parser;
typedef struct {uint32_t first, end;} Span;
enum {'''+enum+'''};
'''
gen+=s[s.index('#define BUSTER_CHECK_SCAN_ITEMS'):s.index('// A set of graph operators')]
gen+='''static __attribute__((noinline)) uint64_t previous(const Parser *parser, const Span *spans, size_t count){
  uint64_t sum=0;
  static const uint8_t roles[]={PARSE_ROLE_ADDITIVE,PARSE_ROLE_ASSIGN,PARSE_ROLE_COMMA,PARSE_ROLE_SEPARATOR};
  for(size_t i=0;i<count;i++) {
    const uint32_t end=spans[i].end;
    CheckCommonScan scan={.next=spans[i].first};
    for(uint32_t token=check_common_next_token(parser,end,BUSTER_CHECK_NONE,roles,4,&scan);token<end;token=check_common_next_token(parser,end,BUSTER_CHECK_NONE,roles,4,&scan))sum+=token+1;
  }
  return sum;
}
static uint64_t check_input_scan_all(uint32_t first,uint32_t count){return _bzhi_u64(UINT64_MAX,count-first<64?count-first:64);}
static __attribute__((noinline)) uint64_t next(const Parser *parser,const Span *spans,size_t count){
    uint64_t sum=0;
    for(size_t i=0;i<count;i++){
        uint32_t first=spans[i].first,end=spans[i].end;
'''
x=(d/'mask-loop.c.inc').read_text()
gen+=x.replace('check_common_sizeof_decay_operator(parser, pp, input, stream, types, spell, scratch, token);','sum+=token+1;')+'''
    }
    return sum;
}
static uint64_t tick(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000000000ull+t.tv_nsec;}
static void *load(const char *path,size_t *len){FILE *f=fopen(path,"rb");if(!f)abort();fseek(f,0,SEEK_END);long s=ftell(f);rewind(f);void *p=malloc(s);if(!p||fread(p,1,s,f)!=(size_t)s)abort();fclose(f);*len=s;return p;}
int main(int argc,char **argv){
  if(argc!=3)return 1;size_t bytes,room;uint8_t *roles=load(argv[1],&bytes);Span *spans=load(argv[2],&room);size_t n=room/sizeof(*spans);
  Parser p={.tree.roles=roles};uint64_t oracle=previous(&p,spans,n);if(oracle!=next(&p,spans,n))return 2;
  printf("round\\tarm\\tns-per-full-source-range-set\\tpositions-checksum\\n");
  for(unsigned round=1;round<=7;round++)for(unsigned pos=0;pos<4;pos++){unsigned arm=(round+((pos==1)||(pos==2)))%2;uint64_t start=tick(),out=0;
    for(unsigned r=0;r<128;r++){__asm__ volatile("":::"memory");out+=arm?next(&p,spans,n):previous(&p,spans,n);}
    uint64_t end=tick();if(out!=128*oracle)return 3;printf("%u\\t%u\\t%.3f\\t%llu\\n",round,arm,(end-start)/128.,(unsigned long long)oracle);
  }
  return 0;
}
'''
(d/'kernel.c').write_text(gen)
