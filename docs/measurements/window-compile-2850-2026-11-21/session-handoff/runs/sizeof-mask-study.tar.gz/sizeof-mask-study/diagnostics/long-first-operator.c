#define OR8(x) ((x)|(x)|(x)|(x)|(x)|(x)|(x)|(x))
int a[6];
unsigned long f(int n) { return sizeof(OR8(OR8(OR8(n))) + a); }

