from pathlib import Path
import csv,hashlib,subprocess
d=Path(__file__).resolve().parent;w=d.parent;target=d/'runtime';target.mkdir(exist_ok=True)
hosts={'parent':w/'default-integer-control/build/compiler','candidate':w/'sizeof-mask-exact/build/compiler','clang':Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')}
dig=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (d/'runtime.tsv').open('w') as f:
 writer=csv.writer(f,delimiter='\t',lineterminator='\n');writer.writerow(['compiler','object-sha256','diagnostics-sha256','run-exit'])
 for label,cc in hosts.items():
    obj=target/(label+'.o');exe=target/label;diag=target/(label+'.stderr')
    with diag.open('wb') as se:
        subprocess.run([cc,'-c','-std=gnu17','-fno-caret-diagnostics',d/'runtime.c','-o',obj],check=True,stderr=se)
    subprocess.run(['cc','-no-pie',obj,'-o',exe],check=True)
    run=subprocess.run([exe]);assert run.returncode==0
    writer.writerow([label,dig(obj),dig(diag),run.returncode])
 assert (target/'parent.o').read_bytes()==(target/'candidate.o').read_bytes()
 assert (target/'parent.stderr').read_bytes()==(target/'candidate.stderr').read_bytes()==(target/'clang.stderr').read_bytes()
