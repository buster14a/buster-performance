    for (uint32_t line = first; line < end;)
    {
        const uint32_t live = end - line < 64 ? end - line : 64;
        const __mmask64 lanes = check_input_scan_all(line, end);
        const __m512i roles = _mm512_maskz_loadu_epi8(lanes, parser->tree.roles + line);
        uint64_t operators = _mm512_cmpeq_epi8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_ADDITIVE)) |
                             _mm512_cmpeq_epi8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_ASSIGN)) |
                             _mm512_cmpeq_epi8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_COMMA)) |
                             _mm512_cmpeq_epi8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_SEPARATOR));
        for (; operators != 0; operators &= operators - 1)
        {
            const uint32_t token = line + (uint32_t)__builtin_ctzll(operators);
            check_common_sizeof_decay_operator(parser, pp, input, stream, types, spell, scratch, token);
        }
        line += live;
    }