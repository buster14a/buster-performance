from pathlib import Path
import csv,hashlib,json,re,shlex,subprocess,sys,tempfile
d=Path(__file__).resolve().parent;w=d.parent;ref=w/'sizeof-expression-spans'
src=w/sys.argv[1]; target=d/('view-controls-'+sys.argv[1]);target.mkdir(exist_ok=True)
c=next(x for x in json.loads((ref/'build/compile_commands.json').read_text()) if x['file'].endswith('main_unit_checker.c'))
args=shlex.split(c['command']);args=[a for a in args[:args.index('-Xclang')] if not a.startswith('-DCMAKE_INTDIR')]
layout=subprocess.check_output([*args,'-Xclang','-fdump-record-layouts','-fsyntax-only',c['file']],cwd=c['directory'],stderr=subprocess.PIPE,text=True)
def offset(struct,name):
    st=re.search(r'^\s*0 \| struct '+struct+r'\n(.*?)\[sizeof=',layout,re.S|re.M)[1]
    return int(re.search(r'^\s*(\d+) \|   \S[^\n]*?\b'+name+r'$',st,re.M)[1])
off={n:offset('CheckInput',n) for n in ['token_count','sizeof_span_parser']}
parents=offset('Parser','tree')+offset('ParseTree','parents');ends=offset('Parser','ends')
# The executable is a static ET_EXEC. Borrow an unused test-only BSS array in this disposable process.
symbols=subprocess.check_output(['nm','-S','-an',src/'build/compiler'],text=True)
slot=re.search(r'^([0-9a-f]+) ([0-9a-f]+) b emitted_test_rows\.functions$',symbols,re.M)
scratch_addr=int(slot[1],16);scratch_bytes=int(slot[2],16)
assert 'EXEC' in subprocess.check_output(['readelf','-h',src/'build/compiler'],text=True).split('Type:',1)[1].splitlines()[0]

digest=lambda b:hashlib.sha256(b).hexdigest()
with (target/'results.tsv').open('w') as out:
 writer=csv.writer(out,delimiter='\t',lineterminator='\n');writer.writerow(['source','mode','action','exit','diagnostics-sha256','object-sha256','process-views'])
 for fixture in ['nested.c','long-mask.c','warning-error.c']:
  for action in ['-c','-fsyntax-only']:
   with tempfile.TemporaryDirectory(dir=target) as td:
    t=Path(td);obj=t/'unit.o';opts=['-std=gnu17','-fno-caret-diagnostics',action,d/fixture];opts+=['-o',obj] if action=='-c' else []
    x=subprocess.run([w/'default-integer-control/build/compiler',*opts],capture_output=True)
    oldcode=x.returncode
    old=(x.stdout,x.stderr,obj.read_bytes() if obj.is_file() else b'')
    for mode in ['indexed','complete-parser','unindexed-parser']:
     obj.unlink(missing_ok=True)
     profile=t/('script-'+mode+'.gdb');views=t/('view-'+mode)
     code=f"""set pagination off
set debuginfod enabled off
set confirm off
python
import gdb,struct
def rd(a,n):
 return int.from_bytes(gdb.selected_inferior().read_memory(a,n),'little')
def wr(a,b):
 gdb.selected_inferior().write_memory(a,b)
class Worker(gdb.Breakpoint):
 def stop(self):
  parser=int(gdb.parse_and_eval('$rdi'));inp=int(gdb.parse_and_eval('$rdx'));n=rd(inp+{off['token_count']},4)
  if n==0:return False
  before=rd(parser+{ends},8)
  assert n*4<={scratch_bytes}
  if '{mode}'!='indexed':
   wr(inp+{off['sizeof_span_parser']},bytes(8));p=0
   if '{mode}'=='complete-parser':
    raw=rd(parser+{parents},8)
    parent=struct.unpack('<'+'I'*n,gdb.selected_inferior().read_memory(raw,n*4))
    # Maximum source index among every transitive descendant of each parser row.
    check=list(range(n))
    for i in range(n):
     v=parent[i]; seen={{i}}
     while v<n and v not in seen:
      seen.add(v);check[v]=max(check[v],i);v=parent[v]
    p={scratch_addr}
    wr(p,struct.pack('<'+'I'*n,*check))
   wr(parser+{ends},p.to_bytes(8,'little'))
  with open('{views}','a') as f:f.write(str(n)+' '+str(bool(before))+'\\n')
  return False
Worker("*'check_driver_common_warnings.buster_split'")
end
run {shlex.join(list(map(str,opts)))} >{t}/stdout 2>{t}/stderr
python
assert int(gdb.parse_and_eval('$_exitcode'))=={oldcode}
end
"""
     profile.write_text(code)
     x=subprocess.run(['gdb','-q','--batch','-x',profile,'--args',src/'build/compiler',*opts],capture_output=True,timeout=65)
     (target/(fixture+'-'+action+'-'+mode+'.gdb')).write_bytes(x.stdout+x.stderr)
     (target/(fixture+'-'+action+'-'+mode+'.stderr')).write_bytes((t/'stderr').read_bytes() if (t/'stderr').exists() else b'')
     assert x.returncode==0 and views.is_file() and b'Python Exception' not in x.stderr,(fixture,mode,x.stderr)
     new=((t/'stdout').read_bytes(),(t/'stderr').read_bytes(),obj.read_bytes() if obj.is_file() else b'')
     assert old==new,(fixture,mode,action,new[1],old[1])
     writer.writerow([fixture,mode,action,oldcode,digest(new[1]),digest(new[2]) if new[2] else '-',','.join(views.read_text().splitlines())]);out.flush()
