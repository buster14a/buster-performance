#!/bin/bash
set -eu
cd "$(dirname "$0")"
until [[ -s view-controls-sizeof-expression-spans/results.tsv && $(wc -l <view-controls-sizeof-expression-spans/results.tsv) == 19 ]]; do sleep 4; done
cores -n 1 --title '2850 verify sparse native sizeof warning fallback views and source recovery' --link https://github.com/buster14a/buster/issues/2850 -- python3 live-fallback.py sizeof-mask-exact >b09-fallback.log 2>&1
