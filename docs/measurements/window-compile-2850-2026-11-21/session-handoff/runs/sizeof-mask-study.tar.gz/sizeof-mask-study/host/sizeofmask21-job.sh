#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2
base=40ae34f9d77afc42face58eff3338b7b1d1ba469
label=sizeofmask21
./build-label.sh "$label" "$base" "$label.patch"
./lock.sh cc -O2 -std=c17 sizeofspan-wall.c -o "results/$label/one-process-clock" > "results/$label/build-clock.log" 2>&1
while [[ ! -s results/sizeofspan7f/.built ]]; do if grep -q 'build failed' sizeofspan7f-job.log; then exit 1; fi; sleep 15; done
bash "$label.sh" "$label" sqlite 1 3
echo SQLITE_COMPLETE
bash "$label.sh" "$label" main 1 3
echo ALL_COMPLETE
