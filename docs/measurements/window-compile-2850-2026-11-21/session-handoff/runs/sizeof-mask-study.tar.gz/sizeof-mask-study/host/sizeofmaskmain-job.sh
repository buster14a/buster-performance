#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2
label=sizeofmaskb09
test -s results/$label/.built && test -s results/main40ae/.built
bash sizeofmaskmain.sh "$label" sqlite 1 7
echo SQLITE_COMPLETE
for group in main lua musl; do bash sizeofmaskmain.sh "$label" "$group" 1 3; done
echo ALL_COMPLETE
