#!/bin/bash
set -eu
cd "$(dirname "$0")"
until [[ -s exact.compiler ]]; do sleep 6; done
cores -n 1 --title '2850 compare long and nested sizeof diagnostic policy, native ELF and actual execution with Clang' --link https://github.com/buster14a/buster/issues/2850 -- python3 runtime.py >runtime.log 2>&1
