#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; mkdir -p "$d/hardware"
cluster='cd ~/buster-fast-bench/2850-codex-step2'
for group in sqlite main; do
 until ssh benchpress "$cluster && test -s results/ordinary-pair-sizeofmask21-$group/order.tsv && test \"\$(wc -l < results/ordinary-pair-sizeofmask21-$group/order.tsv)\" = 25"; do sleep 20; done
 ssh benchpress "$cluster && tar cf - results/sizeofmask21/{revision.txt,compiler.sha256,build.log,build-clock.log} results/sizeofspan7f/{revision.txt,compiler.sha256} results/ordinary-pair-sizeofmask21-$group sizeofmask21-job.log" | tar xf - -C "$d/hardware"
 python3 "$d/paired.py" "$d/hardware" "$group" >"$d/hardware/$group-verified.txt"
done
