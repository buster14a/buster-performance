Breakpoint 1 at 0xfab970: file /home/david/Documents/Codex/2026-11-21/g/work/sizeof-mask-exact/src/buster/compiler/c_check_common_warnings.c, line 12996.
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/usr/lib/libthread_db.so.1".
[New Thread 0x9020a80 (LWP 246671) (id 2)]
[Inferior 1 (process 246657) exited with code 01]
