#!/bin/bash
set -eu
cd "$(dirname "$0")"; python3 make-kernel.py
/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang -O3 -march=native -std=gnu17 kernel.c -o kernel
for source in sqlite main; do
 p=../sizeof-expression-study/source-observations
 ./kernel "$p/$source-roles" "$p/$source-spans" >"$source.tsv"
done
