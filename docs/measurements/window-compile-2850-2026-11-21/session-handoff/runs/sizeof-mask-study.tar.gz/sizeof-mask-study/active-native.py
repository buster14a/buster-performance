from pathlib import Path
import csv,statistics,sys
p=Path(sys.argv[1]);facts=[]
x=list(csv.DictReader((p/'order.tsv').open(),delimiter='\t'))
for rd in sorted({int(r['round']) for r in x if r['series']=='pmu'}):
 rows=[r for r in x if r['series']=='pmu' and int(r['round'])==rd]
 if len(rows)!=4: continue
 arm={k:[] for k in ['candidate','baseline']}
 for r in rows:
  h=p/f"pmu-{rd}-{r['position']}.perf"
  rr={t[2]:float(t[0]) for t in csv.reader(h.open()) if len(t)>4 and float(t[4])==100}
  arm[r['mode']].append([rr['instructions:u'],rr['cycles:u'],rr['cycles:k']+rr['cycles:u'],rr['task-clock']])
 d=[statistics.mean(a)-statistics.mean(b) for a,b in zip(zip(*arm['candidate']),zip(*arm['baseline']))];facts.append(d)
print('pmu-rounds',len(facts), 'paired-median delta (user instructions, user cycles, total cycles, task-clock ms)',*[statistics.median(v) for v in zip(*facts)])
