#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; src=$d/../sizeof-operator-mask
until [[ -s "$src/build/predefines.h" && -x "$src/build/compiler" && -s "$d/ranges.tsv" && -s "$d/main.tsv" ]]; do sleep 3; done
python3 "$d/local-pairs.py"
