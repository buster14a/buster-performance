from pathlib import Path
import csv,hashlib
d=Path(__file__).resolve().parent
sections=[('generator','ranges.tsv'),('source interval census','source-regions.tsv'),('full typed output and objects','typed.tsv'),('paired range microkernel','kernel-summary.tsv'),('long and nested runtime','runtime.tsv'),('exact Clang / parent diagnostics','../sizeof-mask-b09-diagnostics/diagnostics.tsv'),('source-schema attestation','exact-attested.log'),('forced fallback on main candidate','view-controls-sizeof-expression-spans/results.tsv'),('forced sparse fallbacks','view-controls-sizeof-mask-exact/results.tsv')]
with (d/'local-records.tsv').open('w') as out:
 w=csv.writer(out,delimiter='\t',lineterminator='\n');w.writerow(['record','path','bytes','sha256'])
 for label,src in sections:
    p=d/src
    if p.is_file():w.writerow([label,src,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()])
