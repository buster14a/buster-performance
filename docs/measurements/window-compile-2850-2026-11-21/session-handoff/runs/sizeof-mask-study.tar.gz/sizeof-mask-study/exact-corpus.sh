#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; w=${d%/*}; src=$w/sizeof-mask-exact; baseline=$w/default-integer-control/build/compiler
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
export CORES_TITLE='2850 exact published sparse sizeof native objects and diagnostics across four full-source corpora'
export CORES_LINK=https://github.com/buster14a/buster/issues/2850
cd "$w/switch-inputs"
source ../switch-local-args.sh
tree=$w/pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $w/proof-predefines.h $tree/src/buster/compiler/main.c"
mkdir -p "$d/corpus"
for group in sqlite main lua musl; do
 v=${group}_arguments; eval "args=(${!v})"
 cores -n 1 -- python3 "$w/default-object-qa/pair.py" "$d/corpus" "$group" "$baseline" "$src/build/compiler" "${args[@]}" >"$d/$group.log" 2>&1
done
