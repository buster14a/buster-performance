// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Compile after the two production functions extracted by make-oracle.sh.
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <string.h>

#define LIMIT 1100u
static uint32_t seed = 2850;
static uint32_t random_number(void)
{
    seed = seed * 1664525u + 1013904223u;
    return seed;
}

int main(void)
{
    uint32_t parents[LIMIT], ends[LIMIT], order[LIMIT], names[LIMIT];
    uint8_t roles[LIMIT], kinds[LIMIT];
    CheckSizeofSpan retained[LIMIT];
    uint64_t queried = 0, candidates = 0, outside_closer = 0, overlaps = 0, masks = 0;
    for (uint32_t n = 3; n <= LIMIT; n += 1)
    {
        for (uint32_t round = 0; round < 4; round += 1)
        {
            for (uint32_t i = 0; i < n; i += 1)
            {
                order[i] = i;
                roles[i] = random_number() % 9;
                names[i] = (random_number() >> 17) % 2;
                kinds[i] = (random_number() >> 17) % 2;
                ends[i] = i;
            }
            for (uint32_t i = n; i > 1; i -= 1)
            {
                const uint32_t other = random_number() % i;
                const uint32_t temp = order[i - 1];
                order[i - 1] = order[other];
                order[other] = temp;
            }
            // Arbitrary forests, including crossing source intervals. A node's ancestors precede it in 'order'.
            for (uint32_t i = 0; i < n; i += 1)
            {
                parents[order[i]] = i && ((random_number() >> 19) % 9) ? order[random_number() % i] : UINT32_MAX;
            }
            for (uint32_t i = n; i-- > 0;)
            {
                const uint32_t node = order[i], p = parents[node];
                if (p < n && ends[p] < ends[node]) ends[p] = ends[node];
            }
            // Install early and late operators, often after a closer, without disturbing parents or subtree ends.
            for (uint32_t i = 1; i < n; i += 1)
            {
                const uint32_t parent = parents[i];
                if (parent < n && (random_number() >> 17) % 7 == 0)
                {
                    roles[i] = PARSE_ROLE_OPEN_SIZEOF;
                    roles[parent] = PARSE_ROLE_CLOSE_SIZEOF;
                    kinds[i - 1] = names[i - 1] = 1;
                }
            }
            Parser parser = { .tokens = { .count = n }, .tree = { .roles = roles, .parents = parents } };
            CheckInput output = { .sizeof_spans = retained };
            CheckInputReader reader = { .output = &output, .parser = &parser, .ends = ends };
            uint32_t visited = 0;
            for (uint32_t k = 0; k < n; k += 1)
            {
                if (kinds[k] && names[k])
                {
                    check_input_sizeof_span(&reader, k, &visited);
                    queried += 1;
                }
            }
            for (uint32_t i = 1; i < output.sizeof_span_count; i += 1)
            {
                assert(retained[i - 1].end <= retained[i].first);
            }
            uint32_t which = 0;
            for (uint32_t t = 1; t + 1 < n; t += 1)
            {
                while (which < output.sizeof_span_count && retained[which].end <= t) which += 1;
                const bool member = which < output.sizeof_span_count && retained[which].first <= t;
                // Independent necessary predicate of the former whole-unit warning pass.
                uint32_t close = parents[t];
                while (close < n && roles[close] == PARSE_ROLE_CLOSE_GROUP) close = parents[close];
                const bool binary = roles[t] >= PARSE_ROLE_ADDITIVE && roles[t] <= PARSE_ROLE_SEPARATOR;
                if (binary && close < n && roles[close] == PARSE_ROLE_CLOSE_SIZEOF)
                {
                    for (uint32_t open = t; open-- > 1;)
                    {
                        if (roles[open] == PARSE_ROLE_OPEN_SIZEOF && parents[open] == close)
                        {
                            if (names[open - 1] && kinds[open - 1])
                            {
                                assert(member);
                                candidates += 1;
                                outside_closer += t > close;
                            }
                            break;
                        }
                    }
                }
                masks += member;
            }
            overlaps += output.sizeof_span_count != 0;
        }
    }
    assert(outside_closer && candidates && overlaps && masks);
    printf("forests\tkeywords\toperator-ancestor-and-opener-matches\tqualified-after-close\tforests-with-spans\tcovered-source-slots\n");
    printf("%u\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\n", (LIMIT - 2) * 4, queried, candidates, outside_closer, overlaps, masks);
    return 0;
}
