#define OR8(x) ((x)|(x)|(x)|(x)|(x)|(x)|(x)|(x))
int values[6];
int side;
unsigned long long_operand(int n) { return sizeof(OR8(OR8(OR8(n))) + values); }
unsigned long nested_operand(void) { return sizeof(values + sizeof(values + side++)); }
int main(void) {
    return long_operand(2) != sizeof(int *) || nested_operand() != sizeof(int *) || side != 0;
}
