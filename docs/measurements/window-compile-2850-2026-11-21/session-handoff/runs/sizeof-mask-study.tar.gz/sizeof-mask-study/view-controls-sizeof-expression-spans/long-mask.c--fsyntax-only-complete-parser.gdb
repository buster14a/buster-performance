Breakpoint 1 at 0xfab7e0: file /home/david/Documents/Codex/2026-11-21/g/work/sizeof-expression-spans/src/buster/compiler/c_check_common_warnings.c, line 12985.
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/usr/lib/libthread_db.so.1".
[New Thread 0x9020a80 (LWP 4051133) (id 2)]
[Thread 0x9020a80 (LWP 4051106) (id 1) exited]
[New LWP 4051106 (id 3)]
[Inferior 1 (process 4051106) exited normally]
