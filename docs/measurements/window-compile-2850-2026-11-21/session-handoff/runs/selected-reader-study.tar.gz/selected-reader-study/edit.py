from pathlib import Path
p=Path(__file__).resolve().parents[1]/'selected-reader-storage/src/buster/compiler'
for name in 'c_check_input.c c_check_input_initializer.c c_check_control_input.c c_check_deferred_expressions.c c_check_enum_input.c c_check_constant.c c_check_select.c c_check_packed_input.c c_check_x86_input.c'.split():
 f=p/name;s=f.read_text()
 s=s.replace('reader->selected_tokens != NULL ? reader->selected_tokens[root] : BUSTER_CHECK_NONE','check_input_selection_at(reader, root)').replace('selected && reader->selected_tokens != NULL ? reader->selected_tokens[close]', 'selected ? check_input_selection_at(reader, close)')
 s=s.replace('reader->selected_tokens != NULL && (reader->selected_tokens[token] & CHECK_INPUT_SOURCE_SELECTION)', '(check_input_selection_at(reader, token) & CHECK_INPUT_SOURCE_SELECTION)')
 for value in ['chosen','root']:
  s=s.replace('reader->selected_tokens[close] = '+value+';', 'check_input_selection_set(reader, close, '+value+');')
 s=s.replace('reader->selected_tokens[token] = root | CHECK_INPUT_SOURCE_SELECTION;', 'check_input_selection_set(reader, token, root | CHECK_INPUT_SOURCE_SELECTION);')
 for index in ['token','root']:
  s=s.replace('reader->selected_tokens['+index+']','check_input_selection_at(reader, '+index+')')
 s=s.replace('check_input_scan_below(reader->selected_tokens, first, count, BUSTER_CHECK_NONE)','check_input_selections_below(reader, first, count)')
 if name=='c_check_input.c':
  s=s.replace('    uint32_t* selected_tokens; // NONE, a runtime operand token, or SOURCE_SELECTION | a proof-only operand token.','''    // The checked selection of a _Generic or choose expression. Subreaders may supply a private dense column.
    uint32_t* selected_tokens;
    CheckSparseColumn selected_sparse;''')
  where=s.index('// A constant reading\'s failure evidence')
  s=s[:where]+'''// Only the closing token of a selection can have an operand here. A proof-only selection sets the high bit.
static uint32_t check_input_selection_at(const CheckInputReader* reader, uint32_t token)
{
    if (reader->selected_tokens != NULL)
    {
        return reader->selected_tokens[token];
    }
    return check_sparse_present(reader->selected_sparse) ? check_sparse_get(reader->selected_sparse, token) : BUSTER_CHECK_NONE;
}

static void check_input_selection_set(CheckInputReader* reader, uint32_t token, uint32_t value)
{
    if (reader->selected_tokens != NULL)
    {
        reader->selected_tokens[token] = value;
    }
    else if (check_sparse_present(reader->selected_sparse))
    {
        check_sparse_set(&reader->output->sparse_pool, reader->selected_sparse, token, value);
    }
}

'''+s[where:]
  where=s.index('// The latest boundary strictly before token')
  s=s[:where]+'''static uint32_t check_input_selections_below(const CheckInputReader* reader, uint32_t first, uint32_t count)
{
    if (reader->selected_tokens != NULL)
    {
        return check_input_scan_below(reader->selected_tokens, first, count, BUSTER_CHECK_NONE);
    }
    return check_sparse_present(reader->selected_sparse) ? check_sparse_below(reader->selected_sparse, first, count, BUSTER_CHECK_NONE) : 0;
}

'''+s[where:]
  s=s.replace('    memset(reader->selected_tokens, 0xff, bytes);\n','')
  s=s.replace('    BUSTER_CHECK_INPUT_ARRAY(selected_tokens, uint32_t);\n','')
  s=s.replace('CheckSparseColumn sparse_columns[12] = { 0 };','CheckSparseColumn sparse_columns[13] = { 0 };\n    const uint32_t column_count = counts.groups[CHECK_INPUT_COUNT_SELECTIONS] != 0 ? 13 : 12;')
  s=s.replace('sparse_columns, BUSTER_ARRAY_LENGTH(sparse_columns), wide_columns','sparse_columns, column_count, wide_columns')
  s=s.replace('    input->string_ids = sparse_columns[11];','    input->string_ids = sparse_columns[11];\n    reader.selected_sparse = sparse_columns[12];')
 f.write_text(s)
f=p/'c_check_attested_test.c';s=f.read_text().replace('    { "selected_tokens", CHECK_ATTESTED_FIELD_OWN },','    { "selected_tokens", CHECK_ATTESTED_FIELD_OWN },\n    { "selected_sparse", CHECK_ATTESTED_FIELD_OWN },');f.write_text(s)
