from pathlib import Path
import csv,hashlib,json,os,re,shlex,subprocess,tempfile
d=Path(__file__).resolve().parent;w=d.parent;src=w/'classified-value-init'
s=(w/'sizeof-expression-study/source-regions.py').read_text()
exec(s[s.index('c=next('):s.index("ofs=offsets('CheckInput'")].replace('-fdump-record-layouts','-fdump-record-layouts-complete'),globals())
o=offsets('CheckInputReader',['first_value','output']);fields=offsets('CheckInput',['token_count'])
srcargs=s.split("srcargs='''")[1].split("'''")[0].replace('\\\\0','\\0').replace('$1/pregraph-warning-study','$1/switch-inputs/../pregraph-warning-study').replace('$1/proof-predefines.h','$1/switch-inputs/../proof-predefines.h')
with tempfile.TemporaryDirectory(dir=d) as tmp,(d/'poison.tsv').open('w',buffering=1) as f:
 t=Path(tmp);wr=csv.writer(f,delimiter='\t');wr.writerow(['unit','policy','first_words_replaced','old_ff','digest','status','native_exact','diagnostics_exact'])
 for u in ['sqlite','main']:
  args=subprocess.check_output(['bash','-c',srcargs,'_',str(w),u]).decode().strip('\0').split('\0')
  for policy,opts in [('default',[]),('all',['-Weverything'])]:
   g=t/'run.gdb';new=t/'new.o';base=t/'reference.o';new.unlink(missing_ok=True)
   r=subprocess.run([src/'build/compiler','--lanes','1','-c',*args,*opts,'-o',base],capture_output=True)
   g.write_text(f"""set pagination off
set confirm off
set debuginfod enabled off
python
import gdb,struct
class Poison(gdb.Breakpoint):
 def stop(self):
  p=int(gdb.parse_and_eval('$rdi'));inf=gdb.selected_inferior()
  word=lambda a,n:int.from_bytes(inf.read_memory(a,n).tobytes(),'little')
  n=word(word(p+{o['output']},8)+{fields['token_count']},4)
  if n<10000:return False
  a=word(p+{o['first_value']},8);before=inf.read_memory(a,n*4).tobytes()
  with open('{t}/hits','w') as log:log.write('%d %d'%(n,before.count(b'\\xff')==4*n))
  inf.write_memory(a,b'\\xa5'*(4*n))
  self.enabled=False
  return False
Poison("*'check_input_resolve_range.buster_split'")
end
run {shlex.join(["--lanes","1","-c",*args,*opts,"-o",str(new)])} >{t}/stdout 2>{t}/stderr
""")
   (t/'hits').unlink(missing_ok=True)
   run=subprocess.run(['gdb','-q','--batch','-x',g,'--args',src/'build/compiler','--lanes','1','-c',*args,*opts,'-o',new],capture_output=True)
   (d/(u+'-'+policy+'.log')).write_bytes(run.stdout+run.stderr)
   n,old=(t/'hits').read_text().split()
   equal=new.is_file() and new.read_bytes()==base.read_bytes();diag=(t/'stderr').read_bytes()==r.stderr and (t/'stdout').read_bytes()==r.stdout
   wr.writerow([u,policy,n,old,hashlib.sha256(base.read_bytes()).hexdigest(),r.returncode,equal,diag]);assert equal and diag and r.returncode==0
