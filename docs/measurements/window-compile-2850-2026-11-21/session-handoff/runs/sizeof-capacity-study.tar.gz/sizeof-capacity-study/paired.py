from pathlib import Path
import csv,hashlib,statistics,sys
root=Path(sys.argv[1]);group=sys.argv[2];d=root/'results'/('ordinary-pair-sizeofcapdd4-'+group)
ordered=list(csv.DictReader((d/'order.tsv').open(),delimiter='\t'))
n=7 if group=='sqlite' else 3
def unique(stem):return (d/stem).read_bytes()
native=unique('preflight-baseline.objects')
for f in d.glob('*.objects'):assert f.read_bytes()==native, f
assert len(list(d.glob('*.objects')))==8*n+6
for pre in ['policy','preflight']:
    for ext in ['stdout','stderr']:
        assert unique(f'{pre}-baseline.{ext}')==unique(f'{pre}-candidate.{ext}')
assert len(ordered)==8*n
obs={}
with (root/(group+'-samples.tsv')).open('w') as o:
  wr=csv.writer(o,delimiter='\t',lineterminator='\n');wr.writerow(['series','round','position','mode','metric','value'])
  for series in ['wall','pmu']:
    for round in range(1,n+1):
      rows=[x for x in ordered if x['series']==series and int(x['round'])==round]
      arms=[x['mode'] for x in rows];assert len(rows)==4 and arms==arms[::-1] and arms.count('candidate')==2
      for row in rows:
        pos=int(row['position']);arm=row['mode'];stem=f'{series}-{round}-{pos}'
        for ext in ['stdout','stderr']:assert unique(stem+'.'+ext)==unique('preflight-baseline.'+ext),(stem,ext)
        if series=='wall':
          x=next(csv.DictReader((d/(stem+'.wall')).open(),delimiter='\t'));assert int(x['status'])==0
          metrics={'wall-ms':int(x['wall-ns'])/1000000,'wall-user-ms':int(x['user-us'])/1000,'wall-system-ms':int(x['system-us'])/1000,'wall-minor-faults':int(x['minor-faults']),'wall-major-faults':int(x['major-faults']),'wall-maxrss-kib':int(x['maxrss-kib'])}
        else:
          with (d/(stem+'.perf')).open() as inp: records=[x for x in csv.reader(inp) if len(x)>=5]
          pmu={x[2]:float(x[0]) for x in records}; assert all(float(x[4])==100 for x in records)
          metrics={'pmu-task-clock-ms':pmu['task-clock'],'user-instructions':pmu['instructions:u'],'total-cycles':pmu['cycles:u']+pmu['cycles:k'],'user-cycles':pmu['cycles:u'],'kernel-instructions':pmu['instructions:k'],'pmu-faults':pmu['page-faults']}
        for k,v in metrics.items():
          wr.writerow([series,round,pos,arm,k,v]);obs.setdefault(k,{}).setdefault(round,{}).setdefault(arm,[]).append(v)
with (root/(group+'-paired.tsv')).open('w') as o,(root/(group+'-summary.tsv')).open('w') as s:
    w=csv.writer(o,delimiter='\t',lineterminator='\n');w.writerow(['metric','round','baseline','candidate','difference'])
    ws=csv.writer(s,delimiter='\t',lineterminator='\n');ws.writerow(['metric','baseline-median','candidate-median','paired-median','paired-min','paired-max','faster-rounds','rounds'])
    for metric,rounds in obs.items():
        old=[];new=[];deltas=[]
        for r,x in rounds.items():
            a=statistics.mean(x['baseline']);b=statistics.mean(x['candidate']);old.append(a);new.append(b);deltas.append(b-a);w.writerow([metric,r,a,b,b-a])
        ws.writerow([metric,statistics.median(old),statistics.median(new),statistics.median(deltas),min(deltas),max(deltas),sum(x<0 for x in deltas),len(deltas)])
print(len(ordered),'fresh timed invocations',len(native.splitlines()),'identical objects per manifest',hashlib.sha256(native).hexdigest())
