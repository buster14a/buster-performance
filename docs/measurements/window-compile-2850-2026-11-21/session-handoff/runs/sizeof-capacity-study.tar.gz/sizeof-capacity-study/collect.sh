#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; mkdir -p "$d/hardware"
cluster='cd ~/buster-fast-bench/2850-codex-step2'
for group in sqlite main; do
 n=25; if [[ $group == sqlite ]]; then n=57; fi
 until ssh benchpress "$cluster && test -s results/ordinary-pair-sizeofcapdd4-$group/order.tsv && test \"\$(wc -l < results/ordinary-pair-sizeofcapdd4-$group/order.tsv)\" = $n"; do sleep 20; done
 ssh benchpress "$cluster && tar cf - results/sizeofcapdd4/{revision.txt,compiler.sha256,build.log,build-clock.log} results/main40ae/{revision.txt,compiler.sha256} results/ordinary-pair-sizeofcapdd4-$group sizeofcapdd4-job.log" | tar xf - -C "$d/hardware"
 python3 "$d/paired.py" "$d/hardware" "$group" >"$d/hardware/$group-verified.txt"
done
