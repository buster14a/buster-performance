#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD
until [[ -s compiler.sha256 ]]; do sleep 4; done
export CORES_TITLE='2850 verify allocation-on-first-candidate warning ranges against real frozen source rows, typed dumps and native Clang'
export CORES_LINK=https://github.com/buster14a/buster/issues/2850
cores -n 1 -- python3 source-regions.py >source-regions.log 2>&1
cores -n 1 -- python3 diagnostics.py >diagnostics.log 2>&1
cores -n 1 -- python3 runtime.py >runtime.log 2>&1
