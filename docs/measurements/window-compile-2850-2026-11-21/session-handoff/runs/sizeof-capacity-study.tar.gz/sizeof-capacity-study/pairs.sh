#!/bin/bash
set -eu
cd "$(dirname "$0")"
until [[ -s compiler.sha256 && -s ranges.tsv && -s typed.tsv && $(wc -l <typed.tsv) == 5 ]]; do sleep 6; done
python3 local-pairs.py
