#!/bin/bash
set -eu
cd "$(dirname "$0")/../sizeof-retained-capacity"
./build.sh --config Develop --target compiler --jobs 1
cp ../sizeof-mask-exact/build/predefines.h build/predefines.h
sha256sum build/compiler >../sizeof-capacity-study/compiler.sha256
