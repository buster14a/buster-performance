set pagination off
set debuginfod enabled off
set confirm off
python
import gdb
def read(ptr,size):
 return int.from_bytes(gdb.selected_inferior().read_memory(ptr,size).tobytes(),'little')
class Worker(gdb.Breakpoint):
 def stop(self):
  parser=int(gdb.parse_and_eval('$rdi'));inp=int(gdb.parse_and_eval('$rdx'));n=read(inp+1940,4)
  if n>10000:
   assert parser==read(inp+2704,8),(parser,n)
   cnt=read(inp+2720,4)
   # The source's real kind bytes are independent of the retained warning ranges.
   with open('/home/david/Documents/Codex/2026-11-21/g/work/sizeof-capacity-study/tmpynd_vhad/kinds','wb') as fn:fn.write(gdb.selected_inferior().read_memory(read(parser+88,8),n).tobytes())
   with open('/home/david/Documents/Codex/2026-11-21/g/work/sizeof-capacity-study/tmpynd_vhad/index-state','w') as fn:fn.write(str(bool(read(inp+2712,8)))+' '+str(cnt)+'\n')
   with open('/home/david/Documents/Codex/2026-11-21/g/work/sizeof-capacity-study/tmpynd_vhad/spans','wb') as fn:fn.write(gdb.selected_inferior().read_memory(read(inp+2712,8),cnt*8).tobytes() if cnt else b'')
   with open('/home/david/Documents/Codex/2026-11-21/g/work/sizeof-capacity-study/tmpynd_vhad/roles','wb') as fn:fn.write(gdb.selected_inferior().read_memory(read(parser+160,8),n).tobytes())
  return False
Worker("*'check_driver_common_warnings.buster_split'")
end
run
