from pathlib import Path
import csv,re
d=Path(__file__).resolve().parent;w=d.parent
src=(w/'sizeof-retained-capacity/src/buster/compiler/c_parser.c').read_text().split('#define BUSTER_PARSE_KINDS(X)',1)[1].split('typedef enum',1)[0]
kinds=re.findall(r'^    X\((\w+)\)',src,re.M)
assert kinds.count('SIZEOF')==1
k=kinds.index('SIZEOF')
x=list(csv.DictReader((d/'source-regions.tsv').open(),delimiter='\t'))
with (d/'footprint.tsv').open('w') as f:
 wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['source','keyword-kind','keyword-count','old-reserved-bytes','new-pointer-nonnull','retained-ranges','new-reserved-bytes'])
 for row in x:
  g=row['source'];raw=(d/'source-observations'/(g+'-kinds')).read_bytes();count=raw.count(k);assert len(raw)==int(row['tokens']);keep=int(row['coalesced-ranges'])
  ok,n=(d/'source-observations'/(g+'-index-state')).read_text().split();assert int(n)==keep and (ok=='True')==(keep!=0)
  capacity=reserved=0
  while capacity<keep:
   capacity=min(4 if capacity==0 else 2*capacity,count);reserved+=capacity
  wr.writerow([g,k,count,8*count,ok,keep,8*reserved])
