int a[8];
unsigned long f(void) { return sizeof(a + 0) + sizeof(a + 1) + sizeof(a + 2) + sizeof(a + 3) + sizeof(a + 4) + sizeof(a + 5) + sizeof(a + 6) + sizeof(a + 7) + sizeof(a + 8) + sizeof(a + 9) + sizeof(a + 10) + sizeof(a + 11) + sizeof(a + 12) + sizeof(a + 13) + sizeof(a + 14) + sizeof(a + 15) + sizeof(a + 16); }
