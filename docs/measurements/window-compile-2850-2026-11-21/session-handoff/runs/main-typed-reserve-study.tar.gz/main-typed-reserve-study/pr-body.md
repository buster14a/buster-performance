A translation unit containing an atomic or transport-vector type currently runs the full lowering reserve calculation on every expression. This change uses batches of sixteen checked result types, conversion types and left-operand types to identify expressions with ordinary storage needs. Vector builtins, wrapped types and other exceptional cases still run their full reserve rule. The final type in the column can participate without reading past the allocation.

The existing numerical reserve assertion now covers transport entries and locals. A regression case checks a scalar subscript result whose wide vector operand still needs transport storage.

This is a scoped contribution to #2850. Current-head qualification is comparing all seven reserve fields, object files, diagnostics and executable results on vector-heavy probes and frozen real inputs. I will add the matched Release measurements for SQLite and Buster before requesting the protected merge.

---
Agent session: 01a20074-0229-7740-8c28-0181f413f774 (Codex session ID, no share URL is exposed)
Model: OpenAI / GPT-6
