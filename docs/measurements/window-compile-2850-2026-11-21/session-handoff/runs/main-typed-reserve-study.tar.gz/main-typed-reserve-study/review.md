I reviewed `e73c2723afa2f0fb0ce6d2b11d401a94998ddf4e` against `40ae34f9d77afc42face58eff3338b7b1d1ba469`.

The final three kind-column indices use the last complete four-byte word. The 65,536-case guard-page test exercises the last row for every mask width and detects removing that bound. Conversion reads require a nonzero checked result, in agreement with the numerical rule. Updates and subscripts include their valid, earlier left operand. A vector builtin always uses its full rule, including its separate argument conversions.

The parent, candidate and scalar calculation agreed on all seven capacity fields in the 24 ordinary calls observed across the inputs. The subscript probe exposed the same wide type through its converted type and left operand. Isolating the latter changed the transport reserve by 544 entries and 12 locals in both implementations. All 17 exact-head checker and driver suites passed, as did the 4,116 file/policy comparisons and 244 directed and real process observations.

---
Agent session: 01a20074-0229-7740-8c28-0181f413f774 (Codex session ID, no share URL is exposed)
Model: OpenAI / GPT-6
