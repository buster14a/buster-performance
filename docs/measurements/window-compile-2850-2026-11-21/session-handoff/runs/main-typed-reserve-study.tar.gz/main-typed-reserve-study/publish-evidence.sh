#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
d=$PWD
repo="$d/../typed-reserve-public-evidence"
path=docs/measurements/window-compile-2850-2026-11-21/e73c2723a
test -s receipt/summary.json
test -s target/summary.tsv
mkdir -p receipt/target
cp target/* receipt/target/
cp target-admission.json receipt/target/
cp target-raw/parent.built target-raw/candidate.built receipt/target/
# The shared runner's wait log can identify unrelated owners. The measurements and compiler streams are retained.
tar czf receipt/target/raw.tar.gz -C target-raw/target --exclude=lock.log --exclude=samples.tsv --exclude=summary.tsv --exclude=system.json --exclude=lscpu.txt .
tar czf receipt/target/wall-raw.tar.gz -C target-raw/target-wall --exclude=lock.log --exclude=samples.tsv --exclude=summary.tsv .
for arm in parent candidate; do
    sed -n '/-- The C compiler identification/,$p' "target-raw/$arm-build.log" | gzip -n > "receipt/target/$arm-build.log.gz"
done
python3 - <<'PY'
import csv,json,pathlib
d=pathlib.Path('receipt');txt=(d/'README.md').read_text();m='## Ryzen 7 9700X'
if m not in txt:
 rows=list(csv.DictReader((d/'target/summary.tsv').open(),delimiter='\t'))
 txt+='\n'+m+'\n\nThe exact parent and PR revisions each built in Release on benchpress. The shared exclusive lock covers each invocation separately. Five alternating ABBA or BAAB rounds used CPU 2 with one compiler lane. Five additional alternating rounds timed the compiler directly with the monotonic clock. The kernel software duration event in the PMU series returned zero. The direct process series supplies the reported wall times. Every measured result matched the preflight ELF and compiler streams. [PMU samples](target/samples.tsv), [direct wall samples](target/wall-samples.tsv), [compiler hashes and machine details](target/system.json), [hosted admission](target/target-admission.json) and [individual PMU logs](target/raw.tar.gz).\n\n| Source | Metric | Parent | Candidate | Paired change | Lower rounds |\n| --- | --- | ---: | ---: | ---: | ---: |\n'
 for r in rows:txt+=f"| {r['input']} | {r['metric']} | {float(r['median-parent']):,.0f} | {float(r['median-candidate']):,.0f} | {float(r['median-paired-change']):+,.0f} | {r['lower-rounds']}/{r['rounds']} |\n"
 (d/'README.md').write_text(txt)
PY
mkdir -p "$repo/$path"
cp -a receipt/. "$repo/$path/"
git -C "$repo" add -- "$path"
if ! git -C "$repo" diff --cached --quiet; then git -C "$repo" commit -m 'Record ordinary operand reserve measurements and numeric controls for #2850'; fi
for attempt in 1 2 3 4; do
    git -C "$repo" fetch -q origin main
    git -C "$repo" rebase FETCH_HEAD
    if git -C "$repo" push origin HEAD:main; then git -C "$repo" rev-parse HEAD > evidence-revision.txt; exit 0; fi
done
exit 1
