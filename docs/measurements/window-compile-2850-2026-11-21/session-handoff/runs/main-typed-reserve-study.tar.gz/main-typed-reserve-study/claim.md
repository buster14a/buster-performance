I’m taking the ordinary lowering reserve planner within the existing #2850 effort, on `codex/2850-typed-operand-reserve`. The checked types and conversions can rule out vector and atomic reserve work for many expressions even when another expression in the translation unit needs it. I’m qualifying the production change against the current main branch, including Buster, SQLite, vector-heavy programs, and the complete numerical reserve result. The single-core 1 GB/s goal remains open.

---
Agent session: 01a20074-0229-7740-8c28-0181f413f774 (Codex session ID, no share URL is exposed)
Model: OpenAI / GPT-6
