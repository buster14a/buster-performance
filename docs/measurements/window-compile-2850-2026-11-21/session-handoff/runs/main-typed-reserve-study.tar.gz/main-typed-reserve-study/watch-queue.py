import json,subprocess,time
from pathlib import Path
d=Path(__file__).resolve().parent;repo='buster14a/buster';oid='d541430bf1ff3ed59880352758fabbc664c839fc';run=44985578903
def api(path):
 for i in range(3):
  p=subprocess.run(['gh','api',path],capture_output=True)
  if p.returncode==0:return json.loads(p.stdout)
  time.sleep(2**i)
 raise RuntimeError(p.stderr.decode())
last=None
with (d/'queue-status.tsv').open('w',buffering=1) as out:
 out.write('utc\trun\tconclusion\tpr\tmerged\n')
 while True:
  r=api(f'repos/{repo}/actions/runs/{run}');pr=api(f'repos/{repo}/pulls/3269');obj=(r['status'],r['conclusion'],pr['state'],pr['merged'])
  if obj!=last:
   out.write(time.strftime('%FT%TZ',time.gmtime())+'\t'+'\t'.join(str(a) for a in obj)+'\n');last=obj
  if r['status']=='completed' and (r['conclusion']!='success' or pr['merged']):
   alljobs=[];page=1
   while True:
    response=api(f'repos/{repo}/actions/runs/{run}/jobs?per_page=100&page={page}');alljobs+=response['jobs']
    if len(alljobs)>=response['total_count'] or not response['jobs']:break
    page+=1
   (d/'queue-final.json').write_text(json.dumps({'run':{k:r[k] for k in ('id','status','conclusion','head_sha','html_url')},'merged':pr['merged'],'merged_at':pr['merged_at'],'merge_commit_sha':pr['merge_commit_sha'],'gates':[{k:j[k] for k in ('id','name','status','conclusion','html_url')} for j in alljobs if j['name'] in ('Integration qualification','Measurement storage policy') or j['conclusion']=='failure']},indent=2));break
  time.sleep(30)
