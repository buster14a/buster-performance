#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
remote=/home/david/buster-fast-bench/2850-typed-reserve-e73c2723a
mkdir -p target-raw target
tailscale ssh david@benchpress "cd '$remote' && test \"\$(cat target.status)\" = 0 && test \"\$(cat wall.status)\" = 0 && test -s target/complete && test -s target-wall/complete && tar czf - --exclude='*.elf' target target-wall parent.built candidate.built parent-build.log candidate-build.log target.status wall.status" | tar xzf - -C target-raw
cp target-raw/target/system.json target-raw/target/lscpu.txt target
cp target-raw/target-wall/samples.tsv target/wall-samples.tsv
cp target-raw/target/summary.tsv target/pmu-original-summary.tsv
python3 join-target.py
