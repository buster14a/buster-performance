#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
bash per-file.sh
python3 package.py
