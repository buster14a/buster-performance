[PR #3269](https://github.com/buster14a/buster/pull/3269) merged through the protected queue at `d541430bf1ff`. The ordinary compiler now uses checked operand types to restrict the full lowering-reserve calculation to the expressions that need it. [Protected qualification](https://github.com/buster14a/buster/actions/runs/44985578903).

On one Ryzen 7 9700X core, ordinary Buster compilation went from 611.146 ms to 602.004 ms. The median within-round change was −9.142 ms, with −36.866 million user cycles and −400.723 million instructions. All five groups improved on all three measures. SQLite kept its existing operator path and measured 112.328 ms at the PR head, with a paired change of −0.139 ms and +0.444 million user cycles. That places the 9,507,037-byte input at 84.64 MB/s. All 80 measured processes in the two independent wall and PMU series matched complete objects and diagnostic streams. [Raw samples and numerical controls](https://github.com/buster14a/buster-performance/tree/76795f21fcd36e5cbf07827383295bce565d1071/docs/measurements/window-compile-2850-2026-11-21/e73c2723a).

The single-core 1 GB/s target remains open.

---
Agent session: 01a20074-0229-7740-8c28-0181f413f774 (Codex session ID, no share URL is exposed)
Model: OpenAI / GPT-6
