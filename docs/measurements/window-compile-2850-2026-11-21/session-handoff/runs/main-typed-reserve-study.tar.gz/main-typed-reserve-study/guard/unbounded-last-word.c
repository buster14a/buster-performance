#include <immintrin.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <unistd.h>
typedef struct { struct { uint32_t count; uint8_t *kind; } types; } TypeTable;
#define BUSTER_TYPE_INDEX_SHIFT 3
#define BUSTER_TYPE_KIND_VECTOR 12
#define BUSTER_TYPE_KIND_ATOMIC 14
#define BUSTER_TYPE_KIND_ALIGNED 18
#define BUSTER_TYPE_KIND_WRAPPERS BUSTER_TYPE_KIND_ALIGNED
static __mmask16 check_lower_plain_reserve_types(const TypeTable* types, __mmask16 active, __m512i ids)
{
    const __m512i zero = _mm512_setzero_si512();
    const __mmask16 nonzero = _mm512_mask_cmpneq_epi32_mask(active, ids, zero);
    __mmask16 plain = active & ~nonzero;
    if (nonzero != 0)
    {
        const __m512i index = _mm512_srli_epi32(ids, BUSTER_TYPE_INDEX_SHIFT);
        const __m512i begin = index;
        const __m512i word = _mm512_mask_i32gather_epi32(zero, nonzero, begin, types->types.kind, 1);
        const __m512i shift = _mm512_slli_epi32(_mm512_sub_epi32(index, begin), 3);
        const __m512i kind = _mm512_and_si512(_mm512_srlv_epi32(word, shift), _mm512_set1_epi32(255));
        const __mmask16 before = _mm512_mask_cmplt_epu32_mask(nonzero, kind, _mm512_set1_epi32(BUSTER_TYPE_KIND_VECTOR));
        const __mmask16 after = _mm512_mask_cmpgt_epu32_mask(nonzero, kind, _mm512_set1_epi32(BUSTER_TYPE_KIND_ATOMIC));
        plain |= before | _mm512_mask_cmplt_epu32_mask(after, kind, _mm512_set1_epi32(BUSTER_TYPE_KIND_WRAPPERS));
    }
    return plain;
}

int main(void)
{
    struct rlimit limit = { 0, 0 };
    setrlimit(RLIMIT_CORE, &limit);
    long page = sysconf(_SC_PAGESIZE);
    uint8_t *memory = mmap(0, 2 * page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (memory == MAP_FAILED || mprotect(memory + page, page, PROT_NONE) != 0) return 2;
    uint32_t seed = 2850;
    size_t checks = 0;
    for (uint32_t n = 4; n < 68; n += 1)
    {
        uint8_t *kinds = memory + page - n;
        TypeTable types = { .types = { n, kinds } };
        for (uint32_t j = 0; j < n; j += 1) kinds[j] = j == 0 ? 0 : (j * 7 + n) % 20;
        for (uint32_t trial = 0; trial < 64; trial += 1)
        {
            uint32_t ids[16];
            for (uint32_t j = 0; j < 16; j += 1)
            {
                seed = seed * 1664525 + 1013904223;
                uint32_t index = j < 3 ? n - 1 - j : seed % n;
                ids[j] = index == 0 ? 0 : (index << 3) | (seed & 7);
            }
            for (unsigned width = 1; width <= 16; width += 1)
            {
                uint16_t mask = (1u << width) - 1, expected = 0;
                for (unsigned j = 0; j < width; j += 1)
                {
                    uint8_t kind = kinds[ids[j] >> 3];
                    if (kind < 12 || (kind > 14 && kind < 18)) expected |= (uint16_t)(1u << j);
                }
                uint16_t got = check_lower_plain_reserve_types(&types, mask, _mm512_loadu_epi32(ids));
                if (got != expected)
                {
                    fprintf(stderr,"count=%u trial=%u width=%u got=%u expected=%u\n",n,trial,width,got,expected);
                    return 1;
                }
                checks += 1;
            }
        }
    }
    printf("%zu guard-page and mask comparisons\n",checks);
    return 0;
}
