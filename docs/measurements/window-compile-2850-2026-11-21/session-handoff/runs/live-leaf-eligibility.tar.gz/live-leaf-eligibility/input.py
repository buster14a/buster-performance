from pathlib import Path
import csv,hashlib,json,os,re,shlex,subprocess,tempfile
d=Path(__file__).resolve().parent;w=d.parent;src=w/'prefix-leaf-dictionary'
s=(w/'sizeof-expression-study/source-regions.py').read_text()
exec(s[s.index('c=next('):s.index("ofs=offsets('CheckInput'")].replace('-fdump-record-layouts','-fdump-record-layouts-complete'),globals())
out=offsets('CheckInputReader',['output'])['output']
cols=offsets('CheckInput',['token_count','overload_heads','kr_parameter_count','weak_name_count','symbol_pragmas'])
srcargs=s.split("srcargs='''")[1].split("'''")[0].replace('\\\\0','\\0').replace('$1/pregraph-warning-study','$1/switch-inputs/../pregraph-warning-study').replace('$1/proof-predefines.h','$1/switch-inputs/../proof-predefines.h')
for u in ['sqlite','main']:
 args=subprocess.check_output(['bash','-c',srcargs,'_',str(w),u]).decode().strip('\0').split('\0')
 with tempfile.TemporaryDirectory(dir=d) as tmp:
  t=Path(tmp);g=t/'probe.gdb';g.write_text(f"""set pagination off
set debuginfod enabled off
python
import gdb
seen=set()
class Eligibility(gdb.Breakpoint):
 def stop(self):
  inf=gdb.selected_inferior()
  read=lambda a,n:int.from_bytes(inf.read_memory(a,n).tobytes(),'little')
  p=int(gdb.parse_and_eval('$rdi'));unit=read(p+{out},8); n=read(unit+{cols['token_count']},4)
  if n not in seen:
   seen.add(n)
   with open('{t}/state','a') as log:print(n,read(unit+{cols['overload_heads']},8)!=0,read(unit+{cols['kr_parameter_count']},4),read(unit+{cols['weak_name_count']},4),read(unit+{cols['symbol_pragmas']},8)!=0,file=log)
  return False
Eligibility("*'check_input_expressions'")
end
run
""")
  env=os.environ|{k:'1' for k in 'BUSTER_PARSE_LIVE_FOREST BUSTER_LIVE_CHECKED_INPUT BUSTER_PARSE_LIVE_AUDIT BUSTER_LIVE_ORDINARY_HANDOFF BUSTER_PRE_EOF_LEAVES'.split()}|{'BUSTER_PRE_EOF_NATIVE_WINDOW':'24'}
  p=subprocess.run(['gdb','-q','--batch','-x',g,'--args',src/'build/compiler','--lanes','1','-c',*args,'-o',t/'out.o'],env=env,capture_output=True);(d/(u+'.log')).write_bytes(p.stderr+p.stdout)
  assert (t/'out.o').read_bytes()==(w/'source-typed-study'/(u+'.o')).read_bytes();(d/(u+'.tsv')).write_bytes((t/'state').read_bytes())
