from pathlib import Path
import csv,collections,statistics
d=Path(__file__).resolve().parent
def read(p):
 return list(csv.DictReader(p.open(),delimiter='\t'))
for folder in ['debug-run','optimized-run']:
 if not (d/folder/'sqlite.graphless.log').exists():continue
 for unit in ['sqlite','main','random','nested','forest']:
  for mode in ['graphless','bounded8','bounded32','bounded128']:
   p=d/folder/(unit+'.'+mode+'.log')
   if not p.exists():continue
   l=[x.split('\t') for x in p.read_text().splitlines()];rows={};owned={}
   harmless={'list','drop','separator','group','terminator'}
   for r in l:
    if r[0]=='source-root-residual':rows[int(r[1])]=(int(r[2]),{k:int(v) for col in r[3:] for k,v in [col.split('=')] if k not in harmless})
    if r[0]=='source-root-body':owned[int(r[1])]=int(r[2])
   refs=[r for r in l if r[0]=='source-native-fragment'];units={int(r[1]):int(r[2]) for r in refs}
   chosen=sum((not rr for c,rr in rows.values()))
   actual=sum((c in units for c in owned.values())); bytes_emitted=sum(units.get(c,0) for c in owned.values())
   print(folder,unit,mode,'total',len(rows),'no expression actions',chosen,'published',len(owned),'used',actual,'injected bytes',bytes_emitted,'covered physical tokens',sum(c-o+1 for o,c in owned.items()))
   if not rows:continue
   candidates=collections.Counter();nodes=collections.Counter()
   for o,(c,by) in rows.items():
    key=tuple(sorted(by));candidates[key]+=1;nodes[key]+=c-o+1
   print('largest single remaining classes:',[(k,candidates[k],nodes[k]) for k in candidates if len(k)<=1])
   print('largest mixed remaining classes:',[(k,n,nodes[k]) for k,n in candidates.most_common(7)])
   o=d/folder/(unit+'.'+mode+'.ownership.tsv')
   with o.open('w') as f:
    w=csv.writer(f,delimiter='\t');w.writerow(['open','close','covered tokens','published','injected','bytes','remaining'])
    for o,(c,by) in sorted(rows.items()):w.writerow([o,c,c-o+1,o in owned,o in owned and c in units,units.get(c,0) if o in owned else 0,str(by)])
