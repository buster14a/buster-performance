from pathlib import Path
import subprocess,os,csv
d=Path(__file__).resolve().parent;cc=d.parent/'source-bounded-roots/build/compiler'
cases={
 'partial field error':'unsigned f(unsigned x){x=x+1;return x.missing;}',
 'partial conflicting float pointer':'int f(int x){x=x+1;int *p=2.5;return *p;}',
 'partial invalid dereference':'unsigned f(unsigned x){x=x+1;return *x;}',
 'partial void use':'extern void g(void);unsigned f(unsigned x){x=x+1;return g();}', 
 'counted local':'struct C {int n; int *p __attribute__((counted_by(n)));}; int f(int x, struct C*p){p->n=x;return p->n;}',
 'counted initializer':'struct C {int n; int *p __attribute__((counted_by(n)));}; extern void g(int);int f(int *p){struct C c={0,p};g(c.n);return c.n;}',
 'late counted declaration':'extern void g(int);void f(int x){g(x);x=x+1;}struct C{int n;int *p __attribute__((counted_by(n)));};',
 'sparse switch':'int f(int x){switch(x){case 2:return 1;case 2003:return 2;case 81231:return 3;default:return 4;}}',

 'extern object':'extern int g;extern void consume(int);int f(int x){consume(g);g=x;x=g;return x;}',
 'tentative global':'int g;extern void consume(int);int f(int x){consume(g);g=x;x=g;return x;}',
 'file block shadow':'int g;extern void consume(int);int f(int g){consume(g);{int g=3;consume(g);}return g;}',
 'global member data':'struct P{int x;};extern struct P*gp;void f(int x){gp->x=x;}',
 'extern local identity':'extern void consume(int);int f(int x){extern int g;consume(g);g=x;x=g;return x;}',
 'register address':'extern void consume(int*);void f(int x){register int r=x;consume(&r);}',
 'width addpower':'unsigned f(unsigned x){x=x*2;return x;}',
 'width subzero':'int f(int x){x=x-0;return x;}',
 'width nulptr':'void *f(void *p){p=0;return p;}',
 'undefined assignment':'struct P{int x;};int f(struct P*p){p->x=p->missing;return p->x;}',
 'zero initializer':'int f(void){int x;int y;x=0;y=x;return y;}',
 'atomic pointer member':'struct P{_Atomic int x;};void f(struct P*p,int v){p->x=v;}',
 'restricted assignment':'int*f(int * restrict p,int*q){p=q;return p;}',
 'callee static minimum':'extern void effect(int x[static 9]);void f(void){effect(0);}',
 'nullability':'extern void effect(int * _Nonnull);void f(void){effect(0);}',
 'unavailable member':'struct S{int x __attribute__((unavailable));};extern void effect(int);void f(struct S*s){effect(s->x);}',
 'noderef member':'struct S{int x;};extern void effect(int);void f(struct S __attribute__((noderef))*s){effect(s->x);}',
 'discarded result':'int effect(int) __attribute__((warn_unused_result));void f(int x){effect(x);}',
 'illegal store':'struct S{const int x;};void f(struct S*p,int v){p->x=v;}',
 'const member dest':'struct S{int x;};void f(const struct S*p,int v){p->x=v;}',
 'bitfield dest':'struct S{unsigned x:5;};void f(struct S*p,unsigned v){p->x=v;}',
 'volatile source':'struct S{volatile int x;};int f(struct S*p){int v;v=p->x;return v;}',
 'static dest':'static int y;void f(int x){y=x;}',
 'static source':'static int x;void f(int y){y=x;}',
 'ptr qual loss':'void f(const int *a,int *b){b=a;}',
 'nonzero pointer':'void f(int *a){a=7;}',
 'const local':'void f(int x){const int y=3;y=x;}',
 'simple integer':'int f(int a,int b){int t=0;t=a+b;return t;}',
 'member store and load':'struct S{int x;};int f(struct S*p,int x){p->x=x;x=p->x;return x;}',
 'unsigned wrap':'unsigned f(unsigned x){x=x+1;return x;}',
 'self member':'struct S{int x;};void f(struct S*p,int x){p->x=p->x+x;}',
 'nested control':'int f(int a,int b){if(a){a=a+b;}else{b=b-a;}return a*b;}',
 'shadowed local':'int f(int a,int b){ {int a=2;a=b;b=a;}return a+b;}',
 'body':'extern void effect(int); int f(int x) { effect(x); return x+1; }',
 'call-two':'extern int effect(int,int); int f(int x, int y) { effect(x,y); return x-y; }',
 'loop':'extern void effect(int); void f(int x) { while(x--){ effect(x); } }',
 'condition':'extern void effect(int); void f(int x) { if(x){ effect(x); } else {effect(3);} }',
 'jump':'extern void effect(int); void f(int x) { goto a; effect(x);a:effect(x); }',
 'const branch':'extern void effect(int); void f(int x) { if(0){effect(x);}else{effect(3);} }',
 'stmt-expr':'extern void effect(int); void f(int x) { x=({effect(x);4;}); effect(x); }',
 'static local':'extern void effect(int); void f(void) {static int x=7;effect(x); }',
 'volatile local':'extern void effect(int);void f(void){volatile int x=9;effect(x);}',
 'pragma':'extern void effect(int);void f(int x){_Pragma("GCC diagnostic push") effect(x); _Pragma("GCC diagnostic pop")}',
 'attribute':'extern void effect(int) __attribute__((deprecated));void f(int x){effect(x);}',
 'symbol alias':'extern void effect(int) __asm__("call_target");void f(int x){effect(x);}',
 'implicit conversion':'extern void effect(unsigned);void f(int x){effect(x);}',
 'void ptr':'extern void effect(void*);void f(int*x){effect(x);}',
 'volatile pointee':'extern void effect(volatile int*);void f(volatile int*x){effect(x);}',
 'incomplete early':'struct X; extern void effect(struct X*);void f(struct X*x){effect(x);}',
 'function ptr':'void f(void(*effect)(int),int x){effect(x);}',
 'indirect target':'extern void effect(int); void f(int x){ void (*g)(int)=effect;g(x);}',
 'masked bad':'extern void effect(int); void f(int x){if(0){effect(x,x);}}',
 'unsupported operand':'extern void effect(int);void f(int x){effect(++x);}',
 'shadow':'extern void effect(int);void f(int x){{int x=41;effect(x);}effect(x);}',
 'storage':'extern int effect(int); int f(int x){ return effect(x);}',
 'void general':'extern void effect(int); void f(int x){int y=x+1;effect(y);}',
 'local arena':'extern void effect(int);void f(int x){int y=x+1,*p=&y;effect(y);*p=x;effect(y);}',
 'argument order':'extern void effect(int,int,int,int);void f(int x,int y){effect(y,2,x,y);}',
 'noreturn':'_Noreturn void effect(int);void f(int x){effect(x);}',
 'returns-twice':'extern int effect(int) __attribute__((returns_twice));void f(int x){effect(x);}',
 'cold repeated':'extern void effect(int);void f(int x){effect(x);effect(0);effect(x);}',
 'wrong abi':'extern int __attribute__((ms_abi)) effect(int);void f(int x){effect(x);}',
 'bound outside function':'extern void effect(int);int object=effect(0);',
 'enum arg':'extern int effect(int);enum K{X=5};void f(void){effect(X);}',
 'no args':'extern void effect(void);void f(int x){if(x){effect();}}',
 'aggregate return':'struct S{int x;};extern struct S effect(int);void f(int x){effect(x);}',
 'shadowed label':'extern void effect(int);void f(int x){if(x)goto label;{effect(x);}label:;effect(x);}',
 'alias through parameter':'extern int effect(int*);int f(int *p){effect(p); return *p;}'
}
cases.update({
 'deep nested': 'int f(int a,int b){a=(((a^b)+13)*(b&17))^(a-b);return a;}',
 'narrow': 'struct X{unsigned char x; short y;};int f(struct X*p,int a){a=(p->x+p->y)^a;return a;}',
 'short circuit': 'int f(int*a,int x){if(x&&*a){x=x+1;}return x;}',
 'stack save': 'int f(int a,int b){int v[a];v[0]=2;if(a>b){return b+(a&2);}return v[0];}',
 'cleanup return': 'extern void close(int*); int f(int a,int b){int x __attribute__((cleanup(close)))=a; return b+x;}',
 'warning shift': 'int f(int a,int b){a=b<<32;return a;}',
 'pointer added': 'int*f(int*a,int b){a=a+b;return a;}',
 'tautology': 'int f(int a,int b){if((a+b)==(a+b)){return 1;}return 0;}',
 'different pointers': 'int f(int*p,long*q){if(p==q){return 1;}return 0;}',
 'late defined': 'extern int f(void); int g(int x){x=f()+x;return x;} int f(void){return 42;}',
 'empty trailing': 'extern int f(int); int g(int x){f(x+1,);return x;}',
 'divide zero': 'int f(int x){x=x/0;return x;}',
 'large constant': 'unsigned f(unsigned x){x=(x+0xabcdefU)^0x5A11U;return x;}',
 'enum shadow': 'enum{A=4};int f(int b){int A=b;if(A+3==4){return A;}return b;}',
 'address of local': 'extern void f(int*);int g(int a,int b){f(&a);a=(b^3)+a;return a;}',
 'inline return': 'inline int f(unsigned a,short b){return (a*b)^((a+b)>>2);}',
 'late member': 'struct S; int f(struct S*p,int x){return p->x+x;} struct S{int x;};',
 'UB unsigned compare': 'int f(unsigned a){if(a<0){return 7;}return 0;}',
 'unprototyped arg': 'extern void g();void f(int x,int b){g((x^b)+3);}',
})
policies=[('default',[]),('warnings',['-Wall','-Wextra']),('debug',['-g']),('PIC',['-fPIC']),('source',['--verify'])]
with (d/'policy.tsv').open('w',buffering=1) as out:
 wr=csv.writer(out,delimiter='\t');wr.writerow(['name','policy','code','same','source','lower'])
 for name,src in cases.items():
  file=d/'edge.c';file.write_text(src+'\n')
  for policy,args in policies:
   states=[]
   for mode in 'AB':
    obj=d/'edge.o';obj.unlink(missing_ok=True)
    env={**os.environ,**({'BUSTER_DIRECT_SOURCE_STATEMENTS':'1','BUSTER_DIRECT_RETURN_AUDIT':'1','BUSTER_DIRECT_OPERATOR_PROGRAM':'1','BUSTER_DIRECT_OPERATOR_CALLS':'1','BUSTER_SOURCE_ROOT_BODIES':'1','BUSTER_SOURCE_ROOT_BUDGET':'32','BUSTER_SOURCE_LINEAR_BODIES':'1','BUSTER_COMPOSE_SOURCE_STATEMENTS':'1','BUSTER_CONTROL_SOURCE_NATIVE':'1','BUSTER_CONTROL_EARLY_NATIVE':'1','BUSTER_CONTROL_EARLY_RELEASE':'1'} if mode=='B' else {})}
    p=subprocess.run([cc,*args,'--lanes','1','-c',file,'-o',obj],capture_output=True,env=env)
    lines=p.stderr.splitlines(keepends=True)
    states.append((p.returncode,p.stdout,b''.join(l for l in lines if not l.startswith((b'direct-statement\t',b'direct-statement-lower\t',b'direct-condition\t',b'direct-operator-return\t',b'source-body-statement-room\t'))),obj.read_bytes() if obj.exists() else None))
   if states[0]!=states[1]:
    label=''.join(c if c.isalnum() else '-' for c in name)+'-'+policy
    for tag,state in zip('AB',states):
     (d/(label+'-'+tag+'.stderr')).write_bytes(state[2])
     if state[3] is not None:(d/(label+'-'+tag+'.o')).write_bytes(state[3])
   wr.writerow((name,policy,states[-1][0],states[0]==states[1],sum(l.startswith(b'direct-statement\t') for l in lines),sum(l.startswith(b'direct-statement-lower\t') for l in lines)))
