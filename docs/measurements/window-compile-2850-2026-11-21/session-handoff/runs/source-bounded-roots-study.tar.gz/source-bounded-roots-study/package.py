from pathlib import Path
import csv,hashlib,io,json,subprocess,tarfile,collections,statistics
d=Path(__file__).resolve().parent;w=d.parent;repo=w/'source-bounded-roots';cc=repo/'build/compiler'
def digest(data):return hashlib.sha256(data).hexdigest()
def run(*args):return subprocess.check_output(args,cwd=repo)
head=run('git','rev-parse','HEAD').decode().strip();base=run('git','rev-parse','b352534f2').decode().strip();patch=run('git','format-patch','--stdout',base+'..'+head)
rows=lambda file:list(csv.DictReader(file.open(),delimiter='\t'))
results={}
for name,part,col in [('objects','optimized-run/objects.tsv','exact'),('Clang runtime','optimized-run/runtime.tsv','exact'),('CLI cases','policy.tsv','same')]:
 r=rows(d/part);results[name]=[len(r),sum(x[col]=='True' for x in r)]
for n in ['sqlite','main','lua','musl']:
 r=rows(d/'real'/(n+'.tsv'));results['frozen '+n]=[len(r),sum(all(a[k]=='1' for k in ['obj-equal','stderr-equal','stdout-equal']) and a['ref-exit']==a['local-exit'] for a in r)]
results['checker']= (d/'checker-status.txt').read_text().splitlines() if (d/'checker-status.txt').exists() else []
mode='bounded32';r=[x for x in rows(d/'optimized-run/objects.tsv') if x['mode']==mode];counts={x['unit']:{'graph':x['graph'],'programs':x['programs']} for x in r}
(d/'qualification.json').write_text(json.dumps({'head':head,'base':base,'compiler_sha256':digest(cc.read_bytes()),'results':results,'operator_counts':counts},indent=2)+'\n')
allfiles=[]
for p in d.rglob('*'):
 if not p.is_file() or (p.name.startswith('evidence.') or p.name=='archive.log') or any(x in ('optimized','__pycache__','debug-run') for x in p.relative_to(d).parts):continue
 if p.suffix in ('.tsv','.txt','.md','.c','.py','.sh','.json','.h','.status','.stdout','.stderr','.log') and p.stat().st_size<15*1024*1024:
  allfiles.append(p)
manifest={'head':head,'base':base,'patch_sha256':digest(patch),'files':{str(p.relative_to(d)):digest(p.read_bytes()) for p in sorted(allfiles)}}
def mem(t,name,b):
 item=tarfile.TarInfo(name);item.size=len(b);item.mtime=0;t.addfile(item,io.BytesIO(b))
with tarfile.open(d/'evidence.tar.xz','w:xz',preset=1) as tar:
 mem(tar,'manifest.json',(json.dumps(manifest,indent=2)+'\n').encode());mem(tar,'changes.mbox',patch)
 for p in sorted(allfiles):mem(tar,str(p.relative_to(d)),p.read_bytes())
with tarfile.open(d/'evidence.tar.xz') as tar:
 for p,h in manifest['files'].items():assert digest(tar.extractfile(p).read())==h,p
 assert digest(tar.extractfile('changes.mbox').read())==manifest['patch_sha256']
print(head,digest((d/'evidence.tar.xz').read_bytes()),len(allfiles),results)
