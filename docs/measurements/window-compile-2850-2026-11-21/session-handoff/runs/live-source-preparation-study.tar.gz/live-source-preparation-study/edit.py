from pathlib import Path
p=Path(__file__).resolve().parents[1]/'live-source-preparation/src/buster/compiler'
f=p/'c_check_comma_input.c';s=f.read_text()
s=s.replace('static void check_input_expression_commas_scalar(CheckInputReader* reader)\n{\n    const Parser* parser = reader->parser;','static void check_input_comma_scalar_range(const Parser* parser, const uint32_t* postorder, uint8_t* commas, uint32_t begin, uint32_t end)\n{').replace('for (uint32_t k = count; k-- > 0;)','for (uint32_t k = end; k-- > begin;)').replace('reader->postorder[k]','postorder[k]')
s=s.replace('static bool check_input_expression_commas_vector(CheckInputReader* reader)\n{\n    const Parser* parser = reader->parser;','static bool check_input_comma_vector_range(const Parser* parser, uint8_t* commas, uint32_t begin, uint32_t end)\n{').replace('for (uint32_t end = count; complete && end != 0;)','while (complete && end > begin)').replace('end > 64 ? end - 64 : 0','end - begin > 64 ? end - 64 : begin').replace('reader->expression_commas','commas')
at=s.index('static void check_input_expression_commas(CheckInputReader* reader)')
s=s[:at]+'''static void check_input_expression_commas_scalar(CheckInputReader* reader)
{
    check_input_comma_scalar_range(reader->parser, reader->postorder, reader->expression_commas, 0, reader->parser->tokens.count);
}

static bool check_input_expression_commas_vector(CheckInputReader* reader)
{
    return check_input_comma_vector_range(reader->parser, reader->expression_commas, 0, reader->parser->tokens.count);
}

'''+s[at:];f.write_text(s)
f=p/'c_check_input.c';s=f.read_text();a=s.index('static void check_input_declaration_starts(');b=s.index('// The first token of the declaration',a)
sub=s[a:b];sub=sub.replace('static void check_input_declaration_starts(const Parser* parser, CheckDeclarationStarts* blocks, uint32_t* stack)','''typedef struct CheckDeclarationCursor
{
    uint32_t next, boundaries, depth, previous;
} CheckDeclarationCursor;

static void check_input_declaration_range(const uint8_t* roles, uint32_t count, CheckDeclarationStarts* blocks,
                                          uint32_t* stack, CheckDeclarationCursor* cursor)''').replace('    const uint32_t count = parser->tokens.count;\n    const uint8_t* roles = parser->tree.roles;\n','').replace('uint32_t boundaries = 0','uint32_t boundaries = cursor->boundaries').replace('uint32_t depth = 0','uint32_t depth = cursor->depth').replace('uint32_t previous = 0','uint32_t previous = cursor->previous').replace('for (uint32_t token = 0;', 'for (uint32_t token = cursor->next;').replace('    // The sentinel belongs', '    *cursor = (CheckDeclarationCursor){ count, boundaries, depth, previous };\n    // The sentinel belongs')
sub+='''static void check_input_declaration_starts(const Parser* parser, CheckDeclarationStarts* blocks, uint32_t* stack)
{
    CheckDeclarationCursor cursor = { 0 };
    check_input_declaration_range(parser->tree.roles, parser->tokens.count, blocks, stack, &cursor);
}

''';s=s[:a]+sub+s[b:]
s=s.replace('#include "c_check_comma_input.c"\n','')
pos=s.index('typedef struct CheckLiveInput\n');s=s[:pos]+'#include "c_check_comma_input.c"\n\n'+s[pos:]
s=s.replace('    bool used, failed, keep_boundaries;', '''    bool used, failed, keep_boundaries, preparation;
    uint8_t* commas;
    CheckDeclarationStarts* declaration_starts;
    uint32_t* declaration_stack;
    CheckDeclarationCursor declaration_cursor;''')
s=s.replace('const ParseTokens* tokens, const ParseTree* tree, uint32_t begin, uint32_t end)\n{\n    CheckLiveInput* live', 'const ParseTokens* tokens, const ParseTree* tree, const uint32_t* order, uint32_t begin, uint32_t end)\n{\n    CheckLiveInput* live')
needle='    const CheckInputTokenCounts window = check_input_count_window';at=s.index(needle)
s=s[:at]+'''    if (live->preparation)
    {
        if (!live->commas)
        {
            live->commas = arena_push_array(&parser->live_rows, (uint64_t)tokens->capacity + 1, sizeof(uint8_t), 64);
            live->declaration_starts = arena_push_array(&parser->live_rows, (tokens->capacity >> 6) + 1, sizeof(CheckDeclarationStarts), 64);
            live->declaration_stack = BUSTER_ARENA_PUSH_ARRAY(&parser->live_rows, uint32_t, (uint64_t)tokens->capacity + 1);
        }
        if (!live->commas || !live->declaration_starts || !live->declaration_stack)
        {
            live->failed = true;
            return;
        }
        Parser view = { .tree = *tree };
        view.tokens.count = end;
        if (!check_input_comma_vector_range(&view, live->commas, begin, end))
            check_input_comma_scalar_range(&view, order, live->commas, begin, end);

        // A partial block belongs to the next publication. Its open-aggregate stack survives the boundary.
        check_input_declaration_range(tree->roles, end & ~63u, live->declaration_starts, live->declaration_stack, &live->declaration_cursor);
    }
'''+s[at:]
s=s.replace('reader.declaration_starts = declaration_starts ? arena_push_array', 'reader.declaration_starts = published && live->preparation ? live->declaration_starts : declaration_starts ? arena_push_array')
s=s.replace('    BUSTER_CHECK_INPUT_ARRAY(expression_commas, uint8_t);', '''    if (published && live->preparation) reader.expression_commas = live->commas;
    else { BUSTER_CHECK_INPUT_ARRAY(expression_commas, uint8_t); }''')
s=s.replace('        check_input_expression_commas(&reader);','''        if (!(published && live->preparation)) check_input_expression_commas(&reader);
        else if (getenv("BUSTER_LIVE_CHECKED_ORACLE") != NULL)
        {
            const uint64_t saved = scratch->length;
            uint8_t* oracle = BUSTER_ARENA_PUSH_ARRAY(scratch, uint8_t, (uint64_t)count + 1);
            if (!oracle) abort();
            check_input_comma_scalar_range(parser, reader.postorder, oracle, 0, count);
            if (memcmp(oracle, reader.expression_commas, count) != 0) abort();
            arena_pop_to(scratch, saved);
        }''')
s=s.replace('            if (reader.declaration_starts != 0)\n            {\n                // The column', '''            if (published && live->preparation)
            {
                const uint32_t prepared = live->declaration_cursor.next;
                check_input_declaration_range(parser->tree.roles, count, live->declaration_starts, live->declaration_stack, &live->declaration_cursor);
                if (getenv("BUSTER_LIVE_CHECKED_ORACLE") != NULL)
                {
                    const uint64_t saved = scratch->length;
                    uint32_t* stack = BUSTER_ARENA_PUSH_ARRAY(scratch, uint32_t, (uint64_t)count + 1);
                    CheckDeclarationStarts* oracle = BUSTER_ARENA_PUSH_ARRAY(scratch, CheckDeclarationStarts, (count >> 6) + 1);
                    if (!stack || !oracle) abort();
                    check_input_declaration_starts(parser, oracle, stack);
                    for (uint32_t k = 0; k <= (count >> 6); k += 1)
                        if (oracle[k].boundaries != reader.declaration_starts[k].boundaries || oracle[k].previous != reader.declaration_starts[k].previous) abort();
                    arena_pop_to(scratch, saved);
                }
                if (getenv("BUSTER_PARSE_LIVE_AUDIT") != NULL)
                    fprintf(stderr, "source-prepare\\tcommas=%u\\tdeclaration-rows=%u\\tbefore-eof=%u\\n", count, prepared, live->before_eof);
            }
            else if (reader.declaration_starts != 0)
            {
                // The column''')
f.write_text(s)
f=p/'c_parser.c';s=f.read_text().replace('void (*live_checked_range)(Parser*, Preprocessor*, const ParseTokens*, const ParseTree*, uint32_t, uint32_t);','void (*live_checked_range)(Parser*, Preprocessor*, const ParseTokens*, const ParseTree*, const uint32_t*, uint32_t, uint32_t);');f.write_text(s)
f=p/'c_parser_source_forest.c';s=f.read_text().replace('pp, &live->tokens, &live->tree, begin, end);','pp, &live->tokens, &live->tree, live->postorder, begin, end);');f.write_text(s)
f=p/'c_checker_driver.c';s=f.read_text().replace('.keep_boundaries = getenv("BUSTER_LIVE_RESOLVE_WINDOWS") != NULL','.keep_boundaries = getenv("BUSTER_LIVE_RESOLVE_WINDOWS") != NULL, .preparation = getenv("BUSTER_LIVE_PREPARE_DECLARATIONS") != NULL');f.write_text(s)
