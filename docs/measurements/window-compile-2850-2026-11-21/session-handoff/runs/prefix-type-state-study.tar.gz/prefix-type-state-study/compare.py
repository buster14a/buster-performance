from pathlib import Path
import csv,hashlib,json,os,re,shlex,subprocess,tempfile
d=Path(__file__).resolve().parent;w=d.parent;src=w/'live-native-references'
template=(w/'prefix-semantic-state-study/compare.py').read_text()
exec(template[template.index("prefix=(w/"):template.index('reader_names=')],globals())
exec(template[template.index('srcargs='):template.index('for u,cut')],globals())
typesptr=offsets('CheckInputReader',['types'])['types']
outptr=offsets('CheckInputReader',['output'])['output']
nptr=offsets('CheckInput',['token_count'])['token_count']
fields={}
for field,structure,groups in [
 ('types','TypeColumns',{1:'kind code flags alignment_log2',4:'base index',8:'extent size hash'}),
 ('parameters','TypeParameters',{4:'type'}),
 ('tags','TypeTags',{1:'packed ms_struct pack_log2 alignment_log2 lookup_log2',4:'type name member_begin member_count completion lookup'}),
 ('members','TypeMembers',{1:'alignment_log2 flags',4:'name type bit_width count_name',8:'offset'})]:
 widths={name:width for width,names in groups.items() for name in names.split()}
 loc=offsets(structure,['count',*widths])
 fields[field]=(offsets('TypeTable',[field])[field],loc['count'],[(name,loc[name],width) for name,width in widths.items()])
for u,cut in [('sqlite',401852),('main',955032)]:
 args=subprocess.check_output(['bash','-c',srcargs,'_',str(w),u]).decode().strip('\0').split('\0')
 with tempfile.TemporaryDirectory(dir=d) as tmp:
  t=Path(tmp);g=t/'observe.gdb'
  g.write_text(f"""set pagination off
set debuginfod enabled off
set confirm off
python
import gdb
fields={fields!r}
cut={cut}
seen=set()
def read(a,n):return gdb.selected_inferior().read_memory(a,n).tobytes()
def word(a,n):return int.from_bytes(read(a,n),'little')
def dump(stage,types):
 if stage in seen:return
 seen.add(stage)
 for field,(offset,number,columns) in fields.items():
  base=types+offset
  count=word(base+number,4)
  assert count<10000000,(field,count)
  for name,loc,width in columns:
   pointer=word(base+loc,8)
   if pointer:
    with open('{t}/'+stage+'-'+field+'-'+name,'wb') as f:f.write(read(pointer,count*width))
class Observe(gdb.Breakpoint):
 def stop(self):
  r=int(gdb.parse_and_eval('$rdi'));out=word(r+{outptr},8);cnt=word(out+{nptr},4);types=word(r+{typesptr},8)
  if 'controls' in self.location:
   if cnt==cut:dump('prefix',types)
   elif cnt>cut:dump('final',types)
  elif cnt>cut and int(gdb.parse_and_eval('$esi'))==cut:dump('resumed',types)
  return False
Observe("*'check_input_controls.buster_split'");Observe("*'check_input_resolve_window.buster_split'")
end
run
""")
  proc=subprocess.run(['gdb','--batch','-q','-x',g,'--args',src/'build/compiler','--lanes','1','-c',*args,'-o',t/'unit.o'],env=env,capture_output=True,timeout=220)
  (d/(u+'.log')).write_bytes(proc.stdout+proc.stderr)
  assert (t/'unit.o').read_bytes()==(w/'source-typed-study'/(u+'.o')).read_bytes()
  with (d/(u+'.tsv')).open('w') as out:
   wr=csv.writer(out,delimiter='\t');wr.writerow(['table','column','stage','prefix_rows','stage_rows','changed_prefix_rows','first_changes','prefix_sha256','overlap_sha256'])
   for f,(offset,number,columns) in fields.items():
    for n,_,width in columns:
     for stage in ['resumed','final']:
      p=t/('prefix-'+f+'-'+n);q=t/(stage+'-'+f+'-'+n)
      assert p.exists()==q.exists(),(f,n,stage)
      if not p.exists():continue
      a=p.read_bytes();b=q.read_bytes();stop=min(len(a),len(b))
      changes=[] if a[:stop]==b[:stop] else [i//width for i in range(0,stop,width) if a[i:i+width]!=b[i:i+width]]
      wr.writerow([f,n,stage,len(a)//width,len(b)//width,len(changes),','.join(map(str,changes[:15])),hashlib.sha256(a).hexdigest(),hashlib.sha256(b[:stop]).hexdigest()])
  assert len((d/(u+'.tsv')).read_text().splitlines())>=45
