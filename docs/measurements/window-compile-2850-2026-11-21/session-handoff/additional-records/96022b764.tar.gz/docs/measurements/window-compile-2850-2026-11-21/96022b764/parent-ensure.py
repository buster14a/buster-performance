from pathlib import Path
import fcntl,hashlib,shutil,subprocess
D=Path(__file__).resolve().parent;W=D.parent;tree=W/'source-counted-parent';binary=tree/'build/compiler'
with (D/'build.lock').open('w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 if not (D/'identity.tsv').exists():
  expected='b352534f202b8a739923cd8b5c8953f773f6a9e1'
  assert subprocess.check_output(['git','-C',tree,'rev-parse','HEAD'],text=True).strip()==expected
  with (D/'build.log').open('w') as log:subprocess.run([tree/'build.sh','--config','Develop','--target','compiler','--jobs','1'],cwd=tree,stdout=log,stderr=subprocess.STDOUT,check=True)
  shutil.copy(W/'body-action-rows/build/predefines.h',tree/'build/predefines.h')
  (D/'identity.tsv').write_text(expected+'\t'+hashlib.sha256(binary.read_bytes()).hexdigest()+'\tDevelop\n')
print(binary)
