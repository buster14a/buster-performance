from common import *
import csv,hashlib,json,shutil,subprocess,tarfile
tree=CC.parent.parent
def git(*a):return subprocess.check_output(['git','-C',tree,*a])
base=git('rev-parse','HEAD^').decode().strip();rev=git('rev-parse','HEAD').decode().strip();o=W/'perf/docs/measurements/window-compile-2850-2026-11-21'/rev[:9];o.mkdir(exist_ok=True)
(o/'implementation.patch').write_bytes(git('diff','--binary',base,rev))
for p in ('common.py','locations.py','qualify.py','suites.py','stage.py','profile.py','mutation.py','census.py','package.py','per-file.sh','pair-output.py','build.log'):
 if (D/p).exists():shutil.copy(D/p,o/p)
for p in ('build.log','identity.tsv','ensure.py'):
 if (W/'source-counted-parent-study'/p).exists():shutil.copy(W/'source-counted-parent-study'/p,o/('parent-'+p))
parent_status=W/'source-counted-parent-study/checker/status.tsv'
if parent_status.exists() and (D/'suites').exists():
 shutil.copy(parent_status,D/'suites/parent-checker-status.tsv')
 shutil.copy(W/'source-refused-body-study/optimized-stack.txt',D/'suites/refused-program-stack.txt')
for k in ('oracle','stage','suites','mutation','census','profile','per-file'):
 q=D/k
 if not q.exists():continue
 dest=o/k;dest.mkdir(exist_ok=True)
 for f in q.iterdir():
  if f.suffix in ['.tsv','.json']:shutil.copy(f,dest/f.name)
 with tarfile.open(dest/'raw.tar.gz','w:gz') as t:
  for f in sorted(q.rglob('*')):
   if f.is_file() and f.suffix not in ['.o','.exe']:t.add(f,arcname=f.relative_to(q))
with (o/'builds.tsv').open('w') as f:t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow(['mode','revision','sha256']);t.writerows([[k,r,hashlib.sha256(p.read_bytes()).hexdigest()] for k,r,p in [('prior-Develop',base,PRIOR),('new-Develop',rev,CC)]])
def tsv(f):return list(csv.DictReader(f.open(),delimiter='\t')) if f.exists() else []
q=D/'oracle';bad=json.loads((q/'failures.json').read_text());hist=json.loads((q/'historical.json').read_text());obs=tsv(q/'comparisons.tsv');fp=tsv(q/'fingerprints.tsv');paired=tsv(D/'stage/paired.tsv');suites=tsv(D/'suites/status.tsv');per=[r for f in (D/'per-file').glob('*.tsv') for r in tsv(f)];mut=tsv(D/'mutation/results.tsv')
text=['# Record counted pointer members while defining their type','',f'The b352 source-native compiler rescanned all declared members whenever it finished checking one function. On a preliminary SQLite instruction trace, just two instructions in that traversal accounted for 1,259 of 38,624 samples, approximately 52.46 million instructions per compile. In `{rev}`, the type producer saves the first member index of a counted_by or counted_by_or_null pointer. A local check can consult that declaration fact directly. Type-table copies retain it. A speculative rollback clears the index only when its declaration is withdrawn. Existing use-site diagnostics still use the complete checked operands and source positions. [Implementation and type-view regression](implementation.patch), [both optimized compiler identities](builds.tsv) and [parent build recipe](parent-ensure.py).','',f'For SQLite, Buster, the driver counted-by fixture and directed diagnostic fixtures, {len(obs):,} complete process observations and {len(fp):,} checked graph fingerprints recorded {len(bad)} differences against the matching parent mode. {sum(r[-1] for r in hist)}/{len(hist)} historical full ELF comparisons matched. [Native and diagnostic comparisons](oracle/comparisons.tsv), [Clang source diagnostics](oracle/clang.tsv), [field fingerprints](oracle/fingerprints.tsv), [existing ordinary/source differences](oracle/previous.json) and [complete sources and captured outputs](oracle/raw.tar.gz).','','| Input | Scope | Paired wall | Faster wall rounds | Paired instructions | Paired cycles | Faster counter rounds |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for n in args:
 for sc in ('native','ordinary','functions'):
  ps={v['metric']:v for v in paired if v['input']==n and v['scope']==sc}
  if len(ps)!=3:continue
  a,ins,cy=ps['ns'],ps['instructions'],ps['cycles'];text.append(f"| {n} | {sc} | {float(a['median-delta'])/1e6:+.3f} ms | {a['faster']}/{a['rounds']} | {float(ins['median-delta']):+,.0f} | {float(cy['median-delta']):+,.0f} | {cy['faster']}/{cy['rounds']} |")
text+=['','Paired local Ryzen 9 7940HS trials used exact Develop builds of the parent and candidate under the same flags. Four balanced production arms emitted the identical expected native object for ordinary and source-native modes. Function-only trials stopped at the same source-local checker boundary. [Paired results](stage/paired.tsv), [raw observations and ELF hashes](stage/samples.tsv) and [counter streams](stage/raw.tar.gz).']
if suites:text+=['',f"Regression suite exit statuses include {sum(r['exit']!='0' for r in suites)} failing commands out of {len(suites)}. [Suite statuses](suites/status.tsv) and [complete suite output](suites/raw.tar.gz). Source parent b352 fails the same refused-program shard on a null type table. [Independent parent control](suites/parent-checker-status.tsv)."]
if per:text+=['',f"Across {len(per):,} SQLite, Buster, Lua and musl file/policy combinations, {sum(r['same']!='1' for r in per)} parent-versus-candidate native status, diagnostic or ELF comparisons differed. [Corpus tables and streams](per-file/raw.tar.gz)."]
if mut:text+=['',f"The debugger observed the production declaration fact on parsed counted-pointer input. With the recorded member the ordinary compiler issued {mut[0]['cannot-use']} read and {mut[0]['cannot-assign']} assignment errors. Zeroing only the declaration fact before the checker ran yielded {mut[-1]['cannot-use']} read and {mut[-1]['cannot-assign']} assignment errors. [Guarded diagnostic outcomes](mutation/results.tsv) and [sources, layouts and debugger traces](mutation/raw.tar.gz)."]
if (o/'profile/config.json').exists():text+=['','Fresh parent and candidate profiles used six ordinary source-native object invocations per workload and arm, with one sample per 250,007 user instructions. [SQLite symbol differences](profile/sqlite.deltas.tsv), [parent SQLite sites](profile/sqlite.control.sites.tsv), [candidate SQLite sites](profile/sqlite.producer.sites.tsv), [Buster symbol differences](profile/main.deltas.tsv) and [raw traces](profile/raw.tar.gz).']
if (o/'census/counts.tsv').exists():
 counts=tsv(D/'census/counts.tsv');text+=['','A debugger inspected the live declaration index and member count at every real check_graph_run entry. The number of rows the previous loop visits follows from the first matching member index, or every non-sentinel member when there is no match. [Exact per-process member counts](census/counts.tsv) and [ELF checks and debugger receipts](census/raw.tar.gz).']
if (D/'oracle/clang-locations.tsv').exists():
 locs=tsv(D/'oracle/clang-locations.tsv');text+=['',f'The per-source Clang check found matching ordered diagnostic locations and severities in {sum(r["same-locations-and-severities"]=="1" for r in locs)} of {len(locs)} comparisons. Exact messages are recorded separately. [Clang event comparisons](oracle/clang-locations.tsv).']
text+=['','The original source-native compiler and this fact-only change both lost 18 of 19 errors and 36 of 38 notes from the existing counted-pointer incomplete-pointee initializer driver fixture when function graphs retired. The ordinary compiler matches all 57 Clang events. The separate source-admission correction has its own [diagnostic and ELF receipts](../819db8940/README.md).', '', 'In the fresh process instruction sample, check_graph_counted_uses itself had 1,301 parent and one candidate sample for SQLite and 9,792 parent and one candidate sample for Buster. The recorded period of 250,007 user instructions and six complete compiles per arm imply 54.21 million and 408.01 million instructions per compilation at this site in the parent.']
(o/'README.md').write_text('\n'.join(text)+'\n');print(o)
