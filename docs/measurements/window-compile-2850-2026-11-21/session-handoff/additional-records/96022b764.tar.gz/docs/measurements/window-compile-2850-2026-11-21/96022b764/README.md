# Record counted pointer members while defining their type

The b352 source-native compiler rescanned all declared members whenever it finished checking one function. On a preliminary SQLite instruction trace, just two instructions in that traversal accounted for 1,259 of 38,624 samples, approximately 52.46 million instructions per compile. In `96022b76451b6899df773673338a7f295712eef0`, the type producer saves the first member index of a counted_by or counted_by_or_null pointer. A local check can consult that declaration fact directly. Type-table copies retain it. A speculative rollback clears the index only when its declaration is withdrawn. Existing use-site diagnostics still use the complete checked operands and source positions. [Implementation and type-view regression](implementation.patch), [both optimized compiler identities](builds.tsv) and [parent build recipe](parent-ensure.py).

For SQLite, Buster, the driver counted-by fixture and directed diagnostic fixtures, 376 complete process observations and 104 checked graph fingerprints recorded 0 differences against the matching parent mode. 4/4 historical full ELF comparisons matched. [Native and diagnostic comparisons](oracle/comparisons.tsv), [Clang source diagnostics](oracle/clang.tsv), [field fingerprints](oracle/fingerprints.tsv), [existing ordinary/source differences](oracle/previous.json) and [complete sources and captured outputs](oracle/raw.tar.gz).

| Input | Scope | Paired wall | Faster wall rounds | Paired instructions | Paired cycles | Faster counter rounds |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| sqlite | native | -3.928 ms | 5/8 | -51,939,472 | -3,754,090 | 3/4 |
| sqlite | ordinary | -7.324 ms | 5/8 | +964,513 | -8,577,675 | 3/4 |
| sqlite | functions | -2.358 ms | 3/5 | -51,604,263 | +2,274,612 | 1/3 |
| main | native | -18.016 ms | 5/8 | -407,594,814 | -116,102,122 | 3/4 |
| main | ordinary | +19.842 ms | 3/8 | +4,628,314 | +150,239,463 | 1/4 |
| main | functions | -26.646 ms | 5/5 | -410,645,050 | -48,508,960 | 3/3 |

Paired local Ryzen 9 7940HS trials used exact Develop builds of the parent and candidate under the same flags. Four balanced production arms emitted the identical expected native object for ordinary and source-native modes. Function-only trials stopped at the same source-local checker boundary. [Paired results](stage/paired.tsv), [raw observations and ELF hashes](stage/samples.tsv) and [counter streams](stage/raw.tar.gz).

Regression suite exit statuses include 1 failing commands out of 9. [Suite statuses](suites/status.tsv) and [complete suite output](suites/raw.tar.gz). Source parent b352 fails the same refused-program shard on a null type table. [Independent parent control](suites/parent-checker-status.tsv).

Across 4,116 SQLite, Buster, Lua and musl file/policy combinations, 0 parent-versus-candidate native status, diagnostic or ELF comparisons differed. [Corpus tables and streams](per-file/raw.tar.gz).

The debugger observed the production declaration fact on parsed counted-pointer input. With the recorded member the ordinary compiler issued 4 read and 1 assignment errors. Zeroing only the declaration fact before the checker ran yielded 0 read and 0 assignment errors. [Guarded diagnostic outcomes](mutation/results.tsv) and [sources, layouts and debugger traces](mutation/raw.tar.gz).

Fresh parent and candidate profiles used six ordinary source-native object invocations per workload and arm, with one sample per 250,007 user instructions. [SQLite symbol differences](profile/sqlite.deltas.tsv), [parent SQLite sites](profile/sqlite.control.sites.tsv), [candidate SQLite sites](profile/sqlite.producer.sites.tsv), [Buster symbol differences](profile/main.deltas.tsv) and [raw traces](profile/raw.tar.gz).

A debugger inspected the live declaration index and member count at every real check_graph_run entry. The number of rows the previous loop visits follows from the first matching member index, or every non-sentinel member when there is no match. [Exact per-process member counts](census/counts.tsv) and [ELF checks and debugger receipts](census/raw.tar.gz).

The per-source Clang check found matching ordered diagnostic locations and severities in 43 of 44 comparisons. Exact messages are recorded separately. [Clang event comparisons](oracle/clang-locations.tsv).

The original source-native compiler and this fact-only change both lost 18 of 19 errors and 36 of 38 notes from the existing counted-pointer incomplete-pointee initializer driver fixture when function graphs retired. The ordinary compiler matches all 57 Clang events. The separate source-admission correction has its own [diagnostic and ELF receipts](../819db8940/README.md).

In the fresh process instruction sample, check_graph_counted_uses itself had 1,301 parent and one candidate sample for SQLite and 9,792 parent and one candidate sample for Buster. The recorded period of 250,007 user instructions and six complete compiles per arm imply 54.21 million and 408.01 million instructions per compilation at this site in the parent.
