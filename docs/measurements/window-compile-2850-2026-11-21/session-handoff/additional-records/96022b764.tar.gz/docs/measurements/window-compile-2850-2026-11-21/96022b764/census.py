from common import *
import csv,gzip,hashlib,re,subprocess
out=D/'census';out.mkdir(exist_ok=True);layout=(D/'mutation/TypeTable-layout.txt').read_text()
m=re.search(r'^\s*(\d+) \|\s+uint32_t first_counted_pointer\s*\n\s*(\d+) \|\s+uint32_t count\s*$',layout,re.M);assert m,layout[:150];idx,number=map(int,m.groups())
syms=subprocess.check_output(['nm','-an',CC],text=True);sym=re.findall(r'^([0-9a-f]+) [tT] check_graph_run(?:\.buster_split)?$',syms,re.M);assert len(sym)==1,sym
with (out/'counts.tsv').open('w',buffering=1) as f:
 t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow(['input','mode','checker-calls','tables-with-counted-pointer','previous-member-rows-visited','ELF','matches-reference'])
 for name,flags in args.items():
  for label,e in [('ordinary',{}),('source',native)]:
   g=out/(name+'.'+label+'.gdb');o=out/(name+'.'+label+'.o');g.write_text('set pagination off\nset confirm off\nset debuginfod enabled off\nset print thread-events off\nset $calls=0\nset $hits=0\nset $rows=(unsigned long long)0\nbreak *0x'+sym[0]+'\ncommands\nsilent\nset $calls=$calls+1\nset $first=*(unsigned int*)($rdi+'+str(idx)+')\nset $count=*(unsigned int*)($rdi+'+str(number)+')\nif $first\nset $hits=$hits+1\nset $rows=$rows+$first\nelse\nset $rows=$rows+$count-1\nend\ncontinue\nend\nrun\nprintf "SOURCE_COUNTED calls=%u hits=%u rows=%llu\\n",$calls,$hits,$rows\n')
   r=subprocess.run(['gdb','-q','--batch','-x',g,'--args',CC,'--lanes','1','-c',*flags,'-o',o],env=env|e,cwd=ROOT,capture_output=True,timeout=300);stem=f'{name}.{label}'
   for k,b in [('stdout',r.stdout),('stderr',r.stderr)]:(out/(stem+'.'+k+'.gz')).write_bytes(gzip.compress(b,mtime=0))
   vals=re.findall(rb'SOURCE_COUNTED calls=(\d+) hits=(\d+) rows=(\d+)',r.stdout);assert len(vals)==1,stem
   h=hashlib.sha256(o.read_bytes()).hexdigest();expected=hashlib.sha256((W/'source-typed-study'/(name+'.o')).read_bytes()).hexdigest();v=tuple(int(x) for x in vals[0]);t.writerow([name,label,*v,h,int(h==expected)]);print(stem,v,flush=True);assert h==expected and v[0]>0
