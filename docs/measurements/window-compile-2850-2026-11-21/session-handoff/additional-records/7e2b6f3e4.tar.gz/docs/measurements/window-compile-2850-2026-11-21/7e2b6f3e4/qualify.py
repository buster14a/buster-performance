from pathlib import Path
import csv,gzip,hashlib,os,subprocess
d=Path(__file__).resolve().parent;w=d.parent;tree=w/'source-refused-body';ref=w/'native-source-facts-study/compiler';cc=d/'compiler';clang='/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang'
e={k:v for k,v in os.environ.items() if not k.startswith(('BUSTER_CONTROL_','BUSTER_SOURCE_','BUSTER_BODY_'))};e['PATH']=str(Path(clang).parent)+':'+e['PATH']
with (d/'results.tsv').open('w',buffering=1) as ff:
 t=csv.writer(ff,delimiter='\t',lineterminator='\n');t.writerow(('mode','shard','exit','stdout','stderr'))
 for mode,b,shards in [('prior-scout',ref,(6,)),('corrected-scout',cc,(6,7,8))]:
  for i in shards:
   r=subprocess.run([b,'test-checker','--seed','2850','--part',f'{i}/8'],env=e,cwd=tree,capture_output=True,timeout=400)
   for key,raw in [('stdout',r.stdout),('stderr',r.stderr)]:(d/(mode+'.'+str(i)+'.'+key+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
   t.writerow([mode,i,r.returncode,hashlib.sha256(r.stdout).hexdigest(),hashlib.sha256(r.stderr).hexdigest()]);print(mode,i,r.returncode,flush=True)
o=w/'perf/docs/measurements/window-compile-2850-2026-11-21'/subprocess.check_output(['git','-C',tree,'rev-parse','--short=9','HEAD'],text=True).strip();o.mkdir(exist_ok=True)
import shutil
for p in [*d.glob('*.gz'),d/'results.tsv',d/'iterate.py',d/'qualify.py',d/'optimized-stack.txt']:shutil.copy(p,o/p.name)
(o/'implementation.patch').write_bytes(subprocess.check_output(['git','-C',tree,'diff','--binary','HEAD^','HEAD']))
rows=list(csv.DictReader((d/'results.tsv').open(),delimiter='\t'));(o/'README.md').write_text(f'''# Refuse malformed source-native lowering inputs

The existing refused-program checker fixture exercises each lowering path with an invalid program lacking its type table. On the source-native parent its cached ABI preparation dereferenced the null table. The existing validation now returns the invalid status before the ABI cache reads it. The optimized source projection at 8681f5f9d first faulted at c_check_program_lower.c:19742. Matched same-flag O0-checker scouts against the existing fixture reported exit {rows[0]['exit']} for the parent and {rows[1]['exit']} for the corrected shard. [Optimized crash frames](optimized-stack.txt), [patch](implementation.patch), [shard results](results.tsv), [parent stderr](prior-scout.6.stderr.gz), [corrected stdout](corrected-scout.6.stdout.gz) and [compiler construction](iterate.py).
''')
