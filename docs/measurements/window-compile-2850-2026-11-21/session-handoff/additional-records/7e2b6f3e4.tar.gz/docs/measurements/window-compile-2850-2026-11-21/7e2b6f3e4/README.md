# Refuse malformed source-native lowering inputs

The existing refused-program checker fixture exercises each lowering path with an invalid program lacking its type table. On the source-native parent its cached ABI preparation dereferenced the null table. The existing validation now returns the invalid status before the ABI cache reads it. The optimized source projection at 8681f5f9d first faulted at c_check_program_lower.c:19742. Matched same-flag O0-checker scouts against the existing fixture reported exit -11 for the parent and -11 for the corrected shard. [Optimized crash frames](optimized-stack.txt), [patch](implementation.patch), [shard results](results.tsv), [parent stderr](prior-scout.6.stderr.gz), [corrected stdout](corrected-scout.6.stdout.gz) and [compiler construction](iterate.py).

The corrected scout progressed past the refused-program fixture and faulted later in the sparse-switch fixture on an absent source input. [Second crash frames](intermediate-stack.txt).
