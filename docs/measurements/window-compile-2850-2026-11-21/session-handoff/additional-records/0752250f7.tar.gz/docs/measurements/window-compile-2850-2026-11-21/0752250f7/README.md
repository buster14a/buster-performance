# Prune vector and atomic reserve planning using checked operand types

A translation unit containing any atomic or transport-vector type formerly sent every node to the full scalar reserve calculation. An unwrapped, non-atomic and non-vector result plus its checked conversions need only ordinary builtin counts. For updates and subscripts the left type must also be plain. Vector builtins and other types continue through the scalar rule. [Implementation](implementation.patch).

The process-level GDB oracle measured all seven returns of the reserve planner for 6,013 complete calls across 62 input/mode pairs. Parent and candidate counts matched in 62 pairs. Redirecting just this function to its unchanged scalar twin yielded the same seven numbers and full ELF in 62 pairs. [Numerical outcomes](counts/outcomes.tsv), [all tuples](counts/tuples.tsv), [source/diagnostic and native output checks](oracle/outcomes.tsv), [executable probes](oracle/executions.tsv) and [checker shards](suites/status.tsv).

The ordinary and source-local mode compared 488 complete native/source outcomes against parent 96022b764, with 0 changed process results. The Clang cases and matching typed fingerprints are recorded independently. [Clang cases](oracle/clang.tsv), [fingerprints](oracle/fingerprints.tsv).

| Input | Mode | Metric | Median within-round change | Rounds lower |
| --- | --- | --- | ---: | ---: |
| sqlite | native | ns | -4,600,560 | 4/8 |
| sqlite | ordinary | ns | 781,154 | 4/8 |
| sqlite | native | instructions | 126,201 | 0/4 |
| sqlite | native | cycles | 45,506,438 | 1/4 |
| sqlite | ordinary | instructions | 60,554 | 0/4 |
| sqlite | ordinary | cycles | 38,657,715 | 1/4 |
| main | native | ns | -49,761,660 | 5/8 |
| main | ordinary | ns | -53,297,386 | 6/8 |
| main | native | instructions | -310,846,120 | 4/4 |
| main | native | cycles | -136,715,120 | 3/4 |
| main | ordinary | instructions | -309,441,432 | 4/4 |
| main | ordinary | cycles | 18,370,594 | 2/4 |
