from common import *
import csv,json,shutil,subprocess,sys,tarfile
subprocess.run([sys.executable,W/'source-counted-initializer-guard-study/focused.py'],check=True)
subprocess.run([sys.executable,D/'numerical.py','--smoke'],check=True)
for k in ('stage.py','qualify.py','numerical.py','suites.py','profile.py'):subprocess.run([sys.executable,D/k],check=True)
subprocess.run(['bash',D/'per-file.sh'],check=True)
tree=CC.parent.parent;rev=subprocess.check_output(['git','-C',tree,'rev-parse','HEAD'],text=True).strip();dest=W/'perf/docs/measurements/window-compile-2850-2026-11-21'/rev[:9];dest.mkdir(exist_ok=True)
for f in [*D.glob('*.py'),D/'per-file.sh',D/'build.log']:shutil.copy(f,dest/f.name)
for k in ('stage','profile','oracle','suites','counts','per-file'):
 p=D/k;o=dest/k;o.mkdir(exist_ok=True)
 for f in p.iterdir():
  if f.suffix in ['.tsv','.json']:shutil.copy(f,o/f.name)
 with tarfile.open(o/'raw.tar.gz','w:gz') as t:
  for f in p.iterdir():
   if f.suffix not in ['.tsv','.json','.o'] and f.name!='app':t.add(f,arcname=f.name)
import hashlib
with (dest/'builds.tsv').open('w') as f:
 f.write('mode\trevision\tcompiler-sha256\tcheckout\n')
 for mode,cc in [('control',PRIOR),('candidate',CC)]:
  commit=subprocess.check_output(['git','-C',cc.parent.parent,'rev-parse','HEAD'],text=True).strip()
  f.write(f'{mode}\t{commit}\t{hashlib.sha256(cc.read_bytes()).hexdigest()}\t{cc.parent.parent}\n')
(dest/'implementation.patch').write_bytes(subprocess.check_output(['git','-C',tree,'diff','HEAD^','HEAD']))
read=lambda k:list(csv.DictReader((D/k).open(),delimiter='\t'))
pairs=read('stage/paired.tsv');outs=read('counts/outcomes.tsv');qq=read('oracle/outcomes.tsv');es=read('oracle/executions.tsv')
rows=['# Prune vector and atomic reserve planning using checked operand types','', 'A translation unit containing any atomic or transport-vector type formerly sent every node to the full scalar reserve calculation. An unwrapped, non-atomic and non-vector result plus its checked conversions need only ordinary builtin counts. For updates and subscripts the left type must also be plain. Vector builtins and other types continue through the scalar rule. [Implementation](implementation.patch).','',f"The process-level GDB oracle measured all seven returns of the reserve planner for {sum(int(r['call-count']) for r in outs):,} complete calls across {len(outs)} input/mode pairs. Parent and candidate counts matched in {sum(r['equal-parent']=='1' for r in outs)} pairs. Redirecting just this function to its unchanged scalar twin yielded the same seven numbers and full ELF in {sum(r['equal-scalar']==r['same-ELF']=='1' for r in outs)} pairs. [Numerical outcomes](counts/outcomes.tsv), [all tuples](counts/tuples.tsv), [source/diagnostic and native output checks](oracle/outcomes.tsv), [executable probes](oracle/executions.tsv) and [checker shards](suites/status.tsv).",'',f"The ordinary and source-local mode compared {len(qq)} complete native/source outcomes against parent 96022b764, with {sum(r['same-prior']!='1' for r in qq)} changed process results. The Clang cases and matching typed fingerprints are recorded independently. [Clang cases](oracle/clang.tsv), [fingerprints](oracle/fingerprints.tsv).",'','| Input | Mode | Metric | Median within-round change | Rounds lower |','| --- | --- | --- | ---: | ---: |']
for r in pairs:rows.append(f"| {r['input']} | {r['scope']} | {r['metric']} | {float(r['median-delta']):,.0f} | {r['faster']}/{r['rounds']} |")
(dest/'README.md').write_text('\n'.join(rows)+'\n');print(dest)
