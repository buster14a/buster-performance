# Use validated source operators for the body lowering reserve

Experimental revision `994a8eec63a9ae43866a10a33ff450c8ba93de31` compared with `1b42a4d3dae381e9e96d93e588fb50770e32d8bc` on the same frozen inputs. Complete graph validation records the unary builtins alongside its overflow effects, library builtins and atomics. The lowering can use these numerical capacities directly when the producer has recorded the entire graph and both its vector builtins and the translation unit’s vector and atomic types are absent. [Implementation](implementation.patch).

The complete scalar reserve and both source revisions matched on 6,013 complete invocations, with 0 differing input results or objects. The candidate matched its parent on 488 of 488 native and diagnostic observations and 4,116 of 4,116 file-policy comparisons. The new checked-operator fixture adds 31 successful checks to shard 1 (305,454 total). The source-local baseline’s inherited checker shard 6 fault is recorded separately. [All reserve tuples](counts/tuples.tsv), [process matrix](oracle/outcomes.tsv), [corpus outputs](per-file), [checker shard outcomes](suites/status.tsv).

A debugger changes exactly one validated atomic-builtin count while lowering the real SQLite or Buster compilation. SQLite consumes the perturbation. Suppressing the checked marker restores the independent result, and Buster with transport vectors uses its full typed rule. The debugger restores the original stream before continuing, and all four configurations produce their original ELF. [Twelve dataflow observations](validated-operator-dataflow/outcomes.tsv).

| Workload | Path | Counter | Paired change | Lower |
| --- | --- | --- | ---: | ---: |
| sqlite | native | ns | -6,893,274 | 5/8 |
| sqlite | ordinary | ns | 1,315,226 | 4/8 |
| sqlite | native | instructions | -1,004,332 | 4/4 |
| sqlite | native | cycles | 3,894,155 | 2/4 |
| sqlite | ordinary | instructions | -1,177,700 | 4/4 |
| sqlite | ordinary | cycles | 15,762,046 | 2/4 |
| main | native | ns | 2,262,266 | 4/8 |
| main | ordinary | ns | 21,878,590 | 4/8 |
| main | native | instructions | -163,975 | 4/4 |
| main | native | cycles | 56,680,616 | 2/4 |
| main | ordinary | instructions | -500,324 | 4/4 |
| main | ordinary | cycles | 47,077,830 | 1/4 |

[Every local wall and PMU sample](stage/samples.tsv), [sampled instruction sites](profile), [observed checked operand populations](operand-eligibility/results.tsv).
