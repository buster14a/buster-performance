from pathlib import Path
import sys
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parent/'source-reserve-kind-census-study'))
from common import CC,ROOT,args,env,native
import csv,gzip,hashlib,json,re,shlex,subprocess
tree=CC.parent.parent;db=json.loads((tree/'build/cmake/native/compile_commands.json').read_text());e=next(x for x in db if x['file'].endswith('main_unit_checker.c') and 'Develop' in x['output']);av=shlex.split(e['command']);blocks=subprocess.run([av[0],*[a for a in av if a.startswith(('-I','-D','-march'))],'-fsyntax-only','-Xclang','-fdump-record-layouts',e['file']],cwd=e['directory'],capture_output=True,check=True).stdout.decode().split('*** Dumping AST Record Layout')
def block(k):return next(b for b in blocks if re.search(r'^\s*0 \| struct '+k+r'\s*$',b,re.M))
def off(t,m):return int(re.search(r'^\s*(\d+) \|   [^ \n][^\n]*?\b'+m+r'\s*$',block(t),re.M)[1])
def sz(t):return int(re.search(r'\[sizeof=(\d+)',block(t))[1])
cfg={t+'.'+k:off(t,k) for t,ff in [('CheckProgram',['input','stream','types']),('CheckInput',['graph']),('CheckGraph',['count','recorded_ready','recorded_nodes','ops']),('CheckStream',['value_types','conversions','graph']),('TypeColumns',['kind','count'])] for k in ff};syms=subprocess.check_output(['nm','-an',CC],text=True);cfg['entry']=int(re.search(r'^([0-9a-f]+) [tT] check_lower_node_counts(?:\.buster_split)?$',syms,re.M)[1],16);cfg['stride']=sz('CheckNodeConversions');cfg['conv']=sz('CheckConversion')
src=(tree/'src/buster/compiler/c_check_actions.c').read_text();en=re.search(r'typedef enum CheckOp\s*\{(.*?)\}\s*CheckOp',src,re.S)[1];en=re.sub(r'//[^\n]*|/\*.*?\*/','',en,flags=re.S);assert '=' not in en
cfg['ops']={re.match(r'\s*(CHECK_OP_\w+)',s)[1]:i for i,s in enumerate(en.split(',')) if s.strip()}; cols=['nodes','recorded-and-stream-mask','exceptional-kinds','blocks','exceptional-blocks','blocks-below-first','vector-builtin-blocks','first-exceptional-index','max-used-index','distinct-type-ids']
with (D/'results.tsv').open('w') as f:
 t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow(['input','scope','sequence',*cols])
 for n in ('sqlite','main'):
  for mode,ov in [('ordinary',{}),('source',native)]:
   pre=D/(n+'.'+mode);scr=pre.with_suffix('.'+mode+'.gdb');scr.write_text(f'set pagination off\nset debuginfod enabled off\npython cfg={cfg!r}\nsource {D}/observe.py\nrun\n');obj=Path(str(pre)+'.o');x=subprocess.run(['gdb','-q','-nx','--batch','-x',scr,'--args',CC,'--lanes','1','-c',*args[n],'-o',obj],env=env|ov,cwd=ROOT,capture_output=True,timeout=500)
   for k,raw in [('stdout',x.stdout),('stderr',x.stderr)]:Path(str(pre)+'.'+k+'.gz').write_bytes(gzip.compress(raw,mtime=0))
   rows=[tuple(int(v) for v in s.split()) for s in re.findall(rb'^BODY (.*)$',x.stdout,re.M)];assert len(rows)==({'sqlite':2675,'main':3108}[n] if mode=='source' else 1),(n,mode,len(rows),x.stderr[-400:],x.stdout[-300:]);assert obj.exists(),obj
   t.writerows(([n,mode,i,*r] for i,r in enumerate(rows)));f.flush();print(n,mode,'calls',len(rows),'recorded',sum(r[1]&1 for r in rows),'checked-stream-graph',sum((r[1]&2)!=0 for r in rows),'exceptional',sum(r[2] for r in rows),'blocks',sum(r[3] for r in rows),'exceptional-blocks',sum(r[4] for r in rows),'blocks-below-first',sum(r[5] for r in rows),'vector-builtin-blocks',sum(r[6] for r in rows),'object',hashlib.sha256(obj.read_bytes()).hexdigest(),flush=True);obj.unlink()
