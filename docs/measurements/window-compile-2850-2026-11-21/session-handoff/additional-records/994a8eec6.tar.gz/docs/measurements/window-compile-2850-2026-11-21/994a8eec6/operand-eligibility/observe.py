from collections import Counter
import gdb
def read(address,n):return bytes(gdb.selected_inferior().read_memory(address,n))
def load(address,n=4):return int.from_bytes(read(address,n),'little')
def field(address,key,n=4):return load(address+cfg[key],n)
def words(address,n):return memoryview(read(address,4*n)).cast('I') if n else []
class Entry(gdb.Breakpoint):
 def stop(self):
  p=int(gdb.parse_and_eval('$rsi'));g=field(p,'CheckProgram.input',8)+cfg['CheckInput.graph'];s=field(p,'CheckProgram.stream',8);ty=field(p,'CheckProgram.types',8)
  nn=field(g,'CheckGraph.count');nt=field(ty,'TypeColumns.count');kinds=read(field(ty,'TypeColumns.kind',8),nt);recorded=field(g,'CheckGraph.recorded_ready',1) and field(g,'CheckGraph.recorded_nodes')==nn
  recorded=2*int(field(s,'CheckStream.graph',8)==g)+int(recorded)
  tycol=field(s,'CheckStream.value_types',8);cv=field(s,'CheckStream.conversions',8)
  if not tycol and nn:raise Exception('non-columnar checked stream')
  r=words(tycol,nn);st=cfg['stride']//4;arr=words(cv,nn*st);c0=arr[0::st] if nn else [];c1=arr[cfg['conv']//4::st] if nn else []
  ops=words(field(g,'CheckGraph.ops',8),nn); op=cfg['ops'];bounds=[]
  for i in range(0,nn,16):
   a=i+16;ids={v>>3 for vs in (r,c0,c1) for v in vs[i:a]}; result={v>>3 for v in r[i:a]}; ks={kinds[j] for j in ids}; typ=bool(ks & {12,13,14,18,19})
   bounds.append((typ, max(ids,default=0),any(j in (op['CHECK_OP_BUILTIN_VECTOR'],) for j in ops[i:a])))
  type_rows={v>>3 for vs in (r,c0,c1) for v in vs};ids_by_kind={kinds[j] for j in type_rows}; first_special=next((i for i,b in enumerate(kinds) if b in (12,13,14,18,19)),nt)
  active=sum(x[0] for x in bounds); low=sum(x[1]<first_special for x in bounds); vec=sum(x[2] for x in bounds); width=type_rows and max(type_rows) or 0
  print('BODY',nn,int(recorded),int(bool(ids_by_kind & {12,13,14,18,19})),len(bounds),active,low,vec,first_special,width,len(type_rows));return False
Entry('*0x%x'%cfg['entry'],internal=True)
