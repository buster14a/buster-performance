#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;mkdir -p "$d/per-file"
python3 "$d/../source-member-operands-study/warning-interactions.py" source-scalar-member-study source-scalar-member-operands >"$d/warning-interactions.log" 2>&1
for i in prior source;do
 tree=main-fbef-clean;[[ $i == prior ]] || tree=source-scalar-member-operands
 echo '#!/bin/sh' > "$d/per-file/$i"
 printf 'exec "%s/../%s/build/compiler" --node-window "$@"\n' "$d" "$tree" >> "$d/per-file/$i"
 chmod u+x "$d/per-file/$i"
done
cd ../switch-inputs;source ../switch-local-args.sh;source_tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$source_tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $source_tree/src/buster/compiler/main.c"
for g in sqlite main lua musl;do v=${g}_arguments;eval "args=(${!v})";python3 "$d/../default-object-qa/pair.py" "$d/per-file" "$g" "$d/per-file/prior" "$d/per-file/source" "${args[@]}";done
