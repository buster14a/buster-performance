# Pointer reads and side effects

Additional pointer-read, side-effect and evaluation tests compared exit status, standard output, diagnostics and ELF for 66 source/policy cases. 0 differed from the prior source-window compiler. [Per-case results](warning-interactions.tsv) and [source, compiler and Clang streams](warning-interactions.tar.gz).
