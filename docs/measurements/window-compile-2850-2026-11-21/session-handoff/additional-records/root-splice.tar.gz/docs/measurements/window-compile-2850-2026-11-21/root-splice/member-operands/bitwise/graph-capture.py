from pathlib import Path
import json,sys
base=Path(__file__).resolve().parent
abi=json.loads((base.parent/'ordinary-member-facts-study/base-abi.json').read_text())
fields={
 'graph':'ops tokens operand0 operand1 operand2 types members argument_counts contexts source_positions',
 'stream':'value_types value_flags value_objects value_categories value_constants conversions diagnostics diagnostic_operands member_offsets warnings warning_ignored constant_evaluated payload_rows',
}
script="""set confirm off
set pagination off
set debuginfod enabled off
python
import gdb,json,os
from pathlib import Path
abi=ABI
fields=FIELDS
dest=Path(os.environ['MEMBER_CAPTURE'])
dest.mkdir(exist_ok=True)
def raw(p,count):return gdb.selected_inferior().read_memory(p,count).tobytes()
def u(p,n):return int.from_bytes(raw(p,n),'little')
class Done(gdb.FinishBreakpoint):
    def __init__(self,g,s):super().__init__(gdb.newest_frame(),internal=True);self.g=g;self.s=s
    def stop(self):
        holders={'graph':self.g,'stream':self.s}
        n=u(self.g+abi['graph.count'][3],4);a=u(self.g+abi['graph.argument_count'][3],4);p=u(self.s+abi['stream.payload_count'][3],4)
        print('MEMBER_GRAPH',n,a,p)
        (dest/'counts').write_text('%d %d %d' % (n,a,p))
        for group,keys in fields.items():
            for key in keys.split():
                name=group+'.'+key;_,_,_,off,width=abi[name];addr=u(holders[group]+off,8)
                if addr:(dest/name).write_bytes(raw(addr,n*width))
        for group,key,count in [('graph','argument_nodes',a),('stream','argument_conversions',a),('stream','payloads',p)]:
            name=group+'.'+key;_,_,_,off,width=abi[name];addr=u(holders[group]+off,8)
            if addr:(dest/name).write_bytes(raw(addr,count*width))
        return False
class Start(gdb.Breakpoint):
    def stop(self):
        Done(int(gdb.parse_and_eval('$rsi')),int(gdb.parse_and_eval('$r9')))
        return False
Start('*check_graph_run')
end
run
"""
(base/'capture.gdb').write_text(script.replace('ABI',repr(abi)).replace('FIELDS',repr(fields)))
