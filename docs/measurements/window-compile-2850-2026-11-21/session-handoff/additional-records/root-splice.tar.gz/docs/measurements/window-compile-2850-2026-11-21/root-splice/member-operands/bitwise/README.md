# Source-resolved field loads in bitwise operands

Buster `75de49fff9597b635b7fa13fae9de88f19d89841` extends the explicit source-window compiler at `0e1d5b825801135bf50e79da9d546bc95209ab30`. The ordinary declaration binding and source-visible field layout produce a local-pointer load, an optional offset and pointer addition, and a field load before the checker creates the arrow node. Its binary parent checks the resulting lvalue and emits native code through the normal driver.

On SQLite, 44 field operands each displaced a checker node. The input went from 310,549 to 310,505 nodes. 217,553 fixed operand references and 34,220 call argument references survived. The source-owned fields retain their ordinary value. Their explicit input conversions and member offsets move to the native tape. The [SQLite graph audit](sqlite.json), [per-field identities and offsets](sqlite.roots.tsv), [focused audit](guard.json) and [compiler-source audit](main.json) give the observed scope.

The nonmutated and ordinary execution fixture outcomes were `1514966879850282001`. Replacing each selected byte offset with a different in-record offset gave `9138701416126361617`. Replacing the local object number with an invalid value made object compilation fail. [ELF hashes and outputs](elf-controls.tsv) and [debugger sessions](control.tar.xz) capture those controls.

The 112 focused source and policy comparisons have 5 mismatches against the prior source-window compiler. [Outcomes](source-comparisons.tsv) and [all compiler, Clang, executable and diagnostic streams](cases.tar.xz) record every case. The [four-workload checks](frozen.tsv) cover default objects, warning-enabled objects and a separate stage-report compile. The native graph capture ran on the local 7940HS Develop executables.

An invalid bitwise operand lost its field declaration’s typedef spelling. The reference printed `Alias` with its underlying `int`. The compacted operand printed only `int`. Both diagnosed the original operator and returned the same failure status. The later scalar-field revision carries the member’s declaration identity into that diagnostic path.
