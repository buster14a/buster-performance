#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;mkdir -p capture;python3 graph-capture.py
cd ../switch-inputs;source ../switch-local-args.sh
source_tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$source_tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $source_tree/src/buster/compiler/main.c"
failed=0
for corpus in guard sqlite main;do
 if [[ $corpus == guard ]];then args=("$d/cases/runtime.c");else v=${corpus}_arguments; eval "args=(${!v})";fi
 for label in prior source;do tree=main-fbef-clean;[[ $label == prior ]] || tree=source-member-locations
   MEMBER_CAPTURE="$d/capture/$corpus-$label" gdb -q --batch -x "$d/capture.gdb" --args "../$tree/build/compiler" --lanes 1 --node-window -c "${args[@]}" -o "$d/capture/ordinary.o" >"$d/capture/$corpus-$label.log" 2>&1
   test -f "$d/capture/$corpus-$label/counts"
 done
 python3 "$d/graph-audit.py" "$corpus" || failed=1
done
exit "$failed"
