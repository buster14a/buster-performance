# Source and reference boundaries

The retained local Develop control executable was built at `fbef2d68dfc952c269d7a2fd008220341428e727`. The source-window patch is based on `0e1d5b825801135bf50e79da9d546bc95209ab30`. Between these revisions Git reports a change only in `docs/one-core-path.md`. Their compiler sources and build system are identical. The four local workloads use the frozen local source snapshot. Throughput measurements on the 9700X use their separately recorded Release compiler and input hashes.
