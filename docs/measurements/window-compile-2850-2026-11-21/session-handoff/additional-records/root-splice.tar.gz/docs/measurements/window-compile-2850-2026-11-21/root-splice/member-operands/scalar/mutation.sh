#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD
base=../main-fbef-clean/build/compiler;test -x "$base"
new=../source-scalar-member-operands/build/compiler
src="$d/cases/runtime.c";test -s "$src"
clang=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
mkdir -p "$d/control"
for mode in ordinary same corrupt reject;do
 if [[ $mode == ordinary ]];then
   "$base" -nostdinc -std=c17 --lanes 1 -c "$src" -o "$d/control/$mode.o" >"$d/control/$mode.stdout" 2>"$d/control/$mode.stderr"
 else
   expr='set $rcx = $rcx == 0 ? 4 : 0'
   [[ $mode != reject ]] || expr='set $rsi = 0xffffffff'
   [[ $mode != same ]] || expr='set $rcx = $rcx'
   cat >"$d/control/$mode.gdb" <<GDB
set pagination off
set confirm off
set debuginfod enabled off
set \$called = 0
break *check_node_window_member_rows
commands
silent
set \$called = \$called + 1
$expr
continue
end
run
printf "SOURCE_ROWS %u\\n", \$called
GDB
   gdb -q --batch -x "$d/control/$mode.gdb" --args "$new" -nostdinc -std=c17 --node-window --lanes 1 -c "$src" -o "$d/control/$mode.o" >"$d/control/$mode.gdb.log" 2>&1
   grep -Eq 'SOURCE_ROWS [1-9][0-9]*$' "$d/control/$mode.gdb.log"
 fi
 if [[ $mode != reject ]];then
   "$clang" "$d/control/$mode.o" -o "$d/control/$mode.exe"
   "$d/control/$mode.exe" >"$d/control/$mode.answer"
 fi
done
cmp "$d/control/ordinary.o" "$d/control/same.o"
cmp "$d/control/ordinary.answer" "$d/control/same.answer"
! cmp -s "$d/control/ordinary.answer" "$d/control/corrupt.answer"
test ! -s "$d/control/reject.o"
