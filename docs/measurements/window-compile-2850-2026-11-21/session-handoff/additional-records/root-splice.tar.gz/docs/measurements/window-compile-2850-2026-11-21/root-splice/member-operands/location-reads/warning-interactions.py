from pathlib import Path
import csv,hashlib,gzip,re,subprocess,sys
w=Path(__file__).resolve().parent.parent;st=w/sys.argv[1];tree=w/sys.argv[2];out=st/'warning-interactions';out.mkdir(exist_ok=True)
clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
header='struct S{int field;int other;int *ptr;int arr[3];};extern int foo(int,int*);\n'
tests={
 'write_after_read':'int f(struct S*p,struct S*q){return p->field + (p=q)->other;}',
 'write_before_read':'int f(struct S*p,struct S*q){return (p=q)->field + p->other;}',
 'write_after_bitwise':'int f(struct S*p,struct S*q){return (p->field|3)+((p=q)->other&4);}',
 'read_argument':'int f(struct S*p,struct S*q){return foo(p->field,(p=q)->ptr);}',
 'increment':'int f(struct S*p){return p->field + p++->field;}',
 'assign_target':'int f(struct S*p,struct S*q){return p->field=(p=q)->field;}',
 'assign_effect':'int f(struct S*p){return p->field++ + p->field;}',
 'shortcircuit':'int f(struct S*p,struct S*q){return p->field && (p=q)->field;}',
 'comma':'int f(struct S*p,struct S*q){return (p->field,p=q,p->field);}',
 'uninit_bitwise':'int f(int c,struct S*q){struct S*p;if(c)p=q;return p->field|1;}',
 'uninit_address':'int *f(void){struct S*p;return &p->field;}',
 'dead_sizeof':'int f(void){struct S*p;return sizeof(p->field + 2);}',
 'sizeof_array':'int f(struct S*p){return sizeof p->arr;}',
 'index_bounds':'int f(struct S*p){return p->arr[4];}',
 'string_noderef':'int f(struct S *__attribute__((noderef)) p){return p->field+3;}',
 'arrow_in_switch':'int f(struct S*p,int x){switch(x){case 1: return p->field;case 2:return p->other;default:return 327;} }',
 'implicit_bool':'int f(struct S*p){return &p->other ? 1 : 0;}',
 'escape':'int *f(struct S*p){struct S temporary;return (p=&temporary,&p->other);}',
 'function_argument':'int f(struct S*p,struct S*q){return foo(p->field,&q->other);}',
 'address_of_array':'int *f(struct S*p){return &p->arr[8];}',
 'getarray':'int f(struct S*p){return p->arr < (int*)0;}',
 'nonnull_param':'int f(struct S*p){return (p->ptr | 3);}',
}
options={'wall':['-Wall','-Wextra'],'strict':['-Wall','-Wextra','-Werror'],'everything':['-Weverything','-Wno-c++-compat']}
h=lambda x:hashlib.sha256(x).hexdigest()
rows=[]
for name,body in tests.items():
 src=out/(name+'.c');src.write_text(header+body+'\n')
 for policy,opts in options.items():
  rec={}
  for role,exe,flags in [('prior',w/'main-fbef-clean/build/compiler',['--node-window','--lanes','1']),('source',tree/'build/compiler',['--node-window','--lanes','1']),('clang',clang,['-fno-color-diagnostics'])]:
   bn=out/'test.o';bn.unlink(missing_ok=True);r=subprocess.run([exe,*flags,'-std=gnu17','-nostdinc',*opts,'-c',src,'-o',bn],capture_output=True)
   rec[role]=(r.returncode,h(r.stdout),h(r.stderr),h(bn.read_bytes()) if bn.exists() else '-')
   for k in ('stdout','stderr'):(out/f'{name}.{policy}.{role}.{k}.gz').write_bytes(gzip.compress(getattr(r,k),mtime=0))
  rows.append((name,policy,int(rec['prior']==rec['source']),*rec['prior'],*rec['source'],*rec['clang']))
with (out/'results.tsv').open('w') as f:
 t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow(['case','policy','same',*[a+'-'+b for a in ('prior','source','clang') for b in ('status','stdout','stderr','object')]]);t.writerows(rows)
print('warning comparisons',len(rows),'deltas',[(r[0],r[1]) for r in rows if not r[2]],flush=True)
