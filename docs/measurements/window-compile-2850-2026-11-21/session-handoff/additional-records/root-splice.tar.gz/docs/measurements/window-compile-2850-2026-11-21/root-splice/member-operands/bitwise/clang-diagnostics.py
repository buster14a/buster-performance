from pathlib import Path
import csv,gzip,hashlib,re,subprocess,sys
st=Path(sys.argv[1]).resolve();w=st.parent;d=st/'cases';tbl=list(csv.DictReader((d/'results.tsv').open(),delimiter='\t'))
srcs=sorted(d.glob('*.c'));compiler=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
policy={'syntax':[],'warn':['-Wall','-Wextra'],'error':['-Wall','-Wextra','-Werror'],'everything':['-Weverything','-Wno-c++-compat']}
outputs=st/'clang-diagnostics';outputs.mkdir(exist_ok=True)
with (outputs/'outcomes.tsv').open('w') as f:
 t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow(('case','policy','clang-status','prior-window-status','source-window-status','clang-errors','clang-warnings','clang-stderr','prior-stderr','source-stderr'))
 for src in srcs:
  for name,opts in policy.items():
   records={x['variant']:x for x in tbl if x['case']==src.stem and x['mode']==name}
   if not records:continue
   r=subprocess.run([compiler,'-fsyntax-only','-nostdinc','-fno-color-diagnostics','-std=gnu17',*opts,src],capture_output=True)
   for key in ('stdout','stderr'):(outputs/(src.stem+'.'+name+'.'+key+'.gz')).write_bytes(gzip.compress(getattr(r,key),mtime=0))
   t.writerow((src.stem,name,r.returncode,records['prior']['exit'],records['source']['exit'],len(re.findall(rb'\berror: ',r.stderr)),len(re.findall(rb'\bwarning: ',r.stderr)),hashlib.sha256(r.stderr).hexdigest(),records['prior']['stderr'],records['source']['stderr']))
(outputs/'compiler.txt').write_bytes(subprocess.check_output([compiler,'--version']))
