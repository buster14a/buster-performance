#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD
base=../main-fbef-clean/build/compiler;test -x "$base"
new=../source-member-location-reads/build/compiler
src="$d/cases/runtime.c";test -s "$src"
clang=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
mkdir -p "$d/control"
for mode in ordinary same corrupt reject;do
 if [[ $mode == ordinary ]];then
   "$base" -nostdinc -std=c17 --lanes 1 -c "$src" -o "$d/control/$mode.o" >"$d/control/$mode.stdout" 2>"$d/control/$mode.stderr"
 else
   hook=check_lower_window_field
   expr='set $rsi = $rsi == 0 ? 4 : 0'
   if [[ $mode == reject ]];then
     # The optimized lowering loop loads the recorded local into r13 for its object-count check.
     objdump -d --disassemble=check_lower_window "$new" >"$d/control/lowering.asm"
     addr=$(awk '/cmp    %rsi,%r13$/ {sub(/:$/,"",$1);print $1}' "$d/control/lowering.asm")
     [[ $addr =~ ^[0-9a-f]+$ ]]
     hook="0x$addr";expr='set $r13 = 0xffffffff'
     rm -f "$d/control/reject.o"
   fi
   [[ $mode != same ]] || expr='set $rsi = $rsi'
   cat >"$d/control/$mode.gdb" <<GDB
set pagination off
set confirm off
set debuginfod enabled off
set \$called = 0
break *$hook
commands
silent
set \$called = \$called + 1
$expr
continue
end
run
printf "SOURCE_ROWS %u\\n", \$called
GDB
   gdb -q --batch -x "$d/control/$mode.gdb" --args "$new" -nostdinc -std=c17 --node-window --lanes 1 -c "$src" -o "$d/control/$mode.o" >"$d/control/$mode.gdb.log" 2>&1
   grep -Eq 'SOURCE_ROWS [1-9][0-9]*$' "$d/control/$mode.gdb.log"
 fi
 if [[ $mode != reject ]];then
   "$clang" "$d/control/$mode.o" -o "$d/control/$mode.exe"
   "$d/control/$mode.exe" >"$d/control/$mode.answer"
 fi
done
cmp "$d/control/ordinary.o" "$d/control/same.o"
cmp "$d/control/ordinary.answer" "$d/control/same.answer"
! cmp -s "$d/control/ordinary.answer" "$d/control/corrupt.answer"
test ! -s "$d/control/reject.o"
