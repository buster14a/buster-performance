"""Use each native compiler's clang ABI to collect its ordinary checker output just after check_graph_run."""
import json, re, shlex, subprocess, sys
from pathlib import Path
d=Path(__file__).resolve().parent; w=d.parent
schema = {
 'stream':('CheckStream',{'count':('scalar','atomic_count'),'atomics':('array','atomics')}),
 'atomic':('CheckBuiltinAtomicEffect',{'atomics':('scalar','node object_address store_value object_type value_type object_size required_alignment minimum_alignment evaluated_operands success_order failure_order known_orders warnings warning_operands unsupported runtime_builtin fence_scope alignment_known volatile_access reads_memory writes_memory rmw compiler_barrier late_completion answers query_size query_pointer space_target')}),
}
for name,tree in [('base','main-fbef-clean'),('candidate','source-member-location-reads')]:
 src=w/tree
 unit=next(x for x in json.loads((src/'build/compile_commands.json').read_text()) if x['file'].endswith('main_unit_checker.c'))
 args=shlex.split(unit['command']);args=args[:args.index('-Xclang')];args=[a for a in args if not a.startswith('-DCMAKE_INTDIR')]
 fields={};qs={}
 def take(expr):
    qs.setdefault(expr,'FieldOracle'+str(len(qs)))
    return expr
 for group,(typ,items) in schema.items():
    for num,(kind,cols) in items.items():
        for f in cols.split():
            fields[group+'.'+f]=[group,num,kind,take(f'__builtin_offsetof({typ},{f})'),take(f'sizeof('+('*' if kind=='array' else '')+f'(({typ}*)0)->{f})')]
 for label,expr in [('type_offset','__builtin_offsetof(TypeTable,types)'),('stats_offset','__builtin_offsetof(CheckStream,statistics)')]:
    fields[label]=take(expr)
 lay=d/(name+'-atomic-abi.c')
 lay.write_text('#include '+json.dumps(unit['file'])+'\n'+'\n'.join(f'struct {tag} {{char size[1+({expr})];}}; _Static_assert(sizeof(struct {tag})>0,"");' for expr,tag in qs.items()))
 text=subprocess.check_output([*args,'-Xclang','-fdump-record-layouts','-fsyntax-only',str(lay)],cwd=unit['directory'],stderr=subprocess.PIPE,text=True)
 vals={tag:int(size)-1 for tag,size in re.findall(r'\| struct (FieldOracle\d+)\n.*?\[sizeof=(\d+)',text,re.S)}
 spec={k:([*v[:3],*[vals[qs[l]] for l in v[3:]]] if isinstance(v,list) else vals[qs[v]]) for k,v in fields.items()}
 (d/(name+'-atomic-abi.json')).write_text(json.dumps(spec,sort_keys=True,indent=2)+'\n')
assert (d/'base-atomic-abi.json').read_bytes()==(d/'candidate-atomic-abi.json').read_bytes()
