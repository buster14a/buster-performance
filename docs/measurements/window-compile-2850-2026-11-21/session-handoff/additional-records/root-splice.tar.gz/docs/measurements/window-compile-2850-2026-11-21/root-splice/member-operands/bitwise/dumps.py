from pathlib import Path
import csv,gzip,hashlib,subprocess,sys
w=Path(__file__).resolve().parent.parent;st=w/sys.argv[1];tree=w/sys.argv[2];out=st/'dumps';out.mkdir(exist_ok=True)
src=out/'declarations.c';src.write_text("""typedef int Count;
struct Pair {int pad; Count count; unsigned short a[4]; };
static struct Pair seed={2,71,{13,27,41,63}}; static struct Pair *global=&seed;
int field(struct Pair *p,unsigned v){p->a[v&3]=v;return p->count ^ (v + p->a[1]);}
int call(void){return field(global,3);}
""")
cases=[('source',src),('runtime',st/'cases/runtime.c'),('invalid',st/'cases/lexical.c')]
with (out/'results.tsv').open('w') as f:
 t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow(['case','mode','variant','exit','stdout-bytes','stderr-bytes','stdout-sha256','stderr-sha256'])
 for name,c in cases:
  for mode,opts in [('typed',['--dump-typed']),('static',['--dump-static']),('both',['--dump-typed','--dump-static']),('warn',['-fsyntax-only','-Weverything','-Wno-c++-compat']),('error',['-fsyntax-only','-Wall','-Wextra','-Werror'])]:
   outcomes=[]
   for variant,bin,extra in [('ordinary',w/'main-fbef-clean/build/compiler',[]),('prior',w/'main-fbef-clean/build/compiler',['--node-window']),('candidate',tree/'build/compiler',['--node-window'])]:
    r=subprocess.run([bin,*extra,'--lanes','1','-std=gnu17','-nostdinc',*opts,c,'-o',out/'unit.o'],capture_output=True);obs=(r.returncode,r.stdout,r.stderr);outcomes.append(obs)
    for k,b in zip(('stdout','stderr'),obs[1:]):(out/f'{name}.{mode}.{variant}.{k}.gz').write_bytes(gzip.compress(b,mtime=0))
    t.writerow([name,mode,variant,r.returncode,len(r.stdout),len(r.stderr),*[hashlib.sha256(b).hexdigest() for b in obs[1:]]])
   assert outcomes[1]==outcomes[2],(name,mode)
