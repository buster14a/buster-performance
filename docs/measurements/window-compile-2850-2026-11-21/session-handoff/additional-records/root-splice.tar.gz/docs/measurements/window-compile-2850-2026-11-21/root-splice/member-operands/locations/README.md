# Source-owned field locations and their ordinary consumers

Buster `473d009274e4501d8b7a03a712f00366aa30ef08` stores the pointer read once. Its ordinary parent asks for either the field address or its loaded value. This source experiment admitted scalar, pointer, fixed array, structure and union fields. [Source patch](source.patch)

SQLite's completed checked graph fell from 310,549 to 293,212 nodes. Buster self fell from 1,407,359 to 1,398,205. The retained values, warnings, conversions, argument references, member offsets and explicit operand edges matched the prior source-window compiler after remapping node identities and accounting for the fields handled by the native tape. [SQLite](sqlite.json) and [Buster self](main.json)

The subsequent native compiler rejected SQLite's `AtomicStore(&db->u1.isInterrupted,1)` and Buster's atomic arrival counter in `lane.c`. The ordinary atomic proof recovers a member's alignment by walking its address expression. The cropped field lost that evidence. Both control compiles succeed. [SQLite stage report](sqlite-stage.stderr), [SQLite driver](sqlite-source.log) and [Buster driver](main-source.log)

An independent source oracle found 18 diagnostic mismatches across 66 pointer-read and evaluation-order comparisons. Six source programs that should fail with `-Werror` became successful. [Affected programs and Clang streams](diagnostic-comparison.md)

All 432 focused field and option combinations emitted their expected status, diagnostic streams and ELF. The full translation-unit runs exposed the additional atomic proof dependency. [Detailed focused outcomes](focused.tsv) and [source, executables' outputs and typed/static dumps](cases.tar.gz)

A field-offset mutation changed the guarded native result from 1514966879850282001 to 9138701416126361617. Substituting an invalid local number caused native compilation to fail. [Debugger and outputs](control.tar.gz)
