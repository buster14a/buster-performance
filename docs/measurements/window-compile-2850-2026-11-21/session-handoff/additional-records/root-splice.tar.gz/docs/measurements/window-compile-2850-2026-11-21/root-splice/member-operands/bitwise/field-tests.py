"""Exercise actual source member-window lowering, refusals and full diagnostics."""
import csv, gzip, hashlib, re, subprocess
from pathlib import Path
d=Path(__file__).resolve().parent; w=d.parent;out=d/'cases';out.mkdir(exist_ok=True)
base=w/'main-fbef-clean/build/compiler';candidate=w/'source-member-operands/build/compiler'
clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
common='''struct S{int lead; int x; unsigned bits:4; int tail;};'''
program=common+'''
extern int printf(const char*,...);
static int read(struct S *p,struct S *q,unsigned m) {
  return (p->lead&m) ^ (q->x|m) ^ (p->tail ^ m) ^ (p->bits&m);
}
int main(void) {
  unsigned long long h=17;struct S a,b;
  for(unsigned i=0;i<4096;i++) {
    a.lead = i*119; a.x=i*35; a.tail=i+56; a.bits=i;
    b.lead=i+903; b.x=1701+i*179; b.tail=33-i; b.bits=i>>3;
    h = h*131 + (unsigned)read((i&1)?&a:&b,(i&4)?&a:&b,i*13);
  }
  printf("%llu\\n",h);return 0;
}'''
cases={'runtime':program,
       'incomplete':'struct S;int f(struct S*p){return p->x&5;}struct S{int x;};',
       'deprecated':'struct S{int x __attribute__((deprecated));};int f(struct S*p){return p->x&7;}',
       'pointer-member':'struct S{int *p;};int f(struct S*s){return s->p|10;}',
       'bitfield':common+'int f(struct S*p){return p->bits^4;}',
       'danger':common+'int f(struct S*p){return (p->x&3)/(p->x^3);}',
       'pointer-undef':common+'int f(void){struct S *p;return p->x&4;}',
       'qualifier':common+'int f(volatile struct S*p){return p->x&7;}',
       'lexical':'typedef int Alias;struct S{ Alias x; };int f(struct S*p){return p->x | 1.0;}',
       'wrong-name':common+'int f(struct S*p){return p->unknown&7;}',
       'anonymous':'struct S{union{int x;};};int f(struct S*p){return p->x&7;}',
       'vector':'typedef int V __attribute__((ext_vector_type(4))); int f(V*p){return p->x&7;}',
       'policy':common+'int f(struct S*p){return p->x&0;}',
       'scoped':'struct S{int pad;int x;};int a(struct S*p){return p->x^1;}int b(void){struct S{int x;};struct S z={4};struct S*p=&z;return p->x&3;}' }
modes={'object':['-c'],'warn':['-c','-Wall','-Wextra'],'error':['-c','-Wall','-Wextra','-Werror'],'debug':['-c','-g'],
       'tier1':['-c','--tier1'],'dump':['--dump-typed','--dump-static'],'syntax':['-fsyntax-only'],'unsigned':['-c','-funsigned-char']}
def sha(blob): return hashlib.sha256(blob).hexdigest()
def run(cmd,stem):
    r=subprocess.run([*map(str,cmd)],capture_output=True,cwd=out,timeout=120)
    for key in ('stdout','stderr'): (out/(stem+'.'+key+'.gz')).write_bytes(gzip.compress(getattr(r,key),mtime=0))
    return r
for case,source in cases.items(): (out/(case+'.c')).write_text(source+'\n')
f=(out/'results.tsv').open('w',buffering=1); t=csv.writer(f,delimiter='\t',lineterminator='\n')
t.writerow(['case','mode','variant','exit','stdout','stderr','object'])
faults=[];obj=out/'unit.o';exe=out/'execute'
for case in cases:
    c=out/(case+'.c')
    for kind,flags in modes.items():
        observations=[]
        for variant,cc,opts in [('ordinary',base,[]),('prior',base,['--node-window']),('source',candidate,['--node-window'])]:
            obj.unlink(missing_ok=True); exe.unlink(missing_ok=True)
            cmd=[cc,*opts,'--lanes','1','-nostdinc','-std=gnu17',*flags,c]
            if '-c' in cmd: cmd+=['-o',obj]
            if kind=='dump': cmd+=['-o',obj]
            stem=f'{case}.{kind}.{variant}';r=run(cmd,stem)
            record=(r.returncode,sha(r.stdout),sha(r.stderr),sha(obj.read_bytes()) if obj.exists() else '-');observations.append(record)
            t.writerow([case,kind,variant,*record])
            if case=='runtime' and kind in ('object','tier1','debug') and r.returncode==0:
                l=run([clang,obj,'-o',exe],stem+'.link');assert l.returncode==0,l.stderr; nr=run([exe],stem+'.exec')
                anchor=out/'runtime.clang';cl=run([clang,'-std=gnu17','-O0',c,'-o',anchor],stem+'.clang');assert cl.returncode==0,cl.stderr
                cr=run([anchor],stem+'.clangrun')
                if (cr.returncode,cr.stdout,cr.stderr)!=(nr.returncode,nr.stdout,nr.stderr): faults.append((case,kind,variant,'clang-execution'))
        if observations[1]!=observations[2]: faults.append((case,kind,'prior/source',observations))
        if kind!='dump' and observations[0]!=observations[2]: faults.append((case,kind,'ordinary/source',observations))
    for variant,cc in [('prior',base),('source',candidate)]:
        r=run([cc,'--node-window','--time-stages','--lanes','1','-nostdinc','-std=gnu17','-c',c,'-o',obj],case+'.stage.'+variant)
        m=re.search(rb'node-window: taken=(\d+) ordinary-nodes-replaced=(\d+) summary-nodes=(\d+) graph-nodes=(\d+)',r.stderr)
        if m: print(case,variant,m.groups(),flush=True)
    f.flush()
(out/'failures.txt').write_text('\n'.join(map(str,faults))+'\n')
print('failures',len(faults));assert not faults
