#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD; cd ../switch-inputs;source ../switch-local-args.sh
mkdir -p "$d/quick"
cat > "$d/quick/fields.c" <<'C'
struct S { int x; int y; };
int f(struct S *p,int m){return (p->x & m)^(p->y | m);}
C
for target in fields sqlite;do
 if [[ $target == fields ]];then args=("$d/quick/fields.c");else eval "args=(${sqlite_arguments})";fi
 for mode in prior source;do
  tree=main-fbef-clean;[[ $mode == prior ]] || tree=source-scalar-member-operands
  "../$tree/build/compiler" --lanes 1 --node-window --time-stages -c "${args[@]}" -o "$d/quick/$target.$mode.o" >"$d/quick/$target.$mode.stdout" 2>"$d/quick/$target.$mode.stderr"
  grep 'node-window:' "$d/quick/$target.$mode.stderr"
 done
 cmp "$d/quick/$target.prior.o" "$d/quick/$target.source.o"
done
