#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD; cd ../switch-inputs;source ../switch-local-args.sh
source_tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$source_tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $source_tree/src/buster/compiler/main.c"
mkdir -p "$d/four" "$d/objects";cd "$d/objects"
python3 "$d/../source-member-operands-study/warning-interactions.py" source-member-locations-study source-member-locations >"$d/warning-interactions.log" 2>&1
for workload in sqlite main lua musl; do
 v=${workload}_arguments;eval "args=(${!v})"
 if test "$workload" = main || test "$workload" = sqlite;then args+=(-o unit.o);fi
 for mode in prior source;do
  tree="$d/../main-fbef-clean";[[ $mode == prior ]] || tree="$d/../source-member-locations"
  for kind in normal warn diagnostic;do
   case $kind in normal) flags=();;warn) flags=(-Wall -Wextra);;diagnostic) flags=(--time-stages);;esac
   rm -f -- ./*.o
   stem="$d/four/$workload-$mode-$kind"
   "$tree/build/compiler" --lanes 1 --node-window -c "${flags[@]}" "${args[@]}" >"$stem.stdout" 2>"$stem.stderr"
   sha256sum -- ./*.o | LC_ALL=C sort -k2 >"$stem.objects"
   if [[ $mode == source ]];then
      for ext in objects stdout stderr;do
        if [[ $kind != diagnostic || $ext != stderr ]]; then cmp "$d/four/$workload-prior-$kind.$ext" "$stem.$ext" || echo "$workload $kind $ext" >>"$d/four/mismatches.txt";fi
      done
   fi
  done
 done
done
