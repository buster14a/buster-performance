#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;out="$d/paid";mkdir -p "$out";cd ../switch-inputs;source ../switch-local-args.sh
source_tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$source_tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $source_tree/src/buster/compiler/main.c"
cpu=$(python3 -c 'import os;print(min(os.sched_getaffinity(0)))')
for workload in sqlite main;do
 v=${workload}_arguments;eval "args=(${!v})";args+=(-o "$out/native.o")
 for control in prior ordinary;do
  for n in 1 2 3;do
   order=(baseline candidate candidate baseline); [[ $n != 2 ]] || order=(candidate baseline baseline candidate)
   for j in 0 1 2 3;do
    variant=${order[j]}; stem="$out/$workload.$control.$n.$j.$variant"
    tree=source-member-location-reads;opts=(--node-window)
    if [[ $variant == baseline ]];then
     if [[ $control == prior ]];then tree=main-fbef-clean;else opts=();fi
    fi
    taskset -c "$cpu" perf stat -x, --no-big-num -o "$stem.perf" -e instructions:u,cycles:u -- "../$tree/build/compiler" --lanes 1 "${opts[@]}" -c "${args[@]}" >"$stem.stdout" 2>"$stem.stderr"
    sha256sum "$out/native.o" >"$stem.object";anchor="$out/$workload.prior.1.0.baseline"
    for ext in object stdout stderr;do cmp "$anchor.$ext" "$stem.$ext";done
   done
  done
 done
done
