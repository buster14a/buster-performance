import csv, hashlib, json, struct, sys
from pathlib import Path
from array import array
p=Path(__file__).resolve().parent;w=p.parent
abi=json.loads((w/'ordinary-member-facts-study/base-abi.json').read_text())
src=(w/'source-member-locations/src/buster/compiler/c_check_actions.c').read_text().split('typedef enum CheckOp')[1].split('}')[0]
import re
names=re.findall(r'^\s*(CHECK_OP_\w+),',src,re.M);arrow=names.index('CHECK_OP_ARROW');value=names.index('CHECK_OP_VALUE')
corpus=sys.argv[1];base=p/'capture'/(corpus+'-prior');new=p/'capture'/(corpus+'-source');out=p/'capture'
def data(folder):
 db={}
 for f in folder.iterdir():
  if '.' not in f.name:continue
  width=abi[f.name][4]
  db[f.name]=memoryview(f.read_bytes()).cast({1:'B',4:'I',8:'Q'}.get(width,'B'))
 return db
a,b=data(base),data(new);n,args,pa=map(int,(base/'counts').read_text().split());m,new_args,pb=map(int,(new/'counts').read_text().split());assert args==new_args and a.keys()==b.keys()
missing=0xffffffff
mapping=array('I',[missing])*n; dropped=[];replaced={};i=j=0
while i<n and j<m:
 if a['graph.ops'][i]==value and i+1<n and a['graph.ops'][i+1]==arrow and a['graph.operand0'][i+1]==i and b['graph.ops'][j]==value and b['graph.tokens'][j]==a['graph.tokens'][i+1]:
  dropped.append(i);replaced[i+1]=j;i+=1
 else:
  assert a['graph.ops'][i]==b['graph.ops'][j] and a['graph.tokens'][i]==b['graph.tokens'][j],(corpus,i,j,'identity')
 mapping[i]=j;i+=1;j+=1
assert i==n and j==m and n-m==len(replaced)
order=[(key,arr,b[key]) for key,arr in a.items() if key.startswith('stream.') and key not in ('stream.member_offsets','stream.payload_rows','stream.conversions','stream.payloads','stream.argument_conversions')]
graph=[(key,arr,b[key]) for key,arr in a.items() if key in ('graph.types','graph.contexts','graph.argument_counts','graph.source_positions')]
edge=[(key,arr,b[key]) for key,arr in a.items() if key in ('graph.operand0','graph.operand1','graph.operand2')]
def payload(db,index,translate=False):
 z=bytearray(db['stream.payloads'][(index-1)*96:index*96]);z[42:48]=bytes(6);z[58:64]=bytes(6)
 # A recorded fault carries a graph node identity. Compare that source node after the permutation.
 if translate and int.from_bytes(z[84:88],'little')!=0:
  at=int.from_bytes(z[88:92],'little')
  if at!=missing:
   assert at<len(mapping) and mapping[at]!=missing,(corpus,'lost fault node',at)
   z[88:92]=int(mapping[at]).to_bytes(4,'little')
 return z
base_ops=a['graph.ops'];bm=a['graph.members'];nm=b['graph.members'];af=a['stream.payload_rows'];bf=b['stream.payload_rows'];cv=a['stream.conversions'];nv=b['stream.conversions'];off=a['stream.member_offsets'];new_off=b['stream.member_offsets']
edges=0; mismatches={}
def fail(k,i,j,av,bv):
 if k not in mismatches:mismatches[k]=(i,j,str(av)[:90],str(bv)[:90])
for i,j in enumerate(mapping):
 if j==missing:continue
 compact=i in replaced
 for k,left,right in order:
  if left[i]!=right[j]:fail(k,i,j,left[i],right[j])
 if bool(af[i])!=bool(bf[j]) or (af[i] and payload(a,af[i],True)!=payload(b,bf[j])):fail('payload',i,j,af[i],bf[j])
 if compact:continue
 for k,left,right in graph:
  if left[i]!=right[j]:fail(k,i,j,left[i],right[j])
 for k,left,right in edge:
  v=left[i];ex=missing if v==missing else mapping[v];edges+=v!=missing
  if ex!=right[j] or (v!=missing and ex==missing):fail(k,i,j,ex,right[j])
 if base_ops[i]!=value or bm[i]==0:
  if bm[i]!=nm[j]:fail('graph.members',i,j,bm[i],nm[j])
 if off[i]!=new_off[j]:fail('stream.member_offsets',i,j,off[i],new_off[j])
 if cv[i*32:i*32+32]!=nv[j*32:j*32+32]:fail('stream.conversions',i,j,cv[i*32:i*32+32].hex(),nv[j*32:j*32+32].hex())
for i in range(args):
 if mapping[a['graph.argument_nodes'][i]]!=b['graph.argument_nodes'][i]:fail('argument-node',i,i,a['graph.argument_nodes'][i],b['graph.argument_nodes'][i])
if a.get('stream.argument_conversions')!=b.get('stream.argument_conversions'):fail('argument-conversions',0,0,'','')
with (out/(corpus+'.roots.tsv')).open('w') as f:
 t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow(['pointer_node','member_node','summary_node','member_token','bit_offset','pointer_type','result_type'])
 for i,j in replaced.items(): t.writerow((i-1,i,j,a['graph.tokens'][i],off[i],a['stream.value_types'][i-1],a['stream.value_types'][i]))
result=dict(input=corpus,prior_nodes=n,source_nodes=m,removed=len(dropped),surviving_edges=edges,call_arguments=args,mismatches=mismatches)
print(json.dumps(result));(out/(corpus+'.json')).write_text(json.dumps(result,indent=2)+'\n')
assert not mismatches,mismatches
