# Source-produced checked record member selections

Buster `8681f5f9de26fce608ad3e2c14874132ac1e22a1` resolves direct source-visible record field selections inside the pending postorder expression batch on `b352534f202b8a739923cd8b5c8953f773f6a9e1`. A leaf or preceding selection supplies the base type and value flags. The new source result carries the complete field type, its bit offset and the left operand’s conversion. Later field selections consume an earlier result while the batch still owns its graph columns. The checker reuses the result after it checks the final operator, input type, flags, category, constant context and source position. [Patch](implementation.patch) and [compiler identities](builds.tsv).

| Input | Native trials | Source-local nodes | Field selections produced | Using an earlier field result | Consumed |
| --- | ---: | ---: | ---: | ---: | ---: |
| sqlite | 2,674 | 319,280 | 24,620 | 3,054 | 19,225 |
| main | 8,654 | 581,511 | 14,197 | 1,503 | 13,985 |

Native status, diagnostic text, typed or static output, ELF hashes and checked-graph comparisons recorded 0 candidate-versus-control differences. 30 comparisons also record differences already present between ordinary compilation and the parent’s source-local route. The two frozen objects for each real workload matched in 4 of 4 checks. [Native outputs](oracle/native.tsv), [checked scopes](oracle/checked.tsv), [differences](oracle/failures.json), [baseline scope differences](oracle/previous.json), [saved object identities](oracle/historical-elf.json), [body-level proof coverage](oracle/coverage.tsv), [totals](oracle/totals.tsv) and [source, statuses and full raw streams](oracle/raw.tar.gz).

| Input | Scope | Paired wall | Faster wall rounds | Paired user instructions | Paired user cycles |
| --- | --- | ---: | ---: | ---: | ---: |
| sqlite | native | -8.984 ms | 3/5 | -566,397 | +22,262,382 |
| sqlite | local-stage | -1.997 ms | 4/5 | -1,040,964 | -4,362,116 |
| main | native | +2.354 ms | 2/5 | +11,369,048 | +176,754,234 |
| main | local-stage | -2.999 ms | 3/5 | +11,024,028 | +126,318,725 |

All stage measurements used one local Ryzen 9 7940HS core and the same optimized binary. The native comparisons enable the existing source-owned function path on both arms and emit a full ordinary ELF for each process. The stage-only arms admit all complete functions and stop at the same checker boundary. Five alternating ABBA/BAAB rounds measured wall time. Three additional rounds measured user cycles and instructions. [Paired results](stage/paired.tsv), [per-process samples with ELF hashes](stage/samples.tsv) and [raw output and counters](stage/raw.tar.gz).

Fingerprints were also taken inside the actual source-native trials. The producer and the source-native control differed at 0 function endings. The table separately identifies differences between the unchanged local trials and a whole-unit ordinary check. [Native trial fingerprints](live/comparisons.tsv) and [raw per-function records](live/raw.tar.gz).

The debugger selected the first checked field access at the checker input. The untouched source-native function returned `0 13`. Replacing the source-produced zero-bit offset with 32 bits returned `0 29`. An invalid input witness sent the operation through its ordinary checker action and preserved the original object and runtime output. The ordinary and observed controls retain their ELF hashes and runtime output. [Guarded outcomes](mutation/results.tsv) and [source and raw debugger transcripts](mutation/raw.tar.gz).

Two generated programs each exercised 196 integer type pairs. A third exercised chained record accesses, unsigned bit-fields and volatile loads. Nine argument counts on five builds agreed in every execution. [Runtime results](runtime/results.tsv) and [programs, full outputs and diagnostics](runtime/raw.tar.gz).

The [standalone replay](reproduce.py) extracts the archived directed sources, accepts the two compiler paths and the frozen SQLite, Buster and predefines paths, and compares complete native outputs and ordinary source-local checked fingerprints without the original study directories.

Six whole SQLite compilations and six Buster compilations per arm were sampled with the user-instructions event at a period of 250,007. Every native object matched its reference. [Sampling settings](profile/config.json), [SQLite symbol differences](profile/sqlite.deltas.tsv), [SQLite control source locations](profile/sqlite.control.sites.tsv), [Buster symbol differences](profile/main.deltas.tsv) and [raw perf recordings and symbolized streams](profile/raw.tar.gz).

The source-native compiler and its producer arm compared 4,116 real file and warning-policy combinations from SQLite, Buster, Lua and musl. Each record covers driver status, native ELF hash and both output streams. 0 differed. [All per-file comparisons and raw diagnostics](per-file/raw.tar.gz).

The standalone replay recorded 578 mode comparisons. [Replay outcomes](replay/comparisons.tsv) and [full replay streams](replay/raw.tar.gz).

Completed 8 checker shards and observed 1 nonzero exit statuses. The parent control and source candidate both fail the refused-program test in check_lower_prepare on a null type table. [Shard outcomes](checker/status.tsv) and [full checker logs](checker/raw.tar.gz).

A four-arm SQLite comparison included the unmodified previous compiler in ordinary and source-native modes, and the current executable with the producer off and on. Eight balanced wall rounds and four balanced counter rounds each emitted the frozen native ELF. [All paired arms](process/paired.tsv), [per-process hashes and samples](process/samples.tsv) and [counter output](process/raw.tar.gz).

The independent parent executable used for semantic comparisons had an O0 checker and optimized other units. The stage timing arms used the same optimized Develop compiler.

The cross-binary process benchmark used the separately built [exact optimized parent](process/parent-identity.tsv).
