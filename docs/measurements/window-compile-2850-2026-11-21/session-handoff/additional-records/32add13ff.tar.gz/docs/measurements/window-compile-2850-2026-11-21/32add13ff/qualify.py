from pathlib import Path
import csv,gzip,hashlib,os,shutil,subprocess
d=Path(__file__).resolve().parent;w=d.parent;tree=w/'source-refused-switch';cc=d/'compiler';env={k:v for k,v in os.environ.items() if not k.startswith(('BUSTER_CONTROL_','BUSTER_SOURCE_','BUSTER_BODY_'))};env['PATH']='/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:'+env['PATH']
def run():
 subprocess.run(['python3',d/'iterate.py'],cwd=d,check=True)
 r=subprocess.run([cc,'test-checker','--seed','2850','--part','6/8'],cwd=tree,env=env,capture_output=True,timeout=400)
 for k,v in [('stdout',r.stdout),('stderr',r.stderr)]:(d/('corrected.'+k+'.gz')).write_bytes(gzip.compress(v,mtime=0))
 with (d/'results.tsv').open('w') as f:
  t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow(['revision','mode','shard','exit'])
  t.writerow(['b352534f2','optimized parent',6,-11]);t.writerow(['7e2b6f3e4','type guard scout',6,-11]);t.writerow(['32add13ff','both guards scout',6,r.returncode])
 o=w/'perf/docs/measurements/window-compile-2850-2026-11-21/32add13ff';o.mkdir(exist_ok=True)
 for p in [*d.glob('*.gz'),d/'results.tsv',d/'iterate.py',d/'qualify.py',d/'intermediate-stack.txt']:shutil.copy(p,o/p.name)
 (o/'implementation.patch').write_bytes(subprocess.check_output(['git','-C',tree,'diff','--binary','b352534f2','HEAD']))
 (o/'README.md').write_text(f'''# Preserve refused-program and sparse-switch lowering controls

An invalid CheckProgram with no types formerly reached ABI setup. After fixing that first retained fixture, the synthetic sparse-switch fixture reached source-body lookup with no input, even though the existing generic switch plan only needs its explicit case and control records. The two guards preserve those existing entry points. The optimized source-native parent and the intermediate checker scout both faulted in shard 6 at successive fixtures. The scout including both corrections exited {r.returncode} on the same complete shard. [Two-commit patch against b352](implementation.patch), [recorded outcomes](results.tsv), [intermediate stack frames](intermediate-stack.txt), [final shard output](corrected.stdout.gz) and [link recipe](iterate.py).
''')
 print('refused switch fixed scout',r.returncode,flush=True)
if __name__=='__main__':run()
