from common import *
import csv,hashlib,json,shutil,subprocess,tarfile
tree=CC.parent.parent;key=subprocess.check_output(['git','-C',tree,'rev-parse','HEAD'],text=True).strip();o=W/'perf/docs/measurements/window-compile-2850-2026-11-21'/key[:9];o.mkdir(exist_ok=True)
import hashlib
with (o/'builds.tsv').open('w') as f:
 f.write('mode\trevision\tcompiler-sha256\tcheckout\n')
 for mode,cc in [('control',PRIOR),('candidate',CC)]:
  commit=subprocess.check_output(['git','-C',cc.parent.parent,'rev-parse','HEAD'],text=True).strip()
  f.write(f'{mode}\t{commit}\t{hashlib.sha256(cc.read_bytes()).hexdigest()}\t{cc.parent.parent}\n')
(o/'implementation.patch').write_bytes(subprocess.check_output(['git','-C',tree,'diff','HEAD^','HEAD']))
def info(q):return list(csv.DictReader(q.open(),delimiter='\t'))
q=D/'oracle';loc=info(q/'clang-locations.tsv');comp=info(q/'comparisons.tsv');fp=info(q/'fingerprints.tsv');sel=info(q/'selection.tsv');files=sum((info(p) for p in (D/'per-file').glob('*.tsv')),[])
for k in ('common.py','locations.py','qualify.py','package.py','per-file.sh','pair-output.py','focused.py','build.log'):shutil.copy(D/k,o/k)
for k in ('oracle','per-file','focused'):
 if not (D/k).exists():continue
 d=D/k;dest=o/k;dest.mkdir(exist_ok=True)
 for p in d.iterdir():
  if p.suffix in ['.tsv','.json']:shutil.copy(p,dest/p.name)
 with tarfile.open(dest/'raw.tar.gz','w:gz') as t:
  for p in d.iterdir():
   if p.suffix not in ['.tsv','.json','.o']:t.add(p,arcname=p.name)
lines=['# Preserve automatic counted-pointer initializer diagnostics','', 'The ordinary diagnostic pass reads the translation-unit graph of the aggregate initializer. For units declaring counted_by or counted_by_or_null pointer members the source-native admission now leaves that graph in place, including block-scope initializers. The existing binding pass has already processed declarations in the unit before graph admission. This guard uses the independently produced [counted-pointer type fact](../96022b764/README.md). The ordinary path is also used for valid counted-pointer programs. [Code](implementation.patch).']
for m in ('prior-source','ordinary','source'):
 l=[r for r in loc if r['mode']==m];r=next(v for v in l if v['input']=='counted-by-initializations-of-an-incomplete-pointee');lines+=['',f"{m} reproduced all ordered Clang diagnostic locations, severities and messages in {sum(v['same-messages']=='1' for v in l)}/{len(l)} programs. The established incomplete-pointee initializer fixture produced {r['compiler-events']}/{r['clang-events']} Clang diagnostics and notes. [Individual Clang events](oracle/clang-locations.tsv)."]
lines+=['',f"The matched compiler runs retained {len(comp)} status, object and stdout/stderr receipts, covering the default, warning, fatal-warning and typed/static dump policies. [Comparisons](oracle/comparisons.tsv) and [retained streams and source fixtures](oracle/raw.tar.gz). The four real ordinary/source historical ELF checks are in [the hash table](oracle/historical.json). All {sum(r['equal-prior']=='1' for r in fp)} of {len(fp)} unretired fingerprints matched the corresponding earlier compiler. [Semantic fingerprints](oracle/fingerprints.tsv)."]
for n in ('sqlite','main'):
 r=next(v for v in sel if v['case']==n and v['mode']=='candidate');lines+=['',f"{n} source-native admission with this guard reported `{r['summary']}`. [Admission output and ELF hashes](oracle/selection.tsv)."]
lines+=['',f"Across {len(files):,} real SQLite, Buster, Lua and musl file/policy combinations, {sum(r['same']!='1' for r in files)} native status, diagnostic or ELF observations differed between the parent and candidate. [The manifest and raw streams](per-file/raw.tar.gz).",'','The separate source-observability guard in [88b83219e](../88b83219e/README.md) addresses typed dump retirement in units without counted pointers. This revision isolates counted initializer behavior against 96022b764.']
(o/'README.md').write_text('\n'.join(lines)+'\n')
print(o,flush=True)
