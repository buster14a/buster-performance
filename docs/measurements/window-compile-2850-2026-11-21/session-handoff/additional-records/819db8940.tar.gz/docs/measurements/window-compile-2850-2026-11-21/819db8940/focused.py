from common import *
import csv,gzip,hashlib,re,subprocess
f=D/'focused';f.mkdir(exist_ok=True);cases=D/'oracle/cases';clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
names=['counted-by-initializations-of-an-incomplete-pointee','isolated-auto','isolated-implicit','isolated-compound','nested-auto','block-member','block-optional','late-completion','valid-counted-auto','valid-block-member']
names+=['inline-compound-tag', 'inline-compound-anonymous', 'inline-typeof-initializer', 'inline-sizeof-compound', 'late-block-definition']
def et(raw):return re.findall(rb'^.*?:(\d+):(\d+): (error|warning|note): (.*)$',raw,re.M)
with (f/'outcomes.tsv').open('w',buffering=1) as fp:
 t=csv.writer(fp,delimiter='\t',lineterminator='\n');t.writerow(['case','mode','exit','errors','notes','same-Clang-events','same-ordinary-process','ELF','stdout','stderr'])
 for n in names:
  source=cases/(n+'.c');vals={};out=f/'unit.o'
  for mode,cc,e in [('clang',clang,{}),('ordinary',CC,{}),('prior-source',PRIOR,native),('layout-source',W/'source-layout-counted-pointer/build/compiler',native),('candidate',CC,native)]:
   if not cc.exists():continue
   out.unlink(missing_ok=True);cmd=[cc,'-std=c23','-nostdinc','-fsyntax-only',source] if mode=='clang' else [cc,'--lanes','1','-std=c23','-nostdinc','-c',source,'-o',out]
   r=subprocess.run(cmd,cwd=ROOT,env=env|e,capture_output=True,timeout=30);h=hashlib.sha256(out.read_bytes()).hexdigest() if out.exists() else '-';val=(r.returncode,h,r.stdout,r.stderr);vals[mode]=val
   for label,payload in [('stdout',r.stdout),('stderr',r.stderr)]:(f/(n+'.'+mode+'.'+label+'.gz')).write_bytes(gzip.compress(payload,mtime=0))
   t.writerow([n,mode,r.returncode,r.stderr.count(b'error:'),r.stderr.count(b'note:'),int(et(r.stderr)==et(vals['clang'][-1])),int(val==vals.get('ordinary')),h,hashlib.sha256(r.stdout).hexdigest(),hashlib.sha256(r.stderr).hexdigest()])
