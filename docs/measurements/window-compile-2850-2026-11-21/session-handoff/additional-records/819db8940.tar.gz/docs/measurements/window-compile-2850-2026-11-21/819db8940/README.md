# Preserve automatic counted-pointer initializer diagnostics

The ordinary diagnostic pass reads the translation-unit graph of the aggregate initializer. For units declaring counted_by or counted_by_or_null pointer members the source-native admission now leaves that graph in place, including block-scope initializers. The existing binding pass has already processed declarations in the unit before graph admission. This guard uses the independently produced [counted-pointer type fact](../96022b764/README.md). The ordinary path is also used for valid counted-pointer programs. [Code](implementation.patch).

prior-source reproduced all ordered Clang diagnostic locations, severities and messages in 23/36 programs. The established incomplete-pointee initializer fixture produced 3/57 Clang diagnostics and notes. [Individual Clang events](oracle/clang-locations.tsv).

ordinary reproduced all ordered Clang diagnostic locations, severities and messages in 29/36 programs. The established incomplete-pointee initializer fixture produced 57/57 Clang diagnostics and notes. [Individual Clang events](oracle/clang-locations.tsv).

source reproduced all ordered Clang diagnostic locations, severities and messages in 29/36 programs. The established incomplete-pointee initializer fixture produced 57/57 Clang diagnostics and notes. [Individual Clang events](oracle/clang-locations.tsv).

The matched compiler runs retained 600 status, object and stdout/stderr receipts, covering the default, warning, fatal-warning and typed/static dump policies. [Comparisons](oracle/comparisons.tsv) and [retained streams and source fixtures](oracle/raw.tar.gz). The four real ordinary/source historical ELF checks are in [the hash table](oracle/historical.json). All 160 of 160 unretired fingerprints matched the corresponding earlier compiler. [Semantic fingerprints](oracle/fingerprints.tsv).

sqlite source-native admission with this guard reported `control-source-summary	bodies=2674	selected=2674	local-graph-nodes=319280	unit-graph-capacity=780125	unit-graph-nodes=4343`. [Admission output and ELF hashes](oracle/selection.tsv).

main source-native admission with this guard reported `control-source-summary	bodies=8667	selected=3074	local-graph-nodes=452701	unit-graph-capacity=2719324	unit-graph-nodes=954715`. [Admission output and ELF hashes](oracle/selection.tsv).

Across 4,116 real SQLite, Buster, Lua and musl file/policy combinations, 0 native status, diagnostic or ELF observations differed between the parent and candidate. [The manifest and raw streams](per-file/raw.tar.gz).

The separate source-observability guard in [88b83219e](../88b83219e/README.md) addresses typed dump retirement in units without counted pointers. This revision isolates counted initializer behavior against 96022b764.
