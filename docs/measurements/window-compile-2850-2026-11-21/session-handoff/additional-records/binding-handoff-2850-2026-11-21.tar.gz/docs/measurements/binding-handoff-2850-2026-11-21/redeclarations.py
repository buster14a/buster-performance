import csv,hashlib,pathlib,subprocess,sys,time
d=pathlib.Path(__file__).resolve().parent
w=d.parent
v=sys.argv[1]
o=d/('qualification-'+v);o.mkdir(exist_ok=True)
attr='__attribute__((internal_linkage)) '
with (o/'scale.tsv').open('w') as f:
 out=csv.writer(f,delimiter='\t');out.writerow(['kind','names','declarations','version','round','return','wall_ns','object_sha256'])
 for mode in ['plain','attributed']:
  for n in [2000,4000,8000,16000]:
   p=o/'long-redeclarations.c'
   src=''.join((attr if mode=='attributed' and i%2==0 else '')+'int f(int);\n' for i in range(n))
   p.write_text(src+'int f(int x){return x;}\nint main(void){return f(0);}\n')
   ref=None
   for rd,cc in enumerate(['binding-parent',v,v,'binding-parent']):
    obj=o/'long.o';obj.unlink(missing_ok=True)
    start=time.monotonic_ns()
    r=subprocess.run([w/cc/'build/compiler','--lanes','1','-nostdinc','-std=gnu17','-c',p,'-o',obj],capture_output=True,cwd=w/cc,timeout=90)
    ns=time.monotonic_ns()-start
    assert r.returncode==0,r.stderr[:300]
    digest=hashlib.sha256(obj.read_bytes()).hexdigest()
    receipt=(r.returncode,r.stdout,r.stderr,digest)
    if ref is None:ref=receipt
    assert receipt==ref
    out.writerow([mode,1,n,cc,rd,r.returncode,ns,digest])
   f.flush()
