set confirm off
set pagination off
set debuginfod enabled off
set breakpoint pending on
break check_input_binding_answers.buster_split
run
info args
python
r=gdb.parse_and_eval("reader")
b=r['bindings']
events=int(b['count'])
operations=bytes(gdb.selected_inferior().read_memory(int(b['operation']),events))
print("retained tokens={} events={} declares={} uses={} restores={}".format(int(r['parser']['tokens']['count']),events,operations.count(0),operations.count(1),operations.count(2)))
import array
keys=array.array("I",gdb.selected_inferior().read_memory(int(b['key']),events*4).tobytes())
prev=array.array("I",gdb.selected_inferior().read_memory(int(b['previous']),events*4).tobytes())
names=int(b['name_capacity'])
print("names={} first_stores={} nonzero_predecessor_loads={} ordinary_fresh_chain_stores={}".format(names,events,sum(op!=2 and h!=0 for op,h in zip(operations,prev)),sum(op==0 and h==0 and k<names for op,h,k in zip(operations,prev,keys))))
try:
 roots=int(r['internal_linkage_roots'])
 kept=array.array("I",gdb.selected_inferior().read_memory(roots,names*4).tobytes())
 print("names_with_queried_root={}".format(sum(x!=0 for x in kept)))
except gdb.error:
 pass
end
quit
