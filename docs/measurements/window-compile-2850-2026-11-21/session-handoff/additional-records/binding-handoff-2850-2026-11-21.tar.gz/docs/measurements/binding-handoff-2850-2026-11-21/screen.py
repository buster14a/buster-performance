import csv, hashlib, json, os, pathlib, shlex, statistics, subprocess, sys, time
d=pathlib.Path(__file__).resolve().parent
work=d.parent
variant,rep_str,*corpora=sys.argv[1:]
repeats=int(rep_str)
suffix='' if corpora in ([],['sqlite','self']) else '-'+'-'.join(corpora)
outdir=d/('screen-'+variant+suffix);outdir.mkdir(exist_ok=True)
inputs=work/'switch-inputs'
def argv(g):
    if g=='self':
        source=work/'pregraph-warning-study/compiler-source/src'
        return ['-march=native','-I'+str(source),'-fwrapv','-funsigned-char','--predefines',str(work/'proof-predefines.h'),str(source/'buster/compiler/main.c')]
    raw=subprocess.check_output(['bash','-c','source ../switch-local-args.sh; v=$1\x5farguments; printf "%s" "${!v}"','_',g],cwd=inputs,text=True)
    return shlex.split(raw)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
binaries={'base':work/'binding-parent/build/compiler','new':work/variant/'build/compiler'}
with (outdir/'builds.tsv').open('w') as f:
    for k,p in binaries.items():print(k,digest(p),subprocess.check_output(['git','-C',p.parents[1],'rev-parse','HEAD'],text=True).strip(),p,sep='\t',file=f)
measurements=[]
for corpus in corpora or ['sqlite','self']:
    args=argv(corpus);inputs_total=sum(a.endswith('.c') for a in args)
    path=outdir/corpus;path.mkdir(exist_ok=True)
    obj=path/'unit.o'; ref=None
    (path/'args.json').write_text(json.dumps(args))
    for rd in range(repeats+1):
        ordered=['base','new','new','base'] if rd%2==1 else ['new','base','base','new']
        for pos,key in enumerate(ordered):
            with (path/f'{rd}-{pos}-{key}.stat').open('w') as counters:
                event='-e';prep=['perf','stat','-x','\t','-o',counters.name,event,'instructions:u,cycles:u,cycles:k,minor-faults']
                command=[str(binaries[key]),'--lanes','1','-c',*args]
                if inputs_total==1:command+=['-o',str(obj)]
                t=time.monotonic_ns()
                res=subprocess.run(prep+command,cwd=path,capture_output=True,timeout=150)
                ns=time.monotonic_ns()-t
            (path/f'{rd}-{pos}-{key}.err').write_bytes(res.stderr)
            if res.returncode: raise RuntimeError(res.stderr[:3000])
            objects=sorted(path.glob('*.o')); assert len(objects)==inputs_total, (len(objects),inputs_total)
            outs=[(x.name,digest(x)) for x in objects]
            check=(outs, res.stdout, res.stderr)
            if ref is None: ref=check
            assert ref==check, (key,corpus,rd,pos)
            if rd==0:continue
            fields={r[2]:r[0] for r in csv.reader(open(counters.name),delimiter='\t') if len(r)>=3}
            row=(corpus,rd,pos,key,ns,*[int(fields[e]) for e in ['instructions:u','cycles:u','cycles:k','minor-faults']])
            measurements.append(row)
        print(corpus,rd,flush=True)
    (path/'object-hashes.json').write_text(json.dumps(ref[0]))
    for f in path.glob('*.o'):f.unlink()
with (outdir/'raw.tsv').open('w') as f:
    w=csv.writer(f,delimiter='\t');w.writerow(['corpus','round','position','variant','wall_ns','instructions_u','cycles_u','cycles_k','faults']);w.writerows(measurements)
with (outdir/'summary.tsv').open('w') as f:
    w=csv.writer(f,delimiter='\t');w.writerow(['corpus','metric','ratio_median','ratio_min','ratio_max'])
    for corpus in dict.fromkeys(r[0] for r in measurements):
        for index,metric in enumerate(['wall','instructions','cycles_user','cycles_kernel','faults'],4):
            ratios=[]
            for rd in range(1,repeats+1):
                sub=[r for r in measurements if r[0]==corpus and r[1]==rd]
                ratios.append(statistics.mean(r[index] for r in sub if r[3]=='new')/statistics.mean(r[index] for r in sub if r[3]=='base'))
            w.writerow([corpus,metric,*[f'{v:.6f}' for v in [statistics.median(ratios),min(ratios),max(ratios)]]])
