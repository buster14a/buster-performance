# Source-order binding experiments for Buster #2850

An ordinary SQLite object compile at `325883abf9607ac726966a0af2097377832d53ac` retained 167,474 binding events for 716,136 tokens. The debugger counted 34,530 declarations, 97,600 uses and 35,344 scope restores at the binding handoff. Three separate Release profiles attributed 4.25–4.51% of user cycles to the source-order resolver, 1.85–2.01% to declaration reading, 0.41–0.43% to publishing an individual binding answer, and 0.22–0.28% to the outer binding-answer routine. Percentages are exclusive samples on the local Ryzen 9 7940HS.

The private first-declaration column had one reader, the redeclaration check for `internal_linkage`. It received 167,474 writes and 99,044 predecessor reads. The first-handle entries of all 132,944 uses and restorations were unreachable by that reader. Storing the root at the start of each ordinary name chain needs 32,791 writes in the same event stream. A third implementation checks the existing open end of a cached root only when the attribute is queried. The parser and deferred readers keep their original event and declaration identities.

## Measured changes

Each row gives the median of the paired round ratios, expressed as a percent change from pristine. The local machine shared load with other leased cores. Each comparison stayed on one physical core, alternated ABBA / BAAB, discarded a warm-up round, and compared every output object and diagnostic. The wall column includes the `perf stat` process. The native qualification record, when available, supplies the target-machine timing.

| Experiment | Input | Wall | User instructions | User cycles | Kernel cycles | Minor faults |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| binding-first | sqlite | -1.111% | -0.079% | +0.081% | +0.268% | -0.002% |
| binding-first | self | -0.264% | +0.029% | -0.093% | +1.008% | -0.006% |
| binding-known | sqlite | +1.116% | -0.571% | +1.253% | +0.328% | +0.001% |
| binding-known | self | +1.327% | -0.158% | +0.913% | +1.421% | +0.000% |
| binding-linkage-cache | sqlite | -0.604% | -0.123% | -0.673% | -0.523% | -0.291% |
| binding-linkage-cache | self | -1.382% | +0.017% | -1.592% | -1.622% | -0.111% |
| binding-linkage-cache-lua-musl | lua | -3.671% | -0.075% | +1.726% | +0.348% | -0.456% |
| binding-linkage-cache-lua-musl | musl | -0.245% | -0.070% | -1.598% | +0.814% | -0.449% |
| binding-name-head | sqlite | +3.757% | -0.103% | +2.918% | +1.531% | -0.254% |
| binding-name-head | self | +0.147% | +0.023% | -0.355% | +0.181% | -0.091% |

`binding-first` writes the existing first handle only on declarations. `binding-name-head` keeps the active root per ordinary name. `binding-linkage-cache` removes root traffic from declaring and using names, and consults the oldest live declaration on demand for attributed redeclarations. `binding-known` bypasses intrinsic preparation and implicit-library restoration for a visible ordinary name absent from the intrinsic catalogue. `binding-direct-walk` uses the private source-order head invariant and a streaming token-bounds reduction, falling back to individual validation for imported streams. `binding-range` represents use events and validated declarations with masks over blocks of 64 events.

## Source and verification

Each experiment directory contains a patch against pristine, exact source and executable IDs, paired raw counters and object hashes. `cases.tsv` compares exit status, diagnostics, stdout and emitted ELF on 17 fixtures across seven driver configurations. It includes a Clang syntax-status column. The fixture runner also links and executes successful fixtures with a main function and runs the checker binding benchmark against its independent resolution modes. `scale.tsv` exercises ordinary and alternately attributed same-name prototypes at 2,000, 4,000, 8,000 and 16,000 declarations.

To replay, make pristine and candidate worktrees from the recorded base and apply the candidate patch. Build both with the same Clang 23.1.4 using `./build.sh --config Release`. The original runner expects sibling worktrees, a `binding-range-study` harness directory and the frozen SQLite, Lua and musl corpus layout in `switch-inputs`. The compiler self input is `84a7d3d76891d6c393497e62e6aff38f2b162fc2` with the options in `screen.py`. The package includes the workload hashes, compiler target information and `switch-local-args.sh`.
