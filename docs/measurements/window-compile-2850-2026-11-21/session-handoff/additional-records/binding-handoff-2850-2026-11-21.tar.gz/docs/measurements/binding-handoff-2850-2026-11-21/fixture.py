import csv, hashlib, os, pathlib, subprocess, sys
d=pathlib.Path(__file__).resolve().parent
work=d.parent
variant=sys.argv[1]
output=d/('qualification-'+variant);output.mkdir(exist_ok=True)
names=['a','b','c']
gnu='__attribute__((internal_linkage))';std='[[clang::__internal_linkage__]]'
cases={
 'first-function':f'{gnu} int x(void); int x(void); {gnu} int x(void){{return 1;}} int main(void){{return x()!=1;}}',
 'late-function':f'int x(void); int x(void); {gnu} int x(void){{return 1;}}',
 'first-object':f'{gnu} int x; extern int x; {gnu} int x; int main(void){{return x;}}',
 'late-object':f'int x; extern int x; {gnu} int x;',
 'c23':f'{std} int x(void); int x(void); {std} int x(void){{return 0;}} int main(void){{return x();}}',
 'late-c23':f'int x(void); {std} int x(void){{return 1;}}',
 'scope-live':f'{gnu} int x(void); int f(void){{int x=3;{{int x=4; if(x!=4) return 1;}}return x!=3;}} {gnu} int x(void){{return 0;}} int main(void){{return f()+x();}}',
 'scope-close':f'int f(void){{{{extern int x(void); {gnu} int x(void);}} {{extern int x(void); {gnu} int x(void);}}return 0;}}',
 'scope-new':f'int f(void){{{{{gnu} extern int x(void); {gnu} extern int x(void);}} {{extern int x(void); {gnu} extern int x(void);}}return 0;}}',
 'scoped-linkages':f'{gnu} int x(void); int f(void){{{{int x=3; if (x!=3) return 1;}} {{extern int x(void);return x();}}}} {gnu} int x(void){{return 0;}} int main(void){{return f();}}',
 'tag-typedef':f'struct x {{int x;}}; {gnu} int x(void); int f(void){{struct x x={{3}};{{typedef int x; x n=0;if(n)return n;}} return x.x!=3;}} {gnu} int x(void){{return 0;}} int main(void){{return f()+x();}}',
 'gnu89-implicit':'int f(){return unknown(3);} int unknown(x) int x; {return x;}',
 'type-query':'typedef int T; int a[2]; int f(int p){typeof(p) q=p;__auto_type k=q;return k+sizeof(a);}',
 'builtins':'int f(int i){__typeof__(i) j=__builtin_abs(i); return j;}',
 'missing':'int f(void){return missing;}',
}
cases['long-interleaved']='\n'.join([f'{gnu} int {n}(void);' for n in names]+[f'{gnu if i%2==0 else ""} int {n}(void);' for i in range(256) for n in names]+[f'{gnu} int {n}(void){{return 0;}}' for n in names]+['int main(void){return a()+b()+c();}'])
cases['long-late']='\n'.join([f'int {n}(void);' for n in names]*512+[f'{gnu} int b(void);'])
modes={'object':['-c'],'warnings':['-c','-Wall','-Wextra'],'everything':['-c','-Weverything','-Wno-c++-compat'],'scalar':['--scalar','-c'],'deferred':['--deferred-bodies','--lanes','2','-c'],'attested-off':['--attested=off','-c'],'syntax':['-fsyntax-only']}
sha=lambda data:hashlib.sha256(data).hexdigest()
def run(cmd):return subprocess.run(cmd,cwd=work/variant,timeout=80,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
binaries=[work/x/'build/compiler' for x in ['binding-parent',variant]]
clang=os.environ.get('BUSTER_CLANG','clang')
with (output/'cases.tsv').open('w') as table:
 w=csv.writer(table,delimiter='\t');w.writerow(('case','mode','equal','code','stdout','stderr','object','clang_syntax_code'))
 for ident,source in cases.items():
  file=output/(ident+'.c');file.write_text(source+'\n');obj=output/'same.o'
  language='-std=c23' if 'c23' in ident else '-std=gnu89' if 'gnu89' in ident else '-std=gnu17'
  clangcode=run([clang,'-fsyntax-only',language,file]).returncode
  for mode,flags in modes.items():
   command=[*flags,language,'-nostdinc',str(file)]
   if '-c' in flags:command+=['-o',str(obj)]
   receipts=[]
   for i,bin in enumerate(binaries):
    obj.unlink(missing_ok=True);r=run([bin,*command])
    if i==1 and mode=='object':(output/(ident+'.diag')).write_bytes(r.stderr)
    receipts.append((r.returncode,sha(r.stdout),sha(r.stderr),sha(obj.read_bytes()) if obj.exists() else '-'))
   w.writerow((ident,mode,int(receipts[0]==receipts[1]),*receipts[1],clangcode))
   if receipts[0]!=receipts[1]:raise RuntimeError((ident,mode,receipts))
  if 'main(void)' in source:
   r=run([binaries[1],'-nostdinc',language,'-c',file,'-o',obj])
   if r.returncode==0:
    exe=output/'case.exe'; res=run([clang,obj,'-o',exe]); assert res.returncode==0,res.stderr
    assert run([exe]).returncode==0,ident
source=output/'history.c'
source.write_text('typedef int T; struct x { T x; };\nint x; int f(int x) { int y=x; { struct x x={4}; y += x.x; } return y+x; }\n')
for bin in binaries:
 result=run([bin,'benchmark-checker-bindings','--passes','1','-nostdinc',source])
 (output/(bin.parents[1].name+'-history.txt')).write_bytes(result.stdout+result.stderr)
 assert result.returncode==0,(bin,result.stdout[-240:],result.stderr[:200])
