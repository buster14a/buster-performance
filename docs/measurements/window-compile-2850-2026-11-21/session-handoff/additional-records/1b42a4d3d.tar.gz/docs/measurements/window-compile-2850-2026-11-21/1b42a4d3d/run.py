from common import *
import csv,json,shutil,subprocess,sys,tarfile
subprocess.run([sys.executable,D/'numerical.py','--smoke'],check=True)
for k in ('stage.py','qualify.py','numerical.py','suites.py','profile.py'):subprocess.run([sys.executable,D/k],check=True)
subprocess.run(['bash',D/'per-file.sh'],check=True)
tree=CC.parent.parent;rev=subprocess.check_output(['git','-C',tree,'rev-parse','HEAD'],text=True).strip();dest=W/'perf/docs/measurements/window-compile-2850-2026-11-21'/rev[:9];dest.mkdir(exist_ok=True)
for f in [*D.glob('*.py'),D/'per-file.sh',D/'build.log']:shutil.copy(f,dest/f.name)
for k in ('stage','profile','oracle','suites','counts','per-file'):
 p=D/k;o=dest/k;o.mkdir(exist_ok=True)
 for f in p.iterdir():
  if f.suffix in ['.tsv','.json']:shutil.copy(f,o/f.name)
 with tarfile.open(o/'raw.tar.gz','w:gz') as t:
  for f in p.iterdir():
   if f.suffix not in ['.tsv','.json','.o'] and f.name!='app':t.add(f,arcname=f.name)
import hashlib
with (dest/'builds.tsv').open('w') as f:
 f.write('mode\trevision\tcompiler-sha256\tcheckout\n')
 for mode,cc in [('control',PRIOR),('candidate',CC)]:
  commit=subprocess.check_output(['git','-C',cc.parent.parent,'rev-parse','HEAD'],text=True).strip()
  f.write(f'{mode}\t{commit}\t{hashlib.sha256(cc.read_bytes()).hexdigest()}\t{cc.parent.parent}\n')
(dest/'implementation.patch').write_bytes(subprocess.check_output(['git','-C',tree,'diff','HEAD^','HEAD']))
read=lambda k:list(csv.DictReader((D/k).open(),delimiter='\t'))
pairs=read('stage/paired.tsv');outs=read('counts/outcomes.tsv');qq=read('oracle/outcomes.tsv');es=read('oracle/executions.tsv')
rows=['# Reuse the reserve type census across source bodies','', 'The body-local compiler carries atomic, extended-vector, ordinary-vector and transport-vector presence from earlier functions. It scans only appended types while binding, table identity and record completion permit reuse. Both compilers already include the typed scalar-node reserve rule. [Implementation](implementation.patch).','',f"The process-level GDB oracle measured all seven returns of the reserve planner for {sum(int(r['call-count']) for r in outs):,} complete calls across {len(outs)} input/mode pairs. Parent and candidate counts matched in {sum(r['equal-parent']=='1' for r in outs)} pairs. Redirecting just this function to its unchanged scalar twin yielded the same seven numbers and full ELF in {sum(r['equal-scalar']==r['same-ELF']=='1' for r in outs)} pairs. [Numerical outcomes](counts/outcomes.tsv), [all tuples](counts/tuples.tsv), [source/diagnostic and native output checks](oracle/outcomes.tsv), [executable probes](oracle/executions.tsv) and [checker shards](suites/status.tsv).",'',f"The ordinary and source-local mode compared {len(qq)} complete native/source outcomes against parent 0752250f7, with {sum(r['same-prior']!='1' for r in qq)} changed process results. The Clang cases and matching typed fingerprints are recorded independently. [Clang cases](oracle/clang.tsv), [fingerprints](oracle/fingerprints.tsv).",'','| Input | Mode | Metric | Median within-round change | Rounds lower |','| --- | --- | --- | ---: | ---: |']
for r in pairs:rows.append(f"| {r['input']} | {r['scope']} | {r['metric']} | {float(r['median-delta']):,.0f} | {r['faster']}/{r['rounds']} |")
rows+=['','## Work repeated across bodies','','The real source reuses the checked type-table prefix on 2,673 SQLite calls and 3,106 Buster calls. Instrumentation at the planner boundary counts rows available to inspect before and after prefix reuse. A terminal epoch already contains an atomic or transport vector. [Type rows per input](counts/suffix.tsv).','','| Source | Planner calls | Table rows over calls | Rows remaining to examine | Terminal epochs |','| --- | ---: | ---: | ---: | ---: |']
for r in read('counts/suffix.tsv'):
 if r['input'] in ['sqlite','main'] and r['scope']=='source':
  rows.append(f"| {r['input']} | {int(r['calls']):,} | {int(r['table-rows']):,} | {int(r['rows-remaining-to-examine']):,} | {int(r['terminal-epochs']):,} |")
rows+=['','Both source-native runs retired fewer instructions. SQLite wall time increased by 6.1 ms with two of eight rounds lower. Buster wall time increased by 32.1 ms with one of eight rounds lower. The developer-host runs do not justify enabling this change. [Source instruction samples](profile) and [individual wall and counter samples](stage/samples.tsv).','', 'The source-local base also fails checker shard 6. The ordinary production reserve PR has its own independent main-branch qualification.']
(dest/'README.md').write_text('\n'.join(rows)+'\n');print(dest)
