# Reuse the reserve type census across source bodies

The body-local compiler carries atomic, extended-vector, ordinary-vector and transport-vector presence from earlier functions. It scans only appended types while binding, table identity and record completion permit reuse. Both compilers already include the typed scalar-node reserve rule. [Implementation](implementation.patch).

The process-level GDB oracle measured all seven returns of the reserve planner for 6,013 complete calls across 62 input/mode pairs. Parent and candidate counts matched in 62 pairs. Redirecting just this function to its unchanged scalar twin yielded the same seven numbers and full ELF in 62 pairs. [Numerical outcomes](counts/outcomes.tsv), [all tuples](counts/tuples.tsv), [source/diagnostic and native output checks](oracle/outcomes.tsv), [executable probes](oracle/executions.tsv) and [checker shards](suites/status.tsv).

The ordinary and source-local mode compared 488 complete native/source outcomes against parent 0752250f7, with 0 changed process results. The Clang cases and matching typed fingerprints are recorded independently. [Clang cases](oracle/clang.tsv), [fingerprints](oracle/fingerprints.tsv).

| Input | Mode | Metric | Median within-round change | Rounds lower |
| --- | --- | --- | ---: | ---: |
| sqlite | native | ns | 6,092,118 | 2/8 |
| sqlite | ordinary | ns | 8,274,932 | 3/8 |
| sqlite | native | instructions | -4,561,089 | 4/4 |
| sqlite | native | cycles | -17,011,686 | 2/4 |
| sqlite | ordinary | instructions | -39,582 | 4/4 |
| sqlite | ordinary | cycles | -35,516,442 | 3/4 |
| main | native | ns | 32,065,297 | 1/8 |
| main | ordinary | ns | 9,680,781 | 4/8 |
| main | native | instructions | -51,901,038 | 4/4 |
| main | native | cycles | 60,964,732 | 1/4 |
| main | ordinary | instructions | -4,119,497 | 4/4 |
| main | ordinary | cycles | -127,339,588 | 3/4 |

## Work repeated across bodies

The real source reuses the checked type-table prefix on 2,673 SQLite calls and 3,106 Buster calls. Instrumentation at the planner boundary counts rows available to inspect before and after prefix reuse. A terminal epoch already contains an atomic or transport vector. [Type rows per input](counts/suffix.tsv).

| Source | Planner calls | Table rows over calls | Rows remaining to examine | Terminal epochs |
| --- | ---: | ---: | ---: | ---: |
| main | 3,108 | 31,242,079 | 19,503 | 3,106 |
| sqlite | 2,675 | 10,839,498 | 9,479 | 0 |

Both source-native runs retired fewer instructions. SQLite wall time increased by 6.1 ms with two of eight rounds lower. Buster wall time increased by 32.1 ms with one of eight rounds lower. The developer-host runs do not justify enabling this change. [Source instruction samples](profile) and [individual wall and counter samples](stage/samples.tsv).

The source-local base also fails checker shard 6. The ordinary production reserve PR has its own independent main-branch qualification.
