from common import *
import csv,json,re,shutil,subprocess,sys,tarfile
for k in ['stage.py','qualify.py','suites.py']:subprocess.run([sys.executable,D/k],check=True)
subprocess.run(['bash',D/'per-file.sh'],check=True)
tree=CC.parent.parent;rev=subprocess.check_output(['git','-C',tree,'rev-parse','HEAD'],text=True).strip();dest=W/'perf/docs/measurements/window-compile-2850-2026-11-21'/rev[:9];dest.mkdir(exist_ok=True)
for p in ['stage.py','qualify.py','mutation.py','suites.py','per-file.sh','pair-output.py','common.py','locations.py','run.py','build.log']:shutil.copy(D/p,dest/p)
for k in ('stage','oracle','suites','mutation','per-file'):
 p=D/k;dd=dest/k;dd.mkdir(exist_ok=True)
 for f in p.iterdir():
  if f.suffix in ['.tsv','.json','.txt']:shutil.copy(f,dd/f.name)
 with tarfile.open(dd/'raw.tar.gz','w:gz') as t:
  for f in p.iterdir():
   if f.suffix not in ['.tsv','.json','.o','.txt']:t.add(f,arcname=f.name)
import hashlib
with (dest/'builds.tsv').open('w') as f:
 f.write('mode\trevision\tcompiler-sha256\tcheckout\n')
 for mode,cc in [('control',PRIOR),('candidate',CC)]:
  commit=subprocess.check_output(['git','-C',cc.parent.parent,'rev-parse','HEAD'],text=True).strip()
  f.write(f'{mode}\t{commit}\t{hashlib.sha256(cc.read_bytes()).hexdigest()}\t{cc.parent.parent}\n')
(dest/'implementation.patch').write_bytes(subprocess.check_output(['git','-C',tree,'diff','b352534f2','HEAD']))
rows=list(csv.DictReader((D/'stage/paired.tsv').open(),delimiter='\t'))
lines=['# Record counted-pointer presence without changing existing type-table offsets','', 'The first counted pointer occupies the four unused bytes after TypeTable.last_error. TypeMembers and all existing TypeTable fields retain their original layout. The check is otherwise the same as [96022b764](../96022b764/README.md). The paired local single-core experiment compares this candidate with the optimized original b352534f2 on both source-native compilation and ordinary compilation. [All pairs](stage/paired.tsv), [guarded diagnostic outputs](mutation/results.tsv), [the actual compiler layout](mutation/TypeTable-layout.txt), [all source comparisons](oracle/comparisons.tsv), [checker shards](suites/status.tsv), [implementation against original b352](implementation.patch).','', '| Input | Mode | Counter | Median within-round difference | Rounds lower |','| --- | --- | --- | ---: | ---: |']
for r in rows:lines.append(f"| {r['input']} | {r['scope']} | {r['metric']} | {float(r['median-delta']):,.0f} | {r['faster']}/{r['rounds']} |")
(dest/'README.md').write_text('\n'.join(lines)+'\n')
