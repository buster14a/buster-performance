# Record counted-pointer presence without changing existing type-table offsets

The first counted pointer occupies the four unused bytes after TypeTable.last_error. TypeMembers and all existing TypeTable fields retain their original layout. The check is otherwise the same as [96022b764](../96022b764/README.md). The paired local single-core experiment compares this candidate with the optimized original b352534f2 on both source-native compilation and ordinary compilation. [All pairs](stage/paired.tsv), [guarded diagnostic outputs](mutation/results.tsv), [the actual compiler layout](mutation/TypeTable-layout.txt), [all source comparisons](oracle/comparisons.tsv), [checker shards](suites/status.tsv), [implementation against original b352](implementation.patch).

| Input | Mode | Counter | Median within-round difference | Rounds lower |
| --- | --- | --- | ---: | ---: |
| sqlite | native | ns | -1,338,382 | 5/8 |
| sqlite | ordinary | ns | 809,202 | 4/8 |
| sqlite | native | instructions | -51,939,458 | 4/4 |
| sqlite | native | cycles | 17,845,915 | 2/4 |
| sqlite | ordinary | instructions | 988,412 | 0/4 |
| sqlite | ordinary | cycles | 4,767,764 | 1/4 |
| sqlite | functions | ns | -11,625,920 | 4/5 |
| sqlite | functions | instructions | -51,612,325 | 3/3 |
| sqlite | functions | cycles | -16,293,330 | 3/3 |
| main | native | ns | -10,478,870 | 5/8 |
| main | ordinary | ns | -14,446,267 | 5/8 |
| main | native | instructions | -407,592,268 | 4/4 |
| main | native | cycles | 2,109,928 | 2/4 |
| main | ordinary | instructions | 4,636,232 | 0/4 |
| main | ordinary | cycles | -2,216,114 | 2/4 |
| main | functions | ns | -54,503,628 | 5/5 |
| main | functions | instructions | -410,656,012 | 3/3 |
| main | functions | cycles | -179,174,254 | 3/3 |
