#!/bin/bash
set -eu
cd "$(dirname "$0")"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
python3 optimized.py > optimized.log 2>&1
cp predefines.h ../source-operator-sites/build/
python3 validate.py ../source-operator-sites/build/compiler optimized-run > validate.log
python3 boundary.py > boundary.log 2>&1
bash four.sh > four.log 2>&1
python3 admission.py > admission.log 2>&1
bash corpus.sh sqlite main lua musl > corpus.log 2>&1
bash checker.sh
