from pathlib import Path
import subprocess,csv,hashlib,os,random,sys
d=Path(__file__).resolve().parent;s=d.parent/'switch-inputs';tree=d.parent/'pregraph-warning-study/compiler-source';cc=d.parent/'source-operator-sites/build/compiler'
cases={'sqlite':['-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I'+str(s/'sqlite'),s/'sqlite/sqlite3.c'],
       'main':['-march=native','-I'+str(tree/'src'),'-fwrapv','-funsigned-char','--predefines',d.parent/'proof-predefines.h',tree/'src/buster/compiler/main.c']}
roles={'BUSTER_DIRECT_SOURCE_STATEMENTS':'1'};op=roles|{'BUSTER_DIRECT_OPERATOR_PROGRAM':'1'};arms={'statements':roles,'operators':op}
arms['sites']=op|{'BUSTER_SOURCE_OPERATOR_SITES':'1'}
base={k:v for k,v in os.environ.items() if not k.startswith(('BUSTER_DIRECT_','BUSTER_SOURCE_','BUSTER_CONTROL_','BUSTER_COMPOSE_','BUSTER_OPERATOR_'))};base['BUSTER_DIRECT_GRAPH_CENSUS']='1'
cost=(d/'parts.tsv').open('w',buffering=1);cost.write('unit\tround\tarm\tpart\tcalls\tselected\tticks\n')
with (d/'admission.tsv').open('w',buffering=1) as f:
 w=csv.writer(f,delimiter='\t');w.writerow(['unit','round','position','arm','ns','exact'])
 for k,args in cases.items():
  ref=hashlib.sha256((d/'optimized-run'/(k+'.ordinary.o')).read_bytes()).digest();out=d/'admission.o'
  for r in range(8):
   order=list(arms);random.Random(4212+r).shuffle(order)
   for pos,m in enumerate(order):
    p=subprocess.run([cc,'--lanes','1','-c',*args,'-o',out],env=base|arms[m]|({'BUSTER_SOURCE_OPERATOR_PROFILE':'1'} if r>=4 else {}),capture_output=True,check=True)
    line=next(l for l in p.stderr.splitlines() if l.startswith(b'source-statement-roles\t'));w.writerow([k,r,pos,m,int(line.split(b'\t')[-1]),ref==hashlib.sha256(out.read_bytes()).digest()])
    for l in p.stderr.decode().splitlines():
     if l.startswith('source-operator-part\t'):cost.write(f'{k}\t{r}\t{m}\t'+l.split('\t',1)[1]+'\n')
