import pathlib,csv,collections,statistics as s
d=pathlib.Path(__file__).resolve().parent
def read(name):return list(csv.DictReader((d/name).open(),delimiter='\t'))
for group in ['sqlite','main']:
 rows=read(group+'-four.tsv')
 for stage in ['ordinary','check-input.expressions','total']:
  times=collections.defaultdict(dict)
  for x in rows:
   assert x['equal']=='True'
   if x['stage']==stage:times[x['policy']][int(x['round'])]=int(x['ns'])/1e6
  if times:
   print(group,stage,{k:round(s.median(v.values()),3) for k,v in times.items()})
   for k in ['operators','ordinary']:
    diff=[v-times[k][r] for r,v in times['sites'].items()]
    print('sites vs',k,round(s.median(diff),3),'ms',sum(x<0 for x in diff),'of',len(diff))
 for cost in ['simple','instrumented']:
  a=collections.defaultdict(list)
  for x in read('admission.tsv'):
   assert x['exact']=='True'
   if x['unit']==group and (int(x['round'])>=4)==(cost=='instrumented'):a[x['arm']].append(int(x['ns'])/1e6)
  print(group,'admission',cost,{k:round(s.median(v),3) for k,v in a.items()})
 for x in ['operators','sites']:
  parts=collections.defaultdict(list)
  for row in read('parts.tsv'):
   if row['unit']==group and row['arm']==x:parts[(row['part'],row['calls'],row['selected'])].append(int(row['ticks']))
  print(group,x,'component median ticks',{k:int(s.median(v)) for k,v in parts.items()})
