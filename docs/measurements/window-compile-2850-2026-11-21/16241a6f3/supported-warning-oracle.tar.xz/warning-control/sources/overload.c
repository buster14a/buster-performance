typedef unsigned long T;typedef char C;typedef struct Tagged{int v;}S;typedef int *P;typedef int Fn(int);typedef int Arr[4];typedef int Aligned __attribute__((aligned(16)));typedef int *Node __attribute__((noderef));typedef volatile int V;typedef int VOL;typedef const int RV;enum E { A=1 };
__attribute__((overloadable)) int f(T*); __attribute__((overloadable)) int f(C*);
