typedef int T __attribute__((deprecated));typedef int G __attribute__((address_space(1)));typedef int Fn(int) __attribute__((ms_abi));extern int a(T*,G*,Fn*);int go(void){return 0;}
