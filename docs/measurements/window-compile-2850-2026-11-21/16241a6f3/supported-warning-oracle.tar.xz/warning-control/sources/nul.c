int f(void *); int g(void **); int h(void); int body(void){return h();}
