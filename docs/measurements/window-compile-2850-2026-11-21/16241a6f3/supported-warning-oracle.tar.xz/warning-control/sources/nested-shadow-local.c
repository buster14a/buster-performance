typedef int T; int f(T a){typedef long T;T b=9;{typedef char T; T x=3;b+=x;}return a+b;}int main(void){return f(5)!=17;}
