typedef unsigned long T;typedef char C;typedef struct Tagged{int v;}S;typedef int *P;typedef int Fn(int);typedef int Arr[4];typedef int Aligned __attribute__((aligned(16)));typedef int *Node __attribute__((noderef));typedef volatile int V;typedef int VOL;typedef const int RV;enum E { A=1 };
static int outer(int n){{int x=1; n+=x;}{signed char x[2];}return n;}int main(void){return outer(3)!=4;}
