int n;void go(int*p){n+=*p;}int run(void){int k __attribute__((cleanup(go)))=3;return 0;}int main(void){run();return n!=3;}
