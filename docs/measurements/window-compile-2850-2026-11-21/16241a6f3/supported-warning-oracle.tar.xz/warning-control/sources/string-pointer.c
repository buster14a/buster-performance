const char *f(const char *s){const char *p=s;return p+1;}int main(void){return *f("abc")!=98;}
