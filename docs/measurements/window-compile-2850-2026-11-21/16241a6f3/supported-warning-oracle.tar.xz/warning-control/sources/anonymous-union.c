typedef union {long a; int b;} U; int f(U *u,U x){U *p=u; U a=x;return p->b + a.b;}
