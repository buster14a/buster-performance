typedef unsigned long T;typedef char C;typedef struct Tagged{int v;}S;typedef int *P;typedef int Fn(int);typedef int Arr[4];typedef int Aligned __attribute__((aligned(16)));typedef int *Node __attribute__((noderef));typedef volatile int V;typedef int VOL;typedef const int RV;enum E { A=1 };
int f(C*,T*,int);int f(char*,unsigned long*,int);int f(char *c,T *x,int k){return c[k]+*x;}
int main(void){char s[]={2,9};T x=7;return f(s,&x,1)!=16;}
