typedef int Global __attribute__((address_space(1))); Global *f(Global *p){Global *q=p;return q;}
