int f(int a,double a){return 4;}
