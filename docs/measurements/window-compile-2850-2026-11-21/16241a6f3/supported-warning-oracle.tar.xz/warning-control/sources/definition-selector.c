typedef struct S {int k;} S;extern int f(const S*,int);int f(const S *p,int k){return p->k+k;}int main(void){S p={8};return f(&p,4)!=12;}
