int f(int, int n, const char *) { int x = n; return x; }
