typedef int T;int f(int T,int value){int a=T;{typedef long T;T x=value;a+=x;}return a;}int main(void){return f(2,6)!=8;}
