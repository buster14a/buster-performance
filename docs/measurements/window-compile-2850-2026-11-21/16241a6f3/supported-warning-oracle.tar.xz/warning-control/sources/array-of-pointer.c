typedef int T; int f(int n,int **p){T *q[3];q[0]=*p;return *q[0];}
