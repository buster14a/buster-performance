int f(int n){typedef int A[n]; A x; x[0]=n; return x[0];}int main(void){return f(4)!=4;}
