int f(void){int *x=0, a=5,b=a+8;return b;}int main(void){return f()!=13;}
