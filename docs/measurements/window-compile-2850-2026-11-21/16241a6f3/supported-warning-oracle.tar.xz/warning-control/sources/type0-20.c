typedef unsigned long T;typedef char C;typedef struct Tagged{int v;}S;typedef int *P;typedef int Fn(int);typedef int Arr[4];typedef int Aligned __attribute__((aligned(16)));typedef int *Node __attribute__((noderef));typedef volatile int V;typedef int VOL;typedef const int RV;enum E { A=1 };
extern int fn0(int wrong[0]);
static int local0(int wrong[0]);
extern int two0(int,int wrong[0]);
extern int three0(int wrong[0],int);
extern int fn1(typeof(int));
static int local1(typeof(int));
extern int two1(int,typeof(int));
extern int three1(typeof(int),int);
extern int fn2(int __attribute__((ns_consumed)));
static int local2(int __attribute__((ns_consumed)));
extern int two2(int,int __attribute__((ns_consumed)));
extern int three2(int __attribute__((ns_consumed)),int);
int go(void){return 0;}
