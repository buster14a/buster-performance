typedef signed char C; C *f(C *p){C *q=p;return q;}int main(void){C c=-4;return *f(&c)!=-4;}
