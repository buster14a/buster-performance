typedef struct Missing Incomplete;void f(Incomplete *p){Incomplete x;Incomplete *q=p;}
