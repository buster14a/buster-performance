typedef int T; void f(int p) {extern T g;extern long g; int a; double a; int p; }
