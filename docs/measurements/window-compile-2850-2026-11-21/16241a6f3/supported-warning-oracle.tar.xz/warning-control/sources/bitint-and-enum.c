typedef _BitInt(41) Wide;typedef enum V{A=2} V;int f(Wide a,V v){Wide w=a+v;V x=A;return w+x;}
