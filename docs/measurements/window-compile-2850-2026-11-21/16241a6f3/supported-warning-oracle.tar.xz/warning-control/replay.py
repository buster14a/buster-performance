from pathlib import Path
import csv,hashlib,subprocess,sys,tempfile
root=Path(__file__).resolve().parent
compilers=[Path(v).resolve() for v in sys.argv[1:]];assert len(compilers)==2
rows=list(csv.DictReader((root/'results.tsv').open(),delimiter='\t'))
with tempfile.TemporaryDirectory() as tmp:
 for row in rows:
  data=[];src=root/'sources'/(row['source']+'.c');obj=Path(tmp)/'unit.o'
  for cc in compilers:
   obj.unlink(missing_ok=True)
   r=subprocess.run([cc,row['dialect'],'-c','-Wall','-Wextra','-ferror-limit=0',src,'-o',obj],capture_output=True)
   assert b'unsupported warning option' not in r.stderr and b'usage: compiler' not in r.stderr
   data.append((r.returncode,r.stdout,r.stderr,obj.read_bytes() if obj.exists() else b''))
  assert data[0]==data[1] and data[1][0]==int(row['status']),row['source']
print(len(rows),'paired source-policy results matched')
