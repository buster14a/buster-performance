from pathlib import Path
import subprocess as sp,csv,statistics
w=Path(__file__).resolve().parent.parent;d=w/'packed-declaration-study';src=w/'switch-inputs/sqlite/sqlite3.c';cc=[w/'main-fbef-clean/build/compiler',w/'packed-declaration-records/build/compiler'];records=[]
with (d/'pmu.tsv').open('w',buffering=1) as f:
 wr=csv.writer(f,delimiter='\t');wr.writerow(['case','pair','image','instructions','cycles']);
 for tag,args in [('sqlite',['-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I'+str(src.parent),src]),('accepted',[d/'prototypes-admitted.c']),('refused',[d/'prototypes-named.c']),('mixed',[d/'prototypes-mixed.c'])]:
  deltas=[]
  for i in range(12):
   vals={}
   for n in ([0,1] if i%2==0 else [1,0]):
    r=sp.run(['perf','stat','-x,','--no-big-num','-e','{instructions:u,cycles:u}','--',cc[n],'-c',*args,'-o',d/'perf.o'],capture_output=True,timeout=30);assert r.returncode==0,r.stderr;ev={l.split(',')[2].split(':')[0]:int(l.split(',')[0]) for l in r.stderr.decode().splitlines() if ',,instructions:u,' in l or ',,cycles:u,' in l};assert 'instructions' in ev,(r.stderr,ev);vals[n]=ev;wr.writerow([tag,i,['ref','candidate'][n],ev['instructions'],ev['cycles']]);
   deltas.append((vals[1]['instructions']-vals[0]['instructions'],vals[1]['cycles']-vals[0]['cycles']))
  print(tag,'paired med instructions',statistics.median(a for a,b in deltas),'paired med cycles',statistics.median(b for a,b in deltas),'cycle wins',sum(b<0 for a,b in deltas),'n',len(deltas),flush=True)
