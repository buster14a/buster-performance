#!/bin/bash
set -eu
cd "$(dirname "$0")/../packed-declaration-records"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >../packed-declaration-study/build.log 2>&1
cp ../main-fbef-clean/build/predefines.h build/predefines.h
cd ../switch-inputs
source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
BUSTER_DECLARATION_CENSUS=1 ../packed-declaration-records/build/compiler -c -o ../packed-declaration-study/sqlite.candidate.o "${args[@]}" >../packed-declaration-study/sqlite.out 2>../packed-declaration-study/counter.txt
../main-fbef-clean/build/compiler -c -o ../packed-declaration-study/sqlite.parent.o "${args[@]}" >../packed-declaration-study/parent.out 2>../packed-declaration-study/parent.err
cmp ../packed-declaration-study/sqlite.candidate.o ../packed-declaration-study/sqlite.parent.o
python3 ../packed-declaration-study/oracle.py >../packed-declaration-study/oracle.log 2>&1
python3 ../packed-declaration-study/local_pairs.py >../packed-declaration-study/pairs.log 2>&1
python3 ../packed-declaration-study/target_pairs.py >../packed-declaration-study/target.log 2>&1
parent=$PWD/../main-fbef-clean/build/compiler
new=$PWD/../packed-declaration-records/build/compiler
out=$PWD/../packed-declaration-study/corpus
mkdir -p "$out"
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main lua musl; do var=${g}_arguments; eval "args=(${!var})"; python3 ../default-object-qa/pair.py "$out" "$g" "$parent" "$new" "${args[@]}"; done
python3 ../packed-declaration-study/pmu.py >../packed-declaration-study/pmu.log 2>&1
cd ../packed-declaration-records
for part in {1..8}; do ./build/compiler test-checker --seed 2850 --part "$part/8" >"../packed-declaration-study/checker-$part.log" 2>&1; done
