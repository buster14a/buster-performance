#!/bin/bash
export BUSTER_CONTROL_SOURCE_NATIVE=1
unset BUSTER_SOURCE_ARITHMETIC
exec /home/david/Documents/Codex/2026-11-21/g/work/source-sparse-proof-study/../source-sparse-proof/build/compiler "$@"
