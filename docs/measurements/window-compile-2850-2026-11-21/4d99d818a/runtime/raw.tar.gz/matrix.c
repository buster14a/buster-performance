extern int printf(const char *,...);
typedef unsigned long long U;
__attribute__((noinline)) static U f0_0(_Bool x,_Bool y){_Bool a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_1(_Bool x,char y){_Bool a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_2(_Bool x,signed char y){_Bool a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_3(_Bool x,unsigned char y){_Bool a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_4(_Bool x,short y){_Bool a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_5(_Bool x,unsigned short y){_Bool a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_6(_Bool x,int y){_Bool a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_7(_Bool x,unsigned y){_Bool a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_8(_Bool x,long y){_Bool a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_9(_Bool x,unsigned long y){_Bool a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_10(_Bool x,long long y){_Bool a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_11(_Bool x,unsigned long long y){_Bool a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_12(_Bool x,__int128 y){_Bool a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f0_13(_Bool x,unsigned __int128 y){_Bool a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_0(char x,_Bool y){char a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_1(char x,char y){char a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_2(char x,signed char y){char a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_3(char x,unsigned char y){char a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_4(char x,short y){char a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_5(char x,unsigned short y){char a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_6(char x,int y){char a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_7(char x,unsigned y){char a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_8(char x,long y){char a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_9(char x,unsigned long y){char a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_10(char x,long long y){char a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_11(char x,unsigned long long y){char a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_12(char x,__int128 y){char a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f1_13(char x,unsigned __int128 y){char a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_0(signed char x,_Bool y){signed char a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_1(signed char x,char y){signed char a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_2(signed char x,signed char y){signed char a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_3(signed char x,unsigned char y){signed char a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_4(signed char x,short y){signed char a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_5(signed char x,unsigned short y){signed char a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_6(signed char x,int y){signed char a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_7(signed char x,unsigned y){signed char a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_8(signed char x,long y){signed char a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_9(signed char x,unsigned long y){signed char a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_10(signed char x,long long y){signed char a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_11(signed char x,unsigned long long y){signed char a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_12(signed char x,__int128 y){signed char a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f2_13(signed char x,unsigned __int128 y){signed char a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_0(unsigned char x,_Bool y){unsigned char a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_1(unsigned char x,char y){unsigned char a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_2(unsigned char x,signed char y){unsigned char a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_3(unsigned char x,unsigned char y){unsigned char a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_4(unsigned char x,short y){unsigned char a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_5(unsigned char x,unsigned short y){unsigned char a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_6(unsigned char x,int y){unsigned char a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_7(unsigned char x,unsigned y){unsigned char a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_8(unsigned char x,long y){unsigned char a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_9(unsigned char x,unsigned long y){unsigned char a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_10(unsigned char x,long long y){unsigned char a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_11(unsigned char x,unsigned long long y){unsigned char a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_12(unsigned char x,__int128 y){unsigned char a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f3_13(unsigned char x,unsigned __int128 y){unsigned char a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_0(short x,_Bool y){short a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_1(short x,char y){short a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_2(short x,signed char y){short a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_3(short x,unsigned char y){short a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_4(short x,short y){short a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_5(short x,unsigned short y){short a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_6(short x,int y){short a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_7(short x,unsigned y){short a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_8(short x,long y){short a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_9(short x,unsigned long y){short a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_10(short x,long long y){short a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_11(short x,unsigned long long y){short a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_12(short x,__int128 y){short a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f4_13(short x,unsigned __int128 y){short a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_0(unsigned short x,_Bool y){unsigned short a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_1(unsigned short x,char y){unsigned short a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_2(unsigned short x,signed char y){unsigned short a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_3(unsigned short x,unsigned char y){unsigned short a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_4(unsigned short x,short y){unsigned short a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_5(unsigned short x,unsigned short y){unsigned short a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_6(unsigned short x,int y){unsigned short a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_7(unsigned short x,unsigned y){unsigned short a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_8(unsigned short x,long y){unsigned short a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_9(unsigned short x,unsigned long y){unsigned short a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_10(unsigned short x,long long y){unsigned short a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_11(unsigned short x,unsigned long long y){unsigned short a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_12(unsigned short x,__int128 y){unsigned short a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f5_13(unsigned short x,unsigned __int128 y){unsigned short a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_0(int x,_Bool y){int a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_1(int x,char y){int a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_2(int x,signed char y){int a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_3(int x,unsigned char y){int a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_4(int x,short y){int a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_5(int x,unsigned short y){int a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_6(int x,int y){int a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_7(int x,unsigned y){int a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_8(int x,long y){int a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_9(int x,unsigned long y){int a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_10(int x,long long y){int a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_11(int x,unsigned long long y){int a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_12(int x,__int128 y){int a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f6_13(int x,unsigned __int128 y){int a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_0(unsigned x,_Bool y){unsigned a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_1(unsigned x,char y){unsigned a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_2(unsigned x,signed char y){unsigned a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_3(unsigned x,unsigned char y){unsigned a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_4(unsigned x,short y){unsigned a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_5(unsigned x,unsigned short y){unsigned a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_6(unsigned x,int y){unsigned a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_7(unsigned x,unsigned y){unsigned a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_8(unsigned x,long y){unsigned a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_9(unsigned x,unsigned long y){unsigned a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_10(unsigned x,long long y){unsigned a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_11(unsigned x,unsigned long long y){unsigned a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_12(unsigned x,__int128 y){unsigned a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f7_13(unsigned x,unsigned __int128 y){unsigned a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_0(long x,_Bool y){long a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_1(long x,char y){long a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_2(long x,signed char y){long a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_3(long x,unsigned char y){long a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_4(long x,short y){long a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_5(long x,unsigned short y){long a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_6(long x,int y){long a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_7(long x,unsigned y){long a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_8(long x,long y){long a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_9(long x,unsigned long y){long a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_10(long x,long long y){long a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_11(long x,unsigned long long y){long a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_12(long x,__int128 y){long a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f8_13(long x,unsigned __int128 y){long a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_0(unsigned long x,_Bool y){unsigned long a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_1(unsigned long x,char y){unsigned long a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_2(unsigned long x,signed char y){unsigned long a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_3(unsigned long x,unsigned char y){unsigned long a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_4(unsigned long x,short y){unsigned long a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_5(unsigned long x,unsigned short y){unsigned long a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_6(unsigned long x,int y){unsigned long a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_7(unsigned long x,unsigned y){unsigned long a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_8(unsigned long x,long y){unsigned long a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_9(unsigned long x,unsigned long y){unsigned long a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_10(unsigned long x,long long y){unsigned long a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_11(unsigned long x,unsigned long long y){unsigned long a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_12(unsigned long x,__int128 y){unsigned long a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f9_13(unsigned long x,unsigned __int128 y){unsigned long a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_0(long long x,_Bool y){long long a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_1(long long x,char y){long long a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_2(long long x,signed char y){long long a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_3(long long x,unsigned char y){long long a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_4(long long x,short y){long long a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_5(long long x,unsigned short y){long long a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_6(long long x,int y){long long a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_7(long long x,unsigned y){long long a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_8(long long x,long y){long long a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_9(long long x,unsigned long y){long long a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_10(long long x,long long y){long long a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_11(long long x,unsigned long long y){long long a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_12(long long x,__int128 y){long long a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f10_13(long long x,unsigned __int128 y){long long a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_0(unsigned long long x,_Bool y){unsigned long long a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_1(unsigned long long x,char y){unsigned long long a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_2(unsigned long long x,signed char y){unsigned long long a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_3(unsigned long long x,unsigned char y){unsigned long long a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_4(unsigned long long x,short y){unsigned long long a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_5(unsigned long long x,unsigned short y){unsigned long long a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_6(unsigned long long x,int y){unsigned long long a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_7(unsigned long long x,unsigned y){unsigned long long a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_8(unsigned long long x,long y){unsigned long long a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_9(unsigned long long x,unsigned long y){unsigned long long a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_10(unsigned long long x,long long y){unsigned long long a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_11(unsigned long long x,unsigned long long y){unsigned long long a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_12(unsigned long long x,__int128 y){unsigned long long a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f11_13(unsigned long long x,unsigned __int128 y){unsigned long long a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_0(__int128 x,_Bool y){__int128 a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_1(__int128 x,char y){__int128 a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_2(__int128 x,signed char y){__int128 a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_3(__int128 x,unsigned char y){__int128 a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_4(__int128 x,short y){__int128 a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_5(__int128 x,unsigned short y){__int128 a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_6(__int128 x,int y){__int128 a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_7(__int128 x,unsigned y){__int128 a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_8(__int128 x,long y){__int128 a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_9(__int128 x,unsigned long y){__int128 a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_10(__int128 x,long long y){__int128 a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_11(__int128 x,unsigned long long y){__int128 a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_12(__int128 x,__int128 y){__int128 a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f12_13(__int128 x,unsigned __int128 y){__int128 a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_0(unsigned __int128 x,_Bool y){unsigned __int128 a=x;_Bool b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_1(unsigned __int128 x,char y){unsigned __int128 a=x;char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_2(unsigned __int128 x,signed char y){unsigned __int128 a=x;signed char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_3(unsigned __int128 x,unsigned char y){unsigned __int128 a=x;unsigned char b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_4(unsigned __int128 x,short y){unsigned __int128 a=x;short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_5(unsigned __int128 x,unsigned short y){unsigned __int128 a=x;unsigned short b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_6(unsigned __int128 x,int y){unsigned __int128 a=x;int b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_7(unsigned __int128 x,unsigned y){unsigned __int128 a=x;unsigned b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_8(unsigned __int128 x,long y){unsigned __int128 a=x;long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_9(unsigned __int128 x,unsigned long y){unsigned __int128 a=x;unsigned long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_10(unsigned __int128 x,long long y){unsigned __int128 a=x;long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_11(unsigned __int128 x,unsigned long long y){unsigned __int128 a=x;unsigned long long b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_12(unsigned __int128 x,__int128 y){unsigned __int128 a=x;__int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
__attribute__((noinline)) static U f13_13(unsigned __int128 x,unsigned __int128 y){unsigned __int128 a=x;unsigned __int128 b=y; a=b; b=x; return (U)(a+b) ^ ((U)(x<y)<<6) ^ (U)(x^b) ^ ((U)(x>=a)<<4) ^ ((U)!a<<5) ^ (U)(x*y) ^ (U)(~x) ^ ((U)(x&&y)<<24);}
int main(int argc,char**argv){U h=(U)argc;
h=h*1099511628211ULL ^ f0_0((_Bool)(argc+1),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f0_1((_Bool)(argc+1),(char)(2*argc+5));
h=h*1099511628211ULL ^ f0_2((_Bool)(argc+1),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f0_3((_Bool)(argc+1),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f0_4((_Bool)(argc+1),(short)(2*argc+8));
h=h*1099511628211ULL ^ f0_5((_Bool)(argc+1),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f0_6((_Bool)(argc+1),(int)(2*argc+10));
h=h*1099511628211ULL ^ f0_7((_Bool)(argc+1),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f0_8((_Bool)(argc+1),(long)(2*argc+12));
h=h*1099511628211ULL ^ f0_9((_Bool)(argc+1),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f0_10((_Bool)(argc+1),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f0_11((_Bool)(argc+1),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f0_12((_Bool)(argc+1),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f0_13((_Bool)(argc+1),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f1_0((char)(argc+2),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f1_1((char)(argc+2),(char)(2*argc+5));
h=h*1099511628211ULL ^ f1_2((char)(argc+2),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f1_3((char)(argc+2),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f1_4((char)(argc+2),(short)(2*argc+8));
h=h*1099511628211ULL ^ f1_5((char)(argc+2),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f1_6((char)(argc+2),(int)(2*argc+10));
h=h*1099511628211ULL ^ f1_7((char)(argc+2),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f1_8((char)(argc+2),(long)(2*argc+12));
h=h*1099511628211ULL ^ f1_9((char)(argc+2),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f1_10((char)(argc+2),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f1_11((char)(argc+2),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f1_12((char)(argc+2),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f1_13((char)(argc+2),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f2_0((signed char)(argc+3),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f2_1((signed char)(argc+3),(char)(2*argc+5));
h=h*1099511628211ULL ^ f2_2((signed char)(argc+3),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f2_3((signed char)(argc+3),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f2_4((signed char)(argc+3),(short)(2*argc+8));
h=h*1099511628211ULL ^ f2_5((signed char)(argc+3),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f2_6((signed char)(argc+3),(int)(2*argc+10));
h=h*1099511628211ULL ^ f2_7((signed char)(argc+3),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f2_8((signed char)(argc+3),(long)(2*argc+12));
h=h*1099511628211ULL ^ f2_9((signed char)(argc+3),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f2_10((signed char)(argc+3),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f2_11((signed char)(argc+3),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f2_12((signed char)(argc+3),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f2_13((signed char)(argc+3),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f3_0((unsigned char)(argc+4),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f3_1((unsigned char)(argc+4),(char)(2*argc+5));
h=h*1099511628211ULL ^ f3_2((unsigned char)(argc+4),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f3_3((unsigned char)(argc+4),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f3_4((unsigned char)(argc+4),(short)(2*argc+8));
h=h*1099511628211ULL ^ f3_5((unsigned char)(argc+4),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f3_6((unsigned char)(argc+4),(int)(2*argc+10));
h=h*1099511628211ULL ^ f3_7((unsigned char)(argc+4),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f3_8((unsigned char)(argc+4),(long)(2*argc+12));
h=h*1099511628211ULL ^ f3_9((unsigned char)(argc+4),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f3_10((unsigned char)(argc+4),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f3_11((unsigned char)(argc+4),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f3_12((unsigned char)(argc+4),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f3_13((unsigned char)(argc+4),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f4_0((short)(argc+5),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f4_1((short)(argc+5),(char)(2*argc+5));
h=h*1099511628211ULL ^ f4_2((short)(argc+5),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f4_3((short)(argc+5),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f4_4((short)(argc+5),(short)(2*argc+8));
h=h*1099511628211ULL ^ f4_5((short)(argc+5),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f4_6((short)(argc+5),(int)(2*argc+10));
h=h*1099511628211ULL ^ f4_7((short)(argc+5),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f4_8((short)(argc+5),(long)(2*argc+12));
h=h*1099511628211ULL ^ f4_9((short)(argc+5),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f4_10((short)(argc+5),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f4_11((short)(argc+5),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f4_12((short)(argc+5),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f4_13((short)(argc+5),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f5_0((unsigned short)(argc+6),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f5_1((unsigned short)(argc+6),(char)(2*argc+5));
h=h*1099511628211ULL ^ f5_2((unsigned short)(argc+6),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f5_3((unsigned short)(argc+6),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f5_4((unsigned short)(argc+6),(short)(2*argc+8));
h=h*1099511628211ULL ^ f5_5((unsigned short)(argc+6),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f5_6((unsigned short)(argc+6),(int)(2*argc+10));
h=h*1099511628211ULL ^ f5_7((unsigned short)(argc+6),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f5_8((unsigned short)(argc+6),(long)(2*argc+12));
h=h*1099511628211ULL ^ f5_9((unsigned short)(argc+6),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f5_10((unsigned short)(argc+6),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f5_11((unsigned short)(argc+6),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f5_12((unsigned short)(argc+6),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f5_13((unsigned short)(argc+6),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f6_0((int)(argc+7),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f6_1((int)(argc+7),(char)(2*argc+5));
h=h*1099511628211ULL ^ f6_2((int)(argc+7),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f6_3((int)(argc+7),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f6_4((int)(argc+7),(short)(2*argc+8));
h=h*1099511628211ULL ^ f6_5((int)(argc+7),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f6_6((int)(argc+7),(int)(2*argc+10));
h=h*1099511628211ULL ^ f6_7((int)(argc+7),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f6_8((int)(argc+7),(long)(2*argc+12));
h=h*1099511628211ULL ^ f6_9((int)(argc+7),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f6_10((int)(argc+7),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f6_11((int)(argc+7),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f6_12((int)(argc+7),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f6_13((int)(argc+7),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f7_0((unsigned)(argc+8),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f7_1((unsigned)(argc+8),(char)(2*argc+5));
h=h*1099511628211ULL ^ f7_2((unsigned)(argc+8),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f7_3((unsigned)(argc+8),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f7_4((unsigned)(argc+8),(short)(2*argc+8));
h=h*1099511628211ULL ^ f7_5((unsigned)(argc+8),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f7_6((unsigned)(argc+8),(int)(2*argc+10));
h=h*1099511628211ULL ^ f7_7((unsigned)(argc+8),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f7_8((unsigned)(argc+8),(long)(2*argc+12));
h=h*1099511628211ULL ^ f7_9((unsigned)(argc+8),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f7_10((unsigned)(argc+8),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f7_11((unsigned)(argc+8),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f7_12((unsigned)(argc+8),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f7_13((unsigned)(argc+8),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f8_0((long)(argc+9),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f8_1((long)(argc+9),(char)(2*argc+5));
h=h*1099511628211ULL ^ f8_2((long)(argc+9),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f8_3((long)(argc+9),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f8_4((long)(argc+9),(short)(2*argc+8));
h=h*1099511628211ULL ^ f8_5((long)(argc+9),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f8_6((long)(argc+9),(int)(2*argc+10));
h=h*1099511628211ULL ^ f8_7((long)(argc+9),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f8_8((long)(argc+9),(long)(2*argc+12));
h=h*1099511628211ULL ^ f8_9((long)(argc+9),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f8_10((long)(argc+9),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f8_11((long)(argc+9),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f8_12((long)(argc+9),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f8_13((long)(argc+9),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f9_0((unsigned long)(argc+10),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f9_1((unsigned long)(argc+10),(char)(2*argc+5));
h=h*1099511628211ULL ^ f9_2((unsigned long)(argc+10),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f9_3((unsigned long)(argc+10),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f9_4((unsigned long)(argc+10),(short)(2*argc+8));
h=h*1099511628211ULL ^ f9_5((unsigned long)(argc+10),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f9_6((unsigned long)(argc+10),(int)(2*argc+10));
h=h*1099511628211ULL ^ f9_7((unsigned long)(argc+10),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f9_8((unsigned long)(argc+10),(long)(2*argc+12));
h=h*1099511628211ULL ^ f9_9((unsigned long)(argc+10),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f9_10((unsigned long)(argc+10),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f9_11((unsigned long)(argc+10),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f9_12((unsigned long)(argc+10),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f9_13((unsigned long)(argc+10),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f10_0((long long)(argc+11),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f10_1((long long)(argc+11),(char)(2*argc+5));
h=h*1099511628211ULL ^ f10_2((long long)(argc+11),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f10_3((long long)(argc+11),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f10_4((long long)(argc+11),(short)(2*argc+8));
h=h*1099511628211ULL ^ f10_5((long long)(argc+11),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f10_6((long long)(argc+11),(int)(2*argc+10));
h=h*1099511628211ULL ^ f10_7((long long)(argc+11),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f10_8((long long)(argc+11),(long)(2*argc+12));
h=h*1099511628211ULL ^ f10_9((long long)(argc+11),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f10_10((long long)(argc+11),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f10_11((long long)(argc+11),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f10_12((long long)(argc+11),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f10_13((long long)(argc+11),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f11_0((unsigned long long)(argc+12),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f11_1((unsigned long long)(argc+12),(char)(2*argc+5));
h=h*1099511628211ULL ^ f11_2((unsigned long long)(argc+12),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f11_3((unsigned long long)(argc+12),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f11_4((unsigned long long)(argc+12),(short)(2*argc+8));
h=h*1099511628211ULL ^ f11_5((unsigned long long)(argc+12),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f11_6((unsigned long long)(argc+12),(int)(2*argc+10));
h=h*1099511628211ULL ^ f11_7((unsigned long long)(argc+12),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f11_8((unsigned long long)(argc+12),(long)(2*argc+12));
h=h*1099511628211ULL ^ f11_9((unsigned long long)(argc+12),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f11_10((unsigned long long)(argc+12),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f11_11((unsigned long long)(argc+12),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f11_12((unsigned long long)(argc+12),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f11_13((unsigned long long)(argc+12),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f12_0((__int128)(argc+13),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f12_1((__int128)(argc+13),(char)(2*argc+5));
h=h*1099511628211ULL ^ f12_2((__int128)(argc+13),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f12_3((__int128)(argc+13),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f12_4((__int128)(argc+13),(short)(2*argc+8));
h=h*1099511628211ULL ^ f12_5((__int128)(argc+13),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f12_6((__int128)(argc+13),(int)(2*argc+10));
h=h*1099511628211ULL ^ f12_7((__int128)(argc+13),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f12_8((__int128)(argc+13),(long)(2*argc+12));
h=h*1099511628211ULL ^ f12_9((__int128)(argc+13),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f12_10((__int128)(argc+13),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f12_11((__int128)(argc+13),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f12_12((__int128)(argc+13),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f12_13((__int128)(argc+13),(unsigned __int128)(2*argc+17));
h=h*1099511628211ULL ^ f13_0((unsigned __int128)(argc+14),(_Bool)(2*argc+4));
h=h*1099511628211ULL ^ f13_1((unsigned __int128)(argc+14),(char)(2*argc+5));
h=h*1099511628211ULL ^ f13_2((unsigned __int128)(argc+14),(signed char)(2*argc+6));
h=h*1099511628211ULL ^ f13_3((unsigned __int128)(argc+14),(unsigned char)(2*argc+7));
h=h*1099511628211ULL ^ f13_4((unsigned __int128)(argc+14),(short)(2*argc+8));
h=h*1099511628211ULL ^ f13_5((unsigned __int128)(argc+14),(unsigned short)(2*argc+9));
h=h*1099511628211ULL ^ f13_6((unsigned __int128)(argc+14),(int)(2*argc+10));
h=h*1099511628211ULL ^ f13_7((unsigned __int128)(argc+14),(unsigned)(2*argc+11));
h=h*1099511628211ULL ^ f13_8((unsigned __int128)(argc+14),(long)(2*argc+12));
h=h*1099511628211ULL ^ f13_9((unsigned __int128)(argc+14),(unsigned long)(2*argc+13));
h=h*1099511628211ULL ^ f13_10((unsigned __int128)(argc+14),(long long)(2*argc+14));
h=h*1099511628211ULL ^ f13_11((unsigned __int128)(argc+14),(unsigned long long)(2*argc+15));
h=h*1099511628211ULL ^ f13_12((unsigned __int128)(argc+14),(__int128)(2*argc+16));
h=h*1099511628211ULL ^ f13_13((unsigned __int128)(argc+14),(unsigned __int128)(2*argc+17));
printf("%llu\n",h);return 0;}
