set pagination off
set confirm off
set debuginfod enabled off
set $seen=0
break *0x00000000013c1810
commands
silent
set $seen=$seen+1
if $seen == 1
printf "FIRST_ROW %u STORE %u\n", $ecx, $r8d
end
continue
end
run
printf "ROW_CALLS %u\n", $seen
