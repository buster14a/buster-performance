extern int printf(const char*,...);
int f(int a,int b){return (a+b) ^ (b*3);}
int main(int argc,char**v){int r=f(argc+13,argc+5);printf("%d\n",r);return 0;}
