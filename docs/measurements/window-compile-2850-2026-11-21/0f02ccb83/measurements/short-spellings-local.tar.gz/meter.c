#include "buster/compiler/c_refine_benchmark.c"
int main(int argc, char** argv)
{
    Corpus corpus = {0};
    corpus.arena = arena_reserve(BUSTER_REFINE_BENCHMARK_MEMORY);
    corpus.files = arena_push_array(&corpus.arena, 1, sizeof(CorpusFile), 64);
    static InternTable table;
    if (argc != 2 || !intern_initialize(&table) || !refine_benchmark_add_file(&corpus, argv[1], false) || corpus.file_count != 1)
        return 1;
    CorpusFile *f = &corpus.files[0];
    return !refine_tokens(&table, f->bytes, f->length, f->kinds, f->starts, f->pristine_ends, f->count, f->ends, f->space, 0);
}
