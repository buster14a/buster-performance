from pathlib import Path
here=Path(__file__).resolve().parent
d=here/'boundaries';d.mkdir(exist_ok=True)
# Test raw source spellings at every supported byte length, deliberate index collisions,
# 4,096-token block boundaries, the last source word, and ordinary/escaped aliases.
pieces=['a','aa','aaa','aaaa','aaaaa','_','while','else','if','var','v','x','x123','g23','g234','v123',
        'a331','a432','a533','cat','bet','ate','eta','até','β','\\u03b2','a\\\nb','ab','a??/\nb','back_reference_0123456789']
for n in [65535,65536,65537,131071,131072,131073]:
    unit=(' '.join(pieces)+'\n').encode(); body=(unit*(n//len(unit)+1))[:n-8]
    (d/f'bytes-{n}.c').write_bytes(body+b'\n x varz')
for tail in ['x','xx','xxx','xxxx','xxxxa']:
    (d/f'tail-{tail}.c').write_text('a aa aaa aaaa aaaaa x '+'ba aa a a_ '*9000+'\n'+tail)
