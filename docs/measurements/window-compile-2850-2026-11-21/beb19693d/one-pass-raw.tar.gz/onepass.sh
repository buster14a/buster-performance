#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD
cd ../switch-inputs; source ../switch-local-args.sh
case $1 in
fixture) args=(-nostdinc "$d/fixture.c");;
generated) args=(-nostdinc -fwrapv "$d/generated.c");;
sqlite) eval "args=($sqlite_arguments)";;
main) tree=$PWD/../pregraph-warning-study/compiler-source
args=(-march=native -I"$tree/src" -fwrapv -funsigned-char --predefines "$PWD/../proof-predefines.h" "$tree/src/buster/compiler/main.c");;
esac
BUSTER_BODY_SOURCE_NATIVE=1 "$d/compiler" --lanes 1 -c "${args[@]}" -o "$d/$1.native.o" > "$d/$1.native.out" 2> "$d/$1.native"
cmp "$d/$1.o" "$d/$1.native.o"
sha256sum "$d/$1.native.o"
