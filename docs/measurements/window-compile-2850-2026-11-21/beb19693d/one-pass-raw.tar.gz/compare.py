from pathlib import Path
from struct import unpack_from as unpack
import collections,sys
d=Path(__file__).resolve().parent
label=sys.argv[1]
def table(p, tag):
    rows={}
    for line in p.read_text().splitlines():
        fields=line.split('\t')
        if fields[0]=='body-ops-'+tag: rows[int(fields[1])]=fields[2:]
    return rows
def cstr(data,pos):
    return data[pos:data.index(0,pos)].decode()
class Object:
    def __init__(self,data):
        header=unpack('<16sHHIQQQIHHHHHH',data)
        self.sections=sections=[unpack('<IIQQQQIIQQ',data,header[6]+i*header[11]) for i in range(header[12])]
        self.data=data;self.bodies={};self.local={};self.relocations=collections.defaultdict(list); symbols={}
        for i,sec in enumerate(sections):
            if sec[1]!=2: continue
            strs=sections[sec[6]]
            for j in range(0,sec[5],sec[9]):
                name,info,_,section,value,size=unpack('<IBBHQQ',data,sec[4]+j)
                name=cstr(data,strs[4]+name)
                symbols[i,j//sec[9]]=name if (info&15)!=3 else ("section",section)
                if section and (info&15)==2 and size:
                    self.bodies[name]=(section,value,size)
                    if (info>>4)==0: self.local[name]=(section,value)
        for sec in sections:
            if sec[1]!=4: continue
            for j in range(0,sec[5],sec[9]):
                offset,info,addend=unpack('<QQq',data,sec[4]+j)
                self.relocations[sec[7]].append((offset,info&0xffffffff,addend,symbols[sec[6],info>>32]))
    def function(self,name):
        section,value,size=self.bodies[name];base=self.sections[section][4]+value
        rels=[(offset-value,kind,addend,target) for offset,kind,addend,target in self.relocations[section] if value<=offset<value+size]
        return self.data[base:base+size].hex(),rels
    def agrees(self,name,machine,expected):
        code,actual=self.function(name)
        if code!=machine or len(actual)!=len(expected):return False
        for (o,k,a,t),(eo,ek,ea,et) in zip(actual,expected):
            if (o,k)!=(eo,ek):return False
            if isinstance(t,tuple) and et in self.local:
                sec,base=self.local[et]
                if t!=("section",sec) or a!=base+ea:return False
            elif (a,t)!=(ea,et):return False
        return True
def reloc(s):
    if not s: return []
    offset,kind,addend,target=s.split(':')
    return [(int(offset),{1:4,5:2}[int(kind)],int(addend),target)]
if __name__=='__main__':
    src=table(d/(label+'.source'),'source');ref=table(d/(label+'.ref'),'reference')
    obj=Object((d/(label+'.o')).read_bytes()); counts=collections.Counter()
    with (d/(label+'.comparison.tsv')).open('w') as out:
        print('closing\tfunction\ttyped_entries\tbytes\trelocation\tordinary_stream\tobject',file=out)
        for close,(name,par,n,entries,machine,fixup) in src.items():
            raw=ref.get(close);count=int(n);counts['produced']+=1;counts['typed_entries']+=count;counts['code_bytes']+=len(machine)//2;counts['relocations']+=bool(fixup)
            rs='no-code' if raw is None else 'match' if raw==src[close] else 'different'
            os='no-symbol' if name not in obj.bodies else 'match' if obj.agrees(name,machine,reloc(fixup)) else 'different'
            counts['stream_'+rs]+=1;counts['elf_'+os]+=1
            print(close,name,n,len(machine)//2,fixup or '-',rs,os,sep='\t',file=out)
            if rs=='different' or os=='different': print('mismatch',close,name,src[close],raw,obj.function(name) if name in obj.bodies else None)
    print(label,dict(counts))
