extern int ext(int);
int f0(int x,int y) {return (~(73));}
int f1(int x,int y) {return ext((((1) + (-7))) & 255);}
int f2(int x,int y) {return ((y) * (-2147));}
int f3(int x,int y) {return (((~(0))) | ((~(1))));}
int f4(int x,int y) {return ((1) + (73));}
int f5(int x,int y) {return ext((((((-2147) <= (-2147))) >= (((y) == (-7))))) & 255);}
int f6(int x,int y) {return ((((y) ^ (y))) | ((~(73))));}
int f7(int x,int y) {return ((((((x) | (-7))) > (((-7) ^ (-7))))) == (((((y) + (73))) * (((-2147) - (8192))))));}
int f8(int x,int y) {return ((((x) | (73))) > (((-2147) > (-7))));}
int f9(int x,int y) {return (~(ext((1) & 255)));}
int f10(int x,int y) {return ((-7) | (-2147));}
int f11(int x,int y) {return (((((-(y))) | (((-7) * (-7))))) * (((((y) - (-7))) >= ((-(73))))));}
int f12(int x,int y) {return ((73) ^ (y));}
int f13(int x,int y) {return ((ext((1) & 255)) >= ((~(73))));}
int f14(int x,int y) {return (~(1));}
int f15(int x,int y) {return (~(((((-2147) - (8192))) != (((8192) < (0))))));}
int f16(int x,int y) {return ((y) | (0));}
int f17(int x,int y) {return ((((((x) > (0))) != (((-2147) - (8192))))) ^ (((((1) > (0))) | (ext((0) & 255)))));}
int f18(int x,int y) {return ((((x) > (y))) == (((8192) < (x))));}
int f19(int x,int y) {return ((((0) ^ (y))) - (((8192) | (x))));}
int f20(int x,int y) {return (-(((8192) >= (-2147))));}
int f21(int x,int y) {return (~(((ext((73) & 255)) == (((y) < (-2147))))));}
int f22(int x,int y) {return (~(((((0) & (-2147))) > ((~(-2147))))));}
int f23(int x,int y) {return ((((((-2147) != (1))) != (ext((y) & 255)))) - (((((y) * (-2147))) - (((x) * (0))))));}
int f24(int x,int y) {return ((y) < (-2147));}
int f25(int x,int y) {return ext((y) & 255);}
int f26(int x,int y) {return ((((((1) < (1))) & (((y) >= (1))))) ^ (((((y) >= (x))) < (((1) == (8192))))));}
int f27(int x,int y) {return (-(((x) > (8192))));}
int f28(int x,int y) {return ((((0) * (8192))) > (((-7) == (x))));}
int f29(int x,int y) {return ((0) >= (x));}
int f30(int x,int y) {return (~(((1) == (73))));}
int f31(int x,int y) {return ((8192) & (0));}
int f32(int x,int y) {return ((((((73) <= (-7))) >= (((0) < (y))))) & (((((-2147) + (-2147))) != (((-7) >= (-2147))))));}
int f33(int x,int y) {return (-(1));}
int f34(int x,int y) {return ((((((x) <= (0))) & ((~(8192))))) == ((((-(-7))) < ((-(x))))));}
int f35(int x,int y) {return (-(((((1) ^ (73))) <= (((-2147) <= (y))))));}
int f36(int x,int y) {return (((-(y))) | (((8192) & (-2147))));}
int f37(int x,int y) {return (((-((-(-7))))) * ((((-(1))) * (ext((x) & 255)))));}
int f38(int x,int y) {return ((((1) - (x))) + (((y) == (-2147))));}
int f39(int x,int y) {return ((1) - (1));}
int f40(int x,int y) {return ((((((1) < (-2147))) & (((-2147) & (1))))) + ((((-(x))) > (((y) + (-2147))))));}
int f41(int x,int y) {return (((-(((-2147) * (x))))) <= (((((-7) * (1))) | (((x) | (x))))));}
int f42(int x,int y) {return ((((-7) < (8192))) > (((8192) >= (-2147))));}
int f43(int x,int y) {return (((-((~(-7))))) | (ext(((-(0))) & 255)));}
int f44(int x,int y) {return ((y) <= (8192));}
int f45(int x,int y) {return ((1) == (73));}
int f46(int x,int y) {return ((-2147) & (0));}
int f47(int x,int y) {return ((((((73) < (-2147))) & (((y) >= (x))))) < (((((-7) * (1))) < (((0) - (-7))))));}
int f48(int x,int y) {return ((((73) | (-7))) == (((x) + (x))));}
int f49(int x,int y) {return ((ext((73) & 255)) > (((-2147) ^ (-2147))));}
int f50(int x,int y) {return ((((x) + (-7))) >= ((~(1))));}
int f51(int x,int y) {return ext((-2147) & 255);}
int f52(int x,int y) {return ((((x) == (-7))) != (((-7) != (8192))));}
int f53(int x,int y) {return ext((((1) < (y))) & 255);}
int f54(int x,int y) {return (~(((((-2147) ^ (y))) <= (((x) != (1))))));}
int f55(int x,int y) {return ext((((((-7) == (1))) <= ((~(8192))))) & 255);}
int f56(int x,int y) {return (~((~(73))));}
int f57(int x,int y) {return ((x) <= (y));}
int f58(int x,int y) {return (-((((-(8192))) - (((8192) ^ (8192))))));}
int f59(int x,int y) {return (~(73));}
int f60(int x,int y) {return (~(((73) * (-7))));}
int f61(int x,int y) {return ((((1) >= (-2147))) - (((x) != (-2147))));}
int f62(int x,int y) {return ((y) == (x));}
int f63(int x,int y) {return ext((((((y) >= (-7))) * (((0) > (8192))))) & 255);}
int f64(int x,int y) {return ((((((x) | (1))) > (((73) >= (0))))) + ((((-(0))) >= ((-(x))))));}
int f65(int x,int y) {return ((((((y) | (1))) != (((-7) & (73))))) | ((~(((1) * (73))))));}
int f66(int x,int y) {return ((((((-2147) | (y))) != (((1) <= (-7))))) + (((((73) != (x))) + ((~(0))))));}
int f67(int x,int y) {return (~(-2147));}
int f68(int x,int y) {return ((73) | (0));}
int f69(int x,int y) {return ((8192) ^ (-2147));}
int f70(int x,int y) {return ((((((y) * (0))) < ((~(-7))))) & ((((-(0))) & (((y) > (-2147))))));}
int f71(int x,int y) {return ((1) & (y));}
int f72(int x,int y) {return ((ext((((8192) + (1))) & 255)) > (((((0) - (8192))) * (((8192) + (-2147))))));}
int f73(int x,int y) {return (((~(((73) != (-2147))))) + ((-(((x) < (73))))));}
int f74(int x,int y) {return (((((~(-2147))) * (((73) < (1))))) < ((((~(8192))) ^ (((73) & (73))))));}
int f75(int x,int y) {return ((0) & (73));}
int f76(int x,int y) {return (-((((~(y))) + ((-(x))))));}
int f77(int x,int y) {return ((((ext((-2147) & 255)) >= (((-2147) != (y))))) - (((((8192) >= (y))) * (ext((73) & 255)))));}
int f78(int x,int y) {return ((((y) & (-2147))) - (((8192) < (8192))));}
int f79(int x,int y) {return (((~(0))) + (((-2147) >= (8192))));}
int f80(int x,int y) {return ((((0) <= (8192))) > (((1) != (8192))));}
int f81(int x,int y) {return ((-7) * (-2147));}
int f82(int x,int y) {return (-(((((-7) - (0))) != (((73) | (73))))));}
int f83(int x,int y) {return (~(x));}
int f84(int x,int y) {return (~((-(((-2147) & (-7))))));}
int f85(int x,int y) {return ((((((y) != (-2147))) + (((y) - (x))))) <= (((((-2147) != (0))) == (((1) == (x))))));}
int f86(int x,int y) {return ((((y) - (-7))) >= (((1) | (0))));}
int f87(int x,int y) {return (((~(x))) >= ((~(1))));}
int f88(int x,int y) {return ((((73) == (73))) > (((-2147) < (x))));}
int f89(int x,int y) {return ((ext((ext((0) & 255)) & 255)) != ((-(((8192) < (-2147))))));}
int f90(int x,int y) {return ((((0) - (8192))) ^ (((73) + (-7))));}
int f91(int x,int y) {return ((0) < (8192));}
int f92(int x,int y) {return (((~((-(0))))) > (((((y) > (8192))) != (((-7) != (1))))));}
int f93(int x,int y) {return ((((1) | (-2147))) ^ (((73) >= (73))));}
int f94(int x,int y) {return (((((-(y))) - (ext((-2147) & 255)))) > ((((-(73))) & (((-2147) >= (73))))));}
int f95(int x,int y) {return ext((((0) <= (0))) & 255);}
int f96(int x,int y) {return ((0) & (8192));}
int f97(int x,int y) {return ext((((1) & (1))) & 255);}
int f98(int x,int y) {return ext((1) & 255);}
int f99(int x,int y) {return (-((-(-7))));}
int f100(int x,int y) {return ((((y) | (8192))) - (((1) > (8192))));}
int f101(int x,int y) {return (~(((-7) & (8192))));}
int f102(int x,int y) {return ((y) ^ (1));}
int f103(int x,int y) {return ((((((x) - (0))) >= ((-(x))))) > (((((-7) == (-2147))) > (((-2147) <= (8192))))));}
int f104(int x,int y) {return ((((((73) < (8192))) & (((73) != (y))))) <= ((-(((-2147) == (-7))))));}
int f105(int x,int y) {return (-(-2147));}
int f106(int x,int y) {return ((((((y) | (0))) >= (((-2147) > (-2147))))) & (((((8192) * (73))) > (ext((73) & 255)))));}
int f107(int x,int y) {return ((1) + (0));}
int f108(int x,int y) {return (((~(((y) >= (8192))))) ^ (((((x) + (-2147))) == (((y) - (8192))))));}
int f109(int x,int y) {return (~(((-7) | (1))));}
int f110(int x,int y) {return ((((1) >= (1))) + (((-2147) ^ (-2147))));}
int f111(int x,int y) {return ((-2147) & (-2147));}
int f112(int x,int y) {return ((x) & (y));}
int f113(int x,int y) {return ((((-7) ^ (x))) - (((1) >= (73))));}
int f114(int x,int y) {return ((((((0) < (-7))) * (((73) < (0))))) + (((((0) ^ (-7))) > (((73) >= (-2147))))));}
int f115(int x,int y) {return (-(((((y) ^ (x))) ^ ((-(73))))));}
int f116(int x,int y) {return ext((((((8192) >= (-7))) & (((73) >= (-2147))))) & 255);}
int f117(int x,int y) {return (-(((((8192) | (-7))) < (((8192) <= (0))))));}
int f118(int x,int y) {return ((((-7) > (1))) != (((1) != (x))));}
int f119(int x,int y) {return ((((1) >= (x))) == ((~(-2147))));}
int f120(int x,int y) {return ((((x) | (-7))) == (((1) & (73))));}
int f121(int x,int y) {return ((((x) == (x))) | ((-(0))));}
int f122(int x,int y) {return (-(((((1) * (y))) | ((~(1))))));}
int f123(int x,int y) {return ((ext((((y) == (y))) & 255)) <= (((((0) != (-2147))) ^ ((~(0))))));}
int f124(int x,int y) {return ((((-7) | (x))) < (((1) * (8192))));}
int f125(int x,int y) {return ((((1) ^ (8192))) < (((1) != (73))));}
int f126(int x,int y) {return ((0) == (0));}
int f127(int x,int y) {return ((((((-7) > (0))) | ((-(x))))) == (((((1) <= (0))) * (((0) > (8192))))));}
int f128(int x,int y) {return ((y) < (73));}
int f129(int x,int y) {return (((~(((y) & (0))))) > (((((-7) ^ (0))) | (((73) == (-2147))))));}
int f130(int x,int y) {return ((((((x) == (0))) >= (((8192) <= (-7))))) | ((((~(1))) & (((-2147) > (x))))));}
int f131(int x,int y) {return ((((((-2147) * (0))) != ((~(-2147))))) | (((((x) | (73))) != (((-2147) * (0))))));}
int f132(int x,int y) {return (~(((((x) + (1))) >= (ext((1) & 255)))));}
int f133(int x,int y) {return ((((73) ^ (8192))) * (((y) + (1))));}
int f134(int x,int y) {return ((((((0) > (-7))) - (((x) - (-2147))))) - (((((-2147) == (1))) >= (((-7) ^ (1))))));}
int f135(int x,int y) {return ((((((-7) > (8192))) | (((73) - (8192))))) <= (((((8192) == (x))) != ((-(73))))));}
int f136(int x,int y) {return ((y) < (1));}
int f137(int x,int y) {return ((ext((y) & 255)) ^ ((~(0))));}
int f138(int x,int y) {return (~(((0) & (-7))));}
int f139(int x,int y) {return ((((((y) & (y))) >= (((-2147) * (8192))))) < (((((73) & (x))) <= (((73) - (x))))));}
int f140(int x,int y) {return (((((~(1))) != (((x) - (73))))) >= (((((y) == (-2147))) & (((73) != (y))))));}
int f141(int x,int y) {return (((-(y))) ^ (((x) | (y))));}
int f142(int x,int y) {return (((-(y))) >= (((0) < (-2147))));}
int f143(int x,int y) {return ((8192) & (73));}
int f144(int x,int y) {return ((((8192) - (0))) != ((~(73))));}
int f145(int x,int y) {return (((((~(8192))) > ((~(-7))))) + (((((73) <= (y))) * (((8192) < (-7))))));}
int f146(int x,int y) {return ((((x) < (-2147))) | (((0) != (73))));}
int f147(int x,int y) {return ((((x) & (-7))) < (((-7) & (x))));}
int f148(int x,int y) {return ((((1) & (73))) | (((y) + (-7))));}
int f149(int x,int y) {return (~(((ext((1) & 255)) >= (((-7) != (0))))));}
int f150(int x,int y) {return ((y) ^ (-2147));}
int f151(int x,int y) {return ((((((-7) | (y))) ^ (((0) + (-7))))) < (((((0) & (-7))) < (((y) * (1))))));}
int f152(int x,int y) {return (~((-(((1) - (73))))));}
int f153(int x,int y) {return ((((-2147) ^ (-2147))) != ((~(1))));}
int f154(int x,int y) {return ext(((((~(x))) >= (((-2147) + (73))))) & 255);}
int f155(int x,int y) {return ext((((0) - (-7))) & 255);}
int f156(int x,int y) {return ((((((8192) | (x))) & (((73) - (0))))) >= (((((0) | (-7))) + (((1) == (1))))));}
int f157(int x,int y) {return (((~(ext((-7) & 255)))) == ((~(((y) ^ (-7))))));}
int f158(int x,int y) {return ((((8192) <= (-2147))) != (ext((-7) & 255)));}
int f159(int x,int y) {return ((-2147) >= (-7));}
int f160(int x,int y) {return ext((((((y) < (-2147))) * (((8192) <= (y))))) & 255);}
int f161(int x,int y) {return ((((x) == (0))) + (((8192) != (-7))));}
int f162(int x,int y) {return (((-(((y) >= (1))))) <= (ext((((73) < (-2147))) & 255)));}
int f163(int x,int y) {return ((((((73) & (8192))) >= ((-(x))))) ^ (((ext((x) & 255)) < ((~(-7))))));}
int f164(int x,int y) {return ((ext((((1) | (x))) & 255)) < (((((y) + (-2147))) < (((1) | (0))))));}
int f165(int x,int y) {return ((((((x) == (y))) != (((8192) * (y))))) & ((-((~(1))))));}
int f166(int x,int y) {return ((8192) != (8192));}
int f167(int x,int y) {return ((((((-7) >= (y))) - (((y) <= (-2147))))) < (ext((((73) <= (0))) & 255)));}
int f168(int x,int y) {return ((((-2147) ^ (y))) ^ (ext((y) & 255)));}
int f169(int x,int y) {return ((((0) | (0))) * ((~(0))));}
int f170(int x,int y) {return ((((y) + (0))) != (((0) ^ (0))));}
int f171(int x,int y) {return ((((((8192) | (73))) & (((1) <= (8192))))) <= ((~((~(8192))))));}
int f172(int x,int y) {return ((y) - (-7));}
int f173(int x,int y) {return ext((((((1) ^ (1))) == (((73) + (-7))))) & 255);}
int f174(int x,int y) {return ((((73) == (y))) == (((0) + (0))));}
int f175(int x,int y) {return ((0) == (x));}
int f176(int x,int y) {return ((0) * (-7));}
int f177(int x,int y) {return ext((x) & 255);}
int f178(int x,int y) {return ((0) < (0));}
int f179(int x,int y) {return (((~(((y) - (8192))))) != (((((y) + (1))) < (((-2147) ^ (0))))));}
int f180(int x,int y) {return (-(x));}
int f181(int x,int y) {return ((((y) == (-7))) ^ (((8192) ^ (73))));}
int f182(int x,int y) {return ((((((-7) == (y))) > (ext((73) & 255)))) == (ext((((x) >= (73))) & 255)));}
int f183(int x,int y) {return ((-7) - (-2147));}
int f184(int x,int y) {return (-(x));}
int f185(int x,int y) {return (-(ext((73) & 255)));}
int f186(int x,int y) {return ((8192) > (-2147));}
int f187(int x,int y) {return (-((((-(1))) < ((-(0))))));}
int f188(int x,int y) {return ((73) * (73));}
int f189(int x,int y) {return (~(((ext((1) & 255)) <= (((y) + (8192))))));}
int f190(int x,int y) {return ((((-7) != (x))) * (((1) < (0))));}
int f191(int x,int y) {return ((y) ^ (-7));}
int f192(int x,int y) {return (((((-(x))) + (((0) + (-2147))))) != (((((x) <= (0))) >= (((-2147) >= (73))))));}
int f193(int x,int y) {return ((73) ^ (0));}
int f194(int x,int y) {return ((0) == (y));}
int f195(int x,int y) {return ((ext((((1) == (8192))) & 255)) != (((((y) - (0))) ^ ((~(0))))));}
int f196(int x,int y) {return ((((((x) > (1))) + (((8192) >= (1))))) & (((((8192) != (x))) > (ext((-7) & 255)))));}
int f197(int x,int y) {return ext((x) & 255);}
int f198(int x,int y) {return ((8192) < (x));}
int f199(int x,int y) {return ext((((0) | (8192))) & 255);}
int f200(int x,int y) {return ((((1) == (-7))) ^ (((x) >= (-7))));}
int f201(int x,int y) {return ((((((1) >= (8192))) >= (ext((73) & 255)))) & (((((0) & (-2147))) | (((y) != (-2147))))));}
int f202(int x,int y) {return (-(0));}
int f203(int x,int y) {return ext(((~(((73) >= (8192))))) & 255);}
int f204(int x,int y) {return ((0) + (-2147));}
int f205(int x,int y) {return ((x) >= (-2147));}
int f206(int x,int y) {return ((y) != (73));}
int f207(int x,int y) {return ((ext((((0) < (8192))) & 255)) * ((-(ext((-2147) & 255)))));}
int f208(int x,int y) {return ((73) | (73));}
int f209(int x,int y) {return ((((((1) + (-2147))) | (((8192) <= (0))))) - ((((-(1))) >= (((y) <= (-7))))));}
int f210(int x,int y) {return ((((8192) > (-7))) * (ext((-7) & 255)));}
int f211(int x,int y) {return ((x) ^ (x));}
int f212(int x,int y) {return ext((((((-7) | (73))) | (((1) <= (1))))) & 255);}
int f213(int x,int y) {return ((-2147) != (73));}
int f214(int x,int y) {return ((0) - (0));}
int f215(int x,int y) {return ext((0) & 255);}
int f216(int x,int y) {return (~(x));}
int f217(int x,int y) {return (-(((0) & (8192))));}
int f218(int x,int y) {return ext((((1) < (y))) & 255);}
int f219(int x,int y) {return (~(x));}
int f220(int x,int y) {return (-(-2147));}
int f221(int x,int y) {return (((-(1))) * (((0) & (73))));}
int f222(int x,int y) {return (((~(0))) | ((~(x))));}
int f223(int x,int y) {return ((73) & (1));}
int f224(int x,int y) {return ((((((-2147) < (-2147))) + (((-2147) >= (0))))) < (((((x) > (-7))) + (((73) | (-2147))))));}
int f225(int x,int y) {return (-(((x) == (x))));}
int f226(int x,int y) {return ((((1) >= (8192))) <= ((~(-2147))));}
int f227(int x,int y) {return ((((8192) + (-2147))) & (((x) - (73))));}
int f228(int x,int y) {return ((((-2147) != (x))) - (((0) >= (y))));}
int f229(int x,int y) {return ((((8192) != (1))) ^ ((~(0))));}
int f230(int x,int y) {return (~((~((-(x))))));}
int f231(int x,int y) {return ((((((73) != (-7))) == ((-(0))))) >= (ext(((~(73))) & 255)));}
int f232(int x,int y) {return ((((((73) == (1))) + ((~(x))))) + (((((1) < (x))) - (((1) > (73))))));}
int f233(int x,int y) {return ((-7) ^ (x));}
int f234(int x,int y) {return ((((((0) == (-2147))) & (((8192) != (73))))) >= (((((y) + (0))) != (((-7) < (73))))));}
int f235(int x,int y) {return (-(ext((8192) & 255)));}
int f236(int x,int y) {return (-(((73) & (y))));}
int f237(int x,int y) {return ((1) <= (8192));}
int f238(int x,int y) {return (((~((~(y))))) & (((((x) >= (y))) | (((73) * (0))))));}
int f239(int x,int y) {return (~(((8192) * (x))));}
int f240(int x,int y) {return (~(((8192) <= (8192))));}
int f241(int x,int y) {return ((((((-7) ^ (1))) & (((x) | (x))))) & (((ext((8192) & 255)) >= (((-7) <= (-2147))))));}
int f242(int x,int y) {return (-(ext((x) & 255)));}
int f243(int x,int y) {return ((((ext((-2147) & 255)) * (((-2147) ^ (x))))) >= (((((1) & (8192))) | (ext((-7) & 255)))));}
int f244(int x,int y) {return (~(0));}
int f245(int x,int y) {return ext((y) & 255);}
int f246(int x,int y) {return (-(((((-2147) | (y))) > (((1) != (1))))));}
int f247(int x,int y) {return ext((((1) >= (73))) & 255);}
int f248(int x,int y) {return ((73) > (-7));}
int f249(int x,int y) {return (((((~(x))) | (((-2147) <= (0))))) != (((ext((8192) & 255)) * ((~(1))))));}
int f250(int x,int y) {return (((~(0))) != ((-(73))));}
int f251(int x,int y) {return ext((1) & 255);}
int f252(int x,int y) {return (((~((-(0))))) <= (((((-2147) * (73))) >= (((-2147) <= (y))))));}
int f253(int x,int y) {return (~((-(0))));}
int f254(int x,int y) {return ((8192) + (0));}
int f255(int x,int y) {return ((((1) - (8192))) != (((0) == (8192))));}
int f256(int x,int y) {return (-(0));}
int f257(int x,int y) {return ((((1) >= (8192))) + (((73) != (-7))));}
int f258(int x,int y) {return ((ext((-7) & 255)) > (((1) * (8192))));}
int f259(int x,int y) {return (((((~(y))) + (((-2147) * (73))))) - (((((8192) != (-2147))) * (((8192) > (8192))))));}
int f260(int x,int y) {return ((-2147) < (-2147));}
int f261(int x,int y) {return ((((((-7) - (x))) & (((-7) > (73))))) >= (ext((((y) * (73))) & 255)));}
int f262(int x,int y) {return ((ext((8192) & 255)) | (((8192) != (y))));}
int f263(int x,int y) {return ((-7) | (-7));}
int f264(int x,int y) {return ((((((x) > (1))) * (ext((-2147) & 255)))) * (((((y) <= (y))) - (((y) ^ (-2147))))));}
int f265(int x,int y) {return ext((((1) * (-2147))) & 255);}
int f266(int x,int y) {return ((ext((y) & 255)) == (((1) >= (1))));}
int f267(int x,int y) {return ((((((-2147) | (-7))) < (((x) >= (73))))) == (ext((((-7) >= (73))) & 255)));}
int f268(int x,int y) {return ((8192) & (0));}
int f269(int x,int y) {return ((73) < (y));}
int f270(int x,int y) {return ext((8192) & 255);}
int f271(int x,int y) {return (((((~(-7))) <= ((~(1))))) - ((~(((-7) | (0))))));}
int f272(int x,int y) {return ((ext(((-(-7))) & 255)) <= (((((73) > (-2147))) & ((-(73))))));}
int f273(int x,int y) {return ext((((y) == (8192))) & 255);}
int f274(int x,int y) {return ((1) - (x));}
int f275(int x,int y) {return ext((((y) | (y))) & 255);}
int f276(int x,int y) {return ((73) | (73));}
int f277(int x,int y) {return ((((ext((0) & 255)) + ((-(-2147))))) <= (((ext((0) & 255)) ^ (((x) > (-2147))))));}
int f278(int x,int y) {return ((((((1) + (-7))) > (((y) <= (x))))) == (((((-7) * (73))) * (((73) != (-7))))));}
int f279(int x,int y) {return ((((73) - (y))) - (((y) - (8192))));}
int f280(int x,int y) {return ((((((0) + (0))) != (ext((-7) & 255)))) <= ((((~(y))) & (((-2147) > (8192))))));}
int f281(int x,int y) {return (((((-(-2147))) + (ext((-7) & 255)))) == ((((-(0))) >= ((~(1))))));}
int f282(int x,int y) {return (((~(((-7) + (-7))))) > ((-(((-2147) & (y))))));}
int f283(int x,int y) {return (~(((73) >= (0))));}
int f284(int x,int y) {return ext((8192) & 255);}
int f285(int x,int y) {return (~(((-2147) * (73))));}
int f286(int x,int y) {return (((-(x))) * (((x) * (0))));}
int f287(int x,int y) {return ((((73) + (1))) ^ (((x) ^ (-2147))));}
int f288(int x,int y) {return (~((~(x))));}
int f289(int x,int y) {return (((((-(73))) ^ (ext((y) & 255)))) <= (((((-2147) - (y))) * (((x) | (73))))));}
int f290(int x,int y) {return ((((ext((x) & 255)) != (((8192) | (8192))))) <= ((((~(1))) * (((x) & (-2147))))));}
int f291(int x,int y) {return ((x) < (y));}
int f292(int x,int y) {return ((((x) >= (x))) != (((x) > (x))));}
int f293(int x,int y) {return ((((8192) & (-7))) < ((-(0))));}
int f294(int x,int y) {return ((((1) - (0))) - ((~(x))));}
int f295(int x,int y) {return ext((((8192) >= (0))) & 255);}
int f296(int x,int y) {return (((~(73))) - ((-(y))));}
int f297(int x,int y) {return ((((((1) & (8192))) < (((73) | (1))))) - ((((~(x))) > (ext((0) & 255)))));}
int f298(int x,int y) {return ((((x) == (x))) * (((0) - (73))));}
int f299(int x,int y) {return ((((8192) == (-2147))) ^ (((-2147) <= (1))));}
int f300(int x,int y) {return ((x) <= (-2147));}
int f301(int x,int y) {return ((ext((((1) | (-2147))) & 255)) == (((((x) * (8192))) | (ext((x) & 255)))));}
int f302(int x,int y) {return ext((((((8192) >= (73))) - (((8192) >= (1))))) & 255);}
int f303(int x,int y) {return (((((~(1))) != (((-2147) | (y))))) | (ext(((~(73))) & 255)));}
int f304(int x,int y) {return ((((x) & (73))) != (((-2147) != (0))));}
int f305(int x,int y) {return (~(8192));}
int f306(int x,int y) {return ((((8192) == (-7))) == (((73) > (0))));}
int f307(int x,int y) {return (((~(((y) ^ (y))))) & (((((73) >= (1))) + (ext((y) & 255)))));}
int f308(int x,int y) {return ((((y) ^ (-7))) * ((-(-7))));}
int f309(int x,int y) {return ((y) | (y));}
int f310(int x,int y) {return ((((-7) * (1))) & (((y) | (73))));}
int f311(int x,int y) {return (-((~(ext((-2147) & 255)))));}
int f312(int x,int y) {return ((-2147) + (-7));}
int f313(int x,int y) {return ext((73) & 255);}
int f314(int x,int y) {return ((1) == (1));}
int f315(int x,int y) {return ((-2147) | (0));}
int f316(int x,int y) {return (((((~(y))) & (((y) <= (-2147))))) == (((((73) >= (-2147))) | (((-2147) >= (73))))));}
int f317(int x,int y) {return (~(0));}
int f318(int x,int y) {return ((((-7) + (-2147))) | ((~(y))));}
int f319(int x,int y) {return ((((((-2147) > (8192))) | (((1) ^ (8192))))) | ((~((-(y))))));}
int f320(int x,int y) {return (-(((((8192) != (-7))) ^ (((0) != (x))))));}
int f321(int x,int y) {return ext((-7) & 255);}
int f322(int x,int y) {return ext((((73) | (8192))) & 255);}
int f323(int x,int y) {return (~(((1) + (-2147))));}
int f324(int x,int y) {return ((((8192) ^ (73))) & (((8192) - (-7))));}
int f325(int x,int y) {return (~(0));}
int f326(int x,int y) {return ((((((-2147) | (1))) > (((x) != (-2147))))) * (((ext((73) & 255)) <= (((0) >= (y))))));}
int f327(int x,int y) {return ((((y) & (0))) == (((8192) - (1))));}
int f328(int x,int y) {return (((((-(x))) < (((73) > (0))))) ^ (((ext((0) & 255)) >= (((0) * (x))))));}
int f329(int x,int y) {return (~(ext((ext((x) & 255)) & 255)));}
int f330(int x,int y) {return ((ext((x) & 255)) + (((73) + (-2147))));}
int f331(int x,int y) {return ext((((((8192) >= (0))) & (((-2147) >= (0))))) & 255);}
int f332(int x,int y) {return (-(((((x) - (0))) >= (((8192) > (-2147))))));}
int f333(int x,int y) {return ((((ext((-7) & 255)) * (((8192) - (0))))) == (((((-2147) - (8192))) - (((0) != (y))))));}
int f334(int x,int y) {return ((((((-2147) * (y))) < (((0) < (0))))) >= (((((-7) == (-7))) != ((-(x))))));}
int f335(int x,int y) {return (~(0));}
int f336(int x,int y) {return ((((((1) & (-2147))) | (((y) * (x))))) & (((ext((1) & 255)) > (((y) + (-7))))));}
int f337(int x,int y) {return ((73) == (x));}
int f338(int x,int y) {return ((ext((-7) & 255)) >= (((1) <= (-2147))));}
int f339(int x,int y) {return (((-(((8192) & (0))))) & (((((8192) ^ (73))) != ((-(-2147))))));}
int f340(int x,int y) {return (-(-7));}
int f341(int x,int y) {return ((((-7) - (-2147))) | (((73) >= (1))));}
int f342(int x,int y) {return ext((((8192) + (8192))) & 255);}
int f343(int x,int y) {return ((0) | (-7));}
int f344(int x,int y) {return (~(((((0) & (8192))) - (((8192) ^ (8192))))));}
int f345(int x,int y) {return ((73) & (x));}
int f346(int x,int y) {return ((((-2147) > (y))) == (((73) + (-2147))));}
int f347(int x,int y) {return ((-2147) >= (-2147));}
int f348(int x,int y) {return ((((1) == (8192))) & (((8192) ^ (-7))));}
int f349(int x,int y) {return (((((~(73))) >= (((1) < (-7))))) + (((((0) + (1))) != (((1) - (-7))))));}
int f350(int x,int y) {return (((-(8192))) < ((~(x))));}
int f351(int x,int y) {return ((((8192) > (8192))) | (((x) > (0))));}
int f352(int x,int y) {return ((((0) < (73))) < (((y) & (y))));}
int f353(int x,int y) {return ((-7) != (x));}
int f354(int x,int y) {return ext((0) & 255);}
int f355(int x,int y) {return ext((((73) | (73))) & 255);}
int f356(int x,int y) {return ((((y) | (y))) <= (((8192) ^ (0))));}
int f357(int x,int y) {return (~(-2147));}
int f358(int x,int y) {return ((y) ^ (-2147));}
int f359(int x,int y) {return ext((ext((0) & 255)) & 255);}
int f360(int x,int y) {return ((((((x) != (-2147))) * (((x) < (-2147))))) | (((ext((y) & 255)) == (((-2147) < (8192))))));}
int f361(int x,int y) {return ext((-2147) & 255);}
int f362(int x,int y) {return ((1) != (73));}
int f363(int x,int y) {return (((((~(73))) > (((0) != (-2147))))) <= (((((y) + (73))) - (((73) > (x))))));}
int f364(int x,int y) {return (((((-(y))) ^ (((8192) == (-2147))))) < ((((~(y))) - (((73) ^ (0))))));}
int f365(int x,int y) {return ((((((x) ^ (1))) < (((8192) | (8192))))) & (((((8192) < (-2147))) < (((1) <= (1))))));}
int f366(int x,int y) {return (((((~(8192))) == (((1) >= (y))))) * ((-(((-2147) == (-2147))))));}
int f367(int x,int y) {return ((ext((((x) > (x))) & 255)) != ((((~(1))) + (((-2147) > (y))))));}
int f368(int x,int y) {return (((((-(1))) != ((~(-2147))))) ^ (((ext((y) & 255)) != (((-7) * (-2147))))));}
int f369(int x,int y) {return ((-7) & (-2147));}
int f370(int x,int y) {return (-(8192));}
int f371(int x,int y) {return ((x) <= (1));}
int f372(int x,int y) {return ((((((-7) & (-7))) | (((73) <= (y))))) == (((((y) >= (y))) <= ((-(0))))));}
int f373(int x,int y) {return ((((((y) * (-2147))) >= (((-2147) > (-2147))))) == ((-((-(0))))));}
int f374(int x,int y) {return ext((-7) & 255);}
int f375(int x,int y) {return ((((x) + (1))) + (ext((8192) & 255)));}
int f376(int x,int y) {return ((1) - (1));}
int f377(int x,int y) {return ((-7) ^ (-2147));}
int f378(int x,int y) {return ext((((((1) >= (x))) <= ((~(8192))))) & 255);}
int f379(int x,int y) {return ((((-7) ^ (8192))) | (((-2147) < (1))));}
int f380(int x,int y) {return (-(73));}
int f381(int x,int y) {return ((((y) | (73))) != (((0) | (x))));}
int f382(int x,int y) {return ((8192) & (x));}
int f383(int x,int y) {return (~(73));}
int f384(int x,int y) {return ext((1) & 255);}
int f385(int x,int y) {return (~(((1) * (-2147))));}
int f386(int x,int y) {return (~((((-(y))) < (((0) + (1))))));}
int f387(int x,int y) {return (~(((-7) <= (x))));}
int f388(int x,int y) {return ext(((((~(y))) <= (((8192) & (-2147))))) & 255);}
int f389(int x,int y) {return ((((((-7) < (8192))) + ((~(1))))) == ((~(((1) > (8192))))));}
int f390(int x,int y) {return ((ext((0) & 255)) < (((-7) < (y))));}
int f391(int x,int y) {return ((-2147) < (73));}
int f392(int x,int y) {return ext((-7) & 255);}
int f393(int x,int y) {return (~(((x) == (-2147))));}
int f394(int x,int y) {return ((x) == (x));}
int f395(int x,int y) {return (((~(-7))) == (((8192) < (1))));}
int f396(int x,int y) {return ((((((-7) & (73))) == (((-7) + (x))))) + (((((y) > (0))) & (((0) != (-2147))))));}
int f397(int x,int y) {return ((-7) - (0));}
int f398(int x,int y) {return ((y) > (73));}
int f399(int x,int y) {return ((((8192) > (8192))) == (((x) + (0))));}
