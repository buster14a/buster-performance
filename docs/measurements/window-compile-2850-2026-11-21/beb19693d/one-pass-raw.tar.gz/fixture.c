int const_i(void) { return 17; }
int get_i(int x) { return x; }
int calc_i(int x, int y) { return (x + 2) ^ y; }
int dead(void) { return 1 + 2; }
extern int ext(int);
int call_i(int x) { return ext(x); }
struct S { long a; int b; unsigned short c; };
int read_int(const int *x) {return *x;}
int read_member(const struct S* s){return s->b;}
unsigned short read_short(const struct S* s){return s->c;}
unsigned long math_word(unsigned long w){return w ^ 123UL;}
const int* keep_ptr(const int* p){return p;}
extern unsigned long ext_word(const struct S*, unsigned long);
unsigned long call_word(const struct S* s, unsigned long x){return ext_word(s,x);}
