from pathlib import Path
import random
rng=random.Random(2850); d=Path(__file__).resolve().parent
def expression(n):
    if not n:return rng.choice(['x','y','0','1','-7','73','-2147','8192'])
    a=expression(n-1)
    if rng.randrange(4)==0: return rng.choice([f'(~({a}))',f'(-({a}))',f'ext(({a}) & 255)'])
    b=expression(n-1)
    return f'(({a}) {rng.choice(["+","-","*","^","&","|","==","!=","<","<=",">",">="])} ({b}))'
body=['extern int ext(int);']
for i in range(400):body.append(f'int f{i}(int x,int y) {{return {expression(rng.randrange(1,4))};}}')
(d/'generated.c').write_text('\n'.join(body)+'\n')
head=['#include <stdio.h>','#include <stdint.h>','int ext(int x) { return (x & 255) * 3 + 11; }']
head+= [f'int f{i}(int,int);' for i in range(400)]
head+=['int main(void){uint64_t h=0;int (*f[])(int,int)={'+','.join(f'f{i}' for i in range(400))+'};','for (int x=-19;x<20;x++) for(int y=-17;y<18;y++) for(unsigned i=0;i<400;i++) h=h*31+(uint32_t)f[i](x,y);','printf("%llu\\n",(unsigned long long)h);return 0;}']
(d/'generated-driver.c').write_text('\n'.join(head)+'\n')
