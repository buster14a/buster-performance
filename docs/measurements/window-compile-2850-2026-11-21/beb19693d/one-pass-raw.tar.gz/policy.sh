#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d=$PWD
cd ../switch-inputs; source ../switch-local-args.sh
case $1 in
fixture) args=(-nostdinc "$d/fixture.c");;
generated) args=(-nostdinc -fwrapv "$d/generated.c");;
sqlite) eval "args=($sqlite_arguments)";;
main) tree=$PWD/../pregraph-warning-study/compiler-source
args=(-march=native -I"$tree/src" -fwrapv -funsigned-char --predefines "$PWD/../proof-predefines.h" "$tree/src/buster/compiler/main.c");;
esac
case $2 in all) flags=(-Wall -Wextra);;everything) flags=(-Weverything -Wno-c++-compat);;default) flags=();;esac
d=$d/policy
mkdir -p "$d"
for v in ref native;do
 mode=(); [[ $v != native ]] || mode=(BUSTER_BODY_SOURCE_NATIVE=1)
 env "${mode[@]}" "$d/../compiler" --lanes 1 -c "${flags[@]}" "${args[@]}" -o "$d/$1-$2-$v.o" > "$d/$1-$2-$v.out" 2> "$d/$1-$2-$v.stderr"
done
rg -v '^body-native-' "$d/$1-$2-native.stderr" > "$d/$1-$2-ordinary.stderr" || true
for ext in out o;do cmp "$d/$1-$2-ref.$ext" "$d/$1-$2-native.$ext";done
cmp "$d/$1-$2-ref.stderr" "$d/$1-$2-ordinary.stderr"
