#include <stdint.h>
#include <stdio.h>
int const_i(void), get_i(int), calc_i(int, int), dead(void), call_i(int);
int ext(int x) { return 3*x + 9; }
struct S { long a; int b; unsigned short c; };
int read_int(const int*), read_member(const struct S*);
unsigned short read_short(const struct S*);
unsigned long math_word(unsigned long), call_word(const struct S*,unsigned long);
const int* keep_ptr(const int*);
unsigned long ext_word(const struct S* s,unsigned long w){return (unsigned long)s->b + w;}
int main(void) {
    uint64_t h=0;
    for(int x=-97; x<=97; ++x) for(int y=-111; y<=111; ++y) {
        h=h*31+(uint32_t)const_i(); h=h*31+(uint32_t)get_i(x); h=h*31+(uint32_t)calc_i(x,y);
        struct S s={x,x+y,(unsigned short)x};
        h=h*31+(uint32_t)read_int(&x);h=h*31+(uint32_t)read_member(&s);h=h*31+read_short(&s);
        h=h*31+math_word((unsigned long)x);h=h*31+(keep_ptr(&x)==&x);h=h*31+call_word(&s,(unsigned long)y);
        h=h*31+(uint32_t)dead(); h=h*31+(uint32_t)call_i(y);
    }
    printf("%llu\n",(unsigned long long)h);
}
