#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs;source ../switch-local-args.sh
eval "all=($musl_arguments)"
flags=(); for a in "${all[@]}";do [[ $a == *.c ]] && break;flags+=("$a");done
o=$d/musl-small
clang=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$clang" -O0 -fno-builtin "${flags[@]}" -I"$musl/src/dirent" -c "$d/musl-small-driver.c" -o "$o/driver.o"
inputs=(dirent/dirfd dirent/telldir string/bcmp string/index string/rindex)
for src in "${inputs[@]}";do f=$musl/src/$src.c;n=${src##*/};p=$o/$n
 BUSTER_BODY_SOURCE_NATIVE=1 BUSTER_BODY_NATIVE_ONLY=1 BUSTER_BODY_NATIVE_AUDIT=1 "$d/compiler" --lanes 1 -c "${flags[@]}" "$f" -o "$p.strict.o" > "$p.strict.stdout" 2>"$p.strict.stderr"
 "$clang" -O0 "${flags[@]}" -c "$f" -o "$p.clang.o"
 cmp "$p.strict.o" "$p.ref.o";rg '^body-native-summary' "$p.strict.stderr" |sed "s@^@$src\t@"
done
for v in ref strict clang; do l=();for src in "${inputs[@]}";do l+=("$o/${src##*/}.$v.o");done
 "$clang" -O0 "$o/driver.o" "${l[@]}" -o "$o/run-$v"
 "$o/run-$v" >"$o/$v.result"
 cmp "$o/ref.result" "$o/$v.result"
done
cat "$o/ref.result"
