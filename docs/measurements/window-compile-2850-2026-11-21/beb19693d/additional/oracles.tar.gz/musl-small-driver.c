#define _BSD_SOURCE
#include <dirent.h>
#include "__dirent.h"
#include <strings.h>
#include <stdint.h>
#include <stdio.h>

int main(void)
{
    struct __dirstream dir = {0};
    uint64_t hash = 0;
    const char a[] = "aabacab", b[] = "aabacac";
    for (int fd = -97; fd <= 97; ++fd)
    {
        dir.fd = fd;
        dir.tell = (long)fd * 123456789;
        hash = hash * 31 + dirfd(&dir);
        hash = hash * 31 + telldir(&dir);
        for (unsigned bytes = 0; bytes <= sizeof(a); ++bytes)
        {
            hash = hash * 31 + (bcmp(a,b,bytes) == 0);
            int c = (int)(bytes % 5) + 'a';
            const char* first = index(a,c);
            const char* last = rindex(a,c);
            hash = hash * 31 + (first != 0 ? (unsigned)(first-a) + 1 : 0);
            hash = hash * 31 + (last != 0 ? (unsigned)(last-a) + 1 : 0);
        }
    }
    printf("%llu\n",(unsigned long long)hash);
    return 0;
}
