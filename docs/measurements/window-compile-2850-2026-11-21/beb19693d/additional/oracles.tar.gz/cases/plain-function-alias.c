extern int a(int) __asm__("named_a");int f(int v){return a(v);}
