int __attribute__((ms_abi)) f(int x){return x;}
