extern int e(int); int f(int x){return e(e(x));}
