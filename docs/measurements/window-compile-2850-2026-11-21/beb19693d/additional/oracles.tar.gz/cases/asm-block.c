int f(int x){__asm__("" : "+r"(x));return x;}
