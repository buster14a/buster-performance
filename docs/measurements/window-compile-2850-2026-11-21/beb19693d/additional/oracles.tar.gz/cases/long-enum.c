enum E { E1=1,E2=2 }; enum E f(enum E x){return x;}
