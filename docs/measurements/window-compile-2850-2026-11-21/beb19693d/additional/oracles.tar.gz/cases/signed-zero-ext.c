signed char f(void){return -103;} unsigned char g(void){return 250;}
