int g=73;int f(int x){return x+1;} int use(void){return g;}
