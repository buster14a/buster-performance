static int f(int x,int y){return x;}int t(int a,int b){return f(a,b);}
