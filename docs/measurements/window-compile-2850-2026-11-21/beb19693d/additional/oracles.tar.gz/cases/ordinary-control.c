int f(int x){if (x<3) return x+2;return x-2;}
