static int t(int x){return x+4;} int f(int y){return t(y);}
