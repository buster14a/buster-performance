int f(int x){int a=x+1;return a*2;}
