int f(int x){return x+no_such_value;}
