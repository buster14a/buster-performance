int f(volatile int x){return x;}
