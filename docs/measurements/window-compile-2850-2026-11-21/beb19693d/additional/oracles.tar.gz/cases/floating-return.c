double f(double a){return a+1.0;}
