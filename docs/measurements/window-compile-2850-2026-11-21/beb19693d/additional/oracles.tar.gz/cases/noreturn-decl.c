__attribute__((noreturn)) int f(int x){return x;}
