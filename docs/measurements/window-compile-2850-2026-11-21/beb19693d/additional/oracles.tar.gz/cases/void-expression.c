int f(int x){return (void)x;}
