struct S{unsigned x:3;}; unsigned f(struct S *s){return s->x;}
