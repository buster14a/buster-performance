from pathlib import Path
import subprocess,os,csv,hashlib
d=Path(__file__).resolve().parent; out=d/'edge-qa';out.mkdir(exist_ok=True)
cases={
'undefined-name':'int f(int x){return x+no_such_value;}',
'invalid-pointer':'int f(int *p){return p;}',
'volatile-load':'int f(volatile int *p){return *p;}',
'volatile-local':'int f(volatile int x){return x;}',
'ordinary-control':'int f(int x){if (x<3) return x+2;return x-2;}',
'conditional-expr':'int f(int x,int y){return x?x:y;}',
'address-constant':'static int global; int *f(void){return &global;}',
'member-bitfield':'struct S{unsigned x:3;}; unsigned f(struct S *s){return s->x;}',
'floating-return':'double f(double a){return a+1.0;}',
'variadic-decl':'int f(int x,...){return x;}',
'plain-function-alias':'extern int a(int) __asm__("named_a");int f(int v){return a(v);}',
'special-abi':'int __attribute__((ms_abi)) f(int x){return x;}',
'static-callee':'static int t(int x){return x+4;} int f(int y){return t(y);}',
'asm-block':'int f(int x){__asm__("" : "+r"(x));return x;}',
'void-expression':'int f(int x){return (void)x;}',
'nested-calls':'extern int e(int); int f(int x){return e(e(x));}',
'checked-initializer':'int f(int x){int a=x+1;return a*2;}',
'unit-data':'int g=73;int f(int x){return x+1;} int use(void){return g;}',
'comma-side-effect':'extern int e(int); int f(int x){return (e(x),41);}',
'noreturn-decl':'__attribute__((noreturn)) int f(int x){return x;}',
'unsequenced':'int f(int x){return x++ + ++x;}',
'long-enum':'enum E { E1=1,E2=2 }; enum E f(enum E x){return x;}',
'unused-param':'static int f(int x,int y){return x;}int t(int a,int b){return f(a,b);}',
'bool-return':'_Bool f(int x){return x;}',
'signed-zero-ext':'signed char f(void){return -103;} unsigned char g(void){return 250;}',
}
sha=lambda x:hashlib.sha256(x).hexdigest()
with (out/'matrix.tsv').open('w') as f:
 w=csv.writer(f,delimiter='\t');w.writerow(['case','policy','ref_code','native_code','objects','stdout','stderr','diagnostic_bytes'])
 for name,source in cases.items():
  src=out/(name+'.c');src.write_text(source+'\n')
  for mode,flags in [('default',[]),('warnings',['-Wall','-Wextra']),('everything',['-Weverything','-Wno-c++-compat'])]:
   result=[]
   for v in ('ordinary','source'):
    obj=out/(name+'.'+v+'.o');obj.unlink(missing_ok=True)
    env=dict(os.environ)
    if v=='source':env['BUSTER_BODY_SOURCE_NATIVE']='1'
    o=subprocess.run([d/'compiler','--lanes','1','-c','-nostdinc',*flags,src,'-o',obj],capture_output=True,env=env)
    result.append((o.returncode,sha(obj.read_bytes()) if obj.exists() else '',o.stdout,o.stderr))
   a,b=result;matches=[a[i]==b[i] for i in range(1,4)];w.writerow([name,mode,a[0],b[0],*matches,len(a[3])])
   if a!=b:print(name,mode,a[0:2],b[0:2],a[3][:220],b[3][:220])
