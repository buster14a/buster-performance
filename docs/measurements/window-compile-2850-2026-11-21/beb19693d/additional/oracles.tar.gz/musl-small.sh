#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs;source ../switch-local-args.sh
eval "all=($musl_arguments)"
flags=(); for a in "${all[@]}";do [[ $a == *.c ]] && break;flags+=("$a");done
mkdir -p "$d/musl-small"
for src in dirent/dirfd dirent/telldir string/bcmp string/index string/rindex string/strings/ffsl ctype/toascii strings/ffsl thread/pthread_self thread/pthread_getcpuclockid unistd/getpid;do
 f=$musl/src/$src.c;[[ -e $f ]] || continue
 n=${src##*/};p=$d/musl-small/$n; b=$d/compiler
 "$b" --lanes 1 -c "${flags[@]}" "$f" -o "$p.ref.o" >"$p.ref.stdout" 2>"$p.ref.stderr"
 BUSTER_BODY_SOURCE_NATIVE=1 BUSTER_BODY_NATIVE_AUDIT=1 "$b" --lanes 1 -c "${flags[@]}" "$f" -o "$p.native.o" >"$p.native.stdout" 2>"$p.native.stderr"
 cmp "$p.ref.o" "$p.native.o"; rg '^body-native-summary' "$p.native.stderr" | sed "s@^@$src\t@"
done
