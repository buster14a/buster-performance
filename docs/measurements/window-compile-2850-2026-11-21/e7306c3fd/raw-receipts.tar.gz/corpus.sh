#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d=$PWD
cd ../switch-inputs; source ../switch-local-args.sh
case $1 in
generated) args=(-nostdinc -fwrapv "$d/generated.c");;
fixture) args=(-nostdinc "$d/fixture.c");;
sqlite) eval "args=($sqlite_arguments)";;
main) tree=$PWD/../pregraph-warning-study/compiler-source
  args=(-march=native -I"$tree/src" -fwrapv -funsigned-char --predefines "$PWD/../proof-predefines.h" "$tree/src/buster/compiler/main.c");;
esac
rm -f "$d/$1.rows"
BUSTER_BODY_WRITE_PUBLICATION="$d/$1.rows" BUSTER_CHECK_BODY_SOURCE_ONLY=1 BUSTER_CHECK_BODY_ADMIT_ALL=1 BUSTER_BODY_SOURCE_OPS=1 "$d/compiler" --lanes 1 -c "${args[@]}" -o "$d/unused.o" > "$d/$1.source.out" 2> "$d/$1.source"
BUSTER_BODY_TYPED_REFERENCE=1 "$d/compiler" --lanes 1 -c "${args[@]}" -o "$d/$1.o"  > "$d/$1.ref.out" 2> "$d/$1.ref"
BUSTER_BODY_READ_PUBLICATION="$d/$1.rows" "$d/compiler" --lanes 1 -c "${args[@]}" -o "$d/$1.published.o" > "$d/$1.published.out" 2> "$d/$1.published"
cmp "$d/$1.o" "$d/$1.published.o"
sha256sum "$d/$1.o" "$d/$1.published.o"
BUSTER_BODY_DIRECT_OPERATIONS=1 BUSTER_BODY_DIRECT_AUDIT=1 "$d/compiler" --lanes 1 -c "${args[@]}" -o "$d/$1.direct.o" > "$d/$1.direct.out" 2> "$d/$1.direct"
cmp "$d/$1.o" "$d/$1.direct.o"
sha256sum "$d/$1.direct.o"
