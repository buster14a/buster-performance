from compare import *
import subprocess
clang='/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang'
rows=table(d/'fixture.source','source')
with (d/'from-checker.s').open('w') as f:
    print('.text',file=f)
    for row in rows.values():
        name,params,count,entries,machine,fixup=row
        print(f'.p2align 4\n.globl {name}\n.type {name},@function\n{name}:',file=f)
        print('.byte '+','.join(hex(b) for b in bytes.fromhex(machine)),file=f)
        if fixup:
            for offset,kind,addend,target in reloc(fixup):
                assert kind==4
                print(f'.globl {target}\n.reloc {name}+{offset}, R_X86_64_PLT32, {target}{addend:+d}',file=f)
        print(f'.size {name},.-{name}',file=f)
    print('.section .note.GNU-stack,"",@progbits',file=f)
def run(args):
    return subprocess.run(args,check=True,cwd=d,capture_output=True).stdout
run([clang,'-c','from-checker.s','-o','from-checker.o'])
run([clang,'-O0','-c','fixture.c','-o','clang.o'])
a,b=Object((d/'fixture.o').read_bytes()),Object((d/'from-checker.o').read_bytes())
assert set(b.bodies)==set(a.bodies)
for name in b.bodies: assert a.function(name)==b.function(name),(name,a.function(name),b.function(name))
outputs={}
for variant in ['fixture','from-checker','clang']:
    run([clang,'native-driver.c',variant+'.o','-o',variant+'-run']);outputs[variant]=run(['./'+variant+'-run'])
assert len(set(outputs.values()))==1,outputs
print('Identical ordinary ELF bytes and relocations for every fixture function; three independently linked programs match.',next(iter(outputs.values())).decode().strip())
