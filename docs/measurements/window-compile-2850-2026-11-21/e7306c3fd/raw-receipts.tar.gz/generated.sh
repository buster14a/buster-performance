#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d=$PWD
bash corpus.sh generated > generated.objects
clang=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$clang" -O0 -fwrapv -c generated.c -o generated.clang.o
for mode in baseline published direct clang; do
  o="generated.$mode.o"; [[ $mode != baseline ]] || o=generated.o
  "$clang" -O0 -fwrapv generated-driver.c "$o" -o "generated-$mode"
  "./generated-$mode" > "generated-$mode.stdout"
  cmp generated-baseline.stdout "generated-$mode.stdout"
done
python3 compare.py generated > generated.comparison.log
tail -n 1 generated.comparison.log
cat generated-baseline.stdout
