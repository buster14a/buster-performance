from pathlib import Path
import csv,subprocess,os,hashlib,sys
d=Path(__file__).resolve().parent
g=sys.argv[1];opts=[s for s in sys.argv[2:] if not s.endswith('.c')];files=[s for s in sys.argv[2:] if s.endswith('.c')]
ref=(d/'../main-fbef-clean/build/compiler').resolve(); arms={'clean':ref,'all-local':d/'compiler'}
roots={a:d/('real-'+a) for a in arms}; sha=lambda s:hashlib.sha256(s).hexdigest()
for r in roots.values():r.mkdir(exist_ok=True)
handles={a:(r/(g+'.tsv')).open('w',buffering=1) for a,r in roots.items() if a!='clean'};tables={a:csv.writer(f,delimiter='\t') for a,f in handles.items()}
for t in tables.values():t.writerow('file policy ref-exit local-exit obj-equal stdout-equal stderr-equal bytes ref-sha source-sha ref-object-sha source-object-sha'.split())
for i,s in enumerate(files):
 for policy,flags in [('default',[]),('wall',['-Wall','-Wextra']),('strict',['-Wall','-Wextra','-Werror']),('quiet',['-w']),('everything',['-Weverything'])]:
  reference=None
  for arm,exe in arms.items():
   out=roots[arm];obj=out/(g+'-unit.o');obj.unlink(missing_ok=True)
   r=subprocess.run([exe,'--lanes','1','-c',*opts,*flags,s,'-o',obj],env=os.environ|({'BUSTER_CONTROL_EARLY_RELEASE':'1','BUSTER_CONTROL_EARLY_NATIVE':'1','BUSTER_CONTROL_SOURCE_NATIVE':'1','BUSTER_SOURCE_CONTROL_MASKS':'1','BUSTER_SOURCE_BORROW_CHILDREN':'1','BUSTER_SOURCE_FIRST_NODE':'1','BUSTER_SOURCE_WRITE_COLUMNS':'1','BUSTER_SOURCE_GROW_GRAPH':'1','BUSTER_SOURCE_RETIRE_LISTS':'1','BUSTER_SOURCE_FILE_DATA':'1'} if arm!='clean' else {}),capture_output=True,stdin=subprocess.DEVNULL,timeout=180)
   obs=(r.returncode,sha(obj.read_bytes()) if obj.exists() else '',r.stdout,r.stderr)
   if g in ('main','sqlite'):(out/f'{g}-{policy}.stderr').write_bytes(obs[3])
   if arm=='clean':reference=obs;continue
   a,b=reference,obs;tables[arm].writerow((s,policy,a[0],b[0],*(int(a[j]==b[j]) for j in range(1,4)),len(a[3]),sha(a[3]),sha(b[3]),a[1],b[1]))
   if a!=b:
    (out/f'{g}-{i}-{policy}-clean.stderr').write_bytes(a[3]);(out/f'{g}-{i}-{policy}-source.stderr').write_bytes(b[3])
for f in handles.values():f.close()
