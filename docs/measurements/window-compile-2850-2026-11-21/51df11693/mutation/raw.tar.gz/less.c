extern int printf(const char *,...);
int less(int a,int b){return a<b;}
int main(int argc,char **argv){int x=less(-argc,2);printf("%d\n",x);return 0;}
