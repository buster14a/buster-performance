extern int printf(const char*,...);
struct A{ unsigned value; int other; }; struct B { unsigned first; struct A a; struct B *next; };
struct Bits { unsigned a:3; unsigned b:5; volatile unsigned v; };
__attribute__((noinline)) unsigned eval(struct B *p,struct Bits *b){return (p->next->a.value * 13u) ^ (p->a.value<<2) ^ b->a ^ b->b ^ b->v ^ p->first;}
int main(int argc,char **argv){unsigned i=(unsigned)argc;struct B q={i*7u,{i+3u,2},0};struct B p={i*3u,{i^31u,5},&q};
struct Bits b={i,7u+i,i*17u};printf("%u\n",eval(&p,&b));return 0;}
