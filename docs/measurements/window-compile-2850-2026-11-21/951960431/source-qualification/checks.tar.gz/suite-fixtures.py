from pathlib import Path
from collections import Counter
from itertools import product
import ast,re,sys,subprocess,tempfile
out=Path(__file__).resolve().parent
baseline,head,pinned=(str(Path(x).resolve()) for x in sys.argv[1:4])
repo=(Path(sys.argv[4]).resolve() if len(sys.argv)>4 else out.parent/'unseq-outer-tree')
s=(repo/'src/buster/compiler/c_check_unsequenced_driver_test.c').read_text()
patterns=re.findall(r'static const char (\w+)\[\] =\n(.*?);\n\n',s,re.S)
counts=Counter()
with tempfile.TemporaryDirectory() as td:
 for name,text in patterns:
  if 'unsequenced' not in name: continue
  src=Path(td)/(name+'.c')
  src.write_text(''.join(ast.literal_eval(m.group(1)) for l in text.splitlines() if (m:=re.fullmatch(r'    ("(?:[^"\\]|\\.)*")',l))))
  assert src.read_text().strip(),name
  for std,policy in product(['-std=gnu17','-std=c23'],[[],['-Wall','-Wextra'],['-Werror=unsequenced'],['-w'],['-Wno-sequence-point'],['-Wno-everything','-Wunsequenced']]):
   flags=[std,*policy,'-fsyntax-only','-fno-caret-diagnostics','-fno-color-diagnostics']
   oracle=subprocess.run([pinned,*flags,str(src)],capture_output=True)
   target=(oracle.returncode,oracle.stdout,oracle.stderr)
   rows=[]
   for mode in ([],['--scalar'],['--deferred-bodies','--lanes','3']):
    results=[]
    for exe in (baseline,head):
     p=subprocess.run([exe,*mode,*flags,str(src)],capture_output=True)
     results.append((p.returncode,p.stdout,p.stderr))
    assert results[0]==results[1],(name,std,policy,mode)
    counts['native-pairs']+=1
    counts['exact-clang']+=results[1]==target
    if results[1]!=target: rows.append(mode)
   if rows: print('preexisting clang variation',name,std,policy,rows)
  print(name,dict(counts),flush=True)
