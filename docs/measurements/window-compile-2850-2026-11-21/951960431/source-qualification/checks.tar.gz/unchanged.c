int q(volatile int *a, int n) {
    int x = n;
    a[x & 1] = x;
    (void)(x += x);
    (void)(x *= 2);
    if ((x = n)) { x++; --x; }
    x = (n++, n);
    x = (n ? n : x);
    return (x = n);
}
