#define ADVANCE(v) ((v)++)
int check(int x) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunsequenced"
    x = ADVANCE(x);
#pragma clang diagnostic warning "-Wunsequenced"
    x = ADVANCE(x);
#pragma clang diagnostic pop
    (void)(x += x);
    return x++ + x;
}
