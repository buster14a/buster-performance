int unrelated = unknown_name;
int after(int x, int y) {
    if (0) x = x++;
    x = x + y;
    if (y) x += ++x;
    return x;
}
