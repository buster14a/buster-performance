from pathlib import Path
from tempfile import TemporaryDirectory
from itertools import product
import collections,subprocess,sys,hashlib
work=Path(__file__).resolve().parent
base,candidate,clang=(Path(x).resolve() for x in sys.argv[1:4])
compile_modes=[['-c'],['-c','--node-window'],['-c','--node-window-assignments'],['-c','--deferred-bodies','--lanes','3'],['-c','--scalar'],['-fsyntax-only'],['-c','-g']]
policies=[[],['-Wall','-Wextra'],['-Werror'],['-Werror=unsequenced'],['-w'],['-Wno-unsequenced'],['-Wno-everything','-Wunsequenced']]
results=collections.Counter()
with TemporaryDirectory() as td:
 src=Path(td)/'example.c';obj=Path(td)/'example.o'
 for source in (work/'sole.c',work/'pragma.c',work/'unchanged.c',work/'recovered.c'):
  src.write_bytes(source.read_bytes())
  for mode,flags in product(compile_modes,policies):
   got=[]
   for exe in (base,candidate):
    obj.unlink(missing_ok=True)
    p=subprocess.run([str(exe),*mode,*flags,str(src),'-o',str(obj)],capture_output=True)
    got.append((p.returncode,p.stdout,p.stderr,obj.read_bytes() if obj.exists() else None))
   assert got[0]==got[1],(source,mode,flags)
   rc,_,stderr,elf=got[0]
   assert b'unsupported option' not in stderr
   assert rc==0 or b'error:' in stderr
   results['pairs']+=1;results['objects']+=elf is not None;results['rejected']+=bool(rc);results['diagnostic-bytes']+=len(stderr)
  for flags in policies:
   got=[]
   for exe in (base,candidate,clang):
    p=subprocess.run([str(exe),'-fsyntax-only','-fno-caret-diagnostics','-fno-color-diagnostics',*flags,str(src)],capture_output=True)
    got.append((p.returncode,p.stdout,p.stderr))
   assert got[0]==got[1]==got[2],(source,flags,[(r[0],r[2]) for r in got])
   results['independent-clang-control']+=1
  print(source.name,dict(results),flush=True)
