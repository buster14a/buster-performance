from pathlib import Path
from collections import Counter
from itertools import product
from tempfile import TemporaryDirectory
import hashlib,os,re,subprocess,sys
d=Path(__file__).resolve().parent
base,head,clang=[str(Path(a).resolve()) for a in sys.argv[1:4]]
ops=['=','+=','-=','*=','/=','%=','<<=','>>=','&=','^=','|=']
patterns=[
 'X OP X + y', 'X OP (X ? y : X)', 'X OP (y, X)', 'X OP (*p + a[y & 3])',
 'X OP X++', 'X OP ++X', 'X OP (X OP y)', 'X OP (y ? X++ : X)', 'X OP (++y, X)',
 'X OP joint(X++, X)', 'joint(X OP y, X)', 'joint(X++, X++)', 'joint(NEXT(X), X)',
 'X OP NEXT(X)', 'X OP CHANGE(X)', 'X OP (y && NEXT(X))', 'X OP (y || NEXT(X))',
 'X OP (int)sizeof(X++)', 'X OP __builtin_choose_expr(1, X, NEXT(X))',
 'X OP _Generic(y, int: X, default: X++)', '++X', '--X', 'X++', 'X--',
 'X OP VALUE(X)', 'X OP ({ int q = y; q + X; })', 'X OP (X++ + X)', 'joint(X, X OP (y+X))',
]
wraps=['E;','(void)(E);','if ((E)) use(y);','while ((E)) { break; }','return (E);']
prelude='''#define NEXT(n) ((n)++)
#define CHANGE(n) ((n) += 3)
#define VALUE(n) (n)
int joint(int, int); void use(int);
'''
def operand(pattern,name,op):
 return re.sub(r'\bX\b',lambda _:name,pattern).replace('OP',op)
def expressions():
 for which,(pattern,op,wrapper,x,volatile) in enumerate(product(patterns,ops,wraps,('x','*p','a[0]'),(False,True))):
  expr=operand(pattern, 'x' if x=='x' else '('+x+')',op)
  qual='volatile ' if volatile else ''
  text=f'int f{which}({qual}int x, int y, {qual}int *p, {qual}int *a) {{ '+wrapper.replace('E',expr)+' return y; }'
  yield which,text
def run(exe,args,source,obj):
 obj.unlink(missing_ok=True)
 p=subprocess.run([exe,*args,str(source),'-o',str(obj)],capture_output=True)
 return p.returncode,p.stdout,p.stderr,hashlib.sha256(obj.read_bytes()).digest() if obj.exists() else None
cases=list(expressions())
if '--screen' in sys.argv:
 cases=cases[::11]
totals=Counter()
with TemporaryDirectory() as tmp:
 src=Path(tmp)/'test.c';obj=Path(tmp)/'test.o'
 for off in range(0,len(cases),64):
  group=cases[off:off+64]
  src.write_text(prelude+'\n'.join(s for n,s in group)+'\n')
  for k,mode in enumerate((['-fsyntax-only'],['-c'],['-c','--scalar'],['-c','--deferred-bodies','--lanes','3'])):
   flags=['-std=gnu17' if (off//64)%2==0 else '-std=c23','-Wno-everything','-Wunsequenced','-ferror-limit=0']
   if k in (0,1): flags.append('-fno-caret-diagnostics')
   if k==1 and (off//64)%3==0: flags.append('-Werror')
   if k==2 and (off//64)%5==0: flags.append('-w')
   before=run(base,[*mode,*flags],src,obj); after=run(head,[*mode,*flags],src,obj)
   assert before==after,(off,k,mode,[(r[0],len(r[2]),r[3]) for r in (before,after)])
   totals['native-pairs']+=1;totals['native-ELF-pairs']+=before[3] is not None;totals['native-diagnostic-bytes']+=len(before[2]);totals['native-rejections']+=bool(before[0])
   if k==0:
    oracle=run(clang,[*mode,*flags],src,obj)
    if before[:3]!=oracle[:3]:
     totals['clang-baseline-diff-files']+=1
     if not (d/'first-clang-diff.c').exists():
      (d/'first-clang-diff.c').write_text(src.read_text())
      (d/'first-clang-diff.buster').write_bytes(before[2]);(d/'first-clang-diff.clang').write_bytes(oracle[2])
    else: totals['clang-matched-files']+=1
  totals['functions']+=len(group)
  print(off,dict(totals),flush=True)
