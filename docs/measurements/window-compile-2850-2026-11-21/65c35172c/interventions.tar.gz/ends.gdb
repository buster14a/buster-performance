set pagination off
set debuginfod enabled off
set confirm off
python
import gdb
def word(addr,z):return int.from_bytes(gdb.selected_inferior().read_memory(addr,z).tobytes(),'little')
class Returned(gdb.FinishBreakpoint):
 def __init__(self,ptr):
  super().__init__(gdb.newest_frame(),internal=True)
  self.ptr=ptr
 def stop(self):
  inf=gdb.selected_inferior();rows=word(self.ptr+8,8);count=word(self.ptr+24,4);changed=0
  for i in range(count):
   row=rows+40*i
   if 'ends'=='instructions' and word(row+4,4):addr=word(row+16,8)+12
   elif 'ends'=='bytes' and word(row+12,4):addr=word(row+32,8)
   elif 'ends'=='ends' and word(row+8,4):addr=word(row+24,8)
   else:continue
   inf.write_memory(addr,bytes([word(addr,1)^1]));changed+=1
  print('measured-handoff rows=%d changed=%d'%(count,changed))
  return False
class Entry(gdb.Breakpoint):
 def stop(self):
  Returned(word(int(gdb.parse_and_eval('$rdi'))+232,8))
  return False
Entry("*'check_driver_live_native_prefix'")
end
run
