#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;tag=${1:-v1};out=$PWD/results/structural-single-source-names-$tag;mkdir -p "$out"
dir=$PWD/trees/structuralnames$tag
if ! test -d "$dir";then git -C src worktree add -q --detach "$dir" 0e1d5b825;git -C "$dir" apply "$root/pp-structural/names-$tag.patch";fi
src=$dir/src;source corpora.sh;eval "args=($sqlite_arguments)"
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
lock() { ./lock.sh taskset -c 2 "$@"; }
lock env PATH="$paths:$PATH" clang -O3 -gline-tables-only -fno-omit-frame-pointer -std=gnu17 -fwrapv -funsigned-char -march=native -I"$src" -I"$src/buster/compiler" "$root/pp-structural/source-parser-$tag.c" -o "$out/probe" >"$out/build" 2>&1
for h in deferred history;do
 for arm in baseline spans;do
  vars=();[[ $arm != baseline ]] || vars+=(PP_EAGER=1);[[ $h != history ]] || vars+=(PP_RECORD_HISTORY=1)
  lock env "${vars[@]}" PP_SPAN_REPORT=1 PP_TREE="$out/$h-$arm.tree" PP_PRINT="$out/$h-$arm.i" PP_ROWS="$out/$h-$arm.rows" "$out/probe" "${args[@]}" >"$out/$h-$arm.preflight" 2>"$out/$h-$arm.lease"
  cmp "$out/$h-$arm.i" "$root/results/active-source-profile/ordinary.i"
  cmp "$out/$h-$arm.rows" "$root/results/active-source-origins/eager.$h.rows"
 done
 cmp "$out/$h-baseline.tree" "$out/$h-spans.tree"
done
for r in 1 2 3;do
 case $r in 1)arms=(baseline spans consumed consumed spans baseline);;2)arms=(spans consumed baseline baseline consumed spans);;3)arms=(consumed baseline spans spans baseline consumed);;esac
 for i in {0..5};do
 arm=${arms[i]};vars=();[[ $arm != baseline ]] || vars=(PP_EAGER=1);[[ $arm != consumed ]] || vars=(PP_CONSUME_NAMES=1)
 lock env "${vars[@]}" PP_SPAN_REPORT=1 "$out/probe" "${args[@]}" >"$out/$r-$i-$arm.tsv" 2>"$out/$r-$i-$arm.lease"
 done
done
(cd "$out" && sha256sum *.tree *.rows *.i probe >hashes)
