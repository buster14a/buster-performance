#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;out=$PWD/results/structural-single-fences
src=$PWD/trees/structuralgap/src;mkdir -p "$out"
source corpora.sh;eval "args=($sqlite_arguments)";input=${args[-1]}
toolchain=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
lock() { ./lock.sh taskset -c 2 "$@"; }
lock env PATH="$toolchain:$PATH" clang -O3 -gline-tables-only -march=native -I"$root/pp-structural/fences" "$root/pp-structural/fence-scan.c" -o "$out/probe" >"$out/build" 2>&1
lock "$out/probe" "$input" "$out/hashes.tsv" >"$out/preflight.out" 2>"$out/preflight.err"
cmp "$out/hashes.tsv" "$root/results/structural-single-index/hashes.tsv"
for i in {1..9};do lock "$out/probe" "$input" >"$out/$i.out" 2>"$out/$i.err";done
sha256sum "$out/probe" "$out/hashes.tsv" "$input" >"$out/hashes"
