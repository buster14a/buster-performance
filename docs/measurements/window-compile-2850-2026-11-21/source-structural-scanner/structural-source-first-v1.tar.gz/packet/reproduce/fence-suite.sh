#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;src=$d/../pp-structural-fences/src
cc=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$cc" -O2 -g0 -std=gnu17 -march=native -fwrapv -funsigned-char -I"$src" -I"$src/buster/compiler" "$d/suite.c" -o "$d/fence-suite"
"$d/fence-suite" "$d"/../active-source-study/edges/*.c "$d/../switch-inputs/sqlite/sqlite3.c" "$src"/buster/compiler/c_preprocessor*.c "$src"/buster/compiler/c_lexer*.c "$d"/../switch-inputs/inputs/lua-5.4.8/src/*.c >"$d/fence-suite.out" 2>"$d/fence-suite.err"
