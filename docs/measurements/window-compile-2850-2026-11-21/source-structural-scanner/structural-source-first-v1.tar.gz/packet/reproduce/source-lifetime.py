from pathlib import Path
import os,subprocess,re,sys
root=Path(__file__).resolve().parent;exe=root/(sys.argv[1] if len(sys.argv)>1 else 'source-parser');tmp=root/('lifetime-'+exe.name);tmp.mkdir(exist_ok=True)
pad=(b'/* '+b'x'*65536+b' */\n')*17
a=tmp/'first.h';b=tmp/'second.h';p=tmp/'main.c'
header_a=b'#define EMA(x) (x)\nstruct first { int shared_name; };\nextern int active_header_name;\n'
header_b=b'#define EMB(x) EMA(x)\nstruct second { int shared_name; };\nextern int active_header_name;\n'
b.write_bytes(header_b)
cases={
 'headers-then-main':b'#include "first.h"\n#include "second.h"\n#line 91 "other.c"\nint active_header_name; int actual(struct first p) { return EMB(p.shared_name); }\n',
 'header-redefined':b'#include "first.h"\n#undef EMA\n#define EMA(x) ((x)+1)\n#include "second.h"\nint actual(struct second p) { return EMB(p.shared_name); }\n',
 'embedded-diagnostics':b'#include "first.h"\n#include "second.h"\n#line 72 "later.c"\n#warning delayed_range\nint actual(struct first p) { return p.shared_name; }\n',
 'clashing-spellings': b'#include "first.h"\n#define active_header_name p\nint actual(struct first active_header_name) { return active_header_name.shared_name; }\n'
}
for case,body in cases.items():
 p.write_bytes(pad+b'extern int establish_primary_views;\n'*700+body)
 for mode in ['default','history','max-warnings']:
  out=[]
  for arm in ['baseline','spans']:
   a.write_bytes(header_a)
   prefix=tmp/(case+'-'+mode+'-'+arm); env=dict(os.environ,PP_TREE=str(prefix)+'.tree',PP_PRINT=str(prefix)+'.i',PP_ROWS=str(prefix)+'.rows',PP_UNLINK_PROBE=str(a),PP_DEMAND_REVERSE='1')
   if arm=='baseline':env['PP_EAGER']='1'
   if mode=='history':env['PP_RECORD_HISTORY']='1'
   flags=['-Weverything'] if mode=='max-warnings' else []
   r=subprocess.run([str(exe),*flags,'-I',str(tmp),str(p)],capture_output=True,env=env)
   out.append((r.returncode,r.stderr,*[Path(str(prefix)+ext).read_bytes() if r.returncode==0 else b'' for ext in ('.i','.rows','.tree')]))
  if out[0]!=out[1] or out[0][0]:raise SystemExit((case,mode,[(x[0],x[1][:900]) for x in out]))
  print(case,mode,'same transcript, output, full parser tree and diagnostics after unlink; reverse/idempotent first demand')
