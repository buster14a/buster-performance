from pathlib import Path
from collections import Counter,defaultdict
from array import array
from bisect import bisect_left,bisect_right
import csv
d=Path(__file__).resolve().parent
ledger=array('I');ledger.frombytes((d/'raw.ledger').read_bytes());starts=ledger[1::3]
base=int((d/'macro-range').read_text().split()[1])
defs={}
for r in csv.reader((d/'macro-defs.tsv').open(),delimiter='\t'):
 name=r[0];loc,fun,simple,order,body,params=map(int,r[1:]);defs[name,loc]=(fun,simple,order,body,params)
metrics=defaultdict(Counter);totals=Counter()
for r in csv.reader((d/'macro-history.tsv').open(),delimiter='\t'):
 name=r[0];loc,begin,end,parent,builtin=map(int,r[1:])
 if (name,loc) not in defs:continue
 fun,simple,order,body,params=defs[name,loc]
 if parent or not (0<=begin-base<=end-base<9507037):continue
 low=bisect_left(starts,begin-base);top=bisect_right(starts,end-base)
 if low==len(starts) or starts[low]!=begin-base:continue
 x=metrics[name];x['calls']+=1;x['function_calls']+=fun;x['raw_rows']+=top-low
 if fun and simple and not order:
  x['erasing_calls']+=1;x['erasing_rows']+=top-low
 for k in ['calls','function_calls','raw_rows','erasing_calls','erasing_rows']:pass
with (d/'macro-rank.tsv').open('w') as f:
 keys=['calls','function_calls','raw_rows','erasing_calls','erasing_rows']
 print('name',*keys,sep='\t',file=f)
 for name,x in sorted(metrics.items(),key=lambda v:-v[1]['raw_rows']):
  totals.update(x);print(name,*(x[k] for k in keys),sep='\t',file=f)
print(totals)
