#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;src=$d/../pp-structural-live/src
cc=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$cc" -O2 -g -fno-omit-frame-pointer -march=native -fwrapv -funsigned-char -std=gnu17 -I"$src" -I"$src/buster/compiler" "$d/projected.c" -o "$d/projected"
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";cd "$d"
PP_PRINT="$d/projected.i" PP_ROWS="$d/projected.rows" ./projected "${args[@]}" >projected.tsv
cmp original.i projected.i && python ../active-source-study/origin-diff.py ../active-source-study/local-origins/eager.rows projected.rows
