from pathlib import Path
from array import array
from collections import Counter
from bisect import bisect_right
import re,json,csv
d=Path(__file__).resolve().parent
def words(b):
 a=array('I');a.frombytes(b);return a
s=(d.parent/'switch-inputs/sqlite/sqlite3.c').read_bytes()
a=d.parent/'active-source-study/target';src=words((d/'raw.ledger').read_bytes());raw=(a/'primary.raw').read_bytes();n=len(raw)//9
out=(a/'output.rows').read_bytes();t=len(out)//10;flags=out[t:2*t];kinds=out[:t];locs=words(out[2*t:6*t]);base=int(re.search(r'base (\d+)',(a/'census.err').read_text())[1]);original={loc-base:k for loc,k,f in zip(locs,kinds,flags) if not f&8 and base<=loc<base+len(s)}
defs={r[0].encode() for r in csv.reader((d/'macro-defs.tsv').open(),delimiter='\t')}
rows=[];occ=Counter();keywords=set();bad=0
for k,start,end in zip(src[::3],src[1::3],src[2::3]):
 if k&127!=1 or start not in original:continue
 word=s[start:end]
 if not re.fullmatch(rb'[a-zA-Z_$][a-zA-Z_$0-9]*',word):bad+=1;continue
 kw=original[start]!=1
 if kw:keywords.add(word)
 rows.append((word,kw,start));occ[word]+=1
def summary(watched):
 props={
 'first byte':lambda x:x[:1],
 'first 2 bytes':lambda x:x[:2],
 'first and last bytes':lambda x:(x[0],x[-1]),
 'length and first byte':lambda x:(len(x), x[0]),
 'length, first and last byte':lambda x:(len(x),x[0],x[-1]),
 'length and first two bytes':lambda x:(len(x),x[:2]),
 'length, first two and last byte':lambda x:(len(x),x[:2],x[-1]),
 'exact':lambda x:x,
 }
 result={}
 for name,key in props.items():
  maybe={key(x) for x in watched};admit=Counter({w:n for w,n in occ.items() if key(w) not in maybe})
  result[name]=[sum(admit.values()),len(admit),len(maybe)]
 return result
print(json.dumps({'direct_raw_names':len(rows),'direct_distinct':len(occ),'nonplain_rejected':bad,'macro_spellings':len(defs),'direct_keywords':sum(k for _,k,_ in rows),'keyword_spellings':sorted(x.decode() for x in keywords),'macro_only':summary(defs),'macros_and_current_keywords':summary(defs|keywords)},indent=2))
