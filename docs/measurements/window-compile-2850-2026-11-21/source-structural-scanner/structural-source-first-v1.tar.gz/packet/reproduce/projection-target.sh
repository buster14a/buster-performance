#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD
out=$PWD/results/structural-single-projection;mkdir -p "$out"
if ! test -d trees/structuralprojection;then git -C src worktree add -q --detach "$PWD/trees/structuralprojection" 0e1d5b825;fi
git -C trees/structuralprojection apply --check "$root/pp-structural/projection.patch"
git -C trees/structuralprojection apply "$root/pp-structural/projection.patch"
src=$PWD/trees/structuralprojection/src;source corpora.sh;eval "args=($sqlite_arguments)"
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
lock() { ./lock.sh taskset -c 2 "$@"; }
lock env PATH="$paths:$PATH" clang -O3 -gline-tables-only -fno-omit-frame-pointer -std=gnu17 -fwrapv -funsigned-char -march=native -I"$src" -I"$src/buster/compiler" "$root/pp-structural/projected.c" -o "$out/probe" >"$out/build" 2>&1
for history in deferred history;do
 for arm in baseline projection;do
  vars=();if [[ $arm == baseline ]];then vars+=(PP_EAGER=1);fi
  if [[ $history == history ]];then vars+=(PP_RECORD_HISTORY=1);fi
  lock env "${vars[@]}" PP_PRINT="$out/$arm.$history.i" PP_ROWS="$out/$arm.$history.rows" "$out/probe" "${args[@]}" >"$out/$arm.$history.preflight" 2>"$out/$arm.$history.lease"
  cmp "$out/$arm.$history.i" "$root/results/active-source-profile/ordinary.i"
  cmp "$out/$arm.$history.rows" "$root/results/active-source-origins/eager.$history.rows"
 done
done
for r in {1..3};do
 if ((r%2));then arms=(baseline projection projection baseline);else arms=(projection baseline baseline projection);fi
 for i in {0..3};do arm=${arms[$i]};vars=();if [[ $arm == baseline ]];then vars=(PP_EAGER=1);fi
  lock env "${vars[@]}" "$out/probe" "${args[@]}" >"$out/$r-$i-$arm.tsv" 2>"$out/$r-$i-$arm.lease"
 done
done
(cd "$out" && sha256sum *.i *.rows probe >hashes)
