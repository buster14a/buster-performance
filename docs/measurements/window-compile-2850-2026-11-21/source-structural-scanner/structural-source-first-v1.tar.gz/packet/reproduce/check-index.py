from pathlib import Path
from array import array
import hashlib,json,sys
root=Path(__file__).resolve().parent
field=array('I');field.frombytes((root/'raw.ledger').read_bytes())
sentinels=[i for i in range(len(field)//3) if field[i*3] & 255 == 188]
rows=[tuple(map(int,line.split())) for line in Path(sys.argv[1]).read_text().splitlines()]
assert len(rows)==len(sentinels)
for (h,end),idx in zip(rows,sentinels):
 assert field[3*idx+1]==h
 j=idx+1
 while j<len(field)//3 and not(field[3*j]&128):j+=1
 assert field[3*(j-1)+2]<=end and (j==len(field)//3 or field[3*j+1]>=end),(h,end,idx,j)
print(f'{len(rows)} source directive offsets and all canonical token payload boundaries match')
