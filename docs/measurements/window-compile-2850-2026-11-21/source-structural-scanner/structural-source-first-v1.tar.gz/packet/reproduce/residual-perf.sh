#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;out=$PWD/results/structural-single-residual-perf
base=$PWD/results/structural-single-ideal
mkdir -p "$out"
source corpora.sh;eval "args=($sqlite_arguments)";input=${args[-1]}
for t in {1..720};do if test -s "$base/both.preflight" && test -s "$base/both.i" && cmp -s "$base/both.i" "$root/results/active-source-profile/ordinary.i";then break;fi;sleep 5;done
cmp "$base/both.i" "$root/results/active-source-profile/ordinary.i"
for r in 1 2 3;do
 if [[ $r == 2 ]];then arms=(both baseline);else arms=(baseline both);fi
 for arm in "${arms[@]}";do
  if [[ $arm == baseline ]];then over=$input;else over=$root/pp-structural/both.c;fi
  stem=$out/$r-$arm
  ./lock.sh taskset -c 2 env PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$over" perf record -e cycles:u -c 19001 -g --call-graph fp -o "$stem.perf" -- "$base/probe" "${args[@]}" >"$stem.tsv" 2>"$stem.lease"
  ./lock.sh taskset -c 2 perf report --stdio --no-children -g none -n --sort comm,symbol --percent-limit 0 -i "$stem.perf" >"$stem.flat" 2>"$stem.report.lease"
 done
done
sha256sum "$base/probe" >"$out/binary.sha256"
