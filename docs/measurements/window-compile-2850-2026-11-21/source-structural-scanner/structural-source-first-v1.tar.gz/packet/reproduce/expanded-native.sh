#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;out=$PWD/results/structural-single-expanded
base=$PWD/results/structural-single-ideal
mkdir -p "$out";source corpora.sh;eval "args=($sqlite_arguments)";input=${args[-1]}
expanded=$root/results/active-source-profile/ordinary.i
for n in {1..720};do test -x "$base/probe" && break;sleep 5;done
./lock.sh taskset -c 2 env PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$expanded" PP_PRINT="$out/expanded.i" "$base/probe" "${args[@]}" > "$out/expanded.preflight" 2>"$out/expanded.lease"
sha256sum "$expanded" "$out/expanded.i" >"$out/hashes"
for r in {1..3};do
 if ((r%2));then arms=(both expanded expanded both);else arms=(expanded both both expanded);fi
 for i in {0..3};do arm=${arms[i]};src=$expanded;if [[ $arm == both ]];then src=$root/pp-structural/both.c;fi
  ./lock.sh taskset -c 2 env PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$src" "$base/probe" "${args[@]}" >"$out/$r-$i-$arm.tsv" 2>"$out/$r-$i-$arm.lease"
 done
done
