from pathlib import Path
from array import array
import sys,json
root=Path(__file__).resolve().parent
source=Path(sys.argv[1]).read_bytes()
a=array('I');a.frombytes((root/'raw.ledger').read_bytes())
n=len(a)//3
skips=[]
for line in Path(sys.argv[2]).read_text().splitlines():
 f=line.split('\t')
 if f[0]=='pp-group-skip' and int(f[1])==len(source):skips.append((int(f[3]),int(f[4])))
skipped=bytearray(n)
for first,last in skips: skipped[first:last]=b'\1'*(last-first)
metadata={}
for mode in ('trivia','live','both'):
 stream=bytearray();previous=0;kept=0
 for i in range(n):
  if mode!='trivia' and skipped[i]:continue
  k,start,end=a[i*3:i*3+3]
  gap=source[previous:start];kept+=1
  if mode=='live' and (not i or not skipped[i-1]):stream+=gap
  else:
   # Keep physical line counts, logical line starts, and inter-token spacing.
   lines=gap.count(b'\n')+gap.count(b'\r')-gap.count(b'\r\n')
   if k&128:stream+=b'\n'*lines
   else:
    if k&256:stream+=b' '
    stream+=b'\\\n'*lines
  stream+=source[start:end]
  previous=end
 stream+=source[previous:] if mode=='live' else b'\n'*source[previous:].count(b'\n')
 output=root/(mode+'.c');output.write_bytes(stream)
 metadata[mode]={'physical_bytes':len(stream),'raw_rows':kept,'physical_lf':stream.count(b'\n')}
assert n==1166437 and sum(skipped)==463372
(root/'ideal.json').write_text(json.dumps(metadata,indent=2)+'\n')
