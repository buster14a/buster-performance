#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>
#include "buster/compiler/c_pp_structure.c"
static uint64_t clockns(void) {struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
int main(int argc,char**argv)
{
 if(argc<2)return 2;
 int f=open(argv[1],O_RDONLY);struct stat st;if(f<0 || fstat(f,&st)!=0)return 1;
 uint8_t* src=mmap(NULL,st.st_size,PROT_READ,MAP_PRIVATE,f,0);if(src==MAP_FAILED)return 1;
 PPSourceStructure index={ .directives=malloc(1u<<22),.capacity=(1u<<22)/sizeof(PPSourceDirective)};
 uint64_t start=clockns();bool ok=pp_structure_scan(src,st.st_size,&index);uint64_t ticks=clockns()-start;
 fprintf(stderr,"%u %u %u %u %u %lu\n",ok,index.count,index.comments,index.comment_bytes,index.unsafe,(unsigned long)ticks);
 if(argc>2 && ok){FILE* out=fopen(argv[2],"w");for(uint32_t i=0;i<index.count;i++)fprintf(out,"%u %u\n",index.directives[i].hash,index.directives[i].end);fclose(out);}
 return !ok;
}
