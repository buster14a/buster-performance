#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;src=$PWD/trees/factsmain0e1d/src
source corpora.sh;eval "args=($sqlite_arguments)";input=${args[-1]}
toolchain=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
kind=$1;out=$PWD/results/structural-single-$kind;mkdir -p "$out"
lock() { ./lock.sh taskset -c 2 "$@"; }
if [[ $kind == index ]];then
 lock env PATH="$toolchain:$PATH" clang -O3 -gline-tables-only -march=native -I"$root/pp-structural" "$root/pp-structural/scan.c" -o "$out/scan" >"$out/build" 2>&1
 lock "$out/scan" "$input" "$out/hashes.tsv" >"$out/preflight.out" 2>"$out/preflight.err"
 for i in {1..9};do lock "$out/scan" "$input" >"$out/$i.out" 2>"$out/$i.err";done
 sha256sum "$out/scan" "$out/hashes.tsv" "$input" >"$out/hashes"
elif [[ $kind == ideal ]];then
 lock env PATH="$toolchain:$PATH" clang -O3 -gline-tables-only -fno-omit-frame-pointer -std=gnu17 -fwrapv -funsigned-char -march=native -I"$src" -I"$src/buster/compiler" "$root/pp-structural/raw-oracle.c" "$root/pp-structural/overlay.c" -Wl,--wrap=open -o "$out/probe" >"$out/build" 2>&1
 for arm in baseline live trivia both;do
  if [[ $arm == baseline ]];then over=$input;else over=$root/pp-structural/$arm.c;fi
  lock env PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$over" PP_PRINT="$out/$arm.i" "$out/probe" "${args[@]}" >"$out/$arm.preflight" 2>"$out/$arm.lease"
  cmp "$out/$arm.i" "$root/results/active-source-profile/ordinary.i"
 done
 for r in 1 2 3;do
  case $r in 1) arms=(baseline trivia live both both live trivia baseline);;2) arms=(live both baseline trivia trivia baseline both live);;3) arms=(trivia baseline both live live both baseline trivia);;esac
  for i in {0..7};do arm=${arms[$i]};if [[ $arm == baseline ]];then over=$input;else over=$root/pp-structural/$arm.c;fi
   lock env PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$over" "$out/probe" "${args[@]}" >"$out/$r-$i-$arm.tsv" 2>"$out/$r-$i-$arm.lease"
  done
 done
 (cd "$out" && sha256sum *.i probe >hashes)
elif [[ $kind == names ]];then
 for r in 1 2 3;do
  case $r in 1) arms=(eager spans batches batches spans eager);;2) arms=(batches eager spans spans eager batches);;3) arms=(spans batches eager eager batches spans);;esac
  for i in {0..5};do arm=${arms[i]}
   case $arm in eager) bin=$root/results/active-source-profile/pinned;;*) bin=$root/results/active-direct-$arm/pilot;;esac
   lock "$bin" "${args[@]}" >"$out/$r-$i-$arm.tsv" 2>"$out/$r-$i-$arm.lease"
  done
 done
fi
