from pathlib import Path
import os,subprocess,sys
d=Path(__file__).resolve().parent
exe=d/(sys.argv[1] if len(sys.argv)>1 else 'single-gap')
tmp=d/(exe.name+'-policies');tmp.mkdir(exist_ok=True)
fill=(b'/*pad'+b'x'*65536+b'*/\n')*17
inputs={
 'inactive-trigraph': b'??=define X 2\n',
 'inactive-splice': b'left\\   \nright\n',
 'inactive-comment': b'/* embedded /* comment */\n',
 'inactive-unmatched-comment': b'/* unterminated\n',
 'inactive-unmatched-quote': b'"unterminated\n',
 'inactive-nul': b'int a;\x00\n',
 'inactive-utf8': b'int \xffrow;\n',
 'inactive-ucn': br'int \u123identifier;' + b'\n',
 'inactive-deprecated': b'int a = 0b01;\n',
 'inactive-directive-digraph': b'%:define ZZ 2\n',
 'inactive-multiline': b'// hello\\\n next\n',
 'inactive-hash-candidate': b'/* leading\n#not_a_directive\n*/\n',
 'inactive-dollar': b'int x$y;\n',
 'inactive-syntax-numeric': b'auto x=0x12z9;\n',
}
bad=0
for name,raw in inputs.items():
 p=tmp/(name+'.c');p.write_bytes(fill+b'#if 0\n'+raw+b'#endif\nint okay;\n')
 for flags in ([],['-Weverything'],['-std=c11','-trigraphs','-Weverything']):
  out=[]
  for eager in (True,False):
   f=tmp/(name+str(eager)+'.i');env=dict(os.environ,PP_PRINT=str(f))
   if eager:env['PP_EAGER']='1'
   r=subprocess.run([exe,*flags,p],capture_output=True,env=env)
   out.append((r.returncode,r.stderr,f.read_bytes() if r.returncode==0 else b''))
  eq=out[0]==out[1]
  print(name,','.join(flags) or 'default',eq,repr(out[0][1][:160]),repr(out[1][1][:160]))
  bad+=not eq
raise SystemExit(bool(bad))
