#include <fcntl.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
extern int __real_open(const char*,int,...);
int __wrap_open(const char* name,int flags,...)
{
 const char* actual=getenv("PP_OVERLAY_ORIGINAL"),*replacement=getenv("PP_OVERLAY_BYTES");
 if(actual && replacement && strcmp(actual,name)==0) name=replacement;
 if(flags&O_CREAT){va_list ap;va_start(ap,flags);int mode=va_arg(ap,int);va_end(ap);return __real_open(name,flags,mode);}
 return __real_open(name,flags);
}
