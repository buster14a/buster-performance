from pathlib import Path
import subprocess,os
d=Path(__file__).resolve().parent;exe=d/'projected';cases=d/'forecast-cases';cases.mkdir(exist_ok=True)
cc='/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang'
fill=(b'/* '+b'x'*65520+b' */\n')*17
inputs={
 'error-active':(b'#if 1\n#line 300 "where.c"\n#error active_problem\n#endif\n',b'active_problem'),
 'nested-duplicate':(b'#if 0\n#if 0\n#else\n#else\n#endif\n#endif\n',b'#else'),
 'missing-close':(b'#if 0\nint broken;\n',b'unterminated'),
 'undefined-paste':(b'#define F(a,b) a ## b\nint x=F(+,*);\n',b'past'),
 'missing-argument':(b'#define T(x,y) 1\nint k=T(3);\n',b'arguments'),
 'missing-header':(b'#if 1\n#include "missing-structural-header.h"\n#endif\n',b'missing-structural-header.h'),
}
for name,(body,word) in inputs.items():
 p=cases/(name+'.c');p.write_bytes(fill+body)
 clang=subprocess.run([cc,'-E','-P',str(p)],capture_output=True)
 if not clang.returncode or word.lower() not in clang.stderr.lower():raise SystemExit((name,'clang',clang.returncode,clang.stderr))
 for flags in ([],['-Weverything']):
  results=[]
  for arm in ('eager','candidate'):
   env=dict(os.environ)
   if arm=='eager':env['PP_EAGER']='1'
   r=subprocess.run([str(exe),*flags,str(p)],env=env,capture_output=True);results.append(r)
  if results[0].returncode!=results[1].returncode or not results[0].returncode or results[0].stderr!=results[1].stderr or word.lower() not in results[1].stderr.lower():
   raise SystemExit((name,flags,[(r.returncode,r.stderr) for r in results]))
  print(name,' '.join(flags) or 'default','eager and candidate diagnostics identical; clang rejects')
