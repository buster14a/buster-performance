from pathlib import Path
import os,subprocess,sys
d=Path(__file__).resolve().parent;exe=d/sys.argv[1];tmp=d/('identities-'+exe.name);tmp.mkdir(exist_ok=True)
pad=b'/*pad'+b'x'*1048600+b'*/\n'
decl=b''.join(b'extern int raw_name_%d;\n'%i for i in range(1100))
p=tmp/'main.c';(tmp/'b.h').write_bytes(b'#define switch_here aliased_here\n#define NEW_NAME(x) ((x)+3)\n')
cases={
 'new-header-macro':(b'int switch_here;\n'+decl+b'#include "b.h"\nint switch_here; int after(int raw_name_1){return NEW_NAME(raw_name_1);}\n',True),
 'paste-and-stringize':(b'#define CAT(x,y) x##y\n#define STR(x) #x\n'+decl+b'char const* stringified=STR(raw_name_23);\nint glued=CAT(raw_name_,33);\n',True),
 'invoke-through-alias-and-pragmas':(b'#define CALL(x) x\n#define INDIRECT CALL\n#define P(x) _Pragma(#x)\n'+decl+b'int spelling=INDIRECT(raw_name_41);\n#define E 1\nP(push_macro("E"))\n#undef E\n#define E 2\nP(pop_macro("E"))\n#if E==1\nint survived;\n#endif\n',True),
 'nested-same-file':(b'#ifndef ALREADY\n#define ALREADY\n'+decl+b'\n#define raw_name_17 another\n#include "main.c"\n#else\n'+decl+b'\n#endif\n',True),
 'cross-directive-arguments':(b'#define TWO(a,b) ((a)+(b))\n'+decl+b'int sum=TWO(raw_name_405,\n#if 1\nraw_name_408\n#else\n0\n#endif\n);\n',True),
 'escaped-spellings':(decl+b'#define ESC abc\nextern int abc; extern int a\\\nbc; extern int caf\\u00e9;\nint use(){return E\\\nSC;}\n',True),
 'poison-new-ordinary-name':(decl+b'#define P(x) _Pragma(#x)\nP(GCC poison raw_name_302)\nint bad=raw_name_302;\n',False),
 'bad-paste':(decl+b'#define CAT(x,y) x##y\nint bad=CAT(+,*);\n',False),
 'disabled-name-warning':(decl+b'#if 0\n#error absent\n#endif\n#line 52 "new.h"\n#warning changed_loc\n',True),
}
for name,(body,success) in cases.items():
 p.write_bytes(pad+body)
 for mode in ['normal','history','max']:
  obs=[]
  for arm in ['eager','views']:
   stem=tmp/(name+'-'+mode+'-'+arm);env=dict(os.environ,PP_PRINT=str(stem)+'.i',PP_ROWS=str(stem)+'.rows',PP_DEMAND_REVERSE='1')
   if arm=='eager':env['PP_EAGER']='1'
   if mode=='history':env['PP_RECORD_HISTORY']='1'
   flags=['-Weverything'] if mode=='max' else []
   r=subprocess.run([exe,*flags,'-I',str(tmp),p],env=env,capture_output=True)
   obs.append((r.returncode,r.stderr,*[Path(str(stem)+ext).read_bytes() if r.returncode==0 else b'' for ext in ('.i','.rows')]))
  if obs[0]!=obs[1] or ((obs[0][0]==0)!=success):raise SystemExit((name,mode,[(x[0],x[1][:900]) for x in obs]))
  print(name,mode,obs[0][0],'exact')
