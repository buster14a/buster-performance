#include <stdio.h>
#include <stdlib.h>
#include "buster/compiler/c_lexer.c"
#include "buster/compiler/c_pp_structure.c"
int main(int argc,char**argv)
{
 unsigned used=0,fall=0,mismatch=0;unsigned long long bytes=0,dirs=0;
 for(int f=1;f<argc;f++)
 {
  FILE* input=fopen(argv[f],"rb");if(!input)return 3;fseek(input,0,SEEK_END);size_t size=ftell(input);rewind(input);
  uint8_t* source=calloc(size+65,1);if(fread(source,1,size,input)!=size)return 3;fclose(input);
  PPSourceStructure index={.directives=malloc((size+1)*sizeof(PPSourceDirective)),.capacity=size+1};
  uint8_t* kinds=malloc(BUSTER_C_TOKENIZER_CAPACITY(size));uint32_t*starts=malloc(BUSTER_C_TOKENIZER_CAPACITY(size)*4),*ends=malloc(BUSTER_C_TOKENIZER_CAPACITY(size)*4);
  bool cert=pp_structure_scan(source,size,&index);
  if(cert)
  {
   int64_t count=c_tokenize(source,size,kinds,starts,ends,C_TOKENIZER_NO_DIGIT_SEPARATORS);
   unsigned found=0;
   for(int64_t i=0;i<count;i++)if(kinds[i]==(C_TOKEN_HASH|BUSTER_C_TOKEN_START_OF_LINE))
   {
    if(found>=index.count || starts[i]!=index.directives[found].hash){fprintf(stderr,"%s hash %u source %u canonical %u\n",argv[f],found,found<index.count?index.directives[found].hash:0xffffffff,starts[i]);mismatch++;break;}
    unsigned j=i+1;while(j<count && !(kinds[j]&BUSTER_C_TOKEN_START_OF_LINE))j++;
    if((j>i+1 && ends[j-1]>index.directives[found].end)||(j<count && starts[j]<index.directives[found].end)){fprintf(stderr,"%s directive end %u %u %u\n",argv[f],found,index.directives[found].end,j<count?starts[j]:0);mismatch++;break;}
    found++;
   }
   if(found!=index.count){mismatch++;fprintf(stderr,"%s directive count %u %u\n",argv[f],found,index.count);}
   used++;dirs+=index.count;bytes+=size;
  }
  else fall++;
  free(index.directives);free(starts);free(ends);free(kinds);free(source);
 }
 printf("certified %u files, %llu bytes, %llu directives, %u passed to the canonical lexer, %u differences\n",used,bytes,dirs,fall,mismatch);
 return !!mismatch;
}
