from pathlib import Path
import subprocess,os,sys
root=Path(__file__).resolve().parent;exe=str(root/'single-gap');d=root/'gap-cases';d.mkdir(exist_ok=True)
fill=b'/*pad'+b'x'*65518+b'*/\n'
base=fill*17
cases={
 'active-names':b'#if 0\nint hidden;\n#endif\n#define Y(x) ((x)+2)\nint actual=Y(20);\n',
 'eflag':b'#define H 0\n#if H\n#define M 0\n#else\n#define M 7\n#endif\nint a=M;\n',
 'counter-change':b'int count=__COUNTER__;\n#if __COUNTER__==1\nint real=9;\n#else\nint wrong=5;\n#endif\n',
 'macro-side-effect':b'#define P(x) _Pragma(#x)\n#define X 1\nP(push_macro("X"))\n#undef X\n#define X 0\nP(pop_macro("X"))\n#if X\nint x=1;\n#else\nint x=2;\n#endif\n',
 'multiline-comment':b'#define A /* comment\n continues */ 3\nint v=A;\n',
 'splice-macro':b'#define A 1 \\\n/* comment\n continues */ + 3\nint v=A;\n',
 'mixed-ifdef':b'#if 0\n#define A 1\n#if 1\nint v;\n#endif\n#elif 1\nint a;\n#endif\n',
 'direct-header-name':b'#include <a/*b.h>\nint v=H;\n',
 'consecutive-false':b'#if 0\nint a;\n#elif 0\nint b;\n#else\nint c;\n#endif\n',
 'macro-args':b'#define G(x,y) x+y\nint v=G(1,\n#if 0\n 9\n#else\n 4\n#endif\n);\n',
 'warning-map':b'#if 0\nint dead;\n#else\n#line 72 "shape.h"\n#warning published location\nint v;\n#endif\n',
 'mapped-line':b'#line 99 "virtual.c"\n#define F(x) ((x)+__LINE__)\nint v=F(2);\n',
}
(d/'a').mkdir(exist_ok=True);(d/'a/*b.h').write_text('#define H 7\n')
for name,code in cases.items():
 p=d/(name+'.c');p.write_bytes(base+code)
 for mode in ('deferred','history'):
  paths=[];values=[]
  for arm in ('eager','candidate'):
   f=d/f'{name}-{mode}-{arm}';env=dict(os.environ,PP_ROWS=str(f)+'.rows',PP_PRINT=str(f)+'.i')
   if arm=='eager':env['PP_EAGER']='1'
   if mode=='history':env['PP_RECORD_HISTORY']='1'
   r=subprocess.run([exe,'-I',str(d),str(p)],env=env,capture_output=True)
   if r.returncode:raise SystemExit((name,mode,arm,r.returncode,r.stderr))
   Path(str(f)+'.err').write_bytes(r.stderr);values.append(r.stdout.decode().strip());paths.append(f)
  for ext in ['.rows','.i','.err']:
   a,b=[Path(str(f)+ext).read_bytes() for f in paths]
   if a!=b:raise SystemExit((name,mode,ext,a[:300],b[:300],values))
  print(name,mode,*values[1].split()[2:7])
