from pathlib import Path
import re,json,statistics,collections
d=Path(__file__).resolve().parent
result={};profile={}
for p in sorted(d.glob('structural-single-*')):
 rows=collections.defaultdict(list)
 for f in p.glob('*-*-*.tsv'):
  a=f.read_text().strip().split()
  if a:rows[f.stem.split('-')[-1]].append(int(a[0]))
 if p.name.endswith('-index'):
  for f in p.glob('[0-9].err'):
   m=re.search(r'^1 12548 \d+ \d+ 0 (\d+)$',f.read_text(),re.M)
   assert m;rows['index'].append(int(m[1]))
 if rows:result[p.name]={arm:{'fresh_processes':len(v),'median_ms':statistics.median(v)/1e6,'min_ms':min(v)/1e6,'max_ms':max(v)/1e6} for arm,v in rows.items()}
 if p.name.endswith('-perf'):
  for f in sorted(p.glob('*.flat')):
   a=profile.setdefault(f.stem.split('-')[-1],collections.Counter())
   for row in f.read_text().splitlines():
    m=re.match(r'\s*\d+\.\d+%\s+(\d+)\s+\S+\s+\[[k.]\]\s+(\S+)',row)
    if m:a[m[2]]+=int(m[1])
print(json.dumps(result,indent=2))
for arm,counts in profile.items():
 print(arm,sum(counts.values()),[(k,n,round(n*100/sum(counts.values()),2)) for k,n in counts.most_common(12)])
