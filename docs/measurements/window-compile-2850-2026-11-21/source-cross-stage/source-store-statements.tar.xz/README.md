# Scalar source assignments in full ordinary functions

Signed production head `18fa4891a` in `../source-store-statements` accepts
complete source-level calls and assignments inside compound statements. It
uses parser roles, canonical automatic and parameter objects, the exact scalar
and record type, prototypes, field displacements and method-specific qualifier
and attribute checks. Each accepted statement substitutes one control entry,
and its fresh compiler skips creation of all its general checker graph nodes.
The ordinary backend consumes scalar operations and handles local assignment,
call ABI, frame, fixups and object output. `f88313f10` adds a test inventory
for these compiler fields.

SQLite had 2,824 calls and 3,575 assignments across 1,393 functions. The
40,342 selected tokens are 7.06% of its 571,315 physical body tokens. Its
graph fell from 323,623 to 291,867 nodes, 144,755 to 129,167 leaves and 34,220
to 28,793 arguments. The producer took 3.459 ms in the untraced census run.
Buster had 449 calls and 985 assignments across 636 functions and dropped
6,859 of its 1,407,416 graph nodes.

All 1,372 real object compiles, including SQLite, independent frozen Buster, 34
Lua and 1,336 musl sources, returned byte-identical complete objects, stdout,
stderr and status. The three Clang SQLite shell controls, 340 paired edge and
policy cases and two Clang-linked control/record fixtures passed. The
`*.census.stderr` files report graph sizes and source production without a
per-statement trace. `coverage.txt` joins selected token intervals against
independently captured function boundaries.

Eight interleaved local samples on the Ryzen 9 7940HS gave SQLite full wall
medians 282.312 and 280.403 ms, paired delta −4.044 ms, five of eight
improved. Expression checking fell from 30.661 to 26.619 ms in all eight
stage-timed pairs. Buster full wall medians were 1,643.164 and 1,603.027 ms,
paired delta −18.253 ms, five improvements in eight. Differences in local
system load are relevant at this spread. These measurements do not establish
target-host throughput. Full paired raw data and source controls are retained
in `*-performance.tsv`, `real/*.tsv`, `policy.tsv`, `coverage.txt`,
`results.txt` and `pair-summary.tsv`.
