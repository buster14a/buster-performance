#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; cd ../source-store-statements
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../buster/build/predefines.h build/
cd "$d";cc=../source-store-statements/build/compiler
"$cc" --lanes 1 -c mixed.c -o mixed.base.o
BUSTER_DIRECT_SOURCE_STATEMENTS=1 BUSTER_DIRECT_RETURN_AUDIT=1 "$cc" --lanes 1 -c mixed.c -o mixed.new.o 2>mixed.new.stderr
python3 elf.py mixed.base.o mixed.new.o >mixed.elf
clang -c mixed.c -o mixed.clang.o
for v in base new clang;do clang mixed-driver.c mixed."$v".o -o mixed."$v".bin;./mixed."$v".bin >mixed."$v".stdout;done
cmp mixed.clang.stdout mixed.new.stdout
bash "$d/record-qa.sh"
bash "$d/qa.sh" >"$d/qa.log" 2>&1
python3 "$d/boundary.py" >"$d/policy.log" 2>&1
bash "$d/perf.sh" >"$d/perf.log" 2>&1
python3 "$d/../source-statement-calls-study/coverage.py" "$d" >"$d/coverage.txt"
python3 "$d/../source-call-native-study/report-pairs.py" "$d"
python3 "$d/../source-statement-calls-study/results.py" "$d" >"$d/results.txt"
