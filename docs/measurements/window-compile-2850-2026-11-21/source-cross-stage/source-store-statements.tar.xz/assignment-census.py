from pathlib import Path
import re,collections,subprocess,csv
d=Path(__file__).resolve().parent
src=(d.parent/'fresh-file-study/sqlite.i').read_text()
tok=re.findall(r'''"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|[a-zA-Z_$][\w$]*|[0-9]+|->|==|!=|>=|<=|&&|\|\||\+\+|--|[^\s]''',src)
syms={x.split()[-1] for x in subprocess.check_output(['nm','-S','--defined-only',d.parent/'source-statement-calls-study/sqlite.base.o'],text=True).splitlines() if len(x.split())==4 and x.split()[2] in ('t','T')}
def operand(t):
 return (len(t)==1 and (t[0].isidentifier() or t[0].isdecimal())) or (len(t)==3 and t[0].isidentifier() and t[1]=='->' and t[2].isidentifier())
def shape(t):
 if operand(t):return 'truth'
 if t and t[0]=='!' and operand(t[1:]):return '!truth'
 for j,v in enumerate(t):
  if v in ('==','!=','<','>','<=','>=','&') and operand(t[:j]) and operand(t[j+1:]):return v
 return 'other'
rules=collections.Counter();tall=collections.Counter();funs=collections.defaultdict(set);depth=0;name=None
for i,t in enumerate(tok):
 if t=='{':
  if not depth and i>1 and tok[i-1]==')':
   j=i-2; b=1
   while j>=0 and b:b+=(tok[j]==')')-(tok[j]=='(');j-=1
   name=tok[j] if j>=0 and tok[j] in syms else None
  depth+=1
 elif t=='}':
  depth-=1
  if not depth:name=None
 elif name and t=='=':
  a=i-1
  if a>=2 and tok[a-1]=='->':a-=2
  if a<1 or tok[a-1] not in (';','{','}') or not operand(tok[a:i]):continue
  k=i+1
  while k<len(tok) and k-i<=30 and tok[k] not in (';','{','}'):k+=1
  if k>=len(tok) or tok[k]!=';':continue
  rhs=tok[i+1:k]
  if operand(rhs):what='copy'
  elif any(v in ('+','-','*','&','|','^') and operand(rhs[:j]) and operand(rhs[j+1:]) for j,v in enumerate(rhs)):what='binary'
  else:what='complex'
  rules[what]+=1;tall[what]+=k-a+1;funs[what].add(name)
print('shape\tmatched\tphysical_tokens_estimate\tfunctions')
for k,n in rules.most_common():print(k,n,tall[k],len(funs[k]),sep='\t')
