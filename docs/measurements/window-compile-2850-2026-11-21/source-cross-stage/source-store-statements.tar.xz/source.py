from pathlib import Path
d=Path(__file__).resolve().parent.parent/'source-store-statements/src/buster/compiler'
p=d/'c_check_input.c';s=p.read_text().replace('    uint32_t callee;\n    uint32_t count;\n    CheckSourceCallArgument arguments[4];','    uint32_t callee;\n    uint32_t count;\n    uint8_t operation; // Parser kind of a simple assignment RHS binary operator, zero for a copy.\n    CheckSourceCallArgument arguments[4];');p.write_text(s)
p=d/'c_check_native_return.c';s=p.read_text();start=s.index('static bool check_source_call_statement(')
a=s.index('        if (p->tokens.kinds[t] == PARSE_KIND_NUMBER)',start);b=s.index('\n    }\n    return t == close;',a)
body=s[a:b]
body=body.replace('if (p->tokens.kinds[t] == PARSE_KIND_NUMBER)','if (p->tokens.kinds[t] == PARSE_KIND_NUMBER || p->tokens.kinds[t] == PARSE_KIND_MINUS)').replace('if (!check_return_value(reader, 0, &t, close, &value) || !value.literal ||','if (write || !check_return_value(reader, 0, &t, close, &value) || !value.literal ||').replace('.type = expected, .constant = value.constant','.type = expected ? expected : BUSTER_TYPE_INT, .constant = value.constant')
body=body.replace('if (type_kind(types, type) != BUSTER_TYPE_KIND_POINTER || in->marked_member_count != 0)','if (type_kind(types, type) != BUSTER_TYPE_KIND_POINTER || in->marked_member_count != 0 || in->noderef_member_count || in->noderef_declaration_count)').replace('if ((type_qualifiers(record) & ~(uint32_t)BUSTER_TYPE_CONST) != 0 ||','if ((write && type_qualifiers(record)) || (type_qualifiers(record) & ~(uint32_t)BUSTER_TYPE_CONST) != 0 ||').replace('(quals & ~(uint32_t)BUSTER_TYPE_CONST) != 0 ||','(write && quals) || (quals & ~(uint32_t)BUSTER_TYPE_CONST) != 0 ||').replace('if (!check_source_argument_compatible(types, type, expected))','if ((write && type_qualifiers(type)) || (expected && !check_source_argument_compatible(types, type, expected)))').replace('.type = expected, .source_type = base','.type = expected ? expected : type_unqualified(type), .source_type = base')
helper='''static bool check_source_statement_operand(CheckInputReader* reader,uint32_t* cursor,uint32_t close,TypeId expected,bool write,CheckSourceCallArgument* argument)
{
    const Parser* p=reader->parser;
    const CheckInput* in=reader->output;
    const TypeTable* types=reader->types;
    uint32_t t=*cursor;
    if(t>=close) return false;
'''+body+'''
    *cursor=t;
    return true;
}

'''
s=s[:a]+'''        if (!check_source_statement_operand(reader,&t,close,expected,false,argument)) return false;'''+s[b:]
s=s[:start]+helper+s[start:]
idx=s.index('static void check_source_call_statements(')
s=s[:idx]+'''static bool check_source_store_statement(CheckInputReader* reader,uint32_t equal,uint32_t end,uint32_t* begin,CheckSourceCallStatement* store)
{
    const Parser* p=reader->parser;
    if(p->tokens.kinds[equal]!=PARSE_KIND_EQUAL || equal<2 || end<=equal+1 || end-equal>9) return false;
    uint32_t first=equal-1;
    if(first>=2 && p->tokens.kinds[first-1]==PARSE_KIND_ARROW) first-=2;
    if(!first || (p->tokens.kinds[first-1]!=PARSE_KIND_SEMI && p->tokens.kinds[first-1]!=PARSE_KIND_L_BRACE && p->tokens.kinds[first-1]!=PARSE_KIND_R_BRACE)) return false;
    uint32_t at=first;
    CheckSourceCallArgument* args=store->arguments;
    if(!check_source_statement_operand(reader,&at,equal,0,true,args) || at!=equal) return false;
    const TypeId type=args[0].type;
    at+=1;
    if(!check_source_statement_operand(reader,&at,end,type,false,args+1)) return false;
    store->count=2;
    if(at<end)
    {
        if(!args[1].object || type_kind(reader->types,type)!=BUSTER_TYPE_KIND_INTEGER) return false;
        const uint8_t op=p->tokens.kinds[at++];
        if(op!=PARSE_KIND_PLUS && op!=PARSE_KIND_MINUS && op!=PARSE_KIND_STAR && op!=PARSE_KIND_AMP && op!=PARSE_KIND_PIPE && op!=PARSE_KIND_CARET) return false;
        if(!check_source_statement_operand(reader,&at,end,type,false,args+2)) return false;
        store->operation=op;
        store->count=3;
    }
    if(at!=end) return false;
    *begin=first;
    return true;
}

'''+s[idx:]
a=s.index('        uint64_t calls = _mm512_mask_cmpeq_epi8_mask');b=s.index('            if (in->region_count)',a)
s=s[:a]+'''        const uint64_t openings=_mm512_mask_cmpeq_epi8_mask(lanes,roles,_mm512_set1_epi8(PARSE_ROLE_OPEN_CALL));
        const uint64_t assigns=_mm512_mask_cmpeq_epi8_mask(lanes,roles,_mm512_set1_epi8(PARSE_ROLE_ASSIGN));
        const uint8_t* kinds=p->tokens.kinds;
        uint64_t sites=openings | assigns;
        while(sites)
        {
            const uint32_t bit=(uint32_t)__builtin_ctzll(sites); sites&=sites-1;
            const uint32_t first=base+bit;
            const bool call_site=((openings>>bit)&1)!=0;
            const uint32_t parent=p->tree.parents[first];
            if(first<2 || parent<=first || parent>=count-1) continue;
            const uint32_t end=call_site?parent+1:parent;
            if(end-first>18 || p->tree.roles[end]!=PARSE_ROLE_TERMINATOR || kinds[end]!=PARSE_KIND_SEMI ||
               p->tree.parents[end]>=count || (p->tree.roles[p->tree.parents[end]]!=PARSE_ROLE_CLOSE_BODY && p->tree.roles[p->tree.parents[end]]!=PARSE_ROLE_CLOSE_BLOCK)) continue;
            if(call_site && (p->tree.roles[parent]!=PARSE_ROLE_CLOSE_CALL || p->tree.parents[parent]!=end)) continue;
'''+s[b:]
s=s.replace('uint32_t owner = p->tree.parents[end + 1], limit = 0;', 'uint32_t owner = p->tree.parents[end], limit = 0;')
s=s.replace('''            if (!check_source_call_statement(reader, first, end, &call))
                continue;''','''            uint32_t begin=first-1;
            if(call_site ? !check_source_call_statement(reader,first,parent,&call) : !check_source_store_statement(reader,first,end,&begin,&call)) continue;''')
s=s.replace('check_sparse_set(pool, in->source_call_tokens, end + 1, in->source_call_count);','check_sparse_set(pool, in->source_call_tokens, end, in->source_call_count);').replace('memset(reader->visits + first - 1, 0, (size_t)(end - first + 3));','memset(reader->visits + begin, 0, (size_t)(end-begin)+1);').replace('first - 1, end + 1, call.callee, call.count','begin,end,call.callee,call.count')
p.write_text(s)
p=d/'c_check_program.c';s=p.read_text().replace('if(seen[object]!=epoch) {seen[object]=epoch;needed[object]=1;references[reference_count++]=(uint64_t)object<<32;}','if(object!=0 && seen[object]!=epoch) {seen[object]=epoch;needed[object]=1;references[reference_count++]=(uint64_t)object<<32;}');p.write_text(s)
p=d/'c_check_program_lower.c';s=p.read_text();a=s.index('        for(uint32_t a=0;a<count;a+=1)\n        {\n            const CheckSourceCallArgument* arg=plan->arguments+a;');b=s.index('        const uint8_t returned=',a)
helper=s[a:b].split('            const uint8_t class=',1)[1].rsplit('        }',1)[0]
helper='''static void check_lower_source_operand(CheckLowerWriter* writer,const CheckSourceCallArgument* arg,bool address)
{
            const uint8_t class='''+helper+'''}

'''
helper=helper.replace('''                    const uint8_t loaded=check_lower_class(writer,field);
                    check_lower_emit(writer,BUSTER_TYPED_LOAD,loaded,check_lower_access(writer,loaded,field));''','''                    if(!address)
                    {
                        const uint8_t loaded=check_lower_class(writer,field);
                        check_lower_emit(writer,BUSTER_TYPED_LOAD,loaded,check_lower_access(writer,loaded,field));
                    }''')
s=s[:a]+'''        for(uint32_t a=0;a<count;a+=1) check_lower_source_operand(writer,plan->arguments+a,false);
'''+s[b:]
i=s.index('static void check_lower_control(CheckLowerWriter* writer, uint32_t index)\n{')
s=s[:i]+helper+'''static void check_lower_source_store(CheckLowerWriter* writer,const CheckSourceCallStatement* value)
{
    const CheckSourceCallArgument* dest=value->arguments;
    const uint32_t local=check_lower_local_of(writer,dest->object);
    if(local>=writer->local_count) {check_lower_fail(writer,CHECK_PROGRAM_INVALID);return;}
    const uint8_t class=check_lower_class(writer,dest->type);
    if(dest->field) check_lower_source_operand(writer,dest,true);
    check_lower_source_operand(writer,dest+1,false);
    if(value->operation)
    {
        check_lower_source_operand(writer,dest+2,false);
        const uint8_t op=value->operation;
        const uint32_t typed=op==PARSE_KIND_PLUS?BUSTER_TYPED_ADD:op==PARSE_KIND_MINUS?BUSTER_TYPED_SUB:op==PARSE_KIND_STAR?BUSTER_TYPED_MUL:
                             op==PARSE_KIND_AMP?BUSTER_TYPED_AND:op==PARSE_KIND_PIPE?BUSTER_TYPED_OR:BUSTER_TYPED_XOR;
        check_lower_emit(writer,typed,class,0);
    }
    if(dest->field) check_lower_emit(writer,BUSTER_TYPED_STORE,class,check_lower_access_value(writer->program->types,class,dest->type));
    else check_lower_emit(writer,BUSTER_TYPED_STORE_LOCAL,class,local);
    check_lower_emit(writer,BUSTER_TYPED_DISCARD,class,0);
}

'''+s[i:]
s=s.replace('''        uint32_t count=0;
        const TypeId* params=type_parameters(program->types,plan->function,&count);''','''        if(!plan->callee)
        {
            writer->statement=BUSTER_CHECK_NONE;
            check_lower_source_store(writer,plan);
            if(getenv("BUSTER_DIRECT_RETURN_AUDIT")!=NULL) fprintf(stderr,"direct-statement-lower\\t%u\\tstore\\n",control.token);
            return;
        }
        uint32_t count=0;
        const TypeId* params=type_parameters(program->types,plan->function,&count);''',1)
p.write_text(s)
