from pathlib import Path
import re,collections,subprocess,csv
d=Path(__file__).resolve().parent
src=(d.parent/'fresh-file-study/sqlite.i').read_text()
tok=re.findall(r'''"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|[a-zA-Z_$][\w$]*|[0-9]+|->|==|!=|>=|<=|&&|\|\||\+\+|--|[^\s]''',src)
syms={x.split()[-1] for x in subprocess.check_output(['nm','-S','--defined-only',d.parent/'source-statement-calls-study/sqlite.base.o'],text=True).splitlines() if len(x.split())==4 and x.split()[2] in ('t','T')}
def operand(t):
 return (len(t)==1 and (t[0].isidentifier() or t[0].isdecimal())) or (len(t)==3 and t[0].isidentifier() and t[1]=='->' and t[2].isidentifier())
def shape(t):
 if operand(t):return 'truth'
 if t and t[0]=='!' and operand(t[1:]):return '!truth'
 for j,v in enumerate(t):
  if v in ('==','!=','<','>','<=','>=','&') and operand(t[:j]) and operand(t[j+1:]):return v
 return 'other'
reg=collections.defaultdict(collections.Counter);n=collections.Counter();covered=collections.Counter();depth=0;name=None
for i,t in enumerate(tok):
 if t=='{':
  if not depth and i>1 and tok[i-1]==')':
   j=i-2; b=1
   while j>=0 and b:b+=(tok[j]==')')-(tok[j]=='(');j-=1
   name=tok[j] if j>=0 and tok[j] in syms else None
  depth+=1
 elif t=='}':
  depth-=1
  if not depth:name=None
 elif name and t in ('if','while') and tok[i+1]=='(':
  j=i+2; b=1
  while j<len(tok) and b>0:b+=(tok[j]=='(')-(tok[j]==')');j+=1
  typ=shape(tok[i+2:j-1]);n[typ]+=1;covered[typ]+=j-(i+2)-1;reg[name][typ]+=1
print('kind\theaders\toperand_tokens\tfunctions')
for k,c in n.most_common():print(k,c,covered[k],sum(v.get(k,0)>0 for v in reg.values()),sep='\t')
print('total',sum(n.values()),sum(covered.values()),len(reg),sep='\t')
print('subset',sum(n.values())-n['other'],sum(covered.values())-covered['other'],sum(any(k!='other' for k in v) for v in reg.values()),sep='\t')
