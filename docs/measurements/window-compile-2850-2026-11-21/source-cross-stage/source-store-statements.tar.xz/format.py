from pathlib import Path
import subprocess,re
root=Path(__file__).resolve().parent.parent/'source-store-statements'
files=['c_check_native_return.c','c_check_program.c','c_check_program_lower.c','c_check_input.c']
style='{BasedOnStyle: LLVM, IndentWidth: 4, ColumnLimit: 140, BreakBeforeBraces: Allman, AllowShortIfStatementsOnASingleLine: Never, AllowShortLoopsOnASingleLine: false, AllowShortFunctionsOnASingleLine: None, PointerAlignment: Left, SortIncludes: Never}'
for name in files:
 path='src/buster/compiler/'+name
 diff=subprocess.check_output(['git','diff','--unified=0','2ec56de06','--',path],cwd=root,text=True)
 heads=re.findall(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@',diff,re.M)
 lines=['--lines='+a+':'+str(int(a)+int(count or '1')-1) for a,count in heads if count!='0']
 subprocess.run(['clang-format','-i','-style='+style,*lines,path],cwd=root,check=True)
