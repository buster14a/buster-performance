#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;root=${d%/*}
cc=${DIRECT_COMPILER:-$root/source-store-statements/build/compiler}
cd "$root/switch-inputs"
source ../switch-local-args.sh
tree=$root/pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $root/proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main; do
 name=${g}_arguments; eval "args=(${!name})"
 BUSTER_DIRECT_GRAPH_CENSUS=1 "$cc" --lanes 1 -c "${args[@]}" -o "$d/$g.base.o" >"$d/$g.base.stdout" 2>"$d/$g.base.stderr"
 BUSTER_DIRECT_GRAPH_CENSUS=1 BUSTER_DIRECT_SOURCE_STATEMENTS=1 BUSTER_DIRECT_RETURN_AUDIT=1 BUSTER_CONTROL_EARLY_AUDIT=1 "$cc" --lanes 1 -c "${args[@]}" -o "$d/$g.new.o" >"$d/$g.new.stdout" 2>"$d/$g.new.stderr"
 BUSTER_DIRECT_GRAPH_CENSUS=1 BUSTER_DIRECT_SOURCE_STATEMENTS=1 "$cc" --lanes 1 -c "${args[@]}" -o "$d/$g.census.o" >"$d/$g.census.stdout" 2>"$d/$g.census.stderr"
 python3 "$d/elf.py" "$d/$g.base.o" "$d/$g.new.o" >"$d/$g.elf"
done
ref=$root/parser-sql-runtime/runtime
clang=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$clang" -no-pie "$ref/shell.o" "$d/sqlite.new.o" -ldl -lpthread -lm -o "$d/sqlite.bin"
for t in core files dotcommands; do
 cwd=$(mktemp -d "$d/sql.XXXXX")
 (cd "$cwd" && timeout 30 "$d/sqlite.bin" -batch :memory: <"$root/pending-expression-windows/tests/sqlite/$t.sql") >"$d/$t.stdout" 2>"$d/$t.stderr" && code=0 || code=$?
 echo "$code" >"$d/$t.status"
 for f in stdout stderr status; do cmp "$ref/clang.$t.$f" "$d/$t.$f"; done
done
