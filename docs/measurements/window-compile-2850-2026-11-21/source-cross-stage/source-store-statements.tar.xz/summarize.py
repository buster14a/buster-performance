from pathlib import Path
from statistics import median
from collections import Counter
import csv, hashlib, sys
d=Path(__file__).resolve().parent
for group in ('sqlite','main'):
 rows=list(csv.DictReader((d/f'{group}-performance.tsv').open(),delimiter='\t'))
 for m in ['ordinary','total','check-input','check-program','check-expressions','lower','lower.statements','tier0','encode']:
  values=[[int(r['ns'])/1e6 for r in rows if r['variant']==v and r['measurement']==m] for v in 'AB']
  print(group,m,*[f'{median(v):.3f}' if v else '-' for v in values],*[len(v) for v in values],sep='\t')
for group in ('sqlite','main','shapes','store','wrappers','extended'):
 p=d/f'{group}.new.stderr'
 if not p.exists():continue
 print(group,Counter(s.split('\t')[0] for s in p.read_text().splitlines()),(d/f'{group}.elf').read_text().strip().replace('\n','; '))
for k in ['matrix','edge','call-policy','policy']:
 p=d/f'{k}.tsv'
 if p.exists():
  r=list(csv.DictReader(p.open(),delimiter='\t')); fail=[(e.get('case',e.get('name','')),e.get('policy',e.get('flags','')),col) for e in r for col,v in e.items() if v=='False'];print(k,len(r),fail)
