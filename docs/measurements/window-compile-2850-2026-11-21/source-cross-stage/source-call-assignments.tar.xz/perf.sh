#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs
source ../switch-local-args.sh
root=${d%/*}
tree=$root/pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $root/proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main;do name=${g}_arguments;eval "args=(${!name})";python3 "$d/perf.py" "$g" "${args[@]}";done

bash "$d/corpus.sh" sqlite main lua musl >"$d/corpus.log" 2>&1
