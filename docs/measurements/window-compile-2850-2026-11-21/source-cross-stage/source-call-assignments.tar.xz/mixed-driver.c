#include <stdio.h>
static unsigned value;
void add(int x){ value=(value^x)*33u; }
int add2(int x,int y){ add(x);add(y);return (int)value; }
void series(int,int);
int main(void){for(int i=0;i<400;i++){series(i,i);series(i,i+4);} printf("%08x\n",value);}
