# Calling a function directly into a scalar destination

Signed source `501757cce` includes complete source calls and assignments,
call result storage in a local or record member, attention to final type/ABI,
the physical source-prefix mask, full state attestation and both synthetic
lowerer guards. A supported local or member assignment from a call validates
its up to three scalar arguments, final function declaration and destination
without building expression graph nodes or general lowering tasks. Call frame
layout, local storage, relocations and final native encoding remain ordinary.

This adds 1,020 call-result assignments over 440 real SQLite functions,
including 309 independently observed member actions. All calls and stores
together occupy 49,505 physical tokens in 1,467 functions and reduce 323,623
ordinary graph nodes to 284,738. Buster gains 45 call-result assignments in 28
functions. The SIMD source-prefix filter reduced scalar candidates from
36,443 to 17,926 on SQLite and from 94,416 to 15,277 on Buster, with identical
selected source rows and graph sizes. The one-shot SQLite scanner clocks were
4.085 ms and 4.057 ms respectively.

All 1,372 real native objects and outputs, 450 paired policy fixtures, three
SQLite shell traces and three linked runtime fixtures matched. The independent
C call-result driver produced the same digest as Clang. Checker shard 6 finished
87,520 checks with zero failures on this head. See `checker6.log`.

Eight fresh four-arm SQLite medians were 294.025 ms for ordinary, 290.061 ms
with call-result assignment, and 288.465 ms with source prefixes filtered.
The latter won seven of its eight paired comparisons against ordinary.
Twelve local PMU pairs measured 44.25 million fewer retired user instructions
for the filtered variant, 12/12 improvements, and 8.94 million fewer user
cycles with 8/12 improvements. It removed 7.82 million retired branches.
Hardware is the local Ryzen 9 7940HS. `*-three.tsv` contains all four arms,
along with `sqlite-pmu.tsv`, `results.txt`, `coverage.txt`, `members.txt` and
the Clang/link and full-corpus outputs.
