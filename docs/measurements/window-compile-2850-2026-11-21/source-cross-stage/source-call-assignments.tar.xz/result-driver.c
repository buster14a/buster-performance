#include <stdio.h>
struct Pair { int x; unsigned code; void* data; };
extern int update(struct Pair *, int);
static int keys[3];
static unsigned long long hash=7;
int next(int x,unsigned u){ hash=hash*33+(unsigned)x;return x+(int)(u%5)+1;}
unsigned mask(void *p){ hash=hash*33+42;return p==keys+1?27:9;}
void *pick(int x){hash=hash*33+(unsigned)x;return keys+((unsigned)x%3);}
long wide(int x){return x;}
int main(void){struct Pair p={5,7,keys+1};for(int i=-9;i<15;i++){int v=update(&p,i);hash=hash*33u+(unsigned)v+p.code;}printf("%016llx\n",hash);}
