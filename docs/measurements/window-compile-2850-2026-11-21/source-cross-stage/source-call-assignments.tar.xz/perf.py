import os,sys,time,subprocess,csv,hashlib
from pathlib import Path
d=Path(__file__).resolve().parent;cc=d.parent/'source-call-assignments/build/compiler';group=sys.argv[1];args=sys.argv[2:];out=d/f'{group}.timed.o'
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
with (d/f'{group}-performance.tsv').open('w',buffering=1) as f:
 wr=csv.writer(f,delimiter='\t');wr.writerow(['pass','order','variant','measurement','ns','sha256'])
 for staged in [False,True]:
  for i in range(4):
   for j,v in enumerate(('ABBA','BAAB')[i%2]):
    env={**os.environ};env.update({'BUSTER_DIRECT_SOURCE_STATEMENTS':'1'} if v=='B' else {})
    start=time.monotonic_ns();r=subprocess.run([cc,'--lanes','1',*(['--time-stages'] if staged else []),'-c',*args,'-o',out],capture_output=True,env=env);elapsed=time.monotonic_ns()-start
    assert r.returncode==0,r.stderr[:600]
    h=hashlib.sha256(out.read_bytes()).hexdigest()
    expected=hashlib.sha256((d/f'{group}.{"base" if v=="A" else "new"}.o').read_bytes()).hexdigest()
    assert h==expected,(group,v,h,expected)
    if not staged:wr.writerow([i,j,v,'ordinary',elapsed,h])
    else:
     for line in r.stderr.decode().splitlines():
      cols=line.split('\t')
      if cols[0]=='time-stage' and cols[1]!='stage':wr.writerow([i,j,v,cols[1],round(float(cols[2])*1e6),h])
