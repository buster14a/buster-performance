struct Pair { int x; unsigned code; void* data; };
extern int next(int x, unsigned u);
extern unsigned mask(void *p);
extern void *pick(int);
extern long wide(int);
int update(struct Pair *p, int start){
 int x=start;
 x=next(x,p->code);
 p->x=next(x,4);
 p->code=mask(p->data);
 p->data=pick(p->x);
 if(x>3){x=next(p->x,p->code);}
 while(x<0){x=next(x,1);}
 return x;
}
