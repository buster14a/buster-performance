from pathlib import Path
d=Path(__file__).resolve().parent.parent/'source-call-assignments/src/buster/compiler'
def replace(s,old,new):
 assert s.count(old)==1,(old,s.count(old))
 return s.replace(old,new,1)
p=d/'c_check_native_return.c';s=p.read_text()
s=replace(s,'uint32_t first, uint32_t close, CheckSourceStatement* call)','uint32_t first, uint32_t close, bool assigned, CheckSourceStatement* call)')
s=replace(s,'''        (p->tokens.kinds[token - 1] != PARSE_KIND_SEMI && p->tokens.kinds[token - 1] != PARSE_KIND_L_BRACE &&
         p->tokens.kinds[token - 1] != PARSE_KIND_R_BRACE))''','''        (assigned ? p->tokens.kinds[token - 1] != PARSE_KIND_EQUAL :
         (p->tokens.kinds[token - 1] != PARSE_KIND_SEMI && p->tokens.kinds[token - 1] != PARSE_KIND_L_BRACE &&
          p->tokens.kinds[token - 1] != PARSE_KIND_R_BRACE)))''')
s=replace(s,'    if (n > 4)\n','    if (n > (assigned ? 3u : 4u))\n')
s=replace(s,'uint32_t equal, uint32_t end, uint32_t* begin,','uint32_t equal, uint32_t end, uint32_t* begin, bool assigned_calls,')
s=replace(s,'end - equal > 9)','end - equal > (assigned_calls ? 18u : 9u))')
s=replace(s,'''    const TypeId type = args[0].type;
    at += 1;
    if (!check_source_statement_operand''','''    const TypeId type = args[0].type;
    at += 1;
    // Both the call's closing token and assignment must be the complete RHS/statement.
    // The fourth operand slot carries its lvalue while the first three carry arguments.
    if (assigned_calls && at + 2 < end && p->tree.roles[at + 1] == PARSE_ROLE_OPEN_CALL &&
        p->tree.parents[at + 1] == end - 1 && p->tree.roles[end - 1] == PARSE_ROLE_CLOSE_CALL &&
        p->tree.parents[end - 1] == equal)
    {
        const CheckSourceOperand dest = args[0];
        if (!check_source_call_statement(reader, at + 1, end - 1, true, store) ||
            !check_source_argument_compatible(reader->types, type_return(reader->types, store->function), type))
            return false;
        store->arguments[3] = dest;
        store->operation = PARSE_KIND_EQUAL;
        *begin = first;
        return true;
    }
    if (!check_source_statement_operand''')
s=replace(s,'    const bool census = getenv("BUSTER_DIRECT_GRAPH_CENSUS") != NULL;','    const bool census = getenv("BUSTER_DIRECT_GRAPH_CENSUS") != NULL;\n    const bool assigned_calls = getenv("BUSTER_DIRECT_CALL_ASSIGNMENTS") != NULL;\n    uint32_t result_calls = 0;')
s=replace(s,'!check_source_call_statement(reader, first, parent, &call)','!check_source_call_statement(reader, first, parent, false, &call)')
s=replace(s,'!check_source_store_statement(reader, first, end, &begin, &call)','!check_source_store_statement(reader, first, end, &begin, assigned_calls, &call)')
s=replace(s,'                call_count += call_site;','                result_calls += call.operation == PARSE_KIND_EQUAL && call.callee;\n                call_count += call_site;')
s=replace(s,'            if (in->source_statement_audit)\n                fprintf(stderr, "direct-statement', '''            if (in->source_statement_audit && call.operation == PARSE_KIND_EQUAL && call.callee)
                fprintf(stderr, "direct-statement-result\\t%u\\t%u\\n", begin, end);
            if (in->source_statement_audit)
                fprintf(stderr, "direct-statement''')
s=replace(s,'        fprintf(stderr,"source-statement-roles','        fprintf(stderr,"source-statement-call-results\\t%u\\n",result_calls);\n        fprintf(stderr,"source-statement-roles')
p.write_text(s)
p=d/'c_check_program_lower.c';s=p.read_text();s=replace(s,'''        for (uint32_t a = 0; a < count; a += 1)
            check_lower_source_operand(writer, plan->arguments + a, false);
        const uint8_t returned=check_lower_class(writer,result);
        check_lower_emit(writer,BUSTER_TYPED_CALL,returned,call);
        if(result!=BUSTER_TYPE_VOID) check_lower_emit(writer,BUSTER_TYPED_DISCARD,returned,0);''','''        const bool assigned = plan->operation == PARSE_KIND_EQUAL;
        const CheckSourceOperand* dest = plan->arguments + 3;
        if (assigned && dest->field)
            check_lower_source_operand(writer, dest, true);
        for (uint32_t a = 0; a < count; a += 1)
            check_lower_source_operand(writer, plan->arguments + a, false);
        const uint8_t returned = check_lower_class(writer,result);
        check_lower_emit(writer, BUSTER_TYPED_CALL, returned, call);
        if (assigned)
        {
            const uint8_t class = check_lower_class(writer, dest->type);
            if (dest->field)
                check_lower_emit(writer, BUSTER_TYPED_STORE, class, check_lower_access_value(program->types, class, dest->type));
            else
                check_lower_emit(writer, BUSTER_TYPED_STORE_LOCAL, class, check_lower_local_of(writer, dest->object));
        }
        if (result != BUSTER_TYPE_VOID)
            check_lower_emit(writer, BUSTER_TYPED_DISCARD, returned, 0);''');p.write_text(s)
