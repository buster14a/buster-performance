#include <stdio.h>
struct Box { int first; int second; unsigned u; void *p; };
static struct Box *global;
static int o;
static unsigned long long hash=7;
extern void mixed(struct Box *,int);
extern int changes(struct Box *,struct Box *,int,int);
void event(int a,unsigned b,void*p){hash=hash*33u+(unsigned)a+((unsigned long long)b<<15)+(p==global?2:p==&o?5:0);}
long observed(int a,void*p){event(a,41,p);return a;}
int main(void){struct Box box={-13,87,402,&o};global=&box;struct Box second={41,12,11,0};for(int i=0;i<150;i++){mixed(&box,i);event(changes(&box,&second,i,4),second.u,second.p);}printf("%016llx\n",hash);}
