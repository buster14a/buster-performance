from pathlib import Path
import struct,sys
def load(file):
 data=Path(file).read_bytes();header=struct.unpack_from('<HHIQQQIHHHHHH',data,16);at=header[5];size,count,names=header[-3:]
 rows=[struct.unpack_from('<IIQQQQIIQQ',data,at+i*size) for i in range(count)]
 def content(i):r=rows[i];return data[r[4]:r[4]+r[5]]
 names=content(names)
 def string(s,i):return s[i:s.index(0,i)].decode(errors='replace')
 sections={string(names,r[0]):content(i) for i,r in enumerate(rows)}
 bodies={};meta={}
 for i,r in enumerate(rows):
  if r[1]!=2:continue
  syms=content(i);strings=content(r[6])
  for off in range(0,len(syms),r[-1]):
   name,info,vis,section,value,n=struct.unpack_from('<IBBHQQ',syms,off)
   if info&15==2 and section and section<len(rows):
    name=string(strings,name);bodies[name]=content(section)[value:value+n];meta[name]=(section,value,n)
 return sections,bodies,meta
if __name__=='__main__':
 a,b=[load(x) for x in sys.argv[1:]]
 print('changed sections',[(s,len(a[0].get(s,b'')),len(b[0].get(s,b''))) for s in sorted(a[0].keys()|b[0].keys()) if a[0].get(s)!=b[0].get(s)])
 changes=[n for n in sorted(a[1].keys()|b[1].keys()) if a[1].get(n)!=b[1].get(n)]
 print('changed functions',len(changes),'of',len(a[1]))
 for n in changes[:100]:
  aa=a[1].get(n,b'');bb=b[1].get(n,b'');print(n,len(aa),len(bb),aa[:65].hex(),bb[:65].hex())
