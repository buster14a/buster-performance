import csv,hashlib,os,random,subprocess,sys,time
from pathlib import Path
d=Path(__file__).resolve().parent;cc=d.parent/'source-call-assignments/build/compiler';group=sys.argv[1]
flags=sys.argv[2:];os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
policies={
 'ordinary':{},
 'stores_calls':{'BUSTER_DIRECT_SOURCE_STATEMENTS':'1'},
 'call_result':{'BUSTER_DIRECT_SOURCE_STATEMENTS':'1','BUSTER_DIRECT_CALL_ASSIGNMENTS':'1'},
 'masked':{'BUSTER_DIRECT_SOURCE_STATEMENTS':'1','BUSTER_DIRECT_CALL_ASSIGNMENTS':'1','BUSTER_SOURCE_MASK_ADMISSION':'1'}
}
refhash=hashlib.sha256((d/(group+'.base.o')).read_bytes()).hexdigest()
fixed={k:v for k,v in os.environ.items() if k not in ('BUSTER_DIRECT_SOURCE_STATEMENTS','BUSTER_DIRECT_CALL_ASSIGNMENTS','BUSTER_SOURCE_MASK_ADMISSION')}
with (d/(group+'-three.tsv')).open('w',buffering=1) as out:
 w=csv.writer(out,delimiter='\t');w.writerow(('round','position','policy','stage','ns','sha256','equal'))
 for traced in [False,True]:
  for r in range(8):
   order=list(policies);random.Random(331+r).shuffle(order)
   for i,m in enumerate(order):
    dest=d/(group+'-three.o')
    t=time.perf_counter_ns();p=subprocess.run([cc,'--lanes','1',*(['--time-stages'] if traced else []),'-c',*flags,'-o',dest],capture_output=True,env=fixed|policies[m]);ns=time.perf_counter_ns()-t
    if p.returncode:raise RuntimeError((m,p.stderr[-4096:]))
    h=hashlib.sha256(dest.read_bytes()).hexdigest()
    if not traced:w.writerow((r,i,m,'ordinary',ns,h,h==refhash))
    else:
     for line in p.stderr.decode().splitlines():
      bits=line.split('\t')
      if len(bits)>2 and bits[0]=='time-stage' and bits[1]!='stage':w.writerow((r,i,m,bits[1],round(1e6*float(bits[2])),h,h==refhash))
