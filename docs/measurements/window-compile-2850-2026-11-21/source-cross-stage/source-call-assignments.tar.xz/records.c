struct Box { int first; int second; unsigned u; void *p; };
extern void event(int, unsigned, void *);
extern long observed(int, void *);
void mixed(struct Box *box,int x){
  event(box->second,box->u,box->p);
  if(x==7){observed(box->first,box->p);}
  else if(x<30){int y=x*2;event(y,box->u,box->p);}
  else {observed(x,box);}
  for(int i=0;i<((unsigned)x%5);i++){event(i,0,box->p);}
}
int changes(struct Box *box,struct Box *other,int x,int y){
 int r=x;
 if(x<100){r=y;box->first=r+2;}
 else {r=x-y;box->second=r;}
 for(int i=0;i<5;i++){other->second=box->first; r=other->second ^ x;box->first=r;}
 box->u=other->u;
 other->p=box->p;
 x=r+1;
 x=x+y;
 return x;
}
