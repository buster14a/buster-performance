#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD
cc=../source-call-assignments/build/compiler
"$cc" --lanes 1 -c records.c -o records.base.o
BUSTER_DIRECT_SOURCE_STATEMENTS=1 BUSTER_DIRECT_RETURN_AUDIT=1 "$cc" --lanes 1 -c records.c -o records.new.o 2>records.new.stderr
python3 elf.py records.base.o records.new.o >records.elf
clang -c records.c -o records.clang.o
for v in base new clang;do clang records-driver.c records."$v".o -o records."$v".bin;./records."$v".bin >records."$v".stdout;done
cmp records.clang.stdout records.new.stdout
