extern int effect(int*);int f(int *p){effect(p); return *p;}
