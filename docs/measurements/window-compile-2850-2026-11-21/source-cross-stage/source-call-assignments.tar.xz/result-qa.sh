#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cc=../source-call-assignments/build/compiler
"$cc" --lanes 1 -c result.c -o result.base.o
BUSTER_DIRECT_SOURCE_STATEMENTS=1 BUSTER_DIRECT_RETURN_AUDIT=1 "$cc" --lanes 1 -c result.c -o result.new.o 2>result.new.stderr
python3 elf.py result.base.o result.new.o >result.elf
clang -c result.c -o result.clang.o
for v in base new clang;do clang result-driver.c result."$v".o -o result."$v".bin;./result."$v".bin >result."$v".stdout;done
cmp result.clang.stdout result.new.stdout
