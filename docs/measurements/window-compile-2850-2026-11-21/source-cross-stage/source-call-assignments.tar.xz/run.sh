#!/bin/bash
set -eu
export BUSTER_DIRECT_CALL_ASSIGNMENTS=1 BUSTER_SOURCE_MASK_ADMISSION=1
cd "$(dirname "$0")"; d=$PWD; cd ../source-call-assignments
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
python3 "$d/optimized.py" >"$d/build.log" 2>&1
cp ../buster/build/predefines.h build/
cd "$d";cc=../source-call-assignments/build/compiler
"$cc" --lanes 1 -c mixed.c -o mixed.base.o
BUSTER_DIRECT_SOURCE_STATEMENTS=1 BUSTER_DIRECT_RETURN_AUDIT=1 "$cc" --lanes 1 -c mixed.c -o mixed.new.o 2>mixed.new.stderr
python3 elf.py mixed.base.o mixed.new.o >mixed.elf
clang -c mixed.c -o mixed.clang.o
for v in base new clang;do clang mixed-driver.c mixed."$v".o -o mixed."$v".bin;./mixed."$v".bin >mixed."$v".stdout;done
cmp mixed.clang.stdout mixed.new.stdout
bash "$d/record-qa.sh"
bash "$d/result-qa.sh"
(cd ../source-call-assignments && ./build/compiler test-checker --seed 2850 --part 6/8) >"$d/checker6.log" 2>&1 || true
bash "$d/qa.sh" >"$d/qa.log" 2>&1
python3 "$d/boundary.py" >"$d/policy.log" 2>&1
bash "$d/three.sh" >"$d/three.log" 2>&1
bash "$d/perf.sh" >"$d/perf.log" 2>&1
python3 "$d/../source-statement-calls-study/coverage.py" "$d" >"$d/coverage.txt"
python3 "$d/../source-call-native-study/report-pairs.py" "$d"
python3 "$d/../source-statement-calls-study/results.py" "$d" >"$d/results.txt"
bash "$d/../source-statement-calls-study/pmu.sh" "$d" >"$d/pmu.log" 2>&1
