from pathlib import Path
import subprocess,os,csv
d=Path(__file__).resolve().parent;cc=d.parent/'source-call-assignments/build/compiler'
cases={
 'associated call':'extern int foo(int);int f(int x){x=foo(x);return x;}',
 'pointer return':'struct P{int v;};extern struct P*foo(int);void*f(void*p,int x){p=foo(x);return p;}',
 'aggregate return':'struct P{int v;};extern struct P foo(int);void f(struct P*p,int x){*p=foo(x);}',
 'narrowing return':'extern long foo(int);int f(int x){x=foo(x);return x;}',
 'nodiscard store':'int foo(int) __attribute__((warn_unused_result));int f(int x){x=foo(x);return x;}',
 'ret unsupported scalar':'extern int foo(int,int,int,int);int f(int x){x=foo(x,2,3,4);return x;}',
 'dropped call result':'extern int foo(int);int f(int x){if(0){x=foo(x);}return x;}',
 'computed assignment dest':'extern int foo(int);int f(int x,int*p){p[x]=foo(x);return p[x];}',

 'extern object':'extern int g;extern void consume(int);int f(int x){consume(g);g=x;x=g;return x;}',
 'tentative global':'int g;extern void consume(int);int f(int x){consume(g);g=x;x=g;return x;}',
 'file block shadow':'int g;extern void consume(int);int f(int g){consume(g);{int g=3;consume(g);}return g;}',
 'global member data':'struct P{int x;};extern struct P*gp;void f(int x){gp->x=x;}',
 'extern local identity':'extern void consume(int);int f(int x){extern int g;consume(g);g=x;x=g;return x;}',
 'register address':'extern void consume(int*);void f(int x){register int r=x;consume(&r);}',
 'width addpower':'unsigned f(unsigned x){x=x*2;return x;}',
 'width subzero':'int f(int x){x=x-0;return x;}',
 'width nulptr':'void *f(void *p){p=0;return p;}',
 'undefined assignment':'struct P{int x;};int f(struct P*p){p->x=p->missing;return p->x;}',
 'zero initializer':'int f(void){int x;int y;x=0;y=x;return y;}',
 'atomic pointer member':'struct P{_Atomic int x;};void f(struct P*p,int v){p->x=v;}',
 'restricted assignment':'int*f(int * restrict p,int*q){p=q;return p;}',
 'condition truth':'int f(int x){if(x){return 3;}return 4;}',
 'condition not':'int f(int x){if(!x){return 4;}return 3;}',
 'condition null pointer':'int f(int *p){if(p==0){return 7;}return *p;}',
 'cond loop':'int f(int x){int y=0;while(x<7){y+=x++;}return y;}',
 'condition global':'int g;int f(int x){if(g==x){return 1;}return 2;}',
 'condition local const':'int f(int x){const int y=1;if(y){return x;}return 5;}',
 'condition lookalike genuine':'int f(int a,int b){if(a==b){return 5;}return 0;}',
 'condition selfcompare':'int f(int x){if(x==x){return 4;}return 5;}',
 'condition unsigned negative':'int f(unsigned x){if(x < -1){return 4;}return 6;}',
 'condition pretest':'int f(int x){int y=0;do{y+=2;}while(y < x);return y;}',
 'condition volatile':'int f(volatile int *x){if(*x){return 4;}return 3;}',
 'condition ternary':'int f(int x,int y){if(x?y:x){return 2;}return 3;}',
 'condition switch':'int f(int x){switch(x){case 4:return 5;default:return 6;}}',
 'condition head member':'struct R{int x;};int f(struct R*r,int y){if(r->x==y){return r->x;}return y+1;}',
 'condition ifdef':'int f(int x){if(x){\n#if 1\nreturn 4;\n#endif\n}return 3;}',

 'callee static minimum':'extern void effect(int x[static 9]);void f(void){effect(0);}',
 'nullability':'extern void effect(int * _Nonnull);void f(void){effect(0);}',
 'unavailable member':'struct S{int x __attribute__((unavailable));};extern void effect(int);void f(struct S*s){effect(s->x);}',
 'noderef member':'struct S{int x;};extern void effect(int);void f(struct S __attribute__((noderef))*s){effect(s->x);}',
 'discarded result':'int effect(int) __attribute__((warn_unused_result));void f(int x){effect(x);}',
 'illegal store':'struct S{const int x;};void f(struct S*p,int v){p->x=v;}',
 'const member dest':'struct S{int x;};void f(const struct S*p,int v){p->x=v;}',
 'bitfield dest':'struct S{unsigned x:5;};void f(struct S*p,unsigned v){p->x=v;}',
 'volatile source':'struct S{volatile int x;};int f(struct S*p){int v;v=p->x;return v;}',
 'static dest':'static int y;void f(int x){y=x;}',
 'static source':'static int x;void f(int y){y=x;}',
 'ptr qual loss':'void f(const int *a,int *b){b=a;}',
 'nonzero pointer':'void f(int *a){a=7;}',
 'const local':'void f(int x){const int y=3;y=x;}',
 'simple integer':'int f(int a,int b){int t=0;t=a+b;return t;}',
 'member store and load':'struct S{int x;};int f(struct S*p,int x){p->x=x;x=p->x;return x;}',
 'unsigned wrap':'unsigned f(unsigned x){x=x+1;return x;}',
 'self member':'struct S{int x;};void f(struct S*p,int x){p->x=p->x+x;}',
 'nested control':'int f(int a,int b){if(a){a=a+b;}else{b=b-a;}return a*b;}',
 'shadowed local':'int f(int a,int b){ {int a=2;a=b;b=a;}return a+b;}',
 'body':'extern void effect(int); int f(int x) { effect(x); return x+1; }',
 'call-two':'extern int effect(int,int); int f(int x, int y) { effect(x,y); return x-y; }',
 'loop':'extern void effect(int); void f(int x) { while(x--){ effect(x); } }',
 'condition':'extern void effect(int); void f(int x) { if(x){ effect(x); } else {effect(3);} }',
 'jump':'extern void effect(int); void f(int x) { goto a; effect(x);a:effect(x); }',
 'const branch':'extern void effect(int); void f(int x) { if(0){effect(x);}else{effect(3);} }',
 'stmt-expr':'extern void effect(int); void f(int x) { x=({effect(x);4;}); effect(x); }',
 'static local':'extern void effect(int); void f(void) {static int x=7;effect(x); }',
 'volatile local':'extern void effect(int);void f(void){volatile int x=9;effect(x);}',
 'pragma':'extern void effect(int);void f(int x){_Pragma("GCC diagnostic push") effect(x); _Pragma("GCC diagnostic pop")}',
 'attribute':'extern void effect(int) __attribute__((deprecated));void f(int x){effect(x);}',
 'symbol alias':'extern void effect(int) __asm__("call_target");void f(int x){effect(x);}',
 'implicit conversion':'extern void effect(unsigned);void f(int x){effect(x);}',
 'void ptr':'extern void effect(void*);void f(int*x){effect(x);}',
 'volatile pointee':'extern void effect(volatile int*);void f(volatile int*x){effect(x);}',
 'incomplete early':'struct X; extern void effect(struct X*);void f(struct X*x){effect(x);}',
 'function ptr':'void f(void(*effect)(int),int x){effect(x);}',
 'indirect target':'extern void effect(int); void f(int x){ void (*g)(int)=effect;g(x);}',
 'masked bad':'extern void effect(int); void f(int x){if(0){effect(x,x);}}',
 'unsupported operand':'extern void effect(int);void f(int x){effect(++x);}',
 'shadow':'extern void effect(int);void f(int x){{int x=41;effect(x);}effect(x);}',
 'storage':'extern int effect(int); int f(int x){ return effect(x);}',
 'void general':'extern void effect(int); void f(int x){int y=x+1;effect(y);}',
 'local arena':'extern void effect(int);void f(int x){int y=x+1,*p=&y;effect(y);*p=x;effect(y);}',
 'argument order':'extern void effect(int,int,int,int);void f(int x,int y){effect(y,2,x,y);}',
 'noreturn':'_Noreturn void effect(int);void f(int x){effect(x);}',
 'returns-twice':'extern int effect(int) __attribute__((returns_twice));void f(int x){effect(x);}',
 'cold repeated':'extern void effect(int);void f(int x){effect(x);effect(0);effect(x);}',
 'wrong abi':'extern int __attribute__((ms_abi)) effect(int);void f(int x){effect(x);}',
 'bound outside function':'extern void effect(int);int object=effect(0);',
 'enum arg':'extern int effect(int);enum K{X=5};void f(void){effect(X);}',
 'no args':'extern void effect(void);void f(int x){if(x){effect();}}',
 'aggregate return':'struct S{int x;};extern struct S effect(int);void f(int x){effect(x);}',
 'shadowed label':'extern void effect(int);void f(int x){if(x)goto label;{effect(x);}label:;effect(x);}',
 'alias through parameter':'extern int effect(int*);int f(int *p){effect(p); return *p;}'
}
policies=[('default',[]),('warnings',['-Wall','-Wextra']),('debug',['-g']),('PIC',['-fPIC']),('source',['--verify'])]
with (d/'policy.tsv').open('w',buffering=1) as out:
 wr=csv.writer(out,delimiter='\t');wr.writerow(['name','policy','code','same','source','lower'])
 for name,src in cases.items():
  file=d/'edge.c';file.write_text(src+'\n')
  for policy,args in policies:
   states=[]
   for mode in 'AB':
    obj=d/'edge.o';obj.unlink(missing_ok=True)
    env={**os.environ,**({'BUSTER_DIRECT_SOURCE_STATEMENTS':'1','BUSTER_DIRECT_RETURN_AUDIT':'1'} if mode=='B' else {})}
    p=subprocess.run([cc,*args,'--lanes','1','-c',file,'-o',obj],capture_output=True,env=env)
    lines=p.stderr.splitlines(keepends=True)
    states.append((p.returncode,p.stdout,b''.join(l for l in lines if not l.startswith((b'direct-statement\t',b'direct-statement-lower\t',b'direct-statement-result\t',b'direct-condition\t',b'direct-condition-lower\t'))),obj.read_bytes() if obj.exists() else None))
   wr.writerow((name,policy,states[-1][0],states[0]==states[1],sum(l.startswith(b'direct-statement\t') for l in lines),sum(l.startswith(b'direct-statement-lower\t') for l in lines)))
