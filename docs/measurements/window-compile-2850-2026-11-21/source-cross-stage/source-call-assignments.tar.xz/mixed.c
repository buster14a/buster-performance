extern void add(int);
extern int add2(int,int);
void series(int x, int y){
 add(x); add2(x,y);
 if(x==y){ add2(x,4); add(y); }
 else { add2(8,x); }
 for(int i=0;i<6;i++){ add2(x,i); }
}
void no_call(void){ int x=1; x++; }
