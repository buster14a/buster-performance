#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;v=$1;cc=$root/trees/structuralnames$v/build/compiler
out=$root/results/structural-single-replay-edges-$v;mkdir -p "$out"
test -x "$cc"
python3 pp-structural/make-replay-cases.py "$out"
for case in small oneblock twoblocks manyblocks early header;do
 for arm in before candidate;do
  vars=();[[ $arm != candidate ]] || vars=(BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1)
  stem=$out/$case-$arm
  ./lock.sh taskset -c 2 bash -c 'set +e;stem=$1;shift;"$@" >"$stem.out" 2>"$stem.err";echo $? >"$stem.rc"' _ "$stem" env "${vars[@]}" "$cc" -Weverything -c "$out/$case.c" -o "$stem.o" >"$stem.lease" 2>&1
 done
 cmp -s "$out/$case-before.rc" "$out/$case-candidate.rc" && cmp -s "$out/$case-before.err" "$out/$case-candidate.err" && cmp -s "$out/$case-before.o" "$out/$case-candidate.o" && match=yes || match=no
 printf '%s %s %s %s\n' "$case" "$match" "$(cat "$out/$case-before.rc")" "$(cat "$out/$case-candidate.rc")" >>"$out/results"
done
