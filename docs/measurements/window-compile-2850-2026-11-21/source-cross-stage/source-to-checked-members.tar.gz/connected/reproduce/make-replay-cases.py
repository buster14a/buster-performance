from pathlib import Path
import sys
root=Path(sys.argv[1]);root.mkdir(exist_ok=True)
for name,n,pad,where in [('small',192,False,'late'),('oneblock',192,True,'late'),('twoblocks',382,True,'late'),('manyblocks',770,True,'late'),('early',382,True,'early'),('header',770,True,'header')]:
 parts=[(b'/*'+b'x'*1048550+b'*/\n') if pad else b'']
 parts.append(b'extern int local_spelling;\n'*n)
 if where=='header':parts.append(b'#include "h.h"\n')
 if where=='early':parts.append(b'#warning explicit_warning\n')
 parts.append(b'int main(void){int unused_local=1;return 0;}\n')
 (root/(name+'.c')).write_bytes(b''.join(parts))
(root/'h.h').write_bytes(b'struct retain { int field; };\nextern int ordinary_header;\n')
