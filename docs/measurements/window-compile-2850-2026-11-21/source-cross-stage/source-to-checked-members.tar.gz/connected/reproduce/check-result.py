from pathlib import Path
import csv,sys,collections
d=Path(__file__).resolve().parent
def cols(p):
 with p.open() as f:return list(csv.DictReader(f,delimiter='\t'))
source={int(x['pp-row']):x for x in cols(d/'../pp-structural-study/structural-single-member-census/members.tsv')}
ordinary={int(x['pp-row']):x for x in cols(d/'../source-member-trace-study/sqlite-members.tsv')}
for p in map(Path,sys.argv[1:]):
 rows=p.read_text().splitlines();ref=set();bad=[]
 for line in rows:
  row,rec,spelling,slot,offset,quals,*extras=line.split('\t');k=int(row)
  s=source.get(k);o=ordinary.get(k);ref.add(k)
  if s is None or o is None or s['spelling']!=spelling or o['member-slot']!=slot or o['offset-bits']!=offset or (int(o['record-type'])&~7)!=(int(rec)&~7):bad.append(line)
 print(p,'physical queries',len(rows),'distinct',len(ref),'producer retained',len(source),'missed',len(source.keys()-ref),'mismatched',len(bad),'examples',bad[:3]);assert not bad
