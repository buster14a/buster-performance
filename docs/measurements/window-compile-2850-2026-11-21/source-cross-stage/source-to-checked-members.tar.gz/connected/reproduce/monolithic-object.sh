#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;v=$1
pre=$root/results/structural-single-source-names-$v;out=$root/results/structural-single-object-$v;tree=$root/trees/structuralnames$v
mkdir -p "$out"
for ((n=0;n<720;n++));do [[ -s $pre/deferred-spans.tree && -s $pre/deferred-spans.rows ]] && break;sleep 5;done
cmp "$pre/deferred-spans.tree" "$pre/deferred-baseline.tree"
cmp "$pre/deferred-spans.rows" "$root/results/active-source-origins/eager.deferred.rows"
source corpora.sh;eval "args=($sqlite_arguments)"
./lock.sh bash -c 'cd "$1" && ./build.sh --config Release' _ "$tree" >"$out/build" 2>&1
cc=$tree/build/compiler;base=$root/results/factsmain0e1d/compiler
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
lock() { ./lock.sh taskset -c 2 "$@"; }
for mode in basic extended;do
 flags=();[[ $mode != extended ]] || flags=(-DSQLITE_ENABLE_FTS5 -DSQLITE_ENABLE_FTS3 -DSQLITE_ENABLE_SESSION -DSQLITE_ENABLE_PREUPDATE_HOOK -DSQLITE_ENABLE_GEOPOLY -DSQLITE_ENABLE_DBSTAT_VTAB)
 for w in default max;do
  warnings=();[[ $w != max ]] || warnings=(-Weverything)
  f=$out/$mode-$w
  lock bash -c 'f=$1;shift;exec "$@" >"$f.out" 2>"$f.err"' _ "$f" env BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 "$cc" -c "${args[@]}" "${flags[@]}" "${warnings[@]}" -o "$f.o" >"$f.lock" 2>&1
  for kind in o out err;do cmp "$f.$kind" "$root/results/active-source-native-oracles/eager-$mode-$w.$kind";done
 done
done
lock env PATH="$paths:$PATH" clang -no-pie "$root/results/active-source-native-oracles/driver.o" "$out/basic-default.o" -lm -ldl -lpthread -o "$out/linked" >"$out/link.lease" 2>&1
lock bash -c 'exec "$1" >"$2" 2>"$3"' _ "$out/linked" "$out/sql.out" "$out/sql.err" >"$out/run.lease" 2>&1
cmp "$out/sql.out" "$root/results/active-source-native-oracles/clang.sql"
cmp "$out/sql.err" "$root/results/active-source-native-oracles/clang.sqlerr"
for r in 1 2 3;do
 if ((r%2));then arms=(baseline source source baseline);else arms=(source baseline baseline source);fi
 for i in {0..3};do
  arm=${arms[i]};vars=();compiler=$base
  if [[ $arm == source ]];then vars=(BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1);compiler=$cc;fi
  f=$out/$r-$i-$arm
  lock env "${vars[@]}" python3 -c 'import subprocess,sys,time; t=time.perf_counter_ns(); r=subprocess.run(sys.argv[1:]); print(time.perf_counter_ns()-t); raise SystemExit(r.returncode)' "$compiler" -c "${args[@]}" -o "$out/timed.o" >"$f.time" 2>"$f.lease"
  cmp "$out/timed.o" "$out/basic-default.o"
 done
done
(cd "$out" && sha256sum *.o sql.* >hashes)
