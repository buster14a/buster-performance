#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;out=$root/results/structural-single-replay-fixed-proof;mkdir -p "$out"
cc=$root/trees/structuralnamesv8/build/compiler;bad=$root/results/structural-single-replay-edges-v3
for n in {1..180};do [[ ! -x $cc ]] || break;sleep 5;done
test -x "$cc"
for c in oneblock header;do
 f=$out/$c
 ./lock.sh taskset -c 2 bash -c 'f=$1;shift;"$@" >"$f.out" 2>"$f.err"' _ "$f" env BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 "$cc" -Weverything -c "$bad/$c.c" -o "$f.o" >"$f.lease" 2>&1
 for ext in o err out;do cmp "$bad/$c-before.$ext" "$f.$ext";done
 echo "$c exact recovery of rc=0 stderr, stdout and object against original code on same input" >>"$out/result"
done
(cd "$out" && sha256sum *.o *.err >hashes)
