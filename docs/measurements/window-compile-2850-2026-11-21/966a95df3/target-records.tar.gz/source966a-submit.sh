#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
bash build-label.sh source966a 0e1d5b825801135bf50e79da9d546bc95209ab30 source966a.patch
bash source966a-individual-one.sh sqlite
bash source966a-individual-one.sh main
echo COMPLETE
