from pathlib import Path
from collections import Counter
import re,gzip,csv
w=Path(__file__).resolve().parent;pat=re.compile(r'^\s*(\d+)\s+\d+  (.*?)\s+(\S+)\s+\| (\S+)\s+(\d+)\s+(-?\d+)$');tokens=[]
with gzip.open(w/'sqlite-tree.gz','rt',errors='replace') as f:
 for line in f:
  m=pat.match(line.rstrip('\n'))
  if m:
   i=int(m[1]);assert i==len(tokens),(i,len(tokens),line);tokens.append((m[2].strip(),m[3],m[4],int(m[5]),int(m[6])))
counts=Counter();groups=[];start=0;previous_end=-2;run=0;spans=[]
suffixes=Counter()
with (w/'parser-signatures.tsv').open('w') as f:
 out=csv.writer(f,delimiter='\t');out.writerow(['first','open','close','end','symbol','syntactic_family','parameters','declaration_tokens'])
 for i,(text,kind,role,depth,close) in enumerate(tokens):
  if depth==0 and role in ('TERMINATOR','CLOSE_BODY'):start=i+1
  if role!='OPEN_FUNCTION' or depth!=0 or i==0 or tokens[i-1][1]!='IDENTIFIER' or close+1>=len(tokens):continue
  nxt=close+1
  while nxt+1<len(tokens) and tokens[nxt][0] in ('__attribute__','__attribute') and tokens[nxt+1][0]=='(' and tokens[nxt+1][4]>nxt+1:
   nxt=tokens[nxt+1][4]+1
  if nxt<len(tokens) and tokens[nxt][0]==';':suffixes['attribute' if nxt!=close+1 else 'semi']+=1
  if tokens[close+1][0]!=';':continue
  params=[];a=i+1
  for k in range(i+1,close+1):
   if k==close or tokens[k][0]==',':params.append(tokens[a:k]);a=k+1
  valid=0<len(params)<=8 and close-i<=48
  for par in params:
   if par and par[0][0]=='const':par=par[1:]
   if not par:valid=False;continue
   typ,*ptr=par
   valid &= typ[2]=='SPECIFIER' and (typ[1]=='IDENTIFIER' or typ[0] in ('void','char','int','signed','unsigned','short','long','float','double')) and len(ptr)<=2 and all(x[0]=='*' for x in ptr)
  typedef=any(x[0]=='typedef' for x in tokens[start:i]);valid=valid and not typedef
  cat='unnamed' if valid else 'other';counts[cat,'declarations']+=1;counts[cat,'syntactic_tokens']+=close+2-start; counts[cat,'parameter_tokens']+=close-i+1
  if valid:
   if start!=previous_end+1:
    if run:spans.append(run)
    run=0
   run+=1;previous_end=close+1
  out.writerow([start,i,close,close+1,tokens[i-1][0],cat,len(params),close+2-start])
 if run:spans.append(run)
print('parser tokens',len(tokens),'counts',counts,'runs',len(spans),'max',max(spans),'runs of four or more',sum(x>=4 for x in spans),'admitted in those runs',sum(x for x in spans if x>=4))

print('file-scope direct named function open+suffix-semicolon',suffixes)
