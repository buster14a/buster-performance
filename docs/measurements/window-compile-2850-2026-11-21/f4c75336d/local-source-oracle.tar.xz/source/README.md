# File-scope prototype reader

This ordinary compiler path builds parameter records for parser-delimited file-scope prototypes with up to eight unnamed, unannotated scalar or pointer parameters. A typedef is resolved against the current declaration bindings. The reader checks the whole list before committing types, bindings or parameter records. Other declarations continue through the existing reader. The existing type and declaration registration code consumes the records.

Apply `filesigf4c.patch` to `0e1d5b825801135bf50e79da9d546bc95209ab30` and use the repository's `./build.sh` for the measured production compiler (`f4c75336d7fe1792d053f2385289ca1ce2ade222`). `implementation.c` preserves the complete resulting reader source. The local candidate executable originally hashed to `f23810ec63c368ef92da4392ba66e6ecdaebcd0fdf1c875e56c2f6dd0e7371a3`. The additional `attestation-inventory.patch` classifies the six reader fields for the repository's test suite. It changes only the test source and was committed as `f03f00dd03885461821c254ebc7b41702137d7ee`. The original shard 6 report is preserved.

## Source and object checks

SQLite admitted 956 complete declarations covering 10,686 source tokens and 2,056 parameter specifications covering 6,775 tokens out of 716,136 parsed. `BUSTER_PROTOTYPE_CENSUS=1` prints these counts on ordinary compilation. The lexical inventory is a separate upper bound: 966 eligible-looking declarations, including 764 in consecutive runs of four or more, with the longest run containing 39 declarations.

The 656 directed differential invocations in `oracle.tsv` compare status, diagnostic streams and the full emitted object or assembly. Three linked native programs also matched Clang 23.1.4. The compressed `corpus/*.tsv.gz` manifests preserve 4,116 paired invocations for SQLite, Buster, Lua and musl. Source and diagnostic paths are the original local names.

## Reproduction

For local scripts, place these files in a directory named `fresh-file-study`. The scripts expect siblings `main-fbef-clean/build/compiler` for the reference, `fresh-file-signatures/build/compiler` for the candidate and `switch-inputs/sqlite/sqlite3.c` for the frozen SQLite amalgamation. `oracle.py` names the pinned local Clang executable at its start. `target_pairs.py` writes its three 7,000-prototype controls. Run `python3 oracle.py`, `python3 local_pairs.py`, `python3 target_pairs.py` and `python3 pmu.py` under an exclusive local core lease. The target inputs exist after `target_pairs.py`. The local target/PMU/wall TSVs and logs report Ryzen 9 7940HS observations. `parse_inventory.py` expects a compressed compiler parse-tree dump in `sqlite-tree.gz`. `corpus_pair.py` contains the frozen-source differential runner.

The 9700X scripts are `filesigf4c.sh` and `filesigf4c-one.sh`. The signed-head candidate was built by applying `filesigf4c.patch` on the exact parent. On the shared measurement host the scripts take the existing dedicated CPU lock and compare SQLite in seven interleaved ABBA/BAAB rounds. The separate hardware record includes source and binary identities, paired observations, native reports and the complete object manifest.

On the 9700X the candidate reduced user instructions in all seven rounds (median difference −2,708,859.5). Median elapsed time increased by 0.223 ms, with two of seven rounds faster. Total cycles per token increased by 2.2361 in the median. All 62 complete object manifests matched. The campaign ended with SQLite.
