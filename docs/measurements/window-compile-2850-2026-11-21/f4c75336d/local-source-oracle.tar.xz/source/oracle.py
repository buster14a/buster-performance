from pathlib import Path
import csv,hashlib,subprocess as sp,itertools,os
w=Path(__file__).resolve().parent.parent;d=w/'fresh-file-study';out=d/'oracle';out.mkdir(exist_ok=True);p=w/'main-fbef-clean/build/compiler';q=w/'fresh-file-signatures/build/compiler';clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang');types=['void','int','unsigned','float','double','char','T','C','S','P','Fn','Arr','Aligned','Node','V'];patterns=['{}','const {}','{} *','const {} *','{} **','{} *const','struct Tagged *','enum E','int named','int x[static 4]','int(*)(int)','...','void bad','__attribute__((unused)) int','_Atomic(int)','const void','register int','VOL','RV','int a, int a','int wrong[0]','typeof(int)', 'int __attribute__((ns_consumed))'];head='''typedef unsigned long T;typedef char C;typedef struct Tagged{int v;}S;typedef int *P;typedef int Fn(int);typedef int Arr[4];typedef int Aligned __attribute__((aligned(16)));typedef int *Node __attribute__((noderef));typedef volatile int V;typedef int VOL;typedef const int RV;enum E { A=1 };\n''';modes={'default':['-c'],'severe':['-c','-Weverything','-Werror','-ferror-limit=0'],'warnings':['-c','-Wall','-Wextra','-Wconversion','-ferror-limit=0'],'assembly':['-S'],'debug':['-g','-c'],'typed':['--dump-typed','-c'],'scalar':['--scalar','-c'],'verify':['--verify','-c']}; cases={};h=lambda b:hashlib.sha256(b).hexdigest()
for i,t in enumerate(types):
 for offset in [0,5,10,15,20]:
  params=[pat.format(t) if '{}' in pat else pat for pat in patterns[offset:offset+5]];decls=[]
  for j,v in enumerate(params):
   decls.extend([f'extern int fn{j}({v});',f'static int local{j}({v});',f'extern int two{j}(int,{v});',f'extern int three{j}({v},int);']);
  cases[f'type{i}-{offset}']=head+'\n'.join(decls)+'\nint go(void){return 0;}\n'
cases['redeclarations']=head+'int f(C*,T*,int);int f(char*,unsigned long*,int);int f(char *c,T *x,int k){return c[k]+*x;}\nint main(void){char s[]={2,9};T x=7;return f(s,&x,1)!=16;}\n'
cases['shadow']=head+'extern int f(T*);int g(void){typedef double T;extern int f(T*);return 0;}extern int f(T*);\n'
cases['definition-selector']='typedef struct S {int k;} S;extern int f(const S*,int);int f(const S *p,int k){return p->k+k;}int main(void){S p={8};return f(&p,4)!=12;}\n'
cases['extensions']='typedef int T __attribute__((deprecated));typedef int G __attribute__((address_space(1)));typedef int Fn(int) __attribute__((ms_abi));extern int a(T*,G*,Fn*);int go(void){return 0;}\n'
cases['nul']='int f(void *); int g(void **); int h(void); int body(void){return h();}\n'
cases['overload']=head+'__attribute__((overloadable)) int f(T*); __attribute__((overloadable)) int f(C*);\n'
cases['linkset']=head+'extern int f(T*,T*, int); int f(T *a,T*b,int n){return a[0]+b[0]+n;} int main(void){T a=9,b=1;return f(&a,&b,3)!=13;}\n'
with (d/'oracle.tsv').open('w',buffering=1) as log:
 wr=csv.writer(log,delimiter='\t');wr.writerow(['source','mode','same','status','stderr','output','runtime','clang_runtime']);
 for name,src in cases.items():
  f=out/(name+'.c');f.write_text(src)
  for m,flags in modes.items():
   result=[];native=[];obj=out/('unit.s' if m=='assembly' else 'unit.o');exe=out/'unit';oracle=None
   for cc in (p,q):
    obj.unlink(missing_ok=True);r=sp.run([cc,'-std=gnu23',*flags,f,'-o',obj],capture_output=True,timeout=30);result.append((r.returncode,r.stdout,r.stderr,obj.read_bytes() if obj.exists() else b''));
    if m=='default' and name in ('linkset','definition-selector','redeclarations') and r.returncode==0:
     link=sp.run([clang,'-no-pie',obj,'-o',exe],capture_output=True);assert link.returncode==0,link.stderr;native.append(sp.run([exe],capture_output=True).returncode)
   if native:
    c=sp.run([clang,'-Wno-everything',f,'-o',exe],capture_output=True);assert c.returncode==0,c.stderr;oracle=sp.run([exe],capture_output=True).returncode
   ref,fix=result;same=ref==fix and all(x==oracle for x in native);wr.writerow([name,m,int(same),fix[0],h(fix[2]),h(fix[3]),native,oracle]);
   if not same:
    dest=out/name/m;dest.mkdir(exist_ok=True,parents=True);print(name,m,[(tag,len(a),len(b)) for tag,a,b in zip(['stdout','stderr','obj'],ref[1:],fix[1:]) if a!=b],flush=True)
    for id,rs in [('ref',ref),('fix',fix)]:
     for tag,v in zip(['stdout','stderr','obj'],rs[1:]):(dest/(id+'.'+tag)).write_bytes(v)
