from pathlib import Path
import csv,subprocess as sp,random,time,statistics,re
w=Path(__file__).resolve().parent.parent;d=w/'fresh-file-study';c=[('base',w/'main-fbef-clean/build/compiler'),('candidate',w/'fresh-file-signatures/build/compiler')];rng=random.Random(2850)
forms={'admitted':'const S*,T,int,char**','named':'const S *s,T t,int n,char **p','mixed':None};metric=re.compile(rb'^time-stage\tcheck-input\t([0-9.]+)',re.M)
with (d/'target-pairs.tsv').open('w',buffering=1) as stream:
 wr=csv.writer(stream,delimiter='\t');wr.writerow(['mode','pair','order','base_ms','candidate_ms','base_input_ms','candidate_input_ms']);
 for mode,ps in forms.items():
  f=d/('prototypes-'+mode+'.c');f.write_text('typedef struct S { int k; } S; typedef unsigned long T;\n'+''.join(f'int p{i}({ps if ps else list(forms.values())[i%2]});\n' for i in range(7000))+'int main(void){return 0;}\n');data=[];args=['-c','--lanes','1',f,'-o',d/'synth.o']
  for j in range(19):
   order=c.copy();rng.shuffle(order);v={}
   for label,cc in order:
    st=time.perf_counter_ns();r=sp.run([cc,'--time-stages',*args],capture_output=True,timeout=60);elapsed=(time.perf_counter_ns()-st)/1e6;assert r.returncode==0,r.stderr;rs=metric.search(r.stderr);assert rs,r.stderr;v[label]=(elapsed,float(rs[1]));
   if j>0:
    a,b=v['base'],v['candidate'];wr.writerow([mode,j,','.join(x[0] for x in order),a[0],b[0],a[1],b[1]]);data.append((b[0]-a[0],b[1]-a[1]))
  print(mode,'n',len(data),'paired-delta-wall-ms',statistics.median(x[0] for x in data),'paired-delta-check-input-ms',statistics.median(x[1] for x in data),flush=True)
