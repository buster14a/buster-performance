set pagination off
set confirm off
set debuginfod enabled off
set $calls=0
set $changed=0
break *0x000000000138fe90
commands
silent
set $calls=$calls+1
set $p=*(char**)($rdi+8)+20*(*(unsigned int*)($rdi+24))
if *(unsigned char*)($p+12)==12 && $changed == 0
set $changed=1
printf "CHECKED_LT node=%u result=%u lhs=%u rhs=%u\n",*(unsigned int*)$p,*(unsigned char*)($p+15),*(unsigned char*)($p+16),*(unsigned char*)($p+17)
end
continue
end
run
printf "VISITED %u COMPARES %u\n",$calls,$changed
