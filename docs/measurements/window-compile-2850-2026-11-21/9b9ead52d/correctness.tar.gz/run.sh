#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD;cd ../declaration-list-heads
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >"$d/build.log" 2>&1;cp ../buster/build/predefines.h build/predefines.h
for i in {1..8};do build/compiler test-checker --seed 2850 --part "$i/8" >"$d/checker-$i.log" 2>&1;done
