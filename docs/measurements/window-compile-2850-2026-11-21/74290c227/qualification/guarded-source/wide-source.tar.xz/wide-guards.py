"""Target fields with swizzle spellings, source-time tag visibility, qualifiers and constant provenance."""
import csv,gzip,hashlib,subprocess
from pathlib import Path
d=Path(__file__).resolve().parent;out=d/'wide';out.mkdir(exist_ok=True);w=d.parent
ccs=[w/'main-fbef-clean/build/compiler',w/'struct-member-facts/build/compiler']
pad='int warm(int i){\n'+'i=(i^15)+7;\n'*800+'return i;}\n'
cases={
'const':'struct S{int x;int y;}; static const struct S s={3,7}; static const struct S *const p=&s; int f(void){return p->x ^ p->y ^ p->x;} static_assert(__builtin_constant_p(p->x) == __builtin_constant_p(p->x));',
'load':'struct S{int x;}; int f(struct S *a, struct S **b){return (a->x&7)^((*b)->x&3)^a->x^(*b)->x;}',
'reg':'struct S{int x; int w;}; int f(register struct S*p, struct S*q){return p->x^q->x^p->w^q->w;}',
'atomic':'struct S{_Atomic(int) x; volatile int y;};int f(struct S*p,struct S*q){return p->x^q->x^p->y^q->y;}',
'temporals':'struct S;int f(struct S*p){return p->x ^ p->x;}struct S{int x;};int g(struct S*p){return p->x^p->x;}',
'packed':'struct __attribute__((packed)) S{char c;int x; short y;};int f(struct S*p){return p->x^p->y^p->x^p->y;}',
'annotated':'struct S { int x __attribute__((deprecated));};int f(struct S*p){return p->x^p->x;}',
'vector':'typedef int V __attribute__((ext_vector_type(4))); struct S{int x;int y;};int f(struct S*p, V*v){return p->x ^ v->x ^ p->x ^ v->x;}',
'inactive':'union U{struct{int x;} a;int b;}; int f(union U *p){return p->a.x^p->a.x^p->b;}',
'noderef':'struct S{int x;};int f(struct S __attribute__((noderef))*p){return p->x^p->x;}',
}
with (out/'results.tsv').open('w') as fp:
 t=csv.writer(fp,delimiter='\t',lineterminator='\n');t.writerow(['name','mode','exit','stdout','stderr','object'])
 for k,body in cases.items():
  src=out/(k+'.c');src.write_text(pad+body+'\n');obj=out/'same.o'
  for mode,args in [('native',['-c']),('typed',['-fsyntax-only','--dump-typed','--dump-static']),('errs',['-fsyntax-only','-Weverything','-Werror']),('trans',['--check-transitions','-c']),('scalar',['--scalar','--dump-typed']),('tier',['--tier1','-c'])]:
   pairs=[]
   for tag,cc in zip(('base','source'),ccs):
    obj.unlink(missing_ok=True);r=subprocess.run([cc,'--lanes','1','-std=c23',*args,src,*(['-o',obj] if '-c' in args else [])],capture_output=True,timeout=90)
    dig=lambda data:hashlib.sha256(data).hexdigest()
    result=(r.returncode,dig(r.stdout),dig(r.stderr),dig(obj.read_bytes()) if obj.exists() else '-');pairs.append(result)
    for n in ['stdout','stderr']:(out/f'{k}.{mode}.{tag}.{n}.gz').write_bytes(gzip.compress(getattr(r,n),mtime=0))
   t.writerow([k,mode,*pairs[1]]);fp.flush();assert pairs[0]==pairs[1],(k,mode,pairs)
print(len(cases)*6,'extended member guard pairs')
