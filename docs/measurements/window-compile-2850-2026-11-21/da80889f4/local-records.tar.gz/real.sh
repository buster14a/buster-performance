#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs;source ../switch-local-args.sh
case $1 in sqlite) eval "args=($sqlite_arguments)";;
main) tree=$PWD/../pregraph-warning-study/compiler-source;args=(-march=native -I"$tree/src" -fwrapv -funsigned-char --predefines "$PWD/../proof-predefines.h" "$tree/src/buster/compiler/main.c");;esac
BUSTER_CONTROL_EARLY_RELEASE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_SOURCE_DIRTY_DIAGNOSTICS=1 BUSTER_SOURCE_BORROW_CHILDREN=1 BUSTER_SOURCE_FIRST_NODE=1 BUSTER_SOURCE_WRITE_COLUMNS=1 BUSTER_SOURCE_GROW_GRAPH=1 BUSTER_SOURCE_RETIRE_LISTS=1 BUSTER_SOURCE_FILE_DATA=1 BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_SOURCE_AUDIT=1 "$d/compiler" --lanes 1 -c "${args[@]}" -o "$d/$1.$2.o" > "$d/$1.$2.out" 2>"$d/$1.$2.stderr"
cmp "$d/$1.$2.o" "$d/../source-typed-study/$1.o"
