from pathlib import Path
r=Path(__file__).resolve().parent.parent/'live-checker-input/src/buster/compiler'
def rep(p,a,b):
 s=p.read_text();assert s.count(a)==1,a;p.write_text(s.replace(a,b))
p=r/'c_parser.c'
rep(p,'    void* live_forest;','''    void* live_forest;
    void* live_consumer;
    void (*live_checked_range)(Parser*, Preprocessor*, const ParseTokens*, const ParseTree*, uint32_t, uint32_t);''')
p=r/'c_parser_source_forest.c'
rep(p,'    ParseTokens tokens;','    Parser* owner;\n    ParseTokens tokens;')
rep(p,'    live->parsed = end;','''    if (live->owner->live_checked_range != NULL)
        live->owner->live_checked_range(live->owner, pp, &live->tokens, &live->tree, begin, end);
    live->parsed = end;''')
rep(p,'.scratch = &parser->scratch }','.owner = parser, .scratch = &parser->scratch }')
p=r/'c_check_input.c';s=p.read_text()
a=s.index('static __attribute__((noinline)) CheckInputTokenCounts check_input_count_tokens');b=s.index('    // The names of the syntax bits:',a)
s=s[:a]+'''static __attribute__((noinline)) CheckInputTokenCounts check_input_count_range(uint32_t count, const uint8_t* kinds, const uint8_t* roles,
                                                                              const uint32_t* token_names, const uint32_t* names, const uint8_t* groups,
                                                                              uint32_t name_count, uint8_t* syntax, uint8_t* visits)
{
'''+s[b:]
a=s.index('    const uint32_t count = parser->tokens.count;',a);b=s.index('    const __m512i role_tests_low',a);s=s[:a]+s[b:]
a=s.index('    const char* const vararg_spellings[]',s.index('static bool check_input_run('));b=s.index('    const uint64_t mark = scratch->length;',a);names=s[a:b]
names=names.replace('uint32_t names[BUSTER_CHECK_INPUT_COUNT_NAMES] =','const uint32_t first_names[] =').replace('uint8_t groups[BUSTER_CHECK_INPUT_COUNT_NAMES] =','const uint8_t first_groups[] =')
names=names.replace('    uint32_t name_count = 4;', '''    memcpy(names, first_names, sizeof(first_names));
    memcpy(groups, first_groups, sizeof(first_groups));
    uint32_t name_count = BUSTER_ARRAY_LENGTH(first_names);''')
s=s[:a]+s[b:]
a=s.index('    uint8_t* syntax = arena_push_array',a);b=s.index('    input->vla_capacity =',a)
s=s[:a]+'''    CheckLiveInput* live = parser->live_consumer;
    const bool published = live != NULL && live->owner == parser && !live->used && !live->failed &&
                           live->rows == count && live->roles != NULL && live->roles == parser->tree.roles &&
                           live->kinds == parser->tokens.kinds && pp == live->pp;
    uint8_t* syntax = published ? live->syntax : arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint8_t), 64);
    uint8_t* visits = published ? live->visits : syntax != NULL ? arena_push_array(scratch, (uint64_t)count + 1 + BUSTER_CHECK_VISITS_PADDING, sizeof(uint8_t), 64) : NULL;
    CheckInputTokenCounts counts;
    if (published)
    {
        counts = live->counts;
        live->used = true;
        if (getenv("BUSTER_LIVE_CHECKED_ORACLE") != NULL)
        {
            uint8_t* checked_syntax = arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint8_t), 64);
            uint8_t* checked_visits = arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint8_t), 64);
            if (!checked_syntax || !checked_visits) abort();
            const CheckInputTokenCounts ordinary = check_input_count_window(parser->tokens.kinds, parser->tree.roles, parser->tokens.names,
                                                                          count, pp, checked_syntax, checked_visits);
            if (!check_input_equal_counts(&ordinary, &counts) || memcmp(checked_syntax, syntax, count + 1) ||
                memcmp(checked_visits, visits, count + 1)) abort();
        }
        if (getenv("BUSTER_PARSE_LIVE_AUDIT") != NULL)
            fprintf(stderr, "live-check-input\\trows=%u\\tbefore-eof=%u\\twindows=%u\\n", count, live->before_eof, live->windows);
    }
    else counts = check_input_count_window(parser->tokens.kinds, parser->tree.roles, parser->tokens.names, count, pp, syntax, visits);
'''+s[b:]
a=s.index('// The columns of a value a token whose empty value is NONE')
new='''static __attribute__((unused)) CheckInputTokenCounts check_input_count_tokens(const Parser* parser, const uint32_t* names, const uint8_t* groups,
                                                                               uint32_t name_count, uint8_t* syntax, uint8_t* visits)
{
    return check_input_count_range(parser->tokens.count, parser->tokens.kinds, parser->tree.roles, parser->tokens.names,
                                   names, groups, name_count, syntax, visits);
}

static CheckInputTokenCounts check_input_count_window(const uint8_t* kinds, const uint8_t* roles, const uint32_t* token_names, uint32_t count,
                                                     Preprocessor* pp, uint8_t* syntax, uint8_t* visits)
{
    uint32_t names[BUSTER_CHECK_INPUT_COUNT_NAMES];
    uint8_t groups[BUSTER_CHECK_INPUT_COUNT_NAMES];
'''+names+'''    return check_input_count_range(count, kinds, roles, token_names, names, groups, name_count, syntax, visits);
}

typedef struct CheckLiveInput
{
    Parser* owner;
    Preprocessor* pp;
    const uint8_t* roles;
    const uint8_t* kinds;
    uint8_t* syntax;
    uint8_t* visits;
    CheckInputTokenCounts counts;
    uint32_t rows, before_eof, windows;
    bool used, failed;
} CheckLiveInput;

static bool check_input_equal_counts(const CheckInputTokenCounts* x, const CheckInputTokenCounts* y)
{
    return x->subscripts == y->subscripts && x->asms == y->asms && x->asm_groups == y->asm_groups && x->size_queries == y->size_queries &&
           x->vector_members == y->vector_members && x->pretty_function_name == y->pretty_function_name && x->operands == y->operands &&
           x->calls == y->calls && memcmp(x->groups, y->groups, sizeof(x->groups)) == 0;
}

// A closed grammar window ends on a declaration terminator or a body closer. Neither needs the
// following declaration's first token to classify its syntax or reader visit.
static void check_input_publish_window(Parser* parser, Preprocessor* pp, const ParseTokens* tokens, const ParseTree* tree, uint32_t begin, uint32_t end)
{
    CheckLiveInput* live = parser->live_consumer;
    if (live->failed || live->used || begin >= end) return;
    if (live->syntax == NULL)
    {
        live->syntax = arena_push_array(&parser->live_rows, (uint64_t)tokens->capacity + 1, sizeof(uint8_t), 64);
        live->visits = arena_push_array(&parser->live_rows, (uint64_t)tokens->capacity + 1 + BUSTER_CHECK_VISITS_PADDING, sizeof(uint8_t), 64);
        live->owner = parser;
        live->pp = pp;
        live->roles = tree->roles;
        live->kinds = tokens->kinds;
    }
    if (!live->syntax || !live->visits || begin != live->rows ||
        (begin && tokens->kinds[begin - 1] != PARSE_KIND_SEMI && tree->roles[begin - 1] != PARSE_ROLE_CLOSE_BODY))
    {
        live->failed = true;
        return;
    }
    const CheckInputTokenCounts window = check_input_count_window(tokens->kinds + begin, tree->roles + begin, tokens->names + begin,
                                                                end - begin, pp, live->syntax + begin, live->visits + begin);
    CheckInputTokenCounts* counts = &live->counts;
    counts->subscripts += window.subscripts;
    counts->asms += window.asms;
    counts->asm_groups += window.asm_groups;
    counts->size_queries += window.size_queries;
    counts->vector_members += window.vector_members;
    counts->pretty_function_name |= window.pretty_function_name;
    counts->operands += window.operands;
    counts->calls += window.calls;
    for (uint32_t i = 0; i < CHECK_INPUT_COUNT_GROUPS; i += 1) counts->groups[i] += window.groups[i];
    live->rows = end;
    live->windows += 1;
    if (pp->context_count != 0) live->before_eof = end;
}

'''
s=s[:a]+new+s[a:];p.write_text(s)
p=r/'c_checker_driver.c'
rep(p,'        if (getenv("BUSTER_PARSE_LIVE_FOREST") != NULL) parse_begin_source_forest(parser, pp);','''        CheckLiveInput live_input = { 0 };
        if (getenv("BUSTER_PARSE_LIVE_FOREST") != NULL)
        {
            parse_begin_source_forest(parser, pp);
            if (parser->live_forest != NULL && getenv("BUSTER_LIVE_CHECKED_INPUT") != NULL)
            {
                parser->live_checked_range = check_input_publish_window;
                parser->live_consumer = &live_input;
            }
        }''')
