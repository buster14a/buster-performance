struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){int m=3,n=4;typeof((m+n)*(a+b)) z=m*n;return _Generic((z+a+b),int:z+a+b,default:73)+sizeof(m+n);}
int main(void){return (unsigned)compute()%199;}
