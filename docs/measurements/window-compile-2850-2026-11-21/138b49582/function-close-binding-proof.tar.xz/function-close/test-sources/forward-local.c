int get(void){int x=7;return y+x;int y=3;}
