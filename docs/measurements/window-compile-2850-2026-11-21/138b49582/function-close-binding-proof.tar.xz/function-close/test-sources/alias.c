extern int datum; int get(void){return datum;}int source;extern int datum __attribute__((alias("source")));
