struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){typedef int V; V k=1;int n=3;{typedef long V;V a=n;{long n=7;k+=a*n;} k+=n;}return k+n+a+b+c;}
int main(void){return (unsigned)compute()%199;}
