struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){typedef int X;X k=a+b+c;{int X=a+b; k+=X*a+b;}return k+a+b+c;}
int main(void){return (unsigned)compute()%199;}
