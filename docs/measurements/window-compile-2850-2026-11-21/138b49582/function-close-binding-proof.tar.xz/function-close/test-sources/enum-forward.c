enum E:unsigned; int get(void){enum E *p=0;return !!p;}enum E:unsigned{X=1};
