struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){int k=({int a=8,b=2; a*b+c;});return a+b+c+k;}
int main(void){return (unsigned)compute()%199;}
