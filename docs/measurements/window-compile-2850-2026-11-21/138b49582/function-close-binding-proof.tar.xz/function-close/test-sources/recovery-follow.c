int a;int get(void){return a+typo_a;}int good(void){return a;}
