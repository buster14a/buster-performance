void *a;int get(int x){if(x)goto *a;a=&&done;goto done;done:return x;}
