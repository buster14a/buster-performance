struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){int x=a+b+c;return __builtin_popcount((unsigned)(x+a+b+c))+__builtin_choose_expr(1,a+b+c, b*c)+x;}
int main(void){return (unsigned)compute()%199;}
