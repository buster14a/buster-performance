struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){int m=3,n=4;int q[m+n];q[0]=a+b+c;return q[0]+(int)sizeof q+m*n;}
int main(void){return (unsigned)compute()%199;}
