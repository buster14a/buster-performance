struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){void *l=&&label;int x=a+b+c;goto *l;label:return x+a+b+c;}
int main(void){return (unsigned)compute()%199;}
