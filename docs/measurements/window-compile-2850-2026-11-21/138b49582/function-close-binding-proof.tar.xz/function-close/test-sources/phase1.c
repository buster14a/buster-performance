struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){int k=1+a;return ((a * 3) ^ b) + ((b * 3) ^ c) + ((c * 3) ^ a) + ((a * 3) ^ b) + ((b * 3) ^ a)+k;}
int main(void){return (unsigned)compute()%199;}
