struct S; extern struct S *p; int get(void){return p->x;} struct S{int x;};
