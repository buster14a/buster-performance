extern int a[]; int get(void){return sizeof a;} int a[4];
