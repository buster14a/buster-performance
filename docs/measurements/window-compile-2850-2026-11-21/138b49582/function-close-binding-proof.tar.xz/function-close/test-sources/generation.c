extern int (*p)[]; int get(int k){return (*p)[k];} int (*p)[4];
