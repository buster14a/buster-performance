struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){enum { X=2, Y=X+E };int k=Y;{enum { Y=4 };k+=Y;}return k+X+Y+E+a+b;}
int main(void){return (unsigned)compute()%199;}
