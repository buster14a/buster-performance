struct T; int get(int k){extern struct T *p; return p!=0;}struct T{int k;};struct T *p;
