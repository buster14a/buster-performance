int f(int); int get(void){return f(2);} int f(int a){return a;}
