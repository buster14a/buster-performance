struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){int t[]={ [E]=a+b+c, [1]=c*a+b };struct Pair s={.x=t[E],.y=a};return s.x+s.y+a+b+c;}
int main(void){return (unsigned)compute()%199;}
