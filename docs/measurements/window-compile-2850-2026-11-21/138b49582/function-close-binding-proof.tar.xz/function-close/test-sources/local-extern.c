int get(int k){extern int a[];return a[k];} int a[3];
