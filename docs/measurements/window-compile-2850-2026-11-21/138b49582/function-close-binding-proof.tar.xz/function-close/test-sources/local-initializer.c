int get(void){int a[]={sizeof a,1};return a[0];}
