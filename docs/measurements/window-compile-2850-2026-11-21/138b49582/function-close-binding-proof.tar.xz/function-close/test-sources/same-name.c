int k;int one(void){int k=4;{typedef int k;k v=2;}return k;}int two(void){return k;}
