int f();int get(void){return f(2);}int f(int x){return x;}
