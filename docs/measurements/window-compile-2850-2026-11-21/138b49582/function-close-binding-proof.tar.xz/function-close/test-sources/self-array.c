int get(void){int *a[]={(int*)a};return a[0]==(int*)a;}
