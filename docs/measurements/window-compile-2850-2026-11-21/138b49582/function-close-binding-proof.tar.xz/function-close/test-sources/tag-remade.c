struct S;extern struct S *p;int get(void){return p!=0;}struct S{int n;};
