int get(int x){__label__ done;goto done;done:return x+1;}
