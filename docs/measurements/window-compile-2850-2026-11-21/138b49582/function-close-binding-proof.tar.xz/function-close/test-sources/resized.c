struct S { int x; };extern struct S table[];struct S get(int i){return table[i];}struct S table[4];
