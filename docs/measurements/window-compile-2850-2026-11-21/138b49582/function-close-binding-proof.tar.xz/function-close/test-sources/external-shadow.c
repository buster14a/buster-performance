struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){extern int outside; int n=a+b+c; {int outside=n;b+=outside;} return outside+b+c+n;}
int main(void){return (unsigned)compute()%199;}
