typedef int A[]; extern A a; int get(int k){return a[k];} int a[3];
