extern int a[]; int get(int k){return a[k];} int a[4];
