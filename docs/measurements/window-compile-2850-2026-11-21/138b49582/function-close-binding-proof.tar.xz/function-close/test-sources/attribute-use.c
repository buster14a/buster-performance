static int unused;int get(int n){int v __attribute__((unused))=n;return v;}
