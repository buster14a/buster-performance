int a[]; int get(int n){return a[n];} int a[4];
