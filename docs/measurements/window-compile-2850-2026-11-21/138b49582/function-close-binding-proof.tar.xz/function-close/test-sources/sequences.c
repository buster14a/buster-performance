struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
int outside=7; int compute(void){int x=a+b+c;volatile int y=x;int z=b,cnt=c; x+=z*cnt;x+=y*y;return x+y+z+cnt;}
int main(void){return (unsigned)compute()%199;}
