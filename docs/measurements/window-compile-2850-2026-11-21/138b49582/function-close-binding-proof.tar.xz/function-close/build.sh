#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/../function-close-bindings"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >../binding-close-study/build.log 2>&1
cp ../default-integer-control/build/predefines.h build/predefines.h
cd ../switch-inputs
source ../switch-local-args.sh
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main; do
  var=${g}_arguments
  eval "args=(${!var})"
  o=$PWD/../binding-close-study
  rm -f "$o/$g.close"
  BUSTER_CLOSE_BINDING_WITNESS="$o/$g.close" ../function-close-bindings/build/compiler -c -o "$o/$g.o" "${args[@]}" >"$o/$g.out" 2>"$o/$g.err"
  ../default-integer-control/build/compiler -c -o "$o/$g.base.o" "${args[@]}" >"$o/$g.base.out" 2>"$o/$g.base.err"
  cmp "$o/$g.o" "$o/$g.base.o"
  cmp "$o/$g.out" "$o/$g.base.out"
  cmp "$o/$g.err" "$o/$g.base.err"
  map=$g
  if [[ $g == main ]]; then map=buster; fi
  python3 "$o/compare.py" "$o/$g.close" "$o/../proven-use-study/$map-upstream.answers" "$o/$g" >"$o/$g.summary"
done
python3 ../binding-close-study/adversarial.py >../binding-close-study/adversarial.log
python3 ../binding-close-study/canonical.py >../binding-close-study/canonical.log
