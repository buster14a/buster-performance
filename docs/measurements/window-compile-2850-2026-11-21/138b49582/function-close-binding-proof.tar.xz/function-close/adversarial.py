"""Exercise real function-close observations when later declarations, error recovery or scope may change an answer."""
from pathlib import Path
import csv, hashlib, os, subprocess
from compare import extract
s=Path(__file__).resolve().parent;w=s.parent
tree=w/'function-close-bindings/build/compiler'
base=w/'default-integer-control/build/compiler'
ref=w/'source-proven-binding-answers/build/compiler'
fixtures=s/'fixtures';fixtures.mkdir(exist_ok=True)
special={
'incomplete-object': 'extern int a[]; int get(int k){return a[k];} int a[4];',
'incomplete-bound': 'extern int a[]; int get(void){return sizeof a;} int a[4];',
'tentative-late': 'int a[]; int get(int n){return a[n];} int a[4];',
'array-typedef': 'typedef int A[]; extern A a; int get(int k){return a[k];} int a[3];',
'local-extern': 'int get(int k){extern int a[];return a[k];} int a[3];',
'local-initializer': 'int get(void){int a[]={sizeof a,1};return a[0];}',
'self-array': 'int get(void){int *a[]={(int*)a};return a[0]==(int*)a;}',
'redecl-func': 'int f(int); int get(void){return f(2);} int f(int a){return a;}',
'tag-remade': 'struct S;extern struct S *p;int get(void){return p!=0;}struct S{int n;};',
'later-field': 'struct S; extern struct S *p; int get(void){return p->x;} struct S{int x;};',
'computed-label': 'void *a;int get(int x){if(x)goto *a;a=&&done;goto done;done:return x;}',
'local-label': 'int get(int x){__label__ done;goto done;done:return x+1;}',
'same-name': 'int k;int one(void){int k=4;{typedef int k;k v=2;}return k;}int two(void){return k;}',
'enum-forward': 'enum E:unsigned; int get(void){enum E *p=0;return !!p;}enum E:unsigned{X=1};',
'attribute-use': 'static int unused;int get(int n){int v __attribute__((unused))=n;return v;}',
'recovery-follow': 'int a;int get(void){return a+typo_a;}int good(void){return a;}',
'redecl-in-body': 'struct T; int get(int k){extern struct T *p; return p!=0;}struct T{int k;};struct T *p;',
'old-decl': 'int f();int get(void){return f(2);}int f(int x){return x;}',
'forward-local': 'int get(void){int x=7;return y+x;int y=3;}',
'generation': 'extern int (*p)[]; int get(int k){return (*p)[k];} int (*p)[4];',
'alias': 'extern int datum; int get(void){return datum;}int source;extern int datum __attribute__((alias("source")));',
'resized': 'struct S { int x; };extern struct S table[];struct S get(int i){return table[i];}struct S table[4];',
}
for name,source in special.items():(fixtures/(name+'.c')).write_text(source+'\n')
preexisting=w/'proven-use-study/event-fixtures'
cases=list(fixtures.glob('*.c'))+sorted(p for p in preexisting.glob('*.c') if not p.name.startswith('padded-'))
hashval=lambda data:hashlib.sha256(data).hexdigest()
with (s/'adversarial.tsv').open('w',buffering=1) as fp:
 wr=csv.writer(fp,delimiter='\t')
 wr.writerow('source mode status native stdout stderr state bodies tokens before_decl before_type after_decl after_type'.split())
 for f in cases:
  for mode,flags in [('ordinary',[]),('warnings',['-Wall','-Wextra','-ferror-limit=0']),('c17',['-std=gnu17']),('scalar',['--scalar'])]:
   scratch=s/'adversarial-tmp';scratch.mkdir(exist_ok=True);obj=scratch/'unit.o';close=scratch/'close.bin';answer=scratch/'answer.bin'
   close.unlink(missing_ok=True);answer.unlink(missing_ok=True);results=[]
   for cc,extra in [(base,{}),(tree,{'BUSTER_CLOSE_BINDING_WITNESS':str(close)}),(ref,{'BUSTER_SOURCE_USE_ANSWERS':str(answer),'BUSTER_SOURCE_USE_REFERENCE':'1'})]:
    obj.unlink(missing_ok=True)
    r=subprocess.run([cc,*flags,'-c',f,'-o',obj],env={**os.environ,**extra},capture_output=True,timeout=90)
    results.append((r.returncode,r.stdout,r.stderr,obj.read_bytes() if obj.exists() else b''))
   assert results[0]==results[1]==results[2],(f,mode)
   st,out,err,blob=results[0]
   data=answer.read_bytes() if answer.exists() else b''
   words=int.from_bytes(data[:4],'little')
   shape='one' if data and len(data)==4+8*words and close.exists() else 'no-complete-unit'
   counts={}
   if shape=='one':
    counts=extract(close,answer,scratch/'compare')
    if counts['after_decl'] or counts['after_type']:
     (s/'changes').mkdir(exist_ok=True)
     (s/'changes'/(f.stem+'-'+mode+'.tsv')).write_bytes((scratch/'compare.changes.tsv').read_bytes())
   wr.writerow([f.name,mode,st,hashval(blob),hashval(out),hashval(err),shape,*[counts.get(k,0) for k in ['bodies','tokens','before_decl','before_type','after_decl','after_type']]])
print('completed',len(cases)*4)
