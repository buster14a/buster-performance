"""Decode real function-close records and compare source and projected arrays with final binding."""
import array
from collections import Counter
import csv
from pathlib import Path
import struct
import sys

def extract(path, expected, output):
    none = 2**32-1
    words = array.array('I', path.read_bytes())
    final = array.array('I', expected.read_bytes())
    if sys.byteorder != 'little':
        words.byteswap()
        final.byteswap()
    assert len(final) and len(final) == 1 + final[0]*2
    n = final[0]
    counts = Counter()
    records = []
    opened = set()
    changed = []
    p = 0
    while p < len(words):
        count, first, end, ev_first, ev_end = words[p:p+5]
        p += 5
        assert count == n and 0 <= first < end <= n and first not in opened
        opened.add(first)
        ln = end-first
        dec = words[p:p+ln]
        typ = words[p+ln:p+ln*2]
        p += ln*2
        base_dec, base_typ = dec[:], typ[:]
        events = {}
        while words[p] != none:
            token, event, namespace, handle, target, predicted, captured, kind = words[p:p+8]
            assert first <= token < end and ev_first <= event < ev_end
            counts['uses'] += 1
            counts['bound'] += handle != 0
            counts['ordinary'] += namespace == 0
            counts['repeat'] += token in events
            events[token] = (event, namespace, handle, target, predicted, captured, kind)
            dec[token-first] = target
            typ[token-first] = predicted
            p += 8
        p += 1
        a,b,c,d=0,0,0,0
        for j in range(ln):
            token = first+j
            fd, ft = final[1+token], final[1+n+token]
            a += base_dec[j] != fd
            b += base_typ[j] != ft
            if dec[j] != fd or typ[j] != ft:
                c += dec[j] != fd
                d += typ[j] != ft
                changed.append((first,token,base_dec[j],base_typ[j],dec[j],typ[j],fd,ft,*events.get(token,(None,)*7)))
        counts.update(bodies=1,tokens=ln,before_decl=a,before_type=b,after_decl=c,after_type=d,dirty_bodies=(c+d>0))
        records.append((first,end,ev_first,ev_end,len(events),a,b,c,d))
    with output.with_suffix('.bodies.tsv').open('w') as f:
        writer=csv.writer(f,delimiter='\t');writer.writerow('body end event_first event_end uses raw_decl raw_type projected_decl projected_type'.split());writer.writerows(records)
    with output.with_suffix('.changes.tsv').open('w') as f:
        writer=csv.writer(f,delimiter='\t');writer.writerow('body token raw_decl raw_type projected_decl projected_type final_decl final_type event namespace handle target type_at_close captured kind'.split());writer.writerows(changed)
    return counts

if __name__=='__main__':
    c=extract(*map(Path,sys.argv[1:4]))
    print(' '.join(f'{k}={v}' for k,v in c.items()))
