"""Join the untouched public checker's event and type outputs to final parser function ranges."""
from array import array
from bisect import bisect_right
from collections import Counter,defaultdict
from pathlib import Path
import csv,sys,struct,statistics
s=Path(__file__).resolve().parent;w=s.parent
def col(data,n=4):return array('I',data) if n==4 else data
for source,ref in [('sqlite','sqlite'),('main','buster')]:
 parsed=w/'byte-depth-study/source-depths'/('baseline-'+source+'.bin')
 roles=Path(str(parsed)+'.roles').read_bytes();parents=col(Path(str(parsed)+'.parents').read_bytes())
 bounds=[(i,parents[i]) for i,role in enumerate(roles) if role==52 and parents[i]<len(roles) and roles[parents[i]]==77]
 assert all(a<=b and (k==0 or bounds[k-1][1]<a) for k,(a,b) in enumerate(bounds))
 starts=[a for a,b in bounds]
 raw=(w/'source-use-run-study'/(ref+'-upstream.events')).read_bytes()
 visits,events,names,active=struct.unpack_from('<4I',raw);p=16+4*(names*3+active)
 cs=[]
 for n in [4,4,4,4,4,4,1,1]:
  cs.append(col(raw[p:p+events*n],n));p+=events*n
 assert p==len(raw)
 key,decl,point,end,prev,depth,operation,kind=cs
 facts=col((w/'proven-use-study'/(ref+'-upstream.answers')).read_bytes());n=facts[0];assert n==len(roles)
 target=facts[1:1+n];types=facts[1+n:]
 global_counts=Counter();by=[Counter() for _ in bounds];externals=[set() for _ in bounds];targets=[set() for _ in bounds]
 for event,op in enumerate(operation):
  if op!=1:continue
  token=decl[event]
  i=bisect_right(starts,token)-1
  if i<0 or bounds[i][1]<token:continue
  h=prev[event];c=by[i];c['uses']+=1
  if key[event]>=names:c['non_ordinary']+=1;continue
  c['ordinary']+=1
  if h==0:c['unbound']+=1;continue
  d=decl[h-1];c['bound']+=1;targets[i].add(d)
  if depth[h-1]==0:
   externals[i].add(d);c['file_scope']+=1
  else:c['local_scope']+=1
  if d==target[token]:c['target_equal']+=1
  if types[d]==types[token]:c['type_equal']+=1
  if d!=target[token] or types[d]!=types[token]:c['exception']+=1
 with (s/(source+'.dependencies.tsv')).open('w') as f:
  out=csv.writer(f,delimiter='\t');keys='uses ordinary bound unbound file_scope local_scope target_equal type_equal non_ordinary exception'.split()
  out.writerow(['body','end','unique_targets','unique_file_targets',*keys])
  for i,(a,b) in enumerate(bounds):
   c=by[i];global_counts.update(c);out.writerow([a,b,len(targets[i]),len(externals[i]),*[c[k] for k in keys]])
 exceptional=sum(c['exception']!=0 for c in by)
 print(source,'bodies',len(bounds),'body tokens',sum(b+1-a for a,b in bounds),global_counts,'except bodies',exceptional,'p50/max unique file targets',statistics.median(map(len,externals)),max(map(len,externals)))
