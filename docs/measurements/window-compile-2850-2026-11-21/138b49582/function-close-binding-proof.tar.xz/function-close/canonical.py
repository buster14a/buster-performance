from pathlib import Path
import csv,hashlib,os,subprocess
from compare import extract
s=Path(__file__).resolve().parent;w=s.parent;cs=w/'pregraph-warning-study/compiler-source'
expected=next(r for r in csv.DictReader((w/'proven-use-study/events.tsv').open(),delimiter='\t') if r['source']=='buster' and r['mode']=='default')['output_sha256']
args=['-march=native','-I'+str(cs/'src'),'-fwrapv','-funsigned-char','--predefines',w/'proof-predefines.h',cs/'src/buster/compiler/main.c']
close=s/'buster-canonical.close';close.unlink(missing_ok=True)
for tree,n,env in [('default-integer-control','reference',{}),('function-close-bindings','candidate',{'BUSTER_CLOSE_BINDING_WITNESS':str(close)})]:
 f=s/('buster-canonical-'+n+'.o')
 r=subprocess.run([w/tree/'build/compiler','-c',*args,'-o',f],env={**os.environ,**env},capture_output=True)
 assert (r.returncode,r.stdout,r.stderr)==(0,b'',b''),(r.returncode,r.stdout,r.stderr[:200])
 actual=hashlib.sha256(f.read_bytes()).hexdigest();assert actual==expected,(n,expected,actual)
counts=extract(close,w/'proven-use-study/buster-upstream.answers',s/'buster-canonical')
(s/'buster-canonical.summary').write_text(' '.join(f'{k}={v}' for k,v in counts.items())+'\n')
print(expected,counts)
