from pathlib import Path
import csv,hashlib,io,re,subprocess,tarfile
s=Path(__file__).resolve().parent;w=s.parent;t=w/'source-census-forms'
def rows(p): return list(csv.DictReader(p.open(),delimiter='\t'))
general=rows(s/'oracle.tsv');assert len(general)==4304 and all(x['same']=='1' for x in general)
frozen=[x for f in (s/'corpus').glob('*.tsv') for x in rows(f)];assert len(frozen)==4116 and all(x['same']=='1' for x in frozen)
events=rows(s/'events.tsv');assert len(events)==376
for name in ['sqlite','buster']:
 e=next(x for x in events if x['source']==name and x['mode']=='default')
 assert hashlib.sha256((w/'source-use-run-study'/(name+'-upstream.events')).read_bytes()).hexdigest()==e['event_sha256']
for name in ['sqlite','main']:
 assert (s/(name+'.recipes')).read_bytes()==(w/'final-roles-study/recipe-repair'/(name+'.final.recipes')).read_bytes()
checks=sum(int(re.search(r'test-checker: (\d+) checks, 0 failures',(s/f'checker-{i}.log').read_text())[1]) for i in range(1,9))
four=rows(s/'four-way.tsv');assert len(four)==192
tip=subprocess.check_output(['git','-C',t,'rev-parse','HEAD'],text=True).strip()
base='40ae34f9d77afc42face58eff3338b7b1d1ba469';out=s/'single-source-census.tar.xz'
with tarfile.open(out,'w:xz',preset=2) as tar:
 def add(n,dat):
  i=tarfile.TarInfo('source-census/'+n);i.size=len(dat);tar.addfile(i,io.BytesIO(dat))
 for pat in ['*.py','*.sh','prefix-oracle.c','prefix-oracle.log','live-prefixes.log','*.recipes','sqlite-*.bin','events.log','counter.txt','events.tsv','oracle.tsv','four-way.tsv','four-way.log','pairs.log','pmu.log','target.log','*.stages','local-ab.tsv','pmu.tsv','target-pairs.tsv','sqlite-stage-pairs.tsv','checker-*.log','corpus/*.tsv']:
  for p in sorted(s.glob(pat)):add(p.relative_to(s).as_posix(),p.read_bytes())
 add('implementation.patch',subprocess.check_output(['git','-C',t,'diff','--binary',base,tip]))
 add('dco.txt',subprocess.check_output([w/'buster/build/dco','audit','--base',base,'--head',tip],cwd=t))
 trials=[('40ae34f9d','default-integer-control'),('a137ff13c','packed-declarations-main'),('14e1d43f0','classified-source-use-runs'),('5356f9267','source-census-forms')]
 add('versions.tsv',''.join(f'{subprocess.check_output(["git","-C",w/tr,"rev-parse","HEAD"],text=True).strip()}\t{hashlib.sha256((w/tr/"build/compiler").read_bytes()).hexdigest()}\n' for rev,tr in trials).encode())
 add('README.md',f'''# Declaration recipes and ordinary identifier classification from one source census

The signed candidate {tip} derives both the packed declaration recipe and the ordinary identifier marks in the input reader's single full token census. The recipe producer carries the role and kind masks across one 64-token tile and masks terminal lanes. The guarded scalar recipe oracle checked 716,136 live SQLite slots plus 6,912 alignment, shape and tail cases. The live SQLite and Buster recipe arrays are byte-identical to the independent late parser repair observations. Default SQLite admits 2,548 named function definitions, 8,365 local declarations, 6,385 definition parameters, 3,566 prototype parameters and 71,472 ordinary identifier uses across 19,628 name runs.

All 376 source-policy binding probes, 4,304 directed source/policy comparisons with supported warning flags, 4,116 frozen source/policy comparisons, and {checks:,} checker assertions passed. Complete objects, statuses, diagnostics, upstream binding stream SHA-256 values and independent Clang executable results are retained in the records. The four-compiler design uses 32 interleaved physical-core wall rounds and 16 user cycle/instruction rounds on the local Ryzen 9 7940HS. All four emitted the same complete SQLite object. The comparison includes stock, declaration-only, name-only and combined binaries. Raw and paired comparisons are in four-way.tsv and four-way.log.
'''.encode())
print(tip,checks,hashlib.sha256(out.read_bytes()).hexdigest())
