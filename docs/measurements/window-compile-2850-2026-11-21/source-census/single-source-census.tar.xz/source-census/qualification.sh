#!/bin/bash
set -eu
cd "$(dirname "$0")"
until [[ -s sqlite.parent.o ]]; do if grep -qiE '^FAILED:|ninja: build stopped' build.log 2>/dev/null; then exit 1; fi; sleep 10; done
bash live-prefixes.sh >live-prefixes.log 2>&1
CORES_TITLE='2850 four-way ordinary declaration and use source producer controls' CORES_LINK='https://github.com/buster14a/buster/issues/2850' cores -n 1 -- python3 four-way.py >four-way.log 2>&1
