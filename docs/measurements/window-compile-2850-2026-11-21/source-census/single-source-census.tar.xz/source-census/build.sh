#!/bin/bash
set -eu
cd "$(dirname "$0")/../source-census-forms"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >../source-census-study/build.log 2>&1
cp ../default-integer-control/build/predefines.h build/predefines.h
cd ../switch-inputs
source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
BUSTER_DECLARATION_CENSUS=1 BUSTER_SOURCE_USE_CENSUS=1 ../source-census-forms/build/compiler -c -o ../source-census-study/sqlite.candidate.o "${args[@]}" >../source-census-study/sqlite.out 2>../source-census-study/counter.txt
../default-integer-control/build/compiler -c -o ../source-census-study/sqlite.parent.o "${args[@]}" >../source-census-study/parent.out 2>../source-census-study/parent.err
cmp ../source-census-study/sqlite.candidate.o ../source-census-study/sqlite.parent.o
python3 ../source-census-study/events.py >../source-census-study/events.log 2>&1
python3 ../source-census-study/oracle.py >../source-census-study/oracle.log 2>&1
python3 ../source-census-study/local_pairs.py >../source-census-study/pairs.log 2>&1
python3 ../source-census-study/target_pairs.py >../source-census-study/target.log 2>&1
parent=$PWD/../default-integer-control/build/compiler
new=$PWD/../source-census-forms/build/compiler
out=$PWD/../source-census-study/corpus
mkdir -p "$out"
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main lua musl; do var=${g}_arguments; eval "args=(${!var})"; python3 ../default-object-qa/pair.py "$out" "$g" "$parent" "$new" "${args[@]}"; done
python3 ../source-census-study/pmu.py >../source-census-study/pmu.log 2>&1
cd ../source-census-forms
for part in {1..8}; do ./build/compiler test-checker --seed 2850 --part "$part/8" >"../source-census-study/checker-$part.log" 2>&1; done
