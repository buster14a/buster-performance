#!/bin/bash
set -eu
cd "$(dirname "$0")/../switch-inputs"
w=$(cd .. && pwd);d=$w/source-census-study
source ../switch-local-args.sh
tree=$w/pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $w/proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main;do
 var=${g}_arguments;eval "args=(${!var})"
 BUSTER_SOURCE_CENSUS_PREFIXES="$d/$g.recipes" "$w/source-census-forms/build/compiler" -c -o "$d/$g.live.o" "${args[@]}"
 cmp "$d/$g.recipes" "$w/final-roles-study/recipe-repair/$g.final.recipes"
 sha256sum "$d/$g.recipes"
done
