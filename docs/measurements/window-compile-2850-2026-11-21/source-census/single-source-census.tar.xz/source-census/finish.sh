#!/bin/bash
set -eu
cd "$(dirname "$0")"
until grep -q 'checks, 0 failures' checker-8.log 2>/dev/null && grep -q 'combined vs uses cycles median' four-way.log 2>/dev/null; do sleep 12; done
python3 package.py
