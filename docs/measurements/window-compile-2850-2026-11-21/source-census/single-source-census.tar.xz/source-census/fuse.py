from pathlib import Path
w=Path(__file__).resolve().parent.parent;t=w/'source-census-forms/src/buster/compiler'
for name in ['c_check_input.c','c_check_attested_test.c']:
 p=t/name;s=p.read_text();s=''.join(line for line in s.splitlines(keepends=True) if not line.startswith(('<<<<<<<','=======','>>>>>>>')));p.write_text(s)
p=t/'c_check_input.c';s=p.read_text()
a=s.index('// Emit a syntactic recipe');b=s.index('// Read a complete scalar',a);old=s[a:b]
start=old.index('        const unsigned __int128 specifier =');finish=old.index('        following_specifiers = specifiers;',start)
body=''.join(line[4:] for line in old[start:finish].splitlines(keepends=True))
body=body.replace('prefixes + first','output').replace('following_specifiers','following.specifiers').replace('following_stars','following.stars').replace('following_names','following.names').replace('following_delimiters','following.delimiters')
for field in ['specifiers','stars','names','delimiters']:
 import re
 body=re.sub(r'(?<!\.)\b'+field+r'\b','current.'+field,body)
mstart=old.index('        const uint64_t specifiers =');mend=old.index('        const unsigned __int128 specifier =',mstart)
masks=''.join(line[4:] for line in old[mstart:mend].splitlines(keepends=True))
helper='''// Classify complete syntactic name prefixes as adjacent source-census groups become available. The
// single pending group carries the seven-token maximum lookahead without reading the parser tree twice.
typedef struct CheckInputPrefixMasks
{
    uint64_t specifiers;
    uint64_t stars;
    uint64_t names;
    uint64_t delimiters;
} CheckInputPrefixMasks;

static inline __attribute__((always_inline)) void check_input_prefix_block(uint8_t* output, __mmask64 lanes, CheckInputPrefixMasks current, CheckInputPrefixMasks following)
{
'''+body+'''}

static inline __attribute__((always_inline)) void check_input_prefix_group(uint8_t* output, uint32_t first, uint32_t count, __mmask64 lanes, __m512i kinds, __m512i roles,
                                                                           CheckInputPrefixMasks* pending)
{
'''+masks+'''    const CheckInputPrefixMasks current = { .specifiers = specifiers, .stars = stars, .names = names, .delimiters = delimiters };
    if (first != 0)
    {
        check_input_prefix_block(output + first - 64, UINT64_MAX, *pending, current);
    }
    if (count - first <= 64)
    {
        check_input_prefix_block(output + first, lanes, current, (CheckInputPrefixMasks){ 0 });
    }
    *pending = current;
}

'''
s=s[:a]+helper+s[b:]
s=s.replace('uint8_t* visits, bool classify_operands)\n','uint8_t* visits, bool classify_operands, uint8_t* named_prefixes)\n')
a=s.index('    int64_t attribute_depth = 0;',s.index('CheckInputTokenCounts check_input_count_tokens('));s=s[:a]+'    CheckInputPrefixMasks pending_prefixes = { 0 };\n'+s[a:]
a=s.index('        const __m512i role = roles != 0 ?',a);a=s.index('\n',a)+1
s=s[:a]+'''        if (named_prefixes != NULL)
        {
            check_input_prefix_group(named_prefixes, token, count, lanes, kind, role, &pending_prefixes);
        }
'''+s[a:]
a=s.index('    const bool source_use_runs = fresh_output');b=s.index('    input->vla_capacity',a)
s=s[:a]+'''    const bool ordinary_source = fresh_output && complete_translation_unit && deferred == NULL && deferred_tokens == NULL && attested == NULL && parser->errors == 0 &&
                                 parser->recovered_types == NULL && !parser->options.scalar && pp->options.published_unused_only && !pp->options.predefines.debug &&
                                 !pp->options.predefines.debug_modules && !pp->options.node_window && !pp->options.node_window_constants;
    const bool source_use_runs = ordinary_source && getenv("BUSTER_SOURCE_USE_REFERENCE") == NULL && parser->language.standard >= 1999;
    uint8_t* named_prefixes = ordinary_source && visits != NULL && parser->tree.roles != NULL ? BUSTER_ARENA_PUSH_ARRAY(scratch, uint8_t, count) : NULL;
    const CheckInputTokenCounts counts = check_input_count_tokens(parser, names, groups, name_count, syntax, visits, source_use_runs, named_prefixes);
    const char* prefix_output = named_prefixes != NULL ? getenv("BUSTER_SOURCE_CENSUS_PREFIXES") : NULL;
    if (prefix_output != NULL)
    {
        FILE* file = fopen(prefix_output, "wb");
        if (file == NULL || fwrite(named_prefixes, 1, count, file) != count || fclose(file) != 0)
        {
            abort();
        }
    }
'''+s[b:]
a=s.index('        .plain_declarations = fresh_output');b=s.index('        .source_use_runs = source_use_runs',a);s=s[:a]+'''        .plain_declarations = named_prefixes != NULL,
        .plain_prefixes = named_prefixes,
'''+s[b:]
a=s.index('    if (valid && reader.plain_declarations)',b-500);b=s.index('\n    }',a)+len('\n    }\n');s=s[:a]+s[b:];p.write_text(s)
for name in ['c_check_input_scan_test.c','c_check_overload_test.c']:
 p=t/name;s=p.read_text();lines=s.splitlines(keepends=True);matches=0
 for i,line in enumerate(lines):
  if 'check_input_count_tokens(' in line and ', false);' in line:lines[i]=line.replace(', false);',', false, NULL);');matches+=1
 assert matches==1;p.write_text(''.join(lines))
