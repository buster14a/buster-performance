#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>
#include <sys/mman.h>
#include <unistd.h>
typedef struct { struct { const uint8_t *kinds; uint32_t count; } tokens; struct { const uint8_t *roles; } tree; } Parser;
#define PARSE_KIND_END 0
#define PARSE_KIND_UNKNOWN 1
#define PARSE_KIND_IDENTIFIER 2
#define PARSE_KIND_NUMBER 3
#define PARSE_KIND_CHARACTER 4
#define PARSE_KIND_STRING 5
#define PARSE_KIND_L_SQUARE 6
#define PARSE_KIND_R_SQUARE 7
#define PARSE_KIND_L_PAREN 8
#define PARSE_KIND_R_PAREN 9
#define PARSE_KIND_L_BRACE 10
#define PARSE_KIND_R_BRACE 11
#define PARSE_KIND_PERIOD 12
#define PARSE_KIND_ELLIPSIS 13
#define PARSE_KIND_AMP 14
#define PARSE_KIND_AMPAMP 15
#define PARSE_KIND_AMPEQUAL 16
#define PARSE_KIND_STAR 17
#define PARSE_KIND_STAREQUAL 18
#define PARSE_KIND_PLUS 19
#define PARSE_KIND_PLUSPLUS 20
#define PARSE_KIND_PLUSEQUAL 21
#define PARSE_KIND_MINUS 22
#define PARSE_KIND_ARROW 23
#define PARSE_KIND_MINUSMINUS 24
#define PARSE_KIND_MINUSEQUAL 25
#define PARSE_KIND_TILDE 26
#define PARSE_KIND_EXCLAIM 27
#define PARSE_KIND_EXCLAIMEQUAL 28
#define PARSE_KIND_SLASH 29
#define PARSE_KIND_SLASHEQUAL 30
#define PARSE_KIND_PERCENT 31
#define PARSE_KIND_PERCENTEQUAL 32
#define PARSE_KIND_LESS 33
#define PARSE_KIND_LESSLESS 34
#define PARSE_KIND_LESSEQUAL 35
#define PARSE_KIND_LESSLESSEQUAL 36
#define PARSE_KIND_GREATER 37
#define PARSE_KIND_GREATERGREATER 38
#define PARSE_KIND_GREATEREQUAL 39
#define PARSE_KIND_GREATERGREATEREQUAL 40
#define PARSE_KIND_CARET 41
#define PARSE_KIND_CARETEQUAL 42
#define PARSE_KIND_PIPE 43
#define PARSE_KIND_PIPEPIPE 44
#define PARSE_KIND_PIPEEQUAL 45
#define PARSE_KIND_QUESTION 46
#define PARSE_KIND_COLON 47
#define PARSE_KIND_SEMI 48
#define PARSE_KIND_EQUAL 49
#define PARSE_KIND_EQUALEQUAL 50
#define PARSE_KIND_COMMA 51
#define PARSE_KIND_TYPE 52
#define PARSE_KIND_STRUCT 53
#define PARSE_KIND_ENUM 54
#define PARSE_KIND_QUALIFIER 55
#define PARSE_KIND_ATOMIC 56
#define PARSE_KIND_CALLING_CONVENTION 57
#define PARSE_KIND_STORAGE 58
#define PARSE_KIND_TYPEDEF 59
#define PARSE_KIND_ATTRIBUTE 60
#define PARSE_KIND_ASM 61
#define PARSE_KIND_ALIGNAS 62
#define PARSE_KIND_TYPEOF 63
#define PARSE_KIND_SIZEOF 64
#define PARSE_KIND_TYPE_ARGUMENT 65
#define PARSE_KIND_GENERIC 66
#define PARSE_KIND_STATIC_ASSERT 67
#define PARSE_KIND_EXTENSION 68
#define PARSE_KIND_REAL_IMAG 69
#define PARSE_KIND_LABEL 70
#define PARSE_KIND_IF 71
#define PARSE_KIND_ELSE 72
#define PARSE_KIND_SWITCH 73
#define PARSE_KIND_CASE 74
#define PARSE_KIND_DEFAULT 75
#define PARSE_KIND_WHILE 76
#define PARSE_KIND_DO 77
#define PARSE_KIND_FOR 78
#define PARSE_KIND_GOTO 79
#define PARSE_KIND_CONTINUE 80
#define PARSE_KIND_BREAK 81
#define PARSE_KIND_RETURN 82
#define PARSE_ROLE_NONE 0
#define PARSE_ROLE_ERROR 1
#define PARSE_ROLE_OPERAND 2
#define PARSE_ROLE_MEMBER 3
#define PARSE_ROLE_STRING_NEXT 4
#define PARSE_ROLE_QUALIFIER_LEFT 5
#define PARSE_ROLE_LEAF_RIGHT 6
#define PARSE_ROLE_SPECIFIER 7
#define PARSE_ROLE_TAG 8
#define PARSE_ROLE_PREFIX 9
#define PARSE_ROLE_POSTFIX 10
#define PARSE_ROLE_MEMBER_OPERATOR 11
#define PARSE_ROLE_MULTIPLICATIVE 12
#define PARSE_ROLE_ADDITIVE 13
#define PARSE_ROLE_SHIFT 14
#define PARSE_ROLE_RELATIONAL 15
#define PARSE_ROLE_EQUALITY 16
#define PARSE_ROLE_BITWISE_AND 17
#define PARSE_ROLE_BITWISE_XOR 18
#define PARSE_ROLE_BITWISE_OR 19
#define PARSE_ROLE_LOGICAL_AND 20
#define PARSE_ROLE_LOGICAL_OR 21
#define PARSE_ROLE_ASSIGN 22
#define PARSE_ROLE_RANGE 23
#define PARSE_ROLE_BITFIELD 24
#define PARSE_ROLE_COMMA 25
#define PARSE_ROLE_RETURN 26
#define PARSE_ROLE_ASSOCIATION 27
#define PARSE_ROLE_SEPARATOR 28
#define PARSE_ROLE_ASM_COLON 29
#define PARSE_ROLE_TERMINATOR 30
#define PARSE_ROLE_ELSE 31
#define PARSE_ROLE_DO 32
#define PARSE_ROLE_LABEL 33
#define PARSE_ROLE_OPEN_GROUP 34
#define PARSE_ROLE_OPEN_CALL 35
#define PARSE_ROLE_OPEN_FUNCTION 36
#define PARSE_ROLE_OPEN_CAST 37
#define PARSE_ROLE_OPEN_COMPOUND 38
#define PARSE_ROLE_OPEN_SIZEOF 39
#define PARSE_ROLE_OPEN_SPECIFIER 40
#define PARSE_ROLE_OPEN_ATTRIBUTE 41
#define PARSE_ROLE_OPEN_ATTRIBUTE_SPECIFIER 42
#define PARSE_ROLE_OPEN_ATTRIBUTE_LEFT 43
#define PARSE_ROLE_OPEN_ATTRIBUTE_RIGHT 44
#define PARSE_ROLE_OPEN_ATTRIBUTE_LIST 45
#define PARSE_ROLE_OPEN_ASM 46
#define PARSE_ROLE_OPEN_KEYWORD 47
#define PARSE_ROLE_OPEN_CONDITION 48
#define PARSE_ROLE_OPEN_FOR 49
#define PARSE_ROLE_OPEN_SUBSCRIPT 50
#define PARSE_ROLE_OPEN_BLOCK 51
#define PARSE_ROLE_OPEN_BODY 52
#define PARSE_ROLE_OPEN_STRUCT 53
#define PARSE_ROLE_OPEN_ENUM 54
#define PARSE_ROLE_OPEN_INITIALIZER 55
#define PARSE_ROLE_OPEN_COMPOUND_BODY 56
#define PARSE_ROLE_OPEN_TERNARY 57
#define PARSE_ROLE_OPEN_CASE 58
#define PARSE_ROLE_CLOSE_GROUP 59
#define PARSE_ROLE_CLOSE_CALL 60
#define PARSE_ROLE_CLOSE_FUNCTION 61
#define PARSE_ROLE_CLOSE_CAST 62
#define PARSE_ROLE_CLOSE_COMPOUND 63
#define PARSE_ROLE_CLOSE_SIZEOF 64
#define PARSE_ROLE_CLOSE_SPECIFIER 65
#define PARSE_ROLE_CLOSE_ATTRIBUTE 66
#define PARSE_ROLE_CLOSE_ATTRIBUTE_SPECIFIER 67
#define PARSE_ROLE_CLOSE_ATTRIBUTE_LEFT 68
#define PARSE_ROLE_CLOSE_ATTRIBUTE_RIGHT 69
#define PARSE_ROLE_CLOSE_ATTRIBUTE_LIST 70
#define PARSE_ROLE_CLOSE_ASM 71
#define PARSE_ROLE_CLOSE_KEYWORD 72
#define PARSE_ROLE_CLOSE_CONDITION 73
#define PARSE_ROLE_CLOSE_FOR 74
#define PARSE_ROLE_CLOSE_SUBSCRIPT 75
#define PARSE_ROLE_CLOSE_BLOCK 76
#define PARSE_ROLE_CLOSE_BODY 77
#define PARSE_ROLE_CLOSE_STRUCT 78
#define PARSE_ROLE_CLOSE_ENUM 79
#define PARSE_ROLE_CLOSE_INITIALIZER 80
#define PARSE_ROLE_CLOSE_COMPOUND_BODY 81
#define PARSE_ROLE_CLOSE_TERNARY 82
#define PARSE_ROLE_CLOSE_CASE 83
static uint64_t check_input_scan_all(uint32_t first, uint32_t count)
{
    return _bzhi_u64(UINT64_MAX, count - first < 64 ? count - first : 64);
}

typedef struct CheckInputPrefixMasks
{
    uint64_t specifiers;
    uint64_t stars;
    uint64_t names;
    uint64_t delimiters;
} CheckInputPrefixMasks;

static inline __attribute__((always_inline)) void check_input_prefix_block(uint8_t* output, __mmask64 lanes, CheckInputPrefixMasks current, CheckInputPrefixMasks following)
{
    const unsigned __int128 specifier = current.specifiers | ((unsigned __int128)following.specifiers << 64);
    const unsigned __int128 star = current.stars | ((unsigned __int128)following.stars << 64);
    const unsigned __int128 name = (current.names | ((unsigned __int128)following.names << 64)) &
                                   ((current.delimiters | ((unsigned __int128)following.delimiters << 64)) >> 1);
    const unsigned __int128 single_pointer = star & (name >> 1);
    const unsigned __int128 double_pointer = star & (single_pointer >> 1);
    uint64_t prefix = current.specifiers;
    __m512i result = _mm512_setzero_si512();
    #pragma clang loop unroll(full)
    for (uint32_t length = 1; length <= 4; length += 1)
    {
        result = _mm512_mask_set1_epi8(result, prefix & (uint64_t)(name >> length), (char)length);
        result = _mm512_mask_set1_epi8(result, prefix & (uint64_t)(single_pointer >> length), (char)(8 + length));
        result = _mm512_mask_set1_epi8(result, prefix & (uint64_t)(double_pointer >> length), (char)(16 + length));
        prefix &= (uint64_t)(specifier >> length);
    }
    _mm512_mask_storeu_epi8(output, lanes, result);
}

static inline __attribute__((always_inline)) void check_input_prefix_group(uint8_t* output, uint32_t first, uint32_t count, __mmask64 lanes, __m512i kinds, __m512i roles,
                                                                           CheckInputPrefixMasks* pending)
{
    const uint64_t specifiers = _mm512_mask_cmpeq_epi8_mask(lanes, roles, _mm512_set1_epi8(PARSE_ROLE_SPECIFIER));
    const uint64_t stars = _mm512_mask_cmpeq_epi8_mask(lanes, kinds, _mm512_set1_epi8(PARSE_KIND_STAR));
    const uint64_t names = _mm512_cmpeq_epi8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_OPERAND)) &
                           _mm512_mask_cmpeq_epi8_mask(lanes, kinds, _mm512_set1_epi8(PARSE_KIND_IDENTIFIER));
    const uint64_t delimiters = lanes & (_mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PARSE_KIND_SEMI)) |
                                         _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PARSE_KIND_COMMA)) |
                                         _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PARSE_KIND_EQUAL)) |
                                         _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PARSE_KIND_R_PAREN)) |
                                         _mm512_cmpeq_epi8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_OPEN_FUNCTION)));
    const CheckInputPrefixMasks current = { .specifiers = specifiers, .stars = stars, .names = names, .delimiters = delimiters };
    if (first != 0)
    {
        check_input_prefix_block(output + first - 64, UINT64_MAX, *pending, current);
    }
    if (count - first <= 64)
    {
        check_input_prefix_block(output + first, lanes, current, (CheckInputPrefixMasks){ 0 });
    }
    *pending = current;
}


static void check_input_named_prefixes(const Parser* p,uint8_t* out){
 CheckInputPrefixMasks pending={0};
 for(uint32_t i=0;i<p->tokens.count;i+=64){
  __mmask64 lanes=check_input_scan_all(i,p->tokens.count);
  __m512i k=_mm512_maskz_loadu_epi8(lanes,p->tokens.kinds+i),r=_mm512_maskz_loadu_epi8(lanes,p->tree.roles+i);
  check_input_prefix_group(out,i,p->tokens.count,lanes,k,r,&pending);
 }
}

static uint8_t scalar(const uint8_t* kinds, const uint8_t* roles, uint32_t at, uint32_t count) {
 uint32_t j=at;while(j<count && j-at<4 && roles[j]==PARSE_ROLE_SPECIFIER)j++;
 if(j==at)return 0;
 uint32_t k=j;while(k<count && k-j<2 && kinds[k]==PARSE_KIND_STAR)k++;
 if(k+1>=count || kinds[k]!=PARSE_KIND_IDENTIFIER || roles[k]!=PARSE_ROLE_OPERAND)return 0;
 const uint8_t next=kinds[k+1];
 return next==PARSE_KIND_COMMA || next==PARSE_KIND_SEMI || next==PARSE_KIND_R_PAREN || next==PARSE_KIND_EQUAL || roles[k+1]==PARSE_ROLE_OPEN_FUNCTION ? ((j-at)|((k-j)<<3)):0;
}
static uint8_t *guard(uint32_t n) {
 size_t p=sysconf(_SC_PAGESIZE),room=((n+p-1)/p)*p;
 uint8_t *base=mmap(NULL,room+p,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 if(base==MAP_FAILED || mprotect(base+room,p,PROT_NONE))abort();
 return base+room-n;
}
static void unguard(uint8_t *ptr,uint32_t n) {
 size_t p=sysconf(_SC_PAGESIZE),room=((n+p-1)/p)*p;munmap(ptr+n-room,room+p);
}
static uint32_t verified;
static uint32_t verify(const uint8_t*k,const uint8_t*r,uint32_t n) {
 uint8_t *kk=guard(n),*rr=guard(n),*out=guard(n);
 memcpy(kk,k,n);memcpy(rr,r,n);memset(out,255,n);
 Parser p={.tokens={.kinds=kk,.count=n},.tree={.roles=rr}};check_input_named_prefixes(&p,out);
 uint32_t emits=0;
 for(uint32_t j=0;j<n;j++){
  const uint8_t want=scalar(kk,rr,j,n);
  if(out[j]!=want){fprintf(stderr,"mismatch count=%u at=%u got=%u want=%u\n",n,j,out[j],want);abort();}
  emits+=out[j]!=0;
 }
 unguard(kk,n);unguard(rr,n);unguard(out,n);verified+=n;return emits;
}
int main(int argc,char**argv) {
 if(argc!=4)return 2;
 uint32_t n=strtoul(argv[3],NULL,10);uint8_t*k=malloc(n),*r=malloc(n);
 FILE *kf=fopen(argv[1],"rb"),*rf=fopen(argv[2],"rb");if(!kf||!rf||fread(k,1,n,kf)!=n||fread(r,1,n,rf)!=n)return 1;
 printf("sqlite tokens=%u emitted-prefix-bytes=%u\n",n,verify(k,r,n));
 uint8_t ks[200],rs[200];unsigned cases=0;
 for(unsigned shift=0;shift<64;shift++){for(unsigned sp=1;sp<=4;sp++){for(unsigned ptr=0;ptr<=2;ptr++){for(unsigned tail=0;tail<=8;tail++){
   memset(ks,0,sizeof ks);memset(rs,0,sizeof rs);unsigned i=shift;for(unsigned t=0;t<sp;t++)rs[i++]=PARSE_ROLE_SPECIFIER;for(unsigned t=0;t<ptr;t++)ks[i++]=PARSE_KIND_STAR;
   ks[i]=PARSE_KIND_IDENTIFIER;rs[i++]=PARSE_ROLE_OPERAND;ks[i++]=PARSE_KIND_SEMI;
   unsigned len=i+tail;if(tail<3)len=i-2+tail;verify(ks,rs,len);cases++;
 }}}}
 printf("alignment-shape-tail-cases=%u scalar-checked-output-bytes=%u guard-pages=both-inputs-and-output\n",cases,verified);return 0;
}
