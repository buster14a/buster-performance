from pathlib import Path
import csv,subprocess as sp,random,time,statistics,re,os,hashlib
w=Path(__file__).resolve().parent.parent;d=w/'source-census-study';c=[('base',w/'default-integer-control/build/compiler'),('candidate',w/'source-census-forms/build/compiler')];rng=random.Random(2850);metric=re.compile(rb'^time-stage\tcheck-input\t([0-9.]+)',re.M)
uses=' + '.join(['a*b+c','b*c+a','c*a+b']*5)
forms={'admitted':lambda i:f'static int p{i}(int a,int b,int c){{return {uses};}}', 'named':lambda i:f'extern int q{i}(const S*,T,int,char**);', 'mixed':lambda i:f'static int p{i}(int a,int b,int c){{int d=a+b;{{int a=b+c;d+=a;}}return ({uses})+d;}}' };num=700
with (d/'target-pairs.tsv').open('w',buffering=1) as stream:
 wr=csv.writer(stream,delimiter='\t');wr.writerow(['mode','pair','order','base_ms','candidate_ms','base_input_ms','candidate_input_ms']);
 for mode,form in forms.items():
  f=d/('prototypes-'+mode+'.c');f.write_text('typedef struct S { int k; } S; typedef unsigned long T;\n'+'\n'.join(form(i) for i in range(num))+'\nint main(void){return 0;}\n');data=[];args=['-c',f,'-o',d/'synth.o']
  reference=sp.run([c[0][1],*args],capture_output=True,timeout=60);assert reference.returncode==0,reference.stderr
  ref_object=(d/'synth.o').read_bytes()
  ordinary=sp.run([c[1][1],*args],env=dict(os.environ,BUSTER_SOURCE_USE_CENSUS="1"),capture_output=True,timeout=60);assert ordinary.returncode==0 and ref_object==(d/'synth.o').read_bytes(),ordinary.stderr
  print(mode, 'native-hash',hashlib.sha256(ref_object).hexdigest(),ordinary.stderr.decode().strip(),flush=True)
  for j in range(19):
   order=c.copy();rng.shuffle(order);v={}
   for label,cc in order:
    st=time.perf_counter_ns();r=sp.run([cc,'--time-stages',*args],capture_output=True,timeout=60);elapsed=(time.perf_counter_ns()-st)/1e6;assert r.returncode==0,r.stderr;rs=metric.search(r.stderr);assert rs,r.stderr;v[label]=(elapsed,float(rs[1]));
   if j>0:
    a,b=v['base'],v['candidate'];wr.writerow([mode,j,','.join(x[0] for x in order),a[0],b[0],a[1],b[1]]);data.append((b[0]-a[0],b[1]-a[1]))
  print(mode,'n',len(data),'paired-delta-wall-ms',statistics.median(x[0] for x in data),'paired-delta-check-input-ms',statistics.median(x[1] for x in data),flush=True)
