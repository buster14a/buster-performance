#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;new=$PWD/../tier0-entry-representation/build/compiler;ref=$PWD/../main-fbef-clean/build/compiler
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
for m in ref new;do exe=${!m};"$exe" -c "${args[@]}" -o "$d/$m.o" > "$d/$m.stdout" 2> "$d/$m.stderr";done
for ext in o stdout stderr;do cmp "$d/ref.$ext" "$d/new.$ext";done
sha256sum "$d/ref.o" "$d/new.o"
