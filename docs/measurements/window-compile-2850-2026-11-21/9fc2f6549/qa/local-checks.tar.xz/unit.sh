#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;cd ../tier0-entry-representation
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build/compiler test-tier0 --seed 2850 --count 300 --cross-check --cross-count 12 --clang "$(command -v clang)" > "$d/unit.log" 2>&1
