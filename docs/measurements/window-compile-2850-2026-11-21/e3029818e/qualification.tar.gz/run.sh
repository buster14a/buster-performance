#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; cd ../expression-presence
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/
cd ../switch-inputs; source ../switch-local-args.sh
tree=$PWD/../pregraph-warning-study/compiler-source;main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for unit in sqlite main lua musl; do
 v=${unit}_arguments; eval "args=(${!v})"; python3 "$d/qualification.py" "$unit" "${args[@]}"
done
