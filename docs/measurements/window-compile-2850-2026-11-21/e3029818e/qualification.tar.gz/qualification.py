import csv,hashlib,os,subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent
ref=(p/'../main-fbef-clean/build/compiler').resolve();exe=(p/'../expression-presence/build/compiler').resolve()
target=sys.argv[1];opts=[a for a in sys.argv[2:] if not a.endswith('.c')];files=[a for a in sys.argv[2:] if a.endswith('.c')]
with (p/(target+'.tsv')).open('w',buffering=1) as f:
 t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow(['file','policy','exit','reference_object','ordinary_equal','published_equal','oracle_equal'])
 for src in files:
  for pol,flags in [('default',[]),('all',['-Weverything']),('strict',['-Wall','-Wextra','-Werror']),('suppress',['-w']),('no-attest',['--attested=off'])]:
   result=[]
   for arm,binary,marks in [('base',ref,{}),('ordinary',exe,{}),('packed',exe,{'BUSTER_EXPRESSION_PRESENCE':'1'}),('oracle',exe,{'BUSTER_EXPRESSION_PRESENCE':'1','BUSTER_EXPRESSION_PRESENCE_ORACLE':'1'})]:
    obj=p/(target+'.o');obj.unlink(missing_ok=True)
    r=subprocess.run([binary,'--lanes','1','-c',*opts,*flags,src,'-o',obj],env=os.environ|marks,capture_output=True)
    result.append((r.returncode,hashlib.sha256(obj.read_bytes()).hexdigest() if obj.exists() else '',r.stdout,r.stderr))
    if target in ['sqlite','main'] or result[0]!=result[-1]:(p/(target+'-'+Path(src).stem+'-'+pol+'-'+arm+'.stderr')).write_bytes(r.stderr)
   a=result[0];t.writerow([src,pol,*a[:2],*(int(r==a) for r in result[1:])])
