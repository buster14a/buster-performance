"""Exercise future declarations capable of changing prior incomplete, deduced, reconstructed or linked types."""
from pathlib import Path
import csv,hashlib,importlib.util,os,subprocess
s=Path(__file__).resolve().parent;w=s.parent
spec=importlib.util.spec_from_file_location('compare',w/'binding-close-study/compare.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
cases={
'tentative-incomplete':'int arr[];int get(int k){return arr[k];}',
'tentative-only-object-size':'int arr[];int get(void){return __builtin_object_size(arr,0);}',
'late-explicit-array':'extern int arr[];int get(int k){int *p=arr;return p[k];}int arr[37];',
'late-initialized-array':'extern int arr[];int get(int k){return arr[k];}int arr[]={1,2,3,4};',
'late-visible-size':'extern int arr[];int a(void){return __builtin_object_size(arr,0);}int arr[37];int b(void){return __builtin_object_size(arr,0);}',
'late-restrict':'extern int *ptr;int f(int k){return ptr[k];}int *restrict ptr;',
'pointer-array-target':'extern int (*v)[];int get(int k){return (*v)[k];}int (*v)[47];',
'scope-extern':'int get(int k){extern int v[];return v[k];}int v[8];',
'unspecified-prototype':'int f();int get(void){return f(2);}int f(int value){return value;}',
'knr-definition':'extern int f();int get(void){return f(2);}int f(x) int x;{return x;}',
'variadic-conflict':'int f(int);int get(void){return f(2);}int f(int x,...){return x;}',
'incomplete-tag':'struct S;extern struct S *p;int get(void){return p!=0;}struct S{int x;};struct S *p;',
'late-enum':'enum E:unsigned;extern enum E k;int f(void){return (unsigned)k;}enum E:unsigned{A=7};enum E k;',
'auto-init-body':'typedef int T;int get(int k){__auto_type a=k;return a+1;}',
'array-initializer':'int get(void){int *p[]={(int*)p};return p[0]==(int*)p;}',
'local-tentative-shadows':'int a[];int get(int k){extern int a[];{int a[3]={2};k+=a[0];}return a[k];}',
'typo-follow':'int datum;int f(void){return datm+datum;}int g(void){return datum;}',
'offset-attributes':'extern int value;int get(void){return value;}int backing;extern int value __attribute__((alias("backing")));',
'enum-and-shadow':'enum E{A=1};int get(void){enum {A=3};int k=A;return k;}enum E val=A;',
}
rect=s/'late-edges';rect.mkdir(exist_ok=True)
pad=''.join(f'typedef int filler_{j};\n' for j in range(2050))
hashval=lambda b:hashlib.sha256(b).hexdigest()
with (s/'late-edges.tsv').open('w',buffering=1) as f:
 out=csv.writer(f,delimiter='\t');out.writerow('source mode rc elf stderr final_bytes final_sha256 bodies tokens residual_decl residual_type'.split())
 for name,source in cases.items():
  src=rect/(name+'.c');src.write_text(source+'\n'+pad)
  for mode,flags in [('ordinary',[]),('warnings',['-Wall','-Wextra','-ferror-limit=0']),('gnu17',['-std=gnu17'])]:
   output=rect/'unit.o';close=rect/'early.bin';answer=rect/'final.bin';ref=rect/'reference.bin';results=[]
   for file in [close,answer,ref]:file.unlink(missing_ok=True)
   for tree,env in [('default-integer-control',{}),('source-proven-binding-answers',{'BUSTER_SOURCE_USE_ANSWERS':str(ref),'BUSTER_SOURCE_USE_REFERENCE':'1'}),('function-close-all-bindings',{'BUSTER_SOURCE_USE_ANSWERS':str(answer),'BUSTER_CHECKED_BODY_BINDINGS':str(close)})]:
    output.unlink(missing_ok=True);run=subprocess.run([w/tree/'build/compiler',*flags,'-c',src,'-o',output],env={**os.environ,**env},capture_output=True,timeout=60)
    results.append((run.returncode,run.stdout,run.stderr,output.read_bytes() if output.exists() else b''))
   assert results[0]==results[1]==results[2],(name,mode)
   a=answer.read_bytes() if answer.exists() else b'';r=ref.read_bytes() if ref.exists() else b'';assert a==r,(name,mode,'final')
   n=int.from_bytes(a[:4],'little');c={}
   if close.exists() and a and len(a)==4+8*n:
    c=module.extract(close,answer,rect/(name+'-'+mode))
   rc,stdout,stderr,elf=results[0]
   out.writerow([name,mode,rc,hashval(elf),hashval(stderr),len(a),hashval(a),*[c.get(k,0) for k in ['bodies','tokens','after_decl','after_type']]])
print('late source edge comparisons',len(cases)*3)
