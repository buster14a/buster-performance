# Source-ordered ordinary identifier use records

Baseline `40ae34f9d77afc42face58eff3338b7b1d1ba469` and candidate `b692332ec4497ff05a58fe7fa9c8bd41ded1e26b` were built with pinned Clang 23.1.4 on the Ryzen 9 7940HS. At each actual function close the candidate publishes missing declared types and declaration identities for bound ordinary identifier uses, including linked functions, objects, aggregates and enumeration constants. It retains each new use's original TypeId and event identity, suppresses ambiguous same-token writers and reconciles signatures at the canonical binding handoff. The raw records under source-boundary are the actual reader columns after writing a function's results, before reading any following declaration. The section actual-close.log records all observed residual differences per workload. All eight event columns, active heads, visit tallies and both final per-source-token binding answers match the GDB captures from untouched 40ae34f9d77afc42face58eff3338b7b1d1ba469. The raw certificate preserves 450 focused source-policy comparisons.

Source | Functions projected | Uses projected | All uses | Events | Bytes | Stream SHA-256
--- | --- | --- | --- | --- | --- | ---
sqlite | 2674 | 96872 | 97600 | 167474 | 4666856 | bb92830c050d0d1bbb1aa816fd0265e1dba703b92839b0bd783902dc58344d87
buster | 8667 | 154780 | 217102 | 357701 | 10281578 | be6a49dce7157aefe857b7c2705413fd79cd0fa55fcc8afc6745b74cbb5f65a8
phase-matrix | 577 | 39681 | 39681 | 46597 | 1228570 | cc84518fbeb649e10de8563f93d099f3cddf67d7afec26977b23de97fe9e87ed

The adversarial suite ran 450 source-policy pairs using warning, optimization-eligibility and recovery controls, including a 576-function alignment/run-length matrix. It compared complete output bytes, diagnostics and statuses with the upstream compiler. 32 successful linked executables also ran against pinned Clang. SQLite, Buster, 34 Lua files and 1,336 musl files added 4,116 individual source/policy pairs. The declaration-family cross-check adds 3,096 comparisons with warnings checked using supported `-Wall -Wextra`. The checker shards totaled 850,926 assertions.

The reserved physical-core study used native bare `-c` on SQLite on a Ryzen 9 7940HS. `local-ab.tsv`, `pmu.tsv`, `target-pairs.tsv` and the scripts retain all median components and synthetic positive, refused and mixed source cases. Files `pairs.log`, `pmu.log` and `target.log` summarize those samples.
