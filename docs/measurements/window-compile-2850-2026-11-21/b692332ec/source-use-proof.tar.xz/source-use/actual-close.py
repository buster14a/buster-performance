from pathlib import Path
import csv,hashlib,importlib.util,os,subprocess
s=Path(__file__).resolve().parent;w=s.parent;f=w/'binding-close-study/compare.py'
spec=importlib.util.spec_from_file_location('compare',f);compare=importlib.util.module_from_spec(spec);spec.loader.exec_module(compare)
records=list(csv.DictReader((w/'proven-use-study/events.tsv').open(),delimiter='\t'))
cs=w/'pregraph-warning-study/compiler-source';sqlite=w/'switch-inputs/sqlite/sqlite3.c'
for name,args in [('sqlite',['-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I'+str(sqlite.parent),sqlite]),('buster',['-march=native','-I'+str(cs/'src'),'-fwrapv','-funsigned-char','--predefines',w/'proof-predefines.h',cs/'src/buster/compiler/main.c'])]:
 expected=next(r for r in records if r['source']==name and r['mode']=='default')
 obj=s/(name+'.in-place.o');close=s/(name+'.in-place.close');close.unlink(missing_ok=True)
 result=subprocess.run([w/'function-close-all-bindings/build/compiler','-c',*args,'-o',obj],env={**os.environ,'BUSTER_CHECKED_BODY_BINDINGS':str(close),'BUSTER_SOURCE_USE_CENSUS':'1'},capture_output=True)
 assert result.returncode==0 and hashlib.sha256(obj.read_bytes()).hexdigest()==expected['output_sha256'],(name,result.returncode,result.stderr[:200])
 counts=compare.extract(close,w/'proven-use-study'/(name+'-upstream.answers'),s/(name+'-direct'))
 print(name,result.stderr.decode().strip(),counts,flush=True)
