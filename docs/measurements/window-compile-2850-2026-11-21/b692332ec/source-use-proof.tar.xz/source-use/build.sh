#!/bin/bash
set -eu
cd "$(dirname "$0")/../function-close-all-bindings"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >../close-all-study/build.log 2>&1
cp ../default-integer-control/build/predefines.h build/predefines.h
cd ../switch-inputs
source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
BUSTER_SOURCE_USE_CENSUS=1 ../function-close-all-bindings/build/compiler -c -o ../close-all-study/sqlite.candidate.o "${args[@]}" >../close-all-study/sqlite.out 2>../close-all-study/counter.txt
../default-integer-control/build/compiler -c -o ../close-all-study/sqlite.parent.o "${args[@]}" >../close-all-study/parent.out 2>../close-all-study/parent.err
cmp ../close-all-study/sqlite.candidate.o ../close-all-study/sqlite.parent.o
python3 ../close-all-study/actual.py >../close-all-study/actual.log
python3 ../close-all-study/late-edges.py >../close-all-study/late-edges.log
python3 ../close-all-study/events.py >../close-all-study/events.log 2>&1
cmp ../close-all-study/sqlite-candidate.answers ../proven-use-study/sqlite-upstream.answers
cmp ../close-all-study/buster-candidate.answers ../proven-use-study/buster-upstream.answers
python3 ../close-all-study/oracle.py >../close-all-study/oracle.log 2>&1
python3 ../close-all-study/local_pairs.py >../close-all-study/pairs.log 2>&1
python3 ../close-all-study/target_pairs.py >../close-all-study/target.log 2>&1
parent=$PWD/../default-integer-control/build/compiler
new=$PWD/../function-close-all-bindings/build/compiler
out=$PWD/../close-all-study/corpus
mkdir -p "$out"
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main lua musl; do var=${g}_arguments; eval "args=(${!var})"; python3 ../default-object-qa/pair.py "$out" "$g" "$parent" "$new" "${args[@]}"; done
python3 ../close-all-study/pmu.py >../close-all-study/pmu.log 2>&1
cd ../function-close-all-bindings
for part in {1..8}; do ./build/compiler test-checker --seed 2850 --part "$part/8" >"../close-all-study/checker-$part.log" 2>&1; done
