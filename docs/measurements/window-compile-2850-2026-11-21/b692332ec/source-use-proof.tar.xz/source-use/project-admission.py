from pathlib import Path
from array import array
from collections import Counter
import csv
s=Path(__file__).resolve().parent;w=s.parent
for source,phase,ref in [('sqlite','sqlite','sqlite'),('buster','buster-canonical','buster')]:
 words=array('I',(w/'binding-close-study'/(phase+'.close')).read_bytes());final=array('I',(w/'proven-use-study'/(ref+'-upstream.answers')).read_bytes());n=final[0];p=0;totals=Counter()
 with (s/(source+'-expected.tsv')).open('w') as file:
  out=csv.writer(file,delimiter='\t');out.writerow('body end uses writes untouched_captures residual_declarations residual_types'.split())
  while p<len(words):
   count,start,end,lo,hi=words[p:p+5];p+=5;ln=end-start
   ds=words[p:p+ln];ts=words[p+ln:p+ln*2];p+=2*ln
   a=[];seen=Counter()
   while words[p]!=2**32-1:
    token,event,ns,handle,decl,type,captured,kind=words[p:p+8];p+=8;a.append((token,event,ns,handle,decl,type,captured,kind));seen[token]+=1
   p+=1
   accepted=old=0
   for token,event,ns,handle,decl,type,captured,kind in a:
    j=token-start
    if seen[token]==1 and handle and handle<=event and ns==0 and kind!=0 and ds[j]==2**32-1 and ts[j]==0 and type:
     ds[j]=decl;ts[j]=type;accepted+=1
    else:old+=1
   delta_d=sum(ds[j]!=final[1+start+j] for j in range(ln));delta_t=sum(ts[j]!=final[1+n+start+j] for j in range(ln));totals.update(bodies=1,uses=len(a),writes=accepted,preserved=old,decl_diff=delta_d,type_diff=delta_t)
   out.writerow([start,end,len(a),accepted,old,delta_d,delta_t])
 print(source,totals)
