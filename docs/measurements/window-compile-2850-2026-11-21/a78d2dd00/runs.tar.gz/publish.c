static bool check_live_integer(Preprocessor* pp, const ParseTokens* tokens, uint32_t at, uint32_t* value)
{
    const uint32_t source = parse_source_index(tokens, at);
    if (source >= pp->output.count) return false;
    const uint8_t kind = pp->output.kinds[source];
    if (kind == BUSTER_PP_KIND_INTEGER)
    {
        *value = pp->output.values[source];
        return true;
    }
    const uint32_t location = pp->output.locations[source];
    const uint32_t length = pp->output.values[source] - location;
    if (kind != C_TOKEN_NUMERIC_CONSTANT || length == 0 || length > 10) return false;
    uint8_t buffer[24];
    const uint8_t* spelling = NULL;
    const uint32_t size = pp_spelling(pp, kind, pp->output.values[source], location, buffer, &spelling);
    if (size == 0 || (size > 1 && spelling[0] == '0')) return false;
    uint64_t number = 0;
    for (uint32_t i = 0; i < size; i += 1)
    {
        if (spelling[i] < '0' || spelling[i] > '9') return false;
        number = number * 10 + spelling[i] - '0';
    }
    *value = (uint32_t)number;
    return number <= INT32_MAX;
}

// The mapper stores only expressions for which the real PP has already published a concrete
// value. The native emitter later compares its selected records before reusing these bytes.
static void check_live_leaf_window(CheckLiveInput* state, Parser* parser, Preprocessor* pp, const ParseTokens* tokens,
                                   const ParseTree* tree, uint32_t begin, uint32_t end)
{
    if (!state->native_leaves || !x86_encoder_initialized || pp->context_count == 0) return;
    for (uint32_t block = begin; block < end; block += 64)
    {
        const uint32_t length = end - block < 64 ? end - block : 64;
        const uint64_t lanes = _bzhi_u64(UINT64_MAX, length);
        const __m512i roles = _mm512_maskz_loadu_epi8(lanes, tree->roles + block);
        uint64_t closes = _mm512_mask_cmpeq_epi8_mask(lanes, roles, _mm512_set1_epi8(PARSE_ROLE_CLOSE_BODY));
        while (closes != 0)
        {
            const uint32_t close = block + (uint32_t)__builtin_ctzll(closes);
            closes &= closes - 1;
            if (close < begin + 4 || tokens->kinds[close - 1] != PARSE_KIND_SEMI ||
                tokens->kinds[close - 2] != PARSE_KIND_NUMBER || tokens->kinds[close - 3] != PARSE_KIND_RETURN ||
                tree->roles[close - 4] != PARSE_ROLE_OPEN_BODY || tree->parents[close - 4] != close) continue;
            uint32_t value = 0;
            if (!check_live_integer(pp, tokens, close - 2, &value)) continue;
            if (state->leaf_count == state->leaf_capacity)
            {
                const uint32_t capacity = state->leaf_capacity ? 2 * state->leaf_capacity : 16;
                CheckLiveLeaf* leaves = BUSTER_ARENA_PUSH_ARRAY(&parser->live_rows, CheckLiveLeaf, capacity);
                if (leaves == NULL) return;
                if (state->leaf_count != 0) memcpy(leaves, state->leaves, state->leaf_count * sizeof(*leaves));
                state->leaves = leaves;
                state->leaf_capacity = capacity;
            }
            X86Instruction instructions[2] = {
                { .form = value == 0 ? X86_FORM_XOR_RM32_R32 : X86_FORM_MOV_R32_IMM32, .immediate = (int32_t)value },
                { .form = X86_FORM_RET },
            };
            uint8_t encoded[BUSTER_X86_ENCODER_CAPACITY(2)];
            const int64_t n = x86_encode(instructions, 2, encoded, sizeof(encoded), NULL, NULL);
            if (n <= 0 || n > 16) continue;
            CheckLiveLeaf* leaf = state->leaves + state->leaf_count++;
            *leaf = (CheckLiveLeaf){ .opening = close - 4, .size = (uint32_t)n };
            memcpy(leaf->instructions, instructions, sizeof(instructions));
            memcpy(leaf->bytes, encoded, (size_t)n);
        }
    }
}

