// An exact instruction-record match discharges conversion, ABI, target and prologue
// dependencies for this shape. The byte producer ran while original source contexts were open.
static const CheckLiveLeaf* check_program_live_leaf(const CheckEmitRun* run, uint32_t body, const EmittedCode* code)
{
    const Parser* parser = run->program->parser;
    const CheckLiveInput* live = parser != NULL ? parser->live_consumer : NULL;
    if (live == NULL || !live->native_leaves || !live->used || live->owner != parser || !live->leaf_count ||
        code->count != 2 || code->reference_count || code->branch_count || code->label_count || code->literal_count) return NULL;
    const uint32_t opening = run->program->bodies[body].opening;
    uint32_t low = 0, high = live->leaf_count;
    while (low < high)
    {
        const uint32_t middle = low + (high - low) / 2;
        if (live->leaves[middle].opening < opening) low = middle + 1;
        else high = middle;
    }
    if (low == live->leaf_count || live->leaves[low].opening != opening) return NULL;
    const CheckLiveLeaf* leaf = live->leaves + low;
    if (memcmp(leaf->instructions, code->records, sizeof(leaf->instructions)) != 0)
    {
        if (live->audit_leaves) fprintf(stderr, "live-leaf-decline\topening=%u\twant=%u,%u\tactual=%u,%u\n",
                                       opening, leaf->instructions[0].form, leaf->instructions[1].form, code->records[0].form, code->records[1].form);
        return NULL;
    }
    if (live->audit_leaves) fprintf(stderr, "live-leaf-emitted\topening=%u\tbytes=%u\n", opening, leaf->size);
    return leaf;
}

