#!/bin/bash
set -eu
cd "$(dirname "$0")/../source-proven-binding-answers"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >../proven-use-study/build.log 2>&1
cp ../default-integer-control/build/predefines.h build/predefines.h
cd ../switch-inputs
source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
BUSTER_SOURCE_USE_CENSUS=1 ../source-proven-binding-answers/build/compiler -c -o ../proven-use-study/sqlite.candidate.o "${args[@]}" >../proven-use-study/sqlite.out 2>../proven-use-study/counter.txt
../default-integer-control/build/compiler -c -o ../proven-use-study/sqlite.parent.o "${args[@]}" >../proven-use-study/parent.out 2>../proven-use-study/parent.err
cmp ../proven-use-study/sqlite.candidate.o ../proven-use-study/sqlite.parent.o
python3 ../proven-use-study/events.py >../proven-use-study/events.log 2>&1
python3 ../proven-use-study/oracle.py >../proven-use-study/oracle.log 2>&1
python3 ../proven-use-study/local_pairs.py >../proven-use-study/pairs.log 2>&1
python3 ../proven-use-study/target_pairs.py >../proven-use-study/target.log 2>&1
parent=$PWD/../default-integer-control/build/compiler
new=$PWD/../source-proven-binding-answers/build/compiler
out=$PWD/../proven-use-study/corpus
mkdir -p "$out"
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main lua musl; do var=${g}_arguments; eval "args=(${!var})"; python3 ../default-object-qa/pair.py "$out" "$g" "$parent" "$new" "${args[@]}"; done
python3 ../proven-use-study/pmu.py >../proven-use-study/pmu.log 2>&1
cd ../source-proven-binding-answers
for part in {1..8}; do ./build/compiler test-checker --seed 2850 --part "$part/8" >"../proven-use-study/checker-$part.log" 2>&1; done
