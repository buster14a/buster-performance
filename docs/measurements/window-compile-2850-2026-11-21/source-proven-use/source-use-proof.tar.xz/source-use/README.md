# Source-ordered ordinary identifier use records

Baseline `40ae34f9d77afc42face58eff3338b7b1d1ba469` and candidate `4163a78ca54d39aecca6fefd3319f188c5b32ebe` were built with pinned Clang 23.1.4 on the Ryzen 9 7940HS. The reader batches source-ordered use events whose live binding handles and semantic readiness were proved before emission. All eight canonical CBindings columns, live heads, active declarations, and the source visit count are present in its binary event oracle. GDB independently read the SQLite and Buster streams at the end of the existing resolver walk in the untouched reference executable. The raw byte streams, compiled field offsets, GDB programs, and extraction script are retained in `untouched-control`. The candidate's ordinary reader and its disabled control both reproduced the reference stream exactly.

The implementation retains the declaration token from each source-proved live handle. At the regular end-of-unit binding handoff it merges these contiguous runs with general uses and reads the declaration's then-final type, retaining use-local captures as the canonical consumer does. The solved columns contain a declaration token and a TypeId for every input token. The candidate exactly reproduced both untouched GDB artifacts (SQLite 5,729,092 bytes and Buster 19,468,508 bytes). This experiment consumed final state after the last declaration in the translation unit.

Source | Runs | Uses in runs | All uses | Events | Bytes | Stream SHA-256
--- | --- | --- | --- | --- | --- | ---
sqlite | 19628 | 71472 | 97600 | 167474 | 4666856 | bb92830c050d0d1bbb1aa816fd0265e1dba703b92839b0bd783902dc58344d87
buster | 29414 | 111111 | 217102 | 357701 | 10281578 | be6a49dce7157aefe857b7c2705413fd79cd0fa55fcc8afc6745b74cbb5f65a8
phase-matrix | 3200 | 38141 | 39681 | 46597 | 1228570 | cc84518fbeb649e10de8563f93d099f3cddf67d7afec26977b23de97fe9e87ed

The adversarial suite ran 450 source-policy pairs using warning, optimization-eligibility and recovery controls, including a 576-function alignment/run-length matrix. It compared complete output bytes, diagnostics and statuses with the upstream compiler. 32 successful linked executables also ran against pinned Clang. SQLite, Buster, 34 Lua files and 1,336 musl files added 4,116 individual source/policy pairs. The declaration-family cross-check adds 3,096 comparisons with warnings checked using supported `-Wall -Wextra`. The checker shards totaled 850,926 assertions.

The reserved physical-core study used native bare `-c` on SQLite on a Ryzen 9 7940HS. `local-ab.tsv`, `pmu.tsv`, `target-pairs.tsv` and the scripts retain all median components and synthetic positive, refused and mixed source cases. Files `pairs.log`, `pmu.log` and `target.log` summarize those samples.
