from pathlib import Path
import csv,hashlib,statistics,subprocess,time,os
study=Path(__file__).resolve().parent;w=study.parent
programs={'stock':'default-integer-control','source_close':'unpublished-source-bindings','same_binary_reference':'implicit-bound-use-rows','filtered':'implicit-bound-use-rows'}
def env(k):
 return {**os.environ,'BUSTER_SOURCE_USE_REFERENCE':'1'} if k=='same_binary_reference' else os.environ
cc={k:w/v/'build/compiler' for k,v in programs.items()};sqlite=w/'switch-inputs/sqlite/sqlite3.c';obj=study/'four-way.o'
args=['-c','-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I'+str(sqlite.parent),sqlite,'-o',obj]
names=list(programs);pattern=((0,1,3,2),(1,2,0,3),(2,3,1,0),(3,0,2,1))
signature=None;data={}
for k in names:
 r=subprocess.run([cc[k],*args],capture_output=True,env=env(k));assert r.returncode==0,r.stderr
 payload=(r.stdout,r.stderr,hashlib.sha256(obj.read_bytes()).digest())
 if signature is None:signature=payload
 assert signature==payload,k
print('all four ordinary ELFs',signature[-1].hex(),flush=True)
with (study/'four-way.tsv').open('w',buffering=1) as out:
 write=csv.writer(out,delimiter='\t',lineterminator='\n');write.writerow(['metric','round','slot','compiler','wall_ms','instructions','cycles'])
 for metric,rounds in [('wall',32),('pmu',16)]:
  for i in range(rounds):
   seq=pattern[i%4] if i//4%2==0 else pattern[i%4][::-1]
   for slot,j in enumerate(seq):
    k=names[j];cmd=[cc[k],*args]
    if metric=='pmu':cmd=['perf','stat','--no-big-num','-x,','-e','{instructions:u,cycles:u}','--',*cmd]
    start=time.perf_counter_ns();r=subprocess.run(cmd,capture_output=True,env=env(k),timeout=90);elapsed=(time.perf_counter_ns()-start)/1e6;assert r.returncode==0,r.stderr
    instr=cyc=''
    if metric=='pmu':
     received={x.split(',')[2]:int(x.split(',')[0]) for x in r.stderr.decode().splitlines() if ',,instructions:u,' in x or ',,cycles:u,' in x}
     instr=received['instructions:u'];cyc=received['cycles:u']
    data[metric,i,k]=(elapsed,instr,cyc);write.writerow([metric,i,slot,k,elapsed,instr,cyc])
  for k in names[:-1]:
   for col,heading in ([(0,'wall_ms')] if metric=='wall' else [(1,'instructions'),(2,'cycles')]):
    ds=[data[metric,i,'filtered'][col]-data[metric,i,k][col] for i in range(rounds)]
    print('filtered vs',k,heading,'median',statistics.median(ds),'wins',sum(d<0 for d in ds),'rounds',rounds,flush=True)
