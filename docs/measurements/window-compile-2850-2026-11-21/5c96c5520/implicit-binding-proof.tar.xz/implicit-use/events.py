"""Compare the exact, canonical ordinary binding stream, as well as independent native outputs."""
from pathlib import Path
import csv
import hashlib
import os
import re
import subprocess
import struct
from codec import encode,decode

study = Path(__file__).resolve().parent
work = study.parent
compiler = work / 'implicit-bound-use-rows/build/compiler'
baseline = work / 'default-integer-control/build/compiler'
clang = Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
folder = study / 'event-fixtures'
folder.mkdir(exist_ok=True)
sqlite = work / 'switch-inputs/sqlite/sqlite3.c'
tree = work / 'pregraph-warning-study/compiler-source'
inputs = {
    'sqlite': ['-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I'+str(sqlite.parent),sqlite],
    'buster': ['-march=native','-I'+str(tree/'src'),'-fwrapv','-funsigned-char','--predefines',work/'proof-predefines.h',tree/'src/buster/compiler/main.c'],
}

shared = '''struct Pair { int x,y; }; enum En { E=3 }; static int a=2,b=3,c=4;
static int sum(int x, int y) { return x+y; }
'''
def arithmetic(names):
    return ' + '.join(f'(({x} * 3) ^ {names[(i+1)%len(names)]})' for i,x in enumerate(names))
bodies = {
    'simple': ('int x=2,y=3;return '+arithmetic(['x','y','a','b','c']*8)+';', True),
    'member': ('struct Pair q={a,b};struct Pair *p=&q;return p->x*q.y+(p->y?q.x:a)+a*b+c;', True),
    'shadow': ('typedef int V; V k=1;int n=3;{typedef long V;V a=n;{long n=7;k+=a*n;} k+=n;}return k+n+a+b+c;',True),
    'scope-for': ('int total=0;for(int a=2,b=1;a<5;a++){int c=a+b;total+=a+b+c;}return total+a+b+c;',True),
    'param-calls': ('int (*p)(int,int)=sum;return sum(c,b)+p(a,b)+sum(b+c,a);', True),
    'queries': ('int m=3,n=4;typeof((m+n)*(a+b)) z=m*n;return _Generic((z+a+b),int:z+a+b,default:73)+sizeof(m+n);',True),
    'vla': ('int m=3,n=4;int q[m+n];q[0]=a+b+c;return q[0]+(int)sizeof q+m*n;',True),
    'inferred': ('int m=3,n=4; __auto_type d=(m+n)*(a+b);return m*d+n+a+b+c;',True),
    'enum': ('enum { X=2, Y=X+E };int k=Y;{enum { Y=4 };k+=Y;}return k+X+Y+E+a+b;',True),
    'labels': ('int k=a+b+c;goto a;a:k+=b*c+a;goto b;b:return k+a+b+c;',True),
    'label-address': ('void *l=&&label;int x=a+b+c;goto *l;label:return x+a+b+c;',True),
    'label-with-attribute': ('int x=a+b+c;goto key;key: __attribute__((unused)); return x+a+b+c;',True),
    'switch': ('int e=a+b+c;switch(e){case E: return e+a+b;default:return e+a+b+c;}',True),
    'typedef-value': ('typedef int X;X k=a+b+c;{int X=a+b; k+=X*a+b;}return k+a+b+c;',True),
    'statement-expression': ('int k=({int a=8,b=2; a*b+c;});return a+b+c+k;',True),
    'sequences': ('int x=a+b+c;volatile int y=x;int z=b,cnt=c; x+=z*cnt;x+=y*y;return x+y+z+cnt;',True),
    'call-builtins': ('int x=a+b+c;return __builtin_popcount((unsigned)(x+a+b+c))+__builtin_choose_expr(1,a+b+c, b*c)+x;',True),
    'builtin-prefix-object': ('int __builtin_notacatalogobject=a+b+c;int x=__builtin_notacatalogobject;return x+b+__builtin_notacatalogobject+a;',True),
    'intrinsic-shadow': ('int _mm_sfence=a+b+c;int _m_prefetch=b+c;return _mm_sfence*_m_prefetch+a+b+c;',True),
    'external-shadow': ('extern int outside; int n=a+b+c; {int outside=n;b+=outside;} return outside+b+c+n;',True),
    'designators': ('int t[]={ [E]=a+b+c, [1]=c*a+b };struct Pair s={.x=t[E],.y=a};return s.x+s.y+a+b+c;',True),
    'pointer': ('int *p=&a;int *q=&b;int *r=&c;return *p+*q+*r+a+b+c;', True),
    'zero-name': ('return (1+2)*3;',True),
    'undeclared': ('int value=a+b+c;return value+unknown_token+b+c;',False),
    'scope-error': ('{int value=a+b+c;} return a+b+c+value;',False),
    'unknown-call': ('int value=a+b+c; return undeclared_fn(value,a,b,c)+a+b;',False),
    'wrong-type': ('struct Pair p={a,b};return a+b+c+p;',False),
    'duplicate-name': ('int value=a+b+c;long value=b*c+a;return value+c+a;',False),
    'missing-label': ('int value=a+b+c;goto missing;return value+a+b+c;',False),
    'warning': ('int k=a+b+c; unsigned char ch=k; if(ch) return ch+k+a+b;return k+a+b+c;',True),
    'unused-expr': ('int k=a+b+c; a+b+c+k; return k+a+b+c;',True),
}
for pad in [0,1,15,63,64,65]:
    names=['a','b','c']
    bodies[f'phase{pad}'] = ('int k='+('1+'*pad)+'a;return '+arithmetic((names*23)[:4+pad])+ '+k;',True)
for name,(body,_) in bodies.items():
    f=folder/(name+'.c')
    f.write_text(shared+'int outside=7; int compute(void){'+body+'}\nint main(void){return (unsigned)compute()%199;}\n')
    inputs[name]=[f]
# Each synthetic body restarts at a different token phase and ends a short name run at a real rebind.
matrix=folder/'phase-run-matrix.c'
programs=[];calls=[]
for phase in range(64):
    for length in (1,2,15,16,17,31,63,64,65):
        name=f'edge_{phase}_{length}'
        expression='+'.join(('a','b','c')[i%3] for i in range(length))
        programs.append('static int '+name+'(int a,int b,int c){'+';'*phase+
                        'int k='+expression+';{int a=k+1;k+='+expression+';}return (k+a+b+c)&255;}')
        calls.append(name+'(2,3,4)')
matrix.write_text('\n'.join(programs)+'\nint main(void){unsigned v=0;'+''.join('v+='+call+';' for call in calls)+'return v%199;}\n')
inputs['phase-matrix']=[matrix]
# Exercise source-to-answer publication above its 8k-token threshold for every source-order hazard too.
padding=''.join(f'typedef int proof_padding_{j};\n' for j in range(2048))
for name in bodies:
    original=inputs[name][0]
    f=folder/('padded-'+name+'.c')
    f.write_text(original.read_text()+padding)
    inputs['padded-'+name]=[f]
modes={'default':['-c'],'strict':['-c','-Wall','-Wextra','-ferror-limit=0'],'fatal':['-c','-Weverything','-Werror','-ferror-limit=0'],'c17':['-c','-std=gnu17'],'c89':['-c','-std=gnu89'],'debug':['-g','-c'],'typed':['--dump-typed','-c'],'scalar':['--scalar','-c'],'assembly':['-S'],'syntax':['-fsyntax-only']}
def sha(data):
    return hashlib.sha256(data).hexdigest()
def execute(args,env=None):
    return subprocess.run(args,env=env,capture_output=True,timeout=90)
def event_info(raw):
    totals=[0]*5
    pos=0
    while pos<len(raw):
        visits,events,names,active=struct.unpack_from('<4I',raw,pos)
        start=pos+16+4*(names*3+active)
        end=start+26*events
        assert end<=len(raw),(pos,len(raw),events,names,active)
        block=raw[pos:end]
        try:
            packed,counts=encode(block);assert decode(packed)==block
            status='exact'
        except (IndexError,ValueError,AssertionError):
            (study/('codec-disputed-%s-%s-%d.events' % (name,mode,pos))).write_bytes(block)
            packed=b'';counts={'unbound':0,'repositioned':0};status='disputed'
        with (study/'codecs.tsv').open('a') as log:
            print(name,mode,pos,len(block),len(packed),counts['unbound'],counts['repositioned'],status,sep='\t',file=log)
        operations=raw[start+24*events:start+25*events]
        previous=struct.unpack_from('<'+str(events)+'I',raw,start+16*events)
        values=(visits,events,names,operations.count(1),sum(op==1 and h!=0 for op,h in zip(operations,previous)))
        totals=[a+b for a,b in zip(totals,values)];pos=end
    return totals
(study/'codecs.tsv').write_text('source\tmode\toffset\tcanonical_bytes\tpacked_bytes\tunbound\trepositioned\tstatus\n')
with (study/'events.tsv').open('w',buffering=1) as file:
    wr=csv.writer(file,delimiter='\t',lineterminator='\n')
    wr.writerow(['source','mode','rc','runs','uses','visits','events','all_uses','bound_uses','event_bytes','event_sha256','output_sha256','diagnostics_sha256','answer_bytes','answer_sha256','clang_runtime'])
    for name,args in inputs.items():
        for mode,flags in (modes.items() if name in bodies else [('default',modes['default']),('strict',modes['strict'])]):
            data=[];obj=folder/('unit.s' if mode=='assembly' else 'unit.o')
            executable=folder/'unit'; runtime='-'; count=(0,0); raw=b''; answer=b''
            for kind,image in [('upstream',baseline),('reference',compiler),('candidate',compiler)]:
                obj.unlink(missing_ok=True)
                event=folder/'stream.bin';event.unlink(missing_ok=True)
                solved=folder/'answers.bin';solved.unlink(missing_ok=True)
                env=os.environ.copy()
                if kind!='upstream':env.update(BUSTER_SOURCE_USE_EVENTS=str(event),BUSTER_SOURCE_USE_ANSWERS=str(solved))
                if kind=='reference':env['BUSTER_SOURCE_USE_REFERENCE']='1'
                if kind=='candidate':env['BUSTER_SOURCE_USE_CENSUS']='1'
                cmd=[image,*flags,*args]
                if mode!='syntax':cmd.extend(['-o',obj])
                run=execute(cmd,env)
                err=run.stderr
                if kind=='candidate':
                    matches=re.findall(rb'^source-use-runs runs=(\d+) uses=(\d+) events=(\d+) visits=(\d+)\n',err,re.M)
                    if matches:
                        count=tuple(sum(int(row[i]) for row in matches) for i in range(2))
                        err=re.sub(rb'^source-use-runs .*\n',b'',err,flags=re.M)
                if kind=='reference': raw=event.read_bytes() if event.exists() else b''
                if kind=='reference': answer=solved.read_bytes() if solved.exists() else b''
                if kind=='candidate': assert answer==(solved.read_bytes() if solved.exists() else b''),(name,mode,'solved declaration or type differs')
                if kind=='candidate' and name in ('sqlite','buster') and mode=='default':(study/(name+'-candidate.answers')).write_bytes(answer)
                if kind=='candidate': assert raw==(event.read_bytes() if event.exists() else b''),(name,mode,'binding rows differ')
                obj_data=obj.read_bytes() if obj.exists() else b''
                data.append((run.returncode,run.stdout,err,obj_data))
            assert data[0]==data[1]==data[2],(name,mode,'upstream mismatch',[(r,len(o),e[:180],len(b)) for r,o,e,b in data])
            rc,std,err,blob=data[-1]
            if (name=='phase-matrix' or name in bodies and bodies[name][1]) and mode=='default' and rc==0:
                link=execute([clang,'-no-pie',obj,'-o',executable]);assert link.returncode==0,link.stderr
                native=execute([executable]);build=execute([clang,'-std=gnu23','-Wno-everything',*args,'-o',executable]);assert build.returncode==0,build.stderr
                oracle=execute([executable]);assert native.returncode==oracle.returncode,(name,native.returncode,oracle.returncode)
                runtime=oracle.returncode
            visits,events,names,all_uses,bound=event_info(raw)
            wr.writerow([name,mode,rc,*count,visits,events,all_uses,bound,len(raw),sha(raw),sha(blob),sha(err),len(answer),sha(answer),runtime])
            if name in ('sqlite','buster') or mode=='default':
                print(name,mode,'rc',rc,'runs',count[0],'uses',count[1],'events',events,'visits',visits,'bound',bound,'total-uses',all_uses,'bytes',len(raw),sha(raw),'runtime',runtime,flush=True)
