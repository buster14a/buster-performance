set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
python
import struct,gdb
from pathlib import Path
offsets = {'heads': 0, 'name_capacity': 8, 'active': 24, 'active_count': 32, 'count': 16, 'operation': 88, 'kind': 96, 'key': 40, 'declaration': 48, 'point': 56, 'end': 64, 'previous': 72, 'depth': 80}
folder = Path('/home/david/Documents/Codex/2026-11-21/g/work/compact-binding-trace-study/native-states')
class Capture(gdb.Breakpoint):
  observations = 0
  def stop(self):
    base=int(gdb.parse_and_eval('$rsi'));p=gdb.selected_inferior()
    def mem(address,n):return bytes(p.read_memory(address,n)) if n else b''
    def field(k,n):return int.from_bytes(mem(base+offsets[k],n),'little')
    n=field('count',4);names=field('name_capacity',4);active=field('active_count',4)
    path=folder / ('state-%03d.events'%self.observations)
    with path.open('wb') as out:
        out.write(struct.pack('<4I',0,n,names,active))
        for key,size in [('heads',12*names),('active',4*active)]+[(k,4*n) for k in ('key','declaration','point','end','previous','depth')]+[(k,n) for k in ('operation','kind')]:
            out.write(mem(field(key,8),size))
    self.observations+=1
    if self.observations>=24:self.enabled=False
    return False
capture=Capture('c_binding_test_compare')
end
run
quit
