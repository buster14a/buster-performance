from pathlib import Path
from array import array
from collections import Counter
import struct
import sys

def parse(raw):
    header = struct.unpack_from('<4I',raw)
    visits,events,names,active=header
    cur=16
    def take(n,w=4):
        nonlocal cur
        data=raw[cur:cur+w*n]
        assert len(data)==w*n
        cur+=len(data)
        return array('I',data) if w==4 else data
    cols=[take(3*names),take(active)]
    cols.extend(take(events,w) for w in (4,4,4,4,4,4,1,1))
    assert cur==len(raw)
    return header,cols

if __name__=='__main__':
    for fn in sys.argv[1:]:
        raw=Path(fn).read_bytes()
        (v,n,names,a),(heads,active,key,d,p,end,h,depth,op,kind)=parse(raw)
        c=Counter()
        for i,operation in enumerate(op):
            c[('op',operation)]+=1
            c[('different_point',operation)]+=p[i]!=d[i]
            if operation==1:
                c['bound']+=h[i]!=0
                c['source_bound_same_key']+=h[i]!=0 and key[h[i]-1]==key[i]
                c['nonordinary']+=key[i]>=names
                c['uses_kind_obj']+=kind[i]==1
                c['uses_depth0']+=depth[i]==0
                c['uses_endnone']+=end[i]==2**32-1
                c['repeatsource']+=i>0 and d[i]<=d[i-1]
            if operation==2:
                c['nonconst_restore']+=bool(key[i] or h[i] or depth[i] or kind[i] or end[i]!=2**32-1)
        print(Path(fn).name,dict(c))
