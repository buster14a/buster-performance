"""Lossless source-order event schema for a single CBindings producer."""
from array import array
from collections import Counter
import hashlib
from pathlib import Path
import struct
import sys
from census import parse

NONE = 2**32 - 1
U32 = struct.Struct('<I')
HEADER = struct.Struct('<3I')

def encode(raw):
    (visits,n,names,active_count),(heads,active,key,decl,point,end,prev,depth,op,kind) = parse(raw)
    encoded = bytearray(HEADER.pack(visits,n,names))
    counts = Counter()
    for i,operation in enumerate(op):
        if operation == 0:
            assert kind[i] < 6
            encoded.append(kind[i])
            encoded.extend(struct.pack('<4I',decl[i],point[i],key[i],depth[i]))
            counts['declare'] += 1
        elif operation == 1:
            assert (depth[i],kind[i],end[i]) == (0,1,NONE)
            bound = prev[i] != 0
            if bound:
                assert prev[i] <= i and key[prev[i]-1] == key[i] and op[prev[i]-1] == 0
            special = decl[i] != point[i]
            encoded.append(8+2*special+(not bound))
            encoded.extend(struct.pack('<2I',decl[i],prev[i] if bound else key[i]))
            if special: encoded.extend(U32.pack(point[i]))
            counts['unbound' if not bound else 'bound'] += 1
            counts['repositioned'] += special
        else:
            assert operation == 2 and (key[i],prev[i],depth[i],kind[i],end[i]) == (0,0,0,0,NONE)
            encoded.append(12)
            encoded.extend(struct.pack('<2I',decl[i],point[i]))
            counts['restore'] += 1
    return encoded,counts

def decode(encoded):
    visits,n,names=HEADER.unpack_from(encoded)
    head=array('I',[0])*(3*names)
    active=array('I')
    keys,decl,points,ends,prev,depth=[array('I') for _ in range(6)]
    ops,kinds=bytearray(),bytearray()
    cur=HEADER.size
    def u32():
        nonlocal cur
        value=U32.unpack_from(encoded,cur)[0]
        cur+=4
        return value
    for i in range(n):
        tag=encoded[cur];cur+=1
        tok=u32();kind=d=key=previous=0
        if tag<6:
            kind=tag;op=0;p=u32();key=u32();d=u32()
            previous=head[key];head[key]=i+1;active.append(i)
        elif tag==12:
            op=2;p=u32()
            while len(active)>tok:
                old=active.pop();ends[old]=i;head[keys[old]]=prev[old]
        else:
            assert 8<=tag<=11
            op=1;kind=1
            value=u32();p=u32() if tag>=10 else tok
            if tag%2:
                key=value;assert head[key]==0
            else:
                previous=value;key=keys[previous-1]
                assert head[key]==previous
        ops.append(op);kinds.append(kind)
        keys.append(key);decl.append(tok);points.append(p);ends.append(NONE);prev.append(previous);depth.append(d)
    assert cur==len(encoded)
    return b''.join([struct.pack('<4I',visits,n,names,len(active)),head,active,keys,decl,points,ends,prev,depth,ops,kinds])

if __name__ == '__main__':
    for name in sys.argv[1:]:
        raw=Path(name).read_bytes()
        encoded,stats=encode(raw)
        assert decode(encoded)==raw
        print(Path(name).name,len(raw),len(encoded),round(len(encoded)/len(raw),5),hashlib.sha256(raw).hexdigest(),dict(stats))
