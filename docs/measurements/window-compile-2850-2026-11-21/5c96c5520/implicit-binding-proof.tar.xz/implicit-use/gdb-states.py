"""Reconstruct complete native CBindings test states, including tags, label namespaces and missing targets."""
import ast,hashlib,subprocess
from pathlib import Path
from census import parse
from codec import encode,decode
s=Path(__file__).resolve().parent;w=s.parent
offsets=ast.literal_eval(next(line[line.index('{'):] for line in (w/'source-use-run-study/upstream-events.log').read_text().splitlines() if line.startswith('layout offsets')))
gdb='''set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
python
import struct,gdb
from pathlib import Path
offsets = OFFSETS
folder = Path(FOLDER)
class Capture(gdb.Breakpoint):
  observations = 0
  def stop(self):
    base=int(gdb.parse_and_eval('$rsi'));p=gdb.selected_inferior()
    def mem(address,n):return bytes(p.read_memory(address,n)) if n else b''
    def field(k,n):return int.from_bytes(mem(base+offsets[k],n),'little')
    n=field('count',4);names=field('name_capacity',4);active=field('active_count',4)
    path=folder / ('state-%03d.events'%self.observations)
    with path.open('wb') as out:
        out.write(struct.pack('<4I',0,n,names,active))
        for key,size in [('heads',12*names),('active',4*active)]+[(k,4*n) for k in ('key','declaration','point','end','previous','depth')]+[(k,n) for k in ('operation','kind')]:
            out.write(mem(field(key,8),size))
    self.observations+=1
    if self.observations>=24:self.enabled=False
    return False
capture=Capture('c_binding_test_compare')
end
run
quit
'''
dst=s/'native-states';dst.mkdir(exist_ok=True)
g=(s/'native-states.gdb');g.write_text(gdb.replace('OFFSETS',repr(offsets)).replace('FOLDER',repr(str(dst))))
cmd=['gdb','-nx','-batch','-x',g,'--args',w/'default-integer-control/build/compiler','test-bindings','--seed','2850']
r=subprocess.run(cmd,capture_output=True,timeout=120);(s/'native-states-gdb.log').write_bytes(r.stdout+r.stderr)
assert r.returncode==0,r.stderr
out=[]
for f in sorted(dst.glob('*.events')):
    raw=f.read_bytes();compact,counts=encode(raw);assert decode(compact)==raw
    (_,n,names,_),(_,_,keys,_,_,_,handles,_,operations,_)=parse(raw)
    other=sum(op==1 and keys[i]>=names for i,op in enumerate(operations))
    out.append((f.name,n,len(raw),len(compact),counts['bound'],counts['unbound'],other,hashlib.sha256(raw).hexdigest()))
assert len(out)>=3 and sum(r[5] for r in out)>0 and sum(r[6] for r in out)>0
with (s/'native-states.tsv').open('w') as f:
    print('source','events','canonical_bytes','represented_bytes','bound','unbound','other_namespaces','sha256',sep='\t',file=f)
    for row in out:print(*row,sep='\t',file=f)
print(len(out),'logical streams;',sum(r[5] for r in out),'unbound;',sum(r[6] for r in out),'non-ordinary')
