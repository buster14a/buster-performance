"""Independently read physical slots from the actual two compiled inputs and reconstruct logical rows."""
from pathlib import Path
from collections import Counter
from array import array
import csv,hashlib,struct,subprocess
from census import parse
s=Path(__file__).resolve().parent;w=s.parent
sqlite=w/'switch-inputs/sqlite/sqlite3.c';tree=w/'pregraph-warning-study/compiler-source'
sources={'sqlite':['-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I'+str(sqlite.parent),sqlite],
         'buster':['-march=native','-I'+str(tree/'src'),'-fwrapv','-funsigned-char','--predefines',w/'proof-predefines.h',tree/'src/buster/compiler/main.c']}
names=['heads','active','key','declaration','point','end','previous','depth','operation','kind']
def sha(data):return hashlib.sha256(data).hexdigest()
with (s/'physical.tsv').open('w',buffering=1) as tbl:
    out=csv.writer(tbl,delimiter='\t',lineterminator='\n');out.writerow(['input','uses','physical_key_diffs','physical_end_diffs','physical_depth_diffs','physical_kind_diffs','physical_sha256','logical_sha256','answers_sha256','elf_sha256'])
    for name,args in sources.items():
        pref=s/('physical-'+name)
        run=subprocess.run(['python3',s/'replay-gdb.py',w/'implicit-bound-use-rows',pref,'--',*args],capture_output=True,timeout=180)
        assert run.returncode==0,run.stderr.decode()[-1600:]
        raw=(Path(str(pref)+'.events')).read_bytes()
        baseline=(w/'source-use-run-study'/(name+'-upstream.events')).read_bytes()
        answers=(Path(str(pref)+'.answers')).read_bytes()
        assert answers==(w/'proven-use-study'/(name+'-upstream.answers')).read_bytes()
        meta,columns=parse(raw);b,bc=parse(baseline);assert b==meta
        norm=[array('I',col) if isinstance(col,array) else bytearray(col) for col in columns]
        changes=Counter()
        for k,(x,y) in enumerate(zip(columns,bc)):
            if names[k] not in ('key','end','depth','kind'):
                assert x==y,(name,names[k])
        uses=0
        for i,op in enumerate(columns[8]):
            if op==1:
                h=columns[6][i];uses+=1
                for k,logical in [(2,columns[2][h-1] if h else columns[2][i]),(5,2**32-1),(7,0),(9,1)]:
                    assert logical==bc[k][i],(name,i,names[k])
                    changes[names[k]]+=columns[k][i]!=logical
                    norm[k][i]=logical
        assert b''.join([struct.pack('<4I',*meta),*norm])==baseline
        assert changes['key'] and changes['end'] and changes['kind']
        out.writerow([name,uses,*[changes[k] for k in ('key','end','depth','kind')],sha(raw),sha(baseline),sha(answers),sha(Path(str(pref)+'.o').read_bytes())])
