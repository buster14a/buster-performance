"""Differential replay of callers that inspect binding metadata after source resolution."""
import ast,csv,hashlib,os,re,subprocess
from pathlib import Path
from codec import encode,decode
p=Path(__file__).resolve().parent; w=p.parent
trees=[w/'default-integer-control',w/'implicit-bound-use-rows',w/'implicit-bound-use-rows']
src=trees[0]/'src/buster/compiler'
tmp=p/'metadata-sources';tmp.mkdir(exist_ok=True)
inputs={}
for suite in ['symbol_pragma_test','symbol_pragma_driver_test','fp_eval_driver_test','target_versions_driver_test']:
    text=(src/('c_check_'+suite+'.c')).read_text()
    for m in re.finditer(r'"(?:[^"\\]|\\.)*"(?:\s*"(?:[^"\\]|\\.)*")*',text):
        cs=''.join(ast.literal_eval(x) for x in re.findall(r'"(?:[^"\\]|\\.)*"',m[0]))
        if len(cs)>25 and ('#pragma' in cs or '__attribute__' in cs) and ('int ' in cs or 'float ' in cs or 'void ' in cs):
            inputs.setdefault(cs,suite+'-'+str(len(inputs)))
inputs.update({
'extern int x; int read(void){ return x; }\n#pragma redefine_extname x changed_name\nextern int x;\n':'rename-after-read',
'static int f(void){return 9;} int use(void){int f=2;return f;}\n#pragma weak f\n':'weak-shadow',
'int use(void){int f=2;return f + missing;}\n#pragma weak f\n':'unknown-weak',
'int f(int a){return a;} int g(int a){return f(a);}\n#pragma redefine_extname f redirected\n':'rename-after-call',
'extern int x;\n#pragma weak alias = x\nint g(void){return x;}\n':'weak-alias',
'extern int f(int); int x(int y){return f(y);}\nint __attribute__((target("sse2"))) f(int x){return x;}\n':'target-after-call',
'float f(float x){return x;} typedef float float_t;\n#pragma clang fp eval_method(double)\nfloat_t ref;':'float-typedef'
})
padding=''.join('typedef int meta_pad_%d;\n'%i for i in range(2048))
flags=[('default',[]),('strict',['-Wall','-Wextra','-ferror-limit=0']),('disabled-attestation',['--attested=off']),('scalar',['--scalar'])]
def h(data):return hashlib.sha256(data).hexdigest()
with (p/'policies.tsv').open('w',buffering=1) as out:
    writer=csv.writer(out,delimiter='\t',lineterminator='\n');writer.writerow(['source','policy','status','short_rows','output_sha256','diagnostics_sha256','event_sha256'])
    for source,name in inputs.items():
        f=tmp/(name+'.c');f.write_text(source+'\n'+padding)
        for mode,args in flags:
            payloads=[]
            for i,t in enumerate(trees):
                obj=tmp/'out.o';obj.unlink(missing_ok=True);trace=tmp/'events.bin';trace.unlink(missing_ok=True)
                env=os.environ.copy()
                if i>0:env['BUSTER_SOURCE_USE_EVENTS']=str(trace)
                if i==1:env['BUSTER_SOURCE_USE_REFERENCE']='1'
                if i==2:env['BUSTER_SOURCE_USE_CENSUS']='1'
                r=subprocess.run([t/'build/compiler','-c',*args,str(f),'-o',str(obj)],env=env,capture_output=True,timeout=30)
                msg=r.stderr
                if i==2:
                    found=re.findall(rb'^source-use-runs runs=\d+ uses=(\d+) events=\d+ visits=\d+\n',msg,re.M)
                    hits=sum(map(int,found))
                    msg=re.sub(rb'^source-use-runs .*?\n',b'',msg,flags=re.M)
                payloads.append((r.returncode,r.stdout,msg,obj.read_bytes() if obj.is_file() else b''))
                if i==1:raw=trace.read_bytes() if trace.is_file() else b''
                if i==2:assert raw==(trace.read_bytes() if trace.is_file() else b''),(name,mode,'event stream')
            assert payloads[0]==payloads[1]==payloads[2],(name,mode,'native result',[(a,b,c[:200],len(d)) for a,b,c,d in payloads])
            status,stdout,stderr,data=payloads[0]
            writer.writerow([name,mode,status,hits,h(data),h(stderr),h(raw)])
print(len(inputs),'inputs',len(inputs)*len(flags),'comparisons')
