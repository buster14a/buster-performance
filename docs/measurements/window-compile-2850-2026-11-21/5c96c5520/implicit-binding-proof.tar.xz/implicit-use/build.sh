#!/bin/bash
set -eu
cd "$(dirname "$0")/../implicit-bound-use-rows"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >../compact-binding-trace-study/build.log 2>&1
cp ../default-integer-control/build/predefines.h build/predefines.h
./build/compiler test-checker --seed 2850 --part 6/8 >../compact-binding-trace-study/early-shard6.log 2>&1
python3 ../compact-binding-trace-study/gdb-states.py >../compact-binding-trace-study/native-states.log 2>&1
cd ../switch-inputs
source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
BUSTER_SOURCE_USE_CENSUS=1 ../implicit-bound-use-rows/build/compiler -c -o ../compact-binding-trace-study/sqlite.candidate.o "${args[@]}" >../compact-binding-trace-study/sqlite.out 2>../compact-binding-trace-study/counter.txt
../default-integer-control/build/compiler -c -o ../compact-binding-trace-study/sqlite.parent.o "${args[@]}" >../compact-binding-trace-study/parent.out 2>../compact-binding-trace-study/parent.err
cmp ../compact-binding-trace-study/sqlite.candidate.o ../compact-binding-trace-study/sqlite.parent.o

python3 ../compact-binding-trace-study/four-way.py >../compact-binding-trace-study/four-way.log
python3 ../compact-binding-trace-study/events.py >../compact-binding-trace-study/events.log 2>&1
cmp ../compact-binding-trace-study/sqlite-candidate.answers ../proven-use-study/sqlite-upstream.answers
cmp ../compact-binding-trace-study/buster-candidate.answers ../proven-use-study/buster-upstream.answers
python3 ../compact-binding-trace-study/raw-gdb.py >../compact-binding-trace-study/raw-gdb.log 2>&1
python3 ../compact-binding-trace-study/policies.py >../compact-binding-trace-study/policies.log 2>&1
python3 ../compact-binding-trace-study/oracle.py >../compact-binding-trace-study/oracle.log 2>&1
python3 ../compact-binding-trace-study/local_pairs.py >../compact-binding-trace-study/pairs.log 2>&1
python3 ../compact-binding-trace-study/target_pairs.py >../compact-binding-trace-study/target.log 2>&1
parent=$PWD/../default-integer-control/build/compiler
new=$PWD/../implicit-bound-use-rows/build/compiler
out=$PWD/../compact-binding-trace-study/corpus
mkdir -p "$out"
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main lua musl; do var=${g}_arguments; eval "args=(${!var})"; python3 ../default-object-qa/pair.py "$out" "$g" "$parent" "$new" "${args[@]}"; done
python3 ../compact-binding-trace-study/pmu.py >../compact-binding-trace-study/pmu.log 2>&1
cd ../implicit-bound-use-rows
for part in {1..8}; do ./build/compiler test-checker --seed 2850 --part "$part/8" >"../compact-binding-trace-study/checker-$part.log" 2>&1; done
