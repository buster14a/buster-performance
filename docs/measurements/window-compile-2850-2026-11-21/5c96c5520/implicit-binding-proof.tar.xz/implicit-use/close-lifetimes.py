"""Can the next source operation still reference canonical events made while a function was read?"""
import csv
from pathlib import Path
from collections import Counter
from bisect import bisect_right
import statistics
from census import parse
s=Path(__file__).resolve().parent
w=s.parent;none=2**32-1
for name in ['sqlite','buster']:
    original=w/'source-use-run-study'/(name+'-upstream.events')
    observer=w/'binding-close-study'/('sqlite.bodies.tsv' if name=='sqlite' else 'buster-canonical.bodies.tsv')
    (_,cnt,names,nactive),(heads,active,key,decl,point,until,previous,depth,op,kind)=parse(original.read_bytes())
    spans=list(csv.DictReader(observer.open(),delimiter='\t'))
    last_reference=[-1]*cnt
    source_future=[set() for i in spans]
    containing=[-1]*cnt
    max_len=0
    for fi,r in enumerate(spans):
        lo,hi=map(int,(r['event_first'],r['event_end']))
        max_len=max(max_len,hi-lo)
        assert 0<=lo<=hi<=cnt
        assert fi==0 or int(spans[fi-1]['event_end'])<=lo
        for i in range(lo,hi):containing[i]=fi
    for e,h in enumerate(previous):
        if h:
            assert op[h-1]==0 and h<=e+1
            last_reference[h-1]=max(last_reference[h-1],e)
            fi=containing[h-1]
            if fi>=0 and e>=int(spans[fi]['event_end']):source_future[fi].add(h-1)
    final_active=set(active); final_heads={h-1 for h in heads if h}; assert final_heads<=final_active
    measures=Counter()
    with (s/(name+'.close-lifetimes.tsv')).open('w') as out:
        wr=csv.writer(out,delimiter='\t',lineterminator='\n')
        keys=['rows','uses','decls','restores','source_ref_after','source_ref_after_next','active_at_cut','active_after_next','future_undo_needed','future_undo_after_next','file_head','active_at_EOF','last_use_lag','last_pop_lag']
        wr.writerow(['body','close','lo','hi',*keys])
        for fi,r in enumerate(spans):
            lo,hi=map(int,(r['event_first'],r['event_end']))
            c=Counter();c['rows']=hi-lo
            for i in range(lo,hi):
                operation=op[i]
                if operation==1:c['uses']+=1;continue
                if operation==2:c['restores']+=1;continue
                c['decls']+=1
                c['source_ref_after']+=last_reference[i]>=hi
                c['source_ref_after_next']+=last_reference[i]>hi
                c['active_at_cut']+=until[i]>=hi
                c['active_after_next']+=until[i]>hi
                c['future_undo_needed']+=hi<=until[i]<none
                c['future_undo_after_next']+=hi<until[i]<none
                c['file_head']+=i in final_heads
                c['active_at_EOF']+=i in final_active
                if last_reference[i]>=hi:c['last_use_lag']=max(c['last_use_lag'],last_reference[i]-hi+1)
                if hi<=until[i]<none:c['last_pop_lag']=max(c['last_pop_lag'],until[i]-hi+1)
            assert c['source_ref_after']==len(source_future[fi])
            wr.writerow([r['body'],r['end'],lo,hi,*[c[k] for k in keys]])
            for k in keys:
                if k.startswith('last_'):measures[k]=max(c[k],measures[k])
                else:measures[k]+=c[k]
    print(name,'total',cnt,'functions',len(spans),'max_window',max_len,'logical_rows_at_cuts',dict(measures))
