struct P{int a,b;};struct P g={2,3};int f(struct P*p,int x){return p->a*g.b+x;}
