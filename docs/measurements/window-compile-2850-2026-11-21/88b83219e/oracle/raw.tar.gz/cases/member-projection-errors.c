struct A{int a;}; int f(struct A*p){return p->a+p->missing;}
