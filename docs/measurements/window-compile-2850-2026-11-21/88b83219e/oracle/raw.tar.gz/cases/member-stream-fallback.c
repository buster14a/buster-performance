struct S{int alpha:3; volatile int v; int b;}; struct W{struct S x;struct S *q;}; int f(struct W*w){return w->x.alpha + w->q->v + w->x.b;}
