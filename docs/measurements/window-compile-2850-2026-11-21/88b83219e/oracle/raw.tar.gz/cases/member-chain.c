struct Inner{int a,b;}; struct Outer{int unused;struct Inner in;struct Outer*next;}; int f(struct Outer*p){return p->next->in.b + p->in.a;}
