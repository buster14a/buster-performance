#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d=$PWD; cd ../expression-profile
export PATH="/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH"
./build.sh >"$d/build.log" 2>&1
cp ../buster/build/predefines.h build/predefines.h
cc=$PWD/build/compiler; ref=$PWD/../profile-current-parent/build/compiler
sha256sum "$cc" "$ref" >"$d/binaries"
f=tests/checker/node-window.c
for cfg in base new;do
 [[ $cfg == new ]] && bin=$cc || bin=$ref
 for flags in ordinary time window timed-window;do
  args=(); [[ $flags != time && $flags != timed-window ]] || args+=(--time-stages)
  [[ $flags != window && $flags != timed-window ]] || args+=(--node-window)
  strace -qq -e getrusage -o "$d/$cfg-$flags.trace" "$bin" --lanes 1 -nostdinc -c "${args[@]}" "$f" -o "$d/$cfg-$flags.o" >"$d/$cfg-$flags.out" 2>"$d/$cfg-$flags.err"
  cmp "$d/base-ordinary.o" "$d/$cfg-$flags.o"
 done
 "$bin" benchmark-checker-bindings --passes 1 -nostdinc "$f" >"$d/$cfg-bench.out" 2>"$d/$cfg-bench.err"
done
for part in 5 6;do "$cc" test-checker --part "$part/8" --seed 2850 >"$d/checker-$part.log" 2>&1;done
cd ../switch-inputs;source ../switch-local-args.sh
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite lua musl main;do v=${g}_arguments;eval "files=(${!v})";python3 "$d/../default-object-qa/pair.py" "$d" "$g" "$ref" "$cc" "${files[@]}";done
python3 "$d/paths.py" >"$d/paths.log"
