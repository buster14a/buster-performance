from pathlib import Path
import hashlib, itertools,csv,subprocess,tempfile,sys,os
d=Path(__file__).resolve().parent;tree=d.parent/'expression-profile';ref=d.parent/'profile-current-parent/build/compiler';own=tree/'build/compiler'
def digest(x):return hashlib.sha256(x).hexdigest()
headers=['source','driver','window','debug','timed','same','returncode','object','warning','stage_rows_parent','stage_rows_patch']
with (d/'paths.tsv').open('w',buffering=1) as f, tempfile.TemporaryDirectory(dir=d) as tmp:
 w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(headers)
 for source,driver,window,debug,timing in itertools.product(['tests/checker/node-window.c','tests/checker/control.c'],['ordinary','deferred','scalar'],['none','regular','assignments'],[False,True],[False,True]):
  src=tree/source
  if not src.exists():
   if source.endswith('control.c'):src=d.parent/'cross-chunk-study/logical-guard.c'
   else:raise FileNotFoundError(src)
  flags=['--lanes','2','--deferred-bodies'] if driver=='deferred' else ['--lanes','1']
  if driver=='scalar':flags.append('--scalar')
  if window!='none':flags+=['--node-window' if window=='regular' else '--node-window-assignments']
  if debug:flags+=['-g']
  if timing:flags+=['--time-stages']
  got=[];stages=[]
  for cc in (ref,own):
   obj=Path(tmp)/'out.o';obj.unlink(missing_ok=True)
   r=subprocess.run([str(cc),*flags,'-c','-nostdinc',str(src),'-o',str(obj)],capture_output=True,timeout=20)
   lines=r.stderr.splitlines(True)
   reports=[l for l in lines if l.startswith((b'time-',b'lowering-nodes\t'))]
   clean=[l for l in lines if l not in reports]
   stages.append(len(reports));got.append((r.returncode,digest(obj.read_bytes()) if obj.exists() else '-',digest(b''.join(clean)),r.stdout))
  a,b=got;w.writerow([src.name,driver,window,int(debug),int(timing),int(a==b),*a[:3],*stages])
  if a!=b or a[0] or (timing and not all(stages)):print('difference',src.name,flags,a[:3],b[:3],stages,flush=True)
