#include <stdint.h>
#include <stdio.h>
int immediate(void),simple(int),conditional(int),alternative(int),folded(int),iteration(int),repeated(int),indices(int),local_init(int),cases(int);
int global=17;
static unsigned calls, unreached;
int consume(int x){calls=calls*31u+(unsigned)x;return 4*x+7;}
int unreachable(void){unreached++;return -99;}
int main(void)
{
    unsigned long long h=0;
    for(int i=-8;i<31;i++)
    {
        h=h*31u+(unsigned)immediate(); h=h*31u+(unsigned)simple(i); h=h*31u+(unsigned)conditional(i);
        h=h*31u+(unsigned)alternative(i); h=h*31u+(unsigned)folded(i); h=h*31u+(unsigned)iteration(i);
        h=h*31u+(unsigned)repeated(i);h=h*31u+(unsigned)indices(i);
    }
    printf("%llu %u %u\n",h,calls,unreached);
    return unreached!=0;
}
