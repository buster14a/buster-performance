#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"; d=$PWD
sed -e '/^int local_init/d' -e '/^int cases(/d' fixtures.c > complete.c
sed -e 's/h=h\*31u+(unsigned)local_init(i);//' -e '/unsigned)cases(i);/d' driver.c > complete-driver.c
"$d/compiler" --lanes 1 -nostdinc -c "$d/complete.c" -o complete.ref.o > complete.ref.stdout 2> complete.ref.stderr
BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_SOURCE_ONLY=1 BUSTER_CONTROL_SOURCE_AUDIT=1 "$d/compiler" --lanes 1 -nostdinc -c "$d/complete.c" -o complete.native.o > complete.native.stdout 2> complete.native.stderr
cmp complete.ref.o complete.native.o
clang=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$clang" -O0 -c complete.c -o complete.clang.o
for v in ref native clang;do "$clang" complete-driver.c "complete.$v.o" -o "complete.$v"; "./complete.$v" >"complete.$v.result"; cmp complete.ref.result "complete.$v.result";done
sha256sum complete.ref.o complete.native.o
cat complete.ref.result
