#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD
cd ../switch-inputs;source ../switch-local-args.sh
case $1 in
fixture) args=(-nostdinc "$d/fixtures.c");;
sqlite) eval "args=($sqlite_arguments)";;
main) tree=$PWD/../pregraph-warning-study/compiler-source
args=(-march=native -I"$tree/src" -fwrapv -funsigned-char --predefines "$PWD/../proof-predefines.h" "$tree/src/buster/compiler/main.c");;
esac
BUSTER_BODY_DISCARD_RESULT=1 BUSTER_CHECK_BODY_SOURCE_ONLY=1 BUSTER_CHECK_BODY_ADMIT_ALL=1 BUSTER_SOURCE_CONTROLS=1 BUSTER_LOCAL_CONTROL_NATIVE=1 "$d/compiler" --lanes 1 -c "${args[@]}" -o "$d/unused.o" >"$d/$1.source.out" 2>"$d/$1.source"
BUSTER_CONTROL_NATIVE_REFERENCE=1 "$d/compiler" --lanes 1 -c "${args[@]}" -o "$d/$1.o" >"$d/$1.ref.out" 2>"$d/$1.ref"
