import argparse, csv, hashlib, json, re, statistics
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('results',type=Path)
p.add_argument('out',type=Path)
p.add_argument('--partial',action='store_true')
args=p.parse_args()
def pmu(path):
    with path.open() as f:
        values={r[2]:float(r[0]) for r in csv.reader(f) if len(r)>=6}
    values['total cycles']=values['cycles:u']+values['cycles:k']
    return values
def wall(path):
    vals=re.findall(r'^run 1 list 1: ([\d.]+) ms wall, ([\d.]+) ms user, ([\d.]+) ms system, (\d+) KiB wait4 peak, (\d+) minor faults, (\d+) major, (\d+) user cycles, (\d+) instructions, status (\d+)$',path.read_text(),re.M)
    assert len(vals)==1 and vals[0][-1]=='0',path
    return dict(zip(['wall ms','user ms','system ms','peak KiB','minor faults','major faults','user cycles','instructions'],map(float,vals[0])))
def stage(path):
    values={}
    for line in path.read_text(errors='replace').splitlines():
        f=line.split('\t')
        if len(f)>=3 and ((f[0]=='time-stage' and f[1] in ('check-input','total')) or (f[0]=='time-process' and f[1] in ('tokens','minor-faults'))):
            name=f[0]+'.'+f[1]
            values[name]=values.get(name,0)+float(f[2])
    return values
def equal(a,b):
    assert a.read_bytes()==b.read_bytes(),(a,b)
def med(x):return statistics.median(x)
out={}
for corpus in ('sqlite','lua','musl','main'):
    data=out[corpus]={}
    for mode,wanted in [('pmu',7),('wall',7),('stage',3),('warnings',1),('debug',1)]:
        samples=[]
        for i in range(1,wanted+1):
            a,b=[args.results/f'{mode}-{corpus}-{i}-{side}' for side in ('base','new')]
            if args.partial and not (a.with_suffix('.done').exists() and b.with_suffix('.done').exists()):continue
            assert a.with_suffix('.done').exists() and b.with_suffix('.done').exists(),(a,b)
            equal(a.with_suffix('.objects'),b.with_suffix('.objects'))
            if mode!='stage':
                for ext in ('.out','.err'):equal(a.with_suffix(ext),b.with_suffix(ext))
            if mode=='wall': samples.append([wall(q.with_suffix('.wall')) for q in (a,b)])
            elif mode=='stage': samples.append([stage(q.with_suffix('.err')) for q in (a,b)])
            elif mode=='pmu': samples.append([pmu(q.with_suffix('.perf')) for q in (a,b)])
            else: samples.append([])
        group=data[mode]={'pairs':len(samples)}
        if mode not in ('wall','pmu','stage') or not samples:continue
        for name in samples[0][0]:
            base=[a[name] for a,b in samples]; new=[b[name] for a,b in samples]
            diff=[b-a for a,b in zip(base,new)]
            ratio=[100*(b/a-1) for a,b in zip(base,new) if a]
            group[name]={'base':med(base),'new':med(new),'delta':med(diff),'range':[min(diff),max(diff)],'percent':med(ratio) if ratio else None,'percent range':[min(ratio),max(ratio)] if ratio else None}
args.out.write_text(json.dumps(out,indent=2)+'\n')
for corpus,data in out.items():
    print(corpus,[(m,data[m]['pairs']) for m in data])
    for mode,key in [('pmu','instructions:u'),('pmu','total cycles'),('pmu','page-faults'),('wall','wall ms')]:
        if key in data[mode]:
            v=data[mode][key]
            print(key,'base %.2f diff %+.2f [%+.2f, %+.2f] %+.4f%%' % (v['base'],v['delta'],*v['range'],v['percent']))
