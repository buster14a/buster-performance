from pathlib import Path
import csv,hashlib,json,shutil,sys,statistics as st,tarfile,re,subprocess
d=Path(__file__).resolve().parent;g=Path(sys.argv[1]); src=d.parent/'bench-local/tail3250-temp'
g.mkdir(exist_ok=True,parents=True)
subprocess.run([sys.executable,str(d/'summarize.py'),str(src),str(g/'paired.json'),'--partial'],stdout=subprocess.DEVNULL,check=True)
assert json.loads((g/'paired.json').read_text())==json.loads((d.parent/'bench-local/tail3250-snapshot.json').read_text())
subprocess.run(['tar','--zstd','-cf',str(g.resolve()/'native-runs.tar.zst'),'-C',str(src),'.'],check=True)
def read(p):
 return list(csv.DictReader(p.open(),delimiter='\t'))
real=read(d/'real-graph/rows.tsv')
assert len(real)==1372 and all(r['old_rc']==r['new_rc']=='0' and r['match']=='1' and r['old_graph']==r['new_graph'] and r['old_elf']==r['new_elf'] and r['old_diag']==r['new_diag'] and r['scalar_tail']==r['scalar_count'] and r['coded_tail']==r['coded_count'] for r in real)
def sumc(r,k):return sum(int(x[k]) for x in r)
stats=json.loads((g/'paired.json').read_text())
assert all(stats[k]['pmu']['pairs']==stats[k]['wall']['pairs']==7 for k in stats)
rows=[]
for corpus in ['sqlite','lua','musl','main']:
 part=[x for x in real if x['corpus']==corpus];rows.append([corpus,len(part),4*(sumc(part,'tokens')+sumc(part,'readers')),sumc(part,'nodes'),sumc(part,'arguments'),sumc(part,'graph_bytes')])
with (g/'graphs.tsv').open('w') as f:
 w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['corpus','units','avoided_tail_bytes','checked_nodes','arguments','normalized_graph_bytes']);w.writerows(rows)
shards={}
for kind in ['checker','driver']:
 values=[]
 for i in range(1,9):
  p=d/'shards'/f'{kind}-{i}.log';q=p.with_suffix('.status')
  assert q.read_text().strip()=='0';values.append(int(re.findall(r'(\d+) checks, 0 failures',p.read_text())[-1]))
 shards[kind]=values
(g/'shards.json').write_text(json.dumps(shards,indent=2)+'\n')
with tarfile.open(g/'source-and-receipts.tar.gz','w:gz',compresslevel=3) as tar:
 files=[d/'real-graph/rows.tsv',*(d/'shards').iterdir(),d/'locked-identities',d/'expected.tree',d/'summarize.py',d/'build-locked.sh',d/'release-record.py']
 files+=[d/'export/patches/candidate.patch',d/'export/patches/revisions.txt']
 files+=list((d/'export/scripts').glob('*.sh'))
 for p in sorted(set(files)):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(d)))
print('checker and driver', [sum(shards[k]) for k in shards], 'checked rows and args',[sum(r[k] for r in rows) for k in [3,4,5]])
