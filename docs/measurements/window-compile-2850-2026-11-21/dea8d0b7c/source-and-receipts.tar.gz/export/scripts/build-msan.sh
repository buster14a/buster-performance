#!/usr/bin/env bash
set -euo pipefail
d=$(cd "$(dirname "$0")" && pwd); tree=${BUSTER_PROOF_TREE:?set BUSTER_PROOF_TREE to the reconstructed proof checkout}; cd "$tree"
test "$(git write-tree)" = 7fc103a9251eaf6d64784dedc65e1818acdccc00
BUSTER_SANITIZER=memory BUSTER_SANITIZER_OPTIMIZATION=3 ./build.sh --config Release --jobs "${CORES:-2}" > "$d/msan.build" 2>&1
cp --reflink=auto build/compiler "$d/poison-msan"

sha256sum "$d/poison-msan" > "$d/msan.sha256"
