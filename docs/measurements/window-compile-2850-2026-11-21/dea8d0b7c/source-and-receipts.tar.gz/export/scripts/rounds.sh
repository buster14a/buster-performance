#!/usr/bin/env bash
set -euo pipefail
d=$(cd "$(dirname "$0")" && pwd); shared="$HOME/buster-fast-bench/2850-codex-step2"
export BUSTER_BENCH_TITLE='2850 reader expression value chain tails' BUSTER_BENCH_URL=https://github.com/buster14a/buster/issues/2850
for (( r=$1; r<=$2; r++ )); do
    modes=(base new); if ((r%2 == 0)); then modes=(new base); fi
    for corpus_key in sqlite lua musl main; do
      (
        flock -x 8
        for label in "${modes[@]}"; do "$shared/lock.sh" bash "$d/one.sh" "$r" "$label" "$corpus_key" "$3"; done
      ) 8>"$shared/our-timing.lock"
      o="$d/results/$3-$corpus_key-$r"; cmp "$o-base.objects" "$o-new.objects"
      if [[ $3 != stage ]]; then cmp "$o-base.out" "$o-new.out"; cmp "$o-base.err" "$o-new.err"; fi
    done
done
