#!/usr/bin/env bash
set -eu
d=$(cd "$(dirname "$0")" && pwd); cd "$d/../reader-value-pr"; export d
export PATH="$HOME/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH"
clang --version | head -1
for kind in checker driver; do
    export kind
    seq 1 8 | xargs -P "${CORES:-2}" -IXX bash -c 'set -eu; if [[ $kind == checker ]]; then args=(test-checker --seed 133); else args=(test-checker-driver --executable "$PWD/build/compiler" --in-process); fi; status=0; timeout 900 build/compiler "${args[@]}" --part "$1/8" > "$d/shards/$kind-$1.log" 2>&1 || status=$?; echo "$status" > "$d/shards/$kind-$1.status"; exit "$status"' bash XX
done
