#!/usr/bin/env bash
set -euo pipefail
d=$(cd "$(dirname "$0")" && pwd); shared="$HOME/buster-fast-bench/2850-codex-step2"
round=$1; lab=$2; workload=$3; kind=$4
cd "$shared"; source ./corpora.sh
main_arguments="-march=native -I$shared/pooled-main-source/src -fwrapv -funsigned-char --predefines $shared/proof-predefines.h $shared/pooled-main-source/src/buster/compiler/main.c"
name="${workload}_arguments"; eval "args=(${!name})"; args=(--lanes 1 -c "${args[@]}")
case $workload in sqlite|main) num=1; args+=(-o unit.o);; lua) num=34;; musl) num=1336;; esac
exe=$d/compiler; if [[ $lab == base ]]; then exe="$shared/results/constbaseb86/compiler"; fi
mkdir -p "$d/scratch/$workload" "$d/results"
stem="$d/results/$kind-$workload-$round-$lab"
cd "$d/scratch/$workload"; rm -f -- ./*.o
case $kind in
   pmu) taskset -c 2 perf stat --no-big-num -x, -o "$stem.perf" -e '{cycles:u,instructions:u,cycles:k,instructions:k}' -e task-clock,page-faults,context-switches,cpu-migrations -- "$exe" "${args[@]}" > "$stem.out" 2> "$stem.err";;
   stage) taskset -c 2 "$exe" --time-stages "${args[@]}" > "$stem.out" 2> "$stem.err";;
   wall) taskset -c 2 "$shared/results/baked177/compiler" time-runs --runs 1 --warmups 1 --executable "$exe" --list "${args[@]}" > "$stem.wall" 2> "$stem.err"; touch "$stem.out";;
   warnings) taskset -c 2 "$exe" -Wall -Wextra "${args[@]}" > "$stem.out" 2> "$stem.err";;
   debug) taskset -c 2 "$exe" -g "${args[@]}" > "$stem.out" 2> "$stem.err";;
esac
python3 "$shared/full-chain-manifest.py" "$stem.objects" "$num"
date -u +%FT%TZ > "$stem.done"
