#!/usr/bin/env bash
set -euo pipefail
d=$(cd "$(dirname "$0")" && pwd); cd "$d"
shared="$HOME/buster-fast-bench/2850-codex-step2"
base=b86eadcbd3d6c5cdf687f6b67b0281df2ac34034
git clone -q --local --no-checkout "$shared/src" src
if ! git -C src cat-file -e "$base" 2>/dev/null; then git -C src fetch -q https://github.com/buster14a/buster "$base"; fi
git -C src checkout -q --detach "$base"
git -C src apply "$d/candidate.patch"; git -C src add src
git -C src write-tree > built.tree; cmp expected.tree built.tree
cd src
"$shared/lock.sh" bash -c './build.sh --config Release' > "$d/build.log" 2>&1
cp build/compiler "$d/compiler"
sha256sum "$d/compiler" "$shared/results/constbaseb86/compiler" > "$d/identities"
date -u +%FT%TZ > "$d/built"
