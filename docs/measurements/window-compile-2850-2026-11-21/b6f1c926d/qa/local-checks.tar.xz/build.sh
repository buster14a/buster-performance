#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;cd ../tier0-value-classes
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >"$d/build.log" 2>&1;cp ../buster/build/predefines.h build/predefines.h
bash "$d/check.sh" > "$d/check.log" 2>&1
