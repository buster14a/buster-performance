#include <stdint.h>
#include <stdio.h>
#include <limits.h>
#include <immintrin.h>
#include <unistd.h>
#include <sys/mman.h>
static __mmask64 tier0_lanes(int64_t first, uint32_t count)
{
    const int64_t low = first < 0 ? -first : 0;
    const int64_t high = (int64_t)count - first;
    uint64_t mask = 0;
    if (high > low)
    {
        const uint64_t below_high = high >= 64 ? ~0ull : (1ull << high) - 1;
        const uint64_t below_low = low >= 64 ? ~0ull : (1ull << low) - 1;
        mask = below_high & ~below_low;
    }
    return (__mmask64)mask;
}
static void tier0_vector_value_bytes(const uint64_t* values, uint32_t count, __m512i* low_bytes, __m512i* width_bytes)
{
    _Alignas(64) uint8_t low[64];
    _Alignas(64) uint8_t width[64];
    for (uint32_t lane = 0; lane < count; lane += 8)
    {
        const __mmask8 live = (__mmask8)tier0_lanes(lane, count);
        const __m512i value = _mm512_maskz_loadu_epi64(live, values + lane);
        const __m512i sign = _mm512_srai_epi64(value, 63);
        const __m512i zeros = _mm512_lzcnt_epi64(_mm512_xor_si512(value, sign));
        const __m512i signed_width = _mm512_or_si512(zeros, _mm512_and_si512(sign, _mm512_set1_epi64(128)));
        _mm_storel_epi64((__m128i*)(low + lane), _mm512_cvtepi64_epi8(value));
        _mm_storel_epi64((__m128i*)(width + lane), _mm512_cvtepi64_epi8(signed_width));
    }
    const __mmask64 live = tier0_lanes(0, count);
    *low_bytes = _mm512_maskz_loadu_epi8(live, low);
    *width_bytes = _mm512_maskz_loadu_epi8(live, width);
}

int main(void)
{
    const uint64_t page = (uint64_t)sysconf(_SC_PAGESIZE);
    uint8_t* memory = mmap(0, 2 * page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (memory == MAP_FAILED || mprotect(memory + page, page, PROT_NONE) != 0)
        return 1;
    uint64_t seed = UINT64_C(0X7da27570a7ef595b);
    uint32_t checked = 0;
    for (uint32_t n = 0; n <= 64; n++)
    {
        uint64_t* values = (uint64_t*)(memory + page) - n;
        for (uint32_t row = 0; row < 256; row++)
        {
            for (uint32_t j = 0; j < n; j++)
            {
                seed ^= seed >> 12;
                seed ^= seed << 25;
                seed ^= seed >> 27;
                const uint64_t bit = UINT64_C(1) << ((row + j) & 63);
                const uint64_t sides[] = { bit - 1, bit, bit + 1, -bit - 1, -bit, -bit + 1, seed, seed >> (row & 63) };
                values[j] = sides[(row ^ j) & 7];
            }
            __m512i lows, widths;
            tier0_vector_value_bytes(values, n, &lows, &widths);
            const uint64_t fits32 = _mm512_cmpge_epi8_mask(_mm512_and_si512(widths, _mm512_set1_epi8(127)), _mm512_set1_epi8(33));
            const uint64_t fits8u = _mm512_cmpge_epi8_mask(widths, _mm512_set1_epi8(56));
            const uint64_t fits31u = _mm512_cmpge_epi8_mask(widths, _mm512_set1_epi8(33));
            const uint64_t zero = _mm512_cmpeq_epi8_mask(widths, _mm512_set1_epi8(64));
            uint8_t low[64];
            _mm512_storeu_si512(low, lows);
            for (uint32_t j = 0; j < n; j++)
            {
                const uint64_t v = values[j];
                if ((fits32 >> j & 1) != ((int64_t)v >= INT32_MIN && (int64_t)v <= INT32_MAX) ||
                    (fits8u >> j & 1) != (v <= UINT8_MAX) || (fits31u >> j & 1) != (v <= INT32_MAX) ||
                    (zero >> j & 1) != (v == 0) || (uint8_t)v != low[j])
                {
                    printf("mismatch at length %u, lane %u, value %016llx\n", n, j, (unsigned long long)v);
                    return 1;
                }
                checked++;
            }
        }
    }
    printf("%u guarded value lanes matched all five predicates at block sizes 0 through 64\n", checked);
}
