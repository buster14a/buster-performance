"""Compile the exact production helper and compare its classifications against 64-bit C values up to a protected page."""
import pathlib, subprocess, sys
d=pathlib.Path(__file__).resolve().parent
src=(d.parent /'tier0-value-classes/src/buster/compiler/tier0.c').read_text()
def function(defn):
    start=src.index(defn)
    return src[start:src.index('\n}',start)+2]
prefix="""#include <stdint.h>
#include <stdio.h>
#include <limits.h>
#include <immintrin.h>
#include <unistd.h>
#include <sys/mman.h>
"""
main=r"""
int main(void)
{
    const uint64_t page = (uint64_t)sysconf(_SC_PAGESIZE);
    uint8_t* memory = mmap(0, 2 * page, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (memory == MAP_FAILED || mprotect(memory + page, page, PROT_NONE) != 0)
        return 1;
    uint64_t seed = UINT64_C(0X7da27570a7ef595b);
    uint32_t checked = 0;
    for (uint32_t n = 0; n <= 64; n++)
    {
        uint64_t* values = (uint64_t*)(memory + page) - n;
        for (uint32_t row = 0; row < 256; row++)
        {
            for (uint32_t j = 0; j < n; j++)
            {
                seed ^= seed >> 12;
                seed ^= seed << 25;
                seed ^= seed >> 27;
                const uint64_t bit = UINT64_C(1) << ((row + j) & 63);
                const uint64_t sides[] = { bit - 1, bit, bit + 1, -bit - 1, -bit, -bit + 1, seed, seed >> (row & 63) };
                values[j] = sides[(row ^ j) & 7];
            }
            __m512i lows, widths;
            tier0_vector_value_bytes(values, n, &lows, &widths);
            const uint64_t fits32 = _mm512_cmpge_epi8_mask(_mm512_and_si512(widths, _mm512_set1_epi8(127)), _mm512_set1_epi8(33));
            const uint64_t fits8u = _mm512_cmpge_epi8_mask(widths, _mm512_set1_epi8(56));
            const uint64_t fits31u = _mm512_cmpge_epi8_mask(widths, _mm512_set1_epi8(33));
            const uint64_t zero = _mm512_cmpeq_epi8_mask(widths, _mm512_set1_epi8(64));
            uint8_t low[64];
            _mm512_storeu_si512(low, lows);
            for (uint32_t j = 0; j < n; j++)
            {
                const uint64_t v = values[j];
                if ((fits32 >> j & 1) != ((int64_t)v >= INT32_MIN && (int64_t)v <= INT32_MAX) ||
                    (fits8u >> j & 1) != (v <= UINT8_MAX) || (fits31u >> j & 1) != (v <= INT32_MAX) ||
                    (zero >> j & 1) != (v == 0) || (uint8_t)v != low[j])
                {
                    printf("mismatch at length %u, lane %u, value %016llx\n", n, j, (unsigned long long)v);
                    return 1;
                }
                checked++;
            }
        }
    }
    printf("%u guarded value lanes matched all five predicates at block sizes 0 through 64\n", checked);
}
"""
(d/'width-oracle.c').write_text(prefix+function('static __mmask64 tier0_lanes(int64_t first, uint32_t count)\n{')+'\n'+function('static void tier0_vector_value_bytes')+'\n'+main)
subprocess.run([sys.argv[1],'-std=gnu11','-O3','-march=native',str(d/'width-oracle.c'),'-o',str(d/'width-oracle')],check=True)
subprocess.run([str(d/'width-oracle')],check=True)
