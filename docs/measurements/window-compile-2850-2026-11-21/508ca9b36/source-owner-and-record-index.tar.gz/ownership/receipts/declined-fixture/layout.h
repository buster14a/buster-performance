struct left { char before; struct { int shared; unsigned narrow:3; }; };
struct right { long shared; int last; };
#define ACCESS(p,m) ((p)->m)
