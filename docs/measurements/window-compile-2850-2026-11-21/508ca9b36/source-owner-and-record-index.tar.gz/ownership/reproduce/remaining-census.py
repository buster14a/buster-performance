from pathlib import Path
d=Path(__file__).resolve().parent;src=(d/'../pp-structural-study/member-census.c').read_text()
s=src.replace('    if (getenv("PP_TREE"))\n    {','''    if (getenv("PP_TREE"))
    {
        uint8_t* owned=calloc(pp.output.count,1);
        if(!owned)return 19;
        for(uint32_t r=0;r<pp.output.count;r++)
            owned[r]=pp.output.kinds[r]==C_TOKEN_RAW_IDENTIFIER && (pp.output.values[r]&BUSTER_SOURCE_NAME);
''')
token='''        if (parse_options.source_member_views)
        {''';assert s.count(token)==1
s=s.replace(token,'''        if(getenv("PP_ALL_SOURCE_ROWS"))
        {
            FILE* out=fopen(getenv("PP_ALL_SOURCE_ROWS"),"w"); if(!out)return 19;
            fprintf(out,"parser-token\\tpp-row\\tlocation\\trole\\tparent-role\\tprior-kind\\tnext-kind\\tspelling\\n");
            for(uint32_t t=0;t<parser.tokens.count;t++)
            {
                const uint32_t row=parse_source_index(&parser.tokens,t);
                if(!owned[row])continue;
                const uint8_t* bytes;uint32_t length;
                if(!pp_span_spelling(&pp,row,&bytes,&length))
                {
                    const uint32_t id=pp.output.values[row];
                    if(!id)return 19;
                    bytes=intern_bytes(pp.table,id);length=intern_length(pp.table,id);
                }
                const uint32_t parent=parser.tree.parents[t];
                fprintf(out,"%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%.*s\\n",t,row,pp.output.locations[row],
                        parser.tree.roles[t],parent<parser.tokens.count?parser.tree.roles[parent]:255,
                        t?parser.tokens.kinds[t-1]:255,t+1<parser.tokens.count?parser.tokens.kinds[t+1]:255,(int)length,bytes);
            }
            fclose(out);
        }
        free(owned);
'''+token)
(d/'retained-roles.c').write_text(s)
