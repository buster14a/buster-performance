#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;v=$1
tree=$root/trees/physical-member-$v;out=$root/results/physical-member-ownership-$v;mkdir -p "$out"
if [[ ! -d $tree ]];then git -C src worktree add -q --detach "$tree" 0e1d5b825;git -C "$tree" apply "$root/pp-member-connected/$v.patch";fi
for n in {1..180};do test ! -x "$tree/build/compiler" || break;sleep 2;done
test -x "$tree/build/compiler"
source corpora.sh
main_arguments="-march=native -I$root/pooled-main-source/src -fwrapv -funsigned-char --predefines $root/proof-predefines.h $root/pooled-main-source/src/buster/compiler/main.c"
for corpus in main sqlite;do
 k=${corpus}_arguments;eval "args=(${!k})"
 for mode in ordinary compatible connected declined;do
  vars=();if [[ $mode != ordinary ]];then vars=(BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONNECTED_MEMBER_VIEWS=1);fi
  if [[ $mode == connected || $mode == declined ]];then vars+=(BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1 BUSTER_SOURCE_PHYSICAL_MEMBER_LOG="$out/$corpus-$mode.queries");fi
  if [[ $mode == declined ]];then vars+=(BUSTER_CONTROL_SKIP_TRIAL=1);fi
  f=$out/$corpus-$mode
  ./lock.sh taskset -c 2 bash -c 'f=$1;shift;set +e;"$@" >"$f.out" 2>"$f.err";echo $? >"$f.rc"' _ "$f" env "${vars[@]}" "$tree/build/compiler" --lanes 1 -c "${args[@]}" -o "$f.o" >"$f.lease" 2>&1
  cmp "$f.rc" "$out/$corpus-ordinary.rc";test "$(cat "$f.rc")" = 0;cmp "$f.o" "$out/$corpus-ordinary.o";cmp "$f.out" "$out/$corpus-ordinary.out"
  # The source-body prototype notes a declined body on stderr even without source names.
  # Save each original stream and compare user-facing diagnostics separately if present.
  sed '/^body-source-decline[[:space:]]/d' "$f.err" >"$f.diagnostics";if [[ $mode != ordinary ]];then cmp "$f.diagnostics" "$out/$corpus-ordinary.diagnostics";fi
 done
done
(cd "$out" && sha256sum *.o *.rc *.diagnostics *.queries >hashes)
