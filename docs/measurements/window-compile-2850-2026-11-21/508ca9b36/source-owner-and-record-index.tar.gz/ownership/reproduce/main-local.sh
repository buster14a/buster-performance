#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD
cd ../switch-inputs;tree=$PWD/../pregraph-warning-study/compiler-source
args=(-march=native -I"$tree/src" -fwrapv -funsigned-char --predefines "$PWD/../proof-predefines.h" "$tree/src/buster/compiler/main.c")
out=$d/owner-main;mkdir -p "$out"
for mode in ordinary compatible connected native-only declined;do
 vars=();case $mode in compatible|connected|declined)vars=(BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONNECTED_MEMBER_VIEWS=1);;esac
 case $mode in connected|declined|native-only)vars+=(BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1);;esac
 [[ $mode != declined ]] || vars+=(BUSTER_CONTROL_SKIP_TRIAL=1)
 [[ $mode != connected ]] || vars+=(BUSTER_SOURCE_PHYSICAL_MEMBER_LOG="$out/connected.queries")
 set +e;env "${vars[@]}" "$d/owner-local/compiler" --lanes 1 -c "${args[@]}" -o "$out/$mode.o" >"$out/$mode.out" 2>"$out/$mode.err";rc=$?;set -e
 echo "$rc" >"$out/$mode.rc"
 filter=$out/$mode.diagnostics;sed '/^body-source-decline[[:space:]]/d' "$out/$mode.err" >"$filter"
 cmp "$out/$mode.rc" "$out/ordinary.rc";test "$rc" = 0;cmp "$out/$mode.o" "$out/ordinary.o";cmp "$filter" "$out/ordinary.diagnostics"
done
cmp "$out/connected.err" "$out/native-only.err"
(cd "$out" && sha256sum *.o *.err >hashes)
