from collections import Counter,defaultdict
from pathlib import Path
import csv,re
d=Path(__file__).resolve().parent;src=(d/'../pp-member-connected/src/buster/compiler/c_parser.c').read_text()
roles=re.findall(r'^\s*X\((\w+),',src.split('#define BUSTER_PARSE_ROLES(X)',1)[1].split('typedef enum ParseRole',1)[0],re.M)
kinds=re.findall(r'^\s*X\((\w+)\)',src.split('#define BUSTER_PARSE_KINDS(X)',1)[1].split('typedef enum ParseKind',1)[0],re.M)
def code(table,s):return table[int(s)] if int(s)<len(table) else 'NONE'
rows=list(csv.DictReader((d/'remaining.tsv').open(),delimiter='\t'))
c=Counter();parents=Counter();nonmembers=Counter();pairs=Counter();group=defaultdict(set)
for r in rows:
 role=code(roles,r['role']);parent=code(roles,r['parent-role']);prior=code(kinds,r['prior-kind']);after=code(kinds,r['next-kind'])
 c[role]+=1;group[role].add(r['spelling'])
 if role=='OPERAND':
  parents[parent]+=1;pairs[(prior,after)]+=1;nonmembers[r['spelling']]+=1
print('valid source names',len(rows),'unique spellings',len({r['spelling'] for r in rows}),'nonmember source names',sum(c.values())-c['MEMBER'])
print('role count distinct-spellings');print('\n'.join('%s %s %s'%(role,n,len(group[role])) for role,n in c.most_common()))
print('operand-parent counts',parents.most_common(16))
print('top operand adjacent kinds',pairs.most_common(14))
print('top operand spellings',nonmembers.most_common(14))
