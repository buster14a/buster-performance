#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;src=$PWD/../pp-name-replay/src;cc=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$cc" -O2 -march=native -fwrapv -funsigned-char -std=gnu17 -I"$src" -I"$src/buster/compiler" retained-roles.c -o retained-roles
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";cd "$d"
PP_MEMBER_VIEWS=1 PP_TREE="$PWD/remaining.tree" PP_ALL_SOURCE_ROWS="$PWD/remaining.tsv" ./retained-roles "${args[@]}" >remaining.stage
cmp remaining.tree ../pp-structural-study/span.replayed.tree
