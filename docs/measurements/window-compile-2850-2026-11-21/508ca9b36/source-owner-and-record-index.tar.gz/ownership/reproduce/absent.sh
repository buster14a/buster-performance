#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;v=$1;d=$root/results/physical-member-absent-$v;mkdir -p "$d";tree=$root/trees/physical-member-$v
test -x "$tree/build/compiler"
python3 pp-member-connected/edges.py "$d"
python3 - "$d" <<'PY'
from pathlib import Path
import sys
d=Path(sys.argv[1])
s=(d/'nested.c').read_text(); needle='a->shared + '; where=s.index(needle)
for _ in range(18):where=s.index(needle,where+len(needle))
s=s[:where]+s[where:].replace(needle,'a->not_a_field + ',1);(d/'field.c').write_text(s)
PY
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
for arm in ordinary connected clang;do
 cc=$tree/build/compiler;vars=()
 if [[ $arm == connected ]];then vars=(BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1 BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONNECTED_MEMBER_VIEWS=1 BUSTER_SOURCE_PHYSICAL_MEMBER_LOG="$d/queries");fi
 if [[ $arm == clang ]];then cc=clang;vars=(PATH="$paths:$PATH");fi
 ./lock.sh taskset -c 2 bash -c 'stem=$1;shift;set +e;"$@" >"$stem.out" 2>"$stem.err";echo $? >"$stem.rc"' _ "$d/$arm" env "${vars[@]}" "$cc" -std=gnu17 -c "$d/field.c" -o "$d/$arm.o" >"$d/$arm.lease" 2>&1
done
cmp "$d/ordinary.rc" "$d/connected.rc";cmp "$d/ordinary.rc" "$d/clang.rc";cmp "$d/ordinary.err" "$d/connected.err";cmp "$d/ordinary.out" "$d/connected.out"
test "$(cat "$d/ordinary.rc")" = 1
awk -F '\t' '$3=="not_a_field" && $4==0 && $5==0 { print; found=1 } END { exit !found }' "$d/queries" >"$d/actual-source-miss"
