from pathlib import Path
import sys
d=Path(sys.argv[1]);d.mkdir(exist_ok=True)
pad='/*'+('p'*1048576)+'*/\n'
prefix=pad+'extern int pad_spelling;\n'*150
(d/'layout.h').write_text('struct left { char before; struct { int shared; unsigned narrow:3; }; };\nstruct right { long shared; int last; };\n#define ACCESS(p,m) ((p)->m)\n')
decls='#include "layout.h"\n'
fn='int inspect(struct left* a,struct right* b){ int sum=0;\n'+('sum += a->shared + a->narrow + b->shared;\n'*36)+'return sum+ACCESS(a,shared)+b->last; }\n'
cases={'nested':decls+fn,'mapped':decls+'#line 73 "visible.c"\n'+fn,'const':decls+fn.replace('struct left*','const struct left*'),'unknown':decls+fn.replace('a->shared','a->not_a_field',1),'incomplete':'struct absent;\nint bad(struct absent* p){return p->field;}\n','nonrecord':'int bad(int value){ return value.field; }\n'}
for k,s in cases.items():(d/(k+'.c')).write_text(prefix+s)
