#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;v=$1;out=$root/results/physical-member-times-$v;mkdir -p "$out"
qualified=$root/results/physical-member-$v;test -s "$qualified/hashes"
cc=$root/trees/physical-member-$v/build/compiler
source corpora.sh;eval "args=($sqlite_arguments)"
for r in 1 2 3;do
 case $r in 1) arms=(ordinary native connected connected native ordinary);; 2) arms=(native connected ordinary ordinary connected native);; 3) arms=(connected ordinary native native ordinary connected);;esac
 for i in {0..5};do
  a=${arms[i]};vars=()
  if [[ $a != ordinary ]];then vars=(BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1);fi
  if [[ $a == connected ]];then vars+=(BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONNECTED_MEMBER_VIEWS=1);fi
  f=$out/$r-$i-$a
  ./lock.sh taskset -c 2 env "${vars[@]}" python3 -c 'import subprocess,sys,time;t=time.perf_counter_ns();p=subprocess.run(sys.argv[1:]);print(time.perf_counter_ns()-t);raise SystemExit(p.returncode)' "$cc" --lanes 1 -c "${args[@]}" -o "$f.o" >"$f.time" 2>"$f.lease"
  cmp "$f.o" "$qualified/default-ordinary.o"
 done
done
(cd "$out" && sha256sum *.o >hashes)
