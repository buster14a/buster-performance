#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;out=$d/corpus-owners;mkdir -p "$out"
cd ../switch-inputs;source ../switch-local-args.sh
for c in lua musl;do
 name=${c}_arguments;eval "args=(${!name})"
 for w in default warnings;do
  warning=();[[ $w == default ]] || warning=(-Wall -Wextra)
  for arm in ordinary connected;do
   dir=$out/$c-$w-$arm;mkdir -p "$dir"
   vars=();[[ $arm == ordinary ]] || vars=(BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONNECTED_MEMBER_VIEWS=1 BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1)
   (cd "$dir";set +e;env "${vars[@]}" "$d/owner-local/compiler" --lanes 1 -c "${warning[@]}" "${args[@]}" >stdout 2>stderr;echo $? >rc;find . -maxdepth 1 -name '*.o' -print0 |sort -z|xargs -0 -r sha256sum >objects)
  done
  a=$out/$c-$w-ordinary;b=$out/$c-$w-connected
  for ext in rc stdout objects;do cmp "$a/$ext" "$b/$ext";done
  sed '/^body-source-decline[[:space:]]/d' "$b/stderr" >"$b/diagnostics";cmp "$a/stderr" "$b/diagnostics"
  test "$(cat "$a/rc")" = 0;printf '%s %s %s identical complete objects and diagnostic streams\n' "$c" "$w" "$(wc -l <"$a/objects")" >>"$out/summary"
 done
done
