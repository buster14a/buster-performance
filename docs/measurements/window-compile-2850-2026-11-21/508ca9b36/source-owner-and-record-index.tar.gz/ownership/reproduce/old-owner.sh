#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;out=$root/results/physical-member-owner-before;mkdir -p "$out";source corpora.sh;main_arguments="-march=native -I$root/pooled-main-source/src -fwrapv -funsigned-char --predefines $root/proof-predefines.h $root/pooled-main-source/src/buster/compiler/main.c";eval "args=($main_arguments)"
for a in ordinary compatible connected;do
 vars=();[[ $a == ordinary ]] || vars=(BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONNECTED_MEMBER_VIEWS=1)
 [[ $a != connected ]] || vars+=(BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1)
 f=$out/$a
 ./lock.sh taskset -c 2 bash -c 'f=$1;shift;set +e;"$@" >"$f.out" 2>"$f.err";echo $? >"$f.rc"' _ "$f" env "${vars[@]}" "$root/trees/physical-member-v2/build/compiler" --lanes 1 -c "${args[@]}" -o "$f.o" >"$f.lease" 2>&1
 printf '%s %s\n' "$a" "$(cat "$f.rc")" >>"$out/results"
done
