set pagination off
set debuginfod enabled off
set confirm off
python
import gdb
def read(p,n):
 return int.from_bytes(gdb.selected_inferior().read_memory(p,n).tobytes(),'little')
class Returned(gdb.FinishBreakpoint):
 def __init__(self,ptr):
  super().__init__(gdb.newest_frame(),internal=True);self.ptr=ptr
 def stop(self):
  p=self.ptr;n=read(p+128,4);q=read(p+168,8);b=0
  print('source-depths',n,b)
  if n>=8192 and q:
   for suffix,ptr,size in [('',q,n*(1 if b else 4)),('.roles',read(p+160,8),n),('.parents',read(p+176,8),n*4)]:
    with open('direct-depth-study/source-depths/baseline-sqlite.bin'+suffix,'wb') as f:f.write(gdb.selected_inferior().read_memory(ptr,size).tobytes())
   pass
  return False
class Enter(gdb.Breakpoint):
 def stop(self):
  Returned(int(gdb.parse_and_eval('$rdi')))
  return False
Enter('*parse_translation_unit')
end
run
