from pathlib import Path
import json,csv,tarfile,hashlib,shutil,re
d=Path(__file__).resolve().parent;top=d.parent/'perf-counters/docs/measurements/window-compile-2850-2026-11-21'
g=top/'29f478aaf/source-qualification';g.mkdir(parents=True,exist_ok=True)
def tsv(n,rows):
 with (g/n).open('w') as out: csv.writer(out,delimiter='\t',lineterminator='\n').writerows(rows)
def data(p):return list(csv.DictReader(p.open(),delimiter='\t'))
rows=[['corpus','driver_policy','units','same','success']]
for c,n in [('main',1),('sqlite',1),('lua',34),('musl',1336)]:
 for pol in ['default','wall','all']:
  r=[x for x in data(d/(c+'.tsv')) if x['policy']==pol]
  assert len(r)==n and all(x['same']=='1' and x['code']=='0' for x in r)
  rows.append([c,pol,n,n,n])
tsv('corpora.tsv',rows)
rows=[['driver','variant','getrusage_calls','check_expressions_reported','elf_sha256']]
for mode in ['ordinary','time','window','timed-window']:
 for arm in ['base','new']:
  k=arm+'-'+mode
  trace=(d/(k+'.trace')).read_text().count('getrusage(');ts='time-stage\tcheck-expressions\t' in (d/(k+'.err')).read_text()
  assert ts==(mode in ['time','timed-window']) and trace==(33 if ts else 2 if arm=='base' else 0)
  rows.append([mode,arm,trace,int(ts),hashlib.sha256((d/(k+'.o')).read_bytes()).hexdigest()])
assert len(set(r[-1] for r in rows[1:]))==1
tsv('trace.tsv',rows)
def normalize(s):
 # Durations, shares, throughput, and their comparisons are naturally variable. Keep every other column.
 return [re.sub(r'\s(?:ns|(?:[a-z_]+)_ns|ns_per_\w+|cycles|cycles_per_\w+|tsc_ticks_per_ns|resolution_ns_per_token|timing_ticks_per_token|share|resolved)=[^\s]+','',l) for l in s.splitlines()]
b=normalize((d/'base-bench.out').read_text());n=normalize((d/'new-bench.out').read_text())
assert b==n,[(i,x,y) for i,(x,y) in enumerate(zip(b,n)) if x!=y]
(g/'benchmark-counts.txt').write_text('\n'.join(b)+'\n')
with tarfile.open(g/'receipts.tar.gz','w:gz',compresslevel=3) as tar:
 for p in sorted(set([*(d.glob('*.tsv')),*(d.glob('*.trace')),*(d.glob('*.err')),*(d.glob('*.out')),*(d.glob('checker-*.log')),d/'binaries',d/'qualify.sh',d.parent/'default-object-qa/pair.py',d/'pack.py'])):
  tar.add(p,arcname=p.name)
(g/'README.md').write_text('''# Expression profiling through the public driver

Source `29f478aafc3dc6218654f7007fb68da28d13cc72` and its parent `b86eadcbd3d6c5cdf687f6b67b0281df2ac34034` produced identical status, stdout, diagnostics and ELF in 4,116 process pairs. The four corpora comprise 1,372 translation units under the default, `-Wall -Wextra` and `-Weverything -Wno-c++-compat` policies. [Unit counts](corpora.tsv)

On the node-window fixture, tracing both executable images with and without the window counted two process resource queries in ordinary parent compiles and zero in the candidate. Each timed compile made 33 calls and reported the expression stage. All eight objects agreed. The binding benchmark produced the same per-class and per-mode counts. The two targeted checker shards passed 210,614 and 86,654 checks. [Process traces](trace.tsv) · [Benchmark counts](benchmark-counts.txt) · [Scripts, hashes and raw receipts](receipts.tar.gz)

Timings in these local receipts are diagnostic. The [locked 9700X study](../README.md) measures the complete fresh driver.
''')
