set pagination off
set debuginfod enabled off
set confirm off
python
import gdb,os
def present(addr,length):
 page=os.sysconf('SC_PAGE_SIZE');start=(addr+page-1)//page;end=(addr+length)//page;count=max(0,end-start)
 with open('/proc/%d/pagemap'%gdb.selected_inferior().pid,'rb') as pages:
  pages.seek(8*start);data=pages.read(8*count)
  assert len(data)==8*count
 return (sum(data[i+7]>>7 for i in range(0,len(data),8)),count)
def read(p,n):
 return int.from_bytes(gdb.selected_inferior().read_memory(p,n).tobytes(),'little')
class Returned(gdb.FinishBreakpoint):
 def __init__(self,ptr):
  super().__init__(gdb.newest_frame(),internal=True);self.ptr=ptr
 def stop(self):
  p=self.ptr;n=read(p+128,4);q=read(p+168,8);b=0
  print('source-depths',n,b)
  if n>=8192 and q:
   for suffix,ptr,size in [('',q,n*(1 if b else 4)),('.roles',read(p+160,8),n),('.parents',read(p+176,8),n*4)]:
    with open('final-roles-study/source-depths/baseline-sqlite.bin'+suffix,'wb') as f:f.write(gdb.selected_inferior().read_memory(ptr,size).tobytes())
   try:
    for name,offset,length in [('lefts',2752,4*n),('left_keys',2760,2*n),('works',2768,((n+63)//64)*384), ('kernel_waiting',2528,4*n), ('kernel_waiting_thresholds',2536,4*n), ('kernel_lefts',2544,4*n), ('kernel_left_key_values',2552,4*n), ('kernel_stack',2512,4*n), ('kernel_stack_keys',2520,4*n), ('secondary',2808,4*n), ('check_classes',2688,n), ('check_groups',2696,n)]:
     resident,pages=present(read(p+offset,8),length);print('precedence-resident',name,length,resident,pages)
   except OSError as error:
    print('residency-unavailable',error)
   pass
  return False
class Enter(gdb.Breakpoint):
 def stop(self):
  Returned(int(gdb.parse_and_eval('$rdi')))
  return False
Enter('*parse_translation_unit')
end
run
