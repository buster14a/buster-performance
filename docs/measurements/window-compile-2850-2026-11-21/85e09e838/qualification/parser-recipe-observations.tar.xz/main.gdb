set pagination off
set debuginfod enabled off
set confirm off
python
import gdb
def read(o,size):return int.from_bytes(gdb.selected_inferior().read_memory(o,size).tobytes(),'little')
class Kernel(gdb.Breakpoint):
 def stop(self):
  global n,roles
  k=int(gdb.parse_and_eval('$rsi')); inp=int(gdb.parse_and_eval('$rdx'))
  n=read(inp+24,4);roles=read(k+56,8)
  if n>=8192:
   with open('final-roles-study/recipe-repair/main.kinds','wb') as f:f.write(gdb.selected_inferior().read_memory(read(inp,8),n).tobytes())
  return False
class Returned(gdb.FinishBreakpoint):
 def stop(self):
  if n>=8192:
   with open('final-roles-study/recipe-repair/main.raw-roles','wb') as f:f.write(gdb.selected_inferior().read_memory(roles,n).tobytes())
  return False
class Checked(gdb.Breakpoint):
 def stop(self):
  Returned(gdb.newest_frame(),internal=True);return False
class Repair(gdb.Breakpoint):
 def stop(self):
  if n>=8192:print('repair',int(gdb.parse_and_eval('$edx')),int(gdb.parse_and_eval('$ecx')))
  return False
Kernel("*'parse_vector.buster_split'")
Checked("*'parse_check_avx512_period.buster_split'")
Repair("*'parse_fallback_item'")
end
run
