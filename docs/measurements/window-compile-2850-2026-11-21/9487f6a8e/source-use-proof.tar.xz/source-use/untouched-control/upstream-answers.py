"""Stop the untouched public checker immediately after binding and read final declaration and type columns."""
from pathlib import Path
import ast,subprocess,sys
study=Path(__file__).resolve().parent
origin=study.parent/'source-use-run-study/upstream-events.py'
source=origin.read_text().replace("study=Path(__file__).resolve().parent","study=Path(__file__).resolve().parent")
a=source.index('reader_bindings=');b=source.index('sqlite=w/',a)
source=source[:a]+'''reader_types=field_offset('CheckInputReader','declared_types')
output_declarations=field_offset('CheckInput','declarations')
output_count=field_offset('CheckInput','token_count')
print('offsets',reader_types,output_declarations,output_count)
gdb_program="""set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
break check_input_binding_events.buster_split
run
set $reader=$rdi
finish
python
import struct,gdb
p=gdb.selected_inferior()
rd=int(gdb.parse_and_eval('$reader'))
def mem(addr,n): return bytes(p.read_memory(addr,n)) if n else b''
def num(addr,n): return int.from_bytes(mem(addr,n),'little')
out=num(rd,8)
n=num(out+OCNT,4)
decls=num(out+ODECLS,8)
types=num(rd+RTYPES,8)
with open(DEST,'wb') as f:
 f.write(struct.pack('<I',n));f.write(mem(decls,n*4));f.write(mem(types,n*4))
end
continue
quit
"""
'''+source[b:]
a=source.index('gdbfile.write_text(');b=source.index('\n cmd=',a)
source=source[:a]+'''gdbfile.write_text(gdb_program.replace('RTYPES',str(reader_types)).replace('ODECLS',str(output_declarations)).replace('OCNT',str(output_count)).replace('DEST',repr(str(data))))'''+source[b:]
source=source.replace("name+'-upstream.events'","name+'-upstream.answers'").replace("name+'-upstream.gdb'","name+'-answer-reference.gdb'").replace("name+'-upstream-gdb.log'","name+'-answer-gdb.log'")
exec(compile(source,str(__file__),'exec'))
