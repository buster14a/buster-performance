# Source-ordered ordinary identifier use records

Baseline `40ae34f9d77afc42face58eff3338b7b1d1ba469` and candidate `9487f6a8e82bd57d8de814aeb5c3d80429a72a1d` were built with pinned Clang 23.1.4 on the Ryzen 9 7940HS. At each actual source function boundary the candidate projects already bound automatic and parameter object references with settled integer, floating or pointer types into the canonical declaration and type columns. Linked objects, unresolved names, labels, typedefs, existing captures and non-admitted cases retain the general publisher. Each admitted use is marked by its canonical binding event for the final consumer. Source scope, diagnostic and invalid-declaration passes continue to see the original event stream. All eight event columns, active heads, visit tallies and both final per-source-token binding answers match the GDB captures from untouched 40ae34f9d77afc42face58eff3338b7b1d1ba469. The raw certificate preserves 450 focused source-policy comparisons.

Source | Functions projected | Uses projected | All uses | Events | Bytes | Stream SHA-256
--- | --- | --- | --- | --- | --- | ---
sqlite | 2674 | 78497 | 97600 | 167474 | 4666856 | bb92830c050d0d1bbb1aa816fd0265e1dba703b92839b0bd783902dc58344d87
buster | 8667 | 95619 | 217102 | 357701 | 10281578 | be6a49dce7157aefe857b7c2705413fd79cd0fa55fcc8afc6745b74cbb5f65a8
phase-matrix | 577 | 39105 | 39681 | 46597 | 1228570 | cc84518fbeb649e10de8563f93d099f3cddf67d7afec26977b23de97fe9e87ed

The adversarial suite ran 450 source-policy pairs using warning, optimization-eligibility and recovery controls, including a 576-function alignment/run-length matrix. It compared complete output bytes, diagnostics and statuses with the upstream compiler. 32 successful linked executables also ran against pinned Clang. SQLite, Buster, 34 Lua files and 1,336 musl files added 4,116 individual source/policy pairs. The declaration-family cross-check adds 3,096 comparisons with warnings checked using supported `-Wall -Wextra`. The checker shards totaled 850,926 assertions.

The reserved physical-core study used native bare `-c` on SQLite on a Ryzen 9 7940HS. `local-ab.tsv`, `pmu.tsv`, `target-pairs.tsv` and the scripts retain all median components and synthetic positive, refused and mixed source cases. Files `pairs.log`, `pmu.log` and `target.log` summarize those samples.
