#!/bin/bash
set -eu
cd "$(dirname "$0")/../function-close-local-bindings"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >../close-local-checked-study/build.log 2>&1
cp ../default-integer-control/build/predefines.h build/predefines.h
./build/compiler test-checker --seed 2850 --part 6/8 >../close-local-checked-study/early-shard6.log 2>&1
cd ../switch-inputs
source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
BUSTER_SOURCE_USE_CENSUS=1 ../function-close-local-bindings/build/compiler -c -o ../close-local-checked-study/sqlite.candidate.o "${args[@]}" >../close-local-checked-study/sqlite.out 2>../close-local-checked-study/counter.txt
../default-integer-control/build/compiler -c -o ../close-local-checked-study/sqlite.parent.o "${args[@]}" >../close-local-checked-study/parent.out 2>../close-local-checked-study/parent.err
cmp ../close-local-checked-study/sqlite.candidate.o ../close-local-checked-study/sqlite.parent.o
python3 ../close-local-checked-study/events.py >../close-local-checked-study/events.log 2>&1
cmp ../close-local-checked-study/sqlite-candidate.answers ../proven-use-study/sqlite-upstream.answers
cmp ../close-local-checked-study/buster-candidate.answers ../proven-use-study/buster-upstream.answers
python3 ../close-local-checked-study/oracle.py >../close-local-checked-study/oracle.log 2>&1
python3 ../close-local-checked-study/local_pairs.py >../close-local-checked-study/pairs.log 2>&1
python3 ../close-local-checked-study/target_pairs.py >../close-local-checked-study/target.log 2>&1
parent=$PWD/../default-integer-control/build/compiler
new=$PWD/../function-close-local-bindings/build/compiler
out=$PWD/../close-local-checked-study/corpus
mkdir -p "$out"
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main lua musl; do var=${g}_arguments; eval "args=(${!var})"; python3 ../default-object-qa/pair.py "$out" "$g" "$parent" "$new" "${args[@]}"; done
python3 ../close-local-checked-study/pmu.py >../close-local-checked-study/pmu.log 2>&1
cd ../function-close-local-bindings
for part in {1..8}; do ./build/compiler test-checker --seed 2850 --part "$part/8" >"../close-local-checked-study/checker-$part.log" 2>&1; done
