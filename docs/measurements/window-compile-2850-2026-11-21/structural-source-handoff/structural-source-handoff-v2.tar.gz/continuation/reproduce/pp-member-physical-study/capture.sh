#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python iterate.py
printf 'pp-row\trecord-type\tspelling\tmember-slot\toffset-bits\tinherited-qualifiers\n' > semantic.tsv
BUSTER_SOURCE_PHYSICAL_MEMBER_LOG="$PWD/semantic.tsv" BUSTER_SOURCE_PHYSICAL_MEMBERS=1 bash run.sh sqlite
sha256sum semantic.tsv sqlite.o
