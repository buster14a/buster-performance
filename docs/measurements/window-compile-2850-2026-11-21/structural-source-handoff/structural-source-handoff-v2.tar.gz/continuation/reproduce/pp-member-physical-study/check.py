from pathlib import Path
import csv,collections
d=Path(__file__).resolve().parent
def rows(p):
 with p.open() as f:yield from csv.DictReader(f,delimiter='\t')
known={int(r['pp-row']):r for r in rows(d/'../source-member-trace-study/sqlite-members.tsv')}
retained={int(r['pp-row']):r for r in rows(d/'../pp-structural-study/structural-single-member-census/members.tsv')}
seen=set();total=0;miss=[]
for row in rows(d/'semantic.tsv'):
 r=int(row['pp-row']);seen.add(r);total+=1;expected=known[r]
 for col in ('record-type','spelling','member-slot','offset-bits'):
  if col=='record-type':
   a=int(row[col])&~7;b=int(expected[col])&~7
  else:a=row[col];b=expected[col]
  if a!=b:miss.append((r,col,a,b))
print('live physical queries',total,'unique real access rows',len(seen),'withheld by independent producer',len(seen&retained.keys()),'fully checked independent semantic rows',len(known),'mismatched columns',len(miss),miss[:10])
assert total>0 and not miss
