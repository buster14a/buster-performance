#include <stdio.h>
#include "buster/compiler/c_preprocessor_benchmark.c"
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];
int main(int argc,char** argv)
{
    Arena a=arena_reserve(1ull<<30);
    const char *input,*output;bool markers;PPOptions options;
    if(!pp_parse_options(argc-1,argv+1,&options,&a,&input,&output,&markers))return 2;
    options.defer_history=true;
    static InternTable table;static Preprocessor pp;
    const char* mode=getenv("PP_ID_MODE");const char* form=getenv("PP_ID_DICTIONARY");const char* tape=getenv("PP_ID_TAPE");
    if(!mode || !form || !tape)return 3;
    const bool save=strcmp(mode,"save")==0,preseed=strcmp(mode,"preseed")==0 || strcmp(mode,"exact")==0,exact=strcmp(mode,"exact")==0;
    const uint64_t start_init=pp_benchmark_nanoseconds();
    if(!intern_initialize(&table))return 4;
    if(save){pp_id_saving=fopen(tape,"wb");if(!pp_id_saving)return 5;}
    if(preseed)
    {
        FILE* f=fopen(form,"rb");if(!f)return 6;
        uint32_t count=0;if(fread(&count,4,1,f)!=1)return 6;
        for(uint32_t i=1;i<count;i++)
        {
            uint32_t n=0;if(fread(&n,4,1,f)!=1)return 6;
            uint8_t* b=malloc(n+16);if(!b || fread(b,1,n,f)!=n)return 6;
            if(intern_find_or_add(&table,b,n)!=i){fprintf(stderr,"dictionary order %u\n",i);return 7;}
            free(b);
        }
        if(fgetc(f)!=EOF || fclose(f))return 6;
    }
    if(exact)
    {
        FILE* f=fopen(tape,"rb");if(!f || fseek(f,0,SEEK_END))return 8;
        long len=ftell(f);if(len<=0 || len%4 || fseek(f,0,SEEK_SET))return 8;
        uint32_t* prepared=malloc(len);if(!prepared || fread(prepared,1,len,f)!=(size_t)len || fclose(f))return 8;
        pp_id_cursor=prepared;pp_id_end=prepared+len/4;
    }
    uint64_t started=pp_benchmark_nanoseconds();
    if(!pp_initialize(&pp,&options,&table) || !pp_run(&pp,input))return 9;
    uint64_t done=pp_benchmark_nanoseconds();
    if(exact && pp_id_cursor!=pp_id_end)return 10;
    if(save)
    {
        if(fclose(pp_id_saving))return 11;
        FILE* f=fopen(form,"wb");if(!f || fwrite(&table.count,4,1,f)!=1)return 12;
        for(uint32_t i=1;i<table.count;i++)
        {
            uint32_t n=intern_length(&table,i);if(fwrite(&n,4,1,f)!=1 || fwrite(intern_bytes(&table,i),1,n,f)!=n)return 12;
        }
        if(fclose(f))return 12;
    }
    if(getenv("PP_PRINT"))
    {
        FILE* f=fopen(getenv("PP_PRINT"),"wb");if(!f || !pp_print(&pp,f,false) || fclose(f))return 13;
    }
    printf("%lu %u %u %lu %lu %lu\n",done-started,pp.output.count,table.count,pp_id_calls,pp_id_rows,started-start_init);
    pp_release(&pp);intern_release(&table);arena_release(&a);
    return 0;
}
