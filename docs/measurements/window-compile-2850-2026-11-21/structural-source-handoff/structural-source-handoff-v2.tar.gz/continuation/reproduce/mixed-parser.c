#define BUSTER_PP_STRUCTURAL_EXPERIMENT 1
#include "buster/compiler/c_preprocessor_benchmark.c"
#include "buster/compiler/c_parser.c"
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];
static bool projected_init(Preprocessor* pp,InternTable* table,const PPOptions* options)
{
 return intern_initialize(table) && pp_initialize(pp,options,table);
}
static void projected_release(Preprocessor* pp,InternTable* table)
{
 pp_release(pp);intern_release(table);
}
int main(int argc,char** argv)
{
    Arena arena=arena_reserve(1ull<<30);
    const char *input,*output;bool markers;PPOptions options;
    if(!pp_parse_options(argc-1,argv+1,&options,&arena,&input,&output,&markers))return 2;
    options.defer_history=getenv("PP_RECORD_HISTORY")==NULL;
    options.collect_diagnostics=true;
    static Preprocessor pre,pp;
    static InternTable trial,table;
    uint64_t begin=pp_benchmark_nanoseconds(), clocks[5]={begin};
    PPProjection plan={.path=input,.forecast=true,.live=true,.handled=BUSTER_PP_NONE,.main_range=BUSTER_PP_NONE};
    const bool eager=getenv("PP_EAGER")!=NULL;
    int fd=eager?-1:open(input,O_RDONLY);struct stat st={0};
    bool possible=fd>=0 && fstat(fd,&st)==0 && st.st_size>=(1u<<20) && st.st_size<UINT32_MAX/2 && !options.assembly && !options.preprocessed &&
        !(c_language_lexer_flags(options.language)&(C_TOKENIZER_NO_LINE_COMMENTS|C_TOKENIZER_CPLUSPLUS));
    uint32_t length=possible?(uint32_t)st.st_size:0;
    uint8_t* raw=possible?mmap(NULL,length,PROT_READ,MAP_PRIVATE,fd,0):MAP_FAILED;
    if(fd>=0)close(fd);
    possible=possible && raw!=MAP_FAILED;
    if(possible)
    {
        plan.original_length=length;plan.device=(uint64_t)st.st_dev;plan.inode=(uint64_t)st.st_ino;
        plan.index.capacity=length/8+8;
        plan.index.directives=malloc((size_t)plan.index.capacity*sizeof(*plan.index.directives));
        plan.index.trigraphs=options.trigraphs;
        plan.index.digit_separators=(c_language_lexer_flags(options.language)&C_TOKENIZER_NO_DIGIT_SEPARATORS)==0;
        possible=plan.index.directives && pp_structure_scan(raw,length,&plan.index);
    }
    clocks[1]=pp_benchmark_nanoseconds();
    if(possible)
    {
        size_t count=plan.index.count+1;
        plan.virtual_bytes=malloc((size_t)length+count+128);
        plan.segments=malloc(2*count*sizeof(*plan.segments));
        plan.predicted=calloc(count,1);plan.observed=calloc(count,1);
        possible=plan.virtual_bytes && plan.segments && plan.predicted && plan.observed;
    }
    uint32_t total_skipped=0, omitted=0,unverified=0,predict_bytes=0,live_bytes=0;
    clocks[2]=pp_benchmark_nanoseconds();
    plan.prepared=0;plan.primary=NULL;
    pp_projection=possible?&plan:NULL;
    if(!projected_init(&pp,&table,&options))return 1;
    bool okay=pp_run(&pp,input);
    if (possible)
    {
        predict_bytes=plan.virtual_length;live_bytes=plan.reached_bytes;
        total_skipped=plan.reached;omitted=plan.reached_rows;
        for(uint32_t i=0;i<=plan.index.count;i++)
        {
            const uint32_t a=i?plan.index.directives[i-1].end:0;
            const uint32_t b=i<plan.index.count?plan.index.directives[i].hash:length;
            unverified+=(b>a && plan.predicted[i] && !plan.observed[i]);
        }
        if (!okay || plan.failed || plan.prepared!=1 || unverified)
        {
            projected_release(&pp,&table);possible=false;pp_projection=NULL;
            if(!projected_init(&pp,&table,&options))return 1;
            okay=pp_run(&pp,input);
        }
    }
    clocks[3]=pp_benchmark_nanoseconds();pp_projection=NULL;
    if (getenv("PP_DEBUG")) fprintf(stderr,"structural rejection byte %u; failed %u; prepared %u; physical rows %u\n",plan.index.unsafe,plan.failed,plan.prepared,plan.index.count);
    pp_diagnostic_publish(&pp);
    if(!okay)return 1;
    printf("%lu %u %u %u %u %u %u %u %u %lu %lu %lu\n",clocks[3]-begin,pp.output.count,possible,plan.index.count,total_skipped,omitted,unverified,predict_bytes,live_bytes,clocks[1]-begin,clocks[2]-clocks[1],clocks[3]-clocks[2]);
    if (getenv("PP_UNLINK_PROBE") && unlink(getenv("PP_UNLINK_PROBE"))!=0) return 13;
    if (getenv("PP_DEMAND_REVERSE"))
    {
        for (uint32_t j=pp.output.count;j>0;j--)
        {
            const uint32_t i=j-1;
            if (pp.output.kinds[i]==C_TOKEN_RAW_IDENTIFIER && (i%3)==0 && (pp.output.values[i]&BUSTER_SOURCE_NAME))
            {
                const uint8_t* bytes;
                uint32_t len;
                if(!pp_span_spelling(&pp,i,&bytes,&len)) return 14;
                const IdentId id=pp_span_identity(&pp,i);
                if(!id || id!=pp_span_identity(&pp,i) || intern_length(pp.table,id)!=len || memcmp(intern_bytes(pp.table,id),bytes,len)) return 14;
            }
        }
    }
    uint64_t handoff_begin=pp_benchmark_nanoseconds();
    unsigned demanded=0;
    const bool use_identity=getenv("PP_CONSUME_NAMES")!=NULL;
    if(use_identity)
    {
        for(uint32_t i=0;i<pp.output.count;i++) if(pp.output.kinds[i]==C_TOKEN_RAW_IDENTIFIER && (pp.output.values[i]&BUSTER_SOURCE_NAME))
        {
            if(!pp_span_identity(&pp,i)) return 9;
            demanded++;
        }
    }
    if (getenv("PP_SPAN_REPORT")) fprintf(stderr,"span handoff %u gaps %u rows %u source names, %u demanded in %lu ns, %u canonical entries, %u header-backed names, %u forced raw identities\n",
            plan.span_gaps,plan.span_rows,plan.span_names,demanded,pp_benchmark_nanoseconds()-handoff_begin,table.count,plan.header_names,plan.forced_names);
    if (getenv("PP_TREE"))
    {
        static Parser parser;
        ParseOptions parse_options={0};
        if (!parse_initialize(&parser,&parse_options,options.language)) return 10;
        if (!parse_translation_unit(&parser,&pp))
        {
            parse_print_diagnostics(&parser,&pp);
            return 11;
        }
        FILE* file=fopen(getenv("PP_TREE"),"wb");if(!file)return 12;
        const uint32_t n=parser.tokens.count;
        if(fwrite(&n,4,1,file)!=1 || fwrite(parser.tokens.kinds,1,n,file)!=n ||
           fwrite(parser.tree.roles,1,n,file)!=n || fwrite(parser.tree.depths,4,n,file)!=n ||
           fwrite(parser.tree.parents,4,n,file)!=n || fclose(file)!=0) return 12;
        parse_release(&parser);
    }
    if(getenv("PP_PRINT"))
    {
        FILE* f=fopen(getenv("PP_PRINT"),"w");
        if(!f || !pp_print(&pp,f,false) || fclose(f)!=0)return 6;
    }
    if(getenv("PP_ROWS"))
    {
        FILE* f=fopen(getenv("PP_ROWS"),"wb");if(!f)return 7;
        for(uint32_t i=0;i<pp.output.count;i++)
        {
            const uint8_t kind=pp.output.kinds[i];const uint32_t val=pp.output.values[i];
            bool named=kind==C_TOKEN_RAW_IDENTIFIER || (kind>=BUSTER_PP_KIND_KEYWORD && kind<BUSTER_PP_KIND_PRAGMA_END);
            const uint32_t v=named?intern_length(&table,val):val;
            const uint8_t k[2]={kind,pp.output.flags[i]};
            fwrite(k,1,2,f);fwrite(pp.output.locations+i,4,1,f);fwrite(&v,4,1,f);
            if(named)fwrite(intern_bytes(&table,val),1,v,f);
        }
        fclose(f);
    }
    projected_release(&pp,&table);arena_release(&arena);
    if(raw!=MAP_FAILED)munmap(raw,length);
    free(plan.index.directives);free(plan.virtual_bytes);free(plan.segments);free(plan.predicted);free(plan.observed);
    return 0;
}
