from pathlib import Path
from statistics import median
import re
for p in sorted(Path('.').glob('structural-single-source-names-v*')):
 if not (p/'hashes').is_file():continue
 print(p.name)
 for a in ['baseline','spans','consumed']:
  vals=[];total=[];dem=[]
  for f in p.glob('*-*-'+a+'.tsv'):
   x=int(f.read_text().split()[0]);m=re.search(r'(\d+) demanded in (\d+) ns',f.with_suffix('.lease').read_text());vals.append(x);total.append(x+int(m[2]));dem.append(int(m[1]))
  if vals:print(a,len(vals),round(median(vals)/1e6,4),round(median(total)/1e6,4),int(median(dem)))
 print((p/'deferred-spans.lease').read_text().splitlines()[-1])
p=Path('structural-single-idbound')
for k in ['original','both']:
 for a in ['baseline','preseed','exact']:
  vals=[int(f.read_text().split()[0]) for f in p.glob(k+'-?-?-'+a+'.tsv') if f.read_text().strip()]
  if vals:print(k,a,len(vals),round(median(vals)/1e6,4),(p/(k+'-'+a+'.check')).read_text().strip())
