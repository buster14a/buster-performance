#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;v=v7;src=$root/trees/structuralnames$v/src
out=$root/results/structural-single-member-census;mkdir -p "$out"
source corpora.sh;eval "args=($sqlite_arguments)"
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
lock() { ./lock.sh taskset -c 2 "$@"; }
lock env PATH="$paths:$PATH" clang -O3 -gline-tables-only -fno-omit-frame-pointer -std=gnu17 -fwrapv -funsigned-char -march=native -I"$src" -I"$src/buster/compiler" "$root/pp-structural/member-census.c" -o "$out/probe" >"$out/build" 2>&1
lock env PP_MEMBER_VIEWS=1 PP_TREE="$out/main.tree" PP_SPAN_REPORT=1 PP_MEMBER_ROWS="$out/members.tsv" "$out/probe" "${args[@]}" >"$out/result" 2>"$out/lease"
cmp "$out/main.tree" "$root/results/structural-single-source-names-v6fixed/deferred-baseline.tree"
(cd "$out" && sha256sum probe main.tree members.tsv >hashes)
