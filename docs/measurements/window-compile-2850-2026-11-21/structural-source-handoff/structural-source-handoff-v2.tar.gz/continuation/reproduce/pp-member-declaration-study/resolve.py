from collections import Counter,defaultdict
from bisect import bisect_right
from dataclasses import dataclass
import csv
from pathlib import Path
root=Path(__file__).resolve().parent
def tsv(path):
 with path.open() as f: yield from csv.DictReader(f,delimiter='\t')
@dataclass(frozen=True)
class Field:
 slot:int
 name:str
 canonical:int
 typ:int
 offset:int
 width:int
 child:int

events=defaultdict(lambda:defaultdict(list))
for d in tsv(root/'declarations.tsv'):
 record,close=map(int,(d['record-type'],d['closing-token']))
 events[record][close].append(Field(int(d['member-slot']),d['spelling'],int(d['declared-id']),int(d['declared-type']),int(d['offset-bits']),int(d['bit-width']),int(d['anonymous-record'])))
by_record={record:sorted(history) for record,history in events.items()}
def lookup(record,close,name):
 versions=by_record.get(record&~7,[])
 i=bisect_right(versions,close)
 if i==0:return None
 for field in events[record&~7][versions[i-1]]:
  if name and field.name==name: return (field,field.offset,record&7)
  if field.child:
   inner=lookup(field.typ,close,name)
   if inner:
    member,offset,quals=inner
    return (member,field.offset+offset,(record&7)|quals)
 return None

available={int(s['pp-row']):s for s in tsv(root/'../pp-structural-study/structural-single-member-census/members.tsv')}
counts={k:Counter() for k in ('all','source')}
seen={k:set() for k in counts}
mismatches=[]
with (root/'resolved.tsv').open('w') as fp:
 print('pp-row','source','close','record','spelling','member-slot','offset-bits','bit-width','declared-type','declared-id','inherited-qualifiers','checked-type',sep='\t',file=fp)
 for a in tsv(root/'../source-member-trace-study/sqlite-members.tsv'):
  row=int(a['pp-row']);record=int(a['record-type']);close=int(a['closing-token'])
  physical=available.get(row)
  spelling=physical['spelling'] if physical else a['spelling']
  if physical:assert a['pp-location']==physical['pp-location'] and a['parser-member-token']==physical['parser-token'] and spelling==a['spelling']
  answer=lookup(record,close,spelling)
  cohort=['all','source'] if physical else ['all']
  for key in cohort:counts[key]['total']+=1
  if not answer:
   mismatches.append((row,'decl missing',record,spelling));continue
  f,offset,quals=answer
  expected=tuple(map(int,(a['member-slot'],a['offset-bits'],a['bit-width'],a['canonical-name-id'])))
  chosen=(f.slot,offset,f.width,f.canonical)
  if expected!=chosen:mismatches.append((row,'field',expected,chosen))
  for key in cohort:
   counts[key]['exact field slot, offset, width and canonical declaration']+=expected==chosen
   counts[key]['exact checked type with inherited qualifiers']+=(f.typ|quals)==int(a['result-type'])
   counts[key]['bitfields']+=f.width>0
   seen[key].add(f.slot)
  print(row,bool(physical),close,record,spelling,f.slot,offset,f.width,f.typ,f.canonical,quals,a['result-type'],sep='\t',file=fp)
print('completed record types',len(events),'record snapshots',sum(map(len,events.values())),'declared slots',len({f.slot for v in events.values() for fields in v.values() for f in fields}))
for k,c in counts.items():print(k,dict(c),'distinct selected slots',len(seen[k]))
last=max(t for v in events.values() for t in v)
assert all(lookup(r,last,'__absent_internal_control_probe') is None for r in events)
names=defaultdict(set)
for r in events:
 for f in events[r][by_record[r][-1]]:
  if f.name:names[f.name].add(f.slot)
print('one spelling on multiple independent declarations',sum(len(v)>1 for v in names.values()))
print('mismatches',len(mismatches),'sample',mismatches[:12])
if mismatches:raise SystemExit(1)
