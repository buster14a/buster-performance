#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python iterate.py
printf 'closing-token\ttag\trecord-type\tmember-slot\tdeclared-id\tspelling\tdeclared-type\toffset-bits\tbit-width\tflags\tanonymous-record\n' >declarations.tsv
BUSTER_MEMBER_DECLARATIONS="$PWD/declarations.tsv" bash run.sh sqlite
sha256sum declarations.tsv sqlite.o
