from pathlib import Path
import csv,collections
root=Path(__file__).resolve().parent
def rows(p):
 with p.open() as f: return list(csv.DictReader(f,delimiter='\t'))
source=rows(root/'../pp-structural-study/structural-single-member-census/members.tsv')
access=rows(root/'../source-member-trace-study/sqlite-members.tsv')
available={int(s['pp-row']):s for s in source}
used=set()
assert len(available)==len(source)
for a in access:
 s=available.get(int(a['pp-row']))
 if s is None:continue
 assert a['pp-location']==s['pp-location'] and a['spelling']==s['spelling'] and a['parser-member-token']==s['parser-token'],(a,s)
 used.add(int(a['pp-row']))
print('actual checked accesses',len(access),'physical selectors at parser exit',len(source),'matched by original location, PP row, parser index and physical spelling',len(used),'other checked accesses',len(access)-len(used),'other physical selectors',len(available)-len(used))
print('distinct source spellings',len({available[i]['spelling'] for i in used}),'selected members',len({a['member-slot'] for a in access if int(a['pp-row']) in used}))
