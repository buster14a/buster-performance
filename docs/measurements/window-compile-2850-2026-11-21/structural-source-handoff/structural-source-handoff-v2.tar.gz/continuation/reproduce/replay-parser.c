#include "buster/compiler/c_preprocessor_benchmark.c"
#include "buster/compiler/c_parser.c"
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];
static bool projected_init(Preprocessor* pp,InternTable* table,const PPOptions* options)
{
 return intern_initialize(table) && pp_initialize(pp,options,table);
}
static void projected_release(Preprocessor* pp,InternTable* table)
{
 pp_release(pp);intern_release(table);
}
int main(int argc,char** argv)
{
    Arena arena=arena_reserve(1ull<<30);
    const char *input,*output;bool markers;PPOptions options;
    if(!pp_parse_options(argc-1,argv+1,&options,&arena,&input,&output,&markers))return 2;
    options.defer_history=getenv("PP_RECORD_HISTORY")==NULL;
    options.collect_diagnostics=true;
    static Preprocessor pre,pp;
    static InternTable trial,table;
    uint64_t begin=pp_benchmark_nanoseconds();
    const bool eager=getenv("PP_EAGER")!=NULL;
    PPNameViews plan={0};
    if(!projected_init(&pp,&table,&options))return 1;
    pp.name_views=eager?NULL:&plan;
    bool okay=pp_run(&pp,input);
    const uint64_t finish=pp_benchmark_nanoseconds();
    pp_diagnostic_publish(&pp);
    if(!okay)return 1;
    printf("%lu %u %u %u %u %u %u %u %u %u %u %u\n",finish-begin,pp.output.count,!eager,0,0,0,0,0,0,0,0,0);
    if (getenv("PP_UNLINK_PROBE") && unlink(getenv("PP_UNLINK_PROBE"))!=0) return 13;
    if (getenv("PP_DEMAND_REVERSE"))
    {
        for (uint32_t j=pp.output.count;j>0;j--)
        {
            const uint32_t i=j-1;
            if (pp.output.kinds[i]==C_TOKEN_RAW_IDENTIFIER && (i%3)==0 && (pp.output.values[i]&BUSTER_SOURCE_NAME))
            {
                const uint8_t* bytes;
                uint32_t len;
                if(!pp_span_spelling(&pp,i,&bytes,&len)) return 14;
                const IdentId id=pp_span_identity(&pp,i);
                if(!id || id!=pp_span_identity(&pp,i) || intern_length(pp.table,id)!=len || memcmp(intern_bytes(pp.table,id),bytes,len)) return 14;
            }
        }
    }
    uint64_t handoff_begin=pp_benchmark_nanoseconds();
    unsigned demanded=0;
    const bool use_identity=getenv("PP_CONSUME_NAMES")!=NULL;
    if(use_identity)
    {
        for(uint32_t i=0;i<pp.output.count;i+=16)
        {
            const uint32_t n=pp.output.count-i;
            const __mmask16 valid=n>=16?0xffffu:(__mmask16)_bzhi_u32(0xffff,n);
            const __mmask16 names=_mm_mask_cmpeq_epi8_mask(valid,_mm_maskz_loadu_epi8(valid,pp.output.kinds+i),_mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            demanded+=(uint32_t)__builtin_popcount(names&_mm512_movepi32_mask(_mm512_maskz_loadu_epi32(names,pp.output.values+i)));
        }
        if(!pp_span_consume_all(&pp))return 9;
    }
    if (getenv("PP_SPAN_REPORT")) fprintf(stderr,"span handoff %u gaps %u rows %u source names, %u demanded in %lu ns, %u canonical entries, %u header-backed names, %u forced raw identities\n",
            plan.span_gaps,plan.span_rows,plan.span_names,demanded,pp_benchmark_nanoseconds()-handoff_begin,table.count,plan.header_names,plan.forced_names);
    if (getenv("PP_TREE"))
    {
        static Parser parser;
        ParseOptions parse_options={.source_member_views=getenv("PP_MEMBER_VIEWS")!=NULL};
        if (!parse_initialize(&parser,&parse_options,options.language)) return 10;
        if (!parse_translation_unit(&parser,&pp))
        {
            parse_print_diagnostics(&parser,&pp);
            return 11;
        }
        if (parse_options.source_member_views)
        {
            uint32_t withheld=0,requested=0;
            for(uint32_t t=1;t<parser.tokens.count;t++)
            {
                const uint32_t row=parse_source_index(&parser.tokens,t);
                if(pp.output.kinds[row]==C_TOKEN_RAW_IDENTIFIER && (pp.output.values[row]&BUSTER_SOURCE_NAME))
                {
                    if(parser.tokens.names[t]!=0 || (parser.tokens.kinds[t-1]!=PARSE_KIND_PERIOD && parser.tokens.kinds[t-1]!=PARSE_KIND_ARROW))return 15;
                    withheld++;
                    if(t%3==0)
                    {
                        const IdentId id=parse_demand_member(&parser,&pp,t);
                        if(!id || parse_demand_member(&parser,&pp,t)!=id || parser.tokens.names[t]!=id)return 16;
                        requested++;
                    }
                }
            }
            if(getenv("PP_SPAN_REPORT")) fprintf(stderr,"actual parser withheld %u selector identities, semantic reader demanded %u\n",withheld,requested);
        }
        FILE* file=fopen(getenv("PP_TREE"),"wb");if(!file)return 12;
        const uint32_t n=parser.tokens.count;
        if(fwrite(&n,4,1,file)!=1 || fwrite(parser.tokens.kinds,1,n,file)!=n ||
           fwrite(parser.tree.roles,1,n,file)!=n || fwrite(parser.tree.depths,4,n,file)!=n ||
           fwrite(parser.tree.parents,4,n,file)!=n || fclose(file)!=0) return 12;
        parse_release(&parser);
    }
    if (getenv("PP_REPLAY_HISTORY") && !pp_history_ensure(&pp)) return 17;
    if(getenv("PP_PRINT"))
    {
        FILE* f=fopen(getenv("PP_PRINT"),"w");
        if(!f || !pp_print(&pp,f,false) || fclose(f)!=0)return 6;
    }
    if(getenv("PP_ROWS"))
    {
        FILE* f=fopen(getenv("PP_ROWS"),"wb");if(!f)return 7;
        for(uint32_t i=0;i<pp.output.count;i++)
        {
            const uint8_t kind=pp.output.kinds[i];const uint32_t val=pp.output.values[i];
            bool named=kind==C_TOKEN_RAW_IDENTIFIER || (kind>=BUSTER_PP_KIND_KEYWORD && kind<BUSTER_PP_KIND_PRAGMA_END);
            const uint32_t v=named?intern_length(&table,val):val;
            const uint8_t k[2]={kind,pp.output.flags[i]};
            fwrite(k,1,2,f);fwrite(pp.output.locations+i,4,1,f);fwrite(&v,4,1,f);
            if(named)fwrite(intern_bytes(&table,val),1,v,f);
        }
        fclose(f);
    }
    projected_release(&pp,&table);arena_release(&arena);
    return 0;
}
