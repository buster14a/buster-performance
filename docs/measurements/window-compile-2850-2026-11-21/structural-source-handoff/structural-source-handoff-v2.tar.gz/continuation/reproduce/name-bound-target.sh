#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;out=$PWD/results/structural-single-idbound
tree=$PWD/trees/structural-idbound;mkdir -p "$out"
if ! test -d "$tree";then git -C src worktree add -q --detach "$tree" 0e1d5b825;git -C "$tree" apply "$root/pp-structural/idbound.patch";fi
src=$tree/src;source corpora.sh;eval "args=($sqlite_arguments)";input=${args[-1]}
paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
lock() { ./lock.sh taskset -c 2 "$@"; }
lock env PATH="$paths:$PATH" clang -O3 -gline-tables-only -fno-omit-frame-pointer -std=gnu17 -fwrapv -funsigned-char -march=native -I"$src" -I"$src/buster/compiler" "$root/pp-structural/name-bound.c" "$root/pp-structural/overlay.c" -Wl,--wrap=open -o "$out/probe" >"$out/build" 2>&1
for kind in original both;do
 over=$input;[[ $kind != both ]] || over=$root/pp-structural/both.c
 vars=(PP_OVERLAY_ORIGINAL="$input" PP_OVERLAY_BYTES="$over" PP_ID_DICTIONARY="$out/$kind.dictionary" PP_ID_TAPE="$out/$kind.tape")
 for arm in save baseline preseed exact;do
  lock env "${vars[@]}" PP_ID_MODE="$arm" PP_PRINT="$out/$kind-$arm.i" "$out/probe" "${args[@]}" >"$out/$kind-$arm.check" 2>"$out/$kind-$arm.lease"
  cmp "$out/$kind-$arm.i" "$root/results/active-source-profile/ordinary.i"
 done
 for r in 1 2 3;do
  case $r in 1)arms=(baseline preseed exact exact preseed baseline);;2)arms=(preseed exact baseline baseline exact preseed);;3)arms=(exact baseline preseed preseed baseline exact);;esac
  for i in {0..5};do
   arm=${arms[i]};lock env "${vars[@]}" PP_ID_MODE="$arm" "$out/probe" "${args[@]}" >"$out/$kind-$r-$i-$arm.tsv" 2>"$out/$kind-$r-$i-$arm.lease"
  done
 done
done
(cd "$out" && sha256sum probe *.i *.tape *.dictionary >hashes)
