struct S{int n;struct U*p __attribute__((counted_by(n))); int bad[-1];}; struct U; struct T{struct U *p;};struct U*f(struct T*x){return x->p;}
