struct Node;struct A{int n;int a[] __attribute__((counted_by(n)));};struct Node*f(struct Node*n){return n;}
