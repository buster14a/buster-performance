struct Node; struct A{unsigned len;struct Node *p __attribute__((counted_by(len)));}; struct Node{int x;};int f(struct A*a){return a->p->x;}
