struct I;struct C{unsigned n;struct I*p __attribute__((counted_by(n)));};struct I**f(struct C*x){return &x->p;}
