struct I;typedef struct I *P __attribute__((aligned(8)));struct C{unsigned n;P p __attribute__((counted_by(n)));};struct I*f(struct C*x){return x->p;}
