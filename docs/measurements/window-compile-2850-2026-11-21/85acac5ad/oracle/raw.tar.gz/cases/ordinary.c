struct Node;struct A{unsigned len;struct Node *p;};struct Node*f(struct A*a){return a->p;}
