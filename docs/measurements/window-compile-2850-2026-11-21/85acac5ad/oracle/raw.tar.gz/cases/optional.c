struct Node;struct A{unsigned len;struct Node*p __attribute__((counted_by_or_null(len)));};struct Node*f(struct A*a){return a->p;}
