struct Node;struct A{unsigned len;struct Node*p __attribute__((sized_by(len)));};struct Node*f(struct A*a){return a->p;}
