struct Node;struct A{unsigned len;struct Node*p __attribute__((counted_by(len)));};struct Outer{struct A a;};int f(struct Outer*x){return x->a.p!=0;}
