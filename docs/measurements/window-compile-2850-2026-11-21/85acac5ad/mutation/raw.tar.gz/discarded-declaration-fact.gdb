set pagination off
set confirm off
set debuginfod enabled off
set $hits=0
break *0x0000000000f3ced0
commands
silent
set $slot=(unsigned int*)($rdi+256)
if *$slot != 0
printf "COUNTED_POINTER member=%u\n",*$slot
set $hits=$hits+1
set *$slot=0
end
continue
end
run
printf "COUNTED_HITS=%u\n",$hits
