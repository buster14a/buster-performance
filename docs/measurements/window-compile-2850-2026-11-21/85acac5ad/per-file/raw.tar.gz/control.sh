#!/bin/bash
unset BUSTER_CONTROL_SOURCE_NATIVE
exec /home/david/Documents/Codex/2026-11-21/g/work/main-counted-pointer-study/../default-integer-control/build/compiler "$@"
