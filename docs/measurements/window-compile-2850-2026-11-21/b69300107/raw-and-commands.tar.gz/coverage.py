from pathlib import Path
import collections,csv,sys
p=Path(__file__).resolve().parent;case=sys.argv[1] if len(sys.argv)>1 else 'sqlite';arm=sys.argv[2] if len(sys.argv)>2 else 'combined';ref=p/'sqlite.ref';r={int(q[1]):int(q[3]) for l in ref.open() if (q:=l.rstrip().split('\t'))[0]=='control-native-ordinary'};why={};sel={};
for l in (p/f'{case}.{arm}.stderr').open():
 q=l.strip().split('\t');
 if q[0]=='control-source-decline':why[int(q[1])]=(q[2]+'-'+q[3] if q[2] in ['builtin','auxiliary-records','attribute-or-label-address'] else q[2],int(q[4]))
 if q[0]=='control-source-function':sel[int(q[4])]=(int(q[2]),int(q[3]))
c=collections.defaultdict(list)
for close,entries in r.items():
 name,nodes=why.get(close,('owned' if close in sel else 'not-attempted',0));c[name].append((entries,close,nodes))
with (p/f'{case}.{arm}.coverage.tsv').open('w') as f:
 w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['reason','functions','entries','nodes','largest-entries','largest-close']);
 for k,rows in sorted(c.items(),key=lambda x:-sum(v[0] for v in x[1])):w.writerow([k,len(rows),sum(v[0] for v in rows),sum(v[2] for v in rows),*max(rows)[:2]])
print((p/f'{case}.{arm}.coverage.tsv').read_text())
