#!/bin/bash
set -eu
cd "$(dirname "$0")/../classified-source-use-runs"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >../classified-use-study/build.log 2>&1
cp ../default-integer-control/build/predefines.h build/predefines.h
cd ../switch-inputs
source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
BUSTER_SOURCE_USE_CENSUS=1 ../classified-source-use-runs/build/compiler -c -o ../classified-use-study/sqlite.candidate.o "${args[@]}" >../classified-use-study/sqlite.out 2>../classified-use-study/counter.txt
../default-integer-control/build/compiler -c -o ../classified-use-study/sqlite.parent.o "${args[@]}" >../classified-use-study/parent.out 2>../classified-use-study/parent.err
cmp ../classified-use-study/sqlite.candidate.o ../classified-use-study/sqlite.parent.o
python3 ../classified-use-study/events.py >../classified-use-study/events.log 2>&1
python3 ../classified-use-study/oracle.py >../classified-use-study/oracle.log 2>&1
python3 ../classified-use-study/local_pairs.py >../classified-use-study/pairs.log 2>&1
python3 ../classified-use-study/target_pairs.py >../classified-use-study/target.log 2>&1
parent=$PWD/../default-integer-control/build/compiler
new=$PWD/../classified-source-use-runs/build/compiler
out=$PWD/../classified-use-study/corpus
mkdir -p "$out"
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main lua musl; do var=${g}_arguments; eval "args=(${!var})"; python3 ../default-object-qa/pair.py "$out" "$g" "$parent" "$new" "${args[@]}"; done
python3 ../classified-use-study/pmu.py >../classified-use-study/pmu.log 2>&1
cd ../classified-source-use-runs
for part in {1..8}; do ./build/compiler test-checker --seed 2850 --part "$part/8" >"../classified-use-study/checker-$part.log" 2>&1; done
