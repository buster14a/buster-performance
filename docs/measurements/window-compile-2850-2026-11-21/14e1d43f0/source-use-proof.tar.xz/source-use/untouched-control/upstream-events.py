"""Read canonical binding rows directly from the untouched upstream compiler in GDB."""
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
study=Path(__file__).resolve().parent
w=study.parent
tree=w/'default-integer-control'
commands=json.loads((tree/'build/compile_commands.json').read_text())
entry=next(x for x in commands if 'main_unit_checker.c.o' in x['command'])
cmd=shlex.split(entry['command']);i=cmd.index('-o')
cmd=cmd[:i]+['-Xclang','-fdump-record-layouts','-fsyntax-only',cmd[-1]]
for al in ['-emit-llvm','-Xclang','-disable-llvm-passes']:
 if al=='-Xclang':continue
 if al in cmd:
  i=cmd.index(al);del cmd[i]
  if i and cmd[i-1]=='-Xclang':del cmd[i-1]
p=subprocess.run(cmd,cwd=entry['directory'],capture_output=True,timeout=60)
assert p.returncode==0,p.stderr.decode()[:1500]
layouts=p.stdout.decode()
def field_offset(struct,field):
 start=layouts.index(' | struct '+struct+'\n');end=layouts.index('[sizeof=',start)
 return int(re.search(r'^\s*(\d+) \|   \S.*?\b'+field+'$',layouts[start:end],re.M)[1])
reader_bindings=field_offset('CheckInputReader','bindings')
output_visits=field_offset('CheckInput','resolve_visits')
fields=['heads','name_capacity','active','active_count','count','operation','kind','key','declaration','point','end','previous','depth']
offset={k:field_offset('CBindings',k) for k in fields}
print('layout offsets',reader_bindings,output_visits,offset,flush=True)
gdb_program="""set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
break check_input_resolve_range.buster_split
run
set $reader=$rdi
finish
python
import struct, gdb
p=gdb.selected_inferior()
rd=int(gdb.parse_and_eval('$reader'))
def mem(addr,n): return bytes(p.read_memory(addr,n)) if n else b''
def num(addr,n): return int.from_bytes(mem(addr,n),'little')
base=rd+READER_BINDINGS
offset=OFFSETS
def val(k,width):return num(base+offset[k],width)
out=num(rd,8)
visits=num(out+OUTPUT_VISITS,4)
events=val('count',4)
names=val('name_capacity',4)
active=val('active_count',4)
with open(DEST,'wb') as f:
 f.write(struct.pack('<4I',visits,events,names,active))
 for k,sz in [('heads',4*names*3),('active',4*active)]+[(name,4*events) for name in ('key','declaration','point','end','previous','depth')]+[(name,events) for name in ('operation','kind')]:
  f.write(mem(val(k,8),sz))
end
continue
quit
"""
sqlite=w/'switch-inputs/sqlite/sqlite3.c'; cs=w/'pregraph-warning-study/compiler-source'
inputs={'sqlite':['-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I'+str(sqlite.parent),sqlite], 'buster':['-march=native','-I'+str(cs/'src'),'-fwrapv','-funsigned-char','--predefines',w/'proof-predefines.h',cs/'src/buster/compiler/main.c']}
for name,args in inputs.items():
 data=study/(name+'-upstream.events')
 gdbfile=study/(name+'-upstream.gdb')
 gdbfile.write_text(gdb_program.replace('READER_BINDINGS',str(reader_bindings)).replace('OUTPUT_VISITS',str(output_visits)).replace('OFFSETS',repr(offset)).replace('DEST',repr(str(data))))
 cmd=['gdb','-nx','-batch','-x',gdbfile,'--args',tree/'build/compiler','-c',*args,'-o',study/'gdb-upstream.o']
 r=subprocess.run(cmd,capture_output=True,timeout=90);(study/(name+'-upstream-gdb.log')).write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr.decode()[:1000]
 print(name,data.stat().st_size,hashlib.sha256(data.read_bytes()).hexdigest(),flush=True)
