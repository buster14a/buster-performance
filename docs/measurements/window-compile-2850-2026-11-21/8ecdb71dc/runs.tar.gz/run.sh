#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;cd ../live-prefix-objects
./build.sh --config Develop --target compiler --jobs 1 >"$d/build.log" 2>&1
cp ../body-action-rows/build/predefines.h build/
exe=$PWD/build/compiler
cd ../switch-inputs;source ../switch-local-args.sh
tree=$PWD/../pregraph-warning-study/compiler-source;main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for u in sqlite main; do
 v=${u}_arguments;eval "args=(${!v})"; windows=(8 16 24 36 full);[[ $u != main ]] || windows=(8 24 48 76 full)
 for n in "${windows[@]}";do
  envs=(BUSTER_PARSE_LIVE_FOREST=1 BUSTER_PARSE_LIVE_AUDIT=1); [[ $n == full ]] || envs+=(BUSTER_LIVE_NATIVE_CHECKPOINT="$n")
  env "${envs[@]}" "$exe" --lanes 1 -c "${args[@]}" -o "$d/$u.$n.o" >"$d/$u.$n.stdout" 2>"$d/$u.$n.stderr" && rc=0 || rc=$?
  echo "$rc" >"$d/$u.$n.status"
 done
 cmp "$d/$u.full.o" "$d/../source-typed-study/$u.o"
done
