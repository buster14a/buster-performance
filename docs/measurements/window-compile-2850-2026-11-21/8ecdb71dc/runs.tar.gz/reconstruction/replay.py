"""Reconstruct a selected early function using only its early RELAs and the final symbol layout."""
from pathlib import Path
import bisect,collections,csv,hashlib,struct,sys
d=Path(__file__).resolve().parent
lib=d/'../live-prefix-native-study/relocations.py'
exec(lib.read_text().split("for u in ['sqlite','main']:")[0],globals())
d=Path(__file__).resolve().parent
def state(obj):
    obj.byname={n:i for i,(n,k,b,s,o,z) in enumerate(obj.sym) if n and obj.names[n]==1 and k in (0,1,2,6)}
    obj.sectionsyms={s:i for i,(n,k,b,s,o,z) in enumerate(obj.sym) if k==3}
    obj.rs={s[7]:s for s in obj.sec if s[1]==4}
def translate(early,final,r,i,add):
    anchor=early.target(r,i,add)
    if anchor is None or anchor[0]!='name':return None
    _,name,disp=anchor
    j=final.byname.get(name)
    if j is None:return None
    n,k,b,s,o,z=final.sym[j]
    # object_uses_section_symbol for the three supported non-GOT x86 relocations.
    if r not in (1,2,4):return None
    if s and b==0:
        if s not in final.sectionsyms or final.sec[s][2]&16:return None
        return final.sectionsyms[s],disp+o
    return j,disp
def process(src,u,label,full,out):
    pre=Object(src);state(pre);written=bytearray(full.data)
    chosen=[];refused=collections.Counter();blobs={};records={}
    for name in sorted(pre.funcs.keys()&full.funcs.keys()):
        early_sec,early_off,length,body=pre.funcs[name];sec,off,z,_=full.funcs[name]
        if z!=length:refused['length']+=1;continue
        if (pre.sec[early_sec][2]&4)==0 or (full.sec[sec][2]&4)==0:continue
        block=[];fail=False
        for pos,r,idx,add in pre.rels_for(name):
            converted=translate(pre,full,r,idx,add)
            if converted is None:fail=True;break
            target,adj=converted;block.append((pos+off,(target<<32)|r,adj))
        if fail:refused['unresolved-target']+=1;continue
        # The writer allocates a contiguous RELA interval for each atom. Only the interval's
        # location and size are read from the reference container; every value comes from early records.
        ls=full.rels[sec];begin=bisect.bisect_left(ls,(off,));end=bisect.bisect_left(ls,(off+z,))
        if len(block)!=end-begin:refused['interval-size']+=1;continue
        at=full.sec[sec][4]+off
        blobs[at]=body
        if block:
            rst=full.rs[sec];start=rst[4]+begin*rst[9]
            records[start]=b''.join(struct.pack('<QQq',*row) for row in block)
        chosen.append((name,z,len(block)))
    def erase_and_restore(pieces):
        for start,bs in pieces.items():written[start:start+len(bs)]=b'\xa5'*len(bs)
        for start,bs in pieces.items():written[start:start+len(bs)]=bs
    erase_and_restore(blobs);erase_and_restore(records)
    h=hashlib.sha256(written).hexdigest()
    issue=[]
    for group,pieces in [('text',blobs),('rela',records)]:
        for start,bs in pieces.items():
            if bs!=full.data[start:start+len(bs)]:
                diffs=[i for i in range(len(bs)) if bs[i]!=full.data[start+i]]
                issue.append((group,start,len(bs),len(diffs),diffs[0]))
    with (out/(u+'.'+label+'.mismatch.tsv')).open('w') as f:
        writer=csv.writer(f,delimiter='\t',lineterminator='\n');writer.writerow(['kind','offset','size','different_bytes','first']);writer.writerows(issue)
    with (out/(u+'.'+label+'.replaced.tsv')).open('w') as f:
        writer=csv.writer(f,delimiter='\t',lineterminator='\n');writer.writerow(['function','text_bytes','relocations']);writer.writerows(chosen)
    if chosen and not issue:(out/(u+'.'+label+'.rebuilt.o')).write_bytes(written)
    return [u,label,len(chosen),sum(z for _,z,_ in chosen),sum(n for _,_,n in chosen),len(issue),h,hashlib.sha256(full.data).hexdigest(),dict(refused)]
if __name__=='__main__':
    root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=True)
    with (out/'reconstruction.tsv').open('w',buffering=1) as f:
        t=csv.writer(f,delimiter='\t',lineterminator='\n');t.writerow('unit checkpoint reconstructed_functions text_bytes rewritten_RELA differing_intervals reconstructed_sha target_sha declined'.split())
        for u in ['sqlite','main']:
            final=Object(d/'../source-typed-study'/(u+'.o'));state(final)
            for src in sorted(root.glob(u+'.*.o')):
                label=src.name.split('.')[1]
                if label=='full' or not label.isdecimal():continue
                t.writerow(process(src,u,label,final,out))
