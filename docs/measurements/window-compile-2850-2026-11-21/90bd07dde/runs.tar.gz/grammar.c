typedef struct LiveTokenGuard
{
    uint8_t kinds[BUSTER_PARSE_TOKEN_PADDING];
    uint32_t names[BUSTER_PARSE_TOKEN_PADDING];
    uint8_t flags[BUSTER_PARSE_TOKEN_PADDING];
} LiveTokenGuard;

static void live_token_boundary(ParseTokens* tokens, int64_t first, LiveTokenGuard* guard, bool restore)
{
    if (restore)
    {
        memcpy(tokens->kinds + first, guard->kinds, sizeof(guard->kinds));
        memcpy(tokens->names + first, guard->names, sizeof(guard->names));
        memcpy(tokens->flags + first, guard->flags, sizeof(guard->flags));
    }
    else
    {
        memcpy(guard->kinds, tokens->kinds + first, sizeof(guard->kinds));
        memcpy(guard->names, tokens->names + first, sizeof(guard->names));
        memcpy(guard->flags, tokens->flags + first, sizeof(guard->flags));
        memset(tokens->kinds + first, PARSE_KIND_END, sizeof(guard->kinds));
        memset(tokens->names + first, 0, sizeof(guard->names));
        memset(tokens->flags + first, 0, sizeof(guard->flags));
    }
}

// The producer pauses while a window runs. Only its two padding regions need a temporary
// sentinel. The tree writes straight to its final positions, saving the preceding window's tail.
static bool live_vector_tree(LiveForest* live, Preprocessor* pp, uint32_t begin, uint32_t count, ParseTree tree)
{
    const int64_t before = (int64_t)begin - BUSTER_PARSE_TOKEN_PADDING;
    const int64_t after = (int64_t)begin + count;
    LiveTokenGuard left, right;
    uint8_t preceding_roles[BUSTER_PARSE_TOKEN_PADDING];
    uint32_t preceding_depths[BUSTER_PARSE_TOKEN_PADDING], preceding_parents[BUSTER_PARSE_TOKEN_PADDING];
    memcpy(preceding_roles, live->tree.roles + before, sizeof(preceding_roles));
    memcpy(preceding_depths, live->tree.depths + before, sizeof(preceding_depths));
    memcpy(preceding_parents, live->tree.parents + before, sizeof(preceding_parents));
    live_token_boundary(&live->tokens, before, &left, false);
    live_token_boundary(&live->tokens, after, &right, false);
    ParseKernels kernels = { 0 };
    ParseVectorBuffers buffers = { 0 };
    Arena* scratch = live->scratch;
    bool valid = parse_kernels_reserve_tree(&kernels, scratch, count, live->names.capacity, &tree) &&
                 parse_vector_buffers_reserve(&buffers, scratch, count);
    if (valid)
    {
        for (uint32_t i = 0; i < live->file_type_count; i += 1)
            kernels.typedef_names[live->file_types[i]] = BUSTER_PARSE_TYPEDEF_FILE;

        ParseDiagnostic diagnostics[8];
        const ParseInput input = {
            .kinds = live->tokens.kinds + begin, .names = live->tokens.names + begin, .flags = live->tokens.flags + begin,
            .count = count, .language = pp->options.language, .meanings = &live->names, .scratch = scratch,
            .diagnostics = diagnostics, .diagnostic_capacity = 8, .prior_file_items = begin != 0,
        };
        const ParseKernelResult parsed = parse_vector(&kernels, &input, live->predeclared, &buffers);
        valid = !parsed.fallback.errors && !kernels.unsupported && !kernels.unbalanced;
        if (valid)
        {
            // The per-item scalar fallback can unmark an inherited name when restoring its local view.
            for (uint32_t i = 0; i < live->file_type_count; i += 1)
                live->names.meanings[live->file_types[i]] = PARSE_MEANING_TYPEDEF;
            for (uint32_t i = 0; i < kernels.typedef_count; i += 1)
                if (kernels.typedef_scopes[i] == BUSTER_PARSE_TYPEDEF_FILE)
                    live_file_typedef(live, kernels.typedef_log[i]);
            live->vector_tokens += count;
            live->fallback_tokens += parsed.fallback.tokens;
        }
    }
    live_token_boundary(&live->tokens, before, &left, true);
    live_token_boundary(&live->tokens, after, &right, true);
    memcpy(live->tree.roles + before, preceding_roles, sizeof(preceding_roles));
    memcpy(live->tree.depths + before, preceding_depths, sizeof(preceding_depths));
    memcpy(live->tree.parents + before, preceding_parents, sizeof(preceding_parents));
    return valid;
}

