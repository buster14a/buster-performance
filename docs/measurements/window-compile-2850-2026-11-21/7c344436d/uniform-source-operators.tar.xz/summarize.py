from pathlib import Path
import csv,collections,bisect,statistics
d=Path(__file__).resolve().parent;bound=d.parent/'source-bound-statements-study'
for kind,fn in [('sqlite','sqlite.bodies.tsv'),('main','buster-canonical.bodies.tsv')]:
 data=list(csv.DictReader((bound/fn).open(),delimiter='\t'));beg=[int(r['body']) for r in data];end=[int(r['end']) for r in data]
 def selected(mode):
  read=d/'optimized-run'/(kind+'.'+mode+'.log')
  if not read.exists():return {}
  rows={}
  for l in read.open():
   a=l.strip().split('\t')
   if a[0] not in ('direct-operator-return','direct-condition','direct-statement'):continue
   b,e,c,_,steps=map(int,a[1:6]);i=bisect.bisect_right(beg,b)-1
   assert i>=0 and e<=end[i],(kind,b,e,i)
   rows[(b,e)]=(i,steps,'return' if a[0]=='direct-operator-return' else 'condition' if a[0]=='direct-condition' else 'call' if c else 'store')
  return rows
 rows=selected('operators');base=selected('statements');print(kind,'ref-token-count',sum(e-b+1 for b,e in zip(beg,end)))
 if not rows:continue
 with (d/(kind+'-intervals.tsv')).open('w') as f:
  wr=csv.writer(f,delimiter='\t');wr.writerow('begin end closing-token class steps'.split())
  for (b,e),(i,k,t) in sorted(rows.items()):wr.writerow([b,e,end[i],t,k])
 for title,keep in [('all',rows),('programs',{s:v for s,v in rows.items() if v[1]}),('extra',{s:v for s,v in rows.items() if s not in base})]:
  print(title,len(keep),'tokens',sum(e-b+1 for b,e in keep),'bodies',len({i for i,k,t in keep.values()}),'steps',sum(k for i,k,t in keep.values()),'by-kind',collections.Counter(t for i,k,t in keep.values()))
 fn=d/(kind+'-four.tsv')
 if not fn.exists():continue
 samples=collections.defaultdict(dict)
 for r in csv.DictReader(fn.open(),delimiter='\t'):samples[r['stage'],r['policy']][int(r['round'])]=int(r['ns'])/1e6
 for stage in ('ordinary','total','check-input','check-expressions','check-program','lower','tier0'):
  for base,head in [('ordinary','operators'),('statements','operators'),('native','composed'),('ordinary','composed')]:
   a=samples[stage,base];b=samples[stage,head];p=[(a[r],b[r]) for r in a.keys()&b.keys()]
   if p:print(stage,base,head,'n',len(p),'medians',round(statistics.median(x for x,y in p),3),round(statistics.median(y for x,y in p),3),'delta',round(statistics.median(y-x for x,y in p),3),'wins',sum(y<x for x,y in p))
