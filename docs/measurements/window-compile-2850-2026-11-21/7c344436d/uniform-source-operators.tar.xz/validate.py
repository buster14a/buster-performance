from pathlib import Path
import sys,os,hashlib,subprocess,csv
d=Path(__file__).resolve().parent; w=d.parent; s=w/'switch-inputs';tree=w/'pregraph-warning-study/compiler-source'
cc=Path(sys.argv[1]).resolve();dest=d/(sys.argv[2] if len(sys.argv)>2 else 'test');dest.mkdir(exist_ok=True)
cases={'callees':[d/'callees.c'],'forest':[d/'forest.c'],'challenge':[d/'challenge.c'],'random':['-fwrapv',d/'random.c'],'sqlite':['-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I'+str(s/'sqlite'),s/'sqlite/sqlite3.c'],'main':['-march=native','-I'+str(tree/'src'),'-fwrapv','-funsigned-char','--predefines',w/'proof-predefines.h',tree/'src/buster/compiler/main.c']}
roles={'BUSTER_DIRECT_SOURCE_STATEMENTS':'1'};program=roles|{'BUSTER_DIRECT_OPERATOR_PROGRAM':'1'};native={'BUSTER_CONTROL_SOURCE_NATIVE':'1','BUSTER_CONTROL_EARLY_NATIVE':'1','BUSTER_CONTROL_EARLY_RELEASE':'1'}
modes={'ordinary':{},'statements':roles,'operators':program,'native':native,'composed':program|native|{'BUSTER_COMPOSE_SOURCE_STATEMENTS':'1'}}
audit={'BUSTER_DIRECT_RETURN_AUDIT':'1','BUSTER_DIRECT_GRAPH_CENSUS':'1','BUSTER_CONTROL_EARLY_AUDIT':'1','BUSTER_CONTROL_SOURCE_AUDIT':'1'}
env={k:v for k,v in os.environ.items() if not k.startswith(('BUSTER_DIRECT_','BUSTER_SOURCE_','BUSTER_CONTROL_','BUSTER_COMPOSE_'))}
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
with (dest/'objects.tsv').open('w',buffering=1) as f:
 wri=csv.writer(f,delimiter='\t');wri.writerow(['unit','mode','rc','sha','exact','programs','graph','native','fragments'])
 for name,args in cases.items():
  ref=None
  for m,flags in modes.items():
   v=dest/(name+'.'+m+'.o');v.unlink(missing_ok=True);r=subprocess.run([cc,'--lanes','1','-c',*args,'-o',v],env=env|flags|audit,capture_output=True,timeout=150);(dest/(name+'.'+m+'.log')).write_bytes(r.stderr)
   sha=hashlib.sha256(v.read_bytes()).hexdigest() if v.exists() else None
   if m=='ordinary': ref=sha
   lines=r.stderr.decode(errors='replace').splitlines(); collect=lambda pref:' | '.join(x for x in lines if x.startswith(pref))
   row=[name,m,r.returncode,sha,ref and sha==ref,collect('source-operator-programs'),collect('source-statement-graph'),collect('control-source-summary'),sum(x.startswith('source-native-fragment\t') for x in lines)]
   print(*row[:7],flush=True);wri.writerow(row)
clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
with (dest/'runtime.tsv').open('w') as f:
 wr=csv.writer(f,delimiter='\t');wr.writerow(['unit','mode','rc','actual','clang','exact'])
 for name,driver in [('challenge','driver.c'),('random','random-driver.c')]:
  exe=dest/(name+'.clang');subprocess.run([clang,'-fwrapv',d/(name+'.c'),d/driver,'-o',exe],check=True);expected=subprocess.check_output([exe])
  for m in modes:
   out=dest/(name+'.'+m+'.exe');o=dest/(name+'.'+m+'.o')
   if not o.exists():continue
   subprocess.run([clang,'-no-pie',o,d/driver,'-o',out],check=True);r=subprocess.run([out],capture_output=True)
   wr.writerow([name,m,r.returncode,r.stdout.decode().strip(),expected.decode().strip(),r.returncode==0 and r.stdout==expected])
