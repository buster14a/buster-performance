extern int printf(const char *,...);
volatile int v;int a;int f(int x){v=x;v++;a+=v;((void)v); return a;}
int main(void){int r=f(3);printf("%d %d\n",r,v);return 0;}

