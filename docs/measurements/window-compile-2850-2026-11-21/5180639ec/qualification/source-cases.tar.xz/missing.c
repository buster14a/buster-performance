int f(int x){ x=not_declared(); x+=z; return x;}
