extern int printf(const char *,...);
int n;int f(int x){return n+=x;}
int main(void){__builtin_choose_expr(1,f(1),f(2));_Generic(f(22),int: f(3),default:f(4));printf("%d\n",n);return 0;}

