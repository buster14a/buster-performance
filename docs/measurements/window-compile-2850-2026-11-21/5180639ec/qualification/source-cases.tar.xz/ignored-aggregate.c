struct [[nodiscard]] S{int a;};struct S f(void);void g(void){f(); (void)f();}
