extern int printf(const char *,...);
#pragma STDC FENV_ACCESS ON
volatile float f;float g(float a){return f+=a;}
int main(void){g(2);f+=3;printf("%d\n",(int)f);return 0;}

