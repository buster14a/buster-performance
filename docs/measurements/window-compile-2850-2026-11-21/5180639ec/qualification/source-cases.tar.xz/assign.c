extern int printf(const char *,...);
struct S { int a; float b; }; struct S x,y={2,3}; _Atomic unsigned a; unsigned b;
int main(void){x=y; a=5; a++; b+=a; b<<=1; printf("%d %d %u %u\n",x.a,(int)x.b,b,(unsigned)a);return 0;}

