__attribute__((warn_unused_result)) int t(void);void f(void){t(); (void)t(); (t());}
