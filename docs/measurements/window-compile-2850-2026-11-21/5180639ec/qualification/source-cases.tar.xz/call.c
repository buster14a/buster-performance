extern int printf(const char *,...);
int n;void pv(int x){n=n*3+x;}int pi(int x){pv(x);return n;} struct S{int a,b;};struct S ps(int x){pv(x);return (struct S){x,x+1};}
int main(void){pv(1);pi(2);(ps(3));(void)pi(4); printf("%d\n",n);return 0;}

