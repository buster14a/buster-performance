extern int printf(const char *,...);
int n;int f(int x){return n=n*5+x;}
int main(void){((f(2)));{(void)(f(3),f(4));} if(n) f(5);else f(6);printf("%d\n",n);return 0;}

