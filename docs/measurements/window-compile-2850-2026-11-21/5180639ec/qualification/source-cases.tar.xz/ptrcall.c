extern int printf(const char *,...);
int n; void f(int x){n+=x;} void (* volatile fn)(int)=f;
int main(void){fn(3);(fn)(5);printf("%d\n",n);return 0;}

