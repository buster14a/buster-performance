struct X;struct X f(void);void h(void){f();}
