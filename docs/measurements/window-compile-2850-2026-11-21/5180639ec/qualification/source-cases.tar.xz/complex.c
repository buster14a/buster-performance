extern int printf(const char *,...);
typedef float _Complex C; C z; C f(int x){z+=x+2.0fi;return z;}
int main(void){f(2);(void)f(3);printf("%d %d\n",(int)__real__ z,(int)__imag__ z);return 0;}

