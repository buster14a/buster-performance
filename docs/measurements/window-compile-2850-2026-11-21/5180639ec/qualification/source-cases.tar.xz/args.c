[[nodiscard]] int f(int, int);void g(void){f(1);f(2,3);}
