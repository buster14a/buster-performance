int f(void);void g(int x){for(f();x;f()) f(); L: f(); if (x){f();}else f();}
