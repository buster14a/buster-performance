extern int printf(const char *,...);
_Noreturn void halt(void){__builtin_trap();} int f(int x){if(x){halt();}return 9;}
int main(void){printf("%d\n",f(0));return 0;}

