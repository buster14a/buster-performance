extern int printf(const char *,...);
int n;int f(int x){n+=x;return n;}
int main(void){int r=({f(2);int y=({f(3);f(4);}); y+n;}); printf("%d %d\n",r,n);return 0;}

