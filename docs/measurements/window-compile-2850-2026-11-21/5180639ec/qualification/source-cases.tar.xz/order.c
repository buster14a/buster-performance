[[nodiscard]] int g(int);void f(int x){x==1;g(2);x=g(3);x=x++ + x++;g(4);}
