extern int printf(const char *,...);
struct S{unsigned a:3,b:3;};struct S s;
int main(void){s.a=4;s.a++;s.b+=s.a;((void)s.b);printf("%u %u\n",s.a,s.b);return 0;}

