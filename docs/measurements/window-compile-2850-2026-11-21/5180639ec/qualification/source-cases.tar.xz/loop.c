extern int printf(const char *,...);
int n;int f(int x){return n+=x;}
int main(void){for(int i=0;i<3;i++){f(i);if(i==1) continue;else {n++;}}printf("%d\n",n);return 0;}

