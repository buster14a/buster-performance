void f(void){const int x=1;x++;x=3;}
