extern int printf(const char *,...);
int n;int f(int x){return ++n+x;}
int main(void){int r=({n=1;lab: f(5);});int q=({n+=2;});printf("%d %d %d\n",r,q,n);return 0;}

