extern int printf(const char *,...);
int n;int take(int x){++n; return x;}
int main(void){int a[3]={1,2,3}; __typeof__(int (*)[take(3)]) p=(void *)&a; (void)p;printf("%d %d\n",n,a[1]);return 0;}

