[[nodiscard]] int a(int);int f(void){a(1);((a(2)));(void)a(3);if(0){a(4);}return 0;}
