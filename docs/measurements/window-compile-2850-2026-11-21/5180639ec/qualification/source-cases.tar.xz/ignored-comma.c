[[nodiscard]] int g(int);void f(int x){g(1),g(2);x?g(3):g(4);(void)(x?g(5):g(6));}
