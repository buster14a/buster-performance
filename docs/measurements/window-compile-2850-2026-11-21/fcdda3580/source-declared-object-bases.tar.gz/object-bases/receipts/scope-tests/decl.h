struct X { int value; }; struct Y { long other; int value; };
extern struct X *p;
#define CARE(x) ((x)->value)
