#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;v=${1:-v1};out=$root/results/pp-bases-$v;tree=$root/trees/pp-bases-$v;mkdir -p "$out"
if [[ ! -d $tree ]];then git -C src worktree add -q --detach "$tree" 0e1d5b825;git -C "$tree" apply "$root/pp-bases/$v.patch";fi
./lock.sh bash -c 'cd "$1" && ./build.sh --config Release' _ "$tree" >"$out/build" 2>&1
source corpora.sh;main_arguments="-march=native -I$root/pooled-main-source/src -fwrapv -funsigned-char --predefines $root/proof-predefines.h $root/pooled-main-source/src/buster/compiler/main.c"
for c in sqlite main;do k=${c}_arguments;eval "args=(${!k})"
 for a in ordinary fields bases;do
  vars=();[[ $a == ordinary ]] || vars=(BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_CONNECTED_MEMBER_VIEWS=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1)
  [[ $a != bases ]] || vars+=(BUSTER_SOURCE_BASE_NAMES=1 BUSTER_SOURCE_BASE_LOG="$out/$c.seen")
  f=$out/$c-$a
  ./lock.sh taskset -c 2 bash -c 'f=$1;shift;set +e;"$@" >"$f.out" 2>"$f.err";echo $? >"$f.rc"' _ "$f" env "${vars[@]}" BUSTER_SOURCE_BASE_ANSWERS="$f.answers" "$tree/build/compiler" --lanes 1 -c "${args[@]}" -o "$f.o" >"$f.lease" 2>&1
  for x in rc out o;do cmp "$out/$c-ordinary.$x" "$f.$x";done
  sed '/^body-source-decline[[:space:]]/d' "$f.err" >"$f.diagnostics";cmp "$out/$c-ordinary.diagnostics" "$f.diagnostics";test "$(cat "$f.rc")" = 0
 done
done
(cd "$out" && sha256sum *.o *.answers *.seen >hashes)
