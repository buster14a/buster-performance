#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;prefix=$d/../pp-member-connected-study
python "$prefix/local.py" pp-object-bases base-test
cc=$prefix/base-test/compiler
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
for arm in ordinary fields bases;do
 vars=();[[ $arm == ordinary ]] || vars=(BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_CONNECTED_MEMBER_VIEWS=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1)
 [[ $arm != bases ]] || vars+=(BUSTER_SOURCE_BASE_NAMES=1 BUSTER_SOURCE_BASE_LOG="$d/bases.seen")
 env "${vars[@]}" BUSTER_SOURCE_BASE_ANSWERS="$d/$arm.answers" "$cc" --lanes 1 -c "${args[@]}" -o "$d/$arm.o" >"$d/$arm.out" 2>"$d/$arm.err"
 for ext in o out err;do cmp "$d/$arm.$ext" "$d/ordinary.$ext";done
done
