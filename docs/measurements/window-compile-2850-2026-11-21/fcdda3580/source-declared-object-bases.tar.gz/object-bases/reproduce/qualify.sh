#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2;root=$PWD;v=v2;qualified=$root/results/pp-bases-$v;out=$root/results/pp-bases-extra-$v;mkdir -p "$out";cc=$root/trees/pp-bases-$v/build/compiler
for ((n=0;n<900;n++));do [[ -s "$qualified/hashes" ]] && break;sleep 2;done;test -s "$qualified/hashes"
source corpora.sh;eval "args=($sqlite_arguments)";paths=$(bash trees/factsmain0e1d/tools/ci/session-toolchain.sh stage)
field=(BUSTER_CONTROL_SOURCE_NATIVE=1 BUSTER_CONTROL_EARLY_NATIVE=1 BUSTER_CONTROL_EARLY_RELEASE=1 BUSTER_EXPERIMENT_PP_SOURCE_NAMES=1 BUSTER_SOURCE_PHYSICAL_MEMBERS=1 BUSTER_CONNECTED_MEMBER_VIEWS=1)
for a in ordinary bases;do
 vars=();[[ $a == ordinary ]] || vars=("${field[@]}" BUSTER_SOURCE_BASE_NAMES=1)
 f=$out/warnings-$a
 ./lock.sh taskset -c 2 bash -c 'f=$1;shift;exec "$@" >"$f.out" 2>"$f.err"' _ "$f" env "${vars[@]}" "$cc" --lanes 1 -c -Weverything "${args[@]}" -o "$f.o" >"$f.lease" 2>&1
done
for x in out err o;do cmp "$out/warnings-ordinary.$x" "$out/warnings-bases.$x";done
./lock.sh taskset -c 2 env PATH="$paths:$PATH" clang -no-pie "$root/results/active-source-native-oracles/driver.o" "$qualified/sqlite-bases.o" -lm -ldl -lpthread -o "$out/sql" >"$out/link.lease" 2>&1
./lock.sh taskset -c 2 bash -c 'exec "$1" >"$2" 2>"$3"' _ "$out/sql" "$out/sql.out" "$out/sql.err" >"$out/sql.lease" 2>&1
cmp "$out/sql.out" "$root/results/active-source-native-oracles/clang.sql";cmp "$out/sql.err" "$root/results/active-source-native-oracles/clang.sqlerr"
for r in 1 2 3;do case $r in 1)arms=(ordinary fields bases bases fields ordinary);;2)arms=(fields bases ordinary ordinary bases fields);;3)arms=(bases ordinary fields fields ordinary bases);;esac
 for i in {0..5};do a=${arms[i]};vars=();[[ $a == ordinary ]] || vars=("${field[@]}");[[ $a != bases ]] || vars+=(BUSTER_SOURCE_BASE_NAMES=1)
 f=$out/$r-$i-$a
 ./lock.sh taskset -c 2 env "${vars[@]}" python3 -c 'import subprocess,sys,time;t=time.perf_counter_ns();r=subprocess.run(sys.argv[1:]);print(time.perf_counter_ns()-t);raise SystemExit(r.returncode)' "$cc" --lanes 1 -c "${args[@]}" -o "$f.o" >"$f.time" 2>"$f.lease"
 cmp "$qualified/sqlite-ordinary.o" "$f.o"
 done
done
(cd "$out" && sha256sum *.o sql.out sql.err warnings-*.err >hashes)
