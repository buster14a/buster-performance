#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;python3 "$d/../pp-member-connected-study/local.py" pp-object-bases base-final
sed 's@base-clean/compiler@base-final/compiler@' edges.py >edges-final.py
python3 edges-final.py
echo 'all fresh unprimed base fixtures agree'
