    const char* path=getenv("BUSTER_SOURCE_BASE_ANSWERS");
    if(path)
    {
        FILE* f=fopen(path,"a");
        if(!f)return false;
        for(uint32_t t=1;t+1<parser->tokens.count;t++)
        {
            if(parser->tokens.kinds[t]!=PARSE_KIND_IDENTIFIER || parser->tokens.kinds[t+1]!=PARSE_KIND_ARROW ||
               parser->tokens.kinds[t-1]==PARSE_KIND_PERIOD || parser->tokens.kinds[t-1]==PARSE_KIND_ARROW)continue;
            const uint32_t id=parser->tokens.names[t],decl=output->declarations[t];
            if(!id)continue;
            fprintf(f,"%u\t%u\t%.*s\t%u\n",t,parse_source_index(&parser->tokens,t),(int)intern_length(reader->pp->table,id),intern_bytes(reader->pp->table,id),decl);
        }
        if(fclose(f)!=0)return false;
    }
