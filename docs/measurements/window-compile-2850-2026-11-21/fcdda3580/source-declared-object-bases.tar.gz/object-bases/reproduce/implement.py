from pathlib import Path
d=Path(__file__).resolve().parent;src=d.parent/'pp-object-bases/src/buster/compiler'
p=src/'c_preprocessor.c';s=p.read_text().replace('    PPBorrowedSelector* selectors;', '''    void* base_names;
    PPBorrowedSelector* bases;
    uint32_t base_count;
    PPBorrowedSelector* selectors;''');p.write_text(s)
p=src/'c_pp_source_names.c';s=p.read_text().replace('''    RefineIdentifiers batch;
    uint32_t rows[BUSTER_PP_SOURCE_BATCH];''','''    const bool leave_bases=leave_members && getenv("BUSTER_SOURCE_BASE_NAMES")!=NULL;
    RefineIdentifiers batch;
    uint32_t rows[BUSTER_PP_SOURCE_BATCH];''').replace('''            const uint32_t loc=pp->output.locations[row],len=pp->output.values[row]&INT32_MAX;''','''            if(leave_bases && row+1<pp->output.count && pp->output.kinds[row+1]==C_TOKEN_ARROW)continue;
            const uint32_t loc=pp->output.locations[row],len=pp->output.values[row]&INT32_MAX;''');p.write_text(s)
p=src/'c_parser_impl.c';s=p.read_text().replace('''    if(!parser->options.source_member_views || token>=parser->tokens.count || !token ||
       (parser->tokens.kinds[token-1]!=PARSE_KIND_PERIOD && parser->tokens.kinds[token-1]!=PARSE_KIND_ARROW)) return 0;''','''    if(!parser->options.source_member_views || token>=parser->tokens.count || !token)return 0;''')
s=s.replace('''        plan->selector_count=0;
        uint32_t body=0;''','''        const bool borrow_bases=getenv("BUSTER_SOURCE_BASE_NAMES")!=NULL;
        if(borrow_bases)
        {
            plan->bases=BUSTER_ARENA_PUSH_ARRAY(&pp->arena,PPBorrowedSelector,count+1);
            if(!plan->bases)return false;
        }
        plan->base_count=plan->selector_count=0;
        uint32_t body=0;''')
needle='''            if(plan->selector_count && plan->selectors[plan->selector_count-1].row>=row)return false;'''
s=s.replace(needle,'''            if(borrow_bases && parser->tokens.kinds[t-1]!=PARSE_KIND_PERIOD && parser->tokens.kinds[t-1]!=PARSE_KIND_ARROW &&
               t+1<parser->tokens.count && parser->tokens.kinds[t+1]==PARSE_KIND_ARROW)
            {
                const bool primary=plan->primary && pp_find_range(pp,pp->output.locations[row])==plan->range;
                if(body && primary && role==PARSE_ROLE_OPERAND && parser->tree.roles[t+1]==PARSE_ROLE_MEMBER_OPERATOR &&
                   intern_find(pp->table,spelling,length))
                    plan->bases[plan->base_count++]=(PPBorrowedSelector){spelling,row,length,t,0};
                else if(!parse_demand_member(parser,pp,t))return false;
                continue;
            }
'''+needle);p.write_text(s)
p=src/'c_check_input.c';s=p.read_text();i=s.index('static inline __attribute__((always_inline)) void check_input_resolve_name(');s=s[:i]+(d/'base.inc').read_text()+'\n'+s[i:];i=s.index('    const uint32_t identifier = parser->tokens.names[i];',i);s=s[:i]+'    check_base_publish(reader,i);\n'+s[i:];p.write_text(s)
