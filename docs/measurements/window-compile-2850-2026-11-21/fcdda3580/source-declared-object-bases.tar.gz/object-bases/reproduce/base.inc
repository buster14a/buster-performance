// Only declarations entered in this live binding stream populate the spelling directory.
// The ordinary scope heads still select the binding, including shadowing and restoration.
typedef struct CheckBaseNames
{
    const uint32_t* events;
    uint32_t seen;
    uint32_t capacity;
    uint32_t* ids;
} CheckBaseNames;

static uint32_t check_base_hash(const uint8_t* bytes,uint32_t n)
{
    uint32_t a=0,b=0;
    if(n>=4){memcpy(&a,bytes,4);memcpy(&b,bytes+n-4,4);}
    else for(uint32_t k=0;k<n;k++)a|=(uint32_t)bytes[k]<<(8*k);
    return _mm_crc32_u32(_mm_crc32_u32(n,a),b)*2654435761u;
}

static IdentId check_base_declared_name(CheckInputReader* reader,const PPBorrowedSelector* use,uint32_t* declaration)
{
    PPNameViews* plan=reader->pp->name_views;
    CheckBaseNames* names=plan->base_names;
    const CBindings* events=&reader->bindings;
    if(!names)
    {
        names=BUSTER_ARENA_PUSH_ARRAY(&reader->pp->arena,CheckBaseNames,1);
        if(!names)return 0;
        *names=(CheckBaseNames){0};plan->base_names=names;
    }
    if(names->events!=events->key || events->count<names->seen)
    {
        uint32_t capacity=32;
        if(events->name_capacity>=(1u<<29))return 0;
        while(capacity<2*events->name_capacity)capacity*=2;
        names->ids=BUSTER_ARENA_PUSH_ARRAY(&reader->pp->arena,uint32_t,capacity);
        if(!names->ids)return 0;
        memset(names->ids,0,(size_t)capacity*4);names->capacity=capacity;names->seen=0;names->events=events->key;
    }
    if(!names->ids)return 0;
    const InternTable* table=reader->pp->table;
    for(;names->seen<events->count;names->seen++)
    {
        const uint32_t e=names->seen,id=events->key[e];
        if(events->operation[e]!=C_BINDING_DECLARE || !id || id>=events->name_capacity)continue;
        uint32_t slot=check_base_hash(intern_bytes(table,id),intern_length(table,id))&(names->capacity-1);
        while(names->ids[slot] && names->ids[slot]!=id)slot=(slot+1)&(names->capacity-1);
        names->ids[slot]=id;
    }
    uint32_t slot=check_base_hash(use->bytes,use->length)&(names->capacity-1);
    while(names->ids[slot])
    {
        const uint32_t id=names->ids[slot];
        if(intern_length(table,id)==use->length && memcmp(intern_bytes(table,id),use->bytes,use->length)==0)
        {
            const uint32_t handle=c_bindings_lookup(events,C_BINDING_ORDINARY,id);
            if(handle && events->declaration[handle-1]<reader->parser->tokens.count)
            {
                *declaration=events->declaration[handle-1];
                if(reader->parser->tokens.names[*declaration]==id)return id;
            }
            return 0;
        }
        slot=(slot+1)&(names->capacity-1);
    }
    return 0;
}

static void check_base_publish(CheckInputReader* reader,uint32_t token)
{
    PPNameViews* plan=reader->pp?reader->pp->name_views:NULL;
    if(!plan || !plan->base_count || reader->parser->tokens.names[token])return;
    uint32_t low=0,high=plan->base_count;
    while(low<high)
    {
        const uint32_t m=low+(high-low)/2;
        if(plan->bases[m].parser_token<token)low=m+1;else high=m;
    }
    if(low==plan->base_count || plan->bases[low].parser_token!=token)return;
    const PPBorrowedSelector* use=plan->bases+low;
    if(parse_source_index(&reader->parser->tokens,token)!=use->row)return;
    uint32_t decl=BUSTER_CHECK_NONE;
    IdentId id=check_base_declared_name(reader,use,&decl);
    const bool from_declaration=id!=0;
    if(!id)id=intern_find_or_add(reader->pp->table,use->bytes,use->length);
    if(!id){reader->output->resource=true;return;}
    reader->parser->tokens.names[token]=id;
    if(!reader->pp->output_released)reader->pp->output.values[use->row]=id;
    const char* trace=getenv("BUSTER_SOURCE_BASE_LOG");
    if(trace)
    {
        FILE* out=fopen(trace,"a");
        if(out){fprintf(out,"%u\t%u\t%.*s\t%u\t%u\t%u\n",token,use->row,(int)use->length,use->bytes,from_declaration,decl,id);fclose(out);}
    }
}
