import sys,subprocess,csv,hashlib,shutil,os
from pathlib import Path
d=Path(__file__).resolve().parent;area=d/'scope-tests';area.mkdir(exist_ok=True);cc=d.parent/'pp-member-connected-study/base-clean/compiler';clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang')
env={k:'1' for k in 'BUSTER_CONTROL_SOURCE_NATIVE BUSTER_CONTROL_EARLY_NATIVE BUSTER_CONTROL_EARLY_RELEASE BUSTER_CONNECTED_MEMBER_VIEWS BUSTER_SOURCE_PHYSICAL_MEMBERS BUSTER_EXPERIMENT_PP_SOURCE_NAMES BUSTER_SOURCE_BASE_NAMES'.split()}
(area/'decl.h').write_text('struct X { int value; }; struct Y { long other; int value; };\nextern struct X *p;\n#define CARE(x) ((x)->value)\n')
pad='/*'+'z'*1048576+'*/\n#include "decl.h"\n'+'extern int padding;\n'*180
body='int run(struct X *p,struct Y *q){int sum=p->value; {struct Y *p=q; sum+=p->value;} sum+=p->value; return sum+CARE(q); }'
sources={'shadow':body,'global':'int use(void){return p->value;}\n'+body,'mapped':'#line 77 "base-scope.c"\n'+body,'undeclared':body.replace('sum=p->value','sum=unique_absent_name->value'),'after-scope':'int use(struct X *arg){{ struct X *gone=arg; (void)gone; }return gone->value;}','typedef':'typedef struct X *Alias; int use(Alias p){ int s=p->value; { typedef long Alias; Alias v=0; s+=v;}return s+p->value;}','wrong-type':body.replace('struct Y *p=q','int p=1'),'unknown-field':body.replace('sum+=p->value','sum+=p->absent',1),'different-name':'int use(struct X *first, struct Y *second){return first->value+second->value;}'}
summary=[];bad=0
for name,src in sources.items():
 source=area/(name+'.c');source.write_text(pad+src+'\n')
 for arm in ['ordinary','source','clang']:
  path=area/(name+'-'+arm);exe=clang if arm=='clang' else cc
  log=Path(str(path)+'.seen');answers=Path(str(path)+'.answers')
  for f in (log,answers):f.unlink(missing_ok=True)
  v=dict(os.environ)
  if arm=='source':v.update(env,BUSTER_SOURCE_BASE_LOG=str(log))
  if arm!='clang':v['BUSTER_SOURCE_BASE_ANSWERS']=str(answers)
  r=subprocess.run([exe,'-std=gnu17','-c',source,'-o',str(path)+'.o'],capture_output=True,env=v)
  for ext,data in [('rc',str(r.returncode).encode()),('out',r.stdout),('err',r.stderr)]:Path(str(path)+'.'+ext).write_bytes(data)
 ref=area/(name+'-ordinary');candidate=area/(name+'-source');cl=area/(name+'-clang')
 get=lambda p,ext:(Path(str(p)+'.'+ext).read_bytes())
 good=all(get(ref,ext)==get(candidate,ext) for ext in ('rc','out','err')) and ((get(ref,'rc')==b'0')==(get(cl,'rc')==b'0'))
 if get(ref,'rc')==b'0':good=good and get(ref,'o')==get(candidate,'o')
 seen=(area/(name+'-source.seen')); seen=seen.read_text().splitlines() if seen.is_file() else []
 normal=(area/(name+'-ordinary.answers')); original={int(r[0]):(r[2],int(r[3])) for r in csv.reader(normal.open(),delimiter='\t')} if normal.exists() else {}
 matches=0;miss=0
 for ln in seen:
  t,p,word,held,decl,_=ln.split('\t')
  if held=='0':miss+=1
  elif int(t) in original:matches+=int(original[int(t)]==(word,int(decl)))
  else:matches+=1 if get(ref,'rc')!=b'0' else 0
 good=good and matches+miss==len(seen)
 summary.append(f'{name} result={good} ordinary={get(ref,"rc").decode()} clang={get(cl,"rc").decode()} source-queries={len(seen)} declared={matches} binding-misses={miss}')
 bad+=not good
(area/'results').write_text('\n'.join(summary)+'\n');print(*summary,sep='\n');sys.exit(bad!=0)
