import csv,collections,sys
from pathlib import Path
d=Path(__file__).resolve().parent
args=sys.argv[1:]; seen=Path(args[0]) if args else d/'bases.seen';answers=Path(args[1]) if args else d/'ordinary.answers';out=Path(args[2]) if args else d/'declaration-bound.tsv'
def table(path):return list(csv.reader(path.open(),delimiter='\t'))
c={int(r['parser-token']):r for r in csv.DictReader((d/'coordinates.tsv').open(),delimiter='\t')}
a={int(t):(int(p),s,int(decl)) for t,p,s,decl in table(answers)}
chains={int(r['base-token']):r for r in csv.DictReader((d.parent/'member-chain-native-study/base-source-overlap.tsv').open(),delimiter='\t')}
stats=collections.Counter();bad=[]
with out.open('w') as f:
 w=csv.writer(f,delimiter='\t',lineterminator='\n')
 w.writerow('parser-token pp-row pp-location spelling declaration-source-backed resolved-declaration-token ordinary-declaration-token canonical-name native-operand all-fields-source-backed some-fields-source-backed'.split())
 for t,p,s,src,decl,name in table(seen):
  t,p,src,decl,name=map(int,(t,p,src,decl,name)); cr=c[t]; ar=a[t]; ch=chains.get(t,{})
  verified=src and ar==(p,s,decl);stats['total']+=1;stats['source']+=src;stats['same']+=bool(verified);stats['ordinary-positive']+=ar[2]!=0
  if not verified:bad.append([t,p,s,src,decl,ar])
  assert int(cr['pp-row'])==p and cr['spelling']==s
  allfields=int(ch.get('all-field-names-source-bound',0)); some=int(ch.get('some-field-names-source-bound',0));stats['native']+=bool(verified and ch);stats['all-fields']+=bool(verified and allfields);stats['some-fields']+=bool(verified and some)
  w.writerow([t,p,cr['pp-location'],s,src,decl,ar[2],name,int(bool(ch)),allfields,some])
print(dict(stats));print('first mismatches',bad[:6])
