extern int f(void);int run(int x){static int k=f();return k+x;}
