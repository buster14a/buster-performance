int run(int x){static _Thread_local int q=3;return q+=x;}
