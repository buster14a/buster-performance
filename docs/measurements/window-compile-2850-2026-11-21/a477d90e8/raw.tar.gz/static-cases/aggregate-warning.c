int run(int x){struct T{unsigned char n;};static struct T k={0x1234};return k.n+x;}
