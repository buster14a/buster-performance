int run(int x){static int a[3]={[2]=1,[2]=4};int b[3]={[0]=x,[0]=6};return a[2]+b[0];}
