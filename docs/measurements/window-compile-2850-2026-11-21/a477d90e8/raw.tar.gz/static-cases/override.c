int run(int x){static int a[4]={[1]=7,[1]=5};return x+a[1];}
