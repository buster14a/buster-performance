int run(int x){static int k=5; if(x&1){static int k=6;return ++k;} return k+=2;}
