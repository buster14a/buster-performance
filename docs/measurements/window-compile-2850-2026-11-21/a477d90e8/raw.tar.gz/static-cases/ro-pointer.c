static int a[]={3,2,8,1};int run(int x){static int *q[3]={a+2,&a[1],a};return *q[(unsigned)x%3];}
