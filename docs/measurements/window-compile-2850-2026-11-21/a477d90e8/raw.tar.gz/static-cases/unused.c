int run(int x){static const int dead[]={1,2,3}; return x;}
