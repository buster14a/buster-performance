int run(int x){struct S {int a[2];}; static struct S s={.a[1]=2,.a={3,4}};return s.a[x&1];}
