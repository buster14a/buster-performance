int run(int x){static int s=4;s+=x;return s;}
