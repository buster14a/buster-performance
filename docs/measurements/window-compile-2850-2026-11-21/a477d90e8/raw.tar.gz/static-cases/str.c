int run(int x){static const char t[][5]={"a\0bc","wxyz",[3]="k"};return t[x&3][(x>>2)&3];}
