#include <stdio.h>
extern int run(int); int main(void){unsigned sum=1;for(int j=0;j<99;j++)sum=sum*71u+(unsigned)run(j);printf("%u\n",sum);return 0;}
