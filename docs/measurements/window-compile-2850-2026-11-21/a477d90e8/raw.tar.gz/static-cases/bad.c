int run(int x){static int* k=3;return x+*k;}
