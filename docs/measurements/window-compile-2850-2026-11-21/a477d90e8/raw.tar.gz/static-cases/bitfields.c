int run(int x){struct R{unsigned a:3; signed b:5;};static struct R k[2]={{3,-2},{4,8}};return (int)k[x&1].a+k[x&1].b;}
