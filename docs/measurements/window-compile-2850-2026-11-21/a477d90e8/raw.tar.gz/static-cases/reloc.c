static int v[8]={1,2,3,4,5,6,7,8};int run(int x){struct T{int n;int *p;}; static const struct T t[]={{2,&v[1]},{.p=v+4,.n=3}};return t[x&1].n+*t[x&1].p;}
