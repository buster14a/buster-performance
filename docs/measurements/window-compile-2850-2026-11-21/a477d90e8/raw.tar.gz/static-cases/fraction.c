int run(int x){static int n=1.75;return n+x;}
