int run(int x){static const int t[7]={[5]=8,[2]=3,[0]=6};return t[(unsigned)x%7];}
