static int h(int x){static int k=9;return k+=x;}int run(int x){static int k=2;return h(x)-k++;}
