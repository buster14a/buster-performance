int run(int x){int a[4]={[1]=x++,[1]=x+7};return a[1];}
