int run(int x){static void *p=0;static int k[8]={0};return (p!=0)+k[x&7];}
