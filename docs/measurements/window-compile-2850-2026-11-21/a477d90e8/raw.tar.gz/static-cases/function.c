static int add(int x){return x+3;} static int sub(int x){return x-2;} int run(int x){static int (*const fs[])(int)={add,sub};return fs[x&1](x);}
