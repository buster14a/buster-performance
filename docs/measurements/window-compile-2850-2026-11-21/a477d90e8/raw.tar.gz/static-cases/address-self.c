int run(int x){static void *p=&p;return (p==&p)+x;}
