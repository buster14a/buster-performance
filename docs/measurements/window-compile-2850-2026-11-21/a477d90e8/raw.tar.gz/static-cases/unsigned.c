int run(int x){static unsigned char c=0x1234;return c+x;}
