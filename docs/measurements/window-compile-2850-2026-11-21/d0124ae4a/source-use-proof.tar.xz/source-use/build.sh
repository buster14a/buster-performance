#!/bin/bash
set -eu
cd "$(dirname "$0")/../unpublished-source-bindings"
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
./build.sh >../unpublished-binding-study/build.log 2>&1
cp ../default-integer-control/build/predefines.h build/predefines.h
./build/compiler test-checker --seed 2850 --part 6/8 >../unpublished-binding-study/early-shard6.log 2>&1
cd ../switch-inputs
source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
BUSTER_SOURCE_USE_CENSUS=1 ../unpublished-source-bindings/build/compiler -c -o ../unpublished-binding-study/sqlite.candidate.o "${args[@]}" >../unpublished-binding-study/sqlite.out 2>../unpublished-binding-study/counter.txt
../default-integer-control/build/compiler -c -o ../unpublished-binding-study/sqlite.parent.o "${args[@]}" >../unpublished-binding-study/parent.out 2>../unpublished-binding-study/parent.err
cmp ../unpublished-binding-study/sqlite.candidate.o ../unpublished-binding-study/sqlite.parent.o
python3 ../unpublished-binding-study/list-census.py >../unpublished-binding-study/list-census.log
python3 ../unpublished-binding-study/four-way.py >../unpublished-binding-study/four-way.log
python3 ../unpublished-binding-study/events.py >../unpublished-binding-study/events.log 2>&1
cmp ../unpublished-binding-study/sqlite-candidate.answers ../proven-use-study/sqlite-upstream.answers
cmp ../unpublished-binding-study/buster-candidate.answers ../proven-use-study/buster-upstream.answers
python3 ../unpublished-binding-study/oracle.py >../unpublished-binding-study/oracle.log 2>&1
python3 ../unpublished-binding-study/local_pairs.py >../unpublished-binding-study/pairs.log 2>&1
python3 ../unpublished-binding-study/target_pairs.py >../unpublished-binding-study/target.log 2>&1
parent=$PWD/../default-integer-control/build/compiler
new=$PWD/../unpublished-source-bindings/build/compiler
out=$PWD/../unpublished-binding-study/corpus
mkdir -p "$out"
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
for g in sqlite main lua musl; do var=${g}_arguments; eval "args=(${!var})"; python3 ../default-object-qa/pair.py "$out" "$g" "$parent" "$new" "${args[@]}"; done
python3 ../unpublished-binding-study/pmu.py >../unpublished-binding-study/pmu.log 2>&1
cd ../unpublished-source-bindings
for part in {1..8}; do ./build/compiler test-checker --seed 2850 --part "$part/8" >"../unpublished-binding-study/checker-$part.log" 2>&1; done
