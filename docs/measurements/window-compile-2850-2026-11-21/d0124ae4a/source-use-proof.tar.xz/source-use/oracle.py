from pathlib import Path
import csv,hashlib,subprocess as sp,itertools,os
w=Path(__file__).resolve().parent.parent;d=w/'unpublished-binding-study';out=d/'oracle';out.mkdir(exist_ok=True);p=w/'default-integer-control/build/compiler';q=w/'unpublished-source-bindings/build/compiler';clang=Path('/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang');types=['void','int','unsigned','float','double','char','T','C','S','P','Fn','Arr','Aligned','Node','V'];patterns=['{}','const {}','{} *','const {} *','{} **','{} *const','struct Tagged *','enum E','int named','int x[static 4]','int(*)(int)','...','void bad','__attribute__((unused)) int','_Atomic(int)','const void','register int','VOL','RV','int a, int a','int wrong[0]','typeof(int)', 'int __attribute__((ns_consumed))'];head='''typedef unsigned long T;typedef char C;typedef struct Tagged{int v;}S;typedef int *P;typedef int Fn(int);typedef int Arr[4];typedef int Aligned __attribute__((aligned(16)));typedef int *Node __attribute__((noderef));typedef volatile int V;typedef int VOL;typedef const int RV;enum E { A=1 };\n''';modes={'default':['-c'],'severe':['-c','-Weverything','-Werror','-ferror-limit=0'],'warnings':['-c','-Wall','-Wextra','-ferror-limit=0'],'assembly':['-S'],'debug':['-g','-c'],'typed':['--dump-typed','-c'],'scalar':['--scalar','-c'],'verify':['--verify','-c']}; cases={};h=lambda b:hashlib.sha256(b).hexdigest()
for i,t in enumerate(types):
 for offset in [0,5,10,15,20]:
  params=[pat.format(t) if '{}' in pat else pat for pat in patterns[offset:offset+5]];decls=[]
  for j,v in enumerate(params):
   decls.extend([f'extern int fn{j}({v});',f'static int local{j}({v});',f'extern int two{j}(int,{v});',f'extern int three{j}({v},int);']);
  cases[f'type{i}-{offset}']=head+'\n'.join(decls)+'\nint go(void){return 0;}\n'
cases['redeclarations']=head+'int f(C*,T*,int);int f(char*,unsigned long*,int);int f(char *c,T *x,int k){return c[k]+*x;}\nint main(void){char s[]={2,9};T x=7;return f(s,&x,1)!=16;}\n'
cases['shadow']=head+'extern int f(T*);int g(void){typedef double T;extern int f(T*);return 0;}extern int f(T*);\n'
cases['definition-selector']='typedef struct S {int k;} S;extern int f(const S*,int);int f(const S *p,int k){return p->k+k;}int main(void){S p={8};return f(&p,4)!=12;}\n'
cases['extensions']='typedef int T __attribute__((deprecated));typedef int G __attribute__((address_space(1)));typedef int Fn(int) __attribute__((ms_abi));extern int a(T*,G*,Fn*);int go(void){return 0;}\n'
cases['nul']='int f(void *); int g(void **); int h(void); int body(void){return h();}\n'
cases['overload']=head+'__attribute__((overloadable)) int f(T*); __attribute__((overloadable)) int f(C*);\n'
cases['linkset']=head+'extern int f(T*,T*, int); int f(T *a,T*b,int n){return a[0]+b[0]+n;} int main(void){T a=9,b=1;return f(&a,&b,3)!=13;}\n'
for i,t in enumerate(['int','unsigned','unsigned long','signed char','float','double','_Bool','T','C','S','P','Fn','Arr','Aligned','Node','V','enum E','struct Tagged']):
 for j,form in enumerate(['{t} x;', '{t} *x = 0;', 'const {t} *x = 0;', '{t} **x=0;', 'static {t} x;', 'extern {t} x;', '{t} x, *y;', 'register {t} x;', '{t} x[2];', '{t} x __attribute__((unused));']):
  code=form.format(t=t);cases[f'local-{i}-{j}']=head + 'static int outer(int n){{int x=1; n+=x;}{'+code+'}return n;}int main(void){return outer(3)!=4;}\n'
 for j,rtype in enumerate(['int','long','unsigned char','const char *','T','S *']):
  cases[f'definition-{i}-{j}']=head + f'static {rtype} named({t} *p, const {t} *q, int n){{(void)p;(void)q;return ({rtype})0;}} int main(void){{return named(0,0,1)!=0;}}\n'
cases.update({
 'dialect17-bool': 'typedef int bool; int run(bool value){bool local=value;return sizeof local;}int main(void){return run(5)!=sizeof(int);}',
 'dialect17-char8': 'typedef long char8_t;char8_t f(char8_t x){char8_t y=x;return y;}int main(void){return f(789)!=789;}',
 'nested-shadow-local': 'typedef int T; int f(T a){typedef long T;T b=9;{typedef char T; T x=3;b+=x;}return a+b;}int main(void){return f(5)!=17;}\n',
 'invalid-merge': 'typedef int T; void f(int p) {extern T g;extern long g; int a; double a; int p; }\n',
 'anonymous-union': 'typedef union {long a; int b;} U; int f(U *u,U x){U *p=u; U a=x;return p->b + a.b;}\n',
 'array-of-pointer': 'typedef int T; int f(int n,int **p){T *q[3];q[0]=*p;return *q[0];}\n',
 'typedef-hiding': 'typedef int T;int f(int T,int value){int a=T;{typedef long T;T x=value;a+=x;}return a;}int main(void){return f(2,6)!=8;}\n',
 'signed-pointer': 'typedef signed char C; C *f(C *p){C *q=p;return q;}int main(void){C c=-4;return *f(&c)!=-4;}\n',
 'address-space': 'typedef int Global __attribute__((address_space(1))); Global *f(Global *p){Global *q=p;return q;}\n',
 'variably-modified': 'int f(int n){typedef int A[n]; A x; x[0]=n; return x[0];}int main(void){return f(4)!=4;}\n',
 'parameter-duplicate': 'int f(int a,double a){return 4;}\n',
 'declaration-continuation':'int f(void){int *x=0, a=5,b=a+8;return b;}int main(void){return f()!=13;}\n',
 'attribute-cleanup':'int n;void go(int*p){n+=*p;}int run(void){int k __attribute__((cleanup(go)))=3;return 0;}int main(void){run();return n!=3;}\n',
 'tag-incomplete':'typedef struct Missing Incomplete;void f(Incomplete *p){Incomplete x;Incomplete *q=p;}\n',
 'unnamed-parameter':'int f(int, int n, const char *) { int x = n; return x; }\n',
 'bitint-and-enum':'typedef _BitInt(41) Wide;typedef enum V{A=2} V;int f(Wide a,V v){Wide w=a+v;V x=A;return w+x;}\n',
 'string-pointer':'const char *f(const char *s){const char *p=s;return p+1;}int main(void){return *f("abc")!=98;}\n',
})
with (d/'oracle.tsv').open('w',buffering=1) as log:
 wr=csv.writer(log,delimiter='\t');wr.writerow(['source','mode','same','status','stderr','output','runtime','clang_runtime']);
 for name,src in cases.items():
  f=out/(name+'.c');f.write_text(src)
  for m,flags in modes.items():
   result=[];native=[];obj=out/('unit.s' if m=='assembly' else 'unit.o');exe=out/'unit';oracle=None
   for cc in (p,q):
    obj.unlink(missing_ok=True);r=sp.run([cc,'-std=gnu17' if name.startswith('dialect17-') else '-std=gnu23',*flags,f,'-o',obj],capture_output=True,timeout=30);result.append((r.returncode,r.stdout,r.stderr,obj.read_bytes() if obj.exists() else b''));
    if m=='default' and (name in ('linkset','definition-selector','redeclarations','nested-shadow-local','typedef-hiding','signed-pointer','variably-modified','declaration-continuation','attribute-cleanup','string-pointer') or name.startswith('dialect17-') or name.startswith('local-') or name.startswith('definition-')) and r.returncode==0:
     link=sp.run([clang,'-no-pie',obj,'-o',exe],capture_output=True);assert link.returncode==0,link.stderr;native.append(sp.run([exe],capture_output=True).returncode)
   if native:
    c=sp.run([clang,'-std=gnu17' if name.startswith('dialect17-') else '-std=gnu23','-Wno-everything',f,'-o',exe],capture_output=True);oracle=sp.run([exe],capture_output=True).returncode if c.returncode==0 else 'Clang_rejected'
   ref,fix=result;same=ref==fix and len(set(native))<=1 and (oracle=='Clang_rejected' or all(x==oracle for x in native));wr.writerow([name,m,int(same),fix[0],h(fix[2]),h(fix[3]),native,oracle]);
   if not same:
    dest=out/name/m;dest.mkdir(exist_ok=True,parents=True);print(name,m,[(tag,len(a),len(b)) for tag,a,b in zip(['stdout','stderr','obj'],ref[1:],fix[1:]) if a!=b],flush=True)
    for id,rs in [('ref',ref),('fix',fix)]:
     for tag,v in zip(['stdout','stderr','obj'],rs[1:]):(dest/(id+'.'+tag)).write_bytes(v)
