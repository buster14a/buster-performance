from pathlib import Path
import hashlib,os,re,subprocess
s=Path(__file__).resolve().parent;w=s.parent;cs=w/'pregraph-warning-study/compiler-source';sqlite=w/'switch-inputs/sqlite/sqlite3.c'
for n,args in [('sqlite',['-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I'+str(sqlite.parent),sqlite]),('buster',['-march=native','-I'+str(cs/'src'),'-fwrapv','-funsigned-char','--predefines',w/'proof-predefines.h',cs/'src/buster/compiler/main.c'])]:
 for mode,flags in [('default',[]),('warning',['-Wall','-Wextra']),('quiet',['-w']),('off',['--attested=off']),('scalar',['--scalar'])]:
  result=[];record=[]
  for tree in ['default-integer-control','unpublished-source-bindings']:
   obj=s/'list-census.o';obj.unlink(missing_ok=True);rd=subprocess.run([w/tree/'build/compiler',*flags,'-c',*args,'-o',obj],env={**os.environ,'BUSTER_PENDING_BINDING_CENSUS':'1'},capture_output=True,timeout=90)
   matches=re.findall(rb'^pending-binding-list filter=(\d+) uses=(\d+) published=(\d+) events=(\d+)\n',rd.stderr,re.M)
   clean=re.sub(rb'^pending-binding-list .*\n',b'',rd.stderr,flags=re.M);result.append((rd.returncode,rd.stdout,clean,obj.read_bytes() if obj.exists() else b''));record+=matches
  assert result[0]==result[1],(n,mode)
  print(n,mode,[tuple(int(x) for x in entry) for entry in record],hashlib.sha256(result[0][-1]).hexdigest(),flush=True)
