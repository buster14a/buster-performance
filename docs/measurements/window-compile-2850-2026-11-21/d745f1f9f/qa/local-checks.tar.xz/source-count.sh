#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;cc=$d/../main-fbef-clean/build/compiler
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
"$cc" benchmark-backend-source --only validate "${args[@]}" > "$d/source-count.log"
rg '^backend-source: file=.*functions=' "$d/source-count.log" | tee "$d/source-count.txt"
