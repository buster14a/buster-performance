int probe(int value)
{
    asm goto("testl %0, %0\n\tje %l[zero]\n\tjs %l[negative]" : : "r"(value) : "cc" : zero, negative);
    return value + 1;
zero:
    return 17;
negative:
    return 31;
}

int main(void)
{
    return probe(1) != 2 || probe(0) != 17 || probe(-1) != 31;
}
