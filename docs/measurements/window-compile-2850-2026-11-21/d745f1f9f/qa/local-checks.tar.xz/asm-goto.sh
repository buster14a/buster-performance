#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
d=$PWD
cc=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
for path in scalar vector; do
    flags=()
    if [[ $path == scalar ]];then flags+=(--scalar);fi
    for tree in tier0-entry-storage main-fbef-clean;do
        ../"$tree"/build/compiler "${flags[@]}" -nostdinc -c "$d/asm-goto.c" -o "$d/$tree-$path.o"
        "$cc" "$d/$tree-$path.o" -o "$d/$tree-$path"
        "$d/$tree-$path"
    done
    cmp "$d/main-fbef-clean-$path.o" "$d/tier0-entry-storage-$path.o"
done
"$cc" -O0 "$d/asm-goto.c" -o "$d/clang-goto"; "$d/clang-goto"
echo 'matched -c objects and native three-way asm goto results on both selector paths and Clang'
