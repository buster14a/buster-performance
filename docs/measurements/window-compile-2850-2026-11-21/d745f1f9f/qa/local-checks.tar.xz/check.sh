#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD
bash "$d/asm-goto.sh" > "$d/asm-goto.log" 2>&1
bash "$d/sqlite.sh" > "$d/sqlite.log" 2>&1
bash "$d/unit.sh" || { tail -50 "$d/unit.log";exit 1; }
bash "$d/corpus.sh" > "$d/corpus.log" 2>&1
python3 - "$d" <<'PY'
import csv,sys
from pathlib import Path
d=Path(sys.argv[1])
status=0
for p in sorted((d/'final-corpus').glob('*.tsv')):
    rows=list(csv.DictReader(p.open(),delimiter='\t'))
    n=sum(r['same']=='1' for r in rows)
    print(p.stem, n, 'of', len(rows), 'matching')
    status |= int(n!=len(rows))
raise SystemExit(status)
PY
