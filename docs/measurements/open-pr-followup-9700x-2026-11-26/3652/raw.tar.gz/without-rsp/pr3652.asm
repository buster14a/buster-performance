
/home/david/buster-fast-bench/pr-numbers-codex-6b0809fc/followup-9700x/3652/without-rsp/pr3652-directives.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <aligned>:
   0:	48 83 ec 28          	sub    $0x28,%rsp
   4:	48 8d 04 24          	lea    (%rsp),%rax
   8:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
   d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  12:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  17:	66 66 66 66 66 2e 66 	data16 data16 data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
  1e:	0f 1f 84 00 00 02 00 
  25:	00 
  26:	66 66 66 66 66 2e 66 	data16 data16 data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
  2d:	0f 1f 84 00 00 02 00 
  34:	00 
  35:	66 2e 66 0f 1f 84 00 	data16 cs nopw 0x200(%rax,%rax,1)
  3c:	00 02 00 00 
  40:	90                   	nop
  41:	90                   	nop
  42:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  49:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  50:	00 00 00 00 
  54:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  5b:	00 00 00 00 
  5f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66:	00 00 00 00 
  6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  71:	00 00 00 00 
  75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  7c:	00 00 00 00 
  80:	48 8d 05 f9 ff ff ff 	lea    -0x7(%rip),%rax        # 80 <aligned+0x80>
  87:	90                   	nop
  88:	90                   	nop
  89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  90:	48 8d 0d f9 ff ff ff 	lea    -0x7(%rip),%rcx        # 90 <aligned+0x90>
  97:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  9c:	48 89 06             	mov    %rax,(%rsi)
  9f:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  a4:	48 89 0e             	mov    %rcx,(%rsi)
  a7:	48 8b 04 24          	mov    (%rsp),%rax
  ab:	48 83 e0 3f          	and    $0x3f,%rax
  af:	48 85 c0             	test   %rax,%rax
  b2:	b8 00 00 00 00       	mov    $0x0,%eax
  b7:	0f 94 c0             	sete   %al
  ba:	6b c0 65             	imul   $0x65,%eax,%eax
  bd:	03 c7                	add    %edi,%eax
  bf:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  c4:	48 83 e1 0f          	and    $0xf,%rcx
  c8:	48 85 c9             	test   %rcx,%rcx
  cb:	b9 00 00 00 00       	mov    $0x0,%ecx
  d0:	0f 94 c1             	sete   %cl
  d3:	6b c9 67             	imul   $0x67,%ecx,%ecx
  d6:	03 c1                	add    %ecx,%eax
  d8:	48 83 c4 28          	add    $0x28,%rsp
  dc:	c3                   	ret
  dd:	cc                   	int3
  de:	cc                   	int3
  df:	cc                   	int3

00000000000000e0 <data_bytes>:
  e0:	48 83 ec 18          	sub    $0x18,%rsp
  e4:	48 8d 04 24          	lea    (%rsp),%rax
  e8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  ed:	eb 1c                	jmp    10b <data_bytes+0x2b>
  ef:	23 45 89             	and    -0x77(%rbp),%eax
  f2:	67 01 ef             	addr32 add %ebp,%edi
  f5:	cd ab                	int    $0xab
  f7:	80 70 60 50          	xorb   $0x50,0x60(%rax)
  fb:	40 30 20             	xor    %spl,(%rax)
  fe:	10 41 5a             	adc    %al,0x5a(%rcx)
 101:	71 00                	jno    103 <data_bytes+0x23>
 103:	72 73                	jb     178 <relocated+0x18>
 105:	00 00                	add    %al,(%rax)
 107:	00 5a 5a             	add    %bl,0x5a(%rdx)
 10a:	a5                   	movsl  (%rsi),(%rdi)
 10b:	48 8d 05 dd ff ff ff 	lea    -0x23(%rip),%rax        # ef <data_bytes+0xf>
 112:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 117:	48 89 02             	mov    %rax,(%rdx)
 11a:	31 c0                	xor    %eax,%eax
 11c:	31 c9                	xor    %ecx,%ecx
 11e:	eb 22                	jmp    142 <data_bytes+0x62>
 120:	48 8b 14 24          	mov    (%rsp),%rdx
 124:	0f b6 14 0a          	movzbl (%rdx,%rcx,1),%edx
 128:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 12f <data_bytes+0x4f>
			12b: R_X86_64_PC32	.rodata-0x4
 12f:	0f b6 34 0e          	movzbl (%rsi,%rcx,1),%esi
 133:	3b d6                	cmp    %esi,%edx
 135:	ba 00 00 00 00       	mov    $0x0,%edx
 13a:	0f 94 c2             	sete   %dl
 13d:	03 c2                	add    %edx,%eax
 13f:	83 c1 01             	add    $0x1,%ecx
 142:	48 83 f9 1c          	cmp    $0x1c,%rcx
 146:	72 d8                	jb     120 <data_bytes+0x40>
 148:	6b c0 6b             	imul   $0x6b,%eax,%eax
 14b:	03 c7                	add    %edi,%eax
 14d:	48 83 c4 18          	add    $0x18,%rsp
 151:	c3                   	ret
 152:	cc                   	int3
 153:	cc                   	int3
 154:	cc                   	int3
 155:	cc                   	int3
 156:	cc                   	int3
 157:	cc                   	int3
 158:	cc                   	int3
 159:	cc                   	int3
 15a:	cc                   	int3
 15b:	cc                   	int3
 15c:	cc                   	int3
 15d:	cc                   	int3
 15e:	cc                   	int3
 15f:	cc                   	int3

0000000000000160 <relocated>:
 160:	48 83 ec 18          	sub    $0x18,%rsp
 164:	48 8d 04 24          	lea    (%rsp),%rax
 168:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 16d:	0f 1f 00             	nopl   (%rax)
 170:	eb 12                	jmp    184 <relocated+0x24>
 172:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
	...
			178: R_X86_64_64	.data
 180:	f8                   	clc
 181:	ff                   	(bad)
 182:	ff                   	(bad)
 183:	ff 48 8d             	decl   -0x73(%rax)
 186:	05 ed ff ff ff       	add    $0xffffffed,%eax
 18b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 190:	48 89 02             	mov    %rax,(%rdx)
 193:	48 8b 04 24          	mov    (%rsp),%rax
 197:	48 8b 00             	mov    (%rax),%rax
 19a:	48 8b 0c 24          	mov    (%rsp),%rcx
 19e:	8b 49 08             	mov    0x8(%rcx),%ecx
 1a1:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 1a8 <relocated+0x48>
			1a4: R_X86_64_PC32	.data-0x4
 1a8:	48 3b c2             	cmp    %rdx,%rax
 1ab:	ba 00 00 00 00       	mov    $0x0,%edx
 1b0:	0f 94 c2             	sete   %dl
 1b3:	6b d2 6d             	imul   $0x6d,%edx,%edx
 1b6:	03 d7                	add    %edi,%edx
 1b8:	03 10                	add    (%rax),%edx
 1ba:	33 c0                	xor    %eax,%eax
 1bc:	83 f9 f8             	cmp    $0xfffffff8,%ecx
 1bf:	0f 94 c0             	sete   %al
 1c2:	6b c0 71             	imul   $0x71,%eax,%eax
 1c5:	03 c2                	add    %edx,%eax
 1c7:	48 83 c4 18          	add    $0x18,%rsp
 1cb:	c3                   	ret
 1cc:	cc                   	int3
 1cd:	cc                   	int3
 1ce:	cc                   	int3
 1cf:	cc                   	int3

00000000000001d0 <short_branches>:
 1d0:	53                   	push   %rbx
 1d1:	48 83 ec 50          	sub    $0x50,%rsp
 1d5:	48 8d 04 24          	lea    (%rsp),%rax
 1d9:	48 8d 5c 24 40       	lea    0x40(%rsp),%rbx
 1de:	8b cf                	mov    %edi,%ecx
 1e0:	83 e1 07             	and    $0x7,%ecx
 1e3:	83 c1 01             	add    $0x1,%ecx
 1e6:	48 89 0c 24          	mov    %rcx,(%rsp)
 1ea:	89 7c 24 40          	mov    %edi,0x40(%rsp)
 1ee:	48 8b cb             	mov    %rbx,%rcx
 1f1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
 1f6:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
 1fb:	8b 09                	mov    (%rcx),%ecx
 1fd:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 202:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 207:	48 8b 00             	mov    (%rax),%rax
 20a:	4c 8b d8             	mov    %rax,%r11
 20d:	48 8b c1             	mov    %rcx,%rax
 210:	49 8b cb             	mov    %r11,%rcx
 213:	83 c0 03             	add    $0x3,%eax
 216:	eb 01                	jmp    219 <short_branches+0x49>
 218:	90                   	nop
 219:	e2 f8                	loop   213 <short_branches+0x43>
 21b:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
 220:	89 06                	mov    %eax,(%rsi)
 222:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
 227:	48 89 0e             	mov    %rcx,(%rsi)
 22a:	83 e7 03             	and    $0x3,%edi
 22d:	48 8b c3             	mov    %rbx,%rax
 230:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 235:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 23a:	8b 00                	mov    (%rax),%eax
 23c:	48 8b cf             	mov    %rdi,%rcx
 23f:	e3 05                	jrcxz  246 <short_branches+0x76>
 241:	eb 00                	jmp    243 <short_branches+0x73>
 243:	83 c0 09             	add    $0x9,%eax
 246:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 24b:	89 02                	mov    %eax,(%rdx)
 24d:	8b 44 24 40          	mov    0x40(%rsp),%eax
 251:	48 8b 0c 24          	mov    (%rsp),%rcx
 255:	6b c9 7f             	imul   $0x7f,%ecx,%ecx
 258:	03 c1                	add    %ecx,%eax
 25a:	48 83 c4 50          	add    $0x50,%rsp
 25e:	5b                   	pop    %rbx
 25f:	c3                   	ret

0000000000000260 <address32>:
 260:	48 83 ec 18          	sub    $0x18,%rsp
 264:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
 269:	48 89 04 24          	mov    %rax,(%rsp)
 26d:	48 8b cf             	mov    %rdi,%rcx
 270:	67 8d 44 49 05       	lea    0x5(%ecx,%ecx,2),%eax
 275:	48 8b 14 24          	mov    (%rsp),%rdx
 279:	89 02                	mov    %eax,(%rdx)
 27b:	8b 44 24 10          	mov    0x10(%rsp),%eax
 27f:	48 83 c4 18          	add    $0x18,%rsp
 283:	c3                   	ret
 284:	cc                   	int3
 285:	cc                   	int3
 286:	cc                   	int3
 287:	cc                   	int3
 288:	cc                   	int3
 289:	cc                   	int3
 28a:	cc                   	int3
 28b:	cc                   	int3
 28c:	cc                   	int3
 28d:	cc                   	int3
 28e:	cc                   	int3
 28f:	cc                   	int3

0000000000000290 <fill>:
 290:	48 83 ec 18          	sub    $0x18,%rsp
 294:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
 299:	89 7c 24 10          	mov    %edi,0x10(%rsp)
 29d:	48 89 04 24          	mov    %rax,(%rsp)
 2a1:	48 8b 04 24          	mov    (%rsp),%rax
 2a5:	8b 00                	mov    (%rax),%eax
 2a7:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 2ac:	0f 1f 40 00          	nopl   0x0(%rax)
 2b0:	90                   	nop
 2b1:	83 c0 11             	add    $0x11,%eax
 2b4:	48 8b 14 24          	mov    (%rsp),%rdx
 2b8:	89 02                	mov    %eax,(%rdx)
 2ba:	8b 44 24 10          	mov    0x10(%rsp),%eax
 2be:	48 83 c4 18          	add    $0x18,%rsp
 2c2:	c3                   	ret
 2c3:	cc                   	int3
 2c4:	cc                   	int3
 2c5:	cc                   	int3
 2c6:	cc                   	int3
 2c7:	cc                   	int3
 2c8:	cc                   	int3
 2c9:	cc                   	int3
 2ca:	cc                   	int3
 2cb:	cc                   	int3
 2cc:	cc                   	int3
 2cd:	cc                   	int3
 2ce:	cc                   	int3
 2cf:	cc                   	int3

00000000000002d0 <section_data>:
 2d0:	48 83 ec 18          	sub    $0x18,%rsp
 2d4:	48 8d 04 24          	lea    (%rsp),%rax
 2d8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 2dd:	48 8d 05 00 00 00 00 	lea    0x0(%rip),%rax        # 2e4 <section_data+0x14>
			2e0: R_X86_64_PC32	.rodata.buster2351-0x4
 2e4:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 2e9:	48 89 02             	mov    %rax,(%rdx)
 2ec:	48 8b 04 24          	mov    (%rsp),%rax
 2f0:	81 38 78 56 34 12    	cmpl   $0x12345678,(%rax)
 2f6:	b8 00 00 00 00       	mov    $0x0,%eax
 2fb:	0f 94 c0             	sete   %al
 2fe:	69 c0 8b 00 00 00    	imul   $0x8b,%eax,%eax
 304:	03 c7                	add    %edi,%eax
 306:	48 83 c4 18          	add    $0x18,%rsp
 30a:	c3                   	ret
 30b:	cc                   	int3
 30c:	cc                   	int3
 30d:	cc                   	int3
 30e:	cc                   	int3
 30f:	cc                   	int3
 310:	cc                   	int3
 311:	cc                   	int3
 312:	cc                   	int3
 313:	cc                   	int3
 314:	cc                   	int3
 315:	cc                   	int3
 316:	cc                   	int3
 317:	cc                   	int3
 318:	cc                   	int3
 319:	cc                   	int3
 31a:	cc                   	int3
 31b:	cc                   	int3
 31c:	cc                   	int3
 31d:	cc                   	int3
 31e:	cc                   	int3
 31f:	cc                   	int3
 320:	cc                   	int3
 321:	cc                   	int3
 322:	cc                   	int3
 323:	cc                   	int3
 324:	cc                   	int3
 325:	cc                   	int3
 326:	cc                   	int3
 327:	cc                   	int3
 328:	cc                   	int3
 329:	cc                   	int3
 32a:	cc                   	int3
 32b:	cc                   	int3
 32c:	cc                   	int3
 32d:	cc                   	int3
 32e:	cc                   	int3
 32f:	cc                   	int3
 330:	cc                   	int3
 331:	cc                   	int3
 332:	cc                   	int3
 333:	cc                   	int3
 334:	cc                   	int3
 335:	cc                   	int3
 336:	cc                   	int3
 337:	cc                   	int3
 338:	cc                   	int3
 339:	cc                   	int3
 33a:	cc                   	int3
 33b:	cc                   	int3
 33c:	cc                   	int3
 33d:	cc                   	int3
 33e:	cc                   	int3
 33f:	cc                   	int3

0000000000000340 <trailing_alignment>:
 340:	48 83 ec 08          	sub    $0x8,%rsp
 344:	66 66 66 66 66 2e 66 	data16 data16 data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
 34b:	0f 1f 84 00 00 02 00 
 352:	00 
 353:	66 66 66 66 66 2e 66 	data16 data16 data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
 35a:	0f 1f 84 00 00 02 00 
 361:	00 
 362:	66 66 66 66 66 2e 66 	data16 data16 data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
 369:	0f 1f 84 00 00 02 00 
 370:	00 
 371:	66 66 66 66 66 2e 66 	data16 data16 data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
 378:	0f 1f 84 00 00 02 00 
 37f:	00 
 380:	90                   	nop
 381:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 388:	00 
 389:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 390:	00 00 00 00 
 394:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 39b:	00 00 00 00 
 39f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 3a6:	00 00 00 00 
 3aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 3b1:	00 00 00 00 
 3b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 3bc:	00 00 00 00 

00000000000003c0 <buster2351_trailing>:
 3c0:	90                   	nop
 3c1:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 3c8 <buster2351_trailing+0x8>
			3c4: R_X86_64_REX_GOTPCRELX	buster2351_trailing-0x4
 3c8:	48 83 e0 3f          	and    $0x3f,%rax
 3cc:	48 85 c0             	test   %rax,%rax
 3cf:	b8 00 00 00 00       	mov    $0x0,%eax
 3d4:	0f 94 c0             	sete   %al
 3d7:	69 c0 83 00 00 00    	imul   $0x83,%eax,%eax
 3dd:	03 c7                	add    %edi,%eax
 3df:	48 83 c4 08          	add    $0x8,%rsp
 3e3:	c3                   	ret
 3e4:	cc                   	int3
 3e5:	cc                   	int3
 3e6:	cc                   	int3
 3e7:	cc                   	int3
 3e8:	cc                   	int3
 3e9:	cc                   	int3
 3ea:	cc                   	int3
 3eb:	cc                   	int3
 3ec:	cc                   	int3
 3ed:	cc                   	int3
 3ee:	cc                   	int3
 3ef:	cc                   	int3
 3f0:	cc                   	int3
 3f1:	cc                   	int3
 3f2:	cc                   	int3
 3f3:	cc                   	int3
 3f4:	cc                   	int3
 3f5:	cc                   	int3
 3f6:	cc                   	int3
 3f7:	cc                   	int3
 3f8:	cc                   	int3
 3f9:	cc                   	int3
 3fa:	cc                   	int3
 3fb:	cc                   	int3
 3fc:	cc                   	int3
 3fd:	cc                   	int3
 3fe:	cc                   	int3
 3ff:	cc                   	int3

0000000000000400 <alignment_only>:
 400:	48 83 ec 08          	sub    $0x8,%rsp
 404:	66 66 66 66 66 2e 66 	data16 data16 data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
 40b:	0f 1f 84 00 00 02 00 
 412:	00 
 413:	66 66 66 66 66 2e 66 	data16 data16 data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
 41a:	0f 1f 84 00 00 02 00 
 421:	00 
 422:	66 66 66 66 66 2e 66 	data16 data16 data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
 429:	0f 1f 84 00 00 02 00 
 430:	00 
 431:	66 66 66 66 66 2e 66 	data16 data16 data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
 438:	0f 1f 84 00 00 02 00 
 43f:	00 

0000000000000440 <buster2351_only>:
 440:	90                   	nop
 441:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 448 <buster2351_only+0x8>
			444: R_X86_64_REX_GOTPCRELX	buster2351_only-0x4
 448:	48 83 e0 3f          	and    $0x3f,%rax
 44c:	48 85 c0             	test   %rax,%rax
 44f:	b8 00 00 00 00       	mov    $0x0,%eax
 454:	0f 94 c0             	sete   %al
 457:	69 c0 89 00 00 00    	imul   $0x89,%eax,%eax
 45d:	03 c7                	add    %edi,%eax
 45f:	48 83 c4 08          	add    $0x8,%rsp
 463:	c3                   	ret
 464:	cc                   	int3
 465:	cc                   	int3
 466:	cc                   	int3
 467:	cc                   	int3
 468:	cc                   	int3
 469:	cc                   	int3
 46a:	cc                   	int3
 46b:	cc                   	int3
 46c:	cc                   	int3
 46d:	cc                   	int3
 46e:	cc                   	int3
 46f:	cc                   	int3

0000000000000470 <vector_data>:
 470:	48 83 ec 38          	sub    $0x38,%rsp
 474:	48 8d 04 24          	lea    (%rsp),%rax
 478:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 47d:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
 484:	00 
 485:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 48c:	00 00 
 48e:	0f 57 c0             	xorps  %xmm0,%xmm0
 491:	f3 0f 2a c7          	cvtsi2ss %edi,%xmm0
 495:	f3 0f 11 04 24       	movss  %xmm0,(%rsp)
 49a:	41 bb 00 00 c0 3f    	mov    $0x3fc00000,%r11d
 4a0:	66 41 0f 6e c3       	movd   %r11d,%xmm0
 4a5:	f3 0f 11 44 24 04    	movss  %xmm0,0x4(%rsp)
 4ab:	41 bb 00 00 00 c0    	mov    $0xc0000000,%r11d
 4b1:	66 41 0f 6e c3       	movd   %r11d,%xmm0
 4b6:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
 4bc:	41 bb 00 00 40 40    	mov    $0x40400000,%r11d
 4c2:	66 41 0f 6e c3       	movd   %r11d,%xmm0
 4c7:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
 4cd:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 4d2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 4d7:	62 f1 7e 08 6f 00    	vmovdqu32 (%rax),%xmm0
 4dd:	62 f1 7e 08 7f 44 24 	vmovdqu32 %xmm0,0x10(%rsp)
 4e4:	01 
 4e5:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
 4ea:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 4ef:	c5 f8 10 00          	vmovups (%rax),%xmm0
 4f3:	66 66 66 2e 66 0f 1f 	data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
 4fa:	84 00 00 02 00 00 
 500:	0f 58 c0             	addps  %xmm0,%xmm0
 503:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
 508:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 50c:	f3 0f 10 04 24       	movss  (%rsp),%xmm0
 511:	41 bb 00 00 40 40    	mov    $0x40400000,%r11d
 517:	66 41 0f 6e cb       	movd   %r11d,%xmm1
 51c:	c4 e2 79 99 4c 24 04 	vfmadd132ss 0x4(%rsp),%xmm0,%xmm1
 523:	41 bb 00 00 a0 40    	mov    $0x40a00000,%r11d
 529:	66 41 0f 6e c3       	movd   %r11d,%xmm0
 52e:	c4 e2 71 99 44 24 08 	vfmadd132ss 0x8(%rsp),%xmm1,%xmm0
 535:	41 bb 00 00 e0 40    	mov    $0x40e00000,%r11d
 53b:	66 41 0f 6e cb       	movd   %r11d,%xmm1
 540:	c4 e2 79 99 4c 24 0c 	vfmadd132ss 0xc(%rsp),%xmm0,%xmm1
 547:	f3 0f 2c c1          	cvttss2si %xmm1,%eax
 54b:	48 83 c4 38          	add    $0x38,%rsp
 54f:	c3                   	ret
 550:	cc                   	int3
 551:	cc                   	int3
 552:	cc                   	int3
 553:	cc                   	int3
 554:	cc                   	int3
 555:	cc                   	int3
 556:	cc                   	int3
 557:	cc                   	int3
 558:	cc                   	int3
 559:	cc                   	int3
 55a:	cc                   	int3
 55b:	cc                   	int3
 55c:	cc                   	int3
 55d:	cc                   	int3
 55e:	cc                   	int3
 55f:	cc                   	int3

0000000000000560 <directed>:
 560:	53                   	push   %rbx
 561:	48 83 ec 30          	sub    $0x30,%rsp
 565:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
 56a:	48 8d 4c 24 2c       	lea    0x2c(%rsp),%rcx
 56f:	89 7c 24 28          	mov    %edi,0x28(%rsp)
 573:	8d 57 05             	lea    0x5(%rdi),%edx
 576:	89 54 24 2c          	mov    %edx,0x2c(%rsp)
 57a:	48 89 04 24          	mov    %rax,(%rsp)
 57e:	48 8b 04 24          	mov    (%rsp),%rax
 582:	8b 00                	mov    (%rax),%eax
 584:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
 589:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
 58e:	8b 09                	mov    (%rcx),%ecx
 590:	48 8b d7             	mov    %rdi,%rdx
 593:	66 66 66 2e 66 0f 1f 	data16 data16 data16 cs nopw 0x200(%rax,%rax,1)
 59a:	84 00 00 02 00 00 
 5a0:	83 c0 07             	add    $0x7,%eax
 5a3:	83 f1 13             	xor    $0x13,%ecx
 5a6:	85 d2                	test   %edx,%edx
 5a8:	78 09                	js     5b3 <directed+0x53>
 5aa:	74 0e                	je     5ba <directed+0x5a>
 5ac:	bf 00 00 00 00       	mov    $0x0,%edi
 5b1:	eb 0c                	jmp    5bf <directed+0x5f>
 5b3:	bf 01 00 00 00       	mov    $0x1,%edi
 5b8:	eb 05                	jmp    5bf <directed+0x5f>
 5ba:	bf 02 00 00 00       	mov    $0x2,%edi
 5bf:	48 8b 34 24          	mov    (%rsp),%rsi
 5c3:	89 06                	mov    %eax,(%rsi)
 5c5:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 5ca:	89 0e                	mov    %ecx,(%rsi)
 5cc:	8b c7                	mov    %edi,%eax
 5ce:	8b d8                	mov    %eax,%ebx
 5d0:	83 fb 01             	cmp    $0x1,%ebx
 5d3:	74 18                	je     5ed <directed+0x8d>
 5d5:	83 fb 02             	cmp    $0x2,%ebx
 5d8:	74 29                	je     603 <directed+0xa3>
 5da:	8b 44 24 28          	mov    0x28(%rsp),%eax
 5de:	8b 4c 24 2c          	mov    0x2c(%rsp),%ecx
 5e2:	8d 0c 49             	lea    (%rcx,%rcx,2),%ecx
 5e5:	03 c1                	add    %ecx,%eax
 5e7:	48 83 c4 30          	add    $0x30,%rsp
 5eb:	5b                   	pop    %rbx
 5ec:	c3                   	ret
 5ed:	8b 44 24 28          	mov    0x28(%rsp),%eax
 5f1:	8b 4c 24 2c          	mov    0x2c(%rsp),%ecx
 5f5:	8d 0c 89             	lea    (%rcx,%rcx,4),%ecx
 5f8:	03 c1                	add    %ecx,%eax
 5fa:	83 c0 65             	add    $0x65,%eax
 5fd:	48 83 c4 30          	add    $0x30,%rsp
 601:	5b                   	pop    %rbx
 602:	c3                   	ret
 603:	8b 44 24 28          	mov    0x28(%rsp),%eax
 607:	8b 4c 24 2c          	mov    0x2c(%rsp),%ecx
 60b:	6b c9 07             	imul   $0x7,%ecx,%ecx
 60e:	03 c1                	add    %ecx,%eax
 610:	05 d3 00 00 00       	add    $0xd3,%eax
 615:	48 83 c4 30          	add    $0x30,%rsp
 619:	5b                   	pop    %rbx
 61a:	c3                   	ret
 61b:	cc                   	int3
 61c:	cc                   	int3
 61d:	cc                   	int3
 61e:	cc                   	int3
 61f:	cc                   	int3

0000000000000620 <unreachable>:
 620:	8d 87 97 00 00 00    	lea    0x97(%rdi),%eax
 626:	c3                   	ret
 627:	cc                   	int3
 628:	cc                   	int3
 629:	cc                   	int3
 62a:	cc                   	int3
 62b:	cc                   	int3
 62c:	cc                   	int3
 62d:	cc                   	int3
 62e:	cc                   	int3
 62f:	cc                   	int3

0000000000000630 <tested>:
 630:	53                   	push   %rbx
 631:	55                   	push   %rbp
 632:	41 54                	push   %r12
 634:	48 83 ec 10          	sub    $0x10,%rsp
 638:	8d 1c 7f             	lea    (%rdi,%rdi,2),%ebx
 63b:	31 ed                	xor    %ebp,%ebp
 63d:	e9 fc 00 00 00       	jmp    73e <tested+0x10e>
 642:	8d 04 2f             	lea    (%rdi,%rbp,1),%eax
 645:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
 64a:	48 8b f8             	mov    %rax,%rdi
 64d:	e8 00 00 00 00       	call   652 <tested+0x22>
			64e: R_X86_64_PLT32	.text-0x4
 652:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 657:	8b cf                	mov    %edi,%ecx
 659:	2b cd                	sub    %ebp,%ecx
 65b:	48 89 04 24          	mov    %rax,(%rsp)
 65f:	48 8b f9             	mov    %rcx,%rdi
 662:	e8 00 00 00 00       	call   667 <tested+0x37>
			663: R_X86_64_PLT32	.text+0xdc
 667:	8b c8                	mov    %eax,%ecx
 669:	48 8b 04 24          	mov    (%rsp),%rax
 66d:	44 8d 24 08          	lea    (%rax,%rcx,1),%r12d
 671:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 676:	8d 04 2f             	lea    (%rdi,%rbp,1),%eax
 679:	48 8b f8             	mov    %rax,%rdi
 67c:	e8 00 00 00 00       	call   681 <tested+0x51>
			67d: R_X86_64_PLT32	.text+0x15c
 681:	44 03 e0             	add    %eax,%r12d
 684:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 689:	8b c7                	mov    %edi,%eax
 68b:	2b c5                	sub    %ebp,%eax
 68d:	48 8b f8             	mov    %rax,%rdi
 690:	e8 00 00 00 00       	call   695 <tested+0x65>
			691: R_X86_64_PLT32	.text+0x1cc
 695:	44 03 e0             	add    %eax,%r12d
 698:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 69d:	8d 04 2f             	lea    (%rdi,%rbp,1),%eax
 6a0:	48 8b f8             	mov    %rax,%rdi
 6a3:	e8 00 00 00 00       	call   6a8 <tested+0x78>
			6a4: R_X86_64_PLT32	.text+0x25c
 6a8:	44 03 e0             	add    %eax,%r12d
 6ab:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 6b0:	8b c7                	mov    %edi,%eax
 6b2:	2b c5                	sub    %ebp,%eax
 6b4:	48 8b f8             	mov    %rax,%rdi
 6b7:	e8 00 00 00 00       	call   6bc <tested+0x8c>
			6b8: R_X86_64_PLT32	.text+0x28c
 6bc:	44 03 e0             	add    %eax,%r12d
 6bf:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 6c4:	8d 04 2f             	lea    (%rdi,%rbp,1),%eax
 6c7:	48 8b f8             	mov    %rax,%rdi
 6ca:	e8 00 00 00 00       	call   6cf <tested+0x9f>
			6cb: R_X86_64_PLT32	.text+0x2cc
 6cf:	44 03 e0             	add    %eax,%r12d
 6d2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 6d7:	8d 04 2f             	lea    (%rdi,%rbp,1),%eax
 6da:	48 8b f8             	mov    %rax,%rdi
 6dd:	e8 00 00 00 00       	call   6e2 <tested+0xb2>
			6de: R_X86_64_PLT32	.text+0x33c
 6e2:	44 03 e0             	add    %eax,%r12d
 6e5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 6ea:	8b c7                	mov    %edi,%eax
 6ec:	2b c5                	sub    %ebp,%eax
 6ee:	48 8b f8             	mov    %rax,%rdi
 6f1:	e8 00 00 00 00       	call   6f6 <tested+0xc6>
			6f2: R_X86_64_PLT32	.text+0x3fc
 6f6:	44 03 e0             	add    %eax,%r12d
 6f9:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 6fe:	8b c7                	mov    %edi,%eax
 700:	2b c5                	sub    %ebp,%eax
 702:	48 8b f8             	mov    %rax,%rdi
 705:	e8 00 00 00 00       	call   70a <tested+0xda>
			706: R_X86_64_PLT32	.text+0x46c
 70a:	44 03 e0             	add    %eax,%r12d
 70d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 712:	8b c7                	mov    %edi,%eax
 714:	2b c5                	sub    %ebp,%eax
 716:	48 8b f8             	mov    %rax,%rdi
 719:	e8 00 00 00 00       	call   71e <tested+0xee>
			71a: R_X86_64_PLT32	.text+0x55c
 71e:	44 03 e0             	add    %eax,%r12d
 721:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 726:	8d 04 2f             	lea    (%rdi,%rbp,1),%eax
 729:	48 8b f8             	mov    %rax,%rdi
 72c:	e8 00 00 00 00       	call   731 <tested+0x101>
			72d: R_X86_64_PLT32	.text+0x61c
 731:	41 03 c4             	add    %r12d,%eax
 734:	03 d8                	add    %eax,%ebx
 736:	83 c5 01             	add    $0x1,%ebp
 739:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 73e:	83 fd 05             	cmp    $0x5,%ebp
 741:	0f 8c fb fe ff ff    	jl     642 <tested+0x12>
 747:	8b c3                	mov    %ebx,%eax
 749:	48 83 c4 10          	add    $0x10,%rsp
 74d:	41 5c                	pop    %r12
 74f:	5d                   	pop    %rbp
 750:	5b                   	pop    %rbx
 751:	c3                   	ret
