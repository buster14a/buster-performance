
/home/david/buster-fast-bench/pr-numbers-codex-6b0809fc/followup-9700x/3658/base3597-kernel.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <put_v4>:
   0:	8b c2                	mov    %edx,%eax
   2:	03 06                	add    (%rsi),%eax
   4:	89 44 24 e8          	mov    %eax,-0x18(%rsp)
   8:	8b c2                	mov    %edx,%eax
   a:	03 46 04             	add    0x4(%rsi),%eax
   d:	83 c0 01             	add    $0x1,%eax
  10:	89 44 24 ec          	mov    %eax,-0x14(%rsp)
  14:	8b c2                	mov    %edx,%eax
  16:	03 46 08             	add    0x8(%rsi),%eax
  19:	83 c0 02             	add    $0x2,%eax
  1c:	89 44 24 f0          	mov    %eax,-0x10(%rsp)
  20:	03 56 0c             	add    0xc(%rsi),%edx
  23:	8d 42 03             	lea    0x3(%rdx),%eax
  26:	89 44 24 f4          	mov    %eax,-0xc(%rsp)
  2a:	62 f1 7e 08 6f 84 24 	vmovdqu32 -0x18(%rsp),%xmm0
  31:	e8 ff ff ff 
  35:	62 f1 7e 08 7f 07    	vmovdqu32 %xmm0,(%rdi)
  3b:	c3                   	ret
  3c:	cc                   	int3
  3d:	cc                   	int3
  3e:	cc                   	int3
  3f:	cc                   	int3

0000000000000040 <put_v8>:
  40:	55                   	push   %rbp
  41:	48 89 e5             	mov    %rsp,%rbp
  44:	48 83 ec 20          	sub    $0x20,%rsp
  48:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
  4c:	8b c2                	mov    %edx,%eax
  4e:	03 06                	add    (%rsi),%eax
  50:	89 04 24             	mov    %eax,(%rsp)
  53:	8b c2                	mov    %edx,%eax
  55:	03 46 04             	add    0x4(%rsi),%eax
  58:	83 c0 01             	add    $0x1,%eax
  5b:	89 44 24 04          	mov    %eax,0x4(%rsp)
  5f:	8b c2                	mov    %edx,%eax
  61:	03 46 08             	add    0x8(%rsi),%eax
  64:	83 c0 02             	add    $0x2,%eax
  67:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6b:	8b c2                	mov    %edx,%eax
  6d:	03 46 0c             	add    0xc(%rsi),%eax
  70:	83 c0 03             	add    $0x3,%eax
  73:	89 44 24 0c          	mov    %eax,0xc(%rsp)
  77:	8b c2                	mov    %edx,%eax
  79:	03 46 10             	add    0x10(%rsi),%eax
  7c:	83 c0 04             	add    $0x4,%eax
  7f:	89 44 24 10          	mov    %eax,0x10(%rsp)
  83:	8b c2                	mov    %edx,%eax
  85:	03 46 14             	add    0x14(%rsi),%eax
  88:	83 c0 05             	add    $0x5,%eax
  8b:	89 44 24 14          	mov    %eax,0x14(%rsp)
  8f:	8b c2                	mov    %edx,%eax
  91:	03 46 18             	add    0x18(%rsi),%eax
  94:	83 c0 06             	add    $0x6,%eax
  97:	89 44 24 18          	mov    %eax,0x18(%rsp)
  9b:	03 56 1c             	add    0x1c(%rsi),%edx
  9e:	8d 42 07             	lea    0x7(%rdx),%eax
  a1:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  a5:	62 f1 7e 28 6f 04 24 	vmovdqu32 (%rsp),%ymm0
  ac:	62 f1 7e 28 7f 07    	vmovdqu32 %ymm0,(%rdi)
  b2:	c5 f8 77             	vzeroupper
  b5:	48 89 ec             	mov    %rbp,%rsp
  b8:	5d                   	pop    %rbp
  b9:	c3                   	ret
  ba:	cc                   	int3
  bb:	cc                   	int3
  bc:	cc                   	int3
  bd:	cc                   	int3
  be:	cc                   	int3
  bf:	cc                   	int3

00000000000000c0 <put_v16>:
  c0:	55                   	push   %rbp
  c1:	48 89 e5             	mov    %rsp,%rbp
  c4:	48 83 ec 40          	sub    $0x40,%rsp
  c8:	48 83 e4 c0          	and    $0xffffffffffffffc0,%rsp
  cc:	8b c2                	mov    %edx,%eax
  ce:	03 06                	add    (%rsi),%eax
  d0:	89 04 24             	mov    %eax,(%rsp)
  d3:	8b c2                	mov    %edx,%eax
  d5:	03 46 04             	add    0x4(%rsi),%eax
  d8:	83 c0 01             	add    $0x1,%eax
  db:	89 44 24 04          	mov    %eax,0x4(%rsp)
  df:	8b c2                	mov    %edx,%eax
  e1:	03 46 08             	add    0x8(%rsi),%eax
  e4:	83 c0 02             	add    $0x2,%eax
  e7:	89 44 24 08          	mov    %eax,0x8(%rsp)
  eb:	8b c2                	mov    %edx,%eax
  ed:	03 46 0c             	add    0xc(%rsi),%eax
  f0:	83 c0 03             	add    $0x3,%eax
  f3:	89 44 24 0c          	mov    %eax,0xc(%rsp)
  f7:	8b c2                	mov    %edx,%eax
  f9:	03 46 10             	add    0x10(%rsi),%eax
  fc:	83 c0 04             	add    $0x4,%eax
  ff:	89 44 24 10          	mov    %eax,0x10(%rsp)
 103:	8b c2                	mov    %edx,%eax
 105:	03 46 14             	add    0x14(%rsi),%eax
 108:	83 c0 05             	add    $0x5,%eax
 10b:	89 44 24 14          	mov    %eax,0x14(%rsp)
 10f:	8b c2                	mov    %edx,%eax
 111:	03 46 18             	add    0x18(%rsi),%eax
 114:	83 c0 06             	add    $0x6,%eax
 117:	89 44 24 18          	mov    %eax,0x18(%rsp)
 11b:	8b c2                	mov    %edx,%eax
 11d:	03 46 1c             	add    0x1c(%rsi),%eax
 120:	83 c0 07             	add    $0x7,%eax
 123:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
 127:	8b c2                	mov    %edx,%eax
 129:	03 46 20             	add    0x20(%rsi),%eax
 12c:	83 c0 08             	add    $0x8,%eax
 12f:	89 44 24 20          	mov    %eax,0x20(%rsp)
 133:	8b c2                	mov    %edx,%eax
 135:	03 46 24             	add    0x24(%rsi),%eax
 138:	83 c0 09             	add    $0x9,%eax
 13b:	89 44 24 24          	mov    %eax,0x24(%rsp)
 13f:	8b c2                	mov    %edx,%eax
 141:	03 46 28             	add    0x28(%rsi),%eax
 144:	83 c0 0a             	add    $0xa,%eax
 147:	89 44 24 28          	mov    %eax,0x28(%rsp)
 14b:	8b c2                	mov    %edx,%eax
 14d:	03 46 2c             	add    0x2c(%rsi),%eax
 150:	83 c0 0b             	add    $0xb,%eax
 153:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
 157:	8b c2                	mov    %edx,%eax
 159:	03 46 30             	add    0x30(%rsi),%eax
 15c:	83 c0 0c             	add    $0xc,%eax
 15f:	89 44 24 30          	mov    %eax,0x30(%rsp)
 163:	8b c2                	mov    %edx,%eax
 165:	03 46 34             	add    0x34(%rsi),%eax
 168:	83 c0 0d             	add    $0xd,%eax
 16b:	89 44 24 34          	mov    %eax,0x34(%rsp)
 16f:	8b c2                	mov    %edx,%eax
 171:	03 46 38             	add    0x38(%rsi),%eax
 174:	83 c0 0e             	add    $0xe,%eax
 177:	89 44 24 38          	mov    %eax,0x38(%rsp)
 17b:	03 56 3c             	add    0x3c(%rsi),%edx
 17e:	8d 42 0f             	lea    0xf(%rdx),%eax
 181:	89 44 24 3c          	mov    %eax,0x3c(%rsp)
 185:	62 f1 7e 48 6f 04 24 	vmovdqu32 (%rsp),%zmm0
 18c:	62 f1 7e 48 7f 07    	vmovdqu32 %zmm0,(%rdi)
 192:	c5 f8 77             	vzeroupper
 195:	48 89 ec             	mov    %rbp,%rsp
 198:	5d                   	pop    %rbp
 199:	c3                   	ret
