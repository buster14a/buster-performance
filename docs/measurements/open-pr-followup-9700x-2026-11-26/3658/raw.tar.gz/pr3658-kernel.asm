
/home/david/buster-fast-bench/pr-numbers-codex-6b0809fc/followup-9700x/3658/pr3658-kernel.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <put_v4>:
   0:	8b c2                	mov    %edx,%eax
   2:	03 06                	add    (%rsi),%eax
   4:	8b ca                	mov    %edx,%ecx
   6:	03 4e 04             	add    0x4(%rsi),%ecx
   9:	83 c1 01             	add    $0x1,%ecx
   c:	44 8b c2             	mov    %edx,%r8d
   f:	44 03 46 08          	add    0x8(%rsi),%r8d
  13:	41 83 c0 02          	add    $0x2,%r8d
  17:	03 56 0c             	add    0xc(%rsi),%edx
  1a:	83 c2 03             	add    $0x3,%edx
  1d:	62 f2 7d 08 7c c0    	vpbroadcastd %eax,%xmm0
  23:	62 f3 7d 08 22 c1 01 	{evex} vpinsrd $0x1,%ecx,%xmm0,%xmm0
  2a:	62 d3 7d 08 22 c0 02 	{evex} vpinsrd $0x2,%r8d,%xmm0,%xmm0
  31:	62 f3 7d 08 22 c2 03 	{evex} vpinsrd $0x3,%edx,%xmm0,%xmm0
  38:	62 f1 7e 08 7f 07    	vmovdqu32 %xmm0,(%rdi)
  3e:	c3                   	ret
  3f:	cc                   	int3

0000000000000040 <put_v8>:
  40:	8b c2                	mov    %edx,%eax
  42:	03 06                	add    (%rsi),%eax
  44:	8b ca                	mov    %edx,%ecx
  46:	03 4e 04             	add    0x4(%rsi),%ecx
  49:	83 c1 01             	add    $0x1,%ecx
  4c:	44 8b c2             	mov    %edx,%r8d
  4f:	44 03 46 08          	add    0x8(%rsi),%r8d
  53:	41 83 c0 02          	add    $0x2,%r8d
  57:	44 8b ca             	mov    %edx,%r9d
  5a:	44 03 4e 0c          	add    0xc(%rsi),%r9d
  5e:	41 83 c1 03          	add    $0x3,%r9d
  62:	44 8b d2             	mov    %edx,%r10d
  65:	44 03 56 10          	add    0x10(%rsi),%r10d
  69:	41 83 c2 04          	add    $0x4,%r10d
  6d:	48 89 7c 24 f0       	mov    %rdi,-0x10(%rsp)
  72:	8b fa                	mov    %edx,%edi
  74:	03 7e 14             	add    0x14(%rsi),%edi
  77:	83 c7 05             	add    $0x5,%edi
  7a:	89 7c 24 f8          	mov    %edi,-0x8(%rsp)
  7e:	8b fa                	mov    %edx,%edi
  80:	03 7e 18             	add    0x18(%rsi),%edi
  83:	83 c7 06             	add    $0x6,%edi
  86:	03 56 1c             	add    0x1c(%rsi),%edx
  89:	83 c2 07             	add    $0x7,%edx
  8c:	62 f2 7d 08 7c c0    	vpbroadcastd %eax,%xmm0
  92:	62 f3 7d 08 22 c1 01 	{evex} vpinsrd $0x1,%ecx,%xmm0,%xmm0
  99:	62 d3 7d 08 22 c0 02 	{evex} vpinsrd $0x2,%r8d,%xmm0,%xmm0
  a0:	62 d3 7d 08 22 c1 03 	{evex} vpinsrd $0x3,%r9d,%xmm0,%xmm0
  a7:	62 d2 7d 08 7c ca    	vpbroadcastd %r10d,%xmm1
  ad:	8b 44 24 f8          	mov    -0x8(%rsp),%eax
  b1:	62 f3 75 08 22 c8 01 	{evex} vpinsrd $0x1,%eax,%xmm1,%xmm1
  b8:	62 f3 75 08 22 cf 02 	{evex} vpinsrd $0x2,%edi,%xmm1,%xmm1
  bf:	62 f3 75 08 22 ca 03 	{evex} vpinsrd $0x3,%edx,%xmm1,%xmm1
  c6:	62 f1 fd 08 6f c0    	vmovdqa64 %xmm0,%xmm0
  cc:	62 f3 7d 28 38 c1 01 	vinserti32x4 $0x1,%xmm1,%ymm0,%ymm0
  d3:	48 8b 7c 24 f0       	mov    -0x10(%rsp),%rdi
  d8:	62 f1 7e 28 7f 07    	vmovdqu32 %ymm0,(%rdi)
  de:	c5 f8 77             	vzeroupper
  e1:	c3                   	ret
  e2:	cc                   	int3
  e3:	cc                   	int3
  e4:	cc                   	int3
  e5:	cc                   	int3
  e6:	cc                   	int3
  e7:	cc                   	int3
  e8:	cc                   	int3
  e9:	cc                   	int3
  ea:	cc                   	int3
  eb:	cc                   	int3
  ec:	cc                   	int3
  ed:	cc                   	int3
  ee:	cc                   	int3
  ef:	cc                   	int3

00000000000000f0 <put_v16>:
  f0:	8b c2                	mov    %edx,%eax
  f2:	03 06                	add    (%rsi),%eax
  f4:	8b ca                	mov    %edx,%ecx
  f6:	03 4e 04             	add    0x4(%rsi),%ecx
  f9:	83 c1 01             	add    $0x1,%ecx
  fc:	44 8b c2             	mov    %edx,%r8d
  ff:	44 03 46 08          	add    0x8(%rsi),%r8d
 103:	41 83 c0 02          	add    $0x2,%r8d
 107:	44 8b ca             	mov    %edx,%r9d
 10a:	44 03 4e 0c          	add    0xc(%rsi),%r9d
 10e:	41 83 c1 03          	add    $0x3,%r9d
 112:	44 8b d2             	mov    %edx,%r10d
 115:	44 03 56 10          	add    0x10(%rsi),%r10d
 119:	41 83 c2 04          	add    $0x4,%r10d
 11d:	48 89 7c 24 d0       	mov    %rdi,-0x30(%rsp)
 122:	8b fa                	mov    %edx,%edi
 124:	03 7e 14             	add    0x14(%rsi),%edi
 127:	83 c7 05             	add    $0x5,%edi
 12a:	89 7c 24 d8          	mov    %edi,-0x28(%rsp)
 12e:	8b fa                	mov    %edx,%edi
 130:	03 7e 18             	add    0x18(%rsi),%edi
 133:	83 c7 06             	add    $0x6,%edi
 136:	89 7c 24 dc          	mov    %edi,-0x24(%rsp)
 13a:	8b fa                	mov    %edx,%edi
 13c:	03 7e 1c             	add    0x1c(%rsi),%edi
 13f:	83 c7 07             	add    $0x7,%edi
 142:	89 7c 24 e0          	mov    %edi,-0x20(%rsp)
 146:	8b fa                	mov    %edx,%edi
 148:	03 7e 20             	add    0x20(%rsi),%edi
 14b:	83 c7 08             	add    $0x8,%edi
 14e:	89 7c 24 e4          	mov    %edi,-0x1c(%rsp)
 152:	8b fa                	mov    %edx,%edi
 154:	03 7e 24             	add    0x24(%rsi),%edi
 157:	83 c7 09             	add    $0x9,%edi
 15a:	89 7c 24 e8          	mov    %edi,-0x18(%rsp)
 15e:	8b fa                	mov    %edx,%edi
 160:	03 7e 28             	add    0x28(%rsi),%edi
 163:	83 c7 0a             	add    $0xa,%edi
 166:	89 7c 24 ec          	mov    %edi,-0x14(%rsp)
 16a:	8b fa                	mov    %edx,%edi
 16c:	03 7e 2c             	add    0x2c(%rsi),%edi
 16f:	83 c7 0b             	add    $0xb,%edi
 172:	89 7c 24 f0          	mov    %edi,-0x10(%rsp)
 176:	8b fa                	mov    %edx,%edi
 178:	03 7e 30             	add    0x30(%rsi),%edi
 17b:	83 c7 0c             	add    $0xc,%edi
 17e:	89 7c 24 f4          	mov    %edi,-0xc(%rsp)
 182:	8b fa                	mov    %edx,%edi
 184:	03 7e 34             	add    0x34(%rsi),%edi
 187:	83 c7 0d             	add    $0xd,%edi
 18a:	89 7c 24 f8          	mov    %edi,-0x8(%rsp)
 18e:	8b fa                	mov    %edx,%edi
 190:	03 7e 38             	add    0x38(%rsi),%edi
 193:	83 c7 0e             	add    $0xe,%edi
 196:	03 56 3c             	add    0x3c(%rsi),%edx
 199:	83 c2 0f             	add    $0xf,%edx
 19c:	62 f2 7d 08 7c c0    	vpbroadcastd %eax,%xmm0
 1a2:	62 f3 7d 08 22 c1 01 	{evex} vpinsrd $0x1,%ecx,%xmm0,%xmm0
 1a9:	62 d3 7d 08 22 c0 02 	{evex} vpinsrd $0x2,%r8d,%xmm0,%xmm0
 1b0:	62 d3 7d 08 22 c1 03 	{evex} vpinsrd $0x3,%r9d,%xmm0,%xmm0
 1b7:	62 d2 7d 08 7c ca    	vpbroadcastd %r10d,%xmm1
 1bd:	8b 44 24 d8          	mov    -0x28(%rsp),%eax
 1c1:	62 f3 75 08 22 c8 01 	{evex} vpinsrd $0x1,%eax,%xmm1,%xmm1
 1c8:	8b 44 24 dc          	mov    -0x24(%rsp),%eax
 1cc:	62 f3 75 08 22 c8 02 	{evex} vpinsrd $0x2,%eax,%xmm1,%xmm1
 1d3:	8b 44 24 e0          	mov    -0x20(%rsp),%eax
 1d7:	62 f3 75 08 22 c8 03 	{evex} vpinsrd $0x3,%eax,%xmm1,%xmm1
 1de:	8b 44 24 e4          	mov    -0x1c(%rsp),%eax
 1e2:	62 f2 7d 08 7c d0    	vpbroadcastd %eax,%xmm2
 1e8:	8b 44 24 e8          	mov    -0x18(%rsp),%eax
 1ec:	62 f3 6d 08 22 d0 01 	{evex} vpinsrd $0x1,%eax,%xmm2,%xmm2
 1f3:	8b 44 24 ec          	mov    -0x14(%rsp),%eax
 1f7:	62 f3 6d 08 22 d0 02 	{evex} vpinsrd $0x2,%eax,%xmm2,%xmm2
 1fe:	8b 44 24 f0          	mov    -0x10(%rsp),%eax
 202:	62 f3 6d 08 22 d0 03 	{evex} vpinsrd $0x3,%eax,%xmm2,%xmm2
 209:	8b 44 24 f4          	mov    -0xc(%rsp),%eax
 20d:	62 f2 7d 08 7c d8    	vpbroadcastd %eax,%xmm3
 213:	8b 44 24 f8          	mov    -0x8(%rsp),%eax
 217:	62 f3 65 08 22 d8 01 	{evex} vpinsrd $0x1,%eax,%xmm3,%xmm3
 21e:	62 f3 65 08 22 df 02 	{evex} vpinsrd $0x2,%edi,%xmm3,%xmm3
 225:	62 f3 65 08 22 da 03 	{evex} vpinsrd $0x3,%edx,%xmm3,%xmm3
 22c:	62 f1 fd 08 6f c0    	vmovdqa64 %xmm0,%xmm0
 232:	62 f3 7d 28 38 c1 01 	vinserti32x4 $0x1,%xmm1,%ymm0,%ymm0
 239:	62 f1 fd 08 6f d2    	vmovdqa64 %xmm2,%xmm2
 23f:	62 f3 6d 28 38 d3 01 	vinserti32x4 $0x1,%xmm3,%ymm2,%ymm2
 246:	62 f1 fd 28 6f c0    	vmovdqa64 %ymm0,%ymm0
 24c:	62 f3 fd 48 3a c2 01 	vinserti64x4 $0x1,%ymm2,%zmm0,%zmm0
 253:	48 8b 7c 24 d0       	mov    -0x30(%rsp),%rdi
 258:	62 f1 7e 48 7f 07    	vmovdqu32 %zmm0,(%rdi)
 25e:	c5 f8 77             	vzeroupper
 261:	c3                   	ret
