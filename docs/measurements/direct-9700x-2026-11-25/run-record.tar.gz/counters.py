"""Measure retired user-mode events on fresh direct compiler processes."""
import csv
import hashlib
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from measure import sources, sqlite_flags


def main():
    root = Path(__file__).resolve().parent
    name = sys.argv[1]
    corpus = Path(sys.argv[2]).resolve()
    os.sched_setaffinity(0, {2})
    events = ["cycles:u", "instructions:u", "branches:u", "branch-misses:u"]
    flags = sqlite_flags(corpus) if name == "sqlite" else []
    if name == "iconv-tables":
        flags = ["-I" + str(corpus / "libc/musl/src/locale")]
    env = dict(os.environ, LC_ALL="C")
    with tempfile.TemporaryDirectory() as directory, tempfile.TemporaryDirectory(dir="/dev/shm") as shm:
        source = sources(Path(directory), corpus)[name]
        obj = Path(shm) / "out.o"
        stat = Path(shm) / "stat"
        expected = None
        with (root / "evidence" / (name + "-counters.csv")).open("x", newline="") as output:
            writer = csv.writer(output)
            writer.writerow(["workload", "round", "variant", *events, "object_bytes", "object_sha256"])
            for run in range(13):
                order = ["before", "after"] if run % 2 == 0 else ["after", "before"]
                for variant in order:
                    cmd = ["perf", "stat", "-x", ";", "-o", stat, "-e", ",".join(events),
                           "--", root / ("compiler-" + variant), "-c", *flags, source, "-o", obj]
                    subprocess.run(cmd, env=env, check=True)
                    counts = {}
                    for line in stat.read_text().splitlines():
                        fields = line.split(";")
                        if len(fields) >= 5 and fields[2] in events:
                            if float(fields[4]) < 99:
                                raise ValueError("hardware counters multiplexed: " + line)
                            counts[fields[2]] = int(fields[0])
                    data = obj.read_bytes()
                    digest = hashlib.sha256(data).hexdigest()
                    if b"buster direct" not in data or (expected is not None and expected != digest):
                        raise ValueError(name + " did not emit identical direct objects")
                    expected = digest
                    if run >= 2:
                        writer.writerow([name, run - 1, variant, *(counts[e] for e in events), len(data), digest])


if __name__ == "__main__":
    main()
