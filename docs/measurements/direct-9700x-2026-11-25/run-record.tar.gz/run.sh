#!/usr/bin/env bash
set -euo pipefail
run_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$run_dir"
mkdir -p evidence
exec >evidence/progress.log 2>&1
trap 'status=$?; echo "$status" > "$run_dir/evidence/exit-status"' EXIT
export EXCLUSIVE_OWNER=codex-direct-local
export EXCLUSIVE_LINK=https://github.com/buster14a/buster/commit/56490ed95ac23b1634b0252d8ee1405e54947418
export BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0
corpus=/var/lib/buster-9700x/corpora/preprocessor-391e729af658
run() {
  local name=$1 deadline=$2
  shift 2
  echo "$(date -u +%FT%TZ) $name"
  EXCLUSIVE_TITLE="Direct compiler throughput, $name" "$HOME/buster-fast-bench/exclusive.sh" timeout -k 5 "$deadline" bash "$run_dir/held.sh" "$@" >"$run_dir/evidence/$name.log" 2>&1
}
test -f "$corpus/sqlite/sqlite3.c"
run prepare 180 bash -c 'git init -q src && cd src && git fetch -q --depth=1 https://github.com/buster14a/buster.git 56490ed95ac23b1634b0252d8ee1405e54947418 && git checkout -q --detach FETCH_HEAD && git rev-parse HEAD'
cd src
run build-before 555 ./build.sh --config Release --jobs 14
cp -L build/compiler "$run_dir/compiler-before"
run test-before 60 "$run_dir/compiler-before" test-direct
git apply --check "$run_dir/candidate.patch"
git apply "$run_dir/candidate.patch"
run build-after 555 ./build.sh --config Release --jobs 14
cp -L build/compiler "$run_dir/compiler-after"
run test-after 60 "$run_dir/compiler-after" test-direct
cd "$run_dir"
{
    uname -snr
    lscpu | grep -E 'Model name|CPU\(s\)|Thread\(s\)'
    cat /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
    cat /sys/devices/system/cpu/cpu2/topology/thread_siblings_list
    cat /sys/kernel/mm/transparent_hugepage/enabled
    git -C src rev-parse HEAD
    git -C src diff --binary HEAD | sha256sum
    sha256sum compiler-before compiler-after candidate.patch "$corpus/sqlite/sqlite3.c"
    grep -E '^CMAKE_C_COMPILER(:|_)|^BUSTER_HOST_ARCH:' src/build/cmake/znver5/CMakeCache.txt || true
} >evidence/host.txt
for unit in sqlite iconv-tables switch table inline tiny; do
    run "time-$unit" 120 python3 measure.py compiler-before compiler-after "$corpus" "evidence/$unit.csv" --only "$unit" --cpu 2
done
echo "$(date -u +%FT%TZ) done"
