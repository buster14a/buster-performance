"""Replay the local fresh-process direct compiler benchmark on Linux."""
import argparse
import csv
import os
import statistics
import subprocess
import tempfile
import time
from pathlib import Path


def sources(directory, corpus):
    inputs = {"sqlite": corpus / "sqlite/sqlite3.c"}
    cases = "\n".join(f"case {i}: return {(i * 131 + 33) % 3367};" for i in range(4000))
    rows = [",".join(str((row * 311 + i * 17) % 16000) for i in range(32)) for row in range(3500)]
    functions = ["static inline int f0(void){return 1;}"]
    functions.extend(f"static inline int f{i}(void){{return f{i-1}();}}" for i in range(1, 3500))
    units = {
        "switch": "int lookup(int n){ switch(n) {\n" + cases + "\ndefault: return -1; }}\n",
        "table": "const unsigned short transitions[] = {\n" + ",\n".join(rows) + "\n};\n",
        "inline": "\n".join(functions) + "\nint main(void){return f3499()-1;}\n",
        "tiny": "int sum(int x, int y) { return x + y; }\n",
    }
    for name, source in units.items():
        inputs[name] = directory / (name + ".c")
        inputs[name].write_text(source)
    # Compile the actual musl declarations and their seven headers in isolation.
    iconv = (corpus / "libc/musl/src/locale/iconv.c").read_text()
    start = iconv.index("static const unsigned short legacy_chars")
    end = iconv.index("static int fuzzycmp", start)
    inputs["iconv-tables"] = directory / "iconv-tables.c"
    inputs["iconv-tables"].write_text(iconv[start:end] +
        "const void *const tables[] = {legacy_chars, jis0208, gb18030, big5, hkscs, ksc, rev_jis};\n")
    return inputs


def sqlite_flags(corpus):
    flags = ["--lanes", "1", "--predefines", corpus / "provenance/gnu17-pinned-predefines.txt",
             "--target=x86_64-linux-gnu", "-march=znver5", "-std=gnu17", "-nostdinc"]
    for include in ["usr/lib/clang/23/include", "usr/local/include", "usr/include"]:
        flags.extend(["-isystem", corpus / "headers" / include])
    return flags + ["-DSQLITE_OMIT_LOAD_EXTENSION", "-DSQLITE_THREADSAFE=0", "-DSQLITE_ENABLE_MEMSYS5",
                    "-DSQLITE_ENABLE_RTREE", "-I" + str(corpus / "sqlite")]


def benchmark(args):
    os.sched_setaffinity(0, {args.cpu})
    binaries = [args.before.resolve(), args.after.resolve()]
    corpus = args.corpus.resolve()
    with tempfile.TemporaryDirectory() as source_dir, tempfile.TemporaryDirectory(dir="/dev/shm") as object_dir:
        inputs = sources(Path(source_dir), corpus)
        output = Path(object_dir) / "out.o"
        for block in range(2):
            for name, path in inputs.items():
                if args.only and name != args.only:
                    continue
                flags = sqlite_flags(corpus) if name == "sqlite" else []
                if name == "iconv-tables":
                    flags = ["-I" + str(corpus / "libc/musl/src/locale")]
                expected = None
                for run in range(45):
                    pair = [0.0, 0.0]
                    first = (run + block) % 2
                    for variant in [first, 1 - first]:
                        command = [binaries[variant], "-c", *flags, path, "-o", output]
                        start = time.monotonic_ns()
                        subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        pair[variant] = (time.monotonic_ns() - start) / 1e6
                        if run == 0:
                            obj = output.read_bytes()
                            if b"buster direct" not in obj or (expected is not None and obj != expected):
                                raise ValueError(f"{name} produced a different object or used fallback")
                            expected = obj
                    if run >= 4:
                        yield name, block + 1, run - 3, *pair


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for field in ["before", "after", "corpus", "csv"]:
        parser.add_argument(field, type=Path)
    parser.add_argument("--cpu", type=int, default=2)
    parser.add_argument("--only", help="measure just this workload")
    args = parser.parse_args()
    with args.csv.open("x", newline="") as output:
        writer = csv.writer(output)
        writer.writerow(["workload", "block", "round", "before_ms", "after_ms"])
        rows = list(benchmark(args))
        writer.writerows(rows)
    for name in dict.fromkeys(row[0] for row in rows):
        before, after = [statistics.median(row[i] for row in rows if row[0] == name) for i in [3, 4]]
        print(f"{name:7} {before:8.3f} ms -> {after:8.3f} ms   {before / after:.2f}x")


if __name__ == "__main__":
    main()
