#!/usr/bin/env bash
set -euo pipefail
snapshot() {
    date -u +%FT%TZ
    cat /proc/loadavg
    ps -eo psr,pcpu,pid,etimes,user,comm --sort=-pcpu | head -11 || true
}
snapshot
trap snapshot EXIT
"$@"
