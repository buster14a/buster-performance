#!/usr/bin/env bash
set -euo pipefail
run_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$run_dir"
exec >evidence/perf-progress.log 2>&1
trap 'echo "$?" > "$run_dir/evidence/perf-exit-status"' EXIT
export EXCLUSIVE_OWNER=codex-direct-local
export EXCLUSIVE_LINK=https://github.com/buster14a/buster/commit/56490ed95ac23b1634b0252d8ee1405e54947418
corpus=/var/lib/buster-9700x/corpora/preprocessor-391e729af658
for unit in sqlite iconv-tables switch table inline tiny; do
    echo "$(date -u +%FT%TZ) $unit"
    EXCLUSIVE_TITLE="Direct compiler counters, $unit" "$HOME/buster-fast-bench/exclusive.sh" timeout -k 5 120 bash "$run_dir/held.sh" python3 "$run_dir/counters.py" "$unit" "$corpus" >"evidence/perf-$unit.log" 2>&1
done
