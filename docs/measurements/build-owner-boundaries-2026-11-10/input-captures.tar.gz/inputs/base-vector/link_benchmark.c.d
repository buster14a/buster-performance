link_benchmark.c: src/buster/compiler/link_benchmark.c \
  src/buster/compiler/test_paths.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/stdbool.h \
  /usr/include/stdlib.h \
  /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
  /usr/include/features.h /usr/include/features-time64.h \
  /usr/include/x86_64-linux-gnu/bits/wordsize.h \
  /usr/include/x86_64-linux-gnu/bits/timesize.h \
  /usr/include/stdc-predef.h /usr/include/x86_64-linux-gnu/sys/cdefs.h \
  /usr/include/x86_64-linux-gnu/bits/long-double.h \
  /usr/include/x86_64-linux-gnu/gnu/stubs.h \
  /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/stddef.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/__stddef_size_t.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/__stddef_wchar_t.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/__stddef_null.h \
  /usr/include/x86_64-linux-gnu/bits/waitflags.h \
  /usr/include/x86_64-linux-gnu/bits/waitstatus.h \
  /usr/include/x86_64-linux-gnu/bits/floatn.h \
  /usr/include/x86_64-linux-gnu/bits/floatn-common.h \
  /usr/include/x86_64-linux-gnu/sys/types.h \
  /usr/include/x86_64-linux-gnu/bits/types.h \
  /usr/include/x86_64-linux-gnu/bits/typesizes.h \
  /usr/include/x86_64-linux-gnu/bits/time64.h \
  /usr/include/x86_64-linux-gnu/bits/types/clock_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/clockid_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/time_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/timer_t.h \
  /usr/include/x86_64-linux-gnu/bits/stdint-intn.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/endian.h \
  /usr/include/endian.h /usr/include/x86_64-linux-gnu/bits/endian.h \
  /usr/include/x86_64-linux-gnu/bits/endianness.h \
  /usr/include/x86_64-linux-gnu/bits/byteswap.h \
  /usr/include/x86_64-linux-gnu/bits/uintn-identity.h \
  /usr/include/x86_64-linux-gnu/sys/select.h \
  /usr/include/x86_64-linux-gnu/bits/select.h \
  /usr/include/x86_64-linux-gnu/bits/types/sigset_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/__sigset_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h \
  /usr/include/x86_64-linux-gnu/bits/pthreadtypes.h \
  /usr/include/x86_64-linux-gnu/bits/thread-shared-types.h \
  /usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h \
  /usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h \
  /usr/include/x86_64-linux-gnu/bits/struct_mutex.h \
  /usr/include/x86_64-linux-gnu/bits/struct_rwlock.h \
  /usr/include/alloca.h \
  /usr/include/x86_64-linux-gnu/bits/stdlib-bsearch.h \
  /usr/include/x86_64-linux-gnu/bits/stdlib-float.h \
  /usr/include/string.h \
  /usr/include/x86_64-linux-gnu/bits/types/locale_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/__locale_t.h \
  /usr/include/strings.h src/buster/compiler/host_isa.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/immintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/x86gprintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/hresetintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/uintrintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/usermsrintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/crc32intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/prfchiintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/raointintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/cmpccxaddintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/mmintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/xmmintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/mm_malloc.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/emmintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/pmmintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/tmmintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/smmintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/popcntintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/wmmintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/__wmmintrin_aes.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/__wmmintrin_pclmul.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/clflushoptintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/clwbintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avxintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx2intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/f16cintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/bmiintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/bmi2intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/lzcntintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/fmaintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512fintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vlintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512bwintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512bitalgintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512bmmintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512bmmvlintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512cdintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vpopcntdqintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vpopcntdqvlintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vnniintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vlvnniintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avxvnniintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512dqintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vlbitalgintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vlbwintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vlcdintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vldqintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512ifmaintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512ifmavlintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avxifmaintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vbmiintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vbmivlintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vbmi2intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vlvbmi2intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512fp16intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vlfp16intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512bf16intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vlbf16intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/pkuintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/vpclmulqdqintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/vaesintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/gfniintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avxvnniint8intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avxneconvertintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/sha512intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/sm3intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/sm4intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avxvnniint16intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/rtmintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/xtestintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/shaintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/fxsrintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/xsaveintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/xsaveoptintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/xsavecintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/xsavesintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/cetintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/adcintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/adxintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/rdseedintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/wbnoinvdintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/cldemoteintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/waitpkgintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/movdirintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/movrsintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/movrs_avx10_2intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/movrs_avx10_2_512intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/pconfigintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/sgxintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/ptwriteintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/invpcidintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/keylockerintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/amxintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/amxfp16intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/amxcomplexintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/amxfp8intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/amxmovrsintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/amxavx512intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vp2intersectintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx512vlvp2intersectintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2bf16intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2convertintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2copyintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2minmaxintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2niintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2satcvtdsintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2satcvtintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2_512bf16intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2_512convertintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2_512minmaxintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2_512niintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2_512satcvtdsintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/avx10_2_512satcvtintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/sm4evexintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/enqcmdintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/serializeintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/tsxldtrkintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/stdint.h \
  /usr/include/stdint.h /usr/include/x86_64-linux-gnu/bits/wchar.h \
  /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h \
  /usr/include/x86_64-linux-gnu/bits/stdint-least.h /usr/include/stdio.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/stdarg.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/__stdarg___gnuc_va_list.h \
  /usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/__FILE.h \
  /usr/include/x86_64-linux-gnu/bits/types/FILE.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h \
  /usr/include/x86_64-linux-gnu/bits/types/cookie_io_functions_t.h \
  /usr/include/x86_64-linux-gnu/bits/stdio_lim.h \
  /usr/include/x86_64-linux-gnu/bits/stdio.h /usr/include/time.h \
  /usr/include/x86_64-linux-gnu/bits/time.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_tm.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_itimerspec.h \
  /usr/include/errno.h /usr/include/x86_64-linux-gnu/bits/errno.h \
  /usr/include/linux/errno.h /usr/include/x86_64-linux-gnu/asm/errno.h \
  /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
  /usr/include/fcntl.h /usr/include/x86_64-linux-gnu/bits/fcntl.h \
  /usr/include/x86_64-linux-gnu/bits/fcntl-linux.h \
  /usr/include/x86_64-linux-gnu/bits/cloexec.h \
  /usr/include/x86_64-linux-gnu/bits/stat.h \
  /usr/include/x86_64-linux-gnu/bits/struct_stat.h /usr/include/spawn.h \
  /usr/include/sched.h /usr/include/x86_64-linux-gnu/bits/sched.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_sched_param.h \
  /usr/include/x86_64-linux-gnu/bits/cpu-set.h \
  /usr/include/x86_64-linux-gnu/bits/spawn_ext.h /usr/include/unistd.h \
  /usr/include/x86_64-linux-gnu/bits/posix_opt.h \
  /usr/include/x86_64-linux-gnu/bits/environments.h \
  /usr/include/x86_64-linux-gnu/bits/confname.h \
  /usr/include/x86_64-linux-gnu/bits/getopt_posix.h \
  /usr/include/x86_64-linux-gnu/bits/getopt_core.h \
  /usr/include/x86_64-linux-gnu/bits/unistd_ext.h \
  /usr/include/x86_64-linux-gnu/sys/mman.h \
  /usr/include/x86_64-linux-gnu/bits/mman.h \
  /usr/include/x86_64-linux-gnu/bits/mman-map-flags-generic.h \
  /usr/include/x86_64-linux-gnu/bits/mman-linux.h \
  /usr/include/x86_64-linux-gnu/bits/mman-shared.h \
  /usr/include/x86_64-linux-gnu/bits/mman_ext.h \
  /usr/include/x86_64-linux-gnu/sys/stat.h \
  /usr/include/x86_64-linux-gnu/sys/uio.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h \
  /usr/include/x86_64-linux-gnu/bits/uio_lim.h \
  /usr/include/x86_64-linux-gnu/sys/wait.h /usr/include/signal.h \
  /usr/include/x86_64-linux-gnu/bits/signum-generic.h \
  /usr/include/x86_64-linux-gnu/bits/signum-arch.h \
  /usr/include/x86_64-linux-gnu/bits/types/sig_atomic_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/siginfo_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/__sigval_t.h \
  /usr/include/x86_64-linux-gnu/bits/siginfo-arch.h \
  /usr/include/x86_64-linux-gnu/bits/siginfo-consts.h \
  /usr/include/x86_64-linux-gnu/bits/types/sigval_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/sigevent_t.h \
  /usr/include/x86_64-linux-gnu/bits/sigevent-consts.h \
  /usr/include/x86_64-linux-gnu/bits/sigaction.h \
  /usr/include/x86_64-linux-gnu/bits/sigcontext.h \
  /usr/include/x86_64-linux-gnu/bits/types/stack_t.h \
  /usr/include/x86_64-linux-gnu/sys/ucontext.h \
  /usr/include/x86_64-linux-gnu/bits/sigstack.h \
  /usr/include/x86_64-linux-gnu/bits/sigstksz.h \
  /usr/include/x86_64-linux-gnu/bits/ss_flags.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_sigstack.h \
  /usr/include/x86_64-linux-gnu/bits/sigthread.h \
  /usr/include/x86_64-linux-gnu/bits/signal_ext.h \
  /usr/include/x86_64-linux-gnu/bits/types/idtype_t.h \
  /usr/include/x86_64-linux-gnu/sys/resource.h \
  /usr/include/x86_64-linux-gnu/bits/resource.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_rusage.h \
  /usr/include/x86_64-linux-gnu/sys/syscall.h \
  /usr/include/x86_64-linux-gnu/asm/unistd.h \
  /usr/include/x86_64-linux-gnu/asm/unistd_64.h \
  /usr/include/x86_64-linux-gnu/bits/syscall.h \
  src/buster/compiler/lane.c \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/limits.h \
  /usr/include/limits.h /usr/include/x86_64-linux-gnu/bits/posix1_lim.h \
  /usr/include/x86_64-linux-gnu/bits/local_lim.h \
  /usr/include/linux/limits.h \
  /usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h \
  /usr/include/x86_64-linux-gnu/bits/pthread_stack_min.h \
  /usr/include/x86_64-linux-gnu/bits/posix2_lim.h /usr/include/assert.h \
  /usr/include/pthread.h /usr/include/x86_64-linux-gnu/bits/setjmp.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct___jmp_buf_tag.h \
  /usr/include/x86_64-linux-gnu/sys/prctl.h /usr/include/linux/prctl.h \
  /usr/include/linux/types.h /usr/include/x86_64-linux-gnu/asm/types.h \
  /usr/include/asm-generic/types.h /usr/include/asm-generic/int-ll64.h \
  /usr/include/x86_64-linux-gnu/asm/bitsperlong.h \
  /usr/include/asm-generic/bitsperlong.h \
  /usr/include/linux/posix_types.h /usr/include/linux/stddef.h \
  /usr/include/x86_64-linux-gnu/asm/posix_types.h \
  /usr/include/x86_64-linux-gnu/asm/posix_types_64.h \
  /usr/include/asm-generic/posix_types.h /usr/include/linux/futex.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/x86intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/ia32intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/prfchwintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/ammintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/fma4intrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/xopintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/tbmintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/lwpintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/mwaitxintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/clzerointrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/rdpruintrin.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/cpuid.h \
  src/buster/compiler/x86_64_encoder.c src/buster/compiler/baked.h \
  src/buster/compiler/link.c src/buster/compiler/link_program.c \
  src/buster/compiler/object_writer.c /usr/include/elf.h \
  src/buster/compiler/native_debug.h src/buster/compiler/import.c \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/__stddef_header_macro.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/__stddef_ptrdiff_t.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/__stddef_max_align_t.h \
  /workspace/scratch/6891521e933c/toolchain/llvm/lib/clang/23/include/__stddef_offsetof.h \
  src/buster/compiler/runtime.c /usr/include/dirent.h \
  /usr/include/x86_64-linux-gnu/bits/dirent.h \
  /usr/include/x86_64-linux-gnu/bits/dirent_ext.h \
  src/buster/compiler/runtime_paths.h \
  src/buster/compiler/runtime_library_search.c \
  src/buster/compiler/bind.c src/buster/compiler/executable.c \
  /usr/include/x86_64-linux-gnu/sys/random.h \
  src/buster/compiler/dynamic.c src/buster/compiler/snapshot.c
