#include <immintrin.h>
#include <stdbool.h>
#include <stdint.h>
#define BUSTER_CHECK_LITERAL_TABLE_SPLICED 1u
#define BUSTER_CHECK_LITERAL_TABLE_ROUND 2u

// The integer prefix ends at the first suffix byte. Exponent and splice markers can still occur
// after that prefix. Scan every relevant byte until its category is final, including the last lane.
static uint32_t check_literal_table_long_category(const uint8_t* bytes, uint32_t length, uint32_t width, bool splices, bool trigraphs, bool round)
{
    const bool hex = bytes[0] == '0' && (bytes[1] | 0x20) == 'x';
    const bool binary = bytes[0] == '0' && (bytes[1] | 0x20) == 'b';
    const bool octal = !hex && !binary && bytes[0] == '0';
    const uint32_t prefix = hex || binary ? 2 : octal ? 1 : 0;
    const uint32_t limit = hex ? (width == 32 ? 6 : 13) : binary ? (width == 32 ? 24 : 53) : octal ? (width == 32 ? 8 : 17) : (width == 32 ? 7 : 15);
    uint32_t digits = 0;
    bool counting = round;
    bool integer = round;
    bool spliced = false;
    for (uint64_t first = 0; first < length && !spliced && (splices || integer); first += 64)
    {
        const uint32_t left = length - (uint32_t)first;
        const __mmask64 live = left >= 64 ? UINT64_MAX : _bzhi_u64(UINT64_MAX, left);
        const __m512i text = _mm512_maskz_loadu_epi8(live, bytes + first);
        const __m512i lower = _mm512_or_si512(text, _mm512_set1_epi8(0x20));
        if (splices)
        {
            spliced = _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('\\')) != 0 ||
                      (trigraphs && _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('?')) != 0);
        }
        if (integer)
        {
            integer = (_mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('.')) |
                       _mm512_cmpeq_epi8_mask(lower, _mm512_set1_epi8(hex ? 'p' : 'e'))) == 0;
        }
        if (integer && !spliced && counting)
        {
            const uint64_t decimal = _mm512_cmple_epu8_mask(_mm512_sub_epi8(text, _mm512_set1_epi8('0')), _mm512_set1_epi8(9));
            const uint64_t letter = hex ? _mm512_cmple_epu8_mask(_mm512_sub_epi8(lower, _mm512_set1_epi8('a')), _mm512_set1_epi8(5)) : 0;
            const uint64_t from = live & (first == 0 ? UINT64_MAX << prefix : UINT64_MAX);
            const uint64_t stops = from & ~(decimal | letter | _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('\'')));
            const uint64_t before = stops != 0 ? (stops & (0 - stops)) - 1 : UINT64_MAX;
            digits += (uint32_t)__builtin_popcountll((decimal | letter) & from & before);
            counting = stops == 0 && digits <= limit;
        }
    }
    return spliced ? BUSTER_CHECK_LITERAL_TABLE_SPLICED : integer && digits > limit ? BUSTER_CHECK_LITERAL_TABLE_ROUND : 0;
}

// Short spellings fit in one bounded byte vector. Longer spellings carry their prefix state across vectors.
static uint32_t check_literal_table_classify(const uint8_t* bytes, uint32_t length, uint32_t width, bool splices, bool trigraphs, bool round)
{
    uint32_t result = 0;
    if (!splices && !round)
    {
        // A clean spelling with no rounding query needs no bytes examined.
        result = 0;
    }
    else if (length > 64)
    {
        result = check_literal_table_long_category(bytes, length, width, splices, trigraphs, round);
    }
    else
    {
        const uint64_t live = length == 64 ? UINT64_MAX : (UINT64_C(1) << length) - 1;
        const __m512i text = _mm512_maskz_loadu_epi8((__mmask64)live, bytes);
        const uint64_t backslash = splices ? _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('\\')) : 0;
        const uint64_t question = splices && trigraphs ? _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('?')) : 0;
        const uint64_t spliced = live & (backslash | question);
        result = spliced != 0 ? BUSTER_CHECK_LITERAL_TABLE_SPLICED : 0;
        const __m512i lower = _mm512_or_si512(text, _mm512_set1_epi8(0x20));
        const bool hexadecimal = length > 2 && bytes[0] == '0' && (bytes[1] | 0x20) == 'x';
        // A '.' or an exponent makes it a floating literal, which most long numbers of a table are: no digits to count.
        const uint64_t floating = round && spliced == 0 ? live & (_mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('.')) |
                                                                  _mm512_cmpeq_epi8_mask(lower, _mm512_set1_epi8(hexadecimal ? 'p' : 'e'))) : 0;
        if (round && spliced == 0 && floating == 0)
        {
            const bool binary = length > 2 && bytes[0] == '0' && (bytes[1] | 0x20) == 'b';
            const bool octal = !hexadecimal && !binary && length > 1 && bytes[0] == '0';
            const uint32_t first = hexadecimal || binary ? 2 : octal ? 1 : 0;
            const uint32_t limit = hexadecimal ? (width == 32 ? 6 : 13) : binary ? (width == 32 ? 24 : 53) : octal ? (width == 32 ? 8 : 17) : (width == 32 ? 7 : 15);
            const uint64_t decimal = _mm512_cmple_epu8_mask(_mm512_sub_epi8(text, _mm512_set1_epi8('0')), _mm512_set1_epi8(9));
            const uint64_t letter = hexadecimal ? _mm512_cmple_epu8_mask(_mm512_sub_epi8(lower, _mm512_set1_epi8('a')), _mm512_set1_epi8(5)) : 0;
            const uint64_t digit = live & (decimal | letter);
            const uint64_t separator = live & _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('\''));
            const uint64_t from = live & (UINT64_MAX << first);
            const uint64_t stops = from & ~(digit | separator);
            const uint64_t before = stops != 0 ? (stops & (0 - stops)) - 1 : UINT64_MAX;
            const uint32_t digits = (uint32_t)__builtin_popcountll(digit & from & before);
            result = digits > limit ? BUSTER_CHECK_LITERAL_TABLE_ROUND : 0;
        }
    }
    return result;
}


uint32_t head_category(const uint8_t* b,uint32_t n,uint32_t w,bool s,bool t,bool r) {return check_literal_table_classify(b,n,w,s,t,r);}
