#include <immintrin.h>
#include <stdbool.h>
#include <stdint.h>
#define BUSTER_CHECK_LITERAL_TABLE_SPLICED 1u
#define BUSTER_CHECK_LITERAL_TABLE_ROUND 2u

static inline __attribute__((always_inline)) bool check_literal_table_marker(const uint8_t* s, uint32_t length, uint8_t marker, bool fold)
{
    for (uint64_t first = 0; first < length; first += 64)
    {
        const uint32_t left = length - (uint32_t)first;
        const __mmask64 live = left >= 64 ? UINT64_MAX : _bzhi_u64(UINT64_MAX, left);
        const __m512i text = _mm512_maskz_loadu_epi8(live, s + first);
        const __m512i normal = fold ? _mm512_or_si512(text, _mm512_set1_epi8(0x20)) : text;
        if ((_mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8(fold ? '.' : '\\')) |
             _mm512_cmpeq_epi8_mask(normal, _mm512_set1_epi8((char)marker))) != 0)
        {
            return true;
        }
    }
    return false;
}

static uint32_t check_literal_table_classify(const uint8_t* bytes, uint32_t length, uint32_t width, bool splices, bool trigraphs, bool round)
{
    if (splices && check_literal_table_marker(bytes, length, trigraphs ? '?' : '\\', false))
    {
        return BUSTER_CHECK_LITERAL_TABLE_SPLICED;
    }
    if (!round || length <= (width == 32 ? 7u : 15u))
    {
        return 0;
    }
    const bool zero = bytes[0] == '0';
    const uint8_t base = zero ? bytes[1] | 0x20 : 0;
    const bool hex = base == 'x';
    const bool binary = base == 'b';
    if (check_literal_table_marker(bytes, length, hex ? 'p' : 'e', true))
    {
        return 0;
    }
    const uint32_t prefix = hex || binary ? 2 : zero;
    const uint32_t limit = hex ? (width == 32 ? 6 : 13) : binary ? (width == 32 ? 24 : 53) :
                           zero ? (width == 32 ? 8 : 17) : (width == 32 ? 7 : 15);
    uint32_t digits = 0;
    for (uint64_t first = prefix; first < length; first += 64)
    {
        const uint32_t left = length - (uint32_t)first;
        const __mmask64 live = left >= 64 ? UINT64_MAX : _bzhi_u64(UINT64_MAX, left);
        const __m512i text = _mm512_maskz_loadu_epi8(live, bytes + first);
        const __m512i lower = _mm512_or_si512(text, _mm512_set1_epi8(0x20));
        const uint64_t decimal = _mm512_cmple_epu8_mask(_mm512_sub_epi8(text, _mm512_set1_epi8('0')), _mm512_set1_epi8(9));
        const uint64_t letter = hex ? _mm512_cmple_epu8_mask(_mm512_sub_epi8(lower, _mm512_set1_epi8('a')), _mm512_set1_epi8(5)) : 0;
        const uint64_t stops = ~(decimal | letter | _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('\'')));
        const uint64_t before = stops != 0 ? (stops & (0 - stops)) - 1 : UINT64_MAX;
        digits += (uint32_t)__builtin_popcountll((decimal | letter) & before);
        if (stops != 0 || digits > limit)
        {
            break;
        }
    }
    return digits > limit ? BUSTER_CHECK_LITERAL_TABLE_ROUND : 0;
}
uint32_t head_category(const uint8_t* b,uint32_t n,uint32_t w,bool s,bool t,bool r) {return check_literal_table_classify(b,n,w,s,t,r);}
