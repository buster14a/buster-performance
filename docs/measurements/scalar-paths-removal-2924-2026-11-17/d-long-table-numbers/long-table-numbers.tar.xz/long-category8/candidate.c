#include <immintrin.h>
#include <stdint.h>
#include <stdbool.h>
static const uint8_t spelling_class[128] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 128, 0, 0, 0, 0, 0, 0, 1, 0,
    32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 0, 0, 0, 0, 0, 16,
    0, 64, 64, 64, 64, 66, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0,
    0, 64, 64, 64, 64, 66, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

static uint32_t check_literal_table_classify(const uint8_t* bytes, uint32_t length, uint32_t width, bool splices, bool trigraphs, bool round)
{
    const bool count = round && length > (width == 32 ? 7u : 15u);
    if (!splices && !count)
    {
        return 0;
    }
    const bool zero = count && bytes[0] == '0';
    const uint8_t radix = zero ? bytes[1] | 0x20 : 0;
    const bool hex = radix == 'x';
    const bool binary = radix == 'b';
    const uint32_t prefix = hex || binary ? 2 : zero;
    const uint32_t limit = hex ? (width == 32 ? 6 : 13) : binary ? (width == 32 ? 24 : 53) :
                           zero ? (width == 32 ? 8 : 17) : (width == 32 ? 7 : 15);
    const __m512i lo = _mm512_loadu_si512(spelling_class);
    const __m512i hi = _mm512_loadu_si512(spelling_class + 64);
    const __m512i splice = _mm512_set1_epi8(splices ? (trigraphs ? 24 : 8) : 0);
    const __m512i exponent = _mm512_set1_epi8(hex ? 5 : 3);
    const __m512i digits = _mm512_set1_epi8(hex ? 96 : 32);
    uint32_t significant = 0;
    uint64_t from = UINT64_MAX << prefix;
    bool spelling = count;
    for (uint64_t first = 0; first < length; first += 64)
    {
        const uint32_t left = length - (uint32_t)first;
        const __mmask64 live = _bzhi_u64(UINT64_MAX, left < 64 ? left : 64);
        const __m512i text = _mm512_maskz_loadu_epi8(live, bytes + first);
        const __mmask64 ascii = ~_mm512_movepi8_mask(text);
        const __m512i kind = _mm512_maskz_permutex2var_epi8(ascii, lo, text, hi);
        if (_mm512_test_epi8_mask(kind, splice) != 0)
        {
            return 1;
        }
        if (spelling)
        {
            if (_mm512_test_epi8_mask(kind, exponent) != 0)
            {
                spelling = false;
                if (!splices) break;
            }
            else if (from != 0 && significant <= limit)
            {
                const uint64_t valid = _mm512_test_epi8_mask(kind, digits);
                const uint64_t stop = from & ~(valid | _mm512_movepi8_mask(kind));
                const uint64_t before = stop ? (stop & -stop) - 1 : UINT64_MAX;
                significant += (uint32_t)__builtin_popcountll(valid & from & before);
                from = stop == 0 ? UINT64_MAX : 0;
            }
        }
    }
    return spelling && significant > limit ? 2u : 0u;
}
uint32_t head_category(const uint8_t* b,uint32_t n,uint32_t w,bool s,bool t,bool r) {return check_literal_table_classify(b,n,w,s,t,r);}
