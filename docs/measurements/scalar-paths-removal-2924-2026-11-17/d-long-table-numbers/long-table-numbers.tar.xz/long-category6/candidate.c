#include <immintrin.h>
#include <stdbool.h>
#include <stdint.h>
#define BUSTER_CHECK_LITERAL_TABLE_SPLICED 1u
#define BUSTER_CHECK_LITERAL_TABLE_ROUND 2u

static inline __attribute__((always_inline)) __m512i check_literal_table_block(const uint8_t* bytes, uint32_t length)
{
    const __mmask64 live = _bzhi_u64(UINT64_MAX, length < 64 ? length : 64);
    return _mm512_maskz_loadu_epi8(live, bytes);
}

static inline __attribute__((always_inline)) bool check_literal_table_marked(__m512i text, uint8_t a, uint8_t b, bool fold)
{
    const __m512i normal = fold ? _mm512_or_si512(text, _mm512_set1_epi8(0x20)) : text;
    return (_mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8((char)a)) |
            _mm512_cmpeq_epi8_mask(normal, _mm512_set1_epi8((char)b))) != 0;
}

static __attribute__((noinline)) bool check_literal_table_tail_marked(const uint8_t* bytes, uint32_t length, uint8_t a, uint8_t b, bool fold)
{
    for (uint64_t i = 64; i < length; i += 64)
    {
        if (check_literal_table_marked(check_literal_table_block(bytes + i, length - (uint32_t)i), a, b, fold))
        {
            return true;
        }
    }
    return false;
}

static inline __attribute__((always_inline)) uint32_t check_literal_table_count(__m512i text, bool hex, uint64_t from, bool* ended)
{
    const uint64_t decimal = _mm512_cmple_epu8_mask(_mm512_sub_epi8(text, _mm512_set1_epi8('0')), _mm512_set1_epi8(9));
    const __m512i lower = _mm512_or_si512(text, _mm512_set1_epi8(0x20));
    const uint64_t letter = hex ? _mm512_cmple_epu8_mask(_mm512_sub_epi8(lower, _mm512_set1_epi8('a')), _mm512_set1_epi8(5)) : 0;
    const uint64_t stops = from & ~(decimal | letter | _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('\'')));
    const uint64_t before = stops != 0 ? (stops & (0 - stops)) - 1 : UINT64_MAX;
    *ended = stops != 0;
    return (uint32_t)__builtin_popcountll((decimal | letter) & from & before);
}

static __attribute__((noinline)) uint32_t check_literal_table_tail_digits(const uint8_t* bytes, uint32_t length, bool hex, uint32_t digits, uint32_t limit)
{
    bool ended = false;
    for (uint64_t i = 64; i < length && !ended && digits <= limit; i += 64)
    {
        digits += check_literal_table_count(check_literal_table_block(bytes + i, length - (uint32_t)i), hex, UINT64_MAX, &ended);
    }
    return digits;
}

static uint32_t check_literal_table_classify(const uint8_t* bytes, uint32_t length, uint32_t width, bool splices, bool trigraphs, bool round)
{
    if (!splices && !round)
    {
        return 0;
    }
    const __m512i first = check_literal_table_block(bytes, length);
    const uint8_t second = trigraphs ? '?' : '\\';
    if (splices && (check_literal_table_marked(first, '\\', second, false) ||
                    (length > 64 && check_literal_table_tail_marked(bytes, length, '\\', second, false))))
    {
        return BUSTER_CHECK_LITERAL_TABLE_SPLICED;
    }
    if (!round || length <= (width == 32 ? 7u : 15u))
    {
        return 0;
    }
    const bool zero = bytes[0] == '0';
    const uint8_t base = zero ? bytes[1] | 0x20 : 0;
    const bool hex = base == 'x';
    const uint8_t exponent = hex ? 'p' : 'e';
    if (check_literal_table_marked(first, '.', exponent, true) ||
        (length > 64 && check_literal_table_tail_marked(bytes, length, '.', exponent, true)))
    {
        return 0;
    }
    const bool binary = base == 'b';
    const uint32_t prefix = hex || binary ? 2 : zero;
    const uint32_t limit = hex ? (width == 32 ? 6 : 13) : binary ? (width == 32 ? 24 : 53) :
                           zero ? (width == 32 ? 8 : 17) : (width == 32 ? 7 : 15);
    bool ended;
    uint32_t digits = check_literal_table_count(first, hex, UINT64_MAX << prefix, &ended);
    if (length > 64 && !ended && digits <= limit)
    {
        digits = check_literal_table_tail_digits(bytes, length, hex, digits, limit);
    }
    return digits > limit ? BUSTER_CHECK_LITERAL_TABLE_ROUND : 0;
}
uint32_t head_category(const uint8_t* b,uint32_t n,uint32_t w,bool s,bool t,bool r) {return check_literal_table_classify(b,n,w,s,t,r);}
