#include "base.c"
#include <stdio.h>
#include <string.h>
#define BUSTER_ARRAY_LENGTH(x) (sizeof(x)/sizeof((x)[0]))
typedef int CheckTest;
static void check_test_literal_floating_classify(CheckTest* test)
{
    static const char alphabet[] = "0123456789abcdefABCDEFxXbBpPeE.'\\?uUlLwW+-";
    static const char* const spellings[] = {
        "16777217",
        "16777216",
        "0xffffff",
        "0x1000001",
        "077777777",
        "0100000001",
        "0b111111111111111111111111",
        "0b1000000000000000000000001",
        "9007199254740993ULL",
        "0x20000000000001",
        "0400000000000000001",
        "16'777'217",
        "1e5",
        "0x1p3",
        "0x1e5",
        "1.5",
        "1677\\\n7217",
        "1?" "?/\n2",
    };
    uint8_t bytes[80];
    uint64_t state = 0x5d1f2a3b4c6e7f80ull;
    uint64_t digest = UINT64_C(1469598103934665603);
    uint32_t cases = 0;
    for (uint32_t i = 0; i < 20000 + BUSTER_ARRAY_LENGTH(spellings) * 32; i += 1)
    {
        state = state * 6364136223846793005ull + 1442695040888963407ull;
        const uint32_t named = i >= 20000 ? (i - 20000) / 32 : UINT32_MAX;
        uint32_t length = named != UINT32_MAX ? (uint32_t)strlen(spellings[named]) : 1 + (uint32_t)(state >> 33) % 72;
        if (named != UINT32_MAX)
        {
            memcpy(bytes, spellings[named], length);
        }
        for (uint32_t j = 0; named == UINT32_MAX && j < length; j += 1)
        {
            state = state * 6364136223846793005ull + 1442695040888963407ull;
            // Mostly digits, and a prefix now and then, so that long integers come up.
            const uint32_t pick = (uint32_t)(state >> 33);
            bytes[j] = pick % 4 != 0 ? (uint8_t)('0' + pick / 4 % 10) : (uint8_t)alphabet[pick / 4 % (sizeof(alphabet) - 1)];
        }
        if (named == UINT32_MAX && (state >> 60) == 0 && length > 2)
        {
            bytes[0] = '0';
            bytes[1] = (uint8_t)"xXbB"[(state >> 56) & 3];
        }
        const uint32_t flags = named != UINT32_MAX ? (i - 20000) % 32 : (uint32_t)(state >> 40) & 31;
        const uint32_t width = (flags & 1) != 0 ? 64 : 32;
        const bool splices = (flags & 2) != 0;
        const bool trigraphs = (flags & 4) != 0;
        const bool round = (flags & 8) != 0;
        const uint32_t vector = check_literal_table_classify(bytes, length, width, splices, trigraphs, round);
        digest = (digest ^ vector) * UINT64_C(1099511628211);
        cases += 1;
    }
    printf("%016lx\n",digest);
}
int main(void){check_test_literal_floating_classify(NULL); return 0;}
