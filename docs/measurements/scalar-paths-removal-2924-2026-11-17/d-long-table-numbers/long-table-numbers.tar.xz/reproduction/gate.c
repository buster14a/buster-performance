#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <x86intrin.h>
typedef uint32_t (*Category)(const uint8_t*,uint32_t,uint32_t,bool,bool,bool);
uint32_t base_category(const uint8_t*,uint32_t,uint32_t,bool,bool,bool);
uint32_t head_category(const uint8_t*,uint32_t,uint32_t,bool,bool,bool);
static int compare(const void* a,const void* b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return (x>y)-(x<y);}
int main(void)
{
    Category routines[2]={base_category,head_category};
    static uint8_t data[32][1100]; uint32_t sizes[128],lengths=0;
    for(uint32_t n=0;n<=96;n++)sizes[lengths++]=n;
    for(uint32_t b=128;b<=1024;b*=2)for(int d=-2;d<=2;d++)sizes[lengths++]=b+d;
    for(uint32_t shape=0;shape<10;shape++)for(uint32_t z=0;z<lengths;z++){
        uint32_t n=sizes[z];
        for(uint32_t i=0;i<32;i++){
            uint8_t* s=data[i]+i;
            memset(s,'3'+i%6,n);
            if(n>=2 && shape==1){s[0]='0';s[1]='x';}
            if(n>=2 && shape==2){s[0]='0';s[1]='b';}
            if(n && shape==3)s[0]='0';
            if(n && shape==4)s[i%n]='.';
            if(n && shape==5)s[n-1]='E';
            if(n && shape==6)s[n-1]='\\';
            if(n && shape==7)s[n-1]='?';
            if(shape==8)for(uint32_t k=1;k<n;k+=2)s[k]='\'';
            if(shape==9 && n>=2){s[1]='u';if(n>66)s[66]='.';}
        }
        for(uint32_t i=0;i<32;i++)for(uint32_t f=0;f<16;f++)
            if(base_category(data[i]+i,n,f&1?32:64,f&2,f&4,f&8)!=head_category(data[i]+i,n,f&1?32:64,f&2,f&4,f&8))return 1;
        for(uint32_t policy=0;policy<4;policy++){
            uint64_t ticks[2][11]; uint32_t sums[2]={0};
            for(uint32_t rep=0;rep<11;rep++)for(uint32_t order=0;order<2;order++){
                const uint32_t side=(rep+order)&1;
                Category fn=routines[side];
                _mm_lfence();uint64_t start=__rdtsc();_mm_lfence();
                uint32_t sum=0;
                for(uint32_t k=0;k<256;k++){uint32_t i=k&31;sum+=fn(data[i]+i,n,i&1?32:64,policy&1,i&2,policy&2);}
                _mm_lfence();ticks[side][rep]=__rdtsc()-start;sums[side]+=sum;
            }
            if(sums[0]!=sums[1])return 2;
            for(uint32_t side=0;side<2;side++)qsort(ticks[side],11,sizeof(uint64_t),compare);
            printf("%u\t%u\t%u\t%lu\t%lu\n",shape,n,policy,ticks[0][5],ticks[1][5]);
        }
    }
    return 0;
}
