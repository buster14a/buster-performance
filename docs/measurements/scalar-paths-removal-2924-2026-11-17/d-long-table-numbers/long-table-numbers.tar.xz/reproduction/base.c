#include <immintrin.h>
#include <stdbool.h>
#include <stdint.h>
// Whether a number's spelling is an integer literal's: no '.', and no exponent ('e' in decimal, 'p' in hexadecimal).
static bool check_literal_table_integer_spelling(const uint8_t* spelling, uint32_t length)
{
    const bool hexadecimal = length > 2 && spelling[0] == '0' && (spelling[1] | 0x20) == 'x';
    const uint8_t exponent = hexadecimal ? 'p' : 'e';
    bool integer = true;
    for (uint32_t i = 0; integer && i < length; i += 1)
    {
        integer = spelling[i] != '.' && (spelling[i] | 0x20) != exponent;
    }
    return integer;
}

// Whether an integer literal's spelling may hold a value that `width`'s format (32: float, 64: double) can't: more
// digits than every value of that many is exact in, 2^24 or 2^53 being the format's least integer past which one isn't.
// Decimal: 7 or 15 digits; hexadecimal: 6 or 13; octal: 8 or 17; binary: 24 or 53. Leading zeros count, and digit
// separators don't, so the count errs only toward testing: a spelling counted short is still tested by its batch
// (check_literal_table_floating_value), only later.
static bool check_literal_table_integer_may_round(const uint8_t* spelling, uint32_t length, uint32_t width)
{
    const bool hexadecimal = length > 2 && spelling[0] == '0' && (spelling[1] | 0x20) == 'x';
    const bool binary = length > 2 && spelling[0] == '0' && (spelling[1] | 0x20) == 'b';
    const bool octal = !hexadecimal && !binary && length > 1 && spelling[0] == '0';
    const uint32_t first = hexadecimal || binary ? 2 : octal ? 1 : 0;
    const uint32_t limit = hexadecimal ? (width == 32 ? 6 : 13) : binary ? (width == 32 ? 24 : 53) : octal ? (width == 32 ? 8 : 17) : (width == 32 ? 7 : 15);
    uint32_t digits = 0;
    bool more = true;
    for (uint32_t i = first; more && i < length; i += 1)
    {
        const uint8_t c = spelling[i];
        const bool digit = (c >= '0' && c <= '9') || (hexadecimal && (c | 0x20) >= 'a' && (c | 0x20) <= 'f');
        digits += digit;
        more = digit || c == '\'';
    }
    return digits > limit;
}

// What check_literal_table_classify finds in a number's bytes: a line splice (or, with trigraphs, a '?'), which leaves
// its spelling to check_input_spelling; or an integer whose digits allow a value the format can't hold
// (check_literal_table_integer_may_round).
#define BUSTER_CHECK_LITERAL_TABLE_SPLICED 1u
#define BUSTER_CHECK_LITERAL_TABLE_ROUND 2u

// The scalar twin of check_literal_table_classify, and its oracle: `splices` says whether to look for splices, and
// `trigraphs` whether a '?' counts as one, as pp_remove_splices reads them; `round` whether to look for an integer that
// may round in `width`'s format.
static uint32_t check_literal_table_classify_scalar(const uint8_t* bytes, uint32_t length, uint32_t width, bool splices, bool trigraphs, bool round)
{
    bool spliced = false;
    for (uint32_t i = 0; splices && i < length; i += 1)
    {
        spliced = spliced || bytes[i] == '\\' || (trigraphs && bytes[i] == '?');
    }
    const bool rounds = round && !spliced && check_literal_table_integer_spelling(bytes, length) && check_literal_table_integer_may_round(bytes, length, width);
    return spliced ? BUSTER_CHECK_LITERAL_TABLE_SPLICED : rounds ? BUSTER_CHECK_LITERAL_TABLE_ROUND : 0;
}

// A number's category (BUSTER_CHECK_LITERAL_TABLE_SPLICED, _ROUND or neither) from one masked load of its bytes: masks of its
// splices, its '.' and exponent (an integer has none), and its digits up to the first character past its prefix that is
// neither a digit nor a separator. The masked-off lanes past `length` are never read. A number longer than 64 bytes takes
// the scalar twin.
static uint32_t check_literal_table_classify(const uint8_t* bytes, uint32_t length, uint32_t width, bool splices, bool trigraphs, bool round)
{
    uint32_t result = 0;
    if (length > 64)
    {
        result = check_literal_table_classify_scalar(bytes, length, width, splices, trigraphs, round);
    }
    else
    {
        const uint64_t live = length == 64 ? UINT64_MAX : (UINT64_C(1) << length) - 1;
        const __m512i text = _mm512_maskz_loadu_epi8((__mmask64)live, bytes);
        const uint64_t backslash = splices ? _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('\\')) : 0;
        const uint64_t question = splices && trigraphs ? _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('?')) : 0;
        const uint64_t spliced = live & (backslash | question);
        result = spliced != 0 ? BUSTER_CHECK_LITERAL_TABLE_SPLICED : 0;
        const __m512i lower = _mm512_or_si512(text, _mm512_set1_epi8(0x20));
        const bool hexadecimal = length > 2 && bytes[0] == '0' && (bytes[1] | 0x20) == 'x';
        // A '.' or an exponent makes it a floating literal, which most long numbers of a table are: no digits to count.
        const uint64_t floating = round && spliced == 0 ? live & (_mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('.')) |
                                                                  _mm512_cmpeq_epi8_mask(lower, _mm512_set1_epi8(hexadecimal ? 'p' : 'e'))) : 0;
        if (round && spliced == 0 && floating == 0)
        {
            const bool binary = length > 2 && bytes[0] == '0' && (bytes[1] | 0x20) == 'b';
            const bool octal = !hexadecimal && !binary && length > 1 && bytes[0] == '0';
            const uint32_t first = hexadecimal || binary ? 2 : octal ? 1 : 0;
            const uint32_t limit = hexadecimal ? (width == 32 ? 6 : 13) : binary ? (width == 32 ? 24 : 53) : octal ? (width == 32 ? 8 : 17) : (width == 32 ? 7 : 15);
            const uint64_t decimal = _mm512_cmple_epu8_mask(_mm512_sub_epi8(text, _mm512_set1_epi8('0')), _mm512_set1_epi8(9));
            const uint64_t letter = hexadecimal ? _mm512_cmple_epu8_mask(_mm512_sub_epi8(lower, _mm512_set1_epi8('a')), _mm512_set1_epi8(5)) : 0;
            const uint64_t digit = live & (decimal | letter);
            const uint64_t separator = live & _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('\''));
            const uint64_t from = live & (UINT64_MAX << first);
            const uint64_t stops = from & ~(digit | separator);
            const uint64_t before = stops != 0 ? (stops & (0 - stops)) - 1 : UINT64_MAX;
            const uint32_t digits = (uint32_t)__builtin_popcountll(digit & from & before);
            result = digits > limit ? BUSTER_CHECK_LITERAL_TABLE_ROUND : 0;
        }
    }
    return result;
}


uint32_t base_category(const uint8_t* b,uint32_t n,uint32_t w,bool s,bool t,bool r) {return check_literal_table_classify(b,n,w,s,t,r);}
