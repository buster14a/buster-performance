from pathlib import Path
p=Path('src/buster/compiler/c_check_literal_table_input.c');s=p.read_text();a=s.index('static uint32_t check_literal_table_classify(');a=s.index('\n{',a)+2;s=s[:a]+'''
    fprintf(stderr, "literal-shape %u %u %u %u %u\\n", length, width, (unsigned)splices, (unsigned)trigraphs, (unsigned)round);
'''+s[a:];p.write_text(s)
