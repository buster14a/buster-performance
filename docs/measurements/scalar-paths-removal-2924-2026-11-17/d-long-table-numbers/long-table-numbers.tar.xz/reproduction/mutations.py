from pathlib import Path
import subprocess,sys, tempfile
p=Path(__file__).resolve().parent
test=Path(sys.argv[1]).read_text()
rows=[]
for name in ('integer_spellings','classify','classify_guarded'):
 a=test.index('static void check_test_literal_floating_'+name+'(')
 rows.append(test[a:test.index('\n}',a)+2])
header='''
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#define BUSTER_ARRAY_LENGTH(a) (sizeof(a)/sizeof((a)[0]))
typedef struct {uint32_t checked,failed;} CheckTest;
static void check_test_expect(CheckTest* t, bool b, const char* label){t->checked++;if(!b){t->failed++;fprintf(stderr,"%s\\n",label);}}
'''
smoke=header+'\n'.join(rows)+'''
int main(void) {
 CheckTest t={0};
 check_test_literal_floating_integer_spellings(&t);
 check_test_literal_floating_classify(&t);
 check_test_literal_floating_classify_guarded(&t);
 printf("%u fixture checks; %u failures\\n",t.checked,t.failed);
 return t.failed!=0;
}
'''
# The independent category digest and explicit guard values both run without retaining the old production classifier.
mutations=[('short-tail','first < length','first + 64 <= length'),('no-late-exponent','if (integer)','if (integer && first == 0)'),('reverse-radix',"hex ? 'p' : 'e'","hex ? 'e' : 'p'"),('no-trigraph','(trigraphs &&','(false &&'),('lost-suffix','counting = stops == 0 && digits <= limit;','counting = digits <= limit;'),('wrong-cutoff','digits > limit ?','digits >= limit ?'),('no-splice-priority','return spliced ?','return false ?'),('unmasked-tail','_mm512_maskz_loadu_epi8(live, bytes + first)','_mm512_loadu_si512(bytes + first)')]
source=(p/'head.c').read_text()
cc=sys.argv[2]
with tempfile.TemporaryDirectory() as td:
 c=Path(td)/'test.c';exe=Path(td)/'test'
 for name,old,new in [('original','',''),*mutations]:
  assert not old or old in source
  c.write_text((source if not old else source.replace(old,new,1))+smoke)
  subprocess.run([cc,'-O1','-g','-march=native','-fsanitize=address,undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True)
  r=subprocess.run([str(exe)],capture_output=True,text=True)
  print(name, r.returncode, r.stdout.strip(),r.stderr.splitlines()[:1],flush=True)
