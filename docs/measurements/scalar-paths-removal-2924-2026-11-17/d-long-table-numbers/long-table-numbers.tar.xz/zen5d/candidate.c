#include <stdbool.h>
#include <stdint.h>
#include <immintrin.h>
#define BUSTER_CHECK_LITERAL_TABLE_SPLICED 1u
#define BUSTER_CHECK_LITERAL_TABLE_ROUND 2u

// Search every requested marker through the whole spelling. A suffix ends only the
// digit count. Splice detection still takes precedence over a point or exponent.
static uint32_t check_literal_table_classify(const uint8_t* bytes, uint32_t length, uint32_t width, bool splices, bool trigraphs, bool round)
{
    bool count = round && length > (width == 32 ? 7u : 15u);
    if (!splices && !count)
    {
        return 0;
    }
    const bool initial_zero = count && bytes[0] == '0';
    const uint8_t base = initial_zero ? bytes[1] | 0x20 : 0;
    const bool hex = base == 'x';
    const bool binary = base == 'b';
    const uint32_t prefix = hex || binary ? 2 : initial_zero;
    const uint32_t limit = hex ? (width == 32 ? 6 : 13) : binary ? (width == 32 ? 24 : 53) :
                           initial_zero ? (width == 32 ? 8 : 17) : (width == 32 ? 7 : 15);
    uint32_t digits = 0;
    bool integer = count;
    for (uint64_t first = 0; first < length; first += 64)
    {
        const uint32_t left = length - (uint32_t)first;
        const bool full = left >= 64;
        const __mmask64 live = full ? UINT64_MAX : _bzhi_u64(UINT64_MAX, left);
        const __m512i text = _mm512_maskz_loadu_epi8(live, bytes + first);
        if (splices && (_mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('\\')) != 0 ||
                        (trigraphs && _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('?')) != 0)))
        {
            return BUSTER_CHECK_LITERAL_TABLE_SPLICED;
        }
        if (integer)
        {
            const __m512i lower = _mm512_or_si512(text, _mm512_set1_epi8(0x20));
            if ((_mm512_cmpeq_epi8_mask(lower, _mm512_set1_epi8(hex ? 'p' : 'e')) |
                 _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('.'))) != 0)
            {
                if (!splices)
                {
                    return 0;
                }
                integer = false;
            }
            else if (count)
            {
                const uint64_t decimal = _mm512_cmple_epu8_mask(_mm512_sub_epi8(text, _mm512_set1_epi8('0')), _mm512_set1_epi8(9));
                const uint64_t letter = hex ? _mm512_cmple_epu8_mask(_mm512_sub_epi8(lower, _mm512_set1_epi8('a')), _mm512_set1_epi8(5)) : 0;
                const uint64_t from = first == 0 ? UINT64_MAX << prefix : UINT64_MAX;
                const uint64_t stops = from & ~(decimal | letter | _mm512_cmpeq_epi8_mask(text, _mm512_set1_epi8('\'')));
                const uint64_t before = stops != 0 ? (stops & (0 - stops)) - 1 : UINT64_MAX;
                digits += (uint32_t)__builtin_popcountll((decimal | letter) & from & before);
                count = stops == 0 && digits <= limit;
            }
        }
    }
    return integer && digits > limit ? BUSTER_CHECK_LITERAL_TABLE_ROUND : 0;
}
uint32_t head_category(const uint8_t* b,uint32_t n,uint32_t w,bool s,bool t,bool r) {return check_literal_table_classify(b,n,w,s,t,r);}
