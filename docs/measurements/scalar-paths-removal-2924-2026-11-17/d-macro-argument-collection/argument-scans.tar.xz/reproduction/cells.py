from pathlib import Path
from statistics import median
import re,sys
p=Path(sys.argv[1]); mode=sys.argv[2]
for group in sorted(p.iterdir()):
 if not group.is_dir():continue
 results=[]
 for log in group.glob('*.log'):
  raw=log.read_text().split('list 1, user cycles (millions):')[-1]
  med={k:float(v) for k,v in re.findall(r'^  ([\w-]+): \d+ runs, median ([\d.]+)',raw,re.M)}
  if mode in med:results.append(med[mode]/med['base'])
 print(group.name,sum(x<=1 for x in results),len(results),round(median(results),3) if results else None,max(results,default=None))
