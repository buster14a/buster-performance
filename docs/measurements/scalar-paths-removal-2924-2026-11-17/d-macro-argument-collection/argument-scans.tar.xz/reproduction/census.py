from pathlib import Path
p=Path('src/buster/compiler/c_preprocessor_impl.c');s=p.read_text();a=s.index('static void pp_collect_step(Preprocessor* pp)\n{');b=s.index('// Invokes a function-like macro',a)
t=s[a:b];t=t.replace('    bool unterminated = false;', '''    bool unterminated = false;
    const uint32_t role = (context->kind != BUSTER_PP_CONTEXT_FILE) * 2 + invocation->builtin;
    uint32_t consumed = 0;
    uint32_t ordinary = 0;
    uint32_t special = 0;''');t=t.replace('            context->position += 1;','''            consumed += 1;
            const bool delimiter = !invocation->opened || token.kind == C_TOKEN_L_PAREN || token.kind == C_TOKEN_R_PAREN || token.kind == C_TOKEN_COMMA;
            special += delimiter;
            ordinary += !delimiter;
            context->position += 1;''')
t=t[:t.rindex('\n}')]+'''
    const unsigned bin = consumed < 4 ? consumed : consumed <= 8 ? 4 : consumed <= 16 ? 5 : consumed <= 64 ? 6 : 7;
    fprintf(stderr, "collect-visit %u %u %u %u %u\\n", role, bin, consumed, ordinary, special);
}

'''
s=s[:a]+t+s[b:];p.write_text(s)
