from pathlib import Path
p=Path('arg-input');p.mkdir(exist_ok=True)
for shape in ['ordinary','macros','nested','comments']:
 for n in [*range(66),95,96,97,127,128,129,255,256,257]:
  prefix=['#define KEEP 1','#define F(x) #x','#define ALIAS F','#define NAME replacement']
  for k in range(64):
   kinds={'ordinary':['17'], 'macros':['NAME'], 'comments':['/* kept */','n']} 
   if shape=='nested':body=['(']*(n//2)+(['n'] if n%2 else [])+[')']*(n//2)
   else:
    seq=kinds[shape];body=[seq[i%len(seq)] for i in range(n)]
   prefix+=['ALIAS(', '#if KEEP', ' '.join(body), '#endif', ')']
  (p/f'{shape}-{n}.c').write_text('\n'.join(prefix)+'\n')
