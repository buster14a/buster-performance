from pathlib import Path
p=Path(__file__).parent
s=(p/'quarter/buster/compiler/ir_optimize_unroll.c').read_text()
a=s.index('static bool ir_unroll_remap(');b=s.index('\n}\n',a)+3;fn=s[a:b]
pairs=[('production',None,None),('overlapping-columns','(unsigned)rows.use_b << 4','(unsigned)rows.use_b << 3'),('copy-wrong-quarter','_mm512_extracti32x4_epi32(remapped, 2)','_mm512_extracti32x4_epi32(remapped, 1)'),('erase-literals','needed == 0 ? abc','needed == 0 ? _mm512_setzero_si512()'),('write-tail-padding','_mm_mask_storeu_epi32(view->a + dest, active,','_mm_mask_storeu_epi32(view->a + dest, 15,')]
text=['#include "buster/compiler/main_unit_backend.c"\n']
for k,(name,old,new) in enumerate(pairs):
 w=fn.replace('ir_unroll_remap(',f'remap_{k}(')
 if old:assert w.count(old)==1;w=w.replace(old,new)
 text.append(w)
text.append('typedef bool RemapFn(const IrFunction*,uint32_t,uint32_t,const uint32_t*,IrFunction*,uint32_t);\nRemapFn* variants[]={'+','.join('remap_'+str(k)for k in range(len(pairs)))+'};\n')
# The test translation unit below already includes the compiler definitions.
g=(p.parent/'abi/verify-extra.c').read_text()
g=g[g.index('#include <stdio.h>'):]
g=g.replace('Remap measure_base,measure_extra;', 'Remap measure_base;\nstatic Remap* subject;')
g=g.replace('measure_extra','subject').replace('if(argc>1)state=', 'if(argc<3)return 2;const unsigned which=(unsigned)atoi(argv[2]);if(which>=5)return 2;subject=variants[which];\n if(argc>1)state=')
text.append(g);(p/'check-faults.c').write_text(''.join(text))
