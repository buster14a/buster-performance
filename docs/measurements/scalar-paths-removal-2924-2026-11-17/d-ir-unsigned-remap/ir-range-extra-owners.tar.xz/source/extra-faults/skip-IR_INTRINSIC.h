#include <immintrin.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <limits.h>
#define BUSTER_IR_NONE UINT32_MAX
#define BUSTER_IR_OP_TABLE 128
typedef struct { uint32_t instruction_count; uint8_t* op; uint8_t* type; uint8_t* flags; uint8_t* alignment_log2; uint32_t* a; uint32_t* b; uint32_t* c; } IrFunction;
typedef enum IrOp
{
    IR_INVALID,
    IR_CONST,
    IR_UNDEF,
    IR_PARAM,
    IR_COPY,
    IR_ADD,
    IR_SUB,
    IR_MUL,
    IR_SDIV,
    IR_UDIV,
    IR_SREM,
    IR_UREM,
    IR_AND,
    IR_OR,
    IR_XOR,
    IR_SHL,
    IR_LSHR,
    IR_ASHR,
    IR_NEG,
    IR_NOT,
    IR_FADD,
    IR_FSUB,
    IR_FMUL,
    IR_FDIV,
    IR_FNEG,
    IR_ICMP,
    IR_FCMP,
    IR_SELECT,
    IR_TRUNC,
    IR_ZEXT,
    IR_SEXT,
    IR_FTRUNC,
    IR_FEXT,
    IR_SITOFP,
    IR_UITOFP,
    IR_FPTOSI,
    IR_FPTOUI,
    IR_INTTOPTR,
    IR_PTRTOINT,
    IR_BITCAST,
    IR_STACK_ADDR,
    IR_SYMBOL_ADDR,
    IR_ADDRESS,
    IR_LOAD,
    IR_STORE,
    IR_CALL,
    IR_CALL_INDIRECT,
    IR_PHI,
    IR_BR,
    IR_CBR,
    IR_SWITCH,
    IR_RET,
    IR_UNREACHABLE,
    IR_ALLOCA,
    IR_STACK_SAVE,
    IR_STACK_RESTORE,
    IR_BR_INDIRECT,
    IR_VCONST,
    IR_VCMP,
    IR_VSELECT,
    // A frame slot's lifetime (#177): `a` the slot, `b` 0 where its object's lifetime starts and 1 where it ends. It
    // reads and writes nothing: the slot's bytes are indeterminate after a start, and no access may come after an end
    // until the next start. A slot with no marker lives throughout its function; one with markers is live where some
    // path from a start reaches without an end, which Tier 1's frame planner colors (tier1_emit_cfg_lifetimes).
    IR_LIFETIME,
    // A memory fence (#1059): `a` its order, C's memory_order (BUSTER_IR_FENCE_ORDER: relaxed to seq_cst), and its scope
    // (BUSTER_IR_FENCE_SIGNAL: a signal fence, against a signal handler on the same thread alone; without it, a thread
    // fence). It reads and writes no value, but no pass moves a load, a store or a call across it, eliminates one past it
    // or drops it: an effect as an unknown call's on memory, without a call's registers. The typed stream's FENCE.
    IR_FENCE,
    // A pure operation of two integers of its type that C has no operator for (#141), `c` which one
    // (BUSTER_IR_INTRINSIC_*): the high 64 bits of an I64's unsigned product, a times b as 128 bits (mulhu: the high half
    // of a 128-bit integer's product, which Tier 1's split of the 128-bit integers into halves makes, ir_wide.c, and
    // x86's mul gives in rdx), and the x86 builtins' scalar bit manipulations of an I32 or an I64, BMI2's pdep and pext
    // (a's bits deposited at, or extracted from, mask b's set bits) and bzhi (a with its bits from b's low byte up
    // cleared), and BMI1's bextr (a's bits from b's low byte up, as many as its second byte says), whose x86 rows the
    // typed stream's lowering admits (ir_simd_typed.c). The unary splat (#1450) repeats scalar a's raw bits throughout
    // a vector result; its scalar type gives the lane width, b is absent and flags are zero. It does no arithmetic,
    // including on floating operands, so signed zeros and NaN payloads are unchanged. The vector width changes (#1840:
    // extract, widen and insert) move a vector's bits whole between widths, their part in flags, and the permutes (#1840:
    // permute, shuffle, align and shuffle_lanes) move lanes of two vectors, their immediate in flags; the conversions
    // (#1840: extend and truncate) widen or narrow integer lanes, their lanes and mode in flags.
    IR_INTRINSIC,
    // An atomic read/modify/write (#1059): `a` the object's address, `b` the operand, of the result's type (an integer of
    // 1, 2, 4 or 8 bytes), and its flags BUSTER_IR_ATOMIC with its C memory order and its operation
    // (BUSTER_IR_RMW_OPERATION: an exchange, an addition or a compare-exchange, whose desired value, of the result's type,
    // is its `c`, which the others haven't). It returns the object's old value and leaves the operand (an exchange), the
    // sum (an addition) or, where the old value is the operand, the desired value (a compare-exchange) in it, as one
    // locked access; no pass moves an access across it or eliminates it, as an atomic store's and load's. The typed
    // stream's ATOMIC_RMW and ATOMIC_CAS.
    IR_ATOMIC_RMW,
    // A masked vector load (#1840): `a` the address, `b` the mask and `c` the passthrough, a vector of the result's type;
    // its flags the lanes (an IrSimdLane of integers, as a vselect's), whose mask `b` is (ir_lane_mask), and its
    // alignment_log2 a load's. Its lane i is the lane at the address's lane i where b's bit i is set, and the
    // passthrough's lane i where it isn't. A lane whose bit is clear is never read, so it can't fault: the masked
    // builtins' tail reads past an array's end are defined (vmovdqu8 to vmovdqu64 zmm{k}, [p]). A load's effect on
    // memory, of the set lanes' bytes alone: no pass moves it across a store or eliminates it but as an unused load.
    IR_MASKED_LOAD,
    // A masked vector store (#1840): `a` the address, `b` the stored vector and `c` the mask, its flags the lanes as a
    // masked load's and its alignment_log2 a store's. It writes the vector's lane i at the address's lane i where c's bit
    // i is set, and no byte of a lane whose bit is clear (vmovdqu8 to vmovdqu64 [p]{k}, zmm). A store's effect.
    IR_MASKED_STORE,
    // A compressing store (#1840): `a` the address, `b` the stored vector and `c` the mask, its flags the lanes and its
    // alignment_log2 a store's, as a masked store's. It writes the lanes whose bits are set one after another from the
    // address, in the lanes' order, and no other byte (vpcompressb to vpcompressq [p]{k}, zmm): the mask's population
    // count of lanes. A store's effect, of the vector's bytes at the address at most.
    IR_COMPRESS_STORE,
    // A gather (#1840): `a` the base address, `b` the index vector and `c` the mask of the result's lanes, its flags the
    // lanes (an IrSimdLane of integers, as a masked load's) and its alignment_log2 the scale's log2 (0 to 3). Its lane i is
    // the lane's bytes at a + sext(b's element i) * scale where c's bit i is set, and 0 where it isn't; the index's
    // elements are its bits over the result's lanes, dwords or qwords. A lane whose bit is clear is never read, so it
    // can't fault, as a masked load's (vpgatherdd to vpgatherqq zmm{k}, [a + zmm * scale], into a zeroed register). A
    // load's effect, of any memory.
    IR_GATHER,
    // A fused multiply-add (#1840) of floats or doubles: a * b + c, rounded once at the current rounding. Where a, b or c
    // is a NaN, the first of them in that order, quieted; where the product or the sum is invalid (an infinity times zero,
    // or infinities of opposite signs) of no NaN, the default NaN, a negative quiet NaN of no payload. x86's FMA3 forms
    // compute this in each of their orders, 132, 213 and 231 (vfmadd213sd b, a, c's a * b + c), on Intel's and AMD's
    // (#1840's check over 3,375 operand triples): the product's operands in the formula's order, then the addend's.
    IR_FMA,
    // A scatter (#1840): `a` the base address and `b` the index vector, as a gather's, and in the extra array at `c`
    // (ir_extra_value) the stored vector, then the mask of its lanes; its flags the lanes (i32 or i64) and its
    // alignment_log2 the scale's log2 (0 to 3). Lane i, where the mask's bit i is set, is written at a + sext(b's element
    // i) * scale, the lanes in order from lane 0, so that of two set lanes at one address the higher lane's bytes stay; a
    // clear lane writes nothing (vpscatterdd to vpscatterqq [a + zmm * scale]{k}, zmm). A store's effect, of any memory.
    IR_SCATTER,
    // A secondary result of an asm body (#2144): a is the body's IR_CALL, and b its register code (GPR 0..15,
    // XMM 16..31). The value is captured when the body finishes, together with the call's primary result, not when
    // this projection is visited. It stays after that call in the same block; each secondary register has at most
    // one projection. Ordinary value uses may read it in any block dominated by that definition.
    IR_ASM_RESULT,
    IR_OP_COUNT,
} IrOp;
static const uint8_t ir_operand_table[128] = {
[IR_CONST]=0,
[IR_UNDEF]=0,
[IR_PARAM]=0,
[IR_COPY]=1,
[IR_ADD]=3,
[IR_SUB]=3,
[IR_MUL]=3,
[IR_SDIV]=3,
[IR_UDIV]=3,
[IR_SREM]=3,
[IR_UREM]=3,
[IR_AND]=3,
[IR_OR]=3,
[IR_XOR]=3,
[IR_SHL]=3,
[IR_LSHR]=3,
[IR_ASHR]=3,
[IR_NEG]=1,
[IR_NOT]=1,
[IR_FADD]=3,
[IR_FSUB]=3,
[IR_FMUL]=3,
[IR_FDIV]=3,
[IR_FNEG]=1,
[IR_ICMP]=3,
[IR_FCMP]=3,
[IR_SELECT]=7,
[IR_TRUNC]=1,
[IR_ZEXT]=1,
[IR_SEXT]=1,
[IR_FTRUNC]=1,
[IR_FEXT]=1,
[IR_SITOFP]=1,
[IR_UITOFP]=1,
[IR_FPTOSI]=1,
[IR_FPTOUI]=1,
[IR_INTTOPTR]=1,
[IR_PTRTOINT]=1,
[IR_BITCAST]=1,
[IR_STACK_ADDR]=0,
[IR_SYMBOL_ADDR]=0,
[IR_ADDRESS]=1,
[IR_LOAD]=1,
[IR_STORE]=3,
[IR_CALL]=0,
[IR_CALL_INDIRECT]=1,
[IR_PHI]=0,
[IR_BR]=0,
[IR_CBR]=1,
[IR_SWITCH]=1,
[IR_RET]=0,
[IR_UNREACHABLE]=0,
[IR_ALLOCA]=1,
[IR_STACK_SAVE]=0,
[IR_STACK_RESTORE]=1,
[IR_BR_INDIRECT]=1,
[IR_VCONST]=0,
[IR_VCMP]=3,
[IR_VSELECT]=7,
[IR_LIFETIME]=0,
[IR_FENCE]=0,
[IR_INTRINSIC]=1,
[IR_ATOMIC_RMW]=3,
[IR_MASKED_LOAD]=7,
[IR_MASKED_STORE]=7,
[IR_COMPRESS_STORE]=7,
[IR_GATHER]=7,
[IR_FMA]=7,
[IR_SCATTER]=3,
[IR_ASM_RESULT]=1
};
static const uint8_t ir_optional_table[128] = {
[IR_ADDRESS]=2,
[IR_RET]=1,
[IR_CALL]=4,
[IR_CALL_INDIRECT]=4,
[IR_ATOMIC_RMW]=4,
[IR_INTRINSIC]=2
};
static const uint8_t ir_value_columns[128] = {
[IR_CONST]=0,
[IR_UNDEF]=0,
[IR_PARAM]=0,
[IR_COPY]=1,
[IR_ADD]=3,
[IR_SUB]=3,
[IR_MUL]=3,
[IR_SDIV]=3,
[IR_UDIV]=3,
[IR_SREM]=3,
[IR_UREM]=3,
[IR_AND]=3,
[IR_OR]=3,
[IR_XOR]=3,
[IR_SHL]=3,
[IR_LSHR]=3,
[IR_ASHR]=3,
[IR_NEG]=1,
[IR_NOT]=1,
[IR_FADD]=3,
[IR_FSUB]=3,
[IR_FMUL]=3,
[IR_FDIV]=3,
[IR_FNEG]=1,
[IR_ICMP]=3,
[IR_FCMP]=3,
[IR_SELECT]=7,
[IR_TRUNC]=1,
[IR_ZEXT]=1,
[IR_SEXT]=1,
[IR_FTRUNC]=1,
[IR_FEXT]=1,
[IR_SITOFP]=1,
[IR_UITOFP]=1,
[IR_FPTOSI]=1,
[IR_FPTOUI]=1,
[IR_INTTOPTR]=1,
[IR_PTRTOINT]=1,
[IR_BITCAST]=1,
[IR_STACK_ADDR]=0,
[IR_SYMBOL_ADDR]=0,
[IR_ADDRESS]=3,
[IR_LOAD]=1,
[IR_STORE]=3,
[IR_CALL]=132,
[IR_CALL_INDIRECT]=133,
[IR_PHI]=128,
[IR_BR]=0,
[IR_CBR]=1,
[IR_SWITCH]=1,
[IR_RET]=1,
[IR_UNREACHABLE]=0,
[IR_ALLOCA]=1,
[IR_STACK_SAVE]=0,
[IR_STACK_RESTORE]=1,
[IR_BR_INDIRECT]=1,
[IR_VCONST]=0,
[IR_VCMP]=3,
[IR_VSELECT]=7,
[IR_LIFETIME]=0,
[IR_FENCE]=0,
[IR_INTRINSIC]=3,
[IR_ATOMIC_RMW]=7,
[IR_MASKED_LOAD]=7,
[IR_MASKED_STORE]=7,
[IR_COMPRESS_STORE]=7,
[IR_GATHER]=7,
[IR_FMA]=7,
[IR_SCATTER]=131,
[IR_ASM_RESULT]=1
};
static __m512i ir_lookup_bytes(const uint8_t* table, __m128i op)
{
    return _mm512_cvtepu8_epi32(_mm512_castsi512_si128(_mm512_permutex2var_epi8(_mm512_loadu_si512(table), _mm512_zextsi128_si512(op), _mm512_loadu_si512(table + 64))));
}
static uint32_t ir_value_mask(const IrFunction* f, uint32_t i)
{
    const uint32_t op = f->op[i];
    uint32_t result = ir_operand_table[op];
    const uint32_t optional = ir_optional_table[op];
    if (optional != 0)
    {
        const uint32_t present = (uint32_t)(f->a[i] != BUSTER_IR_NONE) | (uint32_t)(f->b[i] != BUSTER_IR_NONE) << 1 | (uint32_t)(f->c[i] != BUSTER_IR_NONE) << 2;
        result |= optional & present;
    }
    return result;
}
