#include "extra-core.h"
typedef struct IrUnrollOperands IrUnrollOperands;
struct IrUnrollOperands
{
    __m512i a, b, c;
    __mmask16 use_a, use_b, use_c;
    __m128i classes;
};

// Copy the byte columns once and identify the value operands among these rows.
static inline __attribute__((always_inline)) IrUnrollOperands ir_unroll_load_operands(const IrFunction* f, uint32_t first, IrFunction* view, uint32_t out, __mmask16 active)
{
    const __m128i operations = _mm_maskz_loadu_epi8(active, f->op + first);
    _mm_mask_storeu_epi8(view->op + out, active, operations);
    _mm_mask_storeu_epi8(view->type + out, active, _mm_maskz_loadu_epi8(active, f->type + first));
    _mm_mask_storeu_epi8(view->flags + out, active, _mm_maskz_loadu_epi8(active, f->flags + first));
    _mm_mask_storeu_epi8(view->alignment_log2 + out, active, _mm_maskz_loadu_epi8(active, f->alignment_log2 + first));
    const __m128i operands = _mm512_castsi512_si128(_mm512_permutex2var_epi8(_mm512_loadu_si512(ir_value_columns), _mm512_zextsi128_si512(operations), _mm512_loadu_si512(ir_value_columns + 64)));
    const __m512i a = _mm512_maskz_loadu_epi32(active, f->a + first);
    const __m512i b = _mm512_maskz_loadu_epi32(active, f->b + first);
    const __m512i c = _mm512_maskz_loadu_epi32(active, f->c + first);
    // A checked fixed value operand always has an id. Optional operands can be absent.
    const __mmask16 use_a = active & _mm_test_epi8_mask(operands, _mm_set1_epi8(1)) & _mm512_cmpneq_epi32_mask(a, _mm512_set1_epi32(-1));
    const __mmask16 use_b = active & _mm_test_epi8_mask(operands, _mm_set1_epi8(2)) & _mm512_cmpneq_epi32_mask(b, _mm512_set1_epi32(-1));
    const __mmask16 use_c = active & _mm_test_epi8_mask(operands, _mm_set1_epi8(4)) & _mm512_cmpneq_epi32_mask(c, _mm512_set1_epi32(-1));
    return (IrUnrollOperands){ a, b, c, use_a, use_b, use_c, operands };
}

static inline __attribute__((always_inline)) __m512i ir_unroll_gather(__m512i values, __mmask16 mask, const uint32_t* middle, __m512i origin)
{
    return _mm512_mask_i32gather_epi32(values, mask, _mm512_sub_epi32(values, origin), middle, 4);
}

static inline __attribute__((always_inline)) void ir_unroll_store_operands(IrFunction* view, uint32_t out, __mmask16 active, __m512i a, __m512i b, __m512i c)
{
    _mm512_mask_storeu_epi32(view->a + out, active, a);
    _mm512_mask_storeu_epi32(view->b + out, active, b);
    _mm512_mask_storeu_epi32(view->c + out, active, c);
}

// The fixed operands of instructions [first, first + count) of `f`, through `map` where they are values, into `a`, `b`
// and `c` from `out`; their opcode, type, flags and alignment copied. Phis', calls' and extra values' operands, which
// the extra array holds, are the caller's. Return whether any opcode in the slice can own one of those lists.
bool measure_extra(const IrFunction* f, uint32_t first, uint32_t count, const uint32_t* map, IrFunction* view, uint32_t out)
{
    // Every valid unsigned id lies within a signed dword of the middle of its map.
    const uint32_t center = f->instruction_count / 2;
    const __m512i origin = _mm512_set1_epi32((int)center);
    const uint32_t* middle = map + center;
    __m128i classes = _mm_setzero_si128();
    uint64_t at = 0;
    for (; at + 16 <= count; at += 16)
    {
        const IrUnrollOperands rows = ir_unroll_load_operands(f, first + (uint32_t)at, view, out + (uint32_t)at, UINT16_MAX);
        classes = _mm_or_si128(classes, rows.classes);
        ir_unroll_store_operands(view, out + (uint32_t)at, UINT16_MAX, ir_unroll_gather(rows.a, rows.use_a, middle, origin),
                                 ir_unroll_gather(rows.b, rows.use_b, middle, origin), ir_unroll_gather(rows.c, rows.use_c, middle, origin));
    }
    if (at < count)
    {
        const __mmask16 active = (__mmask16)((1u << (count - (uint32_t)at)) - 1);
        const IrUnrollOperands rows = ir_unroll_load_operands(f, first + (uint32_t)at, view, out + (uint32_t)at, active);
        classes = _mm_or_si128(classes, rows.classes);
        __m512i gathered_a;
        __m512i gathered_b;
        __m512i gathered_c = rows.c;
        // A partial packet can combine columns whose active value lanes fit in five lanes per column, or eight lanes in each of the first two columns.
        if (((rows.use_a | rows.use_b | rows.use_c) & 0xffe0u) == 0)
        {
            const __m512i ab = _mm512_mask_alignr_epi32(rows.a, 0x03e0, rows.b, rows.b, 11);
            const __m512i abc = _mm512_mask_alignr_epi32(ab, 0x7c00, rows.c, rows.c, 6);
            const __mmask16 lanes_abc = rows.use_a | (unsigned)rows.use_b << 5 | (unsigned)rows.use_c << 10;
            const __m512i got = lanes_abc == 0 ? abc : ir_unroll_gather(abc, lanes_abc, middle, origin);
            gathered_a = _mm512_mask_mov_epi32(rows.a, 0x001f, got);
            gathered_b = _mm512_mask_alignr_epi32(rows.b, 0x001f, got, got, 5);
            gathered_c = _mm512_mask_alignr_epi32(rows.c, 0x001f, got, got, 9);
        }
        else if (((rows.use_a | rows.use_b) & 0xff00u) == 0)
        {
            const __m512i ab = _mm512_inserti64x4(rows.a, _mm512_castsi512_si256(rows.b), 1);
            const __mmask16 lanes_ab = (unsigned)rows.use_a | (unsigned)rows.use_b << 8;
            const __m512i got = ir_unroll_gather(ab, lanes_ab, middle, origin);
            gathered_a = _mm512_mask_mov_epi32(rows.a, 0xff, got);
            gathered_b = _mm512_inserti64x4(rows.b, _mm512_extracti64x4_epi64(got, 1), 0);
            if (rows.use_c != 0)
            {
                gathered_c = ir_unroll_gather(rows.c, rows.use_c, middle, origin);
            }
        }
        else
        {
            gathered_a = ir_unroll_gather(rows.a, rows.use_a, middle, origin);
            gathered_b = ir_unroll_gather(rows.b, rows.use_b, middle, origin);
            if (rows.use_c != 0)
            {
                gathered_c = ir_unroll_gather(rows.c, rows.use_c, middle, origin);
            }
        }
        ir_unroll_store_operands(view, out + (uint32_t)at, active, gathered_a, gathered_b, gathered_c);
    }
    return _mm_movemask_epi8(classes) != 0;
}
