#include "core.h"
bool measure_base(const IrFunction* f, uint32_t first, uint32_t count, const uint32_t* map, IrFunction* view, uint32_t out)
{
    memcpy(view->op + out, f->op + first, count);
    memcpy(view->type + out, f->type + first, count);
    memcpy(view->flags + out, f->flags + first, count);
    memcpy(view->alignment_log2 + out, f->alignment_log2 + first, count);
    if (f->instruction_count <= INT32_MAX)
    {
        const __m512i none = _mm512_set1_epi32(-1);
        const __m512i one = _mm512_set1_epi32(1);
        const __m512i two = _mm512_set1_epi32(2);
        const __m512i four = _mm512_set1_epi32(4);
        for (uint32_t at = 0; at < count; at += 16)
        {
            const uint32_t lanes = count - at < 16 ? count - at : 16;
            const __mmask16 active = (__mmask16)((1u << lanes) - 1u);
            const __m128i operations = _mm_maskz_loadu_epi8(active, f->op + first + at);
            const __m512i operands = ir_lookup_bytes(ir_operand_table, operations);
            const __m512i optional = ir_lookup_bytes(ir_optional_table, operations);
            const __m512i a = _mm512_maskz_loadu_epi32(active, f->a + first + at);
            const __m512i b = _mm512_maskz_loadu_epi32(active, f->b + first + at);
            const __m512i c = _mm512_maskz_loadu_epi32(active, f->c + first + at);
            // ir_value_mask: an opcode's operands, and its optional ones where they aren't BUSTER_IR_NONE.
            const __mmask16 use_a = active & (_mm512_test_epi32_mask(operands, one) | (_mm512_test_epi32_mask(optional, one) & _mm512_cmpneq_epi32_mask(a, none)));
            const __mmask16 use_b = active & (_mm512_test_epi32_mask(operands, two) | (_mm512_test_epi32_mask(optional, two) & _mm512_cmpneq_epi32_mask(b, none)));
            const __mmask16 use_c = active & (_mm512_test_epi32_mask(operands, four) | (_mm512_test_epi32_mask(optional, four) & _mm512_cmpneq_epi32_mask(c, none)));
            _mm512_mask_storeu_epi32(view->a + out + at, active, _mm512_mask_i32gather_epi32(a, use_a, a, map, 4));
            _mm512_mask_storeu_epi32(view->b + out + at, active, _mm512_mask_i32gather_epi32(b, use_b, b, map, 4));
            _mm512_mask_storeu_epi32(view->c + out + at, active, _mm512_mask_i32gather_epi32(c, use_c, c, map, 4));
        }
    }
    else
    {
        for (uint32_t k = 0; k < count; k += 1)
        {
            const uint32_t i = first + k;
            const uint32_t mask = ir_value_mask(f, i);
            view->a[out + k] = (mask & 1) != 0 ? map[f->a[i]] : f->a[i];
            view->b[out + k] = (mask & 2) != 0 ? map[f->b[i]] : f->b[i];
            view->c[out + k] = (mask & 4) != 0 ? map[f->c[i]] : f->c[i];
        }
    }
    return false;
}
