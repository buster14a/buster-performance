#include "buster/compiler/main_unit_backend.c"
bool measure_directtail(const IrFunction* f, uint32_t first, uint32_t count, const uint32_t* map, IrFunction* view, uint32_t out)
{
    return ir_unroll_remap(f, first, count, map, view, out);
}
