from pathlib import Path
from statistics import median
import importlib.util,tarfile
p=Path(__file__).parent
sp=importlib.util.spec_from_file_location('extra',p/'record-extra.py');extra=importlib.util.module_from_spec(sp);sp.loader.exec_module(extra)
d=extra.d;r=p/'shortquarter-results';o=p/'quarters-object-results';m=p/'slim-results'
matrix={}
for seed in (1,133,789):
    assert 'validated 90 lengths' in (m/f'slim-{seed}.log').read_text()
    for line in (m/f'slim-{seed}.tsv').read_text().splitlines():
        w,s,n,reps,base,*heads=map(int,line.split());assert len(heads)==4 and min(reps,base,*heads)>0
        matrix.setdefault((w,s,n),[]).append([x/base for x in heads])
assert len(matrix)==720 and all(len(v)==3 for v in matrix.values())
cells=[]
for j,k in enumerate(['Remap with extra-operand detection','Four-lane stores through length four','Store columns directly for short tails','Group two operand columns']):
    vs=[median(x[j] for x in rounds)for rounds in matrix.values()]
    cells.append(f'| {k} | {sum(v<=1 for v in vs)}/720 | {median(vs):.4f} | {max(vs):.4f} |')
for key,total in [('ir-unroll',5962),('ir-optimize',358076),('ir-store-motion',394)]:
    assert f'{total} checks, 0 failures' in (r/f'shortquarter-test-{key}.log').read_text()
corpus=[]
for g,n in [('lua',34),('sqlite',1),('musl',1336)]:
    assert (r/f'shortquarter-passes-{g}-head.log').read_bytes()==(r/f'shortquarter-passes-{g}-base.log').read_bytes()
    row=[g,extra.change(r/f'shortquarter-cycles-{g}.log')]
    for t in ('tier0','tier1'):
        a,b=[(o/f'quarters-objects-{t}-{g}-{k}.sha').read_bytes()for k in ('base','quarters')]
        assert a==b and len(a.splitlines())==n+2
        row.append(extra.change(o/f'quarters-compile-{t}-{g}.log'))
    corpus.append('| '+' | '.join(row)+' |')
name='ir-short-tail-and-objects.tar.xz'
with tarfile.open(d/name,'w:xz')as t:
    for sub in [r,o,m]:
        for f in sub.iterdir():t.add(f,arcname=sub.name+'/'+f.name)
    for n in ['slim','slim.py','record-slim.py','shortquarter-task','shortquarter-corpus','quarters-objects','record-extra.py']:t.add(p/n,arcname='source/'+n)
f=d/'README.md';s=f.read_text();title='## Limiting the short operand store to four instructions';assert title not in s
f.write_text(s.rstrip()+'\n\n'+title+'''

All methods used the actual IR translation units, two map extents, four opcode distributions and 90 lengths. Each cell is the median paired ratio across three seeds. The four-lane form passed all 720 combinations and all three native suites. Its complete optimizer reports matched byte for byte.

| Method | Cells meeting parent | Median ratio | Slowest ratio |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(cells)+'''

The first timing column measures the four-lane form in the complete pass driver. The last two columns measure the preceding quarter-store implementation in complete compilations across five paired rounds. Both compilers ran from the same directory and produced identical debug objects, standard output and diagnostics on all 1,371 translation units in each tier.

| Corpus | Short form pass driver | Preceding quarter stores, Tier 0 | Preceding quarter stores, Tier 1 |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(corpus)+f'\n\n[All samples, report and object comparisons, sources and suites]({name})\n')
print(*cells,*corpus,sep='\n')
