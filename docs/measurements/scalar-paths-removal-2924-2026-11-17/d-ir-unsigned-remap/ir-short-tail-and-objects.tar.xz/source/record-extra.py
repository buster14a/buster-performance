from pathlib import Path
from statistics import median
import re,tarfile
p=Path(__file__).parent
r=p/'extra-results'
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-ir-unsigned-remap')
def site(prefix,log):
    result={}
    for seed in (1,133,789):
        assert 'validated 90 lengths, 4 opcode distributions and both map extents' in (r/(log.format(seed))).read_text()
        lines=(r/prefix.format(seed)).read_text().splitlines()
        assert len(lines)==720
        for ln in lines:
            wide,shape,n,reps,base,head=map(int,ln.split())
            assert min(reps,base,head)>0
            result.setdefault((wide,shape,n),[]).append(head/base)
    assert len(result)==720 and all(len(v)==3 for v in result.values())
    return {k:median(v) for k,v in result.items()}
def change(file):
    s=file.read_text()
    assert s.rstrip().endswith('ab: done, 0 failed runs')
    rounds=[]
    for block in s.split('time-runs: done, 0 failed processes')[:-1]:
        t={k:int(c)for k,c in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',block,re.M)}
        assert len(t)==2 and min(t.values())>0
        rounds.append(t['head']/t['base'])
    assert len(rounds)==5
    return f'{(median(rounds)-1)*100:+.3f}%'
def writeup():
    reduced=site('extra-time-{}.tsv','extra-check-{}.log')
    actual=site('abi/exact-{}.tsv','abi/exact-{}.log')
    assert reduced.keys()==actual.keys()
    for suite,total in [('ir-unroll',5962),('ir-optimize',358076),('ir-store-motion',394)]:
        assert f'{total} checks, 0 failures' in (r/f'extra-test-{suite}.log').read_text()
    faults=sorted((r/'extra-proof-work').glob('*.status'))
    assert len(faults)==15
    for f in faults:
        code=int(f.read_text())
        assert code==(0 if f.stem=='measure-extra' else 139 if f.stem in ('mut-absent-value','mut-literal-as-value','mut-signed-index') else 1)
    assert 'validated 90 lengths' in (r/'abi/verify.log').read_text()
    rows=[]
    for source,vs in [('Reduced fixture layout',reduced),('Compiler translation units',actual)]:
        for width in [0,1]:
            ratios=[v for (w,_,_),v in vs.items() if w==width]
            rows.append(f'| {source} | {("Narrow","Full unsigned")[width]} | {sum(x<=1 for x in ratios)}/{len(ratios)} | {median(ratios):.4f} | {max(ratios):.4f} |')
    comp=[]
    for group,n in [('lua',34),('sqlite',1),('musl',1336)]:
        assert (r/f'extra-passes-{group}-base.log').read_bytes()==(r/f'extra-passes-{group}-head.log').read_bytes()
        for tier in ('tier0','tier1'):
            b,h=[(r/f'extra-objects-{tier}-{group}-{k}.sha').read_bytes() for k in ('base','extra')]
            assert b==h and len(b.splitlines())==n+2
        comp.append('| '+' | '.join([group,str(n),*[change(r/f'extra-{a}-{group}.log') for a in ('cycles','compile-tier0','compile-tier1')]])+' |')
    with tarfile.open(d/'ir-range-extra-owners.tar.xz','w:xz')as t:
        for f in r.rglob('*'):
            if f.is_file():t.add(f,arcname='native/'+str(f.relative_to(r)))
        for n in ('contiguous-base.patch','contiguous-delta.patch','extra-facts.patch','extra-task','extra-objects','extra-corpus','gate-extra.c','extra-core.h','measure-base.c','measure-extra.c','verify-extra.c','extra-proof-task','extra-faults','abi'):
            f=p/n
            t.add(f,arcname='source/'+n)
    heading='## Copying adjacent ranges and identifying rows that own extra operands'
    f=d/'README.md';s=f.read_text();assert heading not in s
    f.write_text(s.rstrip()+'\n\n'+heading+'''

The remap combines an instruction range and its terminator when their output positions are adjacent. The opcode lookup also reports whether a range contains an instruction with a separate operand list. The caller can skip its second scan when the range has none. The guarded fixtures cover all five owning opcodes, ordinary arithmetic, absent operands and padding. They rejected 14 deliberate changes.

The second timing harness compiles both implementations from their full compiler translation units, including the actual IrFunction layout and opcode tables. Each harness compares 90 lengths, four opcode distributions and two map extents. Each cell is the median paired ratio over three seeds.

| Timing harness | Map | Cells meeting baseline | Median ratio | Slowest ratio |
| --- | --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

The native unroll, optimizer and store-motion suites passed 5,962, 358,076 and 394 checks. Each pair of complete pass reports matched byte for byte. Both tiers produced the same debug objects, standard output and diagnostics. The timing columns give median paired user-cycle changes across five rounds with three fresh processes per executable.

| Corpus | Objects per tier | Optimizer pass driver | Tier 0 compile | Tier 1 compile |
| --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(comp)+'''

[Source, both per-size sweeps, guarded oracle, mutations, pass reports, object hashes and process logs](ir-range-extra-owners.tar.xz)
''')
    print(*rows,*comp,sep='\n')
if __name__=='__main__':writeup()
