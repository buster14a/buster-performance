from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent;r=p/'slim';r.mkdir(exist_ok=True)
f='buster/compiler/ir_optimize_unroll.c'
extra=(p/'tree/src'/f).read_text()
q=(p/'quarters/quarter'/f).read_text()
a=q.index('        // A partial packet can combine columns');b=q.index('        else if (((rows.use_a | rows.use_b) & 0xff00u) == 0)',a)
q=q[:a]+q[b:].replace('        else if (','        if (',1)
for name in ('shortquarter','directtail','halfpair'):
 if name=='shortquarter':s=q
 elif name=='directtail':
  a=q.index('        if (((rows.use_a | rows.use_b) & 0xff00u) == 0)');b=q.index('        ir_unroll_store_operands(view, out + (uint32_t)at, active',a)
  s=q[:a]+'''        gathered_a = ir_unroll_gather(rows.a, rows.use_a, middle, origin);
        gathered_b = ir_unroll_gather(rows.b, rows.use_b, middle, origin);
        if (rows.use_c != 0)
        {
            gathered_c = ir_unroll_gather(rows.c, rows.use_c, middle, origin);
        }
'''+q[b:]
 else:
  a=extra.index('        // A partial packet can combine columns');b=extra.index('        else if (((rows.use_a | rows.use_b) & 0xff00u) == 0)',a)
  s=extra[:a]+extra[b:].replace('        else if (','        if (',1)
 out=r/name/f;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s)
 (r/(name+'.patch')).write_text(''.join(unified_diff(extra.splitlines(True),s.splitlines(True),'a/src/'+f,'b/src/'+f)))
 (r/(name+'.c')).write_text((p/'abi/extra.c').read_text().replace('measure_extra','measure_'+name))
s=(p/'quarters/gate.c').read_text().replace('measure_quarter,measure_packedclasses,measure_emptythird','measure_shortquarter,measure_directtail,measure_halfpair')
(r/'gate.c').write_text(s)
s=(p/'quarters/task').read_text().replace('/quarters','/slim').replace('quarter packedclasses emptythird','shortquarter directtail halfpair').replace('quarters-','slim-').replace('Compare narrow vector stores and operand-mask generation in an integrated IR remap','Compare simpler vector-tail layouts in the full IR translation units')
s=s.replace('cc=$(find','mkdir -p temp\nexport TMPDIR="$PWD/temp"\ncc=$(find')
(r/'task').write_text(s)
