#include "core.h"
void tile(const IrFunction* f, uint32_t first, uint32_t count, const uint32_t* map, IrFunction* view, uint32_t out)
{
    // Every uint32_t value index is within a signed dword of the middle of the map.
    const uint32_t center = f->instruction_count / 2;
    const __m512i origin = _mm512_set1_epi32((int)center);
    for (uint64_t at = 0; at < count; at += 4)
    {
        const uint32_t lanes = count - at < 4 ? (uint32_t)(count - at) : 4;
        const __mmask16 active = (__mmask16)((1u << lanes) - 1u);
        const __m128i operations = _mm_maskz_loadu_epi8(active, f->op + first + at);
        _mm_mask_storeu_epi8(view->op + out + at, active, operations);
        _mm_mask_storeu_epi8(view->type + out + at, active, _mm_maskz_loadu_epi8(active, f->type + first + at));
        _mm_mask_storeu_epi8(view->flags + out + at, active, _mm_maskz_loadu_epi8(active, f->flags + first + at));
        _mm_mask_storeu_epi8(view->alignment_log2 + out + at, active, _mm_maskz_loadu_epi8(active, f->alignment_log2 + first + at));

        const __m512i uses = _mm512_broadcast_i32x4(_mm512_castsi512_si128(ir_lookup_bytes(ir_value_columns, operations)));
        const __m512i column_bits = _mm512_setr_epi32(1,1,1,1,2,2,2,2,4,4,4,4,0,0,0,0);
        const __m128i a = _mm_maskz_loadu_epi32(active, f->a + first + at);
        const __m128i b = _mm_maskz_loadu_epi32(active, f->b + first + at);
        const __m128i c = _mm_maskz_loadu_epi32(active, f->c + first + at);
        const __m512i rows = _mm512_inserti32x4(_mm512_inserti32x4(_mm512_zextsi128_si512(a), b, 1), c, 2);
        const __mmask16 use = _mm512_test_epi32_mask(uses, column_bits) & _mm512_cmpneq_epi32_mask(rows, _mm512_set1_epi32(-1));
        const __m512i result = _mm512_mask_i32gather_epi32(rows, use, _mm512_sub_epi32(rows, origin), map + center, 4);
        _mm_mask_storeu_epi32(view->a + out + at, active, _mm512_castsi512_si128(result));
        _mm_mask_storeu_epi32(view->b + out + at, active, _mm512_extracti32x4_epi32(result, 1));
        _mm_mask_storeu_epi32(view->c + out + at, active, _mm512_extracti32x4_epi32(result, 2));
    }
}
