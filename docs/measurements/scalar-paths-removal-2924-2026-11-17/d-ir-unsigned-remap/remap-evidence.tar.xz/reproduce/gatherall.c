#include "core.h"
void gatherall(const IrFunction* f, uint32_t first, uint32_t count, const uint32_t* map, IrFunction* view, uint32_t out)
{
    // Every uint32_t value index is within a signed dword of the middle of the map.
    const uint32_t center = f->instruction_count / 2;
    const __m512i origin = _mm512_set1_epi32((int)center);
    const __m512i none = _mm512_set1_epi32(-1);
    const __m512i one = _mm512_set1_epi32(1);
    const __m512i two = _mm512_set1_epi32(2);
    const __m512i four = _mm512_set1_epi32(4);
    for (uint64_t at = 0; at < count; at += 16)
    {
        const uint32_t lanes = count - at < 16 ? (uint32_t)(count - at) : 16;
        const __mmask16 active = (__mmask16)((1u << lanes) - 1u);
        const __m128i operations = _mm_maskz_loadu_epi8(active, f->op + first + at);
        _mm_mask_storeu_epi8(view->op + out + at, active, operations);
        _mm_mask_storeu_epi8(view->type + out + at, active, _mm_maskz_loadu_epi8(active, f->type + first + at));
        _mm_mask_storeu_epi8(view->flags + out + at, active, _mm_maskz_loadu_epi8(active, f->flags + first + at));
        _mm_mask_storeu_epi8(view->alignment_log2 + out + at, active, _mm_maskz_loadu_epi8(active, f->alignment_log2 + first + at));
        const __m512i operands = ir_lookup_bytes(ir_value_columns, operations);
        const __m512i a = _mm512_maskz_loadu_epi32(active, f->a + first + at);
        const __m512i b = _mm512_maskz_loadu_epi32(active, f->b + first + at);
        const __m512i c = _mm512_maskz_loadu_epi32(active, f->c + first + at);
        // ir_value_mask: an opcode's operands, and its optional ones where they aren't BUSTER_IR_NONE.
        const __mmask16 use_a = active & _mm512_test_epi32_mask(operands, one) & _mm512_cmpneq_epi32_mask(a, none);
        const __mmask16 use_b = active & _mm512_test_epi32_mask(operands, two) & _mm512_cmpneq_epi32_mask(b, none);
        const __mmask16 use_c = active & _mm512_test_epi32_mask(operands, four) & _mm512_cmpneq_epi32_mask(c, none);
        uint32_t packed[48] __attribute__((aligned(64)));
        const uint32_t na = __builtin_popcount(use_a), nb = __builtin_popcount(use_b);
        const uint32_t count_values = na + nb + __builtin_popcount(use_c);
        _mm512_mask_compressstoreu_epi32(packed, use_a, a);
        _mm512_mask_compressstoreu_epi32(packed + na, use_b, b);
        _mm512_mask_compressstoreu_epi32(packed + na + nb, use_c, c);
        for (uint32_t slot = 0; slot < count_values; slot += 16)
        {
            const __mmask16 mask = (__mmask16)_bzhi_u32(65535u, count_values - slot);
            const __m512i ids = _mm512_maskz_loadu_epi32(mask, packed + slot);
            const __m512i values = _mm512_mask_i32gather_epi32(ids, mask, _mm512_sub_epi32(ids, origin), map + center, 4);
            _mm512_mask_storeu_epi32(packed + slot, mask, values);
        }
        _mm512_mask_storeu_epi32(view->a + out + at, active, _mm512_mask_expandloadu_epi32(a, use_a, packed));
        _mm512_mask_storeu_epi32(view->b + out + at, active, _mm512_mask_expandloadu_epi32(b, use_b, packed + na));
        _mm512_mask_storeu_epi32(view->c + out + at, active, _mm512_mask_expandloadu_epi32(c, use_c, packed + na + nb));
    }
}
