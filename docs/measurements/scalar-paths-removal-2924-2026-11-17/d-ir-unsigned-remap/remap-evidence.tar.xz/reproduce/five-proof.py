from pathlib import Path
p=Path(__file__).parent
s=(p/'tree/src/buster/compiler/ir_optimize_unroll.c').read_text()
s='#include "core.h"\n'+s[s.index('typedef struct IrUnrollOperands'):s.index("// The rewrite's state")].rstrip()+'\n'
s=s.replace('static void ir_unroll_remap(', 'void checkfive(')
(p/'exactfive.c').write_text(s)
mutations={'signed-index':('const uint32_t center = f->instruction_count / 2;','const uint32_t center = 0;'),
 'missing-last-optional':('active & _mm_test_epi8_mask(operands, _mm_set1_epi8(4))','(active & 0x7fffu) & _mm_test_epi8_mask(operands, _mm_set1_epi8(4))'),
 'literal-as-value':('active & _mm_test_epi8_mask(operands, _mm_set1_epi8(2))','active'),
 'absent-value':(' & _mm512_cmpneq_epi32_mask(b, _mm512_set1_epi32(-1))',''),
 'packed-five-mask':('0x03e0, rows.b','0x01e0, rows.b'),
 'packed-c-offset':('got, got, 10);','got, got, 9);'),
 'metadata':('view->alignment_log2 + out, active, _mm_maskz_loadu_epi8(active, f->alignment_log2','view->alignment_log2 + out, active, _mm_maskz_loadu_epi8(active, f->flags'),
 'eight-column-order':('_mm512_extracti64x4_epi64(got, 1)','_mm512_extracti64x4_epi64(got, 0)')}
for name,(a,b) in mutations.items():
 assert s.count(a)==1,(name,s.count(a));(p/f'mut-{name}.c').write_text(s.replace(a,b))
g=(p/'gate-five.c').read_text().replace('Remap base,five,fiverot,fiveskip,fivefour,fivejoin;', 'Remap checkfive;').replace('Remap* impl[]={base,five,fiverot,fiveskip,fivefour,fivejoin};','').replace('for(unsigned j=0;j<6;j++){','for(unsigned j=0;j<1;j++){',1).replace('impl[j](&src','checkfive(&src')
a=g.index('    unsigned reps=');b=g.index('\n   }',a);(p/'verify-five.c').write_text(g[:a]+g[b:])
