#include "core.h"
#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
typedef void Remap(const IrFunction*,uint32_t,uint32_t,const uint32_t*,IrFunction*,uint32_t);
Remap base,rem,remx,remall,maskpack,maskany;
static uint32_t state=3449;
static uint32_t random32(void){state=1664525*state+1013904223;return state;}
enum { N=8256, S=9 };
static uint32_t ids[8]={0,1,2048,0x7ffffff0u,0x7fffffffu,0x80000000u,0x80000035u,0xfffffffeu};
static IrFunction columns(unsigned count){
 IrFunction v={.instruction_count=count};
 v.op=calloc(N,1);v.type=calloc(N,1);v.flags=calloc(N,1);v.alignment_log2=calloc(N,1);v.a=calloc(N,4);v.b=calloc(N,4);v.c=calloc(N,4);return v;
}
static inline uint64_t ticks(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int cmp64(const void*l,const void*r){uint64_t a=*(const uint64_t*)l,b=*(const uint64_t*)r;return (a>b)-(a<b);}
static const uint8_t operations[3][8]={{IR_ADD,IR_FMA,IR_CALL,IR_ADDRESS,IR_CONST,IR_RET,IR_PHI,IR_CBR},{IR_ADD,IR_SUB,IR_LOAD,IR_STORE,IR_MUL,IR_TRUNC,IR_SELECT,IR_FMA},{IR_BR,IR_PHI,IR_CONST,IR_UNDEF,IR_PARAM,IR_FENCE,IR_UNREACHABLE,IR_SYMBOL_ADDR}};
static void populate(IrFunction* f,unsigned wide,unsigned shape){
 uint32_t* cols[]={f->a,f->b,f->c};
 for(unsigned n=0;n<N;n++){
  uint8_t op=shape<3?operations[shape][random32()>>29]:1+(random32()>>8)%(IR_OP_COUNT-1);f->op[n]=op;
  f->type[n]=random32()>>24;f->flags[n]=random32()>>24;f->alignment_log2[n]=random32()>>24;
  for(unsigned c=0;c<3;c++){unsigned bits=ir_operand_table[op]|ir_optional_table[op];uint32_t r=random32();
   cols[c][n]=!(bits&(1<<c))?r:((ir_optional_table[op]&(1<<c))&&(r&256))?UINT32_MAX:ids[(r>>29)&(wide?7:1)];}
 }
}
int main(int argc,char**argv){
 if(argc>1)state=(unsigned)strtoul(argv[1],0,10);
 long pg=sysconf(_SC_PAGESIZE);
 uint32_t* map=mmap(NULL,(uint64_t)UINT32_MAX*4,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_NORESERVE,-1,0);if(map==MAP_FAILED)return 2;
 for(unsigned i=0;i<8;i++){if(mprotect((void*)((uintptr_t)(map+ids[i])&-(uintptr_t)pg),pg,PROT_READ|PROT_WRITE))return 2;map[ids[i]]=ids[i]^0x35aa55c3;}
 Remap* impl[]={base,rem,remx,remall,maskpack,maskany};unsigned sizes[128],ns=0;
 for(unsigned n=0;n<=65;n++)sizes[ns++]=n;
 const unsigned more[]={79,80,81,95,96,97,127,128,129,191,192,193,255,256,257,511,512,513,1023,1024,1025,2048,4096,8192};
 for(unsigned i=0;i<sizeof(more)/sizeof(*more);i++)sizes[ns++]=more[i];
 IrFunction src=columns(0),dst=columns(0),ref=columns(0);
 for(unsigned wide=0;wide<2;wide++){src.instruction_count=wide?UINT32_MAX:N;
  for(unsigned shape=0;shape<4;shape++){populate(&src,wide,shape);
   for(unsigned si=0;si<ns;si++){unsigned n=sizes[si],first=3,out=5;
    for(unsigned j=0;j<6;j++){
     memset(dst.a,0xaa,N*4);memset(dst.b,0xaa,N*4);memset(dst.c,0xaa,N*4);memset(dst.op,0xaa,N);memset(dst.type,0xaa,N);memset(dst.flags,0xaa,N);memset(dst.alignment_log2,0xaa,N);
     impl[j](&src,first,n,map,&dst,out);
     for(unsigned row=0;row<N;row++){
      bool live=row>=out&&row<out+n;unsigned k=live?first+row-out:0;uint32_t* a[]={src.a,src.b,src.c};uint32_t* d[]={dst.a,dst.b,dst.c};
      unsigned use=ir_value_mask(&src,k);
      for(unsigned c=0;c<3;c++){uint32_t v=!live?0xaaaaaaaau:(use&(1<<c))?a[c][k]^0x35aa55c3:a[c][k];if(d[c][row]!=v)return fprintf(stderr,"operand mismatch %u %u %u %u %u\n",j,n,shape,row,c),1;}
      if(dst.op[row]!=(live?src.op[k]:0xaa)||dst.type[row]!=(live?src.type[k]:0xaa)||dst.flags[row]!=(live?src.flags[k]:0xaa)||dst.alignment_log2[row]!=(live?src.alignment_log2[k]:0xaa))return 1;
     }
    }
    unsigned reps=1024/(1+n/8)+4;uint64_t times[6][S];
    for(unsigned r=0;r<S;r++){unsigned off=random32()%6;for(unsigned l=0;l<6;l++){unsigned j=(r&1)?(off+l)%6:(off+6-l)%6;Remap* fn=impl[j];uint64_t t=ticks();for(unsigned x=0;x<reps;x++)fn(&src,first,n,map,&ref,out);times[j][r]=ticks()-t;}}
    printf("%u %u %u %u",wide,shape,n,reps);for(unsigned j=0;j<6;j++){qsort(times[j],S,8,cmp64);printf(" %llu",(unsigned long long)times[j][S/2]);}puts("");
   }
  }
 }
 fprintf(stderr,"validated %u lengths, 4 opcode distributions and both map extents\n",ns);
}
