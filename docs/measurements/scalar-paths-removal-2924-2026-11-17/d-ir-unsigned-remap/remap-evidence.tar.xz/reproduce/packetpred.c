#include "core.h"
static inline __attribute__((always_inline)) void remap_packet(const IrFunction* f, uint32_t first, IrFunction* view, uint32_t out, __mmask16 active,
                                                            const uint32_t* map, __m512i origin, __m512i low, __m512i high)
{
    const __m128i operations = _mm_maskz_loadu_epi8(active, f->op + first);
    _mm_mask_storeu_epi8(view->op + out, active, operations);
    _mm_mask_storeu_epi8(view->type + out, active, _mm_maskz_loadu_epi8(active, f->type + first));
    _mm_mask_storeu_epi8(view->flags + out, active, _mm_maskz_loadu_epi8(active, f->flags + first));
    _mm_mask_storeu_epi8(view->alignment_log2 + out, active, _mm_maskz_loadu_epi8(active, f->alignment_log2 + first));
    const __m128i operands = _mm512_castsi512_si128(_mm512_permutex2var_epi8(low, _mm512_zextsi128_si512(operations), high));
    const __m512i a = _mm512_maskz_loadu_epi32(active, f->a + first);
    const __m512i b = _mm512_maskz_loadu_epi32(active, f->b + first);
    const __m512i c = _mm512_maskz_loadu_epi32(active, f->c + first);
    // ir_value_mask: an opcode's operands, and its optional ones where they aren't BUSTER_IR_NONE.
    const __mmask16 use_a = active & _mm_test_epi8_mask(operands, _mm_set1_epi8(1)) & _mm512_cmpneq_epi32_mask(a, _mm512_set1_epi32(-1));
    const __mmask16 use_b = active & _mm_test_epi8_mask(operands, _mm_set1_epi8(2)) & _mm512_cmpneq_epi32_mask(b, _mm512_set1_epi32(-1));
    const __mmask16 use_c = active & _mm_test_epi8_mask(operands, _mm_set1_epi8(4)) & _mm512_cmpneq_epi32_mask(c, _mm512_set1_epi32(-1));
    __m512i gathered_a = a, gathered_b = b, gathered_c = c;
    if (active != UINT16_MAX && ((use_a | use_b | use_c) & 0xfff0u) == 0)
    {
        const __m512i abc = _mm512_inserti32x4(_mm512_inserti32x4(a, _mm512_castsi512_si128(b), 1), _mm512_castsi512_si128(c), 2);
        const __mmask16 all = use_a | (unsigned)use_b << 4 | (unsigned)use_c << 8;
        const __m512i got = all == 0 ? abc : _mm512_mask_i32gather_epi32(abc, all, _mm512_sub_epi32(abc, origin), map, 4);
        gathered_a = _mm512_inserti32x4(a, _mm512_castsi512_si128(got), 0);
        gathered_b = _mm512_inserti32x4(b, _mm512_extracti32x4_epi32(got, 1), 0);
        gathered_c = _mm512_inserti32x4(c, _mm512_extracti32x4_epi32(got, 2), 0);
    }
    else
    {
        if (active != UINT16_MAX && ((use_a | use_b) & 0xff00u) == 0)
        {
            const __m512i ab = _mm512_inserti64x4(a, _mm512_castsi512_si256(b), 1);
            const __mmask16 lanes_ab = (unsigned)use_a | (unsigned)use_b << 8;
            const __m512i got = _mm512_mask_i32gather_epi32(ab, lanes_ab, _mm512_sub_epi32(ab, origin), map, 4);
            gathered_a = _mm512_mask_mov_epi32(a, 0xff, got);
            gathered_b = _mm512_inserti64x4(b, _mm512_extracti64x4_epi64(got, 1), 0);
        }
        else
        {
            gathered_a = _mm512_mask_i32gather_epi32(a, use_a, _mm512_sub_epi32(a, origin), map, 4);
            gathered_b = _mm512_mask_i32gather_epi32(b, use_b, _mm512_sub_epi32(b, origin), map, 4);
        }
        if (active == UINT16_MAX || use_c != 0)
        {
            gathered_c = _mm512_mask_i32gather_epi32(c, use_c, _mm512_sub_epi32(c, origin), map, 4);
        }
    }
    _mm512_mask_storeu_epi32(view->a + out, active, gathered_a);
    _mm512_mask_storeu_epi32(view->b + out, active, gathered_b);
    _mm512_mask_storeu_epi32(view->c + out, active, gathered_c);
}
void packetpred(const IrFunction* f, uint32_t first, uint32_t count, const uint32_t* map, IrFunction* view, uint32_t out)
{
    const uint32_t center = f->instruction_count / 2;
    const __m512i origin = _mm512_set1_epi32((int)center);
    const __m512i low = _mm512_or_si512(_mm512_loadu_si512(ir_operand_table), _mm512_loadu_si512(ir_optional_table));
    const __m512i high = _mm512_or_si512(_mm512_loadu_si512(ir_operand_table + 64), _mm512_loadu_si512(ir_optional_table + 64));
    uint64_t at = 0;
    for (; at + 16 <= count; at += 16)
    {
        remap_packet(f, first + (uint32_t)at, view, out + (uint32_t)at, UINT16_MAX, map + center, origin, low, high);
    }
    if (at < count)
    {
        const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, count - (uint32_t)at);
        remap_packet(f, first + (uint32_t)at, view, out + (uint32_t)at, active, map + center, origin, low, high);
    }
}
