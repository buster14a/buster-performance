from pathlib import Path
p=Path('src/buster/compiler/ir_optimize_unroll.c')
s=p.read_text(); pos=s.index('static void ir_unroll_remap(');op=s.index('\n{',pos)+2
c='''static uint64_t unroll_calls, unroll_wide, unroll_rows, unroll_hist[18], unroll_ops[128];
static uint32_t unroll_largest;
__attribute__((destructor)) static void unroll_range_report(void)
{
    if (unroll_calls) {
        fprintf(stderr,"unroll-range calls=%llu wide=%llu rows=%llu largest=%u bins=", (unsigned long long)unroll_calls, (unsigned long long)unroll_wide, (unsigned long long)unroll_rows, unroll_largest);
        for(unsigned i=0;i<18;i++)fprintf(stderr,"%llu,", (unsigned long long)unroll_hist[i]);
        fprintf(stderr," ops=");
        for(unsigned i=0;i<128;i++)if(unroll_ops[i])fprintf(stderr,"%u/%llu,",i,(unsigned long long)unroll_ops[i]);
        fputc('\\n',stderr);
    }
}
'''
p.write_text(s[:pos]+c+s[pos:op]+'''
    unroll_calls++;
    unroll_wide += f->instruction_count > INT32_MAX;
    unroll_rows += count;
    unroll_hist[count<=16?count:17]++;
    if(f->instruction_count>unroll_largest)unroll_largest=f->instruction_count;
    for(uint32_t k=0;k<count;k++)unroll_ops[f->op[first+k]]++;
'''+s[op:])
