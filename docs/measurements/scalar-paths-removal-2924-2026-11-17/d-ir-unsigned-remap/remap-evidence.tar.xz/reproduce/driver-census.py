from pathlib import Path
p=Path('src/buster/compiler/ir_optimize_unroll.c')
s=p.read_text();pos=s.index('static void ir_unroll_remap(');op=s.index('\n{',pos)+2
setup='''#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
static uint64_t* ir_range_counts;
__attribute__((constructor)) static void ir_census_attach(void)
{
    const char* path = getenv("BUSTER_IR_REMAP_COUNTS");
    if (path != NULL)
    {
        const int fd = open(path, O_RDWR | O_CLOEXEC);
        if (fd >= 0)
        {
            void* ptr = mmap(NULL, 32, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
            if (ptr != MAP_FAILED) ir_range_counts = ptr;
            close(fd);
        }
    }
}
'''
part='''
    if (ir_range_counts != NULL)
    {
        __atomic_fetch_add(ir_range_counts, 1, __ATOMIC_RELAXED);
        __atomic_fetch_add(ir_range_counts + 1, f->instruction_count > INT32_MAX, __ATOMIC_RELAXED);
        __atomic_fetch_add(ir_range_counts + 2, count, __ATOMIC_RELAXED);
        uint64_t old = __atomic_load_n(ir_range_counts + 3, __ATOMIC_RELAXED);
        while (old < f->instruction_count && !__atomic_compare_exchange_n(ir_range_counts + 3, &old, f->instruction_count, 0, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
    }
'''
p.write_text(s[:pos]+setup+s[pos:op]+part+s[op:])
