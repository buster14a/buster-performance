#include "core.h"
void stripe(const IrFunction* f, uint32_t first, uint32_t count, const uint32_t* map, IrFunction* view, uint32_t out)
{
    // Every uint32_t value index is within a signed dword of the middle of the map.
    const uint32_t center = f->instruction_count / 2;
    const __m512i origin = _mm512_set1_epi32((int)center);
    const __m512i none = _mm512_set1_epi32(-1);
    const __m512i one = _mm512_set1_epi32(1);
    const __m512i two = _mm512_set1_epi32(2);
    const __m512i four = _mm512_set1_epi32(4);
    uint64_t at = 0;
    for (; at + 16 <= count; at += 16)
    {
        const __mmask16 active = UINT16_MAX;
        const __m128i operations = _mm_maskz_loadu_epi8(active, f->op + first + at);
        _mm_mask_storeu_epi8(view->op + out + at, active, operations);
        _mm_mask_storeu_epi8(view->type + out + at, active, _mm_maskz_loadu_epi8(active, f->type + first + at));
        _mm_mask_storeu_epi8(view->flags + out + at, active, _mm_maskz_loadu_epi8(active, f->flags + first + at));
        _mm_mask_storeu_epi8(view->alignment_log2 + out + at, active, _mm_maskz_loadu_epi8(active, f->alignment_log2 + first + at));
        const __m128i operands = _mm512_castsi512_si128(_mm512_permutex2var_epi8(_mm512_loadu_si512(ir_value_columns), _mm512_zextsi128_si512(operations), _mm512_loadu_si512(ir_value_columns+64)));
        const __m512i a = _mm512_maskz_loadu_epi32(active, f->a + first + at);
        const __m512i b = _mm512_maskz_loadu_epi32(active, f->b + first + at);
        const __m512i c = _mm512_maskz_loadu_epi32(active, f->c + first + at);
        // ir_value_mask: an opcode's operands, and its optional ones where they aren't BUSTER_IR_NONE.
        const __mmask16 use_a = active & _mm_test_epi8_mask(operands, _mm_set1_epi8(1)) & _mm512_cmpneq_epi32_mask(a, none);
        const __mmask16 use_b = active & _mm_test_epi8_mask(operands, _mm_set1_epi8(2)) & _mm512_cmpneq_epi32_mask(b, none);
        const __mmask16 use_c = active & _mm_test_epi8_mask(operands, _mm_set1_epi8(4)) & _mm512_cmpneq_epi32_mask(c, none);
        _mm512_mask_storeu_epi32(view->a + out + at, active, _mm512_mask_i32gather_epi32(a, use_a, _mm512_sub_epi32(a, origin), map + center, 4));
        _mm512_mask_storeu_epi32(view->b + out + at, active, _mm512_mask_i32gather_epi32(b, use_b, _mm512_sub_epi32(b, origin), map + center, 4));
        _mm512_mask_storeu_epi32(view->c + out + at, active, _mm512_mask_i32gather_epi32(c, use_c, _mm512_sub_epi32(c, origin), map + center, 4));
    }
    for (; at < count; at += 8)
    {
        const uint32_t lanes = count - at < 8 ? (uint32_t)(count - at) : 8;
        const __mmask16 active = (__mmask16)((1u << lanes) - 1u);
        const __m128i operations = _mm_maskz_loadu_epi8(active, f->op + first + at);
        _mm_mask_storeu_epi8(view->op + out + at, active, operations);
        _mm_mask_storeu_epi8(view->type + out + at, active, _mm_maskz_loadu_epi8(active, f->type + first + at));
        _mm_mask_storeu_epi8(view->flags + out + at, active, _mm_maskz_loadu_epi8(active, f->flags + first + at));
        _mm_mask_storeu_epi8(view->alignment_log2 + out + at, active, _mm_maskz_loadu_epi8(active, f->alignment_log2 + first + at));

        const __m256i uses = _mm512_castsi512_si256(ir_lookup_bytes(ir_value_columns, operations));
        const __m256i a = _mm256_maskz_loadu_epi32(active, f->a + first + at);
        const __m256i b = _mm256_maskz_loadu_epi32(active, f->b + first + at);
        const __m256i c = _mm256_maskz_loadu_epi32(active, f->c + first + at);
        const __mmask8 has_a = _mm256_test_epi32_mask(uses, _mm256_set1_epi32(1)) & _mm256_cmpneq_epi32_mask(a, _mm256_set1_epi32(-1));
        const __mmask8 has_b = _mm256_test_epi32_mask(uses, _mm256_set1_epi32(2)) & _mm256_cmpneq_epi32_mask(b, _mm256_set1_epi32(-1));
        const __mmask8 has_c = _mm256_test_epi32_mask(uses, _mm256_set1_epi32(4)) & _mm256_cmpneq_epi32_mask(c, _mm256_set1_epi32(-1));
        const __m512i ab = _mm512_inserti64x4(_mm512_castsi256_si512(a), b, 1);
        const __mmask16 mask = (unsigned)has_a | (unsigned)has_b << 8;
        const __m512i result = _mm512_mask_i32gather_epi32(ab, mask, _mm512_sub_epi32(ab, origin), map + center, 4);
        __m256i last = c;
        if (has_c)
        {
            last = _mm256_mmask_i32gather_epi32(c, has_c, _mm256_sub_epi32(c, _mm512_castsi512_si256(origin)), map + center, 4);
        }
        _mm256_mask_storeu_epi32(view->a + out + at, active, _mm512_castsi512_si256(result));
        _mm256_mask_storeu_epi32(view->b + out + at, active, _mm512_extracti64x4_epi64(result, 1));
        _mm256_mask_storeu_epi32(view->c + out + at, active, last);
    }
}
