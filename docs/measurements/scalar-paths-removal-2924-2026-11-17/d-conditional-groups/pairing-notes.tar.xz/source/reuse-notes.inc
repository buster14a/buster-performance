// The pairing table links each group independently. An else reports every following middle
// through the next else, which in turn covers the rest. A group without an endif reports its opener.
static bool pp_reuse_notes(Arena* arena, PPFileData* data, uint32_t required, uint8_t* notes)
{
    const uint32_t count = data->directive_count;
    for (uint64_t first = 0; first < count; first += 64)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, count - first < 64 ? (uint32_t)(count - first) : 64);
        const __m512i kinds = _mm512_maskz_loadu_epi8(valid, data->directive_kind + first);
        const __mmask64 elifdef = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PP_DIRECTIVE_ELIFDEF)) |
                                  _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PP_DIRECTIVE_ELIFNDEF));
        _mm512_mask_storeu_epi8(notes + first, valid, _mm512_maskz_set1_epi8(elifdef, BUSTER_PP_NOTE_ELIFDEF));
    }
    for (uint64_t first = 0; required != 0 && first < count; first += 64)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, count - first < 64 ? (uint32_t)(count - first) : 64);
        const __m512i kinds = _mm512_maskz_loadu_epi8(valid, data->directive_kind + first);
        uint64_t elses = required & BUSTER_PP_NOTE_AFTER_ELSE ? _mm512_mask_cmpeq_epi8_mask(valid, kinds, _mm512_set1_epi8(PP_DIRECTIVE_ELSE)) : 0;
        while (elses != 0)
        {
            const uint32_t last_else = (uint32_t)first + (uint32_t)__builtin_ctzll(elses);
            elses &= elses - 1;
            for (uint32_t d = data->directive_next[last_else]; d != BUSTER_PP_NONE && data->directive_kind[d] != PP_DIRECTIVE_ENDIF; d = data->directive_next[d])
            {
                notes[d] |= BUSTER_PP_NOTE_AFTER_ELSE;
                if (data->directive_kind[d] == PP_DIRECTIVE_ELSE)
                {
                    break;
                }
            }
        }
        const __m512i relative = _mm512_sub_epi8(kinds, _mm512_set1_epi8(PP_DIRECTIVE_IF));
        uint64_t opens = required & BUSTER_PP_NOTE_UNTERMINATED ? _mm512_mask_cmple_epu8_mask(valid, relative, _mm512_set1_epi8(PP_DIRECTIVE_IFNDEF - PP_DIRECTIVE_IF)) : 0;
        while (opens != 0)
        {
            const uint32_t opener = (uint32_t)first + (uint32_t)__builtin_ctzll(opens);
            opens &= opens - 1;
            uint32_t d = data->directive_next[opener];
            while (d != BUSTER_PP_NONE && data->directive_kind[d] != PP_DIRECTIVE_ENDIF)
            {
                d = data->directive_next[d];
            }
            if (d == BUSTER_PP_NONE)
            {
                notes[opener] |= BUSTER_PP_NOTE_UNTERMINATED;
            }
        }
    }
    uint32_t total = 0;
    for (uint64_t first = 0; first < count; first += 64)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, count - first < 64 ? (uint32_t)(count - first) : 64);
        const __m512i flags = _mm512_maskz_loadu_epi8(valid, notes + first);
        total += (uint32_t)__builtin_popcountll(_mm512_test_epi8_mask(flags, flags));
    }
    data->note_directives = arena_push_array(arena, (uint64_t)total + 1, sizeof(uint32_t), 4);
    data->note_kinds = arena_push(arena, (uint64_t)total + 1, 1);
    const bool result = data->note_directives != 0 && data->note_kinds != 0;
    data->note_count = 0;
    const __m512i lanes = _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
    for (uint64_t first = 0; result && data->note_count < total; first += 16)
    {
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, count - first < 16 ? (uint32_t)(count - first) : 16);
        const __m128i flags = _mm_maskz_loadu_epi8(valid, notes + first);
        const __mmask16 keep = _mm_test_epi8_mask(flags, flags);
        _mm_mask_compressstoreu_epi8(data->note_kinds + data->note_count, keep, flags);
        _mm512_mask_compressstoreu_epi32(data->note_directives + data->note_count, keep, _mm512_add_epi32(lanes, _mm512_set1_epi32((int32_t)first)));
        data->note_count += (uint32_t)__builtin_popcount(keep);
    }
    return result;
}
