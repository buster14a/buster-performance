#include "buster/compiler/c_preprocessor_benchmark.c"
#include "carryout.inc"
#include "carrymask.inc"
typedef bool Pair(PPFileData*,uint32_t*);
static bool stack_only(PPFileData* d,uint32_t* s){pp_pair_conditionals_scalar(d,s);return true;}
static bool original(PPFileData* d,uint32_t* s){bool notable=true;if(!pp_pair_conditionals_vector(d,s,&notable)){pp_pair_conditionals_scalar(d,s);return true;}return notable;}
static Pair* volatile methods[]={stack_only,original,pair_carryout,pair_carrymask};
static uint32_t state=1;
static uint32_t random_u32(void){state=1664525*state+1013904223;return state;}
static uint64_t tick(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int cmp_u64(const void*a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return(x>y)-(x<y);}
int main(int argc,char**argv)
{
    if(argc>1) state=(uint32_t)strtoul(argv[1],NULL,0);
    unsigned widths[128],nw=0;for(unsigned i=0;i<=65;i++)widths[nw++]=i;
    unsigned more[]={95,96,97,127,128,129,255,256,257,511,512,513,1023,1024,1025,2047,2048,2049,4095,4096,4097,8192,60005};
    for(unsigned i=0;i<BUSTER_ARRAY_LENGTH(more);i++)widths[nw++]=more[i];
    unsigned largest=widths[nw-1];uint8_t*k=malloc(largest+64);uint32_t*links[4],*stack[4];
    for(unsigned j=0;j<4;j++){links[j]=malloc(4*(largest+32));stack[j]=malloc(4*(largest+32));if(!links[j]||!stack[j]||!k)return 2;}
    unsigned checked=0;
    for(unsigned z=0;z<nw;z++)for(unsigned variant=0;variant<11;variant++){
        const unsigned n=widths[z];unsigned pending=0;bool note=false;uint8_t*seen=calloc(n+1,1);if(!seen)return 2;
        for(unsigned i=0;i<n;i++){
            unsigned choice=random_u32()>>16;
            switch(variant){
             case 0:k[i]=PP_DIRECTIVE_DEFINE;break;
             case 1:k[i]=PP_DIRECTIVE_ENDIF;break;
             case 2:k[i]=PP_DIRECTIVE_ELSE;break;
             case 3:k[i]=i+1<n?PP_DIRECTIVE_DEFINE:PP_DIRECTIVE_ENDIF;break;
             case 4:k[i]=i%4==0?PP_DIRECTIVE_ENDIF:i%4==1?PP_DIRECTIVE_IF:i%4==2?PP_DIRECTIVE_ELSE:PP_DIRECTIVE_ENDIF;break;
             case 5:k[i]=i<n/2?PP_DIRECTIVE_IF:PP_DIRECTIVE_ENDIF;break;
             case 6:k[i]=i%4==0?PP_DIRECTIVE_IF:i%4==1?PP_DIRECTIVE_ELIF:i%4==2?PP_DIRECTIVE_ELSE:PP_DIRECTIVE_ENDIF;break;
             case 7:k[i]=i==0?PP_DIRECTIVE_IF:PP_DIRECTIVE_ELSE;break;
             case 8:k[i]=i%7==0?PP_DIRECTIVE_IF:i%7==4?PP_DIRECTIVE_ENDIF:PP_DIRECTIVE_DEFINE;break;
             case 9:k[i]=(uint8_t)(PP_DIRECTIVE_IF+choice%8);break;
             default:k[i]=choice%11?PP_DIRECTIVE_DEFINE:(uint8_t)(PP_DIRECTIVE_IF+choice/11%8);break;
            }
            if(k[i]>=PP_DIRECTIVE_IF&&k[i]<=PP_DIRECTIVE_IFNDEF)seen[pending++]=0;
            else if(k[i]==PP_DIRECTIVE_ENDIF){if(pending)pending--;}
            else if(k[i]>=PP_DIRECTIVE_ELIF&&k[i]<=PP_DIRECTIVE_ELSE&&pending){note|=seen[pending-1];seen[pending-1]|=k[i]==PP_DIRECTIVE_ELSE;}
        }
        note|=pending!=0;free(seen);
        PPFileData inputs[4];for(unsigned j=0;j<4;j++){memset(links[j],0xff,4*(n+1));inputs[j]=(PPFileData){.directive_count=n,.directive_kind=k,.directive_next=links[j]};bool actual=methods[j](&inputs[j],stack[j]);if(j>1&&actual!=note)return 3;if(j&&memcmp(links[j],links[0],4*(n+1)))return 4;}
        unsigned repeats=n<30000?4096/(1+n/4)+3:1;
        uint64_t samples[4][9];
        for(unsigned round=0;round<9;round++){unsigned q=random_u32()>>30;for(unsigned s=0;s<4;s++){
            unsigned j=(q+(round%2?3*s:s))%4;Pair* fn=methods[j];uint64_t start=tick();
            for(unsigned rep=0;rep<repeats;rep++)fn(inputs+j,stack[j]);
            samples[j][round]=tick()-start;
        }}
        printf("%u %u %u",n,variant,repeats);for(unsigned s=0;s<4;s++){qsort(samples[s],9,sizeof(uint64_t),cmp_u64);printf(" %lu",samples[s][4]);}puts("");checked++;
    }
    fprintf(stderr,"%u paired size and shape cells; each complete link table agrees\n",checked);
}
