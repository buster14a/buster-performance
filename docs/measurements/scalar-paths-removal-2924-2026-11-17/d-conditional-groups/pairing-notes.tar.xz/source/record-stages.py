from pathlib import Path
from statistics import median
import tarfile,re
p=Path(__file__).parent;r=p/'results'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-conditional-groups')
runs={}
for mode in ('notes','linked','reuse','pool'):
 mats=[]
 for seed in (1,133,789):
  d={};log=(r/f'{mode}-{seed}.log').read_text()
  assert '979 paired size and shape cells; all links and every note byte/index agree' in log
  for line in (r/f'{mode}-{seed}.tsv').read_text().splitlines():
   v=list(map(int,line.split()));assert len(v)==9 and min(v[5:])>0 and tuple(v[:2]) not in d;d[tuple(v[:2])]=v
  assert len(d)==979;mats.append(d)
 runs[mode]=mats
for seed in (1,133,789):assert '15516' in (r/f'carry-check-{seed}.log').read_text()
def summaries(mode,col,scope=None):
 ds=runs[mode];keys=list(ds[0])
 if scope=='refused':keys=[k for k in keys if any(x[k][3] for x in ds)]
 if isinstance(scope,int):keys=[k for k in keys if k[1]==scope]
 out=[]
 for ref in (5,6):
  v=[median(x[k][col]/x[k][ref] for x in ds)for k in keys]
  out.append(f'{sum(q<=1 for q in v)}/{len(v)} · {median(v):.3f}×')
 return out
labels=[('notes',7,'Carry links with the original notes pass'),('linked',8,'Traverse notes by group links'),('reuse',7,'Reuse the pairing scratch for note bytes'),('reuse',8,'Count notes when recording them'),('pool',7,'Allocate both final note columns together'),('pool',8,'Also batch unterminated openers in files without an endif')]
shapes=['Other directives','Only orphan ends','Only orphan middles','Trailing orphan end','Orphan end, open, else, end','Deep opens, then closes','Open, elif, else, end','Open and repeated else','Sparse regular groups','Dense random conditionals','Sparse random conditionals']
summary=['| '+l+' | '+' | '.join(summaries(m,c)+summaries(m,c,'refused'))+' |'for m,c,l in labels]
byshape=['| '+l+' | '+' | '.join(summaries('pool',7,i))+' |'for i,l in enumerate(shapes)]
s=(r/'pool-compiler-frozen.log').read_text();assert 'cases: 0 of 419 fail' in s and '419 fixtures, 1/2/3/8 lanes, both kernels/orders' in s and all(re.search(r'fuzz: '+mode+r', seed 1: 64 cases, .*?0 differ',s)for mode in ('c17','c23')) and 'snippet columns: pass' in s
body='''## Pair links and complete directive notes

The new pairer uses the carry bits of a 64-bit add to find continuations following their last local opener. Packed conditional ranks match writers to their following directives, and masked stores write the link columns at the original directive indices. Groups extending beyond a packet use a stack of unsigned indices. The implementation records whether a file contains an unterminated group or a middle directive following an else.

Pairing alone and complete pairing with diagnostic notes have different contracts. The isolated link-only control below uses the original stack, which produces links but lacks the flag that selects the notes pass. In the complete stage the forced scalar path calls the notes pass after its stack walk, as the production fallback does. The original dispatcher takes its usual fast path or scalar escape. Every complete stage produces exactly the same links, sorted note indices and note bytes at each of 89 lengths and 11 input shapes. The three seeds use the same input across all four interleaved implementations.

Each cell gives the number of per-size/input ratios at or below one, followed by the median ratio. Three independently seeded rounds run nine rotating interleaved batches per cell on CPU 2 of the locked 9700X. The last two columns cover the 572 cells in which at least one seed actually refused the original vector implementation. All 979 cells remain in the first two columns.

| Complete stage | Forced scalar with notes | Original dispatcher with notes | Reached versus scalar | Reached versus dispatcher |
| --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(summary)+'''

| Final implementation by shape | Forced scalar with notes | Original dispatcher with notes |
| --- | ---: | ---: |
'''+'\n'.join(byshape)+'''

For links alone, the carry implementation beat the original dispatcher in all 979 cells and met the bare scalar stack in 863. The note-aware comparison includes the work performed by the fallback's actual caller. Each seed also passed 15,516 independent link and note-presence checks over randomized inputs, deep groups, boundary sizes and orphan directives.

The submitted full compiler passed 419 frozen cases, all 128 Clang fuzz comparisons, and the 1/2/3/8-lane determinism suite. The native corpus reached the original escape on four of the seven targeted source fixtures, including legally balanced 30,032-level nesting.

[Implementations, paired stage measurements, checks and full-compiler build](pairing-notes.tar.xz)
'''
with tarfile.open(out/'pairing-notes.tar.xz','w:xz') as t:
 for n in ('carryout.inc','carrymask.inc','carry-task','carry-gate.c','check-carry.c','carry.patch','notes-stage.c','notes-task','linked-pair.inc','linked-notes.inc','linked-stage.c','linked-task','reuse-notes.inc','count-notes.inc','reuse-stage.c','reuse-task','pool-notes.inc','open-notes.inc','pool-stage.c','pool-task','pool-full.patch','build-pool-final','pool-compiler-corpus','pool-rare-cases','record-stages.py'):t.add(p/n,arcname='source/'+n)
 for f in sorted(r.glob('*')):
  if f.is_file() and f.name.startswith(('carry-check-','carry-gate-','notes-','linked-','reuse-','pool-')):t.add(f,arcname='native/'+f.name)
f=out/'README.md';old=f.read_text().split('\n## Pair links and complete directive notes')[0];f.write_text(old.rstrip()+'\n\n'+body)
print(*summary,sep='\n')
