static const uint8_t pp_pair_lanes_carryout[64] __attribute__((aligned(64))) = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63};
// Within a 64-directive packet each pending link is a bit at the directive's original position.
// Only opens that survive the packet need an entry in the cross-packet stack.
static bool pair_carryout(PPFileData* data, uint32_t* open)
{
    const __m512i lanes = _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
    uint32_t depth = 0;
    bool notable = false;
    for (uint64_t first = 0; first < data->directive_count; first += 64)
    {
        const uint32_t left = (uint32_t)(data->directive_count - first);
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, left < 64 ? left : 64);
        const __m512i kinds = _mm512_maskz_loadu_epi8(valid, data->directive_kind + first);
        const __m512i relative = _mm512_sub_epi8(kinds, _mm512_set1_epi8(PP_DIRECTIVE_IF));
        uint64_t pending = _mm512_mask_cmple_epu8_mask(valid, relative, _mm512_set1_epi8(PP_DIRECTIVE_IFNDEF - PP_DIRECTIVE_IF));
        if (pending == 0 && depth == 0)
        {
            continue;
        }
        const uint64_t ends = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PP_DIRECTIVE_ENDIF));
        const uint64_t elses = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PP_DIRECTIVE_ELSE));
        uint64_t continuations = _mm512_mask_cmple_epu8_mask(valid, _mm512_sub_epi8(kinds,_mm512_set1_epi8(PP_DIRECTIVE_ELIF)),_mm512_set1_epi8(PP_DIRECTIVE_ENDIF - PP_DIRECTIVE_ELIF));
        // An open group can carry a chain of middle directives across many packets. Link its
        // first continuation here so the remaining local pairs use the same packed rank operation.
        if (depth != 0 && continuations != 0)
        {
            const uint64_t first_continuation = _blsi_u64(continuations);
            if ((pending & (first_continuation - 1)) == 0)
            {
                const uint32_t d = (uint32_t)first + (uint32_t)__builtin_ctzll(first_continuation);
                const uint32_t previous = open[--depth];
                data->directive_next[previous] = d;
                if ((ends & first_continuation) == 0)
                {
                    notable |= data->directive_kind[previous] == PP_DIRECTIVE_ELSE;
                    pending |= first_continuation;
                }
                continuations ^= first_continuation;
            }
        }
        // A carry starts at an opener, stops at an endif, and propagates through every other byte.
        // Its carry-in at a continuation means the preceding structural directive is a local opener.
        // Every such continuation links to the immediately preceding conditional in source order.
        const uint64_t carry = (pending + ~ends) ^ pending ^ ~ends;
        const uint64_t local = continuations & carry;
        if (local != 0)
        {
            const uint64_t conditionals = pending | continuations;
            const uint64_t writers = _pdep_u64(_pext_u64(local, conditionals) >> 1, conditionals);
            const uint64_t middle = local & ~ends;
            if (elses != 0)
            {
                const uint64_t after_else = (_pext_u64(elses & writers, conditionals) << 1) & _pext_u64(middle, conditionals);
                notable |= after_else != 0;
            }
            const __m512i positions = _mm512_load_si512(pp_pair_lanes_carryout);
            const __m512i packed = _mm512_maskz_compress_epi8(local, positions);
            uint8_t destinations[64] __attribute__((aligned(64)));
            _mm512_store_si512(destinations, _mm512_maskz_expand_epi8(writers, packed));
            uint64_t marks = writers;
            for (uint32_t part = 0; marks != 0; part += 16)
            {
                const __mmask16 write = (__mmask16)marks;
                if (write != 0)
                {
                    const __m512i next = _mm512_cvtepu8_epi32(_mm_load_si128((const __m128i*)(destinations + part)));
                    _mm512_mask_storeu_epi32(data->directive_next + first + part, write, _mm512_add_epi32(next, _mm512_set1_epi32((int32_t)first)));
                }
                marks >>= 16;
            }
            // A middle becomes the pending writer of its opener's group. Only writers without a local
            // successor and continuations following a close or the packet boundary can still need work.
            pending = (pending | middle) & ~writers;
            continuations &= ~local;
        }
        while (continuations != 0)
        {
            const uint64_t bit = _blsi_u64(continuations);
            continuations &= continuations - 1;
            const uint64_t available = pending & (bit - 1);
            const uint32_t d = (uint32_t)first + (uint32_t)__builtin_ctzll(bit);
            uint32_t prior;
            bool was_else;
            if (available != 0)
            {
                const uint32_t lane = 63u - (uint32_t)__builtin_clzll(available);
                const uint64_t matched = UINT64_C(1) << lane;
                pending ^= matched;
                prior = (uint32_t)first + lane;
                was_else = (elses & matched) != 0;
            }
            else if (depth != 0)
            {
                prior = open[--depth];
                was_else = data->directive_kind[prior] == PP_DIRECTIVE_ELSE;
            }
            else
            {
                continue;
            }
            data->directive_next[prior] = d;
            if ((ends & bit) == 0)
            {
                notable |= was_else;
                pending |= bit;
            }
        }
        // No later directive can read the last packet's surviving writers.
        if (first + 64 >= data->directive_count)
        {
            notable |= pending != 0;
            break;
        }
        for (uint32_t lane = 0; pending != 0; lane += 16)
        {
            const __mmask16 keep = (__mmask16)pending;
            const __m512i ids = _mm512_add_epi32(lanes, _mm512_set1_epi32((int32_t)((uint32_t)first + lane)));
            _mm512_mask_compressstoreu_epi32(open + depth, keep, ids);
            depth += (uint32_t)__builtin_popcount(keep);
            pending >>= 16;
        }
    }
    return notable || depth != 0;
}
