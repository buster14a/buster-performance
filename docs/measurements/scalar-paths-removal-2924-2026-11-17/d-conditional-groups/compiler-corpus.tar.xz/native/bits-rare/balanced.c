#if 1
int x;
#else
#error lost
#endif
