from pathlib import Path
from statistics import median
from collections import defaultdict
import struct,re,tarfile
p=Path(__file__).parent;r=p/'results'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-conditional-groups')
out.mkdir(exist_ok=True)
shapes=['Other directives','Only orphan ends','Only orphan middles','Last directive is an orphan end','Orphan end, open, else, end','Deep opens followed by ends','Open, elif, else, end','Open followed by else directives','Sparse regular groups','Dense random conditionals','Sparse random conditionals']
def ratios(prefix,col):
 data=defaultdict(list);win=defaultdict(int);old=defaultdict(int);med=defaultdict(list)
 runs=[]
 for seed in (1,133,789):
  cells=[[int(x)for x in line.split()]for line in (r/f'{prefix}gate-{seed}.tsv').read_text().splitlines()];assert len(cells)==979 and all(len(t)==7 and min(t[3:])>0 for t in cells);runs.append(cells)
 for cells in zip(*runs):
  n,shape,reps=cells[0][:3]; assert all(x[:3]==[n,shape,reps]for x in cells)
  sc=median(x[col]/x[3]for x in cells);vec=median(x[col]/x[4]for x in cells)
  win[shape]+=sc<=1;old[shape]+=vec<=1;med[shape].append(sc)
 assert all(len(med[k])==89 for k in range(11))
 return [f'{win[k]}/89 · {old[k]}/89 · {median(med[k]):.2f}' for k in range(11)]
def census():
 rows=[]
 for g in ('lua','sqlite','musl'):
  x=[struct.unpack('<8Q',(r/f'counts-{m}-{g}.bin').read_bytes())for m in ('default','whole')]
  assert x[0]==x[1] and x[0][2:5]==(0,0,0)
  rows.append('| '+g+' | '+' | '.join(str(v)for v in x[0][:5])+' |')
 return rows
def rare(directory,side):
 rows=[];d=r/directory
 for c in sorted(d.glob('*.c')):
  n=c.stem;vs=[]
  for m in ('default','whole'):
   vs.append(struct.unpack('<8Q',(d/f'{n}-{m}.bin').read_bytes()))
   for ext in ('out','err','status'):
    assert (d/f'{n}-{m}-census.{ext}').read_bytes()==(d/f'{n}-{m}-{side}.{ext}').read_bytes()
   for ext in ('err','status'):
    assert (d/f'{n}-clang.{ext}').read_bytes()==(d/f'{n}-{m}-{side}.{ext}').read_bytes()
  assert vs[0][2:5]==vs[1][2:5]
  rows.append('| '+n+' | '+' | '.join(str(v)for v in vs[0][2:5])+' | '+(d/f'{n}-clang.status').read_text().strip()+' |')
 assert len(rows)==7
 return rows
def process(folder):
 out=[]
 for g in ('lua','sqlite','musl'):
  vals=[]
  d=r/f'{folder}-{g}'
  for m in ('default','whole','window'):
   for ext in ('sha','err'):assert (d/f'{m}-base.{ext}').read_bytes()==(d/f'{m}-head.{ext}').read_bytes()
   s=(d/f'{m}.log').read_text();assert s.rstrip().endswith('ab: done, 0 failed runs')
   pairs=[]
   for part in s.split('time-runs: done, 0 failed processes')[:-1]:
    v={k:int(x)for k,x in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',part,re.M)};pairs.append(v['head']/v['base'])
   assert len(pairs)==5;vals.append(median(pairs))
  samples=[]
  for i in (1,2,3):
   xs=[]
   for side in ('base','head'):
    s=(d/f'tables-{side}-{i}.log').read_text();xs.append(float(re.search(r'^  vectorized +[.\d]+ ms +([.\d]+) cycles/token',s,re.M)[1]))
   samples.append(xs[1]/xs[0])
  vals.append(median(samples))
  out.append('| '+g+' | '+' | '.join(f'{100*(v-1):+.3f}%'for v in vals)+' |')
 return out
labels=[('','16-lane conflicts',5),('','Runs',6),('bits-','64-bit local stack',5),('bits-','Sparse stack writes',6)]
if (r/'peel-gate-789.tsv').exists():labels.extend([('peel-','Local links',5),('peel-','Packed local links',6)])
sides=[ratios(prefix,idx)for prefix,_,idx in labels]
rows=['| '+shape+' | '+' | '.join(side[k]for side in sides)+' |'for k,shape in enumerate(shapes)]
for seed in (1,133,789):
 for name in ['both','bits-check']+(['peel-check'] if len(labels)>4 else []):
  assert '15516 complete links and independent note comparisons passed' in (r/f'{name}-{seed}.log').read_text()
def tests(f):
 s=(r/f).read_text();assert 'cases: 0 of 419 fail' in s and re.search(r'419 fixtures, 1/2/3/8 lanes, both kernels/orders, ID seed 153: pass',s) and all(re.search(r'fuzz: '+mode+r', seed 1: 64 cases, .*?0 differ',s)for mode in ('c17','c23'))
tests('packed-frozen.log')
text='''# Preprocessor conditional grouping on Zen 5

## Reach in actual preprocessing

A file-backed process-shared counter in the original compiler counts each prepared file, its directives, a refusal by the vector pairer, the directives in refused files, and successful pairings that require conditional notes. Default and whole-file windows gave the same counts for all three corpora. These include all 34 Lua, one SQLite and 1,336 musl translation units and their headers.

| Corpus | Prepared files | Directives | Refusals | Directives in refused files | Successful pairings requiring notes |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(census())+'''

Seven fixtures exercise whole-compiler preprocessing and Clang on real source files. In both window configurations every candidate output, diagnostic and exit status matched the parent. Clang returned the same exit status and byte-identical stderr on all seven, including multiple diagnostics in the same translation unit. The balanced source with 30,032 open conditionals successfully reproduces the old 16-bit depth refusal. The successful pairer handles extra elses and unterminated groups by asking the notes pass to inspect them.

| Source | Refusals | Directives in refused files | Successful pairings requiring notes | Exit status |
| --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(rare('rare','packed'))+'''

## Pairing cost by shape and size

The locked Ryzen 7 9700X measured 89 widths from zero through 60,005 directives, including every width through 65. Three seeds each measured 979 size and shape combinations. Each repetition uses the same generated input for the original scalar stack, the shipped vector dispatcher with its fallback, and two candidates. Nine measurements rotate the order of those four functions. Ratios compare median ticks for the same seed and input, then take the median of three paired ratios. The original scalar stack only computes the links. The candidates also decide whether the file requires a notes pass.

Each table cell gives the number of widths meeting the scalar stack, the number meeting the original dispatcher, and the median candidate/stack ratio over the 89 widths. The checks compare all final links against the shipped stack and the note bit against a separate expectation. Each of three seeds also passed all 15,516 randomized, deep and boundary checks for each pair of candidates.

| Shape | '''+' | '.join(l for _,l,_ in labels)+' |\n| --- |'+' ---: |'*len(labels)+'\n'+'\n'.join(rows)+'''

## Complete preprocessing

The conflict-detection compiler passed all 419 frozen fixtures, 128 Clang fuzz comparisons and the one-, two-, three- and eight-lane determinism suite. Its `-E` comparisons used five paired rounds of three fresh processes and verified stdout hashes and stderr. The table construction benchmark separately timed 21 passes over representative source files per invocation, with three paired invocations. Percent changes are candidate over parent in user cycles for the three driver columns and cycles per token for the final column.

| Corpus | Default | Whole file | 4 KiB windows | Directive tables |
| --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(process('packed'))+'\n'
has_bits=(r/'bits-rare').is_dir() and (r/'bits-compiler-musl/tables-head-3.log').is_file()
if has_bits:
 tests('bits-compiler-frozen.log');assert rare('bits-rare','packed')==rare('rare','packed')
 text+='''
The 64-bit local-stack compiler passed the same frozen, Clang fuzz, determinism, deep-nesting and error-diagnostic checks. Its three corpus comparisons used the same measurement procedure.

| Corpus | Default | Whole file | 4 KiB windows | Directive tables |
| --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(process('bits-compiler'))+'\n'
text+='\nSeveral mixed or dense inputs still take more cycles than the scalar stack. These results qualify individual inputs and leave the per-size gate open.\n\n[Source changes, original baselines, independent checks, per-size samples, paired commands and raw native process measurements](pairing-native.tar.xz)\n'
files=['packed.inc','runs.inc','bitstack.inc','bitsparse.inc','check-both.c','check-bits.c','gate.c','bits-gate.c','packed.patch','bitstack.patch','census.patch','census.py','check-runs','gate','bits-task','corpus','rare-cases','build-packed','packed-corpus','record.py']
if has_bits:files+=['build-bits','bits-compiler-corpus','bits-rare-cases']
if len(labels)>4:files+=['peel-task','ranges.inc','compressed.inc','peel.py','peel-gate.c','check-peel.c']
with tarfile.open(out/'pairing-native.tar.xz','w:xz')as archive:
 for name in files:archive.add(p/name,arcname='source/'+name)
 for f in sorted(r.rglob('*')):
  if not f.is_file()or 'job' in f.name or 'build.log' in f.name:continue
  if f.parts[len(r.parts)].startswith('bits-compiler-') and not has_bits:continue
  archive.add(f,arcname='native/'+str(f.relative_to(r)))
(out/'README.md').write_text(text)
print(*process('packed'),sep='\n')
