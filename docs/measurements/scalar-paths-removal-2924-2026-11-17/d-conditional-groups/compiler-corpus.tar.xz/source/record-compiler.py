from pathlib import Path
from statistics import median
import re,struct,tarfile
p=Path(__file__).parent;r=p/'results'
text=(p/'record.py').read_text()
exec(text[text.index('def rare('):text.index('labels=')]);exec(text[text.index('def tests('):text.index('\n',text.index("for mode in ('c17','c23')",text.index('def tests(')))])
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-conditional-groups')
sets={}
for v in ['pool','bits']:
 tests(f'{v}-compiler-frozen.log');sets[v]=process(f'{v}-compiler')
 side='packed'
 rare_rows=rare(f'{v}-rare',side)
 print(v,*sets[v],*rare_rows,sep='\n')
body='''## Complete preprocessor and conditional diagnostics

The compiler containing the joint note allocation and the earlier sparse bit-stack compiler were each measured against the uninstrumented parent on the locked 9700X. The preprocessing columns are paired changes in median user cycles over five rounds of three processes. The directive-table column gives the paired change in cycles per token across three alternating rounds. Output hashes and diagnostics matched for every workload and window size.

| Implementation | Corpus | Default | Whole file | 4 KiB window | Directive table |
| --- | --- | ---: | ---: | ---: | ---: |
'''+'\n'.join('| '+v+' '+row for v,rs in sets.items()for row in rs)+'''

The seven source cases include a 30,032-level nest and unmatched, unclosed or duplicate directives. Both compilers matched parent output, diagnostics and exit status in the default and whole-file modes. Diagnostics and exit status also matched Clang on all seven. The counters below report the original dispatcher’s reach. Each compiler passed all 419 fixed fixtures, the determinism check across 1/2/3/8 lanes, and 128 Clang fuzz comparisons.

| Source | Refusals | Refused records | Successful pairings requiring notes | Clang exit status |
| --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(rare_rows)+'''

[Compiler sources, commands, streams, hashes and timings](compiler-corpus.tar.xz)
'''
# Keep the original counter meanings recorded by the producer.
base=(p/'record.py').read_text()
for line in base.splitlines():
 if line.startswith('| Source')or 'Fast refusals' in line: print(line)
with tarfile.open(out/'compiler-corpus.tar.xz','w:xz',preset=2)as t:
 for f in ['pool-full.patch','build-pool-final','pool-compiler-corpus','pool-rare-cases','bitstack.patch','build-bits','bits-compiler-corpus','bits-rare-cases','record.py','record-compiler.py']:t.add(p/f,arcname='source/'+f)
 for tag in sets:
  for f in r.glob(tag+'-compiler-*'):
   if f.is_file()or f.is_dir():t.add(f,arcname='native/'+f.name)
  t.add(r/(tag+'-rare'),arcname='native/'+tag+'-rare')
file=out/'README.md';file.write_text(file.read_text().split('\n## Complete preprocessor and conditional diagnostics')[0].rstrip()+'\n\n'+body)
