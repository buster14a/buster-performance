#include "buster/compiler/c_preprocessor_benchmark.c"
#include "bitstack.inc"
#include "bitsparse.inc"
static uint32_t random_state=1;
static uint32_t rnd(void){random_state=1664525*random_state+1013904223;return random_state;}
static bool check(unsigned n,unsigned variant)
{
    uint8_t *k=malloc(n+1),*had_else=calloc(n+1,1);
    uint32_t *a=malloc(4*(n+1)),*b=malloc(4*(n+1)),*stack=malloc(4*(n+32));
    if (!k||!had_else||!a||!b||!stack) return false;
    unsigned depth=0;bool note=false;
    for(unsigned i=0;i<n;i++){
        unsigned w=rnd()>>20;
        uint8_t op = variant==0?PP_DIRECTIVE_IF + w%8 : variant==1 ? (i<n/2?PP_DIRECTIVE_IF:PP_DIRECTIVE_ENDIF) : variant==2 ? (i%3?PP_DIRECTIVE_ENDIF:PP_DIRECTIVE_ELSE) : variant==3?(i%3?PP_DIRECTIVE_IF:PP_DIRECTIVE_ELSE):variant==4?(i%6==0?PP_DIRECTIVE_IF:i%6==1?PP_DIRECTIVE_ELIF:i%6==2?PP_DIRECTIVE_ELSE:i%6==3?PP_DIRECTIVE_ENDIF:PP_DIRECTIVE_DEFINE):w%33;
        k[i]=op;a[i]=b[i]=BUSTER_PP_NONE;
        if(op>=PP_DIRECTIVE_IF&&op<=PP_DIRECTIVE_IFNDEF){had_else[depth++]=false;}
        else if(op==PP_DIRECTIVE_ENDIF){if(depth)depth--;}
        else if(op>=PP_DIRECTIVE_ELIF&&op<=PP_DIRECTIVE_ELSE&&depth){note|=had_else[depth-1];had_else[depth-1]|=op==PP_DIRECTIVE_ELSE;}
    }
    PPFileData d={.directive_count=n,.directive_kind=k,.directive_next=a};
    pp_pair_conditionals_scalar(&d,stack);d.directive_next=b;
    bool found=pair_bits(&d,stack);
    bool valid=found==(note||depth)&&!memcmp(a,b,n*4);
    if(!valid){for(unsigned i=0;i<n;i++)if(a[i]!=b[i]){fprintf(stderr,"n=%u shape=%u i=%u old=%u new=%u\n",n,variant,i,a[i],b[i]);break;}fprintf(stderr,"notes %d %d\n",found,note||depth);}
    for(unsigned i=0;i<n;i++)b[i]=BUSTER_PP_NONE;
    found=pair_bitsparse(&d,stack);
    valid=valid && found==(note||depth) && !memcmp(a,b,n*4);
    free(k);free(had_else);free(a);free(b);free(stack);return valid;
}
int main(int argc,char**argv){
    if(argc>1)random_state=strtoul(argv[1],NULL,0);
    unsigned count=0;for(unsigned rep=0;rep<20;rep++)for(unsigned width=0;width<129;width++)for(unsigned v=0;v<6;v++){if(!check(width,v))return 1;count++;}
    for(unsigned n=29998;n<=30003;n++)for(unsigned v=0;v<6;v++){if(!check(n*2+5,v))return 2;count++;}
    fprintf(stderr,"%u complete links and independent note comparisons passed\n",count);
}
