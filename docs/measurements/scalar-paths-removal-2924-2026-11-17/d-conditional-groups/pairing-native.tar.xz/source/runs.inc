// Scatter in two groups of eight so full unsigned directive numbers remain representable.
static void pair_link(PPFileData* data, __mmask16 live, __m512i previous, __m512i current)
{
    _mm512_mask_i64scatter_epi32(data->directive_next, (__mmask8)live, _mm512_cvtepu32_epi64(_mm512_castsi512_si256(previous)), _mm512_castsi512_si256(current), 4);
    _mm512_mask_i64scatter_epi32(data->directive_next, (__mmask8)(live >> 8), _mm512_cvtepu32_epi64(_mm512_extracti64x4_epi64(previous, 1)), _mm512_extracti64x4_epi64(current, 1), 4);
}
static bool pair_runs(PPFileData* data, uint32_t* open)
{
    const __m512i lanes = _mm512_setr_epi32(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15);
    uint32_t depth = 0;
    bool notable = false;
    for (uint64_t first = 0; first < data->directive_count; first += 16)
    {
        const uint32_t left = (uint32_t)(data->directive_count - first);
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, left < 16 ? left : 16);
        const __m128i kinds = _mm_maskz_loadu_epi8(valid, data->directive_kind + first);
        const __m128i relative = _mm_sub_epi8(kinds, _mm_set1_epi8(PP_DIRECTIVE_IF));
        uint32_t pending = _mm_mask_cmple_epu8_mask(valid, relative, _mm_set1_epi8(PP_DIRECTIVE_ENDIF - PP_DIRECTIVE_IF));
        const uint32_t opens = _mm_mask_cmple_epu8_mask(pending, relative, _mm_set1_epi8(PP_DIRECTIVE_IFNDEF - PP_DIRECTIVE_IF));
        const uint32_t ends = _mm_mask_cmpeq_epi8_mask(pending, kinds, _mm_set1_epi8(PP_DIRECTIVE_ENDIF));
        const uint32_t mids = pending & ~(opens | ends);
        const uint32_t elses = _mm_mask_cmpeq_epi8_mask(mids, kinds, _mm_set1_epi8(PP_DIRECTIVE_ELSE));
        const __m512i ids = _mm512_add_epi32(lanes, _mm512_set1_epi32((int32_t)first));
        while (pending != 0)
        {
            const uint32_t bit = _blsi_u32(pending);
            const bool pushes = (opens & bit) != 0;
            const bool pops = (ends & bit) != 0;
            const uint32_t kind = pushes ? opens : pops ? ends : mids;
            const uint32_t run = pending & kind & (_blsi_u32(pending & ~kind) - 1);
            pending &= ~run;
            uint32_t n = (uint32_t)__builtin_popcount(run);
            if (pushes)
            {
                _mm512_mask_compressstoreu_epi32(open + depth, (__mmask16)run, ids);
                depth += n;
            }
            else if (depth != 0)
            {
                const __m512i current = _mm512_maskz_compress_epi32((__mmask16)run, ids);
                if (pops)
                {
                    n = depth < n ? depth : n;
                    depth -= n;
                    const __mmask16 used = (__mmask16)_bzhi_u32(UINT16_MAX, n);
                    const __m512i old = _mm512_maskz_loadu_epi32(used, open + depth);
                    const __m512i reverse = _mm512_sub_epi32(_mm512_set1_epi32((int32_t)n - 1),lanes);
                    pair_link(data, used, _mm512_permutexvar_epi32(reverse, old), current);
                }
                else
                {
                    const uint32_t last = 31u - (uint32_t)__builtin_clz(run);
                    const uint32_t previous = open[depth - 1];
                    notable |= data->directive_kind[previous] == PP_DIRECTIVE_ELSE || (elses & run & ~(1u << last)) != 0;
                    const __m512i old = _mm512_mask_permutexvar_epi32(_mm512_set1_epi32((int32_t)previous), 0xfffe, _mm512_sub_epi32(lanes,_mm512_set1_epi32(1)),current);
                    pair_link(data, (__mmask16)_bzhi_u32(UINT16_MAX,n), old, current);
                    open[depth - 1] = (uint32_t)first + last;
                }
            }
        }
    }
    return notable || depth != 0;
}
