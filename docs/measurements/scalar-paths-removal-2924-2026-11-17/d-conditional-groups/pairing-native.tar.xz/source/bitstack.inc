// Within a 64-directive packet each pending link is a bit at the directive's original position.
// Only opens that survive the packet need an entry in the cross-packet stack.
static bool pair_bits(PPFileData* data, uint32_t* open)
{
    const __m512i lanes = _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
    uint32_t depth = 0;
    bool notable = false;
    for (uint64_t first = 0; first < data->directive_count; first += 64)
    {
        const uint32_t left = (uint32_t)(data->directive_count - first);
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, left < 64 ? left : 64);
        const __m512i kinds = _mm512_maskz_loadu_epi8(valid, data->directive_kind + first);
        const __m512i relative = _mm512_sub_epi8(kinds, _mm512_set1_epi8(PP_DIRECTIVE_IF));
        uint64_t pending = _mm512_mask_cmple_epu8_mask(valid, relative, _mm512_set1_epi8(PP_DIRECTIVE_IFNDEF - PP_DIRECTIVE_IF));
        if (pending == 0 && depth == 0)
        {
            continue;
        }
        const uint64_t ends = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PP_DIRECTIVE_ENDIF));
        const uint64_t elses = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(PP_DIRECTIVE_ELSE));
        uint64_t continuations = _mm512_mask_cmple_epu8_mask(valid, _mm512_sub_epi8(kinds,_mm512_set1_epi8(PP_DIRECTIVE_ELIF)),_mm512_set1_epi8(PP_DIRECTIVE_ENDIF - PP_DIRECTIVE_ELIF));
        while (continuations != 0)
        {
            const uint64_t bit = _blsi_u64(continuations);
            continuations &= continuations - 1;
            const uint64_t available = pending & (bit - 1);
            const uint32_t d = (uint32_t)first + (uint32_t)__builtin_ctzll(bit);
            uint32_t prior;
            bool was_else;
            if (available != 0)
            {
                const uint32_t lane = 63u - (uint32_t)__builtin_clzll(available);
                const uint64_t matched = UINT64_C(1) << lane;
                pending ^= matched;
                prior = (uint32_t)first + lane;
                was_else = (elses & matched) != 0;
            }
            else if (depth != 0)
            {
                prior = open[--depth];
                was_else = data->directive_kind[prior] == PP_DIRECTIVE_ELSE;
            }
            else
            {
                continue;
            }
            data->directive_next[prior] = d;
            if ((ends & bit) == 0)
            {
                notable |= was_else;
                pending |= bit;
            }
        }
        for (uint32_t lane = 0; pending != 0; lane += 16)
        {
            const __mmask16 keep = (__mmask16)pending;
            const __m512i ids = _mm512_add_epi32(lanes, _mm512_set1_epi32((int32_t)((uint32_t)first + lane)));
            _mm512_mask_compressstoreu_epi32(open + depth, keep, ids);
            depth += (uint32_t)__builtin_popcount(keep);
            pending >>= 16;
        }
    }
    return notable || depth != 0;
}
