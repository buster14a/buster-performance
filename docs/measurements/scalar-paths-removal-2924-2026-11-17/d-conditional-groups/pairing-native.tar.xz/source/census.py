from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent;name='src/buster/compiler/c_preprocessor.c';s=(p/'tree'/name).read_text()
helper='''static uint64_t* pp_pair_counts(void)
{
    static uint64_t* counts;
    if (!counts)
    {
        const char* path = getenv("BUSTER_PAIR_COUNTS");
        if (path != NULL)
        {
            int fd = open(path, O_RDWR | O_CLOEXEC);
            if (fd >= 0)
            {
                void* map = mmap(NULL, 64, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
                if (map != MAP_FAILED) counts = map;
                close(fd);
            }
        }
    }
    return counts;
}

'''
a=s.index('static bool pp_finish_directives(')
t=s[:a]+helper+s[a:]
a=t.index('    if (result && !pp_pair_conditionals_vector(');b=t.index('    scratch_end(scratch);',a)
t=t[:a]+'''    if (result)
    {
        const bool paired = pp_pair_conditionals_vector(data, indices, &notable);
        uint64_t* counts = pp_pair_counts();
        if (counts)
        {
            __atomic_fetch_add(counts + 0, 1, __ATOMIC_RELAXED);
            __atomic_fetch_add(counts + 1, data->directive_count, __ATOMIC_RELAXED);
            __atomic_fetch_add(counts + 2, !paired, __ATOMIC_RELAXED);
            __atomic_fetch_add(counts + 3, paired ? 0 : data->directive_count, __ATOMIC_RELAXED);
            __atomic_fetch_add(counts + 4, paired && notable, __ATOMIC_RELAXED);
        }
        if (!paired)
        {
            pp_pair_conditionals_scalar(data, indices);
            notable = true;
        }
    }
'''+t[b:]
(p/'census.patch').write_text(''.join(unified_diff(s.splitlines(True),t.splitlines(True),'a/'+name,'b/'+name)))
src=(Path('/tmp/buster-directive-whole')/'corpus').read_text().replace('buster-directive-whole-6b097f86','buster-conditionals-6b097f86').replace('BUSTER_DIRECTIVE_COUNTS','BUSTER_PAIR_COUNTS').replace('$root/src/build/pp-whole-census','/dev/shm/buster-unroll-6b097f86/src/build/pp-pair-census')
(p/'corpus').write_text(src)
