// Pair directives in their original order. A depth names the pending opener or continuation
// of one group. A continuation consumes the preceding writer at its depth, inside this
// packet or on the incoming stack. Unconsumed writers are the only stack entries to publish.
static bool pair_conflicts(PPFileData* data, uint32_t* open)
{
    const __m512i lanes = _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
    const __m512i zero = _mm512_setzero_si512();
    const __m512i one = _mm512_set1_epi32(1);
    uint32_t depth = 0;
    bool notable = false;
    for (uint64_t first = 0; first < data->directive_count; first += 16)
    {
        const uint32_t left = (uint32_t)(data->directive_count - first);
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, left < 16 ? left : 16);
        const __m128i bytes = _mm_maskz_loadu_epi8(valid, data->directive_kind + first);
        const __m128i relative = _mm_sub_epi8(bytes, _mm_set1_epi8(PP_DIRECTIVE_IF));
        const __mmask16 conditionals = _mm_mask_cmple_epu8_mask(valid, relative, _mm_set1_epi8(PP_DIRECTIVE_ENDIF - PP_DIRECTIVE_IF));
        if (conditionals == 0)
        {
            continue;
        }
        const __mmask16 opens = _mm_mask_cmple_epu8_mask(conditionals, relative, _mm_set1_epi8(PP_DIRECTIVE_IFNDEF - PP_DIRECTIVE_IF));
        const __mmask16 ends = _mm_mask_cmpeq_epi8_mask(conditionals, bytes, _mm_set1_epi8(PP_DIRECTIVE_ENDIF));
        const __mmask16 mids = conditionals & ~(opens | ends);
        if (opens == 0 && depth == 0)
        {
            continue;
        }
        const __m512i ids = _mm512_add_epi32(lanes, _mm512_set1_epi32((int32_t)first));
        if (conditionals == opens)
        {
            _mm512_mask_compressstoreu_epi32(open + depth, opens, ids);
            depth += (uint32_t)__builtin_popcount(opens);
            continue;
        }
        const uint32_t carry = depth < 16 ? depth : 16;
        const uint32_t base = depth - carry;
        const __m512i step = _mm512_mask_mov_epi32(_mm512_maskz_mov_epi32(opens, one), ends, _mm512_set1_epi32(-1));
        __m512i scan = step;
        for (uint32_t shift = 1; shift < 16; shift *= 2)
        {
            const __m512i source = _mm512_sub_epi32(lanes, _mm512_set1_epi32((int32_t)shift));
            scan = _mm512_add_epi32(scan, _mm512_maskz_permutexvar_epi32((__mmask16)(UINT16_MAX << shift), source, scan));
        }
        __m512i after = _mm512_add_epi32(scan, _mm512_set1_epi32((int32_t)carry));
        if (_mm512_movepi32_mask(after) != 0)
        {
            // An unmatched #endif leaves the stack empty. Subtract the minimum prefix seen
            // through each lane to ignore every such close without losing later balanced groups.
            __m512i floor = _mm512_min_epi32(after, zero);
            for (uint32_t shift = 1; shift < 16; shift *= 2)
            {
                const __m512i source = _mm512_sub_epi32(lanes, _mm512_set1_epi32((int32_t)shift));
                floor = _mm512_min_epi32(floor, _mm512_maskz_permutexvar_epi32((__mmask16)(UINT16_MAX << shift), source, floor));
            }
            after = _mm512_sub_epi32(after, floor);
        }
        const __m512i before = _mm512_mask_permutexvar_epi32(_mm512_set1_epi32((int32_t)carry), 0xfffe, _mm512_sub_epi32(lanes, one), after);
        const __mmask16 continues = _mm512_mask_cmpgt_epi32_mask(mids | ends, before, zero);
        const __mmask16 writers = opens | (mids & continues);
        const __m512i slot = _mm512_mask_sub_epi32(before, continues, before, one);
        const __m512i matches = _mm512_and_epi32(_mm512_conflict_epi32(slot), _mm512_set1_epi32((int32_t)writers));
        const __mmask16 local = _mm512_mask_test_epi32_mask(continues, matches, matches);
        const __m512i previous_lane = _mm512_sub_epi32(_mm512_set1_epi32(31), _mm512_lzcnt_epi32(matches));
        __m512i previous = _mm512_add_epi32(previous_lane, _mm512_set1_epi32((int32_t)first));
        const __mmask16 incoming = continues & ~local;
        previous = _mm512_mask_i32gather_epi32(previous, incoming, slot, open + base, 4);
        // Directive numbers cover uint32_t, including indices above the signed dword gather limit.
        _mm512_mask_i64scatter_epi32(data->directive_next, (__mmask8)continues, _mm512_cvtepu32_epi64(_mm512_castsi512_si256(previous)), _mm512_castsi512_si256(ids), 4);
        _mm512_mask_i64scatter_epi32(data->directive_next, (__mmask8)(continues >> 8), _mm512_cvtepu32_epi64(_mm512_extracti64x4_epi64(previous, 1)), _mm512_extracti64x4_epi64(ids, 1), 4);
        if ((mids & continues) != 0 && !notable)
        {
            const __mmask16 elses = _mm_mask_cmpeq_epi8_mask(conditionals, bytes, _mm_set1_epi8(PP_DIRECTIVE_ELSE));
            const __m512i previous_bit = _mm512_sllv_epi32(one, previous_lane);
            notable = _mm512_mask_test_epi32_mask(mids & local, previous_bit, _mm512_set1_epi32((int32_t)elses)) != 0;
            uint32_t outside = mids & incoming;
            while (!notable && outside != 0)
            {
                const uint32_t lane = (uint32_t)__builtin_ctz(outside);
                const uint32_t id = (uint32_t)_mm_cvtsi128_si32(_mm512_castsi512_si128(_mm512_permutexvar_epi32(_mm512_set1_epi32((int32_t)lane), previous)));
                notable = data->directive_kind[id] == PP_DIRECTIVE_ELSE;
                outside &= outside - 1;
            }
        }
        const uint32_t consumed = (uint32_t)_mm512_mask_reduce_or_epi32(local, _mm512_sllv_epi32(one, previous_lane));
        _mm512_mask_i32scatter_epi32(open + base, writers & ~consumed, slot, ids, 4);
        depth = base + (uint32_t)_mm_cvtsi128_si32(_mm512_extracti32x4_epi32(_mm512_shuffle_epi32(after, _MM_SHUFFLE(3,3,3,3)), 3));
    }
    return notable || depth != 0;
}
