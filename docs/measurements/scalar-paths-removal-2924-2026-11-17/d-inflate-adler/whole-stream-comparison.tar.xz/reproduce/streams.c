#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <immintrin.h>
typedef int Decompress(const uint8_t*,uint64_t,uint8_t*,uint64_t);
Decompress before_inflate,after_inflate;
typedef struct {uint8_t* compressed;const uint8_t* expected;uint32_t length,size;} Stream;
static uint64_t ticks(void) { _mm_lfence();uint64_t r=__rdtsc();_mm_lfence();return r;}
int main(int argc,char** argv) {
    if(argc!=3)return 2;
    unsigned seed=(unsigned)strtoul(argv[2],0,10);
    FILE* in=fopen(argv[1],"rb");if(!in)return 2;
    if(fseek(in,0,SEEK_END))return 2;long length=ftell(in);rewind(in);
    if(length<=0)return 2;uint8_t* blob=malloc((size_t)length);if(!blob||fread(blob,1,length,in)!=(size_t)length)return 2;
    fclose(in);Stream* rows=calloc(5000,sizeof(*rows));if(!rows)return 2;
    size_t pos=0;unsigned count=0,max=0;uint64_t plain=0;
    while(pos<(size_t)length) {
        if((size_t)length-pos<8||count==5000)return 2;
        Stream* v=&rows[count++];memcpy(&v->length,blob+pos,4);memcpy(&v->size,blob+pos+4,4);pos+=8;
        if(v->length<6||(uint64_t)v->length+v->size>(size_t)length-pos)return 2;
        v->compressed=blob+pos;pos+=v->length;v->expected=blob+pos;pos+=v->size;plain+=v->size;
        if(v->size>max)max=v->size;
    }
    uint8_t* out=malloc(max?max:1);if(!out)return 2;
    Decompress* fn[]={before_inflate,after_inflate};
    for(unsigned i=0;i<count;i++)for(unsigned side=0;side<2;side++){
        Stream* v=&rows[i];
        if(fn[side](v->compressed,v->length,out,v->size)||memcmp(out,v->expected,v->size))return 1;
        v->compressed[v->length-1]^=1;
        if(fn[side](v->compressed,v->length,out,v->size)==0)return 1;
        v->compressed[v->length-1]^=1;
    }
    uint64_t sink=0;
    for(unsigned r=0;r<15;r++){
        uint64_t sample[2];
        for(unsigned j=0;j<2;j++){
            unsigned side=(j+seed+r)&1;const uint64_t start=ticks();
            for(unsigned rep=0;rep<6;rep++)for(unsigned i=0;i<count;i++){
                Stream* v=&rows[i];
                if(fn[side](v->compressed,v->length,out,v->size))return 1;
                sink+=v->size?out[v->size-1]:0;
            }
            sample[side]=ticks()-start;
        }
        printf("%u %u %llu %llu %llu\n",r,count,(unsigned long long)plain,(unsigned long long)sample[0],(unsigned long long)sample[1]);
    }
    fprintf(stderr,"verified %u streams, %llu bytes, sink %llu\n",count,(unsigned long long)plain,(unsigned long long)sink);
    return 0;
}
