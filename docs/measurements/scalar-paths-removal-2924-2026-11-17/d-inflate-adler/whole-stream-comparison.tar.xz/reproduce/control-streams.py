from pathlib import Path
p=Path(__file__).parent
z=(p/'before-decode/inflate.c').read_text();a=z.index('static uint32_t inflate_adler32_vector(');b=z.index('\n}',a)+2
(p/'shared-inflate.c').write_text(z[:a]+'extern uint32_t (*selected_checksum)(const uint8_t*, uint64_t);\n#define inflate_adler32_vector selected_checksum\n'+z[b:])
(p/'shared-decode.c').write_text((p/'before-decode/decode.c').read_text().replace('"inflate.c"','"shared-inflate.c"').replace('before_inflate','shared_inflate'))
s=(p/'streams.c').read_text()
s=s.replace('Decompress before_inflate,after_inflate;', '''Decompress shared_inflate;
typedef uint32_t Checksum(const uint8_t*,uint64_t);
Checksum base, adler_base_copy, final, fcopy;
Checksum *selected_checksum;''')
s=s.replace('Decompress* fn[]={before_inflate,after_inflate};','Checksum* fn[]={base,final,adler_base_copy,fcopy};').replace('side<2','side<4').replace('Stream* v=&rows[i];\n        if(fn[side]','selected_checksum=fn[side];Stream* v=&rows[i];\n        if(shared_inflate').replace('if(fn[side]','if(shared_inflate')
s=s.replace('r<15','r<16').replace('uint64_t sample[2]','uint64_t sample[4]').replace('j<2','j<4').replace('unsigned side=(j+seed+r)&1;','static const unsigned order[4][4]={{0,1,3,2},{1,2,0,3},{2,3,1,0},{3,0,2,1}}; unsigned side=order[(r+seed)%4][j];selected_checksum=fn[side];')
s=s.replace('%llu %llu %llu\\n",r,count','%llu %llu %llu %llu %llu\\n",r,count').replace('(unsigned long long)sample[1]);','(unsigned long long)sample[1],(unsigned long long)sample[2],(unsigned long long)sample[3]);')
(p/'control-streams.c').write_text(s)
