#include <immintrin.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "shared-inflate.c"
int shared_inflate(const uint8_t* in, uint64_t n, uint8_t* out, uint64_t m)
{
    return inflate_zlib(in,n,out,m);
}
