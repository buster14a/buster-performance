from pathlib import Path
import csv,struct,zlib,subprocess,hashlib
root=Path('/dev/shm/buster-emission-6b097f86')
rows={(r['corpus'],r['object'],r['section']):r for r in csv.DictReader(open('sections.tsv'),delimiter='\t')}
found=0
for corpus in ('lua','sqlite','musl'):
 with open(corpus+'.streams','wb') as out:
  for obj in sorted((root/('out-'+corpus)).glob('*.o')):
   subprocess.run(['objcopy','--compress-debug-sections=zlib',obj,'streams-input.o'],check=True)
   f=Path('streams-input.o').read_bytes()
   off=struct.unpack_from('<Q',f,40)[0];width,num,names=struct.unpack_from('<HHH',f,58)
   h=[struct.unpack_from('<IIQQQQIIQQ',f,off+i*width) for i in range(num)]
   tab=f[h[names][4]:h[names][4]+h[names][5]]
   for name,_,flags,_,start,size,*_ in h:
    if flags&0x800:
     sect=tab[name:tab.index(b'\0',name)].decode()
     k=(corpus,obj.name,sect);meta=rows[k]; data=f[start+24:start+size]; plain=zlib.decompress(data)
     assert len(data)==int(meta['compressed']) and hashlib.sha256(plain).hexdigest()==meta['sha256']
     out.write(struct.pack('<II',len(data),len(plain)));out.write(data);out.write(plain);found+=1
Path('streams-input.o').unlink();assert found==len(rows)==4759
