#include <stdint.h>
#include <immintrin.h>
uint32_t paired(const uint8_t* bytes, uint64_t length)
{
    const __m512i weights = _mm512_set_epi8(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
                                            33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64);
    uint64_t a = 1;
    uint64_t b = 0;
    uint64_t at = 0;
    while (length - at >= 64)
    {
        const uint64_t chunks = (length - at) / 64 < 4096 ? (length - at) / 64 : 4096;
        __m512i sums = _mm512_setzero_si512();
        __m512i before = _mm512_setzero_si512();
        __m512i weighted = _mm512_setzero_si512();
        for (uint64_t chunk = 0; chunk < chunks; chunk += 1)
        {
            const __m512i data = _mm512_loadu_si512(bytes + at + chunk * 64);
            before = _mm512_add_epi64(before, sums);
            sums = _mm512_add_epi64(sums, _mm512_sad_epu8(data, _mm512_setzero_si512()));
            weighted = _mm512_dpbusd_epi32(weighted, data, weights);
        }
        const uint64_t sum = (uint64_t)_mm512_reduce_add_epi64(sums);
        const uint64_t prefixes = (uint64_t)_mm512_reduce_add_epi64(before);
        const uint64_t weight = (uint64_t)(uint32_t)_mm512_reduce_add_epi32(weighted);
        b = (b + chunks * 64 * a + 64 * prefixes + weight) % 65521;
        a = (a + sum) % 65521;
        at += chunks * 64;
    }
    const uint32_t tail = (uint32_t)(length - at);
    if (tail != 0)
    {
        const uint32_t lane = (uint32_t)((uintptr_t)(bytes + at) & 63);
        const uint32_t space = 64 - tail;
        const uint32_t shift = lane < space ? lane : space;
        const __mmask64 live = (__mmask64)(_bzhi_u64(UINT64_MAX, tail) << shift);
        const uint8_t* window = (const uint8_t*)((uintptr_t)(bytes + at) - shift);
        const __m512i data = _mm512_maskz_loadu_epi8(live, window);
        const __m512i tail_weights = _mm512_sub_epi8(weights, _mm512_set1_epi8((char)(space - shift)));
        const __m512i weighted = _mm512_dpbusd_epi32(_mm512_setzero_si512(), data, tail_weights);
        const __m512i summed = _mm512_dpbusd_epi32(_mm512_setzero_si512(), data, _mm512_set1_epi8(1));
        const __m512i paired = _mm512_mask_blend_epi32(0xaaaa, _mm512_add_epi32(summed, _mm512_srli_epi64(summed, 32)),
                _mm512_add_epi32(weighted, _mm512_slli_epi64(weighted, 32)));
        const uint64_t both = (uint64_t)_mm512_reduce_add_epi64(paired);
        b += (uint64_t)tail * a + (both >> 32);
        a += (uint32_t)both;
    }
    // Before the tail both values were reduced. After at most 63 bytes,
    // folding the high 16 bits of b once leaves less than twice the modulus.
    b = (b & 65535) + 15 * (b >> 16);
    a -= a >= 65521 ? 65521 : 0;
    b -= b >= 65521 ? 65521 : 0;
    return (uint32_t)(b << 16 | a);
}
