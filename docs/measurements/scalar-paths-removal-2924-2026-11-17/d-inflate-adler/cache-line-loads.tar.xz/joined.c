#include <stdint.h>
#include <immintrin.h>
uint32_t joined(const uint8_t* bytes, uint64_t length)
{
    const __m512i weights = _mm512_set_epi8(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
                                            33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64);
    uint64_t a = 1;
    uint64_t b = 0;
    uint64_t at = 0;
    do
    {
        const uint64_t chunks = (length - at) / 64 < 4096 ? (length - at) / 64 : 4096;
        __m512i sums = _mm512_setzero_si512();
        __m512i before = _mm512_setzero_si512();
        __m512i weighted = _mm512_setzero_si512();
        for (uint64_t chunk = 0; chunk < chunks; chunk += 1)
        {
            const __m512i data = _mm512_loadu_si512(bytes + at + chunk * 64);
            before = _mm512_add_epi64(before, sums);
            sums = _mm512_add_epi64(sums, _mm512_sad_epu8(data, _mm512_setzero_si512()));
            weighted = _mm512_dpbusd_epi32(weighted, data, weights);
        }
        at += chunks * 64;
        const uint32_t tail = length - at < 64 ? (uint32_t)(length - at) : 0;
    if (tail != 0)
    {
        const uint32_t lane = (uint32_t)((uintptr_t)(bytes + at) & 63);
        const uint32_t space = 64 - tail;
        const uint32_t shift = lane < space ? lane : space;
        const __mmask64 live = (__mmask64)(_bzhi_u64(UINT64_MAX, tail) << shift);
        const uint8_t* window = (const uint8_t*)((uintptr_t)(bytes + at) - shift);
        const __m512i data = _mm512_maskz_loadu_epi8(live, window);
        const __m512i tail_weights = _mm512_sub_epi8(weights, _mm512_set1_epi8((char)(space - shift)));
        // Previous full chunks precede every tail byte. Keep their factor separate
        // until folding once at the block boundary.
        const uint64_t full_sum = (uint64_t)_mm512_reduce_add_epi64(sums);
        b += tail * full_sum;
        sums = _mm512_add_epi64(sums, _mm512_sad_epu8(data, _mm512_setzero_si512()));
        weighted = _mm512_dpbusd_epi32(weighted, data, tail_weights);
        at += tail;
    }
        const uint64_t sum = (uint64_t)_mm512_reduce_add_epi64(sums);
        const uint64_t prefixes = (uint64_t)_mm512_reduce_add_epi64(before);
        const uint64_t weight = (uint64_t)(uint32_t)_mm512_reduce_add_epi32(weighted);
        b = (b + (chunks * 64 + tail) * a + 64 * prefixes + weight) % 65521;
        a = (a + sum) % 65521;

    } while (at < length);
    return (uint32_t)(b << 16 | a);
}
