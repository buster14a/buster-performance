#include <stdint.h>
#include <immintrin.h>
uint32_t word_gather(const uint8_t* bytes, uint64_t length)
{
    const __m512i weights = _mm512_set_epi8(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
                                            33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64);
    uint64_t a = 1;
    uint64_t b = 0;
    uint64_t at = 0;
    // Reduce the prefix before the four-byte words, in parallel for the two Adler sums.
    const unsigned small = (unsigned)length & 3u;
    if (small != 0)
    {
        const uint32_t packed = (uint32_t)bytes[0] | ((uint32_t)bytes[small >> 1] << 8) | ((uint32_t)bytes[small-1] << 16);
        const __m128i data = _mm_set1_epi32((int)packed);
        static const uint64_t factors[4] = {
            0, UINT64_C(0x0000000100000001), UINT64_C(0x0001000200010001), UINT64_C(0x0001020300010101)
        };
        const __m128i coefficients = _mm_cvtsi64_si128((long long)factors[small]);
        const __m128i totals = _mm_dpbusd_epi32(_mm_setzero_si128(), data, coefficients);
        a += (uint32_t)_mm_cvtsi128_si32(totals);
        b = small + (uint32_t)_mm_extract_epi32(totals, 1);
    }
    at = small;
    const uint32_t tail = (uint32_t)(length & 60);
    if (tail != 0)
    {
        const uint32_t lane = (uint32_t)((uintptr_t)(bytes + at) & 63);
        const uint32_t space = 64 - tail;
        const uint32_t shift = lane < space ? lane : space;
        const __mmask64 live = (__mmask64)(_bzhi_u64(UINT64_MAX, tail) << shift);
        const uint8_t* window = (const uint8_t*)((uintptr_t)(bytes + at) - shift);
        const __m512i data = _mm512_maskz_loadu_epi8(live, window);
        const __m512i tail_weights = _mm512_sub_epi8(weights, _mm512_set1_epi8((char)(space - shift)));
        const __m512i sum = _mm512_sad_epu8(data, _mm512_setzero_si512());
        const __m512i weighted = _mm512_dpbusd_epi32(_mm512_setzero_si512(), data, tail_weights);
        b += tail * a + (uint32_t)_mm512_reduce_add_epi32(weighted);
        a += (uint64_t)_mm512_reduce_add_epi64(sum);
        uint32_t prefix_sum = (uint32_t)b;
        prefix_sum = (prefix_sum & 65535u) + 15u * (prefix_sum >> 16);
        b = prefix_sum - (prefix_sum >= 65521 ? 65521u : 0u);
    }
    at += tail;
    while (length - at >= 64)
    {
        const uint64_t chunks = (length - at) / 64 < 4096 ? (length - at) / 64 : 4096;
        __m512i sums = _mm512_setzero_si512();
        __m512i before = _mm512_setzero_si512();
        __m512i weighted = _mm512_setzero_si512();
        for (uint64_t chunk = 0; chunk < chunks; chunk += 1)
        {
            const __m512i data = _mm512_loadu_si512(bytes + at + chunk * 64);
            before = _mm512_add_epi64(before, sums);
            sums = _mm512_add_epi64(sums, _mm512_sad_epu8(data, _mm512_setzero_si512()));
            weighted = _mm512_dpbusd_epi32(weighted, data, weights);
        }
        const uint64_t sum = (uint64_t)_mm512_reduce_add_epi64(sums);
        const uint64_t prefixes = (uint64_t)_mm512_reduce_add_epi64(before);
        const uint64_t weight = (uint64_t)(uint32_t)_mm512_reduce_add_epi32(weighted);
        b = (b + chunks * 64 * a + 64 * prefixes + weight) % 65521;
        a = (a + sum) % 65521;
        at += chunks * 64;
    }
    return (uint32_t)(b << 16 | a);
}
