from pathlib import Path
import csv
p=Path(__file__).parent
sizes={int(r['plain']) for r in csv.DictReader((p/'sections.tsv').open(),delimiter='\t')}
sizes.update(range(1025))
for base in (1024,2048,4096,8192,16384,32768,65536,262144,524288,786432):sizes.update(range(base-1,base+65))
(p/'dense-sizes.txt').write_text(''.join(f'{n}\n' for n in sorted(sizes)))
s=(p/'gate-full.c').read_text().replace('base,full_skip,full_pair,full_odd,full_after','base,final,adler_base_copy,fcopy,full_odd').replace('cap=200*pg','cap=600*pg')
a=s.index('    unsigned sizes[3000]');b=s.index('    for(unsigned pat',a)
s=s[:a]+'''    unsigned sizes[4096],count=0;
    FILE* input = fopen("dense-sizes.txt","r");
    if (!input) return 2;
    unsigned item;
    while (fscanf(input,"%u",&item)==1) {
        if (count==4096 || item>cap) return 2;
        sizes[count++]=item;
    }
    fclose(input);
'''+s[b:]
s=s.replace('unsigned reps=32+12000/(1+n/16);','unsigned reps=8+16000/(1+n/16);')
(p/'gate-dense.c').write_text(s)
(p/'bcopy.c').write_text((p/'base.c').read_text().replace('uint32_t base(', 'uint32_t adler_base_copy('))
(p/'fcopy.c').write_text((p/'final.c').read_text().replace('uint32_t final(', 'uint32_t fcopy('))
print(len(sizes),max(sizes))
