from pathlib import Path
import subprocess
p=Path(__file__).parent;d=p/'mutations';d.mkdir(exist_ok=True)
src=(p/'final.c').read_text();t=(p/'gate-full.c').read_text()
t=t.replace('base,full_skip,full_pair,full_odd,full_after','final').replace('s<5;s++','s<1;s++')
(d/'check.c').write_text(t)
cases={'control':None,
 'skip-leading-word':('pos = 0; pos < words','pos = 4; pos < words'),
 'upper-prefix-byte':('rest[short_count - 1]','rest[0]'),
 'two-byte-coefficients':('2, 0, 1, 0 },','2, 0, 2, 0 },'),
 'descending-weights':('0x03020100u','0x01020300u'),
 'pair-order':('even_sums, first_sum','even_sums, second_sum'),
 'odd-final':('if (chunk < chunks)','if (chunk + 1 < chunks)'),
 'prior-pair':('_mm512_add_epi64(before, before), even_sums','before, even_sums'),
 'carry-a':('chunks * 64 * a','chunks * 64'),
 'modulus':('accumulated % 65521','accumulated % 65519')}
for tag,change in cases.items():
 s=src
 if change:
  a,b=change;assert s.count(a)==1,(tag,a);s=s.replace(a,b)
 (d/'target.c').write_text(s)
 subprocess.run(['clang-22','-O2','-march=native','-fsanitize=address,undefined','-fno-sanitize-recover=all',str(d/'target.c'),str(d/'check.c'),'-o',str(d/'verify')],check=True)
 run=subprocess.run([str(d/'verify'),'check','779'],capture_output=True,text=True)
 assert (run.returncode==0)==(tag=='control'),(tag,run.returncode)
 print(tag,run.returncode,run.stderr.splitlines()[0],flush=True)
