#include <stdint.h>
#include <immintrin.h>
uint32_t prefix_tiles(const uint8_t* bytes, uint64_t length)
{
    const __m512i weights = _mm512_set_epi8(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
                                            33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64);
    uint64_t a = 1;
    uint64_t b = 0;
    uint64_t at = 0;
    const uint32_t tail = (uint32_t)(length & 63);
    if (tail != 0)
    {
        const uint32_t lane = (uint32_t)((uintptr_t)(bytes + at) & 15);
        const uint8_t* line = (const uint8_t*)((uintptr_t)(bytes + at) - lane);
        const uint32_t extent = tail + lane;
        __m256i totals = _mm256_setzero_si256();
        const __m128i descending = _mm_set_epi8(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16);
        for (uint32_t first = 0; first < extent; first += 16)
        {
            const uint32_t begin = first == 0 ? lane : 0;
            const uint32_t remain = extent - first;
            const uint32_t live = _bzhi_u32(65535u, remain) & ~_bzhi_u32(65535u, begin);
            const __m128i data = _mm_maskz_loadu_epi8((__mmask16)live, line + first);
            const __m128i weight = _mm_add_epi8(descending, _mm_set1_epi8((char)(remain - 16)));
            const __m256i bytes_twice = _mm256_broadcastsi128_si256(data);
            const __m256i factors = _mm256_set_m128i(weight, _mm_set1_epi8(1));
            totals = _mm256_dpbusd_epi32(totals, bytes_twice, factors);
        }
        const __m128i sum = _mm256_castsi256_si128(totals);
        const __m128i weighted = _mm256_extracti128_si256(totals, 1);
        const __m128i pairs = _mm_hadd_epi32(sum, weighted);
        const __m128i both = _mm_hadd_epi32(pairs, pairs);
        const uint64_t packed = (uint64_t)_mm_cvtsi128_si64(both);
        b = tail + (packed >> 32);
        a += (uint32_t)packed;
        uint32_t prefix_sum = (uint32_t)b;
        prefix_sum = (prefix_sum & 65535u) + 15u * (prefix_sum >> 16);
        b = prefix_sum - (prefix_sum >= 65521 ? 65521u : 0u);
    }
    at = tail;
    while (length - at >= 64)
    {
        const uint64_t chunks = (length - at) / 64 < 4096 ? (length - at) / 64 : 4096;
        __m512i sums = _mm512_setzero_si512();
        __m512i before = _mm512_setzero_si512();
        __m512i weighted = _mm512_setzero_si512();
        for (uint64_t chunk = 0; chunk < chunks; chunk += 1)
        {
            const __m512i data = _mm512_loadu_si512(bytes + at + chunk * 64);
            before = _mm512_add_epi64(before, sums);
            sums = _mm512_add_epi64(sums, _mm512_sad_epu8(data, _mm512_setzero_si512()));
            weighted = _mm512_dpbusd_epi32(weighted, data, weights);
        }
        const uint64_t sum = (uint64_t)_mm512_reduce_add_epi64(sums);
        const uint64_t prefixes = (uint64_t)_mm512_reduce_add_epi64(before);
        const uint64_t weight = (uint64_t)(uint32_t)_mm512_reduce_add_epi32(weighted);
        b = (b + chunks * 64 * a + 64 * prefixes + weight) % 65521;
        a = (a + sum) % 65521;
        at += chunks * 64;
    }
    return (uint32_t)(b << 16 | a);
}
