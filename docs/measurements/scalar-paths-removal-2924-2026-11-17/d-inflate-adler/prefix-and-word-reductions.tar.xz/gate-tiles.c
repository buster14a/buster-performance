#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
typedef uint32_t Checksum(const uint8_t*,uint64_t);
Checksum base,safe,tiles,pairs32,plain16;
static Checksum* const functions[]={base,safe,tiles,pairs32,plain16};
static uint32_t oracle(const uint8_t* p,size_t n)
{
    uint32_t a=1,b=0;
    for (size_t i=0;i<n;i++) {a=(a+p[i])%65521;b=(b+a)%65521;}
    return (b<<16)|a;
}
static uint64_t ticks(void)
{
    _mm_lfence();
    uint64_t v=__rdtsc();
    _mm_lfence();
    return v;
}
static int compare(const void* x,const void* y)
{
    uint64_t a=*(const uint64_t*)x,b=*(const uint64_t*)y;
    return (a>b)-(a<b);
}
int main(int argc,char**argv)
{
    const size_t pg=(size_t)sysconf(_SC_PAGESIZE),cap=200*pg;
    uint8_t* map=mmap(NULL,cap+2*pg,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(map==MAP_FAILED||mprotect(map+pg,cap,PROT_READ|PROT_WRITE)) return 2;
    uint8_t* p=map+pg;
    const int timed=argc>1&&!strcmp(argv[1],"time");
    const unsigned seed=argc>2?(unsigned)strtoul(argv[2],NULL,0):1;
    uint32_t r=seed;uint64_t checked=0,sink=0;
    unsigned sizes[3000],count=0;
    for(unsigned n=0;n<=(timed?127:300);n++) sizes[count++]=n;
    unsigned blocks[]={256,1024,5552,16384,262144,524288,786432};
    for(unsigned k=0;k<sizeof(blocks)/sizeof(*blocks);k++) {
        if(timed&&k!=1&&k!=2&&k!=4)continue;
        for(int j=-(timed?2:4);j<=(timed?3:4);j++)sizes[count++]=blocks[k]+j;
    }
    for(unsigned pat=0;pat<(timed?1u:3u);pat++) {
        for(size_t i=0;i<cap;i++){r^=r<<13;r^=r>>17;r^=r<<5;p[i]=pat==1?255:pat==2?0:(uint8_t)r;}
        for(unsigned k=0;k<count;k++)for(unsigned phase=0;phase<(timed?3u:8u);phase++){
            unsigned n=sizes[k];const uint8_t* bytes=phase==0?p:phase==1?p+cap-n:phase==2?p+17:phase==3&&!n?NULL:p+phase*7;
            uint32_t expect=oracle(bytes,n);
            for(unsigned s=0;s<5;s++){uint32_t got=functions[s](bytes,n);if(got!=expect){fprintf(stderr,"size=%u phase=%u side=%u got=%08x expected=%08x\n",n,phase,s,got,expect);return 1;}checked++;}
            if(!timed)continue;
            unsigned reps=32+12000/(1+n/16);uint64_t clocks[5][9];
            for(unsigned j=0;j<9;j++)for(unsigned i=0;i<5;i++){
                unsigned s=(i+j+seed+k)%5;uint64_t t=ticks();
                for(unsigned rep=0;rep<reps;rep++)sink+=functions[s](bytes,n);
                clocks[s][j]=ticks()-t;
            }
            printf("%u %u %u",n,phase,reps);
            for(unsigned s=0;s<5;s++){qsort(clocks[s],9,sizeof(uint64_t),compare);printf(" %lu",clocks[s][4]);}
            putchar('\n');
        }
    }
    fprintf(stderr,"%lu RFC comparisons passed; sink %lu\n",checked,sink);
    return 0;
}
