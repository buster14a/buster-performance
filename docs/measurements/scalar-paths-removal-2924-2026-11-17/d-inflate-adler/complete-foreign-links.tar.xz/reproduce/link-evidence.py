from pathlib import Path
import subprocess,struct,zlib,hashlib,json
p=Path('/dev/shm/buster-adler-production-6b097f86/links')
for g in ('lua','sqlite','musl'):
 d=p/g
 if not (d/'outputs.sha').exists(): continue
 sections=raw=inflated=0
 for f in sorted(d.glob('*.o')):
  b=f.read_bytes(); off=struct.unpack_from('<Q',b,40)[0];w,n=struct.unpack_from('<HH',b,58)
  for i in range(n):
   h=struct.unpack_from('<IIQQQQIIQQ',b,off+w*i)
   if h[2]&0x800:
    start,size=h[4:6];typ,_,nbytes,_align=struct.unpack_from('<IIQQ',b,start); assert typ==1
    stream=b[start+24:start+size];actual=zlib.decompress(stream);assert len(actual)==nbytes
    sections+=1;raw+=len(stream);inflated+=nbytes
 sym={'lua':'lua_gettop','sqlite':'sqlite3_open','musl':'strspn'}[g]
 rows={}
 for side in ('base','head','external-ref'):
  q=subprocess.run(['gdb','-q','-nx','-batch','-ex','info line '+sym,str(d/side)],capture_output=True,text=True,check=True)
  assert 'Line ' in q.stdout and 'starts at address' in q.stdout,(g,side,q.stdout)
  rows[side]=q.stdout.strip()
 assert rows['base']==rows['head']
 print(json.dumps(dict(corpus=g,objects=len(list(d.glob('*.o'))),sections=sections,compressed=raw,plain=inflated,sha256=hashlib.sha256((d/'head').read_bytes()).hexdigest(),lines=rows),sort_keys=True))
