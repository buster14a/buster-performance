import csv, ctypes, hashlib, os, struct, subprocess, zlib
from pathlib import Path
p=Path.cwd(); so=ctypes.CDLL(str(p/'decode.so'))
so.decompress.argtypes=(ctypes.c_char_p,ctypes.c_uint64,ctypes.c_char_p,ctypes.c_uint64)
root=Path('/dev/shm/buster-emission-6b097f86')
with open('sections.tsv','w') as out:
    w=csv.writer(out,delimiter='\t');w.writerow(('corpus','object','section','compressed','plain','remainder','adler32','sha256'))
    for group,count in [('lua',34),('sqlite',1),('musl',1336)]:
        files=sorted((root/('out-'+group)).glob('*.o'))
        assert len(files)==count
        sizes=[]
        for f in files:
            subprocess.run(['objcopy','--compress-debug-sections=zlib',f,'section.o'],check=True)
            blob=Path('section.o').read_bytes()
            assert blob[:6]==b'\x7fELF\x02\x01'
            off,=struct.unpack_from('<Q',blob,40)
            width,num,names=struct.unpack_from('<HHH',blob,58)
            headers=[struct.unpack_from('<IIQQQQIIQQ',blob,off+i*width) for i in range(num)]
            names=blob[headers[names][4]:headers[names][4]+headers[names][5]]
            for name,_,flags,_,start,size,*_ in headers:
                if flags & 0x800:
                    kind,_,wanted,_=struct.unpack_from('<IIQQ',blob,start)
                    assert kind==1
                    data=blob[start+24:start+size];expect=zlib.decompress(data)
                    assert len(expect)==wanted
                    got=ctypes.create_string_buffer(wanted or 1)
                    assert so.decompress(data,len(data),got,wanted)==0
                    assert got.raw[:wanted]==expect
                    w.writerow((group,f.name,names[name:names.index(b'\x00',name)].decode(),len(data),wanted,wanted%64,format(zlib.adler32(expect),'08x'),hashlib.sha256(expect).hexdigest()))
                    sizes.append(wanted)
        print(group,len(files),len(sizes),sum(sizes),len(set(i%64 for i in sizes)),flush=True)
Path('section.o').unlink()
