from pathlib import Path
from collections import Counter,defaultdict
import re,tarfile
p=Path(__file__).parent;r=p/'results'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-flagged-declarations')
source=(p/'tree/src/buster/compiler/c_parser.c').read_text()
enum=source.split('#define BUSTER_PARSE_KINDS(X)')[1].split('typedef enum ParseKind')[0]
names=re.findall(r'\bX\((\w+)\)',enum)
assert names[61]=='ASM' and names[5]=='STRING'
def parse(group,n):
 raw=(r/(group+'-census.log')).read_text()
 units={};items=[];flags=[];uniquetokens=set();sites=set()
 for line in raw.splitlines():
  row=line.split('\t')
  if row[0] not in ('unit','item','flag'):continue
  tag,path,*data=row;data=tuple(map(int,data))
  if tag=='unit':
   assert path not in units
   units[path]=data
  elif tag=='item':
   assert len(data)==10 and (path,*data[:2]) not in sites
   sites.add((path,*data[:2]));items.append((path,*data))
  else:
   assert len(data)==8 and (path,data[2]) not in uniquetokens
   uniquetokens.add((path,data[2]));flags.append((path,*data))
 assert len(units)==n and set(x[0]for x in items).issubset(units)
 for path,(tokens,flagged,items_n,reparsed,whole,errors) in units.items():
  sub=[i for i in items if i[0]==path]
  assert sum(i[2]-i[1]+1 for i in sub)==reparsed and len(sub)==items_n,(group,path,units[path],len(sub))
  assert all(0<=i[1]<=i[2]<tokens for i in sub)
 for f in flags:assert (f[0],f[1],f[2]) in sites
 changed=sum(any(i[-3:])for i in items if i[3]==0)
 identical=sum(not any(i[-3:])for i in items if i[3]==0)
 rows=[sum(v[j]for v in units.values())for j in range(6)]
 stat=[n,rows[0],sum(v[2]>0 for v in units.values()),rows[2],rows[3],changed,identical,rows[4],sum(v[5]>0 for v in units.values())]
 c=Counter(f[4] for f in flags)
 per_item=defaultdict(set)
 for fl in flags:per_item[fl[0],fl[1],fl[2]].add(fl[4])
 asm_items=sum(names.index('ASM') in ks for ks in per_item.values())
 return stat,c,asm_items
rows=[]; tally=Counter()
for g,n in [('lua',34),('sqlite',1),('musl',1336)]:
 stat,counts,asm_items=parse(g,n);stat.append(asm_items);rows.append('| '+g+' | '+' | '.join(f'{x:,}'for x in stat)+' |');tally.update(counts)
header='## Fallback declarations on compiler sources'
doc=out/'README.md';assert header not in doc.read_text()
table='| Corpus | Files | Tokens | Files reparsed | Items reparsed | Tokens reparsed | Items with changed tree columns | Items with identical columns | Whole units | Files with errors | Items with a flagged asm keyword |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n'+'\n'.join(rows)
raw='\n'.join('| '+(names[k].replace('PARSE_KIND_','') if k<len(names)else str(k))+' | '+str(k)+' | '+f'{n:,}'+' |'for k,n in tally.most_common())
body='''The parent compiler parsed each preprocessed translation unit on the locked 9700X. The probe recorded every flagged token in the ordinary item path and compared the vector roles, depths and parents with the columns after scalar repair. The tree comparison excludes whole-unit kernel failures. A matching tree alone does not establish that a fallback can be removed, since parsing also checks diagnostics and type-name visibility.
'''
with tarfile.open(out/'source-census.tar.xz','w:xz',preset=2)as tar:
 for n in ['census.py','census.c','census-task','run-census','record-census.py']:tar.add(p/n,'source/'+n)
 for g in ['fixtures','lua','sqlite','musl']:tar.add(r/(g+'-census.log'),'native/'+g+'-census.log')
with doc.open('a')as f:f.write('\n'+header+'\n\n'+body+'\n'+table+'\n\n| Flagged input kind | Kind index | Occurrences |\n| --- | ---: | ---: |\n'+raw+'\n\n[Source inputs, native commands and per-token and declaration records](source-census.tar.xz)\n')
print(*rows,sep='\n')
