from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent;q=Path('/tmp/buster-parser-depths')
r=p/'census-src/buster/compiler';r.mkdir(parents=True,exist_ok=True)
src=p/'tree/src/buster/compiler'
(r/'c_parser.c').write_bytes((src/'c_parser.c').read_bytes())
s=(src/'c_parser_impl.c').read_text()
pos=s.index('// The scalar parser on tokens [begin, end]')
s=s[:pos]+'''static const char* declaration_path;
static unsigned whole_reasons;
static uint8_t* prior_k2;
static uint8_t* prior_k6;
'''+s[pos:]
pos=s.index('    uint32_t diagnostic_count',pos)
s=s[:pos]+'''    const uint32_t length = end + 1u - begin;
    uint8_t* roles = NULL;
    uint32_t* depths = NULL;
    uint32_t* parents = NULL;
    if (whole_reasons == 0)
    {
        roles = malloc(length); depths = malloc((size_t)length * sizeof(*depths)); parents = malloc((size_t)length * sizeof(*parents));
        if (!roles || !depths || !parents) abort();
        memcpy(roles, tree.roles, length);
        memcpy(depths, tree.depths, (size_t)length * sizeof(*depths));
        memcpy(parents, tree.parents, (size_t)length * sizeof(*parents));
        for (uint32_t i = begin; i <= end; i++)
        {
            if (kernels->flags[i])
                printf("flag\\t%s\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\n", declaration_path, begin, end, i, input->kinds[i], kernels->vkinds[i], tree.roles[i-begin], prior_k2[i], prior_k6[i]);
        }
    }
'''+s[pos:]
pos=s.index('    result->items += 1;',pos)
s=s[:pos]+'''    uint32_t diff_roles=0, diff_depths=0, diff_parents=0;
    if (whole_reasons == 0)
    {
        for (uint32_t i = 0; i < length; i++)
        {
            diff_roles += roles[i] != tree.roles[i];
            diff_depths += depths[i] != tree.depths[i];
            diff_parents += parents[i] != tree.parents[i];
        }
        free(roles); free(depths); free(parents);
    }
    printf("item\\t%s\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\n", declaration_path, begin, end, whole_reasons, parse.errors, parse.out_of_memory, parse.retyped, parse.undecided, diff_roles, diff_depths, diff_parents);
'''+s[pos:]
n='    if (!result.everything)\n    {\n        parse_check_avx512'
i=s.index(n,s.index('static ParseKernelResult parse_vector_run('))
s=s[:i]+s[i:].replace(n,'''    whole_reasons = (unsigned)kernels->unbalanced | (unsigned)kernels->unsupported * 2 | (unsigned)!statements_ok * 4;
    if (!result.everything)
    {
        prior_k2 = malloc((size_t)count + 1); prior_k6 = malloc((size_t)count + 1);
        if (!prior_k2 || !prior_k6) abort();
        memcpy(prior_k2,kernels->flags,count);
        parse_check_avx512''',1)
i=s.index('        parse_flag_custom_attributes(kernels, input);',i)
s=s[:i]+'        memcpy(prior_k6,kernels->flags,count);\n'+s[i:]
i=s.index('    return result;',i);s=s[:i]+'''    free(prior_k2); free(prior_k6); prior_k2=NULL; prior_k6=NULL;
'''+s[i:]
(r/'c_parser_impl.c').write_text(s)
s=(src/'c_parser_benchmark.c').read_text().replace('            file->path = paths[f];','            file->path = paths[f];\n            declaration_path = file->path;',1).replace('            pp_release(&pp);','''            if (loaded) printf("unit\\t%s\\t%u\\t%llu\\t%llu\\t%llu\\t%u\\t%u\\n",file->path,file->parser.tokens.count, (unsigned long long)file->parser.statistics.flagged_tokens, (unsigned long long)file->parser.statistics.fallback_items,(unsigned long long)file->parser.statistics.fallback_tokens,(unsigned)file->parser.statistics.whole,file->parser.errors);
            pp_release(&pp);''',1).replace('        bench.file_count = path_count;','        return loaded ? 0 : 1;\n        bench.file_count = path_count;',1)
(p/'census.c').write_text(s+'\nint main(int argc,char**argv){return run_parser_benchmark(argc,argv);}\n')
for f in ['census-task','run-census']:
 s=(q/f).read_text().replace('buster-parser-depths','buster-flagged-declarations').replace('codex-k4-','codex-parser-declarations-').replace('/3442','/3441').replace('Count full-width K4 parent recovery on production files and deeply nested source','Count declarations that reach the parser fallback and compare each tree column')
 s=s.replace('for g in dense lua sqlite musl','for g in fixtures lua sqlite musl').replace('dense) args=("$root/dense.c");;','fixtures) args=("$root"/fixtures/*.c);;')
 (p/f).write_text(s)
files={'asm':'__asm__(".text");\nint f(int x) { __asm__ volatile ("" : "+r" (x)); return x; }','generic':'int f(int x) { return _Generic(x, int: 1, default: 2); }','restrict':'void f(int a[__restrict 16]);\nvoid g(int a[static __restrict 8]) { a[0] = 1; }','knr':'int f(a,b) int a; long b; { return a+b; }','c23':'[[maybe_unused]] int a;\nint f(void) { return a; }','availability':'__attribute__((availability(macos,introduced=10.12))) int f(void);','localtypedef':'int f(void) { typedef int word; word x = 3; return x; }','alignas':'typedef int T; _Alignas(16) T x;','group':'int (f)(void) { return 1; }'}
(p/'fixtures').mkdir(exist_ok=True)
for n,src in files.items():(p/'fixtures'/(n+'.c')).write_text(src+'\n')
