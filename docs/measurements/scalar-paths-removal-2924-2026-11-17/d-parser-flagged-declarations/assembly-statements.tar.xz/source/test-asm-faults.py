from pathlib import Path
from hashlib import sha256
import os,subprocess
p=Path(__file__).parent;d=p/'inline-fault-cases';d.mkdir(exist_ok=True)
cases=['__asm__("" "x");','__asm__(42);','void f(void){__asm__(""::: "cc");}', 'void f(int n){__asm__ volatile ("" : "=r"(n));}', 'void f(void){__asm__("" : "r"());}', 'void f(int n){__asm__("" : : "r" (n),);}', 'void f(void){__asm__(""::: ,);}', 'void f(void){__asm__(""::: "cc",);}', 'void f(void){__asm__ const ("");}', 'void f(void){__asm__(""::::);}', 'void f(void){__asm__(""::: : "bad");}', 'void f(void){typedef int T; T t; t = ; __asm__ ("");}', 'int g(,);', 'void f(void){__asm__("" : : : 42);}', 'void f(int n){__asm__("" : : "r");}', 'void f(int n){__asm__("" : : "r" n);}', 'void f(int n){__asm__("" : : 2);}', 'void f(void){__asm__ restrict ("x");}']
for i,text in enumerate(cases):(d/f'{i:02d}.c').write_text(text+'\n')
def run(tag,fault):
 ret=[]
 for case in sorted(d.glob('*.c')):
  tmp=d/'tree.bin';tmp.write_bytes(b'')
  proc=subprocess.run([str(p/(tag+'-columns')),'-std=gnu17','-nostdinc',str(case)],env={**os.environ,'BUSTER_DECL_TREE':str(tmp),'BUSTER_ASM_TEST_FAULT':fault},capture_output=True,check=True)
  row=[l.split(b'\t')[2:] for l in proc.stdout.splitlines()if l.startswith(b'unit\t')]
  assert len(row)==1
  ret.append((sha256(tmp.read_bytes()).hexdigest(),tuple(map(int,row[0]))))
 return ret
baseline=run('grouped','control');control=run('inline-mutant','control')
assert all(a[0]==b[0] for a,b in zip(baseline,control))
assert all(control[i][1][2:4]==(0,0) for i in [0,2,3])
assert all(baseline[i][1][2]>0 for i in [0,2,3])
for fault in ['file-template','operand','clobber','qualifier','section-count','skip-unresolved','block-coverage','file-coverage']:
 test=run('inline-mutant',fault);trees=[i for i,(a,b) in enumerate(zip(control,test))if a[0]!=b[0]];routes=[i for i,(a,b) in enumerate(zip(control,test))if a[1]!=b[1]]
 print(fault,'changed trees or diagnostics',trees,'changed parser statistics',routes,flush=True)
 assert trees or routes
