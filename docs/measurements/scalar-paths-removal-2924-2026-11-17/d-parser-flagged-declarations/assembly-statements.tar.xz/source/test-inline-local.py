from pathlib import Path
import subprocess,os,hashlib
p=Path(__file__).parent; cases=sorted((p/'inline-cases').glob('*.c'))
for dialect in ['c11','gnu11','c17','gnu17','c23','gnu23']:
 runs=[]
 for tag in ['grouped','inline']:
  out=p/(tag+'-'+dialect+'-inline.bin');out.write_bytes(b'');rows=[]
  for offset in range(0,len(cases),64):
   a=subprocess.run([str(p/(tag+'-columns')),'-std='+dialect,'-nostdinc',*map(str,cases[offset:offset+64])],env={**os.environ,'BUSTER_DECL_TREE':str(out)},stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
   rows.extend(line.split(b'\t')[2:] for line in a.stdout.splitlines() if line.startswith(b'unit\t'))
  assert len(rows)==len(cases)
  runs.append((hashlib.sha256(out.read_bytes()).hexdigest(),rows))
  (p/(tag+'-'+dialect+'-inline.tsv')).write_bytes(b'\n'.join(b'\t'.join(x)for x in rows)+b'\n')
 a,b=runs
 if a[0]!=b[0]:
  for case in cases:
   hashes=[]
   for tag in ['grouped','inline']:
    out=p/'inline-error-case.bin';out.write_bytes(b'')
    sub=subprocess.run([str(p/(tag+'-columns')),'-std='+dialect,'-nostdinc',str(case)],env={**os.environ,'BUSTER_DECL_TREE':str(out)},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
    hashes.append(hashlib.sha256(out.read_bytes()).digest())
   if hashes[0]!=hashes[1]:raise ValueError((dialect,case,case.read_text()))
  raise ValueError(dialect)
 assert all(r[:2]==s[:2] and r[4:]==s[4:] and int(s[2])<=int(r[2]) for r,s in zip(a[1],b[1]))
 print(dialect,len(cases),a[0],sum(int(r[2])-int(s[2])for r,s in zip(a[1],b[1])),sum(int(r[3])-int(s[3])for r,s in zip(a[1],b[1])),flush=True)
