from pathlib import Path
from shutil import copytree
p=Path(__file__).parent;d=p/'inline-mutant-src';copytree(p/'inline-src',d,dirs_exist_ok=True)
f=d/'buster/compiler/c_parser_impl.c';s=f.read_text();i=s.index('// K2 and K6 have already written the roles')
s=s[:i]+'''static bool asm_test_fault(const char* name)
{
    const char* fault = getenv("BUSTER_ASM_TEST_FAULT");
    return fault != NULL && strcmp(fault, name) == 0;
}
'''+s[i:]
changes=[
('file-template','if (_mm512_mask_cmpneq_epi8_mask(active,','if (!asm_test_fault("file-template") && _mm512_mask_cmpneq_epi8_mask(active,'),
('operand','    if (count == 0)\n    {\n        return true;\n    }\n    const uint64_t live','    if (count == 0 || asm_test_fault("operand")) return true;\n    const uint64_t live'),
('clobber','if (count % 2 == 0 || strings != expected || commas != (clobbers ^ expected))','if (!asm_test_fault("clobber") && (count % 2 == 0 || strings != expected || commas != (clobbers ^ expected)))'),
('qualifier','if (name != C_NAME_VOLATILE && name != C_NAME_GNU_VOLATILE && name != C_NAME_GNU_VOLATILE2)','if (!asm_test_fault("qualifier") && name != C_NAME_VOLATILE && name != C_NAME_GNU_VOLATILE && name != C_NAME_GNU_VOLATILE2)'),
('section-count','|| __builtin_popcountll(colons) > 3)','|| (!asm_test_fault("section-count") && __builtin_popcountll(colons) > 3))'),
('skip-unresolved','if (close == BUSTER_PARSE_NONE)\n            {\n                return false;','if (close == BUSTER_PARSE_NONE)\n            {\n                return asm_test_fault("skip-unresolved");'),
('block-coverage','if (keyword == 0 || keyword >= end','if (asm_test_fault("block-coverage") || keyword == 0 || keyword >= end'),
('file-coverage','if (end - begin < 4 || kinds[begin] != PARSE_KIND_ASM','if (asm_test_fault("file-coverage") || end - begin < 4 || kinds[begin] != PARSE_KIND_ASM')]
# Scope replacement to the two asm helpers and flag checker.
a=s.index('// K2 and K6 have already written the roles');b=s.index('static ParseFallback parse_fallback(',a)
h=s[a:b]
for name,old,new in changes:
 assert h.count(old)==1,(name,h.count(old));h=h.replace(old,new)
f.write_text(s[:a]+h+s[b:])
