from pathlib import Path
p=Path(__file__).parent;d=p/'asm-cases';d.mkdir(exist_ok=True)
i=0
for pre in ['', ';','typedef int T;','int g(void) { return 0; }','int g[] = {1, 2};','int a, ']:
 for name in ['asm','__asm','__asm__','asm volatile','__asm__ goto','q']:
  for body in ['""','"" "two"','L"wide"','u8"x"','"a" L"b"','123','"x" :','"x" : : "r"(q)','"" ;','']:
   for end in [');', ')',';','));']:
    (d/f'{i:04d}.c').write_text(pre+' '+name+'('+body+end+'\n');i+=1
