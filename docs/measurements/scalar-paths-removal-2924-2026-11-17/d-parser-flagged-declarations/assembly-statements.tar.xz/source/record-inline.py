from pathlib import Path
from hashlib import sha256
import tarfile

p=Path(__file__).parent
r=p/'results'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-flagged-declarations')
tree=p/'local-source-trees'
dialects=('c11','gnu11','c17','gnu17','c23','gnu23')
tags=('census','grouped','asm','inline')
rows=[]
for group,n in [('lua',34),('sqlite',1),('musl',1336)]:
    hashes={(tree/f'{tag}-{group}.sha').read_bytes() for tag in tags}
    assert len(hashes)==1
    totals=[]
    for tag in tags:
        units=[line.split('\t') for line in (tree/f'{tag}-{group}.tsv').read_text().splitlines()]
        assert len(units)==n and len({row[0] for row in units})==n
        if tag=='census': base=units
        for a,b in zip(base,units,strict=True):
            assert a[:2]==b[:2] and a[5:]==b[5:] and int(b[3])<=int(a[3]) and int(b[4])<=int(a[4])
        totals.append([sum(int(x[i]) for x in units) for i in (1,3,4)])
    a,b,c,d=totals
    rows.append('| '+group+' | '+' | '.join(f'{x:,}' for x in [n,a[0],a[1],b[1],c[1],d[1],a[2],d[2]])+' |')
aligned=(p/'grouped-aligned-results.tsv').read_bytes()
assert len(aligned.splitlines())==557 and all((p/f'{tag}-aligned-results.tsv').read_bytes()==aligned for tag in ('asm','inline'))
for family,size,tag in [('asm',1440,'asm'),('inline',6076,'inline')]:
    for standard in dialects:
        left,right=[p/f'{v}-{standard}-{family}.bin' for v in ['grouped',tag]]
        assert sha256(left.read_bytes()).digest()==sha256(right.read_bytes()).digest()
        for v in ['grouped',tag]:assert len((p/f'{v}-{standard}-{family}.tsv').read_text().splitlines())==size
mut=(p/'inline-faults.log').read_text().splitlines()
assert len(mut)==8 and sum('changed trees or diagnostics []' in s for s in mut)==2 and all('changed parser statistics []' not in s for s in mut)
for tag in ('asm','inline'):
    clang=(r/f'{tag}-clang.log').read_text()
    assert 'snippets: 557, 0 failures (with clang)' in clang and 'test-parser: passed' in clang
heading='## File-scope and block assembly statements'
body=heading+'''

The candidate recognizes file-scope assembly with string templates and block assembly statements whose operands and clobbers fit one 64-token window. It checks the statement boundary, modifier, parenthesis, strings, up to three operand sections and the terminator. An unresolved flag elsewhere in a declaration still sends that declaration to the repair parser.

Four builds parsed every translation unit in the pinned Lua, SQLite and musl inputs using the same headers and predefines. The probes serialized all returned tree columns and diagnostics. Their SHA-256 hashes matched in each workload. The table counts top-level reparses and their tokens. The assembly operand checks removed 6,791 reparses in musl beyond the grouped-declarator change.

| Corpus | Files | Input tokens | Parent items | Grouped names | File-scope asm | With block asm | Parent tokens reparsed | Final tokens reparsed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

The block candidate also matched the grouped-name revision on all 557 snippets at 64 token alignments, including their route counters. Separate differential cases covered 1,440 file-scope inputs and 6,076 block inputs in each of six C and GNU dialects. All serialized results matched their respective controls. Six faults in syntax validation changed a tree or diagnostic. Disabling either recognition path changed the positive fixtures' reparse counts. Both candidates passed the complete Clang-backed parser suite on the Ryzen 7 9700X.

These are coverage and correctness measurements. The native per-size and whole-compile measurements run separately.

[Production patch, probe and fixture generators, corpus hashes, per-file counters, fault results and native parser logs](assembly-statements.tar.xz)
'''
doc=out/'README.md'
assert heading not in doc.read_text()
with tarfile.open(out/'assembly-statements.tar.xz','w:xz',preset=2) as tar:
    for name in ['inline-shipping.patch','inline-compiler.patch','asm-compiler.patch','asm-forms.py','inline-cases.py','inline-check.inc','test-asm-local.py','test-inline-local.py','asm-faults.py','test-asm-faults.py','local-corpus-asm.py','all-columns.c','run-aligned.py','aligned-snippets.c','asm-local.log','inline-local.log','inline-faults.log','local-lua-asm.log','local-sqlite-asm.log','local-musl-asm.log','build-asm','build-inline','run-parser-group','record-inline.py']:
        tar.add(p/name,'source/'+name)
    for pat in ('*-aligned-results.tsv','*-inline.tsv','*-asm.tsv'):
        for f in sorted(p.glob(pat)):tar.add(f,'local/'+f.name)
    for f in sorted(tree.iterdir()):tar.add(f,'local/corpora/'+f.name)
    for tag in ('asm','inline'):tar.add(r/f'{tag}-clang.log','native/'+tag+'-clang.log')
with doc.open('a') as f:f.write('\n'+body)
print(*rows,sep='\n')
