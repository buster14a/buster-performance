from pathlib import Path
import subprocess,os,hashlib
p=Path(__file__).parent; cases=sorted((p/'asm-cases').glob('*.c'))
for dialect in ['c11','gnu11','c17','gnu17','c23','gnu23']:
 runs=[]
 for tag in ['grouped','asm']:
  out=p/(tag+'-'+dialect+'-asm.bin');out.write_bytes(b'');rows=[]
  for offset in range(0,len(cases),36):
   a=subprocess.run([str(p/(tag+'-columns')),'-std='+dialect,'-nostdinc',*map(str,cases[offset:offset+36])],env={**os.environ,'BUSTER_DECL_TREE':str(out)},stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
   rows.extend(line.split(b'\t')[2:] for line in a.stdout.splitlines() if line.startswith(b'unit\t'))
  assert len(rows)==len(cases)
  runs.append((hashlib.sha256(out.read_bytes()).hexdigest(),rows))
  (p/(tag+'-'+dialect+'-asm.tsv')).write_bytes(b'\n'.join(b'\t'.join(x)for x in rows)+b'\n')
 a,b=runs
 assert a[0]==b[0],(dialect,a[0],b[0])
 assert all(r[:2]==s[:2] and r[4:]==s[4:] and int(s[2])<=int(r[2]) for r,s in zip(a[1],b[1]))
 print(dialect,len(cases),a[0],sum(int(r[2])-int(s[2])for r,s in zip(a[1],b[1])),sum(int(r[3])-int(s[3])for r,s in zip(a[1],b[1])),flush=True)
