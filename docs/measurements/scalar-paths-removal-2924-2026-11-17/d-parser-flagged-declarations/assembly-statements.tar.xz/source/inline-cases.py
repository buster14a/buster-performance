from pathlib import Path
p=Path(__file__).parent;d=p/'inline-cases';d.mkdir(exist_ok=True)
cases=[]
def put(body):cases.append(body+'\n')
head='int f(int n, int *p){ '
tail=' return n; }'
for q in ['', ' volatile',' __volatile__',' __volatile',' const',' restrict',' inline',' goto',' volatile volatile',' volatile goto']:
 for args in ['""','"" "a"','42','', '"" :','"" ::','"" :::','"" : : : "cc"', '"" : "=r"(n)', '"" : "=m"(*p) : "r"(n) : "memory","cc"', '"" : : "r"(n)', '"" : "=r"(n), "=m"(*p) : "r"(n), "m"(*p)', '"" : "=r"(n) : : : L','"" : [res] "=r"(n) : "r"(n)','"" : "=r"((n))','"" : "=m"(**p)','"" : "=r"(n+1)','"" : "=r"(int)','"" : "=r"(T)','"" : "=r"()','"" : "=r"n','"" : "=r",(n)','"" : "=r"(n),','"" : "=r"*n','"" : "=r"(*n)','""::::','"" : : : , "cc"','"" : : : "cc",','"" : : : "cc" "memory"','"" : : : "cc",, "memory"','"" : : : "cc", foo','"" xxx : "r"(n)', '"" : "r"(n) xxx']:
  statement='__asm__'+q+'('+args+');'
  for pre,post in [('',''),('n=2; ',''),('if(n) ',''),('while(n) ',''),('for(;n;) ',''),('if(n) { ',' }'),('int x = ',''),('int x; ',''),('typedef int T; ',''),('n = ; ',''),('',' int x = ;'),('int x __attribute__((unusual)); ',''),('',' __asm__("other");'),('int n2, ',''),('',' else n++;'),('L: ',''),('typedef int T; if(n) { ', ' }'),('for(int n=0;n<1;++n) { ',' }')]:
   put(head+pre+statement+post+tail)
for nd in [0,1,2,3,4,7,8,15,16,17,31,32,33,63,64,65,127]:
 for errors in [False,True]:
  for punct in ['',',',':',' : : "cc"']:
   seqs=[('"r"(n)' if j%2 else '"m"(*p)')for j in range(nd)]
   if errors and seqs:seqs[-1]=seqs[-1].replace(')','+ )')
   put(head+'__asm__("" : : '+','.join(seqs)+punct+');'+tail)
for i,src in enumerate(cases):(d/f'{i:05d}.c').write_text(src)
print('cases',len(cases))
s=(p/'test-asm-local.py').read_text().replace("'asm-cases'","'inline-cases'").replace("['grouped','asm']","['grouped','inline']").replace('len(cases),36','len(cases),64').replace('offset+36','offset+64').replace("'-asm.", "'-inline.")
s=s.replace("assert a[0]==b[0],(dialect,a[0],b[0])","""if a[0]!=b[0]:
  for case in cases:
   hashes=[]
   for tag in ['grouped','inline']:
    out=p/'inline-error-case.bin';out.write_bytes(b'')
    sub=subprocess.run([str(p/(tag+'-columns')),'-std='+dialect,'-nostdinc',str(case)],env={**os.environ,'BUSTER_DECL_TREE':str(out)},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
    hashes.append(hashlib.sha256(out.read_bytes()).digest())
   if hashes[0]!=hashes[1]:raise ValueError((dialect,case,case.read_text()))
  raise ValueError(dialect)""")
(p/'test-inline-local.py').write_text(s)
