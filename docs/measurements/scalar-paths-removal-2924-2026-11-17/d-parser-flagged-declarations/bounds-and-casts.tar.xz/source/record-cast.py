from pathlib import Path
from hashlib import sha256
import tarfile
p=Path(__file__).parent
o=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-flagged-declarations')
r=p/'results'; title='## Static parameter bounds and pointer casts in asm operands'
assert 'test-parser: passed' in (r/'cast-clang.log').read_text() and 'fixtures: 11 trees checked by hand, 0 failures' in (r/'cast-clang.log').read_text()
snippets=(p/'inline-aligned-results.tsv').read_bytes()
assert len(snippets.splitlines())==557 and all((p/f'{tag}-aligned-results.tsv').read_bytes()==snippets for tag in ['array','cast'])
rows=[]
for grp,n in [('lua',34),('sqlite',1),('musl',1336)]:
    totals=[];hashes=set()
    for path,tag in [('local-source-trees','census'),('local-source-trees','inline'),('array-source-trees','array'),('cast-source-trees','cast')]:
        d=p/path
        hashes.add((d/f'{tag}-{grp}.sha').read_bytes())
        lines=(d/f'{tag}-{grp}.tsv').read_text().splitlines()
        units={x[0]:tuple(map(int,x[1:])) for line in lines if (x:=line.split('\t'))}
        assert len(lines)==len(units)==n
        if not totals:baseline=units
        for fn,v in units.items():
            old=baseline[fn];assert v[0]==old[0] and v[4:]==old[4:] and v[2]<=old[2] and v[3]<=old[3]
        totals.append([sum(v[j]for v in units.values()) for j in [2,3]])
    assert len(hashes)==1
    rows.append('| '+grp+' | '+' | '.join(f'{x:,}' for x in [n,*[v[0]for v in totals],totals[0][1],totals[-1][1]])+' |')
for size,tags,kind in [(5705,['inline','array'],'bounds'),(10885,['array','cast'],'cast')]:
    for lang in ['c11','gnu11','c17','gnu17','c23','gnu23']:
        assert len({sha256((p/f'{tag}-{lang}-{kind}.bin').read_bytes()).digest() for tag in tags})==1
        assert all(len((p/f'{tag}-{lang}-{kind}.tsv').read_text().splitlines())==size for tag in tags)
faults=(p/'cast-faults.log').read_text().splitlines()
assert len(faults)==8 and all('routes []' not in s for s in faults)
doc=o/'README.md';assert title not in doc.read_text()
body=title+'''

The parent flagged the initial `static` and first constant in named array parameters such as `char buf[static 15 + 3 * sizeof(int)]`. The candidate verifies the parameter and its brackets, then checks every token in the constant expression using packet masks. Only those first two flags are covered by that check. An independent change handles memory operands such as `"m"(*(void *volatile *)p)`. After validating the pointer type, the parser compresses the remaining token kinds into the same operand checker used for plain dereferences.

| Corpus | Files | Parent reparses | Plain asm | With array bounds | With pointer casts | Parent tokens reparsed | Final tokens reparsed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

The candidate matched every returned tree, traversal column and diagnostic in the three corpora. Seven musl declarations in seven files still reached the repair parser. SQLite retained its six reparses. The two changes also preserved the results and route counts of all 35,648 aligned parser snippets.

The bounds tests covered 5,705 sources and the asm operand tests covered 10,885 sources, each in six dialects. The parent and candidate produced byte-identical serialized results. The 9700X parser suite passed with Clang, including eleven fixed trees. Eight mutations to the bound checks, pointer grammar, unresolved-flag handling or positive coverage changed the expected results. Four changed a tree or diagnostic and the other four changed route counts.

[Compiler patch, positive and negative cases, source generators, per-file counters and result hashes](bounds-and-casts.tar.xz)
'''
with tarfile.open(o/'bounds-and-casts.tar.xz','w:xz',preset=2)as t:
 for file in ['cast-compiler.patch','array-bound.inc','array-bound.py','cast-asm.inc','cast-asm.py','bound-cases.py','cast-cases.py','bound-cast-faults.py','check-bound-cast-faults.py','cast-faults.log','bound-cases.log','cast-cases.log','native-cast.py','build-cast','local-array-corpus.py','local-cast-corpus.py','record-cast.py','all-columns.c','run-aligned.py','aligned-snippets.c','bound-cast-positive-0.c','bound-cast-positive-1.c']:
  t.add(p/file,'source/'+file)
 for pat in ['*-bounds.tsv','*-cast.tsv','cast-aligned-results.tsv','array-aligned-results.tsv','inline-aligned-results.tsv','cast-*-corpus.log','array-*-corpus.log']:
  for f in sorted(p.glob(pat)):t.add(f,'local/'+f.name)
 for directory in ['array-source-trees','cast-source-trees','local-source-trees']:t.add(p/directory,'local/'+directory)
 t.add(r/'cast-clang.log','native/cast-clang.log')
with doc.open('a')as f:f.write('\n'+body)
print(*rows,sep='\n')
