// A memory operand can dereference a pointer cast, as in "m"(*(void *volatile *)p).
// Remove only complete pointer type names. The same operand check then validates every
// identifier, dereference, constraint and separator left in the field.
static bool parse_asm_cast_operands(__m512i kinds, uint32_t first, uint32_t count)
{
    const uint64_t field = _bzhi_u64(UINT64_MAX, count) << first;
    const uint64_t stars = parse_equal8(kinds, PARSE_KIND_STAR) & field;
    uint64_t casts = parse_equal8(kinds, PARSE_KIND_L_PAREN) & (stars << 1) & field;
    if (casts == 0)
    {
        return false;
    }
    const uint64_t closes = parse_equal8(kinds, PARSE_KIND_R_PAREN) & field;
    const uint64_t types = parse_equal8(kinds, PARSE_KIND_TYPE) & field;
    const uint64_t qualifiers = parse_equal8(kinds, PARSE_KIND_QUALIFIER) & field;
    uint64_t keep = field;
    do
    {
        const uint64_t open = casts & -casts;
        casts ^= open;
        const uint64_t after = closes & -(open << 1);
        if (after == 0 || (types & (open << 1)) == 0 || (stars & (open << 2)) == 0)
        {
            return false;
        }
        const uint64_t close = after & -after;
        const uint64_t interior = (close - 1) & -(open << 2);
        if ((interior & ~(stars | qualifiers)) != 0)
        {
            return false;
        }
        keep &= ~(open | (open << 1) | interior | close);
    } while (casts != 0);
    return parse_asm_operands(_mm512_maskz_compress_epi8(keep, kinds), 0, (uint32_t)__builtin_popcountll(keep));
}
