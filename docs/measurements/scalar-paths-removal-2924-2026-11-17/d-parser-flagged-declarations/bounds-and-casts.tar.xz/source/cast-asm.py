from pathlib import Path
from shutil import copytree
p=Path(__file__).parent
def build(s):
    # Share the byte-kind comparison between the bound and operand checks.
    i=s.index('BUSTER_INLINE __mmask64 parse_equal8(');j=s.index('\n}',i)+2
    helper=s[i:j];s=s[:i]+s[j+2:]
    i=s.index('// A comma-separated list of string constraints');s=s[:i]+helper+'\n\n'+s[i:]
    i=s.index('// Return the end of a complete asm statement');s=s[:i]+(p/'cast-asm.inc').read_text()+'\n'+s[i:]
    old='if (!parse_asm_operands(kinds, first, count))';assert s.count(old)==1
    return s.replace(old,'if (!parse_asm_operands(kinds, first, count) && !parse_asm_cast_operands(kinds, first, count))')
copytree(p/'array-src',p/'cast-src',dirs_exist_ok=True)
f=p/'cast-src/buster/compiler/c_parser_impl.c';f.write_text(build(f.read_text()))
(p/'cast-shipping.c').write_text(build((p/'array-shipping.c').read_text()))
