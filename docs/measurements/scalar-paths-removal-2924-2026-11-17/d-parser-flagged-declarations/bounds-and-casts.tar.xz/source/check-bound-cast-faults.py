from pathlib import Path
from hashlib import sha256
import os,subprocess
p=Path(__file__).parent;d=p/'cast-fault-cases';d.mkdir(exist_ok=True)
sources=['int f(int a[static 1+2]);','int f(int a[static 1 +]);','int f(int a[static 1 2]);','int f(int a[static 1]) { return 1 + ; }','int f(int n,int *p){return p[static 2];}','int f(int a[3][static 2]);','void g(void*p){__asm__("" : "=m"(*(void *volatile *)p));}','void g(void*p){__asm__("" : "=m"(*(1 *)p));}','void g(void*p){__asm__("" : "=m"(*(1 + *)p));}','void g(void*p){__asm__("" : "=m"(*(void *3)p));}','void g(void*p){__asm__("" : "=m"(*(void const)p));}','void g(void*p){__asm__("" : "=m"(*(void )p));}','void g(void*p){__asm__("" : "=m"(*(void *sizeof)p));}','void g(void*p){__asm__("" : "=m"(*(void volatile *)p));}','void g(void*p){__asm__("" : "=m"(*(n*)p));}', 'int f(void){ int a[static 1]; return 0; }']
sources.extend(['int f(int a[static 1 + x]);','int f(int n, int a[static n]);', 'int f(int a[static sizeof(int)]);','int f(int a[static 2 * (2 + 3)]);','int f(int a[static 2 ? 3 : 4]);','int f(int a[static 2.5]);','int f(int a[static -1]);', 'int f(int a[static 2 + (1)]);','int f(int a[static n]){return a[0];}'])
for n,s in enumerate(sources):(d/f'{n}.c').write_text(s+'\n')
def get(fault):
 data=[]
 for i in range(len(sources)):
  out=d/'test.bin';out.write_bytes(b'')
  run=subprocess.run([str(p/'cast-mutant-columns'),'-std=gnu17','-nostdinc',str(d/f'{i}.c')],env={**os.environ,'BUSTER_DECL_TREE':str(out),'BUSTER_BOUND_FAULT':fault},capture_output=True,check=True)
  unit=[x.split(b'\t')[2:] for x in run.stdout.splitlines() if x.startswith(b'unit\t')]
  assert len(unit)==1
  data.append((sha256(out.read_bytes()).hexdigest(),tuple(map(int,unit[0]))))
 return data
base=get('control')
for fault in ['cast-base','cast-star','cast-interior','cast-coverage','bound-coverage','scope','incomplete','unresolved']:
 sample=get(fault)
 tree=[i for i,(a,b) in enumerate(zip(base,sample)) if a[0]!=b[0]]
 routes=[i for i,(a,b) in enumerate(zip(base,sample)) if a[1]!=b[1]]
 print(fault,'tree/diagnostics',tree,'routes',routes,flush=True)
 assert tree or routes
