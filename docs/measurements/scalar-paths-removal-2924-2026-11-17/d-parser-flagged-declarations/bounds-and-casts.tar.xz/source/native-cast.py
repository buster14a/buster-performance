from pathlib import Path
from subprocess import check_output,run,PIPE
from difflib import unified_diff
import os,struct,json
p=Path(__file__).parent
fixtures=['void f(int a[static 3 + sizeof(int)]);\n','void g(void *p){ __asm__("" : "=m"(*(void *volatile *)p)); }\n']
rows=[]
for i,source in enumerate(fixtures):
 q=p/f'bound-cast-positive-{i}.c';q.write_text(source);matches=[]
 for tag in ['census','array','cast']:
  out=p/f'bound-cast-{i}-{tag}.bin';out.write_bytes(b'')
  proc=run([str(p/(tag+'-columns')),'-std=gnu17','-nostdinc',str(q)],env={**os.environ,'BUSTER_DECL_TREE':str(out)},stdout=PIPE,stderr=PIPE,check=True)
  [(n,flagged,items,tokens,whole,errors)]=[list(map(int,v.split(b'\t')[2:])) for v in proc.stdout.splitlines() if v.startswith(b'unit\t')]
  assert not whole and not errors and (items>0 if tag=='census' else items==0 if tag=='cast' or i==0 else items>0)
  raw=out.read_bytes();matches.append(raw)
  assert struct.unpack_from('=IIIII',raw)==(0,n,0,0,0)
  parents=struct.unpack_from('='+str(n)+'i',raw,20+n+4*n)
 assert len(set(matches))==1
 print(source.strip(), parents,flush=True)
 rows.append('    { '+json.dumps(source)+', '+str(n)+', { '+', '.join(map(str,parents))+' }, true },\n')
test='src/buster/compiler/c_parser_test.c';impl='src/buster/compiler/c_parser_impl.c'
s=(p/'tree'/test).read_text()
at=s.index('    { "void f(void){ __asm__');s=s[:at]+''.join(rows)+s[at:]
(p/'cast-test.c').write_text(s)
def patch(name,value):
 old=check_output(['git','show','cc7d4ffb4:'+name],cwd=p/'tree').decode()
 return ''.join(unified_diff(old.splitlines(True),value.splitlines(True),'a/'+name,'b/'+name))
(p/'cast-compiler.patch').write_text(patch(impl,(p/'cast-shipping.c').read_text())+patch(test,s))
s=(p/'build-inline').read_text().replace('inline','cast').replace('$root/asm-built.ok','/dev/shm/buster-burs-rules-6b097f86/signload-timing-builds-clean.ok').replace('Inline assembly statements','Cast memory operands and qualified array bounds')
(p/'build-cast').write_text(s)
for name in ['sources-inline','whole-inline','ordinary-inline']:
 s=(p/name).read_text().replace('inline','cast')
 (p/name.replace('inline','cast')).write_text(s)
d=p/'cast-widths';d.mkdir(exist_ok=True)
for n in [0,1,2,3,4,7,8,9,10,11,12,13,14,15,16,17,31,32,33,63,64,65,127]:
 for tag in ['number','sizeof','pointer','ordinary']:
  if tag in ['number','sizeof']:
   atom='1' if tag=='number' else 'sizeof(int)'
   decl='void fIDX(int a[static 1'+' + '+ ' + '.join([atom]*n)+']);' if n else 'void fIDX(int a[static 1]);'
  elif tag=='pointer':
   ops=', '.join(['"m"(*(void *volatile *)p)']*n)
   decl='void fIDX(void*p){ __asm__ volatile ("" : : '+ops+'); }'
  else:decl='int fIDX(int x){ return '+' + '.join(['x']*(n+1))+'; }'
  (d/f'{tag}-{n}.c').write_text('\n'.join(decl.replace('IDX',str(i))for i in range(32))+'\n')
s=(p/'measure-inline').read_text().replace('inline','cast');(p/'measure-cast').write_text(s)
