from pathlib import Path
p=Path(__file__).parent;d=p/'cast-cases';d.mkdir(exist_ok=True)
cases=[]
for typename in ['void *','int *','void *volatile *','double **','unsigned *const','long *restrict *volatile','int *const const *','unsigned','char const *','void','T*','void *inline *','void *const x','void **x','*void','*','void *3','void *, *','int (*)(void)','int [3]','void *(*)','void *()','volatile *','int ** + 1','_BitInt(2)*','int *__attribute__((unused)) *','struct S *','int volatile *','_Atomic(int)*','']:
    for expr in ['*(TYPE)p','* (TYPE) n','*(TYPE)*p','*(TYPE)(p)','*(TYPE)p+1','*(TYPE)p++','(TYPE)p','**(TYPE)p','*(TYPE)','*(TYPE))p','*(TYPE p','p*(TYPE)p','*(TYPE)+p','*((TYPE)p)','* (TYPE) T']:
        for field in ['"=m"(EXP)', '"=m"(EXP), "=r"(n)', '"=r"(n), "=m"(EXP)', '"=m"(EXP), "=m"(EXP)', '"=m"(EXP),','"=m" EXP','42(EXP)','"=m"(EXP), "r"()']:
            item=field.replace('EXP',expr.replace('TYPE',typename))
            for stmt in ['__asm__("" : FIELD : "r"(n) : "cc");','__asm__ volatile ("" : : FIELD);','__asm__("" : FIELD); int x = ;']:
                cases.append('typedef int T; int f(int n, void *p) { '+stmt.replace('FIELD',item)+' return n; }\n')
for n in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]:
    for tail in ['"r"(*(void * volatile *)p)','"r"(*(void *)p),','"r"(*(void *)(n+1))','"r"(*(void*p)','"r"(*(void *1)p)']:
        cases.append('void f(int n,void*p){__asm__("" : : '+', '.join(['"r"(n)']*n+[tail])+');}\n')
for i,src in enumerate(cases):(d/f'{i:05d}.c').write_text(src)
s=(p/'bound-cases.py').read_text();a=s.index('paths=sorted');s=s[a:].replace("('inline','array')","('array','cast')").replace('-bounds.', '-cast.').replace("mismatch-bound.bin","mismatch-cast.bin")
exec('import hashlib,os,subprocess\n'+s)
