from pathlib import Path
from shutil import copytree
p=Path(__file__).parent
d=p/'cast-mutant-src';copytree(p/'cast-src',d,dirs_exist_ok=True)
f=d/'buster/compiler/c_parser_impl.c';s=f.read_text();anchor=s.index('// K2 and K6 have already written the roles')
s=s[:anchor]+'''static bool bound_fault(const char* name)
{
    const char* fault = getenv("BUSTER_BOUND_FAULT");
    return fault != NULL && strcmp(name,fault)==0;
}
'''+s[anchor:]
rules={
 'cast-base':('(types & (open << 1)) == 0','(!bound_fault("cast-base") && (types & (open << 1)) == 0)'),
 'cast-star':('(stars & (open << 2)) == 0','(!bound_fault("cast-star") && (stars & (open << 2)) == 0)'),
 'cast-interior':('if ((interior & ~(stars | qualifiers)) != 0)','if (!bound_fault("cast-interior") && (interior & ~(stars | qualifiers)) != 0)'),
 'cast-coverage':('if (casts == 0)','if (casts == 0 || bound_fault("cast-coverage"))'),
 'bound-coverage':('if (token < 3 || token >= end','if (bound_fault("bound-coverage") || token < 3 || token >= end'),
 'scope':('kernels->roles[parameters] != PARSE_ROLE_OPEN_FUNCTION','(!bound_fault("scope") && kernels->roles[parameters] != PARSE_ROLE_OPEN_FUNCTION)'),
 'incomplete':('return (numbers & 1) != 0 &&','return bound_fault("incomplete") || ((numbers & 1) != 0 &&'),
 'unresolved':('                first = token + 2;','                if (bound_fault("unresolved")) return true;\n                first = token + 2;'),
}
for fault,(a,b) in rules.items():
 assert s.count(a)==1,(fault,s.count(a));s=s.replace(a,b)
s=s.replace('(numbers | sizes) == ((binary << 1) | 1);','(numbers | sizes) == ((binary << 1) | 1));')
f.write_text(s)
