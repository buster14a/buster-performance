void g(void *p){ __asm__("" : "=m"(*(void *volatile *)p)); }
