from collections import Counter
from pathlib import Path
from hashlib import sha256
import os,sys,subprocess
p=Path(__file__).parent;c=p.parent/'buster-2924-parser-corpora'
r=p/'cast-source-trees';r.mkdir(exist_ok=True)
group=sys.argv[1]
if group=='musl':
 m=c/'libc/musl';gen=c/'musl-generated'
 flags=['-std=c99','-nostdinc','-ffreestanding','-D_XOPEN_SOURCE=700']
 for d in [m/'arch/x86_64',m/'arch/generic',gen/'obj/src/internal',m/'src/include',m/'src/internal',gen/'obj/include',m/'include']:flags+=['-I',str(d)]
 paths=[];seen=set()
 for f in sorted((m/'src').glob('*/*.c'))+sorted((m/'src').glob('*/x86_64/*.c')):
  if f.name not in seen:paths.append(f);seen.add(f.name)
 assert len(paths)==1336
else:
 flags=['-std=gnu17','-nostdinc','--predefines',str(c/'provenance/gnu17-pinned-predefines.txt')]
 for d in ['usr/lib/clang/23/include','usr/local/include','usr/include']:flags+=['-isystem',str(c/'headers'/d)]
 if group=='lua':
  paths=sorted((c/'src').glob('*.c'));assert len(paths)==34
 elif group=='sqlite':
  flags+=['-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I',str(c/'sqlite')]
  paths=[c/'sqlite/sqlite3.c']
 else:raise ValueError(group)
rows={};hashes={}
for tag in ['inline','cast']:
 hasher=sha256();units={}
 for i in range(0,len(paths),24):
  part=paths[i:i+24];tmp=r/f'{tag}-{group}.tmp';tmp.write_bytes(b'')
  a=subprocess.run([str(p/(tag+'-columns')),*flags,*map(str,part)],env={**os.environ,'BUSTER_DECL_TREE':str(tmp)},capture_output=True)
  if a.returncode:raise RuntimeError((tag,part,a.stderr[-800:]))
  with tmp.open('rb')as f:
   while data:=f.read(1<<20):hasher.update(data)
  tmp.unlink()
  for l in a.stdout.splitlines():
   v=l.split(b'\t')
   if v[0]==b'unit':
    key=Path(v[1].decode()).relative_to(c);assert key not in units
    units[key]=tuple(map(int,v[2:]))
 assert len(units)==len(paths)
 hashes[tag]=hasher.hexdigest();rows[tag]=units
 (r/f'{tag}-{group}.sha').write_text(hashes[tag]+'\n')
 (r/f'{tag}-{group}.tsv').write_text(''.join(str(k)+'\t'+'\t'.join(map(str,v))+'\n'for k,v in units.items()))
 print(group,tag,hashes[tag],[sum(v[i]for v in units.values())for i in range(6)],flush=True)
assert len(set(hashes.values()))==1
for path,baseline in rows['inline'].items():
 for tag,u in rows.items():
  x=u[path]
  assert x[0]==baseline[0] and x[4:]==baseline[4:] and x[2]<=baseline[2] and x[3]<=baseline[3],(tag,path,baseline,x)
