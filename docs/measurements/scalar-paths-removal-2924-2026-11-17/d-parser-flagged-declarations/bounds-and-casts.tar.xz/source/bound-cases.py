from pathlib import Path
import subprocess,os,hashlib
p=Path(__file__).parent
d=p/'bound-cases';d.mkdir(exist_ok=True)
cases=[]
bounds=['1','12 + 3 * sizeof(int)','1 << 2','1 != 2','1 & 1 | 1','1 % 2','1 + sizeof(short) / sizeof(char)','2 + sizeof(void)','1, 2','sizeof(int)','a','1 + a','1 + sizeof(int*)','1 + sizeof(T)','1 + sizeof(int int)','1 + sizeof(typedef)','1 + sizeof()','1 + sizeof((int)1)','1 + sizeof(int) 2','1 2','1 +','+ 1','1 * * 2','*','', '1 ; 2','(1+2)','_Generic(1,int:2)','1 ? 2 : 3','1 ... 4','a=1','{1}']
spans=['int f(int a[BOUND]);','int f(int a[BOUND]) { return a[0]; }','int f(int a[BOUND], int b[BOUND]);','int f(int a[BOUND],);','int f(int a[BOUND]) { return + ; }','int f(int a[BOUND]) { __asm__ (""); return 1; }','int f(struct S a[BOUND]);','int f(int *a[BOUND]);','int f(int a[BOUND][2]);','int f(int a[2][BOUND]);','int f(int [BOUND]);','int f(int (*a)[BOUND]);','int f(int (*a)(int p[BOUND]));','int f(int a[BOUND] x);','int f(int a[BOUND] = 5);','int f(a[BOUND]);','int a[BOUND];','int x=1,a[BOUND];','typedef int a[BOUND];','int f(void){ int a[BOUND];return 1;}','int f(int *a){return a[BOUND];}','int f(int (*a)(int)){return a(1)[BOUND];}','void f(int a[BOUND]) { if (1) 1 + ; }','void f(int a[BOUND]) { typedef int T; T t; t=; }','struct X { int a[BOUND]; };']
for prefix in ('static ','extern ','const ','restrict ','static static ','static const ',''):
    for expr in bounds:
        for form in spans:cases.append('typedef int T;\n'+form.replace('BOUND',prefix+expr)+'\n')
for n in [1,2,3,4,7,8,15,16,31,32,33,63,64,65,127]:
    for tail in ['',' +',' + sizeof',' + sizeof(',' + sizeof(int',' + sizeof(int)',' + sizeof(int) + 2']:
        cases.append('void f(int a[static '+'+'.join(['2']*n)+tail+']);\n')
for i,src in enumerate(cases):(d/f'{i:05d}.c').write_text(src)
paths=sorted(d.glob('*.c'));assert len(paths)==len(cases)
for dialect in ('c11','gnu11','c17','gnu17','c23','gnu23'):
    runs=[]
    for tag in ('inline','array'):
        out=p/(tag+'-'+dialect+'-bounds.bin');out.write_bytes(b'');rows=[]
        for lo in range(0,len(paths),48):
            cmd=subprocess.run([str(p/(tag+'-columns')),'-std='+dialect,'-nostdinc',*map(str,paths[lo:lo+48])],env={**os.environ,'BUSTER_DECL_TREE':str(out)},capture_output=True,check=True)
            rows.extend(tuple(map(int,row.split(b'\t')[2:])) for row in cmd.stdout.splitlines() if row.startswith(b'unit\t'))
        digest=hashlib.sha256(out.read_bytes()).hexdigest();runs.append((digest,rows))
        (p/f'{tag}-{dialect}-bounds.tsv').write_text(''.join('\t'.join(map(str,row))+'\n' for row in rows))
    (old,a),(new,b)=runs
    if old!=new:
        for i,file in enumerate(paths):
            dig=[]
            for tag in ('inline','array'):
                out=p/'mismatch-bound.bin';out.write_bytes(b'')
                cmd=subprocess.run([str(p/(tag+'-columns')),'-std='+dialect,'-nostdinc',str(file)],env={**os.environ,'BUSTER_DECL_TREE':str(out)},capture_output=True,check=True)
                dig.append(hashlib.sha256(out.read_bytes()).digest())
            if dig[0]!=dig[1]:raise RuntimeError((dialect,i,file.read_text(),a[i],b[i]))
        raise RuntimeError(dialect)
    assert len(a)==len(b)==len(paths) and all(x[:2]==y[:2] and x[4:]==y[4:] and y[2]<=x[2] and y[3]<=x[3] for x,y in zip(a,b))
    print(dialect,len(paths),new,sum(x[2]-y[2] for x,y in zip(a,b)),sum(x[3]-y[3] for x,y in zip(a,b)),flush=True)
