// K6 checks an array bound as an expression and flags its initial static and first operand.
// Recognize a named parameter's minimum bound when each operand is a number or sizeof of one
// built-in type. Other flagged tokens still require the enclosing declaration to be reparsed.
static bool parse_static_parameter_bound(const ParseKernels* kernels, const ParseInput* input, uint32_t token, uint32_t end)
{
    if (token < 3 || token >= end || input->names[token] != C_NAME_STATIC || input->kinds[token] != PARSE_KIND_STORAGE ||
        kernels->roles[token] != PARSE_ROLE_SPECIFIER || kernels->roles[token - 1] != PARSE_ROLE_OPEN_SUBSCRIPT ||
        kernels->roles[token - 2] != PARSE_ROLE_OPERAND || input->kinds[token - 2] != PARSE_KIND_IDENTIFIER)
    {
        return false;
    }
    const uint32_t open = token - 1;
    const uint32_t parameters = kernels->enclosing[open];
    const uint32_t close = kernels->parents[open];
    if (parameters >= open || kernels->roles[parameters] != PARSE_ROLE_OPEN_FUNCTION || kernels->enclosing[token - 2] != parameters ||
        kernels->enclosing[token] != open || close <= token + 1 || close > end || close - token - 1 > 64 ||
        kernels->roles[close] != PARSE_ROLE_CLOSE_SUBSCRIPT || kernels->enclosing[close] != open)
    {
        return false;
    }
    const uint32_t first = token + 1;
    const uint64_t live = _bzhi_u64(UINT64_MAX, close - first);
    const __m512i kinds = _mm512_maskz_loadu_epi8(live, kernels->vkinds + first);
    const __m512i roles = _mm512_maskz_loadu_epi8(live, kernels->roles + first);
    const uint64_t numbers = parse_equal8(kinds, PARSE_KIND_NUMBER) & parse_equal8(roles, PARSE_ROLE_OPERAND);
    const uint64_t sizes = parse_equal8(kinds, PARSE_KIND_SIZEOF) & parse_equal8(roles, PARSE_ROLE_PREFIX);
    const uint64_t opens = parse_equal8(roles, PARSE_ROLE_OPEN_SIZEOF);
    const uint64_t types = parse_equal8(kinds, PARSE_KIND_TYPE) & parse_equal8(roles, PARSE_ROLE_SPECIFIER);
    const uint64_t closes = parse_equal8(roles, PARSE_ROLE_CLOSE_SIZEOF);
    const uint64_t binary = _mm512_cmpge_epu8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_MULTIPLICATIVE)) &
                            _mm512_cmple_epu8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_LOGICAL_OR));
    return (numbers & 1) != 0 && (((numbers | closes) >> (close - first - 1)) & 1) != 0 && (numbers | sizes | opens | types | closes | binary) == live &&
           opens == (sizes << 1) && types == (opens << 1) && closes == (types << 1) &&
           binary == (((numbers | closes) << 1) & live) && (numbers | sizes) == ((binary << 1) | 1);
}
