void f(int a[static 3 + sizeof(int)]);
