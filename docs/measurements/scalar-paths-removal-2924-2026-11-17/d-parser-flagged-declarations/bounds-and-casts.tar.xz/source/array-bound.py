from pathlib import Path
from shutil import copytree
from difflib import unified_diff
from subprocess import check_output
p=Path(__file__).parent
def build(s):
    i=s.index('BUSTER_INLINE __mmask64 parse_equal8(');j=s.index('\n}',i)+2
    helper=s[i:j];s=s[:i]+s[j+2:];a=s.index('// Every flagged token must belong')
    s=s[:a]+helper+'\n\n'+s[a:];a=s.index('// Every flagged token must belong')
    s=s[:a]+(p/'array-bound.inc').read_text()+'\n'+s[a:]
    s=s.replace('parse_resolved_asm_item(', 'parse_resolved_item(')
    s=s.replace('// Every flagged token must belong to a validated statement. A flag before its keyword or\n// after its closing parenthesis still sends the enclosing top-level declaration to the fallback.', '// Each flag must belong to a validated asm statement or parameter bound.')
    s=s.replace('            const uint32_t close = parse_inline_asm_close(kernels, input, first + (uint32_t)__builtin_ctzll(marked), end);','''            const uint32_t token = first + (uint32_t)__builtin_ctzll(marked);
            if (parse_static_parameter_bound(kernels, input, token, end))
            {
                first = token + 2;
                continue;
            }
            const uint32_t close = parse_inline_asm_close(kernels, input, token, end);''')
    return s
d=p/'array-src';copytree(p/'inline-src',d,dirs_exist_ok=True)
f=d/'buster/compiler/c_parser_impl.c';f.write_text(build(f.read_text()))
f='src/buster/compiler/c_parser_impl.c'
src=build((p/'tree'/f).read_text());(p/'array-shipping.c').write_text(src)
