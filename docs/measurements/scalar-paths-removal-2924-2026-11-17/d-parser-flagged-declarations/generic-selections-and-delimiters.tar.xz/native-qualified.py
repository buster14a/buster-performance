from pathlib import Path
from subprocess import check_output,run,PIPE
from difflib import unified_diff
import os,struct,json
p=Path(__file__).parent
fixtures=['void f(int a[__restrict__]);\n','void f(char *p){ g(&(char *){p}); }\n','void (*f(int sig,void (*handler)(int)))(int){return handler;}\n']
rows=[]
for i,source in enumerate(fixtures):
 path=p/f'qualified-positive-{i}.c';path.write_text(source)
 compare=[]
 for tag in ('cast','qualified'):
  out=p/f'qualified-fixture-{i}-{tag}.bin';out.write_bytes(b'')
  res=run([str(p/(tag+'-columns')),'-std=gnu17','-nostdinc',str(path)],env={**os.environ,'BUSTER_DECL_TREE':str(out)},capture_output=True,check=True)
  [(n,flagged,items,tokens,whole,errors)]=[list(map(int,x.split(b'\t')[2:]))for x in res.stdout.splitlines()if x.startswith(b'unit\t')]
  assert not whole and not errors and items==int(tag=='cast'),(i,tag,res.stdout)
  raw=out.read_bytes();compare.append(raw);assert struct.unpack_from('=IIIII',raw)==(0,n,0,0,0) and n<=64
  parents=struct.unpack_from('='+str(n)+'i',raw,20+5*n)
 assert compare[0]==compare[1]
 rows.append('    { '+json.dumps(source)+', '+str(n)+', { '+', '.join(map(str,parents))+' }, true },\n')
impl='src/buster/compiler/c_parser_impl.c';test='src/buster/compiler/c_parser_test.c'
s=(p/'cast-test.c').read_text();pos=s.index('    { "void f(int a[static 3');s=s[:pos]+''.join(rows)+s[pos:];(p/'qualified-test.c').write_text(s)
def patch(name,s):
 old=check_output(['git','show','cc7d4ffb4:'+name],cwd=p/'tree').decode()
 return ''.join(unified_diff(old.splitlines(True),s.splitlines(True),'a/'+name,'b/'+name))
(p/'qualified-compiler.patch').write_text(patch(impl,(p/'qualified-shipping.c').read_text())+patch(test,s))
for name in ('build-cast','measure-cast','sources-cast','ordinary-cast','whole-cast'):
 s=(p/name).read_text().replace('cast','qualified').replace('signload-timing-builds-clean.ok','plan-builds-clean.ok').replace('Cast memory operands and qualified array bounds in the production vector parser','Validate qualified parameter arrays, pointer literals and grouped function definitions in the production parser')
 (p/name.replace('cast','qualified')).write_text(s)
d=p/'qualified-widths';d.mkdir(exist_ok=True)
for n in [0,1,2,3,4,7,8,9,15,16,17,31,32,33,63,64,65,127]:
 for tag in ('qualifiers','literal','parameters','ordinary'):
  if tag=='qualifiers':decl='void fIDX('+(','.join(f'int a{x}[__restrict__]'for x in range(n)) or 'void')+');'
  elif tag=='literal':decl='void fIDX(char *p){ g(&(char *){'+ ' + '.join(['p']+['0']*n)+'}); }'
  elif tag=='parameters':decl='void (*fIDX('+(','.join(f'int a{x}'for x in range(n)) or 'void')+'))(int){return 0;}'
  else:decl='int fIDX(int x){return '+'+'.join(['x']*(n+1))+';}'
  (d/f'{tag}-{n}.c').write_text('\n'.join(decl.replace('IDX',str(i))for i in range(32))+'\n')
