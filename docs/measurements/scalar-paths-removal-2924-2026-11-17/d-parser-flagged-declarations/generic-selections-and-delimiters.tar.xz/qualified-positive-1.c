void f(char *p){ g(&(char *){p}); }
