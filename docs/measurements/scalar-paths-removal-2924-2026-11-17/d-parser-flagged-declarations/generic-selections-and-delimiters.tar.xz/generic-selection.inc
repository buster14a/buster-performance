// One builtin or visible typedef name, optionally qualified and optionally a pointer.
// The caller checks which token ends this type name, a cast's ')' or an association's ':'.
static uint32_t parse_generic_type_end(const ParseKernels* kernels, const ParseInput* input, uint32_t at, uint32_t limit)
{
    if (at < limit && kernels->vkinds[at] == PARSE_KIND_QUALIFIER &&
        (input->names[at] == C_NAME_CONST || input->names[at] == C_NAME_VOLATILE))
    {
        at += 1;
    }
    if (at >= limit || kernels->roles[at] != PARSE_ROLE_SPECIFIER ||
        (kernels->vkinds[at] != PARSE_KIND_TYPE && kernels->vkinds[at] != PARSE_VKIND_TYPE_NAME))
    {
        return BUSTER_PARSE_NONE;
    }
    at += 1;
    return at + (at < limit && kernels->vkinds[at] == PARSE_KIND_STAR && kernels->roles[at] == PARSE_ROLE_PREFIX);
}

// Verify an expression-sized generic selection against its vector roles. Remove the interiors of
// validated casts and association type names from the packet. In the remaining token sequence an
// operand or closing delimiter must precede each infix operator, postfix opener and closing delimiter.
static uint32_t parse_generic_close(const ParseKernels* kernels, const ParseInput* input, uint32_t token, uint32_t end)
{
    if (input->kinds[token] != PARSE_KIND_GENERIC || token == 0 || token >= end ||
        (kernels->roles[token - 1] != PARSE_ROLE_ASSIGN && kernels->roles[token - 1] != PARSE_ROLE_RETURN &&
         kernels->roles[token - 1] != PARSE_ROLE_OPEN_CONDITION) || kernels->roles[token + 1] != PARSE_ROLE_OPEN_KEYWORD)
    {
        return BUSTER_PARSE_NONE;
    }
    const uint32_t open = token + 1;
    const uint32_t first = open + 1;
    const uint32_t close = kernels->parents[open];
    if (close <= first || close >= end || close - first > 64 || kernels->enclosing[close] != open ||
        kernels->roles[close] != PARSE_ROLE_CLOSE_KEYWORD)
    {
        return BUSTER_PARSE_NONE;
    }
    const uint64_t live = _bzhi_u64(UINT64_MAX, close - first);
    const __m512i kinds = _mm512_maskz_loadu_epi8(live, kernels->vkinds + first);
    const __m512i roles = _mm512_maskz_loadu_epi8(live, kernels->roles + first);
    const uint64_t casts = parse_equal8(roles, PARSE_ROLE_OPEN_CAST);
    const uint64_t commas = parse_equal8(kinds, PARSE_KIND_COMMA);
    uint64_t keep = live;
    bool association = false;
    bool seen_default = false;
    for (uint64_t events = casts | commas; events != 0; events &= events - 1)
    {
        const uint32_t lane = (uint32_t)__builtin_ctzll(events);
        const uint32_t i = first + lane;
        uint32_t delimiter;
        if (kernels->roles[i] == PARSE_ROLE_OPEN_CAST)
        {
            delimiter = parse_generic_type_end(kernels, input, i + 1, close);
            if (delimiter >= close || kernels->parents[i] != delimiter || kernels->roles[delimiter] != PARSE_ROLE_CLOSE_CAST)
            {
                return BUSTER_PARSE_NONE;
            }
        }
        else if (kernels->enclosing[i] == open)
        {
            if (kernels->roles[i] != PARSE_ROLE_SEPARATOR || i + 1 >= close)
            {
                return BUSTER_PARSE_NONE;
            }
            association = true;
            if (kernels->vkinds[i + 1] == PARSE_KIND_DEFAULT)
            {
                if (seen_default || kernels->roles[i + 1] != PARSE_ROLE_OPERAND)
                {
                    return BUSTER_PARSE_NONE;
                }
                seen_default = true;
                delimiter = i + 2;
            }
            else
            {
                delimiter = parse_generic_type_end(kernels, input, i + 1, close);
            }
            if (delimiter >= close || kernels->roles[delimiter] != PARSE_ROLE_ASSOCIATION || kernels->enclosing[delimiter] != open)
            {
                return BUSTER_PARSE_NONE;
            }
        }
        else
        {
            const uint32_t call = kernels->enclosing[i];
            if (call <= open || call >= i || kernels->roles[call] != PARSE_ROLE_OPEN_CALL || kernels->roles[i] != PARSE_ROLE_SEPARATOR)
            {
                return BUSTER_PARSE_NONE;
            }
            continue;
        }
        keep &= ~(_bzhi_u64(UINT64_MAX, delimiter - i) << (lane + 1));
    }
    const uint64_t atoms = parse_equal8(roles, PARSE_ROLE_OPERAND) & (parse_equal8(kinds, PARSE_KIND_IDENTIFIER) | parse_equal8(kinds, PARSE_KIND_NUMBER) |
                           parse_equal8(kinds, PARSE_KIND_STRING) | parse_equal8(kinds, PARSE_KIND_CHARACTER));
    const uint64_t unary = parse_equal8(roles, PARSE_ROLE_PREFIX) & (parse_equal8(kinds, PARSE_KIND_AMP) | parse_equal8(kinds, PARSE_KIND_STAR) |
                           parse_equal8(kinds, PARSE_KIND_PLUS) | parse_equal8(kinds, PARSE_KIND_MINUS) | parse_equal8(kinds, PARSE_KIND_TILDE) | parse_equal8(kinds, PARSE_KIND_EXCLAIM));
    const uint64_t binary = _mm512_cmpge_epu8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_MULTIPLICATIVE)) &
                            _mm512_cmple_epu8_mask(roles, _mm512_set1_epi8(PARSE_ROLE_LOGICAL_OR));
    const uint64_t closers = parse_equal8(roles, PARSE_ROLE_CLOSE_GROUP) | parse_equal8(roles, PARSE_ROLE_CLOSE_CALL) | parse_equal8(roles, PARSE_ROLE_CLOSE_SUBSCRIPT);
    const uint64_t left = binary | commas | closers | parse_equal8(roles, PARSE_ROLE_OPEN_CALL) | parse_equal8(roles, PARSE_ROLE_OPEN_SUBSCRIPT) |
                          parse_equal8(roles, PARSE_ROLE_OPEN_TERNARY) | parse_equal8(roles, PARSE_ROLE_CLOSE_TERNARY);
    const uint64_t all = atoms | unary | left | casts | parse_equal8(roles, PARSE_ROLE_OPEN_GROUP);
    const uint64_t values = _pext_u64(atoms | closers, keep);
    const uint64_t sequence = _pext_u64(keep, keep);
    return association && (all & keep) == keep && _pext_u64(left, keep) == ((values << 1) & sequence) &&
           (values & (sequence ^ (sequence >> 1))) != 0 ? close : BUSTER_PARSE_NONE;
}
