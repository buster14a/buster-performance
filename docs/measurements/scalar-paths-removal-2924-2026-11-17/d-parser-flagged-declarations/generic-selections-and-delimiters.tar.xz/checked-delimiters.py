from pathlib import Path
from shutil import copytree
from difflib import unified_diff
from subprocess import check_output
import json
p=Path(__file__).parent
def fix(s):
 s=s.replace('open >= end || kernels->roles[open] != PARSE_ROLE_OPEN_ASM','open >= end || input->kinds[open] != PARSE_KIND_L_PAREN || kernels->roles[open] != PARSE_ROLE_OPEN_ASM')
 s=s.replace('close - open > 65 || kernels->enclosing[close]','close - open > 65 || input->kinds[close] != PARSE_KIND_R_PAREN ||\n        kernels->enclosing[close]')
 s=s.replace('kernels->roles[close] != PARSE_ROLE_CLOSE_SUBSCRIPT || kernels->enclosing[close] != open)', 'input->kinds[close] != PARSE_KIND_R_SQUARE || kernels->roles[close] != PARSE_ROLE_CLOSE_SUBSCRIPT || kernels->enclosing[close] != open)')
 s=s.replace('const uint64_t opens = parse_equal8(roles, PARSE_ROLE_OPEN_SIZEOF);','const uint64_t opens = parse_equal8(roles, PARSE_ROLE_OPEN_SIZEOF) & parse_equal8(kinds, PARSE_KIND_L_PAREN);')
 s=s.replace('const uint64_t closes = parse_equal8(roles, PARSE_ROLE_CLOSE_SIZEOF);','const uint64_t closes = parse_equal8(roles, PARSE_ROLE_CLOSE_SIZEOF) & parse_equal8(kinds, PARSE_KIND_R_PAREN);')
 s=s.replace('kernels->roles[token] != PARSE_ROLE_CLOSE_COMPOUND || end - token < 3','input->kinds[token] != PARSE_KIND_R_PAREN || kernels->roles[token] != PARSE_ROLE_CLOSE_COMPOUND || end - token < 3')
 s=s.replace('kernels->roles[close] != PARSE_ROLE_CLOSE_COMPOUND_BODY || kernels->enclosing[close] != body','input->kinds[close] != PARSE_KIND_R_BRACE || kernels->roles[close] != PARSE_ROLE_CLOSE_COMPOUND_BODY || kernels->enclosing[close] != body')
 return s
path='src/buster/compiler/c_parser_impl.c';test='src/buster/compiler/c_parser_test.c'
def patch(name,value):
 old=check_output(['git','show','cc7d4ffb4:'+name],cwd=p/'tree').decode()
 return ''.join(unified_diff(old.splitlines(True),value.splitlines(True),'a/'+name,'b/'+name))
testlines=''
for index,pos in [('02171',40),('02365',68)]:
 source=(p/f'delimiter-cases/{index}.c').read_text()
 testlines+='    { '+json.dumps(source)+', "1:'+str(pos)+": expected ')'\""+', 0 },\n'
for src,tag,dependency in [('cast','asmclose','$root/qualified-built.ok'),('qualified','checked','$root/asmclose-built.ok')]:
 d=p/(tag+'-src');copytree(p/(src+'-src'),d,dirs_exist_ok=True);f=d/path[4:];f.write_text(fix((p/(src+'-src')/path[4:]).read_text()))
 s=fix((p/(src+'-shipping.c')).read_text());(p/(tag+'-shipping.c')).write_text(s)
 st=(p/(src+'-test.c')).read_text();idx=st.index('    { "void f(void) { asm(\\"a\\", \\"b\\"); }');st=st[:idx]+testlines+st[idx:];(p/(tag+'-test.c')).write_text(st)
 (p/(tag+'-compiler.patch')).write_text(patch(path,s)+patch(test,st))
 b=(p/'build-cast').read_text().replace('cast-',tag+'-').replace('parser-cast','parser-'+tag).replace('/dev/shm/buster-burs-rules-6b097f86/signload-timing-builds-clean.ok',dependency)
 (p/('build-'+tag)).write_text(b)
