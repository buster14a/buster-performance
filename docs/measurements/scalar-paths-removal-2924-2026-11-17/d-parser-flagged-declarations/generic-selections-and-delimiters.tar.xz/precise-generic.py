from pathlib import Path
from shutil import copytree
p=Path(__file__).parent
s=(p/'typed-generic.py').read_text().split("d=p/'generic-src'")[0]
env={'__file__':str(p/'typed-generic.py')};exec(s,env)
def update(s):
 s=env['build'](s)
 s=s.replace('kernels->roles[close] != PARSE_ROLE_CLOSE_KEYWORD)\n    {\n        return BUSTER_PARSE_NONE;', 'kernels->roles[close] != PARSE_ROLE_CLOSE_KEYWORD || input->kinds[close] != PARSE_KIND_R_PAREN)\n    {\n        return BUSTER_PARSE_NONE;')
 a='    const uint64_t casts = parse_equal8(roles, PARSE_ROLE_OPEN_CAST);'
 # The earlier asm walker has its own casts computed from token kinds.
 assert s.count(a)==1
 s=s.replace(a,a+'''
    const uint64_t round_closers = parse_equal8(roles, PARSE_ROLE_CLOSE_CAST) | parse_equal8(roles, PARSE_ROLE_CLOSE_CALL) | parse_equal8(roles, PARSE_ROLE_CLOSE_GROUP);
    if (parse_equal8(kinds, PARSE_KIND_R_PAREN) != round_closers ||
        parse_equal8(kinds, PARSE_KIND_R_SQUARE) != parse_equal8(roles, PARSE_ROLE_CLOSE_SUBSCRIPT) || parse_equal8(kinds, PARSE_KIND_R_BRACE) != 0)
    {
        return BUSTER_PARSE_NONE;
    }''')
 return s
d=p/'precise-src';copytree(p/'checked-src',d,dirs_exist_ok=True);f=d/'buster/compiler/c_parser_impl.c';f.write_text(update((p/'checked-src/buster/compiler/c_parser_impl.c').read_text()))
(p/'precise-shipping.c').write_text(update((p/'checked-shipping.c').read_text()))
s=(p/'local-qualified-corpus.py').read_text().replace('qualified','precise');(p/'local-precise-corpus.py').write_text(s)
