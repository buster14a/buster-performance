from pathlib import Path
from shutil import copytree
p=Path(__file__).parent
def refine(s):
 a=s.index('// K6 checks an array bound')
 b=s.index('    const uint32_t open = token - 1;',a)
 s=s[:a]+'''// K6 reads a parameter's array bound as an expression. It flags the leading storage or
// qualifier token even for a valid minimum bound or an otherwise empty qualified array.
static bool parse_resolved_parameter_bound(const ParseKernels* kernels, const ParseInput* input, uint32_t token, uint32_t end)
{
    if (token < 3 || token >= end || kernels->roles[token] != PARSE_ROLE_SPECIFIER ||
        kernels->roles[token - 1] != PARSE_ROLE_OPEN_SUBSCRIPT || kernels->roles[token - 2] != PARSE_ROLE_OPERAND ||
        input->kinds[token - 2] != PARSE_KIND_IDENTIFIER)
    {
        return false;
    }
    const uint32_t name = input->names[token];
    const bool minimum = name == C_NAME_STATIC && input->kinds[token] == PARSE_KIND_STORAGE;
    const bool qualified = input->kinds[token] == PARSE_KIND_QUALIFIER &&
        (name == C_NAME_RESTRICT || name == C_NAME_GNU_RESTRICT || name == C_NAME_GNU_RESTRICT2 ||
         name == C_NAME_CONST || name == C_NAME_GNU_CONST || name == C_NAME_GNU_CONST2 ||
         name == C_NAME_VOLATILE || name == C_NAME_GNU_VOLATILE || name == C_NAME_GNU_VOLATILE2);
    if (!minimum && !qualified)
    {
        return false;
    }
'''+s[b:]
 s=s.replace('if (input->names[token] == C_NAME_RESTRICT || close == token + 1)','if (qualified || close == token + 1)').replace('return input->names[token] == C_NAME_RESTRICT && close == token + 1;','return qualified && close == token + 1;')
 return s
d=p/'qualified-src';copytree(p/'returning-src',d,dirs_exist_ok=True);f=d/'buster/compiler/c_parser_impl.c';f.write_text(refine((p/'returning-src/buster/compiler/c_parser_impl.c').read_text()))
(p/'qualified-shipping.c').write_text(refine((p/'returning-shipping.c').read_text()))
s=(p/'local-returning-corpus.py').read_text().replace('returning','qualified');(p/'local-qualified-corpus.py').write_text(s)
