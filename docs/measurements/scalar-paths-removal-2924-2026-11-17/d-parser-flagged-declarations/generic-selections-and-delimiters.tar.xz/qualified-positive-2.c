void (*f(int sig,void (*handler)(int)))(int){return handler;}
