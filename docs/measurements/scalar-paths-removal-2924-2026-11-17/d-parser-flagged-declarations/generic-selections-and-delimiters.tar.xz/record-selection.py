from pathlib import Path
from statistics import median
import tarfile,re
p=Path(__file__).resolve().parent
doc=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-flagged-declarations/README.md')
title='## Generic selections, qualified parameters and grouped function definitions'
archive='generic-selections-and-delimiters.tar.xz'
paths=[];rows=[]
for group,n in [('lua',34),('sqlite',1),('musl',1336)]:
 values=[];hashes=set();units=None
 for folder,tag in [('local-source-trees','census'),('cast-source-trees','cast'),('checked-source-trees','checked'),('precise-source-trees','precise')]:
  src=p/folder;table=src/f'{tag}-{group}.tsv';sha=src/f'{tag}-{group}.sha'
  data={r[0]:tuple(map(int,r[1:]))for l in table.read_text().splitlines()if (r:=l.split('\t'))}
  paths.extend([table,sha]);assert len(data)==n;hashes.add(sha.read_text().strip())
  if units is None:units=data
  for name,x in data.items():assert x[0]==units[name][0] and x[4:]==units[name][4:] and x[2]<=units[name][2]
  values.append([sum(v[i]for v in data.values())for i in range(6)])
 assert len(hashes)==1 and values[-1][2:]==[0,0,0,0]
 rows.append('| '+group+' | '+ ' | '.join(f'{v:,}'for v in [n,values[-1][0],values[0][2],values[1][2],values[2][2],values[-1][2]])+' |')
langs=['c11','gnu11','c17','gnu17','c23','gnu23']
for t in ['qualified-cases','checked-cases','precise-qualified-cases']:
 s=(p/(t+'.log')).read_text().splitlines()
 assert all(l.split()[:3]==[lang,'32055','655']for l,lang in zip(s,langs,strict=True))
s=(p/'precise-selection-cases.log').read_text().splitlines();assert len(s)==8 and all(l.split()[1:4]==['28870','0','2578']for l in s)
for t,n,trees in [('asmclose',559,11),('checked',559,14),('precise',561,16)]:
 s=(p/f'{t}-verified-clang.log').read_text()
 assert f'snippets: {n}, 0 failures (with clang)' in s and f'fixtures: {trees} trees checked by hand, 0 failures' in s and f'alignments: {n*64} inputs' in s and 'test-parser: passed' in s
 assert (p/f'{t}-delimiters.log').read_text().strip()=='2736 0'
 paths.extend([p/f'{t}-verified-clang.log',p/f'frozen-{t}/tests/parser-kernels/digests.tsv'])
def cols(tag):
 return [(r[:4],r[7:])for l in (p/f'{tag}-aligned-results.tsv').read_text().splitlines()if(r:=l.split('\t'))]
assert len(cols('census'))==557 and cols('census')==cols('precise')==cols('checked')
a=(p/'added-alignments.log').read_text().splitlines();assert len(a)==24
for i in range(0,24,4):assert len({l.split()[3]for l in a[i:i+4]})==1
faults=(p/'selection-faults.log').read_text().splitlines();assert len(faults)==10 and all('changed routes []' not in l for l in faults)
extra=(p/'selection-boundaries.log').read_text().splitlines()
assert len(extra)==3 and all(l.split()[2]=='0' and int(l.split()[1])==int(l.split()[3])+int(l.split()[4])for l in extra)
size=int(extra[0].split()[1])
assert title not in doc.read_text()
names=['checked-delimiters.py','returning-pointer.py','parameter-literals.py','qualified-bounds.py','native-qualified.py','native-precise.py','checked-compiler.patch','precise-compiler.patch','generic-selection.inc','typed-generic.py','generic-associations.py','precise-generic.py','residual-cases.py','delimiter-cases.py','selection-cases.py','selection-boundaries.py','selection-faults.py','check-selection-faults.py','added-alignments.py','local-checked-corpus.py','local-precise-corpus.py','verify-revised-parser','build-precise','all-columns.c','record-selection.py','run-aligned.py','aligned-snippets.c','residual-details.py','run-residual.py']
paths.extend(p/n for n in names)
for pat in ['*qualified-cases.log','checked-cases.log','*delimiters.log','*selection-cases.log','selection-boundaries.log','selection-faults.log','added-alignments.log','precise-*-corpus.log','checked-*-corpus.log','probe-generic-fixture*.c','qualified-positive*.c','selection-fault-cases/*.c','residual-{lua,sqlite}.log']:
 paths.extend(p.glob(pat))
paths.extend(p/f'{t}-aligned-results.tsv'for t in ['census','checked','precise'])
with tarfile.open(doc.parent/archive,'w:xz',preset=2)as t:
 for f in sorted(set(paths)):t.add(f,str(f.relative_to(p)))
with doc.open('a')as f:
 f.write('\n'+title+'''

The vector parser validates qualifier-only parameter arrays, addressed pointer compound literals and grouped function definitions. The secondary operator pass pairs a generic association’s colon at its own nesting level and retains nested conditional-expression pairs. The bounded selection check recognizes the type or default at each association, checks the raw closing punctuation, and verifies operand adjacency and the final operand. Other forms still reach the existing parser. Two new diagnostics freeze the closing punctuation for inline assembly, and two more cover malformed generic selections.

| Corpus | Translation units | Tokens | Original declaration reparses | Static bounds and asm casts | Qualified parameters and pointer forms | With generic selections |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

No declaration or whole unit reached the scalar parser in these three corpora. Each corpus retained the original serialized tree and diagnostics. The five SQLite function bodies that previously needed reparsing have three corrected roles and seven corrected parent links each. Other real sources and error-recovery views may still use the fallback.

The 9700X Clang-backed suite passed 561 snippets, sixteen fixed trees, 35,904 aligned inputs, generated streams, deep nesting and the driver checks. The old and new parsers gave byte-identical results on the original 557 snippets at all 64 alignments. The four new negative snippets were checked at all alignments against the parent before recording the revised alignment digest. The other frozen batches retained their digests.

The qualifier, compound literal and function-pointer matrix covered 32,055 sources per dialect across six dialects. The generic selection matrix covered 28,870 per dialect across eight dialects. All 2,736 delimiter mutations retained their trees and diagnostics. A separate matrix included '''+f'{size:,}'+''' cases per dialect at packet boundaries and in surrounding declaration and expression contexts, comparing preprocessing status and diagnostics as well as parser outputs. Ten deliberate faults changed trees, diagnostics or fallback counts.

[Compiler patches, source generators, per-file counters and digests, fault results and native suite logs]('''+archive+')\n')
print(*rows,sep='\n')
