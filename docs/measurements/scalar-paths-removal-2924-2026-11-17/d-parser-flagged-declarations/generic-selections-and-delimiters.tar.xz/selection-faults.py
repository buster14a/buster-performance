from pathlib import Path
from shutil import copytree
p=Path(__file__).resolve().parent
d=p/'selection-mutant-src';copytree(p/'precise-src',d,dirs_exist_ok=True)
f=d/'buster/compiler/c_parser_impl.c';s=f.read_text();idx=s.index('static uint32_t parse_generic_type_end(')
s=s[:idx]+'''static bool selection_fault(const char* name)
{
    const char* fault = getenv("BUSTER_SELECTION_FAULT");
    return fault != NULL && strcmp(fault,name) == 0;
}
'''+s[idx:]
start=s.index('static uint32_t parse_generic_type_end(');stop=s.index('// Each skipped flag belongs to',start);body=s[start:stop]
rules={
'coverage':('if (input->kinds[token] != PARSE_KIND_GENERIC','if (selection_fault("coverage") || input->kinds[token] != PARSE_KIND_GENERIC'),
'outer-close':(' || input->kinds[close] != PARSE_KIND_R_PAREN',' || (!selection_fault("outer-close") && input->kinds[close] != PARSE_KIND_R_PAREN)'),
'inner-close':('if (parse_equal8(kinds, PARSE_KIND_R_PAREN)', 'if (!selection_fault("inner-close") && (parse_equal8(kinds, PARSE_KIND_R_PAREN)'),
'uniqueness':('if (seen_default ||', 'if ((!selection_fault("uniqueness") && seen_default) ||'),
'type':('if (at >= limit || kernels->roles[at] != PARSE_ROLE_SPECIFIER ||','if (at >= limit || (!selection_fault("type") && (kernels->roles[at] != PARSE_ROLE_SPECIFIER ||'),
'adjacency':('_pext_u64(left, keep) == ((values << 1) & sequence)','(selection_fault("adjacency") || _pext_u64(left, keep) == ((values << 1) & sequence))'),
'final-operand':('(values & (sequence ^ (sequence >> 1))) != 0 ?','(selection_fault("final-operand") || (values & (sequence ^ (sequence >> 1))) != 0) ?'),
'has-association':('return association &&','return (selection_fault("has-association") || association) &&'),
}
for name,(a,b) in rules.items():
 assert body.count(a)==1,name;body=body.replace(a,b)
body=body.replace('parse_equal8(kinds, PARSE_KIND_R_BRACE) != 0)','parse_equal8(kinds, PARSE_KIND_R_BRACE) != 0))')
body=body.replace('kernels->vkinds[at] != PARSE_VKIND_TYPE_NAME))','kernels->vkinds[at] != PARSE_VKIND_TYPE_NAME))))')
s=s[:start]+body+s[stop:]
a='if (kernels->roles[i] == PARSE_ROLE_OPEN_CASE && association_list';assert s.count(a)==1;s=s.replace(a,'if (!selection_fault("default-role") && kernels->roles[i] == PARSE_ROLE_OPEN_CASE && association_list')
a='else if (association_list)';assert s.count(a)==1;s=s.replace(a,'else if (!selection_fault("colon-role") && association_list)')
f.write_text(s)
