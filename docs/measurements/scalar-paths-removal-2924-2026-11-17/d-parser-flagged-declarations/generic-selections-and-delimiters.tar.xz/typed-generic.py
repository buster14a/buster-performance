from pathlib import Path
from shutil import copytree
import runpy
p=Path(__file__).parent
src=(p/'generic-associations.py').read_text().split("d=p/'generic-inspect-src'")[0]
env={'__file__':str(p/'generic-associations.py')};exec(src,env)
def build(s):
 s=env['adjust'](s)
 a=s.index('// Each skipped flag belongs to');s=s[:a]+(p/'generic-selection.inc').read_text()+'\n'+s[a:]
 key='            const uint32_t close = parse_inline_asm_close(kernels, input, token, end);';assert s.count(key)==1
 s=s.replace(key,'''            const uint32_t close = input->kinds[token] == PARSE_KIND_GENERIC ? parse_generic_close(kernels, input, token, end) :
                                   parse_inline_asm_close(kernels, input, token, end);''')
 return s
d=p/'generic-src';copytree(p/'qualified-src',d,dirs_exist_ok=True);f=d/'buster/compiler/c_parser_impl.c';f.write_text(build((p/'qualified-src/buster/compiler/c_parser_impl.c').read_text()))
(p/'generic-shipping.c').write_text(build((p/'qualified-shipping.c').read_text()))
s=(p/'local-qualified-corpus.py').read_text().replace('qualified','generic');(p/'local-generic-corpus.py').write_text(s)
