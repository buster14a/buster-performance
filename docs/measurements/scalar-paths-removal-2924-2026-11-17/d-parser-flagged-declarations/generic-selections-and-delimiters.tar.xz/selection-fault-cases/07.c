int f(int x){return _Generic(x, long:3+);}
