int f(int x){return _Generic(x, default:0,default:1);}
