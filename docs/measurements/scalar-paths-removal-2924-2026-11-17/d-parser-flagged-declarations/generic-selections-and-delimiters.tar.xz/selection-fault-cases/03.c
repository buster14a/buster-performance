int f(int x){return _Generic(x, int:(int]x,default:1);}
