int f(int x){return _Generic(x,x *:1,default:2);}
