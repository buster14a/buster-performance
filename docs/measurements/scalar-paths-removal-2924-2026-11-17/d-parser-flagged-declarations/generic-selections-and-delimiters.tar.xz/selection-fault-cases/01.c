int f(int x){return _Generic(0?(x):(void*)1, const void*:3, default:4);}
