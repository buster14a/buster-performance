int f(int x){return _Generic(x, int: 0 ? 1 : 2, default: x);}
