int f(int x){return _Generic(x, int:x y);}
