int f(int x){return _Generic(x, const:2);}
