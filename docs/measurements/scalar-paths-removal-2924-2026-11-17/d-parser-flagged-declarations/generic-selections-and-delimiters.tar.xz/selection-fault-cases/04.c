int f(int x){return _Generic(x, int:a[i),default:0);}
