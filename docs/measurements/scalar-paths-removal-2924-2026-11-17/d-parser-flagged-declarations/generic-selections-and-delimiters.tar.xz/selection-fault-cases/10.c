int f(int x){return _Generic(x, 3:2);}
