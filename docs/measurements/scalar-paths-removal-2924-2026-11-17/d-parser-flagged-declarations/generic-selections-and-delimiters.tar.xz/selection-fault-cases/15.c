int f(int x){return _Generic(, default:1);}
