int f(int x){return _Generic(x, int:fn(,x),default:0);}
