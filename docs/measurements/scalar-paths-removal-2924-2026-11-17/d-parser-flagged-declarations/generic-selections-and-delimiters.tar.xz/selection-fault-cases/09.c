int f(int x){return _Generic(x, missing:2);}
