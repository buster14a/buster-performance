int f(int x){return _Generic(x, int:2, default:1];}
