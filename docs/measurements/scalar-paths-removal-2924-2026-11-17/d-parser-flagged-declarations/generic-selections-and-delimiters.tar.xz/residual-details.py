from pathlib import Path
from shutil import copytree
p=Path(__file__).parent;d=p/'residual-src';copytree(p/'cast-src',d,dirs_exist_ok=True)
f=d/'buster/compiler/c_parser_impl.c';s=f.read_text();s=s.replace('static const char* declaration_path;', 'static const char* declaration_path;\nstatic Preprocessor* remaining_pp;\nstatic Parser* remaining_parser;')
a=s.index('    ParseMeanings* meanings = input->meanings;',s.index('static void parse_fallback_item('))
s=s[:a]+'''    if (remaining_parser && !whole_reasons)
    {
        printf("statement\\t%s\\t%u\\t%u\\t", declaration_path, begin, end);
        for (uint32_t j=begin; j<=end; ++j)
        {
            const uint32_t k=parse_source_index(&remaining_parser->tokens,j);
            const PPTokens* out=&remaining_pp->output;
            uint8_t buf[64]; const uint8_t* spelling;
            const uint32_t len=pp_spelling(remaining_pp,out->kinds[k],out->values[k],out->locations[k],buf,&spelling);
            printf(" %.*s%s",(int)len,spelling,kernels->flags[j]?"^":"");
        }
        puts("");
    }
'''+s[a:]
key='            diff_roles += roles[i] != tree.roles[i];'
assert s.count(key)==1
s=s.replace(key,'''            if (roles[i]!=tree.roles[i] || depths[i]!=tree.depths[i] || parents[i]!=tree.parents[i])
                printf("change\\t%s\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\t%u\\n",declaration_path,begin,end,begin+i,roles[i],tree.roles[i],depths[i],tree.depths[i],parents[i],tree.parents[i]);
'''+key)
f.write_text(s)
s=(p/'probe-remaining.py').read_text()
s=s.replace("out=p/'remaining-items.log'","if group=='musl':\n mset={line.split('\\t')[0] for line in (p/'cast-source-trees/cast-musl.tsv').read_text().splitlines() if int(line.split('\\t')[3])}\n paths=[f for f in paths if str(f.relative_to(c)) in mset]\nout=p/f'residual-{group}.log'").replace("'remaining-columns'","'residual-columns'").replace("'remaining-temp.bin'","f'residual-{group}.bin'")
(p/'run-residual.py').write_text(s)
