from pathlib import Path
from hashlib import sha256
import os,subprocess
p=Path(__file__).resolve().parent;d=p/'selection-fault-cases';d.mkdir(exist_ok=True)
expr=['_Generic(x, int:4, default:x+1)','_Generic(0?(x):(void*)1, const void*:3, default:4)', '_Generic(x, int:4]','_Generic(x, int:(int]x,default:1)','_Generic(x, int:a[i),default:0)','_Generic(x, default:0,default:1)','_Generic(x, int:x y)','_Generic(x, long:3+)','_Generic(x)', '_Generic(x, missing:2)','_Generic(x, 3:2)','_Generic(x, const:2)','_Generic(x, x:2)', '_Generic(x,x *:1,default:2)', '_Generic(x, int:fn(,x),default:0)','_Generic(, default:1)','_Generic(x, int: 0 ? 1 : 2, default: x)','_Generic(x, int:4, default:)']
for i,expr in enumerate(expr):
 (d/f'{i:02d}.c').write_text('int f(int x){return '+expr+';}\n')
def get(tag,fault):
 data=[]
 for q in sorted(d.glob('*.c')):
  out=d/'sample.bin';out.write_bytes(b'')
  cmd=subprocess.run([str(p/(tag+'-columns')),'-std=gnu17','-nostdinc',str(q)],env={**os.environ,'BUSTER_DECL_TREE':str(out),'BUSTER_SELECTION_FAULT':fault},capture_output=True,check=True)
  [unit]=[list(map(int,l.split(b'\t')[2:]))for l in cmd.stdout.splitlines() if l.startswith(b'unit\t')]
  data.append((sha256(out.read_bytes()).hexdigest(),unit))
 return data
baseline=get('census','');control=get('precise','')
assert [a[0]for a in control]==[a[0]for a in baseline]
assert get('selection-mutant','control')==control
for fault in ['coverage','outer-close','inner-close','uniqueness','type','adjacency','final-operand','has-association','default-role','colon-role']:
 sample=get('selection-mutant',fault)
 trees=[i for i,(a,b) in enumerate(zip(control,sample)) if a[0]!=b[0]]
 routes=[i for i,(a,b) in enumerate(zip(control,sample)) if a[1]!=b[1]]
 print(fault,'changed trees or diagnostics',trees,'changed routes',routes,flush=True)
 assert trees or routes,fault
