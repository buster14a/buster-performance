void f(int a[__restrict__]);
