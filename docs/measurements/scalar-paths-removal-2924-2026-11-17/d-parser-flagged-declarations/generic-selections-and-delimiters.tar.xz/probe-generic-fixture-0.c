int f(int x){return _Generic(x, int: 4, default: x+1);}
