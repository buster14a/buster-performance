int f(int x){return _Generic(0, int:(int]x, default:2);}
