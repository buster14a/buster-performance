from pathlib import Path
from shutil import copytree
p=Path(__file__).parent
def refine(s):
 s=s.replace('parse_static_parameter_bound','parse_resolved_parameter_bound')
 s=s.replace('input->names[token] != C_NAME_STATIC || input->kinds[token] != PARSE_KIND_STORAGE ||','((input->names[token] != C_NAME_STATIC || input->kinds[token] != PARSE_KIND_STORAGE) &&\n        (input->names[token] != C_NAME_RESTRICT || input->kinds[token] != PARSE_KIND_QUALIFIER)) ||')
 s=s.replace('close <= token + 1 || close > end || close - token - 1 > 64','close <= token || close > end || close - token - 1 > 64')
 mark='    const uint32_t first = token + 1;\n    const uint64_t live = _bzhi_u64(UINT64_MAX, close - first);'
 assert s.count(mark)==1
 s=s.replace(mark,'''    if (input->names[token] == C_NAME_RESTRICT || close == token + 1)
    {
        return input->names[token] == C_NAME_RESTRICT && close == token + 1;
    }
'''+mark)
 mark='// Each flag must belong to a validated asm statement or parameter bound.'
 assert s.count(mark)==1
 s=s.replace(mark,(p/'compound-pointer.inc').read_text()+'\n// Each skipped flag belongs to a complete syntax form checked against the vector tree.')
 mark='            if (parse_resolved_parameter_bound(kernels, input, token, end))'
 s=s.replace(mark,'''            if (parse_addressed_pointer_literal(kernels, input, token, end))
            {
                first = token + 1;
                continue;
            }
'''+mark)
 return s
d=p/'literal-src';copytree(p/'cast-src',d,dirs_exist_ok=True)
f=d/'buster/compiler/c_parser_impl.c';f.write_text(refine((p/'cast-src/buster/compiler/c_parser_impl.c').read_text()))
(p/'literal-shipping.c').write_text(refine((p/'cast-shipping.c').read_text()))
s=(p/'local-cast-corpus.py').read_text().replace("['inline','cast']","['cast','literal']").replace('cast-source-trees','literal-source-trees').replace("rows['inline']","rows['cast']").replace("rows['inline'].items()","rows['cast'].items()").replace("rows['cast'][k]","rows['literal'][k]").replace("hashes['inline']","hashes['literal']")
(p/'local-literal-corpus.py').write_text(s)
