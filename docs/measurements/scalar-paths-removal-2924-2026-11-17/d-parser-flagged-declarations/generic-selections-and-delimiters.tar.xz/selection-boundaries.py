from pathlib import Path
from hashlib import sha256
import os,random,subprocess,sys
p=Path(__file__).resolve().parent;d=p/'selection-boundaries';d.mkdir(exist_ok=True)
forms=['int f(int x){return G;}','int f(int x){return (G);}','int f(int x){if(G) x+=1; return x;}','int f(int x){switch(x){case G: return x;default: return G;}}','int f(int x){switch(x){case 1: return G;default: x++;}return 0;}','int f(int x){int y = G; return y;}','int f(int x){int a[G];return 0;}','int f(int x){return x? G : G;}','int x = G;','int f(int x){return G + ;}','int f(int x){return G x;}','int f(int x){return G; int z = ;}','int f(int x){goto done;done: return G;}']
keys=['unsigned','float','default','T','const T *','_Atomic(int)','__typeof__(x)','struct S *','int **','typeof(x)','long double','int (*)(int)','volatile T','static int','42','',',','default +','default:2:']
values=['0','x','++x','x++','!x','~x','&x','0 ? &x : (void *)0','(int)x','(const T*)x','f(x)','f(x, x+1)','f()','f((x))','x ? x ? 0 : 1 : 2','x->a.x','x[0][0]','"a" "b"','(T){2}','(int)(x ? 1 : 2)','G0','(x,x)','x ?: 1','x?x','x:2','0x1p+0','x ? 1 :','f((x),)','[x]','x,','x.+y','x && (x +)','',')','int','default']
opens=['(', '[','{'];closes=[')',']','}'];cases=set();rng=random.Random(34412924)
for n in [0,1,2,3,4,15,16,17,30,31,32,33,61,62,63,64,65,66,127,128]:
 for shift in range(64):
  for expr in ['_Generic(x,int:'+('x+'*n)+'1,default:2)','_Generic(0?(x):(void*)0,default:'+('('*n)+'x'+(')'*n)+')','_Generic(x,int:x?,default:2)','_Generic(x,int:f(x],default:1)','_Generic(x,int: x, default:)']:
   cases.add('typedef int T; '+'; '*shift+forms[0].replace('G',expr)+'\n')
for i in range(12000):
 expr='_Generic('+rng.choice(values[:23])+','+','.join(rng.choice(keys)+':'+rng.choice(values)for _ in range(rng.randint(1,4)))+')'
 expr=expr.replace('G0','_Generic(x, default: x? 2 : 3, T*:x)')
 if i%2==0:
  j=rng.randrange(len(expr));k=rng.randrange(min(3,len(expr)-j)+1)
  expr=expr[:j]+rng.choice(opens+closes+['?',':',',','default',';','const',' ','','*','/','++','x','42'])+expr[j+k:]
 cases.add('typedef int T; '+rng.choice(forms).replace('G',expr)+'\n')
files=[]
for i,s in enumerate(sorted(cases)):
 q=d/f'{i:05d}.c';
 if not q.exists():q.write_text(s)
 files.append(q)
def run(tag,ps,dialect):
 f=d/(tag+'.bin');f.write_bytes(b'');r=subprocess.run([str(p/(tag+'-columns')),'-std='+dialect,'-nostdinc',*map(str,ps)],env={**os.environ,'BUSTER_DECL_TREE':str(f)},capture_output=True)
 return r.returncode,r.stderr,f.read_bytes()
def compare(q,lang,h):
 a=run('census',q,lang);b=run('precise',q,lang)
 if len(q)>1 and (a[:2]!=(0,b'') or b[:2]!=(0,b'') or a[2]!=b[2]):
  mid=len(q)//2;left=compare(q[:mid],lang,h);right=compare(q[mid:],lang,h);return tuple(x+y for x,y in zip(left,right))
 if a!=b:
  print('different',lang,q[0].name,q[0].read_text().strip(),a[:2],b[:2],flush=True);return 1,0,0
 assert a[0] in (0,1),(q,a[:2])
 h.update(bytes([a[0]]));h.update(a[1]);h.update(a[2])
 return 0,len(q)*int(a[0]==0),len(q)*int(a[0]!=0)
for lang in ('gnu17','c23','c89'):
 h=sha256();bad=valid=rejected=0
 for i in range(0,len(files),64):
  x,y,z=compare(files[i:i+64],lang,h);bad+=x;valid+=y;rejected+=z
  if bad>=10:break
 print(lang,len(files),bad,valid,rejected,h.hexdigest(),flush=True)
 if bad:raise SystemExit(1)
