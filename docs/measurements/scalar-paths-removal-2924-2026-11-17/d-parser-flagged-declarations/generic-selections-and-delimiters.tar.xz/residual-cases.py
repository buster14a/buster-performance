from pathlib import Path
import subprocess,os,sys,hashlib,struct
p=Path(__file__).parent; tag=sys.argv[1]; d=p/'residual-cases';d.mkdir(exist_ok=True)
sources=set()
forms=['void f(int a[Q]);','int f(int a[Q]){return a[0];}','int f(char *const argv[Q],char *const envp[Q]){return 0;}','int f(int p[Q],int p);','int f(int (*p)[Q]);','int f(int (*p)(int a[Q]));','int f(int a[Q][2]);','int f(int a[2][Q]);','int f(void){int a[Q];}','int x[Q];','int f(int a[Q],);','int f(a[Q]){return 1;}','int f(int a[Q], int) {return 1 + ;}','int f(struct a a[Q]);','int f(int a[Q] x);','int f(int a[Q]) {typedef int U; U u=;}']
for qual in ['restrict','__restrict','__restrict__','const','volatile','restrict restrict','restrict const','restrict *','restrict 1','restrict static','static','static 4','static 1++','',',','typedef','extern','*','[restrict]','__attribute__((x))']:
 for form in forms:sources.add(form.replace('Q',qual))
forms=['void f(void*p){g(&(TYPE){EXPR});}','void f(void*p){g((TYPE){EXPR});}','void f(void*p){x = &(TYPE){EXPR};}','void f(void*p){g(x &(TYPE){EXPR});}','int f(void*p){return (&(TYPE){EXPR})!=0;}','void f(){ return g(&(TYPE){EXPR},); }','void f(int k){switch(k){case (TYPE){EXPR}:break;}}','void f(){ const int a[sizeof((TYPE){EXPR})]; }','void f(){__asm__(""::"m"(*(TYPE){EXPR}));}','int k=(TYPE){EXPR};','void f(){return g(&(TYPE){EXPR})+;}']
for typ in ['char *','void *','const T *','volatile int *','T *','int','int **','char *const','restrict int *','_Atomic char *','const const T *','unsigned char *','int float *','T T *','X *','void **','typedef int *','char (*)()','int (*)(void)','int *x','int *[2]','int *restrict','const *','*','']:
 for val in ['p','1','0','"a"','"a" "b" "c"+p%256','p+2*3','p & p','p<2','p="a"','"x" p','p p','1 2','1+2+','(p)','{p}', 'p, p', '.x=1','[0]=p','+p','p++','return',';','p ? a : b','p + *p','p && (q)','p sizeof(int)','']:
  for form in forms:sources.add('typedef int T; '+form.replace('TYPE',typ).replace('EXPR',val))
names=['name','(name)','(*name)','name[3]','*name','name()','name(int x)','name(int x,int x)','name(, )','name(int, )','name(x)','name(x,...)','name(int *x,char *const a[restrict])','name(int x,void (*p)(int))','name(int x, void (*p)(int), long *a)','name(int x,void (*p)(int int))','name(int x,void (*)(int))','name(int x,int (*p)[3])','name(const void *p, T *q)','name(T)','name(int (*p)(int,),int x)','name(int (*p)(int),int ,)','name(return)','name(void)','name(int[*])']
for prefix in ['void','static void','int','typedef void','int x,','extern T','static int x,','struct S','const char','void int','']:
 for name in names:
  for group in ['(*NAME)','(**NAME)','(NAME)','(*const NAME)','(*NAME[2])','(*NAME, other)','(*NAME())','(*NAME)(int)','( (*NAME) )']:
   for tail in ['(int){return 0;}','(void){return;}','(){return;}','(int int){return;}','(int x,){return;}','(int)[2]{return;}','(T*x, long y){return;}','(int);','(int){return 1+;}','(int){ int x = ; }']:
    sources.add('typedef int T; '+prefix+' '+group.replace('NAME',name)+tail)
paths=[]
for i,s in enumerate(sorted(sources)):
 q=d/f'{i:05d}.c'
 if not q.exists():q.write_text(s+'\n')
 paths.append(q)
def once(binary,paths):
 out=p/f'residual-output-{tag}-{binary}.bin';out.write_bytes(b'')
 a=subprocess.run([str(p/(binary+'-columns')),'-std='+dialect,'-nostdinc',*map(str,paths)],env={**os.environ,'BUSTER_DECL_TREE':str(out)},capture_output=True,check=True)
 rows=[tuple(map(int,row.split(b'\t')[2:]))for row in a.stdout.splitlines()if row.startswith(b'unit\t')];assert len(rows)==len(paths)
 return out.read_bytes(),rows
for dialect in sys.argv[2:] or ['c11','gnu11','c17','gnu17','c23','gnu23']:
 hasher=hashlib.sha256();saved=0
 for start in range(0,len(paths),64):
  part=paths[start:start+64];a,ar=once('cast',part);b,br=once(tag,part)
  if a!=b:
   for f in part:
    ca,x=once('cast',[f]);cb,y=once(tag,[f])
    if ca!=cb:print('DIFFERENCE',dialect,f,f.read_text().strip(),x,y,flush=True)
   raise SystemExit(1)
  assert all(x[0]==y[0] and x[2]>=y[2] and x[3]>=y[3] and x[4:]==y[4:]for x,y in zip(ar,br))
  saved+=sum(x[2]-y[2] for x,y in zip(ar,br));hasher.update(a)
 print(dialect,len(paths),saved,hasher.hexdigest(),flush=True)
