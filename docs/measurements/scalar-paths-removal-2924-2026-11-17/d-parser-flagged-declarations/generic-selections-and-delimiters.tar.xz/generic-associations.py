from pathlib import Path
from shutil import copytree
p=Path(__file__).parent
def adjust(s):
 a=s.index('static void parse_secondary_avx512(');b=s.index('    while (open != 0)\n',a)
 sub=s[a:b]
 old='            if (kernels->roles[i] == PARSE_ROLE_OPEN_TERNARY || kernels->roles[i] == PARSE_ROLE_OPEN_CASE)'
 assert sub.count(old)==1
 sub=sub.replace(old,'''            const uint32_t group = kernels->enclosing[i];
            const bool association_list = group > 0 && group < i && kernels->vkinds[group - 1] == PARSE_KIND_GENERIC &&
                                          kernels->roles[group] == PARSE_ROLE_OPEN_KEYWORD;
            if (kernels->roles[i] == PARSE_ROLE_OPEN_CASE && association_list && kernels->vkinds[i] == PARSE_KIND_DEFAULT &&
                i + 1 < count && kernels->vkinds[i + 1] == PARSE_KIND_COLON)
            {
                kernels->roles[i] = PARSE_ROLE_OPERAND;
            }
            else if (kernels->roles[i] == PARSE_ROLE_OPEN_TERNARY || kernels->roles[i] == PARSE_ROLE_OPEN_CASE)''')
 old='''                else
                {
                    const uint8_t previous'''
 assert sub.count(old)==1
 sub=sub.replace(old,'''                else if (association_list)
                {
                    kernels->roles[i] = PARSE_ROLE_ASSOCIATION;
                }
                else
                {
                    const uint8_t previous''')
 return s[:a]+sub+s[b:]
d=p/'generic-inspect-src';copytree(p/'residual-src',d,dirs_exist_ok=True);f=d/'buster/compiler/c_parser_impl.c';f.write_text(adjust((p/'residual-src/buster/compiler/c_parser_impl.c').read_text()))
s=(p/'run-residual.py').read_text().replace('residual-columns','generic-inspect-columns').replace("f'residual-{group}","f'generic-inspect-{group}")
(p/'run-generic-inspect.py').write_text(s)
