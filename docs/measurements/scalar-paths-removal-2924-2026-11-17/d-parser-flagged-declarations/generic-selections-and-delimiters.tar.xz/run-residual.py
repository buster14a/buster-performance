from collections import Counter
from pathlib import Path
from hashlib import sha256
import os,sys,subprocess
p=Path(__file__).parent;c=p.parent/'buster-2924-parser-corpora'
r=p/'local-source-trees';r.mkdir(exist_ok=True)
group=sys.argv[1]
if group=='musl':
 m=c/'libc/musl';gen=c/'musl-generated'
 flags=['-std=c99','-nostdinc','-ffreestanding','-D_XOPEN_SOURCE=700']
 for d in [m/'arch/x86_64',m/'arch/generic',gen/'obj/src/internal',m/'src/include',m/'src/internal',gen/'obj/include',m/'include']:flags+=['-I',str(d)]
 paths=[];seen=set()
 for f in sorted((m/'src').glob('*/*.c'))+sorted((m/'src').glob('*/x86_64/*.c')):
  if f.name not in seen:paths.append(f);seen.add(f.name)
 assert len(paths)==1336
else:
 flags=['-std=gnu17','-nostdinc','--predefines',str(c/'provenance/gnu17-pinned-predefines.txt')]
 for d in ['usr/lib/clang/23/include','usr/local/include','usr/include']:flags+=['-isystem',str(c/'headers'/d)]
 if group=='lua':
  paths=sorted((c/'src').glob('*.c'));assert len(paths)==34
 elif group=='sqlite':
  flags+=['-DSQLITE_OMIT_LOAD_EXTENSION','-DSQLITE_THREADSAFE=0','-DSQLITE_ENABLE_MEMSYS5','-DSQLITE_ENABLE_RTREE','-I',str(c/'sqlite')]
  paths=[c/'sqlite/sqlite3.c']
 else:raise ValueError(group)
if group=='musl':
 mset={line.split('\t')[0] for line in (p/'cast-source-trees/cast-musl.tsv').read_text().splitlines() if int(line.split('\t')[3])}
 paths=[f for f in paths if str(f.relative_to(c)) in mset]
out=p/f'residual-{group}.log'
with out.open('wb')as log:
 for i in range(0,len(paths),24):
  part=paths[i:i+24];tmp=p/f'residual-{group}.bin';tmp.write_bytes(b'')
  proc=subprocess.run([str(p/'residual-columns'),*flags,*map(str,part)],env={**os.environ,'BUSTER_DECL_TREE':str(tmp)},stdout=log,stderr=subprocess.PIPE,check=True)
  tmp.unlink()
