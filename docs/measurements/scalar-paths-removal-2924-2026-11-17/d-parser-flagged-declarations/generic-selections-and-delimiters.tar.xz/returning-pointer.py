from pathlib import Path
from shutil import copytree
p=Path(__file__).parent
def update(s):
 a=s.index('// A grouped identifier with an immediately following parameter list');b=s.index('// A function body follows',a)
 s=s[:a]+'''// A top-level group before a parameter list can still derive a function first. In (name) the
// outside list applies to the name. In (*name(parameters)) the inner list already makes
// name a function, and the outer list describes the pointed-to function. K6 checks both lists.
static uint32_t parse_body_function_group(const ParseKernels* kernels, uint32_t close, uint32_t body)
{
    if (close < 2 || body - close < 3 || kernels->check_groups[body - 1] != PARSE_GROUP_PARAMETERS ||
        kernels->enclosing[body - 1] != close + 1 || kernels->roles[close + 1] != PARSE_ROLE_OPEN_CALL ||
        kernels->check_groups[close] != PARSE_GROUP_DECLARATOR)
    {
        return BUSTER_PARSE_NONE;
    }
    const uint32_t open = kernels->enclosing[close];
    if (open >= close || kernels->roles[open] != PARSE_ROLE_OPEN_GROUP)
    {
        return BUSTER_PARSE_NONE;
    }
    const bool pointer = close - open >= 5 && kernels->vkinds[open + 1] == PARSE_KIND_STAR && kernels->roles[open + 1] == PARSE_ROLE_PREFIX &&
                         kernels->check_groups[close - 1] == PARSE_GROUP_PARAMETERS && kernels->enclosing[close - 1] == open + 3 &&
                         kernels->roles[open + 3] == PARSE_ROLE_OPEN_CALL;
    const uint32_t name = open + 1 + pointer;
    return (close - open == 2 || pointer) && kernels->vkinds[name] == PARSE_KIND_IDENTIFIER &&
           kernels->roles[name] == PARSE_ROLE_OPERAND ? open : BUSTER_PARSE_NONE;
}

'''+s[b:]
 a=s.index('            if ((flagged & closes & bit) != 0 && parse_body_grouped_name(');b=s.index('            else\n',a)
 s=s[:a]+'''            const uint32_t group = (flagged & closes & bit) != 0 ? parse_body_function_group(kernels, token, body) : BUSTER_PARSE_NONE;
            if (group != BUSTER_PARSE_NONE)
            {
                end = group;
            }
'''+s[b:]
 return s
d=p/'returning-src';copytree(p/'literal-src',d,dirs_exist_ok=True);f=d/'buster/compiler/c_parser_impl.c';f.write_text(update((p/'literal-src/buster/compiler/c_parser_impl.c').read_text()))
(p/'returning-shipping.c').write_text(update((p/'literal-shipping.c').read_text()))
s=(p/'local-literal-corpus.py').read_text().replace('literal','returning')
(p/'local-returning-corpus.py').write_text(s)
