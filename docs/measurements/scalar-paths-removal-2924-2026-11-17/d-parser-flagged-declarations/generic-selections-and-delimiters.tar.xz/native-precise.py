from pathlib import Path
from subprocess import run, check_output
from difflib import unified_diff
import os,struct,json
p=Path(__file__).resolve().parent
def patch(name,value):
 old=check_output(['git','show','cc7d4ffb4:'+name],cwd=p/'tree').decode()
 return ''.join(unified_diff(old.splitlines(True),value.splitlines(True),'a/'+name,'b/'+name))
rows=[];bad=[]
for i in range(4):
 path=p/f'probe-generic-fixture-{i}.c';source=path.read_text()
 if i==1:
  source=source.replace('0?(x)', '0?(&x)');path.write_text(source)
 data=[]
 for tag in ('census','precise'):
  f=p/f'precise-fixture-{i}-{tag}.bin';f.write_bytes(b'')
  res=run([str(p/(tag+'-columns')),'-std=gnu17','-nostdinc',str(path)],env={**os.environ,'BUSTER_DECL_TREE':str(f)},capture_output=True,check=True)
  [(n,flagged,items,tokens,whole,errors)]=[list(map(int,l.split(b'\t')[2:])) for l in res.stdout.splitlines() if l.startswith(b'unit\t')]
  assert bool(errors)==(i>=2)
  data.append(f.read_bytes())
  if i<2:
   assert n<=64 and items==int(tag=='census') and not whole
   parents=struct.unpack_from('='+str(n)+'i',data[-1],20+5*n)
 assert data[0]==data[1]
 if i<2:
  rows.append('    { '+json.dumps(source)+', '+str(n)+', { '+', '.join(map(str,parents))+' }, true },\n')
 else:
  diag="1:"+str(49 if i==2 else 41)+": expected ')'"
  bad.append('    { '+json.dumps(source)+', '+json.dumps(diag)+', 0 },\n')
s=(p/'checked-test.c').read_text();pos=s.index('    { "void f(int a[static 3');s=s[:pos]+''.join(rows)+s[pos:]
pos=s.index('    { "void f(void) { asm(\\"a\\", \\"b\\"); }');s=s[:pos]+''.join(bad)+s[pos:];(p/'precise-test.c').write_text(s)
(p/'precise-compiler.patch').write_text(patch('src/buster/compiler/c_parser_impl.c',(p/'precise-shipping.c').read_text())+patch('src/buster/compiler/c_parser_test.c',s))
for name in ('build-qualified','measure-qualified','sources-qualified','ordinary-qualified','whole-qualified'):
 s=(p/name).read_text().replace('qualified','precise').replace('plan-builds-clean.ok','narrow-builds-clean.ok').replace('Validate precise parameter arrays, pointer literals and grouped function definitions in the production parser','Check generic selections, pointer literals and array qualifiers in the vector parser')
 if name=='build-qualified':s=s[:s.index('cd "$root/frozen-grouped"')]+'bash "$root/verify-revised-parser" precise\n'
 (p/name.replace('qualified','precise')).write_text(s)
d=p/'precise-widths';d.mkdir(exist_ok=True)
for n in [0,1,2,3,4,7,8,9,15,16,17,31,32,33,63,64,65,127]:
 for tag in ('associations','selection','ordinary','qualifiers','literal','parameters'):
  orig=p/'qualified-widths'/f'{tag}-{n}.c'
  if orig.exists():
   (d/orig.name).write_bytes(orig.read_bytes());continue
  if tag=='associations':
   stmt='return _Generic(x,'+''.join('struct S'+str(i)+' *: '+str(i)+',' for i in range(n))+' default:0);'
  else:
   stmt='return _Generic(x, int: '+'+'.join(['x']*(n+1))+', default:2);'
  (d/f'{tag}-{n}.c').write_text('\n'.join('int f'+str(i)+'(int x){'+stmt+'}' for i in range(32))+'\n')
