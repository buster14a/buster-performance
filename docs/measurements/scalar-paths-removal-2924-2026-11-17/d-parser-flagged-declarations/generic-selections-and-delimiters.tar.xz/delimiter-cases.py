from pathlib import Path
import os,sys,subprocess,itertools
p=Path(__file__).parent;d=p/'delimiter-cases';d.mkdir(exist_ok=True)
templates=['void f(int a[static 1+sizeof(int)]);','int f(int a[static 3]){return a[0];}','void f(int a[__restrict__]);','void f(char *p){g(&(char *){p});}','void f(char *p){g(&(const char *){"a" "b" + 1});}','void (*fn(int x, void (*p)(int)))(int){return p;}','int (f)(int x){return x;}','asm ("abcd");','void f(void *p){asm volatile(""::"m"(*(void *volatile *)p):"memory");}','void f(int p){asm("" : "=r"(p) : "r"(p));}','int f(int x){return _Generic(x,int:g(x),default:(void *)1);}','int f(int x){if(_Generic(0?(x):(void*)1,const void*:(const char*)(g(x,2)),default:g(x,2)))return 1;return 0;}']
sources=set(templates)
for s in templates:
 ix=[i for i,x in enumerate(s)if x in '()[]{}']
 for i in ix:
  for rep in '()[]{}':sources.add(s[:i]+rep+s[i+1:])
 for i,j in itertools.combinations(ix,2):
  for a in ('([{' if s[i] in '([{' else ')]}'):
   for b in ('([{' if s[j] in '([{' else ')]}'):
    sources.add(s[:i]+a+s[i+1:j]+b+s[j+1:])
paths=[]
for i,s in enumerate(sorted(sources)):
 f=d/f'{i:05d}.c';f.write_text(s+'\n');paths.append(f)
a,b=sys.argv[1:3]
def run(tag,paths):
 f=p/f'delimiter-{a}-{b}-{tag}.bin';f.write_bytes(b'')
 res=subprocess.run([str(p/(tag+'-columns')),'-std=gnu17','-nostdinc',*map(str,paths)],capture_output=True,env={**os.environ,'BUSTER_DECL_TREE':str(f)},check=True)
 return f.read_bytes(),[x for x in res.stdout.splitlines() if x.startswith(b'unit\t')]
bad=0
for i in range(0,len(paths),64):
 sub=paths[i:i+64];x,_=run(a,sub);y,_=run(b,sub)
 if x!=y:
  for f in sub:
   x,rx=run(a,[f]);y,ry=run(b,[f])
   if x!=y:
    print('diff',f.name,f.read_text().strip(),rx[0].split(b'\t')[2:],ry[0].split(b'\t')[2:],flush=True);bad+=1
print(len(paths),bad,flush=True)
raise SystemExit(1 if bad else 0)
