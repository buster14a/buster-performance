from pathlib import Path
from hashlib import sha256
import subprocess,os
p=Path(__file__).resolve().parent;d=p/'added-alignments';d.mkdir(exist_ok=True)
rows=[]
sources=[(p/'delimiter-cases'/f'{n}.c').read_bytes() for n in ('02171','02365')]+[(p/f'probe-generic-fixture-{n}.c').read_bytes() for n in range(4)]
for n,source in enumerate(sources):
 files=[]
 for shift in range(64):
  q=d/f'{n}-{shift}.c';q.write_bytes(b'; '*shift+source);files.append(q)
 oracle=None
 for tag in ('census','asmclose','checked','precise'):
  tree=d/f'{tag}.bin';tree.write_bytes(b'')
  o=subprocess.run([str(p/(tag+'-columns')),'-std=gnu17','-nostdinc',*map(str,files)],env={**os.environ,'BUSTER_DECL_TREE':str(tree)},capture_output=True,check=True)
  data=tree.read_bytes();summ=[list(map(int,l.split(b'\t')[2:])) for l in o.stdout.splitlines() if l.startswith(b'unit\t')];assert len(summ)==64
  if tag=='census':oracle=data
  assert data==oracle,(n,tag)
  print(n,tag,len(data),sha256(data).hexdigest(),sum(x[2] for x in summ),sum(x[5] for x in summ),flush=True)
