from pathlib import Path
p=Path(__file__).parent; f=p/'census.c';s=f.read_text()
a=s.index('            pp_release(&pp);')
s=s[:a]+'''            if (loaded)
            {
                const ParseParser* parser = &file->parser;
                const char* path = getenv("BUSTER_DECL_TREE");
                FILE* report = fopen(path,"ab");
                if (report == NULL) abort();
                uint32_t header[] = { f, parser->tokens.count, parser->errors, parser->fatal, parser->diagnostic_count };
                fwrite(header,sizeof(header),1,report);
                for (uint32_t d=0; d<parser->diagnostic_count; ++d)
                {
                    const ParseDiagnostic* diag=&parser->diagnostics[d];
                    uint32_t row[] = { diag->token, diag->argument, diag->message, diag->place, diag->error, diag->note };
                    fwrite(row,sizeof(row),1,report);
                }
                uint32_t n=parser->tokens.count;
                if (parser->errors == 0 && parser->fatal == PARSE_MESSAGE_NONE && n != 0)
                {
                    fwrite(parser->tree.roles,1,n,report);
                    fwrite(parser->tree.depths,sizeof(uint32_t),n,report);
                    fwrite(parser->tree.parents,sizeof(uint32_t),n,report);
                    const uint32_t* columns[] = {parser->postorder,parser->positions,parser->ends,parser->first_children,parser->next_siblings,parser->sizes};
                    for (uint32_t col=0; col<6; ++col)
                    {
                        const uint32_t present = columns[col] != NULL;
                        fwrite(&present,sizeof(present),1,report);
                        if (present) fwrite(columns[col],sizeof(uint32_t),n,report);
                    }
                }
                if (ferror(report) || fclose(report)!=0) abort();
            }
'''+s[a:]
s=s.replace('const ParseParser* parser = &file->parser;','const __typeof__(file->parser)* parser = &file->parser;')
(p/'oracle.c').write_text(s)
d=p/'declarations';d.mkdir(exist_ok=True)
# Matched-file pairs use the same exact input, including invalid declarations and errors within the body.
cases=[]
for decl in ['int (f)','int f','int ((f))','int *(f)','int (*f)','int (*f(void))','int (f[2])','int (f, g)','int f0, (f)','typedef int (f)','int (a+b)','int (**f)','int (f)(int x)','int (f)[4]','int (f) __attribute__((unused))','int (T)']:
 for params in ['()','(void)','(int)','(int x)','(int x, char *y)','(int x, ...)','(...)','(x)','(x, y)','(int x,)','(void x)','(int (*g)(int))','(const int x[3])','[4]','(int x)[4]','(void)(void)']:
  for body in [' { return 1; }',' { return (1 + ; }',';']:
   cases.append('typedef unsigned T;\n'+decl+params+body+'\n')
for n,case in enumerate(cases):(d/f'{n:04d}.c').write_text(case)
