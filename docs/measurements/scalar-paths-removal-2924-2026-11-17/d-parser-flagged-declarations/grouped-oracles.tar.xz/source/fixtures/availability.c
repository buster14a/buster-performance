__attribute__((availability(macos,introduced=10.12))) int f(void);
