int f(a,b) int a; long b; { return a+b; }
