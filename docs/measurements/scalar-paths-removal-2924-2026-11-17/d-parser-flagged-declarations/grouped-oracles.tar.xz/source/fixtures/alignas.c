typedef int T; _Alignas(16) T x;
