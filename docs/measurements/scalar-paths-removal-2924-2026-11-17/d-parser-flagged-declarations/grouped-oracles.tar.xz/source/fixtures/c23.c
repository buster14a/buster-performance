[[maybe_unused]] int a;
int f(void) { return a; }
