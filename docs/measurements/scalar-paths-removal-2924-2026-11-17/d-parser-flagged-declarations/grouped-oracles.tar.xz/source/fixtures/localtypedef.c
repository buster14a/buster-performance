int f(void) { typedef int word; word x = 3; return x; }
