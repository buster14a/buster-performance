__asm__(".text");
int f(int x) { __asm__ volatile ("" : "+r" (x)); return x; }
