void f(int a[__restrict 16]);
void g(int a[static __restrict 8]) { a[0] = 1; }
