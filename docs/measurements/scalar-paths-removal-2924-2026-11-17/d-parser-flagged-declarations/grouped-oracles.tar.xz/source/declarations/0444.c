typedef unsigned T;
typedef int (f)(int x, char *y) { return 1; }
