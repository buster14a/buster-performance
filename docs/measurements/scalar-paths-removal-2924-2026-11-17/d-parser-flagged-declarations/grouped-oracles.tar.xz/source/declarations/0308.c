typedef unsigned T;
int (f[2])(...);
