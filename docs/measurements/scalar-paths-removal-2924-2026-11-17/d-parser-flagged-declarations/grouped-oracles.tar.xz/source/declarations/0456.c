typedef unsigned T;
typedef int (f)(x, y) { return 1; }
