typedef unsigned T;
int (f[2])[4] { return (1 + ; }
