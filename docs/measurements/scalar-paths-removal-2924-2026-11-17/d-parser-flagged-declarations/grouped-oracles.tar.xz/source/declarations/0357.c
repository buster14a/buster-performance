typedef unsigned T;
int (f, g)(x) { return 1; }
