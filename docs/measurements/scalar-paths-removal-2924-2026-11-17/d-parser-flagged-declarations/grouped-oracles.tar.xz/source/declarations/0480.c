typedef unsigned T;
int (a+b)() { return 1; }
