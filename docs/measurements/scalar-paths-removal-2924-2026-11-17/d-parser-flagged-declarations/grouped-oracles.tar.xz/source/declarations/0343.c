typedef unsigned T;
int (f, g)(int) { return (1 + ; }
