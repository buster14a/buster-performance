typedef unsigned T;
int (f[2])[4];
