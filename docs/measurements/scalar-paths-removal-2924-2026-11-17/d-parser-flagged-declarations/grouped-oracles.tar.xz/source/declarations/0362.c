typedef unsigned T;
int (f, g)(x, y);
