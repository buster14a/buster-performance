typedef unsigned T;
int (*f(void))(int x, char *y);
