typedef unsigned T;
int (f[2])(int (*g)(int)) { return 1; }
