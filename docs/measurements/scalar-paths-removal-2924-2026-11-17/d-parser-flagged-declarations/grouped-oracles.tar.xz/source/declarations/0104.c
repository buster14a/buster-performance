typedef unsigned T;
int ((f))(int);
