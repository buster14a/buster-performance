typedef unsigned T;
int f0, (f)(int x)[4] { return (1 + ; }
