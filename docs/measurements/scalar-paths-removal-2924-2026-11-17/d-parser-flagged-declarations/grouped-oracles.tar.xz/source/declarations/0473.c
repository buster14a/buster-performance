typedef unsigned T;
typedef int (f)[4];
