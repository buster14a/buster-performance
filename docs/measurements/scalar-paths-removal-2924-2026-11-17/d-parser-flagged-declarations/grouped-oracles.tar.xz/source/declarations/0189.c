typedef unsigned T;
int *(f)(void)(void) { return 1; }
