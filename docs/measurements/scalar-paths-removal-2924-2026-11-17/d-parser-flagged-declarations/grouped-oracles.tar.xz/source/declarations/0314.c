typedef unsigned T;
int (f[2])(x, y);
