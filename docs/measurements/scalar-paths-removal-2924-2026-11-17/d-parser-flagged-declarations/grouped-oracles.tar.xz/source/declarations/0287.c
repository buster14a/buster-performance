typedef unsigned T;
int (*f(void))(void)(void);
