typedef unsigned T;
int f(void);
