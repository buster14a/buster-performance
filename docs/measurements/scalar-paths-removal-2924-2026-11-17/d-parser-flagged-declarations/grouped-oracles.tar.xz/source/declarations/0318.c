typedef unsigned T;
int (f[2])(void x) { return 1; }
