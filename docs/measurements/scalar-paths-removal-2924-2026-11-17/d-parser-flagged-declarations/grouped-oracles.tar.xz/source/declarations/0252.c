typedef unsigned T;
int (*f(void))(int x, char *y) { return 1; }
