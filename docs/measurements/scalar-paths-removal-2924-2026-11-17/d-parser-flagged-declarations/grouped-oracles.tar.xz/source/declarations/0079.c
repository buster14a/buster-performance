typedef unsigned T;
int f(void x) { return (1 + ; }
