typedef unsigned T;
int (*f)(int x, ...);
