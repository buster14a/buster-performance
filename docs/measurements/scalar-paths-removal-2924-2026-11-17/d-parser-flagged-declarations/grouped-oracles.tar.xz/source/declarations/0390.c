typedef unsigned T;
int f0, (f)(int) { return 1; }
