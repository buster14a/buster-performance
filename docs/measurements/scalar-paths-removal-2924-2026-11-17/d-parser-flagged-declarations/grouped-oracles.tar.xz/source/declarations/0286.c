typedef unsigned T;
int (*f(void))(void)(void) { return (1 + ; }
