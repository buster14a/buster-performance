typedef unsigned T;
int (f[2])(int) { return (1 + ; }
