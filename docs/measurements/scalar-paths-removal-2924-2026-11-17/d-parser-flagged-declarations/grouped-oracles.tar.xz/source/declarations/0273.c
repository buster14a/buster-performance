typedef unsigned T;
int (*f(void))(int (*g)(int)) { return 1; }
