typedef unsigned T;
typedef int (f)(void x) { return 1; }
