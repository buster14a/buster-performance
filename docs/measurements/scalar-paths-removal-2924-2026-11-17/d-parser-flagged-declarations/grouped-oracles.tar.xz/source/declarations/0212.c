typedef unsigned T;
int (*f)(...);
