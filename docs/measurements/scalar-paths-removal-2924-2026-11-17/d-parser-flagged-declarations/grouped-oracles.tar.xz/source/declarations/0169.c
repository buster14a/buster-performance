typedef unsigned T;
int *(f)(x, y) { return (1 + ; }
