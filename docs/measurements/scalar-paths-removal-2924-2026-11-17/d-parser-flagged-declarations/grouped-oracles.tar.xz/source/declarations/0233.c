typedef unsigned T;
int (*f)[4];
