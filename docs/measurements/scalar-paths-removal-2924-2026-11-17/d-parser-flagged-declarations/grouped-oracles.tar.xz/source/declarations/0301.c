typedef unsigned T;
int (f[2])(int x, char *y) { return (1 + ; }
