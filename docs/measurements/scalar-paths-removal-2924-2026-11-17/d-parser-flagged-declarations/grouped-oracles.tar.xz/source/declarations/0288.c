typedef unsigned T;
int (f[2])() { return 1; }
