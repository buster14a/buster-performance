typedef unsigned T;
int f0, (f)(const int x[3]) { return (1 + ; }
