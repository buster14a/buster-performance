typedef unsigned T;
int f(int x)[4] { return (1 + ; }
