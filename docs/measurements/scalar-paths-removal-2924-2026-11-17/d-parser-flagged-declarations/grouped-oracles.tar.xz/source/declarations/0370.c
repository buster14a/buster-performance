typedef unsigned T;
int (f, g)(int (*g)(int)) { return (1 + ; }
