typedef unsigned T;
int f0, (f)(void) { return 1; }
