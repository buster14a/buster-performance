typedef unsigned T;
int ((f))(x) { return 1; }
