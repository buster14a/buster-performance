typedef unsigned T;
int *(f)(const int x[3]);
