typedef unsigned T;
int f0, (f)(int x, char *y) { return 1; }
