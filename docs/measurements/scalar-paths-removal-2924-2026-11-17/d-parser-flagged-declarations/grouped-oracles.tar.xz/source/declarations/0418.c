typedef unsigned T;
int f0, (f)(int (*g)(int)) { return (1 + ; }
