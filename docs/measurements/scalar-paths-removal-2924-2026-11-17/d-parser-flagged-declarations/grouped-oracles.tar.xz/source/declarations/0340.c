typedef unsigned T;
int (f, g)(void) { return (1 + ; }
