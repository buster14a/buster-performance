typedef unsigned T;
typedef int (f)(int x) { return (1 + ; }
