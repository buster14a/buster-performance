typedef unsigned T;
int (f)(void) { return 1; }
