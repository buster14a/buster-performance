typedef unsigned T;
int (f, g)(const int x[3]);
