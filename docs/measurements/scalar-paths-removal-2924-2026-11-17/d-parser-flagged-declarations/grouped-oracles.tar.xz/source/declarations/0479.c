typedef unsigned T;
typedef int (f)(void)(void);
