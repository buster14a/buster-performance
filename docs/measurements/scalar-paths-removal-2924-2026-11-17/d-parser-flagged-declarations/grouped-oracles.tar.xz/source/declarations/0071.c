typedef unsigned T;
int f(x);
