typedef unsigned T;
int (*f(void))(int x,) { return (1 + ; }
