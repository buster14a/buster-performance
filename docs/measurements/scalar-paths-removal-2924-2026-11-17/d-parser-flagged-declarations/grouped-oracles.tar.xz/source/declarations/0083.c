typedef unsigned T;
int f(int (*g)(int));
