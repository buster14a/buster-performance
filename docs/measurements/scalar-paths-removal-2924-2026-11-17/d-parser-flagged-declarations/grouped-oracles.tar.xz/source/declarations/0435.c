typedef unsigned T;
typedef int (f)(void) { return 1; }
