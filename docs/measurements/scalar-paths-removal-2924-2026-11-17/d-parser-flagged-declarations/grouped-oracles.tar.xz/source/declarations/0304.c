typedef unsigned T;
int (f[2])(int x, ...) { return (1 + ; }
