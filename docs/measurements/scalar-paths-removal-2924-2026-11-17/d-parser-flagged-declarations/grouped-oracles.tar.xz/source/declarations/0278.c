typedef unsigned T;
int (*f(void))(const int x[3]);
