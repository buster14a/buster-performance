typedef unsigned T;
typedef int (f)(...) { return 1; }
