typedef unsigned T;
int f0, (f)(x, y);
