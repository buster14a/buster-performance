typedef unsigned T;
int (f, g)(void);
