typedef unsigned T;
int (f, g)(void x) { return 1; }
