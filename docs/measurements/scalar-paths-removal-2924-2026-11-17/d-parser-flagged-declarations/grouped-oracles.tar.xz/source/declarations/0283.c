typedef unsigned T;
int (*f(void))(int x)[4] { return (1 + ; }
