typedef unsigned T;
int (f, g)[4] { return 1; }
