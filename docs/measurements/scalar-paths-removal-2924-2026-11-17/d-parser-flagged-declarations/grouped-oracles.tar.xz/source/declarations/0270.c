typedef unsigned T;
int (*f(void))(void x) { return 1; }
