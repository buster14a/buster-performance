typedef unsigned T;
int (f[2])(int x)[4] { return (1 + ; }
