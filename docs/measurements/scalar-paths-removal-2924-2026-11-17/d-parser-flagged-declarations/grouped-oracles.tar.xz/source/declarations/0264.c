typedef unsigned T;
int (*f(void))(x, y) { return 1; }
