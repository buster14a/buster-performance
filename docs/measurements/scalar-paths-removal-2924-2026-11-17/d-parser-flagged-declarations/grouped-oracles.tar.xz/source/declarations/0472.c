typedef unsigned T;
typedef int (f)[4] { return (1 + ; }
