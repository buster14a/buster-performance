typedef unsigned T;
typedef int (f)(int) { return 1; }
