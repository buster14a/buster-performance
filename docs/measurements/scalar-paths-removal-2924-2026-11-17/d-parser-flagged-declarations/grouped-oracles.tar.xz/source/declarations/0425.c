typedef unsigned T;
int f0, (f)[4];
