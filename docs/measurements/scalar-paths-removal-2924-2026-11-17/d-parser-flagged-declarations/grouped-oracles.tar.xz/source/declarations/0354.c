typedef unsigned T;
int (f, g)(...) { return 1; }
