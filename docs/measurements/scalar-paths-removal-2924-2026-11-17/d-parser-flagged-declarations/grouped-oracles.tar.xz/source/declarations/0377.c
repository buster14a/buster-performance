typedef unsigned T;
int (f, g)[4];
