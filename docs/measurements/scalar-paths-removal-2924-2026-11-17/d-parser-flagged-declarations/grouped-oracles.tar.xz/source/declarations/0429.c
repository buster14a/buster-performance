typedef unsigned T;
int f0, (f)(void)(void) { return 1; }
