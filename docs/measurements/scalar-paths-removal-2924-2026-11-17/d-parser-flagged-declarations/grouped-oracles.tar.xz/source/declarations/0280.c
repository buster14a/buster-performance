typedef unsigned T;
int (*f(void))[4] { return (1 + ; }
