typedef unsigned T;
int (f, g)(int x)[4] { return 1; }
