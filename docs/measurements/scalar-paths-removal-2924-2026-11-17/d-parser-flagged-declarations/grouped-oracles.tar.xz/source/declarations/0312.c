typedef unsigned T;
int (f[2])(x, y) { return 1; }
