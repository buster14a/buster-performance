typedef unsigned T;
int (f, g)(void)(void) { return 1; }
