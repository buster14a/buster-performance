typedef unsigned T;
int (f, g)(int x, char *y);
