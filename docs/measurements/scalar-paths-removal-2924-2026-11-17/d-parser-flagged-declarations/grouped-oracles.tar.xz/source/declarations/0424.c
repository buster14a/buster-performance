typedef unsigned T;
int f0, (f)[4] { return (1 + ; }
