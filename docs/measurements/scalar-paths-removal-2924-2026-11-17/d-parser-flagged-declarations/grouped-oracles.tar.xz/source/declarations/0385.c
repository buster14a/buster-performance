typedef unsigned T;
int f0, (f)() { return (1 + ; }
