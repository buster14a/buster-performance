typedef unsigned T;
int (f, g)(const int x[3]) { return 1; }
