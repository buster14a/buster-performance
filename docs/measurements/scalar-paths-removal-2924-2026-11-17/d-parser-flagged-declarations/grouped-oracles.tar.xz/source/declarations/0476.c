typedef unsigned T;
typedef int (f)(int x)[4];
