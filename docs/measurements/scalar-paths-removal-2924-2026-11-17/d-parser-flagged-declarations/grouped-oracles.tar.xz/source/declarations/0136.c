typedef unsigned T;
int ((f))[4] { return (1 + ; }
