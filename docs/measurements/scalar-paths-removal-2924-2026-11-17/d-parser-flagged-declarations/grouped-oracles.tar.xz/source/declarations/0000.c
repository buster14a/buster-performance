typedef unsigned T;
int (f)() { return 1; }
