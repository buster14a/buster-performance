typedef unsigned T;
int (f, g)(int x,) { return (1 + ; }
