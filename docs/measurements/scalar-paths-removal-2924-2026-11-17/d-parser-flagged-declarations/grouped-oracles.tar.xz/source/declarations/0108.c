typedef unsigned T;
int ((f))(int x, char *y) { return 1; }
