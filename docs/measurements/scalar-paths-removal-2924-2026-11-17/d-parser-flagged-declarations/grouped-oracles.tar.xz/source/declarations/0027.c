typedef unsigned T;
int (f)(int x,) { return 1; }
