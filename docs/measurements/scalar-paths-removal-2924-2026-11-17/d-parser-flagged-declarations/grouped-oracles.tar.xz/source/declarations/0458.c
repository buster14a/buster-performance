typedef unsigned T;
typedef int (f)(x, y);
