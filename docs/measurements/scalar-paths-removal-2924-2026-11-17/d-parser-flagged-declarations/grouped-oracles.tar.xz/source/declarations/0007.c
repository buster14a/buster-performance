typedef unsigned T;
int (f)(int) { return (1 + ; }
