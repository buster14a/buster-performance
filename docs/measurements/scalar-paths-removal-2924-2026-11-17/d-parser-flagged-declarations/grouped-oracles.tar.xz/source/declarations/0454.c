typedef unsigned T;
typedef int (f)(x) { return (1 + ; }
