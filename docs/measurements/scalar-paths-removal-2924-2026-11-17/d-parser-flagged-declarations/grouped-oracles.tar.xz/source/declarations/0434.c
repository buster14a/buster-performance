typedef unsigned T;
typedef int (f)();
