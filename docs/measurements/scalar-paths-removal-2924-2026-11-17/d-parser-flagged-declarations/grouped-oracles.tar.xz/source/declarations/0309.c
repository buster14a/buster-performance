typedef unsigned T;
int (f[2])(x) { return 1; }
