typedef unsigned T;
int (*f(void))[4];
