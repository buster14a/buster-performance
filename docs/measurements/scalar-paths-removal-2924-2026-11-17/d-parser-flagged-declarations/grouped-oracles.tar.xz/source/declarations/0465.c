typedef unsigned T;
typedef int (f)(int (*g)(int)) { return 1; }
