typedef unsigned T;
int (f[2])(const int x[3]) { return (1 + ; }
