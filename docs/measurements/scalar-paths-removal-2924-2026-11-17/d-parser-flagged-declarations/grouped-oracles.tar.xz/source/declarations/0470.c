typedef unsigned T;
typedef int (f)(const int x[3]);
