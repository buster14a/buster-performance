typedef unsigned T;
int (f[2])(void)(void) { return 1; }
