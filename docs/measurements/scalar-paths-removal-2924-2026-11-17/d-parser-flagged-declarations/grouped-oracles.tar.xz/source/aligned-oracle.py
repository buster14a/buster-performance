from pathlib import Path
p=Path(__file__).parent
s=(p/'tree/src/buster/compiler/c_parser_test.c').read_text()
a=s.index('typedef struct ParseTestSnippet ParseTestSnippet;');b=s.index('\n};',s.index('static const ParseTestSnippet parse_test_snippets[]',a))+3
s='#include <stdio.h>\n#include <stdbool.h>\n'+s[a:b]+'''
int main(void)
{
 for(unsigned i=0;i<sizeof(parse_test_snippets)/sizeof(*parse_test_snippets);++i)
 {
  char name[160];snprintf(name,sizeof(name),"alignment-cases/%04u.txt",i);
  FILE* f=fopen(name,"w");if (!f||fputs(parse_test_snippets[i].source,f)<0||fclose(f))return 1;
 }
 return 0;
}
'''
(p/'alignment-cases').mkdir(exist_ok=True);(p/'aligned-snippets.c').write_text(s)
