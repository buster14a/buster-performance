from pathlib import Path
import subprocess,os,sys,hashlib
p=Path(__file__).parent
d=p/('aligned-'+sys.argv[1]);d.mkdir(exist_ok=True);tag=sys.argv[1];out=p/(tag+'-aligned-results.tsv')
rows=[]
for case in sorted((p/'alignment-cases').glob('*.txt')):
 src=case.read_bytes();files=[]
 for i in range(64):
  q=d/(str(i)+'.c');q.write_bytes(b'; '*i+src);files.append(q)
 tree=d/'trees.bin';tree.write_bytes(b'')
 res=subprocess.run([str(p/(tag+'-columns')),'-std=gnu17','-nostdinc',*map(str,files)],env={**os.environ,'BUSTER_DECL_TREE':str(tree)},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if res.returncode:raise RuntimeError((case, res.stderr[-350:]))
 stats=[line.split(b'\t')[2:] for line in res.stdout.splitlines() if line.startswith(b'unit\t')]
 assert len(stats)==64
 rows.append('\t'.join([case.stem,hashlib.sha256(tree.read_bytes()).hexdigest(),str(tree.stat().st_size),*(str(sum(int(item[k]) for item in stats))for k in range(6))]))
 out.write_text('\n'.join(rows)+'\n')
