#include <stdio.h>
#include <stdbool.h>
typedef struct ParseTestSnippet ParseTestSnippet;
struct ParseTestSnippet
{
    const char* source;
    const char* error;
    const char* std;
    bool semantic;
};

static const ParseTestSnippet parse_test_snippets[] =
{
    // Valid code.
    { "int x;\nint f(int a, int b) { return a + b * 2; }\n", "", 0 },
    // Empty array bounds close with `]`; qualifiers and unspecified-size parameters keep that allowance (#1253).
    { "extern int a[]; void f(int a[], int b[const], int c[*], int d[static 3]);\n", "", 0 },
    { "void f(int [], int [const], int [*]);\n", "", 0 },
    // Before any bound, a wrong closer or a semicolon is a missing expression, not a missing `]`.
    { "int a[);\n", "1:7: expected expression", 0 },
    { "int a[;\n", "1:7: expected expression", 0 },
    { "int a[};\n", "1:7: expected expression", 0 },
    { "void f(int a[);\n", "1:14: expected expression", 0 },
    { "void f(const x [);\n", "1:17: expected expression", 0 },
    { "void f(int a[const);\n", "1:19: expected expression", 0 },
    { "void f(int a[const;\n", "1:19: expected expression", 0 },
    { "void f(int a[const};\n", "1:19: expected expression", 0 },
    { "void f(int a[static );\n", "1:21: expected expression", 0 },
    { "void f(int a[static ;\n", "1:21: expected expression", 0 },
    // Starting an expression still requires its operand, even at the matching bracket.
    { "void f(int a[+]);\n", "1:15: expected expression", 0 },
    { "void f(int a[*);\n", "1:15: expected expression", 0 },
    // After a bound the missing bracket is still the error; a subscript never admits an empty expression.
    { "int a[3;\n", "1:8: expected ']'", 0 },
    { "int a[static 3);\n", "1:15: expected ']'", 0 },
    { "void f(int a[3);\n", "1:15: expected ']'", 0 },
    { "int g(int *p) { return p[); }\n", "1:26: expected expression", 0 },
    { "int g(int *p) { return p[]; }\n", "1:26: expected expression", 0 },
    // Other empty expression contexts are unchanged.
    { "void f(void); void g(void) { f(); for (;;) { return; } }\n", "", 0 },
    { "struct S { int a : 3; char *p; } s = { 1, \"x\" };\n", "", 0 },
    { "int x; void g(void) { if (x) x = 1; else { for (int i = 0; i < 3; i++) x += i; } do x--; while (x); switch (x) { case 1: break; default: ; } }\n", "", 0 },
    { "typedef int T; T (x); int f(T (x)); int g(int (x));\n", "", 0 },
    { "typedef int T; void f(void) { int T; T = 1; }\n", "", 0 },
    { "struct S { int x }; struct S2 { int x; int y };\n", "", 0 },
    { "void f(void) { L: }\n", "", 0 },
    { "void f(void) { a: int x; }\n", "", 0 },
    { "[[deprecated]] int x; int y [[maybe_unused]];\n", "", 0 },
    // C23 attributes alone at a block item are a statement's where the token after them starts no declaration, as clang's
    // isDeclarationStatement decides (#147); after GNU ones clang reads no more of them, and before a block's end it expects
    // the statement.
    { "void f(int x) { [[x]] x += 1; [[gnu::y]] f(x); if (x) [[z]] x = 2; [[w]]; [[v]] (void)x; [[u]] *&x = 3; [[t]] asm(\"\"); [[s]] [[r]] x++; }\n", "", 0 },
    { "typedef int T; void f(void) { [[x]] T y = 1; [[x]] const int z = 2; [[x]] __extension__ z; [[x]] return; }\n", "", 0 },
    { "void f(int x) { l: __attribute__((unused)) [[y]] x++; }\n", "", 0 },
    { "void f(int x) { [[x]] }\n", "1:23: expected statement", 0 },
    { "void f(int x) { if (x) [[y]] }\n", "1:30: expected statement", 0 },
    { "void f(int x) { l: [[y]] }\n", "1:26: expected statement", 0 },
    { "void f(int x) { { [[x]] } x++; }\n", "1:25: expected statement", 0 },
    { "void f(int x) { __attribute__((nomerge)) [[y]] x++; }\n", "1:42: expected expression", 0 },
    { "void f(int x) { __attribute__((nomerge)) [[y]] return; }\n", "1:42: expected expression", 0 },
    { "void f(int x) { __attribute__((aligned(4))) [[y]] int z; }\n", "1:45: an attribute list cannot appear here", 0 },
    { "void f(int x) { if (x) __attribute__((aligned(4))) [[y]] x++; }\n", "1:52: expected expression", 0 },
    { "void f(int x) { switch (x) { case 1: __attribute__((nomerge)) [[y]] x++; } }\n", "1:63: expected expression", 0 },
    // With GNU attributes, every attribute of the prefix, C23's too, must be a statement's for a statement (clang's
    // isStmtAttr), whatever the token after them; and specifiers of attributes alone have no type: an implicit int, but
    // a member's error after C23 ones, which clang's specifiers don't hold.
    { "void f(int x) { [[y]] __attribute__((nomerge)) zz++; }\n", "1:48: unknown type name 'zz'", 0, true },
    { "void f(int x) { [[clang::noinline, y]] __attribute__((noinline)) zz++; }\n", "1:66: unknown type name 'zz'", 0, true },
    { "void f(int x) { [[clang::nomerge]] __attribute__(()) x++; [[clang::likely]] __attribute__((nomerge)) x++; [[msvc::noinline, gnu::noinline]] __attribute__((noinline)) x++; }\n", "", 0 },
    { "void f(int x) { [[__gnu__::__noinline__, _Clang::nomerge]] __attribute__((nomerge)) x++; }\n", "", 0 },
    { "struct S { __attribute__((aligned(4))) *p; };\n", "1:41: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "struct S { int a; [[deprecated]] *p; };\n", "1:34: type name requires a specifier or qualifier", 0 },
    { "[[deprecated]] *p;\n", "1:17: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "void f(void) { __attribute__(()) __attribute__(()) *p; }\n", "1:53: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    // A block item's GNU attributes before a name of no type (#147): clang asks what the name is first (TryAnnotateName),
    // and a declared object's, function's, enumerator's or parameter's, or one it declares implicitly before a `(`, starts
    // no declarator, in any standard; an undeclared name is an implicit int's declarator. After a control statement's
    // head, a label's name or `__extension__`, and in a for's first clause, they are no declaration's.
    { "int x; void f(void) { __attribute__(()) x = 1; }\n", "1:41: expected identifier or '('", 0 },
    { "int x; void f(void) { __attribute__((unused)) __attribute__(()) x; }\n", "1:65: expected identifier or '('", 0 },
    { "void g(void); enum { E }; void f(int p) { __attribute__(()) g(); }\n", "1:61: expected identifier or '('", 0 },
    { "enum { E }; void f(void) { __attribute__(()) E; }\n", "1:46: expected identifier or '('", 0 },
    { "void f(int p) { __attribute__(()) p = 1; }\n", "1:35: expected identifier or '('", 0 },
    { "void f(void) { __attribute__(()) f; }\n", "1:34: expected identifier or '('", 0 },
    { "void f(void) { int x; { __attribute__((aligned(4))) x[1]; } }\n", "1:53: expected identifier or '('", 0 },
    { "int x; void f(void) { switch (1) { case 1: __attribute__(()) x = 1; } }\n", "1:62: expected identifier or '('", 0 },
    { "int x; void f(void) { ({ __attribute__(()) x = 1; }); }\n", "1:44: expected identifier or '('", 0 },
    { "int x; void f(void) { __attribute__(()) x = 1; }\n", "1:41: expected identifier or '('", "c89" },
    { "int x; void f(void) { __attribute__(()) x = 1; }\n", "1:41: expected identifier or '('", "c23" },
    { "void f(void) { __attribute__(()) foo(); }\n", "1:34: expected identifier or '('", "c89" },
    { "int f(a) int a; { __attribute__(()) a = 1; return a; }\n", "1:37: expected identifier or '('", 0 },
    { "int x, y; void g(void) { int z = 2; z = 3; } void f(void) { __attribute__(()) x = 1; }\n", "1:79: expected identifier or '('", "c89" },
    { "void f(void) { __attribute__(()) y = 1; y = 2; }\n", "", "c89" },
    { "void g(void) { int z = 2; z = 3; } void f(void) { __attribute__(()) w = 1; w = 2; } int w;\n", "", "c89" },
    { "void f(void) { int x = sizeof(struct { int x; }); __attribute__(()) x = 1; }\n", "1:69: expected identifier or '('", 0 },
    { "void f(void) { { int x; } __attribute__(()) x = 1; }\n", "1:45: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "void f(void) { for (int x = 0;;) { } __attribute__(()) x; }\n", "1:56: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "int x; void f(void) { int x; { typedef int x; __attribute__(()) x y; } }\n", "", 0 },
    { "int x; void f(void) { if (1) __attribute__(()) x = 1; L: __attribute__(()) x = 1; __attribute__(()) x: ; }\n", "", 0 },
    { "int x; void f(void) { __extension__ __attribute__(()) x = 1; }\n", "1:55: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "int x; void f(void) { for (__attribute__(()) x = 1;;) ; }\n", "1:46: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "int x; void f(void) { __attribute__(()) static x = 1; __attribute__(()) *x; }\n", "1:48: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    // A name of no ordinary binding that a tag in scope has, clang's Sema's error first (isTagTypeWithMissingTag), the tag
    // in scope as its scope keeps it (the parser's ParseScalar.tags): an ordinary binding first, a tag of a block that
    // ended none, and a file-scope tag before the fallback's declaration through the whole unit. Before C23 a `(` makes
    // the name an implicit function's; C23 has none.
    { "struct x { int v; }; void f(void) { __attribute__(()) x = 1; }\n", "1:55: must use 'struct' tag to refer to type 'x'", "gnu89", true },
    { "struct x { int v; }; void f(void) { __attribute__((unused)) x; }\n", "1:61: must use 'struct' tag to refer to type 'x'", 0, true },
    { "union u { int v; }; void f(void) { __attribute__(()) u; }\n", "1:54: must use 'union' tag to refer to type 'u'", "c89", true },
    { "enum e { A }; void f(void) { __attribute__(()) e = 1; }\n", "1:48: must use 'enum' tag to refer to type 'e'", "gnu89", true },
    { "struct x; void f(void) { { __attribute__(()) x = 1; } }\n", "1:46: must use 'struct' tag to refer to type 'x'", "gnu89", true },
    { "void g(void) { struct x { int v; }; } void f(void) { __attribute__(()) x = 1; x = 2; }\n", "", "gnu89" },
    { "struct x { int v; }; void f(void) { int x; __attribute__(()) x = 1; }\n", "1:62: expected identifier or '('", "gnu89" },
    { "int y; void g(void) { y = 1; } struct x { int v; }; void h(void) { y = 2; } void f(void) { __attribute__(()) x = 1; }\n",
      "1:110: must use 'struct' tag to refer to type 'x'", "gnu89", true },
    { "struct x { int v; }; void f(void) { __attribute__(()) x(1); }\n", "1:55: must use 'struct' tag to refer to type 'x'", "c23", true },
    // A tag a definition's parameter list declares is in scope in its body (C17 6.2.1p4; #1556's review), a block in it
    // too, behind a parameter of its name none; a prototype's (a declaration's, or a parameter's in the list) ends with
    // its list, a K&R definition's declarations' with them (clang's), and the body's with the body.
    { "void f(struct S *p) { __attribute__(()) S = 1; }\n", "1:41: must use 'struct' tag to refer to type 'S'", "gnu89", true },
    { "void f(struct S { int a; } p) { { __attribute__(()) S = 1; } }\n", "1:53: must use 'struct' tag to refer to type 'S'", 0, true },
    { "void f(union U *p) { __attribute__(()) U; }\n", "1:40: must use 'union' tag to refer to type 'U'", "c89", true },
    { "void f(enum E { A } e) { __attribute__(()) E = 1; }\n", "1:44: must use 'enum' tag to refer to type 'E'", "gnu89", true },
    { "void f(struct S *S) { __attribute__(()) S = 1; }\n", "1:41: expected identifier or '('", "gnu89" },
    { "int f(a) struct S *a; { __attribute__(()) S = 1; return 0; }\n", "", "c89" },
    { "void g(struct S *p); void f(void) { __attribute__(()) S = 1; }\n", "", "c89" },
    { "int f(void (*q)(struct S *r)) { __attribute__(()) S = 1; return 0; }\n", "", "c89" },
    { "void f(struct S *p) { } void g(void) { __attribute__(()) S = 1; }\n", "", "c89" },
    { "void f(void) { __attribute__(()) x(1); }\n", "1:36: expected parameter declarator", "c23" },
    { "void f(__attribute__((aligned(8))) *p);\n", "1:37: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "enum E : int { A }; enum F : unsigned char;\n", "", 0 },
    // A typedef's first declarator after an enum's underlying type and body is a type name (K3 skips the base).
    { "typedef int U; typedef enum E : unsigned short { A } T; typedef enum : const U { B } V, W; int n = sizeof(T) + sizeof(V) + sizeof(W);\n", "", 0 },
    // GNU attributes among an enum's base's specifiers, which clang takes as the base type's (#428's review): before,
    // between and after them, with a body or without, and where a typedef's declarator follows the body (K3 skips them).
    { "enum E : int __attribute__((unused)); enum F : int __attribute__((unused)) { A };\n", "", 0 },
    { "enum G : __attribute__((unused)) unsigned __attribute__((unused)) char __attribute__((unused)) { B };\n", "", 0 },
    { "typedef enum H : int __attribute__((unused)) { C } T; T t = C; int n = sizeof(T);\n", "", 0 },
    { "int x = (int){1}; int a[3] = { [1 ... 2] = 0 };\n", "", 0 },
    // GNU's single array designator may omit '=', including a range, a prefix operand and a braced initializer.
    { "int a[] = { [0] 1, [3] 4, [4] -1, [5] (int)2 };\n", "", 0 },
    { "int a[2] = { [0 ... 1] +1 }; int b[1][2] = { [0] { 1, 2 } };\n", "", "c17" },
    // GNU's old-style field designator uses ':' in place of '.member =', including a typedef-shadowing member.
    { "struct p { int x, y; }; struct p q = { y: 2, x: 1 };\n", "", 0 },
    { "typedef int T; struct p { int T, x; }; struct p q = { T: 1, x: 2 };\n", "", "c17" },
    { "void f(int x) { asm volatile (\"\" : [r] \"=r\" (x) : \"r\" (x) : \"memory\"); }\n", "", 0 },
    { "int f(a, b) int a; char b; { return a + b; }\n", "", 0 },
    { "int x = 1 ? : 2;\n", "", 0 },
    { "void f(int a, int b) { a = a ? b, a : b; for (b = a ? 1, 2 : 3; b; ) b--; }\n", "", 0 },
    { "int f(void) { return ({ int y = 1; y; }); }\n", "", 0 },
    { "void f(void) { __label__ a, b; a: b: ; }\n", "", 0 },
    { "_Static_assert(1, \"x\"); _Static_assert(1); struct S { _Static_assert(1, \"y\"); int x; };\n", "", 0 },
    { "int x = sizeof(int) + _Alignof(int) + __builtin_offsetof(struct { int a; }, a);\n", "", 0 },
    { "int x = _Generic(1, int: 2, default: 3);\n", "", 0 },
    { "static_assert(1); auto x = 1; constexpr int y = 2; bool b = true; void *p = nullptr;\n", "", "c23" },
    // An unnamed bit-field starts with ':', including after a comma on the preceding line.
    { "struct S { unsigned char :1,\n :1,x:1,y:5; };\n", "", 0 },
    { "struct S { unsigned x:1,\n :1,y:1; };\n", "", 0 },
    { "union U { unsigned x,\n :3; };\n", "", 0 },
    { "typedef unsigned T; struct S { T :2,\n :3,x:1; };\n", "", 0 },
    { "struct S { unsigned :1,\n :1 ? 2 : 3,x:4; };\n", "", 0 },
    // GNU's reserved spellings remain keywords in strict C; plain asm and (before C23) typeof do not.
    { "__extension__ typedef __signed__ __int128 Wide;\n__inline __const int *aliases(__const__ int *__restrict p, __volatile__ int *__restrict__ q) { return p; }\n__inline__ int widths(void) { return __alignof__(Wide) + __alignof(__signed int); }\n", "", "c17" },
    { "int asm, typeof; int f(void) { asm = typeof + 1; return asm; }\n", "", "c17" },
    { "int x; __typeof(x) y; __typeof__(const int) z; __typeof__(int (*)(int)) fp;\nint f(void) { __typeof__(&x) p = &x; __typeof__(*p) value = *p; return value; }\n", "", "c17" },
    { "int a[3]; typeof(a) b; typeof(int (*)(int)) f;\nint g(int x) { typeof((x + 1)) y = x; return y; }\n", "", 0 },
    { "const int x = 1; typeof(x) y = 2; typeof_unqual(x) z;\nint f(void) { typeof(int) n = 3; return n + y; }\n", "", "c23" },
    // A typeof operand follows the visible binding; nested statement expressions and __extension__ keep their scope.
    { "typedef int T; int f(void) { int T = 3; __typeof__(T) x = T; { typedef char T; __typeof__(T) y = 1; x += y; } return x; }\n", "", 0 },
    { "int f(int x) { __auto_type y = ({ __auto_type z = x + 1; z; }); return ({ __typeof__(y) z = y; z + 1; }); }\n", "", 0 },
    { "__extension__ typedef __int128 Wide;\nint f(int x) { __extension__ Wide y = x; return __extension__ ({ int z = (int)y; __extension__ (z ?: 1); }); }\n", "", "c17" },
    { "const char *f(void) { const char *names[] = { __func__, __FUNCTION__, __PRETTY_FUNCTION__ }; return names[0]; }\n", "", "c17" },
    { "struct S { int empty[0]; int value; }; int a[4] = { [0 ... 3] = 2 };\nint f(int x) { switch (x) { case -2 ... 2: return a[x + 2]; default: return x ?: 4; } }\n", "", 0 },
    { "__typeof__ int x;\n", "1:12: expected '(' after '__typeof__'", 0 },
    { "__typeof__() x;\n", "1:12: expected expression", 0 },
    { "__typeof__(int, char) x;\n", "1:15: expected ')'", 0 },
    { "__typeof__(int x;\n", "1:16: expected ')'", 0 },
    { "__typeof__(({ int x = 1; x; })) y;\n", "1:12: statement expression not allowed at file scope", 0 },
    // Invalid code, with clang 23's first error.
    { "struct S { unsigned :1,\n :; };\n", "2:3: expected expression", 0 },
    { "int x,\n:1;\n", "1:6: expected ';' at end of declaration", 0 },
    { "struct S {\n  int x;\n  int broken =\n};\n", "3:13: expected ';' at end of declaration list", 0 },
    { "struct T { int member = 1; };\n", "1:22: expected ';' at end of declaration list", 0 },
    { "union U { int (*callback)(void) = 0; };\n", "1:32: expected ';' at end of declaration list", 0 },
    { "struct V { int x:3 = 1; };\n", "1:19: expected ';' at end of declaration list", 0 },
    // GNU attributes after a bit-field's width end it: the member's, more of them, then `,` or `;`, or the body's `}` after
    // the last member (clang's warning). Anything else is a missing `;`, at the token for a `:` (clang's typo for one).
    { "enum { N = 3 }; struct S { int a : 3 __attribute__((aligned(4))), b : N __attribute__((packed)) __attribute__(()); long : 0 __attribute__((aligned(8)));"
      " char c : (1 + 2) __attribute__((unused)) };\n", "", 0 },
    { "struct S { int x : 3 __attribute__((packed)) + 1; };\n", "1:45: expected ';' at end of declaration list", 0 },
    { "struct S { int x : 3 __attribute__((packed)) : 4; };\n", "1:46: expected ';' at end of declaration list", 0 },
    // clang's attributes of a type argument read it as a type name (#147, parse_scalar_type_argument_attribute), by their
    // names in any syntax, unknown ones' too; another attribute's is an expression.
    { "typedef int T; enum E { A }; struct S { unsigned a : 2 __attribute__((preferred_type(int), packed)), b : 1 __attribute__((__preferred_type__(T))); "
      "unsigned c : 2 __attribute__((preferred_type(const enum E *[2]))); }; void f(void) __attribute__((Owner(int (*)(void)), "
      "iboutletcollection(typeof(1.0)), vec_type_hint(struct { int x; } *)));\n", "", 0, true },
    { "struct S { unsigned a : 2 __attribute__((preferred_type(int, int))); };\n", "1:60: expected ')'", 0 },
    { "void f(void) __attribute__((vec_type_hint(int x)));\n", "1:47: expected ')'", 0 },
    { "int x __attribute__((aligned(int)));\n", "1:30: expected expression", 0 },
    { "void f(void) __attribute__((zzz(int)));\n", "1:33: expected expression", 0 },
    // An asm statement's GNU attributes, which clang prohibits there (#147), but a label's.
    { "void f(void) { __attribute__((nomerge)) asm(\"\"); }\n", "1:16: an attribute list cannot appear here", 0 },
    { "void f(void) { L: __attribute__((unused)) asm(\"\"); }\n", "", 0 },
    { "void f(int x) { if (x) __attribute__((cold)) __attribute__((nomerge)) asm(\"\"); }\n", "1:24: an attribute list cannot appear here", 0 },
    { "struct S { int x : 3 __attribute__((packed)) [4]; };\n", "1:45: expected ';' at end of declaration list", 0 },
    { "int x y;\n", "1:6: expected ';' after top level declarator", 0 },
    { "void f(int a) { a + ; }\n", "1:21: expected expression", 0 },
    { "int f(void) { return 1 }\n", "1:23: expected ';' after return statement", 0 },
    { "int f(void) { int x = 1\nreturn x; }\n", "1:24: expected ';' at end of declaration", 0 },
    { "int a[3 4];\n", "1:9: expected ']'", 0 },
    // A parameter list whose first parameter starts with an attribute: the parser marks it a function's, in a definition
    // and in a prototype (#1968).
    { "int h(__attribute__((aligned(8))) int q) { int x; return q; }\n", "", 0 },
    // A block right after a case label, a default label and a label, whose `{` K2's rounds read as after a ternary's
    // middle and K1's second part makes a block's (#2924: no snippet had one, and a mutant that skipped the first lane of
    // every block but the first passed every test).
    { "int f(int x) { switch (x) { case 1: { x = 2; } default: { x = 3; } } l: { x = 4; } return x; }\n", "", 0 },
    { "int p(__attribute__((unused)) int, __attribute__((unused)) char *);\nint (*fp)(__attribute__((unused)) int);\n", "", 0 },
    { "int k([[maybe_unused]] int q);\nint m([[maybe_unused]] int q, __attribute__((unused)) int r) { return q + r; }\n", "", "c23" },
    // A comma at the top of an array declarator's size or an array designator's index (#1867); one in parentheses or a
    // call's arguments, or in a subscript, is an operator's.
    { "void f(int n, int m) { int u[n, m]; }\n", "1:31: expected ']'", 0 },
    { "int w[1, 2];\n", "1:8: expected ']'", 0 },
    { "struct S { int m[1, 2]; };\n", "1:19: expected ']'", 0 },
    { "void g(int n, int p[n, 2]);\n", "1:22: expected ']'", 0 },
    { "int c = sizeof(int[1, 2]);\n", "1:21: expected ']'", 0 },
    { "typedef int T[2, 3];\n", "1:16: expected ']'", 0 },
    { "int d[3] = { [1, 2] = 3 };\n", "1:16: expected ']'", 0 },
    { "void f(void) { int e[2] = { [0, 1] 2 }; }\n", "1:31: expected ']'", 0 },
    { "int z[1, 2;\n", "1:8: expected ']'", 0 },
    { "int f(int, int); void h(void) { int a[(1, 2)]; int b[f(1, 2)]; int d[3] = { [(1, 2)] = 3 }; }\n", "", 0 },
    { "int q[2]; void f(int *p, int i) { p[i, 0] = p[0, i]; int d[3] = { [sizeof q[1, 0] - 2] = 3 }; }\n", "", 0 },
    { "struct { x; } s;\n", "1:10: type name requires a specifier or qualifier", 0 },
    { "void f(void) { if (1) }\n", "1:23: expected statement", 0 },
    { "enum E { A B };\n", "1:11: missing ',' between enumerators", 0 },
    { "enum E { A = 1 2 };\n", "1:16: expected '}' or ','", 0 },
    { "enum E {};\n", "1:9: use of empty enum", 0 },
    { "enum E { 5 };\n", "1:10: expected identifier", 0 },
    { "int f(int a) { return (a; }\n", "1:25: expected ')'", 0 },
    { "void f(int a) { f(a)); }\n", "1:21: extraneous ')' before ';'", 0 },
    { "void f(int a) { a ]; }\n", "1:19: extraneous ']' before ';'", 0 },
    { "struct S { int a; } int y;\n", "1:20: expected ';' after struct", 0 },
    { "struct S { union { int a; }\n};\n", "2:1: expected member name or ';' after declaration specifiers", 0 },
    { "struct T { int a; } }\n", "1:21: expected identifier or '('", 0 },
    { "int ();\n", "1:6: expected identifier or '('", 0 },
    { "int (*);\n", "1:7: expected identifier or '('", 0 },
    { "int *;\n", "1:6: expected identifier or '('", 0 },
    { "int a = 1, ;\n", "1:12: expected identifier or '('", 0 },
    { "void f(void) { int (*)(void); }\n", "1:22: expected identifier or '('", 0 },
    { "5;\n", "1:1: expected identifier or '('", 0 },
    { "}\n", "1:1: extraneous closing brace ('}')", 0 },
    { "int f(int x int y);\n", "1:13: expected ')'", 0 },
    { "int f(int, ..., int);\n", "1:15: expected ')'", 0 },
    { "int a = ;\n", "1:9: expected expression", 0 },
    { "void f(void) { if (1) else; }\n", "1:23: expected expression", 0 },
    { "void f(void) { else ; }\n", "1:16: expected expression", 0 },
    { "void f(void) { for (;) ; }\n", "1:22: expected ';' in 'for' statement specifier", 0 },
    { "void f(void) { for (;;;) ; }\n", "1:23: expected expression", 0 },
    { "void f(void) { goto 5; }\n", "1:21: expected identifier", 0 },
    { "void f(void) { while(1) break 5; }\n", "1:30: expected ';' after break statement", 0 },
    { "void f(void) { while(1) continue x; }\n", "1:34: named 'continue' is only supported in C2y", 0 },
    { "void f(void) { int x; x = (int); }\n", "1:32: expected expression", 0 },
    { "void f(void) { int x; x.; }\n", "1:25: expected identifier", 0 },
    { "void f(int a) { a ? 1; }\n", "1:22: expected ':'", 0 },
    { "void f(void) { f(,); }\n", "1:18: expected expression", 0 },
    { "void f(void) { f(1,); }\n", "1:20: expected expression", 0 },
    { "void f(void) { do ; }\n", "1:21: expected 'while' in do/while loop", 0 },
    { "void f(void) { do ; while (1) }\n", "1:30: expected ';' after do/while statement", 0 },
    { "int (*p)(int;\n", "1:13: expected ')'", 0 },
    // A declarator's group holds one declarator.
    { "int (*f, g);\n", "1:8: expected ')'", 0 },
    { "struct S { int (*f, g); };\n", "1:19: expected ')'", 0 },
    { "void m(void (*f (void *), int a));\n", "1:25: expected ')'", 0 },
    { "int x = sizeof int;\n", "1:15: expected parentheses around type name in sizeof expression", 0 },
    { "void f(void) { if (1) int y; }\n", "1:23: expected expression", 0 },
    { "void f(void) { int g(void) { return 1; } }\n", "1:28: function definition is not allowed here", 0 },
    { "struct S { + };\n", "1:12: type name requires a specifier or qualifier", 0 },
    { "int x = (int y)1;\n", "1:14: expected ')'", 0 },
    { "int x = sizeof(int y);\n", "1:20: expected ')'", 0 },
    { "void f(void) { if 1; }\n", "1:19: expected '(' after 'if'", 0 },
    { "void f(void) { while }\n", "1:22: expected '(' after 'while'", 0 },
    { "struct;\n", "1:1: declaration of anonymous struct must be a definition", 0 },
    { "void f(void) { asm(\"nop\") x; }\n", "1:26: expected ';' after asm statement", 0 },
    { "asm(\"nop\") x;\n", "1:11: expected ';' after top-level asm block", 0 },
    { "_Static_assert(1, \"x\") int y;\n", "1:23: expected ';' after '_Static_assert'", 0 },
    { "void f(void) { goto x y; }\n", "1:22: expected ';' after goto statement", 0 },
    // A computed goto's `*` takes the whole expression after it, as clang's ParseGotoStatement does: a conditional, a
    // sum, a comma, an assignment, a `*` of its own and a group; and an operand must follow it.
    { "void f(int n) { void *p = &&a; goto *p ? &&a : &&b; goto *p + 0; goto *n, p; goto *p = p; goto **(void **)&p; goto *(p); a: b:; }\n", "", 0 },
    { "void f(void) { goto *; }\n", "1:22: expected expression", 0 },
    { "void f(void *p) { goto * const p; }\n", "1:26: expected expression", 0 },
    { "void f(void *p) { goto *p + ; }\n", "1:29: expected expression", 0 },
    // Any other operator after goto is an error: the vector path gives it the `*`'s role, and its checks send it to the
    // scalar parser.
    { "void f(int x) { goto &x; }\n", "1:22: expected identifier", 0 },
    { "void f(void) { a: goto &&a; }\n", "1:24: expected identifier", 0 },
    { "int x = __builtin_offsetof(int y, z);\n", "1:31: expected ','", 0 },
    { "void f(void) { switch(1) { default 1; } }\n", "1:35: expected ':' after 'default'", 0 },
    { "int x = _Generic(1, int 1);\n", "1:24: expected ':'", 0 },
    { "int x = (1 ? 2 : );\n", "1:18: expected expression", 0 },
    { "enum E { A = 1 = 2 };\n", "1:16: expected '}' or ','", 0 },
    { "void f(int a) { switch (a) { case 1 = 2: ; } }\n", "1:36: expected ':' after 'case'", 0 },
    { "void f(int a) { switch (a) { case 1, 2: ; } }\n", "1:36: expected ':' after 'case'", 0 },
    { "struct S { int a : 1 = 2; };\n", "1:21: expected ';' at end of declaration list", 0 },
    { "_Static_assert(1 = 2, \"x\");\n", "1:17: expected ','", 0 },
    { "void f(int a) { a ... 2; }\n", "1:18: expected ';' after expression", 0 },
    { "void f(int x) { asm (\"\" : \"=r\" [r] (x)); }\n", "1:32: expected '(' after 'asm operand'", 0 },
    { "int x = ({ 1; 2; });\n", "1:9: statement expression not allowed at file scope", 0 },
    { "void f(void) { int x; __label__ a; }\n", "1:23: expected expression", 0 },
    { "void f(void) { return }\n", "1:23: expected expression", 0 },
    { "void f(void) { int x }\n", "1:21: expected ';' at end of declaration", 0 },
    { "void f(int x) { x = 1 }\n", "1:22: expected ';' after expression", 0 },
    { "int x = { 1, 2 } }\n", "1:17: expected ';' after top level declarator", 0 },
    { "struct {;\n\n\n", "3:1: expected '}'", 0 },
    { "void f(void) {\n  int x;\n\n", "3:1: expected '}'", 0 },
    { "int x\n\n", "1:6: expected ';' after top level declarator", 0 },
    { "int x = (1 +\n\n", "2:1: expected expression", 0 },
    // sizeof of a compound literal, whose parentheses aren't sizeof's.
    { "int x = sizeof (int){1};\nint y = sizeof (int[]){1,2,3};\nint z = sizeof (int[]){1,2}[0];\n", "", 0 },
    // A declarator's name is in scope once its declarator is complete: the inner T's array size still sees the typedef,
    // its initializer and later declarators the object.
    { "typedef int T; void f(void) { int T[sizeof((T)0)]; }\n", "", 0 },
    { "typedef int T; void m(void) { int T = (T)1; }\n", "1:42: expected ';' at end of declaration", 0 },
    { "typedef int T; void k(int T, int u[sizeof(T)]);\n", "", 0 },
    // A definition's parameters stay in scope through the rest of its declarator and attributes, into its body, and
    // only there: after the body, the typedef is back.
    { "typedef int T;\nint (*h(int T))(int) { (void)T; return 0; }\n", "", 0 },
    { "int g(int x) __attribute__((unused)) { return x; }\n", "", 0 },
    { "typedef int T; int f(int T) { return T; } T g;\n", "", 0 },
    // Whether a body may follow is what the declarator makes its name first: a function through groups and later
    // suffixes, not a pointer to one, and only for a declaration's one declarator.
    { "void (f(void)) {}\nint (*g(void))[3] { return 0; }\n", "", 0 },
    { "int (q)(int x) { return x; }\nint *(r)(void) { return 0; }\n", "", 0 },
    { "int (*p)(int) { return 0; }\n", "1:14: expected ';' after top level declarator", 0 },
    // A function's typedef declaration cannot carry a body, even though the declarator is a function's.
    { "typedef int f(int x) { return x; }\n", "1:1: function definition declared 'typedef'", 0 },
    { "typedef int f(int x) { return x; }\nint g(void) { return f(1); }\n", "1:1: function definition declared 'typedef'", 0 },
    { "int typedef f(void) { return 0; }\n", "1:5: function definition declared 'typedef'", 0 },
    { "int f(int a), g(int b) { return b; }\n", "1:23: expected ';' after top level declarator", 0 },
    { "int (*f(void)) x\n", "1:16: expected function body after function declarator", 0 },
    // The end of an identifier is where its spelling ends: a UCN and a line splice make it longer than its bytes.
    { "int \\u00E9\n", "1:11: expected ';' after top level declarator", 0 },
    { "int ve\\\nctor\n", "2:5: expected ';' after top level declarator", 0 },
    // An enumeration constant's scope begins after its enumerator, value included.
    { "typedef int T; void f(void) { enum { T = sizeof((T)0) }; }\n", "", 0 },
    { "typedef int T; void f(void) { enum { A = sizeof(T), T, B = T }; int y = T; }\n", "", 0 },
    { "typedef int T; void f(void) { enum { A = sizeof(T), T = 2, B = T }; int y = T; }\n", "", 0 },
    { "typedef int T; void f(void) { enum { T = 1 } x; T y; }\n", "1:50: expected ';' after expression", 0 },
    // Selection and iteration statements are blocks, and so is each of their substatements; a labeled statement isn't.
    { "typedef int T; void f(void) { if (sizeof(enum { T = 1 })) { int y = T; } else { int z = T; } T x; }\n", "", 0 },
    { "typedef int T; void f(void) { while (sizeof(enum { T = 1 })) (void)T; switch (sizeof(enum { T = 1 })) { case T: ; } T x; }\n", "", 0 },
    { "typedef int T; void f(void) { do (void)sizeof(enum { T = 1 }); while (0); do {} while (sizeof(enum { T = 1 }) + T); T x; }\n", "", 0 },
    { "typedef int T; void f(void) { if (1) (void)sizeof(enum { T = 1 }); else (void)(T)1; for (;;) (void)sizeof(enum { T = 1 }); T x; }\n", "", 0 },
    { "typedef int T; void f(void) { do (void)sizeof(enum { T = 1 }); while (T); }\n", "1:71: unexpected type name 'T': expected expression", 0, true },
    { "typedef int T; void f(void) { L: (void)sizeof(enum { T = 1 }); T x; }\n", "1:65: expected ';' after expression", 0 },
    // A definition's parameters are in scope in its body, and not in the rest of its declarator or its attributes;
    // what its parameter list declares is.
    { "typedef int T; int (*f(int T))[sizeof((T)0)] { return 0; }\n", "", 0 },
    { "typedef int T; int (*g(int T))(T) { (void)T; return 0; }\n", "", 0 },
    { "typedef int T; int h(int T) __attribute__((aligned(sizeof((T)0)))) { return T; }\n", "", 0 },
    { "typedef int T; int f(enum { T = 1 } a) { return T + a; }\n", "", 0 },
    // __builtin_offsetof's member designator: members' names whatever the ordinary names mean, `.` and subscripts.
    { "typedef int T; struct S { int T; int m[2]; }; int x = __builtin_offsetof(struct S, T) + __builtin_offsetof(struct S, m[1]);\n", "", 0 },
    { "typedef int T; struct U { int T; }; struct S { struct U m[2]; }; int x = __builtin_offsetof(struct S, m[sizeof(T) - 3].T);\n", "", 0 },
    { "struct S { int a; }; int x = __builtin_offsetof(struct S, a + 1);\n", "1:61: expected ')'", 0 },
    { "struct S { int a; }; int x = __builtin_offsetof(struct S, (a));\n", "1:59: expected identifier", 0 },
    { "struct S { int a; }; int x = __builtin_offsetof(struct S, a->b);\n", "1:60: expected ')'", 0 },
    // __builtin_available's specs (#148): a `*`, or a platform's name, whatever the ordinary names mean, and its number;
    // clang's errors where the tokens' kinds don't fit, its `(` expected just after the keyword.
    { "typedef int macos; int f(void) { if (__builtin_available(macos 10.12, ios 10_3, *)) return 1; return __builtin_available(*); }\n", "", 0 },
    { "int f(void) { return __builtin_available; }\n", "1:41: expected '('", 0 },
    { "int f(void) { return __builtin_available x; }\n", "1:41: expected '('", 0 },
    { "int f(void) { return __builtin_available(); }\n", "1:42: expected a platform name here", 0 },
    { "int f(void) { return __builtin_available(*,); }\n", "1:44: expected a platform name here", 0 },
    { "int f(void) { return __builtin_available(int 1, *); }\n", "1:42: expected a platform name here", 0 },
    { "int f(void) { return __builtin_available(macos x, *); }\n", "1:48: expected a version of the form 'major[.minor[.subminor]]'", 0 },
    { "int f(void) { return __builtin_available(macos 'a', *); }\n", "1:48: expected a version of the form 'major[.minor[.subminor]]'", 0 },
    { "int f(void) { return __builtin_available(macos \"1\", *); }\n", "1:48: expected a version of the form 'major[.minor[.subminor]]'", 0 },
    { "int f(void) { return __builtin_available(*, macos 1 ios 2); }\n", "1:53: expected ')'", 0 },
    { "int f(void) { return __builtin_available(* macos); }\n", "1:44: expected ')'", 0 },
    { "int f(void) { return __builtin_available(*; }\n", "1:43: expected ')'", 0 },
    { "int f(void) { return __builtin_available(* ;); }\n", "1:44: unexpected ';' before ')'", 0 },
    // An initializer's designators take `.`, never `->`.
    { "struct S { int a; } s = { ->a = 1 };\n", "1:27: expected expression", 0 },
    { "struct S { struct { int b; } a; } s = { .a->b = 1 };\n", "1:43: expected '=' or another designator", 0 },
    // Only a single array subscript allows GNU's missing '='; field and chained designators still require it.
    { "struct S { int a; } s = { .a 1 };\n", "1:30: expected '=' or another designator", 0 },
    { "int a[1][2] = { [0][1] 1 };\n", "1:24: expected '=' or another designator", 0 },
    { "struct S { int a[1]; } s = { .a[0] 1 };\n", "1:36: expected '=' or another designator", 0 },
    // After a single one, clang reads the value GNU lets follow it: what can't begin one is a missing expression.
    { "int a[2] = { [0] };\n", "1:18: expected expression", 0 },
    { "int a[2] = { [0 ... 1], 1 };\n", "1:23: expected expression", 0 },
    { "int a[2] = { [0] / 2 };\n", "1:18: expected expression", 0 },
    { "void f(int *p) { int a[2] = { [1] -1, [0] (int)2.5 }, b[2] = { [1] sizeof a, [0] *p }; }\n", "", 0 },
    // K&R definitions: the name's own identifier list, through the declarator's groups, in C17 and before.
    { "int (f(x)) int x; { return x; }\nint (*g(y)) int y; { return 0; }\n", "", 0 },
    { "int f(x) int x; 5\n", "1:17: expected function body after function declarator", 0 },
    { "int f(x) int x; { return x; }\n", "1:7: unknown type name 'x'", "c23", true },
    { "int g(const x);\n", "1:13: unknown type name 'x'", "c23", true },
    // A K&R definition's parameter declarations declare its parameters, each once, with `register` at most, without
    // initializers, in a scope of their own, which the body ends; and its identifier list names each once.
    { "int f(a, a) { return 0; }\n", "1:10: redefinition of parameter 'a'", 0 },
    { "int f(a) int a; int b; { return a; }\n", "1:21: parameter named 'b' is missing", 0 },
    { "int f(a, b) int a, b, a; { return 0; }\n", "1:23: redefinition of parameter 'a'", 0 },
    { "int f(a) int a; int; { return 0; }\n", "1:17: declaration does not declare a parameter", 0 },
    { "int f(a) static int a; { return 0; }\n", "1:10: invalid storage class specifier in function declarator", 0 },
    { "int f(a, b) register int a; int b; { return a + b; }\n", "", 0 },
    { "int f(a) int a = 1, b; { return 0; }\n", "1:15: expected ';' at end of declaration", 0 },
    { "int f(a) int g(void) { return 0; }\n", "1:14: parameter named 'g' is missing", 0 },
    { "int f(a) int a __attribute__((unused)), b; { return 0; }\n", "1:41: parameter named 'b' is missing", 0 },
    { "typedef int B; int f(a) enum { B } a; { B x; return 0; }\n", "", 0 },
    { "int f(a, b) int a,\n{ return 0; }\n", "2:1: expected identifier or '('", 0 },
    { "int f(a) 5\n", "1:10: expected function body after function declarator", 0 },
    { "int f(a) int a; __extension__ int b; { return 0; }\n", "1:17: expected function body after function declarator", 0 },
    // The list's names are ordinary identifiers in the body, where a K&R list may name them again (which only clang's
    // semantic analysis rejects, there).
    { "int f(a) { int g(a, b); return 0; }\n", "", 0, true },
    // An attribute list where clang takes none: after a K&R identifier list, an operand or a designator's member.
    { "int f(a) [[deprecated]] int a; { return a; }\n", "1:10: an attribute list cannot appear here", 0 },
    { "int a[2]; int b = a[[0]];\n", "1:20: an attribute list cannot appear here", 0 },
    { "struct S { int a; }; int x = __builtin_offsetof(struct S, a [[x]]);\n", "1:61: an attribute list cannot appear here", 0 },
    // An identifier where a type would be is the name, with an implicit int, if what follows may follow a name, and
    // else an unknown type name.
    { "int f(int a, x);\n", "", "c89" },
    { "int f(x y);\n", "1:7: unknown type name 'x'", 0, true },
    { "int f(int a, x);\n", "1:14: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "x y;\n", "1:1: unknown type name 'x'", 0, true },
    { "struct S { x *y; };\n", "1:12: unknown type name 'x'", 0, true },
    { "struct S { [[deprecated]] x; };\n", "1:27: type name requires a specifier or qualifier", 0 },
    { "x;\n", "1:1: a type specifier is required for all declarations", "c23", true },
    { "__extension__ x;\n", "1:15: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "__extension__;\n", "", 0 },
    // A declarator without specifiers is an implicit int, as an identifier is; its group holds the name.
    { "(x);\n", "1:2: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "(x);\n", "", "c89" },
    { "(\"x\");\n", "1:2: expected identifier or '('", 0 },
    { "static (x);\n", "1:9: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    // Clang finishes the declarator before diagnosing its missing return/type specifier.
    { "f(A,\n12);\n", "2:1: expected identifier", 0 },
    { "typedef BOOLEAN\n(NTAPI *Fn)(int);\n", "2:2: unknown type name 'NTAPI'", 0, true },
    { "f(a)\nextern int x;\n", "2:1: invalid storage class specifier in function declarator", 0 },
    { "f(void);\n", "1:1: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "f(a) int a; {return a;}\n", "1:1: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    // The primary diagnostic belongs to the invocation; macro spelling remains available as an expansion note.
    { "#define TYPE Missing\nTYPE x;\n", "2:1: unknown type name 'Missing'", 0, true },
    { "#define TYPE Missing\n#define OUTER TYPE\nOUTER x;\n", "3:1: unknown type name 'Missing'", 0, true },
    // Missing separators follow the outer invocation's physical end, including substituted arguments and splices.
    { "#define END return 1\nint f(void){ END }\n", "2:17: expected ';' after return statement", 0 },
    { "#define RET(x) return x\nint f(void){ RET(2) }\n", "2:20: expected ';' after return statement", 0 },
    { "#define ID(x) x\nint f(void){ ID(return 3) }\n", "2:26: expected ';' after return statement", 0 },
    { "#define INNER return 4\n#define OUTER INNER\nint f(void){ OUTER }\n", "3:19: expected ';' after return statement", 0 },
    { "#define RET(x) return x\n#define ALIAS RET\nint f(void){ ALIAS(5) }\n", "3:22: expected ';' after return statement", 0 },
    { "#define RET(x) return x\n#define WRAP(x) RET(x)\nint f(void){ WRAP(6) }\n", "3:21: expected ';' after return statement", 0 },
    { "#define RET(x) return x\n#define ID(x) x\nint f(void){ ID(RET(7)) }\n", "3:24: expected ';' after return statement", 0 },
    { "#define RET(x) return x\n#define CAT(a,b) a##b\n#define VALUE8 8\nint f(void){ RET(CAT(VALUE,8)) }\n", "4:31: expected ';' after return statement", 0 },
    { "#define END return 1\nint f(void){ EN\\\nD }\n", "3:2: expected ';' after return statement", 0 },
    { "#define RET(x) return x\nint f(void){ RET\\\n(9) }\n", "3:4: expected ';' after return statement", 0 },
    // Inside an unfinished expansion, the next token remains the primary location, including argument spelling.
    { "#define M return 1 return 2;\nint f(void){ M }\n", "2:14: expected ';' after return statement", 0 },
    { "#define D int x=1 int y=2;\nint f(void){ D return 0; }\n", "2:14: expected ';' at end of declaration", 0 },
    { "#define E(a) a int y=2;\nint f(void){ E(int x=1) return 0; }\n", "2:14: expected ';' at end of declaration", 0 },
    { "#define A(x) x\nint f(void){ A(return 1 return 2;) }\n", "2:25: expected ';' after return statement", 0 },
    // A _Static_assert's message is string literals.
    { "_Static_assert(1, \"x\" \"y\" \"z\");\n", "", 0 },
    { "_Static_assert(1, identifier);\n", "1:19: expected string literal for diagnostic message in static_assert", 0, true },
    { "_Static_assert(1, \"x\" + 1);\n", "1:23: expected ')'", 0 },
    { "_Static_assert(1, \"x\", 2);\n", "1:22: expected ')'", 0 },
    // A type name where an operand would be.
    { "typedef int T; int y = sizeof T;\n", "1:30: expected parentheses around type name in sizeof expression", 0 },
    { "typedef int T; int y = 1 ? T : 2;\n", "1:28: unexpected type name 'T': expected expression", 0, true },
    // A K&R definition's identifier list is its name's, whatever suffixes its return type has.
    { "int (*f(x))(int) int x; { return 0; }\nint (*g(y))[3] int y; { return 0; }\n", "", 0 },
    // A tag's definition may end a _Generic association's type name.
    { "int x = _Generic(0, struct S { int a; }: 1, default: 0);\nint y = _Generic(0, enum E { A }: 1, default: 0);\n", "", "c17" },
    // A GNU attribute list's items may be empty, the last one too.
    { "int x __attribute__((unused,)); int f(int a __attribute__((unused,))); enum E { A __attribute__((deprecated,)) };\nint y __attribute__((,unused,,deprecated,));\n", "", 0 },
    // C23's attribute lists: names, perhaps in a scope and with arguments, separated by commas, any item empty; clang
    // expects the `,` or the `]` after the token before.
    { "[[]] int a; [[,]] int b; [[deprecated,,maybe_unused]] int c; [[gnu::aligned(8), ]] int d; [[__gnu__::__unused__, x ::y]] int e;\n", "", 0 },
    { "[[123]] int x;\n", "1:3: expected ']'", 0 },
    { "[[gnu::unused gnu::deprecated]] int x;\n", "1:14: expected ','", "c23" },
    { "[[x(1)   (2)]] int x;\n", "1:7: expected ','", 0 },
    { "[[x,  1]] int x;\n", "1:5: expected ']'", 0 },
    { "[[gnu::]] int x;\n", "1:8: expected identifier", 0 },
    // A label's name after `&&`, an asm operand's symbolic name and asm goto's labels are names, whatever the ordinary
    // names mean; asm goto's colons come to its labels, and they to one at least.
    { "typedef int T, L; void f(int x) { void *p = &&T; asm goto(\"\" : [T] \"=r\"(x) : [U] \"r\"(x) : : L); goto *p; T: L:; }\n", "", 0 },
    { "void f(int x) { asm(\"\" : [42] \"=r\"(x)); }\n", "1:27: expected identifier", 0 },
    { "void f(int x) { asm(\"\" : [x + 1] \"=r\"(x)); }\n", "1:29: expected ']'", 0 },
    { "void f(int x) { asm(\"\" : [a]); }\n", "1:29: expected string literal in 'asm'", 0 },
    { "void f(void) { asm goto(\"\" ::::); }\n", "1:32: expected identifier", 0 },
    { "void f(void) { asm goto(\"\" :::: a + b); a: b:; }\n", "1:35: expected ')'", 0 },
    { "void f(void) { asm goto(\"\" :); }\n", "1:29: expected ':'", 0 },
    { "void f(void) { asm goto(\"\" ::: \"memory\"); }\n", "1:40: expected ':'", 0 },
    // An asm statement's template, constraints and clobbers are string literals, its operands in parentheses and its
    // labels names, which nothing continues; an asm label is string literals, and a top-level asm block its template.
    { "int x asm(\"a\" \"b\"), y __asm__(\"c\") = 1; void f(int z) { asm(\"a\" \"b\" : \"=r\" \"m\"(z), [b] \"=r\"(z) : \"r\"(z) : \"memory\", \"cc\"); }\n", "", 0 },
    { "void f(void) { asm(\"\" + 1); }\n", "1:23: expected ')'", 0 },
    { "void f(void) { asm(\"a\", \"b\"); }\n", "1:23: expected ')'", 0 },
    { "void f(int x) { asm(\"\" : \"=r\"(x) + 1); }\n", "1:34: expected ')'", 0 },
    { "void f(void) { asm(\"\" ::: \"memory\" + 1); }\n", "1:36: expected ')'", 0 },
    { "void f(void) { asm(\"\" ::: \"a\",); }\n", "1:31: expected string literal in 'asm'", 0 },
    { "void f(int x) { asm(\"\" ::: x); }\n", "1:28: expected ')'", 0 },
    { "void f(int x) { asm(\"\" : \"=r\"(x),); }\n", "1:34: expected string literal in 'asm'", 0 },
    { "int x; asm(\"\" : \"=r\"(x));\n", "1:15: expected ')'", 0 },
    { "int x asm(\"y\" + 1);\n", "1:15: expected ')'", 0 },
    { "int x asm(y);\n", "1:11: expected string literal in 'asm'", 0 },
    // Local labels never bind ordinary names, asm qualifiers have exact identities, and only one `::` token is a scope.
    { "typedef int T; void f(void) { __label__ L,T; T x; goto L; L: T:; }\n", "", 0 },
    { "typedef int T; void f(void) { __label__ T; T x; T:; }\n", "", 0 },
    { "void f(void) { __label__ *L; }\n", "1:26: expected identifier", 0 },
    { "void f(void) { __label__ L = 3; }\n", "1:27: expected ';' at end of declaration", 0 },
    { "void f(void) { __label__ L,; }\n", "1:28: expected identifier", 0 },
    { "void f(void) { __label__; }\n", "1:25: expected identifier", 0 },
    { "void f(void) { __label__ int; }\n", "1:26: expected identifier", 0 },
    { "void f(void) { __label__ L(void); }\n", "1:27: expected ';' at end of declaration", 0 },
    { "void f(void) { __label__ L[3]; }\n", "1:27: expected ';' at end of declaration", 0 },
    { "void f(void) { __label__ L M; }\n", "1:27: expected ';' at end of declaration", 0 },
    { "__label__ L;\n", "1:1: expected identifier or '('", 0 },
    { "struct S { __label__ L; };\n", "1:12: type name requires a specifier or qualifier", 0 },
    { "void f(__label__ L);\n", "1:8: expected parameter declarator", 0 },
    { "void f(void) { if (1) __label__ L; }\n", "1:23: expected expression", 0 },
    { "int __label__ L;\n", "1:5: expected identifier or '('", 0 },
    { "void f(void) { asm const(\"\"); }\n", "1:20: expected 'volatile', 'inline', 'goto', or '('", 0, true },
    { "void f(void) { asm static(\"\"); }\n", "1:20: expected 'volatile', 'inline', 'goto', or '('", 0, true },
    { "void f(void) { asm restrict(\"\"); }\n", "1:20: expected 'volatile', 'inline', 'goto', or '('", 0, true },
    { "void f(void) { asm volatile __volatile__(\"\"); }\n", "1:29: duplicate asm qualifier 'volatile'", 0, true },
    { "void f(void) { asm inline __inline__(\"\"); }\n", "1:27: duplicate asm qualifier 'inline'", 0, true },
    { "void f(void) { asm goto goto(\"\" :::: L); L:; }\n", "1:25: duplicate asm qualifier 'goto'", 0, true },
    { "asm volatile(\"\");\n", "1:5: meaningless 'volatile' on asm outside function", 0, true },
    { "int x __asm__ inline(\"y\");\n", "1:15: meaningless 'inline' on asm outside function", 0, true },
    { "__asm__ const(\"\");\n", "1:9: expected '(' after 'asm'", 0 },
    { "void f(void) { asm volatile inline(\"\"); asm __inline __volatile__(\"\"); asm __inline__ __volatile(\"\"); }\n", "", 0 },
    { "#define C :\n[[gnu:C unused]] int x;\n", "2:6: expected ','", "c23" },
    { "#define C ::\n[[gnu C unused]] int x;\n", "", "c23" },
    { "#define C :\n[[gnu C: unused]] int x;\n", "2:6: expected ','", "c23" },
    // GNU label attributes need no empty statement before the next statement, declaration, block or closing brace.
    { "void f(void) { L: __attribute__((unused)) return; }\n", "", 0 },
    { "void f(void) { L: __attribute__((unused)) f(); }\n", "", 0 },
    { "void f(void) { L: __attribute__((cold)) __attribute__((unused)) { return; } }\n", "", 0 },
    { "void f(void) { L: __attribute__((unused)) }\n", "", 0 },
    { "void f(void) { L: __attribute__((unused)) int x; }\n", "", 0 },
    // Statement attributes have the same continuation at a block-item boundary and after a control head.
    { "void f(void) { __attribute__((noinline)) f(); }\n", "", 0 },
    { "void f(void) { __attribute__((always_inline)) f(); }\n", "", 0 },
    { "void f(void) { __attribute__((__noinline__)) f(); }\n", "", 0 },
    { "void f(void) { if (1) __attribute__((noinline)) f(); }\n", "", 0 },
    { "void f(void) { if (1) __attribute__((noinline)) { f(); } }\n", "", 0 },
    { "void f(void) { if (1) __attribute__((unused)) int x; }\n", "1:47: expected expression", 0 },
    { "void f(void) { if (1) __attribute__((noinline)) }\n", "1:49: expected statement", 0 },
    { "void f(void) { __attribute__((noinline)) }\n", "1:42: expected statement", 0 },
    { "void f(int x) { switch (x) { case 0: __attribute__((always_inline)) } }\n", "1:69: expected statement", 0 },
    { "void f(int x) { switch (x) { default: __attribute__((__noinline__)) } }\n", "1:69: expected statement", 0 },
    { "void f(void) { __attribute__((__always_inline__, noinline)) }\n", "1:61: expected statement", 0 },
    { "void f(void) { __attribute__((unknown)) x; }\n", "1:41: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    // An existing ordinary name after a declaration's GNU prefix is an expression annotation, which clang cannot
    // read as a declarator. Unbound names keep implicit int; typedefs, statement attributes and labels keep their paths.
    { "int x; void f(void) { __attribute__(()) x = 1; }\n", "1:41: expected identifier or '('", 0 },
    { "void f(int x) { __attribute__(()) x = 1; }\n", "1:35: expected identifier or '('", 0 },
    { "void f(void) { int x; __attribute__((unused)) x; }\n", "1:47: expected identifier or '('", 0 },
    { "enum { x }; void f(void) { __attribute__((unused)) x; }\n", "1:52: expected identifier or '('", 0 },
    { "void g(void); void f(void) { __attribute__(()) g(); }\n", "1:48: expected identifier or '('", 0 },
    { "void f(void) { { int x; } __attribute__(()) x; }\n", "1:45: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "void f(void) { __attribute__(()) x = 1; }\n", "1:34: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "int x; __attribute__(()) x = 1;\n", "1:26: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "typedef int T; void f(void) { __attribute__(()) T x; }\n", "", 0 },
    { "int x; void f(void) { __attribute__(()) x = 1; }\n", "1:41: expected identifier or '('", "c89" },
    { "void f(void) { __attribute__(()) x = 1; }\n", "", "c89" },
    { "void f(void) { __attribute__((unused)) __extension__ int x; }\n", "1:40: expected identifier or '('", 0 },
    { "void f(void) { L: __attribute__((unused)) __extension__ int x; }\n", "1:57: expected expression", 0 },
    // A file-scope declaration's leading attribute lists (C23's, then GNU's) and the `__extension__`s after them, as clang's
    // ParseTopLevelDecl reads them before ParseExternalDeclaration (#1447), in any order. An `__extension__` after a
    // specifier or after a list after an `__extension__` is none; a C23 list just after an `__extension__` and the lists
    // before a static assertion are clang's error, at the first of them.
    { "__attribute__((unused)) __extension__ int a;\n", "", 0 },
    { "__attribute__((unused)) __attribute__((used)) __extension__ __extension__ int a;\n", "", 0 },
    { "__attribute__((unused)) __extension__ __attribute__((unused)) int a;\n", "", 0 },
    { "__attribute__((unused)) __extension__ static int c(void) { return 0; }\n", "", 0 },
    { "__attribute__((unused)) __extension__ struct S { int x; } s;\n", "", 0 },
    { "__attribute__((unused)) __extension__ typedef int T;\n", "", 0 },
    { "int a; __attribute__((unused)) __extension__ int b(void), c;\n", "", 0 },
    { "[[gnu::unused]] __attribute__((unused)) __extension__ int a;\n", "", "c23" },
    { "[[gnu::unused]] __extension__ __attribute__((unused)) int a;\n", "", "c23" },
    { "__attribute__((unused)) static __extension__ int a;\n", "1:32: expected identifier or '('", 0 },
    { "__attribute__((unused)) __extension__ __attribute__((unused)) __extension__ int a;\n", "1:63: expected identifier or '('", 0 },
    { "__extension__ __attribute__((unused)) __extension__ int a;\n", "1:39: expected identifier or '('", 0 },
    { "__attribute__((unused)) [[gnu::unused]] __extension__ int a;\n", "", "c23" },
    { "__attribute__((unused)) __extension__ [[gnu::unused]] int a;\n", "1:39: an attribute list cannot appear here", "c23" },
    { "__extension__ [[gnu::unused]] int a;\n", "1:15: an attribute list cannot appear here", "c23" },
    { "__attribute__((unused)) _Static_assert(1, \"\");\n", "1:1: an attribute list cannot appear here", 0 },
    { "__attribute__((unused)) __extension__ __extension__ _Static_assert(1, \"\");\n", "1:1: an attribute list cannot appear here", 0 },
    { "[[gnu::unused]] _Static_assert(1, \"\");\n", "1:1: an attribute list cannot appear here", "c23" },
    // A GNU list between a tag's name and its body ends the declaration, as clang's does (a C23 list there is read on,
    // #2268, which the checker's fixtures cover: clang's parser reports it).
    { "struct S __attribute__((packed)) { int a; };\n", "1:34: expected identifier or '('", 0 },
    // `__extension__`s before a static assertion, at file scope and in a block, which clang takes (#1447).
    { "__extension__ _Static_assert(1, \"\");\nvoid f(void) { __extension__ __extension__ _Static_assert(1, \"\"); }\n", "", 0 },
    // Attribute applicability belongs to semantic checking; the parser retains even an invalid statement attribute.
    { "void f(void) { __attribute__((unused)); }\n", "", 0, true },
    // #1127's places and messages. A GNU attribute list's and its arguments' `)` and its second `(` are expected after the
    // token before (clang's ExpectAndConsume); an argument list that starts with what can't is an expression's error.
    { "int x __attribute__ ((unused x));\n", "1:29: expected ')'", 0 },
    { "int x __attribute__ (( (unused)));\n", "1:23: expected ')'", 0 },
    { "int x __attribute__ ((aligned(4 4)));\n", "1:32: expected ')'", 0 },
    { "int x __attribute__ ((aligned(;)));\n", "1:31: expected expression", 0 },
    // Clang classifies the required string's diagnostic as semantic, including an empty or malformed argument.
    { "int x __attribute__((section(,)));\n", "1:30: expected string literal as argument of 'section' attribute", 0, true },
    { "int x __attribute__((section(1,)));\n", "1:30: expected string literal as argument of 'section' attribute", 0, true },
    { "int x __attribute__ ( unused));\n", "1:22: expected '(' after '('", 0 },
    // A for-statement's missing `;` is at the token clang finds instead.
    { "void f(int n) { for (int i = 0; i n < ; i++) { } }\n", "1:35: expected ';' in 'for' statement specifier", 0 },
    { "void f(int n) { for (int i = 0 i < n; i++) ; }\n", "1:32: expected ';' in 'for' statement specifier", 0 },
    { "void f(int n) { for (; n ) ; }\n", "1:26: expected ';' in 'for' statement specifier", 0 },
    // A `;` just before a group's closer, where clang's balanced delimiters close it; a few builtins check theirs apart.
    { "void f(int a) { f(a;); }\n", "1:20: unexpected ';' before ')'", 0 },
    { "int a[2] = {1;};\n", "1:14: unexpected ';' before '}'", 0 },
    { "int x[3;];\n", "1:8: unexpected ';' before ']'", 0 },
    { "void f(__builtin_va_list ap) { int a = __builtin_va_arg(ap, int;); }\n", "1:64: expected ')'", 0 },
    { "int a = __builtin_offsetof(struct { int a[2]; }, a[1;]);\n", "1:53: unexpected ';' before ']'", 0 },
    { "void f(int a) { if (a)) ; }\n", "1:23: extraneous ')' after condition, expected a statement", 0 },
    // A return statement's `;` is expected as any other token; a function declarator's body before its `;`, but after
    // an asm label.
    { "int f(void) { return (1)); }\n", "1:25: expected ';' after return statement", 0 },
    { "int f(void) __attribute__((unused)));\n", "1:36: expected function body after function declarator", 0 },
    { "int f(void) __attribute__((unused)) (void);\n", "1:37: expected function body after function declarator", 0 },
    { "int f(void) __asm__(\"f\"));\n", "1:25: extraneous ')' before ';'", 0 },
    { "int f(int * char p);\n", "1:13: invalid parameter name: 'char' is a keyword", 0 },
    { "enum E { A 1 };\n", "1:12: expected '= constant-expression' or end of enumerator definition", 0 },
    { "union;\n", "1:1: declaration of anonymous union must be a definition", 0 },
    { "enum;\n", "1:5: expected identifier or '{'", 0 },
    // After a tag's definition, a name that can't be the declarator is the next declaration's type, just after the body.
    { "struct S { int a; } x y;\n", "1:20: expected ';' after struct", 0 },
    { "struct S { int a; } __attribute__((packed)) x y;\n", "1:20: expected ';' after struct", 0 },
    { "struct S { int a; union\n int x; long y; } u;\n", "1:24: expected ';' after union", 0 },
    { "void f(int a) { f(;); }\n", "1:19: expected expression", 0 },
    { "void f(int a) { a = a ? ) : 1; }\n", "1:25: expected expression", 0 },
    { "int a = _Generic(1 2, int: 1);\n", "1:19: expected ','", 0 },
    { "int a = __builtin_choose_expr(1 2, 3);\n", "1:32: expected ','", 0 },
    { "int [3] x;\n", "1:10: brackets are not allowed here; to declare an array, place the brackets after the identifier", 0 },
    { "int x, [2] = { 5, 6 };\n", "1:12: expected identifier or '('", 0 },
    { "struct P { int c; } p = { . .c = 1 };\n", "1:29: expected a field designator, such as '.field = 4'", 0 },
    { "void f(int *t, int a) { a = t[[a] + 1]; }\n", "1:30: C++11 only allows consecutive left square brackets when introducing an attribute", 0 },
    { "void f(int a) { do ; while a; }\n", "1:28: expected '(' after 'do/while'", 0 },
    // A braced initializer in a list takes no postfix operator, which the parser took before.
    { "int a[2][1] = { {1}[0] };\n", "1:20: expected '}'", 0 },
    // A `#pragma pack` may follow a tag's body, and the specifiers go on (clang's error is the checker's, "cannot combine
    // with previous 'struct' declaration specifier"); another pragma there is a missing `;`.
    { "#pragma pack(push, 1)\nstruct P { char c; int i; }\n#pragma pack(pop)\nint x;\n", "", 0, true },
    { "struct P { char c; int i; }\n_Pragma(\"pack(pop)\") static int x;\n", "", 0, true },
    { "struct P { char c; int i; }\n#pragma GCC diagnostic push\nint x;\n", "1:28: expected ';' after struct", 0 },
    { "#pragma pack(push, 1)\nstruct P { char c; int i; }\n#pragma pack(pop)\nx y;\n", "2:28: expected ';' after struct", 0 },
    // A string follows no subscript (K6 let it, for asm operands' `[name] "constraint"`, which go to the scalar parser).
    { "void g(const char *, const char *); void f(char **a) { g(a[0] \"x\"); }\n", "1:63: expected ')'", 0 },
    { "void f(int x) { asm volatile (\"\" : [r] \"=r\" (x) : [i] \"r\" (x)); }\n", "", 0 },
    // A parameter's declarator without specifiers is an implicit int, at its name or where its name would be; a typeless
    // abstract declarator's and an unnamed bit-field's are too.
    { "int f(*p);\n", "1:8: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "int f(*);\n", "1:8: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "int f([3]);\n", "1:7: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "int f((void));\n", "1:8: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "int f(int a, (*b)(void));\n", "1:16: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "int f(* char p);\n", "1:9: invalid parameter name: 'char' is a keyword", 0 },
    { "int f((__nonnull__ (1)));\n", "1:21: expected parameter declarator", 0 },
    { "int x = (const)1;\n", "1:15: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "struct S { const : 3; };\n", "1:18: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    // A declarator ends at its attributes and asm label: no suffix after them, nor attributes after its name in its
    // parentheses; a declaration's `(` there is clang's C++-style direct initializer (#1252).
    { "int x __attribute__((unused)) [3];\n", "1:30: expected ';' after top level declarator", 0 },
    { "struct S { int x __attribute__((unused)) [3]; };\n", "1:41: expected ';' at end of declaration list", 0 },
    { "void g(int x __attribute__((unused)) [3]);\n", "1:38: expected ')'", 0 },
    { "int (*p __attribute__((unused)))(void);\n", "1:9: expected ')'", 0 },
    { "int x __attribute__((unused)) (3);\n", "", 0 },
    { "int x __asm__(\"x\") (3), y;\n", "", 0 },
    { "int x __attribute__((unused)) (3) = 4;\n", "1:34: expected ';' after top level declarator", 0 },
    { "int x __attribute__((unused)) (int);\n", "1:32: expected expression", 0 },
    { "struct S { int x __attribute__((unused)) (3); };\n", "1:41: expected ';' at end of declaration list", 0 },
    // A declarator's group holds no initializer: clang closes it at the `=`.
    { "int (*fp(int, ...) = 0;\n", "1:20: expected ')'", 0 },
    { "void f(void) { int (*p = 0; }\n", "1:24: expected ')'", 0 },
    // What can't continue a declarator ends it, and clang's Sema takes it, saying a missing type, before the parser
    // looks at what follows: but after it asks for a function's body.
    { "*p 1;\n", "1:2: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "*p }\n", "1:2: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "void f(*p 1);\n", "1:9: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "static const char *name( (int c)\n{\n", "1:27: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "void g(void) { const *p ); }\n", "1:23: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "struct S { const *p ) };\n", "1:19: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    { "*f() 1;\n", "1:6: expected function body after function declarator", 0 },
    { "int f( (a, b);\n", "1:10: expected ')'", 0 },
    { "(*x 1;\n", "1:5: expected ')'", 0 },
    { "(x;\n", "1:3: expected ')'", 0 },
    { "*f() int x;\n", "1:2: type specifier missing, defaults to 'int'; ISO C99 and later do not support implicit int [-Wimplicit-int]", 0, true },
    // At the end of the file: a function's body, a do-statement's while, a head's or a label's statement.
    { "int f(void)\n", "1:12: expected function body after function declarator", 0 },
    { "void f(int a) { do { { a -= 1; } while (a > 0); return; }\n", "1:58: expected 'while' in do/while loop", 0 },
    { "void f(int a) { if (a) do a -= 1;\n", "1:34: expected 'while' in do/while loop", 0 },
    { "void f(int a) { while (a)\n", "1:26: expected expression", 0 },
    { "void f(int a) { switch (a) { case 1:\n", "1:37: expected expression", 0 },
    { "void f(int a) { do { { a -= 1; }\n", "1:33: expected '}'", 0 },
};
int main(void)
{
 for(unsigned i=0;i<sizeof(parse_test_snippets)/sizeof(*parse_test_snippets);++i)
 {
  char name[160];snprintf(name,sizeof(name),"alignment-cases/%04u.txt",i);
  FILE* f=fopen(name,"w");if (!f||fputs(parse_test_snippets[i].source,f)<0||fclose(f))return 1;
 }
 return 0;
}
