from pathlib import Path
import re
p=Path(__file__).parent
f=p/'tree/src/buster/compiler/c_parser.c'
diag=f.read_text().split('struct ParseDiagnostic\n{',1)[1].split('\n};',1)[0]
fields=re.findall(r'^    (?:uint\d+_t|bool) (\w+);',diag,re.M)
assert len(fields)>30
t=(p/'tree-oracle.py').read_text()
s=(p/'oracle.c').read_text().replace('diag->token, diag->argument, diag->message, diag->place, diag->error, diag->note',', '.join('diag->'+field for field in fields))
(p/'all-columns.c').write_text(s)
s=(p/'run-census').read_text().replace('group=$1','group=$1; exe=$2; shift 2').replace('fixtures) args=', 'declarations) args=("$root"/declarations/*.c);;\nfixtures) args=').replace('if [[ $group == musl ]];then','if [[ $group == musl || $group == declarations ]];then').replace('./census ', '"$exe" "$@" ')
(p/'run-parser-group').write_text(s)
s=(p/'census-task').read_text().split('"$lock" "$cc"')[0]
s+='''for tag in census grouped;do
 "$lock" "$cc" -O3 -march=native -fwrapv -funsigned-char -fno-strict-aliasing -ffunction-sections -fdata-sections -Wl,--gc-sections -I "$tag-src" -I "$base" -I "$base/buster/compiler" all-columns.c -lm -o "$tag-oracle" >"$tag-oracle-build.log" 2>&1
done
for g in fixtures declarations lua sqlite musl;do
 for tag in census grouped;do
  export BUSTER_DECL_TREE="$PWD/$tag-$g.tmp"
  : >"$BUSTER_DECL_TREE"
  bash run-parser-group "$g" "./$tag-oracle" >"$tag-$g-trees.log" 2>&1
  test -s "$BUSTER_DECL_TREE"; sha256sum <"$BUSTER_DECL_TREE" >"$tag-$g.sha"; wc -c <"$BUSTER_DECL_TREE" >"$tag-$g.bytes"
  rm "$BUSTER_DECL_TREE"
 done
 cmp "{group}".sha "{other}".sha
 cmp "{group}".bytes "{other}".bytes
done
touch grouped-oracle.ok
'''.replace('"{group}"','"census-$g"').replace('"{other}"','"grouped-$g"')
(p/'grouped-oracle-task').write_text(s)
d=p/'widths';d.mkdir(exist_ok=True)
for width in (0,1,2,3,4,7,8,14,15,16,17,30,31,32,33,63,64,65,127,128,256):
 for grouped in (False,True):
  args=', '.join('int a'+str(i) for i in range(width)) or 'void'
  lines=[]
  for n in range(64):
   name='f'+str(n)
   if grouped:name='('+name+')'
   lines.append('int '+name+'('+args+') { return '+('a0' if width else '0')+'; }')
  (d/(('group' if grouped else 'plain')+'-'+str(width)+'.c')).write_text('\n'.join(lines)+'\n')
