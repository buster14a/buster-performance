from pathlib import Path
from collections import Counter
import tarfile
p=Path(__file__).parent;r=p/'results'
o=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-flagged-declarations')
def tab(tag):
 a={}
 for line in (p/(tag+'-aligned-results.tsv')).read_text().splitlines():
  id,digest,*data=line.split('\t');a[id]=digest,tuple(map(int,data))
 return a
a,b=tab('census'),tab('grouped')
assert len(a)==len(b)==557 and a.keys()==b.keys()
for k in a: assert a[k][0]==b[k][0] and a[k][1][:2]==b[k][1][:2] and a[k][1][5:]==b[k][1][5:]
changed=[k for k in a if a[k]!=b[k]]
assert changed==['0259']
delta=[x-y for x,y in zip(a['0259'][1],b['0259'][1])];assert delta[2:5]==[128,128,1664]
def units(file):
 return {row[1]:tuple(map(int,row[2:]))for line in file.read_text().splitlines() if (row:=line.split('\t'))[0]=='unit'}
x,y=[units(r/f'{t}-fixtures-trees.log')for t in ('census','grouped')]
assert len(x)==len(y)==9 and x.keys()==y.keys()
rows=[]
for key in sorted(x):
 assert x[key][0]==y[key][0] and x[key][4:]==y[key][4:]
 rows.append('| '+Path(key).stem+' | '+' | '.join(map(str,[x[key][0],x[key][2],y[key][2],x[key][3],y[key][3]]))+' |')
assert (r/'census-fixtures.sha').read_bytes()==(r/'grouped-fixtures.sha').read_bytes()
assert (r/'census-fixtures.bytes').read_text()==(r/'grouped-fixtures.bytes').read_text()
assert 'test-parser: passed' in (r/'grouped-frozen-clang.log').read_text()
o.mkdir(exist_ok=True)
doc='''# Grouped function declarators in the vector parser

The parent is buster14a/buster@cc7d4ffb449c1f57d8d867c2ad2bf6dc6bfebc7f. The K6 body check reads declarations backwards in blocks of sixteen. A declarator containing one ordinary name in parentheses immediately followed by the function’s parameter list can take the vector path. The scan continues to the preceding declaration boundary to check for a comma, typedef or another group. More complicated declarators can still reach the fallback.

## Aligned parser inputs

All 557 parser snippets ran at each of 64 preceding token alignments in the parent and candidate. For all 35,648 parses, the token counts, errors, diagnostics with their recovery fields, and all available tree and traversal columns for accepted inputs had matching byte representations. Only snippet 259 changed its route. It defines `int (q)(int x)` and `int *(r)(void)`. Across the alignments the candidate removed 128 fallback items and 1,664 reparsed tokens. The sole change in the parser suite’s frozen digests is the alignments row, which also includes the K6 flags and fallback counts. The full locked 9700X parser suite passed, including all 557 Clang syntax cases, the manually checked trees, and the tiled and borrowed-scratch checks.

The standalone Release-optimized native probes also compared nine parser issue fixtures. Their serialized trees and diagnostics matched. A further 768 generated declarations varied grouping, pointer and array forms, parameters, malformed bodies and declarations.

| Fixture | Tokens | Parent fallback items | Candidate fallback items | Parent fallback tokens | Candidate fallback tokens |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

[Candidate, fixture sources, per-snippet hashes, Clang suite and native logs](grouped-oracles.tar.xz)
'''
assert not (o/'README.md').exists()
with tarfile.open(o/'grouped-oracles.tar.xz','w:xz',preset=2)as t:
 for n in ['census.py','grouped.py','grouped-compiler.patch','census-task','run-census','grouped-oracle-task','aligned-oracle.py','aligned-snippets.c','run-aligned.py','native-grouped.py','all-columns.c','run-parser-group','build-grouped','verify-grouped-digest','tree-oracle.py','check-oracle','record-grouped.py','fixtures','declarations','census-aligned-results.tsv','grouped-aligned-results.tsv','grouped-declarations.log','census-declarations.log','census-tree.bin','grouped-tree.bin']:t.add(p/n,'source/'+n)
 for f in sorted(r.iterdir()):
  if f.is_file():t.add(f,'native/'+f.name)
(o/'README.md').write_text(doc)
print(changed,delta,*rows,sep='\n')
