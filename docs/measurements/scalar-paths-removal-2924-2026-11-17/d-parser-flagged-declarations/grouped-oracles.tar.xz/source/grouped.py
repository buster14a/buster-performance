from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent
t=p/'tree';f='src/buster/compiler/c_parser_impl.c'
old=(t/f).read_text()
prefix='''// A grouped identifier with an immediately following parameter list still derives a function first.
// A pointer, array or second group inside the declarator needs the full declarator parser.
static bool parse_body_grouped_name(const ParseKernels* kernels, uint32_t close, uint32_t body)
{
    return close >= 2 && body - close >= 3 && kernels->check_groups[body - 1] == PARSE_GROUP_PARAMETERS &&
           kernels->enclosing[body - 1] == close + 1 && kernels->roles[close + 1] == PARSE_ROLE_OPEN_CALL &&
           kernels->check_groups[close] == PARSE_GROUP_DECLARATOR && kernels->enclosing[close] == close - 2 && kernels->roles[close - 2] == PARSE_ROLE_OPEN_GROUP &&
           kernels->vkinds[close - 1] == PARSE_KIND_IDENTIFIER && kernels->roles[close - 1] == PARSE_ROLE_OPERAND;
}

// A function body follows just one declarator. Read back to the previous item boundary or the first
// same-depth token that requires full declarator parsing. Both sides of a simple name group are one declarator.
'''
body='''    const uint32_t depth = kernels->node_depths[body];
    const __m512i wanted = _mm512_set1_epi32((int32_t)depth);
    bool fails = false;
    for (uint32_t end = body; end != 0;)
    {
        const uint32_t first = end >= 16 ? end - 16 : 0;
        const __mmask16 live = (__mmask16)_bzhi_u32(UINT16_MAX, end - first);
        const __m512i depths = _mm512_maskz_loadu_epi32(live, kernels->node_depths + first);
        const __m128i roles = _mm_maskz_loadu_epi8(live, kernels->roles + first);
        const __m128i kinds = _mm_maskz_loadu_epi8(live, kernels->vkinds + first);
        const __mmask16 same = _mm512_mask_cmpeq_epi32_mask(live, depths, wanted);
        const __mmask16 stops = _mm512_mask_cmplt_epu32_mask(live, depths, wanted) |
            (same & (_mm_cmpeq_epi8_mask(roles, _mm_set1_epi8(PARSE_ROLE_TERMINATOR)) |
                     _mm_cmpeq_epi8_mask(roles, _mm_set1_epi8(PARSE_ROLE_CLOSE_BODY))));
        const __mmask16 closes = _mm_cmpeq_epi8_mask(roles, _mm_set1_epi8(PARSE_ROLE_CLOSE_GROUP));
        const __mmask16 flagged = same & (closes | _mm_cmpeq_epi8_mask(roles, _mm_set1_epi8(PARSE_ROLE_OPEN_GROUP)) |
            _mm_cmpeq_epi8_mask(roles, _mm_set1_epi8(PARSE_ROLE_COMMA)) |
            (_mm_cmpeq_epi8_mask(roles, _mm_set1_epi8(PARSE_ROLE_SPECIFIER)) & _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(PARSE_KIND_TYPEDEF))));
        const uint32_t events = stops | flagged;
        end = first;
        if (events != 0)
        {
            const uint32_t lane = 31u - (uint32_t)__builtin_clz(events);
            const uint32_t bit = 1u << lane;
            const uint32_t token = first + lane;
            if ((flagged & closes & bit) != 0 && parse_body_grouped_name(kernels, token, body))
            {
                end = token - 2;
            }
            else
            {
                fails = (flagged & bit) != 0;
                break;
            }
        }
    }
'''
def change(s):
 a=s.index("// A function's body follows a declaration's only declarator")
 b=s.index('static void parse_check_body(',a)
 c=s.index('    const uint32_t depth',b);z=s.index('    kernels->flags[body]',c)
 return s[:a]+prefix+s[b:c]+body+s[z:]
s=change(old)
(p/'grouped.c').write_text(s)
(p/'grouped.patch').write_text(''.join(unified_diff(old.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f)))
for tag,root in [('grouped','census-src')]:
 d=p/(tag+'-src/buster/compiler');d.mkdir(parents=True,exist_ok=True)
 (d/'c_parser.c').write_bytes((p/root/'buster/compiler/c_parser.c').read_bytes())
 (d/'c_parser_impl.c').write_text(change((p/root/'buster/compiler/c_parser_impl.c').read_text()))
