from pathlib import Path
from statistics import median
import re,sys,tarfile
p=Path(__file__).parent;r=p/'results'
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-flagged-declarations')
tag=sys.argv[1]; rows=[];files=[]
for group,n in [('lua',34),('sqlite',1),('musl',1336)]:
 row=[group]
 for mode in ['tier0','tier1']:
  prefix='whole-'+tag+'-'
  a,b=[r/(prefix+f'objects-{mode}-{group}-{side}.sha')for side in ['base','frontier']]
  assert a.read_bytes()==b.read_bytes() and len(a.read_text().splitlines())==n+2
  f=r/(prefix+f'compile-{mode}-{group}.log');s=f.read_text()
  assert s.rstrip().endswith('ab: done, 0 failed runs')
  pairs=[]
  for block in s.split('time-runs: done, 0 failed processes')[:-1]:
   vals={k:int(c) for k,c in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',block,re.M)}
   assert len(vals)==2 and min(vals.values())>0
   pairs.append(vals['head']/vals['base'])
  assert len(pairs)==5
  row.append(f'{100*(median(pairs)-1):+.3f}%'); files.extend((a,b,f))
 rows.append('| '+' | '.join(row)+' |')
title='## End-to-end compilation with '+{'grouped':'grouped function names','inline':'inline assembly','cast':'assembly pointer casts and parameter bounds','qualified':'pointer-returning functions and qualified bounds'}[tag]
f=d/'README.md';s=f.read_text();assert title not in s
with tarfile.open(d/('compile-'+tag+'.tar.xz'),'w:xz',preset=2)as t:
 for fn in files:t.add(fn,'native/'+fn.name)
 for n in ['ordinary-'+tag,'whole-'+tag,'record-driver.py']:t.add(p/n,'source/'+n)
 if tag!='supported':
  for n in ['restore-lua-source','lua-src-pinned.sha256']:t.add(Path('/tmp/buster-2924')/n,'source/'+n)
f.write_text(s.rstrip()+'\n\n'+title+'''

Each cell compares five paired rounds of three ordinary compiler processes on the locked 9700X. The table gives the median change in user cycles for a single-lane debug build relative to the parent. All 2,742 objects, standard output and diagnostics matched.

| Corpus | Tier 0 | Tier 1 |
| --- | ---: | ---: |
'''+'\n'.join(rows)+f'\n\n[Native compiler runs, input commands and object manifests](compile-{tag}.tar.xz)\n')
print(*rows,sep='\n')
