from pathlib import Path
import subprocess,os,hashlib
p=Path(__file__).resolve().parent
cases=sorted((p/'precise-widths').glob('*.c'))
assert len(cases)==108
data={};combined={}
for tag in ('census','precise','range'):
 f=p/('range-widths-'+tag+'.bin');f.write_bytes(b'')
 t=subprocess.run([str(p/(tag+'-columns')),'-std=gnu17','-nostdinc',*map(str,cases)],env={**os.environ,'BUSTER_DECL_TREE':str(f)},capture_output=True,check=True)
 assert not t.stderr
 data[tag]={Path(a[1]).name:tuple(map(int,a[2:])) for l in t.stdout.decode().splitlines()if (a:=l.split('\t'))[0]=='unit'}
 assert len(data[tag])==108
 combined[tag]=hashlib.sha256(f.read_bytes()).hexdigest(); print(tag,combined[tag],[(k,sum(v[2] for n,v in data[tag].items()if n.startswith(k+'-'))) for k in ['associations','selection','ordinary','qualifiers','literal','parameters']],flush=True)
assert len(set(combined.values()))==1
for name in data['census']:
 b=data['census'][name];h=data['range'][name]
 assert b[0]==h[0] and b[4:]==h[4:] and h[2]<=data['precise'][name][2]<=b[2],name
 for s in ('',):
  if name.startswith(s):assert h[2:]==(0,0,0,0),(name,h)
