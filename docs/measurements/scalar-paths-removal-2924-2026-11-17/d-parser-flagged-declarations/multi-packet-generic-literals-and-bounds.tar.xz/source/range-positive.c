#define FOUR + 1 + 1 + 1 + 1
#define SIXTEEN FOUR FOUR FOUR FOUR
#define TERMS SIXTEEN SIXTEEN SIXTEEN SIXTEEN
#define WORDS "a" "b" "c" "d"
#define STRINGS WORDS WORDS WORDS WORDS
int select_type(int x) { return _Generic(x TERMS, struct S *: 2, default: x TERMS); }
void literal(char *p) { use(&(char *){p TERMS}); use(&(char *){STRINGS STRINGS STRINGS STRINGS WORDS}); }
void bound(int a[static 1 TERMS + sizeof(int)]) {}
