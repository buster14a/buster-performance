#define FOUR + 1 + 1 + 1 + 1
#define SIXTEEN FOUR FOUR FOUR FOUR
int f(int x) { return _Generic(x SIXTEEN SIXTEEN, struct S *: 2, default: x + ); }
