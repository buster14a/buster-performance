from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
import json
p=Path(__file__).resolve().parent
def lit(name):
 return ('\n'+' '*8).join(json.dumps(line)for line in (p/name).read_text().splitlines(True))
source='''// Exercise expression carries, discarded type tokens and joined string literals across packet boundaries.
static uint32_t parse_test_check_long_declarations(const char* directory)
{
    static const char* const sources[] = {
        '''+lit('range-positive.c')+''',
        '''+lit('range-negative.c')+''',
    };
    uint32_t failures = 0;
    char path[4096];
    for (uint32_t i = 0; i < BUSTER_ARRAY_LENGTH(sources); i += 1)
    {
        snprintf(path, sizeof(path), "%s/long_declaration_%u.c", directory, i);
        const ParseTestSnippet snippet = { .source = sources[i], .error = "", .std = 0 };
        const PPOptions options = parse_test_snippet_options(&snippet);
        const ParseOptions parse_options = { 0 };
        static InternTable table;
        static Preprocessor pp;
        static Parser parser;
        bool ok = parse_test_write(path, sources[i], strlen(sources[i])) && intern_initialize(&table) && pp_initialize(&pp, &options, &table) &&
                  parse_initialize(&parser, &parse_options, options.language) && pp_run(&pp, path);
        if (ok)
        {
            parse_translation_unit(&parser, &pp);
            if (i == 0)
            {
                ok = parser.tokens.count == 653 && parser.errors == 0 && parser.fatal == PARSE_MESSAGE_NONE &&
                     parser.statistics.fallback_items == 0 && !parser.statistics.whole;
            }
            else
            {
                ok = parser.errors == 1 && parser.diagnostic_count == 1 && parser.diagnostics[0].token == 86 &&
                     parser.diagnostics[0].message == PARSE_MESSAGE_EXPECTED_EXPRESSION;
            }
        }
        if (!ok)
        {
            printf("long declaration %u failed\\n", i);
            failures += 1;
        }
        parse_release(&parser);
        pp_release(&pp);
        intern_release(&table);
        remove(path);
    }
    return failures;
}
'''
s=(p/'precise-test.c').read_text();k="// clang's recovery after a declaration";assert s.count(k)==1;s=s.replace(k,source+'\n'+k).replace('            failures += parse_test_check_resumed(directory);','            failures += parse_test_check_long_declarations(directory);\n            failures += parse_test_check_resumed(directory);')
(p/'range-test.c').write_text(s)
patch=''
for name,data in [('c_parser_impl.c',(p/'range-shipping.c').read_text()),('c_parser_test.c',s)]:
 f='src/buster/compiler/'+name;old=check_output(['git','show','cc7d4ffb4:'+f],cwd=p/'tree').decode();patch+=''.join(unified_diff(old.splitlines(True),data.splitlines(True),'a/'+f,'b/'+f))
(p/'range-compiler.patch').write_text(patch)
for name in ['build-precise','ordinary-precise','whole-precise','sources-precise']:
 s=(p/name).read_text().replace('precise','range').replace('narrow-builds-clean.ok','product-builds-clean.ok')
 if name=='build-precise':
  s=s.replace('bash "$root/verify-revised-parser" range','''cd "$root/frozen-precise"
"$lock" taskset -c 2 "$ir/src/build/parser-range" test-parser --clang "$cc" >"$root/range-verified-clang.log" 2>&1
touch "$root/range-verified-clang.ok"''')
 (p/name.replace('precise','range')).write_text(s)
d=p/'size-source/range/buster/compiler';d.mkdir(parents=True,exist_ok=True)
(d/'c_parser.c').write_bytes((p/'size-source/precise/buster/compiler/c_parser.c').read_bytes())
(d/'c_parser_impl.c').write_text((p/'range-shipping.c').read_text())
s=(p/'native-size-rows').read_text().replace('for tag in base precise;do','mkdir -p range-rows\nfor tag in base range;do').replace('base precise','base range').replace('precise base','range base').replace('"size-rows-','"range-rows/size-rows-').replace('"./size-rows-','"./range-rows/size-rows-').replace('touch size-rows.ok','touch range-rows/size-rows.ok')
(p/'native-range-rows').write_text(s)
