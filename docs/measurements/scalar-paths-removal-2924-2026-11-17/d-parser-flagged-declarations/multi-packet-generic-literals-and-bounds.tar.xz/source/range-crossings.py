from pathlib import Path
from hashlib import sha256
from collections import Counter
import subprocess,os,sys
p=Path(__file__).resolve().parent;d=p/'range-crossings';d.mkdir(exist_ok=True)
cases=set()
for n in [*range(128),189,190,191,192,193,255,256,257,511,512,1024]:
 prefix='!'*n+'x';terms='x'+'+1'*n;bound='1'+'+0'*n
 for k in ['struct S *','const struct S*','union U','enum E','T *','struct','struct *','enum 1','struct S ?']:
  for expr in [f'_Generic({prefix},{k}:{terms},default:2)', f'_Generic({prefix},default:( {k} ){terms})']:
   cases.add('typedef int T; int f(int x){return '+expr+';}\n')
 for a in [terms,terms+'+',terms+' x',terms+')',prefix+'?'+terms+':0',prefix+'?'+terms+':']:
  cases.add('int f(int x){return _Generic(x, default:'+a+');}\n')
 for s in ['"x" '*n+'"y"', '"x" '*n+'+', '"x" '*n+'0',terms,terms+'+', terms+' 3']:
  cases.add('void f(char *x){use(&(char *){'+s+'});}\n')
 for s in [bound+'+sizeof(int)',bound+'+sizeof(int)+1',bound+'+sizeof[int]',bound+'+sizeof(int)+',bound+'0 2',bound+'+']:
  cases.add('void f(int a[static '+s+']);\n')
files=[]
for i,s in enumerate(sorted(cases)):
 f=d/f'{i:05d}.c';f.write_text(s);files.append(f)
def run(tag,fs,std):
 dest=d/f'{tag}-{std}.bin';dest.write_bytes(b'')
 v=subprocess.run([str(p/(tag+'-columns')),'-std='+std,'-nostdinc',*map(str,fs)],env={**os.environ,'BUSTER_DECL_TREE':str(dest)},capture_output=True)
 assert v.returncode==0 and not v.stderr,(v.returncode,v.stderr[:240])
 rows=[tuple(map(int,z.split(b'\t')[2:])) for z in v.stdout.splitlines()if z.startswith(b'unit\t')]
 assert len(rows)==len(fs)
 return dest.read_bytes(),rows
for lang in ('gnu17','c23','c89'):
 h=sha256();saved=Counter();bad=0
 for i in range(0,len(files),48):
  fs=files[i:i+48];a,ar=run('census',fs,lang);b,br=run('range',fs,lang)
  if a!=b:
   for f in fs:
    x,_=run('census',[f],lang);y,_=run('range',[f],lang)
    if x!=y:print('mismatch',lang,f.name,f.read_text()[:900],flush=True);bad+=1
   if bad>=5:break
  for m,n in zip(ar,br,strict=True):
   assert m[0]==n[0] and m[5]==n[5] and n[2]<=m[2]
   saved['errors']+=bool(m[5]);saved['reparses_saved']+=m[2]-n[2]
  h.update(a)
 print(lang,len(files),bad,dict(saved),h.hexdigest(),flush=True)
 if bad:raise SystemExit(1)
