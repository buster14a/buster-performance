from pathlib import Path
from shutil import copytree
p=Path(__file__).resolve().parent;d=p/'range-mutant-src';copytree(p/'range-src',d,dirs_exist_ok=True)
f=d/'buster/compiler/c_parser_impl.c';s=f.read_text()
changes=[
 ('previous_value = (values & (sequence ^ (sequence >> 1))) != 0;', 'if (first + length < close && getenv("RANGE_DROP_VALUE")) previous_value = false;'),
 ('discard_to = delimiter + 1;', 'if (getenv("RANGE_DROP_TYPE") && discard_to > first + length) discard_to = first + length;'),
 ('previous_string = (strings >> (width - 1)) & 1;', 'if (first + width < close && getenv("RANGE_DROP_STRING")) previous_string = false;'),
 ('after_sizeof = (sizes >> last) & 1;', 'if (first + width < close && getenv("RANGE_DROP_SIZEOF")) after_sizeof = false;'),
 ('expect_operand = (operators >> (width - 1)) & 1;', 'if (first + width < close && getenv("RANGE_DROP_OPERATOR")) expect_operand = false;')]
for k,new in changes:
 assert s.count(k)==1,k
 s=s.replace(k,k+'\n            '+new)
f.write_text(s)
