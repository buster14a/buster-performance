from pathlib import Path
from collections import Counter
import subprocess,os
p=Path(__file__).resolve().parent;d=p/'range-fault-cases';d.mkdir(exist_ok=True)
def read(tag,files,env):
 save=d/(tag+'.bin');save.write_bytes(b'')
 t=subprocess.run([str(p/(tag+'-columns')),'-std=gnu17','-nostdinc',*map(str,files)],env={**os.environ,'BUSTER_DECL_TREE':str(save),**env},capture_output=True,check=True)
 rows={Path(a[1]).name:tuple(map(int,a[2:]))for l in t.stdout.decode().splitlines()if(a:=l.split('\t'))[0]=='unit'}
 assert len(rows)==len(files)
 return rows,save.read_bytes()
cases=[]
for n in range(26,138):
 # A run with even or odd token count moves a type or value across either side of a packet seam.
 for name,s in {
 'value':f'int f(int x){{return _Generic('+'!'*n+'x,default:'+'x+'*51+'1);}',
 'type':f'int f(int x){{return _Generic('+'!'*n+'x, const struct S *: x, default:'+'! '*68+'x);}',
 'string':'void f(){use(&(char *){'+'"x" '*n+'});}',
 'sizeof':'void f(int a[static 1'+' + 1'*n+' + sizeof(int) + 2]);',
 'shifted-sizeof':'void f(int a[static 1 + sizeof(int)'+' + 1'*n+' + sizeof(int) + 2]);',
 'operator':'void f(char *p){use(&(char *){p'+'+0'*n+'});}'
 }.items():
  f=d/f'{name}-{n}.c';f.write_text(s+'\n');cases.append(f)
for fault in ['VALUE','TYPE','STRING','SIZEOF','OPERATOR']:
 changed=[]
 for i in range(0,len(cases),60):
  fs=cases[i:i+60];ref,raw=read('range',fs,{});control,check=read('range-mutant',fs,{});assert raw==check and ref==control
  bad,mut=read('range-mutant',fs,{'RANGE_DROP_'+fault:'1'})
  changed.extend(k for k,row in ref.items() if bad[k]!=row)
 assert changed,fault
 print(fault,len(changed),changed[:4],flush=True)
