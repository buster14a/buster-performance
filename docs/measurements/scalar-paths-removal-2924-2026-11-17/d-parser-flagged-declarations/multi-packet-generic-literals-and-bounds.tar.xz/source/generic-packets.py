from pathlib import Path
from shutil import copytree
p=Path(__file__).resolve().parent
def update(s):
 a=s.index('// One builtin or visible typedef name');b=s.index('// Verify an expression-sized',a)
 s=s[:a]+'''// A builtin type, visible typedef or tagged type with an optional qualifier and pointer.
static uint32_t parse_generic_type_end(const ParseKernels* kernels, const ParseInput* input, uint32_t at, uint32_t limit)
{
    if (at < limit && kernels->vkinds[at] == PARSE_KIND_QUALIFIER &&
        (input->names[at] == C_NAME_CONST || input->names[at] == C_NAME_VOLATILE))
    {
        at += 1;
    }
    if (at >= limit)
    {
        return BUSTER_PARSE_NONE;
    }
    const uint8_t kind = kernels->vkinds[at];
    if (kind == PARSE_KIND_STRUCT || kind == PARSE_KIND_ENUM)
    {
        if (limit - at < 2 || kernels->roles[at] != PARSE_ROLE_LEAF_RIGHT || input->kinds[at + 1] != PARSE_KIND_IDENTIFIER ||
            kernels->roles[at + 1] != PARSE_ROLE_TAG)
        {
            return BUSTER_PARSE_NONE;
        }
        at += 2;
    }
    else
    {
        if ((kind != PARSE_KIND_TYPE && kind != PARSE_VKIND_TYPE_NAME) || kernels->roles[at] != PARSE_ROLE_SPECIFIER)
        {
            return BUSTER_PARSE_NONE;
        }
        at += 1;
    }
    return at + (at < limit && kernels->vkinds[at] == PARSE_KIND_STAR && kernels->roles[at] == PARSE_ROLE_PREFIX);
}

'''+s[b:]
 a=s.index('static uint32_t parse_generic_close(');b=s.index('// Each skipped flag',a)
 q=s[a:b].replace('    const uint32_t first = open + 1;','    const uint32_t start = open + 1;').replace('close <= first || close >= end || close - first > 64','close <= start || close >= end')
 x=q.index('    const uint64_t live');y=q.index('    return association &&',x)
 body=q[x:y].replace('    const uint64_t live = _bzhi_u64(UINT64_MAX, close - first);','    const uint64_t live = _bzhi_u64(UINT64_MAX, length);').replace('    uint64_t keep = live;\n    bool association = false;\n    bool seen_default = false;', '    uint64_t keep = live & ~_bzhi_u64(UINT64_MAX, discard_to > first ? discard_to - first : 0);').replace('        keep &= ~(_bzhi_u64(UINT64_MAX, delimiter - i) << (lane + 1));','''        discard_to = delimiter + 1;
        keep &= ~(_bzhi_u64(UINT64_MAX, discard_to - first) & ~_bzhi_u64(UINT64_MAX, lane + 1));''')
 body+='''    if ((all & keep) != keep || _pext_u64(left, keep) != (((values << 1) | previous_value) & sequence))
    {
        return BUSTER_PARSE_NONE;
    }
    if (sequence != 0)
    {
        previous_value = (values & (sequence ^ (sequence >> 1))) != 0;
    }
    first += length;
'''
 q=q[:x]+'''    bool association = false;
    bool seen_default = false;
    uint32_t discard_to = start;
    bool previous_value = false;
    for (uint32_t first = start; first < close;)
    {
        const uint32_t length = close - first < 64 ? close - first : 64;
'''+''.join('    '+l if l.strip() else l for l in body.splitlines(True))+'''    }
    return association && previous_value ? close : BUSTER_PARSE_NONE;
}

'''
 return (s[:a]+q+s[b:]).replace('// Verify an expression-sized generic selection against its vector roles. Remove the interiors of\n// validated casts and association type names from the packet. In the remaining token sequence an\n// operand or closing delimiter must precede each infix operator, postfix opener and closing delimiter.', '''// Validate generic selections in packets. A cast or association can span two packets, so remember
// the end of its type and whether the previous retained token finished an operand. An operand or
// closer must precede each infix operator, postfix opener and closing delimiter.''')
d=p/'packet-src';copytree(p/'precise-src',d,dirs_exist_ok=True);f=d/'buster/compiler/c_parser_impl.c';f.write_text(update((p/'precise-src/buster/compiler/c_parser_impl.c').read_text()))
(p/'packet-shipping.c').write_text(update((p/'precise-shipping.c').read_text()))
