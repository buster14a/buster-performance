from pathlib import Path
import os,sys,random,subprocess,hashlib
p=Path(__file__).parent;tag=sys.argv[1];d=p/'selection-cases';d.mkdir(exist_ok=True)
calls=['x','0','1','"s"',"'q'",'a[x]','&a[x+1]','-x','x + y * 4','0 ? (x) : (void *)1','0 ? (&a[x]) : (const T *)1',
       '(const char *)(fn(x,1))','fn(x,a[y+1],2)','(T*)x','fn()','x ? y : z ? y : x','(x, y)','*fn(*p,v)','x++',
       '','+','x y','x +','x + +','x ? y','x : y','x ? : y','x,,x','x ]','fn(,x)','fn(x,)','fn(x y)','a[]','a[x,]',
       'x;','return x','default','(T) (int)','(const T**)x','(void *)(p,)','(x+1)(p)','_Generic(x,int:1)','[]','(x)(y)','0 ? (x) : (void *+)1']
keys=['int','const void *','T','volatile T *','default','const int','unsigned long','void *','long *','int *','const','default default','default *','foo bar','T x','x','1','struct S','_Atomic(T)','int (*)(int)','int int','static int','int +', '']
forms=['int f(void){return G;}','int f(int x){if(G) return 1;return 0;}','int f(int x){int y=G;return y;}','int f(int x){x=G;return x;}','int f(int x){if(G && x) return x;}','T v = G;','int f(int x){if(0) x=G; else return 0;}','int f(){return G G;}','int f(){int a[sizeof(G)];}','int f(){return G + ;}','int f(){return G xyz;}','int f(){x y = G;}','int f(){switch(x){case G:break;default:break;}return 0;}','int f(){x=G, y=2;}','int f(){return g(G + 1);}']
g=lambda control,key,val,rest:'_Generic('+control+','+key+':'+val+rest+')'
sels=set()
for x in calls:
 for key in keys:
  sels.add(g(x,key,'fn(x,2)',',default:(const char*)(ptr)'));sels.add(g('x',key,x,',default:2'));sels.add(g('x','T','1',','+key+':'+x))
for v in calls:
 for w in calls[::4]:sels.add(g('0 ? (x):(void*)1','const void *',v,',default:'+w))
for bad in ['_Generic()','_Generic(x)','_Generic(x,)','_Generic(x,default:)','_Generic(x,int:1,)','_Generic(x int:1)','_Generic(x,int 1)','_Generic(x,default:1,default:2)','_Generic(x,int:1,int:2)','_Generic(x, const void:1,T:2)','_Generic(x,default?x:y)','_Generic(x,(int):2)','_Generic(x,default:( y ? 2:3), T:1)','_Generic(x?y,z:t,default:1)','_Generic(x, default:x ?: 1)','_Generic(x, int:2, y:z)','_Generic(x, int:1, _Generic(y,int:2):3)','_Generic(x, default:(x+1)],y)','_Generic(x, int: ({ default: break; }),default:2)']:sels.add(bad)
rnd=random.Random(2924)
for _ in range(3800):
 c=g(rnd.choice(calls[:15]),rnd.choice(keys[:10]),rnd.choice(calls[:19]),',default:'+rnd.choice(calls[:19]))
 off=rnd.randrange(len(c));sels.add(c[:off]+rnd.choice(['',']','(','const','default',':',',',';','?','&','[','return','int','1'])+c[min(off+rnd.randrange(3),len(c)):])
sources=set()
for i,sel in enumerate(sorted(sels)):
 for form in [*forms[:3],forms[(i+3)%len(forms)]]:sources.add('typedef int T; '+form.replace('G',sel)+'\n')
paths=[]
for i,s in enumerate(sorted(sources)):
 q=d/f'{i:05d}.c'
 if not q.exists():q.write_text(s)
 paths.append(q)
def run(binary,ps,std):
 out=p/f'selection-{tag}-{binary}-output.bin';out.write_bytes(b'')
 cmd=subprocess.run([str(p/(binary+'-columns')),'-std='+std,'-nostdinc',*map(str,ps)],env={**os.environ,'BUSTER_DECL_TREE':str(out)},capture_output=True,check=True)
 rows=[tuple(map(int,row.split(b'\t')[2:]))for row in cmd.stdout.splitlines()if row.startswith(b'unit\t')];assert len(rows)==len(ps)
 return out.read_bytes(),rows
for dialect in sys.argv[2:] or ['gnu17','c11','c17','gnu11','c23','gnu23','c99','c89']:
 bad=[];saved=0;h=hashlib.sha256()
 for i in range(0,len(paths),64):
  ps=paths[i:i+64];a,ar=run('qualified',ps,dialect);b,br=run(tag,ps,dialect)
  if a!=b:
   for f in ps:
    ca,x=run('qualified',[f],dialect);cb,y=run(tag,[f],dialect)
    if ca!=cb:
     bad.append(f);print('DIFFERENCE',dialect,f.name,f.read_text().strip(),x[0],y[0],flush=True)
   if len(bad)>=25:break
  saved+=sum(x[2]-y[2]for x,y in zip(ar,br));h.update(a)
 print(dialect,len(paths),len(bad),saved,h.hexdigest(),flush=True)
 if bad:raise SystemExit(1)
