from pathlib import Path
from hashlib import sha256
import re,tarfile
p=Path(__file__).resolve().parent
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-flagged-declarations')
ranges=p/'range-source-trees'
logs=[p/(n+'.log')for n in ['range-verified-clang','range-crossings','range-boundaries','range-selections','range-widths','range-faults']]
for f in [*logs[:1]]:
 s=f.read_text()
 assert 'snippets: 561, 0 failures (with clang)'in s and 'fixtures: 16 trees checked by hand, 0 failures'in s and 'test-parser: passed'in s
assert all(re.match(r'^\w+ 5004 0 .*2779.*2225',l)for l in logs[1].read_text().splitlines())and len(logs[1].read_text().splitlines())==3
assert len(logs[2].read_text().splitlines())==3 and all(' 14742 0 14735 7 'in s for s in logs[2].read_text().splitlines())
assert len(logs[3].read_text().splitlines())==8 and all(' 28870 0 'in s for s in logs[3].read_text().splitlines())
assert len(logs[5].read_text().splitlines())==5 and all(int(s.split()[1])>0 for s in logs[5].read_text().splitlines())
widths=[p/f'range-widths-{t}.bin' for t in ('census','precise','range')]
assert len({sha256(f.read_bytes()).hexdigest()for f in widths})==1
t=logs[4].read_text();assert all(n in t for n in ["('associations', 544)","('selection', 224)","('literal', 192)"])
assert sum(map(int,re.findall(r", (\d+)\)",t.splitlines()[-1])))==0
for g,n in [('lua',34),('sqlite',1),('musl',1336)]:
 assert (ranges/f'cast-{g}.sha').read_bytes()==(ranges/f'range-{g}.sha').read_bytes()==(p/f'precise-source-trees/precise-{g}.sha').read_bytes()
 units=(ranges/f'range-{g}.tsv').read_text().splitlines();assert len(units)==n and all(all(int(v)==0 for v in l.split('\t')[3:])for l in units)
 logs.append(p/f'range-{g}-corpus.log')
archive='multi-packet-generic-literals-and-bounds.tar.xz';title='## Generic selections, pointer literals and minimum array bounds across packets'
doc=out/'README.md';assert title not in doc.read_text()
names=['generic-packets.py','literal-packets.py','native-ranges.py','range-compiler.patch','range-positive.c','range-negative.c','build-range','all-columns.c','range-crossings.py','range-boundaries.py','selection-cases.py','range-faults.py','check-range-faults.py','check-range-widths.py','local-range-corpus.py','record-ranges.py','native-range-rows']
with tarfile.open(out/archive,'w:xz',preset=2) as a:
 for n in names:a.add(p/n,'source/'+n)
 for f in logs:a.add(f,'results/'+f.name)
 a.add(widths[-1],'results/identical-complete-size-trees.bin')
 for f in sorted(ranges.glob('*')):
  if f.is_file() and f.suffix in ['.tsv','.sha']:a.add(f,'results/corpora/'+f.name)
 a.add(p/'frozen-precise/tests/parser-kernels/digests.tsv','results/frozen/digests.tsv')
with doc.open('a') as f:
 f.write('\n'+title+'''

At `1c111388e` the recognizers carry expression state across 64-token packets. Tagged `struct`, `union` and `enum` types can appear in associations and casts. A type beginning in one packet and ending in the next is removed from the expression masks at both ends. The pointer initializer carries the preceding string or operator. Minimum bounds track numbers and the stages of `sizeof(type)` across packet boundaries.

The previous revision reparsed 544 tagged-association declarations, 224 long generic expressions and 192 long pointer literals across the 108 sizes. This revision reparsed zero declarations in all six families. Their parser outputs were byte-identical to the original compiler. The 1,371 source files also retained their complete trees and diagnostics with zero fallback declarations and whole units.

The frozen native parser suite passed against Clang, including 561 snippets and 35,904 alignments. A permanent 653-token fixture exercises all three recognizers and a malformed 89-token expression requires the original diagnostic at token 86. An additional 5,004 generated sources crossed packet boundaries in valid and malformed expressions under three language modes. Each had 2,779 rejected sources, and 2,225 fewer declarations needed scalar reparsing. All diagnostic and tree streams matched. The 28,870 generic variants under eight language modes and 14,742 boundary/context cases under three modes also retained their outputs. Five independent mutations discarded the previous value, a spanning type, a string, a `sizeof` opener or an operator at a packet boundary. Each broke the expected routing on a fixed witness.

[Production changes, raw size trees, corpus manifests, fixtures and mutant results](multi-packet-generic-literals-and-bounds.tar.xz)
''')
