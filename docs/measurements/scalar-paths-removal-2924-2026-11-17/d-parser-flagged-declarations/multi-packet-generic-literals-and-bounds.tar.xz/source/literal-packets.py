from pathlib import Path
from shutil import copytree
p=Path(__file__).resolve().parent
def change(s):
 a=s.index('static bool parse_addressed_pointer_literal');b=s.index('// A builtin type',a)
 q=s[a:b].replace(' || close - body - 1 > 64','')
 aa=q.index('    const uint64_t live =');bb=q.index('    return (operands | joined',aa)
 core=q[aa:bb].replace('close - body - 1','width').replace(' + body + 1',' + first').replace('(strings << 1)','((strings << 1) | previous_string)')
 core+='''    if ((operands | joined | operators) != live || operands != (((operators << 1) | expect_operand) & live) ||
        operators != ((((operands | joined) << 1) | !expect_operand) & live & ~joined))
    {
        return false;
    }
    previous_string = (strings >> (width - 1)) & 1;
    expect_operand = (operators >> (width - 1)) & 1;
    first += width;
'''
 q=q[:aa]+'''    bool previous_string = false;
    bool expect_operand = true;
    for (uint32_t first = body + 1; first < close;)
    {
        const uint32_t width = close - first < 64 ? close - first : 64;
'''+''.join('    '+l if l.strip()else l for l in core.splitlines(True))+'''    }
    return !expect_operand;
}

'''
 s=s[:a]+q+s[b:]
 a=s.index('static bool parse_resolved_parameter_bound');b=s.index('// K6 flags the closing parenthesis',a)
 q=s[a:b].replace(' || close - token - 1 > 64','')
 aa=q.index('    const uint32_t first = token + 1;');bb=q.index('    return (numbers & 1)',aa)
 core=q[q.index('    const uint64_t live',aa):bb].replace('close - first);','width);')
 core+='''    if ((numbers | sizes | opens | types | closes | binary) != live ||
        opens != (((sizes << 1) | after_sizeof) & live) || types != (((opens << 1) | after_open) & live) ||
        closes != (((types << 1) | after_type) & live) || binary != ((((numbers | closes) << 1) | after_value) & live) ||
        (numbers | sizes) != (((binary << 1) | expect_operand) & live))
    {
        return false;
    }
    const uint32_t last = width - 1;
    after_sizeof = (sizes >> last) & 1;
    after_open = (opens >> last) & 1;
    after_type = (types >> last) & 1;
    after_value = ((numbers | closes) >> last) & 1;
    expect_operand = (binary >> last) & 1;
    first += width;
'''
 q=q[:aa]+'''    if (kernels->vkinds[token + 1] != PARSE_KIND_NUMBER)
    {
        return false;
    }
    bool after_sizeof = false;
    bool after_open = false;
    bool after_type = false;
    bool after_value = false;
    bool expect_operand = true;
    for (uint32_t first = token + 1; first < close;)
    {
        const uint32_t width = close - first < 64 ? close - first : 64;
'''+''.join('    '+l if l.strip()else l for l in core.splitlines(True))+'''    }
    return after_value;
}

'''
 return s[:a]+q+s[b:]
d=p/'range-src';copytree(p/'packet-src',d,dirs_exist_ok=True);f=d/'buster/compiler/c_parser_impl.c';f.write_text(change((p/'packet-src/buster/compiler/c_parser_impl.c').read_text()))
(p/'range-shipping.c').write_text(change((p/'packet-shipping.c').read_text()))
