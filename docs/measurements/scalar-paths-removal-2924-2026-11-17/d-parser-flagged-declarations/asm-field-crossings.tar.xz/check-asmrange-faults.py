from pathlib import Path
import subprocess,os
p=Path(__file__).resolve().parent;d=p/'asmrange-fault-cases';d.mkdir(exist_ok=True)
files=[]
for n in range(1,138):
 # The missing comma lands at different packet positions. A validator that restarts
 # the operand grammar in every packet accepts it when the next constraint lands at lane zero.
 u='"r"(x)';deref='"m"(*p)'
 shapes={'cast':'"" :: "m"(*(void *'+('volatile * '*n)+')p)','separator':'"" :: '+','.join([u]*(n+1)),'clobber':'"" ::: '+','.join(['"cc"']*n)}
 for m in range(6):
  ops=[u]*(n-1)+[deref]*m
  if ops:shapes['missing-'+str(m)]='"" :: '+','.join(ops)+' '+u
 for key,t in shapes.items():
  f=d/f'{key}-{n:03d}.c';f.write_text('void f(int x, void *p){__asm__ volatile('+t+');}\n');files.append(f)
def run(tag,fs,env):
 v=d/(tag+'.bin');v.write_bytes(b'')
 x=subprocess.run([str(p/(tag+'-columns')),'-std=gnu17','-nostdinc',*map(str,fs)],env={**os.environ,'BUSTER_DECL_TREE':str(v),**env},capture_output=True,check=True)
 rows={Path(a[1]).name:tuple(map(int,a[2:]))for l in x.stdout.decode().splitlines()if(a:=l.split('\t'))[0]=='unit'};assert len(rows)==len(fs)
 return rows,v.read_bytes()
for k in ['DROP_CAST','DROP_SEPARATOR','OPEN_PACKET','DROP_CLOBBER']:
 differences=[]
 for off in range(0,len(files),50):
  fs=files[off:off+50];r,a=run('asmrange',fs,{});c,b=run('asmrange-mutant',fs,{});assert a==b and r==c
  m,t=run('asmrange-mutant',fs,{'ASM_'+k:'1'});differences.extend(s for s in r if r[s]!=m[s])
 assert differences,k
 print(k,len(differences),differences[:4],flush=True)
