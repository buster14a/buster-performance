    // The first field is the string template. The next two are outputs and inputs, and the
    // last holds clobbers. A fourth colon introduces asm-goto labels.
    uint32_t starts[4] = { open + 1 };
    uint32_t fields = 1;
    for (uint32_t first = open + 1; first < close;)
    {
        const uint32_t width = close - first < 64 ? close - first : 64;
        const __mmask64 live = _bzhi_u64(UINT64_MAX, width);
        const __m512i kinds = _mm512_maskz_loadu_epi8(live, kernels->vkinds + first);
        uint64_t colons = parse_equal8(kinds, PARSE_KIND_COLON) & live;
        while (colons != 0)
        {
            if (fields == BUSTER_ARRAY_LENGTH(starts))
            {
                return BUSTER_PARSE_NONE;
            }
            starts[fields++] = first + (uint32_t)__builtin_ctzll(colons) + 1;
            colons &= colons - 1;
        }
        first += width;
    }
    for (uint32_t field = 0; field < fields; field += 1)
    {
        const uint32_t begin = starts[field];
        const uint32_t stop = field + 1 < fields ? starts[field + 1] - 1 : close;
        if (field == 1 || field == 2)
        {
            if (!parse_asm_operands(kernels->vkinds, begin, stop))
            {
                return BUSTER_PARSE_NONE;
            }
            continue;
        }
        if (field == 3 && stop != begin && (stop - begin) % 2 == 0)
        {
            return BUSTER_PARSE_NONE;
        }
        for (uint32_t first = begin; first < stop;)
        {
            const uint32_t width = stop - first < 64 ? stop - first : 64;
            const __mmask64 live = _bzhi_u64(UINT64_MAX, width);
            const __m512i kinds = _mm512_maskz_loadu_epi8(live, kernels->vkinds + first);
            const uint64_t strings = field == 0 ? live : live & UINT64_C(0x5555555555555555);
            if ((parse_equal8(kinds, PARSE_KIND_STRING) & live) != strings || (parse_equal8(kinds, PARSE_KIND_COMMA) & live) != (live ^ strings))
            {
                return BUSTER_PARSE_NONE;
            }
            first += width;
        }
    }
