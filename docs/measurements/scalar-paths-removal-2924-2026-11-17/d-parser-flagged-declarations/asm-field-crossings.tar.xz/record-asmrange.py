from pathlib import Path
import tarfile,re,hashlib,struct
p=Path(__file__).resolve().parent
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-flagged-declarations')
headings=['## Inline assembly fields across packet boundaries','## Per-size cost of parsing multi-packet assembly']
def correctness():
    archive='asm-field-crossings.tar.xz'
    files=[p/n for n in ['asmrange-compiler.patch','asm-range.py','asm-range-operands.inc','asm-range-fields.inc','asmrange-crossings.py','asmrange-crossings.log','asmrange-faults.py','check-asmrange-faults.py','asmrange-faults.log','local-asmrange-corpus.py','native-asmrange.py','build-asmrange','asmrange-positive.c','asmrange-negative.c','asmrange-verified-clang.log','record-asmrange.py']]
    t=(p/'asmrange-verified-clang.log').read_text()
    assert '561' in t and '100000' in t and '35904' in t
    for x in ['DROP_CAST 137','DROP_SEPARATOR 137','OPEN_PACKET 13','DROP_CLOBBER 137']:assert x in (p/'asmrange-faults.log').read_text()
    for g,num in [('lua',34),('sqlite',1),('musl',1336)]:
        d=p/'asmrange-source-trees'
        a=(d/f'range-{g}.sha').read_bytes();assert a==(d/f'asmrange-{g}.sha').read_bytes()
        for tag in ['range','asmrange']:
            f=d/f'{tag}-{g}.tsv';lines=f.read_text().splitlines();assert len(lines)==num and all(row.split('\t')[-4:]==['0']*4 for row in lines)
            files.extend([d/f'{tag}-{g}.sha',f])
    for case,header in [('positive',(0,454,0,0,0)),('negative',(0,455,1,0,1))]:
        f=p/f'asmrange-{case}-asmrange.tree';b=f.read_bytes();assert b==(p/f'asmrange-{case}-range.tree').read_bytes() and struct.unpack_from('<5I',b)==header;files.append(f)
    t=(p/'asmrange-crossings.log').read_text()
    assert all(re.search(rf'^{lang} 5724 0 .*?\x27fewer_reparses\x27: 1612',t,re.M)for lang in ('gnu17','c23','c89'))
    doc=out/'README.md';assert headings[0] not in doc.read_text()
    with tarfile.open(out/archive,'w:xz',preset=2)as a:
        for f in files:a.add(f,str(f.relative_to(p)))
    with doc.open('a')as f:f.write('\n'+headings[0]+'''

The candidate checks inline-assembly templates, output and input operands, pointer casts and clobbers across packet boundaries. An operand’s predecessor distinguishes an outer dereference from stars inside a type name. The validator checks the complete operand and its separator even when those tokens occupy different 64-token packets.

Each of 5,724 independently generated files ran under GNU17, C23 and C89. Complete parse results, diagnostics, tree columns and traversal matched the preceding parser. In each dialect 1,612 declarations no longer required reparsing. The cases included 3,566 rejected inputs under GNU17 and C23 and 3,555 under C89. All 1,371 Lua, SQLite and musl inputs kept the same result and zero fallback declarations. The normal native parser suite passed its Clang-backed checks.

The permanent 454-token fixture spans the template, output operands, input pointer cast and clobbers. One inserted number in the pointer cast produced one expected-right-parenthesis diagnostic at token 318, as on the parent. Four deliberate faults were detected. Thirteen malformed cases exposed a dropped separator when a new packet began. The three remaining faults each changed 137 cases.

[Complete results, pinned input trees, native test log and candidate source]('''+archive+')\n')
if __name__=='__main__':correctness()
