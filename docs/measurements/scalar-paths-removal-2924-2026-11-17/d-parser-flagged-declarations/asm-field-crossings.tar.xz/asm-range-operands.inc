// Validate complete constraint operands across packet boundaries. The three tokens before a
// lane distinguish the outer dereference from a star inside a pointer cast. Every accepted
// token must have an allowed predecessor, including the comma separating two operands.
static bool parse_asm_operands(const uint8_t* kinds, uint32_t begin, uint32_t end)
{
    if (begin == end)
    {
        return true;
    }
    if (end - begin < 4 || kinds[begin] != PARSE_KIND_STRING || kinds[end - 2] != PARSE_KIND_IDENTIFIER || kinds[end - 1] != PARSE_KIND_R_PAREN)
    {
        return false;
    }
    for (uint32_t first = begin; first < end;)
    {
        const uint32_t width = end - first < 64 ? end - first : 64;
        const __mmask64 live = _bzhi_u64(UINT64_MAX, width);
        const __m512i now = _mm512_maskz_loadu_epi8(live, kinds + first);
        const __m512i one = _mm512_maskz_loadu_epi8(live, kinds + first - 1);
        const __m512i two = _mm512_maskz_loadu_epi8(live, kinds + first - 2);
        const __m512i three = _mm512_maskz_loadu_epi8(live, kinds + first - 3);
        const uint64_t after_string = parse_equal8(one, PARSE_KIND_STRING);
        const uint64_t after_open = parse_equal8(one, PARSE_KIND_L_PAREN);
        const uint64_t after_star = parse_equal8(one, PARSE_KIND_STAR);
        const uint64_t after_qualifier = parse_equal8(one, PARSE_KIND_QUALIFIER);
        const uint64_t after_close = parse_equal8(one, PARSE_KIND_R_PAREN);
        const uint64_t after_operand_open = after_open & parse_equal8(two, PARSE_KIND_STRING);
        const uint64_t after_deref = after_star & parse_equal8(two, PARSE_KIND_L_PAREN) & parse_equal8(three, PARSE_KIND_STRING);
        const uint64_t after_pointer = (after_star & ~after_deref) | after_qualifier;
        const uint64_t after_cast_open = after_open & parse_equal8(two, PARSE_KIND_STAR);
        const uint64_t after_cast = after_close & (parse_equal8(two, PARSE_KIND_STAR) | parse_equal8(two, PARSE_KIND_QUALIFIER));
        const uint64_t after_operand = after_close & parse_equal8(two, PARSE_KIND_IDENTIFIER);
        const uint64_t valid = (parse_equal8(now, PARSE_KIND_STRING) & (parse_equal8(one, PARSE_KIND_COMMA) | (uint64_t)(first == begin))) |
                               (parse_equal8(now, PARSE_KIND_L_PAREN) & (after_string | after_deref)) |
                               (parse_equal8(now, PARSE_KIND_STAR) & (after_operand_open | parse_equal8(one, PARSE_KIND_TYPE) | after_pointer)) |
                               (parse_equal8(now, PARSE_KIND_IDENTIFIER) & (after_operand_open | after_deref | after_cast)) |
                               (parse_equal8(now, PARSE_KIND_TYPE) & after_cast_open) |
                               (parse_equal8(now, PARSE_KIND_QUALIFIER) & after_pointer) |
                               (parse_equal8(now, PARSE_KIND_R_PAREN) & (parse_equal8(one, PARSE_KIND_IDENTIFIER) | after_pointer)) |
                               (parse_equal8(now, PARSE_KIND_COMMA) & after_operand);
        if ((valid & live) != live)
        {
            return false;
        }
        first += width;
    }
    return true;
}
