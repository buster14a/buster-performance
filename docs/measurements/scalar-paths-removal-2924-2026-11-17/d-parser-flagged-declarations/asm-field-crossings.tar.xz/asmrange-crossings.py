from pathlib import Path
from hashlib import sha256
from collections import Counter
import subprocess,os,random
p=Path(__file__).resolve().parent;d=p/'asmrange-crossings';d.mkdir(exist_ok=True)
cases=set()
def unit(t):
 return 'void f(void *p, int x){__asm__ volatile('+t+');}\n'
def op(i):return ['"r"(x)','"m"(*p)','"m"(*(void *volatile *)p)'][i%3]
def fields(n):
 return ','.join(op(i) for i in range(n))
for n in [*range(140),189,190,191,192,193,255,256,257,511]:
 tpl='"a" '*n+'"b"'
 for suffix in ('',':', '::',':::', ':::"cc","memory"','::',' : '+fields(1)):
  cases.add(unit(tpl+suffix))
 ops=fields(n);clobbers=','.join(['"cc"']*n)
 cases.update(unit(t)for t in [f'"" : {ops} : {ops} : {clobbers}',f'"" :: {ops}',f'"" ::: {clobbers}',f'"" :: {ops},',f'"" ::: {clobbers},',
    f'"" ::: {clobbers} "m"', f'{tpl} 1 :',f'"" :: "m"(*(void *'+('const * '*n)+')p)',f'"" :: "m"(*(void '+('const '*n)+')p)'])
rng=random.Random(20813)
for i in range(3500):
 ts=['""',':',':']
 for j in range(rng.randrange(1,22)):
  if j:ts.append(',')
  ts+=rng.choice([['"r"','(','x',')'],['"m"','(','*','p',')'],['"m"','(','*','(','void','*','volatile','*',')','p',')']])
 if i%2==0:ts+=[':', '"cc"',',','"memory"']
 j=rng.randrange(len(ts));ts[j:j+rng.randrange(0,4)]=rng.choices(['""',',',':','p','(',')','*','volatile','int','1',';','[',']'],k=rng.randrange(0,4))
 cases.add(unit(' '.join(ts)))
files=[]
for i,s in enumerate(sorted(cases)):
 f=d/f'{i:05d}.c';f.write_text(s);files.append(f)
def run(tag,fs,lang):
 dst=d/(tag+'-'+lang+'.bin');dst.write_bytes(b'')
 v=subprocess.run([str(p/(tag+'-columns')),'-std='+lang,'-nostdinc',*map(str,fs)],capture_output=True,env={**os.environ,'BUSTER_DECL_TREE':str(dst)})
 assert v.returncode==0 and not v.stderr,(v.returncode,v.stderr[:400])
 rows=[tuple(map(int,line.split(b'\t')[2:]))for line in v.stdout.splitlines()if line.startswith(b'unit\t')];assert len(rows)==len(fs)
 return dst.read_bytes(),rows
for lang in ('gnu17','c23','c89'):
 h=sha256();counts=Counter();bad=0
 for i in range(0,len(files),64):
  fs=files[i:i+64];a,ar=run('range',fs,lang);b,br=run('asmrange',fs,lang)
  if a!=b:
   for f in fs:
    x,xr=run('range',[f],lang);y,yr=run('asmrange',[f],lang)
    if x!=y:
     print('mismatch',lang,f.name,f.read_text()[:160],xr,yr,flush=True);bad+=1
     if bad>=5:raise SystemExit(1)
  for m,n in zip(ar,br,strict=True):
   assert m[0]==n[0] and m[5]==n[5] and n[2]<=m[2],(m,n)
   counts['errors']+=bool(m[5]);counts['fewer_reparses']+=m[2]-n[2]
  h.update(a)
 print(lang,len(files),bad,dict(counts),h.hexdigest(),flush=True)
 if bad:raise SystemExit(1)
