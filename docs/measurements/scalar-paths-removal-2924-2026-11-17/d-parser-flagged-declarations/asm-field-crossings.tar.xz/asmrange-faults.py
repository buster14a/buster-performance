from pathlib import Path
from shutil import copytree
p=Path(__file__).resolve().parent;d=p/'asmrange-mutant-src';copytree(p/'asmrange-src',d,dirs_exist_ok=True)
f=d/'buster/compiler/c_parser_impl.c';s=f.read_text()
for old,new in [
 ('const uint64_t after_cast_open = after_open & parse_equal8(two, PARSE_KIND_STAR);','const uint64_t after_cast_open = getenv("ASM_DROP_CAST") ? 0 : after_open & parse_equal8(two, PARSE_KIND_STAR);'),
 ('const uint64_t after_operand = after_close & parse_equal8(two, PARSE_KIND_IDENTIFIER);','const uint64_t after_operand = getenv("ASM_DROP_SEPARATOR") ? 0 : after_close & parse_equal8(two, PARSE_KIND_IDENTIFIER);'),
 ('(uint64_t)(first == begin)','(uint64_t)(first == begin || getenv("ASM_OPEN_PACKET"))'),
 ('(width - 1))','unused')]:
 if old=='(width - 1))':continue
 if old.startswith('(uint64_t)'):
  a=s.index('static bool parse_asm_operands(');b=s.index('\n}',a);section=s[a:b];assert section.count(old)==1;s=s[:a]+section.replace(old,new)+s[b:]
 else:assert s.count(old)==1;s=s.replace(old,new)
old='if (fields == BUSTER_ARRAY_LENGTH(starts))';assert s.count(old)==1;s=s.replace(old,'if (fields == BUSTER_ARRAY_LENGTH(starts) || (getenv("ASM_DROP_CLOBBER") && fields == 3))')
f.write_text(s)
