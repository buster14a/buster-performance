from pathlib import Path
from shutil import copytree
p=Path(__file__).resolve().parent
def generate(text):
 a=text.index('// A comma-separated list of string constraints');b=text.index('static uint32_t parse_inline_asm_close',a)
 text=text[:a]+(p/'asm-range-operands.inc').read_text()+'\n// The end of an inline assembly statement whose fields and tree the kernels resolved.\n'+text[b:]
 assert text.count(' || close - open > 65')==1;text=text.replace(' || close - open > 65','')
 a=text.index('    const uint32_t length = close - open - 1;',a);b=text.index('    return close;\n}',a)
 return text[:a]+(p/'asm-range-fields.inc').read_text()+text[b:]
copytree(p/'range-src',p/'asmrange-src',dirs_exist_ok=True)
f=p/'asmrange-src/buster/compiler/c_parser_impl.c';f.write_text(generate(f.read_text()))
(p/'asmrange-shipping.c').write_text(generate((p/'range-shipping.c').read_text()))
