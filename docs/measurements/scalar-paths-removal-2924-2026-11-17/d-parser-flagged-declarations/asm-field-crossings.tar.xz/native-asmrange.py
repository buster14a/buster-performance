from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
import json,re
p=Path(__file__).resolve().parent
s=(p/'range-test.c').read_text()
a=s.index('static uint32_t parse_test_check_long_declarations');b=s.index('    uint32_t failures = 0;',a)
left=s[:b].rstrip();at=left.rindex('    };');decl=left[:at]
for key in ['positive','negative']:
    source=(p/f'asmrange-{key}.c').read_text()
    # Split C literals at token boundaries to keep the permanent regression readable.
    chunks=re.findall(r'.{1,106}(?:\s+|$)|\S+\s*',source)
    assert ''.join(chunks)==source
    decl+='        '+ ('\n        '.join(json.dumps(c) for c in chunks)) + ',\n'
s=decl+'    };\n'+s[b:]
a=s.index('            else\n',s.index('parser.tokens.count == 653'));b=s.index('\n        }\n',a)
old=s[a:b]
messages=re.findall(r'X\((\w+),', (p/'tree/src/buster/compiler/c_parser.c').read_text().split('#define BUSTER_PARSE_MESSAGES(X)')[1].split('\n\n')[0])
reason=messages[20];print('expected diagnostic',reason)
s=s[:a]+old.replace('            else\n','            else if (i == 1)\n',1)+'''
            else if (i == 2)
            {
                ok = parser.tokens.count == 454 && parser.errors == 0 && parser.fatal == PARSE_MESSAGE_NONE &&
                     parser.statistics.fallback_items == 0 && !parser.statistics.whole;
            }
            else
            {
                ok = parser.errors == 1 && parser.diagnostic_count == 1 && parser.diagnostics[0].token == 318 &&
                     parser.diagnostics[0].message == PARSE_MESSAGE_'''+reason+''';
            }'''+s[b:]
(p/'asmrange-test.c').write_text(s)
patch=''
for n,content in [('c_parser_impl.c',(p/'asmrange-shipping.c').read_text()),('c_parser_test.c',s)]:
    path='src/buster/compiler/'+n
    base=check_output(['git','show','cc7d4ffb4:'+path],cwd=p/'tree').decode()
    patch+=''.join(unified_diff(base.splitlines(True),content.splitlines(True),'a/'+path,'b/'+path))
(p/'asmrange-compiler.patch').write_text(patch)
for n in ['build-range','ordinary-range','whole-range','sources-range']:
    s=(p/n).read_text().replace('range','asmrange').replace('/dev/shm/buster-burs-rules-6b097f86/product-builds-clean.ok','/dev/shm/buster-recovery-views-6b097f86/vector-repair-builds-clean.ok')
    (p/n.replace('range','asmrange')).write_text(s)
d=p/'size-source/asmrange/buster/compiler';d.mkdir(parents=True,exist_ok=True)
(d/'c_parser.c').write_bytes((p/'size-source/range/buster/compiler/c_parser.c').read_bytes());(d/'c_parser_impl.c').write_bytes((p/'asmrange-shipping.c').read_bytes())
d=p/'asmrange-widths';d.mkdir(exist_ok=True)
for n in [1,2,3,4,7,8,9,15,16,17,31,32,33,63,64,65,127,128,129]:
 for group,source in {
   'templates':'"a" '*n,
   'outputs':'"" : '+', '.join('"r"(x)'for _ in range(n)),
   'inputs':'"" :: '+', '.join('"m"(*(void *volatile *)p)'for _ in range(n)),
   'cast':'"" :: "m"(*(void *'+('const * '*n)+')p)',
   'clobbers':'"" ::: '+','.join('"cc"'for _ in range(n)),
 }.items():
    (d/f'{group}-{n:04d}.c').write_text('void f(int x, void *p){__asm__ volatile('+source+');}\n')
s=(p/'native-range-rows').read_text().replace('range-rows','asmrange-rows').replace('base range','base asmrange').replace('range base','asmrange base').replace('precise-widths/*.c','precise-widths/*.c asmrange-widths/*.c').replace('= 108','= 203').replace('108 declaration and expression sizes','203 declaration, expression and inline assembly sizes')
(p/'native-asmrange-rows').write_text(s)
