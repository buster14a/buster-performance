from pathlib import Path
from statistics import median
import tarfile,re
p=Path(__file__).resolve().parent;ns={'__file__':str(p/'record-size-rows.py')};exec((p/'record-size-rows.py').read_text().split("if __name__=='__main__'")[0],ns)
ns['r']=r=p/'range-rows-native'
vals=ns['table']('range',[1,2,3]);rows=[];families=[]
for fam in ns['shapes']:
 xs=[vals[fam,n][1]for n in ns['sizes']];families.append(f'| {fam} | {sum(x<=1 for x in xs)}/18 | {min(xs):.4f} | {median(xs):.4f} | {max(xs):.4f} |')
 for n in ns['sizes']:
  data=vals[fam,n];rows.append(f'| {fam} | {n} | {data[0]:,} | {data[1]:.4f} | {data[2]:.4f} |')
assert all(x[1]<=1 for x in vals.values())
for round in (1,2,3):
 s=(r/f'size-rows-range-{round}.log').read_text()
 items=re.findall(r'^precise-widths/[a-z]+-\d+\.c: \d+ tokens; the fallback took (\d+) top-level declarations, (\d+) tokens',s,re.M)
 assert len(items)==108 and all(x==('0','0')for x in items)
doc=ns['out']/'README.md';title='## Native cycles for multi-packet declarations';assert title not in doc.read_text()
archive='multi-packet-parser-sizes.tar.xz'
with tarfile.open(doc.parent/archive,'w:xz',preset=2)as a:
 for n in ('native-range-rows','record-range-sizes.py','record-size-rows.py','parser-size-rows.c','precise-widths','size-source/base','size-source/range'):a.add(p/n,'source/'+n)
 for impl in ('base','range'):
  for i in (1,2,3):a.add(r/f'size-rows-{impl}-{i}.log',f'native/size-rows-{impl}-{i}.log')
with doc.open('a')as f:
 f.write('\n'+title+'''

The multi-packet parser at `1c111388e` met all 108 size comparisons against `cc7d4ffb4` on the 9700X. Both sides ran alternately in three paired rounds with 21 parser samples per input per round. Each candidate file reported zero fallback declarations and tokens. These figures measure the complete vector parser after preprocessing. All ratios divide candidate cycles per token by parent cycles per token.

| Family | Sizes at parity or faster | Minimum ratio | Median ratio | Maximum ratio |
| --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(families)+'''

| Family | Size | Tokens | Core cycles/token ratio | Instructions/token ratio |
| --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+'\n\n[All native samples and the exact source and inputs](multi-packet-parser-sizes.tar.xz)\n')
print(*families,sep='\n')
