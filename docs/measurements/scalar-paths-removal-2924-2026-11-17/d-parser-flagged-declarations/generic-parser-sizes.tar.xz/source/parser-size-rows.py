from pathlib import Path
from subprocess import check_output
p=Path(__file__).resolve().parent
def old(name): return check_output(['git','show','cc7d4ffb4:src/buster/compiler/'+name],cwd=p/'tree')
s=old('c_parser_benchmark.c').decode()
a='            parse_benchmark_time(&bench, passes, only, repeat, set);'
assert s.count(a)==1
s=s.replace(a,'''            ParseBenchmarkFile* files = bench.files;
            const uint32_t count = bench.file_count;
            const uint64_t total = bench.token_count;
            bench.file_count = 1;
            for (uint32_t f = 0; f < count; ++f)
            {
                bench.files = files + f;
                bench.token_count = bench.files->parser.tokens.count;
                printf("input-size %s\\n", bench.files->path);
                parse_benchmark_time(&bench, passes, only, repeat, set);
            }
            bench.files = files;
            bench.file_count = count;
            bench.token_count = total;''')
(p/'parser-size-rows.c').write_text(s+'\nint main(int argc, char** argv) { return run_parser_benchmark(argc, argv); }\n')
for tag in ('base','precise'):
 d=p/'size-source'/tag/'buster/compiler';d.mkdir(parents=True,exist_ok=True)
 (d/'c_parser.c').write_bytes(old('c_parser.c'))
 (d/'c_parser_impl.c').write_bytes(old('c_parser_impl.c') if tag=='base' else (p/'precise-shipping.c').read_bytes())
