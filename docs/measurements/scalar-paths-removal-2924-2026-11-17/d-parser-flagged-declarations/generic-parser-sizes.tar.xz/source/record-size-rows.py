from pathlib import Path
from statistics import median
import re,sys,tarfile
p=Path(__file__).resolve().parent;r=p/'rows-native'
sizes=[0,1,2,3,4,7,8,9,15,16,17,31,32,33,63,64,65,127]
shapes=['associations','selection','ordinary','qualifiers','literal','parameters']
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-flagged-declarations')
def parse(f):
 data={}
 for shape,n,tokens,cycles,inst in re.findall(r'^input-size precise-widths/([a-z]+)-(\d+)\.c\n21 interleaved passes over 1 files, (\d+) tokens,[^\n]*\n  vector\s+[\d.]+ ms\s+[\d.]+ ns/token\s+([\d.]+) cycles/token \[[^\]]+\]\s+([\d.]+) instructions/token',f.read_text(),re.M):
  k=shape,int(n);assert k not in data
  data[k]=(int(tokens),float(cycles),float(inst))
 assert set(data)=={(t,n)for t in shapes for n in sizes}
 return data
def table(tag,rounds):
 base=[parse(r/f'size-rows-base-{i}.log')for i in rounds]
 head=[parse(r/f'size-rows-{tag}-{i}.log')for i in rounds]
 vals={}
 for t in shapes:
  for n in sizes:
   k=t,n;ts={d[k][0]for d in base+head};assert len(ts)==1
   vals[k]=[ts.pop()]+[median(h[k][j]/b[k][j]for b,h in zip(base,head))for j in (1,2)]
 return vals
if __name__=='__main__':
 tag=sys.argv[1] if len(sys.argv)>1 else 'precise'
 rounds=[1,2,3]if len(sys.argv)<3 else list(map(int,sys.argv[2:]))
 vals=table(tag,rounds)
 for t in shapes:
  vs=[vals[t,n][1]for n in sizes]
  print(t,sum(x<=1 for x in vs),len(vs),round(min(vs),4),round(median(vs),4),round(max(vs),4),[(n,round(vals[t,n][1],3)) for n in sizes if vals[t,n][1]>1])
 if len(rounds)!=3 or tag!='precise': sys.exit(0)
 rows=['| '+t+' | '+str(n)+' | '+str(vals[t,n][0])+' | '+f'{vals[t,n][1]:.4f} | {vals[t,n][2]:.4f} |'for t in shapes for n in sizes]
 passed=sum(v[1]<=1 for v in vals.values())
 report=out/'README.md';heading='## Parser cycles for each declaration and expression size';assert heading not in report.read_text()
 with tarfile.open(out/'generic-parser-sizes.tar.xz','w:xz',preset=2)as a:
  for name in ('native-size-rows','record-size-rows.py','parser-size-rows.py','parser-size-rows.c','precise-widths','size-source/base','size-source/precise'):a.add(p/name,'source/'+name)
  for tag in ('base','precise'):
   for i in rounds:a.add(r/f'size-rows-{tag}-{i}.log',f'native/size-rows-{tag}-{i}.log')
 route_counts={}
 for impl in ('base','precise'):
  logs=[(r/f'size-rows-{impl}-{i}.log').read_text()for i in rounds]
  counters=[{(shape,int(n)):int(items)for shape,n,items in re.findall(r'^precise-widths/([a-z]+)-(\d+)\.c: \d+ tokens; the fallback took (\d+) top-level declarations',l,re.M)}for l in logs]
  assert len(counters[0])==108 and counters[0]==counters[1]==counters[2]
  route_counts[impl]=counters[0]
 routing=['| '+shape+' | '+' | '.join(str(sum(route_counts[impl][shape,n] for n in sizes))for impl in ('base','precise'))+' |'for shape in shapes]
 with report.open('a')as f:
  f.write('\n'+heading+f'''

The parent (`cc7d4ffb4`) and parser draft (`f6af8f9cf`) compiled with the same Zen 5 release options. The driver preprocesses all 108 inputs, then calls the production vector parser benchmark separately for each file, keeping its timing region and hardware counters intact. Each input contains 32 declarations. Size counts array parameters, pointer expressions, generic associations or terms according to the workload. The ratios divide the candidate by its paired parent, taking the median of three rounds and 21 parsing samples per input in each round. Lower is faster. The candidate matched or improved {passed} of 108 sizes in core cycles per token.

| Family | Size | Tokens | Core cycles/token ratio | Instructions/token ratio |
| --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'\n\nThe inputs contain 576 declarations per family. Some measurements still include scalar reparsing. The counts below sum the 18 distinct sizes once.\n\n| Family | Parent reparses | Draft reparses |\n| --- | ---: | ---: |\n'+'\n'.join(routing)+'\n\n[Source, input generator outputs and all native measurements](generic-parser-sizes.tar.xz)\n')
