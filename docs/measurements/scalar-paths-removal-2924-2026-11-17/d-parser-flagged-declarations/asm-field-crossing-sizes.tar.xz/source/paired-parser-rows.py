from pathlib import Path
from statistics import median
import re,sys
def compare(rounds):
    sides=[]
    for pair in rounds:
        both=[]
        for path in pair:
            text=Path(path).read_text()
            vals={}
            for directory,shape,n,tokens,cycles,instr in re.findall(r'^input-size ([\w-]+)/([a-z]+)-(\d+)\.c\n21 interleaved passes over 1 files, (\d+) tokens,[^\n]*\n  vector\s+[\d.]+ ms\s+[\d.]+ ns/token\s+([\d.]+) cycles/token \[[^\]]+\]\s+([\d.]+) instructions/token',text,re.M):
                key=(directory,shape,int(n))
                assert key not in vals
                vals[key]=(int(tokens),float(cycles),float(instr))
            assert vals
            both.append(vals)
        sides.append(both)
    keys=sides[0][0].keys()
    assert all(v.keys()==keys for pair in sides for v in pair)
    rows={}
    for key in sorted(keys):
        counts={v[key][0] for pair in sides for v in pair}
        assert len(counts)==1
        rows[key]=(counts.pop(),*[median(b[key][i]/a[key][i] for a,b in sides)for i in (1,2)])
    return rows
def summarize(rows):
    groups=sorted(set((a,b)for a,b,c in rows))
    for directory,shape in groups:
        subset={n:row for (d,s,n),row in rows.items()if (d,s)==(directory,shape)}
        ratios=[r[1]for r in subset.values()]
        print(shape,sum(r<=1 for r in ratios),len(ratios),round(min(ratios),3),round(median(ratios),3),round(max(ratios),3),[(n,round(r[1],3))for n,r in subset.items()if r[1]>1][:6])
if __name__=='__main__':
    args=sys.argv[1:]
    summarize(compare(list(zip(args[::2],args[1::2],strict=True))))
