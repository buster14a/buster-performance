void f(int x, void *p){__asm__ volatile("" : "r"(x), "r"(x), "r"(x), "r"(x), "r"(x), "r"(x), "r"(x), "r"(x), "r"(x));}
