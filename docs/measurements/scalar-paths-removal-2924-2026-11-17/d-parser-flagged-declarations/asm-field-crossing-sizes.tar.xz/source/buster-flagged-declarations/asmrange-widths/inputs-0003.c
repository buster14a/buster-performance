void f(int x, void *p){__asm__ volatile("" :: "m"(*(void *volatile *)p), "m"(*(void *volatile *)p), "m"(*(void *volatile *)p));}
