void f(int x, void *p){__asm__ volatile("a" "a" "a" "a" "a" "a" "a" "a" );}
