void f(int x, void *p){__asm__ volatile("" ::: "cc","cc","cc","cc","cc","cc","cc");}
