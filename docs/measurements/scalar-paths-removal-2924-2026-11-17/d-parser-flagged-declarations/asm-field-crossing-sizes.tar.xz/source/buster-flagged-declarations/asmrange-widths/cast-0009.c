void f(int x, void *p){__asm__ volatile("" :: "m"(*(void *const * const * const * const * const * const * const * const * const * )p));}
