import runpy,tarfile,re,sys
from statistics import median
from pathlib import Path
p=Path(__file__).resolve().parent
work=p/'asmrange-rows-native'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-flagged-declarations')
def run(revision):
    paired=runpy.run_path(str(p.parent/'paired-parser-rows.py'))
    rounds=[[work/f'size-rows-{tag}-{n}.log'for tag in ('base','asmrange')]for n in (1,2,3)]
    rows=paired['compare'](rounds)
    assert len(rows)==203 and all(r[1]<=1 for r in rows.values())
    for _,head in rounds:
        routes=re.findall(r'^(?:asmrange|precise)-widths/[a-z]+-\d+\.c: \d+ tokens; the fallback took (\d+) top-level declarations, (\d+) tokens',head.read_text(),re.M)
        assert len(routes)==len(rows) and set(routes)=={('0','0')}
    summary=[];detail=[]
    for group in sorted({k[1]for k in rows}):
        xs=[r[1]for k,r in rows.items()if k[1]==group]
        summary.append(f'| {group} | {len(xs)} | {min(xs):.4f} | {median(xs):.4f} | {max(xs):.4f} |')
    for (_,group,size),(tokens,cycles,instr)in rows.items():
        detail.append(f'| {group} | {size} | {tokens:,} | {cycles:.4f} | {instr:.4f} |')
    doc=out/'README.md';title='## Per-size cost of parsing multi-packet assembly'
    assert title not in doc.read_text()
    archive='asm-field-crossing-sizes.tar.xz'
    with tarfile.open(out/archive,'w:xz',preset=2)as a:
        for pair in rounds:
            for f in pair:a.add(f,'native/'+f.name)
        a.add(p.parent/'paired-parser-rows.py','source/paired-parser-rows.py')
        for name in ('record-asmrange-sizes.py','native-asmrange-rows','parser-size-rows.c','precise-widths','asmrange-widths','size-source/base','size-source/asmrange'):
            a.add(p/name,'source/buster-flagged-declarations/'+name)
    with doc.open('a') as f:
        f.write('\n'+title+f'\n\nCompiler `{revision[:9]}` matched or improved every one of the 203 native comparisons against `cc7d4ffb4`. The 95 assembly inputs varied template strings, output and input operands, cast qualifiers and clobbers from 1 to 129 elements. The other 108 inputs cover declarations and expressions. Every candidate input reported zero reparsed declarations and tokens. Ratios divide candidate by parent. The table uses the median paired ratio over three rounds of 21 parser samples per file under the 9700X lock.\n\n| Input family | Sizes | Minimum cycles/token ratio | Median ratio | Maximum ratio |\n| --- | ---: | ---: | ---: | ---: |\n'+'\n'.join(summary)+'\n\n| Input family | Size | Tokens | Core cycles/token ratio | Instructions/token ratio |\n| --- | ---: | ---: | ---: | ---: |\n'+'\n'.join(detail)+f'\n\n[Native counters, input files and benchmark sources]({archive})\n')
    print(*summary,sep='\n')
if __name__=='__main__':run(sys.argv[1])
