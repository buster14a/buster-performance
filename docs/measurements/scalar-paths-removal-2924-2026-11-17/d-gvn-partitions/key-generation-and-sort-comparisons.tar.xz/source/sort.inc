// Merge a run up to the other run's next key. Hash equality requires the complete GVN key.
static uint32_t ir_gvn_run_prefix(const IrGvnWork* work, const uint32_t* rows, uint64_t count,
                                  uint32_t limit, bool equal_first, bool initial)
{
    const __mmask8 live = count >= 8 ? UINT8_MAX : (__mmask8)((1u << count) - 1);
    const __m256i positions = _mm256_maskz_loadu_epi32(live, rows);
    const __m512i keys = _mm512_mask_i64gather_epi64(_mm512_setzero_si512(), live,
        _mm512_cvtepu32_epi64(positions), work->hashes, 8);
    const __m512i pivot = _mm512_set1_epi64(work->hashes[limit]);
    uint32_t taken = (uint32_t)__builtin_popcount(_mm512_mask_cmplt_epu64_mask(live, keys, pivot));
    const __mmask8 ties = _mm512_mask_cmpeq_epi64_mask(live, keys, pivot);
    const uint32_t stop = taken + (uint32_t)__builtin_popcount(ties);
    while (taken < stop)
    {
        const uint32_t pos = rows[taken];
        const int cmp = ir_gvn_compare(work, pos, limit, work->members[pos], work->members[limit], initial);
        if (cmp > 0 || (!equal_first && cmp == 0)) break;
        taken += 1;
    }
    return taken;
}

static uint32_t ir_gvn_partition_runs(IrGvnWork* work, uint32_t count, bool initial, uint32_t base)
{
    const uint32_t* members = work->members;
    // Rank each row in its packet. Equal full keys retain their input order.
    const __m256i offsets = _mm256_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7);
    for (uint64_t first = 0; first < count; first += 8)
    {
        const uint32_t size = count - first < 8 ? count - first : 8;
        const __mmask8 live = (__mmask8)((1u << size) - 1);
        const __m512i hashes = _mm512_maskz_loadu_epi64(live, work->hashes + first);
        const __m256i positions = _mm256_add_epi32(offsets, _mm256_set1_epi32((uint32_t)first));
        __m256i ranks = _mm256_setzero_si256();
        for (uint32_t slot = 0; slot < size; slot += 1)
        {
            const uint32_t pivot = (uint32_t)first + slot;
            const __m512i h = _mm512_set1_epi64(work->hashes[pivot]);
            __mmask8 after = _mm512_mask_cmpgt_epu64_mask(live, hashes, h);
            uint32_t ties = _mm512_mask_cmpeq_epi64_mask(live, hashes, h) & ~(1u << slot);
            while (ties != 0)
            {
                const uint32_t lane = (uint32_t)__builtin_ctz(ties);
                const uint32_t other = (uint32_t)first + lane;
                const int cmp = ir_gvn_compare(work, other, pivot, members[other], members[pivot], initial);
                after |= (uint32_t)(cmp > 0 || (cmp == 0 && lane > slot)) << lane;
                ties &= ties - 1;
            }
            ranks = _mm256_mask_sub_epi32(ranks, after, ranks, _mm256_set1_epi32(-1));
        }
        _mm256_mask_i32scatter_epi32(work->order + first, live, ranks, positions, 4);
    }
    for (uint64_t width = 8; width < count; width *= 2)
    {
        for (uint64_t first = 0; first < count; first += 2 * width)
        {
            const uint64_t middle = first + width < count ? first + width : count;
            const uint64_t end = middle + width < count ? middle + width : count;
            uint64_t left = first, right = middle, out = first;
            while (left < middle && right < end)
            {
                const uint32_t a = work->order[left], b = work->order[right];
                const bool from_left = ir_gvn_compare(work, a, b, members[a], members[b], initial) <= 0;
                uint64_t* cursor = from_left ? &left : &right;
                const uint32_t amount = ir_gvn_run_prefix(work, work->order + *cursor, (from_left ? middle : end) - *cursor,
                                                          from_left ? b : a, from_left, initial);
                const __mmask8 live = (__mmask8)((1u << amount) - 1);
                _mm256_mask_storeu_epi32(work->temporary_order + out, live, _mm256_maskz_loadu_epi32(live, work->order + *cursor));
                *cursor += amount;
                out += amount;
            }
            const uint64_t rest = left < middle ? left : right;
            memcpy(work->temporary_order + out, work->order + rest, (end - out) * sizeof(uint32_t));
        }
        uint32_t* swap = work->order;
        work->order = work->temporary_order;
        work->temporary_order = swap;
    }
    uint32_t classes = 0;
    for (uint32_t position = 0; position < count; position += 1)
    {
        const uint32_t current = work->order[position];
        if (position == 0 || ir_gvn_compare(work, work->order[position - 1], current, members[work->order[position - 1]], members[current], initial) != 0)
            classes += 1;
        work->next_classes[current] = base + classes;
    }
    return classes;
}
