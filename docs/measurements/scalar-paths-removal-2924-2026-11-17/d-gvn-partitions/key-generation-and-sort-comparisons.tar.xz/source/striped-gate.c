#include "buster/compiler/main_unit_backend.c"
#include "fixed-keys.inc"
#include "striped-keys.inc"
enum { MAX_ROWS=2048, MAX_EDGES=16, SHAPES=12, METHODS=3 };
static uint32_t state=1;
static uint32_t draw(void){state=state*1664525+1013904223;return state;}
static uint64_t tick(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int compare_time(const void*a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return(x>y)-(x<y);}
typedef uint32_t Method(IrGvnWork*,uint32_t,bool,bool,uint32_t);
static Method*volatile methods[]={ir_gvn_partition,fixed_ir_gvn_partition,striped_ir_gvn_partition};
int main(int argc,char**argv){
    if(argc!=2)return 2;state=strtoul(argv[1],NULL,10);
    static uint32_t a[MAX_ROWS*2],b[MAX_ROWS*2],c[MAX_ROWS*2],alias[MAX_ROWS*2],classes[MAX_ROWS*2],block[MAX_ROWS*2],
        order[MAX_ROWS],tmp[MAX_ROWS],next[MAX_ROWS],members[MAX_ROWS],offsets[2],pred[MAX_EDGES],edges[MAX_ROWS*MAX_EDGES*2];
    static uint8_t op[MAX_ROWS*2],types[MAX_ROWS*2],flags[MAX_ROWS*2],alignment[MAX_ROWS*2],pure[MAX_ROWS*2];
    static uint32_t expected[MAX_ROWS],emitted[MAX_ROWS+1],reverse[MAX_ROWS+1];static uint64_t hashes[MAX_ROWS],fields[2*MAX_ROWS*8];
    static IrSimdValue vectors[MAX_ROWS];IrFunction f={.op=op,.type=types,.flags=flags,.alignment_log2=alignment,.a=a,.b=b,.c=c,.extra=edges,.vector_constants=vectors};
    IrGvnWork w={.ir.function=&f,.members=members,.pure=pure,.alias=alias,.classes=classes,.hashes=hashes,.fields=fields,.next_classes=next,.probes=BUSTER_IR_GVN_PROBES_PER_INSTRUCTION};
    w.ir.cfg.instruction_blocks=block;w.ir.cfg.predecessor_offsets=offsets;w.ir.cfg.predecessors=pred;
    uint32_t sizes[100],nw=0;for(unsigned n=0;n<=65;n++)sizes[nw++]=n;
    unsigned more[]={79,80,81,95,96,97,127,128,129,191,192,193,255,256,257,511,512,513,1024,2048};
    for(unsigned j=0;j<sizeof(more)/sizeof(*more);j++)sizes[nw++]=more[j];
    for(unsigned k=0;k<nw;k++)for(unsigned shape=0;shape<SHAPES;shape++){
        unsigned n=sizes[k];f.instruction_count=2*n;const unsigned ec=shape==5||shape==9?16:2;
        offsets[1]=ec;for(unsigned j=0;j<ec;j++)pred[j]=903+7*j;
        const bool rel=shape>=8,init=shape==3;w.relative_keys=rel;
        for(unsigned i=0;i<2*n;i++){alias[i]=i;classes[i]=i<n?1u:i-n+1u;pure[i]=1;}
        for(unsigned i=0;i<n;i++){
            unsigned group=draw()%n;members[i]=n-1-i;
            const bool vector=shape==1||shape==2||shape==3||(shape==7&&i%4==0);
            const bool phi=shape==4||shape==5||shape==6||shape==9||shape==10||(shape==7&&i%4==2);
            if(vector){
                op[i]=IR_VCONST;a[i]=i;b[i]=0;
                for(unsigned j=0;j<8;j++)vectors[i].words[j]=0;
                vectors[i].words[7]=group;if(shape==1)vectors[i].words[0]=group;
                expected[i]=group+1;
            }else if(phi){
                op[i]=IR_PHI;a[i]=2*ec*i;b[i]=ec;
                unsigned offset=shape==6||shape==10||shape==7?draw()%ec:0;
                for(unsigned e=0;e<ec;e++){unsigned pos=(e+offset)%ec;
                    edges[a[i]+2*pos]=pred[e];edges[a[i]+2*pos+1]=n+(e?((group+e)%n):group);}
                expected[i]=group+1;
            }else{
                op[i]=IR_ADD;a[i]=n+group;b[i]=n+group;c[i]=0;expected[i]=group+1;
            }
            if(shape==7)expected[i]=3*group+(vector?1:phi?2:3);
        }
        for(unsigned sorted=0;sorted<2;sorted++){
            uint64_t times[METHODS][5];unsigned reps=64/(1+n/4)+1;
            for(unsigned r=0;r<5;r++)for(unsigned z=0;z<METHODS;z++){
                unsigned m=(r+z)%METHODS;uint64_t begin=tick();uint32_t count=0;
                for(unsigned rep=0;rep<reps;rep++){
                    for(unsigned i=0;i<n;i++)classes[i]=1;
                    w.order=order;w.temporary_order=tmp;count=methods[m](&w,n,init,sorted,0);
                }
                times[m][r]=tick()-begin;
                // Canonical output IDs are arbitrary. Verify both directions against the generated equivalence.
                memset(emitted,0,(n+1)*4);static uint32_t canonical[3*MAX_ROWS+1];
                memset(canonical,0,(3*n+1)*4);memset(reverse,0,(n+1)*4);unsigned distinct=0;
                for(unsigned i=0;i<n;i++){
                    unsigned e=expected[i],v=classes[i];if(!v||v>n)return 2;
                    if(!canonical[e]){canonical[e]=v;distinct++;}if(!reverse[v])reverse[v]=e;
                    if(canonical[e]!=v||reverse[v]!=e)return fprintf(stderr,"equivalence failure %u %u %u %u row %u\n",n,shape,sorted,m,i),1;
                }
                if(distinct!=count)return fprintf(stderr,"class count %u %u\n",n,shape),1;
            }
            printf("%u %u %u %u",n,shape,sorted,reps);
            for(unsigned m=0;m<METHODS;m++){qsort(times[m],5,8,compare_time);printf(" %llu",(unsigned long long)times[m][2]);}puts("");
        }
    }
    fprintf(stderr,"verified %u lengths, %u layouts, and sorted and bounded-probe partitions\n",nw,SHAPES);
}
