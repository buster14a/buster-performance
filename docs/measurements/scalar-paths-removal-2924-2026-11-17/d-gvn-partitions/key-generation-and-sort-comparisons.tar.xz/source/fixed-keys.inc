static uint32_t fixed_ir_gvn_phi_class(const IrGvnWork* work, uint32_t instruction, uint32_t predecessor, uint32_t position)
{
    const IrFunction* f = work->ir.function;
    const uint32_t* inputs = f->extra + f->a[instruction];
    if (inputs[(uint64_t)position * 2] != predecessor)
    {
        const uint32_t count = f->b[instruction];
        const __m256i wanted = _mm256_set1_epi32((int)predecessor);
        for (uint64_t at = 0; at < count; at += 8)
        {
            const uint32_t left = count - (uint32_t)at;
            const __mmask8 live = left >= 8 ? UINT8_MAX : (__mmask8)((1u << left) - 1);
            const __m512i edges = _mm512_maskz_loadu_epi64(live, inputs + 2 * at);
            const __mmask8 found = _mm256_mask_cmpeq_epi32_mask(live, _mm512_cvtepi64_epi32(edges), wanted);
            if (found != 0)
            {
                position = (uint32_t)at + (uint32_t)__builtin_ctz((unsigned)found);
                break;
            }
        }
    }
    return work->classes[work->alias[inputs[(uint64_t)position * 2 + 1]]];
}

// The static key words beside the opcode, type, flags and alignment. The acyclic numbering and the refinement rounds
// both read them here, so the two cannot disagree on which instructions are alike.
static IrGvnPayload fixed_ir_gvn_payload(const IrGvnWork* work, uint32_t i)
{
    const IrFunction* f = work->ir.function;
    const uint32_t op = f->op[i];
    IrGvnPayload payload = { 0 };
    if (op == IR_CONST)
    {
        payload.low = f->constants[f->a[i]].low;
        payload.high = f->constants[f->a[i]].high;
    }
    else if (op == IR_VCONST)
    {
        // Refinement hashes the first two words. Its comparator checks the other six together on a match.
        payload.low = f->vector_constants[f->a[i]].words[0];
        payload.high = f->vector_constants[f->a[i]].words[1];
    }
    else if (op == IR_PARAM || op == IR_STACK_ADDR || op == IR_SYMBOL_ADDR)
    {
        payload.low = f->a[i];
    }
    else if (op == IR_ICMP || op == IR_VCMP)
    {
        payload.low = f->c[i];
    }
    else if (op == IR_INTRINSIC)
    {
        // Its kind: a ternary kind's `c` also holds its third operand's place, which is no part of its value.
        payload.low = ir_intrinsic_kind(f->c[i]);
    }
    else if (op == IR_ADDRESS)
    {
        payload.low = (uint64_t)f->addresses[f->c[i]].offset;
        payload.high = f->addresses[f->c[i]].scale | ((uint64_t)(f->b[i] == BUSTER_IR_NONE) << 8);
    }
    else if (op == IR_PHI)
    {
        payload.low = work->ir.cfg.instruction_blocks[i];
        payload.high = f->b[i];
    }
    return payload;
}

static uint64_t fixed_ir_gvn_meta(const IrFunction* f, uint32_t i)
{
    return f->op[i] | ((uint64_t)f->type[i] << 8) | ((uint64_t)f->flags[i] << 16) | ((uint64_t)f->alignment_log2[i] << 24);
}

// Writes instruction i's key at position in the field columns.
static void fixed_ir_gvn_key(IrGvnWork* work, uint32_t position, uint32_t i, bool initial)
{
    const IrFunction* f = work->ir.function;
    const uint64_t n = f->instruction_count;
    const uint32_t mask = ir_value_mask3(f, i);
    const IrGvnPayload payload = fixed_ir_gvn_payload(work, i);
    work->fields[position] = fixed_ir_gvn_meta(f, i);
    work->fields[n + position] = !initial ? work->classes[i] : 0;
    work->fields[n * 2 + position] = payload.low;
    work->fields[n * 3 + position] = payload.high;
    work->fields[n * 4 + position] = !initial && (mask & 1) != 0 ? work->classes[ir_gvn_resolve(work->alias, f->a[i])] : 0;
    work->fields[n * 5 + position] = !initial && (mask & 2) != 0 ? work->classes[ir_gvn_resolve(work->alias, f->b[i])] : 0;
    work->fields[n * 6 + position] = !initial && (mask & 4) != 0 ? work->classes[ir_gvn_resolve(work->alias, ir_value_third(f, i))] : 0;
    work->fields[n * 7 + position] = work->pure[i] == 0 ? (uint64_t)i + 1 : 0;
}

// The previous partition already distinguishes every static field, including all vector-constant words.
// A later round can only split a parent by the classes of its direct operands or its phi inputs.
static void fixed_ir_gvn_relative_keys(IrGvnWork* work, uint32_t count)
{
    const IrFunction* f = work->ir.function;
    const uint32_t n = f->instruction_count;
    const __m512i multiplier = _mm512_set1_epi64(BUSTER_IR_GVN_HASH_MULTIPLIER);
    for (uint64_t first = 0; first < count; first += 8)
    {
        const uint32_t amount = count - first < 8 ? count - first : 8;
        const __mmask8 live = (__mmask8)_bzhi_u32(255, amount);
        for (uint32_t lane = 0; lane < amount; lane += 1)
        {
            const uint32_t j = (uint32_t)first + lane;
            const uint32_t i = work->members[j];
            const uint32_t mask = ir_value_mask3(f, i);
            const uint64_t a = (mask & 1) != 0 ? work->classes[work->alias[f->a[i]]] : 0;
            const uint64_t b = (mask & 2) != 0 ? work->classes[work->alias[f->b[i]]] : 0;
            const uint64_t c = (mask & 4) != 0 ? work->classes[work->alias[ir_value_third(f, i)]] : 0;
            work->fields[j] = work->classes[i] | c << 32;
            work->fields[(uint64_t)n + j] = a | b << 32;
        }
        const __m512i parents = _mm512_maskz_loadu_epi64(live, work->fields + first);
        const __m512i pairs = _mm512_maskz_loadu_epi64(live, work->fields + n + first);
        const __m512i prefix = _mm512_mullo_epi64(_mm512_xor_si512(_mm512_set1_epi64(BUSTER_IR_GVN_HASH_BASIS), parents), multiplier);
        _mm512_mask_storeu_epi64(work->hashes + first, live, _mm512_mullo_epi64(_mm512_xor_si512(prefix, pairs), multiplier));
    }
}

// Hash the fixed key columns of the first count members. Equality below also checks every phi input and vector word.
static void fixed_ir_gvn_keys(IrGvnWork* work, uint32_t count, bool initial)
{
    const uint64_t n = work->ir.function->instruction_count;
    for (uint32_t position = 0; position < count; position += 1)
    {
        fixed_ir_gvn_key(work, position, work->members[position], initial);
    }
    for (uint64_t first = 0; first < count; first += BUSTER_IR_OPTIMIZE_BATCH)
    {
        const uint32_t batch = count - first < BUSTER_IR_OPTIMIZE_BATCH ? count - first : BUSTER_IR_OPTIMIZE_BATCH;
        for (uint32_t half = 0; half < batch; half += 8)
        {
            const uint32_t amount = batch - half < 8 ? batch - half : 8;
            const __mmask8 valid = (UINT32_C(1) << amount) - 1;
            __m512i hash = _mm512_set1_epi64(BUSTER_IR_GVN_HASH_BASIS);
            for (uint32_t field = 0; field < BUSTER_IR_GVN_FIELDS; field += 1)
            {
                const __m512i key = _mm512_maskz_loadu_epi64(valid, work->fields + (uint64_t)field * n + first + half);
                hash = _mm512_mullo_epi64(_mm512_xor_si512(hash, key), _mm512_set1_epi64(BUSTER_IR_GVN_HASH_MULTIPLIER));
            }
            _mm512_mask_storeu_epi64(work->hashes + first + half, valid, hash);
        }
    }
}

// Compares the keys at positions a and b, of instructions ia and ib.
static int fixed_ir_gvn_compare(const IrGvnWork* work, uint32_t a, uint32_t b, uint32_t ia, uint32_t ib, bool initial)
{
    int result = work->hashes[a] < work->hashes[b] ? -1 : work->hashes[a] != work->hashes[b];
    const IrFunction* f = work->ir.function;
    const uint32_t fields = work->relative_keys ? 2 : BUSTER_IR_GVN_FIELDS;
    for (uint32_t field = 0; result == 0 && field < fields; field += 1)
    {
        const uint64_t left = work->fields[(uint64_t)field * f->instruction_count + a];
        const uint64_t right = work->fields[(uint64_t)field * f->instruction_count + b];
        result = left < right ? -1 : left != right;
    }
    if (result == 0 && !work->relative_keys && f->op[ia] == IR_VCONST)
    {
        const uint64_t* const left = f->vector_constants[f->a[ia]].words;
        const uint64_t* const right = f->vector_constants[f->a[ib]].words;
        const __mmask8 different = _mm512_mask_cmpneq_epi64_mask(0xfc, _mm512_loadu_si512(left), _mm512_loadu_si512(right));
        if (different != 0)
        {
            const uint32_t word = (uint32_t)__builtin_ctz((unsigned)different);
            result = left[word] < right[word] ? -1 : 1;
        }
    }
    if (result == 0 && !initial && f->op[ia] == IR_PHI && work->pure[ia] != 0)
    {
        const uint32_t block = work->ir.cfg.instruction_blocks[ia];
        for (uint32_t edge = work->ir.cfg.predecessor_offsets[block]; result == 0 && edge < work->ir.cfg.predecessor_offsets[(uint64_t)block + 1]; edge += 1)
        {
            const uint32_t predecessor = work->ir.cfg.predecessors[edge];
            const uint32_t left = fixed_ir_gvn_phi_class(work, ia, predecessor, edge - work->ir.cfg.predecessor_offsets[block]);
            const uint32_t right = fixed_ir_gvn_phi_class(work, ib, predecessor, edge - work->ir.cfg.predecessor_offsets[block]);
            result = left < right ? -1 : left != right;
        }
    }
    return result;
}

// The independent comparison-sort completion also bounds adversarial hash-table work. Neither grouping path
// mutates the old classes: parent-class keys remain immutable until the complete partition is published.
static uint32_t fixed_ir_gvn_partition_sorted(IrGvnWork* work, uint32_t count, bool initial, uint32_t base)
{
    const uint32_t* members = work->members;
    for (uint32_t position = 0; position < count; position += 1)
    {
        work->order[position] = position;
    }
    for (uint64_t width = 1; width < count; width *= 2)
    {
        for (uint64_t first = 0; first < count; first += width * 2)
        {
            const uint64_t middle = first + width < count ? first + width : count;
            const uint64_t end = middle + width < count ? middle + width : count;
            uint64_t left = first;
            uint64_t right = middle;
            for (uint64_t out = first; out < end; out += 1)
            {
                const bool take_left = left < middle && (right == end || fixed_ir_gvn_compare(work, work->order[left], work->order[right], members[work->order[left]], members[work->order[right]], initial) <= 0);
                work->temporary_order[out] = take_left ? work->order[left++] : work->order[right++];
            }
        }
        uint32_t* swap = work->order;
        work->order = work->temporary_order;
        work->temporary_order = swap;
    }
    uint32_t classes = 0;
    for (uint32_t position = 0; position < count; position += 1)
    {
        const uint32_t current = work->order[position];
        if (position == 0 || fixed_ir_gvn_compare(work, work->order[position - 1], current, members[work->order[position - 1]], members[current], initial) != 0)
        {
            classes += 1;
        }
        work->next_classes[current] = base + classes;
    }
    return classes;
}

// Reuse the sort's two n-element u32 columns as bucket heads and representative links. The largest power of two
// not exceeding count needs no extra allocation or padding. Only representatives enter a chain, so a wide duplicate
// class costs one comparison per member, not a growing chain. Full keys (including ordered phi inputs) decide
// equality; the folded hash selects a bucket only. Class IDs need not follow key order, only the same equivalence.
// They run from base + 1, so they never collide with the classes the acyclic numbering already published.
//
// Stop after a linear probe budget and restart the unchanged comparison sort on the already materialized keys.
// This bounds a hostile all-collision round by O(n log n) key comparisons instead of quadratic probing. The table
// probes use scalar indexed loads, not gathers; the preceding eight-lane SIMD key hashing stays unchanged.
static uint32_t fixed_ir_gvn_partition_group(IrGvnWork* work, uint32_t count, bool initial, bool sorted, uint32_t base)
{
    const uint32_t* members = work->members;
    uint32_t classes = 0;
    if (!sorted && count != 0)
    {
        uint32_t buckets = 1;
        while (buckets <= count / 2)
        {
            buckets *= 2;
        }
        memset(work->temporary_order, 0xff, (uint64_t)buckets * sizeof(uint32_t));
        const uint64_t budget = (uint64_t)count * work->probes;
        uint64_t probes = 0;
        for (uint32_t position = 0; position < count && !sorted; position += 1)
        {
            const uint64_t hash = work->hashes[position];
            const uint32_t bucket = (hash ^ (hash >> 32)) & (buckets - 1);
            uint32_t match = work->temporary_order[bucket];
            bool equal = false;
            while (match != BUSTER_IR_NONE && !equal && probes < budget)
            {
                probes += 1;
                equal = fixed_ir_gvn_compare(work, position, match, members[position], members[match], initial) == 0;
                if (!equal)
                {
                    match = work->order[match];
                }
            }
            sorted = match != BUSTER_IR_NONE && !equal;
            if (!sorted)
            {
                if (match == BUSTER_IR_NONE)
                {
                    work->order[position] = work->temporary_order[bucket];
                    work->temporary_order[bucket] = position;
                    classes += 1;
                }
                work->next_classes[position] = match == BUSTER_IR_NONE ? base + classes : work->next_classes[match];
            }
        }
        work->statistics.partition_probes += probes;
        work->statistics.partition_sort_fallbacks += sorted;
    }
    if (sorted)
    {
        classes = fixed_ir_gvn_partition_sorted(work, count, initial, base);
    }
    return classes;
}

static uint32_t fixed_ir_gvn_partition(IrGvnWork* work, uint32_t count, bool initial, bool sorted, uint32_t base)
{
    if (work->relative_keys)
    {
        fixed_ir_gvn_relative_keys(work, count);
    }
    else
    {
        fixed_ir_gvn_keys(work, count, initial);
    }
    const uint32_t classes = fixed_ir_gvn_partition_group(work, count, initial, sorted, base);
    for (uint32_t position = 0; position < count; position += 1)
    {
        work->classes[work->members[position]] = work->next_classes[position];
    }
    work->statistics.rounds += 1;
    return classes;
}

