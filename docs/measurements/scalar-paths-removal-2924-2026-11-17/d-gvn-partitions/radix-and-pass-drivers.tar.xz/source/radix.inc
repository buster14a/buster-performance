typedef struct {
    const uint64_t* column;
    uint32_t extra;
    uint32_t predecessor;
    bool phi;
} IrGvnRadixKey;

static __m512i ir_gvn_radix_keys(const IrGvnWork* w, const IrGvnRadixKey* key, const uint32_t* rows, __mmask8 live)
{
    const __m512i zero = _mm512_setzero_si512();
    const __m512i positions = _mm512_cvtepu32_epi64(_mm256_maskz_loadu_epi32(live, rows));
    if (key->column != NULL)
        return _mm512_mask_i64gather_epi64(zero, live, positions, key->column, 8);
    const IrFunction* f = w->ir.function;
    const __m256i members = _mm512_mask_i64gather_epi32(_mm256_setzero_si256(), live, positions, w->members, 4);
    const __m256i first = _mm512_mask_i64gather_epi32(_mm256_setzero_si256(), live, _mm512_cvtepu32_epi64(members), f->a, 4);
    const __m512i start = _mm512_cvtepu32_epi64(first);
    if (!key->phi)
        return _mm512_mask_i64gather_epi64(zero, live, _mm512_slli_epi64(start, 3), ((const uint64_t*)f->vector_constants) + key->extra + 2, 8);
    const __m512i wanted = _mm512_set1_epi64(key->predecessor);
    const __m512i low = _mm512_set1_epi64(UINT32_MAX);
    __m512i edges = _mm512_mask_i64gather_epi64(zero, live, _mm512_add_epi64(start, _mm512_set1_epi64((uint64_t)key->extra * 2)), f->extra, 4);
    __mmask8 missing = _mm512_mask_cmpneq_epi64_mask(live, _mm512_and_si512(edges, low), wanted);
    for (uint64_t at = 0; missing != 0; at += 2)
    {
        edges = _mm512_mask_i64gather_epi64(edges, missing, _mm512_add_epi64(start, _mm512_set1_epi64(at)), f->extra, 4);
        missing = _mm512_mask_cmpneq_epi64_mask(missing, _mm512_and_si512(edges, low), wanted);
    }
    const __m256i aliases = _mm512_mask_i64gather_epi32(_mm256_setzero_si256(), live, _mm512_srli_epi64(edges, 32), w->alias, 4);
    return _mm512_cvtepu32_epi64(_mm512_mask_i64gather_epi32(_mm256_setzero_si256(), live, _mm512_cvtepu32_epi64(aliases), w->classes, 4));
}

// Process the smaller subrange recursively. Even a sequence of one-row splits uses logarithmic stack.
static void ir_gvn_radix_range(IrGvnWork* w, uint64_t begin, uint64_t end, uint64_t column, bool initial)
{
    const IrFunction* f = w->ir.function;
    const uint32_t fixed = w->relative_keys ? 2 : BUSTER_IR_GVN_FIELDS;
    while (end > begin + 1)
    {
        IrGvnRadixKey key = {0};
        if (column <= fixed)
            key.column = column == 0 ? w->hashes : w->fields + (column - 1) * f->instruction_count;
        else
        {
            const uint32_t i = w->members[w->order[begin]];
            const uint64_t extra = column - fixed - 1;
            if (!w->relative_keys && f->op[i] == IR_VCONST && extra < 6)
                key.extra = (uint32_t)extra;
            else if (!initial && f->op[i] == IR_PHI && w->pure[i] != 0 && extra < f->b[i])
            {
                key.extra = (uint32_t)extra;
                key.phi = true;
                key.predecessor = w->ir.cfg.predecessors[w->ir.cfg.predecessor_offsets[w->ir.cfg.instruction_blocks[i]] + extra];
            }
            else break;
        }
        const __m512i origin = _mm512_broadcastq_epi64(_mm512_castsi512_si128(ir_gvn_radix_keys(w, &key, w->order + begin, 1)));
        __m512i differences = _mm512_setzero_si512();
        for (uint64_t at = begin; at < end; at += 8)
        {
            const __mmask8 live = end - at >= 8 ? UINT8_MAX : (__mmask8)((1u << (end - at)) - 1);
            const __m512i values = ir_gvn_radix_keys(w, &key, w->order + at, live);
            differences = _mm512_or_si512(differences, _mm512_maskz_xor_epi64(live, values, origin));
        }
        const uint64_t changed = (uint64_t)_mm512_reduce_or_epi64(differences);
        if (changed == 0)
        {
            column += 1;
            continue;
        }
        const __m512i bit = _mm512_set1_epi64(UINT64_C(1) << (63 - __builtin_clzll(changed)));
        uint64_t zeros = 0;
        for (uint64_t at = begin; at < end; at += 8)
        {
            const __mmask8 live = end - at >= 8 ? UINT8_MAX : (__mmask8)((1u << (end - at)) - 1);
            const __m512i values = ir_gvn_radix_keys(w, &key, w->order + at, live);
            const __mmask8 lower = _mm512_mask_testn_epi64_mask(live, values, bit);
            w->next_classes[at] = lower;
            zeros += (uint32_t)__builtin_popcount((uint32_t)lower);
        }
        const uint64_t middle = begin + zeros;
        uint64_t left = begin, right = middle;
        for (uint64_t at = begin; at < end; at += 8)
        {
            const __mmask8 live = end - at >= 8 ? UINT8_MAX : (__mmask8)((1u << (end - at)) - 1);
            const __m256i rows = _mm256_maskz_loadu_epi32(live, w->order + at);
            const __mmask8 lower = (__mmask8)w->next_classes[at];
            _mm256_mask_compressstoreu_epi32(w->temporary_order + left, lower, rows);
            _mm256_mask_compressstoreu_epi32(w->temporary_order + right, live & ~lower, rows);
            left += (uint32_t)__builtin_popcount(lower);
            right += (uint32_t)__builtin_popcount(live & ~lower);
        }
        memcpy(w->order + begin, w->temporary_order + begin, (end - begin) * sizeof(uint32_t));
        if (zeros <= end - middle)
        {
            ir_gvn_radix_range(w, begin, middle, column, initial);
            begin = middle;
        }
        else
        {
            ir_gvn_radix_range(w, middle, end, column, initial);
            end = middle;
        }
    }
}
static uint32_t ir_gvn_partition_radix(IrGvnWork*w,uint32_t count,bool initial,uint32_t base)
{
    for(uint32_t i=0;i<count;i++)w->order[i]=i;
    ir_gvn_radix_range(w,0,count,0,initial);
    uint32_t classes=0;
    for(uint32_t pos=0;pos<count;pos++){
        uint32_t i=w->order[pos],prev=w->order[pos?pos-1:0];
        if(!pos||ir_gvn_compare(w,prev,i,w->members[prev],w->members[i],initial)!=0)classes++;
        w->next_classes[i]=base+classes;
    }
    return classes;
}
