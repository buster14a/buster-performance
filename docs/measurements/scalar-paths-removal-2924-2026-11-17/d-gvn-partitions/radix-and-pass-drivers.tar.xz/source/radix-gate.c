#include "buster/compiler/main_unit_backend.c"
#include "radix.inc"

enum { WIDTH=2048, NKEY=11 };
static uint64_t oracle[WIDTH][NKEY];
static uint32_t ordering[WIDTH], expected[WIDTH], state=1;
static uint32_t draw(void){state=state*1664525u+1013904223u;return state;}
static uint64_t tick(void){_mm_lfence();uint64_t x=__rdtsc();_mm_lfence();return x;}
static int compare_time(const void*a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return (x>y)-(x<y);}
static int compare_rows(uint32_t a,uint32_t b){
    for(unsigned j=0;j<NKEY;j++)if(oracle[a][j]!=oracle[b][j])return oracle[a][j]<oracle[b][j]?-1:1;
    return 0;
}
static int reference(const void*a,const void*b){uint32_t x=*(const uint32_t*)a,y=*(const uint32_t*)b;int d=compare_rows(x,y);return d?d:(x>y)-(x<y);}
static void* guard(size_t bytes){
    size_t page=(size_t)sysconf(_SC_PAGESIZE),len=(bytes+page-1)/page*page;
    char*p=mmap(NULL,len+page,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(p==MAP_FAILED||mprotect(p+len,page,PROT_NONE))abort();
    return p+len-bytes;
}
typedef uint32_t Sort(IrGvnWork*,uint32_t,bool,uint32_t);
static Sort* volatile methods[]={ir_gvn_partition_sorted,ir_gvn_partition_radix};
int main(int argc,char**argv){
    if(argc!=2)return 2;
    state=strtoul(argv[1],NULL,10);
    enum{M=2};
    uint32_t a[WIDTH],b[WIDTH],members[WIDTH],block[WIDTH],alias[WIDTH],classes[WIDTH],pred[]={7,19},offs[]={0,2};
    uint8_t op[WIDTH],pure[WIDTH];uint32_t edges[4*WIDTH];
    static IrSimdValue vectors[WIDTH];static uint64_t fields[WIDTH*8];
    uint32_t*o=guard(WIDTH*4),*temp=guard(WIDTH*4),*next=guard(WIDTH*4);uint64_t*h=guard(WIDTH*8);
    IrFunction f={.op=op,.a=a,.b=b,.extra=edges,.vector_constants=vectors};
    IrGvnWork w={.ir.function=&f,.members=members,.fields=fields,.pure=pure,.alias=alias,.classes=classes};
    w.ir.cfg.instruction_blocks=block;w.ir.cfg.predecessor_offsets=offs;w.ir.cfg.predecessors=pred;
    unsigned sizes[100],amount=0;for(unsigned j=0;j<=65;j++)sizes[amount++]=j;
    unsigned extra[]={79,80,81,95,96,97,127,128,129,191,192,193,255,256,257,511,512,513,1024,2048};
    for(unsigned j=0;j<sizeof(extra)/sizeof(*extra);j++)sizes[amount++]=extra[j];
    for(unsigned k=0;k<amount;k++)for(unsigned shape=0;shape<10;shape++){
        uint32_t n=sizes[k],base=n%2?0x80000100u:1;
        f.instruction_count=n;w.relative_keys=shape==8||shape==9;w.hashes=h+WIDTH-n;
        memset(oracle,0,n*sizeof(*oracle));memset(fields,0,8*n*sizeof(*fields));
        uint32_t rand_key=draw();
        for(unsigned pos=0;pos<n;pos++){
            uint32_t i=n-1-pos,key=draw();members[pos]=i;ordering[pos]=pos;op[i]=IR_ADD;pure[i]=1;block[i]=0;alias[i]=i;classes[i]=5+i;
            switch(shape){
            case 0:oracle[pos][0]=((uint64_t)key<<32)|draw();break;
            case 1:oracle[pos][0]=pos;break;
            case 2:oracle[pos][0]=n-pos;break;
            case 3:oracle[pos][0]=(key>>8)%7;break;
            case 4:oracle[pos][0]=UINT64_MAX;break;
            case 5:oracle[pos][0]=UINT64_MAX;oracle[pos][1+pos%8]=1+pos/8;break;
            case 6:op[i]=IR_VCONST;a[i]=i;oracle[pos][0]=UINT64_MAX;
                memset(vectors[i].words,0,64);vectors[i].words[7]=oracle[pos][9]=(key>>12)%17;break;
            case 7:{op[i]=IR_PHI;a[i]=i*4;b[i]=2;unsigned v0=(i+rand_key)%n,v1=(n-1-i)/2;
                unsigned switched=pos&1;for(unsigned e=0;e<2;e++){unsigned j=e^switched;edges[i*4+2*j]=pred[e];edges[i*4+2*j+1]=e?v1:v0;}
                oracle[pos][9]=5+v0;oracle[pos][10]=5+v1;break;}
            case 8:oracle[pos][1]=key%13;oracle[pos][2]=key%5;break;
            case 9:oracle[pos][0]=(pos%3==0)?UINT64_MAX:0;oracle[pos][2]=pos%5;break;
            }
            w.hashes[pos]=oracle[pos][0];
            for(unsigned j=0;j<8;j++)fields[(uint64_t)j*n+pos]=oracle[pos][1+j];
        }
        qsort(ordering,n,4,reference);uint32_t groups=0;
        for(unsigned j=0;j<n;j++){if(j==0||compare_rows(ordering[j-1],ordering[j])!=0)groups++;expected[ordering[j]]=base+groups;}
        uint64_t elapsed[M][5];unsigned reps=112/(1+n/8)+1;
        for(unsigned r=0;r<5;r++)for(unsigned m=0;m<M;m++){
            unsigned t=(r+m)%M;uint64_t begin=tick();uint32_t actual=0;
            for(unsigned rep=0;rep<reps;rep++){w.order=o+WIDTH-n;w.temporary_order=temp+WIDTH-n;w.next_classes=next+WIDTH-n;actual=methods[t](&w,n,false,base);}
            elapsed[t][r]=tick()-begin;
            if(actual!=groups||memcmp(w.order,ordering,n*4)||memcmp(w.next_classes,expected,n*4))
                return fprintf(stderr,"incorrect partition at %u rows, shape %u, method %u\n",n,shape,t),1;
        }
        printf("%u %u %u",n,shape,reps);
        for(unsigned m=0;m<M;m++){qsort(elapsed[m],5,8,compare_time);printf(" %llu",(unsigned long long)elapsed[m][2]);}
        puts("");
    }
    fprintf(stderr,"verified %u lengths across ten layouts on both methods\n",amount);
}
