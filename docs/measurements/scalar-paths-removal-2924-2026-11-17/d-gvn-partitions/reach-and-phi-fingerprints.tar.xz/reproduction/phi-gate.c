#include "buster/compiler/main_unit_backend.c"
#include "fingerprint.inc"
static uint32_t state=1;
static uint32_t draw(void){state=state*1664525+1013904223;return state;}
static uint64_t tick(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int cmp_time(const void* a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return(x>y)-(x<y);}
typedef uint64_t Method(const IrGvnWork*,uint32_t);
static __attribute__((noinline)) uint64_t previous(const IrGvnWork*w,uint32_t i){return ir_gvn_hash_payload(w,BUSTER_IR_GVN_HASH_BASIS,i,false);}
static Method*volatile methods[]={previous,ir_gvn_phi_fingerprint};
static uint32_t pages[]={0,0x7fff8000u,0x80000000u,0xffff8000u};
static uint32_t* map_values(void){
 uint32_t*p=mmap(NULL,UINT64_C(1)<<34,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_NORESERVE,-1,0);
 if(p==MAP_FAILED)return NULL;
 for(unsigned j=0;j<4;j++)if(mprotect(p+pages[j],0x20000,PROT_READ|PROT_WRITE))return NULL;
 return p;
}
static uint32_t index_for(unsigned j,bool wide){return wide?pages[j%4]+j/4:j;}
int main(int argc,char**argv){
 if(argc!=2)return 2;state=strtoul(argv[1],0,10);
 enum{N=2048};uint32_t pred[N],edges[2*N],perm[N],logical[N],a=0,b=0,block=0,offs[2]={0};uint8_t op=IR_PHI,pure=1;
 IrFunction f={.op=&op,.a=&a,.b=&b,.extra=edges};IrGvnWork w={.ir.function=&f,.pure=&pure,.classes=map_values(),.alias=map_values()};
 if(!w.classes||!w.alias)return 2;
 w.ir.cfg.predecessor_offsets=offs;w.ir.cfg.instruction_blocks=&block;w.ir.cfg.predecessors=pred;
 unsigned widths[100],nw=0;for(unsigned i=0;i<=65;i++)widths[nw++]=i;
 unsigned more[]={79,80,81,95,96,97,127,128,129,191,192,193,255,256,257,511,512,513,1024,2048};
 for(unsigned i=0;i<sizeof(more)/sizeof(*more);i++)widths[nw++]=more[i];volatile uint64_t sink=0;
 for(unsigned k=0;k<nw;k++)for(unsigned shape=0;shape<8;shape++){
  unsigned n=widths[k];b=offs[1]=n;bool wide=shape>=6;f.instruction_count=wide?UINT32_MAX:N+1;w.copies=shape>=3;
  for(unsigned j=0;j<n;j++){pred[j]=3*j+1;perm[j]=j;w.classes[index_for(j,wide)]=shape==5?91:draw();w.alias[index_for(j,wide)]=index_for(w.copies?(j*3+1)%n:j,wide);}
  if(shape%3==1)for(unsigned j=0;j<n;j++)perm[j]=n-1-j;
  if(shape%3==2)for(unsigned j=n;j>1;j--){unsigned q=draw()%j,swap=perm[j-1];perm[j-1]=perm[q];perm[q]=swap;}
  for(unsigned j=0;j<n;j++){unsigned q=perm[j];edges[2*j]=pred[q];edges[2*j+1]=index_for(q,wide);logical[q]=w.classes[w.alias[index_for(q,wide)]];}
  uint64_t expect=0,fnv=BUSTER_IR_GVN_HASH_BASIS;
  for(unsigned j=0;j<n;j++){uint64_t x=(uint64_t)pred[j]<<32|logical[j];x=(x^(x>>30))*UINT64_C(0xbf58476d1ce4e5b9);expect+=(x^(x>>27))*UINT64_C(0x94d049bb133111eb);fnv=(fnv^logical[j])*BUSTER_IR_GVN_HASH_MULTIPLIER;}
  if(methods[0](&w,0)!=fnv||methods[1](&w,0)!=expect)return fprintf(stderr,"mismatch %u %u\n",n,shape),1;
  uint64_t ts[2][7];unsigned reps=768/(1+n/16)+1;
  for(unsigned r=0;r<7;r++){unsigned first=draw()>>31;for(unsigned j=0;j<2;j++){unsigned z=first^j;Method* m=methods[z];uint64_t begin=tick(),sum=0;
   for(unsigned i=0;i<reps;i++){__asm__ volatile("":::"memory");sum+=m(&w,0);}ts[z][r]=tick()-begin;sink=sum;}}
  for(unsigned z=0;z<2;z++)qsort(ts[z],7,8,cmp_time);printf("%u %u %u %llu %llu\n",n,shape,reps,(unsigned long long)ts[0][3],(unsigned long long)ts[1][3]);
 }
 fprintf(stderr,"verified %u counts and eight layouts (%llu)\n",nw,(unsigned long long)sink);
}
