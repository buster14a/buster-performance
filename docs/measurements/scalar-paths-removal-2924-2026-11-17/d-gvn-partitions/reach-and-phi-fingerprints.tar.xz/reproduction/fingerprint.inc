static uint64_t ir_gvn_phi_fingerprint(const IrGvnWork* work, uint32_t i)
{
    const IrFunction* f = work->ir.function;
    const uint32_t count = f->b[i];
    const uint32_t center = f->instruction_count / 2;
    const __m256i origin = _mm256_set1_epi32((int)center);
    __m512i sum = _mm512_setzero_si512();
    for (uint64_t at = 0; at < count; at += 8)
    {
        const __mmask8 valid = count - at >= 8 ? UINT8_MAX : (__mmask8)((1u << (count - (uint32_t)at)) - 1);
        const __m512i edges = _mm512_maskz_loadu_epi64(valid, f->extra + ((uint64_t)f->a[i] + 2 * at));
        __m256i ids = _mm512_cvtepi64_epi32(_mm512_srli_epi64(edges, 32));
        if (work->copies)
        {
            ids = _mm256_mmask_i32gather_epi32(_mm256_setzero_si256(), valid, _mm256_sub_epi32(ids, origin), work->alias + center, 4);
        }
        const __m256i classes = _mm256_mmask_i32gather_epi32(_mm256_setzero_si256(), valid, _mm256_sub_epi32(ids, origin), work->classes + center, 4);
        __m512i pairs = _mm512_or_si512(_mm512_slli_epi64(edges, 32), _mm512_cvtepu32_epi64(classes));
        pairs = _mm512_mullo_epi64(_mm512_xor_si512(pairs, _mm512_srli_epi64(pairs, 30)), _mm512_set1_epi64(UINT64_C(0xbf58476d1ce4e5b9)));
        pairs = _mm512_mullo_epi64(_mm512_xor_si512(pairs, _mm512_srli_epi64(pairs, 27)), _mm512_set1_epi64(UINT64_C(0x94d049bb133111eb)));
        sum = _mm512_add_epi64(sum, pairs);
    }
    return (uint64_t)_mm512_reduce_add_epi64(sum);
}

