#include "decl.h"
static EmissionCheck emission_layout_check(const EmissionLayout* layout)
{
    EmissionCheck check = { .error = EMISSION_INVALID, .part = EMISSION_LAYOUT };
    if (layout != NULL && (layout->count == 0 || (layout->starts != NULL && layout->ends != NULL)))
    {
        check = (EmissionCheck){ .error = EMISSION_OK };
        const __m512i limit = _mm512_set1_epi32((int32_t)layout->size);
        for (uint64_t base = 0; base < layout->count && check.error == EMISSION_OK; base += BUSTER_EMISSION_LAYOUT_LANES)
        {
            const uint32_t left = layout->count - (uint32_t)base;
            const __mmask16 live = left >= BUSTER_EMISSION_LAYOUT_LANES ? (__mmask16)UINT16_MAX : (__mmask16)((1u << left) - 1u);
            const __m512i start = _mm512_maskz_loadu_epi32(live, layout->starts + base);
            const __m512i end = _mm512_maskz_loadu_epi32(live, layout->ends + base);
            const __mmask16 successors = left > BUSTER_EMISSION_LAYOUT_LANES ? live : (__mmask16)(live >> 1);
            const __m512i next_start = _mm512_maskz_loadu_epi32(successors, layout->starts + base + 1);
            const uint32_t overlap = (uint32_t)_mm512_mask_cmplt_epu32_mask(successors, next_start, end) << 1;
            const uint32_t bad = overlap | _mm512_mask_cmplt_epu32_mask(live, end, start) |
                                 _mm512_mask_cmpgt_epu32_mask(live, end, limit);
            if (bad != 0)
            {
                check = (EmissionCheck){ .error = EMISSION_INVALID, .part = EMISSION_LAYOUT, .index = (uint32_t)base + (uint32_t)__builtin_ctz(bad) };
            }
        }
    }
    return check;
}
EmissionCheck head(const EmissionLayout* v, bool scalar){(void)scalar;return emission_layout_check(v);}
