#include "decl.h"
static EmissionCheck emission_layout_check_scalar(const EmissionLayout* layout)
{
    EmissionCheck check = { .error = EMISSION_OK, .part = EMISSION_NONE };
    const uint32_t count = layout->count;
    const uint32_t size = layout->size;
    const uint32_t* const starts = layout->starts;
    const uint32_t* const ends = layout->ends;
    uint32_t previous = 0;
    for (uint32_t i = 0; check.error == EMISSION_OK && i < count; i += 1)
    {
        const uint32_t start = starts[i];
        const uint32_t end = ends[i];
        if (start < previous || end < start || end > size)
        {
            check.error = EMISSION_INVALID;
            check.part = EMISSION_LAYOUT;
            check.index = i;
        }
        previous = end;
    }
    return check;
}

// Contiguous validation only: sparse event-to-record resolution below uses scalar loads rather than AVX-512 gathers.
// The same first invalid record as the exact path, including errors at a batch boundary. Masked tails need no slack.
static EmissionCheck emission_layout_check(const EmissionLayout* layout, bool scalar)
{
    EmissionCheck check;
    if (layout == NULL || (layout->count != 0 && (layout->starts == NULL || layout->ends == NULL)))
    {
        check = (EmissionCheck){ .error = EMISSION_INVALID, .part = EMISSION_LAYOUT };
    }
    else if (scalar)
    {
        check = emission_layout_check_scalar(layout);
    }
    else
    {
        const uint32_t count = layout->count;
        const uint32_t size = layout->size;
        const uint32_t* const starts = layout->starts;
        const uint32_t* const ends = layout->ends;
        const __m512i limit = _mm512_set1_epi32((int32_t)size);
        uint32_t previous = 0;
        check = (EmissionCheck){
            .error = EMISSION_OK,
            .part = EMISSION_NONE,
        };
        for (uint64_t base = 0; check.error == EMISSION_OK && base < count; base += BUSTER_EMISSION_LAYOUT_LANES)
        {
            const uint32_t take = count - base < BUSTER_EMISSION_LAYOUT_LANES ? (uint32_t)(count - base) : BUSTER_EMISSION_LAYOUT_LANES;
            const __mmask16 valid = (__mmask16)((1u << take) - 1u);
            const __m512i start = _mm512_maskz_loadu_epi32(valid, starts + base);
            const __m512i end = _mm512_maskz_loadu_epi32(valid, ends + base);
            const __m512i before = _mm512_mask_mov_epi32(_mm512_alignr_epi32(end, end, 15), 1, _mm512_set1_epi32((int32_t)previous));
            const __mmask16 bad = _mm512_mask_cmplt_epu32_mask(valid, start, before) |
                                  _mm512_mask_cmplt_epu32_mask(valid, end, start) |
                                  _mm512_mask_cmpgt_epu32_mask(valid, end, limit);
            if (bad != 0)
            {
                check.error = EMISSION_INVALID;
                check.part = EMISSION_LAYOUT;
                check.index = (uint32_t)base + (uint32_t)__builtin_ctz((uint32_t)bad);
            }
            else
            {
                previous = ends[base + take - 1];
            }
        }
    }
    return check;
}

EmissionCheck head(const EmissionLayout* v,bool scalar){return emission_layout_check(v,scalar);}
