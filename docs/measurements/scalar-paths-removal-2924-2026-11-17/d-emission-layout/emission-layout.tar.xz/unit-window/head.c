#include "decl.h"
static EmissionCheck emission_layout_check(const EmissionLayout* layout)
{
    EmissionCheck check = { .error = EMISSION_INVALID, .part = EMISSION_LAYOUT };
    if (layout != NULL && (layout->count == 0 || (layout->starts != NULL && layout->ends != NULL)))
    {
        check = (EmissionCheck){ .error = EMISSION_OK };
        const __m512i limit = _mm512_set1_epi32((int32_t)layout->size);
        for (uint64_t base = 0; base < layout->count && check.error == EMISSION_OK; base += BUSTER_EMISSION_LAYOUT_LANES)
        {
            const uint64_t remaining = layout->count - base;
            // A short last block ends at the array's last element. Already validated lanes may overlap.
            const uint64_t first = remaining < 16 && layout->count >= 16 ? layout->count - 16 : base;
            const uint32_t take = layout->count < 16 ? layout->count : 16;
            const __mmask16 live = (__mmask16)((1u << take) - 1u);
            const __m512i start = _mm512_maskz_expandloadu_epi32(live, layout->starts + first);
            const __m512i end = _mm512_maskz_expandloadu_epi32(live, layout->ends + first);
            const uint32_t previous = first == 0 ? 0 : layout->ends[first - 1];
            const __m512i before = _mm512_alignr_epi32(end, _mm512_set1_epi32((int32_t)previous), 15);
            const uint32_t bad = _mm512_mask_cmplt_epu32_mask(live, start, before) |
                                 _mm512_mask_cmplt_epu32_mask(live, end, start) |
                                 _mm512_mask_cmpgt_epu32_mask(live, end, limit);
            if (bad != 0)
            {
                check = (EmissionCheck){ .error = EMISSION_INVALID, .part = EMISSION_LAYOUT, .index = (uint32_t)first + (uint32_t)__builtin_ctz(bad) };
            }
        }
    }
    return check;
}
EmissionCheck head(const EmissionLayout* v, bool scalar){(void)scalar;return emission_layout_check(v);}
