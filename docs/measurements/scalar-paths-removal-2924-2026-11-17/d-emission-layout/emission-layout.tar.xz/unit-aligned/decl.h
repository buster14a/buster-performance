#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include <immintrin.h>

#define BUSTER_EMISSION_NO_ORIGIN UINT32_MAX
#define BUSTER_EMISSION_MAX_REGISTERS 65536u
#define BUSTER_EMISSION_LAYOUT_LANES 16u

// The x86-64 target's unwind-register namespace: the System V psABI's DWARF numbers (rax 0, rdx 1, rcx 2, rbx 3, rsi 4,
// rdi 5, rbp 6, rsp 7, r8 to r15 8 to 15, and the return address 16), which its frame events name and its CIE's rules
// start from. emission_x86_registers maps the encoder's numbering (rax, rcx, rdx, rbx, rsp, rbp, rsi, rdi, r8 to r15)
// to it. The other targets' namespaces would be theirs; this is the only one the compiler has.
#define BUSTER_EMISSION_X86_REGISTERS 17u
#define BUSTER_EMISSION_X86_RBP 6u
#define BUSTER_EMISSION_X86_RSP 7u
#define BUSTER_EMISSION_X86_RETURN 16u
static const uint8_t emission_x86_registers[16] __attribute__((unused)) = { 0, 2, 1, 3, 7, 6, 4, 5, 8, 9, 10, 11, 12, 13, 14, 15 };
// Past them, the vector and mask registers a frame may save for its caller (#147, a preserving frame's): xmm0 to xmm15
// (17 to 32), xmm16 to xmm31 (67 to 82) and k0 to k7 (118 to 125), whose rules say where a slot holds one or that it
// holds its caller's value; the namespace's frame events count to the last.
#define BUSTER_EMISSION_X86_DWARF_REGISTERS 126u

// Whether `reg` is one of the vector or mask registers' DWARF numbers a frame's rules may name past the general ones.
static __attribute__((unused)) bool emission_x86_saved_vector(uint32_t reg)
{
    return (reg >= 17 && reg <= 32) || (reg >= 67 && reg <= 82) || (reg >= 118 && reg <= 125);
}

typedef enum EmissionError
{
    EMISSION_OK,
    EMISSION_INVALID,
    EMISSION_CAPACITY,
} EmissionError;

typedef enum EmissionPart
{
    EMISSION_NONE,
    EMISSION_DESCRIPTOR,
    EMISSION_LAYOUT,
    EMISSION_SOURCE,
    EMISSION_FRAME,
    EMISSION_DESTINATION,
} EmissionPart;

// On success, part is EMISSION_NONE and index is 0. Descriptor and destination errors report index 0; layout, source
// and frame errors report the first failing record or event, and an unbalanced final state stack reports frame_count.
typedef struct EmissionCheck EmissionCheck;
struct EmissionCheck
{
    EmissionError error;
    EmissionPart part;
    uint32_t index;
};

typedef enum EmissionSide
{
    EMISSION_LEFT,
    EMISSION_RIGHT,
} EmissionSide;

typedef struct EmissionAnchor EmissionAnchor;
struct EmissionAnchor
{
    uint32_t boundary;
    uint32_t side;
};

typedef struct EmissionLayout EmissionLayout;
struct EmissionLayout
{
    const uint32_t* starts;
    const uint32_t* ends;
    uint32_t count;
    uint32_t size;
};

