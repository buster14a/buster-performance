from pathlib import Path
f=Path('src/buster/compiler/emission_metadata.c');s=f.read_text();m='static EmissionCheck emission_layout_check(const EmissionLayout* layout, bool scalar)\n{'
s=s.replace(m,'''#include <stdio.h>
#include <stdlib.h>
static uint64_t emission_reach_calls[2][7], emission_reach_max;
static unsigned emission_reach_seen;
static void emission_reach_finish(void)
{
    const char* path = getenv("BUSTER_EMISSION_REACH");
    FILE* file = path != NULL ? fopen(path, "a") : NULL;
    if (file != NULL)
    {
        for (uint32_t side = 0; side < 2; side += 1)
        {
            fprintf(file, "%u", side);
            for (uint32_t item = 0; item < 7; item += 1)
            {
                fprintf(file, " %llu", (unsigned long long)emission_reach_calls[side][item]);
            }
            fprintf(file, " %llu\\n", (unsigned long long)emission_reach_max);
        }
        fclose(file);
    }
}
'''+m+'''
    if (!__atomic_exchange_n(&emission_reach_seen, 1, __ATOMIC_RELAXED))
    {
        atexit(emission_reach_finish);
    }
    const uint32_t n = layout != NULL ? layout->count : 0;
    const uint32_t group = layout == NULL ? 0 : n == 0 ? 1 : !layout->starts && !layout->ends ? 2 :
                           !layout->starts ? 3 : !layout->ends ? 4 : n <= 16 ? 5 : 6;
    __atomic_fetch_add(&emission_reach_calls[scalar][group], 1, __ATOMIC_RELAXED);
    uint64_t high = __atomic_load_n(&emission_reach_max, __ATOMIC_RELAXED);
    while (high < n && !__atomic_compare_exchange_n(&emission_reach_max, &high, n, false, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
''');assert s.count('emission_reach_finish')==2;f.write_text(s)
