// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
//
// The emission metadata protocol tests, for the test-emission-metadata command. build.sh compiles this file as a
// translation unit that includes emission_metadata.c; main.c calls run_emission_metadata_tests. The standalone wrapper
// tests/emission-metadata/test.c gives the isolated commands in docs/emission-metadata.md the same tests. No compiler
// tables or fake backend types are required; guarded slices have exactly their stated logical lengths, including every
// SIMD tail. These are protocol tests, not a claim of machine-code/CFG verification or driver migration.

#define _GNU_SOURCE
#include <errno.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

// The standalone wrapper (tests/emission-metadata/test.c) builds this module alone, for any AVX-512F target: it needs
// no more of the host's features than emission_metadata.c's own.
#if !defined(BUSTER_EMISSION_METADATA_TEST_STANDALONE)
#include "host_isa.h"
#endif
#include "emission_metadata.c"

#define BUSTER_EMISSION_METADATA_TEST_REPORTED 8

typedef struct EmissionMetadataTestTally EmissionMetadataTestTally;
struct EmissionMetadataTestTally
{
    uint64_t checks;
    uint64_t failures;
};

static EmissionMetadataTestTally test_tally;

static void test_expect(bool condition, const char* expression, uint32_t line)
{
    test_tally.checks += 1;
    if (!condition)
    {
        if (test_tally.failures < BUSTER_EMISSION_METADATA_TEST_REPORTED)
        {
            fprintf(stderr, "emission metadata: line %u: %s\n", line, expression);
        }
        test_tally.failures += 1;
    }
}

#define BUSTER_EMISSION_TEST(expression) test_expect((expression), #expression, __LINE__)

static bool test_same_check(EmissionCheck a, EmissionCheck b)
{
    return a.error == b.error && a.part == b.part && a.index == b.index;
}

static EmissionSourceEvent test_origin(uint32_t boundary, uint32_t side, uint32_t origin)
{
    const EmissionSourceEvent event = {
        .at = {
            .boundary = boundary,
            .side = side,
        },
        .origin = origin,
        .kind = origin == BUSTER_EMISSION_NO_ORIGIN ? EMISSION_SOURCE_GENERATED : EMISSION_SOURCE_ORIGIN,
    };
    return event;
}

static EmissionFrameEvent test_frame(uint32_t boundary, uint32_t side, uint8_t kind, uint16_t reg, int64_t value)
{
    const EmissionFrameEvent event = {
        .at = {
            .boundary = boundary,
            .side = side,
        },
        .value = value,
        .reg = reg,
        .kind = kind,
    };
    return event;
}

static void test_empty(void)
{
    const EmissionMetadata metadata = { 0 };
    const EmissionLayout layout = { 0 };
    const EmissionStorage storage = { 0 };
    EmissionMetadataPlan plan = {
        .source_count = 7,
        .frame_count = 9,
    };
    EmissionResolved resolved = {
        .source_count = 7,
        .frame_count = 9,
        .size = 11,
    };
    BUSTER_EMISSION_TEST(emission_metadata_plan(&metadata, &layout, false, &plan).error == EMISSION_OK);
    BUSTER_EMISSION_TEST(plan.source_count == 0 && plan.frame_count == 0);
    BUSTER_EMISSION_TEST(emission_metadata_resolve(&metadata, &layout, &storage, false, &resolved).error == EMISSION_OK);
    BUSTER_EMISSION_TEST(resolved.sources == NULL && resolved.frames == NULL && resolved.source_count == 0 && resolved.frame_count == 0 && resolved.size == 0);
    BUSTER_EMISSION_TEST(emission_metadata_check(NULL, &layout, false).error == EMISSION_INVALID);
    BUSTER_EMISSION_TEST(emission_metadata_check(&metadata, NULL, false).error == EMISSION_INVALID);
    BUSTER_EMISSION_TEST(emission_metadata_plan(&metadata, &layout, false, NULL).error == EMISSION_INVALID);
    BUSTER_EMISSION_TEST(emission_metadata_resolve(&metadata, &layout, NULL, false, &resolved).error == EMISSION_INVALID);
    BUSTER_EMISSION_TEST(emission_metadata_resolve(&metadata, &layout, &storage, false, NULL).error == EMISSION_INVALID);
    const EmissionLayout padding = {
        .size = 32,
    };
    const EmissionSourceEvent sources[] = {
        {
            .at = {
                .boundary = 0,
                .side = EMISSION_LEFT,
            },
            .origin = BUSTER_EMISSION_NO_ORIGIN,
            .kind = EMISSION_SOURCE_GENERATED,
        },
        {
            .at = {
                .boundary = 0,
                .side = EMISSION_RIGHT,
            },
            .origin = BUSTER_EMISSION_NO_ORIGIN,
            .kind = EMISSION_SOURCE_GENERATED,
        },
    };
    const EmissionMetadata generated = {
        .sources = sources,
        .source_count = 2,
    };
    EmissionSourceRow rows[2];
    const EmissionStorage destination = {
        .sources = rows,
        .source_capacity = 2,
    };
    BUSTER_EMISSION_TEST(emission_metadata_resolve(&generated, &padding, &destination, false, &resolved).error == EMISSION_OK);
    BUSTER_EMISSION_TEST(rows[0].offset == 0 && rows[1].offset == 32);
}

static void test_layouts(void)
{
    uint32_t starts[] = { 2, 3, 8, 8, 12 };
    uint32_t ends[] = { 3, 8, 8, 10, 13 };
    const EmissionLayout layout = {
        .starts = starts,
        .ends = ends,
        .count = 5,
        .size = 16,
    };
    const EmissionSourceEvent sources[] = {
        {
            .at = {
                .boundary = 0,
                .side = EMISSION_LEFT,
            },
            .origin = BUSTER_EMISSION_NO_ORIGIN,
            .kind = EMISSION_SOURCE_GENERATED,
        },
        {
            .at = {
                .boundary = 0,
                .side = EMISSION_RIGHT,
            },
            .origin = 0,
            .kind = EMISSION_SOURCE_ORIGIN,
        },
        {
            .at = {
                .boundary = 1,
                .side = EMISSION_LEFT,
            },
            .origin = BUSTER_EMISSION_NO_ORIGIN,
            .kind = EMISSION_SOURCE_GENERATED,
        },
        {
            .at = {
                .boundary = 1,
                .side = EMISSION_RIGHT,
            },
            .origin = 1,
            .kind = EMISSION_SOURCE_ORIGIN,
        },
        {
            .at = {
                .boundary = 2,
                .side = EMISSION_RIGHT,
            },
            .origin = 2,
            .kind = EMISSION_SOURCE_ORIGIN,
        },
        {
            .at = {
                .boundary = 3,
                .side = EMISSION_RIGHT,
            },
            .origin = 3,
            .kind = EMISSION_SOURCE_ORIGIN,
        },
        {
            .at = {
                .boundary = 4,
                .side = EMISSION_LEFT,
            },
            .origin = BUSTER_EMISSION_NO_ORIGIN,
            .kind = EMISSION_SOURCE_GENERATED,
        },
        {
            .at = {
                .boundary = 4,
                .side = EMISSION_RIGHT,
            },
            .origin = 4,
            .kind = EMISSION_SOURCE_ORIGIN,
        },
        {
            .at = {
                .boundary = 5,
                .side = EMISSION_LEFT,
            },
            .origin = BUSTER_EMISSION_NO_ORIGIN,
            .kind = EMISSION_SOURCE_GENERATED,
        },
        {
            .at = {
                .boundary = 5,
                .side = EMISSION_RIGHT,
            },
            .origin = BUSTER_EMISSION_NO_ORIGIN,
            .kind = EMISSION_SOURCE_GENERATED,
        },
    };
    const EmissionFrameEvent frames[] = {
        {
            .at = {
                .boundary = 1,
                .side = EMISSION_LEFT,
            },
            .value = 16,
            .reg = 7,
            .kind = EMISSION_FRAME_CFA,
        },
        {
            .at = {
                .boundary = 1,
                .side = EMISSION_LEFT,
            },
            .value = -16,
            .reg = 6,
            .kind = EMISSION_FRAME_OFFSET,
        },
        {
            .at = {
                .boundary = 2,
                .side = EMISSION_LEFT,
            },
            .kind = EMISSION_FRAME_REMEMBER_STATE,
        },
        {
            .at = {
                .boundary = 2,
                .side = EMISSION_LEFT,
            },
            .value = 8,
            .kind = EMISSION_FRAME_CFA_OFFSET,
        },
        {
            .at = {
                .boundary = 3,
                .side = EMISSION_LEFT,
            },
            .reg = 6,
            .kind = EMISSION_FRAME_RESTORE,
        },
        {
            .at = {
                .boundary = 3,
                .side = EMISSION_LEFT,
            },
            .kind = EMISSION_FRAME_RESTORE_STATE,
        },
        {
            .at = {
                .boundary = 4,
                .side = EMISSION_LEFT,
            },
            .value = 16,
            .reg = 6,
            .kind = EMISSION_FRAME_CFA,
        },
        {
            .at = {
                .boundary = 5,
                .side = EMISSION_LEFT,
            },
            .value = 7,
            .reg = 12,
            .kind = EMISSION_FRAME_REGISTER,
        },
    };
    const uint32_t expected_sources[] = { 0, 2, 3, 3, 8, 8, 10, 12, 13, 16 };
    const uint32_t expected_frames[] = { 3, 3, 8, 8, 8, 8, 10, 13 };
    const EmissionMetadata metadata = {
        .sources = sources,
        .frames = frames,
        .source_count = 10,
        .frame_count = 8,
        .origin_count = 5,
        .register_count = 17,
    };
    EmissionSourceRow source_rows[10];
    EmissionFrameRow frame_rows[8];
    const EmissionStorage storage = {
        .sources = source_rows,
        .frames = frame_rows,
        .source_capacity = 10,
        .frame_capacity = 8,
    };
    EmissionResolved result;
    for (uint32_t scalar = 0; scalar < 2; scalar += 1)
    {
        const bool resolved = emission_metadata_resolve(&metadata, &layout, &storage, scalar != 0, &result).error == EMISSION_OK;
        BUSTER_EMISSION_TEST(resolved);
        if (!resolved)
        {
            continue;
        }
        BUSTER_EMISSION_TEST(result.source_count == 10 && result.frame_count == 8 && result.size == 16);
        for (uint32_t i = 0; i < 10; i += 1)
        {
            BUSTER_EMISSION_TEST(source_rows[i].offset == expected_sources[i]);
            BUSTER_EMISSION_TEST(source_rows[i].origin == sources[i].origin && source_rows[i].kind == sources[i].kind);
        }
        for (uint32_t i = 0; i < 8; i += 1)
        {
            BUSTER_EMISSION_TEST(frame_rows[i].offset == expected_frames[i]);
            BUSTER_EMISSION_TEST(frame_rows[i].kind == frames[i].kind && frame_rows[i].reg == frames[i].reg && frame_rows[i].value == frames[i].value && frame_rows[i].reserved == 0);
        }
    }
    // Relax record 1 from five bytes to two. The same producer anchors resolve through the new map; zero-width
    // records and the gap before record 4 remain explicit. No producer event is rewritten to a byte offset.
    ends[1] = 5;
    starts[2] = 5;
    ends[2] = 5;
    starts[3] = 5;
    ends[3] = 7;
    starts[4] = 9;
    ends[4] = 10;
    const EmissionLayout relaxed = {
        .starts = starts,
        .ends = ends,
        .count = 5,
        .size = 13,
    };
    const bool resolved = emission_metadata_resolve(&metadata, &relaxed, &storage, false, &result).error == EMISSION_OK;
    BUSTER_EMISSION_TEST(resolved);
    if (resolved)
    {
        BUSTER_EMISSION_TEST(source_rows[4].offset == 5 && source_rows[5].offset == 5);
        BUSTER_EMISSION_TEST(frame_rows[6].offset == 7 && source_rows[7].offset == 9);
        BUSTER_EMISSION_TEST(source_rows[8].offset == 10 && source_rows[9].offset == 13);
    }
}

static void test_failure(const EmissionMetadata* metadata, const EmissionLayout* layout, EmissionError error, EmissionPart part, uint32_t index)
{
    EmissionSourceRow sources[4];
    EmissionFrameRow frames[4];
    uint8_t before_sources[sizeof(sources)];
    uint8_t before_frames[sizeof(frames)];
    memset(sources, 0xa5, sizeof(sources));
    memset(frames, 0x5a, sizeof(frames));
    memcpy(before_sources, sources, sizeof(sources));
    memcpy(before_frames, frames, sizeof(frames));
    const EmissionStorage storage = {
        .sources = sources,
        .frames = frames,
        .source_capacity = 4,
        .frame_capacity = 4,
    };
    const EmissionResolved unchanged = {
        .sources = sources,
        .frames = frames,
        .source_count = 31,
        .frame_count = 37,
        .size = 41,
    };
    const EmissionMetadataPlan unplanned = {
        .source_count = 43,
        .frame_count = 47,
    };
    for (uint32_t scalar = 0; scalar < 2; scalar += 1)
    {
        EmissionResolved result = unchanged;
        EmissionMetadataPlan plan = unplanned;
        const EmissionCheck check = emission_metadata_resolve(metadata, layout, &storage, scalar != 0, &result);
        BUSTER_EMISSION_TEST(check.error == error && check.part == part && check.index == index);
        BUSTER_EMISSION_TEST(memcmp(sources, before_sources, sizeof(sources)) == 0 && memcmp(frames, before_frames, sizeof(frames)) == 0);
        BUSTER_EMISSION_TEST(result.sources == unchanged.sources && result.frames == unchanged.frames && result.source_count == unchanged.source_count && result.frame_count == unchanged.frame_count && result.size == unchanged.size);
        BUSTER_EMISSION_TEST(test_same_check(check, emission_metadata_plan(metadata, layout, scalar != 0, &plan)));
        BUSTER_EMISSION_TEST(plan.source_count == unplanned.source_count && plan.frame_count == unplanned.frame_count);
    }
}

static void test_invalid(void)
{
    uint32_t starts[] = { 0, 2, 4 };
    uint32_t ends[] = { 2, 3, 5 };
    EmissionLayout layout = {
        .starts = starts,
        .ends = ends,
        .count = 3,
        .size = 6,
    };
    EmissionSourceEvent sources[] = { test_origin(0, EMISSION_LEFT, 0), test_origin(1, EMISSION_RIGHT, 1) };
    EmissionFrameEvent frames[] = { test_frame(1, EMISSION_LEFT, EMISSION_FRAME_CFA, 7, 16), test_frame(3, EMISSION_LEFT, EMISSION_FRAME_RESTORE, 6, 0) };
    EmissionMetadata metadata = {
        .sources = sources,
        .frames = frames,
        .source_count = 2,
        .frame_count = 2,
        .origin_count = 2,
        .register_count = 17,
    };
    BUSTER_EMISSION_TEST(emission_metadata_check(&metadata, &layout, false).error == EMISSION_OK);
    starts[1] = 1;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_LAYOUT, 1);
    starts[1] = 2;
    ends[2] = 3;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_LAYOUT, 2);
    ends[2] = 7;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_LAYOUT, 2);
    ends[2] = 5;
    layout.starts = NULL;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_LAYOUT, 0);
    layout.starts = starts;
    layout.ends = NULL;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_LAYOUT, 0);
    layout.ends = ends;
    metadata.sources = NULL;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_DESCRIPTOR, 0);
    metadata.sources = sources;
    metadata.frames = NULL;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_DESCRIPTOR, 0);
    metadata.frames = frames;
    metadata.register_count = 0;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_DESCRIPTOR, 0);
    metadata.register_count = BUSTER_EMISSION_MAX_REGISTERS + 1;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_DESCRIPTOR, 0);
    metadata.register_count = 17;
    sources[0].at.side = EMISSION_RIGHT;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_SOURCE, 0);
    sources[0].at.side = EMISSION_LEFT;
    sources[1].at.boundary = 4;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_SOURCE, 1);
    sources[1].at.boundary = 1;
    sources[1].at.side = 2;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_SOURCE, 1);
    sources[1].at = sources[0].at;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_SOURCE, 1);
    sources[1] = test_origin(1, EMISSION_RIGHT, 2);
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_SOURCE, 1);
    sources[1].origin = BUSTER_EMISSION_NO_ORIGIN;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_SOURCE, 1);
    sources[1] = test_origin(1, EMISSION_RIGHT, 1);
    sources[1].kind = EMISSION_SOURCE_GENERATED;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_SOURCE, 1);
    sources[1].kind = 2;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_SOURCE, 1);
    sources[1] = test_origin(1, EMISSION_RIGHT, 1);
    frames[1].at.boundary = 4;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
    frames[1].at.boundary = 0;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
    frames[1].at.boundary = 3;
    frames[1].reserved = 1;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
    frames[1].reserved = 0;
    frames[1].kind = 255;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
    frames[1] = test_frame(3, EMISSION_LEFT, EMISSION_FRAME_RESTORE, 17, 0);
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
    frames[1] = test_frame(3, EMISSION_LEFT, EMISSION_FRAME_SAME_VALUE, 6, 1);
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
    frames[1] = test_frame(3, EMISSION_LEFT, EMISSION_FRAME_UNDEFINED, 6, 1);
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
    frames[1] = test_frame(3, EMISSION_LEFT, EMISSION_FRAME_CFA_OFFSET, 7, 16);
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
    frames[1] = test_frame(3, EMISSION_LEFT, EMISSION_FRAME_REGISTER, 6, -1);
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
    frames[1].value = 17;
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
    frames[1] = test_frame(3, EMISSION_LEFT, EMISSION_FRAME_RESTORE_STATE, 0, 0);
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
    frames[1] = test_frame(3, EMISSION_LEFT, EMISSION_FRAME_REMEMBER_STATE, 0, 0);
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 2);
    frames[0] = test_frame(1, EMISSION_LEFT, EMISSION_FRAME_REMEMBER_STATE, 1, 0);
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 0);
    frames[0] = test_frame(1, EMISSION_LEFT, EMISSION_FRAME_REMEMBER_STATE, 0, 0);
    frames[1] = test_frame(3, EMISSION_LEFT, EMISSION_FRAME_RESTORE_STATE, 0, 1);
    test_failure(&metadata, &layout, EMISSION_INVALID, EMISSION_FRAME, 1);
}

static void test_capacity(void)
{
    const uint32_t starts[] = { 0 };
    const uint32_t ends[] = { 1 };
    const EmissionLayout layout = {
        .starts = starts,
        .ends = ends,
        .count = 1,
        .size = 1,
    };
    const EmissionSourceEvent source = test_origin(0, EMISSION_LEFT, 0);
    const EmissionFrameEvent frame = test_frame(1, EMISSION_LEFT, EMISSION_FRAME_CFA_OFFSET, 0, 8);
    const EmissionMetadata metadata = {
        .sources = &source,
        .frames = &frame,
        .source_count = 1,
        .frame_count = 1,
        .origin_count = 1,
        .register_count = 17,
    };
    for (uint32_t which = 0; which < 4; which += 1)
    {
        EmissionSourceRow row = {
            .offset = 77,
            .origin = 88,
            .kind = 99,
        };
        EmissionFrameRow rule = {
            .offset = 11,
            .value = 22,
            .reg = 33,
            .kind = 44,
            .reserved = 55,
        };
        const EmissionStorage storage = {
            .sources = which == 2 ? NULL : &row,
            .frames = which == 3 ? NULL : &rule,
            .source_capacity = which == 0 ? 0 : 1,
            .frame_capacity = which == 1 ? 0 : 1,
        };
        EmissionResolved result = {
            .size = 123,
        };
        const EmissionCheck check = emission_metadata_resolve(&metadata, &layout, &storage, false, &result);
        BUSTER_EMISSION_TEST(check.error == (which < 2 ? EMISSION_CAPACITY : EMISSION_INVALID) && check.part == EMISSION_DESTINATION);
        BUSTER_EMISSION_TEST(row.offset == 77 && row.origin == 88 && row.kind == 99);
        BUSTER_EMISSION_TEST(rule.offset == 11 && rule.value == 22 && rule.reg == 33 && rule.kind == 44 && rule.reserved == 55);
        BUSTER_EMISSION_TEST(result.size == 123 && result.source_count == 0 && result.frame_count == 0);
    }
}

typedef struct TestGuard TestGuard;
struct TestGuard
{
    uint8_t* mapping;
    uint8_t* slice;
    size_t mapping_size;
    bool valid;
};

static TestGuard test_guard(size_t bytes)
{
    TestGuard guard = { 0 };
    const long page = sysconf(_SC_PAGESIZE);
    const bool page_valid = page > 0 && bytes <= (size_t)page;
    BUSTER_EMISSION_TEST(page_valid);
    if (page_valid)
    {
        const size_t size = 3 * (size_t)page;
        uint8_t* mapping = mmap(NULL, size, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        const bool mapped = mapping != MAP_FAILED;
        BUSTER_EMISSION_TEST(mapped);
        if (mapped)
        {
            const bool writable = mprotect(mapping + page, (size_t)page, PROT_READ | PROT_WRITE) == 0;
            BUSTER_EMISSION_TEST(writable);
            if (writable)
            {
                guard = (TestGuard){
                    .mapping = mapping,
                    .slice = mapping + 2 * page - bytes,
                    .mapping_size = size,
                    .valid = true,
                };
            }
            else
            {
                BUSTER_EMISSION_TEST(munmap(mapping, size) == 0);
            }
        }
    }
    return guard;
}

static void test_guard_release(TestGuard guard)
{
    if (guard.valid)
    {
        BUSTER_EMISSION_TEST(munmap(guard.mapping, guard.mapping_size) == 0);
    }
}

static void test_guarded_tails(void)
{
    const EmissionMetadata empty = { 0 };
    const EmissionMetadata missing_sources = { .source_count = 1 };
    const EmissionCheck no_layout = { .error = EMISSION_INVALID, .part = EMISSION_LAYOUT };
    const EmissionCheck no_metadata = { .error = EMISSION_INVALID, .part = EMISSION_DESCRIPTOR };
    BUSTER_EMISSION_TEST(test_same_check(emission_metadata_check(&empty, NULL, false), no_layout));
    for (uint32_t count = 0; count <= 65; count += 1)
    {
        const TestGuard sg = test_guard((size_t)count * sizeof(uint32_t));
        const TestGuard eg = test_guard((size_t)count * sizeof(uint32_t));
        const bool layout_guards = sg.valid && eg.valid;
        EmissionLayout layout = { 0 };
        if (layout_guards)
        {
            uint32_t* const starts = (uint32_t*)sg.slice;
            uint32_t* const ends = (uint32_t*)eg.slice;
            for (uint32_t i = 0; i < count; i += 1)
            {
                starts[i] = 4 * i;
                ends[i] = 4 * i + 2;
            }
            layout = (EmissionLayout){
                .starts = starts,
                .ends = ends,
                .count = count,
                .size = 4 * count,
            };
            for (uint32_t present = 0; present < 3; present += 1)
            {
                const EmissionLayout missing = {
                    .starts = (present & 1) != 0 ? starts : NULL,
                    .ends = (present & 2) != 0 ? ends : NULL,
                    .count = count,
                    .size = layout.size,
                };
                const EmissionCheck expected = count == 0 ? (EmissionCheck){ .error = EMISSION_OK } :
                                                          (EmissionCheck){ .error = EMISSION_INVALID, .part = EMISSION_LAYOUT };
                BUSTER_EMISSION_TEST(test_same_check(emission_metadata_check(&empty, &missing, false), expected));
                BUSTER_EMISSION_TEST(test_same_check(emission_metadata_check(&empty, &missing, true), expected));
                BUSTER_EMISSION_TEST(test_same_check(emission_metadata_check(&missing_sources, &missing, false), no_metadata));
            }
            const EmissionCheck valid_layout = emission_layout_check(&layout, false);
            BUSTER_EMISSION_TEST(valid_layout.error == EMISSION_OK && valid_layout.part == EMISSION_NONE);
            for (uint32_t i = 0; i < count; i += 1)
            {
                const uint32_t original = ends[i];
                ends[i] = UINT32_MAX;
                const EmissionCheck scalar = emission_layout_check(&layout, true);
                const EmissionCheck vector = emission_layout_check(&layout, false);
                BUSTER_EMISSION_TEST(test_same_check(scalar, vector) && scalar.error == EMISSION_INVALID && scalar.index == i);
                ends[i] = original;
            }
            // The other malformed-record rules across SIMD batch boundaries, not only the end-out-of-range rule above.
            for (uint32_t i = 1; i < count; i += 1)
            {
                const uint32_t original_start = starts[i];
                const uint32_t original_end = ends[i];
                starts[i] = 4 * i - 3;
                ends[i] = 4 * i - 1;
                const EmissionCheck scalar_start = emission_layout_check(&layout, true);
                const EmissionCheck vector_start = emission_layout_check(&layout, false);
                BUSTER_EMISSION_TEST(test_same_check(scalar_start, vector_start) && scalar_start.error == EMISSION_INVALID && scalar_start.index == i);
                starts[i] = original_start;
                ends[i] = original_end;
                starts[i] = 4 * i;
                ends[i] = 4 * i - 1;
                const EmissionCheck scalar_end = emission_layout_check(&layout, true);
                const EmissionCheck vector_end = emission_layout_check(&layout, false);
                BUSTER_EMISSION_TEST(test_same_check(scalar_end, vector_end) && scalar_end.error == EMISSION_INVALID && scalar_end.index == i);
                starts[i] = original_start;
                ends[i] = original_end;
            }
        }
        if (!layout_guards)
        {
            test_guard_release(sg);
            test_guard_release(eg);
            continue;
        }
        const TestGuard source_input = test_guard(sizeof(EmissionSourceEvent));
        const TestGuard frame_input = test_guard(2 * sizeof(EmissionFrameEvent));
        const TestGuard source_output = test_guard(sizeof(EmissionSourceRow));
        const TestGuard frame_output = test_guard(2 * sizeof(EmissionFrameRow));
        const bool event_guards = source_input.valid && frame_input.valid && source_output.valid && frame_output.valid;
        if (event_guards)
        {
            EmissionSourceEvent* source = (EmissionSourceEvent*)source_input.slice;
            EmissionFrameEvent* frames = (EmissionFrameEvent*)frame_input.slice;
            *source = test_origin(0, EMISSION_LEFT, BUSTER_EMISSION_NO_ORIGIN);
            frames[0] = test_frame(count, EMISSION_LEFT, EMISSION_FRAME_CFA, 7, 8);
            frames[1] = test_frame(count, EMISSION_RIGHT, EMISSION_FRAME_SAME_VALUE, 6, 0);
            const EmissionMetadata metadata = {
                .sources = source,
                .frames = frames,
                .source_count = 1,
                .frame_count = 2,
                .register_count = 17,
            };
            const EmissionStorage storage = {
                .sources = (EmissionSourceRow*)source_output.slice,
                .frames = (EmissionFrameRow*)frame_output.slice,
                .source_capacity = 1,
                .frame_capacity = 2,
            };
            EmissionResolved result;
            BUSTER_EMISSION_TEST(emission_metadata_resolve(&metadata, &layout, &storage, false, &result).error == EMISSION_OK);
            BUSTER_EMISSION_TEST(result.frames[0].offset == (count == 0 ? 0 : 4 * count - 2));
            BUSTER_EMISSION_TEST(result.frames[1].offset == layout.size);
        }
        test_guard_release(source_input);
        test_guard_release(frame_input);
        test_guard_release(source_output);
        test_guard_release(frame_output);
        test_guard_release(sg);
        test_guard_release(eg);
    }
}

static uint32_t test_random(uint32_t* state)
{
    uint32_t value = *state;
    value ^= value << 13;
    value ^= value >> 17;
    value ^= value << 5;
    *state = value;
    return value;
}

static void test_properties(uint32_t seed)
{
    for (uint32_t run = 0; run < 4096; run += 1)
    {
        uint32_t starts[97];
        uint32_t ends[97];
        EmissionSourceEvent sources[196];
        EmissionFrameEvent frames[196];
        EmissionSourceRow source_rows[2][196];
        EmissionFrameRow frame_rows[2][196];
        const uint32_t count = test_random(&seed) % 98;
        uint32_t size = run % 2 != 0 ? UINT32_MAX - 10000 : 0;
        for (uint32_t i = 0; i < count; i += 1)
        {
            size += test_random(&seed) % 8;
            starts[i] = size;
            size += test_random(&seed) % 16;
            ends[i] = size;
        }
        size += test_random(&seed) % 8;
        uint32_t events = 0;
        for (uint32_t boundary = 0; boundary <= count; boundary += 1)
        {
            for (uint32_t side = 0; side < 2; side += 1)
            {
                const uint32_t origin = test_random(&seed) % 9;
                sources[events] = test_origin(boundary, side, origin < 8 ? origin : BUSTER_EMISSION_NO_ORIGIN);
                frames[events] = test_frame(boundary, side, EMISSION_FRAME_CFA_OFFSET, 0, (int32_t)test_random(&seed));
                events += 1;
            }
        }
        const EmissionLayout layout = {
            .starts = starts,
            .ends = ends,
            .count = count,
            .size = size,
        };
        const EmissionMetadata metadata = {
            .sources = sources,
            .frames = frames,
            .source_count = events,
            .frame_count = events,
            .origin_count = 8,
            .register_count = 17,
        };
        bool resolved_all = true;
        for (uint32_t scalar = 0; scalar < 2; scalar += 1)
        {
            const EmissionStorage storage = {
                .sources = source_rows[scalar],
                .frames = frame_rows[scalar],
                .source_capacity = events,
                .frame_capacity = events,
            };
            EmissionResolved result;
            EmissionMetadataPlan plan;
            const bool planned = emission_metadata_plan(&metadata, &layout, scalar != 0, &plan).error == EMISSION_OK;
            BUSTER_EMISSION_TEST(planned);
            if (planned)
            {
                BUSTER_EMISSION_TEST(plan.source_count == events && plan.frame_count == events);
            }
            const bool resolved = emission_metadata_resolve(&metadata, &layout, &storage, scalar != 0, &result).error == EMISSION_OK;
            BUSTER_EMISSION_TEST(resolved);
            resolved_all &= resolved;
            if (!resolved)
            {
                continue;
            }
            for (uint32_t i = 0; i < events; i += 1)
            {
                const uint32_t boundary = i / 2;
                const uint32_t expected = i % 2 != 0 ? (boundary == count ? size : starts[boundary]) : (boundary == 0 ? 0 : ends[boundary - 1]);
                BUSTER_EMISSION_TEST(result.sources[i].offset == expected && result.frames[i].offset == expected);
                BUSTER_EMISSION_TEST(result.sources[i].origin == sources[i].origin && result.sources[i].kind == sources[i].kind);
                BUSTER_EMISSION_TEST(result.frames[i].value == frames[i].value && result.frames[i].reserved == 0);
            }
        }
        if (resolved_all)
        {
            BUSTER_EMISSION_TEST(memcmp(source_rows[0], source_rows[1], (size_t)events * sizeof(EmissionSourceRow)) == 0);
            BUSTER_EMISSION_TEST(memcmp(frame_rows[0], frame_rows[1], (size_t)events * sizeof(EmissionFrameRow)) == 0);
        }
    }
}

// The event vocabulary has no single fixed-allocation or single-epilogue assumption. These are protocol examples,
// not generated machine-code tests: instruction/CFG proof and independent DWARF checks remain integration work.
static void test_frame_vocabulary(void)
{
    const uint32_t starts[] = { 0, 1, 4, 8, 12, 16, 20, 24, 28 };
    const uint32_t ends[] = { 1, 4, 8, 12, 16, 20, 24, 28, 29 };
    const EmissionLayout layout = {
        .starts = starts,
        .ends = ends,
        .count = 9,
        .size = 32,
    };
    const EmissionFrameEvent frames[] = {
        {
            .at = {
                .boundary = 1,
                .side = EMISSION_LEFT,
            },
            .value = 16,
            .reg = 7,
            .kind = EMISSION_FRAME_CFA,
        },
        {
            .at = {
                .boundary = 1,
                .side = EMISSION_LEFT,
            },
            .value = -16,
            .reg = 6,
            .kind = EMISSION_FRAME_OFFSET,
        },
        {
            .at = {
                .boundary = 2,
                .side = EMISSION_LEFT,
            },
            .value = 16,
            .reg = 6,
            .kind = EMISSION_FRAME_CFA,
        },
        {
            .at = {
                .boundary = 3,
                .side = EMISSION_LEFT,
            },
            .value = -4096,
            .reg = 12,
            .kind = EMISSION_FRAME_OFFSET,
        },
        {
            .at = {
                .boundary = 4,
                .side = EMISSION_LEFT,
            },
            .kind = EMISSION_FRAME_REMEMBER_STATE,
        },
        {
            .at = {
                .boundary = 5,
                .side = EMISSION_LEFT,
            },
            .reg = 12,
            .kind = EMISSION_FRAME_RESTORE,
        },
        {
            .at = {
                .boundary = 5,
                .side = EMISSION_LEFT,
            },
            .reg = 6,
            .kind = EMISSION_FRAME_RESTORE,
        },
        {
            .at = {
                .boundary = 5,
                .side = EMISSION_LEFT,
            },
            .value = 8,
            .reg = 7,
            .kind = EMISSION_FRAME_CFA,
        },
        {
            .at = {
                .boundary = 6,
                .side = EMISSION_LEFT,
            },
            .kind = EMISSION_FRAME_RESTORE_STATE,
        },
        {
            .at = {
                .boundary = 7,
                .side = EMISSION_LEFT,
            },
            .value = 13,
            .reg = 12,
            .kind = EMISSION_FRAME_REGISTER,
        },
        {
            .at = {
                .boundary = 8,
                .side = EMISSION_LEFT,
            },
            .reg = 12,
            .kind = EMISSION_FRAME_SAME_VALUE,
        },
        {
            .at = {
                .boundary = 9,
                .side = EMISSION_RIGHT,
            },
            .reg = 16,
            .kind = EMISSION_FRAME_UNDEFINED,
        },
    };
    const EmissionMetadata metadata = {
        .frames = frames,
        .frame_count = 12,
        .register_count = 17,
    };
    EmissionFrameRow rows[12];
    const EmissionStorage storage = {
        .frames = rows,
        .frame_capacity = 12,
    };
    EmissionResolved result;
    BUSTER_EMISSION_TEST(emission_metadata_resolve(&metadata, &layout, &storage, false, &result).error == EMISSION_OK);
    BUSTER_EMISSION_TEST(result.source_count == 0 && result.sources == NULL && result.frame_count == 12);
    BUSTER_EMISSION_TEST(rows[3].value == -4096 && rows[8].offset == 20 && rows[11].offset == 32);
    EmissionFrameEvent probes[] = {
        test_frame(1, EMISSION_LEFT, EMISSION_FRAME_CFA_OFFSET, 0, 4104),
        test_frame(2, EMISSION_LEFT, EMISSION_FRAME_CFA_OFFSET, 0, 8200),
        test_frame(3, EMISSION_LEFT, EMISSION_FRAME_CFA_OFFSET, 0, 12296),
    };
    const EmissionMetadata probed = {
        .frames = probes,
        .frame_count = 3,
        .register_count = 17,
    };
    BUSTER_EMISSION_TEST(emission_metadata_resolve(&probed, &layout, &storage, false, &result).error == EMISSION_OK);
    BUSTER_EMISSION_TEST(rows[0].value == 4104 && rows[1].value == 8200 && rows[2].value == 12296);
}

static void test_limits_and_state_stack(void)
{
    const EmissionLayout layout = {
        .size = UINT32_MAX,
    };
    EmissionSourceEvent source = test_origin(0, EMISSION_LEFT, UINT32_MAX - 1);
    EmissionFrameEvent frames[] = {
        test_frame(0, EMISSION_LEFT, EMISSION_FRAME_REMEMBER_STATE, 0, 0),
        test_frame(0, EMISSION_LEFT, EMISSION_FRAME_REMEMBER_STATE, 0, 0),
        test_frame(0, EMISSION_LEFT, EMISSION_FRAME_OFFSET, UINT16_MAX, INT32_MIN),
        test_frame(0, EMISSION_RIGHT, EMISSION_FRAME_RESTORE_STATE, 0, 0),
        test_frame(0, EMISSION_RIGHT, EMISSION_FRAME_RESTORE_STATE, 0, 0),
    };
    EmissionMetadata metadata = {
        .sources = &source,
        .frames = frames,
        .source_count = 1,
        .frame_count = 5,
        .origin_count = UINT32_MAX,
        .register_count = BUSTER_EMISSION_MAX_REGISTERS,
    };
    EmissionSourceRow source_row;
    EmissionFrameRow frame_rows[5];
    const EmissionStorage storage = {
        .sources = &source_row,
        .frames = frame_rows,
        .source_capacity = 1,
        .frame_capacity = 5,
    };
    EmissionResolved result;
    BUSTER_EMISSION_TEST(emission_metadata_resolve(&metadata, &layout, &storage, false, &result).error == EMISSION_OK);
    BUSTER_EMISSION_TEST(frame_rows[2].reg == UINT16_MAX && frame_rows[2].value == INT32_MIN && frame_rows[4].offset == UINT32_MAX);
    BUSTER_EMISSION_TEST(source_row.origin == UINT32_MAX - 1 && result.size == UINT32_MAX);
    metadata.register_count -= 1;
    const EmissionCheck invalid_register = emission_metadata_check(&metadata, &layout, false);
    BUSTER_EMISSION_TEST(invalid_register.error == EMISSION_INVALID && invalid_register.part == EMISSION_FRAME && invalid_register.index == 2);
    metadata.register_count += 1;
    frames[4].kind = EMISSION_FRAME_UNDEFINED;
    const EmissionCheck leaked_state = emission_metadata_check(&metadata, &layout, false);
    BUSTER_EMISSION_TEST(leaked_state.error == EMISSION_INVALID && leaked_state.part == EMISSION_FRAME && leaked_state.index == 5);
    frames[1].kind = EMISSION_FRAME_RESTORE_STATE;
    const EmissionCheck underflow = emission_metadata_check(&metadata, &layout, false);
    BUSTER_EMISSION_TEST(underflow.error == EMISSION_INVALID && underflow.part == EMISSION_FRAME && underflow.index == 3);
}

// A destination with spare capacity must receive exactly the planned rows; the bytes after them stay untouched.
static void test_capacity_spare(void)
{
    const uint32_t starts[] = { 0 };
    const uint32_t ends[] = { 1 };
    const EmissionLayout layout = {
        .starts = starts,
        .ends = ends,
        .count = 1,
        .size = 1,
    };
    const EmissionSourceEvent source = test_origin(0, EMISSION_LEFT, 0);
    const EmissionFrameEvent frame = test_frame(1, EMISSION_LEFT, EMISSION_FRAME_CFA_OFFSET, 0, 8);
    const EmissionMetadata metadata = {
        .sources = &source,
        .frames = &frame,
        .source_count = 1,
        .frame_count = 1,
        .origin_count = 1,
        .register_count = 17,
    };
    EmissionSourceRow sources[4];
    EmissionSourceRow source_pattern[4];
    EmissionFrameRow frames[4];
    EmissionFrameRow frame_pattern[4];
    memset(sources, 0xa5, sizeof(sources));
    memset(source_pattern, 0xa5, sizeof(source_pattern));
    memset(frames, 0x5a, sizeof(frames));
    memset(frame_pattern, 0x5a, sizeof(frame_pattern));
    const EmissionStorage storage = {
        .sources = sources,
        .frames = frames,
        .source_capacity = 4,
        .frame_capacity = 4,
    };
    EmissionResolved result;
    const EmissionCheck check = emission_metadata_resolve(&metadata, &layout, &storage, false, &result);
    BUSTER_EMISSION_TEST(check.error == EMISSION_OK && check.part == EMISSION_NONE);
    BUSTER_EMISSION_TEST(result.sources == sources && result.frames == frames && result.source_count == 1 && result.frame_count == 1 && result.size == 1);
    BUSTER_EMISSION_TEST(sources[0].offset == 0 && sources[0].origin == 0 && sources[0].kind == EMISSION_SOURCE_ORIGIN);
    BUSTER_EMISSION_TEST(frames[0].offset == 1 && frames[0].value == 8 && frames[0].reg == 0 && frames[0].kind == EMISSION_FRAME_CFA_OFFSET);
    BUSTER_EMISSION_TEST(memcmp(sources + 1, source_pattern + 1, 3 * sizeof(EmissionSourceRow)) == 0);
    BUSTER_EMISSION_TEST(memcmp(frames + 1, frame_pattern + 1, 3 * sizeof(EmissionFrameRow)) == 0);
}

// Values, unlike code offsets, are signed 64-bit: retain both CFA magnitudes and negative saved-slot offsets.
static void test_wide_frame_values(void)
{
    const uint32_t starts[] = { 0 };
    const uint32_t ends[] = { 1 };
    const EmissionLayout layout = { .starts = starts, .ends = ends, .count = 1, .size = 1 };
    const int64_t values[] = { INT32_MAX, INT64_C(2147483648), INT64_C(2147483703), INT64_MAX, INT32_MIN, INT64_C(-2147483703), INT64_MIN };
    EmissionFrameEvent events[(sizeof(values) / sizeof(values[0]))];
    for (uint32_t i = 0; i < (sizeof(values) / sizeof(values[0])); i += 1)
    {
        events[i] = test_frame(1, EMISSION_LEFT, values[i] >= 0 ? EMISSION_FRAME_CFA_OFFSET : EMISSION_FRAME_OFFSET, values[i] >= 0 ? 0 : 3, values[i]);
    }
    const EmissionMetadata metadata = { .frames = events, .frame_count = (sizeof(events) / sizeof(events[0])), .register_count = BUSTER_EMISSION_X86_REGISTERS };
    EmissionFrameRow rows[2][(sizeof(values) / sizeof(values[0]))];
    memset(rows, 0xa5, sizeof(rows));
    for (uint32_t scalar = 0; scalar < 2; scalar += 1)
    {
        const EmissionStorage storage = { .frames = rows[scalar], .frame_capacity = (sizeof(values) / sizeof(values[0])) };
        EmissionResolved resolved;
        BUSTER_EMISSION_TEST(emission_metadata_resolve(&metadata, &layout, &storage, scalar != 0, &resolved).error == EMISSION_OK);
        for (uint32_t i = 0; i < (sizeof(values) / sizeof(values[0])); i += 1)
        {
            BUSTER_EMISSION_TEST(rows[scalar][i].value == values[i] && rows[scalar][i].offset == 1);
        }
        events[0] = test_frame(1, EMISSION_LEFT, EMISSION_FRAME_REGISTER, 3, INT64_C(0x100000006));
        const EmissionCheck bad = emission_metadata_check(&metadata, &layout, scalar != 0);
        BUSTER_EMISSION_TEST(bad.error == EMISSION_INVALID && bad.part == EMISSION_FRAME && bad.index == 0);
        events[0] = test_frame(1, EMISSION_LEFT, EMISSION_FRAME_CFA_OFFSET, 0, values[0]);
    }
    BUSTER_EMISSION_TEST(memcmp(rows[0], rows[1], sizeof(rows[0])) == 0);
}

int run_emission_metadata_tests(int argc, char** argv)
{
    uint32_t seed = 1056;
    bool valid = true;
    for (int argument = 0; argument < argc; argument += 1)
    {
        if (strcmp(argv[argument], "--seed") == 0 && argument + 1 < argc)
        {
            char* end = 0;
            errno = 0;
            const unsigned long long parsed = strtoull(argv[argument + 1], &end, 10);
            const bool parsed_ok = argv[argument + 1][0] >= '0' && argv[argument + 1][0] <= '9' && end != argv[argument + 1] && *end == 0 && errno == 0 && parsed <= UINT32_MAX;
            valid = valid && parsed_ok;
            if (parsed_ok)
            {
                seed = (uint32_t)parsed;
            }
            argument += 1;
        }
        else
        {
            valid = false;
        }
    }
    int result = 1;
    if (!valid)
    {
        fprintf(stderr, "usage: test-emission-metadata [--seed N]\n");
    }
    else
    {
        test_tally = (EmissionMetadataTestTally){ 0 };
        test_empty();
        test_layouts();
        test_invalid();
        test_capacity();
        test_capacity_spare();
        test_guarded_tails();
        test_properties(seed);
        test_frame_vocabulary();
        test_limits_and_state_stack();
        test_wide_frame_values();
        const uint32_t vector = 1;
        printf("emission metadata: %" PRIu64 " checks, %" PRIu64 " failures (vector=%u, seed=%u)\n",
            test_tally.checks, test_tally.failures, vector, seed);
        result = test_tally.failures == 0 ? 0 : 1;
    }
    return result;
}

#if defined(BUSTER_EMISSION_METADATA_TEST_STANDALONE)
int main(int argc, char** argv)
{
    return run_emission_metadata_tests(argc - 1, argv + 1);
}
#endif
