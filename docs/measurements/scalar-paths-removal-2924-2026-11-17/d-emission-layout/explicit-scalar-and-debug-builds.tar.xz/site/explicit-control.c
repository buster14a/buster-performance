#include "decl.h"
#include <stdio.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
typedef EmissionCheck Validator(const EmissionMetadata*,const EmissionLayout*,bool);
extern Validator base,control;
static uint64_t ticks(void){_mm_lfence();uint64_t v=__rdtsc();_mm_lfence();return v;}
static int cmp(const void* a,const void* b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return (x>y)-(x<y);}
static int equal(EmissionCheck a,EmissionCheck b){return a.error==b.error&&a.index==b.index&&a.part==b.part;}
int main(int argc,char**argv){
 EmissionMetadata metadata={0};
 unsigned sizes[180],count=0;for(unsigned i=0;i<=128;i++)sizes[count++]=i;
 for(unsigned i=256;i<=8192;i*=2)for(int delta=-2;delta<=2;delta++)sizes[count++]=i+delta;
 size_t page=(size_t)sysconf(_SC_PAGESIZE),extent=10*page;
 unsigned char* src[2];for(unsigned i=0;i<2;i++){src[i]=mmap(NULL,extent,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(src[i]==MAP_FAILED||mprotect(src[i]+extent-page,page,PROT_NONE))return 2;}
 uint64_t sink=0,checks=0;int timed=argc>1&&!strcmp(argv[1],"time");
 for(unsigned z=0;z<count;z++)for(unsigned shape=0;shape<14;shape++)for(unsigned phase=0;phase<(timed?1u:16u);phase++){
  unsigned n=sizes[z],pivot=n?(shape==6||shape==9?0:shape==7||shape==10?n/2:n-1):0;
  unsigned slack=argc>2?64:0;
  uint32_t* st=(uint32_t*)(src[0]+extent-page)-n-phase-slack,*en=(uint32_t*)(src[1]+extent-page)-n-phase-slack;
  uint32_t off=phase%2?UINT32_MAX-4*n:0;
  for(unsigned i=0;i<n;i++){st[i]=off+4*i;en[i]=st[i]+(shape==5?0:2);}
  EmissionLayout l={.count=n,.starts=st,.ends=en,.size=off+4*n};EmissionCheck expected={.error=EMISSION_OK};
  if(shape==1||shape==3)l.starts=NULL;if(shape==2||shape==3)l.ends=NULL;
  if(shape==4||((shape>=1&&shape<=3)&&n))expected=(EmissionCheck){.error=EMISSION_INVALID,.part=EMISSION_LAYOUT};
  if(shape==13&&n){
   unsigned first=n>16?15:n/2;st[first]=en[first]+1;if(first+1<n)en[first+1]=0;
   expected=(EmissionCheck){.error=EMISSION_INVALID,.part=EMISSION_LAYOUT,.index=first};
  }
  if(shape>=6&&shape<13&&n){
   if(shape<9){st[pivot]=en[pivot]+1;}else if(shape<12){if(pivot){st[pivot]=en[pivot-1]-1;}else en[pivot]=st[pivot]+3;}
   else{l.size=en[pivot]-1;}
   if(shape<9||pivot||shape==12)expected=(EmissionCheck){.error=EMISSION_INVALID,.part=EMISSION_LAYOUT,.index=pivot};
  }
  const EmissionLayout* layout=shape==4?NULL:&l;Validator* fn[]={base,base,control};
  for(unsigned side=0;side<3;side++){EmissionCheck x=fn[side](&metadata,layout,side==0);if(!equal(x,expected)){fprintf(stderr,"case %u %u %u side %u got %u %u %u expected %u %u %u\n",n,shape,phase,side,x.error,x.part,x.index,expected.error,expected.part,expected.index);return 1;}checks++;}
  if(timed){uint64_t times[3][11];unsigned reps=60+2400/(n/4+1);
   for(unsigned r=0;r<11;r++)for(unsigned m=0;m<2;m++){unsigned side=1+((r+m)&1);uint64_t start=ticks();for(unsigned j=0;j<reps;j++){EmissionCheck v=fn[side](&metadata,layout,side==1);sink+=v.index+v.part+v.error;}times[side][r]=ticks()-start;}
   for(unsigned side=1;side<3;side++)qsort(times[side],11,sizeof(uint64_t),cmp);
   printf("%u %u %u %lu %lu %lu\n",shape,n,reps,0ul,times[1][5],times[2][5]);
  }
 }
 fprintf(stderr,"%lu independent outcome comparisons passed; sink %lu\n",checks,sink);
}
