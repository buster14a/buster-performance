#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <immintrin.h>
#define BUSTER_EMISSION_NO_ORIGIN UINT32_MAX
#define BUSTER_EMISSION_MAX_REGISTERS 65536u
#define BUSTER_EMISSION_LAYOUT_LANES 16u

// The x86-64 target's unwind-register namespace: the System V psABI's DWARF numbers (rax 0, rdx 1, rcx 2, rbx 3, rsi 4,
// rdi 5, rbp 6, rsp 7, r8 to r15 8 to 15, and the return address 16), which its frame events name and its CIE's rules
// start from. emission_x86_registers maps the encoder's numbering (rax, rcx, rdx, rbx, rsp, rbp, rsi, rdi, r8 to r15)
// to it. The other targets' namespaces would be theirs; this is the only one the compiler has.
#define BUSTER_EMISSION_X86_REGISTERS 17u
#define BUSTER_EMISSION_X86_RBP 6u
#define BUSTER_EMISSION_X86_RSP 7u
#define BUSTER_EMISSION_X86_RETURN 16u
static const uint8_t emission_x86_registers[16] __attribute__((unused)) = { 0, 2, 1, 3, 7, 6, 4, 5, 8, 9, 10, 11, 12, 13, 14, 15 };
// Past them, the vector and mask registers a frame may save for its caller (#147, a preserving frame's): xmm0 to xmm15
// (17 to 32), xmm16 to xmm31 (67 to 82) and k0 to k7 (118 to 125), whose rules say where a slot holds one or that it
// holds its caller's value; the namespace's frame events count to the last.
#define BUSTER_EMISSION_X86_DWARF_REGISTERS 126u

// Whether `reg` is one of the vector or mask registers' DWARF numbers a frame's rules may name past the general ones.
static __attribute__((unused)) bool emission_x86_saved_vector(uint32_t reg)
{
    return (reg >= 17 && reg <= 32) || (reg >= 67 && reg <= 82) || (reg >= 118 && reg <= 125);
}

typedef enum EmissionError
{
    EMISSION_OK,
    EMISSION_INVALID,
    EMISSION_CAPACITY,
} EmissionError;

typedef enum EmissionPart
{
    EMISSION_NONE,
    EMISSION_DESCRIPTOR,
    EMISSION_LAYOUT,
    EMISSION_SOURCE,
    EMISSION_FRAME,
    EMISSION_DESTINATION,
} EmissionPart;

// On success, part is EMISSION_NONE and index is 0. Descriptor and destination errors report index 0; layout, source
// and frame errors report the first failing record or event, and an unbalanced final state stack reports frame_count.
typedef struct EmissionCheck EmissionCheck;
struct EmissionCheck
{
    EmissionError error;
    EmissionPart part;
    uint32_t index;
};

typedef enum EmissionSide
{
    EMISSION_LEFT,
    EMISSION_RIGHT,
} EmissionSide;

typedef struct EmissionAnchor EmissionAnchor;
struct EmissionAnchor
{
    uint32_t boundary;
    uint32_t side;
};

typedef struct EmissionLayout EmissionLayout;
struct EmissionLayout
{
    const uint32_t* starts;
    const uint32_t* ends;
    uint32_t count;
    uint32_t size;
};

typedef enum EmissionSourceKind
{
    EMISSION_SOURCE_ORIGIN,
    EMISSION_SOURCE_GENERATED,
} EmissionSourceKind;

typedef struct EmissionSourceEvent EmissionSourceEvent;
struct EmissionSourceEvent
{
    EmissionAnchor at;
    uint32_t origin;
    uint32_t kind;
};

// Register numbers are the output ABI's unwind-register numbers, not an encoder's register numbering. RESTORE means
// the CIE's initial rule, SAME_VALUE means the current register, and REGISTER names the holding register in value.
// CFA/CFA_OFFSET and OFFSET carry signed 64-bit byte offsets. This protocol does not assume eight-byte slots. A target
// writer may still refuse a rule it cannot encode. No expression or target-specific opcode is accepted implicitly.
typedef enum EmissionFrameKind
{
    EMISSION_FRAME_CFA,
    EMISSION_FRAME_CFA_OFFSET,
    EMISSION_FRAME_OFFSET,
    EMISSION_FRAME_REGISTER,
    EMISSION_FRAME_RESTORE,
    EMISSION_FRAME_SAME_VALUE,
    EMISSION_FRAME_UNDEFINED,
    EMISSION_FRAME_REMEMBER_STATE,
    EMISSION_FRAME_RESTORE_STATE,
} EmissionFrameKind;

typedef struct EmissionFrameEvent EmissionFrameEvent;
struct EmissionFrameEvent
{
    EmissionAnchor at;
    int64_t value;
    uint16_t reg;
    uint8_t kind;
    uint8_t reserved;
};

typedef struct EmissionMetadata EmissionMetadata;
struct EmissionMetadata
{
    const EmissionSourceEvent* sources;
    const EmissionFrameEvent* frames;
    uint32_t source_count;
    uint32_t frame_count;
    // Origin IDs index the producer's source-origin table; UINT32_MAX is reserved for generated code.
    uint32_t origin_count;
    // The target's unwind-register namespace. Required only when frame events are present.
    uint32_t register_count;
};

typedef struct EmissionMetadataPlan EmissionMetadataPlan;
struct EmissionMetadataPlan
{
    uint32_t source_count;
    uint32_t frame_count;
};

typedef struct EmissionSourceRow EmissionSourceRow;
struct EmissionSourceRow
{
    uint32_t offset;
    uint32_t origin;
    uint32_t kind;
};

typedef struct EmissionFrameRow EmissionFrameRow;
// Keep the resolved row padding-free: fixed-shape recognition compares complete rows.
struct EmissionFrameRow
{
    uint32_t offset;
    uint16_t reg;
    uint8_t kind;
    uint8_t reserved;
    int64_t value;
};
_Static_assert(sizeof(EmissionFrameRow) == 16, "resolved frame rows have no padding");

typedef struct EmissionStorage EmissionStorage;
struct EmissionStorage
{
    EmissionSourceRow* sources;
    EmissionFrameRow* frames;
    uint32_t source_capacity;
    uint32_t frame_capacity;
};

typedef struct EmissionResolved EmissionResolved;
struct EmissionResolved
{
    const EmissionSourceRow* sources;
    const EmissionFrameRow* frames;
    uint32_t source_count;
    uint32_t frame_count;
    uint32_t size;
};

