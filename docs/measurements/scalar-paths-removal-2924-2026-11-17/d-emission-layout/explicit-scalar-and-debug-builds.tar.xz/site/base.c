#include "decl.h"
static EmissionCheck emission_layout_check_scalar(const EmissionLayout* layout)
{
    EmissionCheck check = {
        .error = EMISSION_INVALID,
        .part = EMISSION_LAYOUT,
    };
    if (layout != NULL && (layout->count == 0 || (layout->starts != NULL && layout->ends != NULL)))
    {
        const uint32_t count = layout->count;
        const uint32_t size = layout->size;
        const uint32_t* const starts = layout->starts;
        const uint32_t* const ends = layout->ends;
        uint32_t previous = 0;
        check.error = EMISSION_OK;
        check.part = EMISSION_NONE;
        for (uint32_t i = 0; check.error == EMISSION_OK && i < count; i += 1)
        {
            const uint32_t start = starts[i];
            const uint32_t end = ends[i];
            if (start < previous || end < start || end > size)
            {
                check.error = EMISSION_INVALID;
                check.part = EMISSION_LAYOUT;
                check.index = i;
            }
            previous = end;
        }
    }
    return check;
}

// Contiguous validation only: sparse event-to-record resolution below uses scalar loads rather than AVX-512 gathers.
// The same first invalid record as the exact path, including errors at a batch boundary. Masked tails need no slack.
static EmissionCheck emission_layout_check(const EmissionLayout* layout, bool scalar)
{
    EmissionCheck check;
    if (scalar || layout == NULL || (layout->count != 0 && (layout->starts == NULL || layout->ends == NULL)))
    {
        check = emission_layout_check_scalar(layout);
    }
    else
    {
        const uint32_t count = layout->count;
        const uint32_t size = layout->size;
        const uint32_t* const starts = layout->starts;
        const uint32_t* const ends = layout->ends;
        const __m512i limit = _mm512_set1_epi32((int32_t)size);
        uint32_t previous = 0;
        check = (EmissionCheck){
            .error = EMISSION_OK,
            .part = EMISSION_NONE,
        };
        for (uint64_t base = 0; check.error == EMISSION_OK && base < count; base += BUSTER_EMISSION_LAYOUT_LANES)
        {
            const uint32_t take = count - base < BUSTER_EMISSION_LAYOUT_LANES ? (uint32_t)(count - base) : BUSTER_EMISSION_LAYOUT_LANES;
            const __mmask16 valid = (__mmask16)((1u << take) - 1u);
            const __m512i start = _mm512_maskz_loadu_epi32(valid, starts + base);
            const __m512i end = _mm512_maskz_loadu_epi32(valid, ends + base);
            const __m512i before = _mm512_mask_mov_epi32(_mm512_alignr_epi32(end, end, 15), 1, _mm512_set1_epi32((int32_t)previous));
            const __mmask16 bad = _mm512_mask_cmplt_epu32_mask(valid, start, before) |
                                  _mm512_mask_cmplt_epu32_mask(valid, end, start) |
                                  _mm512_mask_cmpgt_epu32_mask(valid, end, limit);
            if (bad != 0)
            {
                check.error = EMISSION_INVALID;
                check.part = EMISSION_LAYOUT;
                check.index = (uint32_t)base + (uint32_t)__builtin_ctz((uint32_t)bad);
            }
            else
            {
                previous = ends[base + take - 1];
            }
        }
    }
    return check;
}

static bool emission_anchor_valid(EmissionAnchor at, uint32_t count)
{
    return at.boundary <= count && at.side <= EMISSION_RIGHT;
}

static bool emission_anchor_before(EmissionAnchor a, EmissionAnchor b)
{
    return a.boundary < b.boundary || (a.boundary == b.boundary && a.side < b.side);
}

// Called only after the layout and this anchor have been checked. Never reads a count+1 sentinel or an empty slice.
static uint32_t emission_anchor_offset(const EmissionLayout* layout, EmissionAnchor at)
{
    uint32_t offset;
    if (at.side == EMISSION_LEFT)
    {
        offset = at.boundary == 0 ? 0 : layout->ends[at.boundary - 1];
    }
    else
    {
        offset = at.boundary == layout->count ? layout->size : layout->starts[at.boundary];
    }
    return offset;
}

static EmissionCheck emission_metadata_check(const EmissionMetadata* metadata, const EmissionLayout* layout, bool scalar)
{
    EmissionCheck check = {
        .error = EMISSION_INVALID,
        .part = EMISSION_DESCRIPTOR,
    };
    if (metadata != NULL)
    {
        const uint32_t sources = metadata->source_count;
        const uint32_t frames = metadata->frame_count;
        const uint32_t origins = metadata->origin_count;
        const uint32_t registers = metadata->register_count;
        const EmissionSourceEvent* const source_events = metadata->sources;
        const EmissionFrameEvent* const frame_events = metadata->frames;
        if ((sources == 0 || source_events != NULL) && (frames == 0 || frame_events != NULL) &&
            registers <= BUSTER_EMISSION_MAX_REGISTERS && (frames == 0 || registers != 0))
        {
            check = emission_layout_check(layout, scalar);
            const uint32_t count = check.error == EMISSION_OK ? layout->count : 0;
            EmissionAnchor previous = { 0 };
            for (uint32_t i = 0; check.error == EMISSION_OK && i < sources; i += 1)
            {
                const EmissionSourceEvent event = source_events[i];
                const bool origin = event.kind == EMISSION_SOURCE_ORIGIN && event.origin < origins && event.origin != BUSTER_EMISSION_NO_ORIGIN;
                const bool generated = event.kind == EMISSION_SOURCE_GENERATED && event.origin == BUSTER_EMISSION_NO_ORIGIN;
                // A present source map explicitly describes the start, including a generated prologue or leading padding.
                const bool order = i == 0 ? event.at.boundary == 0 && event.at.side == EMISSION_LEFT : emission_anchor_before(previous, event.at);
                if (!emission_anchor_valid(event.at, count) || !order || (!origin && !generated))
                {
                    check = (EmissionCheck){
                        .error = EMISSION_INVALID,
                        .part = EMISSION_SOURCE,
                        .index = i,
                    };
                }
                previous = event.at;
            }
            previous = (EmissionAnchor){ 0 };
            uint32_t depth = 0;
            for (uint32_t i = 0; check.error == EMISSION_OK && i < frames; i += 1)
            {
                const EmissionFrameEvent event = frame_events[i];
                bool valid = emission_anchor_valid(event.at, count) && !emission_anchor_before(event.at, previous) && event.reserved == 0;
                switch (event.kind)
                {
                    case EMISSION_FRAME_CFA:
                    case EMISSION_FRAME_OFFSET:
                    {
                        valid &= event.reg < registers;
                    } break;
                    case EMISSION_FRAME_CFA_OFFSET:
                    {
                        valid &= event.reg == 0;
                    } break;
                    case EMISSION_FRAME_REGISTER:
                    {
                        valid &= event.reg < registers && event.value >= 0 && event.value < registers;
                    } break;
                    case EMISSION_FRAME_RESTORE:
                    case EMISSION_FRAME_SAME_VALUE:
                    case EMISSION_FRAME_UNDEFINED:
                    {
                        valid &= event.reg < registers && event.value == 0;
                    } break;
                    case EMISSION_FRAME_REMEMBER_STATE:
                    {
                        valid &= event.reg == 0 && event.value == 0;
                        depth += 1;
                    } break;
                    case EMISSION_FRAME_RESTORE_STATE:
                    {
                        valid &= event.reg == 0 && event.value == 0 && depth != 0;
                        depth -= depth != 0;
                    } break;
                    default:
                    {
                        valid = false;
                    } break;
                }
                if (!valid)
                {
                    check = (EmissionCheck){
                        .error = EMISSION_INVALID,
                        .part = EMISSION_FRAME,
                        .index = i,
                    };
                }
                previous = event.at;
            }
            if (check.error == EMISSION_OK && depth != 0)
            {
                check = (EmissionCheck){
                    .error = EMISSION_INVALID,
                    .part = EMISSION_FRAME,
                    .index = frames,
                };
            }
            if (check.error == EMISSION_OK)
            {
                check.part = EMISSION_NONE;
            }
        }
    }
    return check;
}

EmissionCheck base(const EmissionMetadata* m,const EmissionLayout* v,bool scalar){return emission_metadata_check(m,v,scalar);}
