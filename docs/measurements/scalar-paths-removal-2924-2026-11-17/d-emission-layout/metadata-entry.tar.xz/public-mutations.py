from pathlib import Path
import os,subprocess,tempfile
p=Path(__file__).parent; d=p/'unit-caller';cc=os.getenv('CC','clang-22')
total=0
for side in ['caller','compact']:
 base=(d/(side+'.c')).read_text()
 pairs=[
 ('starts', '(layout->starts != NULL && layout->ends != NULL)', '(layout->ends != NULL)'),
 ('ends','(layout->starts != NULL && layout->ends != NULL)','(layout->starts != NULL)'),
 ('empty','layout->count == 0 || (layout->starts != NULL && layout->ends != NULL)','layout->starts != NULL && layout->ends != NULL'),
 ('overlap','_mm512_mask_cmplt_epu32_mask(valid, start, before)','0'),
 ('reversed','_mm512_mask_cmplt_epu32_mask(valid, end, start)','0'),
 ('bounds','_mm512_mask_cmpgt_epu32_mask(valid, end, limit)','0'),
 ('index','(uint32_t)base + (uint32_t)__builtin_ctz((uint32_t)bad)','(uint32_t)base'),
 ('part','check.part = '+('EMISSION_LAYOUT' if side=='caller' else 'descriptor_valid ? EMISSION_LAYOUT : EMISSION_DESCRIPTOR')+';', 'check.part = EMISSION_DESCRIPTOR;')]
 with tempfile.TemporaryDirectory() as tmp:
  t=Path(tmp)
  for name,old,new in [('baseline','','')]+pairs:
   src=base
   if name!='baseline':
    if name=='part' and side=='caller':
     old += '\n            if (layout != NULL'
     new += '\n            if (layout != NULL'
    assert src.count(old)==1,(side,name,src.count(old),old)
    src=src.replace(old,new)
   (t/'variant.c').write_text(src)
   subprocess.run([cc,'-O1','-g','-march=native','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(d),str(d/'base.c'),str(t/'variant.c'),str(d/('pair-'+side+'.c')),'-o',str(t/'check')],check=True)
   run=subprocess.run([str(t/'check')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   s=run.stdout.decode(errors='replace')
   assert (run.returncode==0)==(name=='baseline'),(side,name,run.returncode,s[:220])
   print(side,name,run.returncode,next((l for l in s.splitlines() if 'case ' in l or 'AddressSanitizer' in l or 'comparisons passed' in l or 'runtime error' in l),''),flush=True)
   total+=name!='baseline'
assert total==16
