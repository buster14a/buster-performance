#define CHECK(x) #x
CHECK(u8'b') CHECK(u"one") CHECK(U't')
CHECK(u8'') CHECK(u'') CHECK(U'')
CHECK(u\
8'c') CHECK(U\
"three")
