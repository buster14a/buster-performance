from pathlib import Path
p=Path('src/buster/compiler/c_preprocessor.c');s=p.read_text()
a=s.index('static uint32_t pp_count_splits_vector(');b=s.index('\n}',a)
fn=s[a:b].replace('    uint32_t result = 0;', '    uint32_t result = 0;\n    uint32_t unknown_count = 0;\n    uint32_t unknown_splits = 0;').replace('            result += pp_splits_unknown(bytes, starts[t], ends[t], split);', '''            const bool match = pp_splits_unknown(bytes, starts[t], ends[t], split);
            unknown_count += 1;
            unknown_splits += match;
            result += match;''').replace('    return result;', '''    const char* path = getenv("BUSTER_PREFIX_CENSUS");
    FILE* stream = path != NULL ? fopen(path, "a") : NULL;
    if (stream != NULL)
    {
        fprintf(stream, "%u %lu %u %u %u\\n", count, split, result, unknown_count, unknown_splits);
        fclose(stream);
    }
    return result;''')
p.write_text(s[:a]+fn+s[b:])
