#include "h.h"
#include <sys/mman.h>
#include <unistd.h>
typedef uint32_t (*Expand)(const uint8_t*,Columns,uint32_t,uint64_t);
uint32_t base(const uint8_t*,Columns,uint32_t,uint64_t);
uint32_t head(const uint8_t*,Columns,uint32_t,uint64_t);
bool base_unknown(const uint8_t*,uint32_t,uint32_t,uint64_t);
bool head_unknown(const uint8_t*,uint32_t,uint32_t,uint64_t);
enum { MAX=1026, TOKENS=2*MAX+2, SIDES=4, ROUNDS=11 };
static uint8_t kinds[SIDES][TOKENS];static uint32_t starts[SIDES][TOKENS],ends[SIDES][TOKENS];
static Columns c[SIDES];
static uint8_t *bytes,*guard;
static const struct {const char* spelling;int kind,after,ident,quote,simple;} spell[]={
 {"x",1,-1,0,0,0},{"u8'x'",5,3,2,2,0},{"U'Q'",7,3,1,1,0},{"u\"ok\"",11,8,1,1,0},
 {"u8\\\n'x'",5,3,2,4,0},{"u\\\n8\\\n'X'",5,3,4,6,0},{"U\\\n\"\"",12,8,1,3,0},
 {"u8''",0,0,2,2,5},{"u\\\n8''",0,0,4,4,5},{"U\"",0,0,1,1,12},
 {"@",0,-1,0,0,0},{"u\\\nX",0,-1,0,0,0},{"L'X'",4,-1,0,0,0},{"42",2,-1,0,0,0},{"\\\nu8'Q'",5,3,4,4,0},{"\\\nU\\\n\"q\"",12,8,3,5,0}};
static uint64_t mask(unsigned mode){return mode==0?((7ull<<5)|(7ull<<10)):mode==1?1ull<<5:0;}
static unsigned pick(unsigned g,unsigned i,unsigned n,unsigned phase){
 unsigned k=i+phase;
 return g==0?(k%2?0:13):g==1?(i==0?1:0):g==2?(i+1==n?1:0):g==3?(k%31==0?2:0):g==4?1+k%3:g==5?4+k%3:g==6?7+k%3:g==7?10+k%3:g==8?k%14:g==10?14+k%2:(k%9==0?8:k%13==0?5:0);
}
static unsigned fixture(unsigned n,unsigned g,unsigned phase,uint64_t split)
{
 unsigned idx[MAX],b=0,out=0;
 for(unsigned i=0;i<n;i++){idx[i]=pick(g,i,n,phase);b+=strlen(spell[idx[i]].spelling);}
 bytes=guard-b;b=0;
 for(unsigned i=0;i<n;i++){
  unsigned k=idx[i],len=strlen(spell[k].spelling);uint8_t line=((i+phase)%3==0)?128:0;
  memcpy(bytes+b,spell[k].spelling,len);
  c[2].kind[i]=line|spell[k].kind;c[2].start[i]=b;c[2].end[i]=b+len;
  if(spell[k].after>=0 && ((split>>(spell[k].simple?spell[k].simple:spell[k].kind))&1)){
   c[3].kind[out]=line|C_TOKEN_RAW_IDENTIFIER;c[3].start[out]=b;c[3].end[out]=b+spell[k].ident;++out;
   c[3].kind[out]=spell[k].after;c[3].start[out]=b+spell[k].quote;c[3].end[out]=b+len;
  }else{c[3].kind[out]=c[2].kind[i];c[3].start[out]=b;c[3].end[out]=b+len;}
  out++;b+=len;
 }
 return out;
}
static void reset(unsigned side,unsigned n){memcpy(c[side].kind,c[2].kind,n);memcpy(c[side].start,c[2].start,n*4);memcpy(c[side].end,c[2].end,n*4);}
static uint64_t ticks(void){_mm_lfence();uint64_t v=__rdtsc();_mm_lfence();return v;}
static int cmp(const void* a,const void* b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return (x>y)-(x<y);}
int main(int argc,char** argv)
{
 bool measure=argc>1&&!strcmp(argv[1],"time");Expand expand[]={base,head};uint32_t sizes[200],cnt=0,total=0;
 unsigned page=sysconf(_SC_PAGESIZE);unsigned char* area=mmap(NULL,page*8,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);guard=area+7*page;
 if(area==MAP_FAILED||mprotect(guard,page,PROT_NONE))return 3;
 for(unsigned j=0;j<SIDES;j++)c[j]=(Columns){kinds[j],starts[j],ends[j]};
 for(unsigned n=0;n<=66;n++)sizes[cnt++]=n;for(unsigned n=128;n<=1024;n*=2)for(int j=-2;j<=2;j++)sizes[cnt++]=n+j;
 for(unsigned g=0;g<11;g++)for(unsigned mode=0;mode<3;mode++)for(unsigned z=0;z<cnt;z++){
  unsigned n=sizes[z];uint64_t split=mask(mode);
  for(unsigned shift=0;shift<(measure?1:8);shift++){
   unsigned nout=fixture(n,g,shift,split);
   for(unsigned side=0;side<2;side++){
    reset(side,n);c[side].kind[nout]=0xa5;c[side].start[nout]=0x99999999;c[side].end[nout]=0xcccccccc;
    unsigned got=expand[side](bytes,c[side],n,split);
    if(got!=nout||memcmp(c[side].kind,kinds[3],nout)||memcmp(c[side].start,starts[3],4*nout)||memcmp(c[side].end,ends[3],4*nout)||c[side].kind[nout]!=0xa5||c[side].start[nout]!=0x99999999||c[side].end[nout]!=0xcccccccc){
     fprintf(stderr,"mismatch side=%u shape=%u mode=%u n=%u shift=%u got=%u want=%u\n",side,g,mode,n,shift,got,nout);return 1;
    }
   }
   total++;
  }
  if(measure && mode<2){
   uint64_t v[2][ROUNDS];unsigned reps=6+192/(1+n);
   for(unsigned r=0;r<ROUNDS;r++)for(unsigned y=0;y<2;y++){
    unsigned side=(y+r)&1;v[side][r]=0;
    for(unsigned j=0;j<reps;j++){reset(side,n);uint64_t t=ticks();expand[side](bytes,c[side],n,split);v[side][r]+=ticks()-t;}
   }
   qsort(v[0],ROUNDS,8,cmp);qsort(v[1],ROUNDS,8,cmp);
   printf("%u\t%u\t%u\t%u\t%lu\t%lu\n",g,mode,n,reps,v[0][ROUNDS/2],v[1][ROUNDS/2]);
  }
 }
 fprintf(stderr,"%u protected prefix fixtures passed\n",total);
 return 0;
}
