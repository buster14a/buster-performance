BUSTER_INLINE bool pp_splits_kind(uint64_t split, uint8_t kind)
{
    const uint32_t base = kind & 0x7f;
    return base < 64 && ((split >> base) & 1) != 0;
}

typedef struct PPLiteralPrefix PPLiteralPrefix;
struct PPLiteralPrefix
{
    uint32_t quote;
    uint32_t end;
    uint8_t kind;
};

static PPLiteralPrefix pp_literal_prefix(const uint8_t* bytes, uint32_t start, uint32_t end)
{
    PPLiteralPrefix prefix = { .quote = end, .end = start };
    uint32_t letters = 0;
    if (start < end && (bytes[start] | 0x20) == 'u')
    {
        for (uint32_t at = start; at < end && prefix.quote == end;)
        {
            const uint32_t left = end - at;
            const uint32_t count = left < 64 ? left : 64;
            const __m512i v = _mm512_maskz_loadu_epi8(_bzhi_u64(UINT64_MAX, count), bytes + at);
            const uint64_t quotes = _mm512_cmpeq_epi8_mask(v, _mm512_set1_epi8('\'')) | _mm512_cmpeq_epi8_mask(v, _mm512_set1_epi8('"'));
            const uint32_t take = quotes ? (uint32_t)__builtin_ctzll(quotes) : count;
            const uint64_t alphabet = _mm512_cmpeq_epi8_mask(_mm512_or_si512(v, _mm512_set1_epi8(0x20)), _mm512_set1_epi8('u')) | _mm512_cmpeq_epi8_mask(v, _mm512_set1_epi8('8'));
            const uint64_t marked = _bzhi_u64(alphabet, take);
            if (marked != 0)
            {
                prefix.end = at + 64 - (uint32_t)__builtin_clzll(marked);
                letters += (uint32_t)__builtin_popcountll(marked);
            }
            if (quotes != 0)
            {
                prefix.quote = at + take;
                const bool character = bytes[prefix.quote] == '\'';
                if (letters == 1)
                {
                    prefix.kind = bytes[start] == 'u' ? (character ? C_TOKEN_UTF16_CHAR_CONSTANT : C_TOKEN_UTF16_STRING_LITERAL)
                                                      : (character ? C_TOKEN_UTF32_CHAR_CONSTANT : C_TOKEN_UTF32_STRING_LITERAL);
                }
                else if (letters == 2 && bytes[start] == 'u' && bytes[prefix.end - 1] == '8')
                {
                    prefix.kind = character ? C_TOKEN_UTF8_CHAR_CONSTANT : C_TOKEN_UTF8_STRING_LITERAL;
                }
            }
            at += count;
        }
    }
    return prefix;
}

static bool pp_splits_unknown(const uint8_t* bytes, uint32_t start, uint32_t end, uint64_t split)
{
    const uint8_t kind = pp_literal_prefix(bytes, start, end).kind;
    return kind != 0 && pp_splits_kind(split, kind);
}

static uint32_t pp_count_splits_vector(const uint8_t* bytes, const uint8_t* kinds, const uint32_t* starts, const uint32_t* ends, uint32_t count, uint64_t split)
{
    const __m512i ones = _mm512_set1_epi8(1);
    const __m512i lookup = _mm512_maskz_mov_epi8((__mmask64)split, ones);
    uint32_t result = 0;
    for (uint32_t at = 0; at < count;)
    {
        const uint32_t n = count - at < 64 ? count - at : 64;
        const __mmask64 live = _bzhi_u64(UINT64_MAX, n);
        const __m512i kind = _mm512_maskz_loadu_epi8(live, kinds + at);
        result += (uint32_t)__builtin_popcountll(_mm512_mask_test_epi8_mask(live, _mm512_permutex2var_epi8(lookup, kind, _mm512_setzero_si512()), ones));
        for (uint64_t unknown = _mm512_mask_cmpeq_epi8_mask(live, _mm512_and_si512(kind, _mm512_set1_epi8(127)), _mm512_set1_epi8(C_TOKEN_UNKNOWN)); unknown != 0; unknown &= unknown - 1)
        {
            const uint32_t t = at + (uint32_t)__builtin_ctzll(unknown);
            result += pp_splits_unknown(bytes, starts[t], ends[t], split);
        }
        at += n;
    }
    return result;
}

static uint32_t pp_split_prefixes(const uint8_t* bytes, uint8_t* kinds, uint32_t* starts, uint32_t* ends, uint32_t count, uint32_t splits, uint64_t split)
{
    const __m512i ones = _mm512_set1_epi8(1);
    const __m512i lookup = _mm512_maskz_mov_epi8((__mmask64)split, ones);
    uint32_t next = count;
    uint32_t remaining = splits;
    for (uint32_t limit = count; remaining != 0 && limit != 0;)
    {
        const uint32_t first = (limit - 1) & ~63u;
        const uint64_t live = _bzhi_u64(UINT64_MAX, limit - first);
        const __m512i raw = _mm512_maskz_loadu_epi8(live, kinds + first);
        const uint64_t known = _mm512_mask_test_epi8_mask(live, _mm512_permutex2var_epi8(lookup, raw, _mm512_setzero_si512()), ones);
        const uint64_t unknown = _mm512_mask_cmpeq_epi8_mask(live, _mm512_and_si512(raw, _mm512_set1_epi8(127)), _mm512_set1_epi8(C_TOKEN_UNKNOWN));
        uint64_t events = known | unknown;
        while (events != 0 && remaining != 0)
        {
            const uint32_t lane = 63 - (uint32_t)__builtin_clzll(events);
            const uint32_t t = first + lane;
            events = _bzhi_u64(events, lane);
            const PPLiteralPrefix prefix = pp_literal_prefix(bytes, starts[t], ends[t]);
            const uint64_t bit = UINT64_C(1) << lane;
            if ((known & bit) || (prefix.kind != 0 && pp_splits_kind(split, prefix.kind)))
            {
                const uint32_t plain = next - t - 1;
                if (plain != 0)
                {
                    memmove(kinds + t + remaining + 1, kinds + t + 1, plain);
                    memmove(starts + t + remaining + 1, starts + t + 1, (size_t)plain * sizeof(*starts));
                    memmove(ends + t + remaining + 1, ends + t + 1, (size_t)plain * sizeof(*ends));
                }
                const uint8_t kind = kinds[t];
                const uint32_t put = t + remaining;
                kinds[put] = (unknown & bit) ? C_TOKEN_UNKNOWN : (kind & 127) <= C_TOKEN_UTF32_CHAR_CONSTANT ? C_TOKEN_CHAR_CONSTANT : C_TOKEN_STRING_LITERAL;
                starts[put] = prefix.quote;
                ends[put] = ends[t];
                kinds[put - 1] = (uint8_t)((kind & 128) | C_TOKEN_RAW_IDENTIFIER);
                starts[put - 1] = starts[t];
                ends[put - 1] = prefix.end;
                next = t;
                remaining -= 1;
            }
        }
        limit = first;
    }
    return count + splits;
}
