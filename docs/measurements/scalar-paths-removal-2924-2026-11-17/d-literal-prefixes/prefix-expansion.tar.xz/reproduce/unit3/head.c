#include "h.h"
BUSTER_INLINE bool pp_splits_kind(uint64_t split, uint8_t kind)
{
    const uint32_t base = kind & 0x7f;
    return base < 64 && ((split >> base) & 1) != 0;
}

typedef struct PPLiteralPrefix PPLiteralPrefix;
struct PPLiteralPrefix
{
    uint32_t quote;
    uint32_t end;
    uint8_t kind;
};

static PPLiteralPrefix pp_literal_prefix(const uint8_t* bytes, uint32_t start, uint32_t end, bool typed)
{
    PPLiteralPrefix prefix = { .quote = end, .end = start };
    uint32_t letters = 0;
    const bool possible = start < end && (bytes[start] | 0x20) == 'u';
    const uint32_t available = end - start;
    const bool eight = possible && bytes[start] == 'u' && available > 1 && bytes[start + 1] == '8';
    const uint32_t size = 1u + eight;
    const uint8_t next = possible && available > size ? bytes[start + size] : 0;
    if (next == '\'' || next == '"')
    {
        const uint8_t kind = eight ? C_TOKEN_UTF8_CHAR_CONSTANT : bytes[start] == 'u' ? C_TOKEN_UTF16_CHAR_CONSTANT : C_TOKEN_UTF32_CHAR_CONSTANT;
        prefix.kind = next == '\'' ? kind : kind + (C_TOKEN_UTF8_STRING_LITERAL - C_TOKEN_UTF8_CHAR_CONSTANT);
        prefix.quote = start + size;
        prefix.end = prefix.quote;
    }
    else if (typed || possible)
    {
        for (uint32_t at = start; at < end && prefix.quote == end;)
        {
            const uint32_t left = end - at;
            const uint32_t count = left < 64 ? left : 64;
            const __m512i v = _mm512_maskz_loadu_epi8(_bzhi_u64(UINT64_MAX, count), bytes + at);
            const uint64_t quotes = _mm512_cmpeq_epi8_mask(v, _mm512_set1_epi8('\'')) | _mm512_cmpeq_epi8_mask(v, _mm512_set1_epi8('"'));
            const uint32_t take = quotes ? (uint32_t)__builtin_ctzll(quotes) : count;
            const uint64_t alphabet = _mm512_cmpeq_epi8_mask(_mm512_or_si512(v, _mm512_set1_epi8(0x20)), _mm512_set1_epi8('u')) | _mm512_cmpeq_epi8_mask(v, _mm512_set1_epi8('8'));
            const uint64_t marked = _bzhi_u64(alphabet, take);
            if (marked != 0)
            {
                prefix.end = at + 64 - (uint32_t)__builtin_clzll(marked);
                letters += (uint32_t)__builtin_popcountll(marked);
            }
            if (quotes != 0)
            {
                prefix.quote = at + take;
                const bool character = bytes[prefix.quote] == '\'';
                if (letters == 1)
                {
                    prefix.kind = bytes[start] == 'u' ? (character ? C_TOKEN_UTF16_CHAR_CONSTANT : C_TOKEN_UTF16_STRING_LITERAL)
                                                      : (character ? C_TOKEN_UTF32_CHAR_CONSTANT : C_TOKEN_UTF32_STRING_LITERAL);
                }
                else if (letters == 2 && bytes[start] == 'u' && bytes[prefix.end - 1] == '8')
                {
                    prefix.kind = character ? C_TOKEN_UTF8_CHAR_CONSTANT : C_TOKEN_UTF8_STRING_LITERAL;
                }
            }
            at += count;
        }
    }
    return prefix;
}

static bool pp_splits_unknown(const uint8_t* bytes, uint32_t start, uint32_t end, uint64_t split)
{
    const uint8_t kind = pp_literal_prefix(bytes, start, end, false).kind;
    return kind != 0 && pp_splits_kind(split, kind);
}

static uint32_t pp_count_splits_vector(const uint8_t* bytes, const uint8_t* kinds, const uint32_t* starts, const uint32_t* ends, uint32_t count, uint64_t split)
{
    const __m512i ones = _mm512_set1_epi8(1);
    const __m512i low = _mm512_maskz_mov_epi8((__mmask64)split, ones);
    const __m512i high = _mm512_setzero_si512();
    uint32_t result = 0;
    for (uint32_t i = 0; i < count; i += 64)
    {
        const __mmask64 valid = _bzhi_u64(~0ull, count - i < 64 ? count - i : 64);
        const __m512i kind = _mm512_maskz_loadu_epi8(valid, kinds + i);
        result += (uint32_t)__builtin_popcountll(_mm512_mask_test_epi8_mask(valid, _mm512_permutex2var_epi8(low, kind, high), ones));
        // The rare unknown tokens, one at a time (pp_splits_unknown).
        for (uint64_t unknown = _mm512_mask_cmpeq_epi8_mask(valid, _mm512_and_si512(kind, _mm512_set1_epi8(0x7F)), _mm512_set1_epi8(C_TOKEN_UNKNOWN)); unknown != 0; unknown &= unknown - 1)
        {
            const uint32_t t = i + (uint32_t)__builtin_ctzll(unknown);
            result += pp_splits_unknown(bytes, starts[t], ends[t], split);
        }
    }
    return result;
}

static uint32_t pp_split_prefixes(const uint8_t* bytes, uint8_t* kinds, uint32_t* starts, uint32_t* ends, uint32_t count, uint32_t splits, uint64_t split)
{
    const __m512i duplicate = _mm512_setr_epi32(0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7);
    const uint32_t file_end = ends[count - 1];
    uint32_t remaining = splits;
    for (uint32_t limit = count; remaining != 0 && limit != 0;)
    {
        const uint32_t first = (limit - 1) & ~7u;
        const uint32_t take = limit - first;
        const __mmask8 live = (__mmask8)_bzhi_u32(255, take);
        const __m128i raw = _mm_maskz_loadu_epi8(live, kinds + first);
        const __m256i kind = _mm256_cvtepu8_epi32(raw);
        const __m256i low = _mm256_and_si256(kind, _mm256_set1_epi32(127));
        const __m256i begin = _mm256_maskz_loadu_epi32(live, starts + first);
        const __m256i end = _mm256_maskz_loadu_epi32(live, ends + first);
        const __mmask8 unknown = _mm256_mask_cmpeq_epi32_mask(live, low, _mm256_setzero_si256());
        const __mmask8 known = _mm256_test_epi32_mask(_mm256_srlv_epi32(_mm256_set1_epi32((int)split), low), _mm256_set1_epi32(1));
        __mmask8 marked = known;
        __m256i prefix_end = begin;
        __m256i quote = begin;
        if ((known | unknown) != 0)
        {
            // Only gather complete words within the source, including for the final token before a guard page.
            const __mmask8 safe = _mm256_mask_cmpge_epu32_mask(known | unknown,
                _mm256_sub_epi32(_mm256_set1_epi32((int)file_end), begin), _mm256_set1_epi32(4));
            const __m256i spelling = _mm512_mask_i64gather_epi32(_mm256_setzero_si256(), safe, _mm512_cvtepu32_epi64(begin), bytes, 1);
            const __m256i byte = _mm256_and_si256(spelling, _mm256_set1_epi32(255));
            const __mmask8 u = _mm256_mask_cmpeq_epi32_mask(safe, _mm256_or_si256(byte, _mm256_set1_epi32(32)), _mm256_set1_epi32('u'));
            const __mmask8 eight = _mm256_mask_cmpeq_epi32_mask(u, _mm256_and_si256(spelling, _mm256_set1_epi32(0xffff)), _mm256_set1_epi32('u' | ('8' << 8)));
            const __m256i size = _mm256_mask_add_epi32(_mm256_set1_epi32(1), eight, _mm256_set1_epi32(1), _mm256_set1_epi32(1));
            const __m256i next = _mm256_and_si256(_mm256_mask_blend_epi32(eight, _mm256_srli_epi32(spelling,8), _mm256_srli_epi32(spelling,16)), _mm256_set1_epi32(255));
            const __mmask8 within = _mm256_mask_cmpgt_epu32_mask(u, _mm256_sub_epi32(end,begin), size);
            const __mmask8 character = _mm256_mask_cmpeq_epi32_mask(within, next, _mm256_set1_epi32('\''));
            const __mmask8 ordinary = character | _mm256_mask_cmpeq_epi32_mask(within, next, _mm256_set1_epi32('"'));
            const __mmask8 upper = _mm256_cmpeq_epi32_mask(byte,_mm256_set1_epi32('U'));
            __m256i tok = _mm256_mask_blend_epi32(upper, _mm256_set1_epi32(C_TOKEN_UTF16_CHAR_CONSTANT), _mm256_set1_epi32(C_TOKEN_UTF32_CHAR_CONSTANT));
            tok = _mm256_mask_mov_epi32(tok, eight, _mm256_set1_epi32(C_TOKEN_UTF8_CHAR_CONSTANT));
            tok = _mm256_mask_add_epi32(tok, (__mmask8)~character, tok, _mm256_set1_epi32(C_TOKEN_UTF8_STRING_LITERAL - C_TOKEN_UTF8_CHAR_CONSTANT));
            marked |= unknown & ordinary & _mm256_test_epi32_mask(_mm256_srlv_epi32(_mm256_set1_epi32((int)split),tok), _mm256_set1_epi32(1));
            prefix_end = _mm256_add_epi32(begin,size);
            quote = prefix_end;
            uint32_t ends_by_lane[8], quotes_by_lane[8];
            __mmask8 slow = (known | (unknown & (u | ~safe))) & ~ordinary;
            if (slow != 0)
            {
                _mm256_storeu_si256((__m256i*)ends_by_lane,prefix_end);
                _mm256_storeu_si256((__m256i*)quotes_by_lane,quote);
                for (uint32_t pending = slow; pending != 0; pending &= pending - 1)
                {
                    const uint32_t lane = (uint32_t)__builtin_ctz(pending);
                    const uint32_t t = first + lane;
                    const PPLiteralPrefix prefix = pp_literal_prefix(bytes, starts[t], ends[t], (known >> lane) & 1);
                    ends_by_lane[lane] = prefix.end;
                    quotes_by_lane[lane] = prefix.quote;
                    if (prefix.kind != 0 && pp_splits_kind(split,prefix.kind)) marked |= 1u << lane;
                }
                prefix_end = _mm256_loadu_si256((const __m256i*)ends_by_lane);
                quote = _mm256_loadu_si256((const __m256i*)quotes_by_lane);
            }
        }
        remaining -= (uint32_t)__builtin_popcount(marked);
        const uint32_t put = first + remaining;
        if (marked != 0)
        {
            const __m256i leading = _mm256_mask_add_epi32(kind, marked, _mm256_and_si256(kind,_mm256_set1_epi32(128)),_mm256_set1_epi32(C_TOKEN_RAW_IDENTIFIER));
            __m256i tail_kind = _mm256_mask_blend_epi32(_mm256_cmpgt_epi32_mask(low,_mm256_set1_epi32(C_TOKEN_UTF32_CHAR_CONSTANT)),
                                                      _mm256_set1_epi32(C_TOKEN_CHAR_CONSTANT),_mm256_set1_epi32(C_TOKEN_STRING_LITERAL));
            tail_kind = _mm256_mask_mov_epi32(tail_kind,unknown,_mm256_set1_epi32(C_TOKEN_UNKNOWN));
            const __m512i pair = _mm512_mask_blend_epi32(0xaaaa,duplicate,_mm512_add_epi32(duplicate,_mm512_set1_epi32(16)));
            const __mmask16 slots = (__mmask16)(_pdep_u32(live,0x5555) | _pdep_u32(marked,0xaaaa));
            const __m512i out_kinds = _mm512_permutex2var_epi32(_mm512_castsi256_si512(leading),pair,_mm512_castsi256_si512(tail_kind));
            const __m512i out_starts = _mm512_permutex2var_epi32(_mm512_castsi256_si512(begin),pair,_mm512_castsi256_si512(quote));
            const __m512i out_ends = _mm512_permutex2var_epi32(_mm512_castsi256_si512(_mm256_mask_mov_epi32(end,marked,prefix_end)),pair,_mm512_castsi256_si512(end));
            _mm_mask_compressstoreu_epi8(kinds+put,slots,_mm512_cvtepi32_epi8(out_kinds));
            _mm512_mask_compressstoreu_epi32(starts+put,slots,out_starts);
            _mm512_mask_compressstoreu_epi32(ends+put,slots,out_ends);
        }
        else
        {
            _mm_mask_storeu_epi8(kinds+put,live,raw);
            _mm256_mask_storeu_epi32(starts+put,live,begin);
            _mm256_mask_storeu_epi32(ends+put,live,end);
        }
        limit = first;
    }
    return count + splits;
}

uint32_t head(const uint8_t* bytes,Columns c,uint32_t count,uint64_t split)
{
    uint32_t n=pp_count_splits_vector(bytes,c.kind,c.start,c.end,count,split);
    return n?pp_split_prefixes(bytes,c.kind,c.start,c.end,count,n,split):count;
}
bool head_unknown(const uint8_t* bytes,uint32_t start,uint32_t end,uint64_t split){return pp_splits_unknown(bytes,start,end,split);}
