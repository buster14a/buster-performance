#include "h.h"
BUSTER_INLINE bool pp_splits_kind(uint64_t split, uint8_t kind)
{
    const uint8_t base = kind & 0x7F;
    return base < 64 && ((split >> base) & 1) != 0;
}

static bool pp_splits_unknown(const uint8_t* bytes, uint32_t start, uint32_t end, uint64_t split)
{
    uint32_t at = start < end && (bytes[start] == 'u' || bytes[start] == 'U') ? start : end;
    uint32_t letters = 0;
    bool u = false;
    bool upper = false;
    bool eight = false;
    while (at < end && bytes[at] != '\'' && bytes[at] != '"')
    {
        letters += bytes[at] == 'u' || bytes[at] == 'U' || bytes[at] == '8';
        u |= letters == 1 && bytes[at] == 'u';
        upper |= letters == 1 && bytes[at] == 'U';
        eight |= letters == 2 && bytes[at] == '8';
        at += 1;
    }
    const bool character = at < end && bytes[at] == '\'';
    const uint8_t kind = !(at < end) ? 0
                         : u && eight && letters == 2 ? (character ? C_TOKEN_UTF8_CHAR_CONSTANT : C_TOKEN_UTF8_STRING_LITERAL)
                         : u && letters == 1 ? (character ? C_TOKEN_UTF16_CHAR_CONSTANT : C_TOKEN_UTF16_STRING_LITERAL)
                         : upper && letters == 1 ? (character ? C_TOKEN_UTF32_CHAR_CONSTANT : C_TOKEN_UTF32_STRING_LITERAL)
                         : 0;
    return kind != 0 && pp_splits_kind(split, kind);
}

static uint32_t pp_count_splits_vector(const uint8_t* bytes, const uint8_t* kinds, const uint32_t* starts, const uint32_t* ends, uint32_t count, uint64_t split)
{
    const __m512i ones = _mm512_set1_epi8(1);
    const __m512i low = _mm512_maskz_mov_epi8((__mmask64)split, ones);
    const __m512i high = _mm512_setzero_si512();
    uint32_t result = 0;
    for (uint32_t i = 0; i < count; i += 64)
    {
        const __mmask64 valid = _bzhi_u64(~0ull, count - i < 64 ? count - i : 64);
        const __m512i kind = _mm512_maskz_loadu_epi8(valid, kinds + i);
        result += (uint32_t)__builtin_popcountll(_mm512_mask_test_epi8_mask(valid, _mm512_permutex2var_epi8(low, kind, high), ones));
        // The rare unknown tokens, one at a time (pp_splits_unknown).
        for (uint64_t unknown = _mm512_mask_cmpeq_epi8_mask(valid, _mm512_and_si512(kind, _mm512_set1_epi8(0x7F)), _mm512_set1_epi8(C_TOKEN_UNKNOWN)); unknown != 0; unknown &= unknown - 1)
        {
            const uint32_t t = i + (uint32_t)__builtin_ctzll(unknown);
            result += pp_splits_unknown(bytes, starts[t], ends[t], split);
        }
    }
    return result;
}

static uint32_t pp_split_prefixes(const uint8_t* bytes, uint8_t* kinds, uint32_t* starts, uint32_t* ends, uint32_t count, uint32_t splits, uint64_t split)
{
    uint32_t remaining = splits;
    for (uint32_t i = count; remaining != 0 && i > 0; i -= 1)
    {
        const uint32_t t = i - 1;
        const uint8_t kind = kinds[t];
        const uint32_t start = starts[t];
        const uint32_t end = ends[t];
        const bool unknown = (kind & 0x7F) == C_TOKEN_UNKNOWN && pp_splits_unknown(bytes, start, end, split);
        if (pp_splits_kind(split, kind) || unknown)
        {
            uint32_t quote = start;
            uint32_t prefix_end = start;
            while (bytes[quote] != '\'' && bytes[quote] != '"')
            {
                prefix_end = bytes[quote] == 'u' || bytes[quote] == 'U' || bytes[quote] == '8' ? quote + 1 : prefix_end;
                quote += 1;
            }
            kinds[t + remaining] = unknown ? C_TOKEN_UNKNOWN : (kind & 0x7F) <= C_TOKEN_UTF32_CHAR_CONSTANT ? C_TOKEN_CHAR_CONSTANT : C_TOKEN_STRING_LITERAL;
            starts[t + remaining] = quote;
            ends[t + remaining] = end;
            kinds[t + remaining - 1] = (uint8_t)((kind & 0x80) | C_TOKEN_RAW_IDENTIFIER);
            starts[t + remaining - 1] = start;
            ends[t + remaining - 1] = prefix_end;
            remaining -= 1;
        }
        else
        {
            kinds[t + remaining] = kind;
            starts[t + remaining] = start;
            ends[t + remaining] = end;
        }
    }
    return count + splits;
}

uint32_t base(const uint8_t* bytes,Columns c,uint32_t count,uint64_t split)
{
    uint32_t n=pp_count_splits_vector(bytes,c.kind,c.start,c.end,count,split);
    return n?pp_split_prefixes(bytes,c.kind,c.start,c.end,count,n,split):count;
}
bool base_unknown(const uint8_t* bytes,uint32_t start,uint32_t end,uint64_t split){return pp_splits_unknown(bytes,start,end,split);}
