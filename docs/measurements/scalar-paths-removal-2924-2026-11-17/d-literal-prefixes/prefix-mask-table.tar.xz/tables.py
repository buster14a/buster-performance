from pathlib import Path
from shutil import copyfile
p=Path(__file__).parent;q=p/'table-unit';q.mkdir(exist_ok=True)
for n in ('lexer-base.c','base.c','post.c','head.c','gate.c','random.c'):copyfile(p/'legal-unit'/n,q/n)
s=(p/'legal-unit/lexer-head.c').read_text()
a=s.index('    const ScalarLexer* lexer = &lexer_value;',s.index('BUSTER_LEXER_ENTRY uint64_t c_tokenize_scalar_range'))
s=s[:a]+'''    const uint32_t dropped_prefixes = flags & C_TOKENIZER_WIDE_PREFIX_ONLY
        ? (7u << C_TOKEN_UTF8_CHAR_CONSTANT) | (7u << C_TOKEN_UTF8_STRING_LITERAL)
        : flags & C_TOKENIZER_NO_U8_CHAR ? 1u << C_TOKEN_UTF8_CHAR_CONSTANT : 0;
'''+s[a:]
a=s.index('                    const bool split = (c !=');b=s.index('                    p = lex_char_or_string',a)
s=s[:a]+'''                    const uint8_t ordinary = c2 == '"' ? C_TOKEN_STRING_LITERAL : C_TOKEN_CHAR_CONSTANT;
                    kind = (uint8_t)(ordinary + prefix);
                    if (((dropped_prefixes >> kind) & 1) != 0)
                    {
                        emit(&output, C_TOKEN_RAW_IDENTIFIER, start, prefix_end);
                        start = quote_end - 1;
                        kind = ordinary;
                    }
'''+s[b:]
(q/'lexer-head.c').write_text(s)
for nm in ('native-gate','task','corpus'):
 (p/('table-'+nm)).write_text((p/('legal-'+nm)).read_text().replace('legal','table'))
