#include "lexer-base.c"
#include "post.c"
int64_t base(const uint8_t* bytes,uint32_t len,uint8_t* kind,uint32_t* start,uint32_t* end,uint32_t flags,uint32_t policy)
{
    int64_t n=c_tokenize(bytes,len,kind,start,end,flags);
    const uint64_t split=policy==0 ? ((7ull<<5)|(7ull<<10)) : policy==1 ? 1ull<<5 : 0;
    if(n>0 && split) {
        uint32_t count=pp_count_splits_vector(bytes,kind,start,end,(uint32_t)n,split);
        if(count)n=pp_split_prefixes(bytes,kind,start,end,(uint32_t)n,count,split);
    }
    return n;
}
