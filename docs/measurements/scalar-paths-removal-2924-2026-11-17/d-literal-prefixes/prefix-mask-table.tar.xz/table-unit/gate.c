#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <immintrin.h>
typedef int64_t Lexer(const uint8_t*,uint32_t,uint8_t*,uint32_t*,uint32_t*,uint32_t,uint32_t);
extern Lexer base,head;
enum{MAX=32768,ROUNDS=9};
static uint8_t kinds[2][MAX+128];
static uint32_t starts[2][MAX+128],ends[2][MAX+128];
static char text[MAX];
static uint64_t tick(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int order(const void* a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return(x>y)-(x<y);}
int main(int argc,char**argv){
 const int timed=argc>1&&!strcmp(argv[1],"time");
 Lexer* fn[]={base,head};unsigned sizes[128],total=0,checks=0;
 for(unsigned n=0;n<=66;n++)sizes[total++]=n;
 for(unsigned n=128;n<=1024;n*=2)for(int d=-2;d<=2;d++)sizes[total++]=n+d;
 size_t page=(size_t)sysconf(_SC_PAGESIZE);
 char *p=mmap(NULL,MAX+2*page,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 if(p==MAP_FAILED || mprotect(p+MAX+page,page,PROT_NONE))return 2;
 const char* patterns[]={"x 42 ","u'a' ","U\"x\" ","u8'b' ","u8\"x\" ","u\\\n8\\\n'q' ","\\\nu\\\n\"q\" ","u8'' ","U\"unterminated\n","a /*u'x'*/ ","U??/\n'x' ","u8R\"(q)\" ","$u8'x' ","u8'x'_a ","u8\"x\"\nL'a' "};
 for(unsigned g=0;g<sizeof(patterns)/sizeof(*patterns);g++)for(unsigned mode=0;mode<3;mode++)for(unsigned z=0;z<total;z++){
  unsigned n=sizes[z],flags=g==10?1:g==11?8|(mode?16:0):g==12?128:g==13?2:0;
  for(unsigned phase=0;phase<(timed?1u:8u);phase++){
   size_t len=phase?63*phase:0;memset(text,' ',len);
   for(unsigned i=0;i<n;i++){const char *token=patterns[g];size_t m=strlen(token);memcpy(text+len,token,m);len+=m;}
   char *bytes=p+MAX+page-len;memcpy(bytes,text,len);
   int64_t old=fn[0]((uint8_t*)bytes,len,kinds[0],starts[0],ends[0],flags,mode);
   int64_t new=fn[1]((uint8_t*)bytes,len,kinds[1],starts[1],ends[1],flags,mode);
   if(old<0||new!=old||memcmp(kinds[0],kinds[1],old)||memcmp(starts[0],starts[1],old*4)||memcmp(ends[0],ends[1],old*4)){
    fprintf(stderr,"mismatch shape=%u mode=%u tokens=%u phase=%u counts=%ld/%ld\n",g,mode,n,phase,old,new);
    for(int j=0;j<old&&j<new;j++)if(kinds[0][j]!=kinds[1][j]||starts[0][j]!=starts[1][j]||ends[0][j]!=ends[1][j]){fprintf(stderr,"at token %d kind/start/end %u %u %u vs %u %u %u\n",j,kinds[0][j],starts[0][j],ends[0][j],kinds[1][j],starts[1][j],ends[1][j]);break;}
    return 1;
   }
   ++checks;
   if(timed && mode<2){
    uint64_t v[2][ROUNDS];unsigned reps=2+24/(1+n/4);
    for(unsigned r=0;r<ROUNDS;r++)for(unsigned y=0;y<2;y++){unsigned side=(y+r)&1;uint64_t start=tick();for(unsigned j=0;j<reps;j++)fn[side]((uint8_t*)bytes,len,kinds[side],starts[side],ends[side],flags,mode);v[side][r]=tick()-start;}
    for(unsigned side=0;side<2;side++)qsort(v[side],ROUNDS,sizeof(uint64_t),order);
    printf("%u\t%u\t%u\t%u\t%lu\t%lu\n",g,mode,n,reps,v[0][ROUNDS/2],v[1][ROUNDS/2]);
   }
  }
 }
 fprintf(stderr,"%u guarded producer comparisons passed\n",checks);
}
