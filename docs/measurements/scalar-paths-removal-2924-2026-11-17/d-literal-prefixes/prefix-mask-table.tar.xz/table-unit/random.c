#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

typedef int64_t Lexer(const uint8_t*, uint32_t, uint8_t*, uint32_t*, uint32_t*, uint32_t, uint32_t);
extern Lexer base, head;
static uint32_t seed = 53;
static uint32_t next(void) { seed = seed * 1664525u + 1013904223u; return seed; }
enum {CAP = 4096};
static uint32_t starts[2][CAP], ends[2][CAP];
static uint8_t kinds[2][CAP];
int main(int argc, char** argv)
{
    if (argc > 1) seed=(uint32_t)strtoul(argv[1],NULL,10);
    static const char* fragments[] = {"u8", "'a'", "L", "\\", "u", "U", "R", "\"", "'", "??/", "\n", "\r\n", "'","8",
                                      "/*", "*/", "//", "<=", "<=>", "%:%:", "..", "0x", "p-4", " ++;", "??=", "\033", "\302\240",
                                      "$_", "??<", " ", "\0", "_abcdef", "xx", "x//\r\""};
    const unsigned count=sizeof(fragments)/sizeof(*fragments);
    uint32_t page=(uint32_t)sysconf(_SC_PAGESIZE);
    uint8_t* map=mmap(NULL,3*page,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(map==MAP_FAILED||mprotect(map,page,PROT_NONE)||mprotect(map+2*page,page,PROT_NONE))return 2;
    unsigned cases=0;
    for(unsigned sample=0;sample<16000;sample++){
        unsigned length=sample<1152?sample:(next()>>13)%1537,phase=(next()>>13)%64;
        uint8_t* src=sample&1?map+2*page-length:map+page+phase;
        for(unsigned pos=0;pos<length;){
            const char* s=fragments[(next()>>12)%count];
            unsigned k=(unsigned)strlen(s);if(k==0){src[pos++]=0;continue;}
            if(k>length-pos)k=length-pos;memcpy(src+pos,s,k);pos+=k;
        }
        unsigned flags=(next()>>16)&511;
        for(unsigned policy=0;policy<3;policy++){
            int64_t n=base(src,length,kinds[0],starts[0],ends[0],flags,policy);
            int64_t h=head(src,length,kinds[1],starts[1],ends[1],flags,policy);
            if(n!=h || (n>=0 && (memcmp(kinds[0],kinds[1],n)||memcmp(starts[0],starts[1],4*n)||memcmp(ends[0],ends[1],4*n)))){
                fprintf(stderr,"divergence at sample %u length %u flags %u policy %u counts %ld/%ld\n",sample,length,flags,policy,n,h);
                for(int t=0;t<n&&t<h;t++)if(kinds[0][t]!=kinds[1][t]||starts[0][t]!=starts[1][t]||ends[0][t]!=ends[1][t]){fprintf(stderr,"at token %d %u %u %u vs %u %u %u\n",t,kinds[0][t],starts[0][t],ends[0][t],kinds[1][t],starts[1][t],ends[1][t]);break;}
                FILE* fout=fopen("divergence.bin","wb");if(fout){fwrite(src,1,length,fout);fclose(fout);}return 1;
            }
            cases++;
        }
    }
    printf("%u guarded randomized token streams matched in all three policies\n",cases);
}
