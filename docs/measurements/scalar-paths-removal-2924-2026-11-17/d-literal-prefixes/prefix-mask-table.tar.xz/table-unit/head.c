#include "lexer-head.c"
int64_t head(const uint8_t* bytes,uint32_t len,uint8_t* kind,uint32_t* start,uint32_t* end,uint32_t flags,uint32_t policy)
{
    return c_tokenize(bytes,len,kind,start,end,flags|(policy==0?C_TOKENIZER_WIDE_PREFIX_ONLY:policy==1?C_TOKENIZER_NO_U8_CHAR:0));
}
