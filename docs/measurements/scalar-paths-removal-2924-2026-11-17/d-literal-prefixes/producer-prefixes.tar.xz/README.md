Both patches apply independently to buster 2e4400b66b351a989625acbcb80ba079cbb31310. For a driver named producer or producer2, use these commands at the extraction directory, with BUSTER_TREE pointing to a clean compiler checkout at that revision.
 
    driver=producer2
    git -C "$BUSTER_TREE" show HEAD:src/buster/compiler/c_lexer.c > "$driver-unit/lexer-base.c"
    git -C "$BUSTER_TREE" apply "$PWD/$driver.patch"
    cp "$BUSTER_TREE/src/buster/compiler/c_lexer.c" "$driver-unit/lexer-head.c"
    clang -O3 -march=native -fwrapv -funsigned-char -fno-strict-aliasing -Wno-trigraphs -I "$BUSTER_TREE/src" -I "$BUSTER_TREE/src/buster/compiler" "$driver-unit"/{base,head,gate}.c -o "$driver-check"
    ./"$driver-check" check
    taskset -c 2 ./"$driver-check" time

Time under the host's exclusive benchmark lock. Each timings row contains the spelling shape, language policy, size, repetitions, baseline ticks and candidate ticks. Full preprocessor runs compare clean Release builds, including the lexing costs. The raw compiler output digest covers stdout, and stderr was compared independently.
