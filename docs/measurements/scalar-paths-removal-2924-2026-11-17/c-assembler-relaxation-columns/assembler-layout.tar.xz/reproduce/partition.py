from pathlib import Path
import subprocess
p=Path(__file__).parent;u=p/'partition';f='src/buster/compiler/assembler_sections.c'
for name,s in [('old',subprocess.check_output(['git','-C',str(p/'tree'),'show','HEAD:'+f],text=True)),('new',(p/'tree'/f).read_text())]:
 a=s.index('static void asm_partition_fragments(');b=s.index('\n}',s.index('static void asm_partition_append(',a))+3
 (u/(name+'.c')).write_text('#include "layout.h"\n'+s[a:b].replace('static void asm_partition_fragments','void '+name+'_partition').replace('static void asm_partition_append','void '+name+'_append'))
