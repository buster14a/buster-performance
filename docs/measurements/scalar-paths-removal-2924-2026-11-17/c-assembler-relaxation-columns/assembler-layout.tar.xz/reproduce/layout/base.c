#include "fixture.h"
static void asm_relax_add(AsmRelax* relax, const AsmFragment* fragment, uint32_t id, uint32_t region, uint32_t* end)
{
    const bool align = (region & 3) == ASM_RELAX_ALIGN;
    relax->events[relax->event_count++] = (AsmRelaxEvent){
        .local = align ? fragment->alignment : 0,
        .offset = fragment->offset,
        .size = fragment->size,
        .gap = fragment->offset - *end,
        .fragment = id,
        .anchor = align ? fragment->maximum : 0,
        .region = region,
    };
    *end = fragment->offset + fragment->size;
}

static uint32_t asm_relax_role(const AsmRelax* relax, const AsmFragment* fragment, uint32_t id)
{
    const bool leb = fragment->kind == ASM_ULEB || fragment->kind == ASM_SLEB;
    const bool branch = (relax->branches[id / 64] >> (id % 64) & 1) != 0;
    return leb ? ASM_RELAX_LEB : branch ? ASM_RELAX_BRANCH : ASM_RELAX_PLAIN;
}

void base_first(AsmParser* parser, AsmRelax* relax, uint32_t section)
{
    const uint32_t* order = parser->fragment_order;
    const uint32_t end = parser->fragment_begin[section + 1];
    uint32_t at = parser->fragment_begin[section];
    uint32_t offset = 0;
    uint32_t region = 0;
    uint32_t event_end = 0;
    relax->event_begin[section] = relax->event_count;
    while (at < end && parser->result.error == 0)
    {
        const uint32_t id = order[at];
        AsmFragment* fragment = &parser->fragments[id];
        if (fragment->kind == ASM_ALIGN)
        {
            const uint32_t padding = -offset & (fragment->alignment - 1);
            fragment->size = padding <= fragment->maximum ? padding : 0;
            fragment->offset = offset;
            asm_relax_add(relax, fragment, id, region << 2 | ASM_RELAX_ALIGN, &event_end);
            region += 1;
            offset += fragment->size;
            at += 1;
        }
        else
        {
            fragment->offset = offset;
            const uint32_t role = asm_relax_role(relax, fragment, id);
            if (role != ASM_RELAX_PLAIN)
            {
                asm_relax_add(relax, fragment, id, region << 2 | role, &event_end);
            }
            offset += fragment->size;
            at += 1;
        }
        if (offset > BUSTER_ASM_MAX_SECTION)
        {
            asm_fail(parser, fragment->location, "section exceeds the 256 MiB layout limit");
        }
    }
    relax->tails[section] = offset - event_end;
    parser->sections[section].size = offset;
}

void base_place(AsmParser* parser, const AsmRelax* relax, uint32_t section)
{
    for (uint32_t e = relax->event_begin[section]; e < relax->event_begin[section + 1]; e += 1)
    {
        parser->fragments[relax->events[e].fragment].size = relax->events[e].size;
    }
    const uint32_t* order = parser->fragment_order;
    const uint32_t end = parser->fragment_begin[section + 1];
    uint32_t at = parser->fragment_begin[section];
    uint32_t offset = 0;
    while (at < end)
    {
        AsmFragment* fragment = &parser->fragments[order[at]];
        fragment->offset = offset;
        offset += fragment->size;
        at += 1;
    }
}
