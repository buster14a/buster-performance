#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>
#define ASM_RELAX_PLAIN 0
#define ASM_RELAX_ALIGN 1
#define ASM_RELAX_LEB 2
#define ASM_RELAX_BRANCH 3
#define BUSTER_ASM_MAX_SECTION (1u << 28)
enum {ASM_ALIGN=4,ASM_ULEB=5,ASM_SLEB=6};
typedef struct {uint32_t alignment,maximum,offset,size,location;uint8_t kind,layout_role;} AsmFragment;
typedef struct {int64_t local;uint32_t offset,size,gap,fragment,position,anchor,region;} AsmRelaxEvent;
typedef struct {uint32_t* layout_sizes;uint8_t* layout_roles;uint64_t* branches;AsmRelaxEvent* events;uint32_t* event_begin,*tails;uint32_t event_count;} AsmRelax;
typedef struct {AsmFragment* fragments;uint32_t* fragment_order,*fragment_begin;struct{uint32_t size;} *sections;struct{int error;uint32_t location;}result;} AsmParser;
static inline void asm_fail(AsmParser*p,uint32_t pos,const char* reason){(void)reason;p->result.error=1;p->result.location=pos;}
