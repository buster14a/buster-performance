from pathlib import Path
p=Path('src/buster/compiler/assembler.c');s=p.read_text()
mark='    relax->event_begin[section] = relax->event_count;'
assert s.count(mark)==1
s=s.replace(mark,mark+'''
    const char* census = getenv("BUSTER_ASM_LAYOUT_CENSUS");
    FILE* stream = census != NULL ? fopen(census, "a") : NULL;
    if (stream != NULL)
    {
        uint32_t adjacent = 0, align = 0, leb = 0, branch = 0, longest = 0, run = 0;
        for (uint32_t pos = at; pos < end; pos += 1)
        {
            const uint32_t id = order[pos];
            const AsmFragment* f = &parser->fragments[id];
            const uint32_t role = asm_relax_role(relax, f, id);
            adjacent += pos > at && id == order[pos - 1] + 1;
            align += f->kind == ASM_ALIGN;
            leb += role == ASM_RELAX_LEB;
            branch += role == ASM_RELAX_BRANCH;
            run = f->kind == ASM_ALIGN || role != ASM_RELAX_PLAIN ? 0 : run + 1;
            longest = longest > run ? longest : run;
        }
        fprintf(stream, "%u %u %u %u %u %u %u\\n", section, end - at, adjacent, align, leb, branch, longest);
        fclose(stream);
    }''');p.write_text(s)
