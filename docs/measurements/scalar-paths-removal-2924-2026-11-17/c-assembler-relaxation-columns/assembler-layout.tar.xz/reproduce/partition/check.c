#include "layout.h"
#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
void old_partition(AsmParser*);void new_partition(AsmParser*);void old_append(AsmParser*,uint32_t);void new_append(AsmParser*,uint32_t);
static uint32_t seed=11;static uint32_t next(void){seed=seed*1664525u+1013904223u;return seed;}
static AsmFragment fr[1100];int main(void){
 unsigned cells=0,lens[160],nsize=0;
 for(unsigned i=0;i<=98;i++)lens[nsize++]=i;for(unsigned b=128;b<=1024;b*=2)for(int j=-2;j<=2;j++)lens[nsize++]=b+j;
 size_t page=sysconf(_SC_PAGESIZE);uint8_t* mem[2];
 for(unsigned k=0;k<2;k++){mem[k]=mmap(NULL,4*page,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(mem[k]==MAP_FAILED||mprotect(mem[k]+3*page,page,PROT_NONE))return 2;}
 for(unsigned z=0;z<nsize;z++)for(unsigned sec=1;sec<=37;sec+=3)for(unsigned dist=0;dist<9;dist++)for(unsigned shortage=0;shortage<4;shortage++){
  unsigned n=lens[z],cap=n+1+sec+1;cap=shortage==1?cap-1:shortage==2?n:shortage==3?0:cap;
  Pool pools[2];AsmParser parsers[2];
  bool eligible=n!=0;
  for(unsigned i=0;i<=n;i++){uint32_t r=next();unsigned sid=dist==0?0:dist==1?sec/2:dist==2?(i*sec)/(n+1):dist==3?sec-1-((i*sec)/(n+1)):dist==4?(i/16)%sec:dist==5?i%sec:(r>>10)%sec;unsigned kind=dist<3?i%2:dist==6?ASM_LABEL:(r>>17)%3;fr[i]=(AsmFragment){kind,sid};if(i<n)eligible=eligible&&fr[i].section==fr[0].section&&kind!=ASM_ALIGN;}
  for(unsigned k=0;k<2;k++){pools[k]=(Pool){(uint32_t*)(mem[k]+3*page)-cap,0,cap};memset(pools[k].buffer,0xda,cap*4);parsers[k]=(AsmParser){.fragments=fr,.fragment_count=n,.section_count=sec,.arena=&pools[k]};}
  old_partition(&parsers[0]);new_partition(&parsers[1]);
  if(parsers[0].result.error!=parsers[1].result.error||pools[0].used!=pools[1].used)return 1;
  if(!parsers[0].result.error){
   if(parsers[1].record_fragments!=eligible||memcmp(pools[0].buffer,pools[1].buffer,cap*4))return 3;
   old_append(&parsers[0],n);new_append(&parsers[1],n);
   if(memcmp(pools[0].buffer,pools[1].buffer,cap*4))return 4;
  }
  cells++;
 }
 printf("%u stable partitions and post-layout appends matched including exact arena bounds and records eligibility\n",cells);
}
