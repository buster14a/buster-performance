#include <immintrin.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
enum { ASM_LABEL, ASM_INSTRUCTION, ASM_ALIGN };
typedef struct {uint8_t kind; uint32_t section;} AsmFragment;
typedef struct {uint32_t* buffer;size_t used,cap;} Pool;
typedef struct {AsmFragment* fragments;uint32_t fragment_count,section_count,*fragment_order,*fragment_begin;Pool *arena;bool record_fragments;struct {int error;}result;} AsmParser;
static inline uint32_t* alloc_layout(Pool*p,size_t n){if(n>p->cap-p->used)return NULL;uint32_t *out=p->buffer+p->used;p->used+=n;return out;}
#define BUSTER_ARENA_PUSH_ARRAY(arena,type,count) alloc_layout(arena,count)
static inline void asm_fail(AsmParser* p,uint32_t pos,const char *message){(void)pos;(void)message;p->result.error=1;}
