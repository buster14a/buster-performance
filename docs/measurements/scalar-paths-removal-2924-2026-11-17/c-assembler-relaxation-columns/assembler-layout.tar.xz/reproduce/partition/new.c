#include "layout.h"
void new_partition(AsmParser* parser)
{
    const uint32_t count = parser->fragment_count;
    const uint32_t sections = parser->section_count;
    uint32_t* order = BUSTER_ARENA_PUSH_ARRAY(parser->arena, uint32_t, (uint64_t)count + 1);
    uint32_t* begin = BUSTER_ARENA_PUSH_ARRAY(parser->arena, uint32_t, (uint64_t)sections + 1);
    parser->fragment_order = order;
    parser->fragment_begin = begin;
    if (order == NULL || begin == NULL)
    {
        asm_fail(parser, 0, "arena exhausted partitioning section fragments");
        return;
    }
    memset(begin, 0, ((uint64_t)sections + 1) * sizeof(*begin));
    const AsmFragment* fragments = parser->fragments;
    bool records = count != 0;
    bool ordered = true;
    uint32_t previous = 0;
    for (uint32_t pos = 0; pos < count;)
    {
        const uint32_t section = fragments[pos].section;
        ordered &= section >= previous;
        previous = section;
        const uint32_t first = pos;
        do
        {
            records &= fragments[pos].kind == ASM_LABEL || fragments[pos].kind == ASM_INSTRUCTION;
            pos += 1;
        } while (pos < count && fragments[pos].section == section);
        begin[section + 1] += pos - first;
        records &= first == 0;
    }
    parser->record_fragments = records;
    uint32_t start = 0;
    for (uint32_t section = 0; section < sections; section += 1)
    {
        const uint32_t n = begin[section + 1];
        begin[section + 1] = ordered ? start + n : start;
        start += n;
    }
    const __m512i lanes = _mm512_setr_epi32(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15);
    for (uint32_t pos = 0; pos < count;)
    {
        const uint32_t first = pos;
        const uint32_t section = fragments[first].section;
        if (ordered)
        {
            pos = count;
        }
        else
        {
            do { pos += 1; } while (pos < count && fragments[pos].section == section);
        }
        uint32_t target = ordered ? first : begin[section + 1];
        for (uint32_t i = first; i < pos;)
        {
            const uint32_t n = pos - i < 16 ? pos - i : 16;
            _mm512_mask_storeu_epi32(order + target, (__mmask16)_bzhi_u32(UINT16_MAX, n),
                                     _mm512_add_epi32(lanes, _mm512_set1_epi32((int)i)));
            i += n;
            target += n;
        }
        if (!ordered)
        {
            begin[section + 1] = target;
        }
    }
}

void new_append(AsmParser* parser, uint32_t id)
{
    if (parser->result.error == 0)
    {
        const uint32_t section = parser->fragments[id].section;
        const uint32_t position = parser->fragment_begin[section + 1];
        // This is the single CFI fragment appended after layout; the original order allocation has its spare slot.
        memmove(parser->fragment_order + position + 1, parser->fragment_order + position, (id - position) * sizeof(uint32_t));
        parser->fragment_order[position] = id;
        for (uint32_t i = section + 1; i <= parser->section_count; i += 1)
        {
            parser->fragment_begin[i] += 1;
        }
    }
}
