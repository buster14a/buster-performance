#include "layout.h"
void old_partition(AsmParser* parser)
{
    const uint32_t fragment_count = parser->fragment_count;
    const uint32_t section_count = parser->section_count;
    uint32_t* order = BUSTER_ARENA_PUSH_ARRAY(parser->arena, uint32_t, fragment_count + 1);
    uint32_t* begin = BUSTER_ARENA_PUSH_ARRAY(parser->arena, uint32_t, section_count + 1);
    parser->fragment_order = order;
    parser->fragment_begin = begin;
    if (order == 0 || begin == 0)
    {
        asm_fail(parser, 0, "arena exhausted partitioning section fragments");
    }
    else
    {
        const AsmFragment* fragments = parser->fragments;
        // Slot s + 1 holds section s's count, then its write cursor. Scatter advances it to the final end.
        uint32_t* next = begin + 1;
        memset(begin, 0, (section_count + 1) * sizeof(uint32_t));
        for (uint32_t i = 0; i < fragment_count; i += 1)
        {
            next[fragments[i].section] += 1;
        }
        uint32_t start = 0;
        for (uint32_t i = 0; i < section_count; i += 1)
        {
            const uint32_t count = next[i];
            next[i] = start;
            start += count;
        }
        for (uint32_t i = 0; i < fragment_count; i += 1)
        {
            order[next[fragments[i].section]++] = i;
        }
    }
}

void old_append(AsmParser* parser, uint32_t id)
{
    if (parser->result.error == 0)
    {
        const uint32_t section = parser->fragments[id].section;
        const uint32_t position = parser->fragment_begin[section + 1];
        // This is the single CFI fragment appended after layout; the original order allocation has its spare slot.
        memmove(parser->fragment_order + position + 1, parser->fragment_order + position, (id - position) * sizeof(uint32_t));
        parser->fragment_order[position] = id;
        for (uint32_t i = section + 1; i <= parser->section_count; i += 1)
        {
            parser->fragment_begin[i] += 1;
        }
    }
}
