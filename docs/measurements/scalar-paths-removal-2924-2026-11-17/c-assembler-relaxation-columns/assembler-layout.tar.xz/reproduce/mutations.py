from pathlib import Path
import subprocess
p=Path(__file__).parent;u=p/'unit';s=(u/'head.c').read_text()
pairs={
 'lane-two':('sum, zero, 14','sum, zero, 15'),
 'last-quarter':('sum, zero, 8','sum, zero, 9'),
 'inclusive':('_mm512_sub_epi32(sum, size)','sum'),
 'alignment-limit':('pad <= fragment->maximum','pad < fragment->maximum'),
 'event-gap':('fragment->offset - *end','fragment->offset'),
 'event-anchor':('align ? fragment->maximum : 0','0'),
 'region-increment':('region += role == ASM_RELAX_ALIGN','region += role == ASM_RELAX_BRANCH'),
 'overflow-location':('parser->fragment_order[first - 1]','parser->fragment_order[first]'),
 'placement-size':('relax->layout_sizes[event->position] = event->size','relax->layout_sizes[event->position] = 0'),
 'placement-origin':('offset = relax->events[event_begin].offset','offset = 0'),
 'stable-order':('parser->fragment_order[first + i]].offset','first + i].offset'),
 'last-lane':('_bzhi_u32(UINT16_MAX, count);','_bzhi_u32(UINT16_MAX, count ? count - 1 : 0);')
}
for name,(a,b) in pairs.items():
 assert a in s,name
 f=u/'mutant.c';f.write_text(s.replace(a,b,1))
 subprocess.run([__import__('os').environ.get('CC', 'cc'),'-O2','-march=native',u/'base.c',f,u/'check.c','-o',p/'layout-mutant'],check=True)
 r=subprocess.run([p/'layout-mutant'],capture_output=True,text=True)
 if r.returncode==0:raise RuntimeError(name)
 print(name,r.returncode,r.stderr.strip().replace('\n',' ')[:130],flush=True)
