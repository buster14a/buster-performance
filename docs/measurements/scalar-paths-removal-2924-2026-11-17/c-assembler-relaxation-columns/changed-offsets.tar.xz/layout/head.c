#include "fixture.h"
static void asm_relax_add(AsmRelax* relax, const AsmFragment* fragment, uint32_t id, uint32_t position, uint32_t region, uint32_t* end)
{
    const bool align = (region & 3) == ASM_RELAX_ALIGN;
    relax->events[relax->event_count++] = (AsmRelaxEvent){
        .local = align ? fragment->alignment : 0,
        .offset = fragment->offset,
        .size = fragment->size,
        .gap = fragment->offset - *end,
        .fragment = id,
        .position = position,
        .placed_size = fragment->size,
        .anchor = align ? fragment->maximum : 0,
        .region = region,
    };
    *end = fragment->offset + fragment->size;
}

static __m512i asm_fragment_offsets(__m512i size, uint32_t base)
{
    const __m512i zero = _mm512_setzero_si512();
    __m512i sum = _mm512_add_epi32(size, _mm512_alignr_epi32(size, zero, 15));
    sum = _mm512_add_epi32(sum, _mm512_alignr_epi32(sum, zero, 14));
    sum = _mm512_add_epi32(sum, _mm512_alignr_epi32(sum, zero, 12));
    sum = _mm512_add_epi32(sum, _mm512_alignr_epi32(sum, zero, 8));
    return _mm512_add_epi32(_mm512_sub_epi32(sum, size), _mm512_set1_epi32((int32_t)base));
}

static void asm_store_offsets(AsmParser* parser, uint32_t first, uint32_t count, __m512i offsets)
{
    uint32_t values[16];
    _mm512_storeu_si512(values, offsets);
    for (uint32_t i = 0; i < count; i += 1)
    {
        parser->fragments[parser->fragment_order[first + i]].offset = values[i];
    }
}

static void asm_relax_shift_gap(AsmParser* parser, const AsmRelax* relax, uint32_t first, uint32_t end, uint32_t shift)
{
    for (uint32_t pos = first; shift != 0 && pos < end;)
    {
        const uint32_t count = end - pos < 16 ? end - pos : 16;
        const __mmask16 live = (__mmask16)_bzhi_u32(UINT16_MAX, count);
        uint32_t* column = relax->layout_offsets + pos;
        const __m512i offsets = _mm512_add_epi32(_mm512_maskz_loadu_epi32(live, column), _mm512_set1_epi32((int32_t)shift));
        _mm512_mask_storeu_epi32(column, live, offsets);
        asm_store_offsets(parser, pos, count, offsets);
        pos += count;
    }
}

void head_first(AsmParser* parser, AsmRelax* relax, uint32_t section)
{
    const uint32_t end = parser->fragment_begin[section + 1];
    uint32_t offset = 0, region = 0, event_end = 0;
    relax->event_begin[section] = relax->event_count;
    for (uint32_t first = parser->fragment_begin[section]; first < end && parser->result.error == 0;)
    {
        uint32_t count = end - first < 16 ? end - first : 16;
        const __mmask16 live = (__mmask16)_bzhi_u32(UINT16_MAX, count);
        // Read each fragment once for its size and role. Retain sizes only for the subsequent placements.
        uint8_t block_roles[16] = {0};
        uint32_t block_sizes[16];
        for (uint32_t i = 0; i < count; i += 1)
        {
            const AsmFragment* fragment = &parser->fragments[parser->fragment_order[first + i]];
            block_sizes[i] = fragment->size;
            block_roles[i] = fragment->layout_role;
        }
        const __m128i roles = _mm_loadu_si128((const __m128i*)block_roles);
        const __mmask16 alignments = _mm_cmpeq_epi8_mask(roles, _mm_set1_epi8(ASM_RELAX_ALIGN));
        const __m512i sizes = _mm512_maskz_loadu_epi32(live & ~alignments, block_sizes);
        __m512i offsets = asm_fragment_offsets(sizes, offset);
        uint32_t ends[16];
        __m512i final_sizes = sizes;
        for (uint32_t bits = alignments; bits != 0; bits &= bits - 1)
        {
            const uint32_t i = (uint32_t)__builtin_ctz(bits);
            AsmFragment* fragment = &parser->fragments[parser->fragment_order[first + i]];
            const __m512i at = _mm512_permutexvar_epi32(_mm512_set1_epi32((int)i), offsets);
            const uint32_t pos = (uint32_t)_mm_cvtsi128_si32(_mm512_castsi512_si128(at));
            const uint32_t pad = -pos & (fragment->alignment - 1);
            const uint32_t size = pad <= fragment->maximum ? pad : 0;
            fragment->size = size;
            const __m512i delta = _mm512_set1_epi32((int)size);
            offsets = _mm512_mask_add_epi32(offsets, (__mmask16)(0xfffeu << i), offsets, delta);
            final_sizes = _mm512_mask_mov_epi32(final_sizes, (__mmask16)(1u << i), delta);
        }
        const __m512i final = _mm512_add_epi32(offsets, final_sizes);
        _mm512_storeu_si512(ends, final);
        const uint32_t too_large = _mm512_mask_cmpgt_epu32_mask(live, final, _mm512_set1_epi32(BUSTER_ASM_MAX_SECTION));
        count = too_large != 0 ? 1 + (uint32_t)__builtin_ctz(too_large) : count;
        _mm512_mask_storeu_epi32(relax->layout_offsets + first, (__mmask16)_bzhi_u32(UINT16_MAX, count), offsets);
        asm_store_offsets(parser, first, count, offsets);
        for (uint32_t bits = _bzhi_u32(_mm_cmpneq_epi8_mask(roles, _mm_setzero_si128()), count); bits != 0; bits &= bits - 1)
        {
            const uint32_t pos = first + (uint32_t)__builtin_ctz(bits);
            const uint32_t id = parser->fragment_order[pos];
            const uint32_t role = block_roles[pos - first];
            asm_relax_add(relax, &parser->fragments[id], id, pos, (region << 2) | role, &event_end);
            region += role == ASM_RELAX_ALIGN;
        }
        offset = ends[count - 1];
        first += count;
        if (too_large != 0)
        {
            asm_fail(parser, parser->fragments[parser->fragment_order[first - 1]].location, "section exceeds the 256 MiB layout limit");
        }
    }
    relax->tails[section] = offset - event_end;
    parser->sections[section].size = offset;
}

void head_place(AsmParser* parser, const AsmRelax* relax, uint32_t section)
{
    uint32_t begin = parser->fragment_begin[section];
    uint32_t tail_shift = 0;
    for (uint32_t i = relax->event_begin[section]; i < relax->event_begin[section + 1]; i += 1)
    {
        AsmRelaxEvent* event = &relax->events[i];
        AsmFragment* fragment = &parser->fragments[event->fragment];
        const uint32_t shift = event->offset - fragment->offset;
        asm_relax_shift_gap(parser, relax, begin, event->position, shift);
        tail_shift = shift + event->size - event->placed_size;
        fragment->offset = event->offset;
        fragment->size = event->size;
        event->placed_size = event->size;
        relax->layout_offsets[event->position] = event->offset;
        begin = event->position + 1;
    }
    asm_relax_shift_gap(parser, relax, begin, parser->fragment_begin[section + 1], tail_shift);
}
