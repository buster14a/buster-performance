#include "fixture.h"
#include <stdio.h>
enum {MAX=1026,CAP=MAX*3+192};
void base_first(AsmParser*,AsmRelax*,uint32_t);void head_first(AsmParser*,AsmRelax*,uint32_t);
void base_place(AsmParser*,const AsmRelax*,uint32_t);void head_place(AsmParser*,const AsmRelax*,uint32_t);
static AsmFragment f[2][CAP];
static uint32_t sizes[2][CAP],order[CAP],begin[4],eb[2][4],tail[2][4];
static uint8_t roles[CAP];
static uint64_t branches[(CAP+63)/64];
static AsmRelaxEvent events[2][CAP];
static AsmParser parsers[2];static AsmRelax rs[2];
static uint32_t rng;static uint32_t next(void){rng=rng*1664525u+1013904223u;return rng;}
static int check(int stage,unsigned n,unsigned dist,unsigned phase){
 const AsmRelax *a=&rs[0],*b=&rs[1];
 if(parsers[0].result.error!=parsers[1].result.error||parsers[0].result.location!=parsers[1].result.location)return 1;
 if(a->event_count!=b->event_count||tail[0][1]!=tail[1][1]||parsers[0].sections[1].size!=parsers[1].sections[1].size)return 2;
 for(unsigned i=0;i<a->event_count;i++){
  AsmRelaxEvent x=events[0][i],y=events[1][i];x.position=y.position;x.placed_size=y.placed_size;
  if(memcmp(&x,&y,sizeof x)||order[y.position]!=y.fragment)return 3;
 }
 if(!parsers[0].result.error)for(unsigned i=0;i<n;i++){
  unsigned id=order[phase+i];if(f[0][id].size!=f[1][id].size||f[0][id].offset!=f[1][id].offset){fprintf(stderr,"stage %d n %u shape %u phase %u id %u\n",stage,n,dist,phase,id);return 4;}
 }
 return 0;
}
int main(void){
 unsigned lens[256],cnt=0,fixtures=0;
 for(unsigned n=0;n<100;n++)lens[cnt++]=n;
 for(unsigned n=128;n<=1024;n*=2)for(int delta=-2;delta<=2;delta++)lens[cnt++]=n+delta;
 for(unsigned dist=0;dist<10;dist++)for(unsigned phase=0;phase<16;phase++)for(unsigned z=0;z<cnt;z++){
  unsigned n=lens[z];rng=1+n+1000*dist+31*phase;
  memset(branches,0,sizeof branches);memset(roles,0,sizeof roles);memset(events,0,sizeof events);
  begin[1]=phase;begin[2]=phase+n;
  for(unsigned pos=0;pos<n;pos++){
   unsigned id=phase+3*pos, i=phase+pos,r=next();
   unsigned role=dist==0?0:dist==1?1:dist==2?2:dist==3?3:dist==4?pos%4:dist==5?(pos%17==0?1:0):dist==6?(pos%7==0?2:0):dist==7?(pos>=n/2?3:0):r>>30;
   unsigned size=dist==9 && pos%17==16?(1u<<27):r%129;
   f[0][id]=(AsmFragment){.kind=role==1?ASM_ALIGN:role==2?(r&1?ASM_ULEB:ASM_SLEB):0,.layout_role=role,.size=size,.alignment=1u<<(r%9),.maximum=(r>>16)&255,.location=id+1};
   if(role==3)branches[id/64]|=1ull<<(id%64);
   order[i]=id;roles[i]=role;sizes[0][i]=sizes[1][i]=size;f[1][id]=f[0][id];
  }
  for(unsigned j=0;j<2;j++){
   parsers[j]=(AsmParser){.fragments=f[j],.fragment_order=order,.fragment_begin=begin,.sections=calloc(4,sizeof(*parsers[j].sections))};
   rs[j]=(AsmRelax){.layout_offsets=sizes[j],.layout_roles=roles,.branches=branches,.events=events[j],.event_begin=eb[j],.tails=tail[j]};eb[j][1]=eb[j][2]=0;tail[j][1]=0;
  }
  base_first(&parsers[0],&rs[0],1);head_first(&parsers[1],&rs[1],1);
  int rc=check(0,n,dist,phase);if(rc){fprintf(stderr,"first invariant %d n=%u dist=%u phase=%u\n",rc,n,dist,phase);return rc;}
  for(unsigned pass=0;pass<3&&!parsers[0].result.error;pass++){
   uint32_t o=0;
   for(unsigned e=0;e<rs[0].event_count;e++){
    unsigned size=next()%24;o+=events[0][e].gap;
    for(unsigned j=0;j<2;j++){events[j][e].offset=o;events[j][e].size=size;if((events[j][e].region&3)==2)f[j][events[j][e].fragment].size=size;}
    o+=size;
   }
   eb[0][2]=eb[1][2]=rs[0].event_count;
   base_place(&parsers[0],&rs[0],1);head_place(&parsers[1],&rs[1],1);
   rc=check(1,n,dist,phase);if(rc)return rc;
  }
  free(parsers[0].sections);free(parsers[1].sections);fixtures++;
 }
 printf("%u fragment layouts, including overflow, alignment, LEB128 and repeated placement, matched\n",fixtures);
}
