from pathlib import Path
import subprocess
p=Path(__file__).parent;f='src/buster/compiler/tier1_emit_cfg.c';s=subprocess.check_output(['git','-C',str(p/'tree'),'show','7e28b4ed7:'+f],text=True)
a=s.index('static Tier1EmitError tier1_emit_cfg_frame(');b=s.index('\n}',a)+3;c=s[a:b]
c=c.replace('    uint8_t* phis = ir_allocate(scratch, (uint64_t)input->value_count + 1, 1, &ok);','''    // Only a spilled phi uses a predecessor's end to widen its frame slot.
    const bool need_phi_rows = spills != 0 && input->phi_count != 0;
    uint8_t* phis = need_phi_rows ? ir_allocate(scratch, (uint64_t)input->value_count + 1, 1, &ok) : NULL;''')
c=c.replace('    if (error == TIER1_EMIT_OK)\n    {\n        memset(phis', '    if (error == TIER1_EMIT_OK && need_phi_rows)\n    {\n        memset(phis')
x=c.index('    for (uint32_t v = 0; error ==');y=c.index('    // The rows past the spills',x)
old=c[x:y];mark='            const uint32_t node = indices[k];'
core=old[old.index(mark):old.rindex('        }')]
lo=core.index('            const uint32_t home = phis[v]')
hi=core.index('            prepared->starts[node] = start;',lo)
core=core[:lo]+'''            if (need_phi_rows && phis[v] != 0)
            {
                const uint32_t home = tier1_cfg_block_at(input, cfg, input->definitions[v]);
                for (uint32_t e = input->predecessor_offsets[home]; e < input->predecessor_offsets[home + 1]; e += 1)
                {
                    const uint32_t exit = input->block_starts[input->predecessors[e] + 1] - 1;
                    start = exit < start ? exit : start;
                    end = exit + 1 > end ? exit + 1 : end;
                }
            }
'''+core[hi:]
new='''    const __m512i spill_count = _mm512_set1_epi32((int32_t)spills);
    for (uint32_t first = 0; error == TIER1_EMIT_OK && spills != 0 && first < input->value_count;)
    {
        const uint32_t left = input->value_count - first;
        const uint32_t take = left < 16 ? left : 16;
        const __mmask16 live = (__mmask16)_bzhi_u32(UINT16_MAX, take);
        const __m512i ids = _mm512_maskz_loadu_epi32(live, cfg->allocation.spill_ids + first);
        uint32_t used = (uint32_t)_mm512_mask_cmplt_epu32_mask(live, ids, spill_count);
        while (used != 0)
        {
            const uint32_t v = first + (uint32_t)__builtin_ctz(used);
            const uint32_t k = cfg->allocation.spill_ids[v];
            used &= used - 1;
'''+core+'''        }
        first += take;
    }
'''
c=c[:x]+new+c[y:]
x=c.index('    for (uint32_t reg =',c.index('    uint32_t row = spills;'));y=c.index('    for (uint32_t o =',x)
c=c[:x]+'''    if (error == TIER1_EMIT_OK)
    {
        for (uint32_t bits = prepared->call_save_mask & ((1u << BUSTER_TIER1_EMIT_GENERAL_REGISTERS) - 1); bits != 0; bits &= bits - 1)
        {
            const uint32_t below = (bits & -bits) - 1;
            indices[row++] = count + (uint32_t)__builtin_popcount(prepared->call_save_columns & below);
        }
        for (uint32_t bits = prepared->mask_save_mask & 255u; bits != 0; bits &= bits - 1)
        {
            indices[row++] = count + call_columns + (uint32_t)__builtin_ctz(bits);
        }
        for (uint32_t bits = prepared->vector_save_mask; bits != 0; bits &= bits - 1)
        {
            indices[row++] = count + call_columns + prepared->mask_columns + (uint32_t)__builtin_ctz(bits);
        }
        for (uint32_t bits = cfg->temp_slots & ((1u << BUSTER_TIER1_ALLOCATE_CLASSES) - 1); bits != 0; bits &= bits - 1)
        {
            indices[row++] = count + temporary_columns + (uint32_t)__builtin_ctz(bits);
        }
    }
'''+c[y:];(p/'spill-cfg.c').write_text(s[:a]+c+s[b:])
