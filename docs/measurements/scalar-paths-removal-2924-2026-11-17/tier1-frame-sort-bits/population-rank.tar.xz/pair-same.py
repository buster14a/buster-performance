from collections import defaultdict
from pathlib import Path
from statistics import median
import sys,re
rows=defaultdict(lambda:defaultdict(dict))
side=sys.argv[1]
for l in Path(sys.argv[2]).read_text().splitlines():
 m=re.match(r'[\w-]+-tier1-([\w-]+)/sample-(\d+)-([\w-]+).log:.*?(\d+) user cycles,',l)
 if m:rows[m[1]][m[2]][m[3]]=int(m[4])
for group,samples in rows.items():
 s=[x for x in samples.values() if len(x)==4];print(group,len(s),*(round(100*(median(v)-1),3) for v in [( (x[side+'-head']+x[side+'-repeat'])/(x['base']+x['control']) for x in s), (x['control']/x['base'] for x in s),(x[side+'-repeat']/x[side+'-head'] for x in s)])) if s else None
