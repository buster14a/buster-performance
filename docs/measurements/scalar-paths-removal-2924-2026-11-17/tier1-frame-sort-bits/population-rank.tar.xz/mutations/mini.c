// One frame planner, from the tree on the include path, behind a wrapper named SIDE.
#include "host_isa.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <inttypes.h>
typedef struct String8 String8;
struct String8
{
    char* pointer;
    uint64_t length;
};
#include "buster/compiler/lane.c"
#include "buster/compiler/c_types.c"
#include "buster/compiler/calling_convention.c"
#include "mutated-frame.c"

#ifndef BUSTER_ARRAY_LENGTH
#define BUSTER_ARRAY_LENGTH(a) (sizeof(a)/sizeof((a)[0]))
#endif
#include "buster/compiler/tier1_frame_test.c"
int main(int argc, char** argv)
{
    Tier1FrameTest test = {0};
    if (argc == 2) variant = (unsigned)atoi(argv[1]);
    tier1_frame_test_sort(&test);
    for (uint32_t count = 1; count <= 32; count += 1)
    {
        const uint32_t events = count * 2;
        uint64_t* key = malloc((uint64_t)events * sizeof(*key));
        uint32_t order[128];
        for (uint32_t seed = 0; seed < 32; seed += 1)
        {
            for (uint32_t i = 0; i < events; i += 1)
            {
                key[i] = ((uint64_t)((i * 73 + seed * 7) % (seed + 1)) << 32) | i;
            }
            memset(order, 0xff, sizeof(order));
            tier1_frame_rank(key, count, order);
            uint64_t previous = 0;
            bool valid = true;
            for (uint32_t i = 0; i < events && valid; i += 1)
            {
                const uint32_t item = order[i];
                if (item >= events)
                {
                    valid = false;
                }
                else
                {
                    const uint64_t value = key[item / 2 + (item & 1) * count];
                    valid = i == 0 || previous < value;
                    previous = value;
                }
            }
            tier1_frame_test_expect(&test, valid, "event IDs enumerate each original key in increasing order");
        }
        free(key);
    }
    printf("variant %u: %lu failed of %lu checks\n",variant,test.failures,test.checks);
    return test.failures != 0;
}
