from pathlib import Path
import subprocess
p=Path('/tmp/buster-frame');r=p/'tree'
path='src/buster/compiler/tier1_emit_cfg.c'
s=subprocess.check_output(['git','-C',str(r),'show','HEAD:'+path],text=True)
a=s.index('    prepared->starts = ok ? ir_allocate(output, prepared->slot_columns');b=s.index('    uint8_t* operations',a)
s=s[:a]+'''    // All four columns have the same row count. Keep their 64-byte alignment and initialize each row once below.
    const uint64_t stride = ((uint64_t)prepared->slot_columns + 15) & ~UINT64_C(15);
    uint32_t* columns = ok ? arena_push_array(output, 3 * stride + prepared->slot_columns, sizeof(*columns), 64) : 0;
    ok = ok && columns != 0;
    if (ok)
    {
        prepared->starts = columns;
        prepared->ends = columns + stride;
        prepared->sizes = columns + 2 * stride;
        prepared->alignments = columns + 3 * stride;
    }
'''+s[b:]
s=s.replace('uint32_t* prospective = ok ? ir_allocate(scratch, (uint64_t)value_count + fixed_columns + objects, 4, &ok) : 0;', '''uint32_t* prospective = ok ? arena_push_array(scratch, (uint64_t)value_count + fixed_columns + objects, sizeof(*prospective), 64) : 0;
    ok = ok && prospective != 0;''')
a=s.index('        for (uint32_t column = 0; column < prepared->slot_columns; column += 1)')
b=s.index('        for (uint32_t o = 0;',a)
s=s[:a]+'''        memset(prepared->starts, 0, (size_t)prepared->slot_columns * sizeof(*prepared->starts));
        for (uint32_t column = 0; column < prepared->slot_columns; column += 1)
        {
            prepared->ends[column] = (uint32_t)positions;
        }
        for (uint32_t column = count; column < count + fixed_columns; column += 1)
        {
            prepared->sizes[column] = 8;
            prepared->alignments[column] = 8;
        }
'''+s[b:]
a=s.index('        for (uint32_t v = 0; v < value_count; v += 1)\n        {\n            prospective');b=s.index('        for (uint32_t slot',a)
s=s[:a]+'''        memcpy(prospective, value_nodes, (size_t)value_count * sizeof(*prospective));
'''+s[b:]
(p/'columns-cfg.c').write_text(s)
for n in ('row.c','test.c'):
 (p/('columns-'+n)).write_bytes((p/('indexed-'+n)).read_bytes())
for n in ('task','driver','same','same-driver'):
 s=(p/('direct-'+n)).read_text().replace('direct-','columns-').replace('direct-same','columns-same')
 if n=='task':
  a=s.index('"$root/locked" bash "$root/columns-gate"');b=s.index('while [[',a);s=s[:a]+s[b:]
  s=s.replace('cp "$root/columns-test.c"', 'cp "$root/columns-cfg.c" src/buster/compiler/tier1_emit_cfg.c\ncp "$root/columns-test.c"')
  s=s.replace('for group in sqlite', '''for suite in test-tier1-emit test-tier1-cfg test-tier1-cfg-source; do
 "$root/locked" timeout 360 build/compiler "$suite" >"$root/columns-$suite.log" 2>&1
done
for group in sqlite''')
 (p/('columns-'+n)).write_text(s)
