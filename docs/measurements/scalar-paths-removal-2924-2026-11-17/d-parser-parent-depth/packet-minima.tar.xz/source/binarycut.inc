// Eight full-width (depth, precedence) keys. The input and output columns have no padding contract.
static __m512i packet_keys(const ParseKernels* k, uint32_t first, __mmask8 live, const uint8_t* levels)
{
    const __m128i bytes = _mm_maskz_loadu_epi8((__mmask16)live, k->roles + first);
    const __m512i table = parse_lookup8(levels, _mm512_zextsi128_si512(bytes));
    const __m512i depths = _mm512_cvtepu32_epi64(_mm256_maskz_loadu_epi32(live, k->node_depths + first));
    return _mm512_add_epi64(_mm512_slli_epi64(depths, 5), _mm512_cvtepu8_epi64(_mm512_castsi512_si128(table)));
}

static uint64_t packet_minimum(const uint32_t* storage, uint32_t i)
{
    uint64_t key;
    memcpy(&key, storage + (uint64_t)i * 2, sizeof(key));
    return key;
}

static void packet_direction(ParseKernels* k, uint32_t count, bool right)
{
    const __m512i lanes = _mm512_setr_epi64(0,1,2,3,4,5,6,7);
    uint32_t used = 0;
    const uint32_t blocks = ((uint64_t)count + 7) / 8;
    for (uint32_t order = 0; order < blocks; ++order)
    {
        const uint32_t first = (right ? blocks - 1 - order : order) * 8;
        const uint32_t left = count - first;
        const __mmask8 live = (__mmask8)_bzhi_u32(255, left < 8 ? left : 8);
        const __m512i keys = packet_keys(k, first, live, parse_parent_tables.levels);
        const __m512i thresholds = packet_keys(k, first, live, right ? parse_parent_tables.right_thresholds : parse_parent_tables.left_thresholds);
        const __m512i ids = _mm512_add_epi64(lanes, _mm512_set1_epi64(first));
        // Search in the direction of the nearest admissible token. Skip a group only when
        // its minimum excludes every key. The wrapped lanes of these permutes are never used.
        const int step = right ? 1 : -1;
        const __m512i delta = _mm512_set1_epi64(step);
        const __m512i next = _mm512_add_epi64(lanes, delta);
        const __m512i near = _mm512_permutexvar_epi64(next, keys);
        const __m512i two = _mm512_min_epu64(near, _mm512_permutexvar_epi64(next, near));
        const __m512i four = _mm512_min_epu64(two, _mm512_permutexvar_epi64(_mm512_add_epi64(next, delta), two));
        __m512i cursor = lanes;
        const __m512i length = _mm512_set1_epi64(left < 8 ? left : 8);
        for (unsigned distance = 4; distance != 0; distance >>= 1)
        {
            const __m512i to = _mm512_add_epi64(cursor, _mm512_set1_epi64(step * (int)distance));
            const __m512i lowest = distance == 4 ? four : _mm512_permutexvar_epi64(cursor, distance == 2 ? two : near);
            const __mmask8 inside = _mm512_mask_cmplt_epu64_mask(live, to, length);
            cursor = _mm512_mask_mov_epi64(cursor, _mm512_mask_cmpge_epu64_mask(inside, lowest, thresholds), to);
        }
        const __m512i candidate = _mm512_add_epi64(cursor, delta);
        const __mmask8 inside = _mm512_mask_cmplt_epu64_mask(live, candidate, length);
        const __mmask8 hit = _mm512_mask_cmplt_epu64_mask(inside, _mm512_permutexvar_epi64(candidate, keys), thresholds);
        const __m512i found = _mm512_mask_add_epi64(_mm512_set1_epi64(UINT32_MAX), hit, candidate, _mm512_set1_epi64(first));
        uint32_t pending = live & ~hit;
        _mm256_mask_storeu_epi32((right ? k->parents : k->lefts) + first, live, _mm512_cvtepi64_epi32(found));
        if (used != 0 && pending != 0)
        {
            pending &= _mm512_cmpgt_epu64_mask(thresholds, _mm512_set1_epi64((int64_t)packet_minimum(k->stack_keys, 0)));
            uint64_t limits[8];
            _mm512_storeu_si512(limits, thresholds);
            for (uint32_t bits = pending; bits != 0; bits &= bits - 1)
            {
                const uint32_t lane = (uint32_t)__builtin_ctz(bits);
                const uint64_t limit = limits[lane];
                uint32_t slot = used;
                if (packet_minimum(k->stack_keys, used - 1) >= limit)
                {
                    uint32_t lo = 0;
                    uint32_t hi = used - 1;
                    while (lo < hi)
                    {
                        const uint32_t mid = lo + (hi - lo)/2;
                        if (packet_minimum(k->stack_keys, mid) < limit) lo = mid + 1;
                        else hi = mid;
                    }
                    slot = lo;
                }
                if (slot != 0)
                {
                    const uint32_t start = k->stack[slot-1];
                    const uint32_t available = count - start;
                    const __mmask8 mask = (__mmask8)_bzhi_u32(255, available < 8 ? available : 8);
                    const __m512i previous = packet_keys(k, start, mask, parse_parent_tables.levels);
                    const uint32_t match = _mm512_mask_cmplt_epu64_mask(mask, previous, _mm512_set1_epi64((int64_t)limit));
                    const uint32_t index = right ? (uint32_t)__builtin_ctz(match) : 31u - (uint32_t)__builtin_clz(match);
                    (right ? k->parents : k->lefts)[first+lane] = start+index;
                }
            }
        }
        if (order + 1 < blocks)
        {
            const uint64_t least = _mm512_mask_reduce_min_epu64(live, keys);
            while (used != 0 && packet_minimum(k->stack_keys,used-1) >= least) --used;
            k->stack[used] = first;
            memcpy(k->stack_keys + (uint64_t)used * 2, &least, sizeof(least));
            ++used;
        }
    }
}

static void parent_packets(ParseKernels* k,uint32_t n)
{
    packet_direction(k,n,false);
    packet_direction(k,n,true);
    for (uint32_t i=0;i<n;++i)
    {
        const uint8_t rule=parse_role_rules[k->roles[i]];
        const uint32_t left=k->lefts[i],right=k->parents[i];
        if(rule==PARSE_RULE_LEFT) k->parents[i]=left;
        else if(rule==PARSE_RULE_SELECT)
        {
            const bool l = left!=BUSTER_PARSE_NONE, r=right!=BUSTER_PARSE_NONE;
            k->parents[i]=parse_select(left,l?k->node_depths[left]:0,l?parse_role_levels[k->roles[left]]:0,
                                       right,r?k->node_depths[right]:0,r?parse_role_levels[k->roles[right]]:0);
        }
    }
}
