from pathlib import Path
p=Path(__file__).parent;base=(p/'parent-packets.inc').read_text()
a=base.index('        __m512i found =');z=base.index('        _mm256_mask_storeu',a)
body='''        // Search in the direction of the nearest admissible token. Skip a group only when
        // its minimum excludes every key. The wrapped lanes of these permutes are never used.
        const int step = right ? 1 : -1;
        const __m512i delta = _mm512_set1_epi64(step);
        const __m512i next = _mm512_add_epi64(lanes, delta);
        const __m512i near = _mm512_permutexvar_epi64(next, keys);
        const __m512i two = _mm512_min_epu64(near, _mm512_permutexvar_epi64(next, near));
        const __m512i four = _mm512_min_epu64(two, _mm512_permutexvar_epi64(_mm512_add_epi64(next, delta), two));
        __m512i cursor = lanes;
        const __m512i length = _mm512_set1_epi64(left < 8 ? left : 8);
        for (unsigned distance = 4; distance != 0; distance >>= 1)
        {
            const __m512i to = _mm512_add_epi64(cursor, _mm512_set1_epi64(step * (int)distance));
            const __m512i lowest = distance == 4 ? four : _mm512_permutexvar_epi64(cursor, distance == 2 ? two : near);
            const __mmask8 inside = _mm512_mask_cmplt_epu64_mask(live, to, length);
            cursor = _mm512_mask_mov_epi64(cursor, _mm512_mask_cmpge_epu64_mask(inside, lowest, thresholds), to);
        }
        const __m512i candidate = _mm512_add_epi64(cursor, delta);
        const __mmask8 inside = _mm512_mask_cmplt_epu64_mask(live, candidate, length);
        const __mmask8 hit = _mm512_mask_cmplt_epu64_mask(inside, _mm512_permutexvar_epi64(candidate, keys), thresholds);
        const __m512i found = _mm512_mask_add_epi64(_mm512_set1_epi64(UINT32_MAX), hit, candidate, _mm512_set1_epi64(first));
        uint32_t pending = live & ~hit;
'''
for n,binning,cut,adj in [('binarykeys',1,0,0),('binarycut',1,1,0),('adjacentcut',0,1,0),('adjacentfirst',1,1,1)]:
 s=base[:a]+body+base[z:] if binning else base
 if adj:
  start=s.index('        const __m512i two =');end=s.index('        _mm256_mask_storeu',start)
  src=s[start:end].replace('        const __m512i length = _mm512_set1_epi64(left < 8 ? left : 8);','').replace('        const __mmask8 hit =','        hit =').replace('        const __m512i found =','        found =').replace('        uint32_t pending = live & ~hit;','')
  s=s[:start]+'''        const __m512i length = _mm512_set1_epi64(left < 8 ? left : 8);
        const __mmask8 has_neighbor = _mm512_mask_cmplt_epu64_mask(live, next, length);
        __mmask8 hit = _mm512_mask_cmplt_epu64_mask(has_neighbor, near, thresholds);
        __m512i found = _mm512_mask_add_epi64(_mm512_set1_epi64(UINT32_MAX), hit, next, _mm512_set1_epi64(first));
        if (hit != has_neighbor)
        {
'''+src+'''        }
        uint32_t pending = live & ~hit;
'''+s[end:]
 if cut:s=s.replace('            uint64_t limits[8];','''            pending &= _mm512_cmpgt_epu64_mask(thresholds, _mm512_set1_epi64((int64_t)packet_minimum(k->stack_keys, 0)));
            uint64_t limits[8];''')
 (p/(n+'.inc')).write_text(s)
 (p/(n+'.c')).write_text((p/'check-packets.c').read_text().replace('parent-packets.inc',n+'.inc'))
(p/'compare-binary').write_text((p/'compare-online').read_text().replace('online onlinewide onlinetable tablewide','binarykeys binarycut adjacentcut adjacentfirst').replace('online-','binary-'))
