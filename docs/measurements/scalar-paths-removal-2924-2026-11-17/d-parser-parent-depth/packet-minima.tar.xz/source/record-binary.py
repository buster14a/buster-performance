from pathlib import Path
from collections import defaultdict
from statistics import median
import tarfile,re
p=Path(__file__).parent;r=p/'results';out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-parent-depth')
names={'binarykeys':'Four-, two- and one-lane minima','binarycut':'Minima with a stack threshold check','adjacentcut':'Adjacent-lane scan with a stack threshold check','adjacentfirst':'Try the immediate neighbor before the minima'}
rows=[]
for name,title in names.items():
 d=defaultdict(list)
 for seed in (1,133,789):
  assert '351232 synthetic parent indices matched at 88 sizes' in (r/f'{name}-{seed}.log').read_text()
  for line in (r/f'{name}-{seed}.tsv').read_text().splitlines():
   n,g,rep,a,b=map(int,line.split());assert rep>0 and min(a,b)>0;d[n,g].append(b/a)
 assert len(d)==616 and all(len(xs)==3 for xs in d.values())
 for group,num in [('dense',1),('sqlite',1),('lua',34),('musl',1336)]:
  m=re.search(r'(\d+) captured parser calls and (\d+) parent indices matched for both methods',(r/f'{name}-{group}.log').read_text())
  assert m and int(m.group(1))==num
 ratios=[median(xs)for xs in d.values()]
 rows.append(f'| {title} | {sum(x<=1 for x in ratios)}/616 | {median(ratios):.4f} | {max(ratios):.4f} |')
doc=out/'README.md';old=doc.read_text();heading='## Searching each packet with minima for four, two and one neighbor'
assert heading not in old
doc.write_text(old.rstrip()+'\n\n'+heading+'''

The vector query advances within each eight-lane packet past neighbors whose minimum is still above the requested threshold. A second version compares unanswered lanes to the minimum of the pending stack before searching it. The adjacent-lane versions use this check with a linear lane scan or first resolve an entire packet from adjacent neighbors. Each implementation preserves the full unsigned depth.

| Implementation | Cells at or below scalar | Median ratio | Slowest ratio |
| --- | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

All four reproduced the recorded parent of every token across 1,372 real and generated parser calls, including the declaration at depth 2,305. Three seeds each checked 351,232 synthetic indices and the independent full-width oracle. All four still exceed the scalar time at some sizes.

[Implementations, independent oracle, replay checks and all three locked timing runs](packet-minima.tar.xz)
''')
with tarfile.open(out/'packet-minima.tar.xz','w:xz',preset=2)as t:
 for f in ['binary-parents.py','parent-packets.inc','check-packets.c','compare-binary','recover-binary','record-binary.py']:t.add(p/f,'source/'+f)
 for k in names:
  for f in (p/(k+'.c'),p/(k+'.inc')):t.add(f,'source/'+f.name)
  for f in sorted(r.glob(k+'-*')):
   if f.suffix in ['.tsv','.log']:t.add(f,'native/'+f.name)
print(*rows,sep='\n')
