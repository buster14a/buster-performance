from pathlib import Path
from statistics import median
from collections import defaultdict
import tarfile, struct
p=Path(__file__).parent;r=p/'results'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-parent-depth');out.mkdir(exist_ok=True)
groups=['lua','sqlite','musl','dense'];sources=[]
for g in groups:
 records=[list(map(int,x.split('\t')[2:])) for x in (r/f'{g}-census.log').read_text().splitlines() if x.startswith('census\t')]
 counts=[sum(x)for x in list(zip(*records))[:-1]];largest=max(x[-1] for x in records);sources.append((g,len(records),*counts,largest))
 raw=(r/f'graphs-{g}.bin').read_bytes();offset=calls=total=0
 while offset<len(raw):
  n,=struct.unpack_from('<I',raw,offset);offset+=4+9*n;calls+=1;total+=n
 assert offset==len(raw) and [calls,total]==counts[1:3]
methods=['packet','deferred','stackvector','online','onlinewide','onlinetable','tablewide'];rows=[]
for name in methods:
 a=defaultdict(list)
 for seed in (1,133,789):
  assert '351232 synthetic parent indices matched at 88 sizes' in (r/f'{name}-{seed}.log').read_text()
  for line in (r/f'{name}-{seed}.tsv').read_text().splitlines():
   n,shape,reps,parent,candidate=map(int,line.split());a[n,shape].append(candidate/parent)
 for g in groups:
  assert 'parent indices matched for both methods' in (r/f'{name}-{g}.log').read_text()
 assert len(a)==616 and all(len(v)==3 for v in a.values())
 ratios=[median(v)for v in a.values()]
 rows.append((name,sum(v<=1 for v in ratios),median(ratios),max(ratios)))
tables=['Eight-lane full-width queries and block minima','Register stack tops, deferred scalar selection','Register stack tops, deferred vector selection','Gather role metadata, resolve on arrival','Gather role metadata, always store wide keys','Read packed role metadata, resolve on arrival','Read packed role metadata, always store wide keys']
doc='''# K4 parent indices past the packed depth limit

For #3442, the reach probe ran the ordinary preprocessor and parser and recorded the token roles, node depths and final K4 parents. Lua, SQLite and musl stayed within the 2,047-depth packed range. The separate valid C fixture returns a parameter enclosed in 2,304 nested parentheses and reaches the production fallback.

| Input | Files | K4 calls | Parent indices | Deep calls | Deep indices | Maximum depth |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(f'| {g} | {files:,} | {calls:,} | {total:,} | {deep:,} | {wide:,} | {peak:,} |'for g,files,tokens,calls,total,deep,wide,peak in sources)+'''

Seven candidate implementations were compared to the production scalar fallback on the locked Ryzen 7 9700X. Each reproduced every captured parent. A second oracle searches directly left and right for the nearest admissible key, applies the role's selection and resolves ties by operator level. It checks inputs through 129 tokens, including offsets near UINT32_MAX where a 32-bit depth-times-32 key wraps. All widths also run against the production fallback at its representable depths. Larger inputs include 16,384 tokens and use both rising and falling depths.

| Implementation | Shape and size cells at or below scalar | Median ratio | Maximum ratio |
| --- | ---: | ---: | ---: |
'''+'\n'.join(f'| {label} | {wins}/616 | {mid:.3f} | {worst:.3f} |'for label,(_,wins,mid,worst)in zip(tables,rows))+'''

Each cell is the median of three seeds, with seven alternating timing samples per seed. The seven shapes cover uniform depths 0, 2,047 and 2,048, monotone rises and falls, a rise followed by a fall, and mixed depths. Each seed verified 351,232 synthetic indices over 88 widths. The examined implementations still miss the per-size gate, so the scalar fallback remains on the production branch.

[Input generator, captured parent arrays, source, commands, independent oracle and all per-size samples](parent-depth-native.tar.xz)
'''
(out/'README.md').write_text(doc)
with tarfile.open(out/'parent-depth-native.tar.xz','w:xz',preset=1)as t:
 for f in p.iterdir():
  if f.is_file() and f.suffix!='.md':t.add(f,'source/'+f.name)
 for n in ('census-src','graph-src'):
  for f in sorted((p/n).rglob('*.c')):
   # The generating script records the source insertion against the pinned revision.
   if f.name=='c_parser_impl.c':continue
 for f in sorted(r.iterdir()):
  if f.is_file() and not f.name.startswith('early'):t.add(f,'native/'+f.name)
print(sources,rows)
