from pathlib import Path
p=Path(__file__).parent;n=Path('/tmp/buster-parser-names')
r=p/'census-src/buster/compiler';r.mkdir(parents=True,exist_ok=True)
def src(f):return (p/'tree/src/buster/compiler'/f).read_text()
for f in ['c_parser.c']:(r/f).write_text(src(f))
s=src('c_parser_impl.c');a=s.index('// K4 as the vector path runs it:')
s=s[:a]+'''static uint64_t parent_calls, parent_rows, deep_calls, deep_rows, largest_depth;
'''+s[a:]
a=s.index('    if (!kernels->deep_node_depths)',a)
s=s[:a]+'''    ++parent_calls;
    parent_rows += count;
    deep_calls += kernels->deep_node_depths;
    deep_rows += kernels->deep_node_depths ? count : 0;
    const uint32_t peak = count ? parse_deepest(kernels, count) : 0;
    if (peak > largest_depth) largest_depth = peak;
'''+s[a:];(r/'c_parser_impl.c').write_text(s)
s=src('c_parser_benchmark.c');a='            file->path = paths[f];';s=s.replace(a,a+'\n            parent_calls=parent_rows=deep_calls=deep_rows=largest_depth=0;',1)
s=s.replace('            pp_release(&pp);','''            if(loaded) printf("census\\t%s\\t%u\\t%lu\\t%lu\\t%lu\\t%lu\\t%lu\\n",file->path,file->parser.tokens.count,parent_calls,parent_rows,deep_calls,deep_rows,largest_depth);
            pp_release(&pp);''',1)
s=s.replace('        bench.file_count = path_count;','        return loaded ? 0 : 1;\n        bench.file_count = path_count;',1)
(p/'census.c').write_text(s+'\nint main(int argc,char**argv){return run_parser_benchmark(argc,argv);}\n')
for k in ['census-task','run-census']:
 t=(n/k).read_text().replace('buster-parser-names','buster-parser-depths').replace('/tmp/buster-2924-rebuild-6b097f86/src/src','/dev/shm/buster-native-base-cc7d4ffb-6b097f86/src').replace('codex-k6-','codex-k4-').replace('Count name-sensitive K6 lanes while normally parsing C corpora','Count full-width K4 parent recovery on production files and deeply nested source').replace('for g in lua sqlite musl','for g in dense lua sqlite musl').replace('args=(--window-bytes 64 "$root/dense.c")','args=("$root/dense.c")')
 (p/k).write_text(t)
(p/'dense.c').write_text('int f(int x) { return '+'('*2304+'x'+')'*2304+'; }\n')
