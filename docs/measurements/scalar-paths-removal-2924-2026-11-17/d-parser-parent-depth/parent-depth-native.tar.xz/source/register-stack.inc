// Keep each monotone stack's top in registers. A zero key is the permanent bottom.
static inline void parent_stack_pass(ParseKernels* k, uint32_t count, bool wide, bool finish_vectors)
{
    uint32_t ls=0, rs=0, ltop=BUSTER_PARSE_NONE, rtop=BUSTER_PARSE_NONE;
    uint64_t lk=0,rk=0;
    uint8_t* column=(uint8_t*)k->left_key_values;
    uint8_t* lhigh=column+count;
    uint8_t* rhigh=lhigh+count;
    for(uint64_t first=0;first<count;first+=16)
    {
        const unsigned n=count-first<16?(unsigned)(count-first):16;
        const __mmask16 mask=(__mmask16)_bzhi_u32(UINT16_MAX,n);
        const __m512i roles=_mm512_zextsi128_si512(_mm_maskz_loadu_epi8(mask,k->roles+first));
        const __m512i levels=parse_lookup8(parse_parent_tables.levels,roles);
        const __m512i left=parse_lookup8(parse_parent_tables.left_thresholds,roles);
        const __m512i right=parse_lookup8(parse_parent_tables.right_thresholds,roles);
        const __m512i rules=parse_lookup8(parse_parent_tables.rules,roles);
        uint8_t le[16],lt[16],rt[16],ru[16];
        _mm_storeu_si128((__m128i*)le,_mm512_castsi512_si128(levels));
        _mm_storeu_si128((__m128i*)lt,_mm512_castsi512_si128(left));
        _mm_storeu_si128((__m128i*)rt,_mm512_castsi512_si128(right));
        _mm_storeu_si128((__m128i*)ru,_mm512_castsi512_si128(rules));
        for(uint32_t j=0;j<n;j++)
        {
            const uint32_t i=(uint32_t)first+j;
            const uint64_t base=((uint64_t)k->node_depths[i]<<5)+1, key=base+le[j];
            while(rk>key)
            {
                k->parents[rtop]=i;
                --rs;rtop=k->waiting[rs];rk=k->waiting_thresholds[rs];
                if(wide)rk|=(uint64_t)rhigh[rs]<<32;
            }
            const uint64_t threshold=base+lt[j];
            while(lk>=threshold)
            {
                --ls;ltop=k->stack[ls];lk=k->stack_keys[ls];
                if(wide)lk|=(uint64_t)lhigh[ls]<<32;
            }
            k->lefts[i]=ltop;
            // The largest left threshold is one above the current key. The stack is strictly increasing.
            if(lk>=key)
            {
                --ls;ltop=k->stack[ls];lk=k->stack_keys[ls];
                if(wide)lk|=(uint64_t)lhigh[ls]<<32;
            }
            k->stack[ls]=ltop;k->stack_keys[ls]=(uint32_t)lk;if(wide)lhigh[ls]=(uint8_t)(lk>>32);
            ++ls;ltop=i;lk=key;
            if(ru[j]!=PARSE_RULE_LEFT)
            {
                k->waiting[rs]=rtop;k->waiting_thresholds[rs]=(uint32_t)rk;if(wide)rhigh[rs]=(uint8_t)(rk>>32);
                ++rs;rtop=i;rk=base+rt[j];
            }
            else k->parents[i]=ltop;
            column[i]=le[j];
        }
    }
    while(rs){k->parents[rtop]=BUSTER_PARSE_NONE;rtop=k->waiting[--rs];}
    if(!finish_vectors)
    {
        for(uint32_t i=0;i<count;i++)
        {
            const uint8_t rule=parse_role_rules[k->roles[i]];
            const uint32_t l=k->lefts[i],r=k->parents[i];
            if(rule==PARSE_RULE_LEFT) k->parents[i]=l;
            else if(rule==PARSE_RULE_SELECT)k->parents[i]=parse_select(l,l!=BUSTER_PARSE_NONE?k->node_depths[l]:0,l!=BUSTER_PARSE_NONE?column[l]:0,
                                                                        r,r!=BUSTER_PARSE_NONE?k->node_depths[r]:0,r!=BUSTER_PARSE_NONE?column[r]:0);
        }
        return;
    }
    for(uint64_t first=0;first<count;first+=16)
    {
        const unsigned n=count-first<16?(unsigned)(count-first):16;const __mmask16 live=(__mmask16)_bzhi_u32(UINT16_MAX,n);
        _mm512_mask_storeu_epi32(k->stack_keys+first,live,_mm512_cvtepu8_epi32(_mm_maskz_loadu_epi8(live,column+first)));
    }
    const void* depth_base=(const void*)((uintptr_t)k->node_depths+(UINT64_C(1)<<33));
    const void* level_base=(const void*)((uintptr_t)k->stack_keys+(UINT64_C(1)<<33));
    for(uint64_t first=0;first<count;first+=16)
    {
        const unsigned n=count-first<16?(unsigned)(count-first):16;const __mmask16 live=(__mmask16)_bzhi_u32(UINT16_MAX,n);
        const __m512i roles=_mm512_zextsi128_si512(_mm_maskz_loadu_epi8(live,k->roles+first));
        const __m512i rules=parse_lookup8(parse_parent_tables.rules,roles);
        const __m512i l=_mm512_maskz_loadu_epi32(live,k->lefts+first),r=_mm512_maskz_loadu_epi32(live,k->parents+first);
        const __mmask16 lv=live&_mm512_cmpneq_epi32_mask(l,_mm512_set1_epi32(-1)),rv=live&_mm512_cmpneq_epi32_mask(r,_mm512_set1_epi32(-1));
        const __m512i li=_mm512_xor_si512(l,_mm512_set1_epi32(INT32_MIN)),ri=_mm512_xor_si512(r,_mm512_set1_epi32(INT32_MIN));
        const __m512i ld=_mm512_mask_i32gather_epi32(_mm512_setzero_si512(),lv,li,depth_base,4),rd=_mm512_mask_i32gather_epi32(_mm512_setzero_si512(),rv,ri,depth_base,4);
        const __m512i ll=_mm512_mask_i32gather_epi32(_mm512_setzero_si512(),lv,li,level_base,4),rl=_mm512_mask_i32gather_epi32(_mm512_setzero_si512(),rv,ri,level_base,4);
        const __mmask16 weak=_mm512_cmpeq_epi32_mask(ll,_mm512_set1_epi32(PARSE_LEVEL_OPENER))|_mm512_cmpeq_epi32_mask(ll,_mm512_set1_epi32(PARSE_LEVEL_TERMINATOR))|_mm512_cmpeq_epi32_mask(ll,_mm512_set1_epi32(PARSE_LEVEL_HEAD));
        const __m512i tieinfo=_mm512_permutexvar_epi16(_mm512_castsi256_si512(_mm512_cvtepi32_epi16(ll)),_mm512_loadu_si512(parse_parent_tables.weak_ties));
        const __mmask16 left_ties=(__mmask16)_mm512_test_epi16_mask(tieinfo,_mm512_set1_epi16(2));
        const __mmask16 compare=_mm512_cmpgt_epu32_mask(ld,rd)|(_mm512_cmpeq_epi32_mask(ld,rd)&(_mm512_cmpgt_epu32_mask(ll,rl)|(_mm512_cmpeq_epi32_mask(ll,rl)&left_ties)));
        const __mmask16 select=(__mmask16)_mm512_cmpeq_epi8_mask(rules,_mm512_set1_epi8(PARSE_RULE_SELECT));
        const __mmask16 left=(__mmask16)_mm512_cmpeq_epi8_mask(rules,_mm512_set1_epi8(PARSE_RULE_LEFT))|(select&lv&(~rv|(~weak&compare)));
        _mm512_mask_storeu_epi32(k->parents+first,live,_mm512_mask_blend_epi32(left,r,l));
    }
}
static void parent_fast_stack(ParseKernels*k,uint32_t n)
{
    bool wide=n&&parse_deepest(k,n)>=(UINT32_MAX-33ull)/32;
    if(wide)parent_stack_pass(k,n,true,FINISH);
    else parent_stack_pass(k,n,false,FINISH);
}
