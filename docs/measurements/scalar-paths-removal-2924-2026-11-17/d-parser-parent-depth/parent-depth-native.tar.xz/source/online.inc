static inline void parent_online_pass(ParseKernels* k, uint32_t count, bool wide)
{
    uint32_t ls=0,rs=0,ltop=BUSTER_PARSE_NONE,rtop=BUSTER_PARSE_NONE;
    uint64_t lk=0,rk=0,cut=0;
    uint8_t* lh=(uint8_t*)k->lefts;
    uint8_t* rh=lh+count;
    uint8_t* ch=rh+count;
    for(uint64_t first=0;first<count;first+=16)
    {
        const unsigned n=count-first<16?(unsigned)(count-first):16;
        const __mmask16 mask=(__mmask16)_bzhi_u32(UINT16_MAX,n);
        uint32_t info[16];
        if(GATHER)
        {
            const __m512i roles=_mm512_cvtepu8_epi32(_mm_maskz_loadu_epi8(mask,k->roles+first));
            _mm512_storeu_si512(info,_mm512_i32gather_epi32(roles,parse_role_info,4));
        }
        for(unsigned j=0;j<n;j++)
        {
            const uint32_t i=(uint32_t)first+j;
            const uint32_t meta=GATHER?info[j]:parse_role_info[k->roles[i]];
            const uint8_t rule=meta>>24;
            const uint64_t base=((uint64_t)k->node_depths[i]<<5)+1;
            const uint64_t key=base+(uint8_t)meta;
            while(rk>key)
            {
                if(key>=cut) k->parents[rtop]=i;
                --rs;
                rtop=k->waiting[rs];rk=k->waiting_thresholds[rs];cut=k->left_key_values[rs];
                if(wide){rk|=(uint64_t)rh[rs]<<32;cut|=(uint64_t)ch[rs]<<32;}
            }
            const uint64_t threshold=base+(uint8_t)(meta>>8);
            while(lk>=threshold)
            {
                --ls;ltop=k->stack[ls];lk=k->stack_keys[ls];if(wide)lk|=(uint64_t)lh[ls]<<32;
            }
            const uint32_t left=ltop;
            const uint64_t left_key=lk;
            if(lk>=key)
            {
                --ls;ltop=k->stack[ls];lk=k->stack_keys[ls];if(wide)lk|=(uint64_t)lh[ls]<<32;
            }
            k->stack[ls]=ltop;k->stack_keys[ls]=(uint32_t)lk;if(wide)lh[ls]=(uint8_t)(lk>>32);
            ++ls;ltop=i;lk=key;
            k->parents[i]=rule==PARSE_RULE_SELECT||rule==PARSE_RULE_LEFT?left:BUSTER_PARSE_NONE;
            if(rule!=PARSE_RULE_LEFT)
            {
                k->waiting[rs]=rtop;k->waiting_thresholds[rs]=(uint32_t)rk;k->left_key_values[rs]=(uint32_t)cut;
                if(wide){rh[rs]=(uint8_t)(rk>>32);ch[rs]=(uint8_t)(cut>>32);}
                ++rs;rtop=i;rk=base+(uint8_t)(meta>>16);
                const uint8_t lev=(uint8_t)((left_key-1)&31);
                const uint16_t flags=parse_parent_tables.weak_ties[lev];
                cut=rule==PARSE_RULE_SELECT && left_key && !(flags&1)?left_key+(flags>>1):0;
            }
        }
    }
}
static void parent_online(ParseKernels* k,uint32_t count)
{
    if(ALWAYS_WIDE)parent_online_pass(k,count,true);
    else if(count && parse_deepest(k,count)>=(UINT32_MAX-64ull)/32)parent_online_pass(k,count,true);
    else parent_online_pass(k,count,false);
}
