from pathlib import Path
import shutil
p=Path(__file__).parent
s=(p/'census-src/buster/compiler/c_parser_impl.c').read_text();a=s.index('static void parse_parents_vector(');b=s.index('\n}',a)
s=s[:b]+'''
    static _Thread_local FILE* saved;
    if (!saved && getenv("BUSTER_K4_CAPTURE")) saved=fopen(getenv("BUSTER_K4_CAPTURE"),"ab");
    if (saved) {
        fwrite(&count,sizeof(count),1,saved);
        fwrite(kernels->roles,1,count,saved);
        fwrite(kernels->node_depths,sizeof(uint32_t),count,saved);
        fwrite(kernels->parents,sizeof(uint32_t),count,saved);
    }'''+s[b:]
d=p/'graph-src/buster/compiler';d.mkdir(exist_ok=True,parents=True);(d/'c_parser_impl.c').write_text(s);shutil.copy(p/'census-src/buster/compiler/c_parser.c',d)
s=(p/'census-task').read_text().replace('-I census-src','-I graph-src').replace('-o census >census-build','-o graph-census >graph-build').replace('bash run-census "$g"','BUSTER_K4_CAPTURE="$PWD/graphs-$g.bin" bash graph-source "$g"').replace('"$g-census.log"','"graph-$g.log"').replace('touch census.ok','touch graphs.ok');(p/'capture').write_text(s)
(p/'graph-source').write_text((p/'run-census').read_text().replace('./census ','./graph-census '))
