#include "buster/compiler/test_paths.h"
#include "buster/compiler/c_parser_benchmark.c"
#define GATHER 1
#define ALWAYS_WIDE 1
#include "online.inc"
#include <immintrin.h>
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];
typedef void Parent(ParseKernels*,uint32_t);
static Parent* volatile methods[]={parse_parents_scalar,parent_online};
static uint32_t state=1;
static uint32_t random32(void){state=state*1664525u+1013904223u;return state;}
static uint64_t tick(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int cmp64(const void*a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return(x>y)-(x<y);}
static ParseKernels allocate(uint32_t n)
{
    ParseKernels k={0};uint64_t m=(uint64_t)n+64;
    k.roles=calloc(m,1);k.node_depths=calloc(m,4);k.parents=calloc(m,4);k.lefts=calloc(m,4);k.left_key_values=calloc(m,4);k.waiting=calloc(m,4);k.waiting_thresholds=calloc(m,4);k.stack=calloc(m,4);k.stack_keys=calloc(m,4);
    if(!k.roles||!k.node_depths||!k.parents||!k.lefts||!k.left_key_values||!k.waiting||!k.waiting_thresholds||!k.stack||!k.stack_keys)exit(20);
    return k;
}
static void release(ParseKernels k){free(k.roles);free(k.node_depths);free(k.parents);free(k.lefts);free(k.left_key_values);free(k.waiting);free(k.waiting_thresholds);free(k.stack);free(k.stack_keys);}
static int compare(const uint32_t*a,const uint32_t*b,uint32_t n,int shape)
{
    for(uint32_t i=0;i<n;i++)if(a[i]!=b[i]){fprintf(stderr,"n=%u shape=%d i=%u got=%u expected=%u\n",n,shape,i,a[i],b[i]);return 1;}return 0;
}
static int corpus(const char*file)
{
    FILE* f=fopen(file,"rb");if(!f)return 2;uint32_t n;uint64_t calls=0,rows=0,bad=0;
    while(fread(&n,4,1,f)==1)
    {
        ParseKernels k=allocate(n);uint32_t* expected=malloc(4*((uint64_t)n+1));
        if(fread(k.roles,1,n,f)!=n||fread(k.node_depths,4,n,f)!=n||fread(expected,4,n,f)!=n)return 3;
        for(unsigned m=0;m<2;m++){methods[m](&k,n);if(compare(k.parents,expected,n,m))return 4;}
        rows+=n;calls++;free(expected);release(k);
    }
    if(ferror(f))return 5;
    fprintf(stderr,"%lu captured parser calls and %lu parent indices matched for both methods\n",calls,rows);
    return 0;
}
static uint32_t independent(const ParseKernels*k,uint32_t i,uint32_t n)
{
    uint8_t role=k->roles[i];uint64_t base=(uint64_t)k->node_depths[i]*32;uint32_t l=UINT32_MAX,r=UINT32_MAX;
    for(uint32_t j=i;j>0;){--j;if((uint64_t)k->node_depths[j]*32+parse_role_levels[k->roles[j]]<base+parse_role_left_thresholds[role]){l=j;break;}}
    for(uint32_t j=i+1;j<n;j++)if((uint64_t)k->node_depths[j]*32+parse_role_levels[k->roles[j]]<base+parse_role_right_thresholds[role]){r=j;break;}
    switch(parse_role_rules[role]){
    case PARSE_RULE_LEFT:return l;
    case PARSE_RULE_OPENER:case PARSE_RULE_RIGHT:return r;
    default:
        if(l==UINT32_MAX)return r;
        if(r==UINT32_MAX)return l;
        uint8_t level=parse_role_levels[k->roles[l]];
        if(parse_level_is_weak(level))return r;
        uint64_t a=(uint64_t)k->node_depths[l]*32+level,b=(uint64_t)k->node_depths[r]*32+parse_role_levels[k->roles[r]];
        return (a>b||(a==b&&parse_level_ties_left[level]))?l:r;
    }
}
int main(int argc,char**argv)
{
    parse_parent_tables_init();parse_role_info_initialize();
    if(argc==3&&!strcmp(argv[1],"corpus"))return corpus(argv[2]);
    state=argc>1?strtoul(argv[1],0,0):1;
    uint32_t widths[100],nw=0;
    for(uint32_t n=0;n<=65;n++)widths[nw++]=n;
    uint32_t more[]={95,96,97,127,128,129,255,256,257,511,512,513,1023,1024,2047,2048,2049,4095,4096,4097,8192,16384};
    for(unsigned i=0;i<sizeof(more)/sizeof(*more);i++)widths[nw++]=more[i];
    ParseKernels k=allocate(16384);uint32_t* ref=malloc(16384*4);uint64_t verified=0;
    for(unsigned z=0;z<nw;z++)for(unsigned sh=0;sh<7;sh++)
    {
        uint32_t n=widths[z];
        for(uint32_t i=0;i<n;i++){
            uint32_t depth=sh==0?0:sh==1?2047:sh==2?2048:sh==3?i:sh==4?n-i:sh==5?(i<=n/2?i:n-i):random32()%4000;
            k.node_depths[i]=depth;k.roles[i]=(uint8_t)(random32()%PARSE_ROLE_COUNT);
        }
        if(n<=129){for(uint32_t i=0;i<n;i++)ref[i]=independent(&k,i,n);}
        methods[1](&k,n);
        if(n<=129&&compare(k.parents,ref,n,sh))return 6;
        if(n>129)memcpy(ref,k.parents,4*n);
        methods[0](&k,n);
        if(compare(k.parents,ref,n,sh))return 7;
        if(n&&n<=129){
            for(uint32_t i=0;i<n;i++)k.node_depths[i]+=UINT32_MAX-20000;
            for(uint32_t i=0;i<n;i++)ref[i]=independent(&k,i,n);
            methods[1](&k,n);if(compare(k.parents,ref,n,sh))return 8;
            for(uint32_t i=0;i<n;i++)k.node_depths[i]-=UINT32_MAX-20000;
        }
        unsigned reps=512/(n+1)+1;uint64_t samples[2][7];
        for(unsigned j=0;j<7;j++)for(unsigned m=0;m<2;m++){uint32_t side=(m+(j&1))%2;uint64_t start=tick();for(unsigned q=0;q<reps;q++)methods[side](&k,n);samples[side][j]=tick()-start;}
        for(unsigned m=0;m<2;m++)qsort(samples[m],7,sizeof(uint64_t),cmp64);
        printf("%u %u %u %lu %lu\n",n,sh,reps,samples[0][3],samples[1][3]);verified+=n;
    }
    fprintf(stderr,"%lu synthetic parent indices matched at %u sizes, including full unsigned depth keys\n",verified,nw);free(ref);release(k);return 0;
}
