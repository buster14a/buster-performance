typedef uint64_t Writer(const void*,uint8_t*,uint32_t*,uint32_t*);
unsigned capture_input(const uint8_t*,uint64_t,uint8_t*,uint32_t*,uint32_t*);
const void* saved(unsigned);
int has_literals(unsigned);
