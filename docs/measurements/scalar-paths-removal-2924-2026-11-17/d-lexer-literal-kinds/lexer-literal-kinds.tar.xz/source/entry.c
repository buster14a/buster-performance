#define _GNU_SOURCE
#include "buster/compiler/c_lexer.c"
__attribute__((noinline)) int64_t ENTRY(const uint8_t* p,uint64_t n,uint8_t* k,uint32_t* a,uint32_t* b,uint32_t flags)
{
#ifdef SCALAR
    return c_tokenize_scalar(p,n,k,a,b,flags);
#else
    return c_tokenize(p,n,k,a,b,flags);
#endif
}
