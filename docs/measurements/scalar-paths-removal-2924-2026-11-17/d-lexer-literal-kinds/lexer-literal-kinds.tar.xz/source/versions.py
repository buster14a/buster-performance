from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent;name='src/buster/compiler/c_lexer.c';orig=(p/'tree'/name).read_text()
for var in ('base','masks','lookup','quote'):
 s=orig
 if var!='base':
  a=s.index('// The kind of the prefixed literal');b=s.index('// The literals and comments of a chunk',a);s=s[:a]+s[b:]
  a=s.index('        // Prefixed and unknown literals (rare).');b=s.index('        // The starts and ends:',a);s=s[:a]+s[b:]
  a=s.index('            kinds = _mm512_mask_mov_epi8(kinds, t->dot_numbers[j]');b=s.index('\n',a)
  t='''
            // The chunk has a full lookahead vector, including at the source boundary. All prefix
            // lanes can read their second and third characters before the token kinds are compressed.
            if (t->prefixes[j] != 0)
            {
                const __mmask64 utf8 = _mm512_cmpeq_epi8_mask(next_characters, splat8('8'));
                const __m512i third = _mm512_loadu_si512((const uint8_t*)&raw[j] + 2);
'''
  if var=='masks':
   t+='''                __m512i literal = splat8(C_TOKEN_UTF16_CHAR_CONSTANT);
                literal = _mm512_mask_set1_epi8(literal, _mm512_cmpeq_epi8_mask(raw[j], splat8('L')), C_TOKEN_WIDE_CHAR_CONSTANT);
                literal = _mm512_mask_set1_epi8(literal, _mm512_cmpeq_epi8_mask(raw[j], splat8('U')), C_TOKEN_UTF32_CHAR_CONSTANT);
'''
  else:
   t+='''                // The low six ASCII bits distinguish L, u and U.
                BUSTER_LEX_ALIGN(64) static const uint8_t character[64] = {
                    ['L' & 63] = C_TOKEN_WIDE_CHAR_CONSTANT, ['u' & 63] = C_TOKEN_UTF16_CHAR_CONSTANT, ['U' & 63] = C_TOKEN_UTF32_CHAR_CONSTANT,
                };
                __m512i literal = _mm512_permutexvar_epi8(raw[j], _mm512_load_si512(character));
'''
  t+='''                literal = _mm512_mask_set1_epi8(literal, utf8, C_TOKEN_UTF8_CHAR_CONSTANT);
'''
  if var=='quote':
   t+='''                const __mmask64 strings = _mm512_cmpeq_epi8_mask(next_characters, splat8('"')) | _mm512_mask_cmpeq_epi8_mask(utf8, third, splat8('"'));
'''
  else:
   t+='''                const __m512i quote = _mm512_mask_blend_epi8(utf8, next_characters, third);
                const __mmask64 strings = _mm512_cmpeq_epi8_mask(quote, splat8('"'));
'''
  t+='''                literal = _mm512_mask_add_epi8(literal, strings, literal, splat8(C_TOKEN_STRING_LITERAL - C_TOKEN_CHAR_CONSTANT));
                kinds = _mm512_mask_mov_epi8(kinds, t->prefixes[j], literal);
            }
            kinds = _mm512_mask_set1_epi8(kinds, t->unknowns[j], C_TOKEN_UNKNOWN);'''
  s=s[:b]+t+s[b:]
  s=s.replace('write_chunk(const ChunkTokens* t, const uint8_t* source, uint64_t begin, uint64_t length, OutputCursors cursors)','write_chunk(const ChunkTokens* t, OutputCursors cursors)').replace('write_chunk_outlined(const ChunkTokens* t, const uint8_t* source, uint64_t begin, uint64_t length, OutputCursors cursors)','write_chunk_outlined(const ChunkTokens* t, OutputCursors cursors)').replace('write_chunk(t, source, begin, length, cursors)','write_chunk(t, cursors)').replace('(&deferred, source, begin, length, (OutputCursors)','(&deferred, (OutputCursors)')
  s=s.replace('// Measurements: docs/c-lexer.md.', '// Local changes (2026-11-28): classify prefixed and unknown literal kinds from the source vectors before compression.\n// Measurements: docs/c-lexer.md.')
 f=p/var/name.removeprefix('src/');f.parent.mkdir(exist_ok=True,parents=True);f.write_text(s)
 if var!='base':(p/f'{var}.patch').write_text(''.join(unified_diff(orig.splitlines(True),s.splitlines(True),'a/'+name,'b/'+name)))
