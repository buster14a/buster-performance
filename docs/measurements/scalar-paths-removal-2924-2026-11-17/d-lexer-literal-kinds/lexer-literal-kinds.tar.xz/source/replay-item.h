typedef struct {
    ChunkTokens tokens;
    __m512i raw[BUSTER_LEX_VECTOR_COUNT + 1];
    const uint8_t* source;
    uint64_t begin,length;
    int literals;
} Snapshot;
