#define _GNU_SOURCE
#include "buster/compiler/c_lexer.c"
#include <sys/mman.h>
#include <unistd.h>
#include <stdio.h>

int main(void)
{
    const struct { const char* spelling; uint8_t kind; } tokens[] = {
        {"L'x'", C_TOKEN_WIDE_CHAR_CONSTANT}, {"u8'x'", C_TOKEN_UTF8_CHAR_CONSTANT},
        {"u'x'", C_TOKEN_UTF16_CHAR_CONSTANT}, {"U'x'", C_TOKEN_UTF32_CHAR_CONSTANT},
        {"L\"x\"", C_TOKEN_WIDE_STRING_LITERAL}, {"u8\"x\"", C_TOKEN_UTF8_STRING_LITERAL},
        {"u\"x\"", C_TOKEN_UTF16_STRING_LITERAL}, {"U\"x\"", C_TOKEN_UTF32_STRING_LITERAL},
        {"L\"open", C_TOKEN_UNKNOWN}, {"u8'unclosed", C_TOKEN_UNKNOWN},
    };
    const size_t page = (size_t)sysconf(_SC_PAGESIZE);
    uint8_t* map = mmap(NULL, page * 3, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (map == MAP_FAILED || mprotect(map + page, page, PROT_READ | PROT_WRITE)) return 2;
    uint8_t kinds[2048]; uint32_t starts[2048], ends[2048];
    unsigned checked = 0, failed = 0;
    for (unsigned j = 0; j < sizeof(tokens) / sizeof(tokens[0]); ++j)
    for (unsigned lane = 0; lane < 64; ++lane)
    for (unsigned chunk = 0; chunk < 2; ++chunk)
    for (unsigned sol = 0; sol < 2; ++sol)
    {
        const unsigned begin = 64 + lane + 448 * chunk;
        const size_t n = begin + strlen(tokens[j].spelling);
        uint8_t* source = map + 2 * page - n;
        memset(source, ' ', begin);
        source[0] = 'x';
        if (sol) source[1] = '\n';
        memcpy(source + begin, tokens[j].spelling, n - begin);
        const int64_t count = c_tokenize(source, n, kinds, starts, ends, 0);
        const uint8_t expected = tokens[j].kind | (sol ? BUSTER_C_TOKEN_START_OF_LINE : 0);
        const bool ok = count == 2 && kinds[1] == expected && starts[1] == begin && ends[1] == n;
        if (!ok && failed++ < 3) fprintf(stderr, "spelling=%s begin=%u SOL=%u end=%lu got=%ld,%u,%u,%u expected=%u\n",
            tokens[j].spelling, begin, sol, (unsigned long)n, (long)count, kinds[1], starts[1], ends[1], expected);
        checked++;
    }
    fprintf(stderr, "%u named token kinds, bounds and line flags checked, %u failures\n", checked, failed);
    return failed != 0;
}
