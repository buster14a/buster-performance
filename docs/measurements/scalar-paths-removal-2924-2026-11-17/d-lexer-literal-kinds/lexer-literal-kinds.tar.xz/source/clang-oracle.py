import re,subprocess,sys
from pathlib import Path
spellings=[(prefix+quote+'x'+quote,kind+'_'+suffix)for prefix,kind in [('L','wide'),('u8','utf8'),('u','utf16'),('U','utf32')]for quote,suffix in [("'","char_constant"),('"',"string_literal")]]
spellings.extend([('L"open','unknown'),("u8'unclosed",'unknown')])
lines=[];expected={}
for spelling,kind in spellings:
 for lane in range(64):
  for chunk in range(2):
   for sol in range(2):
    before=' '*(64+lane+448*chunk)
    if not sol:before='x'+before[1:]
    lines.append(before+spelling)
    expected[len(lines)]=(len(before)+1,kind,spelling)
path=Path('clang-literal-extents.c');path.write_text('\n'.join(lines)+'\n')
r=subprocess.run([sys.argv[1],'-cc1','-std=gnu23','-dump-raw-tokens',str(path)],capture_output=True,text=True,check=True)
checked=0
for kind,spelling,row,col in re.findall(r"^(\w+)[ \t]+'([^\n]*)'[^\n]*Loc=<[^\n]*?:(\d+):(\d+)>",r.stderr,re.M):
 row=int(row);col=int(col)
 if row in expected and expected[row][0]==col:
  spelling=spelling.replace(chr(92)+'"', '"')
  assert (kind,spelling)==expected[row][1:],(row,kind,spelling,expected[row])
  checked+=1
assert checked==len(lines),(checked,len(lines))
print(checked,'Clang raw token kinds, spellings and byte columns agree')
