from pathlib import Path
p=Path(__file__).parent
f=Path('buster/compiler/c_lexer.c');s=(p/'base'/f).read_text();a=s.index('BUSTER_INLINE OutputCursors write_chunk(')
s=s[:a]+'''static void record_shape(const ChunkTokens* t, const uint8_t* source, uint64_t begin, uint64_t length);
'''+s[a:];a=s.index('    uint8_t* cur_kind = cursors.kind;',a);s=s[:a]+'''    record_shape(t, source, begin, length);
'''+s[a:]
dst=p/'captured'/f;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(s)
s=(p/'compare.c').read_text();a=s.index('typedef int64_t Lex');b=s.index('static uint32_t state=',a)
s=s[:a]+'''#include "replay-api.h"
extern Writer write_base,write_masks,write_lookup,write_quote;
static Writer* volatile methods[]={write_base,write_masks,write_lookup,write_quote};
'''+s[b:]
a=s.index('    unsigned checks=0;')
s=s[:a]+'''    unsigned checks=0;
    for(unsigned z=0;z<nw;z++)for(unsigned shape=0;shape<10;shape++){
        unsigned n=widths[z],off=shape==6?(n?random_word()%n:0):0;
        uint8_t*p=guard+page+max-n;generate(p,n,shape,off);
        unsigned chunks=capture_input(p,n,k[4],a[4],b[4]);
        for(unsigned mode=0;mode<2;mode++){
            unsigned selected[1024],count=0;
            for(unsigned c=0;c<chunks;c++)if(!mode||has_literals(c))selected[count++]=c;
            if(count==0)continue;
            for(unsigned c=0;c<count;c++){
                unsigned index=selected[c];uint64_t ref=methods[0](saved(index),k[0],a[0],b[0]);
                for(unsigned j=1;j<4;j++){
                    uint64_t got=methods[j](saved(index),k[j],a[j],b[j]);
                    if(got!=ref||memcmp(k[j],k[0],(uint32_t)ref)||memcmp(a[j],a[0],4*(uint32_t)ref)||memcmp(b[j],b[0],4*(ref>>32))){
                        fprintf(stderr,"replay mismatch n=%u shape=%u chunk=%u method=%u\\n",n,shape,c,j);return 4;
                    }
                    checks++;
                }
            }
            uint64_t times[4][9];unsigned repeats=512/count+3;
            for(unsigned round=0;round<9;round++){
                unsigned rotate=random_word()%4;
                for(unsigned i=0;i<4;i++){
                    unsigned j=(rotate+(round%2?3*i:i))%4;Writer*fn=methods[j];uint64_t lo=tick();
                    for(unsigned rep=0;rep<repeats;rep++)for(unsigned c=0;c<count;c++)fn(saved(selected[c]),k[j],a[j],b[j]);
                    times[j][round]=tick()-lo;
                }
            }
            printf("%u %u %u %u %u",n,shape,mode,count,repeats);
            for(unsigned j=0;j<4;j++){qsort(times[j],9,sizeof(uint64_t),cmp);printf(" %lu",times[j][4]);}puts("");
        }
    }
    fprintf(stderr,"%u captured output checks passed\\n",checks);
}
'''
(p/'replay.c').write_text(s)
