from pathlib import Path
from statistics import median
import re,struct,tarfile
p=Path(__file__).parent;r=p/'results'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-lexer-literal-kinds');out.mkdir(exist_ok=True)
seeds=(1,133,789)
def matrix(prefix,cols):
 rows=[]
 for seed in seeds:
  lines=(r/f'{prefix}-{seed}.tsv').read_text().splitlines()
  d={};assert ('guarded token stream comparisons passed' if prefix=='gate' else 'captured output checks passed') in (r/f'{prefix}-{seed}.log').read_text()
  for line in lines:
   t=list(map(int,line.split()));k=tuple(t[:cols]);assert k not in d;d[k]=t
  rows.append(d)
 return rows
def paired(t,k,c,b):return median(x[k][c]/x[k][b] for x in t if k in x)
def win(ratios):
 return f'{sum(x<=1 for x in ratios)}/{len(ratios)}, {median(ratios):.3f}×' if ratios else '—'
gate=matrix('gate',2);replay=matrix('replay',3)
keys=set.intersection(*(set(x)for x in replay));union=set.union(*(set(x)for x in replay))
assert all(len(x)==900 for x in gate)
census=[]
for g in ('lua','sqlite','musl','dense'):
 xs=[struct.unpack('<16Q',(r/f'counts-{mode}-{g}.bin').read_bytes())for mode in ('default','window')]
 assert all(sum(x[5:13])==x[3]for x in xs)
 if g=='dense':assert all(x[5:13]==(65,)*8 for x in xs)
 census.append('| '+g+' | '+' | '.join(str(z) for x in xs for z in (x[0],x[3],x[4]))+' |')
for mode in ('c','cpp','raw','raw99'):
 for seed in seeds:
  s=(r/f'lookup-lexer-{mode}-{seed}.log').read_text();assert 'kept comments: 0 of 80020 inputs fail' in s and '88844 checks, 0 failures' in s and 'raw diagnostic boundaries: pass' in s
s=(r/'lookup-preprocessor.log').read_text();assert 'preprocessor determinism: 419 fixtures' in s and len(re.findall(r'64 compared with clang .*0 differ',s))==2
for n in ('base','lookup'):assert '2560 named token kinds, bounds and line flags checked, 0 failures' in (r/f'oracle-{n}.log').read_text()
for n in ('bad-utf8','bad-string'):assert re.search(r'[1-9][0-9]* failures',(r/f'oracle-{n}.log').read_text())
assert '2560 Clang raw token kinds, spellings and byte columns agree' in (r/'oracle-clang.log').read_text()
samples=[]
shapes=['Spaces','Ordinary C tokens','Wide strings','Eight literal kinds','Sparse prefixes','Unterminated literals','Shifted prefixes','Similar identifiers and dot-numbers','Comment delimiters','Mixed lines']
for i,shape in enumerate(shapes):
 fields=[win([paired(gate,k,6,4)for k in gate[0] if k[1]==i])]
 for mode in (0,1):fields.append(win([paired(replay,k,7,5)for k in keys if k[1:]==(i,mode)]))
 samples.append('| '+shape+' | '+' | '.join(fields)+' |')
summary=[]
for name,col in [('Mask comparisons',6),('Byte lookup',7),('Quote offset',8)]:
 cols=[]
 for mode in (0,1):
  cols.append(win([paired(replay,k,col,5)for k in keys if k[2]==mode]))
 summary.append('| '+name+' | '+' | '.join(cols)+' |')
def complete(g):
 d=r/f'lookup-{g}'
 if not all((d/f'tables-{side}-3.log').is_file()for side in ('base','head')):return None
 cols=[]
 for mode in ('default','whole','window'):
  for ext in ('err','sha'):assert (d/f'{mode}-base.{ext}').read_bytes()==(d/f'{mode}-head.{ext}').read_bytes()
  s=(d/f'{mode}.log').read_text();assert s.rstrip().endswith('ab: done, 0 failed runs')
  ratios=[]
  for part in s.split('time-runs: done, 0 failed processes')[:-1]:
   w={k:int(n)for k,n in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',part,re.M)};ratios.append(w['head']/w['base'])
  assert len(ratios)==5
  cols.append(f'{100*(median(ratios)-1):+.3f}%')
 ratios=[]
 for i in (1,2,3):
  vals=[]
  for tag in ('base','head'):
   s=(d/f'tables-{tag}-{i}.log').read_text()
   assert 'corpus: 0 files differ' in s
   m=re.search(r'^  c_tokenize\s+\S+ ms\s+\S+ GB/s\s+(\S+) cycles/B',s,re.M);assert m;vals.append(float(m[1]))
  ratios.append(vals[1]/vals[0])
 cols.append(f'{100*(median(ratios)-1):+.3f}%')
 return '| '+g+' | '+' | '.join(cols)+' |'
whole=[v for g in ('lua','sqlite','musl') if (v:=complete(g))]
data='''# Lexer output for prefixed literals and unknown tokens

This record covers the rare scalar writes after token-kind compression in the normal lexer at cc7d4ffb4. The byte lookup classifies the L, u and U lanes together, overrides u8 from the second byte, uses the quote to select string versus character, and applies unknown and start-of-line masks before compression. The nine-vector deferred source snapshot provides the two lookahead bytes at the end of a chunk.

## Reach in the preprocessor

The unmodified dispatch was instrumented first. Windowing can split a literal and change the number of unknown lanes presented to a single write. The dense input contains 65 of each of the eight named literal kinds.

| Corpus | Default chunks | Prefixes | Unknown | 4 KiB chunks | Prefixes | Unknown |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(census)+'''

## Source boundaries and token output

Three seeded comparisons each checked 3,600 complete token streams over 90 source lengths and ten input shapes. The unmodified scalar tokenizer supplies the expected token kinds, starts and ends. The source ends at an inaccessible page. A separate 2,560-case test checks the eight named literal classes and two malformed spellings, on every byte lane at two vector boundaries and with both start-of-line states. The expected kinds, spellings and columns were verified by Clang's raw token dump. Changing the UTF-8 kind or suppressing string kinds makes this test fail.

The replay captures real chunk classifications and reuses the identical source vectors and token masks in all implementations. Its checks compare the kind bytes and both independently sized start and end streams. Measurements ran on CPU 2 of the locked Ryzen 7 9700X. Each cell uses the median of nine alternating measurements per seed, followed by the median of the three candidate/parent ratios. Each entry gives the number of cells at least as fast as the parent and the median ratio. Only cells reached on all three seeds enter this table. The archive includes every seed's reached cells.

| Implementation | All nonempty captured inputs | Inputs with a captured prefix or unknown lane |
| --- | ---: | ---: |
'''+'\n'.join(summary)+'''

| Source shape | Complete tokenizer | All captured chunks | Affected chunks only |
| --- | ---: | ---: | ---: |
'''+'\n'.join(samples)+'''

The Release compiler passed the C, C++, raw-string and C99 raw-string lexer suites with 200,000 fuzz inputs on each of three seeds in each mode. The preprocessing oracle passed all 419 fixtures, 128 Clang fuzz comparisons and the 1/2/3/8-lane determinism suite.

## Production preprocessing and lexing

Five paired rounds of three processes per executable measured complete preprocessing in default, whole-file and 4 KiB modes. The outputs and diagnostics matched for every row shown. The final column separately compares three pairs of 21-pass complete tokenizer benchmarks on Lua's sources, the SQLite amalgamation or musl's public headers.

| Corpus | Default -E | Whole-file -E | 4 KiB -E | Complete lexer cycles/byte |
| --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(whole)+'''

[Source changes, census, correctness controls, locked benchmark drivers and raw results](lexer-literal-kinds.tar.xz)
'''
with tarfile.open(out/'lexer-literal-kinds.tar.xz','w:xz')as tar:
 for n in ('census.patch','census.py','census-task','corpus','masks.patch','lookup.patch','quote.patch','gate-task','compare.c','entry.c','replay-task','capture.c','writer.c','replay-item.h','replay-api.h','replay.c','replaygen.py','versions.py','build-lookup','lookup-real','lookup-corpus','oracle.c','clang-oracle.py','clang-only','check-oracle','record.py'):tar.add(p/n,arcname='source/'+n)
 for label in ('bad-utf8','bad-string'):
  import difflib
  target='buster/compiler/c_lexer.c'
  change=''.join(difflib.unified_diff((p/'lookup'/target).read_text().splitlines(True),(p/label/target).read_text().splitlines(True),'a/'+target,'b/'+target))
  import io
  blob=change.encode();info=tarfile.TarInfo('source/'+label+'.patch');info.size=len(blob);tar.addfile(info,io.BytesIO(blob))
 for f in sorted(r.rglob('*')):
  if f.is_file() and 'job' not in f.name:tar.add(f,arcname='native/'+str(f.relative_to(r)))
(out/'README.md').write_text(data)
print(*summary,*whole,sep='\n')
