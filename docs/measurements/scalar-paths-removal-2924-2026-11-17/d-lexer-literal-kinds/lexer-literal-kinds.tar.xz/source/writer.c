#define _GNU_SOURCE
#include "buster/compiler/c_lexer.c"
#include "replay-api.h"
#include "replay-item.h"
__attribute__((noinline)) uint64_t ENTRY(const void*ptr,uint8_t*k,uint32_t*a,uint32_t*b){
    const Snapshot*item=ptr;
    OutputCursors cur={.kind=k,.start=a,.end=b};
#ifdef ORIGINAL
    cur=write_chunk(&item->tokens,item->source,item->begin,item->length,cur);
#else
    cur=write_chunk(&item->tokens,cur);
#endif
    return ((uint64_t)(cur.end-b)<<32)|(uint32_t)(cur.kind-k);
}
