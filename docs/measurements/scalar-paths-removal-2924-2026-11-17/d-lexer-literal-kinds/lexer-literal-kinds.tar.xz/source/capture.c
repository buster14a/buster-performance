#define _GNU_SOURCE
#include <stdlib.h>
#include "buster/compiler/c_lexer.c"
#include "replay-api.h"
#include "replay-item.h"
static Snapshot items[1024];
static unsigned total;
static void record_shape(const ChunkTokens* t,const uint8_t* source,uint64_t begin,uint64_t length)
{
    if(total>=1024)abort();
    Snapshot* item=items+total++;
    item->tokens=*t;memcpy(item->raw,t->raw,sizeof(item->raw));item->tokens.raw=item->raw;
    item->source=source;item->begin=begin;item->length=length;item->literals=0;
    for(unsigned i=0;i<BUSTER_LEX_VECTOR_COUNT;i++)if((t->token_lanes & (1u<<i)) && (t->special_lanes & (1u<<i)) && (t->prefixes[i] || t->unknowns[i]))item->literals=1;
}
unsigned capture_input(const uint8_t*p,uint64_t n,uint8_t*k,uint32_t*a,uint32_t*b)
{total=0;if(c_tokenize(p,n,k,a,b,0)<0)abort();return total;}
const void* saved(unsigned i){return items+i;}
int has_literals(unsigned i){return items[i].literals;}
