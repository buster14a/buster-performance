from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent;name='src/buster/compiler/c_lexer.c';s=(p/'tree'/name).read_text()
a=s.index('// III. Write-out: compresses')
helper='''#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdlib.h>
static uint64_t* lexer_prefix_counters(void)
{
    static uint64_t* counters;
    if (counters == NULL)
    {
        const char* path = getenv("BUSTER_PREFIX_COUNTS");
        if (path != NULL)
        {
            const int fd = open(path, O_RDWR | O_CLOEXEC);
            if (fd >= 0)
            {
                void* map = mmap(NULL, 128, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
                if (map != MAP_FAILED) counters = map;
                close(fd);
            }
        }
    }
    return counters;
}

'''
t=s[:a]+helper+s[a:]
a=t.index('    for (unsigned j = first; j < end;',t.index('BUSTER_INLINE OutputCursors write_chunk'))
t=t[:a]+'''    uint64_t* counts = lexer_prefix_counters();
    if (counts != NULL)
    {
        __atomic_fetch_add(counts, 1, __ATOMIC_RELAXED);
        __atomic_fetch_add(counts + 1, end - first, __ATOMIC_RELAXED);
    }
'''+t[a:]
a=t.index('        // Prefixed and unknown literals (rare).');t=t[:a]+'''        if (counts != NULL && special)
        {
            __atomic_fetch_add(counts + 2, 1, __ATOMIC_RELAXED);
            __atomic_fetch_add(counts + 3, (uint64_t)__builtin_popcountll(t->prefixes[j]), __ATOMIC_RELAXED);
            __atomic_fetch_add(counts + 4, (uint64_t)__builtin_popcountll(t->unknowns[j]), __ATOMIC_RELAXED);
        }
'''+t[a:]
a=t.index('            cur_kind[index] = kind');t=t[:a]+'''            if (counts != NULL && kind != C_TOKEN_UNKNOWN)
            {
                const uint32_t index = kind >= C_TOKEN_STRING_LITERAL ? 4 + kind - C_TOKEN_STRING_LITERAL : kind - C_TOKEN_CHAR_CONSTANT;
                if (index > 0 && index <= 8) __atomic_fetch_add(counts + 4 + index, 1, __ATOMIC_RELAXED);
            }
'''+t[a:]
# A chunk can own no token lanes. No iteration occurs when end < first.
t=t.replace('counts + 1, end - first,','counts + 1, end > first ? end - first : 0,')
(p/'census.patch').write_text(''.join(unified_diff(s.splitlines(True),t.splitlines(True),'a/'+name,'b/'+name)))
