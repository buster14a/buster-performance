from pathlib import Path
from statistics import median
import re,tarfile
p=Path(__file__).parent;r=p/'results';s=(p/'record.py').read_text()
exec(s[s.index('def complete('):s.index('whole=[',s.index('def complete('))].replace("f'lookup-{g}'","f'{variant}-{g}'"))
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-lexer-literal-kinds')
rows=[]
for variant in ('lookup','guarded'):
 for g in ('lua','sqlite','musl'):
  row=complete(g);assert row;rows.append('| '+variant+' '+row)
 for f in r.glob(variant+'-lexer-*.log'):assert '200000' in f.read_text()
 assert len(list(r.glob(variant+'-lexer-*.log')))==12
 s=(r/f'{variant}-preprocessor.log').read_text();assert 'cases: 0 of 419 fail' in s and len(re.findall(r'64 compared with clang .*0 differ',s))==2
body='''## Complete compiler qualification for the writer guard

Each executable ran against the same uninstrumented parent on CPU 2 of the locked Ryzen 7 9700X. The preprocessing values are paired changes in user cycles across five rounds of three processes. The lexer value is the median change in cycles per byte over three pairs. All token streams, preprocessed output hashes and diagnostics matched. Both compilers passed twelve seeded lexer runs with 200,000 fuzz inputs per run, 419 preprocessing fixtures, the lane determinism comparison and 128 Clang fuzz checks.

| Implementation | Corpus | Default preprocessing | Whole file | 4 KiB window | Lexer |
| --- | --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

[Commands, fixed-seed results, comparison hashes and timings](writer-compiler.tar.xz)
'''
with tarfile.open(out/'writer-compiler.tar.xz','w:xz',preset=2)as t:
 for name in ('record-complete.py','record.py','build-guarded','guarded-corpus','guarded-real','lookup.patch','guarded.patch'):t.add(p/name,arcname='source/'+name)
 for v in ('lookup','guarded'):
  for f in sorted(r.glob(v+'-*')):
   if f.is_dir()or 'lexer-' in f.name or 'preprocessor.log' in f.name:t.add(f,arcname='native/'+f.name)
file=out/'README.md';file.write_text(file.read_text().split('\n## Complete compiler qualification')[0].rstrip()+'\n\n'+body)
print(*rows,sep='\n')
