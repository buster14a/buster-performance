from pathlib import Path
from statistics import median
import tarfile
p=Path(__file__).parent;r=p/'results';out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-lexer-literal-kinds')
rows=[]
for i,name in enumerate(('Out-of-line literal helper','Inline combined literal mask','Separate chunk literal mask')):
 cells=[]
 for phase,mode in [('gate',None),('replay',0),('replay',1)]:
  xs=[]
  for seed in [1,133,789]:
   prefix='rare-'+phase
   ds={tuple(map(int,l.split()[:2 if mode is None else 3])):list(map(int,l.split()))for l in (r/f'{prefix}-{seed}.tsv').read_text().splitlines()}
   log=(r/f'{prefix}-{seed}.log').read_text();assert 'checks passed' in log or '3600 guarded token stream comparisons passed' in log
   xs.append(ds)
  d=[]
  for k in set.intersection(*(set(s)for s in xs)):
   if mode is None or k[2]==mode:
    col=4 if mode is None else 5;d.append(median(s[k][col+i+1]/s[k][col]for s in xs))
  cells.append(f'{sum(v<=1 for v in d)}/{len(d)} · {median(d):.3f}×')
 rows.append('| '+name+' | '+' | '.join(cells)+' |')
text='''## Keeping the ordinary token write small

The inline combined mask tests for either prefixes or unknown lanes before calculating literal classes. The out-of-line candidate puts that same operation in a separate function, and the third candidate calculates a per-chunk literal mask. All three produced the same bytes on the protected tokenizer inputs and captured writes. Timing uses the same seeds, widths, rotations and reach criteria as above. Each cell gives the number of paired ratios at or below one and the median ratio.

| Implementation | Full tokenizer | All captured inputs | Affected chunks only |
| --- | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

[Variants, complete-tokenizer and writer runs](literal-mask-guards.tar.xz)
'''
with tarfile.open(out/'literal-mask-guards.tar.xz','w:xz') as t:
 for n in ('rare-variants.py','assisted.patch','guarded.patch','split.patch','rare-compare.c','rare-replay.c','rare-replay-task','rare-gate-task','build-guarded','guarded-real','guarded-corpus','record-guards.py'):t.add(p/n,arcname='source/'+n)
 for n in r.glob('rare-*'):t.add(n,arcname='native/'+n.name)
f=out/'README.md';start=f.read_text().split('\n## Keeping the ordinary token write small')[0];f.write_text(start.rstrip()+'\n\n'+text)
print(*rows,sep='\n')
