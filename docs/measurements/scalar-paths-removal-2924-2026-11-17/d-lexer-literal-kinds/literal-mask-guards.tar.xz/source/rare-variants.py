from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent;f=Path('buster/compiler/c_lexer.c');src=(p/'lookup'/f).read_text()
a=src.index('            // The chunk has a full lookahead');b=src.index('\n        }',a)
rare=src[a:b];j=rare.index('                const __mmask64 utf8');k=rare.index('                kinds = _mm512_mask_mov_epi8')
build=rare[j:k]
for v in ('assisted','guarded','split'):
 s=src
 if v in ('assisted','guarded'):
  d=('BUSTER_LEX_NOINLINE static' if v=='assisted' else 'BUSTER_INLINE')+''' __m512i write_literal_kinds(const ChunkTokens* t, unsigned j, __m512i base)
{
    const __m512i* raw = t->raw;
    const __m512i next_characters = _mm512_loadu_si512((const uint8_t*)&raw[j] + 1);
'''+''.join('    '+l.strip()+'\n'for l in build.splitlines())+'''    const __m512i kinds = _mm512_mask_mov_epi8(base, t->prefixes[j], literal);
    return _mm512_mask_set1_epi8(kinds, t->unknowns[j], C_TOKEN_UNKNOWN);
}

'''
  s=src[:a]+'''            if (BUSTER_UNLIKELY((t->prefixes[j] | t->unknowns[j]) != 0))
            {
                kinds = write_literal_kinds(t, j, kinds);
            }'''+src[b:]
  pos=s.index('// III. Write-out: compresses');s=s[:pos]+d+s[pos:]
 else:
  s=src[:a]+src[b:];a=s.index('        kinds = _mm512_mask_mov_epi8(kinds, _load_mask64((__mmask64*)&t->start_of_line[j])')
  s=s[:a]+'''        if (BUSTER_UNLIKELY((rare_lanes >> j) & 1))
        {
'''+rare+'''
        }
'''+s[a:];pos=s.index('    for (unsigned j = first; j < end;',s.index('BUSTER_INLINE OutputCursors write_chunk('))
  s=s[:pos]+'''    const __m512i literals = _mm512_or_si512(_mm512_load_si512(t->prefixes), _mm512_load_si512(t->unknowns));
    const unsigned rare_lanes = _mm512_test_epi64_mask(literals, literals);
'''+s[pos:]
 d=p/v/f;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(s)
 orig=(p/'base'/f).read_text()
 (p/(v+'.patch')).write_text(''.join(unified_diff(orig.splitlines(True),s.splitlines(True),'a/src/'+str(f),'b/src/'+str(f))))
for n in ('replay','compare'):
 s=(p/(n+'.c')).read_text().replace('masks','assisted').replace('lookup','guarded').replace('quote','split');(p/('rare-'+n+'.c')).write_text(s)
for n in ('replay-task','gate-task'):
 s=(p/n).read_text().replace('/dev/shm/buster-unroll-6b097f86/src/src','/dev/shm/buster-native-base-cc7d4ffb-6b097f86/src').replace('masks','assisted').replace('lookup','guarded').replace('quote','split')
 if n=='gate-task':
  s=s.replace('compare.c','rare-compare.c').replace(' -o gate ', ' -o rare-gate ').replace('./gate ', './rare-gate ').replace('gate-build.log','rare-gate-build.log').replace('gate-$seed','rare-gate-$seed').replace('gate.ok','rare-gate.ok')
 else:
  s=s.replace('replay.c','rare-replay.c').replace(' -o replay ', ' -o rare-replay ').replace('./replay ', './rare-replay ').replace('replay-build.log','rare-replay-build.log').replace('replay-$seed','rare-replay-$seed').replace('replay.ok','rare-replay.ok')
 (p/('rare-'+n)).write_text(s)
