#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include "replay-api.h"
extern Writer write_base,write_assisted,write_guarded,write_split;
static Writer* volatile methods[]={write_base,write_assisted,write_guarded,write_split};
static uint32_t state=1;
static uint32_t random_word(void){state=1664525*state+1013904223;return state;}
static uint64_t tick(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int cmp(const void*a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return(x>y)-(x<y);}
static void generate(uint8_t* p,size_t n,unsigned shape,unsigned offset)
{
    const char* samples[]={" ", "foo += bar;\n", "L\"x\" ", "u8\"x\" U'c' u\"a\" L'q' u8'b' U\"y\" u'z' L\"q\"\n",
      "ordinary; ordinary; ordinary; ordinary; ordinary; ordinary; ordinary; u8\"q\";\n", "\"unterminated\nL'unterminated\n",
      "u8\"_\"\nL\"\"\nU'0'\n", "u8x ++ LL \"y\" u88 U3 xL+42 .2e-1\n","// L'x'\n/* u8\"a\" */u'b' ",
      "L\"x\" U'c' u\"a\" L'q' u8'b' U\"y\" u'z' L\"q\"\n"};
    const char* start=samples[shape];size_t width=strlen(start);
    for(size_t i=0;i<n;i++)p[i]=i<offset?' ':start[(i-offset)%width];
    if(shape==9){for(size_t i=3;i<n;i+=67)p[i]=(random_word()&1)?'\n':' ';}
}
int main(int argc,char**argv){
    if(argc>1)state=(uint32_t)strtoul(argv[1],0,0);
    unsigned widths[130],nw=0;for(unsigned i=0;i<=65;i++)widths[nw++]=i;
    unsigned more[]={95,96,97,127,128,129,255,256,257,509,510,511,512,513,514,515,1023,1024,1025,4095,4096,4097,16384,65536};
    for(unsigned i=0;i<sizeof(more)/sizeof(*more);i++)widths[nw++]=more[i];
    size_t max=65536,page=(size_t)sysconf(_SC_PAGESIZE);
    uint8_t* guard=mmap(NULL,max+page*2,PROT_NONE,MAP_ANONYMOUS|MAP_PRIVATE,-1,0);if(guard==MAP_FAILED||mprotect(guard+page,max,PROT_READ|PROT_WRITE))return 2;
    size_t capacity=max+600;uint8_t*k[5];uint32_t*a[5],*b[5];
    for(unsigned i=0;i<5;i++){k[i]=malloc(capacity);a[i]=malloc(capacity*4);b[i]=malloc(capacity*4);if(!k[i]||!a[i]||!b[i])return 3;}
    unsigned checks=0;
    for(unsigned z=0;z<nw;z++)for(unsigned shape=0;shape<10;shape++){
        unsigned n=widths[z],off=shape==6?(n?random_word()%n:0):0;
        uint8_t*p=guard+page+max-n;generate(p,n,shape,off);
        unsigned chunks=capture_input(p,n,k[4],a[4],b[4]);
        for(unsigned mode=0;mode<2;mode++){
            unsigned selected[1024],count=0;
            for(unsigned c=0;c<chunks;c++)if(!mode||has_literals(c))selected[count++]=c;
            if(count==0)continue;
            for(unsigned c=0;c<count;c++){
                unsigned index=selected[c];uint64_t ref=methods[0](saved(index),k[0],a[0],b[0]);
                for(unsigned j=1;j<4;j++){
                    uint64_t got=methods[j](saved(index),k[j],a[j],b[j]);
                    if(got!=ref||memcmp(k[j],k[0],(uint32_t)ref)||memcmp(a[j],a[0],4*(uint32_t)ref)||memcmp(b[j],b[0],4*(ref>>32))){
                        fprintf(stderr,"replay mismatch n=%u shape=%u chunk=%u method=%u\n",n,shape,c,j);return 4;
                    }
                    checks++;
                }
            }
            uint64_t times[4][9];unsigned repeats=512/count+3;
            for(unsigned round=0;round<9;round++){
                unsigned rotate=random_word()%4;
                for(unsigned i=0;i<4;i++){
                    unsigned j=(rotate+(round%2?3*i:i))%4;Writer*fn=methods[j];uint64_t lo=tick();
                    for(unsigned rep=0;rep<repeats;rep++)for(unsigned c=0;c<count;c++)fn(saved(selected[c]),k[j],a[j],b[j]);
                    times[j][round]=tick()-lo;
                }
            }
            printf("%u %u %u %u %u",n,shape,mode,count,repeats);
            for(unsigned j=0;j<4;j++){qsort(times[j],9,sizeof(uint64_t),cmp);printf(" %lu",times[j][4]);}puts("");
        }
    }
    fprintf(stderr,"%u captured output checks passed\n",checks);
}
