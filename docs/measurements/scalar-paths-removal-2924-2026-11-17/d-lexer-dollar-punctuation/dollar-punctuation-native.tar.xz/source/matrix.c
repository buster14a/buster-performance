#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
typedef int64_t Lex(const uint8_t*,uint64_t,uint8_t*,uint32_t*,uint32_t*,uint32_t);
extern Lex base,vector,tables,scan,scalar;
static Lex* volatile methods[]={base,vector,tables,scan,scalar};
static uint32_t state=1;
static uint32_t random_word(void){state=1664525*state+1013904223;return state;}
static uint64_t tick(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int cmp(const void*a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return(x>y)-(x<y);}
static void generate(uint8_t* p,size_t n,unsigned shape,unsigned offset)
{
    const char* samples[]={" ", "int foo = 5;\n", "$$ $abc x$1.5 x$1e-2\n",
      "u8\"$\"$L'x' $u8'x' 1$e-2 12$e+1\n", "\"a\"ms$xy \"b\"_x$z 'x'_w$k \"c\"sv$\n",
      "x$\\\ny 1$\\\r\n.5 $\\\nL\"x\" $L\\\n\"x\"\n", "pre$fix 2$x$y \\\n$x\n",
      "/* $ */ $ // $abc\n\"$\" '$' $foo$\n", "R\"d($)d\"$xx $u8R\"(x$)\"\n",
      "??/\n$\\u00E9 a\xc3\xa9$x 1e$+4\n"};
    const char* start=samples[shape];size_t width=strlen(start);
    for(size_t i=0;i<n;i++)p[i]=i<offset?' ':start[(i-offset)%width];
    if(shape==9){for(size_t i=3;i<n;i+=67)p[i]=(random_word()&1)?'\n':' ';}
}
int main(int argc,char**argv){
    if(argc>1)state=(uint32_t)strtoul(argv[1],0,0);
    unsigned widths[130],nw=0;for(unsigned i=0;i<=65;i++)widths[nw++]=i;
    unsigned more[]={95,96,97,127,128,129,255,256,257,509,510,511,512,513,514,515,1023,1024,1025,4095,4096,4097,16384,65536};
    for(unsigned i=0;i<sizeof(more)/sizeof(*more);i++)widths[nw++]=more[i];
    size_t max=65536,page=(size_t)sysconf(_SC_PAGESIZE);
    uint8_t* guard=mmap(NULL,max+page*2,PROT_NONE,MAP_ANONYMOUS|MAP_PRIVATE,-1,0);if(guard==MAP_FAILED||mprotect(guard+page,max,PROT_READ|PROT_WRITE))return 2;
    size_t capacity=max+600;uint8_t*k[5];uint32_t*a[5],*b[5];
    for(unsigned i=0;i<5;i++){k[i]=malloc(capacity);a[i]=malloc(capacity*4);b[i]=malloc(capacity*4);if(!k[i]||!a[i]||!b[i])return 3;}
    unsigned checks=0; const uint32_t modes[]={128,130,132,134,136,152,160,192,224,129,384,162};
    uint32_t flags=argc>2?strtoul(argv[2],NULL,0):128;
    for(unsigned z=0;z<nw;z++)for(unsigned shape=0;shape<10;shape++){
        unsigned n=widths[z],off=shape==6?(n?random_word()%n:0):0;
        uint8_t*p=guard+page+max-n;generate(p,n,shape,off);
        for(unsigned mode=0;mode<sizeof(modes)/sizeof(modes[0]);mode++){
            uint32_t f=modes[mode];
            int64_t result=methods[4](p,n,k[4],a[4],b[4],f);
            if(result<0||result>n)return 4;
            for(unsigned j=0;j<4;j++){
                int64_t got=methods[j](p,n,k[j],a[j],b[j],f);
                if(got!=result||memcmp(k[j],k[4],result)||memcmp(a[j],a[4],result*4)||memcmp(b[j],b[4],result*4)){
                    fprintf(stderr,"mismatch size=%u shape=%u flags=%u method=%u got=%ld oracle=%ld\n",n,shape,f,j,got,result);return 5;
                }
                checks++;
            }
        }
        const int64_t expected=methods[4](p,n,k[4],a[4],b[4],flags);
        uint64_t times[5][9];unsigned repeats=2048/(n/8+1)+1;
        for(unsigned round=0;round<9;round++){
            unsigned rotate=random_word()%5;
            for(unsigned s=0;s<5;s++){
                unsigned j=(rotate+(round%2?4*s:s))%5;Lex* fn=methods[j];uint64_t lo=tick();
                for(unsigned rep=0;rep<repeats;rep++)fn(p,n,k[j],a[j],b[j],flags);
                times[j][round]=tick()-lo;
            }
        }
        printf("%u %u %u %ld",n,shape,repeats,expected);
        for(unsigned j=0;j<5;j++){qsort(times[j],9,sizeof(uint64_t),cmp);printf(" %lu",times[j][4]);}puts("");
    }
    fprintf(stderr,"%u guarded token stream comparisons passed\n",checks);
}
