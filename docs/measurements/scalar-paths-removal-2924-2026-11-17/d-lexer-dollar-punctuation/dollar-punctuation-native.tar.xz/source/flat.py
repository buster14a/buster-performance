from pathlib import Path
import re
p=Path(__file__).parent;f='buster/compiler/c_lexer.c'
s=(p/'tables'/f).read_text();a=s.index('static const uint8_t c_char_kinds[128]');b=s.index('};',a)
xs=[int(q,16)for q in re.findall(r'0x[0-9A-F]{2}',s[a:b])]
assert len(xs)==128
safe=b'()[]{},;~$';gaps=b' \t\f\v\0'
values=[0xfd if c in b'\r\n' else 0xfe if c in gaps else 0 if c==36 else xs[c] if chr(c).isascii()and (chr(c).isalnum()or c==95 or c in safe) else 0xfc for c in range(128)]
table='BUSTER_LEX_ALIGN(64) static const uint8_t c_dollar_word_kinds[128] =\n{\n'+'\n'.join('    '+', '.join(f'0x{x:02x}'for x in values[i:i+16])+','for i in range(0,128,16))+'\n};'
code=(p/'flat.inc').read_text().replace('TABLE',table).replace('            start_of_line = newlines > start && __builtin_clzll(newlines | 1) < __builtin_clzll(start | 1);\n            if (!start) start_of_line = 1;','            start_of_line = newlines > start;').replace('_mm512_mask_or_epi32(kind, 0xffff, kind,','_mm512_or_si512(kind,')
for name in ['flat','joined','guardonly']:
 t=s
 if name=='joined':
  # A single mask lookup also handles punctuation when there is no compound operator, comment or exponent sign.
  signs=b'=+*/&|!-^%#:<>';w=values[:]
  for c in signs:w[c]=xs[c]
  loc='\n'.join('    '+', '.join(f'0x{x:02x}'for x in w[i:i+16])+','for i in range(0,128,16));tab=table[:table.index('{')+2]+loc+'\n};'
  c=code.replace(table,tab).replace('uint64_t nstarts =','uint64_t previous_operator = 0, previous_exponent = 0;\n    uint64_t nstarts =')
  a=c.index('        const uint64_t newlines')
  c=c[:a]+'''        const uint64_t operators = _mm512_mask_cmpneq_epi8_mask(tokens & ~words, perm2b(c_operator_classes, raw), _mm512_setzero_si512());
        const uint64_t exponent = _mm512_cmpeq_epi8_mask(_mm512_or_si512(raw, splat8(32)), splat8('p')) |
                                  _mm512_cmpeq_epi8_mask(_mm512_or_si512(raw, splat8(32)), splat8('e'));
        const uint64_t sign = _mm512_cmpeq_epi8_mask(raw, splat8('+')) | _mm512_cmpeq_epi8_mask(raw, splat8('-'));
        if ((operators & ((operators << 1) | previous_operator)) || (sign & ((exponent << 1) | previous_exponent))) return C_TOKENIZER_ERROR_NEEDS_SCALAR;
        previous_operator = operators >> 63;
        previous_exponent = exponent >> 63;
'''+c[a:]
 else:c=code
 if name=='guardonly':
  # Retain the complete vector grammar for the flagged suffix of a source containing complex spellings.
  c=c.replace('        const __m512i kind =', '        const __m512i kind =')
 a=t.index('// The chunk loop that `flags` ask for');t=t[:a]+c+'\n'+t[a:]
 if name=='guardonly':
  a=t.index('    if (flags & C_TOKENIZER_NO_DOLLARS)',t.index('static int64_t tokenize_with_flags('));a=t.index('        const bool cplusplus',a)
  t=t[:a]+'''        const int64_t words = tokenize_dollar_words(source, length, begin, kinds, starts, ends);
        if (words >= 0) return words;
'''+t[a:]
 else:
  a=t.index('    if (flags & C_TOKENIZER_NO_DOLLARS)',t.index('static int64_t tokenize_with_flags('));a=t.index('        const bool cplusplus',a)
  t=t[:a]+'''        const int64_t words = tokenize_dollar_words(source, length, begin, kinds, starts, ends);
        if (words >= 0) return words;
'''+t[a:]
  if name=='flat':
   a=t.index('static int64_t c_tokenize_from(');a=t.index('\n{',a)+2
   t=t[:a]+'''
    if ((flags & C_TOKENIZER_NO_DOLLARS) && begin < length && memchr(source + begin, '$', length - begin) == NULL)
    {
        const int64_t words = tokenize_dollar_words(source, length, begin, kinds, starts, ends);
        if (words >= 0) return words;
        flags &= ~C_TOKENIZER_NO_DOLLARS;
    }
'''+t[a:]
 d=p/name/f;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(t)
for a,b in [('gate','flat-gate'),('matrix.c','flat-matrix.c')]:
 t=(p/a).read_text().replace('vector,tables,scan','flat,joined,guardonly').replace('vector tables scan','flat joined guardonly').replace('base,masks,lookup,quote','base,flat,joined,guardonly').replace('matrix.c','flat-matrix.c').replace('dollar-matrix','dollar-flat-matrix').replace('gate-','flat-gate-').replace('touch gate.ok','touch flat-gate.ok')
 (p/b).write_text(t)
