from pathlib import Path
from subprocess import check_output
p=Path(__file__).parent;root=p/'tree';d=root/'src/buster/compiler'
def original(n):return check_output(['git','show','HEAD:src/buster/compiler/'+n],cwd=root).decode()
f='c_lexer.c';s=original(f)
a=s.index('// Common code takes the vectorized path;');b=s.index('// Differences from',a)
s=s[:a]+'''// With C_TOKENIZER_NO_DIGRAPHS or C_TOKENIZER_NO_LINE_COMMENTS, C also supports the punctuator and comment
// rules of older language modes. With C_TOKENIZER_NO_DOLLARS, '$' is punctuation in both identifiers and
// pp-numbers, as in -fno-dollars-in-identifiers and assembler-with-cpp. Rare lines, including raw strings,
// spliced tokens and non-ASCII identifiers, use the scalar lexer with the same flags.
//
// '''.rstrip()+'\n'+s[b:]
a=s.index('    // clang has it with -fno-dollars');b=s.index('    C_TOKENIZER_NO_DOLLARS',a)
s=s[:a]+"    // clang has it with -fno-dollars-in-identifiers and assembler-with-cpp.\n"+s[b:]
s=s.replace("The scalar lexer's alone, as C_TOKENIZER_NO_DOLLARS is:", "Only the scalar lexer keeps comments:").replace('Only from c_tokenize_vectorized (and always with C_TOKENIZER_NO_DOLLARS).','Only from c_tokenize_vectorized.')
s=s.replace('bool after_string)\n','bool after_string, bool no_dollars)\n')
a=s.index('        while (suffix_length < 4 &&');b=s.index('            suffix_length += 1;',a)
s=s[:a]+'''        while (suffix_length < sizeof(suffix))
        {
            const uint8_t c = source_byte(source, begin, length, position + suffix_length);
            if (c >= 0x80 || !(c_char_properties[c] & BUSTER_LEX_CHAR_IDENTIFIER) || (c == '$' && no_dollars))
            {
                break;
            }
            suffix[suffix_length] = (char)c;
'''+s[b:]
s=s.replace("source_byte(source, begin, length, position) == '\"'))","source_byte(source, begin, length, position) == '\"', no_dollars))")
s=s.replace('const bool digraphs, const bool separators)\n','const bool digraphs, const bool separators, const bool no_dollars)\n')
s=s.replace('    __m512i classes = perm2b(c_operator_classes, raw);', '''    if (no_dollars)
    {
        properties = _mm512_mask_mov_epi8(properties, _mm512_cmpeq_epi8_mask(raw, splat8('$')), _mm512_setzero_si512());
    }
    __m512i classes = perm2b(c_operator_classes, raw);''')
s=s.replace('cplusplus, digraphs, separators);','cplusplus, digraphs, separators, no_dollars);')
s=s.replace('uint64_t length, OutputCursors cursors)','uint64_t length, OutputCursors cursors, bool no_dollars)')
s=s.replace('    return write_chunk(t, source, begin, length, cursors);','    return write_chunk(t, source, begin, length, cursors, no_dollars);')
s=s.replace('cur_start, cur_end });','cur_start, cur_end }, no_dollars);').replace('cur_start, cur_end }).kind','cur_start, cur_end }, no_dollars).kind')
s=s.replace('        __m512i kinds = perm2b(c_char_kinds, raw[j]);', '''        __m512i kinds = perm2b(c_char_kinds, raw[j]);
        if (no_dollars)
        {
            kinds = _mm512_mask_set1_epi8(kinds, _mm512_cmpeq_epi8_mask(raw[j], splat8('$')), C_TOKEN_UNKNOWN);
        }''')
s=s.replace('const bool separators, const bool raw_strings, const uint8_t* source','const bool separators, const bool raw_strings, const uint8_t* source',1)
a=s.index('BUSTER_INLINE int64_t tokenize_chunks(');b=s.index('\n',a)
s=s[:a]+s[a:b].replace('const bool raw_strings,','const bool raw_strings, const bool no_dollars,')+s[b:]
import re
s=re.sub(r'(return tokenize_chunks\([^\n]+?, )(source, length)',r'\1false, \2',s)
a=s.index('// The chunk loop that `flags` ask for')
s=s[:a]+'''// Dollar-punctuation modes share the same vector loop. The ordinary C and C++ loops specialize the flag away.
BUSTER_LEX_NOINLINE static int64_t tokenize_dollar_punctuation(bool cplusplus, bool digraphs, bool line_comments, bool separators, bool raw_strings,
                                                               const uint8_t* source, uint64_t length, uint64_t begin, uint8_t* kinds, uint32_t* starts,
                                                               uint32_t* ends, uint64_t* written, uint64_t* restart, uint64_t* scalar_until)
{
    return tokenize_chunks(cplusplus, digraphs, line_comments, separators, raw_strings, true, source, length, begin, kinds, starts, ends, written, restart, scalar_until);
}

'''+s[a:]
a=s.index('    if (flags & C_TOKENIZER_CPLUSPLUS)',s.index('static int64_t tokenize_with_flags('))
s=s[:a]+'''    if (flags & C_TOKENIZER_NO_DOLLARS)
    {
        const bool cplusplus = (flags & C_TOKENIZER_CPLUSPLUS) != 0;
        result = tokenize_dollar_punctuation(cplusplus, digraphs, line_comments, separators, cplusplus || raw_strings, source, length, begin,
                                             kinds, starts, ends, written, restart, scalar_until);
    }
    else '''+s[a:].lstrip()
a=s.index('// Does a source take the scalar lexer whole');b=s.index('static bool c_tokenize_scalar_only',a)
s=s[:a]+'''// The scalar lexer handles retained comments, enabled trigraphs present in the source, and C++ modes
// without digraphs or line comments.
'''+s[b:]
s=s.replace('(flags & (C_TOKENIZER_NO_DOLLARS | C_TOKENIZER_KEEP_COMMENTS))','(flags & C_TOKENIZER_KEEP_COMMENTS)')
(d/f).write_text(s)
f='c_preprocessor.c';s=original(f);a=s.index('// Does token `i` hold a');b=s.index('// The lexer\'s flags for a mode',a)
s=s[:a]+s[b:];s=s.replace('static __attribute__((unused)) uint32_t pp_lex_flags','static uint32_t pp_lex_flags')
a=s.index('// Splits, among `count` freshly lexed');b=s.index('\n}',a)+2
s=s[:a]+'''// Split prefixed literals that the language mode does not recognize.
static uint32_t pp_lex_for_mode(const PPPrepare* mode, const uint8_t* bytes, uint8_t* kinds, uint32_t* starts, uint32_t* ends, uint32_t count)
{
    if (mode->split_kinds != 0)
    {
        const uint32_t splits = pp_count_splits_vector(bytes, kinds, starts, ends, count, mode->split_kinds);
        if (splits != 0)
        {
            count = pp_split_prefixes(bytes, kinds, starts, ends, count, splits, mode->split_kinds);
        }
    }
    return count;
}'''+s[b:]
s=s.replace(" The lexer takes it into identifiers and pp-numbers, and\n// pp_split_dollars splits it out of them where it isn't.","").replace("the '$' boundary of pp_split_dollars where '$' is punctuation","the lexer’s identifier boundary where '$' is punctuation")
s=s.replace('pp_lex_for_mode(prepare, data->bytes, data->length,','pp_lex_for_mode(prepare, data->bytes,').replace('prepare->refine_flags | kept','pp_lex_flags(prepare) | kept').replace('data->values + count, prepare->refine_flags)','data->values + count, pp_lex_flags(prepare))').replace('!prepare->dollar_punctuation && prepare->comments','prepare->comments').replace('c_tokenize_scalar_only(data->bytes, data->length, prepare->refine_flags)','c_tokenize_scalar_only(data->bytes, data->length, pp_lex_flags(prepare))')
(d/f).write_text(s)
f='c_preprocessor_impl.c';s=original(f).replace('pp_lex_for_mode(&mode, bytes, length,','pp_lex_for_mode(&mode, bytes,').replace("which pp_split_dollars leaves without a '$' there, but the classes don't","whose ends the lexer has already found. The classes don't")
(d/f).write_text(s)
f='c_preprocessor_test.c';s=original(f).replace("is punctuation (pp_dollar_punctuation, the\n// scalar lexer's, not the stream's pp_split_dollars).","is punctuation (pp_dollar_punctuation).")
(d/f).write_text(s)
(p/'vector.patch').write_bytes(check_output(['git','diff'],cwd=root))
