// Map the regular packet alphabet to raw token kinds. Whitespace, newline and characters
// that need the general lexical grammar have distinct values above the kind range.
TABLE

static int64_t tokenize_dollar_words(const uint8_t* source, uint64_t length, uint64_t begin, uint8_t* kinds, uint32_t* starts, uint32_t* ends)
{
    const __m512i indices = _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
    uint64_t nstarts = 0, nends = 0, previous_word = 0, start_of_line = 1;
    const uintptr_t aligned = (uintptr_t)(source + begin) & ~(uintptr_t)63;
    const int64_t offset = (int64_t)(aligned - (uintptr_t)source);
    const unsigned head = (unsigned)((uintptr_t)(source + begin) - aligned);
    for (int64_t first = offset; first < (int64_t)length; first += 64)
    {
        const uint64_t left = (uint64_t)((int64_t)length - first);
        const uint64_t valid = _bzhi_u64(UINT64_MAX, left < 64 ? (uint32_t)left : 64) & (first == offset ? UINT64_MAX << head : UINT64_MAX);
        const uintptr_t address = (uintptr_t)source + (uintptr_t)first;
        const __m512i raw = _mm512_maskz_loadu_epi8(valid, (const void*)address);
        const __m512i kind = perm2b(c_dollar_word_kinds, raw);
        if (_mm512_movepi8_mask(raw) || _mm512_cmpeq_epi8_mask(kind, splat8(0xfc)))
        {
            return C_TOKENIZER_ERROR_NEEDS_SCALAR;
        }
        const uint64_t words = _mm512_cmple_epu8_mask(_mm512_sub_epi8(kind, splat8(C_TOKEN_RAW_IDENTIFIER)), splat8(1));
        const uint64_t tokens = _mm512_mask_cmplt_epu8_mask(valid, kind, splat8(0xfc));
        const uint64_t newlines = _mm512_cmpeq_epi8_mask(kind, splat8(0xfd));
        uint64_t start = tokens & ~(words & ((words << 1) | previous_word));
        const uint64_t edge = (words >> 63) & (left > 64);
        bool next_word = false;
        if (edge)
        {
            const uint8_t next = source[first + 64];
            next_word = next < 128 && (c_dollar_word_kinds[next] == C_TOKEN_RAW_IDENTIFIER || c_dollar_word_kinds[next] == C_TOKEN_NUMERIC_CONSTANT);
        }
        uint64_t end = tokens & ~(words & ((words >> 1) | ((uint64_t)next_word << 63)));
        previous_word = words >> 63;
        const uint64_t events = start | newlines;
        const uint64_t bol = _pdep_u64((_pext_u64(newlines, events) << 1) | start_of_line, events) & start;
        if (events)
        {
            start_of_line = newlines > start && __builtin_clzll(newlines | 1) < __builtin_clzll(start | 1);
            if (!start) start_of_line = 1;
        }
        __m512i tagged = _mm512_mask_or_epi32(kind, 0xffff, kind, _mm512_maskz_set1_epi8(bol, (char)BUSTER_C_TOKEN_START_OF_LINE));
        _mm512_mask_compressstoreu_epi8(kinds + nstarts, start, tagged);
        for (unsigned block = 0; start || end; block += 16)
        {
            const __m512i positions = _mm512_add_epi32(indices, _mm512_set1_epi32((int32_t)(first + block)));
            const __mmask16 s = (__mmask16)start, e = (__mmask16)end;
            _mm512_mask_compressstoreu_epi32(starts + nstarts, s, positions);
            _mm512_mask_compressstoreu_epi32(ends + nends, e, _mm512_add_epi32(positions, _mm512_set1_epi32(1)));
            nstarts += __builtin_popcount(s);
            nends += __builtin_popcount(e);
            start >>= 16;
            end >>= 16;
        }
    }
    return (int64_t)nstarts;
}
