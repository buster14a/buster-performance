from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent;meta=Path('/tmp/buster-lexer-prefixes/census.py').read_text()
helper=meta.split("helper='''",1)[1].split("'''",1)[0].replace('BUSTER_PREFIX_COUNTS','BUSTER_DOLLAR_COUNTS')
diff=[]
for name in ('c_lexer','c_preprocessor'):
 f='src/buster/compiler/'+name+'.c';s=(p/'tree'/f).read_text()
 if name=='c_lexer':
  a=s.index('BUSTER_LEXER_ENTRY int64_t c_tokenize_scalar(');t=s[:a]+helper.replace('lexer_prefix_counters','dollar_lex_counts')+s[a:]
  for func,idx in [('c_tokenize_scalar',0),('c_tokenize',2)]:
   a=t.index('\n{',t.index('BUSTER_LEXER_ENTRY int64_t '+func+'('))+2
   t=t[:a]+f'''
    if (flags & C_TOKENIZER_NO_DOLLARS)
    {{
        uint64_t* counts = dollar_lex_counts();
        if (counts) {{ __atomic_fetch_add(counts + {idx}, 1, __ATOMIC_RELAXED); __atomic_fetch_add(counts + {idx+1}, length, __ATOMIC_RELAXED); }}
    }}
'''+t[a:]
 else:
  a=s.index('static int64_t pp_split_dollars(');t=s[:a]+helper.replace('lexer_prefix_counters','dollar_pp_counts')+s[a:]
  a=t.index('    int64_t result = count;',t.index('static int64_t pp_split_dollars('))
  t=t[:a]+'''    uint64_t* reach = dollar_pp_counts();
    if (reach) {
        __atomic_fetch_add(reach + 4, 1, __ATOMIC_RELAXED);
        __atomic_fetch_add(reach + 5, count, __ATOMIC_RELAXED);
        __atomic_fetch_add(reach + 6, dollars, __ATOMIC_RELAXED);
        __atomic_fetch_add(reach + 7, run_bytes != 0, __ATOMIC_RELAXED);
        __atomic_fetch_add(reach + 8, run_bytes, __ATOMIC_RELAXED);
    }
'''+t[a:]
  a=t.index('            result = c_tokenize_scalar(bytes, length',a)
  t=t[:a]+'''            if (reach) __atomic_fetch_add(reach + 9, 1, __ATOMIC_RELAXED);
'''+t[a:]
 diff.extend(unified_diff(s.splitlines(True),t.splitlines(True),'a/'+f,'b/'+f))
(p/'census.patch').write_text(''.join(diff))
s=Path('/tmp/buster-lexer-prefixes/corpus').read_text().replace('buster-lexer-prefixes','buster-lexer-dollars').replace('BUSTER_PREFIX_COUNTS','BUSTER_DOLLAR_COUNTS').replace('lexer-prefix-census','dollar-census').replace(' default) flags=();;', ' default) flags=();;\n nodollars) flags=(-fno-dollars-in-identifiers);;\n asm) flags=(-x assembler-with-cpp);;').replace('dd if=/dev/zero','dd if=/dev/zero')
s=s.replace(' "$HOME/buster-fast-bench/exclusive.sh"',' status=0\n "$HOME/buster-fast-bench/exclusive.sh"').replace('2>&1\n','2>&1 || status=$?\necho "$status" >"$root/driver-$mode-$group.status"\n')
(p/'corpus').write_text(s)
