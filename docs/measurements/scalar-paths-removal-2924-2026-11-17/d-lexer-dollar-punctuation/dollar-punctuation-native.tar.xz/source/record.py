from pathlib import Path
from collections import defaultdict
from statistics import median
import struct,tarfile,re
p=Path(__file__).parent;r=p/'results'
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-lexer-dollar-punctuation');d.mkdir(exist_ok=True)
stage=[]
for group in ('lua','sqlite','musl','dense'):
 for dialect in ('default','nodollars','asm'):
  counters=struct.unpack('<16Q',(r/f'counts-{dialect}-{group}.bin').read_bytes())
  assert (r/f'driver-{dialect}-{group}.status').read_text().strip()=='0'
  stage.append('| '+group+' | '+dialect+' | '+' | '.join(f'{counters[i]:,}'for i in (4,5,6,7,8,9))+' |')
def timings(name):
 out={}
 for di in ('default','nodollars','asm'):
  for g in ('lua','sqlite','musl'):
   q=r/f'{name}-{di}-{g}'
   for m in ('default','whole','window'):
    assert (q/(m+'-base.sha')).read_bytes()==(q/(m+'-head.sha')).read_bytes()
    assert (q/(m+'-base.err')).read_bytes()==(q/(m+'-head.err')).read_bytes()
    s=(q/(m+'.log')).read_text();assert s.rstrip().endswith('ab: done, 0 failed runs')
    v=[]
    for part in s.split('time-runs: done, 0 failed processes')[:-1]:
     a=dict(re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',part,re.M));v.append(int(a['head'])/int(a['base']))
    assert len(v)==5;out[di,g,m]=median(v)
 return out
def pct(v):return f'{(v-1)*100:+.3f}%'
def compile_rows(tbl):
 return ['| '+di+' | '+g+' | '+' | '.join(pct(tbl[di,g,m])for m in ('default','whole','window'))+' |'for di in ('default','nodollars','asm')for g in ('lua','sqlite','musl')]
raw=[];direct={}
for series,labels in [('gate',['Dynamic dialect flags','Dialect lookup tables','Dollar presence scan']),('flat-gate',['Word and punctuation packets','Packets with separated operators','Guarded word packets']),('table-gate',['Shared dialect loops','Shared loops with dollar presence scan','Property vectors selected at entry'])]:
 stats=defaultdict(list)
 for seed in (1,133,789):
  assert '43200 guarded token stream comparisons passed' in (r/f'{series}-{seed}.log').read_text()
  for line in (r/f'{series}-{seed}.tsv').read_text().splitlines():
   n,shape,reps,size,*v=map(int,line.split())
   for j in range(1,4):
    for i in [0,4]:stats[j,i,n,shape].append(v[j]/v[i])
 for j,name in enumerate(labels,1):
  xs=[[median(samples)for (ind,par,*_),samples in stats.items() if ind==j and par==side]for side in (0,4)]
  assert all(len(a)==900 for a in xs)
  vals=[sum(v<=1 for v in a)for a in xs];direct[name]=vals
  raw.append(f'| {name} | {vals[0]}/900 | {vals[1]}/900 | {median(xs[1]):.3f} |')
tbl=timings('vector')
for seed in (1,133,789):
 assert 'dollar punctuation and literal suffix boundaries: correct' in (r/f'shipping-lexer-{seed}.log').read_text()
s=(r/'shipping-preprocessor.log').read_text();assert '0 of 419 fail' in s and '0 of 240 sources differ' in s and '0 of 24 sources differ' in s and s.count('0 unverified), 0 differ')==2
doc='''# Dollar punctuation in the lexer and preprocessor

The parent is buster14a/buster@cc7d4ffb449c1f57d8d867c2ad2bf6dc6bfebc7f. The original preprocessor scans the existing token range for dollars and re-tokenizes matching contiguous runs when `-fno-dollars-in-identifiers` or assembler-with-cpp makes the dollar sign punctuation. A counter records complete scans and the work in the rare positive cases. All twelve preprocessing invocations exited successfully.

| Input | Dialect | Scan calls | Token rows | Positive byte scans | Calls with a run | Bytes in runs | Scalar re-lex calls |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(stage)+'''

## Complete preprocessing

The candidate passes the dialect to initial tokenization and removes the post-tokenization split. The vector property and kind tables distinguish dollar punctuation, and C++ standard literal-suffix recognition observes the same boundary. The fixture freezes Clang's raw tokens and checks kinds, start-of-line flags and both extents at 65 offsets across a lexer chunk boundary. Three 200,000-input lexer seeds passed. The Clang-backed preprocessor suite passed 419 fixed cases, 240 windowed sources, 24 complete units and 128 generated cases for each of C17 and C23.

Five paired rounds ran three processes per side on CPU 2 of the locked Ryzen 7 9700X. Each cell is the median change in user cycles. Preprocessed output SHA-256 and diagnostics matched separately in every cell. The parent always uses whole-file preparation in the two explicit dollar-punctuation dialects. The candidate also honors windowed preparation in those dialects.

| Dialect | Input | Default window | Whole file | 4 KiB window |
| --- | --- | ---: | ---: | ---: |
'''+'\n'.join(compile_rows(tbl))+'''

## Guarded raw tokenization

The independent matrix places each input against an unreadable page. Ten byte distributions exercise dollars in words, numbers, C and C++ literals, standard suffixes, comments, splices, raw strings and Unicode. The 90 widths cover zero through 65 and boundaries through 65,536 bytes. Correctness runs twelve flag sets and checks kinds, start offsets and end offsets. Each series passed 43,200 comparisons per seed over three seeds. Timings use the no-dollar flag, nine within-seed rounds and the median of three seed-level ratios.

| Vector design | At or below parent dispatcher | At or below forced scalar | Median / forced scalar |
| --- | ---: | ---: | ---: |
'''+'\n'.join(raw)+'''

The complete compiler improves substantially on SQLite in the explicit dialects, but several Lua and musl comparisons and many raw input sizes remain slower. The deletion is under qualification.

[Sources, commands, reach counters, frozen oracles, protected inputs and native process logs](dollar-punctuation-native.tar.xz)
'''
(d/'README.md').write_text(doc)
with tarfile.open(d/'dollar-punctuation-native.tar.xz','w:xz',preset=2)as t:
 for n in ['candidate.py','shared-tables.py','flat.py','flat.inc','census.py','census.patch','matrix.py','entry.c','matrix.c','flat-matrix.c','table-matrix.c','gate','flat-gate','table-gate','corpus','build-census','build-vector','build-shipping','shipping.patch','vector.patch','vector-corpus','vector-real','clang-dollars.cpp','check-dollars.inc','dense.c','record.py','fault-check.c','faults.py','check-faults']:
  t.add(p/n,'source/'+n)
 for f in r.iterdir():
  if not f.name.startswith(('once-','common-')):t.add(f,'native/'+f.name)
print(*compile_rows(tbl),*raw,sep='\n')
