from pathlib import Path
p=Path(__file__).parent;s=(p/'tree/src/buster/compiler/c_lexer.c').read_text()
variants=[('control',s),('word',s.replace('properties = _mm512_mask_mov_epi8(properties, _mm512_cmpeq_epi8_mask(raw, splat8(\'$\')), _mm512_setzero_si512());','(void)properties;')),('suffix',s.replace(" || (c == '$' && no_dollars)","")),('whole',s.replace('return cplusplus_mode || (flags & C_TOKENIZER_KEEP_COMMENTS)','return cplusplus_mode || (flags & (C_TOKENIZER_KEEP_COMMENTS | C_TOKENIZER_NO_DOLLARS))'))]
x=s.index('        if (no_dollars)',s.index('BUSTER_INLINE OutputCursors write_chunk('));y=s.index('\n        }',x)+10;variants.append(('kind',s[:x]+s[y:]))
for name,t in variants:
 assert name=='control' or s!=t
 d=p/'faults'/name/'buster/compiler/c_lexer.c';d.parent.mkdir(exist_ok=True,parents=True);d.write_text(t)
