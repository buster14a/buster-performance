#define FOO 37
FOO $FOO x$FOO 1$FOO $$$ x$1.5 $L"x" $u8'y' $
"FOO$FOO" /* $FOO */ FOO
x$FO\
O 1$0x1p-2
