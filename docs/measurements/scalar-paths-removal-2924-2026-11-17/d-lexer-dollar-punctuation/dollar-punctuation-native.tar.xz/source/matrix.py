from pathlib import Path
import re,shutil
p=Path(__file__).parent;prefix=Path('/tmp/buster-lexer-prefixes')
n=(prefix/'compare.c').read_text()
a=n.index('extern Lex ');b=n.index('static uint32_t state',a)
n=n[:a]+'''extern Lex base,vector,tables,scan,scalar;
static Lex* volatile methods[]={base,vector,tables,scan,scalar};
'''+n[b:]
a=n.index('    const char* samples[]');b=n.index('    const char* start=',a)
n=n[:a]+r'''    const char* samples[]={" ", "int foo = 5;\n", "$$ $abc x$1.5 x$1e-2\n",
      "u8\"$\"$L'x' $u8'x' 1$e-2 12$e+1\n", "\"a\"ms$xy \"b\"_x$z 'x'_w$k \"c\"sv$\n",
      "x$\\\ny 1$\\\r\n.5 $\\\nL\"x\" $L\\\n\"x\"\n", "pre$fix 2$x$y \\\n$x\n",
      "/* $ */ $ // $abc\n\"$\" '$' $foo$\n", "R\"d($)d\"$xx $u8R\"(x$)\"\n",
      "??/\n$\\u00E9 a\xc3\xa9$x 1e$+4\n"};
'''+n[b:]
n=n.replace('unsigned checks=0;', '''unsigned checks=0; const uint32_t modes[]={128,130,132,134,136,152,160,192,224,129,384,162};
    uint32_t flags=argc>2?strtoul(argv[2],NULL,0):128;''')
a=n.index('        int64_t expected=');b=n.index('        uint64_t times',a)
n=n[:a]+'''        for(unsigned mode=0;mode<sizeof(modes)/sizeof(modes[0]);mode++){
            uint32_t f=modes[mode];
            int64_t result=methods[4](p,n,k[4],a[4],b[4],f);
            if(result<0||result>n)return 4;
            for(unsigned j=0;j<4;j++){
                int64_t got=methods[j](p,n,k[j],a[j],b[j],f);
                if(got!=result||memcmp(k[j],k[4],result)||memcmp(a[j],a[4],result*4)||memcmp(b[j],b[4],result*4)){
                    fprintf(stderr,"mismatch size=%u shape=%u flags=%u method=%u got=%ld oracle=%ld\\n",n,shape,f,j,got,result);return 5;
                }
                checks++;
            }
        }
        const int64_t expected=methods[4](p,n,k[4],a[4],b[4],flags);
'''+n[b:]
n=n.replace('fn(p,n,k[j],a[j],b[j],0)','fn(p,n,k[j],a[j],b[j],flags)')
(p/'matrix.c').write_text(n);shutil.copy(prefix/'entry.c',p/'entry.c')
s=(p/'tree/src/buster/compiler/c_lexer.c').read_text()
def version(tag,s):
 d=p/tag/'buster/compiler';d.mkdir(parents=True,exist_ok=True);(d/'c_lexer.c').write_text(s)
version('vector',s)
# Per-mode lookup tables select the dollar property and kind without an extra masked compare in either vector.
at=s.index('BUSTER_LEX_ALIGN(64) static const uint8_t c_char_properties[')
T=s
for name in ['c_char_properties','c_char_properties_no_separators','c_char_kinds']:
 a=T.index('BUSTER_LEX_ALIGN(64) static const uint8_t '+name+'[');b=T.index('};',a)+2
 table=T[a:b];xs=list(re.finditer(r'0x[0-9A-F]{2}',table));assert len(xs)==128 and xs[36][0]=='0x01'
 item=xs[36];t=table[:item.start()]+'0x00'+table[item.end():];t=t.replace(name+'[',name+'_dollar_punctuation[')
 T=T[:b]+'\n'+t+T[b:]
a=T.index('    __m512i properties = perm2b(separators');b=T.index('    __m512i classes',a)
T=T[:a]+'''    const uint8_t* properties_table = no_dollars ? (separators ? c_char_properties_dollar_punctuation : c_char_properties_no_separators_dollar_punctuation)
                                                 : (separators ? c_char_properties : c_char_properties_no_separators);
    __m512i properties = perm2b(properties_table, raw);
'''+T[b:]
a=T.index('        __m512i kinds = perm2b(c_char_kinds');b=T.index('        // Multi-character',a)
T=T[:a]+'''        __m512i kinds = perm2b(no_dollars ? c_char_kinds_dollar_punctuation : c_char_kinds, raw[j]);
'''+T[b:]
version('tables',T)
a=T.index('static int64_t c_tokenize_from(');a=T.index('\n{',a)+2
T=T[:a]+'''
    if ((flags & C_TOKENIZER_NO_DOLLARS) && begin < length && memchr(source + begin, '$', length - begin) == NULL)
    {
        flags &= ~C_TOKENIZER_NO_DOLLARS;
    }
'''+T[a:];version('scan',T)
g=(prefix/'gate-task').read_text().replace('buster-lexer-prefixes','buster-lexer-dollars').replace('/dev/shm/buster-unroll-6b097f86/src/src','/dev/shm/buster-native-base-cc7d4ffb-6b097f86/src').replace('lookup masks quote','vector tables scan').replace('base masks lookup quote','base vector tables scan').replace('compare.c','matrix.c').replace('compare','matrix').replace('lookup.o','vector.o').replace('masks.o','tables.o').replace('quote.o','scan.o')
g=g.replace('for name in base vector tables scan','for name in base vector tables scan').replace('base,lookup,masks,quote,scalar','base,vector,tables,scan,scalar')
(p/'gate').write_text(g)
c=(prefix/'guarded-corpus').read_text().replace('buster-lexer-prefixes','buster-lexer-dollars').replace('lexer-prefix-guarded','dollar-vector').replace('root/guarded-','root/vector-')
c=c[:c.index('for r in 1 2 3;do')]
c=c.replace('group=$1','group=$1; dialect=$2').replace('out="$root/vector-$group"','out="$root/vector-$dialect-$group"')
c=c.replace(' for side in base head;do',' case $dialect in nodollars) flags+=(-fno-dollars-in-identifiers);; asm) flags+=(-x assembler-with-cpp);; esac\n for side in base head;do')
(p/'vector-corpus').write_text(c)
j=(prefix/'guarded-real').read_text().replace('buster-lexer-prefixes','buster-lexer-dollars').replace('guarded-built','vector-built').replace('guarded-real','vector-real').replace('for group in lua sqlite musl;do bash guarded-corpus "$group";done','for dialect in nodollars asm default;do for group in lua sqlite musl;do bash vector-corpus "$group" "$dialect";done;done')
(p/'vector-real').write_text(j)
