#define _GNU_SOURCE
#include <stdio.h>
#include "buster/compiler/c_lexer.c"
typedef struct {uint8_t* kinds; uint32_t* starts; uint32_t* ends;} TokenArrays;
#include "check-dollars.inc"
int main(void)
{
    uint8_t kinds[1536];
    uint32_t starts[1536],ends[1536];
    TokenArrays tokens={kinds,starts,ends};
    return check_dollar_punctuation(&tokens)?0:1;
}
