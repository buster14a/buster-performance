from pathlib import Path
from statistics import median
import tarfile,re,sys
p=Path(__file__).parent;r=p/'results';tag=sys.argv[1]
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-lexer-dollar-punctuation')
s=(p/'record.py').read_text();exec(s[s.index('def timings('):s.index('raw=[]')])
tbl=timings(tag)
for seed in (1,133,789):assert 'dollar punctuation and literal suffix boundaries: correct' in (r/f'{tag}-lexer-{seed}.log').read_text()
s=(r/f'{tag}-preprocessor.log').read_text();assert '0 of 419 fail' in s and '0 of 240 sources differ' in s and '0 of 24 sources differ' in s and s.count('0 unverified), 0 differ')==2
heading,desc={'common':('Sharing the dialect loops','Both dollar modes share the same vector loop. The lexer first checks whether the remaining source contains a dollar byte.'),'once':('Selecting dollar punctuation once per file','The preprocessor checks for a dollar byte once at file preparation and passes that choice into every tokenization window.')}[tag]
ok=sum(x<=1 for x in tbl.values());rows=compile_rows(tbl)
f=d/'README.md';s=f.read_text();assert '## '+heading not in s
with tarfile.open(d/(tag+'-preprocessing.tar.xz'),'w:xz',preset=2)as t:
 for n in [tag+'.patch',tag+'-corpus',tag+'-corpus-resume',tag+'-real-resume','shared-tables.py' if tag=='common' else 'prepare-once.py','build-'+tag,'record-dispatch.py','record.py']:t.add(p/n,'source/'+n)
 for x in sorted(r.glob(tag+'-*')):
  if x.is_file() and x.suffix=='.log':t.add(x,'native/'+x.name)
  if x.is_dir():
   for q in x.iterdir():
    if q.name in [m+e for m in ['whole','window','default']for e in ['.log','-base.sha','-head.sha','-base.err','-head.err']]:t.add(q,'native/'+x.name+'/'+q.name)
f.write_text(s.rstrip()+'\n\n## '+heading+'\n\n'+desc+f' All 27 preprocessor output digests and diagnostic streams matched the parent. Each cell reports the median change in user cycles over five pairs of three processes per side. {ok} of the 27 measurements met the parent. Three lexer seeds and the Clang preprocessor suite passed.\n\n| Dialect | Input | Default window | Whole file | 4 KiB window |\n| --- | --- | ---: | ---: | ---: |\n'+'\n'.join(rows)+f'\n\n[Candidate, native comparisons and test outputs]({tag}-preprocessing.tar.xz)\n')
print(ok,*rows,sep='\n')
