from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
import re
p=Path(__file__).parent;f='buster/compiler/c_lexer.c';s=(p/'tables'/f).read_text()
a=s.index('// Dollar-punctuation modes share the same vector loop.');b=s.index('// The chunk loop that',a);s=s[:a]+s[b:]
a=s.index('    if (flags & C_TOKENIZER_NO_DOLLARS)',s.index('static int64_t tokenize_with_flags('));b=s.index('if (flags & C_TOKENIZER_CPLUSPLUS)',a);s=s[:a]+'    const bool no_dollars = (flags & C_TOKENIZER_NO_DOLLARS) != 0;\n    '+s[b:]
s=re.sub(r'(BUSTER_LEX_NOINLINE static int64_t tokenize_(?:c|cpp)\w*\()',r'\1bool no_dollars, ',s)
s=re.sub(r'(return tokenize_chunks\([^\n]+?), false, source,',r'\1, no_dollars, source,',s)
a=s.index('static int64_t tokenize_with_flags(');b=s.index('// The scalar lexer handles retained comments',a)
s=s[:a]+re.sub(r'(tokenize_(?:c|cpp)\w*\()',r'\1no_dollars, ',s[a:b])+s[b:]
for name in ['shared','common','byteprops']:
 t=s
 if name=='common':
  a=t.index('static int64_t c_tokenize_from(');a=t.index('\n{',a)+2
  t=t[:a]+'''
    if ((flags & C_TOKENIZER_NO_DOLLARS) && begin < length && !memchr(source + begin, '$', length - begin))
    {
        flags &= ~C_TOKENIZER_NO_DOLLARS;
    }
'''+t[a:]
 if name=='byteprops':
  # Preselect both low pages once. The upper pages are identical in both dollar modes.
  a=t.index('    const uint8_t* properties_table =');b=t.index('    __m512i classes =',a)
  t=t[:a]+'''    __m512i properties = _mm512_permutex2var_epi8(properties_low, raw, properties_high);
'''+t[b:]
  t=t.replace('const bool digraphs, const bool separators, const bool no_dollars)','const bool digraphs, const __m512i properties_low, const __m512i properties_high)')
  a=t.index('    const U64x8 zero =',t.index('BUSTER_INLINE int64_t tokenize_chunks('));t=t[:a]+'''    const uint8_t* property_table = separators ? c_char_properties : c_char_properties_no_separators;
    const __m512i properties_high = _mm512_load_si512(property_table + 64);
    const __m512i properties_low = _mm512_mask_set1_epi8(_mm512_load_si512(property_table), no_dollars ? UINT64_C(1) << '$' : 0, 0);
'''+t[a:]
  t=t.replace('cplusplus, digraphs, separators, no_dollars);','cplusplus, digraphs, properties_low, properties_high);')
 d=p/name/f;d.parent.mkdir(exist_ok=True,parents=True);d.write_text(t)
 # Production files common to the initial correct implementation. The direct C++ range oracle stays in the compiler.
 diff=[]
 for local in ['c_lexer.c','c_lexer_test.c','c_preprocessor.c','c_preprocessor_impl.c','c_preprocessor_test.c']:
  path='src/buster/compiler/'+local
  old=check_output(['git','show','HEAD:'+path],cwd=p/'tree').decode()
  new=t if local=='c_lexer.c'else(p/'tree'/path).read_text()
  diff.extend(unified_diff(old.splitlines(True),new.splitlines(True),'a/'+path,'b/'+path))
 (p/(name+'.patch')).write_text(''.join(diff))
for a,b in [('gate','table-gate'),('matrix.c','table-matrix.c')]:
 t=(p/a).read_text().replace('vector,tables,scan','shared,common,byteprops').replace('vector tables scan','shared common byteprops').replace('matrix.c','table-matrix.c').replace('dollar-matrix','dollar-table-matrix').replace('gate-','table-gate-').replace('touch gate.ok','touch table-gate.ok')
 (p/b).write_text(t)
for a,b in [('build-shipping','build-common'),('vector-real','common-real'),('vector-corpus','common-corpus')]:
 t=(p/a).read_text().replace('root/shipping.patch','root/common.patch').replace('build/dollar-shipping','build/dollar-common').replace('root/shipping-','root/common-')
 if a=='build-shipping':
  a0=t.index('previous=/dev/shm');b0=t.index('git diff --exit-code',a0)
  t=t[:a0]+'''test -f "$root/shipping-built.ok"
cd "$ir/src"
git apply -R "$root/shipping.patch"
'''+t[b0:]
 else:t=t.replace('vector-built','common-built').replace('vector-real','common-real').replace('vector-corpus','common-corpus').replace('root/vector-','root/common-').replace('build/dollar-vector','build/dollar-common')
 (p/b).write_text(t)
