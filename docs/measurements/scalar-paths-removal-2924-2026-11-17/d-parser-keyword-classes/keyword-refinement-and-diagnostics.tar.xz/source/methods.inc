// These keyword IDs occupy the lower half of a byte. ID zero and the saturated upper bound have no refinement.
_Static_assert(C_NAME_BITINT < 127 && C_NAME_EXTINT < 127 && C_NAME_BUILTIN_OFFSETOF < 127 && C_NAME_BUILTIN_VA_ARG < 127 &&
               C_NAME_BUILTIN_CONVERTVECTOR < 127 && C_NAME_BUILTIN_BIT_CAST < 127, "keyword class lookup fits 128 entries");
static const uint8_t parse_keyword_class[128] = {
    [C_NAME_BITINT] = PARSE_CLASS_BITINT_KEYWORD,
    [C_NAME_EXTINT] = PARSE_CLASS_BITINT_KEYWORD,
    [C_NAME_BUILTIN_OFFSETOF] = PARSE_CLASS_OFFSETOF_KEYWORD,
    [C_NAME_BUILTIN_VA_ARG] = PARSE_CLASS_VA_ARG_KEYWORD,
    [C_NAME_BUILTIN_CONVERTVECTOR] = PARSE_CLASS_VA_ARG_KEYWORD,
    [C_NAME_BUILTIN_BIT_CAST] = PARSE_CLASS_BIT_CAST_KEYWORD,
};

BUSTER_INLINE __m512i parser_named_dense(__m512i classes, __m512i roles, __m512i kinds, const uint32_t* names, uint64_t live)
{
    const uint64_t type = parse_equal8(kinds, PARSE_KIND_TYPEOF);
    const uint64_t rare = live & parse_equal8(roles, PARSE_ROLE_LEAF_RIGHT) & (type | parse_equal8(kinds, PARSE_KIND_TYPE_ARGUMENT));
    if (rare != 0)
    {
        const __m512i a = _mm512_maskz_loadu_epi32((__mmask16)rare, names);
        const __m512i b = _mm512_maskz_loadu_epi32((__mmask16)(rare >> 16), (const void*)((uintptr_t)names + 16 * sizeof(*names)));
        const __m512i c = _mm512_maskz_loadu_epi32((__mmask16)(rare >> 32), (const void*)((uintptr_t)names + 32 * sizeof(*names)));
        const __m512i d = _mm512_maskz_loadu_epi32((__mmask16)(rare >> 48), (const void*)((uintptr_t)names + 48 * sizeof(*names)));
        const __m512i bytes = _mm512_packus_epi16(_mm512_packs_epi32(a, b), _mm512_packs_epi32(c, d));
        const __m512i order = _mm512_setr_epi32(0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15);
        const __m512i keys = _mm512_permutexvar_epi32(order, _mm512_min_epu8(bytes, _mm512_set1_epi8(127)));
        const __m512i named = parse_table8(parse_keyword_class, keys);
        const uint64_t bitint = parse_equal8(named, PARSE_CLASS_BITINT_KEYWORD);
        const uint64_t replace = rare & ~parse_equal8(named, 0) & ~(bitint ^ type);
        classes = _mm512_mask_mov_epi8(classes, replace, named);
    }
    return classes;
}

BUSTER_INLINE __m512i parser_named_group(__m512i classes, __m512i roles, __m512i kinds, const uint32_t* names, uint64_t live)
{
    const uint64_t type = parse_equal8(kinds, PARSE_KIND_TYPEOF);
    const uint64_t rare = live & parse_equal8(roles, PARSE_ROLE_LEAF_RIGHT) & (type | parse_equal8(kinds, PARSE_KIND_TYPE_ARGUMENT));
    if (rare != 0)
    {
        uint8_t result[64] __attribute__((aligned(64)));
        _mm512_store_si512(result, classes);
        uint64_t todo = rare;
        do
        {
            const uint32_t offset = (uint32_t)__builtin_ctzll(todo) & ~15u;
            const __mmask16 lanes = (__mmask16)(todo >> offset);
            const __m512i ids = _mm512_maskz_loadu_epi32(lanes, names + offset);
            const __m128i keys = _mm_min_epu8(_mm512_cvtusepi32_epi8(ids), _mm_set1_epi8(127));
            const __m128i named = _mm512_castsi512_si128(parse_table8(parse_keyword_class, _mm512_castsi128_si512(keys)));
            const __mmask16 bitint = _mm_cmpeq_epi8_mask(named, _mm_set1_epi8(PARSE_CLASS_BITINT_KEYWORD));
            const __mmask16 replace = lanes & _mm_cmpneq_epi8_mask(named, _mm_setzero_si128()) & ~(bitint ^ (type >> offset));
            _mm_mask_storeu_epi8(result + offset, replace, named);
            todo &= ~((uint64_t)UINT16_MAX << offset);
        } while (todo != 0);
        classes = _mm512_load_si512(result);
    }
    return classes;
}

BUSTER_INLINE __m512i parser_named_compress(__m512i classes, __m512i roles, __m512i kinds, const uint32_t* names, uint64_t live)
{
    const uint64_t type = parse_equal8(kinds, PARSE_KIND_TYPEOF);
    const uint64_t rare = live & parse_equal8(roles, PARSE_ROLE_LEAF_RIGHT) & (type | parse_equal8(kinds, PARSE_KIND_TYPE_ARGUMENT));
    if (rare != 0)
    {
        uint64_t todo = rare;
        do
        {
            const uint64_t lanes = _pdep_u64(UINT16_MAX, todo);
            const __m512i byte_indices = _mm512_maskz_compress_epi8(lanes, parse_shifts.lanes8);
            const __m512i indices = _mm512_cvtepu8_epi32(_mm512_castsi512_si128(byte_indices));
            const __m512i ids = _mm512_i32gather_epi32(indices, names, sizeof(*names));
            const __m128i keys = _mm_min_epu8(_mm512_cvtusepi32_epi8(ids), _mm_set1_epi8(127));
            const __m512i named = _mm512_maskz_expand_epi8(lanes, parse_table8(parse_keyword_class, _mm512_castsi128_si512(keys)));
            const uint64_t bitint = parse_equal8(named, PARSE_CLASS_BITINT_KEYWORD);
            classes = _mm512_mask_mov_epi8(classes, lanes & ~parse_equal8(named, 0) & ~(bitint ^ type), named);
            todo ^= lanes;
        } while (todo != 0);
    }
    return classes;
}
