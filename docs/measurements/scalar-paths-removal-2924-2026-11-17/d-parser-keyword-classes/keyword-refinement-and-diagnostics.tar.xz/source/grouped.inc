BUSTER_INLINE __m512i parser_named_quarters(__m512i classes, __m512i roles, __m512i kinds, const uint32_t* names, uint64_t live)
{
    const uint64_t type_of = parse_equal8(kinds, PARSE_KIND_TYPEOF);
    const uint64_t rare = live & parse_equal8(roles, PARSE_ROLE_LEAF_RIGHT) & (type_of | parse_equal8(kinds, PARSE_KIND_TYPE_ARGUMENT));
    if (rare != 0)
    {
        uint64_t todo = rare;
        do
        {
            const uint32_t first = (uint32_t)__builtin_ctzll(todo) & ~15u;
            const uint64_t lanes = todo & ((uint64_t)UINT16_MAX << first);
            const __m512i ids = _mm512_maskz_loadu_epi32((__mmask16)(lanes >> first), names + first);
            const __m128i keys = _mm_min_epu8(_mm512_cvtusepi32_epi8(ids), _mm_set1_epi8(127));
            const __m512i named = _mm512_broadcast_i32x4(_mm512_castsi512_si128(parse_table8(parse_keyword_class, _mm512_castsi128_si512(keys))));
            const uint64_t bitint = parse_equal8(named, PARSE_CLASS_BITINT_KEYWORD);
            classes = _mm512_mask_mov_epi8(classes, lanes & ~parse_equal8(named, 0) & ~(bitint ^ type_of), named);
            todo ^= lanes;
        } while (todo != 0);
    }
    return classes;
}

BUSTER_INLINE __m512i parser_named_masks(__m512i classes, __m512i roles, __m512i kinds, const uint32_t* names, uint64_t live)
{
    const uint64_t type_of = parse_equal8(kinds, PARSE_KIND_TYPEOF);
    const uint64_t rare = live & parse_equal8(roles, PARSE_ROLE_LEAF_RIGHT) & (type_of | parse_equal8(kinds, PARSE_KIND_TYPE_ARGUMENT));
    if (rare != 0)
    {
        uint64_t todo = rare;
        do
        {
            const uint32_t first = (uint32_t)__builtin_ctzll(todo) & ~15u;
            const __mmask16 lanes = (__mmask16)(todo >> first);
            const __m512i ids = _mm512_maskz_loadu_epi32(lanes, names + first);
            const uint64_t bits = (uint64_t)(_mm512_cmpeq_epi32_mask(ids, _mm512_set1_epi32(C_NAME_BITINT)) |
                                              _mm512_cmpeq_epi32_mask(ids, _mm512_set1_epi32(C_NAME_EXTINT))) << first;
            const uint64_t va = (uint64_t)(_mm512_cmpeq_epi32_mask(ids, _mm512_set1_epi32(C_NAME_BUILTIN_VA_ARG)) |
                                            _mm512_cmpeq_epi32_mask(ids, _mm512_set1_epi32(C_NAME_BUILTIN_CONVERTVECTOR))) << first;
            const uint64_t offset = (uint64_t)_mm512_cmpeq_epi32_mask(ids, _mm512_set1_epi32(C_NAME_BUILTIN_OFFSETOF)) << first;
            const uint64_t cast = (uint64_t)_mm512_cmpeq_epi32_mask(ids, _mm512_set1_epi32(C_NAME_BUILTIN_BIT_CAST)) << first;
            classes = _mm512_mask_set1_epi8(classes, type_of & bits, PARSE_CLASS_BITINT_KEYWORD);
            classes = _mm512_mask_set1_epi8(classes, ~type_of & va, PARSE_CLASS_VA_ARG_KEYWORD);
            classes = _mm512_mask_set1_epi8(classes, ~type_of & offset, PARSE_CLASS_OFFSETOF_KEYWORD);
            classes = _mm512_mask_set1_epi8(classes, ~type_of & cast, PARSE_CLASS_BIT_CAST_KEYWORD);
            todo &= ~((uint64_t)UINT16_MAX << first);
        } while (todo != 0);
    }
    return classes;
}

BUSTER_INLINE __m512i parser_named_four(__m512i classes, __m512i roles, __m512i kinds, const uint32_t* names, uint64_t live)
{
    const uint64_t type_of = parse_equal8(kinds, PARSE_KIND_TYPEOF);
    const uint64_t rare = live & parse_equal8(roles, PARSE_ROLE_LEAF_RIGHT) & (type_of | parse_equal8(kinds, PARSE_KIND_TYPE_ARGUMENT));
    if (rare != 0)
    {
        uint64_t todo = rare;
        do
        {
            const uint32_t first = (uint32_t)__builtin_ctzll(todo) & ~3u;
            const uint64_t lanes = todo & (UINT64_C(15) << first);
            const __m128i ids = _mm_maskz_loadu_epi32((__mmask8)(lanes >> first), names + first);
            const __m128i keys = _mm_min_epu8(_mm_cvtusepi32_epi8(ids), _mm_set1_epi8(127));
            const __m512i named = _mm512_broadcastd_epi32(_mm512_castsi512_si128(parse_table8(parse_keyword_class, _mm512_castsi128_si512(keys))));
            const uint64_t bitint = parse_equal8(named, PARSE_CLASS_BITINT_KEYWORD);
            classes = _mm512_mask_mov_epi8(classes, lanes & ~parse_equal8(named, 0) & ~(bitint ^ type_of), named);
            todo ^= lanes;
        } while (todo != 0);
    }
    return classes;
}
