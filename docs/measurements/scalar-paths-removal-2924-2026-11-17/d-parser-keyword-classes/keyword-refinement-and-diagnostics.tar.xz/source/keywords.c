typedef __builtin_va_list Arguments;
struct Point { int x; int y; };
typedef int V4I __attribute__((vector_size(16)));
typedef float V4F __attribute__((vector_size(16)));
int consume(Arguments args, int x, V4F values)
{
    _BitInt(17) value = x;
    __typeof__(value) copy = value;
    V4I converted = __builtin_convertvector(values, V4I);
    return __builtin_va_arg(args, int) + __builtin_offsetof(struct Point, y) + copy + converted[0];
}
