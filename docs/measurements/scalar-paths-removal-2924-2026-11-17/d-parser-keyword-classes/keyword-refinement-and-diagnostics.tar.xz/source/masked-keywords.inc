BUSTER_INLINE __m512i parser_named_masked(__m512i classes, __m512i roles, __m512i kinds, const uint32_t* names, uint64_t live)
{
    const uint64_t type_of = parse_equal8(kinds, PARSE_KIND_TYPEOF);
    const uint64_t rare = live & parse_equal8(roles, PARSE_ROLE_LEAF_RIGHT) & (type_of | parse_equal8(kinds, PARSE_KIND_TYPE_ARGUMENT));
    if (rare != 0)
    {
        uint64_t todo = rare;
        do
        {
            // Compress up to sixteen name indices, gather their 32-bit IDs and expand the resulting byte classes.
            const uint64_t lanes = _pdep_u64(UINT16_MAX, todo);
            const __m512i byte_indices = _mm512_maskz_compress_epi8(lanes, parse_shifts.lanes8);
            const __m512i indices = _mm512_cvtepu8_epi32(_mm512_castsi512_si128(byte_indices));
            const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, (uint32_t)__builtin_popcountll(lanes));
            const __m512i ids = _mm512_mask_i32gather_epi32(_mm512_setzero_si512(), active, indices, names, sizeof(*names));
            const __m128i keys = _mm_min_epu8(_mm512_cvtusepi32_epi8(ids), _mm_set1_epi8(127));
            const __m512i named = _mm512_maskz_expand_epi8(lanes, parse_table8(parse_keyword_class, _mm512_castsi128_si512(keys)));
            const uint64_t bitint = parse_equal8(named, PARSE_CLASS_BITINT_KEYWORD);
            classes = _mm512_mask_mov_epi8(classes, lanes & ~parse_equal8(named, 0) & ~(bitint ^ type_of), named);
            todo ^= lanes;
        } while (todo != 0);
    }
    return classes;
}
