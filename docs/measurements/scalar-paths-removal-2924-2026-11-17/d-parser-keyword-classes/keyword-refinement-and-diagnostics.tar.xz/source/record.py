from pathlib import Path
from statistics import median
import re,tarfile
p=Path(__file__).parent;r=p/'results'
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-keyword-classes');d.mkdir(exist_ok=True)
counts=[]
for name,labels in [('native',['Pack all active quarters','Store each quarter','Compress indices and gather']),('fair',['Compress indices and gather','Mask the index gather']),('grouped',['Broadcast quarter classes','Apply per-class masks','Group four identifiers'])]:
    table={}
    for seed in (1,133,789):
        for line in (r/f'{name}-{seed}.tsv').read_text().splitlines():
            n,shape,base,*v=map(int,line.split());assert len(v)==len(labels) and min(base,*v)>0
            table.setdefault((n,shape),[]).append([h/base for h in v])
    assert len(table)==585 and all(len(v)==3 for v in table.values())
    assert '108160 independent guarded keyword fixtures' in (r/('guarded.log' if name=='native' else name+'-guarded.log')).read_text()
    for j,label in enumerate(labels):
        vs=[median(v[j]for v in rr)for rr in table.values()]
        counts.append('| '+' | '.join([('Reconstruct role inputs' if name=='native' else 'Use existing role inputs'),label,f'{sum(x<=1 for x in vs)}/585',f'{median(vs):.4f}',f'{max(vs):.4f}'])+' |')
corpus=[]
for g,n in [('lua',34),('sqlite',1),('musl',1336)]:
    census=[v.split('\t')for v in (r/f'{g}-census.log').read_text().splitlines()if v.startswith('census\t')];assert len(census)==n
    sums=[sum(v) for v in zip(*[list(map(int,line[2:]))for line in census])]
    tokens,ty,arg,refined,*hist=sums;assert len(hist)==65 and sum(i*v for i,v in enumerate(hist))==ty+arg
    br=[];hr=[]
    prefix=r/f'corpus-{g}';groups=list(prefix.glob('*-1-base.log'))
    for i in range(1,4):
        b=h=0;total=0
        for z in groups:
            key=z.name.split('-')[0]
            data=[(prefix/f'{key}-{i}-{side}.log').read_text()for side in ('base','head')]
            matches=[re.search(r'7 interleaved passes over (\d+) files?, (\d+) tokens,',x) for x in data]
            assert all(matches) and matches[0].groups()==matches[1].groups()
            units,t=map(int,matches[0].groups());total+=units
            vals=[float(re.search(r'^\s*vector-k6\s+[^\n]*?\s([0-9.]+) cycles/token',x,re.M)[1])for x in data]
            b+=t*vals[0];h+=t*vals[1]
        assert total==n;br.append(b);hr.append(h)
    ratio=median(h/b for b,h in zip(br,hr))
    corpus.append('| '+' | '.join(map(str,[g,n,tokens,ty,arg,refined,hist[1],sum(hist[2:]),f'{(ratio-1)*100:+.3f}%']))+' |')
diag=r/'diagnostic-results';files=list(diag.glob('*.clang'));assert len(files)==15
old=0
for f in files:
    a,b,c=[re.search(r'^.*?:(\d+:\d+): error: (.*)$',k.read_text(),re.M).groups()for k in (f,f.with_suffix('.parent'),f.with_suffix('.fixed'))];assert a==c;old+=a!=b
assert old==6
assert (r/'keyword-mutations.outcome').read_bytes()==(r/'keyword-parent-mutations.outcome').read_bytes()
assert '3 mismatches' in (r/'keyword-mutations.outcome').read_text()
assert (r/'diagnostic-delivery-mutations.log').read_text().rstrip().endswith('test-parser: passed') and '0 mismatches' in (r/'diagnostic-delivery-mutations.log').read_text()
assert (r/'diagnostic-delivery-oracle.log').read_text().rstrip().endswith('test-parser: passed')
archive='keyword-refinement-and-diagnostics.tar.xz'
with tarfile.open(d/archive,'w:xz')as t:
    for f in r.rglob('*'):
        if f.is_file()and not f.name.startswith('sparse-'):t.add(f,arcname='native/'+str(f.relative_to(r)))
    for n in ['production.patch','census-src','census.c','census-task','run-census','gate.c','fair.c','grouped.c','methods.inc','masked-keywords.inc','grouped.inc','task','fair-task','grouped-task','parser-corpus','diagnostic-final.patch','diagnostic-compare','diagnostic-inputs','keywords.c','compare-mutations','record.py']:t.add(p/n,arcname='source/'+n)
(d/'README.md').write_text('''# Name-dependent K6 parser classes on the Ryzen 7 9700X

The original K6 block refines individual type and builtin tokens by name. The census counts each block when the normal parser reaches this check. The candidate compresses up to sixteen active token positions, gathers full 32-bit identifiers, looks up a byte class, then expands classes at the original positions. It retains the coarse class for unrelated names, mismatched grammar kinds and roles other than a right-hand leaf. Independently specified cases at a guard page checked 108,160 placements including high identifier IDs.

| Corpus | Files | Tokens | Typeof lanes | Type argument lanes | Classes changed | Blocks with one rare lane | Blocks with at least two | Candidate K6 cycles |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(corpus)+'''

K6 cycles use the median of three paired rounds of the production benchmark. Each round times seven passes per input. For a corpus split into groups of files, the rates are weighted by the number of tokens before calculating the paired ratio.

The first isolated harness reconstructed the role table and spilled input vectors inside its baseline wrapper. The production caller already has those inputs. The second and third harnesses pass them to the baseline, which exposes the cost of gathering sparse keywords. Cells cover 65 live lengths and nine densities, using the median paired ratio across three rotated seeds.

| Baseline setup | Method | Cells meeting baseline | Median ratio | Slowest ratio |
| --- | --- | ---: | ---: | ---: |
'''+ '\n'.join(counts)+'''

A separate parser diagnostic surfaced in 120 mutations. The original and vector-refinement compilers had the same three mismatches. The standalone repair for the missing opening parenthesis after `_BitInt` and `_ExtInt` matched the first Clang error and its location on all 15 controls, including six where the original differed. Repeating the 120 mutations with the repair produced zero mismatches. Its final native suite passed 557 Clang snippets, 2,000 generated streams, 35,648 alignment inputs and 320 driver runs, including the fixed carets.

[Source changes, raw cycle samples, Clang results and production parser receipts]('''+archive+')\n')
print(*corpus,*counts,sep='\n')
