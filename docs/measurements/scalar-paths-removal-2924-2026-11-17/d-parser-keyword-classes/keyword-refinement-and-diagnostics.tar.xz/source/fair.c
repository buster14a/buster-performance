#include "buster/compiler/test_paths.h"
#include "buster/compiler/c_parser_benchmark.c"
#include "methods.inc"
#include "masked-keywords.inc"
#include <x86intrin.h>
_Thread_local char oracle_temporary_buffer[BUSTER_TEST_TEMPORARY_BYTES];
typedef __m512i Refine(__m512i,__m512i,__m512i,__m512i,const uint8_t*,const uint8_t*,const uint8_t*,const uint32_t*,uint64_t);
static __attribute__((noinline)) __m512i previous(__m512i classes,__m512i role,__m512i kinds,__m512i role_bits,const uint8_t*rs,const uint8_t*ks,const uint8_t*typed,const uint32_t*names,uint64_t live)
{
    uint8_t rows[64] __attribute__((aligned(64)));
    _mm512_store_si512(rows,classes);
    uint64_t rare=_mm512_test_epi8_mask(role_bits,_mm512_set1_epi8(BUSTER_PARSE_CHECK_RARE))&live&
        (parse_equal8(kinds,PARSE_KIND_TYPE_ARGUMENT)|parse_equal8(kinds,PARSE_KIND_TYPEOF));
    while(rare){
        unsigned i=__builtin_ctzll(rare);rare&=rare-1;
        rows[i]=parse_check_class(rs[i],ks[i],names[i],typed[i]!=0);
    }
    return _mm512_load_si512(rows);
}
#define WRAPPER(name) static __attribute__((noinline)) __m512i name(__m512i classes,__m512i role,__m512i kinds,__m512i role_bits,const uint8_t*rs,const uint8_t*ks,const uint8_t*typed,const uint32_t*names,uint64_t live){return parser_named_##name(classes,role,kinds,names,live);}
WRAPPER(compress)
WRAPPER(masked)
static Refine*volatile methods[]={previous,compress,masked};
static const uint8_t typed[64];
static uint32_t rng;
static uint32_t step(void){rng=rng*1664525u+1013904223u;return rng;}
static uint64_t stamp(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int cmp(const void*a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return (x>y)-(x<y);}
static const uint32_t named[]={C_NAME_BITINT,C_NAME_EXTINT,C_NAME_BUILTIN_OFFSETOF,C_NAME_BUILTIN_VA_ARG,C_NAME_BUILTIN_CONVERTVECTOR,C_NAME_BUILTIN_BIT_CAST,0,126,127,128,UINT32_MAX,0x80000000u+C_NAME_BITINT,256+C_NAME_BUILTIN_VA_ARG};
static uint8_t wanted(uint32_t id,uint8_t kind,uint8_t role,uint8_t coarse){
    if(role!=PARSE_ROLE_LEAF_RIGHT)return coarse;
    if(kind==PARSE_KIND_TYPEOF && (id==C_NAME_BITINT||id==C_NAME_EXTINT))return PARSE_CLASS_BITINT_KEYWORD;
    if(kind==PARSE_KIND_TYPE_ARGUMENT){
        if(id==C_NAME_BUILTIN_OFFSETOF)return PARSE_CLASS_OFFSETOF_KEYWORD;
        if(id==C_NAME_BUILTIN_CONVERTVECTOR||id==C_NAME_BUILTIN_VA_ARG)return PARSE_CLASS_VA_ARG_KEYWORD;
        if(id==C_NAME_BUILTIN_BIT_CAST)return PARSE_CLASS_BIT_CAST_KEYWORD;
    }
    return coarse;
}
static int guards(uint32_t*end){
    unsigned cases=0;
    for(unsigned n=1;n<=64;n++)for(unsigned at=0;at<n;at++)for(unsigned shape=0;shape<4;shape++)for(unsigned id=0;id<BUSTER_ARRAY_LENGTH(named);id++){
        uint8_t ks[64],rs[64],cs[64],expect[64];
        memset(ks,PARSE_KIND_IDENTIFIER,64);memset(rs,PARSE_ROLE_OPERAND,64);
        uint32_t*names=end-n;memset(names,0,n*sizeof(*names));
        ks[at]=shape&1?PARSE_KIND_TYPEOF:PARSE_KIND_TYPE_ARGUMENT;rs[at]=shape&2?PARSE_ROLE_CLOSE_SPECIFIER:PARSE_ROLE_LEAF_RIGHT;
        names[at]=named[id];
        __m512i k=_mm512_loadu_si512(ks),r=_mm512_loadu_si512(rs);
        __m512i coarse=parse_check_classes_avx512(r,k,parse_table8(parse_check_vector.role_bits,r),0);
        _mm512_storeu_si512(cs,coarse);
        memcpy(expect,cs,64);expect[at]=wanted(names[at],ks[at],rs[at],cs[at]);
        for(unsigned i=0;i<3;i++)if(_mm512_cmpneq_epi8_mask(methods[i](coarse,r,k,parse_table8(parse_check_vector.role_bits,r),rs,ks,typed,names,_bzhi_u64(UINT64_MAX,n)),_mm512_loadu_si512(expect))){
            fprintf(stderr,"mismatch method=%u width=%u lane=%u shape=%u id=%u\n",i,n,at,shape,names[at]);return 1;
        }
        cases++;
    }
    fprintf(stderr,"validated %u independent guarded keyword fixtures\n",cases);return 0;
}
int main(int argc,char**argv){
    if(argc!=2)return 2;
    parse_tables_initialize();
    size_t page=sysconf(_SC_PAGESIZE);char*map=mmap(0,page*2,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(map==MAP_FAILED||mprotect(map+page,page,PROT_NONE))return 2;
    uint32_t*end=(uint32_t*)(map+page);
    if(!strcmp(argv[1],"verify"))return guards(end);
    rng=atoi(argv[1]);
    for(unsigned n=0;n<=64;n++)for(unsigned shape=0;shape<9;shape++){
        uint32_t*names=end-n;uint8_t ks[64],rs[64];memset(ks,PARSE_KIND_IDENTIFIER,64);memset(rs,PARSE_ROLE_OPERAND,64);
        static const unsigned strides[]={0,255,32,16,8,4,2,1,1};
        unsigned step_by=strides[shape];
        for(unsigned l=0;l<n;l++){
            unsigned id=step()%BUSTER_ARRAY_LENGTH(named);
            names[l]=named[id];
            if(step_by && (shape==1?l==n/2:l%step_by==0)){
                ks[l]=(step()>>24)&1?PARSE_KIND_TYPEOF:PARSE_KIND_TYPE_ARGUMENT;
                rs[l]=shape==8?PARSE_ROLE_CLOSE_SPECIFIER:PARSE_ROLE_LEAF_RIGHT;
            }
        }
        __m512i k=_mm512_loadu_si512(ks),r=_mm512_loadu_si512(rs);
        __m512i c=parse_check_classes_avx512(r,k,parse_table8(parse_check_vector.role_bits,r),0);
        uint64_t live=_bzhi_u64(UINT64_MAX,n),times[3][11];const __m512i role_bits=parse_table8(parse_check_vector.role_bits,r);__m512i expect=previous(c,r,k,role_bits,rs,ks,typed,names,live);
        for(unsigned round=0;round<11;round++){
            unsigned first=step()%3;
            for(unsigned j=0;j<3;j++){unsigned m=(first+(round&1?j:3-j))%3;Refine*fn=methods[m];uint64_t before=stamp();__m512i v=c;
                for(unsigned iter=0;iter<768;iter++){v=fn(c,r,k,role_bits,rs,ks,typed,names,live);__asm__ volatile(""::"v"(v):"memory");}
                times[m][round]=stamp()-before;if(_mm512_cmpneq_epi8_mask(v,expect))return 1;
            }
        }
        printf("%u %u",n,shape);for(unsigned m=0;m<3;m++){qsort(times[m],11,sizeof(uint64_t),cmp);printf(" %llu",(unsigned long long)times[m][5]);}puts("");
    }
    fputs("validated all 65 live lengths and nine keyword densities\n",stderr);return 0;
}
