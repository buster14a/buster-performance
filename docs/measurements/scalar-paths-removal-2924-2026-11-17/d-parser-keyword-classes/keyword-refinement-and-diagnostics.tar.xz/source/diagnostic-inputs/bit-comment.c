_BitInt /* ignored */ value;
