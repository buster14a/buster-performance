_BitInt
value;
