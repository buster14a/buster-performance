int f(void) { return __builtin_available
value; }
