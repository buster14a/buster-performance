int f(void) { return __builtin_available /* ignored */ value; }
