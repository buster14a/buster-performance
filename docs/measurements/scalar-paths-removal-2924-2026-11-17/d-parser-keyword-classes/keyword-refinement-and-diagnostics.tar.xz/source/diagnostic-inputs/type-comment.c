typeof /* ignored */ value;
