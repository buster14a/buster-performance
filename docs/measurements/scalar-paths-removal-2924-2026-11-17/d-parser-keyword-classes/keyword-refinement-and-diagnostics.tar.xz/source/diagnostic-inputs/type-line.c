typeof
value;
