_ExtInt value;
