__typeof__
value;
