__typeof__ /* ignored */ value;
