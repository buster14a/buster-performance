from pathlib import Path
import shutil
p=Path(__file__).parent
src=(p/'marks/head.c').read_text()
for name in ('split','clear','binary'):
 d=p/name;d.mkdir(exist_ok=True)
 for f in ('baseline.c','types.h','gate.c'):shutil.copyfile(p/'counted'/f,d/f)
 s=src
 if name=='binary':
  s=(p/'counted/head.c').read_text().replace('uint64_t total = 0;', 'bool any = false;')
  s=s.replace('if (total == 0)','if (!any)').replace('                    memset(out, 0, words * sizeof(*out));','                    memset(out, 0, words * sizeof(*out));\n                    any = true;')
  s=s.replace('                total += (previous & bit) == 0;\n','')
  s=s.replace('    return total;','''    uint64_t total = 0;
    for (uint32_t i = 0; any && i < words; i += 16)
    {
        const uint32_t left = words - i;
        const __mmask16 live = (__mmask16)_bzhi_u32(UINT16_MAX, left < 16 ? left : 16);
        const __m512i bits = _mm512_maskz_loadu_epi32(live, out + i);
        total += (uint32_t)_mm512_reduce_add_epi32(_mm512_popcnt_epi32(bits));
    }
    return total;''')
 else:
  s=s.replace('    memset(marked, 0, symbol_count);', '''    uint8_t* called = marked + symbol_count;
    bool any = false;''')
  a=s.index('        while (hits != 0)')
  s=s[:a]+'''        if (hits != 0 && !any)
        {
            memset(marked, 0, (size_t)symbol_count * 2);
            any = true;
        }
'''+s[a:]
  s=s.replace('            marked[t] |= call ? 1u : 2u;','''            uint8_t* const column = call ? called : marked;
            column[t] = 0xff;''')
  s=s.replace('first < symbol_count; first += 64','any && first < symbol_count; first += 64')
  s=s.replace('        const __m512i mark =','        const __m512i calls = _mm512_maskz_loadu_epi8(live, called + first);\n        const __m512i mark =')
  s=s.replace('_mm512_test_epi8_mask(mark,_mm512_set1_epi8(2)) | (~function & _mm512_test_epi8_mask(mark,_mm512_set1_epi8(1)))','_mm512_movepi8_mask(mark) | (~function & _mm512_movepi8_mask(calls))')
  if name=='clear':
   # Non-call fixups need the same one-byte mark as calls if the target is data.
   a=s.index('            uint8_t* const column =');b=s.index('            hits &=',a)
   s=s[:a]+'''            if (!call || (l->symbols.flags[t] & BUSTER_LINK_SYMBOL_TYPE) != BUSTER_LINK_SYMBOL_FUNCTION)
            {
                marked[t] = 0xff;
            }
'''+s[b:]
   s=s.replace('    uint8_t* called = marked + symbol_count;\n','').replace('(size_t)symbol_count * 2','symbol_count')
   a=s.index('        const __m512i flags =');b=s.index('        memcpy(out',a)
   s=s[:a]+'''        const __m512i mark = _mm512_maskz_loadu_epi8(live, marked + first);
        const __mmask64 bits = imported & _mm512_movepi8_mask(mark);
'''+s[b:]
 (d/'head.c').write_text(s)
