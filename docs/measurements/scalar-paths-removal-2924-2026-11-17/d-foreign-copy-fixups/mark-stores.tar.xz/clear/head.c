#include "types.h"
// The per-symbol source and type are final before copy-relocation discovery.
uint64_t head(const Link* l,uint32_t* unused,uint32_t* out,unsigned path)
{
    (void)path;
    if (!l->symbols.has_imports || l->fixups.count <= 1)
    {
        return 0;
    }
    const uint32_t symbol_count = l->symbols.count;
    uint8_t *marked = (uint8_t*)unused;
    bool any = false;
    const LinkFixups* f = &l->fixups;
    const uintptr_t base = (uintptr_t)f->kind;
    const uintptr_t start = base + 1;
    const uintptr_t end = base + f->count;
    const __m512i lookup = _mm512_broadcast_i32x4(_mm_setr_epi8(0,-1,0,0,0,-1,0,0,0,-1,-1,-1,0,0,0,0));
    for (uintptr_t addr = start & ~(uintptr_t)63; addr < end; addr += 64)
    {
        const uintptr_t left = end - addr;
        const __mmask64 high = _bzhi_u64(UINT64_MAX, left < 64 ? (unsigned)left : 64);
        const __mmask64 live = addr < start ? high & (UINT64_MAX << (start - addr)) : high;
        const __m512i raw = _mm512_maskz_loadu_epi8(live, (const void*)addr);
        const __m512i kind = _mm512_and_si512(raw, _mm512_set1_epi8(BUSTER_LINK_FIXUP_KIND));
        const __mmask64 known = _mm512_cmplt_epu8_mask(kind, _mm512_set1_epi8(16));
        uint64_t hits = known & _mm512_movepi8_mask(_mm512_shuffle_epi8(lookup, kind));
        if (hits != 0 && !any)
        {
            memset(marked, 0, symbol_count);
            any = true;
        }
        while (hits != 0)
        {
            const uint32_t i = (uint32_t)(addr + (unsigned)__builtin_ctzll(hits) - base);
            const uint32_t t = f->target[i];
            const bool call = (f->kind[i] & BUSTER_LINK_FIXUP_KIND) == BUSTER_LINK_FIXUP_CALL;
            if (!call || (l->symbols.flags[t] & BUSTER_LINK_SYMBOL_TYPE) != BUSTER_LINK_SYMBOL_FUNCTION)
            {
                marked[t] = 0xff;
            }
            hits &= hits - 1;
        }
    }
    uint64_t total = 0;
    for (uint64_t first = 0; any && first < symbol_count; first += 64)
    {
        const uint32_t left = symbol_count - (uint32_t)first;
        const __mmask64 live = _bzhi_u64(UINT64_MAX, left < 64 ? left : 64);
        const __m512i source = _mm512_maskz_loadu_epi8(live, l->symbols.source + first);
        const __mmask64 imported = _mm512_cmpeq_epi8_mask(source, _mm512_set1_epi8(BUSTER_LINK_SOURCE_FOREIGN_SHARED));
        const __m512i mark = _mm512_maskz_loadu_epi8(live, marked + first);
        const __mmask64 bits = imported & _mm512_movepi8_mask(mark);
        memcpy(out + first/32, &bits, 8);
        total += __builtin_popcountll(bits);
    }
    return total;
}
