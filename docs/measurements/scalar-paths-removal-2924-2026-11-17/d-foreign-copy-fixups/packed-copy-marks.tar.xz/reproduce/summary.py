from statistics import median
from pathlib import Path
import sys
def ratios(p,layout):
 r=[[] for _ in range(5)]
 for rows in zip(*((p/f'{layout}-{k}.tsv').read_text().splitlines() for k in (1,2,3)),strict=True):
  x=[list(map(int,s.split())) for s in rows];shape,n=x[0][:2];r[shape].append((n,median(z[5]/z[3] for z in x),median(z[5]/z[4] for z in x)))
 return r
if __name__=='__main__':
 for layout in ('guarded','aligned'):
  print(layout)
  for name,g in zip(('empty','mixed','all','repeated','indirect'),ratios(Path(sys.argv[1]),layout)):
   print(name,[(sum(u[i]<=1 for u in g),round(median(u[i] for u in g),3)) for i in (1,2)],[(n,round(a,2)) for n,a,b in g if n in (1,7,16,64,8192)])
