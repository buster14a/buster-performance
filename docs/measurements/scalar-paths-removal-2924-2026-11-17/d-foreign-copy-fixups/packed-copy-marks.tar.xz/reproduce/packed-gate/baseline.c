#include "types.h"
#define BUSTER_FOREIGN_LINK_DIRECT_KINDS                                                                                                                \
    ((1u << BUSTER_LINK_FIXUP_PC32) | (1u << BUSTER_LINK_FIXUP_PC64) | (1u << BUSTER_LINK_FIXUP_ABS32) | (1u << BUSTER_LINK_FIXUP_ABS32S) |         \
     (1u << BUSTER_LINK_FIXUP_CALL))

static bool foreign_link_bit32(const uint32_t* bits, uint32_t index)
{
    return (bits[index / 32] >> (index % 32) & 1) != 0;
}

// Whether a fixup of `kind` (without the wide flag) to an import needs a copy of it: a kind that reaches a library's
// symbol neither through the GOT nor by an ABS64 nor, for a function, by a call (link_check_target's rule).
static bool foreign_link_needs_copy(const Link* link, uint8_t kind, SymbolId target)
{
    const bool function = (link->symbols.flags[target] & BUSTER_LINK_SYMBOL_TYPE) == BUSTER_LINK_SYMBOL_FUNCTION;
    return (BUSTER_FOREIGN_LINK_DIRECT_KINDS >> kind & 1) != 0 && !(kind == BUSTER_LINK_FIXUP_CALL && function);
}

static void foreign_link_mark_copies(const Link* link, const uint32_t* imports, uint32_t* copied, ForeignPath path)
{
    const LinkFixups* fixups = &link->fixups;
    FixupId first = 1;
    if (path == FOREIGN_PATH_VECTOR)
    {
        const __m512i direct = _mm512_set1_epi32((int)BUSTER_FOREIGN_LINK_DIRECT_KINDS);
        for (; first + 16 <= fixups->count; first += 16)
        {
            const __m512i kinds = _mm512_and_si512(_mm512_cvtepu8_epi32(_mm_loadu_si128((const __m128i*)(fixups->kind + first))), _mm512_set1_epi32(BUSTER_LINK_FIXUP_KIND));
            const __mmask16 candidates = _mm512_test_epi32_mask(_mm512_srlv_epi32(direct, kinds), _mm512_set1_epi32(1));
            if (candidates != 0)
            {
                const __m512i targets = _mm512_loadu_si512(fixups->target + first);
                const __m512i words = _mm512_mask_i32gather_epi32(_mm512_setzero_si512(), candidates, _mm512_srli_epi32(targets, 5), imports, 4);
                const __m512i bits = _mm512_srlv_epi32(words, _mm512_and_si512(targets, _mm512_set1_epi32(31)));
                for (uint32_t hits = _mm512_mask_test_epi32_mask(candidates, bits, _mm512_set1_epi32(1)); hits != 0; hits &= hits - 1)
                {
                    const FixupId fixup = first + (FixupId)__builtin_ctz(hits);
                    const SymbolId target = fixups->target[fixup];
                    copied[target / 32] |= foreign_link_needs_copy(link, fixups->kind[fixup] & BUSTER_LINK_FIXUP_KIND, target) ? 1u << (target % 32) : 0;
                }
            }
        }
    }
    for (; first < fixups->count; first += 1)
    {
        const SymbolId target = fixups->target[first];
        const bool copy = foreign_link_bit32(imports, target) && foreign_link_needs_copy(link, fixups->kind[first] & BUSTER_LINK_FIXUP_KIND, target);
        copied[target / 32] |= copy ? 1u << (target % 32) : 0;
    }
}


static uint64_t foreign_link_imports(const Link* link, uint32_t* imports, ForeignPath path)
{
    const LinkSymbols* symbols = &link->symbols;
    uint64_t total = 0;
    for (uint32_t first = 0; first < symbols->count; first += 64)
    {
        const uint32_t n = symbols->count - first < 64 ? symbols->count - first : 64;
        uint64_t mask = 0;
        if (path == FOREIGN_PATH_VECTOR)
        {
            const __mmask64 lanes = _bzhi_u64(~0ull, n);
            mask = _mm512_mask_cmpeq_epi8_mask(lanes, _mm512_maskz_loadu_epi8(lanes, symbols->source + first), _mm512_set1_epi8(BUSTER_LINK_SOURCE_FOREIGN_SHARED));
        }
        else
        {
            for (uint32_t i = 0; i < n; i += 1)
            {
                mask |= (uint64_t)(symbols->source[first + i] == BUSTER_LINK_SOURCE_FOREIGN_SHARED) << i;
            }
        }
        imports[first / 32] = (uint32_t)mask;
        imports[first / 32 + 1] = (uint32_t)(mask >> 32);
        total += (uint64_t)__builtin_popcountll(mask);
    }
    return total;
}

uint64_t baseline(const Link* l,uint32_t* imports,uint32_t* out,unsigned path)
{
    uint64_t total = 0;
    const uint32_t words = 2 * ((l->symbols.count + 63) / 64);
    if (foreign_link_imports(l, imports, path) != 0)
    {
        memset(out, 0, words * sizeof(*out));
        foreign_link_mark_copies(l,imports,out,path);
        for (uint32_t w = 0; w < words; ++w) total += __builtin_popcount(out[w]);
    }
    return total;
}
