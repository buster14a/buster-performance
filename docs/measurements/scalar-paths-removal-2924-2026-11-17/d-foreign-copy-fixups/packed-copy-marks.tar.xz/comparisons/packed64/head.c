#include "types.h"
static uint64_t foreign_link_mark_copies(const Link* link, uint8_t* marked, uint32_t* copied)
{
    if (link->fixups.count <= 1)
    {
        return 0;
    }
    (void)marked;
    const uint32_t symbol_count = link->symbols.count;
    bool expanded = false;
    uint64_t word_bits = 0;
    const LinkFixups* fixups = &link->fixups;
    const uintptr_t base = (uintptr_t)fixups->kind;
    const uintptr_t start = base + 1;
    const uintptr_t end = base + fixups->count;
    static const uint8_t direct[16] = {
        [BUSTER_LINK_FIXUP_CALL] = 0x80, [BUSTER_LINK_FIXUP_PC32] = 0x80, [BUSTER_LINK_FIXUP_PC64] = 0x80,
        [BUSTER_LINK_FIXUP_ABS32] = 0x80, [BUSTER_LINK_FIXUP_ABS32S] = 0x80,
    };
    const __m512i lookup = _mm512_broadcast_i32x4(_mm_loadu_si128((const __m128i*)direct));
    for (uintptr_t addr = start & ~(uintptr_t)63; addr < end; addr += 64)
    {
        const uintptr_t left = end - addr;
        const __mmask64 high = _bzhi_u64(UINT64_MAX, left < 64 ? (unsigned)left : 64);
        const __mmask64 live = addr < start ? high & (UINT64_MAX << (start - addr)) : high;
        const __m512i raw = _mm512_maskz_loadu_epi8(live, (const void*)addr);
        const __m512i kind = _mm512_and_si512(raw, _mm512_set1_epi8(BUSTER_LINK_FIXUP_KIND));
        const __mmask64 known = _mm512_cmplt_epu8_mask(kind, _mm512_set1_epi8(16));
        uint64_t hits = known & _mm512_movepi8_mask(_mm512_shuffle_epi8(lookup, kind));
        if (!expanded)
        {
            while (hits != 0)
            {
                const FixupId i = (FixupId)(addr + (unsigned)__builtin_ctzll(hits) - base);
                const SymbolId target = fixups->target[i];
                if (target >= 64)
                {
                    // A reference outside the first bitmap word needs per-symbol marks.
                    // Publish the targets already seen before continuing with the same fixup.
                    memset(copied, 0, 2 * (((uint64_t)symbol_count + 63) / 64) * sizeof(*copied));
                    memcpy(copied, &word_bits, sizeof(word_bits));
                    expanded = true;
                    break;
                }
                const bool call = (fixups->kind[i] & BUSTER_LINK_FIXUP_KIND) == BUSTER_LINK_FIXUP_CALL;
                if (!call || (link->symbols.flags[target] & BUSTER_LINK_SYMBOL_TYPE) != BUSTER_LINK_SYMBOL_FUNCTION)
                {
                    word_bits |= UINT64_C(1) << target;
                }
                hits &= hits - 1;
            }
        }
        if (hits != 0 && _mm512_mask_cmpeq_epi8_mask(hits, kind, _mm512_set1_epi8(BUSTER_LINK_FIXUP_CALL)) == 0)
        {
            for (; hits != 0; hits &= hits - 1)
            {
                const FixupId i = (FixupId)(addr + (unsigned)__builtin_ctzll(hits) - base);
                const SymbolId target = fixups->target[i];
                ((uint64_t*)copied)[target / 64] |= UINT64_C(1) << (target % 64);
            }
        }
        while (hits != 0)
        {
            const FixupId i = (FixupId)(addr + (unsigned)__builtin_ctzll(hits) - base);
            const SymbolId target = fixups->target[i];
            const bool call = (fixups->kind[i] & BUSTER_LINK_FIXUP_KIND) == BUSTER_LINK_FIXUP_CALL;
            if (!call || (link->symbols.flags[target] & BUSTER_LINK_SYMBOL_TYPE) != BUSTER_LINK_SYMBOL_FUNCTION)
            {
                ((uint64_t*)copied)[target / 64] |= UINT64_C(1) << (target % 64);
            }
            hits &= hits - 1;
        }
    }
    uint64_t total = 0;
    for (uint64_t first = 0; expanded && first < symbol_count; first += 64)
    {
        const uint32_t left = symbol_count - (uint32_t)first;
        const __mmask64 live = _bzhi_u64(UINT64_MAX, left < 64 ? left : 64);
        const __m512i source = _mm512_maskz_loadu_epi8(live, link->symbols.source + first);
        const __mmask64 imported = _mm512_cmpeq_epi8_mask(source, _mm512_set1_epi8(BUSTER_LINK_SOURCE_FOREIGN_SHARED));
        uint64_t seen;
        memcpy(&seen, copied + first / 32, sizeof(seen));
        const uint64_t bits = seen & imported;
        memcpy(copied + first / 32, &bits, sizeof(bits));
        total += (uint64_t)__builtin_popcountll(bits);
    }
    if (!expanded && word_bits != 0)
    {
        const __mmask64 live = symbol_count >= 64 ? UINT64_MAX : _bzhi_u64(UINT64_MAX, symbol_count);
        const __m512i source = _mm512_maskz_loadu_epi8(live, link->symbols.source);
        const uint64_t bits = word_bits & _mm512_cmpeq_epi8_mask(source, _mm512_set1_epi8(BUSTER_LINK_SOURCE_FOREIGN_SHARED));
        if (symbol_count > 64)
        {
            memset(copied, 0, 2 * (((uint64_t)symbol_count + 63) / 64) * sizeof(*copied));
        }
        memcpy(copied, &bits, sizeof(bits));
        total += (uint64_t)__builtin_popcountll(bits);
    }
    return total;
}
uint64_t head(const Link* l, uint32_t* scratch, uint32_t* copied, unsigned path)
{
    (void)path;
    return l->symbols.has_imports ? foreign_link_mark_copies(l, (uint8_t*)scratch, copied) : 0;
}
