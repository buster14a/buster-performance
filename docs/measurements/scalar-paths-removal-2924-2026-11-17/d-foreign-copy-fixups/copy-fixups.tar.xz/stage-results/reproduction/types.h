#include <stdbool.h>
#include <stdint.h>
#include <immintrin.h>
#define BUSTER_LINK_SYMBOL_TYPE 0x0f
#define BUSTER_LINK_SYMBOL_FUNCTION 0x02
#define BUSTER_LINK_FIXUP_NONE 0
#define BUSTER_LINK_FIXUP_CALL 1
#define BUSTER_LINK_FIXUP_CALL_GOT 2
#define BUSTER_LINK_FIXUP_LOAD_GOT 3
#define BUSTER_LINK_FIXUP_GOTPCREL 4
#define BUSTER_LINK_FIXUP_PC32 5
#define BUSTER_LINK_FIXUP_TPOFF32 6
#define BUSTER_LINK_FIXUP_GOTTPOFF 7
#define BUSTER_LINK_FIXUP_ABS64 8
#define BUSTER_LINK_FIXUP_PC64 9
#define BUSTER_LINK_FIXUP_ABS32 10
#define BUSTER_LINK_FIXUP_ABS32S 11
#define BUSTER_LINK_FIXUP_SIZE32 12
#define BUSTER_LINK_FIXUP_SIZE64 13
#define BUSTER_LINK_FIXUP_TLSGD 14
#define BUSTER_LINK_FIXUP_TLSLD 15
#define BUSTER_LINK_FIXUP_DTPOFF32 16
#define BUSTER_LINK_FIXUP_TPOFF64 17
#define BUSTER_LINK_FIXUP_DTPOFF64 18
#define BUSTER_LINK_FIXUP_KINDS 19
#define BUSTER_LINK_FIXUP_KIND 0x7f
#define BUSTER_LINK_FIXUP_WIDE 0x80
#define BUSTER_LINK_FIXUP_BYTES (sizeof(uint32_t) + sizeof(SymbolId) + sizeof(int32_t) + sizeof(uint8_t))
#define BUSTER_LINK_FIXUP_COLUMNS 4
typedef uint32_t FixupId;
typedef uint32_t SymbolId;
typedef enum { FOREIGN_PATH_VECTOR, FOREIGN_PATH_EXACT } ForeignPath;
typedef struct { uint32_t count; uint8_t* kind; uint32_t* target; } LinkFixups;
typedef struct { uint32_t count; uint8_t* flags; uint8_t* source; } LinkSymbols;
typedef struct { LinkSymbols symbols; LinkFixups fixups; } Link;

#define BUSTER_LINK_SOURCE_FOREIGN_SHARED 5
#include <string.h>
