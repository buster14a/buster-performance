#include "types.h"
// The per-symbol source and type are final before copy-relocation discovery.
uint64_t head(const Link* l,uint32_t* unused,uint32_t* out,unsigned path)
{
    (void)unused;
    (void)path;
    const uint32_t words = 2 * ((l->symbols.count + 63) / 64);
    memset(out, 0, words * sizeof(*out));
    const LinkFixups* f = &l->fixups;
    const uintptr_t base = (uintptr_t)f->kind;
    const uintptr_t start = base + 1;
    const uintptr_t end = base + f->count;
    const __m128i direct = _mm_setr_epi8(0,-1,0,0,0,-1,0,0,0,-1,-1,-1,0,0,0,0);
    for (uintptr_t addr = start & ~(uintptr_t)15; addr < end && f->count > 1; addr += 16)
    {
        const uintptr_t left = end - addr;
        const __mmask16 high = (__mmask16)_bzhi_u32(UINT16_MAX, left < 16 ? (unsigned)left : 16);
        const __mmask16 live = addr < start ? (__mmask16)(high & (UINT32_MAX << (start - addr))) : high;
        const __m128i raw = _mm_maskz_loadu_epi8(live, (const void*)addr);
        const __m128i kind = _mm_and_si128(raw, _mm_set1_epi8(BUSTER_LINK_FIXUP_KIND));
        const __mmask16 known = _mm_cmplt_epu8_mask(kind, _mm_set1_epi8(16));
        uint32_t hits = known & _mm_movepi8_mask(_mm_shuffle_epi8(direct, kind));
        while (hits != 0)
        {
            const uint32_t i = (uint32_t)(addr + (unsigned)__builtin_ctz(hits) - base);
            const uint32_t t = f->target[i];
            if (l->symbols.source[t] == BUSTER_LINK_SOURCE_FOREIGN_SHARED &&
                ((f->kind[i] & BUSTER_LINK_FIXUP_KIND) != BUSTER_LINK_FIXUP_CALL ||
                 (l->symbols.flags[t] & BUSTER_LINK_SYMBOL_TYPE) != BUSTER_LINK_SYMBOL_FUNCTION))
            {
                out[t / 32] |= 1u << (t % 32);
            }
            hits &= hits - 1;
        }
    }
    uint64_t total = 0;
    for (uint32_t w = 0; w < words; ++w) total += __builtin_popcount(out[w]);
    return total;
}
