#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

void baseline(const Link*, const uint32_t*, uint32_t*, unsigned);
void head(const Link*, const uint32_t*, uint32_t*, unsigned);
typedef void (*Mark)(const Link*, const uint32_t*, uint32_t*, unsigned);
static int compare(const void* a, const void* b)
{
    const uint64_t x = *(const uint64_t*)a;
    const uint64_t y = *(const uint64_t*)b;
    return (x > y) - (x < y);
}
static uint64_t now(void)
{
    _mm_lfence();
    const uint64_t t = __rdtsc();
    _mm_lfence();
    return t;
}
int main(int argc, char** argv)
{
    enum { CAP = 16384, SYMBOLS = 4096 };
    static uint8_t flags[SYMBOLS];
    uint32_t imports[SYMBOLS / 32], copied[3][SYMBOLS / 32], sizes[200], count = 0;
    const size_t page = (size_t)sysconf(_SC_PAGESIZE);
    const size_t size = (CAP * 4 + page * 3 + page - 1) / page * page;
    uint8_t* kinds_end = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    uint8_t* targets_end = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (kinds_end == MAP_FAILED || targets_end == MAP_FAILED) return 4;
    kinds_end += size - page; targets_end += size - page;
    if (mprotect(kinds_end, page, PROT_NONE) || mprotect(targets_end, page, PROT_NONE)) return 4;
    for (unsigned n=0; n<=96; n++) sizes[count++]=n;
    for (unsigned n=128; n<=CAP; n*=2) for (int t=-2; t<=2; t++) if (n+t<=CAP) sizes[count++]=n+t;
    for (unsigned shape=0; shape<5; shape++) for (unsigned z=0; z<count; z++)
    {
        const uint32_t n=sizes[z];
        Link link={.fixups={.count=n+1,.kind=kinds_end-n-1,.target=(uint32_t*)targets_end-n-1},.symbols={.count=SYMBOLS,.flags=flags}};
        if (argc > 1 && strcmp(argv[1], "aligned") == 0)
        {
            link.fixups.kind = kinds_end - (CAP + 64);
            link.fixups.target = (uint32_t*)targets_end - (CAP + 16);
        }
        link.fixups.kind[0] = BUSTER_LINK_FIXUP_NONE;
        link.fixups.target[0] = 0;
        memset(imports,0,sizeof(imports));memset(copied,0,sizeof(copied));
        for(uint32_t s=0;s<SYMBOLS;s++)
        {
            flags[s]=s%5?1:BUSTER_LINK_SYMBOL_FUNCTION;
            if(shape==2 || (shape!=0 && (s%11==0 || shape==3))) imports[s/32]|=1u<<(s%32);
        }
        for(uint32_t i=1;i<=n;i++)
        {
            uint32_t s=shape==3?i%17:(i*7321+13)%SYMBOLS;
            const uint8_t k=shape==2?BUSTER_LINK_FIXUP_PC32:shape==3?BUSTER_LINK_FIXUP_CALL:shape==4?BUSTER_LINK_FIXUP_LOAD_GOT:(i*7+3)%19;
            link.fixups.kind[i]=k|(i%3?0:128);link.fixups.target[i]=s;
            const bool direct=k==BUSTER_LINK_FIXUP_PC32 || k==BUSTER_LINK_FIXUP_PC64 || k==BUSTER_LINK_FIXUP_ABS32 || k==BUSTER_LINK_FIXUP_ABS32S || (k==BUSTER_LINK_FIXUP_CALL && flags[s]!=BUSTER_LINK_SYMBOL_FUNCTION);
            if(direct && ((imports[s/32]>>(s%32))&1))copied[2][s/32]|=1u<<(s%32);
        }
        Mark marks[3]={baseline,baseline,head};
        uint64_t samples[3][9];const uint32_t reps=32+2048/(n+1);
        for (unsigned i=0;i<9;i++)for(unsigned j=0;j<3;j++)
        {
            unsigned v=(i+j)%3;uint32_t* out=copied[v%2];
            memset(out,0,sizeof(copied[0]));const uint64_t begin=now();
            for(uint32_t r=0;r<reps;r++)marks[v](&link,imports,out,v==1?FOREIGN_PATH_EXACT:FOREIGN_PATH_VECTOR);
            samples[v][i]=now()-begin;
            if(memcmp(copied[2],out,sizeof(copied[0]))!=0)return 2;
        }
        for(unsigned v=0;v<3;v++)qsort(samples[v],9,sizeof(uint64_t),compare);
        printf("%u\t%u\t%u\t%lu\t%lu\t%lu\n",shape,n,reps,samples[0][4],samples[1][4],samples[2][4]);
    }
    return 0;
}
