#include "types.h"
#define BUSTER_FOREIGN_LINK_DIRECT_KINDS                                                                                                                \
    ((1u << BUSTER_LINK_FIXUP_PC32) | (1u << BUSTER_LINK_FIXUP_PC64) | (1u << BUSTER_LINK_FIXUP_ABS32) | (1u << BUSTER_LINK_FIXUP_ABS32S) |         \
     (1u << BUSTER_LINK_FIXUP_CALL))

// Mark direct references to imported data. Each batch, including the last, reads only its live rows.
// Repeated hits can share a bitmap word or even the same bit, so their updates stay ordered.
static void foreign_link_mark_copies(const Link* link, const uint32_t* imports, uint32_t* copied)
{
    const LinkFixups* fixups = &link->fixups;
    const __m512i direct = _mm512_set1_epi32((int)BUSTER_FOREIGN_LINK_DIRECT_KINDS);
    for (uint64_t first = 1; first < fixups->count; first += 16)
    {
        const uint32_t remaining = fixups->count - (uint32_t)first;
        const __mmask16 lanes = (__mmask16)_bzhi_u32(UINT16_MAX, remaining < 16 ? remaining : 16);
        const __m128i raw = _mm_maskz_loadu_epi8(lanes, fixups->kind + first);
        const __m512i kinds = _mm512_cvtepu8_epi32(_mm_and_si128(raw, _mm_set1_epi8(BUSTER_LINK_FIXUP_KIND)));
        const __mmask16 candidates = _mm512_mask_test_epi32_mask(lanes, _mm512_srlv_epi32(direct, kinds), _mm512_set1_epi32(1));
        if (candidates != 0)
        {
            const __m512i targets = _mm512_maskz_loadu_epi32(candidates, fixups->target + first);
            const __m512i words = _mm512_mask_i32gather_epi32(_mm512_setzero_si512(), candidates, _mm512_srli_epi32(targets, 5), imports, 4);
            const __m512i bits = _mm512_srlv_epi32(words, _mm512_and_si512(targets, _mm512_set1_epi32(31)));
            __mmask16 hits = _mm512_mask_test_epi32_mask(candidates, bits, _mm512_set1_epi32(1));
            while (hits != 0)
            {
                const FixupId fixup = (FixupId)first + (FixupId)__builtin_ctz(hits);
                const SymbolId target = fixups->target[fixup];
                if ((fixups->kind[fixup] & BUSTER_LINK_FIXUP_KIND) != BUSTER_LINK_FIXUP_CALL ||
                    (link->symbols.flags[target] & BUSTER_LINK_SYMBOL_TYPE) != BUSTER_LINK_SYMBOL_FUNCTION)
                {
                    copied[target / 32] |= UINT32_C(1) << (target % 32);
                }
                hits &= hits - 1;
            }
        }
    }
}

void head(const Link* l,const uint32_t* i,uint32_t* c,unsigned version){(void)version;foreign_link_mark_copies(l,i,c);}
