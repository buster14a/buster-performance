int f(void){int x;int x;}
