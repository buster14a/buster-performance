struct S {int x;int x;int x;int x;int x;int x;int x;int x;int x;};
