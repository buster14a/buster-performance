int f(void){1;1;1;}
