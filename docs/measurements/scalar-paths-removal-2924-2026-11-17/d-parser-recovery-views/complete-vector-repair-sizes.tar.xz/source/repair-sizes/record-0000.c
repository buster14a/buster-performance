struct S {int x;};
