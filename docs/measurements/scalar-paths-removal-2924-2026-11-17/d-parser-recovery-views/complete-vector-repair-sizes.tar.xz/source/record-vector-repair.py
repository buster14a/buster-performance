import runpy,tarfile
from statistics import median
from pathlib import Path
p=Path(__file__).resolve().parent;out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-recovery-views')
r=p/'native-results';rounds=[[r/'repair-sizes'/f'repair-{i}-{v}.log' for v in (0,1)]for i in (1,2,3)]
rows=runpy.run_path(str(p.parent/'paired-parser-rows.py'))['compare'](rounds)
assert len(rows)==96
counts={k:sum(v[1]<=1 for (_,g,_),v in rows.items()if g==k)for k in ('declaration','record','statement','scopes')}
assert counts=={'declaration':16,'record':16,'statement':13,'scopes':0}
for group,expected in [('malformed-calls','10539'),('attribute-recovery','14718'),('initializer-diagnostics','6642')]:
 s=(r/f'vector-repair-{group}.log').read_text()
 assert expected+' checks, 0 failures' in s, s[-300:]
s=[]
for group,passed in counts.items():
 vals=[row[1]for (_,g,_),row in rows.items()if group==g]
 s.append(f'| {group} | {passed}/24 | {min(vals):.4f} | {median(vals):.4f} | {max(vals):.4f} |')
detail=[f'| {group} | {size} | {tokens:,} | {cycles:.4f} | {insns:.4f} |' for (_,group,size),(tokens,cycles,insns)in rows.items()]
doc=out/'README.md';title='## Rebuilding structure repairs with the vector parser';assert title not in doc.read_text()
archive='complete-vector-repair-sizes.tar.xz'
with tarfile.open(out/archive,'w:xz',preset=2)as a:
 for nm in ('vector-repair.patch','build-vector-repair','test-vector-repair','record-vector-repair.py','native-repair-sizes','repair-size-rows.c','repair-sizes','repair-source'):
  a.add(p/nm,'source/'+nm)
 a.add(p.parent/'paired-parser-rows.py','paired-parser-rows.py')
 for f in [*sorted(r.glob('vector-repair-*.log')),*(q for pair in rounds for q in pair)]:a.add(f,'native/'+f.name)
with doc.open('a')as f:
 f.write('\n'+title+'\n\nThe production candidate runs the ordinary vector grammar into the checker’s padded output columns, keeps interned custom attribute IDs, and restores the scratch arena before building the traversal. Native Clang-backed checker suites passed 10,539 malformed-call checks, 14,718 attribute-recovery checks and 6,642 initializer-diagnostic checks.\n\nThe microbenchmark times the complete tree rebuild on already prepared padded views, including resetting name meanings. Input preparation and traversal construction remain outside both timed regions. The baseline calls the existing scalar recovery parser on the same tokens and output columns. Each ratio divides candidate by baseline and takes the median of three paired rounds of 21 samples on the locked 9700X. Of 96 sizes, 45 met parity. Every nested-scope input and every seven-token function missed. This candidate remains experimental.\n\n| Source family | Sizes at parity or faster | Minimum cycles/token ratio | Median | Maximum |\n| --- | ---: | ---: | ---: | ---: |\n'+'\n'.join(s)+'\n\n| Family | Size | Tokens | Core cycles/token ratio | Instructions/token ratio |\n| --- | ---: | ---: | ---: | ---: |\n'+'\n'.join(detail)+f'\n\n[Exact fixture sources, compiler patch, correctness and counter logs]({archive})\n')
print(counts)
