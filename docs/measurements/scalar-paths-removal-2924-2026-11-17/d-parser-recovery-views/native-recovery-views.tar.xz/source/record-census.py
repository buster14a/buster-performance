from pathlib import Path
import struct, tarfile, re
from collections import Counter,defaultdict
p=Path(__file__).resolve().parent
base=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17')
out=base/'d-parser-recovery-views';out.mkdir(exist_ok=True)
sites=['edited prefix','resumed prefix','structure repair','checker driver recovery','binding replay']
totals=defaultdict(Counter); tests=[];files=[]
for name in ['bindings','attribute-recovery','malformed-calls','initializer-diagnostics']:
    src=p/'native-results';local=p/'local-pinned';data=(src/(name+'.bin')).read_bytes()
    assert data==(local/(name+'.bin')).read_bytes() and (local/(name+'.exit')).read_text().strip()=='0'
    check=0
    for d in [src,local]:
        log=(d/(name+'.log')).read_text();m=re.search(r'^(?:checker-driver|parser bindings): (\d+) checks,.*?0 failures',log,re.M)
        assert m and (not check or check==int(m[1]));check=int(m[1])
    for site,n,e,d,oom,r,u,k,h in struct.iter_unpack('<9Q',data):
        assert 1<=site<=5 and not (oom or r or u)
        totals[site].update(dict(calls=1,tokens=n,error_calls=int(e>0),diagnostics=d))
    tests.append(f'| {name} | {len(data)//72:,} | {check:,} |')
    files.extend([src/(name+'.bin'),src/(name+'.log'),local/(name+'.log'),local/(name+'.exit')])
assert sum(c['calls'] for c in totals.values())==44677
def row(s):
    c=totals[s]
    return '| '+sites[s-1]+' | '+' | '.join(f'{c[k]:,}' for k in ('calls','tokens','error_calls','diagnostics'))+' |'
doc=out/'README.md';assert not doc.exists()
with tarfile.open(out/'native-recovery-views.tar.xz','w:xz',preset=2)as a:
    for f in files:a.add(f,str(f.relative_to(p)))
    for name in ['recovery-census.patch','build-native-recovery','native-recovery-suites','run-local-suites','record-census.py']:a.add(p/name,'source/'+name)
doc.write_text('''# Parser recovery views and binding replay
       
The measurement adds one 72-byte append after each scalar parser call in the four callers at `cc7d4ffb4`. On the Ryzen 7 9700X, the normal Release compiler ran the repository’s checker and binding suites under the exclusive lock with Clang 23.1.4. A separate local build reproduced every trace byte with the same Clang version. The trace records the caller, token count, scalar errors, diagnostic count, resource and classification flags, a hash of the token kinds, and a hash of every successful tree’s role, depth and parent columns.

| Suite | Calls | Passing checks |
| --- | ---: | ---: |
'''.replace('       \n','\n')+'\n'.join(tests)+'''

| Caller | Calls | Tokens parsed | Calls reporting errors | Returned diagnostics |
| --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(row(i)for i in range(1,6))+'''

All 1,018 structure repairs returned trees without syntax errors. Resumed prefixes returned errors on 11,925 views and the driver returned errors on another 991. These callers consume the repaired tree or its diagnostics. Binding replay also emits scope and declaration events. The trace counts that caller separately. All 44,677 calls completed without memory exhaustion, retyping or an undecided classification.

[Raw native traces, per-suite logs, source patch and verification script](native-recovery-views.tar.xz)
''')
print(*[row(i)for i in range(1,6)],sep='\n')
