from pathlib import Path
from collections import Counter
import runpy,tarfile
p=Path(__file__).resolve().parent
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-parser-recovery-views')
vs=runpy.run_path(str(p/'compare-raw.py'))['verify'];counts=Counter();archives=[]
for suite in ['bindings','attribute-recovery','malformed-calls','initializer-diagnostics']:
 r=p/'native-results';f=r/('raw-'+suite+'.bin');g=f.with_suffix('.comparison');base=f.read_bytes();new=g.read_bytes()
 assert base==(r/(suite+'.bin')).read_bytes()==(p/'local-raw-suites'/(suite+'.bin')).read_bytes()
 assert new==(p/'local-raw-suites'/(suite+'.raw')).read_bytes()
 counts.update(vs(base,new));archives+=[f,g,f.with_suffix('.log')]
assert sum(counts.values())==44459 and counts[3,'valid','clean','equal']==1018 and sum(v for k,v in counts.items() if k[3]=='different')==2604
doc=d/'README.md';heading='## Tree equivalence before repairing flagged declarations';assert heading not in doc.read_text()
names=['edited prefix','resumed prefix','structure repair','checker driver recovery']
rows=['| '+names[k[0]-1]+' | '+k[1]+' | '+k[2]+' | '+k[3]+' | '+f'{v:,} |'for k,v in sorted(counts.items())]
arch='raw-vector-recovery-trees.tar.xz'
with tarfile.open(d/arch,'w:xz',preset=2)as a:
 for f in archives:a.add(f,'native/'+f.name)
 for n in ['raw-recovery.patch','raw-recovery.inc','raw-recovery.py','build-native-raw','native-raw-suites','compare-raw.py','record-raw.py','raw-native-comparison.tsv']:a.add(p/n,'source/'+n)
with doc.open('a')as f:f.write('\n'+heading+'''

Each nonbinding caller ran the existing AVX-512 kernels on padded copies of its recovery view in a private arena. This comparison bypassed the parser’s flagged-item and whole-unit repair step. For each accepted scalar tree, the probe compared every token’s role, depth and parent whenever the kernels returned a whole tree. All 44,459 native records matched an independent local run byte for byte and the checker and Clang suites passed on both computers. The binding suite emitted its original 218 census rows. It requires scope events and was excluded from the tree-only probe.

| Caller | Scalar result | Kernel result | Tree columns | Calls |
| --- | --- | --- | --- | ---: |
'''+'\n'.join(rows)+'''

Here “clean” means that the kernels covered the whole view without flagging any token. “Flagged” means that the kernels produced tree columns and asked for selected declarations to be repaired. “Whole” means they asked for the complete input to be reparsed. The raw kernels reproduced all 1,018 structure-repair trees. They produced different columns on 1,060 valid resumed prefixes and 1,544 valid driver recovery views. The error-producing and whole-unit rows were counted without comparing partial trees. The ordinary parser’s diagnostic path still matters for those inputs.

[Native comparison records, suite logs, instrumentation and decoder]('''+arch+')\n')
