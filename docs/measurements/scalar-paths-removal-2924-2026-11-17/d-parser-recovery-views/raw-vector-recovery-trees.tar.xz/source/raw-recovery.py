from pathlib import Path
import re,subprocess
p=Path(__file__).resolve().parent;d=p/'tree/src/buster/compiler'
f=d/'c_parser_impl.c';s=f.read_text();k='static ParseKernelResult parse_vector_run(';assert s.count(k)==1;s=s.replace(k,'static _Thread_local bool recovery_skip_fallback;\n\n'+k)
key='if (!(tile && result.everything))';assert s.count(key)==1;s=s.replace(key,'if (!recovery_skip_fallback && !(tile && result.everything))')
k=s.index('static ParseKernelResult parse_vector(');j=s.index('\n}',k)+2;s=s[:j]+'\n\n'+(p/'raw-recovery.inc').read_text()+s[j:];f.write_text(s)
f=d/'c_parser.c';s=f.read_text();k='BUSTER_PARSER_ENTRY ParseScalarResult parse_scalar_traced(';assert s.count(k)==1;f.write_text(s.replace(k,'BUSTER_PARSER_ENTRY __attribute__((unused)) void recovery_vector_probe(uint32_t site, Parser* view, uint32_t count, ParseScalarResult scalar);\n'+k))
for name in ['c_check_prefix.c','c_check_repair.c','c_checker_driver.c']:
 f=d/name;s=f.read_text()
 pat=r'(?m)^([ ]*)recovery_census\((\d), view->tokens.kinds, (\w+), parsed,[^;]*?;'
 s,n=re.subn(pat,lambda m:m[0]+'\n'+m[1]+f'recovery_vector_probe({m[2]}, view, {m[3]}, parsed);',s)
 assert n==(2 if name=='c_check_prefix.c'else 1);f.write_text(s)
(p/'raw-recovery.patch').write_bytes(subprocess.check_output(['git','diff','--','src'],cwd=p/'tree'))
