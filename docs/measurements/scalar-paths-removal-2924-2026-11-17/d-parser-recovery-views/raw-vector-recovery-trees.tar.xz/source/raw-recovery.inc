// Measurement only. Compare the unmodified vector kernels on an independent copy of a recovery
// view to the scalar caller's result. The probe never replaces the caller's tree or diagnostics.
BUSTER_PARSER_ENTRY __attribute__((unused)) void recovery_vector_probe(uint32_t site, Parser* view, uint32_t count, ParseScalarResult scalar)
{
    const char* path = getenv("BUSTER_RAW_RECOVERY");
    if (!path) return;
    const uint64_t capacity = (uint64_t)count + 2 * BUSTER_PARSE_TOKEN_PADDING;
    Arena arena = arena_reserve((8ull << 20) + capacity * 1024 + (uint64_t)view->meanings.capacity * 64);
    uint64_t record[] = { site, count, scalar.errors, scalar.out_of_memory, UINT64_MAX, UINT64_MAX, 0, 0, 0 };
    ParseKernels kernels;
    ParseVectorBuffers buffers;
    uint8_t* kinds = BUSTER_ARENA_PUSH_ARRAY(&arena, uint8_t, capacity);
    uint32_t* names = BUSTER_ARENA_PUSH_ARRAY(&arena, uint32_t, capacity);
    uint8_t* flags = BUSTER_ARENA_PUSH_ARRAY(&arena, uint8_t, capacity);
    uint8_t* initial = BUSTER_ARENA_PUSH_ARRAY(&arena, uint8_t, view->meanings.capacity);
    if (arena.base && kinds && names && flags && initial &&
        parse_kernels_reserve(&kernels, &arena, count, view->meanings.capacity) &&
        parse_vector_buffers_reserve(&buffers, &arena, count))
    {
        memset(kinds, PARSE_KIND_END, capacity);
        memset(names, 0, capacity * sizeof(*names));
        memset(flags, 0, capacity);
        kinds += BUSTER_PARSE_TOKEN_PADDING;
        names += BUSTER_PARSE_TOKEN_PADDING;
        flags += BUSTER_PARSE_TOKEN_PADDING;
        memcpy(kinds, view->tokens.kinds, count);
        memcpy(names, view->tokens.names, (uint64_t)count * sizeof(*names));
        memcpy(flags, view->tokens.flags, count);
        ParseMeanings meanings = view->meanings;
        memset(initial, PARSE_MEANING_ORDINARY, meanings.capacity);
        meanings.meanings = initial;
        for (uint32_t i = 0; i < BUSTER_PARSE_PREDECLARED_TYPEDEFS; ++i)
            initial[view->predeclared[i]] = PARSE_MEANING_TYPEDEF;
        const ParseInput input = { .kinds = kinds, .names = names, .flags = flags, .count = count,
                                   .language = view->language, .meanings = &meanings, .scratch = &arena };
        recovery_skip_fallback = true;
        const ParseKernelResult result = parse_vector(&kernels, &input, view->predeclared, &buffers);
        recovery_skip_fallback = false;
        record[4] = result.everything;
        record[5] = result.flagged_tokens;
        if (!scalar.errors && !scalar.out_of_memory && !result.everything)
        {
            for (uint32_t t = 0; t < count; ++t)
            {
                record[6] += view->tree.roles[t] != kernels.roles[t];
                record[7] += view->tree.depths[t] != kernels.node_depths[t];
                record[8] += view->tree.parents[t] != kernels.parents[t];
            }
        }
    }
    arena_release(&arena);
    const int fd = open(path, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
    if (fd < 0 || write(fd, record, sizeof(record)) != (ssize_t)sizeof(record) || close(fd)) abort();
}
