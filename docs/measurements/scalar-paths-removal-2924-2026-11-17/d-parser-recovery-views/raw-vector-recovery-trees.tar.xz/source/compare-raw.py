from pathlib import Path
from collections import Counter
from struct import iter_unpack
import sys
p=Path(__file__).resolve().parent
def verify(census,raw):
    entries=list(iter_unpack('<9Q',census)); data=iter_unpack('<9Q',raw);counts=Counter()
    for x,y in zip(data,(v for v in entries if v[0]!=5),strict=True):
        s,t,e,oom,w,k,m,d,a=x;assert (s,t,e,oom)==(*y[:3],y[4]) and not oom and w<=1
        status='invalid' if e else 'valid';result='whole'if w else 'flagged'if k else 'clean'
        counts[s,status,result,'different'if m+d+a else 'equal'if not (e or w)else 'uncompared']+=1
    return counts
if __name__=='__main__':
    data=Counter()
    for suite in ('bindings','attribute-recovery','malformed-calls','initializer-diagnostics'):
        local=p/'local-raw-suites'/suite;native=p/'native-results'/('raw-'+suite)
        base=native.with_suffix('.bin').read_bytes();raw=native.with_suffix('.comparison').read_bytes()
        assert base==local.with_suffix('.bin').read_bytes()==(p/'native-results'/(suite+'.bin')).read_bytes()
        assert raw==local.with_suffix('.raw').read_bytes()
        data.update(verify(base,raw))
    assert sum(data.values())==44459 and all(key[3]=='equal'for key in data if key[2]=='clean')
    for k,v in sorted(data.items()):print(*k,v,sep='\t')
