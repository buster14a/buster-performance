from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,difflib
p=Path(__file__).parent;f='src/buster/compiler/c_preprocessor_impl.c'
with TemporaryDirectory()as tmp:
 d=Path(tmp);q=d/f;q.parent.mkdir(parents=True);q.write_text((p/'live'/f).read_text())
 subprocess.run(['git','apply',str(p/'interior.patch')],cwd=d,check=True);s=q.read_text()
old=s;a=s.index('    PPBodyWordCache* cache =',s.index('static void pp_scan_body_word'));b=s.index('            if (hashes != 0 && macro->parameter_count',a);e=s.index('        t += count;',b)
t=s[b:e].replace('word + (uint32_t)__builtin_ctzll(todo)','t + (uint32_t)__builtin_ctzll(todo)').replace('            uint64_t optional = body & cache->optional;','')
s=s[:a]+'''    uint32_t found_paste = 0;
    uint32_t found_hash = 0;
    uint32_t found_opt = 0;
    for (uint32_t t = begin; t < end;)
    {
        const uint32_t left = end - t;
        const uint32_t count = left < 16 ? left : 16;
        const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, count);
        const __m128i kinds = _mm_and_si128(_mm_maskz_loadu_epi8(active,data->kinds + t), _mm_set1_epi8(0x7f));
        const __mmask16 identifiers = _mm_cmpeq_epi8_mask(kinds,_mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
        const __m512i ids = _mm512_maskz_loadu_epi32(active,data->values + t);
        uint64_t optional = _mm512_mask_cmpeq_epi32_mask(identifiers,ids,_mm512_set1_epi32(C_NAME_VA_OPT));
        uint64_t hashes = _mm_cmpeq_epi8_mask(kinds,_mm_set1_epi8(C_TOKEN_HASH));
        found_paste |= _mm_cmpeq_epi8_mask(kinds,_mm_set1_epi8(C_TOKEN_HASHHASH));
        if (hashes | optional)
        {
'''+t+s[e:]
(p/'bodylanes.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f)))
for suffix in ('task','resume','defines','shape-group','corpus'):
 t=(p/('interior-'+suffix)).read_text().replace('interior','bodylanes').replace('Stream complete macro-body words and parse common parameter lists once','Test flag and name comparisons in contiguous replacement-list packets')
 t=t.replace('git apply -R "$root/namedpublication.patch"\n','')
 (p/('bodylanes-'+suffix)).write_text(t)
