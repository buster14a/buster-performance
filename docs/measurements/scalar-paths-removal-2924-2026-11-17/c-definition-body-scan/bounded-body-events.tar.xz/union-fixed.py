from pathlib import Path
f=Path('src/buster/compiler/c_preprocessor.c');s=f.read_text()
needle='    uint64_t optional;\n};\n\nstruct Preprocessor'
assert s.count(needle)==1;f.write_text(s.replace(needle,'    uint64_t optional;\n    uint64_t marked;\n};\n\nstruct Preprocessor'))
f=Path('src/buster/compiler/c_preprocessor_impl.c');s=f.read_text()
a=s.index('            uint64_t identifiers =',s.index('static void pp_scan_body_word('))
b=s.index('\n        }\n        const uint32_t offset',a)
s=s[:a]+'''            const uint64_t identifiers = _mm512_mask_cmpeq_epi8_mask(live, kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            uint64_t optional = 0;
            for (uint32_t off = 0; off < 64; off += 16)
            {
                const __mmask16 named = (__mmask16)(identifiers >> off);
                if (named != 0)
                {
                    const __mmask16 present = (__mmask16)(live >> off);
                    const __m512i values = _mm512_maskz_loadu_epi32(present, data->values + word + off);
                    optional |= (uint64_t)_mm512_mask_cmpeq_epi32_mask(named, values, _mm512_set1_epi32(C_NAME_VA_OPT)) << off;
                }
            }
            cache->optional = optional;
            cache->marked = cache->pastes | cache->hashes | optional;'''+s[b:]
a=s.index('        found_paste |= body',a);b=s.index('        t += count;',a)
s=s[:a]+'''        if ((body & cache->marked) != 0)
        {
            found_paste |= body & cache->pastes;
            found_hash |= body & cache->hashes;
            found_opt |= body & cache->optional;
        }
'''+s[b:]
s=s.replace('const __mmask64 live = _bzhi_u64(UINT64_MAX, data->token_count - word);', '''const uint32_t left = data->token_count - word;
            const __mmask64 live = left >= 64 ? UINT64_MAX : _bzhi_u64(UINT64_MAX, left);''')
f.write_text(s)
