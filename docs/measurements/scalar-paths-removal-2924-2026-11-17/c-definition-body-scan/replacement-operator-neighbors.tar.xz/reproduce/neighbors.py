from pathlib import Path
import difflib,subprocess,tempfile
p=Path(__file__).parent;f='src/buster/compiler/c_preprocessor_impl.c'
s=(p/'current-lanes.c').read_text()
with tempfile.TemporaryDirectory()as tmp:
 q=Path(tmp)/f;q.parent.mkdir(parents=True);q.write_text(s)
 for patch in ('binding.patch','blocks.patch'):subprocess.run(['git','apply',str(p/patch)],cwd=tmp,check=True)
 prior=q.read_text()
i=s.index('static void pp_scan_body_word');a=s.index('        const __m128i kinds',i);b=s.index('        t += count;',a)
s=s[:a]+'''        // Up to three following kinds decide the common #parameter and __VA_OPT__(identifier) spellings.
        const __mmask32 look=(__mmask32)_bzhi_u32(UINT32_MAX,left < 19 ? left : 19);
        const __m256i kinds=_mm256_and_si256(_mm256_maskz_loadu_epi8(look,data->kinds+t),_mm256_set1_epi8(0x7f));
        const uint32_t named=_mm256_cmpeq_epi8_mask(kinds,_mm256_set1_epi8(C_TOKEN_RAW_IDENTIFIER)) & look;
        const __m512i ids=_mm512_maskz_loadu_epi32(active,data->values+t);
        uint32_t optional=_mm512_mask_cmpeq_epi32_mask((__mmask16)named,ids,_mm512_set1_epi32(C_NAME_VA_OPT));
        uint32_t hashes=_mm256_cmpeq_epi8_mask(kinds,_mm256_set1_epi8(C_TOKEN_HASH)) & active;
        found_paste |= _mm256_cmpeq_epi8_mask(kinds,_mm256_set1_epi8(C_TOKEN_HASHHASH)) & active;
        if (hashes && macro->parameter_count == 1 && !(macro->flags & BUSTER_PP_MACRO_VARIADIC))
        {
            const __mmask16 followed=(__mmask16)(hashes & (named >> 1));
            const __m512i next=_mm512_maskz_loadu_epi32(followed,data->values+t+1);
            const IdentId formal=data->values[macro->parameters_begin];
            hashes &= ~_mm512_mask_cmpeq_epi32_mask(followed,next,_mm512_set1_epi32((int)formal));
        }
        if (optional && (macro->flags & BUSTER_PP_MACRO_VARIADIC) && left > 3)
        {
            const uint32_t open=_mm256_cmpeq_epi8_mask(kinds,_mm256_set1_epi8(C_TOKEN_L_PAREN));
            const uint32_t close=_mm256_cmpeq_epi8_mask(kinds,_mm256_set1_epi8(C_TOKEN_R_PAREN));
            const __mmask16 simple=(__mmask16)(optional & (open >> 1) & (named >> 2) & (close >> 3));
            const __m512i inner=_mm512_maskz_loadu_epi32(simple,data->values+t+2);
            optional &= ~_mm512_mask_cmpneq_epi32_mask(simple,inner,_mm512_set1_epi32(C_NAME_VA_OPT));
        }
        found_hash |= hashes;
        found_opt |= optional;
'''+s[b:]
(p/'neighbors.patch').write_text(''.join(difflib.unified_diff(prior.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f)))
for tail in ('task','resume','shape-group','defines','corpus'):
 t=(p/('blocks-'+tail)).read_text().replace('blocks','neighbors').replace('four consecutive identifier vectors per token-kind load','token neighbors for stringizing and variadic replacement')
 (p/('neighbors-'+tail)).write_text(t)
