from pathlib import Path
import subprocess
root=Path('src/buster/compiler')
# Start from the prior file-absence experiment's source changes, preserving the candidate definition routine.
p=root/'c_refine.c';s=p.read_text()
s=s.replace('    uint64_t replacement;\n};','    uint64_t replacement;\n    uint64_t optional;\n};').replace('    uint64_t replacement = progress->replacement;','    uint64_t replacement = progress->replacement;\n    uint64_t optional = progress->optional;').replace('refine_pass_c(&identifiers, block, block_end, values, &replacement);','refine_pass_c(&identifiers, block, block_end, values, &optional);').replace('    progress->replacement = replacement;','    progress->replacement = replacement;\n    progress->optional = optional;')
assert 'progress->optional = optional;' in s;p.write_text(s)
p=root/'c_preprocessor.c';s=p.read_text().replace('    bool ordinary_replacement_lists;', '    bool ordinary_replacement_lists;\n    bool no_optional_replacement;').replace('data->ordinary_replacement_lists = progress.replacement == 0;', 'data->ordinary_replacement_lists = (progress.replacement | progress.optional) == 0;\n        data->no_optional_replacement = progress.optional == 0;')
p.write_text(s)
p=root/'c_preprocessor_impl.c';s=p.read_text().replace('    data->token_count = record->token_count;', '    data->ordinary_replacement_lists = record->ordinary_replacement_lists;\n    data->no_optional_replacement = record->no_optional_replacement;\n    data->token_count = record->token_count;').replace('    data->kinds = NULL;\n    data->starts = NULL;', '    data->ordinary_replacement_lists = false;\n    data->no_optional_replacement = false;\n    data->kinds = NULL;\n    data->starts = NULL;')
a=s.index('static void pp_define(Preprocessor*');b=s.index('\n}',a);fn=s[a:b].replace('if (valid && macro.body_begin < macro.body_end)', 'if (valid && macro.body_begin < macro.body_end && !data->ordinary_replacement_lists)');s=s[:a]+fn+s[b:]
s=s.replace('uint64_t identifiers = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER)) & live;', 'uint64_t identifiers = data->no_optional_replacement ? 0 : _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER)) & live;')
p.write_text(s)
