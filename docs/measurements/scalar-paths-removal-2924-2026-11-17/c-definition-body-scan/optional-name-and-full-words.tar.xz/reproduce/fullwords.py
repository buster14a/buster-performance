from pathlib import Path
from tempfile import TemporaryDirectory
from difflib import unified_diff
import shutil,subprocess
p=Path(__file__).parent;f='src/buster/compiler/c_preprocessor_impl.c'
with TemporaryDirectory()as tmp:
 d=Path(tmp)
 for name in ['c_preprocessor.c','c_preprocessor_impl.c','c_refine.c']:
  path=d/'src/buster/compiler'/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p/'neighbor-source/src/buster/compiler'/name,path)
 subprocess.run(['git','apply',str(p/'tokenmarks.patch')],cwd=d,check=True);prev=(d/f).read_text()
a=prev.index('        const uint32_t count =',prev.index('static void pp_scan_body_word'));b=prev.index('        if (hashes | optional)',a)
t='''        uint32_t count;
        uint64_t hashes;
        uint64_t optional;
        if (left >= 64)
        {
            count = 64;
            const __m512i kinds = _mm512_and_si512(_mm512_loadu_si512(data->kinds + t), _mm512_set1_epi8(0x7f));
            hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH)) != 0;
            optional = 0;
            if (!data->va_opt_absent)
            {
                const uint32_t* values = data->values + t;
                const __m512i name = _mm512_set1_epi32(C_NAME_VA_OPT);
                const uint64_t a = _mm512_cmpeq_epi32_mask(name, _mm512_loadu_si512(values));
                const uint64_t b = _mm512_cmpeq_epi32_mask(name, _mm512_loadu_si512(values + 16));
                const uint64_t c = _mm512_cmpeq_epi32_mask(name, _mm512_loadu_si512(values + 32));
                const uint64_t d = _mm512_cmpeq_epi32_mask(name, _mm512_loadu_si512(values + 48));
                const uint64_t named = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
                optional = named & (a | b << 16 | c << 32 | d << 48);
            }
        }
        else
        {
            count = left < 16 ? left : 16;
            const __mmask16 live = (__mmask16)_bzhi_u32(UINT16_MAX, count);
            const __m128i kinds = _mm_and_si128(_mm_maskz_loadu_epi8(live, data->kinds + t), _mm_set1_epi8(0x7f));
            hashes = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASHHASH));
            const __mmask16 named = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            const __m512i values = _mm512_maskz_loadu_epi32(live, data->values + t);
            optional = _mm512_mask_cmpeq_epi32_mask(named, values, _mm512_set1_epi32(C_NAME_VA_OPT));
        }
'''
s=prev[:a]+t+prev[b:]
(p/'fullwords.patch').write_text(''.join(unified_diff(prev.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f)))
for suffix in ('resume','corpus','shape-group','defines','task'):
 s=(p/('tokenmarks-'+suffix)).read_text().replace('tokenmarks','fullwords')
 if suffix=='task':
  s=s.replace('until [[ -f neighbors-defines.ok ]]; do sleep 15; done','test -x "$root/pp-tokenmarks2"')
  s=s.replace('bash fullwords-resume','bash fullwords-focus\nbash fullwords-resume')
 (p/('fullwords-'+suffix)).write_text(s)
