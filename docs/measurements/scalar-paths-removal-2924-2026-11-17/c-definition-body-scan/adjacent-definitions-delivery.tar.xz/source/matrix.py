from pathlib import Path
from statistics import median
import sys,re,tarfile,io
p=Path(__file__).parent
def sample(v):
 r=p/(v+'-production-results')/(v+'-sizes-output');rows=[];cases=[]
 for g,n in [('literal',75),('parameter',74),('paste',72),('stringize',73),('optional',71)]:
  files=sorted(r.glob(g+'-*-3-default.log'));assert len(files)==n,(g,len(files))
  for f in files:
   prefix=f.name.removesuffix('-3-default.log');n=int(prefix.split('-')[1]);group=[]
   shas=[(r/f'{prefix}-{s}.sha').read_text().strip() for s in ('scalar','vector','head')]
   assert len(set(shas))==1 and re.fullmatch('[a-f0-9]{64}',shas[0])
   assert len({(r/f'{prefix}-{s}.err').read_bytes()for s in ('scalar','vector','head')})==1
   for i in (1,2,3):
    direct=[float(re.search(r'([\d.]+) cycles per #define',(r/f'{prefix}-{i}-{m}.define').read_text())[1]) for m in ('scalar','vector','head')]
    whole=[]
    for m in ('scalar','default'):
     s=(r/f'{prefix}-{i}-{m}.log').read_text();assert s.rstrip().endswith('time-runs: done, 0 failed processes'),f
     cycles={key:int(c)for key,c in re.findall(r'^list 1 (base|head) .*?\]: 4 runs, median .*? (\d+) user cycles,',s,re.M)}
     assert len(cycles)==2 and min(cycles.values())>0
     whole.extend([cycles['base'],cycles['head']])
    group.append([direct[2]/direct[0],direct[2]/direct[1],whole[1]/whole[0],whole[3]/whole[2]])
    rows.append([g,n,i,*direct,*whole,shas[0]])
   cases.append([g,n,*[median(vals) for vals in zip(*group)]])
 print(v,[(sum(c[i]<=1 for c in cases),round(median(c[i]for c in cases),5),round(max(c[i]for c in cases),5))for i in range(2,6)],flush=True)
 return rows,cases
if __name__=='__main__':
 for v in sys.argv[1:]:sample(v)
