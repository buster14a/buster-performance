from pathlib import Path
from statistics import median
from io import BytesIO
import re,tarfile
from matrix import sample
p=Path(__file__).parent
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/c-definition-body-scan')
def readpairs(f):
 s=f.read_text();assert s.rstrip().endswith('ab: done, 0 failed runs')
 out=[]
 for block in s.split('time-runs: done, 0 failed processes')[:-1]:
  z={k:int(c)for k,c in re.findall(r'^list 1 (base|head) .*?\]: 4 runs, median .*? (\d+) user cycles,',block,re.M)}
  assert len(z)==2 and min(z.values())>0;out.append(z['head']/z['base'])
 return out
name='adjacent-definitions-delivery.tar.xz'
tab=[];corp=[];both=[]
with tarfile.open(d/name,'w:xz')as t:
 def add(fn,b):
  b=b.encode();i=tarfile.TarInfo(fn);i.size=len(b);t.addfile(i,BytesIO(b))
 for v in ('deflines','delivery'):
  r=p/(v+'-production-results');rows,cs=sample(v)
  add(v+'/cycles.tsv','shape\tlength\tround\tscalar_definition\tdefault_definition\tcandidate_definition\tscalar_command_base\tscalar_command_candidate\tdefault_command_base\tdefault_command_candidate\toutput_sha256\n'+'\n'.join('\t'.join(map(str,row))for row in rows)+'\n')
  for i in range(2,6):assert max(c[i] for c in cs)<=1
  worst=[max(c[i]for c in cs)for i in range(2,6)]
  tab.append('| '+' | '.join([v,*[f'{k:.5f}'for k in worst]])+' |')
  for g in ('lua','sqlite','musl'):
   folder=r/f'{v}-{g}';nums=[]
   for ext in ['sha','err']:
    assert len({(folder/f'{m}-{side}.{ext}').read_bytes()for m in ['scalar','default']for side in ['base','head']})==1
   for mode in ['default','scalar']:
    vals=readpairs(folder/(mode+'.log'));assert len(vals)==7;nums.append(f'{100*(median(vals)-1):+.3f}%')
    if g=='sqlite' and v=='delivery':
     extra=readpairs(p/f'delivery-sqlite-control-results/{mode}-paired.log');same=readpairs(p/f'delivery-sqlite-control-results/{mode}-identical.log')
     assert len(extra)==14 and len(same)==7
     both.append('| '+' | '.join([mode,*[f'{100*(median(z)-1):+.3f}%'for z in [vals,extra,vals+extra,same]]])+' |')
   corp.append('| '+' | '.join([v,g,*nums])+' |');t.add(folder,arcname=v+'/'+g)
 for n in ['final-review-v2.patch','deflines.patch','delivery-clean.patch','delivery-sizes','delivery-corpus','delivery-sqlite-control','matrix.py','record-delivery.py','gen-shapes.py','passing-new.digests','final-fixtures']:t.add(p/n,arcname='source/'+n)
 t.add(p/'delivery-receipts',arcname='oracle');t.add(p/'delivery-sqlite-control-results',arcname='sqlite-control')
 for f in (p/'production/tests/preprocessor/cases').glob('042[012].*'):t.add(f,arcname='fixtures/'+f.name)
 t.add(p/'production/tests/preprocessor/cases/catalog.tsv',arcname='fixtures/catalog.tsv')
oracle=(p/'delivery-receipts/ready-oracle.log').read_text();assert 'cases: 0 of 422 fail' in oracle and oracle.count('0 unverified), 0 differ')==2 and '0 of 240 sources differ' in oracle and '0 of 1041 checks fail' in oracle
shas=[s.split()[0]for s in (p/'delivery-receipts/ready-code.sha').read_text().splitlines()];assert len(shas)==2 and shas[0]==shas[1]
title='## Adjacent definitions on the shipping file path';f=d/'README.md';s=f.read_text();assert title not in s
f.write_text(s.rstrip()+'\n\n'+title+'''

Each definition still updates macro state before the next line, including poison checks and diagnostics. Definitions in ordinary file input can share the directive dispatch until text, a different directive, a fatal error or the end of the file. Argument collection processes one directive per step.

Both builds met all four comparisons at all 365 sizes. The numbers below are the largest candidate/parent ratio over the 365 medians of three paired rounds. Each definition sample measured 21 passes. A complete-command round timed four fresh processes per executable. Each paired command produced identical stdout and stderr.

| Build | Definition vs. scalar | Definition vs. default | Complete vs. scalar | Complete vs. default |
| --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(tab)+'''

The delivery build is PR #3686 commit `c2e25b4c9`. The final source-comment edit produced identical executable code (.text SHA-256 `'''+shas[0]+'''`). Release preprocessing cycles on the three corpora changed as follows in the initial seven paired rounds.

| Build | Corpus | Default | Scalar flag |
| --- | --- | ---: | ---: |
'''+ '\n'.join(corp)+'''

SQLite also has fourteen additional pairs on the final binary and seven pairs running the parent on both sides. All 21 candidate pairs count in the combined column.

| SQLite mode | First 7 | Additional 14 | All 21 | Identical executable |
| --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(both)+f'''

The shipping executable passed all 422 deterministic cases and 256 generated cases against Clang, 240 windowed sources, 119,625 checks of window cuts and 1,041 directive-position checks. The untouched parent provided the nine new case, compile and print digests. The fixtures cover definitions separated by emitted text, argument collection, skipped groups, redefinition, poisoned names, an invalid paste, and an unterminated comment.

[Source, every paired size, corpus receipts, independent expected outputs and oracle logs]({name})
''')
