from pathlib import Path
import subprocess
p=Path('src/buster/compiler/c_preprocessor_impl.c')
s=p.read_text()
base=subprocess.check_output(['git','show','HEAD:'+str(p)],text=True)
a=base.index('static void pp_define(Preprocessor*'); b=base.index('\n}\n',a)+3
old=base[a:b].replace('static void pp_define(', 'static __attribute__((noinline)) void pp_define_baseline(').replace('if (BUSTER_VECTOR_PATH(pp->vectorized))','if (pp_bench_body_mode != 1 && BUSTER_VECTOR_PATH(pp->vectorized))')
a=s.index('static void pp_define(Preprocessor*');b=s.index('\n}\n',a)+3
s=s[:a]+old+'\n'+s[a:b].replace('static void pp_define(', 'static __attribute__((noinline)) void pp_define_candidate(')+'''
static void pp_define(Preprocessor* pp, uint32_t data_index, uint32_t base, uint32_t begin, uint32_t end)
{
    if (pp_bench_body_mode == 2)
    {
        pp_define_candidate(pp, data_index, base, begin, end);
    }
    else
    {
        pp_define_baseline(pp, data_index, base, begin, end);
    }
}
'''+s[b:]
start=s.index('static void pp_scan_body_vector(')
s=s[:start]+'''static unsigned pp_bench_body_mode;
__attribute__((constructor)) static void pp_bench_marked_init(void)
{
    char path[4096];
    const ssize_t n = readlink("/proc/self/exe",path,sizeof(path)-1);
    if (n > 0)
    {
        path[n] = 0;
        const char* m = strstr(path,"-marks");
        pp_bench_body_mode = m != NULL ? (unsigned)strtoul(m+6,NULL,10) : 0;
    }
}
'''+s[start:]
s=s.replace('    if (end - begin == 1)','    if (pp_bench_body_mode == 2 && end - begin == 1)',1)
p.write_text(s)
