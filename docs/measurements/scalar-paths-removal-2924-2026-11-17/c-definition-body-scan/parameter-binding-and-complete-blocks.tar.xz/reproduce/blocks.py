from pathlib import Path
import subprocess,difflib,tempfile
p=Path(__file__).parent;f='src/buster/compiler/c_preprocessor_impl.c'
with tempfile.TemporaryDirectory() as tmp:
 q=Path(tmp)/f;q.parent.mkdir(parents=True);q.write_text((p/'current-lanes.c').read_text())
 subprocess.run(['git','apply',str(p/'binding.patch')],cwd=tmp,check=True);s=old=q.read_text()
a=s.index('        const uint32_t count =',s.index('static void pp_scan_body_word'));b=s.index('        if (hashes | optional)',a)
s=s[:a]+'''        uint32_t count;
        uint64_t hashes;
        uint64_t optional = 0;
        if (left >= 64)
        {
            count = 64;
            const __m512i kinds = _mm512_and_si512(_mm512_loadu_si512(data->kinds + t), _mm512_set1_epi8(0x7f));
            hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH)) != 0;
            const uint64_t named = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            if (named != 0)
            {
                // A match outside the identifier lanes can be a token's ending byte offset.
                const uint32_t* const values = data->values + t;
                const __m512i target = _mm512_set1_epi32(C_NAME_VA_OPT);
                const uint64_t a = _mm512_cmpeq_epi32_mask(target, _mm512_loadu_si512(values));
                const uint64_t b = _mm512_cmpeq_epi32_mask(target, _mm512_loadu_si512(values + 16));
                const uint64_t c = _mm512_cmpeq_epi32_mask(target, _mm512_loadu_si512(values + 32));
                const uint64_t d = _mm512_cmpeq_epi32_mask(target, _mm512_loadu_si512(values + 48));
                optional = named & (a | b << 16 | c << 32 | d << 48);
            }
        }
        else
        {
            count = left < 16 ? left : 16;
            const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, count);
            const __m128i kinds = _mm_and_si128(_mm_maskz_loadu_epi8(active, data->kinds + t), _mm_set1_epi8(0x7f));
            hashes = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASHHASH)) != 0;
            const __mmask16 named = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            if (named != 0)
            {
                const __m512i ids = _mm512_maskz_loadu_epi32(named, data->values + t);
                optional = _mm512_cmpeq_epi32_mask(ids, _mm512_set1_epi32(C_NAME_VA_OPT));
            }
        }
'''+s[b:]
# A mark at bit 32 or above matters just as much as the first bit.
a=s.index('static void pp_scan_body_word');b=s.index('static __attribute__((noinline)) bool pp_define_marked',a)
s=s[:a]+s[a:b].replace('found_hash |= hashes;', 'found_hash |= hashes != 0;').replace('found_opt |= optional;', 'found_opt |= optional != 0;')+s[b:]
(p/'blocks.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f)))
for suffix in ('task','resume','shape-group','defines','corpus'):
 s=(p/('binding-'+suffix)).read_text().replace('binding','blocks').replace('guarded macro-redefinition checks','four consecutive identifier vectors per token-kind load')
 (p/('blocks-'+suffix)).write_text(s)
