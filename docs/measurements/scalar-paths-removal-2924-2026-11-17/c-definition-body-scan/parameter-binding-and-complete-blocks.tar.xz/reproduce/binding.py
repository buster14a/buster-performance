from pathlib import Path
import difflib
p=Path(__file__).parent;old=(p/'current-lanes.c').read_text();s=old
i=s.index('static __attribute__((noinline)) void pp_define_candidate');a=s.index('            const PPMacroId previous =',i);b=s.index('            const PPMacroId id =',a)
body=s[a:b];body=body[body.index('            if (previous'):];body=body.replace('&macro)', 'macro)').replace('&macro,','macro,')
body=''.join(l[8:] if l.startswith('        ')else l for l in body.splitlines(True))
helper='''// A live cached bit can denote a poisoned name or the defined operator as well as a macro.
static __attribute__((noinline)) void pp_check_replaced_definition(Preprocessor* pp, const PPMacro* macro, IdentId name, uint32_t location)
{
    const PPMacroId previous = pp->macro_of[name];
    const uint8_t builtin = pp->macros[previous].builtin;
    if (builtin == PP_BUILTIN_POISONED || builtin == PP_BUILTIN_DEFINED)
    {
        return;
    }
'''+body+'}\n\n'
s=s[:a]+'''            if (pp_is_macro(pp, name))
            {
                pp_check_replaced_definition(pp, &macro, name, location);
            }
'''+s[b:];s=s[:i]+helper+s[i:]
a=s.index('    if (!pp->options.no_history && (name == C_NAME_FALSE');b=s.index('\n    }',a)+6
s=s[:a]+'''    if (!pp->options.no_history && (name == C_NAME_FALSE ||
        (intern_length(pp->table, name) == 4 && memcmp(intern_bytes(pp->table, name), "NULL", 4) == 0)))
    {
        pp_diagnostic_macro_change(pp, name, id);
    }'''+s[b:]
# Share one mask of plausible operators across the common no-operator path.
a=s.index('        const __mmask16 identifiers',s.index('static void pp_scan_body_word'));b=s.index('        if (hashes | optional)',a)
s=s[:a]+'''        const __mmask16 identifiers = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
        uint64_t optional = 0;
        if (identifiers != 0)
        {
            const __m512i ids = _mm512_maskz_loadu_epi32(identifiers, data->values + t);
            optional = _mm512_cmpeq_epi32_mask(ids, _mm512_set1_epi32(C_NAME_VA_OPT));
        }
        uint64_t hashes = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASH));
        found_paste |= _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASHHASH));
'''+s[b:]
f='src/buster/compiler/c_preprocessor_impl.c';(p/'binding.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f)))
for suffix in ('task','resume','defines','shape-group','corpus'):
 t=(p/('bodylanes-'+suffix)).read_text().replace('bodylanes','binding').replace('Test flag and name comparisons in contiguous replacement-list packets','Measure replacement-list scans with guarded macro-redefinition checks')
 (p/('binding-'+suffix)).write_text(t)
