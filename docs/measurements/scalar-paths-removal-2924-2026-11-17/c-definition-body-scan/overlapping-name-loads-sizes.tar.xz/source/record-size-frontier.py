from pathlib import Path
from statistics import median
from io import BytesIO
import re,tarfile
p=Path(__file__).parent
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/c-definition-body-scan')
r=p/'remainder-production-results/remainder-sizes-output'
rows=['shape\tlength\tround\tscalar_define\tdefault_define\thead_define\tscalar_whole_base\tscalar_whole_head\tdefault_whole_base\tdefault_whole_head\tstdout_sha256']
out=[];losers=[];allvalues=[]
for g,n in [('literal',75),('parameter',74),('paste',72),('stringize',73),('optional',71)]:
    fs=sorted(r.glob(g+'-*-3-default.log'));assert len(fs)==n
    ratios=[]
    for f in fs:
        prefix=f.name.removesuffix('-3-default.log');length=int(prefix.split('-')[1]); group=[]
        sha=[(r/f'{prefix}-{m}.sha').read_text().strip() for m in ('scalar','vector','head')]
        assert len(set(sha))==1 and re.fullmatch('[a-f0-9]{64}',sha[0])
        assert len({(r/f'{prefix}-{m}.err').read_bytes()for m in ('scalar','vector','head')})==1
        for i in (1,2,3):
            direct=[float(re.search(r'([\d.]+) cycles per #define',(r/f'{prefix}-{i}-{m}.define').read_text())[1])for m in ('scalar','vector','head')]
            pairs=[]
            for m in ('scalar','default'):
                s=(r/f'{prefix}-{i}-{m}.log').read_text();assert s.rstrip().endswith('time-runs: done, 0 failed processes')
                a={k:int(c)for k,c in re.findall(r'^list 1 (base|head) .*?\]: 4 runs, median .*? (\d+) user cycles,',s,re.M)}
                assert len(a)==2 and min(a.values())>0;pairs += [a['base'],a['head']]
            rows.append('\t'.join(map(str,[g,length,i,*direct,*pairs,sha[0]])))
            group.append([direct[2]/direct[0],direct[2]/direct[1],pairs[1]/pairs[0],pairs[3]/pairs[2]])
        vals=[median(x) for x in zip(*group)];ratios.append(vals);allvalues.append(vals)
        if vals[2]>1 or vals[3]>1:losers.append('| '+' | '.join([g,str(length),f'{(vals[2]-1)*100:+.3f}%',f'{(vals[3]-1)*100:+.3f}%'])+' |')
    out.append('| '+' | '.join([g,str(n),*[str(sum(x[i]<=1 for x in ratios))for i in range(4)]])+' |')
def addtext(t,name,s):
    buf=s.encode();i=tarfile.TarInfo(name);i.size=len(buf);t.addfile(i,BytesIO(buf))
name='overlapping-name-loads-sizes.tar.xz'
with tarfile.open(d/name,'w:xz')as t:
    addtext(t,'size-rounds.tsv','\n'.join(rows)+'\n')
    for fn in ['complete-body.patch','remainder-body.patch','remainder-sizes','gen-shapes.py','record-size-frontier.py','parent-case.digests']:t.add(p/fn,arcname='source/'+fn)
title='## Overlapping identifier loads on final packets'
f=d/'README.md';s=f.read_text();assert title not in s
worst=[max(x[i] for x in allvalues) for i in range(4)]
f.write_text(s.rstrip()+'\n\n'+title+'''

The scanner tests up to four overlapping, fully in-bounds vectors for the last 17 to 63 identifiers and maps each comparison mask back to the original token positions. The production definition path used fewer cycles than both the untouched scalar and default implementations at all 365 sizes. The slowest candidate/parent definition ratios were '''+f'{worst[0]:.4f} against scalar and {worst[1]:.4f} against default.'+'''

Each definition measurement used 21 passes. Complete preprocessing used four fresh processes of each executable per round. The table counts cells with a median candidate/parent ratio at most 1 over three rounds. Every output digest and diagnostic stream matched.

| Shape | Sizes | Definitions vs. scalar | Definitions vs. default | Complete vs. scalar | Complete vs. default |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(out)+'''

The complete command exceeded one or both parents in these cells.

| Shape | Tokens | Against scalar | Against default |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(losers)+f'\n\n[All paired samples, output digests, exact production changes and runner]({name})\n')
print(*out,*losers,sep='\n')
