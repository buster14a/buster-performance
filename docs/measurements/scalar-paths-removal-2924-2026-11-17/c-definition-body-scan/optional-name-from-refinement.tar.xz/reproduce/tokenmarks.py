from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent;d=p/'neighbor-source/src/buster/compiler';diff=[]
def emit(n,s):
 prior=(d/n).read_text();f='src/buster/compiler/'+n;diff.extend(unified_diff(prior.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f))
n='c_refine.c';s=(d/n).read_text()
s=s.replace('BUSTER_INLINE void refine_pass_c(const RefineIdentifiers* identifiers, uint64_t begin, uint64_t end, uint32_t* values)','BUSTER_INLINE bool refine_pass_c(const RefineIdentifiers* identifiers, uint64_t begin, uint64_t end, uint32_t* values, uint32_t watched_name)')
a=s.index('BUSTER_INLINE bool refine_pass_c');b=s.index('// Pass B',a);t=s[a:b].replace('    uint32_t position = 0;', '    uint32_t position = 0;\n    __mmask16 found = 0;').replace('        const __m512i group_ids','        found |= _mm512_mask_cmpeq_epi32_mask((__mmask16)_bzhi_u32(0xffff, live), ids, _mm512_set1_epi32((int)watched_name));\n        const __m512i group_ids')
t=t.rstrip();assert t.endswith('}');s=s[:a]+t[:-1]+'    return found != 0;\n}\n\n'+s[b:]
q='struct RefineProgress\n{';assert q in s;s=s.replace(q,q+'\n    uint32_t watched_name;\n    bool found_name;')
s=s.replace('            refine_pass_c(&identifiers, block, block_end, values);','            progress->found_name |= refine_pass_c(&identifiers, block, block_end, values, progress->watched_name);')
emit(n,s)
n='c_preprocessor.c';s=(d/n).read_text();q='struct PPFileData\n{';s=s.replace(q,q+'\n    // Set only after all interned names in this snapshot have been checked.\n    bool va_opt_absent;')
for pointer in ('chunks','backslash_chunks'):
 q='refine_progress_begin(&progress, '+pointer+');';assert s.count(q)==1;s=s.replace(q,q+'\n'+('            ' if pointer=='chunks' else '    ')+'progress.watched_name = C_NAME_VA_OPT;')
q='data->space, prepare->refine_flags, &progress);';assert s.count(q)==1;s=s.replace(q,q+'\n            data->va_opt_absent = refined && !progress.found_name;')
a=s.index('static PPPrepareStatus pp_prepare_windows(');b=s.index('        data->token_count = (uint32_t)count;',a);s=s[:b]+'        data->va_opt_absent = !progress.found_name;\n'+s[b:]
emit(n,s)
n='c_preprocessor_impl.c';s=(p/'current-lanes.c').read_text()
a=s.index('        const uint32_t count =',s.index('static void pp_scan_body_word'));b=s.index('        if (hashes | optional)',a)
s=s[:a]+'''        const uint32_t count = left < 64 ? left : 64;
        const __mmask64 active = (__mmask64)_bzhi_u64(UINT64_MAX, count);
        const __m512i kinds = _mm512_and_si512(_mm512_maskz_loadu_epi8(active, data->kinds + t), _mm512_set1_epi8(0x7f));
        uint64_t hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH)) & active;
        found_paste |= _mm512_mask_cmpeq_epi8_mask(active, kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH)) != 0;
        uint64_t optional = 0;
        if (!data->va_opt_absent)
        {
            const uint64_t named = _mm512_mask_cmpeq_epi8_mask(active, kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            for (uint32_t off = 0; off < count; off += 16)
            {
                const __mmask16 names = (__mmask16)(named >> off);
                const __m512i ids = _mm512_maskz_loadu_epi32(names, data->values + t + off);
                optional |= (uint64_t)_mm512_mask_cmpeq_epi32_mask(names, ids, _mm512_set1_epi32(C_NAME_VA_OPT)) << off;
            }
        }
'''+s[b:]
a=s.index('static void pp_scan_body_word');b=s.index('static __attribute__((noinline)) bool pp_define_marked',a)
s=s[:a]+s[a:b].replace('found_hash |= hashes;', 'found_hash |= hashes != 0;').replace('found_opt |= optional;', 'found_opt |= optional != 0;')+s[b:]
emit(n,s)
(p/'tokenmarks.patch').write_text(''.join(diff))
for tail in ('task','resume','shape-group','defines','corpus'):
 s=(p/('neighbors-'+tail)).read_text().replace('neighbors','tokenmarks').replace('token neighbors for stringizing and variadic replacement','optional-name presence collected during token refinement')
 if tail=='task':
  s=s.replace('cd checkout','until [[ -f neighbors-defines.ok ]]; do sleep 15; done\ncd checkout')
  a=s.index('for mode in 0 1 2 4; do');b=s.index('cd "$root"\n',a)
  s=s[:a]+'''ln -f build/compiler build/pp-tokenmarks-marks2
ln -sfn "$root/checkout/build/pp-tokenmarks-marks2" "$root/pp-tokenmarks2"
# Keep the untouched scalar and control compilers independent of all refinement costs.
for mode in 0 1 4;do ln -sfn "$(readlink -f "$root/pp-bodylanes$mode")" "$root/pp-tokenmarks$mode";done
'''+s[b:]
 (p/('tokenmarks-'+tail)).write_text(s)
