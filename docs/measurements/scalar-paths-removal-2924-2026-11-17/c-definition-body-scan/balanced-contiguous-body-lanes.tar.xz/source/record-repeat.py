from pathlib import Path
from statistics import median
from io import BytesIO
import re,tarfile
p=Path(__file__).parent
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/c-definition-body-scan')
rows=['shape\tlength\tround\tdefinition_s1\tdefinition_s2\tdefinition_h1\tdefinition_h2\tprocess_s1\tprocess_s2\tprocess_h1\tprocess_h2']
labels=('s1','s2','h1','h2')
groups={'literal':75,'parameter':74,'stringize':73,'paste':72,'optional':71}
samples={};table=[]
with tarfile.open(p/'repeat-native.tar.gz','r|gz')as tar:
 logs={m.name:tar.extractfile(m).read().decode() for m in tar if m.isfile()}
assert len(logs)==12775
for shape,total in groups.items():
 matches=list(re.finditer(r'^repeated-bodylanes/'+shape+r'-(\d+)-1.log$', '\n'.join(logs),re.M))
 lengths=sorted(int(m[1])for m in matches)
 assert len(lengths)==total and len(set(lengths))==total
 cells=[]
 for n in lengths:
  asites=[];bprocess=[]
  for run in range(1,8):
   name=f'repeated-bodylanes/{shape}-{n}-{run}'
   s=logs[name+'.log'];assert s.rstrip().endswith('time-runs: done, 0 failed processes')
   cycles={k:int(c)for k,c in re.findall(r'^list 1 (s1|s2|h1|h2) .*?\]: 4 runs, median .*? (\d+) user cycles,',s,re.M)}
   assert set(cycles)==set(labels)
   site=[]
   for k in labels:
    m=re.search(r'([\d.]+) cycles per #define .* cycles per lookup\s*$',logs[name+'-'+k+'.log']);assert m;site.append(float(m[1]))
   assert min(site)>0 and min(cycles.values())>0
   whole=[cycles[k]for k in labels]
   asites.append(sum(site[2:])/sum(site[:2]));bprocess.append(sum(whole[2:])/sum(whole[:2]))
   rows.append('\t'.join(map(str,[shape,n,run,*site,*whole])))
  cells.append((median(asites),median(bprocess),n))
 samples[shape]=cells
 table.append(f'| {shape} | {sum(a<=1 for a,b,n in cells)}/{total} | {max(a for a,b,n in cells):.4f} | {sum(b<=1 for a,b,n in cells)}/{total} | {max(b for a,b,n in cells):.4f} |')
z=sum(samples.values(),[]);print(*table,sep='\n');print('totals',sum(a<=1 for a,b,n in z),sum(b<=1 for a,b,n in z))
with tarfile.open(d/'balanced-contiguous-body-lanes.tar.xz','w:xz')as t:
 for n in ('bodylanes-repeat','repeat-recover.py','bodylanes.patch','record-repeat.py'):t.add(p/n,arcname='source/'+n)
 t.add(p/'repeat-native.tar.gz',arcname='native.tar.gz')
 data=('\n'.join(rows)+'\n').encode();info=tarfile.TarInfo('rounds.tsv');info.size=len(data);t.addfile(info,BytesIO(data))
heading='## Seven balanced rounds at each macro-body length'
f=d/'README.md';s=f.read_text();assert heading not in s
f.write_text(s.rstrip()+'\n\n'+heading+'''

Four aliases rotated launch order in each of seven rounds at every size. Two aliases used the scalar replacement-list scan and two used the contiguous sixteen-token vector implementation. For each input, the table uses the median of seven paired ratios of the combined vector counters to the combined scalar counters. Each definition-only observation uses the existing cycles-per-definition benchmark. Each complete-command observation is a median over four fresh preprocessing processes.

| Body | Direct lengths meeting scalar | Slowest direct ratio | Complete lengths meeting scalar | Slowest complete ratio |
| --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(table)+f'''

Across all five body shapes, the vector method met scalar at {sum(a<=1 for a,b,n in z)} of 365 direct comparisons and {sum(b<=1 for a,b,n in z)} of 365 complete preprocessing comparisons.

[Four-alias samples for every size and round, raw counters, runner and implementation patch](balanced-contiguous-body-lanes.tar.xz)
''')
