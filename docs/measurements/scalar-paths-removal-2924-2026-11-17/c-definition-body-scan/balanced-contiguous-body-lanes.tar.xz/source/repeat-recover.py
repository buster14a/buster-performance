from pathlib import Path
import re,os,subprocess
p=Path('/dev/shm/buster-pp-publish-6b097f86')
os.chdir(p)
os.environ.update(EXCLUSIVE_OWNER='codex-ppbody-6b097f86',EXCLUSIVE_TITLE='Repeat each macro body size with balanced launches',EXCLUSIVE_LINK='https://github.com/buster14a/buster/issues/2924')
files=sorted(Path('shape-input').glob('*.c'))
assert len(files)==365
def valid(f,r):
    base=Path('repeated-bodylanes')/(f.stem+'-'+str(r))
    try:
        if Path(str(base)+'.log').read_bytes().splitlines()[-1]!=b'time-runs: done, 0 failed processes':return False
        for label in ('s1','h1','h2','s2'):
            v=Path(str(base)+'-'+label+'.log').read_bytes().splitlines()[-1]
            if not re.search(rb'\d[.\d]* cycles per #define .* cycles per lookup\s*$',v):return False
    except (FileNotFoundError,IndexError):return False
    return True
for r in range(1,8):
    missing=[f for f in files if not valid(f,r)]
    print(r,len(missing),flush=True)
    for i in range(0,len(missing),10):
        subprocess.run([str(Path.home()/'buster-fast-bench/exclusive.sh'),'taskset','-c','2','bash','bodylanes-repeat',str(r),*missing[i:i+10]],check=True)
    assert all(valid(f,r) for f in files)
Path('repeated-bodylanes.ok').touch()
