from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,difflib
p=Path(__file__).parent;f='src/buster/compiler/c_preprocessor_impl.c';base=(p/'current-tree'/f).read_text()
with TemporaryDirectory()as tmp:
 d=Path(tmp);q=d/f;q.parent.mkdir(parents=True);q.write_text(base)
 for n in ('operators','publication'):subprocess.run(['git','apply',str(p/(n+'.patch'))],cwd=d,check=True)
 old=q.read_text()
a=old.index('            for (uint32_t off = 0; off < 64; off += 16)',old.index('static void pp_scan_body_word'));b=old.index('            cache->optional = optional;',a)
s=old[:a]+'''            if (identifiers != 0 && left >= 64)
            {
                _Static_assert(C_NAME_VA_OPT > 0 && C_NAME_VA_OPT < UINT8_MAX, "optional name fits between saturation endpoints");
                const uint32_t* ids = data->values + word;
                const __m512i ab = _mm512_packs_epi32(_mm512_loadu_si512(ids), _mm512_loadu_si512(ids + 16));
                const __m512i cd = _mm512_packs_epi32(_mm512_loadu_si512(ids + 32), _mm512_loadu_si512(ids + 48));
                const __m512i order = _mm512_setr_epi32(0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15);
                const __m512i packed = _mm512_permutexvar_epi32(order, _mm512_packus_epi16(ab,cd));
                optional = identifiers & _mm512_cmpeq_epi8_mask(packed, _mm512_set1_epi8((char)C_NAME_VA_OPT));
            }
            else
            {
'''+ '\n'.join('    '+l for l in old[a:b].rstrip().splitlines())+'''
            }
'''+old[b:]
(p/'packednames.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f)))
for suffix in ('task','resume','defines','shape-group','corpus'):
 s=(p/('publication-'+suffix)).read_text().replace('publication','packednames').replace('Test packednamesing','Test packing').replace('Measure definition packednames and diagnostic visibility','Pack 64 token identifiers to classify replacement operators')
 (p/('packednames-'+suffix)).write_text(s)
