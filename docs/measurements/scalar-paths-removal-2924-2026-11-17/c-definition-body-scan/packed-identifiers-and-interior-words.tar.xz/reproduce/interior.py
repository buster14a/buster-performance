from pathlib import Path
import difflib
p=Path(__file__).parent;f='src/buster/compiler/c_preprocessor_impl.c';s=(p/'live'/f).read_text();old=s
# Stream complete interior words without publishing a cache entry. The marks that require the ordered
# validator continue through the ordinary bounded-word handling.
a=s.index('        const uint32_t word = t & ~63u;',s.index('static void pp_scan_body_word'))
s=s[:a]+'''        if (end - t >= 64)
        {
            const __m512i kinds = _mm512_and_si512(_mm512_loadu_si512(data->kinds + t), _mm512_set1_epi8(0x7f));
            const __mmask64 hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH));
            const __mmask64 pastes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH));
            const __mmask64 names = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            __mmask16 possible = 0;
            if (names != 0)
            {
                const __m512i opt_id = _mm512_set1_epi32(C_NAME_VA_OPT);
                const uint32_t* ids = data->values + t;
                possible = _mm512_mask_cmpeq_epi32_mask((__mmask16)names, _mm512_loadu_si512(ids), opt_id) |
                           _mm512_mask_cmpeq_epi32_mask((__mmask16)(names >> 16), _mm512_loadu_si512(ids + 16), opt_id) |
                           _mm512_mask_cmpeq_epi32_mask((__mmask16)(names >> 32), _mm512_loadu_si512(ids + 32), opt_id) |
                           _mm512_mask_cmpeq_epi32_mask((__mmask16)(names >> 48), _mm512_loadu_si512(ids + 48), opt_id);
            }
            if (hashes == 0 && possible == 0)
            {
                found_paste |= pastes;
                t += 64;
                continue;
            }
        }
'''+s[a:]
a=s.index('            const uint32_t first = begin + 2;',s.index('static __attribute__((noinline)) bool pp_define_marked'))
b=s.index('        }\n        else if (begin + 1',a)
s=s[:a]+'''            const uint32_t first = begin + 2;
            const uint32_t count = end - first;
            const uint8_t kind = count ? data->kinds[first] & 0x7f : C_TOKEN_UNKNOWN;
            const bool named = kind == C_TOKEN_RAW_IDENTIFIER;
            const bool one = named && count >= 2 && (data->kinds[first + 1] & 0x7f) == C_TOKEN_R_PAREN;
            const bool variadic = (kind == C_TOKEN_ELLIPSIS && count >= 2 && (data->kinds[first + 1] & 0x7f) == C_TOKEN_R_PAREN) ||
                                  (named && count >= 4 && (data->kinds[first + 1] & 0x7f) == C_TOKEN_COMMA &&
                                   (data->kinds[first + 2] & 0x7f) == C_TOKEN_ELLIPSIS && (data->kinds[first + 3] & 0x7f) == C_TOKEN_R_PAREN);
            if (kind == C_TOKEN_R_PAREN || one || variadic)
            {
                macro.flags |= BUSTER_PP_MACRO_FUNCTION | (variadic ? BUSTER_PP_MACRO_VARIADIC : 0);
                macro.parameters_begin = first;
                macro.parameter_count = named + variadic;
                macro.body_begin = first + (variadic ? (named ? 4 : 2) : 1 + named);
            }
            else
            {
                valid = pp_define_parameters(pp, data, &macro, begin + 1, end, &parameters);
            }
'''+s[b:]
(p/'interior.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f)))
for suffix in ('task','resume','defines','shape-group','corpus'):
 t=(p/('packednames-'+suffix)).read_text().replace('packednames','interior').replace('Pack 64 token identifiers to classify replacement operators','Stream complete macro-body words and parse common parameter lists once')
 if suffix=='task':
  t=t.replace('git apply "$root/interior.patch"', 'git apply -R "$root/namedpublication.patch"\ngit apply "$root/interior.patch"')
  t=t+'bash interior-defines\n'
 (p/('interior-'+suffix)).write_text(t)
