from pathlib import Path
p=Path('src/buster/compiler/c_preprocessor_impl.c');s=p.read_text()
a=s.index('static bool pp_check_replacement_list(');b=s.index('\n}\n',a)+3;old=s[a:b]
new=old.replace('pp_check_replacement_list(', 'pp_check_replacement_events(')
i=new.index('    for (uint32_t t = macro->body_begin');j=new.index('        const uint8_t kind',i)
new=new[:i]+'''    for (uint32_t first = macro->body_begin; result && first < end;)
    {
        const uint32_t count = end - first < 16 ? end - first : 16;
        const __mmask16 live = (__mmask16)_bzhi_u32(UINT16_MAX, count);
        const __m128i kinds = _mm_and_si128(_mm_maskz_loadu_epi8(live, data->kinds + first), _mm_set1_epi8(0x7f));
        const __mmask16 ids = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
        const __mmask16 opts = ids == 0 ? 0 : _mm512_mask_cmpeq_epi32_mask(ids & live, _mm512_maskz_loadu_epi32(ids & live, data->values + first), _mm512_set1_epi32(C_NAME_VA_OPT));
        uint32_t events = opts | _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASH));
        if (va_opt_depth != 0 || opts != 0)
        {
            events |= _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_L_PAREN)) |
                      _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_R_PAREN));
        }
        events &= live;
        while (result && events != 0)
        {
            const uint32_t lane = (uint32_t)__builtin_ctz(events);
            const uint32_t t = first + lane;
            events &= events - 1;
'''+new[j:]
a2=new.index('        const uint8_t kind =');e=new.index('\n    }\n    if (result && va_opt_depth',a2)
part=new[a2:e].replace('            t += 1;', '''            // The opening parenthesis was consumed here, including at the next block's first lane.
            events &= ~(UINT32_C(1) << (lane + 1));''').replace('else if (va_opt_depth != 0 && kind == C_TOKEN_L_PAREN)', 'else if (va_opt_depth != 0 && t != va_opt_open && kind == C_TOKEN_L_PAREN)')
part='\n'.join('    '+v if v else '' for v in part.split('\n'))
new=new[:a2]+part+'\n        }\n        first += count;'+new[e:]
s=s[:b]+new+s[b:]
a=s.index('static __attribute__((noinline)) bool pp_define_marked(');b=s.index('\n}\n',a)+3
s=s[:a]+s[a:b].replace('pp_check_replacement_list(', 'pp_check_replacement_events(')+s[b:]
p.write_text(s)
