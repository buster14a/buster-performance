from pathlib import Path
p=Path('src/buster/compiler/c_preprocessor_impl.c');s=p.read_text()
a=s.index('// Adjacent definitions often share');b=s.index('static __attribute__((noinline)) bool pp_define_marked',a)
scan=s[a:b].replace('static void pp_scan_body_word(Preprocessor* pp, uint32_t file, const PPFileData* data, uint32_t begin, uint32_t end, bool* paste, bool* hash, bool* opt)','static uint8_t pp_definition_marks(PPBodyWordCache* cache, const PPFileData* data, uint32_t begin, uint32_t end)').replace('    PPBodyWordCache* cache = &pp->replacement_word;\n','').replace('cache->file != file + 1 || cache->word != word','cache->word != word').replace('            cache->file = file + 1;\n','').replace('    *paste = found_paste != 0;\n    *hash = found_hash != 0;\n    *opt = found_opt != 0;','    return (uint8_t)((found_paste != 0) | ((found_hash != 0) << 1) | ((found_opt != 0) << 2));')
s=s[:a]+s[b:]
s=s.replace('        pp->replacement_word.file = 0;\n','')
for name in ('pp_define_candidate','pp_define'):
 key='void '+name+'(Preprocessor* pp, uint32_t data_index, uint32_t base, uint32_t begin, uint32_t end)'
 assert key in s;s=s.replace(key,key[:-1]+', uint8_t marks)')
s=s.replace('pp_define_candidate(pp, data_index, base, begin, end);','pp_define_candidate(pp, data_index, base, begin, end, marks);')
s=s.replace('pp_define(pp, data_index, base, hash + 2, end);','pp_define(pp, data_index, base, hash + 2, end, data->definition_marks[d]);')
a=s.index('static __attribute__((noinline)) void pp_define_candidate(');b=s.index('\n}',a)
c=s[a:b];a1=c.index('            bool pastes;');b1=c.index('            macro.flags |= pastes',a1)
c=c[:a1]+'''            const bool pastes = (marks & 1) != 0;
            const bool hashes = (marks & 2) != 0;
            const bool va_opt = (marks & 4) != 0;
'''+c[b1:];s=s[:a]+c+s[b:]
s=s.replace('    data->directive_kind = record->directive_kind;', '    data->definition_marks = record->definition_marks;\n    data->directive_kind = record->directive_kind;')
p.write_text(s)
p=Path('src/buster/compiler/c_preprocessor.c');s=p.read_text();s=s.replace('    PPBodyWordCache replacement_word;\n','').replace('    uint8_t* directive_kind;', '    uint8_t* directive_kind;\n    uint8_t* definition_marks;',1)
s=s.replace('    data->directive_kind = arena_push(arena, count + 1, 1);','''    data->directive_kind = arena_push(arena, 2 * ((uint64_t)count + 1), 1);
    data->definition_marks = data->directive_kind != NULL ? data->directive_kind + (uint64_t)count + 1 : NULL;''')
a=s.index('// Each directive\'s kind and line end');s=s[:a]+scan+s[a:]
a=s.index('static bool pp_finish_directives(');b=s.index('\n}',a)
c=s[a:b].replace('    bool elifdef = false;', '    PPBodyWordCache cache = { .word = UINT32_MAX };\n    bool elifdef = false;').replace('        data->directive_kind[d] = kind;', '''        data->directive_kind[d] = kind;
        if (kind == PP_DIRECTIVE_DEFINE)
        {
            data->definition_marks[d] = pp_definition_marks(&cache, data, hash + 3, end);
        }''')
s=s[:a]+c+s[b:];p.write_text(s)
p=Path('src/buster/compiler/c_preprocessor_benchmark.c');s=p.read_text()
s=s.replace('data->directive_hash[d] + 2, data->directive_end[d]);','data->directive_hash[d] + 2, data->directive_end[d], data->definition_marks[d]);')
assert 'data->definition_marks[d]' in s;p.write_text(s)
