from pathlib import Path
import re
p=Path('src/buster/compiler/c_preprocessor.c');s=p.read_text()
s=s.replace('struct Preprocessor\n{','''typedef struct PPBodyWordCache PPBodyWordCache;
struct PPBodyWordCache
{
    uint32_t file;
    uint32_t word;
    uint64_t hashes;
    uint64_t pastes;
    uint64_t optional;
};

struct Preprocessor
{
    PPBodyWordCache replacement_word;''')
p.write_text(s)
p=Path('src/buster/compiler/c_preprocessor_impl.c');s=p.read_text()
a=s.index('static __attribute__((noinline)) bool pp_define_marked(')
s=s[:a]+'''// Adjacent definitions often share a 64-token word. Classify it only when an active definition uses it.
static void pp_scan_body_word(Preprocessor* pp, uint32_t file, const PPFileData* data, uint32_t begin, uint32_t end, bool* paste, bool* hash, bool* opt)
{
    PPBodyWordCache* cache = &pp->replacement_word;
    uint64_t found_paste = 0;
    uint64_t found_hash = 0;
    uint64_t found_opt = 0;
    for (uint32_t t = begin; t < end;)
    {
        const uint32_t word = t & ~63u;
        if (cache->file != file + 1 || cache->word != word)
        {
            const __mmask64 live = _bzhi_u64(UINT64_MAX, data->token_count - word);
            const __m512i kinds = _mm512_and_si512(_mm512_maskz_loadu_epi8(live, data->kinds + word), _mm512_set1_epi8(0x7f));
            cache->file = file + 1;
            cache->word = word;
            cache->hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH));
            cache->pastes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH));
            uint64_t identifiers = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER)) & live;
            uint64_t optional = 0;
            for (uint32_t off = 0; identifiers != 0; off += 16)
            {
                const __mmask16 named = (__mmask16)identifiers;
                if (named != 0)
                {
                    const __m512i values = _mm512_maskz_loadu_epi32(named, data->values + word + off);
                    optional |= (uint64_t)_mm512_mask_cmpeq_epi32_mask(named, values, _mm512_set1_epi32(C_NAME_VA_OPT)) << off;
                }
                identifiers >>= 16;
            }
            cache->optional = optional;
        }
        const uint32_t offset = t - word;
        const uint32_t count = end - t < 64 - offset ? end - t : 64 - offset;
        const uint64_t body = _bzhi_u64(UINT64_MAX, count) << offset;
        found_paste |= body & cache->pastes;
        found_hash |= body & cache->hashes;
        found_opt |= body & cache->optional;
        t += count;
    }
    *paste = found_paste != 0;
    *hash = found_hash != 0;
    *opt = found_opt != 0;
}

'''+s[a:]
a=s.index('static void pp_define(Preprocessor*');b=s.index('\n}',a);q=s[a:b]
i=q.index('            if (BUSTER_VECTOR_PATH(pp->vectorized))');j=q.index('            if (pastes || hashes || va_opt)',i)
q=q[:i]+'''            pp_scan_body_word(pp, data_index, data, macro.body_begin, macro.body_end, &pastes, &hashes, &va_opt);
            macro.flags |= pastes ? BUSTER_PP_MACRO_PASTES : 0;
            const bool bad_end = pastes && ((data->kinds[macro.body_begin] & 0x7f) == C_TOKEN_HASHHASH || (data->kinds[macro.body_end - 1] & 0x7f) == C_TOKEN_HASHHASH);
'''+q[j:].replace('if (pastes || hashes || va_opt)','if (bad_end || hashes || va_opt)',1)
s=s[:a]+q+s[b:]
s=s.replace('        FileCache* cache = pp->cache;\n        for (uint32_t r', '        pp->replacement_word.file = 0;\n        FileCache* cache = pp->cache;\n        for (uint32_t r')
p.write_text(s)
