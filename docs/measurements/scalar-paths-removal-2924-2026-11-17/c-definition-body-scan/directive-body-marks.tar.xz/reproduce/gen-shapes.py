from pathlib import Path
p=Path('shape-input');p.mkdir(exist_ok=True)
lengths=[*range(0,66),95,96,97,127,128,129,255,256,257]
for group,minimum in [('literal',0),('parameter',1),('stringize',2),('paste',3),('optional',4)]:
 for n in lengths:
  if n<minimum:continue
  out=[]
  prefix={'literal':[],'parameter':[],'stringize':['#','x'],'paste':['x','##','x'],'optional':['__VA_OPT__','(','x',')']}[group]
  for i in range(256):
   name=f'Macro{i}'
   body=prefix+(['123' if group=='literal' else 'x']*(n-len(prefix)))
   signature=name+('' if group=='literal' else '(x,...)' if group=='optional' else '(x)')
   out.append('#define '+signature+' '+' '.join(body))
   if i%16==0:
    out.append(name+('' if group=='literal' else '(token,1)' if group=='optional' and i%32==0 else '(token)'))
  (p/f'{group}-{n}.c').write_text('\n'.join(out)+'\n')
