from pathlib import Path
import tarfile
p=Path(__file__).parent;d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/c-definition-body-scan')
r=p/'results'
def diagnostics(f):return [l for l in f.read_text().splitlines()if 'embedding a directive within macro arguments has undefined behavior' in l]
count=before=equal=0;remaining=set()
for f in (r/'clang').glob('*.err'):
 old=r/'parent'/f.name;new=r/'final'/f.name
 assert diagnostics(f)==diagnostics(new)
 assert f.with_suffix('.status').read_bytes()==new.with_suffix('.status').read_bytes()
 count+=1;before+=diagnostics(f)!=diagnostics(old);equal+=f.read_bytes()==new.read_bytes()
 if f.read_bytes()!=new.read_bytes():remaining.add(f.name.split('.c-')[0])
assert (count,before,equal)==(126,64,96)
assert remaining=={'builtin','include','numeric','pragma','pragma-diagnostic'}
assert '86 cases, 0 differ' in (r/'final-carets.log').read_text()
assert 'cases: 0 of 419 fail' in (r/'final-frozen.log').read_text() and (r/'final-frozen.log').read_text().count('0 unverified), 0 differ')==2
name='embedded-directive-diagnostic-controls.tar.xz'
with tarfile.open(d/name,'w:xz')as t:
 for v in ['controls','oracle','final.patch','embedded-directives.c','catalog.tsv','record.py','verify-fixtures']:t.add(p/v,arcname='source/'+v)
 for v in ['parent','clang','final','final-frozen.log','final-carets.log']:t.add(r/v,arcname='results/'+v)
title='## The embedded-directive warning exposed by the macro control';f=d/'README.md';s=f.read_text();assert title not in s
f.write_text(s.rstrip()+'\n\n'+title+f'''

A separate compiler change issues Clang’s embedded-directive diagnostic during function-like macro argument collection. The controls cover accepted directives, unconditional rejections, conditional skipping, builtin operands, command-line options, and pragma push and pop. The parent differed on the targeted diagnostic in 64 of 126 runs. The corrected compiler matched Clang’s message, position, severity and option in all 126, including the cases where Clang stays quiet. All 126 exit statuses matched. Complete stderr matched in 96 runs. Thirty retained an additional pre-existing difference in a macro expansion note, a malformed line marker diagnostic, or the scratch-space note for an invalid builtin pragma.

The complete caret suite matched Clang in all 86 cases, including the three new invocations. All 419 frozen preprocessing cases and 128 generated Clang comparisons passed.

[Inputs, compiler changes, expected and actual stderr, exit codes and full suite logs]({name})
''')
