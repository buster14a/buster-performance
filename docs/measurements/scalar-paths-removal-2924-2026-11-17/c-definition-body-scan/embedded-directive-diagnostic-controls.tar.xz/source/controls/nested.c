#define F(x) x
F(
#if 0
#define V 4
#endif
X)
