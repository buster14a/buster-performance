#define F(x) x
F(
#undef FOO
X)
