#define F(x) x
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wembedded-directive"
F(
#define A 1
A)
#pragma clang diagnostic pop
F(
#undef A
0)
