#define F(x) x
F(
#define A 1
A)
