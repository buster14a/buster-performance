#define F(x) x
F(
#if 1
2
#endif
X)
