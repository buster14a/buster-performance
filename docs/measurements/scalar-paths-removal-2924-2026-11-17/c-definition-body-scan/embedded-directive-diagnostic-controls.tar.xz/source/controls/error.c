#define F(x) x
F(
#error example
X)
