#define F(x) x
F(
#
X)
