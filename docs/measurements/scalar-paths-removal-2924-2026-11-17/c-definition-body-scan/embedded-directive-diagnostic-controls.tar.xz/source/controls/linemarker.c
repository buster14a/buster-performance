#define F(x) x
F(
# 1 "orig.c"
X)
