#define F(x) x
F(
#include "x.h"
X)
