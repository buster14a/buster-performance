#define F(x) x
F(
#pragma once
X)
