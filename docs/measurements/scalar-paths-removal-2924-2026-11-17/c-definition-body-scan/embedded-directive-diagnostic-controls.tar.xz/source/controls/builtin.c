_Pragma(
#define B 1
"message hello")
