#define F(x) x
F(
#pragma clang diagnostic push
X)
