#define F(x) x
F(
#define V 4
X)
