#define F(x) x
F(
#ifdef FOO
2
#else
3
#endif
X)
