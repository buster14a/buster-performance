#define F(x) x
F(
#warning message
X)
