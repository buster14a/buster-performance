#define F(x) x
F(
# 123 4
X)
