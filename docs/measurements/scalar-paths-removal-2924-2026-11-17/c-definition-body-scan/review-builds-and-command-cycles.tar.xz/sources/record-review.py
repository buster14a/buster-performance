from pathlib import Path
from statistics import median
from io import BytesIO
import re,tarfile
from matrix import sample
p=Path(__file__).parent
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/c-definition-body-scan')
name='review-builds-and-command-cycles.tar.xz'
tab=[];corpora=[]
with tarfile.open(d/name,'w:xz') as t:
 def add(fn,txt):
  b=txt.encode();f=tarfile.TarInfo(fn);f.size=len(b);t.addfile(f,BytesIO(b))
 for v,label in [('review','Review before window-test adjustment'),('finalreview','PR b221c08aa'),('packedops','Operator flags returned together'),('adjacent','Adjacent definition lines')]:
  r=p/(v+'-production-results');rows,cs=sample(v)
  add(v+'/measurements.tsv','shape\ttokens\tround\tscalar_define\tdefault_define\thead_define\tscalar_base_cycles\tscalar_head_cycles\tdefault_base_cycles\tdefault_head_cycles\tstdout_sha256\n'+'\n'.join('\t'.join(map(str,row))for row in rows)+'\n')
  add(v+'/cell-ratios.tsv','shape\ttokens\tdefine_scalar\tdefine_default\tcommand_scalar\tcommand_default\n'+'\n'.join('\t'.join(map(str,row)) for row in cs)+'\n')
  nums=[sum(c[i]<=1 for c in cs)for i in range(2,6)]
  worst=[f'{100*(max(c[i]for c in cs)-1):+.3f}%'for i in (4,5)]
  tab.append('| '+' | '.join(map(str,[label,*nums,*worst]))+' |')
  oracle=next(r.glob('*oracle*.log'));s=oracle.read_text();assert s.count('0 unverified), 0 differ')==2 and '0 of 240 sources differ' in s and '0 of 1041 checks fail' in s
  t.add(oracle,arcname=v+'/'+oracle.name)
  if v!='review':
   for corpus in ['lua','sqlite','musl']:
    f=r/f'{v}-{corpus}';c=[]
    for ext in ['sha','err']:
     assert len({(f/f'{m}-{side}.{ext}').read_bytes()for m in ['default','scalar']for side in ['base','head']})==1
    for mode in ['default','scalar']:
     l=(f/(mode+'.log')).read_text();assert l.rstrip().endswith('ab: done, 0 failed runs')
     vals=[]
     for row in l.split('time-runs: done, 0 failed processes')[:-1]:
      pair={k:int(u) for k,u in re.findall(r'^list 1 (base|head) .*?\]: 4 runs, median .*? (\d+) user cycles,',row,re.M)}
      assert len(pair)==2;vals.append(pair['head']/pair['base'])
     assert len(vals)==7;c.append(f'{100*(median(vals)-1):+.3f}%')
    corpora.append('| '+' | '.join([label,corpus,*c])+' |');t.add(f,arcname=v+'/'+corpus)
 for n in ['matrix.py','record-review.py','gen-shapes.py','parent-case.digests','review-body.patch','final-review-v2.patch','packed-operators.patch','adjacent-defines.patch','review-sizes','finalreview-sizes','finalreview-corpus','packedops-sizes','packedops-corpus','adjacent-sizes','adjacent-corpus']:t.add(p/n,arcname='sources/'+n)
title='## The reviewed scanner and two changes to definition dispatch'
read=d/'README.md';s=read.read_text();assert title not in s
read.write_text(s.rstrip()+'\n\n'+title+'''

The 365 input shapes were measured on each compiled review image, including after a test driver changed its window sizes. Each count is the number of input shapes whose median of three paired ratios met its parent. Each complete command ran four fresh processes per executable per pair. Every output and diagnostic stream agreed. The direct definition timings used 21 passes per process.

| Build | Definitions vs. scalar | Definitions vs. default | Complete vs. scalar | Complete vs. default | Worst complete vs. scalar | Worst complete vs. default |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(tab)+'''

Each corpus used seven paired rounds. Percent changes use the median ratio of process user cycles. The corpora contain 34 Lua translation units, the SQLite amalgamation, and 1,336 musl translation units.

| Build | Corpus | Default | Scalar flag |
| --- | --- | ---: | ---: |
'''+ '\n'.join(corpora)+f'\n\n[Every size and round, source deltas, full corpus receipts and Clang comparisons]({name})\n')
print(*tab,*corpora,sep='\n')
