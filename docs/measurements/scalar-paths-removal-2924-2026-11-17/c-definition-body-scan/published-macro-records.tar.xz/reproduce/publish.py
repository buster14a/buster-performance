from pathlib import Path
p=Path('src/buster/compiler/c_preprocessor_impl.c')
s=p.read_text()
a=s.index('// A new macro record (id from 1).')
b=s.index('\nstatic void pp_define_builtin',a)
old=s[a:b]
new=old.replace('static PPMacroId pp_new_macro(Preprocessor* pp, IdentId name)','BUSTER_INLINE PPMacroId pp_append_macro(Preprocessor* pp, const PPMacro* macro)').replace('(PPMacro){ .name = name };','*macro;')
# Reuse the allocation and capacity handling for all macro sources.
new+='''\nstatic PPMacroId pp_new_macro(Preprocessor* pp, IdentId name)
{
    const PPMacro macro = { .name = name };
    return pp_append_macro(pp, &macro);
}
'''
s=s[:a]+new+s[b:]
a=s.index('\nstatic void pp_define(Preprocessor*');b=s.index('\n}',a)
s=s[:a]+s[a:b].replace('const PPMacroId id = pp_new_macro(pp, name);','const PPMacroId id = pp_append_macro(pp, &macro);').replace('                pp->macros[id] = macro;\n','')+s[b:]
# A single load and comparison identify the cached token block.
f=Path('src/buster/compiler/c_preprocessor.c');q=f.read_text();a=q.index('struct PPBodyWordCache\n');b=q.index('\n};',a)
q=q[:a]+q[a:b].replace('    uint32_t file;\n    uint32_t word;', '    uint64_t block;')+q[b:];f.write_text(q)
s=s.replace('if (cache->file != file + 1 || cache->word != word)', 'const uint64_t block = ((uint64_t)file + 1) << 32 | word;\n        if (cache->block != block)').replace('            cache->file = file + 1;\n            cache->word = word;', '            cache->block = block;').replace('pp->replacement_word.file = 0;', 'pp->replacement_word.block = 0;')
p.write_text(s)
