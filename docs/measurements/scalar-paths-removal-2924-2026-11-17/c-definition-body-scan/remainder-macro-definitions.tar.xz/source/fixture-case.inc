static const PPTestCase fixture_case = {
.name = "replacement operators across a full token packet",
            .source = "#define E\n"
                      "#define S(x) "
                      "E E E E E E E E E E E E E E E E "
                      "E E E E E E E E E E E E E E E E "
                      "E E E E E E E E E E E E E E E E "
                      "E E E E E E E E E E E E E E E #x\n"
                      "#define V(x, ...) "
                      "E E E E E E E E E E E E E E E E "
                      "E E E E E E E E E E E E E E E E "
                      "E E E E E E E __VA_OPT__(x) E E E E E E E E "
                      "E E E E E E E E E E E E E E E E "
                      "E E E x ## suffix\n"
                      "S(word)\n"
                      "V(arg)\n"
                      "V(arg, yes)\n",
            .standard = "c23",
            .expected = "\"word\" argsuffix arg argsuffix",
};
