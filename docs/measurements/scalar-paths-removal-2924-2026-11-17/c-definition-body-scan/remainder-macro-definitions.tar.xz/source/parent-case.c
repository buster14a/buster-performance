#include "buster/compiler/main_unit_frontend.c"
#include "fixture-case.inc"
int main(int argc, char**argv)
{
    return argc==2 && pp_test_case(&fixture_case, argv[1], true) ? 0 : 1;
}
