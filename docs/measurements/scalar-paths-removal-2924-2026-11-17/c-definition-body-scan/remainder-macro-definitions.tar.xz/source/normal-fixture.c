#define E
#define S(x) E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E #x
#define V(x, ...) E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E E __VA_OPT__(x) E E E E E E E E E E E E E E E E E E E E E E E E E E E x ## suffix
S(word)
V(arg)
V(arg, yes)
