from pathlib import Path
p=Path('src/buster/compiler/c_preprocessor.c');s=p.read_text().replace('struct PPFileData\n{','''struct PPFileData
{
    // Zero until a live replacement first needs identifier classification. Two records that
    // share lexical bytes may calculate this private hint independently.
    uint8_t va_opt_spelling;''')
p.write_text(s)
p=Path('src/buster/compiler/c_preprocessor_impl.c');s=p.read_text();a=s.index('// Adjacent definitions often share')
s=s[:a]+'''// A phase-1 or phase-2 escape can synthesize preprocessor spelling characters. On those
// inputs retain the normal identifier comparison. Otherwise the bytes suffice to rule out __VA_OPT__.
static bool pp_body_may_have_va_opt(Preprocessor* pp, uint32_t file)
{
    PPFileData* data = &pp->datas[file];
    if (data->va_opt_spelling == 0)
    {
        const uint8_t* bytes = data->bytes;
        const uint32_t length = data->length;
        const bool escaped = length != 0 && (memchr(bytes, '\\\\', length) != NULL || memchr(bytes, '?', length) != NULL);
        const bool spelled = !escaped && length >= 10 && memmem(bytes, length, "__VA_OPT__", 10) != NULL;
        data->va_opt_spelling = escaped || spelled ? 1 : 2;
    }
    return data->va_opt_spelling == 1;
}

'''+s[a:]
needle='            uint64_t optional = 0;';assert s.count(needle)==1
s=s.replace(needle,'''            if (identifiers != 0 && !pp_body_may_have_va_opt(pp, file))
            {
                identifiers = 0;
            }
'''+needle)
# A file's lexical snapshot may be replaced after an include-context restart.
mark='        pp->replacement_word.file = 0;';assert s.count(mark)==1
s=s.replace(mark,mark+'\n        for (uint32_t f = 0; f < pp->data_count; f += 1) pp->datas[f].va_opt_spelling = 0;')
p.write_text(s)
