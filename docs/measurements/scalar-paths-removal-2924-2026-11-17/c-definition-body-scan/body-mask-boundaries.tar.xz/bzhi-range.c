#include <immintrin.h>
#include <stdio.h>
#include <stdint.h>
__attribute__((noinline)) static uint64_t lanes(uint32_t n){return _bzhi_u64(UINT64_MAX,n);}
int main(void){unsigned ns[]={63,64,65,255,256,257,319,320,511,512,1025};for(unsigned i=0;i<sizeof(ns)/sizeof(*ns);i++)printf("%u %016lx\n",ns[i],lanes(ns[i]));}
