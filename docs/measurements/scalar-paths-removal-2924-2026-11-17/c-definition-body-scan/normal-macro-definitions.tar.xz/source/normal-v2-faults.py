from pathlib import Path
p=Path(__file__).parent
s=(p/'production/src/buster/compiler/c_preprocessor_impl.c').read_text()
start=s.index('static void pp_scan_definition_body(');s=s[start:s.index('\n}\n',start)+3]
changes=[None,('0, 4, 8, 12, 1, 5, 9, 13','0, 4, 8, 12, 2, 5, 9, 13'),('data->values[token + 1] == formal','data->values[token + 1] != formal'),('(data->kinds[token + 3] & 0x7f) == C_TOKEN_R_PAREN','(data->kinds[token + 3] & 0x7f) == C_TOKEN_L_PAREN'),('found_hash |= hashes != 0','found_hash |= (uint32_t)hashes'),('if (named != 0)','if (named == 0)'),('_mm_maskz_loadu_epi8(active, data->kinds + t)','_mm_loadu_si128((const __m128i*)(data->kinds + t))')]
out=[]
for i,x in enumerate(changes):
 fn=s.replace('pp_scan_definition_body(',f'case_{i}(')
 if x:
  old,new=x;assert fn.count(old)==1;fn=fn.replace(old,new)
 out.append(fn)
(p/'normal-v2-faults.inc').write_text('\n'.join(out))
