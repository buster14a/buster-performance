#include "buster/compiler/c_preprocessor_benchmark.c"
#include <sys/mman.h>
#include <unistd.h>
#include "normal-faults.inc"
typedef void DefinitionScan(const PPFileData*,const PPMacro*,bool*,bool*,bool*);
static DefinitionScan* const scans[]={case_0,case_1,case_2,case_3,case_4,case_5,case_6};
static bool differs(DefinitionScan* fn, PPFileData* data, PPMacro* macro, unsigned n, unsigned at, unsigned shape)
{
    bool wanted_paste=false, wanted_hash=false, wanted_opt=false;
    const uint32_t end=macro->body_end;
    for(uint32_t i=macro->body_begin;i<end;i++)
    {
        uint8_t kind=data->kinds[i]&127;
        if(kind==C_TOKEN_HASHHASH) wanted_paste=true;
        if(kind==C_TOKEN_HASH)
        {
            bool formal=!(macro->flags&BUSTER_PP_MACRO_VARIADIC) && macro->parameter_count==1 && i+1<end &&
                (data->kinds[i+1]&127)==C_TOKEN_RAW_IDENTIFIER && data->values[i+1]==data->values[macro->parameters_begin];
            wanted_hash |= !formal;
        }
        if(kind==C_TOKEN_RAW_IDENTIFIER && data->values[i]==C_NAME_VA_OPT)
        {
            bool simple=(macro->flags&BUSTER_PP_MACRO_VARIADIC) && end-i>=4 &&
                (data->kinds[i+1]&127)==C_TOKEN_L_PAREN && (data->kinds[i+2]&127)==C_TOKEN_RAW_IDENTIFIER &&
                data->values[i+2]!=C_NAME_VA_OPT && (data->kinds[i+3]&127)==C_TOKEN_R_PAREN;
            wanted_opt |= !simple;
        }
    }
    bool paste,hash,opt;fn(data,macro,&paste,&hash,&opt);
    if(paste==wanted_paste && hash==wanted_hash && opt==wanted_opt)return false;
    fprintf(stderr,"length %u position %u shape %u expected flags %u/%u/%u, saw %u/%u/%u\n",n,at,shape,wanted_paste,wanted_hash,wanted_opt,paste,hash,opt);
    return true;
}
static void* end_page(unsigned page)
{
    uint8_t* p=mmap(NULL,2*page,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(p==MAP_FAILED || mprotect(p+page,page,PROT_NONE)!=0)return NULL;
    return p+page;
}
int main(int argc,char**argv)
{
    if(argc!=2)return 2;unsigned side=(unsigned)atoi(argv[1]);if(side>=7)return 2;
    const unsigned page=(unsigned)sysconf(_SC_PAGESIZE);
    uint8_t* end_k=end_page(page);uint32_t* end_v=end_page(page);
    if(!end_k||!end_v)return 2;
    uint64_t checks=0;
    for(unsigned n=0;n<=257;n++)
    {
        PPFileData data={.kinds=end_k-(n+1),.values=end_v-(n+1),.token_count=n+1};
        PPMacro m={.parameters_begin=0,.body_begin=1,.body_end=n+1};
        data.values[0]=831u;
        for(unsigned at=0;at<(n?n:1);at++)for(unsigned shape=0;shape<11;shape++)
        {
            memset(data.kinds+1,C_TOKEN_NUMERIC_CONSTANT,n);
            for(unsigned i=1;i<=n;i++)data.values[i]=0x80000000u|C_NAME_VA_OPT;
            m.flags=shape>=6?BUSTER_PP_MACRO_VARIADIC:0;m.parameter_count=1;
            if(n)
            {
                uint32_t start=at+1;
                data.kinds[start]=128|(shape==0?C_TOKEN_HASHHASH:shape==1||shape==2||shape==3?C_TOKEN_HASH:shape==4?C_TOKEN_NUMERIC_CONSTANT:C_TOKEN_RAW_IDENTIFIER);
                if(shape>=4)data.values[start]=shape==10?0xffffff00u|C_NAME_VA_OPT:C_NAME_VA_OPT;
                if(shape==2 && start+1<=n){data.kinds[start+1]=C_TOKEN_RAW_IDENTIFIER;data.values[start+1]=831;}
                if(shape==3 && start+1<=n){data.kinds[start+1]=C_TOKEN_RAW_IDENTIFIER;data.values[start+1]=832;}
                if((shape==7||shape==8||shape==9)&&start+1<=n)data.kinds[start+1]=C_TOKEN_L_PAREN;
                if((shape==8||shape==9)&&start+2<=n){data.kinds[start+2]=C_TOKEN_RAW_IDENTIFIER;data.values[start+2]=shape==8?831:C_NAME_VA_OPT;}
                if((shape==8||shape==9)&&start+3<=n)data.kinds[start+3]=C_TOKEN_R_PAREN;
            }
            if(differs(scans[side],&data,&m,n,at,shape))return 1;
            checks++;
        }
    }
    fprintf(stderr,"validated %llu placements in 258 lengths and eleven operator or identifier shapes\n",(unsigned long long)checks);
    return 0;
}
