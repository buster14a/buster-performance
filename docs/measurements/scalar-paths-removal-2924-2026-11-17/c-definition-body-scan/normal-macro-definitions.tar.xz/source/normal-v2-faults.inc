static void case_0(const PPFileData* data, const PPMacro* macro, bool* paste, bool* hash, bool* opt)
{
    const uint32_t begin = macro->body_begin;
    const uint32_t end = macro->body_end;
    uint32_t found_paste = 0;
    uint32_t found_hash = 0;
    uint32_t found_opt = 0;
    for (uint32_t t = begin; t < end;)
    {
        const uint32_t left = end - t;
        uint32_t count = 64;
        uint64_t hashes;
        uint64_t optional;
        if (left >= 64)
        {
            const __m512i kinds = _mm512_and_si512(_mm512_loadu_si512(data->kinds + t), _mm512_set1_epi8(0x7f));
            hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH)) != 0;
            const uint64_t named = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            optional = 0;
            if (named != 0)
            {
                // Saturation to a byte is exact for this name comparison. Restore the token order after lane-local packs.
                _Static_assert(C_NAME_VA_OPT > 0 && C_NAME_VA_OPT < UINT8_MAX, "optional name lies within the saturation limits");
                const uint32_t* values = data->values + t;
                const __m512i ab = _mm512_packs_epi32(_mm512_loadu_si512(values), _mm512_loadu_si512(values + 16));
                const __m512i cd = _mm512_packs_epi32(_mm512_loadu_si512(values + 32), _mm512_loadu_si512(values + 48));
                const __m512i order = _mm512_setr_epi32(0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15);
                const __m512i ids = _mm512_permutexvar_epi32(order, _mm512_packus_epi16(ab, cd));
                optional = _mm512_mask_cmpeq_epi8_mask(named, ids, _mm512_set1_epi8(C_NAME_VA_OPT));
            }
        }
        else
        {
            count = left < 16 ? left : 16;
            const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, count);
            const __m128i kinds = _mm_and_si128(_mm_maskz_loadu_epi8(active, data->kinds + t), _mm_set1_epi8(0x7f));
            const __mmask16 identifiers = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            const __m512i ids = _mm512_maskz_loadu_epi32(active, data->values + t);
            optional = _mm512_mask_cmpeq_epi32_mask(identifiers, ids, _mm512_set1_epi32(C_NAME_VA_OPT));
            hashes = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASHHASH));
        }
        if (hashes | optional)
        {
            if (hashes != 0 && macro->parameter_count == 1 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) == 0)
            {
                const IdentId formal = data->values[macro->parameters_begin];
                for (uint64_t todo = hashes; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 1 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 1] == formal)
                    {
                        hashes &= hashes - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_hash |= hashes != 0;

            if (optional != 0 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) != 0)
            {
                for (uint64_t todo = optional; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 3 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_L_PAREN &&
                        (data->kinds[token + 2] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 2] != C_NAME_VA_OPT &&
                        (data->kinds[token + 3] & 0x7f) == C_TOKEN_R_PAREN)
                    {
                        optional &= optional - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_opt |= optional != 0;
        }
        t += count;
    }
    *paste = found_paste != 0;
    *hash = found_hash != 0;
    *opt = found_opt != 0;
}

static void case_1(const PPFileData* data, const PPMacro* macro, bool* paste, bool* hash, bool* opt)
{
    const uint32_t begin = macro->body_begin;
    const uint32_t end = macro->body_end;
    uint32_t found_paste = 0;
    uint32_t found_hash = 0;
    uint32_t found_opt = 0;
    for (uint32_t t = begin; t < end;)
    {
        const uint32_t left = end - t;
        uint32_t count = 64;
        uint64_t hashes;
        uint64_t optional;
        if (left >= 64)
        {
            const __m512i kinds = _mm512_and_si512(_mm512_loadu_si512(data->kinds + t), _mm512_set1_epi8(0x7f));
            hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH)) != 0;
            const uint64_t named = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            optional = 0;
            if (named != 0)
            {
                // Saturation to a byte is exact for this name comparison. Restore the token order after lane-local packs.
                _Static_assert(C_NAME_VA_OPT > 0 && C_NAME_VA_OPT < UINT8_MAX, "optional name lies within the saturation limits");
                const uint32_t* values = data->values + t;
                const __m512i ab = _mm512_packs_epi32(_mm512_loadu_si512(values), _mm512_loadu_si512(values + 16));
                const __m512i cd = _mm512_packs_epi32(_mm512_loadu_si512(values + 32), _mm512_loadu_si512(values + 48));
                const __m512i order = _mm512_setr_epi32(0, 4, 8, 12, 2, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15);
                const __m512i ids = _mm512_permutexvar_epi32(order, _mm512_packus_epi16(ab, cd));
                optional = _mm512_mask_cmpeq_epi8_mask(named, ids, _mm512_set1_epi8(C_NAME_VA_OPT));
            }
        }
        else
        {
            count = left < 16 ? left : 16;
            const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, count);
            const __m128i kinds = _mm_and_si128(_mm_maskz_loadu_epi8(active, data->kinds + t), _mm_set1_epi8(0x7f));
            const __mmask16 identifiers = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            const __m512i ids = _mm512_maskz_loadu_epi32(active, data->values + t);
            optional = _mm512_mask_cmpeq_epi32_mask(identifiers, ids, _mm512_set1_epi32(C_NAME_VA_OPT));
            hashes = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASHHASH));
        }
        if (hashes | optional)
        {
            if (hashes != 0 && macro->parameter_count == 1 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) == 0)
            {
                const IdentId formal = data->values[macro->parameters_begin];
                for (uint64_t todo = hashes; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 1 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 1] == formal)
                    {
                        hashes &= hashes - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_hash |= hashes != 0;

            if (optional != 0 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) != 0)
            {
                for (uint64_t todo = optional; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 3 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_L_PAREN &&
                        (data->kinds[token + 2] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 2] != C_NAME_VA_OPT &&
                        (data->kinds[token + 3] & 0x7f) == C_TOKEN_R_PAREN)
                    {
                        optional &= optional - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_opt |= optional != 0;
        }
        t += count;
    }
    *paste = found_paste != 0;
    *hash = found_hash != 0;
    *opt = found_opt != 0;
}

static void case_2(const PPFileData* data, const PPMacro* macro, bool* paste, bool* hash, bool* opt)
{
    const uint32_t begin = macro->body_begin;
    const uint32_t end = macro->body_end;
    uint32_t found_paste = 0;
    uint32_t found_hash = 0;
    uint32_t found_opt = 0;
    for (uint32_t t = begin; t < end;)
    {
        const uint32_t left = end - t;
        uint32_t count = 64;
        uint64_t hashes;
        uint64_t optional;
        if (left >= 64)
        {
            const __m512i kinds = _mm512_and_si512(_mm512_loadu_si512(data->kinds + t), _mm512_set1_epi8(0x7f));
            hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH)) != 0;
            const uint64_t named = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            optional = 0;
            if (named != 0)
            {
                // Saturation to a byte is exact for this name comparison. Restore the token order after lane-local packs.
                _Static_assert(C_NAME_VA_OPT > 0 && C_NAME_VA_OPT < UINT8_MAX, "optional name lies within the saturation limits");
                const uint32_t* values = data->values + t;
                const __m512i ab = _mm512_packs_epi32(_mm512_loadu_si512(values), _mm512_loadu_si512(values + 16));
                const __m512i cd = _mm512_packs_epi32(_mm512_loadu_si512(values + 32), _mm512_loadu_si512(values + 48));
                const __m512i order = _mm512_setr_epi32(0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15);
                const __m512i ids = _mm512_permutexvar_epi32(order, _mm512_packus_epi16(ab, cd));
                optional = _mm512_mask_cmpeq_epi8_mask(named, ids, _mm512_set1_epi8(C_NAME_VA_OPT));
            }
        }
        else
        {
            count = left < 16 ? left : 16;
            const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, count);
            const __m128i kinds = _mm_and_si128(_mm_maskz_loadu_epi8(active, data->kinds + t), _mm_set1_epi8(0x7f));
            const __mmask16 identifiers = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            const __m512i ids = _mm512_maskz_loadu_epi32(active, data->values + t);
            optional = _mm512_mask_cmpeq_epi32_mask(identifiers, ids, _mm512_set1_epi32(C_NAME_VA_OPT));
            hashes = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASHHASH));
        }
        if (hashes | optional)
        {
            if (hashes != 0 && macro->parameter_count == 1 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) == 0)
            {
                const IdentId formal = data->values[macro->parameters_begin];
                for (uint64_t todo = hashes; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 1 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 1] != formal)
                    {
                        hashes &= hashes - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_hash |= hashes != 0;

            if (optional != 0 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) != 0)
            {
                for (uint64_t todo = optional; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 3 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_L_PAREN &&
                        (data->kinds[token + 2] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 2] != C_NAME_VA_OPT &&
                        (data->kinds[token + 3] & 0x7f) == C_TOKEN_R_PAREN)
                    {
                        optional &= optional - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_opt |= optional != 0;
        }
        t += count;
    }
    *paste = found_paste != 0;
    *hash = found_hash != 0;
    *opt = found_opt != 0;
}

static void case_3(const PPFileData* data, const PPMacro* macro, bool* paste, bool* hash, bool* opt)
{
    const uint32_t begin = macro->body_begin;
    const uint32_t end = macro->body_end;
    uint32_t found_paste = 0;
    uint32_t found_hash = 0;
    uint32_t found_opt = 0;
    for (uint32_t t = begin; t < end;)
    {
        const uint32_t left = end - t;
        uint32_t count = 64;
        uint64_t hashes;
        uint64_t optional;
        if (left >= 64)
        {
            const __m512i kinds = _mm512_and_si512(_mm512_loadu_si512(data->kinds + t), _mm512_set1_epi8(0x7f));
            hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH)) != 0;
            const uint64_t named = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            optional = 0;
            if (named != 0)
            {
                // Saturation to a byte is exact for this name comparison. Restore the token order after lane-local packs.
                _Static_assert(C_NAME_VA_OPT > 0 && C_NAME_VA_OPT < UINT8_MAX, "optional name lies within the saturation limits");
                const uint32_t* values = data->values + t;
                const __m512i ab = _mm512_packs_epi32(_mm512_loadu_si512(values), _mm512_loadu_si512(values + 16));
                const __m512i cd = _mm512_packs_epi32(_mm512_loadu_si512(values + 32), _mm512_loadu_si512(values + 48));
                const __m512i order = _mm512_setr_epi32(0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15);
                const __m512i ids = _mm512_permutexvar_epi32(order, _mm512_packus_epi16(ab, cd));
                optional = _mm512_mask_cmpeq_epi8_mask(named, ids, _mm512_set1_epi8(C_NAME_VA_OPT));
            }
        }
        else
        {
            count = left < 16 ? left : 16;
            const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, count);
            const __m128i kinds = _mm_and_si128(_mm_maskz_loadu_epi8(active, data->kinds + t), _mm_set1_epi8(0x7f));
            const __mmask16 identifiers = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            const __m512i ids = _mm512_maskz_loadu_epi32(active, data->values + t);
            optional = _mm512_mask_cmpeq_epi32_mask(identifiers, ids, _mm512_set1_epi32(C_NAME_VA_OPT));
            hashes = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASHHASH));
        }
        if (hashes | optional)
        {
            if (hashes != 0 && macro->parameter_count == 1 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) == 0)
            {
                const IdentId formal = data->values[macro->parameters_begin];
                for (uint64_t todo = hashes; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 1 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 1] == formal)
                    {
                        hashes &= hashes - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_hash |= hashes != 0;

            if (optional != 0 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) != 0)
            {
                for (uint64_t todo = optional; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 3 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_L_PAREN &&
                        (data->kinds[token + 2] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 2] != C_NAME_VA_OPT &&
                        (data->kinds[token + 3] & 0x7f) == C_TOKEN_L_PAREN)
                    {
                        optional &= optional - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_opt |= optional != 0;
        }
        t += count;
    }
    *paste = found_paste != 0;
    *hash = found_hash != 0;
    *opt = found_opt != 0;
}

static void case_4(const PPFileData* data, const PPMacro* macro, bool* paste, bool* hash, bool* opt)
{
    const uint32_t begin = macro->body_begin;
    const uint32_t end = macro->body_end;
    uint32_t found_paste = 0;
    uint32_t found_hash = 0;
    uint32_t found_opt = 0;
    for (uint32_t t = begin; t < end;)
    {
        const uint32_t left = end - t;
        uint32_t count = 64;
        uint64_t hashes;
        uint64_t optional;
        if (left >= 64)
        {
            const __m512i kinds = _mm512_and_si512(_mm512_loadu_si512(data->kinds + t), _mm512_set1_epi8(0x7f));
            hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH)) != 0;
            const uint64_t named = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            optional = 0;
            if (named != 0)
            {
                // Saturation to a byte is exact for this name comparison. Restore the token order after lane-local packs.
                _Static_assert(C_NAME_VA_OPT > 0 && C_NAME_VA_OPT < UINT8_MAX, "optional name lies within the saturation limits");
                const uint32_t* values = data->values + t;
                const __m512i ab = _mm512_packs_epi32(_mm512_loadu_si512(values), _mm512_loadu_si512(values + 16));
                const __m512i cd = _mm512_packs_epi32(_mm512_loadu_si512(values + 32), _mm512_loadu_si512(values + 48));
                const __m512i order = _mm512_setr_epi32(0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15);
                const __m512i ids = _mm512_permutexvar_epi32(order, _mm512_packus_epi16(ab, cd));
                optional = _mm512_mask_cmpeq_epi8_mask(named, ids, _mm512_set1_epi8(C_NAME_VA_OPT));
            }
        }
        else
        {
            count = left < 16 ? left : 16;
            const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, count);
            const __m128i kinds = _mm_and_si128(_mm_maskz_loadu_epi8(active, data->kinds + t), _mm_set1_epi8(0x7f));
            const __mmask16 identifiers = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            const __m512i ids = _mm512_maskz_loadu_epi32(active, data->values + t);
            optional = _mm512_mask_cmpeq_epi32_mask(identifiers, ids, _mm512_set1_epi32(C_NAME_VA_OPT));
            hashes = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASHHASH));
        }
        if (hashes | optional)
        {
            if (hashes != 0 && macro->parameter_count == 1 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) == 0)
            {
                const IdentId formal = data->values[macro->parameters_begin];
                for (uint64_t todo = hashes; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 1 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 1] == formal)
                    {
                        hashes &= hashes - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_hash |= (uint32_t)hashes;

            if (optional != 0 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) != 0)
            {
                for (uint64_t todo = optional; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 3 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_L_PAREN &&
                        (data->kinds[token + 2] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 2] != C_NAME_VA_OPT &&
                        (data->kinds[token + 3] & 0x7f) == C_TOKEN_R_PAREN)
                    {
                        optional &= optional - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_opt |= optional != 0;
        }
        t += count;
    }
    *paste = found_paste != 0;
    *hash = found_hash != 0;
    *opt = found_opt != 0;
}

static void case_5(const PPFileData* data, const PPMacro* macro, bool* paste, bool* hash, bool* opt)
{
    const uint32_t begin = macro->body_begin;
    const uint32_t end = macro->body_end;
    uint32_t found_paste = 0;
    uint32_t found_hash = 0;
    uint32_t found_opt = 0;
    for (uint32_t t = begin; t < end;)
    {
        const uint32_t left = end - t;
        uint32_t count = 64;
        uint64_t hashes;
        uint64_t optional;
        if (left >= 64)
        {
            const __m512i kinds = _mm512_and_si512(_mm512_loadu_si512(data->kinds + t), _mm512_set1_epi8(0x7f));
            hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH)) != 0;
            const uint64_t named = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            optional = 0;
            if (named == 0)
            {
                // Saturation to a byte is exact for this name comparison. Restore the token order after lane-local packs.
                _Static_assert(C_NAME_VA_OPT > 0 && C_NAME_VA_OPT < UINT8_MAX, "optional name lies within the saturation limits");
                const uint32_t* values = data->values + t;
                const __m512i ab = _mm512_packs_epi32(_mm512_loadu_si512(values), _mm512_loadu_si512(values + 16));
                const __m512i cd = _mm512_packs_epi32(_mm512_loadu_si512(values + 32), _mm512_loadu_si512(values + 48));
                const __m512i order = _mm512_setr_epi32(0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15);
                const __m512i ids = _mm512_permutexvar_epi32(order, _mm512_packus_epi16(ab, cd));
                optional = _mm512_mask_cmpeq_epi8_mask(named, ids, _mm512_set1_epi8(C_NAME_VA_OPT));
            }
        }
        else
        {
            count = left < 16 ? left : 16;
            const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, count);
            const __m128i kinds = _mm_and_si128(_mm_maskz_loadu_epi8(active, data->kinds + t), _mm_set1_epi8(0x7f));
            const __mmask16 identifiers = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            const __m512i ids = _mm512_maskz_loadu_epi32(active, data->values + t);
            optional = _mm512_mask_cmpeq_epi32_mask(identifiers, ids, _mm512_set1_epi32(C_NAME_VA_OPT));
            hashes = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASHHASH));
        }
        if (hashes | optional)
        {
            if (hashes != 0 && macro->parameter_count == 1 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) == 0)
            {
                const IdentId formal = data->values[macro->parameters_begin];
                for (uint64_t todo = hashes; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 1 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 1] == formal)
                    {
                        hashes &= hashes - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_hash |= hashes != 0;

            if (optional != 0 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) != 0)
            {
                for (uint64_t todo = optional; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 3 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_L_PAREN &&
                        (data->kinds[token + 2] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 2] != C_NAME_VA_OPT &&
                        (data->kinds[token + 3] & 0x7f) == C_TOKEN_R_PAREN)
                    {
                        optional &= optional - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_opt |= optional != 0;
        }
        t += count;
    }
    *paste = found_paste != 0;
    *hash = found_hash != 0;
    *opt = found_opt != 0;
}

static void case_6(const PPFileData* data, const PPMacro* macro, bool* paste, bool* hash, bool* opt)
{
    const uint32_t begin = macro->body_begin;
    const uint32_t end = macro->body_end;
    uint32_t found_paste = 0;
    uint32_t found_hash = 0;
    uint32_t found_opt = 0;
    for (uint32_t t = begin; t < end;)
    {
        const uint32_t left = end - t;
        uint32_t count = 64;
        uint64_t hashes;
        uint64_t optional;
        if (left >= 64)
        {
            const __m512i kinds = _mm512_and_si512(_mm512_loadu_si512(data->kinds + t), _mm512_set1_epi8(0x7f));
            hashes = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_HASHHASH)) != 0;
            const uint64_t named = _mm512_cmpeq_epi8_mask(kinds, _mm512_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            optional = 0;
            if (named != 0)
            {
                // Saturation to a byte is exact for this name comparison. Restore the token order after lane-local packs.
                _Static_assert(C_NAME_VA_OPT > 0 && C_NAME_VA_OPT < UINT8_MAX, "optional name lies within the saturation limits");
                const uint32_t* values = data->values + t;
                const __m512i ab = _mm512_packs_epi32(_mm512_loadu_si512(values), _mm512_loadu_si512(values + 16));
                const __m512i cd = _mm512_packs_epi32(_mm512_loadu_si512(values + 32), _mm512_loadu_si512(values + 48));
                const __m512i order = _mm512_setr_epi32(0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15);
                const __m512i ids = _mm512_permutexvar_epi32(order, _mm512_packus_epi16(ab, cd));
                optional = _mm512_mask_cmpeq_epi8_mask(named, ids, _mm512_set1_epi8(C_NAME_VA_OPT));
            }
        }
        else
        {
            count = left < 16 ? left : 16;
            const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, count);
            const __m128i kinds = _mm_and_si128(_mm_loadu_si128((const __m128i*)(data->kinds + t)), _mm_set1_epi8(0x7f));
            const __mmask16 identifiers = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_RAW_IDENTIFIER));
            const __m512i ids = _mm512_maskz_loadu_epi32(active, data->values + t);
            optional = _mm512_mask_cmpeq_epi32_mask(identifiers, ids, _mm512_set1_epi32(C_NAME_VA_OPT));
            hashes = _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASH));
            found_paste |= _mm_cmpeq_epi8_mask(kinds, _mm_set1_epi8(C_TOKEN_HASHHASH));
        }
        if (hashes | optional)
        {
            if (hashes != 0 && macro->parameter_count == 1 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) == 0)
            {
                const IdentId formal = data->values[macro->parameters_begin];
                for (uint64_t todo = hashes; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 1 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 1] == formal)
                    {
                        hashes &= hashes - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_hash |= hashes != 0;

            if (optional != 0 && (macro->flags & BUSTER_PP_MACRO_VARIADIC) != 0)
            {
                for (uint64_t todo = optional; todo != 0; todo &= todo - 1u)
                {
                    const uint32_t token = t + (uint32_t)__builtin_ctzll(todo);
                    if (end - token > 3 && (data->kinds[token + 1] & 0x7f) == C_TOKEN_L_PAREN &&
                        (data->kinds[token + 2] & 0x7f) == C_TOKEN_RAW_IDENTIFIER && data->values[token + 2] != C_NAME_VA_OPT &&
                        (data->kinds[token + 3] & 0x7f) == C_TOKEN_R_PAREN)
                    {
                        optional &= optional - 1u;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            found_opt |= optional != 0;
        }
        t += count;
    }
    *paste = found_paste != 0;
    *hash = found_hash != 0;
    *opt = found_opt != 0;
}
