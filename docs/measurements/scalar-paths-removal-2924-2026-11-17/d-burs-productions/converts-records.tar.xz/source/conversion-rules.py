from pathlib import Path
from subprocess import check_output
from difflib import unified_diff
p=Path(__file__).parent;src=p/'call-src/src/buster/compiler';t=p/'tree';d=p/'convert-src/src/buster/compiler';d.mkdir(exist_ok=True,parents=True)
files=['tier1_select.c','tier1_select_burs.c','tier1_select_burs_test.c']
for n in files:(d/n).write_bytes((src/n).read_bytes())
f=d/'tier1_select_burs.c';s=f.read_text()
pos=s.index('        __m512i result = _mm512_mask_mov_epi32')
s=s[:pos]+'''        const __mmask16 copies = _mm512_mask_cmpeq_epi32_mask(simple, op, _mm512_set1_epi32(IR_COPY));
        const __mmask16 unary = integer & (_mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_NEG)) | _mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_NOT)));
        const __mmask16 truncs = _mm512_mask_cmpeq_epi32_mask(a_valid, op, _mm512_set1_epi32(IR_TRUNC));
        const __mmask16 sexts = _mm512_mask_cmpeq_epi32_mask(a_valid, op, _mm512_set1_epi32(IR_SEXT));
        __mmask16 conversions = 0;
        if ((truncs | sexts) != 0)
        {
            const __m512i a_op = _mm512_and_si512(a_word, byte);
            const uint32_t narrow_sources = (1u << IR_I8) | (1u << IR_I16) | (1u << IR_I32);
            const __mmask16 narrow_results = tier1_burs_types(truncs, type, narrow_sources);
            const __mmask16 trunc_inputs = tier1_burs_types(narrow_results, a_type, narrow_sources | (1u << IR_I64));
            // A narrow write can absorb its I32 producer only for these four operations.
            const __mmask16 changes_width = _mm512_cmpeq_epi32_mask(a_type, _mm512_set1_epi32(IR_I32)) &
                                            _mm512_cmpneq_epi32_mask(type, _mm512_set1_epi32(IR_I32));
            const __mmask16 can_fold = _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_ADD)) | _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_SUB)) |
                                       _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_NEG)) | _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_NOT));
            conversions = trunc_inputs & ~(changes_width & can_fold);
            const __mmask16 signed_results = tier1_burs_types(sexts, type, integers | (1u << IR_I16));
            const __mmask16 signed_inputs = tier1_burs_types(signed_results, a_type, narrow_sources);
            // A constant, parameter, phi or call is never a folded load, truncation or signed arithmetic tree.
            const __mmask16 terminal = _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_CONST)) | _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_PARAM)) |
                                       _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_PHI)) | _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_CALL)) |
                                       _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_CALL_INDIRECT));
            conversions |= signed_inputs & terminal;
        }
'''+s[pos:]
s=s.replace('direct | parameters | phis | returns,','direct | parameters | phis | returns | copies | unary | conversions,')
f.write_text(s)
f=d/'tier1_select_burs_test.c';s=f.read_text().replace('(op == IR_PHI && plain_type) ||','''(op == IR_PHI && plain_type) || (op == IR_COPY && plain_type && type != IR_I1) ||
                           ((op == IR_NEG || op == IR_NOT) && (type == IR_I32 || type == IR_I64)) ||
                           (op == IR_TRUNC && (type == IR_I8 || type == IR_I16 || type == IR_I32) && function->type[function->a[node]] == IR_I64) ||
                           (op == IR_SEXT && (type == IR_I16 || type == IR_I32 || type == IR_I64) && function->op[function->a[node]] == IR_PARAM &&
                            (function->type[function->a[node]] >= IR_I8 && function->type[function->a[node]] <= IR_I32)) ||''');f.write_text(s)
patch=''
for n in files:
 f='src/buster/compiler/'+n;b=check_output(['git','show','cc7d4ffb4:'+f],cwd=t).decode()
 patch+=''.join(unified_diff(b.splitlines(True),(d/n).read_text().splitlines(True),'a/'+f,'b/'+f))
(p/'converts.patch').write_text(patch)
for n in ['build-calls','calls-corpus','ordinary-calls','whole-calls','calls-tests','calls-bench-source','calls-measure-sources','calls-measure-widths']:
 s=(p/n).read_text().replace('calls','converts')
 if n.startswith('build'):
  s=s.replace('buster-directive-whole-','buster-dom-loops-').replace('previous/seekscan-built.ok','previous/cursor-built.ok').replace('previous/seekscan.patch','previous/cursor.patch')
 if n=='calls-corpus':s=s.replace('supported-census.ok','calls-census.ok')
 (p/n.replace('calls','converts')).write_text(s)
