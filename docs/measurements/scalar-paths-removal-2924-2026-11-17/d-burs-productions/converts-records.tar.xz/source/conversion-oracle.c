#define _GNU_SOURCE
#include "buster/compiler/tier1_select_benchmark.c"
#include "buster/compiler/ir_validate.c"
#include "buster/compiler/ir_parse.c"
#include "check-common.inc"

int main(int argc, char** argv)
{
    if (argc != 2 || !tier1_select_initialize()) return 2;
    const uint32_t state = tier1_burs_pool[tier1_burs_table_base[TIER1_BURS_OP_DIRECT]];
    const uint32_t entry = state * TIER1_BURS_NONTERMINALS + TIER1_BURS_REG;
    const uint32_t rule = tier1_burs_state_rules[entry];
    if (strcmp(argv[1],"munch") == 0) tier1_burs_rules[rule].action = TIER1_BURS_ACTION_MUNCH;
    else if (strcmp(argv[1],"state") == 0) tier1_burs_table_base[TIER1_BURS_OP_DIRECT] = tier1_burs_table_base[TIER1_BURS_OP_REG];
    else if (strcmp(argv[1],"goal") == 0) tier1_burs_goal[TIER1_BURS_OP_DIRECT] = TIER1_BURS_STMT;
    else if (strcmp(argv[1],"missing") == 0) tier1_burs_state_rules[entry] = 0;
    else if (strcmp(argv[1],"control") != 0) return 2;
    Arena input = arena_reserve(1u<<24), scratch = arena_reserve(1u<<26);
    char program[2048];
    size_t used = (size_t)snprintf(program,sizeof(program),"function (i32) -> i64 {\nb0:\n  %%0 = param.i32 0\n  %%1 = sext.i64 %%0\n  %%2 = trunc.i32 %%1\n");
    for (unsigned i=3;i<17;++i)
        used += (size_t)snprintf(program+used,sizeof(program)-used,"  %%%u = %s.i32 %%%u\n",i,i%3==0?"copy":i%3==1?"neg":"not",i-1);
    used += (size_t)snprintf(program+used,sizeof(program)-used,"  %%17 = br.void b1\nb1:\n  %%18 = ret.void %%1\n}\n");
    IrFunction function;
    if (ir_parse((String8){.pointer=program,.length=used},&input,&scratch,&function).error!=IR_PARSE_OK) return 3;
    Tier1BursCheck tested = {0};
    tier1_burs_check_function(&tested,&function,NULL,&scratch);
    int failures = tested.functions!=1 || tested.nodes!=19 || tested.matched!=19 ||
                   tested.mismatches!=0 || tested.uncovered!=0 || tested.fallbacks!=0;
    printf("checked %"PRIu64" nodes, %"PRIu64" direct, %"PRIu64" mismatches, %"PRIu64" fallbacks, %d failed\n",tested.nodes,tested.matched,tested.mismatches,tested.fallbacks,failures);
    arena_release(&scratch); arena_release(&input);
    return failures;
}
