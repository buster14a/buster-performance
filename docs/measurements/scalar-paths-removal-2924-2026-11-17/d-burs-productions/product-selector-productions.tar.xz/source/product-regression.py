from pathlib import Path
import json
from subprocess import check_output
from difflib import unified_diff
p=Path(__file__).resolve().parent;src=p/'product-src/buster/compiler';f=src/'tier1_select_burs_test.c';s=f.read_text()
program=(p/'product-fixture.ir').read_text()
fixture='''// SQLite widens bounded I32 multiplies to I64. The same multiply may wrap at I32, or another
// consumer may still need the narrow result. Check the selected operations and their actual operands.
static void tier1_select_test_burs_signed_products(Tier1SelectTest* test)
{
    static const char source[] = '''+ ('\n'+' '*33).join(json.dumps(l)for l in program.splitlines(True))+''';
    Arena input = arena_reserve(UINT64_C(1) << 24);
    Arena output = arena_reserve(UINT64_C(1) << 24);
    Arena scratch = arena_reserve(UINT64_C(1) << 26);
    IrFunction function = { 0 };
    Tier1SelectPlan plan = { 0 };
    uint32_t failed = BUSTER_IR_NONE;
    const bool valid = input.base && output.base && scratch.base &&
                       ir_parse((String8){ .pointer = (char*)source, .length = sizeof(source) - 1 }, &input, &scratch, &function).error == IR_PARSE_OK &&
                       tier1_select_plan(&function, 0, &output, &scratch, &plan, &failed) == TIER1_SELECT_OK;
    tier1_select_test_expect(test, valid, "signed product fixture produces a plan");
    if (valid)
    {
        const Tier1SelectPattern* patterns = plan.patterns;
        tier1_select_test_expect(test, plan.covered[6] && patterns[7].rule == TIER1_RULE_IMMEDIATE && patterns[7].operation == X86_OPERATION_IMUL &&
                                       patterns[7].width == 8 && patterns[7].values[0] == 3 && patterns[7].immediate == 7,
                                 "bounded signed product with an immediate folds into its extension");
        tier1_select_test_expect(test, plan.covered[8] && patterns[9].rule == TIER1_RULE_REGISTER && patterns[9].operation == X86_OPERATION_IMUL &&
                                       patterns[9].width == 8 && patterns[9].values[0] == 3 && patterns[9].values[1] == 4,
                                 "bounded signed product with two register operands folds into its extension");
        tier1_select_test_expect(test, !plan.covered[10] && patterns[10].width == 4 && patterns[11].rule == TIER1_RULE_SIGN_EXTEND && patterns[11].values[0] == 10,
                                 "wrapping I32 product finishes before its signed extension");
        tier1_select_test_expect(test, !plan.covered[12] && patterns[12].width == 4 && patterns[13].rule == TIER1_RULE_SIGN_EXTEND && patterns[13].values[0] == 12,
                                 "shared I32 product keeps the narrow result");
    }
    arena_release(&scratch);
    arena_release(&output);
    arena_release(&input);
}
'''
k='static void tier1_select_test_burs(Tier1SelectTest* test)';assert k in s and fixture not in s
f.write_text(s.replace(k,fixture+'\n'+k).replace('    tier1_select_test_burs_links(test);','    tier1_select_test_burs_links(test);\n    tier1_select_test_burs_signed_products(test);'))
runner='''#define _GNU_SOURCE
#include "buster/compiler/tier1_select_benchmark.c"
#include "buster/compiler/ir_validate.c"
#include "buster/compiler/ir_parse.c"
typedef struct Tier1SelectTest { unsigned checks, failures; } Tier1SelectTest;
static void tier1_select_test_expect(Tier1SelectTest* t,bool ok,const char* what)
{
    ++t->checks;
    if (!ok) {fprintf(stderr,"%s\\n",what);++t->failures;}
}
'''+fixture+'''
int main(int argc,char** argv)
{
    if (argc != 2 || !tier1_select_initialize()) return 2;
    bool found=false;
    for (uint32_t rule=0;rule<tier1_burs_rule_count;++rule)
    {
        if (tier1_burs_rules[rule].op != TIER1_BURS_OP_SIGNED_PRODUCT) continue;
        found=true;
        if(!strcmp(argv[1],"direct")) tier1_burs_rules[rule].action=TIER1_BURS_ACTION_PLAIN;
        if(!strcmp(argv[1],"immediate")) {tier1_burs_rules[rule].action=TIER1_BURS_ACTION_KIND;tier1_burs_rules[rule].kind=TIER1_RULE_SIGN_EXTEND;}
    }
    if(!found) return 2;
    Tier1SelectTest t={0};
    tier1_select_test_burs_signed_products(&t);
    printf("signed multiply %u checks, %u failures\\n",t.checks,t.failures);
    return t.failures!=0;
}
'''
(p/'product-oracle.c').write_text(runner)
diff=''
for f in sorted(src.glob('*.c')):
 path='src/buster/compiler/'+f.name;old=check_output(['git','show','cc7d4ffb4:'+path],cwd=p/'tree').decode()
 diff+=''.join(unified_diff(old.splitlines(True),f.read_text().splitlines(True),'a/'+path,'b/'+path))
(p/'product.patch').write_text(diff)
