from collections import Counter
from hashlib import sha256
from pathlib import Path
import gzip, re, runpy, sys, tarfile
p=Path(__file__).resolve().parent
r=p/'results'
tag,commit=sys.argv[1:3]
assert tag in ('product','widen')
compare=runpy.run_path(str(p/'compare-selected.py'))['compare']
verify=runpy.run_path(str(p/'verify-plan-bytes.py'))['verify']
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-burs-productions')
files=set();rows=[]; totals=Counter();visits=Counter()
for mode in ['default','all']:
    for group in ['lua','sqlite','musl']:
        c,_=compare(tag,mode,group)
        counts=verify(mode,group);totals.update(counts);visits.update(c)
        assert counts['failures']==0
        parent=gzip.decompress((r/f'plans-{mode}-{group}.gz').read_bytes())
        log=r/f'{tag}-plan-bytes-{mode}-{group}.log'
        lines=log.read_text().splitlines()
        assert len(lines)==2 and int(lines[0].split()[0])==len(parent) and lines[1].split()[0]==sha256(parent).hexdigest()
        files.add(log)
        for ext in ['sha','out','err']:
            for prefix,original in [('plan-'+tag,'plan-parent-'),(tag,'')]:
                baseline=(r/f'{original}{mode}-{group}.{ext}').read_bytes()
                f=r/f'{prefix}-{mode}-{group}.{ext}';assert f.read_bytes()==baseline;files.add(f)
        files.add(r/f'{tag}-records-{mode}-{group}.bin')
        rows.append(f'| {mode} | {group} | {counts["plans"]:,} | {counts["bytes"]:,} | {c["total"]:,} | {c["candidate"]:,} |')
assert totals==dict(plans=13036,nodes=2364459,uses=912714,bytes=168865267)
assert visits['total']==1006223 and visits['baseline']==396316 and visits['candidate']<19716
for name in ['select','test-tier1-emit','test-tier1-liveness','test-tier1-masks','pipeline-1','pipeline-133','pipeline-789']:
    f=r/f'{tag}-{name}.log';s=f.read_text();assert re.search(r'[1-9]\d* checks, 0 failures',s);files.add(f)
    if name=='select':assert '5957, digest d15b788da26467e5' in s
    if name.startswith('pipeline'):assert re.search(r'native=[1-9]\d* clang=[1-9]\d*',s)
details={'product':('Signed multiplication in the selector grammar','The grammar covers bounded signed products in register and immediate forms. It also covers narrow results, floating-point casts, conditional branches and nonconstant divisors. Labeling uses the grammar’s child count and handles terminals directly. The fixed multiply regression checks both folded operand forms, wrapping arithmetic and a shared result. Forcing the ordinary extension broke two assertions.'),
         'widen':('Signed bitwise operations and chained extensions in the selector grammar','The grammar covers signed widening of I32 bitwise operations, arithmetic shifts, negation, nested extensions including folded loads, and a truncation followed by an extension. The regression checks seven node positions and the effect of shared uses. Four deliberate changes to coverage, bitwise selection, chaining and projection failed the fixture.')}
title,desc=details[tag]
sources=[tag+'.patch','plan-chosen.patch',tag+'-plans',tag+'-tests',tag+'-corpus','build-'+tag,'record-signed-production.py','compare-selected.py','verify-plan-bytes.py',tag+'-expanded.log']
if tag=='product':
    assert (r/'fixtures-product/regression/control.status').read_text().strip()=='0' and (r/'fixtures-product/regression/direct.status').read_text().strip()=='1'
    assert '5 checks, 2 failures' in (r/'fixtures-product/regression/direct.log').read_text()
    files.update((r/'fixtures-product/regression').glob('*'))
    sources+=['signed-products.py','product-regression.py','product-oracle.c']
else:
    for label in ['control','coverage','bits','chain','projection']:
        f=r/f'fixtures-widen/{label}.log'
        assert f.is_file();files.add(f)
    sources+=['signed-widenings.py','widening-fixture.py','widen-oracle.c']
archive=tag+'-selector-productions.tar.xz'
doc=out/'README.md';assert '## '+title+'\n' not in doc.read_text()
with tarfile.open(out/archive,'w:xz',preset=2)as t:
    for f in sorted(files):t.add(f,'native/'+str(f.relative_to(r)))
    for n in sources:t.add(p/n,'source/'+n)
with doc.open('a')as f:
    f.write('\n## '+title+'\n\n'+desc+f'\n\nCompiler `{commit[:9]}` reproduced all 168,865,267 returned plan bytes and all 2,742 debug objects and diagnostic streams from `cc7d4ffb4`. Across 1,006,223 candidate lists the candidates kept the same order and the winner stayed the same. The original maximal-munch pass handled 396,316 of these visits. The deferred-cost baseline handled 19,716 and this revision handled {visits["candidate"]:,}. All three Clang-backed pipeline seeds passed.\n\n| Optimization passes | Corpus | Plans | Identical plan bytes | Candidate lists | Maximal-munch visits |\n| --- | --- | ---: | ---: | ---: | ---: |\n'+'\n'.join(rows)+'\n\nThe archived native streams from the deferred-cost comparison reproduce the parent side. This archive supplies the new per-corpus byte counts and hashes, object and diagnostic manifests, candidate lists, source, native checks and mutation results.\n\n[Native results and verification scripts]('+archive+')\n')
print(dict(visits))
