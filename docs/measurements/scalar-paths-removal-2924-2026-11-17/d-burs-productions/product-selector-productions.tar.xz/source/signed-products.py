from pathlib import Path
from shutil import copytree
from subprocess import check_output
from difflib import unified_diff
p=Path(__file__).resolve().parent;d=p/'product-src';copytree(p/'arity-src',d,dirs_exist_ok=True)
c=d/'buster/compiler';f=c/'tier1_select_burs.c';s=f.read_text()
def once(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
for a in ['OP_NARROW_UNARY','FAMILY_NARROW','ACTION_NARROW']:
 prefix=a.split('_')[0];old='    TIER1_BURS_'+a+',\n';once(old,old+'    TIER1_BURS_'+prefix+'_SIGNED_PRODUCT,\n')
k='    // A single-use I32 arithmetic producer';once(k,'''    // The widening multiply has a register extension and, when range and use proofs allow it,
    // a signed 64-bit multiply with an immediate or register operand.
    { TIER1_BURS_REG, TIER1_BURS_FAMILY_SIGNED_PRODUCT, 0, { TIER1_BURS_REG, BUSTER_TIER1_BURS_NO_KID }, 1, TIER1_BURS_ACTION_SIGNED_PRODUCT, TIER1_RULE_NONE },
'''+k)
k='    case TIER1_BURS_FAMILY_NARROW:';once(k,'''    case TIER1_BURS_FAMILY_SIGNED_PRODUCT:
        member = op == TIER1_BURS_OP_SIGNED_PRODUCT;
        break;
'''+k)
k='        __mmask16 narrow_unary = 0;';once(k,k+'\n        __mmask16 signed_products = 0;')
a=s.index('            // A constant, parameter, phi or call');b=s.index('            const __mmask16 from_load',a);s=s[:a]+s[b:]
a=s.index('            // Algebraic extension patterns');b=s.index('            sign_loads =',a)
s=s[:a]+'''            // These I32 producers have additional algebraic patterns when widened to I64.
            const __mmask16 multiply = _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_MUL));
            const __mmask16 algebra = can_fold | multiply | _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_AND)) |
                                      _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_OR)) | _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_XOR)) |
                                      _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_ASHR));
            conversions |= signed_inputs & ~(chained | from_load | (signed_arithmetic & algebra));
            signed_products = signed_arithmetic & multiply;
'''+s[b:]
k='        result = _mm512_mask_mov_epi32(result, narrow_binary';once(k,'        result = _mm512_mask_mov_epi32(result, signed_products, _mm512_set1_epi32(TIER1_BURS_OP_SIGNED_PRODUCT));\n'+k)
k='        case TIER1_BURS_ACTION_NARROW:';once(k,'''        case TIER1_BURS_ACTION_SIGNED_PRODUCT:
            match = (p == 0 && (pattern->rule == TIER1_RULE_COPY || pattern->rule == TIER1_RULE_SIGN_EXTEND)) ||
                    (pattern->operation == X86_OPERATION_IMUL && pattern->fold_count != 0 && (pattern->rule == TIER1_RULE_IMMEDIATE || pattern->rule == TIER1_RULE_REGISTER));
            break;
'''+k)
once('const bool walked = rule->action == TIER1_BURS_ACTION_NARROW','const bool walked = rule->action == TIER1_BURS_ACTION_SIGNED_PRODUCT || rule->action == TIER1_BURS_ACTION_NARROW')
f.write_text(s)
f=c/'tier1_select_burs_test.c';s=f.read_text()
k='        if (floating && op >= IR_FADD';once(k,'''        if (op == IR_SEXT && type == IR_I64 && function->type[function->a[node]] == IR_I32 && function->op[function->a[node]] == IR_MUL)
        {
            check->mismatches += class != TIER1_BURS_OP_SIGNED_PRODUCT;
        }
'''+k)
k='            if (class == TIER1_BURS_OP_NARROW_BINARY || class == TIER1_BURS_OP_NARROW_UNARY)';once(k,k[:-1]+' || class == TIER1_BURS_OP_SIGNED_PRODUCT)')
f.write_text(s);(d/'check-common.inc').write_text(s.split('#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)')[0])
diff=''
for f in sorted(c.glob('*.c')):
 path='src/buster/compiler/'+f.name;old=check_output(['git','show','cc7d4ffb4:'+path],cwd=p/'tree').decode()
 diff+=''.join(unified_diff(old.splitlines(True),f.read_text().splitlines(True),'a/'+path,'b/'+path))
(p/'product.patch').write_text(diff)
for name in ['build-arity','arity-corpus','arity-tests','arity-measure-sources','arity-bench-source','ordinary-arity','whole-arity','arity-measure-widths']:
 s=(p/name).read_text().replace('arity','product').replace('fpconvert-builds-clean.ok','arity-builds-clean.ok').replace('fpconvert-census.ok','arity-census.ok')
 (p/name.replace('arity','product')).write_text(s)
