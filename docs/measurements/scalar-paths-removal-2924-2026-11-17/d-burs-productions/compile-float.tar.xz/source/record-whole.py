from pathlib import Path
from statistics import median
import re,sys,tarfile
p=Path(__file__).parent;r=p/'results'
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-burs-productions')
tag=sys.argv[1]; rows=[];files=[]
for group,n in [('lua',34),('sqlite',1),('musl',1336)]:
 row=[group]
 for mode in ['default','all']:
  prefix='whole-'+tag+'-'
  a,b=[r/(prefix+f'objects-{mode}-{group}-{side}.sha')for side in ['base','frontier']]
  assert a.read_bytes()==b.read_bytes() and len(a.read_text().splitlines())==n+2
  f=r/(prefix+f'compile-{mode}-{group}.log');s=f.read_text()
  assert s.rstrip().endswith('ab: done, 0 failed runs')
  pairs=[]
  for block in s.split('time-runs: done, 0 failed processes')[:-1]:
   vals={k:int(c) for k,c in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',block,re.M)}
   assert len(vals)==2 and min(vals.values())>0
   pairs.append(vals['head']/vals['base'])
  assert len(pairs)==5
  row.append(f'{100*(median(pairs)-1):+.3f}%'); files.extend((a,b,f))
 rows.append('| '+' | '.join(row)+' |')
title='## End-to-end compilation with '+{'ordered':'floating-point productions in dependency order','signloads':'signed widening load productions','extended':'x87 productions','chosen':'deferred candidate costs','supported':'single-pattern leaves','calls':'ABI-specific call rules','converts':'conversion rules','float': 'floating-point load and binary rules', 'candidateinit': 'initializing the populated candidate slots', 'earlyjump': 'initializing populated slots and classifying control flow early'}[tag]
f=d/'README.md';s=f.read_text();assert title not in s
with tarfile.open(d/('compile-'+tag+'.tar.xz'),'w:xz',preset=2)as t:
 for fn in files:t.add(fn,'native/'+fn.name)
 for n in ['ordinary-'+tag,'whole-'+tag,'record-whole.py']:t.add(p/n,'source/'+n)
 if tag!='supported':
  for n in ['restore-lua-source','lua-src-pinned.sha256']:t.add(Path('/tmp/buster-2924')/n,'source/'+n)
f.write_text(s.rstrip()+'\n\n'+title+'''

Each cell compares five paired rounds of three ordinary compiler processes on the locked 9700X. The table gives the median change in user cycles for a single-lane Tier 1 debug build relative to the parent. All 2,742 objects, standard output and diagnostics matched.

| Corpus | Default passes | All passes |
| --- | ---: | ---: |
'''+'\n'.join(rows)+f'\n\n[Native compiler runs, input commands and object manifests](compile-{tag}.tar.xz)\n')
print(*rows,sep='\n')
