from pathlib import Path
p=Path(__file__).parent
s=(p/'signload-oracle.c').read_text()
s=s.replace('#include "check-common.inc"', '''static bool erase_load;
static uint32_t extended_count;
static void inspect_classes(const Tier1SelectForest* forest, const uint32_t* users, uint32_t* words, uint32_t* classes, uint32_t* kids)
{
    tier1_burs_classify_vector(forest,users,words,classes,kids);
    for (uint32_t i=0;i<forest->function->instruction_count;++i)
    {
        if (erase_load && forest->function->op[i]==IR_LOAD) classes[i]=TIER1_BURS_OP_REG;
        extended_count+=classes[i]==TIER1_BURS_OP_X87;
    }
}
#define tier1_burs_classify_vector inspect_classes
#include "check-common.inc"
#undef tier1_burs_classify_vector''')
a=s.index('    unsigned changed');b=s.index('    Arena input',a)
ir=['param.ptr 0','param.f64 1','param.i32 2','load.f80 %0 align=16','fext.f80 %1','fadd.f80 %3, %4','fsub.f80 %5, %3','fmul.f80 %6, %4','fdiv.f80 %7, %3','copy.f80 %8','fneg.f80 %9','fcmp.i1 %10, %3 lt','sitofp.f80 %2','uitofp.f80 %2','fptosi.i32 %12','fptoui.i32 %13','ftrunc.f64 %10','store.void %0, %10 align=16','const.f80 0x0000000000003fffc000000000000000','undef.f80','ret.void %16']
s=s[:a]+'''    bool changed=false;
    erase_load=strcmp(argv[1],"coverage")==0;
    for (uint32_t i=1;i<tier1_burs_rule_count;++i)
    {
        Tier1BursRule* rule=&tier1_burs_rules[i];
        if (rule->op!=TIER1_BURS_OP_X87) continue;
        if (strcmp(argv[1],"action")==0) { rule->action=TIER1_BURS_ACTION_MUNCH;changed=true; }
        if (strcmp(argv[1],"kind")==0) { rule->kind=TIER1_RULE_FLOAT_BINARY;changed=true; }
    }
    if (!changed && !control && !erase_load) return 2;
    static char program[] =
        "function (ptr, f64, i32) -> f64 {\\nb0:\\n"
'''+''.join(f'        "  %{i} = {inst}\\n"\n' for i,inst in enumerate(ir))+'''        "}\\n";
'''+s[b:]
s=s.replace('    return tested.functions != 1 || tested.nodes != 16', '    printf("x87 productions %u, expected 17\\n", extended_count);\n    return extended_count != 17 || tested.functions != 1 || tested.nodes != 21')
(p/'extended-oracle.c').write_text(s)
