from collections import Counter
from pathlib import Path
import runpy,re,tarfile
p=Path(__file__).resolve().parent;r=p/'results'
doc=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-burs-productions/README.md')
capture=runpy.run_path(str(p/'compare-selected.py'))['compare']
total=Counter();rows=[];files=set()
for mode in ['default','all']:
 for group,num in [('lua',34),('sqlite',1),('musl',1336)]:
  s,_=capture('extended',mode,group);old,_=capture('signloads',mode,group)
  assert s['total']==old['total'] and s['candidate']<=old['candidate']
  total.update(s)
  rows.append(f'| {mode} | {group} | {s["total"]:,} | {old["candidate"]:,} | {s["candidate"]:,} |')
  for tag in ['','extended-']:
   files.add(r/f'{tag}records-{mode}-{group}.bin')
   for ext in ['sha','out','err']:files.add(r/f'{tag}{mode}-{group}.{ext}')
  assert len((r/f'extended-{mode}-{group}.sha').read_text().splitlines())==num
assert total=={'total':1006223,'baseline':396316,'candidate':19716}
for kind in ['select','pipeline-1','pipeline-133','pipeline-789','test-tier1-emit','test-tier1-masks','test-tier1-liveness']:
 f=r/f'extended-{kind}.log';s=f.read_text();files.add(f)
 assert re.search(r'[1-9]\d* checks, 0 failures',s)
 if kind=='select':assert '1530046 checks, 0 failures' in s and '5957, digest d15b788da26467e5' in s
 if kind.startswith('pipeline'):assert re.search(r'native=[1-9]\d* clang=[1-9]\d*',s)
for name,n,m in [('control',17,0),('action',17,17),('kind',17,17),('coverage',16,0)]:
 stem=r/'mutants/extended'/f'x87-{name}';f=stem.with_suffix('.log');st=stem.with_suffix('.status');s=f.read_text();files.update([f,st])
 assert f'x87 productions {n}, expected 17' in s and f'{m} mismatches' in s and int(st.read_text())==int(name!='control')
local=(p/'extended-expanded.log').read_text()
assert '1032 states, 221 rules, 38823 entries' in local and '7362 nodes, 5523 matched, 0 mismatches, 0 uncovered, 0 fallbacks' in local
name='long-double-productions.tar.xz';heading='## Long double operations'
assert heading not in doc.read_text()
with tarfile.open(doc.parent/name,'w:xz',preset=2)as t:
 for f in sorted(files):t.add(f,'native/'+str(f.relative_to(r)))
 for n in ['extended.patch','capture.patch','extended-rules.py','extended-fixture.py','extended-oracle.c','mutate-extended','extended-expanded.log','extended-corpus-compared.log','extended-tests','extended-corpus','build-extended','compare-selected.py','record-extended.py']:t.add(p/n,'source/'+n)
 t.add(p/'extended-src/check-common.inc','source/check-common.inc')
with doc.open('a')as f:
 f.write('\n'+heading+'''

The selector now classifies x87 operations from the result and operand types in each vector of IR instructions. Long double phis use the existing direct phi production. The baked grammar has 1,032 states, 221 rules and 38,823 entries.

| Passes | Corpus | Visited nodes | Signed-load maximal munch | Long double maximal munch |
| --- | --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

The number of maximal-munch visits fell from 396,316 on the original build to 19,716 (95.0% fewer). All 1,006,223 candidate rule lists and chosen indices matched in visit order. All 2,742 debug objects and both output streams matched. The native suite passed the 5,957-plan frozen digest, 1,530,046 selector checks, and three Clang-backed pipeline seeds. A separate 21-node function required 17 x87 classifications. Changing the rule action or kind caused 17 mismatches. Dropping the extended-precision load from that class failed the count independently. The 251 verified repository IR inputs covered 7,362 nodes. These counts measure grammar coverage and correctness. Timing results have their own tables.

[Source, fixtures, faults, native logs, candidate traces and object manifests](long-double-productions.tar.xz)
''')
