// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
//
// The bottom-up rewrite selection's own checks (#141, tier1_select_burs.c), which test-tier1-select runs, and the
// per-function check the pipeline's tests and benchmark-tier1-select-source run on every function they plan:
//
// - the tables: built, the REG leaf's state first, every state's rules the rules' own derivations (a rule names its
//   nonterminal), every operator's table entry a state, and a node of each leaf operator its state;
// - the labeling and the rule choice against their equations (tier1_burs_test_equation) at every node of random
//   columns of every operator and child states drawn from every state the tables have, 16-lane tails and lone levels
//   among them;
// - per function (tier1_burs_check_function): each visible child the node's own earlier operand, every node's state
//   and rule their equations', every node of a class the grammar covers with a candidate of its own
//   (tier1_select_candidates), and the rule's candidate found for each, which it counts. The classes themselves the
//   plans' frozen digest checks (tier1_select_test_digest).
//
// Include after tier1_select_test.c. Keep the per-function check shared for the checker's code-certificate corpus;
// the backend unit alone reads the fixtures below it, at their original definition and inclusion points.

typedef struct Tier1BursCheck Tier1BursCheck;
struct Tier1BursCheck
{
    uint64_t functions;
    uint64_t nodes;
    // Nodes whose children, state or rule break their definitions.
    uint64_t mismatches;
    // Nodes of a class the grammar covers without a candidate: the class promised one.
    uint64_t uncovered;
    // Nodes of a class the grammar covers whose goal rule names a candidate the walks made, and those that took munch's.
    uint64_t matched;
    uint64_t fallbacks;
    // Integer comparisons classed as a truth value's link.
    uint64_t links;
    // Addresses and frame objects' addresses whose class was checked against its definition.
    uint64_t addresses;
};

// The plan's prerequisites, built here apart from it: each node's block, uses, last user, barriers, canonical answer and
// depth (a non-phi operand's depth plus one, as the plan orders its choices), and the nodes in levels. Returns whether
// the function is one the plan reads (operands in range and before their users within a block).
static bool tier1_burs_check_prepare(const IrFunction* function, const IrDominance* dominance, Arena* scratch, uint32_t* blocks, uint32_t* uses, uint32_t* users, uint32_t* barriers, uint8_t* canonical, uint16_t* known_bits,
                                     uint32_t* level_offsets, uint32_t* level_nodes, uint32_t* scope_workspace, uint32_t* maximum_depth)
{
    const uint32_t count = function->instruction_count;
    uint32_t* depths = arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), _Alignof(uint32_t));
    bool valid = depths != 0;
    for (uint32_t block = 0; valid && block < function->block_count; block += 1)
    {
        for (uint32_t node = function->block_offsets[block]; node < function->block_offsets[block + 1]; node += 1)
        {
            blocks[node] = block;
        }
    }
    if (valid)
    {
        memset(uses, 0, (uint64_t)count * sizeof(uint32_t));
        memset(depths, 0, (uint64_t)count * sizeof(uint32_t));
        memset(level_offsets, 0, ((uint64_t)count + 2) * sizeof(uint32_t));
        memset(users, 0xff, (uint64_t)count * sizeof(uint32_t));
    }
    *maximum_depth = 0;
    for (uint32_t node = 0; valid && node < count; node += 1)
    {
        const uint32_t operand_count = (uint32_t)ir_operand_count(function, node);
        for (uint32_t p = 0; valid && p < operand_count; p += 1)
        {
            const IrOperand operand = ir_operand(function, node, p, blocks[node]);
            valid = operand.value < count;
            if (valid)
            {
                uses[operand.value] += 1;
                users[operand.value] = node;
                const uint32_t next = function->op[node] != IR_PHI && operand.value < node ? depths[operand.value] + 1 : 0;
                depths[node] = next > depths[node] ? next : depths[node];
            }
        }
        *maximum_depth = valid && depths[node] > *maximum_depth ? depths[node] : *maximum_depth;
    }
    for (uint32_t node = 0; valid && node < count; node += 1)
    {
        level_offsets[depths[node] + 1] += 1;
    }
    for (uint32_t level = 0; valid && level <= *maximum_depth; level += 1)
    {
        level_offsets[level + 1] += level_offsets[level];
    }
    // Placed in each level by node order, through a copy of the offsets.
    uint32_t* cursors = valid ? arena_push_array(scratch, (uint64_t)count + 2, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    valid = valid && cursors != 0;
    if (valid)
    {
        memcpy(cursors, level_offsets, ((uint64_t)count + 2) * sizeof(uint32_t));
        for (uint32_t node = 0; node < count; node += 1)
        {
            level_nodes[cursors[depths[node]]++] = node;
        }
        tier1_select_barriers(function, count, barriers);
        tier1_select_known_bits(function, dominance, blocks, cursors, known_bits);
        tier1_select_canonical(function, blocks, known_bits, canonical, cursors);
        tier1_select_scoped_ranges(function, dominance, blocks, known_bits, canonical, cursors, scope_workspace);
    }
    return valid;
}

// The labeling's and the rule choice's defining equations at `node`: its state is its operator's table entry at its
// visible children's states mapped (the REG leaf's state for an absent child), and its rule is its state's rule of its
// operator's goal. Whether both hold, from the columns as they are.
static bool tier1_burs_test_equation(uint32_t count, const uint32_t* classes, const uint32_t* kids, const uint32_t* states, const uint32_t* rules, uint32_t node)
{
    const uint32_t op = classes[node];
    const uint32_t left = kids[node] != BUSTER_IR_NONE ? states[kids[node]] : BUSTER_TIER1_BURS_REG_STATE;
    const uint32_t right = kids[count + node] != BUSTER_IR_NONE ? states[kids[count + node]] : BUSTER_TIER1_BURS_REG_STATE;
    const uint32_t row = tier1_burs_pool[tier1_burs_map_base[0][op] + left];
    const uint32_t column = tier1_burs_pool[tier1_burs_map_base[1][op] + right];
    const uint32_t state = tier1_burs_pool[tier1_burs_table_base[op] + row * tier1_burs_table_width[op] + column];
    return states[node] == state && rules[node] == tier1_burs_state_rules[states[node] * TIER1_BURS_NONTERMINALS + tier1_burs_goal[op]];
}

// The definition of an address's displacement fitting a disp32 (its constant index scaled, plus its offset, in exact
// arithmetic): the condition of its lea's candidate (tier1_select_candidates). An address past it has no candidate, and
// its class is the REG leaf's; tier1_burs_classify_vector's limbs must agree with it.
static bool tier1_burs_displacement(const IrFunction* function, uint32_t node)
{
    const IrAddress operand = function->addresses[function->c[node]];
    const uint32_t b = function->b[node];
    uint64_t constant = 0;
    const bool constant_index = b != BUSTER_IR_NONE && tier1_select_constant(function, b, &constant);
    int64_t displacement = 0;
    return !__builtin_mul_overflow((int64_t)(constant_index ? constant : 0), (int64_t)operand.scale, &displacement) && !__builtin_add_overflow(displacement, operand.offset, &displacement) &&
           displacement == (int64_t)(int32_t)displacement;
}

// Checks `function` (verified, with dominance) into `check`: its children, states and rules against their definitions,
// and the candidates of the grammar's classes.
static void tier1_burs_check_function(Tier1BursCheck* check, const IrFunction* function, const IrDominance* dominance, Arena* scratch)
{
    const uint64_t mark = scratch->length;
    const uint32_t count = function->instruction_count;
    uint32_t* blocks = arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), 64);
    uint32_t* uses = arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), 64);
    uint32_t* users = arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), 64);
    uint32_t* barriers = arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), 64);
    uint8_t* canonical = arena_push_array(scratch, (uint64_t)count + 1, 1, 64);
    uint16_t* known_bits = arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint16_t), 64);
    uint32_t* level_offsets = arena_push_array(scratch, (uint64_t)count + 2, sizeof(uint32_t), 64);
    uint32_t* level_nodes = arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), 64);
    uint32_t* words = arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), 64);
    uint32_t* columns[4];
    bool valid = blocks != 0 && uses != 0 && users != 0 && barriers != 0 && canonical != 0 && known_bits != 0 && level_offsets != 0 && level_nodes != 0 && words != 0 && tier1_select_initialize();
    // Classes, children (two columns), states and rules.
    columns[0] = valid ? arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), 64) : 0;
    columns[1] = valid ? arena_push_array(scratch, (uint64_t)count * 2 + 1, sizeof(uint32_t), 64) : 0;
    columns[2] = valid ? arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), 64) : 0;
    columns[3] = valid ? arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), 64) : 0;
    valid = valid && columns[0] != 0 && columns[1] != 0 && columns[2] != 0 && columns[3] != 0;
    uint32_t maximum_depth = 0;
    valid = valid && tier1_burs_check_prepare(function, dominance, scratch, blocks, uses, users, barriers, canonical, known_bits, level_offsets, level_nodes, words, &maximum_depth);
    const Tier1SelectForest forest = {
        .function = function,
        .blocks = blocks,
        .uses = uses,
        .costs = 0,
        .barriers = barriers,
        .canonical = canonical,
        .known_bits = known_bits,
        .vectors = ir_function_has_vectors(function),
    };
    if (valid)
    {
        tier1_burs_classify_vector(&forest, users, words, columns[0], columns[1]);
        tier1_burs_label_vector(maximum_depth, level_offsets, level_nodes, count, columns[0], columns[1], columns[2]);
        tier1_burs_rules_vector(count, columns[0], columns[2], columns[3]);
        check->functions += 1;
        check->nodes += count;
    }
    // The candidates need the costs column the plan keeps: zero, which the candidates' costs alone read.
    uint32_t* costs = valid ? arena_push_array(scratch, (uint64_t)count + 1, sizeof(uint32_t), 64) : 0;
    valid = valid && costs != 0;
    if (valid)
    {
        memset(costs, 0, (uint64_t)count * sizeof(uint32_t));
    }
    const Tier1SelectForest costed = {
        .function = function,
        .blocks = blocks,
        .uses = uses,
        .costs = costs,
        .barriers = barriers,
        .canonical = canonical,
        .known_bits = known_bits,
        .vectors = ir_function_has_vectors(function),
    };
    for (uint32_t node = 0; valid && node < count; node += 1)
    {
        // A visible child is the node's own operand, an earlier node; its state and rule are their equations' (tier1_burs_test_equations).
        const uint32_t a = columns[1][node];
        const uint32_t b = columns[1][count + node];
        const bool same = (a == BUSTER_IR_NONE || (a == function->a[node] && a < node)) && (b == BUSTER_IR_NONE || (b == function->b[node] && b < node)) &&
                          tier1_burs_test_equation(count, columns[0], columns[1], columns[2], columns[3], node);
        if (!same && check->mismatches < 8)
        {
            fprintf(stderr, "  burs node %u (%s) breaks its equations: class %u, children %u,%u, state %u, rule %u\n", node, ir_op_names[function->op[node]],
                    columns[0][node], a, b, columns[2][node], columns[3][node]);
        }
        check->mismatches += !same;
        // An address's class by its displacement's definition (tier1_burs_displacement), and a frame object's address's by
        // its slot's (tier1_select_stack_object), which the vector classifier computes from gathers (#3450).
        const uint32_t op = function->op[node];
        if (op == IR_ADDRESS || op == IR_STACK_ADDR)
        {
            const uint32_t b_child = function->b[node];
            const uint32_t expected = op == IR_STACK_ADDR ? (tier1_select_stack_object(function, function->a[node]) ? (blocks[node] == 0 ? TIER1_BURS_OP_SLOT_X : TIER1_BURS_OP_SLOT) : TIER1_BURS_OP_REG) :
                                      !tier1_burs_displacement(function, node) ? TIER1_BURS_OP_REG :
                                      b_child == BUSTER_IR_NONE ? TIER1_BURS_OP_ADDR_NOIDX :
                                      b_child < count && function->op[b_child] == IR_CONST ? TIER1_BURS_OP_ADDR_CIDX : TIER1_BURS_OP_ADDR_IDX;
            if (columns[0][node] != expected && check->mismatches < 8)
            {
                fprintf(stderr, "  burs node %u (%s) has class %u, its definition's %u\n", node, ir_op_names[op], columns[0][node], expected);
            }
            check->mismatches += columns[0][node] != expected;
            check->addresses += 1;
        }
        // An integer comparison's class is the link's exactly where it is one (tier1_select_truth): eq or ne of the zero
        // extension two nodes before it, of the I1 right before that, and of a zero right before it that it alone uses,
        // in its block.
        const uint32_t class = columns[0][node];
        const uint32_t type = function->type[node];
        const bool plain_type = (type >= IR_I1 && type <= IR_I64) || type == IR_PTR || type == IR_F32 || type == IR_F64;
        const bool plain = op == IR_BR || op == IR_BR_INDIRECT || op == IR_SYMBOL_ADDR || op == IR_LIFETIME ||
                           op == IR_UNREACHABLE || op == IR_FENCE || op == IR_STACK_SAVE ||
                           (op == IR_PARAM && plain_type && function->a[node] < BUSTER_TIER1_SELECT_MAX_ARGUMENTS) ||
                           (op == IR_PHI && plain_type) || (op == IR_COPY && plain_type && type != IR_I1) ||
                           ((op == IR_NEG || op == IR_NOT) && (type == IR_I32 || type == IR_I64)) ||
                           (op == IR_TRUNC && (type == IR_I8 || type == IR_I16 || type == IR_I32) && function->type[function->a[node]] == IR_I64) ||
                           (op == IR_SEXT && (type == IR_I16 || type == IR_I32 || type == IR_I64) && function->op[function->a[node]] == IR_PARAM &&
                            (function->type[function->a[node]] >= IR_I8 && function->type[function->a[node]] <= IR_I32)) || (op == IR_RET && function->a[node] == BUSTER_IR_NONE);
        const bool floating = type == IR_F32 || type == IR_F64;
        if (op == IR_SEXT && (type == IR_I32 || type == IR_I64) && function->op[function->a[node]] == IR_LOAD &&
            function->type[function->a[node]] >= IR_I8 && function->type[function->a[node]] <= IR_I32)
        {
            check->mismatches += class != TIER1_BURS_OP_SIGN_LOAD;
        }
        if (floating && op >= IR_FADD && op <= IR_FDIV)
        {
            const bool left = (op == IR_FADD || op == IR_FMUL) && function->op[function->b[node]] != IR_LOAD;
            check->mismatches += class != (left ? TIER1_BURS_OP_FLOAT_BINARY_LEFT : TIER1_BURS_OP_FLOAT_BINARY_RIGHT);
        }
        if (floating && op == IR_LOAD)
        {
            const bool folded = users[node] < count && tier1_select_load_folds(&forest, users[node], node);
            check->mismatches += class != (folded ? TIER1_BURS_OP_FLOAT_LOAD_F : TIER1_BURS_OP_FLOAT_LOAD_N);
        }
        if (plain)
        {
            check->mismatches += class != TIER1_BURS_OP_DIRECT;
        }
        if (class == TIER1_BURS_OP_ICMP || class == TIER1_BURS_OP_ICMP_LINK)
        {
            const uint32_t extended = function->a[node];
            const uint32_t zero = function->b[node];
            const bool shaped = function->c[node] <= IR_NE && extended + 2 == node && zero + 1 == node && function->op[extended] == IR_ZEXT && function->op[zero] == IR_CONST;
            const bool link = shaped && function->a[extended] + 1 == extended && function->type[function->a[extended]] == IR_I1 && function->constants[function->a[zero]].low == 0 &&
                              uses[zero] == 1 && blocks[zero] == blocks[node];
            if ((class == TIER1_BURS_OP_ICMP_LINK) != link && check->mismatches < 8)
            {
                fprintf(stderr, "  burs comparison %u classed %u where its link's definition says %s\n", node, class, link ? "a link" : "none");
            }
            check->mismatches += (class == TIER1_BURS_OP_ICMP_LINK) != link;
            check->links += class == TIER1_BURS_OP_ICMP_LINK;
        }
        if (columns[0][node] != TIER1_BURS_OP_REG)
        {
            const Tier1SelectCandidates candidates = tier1_select_candidates(&costed, node, TIER1_RULE_NONE);
            bool munched = false;
            const uint32_t chosen = tier1_burs_pick(&candidates, columns[3][node], &munched);
            if (class >= TIER1_BURS_OP_SIGN_LOAD && class <= TIER1_BURS_OP_FLOAT_BINARY_LEFT)
            {
                check->mismatches += candidates.count == 0 || munched || chosen != tier1_select_munch(&candidates);
            }
            if (tier1_select_x87_node(function, node) && candidates.count != 0 && candidates.patterns[0].rule == TIER1_RULE_X87)
            {
                check->mismatches += class != TIER1_BURS_OP_X87;
            }
            if (class == TIER1_BURS_OP_X87)
            {
                check->mismatches += munched || candidates.count != 1 || candidates.patterns[0].rule != TIER1_RULE_X87 ||
                                     tier1_burs_rules[columns[3][node]].kind != TIER1_RULE_X87;
            }
            if (class >= TIER1_BURS_OP_CALL && class <= TIER1_BURS_OP_CALL_ROW)
            {
                const Tier1BursRule* rule = &tier1_burs_rules[columns[3][node]];
                check->mismatches += candidates.count != 1 || munched || rule->action != TIER1_BURS_ACTION_PLAIN ||
                                     rule->kind != candidates.patterns[0].rule;
            }
            if (class == TIER1_BURS_OP_DIRECT)
            {
                // A second pattern requires a grammar choice. Catch it here even if both emit the same code today.
                check->mismatches += candidates.count != 1 || munched || tier1_burs_rules[columns[3][node]].action != TIER1_BURS_ACTION_PLAIN;
            }
            if (candidates.count == 0 && check->uncovered < 8)
            {
                fprintf(stderr, "  burs class %u without a candidate at node %u (%s, type %u, a %u, b %u, uses %u)\n", columns[0][node], node, ir_op_names[function->op[node]], function->type[node],
                        function->a[node], function->b[node], uses[node]);
            }
            check->uncovered += candidates.count == 0;
            check->matched += candidates.count != 0 && !munched;
            check->fallbacks += munched;
        }
    }
    arena_pop_to(scratch, mark);
}

