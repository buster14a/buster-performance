from pathlib import Path
from shutil import copytree
from difflib import unified_diff
from subprocess import check_output
p=Path(__file__).parent;d=p/'extended-src';copytree(p/'signloads-src',d,dirs_exist_ok=True)
c=d/'buster/compiler';f=c/'tier1_select_burs.c';s=f.read_text()
s=s.replace('    TIER1_BURS_OP_FLOAT_BINARY_LEFT,','    TIER1_BURS_OP_FLOAT_BINARY_LEFT,\n    TIER1_BURS_OP_X87,',1).replace('    TIER1_BURS_FAMILY_SIGN_LOAD,','    TIER1_BURS_FAMILY_X87,\n    TIER1_BURS_FAMILY_SIGN_LOAD,',1)
i=s.index('    // A signed widening')
s=s[:i]+'''    // The x87 operations read and write their own frame objects. Their data operands are materialized by the pattern.
    { TIER1_BURS_REG, TIER1_BURS_FAMILY_X87, 0, { BUSTER_TIER1_BURS_NO_KID, BUSTER_TIER1_BURS_NO_KID }, 3, TIER1_BURS_ACTION_PLAIN, TIER1_RULE_X87 },
'''+s[i:]
s=s.replace('    case TIER1_BURS_FAMILY_SIGN_LOAD:', '''    case TIER1_BURS_FAMILY_X87:
        member = op == TIER1_BURS_OP_X87;
        break;
    case TIER1_BURS_FAMILY_SIGN_LOAD:''',1)
i=s.index('        _mm512_mask_storeu_epi32(classes + first, active, result);')
s=s[:i]+'''        const __mmask16 f80 = _mm512_mask_cmpeq_epi32_mask(active, type, _mm512_set1_epi32(IR_F80));
        const __mmask16 a80 = _mm512_mask_cmpeq_epi32_mask(a_valid, a_type, _mm512_set1_epi32(IR_F80));
        const __mmask16 b80 = _mm512_mask_cmpeq_epi32_mask(b_valid, b_type, _mm512_set1_epi32(IR_F80));
        if ((f80 | a80 | b80) != 0)
        {
            const uint32_t values = (1u << IR_CONST) | (1u << IR_UNDEF) | (1u << IR_COPY) | (1u << IR_FNEG) |
                                    (1u << IR_FADD) | (1u << IR_FSUB) | (1u << IR_FMUL) | (1u << IR_FDIV);
            __mmask16 x87 = tier1_burs_types(f80, op, values) | _mm512_mask_cmpeq_epi32_mask(f80, op, _mm512_set1_epi32(IR_LOAD)) |
                            _mm512_mask_cmpeq_epi32_mask(b80, op, _mm512_set1_epi32(IR_STORE)) | _mm512_mask_cmpeq_epi32_mask(a80, op, _mm512_set1_epi32(IR_FCMP));
            x87 |= _mm512_mask_cmpeq_epi32_mask(f80 & tier1_burs_types(a_valid, a_type, floats), op, _mm512_set1_epi32(IR_FEXT));
            x87 |= _mm512_mask_cmpeq_epi32_mask(a80 & floating, op, _mm512_set1_epi32(IR_FTRUNC));
            x87 |= f80 & tier1_burs_types(a_valid, a_type, memory) &
                   (_mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_SITOFP)) | _mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_UITOFP)));
            x87 |= a80 & tier1_burs_types(active, type, memory) &
                   (_mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_FPTOSI)) | _mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_FPTOUI)));
            result = _mm512_mask_mov_epi32(result, x87, _mm512_set1_epi32(TIER1_BURS_OP_X87));
            result = _mm512_mask_mov_epi32(result, _mm512_mask_cmpeq_epi32_mask(f80, op, _mm512_set1_epi32(IR_PHI)), _mm512_set1_epi32(TIER1_BURS_OP_DIRECT));
        }
'''+s[i:]
f.write_text(s)
f=c/'tier1_select_burs_test.c';s=f.read_text()
a=s.index('            if (class >= TIER1_BURS_OP_CALL')
s=s[:a]+'''            if (tier1_select_x87_node(function, node) && candidates.count != 0 && candidates.patterns[0].rule == TIER1_RULE_X87)
            {
                check->mismatches += class != TIER1_BURS_OP_X87;
            }
            if (class == TIER1_BURS_OP_X87)
            {
                check->mismatches += munched || candidates.count != 1 || candidates.patterns[0].rule != TIER1_RULE_X87 ||
                                     tier1_burs_rules[columns[3][node]].kind != TIER1_RULE_X87;
            }
'''+s[a:]
f.write_text(s);(d/'check-common.inc').write_text(s.split('#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)')[0])
diff=''
for f in sorted(c.glob('*.c')):
 name='src/buster/compiler/'+f.name;old=check_output(['git','show','cc7d4ffb4:'+name],cwd=p/'tree').decode()
 diff+=''.join(unified_diff(old.splitlines(True),f.read_text().splitlines(True),'a/'+name,'b/'+name))
(p/'extended.patch').write_text(diff)
for name in ['build-signloads','signloads-corpus','signloads-tests','signloads-measure-sources','signloads-bench-source','ordinary-signloads','whole-signloads','signloads-measure-widths']:
 s=(p/name).read_text().replace('signloads','extended').replace('checked-ordered-census.ok','signloads-census.ok')
 if name=='build-signloads':s=s.replace('/dev/shm/buster-flagged-declarations-6b097f86/inline-built.ok','/dev/shm/buster-cfg-cleanup-6b097f86/adjacent-builds-clean.ok').replace('Build extended BURS grammar extended','Build x87 grammar productions')
 (p/name.replace('signloads','extended')).write_text(s)
