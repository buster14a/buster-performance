#define _GNU_SOURCE
#include "buster/compiler/tier1_select_benchmark.c"
#include "buster/compiler/ir_validate.c"
#include "buster/compiler/ir_parse.c"
static bool erase_load;
static uint32_t extended_count;
static void inspect_classes(const Tier1SelectForest* forest, const uint32_t* users, uint32_t* words, uint32_t* classes, uint32_t* kids)
{
    tier1_burs_classify_vector(forest,users,words,classes,kids);
    for (uint32_t i=0;i<forest->function->instruction_count;++i)
    {
        if (erase_load && forest->function->op[i]==IR_LOAD) classes[i]=TIER1_BURS_OP_REG;
        extended_count+=classes[i]==TIER1_BURS_OP_X87;
    }
}
#define tier1_burs_classify_vector inspect_classes
#include "check-common.inc"
#undef tier1_burs_classify_vector

int main(int argc, char** argv)
{
    if (argc != 2 || !tier1_select_initialize()) return 2;
    const bool control = strcmp(argv[1], "control") == 0;
    bool changed=false;
    erase_load=strcmp(argv[1],"coverage")==0;
    for (uint32_t i=1;i<tier1_burs_rule_count;++i)
    {
        Tier1BursRule* rule=&tier1_burs_rules[i];
        if (rule->op!=TIER1_BURS_OP_X87) continue;
        if (strcmp(argv[1],"action")==0) { rule->action=TIER1_BURS_ACTION_MUNCH;changed=true; }
        if (strcmp(argv[1],"kind")==0) { rule->kind=TIER1_RULE_FLOAT_BINARY;changed=true; }
    }
    if (!changed && !control && !erase_load) return 2;
    static char program[] =
        "function (ptr, f64, i32) -> f64 {\nb0:\n"
        "  %0 = param.ptr 0\n"
        "  %1 = param.f64 1\n"
        "  %2 = param.i32 2\n"
        "  %3 = load.f80 %0 align=16\n"
        "  %4 = fext.f80 %1\n"
        "  %5 = fadd.f80 %3, %4\n"
        "  %6 = fsub.f80 %5, %3\n"
        "  %7 = fmul.f80 %6, %4\n"
        "  %8 = fdiv.f80 %7, %3\n"
        "  %9 = copy.f80 %8\n"
        "  %10 = fneg.f80 %9\n"
        "  %11 = fcmp.i1 %10, %3 lt\n"
        "  %12 = sitofp.f80 %2\n"
        "  %13 = uitofp.f80 %2\n"
        "  %14 = fptosi.i32 %12\n"
        "  %15 = fptoui.i32 %13\n"
        "  %16 = ftrunc.f64 %10\n"
        "  %17 = store.void %0, %10 align=16\n"
        "  %18 = const.f80 0x0000000000003fffc000000000000000\n"
        "  %19 = undef.f80\n"
        "  %20 = ret.void %16\n"
        "}\n";
    Arena input = arena_reserve(1u << 24), scratch = arena_reserve(1u << 26);
    IrFunction function;
    if (ir_parse((String8){.pointer=program,.length=sizeof(program)-1}, &input, &scratch, &function).error != IR_PARSE_OK ||
        ir_verify(&function, &scratch, 0).error != IR_OK) return 3;
    Tier1BursCheck tested = {0};
    tier1_burs_check_function(&tested, &function, 0, &scratch);
    printf("checked %" PRIu64 " nodes, %" PRIu64 " direct, %" PRIu64 " mismatches, %" PRIu64 " uncovered, %" PRIu64 " fallbacks\n",
           tested.nodes, tested.matched, tested.mismatches, tested.uncovered, tested.fallbacks);
    arena_release(&scratch);
    arena_release(&input);
    printf("x87 productions %u, expected 17\n", extended_count);
    return extended_count != 17 || tested.functions != 1 || tested.nodes != 21 || tested.uncovered || tested.mismatches || tested.fallbacks;
}
