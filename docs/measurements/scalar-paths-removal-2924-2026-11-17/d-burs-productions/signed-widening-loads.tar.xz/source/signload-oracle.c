#define _GNU_SOURCE
#include "buster/compiler/tier1_select_benchmark.c"
#include "buster/compiler/ir_validate.c"
#include "buster/compiler/ir_parse.c"
#include "check-common.inc"

int main(int argc, char** argv)
{
    if (argc != 2 || !tier1_select_initialize()) return 2;
    const bool control = strcmp(argv[1], "control") == 0;
    unsigned changed = 0;
    for (uint32_t i = 1; i < tier1_burs_rule_count; ++i)
    {
        Tier1BursRule* rule = &tier1_burs_rules[i];
        if (rule->op != TIER1_BURS_OP_SIGN_LOAD) continue;
        if ((strcmp(argv[1],"load") == 0 && rule->kind == TIER1_RULE_LOAD_ADDRESS) ||
            (strcmp(argv[1],"register") == 0 && rule->action == TIER1_BURS_ACTION_PLAIN))
        {
            rule->action = TIER1_BURS_ACTION_MUNCH;
            ++changed;
        }
        if (strcmp(argv[1],"memory-goal") == 0 && rule->kind == TIER1_RULE_LOAD_ADDRESS)
        {
            rule->action = TIER1_BURS_ACTION_PLAIN;
            ++changed;
        }
    }
    if (!control && !changed) return 2;
    static char program[] =
        "function (ptr, i8) -> i64 {\n"
        "b0:\n"
        "  %0 = param.ptr 0\n"
        "  %1 = param.i8 1\n"
        "  %2 = address.ptr %0 offset=8\n"
        "  %3 = load.i8 %2 align=1\n"
        "  %4 = sext.i64 %3\n"
        "  %5 = load.i16 %0 align=2\n"
        "  %6 = sext.i32 %5\n"
        "  %7 = sext.i64 %5\n"
        "  %8 = load.i8 %2 align=1\n"
        "  %9 = store.void %0, %1 align=1\n"
        "  %10 = sext.i64 %8\n"
        "  %11 = sext.i64 %6\n"
        "  %12 = add.i64 %4, %11\n"
        "  %13 = add.i64 %12, %7\n"
        "  %14 = add.i64 %13, %10\n"
        "  %15 = ret.void %14\n"
        "}\n";
    Arena input = arena_reserve(1u << 24), scratch = arena_reserve(1u << 26);
    IrFunction function;
    if (ir_parse((String8){.pointer=program,.length=sizeof(program)-1}, &input, &scratch, &function).error != IR_PARSE_OK ||
        ir_verify(&function, &scratch, 0).error != IR_OK) return 3;
    Tier1BursCheck tested = {0};
    tier1_burs_check_function(&tested, &function, 0, &scratch);
    printf("checked %" PRIu64 " nodes, %" PRIu64 " direct, %" PRIu64 " mismatches, %" PRIu64 " uncovered, %" PRIu64 " fallbacks\n",
           tested.nodes, tested.matched, tested.mismatches, tested.uncovered, tested.fallbacks);
    arena_release(&scratch);
    arena_release(&input);
    return tested.functions != 1 || tested.nodes != 16 || tested.uncovered || tested.mismatches || tested.fallbacks;
}
