from pathlib import Path
from shutil import copytree
from subprocess import check_output
from difflib import unified_diff
p=Path(__file__).parent;d=p/'signloads-src';copytree(p/'ordered-src',d,dirs_exist_ok=True)
c=d/'buster/compiler';f=c/'tier1_select_burs.c';s=f.read_text()
s=s.replace('    TIER1_BURS_OP_FLOAT_LOAD_F,','    TIER1_BURS_OP_SIGN_LOAD,\n    TIER1_BURS_OP_FLOAT_LOAD_F,',1)
s=s.replace('    TIER1_BURS_FAMILY_FLOAT_LOAD,','    TIER1_BURS_FAMILY_SIGN_LOAD,\n    TIER1_BURS_FAMILY_FLOAT_LOAD,',1)
k='    // A floating binary operation'
s=s.replace(k,'''    // A signed widening reads a scalar load directly when its single use can fold
    // without crossing a memory barrier. Otherwise only the register extension remains.
    { TIER1_BURS_REG, TIER1_BURS_FAMILY_SIGN_LOAD, 0, { TIER1_BURS_REG, BUSTER_TIER1_BURS_NO_KID }, 1, TIER1_BURS_ACTION_PLAIN, TIER1_RULE_NONE },
    { TIER1_BURS_REG, TIER1_BURS_FAMILY_SIGN_LOAD, 0, { TIER1_BURS_LOADF, BUSTER_TIER1_BURS_NO_KID }, 1, TIER1_BURS_ACTION_KIND, TIER1_RULE_LOAD_ADDRESS },
'''+k)
s=s.replace('    case TIER1_BURS_FAMILY_FLOAT_BINARY:', '''    case TIER1_BURS_FAMILY_SIGN_LOAD:
        member = op == TIER1_BURS_OP_SIGN_LOAD;
        break;
    case TIER1_BURS_FAMILY_FLOAT_BINARY:''',1)
s=s.replace('        __mmask16 conversions = 0;', '        __mmask16 conversions = 0;\n        __mmask16 sign_loads = 0;')
s=s.replace('            conversions |= signed_inputs & terminal;', '''            const __mmask16 from_load = _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_LOAD));
            const __mmask16 wide_result = _mm512_mask_cmpeq_epi32_mask(signed_inputs, type, _mm512_set1_epi32(IR_I64));
            const __mmask16 signed_arithmetic = _mm512_mask_cmpeq_epi32_mask(wide_result, a_type, _mm512_set1_epi32(IR_I32));
            const __mmask16 chained = _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_SEXT)) | _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_TRUNC));
            // Algebraic extension patterns operate on an I32 definition widened to I64.
            // Other widths have one register pattern unless the definition is itself a conversion or load.
            conversions |= signed_inputs & (terminal | ~(signed_arithmetic | chained | from_load));
            const __mmask16 from_integer = _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_COPY)) | _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_ZEXT)) |
                                          _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_SHL)) | _mm512_cmpeq_epi32_mask(a_op, _mm512_set1_epi32(IR_LSHR));
            conversions |= signed_inputs & from_integer;
            sign_loads = signed_inputs & from_load & integer;
            conversions |= signed_inputs & from_load & ~integer;''')
k='        // Constants: their class bits'
s=s.replace(k,'        result = _mm512_mask_mov_epi32(result, sign_loads, _mm512_set1_epi32(TIER1_BURS_OP_SIGN_LOAD));\n'+k)
f.write_text(s)
# Fold in the earlier experiment that moved unconditional control operations before general classification.
f=c/'tier1_select.c';s=f.read_text()
a=s.index('static __attribute__((noinline)) bool tier1_select_burs_pattern')
base=(p/'earlyjump-src/buster/compiler/tier1_select.c').read_text()
b=base.index('static __attribute__((noinline)) bool tier1_select_burs_pattern')
s=base[:b]+s[a:]
s=s.replace('op >= TIER1_BURS_OP_FLOAT_LOAD_F)','op >= TIER1_BURS_OP_SIGN_LOAD)');f.write_text(s)
f=c/'tier1_select_burs_test.c';s=f.read_text().replace('            if (class >= TIER1_BURS_OP_FLOAT_LOAD_F','            if (class >= TIER1_BURS_OP_SIGN_LOAD')
k='        if (floating && op >= IR_FADD'
s=s.replace(k,'''        if (op == IR_SEXT && (type == IR_I32 || type == IR_I64) && function->op[function->a[node]] == IR_LOAD &&
            function->type[function->a[node]] >= IR_I8 && function->type[function->a[node]] <= IR_I32)
        {
            check->mismatches += class != TIER1_BURS_OP_SIGN_LOAD;
        }
'''+k)
f.write_text(s);(d/'check-common.inc').write_text(s.split('#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)')[0])
diff=''
for f in sorted(c.glob('*.c')):
 name='src/buster/compiler/'+f.name
 old=check_output(['git','show','cc7d4ffb4:'+name],cwd=p/'tree').decode()
 diff+=''.join(unified_diff(old.splitlines(True),f.read_text().splitlines(True),'a/'+name,'b/'+name))
(p/'signloads.patch').write_text(diff)
for name in ['build-ordered','checked-ordered-corpus','ordered-tests','ordered-measure-sources','ordered-bench-source','ordinary-ordered','whole-ordered','ordered-measure-widths']:
 s=(p/name).read_text().replace('checked-ordered','signloads').replace('ordered','signloads')
 if name=='build-ordered':
  s=s.replace('"$root/candidates-builds-clean.ok"','/dev/shm/buster-flagged-declarations-6b097f86/inline-built.ok')
 if name=='checked-ordered-corpus':
  s=s.replace('float-census.ok','checked-ordered-census.ok')
 (p/name.replace('checked-ordered','signloads').replace('ordered','signloads')).write_text(s)
