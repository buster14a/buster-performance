from pathlib import Path
from collections import Counter
import runpy,re,tarfile
p=Path(__file__).parent;r=p/'results'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-burs-productions')
capture=runpy.run_path(str(p/'compare-selected.py'))['compare']
rows=[];total=Counter();previous=0;files=set()
for mode in ('default','all'):
 for corpus,n in [('lua',34),('sqlite',1),('musl',1336)]:
  stats,_=capture('signloads',mode,corpus);old,_=capture('checked-ordered',mode,corpus)
  total.update(stats);previous+=old['candidate']
  assert len((r/f'signloads-{mode}-{corpus}.sha').read_text().splitlines())==n
  rows.append(f'| {mode} | {corpus} | {stats["total"]:,} | {stats["baseline"]:,} | {old["candidate"]:,} | {stats["candidate"]:,} |')
  for pattern in [f'signloads-{{part}}{mode}-{corpus}',f'{{part}}{mode}-{corpus}']:
   files.add(r/(pattern.format(part='records-')+'.bin'))
   for ext in ['sha','out','err']:files.add(r/(pattern.format(part='')+'.'+ext))
assert total=={'total':1006223,'baseline':396316,'candidate':27534} and previous==43455
for f in ['select','pipeline-1','pipeline-133','pipeline-789','test-tier1-emit','test-tier1-masks','test-tier1-liveness']:
 path=r/f'signloads-{f}.log';files.add(path);s=path.read_text()
 assert re.search(r'[1-9]\d* checks, 0 failures',s)
 if f=='select':assert '1530046 checks, 0 failures' in s and '5957, digest d15b788da26467e5' in s
 if f.startswith('pipeline'):assert re.search(r'native=[1-9]\d* clang=[1-9]\d*',s)
m=r/'mutants/signloads';faults=0
for pref,n,variants in [('',19,'control munch state goal missing'),('conversion-',19,'control munch state goal missing'),('float-',14,'control right left load store register'),('signload-',16,'control load register memory-goal')]:
 for tag in variants.split():
  st=m/(pref+tag+'.status');log=m/(pref+tag+'.log');s=log.read_text()
  files.update([st,log]);assert f'{n} nodes' in s and int(st.read_text())==int(tag!='control')
  if tag=='control':assert '0 mismatches' in s
  else:assert re.search(r'[1-9]\d* mismatches',s);faults+=1
assert faults==16
local=(p/'signloads-expanded.log').read_text()
assert '1031 states, 220 rules, 38792 entries' in local and '7362 nodes, 5521 matched, 0 mismatches, 0 uncovered, 0 fallbacks' in local
heading='## Signed widening loads'
doc=out/'README.md';assert heading not in doc.read_text()
with tarfile.open(out/'signed-widening-loads.tar.xz','w:xz',preset=2)as t:
 for file in sorted(files):t.add(file,'native/'+str(file.relative_to(r)))
 for name in ['signloads.patch','capture.patch','sign-loads.py','signloads-corpus','build-signloads','signloads-tests','mutate-signloads','signload-oracle.c','leaf-oracle.c','conversion-oracle.c','float-oracle.c','float-files.c','local-fp','signloads-expanded.log','compare-selected.py','record-signloads.py']:t.add(p/name,'source/'+name)
with doc.open('a')as fp:fp.write('\n'+heading+'''

Sign extension can fold a single-use signed load into the machine instruction. The new production distinguishes a foldable load from a register input, including an address the selector walks and a memory barrier between the load and extension. Calls and terminators also bypass unused candidate-slot initialization. The baked grammar has 1,031 states, 220 rules and 38,792 entries.

| Passes | Corpus | Visited nodes | Parent maximal munch | Floating-point revision | Signed-load revision |
| --- | --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

Across the six compilations the revision reduced maximal-munch visits from 396,316 to 27,534 (93.1%). All 1,006,223 complete candidate rule lists and chosen indices matched the parent in visit order. All 2,742 debug objects and both output streams matched. The compiler passed the 5,957-plan frozen digest, 1,530,046 selector checks and three Clang-backed pipeline seeds. The independent 16-node function caught all three signed-load faults. The original direct, conversion and floating-point fixtures caught their 13 injected faults. A further 251 verified repository IR inputs covered 7,362 nodes.

[Probe and production source, oracle inputs, native checks, full candidate traces and object manifests](signed-widening-loads.tar.xz)
''')
print(total)
