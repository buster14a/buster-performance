from array import array
from pathlib import Path
from collections import Counter
from hashlib import sha256
import sys,re
p=Path(__file__).parent;r=p/'results'
optext=(p/'tree/src/buster/compiler/ir.c').read_text().split('typedef enum IrOp\n{')[1].split('} IrOp')[0]
opnames=re.findall(r'^\s*(IR_\w+)\s*,',optext,re.M)
multi_float={'IR_LOAD','IR_STORE','IR_FADD','IR_FSUB','IR_FMUL','IR_FDIV'}
def read(path):
 a=array('I');a.frombytes(path.read_bytes());assert a.itemsize==4 and sys.byteorder=='little'
 n=0
 while n<len(a):
  h=a[n:n+8];assert len(h)==8;size,node,op,typ,rule,count,ch,munch=h
  assert size>node and munch<=1 and (ch<count or (count==0 and ch==0xffffffff))
  kinds=a[n+8:n+8+count];assert len(kinds)==count
  yield tuple(h),tuple(kinds)
  n+=8+count
 assert n==len(a)
def compare(tag,mode,group):
 a=r/f'records-{mode}-{group}.bin';b=r/f'{tag}-records-{mode}-{group}.bin'
 samples=Counter();ops=Counter()
 for (old,ak),(new,bk) in zip(read(a),read(b),strict=True):
  assert old[:4]==new[:4] and old[5:7]==new[5:7] and ak==bk,(mode,group,old,new,ak,bk)
  assert new[7]<=old[7],(old,new)
  samples['total']+=1;samples['baseline']+=old[7];samples['candidate']+=new[7]
  if new[7]!=old[7]:
   allowed_multi=multi_float if tag in ('float','ordered','checked-ordered','signloads','extended','chosen','narrow','fpconvert','arity','product','widen') else set()
   if tag in ('signloads','extended','chosen','narrow','fpconvert','arity','product','widen'):allowed_multi=allowed_multi | {'IR_SEXT'}
   if tag in ('narrow','fpconvert','arity','product','widen'):allowed_multi=allowed_multi | {'IR_TRUNC'}
   if tag in ("fpconvert","arity","product","widen"):allowed_multi=allowed_multi | {"IR_SITOFP","IR_UITOFP","IR_FPTOSI","IR_FPTOUI"}
   assert old[5]==1 or (opnames[old[2]] in allowed_multi and old[5]>1),(tag,mode,group,opnames[old[2]],old,new)
   ops[old[2]]+=1
 for ext in ['sha','out','err']:
  assert (r/f'{mode}-{group}.{ext}').read_bytes()==(r/f'{tag}-{mode}-{group}.{ext}').read_bytes()
 print(mode,group,dict(samples),dict(ops))
 return samples,ops
if __name__=='__main__':
 for mode in ('default','all'):
  for g in ('lua','sqlite','musl'):compare(sys.argv[1],mode,g)
