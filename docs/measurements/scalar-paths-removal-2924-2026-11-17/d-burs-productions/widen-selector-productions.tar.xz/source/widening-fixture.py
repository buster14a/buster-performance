from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'conversion-fixtures.py').read_text().split("rows=['param.i32")[0]
ns={'__file__':str(p/'conversion-fixtures.py')};exec(s,ns)
rows=['param.ptr 0','param.i64 1','param.i8 2','load.i8 %0 align=1','sext.i32 %3','sext.i64 %4','trunc.i16 %1','sext.i64 %6','sext.i32 %2','not.i32 %8','sext.i64 %9','neg.i32 %8','sext.i64 %11','const.i32 0x04','and.i32 %8, %13','sext.i64 %14','ashr.i32 %8, %13','sext.i64 %16','xor.i32 %8, %13','sext.i64 %18','add.i64 %5, %7','add.i64 %10, %12','add.i64 %15, %17','add.i64 %19, %20','add.i64 %21, %22','add.i64 %23, %24','ret.void %25']
expect={5:'SIGNED_CHAIN',7:'SIGNED_PROJECTION',**{i:'SIGNED_BITS'for i in [10,12,15,17,19]}}
ns['export']('widen','ptr, i64, i8','i64',rows,expect,[(key,'rule->op == TIER1_BURS_OP_SIGNED_'+kind,'TIER1_BURS_ACTION_PLAIN')for key,kind in [('chain','CHAIN'),('projection','PROJECTION'),('bits','BITS')]])
