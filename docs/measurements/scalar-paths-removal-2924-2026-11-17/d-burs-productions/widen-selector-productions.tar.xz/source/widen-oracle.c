#define _GNU_SOURCE
#include "buster/compiler/tier1_select_benchmark.c"
#include "buster/compiler/ir_validate.c"
#include "buster/compiler/ir_parse.c"
static bool erase_class;
static uint32_t wrong_classes;
static const struct {uint32_t node, op;} expected[] = {
    { 5, TIER1_BURS_OP_SIGNED_CHAIN },
    { 7, TIER1_BURS_OP_SIGNED_PROJECTION },
    { 10, TIER1_BURS_OP_SIGNED_BITS },
    { 12, TIER1_BURS_OP_SIGNED_BITS },
    { 15, TIER1_BURS_OP_SIGNED_BITS },
    { 17, TIER1_BURS_OP_SIGNED_BITS },
    { 19, TIER1_BURS_OP_SIGNED_BITS },
};
static void inspect_classes(const Tier1SelectForest* forest, const uint32_t* users, uint32_t* words, uint32_t* classes, uint32_t* kids)
{
    tier1_burs_classify_vector(forest, users, words, classes, kids);
    if (erase_class) classes[expected[0].node] = TIER1_BURS_OP_REG;
    for (uint32_t i=0; i<sizeof(expected)/sizeof(expected[0]); ++i)
    {
        const uint32_t n = expected[i].node;
        if (n >= forest->function->instruction_count || classes[n] != expected[i].op)
        {
            fprintf(stderr,"class at node %u is %u, expected %u\n",n,classes[n],expected[i].op);
            ++wrong_classes;
        }
    }
}
#define tier1_burs_classify_vector inspect_classes
#include "check-common.inc"
#undef tier1_burs_classify_vector

int main(int argc, char** argv)
{
    if (argc != 2 || !tier1_select_initialize()) return 2;
    const bool control = strcmp(argv[1], "control") == 0;
    bool changed=false;
    erase_class = strcmp(argv[1], "coverage")==0;
    for (uint32_t i=1;i<tier1_burs_rule_count;++i)
    {
        Tier1BursRule* rule=&tier1_burs_rules[i];
        if (strcmp(argv[1],"chain")==0 && (rule->op == TIER1_BURS_OP_SIGNED_CHAIN)) { rule->action=TIER1_BURS_ACTION_PLAIN;changed=true; }
        if (strcmp(argv[1],"projection")==0 && (rule->op == TIER1_BURS_OP_SIGNED_PROJECTION)) { rule->action=TIER1_BURS_ACTION_PLAIN;changed=true; }
        if (strcmp(argv[1],"bits")==0 && (rule->op == TIER1_BURS_OP_SIGNED_BITS)) { rule->action=TIER1_BURS_ACTION_PLAIN;changed=true; }
    }
    if (!changed && !control && !erase_class) return 2;
    static char program[] =
        "function (ptr, i64, i8) -> i64 {\nb0:\n"
        "  %0 = param.ptr 0\n"
        "  %1 = param.i64 1\n"
        "  %2 = param.i8 2\n"
        "  %3 = load.i8 %0 align=1\n"
        "  %4 = sext.i32 %3\n"
        "  %5 = sext.i64 %4\n"
        "  %6 = trunc.i16 %1\n"
        "  %7 = sext.i64 %6\n"
        "  %8 = sext.i32 %2\n"
        "  %9 = not.i32 %8\n"
        "  %10 = sext.i64 %9\n"
        "  %11 = neg.i32 %8\n"
        "  %12 = sext.i64 %11\n"
        "  %13 = const.i32 0x04\n"
        "  %14 = and.i32 %8, %13\n"
        "  %15 = sext.i64 %14\n"
        "  %16 = ashr.i32 %8, %13\n"
        "  %17 = sext.i64 %16\n"
        "  %18 = xor.i32 %8, %13\n"
        "  %19 = sext.i64 %18\n"
        "  %20 = add.i64 %5, %7\n"
        "  %21 = add.i64 %10, %12\n"
        "  %22 = add.i64 %15, %17\n"
        "  %23 = add.i64 %19, %20\n"
        "  %24 = add.i64 %21, %22\n"
        "  %25 = add.i64 %23, %24\n"
        "  %26 = ret.void %25\n"
        "}\n";
    Arena input = arena_reserve(1u << 24), scratch = arena_reserve(1u << 26);
    IrFunction function;
    if (ir_parse((String8){.pointer=program,.length=sizeof(program)-1}, &input, &scratch, &function).error != IR_PARSE_OK ||
        ir_verify(&function, &scratch, 0).error != IR_OK) return 3;
    Tier1BursCheck tested = {0};
    tier1_burs_check_function(&tested, &function, 0, &scratch);
    printf("checked %" PRIu64 " nodes, %" PRIu64 " direct, %" PRIu64 " mismatches, %" PRIu64 " uncovered, %" PRIu64 " fallbacks\n",
           tested.nodes, tested.matched, tested.mismatches, tested.uncovered, tested.fallbacks);
    arena_release(&scratch);
    arena_release(&input);
    printf("classified %zu expected nodes, %u wrong\n", sizeof(expected)/sizeof(expected[0]), wrong_classes);
    return wrong_classes || tested.functions != 1 || tested.nodes != 27 || tested.uncovered || tested.mismatches || tested.fallbacks;
}
