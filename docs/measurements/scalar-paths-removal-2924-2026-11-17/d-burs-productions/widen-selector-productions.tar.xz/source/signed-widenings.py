from pathlib import Path
from shutil import copytree
from difflib import unified_diff
from subprocess import check_output
p=Path(__file__).resolve().parent;d=p/'widen-src';copytree(p/'product-src',d,dirs_exist_ok=True);c=d/'buster/compiler';f=c/'tier1_select_burs.c';s=f.read_text()
def add(k,v):
 global s
 assert s.count(k)==1,k
 s=s.replace(k,v)
names=['SIGNED_BITS','SIGNED_CHAIN','SIGNED_PROJECTION']
for group,values in [('OP',names),('ACTION',names),('FAMILY',['SIGNED_WIDENING'])]:
 k='    TIER1_BURS_'+group+'_SIGNED_PRODUCT,';add(k,k+''.join('\n    TIER1_BURS_'+group+'_'+n+','for n in values))
k='    // The widening multiply';add(k,'''    // For a signed widening, the candidate walk proves which operand an operation can absorb.
    // A nested extension can also bring a load into the widened access.
'''+''.join(f'    {{ TIER1_BURS_REG, TIER1_BURS_FAMILY_SIGNED_WIDENING, {i}, {{ TIER1_BURS_REG, BUSTER_TIER1_BURS_NO_KID }}, 1, TIER1_BURS_ACTION_{n}, TIER1_RULE_NONE }},\n'for i,n in enumerate(names))+k)
k='    case TIER1_BURS_FAMILY_SIGNED_PRODUCT:';add(k,'''    case TIER1_BURS_FAMILY_SIGNED_WIDENING:
        member = op == TIER1_BURS_OP_SIGNED_BITS + kinds;
        break;
'''+k)
k='        __mmask16 signed_products = 0;';add(k,k+'''
        __mmask16 signed_bits = 0;
        __mmask16 signed_chains = 0;
        __mmask16 signed_projections = 0;''')
k='            signed_products = signed_arithmetic & multiply;';add(k,k+'''
            signed_bits = signed_arithmetic & algebra & ~(arithmetic | multiply);
            signed_chains = _mm512_mask_cmpeq_epi32_mask(signed_inputs, a_op, _mm512_set1_epi32(IR_SEXT));
            signed_projections = _mm512_mask_cmpeq_epi32_mask(signed_inputs, a_op, _mm512_set1_epi32(IR_TRUNC));''')
k='        result = _mm512_mask_mov_epi32(result, signed_products';add(k,''.join(f'        result = _mm512_mask_mov_epi32(result, {mask}, _mm512_set1_epi32(TIER1_BURS_OP_{n}));\n'for mask,n in zip(['signed_bits','signed_chains','signed_projections'],names))+k)
k='        case TIER1_BURS_ACTION_SIGNED_PRODUCT:';add(k,'''        case TIER1_BURS_ACTION_SIGNED_BITS:
            match = p == 0 ? (pattern->rule == TIER1_RULE_COPY || pattern->rule == TIER1_RULE_SIGN_EXTEND) :
                    pattern->fold_count != 0 && (pattern->rule == TIER1_RULE_REGISTER || pattern->rule == TIER1_RULE_IMMEDIATE || pattern->rule == TIER1_RULE_UNARY || pattern->rule == TIER1_RULE_COPY);
            break;
        case TIER1_BURS_ACTION_SIGNED_CHAIN:
            match = pattern->rule == TIER1_RULE_SIGN_EXTEND || pattern->rule == TIER1_RULE_LOAD_ADDRESS || (p == 0 && pattern->rule == TIER1_RULE_COPY);
            break;
        case TIER1_BURS_ACTION_SIGNED_PROJECTION:
            // An already-shared truncation can expose a copy with no covered nodes. If the register
            // pattern is already a copy, keep the original operand and the first equal-cost match.
            match = (p == 0 || pattern->fold_count != 0 || (pattern->rule == TIER1_RULE_COPY && candidates->patterns[0].rule == TIER1_RULE_SIGN_EXTEND)) &&
                    (pattern->rule == TIER1_RULE_SIGN_EXTEND || pattern->rule == TIER1_RULE_COPY);
            break;
'''+k)
k='const bool walked = rule->action == TIER1_BURS_ACTION_SIGNED_PRODUCT';add(k,'const bool walked = (rule->action >= TIER1_BURS_ACTION_SIGNED_BITS && rule->action <= TIER1_BURS_ACTION_SIGNED_PROJECTION) ||\n                            rule->action == TIER1_BURS_ACTION_SIGNED_PRODUCT');f.write_text(s)
f=c/'tier1_select_burs_test.c';s=f.read_text();k='            if (class == TIER1_BURS_OP_X87)';add(k,'''            if (class >= TIER1_BURS_OP_SIGNED_BITS && class <= TIER1_BURS_OP_SIGNED_PROJECTION)
            {
                check->mismatches += munched || candidates.count == 0 || candidates.count > (class == TIER1_BURS_OP_SIGNED_CHAIN ? 3 : 2) ||
                                     chosen != tier1_select_munch(&candidates);
            }
'''+k)
f.write_text(s);(d/'check-common.inc').write_text(s.split('#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)')[0])
diff=''
for f in sorted(c.glob('*.c')):
 path='src/buster/compiler/'+f.name;old=check_output(['git','show','cc7d4ffb4:'+path],cwd=p/'tree').decode()
 diff+=''.join(unified_diff(old.splitlines(True),f.read_text().splitlines(True),'a/'+path,'b/'+path))
(p/'widen.patch').write_text(diff)
