from pathlib import Path
import struct, hashlib, gzip, re
from collections import Counter
p=Path(__file__).resolve().parent
def verify(mode,group):
    r=p/'results'
    raw=gzip.decompress((r/f'plans-{mode}-{group}.gz').read_bytes())
    report=(r/f'plan-bytes-{mode}-{group}.log').read_text()
    sizes=re.findall(r'^\s*(\d+)\s+\S+/plan-(?:parent|chosen)\.bin$',report,re.M)
    hashes=re.findall(r'^([0-9a-f]{64})\s+\S+/plan-(?:parent|chosen)\.bin$',report,re.M)
    assert sizes==[str(len(raw))]*2 and hashes==[hashlib.sha256(raw).hexdigest()]*2
    for ext in ['sha','out','err']:
        assert (r/f'plan-parent-{mode}-{group}.{ext}').read_bytes()==(r/f'plan-chosen-{mode}-{group}.{ext}').read_bytes()
    assert len((r/f'plan-parent-{mode}-{group}.sha').read_text().splitlines())==dict(lua=34,sqlite=1,musl=1336)[group]
    offset=0; totals=Counter()
    while offset<len(raw):
        magic,count,error,failed,verified,costed=struct.unpack_from('<6I',raw,offset)
        offset+=24
        assert magic==0x504c414e and verified<=1 and costed<=1
        totals['plans']+=1
        if error:
            totals['failures']+=1
            continue
        cost,uses,arena,check,symbols,has_symbols=struct.unpack_from('<6Q',raw,offset)
        assert check<=1 and has_symbols<=1
        offset+=48+symbols*has_symbols
        if group=='sqlite' and count==1618 and mode=='default':
            # Decode the semantic fields independently for the widening multiply under investigation.
            for n in [1022]:
                q=offset+51*n
                _,a,b,_,_,_,_,_,rule,op,*_=struct.unpack_from('<Q7I15B',raw,q)
                print('sqlite plan',count,n,'rule',rule,'operation',op,'operands',a,b)
        offset+=count*51
        first,=struct.unpack_from('<I',raw,offset)
        last,=struct.unpack_from('<I',raw,offset+count*4)
        assert first==0 and last==uses
        offset+=(count+1+uses)*4
        totals['nodes']+=count;totals['uses']+=uses
    assert offset==len(raw)
    totals['bytes']=len(raw)
    return totals
if __name__=='__main__':
    total=Counter()
    for mode in ('default','all'):
        for group in ('lua','sqlite','musl'):
            s=verify(mode,group);print(mode,group,dict(s));total.update(s)
    print('combined',dict(total))
