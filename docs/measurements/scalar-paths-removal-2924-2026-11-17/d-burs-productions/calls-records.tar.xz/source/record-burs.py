from pathlib import Path
from collections import Counter
from statistics import median
import sys,struct,re,tarfile,runpy
p=Path(__file__).parent;r=p/'results';out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-burs-productions')
optext=(p/'tree/src/buster/compiler/ir.c').read_text().split('typedef enum IrOp\n{')[1].split('} IrOp')[0]
names=re.findall(r'^\s*(IR_\w+)\s*,',optext,re.M)
v=runpy.run_path(str(p/'compare-selected.py'))
def write_capture(tag,title,description,first=False):
 out.mkdir(exist_ok=True)
 stats=[];total=Counter();counts=Counter()
 for mode in ('default','all'):
  for g,n in [('lua',34),('sqlite',1),('musl',1336)]:
   stat,ops=v['compare'](tag,mode,g);total.update(stat);counts.update(ops)
   assert len((r/f'{tag}-{mode}-{g}.sha').read_text().splitlines())==n
   stats.append(f'| {mode} | {g} | {stat["total"]:,} | {stat["baseline"]:,} | {stat["candidate"]:,} | {100*(1-stat["candidate"]/stat["baseline"]):.1f}% |')
 s=(r/f'{tag}-select.log').read_text();assert '1530046 checks, 0 failures' in s and '5957, digest d15b788da26467e5' in s
 for seed in (1,133,789):
  s=(r/f'{tag}-pipeline-{seed}.log').read_text()
  assert re.search(r'^tier1 pipeline: [1-9]\d* checks, 0 failures; native=[1-9]\d* clang=[1-9]\d* ',s,re.M)
 for name in ('test-tier1-emit','test-tier1-liveness','test-tier1-masks'):
  assert re.search(r'^.*?\b[1-9]\d* checks, 0 failures', (r/f'{tag}-{name}.log').read_text(),re.M)
 test=r/'mutants'/tag
 for bad in ['control','munch','state','goal','missing']:
  assert int((test/(bad+'.status')).read_text())==(0 if bad=='control' else 1)
  assert ('19 nodes' in (test/(bad+'.log')).read_text())
 extra=''
 if tag=='calls':
  for mode in ['control','munch','kind','state','goal','missing']:
   assert int((test/('call-'+mode+'.status')).read_text())==(0 if mode=='control' else 1)
   raw=(test/('call-'+mode+'.log')).read_text()
   assert ('checked 19 nodes' in raw) and (('19 direct, 0 mismatches' in raw) if mode=='control' else ('16 mismatches' in raw))
  extra=' A second verified function exercised 16 ordinary calls. Mutating the call rule’s kind was detected at all 16 calls even though every node still selected a grammar production. The call fixture also detected changes to its action, state, goal and missing production.'
 intro='''# Tier 1 instruction selection and maximal munch

The native parent is buster14a/buster@cc7d4ffb449c1f57d8d867c2ad2bf6dc6bfebc7f. A capture at the production pattern selector records the function size, node number, IR operator and type, grammar rule, candidate count, chosen candidate number, fallback flag and every candidate’s machine rule. Each compiler ran in Release on the locked Ryzen 7 9700X with one compilation lane. Within each paired run, both compilers wrote debug objects from the same working directory. The comparison checks every node in order, including its full candidate-rule list and the exact selected index.
''' if first else ''
 body='## '+title+'\n\n'+description+'''

| Passes | Corpus | Selected nodes | Parent maximal munch | Candidate maximal munch | Reduction |
| --- | --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(stats)+f'''

The selected index and all available machine rules matched at all {total["total"]:,} nodes. The six runs also matched every object, standard output and diagnostic byte. The newly covered operations, summed across both configurations, were '''+', '.join(f'{names[k]} ({n:,})'for k,n in counts.most_common())+'''. The selector passed 1,530,046 checks and reproduced the frozen digest d15b788da26467e5 for 5,957 plans. Three pipeline seeds ran with the Clang cross-check. In a separate 19-node verified fixture, changing the baked grammar action, state, goal or missing production was detected even when the independent fallback could emit equivalent code.'''+extra+'''

[Complete captures, candidate and probe patches, native tests, fixture mutations and object manifests]('''+tag+'''-records.tar.xz)
'''
 doc=out/'README.md';old=doc.read_text() if doc.exists() else '';assert '## '+title not in old
 with tarfile.open(out/(tag+'-records.tar.xz'),'w:xz',preset=2)as t:
  masks=['records-*.bin','default-*.sha','all-*.sha','default-*.err','default-*.out','all-*.err','all-*.out',tag+'-records-*.bin',tag+'-default-*',tag+'-all-*',tag+'-select.log',tag+'-test-tier1-*',tag+'-pipeline-*.log']
  for pat in masks:
   for q in sorted(r.glob(pat)):
    if q.is_file():t.add(q,'native/'+q.name)
  for q in sorted(test.iterdir()):
   if q.suffix in ['.log','.status']:t.add(q,'native/mutations/'+q.name)
  if tag=='calls':
   for n in ['call-oracle.c','mutate-calls','resume-calls-capture','retry-census-calls']:t.add(p/n,'source/'+n)
  for n in [tag+'.patch','capture.patch','build-'+tag,'census-corpus',tag+'-corpus',tag+'-tests','compare-selected.py','record-burs.py','leaf-oracle.c','mutate-select']:t.add(p/n,'source/'+n)
 doc.write_text((intro if first else old.rstrip())+'\n\n'+body)
 print(total)
if __name__=='__main__':
 t=sys.argv[1]
 if t=='supported':write_capture(t,'Classifying supported single-pattern leaves','A zero-child goal selects the single concrete machine pattern. It covers unconditional branches, lifetime markers, symbol addresses, stack saves, fences, unreachable blocks and the directly supported parameter, phi and return cases. The ABI, machine operands and cost still come from the original candidate generator. The original precedence of unsupported-node errors is preserved.',True)
 if t=='calls':write_capture(t,'ABI-specific call productions','Three additional grammar leaves represent ordinary calls, inline assembly bodies and machine-row calls. The same ABI checks select their concrete kind for both the classifier and the independent candidate walk. The chosen grammar rule supplies that kind to the pattern builder.')
