#define _GNU_SOURCE
#include "buster/compiler/tier1_select_benchmark.c"
#include "buster/compiler/ir_validate.c"
#include "buster/compiler/ir_parse.c"
#include "check-common.inc"

int main(int argc, char** argv)
{
    if (argc != 2 || !tier1_select_initialize()) return 2;
    const bool control = strcmp(argv[1], "control") == 0;
    unsigned changed = 0;
    for (uint32_t i = 1; i < tier1_burs_rule_count; ++i)
    {
        Tier1BursRule* rule = &tier1_burs_rules[i];
        if ((strcmp(argv[1], "right") == 0 && rule->op == TIER1_BURS_OP_FLOAT_BINARY_RIGHT && rule->kind == TIER1_RULE_FLOAT_LOAD_OPERAND) ||
            (strcmp(argv[1], "left") == 0 && rule->op == TIER1_BURS_OP_FLOAT_BINARY_LEFT && rule->kind == TIER1_RULE_FLOAT_LOAD_OPERAND))
        {
            rule->kind = TIER1_RULE_FLOAT_BINARY;
            ++changed;
        }
        if (rule->action == TIER1_BURS_ACTION_FLOAT_ADDRESS &&
            ((strcmp(argv[1], "load") == 0 && rule->kind == TIER1_RULE_FLOAT_LOAD) ||
             (strcmp(argv[1], "store") == 0 && rule->kind == TIER1_RULE_FLOAT_STORE)))
        {
            rule->action = TIER1_BURS_ACTION_KIND;
            ++changed;
        }
        if (strcmp(argv[1], "register") == 0 && rule->action == TIER1_BURS_ACTION_KIND && rule->kind == TIER1_RULE_FLOAT_BINARY)
        {
            rule->action = TIER1_BURS_ACTION_MUNCH;
            ++changed;
        }
    }
    if (!control && !changed) return 2;
    static char program[] =
        "function (ptr, f64) -> f64 {\nb0:\n"
        "  %0 = param.ptr 0\n"
        "  %1 = param.f64 1\n"
        "  %2 = address.ptr %0 offset=8\n"
        "  %3 = load.f64 %2 align=8\n"
        "  %4 = fsub.f64 %1, %3\n"
        "  %5 = load.f64 %0 align=8\n"
        "  %6 = fmul.f64 %5, %4\n"
        "  %7 = load.f64 %0 align=8\n"
        "  %8 = fadd.f64 %7, %6\n"
        "  %9 = fdiv.f64 %7, %8\n"
        "  %10 = fneg.f64 %9\n"
        "  %11 = address.ptr %0 offset=16\n"
        "  %12 = store.void %11, %10 align=8\n"
        "  %13 = ret.void %10\n}\n";
    Arena input = arena_reserve(1u << 24), scratch = arena_reserve(1u << 26);
    IrFunction function;
    if (ir_parse((String8){.pointer=program,.length=sizeof(program)-1}, &input, &scratch, &function).error != IR_PARSE_OK ||
        ir_verify(&function, &scratch, 0).error != IR_OK) return 3;
    Tier1BursCheck tested = {0};
    tier1_burs_check_function(&tested, &function, 0, &scratch);
    printf("checked %" PRIu64 " nodes, %" PRIu64 " direct, %" PRIu64 " mismatches, %" PRIu64 " uncovered, %" PRIu64 " fallbacks\n",
           tested.nodes, tested.matched, tested.mismatches, tested.uncovered, tested.fallbacks);
    arena_release(&scratch);
    arena_release(&input);
    return tested.functions != 1 || tested.nodes != 14 || tested.uncovered || tested.mismatches || tested.fallbacks;
}
