from pathlib import Path
from subprocess import check_output
from difflib import unified_diff
p=Path(__file__).parent;dest=p/'float-src/buster/compiler';dest.mkdir(parents=True,exist_ok=True)
for f in (p/'convert-src/src/buster/compiler').glob('*.c'):(dest/f.name).write_bytes(f.read_bytes())
f=dest/'tier1_select_burs.c';s=f.read_text()
def add(key,value):
 global s
 assert s.count(key)==1,key
 s=s.replace(key,value+key)
add('    TIER1_BURS_OPERATORS,','''    TIER1_BURS_OP_FLOAT_LOAD_F,
    TIER1_BURS_OP_FLOAT_LOAD_N,
    TIER1_BURS_OP_FLOAT_STORE,
    TIER1_BURS_OP_FLOAT_BINARY_RIGHT,
    TIER1_BURS_OP_FLOAT_BINARY_LEFT,
''')
add('    TIER1_BURS_FAMILY_COPY_TRUTH,','''    TIER1_BURS_FAMILY_FLOAT_LOAD,
    TIER1_BURS_FAMILY_FLOAT_STORE,
    TIER1_BURS_FAMILY_FLOAT_BINARY,
''')
add('    TIER1_BURS_ACTION_PLAIN,','    TIER1_BURS_ACTION_FLOAT_ADDRESS,\n')
add('    // The address walk (tier1_select_address)', '''    // A floating binary operation reads a register or a foldable scalar load. When the right operand is a
    // load it always has priority. Addition and multiplication can otherwise take the left memory operand.
    { TIER1_BURS_REG, TIER1_BURS_FAMILY_FLOAT_BINARY, 0, { TIER1_BURS_REG, TIER1_BURS_REG }, 3, TIER1_BURS_ACTION_KIND, TIER1_RULE_FLOAT_BINARY },
    { TIER1_BURS_REG, TIER1_BURS_FAMILY_FLOAT_BINARY, 1, { TIER1_BURS_REG, TIER1_BURS_LOADF }, 3, TIER1_BURS_ACTION_KIND, TIER1_RULE_FLOAT_LOAD_OPERAND },
    { TIER1_BURS_REG, TIER1_BURS_FAMILY_FLOAT_BINARY, 2, { TIER1_BURS_LOADF, TIER1_BURS_REG }, 3, TIER1_BURS_ACTION_KIND, TIER1_RULE_FLOAT_LOAD_OPERAND },
    { TIER1_BURS_REG, TIER1_BURS_FAMILY_FLOAT_LOAD, 0, { TIER1_BURS_A1, BUSTER_TIER1_BURS_NO_KID }, 1, TIER1_BURS_ACTION_FLOAT_ADDRESS, TIER1_RULE_FLOAT_LOAD },
    { TIER1_BURS_STMT, TIER1_BURS_FAMILY_FLOAT_STORE, 0, { TIER1_BURS_A1, TIER1_BURS_REG }, 1, TIER1_BURS_ACTION_FLOAT_ADDRESS, TIER1_RULE_FLOAT_STORE },
''')
s=s.replace('op == TIER1_BURS_OP_STORE || op == TIER1_BURS_OP_ADDR_CIDX','op == TIER1_BURS_OP_STORE || op >= TIER1_BURS_OP_FLOAT_STORE || op == TIER1_BURS_OP_ADDR_CIDX')
s=s.replace('op == TIER1_BURS_OP_STORE || op == TIER1_BURS_OP_CBR_ADJ ?', 'op == TIER1_BURS_OP_STORE || op == TIER1_BURS_OP_FLOAT_STORE || op == TIER1_BURS_OP_CBR_ADJ ?')
add('    case TIER1_BURS_FAMILY_LOAD:', '''    case TIER1_BURS_FAMILY_FLOAT_BINARY:
        member = (op == TIER1_BURS_OP_FLOAT_BINARY_RIGHT && kinds != 2) || (op == TIER1_BURS_OP_FLOAT_BINARY_LEFT && kinds != 1);
        break;
    case TIER1_BURS_FAMILY_FLOAT_LOAD:
        member = op == TIER1_BURS_OP_FLOAT_LOAD_F || op == TIER1_BURS_OP_FLOAT_LOAD_N;
        break;
    case TIER1_BURS_FAMILY_FLOAT_STORE:
        member = op == TIER1_BURS_OP_FLOAT_STORE;
        break;
''')
s=s.replace('member = op == TIER1_BURS_OP_LOAD_F;', 'member = op == TIER1_BURS_OP_LOAD_F || op == TIER1_BURS_OP_FLOAT_LOAD_F;')
i=s.index('        const __mmask16 load =');j=s.index('        if (load != 0)',i)
s=s[:i]+'''        const __mmask16 floating = tier1_burs_types(active, type, floats);
        const __mmask16 float_leaf = _mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_CONST)) | _mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_UNDEF)) |
                                     _mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_FNEG));
        result = _mm512_mask_mov_epi32(result, floating & float_leaf, _mm512_set1_epi32(TIER1_BURS_OP_DIRECT));
        const __mmask16 binary = floating & _mm512_cmpge_epu32_mask(op, _mm512_set1_epi32(IR_FADD)) & _mm512_cmple_epu32_mask(op, _mm512_set1_epi32(IR_FDIV));
        if (binary != 0)
        {
            const __mmask16 commute = _mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_FADD)) | _mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_FMUL));
            const __mmask16 left = commute & _mm512_cmpneq_epi32_mask(b_op, _mm512_set1_epi32(IR_LOAD));
            result = _mm512_mask_mov_epi32(result, binary, _mm512_mask_blend_epi32(left, _mm512_set1_epi32(TIER1_BURS_OP_FLOAT_BINARY_RIGHT), _mm512_set1_epi32(TIER1_BURS_OP_FLOAT_BINARY_LEFT)));
        }
        const __mmask16 load = tier1_burs_types(active, type, memory | floats) & _mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_LOAD));
'''+s[j:]
a=s.index('            result = _mm512_mask_mov_epi32(result, load,');b=s.index('\n        }',a)
s=s[:a]+'''            result = _mm512_mask_mov_epi32(result, load, _mm512_mask_blend_epi32(floating, _mm512_set1_epi32(TIER1_BURS_OP_LOAD_N), _mm512_set1_epi32(TIER1_BURS_OP_FLOAT_LOAD_N)));
            result = _mm512_mask_mov_epi32(result, foldable, _mm512_mask_blend_epi32(floating, _mm512_set1_epi32(TIER1_BURS_OP_LOAD_F), _mm512_set1_epi32(TIER1_BURS_OP_FLOAT_LOAD_F)));'''+s[b:]
add('        // Addresses by their index', '''        const __mmask16 float_store = tier1_burs_types(b_valid, b_type, floats) & _mm512_cmpeq_epi32_mask(op, _mm512_set1_epi32(IR_STORE));
        result = _mm512_mask_mov_epi32(result, float_store, _mm512_set1_epi32(TIER1_BURS_OP_FLOAT_STORE));
''')
add('        case TIER1_BURS_ACTION_LOAD:', '''        case TIER1_BURS_ACTION_FLOAT_ADDRESS:
            match = pattern->rule == (rule->kind == TIER1_RULE_FLOAT_LOAD ? TIER1_RULE_FLOAT_LOAD_ADDRESS : TIER1_RULE_FLOAT_STORE_ADDRESS) ||
                    (pattern->rule == rule->kind && chosen == UINT32_MAX);
            break;
''')
s=s.replace('const bool walked = rule->action == TIER1_BURS_ACTION_LOAD', 'const bool walked = rule->action == TIER1_BURS_ACTION_FLOAT_ADDRESS || rule->action == TIER1_BURS_ACTION_LOAD')
f.write_text(s)
f=dest/'tier1_select_burs_test.c';s=f.read_text()
where='        if (plain)';s=s.replace(where,'''        const bool floating = type == IR_F32 || type == IR_F64;
        if (floating && op >= IR_FADD && op <= IR_FDIV)
        {
            const bool left = (op == IR_FADD || op == IR_FMUL) && function->op[function->b[node]] != IR_LOAD;
            check->mismatches += class != (left ? TIER1_BURS_OP_FLOAT_BINARY_LEFT : TIER1_BURS_OP_FLOAT_BINARY_RIGHT);
        }
        if (floating && op == IR_LOAD)
        {
            const bool folded = users[node] < count && tier1_select_load_folds(&forest, users[node], node);
            check->mismatches += class != (folded ? TIER1_BURS_OP_FLOAT_LOAD_F : TIER1_BURS_OP_FLOAT_LOAD_N);
        }
'''+where)
f.write_text(s)
diff=''
for f in sorted(dest.glob('*.c')):
 rel='src/buster/compiler/'+f.name;base=check_output(['git','show','cc7d4ffb4:'+rel],cwd=p/'tree').decode()
 diff+=''.join(unified_diff(base.splitlines(True),f.read_text().splitlines(True),'a/'+rel,'b/'+rel))
(p/'float.patch').write_text(diff)
