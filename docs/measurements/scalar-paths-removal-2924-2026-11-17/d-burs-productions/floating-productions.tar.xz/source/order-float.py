from pathlib import Path
from difflib import unified_diff
from shutil import copytree
from subprocess import check_output
p=Path(__file__).parent
src=p/'ordered-src'
copytree(p/'float-src',src,dirs_exist_ok=True)
f=src/'buster/compiler/tier1_select.c'
s=f.read_text().replace('// Both leaf classes require a supported machine pattern, even if a later cover absorbs the value.',"""// Check operations that previously used the generic register leaf in their original dependency order,
        // including values later absorbed by a memory operand. Preserve the first unsupported node.""")
before='if ((classes[node] == TIER1_BURS_OP_REG || (classes[node] >= TIER1_BURS_OP_DIRECT && classes[node] <= TIER1_BURS_OP_CALL_ROW))'
after='const uint32_t op = classes[node];\n        if ((op == TIER1_BURS_OP_REG || (op >= TIER1_BURS_OP_DIRECT && op <= TIER1_BURS_OP_CALL_ROW) || op >= TIER1_BURS_OP_FLOAT_LOAD_F)'
assert s.count(before)==1;f.write_text(s.replace(before,after))
diff=''
for file in sorted((src/'buster/compiler').glob('*.c')):
 rel='src/buster/compiler/'+file.name
 old=check_output(['git','show','cc7d4ffb4:'+rel],cwd=p/'tree').decode()
 diff+=''.join(unified_diff(old.splitlines(True),file.read_text().splitlines(True),'a/'+rel,'b/'+rel))
(p/'ordered.patch').write_text(diff)
for n in ['float-corpus','ordinary-float','whole-float','float-tests','float-bench-source','float-measure-sources','float-measure-widths','build-float']:
 s=(p/n).read_text().replace('float','ordered').replace('out="$root/objects-','out="$root/ordered-objects-')
 if n=='build-float':
  s=s[:s.index('previous=')]+s[s.index('cd "$ir/src"'):]
  s=s.replace('cd "$ir/src"','until [[ -f "$root/candidates-builds-clean.ok" ]];do sleep 2;done\ncd "$ir/src"',1)
  s=s.replace('ln -L build/compiler build/burs-ordered', 'cp --preserve=mode build/compiler /tmp/buster-selector-images-6b097f86/ordered\ncmp build/compiler /tmp/buster-selector-images-6b097f86/ordered\nln -s /tmp/buster-selector-images-6b097f86/ordered build/burs-ordered',1)
  s=s.replace('ln -L build/compiler build/burs-ordered-capture','cp --preserve=mode build/compiler /tmp/buster-selector-images-6b097f86/ordered-capture\ncmp build/compiler /tmp/buster-selector-images-6b097f86/ordered-capture\nln -s /tmp/buster-selector-images-6b097f86/ordered-capture build/burs-ordered-capture')
 (p/n.replace('float','ordered')).write_text(s)
f=p/'compare-selected.py';s=f.read_text().replace("tag=='float'","tag in ('float','ordered')");f.write_text(s)
