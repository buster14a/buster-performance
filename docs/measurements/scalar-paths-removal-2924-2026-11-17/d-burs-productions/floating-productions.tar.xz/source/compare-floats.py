from pathlib import Path
from subprocess import check_output
from difflib import unified_diff
p=Path(__file__).parent
for mode in ['float','fp']:
 d=p/(mode+'-src/buster/compiler')
 f=d/'tier1_select_burs_test.c';s=f.read_text()
 k='            tier1_burs_pick(&candidates, columns[3][node], &munched);'
 assert s.count(k)==1
 condition='class >= TIER1_BURS_OP_FLOAT_LOAD_F && class <= TIER1_BURS_OP_FLOAT_BINARY_LEFT' if mode=='float' else 'class >= TIER1_BURS_OP_FLOAT_REGISTER && class <= TIER1_BURS_OP_FLOAT_STORE'
 s=s.replace(k,'''            const uint32_t chosen = tier1_burs_pick(&candidates, columns[3][node], &munched);
            if ('''+condition+''')
            {
                check->mismatches += candidates.count == 0 || munched || chosen != tier1_select_munch(&candidates);
            }''')
 f.write_text(s)
 f=d/'tier1_select_burs.c';s=f.read_text().replace('BUSTER_TIER1_BURS_MAX_STATES 1024u','BUSTER_TIER1_BURS_MAX_STATES 1088u');f.write_text(s)
 (d.parent.parent/'check-common.inc').write_text((d/'tier1_select_burs_test.c').read_text().split('#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)')[0])
 diff=''
 for f in sorted(d.glob('*.c')):
  rel='src/buster/compiler/'+f.name;base=check_output(['git','show','cc7d4ffb4:'+rel],cwd=p/'tree').decode()
  diff+=''.join(unified_diff(base.splitlines(True),f.read_text().splitlines(True),'a/'+rel,'b/'+rel))
 (p/(mode+'.patch')).write_text(diff)
s=(p/'float-files.c').read_text();s=s.replace('    Tier1BursCheck check', '    printf("baked %u states, %u rules, %u entries\\n",tier1_burs_state_count,tier1_burs_rule_count,tier1_burs_pool_length);\n    Tier1BursCheck check');(p/'float-files.c').write_text(s)
