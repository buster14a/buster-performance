from collections import Counter
from pathlib import Path
from statistics import median
import re,tarfile,runpy
p=Path(__file__).parent;r=p/'results'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-burs-productions')
v=runpy.run_path(str(p/'compare-selected.py'));tot=Counter();rows=[];ops=Counter()
for mode in ['default','all']:
 for g,n in [('lua',34),('sqlite',1),('musl',1336)]:
  counts,changed=v['compare']('checked-ordered',mode,g)
  earlier,_=v['compare']('converts',mode,g)
  assert len((r/f'checked-ordered-{mode}-{g}.sha').read_text().splitlines())==n
  tot.update(counts);ops.update(changed)
  rows.append(f'| {mode} | {g} | {counts["total"]:,} | {counts["baseline"]:,} | {earlier["candidate"]:,} | {counts["candidate"]:,} |')
assert tot['total']==1006223 and tot['baseline']==396316
assert '1530046 checks, 0 failures' in (r/'ordered-select.log').read_text() and '5957, digest d15b788da26467e5' in (r/'ordered-select.log').read_text()
for seed in (1,133,789):
 assert re.search(r'^tier1 pipeline: [1-9]\d* checks, 0 failures; native=[1-9]\d* clang=[1-9]\d* ',(r/f'ordered-pipeline-{seed}.log').read_text(),re.M)
for name in ('test-tier1-emit','test-tier1-liveness','test-tier1-masks'):
 assert re.search(r'^.*?\b[1-9]\d* checks, 0 failures',(r/f'ordered-{name}.log').read_text(),re.M)
mut=r/'mutants/ordered'
for prefix,size,names in [('',19,['control','munch','state','goal','missing']),('conversion-',19,['control','munch','state','goal','missing']),('float-',14,['control','left','right','load','store','register'])]:
 for name in names:
  assert int((mut/(prefix+name+'.status')).read_text())==(0 if name=='control' else 1)
  stats=(mut/(prefix+name+'.log')).read_text()
  assert f'{size} nodes' in stats
  if name=='control':assert '0 mismatches' in stats
  else:assert re.search(r'[1-9]\d* mismatches',stats)
local=(p/'float-expanded.log').read_text()
assert 'baked 1029 states, 218 rules, 38729 entries' in local and '251 verified from 317 IR inputs; 7362 nodes, 5500 matched, 0 mismatches, 0 uncovered, 0 fallbacks' in local
title='## Floating-point load, store and binary productions'
doc=out/'README.md';assert title not in doc.read_text()
body=title+'''

The grammar chooses a register or a foldable memory operand for floating add, subtract, multiply and divide. A right load takes priority. Add and multiply can use a left load. A store or load through a walked address retains its corresponding address pattern. The classifier also covers floating negation, undefined values and constants. The baked grammar has 1,029 states, 218 rules and 38,729 entries.

Newly classified nodes are checked in their original dependency order, including any that a later expression absorbs. On a preliminary build, deferring a previously generic floating-point node reordered the production trace. The tables below are from the corrected build. Both executables used identical object output directories so their DWARF compilation-directory fields matched.

| Passes | Corpus | Visited nodes | Parent maximal munch | Conversion version | Floating-point version |
| --- | --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+f'''

The floating-point version reduced maximal-munch visits by {100*(1-tot["candidate"]/tot["baseline"]):.1f}% overall, to {tot["candidate"]:,}. All {tot["total"]:,} full candidate lists and selected indices matched the parent in visit order. All 2,742 debug objects and both output streams were byte-identical. The frozen plans and 1,530,046 selector checks passed, along with emission, liveness, masks and three Clang-backed pipeline seeds.

A 14-node verified function exercises a right-hand load, commuted left-hand load, a load with two uses, and both walked loads and stores. Changing the loaded side, the register rule or either address action caused its independent choice check to fail. The two existing 19-node fixtures also detected their eight changes to the direct and conversion rules. The optimized host fixture driver checked a further 7,362 nodes from 251 verified repository inputs.

[Grammar and probe source, fixed fixtures, mutation results, per-node captures and object checksums](floating-productions.tar.xz)
'''
with tarfile.open(out/'floating-productions.tar.xz','w:xz',preset=2)as t:
 for glob in ['records-*.bin','default-*.sha','all-*.sha','default-*.err','all-*.err','default-*.out','all-*.out','checked-ordered-*.bin','checked-ordered-*.sha','checked-ordered-*.out','checked-ordered-*.err','ordered-select.log','ordered-pipeline-*.log','ordered-test-tier1-*.log']:
  for f in sorted(r.glob(glob)):t.add(f,'native/'+f.name)
 for f in sorted(mut.iterdir()):
  if f.suffix in ['.status','.log']:t.add(f,'native/mutations/'+f.name)
 for f in ['ordered.patch','capture.patch','order-float.py','float-rules.py','compare-floats.py','compare-selected.py','checked-ordered-corpus','check-ordered-captures','build-ordered','ordered-tests','mutate-ordered','float-oracle.c','leaf-oracle.c','conversion-oracle.c','float-files.c','float-expanded.log','local-fp','record-floating.py']:t.add(p/f,'source/'+f)
with doc.open('a')as f:f.write('\n'+body)
print(tot)
