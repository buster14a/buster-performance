#define _GNU_SOURCE
#include "buster/compiler/tier1_select_benchmark.c"
#include "buster/compiler/ir_validate.c"
#include "buster/compiler/ir_parse.c"
#include "check-common.inc"
int main(int argc, char** argv)
{
    if (!tier1_select_initialize()) return 2;
    printf("baked %u states, %u rules, %u entries\n",tier1_burs_state_count,tier1_burs_rule_count,tier1_burs_pool_length);
    Tier1BursCheck check = {0};
    int verified=0;
    for (int i=1;i<argc;++i)
    {
        FILE* source=fopen(argv[i],"rb");
        if (!source || fseek(source,0,SEEK_END)) return 3;
        long len=ftell(source);
        if (len<0 || fseek(source,0,SEEK_SET)) return 3;
        char* text=calloc((size_t)len+1,1);
        if (!text || fread(text,1,(size_t)len,source)!=(size_t)len || fclose(source)) return 3;
        Arena in=arena_reserve(1ull<<29), tmp=arena_reserve(1ull<<29);
        IrFunction fun;
        if (ir_parse((String8){ .pointer=text,.length=(uint64_t)len },&in,&tmp,&fun).error==IR_PARSE_OK && ir_verify(&fun,&tmp,0).error==IR_OK)
        {
            verified++;
            uint64_t before=check.mismatches;
            tier1_burs_check_function(&check,&fun,0,&tmp);
            if (before!=check.mismatches) fprintf(stderr,"%s: %lu mismatches\n",argv[i],(unsigned long)(check.mismatches-before));
        }
        free(text);arena_release(&in);arena_release(&tmp);
    }
    printf("%d verified from %d IR inputs; %lu nodes, %lu matched, %lu mismatches, %lu uncovered, %lu fallbacks\n",verified,argc-1,(unsigned long)check.nodes,(unsigned long)check.matched,(unsigned long)check.mismatches,(unsigned long)check.uncovered,(unsigned long)check.fallbacks);
    return !verified || check.mismatches || check.uncovered;
}
