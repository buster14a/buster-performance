from pathlib import Path
from statistics import median
import re,tarfile,sys
p=Path(__file__).parent;r=p/'results';out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-burs-productions');tag=sys.argv[1]
rows=[]
for g in ['lua','sqlite','musl']:
 ratios=[];counts=set()
 for i in (1,2,3):
  samples=[(r/f'{tag}-source-{g}-{i}-{side}.log').read_text()for side in ['unroll-base','burs-'+tag]]
  contexts=[re.search(r'^benchmark-tier1-select-source: files=.*$',s,re.M)[0]for s in samples];assert contexts[0]==contexts[1];counts.add(contexts[0])
  assert all('mismatches=0 uncovered=0' in s for s in samples)
  cs=[list(map(float,re.findall(r'^select\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)',s,re.M)[0])) for s in samples]
  ratios.append([y/x for x,y in zip(*cs)])
 assert len(counts)==1
 selected,inst=re.search(r'selected=(\d+).*instructions=(\d+)',counts.pop()).groups()
 rows.append(f'| {g} | {int(selected):,} | {int(inst):,} | '+' | '.join(f'{median(v):.4f}'for v in zip(*ratios))+' |')
heading={'supported':'Complete source selection with single-pattern leaves','calls':'Complete source selection including ABI-specific calls','converts':'Complete source selection including conversions'}[tag]
f=out/'README.md';s=f.read_text();assert '## '+heading not in s
f.write_text(s.rstrip()+'\n\n## '+heading+'''

The production `benchmark-tier1-select-source` command ran on Lua, SQLite and musl with the Release compilers on the 9700X. Each ratio divides the candidate’s measurement per IR instruction by the parent’s, then takes the median of three paired rounds. Both compiled the same set of functions. The bottom-up rewrite checks reported zero mismatches and zero uncovered nodes.

| Corpus | Selected functions | Instructions | Wall time | Core cycles | Retired instructions |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+f'\n\n[Inputs, native commands and all paired samples]({tag}-source-selection.tar.xz)\n')
with tarfile.open(out/(tag+'-source-selection.tar.xz'),'w:xz',preset=2)as t:
 for nm in [tag+'-bench-source',tag+'-measure-sources','record-sources.py']:t.add(p/nm,'source/'+nm)
 for fn in sorted(r.glob(tag+'-source-*.log')):t.add(fn,'native/'+fn.name)
print(*rows,sep='\n')
