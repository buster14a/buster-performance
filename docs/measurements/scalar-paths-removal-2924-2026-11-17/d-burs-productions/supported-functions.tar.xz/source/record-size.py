from collections import defaultdict
from pathlib import Path
from statistics import median
import re, sys, tarfile

p=Path(__file__).parent
r=p/'results'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-burs-productions')
tag,kind=sys.argv[1:]
names={'signloads':'signed load and floating-point productions','supported':'single-pattern leaves','calls':'ABI-specific calls','converts':'conversions','ordered':'floating-point productions','float':'floating-point productions with deferred selection'}
files=[]
def collect(path):
    files.append(path)
    return path.read_bytes()
def pct(x):
    return f'{(x-1)*100:+.3f}%'
if kind=='widths':
    values=defaultdict(list)
    widths=[1,2,7,15,16,17,31,32,63,64,127,256,1024,2048,8192]
    for width in widths:
        for rd in range(1,4):
            samples=[]
            for side in ['unroll-base','burs-'+tag]:
                src=collect(r/f'{tag}-width-{width}-{rd}-{side}.log').decode()
                sample={}
                for line in src.splitlines():
                    if re.match(r'^[a-z]+,(selection|complete),',line):
                        shape,phase,*nums=line.split(',')
                        assert len(nums)==12 and min(map(float,nums[-2:]))>0
                        assert (shape,phase) not in sample
                        sample[shape,phase]=nums
                assert sample and set(x[1] for x in sample)=={'complete','selection'}
                samples.append(sample)
            base,head=samples
            assert base.keys()==head.keys()
            for (shape,phase),old in base.items():
                new=head[shape,phase]
                assert old[:-2]==new[:-2],(tag,width,shape,phase,old,new)
                values[width,shape,phase].append(float(new[-1])/float(old[-1]))
    scores={k:median(v) for k,v in values.items()}
    assert all(len(v)==3 for v in values.values())
    phases=sorted(set(k[2] for k in scores),reverse=True)
    shapes=sorted(set(k[1] for k in scores))
    cols=[(s,ph)for s in shapes for ph in phases]
    table=['| Requested steps | '+' | '.join(sh+' '+ph for sh,ph in cols)+' |','| ---: |'+' ---: |'*len(cols)]
    for width in widths:
        table.append('| '+str(width)+' | '+' | '.join(pct(scores[width,sh,ph]) if (width,sh,ph) in scores else '—' for sh,ph in cols)+' |')
    summary=[]
    for ph in phases:
        v=[z for k,z in scores.items() if k[2]==ph]
        summary.append(f'{sum(x<=1 for x in v)} of {len(v)} {ph} cells')
    title='Synthetic instruction widths with '+names[tag]
    body='The production benchmark generated each shape at fifteen step counts on the locked Ryzen 7 9700X. The table gives the median of three paired changes in TSC ticks per IR instruction. Instruction counts, output records and bytes, spill and reload counts and both reported memory peaks matched in every pair. The candidate met the parent in '+' and '.join(summary)+'.'
    commands=[tag+'-measure-widths']
elif kind=='functions':
    values=defaultdict(list);groupcounts={}
    bands=['1–31','32–127','128–511','512–2,047','2,048–8,191','8,192+','All']
    modes=['default','all']
    for mode in modes:
        for rd in range(1,6):
            bins=defaultdict(lambda:[0,0,0])
            for group,objects in [('lua',34),('sqlite',1),('musl',1336)]:
                records=[]
                for side in ['base','head']:
                    pre=r/(tag+'-cycles')/f'{mode}-{group}-{side}-{rd}'
                    records.append([tuple(map(int,s.split()))for s in collect(pre.with_suffix('.tsv')).splitlines()])
                pre=r/(tag+'-cycles')
                pair_paths=[pre/f'{mode}-{group}-{side}-{rd}' for side in ['base','head']]
                for ext in ['.sha','.out','.err']:
                    left,right=[collect(file.with_suffix(ext)) for file in pair_paths]
                    assert left==right
                    reference=(r/f'{mode}-{group}{ext}').read_bytes()
                    if ext=='.sha':
                        assert len(left.splitlines())==objects
                        assert [line.split(None,1)[1] for line in left.splitlines()]==[line.split(None,1)[1] for line in reference.splitlines()]
                    else:
                        assert left==reference
                a,b=records
                assert a and len(a)==len(b)
                assert len(a)==groupcounts.setdefault((mode,group),len(a))
                metadata=tuple(row[:3] for row in a)
                meta_key=(mode,group,"metadata")
                assert metadata==groupcounts.setdefault(meta_key,metadata)
                for old,new in zip(a,b):
                    assert len(old)==len(new)==4 and old[:3]==new[:3] and min(old[0],old[1],old[3],new[3])>0
                    for bound in (sum(old[0]>=v for v in [32,128,512,2048,8192]),6):
                        cell=bins[bound];cell[0]+=1;cell[1]+=old[3];cell[2]+=new[3]
            for k,(n,base,head) in bins.items():values[mode,k].append((n,head/base))
    title='Production selection by function size with '+names[tag]
    body='Five alternating paired rounds ran single-lane Tier 1 compilation on the locked 9700X. Each measurement brackets verified instruction selection on a production function. For each size band, the table gives the median paired ratio of summed TSC ticks across Lua, SQLite and musl. The function order, instruction and block counts and selection status matched. All 2,742 debug-object checksums and both output streams matched within each paired round.'
    table=['| Input instructions | Default functions | Default change | All-pass functions | All-pass change |','| --- | ---: | ---: | ---: | ---: |']
    for k,band in enumerate(bands):
        row=[band]
        for mode in modes:
            if not values[mode,k]:
                row.extend(['0','—'])
                continue
            ns,ratios=zip(*values[mode,k]);assert len(ns)==5 and len(set(ns))==1
            row.extend([f'{ns[0]:,}',pct(median(ratios))])
        table.append('| '+' | '.join(row)+' |')
    commands=[tag+'-trace','input-'+tag+'-matched','timing.patch']
else:raise ValueError(kind)
doc=out/'README.md'
assert '## '+title not in doc.read_text()
archive=tag+'-'+kind+'.tar.xz'
with tarfile.open(out/archive,'w:xz',preset=2) as tar:
    for file in sorted(set(files)):tar.add(file,'native/'+str(file.relative_to(r)))
    for cmd in commands+['record-size.py']:tar.add(p/cmd,'source/'+cmd)
    if kind=='functions':
        for ext in ['sha','err','out']:
            for mode in modes:
                for group in ['lua','sqlite','musl']:
                    name=f'{mode}-{group}.{ext}';tar.add(r/name,'native/'+name)
with doc.open('a') as f:f.write('\n## '+title+'\n\n'+body+'\n\n'+'\n'.join(table)+f'\n\n[Native paired measurements and commands]({archive})\n')
print(title,body,*table,sep='\n')
