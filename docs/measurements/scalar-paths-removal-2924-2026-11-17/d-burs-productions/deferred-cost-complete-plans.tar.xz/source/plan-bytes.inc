    // Benchmark probe. Internal padding and process-local addresses are not part of the plan.
    if (getenv("BUSTER_PLAN_BYTES"))
    {
        static _Thread_local FILE* trace;
        if (!trace) trace = fopen(getenv("BUSTER_PLAN_BYTES"), "ab");
        if (!trace) abort();
        const uint32_t header[] = { UINT32_C(0x504c414e), count, error, failed_node, verify, costed };
        if (fwrite(header, sizeof(header), 1, trace) != 1) abort();
        if (error == TIER1_SELECT_OK)
        {
            const uint64_t summary[] = { plan.estimated_cost, plan.effective_use_count, plan.arena_bytes, plan.function_verified,
                                         plan.symbol_count, plan.symbol_access != NULL };
            if (fwrite(summary, sizeof(summary), 1, trace) != 1) abort();
            if (plan.symbol_access && fwrite(plan.symbol_access, 1, plan.symbol_count, trace) != plan.symbol_count) abort();
            for (uint32_t i = 0; i < count; ++i)
            {
                const Tier1SelectPattern* pat = plan.patterns + i;
                const uint32_t ints[] = { (uint32_t)pat->displacement, pat->stack_object, plan.costs[i] };
                const uint8_t bytes[] = { pat->rule, pat->operation, pat->width, pat->source_width, pat->storage_width,
                                          pat->condition, pat->scale, pat->fold_count, pat->intrinsic_cost, pat->compare_immediate,
                                          pat->compare_memory, pat->sign_result, pat->nops, pat->rip, plan.covered[i] };
                if (fwrite(&pat->immediate, sizeof(pat->immediate), 1, trace) != 1 ||
                    fwrite(pat->values, sizeof(pat->values), 1, trace) != 1 ||
                    fwrite(ints, sizeof(ints), 1, trace) != 1 || fwrite(bytes, sizeof(bytes), 1, trace) != 1) abort();
            }
            const size_t offsets = (size_t)count + 1;
            if (fwrite(plan.effective_use_offsets, sizeof(uint32_t), offsets, trace) != offsets ||
                (plan.effective_use_count && fwrite(plan.effective_use_values, sizeof(uint32_t), plan.effective_use_count, trace) != plan.effective_use_count)) abort();
        }
        if (fflush(trace)) abort();
    }
