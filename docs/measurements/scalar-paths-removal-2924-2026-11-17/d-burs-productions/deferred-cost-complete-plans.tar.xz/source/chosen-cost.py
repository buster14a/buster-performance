from pathlib import Path
from subprocess import check_output
from shutil import copytree
from difflib import unified_diff
p=Path(__file__).parent
d=p/'chosen-src';copytree(p/'extended-src',d,dirs_exist_ok=True)
c=d/'buster/compiler'
f=c/'tier1_select.c';s=f.read_text().replace('    uint32_t costs[BUSTER_TIER1_SELECT_MAX_CANDIDATES];\n','')
a=s.index('static inline __attribute__((always_inline)) void tier1_select_add_candidate(')
z=s.index('static bool tier1_select_constant(',a)
orig=s[a:z]
normal=orig[orig.index('    pattern.intrinsic_cost'):orig.index('    candidates->patterns')].replace('pattern.', 'pattern->')
s=s[:a]+'''// Rule matching reads the candidate's form, folded-node count and whether an index exists.
// Canonical value IDs and subtree costs are needed only for the pattern that reaches the plan.
static inline __attribute__((always_inline)) uint32_t tier1_select_finish_pattern(const Tier1SelectForest* forest, uint32_t node, Tier1SelectPattern* pattern)
{
'''+normal+'''    return tier1_select_pattern_cost(forest, node, pattern);
}

static inline __attribute__((always_inline)) void tier1_select_add_candidate(Tier1SelectCandidates* candidates, Tier1SelectPattern pattern)
{
    assert(candidates->count < BUSTER_TIER1_SELECT_MAX_CANDIDATES);
    candidates->patterns[candidates->count++] = pattern;
}

'''+s[z:]
s=s.replace('tier1_select_add_candidate(forest, node, ','tier1_select_add_candidate(')
s=s.replace('    // Only the prefix below count is read. Each addition writes both the pattern and its cost.','    // Only the populated prefix is examined during rule matching.')
s=s.replace('            plan->costs[node] = candidates.costs[chosen];','            plan->costs[node] = tier1_select_finish_pattern(forest, node, &plan->patterns[node]);')
s=s.replace('            Tier1SelectCandidates batch[BUSTER_TIER1_SELECT_LANES];\n            uint32_t chosen[BUSTER_TIER1_SELECT_LANES] = {0};','            Tier1SelectPattern selected[BUSTER_TIER1_SELECT_LANES];\n            uint32_t costs[BUSTER_TIER1_SELECT_LANES];')
s=s.replace('                batch[lane] = tier1_select_candidates(forest, node, TIER1_RULE_NONE);\n                if (batch[lane].count == 0)','                const Tier1SelectCandidates candidates = tier1_select_candidates(forest, node, TIER1_RULE_NONE);\n                if (candidates.count == 0)')
s=s.replace('                    chosen[lane] = tier1_select_munch(&batch[lane]);','                    selected[lane] = candidates.patterns[tier1_select_munch(&candidates)];\n                    costs[lane] = tier1_select_finish_pattern(forest, node, &selected[lane]);')
s=s.replace('                plan->patterns[node] = batch[lane].patterns[chosen[lane]];\n                plan->costs[node] = batch[lane].costs[chosen[lane]];','                plan->patterns[node] = selected[lane];\n                plan->costs[node] = costs[lane];')
f.write_text(s)
f=c/'tier1_select_burs_test.c';s=f.read_text();a=s.index('    // The candidates need the costs column');z=s.index('    for (uint32_t node = 0; valid &&',a);s=(s[:a]+s[z:]).replace('tier1_select_candidates(&costed','tier1_select_candidates(&forest')
f.write_text(s);(d/'check-common.inc').write_text(s.split('#if BUSTER_IN_UNIT(BUSTER_UNIT_BACKEND)')[0])
diff=''
for f in sorted(c.glob('*.c')):
 name='src/buster/compiler/'+f.name;old=check_output(['git','show','cc7d4ffb4:'+name],cwd=p/'tree').decode()
 diff+=''.join(unified_diff(old.splitlines(True),f.read_text().splitlines(True),'a/'+name,'b/'+name))
(p/'chosen.patch').write_text(diff)
for name in ['build-extended','extended-corpus','extended-tests','extended-measure-sources','extended-bench-source','ordinary-extended','whole-extended','extended-measure-widths']:
 s=(p/name).read_text().replace('extended','chosen').replace('signloads-census.ok','extended-census.ok')
 if name=='build-extended':
  s=s.replace('/dev/shm/buster-cfg-cleanup-6b097f86/adjacent-builds-clean.ok','$root/extended-builds-clean.ok').replace('Build x87 grammar productions','Build selection with costs and operand canonicalization computed after the grammar chooses')
 (p/name.replace('extended','chosen')).write_text(s)
