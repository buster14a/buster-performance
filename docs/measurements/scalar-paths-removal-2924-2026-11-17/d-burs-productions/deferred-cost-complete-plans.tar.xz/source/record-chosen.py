from pathlib import Path
import runpy,re,tarfile
from collections import Counter
p=Path(__file__).resolve().parent;r=p/'results'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-burs-productions')
verify=runpy.run_path(str(p/'verify-plan-bytes.py'))['verify']
compare=runpy.run_path(str(p/'compare-selected.py'))['compare']
rows=[];picked=Counter();plans=Counter();logs=set()
for mode in ('default','all'):
 for group in ('lua','sqlite','musl'):
  c,_=compare('chosen',mode,group);s=verify(mode,group)
  assert s['failures']==0
  picked.update(c);plans.update(s)
  rows.append(f'| {mode} | {group} | {s["plans"]:,} | {s["nodes"]:,} | {s["uses"]:,} | {s["bytes"]:,} |')
  logs.update(r.glob(f'plan-*-{mode}-{group}.*'));logs.add(r/f'plans-{mode}-{group}.gz')
  logs.update(r.glob(f'chosen-{mode}-{group}.*'));logs.add(r/f'chosen-records-{mode}-{group}.bin')
assert plans==dict(plans=13036,nodes=2364459,uses=912714,bytes=168865267)
assert picked==dict(total=1006223,baseline=396316,candidate=19716)
for test in ['select','pipeline-1','pipeline-133','pipeline-789','test-tier1-masks','test-tier1-emit','test-tier1-liveness']:
 f=r/f'chosen-{test}.log';t=f.read_text();logs.add(f);assert re.search(r'[1-9]\d* checks, 0 failures',t)
 if test=='select':assert '1530046 checks, 0 failures' in t and '5957, digest d15b788da26467e5' in t
 if test.startswith('pipeline'):assert re.search(r'native=[1-9]\d* clang=[1-9]\d*',t)
for f in (r/'mutants/chosen').glob('*.status'):
 assert int(f.read_text())==int(f.stem!='x87-control')
 logs.update([f,f.with_suffix('.log')])
names=['verify-plan-bytes.py','record-chosen.py','chosen-cost.py','chosen.patch','capture.patch','plan-bytes.py','plan-bytes.inc','plan-parent.patch','plan-chosen.patch','build-plan-bytes','plan-corpus','build-chosen','chosen-corpus','chosen-tests','compare-selected.py','chosen-expanded.log','chosen-corpus-compared.log','verified-complete-plans.log']
archive='deferred-cost-complete-plans.tar.xz';doc=out/'README.md';heading='## Complete selector plans with deferred costs'
assert heading not in doc.read_text()
with tarfile.open(out/archive,'w:xz',preset=2)as t:
 for f in sorted(logs):t.add(f,'native/'+str(f.relative_to(r)))
 for n in names:t.add(p/n,'source/'+n)
with doc.open('a')as f:
 f.write('\n'+heading+'''

The default selector canonicalizes operands and computes subtree costs after choosing a pattern. The explicitly costed selector still prices every candidate and reuses the winning pattern. The parent is `cc7d4ffb4` and the candidate is `59c73da8a`. Each compiler wrote all semantic fields of every returned plan to a binary stream in function order. The encoder includes error status, estimates, workspace size, symbol access, pattern payloads, per-node costs, covered flags and effective uses. Each native pair passed byte comparison. The independent reader verified both native hashes, every record boundary and each final effective-use offset.

| Passes | Workload | Successful plans | Plan nodes | Effective uses | Identical bytes |
| --- | --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

The six runs produced 13,036 successful plans, covering 2,364,459 nodes and 912,714 effective uses. Both builds produced the same 2,742 debug objects, stdout and diagnostics. The candidate and choice census recorded 1,006,223 equivalent visits, of which 19,716 used maximal munch on the candidate. The native frozen digest and 1,530,046 selector checks passed, as did the mask, liveness and emitter suites and three Clang-backed pipeline seeds. These source workloads exercised successful plan construction. Failure cases have separate coverage in the selector suite.

[Native streams, object manifests, selection records, probe and verification scripts](deferred-cost-complete-plans.tar.xz)
''')
