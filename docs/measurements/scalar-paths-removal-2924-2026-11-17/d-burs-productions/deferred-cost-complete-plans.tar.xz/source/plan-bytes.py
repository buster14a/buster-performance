from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
p=Path(__file__).parent; f='src/buster/compiler/tier1_select.c'
parents={'parent':check_output(['git','show','cc7d4ffb4:'+f],cwd=p/'tree').decode(),'chosen':(p/'chosen-src'/f[4:]).read_text()}
for tag,s in parents.items():
 start=s.index('static Tier1SelectError tier1_select_plan_checked(',s.index('// `costed` is true'))
 i=s.index('    return error;\n}',start); assert i<s.index('// The plan of a function',start)
 changed=s[:i]+(p/'plan-bytes.inc').read_text()+s[i:]
 (p/f'plan-{tag}.patch').write_text(''.join(unified_diff(s.splitlines(True),changed.splitlines(True),'a/'+f,'b/'+f)))
s=(p/'chosen-corpus').read_text()
s=s[:s.index('until [[ -f')]+'''side=$3
out="/tmp/buster-selector-images-6b097f86/plan-object-dir"
mkdir -p "$out"
cd "$out";test -z "$(find . -name '*.o' -print -quit)"
export BUSTER_PLAN_BYTES="/tmp/buster-selector-images-6b097f86/plan-$side.bin"
test ! -e "$BUSTER_PLAN_BYTES"
exe="/dev/shm/buster-unroll-6b097f86/src/build/plan-$side"
"$HOME/buster-fast-bench/exclusive.sh" taskset -c 2 bash -c 'p=$1; shift;exec "$@" >"$p.out" 2>"$p.err"' _ "$root/plan-$side-$mode-$group" "$exe" -g -c --tier1 --lanes 1 "${flags[@]}" "${args[@]}"
n=$(find . -maxdepth 1 -name '*.o' -type f|wc -l)
case $group in sqlite)test "$n" = 1;;lua)test "$n" = 34;;musl)test "$n" = 1336;;esac
sha256sum -- *.o >"$root/plan-$side-$mode-$group.sha"
rm -- *.o
test -s "$BUSTER_PLAN_BYTES"
'''
(p/'plan-corpus').write_text(s)
s=(p/'build-chosen').read_text()
s=s[:s.index('until [[ -f')]+'''until [[ -f /dev/shm/buster-dom-combined-6b097f86/shortclimb-builds-clean.ok ]];do sleep 2;done
cd "$ir/src"
git diff --exit-code -- src
for side in parent chosen;do
 if [[ $side == chosen ]];then git apply "$root/chosen.patch";fi
 git apply "$root/plan-$side.patch"
 "$lock" timeout 1200 ./build.sh --config Release --jobs 4 >"$root/plan-$side-build.log" 2>&1
 image=/tmp/buster-selector-images-6b097f86/plan-$side
 cp --preserve=mode build/compiler "$image";cmp build/compiler "$image";ln -s "$image" "build/plan-$side"
 git apply -R "$root/plan-$side.patch"
 if [[ $side == chosen ]];then git apply -R "$root/chosen.patch";fi
done
git diff --exit-code -- src;touch "$root/plan-builds-clean.ok";cd "$root"
archive=/tmp/buster-selector-images-6b097f86
for mode in default all;do for group in lua sqlite musl;do
 for side in parent chosen;do bash plan-corpus "$mode" "$group" "$side";done
 for suffix in sha out err;do cmp "plan-parent-$mode-$group.$suffix" "plan-chosen-$mode-$group.$suffix";done
 cmp "$archive/plan-parent.bin" "$archive/plan-chosen.bin"
 wc -c "$archive"/plan-{parent,chosen}.bin >"plan-bytes-$mode-$group.log"
 sha256sum "$archive"/plan-{parent,chosen}.bin >>"plan-bytes-$mode-$group.log"
 gzip -1c "$archive/plan-parent.bin" >"$archive/plans-$mode-$group.gz";rm "$archive"/plan-{parent,chosen}.bin
done;done
touch plan-compared.ok
'''
(p/'build-plan-bytes').write_text(s)
