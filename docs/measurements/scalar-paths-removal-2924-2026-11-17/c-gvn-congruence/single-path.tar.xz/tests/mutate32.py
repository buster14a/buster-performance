from pathlib import Path
import json,shlex,subprocess,os
p=Path('/tmp/buster-3433');root=p/'published/src/buster/compiler';work=p/'mut32';work.mkdir(exist_ok=True)
a=root/'ir_optimize_gvn.c';s=a.read_text()
variants=[
 ('hash tail','work->hashes + first + half, valid, hash','work->hashes + first + half, gvn_mutation == 1 ? (valid & 127) : valid, hash'),
 ('phi proof','&& ir_gvn_distinct_phis(work);','&& (gvn_mutation == 2 || ir_gvn_distinct_phis(work));'),
 ('phi edge value','result.extra[extra++] = operands[pair[1]];','result.extra[extra++] = gvn_mutation == 3 ? pair[1] : operands[pair[1]];'),
 ('call arguments','result.extra[extra++] = operands[f->extra[call->argument_first + j]];','result.extra[extra++] = gvn_mutation == 4 ? f->extra[call->argument_first + j] : operands[f->extra[call->argument_first + j]];'),
 ('debug representative','binding->value = ir_gvn_resolve(work->alias, binding->value);','binding->value = gvn_mutation == 5 ? binding->value : ir_gvn_resolve(work->alias, binding->value);'),
 ('vector policy','const __mmask16 own = valid & _mm_cmplt_epu8_mask','const __mmask16 own = (gvn_mutation == 6 ? 0 : valid) & _mm_cmplt_epu8_mask'),
 ('pressure free values','!work->pressure ||','gvn_mutation == 7 || !work->pressure ||')
]
for label,before,after in variants:
 if before not in s: 
  if label=='debug representative':
   before='binding->anchor = ir_gvn_resolve(work->alias, binding->anchor);';after='binding->anchor = gvn_mutation == 5 ? binding->anchor : ir_gvn_resolve(work->alias, binding->anchor);'
  elif label=='pressure free values':
   before='work.pressure = options.pressure;';after='work.pressure = gvn_mutation != 7 && options.pressure;'
 assert before in s,label
 s=s.replace(before,after,1)
(work/'mutated.c').write_text(s)
(work/'overlay.json').write_text(json.dumps({'version':0,'roots':[{'type':'file','name':str(a),'external-contents':str(work/'mutated.c')}]}))
(work/'driver.c').write_text('static unsigned gvn_mutation;\n#include "buster/compiler/main_unit_backend.c"\nLaneTestResources lane_test_resources;\nint main(int argc, char **argv) { gvn_mutation = argc > 1 ? atoi(argv[1]) : 0; return run_ir_gvn_tests(1, argv); }\n')
cmd=shlex.split((p/'build-only-san').read_text().strip());i=cmd.index(str(p/'sanitized.c'));cmd[i:i+1]=['-ivfsoverlay',str(work/'overlay.json'),str(work/'driver.c')];cmd[-1]=str(work/'test')
subprocess.run(cmd,check=True)
for k,label in enumerate(['original',*[x[0] for x in variants]]):
 r=subprocess.run([str(work/'test'),str(k)],cwd=p/"published",capture_output=True,timeout=90)
 raw=(r.stdout+r.stderr).decode(errors='replace');(work/f'{k}.log').write_text(raw)
 print(k,label,r.returncode,next((l for l in raw.splitlines() if 'failure' in l or 'failed' in l),'')[:160],flush=True)
