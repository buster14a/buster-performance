from pathlib import Path
from statistics import median
from collections import defaultdict
import re, tarfile
p=Path(__file__).parent;r=p/'results';cycles=r/'cycles-matched'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-ir-optimizer-worklists')
out.mkdir(exist_ok=True)
bins=['0–31','32–127','128–511','512–2,047','2,048–8,191','8,192+','Total']
modes=('default','all')
corpora={'lua':34,'sqlite':1,'musl':1336}
measure={}
for mode in modes:
 per=defaultdict(list)
 for run in range(1,6):
  cat=defaultdict(lambda:[0]*5)
  for group,nobj in corpora.items():
   base,head=[cycles/f'{mode}-{group}-{v}-{run}' for v in ('base','head')]
   for ext in ['.sha','.out','.err']:
    assert base.with_suffix(ext).read_bytes()==head.with_suffix(ext).read_bytes()
   assert len(base.with_suffix('.sha').read_text().splitlines())==nobj
   bs,hs=[[[int(x)for x in l.split()]for l in f.with_suffix('.tsv').read_text().splitlines()]for f in (base,head)]
   assert [x[:2]for x in bs]==[x[:2]for x in hs]
   for (blocks,n,w0,d0),(_,_,w1,d1)in zip(bs,hs):
    assert min(w0,d0,w1,d1)>0 and w0>d0 and w1>d1
    for k in (sum(n>=x for x in [32,128,512,2048,8192]),6):
     a=cat[k];a[0]+=1;a[1]+=w0;a[2]+=w1;a[3]+=d0;a[4]+=d1
  assert cat[6][0]==10124
  for k,(n,b,h,db,dh)in cat.items():per[k].append((n,h/b,dh/db))
 for k,x in per.items():
  assert len({a[0]for a in x})==1 and len(x)==5
  measure[mode,k]=[x[0][0],median(a[1]for a in x),median(a[2]for a in x)]
def pipeline():
 return ['| '+name+' | '+' | '.join(f'{v:,}' if i==0 else f'{v:.4f}' for m in modes for i,v in enumerate(measure[m,k]))+' |'for k,name in enumerate(bins)]
def whole(prefix):
 ordinary=[]
 for group,n in corpora.items():
  row=[]
  for m in modes:
   base,head=[(r/f'{prefix}-objects-{m}-{group}-{v}.sha').read_bytes()for v in ('base','frontier')];assert base==head and len(base.splitlines())==n+2
   s=(r/f'{prefix}-compile-{m}-{group}.log').read_text();assert s.rstrip().endswith('ab: done, 0 failed runs')
   ratios=[]
   for part in s.split('time-runs: done, 0 failed processes')[:-1]:
    xs={k:int(x)for k,x in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',part,re.M)}
    ratios.append(xs['head']/xs['base'])
   assert len(ratios)==5;row.append(f'{100*(median(ratios)-1):+.3f}%')
  ordinary.append('| '+group+' | '+str(n)+' | '+' | '.join(row)+' |')
 return ordinary
synthetic=[]
for n in (32,128,512,2048,8192,16384):
 values=[]
 for blocks in (1,8):
  for mode in ('sccp','all'):
   results=[]
   for v in ('unroll-base','sccp-head'):
    s=(r/f'synth-{n}-{blocks}-{mode}-{v}.log').read_text()
    assert 'ir-optimize jump-chain' in s
    t=re.search(r'^ir-optimize large-dag input=(\d+) output=(\d+) blocks=(\d+)/(\d+)[^\n]*\n  ns/function=[^\n]*TSC-ticks/input-instruction=([\d.]+)',s,re.M)
    results.append(t.groups())
   assert results[0][:4]==results[1][:4]
   values.append(float(results[1][4])/float(results[0][4]))
 synthetic.append('| '+str(n)+' | '+' | '.join(f'{v:.4f}'for v in values)+' |')
for seed in (1,133,789):
 assert '0 failures' in (r/f'frozen-{seed}.log').read_text()

for seed in (139,1,133,789):
 assert '384684 checks, 0 failures' in (r/'queue-frozen-139.log').read_text()
 assert '0 failures' in (r/f'queue-frozen-{seed}.log').read_text()
 assert '0 failures' in (r/f'frozen-{seed}.log').read_text()
ordinary=whole('production');final=whole('ring')
dense=[]
for mode in ('sccp','all'):
 v=[]
 for i in (1,2,3):
  xs=[]
  for side in ('sccp-ring','unroll-base'):
   s=(r/f'ring-dense-{mode}-{side}-{i}.log').read_text();assert 'ir-optimize jump-chain' in s
   t=re.search(r'^ir-optimize large-dag input=(\d+) output=(\d+) blocks=(\d+)/(\d+)[^\n]*\n  ns/function=[^\n]*TSC-ticks/input-instruction=([\d.]+)',s,re.M);xs.append(t.groups())
  assert xs[0][:4]==xs[1][:4] and xs[0][0]=='16388'
  v.append(float(xs[0][4])/float(xs[1][4]))
 dense.append(f'{median(v):.4f}')
files=['candidate.patch','queue-tests.patch','probe.patch','tests','trace-matched','matched-corpus','ordinary','ordinary-corpus','verify-queue','ring-ordinary','ring-corpus','record.py']
with tarfile.open(out/'sccp-native.tar.xz','w:xz')as tar:
 for name in files:tar.add(p/name,arcname='source/'+name)
 for f in sorted(r.rglob('*')):
  if f.is_file():tar.add(f,arcname='native/'+str(f.relative_to(r)))
new='''## Sparse conditional constant propagation

Newly executable blocks enqueue up to sixteen instructions per packet. An additional incoming edge revisits only the block’s leading phi nodes. When propagation stalls, masked loads find remaining unknown values in reachable blocks, sixty-four at a time. Each packet fits in the current contiguous span of the ring. The implementation uses the existing queue and scratch space.

The instrumentation brackets SCCP and the complete verified pipeline. The parent is buster14a/buster@cc7d4ffb449c1f57d8d867c2ad2bf6dc6bfebc7f. Five alternating paired rounds on CPU 2 of the locked Ryzen 7 9700X processed all 34 Lua, one SQLite and 1,336 musl translation units. Each row sums ticks within a paired round and takes the median ratio over the five rounds. Every pair had identical function shapes, debug objects, stdout and diagnostics. The six size bins in each configuration are the acceptance workload from issue 3445.

| Input instructions | Default functions | Default pipeline | Default SCCP | All-pass functions | All-pass pipeline | All-pass SCCP |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(pipeline())+'''

### Complete compilation and dense inputs

The shipping revision includes 26,608 ring-buffer checks that cover every ring position and every leading-phi count at ten block sizes. All 384,684 checks passed at the frozen seed, including the optimizer digest `0x292b130a5600b0e5`. Seeds 1, 133 and 789 passed as well. The production-only build and the final build with the extra tests each ran five paired rounds of three processes against the uninstrumented parent. Percentages give the paired change in user cycles. The results include matching debug objects, stdout and diagnostics in both configurations.

| Corpus | Objects | Production-only default | Production-only all passes | Shipping default | Shipping all passes |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(a+b.split('|',3)[3]for a,b in zip(ordinary,final))+'''

The optimizer benchmark also timed large DAGs with eleven samples per executable. The table gives candidate ticks per input instruction divided by parent ticks across the six requested input sizes. The command’s block argument changes the jump-chain shape as well. All emitted graph shapes matched.

| Requested instructions | 1 block, SCCP | 1 block, all | 8 blocks, SCCP | 8 blocks, all |
| ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(synthetic)+'''

Three further alternating pairs used the final shipping executable on the 16,388-instruction single-block DAG. Its median ratios were '''+dense[0]+''' with SCCP alone and '''+dense[1]+''' with all passes.

[SCCP source changes, probes, native commands, correctness checks, raw cycles and object hashes](sccp-native.tar.xz)
'''
path=out/'README.md';base=path.read_text().split('\n## Sparse conditional constant propagation')[0];path.write_text(base.rstrip()+'\n\n'+new)
print(*pipeline(),*ordinary,*final,*synthetic,*dense,sep='\n')
