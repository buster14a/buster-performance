from pathlib import Path
from subprocess import check_output
p=Path(__file__).parent;d=p/'tree';fn='src/buster/compiler/ir_optimize.c';s=check_output(['git','show','HEAD:'+fn],cwd=d).decode()
start=s.index('static __attribute__((unused, aligned(64))) bool ir_optimize_thread_targets(');end=s.index('\nstatic bool ir_optimize_equal(',start)
(p/'original.inc').write_text(s[start:end]);signature=s[start:s.index('\n{',start)]
for tag in ('seedwalk','seedstack','gatherwalk','gatherstack'):
 gather=tag.startswith('gather');stack=tag.endswith('stack')
 body=signature+'''
{
    if (count == 0) return true;
    if (direct == NULL || targets == NULL) return false;
    const __m512i lanes = _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
    bool unresolved = false;
    for (uint64_t first = 0; first < count; first += 16)
    {
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, count - first < 16 ? (uint32_t)(count - first) : 16);
        const __m512i successors = _mm512_maskz_loadu_epi32(valid, direct + first);
        if (_mm512_mask_cmpge_epu32_mask(valid, successors, _mm512_set1_epi32((int32_t)count)) != 0) return false;
        const __m512i ids = _mm512_add_epi32(_mm512_set1_epi32((int32_t)first), lanes);
        const __mmask16 moved = _mm512_mask_cmpneq_epi32_mask(valid, successors, ids);
'''
 if gather:
  body+='''        if (moved != 0 && !unresolved)
        {
            // Rebase the signed gather indices around the middle of the unsigned ID range.
            const void* origin = (const void*)((uintptr_t)direct + (UINT64_C(1) << 33));
            const __m512i indices = _mm512_xor_si512(successors, _mm512_set1_epi32(INT32_MIN));
            const __m512i following = _mm512_mask_i32gather_epi32(successors, moved, indices, origin, sizeof(uint32_t));
            unresolved = _mm512_cmpneq_epi32_mask(following, successors) != 0;
        }
'''
 else:body+='''        unresolved |= moved != 0;
'''
 body+='''    }
    if (!unresolved)
    {
        memmove(targets, direct, (uint64_t)count * sizeof(uint32_t));
        return true;
    }
    const uint64_t saved = scratch->length;
    uint32_t* current = arena_push_array(scratch, count, sizeof(uint32_t), _Alignof(uint32_t));
'''
 if stack:body+='''    uint32_t* path = arena_push_array(scratch, count, sizeof(uint32_t), _Alignof(uint32_t));
    if (current == NULL || path == NULL)
    {
        arena_pop_to(scratch, saved);
        return false;
    }
'''
 else:body+='''    if (current == NULL) return false;
'''
 body+='''    for (uint64_t first = 0; first < count; first += 16)
    {
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, count - first < 16 ? (uint32_t)(count - first) : 16);
        const __m512i successors = _mm512_maskz_loadu_epi32(valid, direct + first);
'''
 if gather:body+='''        const void* origin = (const void*)((uintptr_t)direct + (UINT64_C(1) << 33));
        const __m512i indices = _mm512_xor_si512(successors, _mm512_set1_epi32(INT32_MIN));
        const __m512i following = _mm512_mask_i32gather_epi32(successors, valid, indices, origin, sizeof(uint32_t));
        const __mmask16 ready = _mm512_cmpeq_epi32_mask(following, successors);
'''
 else:body+='''        const __m512i ids = _mm512_add_epi32(_mm512_set1_epi32((int32_t)first), lanes);
        const __mmask16 ready = _mm512_cmpeq_epi32_mask(ids, successors);
'''
 body+='''        _mm512_mask_storeu_epi32(current + first, valid, _mm512_mask_mov_epi32(_mm512_set1_epi32(-1), ready, successors));
    }
    for (uint64_t first = 0; first < count; first += 16)
    {
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, count - first < 16 ? (uint32_t)(count - first) : 16);
        const __m512i known = _mm512_maskz_loadu_epi32(valid, current + first);
        uint32_t pending = _mm512_mask_cmpeq_epi32_mask(valid, known, _mm512_set1_epi32(-1));
        while (pending != 0)
        {
            const uint32_t block = (uint32_t)first + (uint32_t)__builtin_ctz(pending);
            pending &= pending - 1;
            // A previous component walk in this packet may have resolved this block.
            if (current[block] != UINT32_MAX) continue;
            const uint32_t successor = direct[block];
            if (current[successor] != UINT32_MAX)
            {
                current[block] = current[successor];
                continue;
            }
            // The start is unresolved, so it cannot already name a finished representative.
            // Its own ID is a unique temporary mark for all vertices visited by this walk.
            uint32_t node = block;
            uint32_t length = 0;
            do
            {
                current[node] = block;
'''
 body+=('                path[length++] = node;\n' if stack else '                length += 1;\n')
 body+='''                node = direct[node];
            } while (current[node] == UINT32_MAX);
            uint32_t representative = current[node];
            if (representative == block)
            {
                representative = node;
                for (uint32_t other = direct[node]; other != node; other = direct[other])
                {
                    if (other < representative) representative = other;
                }
            }
'''
 if stack:body+='''            for (uint64_t i = 0; i < length; i += 16)
            {
                const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, length - i < 16 ? (uint32_t)(length - i) : 16);
                const __m512i ids = _mm512_maskz_loadu_epi32(active, path + i);
                void* origin = (void*)((uintptr_t)current + (UINT64_C(1) << 33));
                _mm512_mask_i32scatter_epi32(origin, active, _mm512_xor_si512(ids, _mm512_set1_epi32(INT32_MIN)), _mm512_set1_epi32((int32_t)representative), 4);
            }
'''
 else:body+='''            node = block;
            for (uint32_t i = 0; i < length; i += 1)
            {
                current[node] = representative;
                node = direct[node];
            }
'''
 body+='''        }
    }
    memcpy(targets, current, (uint64_t)count * sizeof(uint32_t));
    arena_pop_to(scratch, saved);
    return true;
}
'''
 (p/(tag+'.inc')).write_text(body)
 if tag=='gatherwalk':(d/fn).write_text(s[:start]+body+s[end:])
fn='src/buster/compiler/ir_optimize_layout.c';s=check_output(['git','show','HEAD:'+fn],cwd=d).decode();a=s.index('    const uint32_t count = batch->count;');b=s.index('\n}',a)
t='''    const __mmask16 active = (__mmask16)batch->active;
    const __m512i source = _mm512_loadu_si512(batch->source_enter);
    const __mmask16 back = _mm512_mask_cmple_epu32_mask(active, _mm512_loadu_si512(batch->target_enter), source) &
                           _mm512_cmplt_epu32_mask(source, _mm512_loadu_si512(batch->target_leave));
    const __mmask16 adjacent = _mm512_mask_cmpeq_epi32_mask(active, _mm512_loadu_si512(batch->target), _mm512_loadu_si512(batch->following));
    __m512i priority = _mm512_maskz_set1_epi32(active, 3);
    priority = _mm512_mask_add_epi32(priority, back, priority, _mm512_set1_epi32(2));
    priority = _mm512_mask_add_epi32(priority, adjacent, priority, _mm512_set1_epi32(1));
    const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, batch->count);
    _mm512_mask_storeu_epi32(ranks, valid, priority);'''
(d/fn).write_text(s[:a]+t+s[b:]);(p/'candidate.patch').write_bytes(check_output(['git','diff'],cwd=d))
