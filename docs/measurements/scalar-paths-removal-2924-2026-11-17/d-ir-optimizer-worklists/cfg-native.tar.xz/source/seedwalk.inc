static __attribute__((unused, aligned(64))) bool ir_optimize_thread_targets(Arena* scratch, const uint32_t* direct, uint32_t count, uint32_t* targets)
{
    if (count == 0) return true;
    if (direct == NULL || targets == NULL) return false;
    const __m512i lanes = _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
    bool unresolved = false;
    for (uint64_t first = 0; first < count; first += 16)
    {
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, count - first < 16 ? (uint32_t)(count - first) : 16);
        const __m512i successors = _mm512_maskz_loadu_epi32(valid, direct + first);
        if (_mm512_mask_cmpge_epu32_mask(valid, successors, _mm512_set1_epi32((int32_t)count)) != 0) return false;
        const __m512i ids = _mm512_add_epi32(_mm512_set1_epi32((int32_t)first), lanes);
        const __mmask16 moved = _mm512_mask_cmpneq_epi32_mask(valid, successors, ids);
        unresolved |= moved != 0;
    }
    if (!unresolved)
    {
        memmove(targets, direct, (uint64_t)count * sizeof(uint32_t));
        return true;
    }
    const uint64_t saved = scratch->length;
    uint32_t* current = arena_push_array(scratch, count, sizeof(uint32_t), _Alignof(uint32_t));
    if (current == NULL) return false;
    for (uint64_t first = 0; first < count; first += 16)
    {
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, count - first < 16 ? (uint32_t)(count - first) : 16);
        const __m512i successors = _mm512_maskz_loadu_epi32(valid, direct + first);
        const __m512i ids = _mm512_add_epi32(_mm512_set1_epi32((int32_t)first), lanes);
        const __mmask16 ready = _mm512_cmpeq_epi32_mask(ids, successors);
        _mm512_mask_storeu_epi32(current + first, valid, _mm512_mask_mov_epi32(_mm512_set1_epi32(-1), ready, successors));
    }
    for (uint64_t first = 0; first < count; first += 16)
    {
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, count - first < 16 ? (uint32_t)(count - first) : 16);
        const __m512i known = _mm512_maskz_loadu_epi32(valid, current + first);
        uint32_t pending = _mm512_mask_cmpeq_epi32_mask(valid, known, _mm512_set1_epi32(-1));
        while (pending != 0)
        {
            const uint32_t block = (uint32_t)first + (uint32_t)__builtin_ctz(pending);
            pending &= pending - 1;
            // A previous component walk in this packet may have resolved this block.
            if (current[block] != UINT32_MAX) continue;
            const uint32_t successor = direct[block];
            if (current[successor] != UINT32_MAX)
            {
                current[block] = current[successor];
                continue;
            }
            // The start is unresolved, so it cannot already name a finished representative.
            // Its own ID is a unique temporary mark for all vertices visited by this walk.
            uint32_t node = block;
            uint32_t length = 0;
            do
            {
                current[node] = block;
                length += 1;
                node = direct[node];
            } while (current[node] == UINT32_MAX);
            uint32_t representative = current[node];
            if (representative == block)
            {
                representative = node;
                for (uint32_t other = direct[node]; other != node; other = direct[other])
                {
                    if (other < representative) representative = other;
                }
            }
            node = block;
            for (uint32_t i = 0; i < length; i += 1)
            {
                current[node] = representative;
                node = direct[node];
            }
        }
    }
    memcpy(targets, current, (uint64_t)count * sizeof(uint32_t));
    arena_pop_to(scratch, saved);
    return true;
}
