static __attribute__((unused, aligned(64))) bool ir_optimize_thread_targets(Arena* scratch, const uint32_t* direct, uint32_t count, uint32_t* targets)
{
    const uint64_t saved = scratch->length;
    bool valid = count == 0 || (direct != 0 && targets != 0);
    for (uint32_t block = 0; valid && block < count; block += 1)
    {
        valid = direct[block] < count;
    }
    uint32_t* current = 0;
    uint32_t* minimum = 0;
    uint32_t* next = 0;
    uint32_t* next_minimum = 0;
    if (valid && count != 0)
    {
        current = arena_push_array(scratch, count, sizeof(uint32_t), _Alignof(uint32_t));
        minimum = arena_push_array(scratch, count, sizeof(uint32_t), _Alignof(uint32_t));
        next = arena_push_array(scratch, count, sizeof(uint32_t), _Alignof(uint32_t));
        next_minimum = arena_push_array(scratch, count, sizeof(uint32_t), _Alignof(uint32_t));
        valid = current != 0 && minimum != 0 && next != 0 && next_minimum != 0;
    }
    if (valid && count != 0)
    {
        for (uint32_t block = 0; block < count; block += 1)
        {
            current[block] = UINT32_MAX;
            minimum[block] = UINT32_MAX;
        }
        for (uint32_t block = 0; block < count; block += 1)
        {
            uint32_t node = block;
            uint32_t length = 0;
            while (current[node] == UINT32_MAX && minimum[node] != block)
            {
                minimum[node] = block;
                next_minimum[node] = length;
                next[length++] = node;
                node = direct[node];
            }
            uint32_t representative = current[node];
            if (representative == UINT32_MAX)
            {
                representative = node;
                for (uint32_t i = next_minimum[node]; i < length; i += 1)
                {
                    if (next[i] < representative)
                    {
                        representative = next[i];
                    }
                }
            }
            for (uint32_t i = 0; i < length; i += 1)
            {
                current[next[i]] = representative;
            }
        }
    }
    if (valid && count != 0)
    {
        memcpy(targets, current, (uint64_t)count * sizeof(uint32_t));
    }
    arena_pop_to(scratch, saved);
    return valid;
}
