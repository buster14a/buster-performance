from pathlib import Path
from difflib import unified_diff
import subprocess,sys
p=Path(__file__).parent;repo=p/'tree';tag=sys.argv[1];out=[]
for name in ('ir_optimize.c','c_check_tier1.c'):
 f='src/buster/compiler/'+name
 s=subprocess.check_output(['git','show','HEAD:'+f],cwd=repo).decode() if tag=='base' else (repo/f).read_text()
 if name=='ir_optimize.c':
  a=s.index('static __attribute__((unused, aligned(64))) bool ir_optimize_thread_targets(')
  t=s[:a]+'''static _Thread_local uint64_t cfg_thread_ticks, cfg_layout_ticks;
#define ir_optimize_thread_targets ir_optimize_thread_targets_inner
'''+s[a:]
  a=t.index('static bool ir_optimize_equal(')
  t=t[:a]+'''#undef ir_optimize_thread_targets
static bool ir_optimize_thread_targets(Arena* scratch, const uint32_t* direct, uint32_t count, uint32_t* targets)
{
    static _Thread_local bool opened;
    static _Thread_local FILE* graph;
    if (!opened) { opened = true; const char* path = getenv("BUSTER_CFG_GRAPHS"); if (path) graph = fopen(path, "ab"); }
    if (graph) { fwrite(&count, sizeof(count), 1, graph); fwrite(direct, sizeof(uint32_t), count, graph); }
    _mm_lfence(); const uint64_t start = __rdtsc(); _mm_lfence();
    const bool ok = ir_optimize_thread_targets_inner(scratch, direct, count, targets);
    _mm_lfence(); cfg_thread_ticks += __rdtsc() - start; _mm_lfence();
    return ok;
}

'''+t[a:]
  a=t.index('        error = ok ? ir_optimize_layout_order(');b=t.index(';',a)+1
  t=t[:a]+'''        _mm_lfence(); const uint64_t layout_start = __rdtsc(); _mm_lfence();
'''+t[a:b]+'''
        _mm_lfence(); cfg_layout_ticks += __rdtsc() - layout_start; _mm_lfence();'''+t[b:]
 else:
  a=s.index('        const IrCheck check = ir_optimize_verified_path(');b=s.index(';',a)+1
  t=s[:a]+'''        static FILE* cfg_trace;
        if (!cfg_trace && getenv("BUSTER_CFG_TICKS")) cfg_trace = fopen(getenv("BUSTER_CFG_TICKS"),"a");
        cfg_thread_ticks = 0;
        cfg_layout_ticks = 0;
        _mm_lfence(); const uint64_t cfg_start = __rdtsc(); _mm_lfence();
'''+s[a:b]+'''
        _mm_lfence(); const uint64_t elapsed = __rdtsc() - cfg_start; _mm_lfence();
        if (cfg_trace) fprintf(cfg_trace,"%u %u %lu %lu %lu %lu\\n",function->block_count,function->instruction_count,elapsed,cfg_thread_ticks+cfg_layout_ticks,cfg_thread_ticks,cfg_layout_ticks);
'''+s[b:]
 out.extend(unified_diff(s.splitlines(True),t.splitlines(True),'a/'+f,'b/'+f))
(p/(tag+'-probe.patch')).write_text(''.join(out))
