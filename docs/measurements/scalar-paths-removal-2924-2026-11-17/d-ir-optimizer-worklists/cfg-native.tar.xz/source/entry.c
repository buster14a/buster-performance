#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include "buster/compiler/lane.c"
#include COMPONENT
__attribute__((noinline)) bool ENTRY(Arena* scratch,const uint32_t* edges,uint32_t n,uint32_t* targets)
{
    return ir_optimize_thread_targets(scratch,edges,n,targets);
}
