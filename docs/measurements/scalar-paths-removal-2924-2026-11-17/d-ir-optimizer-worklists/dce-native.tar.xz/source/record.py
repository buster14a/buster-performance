from pathlib import Path
from statistics import median
from collections import defaultdict
import re, tarfile
p=Path(__file__).parent;r=p/'results';cycles=r/'cycles-matched'
out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-ir-optimizer-worklists')
out.mkdir(exist_ok=True)
bins=['0–31','32–127','128–511','512–2,047','2,048–8,191','8,192+','Total']
modes=('default','all')
corpora={'lua':34,'sqlite':1,'musl':1336}
measure={}
for mode in modes:
 per=defaultdict(list)
 for run in range(1,6):
  cat=defaultdict(lambda:[0]*5)
  for group,nobj in corpora.items():
   base,head=[cycles/f'{mode}-{group}-{v}-{run}' for v in ('base','head')]
   for ext in ['.sha','.out','.err']:
    assert base.with_suffix(ext).read_bytes()==head.with_suffix(ext).read_bytes()
   assert len(base.with_suffix('.sha').read_text().splitlines())==nobj
   bs,hs=[[[int(x)for x in l.split()]for l in f.with_suffix('.tsv').read_text().splitlines()]for f in (base,head)]
   assert [x[:2]for x in bs]==[x[:2]for x in hs]
   for (blocks,n,w0,d0),(_,_,w1,d1)in zip(bs,hs):
    assert min(w0,d0,w1,d1)>0 and w0>d0 and w1>d1
    for k in (sum(n>=x for x in [32,128,512,2048,8192]),6):
     a=cat[k];a[0]+=1;a[1]+=w0;a[2]+=w1;a[3]+=d0;a[4]+=d1
  assert cat[6][0]==10124
  for k,(n,b,h,db,dh)in cat.items():per[k].append((n,h/b,dh/db))
 for k,x in per.items():
  assert len({a[0]for a in x})==1 and len(x)==5
  measure[mode,k]=[x[0][0],median(a[1]for a in x),median(a[2]for a in x)]
def pipeline():
 return ['| '+name+' | '+' | '.join(f'{v:,}' if i==0 else f'{v:.4f}' for m in modes for i,v in enumerate(measure[m,k]))+' |'for k,name in enumerate(bins)]
ordinary=[]
for group,n in corpora.items():
 row=[]
 for m in modes:
  base,head=[(r/f'production-objects-{m}-{group}-{v}.sha').read_bytes()for v in ('base','frontier')];assert base==head and len(base.splitlines())==n+2
  s=(r/f'production-compile-{m}-{group}.log').read_text();assert s.rstrip().endswith('ab: done, 0 failed runs')
  ratios=[]
  for part in s.split('time-runs: done, 0 failed processes')[:-1]:
   xs={k:int(x)for k,x in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',part,re.M)}
   ratios.append(xs['head']/xs['base'])
  assert len(ratios)==5;row.append(f'{100*(median(ratios)-1):+.3f}%')
 ordinary.append('| '+group+' | '+str(n)+' | '+' | '.join(row)+' |')
synthetic=[]
for n in (32,128,512,2048,8192,16384):
 values=[]
 for blocks in (1,8):
  for mode in ('dce','all'):
   results=[]
   for v in ('unroll-base','dce-head'):
    s=(r/f'synth-{n}-{blocks}-{mode}-{v}.log').read_text()
    assert 'ir-optimize jump-chain' in s
    t=re.search(r'^ir-optimize large-dag input=(\d+) output=(\d+) blocks=(\d+)/(\d+)[^\n]*\n  ns/function=[^\n]*TSC-ticks/input-instruction=([\d.]+)',s,re.M)
    results.append(t.groups())
   assert results[0][:4]==results[1][:4]
   values.append(float(results[1][4])/float(results[0][4]))
 synthetic.append('| '+str(n)+' | '+' | '.join(f'{v:.4f}'for v in values)+' |')
for seed in (1,133,789):
 assert '0 failures' in (r/f'frozen-{seed}.log').read_text()
assert all('358076 checks, 0 failures' in (r/f'default-{v}.log').read_text() for v in ('dce-shipping','unroll-base'))
text_hash=[s.split()[0]for s in (r/'shipping-text.sha').read_text().splitlines()];assert len(text_hash)==2 and text_hash[0]==text_hash[1]
files=['candidate.patch','shipping.patch','probe.patch','tests','recover-synthetic','trace-matched','matched-corpus','ordinary','ordinary-corpus','verify-shipping','record.py']
with tarfile.open(out/'dce-native.tar.xz','w:xz')as tar:
 for name in files:tar.add(p/name,arcname='source/'+name)
 for f in r.rglob('*'):
  if f.is_file() and f.name!='shipping-default-frozen.log':tar.add(f,arcname='native/'+str(f.relative_to(r)))
(out/'README.md').write_text('''# IR dead-code removal on Zen 5

Sixteen-instruction root classification compresses live instruction numbers directly into the existing worklist. An instruction changes from dead to live once, so roots and newly live operands each enter the linear queue once. The shipping source and the timed source have identical executable text (SHA-256 `'''+text_hash[0]+'''`).

## Real Tier 1 pipelines

The untouched parent is buster14a/buster@cc7d4ffb449c1f57d8d867c2ad2bf6dc6bfebc7f. Clang Release builds ran on CPU 2 of the locked Ryzen 7 9700X. The same probe at each revision brackets the verified optimizer and DCE, using fenced TSC reads. A run measures all 34 Lua, one SQLite and 1,336 musl translation units with one compiler lane and debug information. All five paired rounds presented the same function shapes in the same order and emitted identical objects, stdout and stderr for each mode. Each bin divides summed candidate ticks by summed parent ticks within a round, then takes the median of the five ratios. Counts are per round.

| Input instructions | Default functions | Default pipeline | Default DCE | All-pass functions | All-pass pipeline | All-pass DCE |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(pipeline())+'''

## Full compiler processes

Uninstrumented compilers ran five paired rounds, with three fresh processes per executable in each round. The table gives median paired changes in user cycles. Every debug object, stdout and stderr matched in both configurations.

| Corpus | Objects | Default | All passes |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(ordinary)+'''

## Synthetic optimizer inputs

Each table entry compares the benchmark’s `large-dag` TSC ticks per input instruction, using 11 samples in each process. The block parameter also changes the jump-chain fixture in the raw logs. The emitted graph sizes matched. Small synthetic inputs include timing overhead outside root classification as well as the DCE work. The default-seed optimizer suite passed all 358,076 checks, including its frozen optimize digest `0x292b130a5600b0e5`. Seeds 1, 133 and 789 also passed.

| Requested instructions | 1 block, DCE | 1 block, all | 8 blocks, DCE | 8 blocks, all |
| ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(synthetic)+'''

[Source patches, compiler flags, probes, object and output hashes, raw per-function measurements, synthetic results and correctness logs](dce-native.tar.xz)
''')
print(*pipeline(),*ordinary,*synthetic,sep='\n')
