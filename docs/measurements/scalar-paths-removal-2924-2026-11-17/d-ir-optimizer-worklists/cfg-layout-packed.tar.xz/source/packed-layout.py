from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
p=Path(__file__).parent;f='src/buster/compiler/ir_optimize_layout.c'
s=(p/'proposals-layout.c').read_text();start=s.index('    bool ok = true;');end=s.index('        const __m512i lanes',start)
s=s[:start]+'''    // One scratch allocation holds two link columns, the chosen edge ranks and one visit flag per block.
    // A rank is live only after its source wins an edge. Only the walk flags need zero initialization.
    uint32_t* next = blocks != 0 ? arena_push_array(scratch, blocks, 2 * sizeof(uint32_t) + 2, _Alignof(uint32_t)) : NULL;
    uint32_t* previous = NULL;
    uint8_t* priority = NULL;
    uint8_t* visited = NULL;
    IrError error = blocks != 0 && next == NULL ? IR_ERROR_MEMORY : IR_OK;
    uint32_t kept = 0;
    if (next != NULL)
    {
        previous = next + blocks;
        priority = (uint8_t*)(previous + blocks);
        visited = priority + blocks;
        memset(next, 0xff, (uint64_t)blocks * 2 * sizeof(uint32_t));
        memset(visited, 0, blocks);
'''+s[end:]
(p/'packed-layout.c').write_text(s)
base=check_output(['git','show','cc7d4ffb4:'+f],cwd=p/'tree').decode()
patch=(p/'proposals.patch').read_text().split('--- a/'+f)[0]+''.join(unified_diff(base.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f))
(p/'packed.patch').write_text(patch);(p/'packed-probe.patch').write_bytes((p/'proposals-probe.patch').read_bytes())
for name in ['build-proposals','proposals-tests','proposals-corpus','ordinary-proposals','proposals-matched','proposals-trace']:
 s=(p/name).read_text().replace('proposals','packed')
 if name.startswith('build'):
  s=s.replace('buster-branch-ranks','buster-burs-rules').replace('coldwork-compiler-built.ok','leaves-capture-built.ok').replace('git apply -R "$previous/coldwork.patch"','git apply -R "$previous/capture.patch"\ngit apply -R "$previous/leaves.patch"')
 (p/name.replace('proposals','packed')).write_text(s)
