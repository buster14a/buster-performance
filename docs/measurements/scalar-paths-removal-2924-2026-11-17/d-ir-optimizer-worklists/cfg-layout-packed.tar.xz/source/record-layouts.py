from pathlib import Path
from statistics import median
import tarfile,re
p=Path(__file__).parent;r=p/'results'
def layout(tag):
 s=(p/'record.py').read_text().split('  for seed in [1,133,789]:')[0].replace("'cycles-matched'",repr(tag+'-cycles')).replace("f'production-","f'"+tag+'-')
 scope={'__file__':str(p/'record.py')};exec(s,scope)
 per,whole,out=map(scope.get,['per','whole','out'])
 def parse(f):return {k:(shape,float(v))for k,shape,v in re.findall(r'^ir-optimize (\S+) (input=.*?)\n  ns/function=.*?TSC-ticks/input-instruction=([\d.]+)',f.read_text(),re.M)}
 syn={}
 for f in r.glob(tag+'-synth-*-cfg-'+tag+'.log'):
  base=parse(f.with_name(f.name.replace('cfg-'+tag,'unroll-base')));head=parse(f);assert head and head.keys()==base.keys()
  for k,(shape,v)in head.items():assert shape==base[k][0];syn[f.name,k]=v/base[k][1]
 assert len(syn)==120
 for seed in [139,1,133,789]:assert '0 failures' in (r/f'{tag}-frozen-{seed}.log').read_text()
 desc={'proposals':('Kept blocks and competing layout edges','The builder compresses reachable canonical blocks into their original order. It gathers dominator ranks for up to sixteen candidates and installs each winning outgoing edge immediately. An equal rank keeps the earlier source. Cycle detection visits kept blocks in order.'),'packed':('One allocation for layout links and visit flags','This version allocates the two link columns, the chosen edge ranks and the visit flags together. It sets the absent links and clears the flags once. An edge rank is read only after its source wins an edge.')}[tag]
 rows=[];small=[]
 for k,sz in enumerate(['0–31','32–127','128–511','512–2,047','2,048–8,191','8,192+','Total']):
  for m in ['default','all']:
   vs=[median(x)for x in zip(*per[m,k])];rows.append('| '+sz+' | '+m+' | '+f'{vs[0]:,} | '+' | '.join(f'{x:.4f}'for x in vs[1:])+' |')
   if k!=6:small.append(vs[1:])
 whole_rows=['| '+g+' | '+' | '.join(f'{100*(whole[m,g]-1):+.3f}%'for m in ['default','all'])+' |'for g in ['lua','sqlite','musl']]
 body='## '+desc[0]+'\n\n'+desc[1]+''' Five alternating paired rounds used the same per-function instrumentation on the 9700X. Across 10,124 functions per configuration, each output object, diagnostic stream and sequence of function shapes matched the parent. Each ratio below divides the summed candidate ticks in that bin by the corresponding parent ticks, then takes the median of the pairs.

| Instructions | Passes | Functions | Verified pipeline | CFG cleanup | Target resolution | Layout |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

Ordinary compilers without probes ran five rounds of three processes. Debug objects, diagnostics and stdout matched on all six workloads.

| Corpus | Default passes | All passes |
| --- | ---: | ---: |
'''+'\n'.join(whole_rows)+f'''

The layout improved in {sum(x[3]<=1 for x in small)} of twelve bins, the verified pipeline in {sum(x[0]<=1 for x in small)} of twelve, and the synthetic optimizer in {sum(v<=1 for v in syn.values())} of 120 comparisons. Seed 139 passed 358,076 frozen checks. Three further seeds passed.

[Patch, harnesses, complete compiler samples, per-function ticks and object manifests](cfg-layout-{tag}.tar.xz)
'''
 file=out/'README.md'
 old=file.read_text()
 if '## '+desc[0] in old:raise ValueError(desc[0]+' already present')
 file.write_text(old.rstrip()+'\n\n'+body)
 with tarfile.open(out/f'cfg-layout-{tag}.tar.xz','w:xz',preset=2)as t:
  for n in sorted(p.glob('*')):
   if n.is_file()and (tag in n.name or n.name in ['record-layouts.py','record.py','layout-proposals.py','packed-layout.py']):t.add(n,'source/'+n.name)
  for n in sorted(r.glob(tag+'-*')):t.add(n,'native/'+n.name)
 print(*whole_rows,*[str([sum(x[i]<=1 for x in small)for i in range(4)]),str(sum(v<=1 for v in syn.values())),*rows],sep='\n')
if __name__=='__main__':
 import sys
 layout(sys.argv[1])
