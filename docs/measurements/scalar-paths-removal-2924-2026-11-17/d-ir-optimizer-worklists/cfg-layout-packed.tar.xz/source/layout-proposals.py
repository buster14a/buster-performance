from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent
f='src/buster/compiler/ir_optimize_layout.c'
s=(p/'tree'/f).read_text()
s=s[:s.index('typedef struct IrOptimizeLayoutBatch')]+s[s.index('static IrError ir_optimize_layout_order'):]
s=s.replace('The edges are ranked sixteen at a time from staged columns; target conflicts and chain walks are a scalar consumer.', 'Up to sixteen eligible edges get their ranks from the dominator columns together. Proposals take effect in source order.')
a=s.index('        for (uint32_t block = 0; block < blocks; block += 1)');b=s.index('\n    }',a)
s=s[:a]+'''        const __m512i lanes = _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
        for (uint64_t first = 0; first < blocks; first += BUSTER_IR_OPTIMIZE_BATCH)
        {
            const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, (uint32_t)(blocks - first));
            const __m512i ids = _mm512_add_epi32(lanes, _mm512_set1_epi32((uint32_t)first));
            const __mmask16 live = _mm_mask_cmpneq_epi8_mask(valid, _mm_maskz_loadu_epi8(valid, reachable + first), _mm_setzero_si128());
            const __mmask16 canonical = _mm512_mask_cmpeq_epi32_mask(live, ids, _mm512_maskz_loadu_epi32(live, threads + first));
            _mm512_mask_compressstoreu_epi32(order + kept, canonical, ids);
            kept += (uint32_t)__builtin_popcount(canonical);
        }'''+s[b:]
# BZHI looks only at the bottom 8 bits of its index. Clamp sizes instead of depending on high bits.
s=s.replace('const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, (uint32_t)(blocks - first));','const __mmask16 valid = blocks - first >= 16 ? UINT16_MAX : (__mmask16)_bzhi_u32(UINT16_MAX, (uint32_t)(blocks - first));')
s=s.replace('        IrOptimizeLayoutBatch batch = { .count = count };','        uint32_t targets[BUSTER_IR_OPTIMIZE_BATCH];\n        uint32_t mask = 0;')
a=s.index('                next[block] = target;');b=s.index('\n            }',a)
s=s[:a]+'''                targets[lane] = target;
                mask |= 1u << lane;'''+s[b:]
a=s.index('        uint32_t ranks[');b=s.index('    // Both conditional paths',a)
s=s[:a]+'''        if (mask != 0)
        {
            const __mmask16 active = (__mmask16)mask;
            const __m512i sign = _mm512_set1_epi32(INT32_MIN);
            const __m512i sources = _mm512_maskz_loadu_epi32(active, order + first);
            const __m512i dests = _mm512_maskz_loadu_epi32(active, targets);
            // Sign-extend the rebased index for gather, including block ids above INT32_MAX.
            const void* enter_base = (const void*)((uintptr_t)enter + (UINT64_C(1) << 33));
            const void* leave_base = (const void*)((uintptr_t)leave + (UINT64_C(1) << 33));
            const __m512i from = _mm512_xor_si512(sources, sign);
            const __m512i to = _mm512_xor_si512(dests, sign);
            const __m512i pre = _mm512_mask_i32gather_epi32(_mm512_setzero_si512(), active, from, enter_base, 4);
            const __m512i lower = _mm512_mask_i32gather_epi32(_mm512_setzero_si512(), active, to, enter_base, 4);
            const __m512i upper = _mm512_mask_i32gather_epi32(_mm512_setzero_si512(), active, to, leave_base, 4);
            const uint32_t back = _mm512_cmple_epu32_mask(lower, pre) & _mm512_cmplt_epu32_mask(pre, upper);
            const __mmask16 has_following = first + count == kept ? (__mmask16)(active & ~(1u << (count - 1))) : active;
            const __m512i following = _mm512_maskz_loadu_epi32(has_following, order + (uint64_t)first + 1);
            const uint32_t adjacent = _mm512_mask_cmpeq_epi32_mask(has_following, dests, following);
            // The first equal-rank source wins. Disconnect a displaced source as its replacement is installed.
            while (mask != 0)
            {
                const unsigned lane = (unsigned)__builtin_ctz(mask);
                mask &= mask - 1;
                const uint32_t block = order[first + lane];
                const uint32_t target = targets[lane];
                const uint8_t rank = (uint8_t)(3 + 2 * ((back >> lane) & 1) + ((adjacent >> lane) & 1));
                const uint32_t old = previous[target];
                if (old == BUSTER_IR_NONE || priority[old] < rank)
                {
                    if (old != BUSTER_IR_NONE)
                    {
                        next[old] = BUSTER_IR_NONE;
                    }
                    next[block] = target;
                    previous[target] = block;
                    priority[block] = rank;
                }
            }
        }
        first += count;
    }
'''+s[b:]
s=s.replace('for (uint32_t block = 0; error == IR_OK && block < blocks; block += 1)\n    {\n        if (reachable[block] != 0 && threads[block] == block && visited[block] == 0)', 'for (uint32_t position = 0; error == IR_OK && position < kept; position += 1)\n    {\n        const uint32_t block = order[position];\n        if (visited[block] == 0)')
(p/'proposals-layout.c').write_text(s)
from subprocess import check_output
base=check_output(['git','show','cc7d4ffb4:'+f],cwd=p/'tree').decode()
patch=(p/'closed.patch').read_text().split('--- a/'+f)[0]+''.join(unified_diff(base.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f))
(p/'proposals.patch').write_text(patch)
s=(p/'build-closed').read_text().replace('test -f "$previous/paired-compiler-built.ok"','until [[ -f "$previous/coldwork-compiler-built.ok" ]];do sleep 3;done').replace('pairedranks.patch','coldwork.patch').replace('closed','proposals').replace('bash matched-corpus','bash proposals-matched').replace('--config Release','--config Release --jobs 4')
(p/'build-proposals').write_text(s);(p/'proposals-probe.patch').write_bytes((p/'closed-probe.patch').read_bytes())
for x in ['closed-corpus','closed-matched','closed-trace','closed-tests','ordinary-closed']:
 s=(p/x).read_text().replace('closed','proposals');(p/x.replace('closed','proposals')).write_text(s)
