// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
//
// #1218's block order for Tier 1, included after ir_optimize_single_successor. The optimizer's existing rewrite
// consumes order[new] = old in both its numbering and copying passes; it remains the sole owner of value, target,
// phi and label remapping. Only reachable blocks that survive jump threading enter this order, with entry first.
//
// A linear chain cover prefers a loop's unconditional backedge, then another unconditional edge, over a conditional
// fall-through. Existing physical adjacency breaks ties before the original source id. Conditional edges only join
// free ends/heads. Each node then has at most one predecessor and successor, so cycles can be found in one walk and
// cut at their weakest edge. An ordinary while loop keeps latch -> header and cuts header -> body: its initial jump
// remains, while the latch falls into the test on every iteration. This is a structural heuristic, not a profile.
//
// Up to sixteen eligible edges get their ranks from the dominator columns together. Proposals take effect in source order.
// Each CFG edge and block is read a bounded number of times, with O(blocks + edges) work and 10 bytes/block of
// temporary columns, plus the caller's 4-byte order column. Input/threads are immutable, output order is disjoint,
// and all scratch allocations precede the first output store. Scratch is restored on success and failure.

#ifndef BUSTER_IR_OPTIMIZE_LAYOUT_INCLUDED
#define BUSTER_IR_OPTIMIZE_LAYOUT_INCLUDED

static IrError ir_optimize_layout_order(const IrOptimizeWork* work, const uint32_t* threads, Arena* scratch, uint32_t* order, uint32_t* order_count)
{
    const IrFunction* function = work->function;
    const uint32_t blocks = function->block_count;
    const uint32_t* const offsets = function->block_offsets;
    const uint8_t* const operations = function->op;
    const uint32_t* const true_targets = function->b;
    const uint32_t* const false_targets = function->c;
    const uint32_t* const successor_offsets = work->cfg.successor_offsets;
    const uint32_t* const successors = work->cfg.successors;
    const uint8_t* const edges = work->edges;
    const uint8_t* const reachable = work->blocks;
    const uint32_t* const enter = work->dominators.preorder;
    const uint32_t* const leave = work->dominators.subtree_end;
    const uint64_t mark = scratch->length;
    // One scratch allocation holds two link columns, the chosen edge ranks and one visit flag per block.
    // A rank is live only after its source wins an edge. Only the walk flags need zero initialization.
    uint32_t* next = blocks != 0 ? arena_push_array(scratch, blocks, 2 * sizeof(uint32_t) + 2, _Alignof(uint32_t)) : NULL;
    uint32_t* previous = NULL;
    uint8_t* priority = NULL;
    uint8_t* visited = NULL;
    IrError error = blocks != 0 && next == NULL ? IR_ERROR_MEMORY : IR_OK;
    uint32_t kept = 0;
    if (next != NULL)
    {
        previous = next + blocks;
        priority = (uint8_t*)(previous + blocks);
        visited = priority + blocks;
        memset(next, 0xff, (uint64_t)blocks * 2 * sizeof(uint32_t));
        memset(visited, 0, blocks);
        const __m512i lanes = _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
        for (uint64_t first = 0; first < blocks; first += BUSTER_IR_OPTIMIZE_BATCH)
        {
            const __mmask16 valid = blocks - first >= 16 ? UINT16_MAX : (__mmask16)_bzhi_u32(UINT16_MAX, (uint32_t)(blocks - first));
            const __m512i ids = _mm512_add_epi32(lanes, _mm512_set1_epi32((uint32_t)first));
            const __mmask16 live = _mm_mask_cmpneq_epi8_mask(valid, _mm_maskz_loadu_epi8(valid, reachable + first), _mm_setzero_si128());
            const __mmask16 canonical = _mm512_mask_cmpeq_epi32_mask(live, ids, _mm512_maskz_loadu_epi32(live, threads + first));
            _mm512_mask_compressstoreu_epi32(order + kept, canonical, ids);
            kept += (uint32_t)__builtin_popcount(canonical);
        }
    }
    // Single-successor branches become unconditional in the rewrite. An indirect branch stays opaque even when its
    // target list has one entry. Candidate targets are canonical live blocks and never entry or the source itself.
    for (uint32_t first = 0; error == IR_OK && first < kept;)
    {
        const uint32_t count = kept - first < BUSTER_IR_OPTIMIZE_BATCH ? kept - first : BUSTER_IR_OPTIMIZE_BATCH;
        uint32_t targets[BUSTER_IR_OPTIMIZE_BATCH];
        uint32_t mask = 0;
        for (uint32_t lane = 0; lane < count; lane += 1)
        {
            const uint32_t block = order[first + lane];
            const uint32_t last = offsets[block + 1] - 1;
            const uint32_t op = operations[last];
            uint32_t target = BUSTER_IR_NONE;
            uint32_t live = 0;
            if (op == IR_BR || op == IR_CBR || op == IR_SWITCH)
            {
                for (uint32_t edge = successor_offsets[block]; edge < successor_offsets[block + 1]; edge += 1)
                {
                    if (edges[edge] != 0)
                    {
                        target = threads[successors[edge]];
                        live += 1;
                    }
                }
            }
            const bool candidate = live == 1 && target != 0 && target != block && reachable[target] != 0 && threads[target] == target;
            if (candidate)
            {
                targets[lane] = target;
                mask |= 1u << lane;
            }
        }
        if (mask != 0)
        {
            const __mmask16 active = (__mmask16)mask;
            const __m512i sign = _mm512_set1_epi32(INT32_MIN);
            const __m512i sources = _mm512_maskz_loadu_epi32(active, order + first);
            const __m512i dests = _mm512_maskz_loadu_epi32(active, targets);
            // Sign-extend the rebased index for gather, including block ids above INT32_MAX.
            const void* enter_base = (const void*)((uintptr_t)enter + (UINT64_C(1) << 33));
            const void* leave_base = (const void*)((uintptr_t)leave + (UINT64_C(1) << 33));
            const __m512i from = _mm512_xor_si512(sources, sign);
            const __m512i to = _mm512_xor_si512(dests, sign);
            const __m512i pre = _mm512_mask_i32gather_epi32(_mm512_setzero_si512(), active, from, enter_base, 4);
            const __m512i lower = _mm512_mask_i32gather_epi32(_mm512_setzero_si512(), active, to, enter_base, 4);
            const __m512i upper = _mm512_mask_i32gather_epi32(_mm512_setzero_si512(), active, to, leave_base, 4);
            const uint32_t back = _mm512_cmple_epu32_mask(lower, pre) & _mm512_cmplt_epu32_mask(pre, upper);
            const __mmask16 has_following = first + count == kept ? (__mmask16)(active & ~(1u << (count - 1))) : active;
            const __m512i following = _mm512_maskz_loadu_epi32(has_following, order + (uint64_t)first + 1);
            const uint32_t adjacent = _mm512_mask_cmpeq_epi32_mask(has_following, dests, following);
            // The first equal-rank source wins. Disconnect a displaced source as its replacement is installed.
            while (mask != 0)
            {
                const unsigned lane = (unsigned)__builtin_ctz(mask);
                mask &= mask - 1;
                const uint32_t block = order[first + lane];
                const uint32_t target = targets[lane];
                const uint8_t rank = (uint8_t)(3 + 2 * ((back >> lane) & 1) + ((adjacent >> lane) & 1));
                const uint32_t old = previous[target];
                if (old == BUSTER_IR_NONE || priority[old] < rank)
                {
                    if (old != BUSTER_IR_NONE)
                    {
                        next[old] = BUSTER_IR_NONE;
                    }
                    next[block] = target;
                    previous[target] = block;
                    priority[block] = rank;
                }
            }
        }
        first += count;
    }
    // Both conditional paths remain live here. Preserve the old fall-through where it is available; without profile
    // information, prefer true before false otherwise. Existing direct edges and earlier conditional edges win joins.
    for (uint32_t position = 0; error == IR_OK && position < kept; position += 1)
    {
        const uint32_t block = order[position];
        const uint32_t last = offsets[block + 1] - 1;
        const uint32_t first_edge = successor_offsets[block];
        const uint32_t degree = successor_offsets[block + 1] - first_edge;
        if (operations[last] == IR_CBR && next[block] == BUSTER_IR_NONE && degree == 2 && edges[first_edge] != 0 && edges[first_edge + 1] != 0)
        {
            const uint32_t following = position + 1 < kept ? order[position + 1] : BUSTER_IR_NONE;
            const uint32_t t = threads[true_targets[last]];
            const uint32_t f = threads[false_targets[last]];
            const bool false_first = f == following && t != following;
            const uint32_t targets[] = {
                false_first ? f : t,
                false_first ? t : f,
            };
            for (uint32_t choice = 0; next[block] == BUSTER_IR_NONE && choice < 2; choice += 1)
            {
                const uint32_t target = targets[choice];
                if (target != 0 && target != block && reachable[target] != 0 && threads[target] == target && previous[target] == BUSTER_IR_NONE)
                {
                    next[block] = target;
                    previous[target] = block;
                    priority[block] = (uint8_t)(1 + (target == following));
                }
            }
        }
    }
    // With at most one incoming edge there are only disjoint chains and cycles. A walk either reaches NONE/an earlier
    // walk, or returns to its own start. Cut the least valuable edge; equal ranks start at the lowest target id.
    for (uint32_t position = 0; error == IR_OK && position < kept; position += 1)
    {
        const uint32_t block = order[position];
        if (visited[block] == 0)
        {
            uint32_t current = block;
            uint32_t weakest = BUSTER_IR_NONE;
            while (current != BUSTER_IR_NONE && visited[current] == 0)
            {
                visited[current] = 1;
                const uint32_t target = next[current];
                if (target != BUSTER_IR_NONE && (weakest == BUSTER_IR_NONE || priority[current] < priority[weakest] ||
                    (priority[current] == priority[weakest] && target < next[weakest])))
                {
                    weakest = current;
                }
                current = target;
            }
            if (current == block && weakest != BUSTER_IR_NONE)
            {
                previous[next[weakest]] = BUSTER_IR_NONE;
                next[weakest] = BUSTER_IR_NONE;
            }
        }
    }
    uint32_t placed = 0;
    for (uint32_t block = 0; error == IR_OK && block < blocks; block += 1)
    {
        if (reachable[block] != 0 && threads[block] == block && previous[block] == BUSTER_IR_NONE)
        {
            for (uint32_t current = block; current != BUSTER_IR_NONE; current = next[current])
            {
                order[placed++] = current;
            }
        }
    }
    error = error == IR_OK && placed != kept ? IR_ERROR_STRUCTURE : error;
    if (error == IR_OK)
    {
        *order_count = placed;
    }
    arena_pop_to(scratch, mark);
    return error;
}

#endif
