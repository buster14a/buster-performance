from pathlib import Path
from subprocess import check_output
from difflib import unified_diff
p=Path(__file__).parent;target='src/buster/compiler/ir_optimize_layout.c'
s=(p/'packed-layout.c').read_text()
s=s.replace('    uint32_t kept = 0;', '    uint32_t kept = 0;\n    bool changed_order = false;')
s=s.replace('        memset(visited, 0, blocks);\n','')
s=s.replace('                    priority[block] = rank;','                    priority[block] = rank;\n                    changed_order |= ((adjacent >> lane) & 1) == 0;')
s=s.replace('                    priority[block] = (uint8_t)(1 + (target == following));','                    priority[block] = (uint8_t)(1 + (target == following));\n                    changed_order |= target != following;')
a=s.index('    // With at most one incoming edge')
s=s[:a]+'''    // If every selected edge follows the next kept block, the compressed input order already satisfies the chain cover.
    // A displaced nonadjacent proposal can make this conservative. It cannot hide a reordered edge.
    if (!changed_order && error == IR_OK)
    {
        *order_count = kept;
        arena_pop_to(scratch, mark);
        return IR_OK;
    }
    if (visited != NULL)
    {
        memset(visited, 0, blocks);
    }
'''+s[a:]
(p/'adjacent-layout.c').write_text(s)
old=check_output(['git','show','cc7d4ffb4:'+target],cwd=p/'tree').decode()
patch=(p/'packed.patch').read_text().split('--- a/'+target)[0]+''.join(unified_diff(old.splitlines(True),s.splitlines(True),'a/'+target,'b/'+target))
(p/'adjacent.patch').write_text(patch);(p/'adjacent-probe.patch').write_bytes((p/'packed-probe.patch').read_bytes())
for name in ['build-packed','packed-tests','packed-trace','ordinary-packed','packed-corpus','input-packed-matched']:
 s=(p/name).read_text().replace('packed','adjacent')
 if name=='build-packed':
  a=s.index('previous=');b=s.index('git diff --exit-code -- src',a)
  s=s[:a]+'''until [[ -f /dev/shm/buster-flagged-declarations-6b097f86/cast-built.ok ]];do sleep 2;done
cd "$ir/src"
'''+s[b:]
  for suffix,image in [('', 'cfg-adjacent'),('-probe','cfg-adjacent-probe')]:
   s=s.replace('ln -L build/compiler build/'+image+'\n',f'''cp --preserve=mode build/compiler /tmp/buster-selector-images-6b097f86/{image}
cmp build/compiler /tmp/buster-selector-images-6b097f86/{image}
ln -s /tmp/buster-selector-images-6b097f86/{image} build/{image}
''')
  s=s.replace('cd "$root"\nbash adjacent-matched','''git apply -R "$root/adjacent-probe.patch"
git apply -R "$root/adjacent.patch"
git diff --exit-code -- src
touch "$root/adjacent-builds-clean.ok"''')
 if name=='packed-tests':s=s.replace('"$root"/synth*.log','"$root"/adjacent-synth-*.log')
 (p/name.replace('packed','adjacent')).write_text(s)
