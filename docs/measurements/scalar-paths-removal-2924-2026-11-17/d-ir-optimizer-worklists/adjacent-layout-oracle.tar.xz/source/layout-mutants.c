#define _GNU_SOURCE
#include "buster/compiler/tier1_select_benchmark.c"
#define BUSTER_IR_OPTIMIZE_BATCH 16
typedef struct
{
    const IrFunction* function;
    IrCfg cfg;
    Dominators dominators;
    uint8_t *edges, *blocks;
} IrOptimizeWork;
#define ir_optimize_layout_order parent_layout
#include "parent-layout.c"
#undef ir_optimize_layout_order
#undef BUSTER_IR_OPTIMIZE_LAYOUT_INCLUDED
#define ir_optimize_layout_order current_layout
#include "adjacent-layout.c"
#undef ir_optimize_layout_order

#undef BUSTER_IR_OPTIMIZE_LAYOUT_INCLUDED
#define ir_optimize_layout_order no_direct
#include "no-direct.inc"
#undef ir_optimize_layout_order
#undef BUSTER_IR_OPTIMIZE_LAYOUT_INCLUDED
#define ir_optimize_layout_order no_conditional
#include "no-conditional.inc"
#undef ir_optimize_layout_order
static IrError (*layout)(const IrOptimizeWork*,const uint32_t*,Arena*,uint32_t*,uint32_t*);
enum { MAX_BLOCKS = 513, POISON = 0x673af124 };
typedef struct
{
    uint32_t next;
    uint32_t offset[MAX_BLOCKS+1], start[MAX_BLOCKS+1], successors[2*MAX_BLOCKS];
    uint32_t threads[MAX_BLOCKS], enter[MAX_BLOCKS], leave[MAX_BLOCKS], yes[MAX_BLOCKS], no[MAX_BLOCKS];
    uint8_t ops[MAX_BLOCKS], active[2*MAX_BLOCKS], reachable[MAX_BLOCKS];
} Graph;

static uint32_t random_value(Graph* g)
{
    uint32_t x=g->next;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    return g->next=x;
}

static void make_graph(Graph* g, uint32_t n, unsigned shape, uint32_t seed)
{
    g->next=seed+1;
    uint32_t edges=0;
    for (uint32_t i=0; i<n; ++i)
    {
        g->offset[i]=i;
        g->start[i]=edges;
        g->reachable[i]=1;
        g->threads[i]=i;
        if (shape>=4 && i && (random_value(g)&7)==0) g->reachable[i]=0;
        if (shape>=4 && i && (random_value(g)&15)==0) g->threads[i]=0;
        g->enter[i]=i;
        // Chains, stars and groups of sibling chains give several valid tree-interval relationships.
        g->leave[i]=(i==0 || shape%3==0) ? n : shape%3==1 ? i+1 : ((i/8+1)*8>n?n:(i/8+1)*8);
        const uint32_t adjacent=(i+1)%n;
        unsigned degree;
        if (shape==0) degree=i+1<n;
        else if (shape==1 || shape==2) degree=1;
        else if (shape==3) degree=2;
        else degree=random_value(g)%3;
        g->ops[i]=degree==0 ? IR_RET : degree==1 ? IR_BR : IR_CBR;
        if (shape>=4 && degree && random_value(g)%9==0) g->ops[i]=IR_SWITCH;
        if (shape>=4 && degree && random_value(g)%13==0) g->ops[i]=IR_BR_INDIRECT;
        g->yes[i]=g->no[i]=0;
        for (unsigned j=0;j<degree;++j)
        {
            uint32_t target=shape==0 ? adjacent : shape==1 ? (i+2)%n : shape==2 ? n-1 : shape==3 && j ? adjacent : random_value(g)%n;
            if (shape==5 && !j) target=adjacent;
            g->active[edges]=shape<4 || !!(random_value(g)&3);
            g->successors[edges++]=target;
            if (j) g->no[i]=target; else g->yes[i]=target;
        }
    }
    g->start[n]=edges; g->offset[n]=n;
}

static bool compare(Graph* g, uint32_t n, Arena* arena, bool tiny, const uint32_t* expected)
{
    IrFunction f={.block_count=n,.op=g->ops,.block_offsets=g->offset,.b=g->yes,.c=g->no};
    IrOptimizeWork work={.function=&f,.cfg={.successor_offsets=g->start,.successors=g->successors},
                         .dominators={.preorder=g->enter,.subtree_end=g->leave},.edges=g->active,.blocks=g->reachable};
    uint32_t count[2]={POISON,POISON},out[2][MAX_BLOCKS+2];
    IrError results[2];
    const uint64_t cap=arena->capacity,mark=arena->length;
    if (tiny) arena->capacity=mark;
    for (unsigned j=0;j<2;++j)
    {
        for (uint32_t i=0;i<n+2;++i) out[j][i]=POISON;
        results[j]=(j?layout:parent_layout)(&work,g->threads,arena,out[j]+1,&count[j]);
        if (arena->length!=mark || out[j][0]!=POISON || out[j][n+1]!=POISON) return false;
    }
    arena->capacity=cap;
    if (results[0]!=results[1] || count[0]!=count[1] || memcmp(out[0],out[1],(n+2)*sizeof(uint32_t))) return false;
    if (tiny && n) return results[0]==IR_ERROR_MEMORY && count[0]==POISON && (n==0 || out[0][1]==POISON);
    if (results[0]!=IR_OK || count[0]>n || (n && out[0][1]!=0)) return false;
    bool seen[MAX_BLOCKS]={0};
    for (uint32_t i=0;i<count[0];++i)
    {
        const uint32_t b=out[0][1+i];
        if (b>=n || seen[b] || (expected && b!=expected[i])) return false;
        seen[b]=true;
    }
    for (uint32_t i=0;i<n;++i) if (seen[i] != (g->reachable[i] && g->threads[i]==i)) return false;
    return true;
}

int main(int argc,char** argv)
{
    if (argc!=2) return 2;
    layout=strcmp(argv[1],"control")==0?current_layout:strcmp(argv[1],"direct")==0?no_direct:strcmp(argv[1],"conditional")==0?no_conditional:NULL;
    if (!layout) return 2;
    Arena arena=arena_reserve(1u<<20);arena_push_array(&arena,7,1,1);
    Graph g={0};
    const uint32_t hand[]={0,2,1};
    for (unsigned conditional=0;conditional<2;++conditional)
    {
        make_graph(&g,3,0,0);
        g.start[0]=0;g.start[1]=g.start[2]=g.start[3]=1+conditional;g.ops[0]=conditional?IR_CBR:IR_BR;
        g.ops[1]=g.ops[2]=IR_RET;g.yes[0]=2;g.no[0]=0;g.successors[0]=2;g.successors[1]=0;g.active[0]=g.active[1]=1;
        if (!compare(&g,3,&arena,false,hand)) { fprintf(stderr,"hand fixture %u failed\n",conditional);return 1; }
    }
    unsigned comparisons=0;
    for (unsigned ix=0;ix<=73;++ix)
    {
        static const uint32_t large[]={127,128,129,255,256,257,511,512,513};
        const uint32_t n=ix<65 ? ix : large[ix-65];
        for (unsigned shape=0;shape<8;++shape) for (unsigned seed=0;seed<32;++seed)
        {
            make_graph(&g,n,shape,seed);
            if (!compare(&g,n,&arena,false,NULL) || !compare(&g,n,&arena,true,NULL))
            { fprintf(stderr,"mismatch blocks=%u shape=%u seed=%u\n",n,shape,seed);return 1; }
            comparisons+=2;
        }
    }
    printf("2 hand-checked layouts and %u success/failure comparisons across 74 block counts passed\n",comparisons);
    arena_release(&arena);return 0;
}
