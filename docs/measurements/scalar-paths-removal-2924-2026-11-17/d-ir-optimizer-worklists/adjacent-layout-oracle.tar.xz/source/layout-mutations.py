from pathlib import Path
p=Path(__file__).parent
src=(p/'adjacent-layout.c').read_text()
prefix=''
for name,line in [('direct','changed_order |= ((adjacent >> lane) & 1) == 0;'),('conditional','changed_order |= target != following;')]:
 assert src.count(line)==1
 (p/f'no-{name}.inc').write_text(src.replace(line,'(void)changed_order;'))
 prefix+=f'#undef BUSTER_IR_OPTIMIZE_LAYOUT_INCLUDED\n#define ir_optimize_layout_order no_{name}\n#include "no-{name}.inc"\n#undef ir_optimize_layout_order\n'
s=(p/'layout-oracle.c').read_text()
i=s.index('enum { MAX_BLOCKS')
s=s[:i]+prefix+'static IrError (*layout)(const IrOptimizeWork*,const uint32_t*,Arena*,uint32_t*,uint32_t*);\n'+s[i:]
s=s.replace('(j?current_layout:parent_layout)','(j?layout:parent_layout)').replace('int main(void)\n{','int main(int argc,char** argv)\n{\n    if (argc!=2) return 2;\n    layout=strcmp(argv[1],"control")==0?current_layout:strcmp(argv[1],"direct")==0?no_direct:strcmp(argv[1],"conditional")==0?no_conditional:NULL;\n    if (!layout) return 2;')
(p/'layout-mutants.c').write_text(s)
