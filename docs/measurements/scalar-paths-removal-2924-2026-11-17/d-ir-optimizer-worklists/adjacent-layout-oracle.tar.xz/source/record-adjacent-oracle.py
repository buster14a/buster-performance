from pathlib import Path
import re,tarfile
p=Path(__file__).parent;r=p/'results'
scope={'__file__':str(p/'record.py')}
exec((p/'record.py').read_text().split('def ')[0],scope)
out=scope['out'];doc=out/'README.md'
for n,expected in [('control',0),('direct',1),('conditional',1)]:
 assert int((r/f'layout-oracle-{n}.status').read_text())==expected
 log=(r/f'layout-oracle-{n}.log').read_text()
 assert (('37888 success/failure comparisons across 74 block counts passed' if n=='control' else ('hand fixture 0 failed' if n=='direct' else 'hand fixture 1 failed')) in log)
with tarfile.open(out/'adjacent-layout-oracle.tar.xz','w:xz',preset=2)as t:
 for n in ['parent-layout.c','packed-layout.c','adjacent-layout.c','adjacent-layout.py','adjacent.patch','layout-oracle.c','layout-mutations.py','layout-mutants.c','no-direct.inc','no-conditional.inc','check-layout-oracle','record-adjacent-oracle.py']:t.add(p/n,'source/'+n)
 for fn in sorted(r.glob('layout-oracle-*')):t.add(fn,'native/'+fn.name)
heading='## Exact block order when every selected edge is already adjacent'
body='''
A layout candidate keeps the original order when every selected edge connects consecutive retained blocks. The native comparison called the parent and candidate with identical inputs. It compared the complete order, retained count, error, scratch mark and output canaries. It also independently checked that each reachable, unthreaded block was present once and entry came first.

The locked 9700X passed 37,888 comparisons across 74 block counts from zero through 513. The inputs included holes in the retained block list, competing predecessors, cycles, indirect branches, conditional alternatives and exhausted scratch arenas. Two hand-written three-block graphs checked the expected order 0, 2, 1. Disabling the nonadjacent-edge flag for an unconditional edge failed the first graph. Disabling it for a conditional edge failed the second.

[Compared source, fixed and generated graphs, injected errors and native results](adjacent-layout-oracle.tar.xz)
'''
assert heading not in doc.read_text()
with doc.open('a')as f:f.write('\n'+heading+'\n'+body)
