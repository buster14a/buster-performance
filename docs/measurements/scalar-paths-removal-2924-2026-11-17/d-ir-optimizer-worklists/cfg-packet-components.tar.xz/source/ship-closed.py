from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
import re
p=Path(__file__).parent;d=p/'tree';f='src/buster/compiler/ir_optimize.c';base=check_output(['git','show','cc7d4ffb4:'+f],cwd=d).decode();v=(p/'closedwalk.inc').read_text();a=v.index('static inline __m512i');b=v.index('static __attribute__',a)
v=v[:a]+'''static __m512i ir_optimize_closed_targets(__m512i ids, __m512i successors, __m512i first)
{
    __m512i least = _mm512_min_epu32(ids, successors);
    __m512i step = successors;
    for (unsigned round = 0; round < 4; round += 1)
    {
        const __m512i index = _mm512_sub_epi32(step, first);
        least = _mm512_min_epu32(least, _mm512_permutexvar_epi32(index, least));
        step = _mm512_permutexvar_epi32(index, step);
    }
    return _mm512_permutexvar_epi32(_mm512_sub_epi32(step, first), least);
}

'''+v[b:]
v=v.replace('            __m512i next, minimum;\n','').replace('ir_cfg_packet_paths(_mm512_add_epi32(start, lanes), successors, valid, start, true, &next, &minimum)','ir_optimize_closed_targets(_mm512_add_epi32(start, lanes), successors, start)')
v=v.replace('const bool reverse = (uintptr_t)targets > (uintptr_t)direct;', '''// Resolve packets in memmove order. A shifted output can overlap another packet's input.
        const bool reverse = (uintptr_t)targets > (uintptr_t)direct;''')
v=v.replace('if (remote)','if (remote != 0)').replace('for (uint64_t i = 0; i < packets; ++i)','for (uint64_t i = 0; i < packets; i += 1)')
v=v.replace('    bool unresolved = false;', '    const void* gather_origin = (const void*)((uintptr_t)direct + (UINT64_C(1) << 33));\n    bool unresolved = false;')
v=re.sub(r'^\s*const void\* origin = \(const void\*\)\(\(uintptr_t\)direct \+ \(UINT64_C\(1\) << 33\)\);\n','\n',v,flags=re.M).replace('indices, origin,','indices, gather_origin,')
v=re.sub(r'^([ ]*)if (\(.+\)) (return (?:true|false);|continue;|representative = other;)$',lambda x:x[1]+'if '+x[2]+'\n'+x[1]+'{\n'+x[1]+'    '+x[3]+'\n'+x[1]+'}',v,flags=re.M)
v=v.replace('    bool unresolved = false;\n    bool all_local = true;','''    bool unresolved = false;
    bool all_local = true;''')
a=base.index('static __attribute__((unused, aligned(64))) bool ir_optimize_thread_targets(');b=base.index('static bool ir_optimize_equal(',a)
comment=base[base.rindex('// direct[b]',0,a):a]
x=v.index('static __attribute__');v=v[:x]+comment+v[x:]
full=base[:base.rindex('// direct[b]',0,a)]+v+'\n'+base[b:]
(p/'shipping-closed.c').write_text(full);out=list(unified_diff(base.splitlines(True),full.splitlines(True),'a/'+f,'b/'+f))
f='src/buster/compiler/ir_optimize_layout.c';b=check_output(['git','show','cc7d4ffb4:'+f],cwd=d).decode();h=(d/f).read_text();out.extend(unified_diff(b.splitlines(True),h.splitlines(True),'a/'+f,'b/'+f));(p/'closed.patch').write_text(''.join(out))
a=(p/'build-head').read_text();a=a.replace('test -f "$root/base-probe.ok"','previous=/dev/shm/buster-branch-ranks-6b097f86\ntest -f "$previous/paired-compiler-built.ok"').replace('git apply -R "$root/base-probe.patch"','git apply -R "$previous/pairedranks.patch"').replace('root/candidate.patch','root/closed.patch').replace('build/cfg-head','build/cfg-closed').replace('root/head-','root/closed-').replace('root/build-head','root/build-closed')
# Regenerate the exact instrumentation difference for a method with an additional helper above the measurement.
a=a.replace('root/closed-probe.patch','root/closed-probe.patch')
(p/'build-closed').write_text(a)
f='src/buster/compiler/ir_optimize.c';probe=(p/'head-probe.patch').read_text()
# The assertions in git apply require the context immediately above the function. Generate against the shipping source.
tool=(p/'instrument.py').read_text().replace("s=subprocess.check_output(['git','show','HEAD:'+f],cwd=repo).decode() if tag=='base' else (repo/f).read_text()","s=(p/'shipping-closed.c').read_text() if name=='ir_optimize.c' else (repo/f).read_text()")
(p/'instrument-closed.py').write_text(tool)
for a,b in [('ordinary','ordinary-closed'),('ordinary-corpus','closed-corpus'),('matched-corpus','closed-matched'),('trace-matched','closed-trace'),('tests','closed-tests')]:
 s=(p/a).read_text().replace('cfg-head','cfg-closed').replace('head-built.ok','closed-built.ok').replace('ordinary-corpus','closed-corpus').replace('production-','closed-').replace('/object-tmp','/closed-object-tmp').replace('trace-matched','closed-trace').replace('cycles-matched','closed-cycles').replace('corpus.ok','closed-corpus.ok').replace('ordinary.ok','closed-ordinary.ok').replace('synthetic.ok','closed-synthetic.ok').replace('frozen-','closed-frozen-').replace('frozen.ok','closed-frozen.ok').replace('synth-','closed-synth-')
 if a=='trace-matched':s=s.replace('exe="/dev/shm/buster-unroll-6b097f86/src/build/cfg-$build-probe"','exe="/dev/shm/buster-unroll-6b097f86/src/build/cfg-base-probe"\nif [[ $build == head ]];then exe="/dev/shm/buster-unroll-6b097f86/src/build/cfg-closed-probe";fi')
 if a=='matched-corpus':s=s.replace('cd "$root";mkdir','until [[ -f "$root/closed-probe.ok" ]];do sleep 3;done\ncd "$root";mkdir')
 if a=='ordinary':s=s.replace('cd /dev/shm','cd /dev/shm');s=s.replace('for mode','until [[ -f closed-built.ok ]];do sleep 3;done\nfor mode',1)
 (p/b).write_text(s)
