// After four doublings, an orbit either left the packet or reached a local cycle.
// The next sixteen vertices from that cycle entry contain every member of the cycle.
static inline __m512i ir_cfg_packet_paths(__m512i ids, __m512i successors, __mmask16 valid, __m512i first,
                                          bool closed, __m512i* outside, __m512i* path_minimum)
{
    const __m512i packet_ids = _mm512_mask_mov_epi32(_mm512_set1_epi32(-1), valid, ids);
    __m512i least = _mm512_min_epu32(ids, successors);
    __m512i step = successors;
    for (unsigned round = 0; round < 4; ++round)
    {
        const __m512i index = _mm512_sub_epi32(step, first);
        const __mmask16 local = closed ? UINT16_MAX : _mm512_cmpeq_epi32_mask(step, _mm512_permutexvar_epi32(index, packet_ids));
        least = _mm512_mask_min_epu32(least, local, least, _mm512_permutexvar_epi32(index, least));
        step = _mm512_mask_permutexvar_epi32(step, local, index, step);
    }
    const __m512i index = _mm512_sub_epi32(step, first);
    const __mmask16 local = closed ? UINT16_MAX : _mm512_cmpeq_epi32_mask(step, _mm512_permutexvar_epi32(index, packet_ids));
    *outside = step;
    *path_minimum = least;
    return _mm512_mask_permutexvar_epi32(_mm512_set1_epi32(-1), local, index, least);
}

static __attribute__((unused, aligned(64))) bool ir_optimize_thread_targets(Arena* scratch, const uint32_t* direct, uint32_t count, uint32_t* targets)
{
    if (count == 0) return true;
    if (direct == NULL || targets == NULL) return false;
    const __m512i lanes = _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
    bool unresolved = false;
    bool all_local = true;
    const uint32_t head = ((uintptr_t)direct & 63) / sizeof(uint32_t);
    const uintptr_t aligned = (uintptr_t)direct & ~(uintptr_t)63;
    for (int64_t first = -(int64_t)head; first < count; first += 16)
    {
        const uint64_t remaining = (int64_t)count - first;
        const uint32_t end = remaining < 16 ? (uint32_t)remaining : 16;
        const __mmask16 valid = (__mmask16)(_bzhi_u32(UINT16_MAX, end) & (first < 0 ? UINT16_MAX << head : UINT16_MAX));
        const uintptr_t address = aligned + (first + head) * sizeof(uint32_t);
        const __m512i successors = _mm512_maskz_load_epi32(valid, (const void*)address);
        if (_mm512_mask_cmpge_epu32_mask(valid, successors, _mm512_set1_epi32((int32_t)count)) != 0) return false;
        const __m512i ids = _mm512_add_epi32(_mm512_set1_epi32((int32_t)first), lanes);
        const __mmask16 moved = _mm512_mask_cmpneq_epi32_mask(valid, successors, ids);
        if (moved != 0 && (!unresolved || all_local))
        {
            const __m512i local = _mm512_sub_epi32(successors, _mm512_set1_epi32((int32_t)first));
            __m512i following = _mm512_permutexvar_epi32(local, successors);
            const __m512i packet_ids = _mm512_mask_mov_epi32(_mm512_set1_epi32(-1), valid, ids);
            const __mmask16 remote = _mm512_mask_cmpneq_epi32_mask(moved, successors, _mm512_permutexvar_epi32(local, packet_ids));
            all_local &= remote == 0;
            if (unresolved) continue;
            if (remote)
            {
                const void* origin = (const void*)((uintptr_t)direct + (UINT64_C(1) << 33));
                const __m512i indices = _mm512_xor_si512(successors, _mm512_set1_epi32(INT32_MIN));
                following = _mm512_mask_i32gather_epi32(following, remote, indices, origin, sizeof(uint32_t));
            }
            unresolved = _mm512_mask_cmpneq_epi32_mask(moved, following, successors) != 0;
        }
    }
    if (!unresolved)
    {
        memmove(targets, direct, (uint64_t)count * sizeof(uint32_t));
        return true;
    }
    if (all_local)
    {
        const uint64_t packets = ((uint64_t)head + count + 15) / 16;
        const bool reverse = (uintptr_t)targets > (uintptr_t)direct;
        for (uint64_t i = 0; i < packets; ++i)
        {
            const uint64_t k = reverse ? packets - 1 - i : i;
            const int64_t first = (int64_t)(k * 16) - head;
            const uint64_t left = (int64_t)count - first;
            const __mmask16 valid = (__mmask16)(_bzhi_u32(UINT16_MAX, left < 16 ? (uint32_t)left : 16) & (k == 0 ? UINT16_MAX << head : UINT16_MAX));
            const __m512i start = _mm512_set1_epi32((int32_t)first);
            const __m512i successors = _mm512_maskz_load_epi32(valid, (const void*)(aligned + 64 * k));
            __m512i next, minimum;
            const __m512i resolved = ir_cfg_packet_paths(_mm512_add_epi32(start, lanes), successors, valid, start, true, &next, &minimum);
            _mm512_mask_storeu_epi32((void*)((uintptr_t)targets + (uintptr_t)first * sizeof(uint32_t)), valid, resolved);
        }
        return true;
    }
    const uint64_t saved = scratch->length;
    uint32_t* current = arena_push_array(scratch, count, sizeof(uint32_t), _Alignof(uint32_t));
    if (current == NULL) return false;
    for (uint64_t first = 0; first < count; first += 16)
    {
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, count - first < 16 ? (uint32_t)(count - first) : 16);
        const __m512i successors = _mm512_maskz_loadu_epi32(valid, direct + first);
        const void* origin = (const void*)((uintptr_t)direct + (UINT64_C(1) << 33));
        const __m512i indices = _mm512_xor_si512(successors, _mm512_set1_epi32(INT32_MIN));
        const __m512i following = _mm512_mask_i32gather_epi32(successors, valid, indices, origin, sizeof(uint32_t));
        const __mmask16 ready = _mm512_cmpeq_epi32_mask(following, successors);
        _mm512_mask_storeu_epi32(current + first, valid, _mm512_mask_mov_epi32(_mm512_set1_epi32(-1), ready, successors));
    }
    for (uint64_t first = 0; first < count; first += 16)
    {
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, count - first < 16 ? (uint32_t)(count - first) : 16);
        const __m512i known = _mm512_maskz_loadu_epi32(valid, current + first);
        uint32_t pending = _mm512_mask_cmpeq_epi32_mask(valid, known, _mm512_set1_epi32(-1));
        while (pending != 0)
        {
            const uint32_t block = (uint32_t)first + (uint32_t)__builtin_ctz(pending);
            pending &= pending - 1;
            // A previous component walk in this packet may have resolved this block.
            if (current[block] != UINT32_MAX) continue;
            const uint32_t successor = direct[block];
            if (current[successor] != UINT32_MAX)
            {
                current[block] = current[successor];
                continue;
            }
            // The start is unresolved, so it cannot already name a finished representative.
            // Its own ID is a unique temporary mark for all vertices visited by this walk.
            uint32_t node = block;
            uint32_t length = 0;
            do
            {
                current[node] = block;
                length += 1;
                node = direct[node];
            } while (current[node] == UINT32_MAX);
            uint32_t representative = current[node];
            if (representative == block)
            {
                representative = node;
                for (uint32_t other = direct[node]; other != node; other = direct[other])
                {
                    if (other < representative) representative = other;
                }
            }
            node = block;
            for (uint32_t i = 0; i < length; i += 1)
            {
                current[node] = representative;
                node = direct[node];
            }
        }
    }
    memcpy(targets, current, (uint64_t)count * sizeof(uint32_t));
    arena_pop_to(scratch, saved);
    return true;
}
