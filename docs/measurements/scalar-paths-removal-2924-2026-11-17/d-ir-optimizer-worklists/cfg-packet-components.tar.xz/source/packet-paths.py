from pathlib import Path
p=Path(__file__).parent;s=(p/'registers.inc').read_text()
s=s.replace('    bool unresolved = false;','    bool unresolved = false;\n    bool all_local = true;')
s=s.replace('if (moved != 0 && !unresolved)','if (moved != 0 && (!unresolved || all_local))')
s=s.replace('const __mmask16 remote = _mm512_mask_cmpge_epu32_mask(moved, local, _mm512_set1_epi32(16));','''const __m512i packet_ids = _mm512_mask_mov_epi32(_mm512_set1_epi32(-1), valid, ids);
            const __mmask16 remote = _mm512_mask_cmpneq_epi32_mask(moved, successors, _mm512_permutexvar_epi32(local, packet_ids));
            all_local &= remote == 0;
            if (unresolved) continue;''')
helper='''// After four doublings, an orbit either left the packet or reached a local cycle.
// The next sixteen vertices from that cycle entry contain every member of the cycle.
static inline __m512i ir_cfg_packet_paths(__m512i ids, __m512i successors, __mmask16 valid, __m512i first,
                                          bool closed, __m512i* outside, __m512i* path_minimum)
{
    const __m512i packet_ids = _mm512_mask_mov_epi32(_mm512_set1_epi32(-1), valid, ids);
    __m512i least = _mm512_min_epu32(ids, successors);
    __m512i step = successors;
    for (unsigned round = 0; round < 4; ++round)
    {
        const __m512i index = _mm512_sub_epi32(step, first);
        const __mmask16 local = closed ? UINT16_MAX : _mm512_cmpeq_epi32_mask(step, _mm512_permutexvar_epi32(index, packet_ids));
        least = _mm512_mask_min_epu32(least, local, least, _mm512_permutexvar_epi32(index, least));
        step = _mm512_mask_permutexvar_epi32(step, local, index, step);
    }
    const __m512i index = _mm512_sub_epi32(step, first);
    const __mmask16 local = closed ? UINT16_MAX : _mm512_cmpeq_epi32_mask(step, _mm512_permutexvar_epi32(index, packet_ids));
    *outside = step;
    *path_minimum = least;
    return _mm512_mask_permutexvar_epi32(_mm512_set1_epi32(-1), local, index, least);
}

'''
closed='''    if (all_local)
    {
        const uint64_t packets = ((uint64_t)head + count + 15) / 16;
        const bool reverse = (uintptr_t)targets > (uintptr_t)direct;
        for (uint64_t i = 0; i < packets; ++i)
        {
            const uint64_t k = reverse ? packets - 1 - i : i;
            const int64_t first = (int64_t)(k * 16) - head;
            const uint64_t left = (int64_t)count - first;
            const __mmask16 valid = (__mmask16)(_bzhi_u32(UINT16_MAX, left < 16 ? (uint32_t)left : 16) & (k == 0 ? UINT16_MAX << head : UINT16_MAX));
            const __m512i start = _mm512_set1_epi32((int32_t)first);
            const __m512i successors = _mm512_maskz_load_epi32(valid, (const void*)(aligned + 64 * k));
            __m512i next, minimum;
            const __m512i resolved = ir_cfg_packet_paths(_mm512_add_epi32(start, lanes), successors, valid, start, true, &next, &minimum);
            _mm512_mask_storeu_epi32((void*)((uintptr_t)targets + (uintptr_t)first * sizeof(uint32_t)), valid, resolved);
        }
        return true;
    }
'''
s=helper+s;s=s.replace('    const uint64_t saved =',closed+'    const uint64_t saved =')
for name in ['closedwalk','compresswalk','compressstack','mixedpaths']:
 v=s
 if name!='closedwalk':
  a=v.index('    uint32_t* current =');b=v.index('    for (uint64_t first',v.index('        _mm512_mask_storeu_epi32(current',a))
  scratch='4'if name=='compressstack'else'3'
  t='''    uint32_t* current = arena_push_array(scratch, count, NUM * sizeof(uint32_t), _Alignof(uint32_t));
    if (current == NULL) return false;
    uint32_t* jump = current + count;
    uint32_t* path_min = jump + count;
'''.replace('NUM',scratch)
  if name=='compressstack':t+='    uint32_t* path = path_min + count;\n'
  t+='''    for (int64_t first = -(int64_t)head; first < count; first += 16)
    {
        const uint64_t left = (int64_t)count - first;
        const __mmask16 valid = (__mmask16)(_bzhi_u32(UINT16_MAX, left < 16 ? (uint32_t)left : 16) & (first < 0 ? UINT16_MAX << head : UINT16_MAX));
        const __m512i start = _mm512_set1_epi32((int32_t)first);
        const __m512i ids = _mm512_add_epi32(start, lanes);
        const __m512i successors = _mm512_maskz_load_epi32(valid, (const void*)(aligned + (first + head) * sizeof(uint32_t)));
        __m512i next, minimum;
        const __m512i resolved = ir_cfg_packet_paths(ids, successors, valid, start, false, &next, &minimum);
        const uintptr_t offset = (uintptr_t)first * sizeof(uint32_t);
        _mm512_mask_storeu_epi32((void*)((uintptr_t)current + offset), valid, resolved);
        _mm512_mask_storeu_epi32((void*)((uintptr_t)jump + offset), valid, next);
        _mm512_mask_storeu_epi32((void*)((uintptr_t)path_min + offset), valid, minimum);
    }
'''
  v=v[:a]+t+v[b:];a=v.index('    for (uint64_t first',a+len(t));f=v[a:].replace('direct[','jump[').replace('representative = node;','representative = path_min[node];').replace('if (other < representative) representative = other;','if (path_min[other] < representative) representative = path_min[other];');v=v[:a]+f
  if name=='compressstack':
   v=v.replace('                length += 1;','                path[length++] = node;').replace('                current[node] = representative;\n                node = jump[node];','                current[path[i]] = representative;')
  if name=='mixedpaths':
   v=v.replace('        const __m512i resolved = ir_cfg_packet_paths(ids, successors, valid, start, false, &next, &minimum);','''        __m512i resolved;
        const __mmask16 moved = _mm512_mask_cmpneq_epi32_mask(valid, ids, successors);
        if (moved == 0)
        {
            resolved = next = minimum = successors;
        }
        else
        {
            resolved = ir_cfg_packet_paths(ids, successors, valid, start, false, &next, &minimum);
        }''')
 if name!='closedwalk':
  # An interior vertex may be the minimum of an already resolved coarsened cycle before its own slot is visited.
  v=v.replace('valid, next);','valid, _mm512_mask_mov_epi32(_mm512_set1_epi32(-1), _mm512_cmpeq_epi32_mask(resolved, _mm512_set1_epi32(-1)), next));')
  v=v.replace('current[block] = current[successor];','current[block] = current[successor];\n                jump[block] = UINT32_MAX;')
  v=v.replace('if (representative == block)','if (representative == block && jump[node] != UINT32_MAX)')
  v=v.replace('                current[node] = representative;\n                node = jump[node];','                const uint32_t next = jump[node];\n                current[node] = representative;\n                jump[node] = UINT32_MAX;\n                node = next;')
  v=v.replace('current[path[i]] = representative;','current[path[i]] = representative;\n                jump[path[i]] = UINT32_MAX;')
 (p/(name+'.inc')).write_text(v)
for src,dest in [('orbits.c','path-orbits.c'),('replay-graphs.c','path-replay.c'),('check-orbits','check-paths'),('replay-graphs','replay-paths')]:
 t=(p/src).read_text()
 for a,b in [('seedwalk','closedwalk'),('seedstack','compresswalk'),('gatherwalk','compressstack'),('gatherstack','mixedpaths')]:t=t.replace(a,b)
 if src=='orbits.c':
  t=t.replace('if(methods[m](&empty,edges,n,target)||empty.length)return 9;','''bool complete=methods[m](&empty,edges,n,target);
                    if(empty.length)return 9;
                    if(complete){if(memcmp(target,reference,4*n)||target[n]!=0xcbcbcbcb)return 12;continue;}''')
 if src=='check-orbits':t=t.replace('orbits.c','path-orbits.c').replace('-o orbits','-o path-orbits').replace('./orbits ','./path-orbits ').replace('"orbits-','"path-orbits-').replace('touch orbits.ok','touch path-orbits.ok')
 if src=='replay-graphs':t=t.replace('test -x orbits','until [[ -x path-orbits ]];do sleep 2;done').replace('replay-graphs.c','path-replay.c').replace('-o replay-graphs','-o path-replay').replace('./replay-graphs ','./path-replay ').replace('"replay-','"path-replay-').replace('touch replay.ok','touch path-replay.ok')
 (p/dest).write_text(t)
