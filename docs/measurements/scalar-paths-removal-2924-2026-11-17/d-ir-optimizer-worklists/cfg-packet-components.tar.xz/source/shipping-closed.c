// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md.
//
// Tier 1 optimization (#139). The IR owner supplies ir.c; this file owns transfer functions and transformations,
// never another IR representation. Integer evaluation uses unsigned bits and refuses a faulting division or an
// out-of-range shift. Unknown analysis state and an IR undef are different: undef must enter as overdefined.
// The 16-item fold boundary uses bounded columns; it has no padding, alignment or inactive-lane read contract.
//
// The passes are scalar, the worklists SCCP and dead-code removal fill, since #2924. The vector passes beside them
// (rounds over every instruction with sixteen-lane folds and marks, pointer jumping for the threads, sixteen-lane ranks
// and identity candidates) took 1.02 to 1.44 times their ticks when forced, more with size (#2924's 6987893038).
// #860's AUTO bound kept SCCP and DCE's sweeps off below 8,192 instructions, but every rewrite (LICM's, GVN's, SROA's)
// threaded blocks by the vector pointer jumping and SROA's split ran DCE's vector roots and sweeps, in every compile;
// the deletion's whole-compile run measured their replacement (1,372 of 1,372 objects identical, sqlite3.c's and
// Lua's Tier 1 compiles 0.4 to 1.2% fewer user cycles). #860 had measured the vector passes 9 to 11% ahead at 16K+
// instructions in a near-single-block shape, which no corpus function reaches; the owner's decision (7112387760) was
// asked without it, corrected in 7122231079. #3445 is a vectorized form that would have to win at every size, that
// shape included.

#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "host_isa.h"

#define BUSTER_IR_OPTIMIZE_BATCH 16
#define BUSTER_IR_OPTIMIZE_SCCP 1u
#define BUSTER_IR_OPTIMIZE_DCE 2u
#define BUSTER_IR_OPTIMIZE_CFG 4u
// Tier 1 alone requests physical block placement; the shared optimizer's default preserves block order.
#define BUSTER_IR_OPTIMIZE_LAYOUT 8u
// Tier 1 alone requests identities' forwarding too (#2554, ir_optimize_identities): an integer operation that SCCP
// proves returns one of its operands unchanged is that operand to its users, and is neither kept nor emitted.
#define BUSTER_IR_OPTIMIZE_IDENTITY 16u
// CFG cleanup's merges (#139, ir_optimize_merges): a block whose single predecessor has it as its single successor joins
// it. The C driver's Tier 1 requests it; the shared optimizer's default keeps each block, as its other clients expect.
#define BUSTER_IR_OPTIMIZE_MERGE 32u
#define BUSTER_IR_OPTIMIZE_MEMORY 64u
#define BUSTER_IR_OPTIMIZE_PASSES (BUSTER_IR_OPTIMIZE_SCCP | BUSTER_IR_OPTIMIZE_DCE | BUSTER_IR_OPTIMIZE_CFG | BUSTER_IR_OPTIMIZE_LAYOUT | BUSTER_IR_OPTIMIZE_IDENTITY | BUSTER_IR_OPTIMIZE_MERGE | BUSTER_IR_OPTIMIZE_MEMORY)

typedef struct IrOptimizeOptions IrOptimizeOptions;
struct IrOptimizeOptions
{
    uint32_t passes;
};

typedef struct IrOptimizeResult IrOptimizeResult;
struct IrOptimizeResult
{
    IrFunction function;
    uint64_t sccp_visits;
    // The incoming values SCCP's phi transfers examined, executable or not: the work that grew as the square of a
    // join's predecessors when each visit met them all (#1729).
    uint64_t sccp_phi_incoming;
    uint64_t dce_visits;
    uint64_t scratch_bytes;
    uint32_t folded;
    uint32_t removed_instructions;
    uint32_t removed_blocks;
    // CFG cleanup's merged blocks (ir_optimize_merges): each joins its single predecessor; removed_blocks counts them too.
    uint32_t merged_blocks;
    uint32_t forwarded_loads;
};

typedef enum IrOptimizeState
{
    IROPT_UNKNOWN,
    IROPT_CONSTANT,
    IROPT_OVERDEFINED,
} IrOptimizeState;

typedef struct IrOptimizeWork IrOptimizeWork;
struct IrOptimizeWork
{
    const IrFunction* function;
    IrCfg cfg;
    IrUses uses;
    Dominators dominators;
    // What ir_optimize_prepare's dominator analysis gives past the tree (DominatorOptions.outputs): 0, or LICM's natural
    // loops (#2719), which would otherwise take the analysis a second time.
    uint32_t dominator_outputs;
    // Set before ir_optimize_prepare where the function needs no verification (#2719: Tier 1's LICM and value numbering on
    // the promoted function, which promotion verified and the passes since, threading and if-conversion among them, take
    // as verified, as these two now do; the optimizer after them verifies what reaches it): the preparation builds its
    // CFG without the structural verifier's shape, row and graph checks and doesn't check its operands' dominance. A
    // pass's own result is still verified where it rewrites the function.
    bool validated;
    // Set before ir_optimize_prepare by a pass that reads no use list (#2719: LICM's pressure policy in a function
    // without an undef, whose taint is all it reads them for): the preparation builds none, and `uses` stays empty.
    bool without_uses;
    // A pass using its own worklist and row rewrite needs just the graph and dominators.
    bool analysis_only;
    uint8_t* states;
    IrConstant* values;
    // Allocated lazily by the first SIMD transfer; scalar functions keep their two-word lattice and no wide map.
    uint32_t* vector_indices;
    IrSimdValue* vector_values;
    Arena* scratch;
    IrError simd_error;
    uint8_t* blocks;
    uint8_t* edges;
    uint8_t* live;
    uint8_t* queued;
    uint32_t* queue;
    uint32_t head;
    uint32_t tail;
    uint32_t queued_count;
    // SCCP's worklist moves a constant phi it dequeues to this queue, which it takes from only once the shared one is
    // empty (#1729), so that the edges and values reaching a join in one wave share one visit of it. Reserved by the
    // first such phi, null where it couldn't be (`phis_refused`): phis are then visited in turn. An instruction is in
    // one of the two queues at most (`queued`).
    uint32_t* phis;
    bool phis_refused;
    uint32_t phi_head;
    uint32_t phi_tail;
    uint32_t phi_count;
    // With BUSTER_IR_OPTIMIZE_IDENTITY (#2554), each instruction's forwarded operand, the value its users read in its
    // place, or BUSTER_IR_NONE; null without the option or without any identity (ir_optimize_identities).
    uint32_t* forward;
    IrOptimizeResult statistics;
};

static __attribute__((unused)) IrOptimizeOptions ir_optimize_options(void)
{
    const IrOptimizeOptions result = {
        .passes = BUSTER_IR_OPTIMIZE_SCCP | BUSTER_IR_OPTIMIZE_DCE | BUSTER_IR_OPTIMIZE_CFG,
    };
    return result;
}

static __attribute__((unused)) IrCheck ir_optimize(const IrFunction* function, Arena* output, Arena* scratch, IrOptimizeOptions options, IrOptimizeResult* result);

// Transfer-function classes, internal to this module. These are not IR opcodes.
typedef enum IrOptimizeFoldOp
{
    IROPT_FOLD_NONE,
    IROPT_FOLD_ADD,
    IROPT_FOLD_SUB,
    IROPT_FOLD_MUL,
    IROPT_FOLD_AND,
    IROPT_FOLD_OR,
    IROPT_FOLD_XOR,
    IROPT_FOLD_SHL,
    IROPT_FOLD_LSHR,
    IROPT_FOLD_ASHR,
    IROPT_FOLD_UDIV,
    IROPT_FOLD_UREM,
    IROPT_FOLD_SDIV,
    IROPT_FOLD_SREM,
    IROPT_FOLD_EQ,
    IROPT_FOLD_NE,
    IROPT_FOLD_ULT,
    IROPT_FOLD_ULE,
    IROPT_FOLD_SLT,
    IROPT_FOLD_SLE,
} IrOptimizeFoldOp;

typedef struct IrOptimizeFoldBatch IrOptimizeFoldBatch;
struct IrOptimizeFoldBatch
{
    uint32_t count;
    const uint32_t* operation;
    const uint32_t* width;
    const uint64_t* left;
    const uint64_t* right;
    uint64_t* result;
};

static uint64_t ir_optimize_width_mask(uint32_t width)
{
    const uint64_t result = UINT64_MAX >> (64 - width);
    return result;
}

// All operations take normalized unsigned bit patterns. Signed comparisons use the sign-bit-biased ordering;
// signed division works on magnitudes, so neither signed overflow nor implementation-defined casts enter folding.
static __attribute__((unused)) bool ir_optimize_fold_one(uint32_t operation, uint32_t width, uint64_t left, uint64_t right, uint64_t* output)
{
    bool folded = width != 0 && width <= 64;
    uint64_t result = 0;
    if (folded)
    {
        const uint64_t mask = ir_optimize_width_mask(width);
        const uint64_t sign = UINT64_C(1) << (width - 1);
        left &= mask;
        if (operation < IROPT_FOLD_SHL || operation > IROPT_FOLD_ASHR)
        {
            right &= mask;
        }
        switch (operation)
        {
            case IROPT_FOLD_ADD: result = left + right; break;
            case IROPT_FOLD_SUB: result = left - right; break;
            case IROPT_FOLD_MUL: result = left * right; break;
            case IROPT_FOLD_AND: result = left & right; break;
            case IROPT_FOLD_OR: result = left | right; break;
            case IROPT_FOLD_XOR: result = left ^ right; break;
            case IROPT_FOLD_EQ: result = left == right; break;
            case IROPT_FOLD_NE: result = left != right; break;
            case IROPT_FOLD_ULT: result = left < right; break;
            case IROPT_FOLD_ULE: result = left <= right; break;
            case IROPT_FOLD_SLT: result = (left ^ sign) < (right ^ sign); break;
            case IROPT_FOLD_SLE: result = (left ^ sign) <= (right ^ sign); break;
            case IROPT_FOLD_SHL:
            case IROPT_FOLD_LSHR:
            case IROPT_FOLD_ASHR:
            {
                folded = right < width;
                if (folded)
                {
                    if (operation == IROPT_FOLD_SHL)
                    {
                        result = left << right;
                    }
                    else
                    {
                        result = left >> right;
                        if (operation == IROPT_FOLD_ASHR && (left & sign) != 0 && right != 0)
                        {
                            result |= mask ^ (mask >> right);
                        }
                    }
                }
            } break;
            case IROPT_FOLD_UDIV:
            case IROPT_FOLD_UREM:
            {
                folded = right != 0;
                if (folded)
                {
                    result = operation == IROPT_FOLD_UDIV ? left / right : left % right;
                }
            } break;
            case IROPT_FOLD_SDIV:
            case IROPT_FOLD_SREM:
            {
                folded = right != 0 && !(left == sign && right == mask);
                if (folded)
                {
                    const bool left_negative = (left & sign) != 0;
                    const bool right_negative = (right & sign) != 0;
                    const uint64_t left_magnitude = left_negative ? (-left & mask) : left;
                    const uint64_t right_magnitude = right_negative ? (-right & mask) : right;
                    result = operation == IROPT_FOLD_SDIV ? left_magnitude / right_magnitude : left_magnitude % right_magnitude;
                    const bool negative = operation == IROPT_FOLD_SDIV ? left_negative != right_negative : left_negative;
                    if (negative)
                    {
                        result = -result;
                    }
                }
            } break;
            default: folded = false; break;
        }
        result &= mask;
    }
    if (folded)
    {
        *output = result;
    }
    return folded;
}

// A returned bit authorizes its result slot. Inactive or refused slots are left unchanged.
static __attribute__((unused)) uint16_t ir_optimize_fold_batch(IrOptimizeFoldBatch batch, uint16_t active)
{
    uint16_t folded = 0;
    if (batch.count <= BUSTER_IR_OPTIMIZE_BATCH)
    {
        for (uint32_t i = 0; i < batch.count; i += 1)
        {
            if ((active & (UINT32_C(1) << i)) != 0 && ir_optimize_fold_one(batch.operation[i], batch.width[i], batch.left[i], batch.right[i], &batch.result[i]))
            {
                folded |= UINT32_C(1) << i;
            }
        }
    }
    return folded;
}

// After four doublings, an orbit either left the packet or reached a local cycle.
// The next sixteen vertices from that cycle entry contain every member of the cycle.
static __m512i ir_optimize_closed_targets(__m512i ids, __m512i successors, __m512i first)
{
    __m512i least = _mm512_min_epu32(ids, successors);
    __m512i step = successors;
    for (unsigned round = 0; round < 4; round += 1)
    {
        const __m512i index = _mm512_sub_epi32(step, first);
        least = _mm512_min_epu32(least, _mm512_permutexvar_epi32(index, least));
        step = _mm512_permutexvar_epi32(index, step);
    }
    return _mm512_permutexvar_epi32(_mm512_sub_epi32(step, first), least);
}

// direct[b] is b for an observable block; otherwise the sole successor of a transparent unconditional jump.
// The caller must protect phi-edge identity before classifying a block as transparent. A cycle of transparent
// jumps resolves to its smallest block id, where the consumer retains a self-loop. This preserves nontermination.
// Each block's chain is walked once, up to a block whose target is known or back to a block of this walk: the walked
// blocks take that target, or the smallest block of the cycle found. Failure leaves targets and scratch.length unchanged.
static __attribute__((unused, aligned(64))) bool ir_optimize_thread_targets(Arena* scratch, const uint32_t* direct, uint32_t count, uint32_t* targets)
{
    if (count == 0)
    {
        return true;
    }
    if (direct == NULL || targets == NULL)
    {
        return false;
    }
    const __m512i lanes = _mm512_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
    const void* gather_origin = (const void*)((uintptr_t)direct + (UINT64_C(1) << 33));
    bool unresolved = false;
    bool all_local = true;
    const uint32_t head = ((uintptr_t)direct & 63) / sizeof(uint32_t);
    const uintptr_t aligned = (uintptr_t)direct & ~(uintptr_t)63;
    for (int64_t first = -(int64_t)head; first < count; first += 16)
    {
        const uint64_t remaining = (int64_t)count - first;
        const uint32_t end = remaining < 16 ? (uint32_t)remaining : 16;
        const __mmask16 valid = (__mmask16)(_bzhi_u32(UINT16_MAX, end) & (first < 0 ? UINT16_MAX << head : UINT16_MAX));
        const uintptr_t address = aligned + (first + head) * sizeof(uint32_t);
        const __m512i successors = _mm512_maskz_load_epi32(valid, (const void*)address);
        if (_mm512_mask_cmpge_epu32_mask(valid, successors, _mm512_set1_epi32((int32_t)count)) != 0)
        {
            return false;
        }
        const __m512i ids = _mm512_add_epi32(_mm512_set1_epi32((int32_t)first), lanes);
        const __mmask16 moved = _mm512_mask_cmpneq_epi32_mask(valid, successors, ids);
        if (moved != 0 && (!unresolved || all_local))
        {
            const __m512i local = _mm512_sub_epi32(successors, _mm512_set1_epi32((int32_t)first));
            __m512i following = _mm512_permutexvar_epi32(local, successors);
            const __m512i packet_ids = _mm512_mask_mov_epi32(_mm512_set1_epi32(-1), valid, ids);
            const __mmask16 remote = _mm512_mask_cmpneq_epi32_mask(moved, successors, _mm512_permutexvar_epi32(local, packet_ids));
            all_local &= remote == 0;
            if (unresolved)
            {
                continue;
            }
            if (remote != 0)
            {

                const __m512i indices = _mm512_xor_si512(successors, _mm512_set1_epi32(INT32_MIN));
                following = _mm512_mask_i32gather_epi32(following, remote, indices, gather_origin, sizeof(uint32_t));
            }
            unresolved = _mm512_mask_cmpneq_epi32_mask(moved, following, successors) != 0;
        }
    }
    if (!unresolved)
    {
        memmove(targets, direct, (uint64_t)count * sizeof(uint32_t));
        return true;
    }
    if (all_local)
    {
        const uint64_t packets = ((uint64_t)head + count + 15) / 16;
        // Resolve packets in memmove order. A shifted output can overlap another packet's input.
        const bool reverse = (uintptr_t)targets > (uintptr_t)direct;
        for (uint64_t i = 0; i < packets; i += 1)
        {
            const uint64_t k = reverse ? packets - 1 - i : i;
            const int64_t first = (int64_t)(k * 16) - head;
            const uint64_t left = (int64_t)count - first;
            const __mmask16 valid = (__mmask16)(_bzhi_u32(UINT16_MAX, left < 16 ? (uint32_t)left : 16) & (k == 0 ? UINT16_MAX << head : UINT16_MAX));
            const __m512i start = _mm512_set1_epi32((int32_t)first);
            const __m512i successors = _mm512_maskz_load_epi32(valid, (const void*)(aligned + 64 * k));
            const __m512i resolved = ir_optimize_closed_targets(_mm512_add_epi32(start, lanes), successors, start);
            _mm512_mask_storeu_epi32((void*)((uintptr_t)targets + (uintptr_t)first * sizeof(uint32_t)), valid, resolved);
        }
        return true;
    }
    const uint64_t saved = scratch->length;
    uint32_t* current = arena_push_array(scratch, count, sizeof(uint32_t), _Alignof(uint32_t));
    if (current == NULL)
    {
        return false;
    }
    for (uint64_t first = 0; first < count; first += 16)
    {
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, count - first < 16 ? (uint32_t)(count - first) : 16);
        const __m512i successors = _mm512_maskz_loadu_epi32(valid, direct + first);

        const __m512i indices = _mm512_xor_si512(successors, _mm512_set1_epi32(INT32_MIN));
        const __m512i following = _mm512_mask_i32gather_epi32(successors, valid, indices, gather_origin, sizeof(uint32_t));
        const __mmask16 ready = _mm512_cmpeq_epi32_mask(following, successors);
        _mm512_mask_storeu_epi32(current + first, valid, _mm512_mask_mov_epi32(_mm512_set1_epi32(-1), ready, successors));
    }
    for (uint64_t first = 0; first < count; first += 16)
    {
        const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, count - first < 16 ? (uint32_t)(count - first) : 16);
        const __m512i known = _mm512_maskz_loadu_epi32(valid, current + first);
        uint32_t pending = _mm512_mask_cmpeq_epi32_mask(valid, known, _mm512_set1_epi32(-1));
        while (pending != 0)
        {
            const uint32_t block = (uint32_t)first + (uint32_t)__builtin_ctz(pending);
            pending &= pending - 1;
            // A previous component walk in this packet may have resolved this block.
            if (current[block] != UINT32_MAX)
            {
                continue;
            }
            const uint32_t successor = direct[block];
            if (current[successor] != UINT32_MAX)
            {
                current[block] = current[successor];
                continue;
            }
            // The start is unresolved, so it cannot already name a finished representative.
            // Its own ID is a unique temporary mark for all vertices visited by this walk.
            uint32_t node = block;
            uint32_t length = 0;
            do
            {
                current[node] = block;
                length += 1;
                node = direct[node];
            } while (current[node] == UINT32_MAX);
            uint32_t representative = current[node];
            if (representative == block)
            {
                representative = node;
                for (uint32_t other = direct[node]; other != node; other = direct[other])
                {
                    if (other < representative)
                    {
                        representative = other;
                    }
                }
            }
            node = block;
            for (uint32_t i = 0; i < length; i += 1)
            {
                current[node] = representative;
                node = direct[node];
            }
        }
    }
    memcpy(targets, current, (uint64_t)count * sizeof(uint32_t));
    arena_pop_to(scratch, saved);
    return true;
}

static bool ir_optimize_equal(IrConstant a, IrConstant b)
{
    const bool result = a.low == b.low && a.high == b.high;
    return result;
}

static uint32_t ir_optimize_fold_operation(const IrFunction* f, uint32_t i, bool* swap)
{
    static const uint8_t operations[BUSTER_IR_OP_TABLE] = {
        [IR_ADD] = IROPT_FOLD_ADD,
        [IR_SUB] = IROPT_FOLD_SUB,
        [IR_MUL] = IROPT_FOLD_MUL,
        [IR_AND] = IROPT_FOLD_AND,
        [IR_OR] = IROPT_FOLD_OR,
        [IR_XOR] = IROPT_FOLD_XOR,
        [IR_SHL] = IROPT_FOLD_SHL,
        [IR_LSHR] = IROPT_FOLD_LSHR,
        [IR_ASHR] = IROPT_FOLD_ASHR,
        [IR_UDIV] = IROPT_FOLD_UDIV,
        [IR_SDIV] = IROPT_FOLD_SDIV,
        [IR_UREM] = IROPT_FOLD_UREM,
        [IR_SREM] = IROPT_FOLD_SREM,
    };
    uint32_t operation = operations[f->op[i]];
    *swap = false;
    if (f->op[i] == IR_ICMP)
    {
        static const uint8_t predicates[IR_PREDICATE_COUNT] = {
            IROPT_FOLD_EQ,
            IROPT_FOLD_NE,
            IROPT_FOLD_SLT,
            IROPT_FOLD_SLE,
            IROPT_FOLD_SLT,
            IROPT_FOLD_SLE,
            IROPT_FOLD_ULT,
            IROPT_FOLD_ULE,
            IROPT_FOLD_ULT,
            IROPT_FOLD_ULE,
        };
        operation = predicates[f->c[i]];
        *swap = f->c[i] == IR_GT || f->c[i] == IR_GE || f->c[i] == IR_UGT || f->c[i] == IR_UGE;
    }
    return operation;
}

static unsigned __int128 ir_optimize_bits(IrConstant value)
{
    const unsigned __int128 result = ((unsigned __int128)value.high << 64) | value.low;
    return result;
}

static IrConstant ir_optimize_constant(unsigned __int128 value, uint32_t width)
{
    if (width < 128)
    {
        value &= ((unsigned __int128)1 << width) - 1;
    }
    const IrConstant result = {
        .low = (uint64_t)value,
        .high = (uint64_t)(value >> 64),
    };
    return result;
}

static bool ir_optimize_fold_wide(uint32_t operation, IrConstant a, IrConstant b, IrConstant* output)
{
    const unsigned __int128 left = ir_optimize_bits(a);
    const unsigned __int128 right = ir_optimize_bits(b);
    const unsigned __int128 sign = (unsigned __int128)1 << 127;
    unsigned __int128 value = 0;
    bool folded = true;
    switch (operation)
    {
        case IROPT_FOLD_ADD: value = left + right; break;
        case IROPT_FOLD_SUB: value = left - right; break;
        case IROPT_FOLD_MUL: value = left * right; break;
        case IROPT_FOLD_AND: value = left & right; break;
        case IROPT_FOLD_OR: value = left | right; break;
        case IROPT_FOLD_XOR: value = left ^ right; break;
        case IROPT_FOLD_EQ: value = left == right; break;
        case IROPT_FOLD_NE: value = left != right; break;
        case IROPT_FOLD_ULT: value = left < right; break;
        case IROPT_FOLD_ULE: value = left <= right; break;
        case IROPT_FOLD_SLT: value = (left ^ sign) < (right ^ sign); break;
        case IROPT_FOLD_SLE: value = (left ^ sign) <= (right ^ sign); break;
        case IROPT_FOLD_SHL:
        case IROPT_FOLD_LSHR:
        case IROPT_FOLD_ASHR:
        {
            folded = right < 128;
            if (folded)
            {
                if (operation == IROPT_FOLD_SHL)
                {
                    value = left << (uint32_t)right;
                }
                else
                {
                    value = left >> (uint32_t)right;
                    if (operation == IROPT_FOLD_ASHR && (left & sign) != 0 && right != 0)
                    {
                        value |= ~(unsigned __int128)0 << (128 - (uint32_t)right);
                    }
                }
            }
        } break;
        case IROPT_FOLD_UDIV:
        case IROPT_FOLD_UREM:
        {
            folded = right != 0;
            if (folded)
            {
                value = operation == IROPT_FOLD_UDIV ? left / right : left % right;
            }
        } break;
        case IROPT_FOLD_SDIV:
        case IROPT_FOLD_SREM:
        {
            folded = right != 0 && !(left == sign && right == ~(unsigned __int128)0);
            if (folded)
            {
                const bool negative_left = (left & sign) != 0;
                const bool negative_right = (right & sign) != 0;
                const unsigned __int128 magnitude_left = negative_left ? -left : left;
                const unsigned __int128 magnitude_right = negative_right ? -right : right;
                value = operation == IROPT_FOLD_SDIV ? magnitude_left / magnitude_right : magnitude_left % magnitude_right;
                if (operation == IROPT_FOLD_SDIV ? negative_left != negative_right : negative_left)
                {
                    value = -value;
                }
            }
        } break;
        default: folded = false; break;
    }
    if (folded)
    {
        *output = ir_optimize_constant(value, 128);
    }
    return folded;
}

static uint32_t ir_optimize_edge(const IrCfg* cfg, uint32_t from, uint32_t to)
{
    uint32_t result = BUSTER_IR_NONE;
    for (uint32_t edge = cfg->successor_offsets[from]; edge < cfg->successor_offsets[(uint64_t)from + 1]; edge += 1)
    {
        if (cfg->successors[edge] == to)
        {
            result = edge;
        }
    }
    return result;
}

static void ir_optimize_enqueue(IrOptimizeWork* work, uint32_t instruction)
{
    if (work->queued[instruction] == 0)
    {
        work->queued[instruction] = 1;
        work->queue[work->tail] = instruction;
        work->tail += 1;
        if (work->tail == work->function->instruction_count)
        {
            work->tail = 0;
        }
        work->queued_count += 1;
    }
}

static uint32_t ir_optimize_dequeue(IrOptimizeWork* work)
{
    const uint32_t instruction = work->queue[work->head];
    work->head += 1;
    if (work->head == work->function->instruction_count)
    {
        work->head = 0;
    }
    work->queued_count -= 1;
    work->queued[instruction] = 0;
    return instruction;
}

// Moves a constant phi dequeued from the shared queue to the phis' queue (IrOptimizeWork.phis), reserving it unzeroed
// on the first move: only the entries written are read. False where it couldn't be reserved.
static bool ir_optimize_defer_phi(IrOptimizeWork* work, uint32_t instruction)
{
    if (work->phis == NULL && !work->phis_refused)
    {
        work->phis = arena_push_array(work->scratch, work->function->instruction_count, sizeof(uint32_t), 64);
        work->phis_refused = work->phis == NULL;
    }
    const bool deferred = work->phis != NULL;
    if (deferred)
    {
        work->queued[instruction] = 1;
        work->phis[work->phi_tail] = instruction;
        work->phi_tail += 1;
        if (work->phi_tail == work->function->instruction_count)
        {
            work->phi_tail = 0;
        }
        work->phi_count += 1;
    }
    return deferred;
}

static uint32_t ir_optimize_dequeue_sccp(IrOptimizeWork* work)
{
    uint32_t instruction;
    if (work->queued_count != 0)
    {
        instruction = ir_optimize_dequeue(work);
    }
    else
    {
        instruction = work->phis[work->phi_head];
        work->phi_head += 1;
        if (work->phi_head == work->function->instruction_count)
        {
            work->phi_head = 0;
        }
        work->phi_count -= 1;
        work->queued[instruction] = 0;
    }
    return instruction;
}

static void ir_optimize_enqueue_users(IrOptimizeWork* work, uint32_t value)
{
    for (uint32_t use = work->uses.offsets[value]; use < work->uses.offsets[(uint64_t)value + 1]; use += 1)
    {
        ir_optimize_enqueue(work, work->uses.uses[use].instruction);
    }
}

static uint8_t ir_optimize_meet(uint8_t left, IrConstant a, uint8_t right, IrConstant b, IrConstant* value)
{
    uint8_t result;
    if (left == IROPT_UNKNOWN)
    {
        result = right;
        *value = b;
    }
    else if (right == IROPT_UNKNOWN)
    {
        result = left;
        *value = a;
    }
    else if (left == IROPT_CONSTANT && right == IROPT_CONSTANT && ir_optimize_equal(a, b))
    {
        result = IROPT_CONSTANT;
        *value = a;
    }
    else
    {
        result = IROPT_OVERDEFINED;
    }
    return result;
}

// A visit's transfer kind by operation: a fold candidate or the overdefined default (0), a
// constant, a state copy, a phi meet, a select pick, or a unary fold. The op-indexed read keeps
// the per-instruction dispatch a load where the compare chain lowered to a jump table's indirect
// branch (#786).
static const uint8_t ir_optimize_transfer_kinds[BUSTER_IR_OP_TABLE] = {
    [IR_CONST] = 1,
    [IR_COPY] = 2,
    [IR_PHI] = 3,
    [IR_SELECT] = 4,
    [IR_NEG] = 5,
    [IR_NOT] = 5,
    [IR_TRUNC] = 5,
    [IR_ZEXT] = 5,
    [IR_SEXT] = 5,
    [IR_INTTOPTR] = 5,
    [IR_PTRTOINT] = 5,
    [IR_BITCAST] = 5,
    [IR_FNEG] = 5,
    [IR_FADD] = 6,
    [IR_FSUB] = 6,
    [IR_FMUL] = 6,
    [IR_FDIV] = 6,
    [IR_FCMP] = 6,
    [IR_SITOFP] = 7,
    [IR_UITOFP] = 7,
    [IR_FPTOSI] = 7,
    [IR_FPTOUI] = 7,
    [IR_FEXT] = 7,
    [IR_FTRUNC] = 7,
};

static bool ir_optimize_simd_float(uint32_t op, uint32_t width, uint32_t bits, uint32_t predicate, const IrSimdValue* left, const IrSimdValue* right, IrSimdValue* output);
static bool ir_optimize_simd_float_encode(uint64_t sign, unsigned __int128 m, int32_t e, uint32_t width, uint64_t* value);

// Scalar floating operations (#2720) fold as a one-lane vector of ir_optimize_simd_float, where every floating
// environment gives the same bits, and further only where the operation raises no exception flag: a folded scalar row
// is no root (ir_optimize_roots' kind 2), so nothing is left to raise one. So no operand is a NaN (a signaling one
// raises invalid, and two quiet ones' payload would depend on the operands' order in the emitted instruction), the
// result isn't one (an invalid operation's default NaN) and no division is by zero. f80 stays with the x87 at run time.
static bool ir_optimize_float_binary(uint32_t op, uint32_t width, uint32_t predicate, uint64_t a, uint64_t b, uint64_t* value)
{
    const uint64_t exponent = width == 32 ? UINT64_C(0x7f800000) : UINT64_C(0x7ff0000000000000);
    const uint64_t fraction = width == 32 ? UINT64_C(0x007fffff) : UINT64_C(0x000fffffffffffff);
    const uint64_t magnitude = exponent | fraction;
    const bool operand_nan = (a & magnitude) > exponent || (b & magnitude) > exponent;
    const bool divisor_zero = op == IR_FDIV && (b & magnitude) == 0;
    const IrSimdValue left = { .words = { a } };
    const IrSimdValue right = { .words = { b } };
    IrSimdValue output = { 0 };
    bool result = !operand_nan && !divisor_zero && ir_optimize_simd_float(op == IR_FCMP ? IR_VCMP : op, width, width, predicate, &left, &right, &output);
    if (result)
    {
        *value = op == IR_FCMP ? output.words[0] & 1 : output.words[0];
        result = op == IR_FCMP || (*value & magnitude) <= exponent;
    }
    return result;
}

// A conversion's exact value (#2720) under the same rule: no NaN or subnormal operand, an integer that the format holds
// exactly, a floating value that is an integer the target holds, and a narrowing that loses no bit and stays normal.
// Each raises no flag where it folds. Integer operands and results are 8 to 64 bits wide, floating ones f32 or f64.
static bool ir_optimize_float_conversion(uint32_t op, uint32_t from, uint32_t to, uint64_t bits, uint64_t* value)
{
    const bool floating_source = op == IR_FPTOSI || op == IR_FPTOUI || op == IR_FEXT || op == IR_FTRUNC;
    const uint32_t width = floating_source ? from : to;
    const uint32_t precision = width == 32 ? 24 : 53;
    const int32_t bias = width == 32 ? 127 : 1023;
    // The floating format's fields: the source's for a floating source, the target's (unread here) for an integer one.
    const uint64_t sign = floating_source ? UINT64_C(1) << (from - 1) : 0;
    const uint64_t fraction = (UINT64_C(1) << (precision - 1)) - 1;
    const uint64_t exponent = (UINT64_C(1) << (width - 1)) - 1 - fraction;
    const bool zero = floating_source && (bits & ~sign) == 0;
    const bool infinite = floating_source && (bits & ~sign) == exponent;
    const bool special = floating_source && ((bits & exponent) == exponent || (bits & exponent) == 0);
    const uint64_t significand = (bits & fraction) | (fraction + 1);
    const int32_t scale = (int32_t)((bits & exponent) >> (precision - 1)) - bias - (int32_t)(precision - 1);
    bool result = false;
    if (op == IR_SITOFP || op == IR_UITOFP)
    {
        const uint64_t source_sign = UINT64_C(1) << (from - 1);
        const bool negative = op == IR_SITOFP && (bits & source_sign) != 0;
        const uint64_t source_mask = UINT64_MAX >> (64 - from);
        const uint64_t magnitude = negative ? (~bits + 1) & source_mask : bits & source_mask;
        const uint64_t target_sign = UINT64_C(1) << (to - 1);
        result = magnitude == 0 || ir_optimize_simd_float_encode(negative ? target_sign : 0, magnitude, 0, to, value);
        *value = magnitude == 0 ? 0 : *value;
    }
    else if (op == IR_FEXT || op == IR_FTRUNC)
    {
        const uint64_t target_sign = (bits & sign) != 0 ? UINT64_C(1) << (to - 1) : 0;
        const uint64_t target_exponent = to == 32 ? UINT64_C(0x7f800000) : UINT64_C(0x7ff0000000000000);
        result = zero || infinite || (!special && ir_optimize_simd_float_encode(target_sign, significand, scale, to, value));
        *value = zero ? target_sign : infinite ? target_sign | target_exponent : *value;
    }
    else if (!special)
    {
        // An integer's value: past the significand's bits the scale is a left shift, which the target's width bounds;
        // below them the shifted-out bits must be zero.
        const uint32_t right = scale < 0 ? (uint32_t)-scale : 0;
        const bool integral = right < 64 && (significand & ((UINT64_C(1) << right) - 1)) == 0;
        const uint32_t left = scale > 0 ? (uint32_t)scale : 0;
        const uint64_t whole = integral ? (significand >> right) : 0;
        const uint32_t length = 64 - (uint32_t)__builtin_clzll(whole | 1);
        const bool negative = (bits & sign) != 0;
        // A signed target holds magnitudes below 2^(to - 1), and its minimum itself; an unsigned one below 2^to, never
        // negative.
        const uint32_t room = op == IR_FPTOSI ? to - 1 : to;
        const bool minimum = op == IR_FPTOSI && negative && length + left == to && whole == (UINT64_C(1) << (length - 1));
        result = integral && whole != 0 && (length + left <= room || minimum) && !(op == IR_FPTOUI && negative);
        const uint64_t magnitude = result ? whole << left : 0;
        const uint64_t mask = UINT64_MAX >> (64 - to);
        *value = (negative ? ~magnitude + 1 : magnitude) & mask;
    }
    else
    {
        result = zero;
        *value = 0;
    }
    return result;
}

static uint8_t ir_optimize_float_transfer(const IrOptimizeWork* work, uint32_t i, IrConstant* value)
{
    const IrFunction* f = work->function;
    const uint32_t op = f->op[i];
    const uint32_t a = f->a[i];
    const bool binary = ir_optimize_transfer_kinds[op] == 6;
    const uint32_t from = ir_type_bits[f->type[a]];
    const uint32_t to = ir_type_bits[f->type[i]];
    const uint32_t floating = binary || op == IR_FPTOSI || op == IR_FPTOUI || op == IR_FEXT || op == IR_FTRUNC ? from : to;
    const uint32_t integer = op == IR_SITOFP || op == IR_UITOFP ? from : op == IR_FPTOSI || op == IR_FPTOUI ? to : 64;
    const bool sized = (floating == 32 || floating == 64) && (to == 32 || to == 64 || !(op == IR_FEXT || op == IR_FTRUNC)) && integer >= 8 &&
                       integer <= 64 && (integer & (integer - 1)) == 0;
    const uint8_t left = work->states[a];
    const uint8_t right = binary ? work->states[f->b[i]] : IROPT_CONSTANT;
    uint8_t result = left == IROPT_OVERDEFINED || right == IROPT_OVERDEFINED || !sized ? IROPT_OVERDEFINED : left == IROPT_UNKNOWN || right == IROPT_UNKNOWN ? IROPT_UNKNOWN : IROPT_CONSTANT;
    if (result == IROPT_CONSTANT)
    {
        uint64_t bits = 0;
        const bool folded = binary ? ir_optimize_float_binary(op, from, op == IR_FCMP ? f->c[i] : IR_EQ, work->values[a].low, work->values[f->b[i]].low, &bits)
                                   : ir_optimize_float_conversion(op, from, to, work->values[a].low, &bits);
        result = folded ? IROPT_CONSTANT : IROPT_OVERDEFINED;
        *value = (IrConstant){ .low = bits };
    }
    return result;
}

// `examined` counts a phi's incoming values looked at (IrOptimizeResult.sccp_phi_incoming).
static uint8_t ir_optimize_transfer(const IrOptimizeWork* work, uint32_t i, IrConstant* value, uint64_t* examined)
{
    const IrFunction* f = work->function;
    const uint32_t op = f->op[i];
    const uint32_t a = f->a[i];
    const uint32_t b = f->b[i];
    uint8_t result = IROPT_OVERDEFINED;
    const uint32_t kind = ir_optimize_transfer_kinds[op];
    if (kind == 1)
    {
        result = IROPT_CONSTANT;
        *value = f->constants[a];
    }
    else if (kind == 2)
    {
        result = work->states[a];
        *value = work->values[a];
    }
    else if (kind == 3)
    {
        result = IROPT_UNKNOWN;
        // Overdefined meets anything to overdefined: the rest of the incoming values can't change the result.
        uint32_t incoming = 0;
        for (; incoming < b && result != IROPT_OVERDEFINED; incoming += 1)
        {
            const uint32_t predecessor = f->extra[a + incoming * 2];
            const uint32_t source = f->extra[a + incoming * 2 + 1];
            const uint32_t edge = ir_optimize_edge(&work->cfg, predecessor, work->cfg.instruction_blocks[i]);
            if (work->edges[edge] != 0)
            {
                result = ir_optimize_meet(result, *value, work->states[source], work->values[source], value);
            }
        }
        *examined += incoming;
    }
    else if (kind == 4)
    {
        if (work->states[a] == IROPT_CONSTANT)
        {
            const uint32_t source = work->values[a].low != 0 ? b : f->c[i];
            result = work->states[source];
            *value = work->values[source];
        }
        else if (work->states[b] == IROPT_CONSTANT && work->states[f->c[i]] == IROPT_CONSTANT && ir_optimize_equal(work->values[b], work->values[f->c[i]]))
        {
            result = IROPT_CONSTANT;
            *value = work->values[b];
        }
        else if (work->states[a] == IROPT_UNKNOWN)
        {
            result = IROPT_UNKNOWN;
        }
    }
    else if (kind == 5)
    {
        result = work->states[a];
        if (result == IROPT_CONSTANT)
        {
            unsigned __int128 bits = ir_optimize_bits(work->values[a]);
            const uint32_t source_width = ir_type_bits[f->type[a]];
            const uint32_t width = ir_type_bits[f->type[i]];
            // Each applies to one op, so independent conditions; an else-if chain lowers to a
            // jump table's indirect branch here (#786).
            if (op == IR_NEG)
            {
                bits = -bits;
            }
            if (op == IR_NOT)
            {
                bits = ~bits;
            }
            if (op == IR_SEXT && (bits & ((unsigned __int128)1 << (source_width - 1))) != 0)
            {
                bits |= ~(unsigned __int128)0 << source_width;
            }
            if (op == IR_FNEG)
            {
                bits ^= (unsigned __int128)1 << (width - 1);
            }
            *value = ir_optimize_constant(bits, width);
        }
    }
    else if (kind >= 6)
    {
        result = ir_optimize_float_transfer(work, i, value);
    }
    else
    {
        bool swap;
        const uint32_t operation = ir_optimize_fold_operation(f, i, &swap);
        if (operation != IROPT_FOLD_NONE)
        {
            const uint8_t left_state = work->states[a];
            const uint8_t right_state = work->states[b];
            // An `and` of an undef is zero (#3424), as LLVM folds it: the undef may be zero, and the result is then zero
            // whatever the other operand is. Not the undef itself, whose bits the `and`'s other operand clears: SROA's
            // eightbytes (ir_sroa_widen) clear a field's bits in a word no store wrote before, an undef after promotion,
            // and an undef that reaches a phi has no definition, so a register holding whatever it held.
            if (operation == IROPT_FOLD_AND && (f->op[a] == IR_UNDEF || f->op[b] == IR_UNDEF))
            {
                result = IROPT_CONSTANT;
                *value = (IrConstant){ 0 };
            }
            else if (left_state == IROPT_OVERDEFINED || right_state == IROPT_OVERDEFINED)
            {
                result = IROPT_OVERDEFINED;
            }
            else if (left_state == IROPT_UNKNOWN || right_state == IROPT_UNKNOWN)
            {
                result = IROPT_UNKNOWN;
            }
            else
            {
                const IrConstant left = work->values[swap ? b : a];
                const IrConstant right = work->values[swap ? a : b];
                const uint32_t width = ir_type_bits[f->type[a]];
                bool folded;
                if (width == 128)
                {
                    folded = ir_optimize_fold_wide(operation, left, right, value);
                }
                else
                {
                    folded = right.high == 0 && ir_optimize_fold_one(operation, width, left.low, right.low, &value->low);
                    value->high = 0;
                }
                result = folded ? IROPT_CONSTANT : IROPT_OVERDEFINED;
            }
        }
    }
    // Vector results, vector comparisons and vector-source bitcasts use ir_optimize_simd_transfer, not this scalar
    // lattice. In particular their sparse payload indices are never interpreted as integer constant bits.
    return result;
}

static bool ir_optimize_publish(IrOptimizeWork* work, uint32_t i, uint8_t state, IrConstant value, bool queue)
{
    IrConstant combined = { 0 };
    const uint8_t next = ir_optimize_meet(work->states[i], work->values[i], state, value, &combined);
    const bool changed = next != work->states[i];
    if (changed)
    {
        work->states[i] = next;
        work->values[i] = next == IROPT_CONSTANT ? combined : (IrConstant){ 0 };
        if (queue)
        {
            ir_optimize_enqueue_users(work, i);
        }
    }
    return changed;
}

#include "ir_optimize_simd.c"

static bool ir_optimize_mark_edge(IrOptimizeWork* work, uint32_t edge, bool queue)
{
    const bool changed = work->edges[edge] == 0;
    if (changed)
    {
        const uint32_t block = work->cfg.successors[edge];
        work->edges[edge] = 1;
        work->blocks[block] = 1;
        if (queue)
        {
            for (uint32_t i = work->function->block_offsets[block]; i < work->function->block_offsets[(uint64_t)block + 1]; i += 1)
            {
                ir_optimize_enqueue(work, i);
            }
        }
    }
    return changed;
}

static bool ir_optimize_control(IrOptimizeWork* work, uint32_t i, bool queue)
{
    const IrFunction* f = work->function;
    const uint32_t block = work->cfg.instruction_blocks[i];
    const uint32_t op = f->op[i];
    uint32_t target = BUSTER_IR_NONE;
    bool all = false;
    if (op == IR_BR)
    {
        target = f->a[i];
    }
    else if (op == IR_CBR || op == IR_SWITCH)
    {
        const uint8_t state = work->states[f->a[i]];
        all = state == IROPT_OVERDEFINED;
        if (state == IROPT_CONSTANT)
        {
            if (op == IR_CBR)
            {
                target = work->values[f->a[i]].low != 0 ? f->b[i] : f->c[i];
            }
            else
            {
                target = f->extra[f->b[i]];
                for (uint32_t entry = 0; entry < f->c[i]; entry += 1)
                {
                    if (ir_optimize_equal(work->values[f->a[i]], f->constants[f->extra[f->b[i] + 1 + entry * 2]]))
                    {
                        target = f->extra[f->b[i] + 2 + entry * 2];
                    }
                }
            }
        }
    }
    else if (op == IR_BR_INDIRECT)
    {
        // It may go to any of its labels (its list's, a jump table's, or every label): no address it holds is known to be
        // one label's rather than another's.
        all = true;
    }
    bool changed = false;
    for (uint32_t edge = work->cfg.successor_offsets[block]; edge < work->cfg.successor_offsets[(uint64_t)block + 1]; edge += 1)
    {
        if (all || work->cfg.successors[edge] == target)
        {
            changed = ir_optimize_mark_edge(work, edge, queue) || changed;
        }
    }
    return changed;
}

// The optimizer's hot functions start lines of their own, as the verifier's do (ir.c's ir_check_rows), so that
// where the code before them ends doesn't move their loops within lines (#786).
static __attribute__((aligned(64))) bool ir_optimize_visit(IrOptimizeWork* work, uint32_t i, bool queue)
{
    bool changed = false;
    if (work->blocks[work->cfg.instruction_blocks[i]] != 0)
    {
        const IrFunction* f = work->function;
        const uint32_t op = f->op[i];
        // The lattice only falls, so no transfer can change an overdefined value: its visits skip it. A join's phi is
        // queued again by each incoming edge and value, and would otherwise meet all of them on every visit (#1729).
        if (work->states[i] != IROPT_OVERDEFINED)
        {
            if (ir_vector_type(f->type[i]) || op == IR_VCMP || (op == IR_BITCAST && ir_vector_type(f->type[f->a[i]])) ||
                (op == IR_INTRINSIC && f->c[i] == BUSTER_IR_INTRINSIC_BITSHUFFLE))
            {
                changed = ir_optimize_simd_visit(work, i, queue);
            }
            else
            {
                IrConstant value = { 0 };
                const uint8_t state = ir_optimize_transfer(work, i, &value, &work->statistics.sccp_phi_incoming);
                changed = ir_optimize_publish(work, i, state, value, queue);
            }
        }
        if (ir_terminator_table[work->function->op[i]] != 0)
        {
            changed = ir_optimize_control(work, i, queue) || changed;
        }
        work->statistics.sccp_visits += 1;
    }
    return changed;
}

// A safety net, not a step verified IR takes: every value in an executable block has operands that dominate it, and a
// phi's block became executable by an edge whose incoming value's block was executable before, so the worklist's fixed
// point leaves none of them unknown. With a trap here, #2924's review found it never fired over the IR and Tier 1
// suites, the metamorphic cases, test-ir-source --passes and c-testsuite's subset; it keeps a transfer that answers
// unknown from known operands sound, by overdefining what is left and visiting its users again.
static bool ir_optimize_settle_unknown(IrOptimizeWork* work, bool queue)
{
    bool changed = false;
    for (uint32_t i = 0; i < work->function->instruction_count; i += 1)
    {
        if (work->blocks[work->cfg.instruction_blocks[i]] != 0 && work->states[i] == IROPT_UNKNOWN)
        {
            changed = ir_optimize_publish(work, i, IROPT_OVERDEFINED, (IrConstant){ 0 }, queue) || changed;
        }
    }
    return changed;
}

static __attribute__((aligned(64))) void ir_optimize_sccp_worklist(IrOptimizeWork* work)
{
    for (uint32_t i = 0; i < work->function->instruction_count; i += 1)
    {
        if (work->blocks[work->cfg.instruction_blocks[i]] != 0)
        {
            ir_optimize_enqueue(work, i);
        }
    }
    bool pending = true;
    while (pending)
    {
        while (work->queued_count != 0 || work->phi_count != 0)
        {
            const uint32_t i = ir_optimize_dequeue_sccp(work);
            // A constant phi queued again, by a new edge into its block or a changed incoming value, waits until nothing
            // else is queued, so that the edges and values reaching a join in one wave share one visit (#1729).
            const bool defer = work->queued_count != 0 && work->states[i] == IROPT_CONSTANT && work->function->op[i] == IR_PHI;
            if (!defer || !ir_optimize_defer_phi(work, i))
            {
                ir_optimize_visit(work, i, true);
            }
        }
        pending = ir_optimize_settle_unknown(work, true);
    }
}

static uint32_t ir_optimize_single_successor(const IrOptimizeWork* work, uint32_t block)
{
    uint32_t target = BUSTER_IR_NONE;
    uint32_t count = 0;
    for (uint32_t edge = work->cfg.successor_offsets[block]; edge < work->cfg.successor_offsets[(uint64_t)block + 1]; edge += 1)
    {
        if (work->edges[edge] != 0)
        {
            target = work->cfg.successors[edge];
            count += 1;
        }
    }
    if (count != 1)
    {
        target = BUSTER_IR_NONE;
    }
    return target;
}

#include "ir_optimize_layout.c"

// 1 is an unconditional effect; 2 is a potential fault or floating-environment effect, discharged only by
// a successful constant transfer. Loads remain roots even when nonvolatile: there is no dereferenceability proof. 3 is a
// vector comparison (#141's element types). SIMD floating arithmetic and comparisons are roots whatever SCCP learns:
// it folds a value only where every MXCSR gives it (ir_optimize_simd.c), and the rewrite keeps the original row, with
// its operands live, for its flags and traps.
// An integer comparison has no such effect and goes where its mask is unused.
static const uint8_t ir_optimize_roots[BUSTER_IR_OP_TABLE] = {
        [IR_LOAD] = 1,
        [IR_STORE] = 1,
        [IR_CALL] = 1,
        [IR_CALL_INDIRECT] = 1,
        [IR_ALLOCA] = 1,
        [IR_STACK_SAVE] = 1,
        [IR_STACK_RESTORE] = 1,
        [IR_LIFETIME] = 1,
        [IR_FENCE] = 1,
        [IR_ATOMIC_RMW] = 1,
        [IR_MASKED_LOAD] = 1,
        [IR_MASKED_STORE] = 1,
        [IR_COMPRESS_STORE] = 1,
        [IR_GATHER] = 1,
        [IR_SCATTER] = 1,
        [IR_BR] = 1,
        [IR_CBR] = 1,
        [IR_SWITCH] = 1,
        [IR_BR_INDIRECT] = 1,
        [IR_RET] = 1,
        [IR_UNREACHABLE] = 1,
        [IR_SDIV] = 2,
        [IR_UDIV] = 2,
        [IR_SREM] = 2,
        [IR_UREM] = 2,
        [IR_SHL] = 2,
        [IR_LSHR] = 2,
        [IR_ASHR] = 2,
        [IR_FADD] = 2,
        [IR_FSUB] = 2,
        [IR_FMUL] = 2,
        [IR_FDIV] = 2,
        [IR_FMA] = 2,
        [IR_FCMP] = 2,
        [IR_FTRUNC] = 2,
        [IR_FEXT] = 2,
        [IR_SITOFP] = 2,
        [IR_UITOFP] = 2,
        [IR_FPTOSI] = 2,
        [IR_FPTOUI] = 2,
        [IR_VCMP] = 3,
};

static bool ir_optimize_root(const IrOptimizeWork* work, uint32_t i)
{
    const uint32_t kind = ir_optimize_roots[work->function->op[i]];
    const bool result = kind == 1 || (kind == 2 && work->states[i] != IROPT_CONSTANT) || ir_optimize_simd_effect(work->function, i);
    return result;
}

// The identities' operations (#2554, ir_optimize_identities), by the operand whose known value makes them return the
// other one: the right's zero (x + 0, x - 0, x | 0, x ^ 0 and a shift by zero) or the left's (0 + x, 0 | x, 0 ^ x),
// the right's one (x * 1 and a division by one) or the left's (1 * x), and the right's all-ones or the left's (x & -1).
#define BUSTER_IR_OPTIMIZE_RIGHT_ZERO 1u
#define BUSTER_IR_OPTIMIZE_LEFT_ZERO 2u
#define BUSTER_IR_OPTIMIZE_RIGHT_ONE 4u
#define BUSTER_IR_OPTIMIZE_LEFT_ONE 8u
#define BUSTER_IR_OPTIMIZE_RIGHT_ONES 16u
#define BUSTER_IR_OPTIMIZE_LEFT_ONES 32u
// A conversion back to its operand's operand's type (#3311): a bitcast of a bitcast, and a truncation of an extension.
// SROA's eightbytes (ir_sroa_widen) carry a double's bits as an i64 and a narrow field's as its extension. An `and` of
// an undef is no identity: SCCP folds it to zero (ir_optimize_transfer, #3424).
#define BUSTER_IR_OPTIMIZE_ROUND_TRIP 64u
static const uint8_t ir_optimize_identity_kinds[BUSTER_IR_OP_TABLE] = {
    [IR_BITCAST] = BUSTER_IR_OPTIMIZE_ROUND_TRIP,
    [IR_TRUNC] = BUSTER_IR_OPTIMIZE_ROUND_TRIP,
    [IR_ADD] = BUSTER_IR_OPTIMIZE_RIGHT_ZERO | BUSTER_IR_OPTIMIZE_LEFT_ZERO,
    [IR_SUB] = BUSTER_IR_OPTIMIZE_RIGHT_ZERO,
    [IR_OR] = BUSTER_IR_OPTIMIZE_RIGHT_ZERO | BUSTER_IR_OPTIMIZE_LEFT_ZERO,
    [IR_XOR] = BUSTER_IR_OPTIMIZE_RIGHT_ZERO | BUSTER_IR_OPTIMIZE_LEFT_ZERO,
    [IR_SHL] = BUSTER_IR_OPTIMIZE_RIGHT_ZERO,
    [IR_LSHR] = BUSTER_IR_OPTIMIZE_RIGHT_ZERO,
    [IR_ASHR] = BUSTER_IR_OPTIMIZE_RIGHT_ZERO,
    [IR_MUL] = BUSTER_IR_OPTIMIZE_RIGHT_ONE | BUSTER_IR_OPTIMIZE_LEFT_ONE,
    [IR_UDIV] = BUSTER_IR_OPTIMIZE_RIGHT_ONE,
    [IR_SDIV] = BUSTER_IR_OPTIMIZE_RIGHT_ONE,
    [IR_AND] = BUSTER_IR_OPTIMIZE_RIGHT_ONES | BUSTER_IR_OPTIMIZE_LEFT_ONES,
};

// The identities' candidates among `count` (at most 64) operations, a bit each, by their opcodes' kinds. Only these few
// read their operands' lattice states.
static uint64_t ir_optimize_identity_candidates(const uint8_t* operations, uint32_t count)
{
    uint64_t candidates = 0;
    for (uint32_t lane = 0; lane < count; lane += 1)
    {
        candidates |= (uint64_t)(ir_optimize_identity_kinds[operations[lane]] != 0) << lane;
    }
    return candidates;
}

// Whether SCCP knows `value`, of `type`'s bits (I1 to I64), is `expected` (zero, one or all ones) at those bits; or, for
// zero, whether it is an undef (#3311), which may be any value, zero among them: an `or`, `xor` or `add` of one is its
// other operand. Never the value forwarded in its place (#3424): an undef that reaches a phi has no definition.
static bool ir_optimize_known(const IrOptimizeWork* work, uint32_t value, uint32_t type, uint64_t expected)
{
    const uint32_t bits = ir_type_bits[type];
    const uint64_t mask = bits >= 64 ? UINT64_MAX : (UINT64_C(1) << bits) - 1;
    const bool undefined = expected == 0 && work->function->op[value] == IR_UNDEF;
    const bool result = (work->states[value] == IROPT_CONSTANT && (work->values[value].low & mask) == (expected & mask)) || undefined;
    return result;
}

// Whether `value` is a zero extension whose source's bits SCCP knows `mask` (of the same type) keeps all of (#3311): an
// `and` of the two is the extension. SROA's eightbytes (ir_sroa_widen) clear a field's bits in a zeroed word and or the
// field's extension in, which leaves this mask on a 32-bit value's extension.
static bool ir_optimize_kept_extension(const IrOptimizeWork* work, uint32_t value, uint32_t mask)
{
    const IrFunction* f = work->function;
    const bool extension = f->op[value] == IR_ZEXT && f->type[f->a[value]] >= IR_I1 && f->type[f->a[value]] <= IR_I64;
    const uint32_t bits = extension ? ir_type_bits[f->type[f->a[value]]] : 64;
    const uint64_t low = bits >= 64 ? UINT64_MAX : (UINT64_C(1) << bits) - 1;
    return extension && work->states[mask] == IROPT_CONSTANT && (work->values[mask].low & low) == low;
}

// The operand instruction i returns unchanged by its kinds (ir_optimize_identity_kinds) and SCCP's facts, or
// BUSTER_IR_NONE: also an `and` of a zero extension and a mask that keeps its source's bits (#3311).
static uint32_t ir_optimize_identity_source(const IrOptimizeWork* work, const uint32_t* forward, uint32_t i, uint32_t type)
{
    const IrFunction* f = work->function;
    const uint32_t kind = ir_optimize_identity_kinds[f->op[i]];
    // Its operands through the identities found before it (#3311), whose values they are: an `or` of an `and` of a zero
    // extension that keeps its bits is that extension's `or`.
    uint32_t a = f->a[i];
    uint32_t b = f->b[i];
    for (uint32_t step = 0; forward != 0 && step < 4; step += 1)
    {
        a = a < f->instruction_count && forward[a] != BUSTER_IR_NONE ? forward[a] : a;
        b = b < f->instruction_count && forward[b] != BUSTER_IR_NONE ? forward[b] : b;
    }
    const bool ones = (kind & BUSTER_IR_OPTIMIZE_RIGHT_ONES) != 0;
    const bool right = ((kind & BUSTER_IR_OPTIMIZE_RIGHT_ZERO) != 0 && ir_optimize_known(work, b, type, 0)) || ((kind & BUSTER_IR_OPTIMIZE_RIGHT_ONE) != 0 && ir_optimize_known(work, b, type, 1)) ||
                       ((kind & BUSTER_IR_OPTIMIZE_RIGHT_ONES) != 0 && ir_optimize_known(work, b, type, UINT64_MAX)) || (ones && ir_optimize_kept_extension(work, a, b));
    const bool left = ((kind & BUSTER_IR_OPTIMIZE_LEFT_ZERO) != 0 && ir_optimize_known(work, a, type, 0)) || ((kind & BUSTER_IR_OPTIMIZE_LEFT_ONE) != 0 && ir_optimize_known(work, a, type, 1)) ||
                      ((kind & BUSTER_IR_OPTIMIZE_LEFT_ONES) != 0 && ir_optimize_known(work, a, type, UINT64_MAX)) || (ones && ir_optimize_kept_extension(work, b, a));
    const uint32_t inner = (kind & BUSTER_IR_OPTIMIZE_ROUND_TRIP) != 0 && a < f->instruction_count ? f->a[a] : BUSTER_IR_NONE;
    const bool round = inner < f->instruction_count && f->type[inner] == type &&
                       ((f->op[i] == IR_BITCAST && f->op[a] == IR_BITCAST) || (f->op[i] == IR_TRUNC && (f->op[a] == IR_ZEXT || f->op[a] == IR_SEXT)));
    const uint32_t result = right ? a : left ? b : round ? inner : BUSTER_IR_NONE;
    return result;
}

// Identities' forwarding (#2554), after SCCP and before DCE: an integer operation, I1 to I64, of a reachable block that
// returns one of its operands unchanged by SCCP's facts (ir_optimize_identity_kinds: a shift by zero, Lua's instruction
// decoding's `>> 0`, a multiplication by one, a C `n * sizeof (char)`, and the rest) forwards that operand, of its own
// type; and a conversion of an integer, f32 or f64 back to its operand's operand's type (#3311) forwards that value. Its users read the operand in its place (ir_optimize_rewrite), DCE marks the operand rather than it (a shift's
// root with it, ir_optimize_dce) and it is gone. An operand defines a value that dominates the operation, which
// dominates the operation's users, so every use stays dominated. A chain of them forwards its first operand that isn't
// one, found with path compression. A result SCCP folded and a vector's stay as they are. False where the map (`count`
// words, in scratch, made at the first identity) has no room; work->forward stays null where nothing forwards.
static bool ir_optimize_identities(IrOptimizeWork* work, Arena* scratch)
{
    const IrFunction* f = work->function;
    const uint32_t count = f->instruction_count;
    bool ok = true;
    uint32_t* forward = 0;
    for (uint64_t first = 0; ok && first < count; first += 64)
    {
        const uint32_t lanes = count - first < 64 ? (uint32_t)(count - first) : 64;
        uint64_t candidates = ir_optimize_identity_candidates(f->op + first, lanes);
        while (ok && candidates != 0)
        {
            const uint32_t i = (uint32_t)first + (uint32_t)__builtin_ctzll(candidates);
            candidates &= candidates - 1;
            const uint32_t type = f->type[i];
            uint32_t source = BUSTER_IR_NONE;
            const bool scalar = (type >= IR_I1 && type <= IR_I64) || type == IR_F32 || type == IR_F64;
            if (scalar && work->blocks[work->cfg.instruction_blocks[i]] != 0 && work->states[i] != IROPT_CONSTANT)
            {
                source = ir_optimize_identity_source(work, forward, i, type);
                source = source != BUSTER_IR_NONE && f->type[source] == type ? source : BUSTER_IR_NONE;
            }
            if (source != BUSTER_IR_NONE && forward == 0)
            {
                forward = ir_allocate(scratch, count, sizeof(uint32_t), &ok);
                if (ok)
                {
                    memset(forward, 0xff, (uint64_t)count * sizeof(uint32_t));
                }
            }
            if (ok && source != BUSTER_IR_NONE)
            {
                forward[i] = source;
            }
        }
    }
    for (uint32_t i = 0; ok && forward != 0 && i < count; i += 1)
    {
        if (forward[i] != BUSTER_IR_NONE)
        {
            uint32_t root = forward[i];
            while (forward[root] != BUSTER_IR_NONE)
            {
                root = forward[root];
            }
            for (uint32_t at = i; forward[at] != root;)
            {
                const uint32_t next = forward[at];
                forward[at] = root;
                at = next;
            }
        }
    }
    work->forward = ok ? forward : 0;
    return ok;
}

// The value that instruction `value`'s users read: its forwarded operand where it has one (#2554), else itself.
static uint32_t ir_optimize_forwarded(const IrOptimizeWork* work, uint32_t value)
{
    const uint32_t result = work->forward != 0 && work->forward[value] != BUSTER_IR_NONE ? work->forward[value] : value;
    return result;
}

static __attribute__((aligned(64))) bool ir_optimize_mark_operands(IrOptimizeWork* work, uint32_t i, bool queue)
{
    const IrFunction* f = work->function;
    bool changed = false;
    const bool collapsed_branch = (f->op[i] == IR_CBR || f->op[i] == IR_SWITCH) && ir_optimize_single_successor(work, work->cfg.instruction_blocks[i]) != BUSTER_IR_NONE;
    const uint32_t forwarded = ir_optimize_forwarded(work, i);
    if (forwarded != i)
    {
        // An identity (#2554): what its users read is its operand alone.
        changed = work->live[forwarded] == 0;
        work->live[forwarded] = 1;
        if (changed && queue)
        {
            ir_optimize_enqueue(work, forwarded);
        }
    }
    else if ((work->states[i] != IROPT_CONSTANT || ir_optimize_simd_effect(f, i)) && !collapsed_branch)
    {
        const uint64_t count = ir_operand_count(f, i);
        for (uint32_t number = 0; number < count; number += 1)
        {
            const IrOperand operand = ir_operand(f, i, number, work->cfg.instruction_blocks[i]);
            const bool executable = f->op[i] != IR_PHI || work->edges[ir_optimize_edge(&work->cfg, operand.block, work->cfg.instruction_blocks[i])] != 0;
            if (executable && work->live[operand.value] == 0)
            {
                work->live[operand.value] = 1;
                changed = true;
                if (queue)
                {
                    ir_optimize_enqueue(work, operand.value);
                }
            }
        }
    }
    work->statistics.dce_visits += 1;
    return changed;
}

static __attribute__((aligned(64))) void ir_optimize_dce_worklist(IrOptimizeWork* work)
{
    for (uint32_t i = 0; i < work->function->instruction_count; i += 1)
    {
        if (work->live[i] != 0)
        {
            ir_optimize_enqueue(work, i);
        }
    }
    while (work->queued_count != 0)
    {
        ir_optimize_mark_operands(work, ir_optimize_dequeue(work), true);
    }
}

static __attribute__((aligned(64))) void ir_optimize_dce(IrOptimizeWork* work, IrOptimizeOptions options)
{
    const IrFunction* f = work->function;
    for (uint32_t block = 0; block < f->block_count; block += 1)
    {
        if (work->blocks[block] != 0)
        {
            const uint32_t first = f->block_offsets[block];
            const uint32_t end = f->block_offsets[(uint64_t)block + 1];
            if ((options.passes & BUSTER_IR_OPTIMIZE_DCE) == 0)
            {
                memset(work->live + first, 1, end - first);
            }
            else
            {
                for (uint32_t i = first; i < end; i += 1)
                {
                    work->live[i] = ir_optimize_root(work, i);
                }
            }
        }
    }
    // An identity is no root (a shift is one, #2554): only its users keep its operand.
    for (uint32_t i = 0; work->forward != 0 && (options.passes & BUSTER_IR_OPTIMIZE_DCE) != 0 && i < f->instruction_count; i += 1)
    {
        work->live[i] = work->forward[i] != BUSTER_IR_NONE ? 0 : work->live[i];
    }
    if ((options.passes & BUSTER_IR_OPTIMIZE_DCE) != 0)
    {
        ir_optimize_dce_worklist(work);
    }
}

// Structural verification has already checked same-block use order, including in dead regions. Only executable
// source regions impose cross-block dominance here: the optimizer will remove the other regions before selection.
static IrCheck ir_optimize_check_reachable(const IrFunction* function, const IrCfg* cfg, const Dominators* dominators)
{
    IrCheck check = ir_check(IR_OK, BUSTER_IR_NONE, 0);
    for (uint32_t i = 0; check.error == IR_OK && i < function->instruction_count; i += 1)
    {
        const uint64_t count = ir_operand_count(function, i);
        for (uint32_t number = 0; check.error == IR_OK && number < count; number += 1)
        {
            const IrOperand operand = ir_operand(function, i, number, cfg->instruction_blocks[i]);
            if (dominators->rpo_index[operand.block] != BUSTER_DOMINATOR_NONE && !dominators_dominates(dominators, cfg->instruction_blocks[operand.value], operand.block))
            {
                check = ir_check(IR_ERROR_DOMINANCE, i, operand.position);
            }
        }
    }
    return check;
}

// `simd`: admission for callers that model vectors and masks. SCCP, GVN and LICM set it; SROA's default does not.
// The first SIMD SCCP transfer allocates its sparse wide lattice, so this common preparation stays scalar-sized.
// Dominators own their matrix budget and scalar fallback (#1352).
static __attribute__((aligned(64))) IrCheck ir_optimize_prepare(IrOptimizeWork* work, const IrFunction* function, Arena* output, Arena* scratch, bool simd)
{
    work->function = function;
    work->scratch = scratch;
    // Retain the CFG built by the structural verifier. No input changes before the optimizer consumes it, so
    // rebuilding the same graph here would repeat its edge enumeration, deduplication and instruction map. A verified
    // function (`validated`) has its CFG built alone.
    IrCheck check = work->validated ? ir_check(ir_cfg_validated(function, scratch, output, &work->cfg), BUSTER_IR_NONE, 0) : ir_prepare_cfg(function, scratch, output, &work->cfg, false);
    const bool needs_order = !work->validated && check.error == IR_OK;
    if (check.error == IR_OK && !simd && ir_function_has_simd(function))
    {
        check.error = IR_ERROR_UNSUPPORTED;
    }
    // Entry phis are forbidden by the shared IR contract: initial invocation has no predecessor value.
    // Pruning their dead predecessors cannot invent an undef value or emit a zero-input phi.
    if (check.error == IR_OK && function->block_count != 0 && function->op[0] == IR_PHI)
    {
        check = ir_check(IR_ERROR_PHI, 0, 0);
    }
    if (check.error == IR_OK)
    {
        const DominatorCfg cfg = {
            .block_count = work->cfg.block_count,
            .edge_count = work->cfg.edge_count,
            .entry = function->block_count == 0 ? BUSTER_DOMINATOR_NONE : 0,
            .successor_offsets = work->cfg.successor_offsets,
            .successors = work->cfg.successors,
            .predecessor_offsets = work->cfg.predecessor_offsets,
            .predecessors = work->cfg.predecessors,
        };
        DominatorOptions options = dominators_options();
        options.outputs = work->dominator_outputs;
        const DominatorStatus status = dominators_analyze(scratch, output, &cfg, options, &work->dominators);
        // A loop analysis past its matrices' limit is a function the pass that asked for it leaves as it was.
        check.error = status == DOMINATOR_OK            ? IR_OK :
                      status == DOMINATOR_NO_MEMORY     ? IR_ERROR_MEMORY :
                      status == DOMINATOR_MATRIX_LIMIT  ? IR_ERROR_UNSUPPORTED :
                                                          IR_ERROR_DOMINANCE;
    }
    if (needs_order)
    {
        // The tree reads only the verified CFG. One operand walk now proves both local order and
        // reachable dominance. A dead cross-block use is legal here; use the original diagnostic order
        // for an inconclusive walk, or when admission or tree construction failed.
        const IrDominance tree = {
            .block_count = function->block_count,
            .enter = work->dominators.preorder,
            .leave = work->dominators.subtree_end,
        };
        if (check.error != IR_OK || ir_check_dominance(function, &work->cfg, &tree).error != IR_OK)
        {
            const IrCheck local = ir_check_dominance(function, &work->cfg, NULL);
            if (local.error != IR_OK)
            {
                check = local;
            }
            else if (check.error == IR_OK)
            {
                check = ir_optimize_check_reachable(function, &work->cfg, &work->dominators);
            }
        }
    }
    // The use lists consume the same verified revision without repeating its shape, row or graph checks.
    if (check.error == IR_OK && !work->without_uses)
    {
        check.error = ir_uses_validated(function, scratch, output, &work->uses);
    }
    if (check.error == IR_OK && !work->analysis_only)
    {
        bool ok = true;
        work->states = ir_allocate(scratch, function->instruction_count, sizeof(uint8_t), &ok);
        work->values = ir_allocate(scratch, function->instruction_count, sizeof(IrConstant), &ok);
        work->blocks = ir_allocate(scratch, function->block_count, sizeof(uint8_t), &ok);
        work->edges = ir_allocate(scratch, work->cfg.edge_count, sizeof(uint8_t), &ok);
        work->live = ir_allocate(scratch, function->instruction_count, sizeof(uint8_t), &ok);
        work->queued = ir_allocate(scratch, function->instruction_count, sizeof(uint8_t), &ok);
        work->queue = ir_allocate(scratch, function->instruction_count, sizeof(uint32_t), &ok);
        if (!ok)
        {
            check.error = IR_ERROR_MEMORY;
        }
    }
    return check;
}

static uint32_t ir_optimize_phi_inputs(const IrOptimizeWork* work, uint32_t instruction)
{
    const IrFunction* f = work->function;
    uint32_t count = 0;
    for (uint32_t incoming = 0; incoming < f->b[instruction]; incoming += 1)
    {
        const uint32_t predecessor = f->extra[f->a[instruction] + incoming * 2];
        count += work->edges[ir_optimize_edge(&work->cfg, predecessor, work->cfg.instruction_blocks[instruction])] != 0;
    }
    return count;
}

// The rewrite's structured-operand arms by operation: a phi's live incoming pairs, a call's
// argument list, a cbr's two targets, a switch's case list, or a br_indirect's label list. The
// op-indexed read keeps the per-instruction dispatch a load where the compare chain lowered to a
// jump table's indirect branch (#786).
static const uint8_t ir_optimize_rewrite_kinds[BUSTER_IR_OP_TABLE] = {
    [IR_PHI] = 1,
    [IR_CALL] = 2,
    [IR_CALL_INDIRECT] = 2,
    [IR_CBR] = 3,
    [IR_SWITCH] = 4,
    [IR_BR_INDIRECT] = 5,
};

// CFG cleanup's merges (#139): a kept block (not threaded away, executable) other than the entry, without a label, whose one
// incoming edge after threading comes from a block whose one executable successor it is, through a br, or a cbr or switch
// that SCCP left one way, joins that predecessor: the rewrite drops the predecessor's jump and goes on with the block's
// instructions. A chain of such blocks becomes one block. `next` takes each block's merged successor (BUSTER_IR_NONE for
// none) and `heads` each block's chain head, itself for a block that merges into none: the predecessors' functional graph
// resolved by ir_optimize_thread_targets, as the threading's targets
// are. A merged block's phis each have one executable incoming value, which becomes the phi's users' operand, as an
// identity's does (`work->forward`); its phis folded to constants stay constants. The predecessor counts are one pass over
// the executable edges, a scatter of one count per edge. Returns the merges' count in *merges.
static IrError ir_optimize_merges(IrOptimizeWork* work, const uint32_t* threads, Arena* scratch, uint32_t* next, uint32_t* heads, uint32_t* merges)
{
    const IrFunction* f = work->function;
    const uint32_t count = f->block_count;
    bool ok = true;
    uint32_t* incoming = ir_allocate(scratch, count, sizeof(uint32_t), &ok);
    uint32_t* from = ir_allocate(scratch, count, sizeof(uint32_t), &ok);
    uint32_t* direct = ir_allocate(scratch, count, sizeof(uint32_t), &ok);
    uint8_t* labelled = ir_allocate(scratch, count, sizeof(uint8_t), &ok);
    IrError error = ok ? IR_OK : IR_ERROR_MEMORY;
    *merges = 0;
    for (uint32_t block = 0; error == IR_OK && block < count; block += 1)
    {
        incoming[block] = 0;
        labelled[block] = 0;
        next[block] = BUSTER_IR_NONE;
        direct[block] = block;
    }
    // A label's block keeps its own block: its address is taken (#131), at its block as threaded.
    for (uint32_t label = 0; error == IR_OK && label < f->label_count; label += 1)
    {
        const uint32_t block = f->labels[label];
        if (block != BUSTER_IR_NONE)
        {
            labelled[block] = 1;
            labelled[threads[block]] = 1;
        }
    }
    for (uint32_t block = 0; error == IR_OK && block < count; block += 1)
    {
        if (work->blocks[block] != 0 && threads[block] == block)
        {
            for (uint32_t edge = work->cfg.successor_offsets[block]; edge < work->cfg.successor_offsets[(uint64_t)block + 1]; edge += 1)
            {
                const uint32_t target = threads[work->cfg.successors[edge]];
                incoming[target] += work->edges[edge] != 0;
                from[target] = work->edges[edge] != 0 ? block : from[target];
            }
        }
    }
    for (uint32_t block = 1; error == IR_OK && block < count; block += 1)
    {
        const bool kept = work->blocks[block] != 0 && threads[block] == block && labelled[block] == 0 && incoming[block] == 1;
        const uint32_t predecessor = kept ? from[block] : BUSTER_IR_NONE;
        const uint32_t successor = predecessor != BUSTER_IR_NONE && predecessor != block ? ir_optimize_single_successor(work, predecessor) : BUSTER_IR_NONE;
        const uint8_t jump = successor != BUSTER_IR_NONE ? f->op[f->block_offsets[(uint64_t)predecessor + 1] - 1] : IR_OP_COUNT;
        if (successor != BUSTER_IR_NONE && threads[successor] == block && (jump == IR_BR || jump == IR_CBR || jump == IR_SWITCH))
        {
            direct[block] = predecessor;
            next[predecessor] = block;
            *merges += 1;
        }
    }
    if (error == IR_OK && !ir_optimize_thread_targets(scratch, direct, count, heads))
    {
        error = IR_ERROR_MEMORY;
    }
    // Every chain starts at a block that merges into none: the entry's reachable graph has no cycle of merges, since a
    // cycle's first block reached would have two predecessors. A head that merges anyway (a corrupt graph) undoes them all.
    bool chained = true;
    for (uint32_t block = 0; error == IR_OK && block < count; block += 1)
    {
        chained = chained && direct[heads[block]] == heads[block];
    }
    for (uint32_t block = 0; error == IR_OK && !chained && block < count; block += 1)
    {
        next[block] = BUSTER_IR_NONE;
        heads[block] = block;
        *merges = 0;
    }
    // The merged blocks' phis: each one's one executable incoming value.
    for (uint32_t block = 0; error == IR_OK && *merges != 0 && block < count; block += 1)
    {
        for (uint32_t i = f->block_offsets[block]; heads[block] != block && i < f->block_offsets[(uint64_t)block + 1] && f->op[i] == IR_PHI; i += 1)
        {
            uint32_t value = BUSTER_IR_NONE;
            for (uint32_t k = 0; work->states[i] != IROPT_CONSTANT && k < f->b[i]; k += 1)
            {
                const uint32_t predecessor = f->extra[f->a[i] + k * 2];
                value = work->edges[ir_optimize_edge(&work->cfg, predecessor, block)] != 0 ? f->extra[f->a[i] + k * 2 + 1] : value;
            }
            if (value != BUSTER_IR_NONE && work->forward == 0)
            {
                work->forward = ir_allocate(scratch, f->instruction_count, sizeof(uint32_t), &ok);
                error = ok ? IR_OK : IR_ERROR_MEMORY;
                if (ok)
                {
                    memset(work->forward, 0xff, (uint64_t)f->instruction_count * sizeof(uint32_t));
                }
            }
            if (value != BUSTER_IR_NONE && work->forward != 0)
            {
                work->forward[i] = value;
            }
        }
    }
    // Every forward goes to its root, so the rewrite reads one step: a forwarded phi's value may be another merged
    // block's phi or an identity, and an identity's root (ir_optimize_identities resolved them before the merges) may
    // be a merged block's phi, now forwarded itself.
    for (uint32_t i = 0; error == IR_OK && *merges != 0 && work->forward != 0 && i < f->instruction_count; i += 1)
    {
        if (work->forward[i] != BUSTER_IR_NONE)
        {
            uint32_t root = work->forward[i];
            while (work->forward[root] != BUSTER_IR_NONE)
            {
                root = work->forward[root];
            }
            for (uint32_t at = i; work->forward[at] != root;)
            {
                const uint32_t following = work->forward[at];
                work->forward[at] = root;
                at = following;
            }
        }
    }
    return error;
}

static IrSizes ir_optimize_metadata_sizes(const IrFunction* f)
{
    IrSizes sizes = {
        .constant_count = f->constant_count,
        .vector_constant_count = f->vector_constant_count,
        .row_count = f->row_count,
        .asm_body_count = f->asm_body_count,
        .slot_count = f->slot_count,
        .address_count = f->address_count,
        .call_type_count = f->call_type_count,
        .parameter_count = f->parameter_count,
        .label_count = f->label_count,
        .abi_call_count = f->abi_call_count,
        .passed_count = f->passed_count,
    };
    return sizes;
}

static void ir_optimize_copy_metadata(const IrFunction* f, IrFunction* target)
{
    target->result_type = f->result_type;
    target->symbol_count = f->symbol_count;
    if (f->constant_count != 0)
    {
        memcpy(target->constants, f->constants, (uint64_t)f->constant_count * sizeof(IrConstant));
    }
    // A vector constant's payload (#141), which its IR_VCONST indexes as before.
    if (f->vector_constant_count != 0)
    {
        memcpy(target->vector_constants, f->vector_constants, (uint64_t)f->vector_constant_count * sizeof(IrSimdValue));
    }
    // The machine rows (#141), which the row calls index as before.
    if (f->row_count != 0)
    {
        memcpy(target->rows, f->rows, (uint64_t)f->row_count * sizeof(Tier0Operation));
    }
    // The asm bodies (#1839), which the body calls index as before.
    if (f->asm_body_count != 0)
    {
        memcpy(target->asm_bodies, f->asm_bodies, (uint64_t)f->asm_body_count * sizeof(IrAsmBody));
    }
    if (f->slot_count != 0)
    {
        memcpy(target->slots, f->slots, (uint64_t)f->slot_count * sizeof(IrSlot));
    }
    if (f->address_count != 0)
    {
        memcpy(target->addresses, f->addresses, (uint64_t)f->address_count * sizeof(IrAddress));
    }
    if (f->call_type_count != 0)
    {
        memcpy(target->call_types, f->call_types, f->call_type_count);
    }
    if (f->parameter_count != 0)
    {
        memcpy(target->parameter_types, f->parameter_types, f->parameter_count);
    }
    if (f->abi_call_count != 0)
    {
        memcpy(target->abi_calls, f->abi_calls, (uint64_t)f->abi_call_count * sizeof(IrAbiCall));
    }
    if (f->passed_count != 0)
    {
        memcpy(target->passed, f->passed, (uint64_t)f->passed_count * sizeof(IrPassed));
    }
    target->parameter_passed = f->parameter_passed;
    target->result_size = f->result_size;
    target->result_abi = f->result_abi;
    target->variadic = f->variadic;
    target->incoming = f->incoming;
}

static __attribute__((aligned(64))) IrError ir_optimize_rewrite(IrOptimizeWork* work, Arena* output, Arena* scratch, IrOptimizeOptions options, IrFunction* result)
{
    const IrFunction* f = work->function;
    bool ok = true;
    const bool cleanup_cfg = (options.passes & BUSTER_IR_OPTIMIZE_CFG) != 0;
    uint32_t* direct = cleanup_cfg ? ir_allocate(scratch, f->block_count, sizeof(uint32_t), &ok) : NULL;
    uint32_t* threads = ir_allocate(scratch, f->block_count, sizeof(uint32_t), &ok);
    uint32_t* blocks = ir_allocate(scratch, f->block_count, sizeof(uint32_t), &ok);
    uint32_t* values = ir_allocate(scratch, f->instruction_count, sizeof(uint32_t), &ok);
    IrError error = ok ? IR_OK : IR_ERROR_MEMORY;
    for (uint32_t block = 0; ok && block < f->block_count; block += 1)
    {
        blocks[block] = BUSTER_IR_NONE;
        if (cleanup_cfg)
        {
            direct[block] = block;
            uint32_t live = 0;
            for (uint32_t i = f->block_offsets[block]; i < f->block_offsets[(uint64_t)block + 1]; i += 1)
            {
                live += work->live[i] != 0 && ir_optimize_forwarded(work, i) == i;
            }
            const uint32_t target = ir_optimize_single_successor(work, block);
            if (block != 0 && work->blocks[block] != 0 && live == 1 && target != BUSTER_IR_NONE && f->op[f->block_offsets[target]] != IR_PHI)
            {
                direct[block] = target;
            }
        }
        else
        {
            threads[block] = block;
        }
    }
    if (ok && cleanup_cfg && !ir_optimize_thread_targets(scratch, direct, f->block_count, threads))
    {
        error = IR_ERROR_MEMORY;
    }
    // Each block's merged successor and chain head (ir_optimize_merges), with BUSTER_IR_OPTIMIZE_MERGE; else none and itself.
    uint32_t* next = ir_allocate(scratch, f->block_count, sizeof(uint32_t), &ok);
    uint32_t* heads = ir_allocate(scratch, f->block_count, sizeof(uint32_t), &ok);
    error = error == IR_OK && !ok ? IR_ERROR_MEMORY : error;
    uint32_t merges = 0;
    if (error == IR_OK && (options.passes & BUSTER_IR_OPTIMIZE_MERGE) != 0)
    {
        error = ir_optimize_merges(work, threads, scratch, next, heads, &merges);
    }
    for (uint32_t block = 0; error == IR_OK && (options.passes & BUSTER_IR_OPTIMIZE_MERGE) == 0 && block < f->block_count; block += 1)
    {
        next[block] = BUSTER_IR_NONE;
        heads[block] = block;
    }
    uint32_t* order = NULL;
    uint32_t order_count = f->block_count;
    if (error == IR_OK && (options.passes & BUSTER_IR_OPTIMIZE_LAYOUT) != 0)
    {
        order = ir_allocate(scratch, f->block_count, sizeof(uint32_t), &ok);
        error = ok ? ir_optimize_layout_order(work, threads, scratch, order, &order_count) : IR_ERROR_MEMORY;
    }
    IrSizes sizes = ir_optimize_metadata_sizes(f);
    for (uint32_t i = 0; error == IR_OK && i < f->instruction_count; i += 1)
    {
        values[i] = BUSTER_IR_NONE;
    }
    for (uint32_t position = 0; error == IR_OK && position < order_count; position += 1)
    {
        const uint32_t head = order != NULL ? order[position] : position;
        // A chain's blocks (ir_optimize_merges) are its head's, in turn: each one's jump to the next is dropped.
        for (uint32_t block = work->blocks[head] != 0 && threads[head] == head && heads[head] == head ? head : BUSTER_IR_NONE; block != BUSTER_IR_NONE; block = next[block])
        {
            blocks[block] = block == head ? sizes.block_count++ : blocks[head];
            const uint32_t end = next[block] != BUSTER_IR_NONE ? f->block_offsets[(uint64_t)block + 1] - 1 : f->block_offsets[(uint64_t)block + 1];
            // A folded phi becomes a constant after every surviving phi. Ordinary instruction order is unchanged.
            for (uint32_t phase = 0; phase < 2; phase += 1)
            {
                for (uint32_t i = f->block_offsets[block]; i < end && (phase != 0 || f->op[i] == IR_PHI); i += 1)
                {
                    const bool phi = f->op[i] == IR_PHI && work->states[i] != IROPT_CONSTANT;
                    if (work->live[i] != 0 && phi == (phase == 0) && ir_optimize_forwarded(work, i) == i)
                    {
                        sizes.instruction_count += work->states[i] == IROPT_CONSTANT && ir_optimize_simd_effect(f, i);
                        values[i] = sizes.instruction_count++;
                        const uint32_t kind = ir_optimize_rewrite_kinds[f->op[i]];
                        if (work->states[i] == IROPT_CONSTANT && f->op[i] != IR_CONST && f->op[i] != IR_VCONST)
                        {
                            if (ir_vector_type(f->type[i]))
                            {
                                sizes.vector_constant_count += 1;
                            }
                            else
                            {
                                sizes.constant_count += 1;
                            }
                        }
                        else if (kind == 1)
                        {
                            sizes.extra_count += (uint64_t)ir_optimize_phi_inputs(work, i) * 2;
                        }
                        else if (kind == 2)
                        {
                            sizes.call_count += 1;
                            sizes.extra_count += f->calls[f->b[i]].argument_count;
                        }
                        else if (kind == 4 && ir_optimize_single_successor(work, block) == BUSTER_IR_NONE)
                        {
                            sizes.extra_count += 1 + (uint64_t)f->c[i] * 2;
                        }
                        else if (kind == 5 && f->b[i] != BUSTER_IR_NONE)
                        {
                            sizes.extra_count += f->c[i];
                        }
                        else if (ir_extra_value_count(f, i) != 0)
                        {
                            sizes.extra_count += ir_extra_value_count(f, i);
                        }
                    }
                }
            }
        }
    }
    // What each operand reads: its value's new index, or an identity's operand's (#2554), which the identity's users read.
    const uint32_t* operands = values;
    if (error == IR_OK && work->forward != 0)
    {
        uint32_t* resolved = ir_allocate(scratch, f->instruction_count, sizeof(uint32_t), &ok);
        error = ok ? IR_OK : IR_ERROR_MEMORY;
        for (uint32_t i = 0; error == IR_OK && i < f->instruction_count; i += 1)
        {
            resolved[i] = values[ir_optimize_forwarded(work, i)];
        }
        operands = resolved;
    }
    IrFunction candidate = { 0 };
    if (error == IR_OK)
    {
        error = ir_create(output, &sizes, &candidate);
    }
    if (error == IR_OK && !ir_debug_create(output, &candidate, f->debug))
    {
        error = IR_ERROR_MEMORY;
    }
    if (error == IR_OK)
    {
        ir_optimize_copy_metadata(f, &candidate);
        for (uint32_t label = 0; label < f->label_count; label += 1)
        {
            const uint32_t block = f->labels[label];
            candidate.labels[label] = block == BUSTER_IR_NONE || work->blocks[block] == 0 ? BUSTER_IR_NONE : blocks[threads[block]];
        }
        uint32_t extra = 0;
        uint32_t constants = f->constant_count;
        uint32_t vector_constants = f->vector_constant_count;
        uint32_t calls = 0;
        uint32_t instructions = 0;
        for (uint32_t position = 0; position < order_count; position += 1)
        {
            const uint32_t head = order != NULL ? order[position] : position;
            if (blocks[head] != BUSTER_IR_NONE && heads[head] == head)
            {
                candidate.block_offsets[blocks[head]] = instructions;
            }
            for (uint32_t block = blocks[head] != BUSTER_IR_NONE && heads[head] == head ? head : BUSTER_IR_NONE; block != BUSTER_IR_NONE; block = next[block])
            {
                const uint32_t target = ir_optimize_single_successor(work, block);
                const uint32_t end = f->block_offsets[(uint64_t)block + 1];
                for (uint32_t phase = 0; phase < 2; phase += 1)
                {
                    for (uint32_t i = f->block_offsets[block]; i < end && (phase != 0 || f->op[i] == IR_PHI); i += 1)
                    {
                        const bool phi = f->op[i] == IR_PHI && work->states[i] != IROPT_CONSTANT;
                        if (values[i] != BUSTER_IR_NONE && phi == (phase == 0))
                        {
                            const uint32_t out = values[i];
                            const uint32_t op = f->op[i];
                            candidate.op[out] = op;
                            candidate.type[out] = f->type[i];
                            candidate.flags[out] = f->flags[i];
                            candidate.alignment_log2[out] = f->alignment_log2[i];
                            candidate.a[out] = f->a[i];
                            candidate.b[out] = f->b[i];
                            candidate.c[out] = f->c[i];
                            if (work->states[i] == IROPT_CONSTANT && op != IR_CONST && op != IR_VCONST)
                            {
                                // A known floating value does not discharge its environment effects. Keep its original
                                // row immediately before the constant used by its consumers, with every operand live.
                                if (ir_optimize_simd_effect(f, i))
                                {
                                    const uint32_t effect = out - 1;
                                    const uint32_t mask = ir_value_mask(f, i);
                                    candidate.op[effect] = op;
                                    candidate.type[effect] = f->type[i];
                                    candidate.flags[effect] = f->flags[i];
                                    candidate.alignment_log2[effect] = f->alignment_log2[i];
                                    candidate.a[effect] = (mask & 1) != 0 ? operands[f->a[i]] : f->a[i];
                                    candidate.b[effect] = (mask & 2) != 0 ? operands[f->b[i]] : f->b[i];
                                    candidate.c[effect] = (mask & 4) != 0 ? operands[f->c[i]] : f->c[i];
                                    instructions += 1;
                                }
                                const bool vector = ir_vector_type(f->type[i]);
                                candidate.op[out] = vector ? IR_VCONST : IR_CONST;
                                candidate.a[out] = vector ? vector_constants : constants;
                                candidate.b[out] = BUSTER_IR_NONE;
                                candidate.c[out] = BUSTER_IR_NONE;
                                candidate.flags[out] = 0;
                                candidate.alignment_log2[out] = 0;
                                if (vector)
                                {
                                    candidate.vector_constants[vector_constants++] = work->vector_values[work->vector_indices[i]];
                                }
                                else
                                {
                                    candidate.constants[constants++] = work->values[i];
                                }
                                work->statistics.folded += 1;
                            }
                            else if (op == IR_BR || ((op == IR_CBR || op == IR_SWITCH) && target != BUSTER_IR_NONE))
                            {
                                candidate.op[out] = IR_BR;
                                candidate.flags[out] = 0;
                                candidate.a[out] = blocks[threads[target]];
                                candidate.b[out] = BUSTER_IR_NONE;
                                candidate.c[out] = BUSTER_IR_NONE;
                            }
                            else
                            {
                                const uint32_t mask = ir_value_mask(f, i);
                                if ((mask & 1) != 0)
                                {
                                    candidate.a[out] = operands[f->a[i]];
                                }
                                if ((mask & 2) != 0)
                                {
                                    candidate.b[out] = operands[f->b[i]];
                                }
                                if ((mask & 4) != 0)
                                {
                                    candidate.c[out] = operands[f->c[i]];
                                }
                                const uint32_t kind = ir_optimize_rewrite_kinds[op];
                                if (kind == 1)
                                {
                                    candidate.a[out] = extra;
                                    candidate.b[out] = 0;
                                    for (uint32_t incoming = 0; incoming < f->b[i]; incoming += 1)
                                    {
                                        const uint32_t predecessor = f->extra[f->a[i] + incoming * 2];
                                        if (work->edges[ir_optimize_edge(&work->cfg, predecessor, block)] != 0)
                                        {
                                            candidate.extra[extra++] = blocks[predecessor];
                                            candidate.extra[extra++] = operands[f->extra[f->a[i] + incoming * 2 + 1]];
                                            candidate.b[out] += 1;
                                        }
                                    }
                                }
                                else if (kind == 2)
                                {
                                    candidate.b[out] = calls;
                                    candidate.calls[calls] = f->calls[f->b[i]];
                                    candidate.calls[calls].argument_first = extra;
                                    for (uint32_t argument = 0; argument < f->calls[f->b[i]].argument_count; argument += 1)
                                    {
                                        candidate.extra[extra++] = operands[f->extra[f->calls[f->b[i]].argument_first + argument]];
                                    }
                                    calls += 1;
                                }
                                else if (kind == 3)
                                {
                                    candidate.b[out] = blocks[threads[f->b[i]]];
                                    candidate.c[out] = blocks[threads[f->c[i]]];
                                }
                                else if (kind == 4)
                                {
                                    candidate.b[out] = extra;
                                    candidate.extra[extra++] = blocks[threads[f->extra[f->b[i]]]];
                                    for (uint32_t entry = 0; entry < f->c[i]; entry += 1)
                                    {
                                        candidate.extra[extra++] = f->extra[f->b[i] + 1 + entry * 2];
                                        candidate.extra[extra++] = blocks[threads[f->extra[f->b[i] + 2 + entry * 2]]];
                                    }
                                }
                                else if (kind == 5 && f->b[i] != BUSTER_IR_NONE)
                                {
                                    // Its labels' list: label indices, which the rewrite keeps (their blocks move).
                                    candidate.b[out] = extra;
                                    for (uint32_t entry = 0; entry < f->c[i]; entry += 1)
                                    {
                                        candidate.extra[extra++] = f->extra[f->b[i] + entry];
                                    }
                                }
                                else if (ir_extra_value_count(f, i) != 0)
                                {
                                    // A ternary intrinsic's third operand, or a scatter's stored vector and mask (#1840), at its new place in the extra array.
                                    candidate.c[out] = ir_intrinsic_ternary_c(f->c[i], extra);
                                    for (uint32_t k = 0, extra_values = ir_extra_value_count(f, i); k < extra_values; k += 1)
                                    {
                                        candidate.extra[extra++] = operands[ir_extra_value(f, i, k)];
                                    }
                                }
                            }
                            instructions += 1;
                        }
                    }
                }
            }
        }
        candidate.block_offsets[candidate.block_count] = candidate.instruction_count;
        ir_debug_remap(f, &candidate, values, NULL, blocks);
        // A merged block's source regions are dropped (c_check_tier1_debug_regions.c's rule for a merger): their
        // original block's end isn't its head's, whose block they would share.
        for (uint32_t k = 0; candidate.debug != NULL && merges != 0 && k < candidate.debug->region_count; k += 1)
        {
            const uint32_t block = f->debug->regions[k].block;
            if (block != BUSTER_IR_NONE && heads[block] != block)
            {
                candidate.debug->regions[k].block = BUSTER_IR_NONE;
                candidate.debug->regions[k].kind = IR_DEBUG_BIND_UNAVAILABLE;
                candidate.debug->regions[k].value = BUSTER_IR_NONE;
            }
        }
        if (candidate.debug != NULL && work->forward != 0)
        {
            // An identity's binding is its operand's value (#2554), of the same type and bits: the remap above gave its
            // origin to nothing, since the identity has no instruction of its own.
            for (uint32_t k = 0; k < candidate.debug->binding_count; k += 1)
            {
                const IrDebugBinding original = f->debug->bindings[k];
                if (original.kind == IR_DEBUG_BIND_VALUE && ir_optimize_forwarded(work, original.value) != original.value && operands[original.value] != BUSTER_IR_NONE)
                {
                    candidate.debug->bindings[k].value = operands[original.value];
                    candidate.debug->bindings[k].kind = IR_DEBUG_BIND_VALUE;
                }
            }
            for (uint32_t k = 0; k < candidate.debug->region_count; k += 1)
            {
                const IrDebugRegion original = f->debug->regions[k];
                IrDebugRegion* region = candidate.debug->regions + k;
                if (region->block != BUSTER_IR_NONE && original.kind == IR_DEBUG_BIND_VALUE && ir_optimize_forwarded(work, original.value) != original.value &&
                    operands[original.value] != BUSTER_IR_NONE)
                {
                    region->value = operands[original.value];
                    region->kind = IR_DEBUG_BIND_VALUE;
                }
            }
        }
        if (candidate.debug != NULL)
        {
            for (uint32_t k = 0; k < candidate.debug->binding_count; k += 1)
            {
                const IrDebugBinding original = f->debug->bindings[k];
                IrDebugBinding* binding = candidate.debug->bindings + k;
                if (original.kind == IR_DEBUG_BIND_VALUE && work->states[original.value] == IROPT_CONSTANT &&
                    f->type[original.value] == original.type && original.bytes != 0 && original.bytes <= 8)
                {
                    const uint64_t literal = work->values[original.value].low;
                    binding->literal = original.bytes == 8 ? literal : literal & ((UINT64_C(1) << (original.bytes * 8)) - 1);
                    binding->value = BUSTER_IR_NONE;
                    binding->kind = IR_DEBUG_BIND_CONSTANT;
                }
            }
            for (uint32_t k = 0; k < candidate.debug->region_count; k += 1)
            {
                const IrDebugRegion original = f->debug->regions[k];
                IrDebugRegion* region = candidate.debug->regions + k;
                if (region->block != BUSTER_IR_NONE && original.kind == IR_DEBUG_BIND_VALUE && work->states[original.value] == IROPT_CONSTANT &&
                    f->type[original.value] == original.type && original.bytes != 0 && original.bytes <= 8)
                {
                    const uint64_t literal = work->values[original.value].low;
                    region->literal = original.bytes == 8 ? literal : literal & ((UINT64_C(1) << (original.bytes * 8)) - 1);
                    region->value = BUSTER_IR_NONE;
                    region->kind = IR_DEBUG_BIND_CONSTANT;
                }
            }
            // SCCP can retain a floating operation's effects immediately before its folded constant. Both records
            // originate in that operation; neither new node is inferred from a neighboring instruction's source.
            for (uint32_t i = 0; i < f->instruction_count; i += 1)
            {
                if (values[i] != BUSTER_IR_NONE && work->states[i] == IROPT_CONSTANT && ir_optimize_simd_effect(f, i))
                {
                    candidate.debug->origins[values[i] - 1] = f->debug->origins[i];
                }
            }
        }
        work->statistics.removed_instructions = f->instruction_count > candidate.instruction_count ? f->instruction_count - candidate.instruction_count : 0;
        work->statistics.removed_blocks = f->block_count - candidate.block_count;
        work->statistics.merged_blocks = merges;
        *result = candidate;
    }
    return error;
}

#include "ir_optimize_memory.c"

static IrCheck ir_optimize_verify_result(const IrFunction* function, Arena* output, Arena* scratch)
{
    const uint64_t mark = scratch->length;
    // Final verification needs one CFG and dominator tree, not optimizer use lists, lattice or work queues.
    // This still rebuilds fresh analyses independently of the retained optimizer-to-selector handoff.
    IrCfg cfg = { 0 };
    Dominators dominators = { 0 };
    IrCheck check = ir_verify_cfg(function, scratch, output, &cfg);
    if (check.error == IR_OK)
    {
        const DominatorCfg graph = {
            .block_count = cfg.block_count,
            .edge_count = cfg.edge_count,
            .entry = function->block_count == 0 ? BUSTER_DOMINATOR_NONE : 0,
            .successor_offsets = cfg.successor_offsets,
            .successors = cfg.successors,
            .predecessor_offsets = cfg.predecessor_offsets,
            .predecessors = cfg.predecessors,
        };
        DominatorOptions options = dominators_options();
        options.outputs = 0;
        const DominatorStatus status = dominators_analyze(scratch, output, &graph, options, &dominators);
        check.error = status == DOMINATOR_OK ? IR_OK : status == DOMINATOR_NO_MEMORY ? IR_ERROR_MEMORY : IR_ERROR_DOMINANCE;
    }
    if (check.error == IR_OK)
    {
        const IrDominance dominance = {
            .enter = dominators.preorder,
            .leave = dominators.subtree_end,
            .block_count = function->block_count,
        };
        // The unchanged revision's joins and same-block order already passed. Check the new tree and full SSA
        // dominance, including unreachable cross-block uses, without rebuilding or rechecking the graph.
        check = ir_verify_dominance(function, &cfg, &dominance);
        if (check.error == IR_ERROR_DOMINANCE && check.instruction != BUSTER_IR_NONE)
        {
            // The former preparation-first verifier reported reachable-use errors before dead-region errors.
            // Preserve that diagnostic priority on failure without a second operand walk for valid output.
            const IrCheck reachable = ir_optimize_check_reachable(function, &cfg, &dominators);
            if (reachable.error != IR_OK)
            {
                check = reachable;
            }
        }
    }
    arena_pop_to(scratch, mark);
    return check;
}

static __attribute__((aligned(64))) IrCheck ir_optimize(const IrFunction* function, Arena* output, Arena* scratch, IrOptimizeOptions options, IrOptimizeResult* result)
{
    const uint64_t output_mark = output->length;
    const uint64_t scratch_mark = scratch->length;
    IrOptimizeWork work = { 0 };
    IrCheck check = ir_check(IR_ERROR_METADATA, BUSTER_IR_NONE, options.passes);
    if (output != scratch && (options.passes & ~BUSTER_IR_OPTIMIZE_PASSES) == 0)
    {
        check = ir_optimize_prepare(&work, function, output, scratch, true);
    }
    if (check.error == IR_OK)
    {
        if (function->block_count != 0)
        {
            work.blocks[0] = 1;
        }
        if ((options.passes & BUSTER_IR_OPTIMIZE_SCCP) != 0)
        {
            ir_optimize_sccp_worklist(&work);
        }
        else
        {
            for (uint32_t block = 0; block < function->block_count; block += 1)
            {
                work.blocks[block] = work.dominators.rpo_index[block] != BUSTER_DOMINATOR_NONE;
                for (uint32_t edge = work.cfg.successor_offsets[block]; edge < work.cfg.successor_offsets[(uint64_t)block + 1]; edge += 1)
                {
                    work.edges[edge] = work.blocks[block];
                }
            }
            for (uint32_t i = 0; i < function->instruction_count; i += 1)
            {
                work.states[i] = function->op[i] == IR_CONST ? IROPT_CONSTANT : IROPT_OVERDEFINED;
                if (function->op[i] == IR_CONST)
                {
                    work.values[i] = function->constants[function->a[i]];
                }
            }
        }
        check.error = work.simd_error;
        if (check.error == IR_OK && (options.passes & BUSTER_IR_OPTIMIZE_IDENTITY) != 0 && !ir_optimize_identities(&work, scratch))
        {
            check.error = IR_ERROR_MEMORY;
        }
        if (check.error == IR_OK && (options.passes & BUSTER_IR_OPTIMIZE_MEMORY) != 0 && !ir_optimize_memory(&work, scratch, &work.statistics.forwarded_loads))
        {
            check.error = IR_ERROR_MEMORY;
        }
        if (check.error == IR_OK)
        {
            ir_optimize_dce(&work, options);
            check.error = ir_optimize_rewrite(&work, output, scratch, options, &work.statistics.function);
        }
    }
    // Load-bearing: the C driver's --tier1 plans this result by tier1_select_plan_verified, which doesn't verify it again,
    // its uses dominated by their definitions (c_check_tier1.c, #141). Weakening this verification needs the driver to
    // verify instead (tier1_select_plan).
    if (check.error == IR_OK)
    {
        check = ir_optimize_verify_result(&work.statistics.function, output, scratch);
    }
    if (check.error == IR_OK)
    {
        work.statistics.scratch_bytes = scratch->length - scratch_mark;
        *result = work.statistics;
    }
    else
    {
        arena_pop_to(output, output_mark);
    }
    arena_pop_to(scratch, scratch_mark);
    return check;
}
