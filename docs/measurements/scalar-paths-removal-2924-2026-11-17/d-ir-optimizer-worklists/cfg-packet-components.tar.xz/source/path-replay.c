#define _GNU_SOURCE
#include <immintrin.h>
#include <stdio.h>
#include "buster/compiler/lane.c"
typedef bool Resolve(Arena*,const uint32_t*,uint32_t,uint32_t*);
extern Resolve original,closedwalk,compresswalk,compressstack,mixedpaths;
static Resolve* volatile methods[]={original,closedwalk,compresswalk,compressstack,mixedpaths};
typedef struct { uint32_t count,bin; uint32_t* edge; } Graph;
static uint64_t tick(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int cmp(const void*a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return(x>y)-(x<y);}
int main(int argc,char**argv)
{
    if(argc!=3)return 2;
    uint32_t seed=strtoul(argv[2],NULL,0);
    FILE*file=fopen(argv[1],"rb");if(!file)return 3;
    if(fseek(file,0,SEEK_END))return 3;long size=ftell(file);if(size<4 || size%4 || fseek(file,0,SEEK_SET))return 3;
    uint32_t* data=malloc((size_t)size), *end=data+size/4;
    Graph* graphs=malloc((size_t)size/4*sizeof(Graph));
    if(!data||!graphs||fread(data,1,(size_t)size,file)!=(size_t)size)return 3;
    fclose(file);
    unsigned ng=0,max=0;
    for(uint32_t*p=data;p<end;)
    {
        unsigned n=*p++;if((size_t)(end-p)<n)return 4;
        unsigned b=0;const unsigned limits[]={2,4,8,16,32,64,128,256,512,1024};
        while(b<10 && n>=limits[b])++b;
        graphs[ng++]=(Graph){n,b,p};p+=n;if(n>max)max=n;
    }
    uint32_t*out=malloc((max+1)*4),*ref=malloc((max+1)*4);Arena scratch=arena_reserve(64<<20);
    if(!out||!ref||!scratch.base)return 5;
    for(unsigned i=0;i<ng;i++)
    {
        const Graph g=graphs[i];
        if(!methods[0](&scratch,g.edge,g.count,ref))return 6;
        for(unsigned m=1;m<5;m++)if(!methods[m](&scratch,g.edge,g.count,out)||scratch.length||memcmp(out,ref,4*g.count))return 7;
    }
    for(unsigned bin=0;bin<12;bin++)
    {
        Graph* selected=malloc(ng*sizeof(Graph));if(!selected)return 8;
        unsigned count=0;uint64_t vertices=0;
        for(unsigned i=0;i<ng;i++)if(bin==11||bin==graphs[i].bin){selected[count++]=graphs[i];vertices+=graphs[i].count;}
        if(!count){free(selected);continue;}
        unsigned repeats=32768/(vertices+1)+1;uint64_t times[5][11];
        for(unsigned round=0;round<11;round++)
        {
            seed=seed*1664525u+1013904223u;unsigned first=(seed>>8)%5;
            for(unsigned j=0;j<5;j++){
                unsigned m=(first+(round&1?4*j:j))%5;Resolve* fn=methods[m];uint64_t start=tick();
                for(unsigned k=0;k<repeats;k++)for(unsigned i=0;i<count;i++)
                    if(!fn(&scratch,selected[i].edge,selected[i].count,out))return 9;
                times[m][round]=tick()-start;
            }
        }
        printf("%u %u %lu %u",bin,count,vertices,repeats);
        for(unsigned m=0;m<5;m++){qsort(times[m],11,sizeof(uint64_t),cmp);printf(" %lu",times[m][5]);}
        puts("");free(selected);
    }
    fprintf(stderr,"%u production graphs, four candidates match every original target\n",ng);
    return 0;
}
