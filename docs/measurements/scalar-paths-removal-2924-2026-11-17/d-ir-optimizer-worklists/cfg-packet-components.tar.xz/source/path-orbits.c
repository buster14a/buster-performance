#define _GNU_SOURCE
#include <immintrin.h>
#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
#include "buster/compiler/lane.c"
typedef bool Resolve(Arena*,const uint32_t*,uint32_t,uint32_t*);
extern Resolve original,closedwalk,compresswalk,compressstack,mixedpaths;
static Resolve* volatile methods[] = {original, closedwalk, compresswalk, compressstack, mixedpaths};
static uint32_t state = 1;
static uint32_t random32(void) { state = state * 1664525u + 1013904223u; return state; }
static uint64_t tick(void) { _mm_lfence(); uint64_t v=__rdtsc(); _mm_lfence(); return v; }
static int compare_ticks(const void* a,const void* b)
{
    uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return (x>y)-(x<y);
}
static void graph(uint32_t* links,uint32_t n,unsigned shape)
{
    for(uint32_t i=0;i<n;++i)
    {
        switch(shape)
        {
            case 0: links[i]=i;break;
            case 1: links[i]=n-1;break;
            case 2: links[i]=i+1<n?i+1:i;break;
            case 3: links[i]=(i+1)%n;break;
            case 4: links[i]=(i+1==n)?n/2:i+1;break;
            case 5: links[i]=(i%8==0 && i+1<n)?i+1:i;break;
            case 6: links[i]=(i^1)<n?(i^1):i;break;
            case 7: links[i]=i?random32()%i:0;break;
            default: links[i]=random32()%n;break;
        }
    }
}
static void expected(const uint32_t* edges,uint32_t n,unsigned shape,uint32_t* out)
{
    for(uint32_t i=0;i<n;i++)
    {
        if(shape==0)out[i]=i;
        else if(shape==1||shape==2)out[i]=n-1;
        else if(shape==3||shape==7)out[i]=0;
        else if(shape==4)out[i]=n/2;
        else if(shape==5)out[i]=edges[i];
        else if(shape==6)out[i]=i&~1u;
        else
        {
            uint32_t slow=i,fast=i;
            do {slow=edges[slow];fast=edges[edges[fast]];} while(slow!=fast);
            uint32_t least=slow;
            for(uint32_t p=edges[slow];p!=slow;p=edges[p]) if(p<least)least=p;
            out[i]=least;
        }
    }
}

int main(int argc,char**argv)
{
    state=argc>1?strtoul(argv[1],NULL,0):1;
    const size_t page=sysconf(_SC_PAGESIZE);
    const uint32_t max=8192;
    uint32_t widths[95],nw=0;
    for(unsigned n=0;n<=65;n++)widths[nw++]=n;
    const unsigned extra[]={95,96,97,127,128,129,255,256,257,511,512,513,1023,1024,1025,2047,2048,2049,4095,4096,4097,8192};
    for(unsigned i=0;i<sizeof(extra)/sizeof(*extra);i++)widths[nw++]=extra[i];
    Arena scratch=arena_reserve(16<<20);
    if(!scratch.base)return 2;
    uint8_t* map=mmap(NULL,max*4+page*2,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(map==MAP_FAILED||mprotect(map+page,max*4,PROT_READ|PROT_WRITE))return 3;
    uint32_t *target=malloc(max*4+8),*reference=malloc(max*4+8),*overlap=malloc(max*4+8);
    if(!target||!reference||!overlap)return 4;
    unsigned good=0,invalid=0,aliases=0,oom=0;
    for(unsigned wi=0;wi<nw;wi++)
    {
        uint32_t n=widths[wi];uint32_t* edges=(uint32_t*)(map+page+4*max)-n;
        for(unsigned shape=0;shape<9;shape++)
        {
            graph(edges,n,shape);expected(edges,n,shape,reference);
            for(unsigned m=0;m<5;++m)
            {
                Resolve* fn=methods[m];memset(target,0xcb,4*n+8);
                if(!fn(&scratch,edges,n,target)||scratch.length||memcmp(target,reference,4*n)||target[n]!=0xcbcbcbcb)return 5;
                good++;
                for(unsigned off=0;off<3;off++)
                {
                    uint32_t* in=overlap+(off==2),*out=overlap+(off==1);
                    memcpy(in,edges,4*n);if(!fn(&scratch,in,n,out)||scratch.length||memcmp(out,reference,4*n))return 6;
                    aliases++;
                }
                if(n)
                {
                    uint32_t index=random32()%n, saved=edges[index];edges[index]=(random32()&1)?UINT32_MAX:n;
                    memset(target,0xcb,4*n+8);if(fn(&scratch,edges,n,target)||scratch.length)return 7;
                    for(unsigned v=0;v<=n;v++)if(target[v]!=0xcbcbcbcb)return 8;
                    edges[index]=saved;invalid++;
                }
            }
            if(n>2 && shape==3)
            {
                for(unsigned m=0;m<5;m++)
                {
                    Arena empty=scratch;empty.capacity=0;empty.length=0;
                    memset(target,0xcb,4*n+8);bool complete=methods[m](&empty,edges,n,target);
                    if(empty.length)return 9;
                    if(complete){if(memcmp(target,reference,4*n)||target[n]!=0xcbcbcbcb)return 12;continue;}
                    for(unsigned v=0;v<=n;v++)if(target[v]!=0xcbcbcbcb)return 10;
                    oom++;
                }
            }
            unsigned repeats=1024/(1+n/4)+2;uint64_t cycle[5][9];
            for(unsigned round=0;round<9;round++)
            {
                unsigned first=random32()%5;
                for(unsigned k=0;k<5;k++)
                {
                    unsigned m=(first+(round&1?4*k:k))%5;Resolve* fn=methods[m];
                    uint64_t lo=tick();for(unsigned z=0;z<repeats;z++)if(!fn(&scratch,edges,n,target))return 11;
                    cycle[m][round]=tick()-lo;
                }
            }
            printf("%u %u %u",n,shape,repeats);for(unsigned m=0;m<5;m++){qsort(cycle[m],9,sizeof(uint64_t),compare_ticks);printf(" %lu",cycle[m][4]);}puts("");
        }
    }
    fprintf(stderr,"%u independent orbit checks, %u aliased outputs, %u invalid-input rollbacks, %u exhausted-arena rollbacks passed\n",good,aliases,invalid,oom);
    return 0;
}
