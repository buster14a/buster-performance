from pathlib import Path
from collections import defaultdict
from statistics import median
import re,tarfile
p=Path(__file__).parent
s=(p/'record.py').read_text().split('for seed in [1,133,789]:\n assert')[0].replace("'cycles-matched'","'closed-cycles'").replace("f'production-","f'closed-")
exec(s)
stats=defaultdict(list);replays=defaultdict(list); syn={}
for seed in (1,133,789):
 assert '369 exhausted-arena rollbacks passed' in (r/f'checked-orbits-{seed}.log').read_text()
 for row in nums(r/f'checked-orbits-{seed}.tsv'):
  for j in range(4):stats[j,*row[:2]].append(row[4+j]/row[3])
 for m in modes:
  for g in groups:
   assert 'match every original target' in (r/f'checked-replay-{m}-{g}-{seed}.log').read_text()
   for row in nums(r/f'checked-replay-{m}-{g}-{seed}.tsv'):
    for j in range(4):replays[j,m,g,row[0]].append(row[5+j]/row[4])
for f in r.glob('closed-synth-*-cfg-closed.log'):
 def parse(f):
  return {k:(shape,float(v))for k,shape,v in re.findall(r'^ir-optimize (\S+) (input=.*?)\n  ns/function=.*?TSC-ticks/input-instruction=([\d.]+)',f.read_text(),re.M)}
 base=parse(f.with_name(f.name.replace('cfg-closed','unroll-base')));head=parse(f);assert head and head.keys()==base.keys()
 for k,(shape,v) in head.items():
  assert shape==base[k][0];syn[f.name,k]=v/base[k][1]
for seed in [139,1,133,789]:assert '0 failures' in (r/f'closed-frozen-{seed}.log').read_text()
def pct(v):return f'{(v-1)*100:+.3f}%'
assert len(stats)==792*4 and len(replays)==61*4 and len(syn)==120
rows=[]
for j,name in enumerate(['Packet-contained graphs','Compress within packets, walk components','Compress within packets, use stack','Compress within packets, select walk by component']):
 a=[median(v)for (method,*_),v in stats.items() if method==j];b=[median(v)for (method,*_),v in replays.items()if method==j]
 rows.append(f'| {name} | {sum(x<=1 for x in a)}/792 | {sum(x<=1 for x in b)}/61 | {median(b):.3f} |')
doc='''## Resolving components inside a vector register

A packet contains sixteen block IDs. When every successor stays inside its own packet, four pointer doublings determine which cycle each lane reaches. The minimum ID on that cycle is its canonical representative. The pass validates all successors before writing output, processes overlapping packets in memmove order, and keeps the linear component walk for cross-packet graphs. Three other implementations also compress internal paths in mixed packets. They carry the minimum interior ID through each compressed edge so a cycle crossing packets keeps its original representative.

Each run used a locked 9700X. Independent guard-page oracles covered nine graph shapes at 88 widths from zero through 8,192. At each of three seeds the four implementations and the parent passed 3,960 target checks, 11,880 shifted/aliased outputs and 3,915 invalid-input rollbacks. In 369 exhausted-arena cases the call failed and restored the arena and output. Self-contained inputs could complete without an allocation. Captured default and all-pass graphs also matched the parent target at every block.

| Implementation | Guarded timings at or below parent | Captured bins and totals at or below parent | Median captured ratio |
| --- | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

The first implementation also ran through the complete compiler. Each row below contains the five-round paired median, summing ticks over all functions in each instruction-count bin. Timings use the same stage boundaries as the earlier CFG comparison.

| Instructions | Configuration | Functions | Verified pipeline | Cleanup | Targets | Layout |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
'''
for k,label in enumerate(['0–31','32–127','128–511','512–2,047','2,048–8,191','8,192+','Total']):
 for m in modes:
  vals=[median(q)for q in zip(*per[m,k])]
  doc+=f'| {label} | {m} | {vals[0]:,} | '+' | '.join(f'{v:.4f}'for v in vals[1:])+' |\n'
doc+='\n| Complete compiler | Debug objects | Default | All passes |\n| --- | ---: | ---: | ---: |\n'
for g,count in groups.items():doc+=f'| {g} | {count:,} | {pct(whole["default",g])} | {pct(whole["all",g])} |\n'
doc+=f'''
All six output manifests matched. Five of six ordinary compilation cells improved. All-pass SQLite used {pct(whole["all","sqlite"])} more user cycles. The frozen optimizer seed passed 358,076 checks with zero failures, and three further seeds passed. The verified optimizer's synthetic benchmarks improved in {sum(x<=1 for x in syn.values())} of 120 shape and size cells. The remaining misses keep the replacement under qualification.

[Source, commands, guarded oracles, per-stage samples, debug object hashes and ordinary compilation timings](cfg-packet-components.tar.xz)
'''
path=out/'README.md';path.write_text(path.read_text().split('\n## Resolving components inside a vector register')[0].rstrip()+'\n\n'+doc)
with tarfile.open(out/'cfg-packet-components.tar.xz','w:xz',preset=3)as t:
 for mask in ('closed*','check-paths','path-*.c','packet-paths.py','ship-closed.py','instrument-closed.py','shipping-closed.c','compress*.inc','mixedpaths.inc','build-closed','replay-paths','ordinary-closed','record-closed.py'):
  for f in sorted(p.glob(mask)):
   if f.is_file():t.add(f,'source/'+f.name)
 for mask in ('closed-*','checked-*'):
  for f in sorted(r.glob(mask)):t.add(f,'native/'+f.name)
print(*rows,f'{sum(x<=1 for x in syn.values())}/120',sep='\n')
