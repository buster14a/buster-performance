from pathlib import Path
import subprocess
p = Path('src/buster/compiler/c_refine.c')
head = p.read_text()
base = subprocess.check_output(['git','show','HEAD:'+str(p)],text=True)
start='BUSTER_INLINE uint32_t refine_newlines_before('
stop='static __attribute__((noinline)) uint64_t refine_step_splices('
def func(s, prefix):
    a=s.index(prefix)
    return s[a:s.index('\n}',a)+2]
original_kernel=func(base,start).replace('refine_newlines_before(', 'refine_newlines_base(')
original_step=func(base,stop).replace('refine_step_splices(', 'refine_step_base(').replace('refine_newlines_before(', 'refine_newlines_base(')
head_step=func(head,stop)
head_kernel=func(head,start)
split_kernel=func(head,'static __attribute__((noinline)) uint32_t refine_wide_newlines')
inline_kernel=split_kernel.replace('static __attribute__((noinline)) uint32_t refine_wide_newlines','BUSTER_INLINE uint32_t refine_wide_inline')+'\n'+head_kernel.replace('refine_wide_newlines(', 'refine_wide_inline(').replace('refine_newlines_before(', 'refine_newlines_inline(')
worker = original_kernel+'\n'+original_step+'\n'+inline_kernel+'\n'+head_step.replace('refine_step_splices(', 'refine_step_inline(').replace('refine_newlines_before(', 'refine_newlines_inline(')+'\n'+head_step.replace('refine_step_splices(', 'refine_step_split(')
wrapper=head_step.split('\n{')[0]+'''
{
    static _Thread_local int variant;
    if (variant == 0)
    {
        const char* setting = getenv("BUSTER_EXPERIMENT_REFINE_NEWLINES");
        variant = setting != NULL && setting[0] == 'i' ? 2 : setting != NULL && setting[0] == 's' ? 3 : 1;
    }
    if (variant == 2)
        return refine_step_inline(source, length, starts, ends, step, step_count, gaps_begin, start_of_line, gaps, flags);
    if (variant == 3)
        return refine_step_split(source, length, starts, ends, step, step_count, gaps_begin, start_of_line, gaps, flags);
    return refine_step_base(source, length, starts, ends, step, step_count, gaps_begin, start_of_line, gaps, flags);
}'''
p.write_text(head.replace(head_step,worker+'\n'+wrapper))
