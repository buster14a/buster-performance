from pathlib import Path
for count,name in ((1,'one'),(512,'ordinary'),(512,'mixed'),(256,'wide')):
 patterns=[b'alpha',b'column\twith\ttabs',b'\xc3\xa9\xe4\xb8\xad\xcc\x81\xf0\x9f\x98\x80',b'control\x01\x7f\xff',b'\xf4\x8f\xbf\xbf'] if name in ('mixed','wide') else [b'plain ASCII text']
 with Path('fixture-'+name+'.c').open('wb') as f:
  for i in range(count):
   v=patterns[i%len(patterns)]
   f.write(b'#warning snippet'+str(i).encode()+b' /* '+v*(100 if name=='wide' else 1)+b' */\n')
