from pathlib import Path
p=Path('tree/src/buster/compiler/c_preprocessor_history_impl.c')
s=p.read_text();a=s.index('static uint32_t pp_snippet_line(');b=s.index('// The column that holds',a)
f=s[a:b].replace('    uint32_t column = 0;', '    uint32_t column = 0;\n    uint32_t used[4] = { 0 };').replace('            columns[at] = column;', '''            used[byte == 9 ? 0 : byte < 128 ? 1 : code_point == UINT32_MAX ? 2 : 3]++;
            columns[at] = column;''').replace('    return column;', '''    const char* path = getenv("BUSTER_SNIPPET_CENSUS");
    FILE* census = path ? fopen(path, "a") : NULL;
    if (census != NULL)
    {
        fprintf(census, "%u %u %u %u %u\\n", length, used[0], used[1], used[2], used[3]);
        fclose(census);
    }
    return column;''')
p.write_text(s[:a]+f+s[b:])
