from pathlib import Path
import subprocess,os
p=Path(__file__).resolve().parent;u=p/'modes3';d=p/'grow-mutants';d.mkdir(exist_ok=True)
flags=['-O2','-g0','-march=native','-fwrapv','-funsigned-char','-I',str(u)]
cc=os.environ.get('CC','clang')
for n in ('gate','base','width'):
 subprocess.run([cc,*flags,'-c',str(u/(n+'.c')),'-o',str(d/(n+'.o'))],check=True)
cases=[('grown-prefix','memcpy(grown, diagnostic->bytes, diagnostic->count);','memset(grown, 0, diagnostic->count);','2'),
       ('direct-byte','fwrite(text, 1, length, diagnostic->stream);','fwrite(text, 1, length - 1, diagnostic->stream);','1'),
       ('fallback-prefix','pp_diagnostic_flush(diagnostic);','diagnostic->count = 0;','3')]
s=(u/'head.c').read_text()
for name,old,new,mode in cases:
 assert s.count(old)==1
 (d/'mutant.c').write_text(s.replace(old,new));subprocess.run([cc,*flags,str(d/'mutant.c'),*[str(d/(n+'.o')) for n in ('gate','base','width')],'-o',str(d/'mutant')],check=True)
 r=subprocess.run([str(d/'mutant'),'check',mode],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print(name,r.returncode,r.stdout.decode().strip().split('\n')[0],flush=True)
 if not r.returncode:raise SystemExit(name+' survived')
