from pathlib import Path
import subprocess,shutil,os
p=Path(__file__).resolve().parent;u=p/'unit';d=p/'mutants';d.mkdir(exist_ok=True)
cc=os.environ.get('CC','clang')
flags=['-O2','-g0','-march=native','-fwrapv','-funsigned-char','-I',str(u)]
for name in ('gate','base','width'):
 subprocess.run([cc,*flags,'-c',str(u/(name+'.c')),'-o',str(d/(name+'.o'))],check=True)
s=(u/'head.c').read_text()
mutants=[
 ('tail-mask','_mm512_maskz_loadu_epi8(live, line + first)','_mm512_loadu_si512(line + first)'),
 ('tab-stop','(pos - tab_end) %','(column - tab_end) %'),
 ('sentinel','_mm_set1_epi32(-1)','_mm_set1_epi32(0)'),
 ('keep-lead','if (left > 64 && crossing != 0)','if (left > 64 && crossing == UINT64_MAX)'),
 ('lone-continuation','two = live & pairs & (continuation >> 1)','two = live & pairs'),
 ('overlong','& ~bad3','& (bad3 | ~bad3)'),
 ('fourth-byte',' & (continuation >> 3) & ~bad4',' & ~bad4'),
 ('escaped-digits','(point >= 0x100000)','(point > 0x10ffff)'),
 ('buffer-count','diagnostic->count += length;','diagnostic->count += length - 1;'),
 ('column-run','plain + 1, column, steps','plain, column, steps'),
]
for name,old,new in mutants:
 assert s.count(old)==1,(name,s.count(old))
 (d/'mutant.c').write_text(s.replace(old,new))
 subprocess.run([cc,*flags,str(d/'mutant.c'),*[str(d/(n+'.o')) for n in ('gate','base','width')],'-o',str(d/'mutant')],check=True)
 r=subprocess.run([str(d/'mutant')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print(name,r.returncode,r.stdout.decode(errors='replace').strip().split('\n')[0],flush=True)
 if r.returncode==0:raise SystemExit('survived: '+name)
