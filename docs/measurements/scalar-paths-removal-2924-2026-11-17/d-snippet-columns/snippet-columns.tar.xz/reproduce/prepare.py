"""Extract the two measured functions and the matching Unicode tables from a compiler checkout."""
import argparse
import subprocess
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('repo',type=Path)
parser.add_argument('output',type=Path)
parser.add_argument('--base',default='2e4400b66b351a989625acbcb80ba079cbb31310')
parser.add_argument('--head',default='8a4a96e27f99ce88594ba06d1d43d5bf50d82cce')
a=parser.parse_args()
def source(rev,file):
 return subprocess.check_output(['git','-C',str(a.repo),'show',rev+':src/buster/compiler/'+file],text=True)
def function(s,mark):
 n=s.index(mark);return s[n:s.index('\n}\n',n)+3]
a.output.mkdir(parents=True,exist_ok=True)
header=Path(__file__).parent/'h.h'
(a.output/'h.h').write_bytes(header.read_bytes())
u=source(a.base,'c_unicode_names.c')
r=source(a.base,'c_unicode_widths.inc')+'\n'+source(a.base,'c_unicode_names.inc')
width='#include "h.h"\n'
for name in ('unicode_printable_ranges','unicode_draft_printable_ranges','unicode_combining_ranges','unicode_double_width_ranges'):
 n=r.index(name+'[');n=r.rfind('\n',0,n)+1;b=r.index('\n};',n)+3
 width+=r[n:b]+'\n'
width+=function(u,'static __attribute__((unused)) bool unicode_in_ranges(')+function(u,'static __attribute__((unused)) bool unicode_is_printable(')
width+=function(u,'BUSTER_UNICODE_ENTRY int32_t unicode_column_width(').replace('BUSTER_UNICODE_ENTRY ','')
(a.output/'width.c').write_text(width)
for side,revision in [('base',a.base),('head',a.head)]:
 s=source(revision,'c_preprocessor_history_impl.c')
 markers=['static void pp_diagnostic_flush(']
 if side=='base':
  markers+=['static void pp_diagnostic_format(','static __attribute__((format(printf, 2, 3))) void pp_diagnostic_append(','static uint32_t pp_snippet_code_point(']
 else:markers+=['static bool pp_diagnostic_grow(','static void pp_snippet_text(','static void pp_snippet_columns(']
 markers+=['static uint32_t pp_snippet_line(']
 out='#include "h.h"\n'+''.join(function(s,m) for m in markers)
 out+=f'\nuint32_t {side}(PPDiagnostic* d,const uint8_t* s,uint32_t n,uint32_t* c){{return pp_snippet_line(d,s,n,c);}}\n'
 (a.output/(side+'.c')).write_text(out)
