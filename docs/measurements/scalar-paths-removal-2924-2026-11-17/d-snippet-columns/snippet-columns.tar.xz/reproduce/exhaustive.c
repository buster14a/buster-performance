#include "h.h"
#include <sys/mman.h>
#include <unistd.h>
uint32_t base(PPDiagnostic*,const uint8_t*,uint32_t,uint32_t*);
uint32_t head(PPDiagnostic*,const uint8_t*,uint32_t,uint32_t*);
static bool same(const uint8_t* s,unsigned n)
{
    uint32_t cols[2][80];
    char text[2][180];
    PPDiagnostic d[2]={{.bytes=text[0],.capacity=sizeof(text[0])},{.bytes=text[1],.capacity=sizeof(text[1])}};
    memset(cols,0x77,sizeof(cols));
    uint32_t a=base(&d[0],s,n,cols[0]), b=head(&d[1],s,n,cols[1]);
    return a==b && d[0].count==d[1].count && memcmp(text[0],text[1],d[0].count+1)==0 && memcmp(cols[0],cols[1],sizeof(cols[0]))==0;
}
int main(void)
{
    const size_t page=(size_t)sysconf(_SC_PAGESIZE);
    uint8_t* p=mmap(NULL,page*2,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(p==MAP_FAILED || mprotect(p+page,page,PROT_NONE))return 2;
    uint8_t* end=p+page;
    unsigned count=0;
    for(uint32_t c=0;c<65536;c++)
    {
        end[-2]=(uint8_t)(c>>8);end[-1]=(uint8_t)c;
        if(!same(end-2,2)){fprintf(stderr,"pair %x\n",c);return 1;}count++;
    }
    for(uint32_t c=0;c<=0x10ffff;c++)
    {
        unsigned size=c<0x80?1:c<0x800?2:c<0x10000?3:4;
        unsigned prefix=60+(c%6);
        uint8_t* s=end-size-prefix;
        memset(s,'x',prefix);
        uint32_t rest=c;
        for(unsigned i=size-1;i>0;i--){s[prefix+i]=(uint8_t)(0x80|(rest&63));rest>>=6;}
        s[prefix]=(uint8_t)((size==1?0:size==2?0xc0:size==3?0xe0:0xf0)|rest);
        if(!same(s,prefix+size)){fprintf(stderr,"encoded %x\n",c);return 1;}count++;
    }
    for(unsigned c=0xc0;c<=0xff;c++)for(unsigned d=0;d<=255;d++)for(unsigned e=0;e<=255;e++)
    {
        end[-3]=(uint8_t)c;end[-2]=(uint8_t)d;end[-1]=(uint8_t)e;
        if(!same(end-3,3)){fprintf(stderr,"three %02x%02x%02x\n",c,d,e);return 1;}count++;
    }
    printf("%u protected-tail comparisons passed, including every code point and all two-byte strings\n",count);
    return 0;
}
