from pathlib import Path
import subprocess
f=Path('src/buster/compiler/c_preprocessor_history_impl.c')
s=f.read_text()
old=subprocess.check_output(['git','show','HEAD:'+str(f)],text=True)
def fn(s,mark):
 i=s.index(mark);return s[i:s.index('\n}\n',i)+3]
old=fn(old,'static uint32_t pp_snippet_line(').replace('static uint32_t pp_snippet_line','static __attribute__((noinline)) uint32_t pp_snippet_baseline')
new=fn(s,'static uint32_t pp_snippet_line(')
s=s.replace(new,new.replace('static uint32_t pp_snippet_line','static __attribute__((noinline)) uint32_t pp_snippet_candidate')+'\n'+old+'''
static uint32_t pp_snippet_line(PPDiagnostic* diagnostic, const uint8_t* line, uint32_t length, uint32_t* columns)
{
    static int select = -1;
    if (select < 0)
    {
        char name[4096];
        const ssize_t size = readlink("/proc/self/exe", name, sizeof(name) - 1);
        select = 0;
        if (size > 0)
        {
            name[size] = 0;
            select = strstr(name, "paired-head") != 0;
        }
    }
    return select ? pp_snippet_candidate(diagnostic, line, length, columns) : pp_snippet_baseline(diagnostic, line, length, columns);
}
''')
f.write_text(s)
