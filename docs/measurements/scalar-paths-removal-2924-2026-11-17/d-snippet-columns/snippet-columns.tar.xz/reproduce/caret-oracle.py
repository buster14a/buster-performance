from pathlib import Path
import os,subprocess,sys
cc,compiler=sys.argv[1:3]
patterns=[b'plain',b'\t',b'\x00',b'\x01\x7f\xff',b'\xc3\xa9\xe4\xb8\xad\xcc\x81\xf0\x9f\x98\x80',b'\xc0\x80\xed\xa0\x80\xf4\x90\x80\x80',b'\xc2\x80\xf4\x8f\xbf\xbf',b'\xf0\x90\x80',b'\t\xe4\xb8\xad\t\xc2\xa0\t',b'\xf0\x9f\x98\x80\xfe']
for g,repeat in [('boundary',1),('long',16)]:
 path=Path('caret-'+g+'.c')
 with path.open('wb') as f:
  for y in range(130):
   for k,v in enumerate(patterns):
    f.write(b'/*'+b'x'*y+v*repeat+b'*/ #warning message'+str(y*10+k).encode()+b'\n')
 outs=[]
 for n,exe in [('clang',cc),('buster',compiler)]:
  proc=subprocess.run([exe,'-std=c23','-E',str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
  if proc.returncode:raise RuntimeError(proc.returncode)
  (Path(n+'-'+g+'.log')).write_bytes(proc.stderr)
  outs.append(proc.stderr)
 a,b=outs
 print(g,len(a),len(b),a==b,flush=True)
 if a!=b:
  for i,(v,w) in enumerate(zip(a.split(b'\n'),b.split(b'\n'))):
   if v!=w:print('first difference',i,repr(v[:180]),repr(w[:180]));break
  raise SystemExit(1)
