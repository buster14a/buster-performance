#include "h.h"
#include <sys/mman.h>
#include <unistd.h>
uint32_t base(PPDiagnostic*,const uint8_t*,uint32_t,uint32_t*);
uint32_t head(PPDiagnostic*,const uint8_t*,uint32_t,uint32_t*);
typedef uint32_t (*Render)(PPDiagnostic*,const uint8_t*,uint32_t,uint32_t*);
static char text[2][42000];
static uint32_t col[2][4200];
static uint64_t ticks(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int cmp(const void* a,const void* b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return (x>y)-(x<y);}
static void fill(uint8_t* s,uint32_t n,unsigned g,uint32_t shift)
{
    static const uint8_t complex[]={0xc2,0xa0,0xe4,0xb8,0xad,0xcc,0x80,0xf0,0x9f,0x98,0x80,9,0xc2,0x80,0xf4,0x8f,0xbf,0xbf,127,1,0xe0,0x90,0xff,32};
    static const uint8_t wide[]={0xe4,0xb8,0xad,0xf0,0x9f,0x98,0x80,0xcc,0x80,0xc2,0xa0};
    for(uint32_t i=0;i<n;++i){
      uint32_t k=i+shift;
      s[i]=g==0?32+k%95:g==1?9:g==2?k%32:g==3?wide[k%sizeof(wide)]:g==4?128+(k*79)%128:g==5?complex[k%sizeof(complex)]:g==6?(k%39==0?9:32+k%95):g==7?(k%39==0?127:32+k%95):g==8?(k%39==0?255:32+k%95):k%39==0?0xc2:k%39==1?0xa0:32+k%95;
    }
}
static bool check(const uint8_t* s,unsigned n, unsigned shape, unsigned shift)
{
    PPDiagnostic d[2]={{.bytes=text[0],.capacity=sizeof(text[0])},{.bytes=text[1],.capacity=sizeof(text[1])}};
    memset(col[0],0xa7,(n+2)*4);memset(col[1],0xa7,(n+2)*4);
    uint32_t a=base(d,s,n,col[0]),b=head(d+1,s,n,col[1]);
    if(a!=b||d[0].count!=d[1].count||memcmp(text[0],text[1],d[0].count+1)||memcmp(col[0],col[1],(n+2)*4)){
        fprintf(stderr,"difference %u %u %u width %u %u bytes %lu %lu\n",shape,n,shift,a,b,d[0].count,d[1].count);
        for(unsigned i=0;i<=n;++i)if(col[0][i]!=col[1][i]){fprintf(stderr,"column %u is %u vs %u\n",i,col[0][i],col[1][i]);break;}
        return false;
    }
    return true;
}
int main(int argc,char** argv)
{
    const unsigned page=sysconf(_SC_PAGESIZE);
    uint8_t* buf=mmap(NULL,page*4,PROT_READ|PROT_WRITE,MAP_ANONYMOUS|MAP_PRIVATE,-1,0);
    if(buf==MAP_FAILED||mprotect(buf+3*page,page,PROT_NONE))return 3;
    const bool measure=argc>1&&!strcmp(argv[1],"time");
    uint32_t sizes[512],cnt=0;
    for(unsigned i=0;i<=128;++i)sizes[cnt++]=i;
    for(unsigned i=256;i<=4096;i*=2)for(int d=-2;d<=2;++d)sizes[cnt++]=i+d;
    Render render[2]={base,head};
    uint32_t cases=0;
    for(unsigned g=0;g<10;++g)for(unsigned z=0;z<cnt;++z){
        unsigned n=sizes[z];uint8_t* s=buf+3*page-n;
        for(unsigned shift=0;shift<32;++shift){fill(s,n,g,shift);if(!check(s,n,g,shift))return 2;++cases;}
        if(measure){
            fill(s,n,g,1);
            uint64_t tt[2][11];unsigned reps=8+512/(1+n);
            for(unsigned k=0;k<11;++k)for(unsigned side=0;side<2;++side){
                unsigned v=(k+side)&1;PPDiagnostic d={.bytes=text[v],.capacity=sizeof(text[v])};uint64_t t=ticks();
                for(unsigned j=0;j<reps;++j){d.count=0;render[v](&d,s,n,col[v]);}
                tt[v][k]=ticks()-t;
            }
            for(unsigned v=0;v<2;++v)qsort(tt[v],11,8,cmp);
            printf("%u\t%u\t%u\t%lu\t%lu\n",g,n,reps,tt[0][5],tt[1][5]);
        }
    }
    fprintf(stderr,"snippet: %u guarded differential cases passed\n",cases);
    return 0;
}
