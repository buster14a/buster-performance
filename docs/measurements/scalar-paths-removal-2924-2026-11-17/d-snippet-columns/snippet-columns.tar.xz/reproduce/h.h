#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <inttypes.h>
typedef struct {FILE* stream; void* arena;char* bytes;uint64_t count,capacity;bool direct;} PPDiagnostic;
#define BUSTER_PP_SNIPPET_TAB_STOP 8
#define BUSTER_ARRAY_LENGTH(a) (sizeof(a)/sizeof((a)[0]))
typedef struct { unsigned char bytes[131072]; size_t used; } BenchArena;
static inline void* arena_push(void* arena, uint64_t count, uint32_t alignment)
{
    (void)alignment;
    BenchArena* a=arena;
    void* result=NULL;
    if(a && count<=sizeof(a->bytes)-a->used){result=a->bytes+a->used;a->used+=count;}
    return result;
}
int32_t unicode_column_width(uint32_t);
