#include <immintrin.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

static inline bool newline(uint8_t c) { return c == '\n' || c == '\r'; }

static inline uint32_t marker(const uint8_t *p, size_t n, bool tri)
{
    if (*p == '\\') return 1;
    if (tri && *p == '?' && n >= 3 && p[1] == '?' && p[2] == '/') return 3;
    return 0;
}

static inline uint64_t horiz(__m512i v)
{
    const __m512i small = _mm512_sub_epi8(v, _mm512_set1_epi8(9));
    const uint64_t controls = _mm512_cmple_epu8_mask(small, _mm512_set1_epi8(3));
    return _mm512_cmpeq_epi8_mask(v, _mm512_set1_epi8(32)) |
           (controls & ~_mm512_cmpeq_epi8_mask(v, _mm512_set1_epi8(10)));
}

static inline bool inner(const uint8_t *s, size_t len, size_t *begin, size_t *end, bool tri)
{
    size_t lo=*begin, hi=*end;
    const uint32_t m=marker(s+lo,hi-lo,tri);
    if (!m || !newline(s[hi-1])) return false;
    lo += m;
    const uint8_t closing=s[--hi];
    if (hi>lo && s[hi-1]==(closing^7)) --hi;
    else if (*end<len && s[*end]==(closing^7)) return false;
    *begin=lo; *end=hi;
    return lo<=hi;
}

bool groups(const uint8_t *s,size_t len,uint32_t begin,uint32_t end,unsigned tri)
{
    if(begin>=end) return begin==end;
    size_t lo=begin,hi=end;
    if(!inner(s,len,&lo,&hi,tri)) return false;
    while(lo<hi){
        size_t count=hi-lo; if(count>64)count=64;
        uint64_t mask=_bzhi_u64(UINT64_MAX,(uint32_t)count);
        __m512i v=_mm512_maskz_loadu_epi8(mask,s+lo);
        uint64_t other=mask&~horiz(v);
        if(!other){lo+=count;continue;}
        lo+=(uint32_t)__builtin_ctzll(other);
        const uint8_t c=s[lo++];
        if(!newline(c)) return false;
        if(lo<hi && s[lo]==(c^7)) ++lo;
        if(lo>=hi) return false;
        unsigned m=marker(s+lo,hi-lo,tri);
        if(!m)return false;
        lo+=m;
    }
    return true;
}

bool edges(const uint8_t *s,size_t len,uint32_t begin,uint32_t end,unsigned tri)
{
    if(begin>=end) return begin==end;
    size_t lo=begin,hi=end;
    if(!inner(s,len,&lo,&hi,tri)) return false;
    uint64_t prev_n=0,prev2_n=0,prev_cr=0,prev_lf=0,prev_q=0,prev2_q=0;
    while(lo<hi){
        size_t count=hi-lo;if(count>64)count=64;
        uint64_t live=_bzhi_u64(UINT64_MAX,(uint32_t)count);
        __m512i v=_mm512_maskz_loadu_epi8(live,s+lo);
        uint64_t h=horiz(v),b=_mm512_cmpeq_epi8_mask(v,_mm512_set1_epi8('\\'));
        uint64_t lf=_mm512_cmpeq_epi8_mask(v,_mm512_set1_epi8('\n')),cr=_mm512_cmpeq_epi8_mask(v,_mm512_set1_epi8('\r'));
        uint64_t n=lf|cr, pn=(n<<1)|prev_n, ppn=(n<<2)|prev2_n;
        uint64_t q=0,slash=0,bad=0;
        if(tri){
            q=_mm512_cmpeq_epi8_mask(v,_mm512_set1_epi8('?'));
            slash=_mm512_cmpeq_epi8_mask(v,_mm512_set1_epi8('/'));
            uint64_t pq=(q<<1)|prev_q,ppq=(q<<2)|prev2_q;
            // The two question marks must start after a newline and be followed by a slash.
            bad |= (q & pq & ppq) | ((pq & ~ppq) ^ (q & pq)) | ((pq & ppq) ^ slash);
            bad |= (q & ~pq) ^ (pn & ~(n|b));
            prev_q=q>>63;prev2_q=q>>62;
        } else {
            bad |= b ^ (pn & ~n);
        }
        bad |= b & ~pn;
        bad |= n & pn & ppn;
        bad |= (lf & ((lf<<1)|prev_lf)) | (cr & ((cr<<1)|prev_cr));
        bad |= ~(h|b|n|q|slash);
        if(bad & live)return false;
        if(count==hi-lo){
            uint64_t final=UINT64_C(1)<<(count-1);
            if(final & (n|q)) return false;
        }
        prev_n=n>>63;prev2_n=n>>62;prev_cr=cr>>63;prev_lf=lf>>63;
        lo+=count;
    }
    return true;
}
