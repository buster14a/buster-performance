#include <stdbool.h>
#include <stdint.h>
typedef struct { const uint8_t *source; uint64_t length; bool trigraphs,cplusplus; } ScalarLexer;
#define C_TOKENIZER_TRIGRAPHS 1
static bool is_whitespace(int32_t c)
{
    return c == ' ' || c == '\t' || c == '\f' || c == '\v' || c == '\n' || c == '\r';
}
static uint64_t escaped_newline_size(const ScalarLexer* lexer, uint64_t position)
{
    uint64_t size = 0;
    uint64_t result = 0;
    while (result == 0 && position + size < lexer->length && is_whitespace(lexer->source[position + size]))
    {
        size += 1;
        uint8_t c = lexer->source[position + size - 1];
        if (c == '\n' || c == '\r')
        {
            if (position + size < lexer->length)
            {
                uint8_t next = lexer->source[position + size];
                if ((next == '\n' || next == '\r') && next != c)
                {
                    size += 1;
                }
            }
            result = size;
        }
    }
    return result;
}
bool original(const uint8_t* source, uint64_t length, uint32_t gap_start, uint32_t gap_end, uint32_t flags)
{
    const ScalarLexer lexer = {
        .source = source,
        .length = length,
        .trigraphs = (flags & C_TOKENIZER_TRIGRAPHS) != 0,
        .cplusplus = false,
    };
    uint64_t p = gap_start;
    bool splices = true;
    while (splices && p < gap_end)
    {
        uint64_t backslash = 0;
        if (source[p] == '\\')
        {
            backslash = 1;
        }
        else if (lexer.trigraphs && p + 2 < length && source[p] == '?' && source[p + 1] == '?' && source[p + 2] == '/')
        {
            backslash = 3;
        }
        const uint64_t newline = backslash != 0 ? escaped_newline_size(&lexer, p + backslash) : 0;
        splices = newline != 0;
        p += backslash + newline;
    }
    return splices && p == gap_end;
}
