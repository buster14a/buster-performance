from pathlib import Path
p=Path(__file__).parent
s=(p/'gaps.c').read_text()
a=s.index('    const __m512i small');b=s.index('\n}',a)
lut=[0]*16
for value in (9,11,12,32):lut[value%16]=value
s=s[:a]+'''    static const uint8_t spelling[64] __attribute__((aligned(64))) = { '''+', '.join(map(str,lut*4))+''' };
    return _mm512_cmpeq_epi8_mask(v, _mm512_shuffle_epi8(_mm512_load_si512(spelling),v));'''+s[b:]
s=s[s.index('#include'):s.index('bool groups(')]+s[s.index('bool edges('):].replace('bool edges(','bool shuffled(')
s=s.replace('        uint64_t h=horiz(v),b=', '''        uint64_t h=horiz(v);
        if ((h & live)==live) {
            // A horizontal byte may follow only another horizontal byte or the end of a marker.
            if(prev_n||prev_q)return false;
            prev_n=prev2_n=prev_q=prev2_q=prev_lf=prev_cr=0;
            lo+=count;continue;
        }
        uint64_t b=''')
# After a pair "??" followed by horizontal text, prev_q accounts for the pending slash.
names=[0]*128;after=[0]*128
for x in (9,11,12,32):names[x]=1;after[x]=7
names[10]=2;after[10]=8|16|4
names[13]=4;after[13]=8|16|2
names[92]=8;after[92]=7
names[63]=16;after[63]=16|32
names[47]=32;after[47]=7
s+='\nstatic const uint8_t classes[128] __attribute__((aligned(64)))={'+','.join(map(str,names))+'};\n'
s+='static const uint8_t allowed[128] __attribute__((aligned(64)))={'+','.join(map(str,after))+'};\n'
s+='''
bool pairs(const uint8_t *s,size_t len,uint32_t begin,uint32_t end,unsigned tri)
{
    if(begin>=end)return begin==end;
    size_t lo=begin,hi=end;
    if(!inner(s,len,&lo,&hi,tri))return false;
    uint64_t prev_n=0,prev2_n=0,prev_q=0,prev2_q=0;
    while(lo<hi){
        size_t count=hi-lo<64?hi-lo:64;
        uint64_t live=_bzhi_u64(UINT64_MAX,(uint32_t)count);
        const __m512i v=_mm512_maskz_loadu_epi8(live,s+lo);
        uint64_t h=horiz(v);
        if((h&live)==live){
            if(prev_n||prev_q)return false;
            prev_n=prev2_n=prev_q=prev2_q=0;
            lo+=count;continue;
        }
        const __m512i pv=_mm512_maskz_loadu_epi8(live,s+lo-1);
        const __m512i current=_mm512_permutex2var_epi8(_mm512_load_si512(classes),v,_mm512_load_si512(classes+64));
        const __m512i next=_mm512_permutex2var_epi8(_mm512_load_si512(allowed),pv,_mm512_load_si512(allowed+64));
        uint64_t bad=~_mm512_test_epi8_mask(current,next) | _mm512_movepi8_mask(v);
        uint64_t n=_mm512_test_epi8_mask(current,_mm512_set1_epi8(6));
        uint64_t q=_mm512_test_epi8_mask(current,_mm512_set1_epi8(16));
        uint64_t slash=_mm512_test_epi8_mask(current,_mm512_set1_epi8(32));
        bad |= n & ((n<<1)|prev_n) & ((n<<2)|prev2_n);
        if(tri){
            uint64_t pq=(q<<1)|prev_q,ppq=(q<<2)|prev2_q;
            bad |= ((pq & ~ppq) ^ (q & pq)) | ((pq & ppq) ^ slash);
        } else bad |= q|slash;
        if(bad&live)return false;
        if(count==hi-lo && ((n|q)&(UINT64_C(1)<<(count-1))))return false;
        prev_n=n>>63;prev2_n=n>>62;prev_q=q>>63;prev2_q=q>>62;
        lo+=count;
    }
    return true;
}
'''
(p/'pairs.c').write_text(s)
t=(p/'gate.c').read_text().replace('original,groups,edges','original,shuffled,pairs')
(p/'pairs-gate.c').write_text(t)
r=(p/'gate-task').read_text().replace('original.c gaps.c gate.c','original.c pairs.c pairs-gate.c').replace('gap-gate','pairs-gate').replace('"gate-$seed','"pairs-$seed').replace('touch gate.ok','touch pairs.ok')
(p/'pairs-task').write_text(r)
(p/'prove-pairs.py').write_text((p/'prove.py').read_text().replace('gaps.so','pairs.so').replace('lib.groups,lib.edges','lib.shuffled,lib.pairs'))
