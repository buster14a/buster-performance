#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
typedef bool Gap(const uint8_t*,size_t,uint32_t,uint32_t,unsigned);
extern Gap original,shuffled,pairs;
static Gap *volatile methods[]={original,shuffled,pairs};
static unsigned rng=1;
static unsigned draw(void){rng=rng*1664525+1013904223;return rng;}
static int cmp(const void* a,const void* b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return (x>y)-(x<y);}
static uint64_t ticks(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static void shape(uint8_t* s,size_t n,unsigned k){
    memset(s,' ',n);if(!n)return;
    if(k==0)return;
    if(k==1){s[n-1]='\n';return;}
    if(k==2){memset(s,'x',n);return;}
    if(k==3||k==4||k==5||k==6||k==7||k==8){
        s[0]='\\';s[n-1]='\n';
        if(k==4&&n>=3)s[n-2]='\r';
        if(k==5&&n>=3)s[n/2]=0;
        if(k==6)s[n-1]=' ';
        if(k==7)for(size_t i=1;i+1<n;i++)s[i]=" \t\f\v"[i%4];
        if(k==8&&n>=4){size_t j=n/2;s[j-1]='\r';s[j]='\\';}
        return;
    }
    if(k==9||k==10){
        size_t i=0;while(n-i>=4){memcpy(s+i,k==9?"\\\n":"\\\r",2);i+=2;}
        s[i]='\\';s[n-1]='\n';return;
    }
    if(k==11||k==12||k==13){
        s[n-1]='\n';
        if(n>=4){s[0]='?';s[1]='?';s[2]='/';}
        if(k==13&&n>=8){
            size_t i=0;while(n-i>=8){s[i]='?';s[i+1]='?';s[i+2]='/';s[i+3]='\n';i+=4;}s[i]='?';s[i+1]='?';s[i+2]='/';
        }
        return;
    }
    if(k==14){s[0]='\\';s[n-1]='\r';if(n>=5){size_t j=n/2;s[j-1]='\r';s[j]='\n';}return;}
    s[0]='\\';s[n-1]='\n';
}
int main(int argc,char**argv){
 if(argc!=2)return 2;rng=strtoul(argv[1],0,10);
 const unsigned page=sysconf(_SC_PAGESIZE),length=8*page;
 uint8_t* map=mmap(NULL,length+2*page,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 if(map==MAP_FAILED||mprotect(map+page,length,PROT_READ|PROT_WRITE))return 2;
 uint8_t *bytes=map+page;unsigned widths[200],nw=0;
 for(unsigned i=0;i<=130;i++)widths[nw++]=i;
 const unsigned more[]={191,192,193,254,255,256,257,258,383,384,385,511,512,513,1023,1024,1025,2047,2048,2049,4095,4096,4097,8191,8192};
 for(unsigned i=0;i<sizeof(more)/sizeof(*more);i++)widths[nw++]=more[i];
 volatile uint64_t sink=0;
 for(unsigned w=0;w<nw;w++)for(unsigned k=0;k<16;k++){
   unsigned n=widths[w],tri=(k==11||k==13),extra=k==15;
   for(unsigned layout=0;layout<2;layout++){
     uint8_t* s=layout?bytes+length-n-extra:bytes;shape(s,n,k);if(extra)s[n]='\r';
     for(unsigned j=1;j<3;j++)if(methods[0](s,n+extra,0,n,tri)!=methods[j](s,n+extra,0,n,tri))return fprintf(stderr,"mismatch width %u shape %u layout %u variant %u\n",n,k,layout,j),3;
   }
   unsigned align=draw()&63;uint8_t* s=bytes+align;shape(s,n,k);if(extra)s[n]='\r';
   unsigned reps=32768/(n/32+1)+64;uint64_t t[3][7];
   for(unsigned r=0;r<7;r++){
     unsigned start=draw()%3;
     for(unsigned z=0;z<3;z++){unsigned j=(start+(r&1?z:3-z))%3;Gap *f=methods[j];uint64_t a=ticks(),sum=0;for(unsigned i=0;i<reps;i++)sum+=f(s,n+extra,0,n,tri);t[j][r]=ticks()-a;sink=sum;}
   }
   printf("%u %u %u %u",n,k,tri,reps);for(unsigned j=0;j<3;j++){qsort(t[j],7,8,cmp);printf(" %lu",t[j][3]);}puts("");
 }
 fprintf(stderr,"checked all %u widths, 16 spellings and both protected placements (%lu)\n",nw,sink);
 munmap(map,length+2*page);
}
