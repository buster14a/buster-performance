from pathlib import Path
from itertools import product
from ctypes import *
import random
p=Path(__file__).parent
lib=CDLL(str(p/'pairs.so'))
fs=[lib.shuffled,lib.pairs]
for f in fs:f.argtypes=[c_char_p,c_size_t,c_uint32,c_uint32,c_uint];f.restype=c_bool
def oracle(data,lo,hi,tri):
    i=lo
    while i<hi:
        if data[i]==92:i+=1
        elif tri and data[i:i+3]==b'??/':i+=3
        else:return False
        while i<len(data) and data[i] in b' \t\v\f':i+=1
        if i==len(data) or data[i] not in (10,13):return False
        c=data[i];i+=1
        if i<len(data) and data[i]==(c^7):i+=1
    return i==hi
tests=0
def check(d,lo,hi,tri):
    global tests
    want=oracle(d,lo,hi,tri)
    for f in fs:
        got=f(d,len(d),lo,hi,tri)
        assert got==want,(f.__name__,d,lo,hi,tri,got,want)
    tests+=1
chars=b'?/\\\r\n \0'
for n in range(7):
    for w in product(chars,repeat=n):
        d=bytes(w)
        for tri in (0,1):
            check(d,0,n,tri)
            if n:check(d,0,n-1,tri)
r=random.Random(3440)
for k in range(25000):
    tri=r.randrange(2)
    v=b''.join(r.choice((b'\\',b'??/')if tri else(b'\\',))+r.choice((b'',b' ',b'\f\t\v',b' '*r.choice((31,62,63,64,65,127,128,129,255,256,1024))))+r.choice((b'\n',b'\r',b'\n\r',b'\r\n')) for _ in range(r.randrange(1,9)))
    if k%2:
        i=r.randrange(len(v));v=v[:i]+bytes([r.randrange(256)])+v[i+1:]
    pos=r.randrange(64);d=b'X'*pos+v+r.choice((b'',b'\n',b'\r',b'?'))
    check(d,pos,pos+len(v),tri)
    i=r.randrange(len(v)+1);j=r.randrange(i,len(v)+1);check(d,pos+i,pos+j,tri)
print(tests,'oracle comparisons per candidate')
