#include <immintrin.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

static inline bool newline(uint8_t c) { return c == '\n' || c == '\r'; }

static inline uint32_t marker(const uint8_t *p, size_t n, bool tri)
{
    if (*p == '\\') return 1;
    if (tri && *p == '?' && n >= 3 && p[1] == '?' && p[2] == '/') return 3;
    return 0;
}

static inline uint64_t horiz(__m512i v)
{
    static const uint8_t spelling[64] __attribute__((aligned(64))) = { 32, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 11, 12, 0, 0, 0, 32, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 11, 12, 0, 0, 0, 32, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 11, 12, 0, 0, 0, 32, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 11, 12, 0, 0, 0 };
    return _mm512_cmpeq_epi8_mask(v, _mm512_shuffle_epi8(_mm512_load_si512(spelling),v));
}

static inline bool inner(const uint8_t *s, size_t len, size_t *begin, size_t *end, bool tri)
{
    size_t lo=*begin, hi=*end;
    const uint32_t m=marker(s+lo,hi-lo,tri);
    if (!m || !newline(s[hi-1])) return false;
    lo += m;
    const uint8_t closing=s[--hi];
    if (hi>lo && s[hi-1]==(closing^7)) --hi;
    else if (*end<len && s[*end]==(closing^7)) return false;
    *begin=lo; *end=hi;
    return lo<=hi;
}

bool shuffled(const uint8_t *s,size_t len,uint32_t begin,uint32_t end,unsigned tri)
{
    if(begin>=end) return begin==end;
    size_t lo=begin,hi=end;
    if(!inner(s,len,&lo,&hi,tri)) return false;
    uint64_t prev_n=0,prev2_n=0,prev_cr=0,prev_lf=0,prev_q=0,prev2_q=0;
    while(lo<hi){
        size_t count=hi-lo;if(count>64)count=64;
        uint64_t live=_bzhi_u64(UINT64_MAX,(uint32_t)count);
        __m512i v=_mm512_maskz_loadu_epi8(live,s+lo);
        uint64_t h=horiz(v);
        if ((h & live)==live) {
            // A horizontal byte may follow only another horizontal byte or the end of a marker.
            if(prev_n||prev_q)return false;
            prev_n=prev2_n=prev_q=prev2_q=prev_lf=prev_cr=0;
            lo+=count;continue;
        }
        uint64_t b=_mm512_cmpeq_epi8_mask(v,_mm512_set1_epi8('\\'));
        uint64_t lf=_mm512_cmpeq_epi8_mask(v,_mm512_set1_epi8('\n')),cr=_mm512_cmpeq_epi8_mask(v,_mm512_set1_epi8('\r'));
        uint64_t n=lf|cr, pn=(n<<1)|prev_n, ppn=(n<<2)|prev2_n;
        uint64_t q=0,slash=0,bad=0;
        if(tri){
            q=_mm512_cmpeq_epi8_mask(v,_mm512_set1_epi8('?'));
            slash=_mm512_cmpeq_epi8_mask(v,_mm512_set1_epi8('/'));
            uint64_t pq=(q<<1)|prev_q,ppq=(q<<2)|prev2_q;
            // The two question marks must start after a newline and be followed by a slash.
            bad |= (q & pq & ppq) | ((pq & ~ppq) ^ (q & pq)) | ((pq & ppq) ^ slash);
            bad |= (q & ~pq) ^ (pn & ~(n|b));
            prev_q=q>>63;prev2_q=q>>62;
        } else {
            bad |= b ^ (pn & ~n);
        }
        bad |= b & ~pn;
        bad |= n & pn & ppn;
        bad |= (lf & ((lf<<1)|prev_lf)) | (cr & ((cr<<1)|prev_cr));
        bad |= ~(h|b|n|q|slash);
        if(bad & live)return false;
        if(count==hi-lo){
            uint64_t final=UINT64_C(1)<<(count-1);
            if(final & (n|q)) return false;
        }
        prev_n=n>>63;prev2_n=n>>62;prev_cr=cr>>63;prev_lf=lf>>63;
        lo+=count;
    }
    return true;
}

static const uint8_t classes[128] __attribute__((aligned(64)))={0,0,0,0,0,0,0,0,0,1,2,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const uint8_t allowed[128] __attribute__((aligned(64)))={0,0,0,0,0,0,0,0,0,7,28,7,7,26,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,48,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

bool pairs(const uint8_t *s,size_t len,uint32_t begin,uint32_t end,unsigned tri)
{
    if(begin>=end)return begin==end;
    size_t lo=begin,hi=end;
    if(!inner(s,len,&lo,&hi,tri))return false;
    uint64_t prev_n=0,prev2_n=0,prev_q=0,prev2_q=0;
    while(lo<hi){
        size_t count=hi-lo<64?hi-lo:64;
        uint64_t live=_bzhi_u64(UINT64_MAX,(uint32_t)count);
        const __m512i v=_mm512_maskz_loadu_epi8(live,s+lo);
        uint64_t h=horiz(v);
        if((h&live)==live){
            if(prev_n||prev_q)return false;
            prev_n=prev2_n=prev_q=prev2_q=0;
            lo+=count;continue;
        }
        const __m512i pv=_mm512_maskz_loadu_epi8(live,s+lo-1);
        const __m512i current=_mm512_permutex2var_epi8(_mm512_load_si512(classes),v,_mm512_load_si512(classes+64));
        const __m512i next=_mm512_permutex2var_epi8(_mm512_load_si512(allowed),pv,_mm512_load_si512(allowed+64));
        uint64_t bad=~_mm512_test_epi8_mask(current,next) | _mm512_movepi8_mask(v);
        uint64_t n=_mm512_test_epi8_mask(current,_mm512_set1_epi8(6));
        uint64_t q=_mm512_test_epi8_mask(current,_mm512_set1_epi8(16));
        uint64_t slash=_mm512_test_epi8_mask(current,_mm512_set1_epi8(32));
        bad |= n & ((n<<1)|prev_n) & ((n<<2)|prev2_n);
        if(tri){
            uint64_t pq=(q<<1)|prev_q,ppq=(q<<2)|prev2_q;
            bad |= ((pq & ~ppq) ^ (q & pq)) | ((pq & ppq) ^ slash);
        } else bad |= q|slash;
        if(bad&live)return false;
        if(count==hi-lo && ((n|q)&(UINT64_C(1)<<(count-1))))return false;
        prev_n=n>>63;prev2_n=n>>62;prev_q=q>>63;prev2_q=q>>62;
        lo+=count;
    }
    return true;
}
