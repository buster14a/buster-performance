from pathlib import Path
p=Path(__file__).parent
s=(p/'pairs.c').read_text()
prefix=s[:s.index('bool shuffled(')]+s[s.index('static const uint8_t classes'):s.index('bool pairs(')]
table=[0]*256
for c in (9,11,12,32):table[c]=1
for c in (10,13):table[c]=2
for c in (47,92):table[c]=4
prefix+='static const uint8_t splice_boundary[256] = { '+', '.join(map(str,table))+' };\n'
pair=s[s.index('bool pairs('):]
start='''    if(!inner(s,len,&lo,&hi,tri))return false;'''
first='''
    if(lo<hi){
        const unsigned opening=splice_boundary[s[lo]];
        if(!(opening&3))return false;
        lo += opening & 1;
    }'''
last='''
    if(lo<hi){
        const unsigned closing=splice_boundary[s[hi-1]];
        if(!(closing&5))return false;
        hi -= closing & 1;
    }'''
a=pair.replace('bool pairs(','bool opening(').replace(start,start+first)
b=pair.replace('bool pairs(','bool boundaries(').replace(start,start+first+last)
(p/'boundaries.c').write_text(prefix+a+b)
(p/'boundaries-gate.c').write_text((p/'pairs-gate.c').read_text().replace('original,shuffled,pairs','original,opening,boundaries'))
(p/'boundaries-task').write_text((p/'pairs-task').read_text().replace('pairs','boundaries'))
(p/'prove-boundaries.py').write_text((p/'prove-pairs.py').read_text().replace('pairs.so','boundaries.so').replace('lib.shuffled,lib.pairs','lib.opening,lib.boundaries'))
