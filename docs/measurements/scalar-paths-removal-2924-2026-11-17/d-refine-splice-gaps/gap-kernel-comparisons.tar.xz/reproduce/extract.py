from pathlib import Path
p=Path(__file__).parent
root=p/'tree/src/buster/compiler'
def fn(file,head):
    s=(root/file).read_text();i=s.index(head);return s[i:s.index('\n}',i)+2]
s='#include <stdbool.h>\n#include <stdint.h>\ntypedef struct { const uint8_t *source; uint64_t length; bool trigraphs,cplusplus; } ScalarLexer;\n#define C_TOKENIZER_TRIGRAPHS 1\n'
s+=fn('c_lexer.c','static bool is_whitespace(')+'\n'+fn('c_lexer.c','static uint64_t escaped_newline_size(')+'\n'+fn('c_refine.c','static bool refine_gap_is_splices(').replace('static bool refine_gap_is_splices','bool original')+'\n'
(p/'original.c').write_text(s)
