from pathlib import Path
d=Path('src/buster/compiler');f=d/'c_refine.c';s=f.read_text()
i=s.index('// Is [gap_start, gap_end)');s=s[:i]+'''#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
static uint64_t* splice_counts;
__attribute__((constructor)) static void refine_attach_splice_counts(void)
{
    const char* path = getenv("BUSTER_SPLICE_COUNTS");
    if (path != NULL)
    {
        int fd = open(path, O_RDWR|O_CLOEXEC);
        if (fd >= 0)
        {
            void* mapping = mmap(NULL, 8192, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
            if (mapping != MAP_FAILED) splice_counts = mapping;
            close(fd);
        }
    }
}
'''+s[i:]
s=s.replace('uint32_t gap_end, uint32_t flags)\n{\n    const ScalarLexer lexer =','uint32_t gap_end, uint32_t flags, uint32_t site)\n{\n    const ScalarLexer lexer =',1)
a=s.index('    return splices && p == gap_end;');s=s[:a]+'''    if (splice_counts != NULL)
    {
        const uint32_t width = gap_end - gap_start;
        const uint32_t bin = width < 33 ? width : width <= 64 ? 33 : width <= 128 ? 34 : width <= 256 ? 35 : width <= 1024 ? 36 : 37;
        const uint32_t category = site * 4 + lexer.trigraphs * 2 + (splices && p == gap_end);
        __atomic_fetch_add(splice_counts + category * 40 + bin, 1, __ATOMIC_RELAXED);
    }
'''+s[a:]
s=s.replace('refine_gap_is_splices(source, length, previous_end, start, flags)','refine_gap_is_splices(source, length, previous_end, start, flags, 0)').replace('refine_gap_is_splices(source, length, gap_start, starts[first + lane], flags)','refine_gap_is_splices(source, length, gap_start, starts[first + lane], flags, 1)');f.write_text(s)
for file,start,site in [('c_preprocessor.c','starts[result + 1], refine_flags',2),('c_preprocessor.c','starts[t], prepare->refine_flags',3),('c_preprocessor_impl.c','starts[i], pp->refine_flags',4)]:
 f=d/file;s=f.read_text();matches=[line for line in s.splitlines()if 'refine_gap_is_splices(' in line and start+')' in line];assert len(matches)==1
 s=s.replace(matches[0],matches[0].replace(start+')',start+', '+str(site)+')'));f.write_text(s)
