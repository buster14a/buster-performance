from pathlib import Path
p=Path(__file__).parent
data=[]
for i in range(240):
 lead=b'\\' if i%2==0 else b'??/'
 line=(b'\n',b'\r',b'\r\n',b'\n\r')[i%4];pad=b' '*(i%69)
 name=f'M{i}'.encode()
 data.extend([b'#define '+name+lead+pad+line+b'(x) x\n',name+b'(17)\n',b'int f'+str(i).encode()+b' = 1 +'+lead+line+b'2;\n'])
(p/'fixture.c').write_bytes(b''.join(data))
