#include "buster/compiler/x86_64_disassembler_benchmark.c"
#include <errno.h>
#include <limits.h>
#include <assert.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include "buster/compiler/test_paths.h"
#include "buster/compiler/test_tool.c"
#include "buster/compiler/x86_64_encoder_test.c"
#include "buster/compiler/x86_64_disassembler_test.c"

#include "buster/compiler/x86_64_disassembler_cli.c"
int main(void)
{
    if (!x86_disassembler_initialize()) return 1;
    uint64_t state=42;
    for (unsigned segment=0;segment<=BUSTER_X86_SEGMENT_SS;segment++) {
        unsigned cramped=0,supported=0,mem=0,encoded=0,rejected=0;
        for (unsigned row=1;row<X86_FORM_COUNT;row++) {
            unsigned number=segment*X86_FORM_COUNT+row;
            if(number>=BUSTER_X86_TEMPLATE_TABLE||((x86_decode_address32_cramped[number/64]>>(number%64))&1)==0)continue;
            cramped++;if(!x86_decode_form_supported(row))continue;supported++;
            for(unsigned j=0;j<16;j++){
                X86Instruction ins=x86_random_instruction(&state,(uint16_t)row,false);
                if((ins.mode&BUSTER_X86_MODE_MEMORY)==0)continue;
                mem++;ins.form=(uint16_t)number;
                uint8_t bytes[32]={0x67};unsigned n=encode_one(&ins,bytes+1,X86_ENCODER_MODE_64);
                if(n==0||n>=15)continue;
                encoded++;X86Decoded d[2];X86DecodeResult seen=x86_disassemble(bytes,n+1,d,2);
                rejected+=!seen.count||!d[0].address32||(d[0].instruction.form&BUSTER_X86_FORM_NUMBER)!=number;
            }
        }
        printf("%u %u %u %u %u %u\n",segment,cramped,supported,mem,encoded,rejected);
    }
    return 0;
}
