#include "buster/compiler/x86_64_disassembler_benchmark.c"
int main(int argc,char**argv){
 if(!x86_disassembler_initialize())return 2;
 static unsigned char raw[1<<20],tr[1<<20];static X86Decoded dec[1<<20];
 for(int n=1;n<argc;n++) {
  FILE* f=fopen(argv[n],"rb");if(!f)return 2;size_t sz=fread(raw,1,sizeof(raw),f);fclose(f);
  trace_output=tr;trace_size=0;
  X86DecodeResult r=x86_disassemble(raw,sz,dec,sizeof(dec)/sizeof(*dec));
  if(r.status!=X86_DECODE_OK||r.count!=trace_size)return 3;
  unsigned count[6]={0},pair[6][6]={0};
  for(unsigned i=0;i<r.count;i++){count[tr[i]]++;if(i)pair[tr[i-1]][tr[i]]++;}
  for(unsigned i=1;i<=5;i++){printf("%s %u %u",argv[n],i,count[i]);for(unsigned j=1;j<=5;j++)printf(" %u",pair[i][j]);puts("");}
 }
}
