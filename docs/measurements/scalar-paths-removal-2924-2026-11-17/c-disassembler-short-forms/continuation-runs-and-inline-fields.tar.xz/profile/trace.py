from pathlib import Path
p=Path(__file__).parent;d=p/'trace-src/buster/compiler';d.mkdir(parents=True,exist_ok=True)
f='x86_64_disassembler.c';s=(p/'unified-src/buster/compiler'/f).read_text()
a=s.rindex('static X86DecodeResult x86_disassemble(');s=s[:a]+'''static unsigned char* trace_output;
static size_t trace_size;
'''+s[a:]
a=s.rindex('static X86DecodeResult x86_disassemble(');t=s[a:]
for marker,log in [('                output[result.count++] = one;\n                result.consumed += length;', 'if (trace_output) trace_output[trace_size++] = entry.form >> 16 & 15 ? 1 : 2;'),('                        output[result.count++] = one;\n                        result.consumed += n;', 'if (trace_output) trace_output[trace_size++] = 3;'),('                    output[result.count++] = decoded;','if (trace_output) trace_output[trace_size++] = 4;'),('            result.count += written;','if (trace_output) { memset(trace_output+trace_size,5,written); trace_size+=written; }')]:
 assert marker in t;t=t.replace(marker,'            '+log+'\n'+marker,1)
(d/f).write_text(s[:a]+t)
g='''#include "buster/compiler/x86_64_disassembler_benchmark.c"
int main(int argc,char**argv){
 if(!x86_disassembler_initialize())return 2;
 static unsigned char raw[1<<20],tr[1<<20];static X86Decoded dec[1<<20];
 for(int n=1;n<argc;n++) {
  FILE* f=fopen(argv[n],"rb");if(!f)return 2;size_t sz=fread(raw,1,sizeof(raw),f);fclose(f);
  trace_output=tr;trace_size=0;
  X86DecodeResult r=x86_disassemble(raw,sz,dec,sizeof(dec)/sizeof(*dec));
  if(r.status!=X86_DECODE_OK||r.count!=trace_size)return 3;
  unsigned count[6]={0},pair[6][6]={0};
  for(unsigned i=0;i<r.count;i++){count[tr[i]]++;if(i)pair[tr[i-1]][tr[i]]++;}
  for(unsigned i=1;i<=5;i++){printf("%s %u %u",argv[n],i,count[i]);for(unsigned j=1;j<=5;j++)printf(" %u",pair[i][j]);puts("");}
 }
}
'''
(p/'trace.c').write_text(g)
