from pathlib import Path
import difflib
p=Path(__file__).parent;f='x86_64_disassembler.c';src=p/'unified-src/buster/compiler';prior=p/'runs-src/buster/compiler';dest=p/'inlinefield-src/buster/compiler';dest.mkdir(parents=True,exist_ok=True);s=(src/f).read_text()
a=s.index('                start->form = x86_decode_trailing_class[key]');e=s.index('\n            }',a)
s=s[:e]+'''
                // An ordinary opcode already includes its ModRM in this two-byte key. Store complete
                // displacement/immediate shuffles directly when no following SIB can change the address.
                const uint32_t kind = x86_decode_trailing_class[key];
                if (prefix == 0 && kind != 0)
                {
                    X86DecodeTrailing record;
                    if (kind == 0xff)
                    {
                        record = x86_decode_literal[rex][key];
                    }
                    else
                    {
                        const X86DecodePagePair page = x86_decode_trailing_index[rex][kind][next >> 5];
                        const uint32_t fields = x86_decode_trailing_forms[page.form][next & 31];
                        record.registers = x86_decode_trailing_registers[page.registers][next & 31];
                        record.form = (uint16_t)fields;
                        record.length = (uint8_t)(fields >> 16);
                        record.shuffle = (uint8_t)(fields >> 24);
                    }
                    if (record.length != 0 && !x86_decode_shuffles[record.shuffle].sib)
                    {
                        start->form = 0x80000000u | (uint32_t)record.form | (uint32_t)record.length << 16 | (uint32_t)record.shuffle << 20;
                        start->operands = record.registers;
                    }
                }'''+s[e:]
i=s.rindex('static X86DecodeResult x86_disassemble(');a=s.index('                        const __m128i raw =',i);b=s.index('                        output[result.count++]',a)
payload=s[a:b];payload=payload.replace('source + start','bytes').replace('one.offset = (uint32_t)start;', 'one.offset = offset;')
helper='''static inline X86Decoded x86_decode_placed_fields(const uint8_t* bytes, uint32_t offset, const X86DecodeTrailing* recipe, uint32_t address)
{
    const uint32_t n = recipe->length;
    const X86DecodeShuffle* shuffle = &x86_decode_shuffles[recipe->shuffle];
'''+''.join(l[20:] if l.startswith('                    ') else l for l in payload.splitlines(True))+'''    return one;
}

'''
s=s[:a]+'''                        X86Decoded one = x86_decode_placed_fields(source + start, (uint32_t)start, recipe, address);
'''+s[b:]
j=s.rindex('// Decodes `source[0, size)',0,i);s=s[:j]+helper+s[j:]
i=s.rindex('static X86DecodeResult x86_disassemble(');a=s.index('            X86DecodeStart completed',i);b=s.index('            if (source[start] == 0x62',a)
s=s[:a]+'''            if ((form & 0x80000000u) != 0)
            {
                const X86DecodeTrailing record = { .registers = entry.operands, .form = (uint16_t)form, .length = (uint8_t)((form >> 16) & 15), .shuffle = (uint8_t)(form >> 20) };
                if (record.length <= remaining)
                {
                    output[result.count++] = x86_decode_placed_fields(source + start, (uint32_t)start, &record, 0);
                    result.consumed += record.length;
                    continue;
                }
            }
            else
            {
'''+''.join('    '+l if l.strip()else l for l in s[a:b].splitlines(True))+'''            }
'''+s[b:]
(dest/f).write_text(s);q='x86_64_disassembler_benchmark.c';(dest/q).write_text((src/q).read_text())
(p/'inlinefield.patch').write_text(''.join(difflib.unified_diff((prior/f).read_text().splitlines(True),s.splitlines(True),'a/src/buster/compiler/'+f,'b/src/buster/compiler/'+f)))
(p/'inlinefield-task').write_text((p/'unified-task').read_text().replace('unified','inlinefield').replace('Measure common compact records for direct and short disassembly templates','Bake unprefixed addressing fields directly into their two-byte indices'))
