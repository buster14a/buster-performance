from pathlib import Path
import difflib
p=Path(__file__).parent;f='x86_64_disassembler.c';original=p/'unified-src/buster/compiler';prior=p/'packet-src/buster/compiler';dest=p/'runs-src/buster/compiler';dest.mkdir(parents=True,exist_ok=True);s=(original/f).read_text()
i=s.rindex('static X86DecodeResult x86_disassemble(');a=s.index('            const uint32_t next = remaining',i);b=s.index('            uint8_t lengths[64];',a);fast=s[a:b]
fast=fast.replace('output[result.count++]','output[written++]').replace('result.consumed +=','start +=').replace('(uint32_t)start','(uint32_t)(offset + start)')
a1=fast.index('            const uint32_t next =');b1=fast.index('            const uint32_t form',a1)
fast=fast[:a1]+'''            uint16_t pair = source[start];
            if (remaining >= 2) memcpy(&pair, source + start, sizeof(pair));
            const uint32_t next = pair >> 8;
            const X86DecodeStart entry = x86_decode_starts[(uint8_t)pair][next];
'''+fast[b1:];fast=fast.replace('source[start] == 0x62 || (source[start] & 0xfe) == 0xc4','(uint8_t)pair == 0x62 || ((uint8_t)pair & 0xfe) == 0xc4')
helper='''// Consume consecutive instructions with complete catalogue recipes. Return their record and byte counts together.
static __attribute__((noinline)) uint64_t x86_decode_recipe_run(const uint8_t* source, uint64_t size, X86Decoded* output, uint64_t capacity, uint32_t offset)
{
    uint32_t start = 0;
    uint32_t written = 0;
    while (start < size && written < capacity)
    {
        const uint64_t remaining = size - start;
'''+''.join(l[4:] if l.startswith('    ') else l for l in fast.splitlines(True))+'''        break;
    }
    return (uint64_t)written << 32 | start;
}

'''
a=s.rindex('            const uint64_t start = result.consumed;',i,b)
main='''            const uint64_t done = x86_decode_recipe_run(source + result.consumed, size - result.consumed, output + result.count, capacity - result.count, (uint32_t)result.consumed);
            result.consumed += (uint32_t)done;
            result.count += done >> 32;
            if (result.consumed == size || result.count == capacity) continue;
            const uint64_t start = result.consumed;
            const uint64_t remaining = size - start;
'''
j=s.rindex('// Decodes `source[0, size)',0,i);s=s[:j]+helper+s[j:a]+main+s[b:];(dest/f).write_text(s)
q='x86_64_disassembler_benchmark.c';(dest/q).write_text((original/q).read_text())
(p/'runs.patch').write_text(''.join(difflib.unified_diff((prior/f).read_text().splitlines(True),s.splitlines(True),'a/src/buster/compiler/'+f,'b/src/buster/compiler/'+f)))
(p/'runs-task').write_text((p/'unified-task').read_text().replace('unified','runs').replace('Measure common compact records for direct and short disassembly templates','Decode contiguous catalogue recipe runs before resuming the shared lane decoder'))
