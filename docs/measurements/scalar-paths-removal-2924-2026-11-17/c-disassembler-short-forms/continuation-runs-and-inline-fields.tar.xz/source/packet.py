from pathlib import Path
import difflib
p=Path(__file__).parent;f='x86_64_disassembler.c';original=p/'unified-src/buster/compiler';dest=p/'packet-src/buster/compiler';dest.mkdir(parents=True,exist_ok=True);s=(original/f).read_text();i=s.rindex('static X86DecodeResult x86_disassemble(');a=s.index('            const uint32_t next = remaining',i);b=s.index('            uint8_t lengths[64];',a)
# Complete vector packets use the existing sixteen-lane decode. A partial packet uses individually bounded recipes.
s=s[:a]+'''            if (capacity - result.count < 16 || remaining < 64)
            {
'''+''.join('    '+l if l.strip() else l for l in s[a:b].splitlines(True))+'''            }
'''+s[b:];(dest/f).write_text(s)
q='x86_64_disassembler_benchmark.c';(dest/q).write_text((original/q).read_text())
(p/'packet.patch').write_text(''.join(difflib.unified_diff((original/f).read_text().splitlines(True),s.splitlines(True),'a/src/buster/compiler/'+f,'b/src/buster/compiler/'+f)))
(p/'packet-task').write_text((p/'unified-task').read_text().replace('unified','packet').replace('Measure common compact records for direct and short disassembly templates','Use one sixteen-lane decode for full packets and bounded recipes for short calls'))
t=(p/'escape-dense').read_text().replace('escape-correct.ok','/dev/shm/buster-decode-escape-6b097f86/packet-built.ok').replace('escape-dense','packet-dense').replace('main escape','main packet').replace('escape main','packet main').replace('cmd=(./escape-mini)','cmd=(/dev/shm/buster-decode-escape-6b097f86/checkout/build/image-packet benchmark-x86-disassembler)')
(p/'packet-dense').write_text(t)
