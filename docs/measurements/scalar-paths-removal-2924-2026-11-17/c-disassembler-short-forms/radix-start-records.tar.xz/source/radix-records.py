from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent;old=p/'groups-src/buster/compiler';f='x86_64_disassembler.c';q='x86_64_disassembler_benchmark.c'
s=(old/f).read_text()
a=s.index('typedef struct\n{\n    X86DecodeStart common;');b=s.index('// A REX prefix',a)
s=s[:a]+'''// A start is either a complete descriptor or a reference to a group varying with the next byte.
#define BUSTER_X86_START_GROUP UINT32_MAX
BUSTER_X86_SHARED BUSTER_BAKED X86DecodeStart x86_decode_start_opcodes[256];
BUSTER_X86_SHARED BUSTER_BAKED X86DecodeStart x86_decode_start_groups[256 * 16];
BUSTER_X86_SHARED BUSTER_BAKED X86DecodeStart x86_decode_start_rows[256 * 256];
'''+s[b:]
at=s.index('static bool x86_decode_operand_tables_initialize(void)\n{')
s=s[:at]+'''// Uniform groups resolve immediately. Equal nonuniform groups share their entire sequence.
static X86DecodeStart x86_decode_pack_starts(const X86DecodeStart* values, X86DecodeStart* table, uint32_t* used)
{
    bool uniform = true;
    for (uint32_t i = 1; uniform && i < 16; i += 1)
    {
        uniform = values[i].form == values[0].form && values[i].operands == values[0].operands;
    }
    if (uniform)
    {
        return values[0];
    }
    uint32_t start = 0;
    while (start < *used && memcmp(table + start, values, 16 * sizeof(*values)) != 0)
    {
        start += 16;
    }
    if (start == *used)
    {
        memcpy(table + start, values, 16 * sizeof(*values));
        *used += 16;
    }
    return (X86DecodeStart){ .form = BUSTER_X86_START_GROUP, .operands = start };
}

'''+s[at:]
a=s.index('    uint32_t exceptions = 0;');b=s.index('            // Choose the most common',a)
prefix=s[a:b].replace('    uint32_t exceptions = 0;','    uint32_t row_count = 0;\n    uint32_t group_count = 0;').replace('        for (uint32_t group =','        X86DecodeStart groups[16];\n        for (uint32_t group =')
prefix=prefix.replace('                entries[lane] = entry;','''                if (entry.form == BUSTER_X86_START_GROUP)
                {
                    return false;
                }
                entries[lane] = entry;''')
end=s.index('    return true;',b)
# The first-level key can refer directly to a row when all high nibbles produce the same group.
# Distinguish references using an explicit row tag from the otherwise unused instruction descriptor.
s=s[:a]+prefix+'''            groups[group] = x86_decode_pack_starts(entries, x86_decode_start_rows, &row_count);
            if (groups[group].form == BUSTER_X86_START_GROUP)
            {
                groups[group].form = BUSTER_X86_START_ROW;
            }
        }
        x86_decode_start_opcodes[first] = x86_decode_pack_starts(groups, x86_decode_start_groups, &group_count);
    }
'''+s[end:]
s=s.replace('#define BUSTER_X86_START_GROUP UINT32_MAX','#define BUSTER_X86_START_GROUP UINT32_MAX\n#define BUSTER_X86_START_ROW (UINT32_MAX - 1)').replace('if (entry.form == BUSTER_X86_START_GROUP)','if (entry.form >= BUSTER_X86_START_ROW)')
a=s.index('            const X86DecodeStartGroup group =');b=s.index(';',s.index('x86_decode_start_exceptions[group.offset',a))+1
s=s[:a]+'''            X86DecodeStart entry = x86_decode_start_opcodes[source[start]];
            if (entry.form == BUSTER_X86_START_GROUP)
            {
                entry = x86_decode_start_groups[entry.operands + (next >> 4)];
            }
            if (entry.form == BUSTER_X86_START_ROW)
            {
                entry = x86_decode_start_rows[entry.operands + (next & 15)];
            }'''+s[b:]
d=p/'radix-src/buster/compiler';d.mkdir(parents=True,exist_ok=True);(d/f).write_text(s)
(d/q).write_text((old/q).read_text().replace('sizeof(x86_decode_start_groups) + sizeof(x86_decode_start_exceptions)','sizeof(x86_decode_start_opcodes) + sizeof(x86_decode_start_groups) + sizeof(x86_decode_start_rows)'))
patch=''.join(''.join(unified_diff((old/n).read_text().splitlines(True),(d/n).read_text().splitlines(True),'a/src/buster/compiler/'+n,'b/src/buster/compiler/'+n))for n in (f,q));(p/'radix.patch').write_text(patch)
s=(p/'groups-task').read_text().replace('groups','radix').replace('../deposited-cli.ok','../groups-cli.ok').replace('Share the common decoded record across neighboring two-byte keys','Measure hierarchical uniform and interned records for one- and two-byte decoder keys').replace('./build.sh --config Release','./build.sh --config Release --jobs 4')
(p/'radix-task').write_text(s)
