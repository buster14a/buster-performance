#include "buster/compiler/x86_64_disassembler_benchmark.c"
static int write_case(const uint8_t *s,unsigned n){
    X86Decoded out[2]={0};X86DecodeResult r=x86_disassemble(s,n,out,2);
    return fwrite(&r.count,8,1,stdout)==1&&fwrite(&r.consumed,8,1,stdout)==1&&fwrite(&r.status,4,1,stdout)==1&&fwrite(out,sizeof(*out),r.count,stdout)==r.count;
}
int main(void){
 if(!x86_disassembler_initialize())return 2;
 uint8_t s[16];
 for(unsigned rex=0;rex<=16;rex++)for(unsigned op=0;op<256;op++){
  if(!((op<64&&(op&7)<4)||(op>=0x80&&op<=0x8b)||op==0x8d))continue;
  for(unsigned reg=0;reg<8;reg++)for(unsigned mod=0;mod<3;mod++)for(unsigned sib=0;sib<256;sib++){
   unsigned k=rex!=0,seed=rex*311+reg*871+op*157+mod*53+sib;
   for(unsigned j=0;j<16;j++){seed=seed*1664525+1013904223;s[j]=(uint8_t)(seed>>24);}
   s[0]=(uint8_t)(0x40|(rex-1));s[k]=(uint8_t)op;s[k+1]=(uint8_t)((mod<<6)|(reg<<3)|4);s[k+2]=(uint8_t)sib;
   if(!write_case(s,16)||!write_case(s,3+((sib+mod+reg)%11)))return 2;
  }
 }
 for(unsigned prefix=0;prefix<3;prefix++)for(unsigned op=0;op<256;op++)for(unsigned row=0;row<64;row++){
    s[0]=(uint8_t[]){0x66,0xf2,0xf3}[prefix];s[1]=0xf;s[2]=(uint8_t)op;s[3]=(uint8_t)(192+row);
    if(!write_case(s,4)||!write_case(s,16))return 2;
 }
 return 0;
}
