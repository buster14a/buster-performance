#define main fixture_main
#include "native-test.c"
#undef main
static void compare_case(const uint8_t* bytes, uint32_t size, unsigned cap)
{
    X86Decoded output[2] = { 0 };
    X86DecodeResult r = x86_disassemble(bytes, size, output, cap);
    if (fwrite(&r.count, 8, 1, stdout) != 1 || fwrite(&r.consumed, 8, 1, stdout) != 1 ||
        fwrite(&r.status, 4, 1, stdout) != 1 || fwrite(output, sizeof(*output), r.count, stdout) != r.count) exit(2);
}
int main(void)
{
    if (!x86_disassembler_initialize()) return 2;
    uint64_t state = 3451, cases = 0;
    x86_test_mode = X86_ENCODER_MODE_64;
    for (unsigned row = 1; row < X86_FORM_COUNT; row++) {
        if (!x86_decode_form_supported(row) || x86_form_descriptions[row].family == BUSTER_X86_FAMILY_LEGACY) continue;
        for (unsigned j=0;j<32;j++) {
            X86Instruction inst=x86_random_instruction(&state,(uint16_t)row,false);
            uint8_t orig[32]={0};
            uint32_t n=encode_one(&inst,orig,X86_ENCODER_MODE_64);
            if (!n || n>15) continue;
            for (unsigned k=0;k<=5;k++) {
                uint8_t a[32]; memcpy(a,orig,sizeof(a));
                if (k) a[(j+k)%n]^=(uint8_t)(1u<<((j*3+k)%8));
                compare_case(a,n,1); compare_case(a,(j+k)%(n+1),1); compare_case(a,n+4,2);
                cases+=3;
            }
        }
    }
    fprintf(stderr,"%llu vector instruction cases\n",(unsigned long long)cases);
    return 0;
}
