#include "buster/compiler/x86_64_disassembler_benchmark.c"
int main(void){
 if(!x86_disassembler_initialize())return 1;
 for(unsigned rex=0;rex<16;rex++)for(unsigned op=0;op<256;op++)for(unsigned row=0;row<64;row++){
  for(unsigned phase=0;phase<3;phase++){
   unsigned n=phase==0?3:phase==1?4:15;
   uint8_t source[15]={0x40|rex,op,0xc0|row};uint32_t seed=rex*991+row*31+op;
   for(unsigned j=3;j<n;j++){seed=seed*1664525+1013904223;source[j]=(uint8_t)(seed>>24);}
   X86Decoded out[2]={0};X86DecodeResult result=x86_disassemble(source,n,out,2);
   if(fwrite(&result.count,sizeof result.count,1,stdout)!=1||fwrite(&result.consumed,sizeof result.consumed,1,stdout)!=1||fwrite(&result.status,sizeof result.status,1,stdout)!=1||fwrite(out,sizeof(*out),result.count,stdout)!=result.count)return 2;
  }
 }
 return 0;
}
