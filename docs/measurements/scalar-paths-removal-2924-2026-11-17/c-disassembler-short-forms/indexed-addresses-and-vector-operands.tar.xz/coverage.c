#include "buster/compiler/x86_64_disassembler_benchmark.c"
typedef struct { uint32_t form, count; uint8_t bytes[15], length; } Coverage;
static int order(const void* a, const void* b)
{
    const Coverage *x=a,*y=b;
    return (x->count < y->count) - (x->count > y->count);
}
int main(int argc,char** argv)
{
    if (argc<2 || !x86_disassembler_initialize()) return 2;
    for(int file=1;file<argc;file++) {
        FILE* in=fopen(argv[file],"rb"); if(!in)return 2;
        uint8_t* b=malloc(4096*1024);unsigned n=fread(b,1,4096*1024,in);fclose(in);
        Coverage* counts=calloc(BUSTER_X86_FORM_TEMPLATES,sizeof(*counts)); unsigned total=0,hit=0;
        for(unsigned at=0;at<n;) {
            prof_miss=false;X86Decoded output={0};
            X86DecodeResult r=x86_disassemble(b+at,n-at,&output,1);
            if(r.count!=1 || !r.consumed)return 1;
            ++total;
            if(prof_miss) {
                unsigned f=output.instruction.form & BUSTER_X86_FORM_NUMBER;
                counts[f].form=f; ++counts[f].count;
                counts[f].length=output.length;memcpy(counts[f].bytes,b+at,output.length);
            } else ++hit;
            at+=r.consumed;
        }
        printf("%s total %u table %u slow %u\n",argv[file],total,hit,total-hit);
        qsort(counts,BUSTER_X86_FORM_TEMPLATES,sizeof(*counts),order);
        for(unsigned i=0;i<35 && counts[i].count;i++) {
            Coverage* c=counts+i;
            printf("%5u %5u %-19s ",c->count,c->form,x86_form_descriptions[c->form%X86_FORM_COUNT].mnemonic);
            for(unsigned j=0;j<c->length;j++)printf("%02x",c->bytes[j]);
            putchar('\n');
        }
        free(counts);free(b);
    }
    return 0;
}
