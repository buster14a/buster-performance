#include "buster/compiler/x86_64_disassembler_benchmark.c"
#include <errno.h>
#include <limits.h>
#include <assert.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include "buster/compiler/test_paths.h"
#include "buster/compiler/test_tool.c"
#include "buster/compiler/x86_64_encoder_test.c"
#include "buster/compiler/x86_64_disassembler_test.c"

#include "buster/compiler/x86_64_disassembler_cli.c"
int main(int argc,char** argv)
{
    return argc > 1 && strcmp(argv[1], "disassemble") == 0 ? run_x86_disassembler(argc - 2, argv + 2) : run_x86_disassembler_tests(argc - 1, argv + 1);
}
