#include "buster/compiler/x86_64_disassembler_benchmark.c"
int main(void)
{
    if (!x86_disassembler_initialize()) return 2;
    uint8_t src[16];
    for(uint32_t rex=0;rex<=16;rex++)for(uint32_t opcode=0;opcode<256;opcode++){
        if(!((opcode<64&&(opcode&7)<4)||(opcode>=0x80&&opcode<=0x8d)||opcode==0xe8||opcode==0xe9))continue;
        for(uint32_t row=0;row<256;row++)for(uint32_t trial=0;trial<13;trial++){
            uint32_t state=rex*523+row*727+opcode*907+trial*137;
            for(unsigned i=0;i<16;i++){state=state*1664525+1013904223;src[i]=(uint8_t)(state>>24);}
            uint32_t idx=rex!=0;src[0]=(uint8_t)(0x40|(rex-1));src[idx]=(uint8_t)opcode;
            src[idx+1]=(uint8_t)row;
            if(trial%2==0)src[idx+2]=0x24;
            size_t n=trial==12?16:trial;
            X86Decoded out[2]={0};
            X86DecodeResult r=x86_disassemble(src,n,out,2);
            if(fwrite(&r.count,8,1,stdout)!=1||fwrite(&r.consumed,8,1,stdout)!=1||fwrite(&r.status,4,1,stdout)!=1||fwrite(out,sizeof(*out),r.count,stdout)!=r.count)return 2;
        }
    }
    return 0;
}
