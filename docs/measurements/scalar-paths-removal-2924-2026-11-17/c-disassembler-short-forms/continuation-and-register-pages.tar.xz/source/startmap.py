from pathlib import Path
import difflib
p=Path(__file__).parent;old=p/'factored-src/buster/compiler';d=p/'startmap-src/buster/compiler';d.mkdir(exist_ok=True,parents=True)
f='x86_64_disassembler.c';s=(old/f).read_text()
a=s.index('#define BUSTER_X86_SHORT_FORMS');b=s.index('// A REX prefix',a)
s=s[:a]+'''typedef struct { uint32_t form, operands; } X86DecodeStart;
BUSTER_X86_SHARED BUSTER_BAKED X86DecodeStart x86_decode_starts[256][256];
'''+s[b:]
a=s.index('    uint32_t short_forms = 1;');b=s.index('    uint32_t direct_count = 1;',a)
t=s[a:b];i=t.index('                uint8_t bytes[2]');j=t.index('\n            }\n            X86DecodePagePair',i)
t=t[i:j].replace('(uint8_t)(16 * group + lane)','(uint8_t)next').replace('forms[lane] =','x86_decode_starts[opcode][next].form =').replace('memcpy(registers + lane, &r.reg, sizeof(registers[lane]));','memcpy(&x86_decode_starts[opcode][next].operands, &r.reg, 4);')
s=s[:a]+'''    for (uint32_t opcode = 0; opcode < 256; opcode += 1)
    {
        for (uint32_t next = 0; next < 256; next += 1)
        {
'''+ '\n'.join(x[4:] for x in t.splitlines())+'''
        }
    }
'''+s[b:]
a=s.index('    return true;',s.index('uint32_t short_forms') if 'uint32_t short_forms' in s else s.index('static bool x86_decode_operand_tables_initialize'))
s=s[:a]+'''    for (uint32_t first = 0; first < 256; first += 1)
    {
        for (uint32_t next = 0; next < 256; next += 1)
        {
            X86DecodeStart* const start = &x86_decode_starts[first][next];
            if (start->form == 0)
            {
                const uint32_t rex = (first & 0xf0) == 0x40 ? (first & 15) + 1 : 0;
                const uint32_t dynamic = rex != 0 && next == 0x0f;
                const uint32_t key = rex != 0 ? next : first == 0x0f ? 256 + next : first;
                const uint32_t prefix = (rex != 0) + (first == 0x0f || dynamic);
                const uint32_t direct = rex != 0 ? x86_decode_rex_direct[rex - 1][next] : 0;
                const uint32_t escaped = next != 0x0f ? 0 : first == 0x66 ? 1 : (first & 0xfe) == 0xf2 ? 2u + (first & 1u) : 0;
                start->form = x86_decode_trailing_class[key] | prefix << 8 | rex << 10 | dynamic << 15;
                start->operands = direct | escaped << 16 | key << 20;
            }
        }
    }
'''+s[a:]
a=s.index('            const X86DecodePagePair short_page');b=s.index('            const uint32_t length',a)
s=s[:a]+'''            const X86DecodeStart entry = x86_decode_starts[source[start]][next];
            const uint32_t form = entry.form;
'''+s[b:]
import re
s=re.sub(r'const uint32_t (\w+) = x86_decode_short_registers\[short_page.registers\]\[next & 15\];',r'const uint32_t \1 = entry.operands;',s)
a=s.index('            const X86Decoded* short_form');b=s.index('                    X86DecodeTrailing record;',a)
s=s[:a]+'''            const uint32_t direct = entry.operands & 0xffff;
            const uint32_t legacy = (entry.operands >> 16) & 3;
            const X86Decoded* short_form = NULL;
            if (direct != 0 && remaining >= 3 && (source[start + 2] & 0xc0) == 0xc0)
            {
                short_form = &x86_decode_direct_pages[direct][source[start + 2] & 63];
            }
            else if (legacy != 0 && remaining >= 4 && (source[start + 3] & 0xc0) == 0xc0)
            {
                short_form = &x86_decode_direct_pages[x86_decode_escaped_direct[legacy - 1][source[start + 2]]][source[start + 3] & 63];
            }
            if (short_form != NULL && short_form->length != 0 && short_form->length <= remaining)
            {
                X86Decoded one = *short_form;
                one.offset = (uint32_t)start;
                output[result.count++] = one;
                result.consumed += one.length;
                continue;
            }
            const uint32_t prefix_bytes = (form >> 8) & 3;
            if (remaining >= prefix_bytes + 2u)
            {
                const bool dynamic = (form & 0x8000) != 0;
                const uint32_t key = dynamic ? 256u + source[start + 2] : entry.operands >> 20;
                const uint32_t kind = dynamic ? x86_decode_trailing_class[key] : form & 255;
                if (kind != 0)
                {
                    const uint32_t row = source[start + prefix_bytes + 1];
                    const uint32_t rex = (form >> 10) & 31;
'''+s[b:]
# A real short record can be longer than the remaining bytes only on the last byte.
# Its operands are not a continuation descriptor. Fall through to the lane decoder in that case.
s=s.replace('const uint32_t direct = entry.operands & 0xffff;', 'const uint32_t direct = length == 0 ? entry.operands & 0xffff : 0;').replace('const uint32_t legacy = (entry.operands >> 16) & 3;', 'const uint32_t legacy = length == 0 ? (entry.operands >> 16) & 3 : 0;').replace('if (remaining >= prefix_bytes + 2u)', 'if (length == 0 && remaining >= prefix_bytes + 2u)')
(d/f).write_text(s)
q='x86_64_disassembler_benchmark.c';s=(old/q).read_text().replace('sizeof(x86_decode_short_index) + sizeof(x86_decode_short_forms) + sizeof(x86_decode_short_registers)','sizeof(x86_decode_starts)');(d/q).write_text(s)
(p/'startmap.patch').write_text(''.join(''.join(difflib.unified_diff((old/f).read_text().splitlines(True),(d/f).read_text().splitlines(True),'a/src/buster/compiler/'+f,'b/src/buster/compiler/'+f))for f in (f,q)))
(p/'startmap-task').write_text((p/'factored-task').read_text().replace('factored','startmap').replace('Test shared operand pages in the complete disassembler image','Test predecoded two-byte continuation descriptors for whole disassembly'))
