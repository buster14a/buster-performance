from pathlib import Path
import difflib
p=Path(__file__).parent;original=p/'startmap-src/buster/compiler';dest=p/'unified-src/buster/compiler';dest.mkdir(exist_ok=True,parents=True)
f='x86_64_disassembler.c';s=(original/f).read_text().replace('BUSTER_BAKED X86Decoded x86_decode_direct_pages','BUSTER_BAKED X86DecodeStart x86_decode_direct_pages')
i=s.index('static bool x86_decode_operand_tables_initialize');a=s.index('                const X86Instruction r =',i);b=s.index('\n            }\n',a);pack=s[a:b].replace('x86_decode_starts[opcode][next].','packed.').replace('bytes[1]','final')
s=s[:a]+'                x86_decode_starts[opcode][next] = x86_decode_pack_start(decoded, bytes[1]);'+s[b:]
s=s[:i]+'''static X86DecodeStart x86_decode_pack_start(X86Decoded decoded, uint8_t final)
{
    X86DecodeStart packed = { 0 };
'''+ '\n'.join(l[12:]for l in pack.splitlines())+'''
    return packed;
}

'''+s[i:]
s=s.replace('X86Decoded page[64] = { 0 };','X86DecodeStart page[64] = { 0 };').replace('page[row] = decoded;', 'page[row] = x86_decode_pack_start(decoded, bytes[2]);').replace('page[row] = one;', 'page[row] = x86_decode_pack_start(one, bytes[3]);')
a=s.index('            const uint32_t next = remaining >= 2');b=s.index('            const uint32_t prefix_bytes',a);section=s[a:b];i=section.index('            if (length !=');j=section.index('            const uint32_t direct',i)
t=section[i:j].replace('(int8_t)next','(int8_t)last').replace('(int32_t)next','(int32_t)last').replace('= entry.operands;', '= completed.operands;').replace('form &','completed.form &').replace('(uint16_t)form','(uint16_t)completed.form').replace('(form >>','(completed.form >>')
s=s[:a]+'''            const uint32_t next = remaining >= 2 ? source[start + 1] : 0;
            const X86DecodeStart entry = x86_decode_starts[source[start]][next];
            const uint32_t form = entry.form;
            X86DecodeStart completed = entry;
            uint32_t last = next;
            uint32_t length = (form >> 16) & 15;
            if (length == 0)
            {
                const uint32_t direct = entry.operands & 0xffff;
                const uint32_t legacy = (entry.operands >> 16) & 3;
                if (direct != 0 && remaining >= 3 && (source[start + 2] & 0xc0) == 0xc0)
                {
                    last = source[start + 2];
                    completed = x86_decode_direct_pages[direct][last & 63];
                }
                else if (legacy != 0 && remaining >= 4 && (source[start + 3] & 0xc0) == 0xc0)
                {
                    last = source[start + 3];
                    completed = x86_decode_direct_pages[x86_decode_escaped_direct[legacy - 1][source[start + 2]]][last & 63];
                }
                length = (completed.form >> 16) & 15;
            }
'''+t+s[b:]
(dest/f).write_text(s)
q='x86_64_disassembler_benchmark.c';(dest/q).write_text((original/q).read_text())
(p/'unified.patch').write_text(''.join(difflib.unified_diff((original/f).read_text().splitlines(True),(dest/f).read_text().splitlines(True),'a/src/buster/compiler/'+f,'b/src/buster/compiler/'+f)))
(p/'unified-task').write_text((p/'startmap-task').read_text().replace('startmap','unified').replace('Test predecoded two-byte continuation descriptors for whole disassembly','Measure common compact records for direct and short disassembly templates'))
