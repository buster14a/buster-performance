from pathlib import Path
import difflib
p=Path(__file__).parent;src=p/'paged-src/buster/compiler';dst=p/'factored-src/buster/compiler';dst.mkdir(parents=True,exist_ok=True)
f='x86_64_disassembler.c';s=(src/f).read_text()
a=s.index('// The high four bits');b=s.index('// A REX prefix',a)
s=s[:a]+'''typedef struct X86DecodePagePair X86DecodePagePair;
struct X86DecodePagePair
{
    uint16_t form;
    uint16_t registers;
};
#define BUSTER_X86_SHORT_FORMS 400
#define BUSTER_X86_SHORT_REGISTERS 48
BUSTER_X86_SHARED BUSTER_BAKED X86DecodePagePair x86_decode_short_index[256][16];
BUSTER_X86_SHARED BUSTER_BAKED uint32_t x86_decode_short_forms[BUSTER_X86_SHORT_FORMS][16];
BUSTER_X86_SHARED BUSTER_BAKED uint32_t x86_decode_short_registers[BUSTER_X86_SHORT_REGISTERS][16];
'''+s[b:]
a=s.index('// Each pair of prefix');b=s.index('BUSTER_X86_SHARED BUSTER_BAKED X86DecodeTrailing x86_decode_literal',a)
s=s[:a]+'''#define BUSTER_X86_OPERAND_FORMS 1152
#define BUSTER_X86_OPERAND_REGISTERS 96
BUSTER_X86_SHARED BUSTER_BAKED X86DecodePagePair x86_decode_trailing_index[17][128][8];
BUSTER_X86_SHARED BUSTER_BAKED uint32_t x86_decode_trailing_forms[BUSTER_X86_OPERAND_FORMS][32];
BUSTER_X86_SHARED BUSTER_BAKED uint32_t x86_decode_trailing_registers[BUSTER_X86_OPERAND_REGISTERS][32];
'''+s[b:]
s=s.replace('    uint32_t pages = 1;', '    uint32_t form_pages = 1;\n    uint32_t register_pages = 1;')
a=s.index('            if (modrm && !x86_decode_intern_page(x86_decode_trailing');b=s.index('\n            }',a)+14
s=s[:a]+'''            for (uint32_t group = 0; modrm && group < 8; group += 1)
            {
                uint32_t forms[32];
                uint32_t registers[32];
                for (uint32_t lane = 0; lane < 32; lane += 1)
                {
                    const X86DecodeTrailing r = page[group * 32 + lane];
                    forms[lane] = (uint32_t)r.form | (uint32_t)r.length << 16 | (uint32_t)r.shuffle << 24;
                    registers[lane] = r.registers;
                }
                X86DecodePagePair* const pair = &x86_decode_trailing_index[rex][kind][group];
                if (!x86_decode_intern_page(x86_decode_trailing_forms, BUSTER_X86_OPERAND_FORMS, sizeof(forms), forms, &pair->form, &form_pages) ||
                    !x86_decode_intern_page(x86_decode_trailing_registers, BUSTER_X86_OPERAND_REGISTERS, sizeof(registers), registers, &pair->registers, &register_pages))
                {
                    return false;
                }
            }'''+s[b:]
s=s.replace('    uint32_t short_pages = 1;', '    uint32_t short_forms = 1;\n    uint32_t short_registers = 1;')
s=s.replace('            X86Decoded page[16] = { 0 };','            uint32_t forms[16] = { 0 };\n            uint32_t registers[16] = { 0 };')
s=s.replace('                    page[lane] = decoded;', '''                    const X86Instruction r = decoded.instruction;
                    const int32_t value = r.immediate != 0 ? r.immediate : r.displacement;
                    if (r.vvvv == 0 && r.decorations == 0 && (r.immediate == 0 || r.displacement == 0) &&
                        (value == 0 || value == (int32_t)bytes[1] || value == (int8_t)bytes[1]))
                    {
                        forms[lane] = (uint32_t)r.form | (uint32_t)decoded.length << 16 | (uint32_t)decoded.address32 << 20 |
                                      (r.immediate != 0 ? 1u << 21 : 0) | (r.displacement != 0 ? 1u << 22 : 0) | (value < 0 ? 1u << 23 : 0);
                        memcpy(registers + lane, &r.reg, sizeof(registers[lane]));
                    }''')
s=s.replace('            if (!x86_decode_intern_page(x86_decode_short, BUSTER_X86_SHORT_PAGES, sizeof(page), page, &x86_decode_short_index[opcode][group], &short_pages))','''            X86DecodePagePair* const pair = &x86_decode_short_index[opcode][group];
            if (!x86_decode_intern_page(x86_decode_short_forms, BUSTER_X86_SHORT_FORMS, sizeof(forms), forms, &pair->form, &short_forms) ||
                !x86_decode_intern_page(x86_decode_short_registers, BUSTER_X86_SHORT_REGISTERS, sizeof(registers), registers, &pair->registers, &short_registers))''')
a=s.index('            const uint32_t page = x86_decode_short_index');b=s.index('            if (short_form->length',a)
s=s[:a]+'''            const X86DecodePagePair short_page = x86_decode_short_index[source[start]][next >> 4];
            const uint32_t form = x86_decode_short_forms[short_page.form][next & 15];
            const uint32_t length = form >> 16 & 15;
            if (length != 0 && length <= remaining)
            {
                const int32_t value = (form & (1u << 23)) != 0 ? (int8_t)next : (int32_t)next;
                X86Decoded one = { .instruction.form = (uint16_t)form, .offset = (uint32_t)start,
                                   .length = (uint8_t)length, .address32 = (uint8_t)(form >> 20 & 1) };
                one.instruction.immediate = (form & (1u << 21)) != 0 ? value : 0;
                one.instruction.displacement = (form & (1u << 22)) != 0 ? value : 0;
                const uint32_t registers = x86_decode_short_registers[short_page.registers][next & 15];
                memcpy(&one.instruction.reg, &registers, sizeof(registers));
                output[result.count++] = one;
                result.consumed += length;
                continue;
            }
            const X86Decoded* short_form = x86_decode_direct_pages[0];
'''+s[b:]
a=s.index('                    const X86DecodeTrailing* recipe = kind ==');b=s.index('                    const X86DecodeShuffle*',a)
s=s[:a]+'''                    X86DecodeTrailing record;
                    if (kind == 0xff)
                    {
                        record = x86_decode_literal[rex][key];
                    }
                    else
                    {
                        const X86DecodePagePair page = x86_decode_trailing_index[rex][kind][row >> 5];
                        const uint32_t fields = x86_decode_trailing_forms[page.form][row & 31];
                        record.registers = x86_decode_trailing_registers[page.registers][row & 31];
                        record.form = (uint16_t)fields;
                        record.length = (uint8_t)(fields >> 16);
                        record.shuffle = (uint8_t)(fields >> 24);
                    }
                    const X86DecodeTrailing* recipe = &record;
'''+s[b:]
(dst/f).write_text(s)
f='x86_64_disassembler_benchmark.c';s=(src/f).read_text().replace('sizeof(x86_decode_short)','sizeof(x86_decode_short_forms) + sizeof(x86_decode_short_registers)').replace('sizeof(x86_decode_trailing)','sizeof(x86_decode_trailing_forms) + sizeof(x86_decode_trailing_registers)')
(dst/f).write_text(s)
(p/'factored.patch').write_text(''.join(''.join(difflib.unified_diff((src/f).read_text().splitlines(True),(dst/f).read_text().splitlines(True),'a/src/buster/compiler/'+f,'b/src/buster/compiler/'+f))for f in ('x86_64_disassembler.c',f)))
(p/'factored-task').write_text((p/'paged-task').read_text().replace('paged','factored'))
