#include "buster/compiler/x86_64_disassembler_benchmark.c"
static size_t width;
static int cmp(const void*a,const void*b){return memcmp(*(const char*const*)a,*(const char*const*)b,width);}
static void measure(const char* name,void* data,size_t count,size_t item,size_t step) {
 width=item*step;const char** rows=malloc(count/step*sizeof(*rows));
 for(size_t i=0;i<count/step;i++)rows[i]=(const char*)data+i*width;
 qsort(rows,count/step,sizeof(*rows),cmp);
 unsigned n=1;
 for(size_t i=1;i<count/step;i++)n+=memcmp(rows[i-1],rows[i],width)!=0;
 printf("%s %zu %u %zu\n",name,step,n,n*width);free(rows);
}
int main(void){if(!x86_disassembler_initialize())return 1;
 size_t n=sizeof(x86_decode_trailing)/sizeof(X86DecodeTrailing);
 uint32_t* forms=malloc(n*4),*regs=malloc(n*4);
 for(size_t i=0;i<n;i++){X86DecodeTrailing *t=(X86DecodeTrailing*)x86_decode_trailing+i;memcpy(forms+i,&t->form,4);regs[i]=t->registers;}
 for(size_t block=8;block<=256;block*=2){measure("operand-form",forms,n,4,block);measure("operand-regs",regs,n,4,block);}
 size_t awkward=0,disp=0,imm=0,addr=0,decor=0,both=0,nonbyte=0;
 for(size_t a=0;a<256;a++)for(size_t b=0;b<256;b++){X86Decoded rec=x86_decode_short[a|(b<<8)];X86Instruction i=rec.instruction;
   awkward+=i.vvvv!=0;addr+=rec.address32!=0;decor+=i.decorations!=0;disp+=i.displacement!=0;imm+=i.immediate!=0;both+=i.immediate!=0&&i.displacement!=0;
   nonbyte+= (i.immediate && i.immediate!=(int)b && i.immediate!=(int8_t)b)||(i.displacement && i.displacement!=(int8_t)b && i.displacement!=(int)b);
   forms[a*256+b]=i.form|rec.length<<16|rec.address32<<20|((i.immediate!=0 && i.immediate==(int)b)?1u:(i.immediate!=0?2u:0u))<<28|((i.displacement!=0 && i.displacement==(int8_t)b)?1u:(i.displacement!=0?2u:0u))<<30;
   memcpy(regs+a*256+b,&i.reg,4);}
 printf("short values: vvvv %zu addr32 %zu decorations %zu displacements %zu immediates %zu both %zu unexpected %zu\n",awkward,addr,decor,disp,imm,both,nonbyte);
 for(size_t block=4;block<=256;block*=2){measure("short-head",forms,65536,4,block);measure("short-regs",regs,65536,4,block);}
 free(regs);free(forms);return 0;}
