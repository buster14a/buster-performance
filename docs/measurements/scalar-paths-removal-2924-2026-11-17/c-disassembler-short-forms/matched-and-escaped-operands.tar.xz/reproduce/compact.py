from pathlib import Path
p=Path(__file__).parent
s=(p/'production-integer.c').read_text()
s=s.replace('X86Decoded x86_decode_rex_direct[16][256][64];','''uint16_t x86_decode_rex_direct[16][256];
BUSTER_X86_SHARED BUSTER_BAKED uint16_t x86_decode_escaped_direct[3][256];
// The catalogue uses fewer than 540 distinct pages for the 4,864 prefix/opcode pairs.
#define BUSTER_X86_DIRECT_PAGES 640
BUSTER_X86_SHARED BUSTER_BAKED X86Decoded x86_decode_direct_pages[BUSTER_X86_DIRECT_PAGES][64];''').replace('BUSTER_X86_SHARED BUSTER_BAKED X86Decoded x86_decode_escaped_direct[3][256][64];\n','')
s=s.replace('    X86Decoded record;\n    uint8_t fields[8];','''    uint32_t registers;
    uint16_t form;
    uint8_t length;
    uint8_t shuffle;
};
typedef struct X86DecodeShuffle X86DecodeShuffle;
struct X86DecodeShuffle
{
    uint8_t fields[8];''')
s=s.replace('BUSTER_X86_SHARED BUSTER_BAKED uint8_t x86_decode_trailing_class', '''// Masks are shared by instructions with the same field lengths and positions.
BUSTER_X86_SHARED BUSTER_BAKED X86DecodeShuffle x86_decode_shuffles[256];
BUSTER_X86_SHARED BUSTER_BAKED uint8_t x86_decode_trailing_class''')
s=s.replace('static bool x86_disassembler_initialize(void)\n{','''// Intern the 64 ModRM register encodings of a prefix/opcode pair. Page zero
// is the empty page, so unavailable forms use the ordinary lane decoder.
static bool x86_decode_intern_direct(const X86Decoded page[64], uint16_t* index, uint32_t* count)
{
    uint32_t row = 0;
    while (row < *count && memcmp(page, x86_decode_direct_pages[row], sizeof(x86_decode_direct_pages[row])) != 0)
    {
        row += 1;
    }
    if (row == BUSTER_X86_DIRECT_PAGES)
    {
        return false;
    }
    if (row == *count)
    {
        memcpy(x86_decode_direct_pages[row], page, sizeof(x86_decode_direct_pages[row]));
        *count += 1;
    }
    *index = (uint16_t)row;
    return true;
}

static bool x86_disassembler_initialize(void)
{''')
s=s.replace('                for (uint32_t rex = 0; rex < 16; rex += 1)','''                uint32_t direct_count = 1;
                uint32_t shuffle_count = 0;
                for (uint32_t rex = 0; rex < 16; rex += 1)''',1)
s=s.replace('                        for (uint32_t row = 0; row < 64; row += 1)','                        X86Decoded page[64] = { 0 };\n                        for (uint32_t row = 0; row < 64; row += 1)')
for array,ind,v in [('rex','rex][opcode','decoded'),('escaped','prefix][op','one')]:
 search=f'                                x86_decode_{array}_direct[{ind}][row] = {v};\n                            }}\n                        }}'
 assert search in s
 s=s.replace(search, f'''                                page[row] = {v};
                            }}
                        }}
                        if (!x86_decode_intern_direct(page, &x86_decode_{array}_direct[{ind}], &direct_count))
                        {{
                            x86_decode_initialized = false;
                            return false;
                        }}''')
s=s.replace('                        return false;\n                    }\n                    for (uint32_t rex', '                        x86_decode_initialized = false;\n                        return false;\n                    }\n                    for (uint32_t rex')
s=s.replace('                            out->record = record;\n                            out->sib', '''                            if (record.address32 || record.instruction.vvvv != 0 || record.instruction.decorations != 0)
                            {
                                continue;
                            }
                            memcpy(&out->registers, &record.instruction.reg, sizeof(out->registers));
                            out->form = record.instruction.form;
                            out->length = record.length;
                            X86DecodeShuffle shuffle = { 0 };
                            shuffle.sib''').replace('                            out->sign_bytes', '                            shuffle.sign_bytes').replace('out->fields[','shuffle.fields[')
anchor=s.index('                                shuffle.fields[4 + byte] =')
end=s.index('\n                            }',anchor)+30
assert s[end-1]=='}',repr(s[end-3:end+4])
s=s[:end]+'''
                            uint32_t id = 0;
                            while (id < shuffle_count && memcmp(&shuffle, &x86_decode_shuffles[id], sizeof(shuffle)) != 0)
                            {
                                id += 1;
                            }
                            if (id == 256)
                            {
                                x86_decode_initialized = false;
                                return false;
                            }
                            if (id == shuffle_count)
                            {
                                x86_decode_shuffles[shuffle_count++] = shuffle;
                            }
                            out->shuffle = (uint8_t)id;'''+s[end:]
s=s.replace('&x86_decode_rex_direct[source[start] & 15][source[start + 1]][source[start + 2] & 63]', '&x86_decode_direct_pages[x86_decode_rex_direct[source[start] & 15][source[start + 1]]][source[start + 2] & 63]').replace('&x86_decode_escaped_direct[legacy][source[start + 2]][source[start + 3] & 63]', '&x86_decode_direct_pages[x86_decode_escaped_direct[legacy][source[start + 2]]][source[start + 3] & 63]')
s=s.replace('const uint32_t n = recipe->record.length;', 'const X86DecodeShuffle* shuffle = &x86_decode_shuffles[recipe->shuffle];\n                    const uint32_t n = recipe->length;').replace('recipe->sib','shuffle->sib').replace('recipe->fields','shuffle->fields').replace('recipe->sign_bytes','shuffle->sign_bytes').replace('X86Decoded one = recipe->record;', '''X86Decoded one = { .instruction.form = recipe->form, .length = recipe->length };
                        memcpy(&one.instruction.reg, &recipe->registers, sizeof(recipe->registers));''')
out=p/'compact-src/buster/compiler';out.mkdir(parents=True,exist_ok=True)
(out/'x86_64_disassembler.c').write_text(s)
