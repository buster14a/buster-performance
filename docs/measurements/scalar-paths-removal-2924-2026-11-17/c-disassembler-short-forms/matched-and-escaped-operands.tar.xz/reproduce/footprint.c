#include "buster/compiler/x86_64_disassembler_benchmark.c"
static size_t width;
static int rows_compare(const void* left,const void* right) {return memcmp(*(const uint8_t*const*)left,*(const uint8_t*const*)right,width);}
static void measure(const char* name,const void* raw,size_t count,size_t step) {
    const uint8_t* data=raw;
    for(unsigned page=1;page<=256;page*=4) {
        if(count%page)continue;
        width=page*step;size_t pages=count/page;
        const uint8_t** order=malloc(sizeof(*order)*pages);
        for(size_t i=0;i<pages;i++)order[i]=data+i*width;
        qsort(order,pages,sizeof(*order),rows_compare);
        size_t unique=1;for(size_t i=1;i<pages;i++)unique+=memcmp(order[i-1],order[i],width)!=0;
        printf("%s %u %zu %zu %zu %zu\n",name,page,pages,unique,count*step,unique*width+pages*(unique<65536?2:4));
        free(order);
    }
}
int main(void) {
    if(!x86_disassembler_initialize())return 1;
    measure("short",x86_decode_short,65536,sizeof(X86Decoded));
    measure("rex",x86_decode_rex_direct,16*256*64,sizeof(X86Decoded));
    measure("escaped",x86_decode_escaped_direct,3*256*64,sizeof(X86Decoded));
    measure("trailing",x86_decode_trailing,17*64*256,sizeof(X86DecodeTrailing));
    measure("literal",x86_decode_literal,17*256,sizeof(X86DecodeTrailing));
    return 0;
}
