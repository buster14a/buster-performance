#include "buster/compiler/x86_64_disassembler_benchmark.c"
static void sample(const uint8_t *p, unsigned n) {
    X86Decoded out[3]={0};const X86DecodeResult r=x86_disassemble(p,n,out,3);
    if(fwrite(&r.count,8,1,stdout)!=1||fwrite(&r.consumed,8,1,stdout)!=1||fwrite(&r.status,4,1,stdout)!=1||fwrite(out,sizeof(*out),r.count,stdout)!=r.count)exit(2);
}
int main(void) {
    if(!x86_disassembler_initialize())return 2;
    uint32_t state=2924;
    for(unsigned rex=0;rex<=16;rex++)for(unsigned op=0;op<256;op++)for(unsigned next=0;next<256;next++) {
        uint8_t b[20];for(unsigned j=0;j<sizeof(b);j++){state=state*1664525+1013904223;b[j]=(uint8_t)(state>>24);}
        unsigned pos=rex!=0;b[0]=(uint8_t)(0x40|(rex-1));b[pos]=(uint8_t)op;b[pos+1]=(uint8_t)next;
        sample(b,20);sample(b,1+state%15);sample(b,2+pos);
    }
    return 0;
}
