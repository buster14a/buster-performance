from pathlib import Path
import textwrap
p=Path(__file__).parent
s=(p/'escape-src/buster/compiler/x86_64_disassembler.c').read_text()
a=s.index('                for (uint32_t prefix = 0; prefix < 65536;')
b=s.index('\n            }\n        }\n    }\n    return result;',a)
body=textwrap.dedent(s[a:b]).replace('x86_decode_initialized = false;\n','')
# Re-indent only the inner success/failure paths changed above.
import re
body=re.sub(r'^( +)\{\n +return false;\n\1}',r'\1{\n\1    return false;\n\1}',body,flags=re.M)
split=body.index('uint32_t next_class')
end=body.index('const uint8_t legacy[3]')
params=body[split:end].replace('uint32_t next_class = 1;','uint32_t next_class = 1;\nuint32_t shuffle_count = 0;').rstrip()
body=body[:split]+body[end:]
body=body.replace('uint32_t shuffle_count = 0;\n','')
pos=body.index('for (uint32_t rex = 0; rex <= 16;')
body=body[:pos]+'''if (!x86_decode_trailing_initialize())
{
    return false;
}
'''+body[pos:]
# Construct the trailing tables before escaped direct pages, matching the measured initialization.
pos=body.index('const uint8_t legacy[3]'); anchor='if (!x86_decode_trailing_initialize())\n{\n    return false;\n}\n'
body=body.replace(anchor,'');body=body[:pos]+anchor+body[pos:]
s=s[:a]+'''                // The ordinary lane tables are ready for decoding the catalogue samples below.
                result = x86_decode_operand_tables_initialize();
                x86_decode_initialized = result;'''+s[b:]
a=s.index('static bool x86_disassembler_initialize(void)\n{')
helpers='''// Build the values and byte shuffles for integer and unprefixed 0F forms.
static bool x86_decode_trailing_initialize(void)
{
'''+textwrap.indent(params,'    ')+'''
    return true;
}

// Bake complete short encodings, register-ModRM pages and the SIB register fields
// by decoding their canonical bytes against the catalogue.
static bool x86_decode_operand_tables_initialize(void)
{
'''+textwrap.indent(body.rstrip(),'    ')+'''
    return true;
}

'''
s=s[:a]+helpers+s[a:]
s=s.replace('||\n                                                   opcode', '||\n                                       opcode')
s=s.replace('x86_decode_trailing_class[512];','x86_decode_trailing_class[512];')
out=p/'compact-tree/src/buster/compiler/x86_64_disassembler.c';out.write_text(s)
