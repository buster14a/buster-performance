from pathlib import Path
p=Path(__file__).parent
s=(p/'compact-src/buster/compiler/x86_64_disassembler.c').read_text()
s=s.replace('x86_decode_trailing_class[256]','x86_decode_trailing_class[512]').replace('x86_decode_trailing[17][64][256]','x86_decode_trailing[17][128][256]').replace('x86_decode_literal[17][256]','x86_decode_literal[17][512]')
a=s.index('                uint32_t next_class');b=s.index('                const uint8_t legacy[3]',a)
part=s[a:b].replace('for (uint32_t opcode = 0; opcode < 256; opcode += 1)','for (uint32_t key = 0; key < 512; key += 1)').replace('                    const bool modrm = ','''                    const uint32_t opcode = key & 255;
                    const bool escaped = key >= 256;
                    const bool modrm = escaped ? ((opcode >= 0x40 && opcode <= 0x4f) || (opcode >= 0x90 && opcode <= 0x9f) ||
                                                   opcode == 0xb6 || opcode == 0xb7 || opcode == 0xbe || opcode == 0xbf || opcode == 0xaf ||
                                                   opcode == 0x28 || opcode == 0x29 || opcode == 0x57) :
                                                ''').replace('                    const bool literal = ','''                    const bool literal = escaped ? (opcode >= 0x80 && opcode <= 0x8f) :
                                                   ''').replace('modrm && kind >= 64','modrm && kind >= 128').replace('const uint32_t prefix = rex != 0;', 'const uint32_t prefix = (rex != 0) + (uint32_t)escaped;').replace('                            bytes[prefix] = (uint8_t)opcode;', '''                            if (escaped)
                            {
                                bytes[prefix - 1] = 0x0f;
                            }
                            bytes[prefix] = (uint8_t)opcode;''').replace('&x86_decode_literal[rex][opcode]','&x86_decode_literal[rex][key]').replace('x86_decode_trailing_class[opcode]', 'x86_decode_trailing_class[key]')
s=s[:a]+part+s[b:]
a=s.index('            const uint32_t rex_prefix =', s.index('// Decodes `source[0, size)'))
b=s.index("            if (source[start] == 0x62",a)
part=s[a:b].replace('                const uint32_t opcode = source[start + rex_prefix];\n                const uint32_t kind = x86_decode_trailing_class[opcode];\n                if (kind != 0)', '''                const bool escaped = source[start + rex_prefix] == 0x0f;
                const uint32_t prefix_bytes = rex_prefix + (uint32_t)escaped;
                const uint32_t key = ((uint32_t)escaped << 8) | source[start + prefix_bytes];
                const uint32_t kind = x86_decode_trailing_class[key];
                if (kind != 0 && remaining >= prefix_bytes + 2u)''').replace('source[start + rex_prefix + 1]', 'source[start + prefix_bytes + 1]').replace('source[start + rex_prefix + 2]', 'source[start + prefix_bytes + 2]').replace('&x86_decode_literal[rex][opcode]', '&x86_decode_literal[rex][key]')
s=s[:a]+part+s[b:]
out=p/'escape-src/buster/compiler';out.mkdir(parents=True,exist_ok=True);(out/'x86_64_disassembler.c').write_text(s)
