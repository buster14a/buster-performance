from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent; dest=p/'groups-src/buster/compiler';dest.mkdir(parents=True,exist_ok=True)
prior=p/'deposited-src/buster/compiler'; plain=p/'inlinefield-src/buster/compiler';f='x86_64_disassembler.c';q='x86_64_disassembler_benchmark.c'
s=(plain/f).read_text()
s=s.replace('BUSTER_X86_SHARED BUSTER_BAKED X86DecodeStart x86_decode_starts[256][256];','''typedef struct
{
    X86DecodeStart common;
    uint16_t offset;
    uint16_t different;
} X86DecodeStartGroup;
BUSTER_X86_SHARED BUSTER_BAKED X86DecodeStartGroup x86_decode_start_groups[256][16];
// Each group contains its common record at least once, leaving at most fifteen exceptions.
BUSTER_X86_SHARED BUSTER_BAKED X86DecodeStart x86_decode_start_exceptions[256 * 16 * 15];''')
i=s.index('static bool x86_decode_operand_tables_initialize(void)\n{');a=s.index('    for (uint32_t opcode =',i);b=s.index('    uint32_t direct_count',a)
s=s[:a]+s[b:]
a=s.index('    for (uint32_t first =',i);b=s.index('    return true;',a)
other=(p/'dictionaries-src/buster/compiler'/f).read_text();i=other.index('    uint32_t forms = 1;');c=other.index('            const uint8_t bytes',i);e=other.index('            uint16_t form = 0;',c)
inner=other[c:e]
t='''    uint32_t exceptions = 0;
    for (uint32_t first = 0; first < 256; first += 1)
    {
        for (uint32_t group = 0; group < 16; group += 1)
        {
            X86DecodeStart entries[16];
            for (uint32_t lane = 0; lane < 16; lane += 1)
            {
                const uint32_t next = group * 16 + lane;
'''+''.join('    '+l for l in inner.splitlines(True))+'''                entries[lane] = entry;
            }
            // Choose the most common complete record, including registers. Ties keep the first.
            uint32_t best = 0;
            uint32_t most = 0;
            for (uint32_t i = 0; i < 16; i += 1)
            {
                uint32_t count = 0;
                for (uint32_t j = 0; j < 16; j += 1)
                {
                    count += entries[j].form == entries[i].form && entries[j].operands == entries[i].operands;
                }
                if (count > most)
                {
                    best = i;
                    most = count;
                }
            }
            X86DecodeStartGroup record = { .common = entries[best], .offset = (uint16_t)exceptions };
            for (uint32_t i = 0; i < 16; i += 1)
            {
                if (entries[i].form != record.common.form || entries[i].operands != record.common.operands)
                {
                    record.different |= (uint16_t)(1u << i);
                    x86_decode_start_exceptions[exceptions++] = entries[i];
                }
            }
            x86_decode_start_groups[first][group] = record;
        }
    }
'''
s=s[:a]+t+s[b:]
s=s.replace('const X86DecodeStart entry = x86_decode_starts[source[start]][next];','''const X86DecodeStartGroup group = x86_decode_start_groups[source[start]][next >> 4];
            const uint32_t bit = 1u << (next & 15);
            const X86DecodeStart entry = (group.different & bit) == 0 ? group.common :
                x86_decode_start_exceptions[group.offset + (uint32_t)__builtin_popcount(group.different & (bit - 1))];''')
(dest/f).write_text(s)
(dest/q).write_text((plain/q).read_text().replace('sizeof(x86_decode_starts)', 'sizeof(x86_decode_start_groups) + sizeof(x86_decode_start_exceptions)'))
def diff(name):return ''.join(unified_diff((prior/name).read_text().splitlines(True),(dest/name).read_text().splitlines(True),'a/src/buster/compiler/'+name,'b/src/buster/compiler/'+name))
(p/'groups.patch').write_text(diff(f)+diff(q))
task=(p/'deposited-task').read_text().replace('deposited','groups').replace('git apply ../groups.patch','while [[ ! -f ../deposited-cli.ok ]]; do sleep 10; done\ngit apply ../groups.patch').replace('Decode register fields directly from the 32-bit start record','Share the common decoded record across neighboring two-byte keys')
(p/'groups-task').write_text(task)
