from pathlib import Path
import os,subprocess,sys,time
r=Path('/dev/shm/buster-decode-escape-6b097f86')
dense=Path('/dev/shm/buster-address-6b097f86/dense')
d=r/'cold-cost-final';d.mkdir(exist_ok=True)
bins={'main':Path('/dev/shm/buster-adler-production-6b097f86/src/build/adler-base'),'owner':r/'checkout/build/image-original','pr':r/'checkout/build/image-escape'}
if len(sys.argv)==1:
 (d/'empty.bin').write_bytes(b'')
 (d/'one.bin').write_bytes(b'\x90')
 (d/'lvm8.bin').write_bytes((dense/'lvm.bin').read_bytes()*8)
 for i in range(7):
  for group in ['empty','one','ltable','lcode','lvm','lvm8']:
   subprocess.run([str(Path.home()/'buster-fast-bench/exclusive.sh'),'taskset','-c','2','python3',__file__,str(i),group],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 (d/'done').touch()
else:
 i=int(sys.argv[1]);g=sys.argv[2]
 f=(d if g in ('empty','one','lvm8') else dense)/(g+'.bin')
 labels=list(bins)
 if i%2:labels.reverse()
 for j in range(3):
  for k in (labels[j:]+labels[:j]):
   args=[str(bins[k]),'disassemble',str(f)]
   with open(os.devnull,'wb') as dev:
    start=time.monotonic_ns()
    pid=os.posix_spawn(args[0],args,os.environ,file_actions=[(os.POSIX_SPAWN_DUP2,dev.fileno(),1),(os.POSIX_SPAWN_DUP2,dev.fileno(),2)])
    pid,status,use=os.wait4(pid,0); ns=time.monotonic_ns()-start
   with (d/'time.tsv').open('a') as log:print(i,g,j,k,os.waitstatus_to_exitcode(status),ns,use.ru_minflt,use.ru_majflt,use.ru_utime,use.ru_stime,sep='\t',file=log)
   if i==0 and j==0:
    with open(os.devnull,'wb') as dev:
     subprocess.run(['perf','stat','-x','\t','-o',str(d/f'perf-{g}-{k}.tsv'),'-e','cycles,instructions,minor-faults,major-faults,task-clock','--',*args],stdout=dev,stderr=dev)
