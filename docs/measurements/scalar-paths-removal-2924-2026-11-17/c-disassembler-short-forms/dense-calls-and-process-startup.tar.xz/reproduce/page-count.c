#include "buster/compiler/x86_64_disassembler_benchmark.c"
static size_t width;
static int cmp(const void*a,const void*b){return memcmp(*(const char*const*)a,*(const char*const*)b,width);}
static void measure(const char* label,const void* data,size_t count,size_t item,size_t step) {
 width=item*step;const char** p=malloc(count/step*sizeof(*p));
 for(size_t i=0;i<count/step;i++)p[i]=(const char*)data+i*width;
 qsort(p,count/step,sizeof(*p),cmp);
 size_t n=1;for(size_t i=1;i<count/step;i++)n+=memcmp(p[i-1],p[i],width)!=0;
 printf("%s %zu %zu %zu\n",label,step,n,n*width);free(p);
}
int main(void){if(!x86_disassembler_initialize())return 1;
 X86Decoded *t=calloc(65536,sizeof(*t));
 for(size_t k=0;k<65536;k++)t[((k&255)<<8)|(k>>8)]=x86_decode_short[k];
 for(size_t step=1;step<=256;step*=2){
 measure("short",t,65536,sizeof(*t),step);
 measure("trailing",x86_decode_trailing,17*128*256,sizeof(X86DecodeTrailing),step);
 }
 return 0;}
