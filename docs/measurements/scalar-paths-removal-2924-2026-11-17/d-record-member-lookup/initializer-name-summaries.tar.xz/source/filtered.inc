static uint8_t name_filter_bit(uint32_t name)
{
    const uint32_t hash=name*UINT32_C(2654435761);
    return (uint8_t)(1u << (uint32_t)(((uint64_t)hash*5)>>32));
}
static uint32_t tagged_walk_frontier(const TypeTable* table, TypeId record, uint32_t name, uint64_t* offset, uint32_t* qualifiers)
{
    typedef struct TypeMemberFrame TypeMemberFrame;
    struct TypeMemberFrame
    {
        uint32_t next;
        uint32_t end;
        uint32_t qualifiers;
        uint64_t offset;
    };
    const TypeId root = type_strip_aligned(table, record);
    const uint8_t kind = type_kind(table, root);
    const bool searching = name != 0 && (kind == BUSTER_TYPE_KIND_STRUCT || kind == BUSTER_TYPE_KIND_UNION);
    if (!searching)
    {
        *offset = 0;
        *qualifiers = 0;
        return 0;
    }
    const uint32_t root_tag = table->types.index[type_index(root)];
    const uint32_t root_end = table->tags.member_begin[root_tag] + table->tags.member_count[root_tag];
    const uint32_t first = frontier_next_candidate(table, table->tags.member_begin[root_tag], root_end, name);
    if (first == root_end || table->members.name[first] == name)
    {
        const bool found = first != root_end;
        *offset = found ? table->members.offset[first] : 0;
        *qualifiers = found ? type_qualifiers(root) : 0;
        return found ? first : 0;
    }
    enum { LOCAL_TAGS = 8 };
    TypeMemberFrame local_stack[LOCAL_TAGS];
    uint32_t local_seen[LOCAL_TAGS] = {type_index(root)};
    TypeMemberFrame* stack = local_stack;
    uint32_t* seen = local_seen;
    uint32_t* places = NULL;
    Scratch scratch = {0};
    uint32_t depth = 0;
    uint32_t seen_count = 1;
    TypeMemberFrame current = {.next = first, .end = root_end, .qualifiers = type_qualifiers(root)};
    uint32_t member = first;
    uint32_t result = 0;
    for (;;)
    {
        if (member == current.end)
        {
            if (depth == 0) break;
            current = stack[--depth];
        }
        else if (table->members.name[member] == name)
        {
            result = member;
            current.offset += table->members.offset[member];
            break;
        }
        else
        {
            current.next = member + 1;
            const TypeId inner = type_strip_aligned(table, table->members.type[member]);
            const uint8_t kind = type_kind(table, inner);
            if (kind == BUSTER_TYPE_KIND_STRUCT || kind == BUSTER_TYPE_KIND_UNION)
            {
                const uint32_t index = type_index(inner);
                const uint32_t tag = table->types.index[index];
                const uint32_t begin = table->tags.member_begin[tag];
                const uint32_t size = table->tags.member_count[tag];
                if (table->tags.lookup[tag] == 0)
                {
                    result = type_lookup_scan(table->members.name, begin, size, name);
                    if (result != 0)
                    {
                        current.offset += table->members.offset[member] + table->members.offset[result];
                        current.qualifiers |= type_qualifiers(inner);
                        break;
                    }
                }
                else
                {
                    const bool visited = places != NULL ? places[index] < seen_count && seen[places[index]] == index :
                        _mm256_cmpeq_epi32_mask(_mm256_loadu_si256((const __m256i*)local_seen), _mm256_set1_epi32((int)index)) != 0;
                    if (!visited)
                    {
                        if (seen_count == LOCAL_TAGS && places == NULL)
                        {
                            scratch = scratch_begin(0);
                            stack = BUSTER_ARENA_PUSH_ARRAY(scratch.arena, TypeMemberFrame, table->tags.count);
                            seen = stack != NULL ? BUSTER_ARENA_PUSH_ARRAY(scratch.arena, uint32_t, table->tags.count) : NULL;
                            places = seen != NULL ? BUSTER_ARENA_PUSH_ARRAY(scratch.arena, uint32_t, table->types.count) : NULL;
                            if (places == NULL)
                            {
                                result = BUSTER_TYPE_MEMBER_UNKNOWN;
                                break;
                            }
                            memcpy(stack, local_stack, depth * sizeof(*stack));
                            memcpy(seen, local_seen, sizeof(local_seen));
                            _mm256_i32scatter_epi32(places, _mm256_loadu_si256((const __m256i*)local_seen), _mm256_setr_epi32(0,1,2,3,4,5,6,7), 4);
                        }
                        if (places != NULL) places[index] = seen_count;
                        seen[seen_count++] = index;
                        if (current.next < current.end) stack[depth++] = current;
                        current.next = begin;
                        current.end = begin + size;
                        current.offset += table->members.offset[member];
                        current.qualifiers |= type_qualifiers(inner);
                    }
                }
            }
        }
        member = frontier_next_candidate(table, current.next, current.end, name);
    }
    if (scratch.arena != NULL) scratch_end(scratch);
    const bool found = result != 0 && result != BUSTER_TYPE_MEMBER_UNKNOWN;
    *offset = found ? current.offset : 0;
    *qualifiers = found ? current.qualifiers : 0;
    return result;
}
static bool init_child_contains(const TypeTable* types, TypeId type, uint32_t name)
{
    const TypeId base=type_strip_aligned(types,type);
    const uint8_t kind=type_kind(types,base);
    if(!name || (kind!=BUSTER_TYPE_KIND_STRUCT && kind!=BUSTER_TYPE_KIND_UNION))return false;
    const uint32_t child=types->types.index[type_index(base)],lookup=types->tags.lookup_log2[child] >= 128 ? BUSTER_TYPE_LOOKUP_WALK : types->tags.lookup[child];
    if(lookup==0)return type_lookup_scan(types->members.name,types->tags.member_begin[child],types->tags.member_count[child],name)!=0;
    if(lookup!=BUSTER_TYPE_LOOKUP_WALK)return type_lookup_probe(types->lookup.buckets,lookup,types->tags.lookup_log2[child],name)!=0;
    uint64_t offset;uint32_t qualifiers;
    const uint32_t result=tagged_walk_frontier(types,base,name,&offset,&qualifiers);
    return result!=0 && result!=BUSTER_TYPE_MEMBER_UNKNOWN;
}

static inline uint32_t init_anonymous_lanes(const TypeTable* types,uint32_t at,uint32_t mask)
{
    const __m128i flags=_mm_maskz_loadu_epi8((__mmask16)mask,types->members.flags+at);
    return mask & ~_mm_test_epi8_mask(flags,_mm_set1_epi8(BUSTER_TYPE_MEMBER_BIT_FIELD));
}
static uint32_t init_cache(const TypeTable* types, uint32_t tag, uint32_t name, bool scalar)
{
    const uint32_t begin = types->tags.member_begin[tag];
    const uint32_t count = types->tags.member_count[tag];
    const uint32_t lookup = types->tags.lookup[tag];
    const uint32_t* const names = types->members.name;
    uint32_t member = 0;
    const uint8_t encoding=types->tags.lookup_log2[tag];
    if (lookup == 0)
    {
        member = scalar ? type_lookup_scan_scalar(names, begin, count, name) : type_lookup_scan(names, begin, count, name);
    }
    else if (encoding < 128)
    {
        const uint32_t log2 = types->tags.lookup_log2[tag];
        member = scalar ? type_lookup_probe_scalar(types->lookup.buckets, lookup, log2, name) :
                          type_lookup_probe(types->lookup.buckets, lookup, log2, name);
    }
    else
    {
        // The tag stores a nonzero lookup word so an ordinary short scan needs just its original test.
        if ((encoding & 64) ? name == 0 : lookup == name)return begin;
        if (!(encoding & name_filter_bit(name)))return 0;
        if (encoding & 32)return init_child_contains(types,types->members.type[begin],name) ? begin : 0;
        const uint32_t end=begin+count;
        const __m512i wanted=_mm512_set1_epi32((int)name);
        uint32_t first=end, saved=0;
        for(uint32_t at=begin;at<end;)
        {
            const uint32_t n=end-at<16?end-at:16;
            const __mmask16 live=(__mmask16)_bzhi_u32(UINT16_MAX,n);
            const __m512i packet=_mm512_maskz_loadu_epi32(live,names+at);
            const uint32_t direct=_mm512_mask_cmpeq_epi32_mask(live,packet,wanted);
            if(direct)return at+(uint32_t)__builtin_ctz(direct);
            if(first==end)
            {
                const uint32_t zero=_mm512_mask_cmpeq_epi32_mask(live,packet,_mm512_setzero_si512());
                if(zero)
                {
                    saved=init_anonymous_lanes(types,at,zero);
                    if(saved)first=at;
                }
            }
            at+=n;
        }
        while(first<end)
        {
            while(saved)
            {
                const uint32_t row=first+(uint32_t)__builtin_ctz(saved);
                if(init_child_contains(types,types->members.type[row],name))return row;
                saved &= saved-1;
            }
            first+=end-first<16?end-first:16;
            if(first!=end)
            {
                const __mmask16 live=(__mmask16)(end-first>=16?UINT16_MAX:(1u<<(end-first))-1u);
                const __m512i packet=_mm512_maskz_loadu_epi32(live,names+first);
                const uint32_t zeros=_mm512_mask_cmpeq_epi32_mask(live,packet,_mm512_setzero_si512());
                saved=zeros?init_anonymous_lanes(types,first,zeros):0;
            }
        }
    }
    return member;
}
static uint32_t init_split(const TypeTable* types, uint32_t tag, uint32_t name, bool scalar)
{
    const uint32_t begin = types->tags.member_begin[tag];
    const uint32_t count = types->tags.member_count[tag];
    const uint32_t lookup = types->tags.lookup[tag];
    const uint32_t* const names = types->members.name;
    uint32_t member = 0;
    const uint8_t encoding=types->tags.lookup_log2[tag];
    if (lookup == 0)
    {
        member = scalar ? type_lookup_scan_scalar(names, begin, count, name) : type_lookup_scan(names, begin, count, name);
    }
    else if (encoding < 128)
    {
        const uint32_t log2 = types->tags.lookup_log2[tag];
        member = scalar ? type_lookup_probe_scalar(types->lookup.buckets, lookup, log2, name) :
                          type_lookup_probe(types->lookup.buckets, lookup, log2, name);
    }
    else
    {
        // The tag stores a nonzero lookup word so an ordinary short scan needs just its original test.
        if ((encoding & 64) ? name == 0 : lookup == name)return begin;
        if (!(encoding & name_filter_bit(name)))return 0;
        if (encoding & 32)return init_child_contains(types,types->members.type[begin],name) ? begin : 0;
        const uint32_t end=begin+count;
        const __m512i wanted=_mm512_set1_epi32((int)name);
        uint32_t first=end, saved=0;
        for(uint32_t at=begin;at<end;)
        {
            const uint32_t n=end-at<16?end-at:16;
            const __mmask16 live=(__mmask16)_bzhi_u32(UINT16_MAX,n);
            const __m512i packet=_mm512_maskz_loadu_epi32(live,names+at);
            const uint32_t direct=_mm512_mask_cmpeq_epi32_mask(live,packet,wanted);
            if(direct)return at+(uint32_t)__builtin_ctz(direct);
            if(first==end)
            {
                const uint32_t zeros=_mm512_mask_cmpeq_epi32_mask(live,packet,_mm512_setzero_si512());
                if(zeros) { first=at; saved=init_anonymous_lanes(types,at,zeros); }
            }
            at+=n;
        }
        while(first<end)
        {
            while(saved)
            {
                const uint32_t row=first+(uint32_t)__builtin_ctz(saved);
                if(init_child_contains(types,types->members.type[row],name))return row;
                saved &= saved-1;
            }
            first+=end-first<16?end-first:16;
            if(first!=end)
            {
                const __mmask16 live=(__mmask16)(end-first>=16?UINT16_MAX:(1u<<(end-first))-1u);
                const __m512i packet=_mm512_maskz_loadu_epi32(live,names+first);
                const uint32_t zeros=_mm512_mask_cmpeq_epi32_mask(live,packet,_mm512_setzero_si512());
                saved=zeros?init_anonymous_lanes(types,first,zeros):0;
            }
        }
    }
    return member;
}
static uint32_t init_pending(const TypeTable* types, uint32_t tag, uint32_t name, bool scalar)
{
    const uint32_t begin = types->tags.member_begin[tag];
    const uint32_t count = types->tags.member_count[tag];
    const uint32_t lookup = types->tags.lookup[tag];
    const uint32_t* const names = types->members.name;
    uint32_t member = 0;
    const uint8_t encoding=types->tags.lookup_log2[tag];
    if (lookup == 0)
    {
        member = scalar ? type_lookup_scan_scalar(names, begin, count, name) : type_lookup_scan(names, begin, count, name);
    }
    else if (encoding < 128)
    {
        const uint32_t log2 = types->tags.lookup_log2[tag];
        member = scalar ? type_lookup_probe_scalar(types->lookup.buckets, lookup, log2, name) :
                          type_lookup_probe(types->lookup.buckets, lookup, log2, name);
    }
    else
    {
        // The tag stores a nonzero lookup word so an ordinary short scan needs just its original test.
        if ((encoding & 64) ? name == 0 : lookup == name)return begin;
        if (!(encoding & name_filter_bit(name)))return 0;
        if (encoding & 32)return init_child_contains(types,types->members.type[begin],name) ? begin : 0;
        const uint32_t end=begin+count;
        const __m512i wanted=_mm512_set1_epi32((int)name);
        uint32_t first=end, saved=0, promoted=0;
        for(uint32_t at=begin;at<end;)
        {
            const uint32_t n=end-at<16?end-at:16;
            const __mmask16 live=(__mmask16)_bzhi_u32(UINT16_MAX,n);
            const __m512i packet=_mm512_maskz_loadu_epi32(live,names+at);
            const uint32_t direct=_mm512_mask_cmpeq_epi32_mask(live,packet,wanted);
            if(direct)return at+(uint32_t)__builtin_ctz(direct);
            if(promoted==0)
            {
                const uint32_t zeros=_mm512_mask_cmpeq_epi32_mask(live,packet,_mm512_setzero_si512());
                uint32_t pending=zeros?init_anonymous_lanes(types,at,zeros):0;
                while(pending)
                {
                    const uint32_t row=at+(uint32_t)__builtin_ctz(pending);
                    if(init_child_contains(types,types->members.type[row],name)){promoted=row;break;}
                    pending&=pending-1;
                }
            }
            at+=n;
        }
        return promoted;
    }
    return member;
}
