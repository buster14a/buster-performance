typedef struct {
    uint32_t names[8];
    uint32_t owners[8];
    uint8_t used;
    bool complete;
} InitSummary;
typedef struct { TypeTable types; InitSummary* summaries; } SummaryView;
static void summary_add(InitSummary* s, uint32_t name, uint32_t row)
{
    for (uint32_t k = 0; k < s->used; k++) if (s->names[k] == name) return;
    if (s->used == 8) { s->complete = false; return; }
    const uint32_t k=s->used++;
    s->names[k]=name;
    s->owners[k]=row;
}
// Build bounded certificates from direct names first. A partial child can shadow a later anonymous sibling.
static void summary_build(const TypeTable* t, InitSummary* summaries, uint32_t tag)
{
    InitSummary* s=summaries+tag;
    s->complete=true;
    uint32_t begin=t->tags.member_begin[tag],end=begin+t->tags.member_count[tag];
    for(uint32_t row=begin;row<end && s->complete;row++)summary_add(s,t->members.name[row],row);
    for(uint32_t row=begin;row<end && s->complete;row++){
        if(t->members.name[row]!=0||(t->members.flags[row]&BUSTER_TYPE_MEMBER_BIT_FIELD))continue;
        TypeId inner=type_strip_aligned(t,t->members.type[row]);uint32_t kind=type_kind(t,inner);
        if(kind!=BUSTER_TYPE_KIND_STRUCT && kind!=BUSTER_TYPE_KIND_UNION)continue;
        uint32_t child=t->types.index[type_index(inner)];
        if(child>=tag){s->complete=false;break;}
        const InitSummary* c=summaries+child;
        for(uint32_t k=0;k<c->used && s->complete;k++)if(c->names[k]!=0)summary_add(s,c->names[k],row);
        s->complete &= c->complete;
    }
}
static inline uint32_t summary_lookup(const TypeTable*t,uint32_t tag,uint32_t name,bool scalar,uint32_t strategy)
{
    const uint32_t lookup=t->tags.lookup[tag];
    if (lookup!=BUSTER_TYPE_LOOKUP_WALK) {
        const uint32_t begin=t->tags.member_begin[tag],n=t->tags.member_count[tag];
        return lookup==0 ? (scalar?type_lookup_scan_scalar(t->members.name,begin,n,name):type_lookup_scan(t->members.name,begin,n,name))
            : (scalar?type_lookup_probe_scalar(t->lookup.buckets,lookup,t->tags.lookup_log2[tag],name):type_lookup_probe(t->lookup.buckets,lookup,t->tags.lookup_log2[tag],name));
    }
    const InitSummary* s=((const SummaryView*)t)->summaries+tag;
    if(strategy==1 && s->used!=0 && s->names[0]==name)return s->owners[0];
    if(strategy==2 && t->members.name[t->tags.member_begin[tag]]==name)return t->tags.member_begin[tag];
    const __mmask8 live=(__mmask8)((1u<<s->used)-1);
    const __m256i names=_mm256_loadu_si256((const __m256i*)s->names);
    const __mmask8 hits=_mm256_mask_cmpeq_epi32_mask(live,names,_mm256_set1_epi32((int)name));
    if(hits)return s->owners[__builtin_ctz((unsigned)hits)];
    return s->complete?0:init_mask(t,tag,name,scalar);
}
static uint32_t summary_packet(const TypeTable*t,uint32_t tag,uint32_t name,bool scalar){return summary_lookup(t,tag,name,scalar,0);}
static uint32_t summary_first(const TypeTable*t,uint32_t tag,uint32_t name,bool scalar){return summary_lookup(t,tag,name,scalar,1);}
static uint32_t summary_row(const TypeTable*t,uint32_t tag,uint32_t name,bool scalar){return summary_lookup(t,tag,name,scalar,2);}
