from pathlib import Path
p=Path(__file__).parent;s=(p/'tagged-gate.c').read_text().replace('#include "tagged.inc"', '#include "shortlist.inc"').replace('init_original,init_cache,init_split,init_pending','init_original,summary_packet,summary_first,summary_row')
a=s.index(' uint32_t* descriptors=');b=s.index(' TypeMember leaflist[]',a)
s=s[:a]+''' InitSummary* summaries=calloc(cap.tags+1,sizeof(*summaries));uint32_t next_tag=0;
 const uint32_t keybase=seed==133?0x81000000u:seed==789?0x40000200u:0;
 if(!summaries)return 2;
'''+s[b:]
a=s.index('  TypeTable cached=tb;');b=s.index('  for(unsigned shape',a)
s=s[:a]+'''  for(;next_tag<tb.tags.count;next_tag++)summary_build(&tb,summaries,next_tag);
  SummaryView cached={.types=tb,.summaries=summaries};
'''+s[b:];s=s.replace('j?&cached:&tb','j?&cached.types:&tb')
(p/'shortlist-gate.c').write_text(s)
(p/'shortlist-task').write_text((p/'tagged-task').read_text().replace('tagged','shortlist').replace('Check first-name descriptors for exhausted record indexes across full-width names','Check bounded summaries of direct and promoted initializer names'))
