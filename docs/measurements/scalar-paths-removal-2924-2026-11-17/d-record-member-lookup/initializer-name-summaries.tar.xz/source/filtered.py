from pathlib import Path
p=Path(__file__).parent;s=(p/'tagged.inc').read_text()
s=s.replace('table->tags.lookup_log2[tag] != UINT8_MAX && table->tags.lookup[tag] == 0','table->tags.lookup[tag] == 0')
s=s.replace('types->tags.lookup_log2[child] == UINT8_MAX ?', 'types->tags.lookup_log2[child] >= 128 ?')
s=s.replace('    if (encoding == UINT8_MAX && lookup == name)return begin;\n    if (encoding != UINT8_MAX && lookup == 0)','    if (lookup == 0)')
s=s.replace('else if (encoding != UINT8_MAX)','else if (encoding < 128)')
before='''        const uint32_t end=begin+count;'''
after='''        // The tag stores a nonzero lookup word so an ordinary short scan needs just its original test.
        if ((encoding & 64) ? name == 0 : lookup == name)return begin;
        if (!(encoding & name_filter_bit(name)))return 0;
        if (encoding & 32)return init_child_contains(types,types->members.type[begin],name) ? begin : 0;
        const uint32_t end=begin+count;'''
assert s.count(before)==3;s=s.replace(before,after)
bit='''static uint8_t name_filter_bit(uint32_t name)
{
    const uint32_t hash=name*UINT32_C(2654435761);
    return (uint8_t)(1u << (uint32_t)(((uint64_t)hash*5)>>32));
}
'''
(p/'filtered.inc').write_text(bit+s)
s=(p/'tagged-gate.c').read_text().replace('tagged.inc','filtered.inc')
s=s.replace(' const uint32_t keybase=', ' uint8_t* visible=calloc(cap.tags+1,1);uint32_t next_tag=0;\n const uint32_t keybase=')
s=s.replace('for(uint32_t tag=0;tag<tb.tags.count;tag++){','for(;next_tag<tb.tags.count;next_tag++){\n    const uint32_t tag=next_tag;')
old='''    if(descriptors[tag]==BUSTER_TYPE_LOOKUP_WALK){
      if(!tb.tags.member_count[tag])return 7;
      encodings[tag]=UINT8_MAX;descriptors[tag]=tb.members.name[tb.tags.member_begin[tag]];
    }'''
new='''    const uint32_t begin=tb.tags.member_begin[tag],end=begin+tb.tags.member_count[tag];uint8_t mask=0;bool sole=false;
    for(uint32_t row=begin;row<end;row++){
      const uint32_t name=tb.members.name[row];mask|=name_filter_bit(name);
      if(name){sole=false;continue;}
      if(!(tb.members.flags[row]&BUSTER_TYPE_MEMBER_BIT_FIELD)){
        TypeId inner=type_strip_aligned(&tb,tb.members.type[row]);uint8_t kind=type_kind(&tb,inner);
        if(kind==BUSTER_TYPE_KIND_STRUCT ||kind==BUSTER_TYPE_KIND_UNION){
          const uint32_t child=tb.types.index[type_index(inner)];if(child>=tag)return 8;
          mask|=visible[child];sole=(row==begin);
        }
      }
    }
    visible[tag]=mask;
    if(descriptors[tag]==BUSTER_TYPE_LOOKUP_WALK){
      if(begin==end)return 7;const uint32_t first=tb.members.name[begin];
      encodings[tag]=128 | (!first?64:0) | (sole?32:0) | mask;
      descriptors[tag]=first?first:UINT32_MAX;
    }'''
assert old in s;s=s.replace(old,new)
(p/'filtered-gate.c').write_text(s)
(p/'filtered-task').write_text((p/'tagged-task').read_text().replace('tagged','filtered').replace('Check first-name descriptors for exhausted record indexes across full-width names','Filter absent designators with the existing tag descriptor'))
