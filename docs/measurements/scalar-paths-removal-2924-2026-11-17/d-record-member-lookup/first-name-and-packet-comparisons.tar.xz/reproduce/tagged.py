from pathlib import Path
p=Path(__file__).parent
src=(p/'contains2.inc').read_text()
src=src.replace('lookup=types->tags.lookup[child]','lookup=types->tags.lookup_log2[child] == UINT8_MAX ? BUSTER_TYPE_LOOKUP_WALK : types->tags.lookup[child]')
src=src.replace('    if (lookup == 0)','    const uint8_t encoding=types->tags.lookup_log2[tag];\n    if (encoding == UINT8_MAX && lookup == name)return begin;\n    if (encoding != UINT8_MAX && lookup == 0)')
src=src.replace('else if (lookup != BUSTER_TYPE_LOOKUP_WALK)','else if (encoding != UINT8_MAX)')
src=src.replace('walk_frontier(types,','tagged_walk_frontier(types,')
walk=(p/'walkfrontier.inc').read_text()
walk=walk[walk.index('static uint32_t walk_frontier('):].replace('walk_frontier(', 'tagged_walk_frontier(').replace('table->tags.lookup[tag] == 0','table->tags.lookup_log2[tag] != UINT8_MAX && table->tags.lookup[tag] == 0')
(p/'tagged.inc').write_text(walk+src)
s=(p/'contains2-gate.c').read_text().replace('contains2.inc','tagged.inc')
s=s.replace('TypeMember leaflist', '''uint32_t* descriptors=calloc(cap.tags+1,sizeof(*descriptors));uint8_t* encodings=calloc(cap.tags+1,sizeof(*encodings));
 const uint32_t keybase=seed==133?0x81000000u:seed==789?0x40000200u:0;
 if(!descriptors || !encodings)return 2;
 TypeMember leaflist''')
s=s.replace('member(1+i,BUSTER_TYPE_INT)','member(keybase+1+i,BUSTER_TYPE_INT)')
s=s.replace('unsigned keys[]={0xf00200,1,1+n/2,n?n:1,','unsigned keys[]={0xf00200,keybase+1,keybase+1+n/2,keybase+(n?n:1),')
s=s.replace('  for(unsigned shape=0;', '''  TypeTable cached=tb;
  cached.tags.lookup=descriptors;cached.tags.lookup_log2=encodings;
  for(uint32_t tag=0;tag<tb.tags.count;tag++){
    descriptors[tag]=tb.tags.lookup[tag];encodings[tag]=tb.tags.lookup_log2[tag];
    if(descriptors[tag]==BUSTER_TYPE_LOOKUP_WALK){
      if(!tb.tags.member_count[tag])return 7;
      encodings[tag]=UINT8_MAX;descriptors[tag]=tb.members.name[tb.tags.member_begin[tag]];
    }
  }
  for(unsigned shape=0;''')
s=s.replace('methods[j](&tb,tag,key,false)','methods[j](j?&cached:&tb,tag,key,false)')
s=s.replace('Walk* fn=methods[j];uint64_t t=ticks();','Walk* fn=methods[j];const TypeTable* table=j?&cached:&tb;uint64_t t=ticks();').replace('fn(&tb,tag,key,false)','fn(table,tag,key,false)')
(p/'tagged-gate.c').write_text(s)
(p/'tagged-task').write_text((p/'contains2-task').read_text().replace('contains2','tagged').replace('Gate direct and promoted initializer designators including zero-name probes','Check first-name descriptors for exhausted record indexes across full-width names'))
