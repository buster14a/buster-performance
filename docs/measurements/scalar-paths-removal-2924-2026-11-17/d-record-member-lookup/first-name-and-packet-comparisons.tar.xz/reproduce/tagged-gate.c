#include "buster/compiler/c_types_benchmark.c"
#include "walkfrontier.inc"
#include "span.inc"
#include "initializers.inc"
#include "tagged.inc"
typedef uint32_t Walk(const TypeTable*,uint32_t,uint32_t,bool);
static Walk* volatile methods[]={init_original,init_cache,init_split,init_pending};
static uint32_t seed=1;
static uint32_t random32(void){seed=seed*1664525+1013904223;return seed;}
static uint64_t ticks(void){_mm_lfence();uint64_t r=__rdtsc();_mm_lfence();return r;}
static int cmp(const void*a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return(x>y)-(x<y);}
static TypeId make(TypeTable*table,const TypeMember* members,unsigned n){TypeId r=type_tag(table,BUSTER_TYPE_KIND_STRUCT,0);return type_complete_record(table,r,members,n,(TypeRecordAttributes){0})?r:0;}
static TypeMember member(unsigned name,TypeId type){return(TypeMember){.name=name,.type=type,.bit_width=BUSTER_TYPE_NOT_BIT_FIELD};}
int main(int argc,char**argv){
 if(argc>1)seed=strtoul(argv[1],0,10);
 TypeCapacity cap={.types=8192,.tags=4096,.members=524288,.parameters=4096,.lookups=1};
 Arena arena=arena_reserve(type_capacity_bytes(cap)),index=arena_reserve(type_index_capacity_bytes(cap));TypeTable tb={0};
 if(!type_initialize(&tb,&arena,&index,cap))return 2;
 uint32_t* descriptors=calloc(cap.tags+1,sizeof(*descriptors));uint8_t* encodings=calloc(cap.tags+1,sizeof(*encodings));
 const uint32_t keybase=seed==133?0x81000000u:seed==789?0x40000200u:0;
 if(!descriptors || !encodings)return 2;
 TypeMember leaflist[]={member(0x1000000,BUSTER_TYPE_INT),member(0x1000001,BUSTER_TYPE_UINT)};
 TypeId leaf=make(&tb,leaflist,2);if(!leaf)return 3;
 TypeMember midlist[]={member(0,type_qualify(&tb,leaf,BUSTER_TYPE_CONST)),member(0x1000002,BUSTER_TYPE_INT)};
 TypeId middle=make(&tb,midlist,2);if(!middle)return 3;
 unsigned sizes[120],ns=0;for(unsigned i=0;i<=65;i++)sizes[ns++]=i;
 unsigned more[]={79,80,81,95,96,97,127,128,129,191,192,193,255,256,257,511,512,513,1023,1024,1025,2048,4096,8192};
 for(unsigned i=0;i<sizeof(more)/sizeof(*more);i++)sizes[ns++]=more[i];
 unsigned routing[5][3]={0};
 TypeMember* ms=calloc(8192,sizeof(*ms));volatile uint64_t sink=0;
 for(unsigned si=0;si<ns;si++)for(unsigned layout=0;layout<5;layout++){
  unsigned n=sizes[si];for(unsigned i=0;i<n;i++)ms[i]=member(keybase+1+i,BUSTER_TYPE_INT);
  if(n&&layout==1)ms[n/2]=member(0,type_qualify(&tb,leaf,BUSTER_TYPE_VOLATILE));
  if(n&&layout==2){ms[0]=member(0,middle);if(n>1)ms[n-1]=member(0x1000000,BUSTER_TYPE_INT);}
  if(layout==3)for(unsigned i=0;i<n;i+=7)ms[i]=member(0,BUSTER_TYPE_UINT),ms[i].bit_width=2;
  if(layout==4 && n>1) { ms[0]=member(0,BUSTER_TYPE_UINT); ms[0].bit_width=2; ms[n-1]=member(0,middle); if(n>19)ms[17]=member(0,type_qualify(&tb,leaf,BUSTER_TYPE_CONST)); }
  TypeId rec=make(&tb,ms,n);if(!rec)return fprintf(stderr,"invalid record %u %u\n",n,layout),3;
  const uint32_t ri=tb.types.index[type_index(rec)], lookup=tb.tags.lookup[ri];
  routing[layout][lookup==0?0:lookup==BUSTER_TYPE_LOOKUP_WALK?2:1]++;
  if(n>16 && lookup != BUSTER_TYPE_LOOKUP_WALK)return fprintf(stderr,"index did not saturate at %u %u\n",n,layout),4;
  unsigned keys[]={0xf00200,keybase+1,keybase+1+n/2,keybase+(n?n:1),0x1000000,0x1000001,0};TypeId view=type_qualify(&tb,rec,BUSTER_TYPE_CONST);
  TypeTable cached=tb;
  cached.tags.lookup=descriptors;cached.tags.lookup_log2=encodings;
  for(uint32_t tag=0;tag<tb.tags.count;tag++){
    descriptors[tag]=tb.tags.lookup[tag];encodings[tag]=tb.tags.lookup_log2[tag];
    if(descriptors[tag]==BUSTER_TYPE_LOOKUP_WALK){
      if(!tb.tags.member_count[tag])return 7;
      encodings[tag]=UINT8_MAX;descriptors[tag]=tb.members.name[tb.tags.member_begin[tag]];
    }
  }
  for(unsigned shape=0;shape<7;shape++){
   uint32_t key=keys[shape],v[4],tag=tb.types.index[type_index(type_strip_aligned(&tb,view))];for(unsigned j=0;j<4;j++)v[j]=methods[j](j?&cached:&tb,tag,key,false);
   for(unsigned j=1;j<4;j++)if(v[0]!=v[j])return fprintf(stderr,"mismatch %u %u %u\n",n,layout,shape),1;
   uint64_t times[4][9];unsigned reps=4096/(1+(shape==1?0:n/16))+32;
   for(unsigned k=0;k<9;k++){unsigned order=random32()>>30;for(unsigned jj=0;jj<4;jj++){
     unsigned j=(k&1)?(order+jj)%4:(order+4-jj)%4;Walk* fn=methods[j];const TypeTable* table=j?&cached:&tb;uint64_t t=ticks();uint64_t acc=0;
     for(unsigned i=0;i<reps;i++){uint32_t found=fn(table,tag,key,false);acc+=found;}
     times[j][k]=ticks()-t;sink=acc;
   }}
   printf("%u %u %u %u",n,layout,shape,reps);for(unsigned j=0;j<4;j++){qsort(times[j],9,8,cmp);printf(" %lu",times[j][4]);}puts("");
  }
 }
 for(unsigned i=0;i<5;i++)fprintf(stderr,"layout %u: %u scan %u index %u walk\n",i,routing[i][0],routing[i][1],routing[i][2]);
 fprintf(stderr,"checked %u widths, 5 layouts and 7 requests (%lu)\n",ns,sink);
}
