from pathlib import Path
p=Path(__file__).parent
old=(p/'contains2.inc').read_text()
start=old.index('static uint32_t init_cache');end=old.index('static uint32_t init_split',start);base=old[start:end]
a=base.index('            const __mmask16 live=');b=base.index('            if(first==end)',a)
c=base.index('const uint32_t zero=_mm512_mask',b)
orig=base[a:b]
full='''            __mmask16 live;
            __m512i packet;
            if (end-at>=16)
            {
                live=UINT16_MAX;
                packet=_mm512_loadu_si512(names+at);
            }
            else
            {
                live=(__mmask16)_bzhi_u32(UINT16_MAX,n);
                packet=_mm512_maskz_loadu_epi32(live,names+at);
            }
            const uint32_t direct=_mm512_cmpeq_epi32_mask(packet,wanted) & live;
            if(direct & 1u)return at;
            if(direct)return at+(uint32_t)__builtin_ctz(direct);
'''
group='''            const uint32_t shift = (n < 16 && at >= 16-n) ? 16-n : 0;
            const __mmask16 live=(__mmask16)_bzhi_u32(UINT16_MAX,n);
            const __m512i packet = (n + shift == 16) ? _mm512_loadu_si512(names + at - shift) : _mm512_maskz_loadu_epi32(live,names+at);
            const uint32_t direct=(_mm512_cmpeq_epi32_mask(packet,wanted) >> shift) & live;
            if(direct & 1u)return at;
            if(direct)return at+(uint32_t)__builtin_ctz(direct);
'''
v1=base.replace(orig,full).replace('init_cache','init_firstpacket')
v2=base.replace(orig,group).replace('init_cache','init_endpacket').replace('const uint32_t zero=_mm512_mask_cmpeq_epi32_mask(live,packet,_mm512_setzero_si512());','const uint32_t zero=(_mm512_cmpeq_epi32_mask(packet,_mm512_setzero_si512()) >> shift) & live;')
# A four-lane head can expose a match before scanning the rest of the names.
head='''            const __mmask8 live4=(__mmask8)_bzhi_u32(15,n);
            const __m128i small=_mm_maskz_loadu_epi32(live4,names+at);
            const uint32_t early=(uint32_t)_mm_mask_cmpeq_epi32_mask(live4, small, _mm512_castsi512_si128(wanted));
            if(early & 1u)return at;
            if(early)return at+(uint32_t)__builtin_ctz(early);
            const __mmask16 live=(__mmask16)_bzhi_u32(UINT16_MAX,n);
            const __m512i packet=_mm512_maskz_loadu_epi32(live,names+at);
            const uint32_t direct=_mm512_mask_cmpeq_epi32_mask(live,packet,wanted);
            if(direct)return at+(uint32_t)__builtin_ctz(direct);
'''
# Use the short head only at the start. A masked load contains only the live record members.
v3=base.replace(orig,head.replace('            const __mmask8 live4=', '            if (at == begin) {\n            const __mmask8 live4=').replace('            const __mmask16 live=', '            }\n            const __mmask16 live=')).replace('init_cache','init_headpacket')
(p/'firstpacket.inc').write_text(old[:start]+v1+v2+v3)
s=(p/'contains2-gate.c').read_text().replace('contains2.inc','firstpacket.inc').replace('init_cache,init_split,init_pending','init_firstpacket,init_endpacket,init_headpacket')
(p/'firstpacket-gate.c').write_text(s)
(p/'firstpacket-task').write_text((p/'contains2-task').read_text().replace('contains2','firstpacket').replace('Gate direct and promoted initializer designators including zero-name probes','Find direct initializer names in bounded first vector groups'))
