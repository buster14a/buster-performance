static uint32_t init_original(const TypeTable* types, uint32_t tag, uint32_t name, bool scalar)
{
    const uint32_t begin = types->tags.member_begin[tag];
    const uint32_t count = types->tags.member_count[tag];
    const uint32_t lookup = types->tags.lookup[tag];
    const uint32_t* const names = types->members.name;
    uint32_t member = 0;
    if (lookup == 0)
    {
        member = scalar ? type_lookup_scan_scalar(names, begin, count, name) : type_lookup_scan(names, begin, count, name);
    }
    else if (lookup != BUSTER_TYPE_LOOKUP_WALK)
    {
        const uint32_t log2 = types->tags.lookup_log2[tag];
        member = scalar ? type_lookup_probe_scalar(types->lookup.buckets, lookup, log2, name) :
                          type_lookup_probe(types->lookup.buckets, lookup, log2, name);
    }
    else
    {
        // Preserve the existing capacity fallback, including direct members before anonymous members. The type
        // table and its columns stay unchanged while the inner lookup uses its separate scratch arena.
        member = type_lookup_scan_scalar(names, begin, count, name);
        const uint8_t* const flags = types->members.flags;
        const TypeId* const member_types = types->members.type;
        for (uint32_t i = 0; i < count && member == 0; i += 1)
        {
            if (names[begin + i] == 0 && (flags[begin + i] & BUSTER_TYPE_MEMBER_BIT_FIELD) == 0)
            {
                uint64_t offset = 0;
                uint32_t qualifiers = 0;
                const uint32_t inner = scalar ? type_lookup_member_scalar(types, member_types[begin + i], name, &offset, &qualifiers) :
                                               type_lookup_member(types, member_types[begin + i], name, &offset, &qualifiers);
                if (inner != 0 && inner != BUSTER_TYPE_MEMBER_UNKNOWN)
                {
                    member = begin + i;
                }
            }
        }
    }
    return member;
}

static uint32_t init_first(const TypeTable* types, uint32_t tag, uint32_t name, bool scalar)
{
    const uint32_t begin = types->tags.member_begin[tag];
    const uint32_t count = types->tags.member_count[tag];
    const uint32_t lookup = types->tags.lookup[tag];
    const uint32_t* const names = types->members.name;
    uint32_t member = 0;
    if (lookup == 0)
    {
        member = scalar ? type_lookup_scan_scalar(names, begin, count, name) : type_lookup_scan(names, begin, count, name);
    }
    else if (lookup != BUSTER_TYPE_LOOKUP_WALK)
    {
        const uint32_t log2 = types->tags.lookup_log2[tag];
        member = scalar ? type_lookup_probe_scalar(types->lookup.buckets, lookup, log2, name) :
                          type_lookup_probe(types->lookup.buckets, lookup, log2, name);
    }
    else
    {
        const uint32_t end = begin + count;
        uint32_t candidate = frontier_next_candidate(types, begin, end, name);
        if (candidate == end) return 0;
        if (names[candidate] == name) return candidate;
        // A designator enters a direct field before it considers a promoted field.
        member = candidate + 1 < end ? name_span(names,candidate + 1,end - candidate - 1,name) : 0;
        while (!member && candidate < end)
        {
            uint64_t offset = 0;
            uint32_t qualifiers = 0;
            const uint32_t inner = scalar ? type_lookup_member_scalar(types, types->members.type[candidate], name, &offset, &qualifiers) :
                                           type_lookup_member(types, types->members.type[candidate], name, &offset, &qualifiers);
            if (inner != 0 && inner != BUSTER_TYPE_MEMBER_UNKNOWN) member = candidate;
            else candidate = frontier_next_candidate(types,candidate + 1,end,name);
        }
    }
    return member;
}

static uint32_t init_separate(const TypeTable* types, uint32_t tag, uint32_t name, bool scalar)
{
    const uint32_t begin = types->tags.member_begin[tag];
    const uint32_t count = types->tags.member_count[tag];
    const uint32_t lookup = types->tags.lookup[tag];
    const uint32_t* const names = types->members.name;
    uint32_t member = 0;
    if (lookup == 0)
    {
        member = scalar ? type_lookup_scan_scalar(names, begin, count, name) : type_lookup_scan(names, begin, count, name);
    }
    else if (lookup != BUSTER_TYPE_LOOKUP_WALK)
    {
        const uint32_t log2 = types->tags.lookup_log2[tag];
        member = scalar ? type_lookup_probe_scalar(types->lookup.buckets, lookup, log2, name) :
                          type_lookup_probe(types->lookup.buckets, lookup, log2, name);
    }
    else
    {
        const uint32_t end = begin + count;
        member = name_span(names,begin,count,name);
        uint32_t candidate = member ? end : frontier_next_candidate(types, begin, end, name);
        while (!member && candidate < end)
        {
            uint64_t offset = 0;
            uint32_t qualifiers = 0;
            const uint32_t inner = scalar ? type_lookup_member_scalar(types, types->members.type[candidate], name, &offset, &qualifiers) :
                                           type_lookup_member(types, types->members.type[candidate], name, &offset, &qualifiers);
            if (inner != 0 && inner != BUSTER_TYPE_MEMBER_UNKNOWN) member = candidate;
            else candidate = frontier_next_candidate(types,candidate + 1,end,name);
        }
    }
    return member;
}

static uint32_t init_mask(const TypeTable* types, uint32_t tag, uint32_t name, bool scalar)
{
    const uint32_t begin = types->tags.member_begin[tag];
    const uint32_t count = types->tags.member_count[tag];
    const uint32_t lookup = types->tags.lookup[tag];
    const uint32_t* const names = types->members.name;
    uint32_t member = 0;
    if (lookup == 0)
    {
        member = scalar ? type_lookup_scan_scalar(names, begin, count, name) : type_lookup_scan(names, begin, count, name);
    }
    else if (lookup != BUSTER_TYPE_LOOKUP_WALK)
    {
        const uint32_t log2 = types->tags.lookup_log2[tag];
        member = scalar ? type_lookup_probe_scalar(types->lookup.buckets, lookup, log2, name) :
                          type_lookup_probe(types->lookup.buckets, lookup, log2, name);
    }
    else
    {
        const uint32_t end = begin + count;
        uint32_t first = end;
        const __m512i needle = _mm512_set1_epi32((int)name);
        for (uint32_t at=begin; at<end;) {
            const uint32_t left=end-at;
            const __mmask16 valid=left>=16?UINT16_MAX:(__mmask16)((1u<<left)-1);
            const __m512i lanes=_mm512_maskz_loadu_epi32(valid,names+at);
            const __mmask16 hits=_mm512_mask_cmpeq_epi32_mask(valid,lanes,needle);
            if (hits) return at+(uint32_t)__builtin_ctz(hits);
            if(first==end) {
                const __mmask16 zero=_mm512_mask_cmpeq_epi32_mask(valid,lanes,_mm512_setzero_si512());
                if(zero) {
                    const __m128i flags=_mm_maskz_loadu_epi8(zero,types->members.flags+at);
                    const __mmask16 eligible=zero & ~_mm_test_epi8_mask(flags,_mm_set1_epi8(BUSTER_TYPE_MEMBER_BIT_FIELD));
                    if(eligible)first=at+(uint32_t)__builtin_ctz(eligible);
                }
            }
            at+=left<16?left:16;
        }
        uint32_t candidate=first;
        while (!member && candidate < end)
        {
            uint64_t offset = 0;
            uint32_t qualifiers = 0;
            const uint32_t inner = scalar ? type_lookup_member_scalar(types, types->members.type[candidate], name, &offset, &qualifiers) :
                                           type_lookup_member(types, types->members.type[candidate], name, &offset, &qualifiers);
            if (inner != 0 && inner != BUSTER_TYPE_MEMBER_UNKNOWN) member = candidate;
            else candidate = frontier_next_candidate(types,candidate + 1,end,name);
        }
    }
    return member;
}

