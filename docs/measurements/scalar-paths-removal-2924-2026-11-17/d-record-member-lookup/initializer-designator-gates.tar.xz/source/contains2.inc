static bool init_child_contains(const TypeTable* types, TypeId type, uint32_t name)
{
    const TypeId base=type_strip_aligned(types,type);
    const uint8_t kind=type_kind(types,base);
    if(!name || (kind!=BUSTER_TYPE_KIND_STRUCT && kind!=BUSTER_TYPE_KIND_UNION))return false;
    const uint32_t child=types->types.index[type_index(base)],lookup=types->tags.lookup[child];
    if(lookup==0)return type_lookup_scan(types->members.name,types->tags.member_begin[child],types->tags.member_count[child],name)!=0;
    if(lookup!=BUSTER_TYPE_LOOKUP_WALK)return type_lookup_probe(types->lookup.buckets,lookup,types->tags.lookup_log2[child],name)!=0;
    uint64_t offset;uint32_t qualifiers;
    const uint32_t result=walk_frontier(types,base,name,&offset,&qualifiers);
    return result!=0 && result!=BUSTER_TYPE_MEMBER_UNKNOWN;
}

static inline uint32_t init_anonymous_lanes(const TypeTable* types,uint32_t at,uint32_t mask)
{
    const __m128i flags=_mm_maskz_loadu_epi8((__mmask16)mask,types->members.flags+at);
    return mask & ~_mm_test_epi8_mask(flags,_mm_set1_epi8(BUSTER_TYPE_MEMBER_BIT_FIELD));
}
static uint32_t init_cache(const TypeTable* types, uint32_t tag, uint32_t name, bool scalar)
{
    const uint32_t begin = types->tags.member_begin[tag];
    const uint32_t count = types->tags.member_count[tag];
    const uint32_t lookup = types->tags.lookup[tag];
    const uint32_t* const names = types->members.name;
    uint32_t member = 0;
    if (lookup == 0)
    {
        member = scalar ? type_lookup_scan_scalar(names, begin, count, name) : type_lookup_scan(names, begin, count, name);
    }
    else if (lookup != BUSTER_TYPE_LOOKUP_WALK)
    {
        const uint32_t log2 = types->tags.lookup_log2[tag];
        member = scalar ? type_lookup_probe_scalar(types->lookup.buckets, lookup, log2, name) :
                          type_lookup_probe(types->lookup.buckets, lookup, log2, name);
    }
    else
    {
        const uint32_t end=begin+count;
        const __m512i wanted=_mm512_set1_epi32((int)name);
        uint32_t first=end, saved=0;
        for(uint32_t at=begin;at<end;)
        {
            const uint32_t n=end-at<16?end-at:16;
            const __mmask16 live=(__mmask16)_bzhi_u32(UINT16_MAX,n);
            const __m512i packet=_mm512_maskz_loadu_epi32(live,names+at);
            const uint32_t direct=_mm512_mask_cmpeq_epi32_mask(live,packet,wanted);
            if(direct)return at+(uint32_t)__builtin_ctz(direct);
            if(first==end)
            {
                const uint32_t zero=_mm512_mask_cmpeq_epi32_mask(live,packet,_mm512_setzero_si512());
                if(zero)
                {
                    saved=init_anonymous_lanes(types,at,zero);
                    if(saved)first=at;
                }
            }
            at+=n;
        }
        while(first<end)
        {
            while(saved)
            {
                const uint32_t row=first+(uint32_t)__builtin_ctz(saved);
                if(init_child_contains(types,types->members.type[row],name))return row;
                saved &= saved-1;
            }
            first+=end-first<16?end-first:16;
            if(first!=end)
            {
                const __mmask16 live=(__mmask16)(end-first>=16?UINT16_MAX:(1u<<(end-first))-1u);
                const __m512i packet=_mm512_maskz_loadu_epi32(live,names+first);
                const uint32_t zeros=_mm512_mask_cmpeq_epi32_mask(live,packet,_mm512_setzero_si512());
                saved=zeros?init_anonymous_lanes(types,first,zeros):0;
            }
        }
    }
    return member;
}
static uint32_t init_split(const TypeTable* types, uint32_t tag, uint32_t name, bool scalar)
{
    const uint32_t begin = types->tags.member_begin[tag];
    const uint32_t count = types->tags.member_count[tag];
    const uint32_t lookup = types->tags.lookup[tag];
    const uint32_t* const names = types->members.name;
    uint32_t member = 0;
    if (lookup == 0)
    {
        member = scalar ? type_lookup_scan_scalar(names, begin, count, name) : type_lookup_scan(names, begin, count, name);
    }
    else if (lookup != BUSTER_TYPE_LOOKUP_WALK)
    {
        const uint32_t log2 = types->tags.lookup_log2[tag];
        member = scalar ? type_lookup_probe_scalar(types->lookup.buckets, lookup, log2, name) :
                          type_lookup_probe(types->lookup.buckets, lookup, log2, name);
    }
    else
    {
        const uint32_t end=begin+count;
        const __m512i wanted=_mm512_set1_epi32((int)name);
        uint32_t first=end, saved=0;
        for(uint32_t at=begin;at<end;)
        {
            const uint32_t n=end-at<16?end-at:16;
            const __mmask16 live=(__mmask16)_bzhi_u32(UINT16_MAX,n);
            const __m512i packet=_mm512_maskz_loadu_epi32(live,names+at);
            const uint32_t direct=_mm512_mask_cmpeq_epi32_mask(live,packet,wanted);
            if(direct)return at+(uint32_t)__builtin_ctz(direct);
            if(first==end)
            {
                const uint32_t zeros=_mm512_mask_cmpeq_epi32_mask(live,packet,_mm512_setzero_si512());
                if(zeros) { first=at; saved=init_anonymous_lanes(types,at,zeros); }
            }
            at+=n;
        }
        while(first<end)
        {
            while(saved)
            {
                const uint32_t row=first+(uint32_t)__builtin_ctz(saved);
                if(init_child_contains(types,types->members.type[row],name))return row;
                saved &= saved-1;
            }
            first+=end-first<16?end-first:16;
            if(first!=end)
            {
                const __mmask16 live=(__mmask16)(end-first>=16?UINT16_MAX:(1u<<(end-first))-1u);
                const __m512i packet=_mm512_maskz_loadu_epi32(live,names+first);
                const uint32_t zeros=_mm512_mask_cmpeq_epi32_mask(live,packet,_mm512_setzero_si512());
                saved=zeros?init_anonymous_lanes(types,first,zeros):0;
            }
        }
    }
    return member;
}
static uint32_t init_pending(const TypeTable* types, uint32_t tag, uint32_t name, bool scalar)
{
    const uint32_t begin = types->tags.member_begin[tag];
    const uint32_t count = types->tags.member_count[tag];
    const uint32_t lookup = types->tags.lookup[tag];
    const uint32_t* const names = types->members.name;
    uint32_t member = 0;
    if (lookup == 0)
    {
        member = scalar ? type_lookup_scan_scalar(names, begin, count, name) : type_lookup_scan(names, begin, count, name);
    }
    else if (lookup != BUSTER_TYPE_LOOKUP_WALK)
    {
        const uint32_t log2 = types->tags.lookup_log2[tag];
        member = scalar ? type_lookup_probe_scalar(types->lookup.buckets, lookup, log2, name) :
                          type_lookup_probe(types->lookup.buckets, lookup, log2, name);
    }
    else
    {
        const uint32_t end=begin+count;
        const __m512i wanted=_mm512_set1_epi32((int)name);
        uint32_t first=end, saved=0, promoted=0;
        for(uint32_t at=begin;at<end;)
        {
            const uint32_t n=end-at<16?end-at:16;
            const __mmask16 live=(__mmask16)_bzhi_u32(UINT16_MAX,n);
            const __m512i packet=_mm512_maskz_loadu_epi32(live,names+at);
            const uint32_t direct=_mm512_mask_cmpeq_epi32_mask(live,packet,wanted);
            if(direct)return at+(uint32_t)__builtin_ctz(direct);
            if(promoted==0)
            {
                const uint32_t zeros=_mm512_mask_cmpeq_epi32_mask(live,packet,_mm512_setzero_si512());
                uint32_t pending=zeros?init_anonymous_lanes(types,at,zeros):0;
                while(pending)
                {
                    const uint32_t row=at+(uint32_t)__builtin_ctz(pending);
                    if(init_child_contains(types,types->members.type[row],name)){promoted=row;break;}
                    pending&=pending-1;
                }
            }
            at+=n;
        }
        return promoted;
    }
    return member;
}
