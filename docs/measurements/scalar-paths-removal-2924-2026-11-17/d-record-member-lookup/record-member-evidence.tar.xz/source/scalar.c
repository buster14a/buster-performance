#include <immintrin.h>
#include <stdint.h>
uint32_t scalar(const uint32_t* names, uint32_t begin, uint32_t count, uint32_t name)
{
    uint32_t result = 0;
    for (uint32_t member = begin; result == 0 && member < begin + count; member += 1)
    {
        result = names[member] == name ? member : 0;
    }
    return result;
}

