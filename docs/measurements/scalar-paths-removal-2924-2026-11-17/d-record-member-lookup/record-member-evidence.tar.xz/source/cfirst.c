#include <immintrin.h>
#include <stdint.h>
uint32_t cfirst(const uint32_t* names, uint32_t begin, uint32_t count, uint32_t name)
{
    const __m512i goal = _mm512_set1_epi32((int)name);
    if (!count) return 0;
    if (count >= 16)
    {
        uint32_t at = 0;
        const uint32_t last = count - 16;
        for (; at < last; at += 16)
        {
            const __mmask16 found = _mm512_cmpeq_epi32_mask(_mm512_loadu_si512(names + begin + at), goal);
            if (found) return begin + at + (uint32_t)__builtin_ctz(found);
        }
        const __mmask16 found = _mm512_cmpeq_epi32_mask(_mm512_loadu_si512(names + begin + last), goal);
        return found ? begin + last + (uint32_t)__builtin_ctz(found) : 0;
    }
    const uint32_t* const start = names + begin;
    const uint32_t shift = ((uintptr_t)start & 4095) > 4096 - 64 ? 16 - count : 0;
    const uint32_t* const packet = (const uint32_t*)((uintptr_t)start - (uintptr_t)shift * 4);
    const __mmask16 lanes = (__mmask16)(((1u << count) - 1u) << shift);
    const __m512i first = _mm512_maskz_loadu_epi32(lanes, packet);
    const __mmask16 hits = _mm512_cmpeq_epi32_mask(first, goal) >> shift;
    return hits ? begin + (uint32_t)__builtin_ctz(hits) : 0;
}
