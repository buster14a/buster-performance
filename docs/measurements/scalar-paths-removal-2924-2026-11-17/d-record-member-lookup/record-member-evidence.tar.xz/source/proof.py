from pathlib import Path
p=Path(__file__).parent;s=(p/'tree/src/buster/compiler/c_types.c').read_text()
a=s.index('// Skip ordinary members that cannot');b=s.index('static uint32_t type_find_member',a)
versions={
 'last-name':('return begin + (uint32_t)__builtin_ctz(possible);','return begin + 31u - (uint32_t)__builtin_clz((uint32_t)possible);'),
 'drop-nameless':('possible |= unnamed & ~_mm_test_epi8_mask(flags, _mm_set1_epi8(BUSTER_TYPE_MEMBER_BIT_FIELD));','possible |= 0;'),
 'include-bitfields':('possible |= unnamed & ~_mm_test_epi8_mask(flags, _mm_set1_epi8(BUSTER_TYPE_MEMBER_BIT_FIELD));','possible |= unnamed;'),
 'drop-leaf-qualifier':('current.qualifiers |= type_qualifiers(inner);','current.qualifiers |= 0;'),
 'omit-parent-offset':('current.offset += table->members.offset[member] + table->members.offset[result];','current.offset += table->members.offset[result];'),
 'drop-siblings':('if (current.next < current.end)','if (false)'),
 'last-lane':('_mm512_maskz_loadu_epi32(live, table->members.name + begin)','_mm512_maskz_loadu_epi32(live & 0x7fff, table->members.name + begin)'),
 'spill-unavailable':('memcpy(stack, local_stack, depth * sizeof(*stack));','result = BUSTER_TYPE_MEMBER_UNKNOWN; break;'),
}
for n,(old,new) in versions.items():
 assert old in s[a:b]; d=p/'proof-src'/n/'buster/compiler';d.mkdir(parents=True,exist_ok=True);(d/'c_types.c').write_text(s[:a]+s[a:b].replace(old,new,1)+s[b:])
