from pathlib import Path
p=Path('src/buster/compiler/c_types.c');s=p.read_text();a=s.index('static uint64_t member_census_resolve');b=s.index('__attribute__((destructor))',a)
s=s[:a]+'''#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
typedef struct { uint64_t resolve[3], init[3], walk, rows, anon; } MemberCensus;
static MemberCensus member_census_local;
static MemberCensus* member_counts = &member_census_local;
__attribute__((constructor)) static void type_census_open(void)
{
    const char* path = getenv("BUSTER_MEMBER_CENSUS");
    if (path != NULL && path[0] != 0)
    {
        const int fd = open(path, O_RDWR | O_CLOEXEC);
        if (fd >= 0)
        {
            void* data = mmap(NULL, sizeof(MemberCensus), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
            if (data != MAP_FAILED) member_counts = data;
            close(fd);
        }
    }
}
#define member_census_resolve (member_counts->resolve)
#define member_census_init (member_counts->init)
#define member_census_walk (member_counts->walk)
#define member_census_rows (member_counts->rows)
#define member_census_anon (member_counts->anon)
'''+s[b:]
for v in ('member_census_resolve[lookup == 0 ? 0 : (lookup == BUSTER_TYPE_LOOKUP_WALK ? 2 : 1)]','member_census_walk','member_census_rows'):
 s=s.replace(v+' += 1;', '__atomic_fetch_add(&'+v+', 1, __ATOMIC_RELAXED);')
s=s.replace('member_census_anon += table->members.name[top->next] == 0;', '__atomic_fetch_add(&member_census_anon, table->members.name[top->next] == 0, __ATOMIC_RELAXED);')
p.write_text(s)
p=Path('src/buster/compiler/c_check_initializer.c');s=p.read_text().replace('member_census_init[lookup == 0 ? 0 : (lookup == BUSTER_TYPE_LOOKUP_WALK ? 2 : 1)] += 1;','__atomic_fetch_add(&member_census_init[lookup == 0 ? 0 : (lookup == BUSTER_TYPE_LOOKUP_WALK ? 2 : 1)], 1, __ATOMIC_RELAXED);');p.write_text(s)
