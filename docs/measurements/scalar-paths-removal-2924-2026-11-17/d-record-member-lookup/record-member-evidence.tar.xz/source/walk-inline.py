from pathlib import Path
p=Path(__file__).parent;t=(p/'walksimd.inc').read_text();a=t.index('    Scratch scratch = scratch_begin(0);');b=t.index('    while (result == 0 && depth != 0)',a)
setup='''    enum { LOCAL_TAGS = 8 };
    TypeMemberFrame local_stack[LOCAL_TAGS];
    uint32_t local_entered[LOCAL_TAGS] = {0};
    TypeMemberFrame* stack = local_stack;
    uint32_t* entered = local_entered;
    uint32_t* places = NULL;
    Scratch scratch = {0};
    const uint32_t room = table->tags.count;
    uint32_t result = 0;
    uint32_t depth = 1;
    uint32_t count = 1;
    uint64_t found_offset = 0;
    uint32_t found_qualifiers = 0;
    entered[0] = type_index(root);
    stack[0] = (TypeMemberFrame){ .next = first, .end = root_end, .qualifiers = type_qualifiers(root) };
'''
t=t[:a]+setup+t[b:];a=t.index('                const bool seen =');b=t.index('                    stack[depth++]',a)
t=t[:a]+'''                const bool seen = places != NULL ? places[index] < count && entered[places[index]] == index :
                    _mm256_cmpeq_epi32_mask(_mm256_loadu_si256((const __m256i*)local_entered), _mm256_set1_epi32((int)index)) != 0;
                if (!seen)
                {
                    if (count == LOCAL_TAGS && places == NULL)
                    {
                        scratch = scratch_begin(0);
                        stack = BUSTER_ARENA_PUSH_ARRAY(scratch.arena, TypeMemberFrame, room);
                        entered = stack != NULL ? BUSTER_ARENA_PUSH_ARRAY(scratch.arena, uint32_t, room) : NULL;
                        places = entered != NULL ? BUSTER_ARENA_PUSH_ARRAY(scratch.arena, uint32_t, table->types.count) : NULL;
                        if (places == NULL)
                        {
                            result = BUSTER_TYPE_MEMBER_UNKNOWN;
                            break;
                        }
                        memcpy(stack, local_stack, depth * sizeof(*stack));
                        memcpy(entered, local_entered, sizeof(local_entered));
                        _mm256_i32scatter_epi32(places, _mm256_loadu_si256((const __m256i*)local_entered), _mm256_setr_epi32(0,1,2,3,4,5,6,7), 4);
                        top = &stack[depth - 1];
                    }
                    const uint32_t tag = table->types.index[index];
                    if (places != NULL) places[index] = count;
                    entered[count++] = index;
'''+t[b:];t=t.replace('    scratch_end(scratch);','    if (scratch.arena != NULL) scratch_end(scratch);')
(p/'walkinline.inc').write_text(t.replace('type_lookup_next_candidate','inline_next_candidate').replace('walk_simd(', 'walk_inline('))
# Also try using an inner record's existing index while all traversal state still fits locally.
a=t.index('                const bool seen =')
t=t[:a]+'''                const uint32_t inner_tag = table->types.index[index];
                if (table->tags.lookup[inner_tag] != BUSTER_TYPE_LOOKUP_WALK)
                {
                    uint64_t inner_offset = 0;
                    uint32_t inner_qualifiers = 0;
                    result = type_lookup_member(table, inner, name, &inner_offset, &inner_qualifiers);
                    if (result != 0 && result != BUSTER_TYPE_MEMBER_UNKNOWN)
                    {
                        found_offset = member_offset + inner_offset;
                        found_qualifiers = top->qualifiers | inner_qualifiers;
                    }
                    continue;
                }
'''+t[a:];(p/'walkindex.inc').write_text(t.replace('type_lookup_next_candidate','index_next_candidate').replace('walk_simd(', 'walk_index('))
g=(p/'walk-gate.c').read_text().replace('#include "walksimd.inc"','#include "walksimd.inc"\n#include "walkinline.inc"\n#include "walkindex.inc"').replace('type_lookup_walk,walk_simd','type_lookup_walk,walk_simd,walk_inline,walk_index').replace('uint32_t key=keys[shape],v[2],qual[2];uint64_t off[2];for(unsigned j=0;j<2;', 'uint32_t key=keys[shape],v[4],qual[4];uint64_t off[4];for(unsigned j=0;j<4;').replace('if(v[0]!=v[1]||off[0]!=off[1]||qual[0]!=qual[1])','for(unsigned j=1;j<4;j++)if(v[0]!=v[j]||off[0]!=off[j]||qual[0]!=qual[j])').replace('times[2][9]', 'times[4][9]').replace('order=random32()>>31;for(unsigned jj=0;jj<2;', 'order=random32()>>30;for(unsigned jj=0;jj<4;').replace('j=order^jj','j=(k&1)?(order+jj)%4:(order+4-jj)%4').replace('for(unsigned j=0;j<2;j++){qsort','for(unsigned j=0;j<4;j++){qsort');(p/'nested-gate.c').write_text(g)
(p/'nested-task').write_text((p/'walk-task').read_text().replace('walk-gate','nested-gate').replace('walk-$seed','nested-$seed').replace('walk.ok','nested.ok'))
