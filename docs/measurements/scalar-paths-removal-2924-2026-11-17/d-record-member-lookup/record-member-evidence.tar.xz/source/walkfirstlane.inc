// Skip ordinary members that cannot match. Anonymous fields remain in declaration order with direct hits.
static inline uint32_t firstlane_next_candidate(const TypeTable* table, uint32_t begin, uint32_t end, uint32_t name)
{
    const __m512i wanted = _mm512_set1_epi32((int)name);
    while (begin < end)
    {
        const uint32_t count = end - begin;
        const __mmask16 live = count >= 16 ? UINT16_MAX : (__mmask16)((1u << count) - 1);
        const __m512i names = _mm512_maskz_loadu_epi32(live, table->members.name + begin);
        const __mmask16 direct = _mm512_cmpeq_epi32_mask(names, wanted);
        const __mmask16 zero = _mm512_mask_cmpeq_epi32_mask(live, names, _mm512_setzero_si512());
        __mmask16 possible = direct | zero;
        if (possible != 0)
        {
            const uint32_t lane = (uint32_t)__builtin_ctz(possible);
            if ((direct & (1u << lane)) != 0 || (table->members.flags[begin + lane] & BUSTER_TYPE_MEMBER_BIT_FIELD) == 0) return begin + lane;
            const __m128i flags = _mm_maskz_loadu_epi8(zero, table->members.flags + begin);
            possible = direct | (zero & ~_mm_test_epi8_mask(flags, _mm_set1_epi8(BUSTER_TYPE_MEMBER_BIT_FIELD)));
            if (possible != 0) return begin + (uint32_t)__builtin_ctz(possible);
        }
        if (count <= 16) break;
        begin += 16;
    }
    return end;
}

static uint32_t walk_firstlane(const TypeTable* table, TypeId record, uint32_t name, uint64_t* offset, uint32_t* qualifiers)
{
    typedef struct TypeMemberFrame TypeMemberFrame;
    struct TypeMemberFrame
    {
        uint32_t next;
        uint32_t end;
        uint32_t qualifiers;
        uint64_t offset;
    };
    const TypeId root = type_strip_aligned(table, record);
    const uint8_t kind = type_kind(table, root);
    const bool searching = name != 0 && (kind == BUSTER_TYPE_KIND_STRUCT || kind == BUSTER_TYPE_KIND_UNION);
    if (!searching)
    {
        *offset = 0;
        *qualifiers = 0;
        return 0;
    }
    const uint32_t root_tag = table->types.index[type_index(root)];
    const uint32_t root_end = table->tags.member_begin[root_tag] + table->tags.member_count[root_tag];
    const uint32_t first = firstlane_next_candidate(table, table->tags.member_begin[root_tag], root_end, name);
    if (first == root_end || table->members.name[first] == name)
    {
        const bool found = first != root_end;
        *offset = found ? table->members.offset[first] : 0;
        *qualifiers = found ? type_qualifiers(root) : 0;
        return found ? first : 0;
    }
    enum { LOCAL_TAGS = 8 };
    TypeMemberFrame local_stack[LOCAL_TAGS];
    uint32_t local_seen[LOCAL_TAGS] = {type_index(root)};
    TypeMemberFrame* stack = local_stack;
    uint32_t* seen = local_seen;
    uint32_t* places = NULL;
    Scratch scratch = {0};
    uint32_t depth = 0;
    uint32_t seen_count = 1;
    TypeMemberFrame current = {.next = first, .end = root_end, .qualifiers = type_qualifiers(root)};
    uint32_t member = first;
    uint32_t result = 0;
    for (;;)
    {
        if (member == current.end)
        {
            if (depth == 0) break;
            current = stack[--depth];
        }
        else if (table->members.name[member] == name)
        {
            result = member;
            current.offset += table->members.offset[member];
            break;
        }
        else
        {
            current.next = member + 1;
            const TypeId inner = type_strip_aligned(table, table->members.type[member]);
            const uint8_t kind = type_kind(table, inner);
            if (kind == BUSTER_TYPE_KIND_STRUCT || kind == BUSTER_TYPE_KIND_UNION)
            {
                const uint32_t index = type_index(inner);
                const uint32_t tag = table->types.index[index];
                const uint32_t begin = table->tags.member_begin[tag];
                const uint32_t size = table->tags.member_count[tag];
                if (table->tags.lookup[tag] == 0)
                {
                    result = type_lookup_scan(table->members.name, begin, size, name);
                    if (result != 0)
                    {
                        current.offset += table->members.offset[member] + table->members.offset[result];
                        current.qualifiers |= type_qualifiers(inner);
                        break;
                    }
                }
                else
                {
                    const uint32_t child_end = begin + size;
                    const uint32_t child = firstlane_next_candidate(table, begin, child_end, name);
                    if (child < child_end && table->members.name[child] == name)
                    {
                        result = child;
                        current.offset += table->members.offset[member] + table->members.offset[child];
                        current.qualifiers |= type_qualifiers(inner);
                        break;
                    }
                    const bool visited = places != NULL ? places[index] < seen_count && seen[places[index]] == index :
                        _mm256_cmpeq_epi32_mask(_mm256_loadu_si256((const __m256i*)local_seen), _mm256_set1_epi32((int)index)) != 0;
                    if (child < child_end && !visited)
                    {
                        if (seen_count == LOCAL_TAGS && places == NULL)
                        {
                            scratch = scratch_begin(0);
                            stack = BUSTER_ARENA_PUSH_ARRAY(scratch.arena, TypeMemberFrame, table->tags.count);
                            seen = stack != NULL ? BUSTER_ARENA_PUSH_ARRAY(scratch.arena, uint32_t, table->tags.count) : NULL;
                            places = seen != NULL ? BUSTER_ARENA_PUSH_ARRAY(scratch.arena, uint32_t, table->types.count) : NULL;
                            if (places == NULL)
                            {
                                result = BUSTER_TYPE_MEMBER_UNKNOWN;
                                break;
                            }
                            memcpy(stack, local_stack, depth * sizeof(*stack));
                            memcpy(seen, local_seen, sizeof(local_seen));
                            _mm256_i32scatter_epi32(places, _mm256_loadu_si256((const __m256i*)local_seen), _mm256_setr_epi32(0,1,2,3,4,5,6,7), 4);
                        }
                        if (places != NULL) places[index] = seen_count;
                        seen[seen_count++] = index;
                        if (current.next < current.end) stack[depth++] = current;
                        current.next = begin;
                        current.end = begin + size;
                        current.offset += table->members.offset[member];
                        current.qualifiers |= type_qualifiers(inner);
                        member = child;
                        continue;
                    }
                }
            }
        }
        member = firstlane_next_candidate(table, current.next, current.end, name);
    }
    if (scratch.arena != NULL) scratch_end(scratch);
    const bool found = result != 0 && result != BUSTER_TYPE_MEMBER_UNKNOWN;
    *offset = found ? current.offset : 0;
    *qualifiers = found ? current.qualifiers : 0;
    return result;
}
