from pathlib import Path
d=Path('src/buster/compiler');p=d/'c_types.c';s=p.read_text()
i=s.index('// The lookup: through each record')
s=s[:i]+'''static uint64_t member_census_resolve[3], member_census_init[3], member_census_walk, member_census_rows, member_census_anon;
__attribute__((destructor)) static void type_census_report(void)
{
    if (member_census_walk || member_census_resolve[0] || member_census_resolve[1] || member_census_init[0] || member_census_init[1] || member_census_init[2])
    {
        fprintf(stderr,"member-census resolve=%llu,%llu,%llu init=%llu,%llu,%llu walk=%llu rows=%llu anonymous=%llu\\n",
                (unsigned long long)member_census_resolve[0],(unsigned long long)member_census_resolve[1],(unsigned long long)member_census_resolve[2],
                (unsigned long long)member_census_init[0],(unsigned long long)member_census_init[1],(unsigned long long)member_census_init[2],
                (unsigned long long)member_census_walk,(unsigned long long)member_census_rows,(unsigned long long)member_census_anon);
    }
}
'''+s[i:];i=s.index('        if (lookup == BUSTER_TYPE_LOOKUP_WALK)',i);s=s[:i]+'''        member_census_resolve[lookup == 0 ? 0 : (lookup == BUSTER_TYPE_LOOKUP_WALK ? 2 : 1)] += 1;
'''+s[i:];i=s.index('static uint32_t type_lookup_walk(',i);a=s.index('    Scratch scratch',i);s=s[:a]+'    member_census_walk += 1;\n'+s[a:];i=s.index('            const uint32_t member = top->next++;',a);s=s[:i]+'''            member_census_rows += 1;
            member_census_anon += table->members.name[top->next] == 0;
'''+s[i:];p.write_text(s)
p=d/'c_check_initializer.c';s=p.read_text();i=s.index('    if (lookup == 0)',s.index('static uint32_t check_init_member('))
s=s[:i]+'''    member_census_init[lookup == 0 ? 0 : (lookup == BUSTER_TYPE_LOOKUP_WALK ? 2 : 1)] += 1;
'''+s[i:];p.write_text(s)
