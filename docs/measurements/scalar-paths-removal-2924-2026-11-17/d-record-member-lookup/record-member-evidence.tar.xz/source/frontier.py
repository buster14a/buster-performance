from pathlib import Path
p=Path(__file__).parent
s=(p/'walkpending.inc').read_text()
head=s[:s.index('    uint32_t spine_member')]
core="""    enum { LOCAL_TAGS = 8 };
    TypeMemberFrame local_stack[LOCAL_TAGS];
    uint32_t local_seen[LOCAL_TAGS] = {type_index(root)};
    TypeMemberFrame* stack = local_stack;
    uint32_t* seen = local_seen;
    uint32_t* places = NULL;
    Scratch scratch = {0};
    uint32_t depth = 0;
    uint32_t seen_count = 1;
    TypeMemberFrame current = {.next = first, .end = root_end, .qualifiers = type_qualifiers(root)};
    uint32_t member = first;
    uint32_t result = 0;
    for (;;)
    {
        if (member == current.end)
        {
            if (depth == 0) break;
            current = stack[--depth];
        }
        else if (table->members.name[member] == name)
        {
            result = member;
            current.offset += table->members.offset[member];
            break;
        }
        else
        {
            current.next = member + 1;
            const TypeId inner = type_strip_aligned(table, table->members.type[member]);
            const uint8_t kind = type_kind(table, inner);
            if (kind == BUSTER_TYPE_KIND_STRUCT || kind == BUSTER_TYPE_KIND_UNION)
            {
                const uint32_t index = type_index(inner);
                const uint32_t tag = table->types.index[index];
                const uint32_t begin = table->tags.member_begin[tag];
                const uint32_t size = table->tags.member_count[tag];
                if (table->tags.lookup[tag] == 0)
                {
                    result = type_lookup_scan(table->members.name, begin, size, name);
                    if (result != 0)
                    {
                        current.offset += table->members.offset[member] + table->members.offset[result];
                        current.qualifiers |= type_qualifiers(inner);
                        break;
                    }
                }
                else
                {
                    const bool visited = places != NULL ? places[index] < seen_count && seen[places[index]] == index :
                        _mm256_cmpeq_epi32_mask(_mm256_loadu_si256((const __m256i*)local_seen), _mm256_set1_epi32((int)index)) != 0;
                    if (!visited)
                    {
                        if (seen_count == LOCAL_TAGS && places == NULL)
                        {
                            scratch = scratch_begin(0);
                            stack = BUSTER_ARENA_PUSH_ARRAY(scratch.arena, TypeMemberFrame, table->tags.count);
                            seen = stack != NULL ? BUSTER_ARENA_PUSH_ARRAY(scratch.arena, uint32_t, table->tags.count) : NULL;
                            places = seen != NULL ? BUSTER_ARENA_PUSH_ARRAY(scratch.arena, uint32_t, table->types.count) : NULL;
                            if (places == NULL)
                            {
                                result = BUSTER_TYPE_MEMBER_UNKNOWN;
                                break;
                            }
                            memcpy(stack, local_stack, depth * sizeof(*stack));
                            memcpy(seen, local_seen, sizeof(local_seen));
                            _mm256_i32scatter_epi32(places, _mm256_loadu_si256((const __m256i*)local_seen), _mm256_setr_epi32(0,1,2,3,4,5,6,7), 4);
                        }
                        if (places != NULL) places[index] = seen_count;
                        seen[seen_count++] = index;
                        if (current.next < current.end) stack[depth++] = current;
                        current.next = begin;
                        current.end = begin + size;
                        current.offset += table->members.offset[member];
                        current.qualifiers |= type_qualifiers(inner);
                    }
                }
            }
        }
        member = pending_next_candidate(table, current.next, current.end, name);
    }
    if (scratch.arena != NULL) scratch_end(scratch);
    const bool found = result != 0 && result != BUSTER_TYPE_MEMBER_UNKNOWN;
    *offset = found ? current.offset : 0;
    *qualifiers = found ? current.qualifiers : 0;
    return result;
}
"""
# Keep the first entry fast and share the traversal's slow allocation with every depth.
def make(n,t):
 (p/('walk'+n+'.inc')).write_text(t.replace('pending_next_candidate',n+'_next_candidate').replace('walk_pending','walk_'+n))
make('frontier',head+core)
# A leaf consumes no continuation. Check the first candidate of a child before allocating its frame.
t=core.replace('                    const bool visited =','''                    const uint32_t child_end = begin + size;
                    const uint32_t child = pending_next_candidate(table, begin, child_end, name);
                    if (child < child_end && table->members.name[child] == name)
                    {
                        result = child;
                        current.offset += table->members.offset[member] + table->members.offset[child];
                        current.qualifiers |= type_qualifiers(inner);
                        break;
                    }
                    const bool visited =''').replace('if (!visited)','if (child < child_end && !visited)').replace('current.qualifiers |= type_qualifiers(inner);\n                    }\n                }\n            }','current.qualifiers |= type_qualifiers(inner);\n                        member = child;\n                        continue;\n                    }\n                }\n            }')
make('ahead',head+t)
# Strip invalid anonymous names with the already loaded flag only when the first named/zero lane is zero.
a=head.index('        const __mmask16 unnamed');b=head.index('        if (count <= 16)',a)
h=head[:a]+'''        const __mmask16 zero = _mm512_mask_cmpeq_epi32_mask(live, names, _mm512_setzero_si512());
        __mmask16 possible = direct | zero;
        if (possible != 0)
        {
            const uint32_t lane = (uint32_t)__builtin_ctz(possible);
            if ((direct & (1u << lane)) != 0 || (table->members.flags[begin + lane] & BUSTER_TYPE_MEMBER_BIT_FIELD) == 0) return begin + lane;
            const __m128i flags = _mm_maskz_loadu_epi8(zero, table->members.flags + begin);
            possible = direct | (zero & ~_mm_test_epi8_mask(flags, _mm_set1_epi8(BUSTER_TYPE_MEMBER_BIT_FIELD)));
            if (possible != 0) return begin + (uint32_t)__builtin_ctz(possible);
        }
'''+head[b:]
make('firstlane',h+t)
g=(p/'spine-gate.c').read_text()
for orig,new in [('spine','frontier'),('leaf','ahead'),('pending','firstlane')]:
 g=g.replace('"walk'+orig+'.inc"','"walk'+new+'.inc"').replace('walk_'+orig,'walk_'+new)
(p/'frontier-gate.c').write_text(g)
(p/'frontier-task').write_text((p/'spine-task').read_text().replace('spine','frontier'))
