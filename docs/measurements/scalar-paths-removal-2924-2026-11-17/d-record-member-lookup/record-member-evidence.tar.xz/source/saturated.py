from pathlib import Path
p=Path(__file__).parent
for old,name in [('frontier','saturated'),('initial','routed')]:
 s=(p/(old+'-gate.c')).read_text().replace('.lookups=0','.lookups=1').replace('TypeMember* ms=calloc', 'unsigned routing[4][3]={0};\n TypeMember* ms=calloc')
 j=s.index('  unsigned keys[]')
 s=s[:j]+'''  const uint32_t ri=tb.types.index[type_index(rec)], lookup=tb.tags.lookup[ri];
  routing[layout][lookup==0?0:lookup==BUSTER_TYPE_LOOKUP_WALK?2:1]++;
  if(n>16 && lookup != BUSTER_TYPE_LOOKUP_WALK)return fprintf(stderr,"index did not saturate at %u %u\\n",n,layout),4;
'''+s[j:]
 s=s.replace(' fprintf(stderr,"checked %u widths',' for(unsigned i=0;i<4;i++)fprintf(stderr,"layout %u: %u scan %u index %u walk\\n",i,routing[i][0],routing[i][1],routing[i][2]);\n fprintf(stderr,"checked %u widths').replace('512/(1+(shape==1?0:n/16))+8', '4096/(1+(shape==1?0:n/16))+32')
 (p/(name+'-gate.c')).write_text(s)
 t=(p/(old+'-task')).read_text().replace(old+'-gate',name+'-gate').replace(old+'-$seed',name+'-$seed').replace(old+'.ok',name+'.ok');(p/(name+'-task')).write_text(t)
