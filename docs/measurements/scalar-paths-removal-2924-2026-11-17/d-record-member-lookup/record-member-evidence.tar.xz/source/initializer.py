from pathlib import Path
p=Path(__file__).parent;s=(p/'tree/src/buster/compiler/c_check_initializer.c').read_text();a=s.index('static uint32_t check_init_member(');b=s.index('\n}',a)+3
old=s[a:b];a=old.index('        // Preserve the existing capacity');b=old.index('\n    }\n    return',a)
print(old[b:].splitlines()[:3])
variants={}
first='''        const uint32_t end = begin + count;
        uint32_t candidate = frontier_next_candidate(types, begin, end, name);
        if (candidate == end) return 0;
        if (names[candidate] == name) return candidate;
        const uint32_t first = candidate;
        // A designator enters a direct field before it considers a promoted field.
        member = candidate + 1 < end ? name_span(names,candidate + 1,end - candidate - 1,name) : 0;
        while (!member && candidate < end)
        {
            uint64_t offset = 0;
            uint32_t qualifiers = 0;
            const uint32_t inner = scalar ? type_lookup_member_scalar(types, types->members.type[candidate], name, &offset, &qualifiers) :
                                           type_lookup_member(types, types->members.type[candidate], name, &offset, &qualifiers);
            if (inner != 0 && inner != BUSTER_TYPE_MEMBER_UNKNOWN) member = candidate;
            else candidate = frontier_next_candidate(types,candidate + 1,end,name);
        }'''
variants['first']=first.replace('        const uint32_t first = candidate;\n','')
variants['separate']='''        const uint32_t end = begin + count;
        member = name_span(names,begin,count,name);
        uint32_t candidate = member ? end : frontier_next_candidate(types, begin, end, name);
'''+ first[first.index('        while (!member'):]
variants['mask']='''        const uint32_t end = begin + count;
        uint32_t first = end;
        const __m512i needle = _mm512_set1_epi32((int)name);
        for (uint32_t at=begin; at<end;) {
            const uint32_t left=end-at;
            const __mmask16 valid=left>=16?UINT16_MAX:(__mmask16)((1u<<left)-1);
            const __m512i lanes=_mm512_maskz_loadu_epi32(valid,names+at);
            const __mmask16 hits=_mm512_mask_cmpeq_epi32_mask(valid,lanes,needle);
            if (hits) return at+(uint32_t)__builtin_ctz(hits);
            if(first==end) {
                const __mmask16 zero=_mm512_mask_cmpeq_epi32_mask(valid,lanes,_mm512_setzero_si512());
                if(zero) {
                    const __m128i flags=_mm_maskz_loadu_epi8(zero,types->members.flags+at);
                    const __mmask16 eligible=zero & ~_mm_test_epi8_mask(flags,_mm_set1_epi8(BUSTER_TYPE_MEMBER_BIT_FIELD));
                    if(eligible)first=at+(uint32_t)__builtin_ctz(eligible);
                }
            }
            at+=left<16?left:16;
        }
        uint32_t candidate=first;
'''+first[first.index('        while (!member'):]
ss=old.replace('check_init_member(','init_original(')+'\n'
for n,t in variants.items():ss+=(old[:a]+t+old[b:]).replace('check_init_member(','init_'+n+'(')+'\n'
(p/'initializers.inc').write_text(ss)
g=(p/'frontier-gate.c').read_text()
a=g.index('#include "walkfrontier.inc"');b=g.index('static uint32_t seed=',a);g=g[:a]+'''#include "walkfrontier.inc"
#include "span.inc"
#include "initializers.inc"
typedef uint32_t Walk(const TypeTable*,uint32_t,uint32_t,bool);
static Walk* volatile methods[]={init_original,init_first,init_separate,init_mask};
'''+g[b:]
g=g.replace('uint32_t key=keys[shape],v[4],qual[4];uint64_t off[4];for(unsigned j=0;j<4;j++)v[j]=methods[j](&tb,view,key,&off[j],&qual[j]);','uint32_t key=keys[shape],v[4],tag=tb.types.index[type_index(type_strip_aligned(&tb,view))];for(unsigned j=0;j<4;j++)v[j]=methods[j](&tb,tag,key,false);').replace('v[0]!=v[j]||off[0]!=off[j]||qual[0]!=qual[j]', 'v[0]!=v[j]').replace('uint32_t qq;uint64_t oo;uint32_t found=fn(&tb,view,key,&oo,&qq);acc+=found+oo+qq;', 'uint32_t found=fn(&tb,tag,key,false);acc+=found;')
(p/'initial-gate.c').write_text(g);(p/'span.inc').write_text((p/'overlap.c').read_text().replace('uint32_t overlap(', 'static inline uint32_t name_span('))
(p/'initial-task').write_text((p/'frontier-task').read_text().replace('frontier','initial'))
