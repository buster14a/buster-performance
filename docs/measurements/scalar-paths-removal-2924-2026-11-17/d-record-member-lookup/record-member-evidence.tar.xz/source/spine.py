from pathlib import Path
p=Path(__file__).parent;s=(p/'walkinline.inc').read_text()
a=s.index('    enum { LOCAL_TAGS');fast='''    uint32_t spine_member = first;
    uint32_t spine_qualifiers = type_qualifiers(root);
    uint64_t spine_offset = 0;
    for (;;)
    {
        const TypeId inner = type_strip_aligned(table, table->members.type[spine_member]);
        const uint8_t kind = type_kind(table, inner);
        if (kind != BUSTER_TYPE_KIND_STRUCT && kind != BUSTER_TYPE_KIND_UNION) break;
        const uint32_t tag = table->types.index[type_index(inner)];
        const uint32_t begin = table->tags.member_begin[tag];
        const uint32_t size = table->tags.member_count[tag];
        spine_qualifiers |= type_qualifiers(inner);
        spine_offset += table->members.offset[spine_member];
        const uint32_t end = begin + size;
        const uint32_t candidate = inline_next_candidate(table, begin, end, name);
        if (candidate == end) break;
        if (table->members.name[candidate] == name)
        {
            *offset = spine_offset + table->members.offset[candidate];
            *qualifiers = spine_qualifiers;
            return candidate;
        }
        spine_member = candidate;
    }
'''
p0=s[:a]+fast+s[a:];out=p0.replace('inline_next_candidate','spine_next_candidate').replace('walk_inline(', 'walk_spine(');(p/'walkspine.inc').write_text(out)
a=p0.index('        const uint32_t candidate = inline_next_candidate');t=p0[:a]+'''        if (table->tags.lookup[tag] == 0)
        {
            const uint32_t leaf = type_lookup_scan(table->members.name, begin, size, name);
            if (leaf != 0)
            {
                *offset = spine_offset + table->members.offset[leaf];
                *qualifiers = spine_qualifiers;
                return leaf;
            }
            break;
        }
'''+p0[a:]
(p/'walkleaf.inc').write_text(t.replace('inline_next_candidate','leaf_next_candidate').replace('walk_inline(', 'walk_leaf('))
# The root's known first candidate does not need to be searched a second time.
t=t.replace('    while (result == 0 && depth != 0)','    uint32_t pending = first;\n    while (result == 0 && depth != 0)').replace('const uint32_t member = inline_next_candidate(table, top->next, top->end, name);','const uint32_t member = pending;')
a=t.index('    if (scratch.arena != NULL)');j=t.rindex('    }',0,a);t=t[:j]+'''        if (result == 0 && depth != 0)
        {
            const TypeMemberFrame* frame = stack + depth - 1;
            pending = inline_next_candidate(table, frame->next, frame->end, name);
        }
'''+t[j:]
(p/'walkpending.inc').write_text(t.replace('inline_next_candidate','pending_next_candidate').replace('walk_inline(', 'walk_pending('))
g=(p/'nested-gate.c').read_text().replace('#include "walksimd.inc"\n#include "walkinline.inc"\n#include "walkindex.inc"', '#include "walkspine.inc"\n#include "walkleaf.inc"\n#include "walkpending.inc"').replace('type_lookup_walk,walk_simd,walk_inline,walk_index','type_lookup_walk,walk_spine,walk_leaf,walk_pending');(p/'spine-gate.c').write_text(g)
(p/'spine-task').write_text((p/'nested-task').read_text().replace('nested','spine'))
