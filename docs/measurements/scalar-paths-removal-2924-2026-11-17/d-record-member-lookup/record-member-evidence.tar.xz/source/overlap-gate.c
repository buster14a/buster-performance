#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
typedef uint32_t Find(const uint32_t*,uint32_t,uint32_t,uint32_t);
Find scalar, page, front, overlap, sequence, frontfirst, cfirst, bounded;
static Find* const scans[]={scalar, page, front, overlap, sequence, frontfirst, cfirst, bounded};
static uint32_t state=3443;
static uint32_t random32(void){state=1664525*state+1013904223;return state;}
static uint64_t ticks(void){_mm_lfence();uint64_t x=__rdtsc();_mm_lfence();return x;}
static int cmp(const void*l,const void*r){uint64_t a=*(const uint64_t*)l,b=*(const uint64_t*)r;return (a>b)-(a<b);}
int main(int argc,char** argv){
 if(argc>1)state=strtoul(argv[1],0,10);
 const unsigned page=sysconf(_SC_PAGESIZE),bytes=64*1024,begin=3;
 char* space=mmap(0,bytes+2*page,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 if(space==MAP_FAILED||mprotect(space+page,bytes,PROT_READ|PROT_WRITE))return 2;
 uint32_t sizes[145];unsigned ns=0;
 for(unsigned n=0;n<=81;n++)sizes[ns++]=n;
 unsigned more[]={95,96,97,111,112,113,127,128,129,191,192,193,255,256,257,511,512,513,1023,1024,1025,2048,4096,8192};
 for(unsigned i=0;i<sizeof(more)/sizeof(*more);i++)sizes[ns++]=more[i];
 volatile uint32_t sink=0;
 for(unsigned g=0;g<2;g++)for(unsigned z=0;z<ns;z++){
  unsigned n=sizes[z];uint32_t* names=(uint32_t*)(space+page)+(g?bytes/4-n-begin:0);
  for(unsigned i=0;i<n;i++)names[begin+i]=1+2*i;
  for(unsigned shape=0;shape<5;shape++){
   unsigned slot=shape==0?n:shape==1?0:shape==2?n/2:shape==3&&n?n-1:n/4;
   unsigned key=slot<n?names[begin+slot]:0xf0000000,expect=slot<n?begin+slot:0;
   if(shape==4&&n)names[begin+n-1]=key;
   for(unsigned j=0;j<8;j++)if(scans[j](names,begin,n,key)!=expect){fprintf(stderr,"bad %u %u %u %u\n",j,g,n,shape);return 1;}
   unsigned scanned=slot<n?slot+1:n;unsigned reps=4096/(1+scanned/16)+32;
   uint64_t times[8][11];
   for(unsigned r=0;r<11;r++){
    unsigned off=random32()%8;
    for(unsigned k=0;k<8;k++){
     unsigned j=r&1?(k+off)%8:(off+8-k)%8;Find* f=scans[j];uint32_t x=0;uint64_t t=ticks();
     for(unsigned it=0;it<reps;it++)x+=f(names,begin,n,key);
     times[j][r]=ticks()-t;sink=x;
    }
   }
   printf("%u %u %u %u",g,n,shape,reps);for(unsigned j=0;j<8;j++){qsort(times[j],11,8,cmp);printf(" %lu",times[j][5]);}puts("");
  }
 }
 fprintf(stderr,"validated %u lengths and five hit positions on both placements (%u)\n",ns,sink);
}
