from pathlib import Path
p=Path(__file__).parent;d=p/'tree/src/buster/compiler';f=d/'c_types.c';import subprocess
s=subprocess.check_output(['git','-C',str(p/'tree'),'show','HEAD:src/buster/compiler/c_types.c'],text=True)
a=s.index('static uint32_t type_lookup_walk(const TypeTable*',s.index('// The walk: depth first'));b=s.index('static uint32_t type_find_member',a);t=s[a:b]
helper='''// Skip ordinary members that cannot match. Anonymous fields remain in declaration order with direct hits.
static inline uint32_t type_lookup_next_candidate(const TypeTable* table, uint32_t begin, uint32_t end, uint32_t name)
{
    const __m512i wanted = _mm512_set1_epi32((int)name);
    while (begin < end)
    {
        const uint32_t count = end - begin;
        const __mmask16 live = count >= 16 ? UINT16_MAX : (__mmask16)((1u << count) - 1);
        const __m512i names = _mm512_maskz_loadu_epi32(live, table->members.name + begin);
        const __mmask16 direct = _mm512_cmpeq_epi32_mask(names, wanted);
        const __mmask16 unnamed = _mm512_mask_cmpeq_epi32_mask(live, names, _mm512_setzero_si512());
        __mmask16 possible = direct;
        if (unnamed != 0)
        {
            const __m128i flags = _mm_maskz_loadu_epi8(unnamed, table->members.flags + begin);
            possible |= unnamed & ~_mm_test_epi8_mask(flags, _mm_set1_epi8(BUSTER_TYPE_MEMBER_BIT_FIELD));
        }
        if (possible != 0)
        {
            return begin + (uint32_t)__builtin_ctz(possible);
        }
        if (count <= 16) break;
        begin += 16;
    }
    return end;
}

'''
i=t.index('    Scratch scratch = scratch_begin(0);');j=t.index('    // A frame',i)
t=t[:i]+t[t.index('    const TypeId root',i):j]+'''    if (!searching)
    {
        *offset = 0;
        *qualifiers = 0;
        return 0;
    }
    const uint32_t root_tag = table->types.index[type_index(root)];
    const uint32_t root_end = table->tags.member_begin[root_tag] + table->tags.member_count[root_tag];
    const uint32_t first = type_lookup_next_candidate(table, table->tags.member_begin[root_tag], root_end, name);
    if (first == root_end || table->members.name[first] == name)
    {
        const bool found = first != root_end;
        *offset = found ? table->members.offset[first] : 0;
        *qualifiers = found ? type_qualifiers(root) : 0;
        return found ? first : 0;
    }
    Scratch scratch = scratch_begin(0);
'''+t[j:]
t=t.replace('searching ? BUSTER_ARENA_PUSH_ARRAY(scratch.arena, TypeMemberFrame, room) : 0','BUSTER_ARENA_PUSH_ARRAY(scratch.arena, TypeMemberFrame, room)').replace('searching && places == 0','places == 0').replace('if (searching && result == 0)','if (result == 0)').replace('        const uint32_t tag = table->types.index[index];\n        places[index]', '        places[index]',1).replace('.next = table->tags.member_begin[tag],\n            .end = table->tags.member_begin[tag] + table->tags.member_count[tag],','.next = first,\n            .end = root_end,',1)
t=t.replace('        if (top->next == top->end)','        const uint32_t member = type_lookup_next_candidate(table, top->next, top->end, name);\n        if (member == top->end)').replace('            const uint32_t member = top->next++;','            top->next = member + 1;')
(p/'walksimd.inc').write_text(helper+t.replace('type_lookup_walk(', 'walk_simd('));f.write_text(s[:a]+helper+t+s[b:])
