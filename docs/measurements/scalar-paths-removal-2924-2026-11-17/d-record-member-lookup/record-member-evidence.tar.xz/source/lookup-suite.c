#include "buster/compiler/c_types_benchmark.c"
#include "buster/compiler/test_paths.h"
#include "buster/compiler/test_tool.c"
#define BUSTER_S8(s) ((String8){(s),sizeof(s)-1})
#include "buster/compiler/c_types_test.c"
int main(void) { return type_test_lookups(1, 150) ? 0 : 1; }
