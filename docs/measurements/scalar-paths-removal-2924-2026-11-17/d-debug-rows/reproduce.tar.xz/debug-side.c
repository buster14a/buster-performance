#include <immintrin.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
#include <limits.h>
typedef struct { char* pointer; uint64_t length; } String8;
#define BUSTER_S8(value) ((String8){ value, sizeof(value)-1 })
#include DEBUG_SOURCE
#include "debug-gate.h"
uint64_t SIDE(const DebugInput* fixture, uint8_t* bytes)
{
    const String8 files[] = {{ "a.c", 3 }, { "b.c", 3 }, { "c.c", 3 }};
    DebugFunction functions[128];
    for (uint32_t i = 0; i < fixture->functions; i++)
    {
        functions[i] = (DebugFunction){ .name = files[0], .size = fixture->size[i], .first_row = fixture->first[i], .row_count = fixture->first[i+1]-fixture->first[i], .file = fixture->file[i], .line = 1, .prologue_end = fixture->body[i] };
    }
    const DebugUnit unit = { .directory = files[0], .files = files, .file_count = 3, .functions = functions, .function_count = fixture->functions, .offsets = fixture->offsets,
        .lines = fixture->lines, .row_files = fixture->row_files, .row_count = fixture->first[fixture->functions] };
    DebugWriter writer = { .bytes = bytes };
    debug_line(&unit, &writer, NULL);
    return writer.size;
}
