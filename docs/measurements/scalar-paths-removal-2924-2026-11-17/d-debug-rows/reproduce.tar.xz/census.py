from pathlib import Path
import gzip
import re
import sys

for path in sorted(Path(sys.argv[1]).glob('rawline-*.txt.gz')):
    counts = [0] * 6
    rows = []
    previous = None
    mark = False
    change = False
    for line in gzip.open(path, 'rt', errors='replace'):
        if 'Extended opcode 2: set Address' in line:
            rows = []
            previous = None
            mark = change = False
        elif 'Set File Name to entry ' in line:
            current = int(re.search(r'Set File Name to entry (\d+)', line)[1])
            change = previous is not None and current != previous
            previous = current
        elif 'Set prologue_end to true' in line:
            mark = True
        elif re.search(r']\s+(?:Special opcode|Copy)', line):
            rows.append((mark, change))
            mark = change = False
        elif 'End of Sequence' in line:
            counts[0] += 1
            counts[1] += len(rows)
            run = 0
            for flag, file_change in rows:
                if flag or file_change:
                    counts[2] += run % 4 + 1
                    counts[3] += run // 4
                    run = 0
                else:
                    run += 1
                counts[4] += flag
                counts[5] += file_change
            counts[2] += run % 4
            counts[3] += run // 4
    assert counts[1] == counts[2] + 4 * counts[3]
    print(path.name, *counts, sep='\t')
