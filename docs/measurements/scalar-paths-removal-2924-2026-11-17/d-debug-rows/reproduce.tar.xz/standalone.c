#include <immintrin.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
#include <limits.h>
typedef struct { char* pointer; uint64_t length; } String8;
#define BUSTER_S8(value) ((String8){ value, sizeof(value)-1 })
#include "head-debug.c"

#include <stdio.h>
#define BUSTER_ARRAY_LENGTH(v) (sizeof(v)/sizeof((v)[0]))
static uint64_t debug_test_leb(const uint8_t* bytes, uint64_t size, uint64_t* position, bool sign, bool* valid)
{
    uint64_t value = 0;
    uint32_t shift = 0;
    uint8_t byte = 0x80;
    while (*valid && (byte & 0x80) != 0)
    {
        if (*position >= size || shift >= 64)
        {
            *valid = false;
        }
        else
        {
            byte = bytes[*position];
            *position += 1;
            value |= (uint64_t)(byte & 0x7f) << shift;
            shift += 7;
        }
    }
    if (sign && (byte & 0x40) != 0 && shift < 64)
    {
        value |= UINT64_MAX << shift;
    }
    return value;
}
// Decode a single row and check the placement of its prologue marker. With this header PC 16 fits every special line, and PC 17 only lines -5 through -1.
static bool debug_test_delta(const uint8_t* bytes, uint64_t size, uint64_t* position, uint32_t pc, int32_t line, bool marked)
{
    bool valid = *position < size;
    if (valid)
    {
        uint8_t opcode = bytes[(*position)++];
        if (marked && opcode == 10)
        {
            valid = *position < size;
            opcode = valid ? bytes[(*position)++] : 0;
            valid = valid && opcode >= 13;
            marked = false;
        }
        if (opcode >= 13)
        {
            const int32_t adjusted = opcode - 13;
            valid = valid && !marked && (uint32_t)(adjusted / 14) == pc && adjusted % 14 - 5 == line;
        }
        else
        {
            const bool fits = line >= -5 && line <= 8 && (pc < 17 || (pc == 17 && line < 0));
            valid = valid && !fits && opcode == 2;
            const uint64_t address = debug_test_leb(bytes, size, position, false, &valid);
            valid = valid && address == pc && *position < size && bytes[(*position)++] == 3;
            const int64_t advance = (int64_t)debug_test_leb(bytes, size, position, true, &valid);
            if (valid && marked)
            {
                valid = *position < size && bytes[(*position)++] == 10;
            }
            valid = valid && advance == line && *position < size && bytes[(*position)++] == 1;
        }
    }
    return valid;
}

static bool debug_test_rows(void)
{
    const uint32_t offsets[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 63, 64, 127, 128, 16383, 16384,
                                 2097151, 2097152, 268435455, 268435456, 0x80000000u, UINT32_MAX };
    const int32_t lines[] = { -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 63, 64, -64, -65, 8191, 8192, -8192, -8193, INT32_MIN, INT32_MAX };
    bool valid = true;
    uint64_t checks = 0;
    for (uint32_t pc = 0; pc < BUSTER_ARRAY_LENGTH(offsets); pc += 1)
    {
        for (uint32_t line = 0; line < BUSTER_ARRAY_LENGTH(lines); line += 1)
        {
            uint32_t delta[4];
            int32_t advance[4];
            for (uint32_t row = 0; row < 4; row += 1)
            {
                delta[row] = offsets[(pc + row) % BUSTER_ARRAY_LENGTH(offsets)];
                advance[row] = lines[(line + row) % BUSTER_ARRAY_LENGTH(lines)];
            }
            for (uint32_t count = 1; count <= 4; count += 1)
            {
                for (uint32_t mark = 0; mark <= count; mark += 1)
                {
                    uint8_t bytes[64];
                    memset(bytes, 0xa5, sizeof(bytes));
                    DebugWriter writer = { .bytes = bytes };
                    DebugWriter measure = { 0 };
                    const uint32_t marked = mark == count ? 0 : 1u << mark;
                    const __m128i offsets_v = _mm_loadu_si128((const __m128i*)delta);
                    const __m128i lines_v = _mm_loadu_si128((const __m128i*)advance);
                    debug_rows_vector(&writer, offsets_v, lines_v, count, marked);
                    debug_rows_vector(&measure, offsets_v, lines_v, count, marked);
                    uint64_t position = 0;
                    valid &= writer.size == measure.size && writer.size < sizeof(bytes);
                    for (uint32_t row = 0; valid && row < count; row += 1)
                    {
                        valid &= debug_test_delta(bytes, writer.size, &position, delta[row], advance[row], mark == row);
                    }
                    valid &= position == writer.size;
                    for (; valid && position < sizeof(bytes); position += 1)
                    {
                        valid &= bytes[position] == 0xa5;
                    }
                }
            }
            checks += 1;
        }
    }
    printf("debug special and LEB rows: %llu boundary batches, %s\n", (unsigned long long)checks, valid ? "pass" : "FAIL");
    return valid;
}

static bool debug_test_random_rows(void)
{
    bool valid = true;
    uint64_t state = 88;
    for (uint32_t batch = 0; valid && batch < 4096; batch += 1)
    {
        uint32_t delta[4];
        int32_t advance[4];
        uint8_t vector[64] = { 0 };
        DebugWriter b = { .bytes = vector };
        for (uint32_t row = 0; row < 4; row += 1)
        {
            state = state * 6364136223846793005ull + 1442695040888963407ull;
            delta[row] = (uint32_t)(state >> 32);
            state = state * 6364136223846793005ull + 1442695040888963407ull;
            advance[row] = (int32_t)(state >> 32);
            if ((batch & (1u << row)) != 0)
            {
                delta[row] %= 17;
                advance[row] = (int32_t)((uint32_t)advance[row] % 14) - 5;
            }
        }
        debug_rows_vector(&b, _mm_loadu_si128((const __m128i*)delta), _mm_loadu_si128((const __m128i*)advance), 4, 0);
        uint64_t position = 0;
        for (uint32_t row = 0; valid && row < 4; row += 1)
        {
            valid &= debug_test_delta(vector, b.size, &position, delta[row], advance[row], false);
        }
        valid &= position == b.size;
    }
    printf("debug special and LEB rows: 4096 deterministic mixed batches, %s\n", valid ? "pass" : "FAIL");
    return valid;
}
int main(void){return !(debug_test_rows() & debug_test_random_rows());}
