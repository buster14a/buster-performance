#include <x86intrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "debug-gate.h"
static int compare(const void* a,const void* b) {uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return x<y?-1:x>y;}
static uint32_t state = 3454;
static uint32_t next(void) { state=state*1664525+1013904223;return state; }
int main(void)
{
 static uint32_t offsets[128*513],lines[128*513],files[128*513];
 static uint8_t old_bytes[2<<20],new_bytes[2<<20];
 const uint32_t sizes[]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,19,23,27,31,32,33,63,64,65,127,128,129,255,256,257,511,512,513};
 for(unsigned shape=0;shape<5;shape++) for(unsigned c=0;c<sizeof sizes/sizeof *sizes;c++){
  unsigned n=sizes[c]; DebugInput f={.functions=128,.offsets=offsets,.lines=lines,.row_files=shape>=2?files:NULL};
  for(unsigned i=0;i<128;i++){
   f.first[i]=n*i; f.file[i]=i%3; f.body[i]=(n && shape!=0)?1+next()%n:0;
   uint32_t pc=0,line=900000,file=f.file[i];
   for(unsigned j=0;j<n;j++){
    unsigned k=n*i+j;
    pc+=shape==4?next()%24576:shape==0?next()%16:next()%23;
    if(shape==4) line=next()&0x7fffffff; else line=j?line+1+(next()%4):1+i;
    if(shape==3 || (shape>=2 && (next()&7)==0))file=(file+1)%3;
    offsets[k]=pc;lines[k]=line;files[k]=file;
   }
   f.size[i]=pc+8;
  }
  f.first[128]=128*n;
  memset(old_bytes,0xa5,sizeof old_bytes);memset(new_bytes,0xa5,sizeof new_bytes);
  uint64_t bytes=baseline(&f,old_bytes);
  if(bytes!=candidate(&f,new_bytes) || bytes!=candidate(&f,NULL) || memcmp(old_bytes,new_bytes,bytes+16)!=0){fprintf(stderr,"different at shape %u n %u size %lu\n",shape,n,bytes);return 1;}
  uint64_t times[2][15]; unsigned repeat=n>128?1:n>16?4:16;
  for(unsigned j=0;j<15;j++)for(unsigned order=0;order<2;order++){
   unsigned side=(order+j)%2;_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();
   uint64_t sum=0;
   for(unsigned k=0;k<repeat;k++){
    if(side){sum+=candidate(&f,NULL);sum+=candidate(&f,new_bytes);}else{sum+=baseline(&f,NULL);sum+=baseline(&f,old_bytes);}
   }
   _mm_lfence();times[side][j]=__rdtsc()-t;
   if(sum!=bytes*2*repeat)return 2;
  }
  for(unsigned j=0;j<2;j++)qsort(times[j],15,sizeof(uint64_t),compare);
  printf("%u\t%u\t%lu\t%lu\t%.4f\n",shape,n,times[0][7],times[1][7],(double)times[1][7]/times[0][7]);fflush(stdout);
 }
 return 0;
}
