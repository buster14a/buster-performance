typedef struct {
 uint32_t functions, size[128], first[129], file[128], body[128];
 uint32_t* offsets;
 uint32_t* lines;
 uint32_t* row_files;
} DebugInput;
uint64_t baseline(const DebugInput*, uint8_t*);
uint64_t candidate(const DebugInput*, uint8_t*);
