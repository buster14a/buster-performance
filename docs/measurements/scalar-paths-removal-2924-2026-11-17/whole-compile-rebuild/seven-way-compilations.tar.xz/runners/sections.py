from hashlib import sha256
from pathlib import Path
from struct import unpack_from
from mmap import mmap,ACCESS_READ
import sys
def sections(p):
 with Path(p).open('rb') as f, mmap(f.fileno(),0,access=ACCESS_READ) as data:
  offset=unpack_from('<Q',data,40)[0]
  size,n,string_index=unpack_from('<3H',data,58)
  rows=[unpack_from('<IIQQQQIIQQ',data,offset+i*size)for i in range(n)]
  names=rows[string_index][4]
  return {data[names+r[0]:data.find(b'\0',names+r[0])].decode():(r[5],sha256(data[r[4]:r[4]+r[5]]).hexdigest()) for r in rows if r[1] not in (0,8)}
a,b=map(sections,sys.argv[1:])
print('section\toriginal_bytes\trebuilt_bytes\toriginal_sha256\trebuilt_sha256')
for key in sorted(a.keys()|b.keys()):
 x=a.get(key,(0,''));y=b.get(key,(0,''));print(key,x[0],y[0],x[1],y[1],sep='\t')
