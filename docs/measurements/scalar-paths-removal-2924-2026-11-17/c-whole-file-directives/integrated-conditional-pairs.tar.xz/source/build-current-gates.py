from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
import re
p=Path(__file__).parent
file='src/buster/compiler/c_preprocessor.c'
src=(p/'tree'/file).read_text()
base=check_output(['git','show','5f5302828:'+file],cwd=p/'tree').decode()
inc=p/'current-base/buster/compiler';inc.mkdir(parents=True,exist_ok=True)
(inc/'c_preprocessor.c').write_text(base)
(inc/'c_preprocessor_benchmark.c').write_bytes(check_output(['git','show','5f5302828:src/buster/compiler/c_preprocessor_benchmark.c'],cwd=p/'tree'))
functions=['pp_next_line','pp_finish_directives','pp_directive_arrays','pp_scan_directives_window','pp_publish_directives','pp_directive_table']
def func(s,name):
 m=re.search(r'^static (?:bool|uint32_t) '+name+r'\([^\n]+?\)\n\{',s,re.M);assert m,name
 return s[m.start():s.index('\n}',m.end())+2]
for tag,old in [('pr','bounded'),('search','groupseek'),('blocks','fullwords'),('both','guardedseek')]:
 out=src
 if tag!='pr':
  w=(p/(old+'.inc')).read_text()
  for name in functions:
   if name not in ['pp_next_line','pp_scan_directives_window']:continue
   if name=='pp_next_line' and tag=='blocks' or name=='pp_scan_directives_window' and tag=='search':continue
   sym=old+'_'+('next_line' if name=='pp_next_line' else name)
   current=func(out,name);new=func(w,sym).replace(sym,name)
   if name=='pp_next_line' and tag=='search':new=new.replace('    const uint32_t current','    if (after >= count)\n    {\n        return count;\n    }\n    const uint32_t current',1)
   if name=='pp_next_line' and tag=='both':new=new.replace('    if (after >= count) return count;','    if (after >= count)\n    {\n        return count;\n    }')
   out=out.replace(current,new)
 selected='\n\n'.join(func(out,name)for name in functions)+'\n'
 for name in functions:selected=re.sub(r'\b'+name+r'\b','current_'+tag+'_'+name,selected)
 (p/('current-'+tag+'.inc')).write_text(selected)
 (p/('current-'+tag+'-increment.patch')).write_text(''.join(unified_diff(src.splitlines(True),out.splitlines(True),'a/'+file,'b/'+file)))
gate=(p/'guarded-search-gate.c').read_text()
a=gate.index('#include "groupseek');b=gate.index('typedef bool TableFn',a)
gate=gate[:a]+''.join('#include "current-'+tag+'.inc"\n'for tag in ('pr','search','blocks','both'))+gate[b:]
a=gate.index('methods[]={');b=gate.index('};',a)
gate=gate[:a]+'methods[]={pp_directive_table,'+','.join('current_'+tag+'_pp_directive_table'for tag in ('pr','search','blocks','both'))+gate[b:]
(p/'current-gate.c').write_text(gate)
task=(p/'guarded-search-task').read_text().replace('base=/dev/shm/buster-adler-production-6b097f86/src/src','base=/tmp/buster-main-5f530282-6b097f86/source/src').replace('-I full-src','-I current-base').replace('guarded-search','current')
task=task.replace('"$lock" "$cc"','until [[ -d /tmp/buster-main-5f530282-6b097f86/source/src/buster ]]; do sleep 2; done\n"$lock" "$cc"')
(p/'current-gate-task').write_text(task)
s=(p/'seekscan-corpus').read_text().replace('out="$root/seekscan-$group"','tag=$2\nbinroot=/tmp/buster-main-5f530282-6b097f86/images\nout="$root/$tag-$group"').replace('base=/dev/shm/buster-unroll-6b097f86/src/build/unroll-base','base="$binroot/main"').replace('head=/dev/shm/buster-unroll-6b097f86/src/build/pp-whole-seekscan','head="$binroot/$tag"')
(p/'current-corpus').write_text(s)
s=(p/'current-build').read_text().split('for tag in main currentmain;do')[0]+'''until [[ -e "$d/currentmain-oracle.ok" ]];do sleep 2;done
for tag in blocks both;do
 git apply "$root/current-$tag-increment.patch"
 "$lock" timeout 1200 ./build.sh --config Release --jobs 4 >"$d/current-$tag-build.log" 2>&1
 cp --preserve=mode build/compiler "$d/images/current-$tag"
 cmp build/compiler "$d/images/current-$tag"
 git apply -R "$root/current-$tag-increment.patch"
 touch "$d/current-$tag-built.ok"
done
'''
(p/'current-build-variants').write_text(s)
s=s[:s.index('until [[')]+'''tag=$1
until [[ -e "$d/$tag-built.ok" ]];do sleep 2;done
if [[ $tag != currentmain ]];then
 "$lock" taskset -c 2 "$d/images/$tag" test-preprocessor --clang --jobs 4 --fuzz 128 >"$d/$tag-oracle.log" 2>&1
 touch "$d/$tag-oracle.ok"
fi
for g in lua sqlite musl;do bash "$root/current-corpus" "$g" "$tag";done
touch "$d/$tag-corpus.ok"
'''
(p/'current-source-task').write_text(s)
