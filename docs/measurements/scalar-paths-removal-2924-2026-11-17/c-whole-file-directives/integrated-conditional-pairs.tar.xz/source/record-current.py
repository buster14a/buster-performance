from pathlib import Path
from collections import defaultdict
from statistics import median
import tarfile,re
p=Path(__file__).parent;r=p/'results';d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/c-whole-file-directives')
s=(p/'record-corpora.py').read_text()
# Reuse the executable's complete-run parser, including the output, diagnostic and five-pair checks.
method=s[s.index('rows=[]'):s.index('source=')]
def corpus(tag):
 env={'r':p/(tag+'-corpus-results'),'variant':tag,'re':re,'median':median};exec(method,env);return env['rows']
def check_oracle(raw,expected,slots):
 assert '0 of '+str(expected)+' fail' in raw and '0 of 240 sources differ' in raw and '0 of 1051 checks fail' in raw and raw.count('0 unverified), 0 differ')==2
 assert '0 of 176 header, mode and hosting sets differ' in raw and f'0 of {slots} checks fail' in raw
for tag,n in [('blockscan',9),('seekscan',13)]:
 for i in range(n+1):
  directory=r/(tag+'-mutations');v=int((directory/f'{i}.status').read_text());s=(directory/f'{i}.log').read_text()
  assert (v==0 and '65 fixed' in s) if i==0 else v in (1,139)
check_oracle((r/'currentmain-source-tree-oracle.log').read_text(),422,119628)
check_oracle((p/'seekscan-corpus-results/seekscan-oracle.log').read_text(),419,119628)
# These corpora precede the main revision that introduced conditional pairing.
rows=corpus('seekscan');qs=defaultdict(list)
for seed in (1,133,789):
 assert '159 widths and fourteen distributions' in (r/f'current-{seed}.log').read_text()
 for l in (r/f'current-{seed}.tsv').read_text().splitlines():
  n,shape,reps,base,*xs=map(int,l.split());assert min(reps,base,*xs)>0 and len(xs)==4
  qs[n,shape].append([v/base for v in xs])
assert len(qs)==2226 and all(len(v)==3 for v in qs.values())
gates=[]
for i,tag in enumerate(['Integrated draft','Guarded line-word search','Complete token blocks','Complete blocks and guarded search']):
 vs=[median(a[i]for a in xs)for xs in qs.values()]
 gates.append(f'| {tag} | {sum(x<=1 for x in vs):,}/2,226 | {median(vs):.4f} | {max(vs):.4f} |')
title='## Integrating the table builder with conditional pairing'
body=title+'''

Main at 5f5302828 includes conditional pairing and shared note storage from PR #3694. The integrated candidate keeps the early return for tables without conditionals and uses the destination arena when acquiring scratch for the pairing stack. The complete compiler passed 422 fixed cases, 256 generated Clang comparisons and all 176 header configurations. Window preparation matched on 240 sources, 119,628 cuts and 1,051 directive-position checks.

The table below compares against the current main table builder in the same optimized harness on the locked 9700X. All 2,226 cells matched for positions, line ends, kinds, conditional links, notes and include guards. Ratios compare three paired seeds.

| Table builder | Cells meeting main | Median ratio | Slowest cell |
| --- | ---: | ---: | ---: |
'''+'\n'.join(gates)+'''

The guarded cursor and fixed-answer table oracle passed 65 cases on each of the prior block-scanner and guarded-search implementations. All nine block-scanner mutations and thirteen guarded-search mutations were detected. The protected inputs catch reads past the final token packet and the final line-bitmap packet, including an already-exhausted cursor.

### Complete preprocessing before conditional pairing landed

The guarded-search compiler was also compared against cc7d4ffb4. Every complete preprocessor output and diagnostic byte matched. The first three columns show median changes in user cycles over five paired rounds of three fresh processes per side. The last two give median table-builder cycles per token. The positive SQLite cells keep this version below the full acceptance gate.

| Corpus | Default | Forced whole file | 4 KiB windows | Parent table | Candidate table |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

[Integrated source, guarded size matrix, fixed-answer mutations, whole-preprocessing samples and test logs](integrated-conditional-pairs.tar.xz)
'''
doc=d/'README.md';assert title not in doc.read_text()
with tarfile.open(d/'integrated-conditional-pairs.tar.xz','w:xz',preset=2)as t:
 for f in sorted((p/'seekscan-corpus-results').rglob('*')):
  if f.is_file():t.add(f,'prior/'+str(f.relative_to(p/'seekscan-corpus-results')))
 for tag in ['blockscan','seekscan']:
  for n in [tag+'.patch',tag+'-corpus','verify-'+tag+'.c',tag+'-mutation-task',tag+'-faults.inc']:t.add(p/n,'source/'+n)
  t.add(r/(tag+'-mutations'),'prior/'+tag+'-mutations')
 for n in ['successor-mutations.py','guardedseek.inc','fullwords.inc','record-corpora.py','record-current.py','currentmain.patch','current-gate.c','current-gate-task','current-base','current-build','current-build-variants','build-current-gates.py','verify-current-tree','current-corpus','current-source-task']:t.add(p/n,'source/'+n)
 for tag in ['pr','search','blocks','both']:t.add(p/('current-'+tag+'.inc'),'source/current-'+tag+'.inc')
 for tag in ['blocks','both']:t.add(p/('current-'+tag+'-increment.patch'),'source/current-'+tag+'-increment.patch')
 for f in [r/'currentmain-source-tree-oracle.log',r/'currentmain-build.log',r/'main-build.log',*sorted(r.glob('current-*.tsv')),*sorted(r.glob('current-[0-9]*.log'))]:t.add(f,'integrated/'+f.name)
with doc.open('a')as f:f.write('\n'+body)
print(*gates,*rows,sep='\n')
