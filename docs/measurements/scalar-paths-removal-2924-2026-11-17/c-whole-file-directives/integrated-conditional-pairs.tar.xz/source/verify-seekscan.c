#include "buster/compiler/c_preprocessor_benchmark.c"
#include "guardedseek.inc"
#include "seekscan-faults.inc"
typedef bool Method(Arena*,PPFileData*);
static Method* methods[]={ guardedseek_pp_directive_table, seekscan0_pp_directive_table, seekscan1_pp_directive_table, seekscan2_pp_directive_table, seekscan3_pp_directive_table, seekscan4_pp_directive_table, seekscan5_pp_directive_table, seekscan6_pp_directive_table, seekscan7_pp_directive_table, seekscan8_pp_directive_table, seekscan9_pp_directive_table, seekscan10_pp_directive_table, seekscan11_pp_directive_table, seekscan12_pp_directive_table };
static const char* labels[]={ "production", "start-line-bits", "directive-bits", "partial-load", "drop-last-token", "overlap-columns", "lose-guard", "lose-notes", "drop-last-word", "bad-successor", "exhausted", "next-current", "skip-word", "unmasked-words" };
static bool check_table(Method*fn, unsigned n, unsigned shape)
{
    static uint8_t bytes[1026];
    const size_t page=(size_t)sysconf(_SC_PAGESIZE);
    uint8_t* map=mmap(NULL,2*page,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(map==MAP_FAILED || mprotect(map+page,page,PROT_NONE))return false;
    uint8_t* kinds=map+page-n;
    static uint32_t values[1026],starts[1026];
    memset(kinds,0,n); memset(values,0,4*n);for(unsigned i=0;i<n;i++)starts[i]=i;
    uint32_t pos[]={0,31,n>=2?n-2:0}, ends[]={15,pos[2],n},links[]={1,2,BUSTER_PP_NONE};
    uint32_t ids[]={C_NAME_IF,C_NAME_ELSE,C_NAME_ENDIF};uint8_t expected[]={PP_DIRECTIVE_IF,PP_DIRECTIVE_ELSE,PP_DIRECTIVE_ENDIF};
    unsigned count=n?3:0,guard=0,note_count=0,note_index=0,note_kind=0;
    if(n){
        if(shape==1){count=2;pos[1]=n-2;ids[0]=C_NAME_IFNDEF;ids[1]=C_NAME_ENDIF;expected[0]=PP_DIRECTIVE_IFNDEF;expected[1]=PP_DIRECTIVE_ENDIF;
            ends[0]=pos[1];ends[1]=n;links[1]=BUSTER_PP_NONE;guard=321;kinds[2]=C_TOKEN_RAW_IDENTIFIER;values[2]=guard;
            // The guard opener has exactly one operand. A non-directive line starts at its next token.
            kinds[3]=C_TOKEN_NUMERIC_CONSTANT|128;ends[0]=3;
        }else if(shape==2){ids[1]=C_NAME_ELIFDEF;expected[1]=PP_DIRECTIVE_ELIFDEF;note_count=1;note_index=1;note_kind=BUSTER_PP_NOTE_ELIFDEF;}
        else if(shape==3){for(unsigned j=0;j<3;j++){ids[j]=C_NAME_DEFINE;expected[j]=PP_DIRECTIVE_DEFINE;links[j]=BUSTER_PP_NONE;}}
        for(unsigned d=0;d<count;d++){kinds[pos[d]]=C_TOKEN_HASH|128;kinds[pos[d]+1]=C_TOKEN_RAW_IDENTIFIER;values[pos[d]+1]=ids[d];}
        if(shape!=1){kinds[15]=C_TOKEN_NUMERIC_CONSTANT|128;kinds[16]=C_TOKEN_HASH;}
    }
    if(n && shape==4){
        memset(kinds,0,n);count=1;pos[0]=n-1;ends[0]=n;links[0]=BUSTER_PP_NONE;expected[0]=PP_DIRECTIVE_NULL;kinds[n-1]=C_TOKEN_HASH|128;
    }
    Arena arena=arena_reserve(1<<20);
    PPFileData data={.kinds=kinds,.values=values,.starts=starts,.bytes=bytes,.length=n,.token_count=n};
    bool ok=arena.base && fn(&arena,&data) && data.directive_count==count && data.guard==guard && data.note_count==note_count;
    if(ok && guard)ok=data.guard_opener==0;
    if(ok && note_count)ok=data.note_directives[0]==note_index && data.note_kinds[0]==note_kind;
    for(unsigned i=0;ok && i<count;i++)ok=data.directive_hash[i]==pos[i] && data.directive_kind[i]==expected[i] && data.directive_end[i]==ends[i] && data.directive_next[i]==links[i];
    if(!ok)fprintf(stderr,"mismatch width=%u shape=%u count=%u guard=%u opener=%u notes=%u\n",n,shape,data.directive_count,data.guard,data.guard_opener,data.note_count);
    arena_release(&arena);munmap(map,2*page);return ok;
}
typedef uint32_t Cursor(const uint64_t*,uint32_t,uint32_t);
static Cursor* cursors[]={guardedseek_next_line, seekscan0_next_line, seekscan1_next_line, seekscan2_next_line, seekscan3_next_line, seekscan4_next_line, seekscan5_next_line, seekscan6_next_line, seekscan7_next_line, seekscan8_next_line, seekscan9_next_line, seekscan10_next_line, seekscan11_next_line, seekscan12_next_line};
static bool check_cursor(Cursor* find)
{
    size_t page=(size_t)sysconf(_SC_PAGESIZE);
    uint8_t* buf=mmap(NULL,page*2,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(buf==MAP_FAILED || mprotect(buf+page,page,PROT_NONE))return false;
    uint64_t* lines=(uint64_t*)(buf+page)-2;
    lines[0]=1;lines[1]=UINT64_C(1)<<61;
    bool ok=find(lines,128,0)==125 && find(lines,128,124)==125 && find(lines,128,125)==128 &&
            find(lines,128,128)==128 && find((uint64_t*)(buf+page),0,UINT32_MAX)==0;
    munmap(buf,page*2);return ok;
}
int main(int argc,char**argv){
    if(argc!=2)return 2;unsigned which=atoi(argv[1]);if(which>=BUSTER_ARRAY_LENGTH(methods))return 2;
    if(!check_cursor(cursors[which]))return fprintf(stderr,"cursor failed\n"),1;
    const unsigned widths[]={0,66,127,128,129,255,256,257,511,512,513,1024,1025};
    for(unsigned j=0;j<BUSTER_ARRAY_LENGTH(widths);j++)for(unsigned shape=0;shape<5;shape++)
        if(!check_table(methods[which],widths[j],shape))return fprintf(stderr,"%s failed invariant\n",labels[which]),1;
    fprintf(stderr,"%s passed the guarded cursor and 65 fixed table, link, inclusion guard and extension note fixtures\n",labels[which]);return 0;
}
