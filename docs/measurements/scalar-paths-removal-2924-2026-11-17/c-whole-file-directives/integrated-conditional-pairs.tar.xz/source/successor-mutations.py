from pathlib import Path
p=Path(__file__).parent
for tag,kind in [('blockscan','fullwords'),('seekscan','guardedseek')]:
 s=(p/(kind+'.inc')).read_text()
 tests=[
 ('start-line-bits','lines[i / 64] = _mm512_movepi8_mask(data);','lines[i / 64] = matches;'),
 ('directive-bits','directives[i / 64] = matches;','directives[i / 64] = matches & ~UINT64_C(1);'),
 ('partial-load','_mm512_maskz_loadu_epi8(active, kinds + i)','_mm512_loadu_si512(kinds + i)'),
 ('drop-last-token','_bzhi_u64(UINT64_MAX, end - i)','_bzhi_u64(UINT64_MAX, end - i - 1)'),
 ('overlap-columns','columns + 2 * slots + kind_words : NULL','columns + slots : NULL'),
 ('lose-guard','result ? pp_find_guard(data, &data->guard_opener) : 0','0'),
 ('lose-notes','return result;\n}\n\nstatic bool '+kind+'_pp_directive_arrays','data->note_count = 0;\n    return result;\n}\n\nstatic bool '+kind+'_pp_directive_arrays'),
 ('drop-last-word','((uint64_t)data->token_count + 63) / 64), data->directive_hash','((uint64_t)data->token_count) / 64), data->directive_hash'),
 ('bad-successor','data->directive_end[d] = end;','data->directive_end[d] = end - 1;'),
 ]
 if tag=='seekscan':
  tests += [
    ('exhausted','if (after >= count) return count;', ''),
    ('next-current','(after & 63u) + 1u','(after & 63u)'),
    ('skip-word','current + 1;','current + 2;'),
    ('unmasked-words','_mm512_maskz_loadu_epi64(active, lines + first)','_mm512_loadu_si512(lines + first)'),
  ]
 parts=[];tabs=[kind+'_pp_directive_table']; curs=[kind+'_next_line']; labels=['production']
 for i,(name,old,new) in enumerate(tests):
  assert old in s,(tag,name)
  prefix=f'{tag}{i}'
  parts.append(s.replace(old,new).replace(kind+'_',prefix+'_'))
  tabs.append(prefix+'_pp_directive_table');curs.append(prefix+'_next_line');labels.append(name)
 (p/(tag+'-faults.inc')).write_text('\n'.join(parts))
 h=(p/'verify-fullscan.c').read_text().replace('fullscan.inc',kind+'.inc').replace('fullscan-faults.inc',tag+'-faults.inc').replace('fullscan_pp_directive_table, FAULT_METHODS',', '.join(tabs)).replace('"production", FAULT_LABELS',', '.join('"'+name+'"'for name in labels))
 h=h[:h.index('int main(')]+'''typedef uint32_t Cursor(const uint64_t*,uint32_t,uint32_t);
static Cursor* cursors[]={'''+', '.join(curs)+'''};
static bool check_cursor(Cursor* find)
{
    size_t page=(size_t)sysconf(_SC_PAGESIZE);
    uint8_t* buf=mmap(NULL,page*2,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(buf==MAP_FAILED || mprotect(buf+page,page,PROT_NONE))return false;
    uint64_t* lines=(uint64_t*)(buf+page)-2;
    lines[0]=1;lines[1]=UINT64_C(1)<<61;
    bool ok=find(lines,128,0)==125 && find(lines,128,124)==125 && find(lines,128,125)==128 &&
            find(lines,128,128)==128 && find((uint64_t*)(buf+page),0,UINT32_MAX)==0;
    munmap(buf,page*2);return ok;
}
'''+h[h.index('int main('):]
 h=h.replace('const unsigned widths[]=', 'if(!check_cursor(cursors[which]))return fprintf(stderr,"cursor failed\\n"),1;\n    const unsigned widths[]=')
 # At tail width 129 the final token usually holds the directive name. Include a solitary marked hash in the final lane.
 h=h.replace('    Arena arena=', '''    if(n && shape==4){
        memset(kinds,0,n);count=1;pos[0]=n-1;ends[0]=n;links[0]=BUSTER_PP_NONE;expected[0]=PP_DIRECTIVE_NULL;kinds[n-1]=C_TOKEN_HASH|128;
    }
    Arena arena=''').replace('shape<4','shape<5').replace('passed 52 fixed','passed the guarded cursor and 65 fixed')
 (p/('verify-'+tag+'.c')).write_text(h)
 task=(p/'fullscan-mutation-task').read_text().replace('fullscan',tag).replace('{0..13}',f'{{0..{len(tests)}}}')
 (p/(tag+'-mutation-task')).write_text(task)
