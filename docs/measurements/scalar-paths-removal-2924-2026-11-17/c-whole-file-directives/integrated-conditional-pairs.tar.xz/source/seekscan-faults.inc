static uint32_t seekscan0_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan0_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan0_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan0_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan0_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = matches;
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = matches;
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan0_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan0_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan0_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan0_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan0_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan0_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan0_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan1_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan1_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan1_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan1_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan1_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches & ~UINT64_C(1);
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches & ~UINT64_C(1);
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan1_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan1_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan1_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan1_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan1_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan1_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan1_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan2_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan2_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan2_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan2_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan2_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan2_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan2_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan2_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan2_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan2_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan2_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan2_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan3_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan3_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan3_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan3_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan3_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i - 1);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan3_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan3_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan3_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan3_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan3_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan3_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan3_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan4_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan4_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan4_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan4_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + slots : NULL;
    return columns != NULL;
}

static uint32_t seekscan4_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan4_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan4_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan4_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan4_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan4_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan4_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan4_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan5_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan5_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan5_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan5_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan5_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan5_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan5_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan5_pp_finish_directives(arena, data, lines);
    data->guard = 0;
    return result;
}

static bool seekscan5_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan5_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan5_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan5_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan6_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan6_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan6_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    data->note_count = 0;
    return result;
}

static bool seekscan6_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan6_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan6_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan6_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan6_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan6_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan6_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan6_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan6_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan7_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan7_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan7_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan7_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan7_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan7_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan7_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count) / 64), data->directive_hash);
    }
    result = result && seekscan7_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan7_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan7_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan7_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan7_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan8_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan8_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan8_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end - 1;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan8_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan8_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan8_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan8_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan8_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan8_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan8_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan8_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan8_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan9_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan9_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan9_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan9_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan9_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan9_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan9_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan9_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan9_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan9_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan9_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan9_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan10_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u));
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan10_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan10_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan10_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan10_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan10_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan10_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan10_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan10_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan10_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan10_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan10_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan11_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 2; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan11_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan11_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan11_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan11_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan11_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan11_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan11_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan11_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan11_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan11_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan11_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t seekscan12_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    if (after >= count) return count;
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_loadu_si512(lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
static bool seekscan12_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = seekscan12_next_line(lines, data->token_count, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool seekscan12_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t seekscan12_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}

static bool seekscan12_pp_publish_directives(Arena* arena, PPFileData* data, const uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = seekscan12_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && seekscan12_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool seekscan12_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return seekscan12_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[16];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = seekscan12_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = seekscan12_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}
