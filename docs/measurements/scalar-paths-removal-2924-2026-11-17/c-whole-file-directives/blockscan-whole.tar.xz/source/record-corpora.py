from pathlib import Path
from statistics import median
import re,tarfile,sys
p=Path(__file__).parent
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/c-whole-file-directives')
variant=sys.argv[1]
assert variant in ('interleave','bounded','fullscan')
labels={'interleave':'Interleaved directive columns','bounded':'Interleaved columns with an unsigned line cursor','fullscan':'Complete bitmap words and an end-of-file line marker'}
tag=labels[variant]
r=p/(variant+'-corpus-results')
rows=[]
for g in ('lua','sqlite','musl'):
    f=r/f'{variant}-{g}';ratios=[]
    for mode in ('default','whole','window'):
        digests=[(f/f'{mode}-{k}.sha').read_text()for k in ('base','head')]
        assert digests[0]==digests[1] and re.fullmatch(r'[0-9a-f]{64}  -\n',digests[0])
        assert (f/f'{mode}-base.err').read_bytes()==(f/f'{mode}-head.err').read_bytes()
        raw=(f/f'{mode}.log').read_text();assert raw.rstrip().endswith('ab: done, 0 failed runs')
        rounds=[]
        for block in raw.split('time-runs: done, 0 failed processes')[:-1]:
            v={k:int(c)for k,c in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',block,re.M)}
            assert len(v)==2 and min(v.values())>0;rounds.append(v['head']/v['base'])
        assert len(rounds)==5
        ratios.append(f'{(median(rounds)-1)*100:+.3f}%')
    kcycles=[]
    for side in ('base','head'):
        ts=[float(re.search(r'([\d.]+) cycles/token',(f/f'tables-{side}-{i}.log').read_text())[1])for i in (1,2,3)]
        kcycles.append(f'{median(ts):.3f}')
    rows.append('| '+' | '.join([g,*ratios,*kcycles])+' |')
source={'interleave':['interleave-production.patch','interleave-corpus','interleave-task'],'bounded':['interleave-production.patch','high-lines.patch','bounded-corpus','bounded-production-task'],'fullscan':['interleave-production.patch','high-lines.patch','fullscan.patch','fullscan-corpus','fullscan-production-task','sentinel-gate.c','bounded.inc','sentinel.inc','fullscan.inc','sentinel-task','verify-fullscan.c','fullscan-faults.py','fullscan-faults.inc','fullscan-mutation-task']}[variant]
more='';archive=variant+'-preprocessing.tar.xz'
if variant=='fullscan':
    sites={}
    for seed in (1,133,789):
        assert '159 widths and nine distributions' in (p/f'sentinel-results/sentinel-{seed}.log').read_text()
        lines=(p/f'sentinel-results/sentinel-{seed}.tsv').read_text().splitlines();assert len(lines)==1431
        for line in lines:
            n,shape,reps,base,*cs=map(int,line.split());assert len(cs)==3 and min(reps,base,*cs)>0
            sites.setdefault((n,shape),[]).append([v/base for v in cs])
    assert len(sites)==1431 and all(len(v)==3 for v in sites.values())
    srows=[]
    for j,n in enumerate(['Bounded cursor','End marker','End marker and unmasked complete words']):
        vs=[median(x[j] for x in v)for v in sites.values()]
        srows.append(f'| {n} | {sum(x<=1 for x in vs)}/1,431 | {median(vs):.4f} | {max(vs):.4f} |')
    assert 'passed 52 fixed' in (r/'fullscan-mutations/0.log').read_text()
    for i in range(14):
        st=int((r/f'fullscan-mutations/{i}.status').read_text())
        assert st in ((0,) if i==0 else (1,139))
    oracle=(r/'fullscan-oracle.log').read_text();assert '0 of 1051 checks fail' in oracle and '0 of 240 sources differ' in oracle and oracle.count('0 unverified), 0 differ')==2
    more='''

The logical end of the token stream is a marked line start. This also gives the final complete bitmap word its own terminating slot. The full-width scanner uses ordinary loads for complete words and a masked load for the last partial word. A fixed-answer table oracle checked 52 fixtures and rejected 13 changes, including a load that crossed the protected end of its input. The Clang comparisons passed. The table gives median paired ratios across three seeds on the 9700X.

| Scanner | Cells meeting parent | Median ratio | Slowest ratio |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(srows)
with tarfile.open(d/archive,'w:xz') as t:
    for f in r.rglob('*'):
        if f.is_file():t.add(f,arcname='native/'+str(f.relative_to(r)))
    for n in source:t.add(p/n,arcname='source/'+n)
    if variant=='fullscan':t.add(p/'sentinel-results',arcname='native/word-sweep')
title='## '+tag+' in complete preprocessing'
f=d/'README.md';s=f.read_text();assert title not in s
f.write_text(s.rstrip()+'\n\n'+title+more+'''

Each configuration matched the untouched parent’s preprocessor output and diagnostics. The first three columns give the median paired change in complete preprocessing user cycles over five rounds with three fresh processes per executable. The last two columns time the directive-table benchmark in cycles per token across three runs.

| Corpus | Default | Forced whole file | 4 KiB windows | Parent table | Candidate table |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(rows)+f'\n\n[Compiler source, output digests, directive-table measurements and process logs]({archive})\n')
print(*rows,sep='\n')
