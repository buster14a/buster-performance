#include <immintrin.h>
#include <stdint.h>
#define BUSTER_C_TOKEN_START_OF_LINE 128
#define C_TOKEN_HASH 60
#define BUSTER_UNLIKELY(x) __builtin_expect(!!(x),0)
static uint32_t pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    for (uint64_t i = begin; i < end; i += 64)
    {
        const __mmask64 valid = end - i >= 64 ? ~0ull : _bzhi_u64(~0ull, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_mask_cmpeq_epi8_mask(valid, block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block) & valid;
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}
static inline void exact_places(uint32_t* places, uint32_t n, __m512i ranks)
{
    if(n>=16) { _mm512_storeu_si512(places, ranks); return; }
    if(n>=8) { _mm256_storeu_si256((__m256i*)places,_mm512_castsi512_si256(ranks)); places+=8; ranks=_mm512_shuffle_i32x4(ranks,ranks,_MM_SHUFFLE(3,2,3,2)); }
    __m256i eight=_mm512_castsi512_si256(ranks);
    if(n&4) { _mm_storeu_si128((__m128i*)places,_mm256_castsi256_si128(eight)); places+=4; eight=_mm256_permute2x128_si256(eight,eight,1); }
    __m128i four=_mm256_castsi256_si128(eight);
    if(n&2) { _mm_storel_epi64((__m128i*)places,four); places+=2; four=_mm_srli_si128(four,8); }
    if(n&1) *places=(uint32_t)_mm_cvtsi128_si32(four);
}
static uint32_t pp_directive_places(const uint64_t* words, uint32_t word_count, uint32_t* places)
{
    const __m512i positions = _mm512_set_epi8(63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37,
                                              36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9,
                                              8, 7, 6, 5, 4, 3, 2, 1, 0);
    uint32_t count = 0;
    for (uint32_t w=0;w<word_count;++w) {
            const uint64_t bits=words[w];
            if (bits == 0) continue;
            if ((bits & (bits - 1)) == 0) {
                places[count++] = 64 * w + (uint32_t)__builtin_ctzll(bits);
                continue;
            }
            const uint64_t after = bits & (bits-1);
            if ((after & (after-1)) == 0) {
                const uint32_t first = 64*w + (uint32_t)__builtin_ctzll(bits);
                const uint32_t last = 64*w + (uint32_t)__builtin_ctzll(after);
                const uint64_t both = ((uint64_t)last<<32) | first;
                __builtin_memcpy(places+count,&both,sizeof(both));
                count+=2;
                continue;
            }
            const uint32_t here = (uint32_t)__builtin_popcountll(bits);
            __m512i set = _mm512_maskz_compress_epi8(bits, positions);
            const __m512i base = _mm512_set1_epi32((int)(64 * w));
            const __m512i first = _mm512_cvtepu8_epi32(_mm512_castsi512_si128(set));
            exact_places(places + count, here, _mm512_add_epi32(base, first));
            if (BUSTER_UNLIKELY(here > 16))
            {
                for (uint32_t offset = 16; offset < here; offset += 16)
                {
                    set = _mm512_shuffle_i32x4(set, set, _MM_SHUFFLE(0, 3, 2, 1));
                    const __m512i next = _mm512_cvtepu8_epi32(_mm512_castsi512_si128(set));
                    const __mmask16 valid = (__mmask16)_bzhi_u32(0xFFFF, here - offset);
                    exact_places(places + count + offset, here - offset, _mm512_add_epi32(base, next));
                }
            }
            count += here;
    }
    return count;
}
uint32_t doublebit(const uint8_t* kinds, uint32_t n, uint64_t* lines, uint64_t* marks, uint32_t* hashes)
{if(n==0)return 0;volatile uint32_t count=pp_scan_directives_window(kinds,0,n,lines,marks);if (!count) return 0;return pp_directive_places(marks,(uint32_t)(((uint64_t)n+63)/64),hashes);}
