from pathlib import Path
p=Path("src/buster/compiler/c_preprocessor.c");s=p.read_text()
setup='#include <sys/mman.h>\n#include <fcntl.h>\n#include <unistd.h>\nstatic uint64_t* directive_counts;\n__attribute__((constructor)) static void pp_census_attach(void)\n{\n    const char* path = getenv("BUSTER_DIRECTIVE_COUNTS");\n    if (path != NULL)\n    {\n        const int fd = open(path, O_RDWR | O_CLOEXEC);\n        if (fd >= 0)\n        {\n            void* ptr = mmap(NULL, 64, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);\n            if (ptr != MAP_FAILED) directive_counts = ptr;\n            close(fd);\n        }\n    }\n}\n'
i=s.index("static bool pp_directive_table(Arena")
s=s[:i]+setup+s[i:]
for mode,fn in enumerate(("pp_directive_table", "pp_directive_table_windowed")):
 i=s.index("static bool "+fn+"(Arena");a=s.index("\n{",i)+2;b=s.index("    return result;",a)
 s=s[:b]+f"""    if (directive_counts != NULL && result)
    {{
        __atomic_fetch_add(directive_counts + {4*mode}, 1, __ATOMIC_RELAXED);
        __atomic_fetch_add(directive_counts + {4*mode+1}, data->token_count, __ATOMIC_RELAXED);
        __atomic_fetch_add(directive_counts + {4*mode+2}, data->directive_count, __ATOMIC_RELAXED);
        __atomic_fetch_add(directive_counts + {4*mode+3}, data->token_count < 64, __ATOMIC_RELAXED);
    }}
"""+s[b:]
p.write_text(s)
