#include <immintrin.h>
#include <stdint.h>
#define BUSTER_C_TOKEN_START_OF_LINE 128
#define C_TOKEN_HASH 60
#define BUSTER_UNLIKELY(x) __builtin_expect(!!(x),0)
static uint32_t pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    for (uint64_t i = begin; i < end; i += 64)
    {
        const __mmask64 valid = end - i >= 64 ? ~0ull : _bzhi_u64(~0ull, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_mask_cmpeq_epi8_mask(valid, block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block) & valid;
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}
static uint32_t pp_directive_places(const uint64_t* words, uint32_t word_count, uint32_t* places)
{
    const __m512i positions = _mm512_set_epi8(63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37,
                                              36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9,
                                              8, 7, 6, 5, 4, 3, 2, 1, 0);
    uint32_t count = 0;
    for (uint32_t w=0;w<word_count;++w) {
            const uint64_t bits=words[w];
            if (bits == 0) continue;
            if ((bits & (bits - 1)) == 0) {
                places[count++] = 64 * w + (uint32_t)__builtin_ctzll(bits);
                continue;
            }
            const __m512i lane = _mm512_add_epi32(_mm512_set1_epi32(64*w),_mm512_setr_epi32(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15));
            for(unsigned off=0;off<64;off+=16) {
                const __mmask16 quarter=bits>>off;
                if(quarter) {
                    _mm512_mask_compressstoreu_epi32(places+count,quarter,_mm512_add_epi32(lane,_mm512_set1_epi32(off)));
                    count+=(uint32_t)__builtin_popcount(quarter);
                }
            }
    }
    return count;
}
uint32_t quarter(const uint8_t* kinds, uint32_t n, uint64_t* lines, uint64_t* marks, uint32_t* hashes)
{if(n==0)return 0;volatile uint32_t count=pp_scan_directives_window(kinds,0,n,lines,marks);if (!count) return 0;return pp_directive_places(marks,(uint32_t)(((uint64_t)n+63)/64),hashes);}
