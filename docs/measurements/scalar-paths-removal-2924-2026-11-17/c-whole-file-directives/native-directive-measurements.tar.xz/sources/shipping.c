#include <stdint.h>
#include <immintrin.h>
#define BUSTER_UNLIKELY(x) __builtin_expect(!!(x), 0)
uint32_t shipping(const uint64_t* words, uint32_t word_count, uint32_t* places)
{
    const __m512i positions = _mm512_set_epi8(63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37,
                                              36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9,
                                              8, 7, 6, 5, 4, 3, 2, 1, 0);
    uint32_t count = 0;
    for (uint32_t group = 0; group < word_count; group += 8)
    {
        const uint32_t size = word_count - group < 8 ? word_count - group : 8;
        const __m512i eight = size == 8 ? _mm512_loadu_si512(words + group) : _mm512_maskz_loadu_epi64((__mmask8)_bzhi_u32(0xFF, size), words + group);
        if (_mm512_test_epi64_mask(eight, eight) == 0)
        {
            continue;
        }
        #pragma clang loop unroll_count(8)
        for (uint32_t lane = 0; lane < size; lane += 1)
        {
            const uint32_t w = group + lane;
            const uint64_t bits = words[w];
            const uint32_t here = (uint32_t)__builtin_popcountll(bits);
            __m512i set = _mm512_maskz_compress_epi8(bits, positions);
            const __m512i base = _mm512_set1_epi32((int)(64 * w));
            const __m512i first = _mm512_cvtepu8_epi32(_mm512_castsi512_si128(set));
            _mm512_mask_storeu_epi32(places + count, (__mmask16)_bzhi_u32(0xFFFF, here), _mm512_add_epi32(base, first));
            if (BUSTER_UNLIKELY(here > 16))
            {
                for (uint32_t offset = 16; offset < here; offset += 16)
                {
                    set = _mm512_shuffle_i32x4(set, set, _MM_SHUFFLE(0, 3, 2, 1));
                    const __m512i next = _mm512_cvtepu8_epi32(_mm512_castsi512_si128(set));
                    const __mmask16 valid = (__mmask16)_bzhi_u32(0xFFFF, here - offset);
                    _mm512_mask_storeu_epi32(places + count + offset, valid, _mm512_add_epi32(base, next));
                }
            }
            count += here;
        }
    }
    return count;
}

