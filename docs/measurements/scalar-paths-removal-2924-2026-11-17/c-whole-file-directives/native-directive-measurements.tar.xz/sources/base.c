#include <immintrin.h>
#include <stdint.h>
#define BUSTER_C_TOKEN_START_OF_LINE 128
#define C_TOKEN_HASH 60
#define BUSTER_UNLIKELY(x) __builtin_expect(!!(x),0)
static uint32_t pp_scan_directives_vector(const uint8_t* kinds, uint32_t count, uint32_t* hashes, uint64_t* lines)
{
    uint32_t result = 0;
    for (uint32_t i = 0; i < count; i += 64)
    {
        const __mmask64 valid = count - i >= 64 ? ~0ull : _bzhi_u64(~0ull, count - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        lines[i / 64] = _mm512_movepi8_mask(block) & valid;
        uint64_t directives = _mm512_mask_cmpeq_epi8_mask(valid, block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        if (hashes != 0)
        {
            for (; directives != 0; directives &= directives - 1)
            {
                hashes[result] = i + (uint32_t)__builtin_ctzll(directives);
                result += 1;
            }
        }
        else
        {
            result += (uint32_t)__builtin_popcountll(directives);
        }
    }
    return result;
}

uint32_t original(const uint8_t* kinds, uint32_t n, uint64_t* lines, uint64_t* marks, uint32_t* hashes)
{ volatile uint32_t count=pp_scan_directives_vector(kinds,n,0,lines);(void)count;return pp_scan_directives_vector(kinds,n,hashes,lines);}
