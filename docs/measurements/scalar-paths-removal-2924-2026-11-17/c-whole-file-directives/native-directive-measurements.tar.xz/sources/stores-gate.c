#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
typedef uint32_t Scan(const uint8_t*,uint32_t,uint64_t*,uint64_t*,uint32_t*);
extern Scan original,dense,exact,quarter;
static Scan* volatile methods[]={original,dense,exact,quarter};
static uint32_t seed=1;
static uint32_t random32(void){seed=seed*1664525+1013904223;return seed;}
static uint64_t ticks(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int cmp(const void*a,const void*b){uint64_t x=*(const uint64_t*)a,y=*(const uint64_t*)b;return (x>y)-(x<y);}
typedef struct { unsigned char* pages; size_t room,page; } Buffer;
static Buffer guarded(size_t size){size_t page=(size_t)sysconf(_SC_PAGESIZE),room=(size+page-1)/page*page;unsigned char* p=mmap(NULL,room+2*page,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(p==MAP_FAILED || mprotect(p+page,room,PROT_READ|PROT_WRITE))abort();return (Buffer){p+page,room,page};}
static void* edge(Buffer b,size_t bytes,unsigned end){return b.pages+(end?b.room-bytes:0);}
int main(int argc,char**argv){
 if(argc>1)seed=strtoul(argv[1],0,10);
 const unsigned largest=16384;Buffer in=guarded(largest),out=guarded(largest*4),lines=guarded(largest/8),masks=guarded(largest/8);
 uint64_t expected_lines[largest/64];uint32_t expected_hits[largest];unsigned sizes[200],ns=0;
 for(unsigned i=0;i<=130;i++)sizes[ns++]=i;
 unsigned more[]={191,192,193,255,256,257,383,384,385,511,512,513,767,768,769,1023,1024,1025,2047,2048,2049,4095,4096,4097,8191,8192,8193,16384};
 for(unsigned i=0;i<sizeof(more)/sizeof(*more);i++)sizes[ns++]=more[i];
 for(unsigned si=0;si<ns;si++)for(unsigned shape=0;shape<7;shape++)for(unsigned side=0;side<2;side++){
  unsigned n=sizes[si],words=(n+63)/64,found=0;uint8_t* kinds=edge(in,n,side); memset(expected_lines,0,words*8);
  for(unsigned i=0;i<n;i++){
   uint32_t r=random32();
   unsigned hit=shape==1?i==0:shape==2?i+1==n:shape==3?!(i%31):shape==4?!(i%7):shape==5?!(i%2):shape==6;
   uint8_t kind=(uint8_t)(hit?HASH_ID|128:(r&1?HASH_ID:1+(r%19)) | ((r&6)==4&&!(r&1)?128:0));
   kinds[i]=kind;if(kind&128)expected_lines[i/64]|=UINT64_C(1)<<(i%64);
   if(kind==(HASH_ID|128))expected_hits[found++]=i;
  }
  uint32_t* places=edge(out,found*4,side);uint64_t* bits=edge(lines,words*8,side),*marks=edge(masks,words*8,side);
  for(unsigned m=0;m<4;m++){
   memset(places,0x55,found*4);memset(bits,0x55,words*8);
   uint32_t got=methods[m](kinds,n,bits,marks,places);
   if(got!=found||memcmp(bits,expected_lines,words*8)||memcmp(places,expected_hits,found*4))return fprintf(stderr,"mismatch %u %u %u %u\n",n,shape,side,m),1;
  }
  uint64_t times[4][9];unsigned reps=2048/(1+n/20)+16;
  for(unsigned k=0;k<9;k++){unsigned start=random32()>>30;for(unsigned jj=0;jj<4;jj++){unsigned m=(start+((k&1)?3*jj:jj))%4;Scan* fn=methods[m];uint64_t t=ticks();for(unsigned i=0;i<reps;i++)fn(kinds,n,bits,marks,places);times[m][k]=ticks()-t;}}
  printf("%u %u %u %u",n,shape,side,reps);for(unsigned m=0;m<4;m++){qsort(times[m],9,8,cmp);printf(" %lu",times[m][4]);}puts("");
 }
 fprintf(stderr,"checked %u widths, seven directive shapes, two page placements\n",ns);
}
