#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
typedef uint32_t Fn(const uint64_t*,uint32_t,uint32_t*);
extern Fn shipping,stream,cluster,grouped;
static Fn* volatile methods[]={shipping,stream,cluster,grouped};
static unsigned seed=3;
static unsigned random32(void){seed=1664525*seed+1013904223;return seed;}
static uint64_t ticks(void){_mm_lfence();uint64_t x=__rdtsc();_mm_lfence();return x;}
static int cmp(const void*x,const void*y){uint64_t a=*(uint64_t*)x,b=*(uint64_t*)y;return(a>b)-(a<b);}
static char* guard(size_t n){char*p=mmap(NULL,n+8192,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(p==MAP_FAILED||mprotect(p+4096,n,PROT_READ|PROT_WRITE))abort();return p+4096;}
int main(int argc,char**argv){
 if(argc>1)seed=atoi(argv[1]);
 const unsigned largest=4096;size_t wbytes=8*largest,obytes=256*largest;char*in=guard(wbytes),*out=guard(obytes);uint32_t* expected=malloc(obytes);
 unsigned widths[80],ns=0;for(unsigned i=0;i<=33;i++)widths[ns++]=i;
 unsigned more[]={47,48,49,63,64,65,127,128,129,255,256,257,511,512,513,1023,1024,1025,2047,2048,2049,4095,4096};
 for(unsigned i=0;i<sizeof(more)/sizeof(*more);i++)widths[ns++]=more[i];
 for(unsigned si=0;si<ns;si++)for(unsigned shape=0;shape<=67;shape++)for(unsigned side=0;side<2;side++){
  unsigned n=widths[si],count=0;uint64_t* w=(uint64_t*)(in+(side?wbytes-8*n:0));
  for(unsigned i=0;i<n;i++){
   unsigned bits=shape<=64?shape:shape==65?(i%13==0?1:0):shape==66?(i%11==4?32:0):random32()%65;
   uint64_t mask=0;for(unsigned k=64-bits;k<64;k++){unsigned v=(random32()>>8)%(k+1);mask|=UINT64_C(1)<<((mask>>v)&1?k:v);}
   w[i]=mask;while(mask){expected[count++]=64*i+__builtin_ctzll(mask);mask&=mask-1;}
  }
  uint32_t* dst=(uint32_t*)(out+(side?obytes-count*4:0));
  uint64_t times[4][7];unsigned reps=1024/(1+n)+2;
  for(unsigned j=0;j<4;j++){memset(dst,0xa5,4*count);if(methods[j](w,n,dst)!=count||memcmp(dst,expected,4*count))return fprintf(stderr,"failed %u %u %u %u\n",n,shape,side,j),1;}
  for(unsigned k=0;k<7;k++){unsigned first=random32()>>30;for(unsigned z=0;z<4;z++){unsigned j=(first+(k%2?3*z:z))%4;Fn*f=methods[j];uint64_t t=ticks();for(unsigned m=0;m<reps;m++)f(w,n,dst);times[j][k]=ticks()-t;}}
  printf("%u %u %u %u",n,shape,side,reps);for(unsigned j=0;j<4;j++){qsort(times[j],7,8,cmp);printf(" %lu",times[j][3]);}puts("");
 }
 fprintf(stderr,"verified %u word counts, 68 distributions and two guard placements\n",ns);
}
