#include <immintrin.h>
#include <stdint.h>
#include <string.h>
#define BUSTER_UNLIKELY(x) __builtin_expect(!!(x),0)
static inline void pp_store_directive_ranks(uint32_t* output, uint32_t count, __m512i ranks)
{
    if (count >= 16)
    {
        _mm512_storeu_si512(output, ranks);
        return;
    }
    if (count >= 8)
    {
        _mm256_storeu_si256((__m256i*)output, _mm512_castsi512_si256(ranks));
        output += 8;
        ranks = _mm512_shuffle_i32x4(ranks, ranks, _MM_SHUFFLE(3, 2, 3, 2));
    }
    __m256i eight = _mm512_castsi512_si256(ranks);
    if ((count & 4) != 0)
    {
        _mm_storeu_si128((__m128i*)output, _mm256_castsi256_si128(eight));
        output += 4;
        eight = _mm256_permute2x128_si256(eight, eight, 1);
    }
    __m128i four = _mm256_castsi256_si128(eight);
    if ((count & 2) != 0)
    {
        _mm_storel_epi64((__m128i*)output, four);
        output += 2;
        four = _mm_srli_si128(four, 8);
    }
    if ((count & 1) != 0)
    {
        *output = (uint32_t)_mm_cvtsi128_si32(four);
    }
}

// Collect positions in order from the same masks for windowed and whole-file preparation.
uint32_t grouped(const uint64_t* words, uint32_t word_count, uint32_t* places)
{
    const __m512i positions = _mm512_set_epi8(63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37,
                                              36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9,
                                              8, 7, 6, 5, 4, 3, 2, 1, 0);
    uint32_t count = 0;
    for (uint32_t group = 0; group < word_count; group += 8)
    {
        const uint32_t size = word_count - group < 8 ? word_count - group : 8;
        const __m512i eight = size == 8 ? _mm512_loadu_si512(words + group) : _mm512_maskz_loadu_epi64((__mmask8)_bzhi_u32(0xFF, size), words + group);
        uint32_t remaining = _mm512_test_epi64_mask(eight, eight);
        while (remaining != 0)
        {
            const uint32_t w = group + (uint32_t)__builtin_ctz(remaining);
            remaining &= remaining - 1;
            const uint64_t bits = words[w];
            const uint32_t start = 64 * w;
            const uint64_t after = bits & (bits - 1);
            if (after == 0)
            {
                places[count++] = start + (uint32_t)__builtin_ctzll(bits);
                continue;
            }
            if ((after & (after - 1)) == 0)
            {
                const uint32_t first = start + (uint32_t)__builtin_ctzll(bits);
                const uint32_t last = start + (uint32_t)__builtin_ctzll(after);
                const uint64_t both = ((uint64_t)last << 32) | first;
                memcpy(places + count, &both, sizeof(both));
                count += 2;
                continue;
            }
            const uint32_t here = (uint32_t)__builtin_popcountll(bits);
            __m512i ranks = _mm512_maskz_compress_epi8(bits, positions);
            const __m512i base = _mm512_set1_epi32((int)start);
            for (uint32_t offset = 0; offset < here; offset += 16)
            {
                const __m512i indices = _mm512_cvtepu8_epi32(_mm512_castsi512_si128(ranks));
                pp_store_directive_ranks(places + count + offset, here - offset, _mm512_add_epi32(base, indices));
                ranks = _mm512_shuffle_i32x4(ranks, ranks, _MM_SHUFFLE(0, 3, 2, 1));
            }
            count += here;
        }
    }
    return count;
}

