from pathlib import Path
p=Path(__file__).parent;base=(p/'bounded.inc').read_text()
nextline='''static uint32_t NAME_next_line(const uint64_t* lines, uint32_t count, uint32_t after)
{
    const uint32_t current = after / 64;
    const uint32_t words = (uint32_t)(((uint64_t)count + 63) / 64);
    // The top token may be UINT32_MAX-1. Mask the bits after it inside the existing word.
    const uint64_t rest = lines[current] & ~_bzhi_u64(UINT64_MAX, (after & 63u) + 1u);
    if (rest != 0)
    {
        const uint32_t found = current * 64u + (uint32_t)__builtin_ctzll(rest);
        return found < count ? found : count;
    }
    for (uint32_t first = current + 1; first < words; first += 8)
    {
        const uint32_t remaining = words - first;
        const __mmask8 active = remaining >= 8 ? UINT8_MAX : (__mmask8)((1u << remaining) - 1);
        const __m512i bits = _mm512_maskz_loadu_epi64(active, lines + first);
        const uint32_t nonempty = _mm512_test_epi64_mask(bits, bits);
        if (nonempty != 0)
        {
            const uint32_t word = first + (uint32_t)__builtin_ctz(nonempty);
            const uint32_t found = word * 64u + (uint32_t)__builtin_ctzll(lines[word]);
            return found < count ? found : count;
        }
    }
    return count;
}
'''
scan='''static uint32_t NAME_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t count = 0;
    uint64_t i = begin;
    const __m512i hash = _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE));
    for (; i + 64 <= end; i += 64)
    {
        const __m512i data = _mm512_loadu_si512(kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    if (i < end)
    {
        const __mmask64 active = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i data = _mm512_maskz_loadu_epi8(active, kinds + i);
        const uint64_t matches = _mm512_cmpeq_epi8_mask(data, hash);
        lines[i / 64] = _mm512_movepi8_mask(data);
        directives[i / 64] = matches;
        count += (uint32_t)__builtin_popcountll(matches);
    }
    return count;
}
'''
for name in ['groupseek','fullwords','bothwords']:
 s=base.replace('bounded','NAME')
 if name!='fullwords':s=nextline+s[s.index('static bool NAME_pp_finish'):];
 if name!='groupseek':
  a=s.index('static uint32_t NAME_pp_scan');b=s.index('static bool NAME_pp_publish',a);s=s[:a]+scan+'\n'+s[b:]
 (p/(name+'.inc')).write_text(s.replace('NAME',name))
s=(p/'paired-lines-gate.c').read_text().replace('pairedwords','groupseek').replace('singlemarks','fullwords').replace('bitwalk','bothwords')
(p/'word-search-gate.c').write_text(s)
(p/'word-search-task').write_text((p/'paired-lines-task').read_text().replace('paired-lines','word-search').replace('directive ends computed by consecutive line-start ranks','word-level successor queries and full token blocks'))
