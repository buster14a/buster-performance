from pathlib import Path
p=Path(__file__).parent
s=(p/'bounded.inc').read_text()
s=s[s.index('static bool bounded_pp_finish_directives'):]
s=s.replace('const uint32_t end = bounded_next_line(lines, data->token_count, hash);','const uint32_t end = data->directive_end[d];').replace('        data->directive_end[d] = end;\n','')
assert 'bounded_next_line(' not in s
for name in ['during','after','sparseranks']:
 t=s;a=t.index('static uint32_t bounded_pp_scan_directives_window')
 endbits='''static uint64_t bounded_line_ends(uint64_t starts, uint64_t directives, uint64_t* previous)
{
    const uint64_t ranked = _pext_u64(directives, starts);
    const uint64_t ends = _pdep_u64((ranked << 1) | *previous, starts);
    if (starts != 0) *previous = directives > (starts ^ directives);
    return ends;
}
'''
 if name=='sparseranks':
  endbits=endbits.replace('    const uint64_t ranked', '''    if (directives == 0)
    {
        const uint64_t value = *previous ? starts & (0 - starts) : 0;
        if (starts != 0) *previous = 0;
        return value;
    }
    const uint64_t ranked''')
 t=t[:a]+endbits+t[a:]
 t=t.replace('const uint64_t* lines, const uint64_t* directives, uint32_t count)','uint64_t* lines, const uint64_t* directives, uint32_t count)')
 t=t.replace('        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);','''        const uint32_t words = (uint32_t)(((uint64_t)data->token_count + 63) / 64);
        pp_directive_places(directives, words, data->directive_hash);
        ENDMASKS
        const uint32_t ends = pp_directive_places(lines, words, data->directive_end);
        if (ends < count) data->directive_end[ends] = data->token_count;''')
 if name=='after':
  t=t.replace('ENDMASKS','''uint64_t previous = 0;
        for (uint32_t w = 0; w < words; w += 1)
            lines[w] = bounded_line_ends(lines[w], directives[w], &previous);''')
 else:
  t=t.replace('        ENDMASKS\n','').replace('uint64_t* lines, uint64_t* directives)\n{','uint64_t* lines, uint64_t* directives, uint64_t* previous)\n{')
  t=t.replace('lines[i / 64] = _mm512_movepi8_mask(block) & valid;','lines[i / 64] = bounded_line_ends(_mm512_movepi8_mask(block) & valid, word, previous);')
  t=t.replace('        const uint32_t count = bounded_pp_scan_directives_window','        uint64_t previous = 0;\n        const uint32_t count = bounded_pp_scan_directives_window').replace('data->token_count, lines, directives);','data->token_count, lines, directives, &previous);')
 (p/(name+'.inc')).write_text(t.replace('bounded_',name+'_'))
g=(p/'bounded-gate.c').read_text().replace('#include "retained.inc"\n#include "interleave.inc"','#include "during.inc"\n#include "after.inc"\n#include "sparseranks.inc"').replace('retained_pp_directive_table,interleave_pp_directive_table,bounded_pp_directive_table','bounded_pp_directive_table,during_pp_directive_table,after_pp_directive_table,sparseranks_pp_directive_table').replace('arena_reserve(1ull<<27)};','arena_reserve(1ull<<27),arena_reserve(1ull<<27)};').replace('data[4]={in,in,in,in}','data[5]={in,in,in,in,in}').replace('j<4','j<5').replace('rounds[4]','rounds[5]').replace('z<4','z<5').replace('(k%2?3*z:z))%4','(k%2?4*z:z))%5').replace('side=step()>>30','side=step()%5').replace('||!equivalent(data,data+3))','||!equivalent(data,data+3)||!equivalent(data,data+4))')
g=g.replace('shape<9','shape<14').replace('   if(hash)last=i;', '''   if(shape>=9)
   {
      const uint32_t h=i*2654435761u+(i>>3)*139u;
      const bool line=shape==9?i%5==0:shape==10?i%113==0:shape==11?i%521==0:shape==12?((h>>26)&3)!=0:i%11==3||i%191==2;
      hash=line && (shape==10?(i/113)%13==0:shape==11?(i/521)%3!=0:((h>>15)&3)==0);
      kinds[i]=hash?(C_TOKEN_HASH|128):(C_TOKEN_RAW_IDENTIFIER | (line?128:0));
   }
   if(hash)last=i;''').replace('nine distributions','fourteen distributions')
(p/'line-ranks-gate.c').write_text(g)
(p/'line-ranks-task').write_text((p/'bounded-task').read_text().replace('bounded','line-ranks').replace('Compare grouped directive line ends and interleaved table storage','Compare directive ends computed by consecutive line-start ranks across 14 distributions'))
