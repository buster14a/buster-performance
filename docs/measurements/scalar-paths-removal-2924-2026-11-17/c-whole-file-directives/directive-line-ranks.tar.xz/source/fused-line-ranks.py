from pathlib import Path
p=Path(__file__).parent
s=(p/'after.inc').read_text()
for n in ['pairedwords','singlemarks','bitwalk']:
 t=s;a=t.index('static uint64_t after_line_ends(');b=t.index('static uint32_t after_pp_scan_directives_window',a);t=t[:a]+t[b:]
 a=t.index('static bool after_pp_publish_directives(')
 h='''static inline uint32_t after_positions(uint32_t word, uint64_t bits, uint32_t* out)
{
    const uint32_t count = (uint32_t)__builtin_popcountll(bits);
    SINGLE
    const __m512i positions = _mm512_setr_epi32(0x03020100,0x07060504,0x0b0a0908,0x0f0e0d0c,0x13121110,0x17161514,0x1b1a1918,0x1f1e1d1c,
                                                0x23222120,0x27262524,0x2b2a2928,0x2f2e2d2c,0x33323130,0x37363534,0x3b3a3938,0x3f3e3d3c);
    const __m512i base = _mm512_set1_epi32((int)(word*64));
    __m512i set = _mm512_maskz_compress_epi8(bits,positions);
    for (uint32_t offset=0;offset<count;offset+=16)
    {
        const __mmask16 live=(__mmask16)_bzhi_u32(UINT16_MAX,count-offset);
        _mm512_mask_storeu_epi32(out+offset,live,_mm512_add_epi32(base,_mm512_cvtepu8_epi32(_mm512_castsi512_si128(set))));
        set=_mm512_shuffle_i32x4(set,set,_MM_SHUFFLE(0,3,2,1));
    }
    return count;
}
static void after_expand(const uint64_t* lines,const uint64_t* hashes,uint32_t words,uint32_t tokens,PPFileData* data)
{
    uint32_t begins=0,ends=0;
    uint64_t previous=0;
    for (uint32_t first=0;first<words;first+=8)
    {
        const __mmask8 valid=(__mmask8)_bzhi_u32(255,words-first<8?words-first:8);
        const __m512i group=_mm512_maskz_loadu_epi64(valid,hashes+first);
        uint32_t marked=_mm512_test_epi64_mask(group,group);
        if (marked==0 && !previous)continue;
        const __m512i sol=_mm512_maskz_loadu_epi64(valid,lines+first);
        uint32_t available=_mm512_test_epi64_mask(sol,sol);
        while(marked || (previous && available))
        {
            const unsigned lane=(unsigned)__builtin_ctz(previous?available:marked);
            const uint32_t w=first+lane;
            const uint64_t ls=lines[w],hs=hashes[w];
            const uint64_t local=_pdep_u64(_pext_u64(hs,ls)<<1,ls);
            const uint64_t done=local | ((0-previous) & (ls & -ls));
            begins+=after_positions(w,hs,data->directive_hash+begins);
            ends+=after_positions(w,done,data->directive_end+ends);
            previous=hs>(ls^hs);
            const uint32_t rest=(UINT32_MAX<<1)<<lane;
            available&=rest;marked&=rest;
        }
    }
    if(previous)data->directive_end[ends]=tokens;
}
'''
 if n=='singlemarks':h=h.replace('SINGLE','if (count <= 1) { if (bits) out[0]=word*64+(uint32_t)__builtin_ctzll(bits); return count; }')
 else:h=h.replace('SINGLE','')
 if n=='bitwalk':
  a1=h.index('    const __m512i positions');b1=h.index('    return count;',a1)
  h=h[:a1]+'''    while (bits != 0)
    {
        *out++ = 64*word+(uint32_t)__builtin_ctzll(bits);
        bits &= bits-1;
    }
'''+h[b1:]
 t=t[:a]+h+t[a:];a=t.index('        pp_directive_places(directives, words, data->directive_hash);');b=t.index('\n    }',a);t=t[:a]+'        after_expand(lines,directives,words,data->token_count,data);'+t[b:]
 (p/(n+'.inc')).write_text(t.replace('after_',n+'_'))
g=(p/'line-ranks-gate.c').read_text()
for a,b in [('during','pairedwords'),('after','singlemarks'),('sparseranks','bitwalk')]:g=g.replace(a,b)
(p/'paired-lines-gate.c').write_text(g)
(p/'paired-lines-task').write_text((p/'line-ranks-task').read_text().replace('line-ranks','paired-lines'))
