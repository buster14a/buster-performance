#include "buster/compiler/c_preprocessor_benchmark.c"
#include "pairedwords.inc"
#include "singlemarks.inc"
#include "bitwalk.inc"
#include "bounded.inc"
typedef bool TableFn(Arena*,PPFileData*);
static TableFn* volatile methods[]={pp_directive_table,bounded_pp_directive_table,pairedwords_pp_directive_table,singlemarks_pp_directive_table,bitwalk_pp_directive_table};
static uint32_t state=1;
static uint32_t step(void){state=state*1664525+1013904223;return state;}
static uint64_t counter(void){_mm_lfence();uint64_t x=__rdtsc();_mm_lfence();return x;}
static int cmp_u64(const void*x,const void*y){uint64_t a=*(uint64_t*)x,b=*(uint64_t*)y;return(a>b)-(a<b);}
static int equivalent(const PPFileData*a,const PPFileData*b){
 uint32_t n=a->directive_count,m=a->note_count;
 return n==b->directive_count&&m==b->note_count&&a->guard==b->guard&&a->guard_opener==b->guard_opener&&
 !memcmp(a->directive_hash,b->directive_hash,4*n)&&!memcmp(a->directive_end,b->directive_end,4*n)&&
 !memcmp(a->directive_kind,b->directive_kind,n)&&!memcmp(a->directive_next,b->directive_next,4*n)&&
 (!m||(!memcmp(a->note_directives,b->note_directives,4*m)&&!memcmp(a->note_kinds,b->note_kinds,m)));
}
int main(int argc,char**argv){
 if(argc>1)state=atoi(argv[1]);Arena stores[]={arena_reserve(1ull<<27),arena_reserve(1ull<<27),arena_reserve(1ull<<27),arena_reserve(1ull<<27),arena_reserve(1ull<<27)};
 unsigned widths[200],ns=0,largest=16384;for(unsigned i=0;i<=130;i++)widths[ns++]=i;
 unsigned more[]={191,192,193,255,256,257,383,384,385,511,512,513,767,768,769,1023,1024,1025,2047,2048,2049,4095,4096,4097,8191,8192,8193,16384};
 for(unsigned i=0;i<sizeof(more)/sizeof(*more);i++)widths[ns++]=more[i];
 uint8_t* bytes=calloc(largest+64,1),*kinds=calloc(largest+64,1);uint32_t* values=calloc(largest+64,4),*starts=calloc(largest+64,4);
 for(unsigned i=0;i<largest;i++){starts[i]=i;bytes[i]='x';}
 for(unsigned si=0;si<ns;si++)for(unsigned shape=0;shape<14;shape++){
  uint32_t n=widths[si],last=UINT32_MAX;for(unsigned i=0;i<n;i++){
   bool hash=shape==1?i==0:shape==2?i+1==n:shape==3?i%31==0:shape==4?i%7==0:shape==5?i%2==0:shape==6?true:shape>=7?i%5==0:false;
   kinds[i]=hash?C_TOKEN_HASH|128:C_TOKEN_RAW_IDENTIFIER;values[i]=C_NAME_IF;
   if(shape>=9)
   {
      const uint32_t h=i*2654435761u+(i>>3)*139u;
      const bool line=shape==9?i%5==0:shape==10?i%113==0:shape==11?i%521==0:shape==12?((h>>26)&3)!=0:i%11==3||i%191==2;
      hash=line && (shape==10?(i/113)%13==0:shape==11?(i/521)%3!=0:((h>>15)&3)==0);
      kinds[i]=hash?(C_TOKEN_HASH|128):(C_TOKEN_RAW_IDENTIFIER | (line?128:0));
   }
   if(hash)last=i;else if(last!=UINT32_MAX && i-last==1){
    values[i]=shape<7?C_NAME_DEFINE:shape==7?(last%10==0?C_NAME_IF:C_NAME_ENDIF):((last/5)%3==0?C_NAME_ELSE:(last/5)%3==1?C_NAME_ELIFDEF:C_NAME_IF);
   }
  }
  const PPFileData in={.bytes=bytes,.length=n,.kinds=kinds,.starts=starts,.values=values,.token_count=n};PPFileData data[5]={in,in,in,in,in};
  for(unsigned j=0;j<5;j++){stores[j].length=0;if(!methods[j](stores+j,data+j))return 2;}
  if(!equivalent(data,data+1)||!equivalent(data,data+2)||!equivalent(data,data+3)||!equivalent(data,data+4))return fprintf(stderr,"mismatch %u %u\n",n,shape),1;
  unsigned reps=1024/(1+n/16)+4;uint64_t rounds[5][9];
  for(unsigned k=0;k<9;k++){unsigned side=step()%5;for(unsigned z=0;z<5;z++){
   unsigned j=(side+(k%2?4*z:z))%5;TableFn*f=methods[j];uint64_t t=counter();
   for(unsigned m=0;m<reps;m++){stores[j].length=0;if(!f(stores+j,data+j))return 3;}
   rounds[j][k]=counter()-t;
  }}
  printf("%u %u %u",n,shape,reps);for(unsigned j=0;j<5;j++){qsort(rounds[j],9,8,cmp_u64);printf(" %lu",rounds[j][4]);}puts("");
 }
 fprintf(stderr,"compared every directive position, kind, end, link, note and include guard at %u widths and fourteen distributions\n",ns);
}
