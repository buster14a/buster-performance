from pathlib import Path
from collections import defaultdict
from statistics import median
import tarfile
p=Path(__file__).parent;r=p/'results';out=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/c-whole-file-directives')
def record(tags,header,intro,archive):
 table=[];worst=[]
 for prefix,names in tags:
  ratios=defaultdict(list)
  for seed in (1,133,789):
   assert '159 widths and fourteen distributions' in (r/f'{prefix}-{seed}.log').read_text()
   lines=(r/f'{prefix}-{seed}.tsv').read_text().splitlines();assert len(lines)==2226
   for line in lines:
    n,g,rep,base,*values=map(int,line.split())
    assert rep>0 and len(values)==4 and min(base,*values)>0
    for j,v in enumerate(values):ratios[j,n,g].append(v/base)
  for j,name in enumerate(names):
   d={(n,g):median(v)for (method,n,g),v in ratios.items() if method==j}
   assert len(d)==2226
   old=[v for (n,g),v in d.items()if g<9];new=[v for (n,g),v in d.items()if g>=9]
   table.append(f'| {name} | {sum(v<=1 for v in old):,}/1,431 | {sum(v<=1 for v in new)}/795 | {sum(v<=1 for v in d.values()):,}/2,226 | {median(d.values()):.4f} | {max(d.values()):.4f} |')
   if j==0:worst.extend((prefix,n,g,v)for (n,g),v in d.items()if v>1)
 title='## '+header
 lines=[title,'',intro,'','Fourteen token distributions span 159 lengths, including zero, every packet boundary in the original matrix, and 16,384 tokens. Each candidate was checked at every cell against the parent for positions, ends, kinds, conditional links, notes and the include guard. Per-cell times are the median of three paired ratios from the locked Ryzen 7 9700X.','', '| Builder | Original distributions | Five mixed line-start distributions | All | Median ratio | Slowest ratio |','| --- | ---: | ---: | ---: | ---: | ---: |',*table,'']
 if worst:lines+=['The current PR builder exceeded scalar in the following expanded-harness cells. Shape 11 places a line start every 521 tokens and marks two of each three starts as directives. Shape 12 takes three out of four pseudorandom line-start values.','',*['- '+f'{t}, {n:,} tokens, shape {g}, ratio {v:.4f}.' for t,n,g,v in worst],'']
 lines+=['[Source, commands, checks and every timing sample]('+archive+'.tar.xz)','']
 path=out/'README.md';s=path.read_text();assert title not in s
 path.write_text(s.rstrip()+'\n\n'+'\n'.join(lines))
 with tarfile.open(out/(archive+'.tar.xz'),'w:xz',preset=3)as t:
  for n in ['bounded.inc','rank-ends.py','fused-line-ranks.py','successor-words.py','record-line-ranks.py','during.inc','after.inc','sparseranks.inc','pairedwords.inc','singlemarks.inc','bitwalk.inc','groupseek.inc','fullwords.inc','bothwords.inc','guardedseek.inc']:
   if (p/n).is_file():t.add(p/n,'source/'+n)
  for tag,_ in tags:
   for n in [tag+'-gate.c',tag+'-task']:t.add(p/n,'source/'+n)
   for n in sorted(r.glob(tag+'-*')):
    if n.suffix in ['.log','.tsv']:t.add(n,'native/'+n.name)
 print(*table,*worst,sep='\n')
if __name__=='__main__':
 import sys
 if 'guarded' in sys.argv:
  record([('guarded-search',['Current PR','Masked line-word successor','Full unmasked token blocks','Complete blocks and guarded successor'])],'Checking the exhausted line cursor','The complete-block scanner and the eight-word successor search were rerun with the successor returning immediately if its caller has reached the end. This preserves the original empty-input and out-of-range contract before the first bitmap read.','guarded-line-successors')
 elif 'words' in sys.argv:
  record([('word-search',['Current PR','Masked line-word successor','Full unmasked token blocks','Both changes'])],'Word-level successor queries and full token blocks','The line successor first examines the remaining bits of the current word, then searches eight line words together. The token scan compares full blocks without a tail mask and masks the final partial block.','line-word-successors')
 else:
  record([('line-ranks',['Current PR, rank experiment','Ends during scan','Ends after scan','Sparse line ranks']),('paired-lines',['Current PR, paired experiment','Paired words','One-bit fast path','Enumerated bits'])],'Directive ends from consecutive line ranks','The line-rank experiments derive each directive end by projecting marked hashes into ordered line-start bits, shifting by one and projecting back. An outstanding directive carries across empty bitmap words. The paired implementations materialize the position and end columns together.','directive-line-ranks')
