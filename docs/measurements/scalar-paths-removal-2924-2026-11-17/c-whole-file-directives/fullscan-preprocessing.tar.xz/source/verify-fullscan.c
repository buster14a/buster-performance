#include "buster/compiler/c_preprocessor_benchmark.c"
#include "fullscan.inc"
#include "fullscan-faults.inc"
typedef bool Method(Arena*,PPFileData*);
static Method* methods[]={ fullscan_pp_directive_table, FAULT_METHODS };
static const char* labels[]={ "production", FAULT_LABELS };
static bool check_table(Method*fn, unsigned n, unsigned shape)
{
    static uint8_t bytes[1026];
    const size_t page=(size_t)sysconf(_SC_PAGESIZE);
    uint8_t* map=mmap(NULL,2*page,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(map==MAP_FAILED || mprotect(map+page,page,PROT_NONE))return false;
    uint8_t* kinds=map+page-n;
    static uint32_t values[1026],starts[1026];
    memset(kinds,0,n); memset(values,0,4*n);for(unsigned i=0;i<n;i++)starts[i]=i;
    uint32_t pos[]={0,31,n>=2?n-2:0}, ends[]={15,pos[2],n},links[]={1,2,BUSTER_PP_NONE};
    uint32_t ids[]={C_NAME_IF,C_NAME_ELSE,C_NAME_ENDIF};uint8_t expected[]={PP_DIRECTIVE_IF,PP_DIRECTIVE_ELSE,PP_DIRECTIVE_ENDIF};
    unsigned count=n?3:0,guard=0,note_count=0,note_index=0,note_kind=0;
    if(n){
        if(shape==1){count=2;pos[1]=n-2;ids[0]=C_NAME_IFNDEF;ids[1]=C_NAME_ENDIF;expected[0]=PP_DIRECTIVE_IFNDEF;expected[1]=PP_DIRECTIVE_ENDIF;
            ends[0]=pos[1];ends[1]=n;links[1]=BUSTER_PP_NONE;guard=321;kinds[2]=C_TOKEN_RAW_IDENTIFIER;values[2]=guard;
            // The guard opener has exactly one operand. A non-directive line starts at its next token.
            kinds[3]=C_TOKEN_NUMERIC_CONSTANT|128;ends[0]=3;
        }else if(shape==2){ids[1]=C_NAME_ELIFDEF;expected[1]=PP_DIRECTIVE_ELIFDEF;note_count=1;note_index=1;note_kind=BUSTER_PP_NOTE_ELIFDEF;}
        else if(shape==3){for(unsigned j=0;j<3;j++){ids[j]=C_NAME_DEFINE;expected[j]=PP_DIRECTIVE_DEFINE;links[j]=BUSTER_PP_NONE;}}
        for(unsigned d=0;d<count;d++){kinds[pos[d]]=C_TOKEN_HASH|128;kinds[pos[d]+1]=C_TOKEN_RAW_IDENTIFIER;values[pos[d]+1]=ids[d];}
        if(shape!=1){kinds[15]=C_TOKEN_NUMERIC_CONSTANT|128;kinds[16]=C_TOKEN_HASH;}
    }
    Arena arena=arena_reserve(1<<20);
    PPFileData data={.kinds=kinds,.values=values,.starts=starts,.bytes=bytes,.length=n,.token_count=n};
    bool ok=arena.base && fn(&arena,&data) && data.directive_count==count && data.guard==guard && data.note_count==note_count;
    if(ok && guard)ok=data.guard_opener==0;
    if(ok && note_count)ok=data.note_directives[0]==note_index && data.note_kinds[0]==note_kind;
    for(unsigned i=0;ok && i<count;i++)ok=data.directive_hash[i]==pos[i] && data.directive_kind[i]==expected[i] && data.directive_end[i]==ends[i] && data.directive_next[i]==links[i];
    if(!ok)fprintf(stderr,"mismatch width=%u shape=%u count=%u guard=%u opener=%u notes=%u\n",n,shape,data.directive_count,data.guard,data.guard_opener,data.note_count);
    arena_release(&arena);munmap(map,2*page);return ok;
}
int main(int argc,char**argv){
    if(argc!=2)return 2;unsigned which=atoi(argv[1]);if(which>=BUSTER_ARRAY_LENGTH(methods))return 2;
    const unsigned widths[]={0,66,127,128,129,255,256,257,511,512,513,1024,1025};
    for(unsigned j=0;j<BUSTER_ARRAY_LENGTH(widths);j++)for(unsigned shape=0;shape<4;shape++)
        if(!check_table(methods[which],widths[j],shape))return fprintf(stderr,"%s failed invariant\n",labels[which]),1;
    fprintf(stderr,"%s passed 52 fixed table, link, inclusion guard and extension note fixtures\n",labels[which]);return 0;
}
