from pathlib import Path
p=Path(__file__).parent
v=(p/'fullscan.inc').read_text()
names=['line-bits','directive-bits','word-count','overlap','line-end','kind','link','notes','guard','early-sentinel','erase-last-word','whole-word-overlap','unmasked-tail']
changes=[
 ('lines[i / 64] = _mm512_movepi8_mask(block);','lines[i / 64] = word;'),
 ('directives[i / 64] = word;', 'directives[i / 64] = word & ~UINT64_C(1);'),
 ('((uint64_t)data->token_count + 63) / 64), data->directive_hash','((uint64_t)data->token_count) / 64), data->directive_hash'),
 ('columns + 2 * slots + kind_words : NULL','columns + slots : NULL'),
 ('data->directive_end[d] = end;', 'data->directive_end[d] = end - 1;'),
 ('data->directive_kind[d] = kind;', 'data->directive_kind[d] = PP_DIRECTIVE_NULL;'),
 ('if ((kinds_seen & conditional_kinds) == 0)', 'if (true)'),
 ('return result;\n}\n\nstatic bool fullscan_pp_directive_arrays','data->note_count = 0;\n    return result;\n}\n\nstatic bool fullscan_pp_directive_arrays'),
 ('result ? pp_find_guard(data, &data->guard_opener) : 0','0'),
 ('UINT64_C(1) << tail);','UINT64_C(1) << (tail == 0 ? 1 : tail - 1));'),
 ('(tail == 0 ? 0 : *last)', 'UINT64_C(0)'),
 ('directives = lines + words + 1;', 'directives = lines + words;'),
 ('_mm512_maskz_loadu_epi8(valid, kinds + i)', '_mm512_loadu_si512(kinds + i)')]
parts=[]; functions=[]
for n,(a,b) in enumerate(changes,1):
 assert a in v and v.count(a)==(2 if n in (1,2) else 1),a
 parts.append(v.replace(a,b).replace('fullscan_pp_',f'fs{n}_'));functions.append(f'fs{n}_directive_table')
(p/'fullscan-faults.inc').write_text('\n'.join(parts)+'\n#define FAULT_METHODS '+', '.join(functions)+'\n#define FAULT_LABELS '+', '.join('"'+x+'"' for x in names)+'\n')
s=(p/'verify-columns.c').read_text().replace('"interleave.inc"','"fullscan.inc"').replace('"table-faults.inc"','"fullscan-faults.inc"').replace('interleave_pp_directive_table','fullscan_pp_directive_table')
# Make a full-width load beyond a logical partial word fail deterministically.
s=s.replace('static uint8_t kinds[1026],bytes[1026];','static uint8_t bytes[1026];\n    const size_t page=(size_t)sysconf(_SC_PAGESIZE);\n    uint8_t* map=mmap(NULL,2*page,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);\n    if(map==MAP_FAILED || mprotect(map+page,page,PROT_NONE))return false;\n    uint8_t* kinds=map+page-n;')
s=s.replace('arena_release(&arena);return ok;', 'arena_release(&arena);munmap(map,2*page);return ok;')
(p/'verify-fullscan.c').write_text(s)
s=(p/'mutation-task').read_text().replace('verify-columns','verify-fullscan').replace('table-mutations','fullscan-mutations').replace('mutation-build','fullscan-mutation-build').replace('{0..9}','{0..13}').replace('ulimit -c 0','ulimit -c 0\nexport TMPDIR="$PWD/temp"').replace('"$lock" "./','"$lock" "./')
s=s.replace('"$lock" "$cc"','export TMPDIR="$PWD/temp"\n"$lock" "$cc"').replace('"$lock" ./verify-fullscan', '"$lock" timeout 50 ./verify-fullscan')
(p/'fullscan-mutation-task').write_text(s)
