static uint32_t fullscan_pp_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fullscan_pp_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fullscan_pp_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fullscan_pp_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fullscan_pp_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fullscan_pp_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fullscan_pp_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fullscan_pp_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fullscan_pp_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fullscan_pp_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fullscan_pp_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fullscan_pp_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}
