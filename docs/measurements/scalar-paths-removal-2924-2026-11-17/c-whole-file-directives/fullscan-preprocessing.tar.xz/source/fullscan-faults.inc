static uint32_t fs1_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs1_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs1_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs1_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs1_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = word;
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = word;
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs1_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs1_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs1_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs1_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs1_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs1_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs1_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs2_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs2_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs2_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs2_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs2_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word & ~UINT64_C(1);
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word & ~UINT64_C(1);
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs2_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs2_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs2_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs2_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs2_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs2_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs2_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs3_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs3_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs3_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs3_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs3_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs3_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs3_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count) / 64), data->directive_hash);
    }
    result = result && fs3_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs3_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs3_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs3_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs3_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs4_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs4_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs4_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs4_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + slots : NULL;
    return columns != NULL;
}

static uint32_t fs4_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs4_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs4_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs4_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs4_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs4_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs4_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs4_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs5_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs5_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs5_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end - 1;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs5_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs5_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs5_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs5_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs5_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs5_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs5_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs5_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs5_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs6_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs6_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs6_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = PP_DIRECTIVE_NULL;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs6_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs6_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs6_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs6_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs6_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs6_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs6_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs6_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs6_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs7_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs7_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs7_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if (true)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs7_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs7_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs7_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs7_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs7_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs7_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs7_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs7_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs7_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs8_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs8_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs8_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    data->note_count = 0;
    return result;
}

static bool fs8_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs8_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs8_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs8_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs8_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs8_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs8_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs8_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs8_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs9_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs9_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs9_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs9_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs9_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs9_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs9_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs9_finish_directives(arena, data, lines);
    data->guard = 0;
    return result;
}

static bool fs9_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs9_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs9_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs9_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs10_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs10_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs10_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs10_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs10_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs10_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs10_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << (tail == 0 ? 1 : tail - 1));
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs10_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs10_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs10_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs10_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs10_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs11_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs11_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs11_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs11_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs11_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs11_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs11_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = UINT64_C(0) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs11_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs11_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs11_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs11_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs11_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs12_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs12_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs12_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs12_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs12_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_maskz_loadu_epi8(valid, kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs12_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs12_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs12_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs12_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs12_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words;
        const uint32_t count = fs12_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs12_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

static uint32_t fs13_next_line(const uint64_t* lines, uint32_t after)
{
    const uint64_t start = (uint64_t)after + 1;
    uint64_t word = start / 64;
    uint64_t bits = lines[word] & (UINT64_MAX << (start % 64));
    while (bits == 0)
    {
        word += 1;
        bits = lines[word];
    }
    return (uint32_t)(word * 64 + (uint32_t)__builtin_ctzll(bits));
}
static bool fs13_finish_directives(Arena* arena, PPFileData* data, const uint64_t* lines)
{
    uint32_t kinds_seen = 0;
    for (uint32_t d = 0; d < data->directive_count; d += 1)
    {
        const uint32_t hash = data->directive_hash[d];
        const uint32_t end = fs13_next_line(lines, hash);
        uint8_t kind = PP_DIRECTIVE_NULL;
        if (hash + 1 < end)
        {
            const uint8_t name_kind = data->kinds[hash + 1] & 0x7F;
            kind = name_kind == C_TOKEN_RAW_IDENTIFIER ? pp_directive_kind_of(data->values[hash + 1]) : name_kind == C_TOKEN_NUMERIC_CONSTANT ? PP_DIRECTIVE_LINE_MARKER : PP_DIRECTIVE_UNKNOWN;
        }
        data->directive_end[d] = end;
        data->directive_kind[d] = kind;
        data->directive_next[d] = BUSTER_PP_NONE;
        kinds_seen |= UINT32_C(1) << kind;
    }
    // Only conditionals can pair or acquire a skip-time note. Every link already has its absent value.
    const uint32_t conditional_kinds = (UINT32_C(2) << PP_DIRECTIVE_ENDIF) - (UINT32_C(1) << PP_DIRECTIVE_IF);
    if ((kinds_seen & conditional_kinds) == 0)
    {
        data->note_count = 0;
        return true;
    }
    const bool elifdef = (kinds_seen & ((UINT32_C(1) << PP_DIRECTIVE_ELIFDEF) | (UINT32_C(1) << PP_DIRECTIVE_ELIFNDEF))) != 0;
    Scratch scratch = scratch_begin(0);
    uint32_t* indices = arena_push_array(scratch.arena, (uint64_t)data->directive_count + 32, sizeof(uint32_t), 64);
    bool result = indices != 0;
    bool notable = true;
    if (result && !pp_pair_conditionals_vector(data, indices, &notable))
    {
        pp_pair_conditionals_scalar(data, indices);
        notable = true;
    }
    scratch_end(scratch);
    data->note_count = 0;
    result = result && (!(notable || elifdef) || pp_note_directives(arena, data));
    return result;
}

static bool fs13_directive_arrays(Arena* arena, PPFileData* data, uint32_t count)
{
    data->directive_count = count;
    const uint64_t slots = (uint64_t)count + 1;
    const uint64_t kind_words = (slots + 3) / 4;
    uint32_t* const columns = arena_push_array(arena, 3 * slots + kind_words, sizeof(uint32_t), _Alignof(uint32_t));
    data->directive_hash = columns;
    data->directive_end = columns != NULL ? columns + slots : NULL;
    data->directive_kind = columns != NULL ? (uint8_t*)(columns + 2 * slots) : NULL;
    data->directive_next = columns != NULL ? columns + 2 * slots + kind_words : NULL;
    return columns != NULL;
}

static uint32_t fs13_scan_directives_window(const uint8_t* kinds, uint32_t begin, uint32_t end, uint64_t* lines, uint64_t* directives)
{
    uint32_t result = 0;
    uint64_t i = begin;
    for (; i + 64 <= end; i += 64)
    {
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    if (i < end)
    {
        const __mmask64 valid = _bzhi_u64(UINT64_MAX, end - i);
        const __m512i block = _mm512_loadu_si512(kinds + i);
        const uint64_t word = _mm512_cmpeq_epi8_mask(block, _mm512_set1_epi8((char)(C_TOKEN_HASH | BUSTER_C_TOKEN_START_OF_LINE)));
        lines[i / 64] = _mm512_movepi8_mask(block);
        directives[i / 64] = word;
        result += (uint32_t)__builtin_popcountll(word);
    }
    return result;
}

static bool fs13_publish_directives(Arena* arena, PPFileData* data, uint64_t* lines, const uint64_t* directives, uint32_t count)
{
    bool result = fs13_directive_arrays(arena, data, count);
    if (result && count != 0)
    {
        // The next line after a directive can always find the logical end, including on a word boundary.
        const uint32_t tail = data->token_count % 64;
        uint64_t* const last = &lines[data->token_count / 64];
        *last = (tail == 0 ? 0 : *last) | (UINT64_C(1) << tail);
        pp_directive_places(directives, (uint32_t)(((uint64_t)data->token_count + 63) / 64), data->directive_hash);
    }
    result = result && fs13_finish_directives(arena, data, lines);
    data->guard = result ? pp_find_guard(data, &data->guard_opener) : 0;
    return result;
}

static bool fs13_directive_table(Arena* arena, PPFileData* data)
{
    if (data->token_count == 0)
    {
        return fs13_publish_directives(arena, data, NULL, NULL, 0);
    }
    uint64_t local[17];
    const uint64_t words = ((uint64_t)data->token_count + 63) / 64;
    uint64_t* lines = local;
    Scratch scratch = {0};
    if (words > BUSTER_ARRAY_LENGTH(local) / 2)
    {
        scratch = scratch_begin(0);
        lines = arena_push_array(scratch.arena, words * 2 + 1, sizeof(uint64_t), 64);
    }
    bool result = lines != NULL;
    if (result)
    {
        uint64_t* directives = lines + words + 1;
        const uint32_t count = fs13_scan_directives_window(data->kinds, 0, data->token_count, lines, directives);
        result = fs13_publish_directives(arena, data, lines, directives, count);
    }
    if (scratch.arena != NULL)
    {
        scratch_end(scratch);
    }
    if (!result)
    {
        data->guard = 0;
    }
    return result;
}

#define FAULT_METHODS fs1_directive_table, fs2_directive_table, fs3_directive_table, fs4_directive_table, fs5_directive_table, fs6_directive_table, fs7_directive_table, fs8_directive_table, fs9_directive_table, fs10_directive_table, fs11_directive_table, fs12_directive_table, fs13_directive_table
#define FAULT_LABELS "line-bits", "directive-bits", "word-count", "overlap", "line-end", "kind", "link", "notes", "guard", "early-sentinel", "erase-last-word", "whole-word-overlap", "unmasked-tail"
