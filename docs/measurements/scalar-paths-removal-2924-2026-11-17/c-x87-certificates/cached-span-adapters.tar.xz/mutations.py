from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text().replace('static __m512i x87_transfer_annotations','static int x87_mutant;\nstatic __m512i x87_transfer_annotations')
for original,broken in [
('annotations + first);','annotations + (x87_mutant == 1 ? 0 : first));'),
('_bzhi_u64(UINT64_MAX, count)', '_bzhi_u64(UINT64_MAX, count - (x87_mutant == 2 && count != 0))'),
('uint64_t loads = _mm512_test_epi8_mask(tags, _mm512_set1_epi8(BUSTER_X87_TRANSFER_RELOAD));','uint64_t loads = _mm512_test_epi8_mask(tags, _mm512_set1_epi8(x87_mutant == 3 ? BUSTER_X87_TRANSFER_STORE : BUSTER_X87_TRANSFER_RELOAD));'),
('((transported >> home) & 1) == 0','x87_mutant == 4 || ((transported >> home) & 1) == 0'),
('((annotations[token] & BUSTER_X87_TRANSFER_STORE) != 0','((annotations[token] & BUSTER_X87_TRANSFER_STORE) != 0'),
('home == r && (annotations[token] & BUSTER_X87_TRANSFER_STORE) != 0 && memcmp','home == r && (x87_mutant == 5 || (annotations[token] & BUSTER_X87_TRANSFER_STORE) != 0) && memcmp'),
('const uint32_t home = owner - first;','const uint32_t home = x87_mutant == 6 ? owner : owner - first;'),
('left >= 64 ? UINT64_MAX : _bzhi_u64(UINT64_MAX, left)', 'x87_mutant == 8 ? _bzhi_u64(UINT64_MAX, left) : left >= 64 ? UINT64_MAX : _bzhi_u64(UINT64_MAX, left)'),
('candidates &= reads & ~repeated;', 'candidates &= (x87_mutant == 7 ? ~reads : reads) & ~repeated;')]:
 if original==broken:continue
 assert original in s,original
 s=s.replace(original,broken)
p.write_text(s)
s=p.read_text()
for before,after in [
 ('kinds[(first + r) % BUSTER_X87_TRANSFER_RECORDS]', 'kinds[(x87_mutant == 9 ? r : first + r) % BUSTER_X87_TRANSFER_RECORDS]'),
 ('records[first + row] = proposed[row];','if (x87_mutant != 10 || proposed[row].form != X86_FORM_FXCH_ST) records[first + row] = proposed[row];')]:
 assert s.count(before)==1
 s=s.replace(before,after)
p.write_text(s)
