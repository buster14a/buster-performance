from collections import defaultdict
from pathlib import Path
from statistics import median
def adapter(d, label, mode, tier):
    grouped = defaultdict(int)
    rows = [[tuple(map(int,l.split()[1:])) for l in p.read_text().splitlines() if l.startswith('x87-adapter ')] for p in sorted(d.glob(f'{label}-{mode}-{tier}-*.log'))]
    assert len(rows)==5 and all(len(x)==260 for x in rows),(mode,tier,[len(x) for x in rows])
    for samples in zip(*rows):
        assert all(x[:2]==samples[0][:2] for x in samples)
        grouped[samples[0][1]]+=median(x[2] for x in samples)
    return grouped
if __name__=='__main__':
 p=Path('/tmp/buster-x87')
 for stem, mode, source in [('finalactual','outlined','outlined-results'),('overlayactual','overlay','overlay-results')]:
  for tier in ['tier0','tier1']:
   a=adapter(p/source,stem,'scalar',tier); b=adapter(p/source,stem,mode,tier)
   bad=[(n,round(b[n]/t,4)) for n,t in a.items() if b[n]>t]
   print(mode,tier,len(a),len(a)-len(bad),round(sum(b.values())/sum(a.values()),5),bad)
