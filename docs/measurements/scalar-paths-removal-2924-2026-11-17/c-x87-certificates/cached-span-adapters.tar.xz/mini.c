#include "buster/compiler/main_unit_backend.c"
int main(int argc, char** argv)
{
    Tier1WideTest test = {0};
    x87_mutant = argc == 2 ? atoi(argv[1]) : 0;
    tier1_x87_transfer_proof(&test);
    tier1_x87_transfer_candidate_bounds(&test);
    printf("variant %d: %u failures in %u checks\n", x87_mutant, (unsigned)test.failures, (unsigned)test.checks);
    return test.failures != 0;
}
