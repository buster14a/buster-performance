from pathlib import Path
from statistics import median
from collections import defaultdict
import sys,re
rows=defaultdict(lambda:defaultdict(dict))
for line in Path(sys.argv[1]).read_text().splitlines():
 m=re.match(r'cachedpath-(tier[01])-([\w-]+)/sample-(\d+)-([\w-]+).log:.*?(\d+) user cycles,.*status 0',line)
 if m:rows[(m[1],m[2])][m[3]][m[4]]=int(m[5])
for group,samples in sorted(rows.items()):
 s=[x for x in samples.values() if len(x)==4]
 if s:print(group,len(s),*(round(100*(median(v)-1),3) for v in [((x['cached-head']+x['duplicate-cached'])/(x['fresh']+x['fresh-control']) for x in s),(x['fresh-control']/x['fresh'] for x in s),(x['duplicate-cached']/x['cached-head'] for x in s)]))
