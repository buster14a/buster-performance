#include <stdint.h>
#include <string.h>
typedef void Div(uint64_t*,uint64_t*,const uint64_t*,const uint64_t*,uint32_t);
extern Div base_div,vector_div;
uint64_t* dividend_work;
void original(uint64_t* q,uint64_t* r,const uint64_t* a,const uint64_t* b,uint32_t n)
{
    memcpy(dividend_work,a,(size_t)n*8);
    base_div(q,r,dividend_work,b,n);
}
extern void inplace_forward(uint64_t*,uint64_t*,const uint64_t*,uint32_t);
void production(uint64_t* q,uint64_t* r,const uint64_t* a,const uint64_t* b,uint32_t n)
{
    memcpy(r,a,(size_t)n*8);
    inplace_forward(q,r,b,n);
}
extern void inplace_reverse(uint64_t*,uint64_t*,const uint64_t*,uint32_t);
void ranked(uint64_t* q,uint64_t* r,const uint64_t* a,const uint64_t* b,uint32_t n)
{
    memcpy(r,a,(size_t)n*8);
    inplace_reverse(q,r,b,n);
}
extern void inplace_lengths(uint64_t*,uint64_t*,const uint64_t*,uint32_t);
void identity(uint64_t* q,uint64_t* r,const uint64_t* a,const uint64_t* b,uint32_t n)
{
    memcpy(r,a,(size_t)n*8);
    inplace_lengths(q,r,b,n);
}
