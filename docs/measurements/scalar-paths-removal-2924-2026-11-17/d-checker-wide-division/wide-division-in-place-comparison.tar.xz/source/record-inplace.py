from pathlib import Path
from statistics import median
import tarfile

here = Path(__file__).parent
directory = Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-checker-wide-division')
strategies = {
    'inplace': ['Forward comparison', 'Reverse comparison', 'Count both lengths during reverse comparison'],
    'entries': ['Clear quotient during comparison', 'Outline normalized quotient estimation', 'Keep the comparison entry hot'],
}
summary = []
for group, labels in strategies.items():
    cells = {}
    for seed in (1, 133, 789):
        path = here / 'inplace-results' / f'{group}-{seed}'
        assert '45 widths, 11 operand distributions' in path.with_suffix('.log').read_text()
        for line in path.with_suffix('.tsv').read_text().splitlines():
            width, shape, repeats, baseline, *ticks = map(int, line.split())
            assert len(ticks) == 3 and min(repeats, baseline, *ticks) > 0
            if width >= 3:
                cells.setdefault((width, shape), []).append([x / baseline for x in ticks])
    assert len(cells) == 473 and all(len(x) == 3 for x in cells.values())
    for index, label in enumerate(labels):
        ratios = [median(run[index] for run in samples) for samples in cells.values()]
        summary.append(f'| {label} | {sum(x <= 1 for x in ratios)}/473 | {median(ratios):.4f} | {max(ratios):.4f} |')
archive = 'wide-division-in-place-comparison.tar.xz'
with tarfile.open(directory / archive, 'w:xz') as output:
    for group in strategies:
        for path in sorted(here.glob(group + '-*.c')):
            output.add(path, arcname='source/' + path.name)
        output.add(here / (group + '-sizes'), arcname='source/' + group + '-sizes')
    for name in ('base.c', 'reuse-gate.c', 'record-inplace.py'):
        output.add(here / name, arcname='source/' + name)
    output.add(here / 'inplace-results', arcname='native')
readme = directory / 'README.md'
heading = '## Compare and divide on a writable dividend'
assert heading not in readme.read_text()
readme.write_text(readme.read_text().rstrip() + '\n\n' + heading + '''

The ordinary folder materializes its operands before starting division. Each routine in this comparison pays for a copy of the dividend into writable storage. The six alternatives reuse that storage for the remainder. All three seeds ran eleven operand distributions at each of 43 eligible widths, from 3 through 129 limbs. Each ratio divides candidate cycles by scalar cycles for the same seed and cell. The table summarizes the median across seeds for each cell.

| Routine | Cells meeting scalar | Median ratio | Slowest ratio |
| --- | ---: | ---: | ---: |
''' + '\n'.join(summary) + f'\n\n[Compiler flags, implementations, checked driver, raw cycle counts and summary script]({archive})\n')
print(*summary, sep='\n')
