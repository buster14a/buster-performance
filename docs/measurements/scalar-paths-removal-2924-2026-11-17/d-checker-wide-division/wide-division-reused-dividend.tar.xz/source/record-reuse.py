from pathlib import Path
from statistics import median
import importlib,sys,tarfile
p=Path(__file__).parent;r=p/'reuse-results';sys.path.insert(0,str(p));large=importlib.import_module('outline-verify');sys.path.insert(0,'/tmp/buster-unroll');change=importlib.import_module('record-extra').change
d=Path('/workspace/buster-performance/docs/measurements/scalar-paths-removal-2924-2026-11-17/d-checker-wide-division')
small={}
for seed in (1,133,789):
    assert '45 widths, 11 operand distributions' in (r/f'reuse-{seed}.log').read_text()
    for l in (r/f'reuse-{seed}.tsv').read_text().splitlines():
        w,shape,reps,b,*vs=map(int,l.split());assert min(reps,b,*vs)>0 and len(vs)==3
        if w>=3:small.setdefault((w,shape),[]).append([v/b for v in vs])
assert len(small)==473 and all(len(v)==3 for v in small.values())
srows=[]
for i,label in enumerate(['Dividend becomes remainder','Dividend becomes quotient','Separate scratch input, current vector core']):
    ratios=[median(x[i]for x in rs)for rs in small.values()];srows.append(f'| {label} | {sum(x<=1 for x in ratios)}/473 | {median(ratios):.4f} | {max(ratios):.4f} |')
lrows=[];stats=['caller_operation\tlimbs\tshape\trounds\tinterrupted\tmedian_ratio_or_bound']
for op in ('quotient','remainder'):
    totals=[]
    for n in large.widths:
        f=r/f'reuse-{op}-results/{n}.tsv';assert large.valid(f,n),(op,n)
        ls=[x.split() for x in f.read_text().splitlines()]
        for h in range(11):
            vals=[(float(l[5]),float(l[6]))for l in ls if int(l[1])==h]
            ratio=median(y/abs(x)for x,y in vals);interrupted=sum(x<0 for x,y in vals)
            totals.append((ratio,interrupted));stats.append(f'{op}\t{n}\t{h}\t{len(vals)}\t{interrupted}\t{ratio:.9g}')
    assert len(totals)==407
    lrows.append(f'| {op} | {sum(x<=1 for x,_ in totals)}/407 | {max(x for x,_ in totals):.4f} | {sum(n for _,n in totals)} |')
corpus=[]
for g,n in [('positive',1),('heavy',1),('lua',34),('sqlite',1),('musl',1336)]:
    row=[g,str(n)]
    for t in ('tier0','tier1'):
        b,h=[(r/f'reuse-objects-{t}-{g}-{k}.sha').read_bytes()for k in ('base','reuse')]
        assert b==h and len(b.splitlines())==n+2;row.append(change(r/f'reuse-compile-{t}-{g}.log'))
    corpus.append('| '+' | '.join(row)+' |')
assert '838227 checks, 0 failures' in (r/'reuse-checker.log').read_text()
sem=r/'reuse-semantic'
for tier in ('tier0','tier1'):
 for suite,n in [('positive',4),('heavy',96)]:assert f'{n} exported _BitInt objects match Clang' in (sem/f'{suite}-{tier}-values.log').read_text()
for fault in ['division','remainder','overflow']:
 assert all((sem/f'fault-{fault}.c-{k}.status').read_text().strip()=='1' for k in ['base','head','clang'])
 for ext in ['stdout','stderr']:assert (sem/f'fault-{fault}.c-head.{ext}').read_bytes()==(sem/f'fault-{fault}.c-base.{ext}').read_bytes()
(p/'reuse-large-rows.tsv').write_text('\n'.join(stats)+'\n')
name='wide-division-reused-dividend.tar.xz'
with tarfile.open(d/name,'w:xz')as t:
    for f in r.rglob('*'):
        if f.is_file():t.add(f,arcname='native/'+str(f.relative_to(r)))
    for n in ['reuse-large-rows.tsv','reuse.patch','reuse-kernels.c','reuse-gate.c','reuse-quotient.c','reuse-remainder.c','reuse-sizes','reuse-task','reuse-objects','reuse-semantic-task','base.c','outline.c','outline-verify.py','positive.c','heavy.c','elf-values.py','record-reuse.py']:t.add(p/n,arcname='source/'+n)
title='## Reusing the materialized dividend for the second output';f=d/'README.md';s=f.read_text();assert title not in s
f.write_text(s.rstrip()+'\n\n'+title+'''

The caller reused the materialized dividend as its temporary quotient or remainder. This removed one arena allocation. Both sides of the small comparison included copying the same input limbs into writable storage before division. Each cell is the median paired ratio over three seeds. The two sizes below three limbs go through the ordinary narrow folder and are excluded.

| Layout | Cells meeting scalar | Median ratio | Slowest ratio |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(srows)+'''

GMP independently verified both outputs at each of 37 larger widths through 131,072 limbs, for eleven operand shapes in each orientation. As in the previous large sweep, an interrupted scalar batch supplies a conservative upper bound on the ratio.

| Caller operation | Cells meeting scalar | Slowest ratio or upper bound | Interrupted scalar batches |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(lrows)+'''

The native checker passed 838,227 checks. Clang agreed on 100 exported data values at each tier and rejected all three erroneous expressions. All 1,371 ordinary debug objects per tier and both explicit wide fixtures matched the parent, as did stdout and diagnostics. The table gives the median of five paired whole-compile cycle measurements.

| Workload | Objects | Tier 0 | Tier 1 |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(corpus)+f'\n\n[Production patch, arithmetic fixtures, GMP and compiler comparisons, hashes and process counters]({name})\n')
print(*srows,*lrows,*corpus,sep='\n')
