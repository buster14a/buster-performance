#include <stdint.h>
#include <string.h>
typedef void Div(uint64_t*,uint64_t*,const uint64_t*,const uint64_t*,uint32_t);
extern Div base_div,vector_div;
uint64_t* dividend_work;
void original(uint64_t* q,uint64_t* r,const uint64_t* a,const uint64_t* b,uint32_t n)
{
    memcpy(dividend_work,a,(size_t)n*8);
    base_div(q,r,dividend_work,b,n);
}
void production(uint64_t* q,uint64_t* r,const uint64_t* a,const uint64_t* b,uint32_t n)
{
    memcpy(r,a,(size_t)n*8);
    vector_div(q,r,r,b,n);
}
void ranked(uint64_t* q,uint64_t* r,const uint64_t* a,const uint64_t* b,uint32_t n)
{
    memcpy(q,a,(size_t)n*8);
    vector_div(q,r,q,b,n);
}
void identity(uint64_t* q,uint64_t* r,const uint64_t* a,const uint64_t* b,uint32_t n)
{
    memcpy(dividend_work,a,(size_t)n*8);
    vector_div(q,r,dividend_work,b,n);
}
