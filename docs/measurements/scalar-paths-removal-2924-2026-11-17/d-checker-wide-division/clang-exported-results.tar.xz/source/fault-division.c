typedef _BitInt(193) S;
_Static_assert((S)7 / (S)0 == 0, "division must diagnose zero");
