from pathlib import Path
from random import Random
p=Path(__file__).parent;r=Random(3444)
def expr(x):
 parts=[]
 while x:parts.append(x % (1<<64));x>>=64
 return '('+' | '.join(f'((U)0x{k:x}ull << {64*i})'for i,k in enumerate(parts))+')'
s=['typedef unsigned _BitInt(769) U;']
for i in range(48):
 a=r.getrandbits(769);b=r.getrandbits(381) or 1
 s.extend([f'#define A{i} '+expr(a),f'#define B{i} '+expr(b),f'U q{i} = A{i} / B{i}, r{i} = A{i} % B{i};',f'_Static_assert(A{i} / B{i} == '+expr(a//b)+');',f'_Static_assert(A{i} % B{i} == '+expr(a%b)+');'])
(p/'heavy.c').write_text('\n'.join(s)+'\n')
