import struct,sys
from pathlib import Path
def variables(f):
 raw=Path(f).read_bytes()
 assert raw[:6]==b'\x7fELF\x02\x01'
 section_offset=struct.unpack_from('<Q',raw,40)[0];section_size,section_count=struct.unpack_from('<HH',raw,58)
 sections=[struct.unpack_from('<IIQQQQIIQQ',raw,section_offset+i*section_size) for i in range(section_count)]
 symbols={}
 for sec in sections:
  if sec[1]!=2:continue
  tab=sections[sec[6]];strings=raw[tab[4]:tab[4]+tab[5]]
  for at in range(sec[4],sec[4]+sec[5],sec[9]):
   name,info,other,index,addr,n=struct.unpack_from('<IBBHQQ',raw,at)
   if info&15!=1 or info>>4!=1 or not(0<index<len(sections)):continue
   key=strings[name:strings.index(0,name)].decode()
   section=sections[index];offset=section[4]+addr-section[3]
   symbols[key]=bytes(n) if section[1]==8 else raw[offset:offset+n]
 return symbols
suite=sys.argv[1];a,b=map(variables,sys.argv[2:]);assert set(a)==set(b),(sorted(a),sorted(b));assert len(a)==(4 if suite=='positive'else 96)
for key in sorted(a):
 bits=(193 if key.startswith('signed') else 257) if suite=='positive'else 769;mask=(1<<bits)-1
 assert int.from_bytes(a[key],'little')&mask==int.from_bytes(b[key],'little')&mask,key
print(f'{suite}: {len(a)} exported _BitInt objects match Clang bit for bit in their declared widths')
