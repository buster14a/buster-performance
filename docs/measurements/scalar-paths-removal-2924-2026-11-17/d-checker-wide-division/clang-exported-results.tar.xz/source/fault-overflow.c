typedef _BitInt(193) S;
typedef unsigned _BitInt(193) U;
#define MIN ((S)((U)1 << 192))
_Static_assert(MIN / (S)-1 == 0, "minimum divided by negative one");
