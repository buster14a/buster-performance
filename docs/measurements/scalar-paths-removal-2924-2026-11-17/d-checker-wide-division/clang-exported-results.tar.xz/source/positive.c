typedef unsigned _BitInt(257) U;
typedef _BitInt(193) S;
#define DIVISOR (((U)1 << 91) + 15)
#define NUMERATOR (((U)1 << 222) + 17)
_Static_assert((NUMERATOR / DIVISOR) * DIVISOR + (NUMERATOR % DIVISOR) == NUMERATOR);
_Static_assert((S)-113 / (S)13 == -8);
_Static_assert((S)-113 % (S)13 == -9);
int f(void) { return 0; }
U wide_quotient = NUMERATOR / DIVISOR;
U wide_remainder = NUMERATOR % DIVISOR;
S signed_quotient = (S)-113 / (S)13;
S signed_remainder = (S)-113 % (S)13;
