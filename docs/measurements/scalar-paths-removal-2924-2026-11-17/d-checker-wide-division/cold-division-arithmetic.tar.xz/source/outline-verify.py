from pathlib import Path
import os,subprocess
widths=(130,191,192,193,255,256,257,383,384,385,511,512,513,1023,1024,1025,2047,2048,2049,4095,4096,4097,8191,8192,8193,16383,16384,16385,32767,32768,32769,65535,65536,65537,131070,131071,131072)
def valid(path,n):
    try:
        rows=[line.split() for line in path.read_text().splitlines()]
        if any(len(row)!=7 or int(row[0])!=n or int(row[3])<1 or int(row[4])<1 or float(row[5])==0 or float(row[6])<=0 for row in rows):return False
        if {int(row[1]) for row in rows}!=set(range(11)):return False
        for s in range(11):
            indices=[int(x[2]) for x in rows if int(x[1])==s]
            if indices not in (list(range(3)),list(range(7))):return False
        return True
    except (FileNotFoundError,ValueError):return False
if __name__=='__main__':
    from time import sleep
    os.chdir('/dev/shm/buster-wide-6b097f86')
    os.environ.update(EXCLUSIVE_OWNER='codex-wide-6b097f86',EXCLUSIVE_TITLE='Complete and verify every large quotient/remainder timing',EXCLUSIVE_LINK='https://github.com/buster14a/buster/issues/3444')
    while not Path('outline-gmp.ok').is_file():sleep(5)
    for n in widths:
        out=Path(f'outline-gmp-results/{n}.tsv')
        if valid(out,n):continue
        print('repeating',n,flush=True)
        tmp=out.with_suffix('.repair')
        with tmp.open('wb')as stdout,out.with_suffix('.repair.log').open('wb')as stderr:
            subprocess.run([str(Path.home()/'buster-fast-bench/exclusive.sh'),'taskset','-c','2','./outline-gmp',str(n)],stdout=stdout,stderr=stderr,check=True)
        assert valid(tmp,n),n
        tmp.replace(out)
    Path('outline-gmp-verified.ok').touch()
