#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <immintrin.h>
#define BUSTER_CHECK_WIDE_VECTOR_LIMBS 8u
#define BUSTER_CHECK_WIDE_LIMB_BITS 64u
static uint32_t check_wide_add_scalar(uint64_t* destination, const uint64_t* a, const uint64_t* b, uint32_t count, bool invert, uint32_t carry)
{
    uint32_t c = carry;
    for (uint32_t i = 0; i < count; i += 1)
    {
        const uint64_t y = invert ? ~b[i] : b[i];
        const unsigned __int128 sum = (unsigned __int128)a[i] + y + c;
        destination[i] = (uint64_t)sum;
        c = (uint32_t)(sum >> 64);
    }
    return c;
}
static int32_t check_wide_compare_scalar(const uint64_t* a, const uint64_t* b, uint32_t count)
{
    int32_t result = 0;
    for (uint32_t i = count; result == 0 && i != 0; i -= 1)
    {
        result = a[i - 1] < b[i - 1] ? -1 : a[i - 1] > b[i - 1] ? 1 : 0;
    }
    return result;
}
static uint32_t check_wide_bits(const uint64_t* a, uint32_t count)
{
    uint32_t result = 0;
    for (uint32_t i = count; result == 0 && i != 0; i -= 1)
    {
        result = a[i - 1] != 0 ? (i - 1) * BUSTER_CHECK_WIDE_LIMB_BITS + 64u - (uint32_t)__builtin_clzll(a[i - 1]) : 0;
    }
    return result;
}
void original(uint64_t* quotient, uint64_t* remainder, const uint64_t* a, const uint64_t* b, uint32_t count)
{
    for (uint32_t i = 0; i < count; i += 1)
    {
        quotient[i] = 0;
        remainder[i] = 0;
    }
    for (uint32_t bit = check_wide_bits(a, count); bit != 0; bit -= 1)
    {
        const uint32_t index = bit - 1;
        // remainder = remainder << 1 | a's bit; it stays below 2b, so its top bit never falls off below count limbs.
        uint64_t carry = (a[index / BUSTER_CHECK_WIDE_LIMB_BITS] >> (index % BUSTER_CHECK_WIDE_LIMB_BITS)) & 1u;
        uint64_t over = 0;
        for (uint32_t i = 0; i < count; i += 1)
        {
            const uint64_t limb = remainder[i];
            remainder[i] = (limb << 1) | carry;
            carry = limb >> 63;
        }
        over = carry;
        if (over != 0 || check_wide_compare_scalar(remainder, b, count) >= 0)
        {
            check_wide_add_scalar(remainder, remainder, b, count, true, 1);
            quotient[index / BUSTER_CHECK_WIDE_LIMB_BITS] |= UINT64_C(1) << (index % BUSTER_CHECK_WIDE_LIMB_BITS);
        }
    }
}
