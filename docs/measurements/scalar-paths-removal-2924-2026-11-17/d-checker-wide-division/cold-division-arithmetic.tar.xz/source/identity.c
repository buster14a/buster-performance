#include <stdint.h>
#include <string.h>
#include <immintrin.h>
typedef uint32_t Digit __attribute__((__may_alias__));

static unsigned used_digits(const Digit* x, unsigned length)
{
    while (length != 0)
    {
        const unsigned lanes = length < 16 ? length : 16;
        const unsigned first = length - lanes;
        const __mmask16 live = (__mmask16)_bzhi_u32(0xffffu, lanes);
        const __m512i digits = _mm512_maskz_loadu_epi32(live, x + first);
        const unsigned nonzero = _mm512_test_epi32_mask(digits, digits);
        if (nonzero != 0) return first + 32u - (unsigned)__builtin_clz(nonzero);
        length = first;
    }
    return 0;
}

static inline __m256i subtract8(__m256i x, __m256i y, unsigned live, unsigned lanes, unsigned* borrow)
{
    const unsigned generate = _mm256_mask_cmplt_epu32_mask(live, x, y);
    const unsigned propagate = _mm256_mask_cmpeq_epi32_mask(live, x, y);
    const unsigned carries = ((generate << 1) | *borrow) + propagate;
    const __m256i raw = _mm256_sub_epi32(x, y);
    *borrow = (carries >> lanes) & 1u;
    return _mm256_mask_sub_epi32(raw, (__mmask8)(carries ^ propagate), raw, _mm256_set1_epi32(1));
}

static unsigned add_back(Digit* r, const Digit* b, unsigned length)
{
    unsigned carry = 0;
    for (unsigned i = 0; i < length; i += 16)
    {
        const unsigned lanes = length-i < 16 ? length-i : 16;
        const __mmask16 live = (__mmask16)_bzhi_u32(0xffffu,lanes);
        const __m512i x = _mm512_maskz_loadu_epi32(live,r+i);
        const __m512i sum = _mm512_add_epi32(x,_mm512_maskz_loadu_epi32(live,b+i));
        const unsigned g = _mm512_mask_cmplt_epu32_mask(live,sum,x);
        const unsigned p = _mm512_mask_cmpeq_epi32_mask(live,sum,_mm512_set1_epi32(-1));
        const unsigned total = ((g<<1)|carry) + p;
        _mm512_mask_storeu_epi32(r+i,live,_mm512_mask_add_epi32(sum,(__mmask16)(total^p),sum,_mm512_set1_epi32(1)));
        carry = (total >> lanes)&1;
    }
    return carry;
}

static int64_t subtract_product(Digit* r, uint32_t top, const Digit* b, unsigned length, uint32_t digit)
{
    const __m512i multiplier = _mm512_set1_epi64(digit);
    unsigned low_borrow=0, high_borrow=0;
    __m256i previous = _mm256_setzero_si256();
    __m256i upper = previous;
    for(unsigned i=0; i<length; i+=8)
    {
        const unsigned lanes = length-i<8 ? length-i : 8;
        const __mmask8 live = (__mmask8)_bzhi_u32(255,lanes);
        const __m256i v = _mm256_maskz_loadu_epi32(live,b+i);
        const __m512i product = _mm512_mul_epu32(_mm512_cvtepu32_epi64(v),multiplier);
        const __m256i low = _mm512_cvtepi64_epi32(product);
        upper = _mm512_cvtepi64_epi32(_mm512_srli_epi64(product,32));
        const __m256i high = _mm256_alignr_epi32(upper,previous,7);
        const __m256i x = _mm256_maskz_loadu_epi32(live,r+i);
        const __m256i t = subtract8(x,low,live,lanes,&low_borrow);
        _mm256_mask_storeu_epi32(r+i,live,subtract8(t,high,live,lanes,&high_borrow));
        previous = upper;
    }
    const uint32_t last=(uint32_t)_mm256_extract_epi32(_mm256_permutevar8x32_epi32(upper,_mm256_set1_epi32((length-1)&7u)),0);
    return (int64_t)top-last-low_borrow-high_borrow;
}

void identity(uint64_t* quotient, uint64_t* remainder, const uint64_t* a, const uint64_t* b, uint32_t count)
{
    const Digit* divisor = (const Digit*)b;
    Digit* rem=(Digit*)remainder;
    Digit* quot=(Digit*)quotient;
    memset(quotient,0,(size_t)count*8);
    memcpy(remainder,a,(size_t)count*8);
    const unsigned an=used_digits((const Digit*)a,2*count);
    if(an==0)return;
    const unsigned n=used_digits(divisor,2*count);
    if(an<n || n==0) return;
    if (n==1 && divisor[0]==1) { memcpy(quotient,a,(size_t)an*4);memset(remainder,0,(size_t)an*4);return; }
    const unsigned shift=(unsigned)__builtin_clz(divisor[n-1]);
    const uint64_t low=n>1?divisor[n-2]:0;
    const uint32_t d=(divisor[n-1]<<shift)|(uint32_t)(low>>(32-shift));
    for(unsigned at=an-n+1;at!=0;)
    {
        unsigned j=--at;
        uint32_t top=j+n<an?rem[j+n]:0;
        uint32_t next=rem[j+n-1];
        uint32_t following=j+n>=2?rem[j+n-2]:0;
        uint32_t high=(top<<shift)|(uint32_t)((uint64_t)next>>(32-shift));
        uint32_t lower=(next<<shift)|(uint32_t)((uint64_t)following>>(32-shift));
        uint32_t estimate=high>=d?UINT32_MAX:(uint32_t)((((uint64_t)high<<32)|lower)/d);
        if(estimate!=0)
        {
            int64_t balance=subtract_product(rem+j,top,divisor,n,estimate);
            while(balance<0){balance+=add_back(rem+j,divisor,n);--estimate;}
            if(j+n<an) rem[j+n]=(uint32_t)balance;
            quot[j]=estimate;
        }
    }
}
