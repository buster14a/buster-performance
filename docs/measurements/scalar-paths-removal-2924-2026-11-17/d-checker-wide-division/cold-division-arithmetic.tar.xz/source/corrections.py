import ctypes as C, sys, random, mmap, os, struct
from pathlib import Path
p=Path(__file__).parent
dll=C.CDLL(str(Path(sys.argv[1]).resolve()));methods=[getattr(dll,n)for n in sys.argv[2:]];word=C.c_uint64;ptr=C.POINTER(word)
for fn in methods:fn.argtypes=[ptr,ptr,ptr,ptr,C.c_uint32];fn.restype=None
seed=random.Random(2924); pg=mmap.PAGESIZE;libc=C.CDLL(None);cases=0
def buffer(n,start):
 length=((8*n+pg-1)//pg+2)*pg
 m=mmap.mmap(-1,length,prot=mmap.PROT_READ|mmap.PROT_WRITE)
 address=C.addressof(C.c_char.from_buffer(m));assert libc.mprotect(C.c_void_p(address),pg,0)==0 and libc.mprotect(C.c_void_p(address+length-pg),pg,0)==0
 off=pg if start else length-pg-8*n
 return m,(word*n).from_address(address+off)
def assign(v,num):C.memmove(C.addressof(v),num.to_bytes(8*len(v),'little'),8*len(v))
def intval(v):return int.from_bytes(C.string_at(v,8*len(v)),'little')
for n in [*range(1,35),48,63,64,65,127,128,129,257,513,1024,4097,131072]:
 w=64*n; lim=1<<w;largest=lim-1
 patterns=[(0,largest),(1,largest),(largest,largest),(largest,largest-1),(largest//2,largest),(largest-1,largest//2+1),(largest,1<<max(0,w-17)),(largest,1<<max(0,w//2)),(largest,19),(largest,1),(largest-7,(1<<min(65,w-1))+1)]
 if n>=3:
  patterns.extend([(0x881ff996d618e75655df97bb43ad9e8b,0xb72c562d706643cdb893ef3a),(0xdca73590ea673c14272af3b981fdd45c,0xe00404b8f53bf78d20f8f21a)])
 if n==17:
  # A two-unit overestimate whose restoration carries across a 16-digit boundary.
  scale=1<<(32*15)
  patterns.extend([(0xdca73590ea673c14272af3b981fdd45c*scale+k,0xe00404b8f53bf78d20f8f21a*scale+1) for k in (0,1,2**31)])
 if n<128:
  for j in range(128):
   bx=seed.randrange(1,w+1);ax=seed.randrange(1,w+1)
   a=seed.getrandbits(ax);b=seed.getrandbits(bx) or 1
   if j%5==0:b=(b & ~((1<<min(bx,32))-1))|1
   if j%9==0:a=(b*(2**32-1)+b-1)%lim
   patterns.append((a,b))
 if n>1024:patterns=[x for i,x in enumerate(patterns)if i in(0,1,2,3,4,5,6,8,9)]
 for placement in (0,1):
  bufs=[buffer(n,placement^(i&1))for i in range(4)];a,b,q,r=[v for m,v in bufs];sentinel=int.from_bytes(b'\xa5'*(8*n),'little')
  for x,y in patterns:
   expected=divmod(x,y);assign(a,x);assign(b,y)
   for f in methods:
    assign(q,sentinel);assign(r,sentinel);f(q,r,a,b,n);got=intval(q),intval(r)
    if got!=expected or intval(a)!=x or intval(b)!=y:raise RuntimeError((f.__name__,n,placement,cases,'incorrect quotient, remainder or input'))
   cases+=1
  del a,b,q,r
  for m,v in bufs:m.close()
print(f'{cases} independently computed quotient/remainder pairs per implementation, limb counts 1 through 131072, protected inputs and outputs, inputs preserved')
