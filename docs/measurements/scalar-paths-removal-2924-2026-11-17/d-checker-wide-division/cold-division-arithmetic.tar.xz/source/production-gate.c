#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <immintrin.h>
typedef void Div(uint64_t*,uint64_t*,const uint64_t*,const uint64_t*,uint32_t);
extern Div original,production,ranked,identity;
static Div* volatile ops[]={original,production,ranked,identity};
static unsigned rng=1;
static uint32_t random32(void){rng=rng*1664525u+1013904223u;return rng;}
static uint64_t random64(void){uint64_t h=random32();return(h<<32)|random32();}
static uint64_t ticks(void){_mm_lfence();uint64_t t=__rdtsc();_mm_lfence();return t;}
static int cmp(const void*l,const void*r){uint64_t a=*(const uint64_t*)l,b=*(const uint64_t*)r;return(a>b)-(a<b);}
int main(int argc,char**argv){
 if(argc>1)rng=strtoul(argv[1],0,10);
 uint32_t sizes[60],ns=0;for(unsigned i=1;i<=33;i++)sizes[ns++]=i;
 unsigned extra[]={47,48,49,63,64,65,95,96,97,127,128,129};for(unsigned i=0;i<sizeof(extra)/sizeof(*extra);i++)sizes[ns++]=extra[i];
 uint64_t a[132],b[132],q[132],r[132],expected_q[132],expected_r[132];volatile uint64_t sink=0;
 for(unsigned si=0;si<ns;si++)for(unsigned shape=0;shape<11;shape++){
  unsigned n=sizes[si];for(unsigned i=0;i<n;i++){a[i]=random64();b[i]=random64();}
  switch(shape){case 0:memset(a,0,n*8);break;case 1:memset(a,0,n*8);a[0]=1;break;case 2:memcpy(b,a,n*8);break;
   case 3:a[n-1]|=1ull<<63;b[n-1]=a[n-1]-1;break;case 4:a[n-1]>>=1;b[n-1]|=1ull<<63;break;
   case 5:memset(b,0,n*8);b[0]=1;break;case 6:memset(b,0,n*8);b[0]=0xfffffffbu;break;
   case 7:memset(b+n/2,0,(n-n/2)*8);b[0]|=1;break;case 8:memset(b,0,n*8);b[n/2]=(uint64_t)1<<(n%64);break;
   case 9:memset(a,0xff,n*8);memset(b,0,n*8);b[0]=0x8000000000000001ull;break;
   case 10:memset(a,0,n*8);memset(b,0,n*8);a[0]=113;b[0]=13;break;}
  if(b[0]==0&&n==1)b[0]=1;
  original(expected_q,expected_r,a,b,n);
  for(unsigned j=0;j<4;j++){memset(q,0xa5,sizeof(q));memset(r,0x5a,sizeof(r));ops[j](q,r,a,b,n);if(memcmp(q,expected_q,n*8)||memcmp(r,expected_r,n*8)||q[n]!=0xa5a5a5a5a5a5a5a5ull||r[n]!=0x5a5a5a5a5a5a5a5aull)return fprintf(stderr,"mismatch %u %u %u\n",n,shape,j),1;}
  uint64_t times[4][7];unsigned reps=shape<=1||shape==10?2048/(1+n/8)+16:480/(n*n)+1;
  for(unsigned k=0;k<7;k++){unsigned order=random32()>>30;for(unsigned z=0;z<4;z++){unsigned j=(order+(k%2?3*z:z))%4;Div* f=ops[j];uint64_t t=ticks();for(unsigned i=0;i<reps;i++)f(q,r,a,b,n);times[j][k]=ticks()-t;sink=q[0]^r[0];}}
  printf("%u %u %u",n,shape,reps);for(unsigned j=0;j<4;j++){qsort(times[j],7,8,cmp);printf(" %lu",times[j][3]);}puts("");
 }
 fprintf(stderr,"checked %u widths, 11 operand distributions (%lu)\n",ns,sink);
}
