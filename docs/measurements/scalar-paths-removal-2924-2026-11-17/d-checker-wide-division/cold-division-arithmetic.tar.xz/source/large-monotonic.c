#define _GNU_SOURCE
#include <gmp.h>
#include <inttypes.h>
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
typedef void Divide(uint64_t*,uint64_t*,const uint64_t*,const uint64_t*,uint32_t);
extern Divide production,original;
static uint64_t seed=3444;
static uint64_t bits(void){seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;return seed;}
static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
static sigjmp_buf jump;
static void expired(int s){(void)s;siglongjmp(jump,1);}
static timer_t timer;
static double timed(Divide* f,uint64_t* q,uint64_t* r,const uint64_t* a,const uint64_t* b,unsigned n,unsigned reps,uint64_t limit){
 struct itimerspec setting={0};
 if(limit){setting.it_value.tv_sec=limit/1000000000;setting.it_value.tv_nsec=limit%1000000000;if(sigsetjmp(jump,1)!=0)return -(double)(limit-50000)/reps;if(timer_settime(timer,0,&setting,0))abort();}
 uint64_t t=now();for(unsigned i=0;i<reps;i++)f(q,r,a,b,n);uint64_t elapsed=now()-t;
 if(limit){struct itimerspec off={0};if(timer_settime(timer,0,&off,0))abort();}
 return (double)elapsed/reps;
}
static unsigned batch(double ns){unsigned k=ns>1000000?1:1000000/(ns<1?1:ns);return k>4096?4096:k?k:1;}
int main(int argc,char**argv){
 if(argc!=2)return 2; unsigned n=atoi(argv[1]);if(n<130||n>131072)return 2;
 struct sigaction handler={0};handler.sa_handler=expired;sigemptyset(&handler.sa_mask);if(sigaction(SIGPROF,&handler,0))return 2;
 struct sigevent ev={0};ev.sigev_notify=SIGEV_SIGNAL;ev.sigev_signo=SIGPROF;if(timer_create(CLOCK_MONOTONIC,&ev,&timer))return 2;
 uint64_t *a=calloc(n,8),*b=calloc(n,8),*q=calloc(n,8),*r=calloc(n,8);
 mpz_t aa,bb,qq,rr,qout,rout;mpz_inits(aa,bb,qq,rr,qout,rout,NULL);
 for(unsigned shape=0;shape<11;shape++){
  for(unsigned i=0;i<n;i++){a[i]=bits();b[i]=bits();}
  switch(shape){case 0:memset(a,0,n*8);break;case 1:memset(a,0,n*8);a[0]=1;break;case 2:memcpy(b,a,n*8);break;
   case 3:a[n-1]|=1ull<<63;b[n-1]=a[n-1]-1;break;case 4:a[n-1]>>=1;b[n-1]|=1ull<<63;break;
   case 5:memset(b,0,n*8);b[0]=1;break;case 6:memset(b,0,n*8);b[0]=0xfffffffbu;break;
   case 7:memset(b+n/2,0,(n-n/2)*8);b[0]|=1;break;case 8:memset(b,0,n*8);b[n/2]=(uint64_t)1<<(n%64);break;
   case 9:memset(a,0xff,n*8);memset(b,0,n*8);b[0]=0x8000000000000001ull;break;
   case 10:memset(a,0,n*8);memset(b,0,n*8);a[0]=113;b[0]=13;break;}
  mpz_import(aa,n,-1,8,0,0,a);mpz_import(bb,n,-1,8,0,0,b);mpz_tdiv_qr(qq,rr,aa,bb);
  double ht=timed(production,q,r,a,b,n,1,0);
  mpz_import(qout,n,-1,8,0,0,q);mpz_import(rout,n,-1,8,0,0,r);
  if(mpz_cmp(qout,qq)||mpz_cmp(rout,rr)){fprintf(stderr,"GMP mismatch %u %u\n",n,shape);return 1;}
  unsigned hr=batch(ht);
  uint64_t budget=(uint64_t)(2.5*ht+8000000);
  double bt=timed(original,q,r,a,b,n,1,budget);unsigned br=bt>0?batch(bt):1;
  if(bt>0){mpz_import(qout,n,-1,8,0,0,q);mpz_import(rout,n,-1,8,0,0,r);if(mpz_cmp(qout,qq)||mpz_cmp(rout,rr))return 1;}
  unsigned rounds=ht>50000000?3:7;
  for(unsigned k=0;k<rounds;k++){
   // The sign records a baseline interrupted after its monotonic timer expired. Only complete calls are timed for head.
   if((k+n+shape)%2==0)ht=timed(production,q,r,a,b,n,hr,0);
   if(k>0 || bt>0)bt=timed(original,q,r,a,b,n,br,budget);
   if((k+n+shape)%2!=0)ht=timed(production,q,r,a,b,n,hr,0);
   printf("%u %u %u %u %u %.2f %.2f\n",n,shape,k,br,hr,bt,ht);fflush(stdout);
  }
 }
 timer_delete(timer);mpz_clears(aa,bb,qq,rr,qout,rout,NULL);free(a);free(b);free(q);free(r);return 0;
}
