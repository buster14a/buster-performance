from pathlib import Path
p=Path(__file__).parent
mutations={
 'borrow-boundary':('((generate << 1) | *borrow)','(generate << 1)'),
 'high-columns':('_mm256_alignr_epi32(upper, previous, 7)','_mm256_alignr_epi32(upper, previous, 6)'),
 'top-product':(' - low_borrow - high_borrow',' - low_borrow'),
 'one-correction':('while (balance < 0)','if (balance < 0)'),
 'carry-boundary':('((generate << 1) | carry)','(generate << 1)'),
 'normalize-low':('((uint64_t)following >> (32 - shift))','0'),
 'low-chunk-order':('if ((greater | less) != 0)','if (order == 0 && (greater | less) != 0)'),
 'quotient-position':('quot[j] = digit;','quot[0] = digit;'),
 'tail-read':('_mm256_maskz_loadu_epi32(live, divisor + i)','_mm256_loadu_si256((const __m256i*)(divisor + i))'),
}
s=(p/'production.c').read_text();d=p/'faults';d.mkdir(exist_ok=True)
for name,(old,new) in mutations.items():
 assert s.count(old)==1,(name,s.count(old));(d/(name+'.c')).write_text(s.replace(old,new))
f=p/'oracle.py';s=f.read_text().replace(' if n<128:',""" if n>=3:
  patterns.extend([(0x881ff996d618e75655df97bb43ad9e8b,0xb72c562d706643cdb893ef3a),(0xdca73590ea673c14272af3b981fdd45c,0xe00404b8f53bf78d20f8f21a)])
 if n==17:
  # A two-unit overestimate whose restoration carries across a 16-digit boundary.
  scale=1<<(32*15)
  patterns.extend([(0xdca73590ea673c14272af3b981fdd45c*scale+k,0xe00404b8f53bf78d20f8f21a*scale+1) for k in (0,1,2**31)])
 if n<128:""")
(p/'corrections.py').write_text(s)
