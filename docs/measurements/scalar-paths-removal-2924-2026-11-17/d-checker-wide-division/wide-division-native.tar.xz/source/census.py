from pathlib import Path
p=Path('src/buster/compiler/c_check_wide.c');s=p.read_text();i=s.index('// quotient and remainder (')
s=s[:i]+'''#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
static uint64_t* wide_division_counts;
__attribute__((constructor)) static void wide_division_attach(void)
{
    const char* file = getenv("BUSTER_WIDE_DIVISION_COUNTS");
    if (file != NULL)
    {
        const int fd = open(file, O_RDWR | O_CLOEXEC);
        if (fd >= 0)
        {
            void* data = mmap(NULL, 64, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
            if (data != MAP_FAILED) wide_division_counts = data;
            close(fd);
        }
    }
}
'''+s[i:]
i=s.index('\n{',s.index('static void check_wide_divide('))+2
s=s[:i]+'''
    if (wide_division_counts != NULL)
    {
        const uint32_t a_bits = check_wide_bits(a, count);
        const uint32_t b_bits = check_wide_bits(b, count);
        __atomic_fetch_add(wide_division_counts, 1, __ATOMIC_RELAXED);
        __atomic_fetch_add(wide_division_counts + 1, count, __ATOMIC_RELAXED);
        __atomic_fetch_add(wide_division_counts + 2, a_bits, __ATOMIC_RELAXED);
        __atomic_fetch_add(wide_division_counts + 3, b_bits, __ATOMIC_RELAXED);
        __atomic_fetch_add(wide_division_counts + 4, b_bits <= 64, __ATOMIC_RELAXED);
        __atomic_fetch_add(wide_division_counts + 5, a_bits < b_bits, __ATOMIC_RELAXED);
        __atomic_fetch_add(wide_division_counts + 6, a_bits == 0, __ATOMIC_RELAXED);
        uint64_t max=__atomic_load_n(wide_division_counts+7,__ATOMIC_RELAXED);
        while (max < count && !__atomic_compare_exchange_n(wide_division_counts+7,&max,count,true,__ATOMIC_RELAXED,__ATOMIC_RELAXED)) {}
    }
'''+s[i:];p.write_text(s)
