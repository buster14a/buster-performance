from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
p=Path(__file__).parent;f='src/buster/compiler/dominators.c'
s=(p/'tree'/f).read_text();script=Path('/tmp/buster-dominators/dfs-cursors.py').read_text().split('for name,fr,lf,gr')[0].replace('static uint32_t dominators_order(','static void dominators_order(')
scope={'__file__':str(p/'active-cursor.py')};exec(script,scope)
s=scope['make'](s,True,False,False)
(p/'cursor-dominators.c').write_text(s);base=check_output(['git','show','cc7d4ffb4:'+f],cwd=p/'tree').decode()
(p/'cursor.patch').write_text(''.join(unified_diff(base.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f)))
for n in ['build-sources','measure-sources','ordinary-sources','sources-corpus']:
 s=(p/n).read_text().replace('sources','cursor')
 if n.startswith('build'):
  a=s.index('lock=');b=s.index('"$lock" timeout',a)
  s=s[:a]+'''lock="$HOME/buster-fast-bench/exclusive.sh"
prior=/dev/shm/buster-burs-rules-6b097f86
until [[ -f "$prior/calls-capture-built.ok" ]];do sleep 3;done
cd "$ir/src"
git apply -R "$prior/capture.patch"
git apply -R "$prior/calls.patch"
git diff --exit-code -- src
git apply "$root/cursor.patch"
'''+s[b:]
  s=s.replace('./build.sh --config Release >','./build.sh --config Release --jobs 4 >')
 (p/n.replace('sources','cursor')).write_text(s)
