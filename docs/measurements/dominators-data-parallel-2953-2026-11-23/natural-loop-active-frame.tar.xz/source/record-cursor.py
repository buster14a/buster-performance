from pathlib import Path
from statistics import median
import tarfile,sys,re
p=Path(__file__).parent;r=p/'results';s=(p/'record.py').read_text()
exec(s[:s.index('tags=')])
m={key:measure('cursor','natural-cursor',key) for key in ('loops','all','synthetic')};w=whole('cursor')
for seed in [174,1,133,789]:assert re.search(r'^dominators: \d+ checks, 0 failures',(r/f'cursor-frozen-{seed}.log').read_text(),re.M)
for g,summary in [('sqlite','5204 checks=22641582'),('fixture','16 checks=2637')]:
 assert 'forms='+summary+' failed=0 excluded=0 passed' in (r/f'cursor-producer-{g}.log').read_text()
title='## Holding the active depth-first frame in registers'
f=out/'README.md';body=f.read_text();assert title not in body
fmt=lambda v:f'{(v-1)*100:+.3f}%'
rs=[]
for k in m['loops']:rs.append(f'| {k} | {fmt(m["loops"][k][0])} | {fmt(m["all"][k][0])} |')
sy=['| '+k+' | '+' | '.join(fmt(m['synthetic'][k+' '+key][0])for key in ('tree','loops','all'))+' |'for k in dict.fromkeys(x.split()[0]for x in m['synthetic'])]
wh=['| '+k+' | '+' | '.join(v)+' |'for k,v in w.items()]
with tarfile.open(out/'natural-loop-active-frame.tar.xz','w:xz',preset=2)as t:
 for n in ['active-cursor.py','cursor.patch','build-cursor','measure-cursor','input-ordinary-cursor','cursor-corpus','record.py','record-cursor.py']:t.add(p/n,'source/'+n)
 t.add(Path('/tmp/buster-dominators/dfs-cursors.py'),'source/dfs-cursors.py')
 for n in r.glob('cursor-*'):t.add(n,'native/'+n.name)
f.write_text(body.rstrip()+'\n\n'+title+'''

DFS keeps the current block and its successor cursor in local variables. It saves a frame on descent and reads it back when the child completes. The resulting Release compiler passed four frozen seeds. Its SQLite producer passed 22,641,582 checks across 5,204 graphs. All nineteen SQLite sets improved over the parent for both loop analysis and complete analysis.

| SQLite set | Loop analysis | Complete analysis |
| --- | ---: | ---: |
'''+'\n'.join(rs)+'''

Three paired runs measured each synthetic case. The loop phase met the parent for every shape. Complete analysis on a ladder and tree analysis on two graphs still cost more.

| Synthetic graph | Tree | Loops | All outputs |
| --- | ---: | ---: | ---: |
'''+'\n'.join(sy)+'''

All 2,742 debug objects, diagnostics and standard output matched. Each ordinary compiler cell is the median change in user cycles across five pairs of three processes per side.

| Corpus | Default passes | All passes |
| --- | ---: | ---: |
'''+'\n'.join(wh)+'''

[Release source, native measurements, tests and output digests](natural-loop-active-frame.tar.xz)
''')
print(*wh,sep='\n')
