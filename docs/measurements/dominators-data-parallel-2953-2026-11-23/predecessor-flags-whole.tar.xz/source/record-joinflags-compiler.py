from pathlib import Path
from statistics import median
import tarfile,re
p=Path(__file__).parent;r=p/'results'
src=Path('/tmp/buster-dom-loops/record.py').read_text();exec(src[src.index('def whole('):src.index('tags=')])
rows=whole('joinflags')
d=Path('/workspace/buster-performance/docs/measurements/dominators-data-parallel-2953-2026-11-23')
f=d/'README.md';title='## Whole compilation with predecessor flags'
assert title not in f.read_text()
body=title+'''

Each cell compares five paired rounds of three complete single-lane compiler processes. The instrument-free compilers produced the same debug objects on all 1,371 translation units with each pass configuration. Their stdout and diagnostics also matched. The figures are median paired changes in user cycles on the 9700X.

| Corpus | Default passes | All passes |
| --- | ---: | ---: |
'''+ '\n'.join('| '+k+' | '+' | '.join(v)+' |' for k,v in rows.items())+'\n\n[Command, object manifests and full native samples](predecessor-flags-whole.tar.xz)\n'
with tarfile.open(d/'predecessor-flags-whole.tar.xz','w:xz',preset=2) as t:
 for name in ['joinflags.patch','joinflags-corpus','ordinary-joinflags','record-joinflags-compiler.py']:t.add(p/name,'source/'+name)
 t.add('/tmp/buster-dom-loops/record.py','source/ordinary-ratios.py')
 for pat in ['joinflags-compile-*.log','joinflags-objects-*.sha']:
  for file in sorted(r.glob(pat)):t.add(file,'native/'+file.name)
with f.open('a')as stream:stream.write('\n'+body)
print(rows)
