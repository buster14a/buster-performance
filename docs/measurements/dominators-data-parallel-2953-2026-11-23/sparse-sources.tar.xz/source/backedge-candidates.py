from pathlib import Path
from difflib import unified_diff
p=Path(__file__).parent;f=Path('buster/compiler/dominators.c');base=(p/'tree/src'/f).read_text()
for tag in ('sourcebits','targetbits','targetcount','backrpo'):
 s=base
 # Publishing the postorder slot as soon as it is finished distinguishes a discovered ancestor from a finished block.
 a=s.index('            result->rpo[finished] = frame->block;');b=s.index('\n}',a)
 s=s[:a]+'''            const uint32_t order = count - 1 - finished;
            result->rpo[order] = frame->block;
            result->rpo_index[frame->block] = order;
            finished += 1;
'''+('            dfs_end[frame->block] = entered;\n' if tag=='backrpo' else '')+'''            depth -= 1;
        }
    }
    result->reachable_count = finished;
    if (finished != count)
    {
        memmove(result->rpo, result->rpo + (count - finished), (uint64_t)finished * sizeof(uint32_t));
        for (uint32_t i = 0; i < finished; ++i)
        {
            result->rpo_index[result->rpo[i]] = i;
        }
        memset(result->rpo + finished, 0xff, (uint64_t)(count - finished) * sizeof(uint32_t));
    }'''+s[b:]
 if tag!='backrpo':
  source=tag=='sourcebits';endpoint='frame->block' if source else 'target'
  s=s.replace('uint32_t* dfs_end','uint64_t* back_edges').replace('dfs_begin, dfs_end','dfs_begin, back_edges')
  s=s.replace('memset(dfs_end, 0xff, (uint64_t)count * sizeof(uint32_t));','if (back_edges != NULL) memset(back_edges, 0, ((uint64_t)count + 63) / 64 * sizeof(uint64_t));')
  a=s.index('                depth += 1;',s.index('static void dominators_order('));b=s.index('\n        }',a)
  s=s[:b]+'''
            else if (back_edges != NULL && result->rpo_index[target] == BUSTER_DOMINATOR_NONE)
            {
                const uint32_t endpoint = '''+endpoint+''';
                back_edges[endpoint / 64] |= UINT64_C(1) << (endpoint % 64);
            }'''+s[b:]
  s=s.replace('dfs_end = arena_push_array(scratch, count, sizeof(uint32_t), _Alignof(uint32_t));','''if ((options.outputs & BUSTER_DOMINATOR_LOOPS) != 0)
            {
                back_edges = arena_push_array(scratch, ((uint64_t)count + 63) / 64, sizeof(uint64_t), _Alignof(uint64_t));
            }''').replace('|| dfs_end == 0 ||','|| ((options.outputs & BUSTER_DOMINATOR_LOOPS) != 0 && back_edges == NULL) ||')
  a=s.index('    for (uint32_t order',s.index('static void dominators_components'));b=s.index('    if (witness_count == 0)',a)
  t='''    for (uint64_t first = 0; first < cfg->block_count; first += 64)
    {
        uint64_t bits = back_edges[first / 64];
        while (bits != 0)
        {
            const uint32_t endpoint = (uint32_t)first + (uint32_t)__builtin_ctzll(bits);
            bits &= bits - 1;
            bool irregular = false;
'''
  if source:t+='''            const uint32_t block = endpoint;
            for (uint32_t edge = cfg->successor_offsets[block]; edge < cfg->successor_offsets[(uint64_t)block + 1]; ++edge)
            {
                const uint32_t target = cfg->successors[edge];
'''
  else:t+='''            const uint32_t target = endpoint;
            bool natural = false;
            for (uint32_t edge = cfg->predecessor_offsets[target]; edge < cfg->predecessor_offsets[(uint64_t)target + 1]; ++edge)
            {
                const uint32_t block = cfg->predecessors[edge];
'''
  guard='' if source else 'result->rpo_index[block] != BUSTER_DOMINATOR_NONE && '
  t+='''                if ('''+guard+'''dfs_begin[target] <= dfs_begin[block] && result->rpo_index[target] <= result->rpo_index[block])
                {
                    const bool dominates = result->preorder[target] <= result->preorder[block] && result->preorder[block] < result->subtree_end[target];
'''+('                    if (dominates) headers[target] = 1;\n' if source else '                    natural |= dominates;\n')+'''                    irregular |= !dominates;
                }
            }
'''
  if not source:t+='''            headers[target] = natural;
'''+('            result->loop_count += natural;\n' if tag=='targetcount' else '')
  t+='''            if (irregular) witnesses[witness_count++] = endpoint;
        }
    }
'''
  s=s[:a]+t+s[b:]
 if tag=='targetcount':
  a=s.index('        for (uint32_t block = 0; block < count; block += 1)',s.index('        dominators_components('));b=s.index('        memset(result->loop_depth',a);s=s[:a]+s[b:]
 s=s.replace('        memset(result->loop_depth, 0, (uint64_t)count * sizeof(uint32_t));','        if (result->loop_count == 0) memset(result->loop_depth, 0, (uint64_t)count * sizeof(uint32_t));')
 d=p/tag/f;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(s)
 raw=(p/'tree').joinpath('src',f);import subprocess
 orig=subprocess.check_output(['git','show','cc7d4ffb4:src/'+str(f)],cwd=p/'tree').decode()
 (p/(tag+'.patch')).write_text(''.join(unified_diff(orig.splitlines(True),s.splitlines(True),'a/src/'+str(f),'b/src/'+str(f))))
s=Path('/tmp/buster-dominators/threshold-bench').read_text().replace('thresholds thresholdbits lowerlinks lowerjumps','sourcebits targetbits targetcount backrpo').replace('lowerjumps lowerlinks thresholdbits thresholds','backrpo targetcount targetbits sourcebits').replace('threshold-','edge-').replace('tree all synthetic','loops all synthetic')
(p/'edge-bench').write_text(s)
