from pathlib import Path
from statistics import median
import re,tarfile,sys
p=Path(__file__).parent;r=p/'results';dom=Path('/tmp/buster-dominators')
base=(p/'record.py').read_text();exec(base[:base.index('tags=')])
cur={m:measure('sources','natural-sources',m)for m in ['loops','all','synthetic']};debug=whole('sources')
def pct(f):return f'{100*(f-1):+.2f}%'
assert all(v[0]<1 for m in ('loops','all')for v in cur[m].values())
assert all(v[0]<1 for k,v in cur['synthetic'].items()if not k.endswith(' tree'))
for seed in [174,1,133,789]:
 s=(r/f'sources-frozen-{seed}.log').read_text();assert re.search(r'^dominators: \d+ checks, 0 failures',s,re.M)
for group,n,c in [('sqlite',5204,22641582),('fixture',16,2637)]:
 assert f'dominators forms={n} checks={c} failed=0 excluded=0 passed' in (r/f'sources-producer-{group}.log').read_text()
body='''## Sparse back-edge sources

DFS now marks a source when an outgoing edge reaches a discovered vertex that has not finished. The mask takes one bit per block and is allocated only for loop output. A candidate target is an ancestor when its preorder and reverse postorder are both at most the source’s. The analysis scans the outgoing edges of marked sources to identify natural headers and irreducibility witnesses. A reverse component walk runs only if a witness was found.

All rows below are median ratios from three alternating pairs on the locked 9700X against the same uninstrumented parent. Each pair processed 5,204 current-form SQLite graphs. The four standalone prototypes mark source blocks, target blocks, target counts, or use reverse postorder directly. Their raw runs are included for comparison.

| SQLite set | Loops | All outputs |
| --- | ---: | ---: |
'''+'\n'.join('| '+k+' | '+pct(v[0])+' | '+pct(cur['all'][k][0])+' |'for k,v in cur['loops'].items())+'''

| Synthetic shape | Tree | Loops | All outputs |
| --- | ---: | ---: | ---: |
'''+'\n'.join('| '+k+' | '+' | '.join(pct(cur['synthetic'][k+' '+m][0])for m in ['tree','loops','all'])+' |'for k in dict.fromkeys(k.split()[0]for k in cur['synthetic']))+'''

Complete Tier 1 debug compilations ran five pairs of three processes per configuration and corpus. All 1,371 objects in each configuration, standard output and diagnostics matched. The shipping executable passed 46,597,151 checks at seed 174 and seeds 1, 133 and 789. Its SQLite producer passed 22,641,582 checks on 5,204 forms and the checked-in IR producer passed 2,637 on 16 forms.

| Workload | Default | All passes |
| --- | ---: | ---: |
'''+'\n'.join('| '+k+' | '+' | '.join(v)+' |'for k,v in debug.items())+'''

[Sparse-source changes, four prototypes, native commands, outputs and raw timing](sparse-sources.tar.xz)
'''
with tarfile.open(out/'sparse-sources.tar.xz','w:xz',preset=2)as t:
 for name in ('sparse-sources.patch','sourcebits.patch','targetbits.patch','targetcount.patch','backrpo.patch','backedge-candidates.py','ship-sources.py','build-sources','measure-sources','sources-corpus','ordinary-sources','edge-bench','record.py','record-sources.py'):t.add(p/name,arcname='source/'+name)
 for f in sorted(r.glob('sources-*')):t.add(f,arcname='native/'+f.name)
 for f in sorted((dom/'results').glob('edge-*.log')):t.add(f,arcname='prototypes/'+f.name)
file=out/'README.md';file.write_text(file.read_text().split('\n## Sparse back-edge sources')[0].rstrip()+'\n\n'+body)
print('total',cur['loops']['all'],cur['all']['all'],debug)
