from pathlib import Path
from difflib import unified_diff
import subprocess
p=Path(__file__).parent;f=Path('buster/compiler/dominators.c')
s=(p/'sourcebits'/f).read_text().replace('back_edges','back_edge_sources')
s=s.replace('// One DFS from entry: each block\'s preorder number (dfs_begin) and subtree end, each number\'s block and DFS parent\n// number, and RPO.', '''// Number reachable blocks in DFS preorder and reverse postorder. When loops are requested, retain the
// sources of edges to discovered, unfinished ancestors. Their outgoing edges will classify all loop headers.''')
s=s.replace('    if (back_edge_sources != NULL) memset(back_edge_sources, 0, ((uint64_t)count + 63) / 64 * sizeof(uint64_t));','''    if (back_edge_sources != NULL)
    {
        memset(back_edge_sources, 0, ((uint64_t)count + 63) / 64 * sizeof(uint64_t));
    }''')
s=s.replace('                const uint32_t endpoint = frame->block;\n                back_edge_sources[endpoint / 64] |= UINT64_C(1) << (endpoint % 64);','''                back_edge_sources[frame->block / 64] |= UINT64_C(1) << (frame->block % 64);''')
s=s.replace('            const uint32_t endpoint = (uint32_t)first + (uint32_t)__builtin_ctzll(bits);','            const uint32_t block = (uint32_t)first + (uint32_t)__builtin_ctzll(bits);').replace('            const uint32_t block = endpoint;\n','')
s=s.replace('                if (dfs_begin[target] <= dfs_begin[block] && result->rpo_index[target] <= result->rpo_index[block])','''                // A DFS ancestor precedes the source in both orders. An earlier sibling follows it in RPO.
                if (dfs_begin[target] <= dfs_begin[block] && result->rpo_index[target] <= result->rpo_index[block])''')
s=s.replace('                    if (dominates) headers[target] = 1;','''                    if (dominates)
                    {
                        headers[target] = 1;
                    }''').replace('            if (irregular) witnesses[witness_count++] = endpoint;','''            if (irregular)
            {
                witnesses[witness_count++] = block;
            }''').replace('        if (result->loop_count == 0) memset(result->loop_depth, 0, (uint64_t)count * sizeof(uint32_t));','''        if (result->loop_count == 0)
        {
            memset(result->loop_depth, 0, (uint64_t)count * sizeof(uint32_t));
        }''')
d=p/'shipping-sources'/f;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(s)
orig=subprocess.check_output(['git','show','cc7d4ffb4:src/'+str(f)],cwd=p/'tree').decode()
(p/'sparse-sources.patch').write_text(''.join(unified_diff(orig.splitlines(True),s.splitlines(True),'a/src/'+str(f),'b/src/'+str(f))))
s=(p/'build-final').read_text();a=s.index('until [[')if 'until [['in s else s.index('test -f');b=s.index('"$lock" timeout',a)
s=s[:a]+'''previous=/dev/shm/buster-lexer-prefixes-6b097f86
test -f "$previous/guarded-built.ok"
cd "$ir/src"
git apply -R "$previous/guarded.patch"
git diff --exit-code -- src
git apply "$root/sparse-sources.patch"
'''+s[b:]
for a,b in [('natural-final','natural-sources'),('final-','sources-')]:s=s.replace(a,b)
(p/'build-sources').write_text(s)
for a,b in [('measure-final','measure-sources'),('final-corpus','sources-corpus'),('ordinary-final','ordinary-sources')]:
 s=(p/a).read_text().replace('natural-final','natural-sources').replace('final-','sources-');(p/b).write_text(s)
