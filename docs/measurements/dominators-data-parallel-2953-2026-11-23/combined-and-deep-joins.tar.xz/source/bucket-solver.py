from pathlib import Path
p=Path(__file__).parent;f=Path('buster/compiler/dominators.c')
for name in ('buckets','activebuckets','pairlabels'):
 s=(p/'compacttree'/f).read_text();a=s.index('// The least semidominator');b=s.index('static bool dominators_bit(',a)
 helper='''// Return the vertex with the least semidominator on the processed portion of this DFS path.
// Compression keeps its representative vertex so a bucket query can later resolve an idom.
static uint32_t dominators_minimum_label(DominatorLink* links, const uint32_t* semi, uint32_t* stack, uint32_t number, uint32_t processed)
{
    uint32_t top = number;
    uint32_t depth = 0;
    while (links[top].ancestor >= processed)
    {
        stack[depth++] = top;
        top = links[top].ancestor;
    }
    const uint32_t root = links[top].ancestor;
    uint32_t label = links[top].least;
    while (depth != 0)
    {
        DominatorLink* link = links + stack[--depth];
        const uint32_t other = link->least;
        if (semi[other] < semi[label])
        {
            label = other;
        }
        link->ancestor = root;
        link->least = label;
    }
    return label;
}

// Solve semidominators and the Lengauer-Tarjan deferred idoms in the same descending pass.
// A join whose semidominator differs from its parent asks for the minimum label on the path
// up to (excluding) its semidominator. At that threshold all the relevant labels are final.
static void dominators_semi_nca(const DominatorCfg* cfg, Dominators* result, const uint32_t* dfs_begin, const uint32_t* vertices,
                                uint32_t* parents, uint32_t* semi, DominatorLink* links, uint32_t* stack, const uint32_t* joins, uint32_t join_count)
{
    const uint32_t reachable = result->reachable_count;
    uint32_t* bucket = result->preorder;
    uint32_t* next = result->subtree_end;
    memset(bucket, 0, (uint64_t)reachable * sizeof(uint32_t));
    const __m256i lanes = _mm256_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7);
    for (uint64_t i = 0; i < reachable; i += 8)
    {
        const uint32_t count = reachable - i < 8 ? (uint32_t)(reachable - i) : 8;
        const __mmask8 valid = (__mmask8)((1u << count) - 1);
        const __m256i parent = _mm256_maskz_loadu_epi32(valid, parents + i);
        const __m256i numbers = _mm256_add_epi32(_mm256_set1_epi32((int32_t)i), lanes);
        _mm256_mask_storeu_epi32(semi + i, valid, parent);
        const __m512i ancestors = _mm512_cvtepu32_epi64(parent);
        const __m512i labels = _mm512_slli_epi64(_mm512_cvtepu32_epi64(numbers), 32);
        _mm512_mask_storeu_epi64(links + i, valid, _mm512_or_si512(ancestors, labels));
    }
    uint32_t pending = join_count;
    for (uint32_t cursor = reachable; cursor != 0;)
    {
        const uint32_t number = --cursor;
        if (pending != 0 && joins[pending - 1] == number)
        {
            pending -= 1;
            const uint32_t block = vertices[number];
            uint32_t least = parents[number];
            for (uint32_t edge = cfg->predecessor_offsets[block]; least != 0 && edge < cfg->predecessor_offsets[(uint64_t)block + 1]; edge += 1)
            {
                const uint32_t source = dfs_begin[cfg->predecessors[edge]];
                if (source != BUSTER_DOMINATOR_NONE)
                {
                    const uint32_t candidate = source <= number ? source : semi[dominators_minimum_label(links, semi, stack, source, number + 1)];
                    least = candidate < least ? candidate : least;
                }
            }
            semi[number] = least;
            if (least != parents[number])
            {
                next[number] = bucket[least];
                bucket[least] = number;
            }
        }
        for (uint32_t item = bucket[number]; item != 0; item = next[item])
        {
            const uint32_t label = dominators_minimum_label(links, semi, stack, item, number + 1);
            parents[item] = semi[label] < number ? label : number;
        }
    }
    // A deferred label is a strict DFS ancestor, so its own idom is already final.
    for (uint32_t i = 0; i < join_count; i += 1)
    {
        const uint32_t number = joins[i];
        const uint32_t label = parents[number];
        result->idom[vertices[number]] = label == semi[number] ? vertices[label] : result->idom[vertices[label]];
    }
}

'''
 if name=='activebuckets':
  helper=helper.replace('    uint32_t pending = join_count;', '''    // Each set bit is a join or a threshold with waiting descendants. tree_offsets is still scratch.
    uint32_t* active = result->tree_offsets;
    memset(active, 0, ((uint64_t)reachable + 31) / 32 * sizeof(uint32_t));
    for (uint32_t i = 0; i < join_count; i += 1)
    {
        active[joins[i] / 32] |= 1u << (joins[i] % 32);
    }
    uint32_t pending = join_count;''')
  helper=helper.replace('    for (uint32_t cursor = reachable; cursor != 0;)\n    {\n        const uint32_t number = --cursor;', '''    for (uint64_t words = ((uint64_t)reachable + 31) / 32; words != 0;)
    {
        const uint32_t word = (uint32_t)--words;
        while (active[word] != 0)
        {
        const uint32_t bit = 31u - (uint32_t)__builtin_clz(active[word]);
        active[word] ^= 1u << bit;
        const uint32_t number = word * 32 + bit;''').replace('                next[number] = bucket[least];','                active[least / 32] |= 1u << (least % 32);\n                next[number] = bucket[least];').replace('    // A deferred label','    }\n    // A deferred label')
 if name=='pairlabels':
  x=helper.index('    uint32_t top = number;');y=helper.index('\n}',x)
  helper=helper[:x]+'''    uint32_t label = links[number].least;
    for (;;)
    {
        const DominatorLink node = links[number];
        if (semi[node.least] < semi[label]) label = node.least;
        if (node.ancestor < processed) break;
        const DominatorLink parent = links[node.ancestor];
        const uint32_t pair = semi[parent.least] < semi[node.least] ? parent.least : node.least;
        links[number] = (DominatorLink){ .ancestor = parent.ancestor, .least = pair };
        if (semi[pair] < semi[label]) label = pair;
        if (parent.ancestor < processed) break;
        number = parent.ancestor;
    }
    return label;'''+helper[y:]
 s=s[:a]+helper+s[b:];d=p/name/f;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(s)
s=(p/'dfs-bench').read_text().replace('treeback compacttree halftree compacthalf parenttree','buckets activebuckets pairlabels').replace('parenttree compacthalf halftree compacttree treeback','pairlabels activebuckets buckets').replace('dfs-','bucket-')
(p/'bucket-bench').write_text(s)
