from pathlib import Path
p=Path(__file__).parent; f=Path('buster/compiler/dominators.c');parent=(p/'compacttree'/f).read_text()
start=parent.index('    for (uint32_t j = 0; j < join_count; j += 1)',parent.index('static void dominators_semi_nca'));end=parent.index('\n}',start)
for name in ['thresholds','thresholdbits','lowerlinks','lowerjumps']:
 dsu=name.startswith('threshold')
 init='''    uint32_t depth = 0;
    // Only a vertex whose semidominator differs from its DFS parent can cross
    // a threshold lying strictly between the two ends of an ancestor path.
'''
 if dsu:
  init+='''    uint32_t exceptions = 0;
    uint32_t* bucket = result->preorder;
    uint32_t* next = result->subtree_end;
    memset(bucket, 0, (uint64_t)reachable * sizeof(uint32_t));
    uint32_t limit = 0;
    links[0].ancestor = 0;
'''
  if name=='thresholdbits':init+='''    uint32_t* active = result->tree_offsets;
    memset(active, 0, ((uint64_t)reachable + 31) / 32 * sizeof(uint32_t));
'''
 else:
  init+='''    links[0] = (DominatorLink){0};
    result->tree_offsets[0] = 0;
'''
 init+='''    for (uint32_t j = 0; j < join_count; j += 1)
    {
        const uint32_t number = joins[j];
        const uint32_t threshold = semi[number];
        if (threshold == parents[number]) continue;
        while (depth && dfs_end[vertices[stack[depth - 1]]] <= number) --depth;
        const uint32_t ancestor = depth ? stack[depth - 1] : 0;
        stack[depth++] = number;
'''
 if dsu:
  init+='''        links[number].least = ancestor;
        links[number].ancestor = number;
        next[number] = bucket[threshold];
        bucket[threshold] = number;
        if (threshold > limit) limit = threshold;
        joins[exceptions++] = number;
'''
  if name=='thresholdbits':init+='''        active[threshold / 32] |= 1u << (threshold % 32);
'''
  init+='''    }
    // Throughout a threshold's queries its live representatives are exactly
    // the exceptional vertices whose semidominators are strictly smaller.
    for (uint64_t cursor = (uint64_t)limit + 1; cursor != 0;)
    {
        const uint32_t threshold = (uint32_t)--cursor;
        for (uint32_t v = bucket[threshold]; v; v = next[v])
        {
            links[v].ancestor = links[v].least;
        }
        for (uint32_t v = bucket[threshold]; v; v = next[v])
        {
            uint32_t x = links[v].ancestor;
            while (x != links[x].ancestor)
            {
                x = links[x].ancestor = links[links[x].ancestor].ancestor;
            }
            parents[v] = x > threshold ? x : 0;
        }
    }
    for (uint32_t j = 0; j < exceptions; ++j)
    {
        const uint32_t v = joins[j];
        const uint32_t witness = parents[v];
        result->idom[vertices[v]] = witness ? result->idom[vertices[witness]] : vertices[semi[v]];
    }'''
  if name=='thresholdbits':
   init=init.replace('    for (uint64_t cursor = (uint64_t)limit + 1; cursor != 0;)\n    {\n        const uint32_t threshold = (uint32_t)--cursor;', '''    for (uint64_t word = (uint64_t)limit / 32 + 1; word != 0;)
    {
        uint32_t bits = active[--word];
        while (bits)
        {
        const uint32_t bit = 31u - (uint32_t)__builtin_clz(bits);
        bits ^= 1u << bit;
        const uint32_t threshold = (uint32_t)(32 * word + bit);''').replace('    for (uint32_t j = 0; j < exceptions;', '    }\n    for (uint32_t j = 0; j < exceptions;')
 else:
  init+='''        uint32_t lower = ancestor;
        if (threshold == 0) lower = 0;
        while (lower != 0 && semi[lower] >= threshold)
        {
            lower = links[lower].ancestor;
        }
        result->idom[vertices[number]] = lower > threshold ? result->idom[vertices[lower]] : vertices[threshold];
        links[number].ancestor = lower;
'''
  if name=='lowerjumps':
   init=init.replace('            lower = links[lower].ancestor;', '''            const uint32_t skip = links[lower].least;
            lower = skip != 0 && semi[skip] >= threshold ? skip : links[lower].ancestor;''')+'''        const uint32_t skip = links[lower].least;
        const uint32_t twice = links[skip].least;
        const uint32_t* levels = result->tree_offsets;
        links[number].least = levels[lower] - levels[skip] == levels[skip] - levels[twice] ? twice : lower;
        result->tree_offsets[number] = levels[lower] + 1;
'''
  init+='    }'
 s=(parent[:start]+init+parent[end:]).replace('Dominators* result, const uint32_t* dfs_begin, const uint32_t* vertices, uint32_t* parents, uint32_t* semi','Dominators* result, const uint32_t* dfs_begin, const uint32_t* dfs_end, const uint32_t* vertices, uint32_t* parents, uint32_t* semi').replace('uint32_t* stack, const uint32_t* joins, uint32_t join_count)','uint32_t* stack, uint32_t* joins, uint32_t join_count)').replace('dominators_semi_nca(cfg, &candidate, dfs_begin, dfs_vertex','dominators_semi_nca(cfg, &candidate, dfs_begin, dfs_end, dfs_vertex')
 o=p/name/f;o.parent.mkdir(parents=True,exist_ok=True);o.write_text(s)
s=(p/'bucket-bench').read_text().replace('buckets activebuckets pairlabels','thresholds thresholdbits lowerlinks lowerjumps').replace('pairlabels activebuckets buckets','lowerjumps lowerlinks thresholdbits thresholds').replace('touch bucket-', 'touch threshold-').replace('>"bucket-', '>"threshold-')
(p/'threshold-bench').write_text(s)
s=(p/'measure-deep').read_text().replace('base compacttree buckets activebuckets pairlabels','thresholds thresholdbits lowerlinks lowerjumps').replace('pairlabels activebuckets buckets compacttree base','lowerjumps lowerlinks thresholdbits thresholds').replace('deep-joins.ok','deep-threshold.ok')
(p/'threshold-deep').write_text(s)
