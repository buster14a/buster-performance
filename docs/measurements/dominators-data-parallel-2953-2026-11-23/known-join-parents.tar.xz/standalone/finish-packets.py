from pathlib import Path
p=Path(__file__).parent;f='buster/compiler/dominators.c'
for n in ['earlyroots','skipjoins','rootpack','trimjoins']:
 s=(p/'fusedminimum'/f).read_text().replace('const uint32_t* joins, uint32_t join_count)','uint32_t* joins, uint32_t join_count)')
 idx=s.index('    for (uint32_t j = 0; j < join_count; ++j)',s.index('static void dominators_semi_nca('))
 fin=s[idx:s.index('\n}',idx)]
 core=fin[fin.index('            unsigned steps'):fin.index('\n        }\n        parents[number]')];core='\n'.join(line[4:] for line in core.splitlines())
 tail='''        parents[number] = candidate;
        result->idom[vertices[number]] = vertices[candidate];'''
 if n=='skipjoins':
  s=s[:idx]+s[idx:].replace('        if (limit == 0)','        if (candidate == limit) continue;\n        if (limit == 0)',1)
 elif n=='earlyroots':
  s=s.replace('    for (uint32_t j = join_count; j != 0;)','    uint32_t pending = join_count;\n    for (uint32_t j = join_count; j != 0;)',1)
  s=s.replace('        semi[number] = least;\n        links[number].least = least;','''        links[number].least = least;
        if (least != parents[number])
        {
            if (least == 0)
            {
                parents[number] = 0;
                result->idom[block] = cfg->entry;
            }
            else
            {
                semi[number] = least;
                joins[--pending] = number;
            }
        }''',1)
  s=s.replace(fin,fin[:fin.index('        if (limit == 0)')].replace('j = 0;','j = pending;')+core+'\n'+tail+'\n    }')
 else:
  packet='''    const __m512i zero = _mm512_setzero_si512();
    const __m512i sign = _mm512_set1_epi32(INT32_MIN);
    const void* semi_base = (const void*)((uintptr_t)semi+(UINT64_C(1)<<33));
    void* parent_base = (void*)((uintptr_t)parents+(UINT64_C(1)<<33));
    const void* vertex_base = (const void*)((uintptr_t)vertices+(UINT64_C(1)<<33));
    void* idom_base = (void*)((uintptr_t)result->idom+(UINT64_C(1)<<33));
    for (uint64_t first = 0; first < join_count; first += 16)
    {
        const uint32_t size = join_count-first < 16 ? (uint32_t)(join_count-first) : 16;
        const __mmask16 live = (__mmask16)_bzhi_u32(UINT16_MAX,size);
        const __m512i numbers = _mm512_maskz_loadu_epi32(live,joins+first);
        const __m512i ids = _mm512_xor_si512(numbers,sign);
        const __m512i limit = _mm512_mask_i32gather_epi32(zero,live,ids,semi_base,4);
        const __m512i parent = _mm512_mask_i32gather_epi32(zero,live,ids,parent_base,4);
        const __mmask16 change = _mm512_mask_cmpgt_epu32_mask(live,parent,limit);
        const __mmask16 root = _mm512_mask_cmpeq_epi32_mask(change,limit,zero);
        if (root)
        {
            const __m512i blocks = _mm512_mask_i32gather_epi32(zero,root,ids,vertex_base,4);
            _mm512_mask_i32scatter_epi32(parent_base,root,ids,zero,4);
            _mm512_mask_i32scatter_epi32(idom_base,root,_mm512_xor_si512(blocks,sign),_mm512_set1_epi32((int)cfg->entry),4);
        }
        uint32_t rest = change & ~root;
'''
  if n=='trimjoins':
   packet='    uint32_t pending = 0;\n'+packet+'''        _mm512_mask_compressstoreu_epi32(joins+pending,(__mmask16)rest,numbers);
        pending += (uint32_t)__builtin_popcount(rest);
    }
'''
   packet+=fin[:fin.index('        if (limit == 0)')].replace('j < join_count','j < pending')+core+'\n'+tail+'\n    }'
  else:packet+='''        while (rest)
        {
            const uint32_t lane = (uint32_t)__builtin_ctz(rest);
            rest &= rest-1;
            const uint32_t number = joins[first+lane];
            const uint32_t limit = semi[number];
            uint32_t candidate = parents[number];
'''+core+'\n'+tail+'\n        }\n    }'
  s=s.replace(fin,packet)
 d=p/n/f;d.parent.mkdir(exist_ok=True,parents=True);d.write_text(s)
for src,dest in [('children-bench','finish-bench'),('children-deep','finish-deep')]:
 s=(p/src).read_text()
 for a,b in [('rootrows','earlyroots'),('uniformrows','skipjoins'),('conflictrows','rootpack'),('rootprefix','trimjoins'),('children-','finish-'),('deep-children','deep-finish')]:s=s.replace(a,b)
 (p/dest).write_text(s)
