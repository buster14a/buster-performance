from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
p=Path(__file__).parent;d=Path('/workspace/scratch/buster-2953-bounded-tree');f='src/buster/compiler/dominators.c'
src=(d/f).read_text().replace("Single-entry blocks inherit their\n// parent's immediate dominator.","The DFS parent immediately\n// dominates a block with just one incoming edge.")
s=(Path('/tmp/buster-dominators/skipjoins')/f[4:]).read_text();a=s.index('            const uint32_t source = dfs_begin',s.index('static void dominators_semi_nca('));b=s.index('        semi[number]',a)
a0=src.index('            const uint32_t source = dfs_begin',src.index('static void dominators_semi_nca('));b0=src.index('        semi[number]',a0)
src=src[:a0]+s[a:b]+src[b0:]
src=src.replace('        if (limit == 0)','''        if (candidate == limit)
        {
            // DFS already stored this parent in both representations.
            continue;
        }
        if (limit == 0)''',1)
base=check_output(['git','show','cc7d4ffb4:'+f],cwd=d).decode();(p/'shipping-skipjoins.c').write_text(src);(p/'skipjoins.patch').write_text(''.join(unified_diff(base.splitlines(True),src.splitlines(True),'a/'+f,'b/'+f)))
for name in ['build-fused','history-fused','measure-fused','ordinary-fused','fused-corpus']:
 t=(p/name).read_text().replace('fused','skipjoins').replace('previous/vector-built.ok','previous/once-built.ok').replace('previous/vector.patch','previous/once.patch').replace(' ./build.sh --config Release',' ./build.sh --config Release --jobs 4').replace('>triplets-fixtures.sha','>skipjoins-triplets-fixtures.sha');(p/name.replace('fused','skipjoins')).write_text(t)
