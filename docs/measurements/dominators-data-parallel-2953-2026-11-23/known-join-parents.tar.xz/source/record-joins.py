from pathlib import Path
from statistics import median
import tarfile,re
p=Path(__file__).parent;r=p/'results';dom=Path('/tmp/buster-dominators')
exec((p/'record-combined.py').read_text().split('current=')[0])
from scores import get
s=Path('/tmp/buster-dom-loops/record.py').read_text();exec(s[s.index('def whole('):s.index('tags=')])
d={m:series('skipjoins',m,'unroll-base','dom-skipjoins')for m in ('tree','all','synthetic','loops')}
h={m:series('skipjoins-history',m,'historical','candidate')for m in ('tree','all','synthetic')}
w=whole('skipjoins')
for x in (174,1,133,789):assert '0 failures' in (r/f'skipjoins-frozen-{x}.log').read_text()
assert 'forms=5204 checks=22641582 failed=0' in (r/'skipjoins-producer-sqlite.log').read_text()
synth=[];tables=[]
for n in ('earlyroots','skipjoins','rootpack','trimjoins'):
 vals=[]
 for m in ('tree','all','synthetic'):
  scores,num=get('finish-',m,n);assert num==3;vals.append(f'{sum(v<=1 for v in scores.values())}/{len(scores)}')
 deep=[float((dom/'results'/f'deep-{n}-{i}.tsv').read_text().splitlines()[-1].split()[-1])for i in [1,2,3]]
 tables.append('| '+n+' | '+' | '.join(vals)+f' | {median(deep):.1f} |')
for k in d['synthetic']:synth.append('| '+k+' | '+pct(d['synthetic'][k])+' | '+pct(h['synthetic'][k])+' |')
header='## Resolving already-known join parents'
body=header+'''

The native compiler omits a second ancestor query when DFS has already stored the semidominator as the parent. During predecessor evaluation it also stops reducing a minimum once it reaches the entry block. Four variants passed the 32,769-block independent deep-join fixture. The standalone columns below give the number of groups meeting the matching parent across three paired runs.

| Variant | SQLite tree | SQLite full analysis | Synthetic | Deep case, ticks per block |
| --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(tables)+'''

The complete compiler used the second variant. Every one of the nineteen current SQLite sets improved for tree, loops, and full analysis. Every one of the nineteen historical sets improved for tree and full analysis, as did every historical synthetic comparison. Four frozen seeds passed. On the 5,204-graph SQLite source producer, 22,641,582 checks passed.

| Synthetic graph and analysis | Current parent | Historical scalar |
| --- | ---: | ---: |
'''+'\n'.join(synth)+'''

All six ordinary object manifests, standard outputs and diagnostics matched. Each cell below compares five paired rounds of three full compiler processes.

| Corpus | Default passes | All passes |
| --- | ---: | ---: |
'''+'\n'.join('| '+k+' | '+' | '.join(x)+' |'for k,x in w.items())+'''

[Measured sources, working implementations, raw native runs and object manifests](known-join-parents.tar.xz)
'''
doc=out/'README.md';s=doc.read_text();assert header not in s;doc.write_text(s.rstrip()+'\n\n'+body)
with tarfile.open(out/'known-join-parents.tar.xz','w:xz',preset=2)as t:
 for file in ['skipjoins.patch','shipping-skipjoins.py','build-skipjoins','measure-skipjoins','ordinary-skipjoins','history-skipjoins','skipjoins-corpus','read-triplets.patch','record-joins.py','record-combined.py']:t.add(p/file,'source/'+file)
 for name in ['finish-packets.py','finish-bench','finish-deep','earlyroots','skipjoins','rootpack','trimjoins','deep-joins.c','scores.py']:t.add(dom/name,'standalone/'+name)
 for file in sorted(r.glob('skipjoins-*')):t.add(file,'production/'+file.name)
 for pref in ['finish-','deep-earlyroots-','deep-rootpack-','deep-trimjoins-','deep-skipjoins-']:
  for f in sorted((dom/'results').glob(pref+'*')):t.add(f,'isolated/'+f.name)
print(w);print(*tables,sep='\n')
