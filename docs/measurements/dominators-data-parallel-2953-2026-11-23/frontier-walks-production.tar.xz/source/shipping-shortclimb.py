from pathlib import Path
from difflib import unified_diff
import subprocess
p=Path(__file__).parent
name='src/buster/compiler/dominators.c'
old=subprocess.check_output(['git','show','cc7d4ffb4:'+name],cwd=p/'tree').decode()
s=(p/'shipping-joinflags.c').read_text()
up=(Path('/tmp/buster-dominators/shortclimb')/name[4:]).read_text()
a=s.index("// Each predecessor's walk"); b=s.index('\n}',s.index('static void dominators_frontiers',a))+2
i=up.index("// Each predecessor's walk");j=up.index('\n}',up.index('static void dominators_frontiers',i))+2
assert s.count('dominators_frontiers(cfg, &candidate);')==1
s=(s[:a]+up[i:j]+s[b:]).replace('dominators_frontiers(cfg, &candidate);','dominators_frontiers(cfg, &candidate);')
(p/'shipping-shortclimb.c').write_text(s)
(p/'shortclimb.patch').write_text(''.join(unified_diff(old.splitlines(True),s.splitlines(True),'a/'+name,'b/'+name)))
for f in ['build-joinflags','history-joinflags','measure-joinflags','ordinary-joinflags','joinflags-corpus']:
 s=(p/f).read_text().replace('joinflags','shortclimb').replace('previous/timing-builds-clean.ok','root/upspan-builds-clean.ok').replace('$HOME/buster-fast-bench/1352-claude/sqlite.cfg','$root/historic-sqlite.cfg')
 for im in ['dom-shortclimb','dom-shortclimb-triplets']:
  s=s.replace('ln -L build/compiler build/'+im+'\n',f'cp --preserve=mode build/compiler /tmp/buster-selector-images-6b097f86/{im}\ncmp build/compiler /tmp/buster-selector-images-6b097f86/{im}\nln -s /tmp/buster-selector-images-6b097f86/{im} build/{im}\n')
 (p/f.replace('joinflags','shortclimb')).write_text(s)
