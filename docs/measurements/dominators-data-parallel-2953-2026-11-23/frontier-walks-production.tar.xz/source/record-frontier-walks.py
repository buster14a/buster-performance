from pathlib import Path
from statistics import median
from hashlib import sha256
import re,tarfile
p=Path(__file__).resolve().parent;r=p/'results'
exec((p/'record-combined.py').read_text().split('current=')[0])
tags=['upspan','shortclimb']
tables={};files=[];lines=[];summary=[]
for tag in tags:
 tree={m:series(tag,m,'unroll-base','dom-'+tag)for m in ('tree','loops','all','synthetic')}
 hist={m:series(tag+'-history',m,'historical','candidate')for m in ('tree','all','synthetic')}
 assert all(len(table[m])==(21 if m=='synthetic' else 19)for table in (tree,hist)for m in table)
 for seed in (174,1,133,789):
  f=r/f'{tag}-frozen-{seed}.log';assert re.search(r'^dominators: \d+ checks, 0 failures',f.read_text(),re.M);files.append(f)
 producer=r/f'{tag}-producer-sqlite.log';assert 'forms=5204 checks=22641582 failed=0 excluded=0 passed' in producer.read_text();files.append(producer)
 sha=r/f'{tag}-triplets-fixtures.sha';t=sha.read_text()
 assert '6e60ddafad95813175997cd42db5e2ef686f00d952d4619ab1b97b18b93d14af'in t and 'dde6529090a5641b935330fc8f5632a19651c1999194531dd2d30052740e0d98'in t
 files.append(sha);tables[tag]=tree,hist
 for m in ('tree','loops','all','synthetic'):
  files.extend(sorted(r.glob(f'{tag}-{m}-*.log')))
 for m in ('tree','all','synthetic'):files.extend(sorted(r.glob(f'{tag}-history-{m}-*.log')))
 print(tag)
 for name,table in [('current',tree),('historical',hist)]:
  for m,v in table.items():
   row=f'| {tag} | {name} | {m} | {sum(x<=1 for x in v.values())}/{len(v)} | {pct(max(v.values()))} |'
   print(row, [(k,x)for k,x in v.items()if x>1]);summary.append(row)
for tag in tags:
 tree,hist=tables[tag]
 rows=['| '+k+' | '+' | '.join(pct(t[m][k])for t,m in [(tree,'tree'),(tree,'loops'),(tree,'all'),(hist,'tree'),(hist,'all')])+' |'for k in tree['tree']]
 synthetic=['| '+k+' | '+pct(v)+' | '+pct(hist['synthetic'][k])+' |'for k,v in tree['synthetic'].items()]
 lines.append('\n### '+({'upspan':'Vectorized spans','shortclimb':'Short ancestor walks'}[tag])+'''

| SQLite group | Current tree | Current loops | Current combined | Historical tree | Historical combined |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

| Synthetic graph and output | Current parent | Historical scalar |
| --- | ---: | ---: |
'''+'\n'.join(synthetic)+'\n')
out=Path('/workspace/buster-performance/docs/measurements/dominators-data-parallel-2953-2026-11-23')
arch='frontier-walks-production.tar.xz';doc=out/'README.md';title='## Dominance frontiers on long and short ancestor walks';assert title not in doc.read_text()
with tarfile.open(out/arch,'w:xz',preset=2)as a:
 for f in sorted(set(files)):a.add(f,'native/'+f.name)
 for tag in tags:
  for name in [tag+'.patch','shipping-'+tag+'.py','build-'+tag,'measure-'+tag,'history-'+tag]:a.add(p/name,'source/'+name)
 for name in ['record-frontier-walks.py','record-combined.py','read-triplets.patch']:a.add(p/name,'source/'+name)
 a.add(dom/'scores.py','source/scores.py')
with doc.open('a')as f:
 f.write('\n'+title+'''

Both variants build dominance frontiers for the same complete dominator implementation. Each comparison used three alternating paired rounds under the exclusive lock on the 9700X. Percentages give the median paired change in core cycles. The current parent read 5,204 SQLite forms. The historical compiler read the reproduced export of 7,806 forms. Each candidate passed four native frozen seeds and the SQLite producer's 22,641,582 independent checks.

| Variant | Baseline | Output | Groups at parity or faster | Largest change |
| --- | --- | --- | ---: | ---: |
'''+'\n'.join(summary)+'\n'+''.join(lines)+'\n[Candidate source, original inputs and all paired measurements]('+arch+')\n')
