#!/bin/bash
# #2953: the branch's Release build against main's (968a085f), each build, test and benchmark under the lock, benchmarks
# on CPU 2: test-dominators and test-ir-source --dominators on sqlite3.c with the branch, then three rounds in turn of
# benchmark-dominators --cfg (tree, loops and all in one process) on main's export of sqlite3.c's CFGs and on the
# synthetic shapes.
set -uo pipefail
D=~/buster-fast-bench/2953-claude
cd "$D"
export EXCLUSIVE_OWNER=claude-2953 EXCLUSIVE_TITLE="Dominators: a data-parallel solver (#2953)" EXCLUSIVE_LINK=https://github.com/buster14a/buster/issues/2953
L=~/buster-fast-bench/exclusive.sh
R=${RUN:-full1}
mkdir -p $R
if [ ! -d branch ]; then
    git clone -q --depth 1 -b claude/2953-dominators-data-parallel https://github.com/buster14a/buster branch
else
    git -C branch fetch -q --depth 1 origin claude/2953-dominators-data-parallel && git -C branch reset -q --hard FETCH_HEAD
fi
git -C branch rev-parse HEAD > $R/branch.rev
git -C main rev-parse HEAD > $R/main.rev
(cd branch && $L timeout -k 5 1500 ./build.sh --config Release) > $R/build-branch.log 2>&1
echo "build branch: $?" >> $R/status.txt
sha256sum main/build/compiler branch/build/compiler > $R/compilers.sha256
$L timeout -k 5 900 branch/build/compiler test-dominators > $R/test-dominators.log 2>&1
echo "test-dominators: $?" >> $R/status.txt
corpus=/var/lib/buster-9700x/corpora/preprocessor-391e729af658
(cd branch && $L timeout -k 5 1500 ./build/compiler test-ir-source --dominators --predefines "$corpus/provenance/gnu17-pinned-predefines.txt" --no-default-config --target=x86_64-linux-gnu -march=znver5 -std=gnu17 -nostdinc -isystem "$corpus/headers/usr/lib/clang/23/include" -isystem "$corpus/headers/usr/local/include" -isystem "$corpus/headers/usr/include" "$corpus/sqlite/sqlite3.c") > $R/ir-source-sqlite.log 2>&1
echo "test-ir-source sqlite3.c: $?" >> $R/status.txt
(cd branch && $L timeout -k 5 900 ./build/compiler test-ir-source --dominators tests/ir-source/dominators.c) > $R/ir-source-fixture.log 2>&1
echo "test-ir-source fixture: $?" >> $R/status.txt
for round in 1 2 3; do
    for v in main branch; do
        $L timeout -k 5 900 taskset -c 2 $v/build/compiler benchmark-dominators --cfg $D/sqlite.cfg > $R/cfg-$v-$round.log 2>&1
        echo "cfg $v $round: $?" >> $R/status.txt
        $L timeout -k 5 900 taskset -c 2 $v/build/compiler benchmark-dominators > $R/synthetic-$v-$round.log 2>&1
        echo "synthetic $v $round: $?" >> $R/status.txt
    done
done
date -u +%FT%TZ > $R/.done
