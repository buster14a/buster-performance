from pathlib import Path
p=Path(__file__).parent
f='buster/compiler/dominators.c'
def make(base,frame,leaves,groups):
 s=base;a=s.index('    const uint32_t count = cfg->block_count;',s.index('static uint32_t dominators_order('))
 if groups:
  x=s.index('    uint32_t join_count',a)
  s=s[:x]+'''    // Child offsets are free until tree construction. Classify predecessor counts in source order.
    uint8_t* const is_join = (uint8_t*)result->tree_offsets;
    for (uint64_t first = 0; first < count; first += 16)
    {
        const uint32_t width = count - first >= 16 ? 16 : (uint32_t)(count - first);
        const __mmask16 active = (__mmask16)_bzhi_u32(UINT16_MAX, width);
        const __m512i starts = _mm512_maskz_loadu_epi32(active, cfg->predecessor_offsets + first);
        const __m512i ends = _mm512_maskz_loadu_epi32(active, cfg->predecessor_offsets + first + 1);
        const __mmask16 multiple = _mm512_cmpgt_epu32_mask(_mm512_sub_epi32(ends, starts), _mm512_set1_epi32(1));
        _mm_mask_storeu_epi8(is_join + first, active, _mm_maskz_set1_epi8(multiple, 1));
    }
'''+s[x:]
  s=s.replace('join_count += cfg->predecessor_offsets[(uint64_t)target + 1] - cfg->predecessor_offsets[target] > 1;', 'join_count += is_join[target];',1)
 if frame:
  a=s.index('    uint64_t depth = 1;',a);b=s.index('    result->reachable_count = finished;',a);body=s[a:b]
  start=body.index('    stack[0] =');stop=body.index('            if (dfs_begin[target]',start)
  body=body[:start]+'''    uint32_t block = cfg->entry;
    uint32_t next = cfg->successor_offsets[block];
    uint32_t end = cfg->successor_offsets[(uint64_t)block + 1];
    for (;;)
    {
        if (next < end)
        {
            const uint32_t target = cfg->successors[next++];
'''+body[stop:]
  body=body.replace('uint64_t depth = 1;', 'uint64_t depth = 0;').replace('frame->block','block')
  a1=body.index('                stack[depth] =');b1=body.index('                depth += 1;',a1)+len('                depth += 1;')
  body=body[:a1]+('''                if (cfg->successor_offsets[target] == cfg->successor_offsets[(uint64_t)target + 1])
                {
                    const uint32_t order = count - 1 - finished++;
                    result->rpo[order] = target;
                    result->rpo_index[target] = order;
                    continue;
                }
''' if leaves else '')+'''                stack[depth++] = (DominatorFrame){ .block = block, .next = next };
                block = target;
                next = cfg->successor_offsets[target];
                end = cfg->successor_offsets[(uint64_t)target + 1];'''+body[b1:]
  body=body.replace('            depth -= 1;','''            if (depth == 0)
            {
                break;
            }
            const DominatorFrame frame = stack[--depth];
            block = frame.block;
            next = frame.next;
            end = cfg->successor_offsets[(uint64_t)block + 1];''')
  s=s[:a]+body+s[b:]
 return s
for name,fr,lf,gr in [('activeframe',1,0,0),('closeleaves',1,1,0),('joinflags',0,0,1),('frameflags',1,0,1)]:
 src=(p/'earlyroots'/f).read_text()
 path=p/name/f;path.parent.mkdir(exist_ok=True,parents=True);path.write_text(make(src,fr,lf,gr))
for a,b in [('finish-bench','cursor-bench'),('finish-deep','cursor-deep')]:
 s=(p/a).read_text()
 for x,y in [('earlyroots','activeframe'),('skipjoins','closeleaves'),('rootpack','joinflags'),('trimjoins','frameflags'),('finish-','cursor-'),('deep-finish','deep-cursor')]:s=s.replace(x,y)
 (p/b).write_text(s)
