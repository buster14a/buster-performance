from pathlib import Path
from statistics import median
import sys,tarfile
p=Path(__file__).parent
dom=Path('/tmp/buster-dominators');sys.path.insert(0,str(dom));from scores import get
out=Path('/workspace/buster-performance/docs/measurements/dominators-data-parallel-2953-2026-11-23');rs=dom/'results'
rows=[];names=['activeframe','closeleaves','joinflags','frameflags']
for n in names:
 fields=[];totals=[]
 for m in ['tree','all','synthetic']:
  scores,rounds=get('cursor-',m,n);assert rounds==3 and len(scores)==(21 if m=='synthetic' else 19)
  fields.append(f'{sum(v<=1 for v in scores.values())}/{len(scores)}')
  if m!='synthetic':totals.append(f'{100*(scores["all"]-1):+.2f}%')
  elif n=='joinflags':print('remaining',[(k,v)for k,v in scores.items() if v>1])
 deep=[]
 for i in [1,2,3]:
  data=(rs/f'deep-{n}-{i}.tsv').read_text().splitlines();assert len(data)>=12
  deep.append(float(data[-1].split()[-1]))
 assert '0 failures' in (rs/f'correct-{n}.log').read_text()
 rows.append('| '+n+' | '+' | '.join(fields+totals+[f'{median(deep):.1f}'])+' |')
title='## Grouping predecessor counts before depth-first search'
f=out/'README.md';s=f.read_text();assert title not in s
with tarfile.open(out/'dfs-cursor-records.tar.xz','w:xz',preset=2)as t:
 for y in names+['dfs-cursors.py','cursor-bench','cursor-deep','deep-joins.c','scores.py']:t.add(dom/y,'source/'+y)
 for mask in ['cursor-*']+['deep-'+n+'-*'for n in names]+['correct-'+n+'.log'for n in names]:
  for q in sorted(rs.glob(mask)):t.add(q,'native/'+q.name)
 t.add(p/'record-cursors.py','source/record-cursors.py')
f.write_text(s.rstrip()+'\n\n'+title+'''

Four standalone variants compare the active DFS frame in registers, finishing child leaves on discovery, classifying sets of sixteen predecessor counts before the walk, and combining the first and third changes. Each passed the independent dominator suite and the deep-join fixture through 32,769 blocks. Three paired rounds ran on the locked 9700X.

| Implementation | SQLite tree sets | SQLite full sets | Synthetic cases | All SQLite graphs, tree | All SQLite graphs, full | Deep fixture, ticks/block |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

The predecessor-count variant met the parent in twenty of the twenty-one synthetic comparisons. Complete analysis on the ladder graph took 0.026% more cycles per block.

[Implementations, fixtures, raw measurements and comparison](dfs-cursor-records.tar.xz)
''')
print(*rows,sep='\n')
