#define _GNU_SOURCE
#include "buster/compiler/dominators_benchmark.c"
int main(int argc, char** argv)
{
    const bool tree_only = argc > 1 && strcmp(argv[1], "tree") == 0;
    const DominatorTestEdge edges[] = {
        {0, 1}, {0, 2}, {1, 2}, {2, 1}, {2, 2}, {2, 3}, {1, 4}, {4, 3}, {5, 5}
    };
    Arena graph = arena_reserve(1 << 20);
    Arena scratch = arena_reserve(1 << 20);
    DominatorCfg cfg = {0};
    Dominators analysis = {0};
    DominatorOptions options = dominators_options();
    if (tree_only) options.outputs = 0;
    if (!dominator_test_cfg(&graph, 6, 0, edges, 9, &cfg) ||
        dominators_analyze(&graph, &scratch, &cfg, options, &analysis) != DOMINATOR_OK) return 2;
    const uint32_t parents[] = {0, 0, 0, 0, 1, BUSTER_DOMINATOR_NONE};
    unsigned failed = memcmp(parents, analysis.idom, sizeof(parents)) != 0;
    if (!tree_only)
    {
        const uint8_t regions[] = {0, 1, 1, 0, 0, 0};
        failed += memcmp(regions, analysis.irreducible, sizeof(regions)) != 0;
        const bool single = analysis.loop_count == 1 && analysis.loop_header[0] == 2 && analysis.loop_size[0] == 1;
        failed += !single;
        if (single)
        {
            failed += analysis.loop_irreducible[0] != 1;
            for (uint32_t b = 0; b < 6; ++b) failed += dominators_loop_contains(&analysis, 0, b) != (b == 2);
        }
    }
    fprintf(stderr, "hand-derived %s outputs: %u failures\n", tree_only ? "immediate dominator" : "SCC and natural loop", failed);
    return failed != 0;
}
