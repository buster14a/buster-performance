from pathlib import Path
import tarfile,sys,re
from statistics import median
p=Path(__file__).parent;r=p/'results';dom=Path('/tmp/buster-dominators')
sys.path.insert(0,str(dom));from scores import parse
out=Path('/workspace/buster-performance/docs/measurements/dominators-data-parallel-2953-2026-11-23')
def measure(prefix,side,mode):
 ds=[];raw=[]
 for i in (1,2,3):
  xs=[]
  for name in ('unroll-base',side):
   s=(r/f'{prefix}-{mode}-{name}-{i}.log').read_text();assert 'benchmark: passed;' in s
   if mode!='synthetic':assert '5204 records' in s and 'functions=2602' in s
   xs.append(parse(s,mode if mode!='loops' else 'tree'))
  assert xs[0].keys()==xs[1].keys() and len(xs[0])==(21 if mode=='synthetic' else 19)
  ds.append({k:xs[1][k]/v for k,v in xs[0].items()});raw.append(xs)
 return {k:(median(x[k]for x in ds),median(x[0][k]for x in raw),median(x[1][k]for x in raw))for k in ds[0]}
def whole(prefix):
 rows={}
 for group,n in [('lua',34),('sqlite',1),('musl',1336)]:
  xs=[]
  for mode in ('default','all'):
   manifests=[(r/f'{prefix}-objects-{mode}-{group}-{v}.sha').read_bytes()for v in ('base','frontier')];assert manifests[0]==manifests[1] and len(manifests[0].splitlines())==n+2
   s=(r/f'{prefix}-compile-{mode}-{group}.log').read_text();assert s.rstrip().endswith('ab: done, 0 failed runs')
   pairs=[]
   for c in s.split('time-runs: done, 0 failed processes')[:-1]:
    w={k:int(x)for k,x in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',c,re.M)};pairs.append(w['head']/w['base'])
   assert len(pairs)==5;xs.append(f'{100*(median(pairs)-1):+.3f}%')
  rows[group]=xs
 return rows
tags=[('compiler','natural-edges','production'),('lazy','natural-lazy','lazy'),('final','natural-final','final')]
meas={};process={}
for name,side,w in tags:
 for mode in ('loops','all','synthetic'):meas[name,mode]=measure(name,side,mode)
 process[name]=whole(w)
for name,pre,source in [('compiler','','source'),('lazy','lazy-','lazy-source'),('final','final-','final-producer')]:
 for seed in (174,1,133,789):
  s=(r/f'{pre}frozen-{seed}.log').read_text();assert re.search(r'^dominators: [0-9]+ checks, 0 failures',s,re.M)
 assert 'forms=5204 checks=22641582 failed=0 excluded=0 passed' in (r/f'{source}-sqlite.log').read_text()
 s=(r/f'{source}-fixture.log').read_text();assert 'failed=0 excluded=0 passed' in s
for n in ('no-header','no-components'):
 s=(r/f'oracle-{n}.log').read_text();assert re.search(r'[1-9][\d]* failures',s)
def pct(v):return f'{(v-1)*100:+.2f}%'
def row(mode,keys):
 return ['| '+k+' | '+' | '.join(pct(meas[tag,m][key][0])for tag,_,_ in tags for m,key in mode(k))+' |'for k in keys]
cfg=row(lambda k:[('loops',k),('all',k)],meas['final','loops'])
shapes=list(dict.fromkeys(k.split(' ')[0]for k in meas['final','synthetic']))
synth=row(lambda k:[('synthetic',k+' loops'),('synthetic',k+' all')],shapes)
objects=['| '+k+' | '+' | '.join(x for tag,_,_ in tags for x in process[tag][k])+' |'for k in process['final']]
q=meas['final','synthetic']['dispatch loops'];old=dom/'original/full5'
hist={name:median(parse((old/f'synthetic-{name}-{i}.log').read_text(),'synthetic')['dispatch loops']for i in (1,2,3))for name in ('main','branch')}
text='''## Natural-loop back edges and irreducible components

Every reachable DFS-ancestor edge identifies either a natural-loop header or a source whose SCC needs the conservative irreducibility flag. The first implementation classifies both during one scan and uses the natural-loop body bit to recognize previously absorbed members. The second implementation records witnesses during classification and runs the reverse SCC walk only when a witness exists. The last build includes the source and documentation changes submitted for review.

The Release compilers ran on CPU 2 of the locked Ryzen 7 9700X. Measurements compare each candidate with cc7d4ffb4 in three alternating paired rounds. Every percentage is the median paired change in cycles per block. The current reader accepts the two current IR forms. Removing the third, scalar-promoted form from the historical SQLite export yields 5,204 records from 2,602 functions. For every function its old third graph was byte-identical to its second after the form number. The original SHA-256 is `dde6529090a5641b935330fc8f5632a19651c1999194531dd2d30052740e0d98`, and the two-form fixture is `dfcfc5ff70eb860723668df8214eb7186fa04b0217f550e4d54b6f2ac9e02204`.

| SQLite set | One scan, loops | One scan, full | Witnesses, loops | Witnesses, full | Shipping loops | Shipping full |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(cfg)+'''

| Synthetic shape | One scan, loops | One scan, full | Witnesses, loops | Witnesses, full | Shipping loops | Shipping full |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(synth)+f'''

The historical random dispatch graph has 2,049 blocks and 8,195 edges. Its loop analysis originally cost {hist['main']:.3f} cycles per block on the pre-3455 revision and {hist['branch']:.3f} on the full5 revision. The new paired shipping comparison measured {q[1]:.3f} on its own parent and {q[2]:.3f} on the candidate.

Each compiler passed the 46,597,165-check default dominance suite and three additional seeds. The actual IR producer passed 22,641,582 checks over all 5,204 SQLite forms, plus the repository’s source fixture. The independent oracle rejected mutations that dropped natural-loop headers or omitted the conservative component flags.

The uninstrumented full Tier 1 compilation used five paired rounds of three processes per executable in every round. Both pass configurations matched all 1,371 debug objects, stdout and diagnostics. The percentages below measure user cycles.

| Corpus | One scan, default | One scan, all passes | Witnesses, default | Witnesses, all passes | Shipping default | Shipping all passes |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(objects)+'''

[Source patches, fixture conversion, full compiler commands, mutation controls, correctness logs and raw measurements](natural-loop-edges.tar.xz)
'''
with tarfile.open(out/'natural-loop-edges.tar.xz','w:xz') as t:
 for n in ('natural.patch','lazy.patch','shipping.patch','build-and-test','measure','ordinary','ordinary-corpus','build-lazy','measure-lazy','ordinary-lazy','lazy-corpus','build-final','measure-final','ordinary-final','final-corpus','record.py'):t.add(p/n,arcname='source/'+n)
 for n in ('paired-export.py','scores.py','check-oracle','oracle.c','sqlite-pairs.cfg','mutations/no-header','mutations/no-components'):t.add(dom/n,arcname='source/'+n)
 for f in sorted(r.iterdir()):
  if f.is_file() and not f.name.endswith('.ok') and 'job.log' not in f.name:t.add(f,arcname='native/'+f.name)
f=out/'README.md';base=f.read_text().split('\n## Natural-loop back edges and irreducible components')[0];f.write_text(base.rstrip()+'\n\n'+text)
print(*cfg,*synth,*objects,sep='\n')
