from pathlib import Path
import hashlib
p=Path(__file__).parent
data=(p/'original-sqlite.cfg').read_bytes()
assert hashlib.sha256(data).hexdigest()=='dde6529090a5641b935330fc8f5632a19651c1999194531dd2d30052740e0d98'
header, records=data.split(b'\n',1)
assert header==b'buster-dominators-v1'
graphs=records.split(b'end\n');assert graphs.pop()==b'complete 1 2602 7806\n' and len(graphs)==7806
out=[header+b'\n']
for i in range(0,len(graphs),3):
 a,b,c=graphs[i:i+3]
 for k,g in enumerate([a,b,c]):
  lines=g.splitlines();assert lines[0].startswith(f'cfg {k} '.encode()) and lines[1:3]==a.splitlines()[1:3]
  assert int(lines[0].split()[3])==len(lines)-3
 assert b.split(b' ',2)[2]==c.split(b' ',2)[2]
 out.extend((a,b'end\n',b,b'end\n'))
out.append(b'complete 1 2602 5204\n')
(p/'sqlite-pairs.cfg').write_bytes(b''.join(out))
print(hashlib.sha256(b''.join(out)).hexdigest())
