from pathlib import Path
from statistics import median
import tarfile,re
p=Path(__file__).parent;r=p/'results';dom=Path('/tmp/buster-dominators')
s=(p/'record-combined.py').read_text().split('current=')[0];exec(s)
whole_text=Path('/tmp/buster-dom-loops/record.py').read_text();exec(whole_text[whole_text.index('def whole('):whole_text.index('tags=')])
current={m:series('fused',m,'unroll-base','dom-fused')for m in ('tree','all','synthetic','loops')}
historic={m:series('fused-history',m,'historical','candidate')for m in ('tree','all','synthetic')}
ordinary=whole('fused');deep={}
for n in ['fused4','fusedpair','fusedminimum','fusedgather']:
 vals=[]
 for i in [1,2,3]:
  a=(dom/'results'/f'deep-{n}-{i}.tsv').read_text().splitlines()
  assert len(a)==12 and int(a[-1].split()[0])==16384;vals.append(float(a[-1].split()[-1]))
 deep[n]=median(vals)
for seed in [174,1,133,789]:assert '0 failures' in (r/f'fused-frozen-{seed}.log').read_text()
assert 'forms=5204 checks=22641582 failed=0' in (r/'fused-producer-sqlite.log').read_text()
tab=['| '+k+' | '+' | '.join(pct(d[m][k])for d,m in [(current,'tree'),(current,'loops'),(current,'all'),(historic,'tree'),(historic,'all')])+' |'for k in current['tree']]
body='''## Join worklist with bounded ancestor climbs

The combined compiler records DFS parents, numbers join blocks once in preorder and seeds the compressed parent/least-label links eight at a time. Incoming edges are examined only at joins. The final ancestor queries use at most four ordinary parent hops before consulting cached jump links. The jump lengths coalesce when two adjacent jumps have equal lengths. Cache entries are populated only for vertices actually queried. The tree output reuses cumulative offsets to place children and the loop pass uses the sparse back-edge source set.

The current-form benchmark used 5,204 SQLite graphs. The historical comparison retained all 7,806 original records and ran the archived scalar compiler. The compatibility build changes only the export reader’s form count. Entries are the median change in cycles per block over three paired rounds on CPU 2 of the locked Ryzen 7 9700X.

| SQLite set | Current tree | Current loops | Current all | Historical tree | Historical all |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(tab)+'''

| Synthetic analysis | Current parent | Historical scalar |
| --- | ---: | ---: |
'''+'\n'.join('| '+k+' | '+pct(v)+' | '+pct(historic['synthetic'][k])+' |'for k,v in current['synthetic'].items())+'''

| Tier 1 corpus | Default passes | All passes |
| --- | ---: | ---: |
'''+'\n'.join('| '+g+' | '+' | '.join(xs)+' |'for g,xs in ordinary.items())+f'''

All debug objects, stdout and diagnostics matched over the six ordinary compiler workloads. Each compiler ran five pairs of three processes. The source producer matched 22,641,582 checks on SQLite. Four seeds of the dominator differential suite passed. The separate deep-join graph has a known immediate dominator for every block. With a depth of 16,384 and 32,769 blocks, the locked median was {deep['fused4']:.1f} ticks per block, compared with 28,122 for the original unbounded climb. This test changes the number of joins and their distance to the semidominator together.

[Implementations, recorded inputs, commands, ordinary object hashes and raw measurements](join-worklist.tar.xz)
'''
with tarfile.open(out/'join-worklist.tar.xz','w:xz',preset=2)as t:
 for name in ['fused.patch','read-triplets.patch','build-fused','history-fused','measure-fused','ordinary-fused','fused-corpus','shipping-fused.py','record-fused.py','record-combined.py']:t.add(p/name,arcname='source/'+name)
 for n in ['fused-sparse.py','fused-bench','fused-deep','deep-joins.c','bounded-jumps.py','scores.py']:t.add(dom/n,arcname='source/'+n)
 for n in ['fused4','fusedpair','fusedminimum','fusedgather']:t.add(dom/n,arcname='candidates/'+n)
 for f in sorted(r.glob('fused-*')):t.add(f,arcname='native/'+f.name)
 for pat in ['fused-*.log','deep-fused*.tsv','deep-fused*.log']:
  for f in sorted((dom/'results').glob(pat)):t.add(f,arcname='isolated/'+f.name)
file=out/'README.md';file.write_text(file.read_text().split('\n## Join worklist with bounded ancestor climbs')[0].rstrip()+'\n\n'+body)
print(ordinary,deep)
