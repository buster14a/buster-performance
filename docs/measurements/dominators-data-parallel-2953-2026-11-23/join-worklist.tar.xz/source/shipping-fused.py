from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
p=Path(__file__).parent;repo=p/'tree';f='src/buster/compiler/dominators.c'
base=check_output(['git','show','cc7d4ffb4:'+f],cwd=repo).decode()
src=(Path('/tmp/buster-dominators/fused4')/f[4:]).read_text()
a=src.index('// One DFS from entry:');b=src.index('static uint32_t dominators_order',a)
src=src[:a]+'''// DFS numbers reachable blocks in preorder and reverse postorder. Single-entry blocks inherit their
// parent's immediate dominator. Joins retain their preorder number for the semidominator pass. If
// loops are requested, record the sources of edges to ancestors still on the active DFS stack.
'''+src[b:]
(p/'fused.patch').write_text(''.join(unified_diff(base.splitlines(True),src.splitlines(True),'a/'+f,'b/'+f)))
for src,name in [('build-combined','build-fused'),('measure-combined','measure-fused'),('ordinary-combined','ordinary-fused'),('final-corpus','fused-corpus'),('qualify-history','history-fused')]:
 s=(p/src).read_text().replace('build/dom-combined','build/dom-fused').replace('(unroll-base dom-combined)','(unroll-base dom-fused)').replace('(dom-combined unroll-base)','(dom-fused unroll-base)').replace('final-','fused-')
 s=s.replace('previous=/dev/shm/buster-lexer-prefixes','previous=/dev/shm/buster-lexer-dollars').replace('previous/lookup-built.ok','previous/vector-built.ok').replace('previous/lookup.patch','previous/vector.patch').replace('root/combined.patch','root/fused.patch')
 if src=='qualify-history':s=s.replace('triplets-built.ok','fused-triplets-built.ok').replace('historic-','fused-history-').replace('triplets-build.log','fused-triplets-build.log')
 (p/name).write_text(s)
