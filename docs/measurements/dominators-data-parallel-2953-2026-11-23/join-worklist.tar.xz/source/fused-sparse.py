from pathlib import Path
import re
p=Path(__file__).parent
filename='buster/compiler/dominators.c'
loops=(Path('/tmp/buster-dom-loops/shipping-sources')/filename).read_text()
for tag,shape in [('fused4','outline4'),('fusedpair','pairskip'),('fusedgather','outline4'),('fusedminimum','outline4')]:
 t=(p/shape/filename).read_text()
 a=t.index('static void dominators_components(');b=t.index('static DominatorStatus dominators_analyze(',a)
 c=loops.index('static void dominators_components(');d=loops.index('static DominatorStatus dominators_analyze(',c)
 t=t[:a]+loops[c:d]+t[b:]
 t=t.replace('uint32_t* dfs_end, uint32_t* vertices','uint64_t* back_edge_sources, uint32_t* vertices').replace('    memset(dfs_end, 0xff, (uint64_t)count * sizeof(uint32_t));','''    if (back_edge_sources != NULL)
    {
        memset(back_edge_sources, 0, ((uint64_t)count + 63) / 64 * sizeof(uint64_t));
    }''').replace('                has_alternate_entry |= dfs_end[target] != BUSTER_DOMINATOR_NONE;', '''                const bool finished_target = result->rpo_index[target] != BUSTER_DOMINATOR_NONE;
                has_alternate_entry |= finished_target;
                if (!finished_target && back_edge_sources != NULL)
                {
                    back_edge_sources[frame->block / 64] |= UINT64_C(1) << (frame->block % 64);
                }''').replace('            dfs_end[frame->block] = entered;\n','')
 t=t.replace('uint32_t* dfs_end = 0;', 'uint64_t* back_edge_sources = NULL;')
 a=t.index('            dfs_end = arena_push_array');b=t.index(';',a)+1
 c=loops.index('            if ((options.outputs & BUSTER_DOMINATOR_LOOPS)',loops.index('            dfs_begin = arena_push_array'));d=loops.index('            workspace =',c)
 t=t[:a]+loops[c:d].rstrip()+t[b:]
 t=t.replace('dfs_end == 0','((options.outputs & BUSTER_DOMINATOR_LOOPS) != 0 && back_edge_sources == NULL)').replace('dfs_begin, dfs_end,','dfs_begin, back_edge_sources,')
 assert 'dfs_end' not in t
 if tag in ['fusedgather','fusedminimum']:
  a=t.index('        for (uint32_t edge = cfg->predecessor_offsets[block]',t.index('static void dominators_semi_nca('));b=t.index('        semi[number] =',a)
  v='''        const uint32_t end = cfg->predecessor_offsets[(uint64_t)block + 1];
        for (uint64_t edge = cfg->predecessor_offsets[block]; edge < end && least != 0; edge += 16)
        {
            const __mmask16 valid = (__mmask16)_bzhi_u32(UINT16_MAX, end - edge < 16 ? (uint32_t)(end - edge) : 16);
            const __m512i predecessors = _mm512_maskz_loadu_epi32(valid, cfg->predecessors + edge);
            const void* base = (const void*)((uintptr_t)dfs_begin + (UINT64_C(1) << 33));
            const __m512i source = _mm512_mask_i32gather_epi32(_mm512_set1_epi32(-1), valid, _mm512_xor_si512(predecessors, _mm512_set1_epi32(INT32_MIN)), base, 4);
            const __mmask16 previous = _mm512_cmple_epu32_mask(source, _mm512_set1_epi32((int32_t)number));
            const uint32_t direct = _mm512_mask_reduce_min_epu32(previous, source);
            least = direct < least ? direct : least;
            uint32_t pending = valid & ~previous & _mm512_cmpneq_epi32_mask(source, _mm512_set1_epi32(-1));
            uint32_t numbers[16];
            _mm512_storeu_si512(numbers, source);
            while (pending && least)
            {
                const uint32_t lane = (uint32_t)__builtin_ctz(pending);
                pending &= pending - 1;
                const uint32_t candidate = dominators_evaluate(links, stack, numbers[lane], number + 1);
                least = candidate < least ? candidate : least;
            }
        }
'''
  if tag=='fusedminimum':
   # Fold common single-packet minima for short predecessor lists in the existing scalar iteration.
   v=t[a:b].replace('edge += 1)','edge += 1)').replace('                    ','                    ').replace('source != BUSTER_DOMINATOR_NONE','source < least').replace('                const uint32_t candidate = source <= number ? source : dominators_evaluate(links, stack, source, number + 1);\n                least = candidate < least ? candidate : least;','''                least = source;
            }
            else if (source > number && source != BUSTER_DOMINATOR_NONE && least != 0)
            {
                const uint32_t candidate = dominators_evaluate(links, stack, source, number + 1);
                least = candidate < least ? candidate : least;''')
  t=t[:a]+v+t[b:]
 d=p/tag/filename;d.parent.mkdir(exist_ok=True,parents=True);d.write_text(t)
for src,dst in [('bounded-bench','fused-bench'),('bounded-deep','fused-deep')]:
 s=(p/src).read_text()
 for a,b in [('outline4','fused4'),('outline8','fusedpair'),('outline16','fusedgather'),('pairskip','fusedminimum'),('bounded-','fused-'),('deep-bounded','deep-fused')]:s=s.replace(a,b)
 (p/dst).write_text(s)
