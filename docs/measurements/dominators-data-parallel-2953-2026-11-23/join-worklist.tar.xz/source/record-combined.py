from pathlib import Path
from statistics import median
import sys,re,tarfile
p=Path(__file__).parent;r=p/'results';dom=Path('/tmp/buster-dominators');sys.path.insert(0,str(dom));from scores import parse
out=Path('/workspace/buster-performance/docs/measurements/dominators-data-parallel-2953-2026-11-23')
def series(tag,mode,base,head):
 runs=[]
 for n in (1,2,3):
  xs=[]
  for v in (base,head):
   s=(r/f'{tag}-{mode}-{v}-{n}.log').read_text();assert 'benchmark: passed;' in s
   xs.append(parse(s,'tree'if mode=='loops'else mode))
  assert xs[0].keys()==xs[1].keys();runs.append(xs)
 return {k:median(b[k]/a[k]for a,b in runs)for k in runs[0][0]}
def pct(x):return f'{100*(x-1):+.2f}%'
current={m:series('final',m,'unroll-base','dom-combined')for m in ('tree','loops','all','synthetic')}
hist={m:series('historic',m,'historical','candidate')for m in ('tree','all','synthetic')}
table=['| '+k+' | '+' | '.join(pct(d[m][k])for d,m in [(current,'tree'),(current,'loops'),(current,'all'),(hist,'tree'),(hist,'all')])+' |'for k in current['tree']]
synthetic=['| '+k+' | '+pct(v)+' | '+pct(hist['synthetic'][k])+' |'for k,v in current['synthetic'].items()]
debug=[]
for g,n in [('lua',34),('sqlite',1),('musl',1336)]:
 cols=[]
 for m in ('default','all'):
  xs=[(r/f'final-objects-{m}-{g}-{v}.sha').read_bytes()for v in ('base','frontier')];assert xs[0]==xs[1] and len(xs[0].splitlines())==n+2
  s=(r/f'final-compile-{m}-{g}.log').read_text();assert s.rstrip().endswith('ab: done, 0 failed runs')
  rr=[]
  for c in s.split('time-runs: done, 0 failed processes')[:-1]:
   vs={k:int(v)for k,v in re.findall(r'^list 1 (base|head) .*?\]: 3 runs, median .*? (\d+) user cycles,',c,re.M)};rr.append(vs['head']/vs['base'])
  assert len(rr)==5;cols.append(f'{(median(rr)-1)*100:+.3f}%')
 debug.append('| '+g+' | '+' | '.join(cols)+' |')
for n in (174,1,133,789):assert re.search(r'^dominators: \d+ checks, 0 failures',(r/f'final-frozen-{n}.log').read_text(),re.M)
assert 'forms=5204 checks=22641582 failed=0 excluded=0 passed' in (r/'final-producer-sqlite.log').read_text()
steps=['base','compacttree','buckets','activebuckets','pairlabels','thresholds','thresholdbits','lowerlinks','lowerjumps']
deep={}
for name in steps:
 xs=[]
 for i in (1,2,3):
  vals=[v.split()for v in (dom/'results'/f'deep-{name}-{i}.tsv').read_text().splitlines()];assert len(vals)==12
  xs.append({int(v[0]):float(v[3]) for v in vals})
 deep[name]={n:median(v[n]for v in xs)for n in xs[0]}
table2=['| '+str(h)+' | '+' | '.join(f'{deep[s][h]:.2f}'for s in steps)+' |'for h in deep['base']]
result='''## Combined tree and natural-loop experiments

The combined executable uses the natural-loop change from PR #3692 and a modified SEMI-NCA tree. DFS installs parents for single-predecessor blocks and collects joins. The solver initializes eight paired parent labels per vector store and resolves only the collected joins. Tree construction uses the existing CSR offsets to fill its children. This experimental tree retains the depth-dependent final climb.

All native samples ran under the exclusive lock on CPU 2 of the 9700X. Each cell shows the median of three paired candidate/baseline cycle ratios. The first three columns compare with cc7d4ffb4 on 5,204 SQLite forms. The final two columns compare against the archived pre-#3455 scalar-loop compiler, SHA-256 `6e60ddafad95813175997cd42db5e2ef686f00d952d4619ab1b97b18b93d14af`, on all 7,806 original forms. For that comparison only, the candidate benchmark reader accepts the archived third form. The ordinary executable was also measured against the historical compiler on the synthetic suite.

| SQLite row | Current tree | Current loops | Current all | Historical tree | Historical all |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(table)+'''

| Synthetic shape and output | Against current compiler | Against historical compiler |
| --- | ---: | ---: |
'''+'\n'.join(synthetic)+'''

The combined executable also passed the frozen suite with four seeds and the source producer with 22,641,582 comparisons over 5,204 SQLite forms. All 1,371 debug objects, diagnostic streams and standard output matched per configuration. Complete compile results are the median paired change in user cycles over five rounds of three processes.

| Corpus | Default Tier 1 | All passes |
| --- | ---: | ---: |
'''+'\n'.join(debug)+'''

### Deep DFS children dominated from above

For each h the fixture has a chain numbered 0 through h. Block h and block 1 each have edges to the same h leaves. DFS descends the chain first. Every chain node has its preceding node as immediate dominator, and every leaf has block 1. The driver verifies every answer after every timing batch, outside the timed interval. The table reports timestamp-counter ticks per block for complete tree analysis, using seven warm samples per process and three measured processes.

The first two implementations climb the previously built dominator tree. The next three compute deferred immediate dominators through Lengauer–Tarjan buckets and compressed minimum labels. The last four resolve semidominator thresholds only for vertices whose semidominator differs from their DFS parent. All seven alternatives passed the 46,597,165-check independent definition suite. The deep fixture distinguishes per-leaf climbing from shared computations. Each alternative still needs its own size and production qualification.

| h | Parent | Modified SEMI-NCA | Buckets | Active buckets | Paired labels | Thresholds | Threshold bitmap | Lower links | Lower jumps |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(table2)+'''

[Compiler changes, historical reader adapter, independent deep-graph checks, build commands and paired raw results](combined-and-deep-joins.tar.xz)
'''
with tarfile.open(out/'combined-and-deep-joins.tar.xz','w:xz')as t:
 for n in ('combined.patch','build-combined','measure-combined','final-corpus','ordinary-combined','qualify-history','read-triplets.patch','record-combined.py'):t.add(p/n,arcname='source/'+n)
 for n in ('deep-joins.c','measure-deep','threshold-deep','bucket-solver.py','threshold-solver.py','bucket-bench','threshold-bench','tree-final.patch','scores.py'):
  t.add(dom/n,arcname='source/'+n)
 for n in steps[2:]:t.add(dom/n,arcname='source/'+n);t.add(dom/'results'/f'correct-{n}.log',arcname=f'native/correct-{n}.log')
 for n in steps:
  for f in (dom/'results').glob(f'deep-{n}-*.tsv'):t.add(f,arcname='native/'+f.name)
 for f in sorted(r.glob('*')):
  if f.is_file() and 'job' not in f.name:t.add(f,arcname='native/'+f.name)
f=out/'README.md';existing=f.read_text().split('\n## Combined tree and natural-loop experiments')[0];f.write_text(existing.rstrip()+'\n\n'+result)
print(table[-1],*debug,table2[-1],sep='\n')
