from pathlib import Path
from statistics import median
import re,collections,sys
p=Path(__file__).parent/'results'
def parse(s,phase):
 if phase in ('tree','all'):
  return {n:float(v)for n,v in re.findall(r'^set=(\S+) cfgs=.*?\], ([\d.]+) cycles/block',s,re.M)}
 return {(n+' '+mode):float(v)for n,mode,v in re.findall(r'^(\S+) blocks=.*? analysis (\S+): .*? ([\d.]+) cycles/block',s,re.M)}
def get(pref,phase,n):
 per=collections.defaultdict(list)
 for i in (1,2,3):
  fs=[p/f'{pref}{phase}-{v}-{i}.log'for v in ('base',n)]
  if not all(f.exists() and 'benchmark: passed;' in f.read_text() for f in fs):continue
  sets=[parse(f.read_text(),phase)for f in fs];assert sets[0].keys()==sets[1].keys()
  for k,b in sets[0].items():per[k].append(sets[1][k]/b)
 return {k:median(v)for k,v in per.items()},max(map(len,per.values()),default=0)
if __name__=='__main__':
 for n in sys.argv[2:]:
  for phase in ('tree','all','synthetic'):
   data,r=get(sys.argv[1],phase,n)
   print(n,phase,r,sum(v<=1 for v in data.values()),len(data),round(100*(data.get('all',1)-1),2),*(f'{k}={100*(v-1):+.1f}%'for k,v in data.items()if phase=='synthetic' and v>1.005))
