#define _GNU_SOURCE
#include "buster/compiler/dominators_benchmark.c"
#include <x86intrin.h>

static uint64_t tick(void)
{
    _mm_lfence();
    const uint64_t t = __rdtsc();
    _mm_lfence();
    return t;
}

static int compare_cycles(const void* a, const void* b)
{
    const uint64_t left = *(const uint64_t*)a, right = *(const uint64_t*)b;
    return (left > right) - (left < right);
}

int main(void)
{
    Arena storage = arena_reserve(128 * 1024 * 1024), scratch = arena_reserve(128 * 1024 * 1024);
    if (!storage.base || !scratch.base) return 2;
    DominatorOptions options = dominators_options();
    options.outputs = 0;
    for (uint32_t h = 8; h <= 16384; h *= 2)
    {
        // The entry and block 1 dominate every leaf. The long DFS path from its
        // parent to block 1 is shared by h leaves. Computing the idom of each leaf
        // separately by climbing that path costs quadratic work.
        storage.length = 0;
        const uint32_t blocks = 2 * h + 1;
        DominatorTestEdge* edges = arena_push_array(&storage, 3 * h, sizeof(*edges), _Alignof(DominatorTestEdge));
        if (!edges) return 2;
        for (uint32_t i = 0; i < h; ++i)
        {
            edges[i] = (DominatorTestEdge){i, i + 1};
            edges[h + i] = (DominatorTestEdge){h, h + 1 + i};
            edges[2 * h + i] = (DominatorTestEdge){1, h + 1 + i};
        }
        DominatorCfg cfg = {0};
        if (!dominator_test_cfg(&storage, blocks, 0, edges, 3*h, &cfg)) return 3;
        const uint64_t saved = storage.length;
        uint64_t samples[7];
        unsigned repeats = 8192 / h + 1;
        for (unsigned i = 0; i < 8; ++i)
        {
            Dominators analysis = {0};
            uint64_t start = tick();
            for (unsigned n = 0; n < repeats; ++n)
            {
                storage.length = saved;
                scratch.length = 0;
                if (dominators_analyze(&storage, &scratch, &cfg, options, &analysis) != DOMINATOR_OK) return 4;
            }
            uint64_t elapsed = tick() - start;
            if (i) samples[i - 1] = elapsed;
            for (uint32_t b = 0; b < blocks; ++b)
            {
                const uint32_t expected = b == 0 ? 0 : b <= h ? b - 1 : 1;
                if (analysis.idom[b] != expected)
                {
                    fprintf(stderr, "h=%u block=%u idom=%u expected=%u\n", h, b, analysis.idom[b], expected);
                    return 5;
                }
            }
        }
        qsort(samples, 7, sizeof(*samples), compare_cycles);
        printf("%u %u %u %.3f\n", h, blocks, repeats, (double)samples[3] / (blocks * repeats));
        fflush(stdout);
    }
    return 0;
}
