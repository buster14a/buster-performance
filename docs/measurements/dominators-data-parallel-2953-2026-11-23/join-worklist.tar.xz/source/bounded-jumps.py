from pathlib import Path
p=Path(__file__).parent;f=Path('buster/compiler/dominators.c');base=(p/'jumptwo'/f).read_text()
start=base.index('        if (candidate > limit)\n        {',base.index('    // Auxiliary jump'));end=base.index('        parents[number] = candidate;',start)
inside=base[start:end];a=inside.index('            if (!initialized)');b=inside.rindex('\n        }')
body='\n'.join(l[8:] if l.startswith('        ')else l for l in inside[a:b].splitlines()).replace('!initialized','!*initialized').replace('initialized = true','*initialized = true')
for name,steps in [('outline4',4),('outline8',8),('outline16',16),('pairskip',8)]:
 helper='''// Populate a compressed ancestor path on first use. A larger jump combines two equal-length
// jumps below the parent. Once populated, each vertex can service weighted-ancestor queries
// without climbing each contributing dominator-tree level.
static __attribute__((noinline)) uint32_t dominators_cached_ancestor(uint32_t candidate, uint32_t limit, const uint32_t* parents, DominatorLink* links,
                                                                     uint32_t* stack, uint32_t* ready, uint32_t reachable, bool* initialized)
{
'''+body+'''
    return candidate;
}

'''
 s=base[:base.index('        if (candidate > limit) candidate = parents[candidate];',base.index('    // Auxiliary jump'))]+'''        if (limit == 0)
        {
            candidate = 0;
        }
        else
        {
            unsigned steps = '''+str(steps)+''';
            while (candidate > limit && steps != 0)
            {
                candidate = parents[candidate];
                --steps;
            }
            if (candidate > limit)
            {
                candidate = dominators_cached_ancestor(candidate, limit, parents, links, stack, ready, reachable, &initialized);
            }
        }
'''+base[end:]
 if name=='pairskip':s=s.replace('            while (candidate > limit && steps != 0)','''            while (candidate > limit && steps != 0)''').replace('                candidate = parents[candidate];\n                --steps;','''                const uint32_t next = parents[candidate];
                candidate = next > limit ? parents[next] : next;
                --steps;''')
 pos=s.index('// SEMI-NCA in DFS preorder');s=s[:pos]+helper+s[pos:]
 d=p/name/f;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(s)
for inp,out in [('jump-bench','bounded-bench'),('jump-deep','bounded-deep')]:
 s=(p/inp).read_text().replace('jumpone jumptwo jumpthree jumplabel','outline4 outline8 outline16 pairskip').replace('jumplabel jumpthree jumptwo jumpone','pairskip outline16 outline8 outline4').replace('jump-','bounded-').replace('deep-jump.ok','deep-bounded.ok')
 (p/out).write_text(s)
