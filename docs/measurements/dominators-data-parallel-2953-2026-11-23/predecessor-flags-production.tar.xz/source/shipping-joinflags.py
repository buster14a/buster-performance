from pathlib import Path
from difflib import unified_diff
from subprocess import check_output
p=Path(__file__).parent
d=Path('/tmp/buster-dominators')
f='src/buster/compiler/dominators.c'
a=(d/'earlyroots'/f[4:]).read_text()
b=(d/'joinflags'/f[4:]).read_text()
start=b.index('    // Child offsets are free')
end=b.index('    uint32_t join_count',start)
s=(p/'shipping-skipjoins.c').read_text()
assert s.count('    uint32_t join_count = 0;')==1
s=s.replace('    uint32_t join_count = 0;',b[start:end]+'    uint32_t join_count = 0;')
old='join_count += cfg->predecessor_offsets[(uint64_t)target + 1] - cfg->predecessor_offsets[target] > 1;'
assert s.count(old)==1
s=s.replace(old,'join_count += is_join[target];')
base=check_output(['git','show','cc7d4ffb4:'+f],cwd=p/'tree').decode()
(p/'shipping-joinflags.c').write_text(s)
(p/'joinflags.patch').write_text(''.join(unified_diff(base.splitlines(True),s.splitlines(True),'a/'+f,'b/'+f)))
for name in ['build-skipjoins','history-skipjoins','measure-skipjoins','ordinary-skipjoins','skipjoins-corpus']:
 s=(p/name).read_text().replace('skipjoins','joinflags').replace('codex-sccp-', 'codex-dominators-')
 if name.startswith('build'):
  s=s.replace('buster-lexer-dollars-','buster-burs-rules-').replace('previous/once-built.ok','previous/timing-builds-clean.ok').replace('git apply -R "$previous/once.patch";','')
 if name.startswith('history'):
  s=s.replace('touch "$root/joinflags-triplets-built.ok"', '''git apply -R "$root/read-triplets.patch"
git apply -R "$root/joinflags.patch"
git diff --exit-code -- src
touch "$root/joinflags-triplets-built.ok" "$root/joinflags-builds-clean.ok"''')
 (p/name.replace('skipjoins','joinflags')).write_text(s)
