from pathlib import Path
from statistics import median
from hashlib import sha256
import tarfile,re
p=Path(__file__).parent;r=p/'results'
exec((p/'record-combined.py').read_text().split('current=')[0])
tree={m:series('joinflags',m,'unroll-base','dom-joinflags')for m in ('tree','loops','all','synthetic')}
old={m:series('joinflags-history',m,'historical','candidate')for m in ('tree','all','synthetic')}
for a in ['tree','loops','all']:assert len(tree[a])==19
assert len(tree['synthetic'])==len(old['synthetic'])==21
assert sha256((r/'historic-sqlite.cfg').read_bytes()).hexdigest()=='dde6529090a5641b935330fc8f5632a19651c1999194531dd2d30052740e0d98'
assert '6e60ddafad95813175997cd42db5e2ef686f00d952d4619ab1b97b18b93d14af' in (r/'joinflags-triplets-fixtures.sha').read_text()
for i in (174,1,133,789):assert re.search(r'^dominators: \d+ checks, 0 failures',(r/f'joinflags-frozen-{i}.log').read_text(),re.M)
assert 'forms=5204 checks=22641582 failed=0 excluded=0 passed' in (r/'joinflags-producer-sqlite.log').read_text()
column=['| '+k+' | '+' | '.join(pct(d[m][k]) for d,m in [(tree,'tree'),(tree,'loops'),(tree,'all'),(old,'tree'),(old,'all')])+' |'for k in tree['tree']]
synthetic=['| '+k+' | '+pct(v)+' | '+pct(old['synthetic'][k])+' |'for k,v in tree['synthetic'].items()]
title='## Predecessor flags in the complete dominator implementation'
doc=out/'README.md';assert title not in doc.read_text()
body=title+'''

Before DFS the candidate classifies sixteen consecutive predecessor counts per packet. The flags occupy the future child-offset workspace. The complete compiler was compared with cc7d4ffb4 and the archived scalar-loop compiler on the locked 9700X. Each cell gives the median paired change in core cycles across three rounds. The historical benchmark uses its original 7,806 SQLite forms. The archival compiler binary retained its published checksum. Rebuilding the CFG exporter at 0be4045eea42e8b3c8bcbf4ae20d823003f6437a and restoring the recorded corpus path reproduced the original input SHA-256, `dde6529090a5641b935330fc8f5632a19651c1999194531dd2d30052740e0d98`.

| SQLite set | Current tree | Current loops | Current combined | Historical tree | Historical combined |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(column)+'''

| Synthetic graph and output | Current parent | Historical scalar |
| --- | ---: | ---: |
'''+'\n'.join(synthetic)+f'''

The candidate met {sum(v<=1 for v in tree['synthetic'].values())} of 21 current synthetic cells and {sum(v<=1 for v in old['synthetic'].values())} of 21 historical cells. Four native frozen seeds passed. The SQLite producer checked 22,641,582 answers across 5,204 forms.

[Shipping source under test, two complete baseline comparisons and the reproduced input](predecessor-flags-production.tar.xz)
'''
with tarfile.open(out/'predecessor-flags-production.tar.xz','w:xz',preset=2)as t:
 for fn in ['joinflags.patch','shipping-joinflags.py','build-joinflags','measure-joinflags','read-triplets.patch','reproduce-triplets','restore-export-name.py','resume-joinflags-history','history-joinflags','joinflags-corpus','ordinary-joinflags','record-combined.py','record-joinflags.py']:t.add(p/fn,'source/'+fn)
 t.add(dom/'scores.py','source/scores.py')
 for pattern in ['joinflags-history-*.log','joinflags-tree-*.log','joinflags-loops-*.log','joinflags-all-*.log','joinflags-synthetic-*.log','joinflags-frozen-*.log','joinflags-producer-sqlite.log','historic-sqlite.cfg','joinflags-triplets-fixtures.sha','reproduce-triplets.log']:
  for fn in sorted(r.glob(pattern)):t.add(fn,'native/'+fn.name)
with doc.open('a')as f:f.write('\n'+body)
print(*synthetic,sep='\n')
