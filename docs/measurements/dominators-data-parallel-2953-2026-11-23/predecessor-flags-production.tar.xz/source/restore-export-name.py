from pathlib import Path
from hashlib import sha256
src=Path('/tmp/buster-1352-repro-6b097f86/recreated.cfg').read_bytes()
a=b'/var/lib/buster-9700x/corpora/preprocessor-391e729af658'
b=b'/home/david/buster-fast-bench/corpus-391e729af658'
assert src.count(a.hex().encode())==7806
data=src.replace(a.hex().encode(),b.hex().encode())
print('reproduced',sha256(data).hexdigest(),flush=True)
assert sha256(data).hexdigest()=='dde6529090a5641b935330fc8f5632a19651c1999194531dd2d30052740e0d98'
Path('/dev/shm/buster-dom-combined-6b097f86/historic-sqlite.cfg').write_bytes(data)
