#!/bin/bash
set -euo pipefail
root=/home/david/buster-fast-bench/1752-current-01a1bae5
side=${1:?}; phase=${2:?}; round=${3:?}
case "$side/$phase" in base/warm|head/warm|base/measured|head/measured) ;; *) exit 2;; esac
[[ "$round" =~ ^[0-9]+$ ]] || exit 2
out="$root/runtime/$phase-$round-$side"
mkdir -p "$root/runtime"; mkdir "$out"; mkdir "$out/db" "$out/tmp"
export LC_ALL=C
bin="$root/out/$side-ordinary-sqlite/program"
args=(--shrink-memory --reprepare --stats --journal wal --size 5 --heap 40000000 64 --testset mix1 "$out/db/speedtest1.db")
printf '%s\0' "$bin" "${args[@]}" > "$out/argv.nul"
env EXCLUSIVE_OWNER=codex-1752-current-01a1bae5 EXCLUSIVE_TITLE="PR1752 SQLite $phase $round $side" EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1752 SQLITE_TMPDIR="$out/tmp" /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 540s perf stat -x, -e cycles:u,instructions:u -o "$out/perf.csv" -- taskset -c 2 "$bin" "${args[@]}" > "$out/stdout" 2> "$out/stderr"
sha256sum "$out/db/speedtest1.db" > "$out/db.sha256"
