// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md in the Buster source tree.
//
// Original, bounded measurement-port admission fixture. Compile for real Zen 5; compare its output with Clang.
// This is correctness/identity coverage, never a performance workload. No generated program has runtime tags.

#include <immintrin.h>
#include <stdio.h>

volatile unsigned long kinds_observed;

__attribute__((noinline)) unsigned long kinds_call(unsigned long value)
{
    kinds_observed += value;
    return value * 17u + 3u;
}

__attribute__((noinline)) unsigned long kinds_integer(unsigned long seed)
{
    unsigned long a = seed + 1;
    unsigned long b = seed + 2;
    unsigned long c = seed + 3;
    unsigned long d = seed + 4;
    unsigned long e = seed + 5;
    unsigned long f = seed + 6;
    unsigned long g = seed + 7;
    unsigned long h = seed + 8;
    for (unsigned int i = 0; i < 9; i += 1)
    {
        if ((seed + i) % 3u == 0)
        {
            a += kinds_call(b + c);
            d ^= a + e;
            f += kinds_call(g + h);
        }
        else
        {
            b += d + f;
            c ^= g + a;
            e += h + b;
        }
        g += c + f;
        h ^= d + e;
    }
    return a + b + c + d + e + f + g + h;
}

__attribute__((noinline)) long double kinds_x87(unsigned long seed)
{
    long double a = 1.0L;
    long double b = 2.0L;
    long double c = 3.0L;
    for (unsigned int i = 0; i < 6; i += 1)
    {
        if ((seed + i) % 2u == 0)
        {
            a = b + c;
        }
        else
        {
            b = a + c;
        }
        c = a + b;
    }
    return a + b + c;
}

__attribute__((noinline)) unsigned long kinds_vector_mask(const unsigned int* input)
{
    __m512i a = _mm512_loadu_si512(input);
    __m512i b = _mm512_loadu_si512(input + 16);
    __m512i c = _mm512_set1_epi32(3);
    __mmask16 m0 = _mm512_cmpgt_epu32_mask(a, b);
    __mmask16 m1 = _mm512_cmpgt_epu32_mask(b, c);
    __mmask16 m2 = _mm512_cmpgt_epu32_mask(c, a);
    __mmask16 m3 = _mm512_cmpeq_epi32_mask(a, c);
    __mmask16 m4 = _mm512_cmpeq_epi32_mask(b, c);
    __mmask16 m5 = _mm512_cmpgt_epu32_mask(a, c);
    __mmask16 m6 = _mm512_cmpgt_epu32_mask(b, a);
    __mmask16 m7 = _mm512_cmpeq_epi32_mask(a, b);
    for (unsigned int i = 0; i < 4; i += 1)
    {
        if ((input[i] & 1u) != 0)
        {
            m0 = _kxor_mask16(m0, m4);
            m2 = _kxor_mask16(m2, m6);
            m5 = _kxor_mask16(m5, m7);
            a = _mm512_mask_add_epi32(a, m0, a, b);
        }
        else
        {
            m1 = _kxor_mask16(m1, m5);
            m3 = _kxor_mask16(m3, m7);
            m6 = _kxor_mask16(m6, m4);
            b = _mm512_mask_add_epi32(b, m1, b, c);
        }
        c = _mm512_mask_add_epi32(c, _kxor_mask16(m2, m3), c, a);
    }
    unsigned int output[16];
    _mm512_storeu_si512(output, _mm512_add_epi32(a, _mm512_add_epi32(b, c)));
    unsigned long sum = (unsigned long)m0 + m1 + m2 + m3 + m4 + m5 + m6 + m7;
    for (unsigned int i = 0; i < 16; i += 1)
    {
        sum += output[i];
    }
    return sum;
}

int main(void)
{
    unsigned int input[32];
    for (unsigned int i = 0; i < 32; i += 1)
    {
        input[i] = i * 7u + i % 3u;
    }
    const unsigned long integer = kinds_integer(1) + kinds_integer(2);
    const unsigned long extended = (unsigned long)kinds_x87(1) + (unsigned long)kinds_x87(2);
    const unsigned long vector = kinds_vector_mask(input);
    printf("%lu %lu %lu %lu\n", integer, extended, vector, kinds_observed);
    return 0;
}
