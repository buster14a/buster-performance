// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See LICENSE and LICENSING.md in the Buster source tree.
//
// Original supplementary admission fixture, prepared only. The first variable-loop fixture produced no x87 edge
// copies. Conditional expressions carry an F80 value across a control-flow join through a typed depth slot, rather
// than relying on promotion of an addressable C local. Actual nonzero U/T tags are still required, never assumed.

#include <stdio.h>

__attribute__((noinline)) long double kinds_x87_choose(unsigned long choice, long double a, long double b, long double c)
{
    return (choice & 1u) != 0 ? a + b : b + c;
}

__attribute__((noinline)) long double kinds_x87_nested(unsigned long choice, long double a, long double b, long double c)
{
    const long double first = (choice & 1u) != 0 ? a : b;
    return (choice & 2u) != 0 ? first + c : first - c;
}

int main(void)
{
    long double sum = 0.0L;
    for (unsigned long i = 0; i < 8; i += 1)
    {
        sum += kinds_x87_choose(i, 1.0L, 2.0L, 3.0L);
        sum += kinds_x87_nested(i, 1.0L, 2.0L, 3.0L);
    }
    printf("%.0Lf\n", sum);
    return 0;
}
