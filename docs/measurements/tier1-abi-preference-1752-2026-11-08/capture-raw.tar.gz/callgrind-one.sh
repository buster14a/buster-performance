#!/bin/bash
set -euo pipefail
root=/home/david/buster-fast-bench/1752-codex-01a1bae5
vgroot=/home/david/buster-fast-bench/1189-codex-01a1b81e-plan/valgrind-retained
side=${1:?}; workload=${2:?}
case "$side/$workload" in base/sqlite|head/sqlite|base/calls|base/tables|base/strings|base/arithmetic|base/closures|head/calls|head/tables|head/strings|head/arithmetic|head/closures) ;; *) exit 2;; esac
if [ "$workload" = sqlite ]; then bin="$root/out/$side-ordinary-sqlite/program"; else bin="$root/out/$side-ordinary-lua/program"; fi
out="$root/callgrind/$side-$workload"
mkdir "$out"; mkdir "$out/db" "$out/tmp"
export VALGRIND_LIB="$vgroot/lib/valgrind" LC_ALL=C
unset CPATH C_INCLUDE_PATH OBJC_INCLUDE_PATH
if [ "$workload" = sqlite ]; then
 args=(--shrink-memory --reprepare --stats --journal wal --size 5 --heap 40000000 64 --testset mix1 "$out/db/speedtest1.db")
else args=("$root/inputs/lua/$workload.lua"); fi
vgargs=(--tool=callgrind --dump-instr=yes --trace-symtab=yes --callgrind-out-file="$out/callgrind.out")
printf '%s\0' "$vgroot/bin/valgrind" "${vgargs[@]}" "$bin" "${args[@]}" > "$out/argv.nul"
cd "$root/inputs/lua"
date -u +%FT%TZ > "$out/start"
env EXCLUSIVE_OWNER=codex-1752-01a1bae5 EXCLUSIVE_TITLE="PR1752 $side $workload callgrind" EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1752 SQLITE_TMPDIR="$out/tmp" /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 540s taskset -c 2 "$vgroot/bin/valgrind" "${vgargs[@]}" "$bin" "${args[@]}" > "$out/stdout" 2> "$out/stderr"
date -u +%FT%TZ > "$out/end"
sha256sum "$out/callgrind.out" "$bin" > "$out/hashes"
