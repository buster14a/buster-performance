#!/bin/bash
set -euo pipefail
root=/home/david/buster-fast-bench/1752-codex-01a1bae5
side=${1:?}; kind=${2:?}; fixture=${3:?}
case "$side/$kind/$fixture" in base/ordinary/kinds-fixture|base/tagged/kinds-fixture|head/ordinary/kinds-fixture|head/tagged/kinds-fixture|base/ordinary/kinds-x87-phi|base/tagged/kinds-x87-phi|head/ordinary/kinds-x87-phi|head/tagged/kinds-x87-phi) ;; *) exit 2;; esac
clangroot=/home/david/.cache/buster/benchpress-clang/efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378
export PATH="$clangroot/bin:/usr/local/bin:/usr/bin:/bin" LD_LIBRARY_PATH="$clangroot/lib" BUSTER_CLANG_RESOURCE_DIR="$clangroot/lib/clang/23" LC_ALL=C
unset CPATH C_INCLUDE_PATH OBJC_INCLUDE_PATH BUSTER_HOST_RUNTIME BUSTER_BUILD_DEFINES BUSTER_TIER1_KINDS
label="$side-$kind-$fixture"
mkdir -p "$root/out/$label" "$root/tmp/$label" "$root/cache/$label"
export TMPDIR="$root/tmp/$label" XDG_CACHE_HOME="$root/cache/$label"
if [ "$kind" = tagged ]; then export BUSTER_TIER1_KINDS="$root/out/$label/kinds"; fi
compiler="$root/out/$side-$kind"
args=(--tier1 --tier1-strict --verify --tier1-report --tier1-schedule=none -march=znver5 -fno-asynchronous-unwind-tables "$root/inputs/fixtures/$fixture.c" -o "$root/out/$label/program")
printf '%s\0' "$compiler" "${args[@]}" > "$root/out/$label/argv.nul"
date -u +%FT%TZ > "$root/out/$label/start"
env EXCLUSIVE_OWNER=codex-1752-01a1bae5 EXCLUSIVE_TITLE="PR1752 $label fixture" EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1752 /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 540s "$compiler" "${args[@]}" > "$root/out/$label/stdout" 2> "$root/out/$label/stderr"
date -u +%FT%TZ > "$root/out/$label/end"
sha256sum "$root/out/$label/program" > "$root/out/$label/program.sha256"
