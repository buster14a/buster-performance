#!/bin/bash
set -euo pipefail
root=/home/david/buster-fast-bench/1752-codex-01a1bae5
side=${1:?}; fixture=${2:?}
case "$side/$fixture" in base/kinds-fixture|base/kinds-x87-phi|head/kinds-fixture|head/kinds-x87-phi) ;; *) exit 2;; esac
prefix="$root/out/$side-tagged-$fixture"
export LC_ALL=C
env EXCLUSIVE_OWNER=codex-1752-01a1bae5 EXCLUSIVE_TITLE="PR1752 $side $fixture execute" EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1752 /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 540s "$prefix/program" > "$prefix/native.out" 2> "$prefix/native.err"
env EXCLUSIVE_OWNER=codex-1752-01a1bae5 EXCLUSIVE_TITLE="PR1752 $side $fixture tag fit" EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1752 /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 540s bash -c 'objdump -d --no-show-raw-insn "$1/program" > "$1/disassembly" && "$2" count "$1/disassembly" /dev/null unused 0 "$1/kinds" > "$1/fit.tsv"' _ "$prefix" "$root/tools/gap"
