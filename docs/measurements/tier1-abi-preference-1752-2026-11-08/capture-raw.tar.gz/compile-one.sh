#!/bin/bash
set -euo pipefail
root=/home/david/buster-fast-bench/1752-codex-01a1bae5
side=${1:?base or head}; kind=${2:?ordinary or tagged}; workload=${3:?sqlite or lua}
case "$side/$kind/$workload" in base/ordinary/sqlite|base/tagged/sqlite|head/ordinary/sqlite|head/tagged/sqlite|base/ordinary/lua|base/tagged/lua|head/ordinary/lua|head/tagged/lua) ;; *) exit 2;; esac
clangroot=/home/david/.cache/buster/benchpress-clang/efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378
export PATH="$clangroot/bin:/usr/local/bin:/usr/bin:/bin" LD_LIBRARY_PATH="$clangroot/lib" BUSTER_CLANG_RESOURCE_DIR="$clangroot/lib/clang/23" LC_ALL=C
unset CPATH C_INCLUDE_PATH OBJC_INCLUDE_PATH BUSTER_HOST_RUNTIME BUSTER_BUILD_DEFINES BUSTER_TIER1_KINDS
label="$side-$kind-$workload"
mkdir -p "$root/out/$label" "$root/tmp/$label" "$root/cache/$label"
export TMPDIR="$root/tmp/$label" XDG_CACHE_HOME="$root/cache/$label"
if [ "$kind" = tagged ]; then export BUSTER_TIER1_KINDS="$root/out/$label/kinds"; fi
compiler="$root/out/$side-$kind"
args=(--tier1 -fno-asynchronous-unwind-tables --tier1-report --tier1-refusals --tier1-schedule=none)
if [ "$workload" = sqlite ]; then
 args+=(-DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE -I"$root/inputs/sqlite" -I"$root/inputs/st" -o "$root/out/$label/program" "$root/inputs/st/speedtest1-unity.c" -lm)
else
 args+=(-std=gnu99 -DLUA_COMPAT_5_3 -DLUA_USE_LINUX -o "$root/out/$label/program")
 for f in lapi lcode lctype ldebug ldo ldump lfunc lgc llex lmem lobject lopcodes lparser lstate lstring ltable ltm lundump lvm lzio lauxlib lbaselib lcorolib ldblib liolib lmathlib loadlib loslib lstrlib ltablib lutf8lib linit lua; do args+=("$root/inputs/lua/lua-5.4.8/src/$f.c"); done
 args+=(-lm -ldl)
fi
printf '%s\0' "$compiler" "${args[@]}" > "$root/out/$label/argv.nul"
sha256sum "$compiler" > "$root/out/$label/compiler.sha256"
date -u +%FT%TZ > "$root/out/$label/start"
env EXCLUSIVE_OWNER=codex-1752-01a1bae5 EXCLUSIVE_TITLE="PR1752 $label compile" EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1752 \
 /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 540s "$compiler" "${args[@]}" > "$root/out/$label/stdout" 2> "$root/out/$label/stderr"
date -u +%FT%TZ > "$root/out/$label/end"
sha256sum "$root/out/$label/program" > "$root/out/$label/program.sha256"
