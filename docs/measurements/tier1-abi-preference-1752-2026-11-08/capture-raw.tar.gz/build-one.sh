#!/bin/bash
set -euo pipefail
root=/home/david/buster-fast-bench/1752-codex-01a1bae5
side=${1:?base or head}; kind=${2:?ordinary or tagged}
case "$side/$kind" in base/ordinary|base/tagged|head/ordinary|head/tagged) ;; *) exit 2;; esac
clangroot=/home/david/.cache/buster/benchpress-clang/efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378
export PATH="$clangroot/bin:/usr/local/bin:/usr/bin:/bin" LD_LIBRARY_PATH="$clangroot/lib" BUSTER_CLANG_RESOURCE_DIR="$clangroot/lib/clang/23" LC_ALL=C
unset CPATH C_INCLUDE_PATH OBJC_INCLUDE_PATH BUSTER_HOST_RUNTIME BUSTER_TIER1_KINDS
printf '%s  %s\n' 141776fef464c4555a5e04387681109bd85f766ec480f1c95a8d1edcb22e58e7 "$root/kinds.patch" | sha256sum -c
cd "$root/$side"
if git apply --reverse --check "$root/kinds.patch"; then :; elif git apply --check "$root/kinds.patch"; then git apply "$root/kinds.patch"; else exit 3; fi
defines=
if [ "$kind" = tagged ]; then defines=-DBUSTER_TIER1_MEASURE_KINDS=1; fi
date -u +%FT%TZ > "$root/logs/$side-$kind-start.txt"
env EXCLUSIVE_OWNER=codex-1752-01a1bae5 EXCLUSIVE_TITLE="PR1752 $side $kind build" EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1752 \
 /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 540s \
 env BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0 BUSTER_BUILD_DEFINES="$defines" ./build.sh --jobs 8 > "$root/logs/$side-$kind-build.log" 2>&1
cp build/compiler "$root/out/$side-$kind"
sha256sum "$root/out/$side-$kind" > "$root/logs/$side-$kind.sha256"
date -u +%FT%TZ > "$root/logs/$side-$kind-end.txt"
