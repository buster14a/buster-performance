BEGIN { FS="\t" }
NR==FNR { tags[$1]=$2; next }
/^[0-9a-f]+ <[^>]+>:/ { name=$0; sub(/^[0-9a-f]+ </,"",name); sub(/>:.*/,"",name); i=0; next }
/^[[:space:]]*[0-9a-f]+:/ && name in tags { i++; kind=substr(tags[name],i,1); if (kind=="T" || kind=="U" || kind=="e") printf "%s\t%d\t%s\t%s\n",name,i,kind,$0 }
