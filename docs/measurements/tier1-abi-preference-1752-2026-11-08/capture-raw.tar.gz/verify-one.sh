#!/bin/bash
set -euo pipefail
root=/home/david/buster-fast-bench/1752-codex-01a1bae5
side=${1:?}; workload=${2:?}
case "$side/$workload" in base/sqlite|head/sqlite|base/calls|base/tables|base/strings|base/arithmetic|base/closures|head/calls|head/tables|head/strings|head/arithmetic|head/closures|oracle/calls|oracle/tables|oracle/strings|oracle/arithmetic|oracle/closures) ;; *) exit 2;; esac
if [ "$side" = oracle ]; then bin="$root/out/lua-oracle/program"; elif [ "$workload" = sqlite ]; then bin="$root/out/$side-ordinary-sqlite/program"; else bin="$root/out/$side-ordinary-lua/program"; fi
out="$root/verification/$side-$workload"
mkdir -p "$out/db" "$out/tmp"
export LC_ALL=C
if [ "$workload" = sqlite ]; then
 args=(--shrink-memory --reprepare --stats --journal wal --size 5 --heap 40000000 64 --testset mix1 --verify "$out/db/speedtest1.db")
else args=("$root/inputs/lua/$workload.lua"); fi
printf '%s\0' "$bin" "${args[@]}" > "$out/argv.nul"
cd "$root/inputs/lua"
env EXCLUSIVE_OWNER=codex-1752-01a1bae5 EXCLUSIVE_TITLE="PR1752 $side $workload verification" EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1752 SQLITE_TMPDIR="$out/tmp" /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 540s taskset -c 2 "$bin" "${args[@]}" > "$out/stdout" 2> "$out/stderr"
