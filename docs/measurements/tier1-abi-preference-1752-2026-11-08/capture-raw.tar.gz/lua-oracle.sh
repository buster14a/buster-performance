#!/bin/bash
set -euo pipefail
root=/home/david/buster-fast-bench/1752-codex-01a1bae5
clangroot=/home/david/.cache/buster/benchpress-clang/efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378
export PATH="$clangroot/bin:/usr/local/bin:/usr/bin:/bin" LD_LIBRARY_PATH="$clangroot/lib" LC_ALL=C
unset CPATH C_INCLUDE_PATH OBJC_INCLUDE_PATH
mkdir -p "$root/out/lua-oracle"
args=(-O0 -std=gnu99 -DLUA_COMPAT_5_3 -DLUA_USE_LINUX -o "$root/out/lua-oracle/program")
for f in lapi lcode lctype ldebug ldo ldump lfunc lgc llex lmem lobject lopcodes lparser lstate lstring ltable ltm lundump lvm lzio lauxlib lbaselib lcorolib ldblib liolib lmathlib loadlib loslib lstrlib ltablib lutf8lib linit lua; do args+=("$root/inputs/lua/lua-5.4.8/src/$f.c"); done
args+=(-lm -ldl)
printf '%s\0' "$clangroot/bin/clang" "${args[@]}" > "$root/out/lua-oracle/argv.nul"
env EXCLUSIVE_OWNER=codex-1752-01a1bae5 EXCLUSIVE_TITLE="PR1752 Lua reference build" EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1752 /home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=10s 540s "$clangroot/bin/clang" "${args[@]}" > "$root/out/lua-oracle/stdout" 2> "$root/out/lua-oracle/stderr"
sha256sum "$root/out/lua-oracle/program" > "$root/out/lua-oracle/program.sha256"
