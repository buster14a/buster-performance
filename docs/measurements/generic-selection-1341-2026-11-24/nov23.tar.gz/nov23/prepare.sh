#!/bin/sh
# Inputs of #1341's acceptance: main's own main.c preprocessed once by main's compiler, the predefines, and the
# generated _Generic units (tools/microarch/uarch.c's generate-generic, written out here).
set -e
D=/tmp/c1341/w; S=$D/s1341; mkdir -p $S; cd /tmp/c1341/main
clang -dM -E -march=znver5 -fwrapv -funsigned-char -x c /dev/null > $S/predefines-znver5.h
$D/bin/main -E -march=znver5 -Isrc -fwrapv -funsigned-char -o $S/main.i src/buster/compiler/main.c
wc -c $S/main.i; grep -c _Generic $S/main.i || true
for n in 1000 2000 4000 8000 16000; do
  i=0; while [ $i -lt $n ]; do echo "int f$i(int a, long b) { int x = a * $i + (int)b; int y = _Generic(x, int: x + 1, long: x - 1, default: 0); return x + y; }"; i=$((i+1)); done > $S/generic-$n.c
done
ls -la $S
