#!/bin/sh
# One round ($1 rotates the build order): main.c -fsyntax-only --time-stages on CPU 2 for each build, then the
# generated units on main and b2669.
D=/tmp/c1341/w; S=$D/s1341; cd $S; r=$1; mkdir -p raw
cat /proc/loadavg; ps -eo psr,pcpu,pid,etimes,user,comm --sort=-pcpu | head -6
set -- b2669 m2669 main; n=$#; i=0
while [ $i -lt $n ]; do
  j=$(( (i + r) % n + 1 )); eval b=\${$j}
  s=$(date +%s%N)
  taskset -c 2 $D/bin/$b -fsyntax-only --predefines predefines-znver5.h -march=znver5 -fwrapv -funsigned-char -fno-strict-aliasing --time-stages main.i > raw/$r-main-$b.log 2>&1
  echo "$b main.i status=$? wall_us=$(( ($(date +%s%N) - s) / 1000 ))" | tee -a raw/$r-main-$b.log
  for g in 1000 2000 4000 8000 16000; do
    taskset -c 2 $D/bin/$b -fsyntax-only --time-stages generic-$g.c > raw/$r-generic-$g-$b.log 2>&1
  done
  i=$((i + 1))
done
cat /proc/loadavg
