#!/bin/sh
# The issue's own input: main.c at 9e7f918f, preprocessed once by main's compiler; then 5 rotated rounds, each under
# the lock, of -fsyntax-only --time-stages by b2669, m2669 and main on CPU 2.
D=/tmp/c1341/w; S=$D/s1341; L=~/buster-fast-bench/exclusive.sh
export EXCLUSIVE_OWNER=claude-1341-1379-1387 EXCLUSIVE_TITLE="9700X acceptance: #1341 #1379 #1387" EXCLUSIVE_LINK=https://claude.ai/code/session_01EgbxngFHzyrnWayfMuSLbk
[ -d /tmp/c1341/old ] || git -C $D/repo worktree add -q --detach /tmp/c1341/old 9e7f918f
cd /tmp/c1341/old && $L $D/bin/main -E -march=znver5 -Isrc -fwrapv -funsigned-char -o $S/old.i src/buster/compiler/main.c; echo "old.i $(wc -c < $S/old.i) bytes, $(grep -o _Generic $S/old.i | wc -l) _Generic"
cd $S; mkdir -p raw
for r in 0 1 2 3 4; do
  $L sh -c 'cat /proc/loadavg; set -- b2669 m2669 main; for k in 0 1 2; do eval b=\${$(( (k + '$r') % 3 + 1 ))}; s=$(date +%s%N); taskset -c 2 '$D'/bin/$b -fsyntax-only --predefines predefines-znver5.h -march=znver5 -fwrapv -funsigned-char -fno-strict-aliasing --time-stages old.i > raw/'$r'-old-$b.log 2>&1; echo "$b status=$? wall_us=$(( ($(date +%s%N) - s) / 1000 ))" | tee -a raw/'$r'-old-$b.log; done; cat /proc/loadavg'
done
