/home/david/buster-fast-bench/codex-180-fix-20261026-evidence/inline-final-current92-generated-proof/clang-reference: \
  /home/david/buster-fast-bench/codex-180-opt-20261026-evidence/runtime.c \
  /usr/lib/clang/23/include/stdint.h /usr/include/stdint.h \
  /usr/include/bits/libc-header-start.h /usr/include/features.h \
  /usr/include/features-time64.h /usr/include/bits/wordsize.h \
  /usr/include/bits/timesize.h /usr/include/stdc-predef.h \
  /usr/include/sys/cdefs.h /usr/include/bits/long-double.h \
  /usr/include/gnu/stubs.h /usr/include/gnu/stubs-64.h \
  /usr/include/bits/types.h /usr/include/bits/typesizes.h \
  /usr/include/bits/time64.h /usr/include/bits/wchar.h \
  /usr/include/bits/stdint-intn.h /usr/include/bits/stdint-uintn.h \
  /usr/include/bits/stdint-least.h /usr/include/stdio.h \
  /usr/lib/clang/23/include/stddef.h \
  /usr/lib/clang/23/include/__stddef_size_t.h \
  /usr/lib/clang/23/include/__stddef_null.h \
  /usr/lib/clang/23/include/stdarg.h \
  /usr/lib/clang/23/include/__stdarg___gnuc_va_list.h \
  /usr/include/bits/types/__fpos_t.h \
  /usr/include/bits/types/__mbstate_t.h \
  /usr/include/bits/types/__fpos64_t.h /usr/include/bits/types/__FILE.h \
  /usr/include/bits/types/FILE.h /usr/include/bits/types/struct_FILE.h \
  /usr/include/bits/types/cookie_io_functions_t.h \
  /usr/include/bits/stdio_lim.h /usr/include/bits/floatn.h \
  /usr/include/bits/floatn-common.h
