#!/usr/bin/env bash
set -euo pipefail
workdir="$HOME/buster-fast-bench/1453-codex-20261106-perf"
export EXCLUSIVE_OWNER=codex-1453 EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1453 LC_ALL=C
for round in 1 2 3; do
  if [[ "$round" == 2 ]]; then order=(candidate13 ec5head); else order=(ec5head candidate13); fi
  for version in "${order[@]}"; do
    export EXCLUSIVE_TITLE="PR 1453 $version warning-dense diagnostic sample $round"
    "$HOME/buster-fast-bench/exclusive.sh" bash -c '
      set -euo pipefail
      version="$1"; round="$2"; workdir="$3"
      test "${BUSTER_9700X_HELD:-}" = 1
      cp "$workdir/$version/build/compiler" "$workdir/compiler"
      prefix="$workdir/$version-dense-$round"
      { printf "held=%s\n" "$BUSTER_9700X_HELD"; cat /var/lib/buster-9700x/owner; sha256sum "$workdir/compiler" "$workdir/warning-dense.c"; } > "$prefix.receipt"
      taskset -c 2 perf stat -x, -e instructions:u,cycles:u -o "$prefix.perf" -- "$workdir/compiler" -std=c23 -fsyntax-only -fno-caret-diagnostics "$workdir/warning-dense.c" > "$prefix.out" 2> "$prefix.err"
      { printf "status=0\n"; cat /var/lib/buster-9700x/owner; sha256sum "$prefix.out" "$prefix.err"; } >> "$prefix.receipt"
    ' -- "$version" "$round" "$workdir"
  done
done
