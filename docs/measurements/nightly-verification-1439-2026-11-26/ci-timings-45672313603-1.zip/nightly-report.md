## Nightly main measurements

No plan: it is before 22:00 Europe/Madrid, the evening before the window: the cycle's snapshot isn't pinned yet.
