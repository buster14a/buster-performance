# ci

Run commands and resolve source paths from the repository root. Follow the
[shared agent rules](../../AGENTS.md), including the 9700X lock and `cores`
requirements. [Command index](README.md).

## Every main revision

Every change reaches `main` through the merge queue (#1430). The queue's
candidate runs the complete hosted contract on its exact commit before it
merges: every row and sanitizer, the vector pool, the fuzz campaigns and the
auxiliary workflows its change touches. Documentation-only changes run it too.
A push to `main` runs no checks (the owner's decision on 2026-11-10). Each
candidate takes its own run-id concurrency group. PRs still cancel only their
own superseded runs, and the hardware lock still serializes the 9700X.

Do not add a push trigger or a candidate path filter. Do not treat a
successful PR run or Measurement storage as a candidate's own hosted rows, and
don't let native-evidence reuse suppress them. `changes --self-test` checks the
triggers, concurrency and hosted-scope policy with counterexamples, a restored
push trigger among them. `tests/ci/nightly.sh` checks the candidates' evidence
and coverage. Before the queue, every push ran its own hosted rows (#1271):
the plain rows in the nightly mode (#2057), and the full matrix before it.

## Early hosted feedback and reproductions (#1427)

Every hosted job that runs the compiler is a drawn item on an AVX-512 runner
(#2924). Each plain item of a pull request's or a merge-queue candidate's run
gives its first result at the start of its own run: the step **Early hosted
feedback (not qualification)**, just before "Run correctness tests within the
hosted CPU budget". It adds no build: it runs the item's compiler, built or
installed. It runs the fixed driver corpus (`tests/ci/feedback/`, no random
seed), which:

- preprocesses, parses and checks a unit;
- emits two units' objects and links them with clang;
- runs the program;
- checks an undeclared-identifier diagnostic.

A failure stops the item before its suite, as the suite's own first failure
would (`--fail-fast`). The step qualifies nothing: the suite runs the corpus's
heading, `Test the early driver feedback corpus`, in its deal, and every row,
item, sanitizer configuration and merge-queue case is unchanged. Sanitizer items
skip the step, and so do dispatched and nightly runs, whose suites report every
command. On pull requests and candidates, plain shard 1 also checks that the
corpus fails on a compiler broken in each area it promises
(`tests/ci/feedback.sh --compiler`). #2034's accounting counts the early step as
first useful feedback (`accounting_phase`).

`tools/ci/feedback.sh` records each item's build, early step and suite. Each
record holds:

- the log and the exact inventory and runner arguments (`command.sh`,
  `selected.tests`);
- the revision, configuration and flags;
- the CPU (`cpu.txt`) and the draw's probe answers (`probe.txt`);
- the tool pins and the apt manifest;
- retained failing cases;
- `result.tsv`, which tells a product failure from an infrastructure failure
  and an incomplete run (a cancellation or a timeout, which never passes).

The item uploads the records as `feedback-ROW-SANITIZER-O3-shardK-ATTEMPT`.
To replay one, check out its `revision` clean and run `bash
/path/to/artifact/reproduce.sh` on Ubuntu 26.04:

- The CPU must pass the vector probe (`tools/ci/vector-probe.c`). A `native`
  record needs the recorded CPU model too.
- It uses the original run's prepared offline inputs through `gh` while
  they're retained. Otherwise it acquires them again and refuses an apt closure
  that differs from the record.
- It then runs the item's setup and build steps in order, and the recorded
  command.

A full rerun on GitHub is `9700x.yml`'s `full` dispatch.

The `changes` job adds an **advisory** affected-test plan to its summary
(`continue-on-error`). Its dependency map is `feedback_rules` in
`tools/ci/feedback.c`, and heading ownership is `feedback_heading`:

- Frontend edits select every downstream group; checker edits include
  emission, execution and diagnostics.
- Headers, unknown paths and build, toolchain, CI and selector changes expand to
  every group, as does an empty change list.
- Documentation is exempt, except the CI and toolchain policy guides.
- An unclassified heading always runs, every decision has its reason, and a
  malformed plan publishes no commands.

The plan selects nothing in CI. Locally, `feedback.sh run DIR PROFILE` runs a
plan through `parallel` with the same records. PROFILE is one of:

- `smoke`: the corpus alone, as the early step runs it;
- `affected`, the groups of the paths in the file `BUSTER_FEEDBACK_FILES`
  names;
- `frontend`, `checker`, `object`, `link` or `diagnostics`, one group;
- `full`: the whole inventory, as each item's suite runs it.

The `affected` and group profiles always run the corpus and the lexer,
link-representation and diagnostic-ordering regressions too.

```sh
bash tests/ci/feedback.sh                                    # in the CI glue fixtures job
bash tests/ci/feedback.sh --compiler build/compiler          # the corpus's mutants, plain shard 1's step
BUSTER_COMPILER=build/compiler bash tools/ci/feedback.sh run build/feedback checker --jobs 4
```

## The merge queue

`9700x.yml` runs on `merge_group` (`checks_requested`, main, no path filter),
the merge queue's candidates (#1430). Main's ruleset requires the queue with no
bypass, and the checking workflows have no `push` trigger: a push to main runs
nothing, since the queue tested it before it landed.

- **What a candidate runs.** The full hosted contract on its exact commit,
  documentation alone included:
  - the `native` plain row (#2032; the `x86-64` rows are gone with the scalar
    host, #2924);
  - the vector pool;
  - the three fuzz campaigns.

  It takes its own run-id concurrency group. Like a pull request's run, it
  stops at its first failure (the owner's choice on 2026-11-12):
  - its tests and fuzz campaigns wait for the policy job;
  - its rows, shards, vector draws and the fuzz campaigns' draws fail fast,
    each within its own matrix;
  - each shard stops at its first failing command (`parallel --fail-fast`,
    #2703), as a pull request's does;
  - once its test rows or fuzz campaigns have failed, `stop-tests` or
    `stop-fuzz` cancels its run (#2703), so its aggregate fails at once
    rather than after the other matrix (the fuzz campaigns take about 21
    minutes).
  It never uses the 9700X (`hardware=skip`, reason `merge-group`), and
  SQLite's full Tcl suite stays nightly.
- **Selector.** `changes --event merge_group --files LIST --workflow
  .github/workflows/9700x.yml` is its profile: `code`, `measure=all` and
  `performance`, whatever it changes. LIST is the candidate's own change,
  `HEAD^1..HEAD`, which picks its `auxiliary` workflows.
- **Auxiliary workflows.** The candidate calls `build.yml`, `build-pgo.yml`,
  `selfhost.yml` and `tier1-problem.yml` (job `auxiliary-NAME`) where its
  change touches a path in that workflow's `pull_request` list. The selector
  reads the list from the workflow. A pull request runs them from their own
  triggers.
- **Invalidated candidates.** The `stale` job (`bash tools/ci/nightly.sh stale
  DIR`, decided by `nightly stale --run RUN < CANDIDATES`) cancels unfinished
  candidate runs whose branch GitHub deleted or moved and whose commit isn't on
  main. It never gates, and a failed read cancels nothing.
- **Aggregate.** The required aggregate passes a candidate only through its
  coverage step, `bash tools/ci/nightly.sh coverage DIR`. That step reads the
  run's jobs and runs `nightly coverage --run RUN < FACTS`, which needs:
  - the native plain row's verdict (drawn since #2924);
  - the vector verdict;
  - the fuzz campaigns' verdict (they draw AVX-512 runners through
    `drawn.yml`, #2924);
  - every job of each auxiliary workflow the selector named
    (`--auxiliary "$AUXILIARY"`), but its draws' skipped ones, and its drawn
    job's one verdict; and none of the others;

  all completed and successful. `qualification.c` reads the step's outcome
  (`COVERAGE_RESULT`); no other event runs the step.
- **Record and credit.** The coverage record has purpose `queue`, and its
  `pr_head` is the merge's second parent. The nightly's evidence glue, run
  listing and harvest accept the candidate's runs of the same commit. Once
  one is credited, the report lists the states without a passing candidate run
  as coverage gaps.
- **Hotfix entry.** Label a pull request `hotfix` to queue it without waiting for its own rows. `hotfix.yml`
  reports `Integration qualification` passed when the label is added, and `9700x.yml` skips the aggregate on the
  pull request's later pushes. Its candidate still runs everything. Use it for fixes that must land fast: a
  hotfix that fails does so in the queue, where it costs the entries behind it a rebuild.
- **Accounting.** `ci-timings.yml` reports outcomes separately from candidate
  fate (merged, live, confirmed invalidated, unknown), all collected attempts'
  runner-minutes, feedback/completion-proxy latency and hosted job queue waits
  (`timings --accounting`, #2034). Failed reads do not prove invalidation.
- **Policy pins.** `changes --self-test` pins the trigger, the concurrency
  group, the selector's routing, the auxiliary calls and the aggregate's
  coverage step. Its mutants include a path filter, another branch or type, a
  shared slot, a skipped selector or coverage step, an auxiliary workflow never
  called or not awaited, and its list unchecked.

[The merge queue](../ci.md#the-merge-queue) has the details and the ruleset's
settings.

## Clang Static Analyzer

Pull requests and merge-queue candidates each run a separate `Clang Static Analyzer`
job on GitHub-hosted Ubuntu 26.04. It checks the triggering merge revision,
including documentation-only changes. The job uses the pinned CI Clang and
the ordinary vector Release build's translation units and flags from
`build.sh print-sources` and `build.sh print-compile-flags`. It uses one
analyzer process per available CPU. Static analysis does not execute the
compiler or need an AVX-512 runner.

Each analyzer finding is a Clang error. The job finishes the sweep, fails
qualification and retains the diagnostic paths as an artifact. A candidate's
analyzer failure also stops the rest of that candidate's run. An optional
build configuration such as libFuzzer needs its own analysis invocation.
[Hosted timing evidence](https://github.com/buster14a/buster-performance/tree/4087a9e563960f17e9e1fc2729f7904e12343270/docs/measurements/merge-queue-clang-analyzer-2026-11-18).

## The compile's count before the merge

No pull request or candidate reaches the 9700X, and hosted runners count no
instructions, so a change's cost to the compile is counted another way before
it merges (#2850). The compiler built with clang's `-fprofile-instr-generate`
keeps a counter for each region of its own source; **the count** is their sum
after one `-c` of the frozen `sqlite3.c` on one lane.

**Count the compile against its base's** takes it on the vector row's plain
shard 4, on pull requests and merge-queue candidates that change the compiler's
sources, its build or the count's own files:

- `tools/ci/compile-count.sh` builds the change and its first parent that
  way, each from its own `print-sources` and Release flags at `-O0`. That
  takes half a minute each, while shard 1 builds the row's product.
- Each executable compiles the unit three times, with the corpus's headers
  and predefines.
- `tools/ci/compile-count.c` reads the raw profiles (format version 11, as
  clang 23.1.4 writes it; another version is refused by its number) and
  compares the two medians.

The verdict:

- A change may move the count by **half a percent**, above or below, without
  saying so.
- A change that means to move it further, a feature's cost or a cut's gain,
  **states its move** in a file of its own,
  `tools/ci/compile-count/NAME.txt`, NAME being its branch's last part. The
  file's last line that isn't empty or a comment (`#`) is the move in percent
  of its base's count and what moved it. The failing step prints the line to
  write (`+7.25 what moved it`). The change is then held to within half a
  percent of what it states.
- A change's statements are the `*.txt` files there that it adds or changes
  against its base; their percentages add up. Files its base holds the same
  are earlier changes' statements, and no later change is held to them. A
  change may delete them: a file it deletes states nothing.
- Each change states in its own file because one shared line, which every
  stating change replaced, made any two open changes that stated moves
  conflict.
- Runs of one executable more than 0.05% apart are no verdict (exit status
  2), and neither are a build that fails, an executable that writes no
  profile, and a statement file with no well-formed line. The CI glue
  fixtures check every statement file in the tree is well formed.
- The step is skipped where the change touches none of the compiler's
  sources, its build, the count's own files, the toolchain's pin, the
  corpus's fetch or the row's workflow.

The base is counted on the same runner in the same step, so main's drift
fails no change. A fixed baseline's does: the 9700X's instructions' baseline
below had 0.11% left a day after it was set, and a branch run had crossed it.

What the count is, measured at `ef3d4475f`
([record](https://github.com/buster14a/buster-performance/tree/main/docs/measurements/compile-count-2850-2026-11-24)):

- 315,170,858 for `sqlite3.c`, of which a one-function unit's 5,387,592 are
  the process's start and the tables a real executable has baked. The step
  prints both sides' one-function counts, so that a move of the start can be
  told from a move of the unit's work.
- Runs of one executable are within 0.0005% of each other: about one run in
  five counts up to 1,500 fewer of 315 million.
- An `-O0` and an `-O1` build count the same, since the counters are placed
  before any optimization, and so do a `native` build and the explicit vector
  target's.
- At #3381's merge, the regression the check was asked for, it counts 7.25%
  over its parent (the instructions rose 7.0%), and the one-function unit's
  count doesn't move.

What it doesn't see: the count is how many times each region runs, not what a
region costs. A change that makes a region slower without running any region
more or less often, a slower vector kernel's straight-line code, a larger
clear, time in the C library or the kernel, moves no counter. The
executable is also unbaked, so a table the real executable has baked counts
at its start (the one-function unit's count shows it). The 9700X's step,
"Hold sqlite3.c's compile to its instructions' baseline" below, and its
timings stay what tell of those, after a merge.

The step is advisory (`continue-on-error`) until hosted runs of other changes
have shown the specification's two other predictions: runs within 0.05% on the
runners drawn, and the step under 12 minutes. Its own pull request's two runs
did, on an EPYC 9V45 and a 9V74: three runs 0.0004% apart in 46 s, and three
identical runs in 66 s. The two runners' counts were 0.00005% apart; the
check compares none across runners.

```sh
bash tests/ci/compile-count.sh                      # in the CI glue fixtures job: the reader, the verdicts, fake checkouts
git worktree add --detach build/count-base origin/main
bash tools/ci/fetch-corpus.sh build/corpus
bash tools/ci/compile-count.sh check build/count-base . build/corpus build/compile-count
```

## Sharing the 9700X

Correctness CI runs on GitHub-hosted Ubuntu 26.04 with the official stable
Clang/LLVM 23.1.4 release, in native host builds (the baseline `x86-64` rows
are gone, #2924). A native build needs a CPU with `host_isa.h`'s complete
vector feature set, so the native row is drawn on qualifying runners too.
On a pull request the native row is the vector row instead (#2033): the
explicit vector target (`BUSTER_HOST_ARCH=vector`, `host_isa.h`'s predicate),
whose plain configuration's 4 shards are items that each draw's collector
assigns, by rank, to the hosted runners whose probe found their CPU qualifies
(`tools/ci/vector-draw.sh`, tested by `bash tests/ci/vector-draw.sh`), drawn in
up to 4 levels, with no emulation; an item no qualifying CPU held fails it as
incomplete ([The vector row](../ci.md#the-vector-row)). Where the sanitizer rows
run, the vector row runs beside `native` with the plain and the three sanitizer
configurations, 16 items in one pool of draws, the costliest first. Each
configuration's item 1 builds its compiler and publishes it; its other items
install that product (`tools/ci/hosted-product.sh`, #2032). Its race fixture is
`.github/workflows/vector-claim-race.yml`.
Artifact rendezvous uses the job-scoped Results service through
`.github/actions/vector-runtime`, with no REST fallback (#2309). Fresh PR
vector rows have a 16-request REST ceiling, including quota observations;
reruns use bounded identity reads and refuse unknown state. The verdict
reports request ledgers and shared-quota headers; see [Vector REST
budget](../ci.md#vector-rest-budget-2309). After changes, run the shell
fixture above and `node tests/ci/vector-runtime.cjs`; both run in the PR's
`CI glue fixtures` job.
Each row (`.github/workflows/hosted-correctness.yml`, which the test job calls
per row) runs its inventory as its own number of shards, a runner each:
`parallel --shard K/N --costs tools/ci/costs/ROW.costs` deals the commands by
the row's hosted costs, the same deal on every shard's runner, so the shards run
each command once ([Shard costs](#shard-costs)). Each vector configuration
builds its compiler once, on a qualifying CPU, and its items verify and run that
product (`tools/ci/hosted-product.sh`; [Shared row
products](../ci.md#shared-row-products), #2032); the `native` plain row's items,
drawn on qualifying CPUs as the vector row's are (#2924), each build their own
(a native build must run on the CPU it was built for), which is why the
`native` sanitizer rows went (#2032). Run
`bash tests/ci/hosted-product.sh` after changing the product's packing, identity
or checks. A plain row's test step took 14.6 minutes on one 4-CPU runner; its
4 shards take about 4 to 6. The steps a row needs once (the native row's arena
checks, the parser smoke test, the performance
readers and the TSan/MSan `main.c` compiles) run in its shard 1.
The repository syntax check retains each build's sanitizer feature flags and
predefines, while excluding its exact host-only detector and frame controls
(#1423). The compiler executing the check remains instrumented.
On merge-queue candidates and the daily and dispatched runs, the nightly
snapshot's daily run among them (not on pull requests, which they would hold up
for over an hour; before the queue, on pushes before the nightly mode), the
vector row's configurations also run the inventory under
`BUSTER_SANITIZER=address|thread|memory` (the `native` sanitizer rows went in
#2032 and the `x86-64` rows in #2924; `native` keeps its plain row), but the
compiler's own `main.c` checking comparison in the TSan and MSan rows, whose
measured memory (docs/ci.md) exceeds a hosted runner's; their `-c` compiles run
in a separate step after the suite. ASan combines UBSan, bounds,
leak and stack-lifetime checks; TSan and MSan use separate builds.
Standalone `BUSTER_SANITIZER=undefined` remains available for manual diagnosis,
but no longer repeats the full suite on every candidate. Diagnostic
builds default to `-O3`, frames and line information, with fatal symbolized detector
proofs and child-report auditing. `BUSTER_FUZZ_AVAILABLE=1` adds in-process
coverage and the `--fuzz` driver override; `BUSTER_FUZZ_ENTRY=FILE.c` replaces
its byte-input callback. Hosted frontend, ELF and crash/replay campaigns gate
the same runs. The hosted matrix runs at `-O3` throughout;
`BUSTER_SANITIZER_OPTIMIZATION=1|2|3` remains available for explicit diagnostic builds.
See `docs/ci.md` for usage and the precise coverage boundaries.
After all the hosted variants and fuzz jobs a run has pass on the same triggering revision, Benchpress
requires the complete vector feature set and runs native correctness before
benchmarks, reusing one build and the existing shared lock. Pull requests never
run it (#2055, the owner's choice on 2026-11-10): hosted correctness qualifies a
pull request, and native correctness and measurements run on its merged
first-parent state in the nightly window. The required aggregate passes a pull
request on its hosted rows and says so. Hosted rows and full native runs share `tools/ci/correctness.tests`.
A backlog state reusing its exact merge-queue candidate's successful full vector
contract runs `tools/ci/znver5-smoke.tests` on the measured binary. Snapshot and
manual full runs exercise the complete native inventory. Failed, cancelled or
skipped hosted tests cannot queue the hardware job; failed native tests cannot
start benchmarks. A pull request's run stops at its first failure: its test rows
fail fast, each shard stops at its first failing command (`parallel
--fail-fast`, #2703), and its tests don't start when the guide-size or DCO hook
check fails. A merge-queue candidate's run does too, its fuzz campaigns fail
fast as well, and its first failed test or fuzz matrix cancels the run. Pushes to main, the daily and dispatched runs report every row. The
existing required check name is retained by a hosted aggregation job that fails
when either stage fails.
Draft and ready PRs alike get hosted feedback and never queue hardware.
Ready/draft transitions start a new run and cancel the superseded run in the
same PR group. The required aggregate passes a code-changing draft on its hosted
rows as it does a ready PR, and the selector's legitimate no-code exemption
still passes. Its C predicate in
`tools/ci/qualification.c` exhaustively tests the allowed outcomes, including
missing/invalid/skipped results and event/selector consistency.
See [the CI guide](../../docs/ci.md) for tool and frozen-input setup.

Agent sessions and CI share the 9700X: the buster14a org's self-hosted runner
runs on the same machine. Its timings only mean something when one thing runs
there at a time, so everything takes one lock:

- Run every build, test, benchmark and perf run there through
  `EXCLUSIVE_OWNER=<name> ~/buster-fast-bench/exclusive.sh COMMAND...`.
  Also set `EXCLUSIVE_TITLE` to the session's title and `EXCLUSIVE_LINK` to
  its link (its claude.ai page, or else the PR or issue it works on): whoever
  waits sees them in `/var/lib/buster-9700x/owner`.
- The runner's job hooks take the same lock for every CI job. Sessions and CI
  jobs wait for it alike: neither goes first. A CI job's owner lines give its
  workflow, job, PR number and title (or a push's first line), the run's link
  and the PR's.
- Hold the lock per run, never around a series of runs: a CI job waits for it
  and times out after 10 minutes.
- No pull request runs a 9700X job (#2055, the owner's decision on
  2026-11-10): its merged first-parent state is measured in the nightly window,
  where each job queues behind the others, so keep the job short. A state's
  backlog run decides as a pull request's run did, on the state's change against
  its first parent. It runs a benchmark's plain run, which checks its paths
  against their scalar twins, where that change touches what the benchmark
  measures (the `changes` job's `measure`): a file that the benchmark's
  translation unit includes, for one built as a unit of its own (the build's
  `*_benchmark.c`), or one that its entry in `changes_benchmarks` names, for one
  in `main.c`'s units (the files that define the functions it calls); or the
  benchmark's own step. A change to the build's description (`build.sh`,
  `CMakeLists.txt`, `cmake/`) runs every one. Pushes to main ran every one
  before the nightly mode (below), then what their first-parent change
  selected; since the merge queue (#1430) they run nothing, and the nightly
  backlog measures every state. A new benchmark's
  step gets an entry in `changes_benchmarks` and an `if:` on `MEASURE`, as the
  others have. Its isolated and after-scalar samples (`--only`, `--after-scalar`,
  repeated processes), which cost about 200 ms before each of 21 samples per
  case, go in a step of their own that runs where the `changes` job's output
  for the module isn't `false`: on the daily scheduled run, dispatched runs and
  pull requests that change the module's sources (its `changes_modules` entry,
  which no `*_test.c` matches: tests don't change what the samples measure).
  Keep the pattern to what the samples measure: a module's own decision
  campaign (#336's binding handoff) has a module of its own, not the whole
  checker's. Samples of different code split by what changes each: #336's
  time the default handoff (`direct`) where its inputs change, and the
  comparison of every mode only where the handoffs themselves do
  (`checker_binding_modes`); #395's time the passes the rows' producers reach
  (`emit` and `build`) where the emission, the lowering or Tier 0 change, and
  every pass only where the rows' own passes do (`check_debug_rows`).
  The daily and dispatched runs time them all. A step gated so also runs on
  the pull request that changes it.
  The same holds for the linkers' baselines and floors, mold's and wild's
  foreign phases, `clang -E`'s times beside the preprocessor's benchmark
  (`--clang`, its harness `c_preprocessor_benchmark.c`) and the first-party
  performance readers' qualification (`tools/performance`, `docs/performance`,
  `web/perf`, their pin; a change to `docs/performance` alone runs the job for
  it). A push
  to main runs none of them before the nightly mode: its pull request's run
  measured what it changes, and the full set took the job past its 10 minutes.
  The daily and dispatched runs, and the nightly snapshot's, have 25 minutes;
  a nightly backlog run has a pull request's 20.
- The job's last measurement holds the compile to a count (#2850): "Hold
  sqlite3.c's compile to its instructions' baseline" runs `measure-compile
  --runs 3 --instructions-baseline tools/ci/compile-instructions.txt` on the
  frozen `sqlite3.c`, and fails where the default compile's median user
  instructions are more than 0.5% from the file's count, above or below. The
  count repeats to a thousandth on the 9700X, and a day of main's merges once
  moved it 15% unseen (11% of it one merge's regression). No pull request's or
  candidate's run reaches the 9700X, so the step tells after the merge, in the
  nightly's runs ([the count before the merge](#the-compiles-count-before-the-merge)
  is the hosted row's):
  - A change that means to move the count, a feature's cost or a cut's gain,
    states it: it writes the count the step prints into the file.
  - A count out of its band that no change meant is a regression. The
    instructions place it exactly: count main's merges since the last run that
    passed, each built as the job builds it.
  - The file's count is this job's build's (`BUSTER_HOST_ARCH=znver5`) on this
    host. A toolchain's upgrade moves it, and states it the same way.
- On a checker pull request, plain hosted vector shard 2 builds the first
  parent of the tested merge while shard 1 builds the merge revision. Shard 2
  compiles the same frozen `sqlite3.c` with both compilers and compares the
  objects (#1572).
  A change classified as diagnostic-only by `sqlite_stable` requires
  byte-identical objects. For other checker changes, a byte difference
  produces a GitHub warning with both file sizes. Growth or shrinkage
  greater than 10% of the base object's bytes fails the shard. This allows
  localized lowering changes such as #1376 while flagging large changes
  across the amalgamation. Run `bash tests/ci/compare-sqlite-objects.sh`
  to check the size boundaries and the diagnostic-only rule.
- The 9700X placement benchmark ("Compare check-expressions with the pull
  request's base over placements", #1050) uses the same object check.
  Each compiler is linked at four within-page placements of
  `main_unit_checker.c` (`./build.sh shifts --checker-placements`).
  For an older base, both sides use the legacy ordinary `.text` sweep.
  The step then runs:
  - `time-runs` over the placements, with the base's executables again as the
    floor;
  - each placement's `measure-compile` stages;
  - `perf stat`'s counters, with failed store-to-load forwards;
  - the checker's functions' samples;
  - the forwarding failures by function.

  The placement benchmark takes about 90 s
  (`docs/c-checker.md`, "The per-node machinery").
- The `changes` job's selector is `tools/ci/changes.c`, with those tables:
  the job builds it with the hosted runner's `cc`, then `--self-test` checks it
  before it decides, and fails the job (so that `test` runs everything) when
  its tables and the workflow disagree: an output a step reads that it doesn't
  write, a `MEASURE` name that isn't a benchmark or a benchmark no step runs, a
  step that doesn't start its `MEASURE` name's `./build/compiler
  benchmark-NAME` (or `measure-NAME`) on a line of its `run:` script, after
  only the line's indentation, a `run:` and a `taskset -c CPUS` (the selector
  finds a step's benchmarks by those lines alone, not in other keys' values,
  folded blocks, quotes, comments, joined lines, here-documents' bodies or
  parentheses earlier lines left open (an array's elements, and a subshell's
  too), or after a `case` pattern's unmatched `)`, though it doesn't read the shell's control flow; mutants of `benchmark-types`'
  step that hide its command in each must fail), a gated step that doesn't run when changed alone, a pattern alternative or a
  unit that names no source; or when a fixture's decision changes (docs alone,
  `docs/performance`, `web/perf`, tests alone, the binding events' producers,
  `zen5`'s digit, closures through includes, the build's description, pushes).
  It also fails when the hosted rows' shards disagree
  (`changes_shard_policy`, on `hosted-correctness.yml` and its caller): the
  row workflow's required number input `shards` must be N throughout, its
  matrix's lookup `fromJSON('[[], [1], [1, 2], ...]')[inputs.shards]` must give
  1 to N for every N it has, the job's name and the run step's
  `--shard "${{ matrix.shard }}/${{ inputs.shards }}"` must take the same
  input, and every number the test job's `shards:` passes must be one the
  lookup has, since a list and an N that disagree would leave a shard's
  commands unrun with every job green; and when the row workflow weakens its shared products
  (`changes_row_policy`: the portable rows alone, the triggering revision, the
  ownership check on the build's tree, the shards' wait for the build, its
  SHA-256 and their verified install, nothing from a cache or another run); and
  when the vector row's probe, `host_isa.h`'s predicate and the build's vector
  flags fall out of step, or its records and products stop being per attempt
  and non-overwriting, or its candidates take items without their collector's
  assignment, or a draw lacks its collector (`changes_vector_policy`); and
  when the vector row's items aren't each configuration's shards 1 to N, or its
  first draw's candidates and its collector's count aren't 3 per item, on a
  pull request and for the pool alike (`changes_shard_policy`), or its items
  stop installing their configuration's one product (`changes_row_policy`). The
  selector doesn't read the row workflow's steps: a change to that file runs
  the steps it gates on `performance`. Run it
  locally with `cc -std=c17 -O2 -Wall -Wextra -Werror -o /tmp/changes
  tools/ci/changes.c && /tmp/changes --self-test` after changing a gate, a
  benchmark's step, the tables, the rows or the shards. Its oracle policy pins the 9700X
  job's `needs` (`[changes, evidence, test, fuzz]`), its `if:` (the `evidence`
  job's success and admission, hosted rows skipped only by evidenced reuse on a
  dispatch, fuzzing only in the plain scope), the native correctness step's
  skip on pull requests alone and the oracle cache's modes, with
  counterexamples for each.
- `~/buster-fast-bench/README-9700x.md` on the host describes the setup and how
  to undo it.

## Hosted inputs

Each run's `prepare-hosted-tools` job acquires every external input its hosted
jobs read, once, and hands it to them. The jobs set up from that handoff alone.
Their setup reaches only GitHub's checkout, cache and artifact services, so an
Ubuntu mirror, DNS or release-host outage can't fail a shard (#2275).

- **Release inputs:** LLVM, CMake, Ninja, mold and wild, pinned by
  `tools/ci/hosted-tools.lock` (`tools/ci/hosted-release.sh`). They come from
  the `hosted-inputs-v1-…` cache, else the run's artifact `ARTIFACT-NAME`,
  which preparation publishes only when that cache didn't verify for it
  (#2372). It and the offline bundle below are kept 1 day.
- **Offline inputs:** `tools/ci/hosted-offline.sh`'s bundle, the run's
  companion artifact `ARTIFACT-NAME-offline`. It holds:
  - the apt closure of `setup-hosted.sh`'s packages, resolved on the
    preparation's runner image, with a manifest of every package and version;
    it carries the image's packages that it pins exactly (#2974);
  - the corpus and Lua's archive (`downloads/DIGEST`);
  - bare mirrors of c-testsuite and SQLite at `refs/pinned/COMMIT`.

  The preparation keeps them in two caches. `hosted-apt-v2-…` is keyed by the
  package list and the image (`ImageOS`, `ImageVersion`). `hosted-ci-v1-…` is
  keyed by the scripts that pin the rest. On a hit it contacts no external
  host. On a miss it fetches each input once, with retries, and checks it as
  the jobs read it.
- **Consumers:** the `.github/actions/hosted-tools` action downloads the
  companion artifact and checks its manifest. It then sets `BUSTER_CI_CACHE`
  and `BUSTER_CI_OFFLINE=1`, so `setup-hosted.sh` installs with
  `apt-get --no-download` and no package lists, and the fetch scripts read the
  bundle alone. A missing file or a bad hash fails the step; nothing is
  fetched again.
- **Summaries:** each job's step summary lists the installed package versions,
  and the preparation's lists every input's source.
- **Image rollouts:** a shard on another image installs the same `.deb`s and
  warns where the image's own packages differ. A carried package moves to the
  bundle's version, up or down. Before this, an exactly pinned image package
  that had moved failed the job. In the merge queue, that dropped the
  candidate (#2974).

Run `bash tests/ci/hosted-offline.sh` after changing any of these scripts. It
is network-free, and the preparation job runs it. `hosted-inputs-drill.yml`
runs a shard's setup, and a warm preparation, with those hosts down. Details,
failure handling and recovery: [Offline inputs](../hosted-toolchain.md#offline-inputs-2275).

## Deterministic work and growth contracts

The correctness inventory's `Test deterministic work and growth contracts`
heading (#2041) runs `bash tests/work-contracts/run.sh` on one CPU. Its small
declared set runs in every applicable PR row and every merge candidate's full
hosted coverage, with the row's host and sanitizer flags. Native correctness
retains the same inventory.

`work_contract.h` uses the existing tagged key/value report style:

```text
work-contract fixture=NAME size=N metric=NAME actual=COUNT bound=LIMIT semantic=pass|fail result=pass|fail
```

A record passes only when its semantic check passes and `actual <= bound`.
Report write/flush failures fail the command too. The runner requires the
complete declared record inventory and identical records on a second run;
missing sizes, duplicate records or a crashed negative control cannot pass.
Inputs are 256, 512 and 1024 (N, 2N and 4N). No elapsed-time or RSS value
enters a verdict.

| Fixture and counted operation | Bound and reason | Required useful result |
| --- | --- | --- |
| Dependency admission: actual filesystem probes (#1314) | At most 9N: up to three probes for each source, object and destination. Doubling N permits at most twice the probes. | Distinct destinations admitted; final source/object hard-link aliases, absent parent-directory aliases and dangling links refused with diagnostics; protected bytes unchanged; stdout requires no probes or storage. |
| Dependency admission: identity comparisons | N × (32 + 20 × ceil(log2(2N))), including index construction; doubling N permits at most three times the work. This retains the existing driver's bounded sorting/search allowance. | The same admission controls, including conflicts at the end of the protected set. |
| Dependency admission: retained arena bytes | N × (80 + 2 × sizeof(DependencyIdentity) + 6 × sizeof(identity pointer)) + three alignment boundaries: bounded names, two protected identities and their three index columns. Doubling permits twice the storage plus alignment. | The same admission controls; this metric describes retained arena demand, not RSS. |
| SSA scoped loops: total requested construction bytes (#1353) | 4096N + 65536: 4 KiB per loop and 64 KiB fixed slack for topology, accesses, reusable local workspace and actual phis. The fixture has 3N+2 blocks, 8N instructions and 4N+1 edges; no blocks-times-locals table is needed. | Every local promoted with one two-input phi and independently known reaching values; all blocks reachable, input unchanged and scratch restored. Phi numbering may differ. |
| SSA scoped loops: total requested verification bytes | The same linear allowance, charged separately from construction. | The independent SSA verifier accepts the complete result and restores scratch. |

The dependency fixture reuses the driver's existing comparison API and
independently counts actual `stat`/`lstat` calls. SSA wraps the real arena
request functions only in its standalone translation unit: failed requests
and requests later released by restoring scratch are still charged. Fixture
generation and the fixture's own oracle buffers are outside those counters.

The runner deliberately restores excessive work in temporary copies of the
real implementations: linear dependency-index searches and dense SSA
selection must fail the work bounds while every semantic check still passes.
A third mutation skips overlap checks and must fail semantic verification
despite doing less work. A source fragment that no longer matches fails the
mutation setup rather than silently testing an unmodified implementation.

The new instrumentation belongs only to standalone test builds, with no
production-source edits. The runner checks the actual znver5 Release flags
and production source inventory, then requires every test wrapper to refuse
the production-unit flags. Existing optional dependency counters are unchanged;
this guarantees no new counter code in benchmark builds. These contracts do not replace
native performance measurements, existing timing guardrails or the focused
SQLite object-change policy. Their counts constrain the stated operations,
not CPU, cache or layout performance.

## Shard costs

Each hosted row deals its inventory to its shards by a table of its own,
`tools/ci/costs/ARCH-SANITIZER-O3.costs` (#2031): the `native` and `vector`
rows (#2033), each sanitizer (the `x86-64` rows' tables went with them, #2924). Each table is
`tools/ci/costs.c`'s output alone, never edited by hand. Its first line says
so, and `costs --self-test --root .`, which the selector's job runs on every
pull request, fails a table that differs in any byte from what `costs refresh`
would write. In particular it fails a table that lacks an inventory heading or
names one the inventory doesn't have:

```sh
cc -std=c17 -O2 -Wall -Wextra -Werror -fno-strict-aliasing tools/ci/costs.c -o build/costs
build/costs --self-test --root .
```

- **What a cost is.** A command's time times the CPUs it held (its heading's
  `[N CPUs]`, at most the runner's 4), in seconds: `parallel`'s unit. A
  measured cost is the 90th percentile (nearest rank) of the command's samples
  in that row. Each sample is first scaled to the slowest CPU's time.
- **CPU speeds.** Hosted runners draw EPYC 7763, 9V74 and 9V45 and Xeon 8370C,
  8573C and 6973P-C, and a deal can't choose one. The scale is each CPU's
  speed against the reference CPU's (the one most jobs drew): the median, over
  the commands both ran in one row, of the ratio of their median times. On
  11 November the 9V45 and the 6973P-C took 0.64 of the 7763's time, the 9V74
  0.79, the 8573C 0.80 and the 8370C 0.89. A CPU that shares fewer than five
  commands with the reference keeps its samples as they are (`-`).
- **Commands without a good sample.** A command whose samples all failed costs
  its longest failure, a lower bound (`#: lower-bound`). One without any sample
  costs the row's median per CPU times its CPUs (`#: unmeasured`).
- **Shard 1's once-only steps.** `#: first-shard SECONDS` is how much longer a
  row's shard 1 runs than its other shards besides their commands: the median
  of shard 1's jobs' time outside the test step, less the others' median, each
  scaled to the slowest CPU as samples are. Only jobs whose commands all passed
  count (a failure skips the later steps), and not the vector row's draws, which
  also wait for their collector; without both kinds of job the line is left out.
- **Peak memory (#2031).** `#: peak MIB TITLE` is a command's largest peak
  memory over the row's samples, failed ones included (a command that ran out of
  memory peaked where it failed), from the runner's `, N MiB peak`. `#:
  runner-memory MIB` is the smallest MemTotal any log's runner reported (the
  sanitizer rows' host report, `memory: N kB`); every hosted row draws the same
  runners, so each table takes it. `parallel` holds the commands running at once
  to 90% of the runner's memory by their peaks, and the deal simulates the same
  ([parallel](parallel.md#the-parallel-runner)). The first peaks came from three
  queue candidates after #2651 (43481775079, 43486864508, 43487074169), 159 logs
  over every row. The largest were 7,813 MiB (Tier 0's inlining test under TSan
  and in the vector draws) and 4.5–5.1 GiB (`main.c`'s comparison with clang, the
  parser and the per-file jobs on the repository's units). The runners had
  15,982 MiB. Without the bound, one vector draw's four largest commands would
  have needed 15,922 MiB at once.
- **Provenance.** The `#:` lines record the row, the runner's CPUs, the
  revisions measured and the CPUs drawn, each with its jobs.
- **Collect.** After a full run (the nightly snapshot's, or a dispatched
  `full` run), `bash tools/ci/costs.sh LOGS_DIRECTORY RUN...` fetches the given
  runs' shard logs (`gh api repos/buster14a/buster/actions/jobs/ID/logs`, each
  shard whose test step ran) and runs `costs collect --tests
  tools/ci/correctness.tests --output tools/ci/costs LOG...`, then `costs
  check`. Give it full runs together with recent main pushes, for more plain
  samples. `collect` writes each row the logs have. A log is data. One that
  lacks the job's name, its CPU, its checkout, or the runner's shard line and
  summary is rejected, and so is the same job twice. A vector row's draw
  (`Vector draw L, candidate C`) takes its row from its take's line, `Vector
  item ITEM: SANITIZER, shard K of N`, one of its caller's configurations (or,
  without the line, from its caller's one configuration), and its shard from its
  report, which must be the item's; a candidate that took no item has no
  report, and `costs.sh` skips it.
- **Peaks.** `bash tools/ci/costs.sh --peaks LOGS_DIRECTORY RUN...` fetches the
  runs' logs as a collect does and runs `costs peaks --tests
  tools/ci/correctness.tests --costs tools/ci/costs LOG...`. It writes each row's
  peaks and the runners' memory into the existing tables and keeps their costs,
  for logs from runs since #2651, whose headings carry `MiB peak`. A command the
  logs don't sample keeps its peak. A later collect over such logs writes the
  peaks itself.
- **Seed.** A row without logs yet takes another row's measurements: `build/costs
  seed --tests tools/ci/correctness.tests --costs tools/ci/costs --row
  vector-address-O3 --from native-address-O3`. Its `#: seeded ROW` line, first
  among the provenance lines, says whose they are; a collect over the row's own
  logs replaces the table, and a seeded table seeds no other. The vector
  sanitizer rows (#2033) ran their first full run (43027989712) on the native
  rows' seeded tables, and their tables are that run's draws' logs since.
- **Refresh.** A pull request that adds, renames or removes a heading runs
  `build/costs refresh --tests tools/ci/correctness.tests --costs
  tools/ci/costs`. It keeps every measurement, estimates the new commands and
  drops the removed ones; no logs are needed.
- **Split.** A pull request that splits a heading into several, finer parts
  for the deal (#2658), runs `build/costs split --tests
  tools/ci/correctness.tests --costs tools/ci/costs --map FILE` instead. FILE's
  lines are `HEADING<TAB>NEW<TAB>WEIGHT`, one per new heading, and a heading
  may keep its title for one of them. In every row's table, each new heading
  takes its weight's share of its heading's cost, and its heading's peak,
  marked `#: derived`. Refresh keeps a derived cost as it is, and the row's
  median leaves it out. The next collect over logs that have the new heading
  measures it. Without the split, refresh would give a new part the row's median
  per CPU, a few seconds, and the deal would put a heading's parts on one shard.
  An unmeasured heading's parts stay estimates.
- **Plan.** `build/costs plan --tests tools/ci/correctness.tests --costs
  tools/ci/costs/ROW.costs --shards 2-8 [--setup S] [--first S] [--deal
  FILE]` predicts the runner's deal and schedule for each shard count, adding
  the table's `#: first-shard` to shard 1 unless `--first` gives another. For
  each N it prints the longest shard, the mean, the imbalance, the floor (the
  longest command alone) and the runner-minutes. A single N lists each
  command's start and end. `--deal` deals by another file, such as an older
  table, and times the deal by `--costs`.
- **Report.** `build/costs report LOG...` gives a run's rows as they ran: each
  row's longest shard, mean, imbalance, span, runner-minutes and the CPUs drawn.

The tables name their runner's CPUs (`#: runner-cpus 4`). With that line,
`parallel` deals as `test_deal_scheduled` (`test_deal.h`) does: the costliest
command first, each to the shard that, run on 4 CPUs in the list's order as
the runner runs it, would end the earliest with it. A deal by costs alone
couldn't see that the shard holding a row's longest command also started its
8-CPU commands first, which hold every CPU. With the 11 November tables, that
deal predicted 389 s for the plain `x86-64` row's longest shard against 321 s
by schedule, and 527 s against 454 s for the plain `native` row. `plan` shares
the function, so its deal is the runner's.

The test job in `9700x.yml` gives each row its count (`shards`):

| Row | Shards | Why |
| --- | ---: | --- |
| `native` plain | 4 | its items, drawn as the vector row's (#2924); more items each rebuild the compiler for under a minute less |
| `vector`, each configuration | 4 | its items, `BUSTER_VECTOR_ITEMS`, which its draws are sized for; the take gives the run step its configuration's count |
| others | 4 | already shorter than the run's longest row |

No deal beats a row's longest command. In the MSan rows that is a part of the
preprocessor's cases against clang (about 20 minutes on an EPYC 7763), and in
the plain rows the semantic driver's and the parser's clang checks; finer parts
(#2030) lower it. A row's once-only steps run on its shard 1 besides its part of
the deal, and the deal sees them: shard 1's simulated schedule ends its table's
`#: first-shard` later, so the commands go to the other shards until they end as
late.

## Setup failures re-run once

A run of `9700x.yml` ("Tests and Zen 5 benchmarks", the only workflow that
calls `hosted-correctness.yml`) whose first attempt failed only because jobs
stopped in setup, before any test ran, has its failed jobs re-run once,
automatically (#2276). `.github/workflows/rerun.yml` runs when the run
completes (`workflow_run`). `tools/ci/rerun.sh` fetches the attempt's jobs and
steps and its cancelled jobs' annotations, `tools/ci/rerun.c` decides, and the
script asks for `rerun-failed-jobs`. The re-run runs tests that never ran,
never ones that failed, so green keeps meaning the tests passed.

- **Which runs.** A failed first attempt (`run_attempt == 1`) of a push or a
  pull request from this repository, checked again just before the request.
  A second attempt is never re-run automatically, whatever stopped it. Forks'
  pull requests and the nightly dispatches are left alone: the coordinator
  plans the dispatches' 9700X work.
- **Where a job stopped.** At its first step that didn't pass: one that failed,
  or one that was cancelled or left running (a lost runner leaves its step
  running). A job that passed or was skipped didn't stop.
- **Re-run** when at least one job stopped in setup and every stopped job did
  one of these:
  - stopped in a setup step of the allowlist below, whether the step failed or
    was interrupted (fail-fast, its timeout, a lost runner), or failed before
    any step ran (its provisioning);
  - stopped in a step that fails because a setup failure stopped another job.
    "Require this row's compiler product" counts when the row's build job
    ("Build the compiler once for the row's shards") stopped in setup itself.
    The vector row's verdict ("Require one passing qualified execution of each
    vector item") counts when a job of its row did, and the required aggregate
    ("Require hosted and native correctness before successful qualification")
    when any job did;
  - was cancelled by fail-fast after another job failed, wherever it was, by
    its annotation ("The strategy configuration was canceled because ..."), or
    was cancelled before any step ran or after every step it ran passed. The
    other job's failure decides.
- **Never re-run** a run with any of these:
  - a failure in any other step: a test step ("Run correctness tests within the
    hosted CPU budget" and every check), the build ("Build the external Clang
    pragma oracle, the clang server and the compiler"), a probe, a report, an
    artifact's upload or download;
  - a job interrupted outside setup by anything but fail-fast: a lost runner,
    or its `timeout-minutes`. The jobs API reports a timeout exactly as it
    reports a fail-fast cancellation, the job and its step `cancelled`; only
    the annotation "The job has exceeded the maximum execution time" tells them
    apart. A test command's own timeout (`parallel --timeout`) fails its step;
  - a self-hosted job (the 9700X's), a job that didn't complete, or a failed
    job none of whose steps failed.
- **The allowlist** (`rerun_steps`), by step name, for every GitHub-hosted job
  of the run:

  | Steps | What they do |
  | --- | --- |
  | `Set up job` | GitHub's own: the runner, the actions' downloads |
  | `Check out triggering commit`, `Check out the triggering commit and its parents`, `Check out the run's commit and its first parent`, `Check out the exact caller revision`, `Check out the qualification policy`, `Check out reviewed first-party performance fixtures and acceptance harnesses`, `Fetch the vector draw's script from this commit` | the checkouts |
  | `Restore verified hosted release inputs` | `.github/actions/hosted-tools` |
  | `Acquire missing inputs once and verify the complete set`, `Acquire missing offline inputs once and check each as the jobs read it` | `prepare-hosted-tools.yml`'s acquisitions |
  | `Install official Clang 23.1.4 and test tools`, `Install official Clang, sanitizer and libFuzzer runtimes` (the fuzz campaigns' before #2924) | `tools/ci/setup-hosted.sh` |
  | `Fetch generic baseline startup objects and runtime for emulation` (historical: the scalar host's, gone with #2924) | `tools/ci/setup-baseline-runtime.sh`, removed |
  | `Fetch and verify frozen corpus inputs`, `Fetch c-testsuite at its pinned commit`, `Fetch SQLite's sources at their pinned commit` | the fetches |

- **Notes.** The workflow's run summary lists every stopped job by the step
  it stopped at and why, re-run or not. After a re-run, the same list goes in
  a comment on the pull request, or on the commit of a push, so that repeated
  infrastructure failures stay visible.
- **API calls.** Every run's jobs share the Actions token's hourly API
  quota, which the vector draws' calls exhausted on 2026-11-11 (their "Take
  the vector item the draw assigns, or end as a redraw" failed with "API
  rate limit exceeded for installation"). So the glue asks for the jobs'
  pages, then only the annotations that could change the decision
  (`rerun annotations`: a cancelled job interrupted outside setup, in a run
  that a setup failure and such jobs alone keep), and, before a re-run, the
  run's state once. Of the 2026-11-05 to 11-11 failed first attempts, none
  needed an annotation.
- **Checks.** `rerun --self-test --root .` runs in `changes` and in the
  workflow before it decides. It tests the rule on synthetic runs and the
  allowlist against the workflow files: each name it holds is a step of the
  watched workflows or of the reusable workflows they call, the row's build
  job and test step keep their names, and `rerun.yml` watches exactly the
  workflows that call `hosted-correctness.yml` and re-runs only failed first
  attempts. A renamed setup step fails it until the list follows.
  `bash tests/ci/rerun.sh`, in the `CI glue fixtures` job, also runs
  the cases recorded from the API in `tests/ci/rerun/cases.tsv` against their
  reports and Markdown: the 2026-11-11 outage's push and pull request, test,
  build, timeout, fail-fast, lost-runner and self-hosted failures. It checks
  workflow mutants that the policy must refuse, and the glue against a fake
  `gh`. Record a new case with `bash tests/ci/rerun/record.sh RUN ATTEMPT
  NAME`, list it in `cases.tsv`, then run `bash tests/ci/rerun.sh --update`
  and read the difference.

```sh
cc -std=c17 -O2 -Wall -Wextra -Werror -fno-strict-aliasing tools/ci/rerun.c -o build/rerun
build/rerun --self-test --root .
bash tests/ci/rerun.sh
```

## Reuse and the nightly backlog

`tools/ci/nightly.c` makes the decisions, `tools/ci/nightly.sh` is their API and
Git glue, and [the CI guide](../../docs/ci.md#nightly-main-measurements) has
the policy. In short:

- Every `9700x.yml` run has an `evidence` job, which must succeed. A
  merge-queue candidate is never admitted. Main is fast-forwarded to its
  commit, so its plain rows are that state's (#1430). A push to main runs
  nothing; before the queue it was admitted (deferred in the nightly mode)
  and reused nothing from its pull request (#1272).
  A nightly dispatch's `evidence` job checks that the commit is a first-parent state of
  main, may reuse the commit's own earlier plain hosted rows (a push's, a
  dispatch's or a merge-queue candidate's), and enforces
  02:00-08:00 Europe/Madrid. The 9700X job checks the window again after it
  takes the lock, right after the host's OS and CPU-model check. That is
  before the host identity's package queries and hashing, and before any
  setup.
- Every run's `record` job writes the `coverage-record-ATTEMPT` artifact. The
  coordinator, `.github/workflows/nightly-backfill.yml`, harvests those
  records into its ledger. It pins the cycle's snapshot, prepares hosted
  qualifications before the window, and dispatches `9700x.yml` on
  `nightly/SHA` branches with `purpose` `backlog` or `snapshot`. It runs one
  9700X run at a time, and only work that fits before 08:00, unless a manual
  `mode: run` gives an `override` reason. The snapshot's comprehensive run is
  required every cycle. States start at the epoch (the merge that added
  `tools/ci/nightly.c`); earlier ones predate the worker and are reported as
  out of scope. A state whose branch GitHub refuses to create is skipped for
  the rest of the job and reported (docs/ci.md, "Refused branches").
- The coordinator reads each state's immutable `nightly.c` window declarations
  with `nightly worker-window`, cached by source blob and rebuilt for every
  job. Historical 04:00-07:00 workers run only in that interval; later
  02:00-08:00 workers can use the added hours. The planner skips temporarily
  ineligible workers, waits for future openings when needed, and reserves a
  waiting snapshot's own deadline. Unknown declarations are reported and stay
  pending. Every admission must fit both the worker and current windows; the
  worker's own lock-time check still applies.
- The planner's optional `--pending FILE` is the coordinator's ephemeral
  dispatch handoff, not a dispatch history. After validating every input and
  option, `plan` atomically compacts it to requests not yet visible in the run
  facts and still within the 600-second API visibility grace. The 64-request
  limit applies to that active set; expired or observed requests do not end
  a long night's work. Malformed input or too many active requests fails
  without replacing the file. This local housekeeping also occurs in dry-run
  mode; it never dispatches anything.
- `vars.BUSTER_NIGHTLY` set to `on` is the switch. Before it, the coordinator
  only harvests, plans and reports, and pushes work as before. With it, pushes
  run hosted rows alone and keep off the 9700X, and the coordinator measures
  each state (native correctness, then its targeted measurements) in the
  02:00-08:00 window. `9700x.yml` has no daily schedule since 2026-11-05: the
  snapshot's comprehensive run is the daily run.
- Tests: `bash tests/ci/nightly.sh` (the self-test, also under ASan and UBSan,
  and the glue against a fake `gh` and a merge history) and
  `bash tests/ci/caches.sh` (the 9700X's caches). Pull requests and
  merge-queue candidates run both in the `glue` job (`CI glue fixtures`),
  beside the rows, which don't wait for them, and the required aggregate
  requires them (#2658); `changes` runs
  `nightly --self-test`, which also fails if the build or the inventory ever
  calls `git`.

## Queue and execution timing

The hosted-only `CI latency report` workflow runs at 08:37 Europe/Madrid and
on manual dispatch. `tools/ci/timings.sh` collects bounded API snapshots and
`tools/ci/timings.c --accounting` reports all outcomes/collected attempts,
first feedback and completion-proxy p50/p95, runner-minutes, reconciled phases,
CPU classes, queue fate and finite-capacity limits. PR setup/build uses actual
step spans and remains measurable without native tests. `Compare` and `Time`
belong to measurement; missing timestamps remain unknown. Lock hold is an
overlay, not an extra additive phase.

The default sample is 10 runs per workflow/event; a UTC split queries separate
before/after windows. Collection uses bounded retries and records incomplete
reads instead of dropping available evidence. Raw JSON, normalized facts,
request/run receipts and the report are retained as workflow artifacts.
`CI_TIMINGS_REPLAY=INPUT_DIRECTORY` regenerates a report in a different output
directory without network calls. Actual account concurrency defaults to
unknown and needs a dated administrative source; the report changes no
scheduling or coverage policy. Backlog age links and quotes the existing
#1439 nightly report rather than creating another ledger.

Read [the metric definitions, configuration and replay recipe](../ci.md#ci-latency-baseline)
before interpreting results. Run `bash tests/ci/timings.sh` for the network-free
regressions. Store raw live evidence in `buster-performance`, not this
repository's retired `docs/measurements` path.

## Requested and nightly paired checker reports

A trusted author can request a SQLite checker comparison by dispatching
`9700x.yml` on the PR branch with purpose `full` and `paired_base` set to a
full commit SHA from protected main. The dispatch measures its resolved head
SHA. The existing nightly snapshot and checker-selected backlog runs use their
first parent. The build barrier prepares both revisions and their four checker
placements in the shared CPU budget. The existing host lock covers the native
capture. The hosted coverage job evaluates the sealed observations.

The run summary gives the paired verdict and independent-unit count. Dispatched
runs retain `paired-verdict-ATTEMPT`, and a capture also produces
`paired-checker-ATTEMPT` for evidence transfer to buster-performance. A skipped
capture reports unmeasured coverage. A requested comparison that failed during
preparation or capture reports incomplete coverage. Ordinary PRs and the merge
queue use their existing correctness checks. The nightly ledger continues to
record which jobs ran. Baseline promotion uses the explicit two-reference
decision in the [paired reader guide](../performance/readers.md#input-identity-and-baseline-promotion).

