
results/xh4/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f93e40 <node_contexts_window_loop>:
 1f93e40:	push   %rbp
 1f93e41:	mov    %rsp,%rbp
 1f93e44:	push   %r15
 1f93e46:	push   %r14
 1f93e48:	push   %r13
 1f93e4a:	push   %r12
 1f93e4c:	push   %rbx
 1f93e4d:	and    $0xffffffffffffffc0,%rsp
 1f93e51:	sub    $0xa80,%rsp
 1f93e58:	mov    (%rdi),%rax
 1f93e5b:	mov    0xb40(%rdi),%r10
 1f93e62:	add    $0x3f,%edx
 1f93e65:	vpxor  %xmm0,%xmm0,%xmm0
 1f93e69:	mov    0x8(%rax),%rax
 1f93e6d:	movzbl 0x14a(%rax),%eax
 1f93e74:	vmovdqa64 %zmm0,0x980(%rsp)
 1f93e7c:	vmovdqa64 %zmm0,0x940(%rsp)
 1f93e84:	vmovdqa64 %zmm0,0x900(%rsp)
 1f93e8c:	vmovdqa64 %zmm0,0x8c0(%rsp)
 1f93e94:	vmovdqa64 %zmm0,0x880(%rsp)
 1f93e9c:	vmovdqa64 %zmm0,0x840(%rsp)
 1f93ea4:	vmovdqa64 %zmm0,0x800(%rsp)
 1f93eac:	vmovdqa64 %zmm0,0x7c0(%rsp)
 1f93eb4:	mov    %al,0x27(%rsp)
 1f93eb8:	cmp    $0x40,%edx
 1f93ebb:	jae    1f93ed4 <node_contexts_window_loop+0x94>
 1f93ebd:	vpxor  %xmm3,%xmm3,%xmm3
 1f93ec1:	xor    %edx,%edx
 1f93ec3:	xor    %eax,%eax
 1f93ec5:	xor    %r9d,%r9d
 1f93ec8:	xor    %r8d,%r8d
 1f93ecb:	vpxor  %xmm4,%xmm4,%xmm4
 1f93ecf:	jmp    1f95d8d <node_contexts_window_loop+0x1f4d>
 1f93ed4:	vbroadcasti32x4 -0x19cbf7e(%rip),%zmm8        # 5c7f60 <.LCPI44_39>
 1f93ede:	shr    $0x6,%edx
 1f93ee1:	mov    %rcx,0x190(%rsp)
 1f93ee9:	vpxor  %xmm3,%xmm3,%xmm3
 1f93eed:	vpxor  %xmm4,%xmm4,%xmm4
 1f93ef1:	movl   $0xffffffff,0x4c(%rsp)
 1f93ef9:	vpxor  %xmm13,%xmm13,%xmm13
 1f93efe:	xor    %r12d,%r12d
 1f93f01:	xor    %r8d,%r8d
 1f93f04:	mov    %rdi,%rbx
 1f93f07:	xor    %r9d,%r9d
 1f93f0a:	movq   $0x0,0x68(%rsp)
 1f93f13:	xor    %r15d,%r15d
 1f93f16:	vpxor  %xmm12,%xmm12,%xmm12
 1f93f1b:	movq   $0x0,0xe8(%rsp)
 1f93f27:	movq   $0x0,0x118(%rsp)
 1f93f33:	vmovdqa64 %zmm0,0x700(%rsp)
 1f93f3b:	mov    %rdi,0x30(%rsp)
 1f93f40:	mov    %rsi,0x90(%rsp)
 1f93f48:	mov    %r10,0x100(%rsp)
 1f93f50:	jmp    1f9406e <node_contexts_window_loop+0x22e>
 1f93f55:	data16 cs nopw 0x0(%rax,%rax,1)
 1f93f60:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f93f64:	vpunpcklqdq %xmm3,%xmm4,%xmm1
 1f93f68:	vmovdqa64 0xa00(%rsp),%zmm4
 1f93f70:	vmovdqa 0x760(%rsp),%ymm3
 1f93f79:	andn   0xb8(%rsp),%rax,%rax
 1f93f83:	mov    0x1e0(%rsp),%r10
 1f93f8b:	or     0x88(%rsp),%r12
 1f93f93:	mov    %edx,0x4c(%rsp)
 1f93f97:	vmovdqa64 0x780(%rsp),%zmm13
 1f93f9f:	vmovdqa64 0x3c0(%rsp),%zmm12
 1f93fa7:	mov    0x1f0(%rsp),%r8
 1f93faf:	mov    0x1e8(%rsp),%r9
 1f93fb7:	mov    %r13,%rbx
 1f93fba:	mov    0x108(%rsp),%r15
 1f93fc2:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f93fc8:	add    0x28(%rsp),%r8
 1f93fcd:	add    0x40(%rsp),%r9
 1f93fd2:	vpopcntq %ymm0,%ymm0
 1f93fd8:	and    %rcx,%rax
 1f93fdb:	mov    0xbe8(%r13),%rcx
 1f93fe2:	mov    %r10d,%edx
 1f93fe5:	shl    $0x6,%rdx
 1f93fe9:	vpaddq %ymm4,%ymm0,%ymm4
 1f93fed:	vpunpcklqdq %xmm5,%xmm2,%xmm0
 1f93ff1:	vpopcntq %xmm0,%xmm0
 1f93ff7:	mov    %rax,(%rcx,%rdx,1)
 1f93ffb:	vpaddq %xmm3,%xmm0,%xmm3
 1f93fff:	vmovdqa64 0x140(%rsp),%zmm0
 1f94007:	vptestnmb %zmm0,%zmm0,%k1
 1f9400d:	vpxor  %xmm0,%xmm0,%xmm0
 1f94011:	kmovq  %k1,%rdi
 1f94016:	kmovq  0x138(%rsp),%k1
 1f94020:	and    %rax,%rdi
 1f94023:	mov    %rdi,0x8(%rcx,%rdx,1)
 1f94028:	mov    %r12,0x10(%rcx,%rdx,1)
 1f9402d:	mov    0x110(%rsp),%r12
 1f94035:	kandq  %k1,%k0,%k0
 1f9403a:	vpcmpgtb %zmm10,%zmm0,%k1{%k1}
 1f94040:	kmovq  %k0,0x18(%rcx,%rdx,1)
 1f94047:	kmovq  %k1,0x20(%rcx,%rdx,1)
 1f9404e:	mov    0x1f8(%rsp),%rdx
 1f94056:	and    $0x1,%r12d
 1f9405a:	dec    %rdx
 1f9405d:	test   %r10d,%r10d
 1f94060:	mov    0x100(%rsp),%r10
 1f94068:	je     1f95d66 <node_contexts_window_loop+0x1f26>
 1f9406e:	mov    %r9,0x1e8(%rsp)
 1f94076:	lea    -0x1(%rdx),%r9d
 1f9407a:	mov    %r8,0x1f0(%rsp)
 1f94082:	vpbroadcastq -0x19c5b14(%rip),%zmm1        # 5ce578 <.LCPI44_0>
 1f9408c:	mov    0xba8(%rbx),%r14
 1f94093:	vmovdqa %ymm3,0x760(%rsp)
 1f9409c:	vmovdqa64 -0x1add226(%rip),%zmm5        # 4b6e80 <abi_test_hex.digits+0xbb00>
 1f940a6:	vmovdqa64 %zmm4,0xa00(%rsp)
 1f940ae:	vmovdqu64 (%r10),%zmm4
 1f940b4:	vmovdqa64 0x700(%rsp),%zmm0
 1f940bc:	vmovdqa64 -0x1add1c6(%rip),%zmm6        # 4b6f00 <abi_test_hex.digits+0xbb80>
 1f940c6:	mov    %rdx,0x1f8(%rsp)
 1f940ce:	mov    0xb88(%rbx),%rax
 1f940d5:	mov    0xb90(%rbx),%rcx
 1f940dc:	mov    0xb98(%rbx),%rdx
 1f940e3:	mov    %r12,0x110(%rsp)
 1f940eb:	mov    %r9,%r11
 1f940ee:	shl    $0x6,%r11
 1f940f2:	test   %r9d,%r9d
 1f940f5:	mov    %r9,0x1e0(%rsp)
 1f940fd:	lea    -0x40(%r11),%r8d
 1f94101:	vpandq 0x2c(%rsi,%r11,1),%zmm1,%zmm7
 1f9410c:	mov    %r11,0x18(%rsp)
 1f94111:	cmove  %r9d,%r8d
 1f94115:	shl    $0x7,%r9
 1f94119:	vmovdqu64 0x6f654(%rsi,%r9,1),%zmm1
 1f94124:	vmovdqu64 0x6f694(%rsi,%r9,1),%zmm2
 1f9412f:	vmovdqu64 0x6b594(%rsi,%r9,1),%zmm3
 1f9413a:	vmovdqu64 (%r14,%r11,1),%zmm11
 1f94141:	vmovdqu64 (%rdx,%r11,1),%zmm9
 1f94148:	vmovdqu64 (%rcx,%r8,1),%zmm24
 1f9414f:	vmovdqu64 (%rax,%r11,1),%zmm16
 1f94156:	vmovdqu64 (%rcx,%r11,1),%zmm17
 1f9415d:	vmovdqu64 (%r14,%r8,1),%zmm19
 1f94164:	vpermt2b 0x40(%r10),%zmm7,%zmm4
 1f9416b:	vmovdqa64 %zmm7,0x780(%rsp)
 1f94173:	vpmovuswb %zmm1,%ymm1
 1f94179:	vpmovuswb %zmm2,%ymm2
 1f9417f:	vpmovuswb %zmm3,%ymm3
 1f94185:	vmovdqa64 %zmm24,%zmm22
 1f9418b:	vmovdqa64 %zmm9,0x9c0(%rsp)
 1f94193:	vinserti64x4 $0x1,%ymm2,%zmm1,%zmm1
 1f9419a:	vmovdqu64 0x196ac(%rsi,%r11,1),%zmm2
 1f941a5:	vpaddb -0x1add2ef(%rip),%zmm1,%zmm14        # 4b6ec0 <abi_test_hex.digits+0xbb40>
 1f941af:	vmovdqa64 %zmm4,%zmm23
 1f941b5:	vmovdqa64 %zmm4,0x700(%rsp)
 1f941bd:	vptestmb %zmm2,%zmm2,%k0
 1f941c3:	vpandd -0x19c321d(%rip){1to16},%zmm11,%zmm2        # 5d0fb0 <.LCPI44_40>
 1f941cd:	kmovq  %k0,%rdi
 1f941d2:	vptestmb %zmm2,%zmm2,%k4
 1f941d8:	vmovdqu64 0x6b554(%rsi,%r9,1),%zmm2
 1f941e3:	kandq  %k4,%k0,%k2
 1f941e8:	vpcmpleub %zmm5,%zmm1,%k0
 1f941ef:	kmovq  %k4,0x138(%rsp)
 1f941f9:	kmovq  %k0,%r13
 1f941fe:	and    %rdi,%r13
 1f94201:	kmovq  %r13,%k1
 1f94206:	mov    %r13,0x98(%rsp)
 1f9420e:	vpermt2b %zmm0,%zmm14,%zmm23{%k1}{z}
 1f94214:	vmovdqu64 0x6d5d4(%rsi,%r9,1),%zmm0
 1f9421f:	kmovq  %k1,0x120(%rsp)
 1f94229:	vpmovuswb %zmm2,%ymm2
 1f9422f:	vinserti64x4 $0x1,%ymm3,%zmm2,%zmm3
 1f94236:	vmovdqu64 0x6d614(%rsi,%r9,1),%zmm2
 1f94241:	vpmovuswb %zmm0,%ymm0
 1f94247:	kmovq  %k4,%r9
 1f9424c:	vptestmb %zmm3,%zmm3,%k0
 1f94252:	vpsubb %zmm3,%zmm6,%zmm20
 1f94258:	mov    %r9,0xb8(%rsp)
 1f94260:	kandq  %k0,%k4,%k3
 1f94265:	kmovq  %k0,%rdi
 1f9426a:	vpcmpnltub %zmm3,%zmm6,%k0
 1f94271:	vpcmpnleub %zmm5,%zmm1,%k4{%k2}
 1f94278:	vbroadcasti32x4 -0x19cc312(%rip),%zmm5        # 5c7f70 <.LCPI44_41>
 1f94282:	kmovq  %k0,%r10
 1f94287:	vpandq 0x2c(%rsi,%r8,1),%zmm5,%zmm21
 1f94292:	vpcmpltub %zmm3,%zmm6,%k2{%k3}
 1f94299:	kmovq  %k4,%r13
 1f9429e:	kmovq  %k4,0x128(%rsp)
 1f942a8:	and    %rdi,%r10
 1f942ab:	mov    0xba0(%rbx),%rdi
 1f942b2:	kortestq %k4,%k2
 1f942b7:	mov    %r13,0xe0(%rsp)
 1f942bf:	kmovq  %r10,%k3
 1f942c4:	mov    %r10,0x28(%rsp)
 1f942c9:	vpermt2b %zmm17,%zmm20,%zmm22{%k3}{z}
 1f942cf:	vpermt2b %zmm11,%zmm20,%zmm19{%k3}{z}
 1f942d5:	vpmovuswb %zmm2,%ymm2
 1f942db:	vmovdqu64 (%rdi,%r11,1),%zmm10
 1f942e2:	vmovdqu64 (%rdi,%r8,1),%zmm1
 1f942e9:	vpermt2b %zmm7,%zmm20,%zmm21{%k3}{z}
 1f942ef:	vinserti64x4 $0x1,%ymm2,%zmm0,%zmm0
 1f942f6:	vpcmpltub -0x1add3c1(%rip),%zmm0,%k1        # 4b6f40 <abi_test_hex.digits+0xbbc0>
 1f94301:	vmovdqu64 (%rdx,%r8,1),%zmm2
 1f94308:	vpsubb %zmm0,%zmm6,%zmm4
 1f9430e:	vptestmb %zmm0,%zmm0,%k7{%k1}
 1f94314:	vmovdqu64 (%rax,%r8,1),%zmm0
 1f9431b:	vmovdqa64 %zmm2,%zmm3
 1f94321:	vpermt2b %zmm9,%zmm20,%zmm3{%k3}{z}
 1f94327:	vpermt2b %zmm9,%zmm4,%zmm2
 1f9432d:	vpermt2b %zmm17,%zmm4,%zmm24{%k7}{z}
 1f94333:	vmovdqa64 %zmm0,%zmm25
 1f94339:	vpermt2b %zmm16,%zmm20,%zmm25{%k3}{z}
 1f9433f:	vpermi2b %zmm10,%zmm1,%zmm20{%k3}{z}
 1f94345:	vpermt2b %zmm16,%zmm4,%zmm0
 1f9434b:	vpermt2b %zmm10,%zmm4,%zmm1
 1f94351:	jne    1f959ef <node_contexts_window_loop+0x1baf>
 1f94357:	vbroadcasti32x4 -0x19cc3e1(%rip),%zmm5        # 5c7f80 <.LCPI44_42>
 1f94361:	vbroadcasti32x4 -0x19cc3db(%rip),%zmm6        # 5c7f90 <.LCPI44_43>
 1f9436b:	vmovdqu64 0x1a72c(%rsi,%r11,1),%zmm18
 1f94376:	vbroadcasti32x4 -0x19cc3e0(%rip),%zmm28        # 5c7fa0 <.LCPI44_44>
 1f94380:	vpxor  %xmm4,%xmm4,%xmm4
 1f94384:	vbroadcasti32x4 -0x19cc3de(%rip),%zmm7        # 5c7fb0 <.LCPI44_45>
 1f9438e:	vmovdqa64 0x700(%rsp),%zmm26
 1f94396:	mov    %r15,0x108(%rsp)
 1f9439e:	mov    %r11,%r14
 1f943a1:	vmovdqa64 %zmm10,0x680(%rsp)
 1f943a9:	vmovdqa64 %zmm11,0x640(%rsp)
 1f943b1:	vpandq -0x19c5e3b(%rip){1to8},%zmm26,%zmm15        # 5ce580 <.LCPI44_20>
 1f943bb:	vpandq %zmm5,%zmm3,%zmm3
 1f943c1:	vpandq %zmm5,%zmm2,%zmm2
 1f943c7:	vptestnmb %zmm18,%zmm18,%k2
 1f943cd:	vpandq %zmm28,%zmm10,%zmm9
 1f943d3:	vpcmpeqb -0x1add11d(%rip),%zmm9,%k6        # 4b72c0 <abi_test_hex.digits+0xbf40>
 1f943dd:	vpandq %zmm28,%zmm1,%zmm1
 1f943e3:	vpternlogd $0xff,%zmm28,%zmm28,%zmm28
 1f943ea:	vbroadcasti32x4 -0x19cc434(%rip),%zmm5        # 5c7fc0 <.LCPI44_46>
 1f943f4:	vpcmpeqb %zmm6,%zmm3,%k0
 1f943fa:	vpcmpgtb %zmm23,%zmm4,%k3{%k2}
 1f94400:	kmovq  %k2,0xa8(%rsp)
 1f9440a:	vptestmb %zmm6,%zmm22,%k2
 1f94410:	vpaddb %zmm28,%zmm16,%zmm27
 1f94416:	vpaddb %zmm28,%zmm0,%zmm0
 1f9441c:	vmovdqa64 %zmm15,0x600(%rsp)
 1f94424:	kmovq  %k0,%rax
 1f94429:	vpcmpeqb %zmm6,%zmm2,%k0{%k7}
 1f9442f:	vpandd -0x19c3485(%rip){1to16},%zmm10,%zmm2        # 5d0fb4 <.LCPI44_47>
 1f94439:	kmovq  %k2,%r13
 1f9443e:	vptestmb %zmm6,%zmm24,%k2
 1f94444:	and    0x28(%rsp),%rax
 1f94449:	kmovq  %k3,0xf8(%rsp)
 1f94453:	korq   %k0,%k2,%k1
 1f94458:	vptestmb -0x1add262(%rip),%zmm17,%k0        # 4b7200 <abi_test_hex.digits+0xbe80>
 1f94462:	vpcmpeqb -0x1add46c(%rip),%zmm2,%k4        # 4b7000 <abi_test_hex.digits+0xbc80>
 1f9446c:	or     %rax,%r13
 1f9446f:	kmovq  %k3,%rax
 1f94474:	mov    %rax,0x1b8(%rsp)
 1f9447c:	mov    %r13,0x6c0(%rsp)
 1f94484:	vptestnmb %zmm2,%zmm2,%k2
 1f9448a:	vbroadcasti32x4 -0x19cc4c4(%rip),%zmm2        # 5c7fd0 <.LCPI44_48>
 1f94494:	kmovq  %k0,%rcx
 1f94499:	vptestmb %zmm7,%zmm17,%k0
 1f9449f:	kmovq  %k2,%rsi
 1f944a4:	vptestmb %zmm9,%zmm9,%k2
 1f944aa:	kmovq  %k4,0x88(%rsp)
 1f944b4:	korq   %k3,%k0,%k5
 1f944b9:	kmovq  %k2,%rdx
 1f944be:	vpcmpltub %zmm6,%zmm27,%k2
 1f944c5:	andn   %rsi,%rax,%rsi
 1f944ca:	mov    %rcx,0x140(%rsp)
 1f944d2:	kandq  %k6,%k5,%k0
 1f944d7:	kmovq  %k2,0xb0(%rsp)
 1f944e1:	kmovq  %k5,0x70(%rsp)
 1f944e8:	kmovq  %k0,%rdi
 1f944ed:	or     %rdi,%rsi
 1f944f0:	vptestmb %zmm2,%zmm17,%k0{%k4}
 1f944f6:	vptestmb %zmm2,%zmm26,%k2{%k2}
 1f944fc:	vpcmpltub %zmm5,%zmm27,%k4
 1f94503:	vpandq %zmm2,%zmm22,%zmm2
 1f94509:	kmovq  %k0,%r8
 1f9450e:	vpcmpeqb %zmm7,%zmm1,%k0{%k7}
 1f94514:	kmovq  %k2,0x1d0(%rsp)
 1f9451e:	vpcmpltub %zmm5,%zmm0,%k7{%k7}
 1f94525:	vbroadcasti32x4 -0x19cc54f(%rip),%zmm0        # 5c7fe0 <.LCPI44_49>
 1f9452f:	vpandq %zmm8,%zmm11,%zmm5
 1f94535:	kmovq  %k0,0x1d8(%rsp)
 1f9453f:	kandq  %k0,%k2,%k0
 1f94544:	vptestnmb %zmm21,%zmm21,%k2
 1f9454a:	andn   %r8,%rax,%rdi
 1f9454f:	mov    0x30(%rsp),%rax
 1f94554:	or     0x140(%rsp),%rdi
 1f9455c:	kmovq  %k4,%r8
 1f94561:	knotq  %k0,%k0
 1f94566:	kmovq  %k2,0x130(%rsp)
 1f94570:	vpcmpgtb %zmm19,%zmm4,%k2{%k2}
 1f94576:	mov    %r8,0x140(%rsp)
 1f9457e:	kmovq  %k0,%r9
 1f94583:	vpcmpeqb -0x1add34d(%rip),%zmm15,%k0{%k4}        # 4b7240 <abi_test_hex.digits+0xbec0>
 1f9458d:	mov    0xbd0(%rax),%rax
 1f94594:	mov    %rdi,0xd0(%rsp)
 1f9459c:	kmovq  %k0,%r15
 1f945a1:	vptestmb %zmm2,%zmm2,%k0
 1f945a7:	vmovdqu64 %zmm15,(%rax,%r14,1)
 1f945ae:	korq   %k2,%k0,%k0
 1f945b3:	vpcmpeqb %zmm7,%zmm15,%k2
 1f945b9:	and    %r9,%r15
 1f945bc:	knotq  %k0,%k0
 1f945c1:	kmovq  %k2,0x40(%rsp)
 1f945c8:	kmovq  %k0,%r10
 1f945cd:	vptestmb -0x1adcfd7(%rip),%zmm26,%k0        # 4b7600 <abi_test_hex.digits+0xc280>
 1f945d7:	kmovq  %k0,0x60(%rsp)
 1f945de:	korq   %k7,%k0,%k0
 1f945e3:	kmovq  %k0,%rcx
 1f945e8:	vpcmpeqb %zmm0,%zmm15,%k0
 1f945ee:	korq   %k0,%k2,%k0
 1f945f3:	or     %r13,%rcx
 1f945f6:	kmovq  %k0,%r11
 1f945fb:	vpcmpneqb %zmm0,%zmm15,%k0
 1f94602:	and    %r10,%rcx
 1f94605:	vpsllw $0x7,%zmm11,%zmm0
 1f9460c:	kmovq  %k0,%r12
 1f94611:	vptestmb %zmm5,%zmm5,%k0
 1f94617:	mov    %rcx,%r10
 1f9461a:	kmovq  %k5,%rcx
 1f9461f:	korq   %k0,%k1,%k0
 1f94624:	or     %r8,%r12
 1f94627:	mov    %rcx,0xd8(%rsp)
 1f9462f:	knotq  %k0,%k0
 1f94634:	or     %rcx,%r12
 1f94637:	and    0xb8(%rsp),%r12
 1f9463f:	kmovq  %k0,%rbx
 1f94644:	vpmovb2m %zmm0,%k0
 1f9464a:	kmovq  %k0,%rax
 1f9464f:	and    %r11,%rbx
 1f94652:	kmovq  %k0,0xa0(%rsp)
 1f9465c:	mov    %rax,0x1c0(%rsp)
 1f94664:	andn   %rdx,%rax,%rax
 1f94669:	mov    %rdi,%rdx
 1f9466c:	not    %rdx
 1f9466f:	and    %rax,%rsi
 1f94672:	mov    %rax,0x80(%rsp)
 1f9467a:	andn   %rdx,%rsi,%rax
 1f9467f:	mov    %rsi,0xf0(%rsp)
 1f94687:	and    %rax,%r12
 1f9468a:	and    %rax,%r15
 1f9468d:	mov    %rax,0x78(%rsp)
 1f94692:	and    %r15,%r10
 1f94695:	and    %rbx,%r12
 1f94698:	mov    %r15,0x1c8(%rsp)
 1f946a0:	or     %r10,%r12
 1f946a3:	mov    %r10,0x38(%rsp)
 1f946a8:	and    %r13,%r12
 1f946ab:	je     1f948d0 <node_contexts_window_loop+0xa90>
 1f946b1:	mov    0x68(%rsp),%r9
 1f946b6:	mov    0x18(%rsp),%r8
 1f946bb:	mov    0x30(%rsp),%rdi
 1f946c0:	mov    %r12,%rbx
 1f946c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f946d0:	mov    0x2c0(%rdi),%rax
 1f946d7:	xor    %r14d,%r14d
 1f946da:	tzcnt  %rbx,%r14
 1f946df:	mov    0x60(%rdi),%edx
 1f946e2:	lea    (%r14,%r8,1),%r15
 1f946e6:	mov    %r15,%rcx
 1f946e9:	shl    $0x6,%rcx
 1f946ed:	mov    0x20(%rax,%rcx,1),%esi
 1f946f1:	mov    0x20(%rdi),%rcx
 1f946f5:	mov    %esi,%eax
 1f946f7:	shr    $0x3,%eax
 1f946fa:	cmp    %edx,%eax
 1f946fc:	cmovae %edx,%eax
 1f946ff:	shl    $0x6,%rax
 1f94703:	testb  $0x4,0x34(%rcx,%rax,1)
 1f94708:	je     1f9473a <node_contexts_window_loop+0x8fa>
 1f9470a:	mov    0x38(%rcx,%rax,1),%eax
 1f9470e:	mov    0xbe0(%rdi),%rcx
 1f94715:	mov    %rax,(%rcx,%r15,8)
 1f94719:	xor    %ecx,%ecx
 1f9471b:	test   %rax,%rax
 1f9471e:	sete   %cl
 1f94721:	inc    %r9
 1f94724:	shlx   %r14,%rcx,%rax
 1f94729:	andn   %r12,%rax,%r12
 1f9472e:	blsr   %rbx,%rbx
 1f94733:	jne    1f946d0 <node_contexts_window_loop+0x890>
 1f94735:	jmp    1f948e2 <node_contexts_window_loop+0xaa2>
 1f9473a:	mov    %r9,0x68(%rsp)
 1f9473f:	vmovdqa64 %zmm12,0x380(%rsp)
 1f94747:	vmovdqa64 %zmm13,0x200(%rsp)
 1f9474f:	vmovdqa64 %zmm14,0x480(%rsp)
 1f94757:	vmovdqa64 %zmm16,0x440(%rsp)
 1f9475f:	vmovdqa64 %zmm17,0x400(%rsp)
 1f94767:	vmovdqa64 %zmm18,0x340(%rsp)
 1f9476f:	vmovdqa64 %zmm19,0x5c0(%rsp)
 1f94777:	kmovq  %k4,0x58(%rsp)
 1f9477e:	vmovdqa64 %zmm20,0x580(%rsp)
 1f94786:	vmovdqa64 %zmm21,0x300(%rsp)
 1f9478e:	vmovdqa64 %zmm22,0x2c0(%rsp)
 1f94796:	vmovdqa64 %zmm23,0x280(%rsp)
 1f9479e:	vmovdqa64 %zmm24,0x540(%rsp)
 1f947a6:	vmovdqa64 %zmm9,0x240(%rsp)
 1f947ae:	kmovq  %k6,0x50(%rsp)
 1f947b5:	vmovdqa64 %zmm25,0x3c0(%rsp)
 1f947bd:	vmovdqa64 %zmm2,0x500(%rsp)
 1f947c5:	vmovdqa64 %zmm5,0x4c0(%rsp)
 1f947cd:	kmovq  %k1,0xc8(%rsp)
 1f947d7:	kmovq  %k7,0xc0(%rsp)
 1f947e1:	vzeroupper
 1f947e4:	call   1f96540 <node_contexts_stride_asked>
 1f947e9:	vmovdqa64 0x4c0(%rsp),%zmm5
 1f947f1:	vmovdqa64 0x500(%rsp),%zmm2
 1f947f9:	vmovdqa64 0x3c0(%rsp),%zmm25
 1f94801:	vmovdqa64 0x240(%rsp),%zmm9
 1f94809:	vmovdqa64 0x540(%rsp),%zmm24
 1f94811:	vmovdqa64 0x280(%rsp),%zmm23
 1f94819:	vmovdqa64 0x2c0(%rsp),%zmm22
 1f94821:	vmovdqa64 0x300(%rsp),%zmm21
 1f94829:	vmovdqa64 0x580(%rsp),%zmm20
 1f94831:	vmovdqa64 0x5c0(%rsp),%zmm19
 1f94839:	vmovdqa64 0x340(%rsp),%zmm18
 1f94841:	vmovdqa64 0x400(%rsp),%zmm17
 1f94849:	vmovdqa64 0x440(%rsp),%zmm16
 1f94851:	vmovdqa64 0x600(%rsp),%zmm15
 1f94859:	vmovdqa64 0x480(%rsp),%zmm14
 1f94861:	vmovdqa64 0x200(%rsp),%zmm13
 1f94869:	vmovdqa64 0x380(%rsp),%zmm12
 1f94871:	vmovdqa64 0x640(%rsp),%zmm11
 1f94879:	vmovdqa64 0x680(%rsp),%zmm10
 1f94881:	vbroadcasti32x4 -0x19cc92b(%rip),%zmm8        # 5c7f60 <.LCPI44_39>
 1f9488b:	kmovq  0xc0(%rsp),%k7
 1f94895:	kmovq  0xc8(%rsp),%k1
 1f9489f:	kmovq  0x50(%rsp),%k6
 1f948a6:	kmovq  0x58(%rsp),%k4
 1f948ad:	mov    0x38(%rsp),%r10
 1f948b2:	mov    0x30(%rsp),%rdi
 1f948b7:	mov    0x18(%rsp),%r8
 1f948bc:	mov    0x68(%rsp),%r9
 1f948c1:	incq   0x118(%rsp)
 1f948c9:	jmp    1f9470e <node_contexts_window_loop+0x8ce>
 1f948ce:	xchg   %ax,%ax
 1f948d0:	mov    0x68(%rsp),%r9
 1f948d5:	mov    0x18(%rsp),%r8
 1f948da:	mov    0x30(%rsp),%rdi
 1f948df:	xor    %r12d,%r12d
 1f948e2:	vpternlogd $0xff,%zmm0,%zmm0,%zmm0
 1f948e9:	kmovq  %k1,%rax
 1f948ee:	vpaddb -0x1add4f8(%rip),%zmm15,%zmm1        # 4b7400 <abi_test_hex.digits+0xc080>
 1f948f8:	mov    0x78(%rsp),%r11
 1f948fd:	mov    0x140(%rsp),%rbx
 1f94905:	kmovq  0x40(%rsp),%k0
 1f9490c:	or     0x6c0(%rsp),%rax
 1f94914:	mov    %r9,0x68(%rsp)
 1f94919:	vpaddb %zmm0,%zmm25,%zmm0
 1f9491f:	vpcmpltub -0x1add7ea(%rip),%zmm0,%k1{%k7}        # 4b7140 <abi_test_hex.digits+0xbdc0>
 1f9492a:	mov    %r11,%r9
 1f9492d:	and    %rbx,%r9
 1f94930:	kmovq  %k0,%rcx
 1f94935:	andn   %rcx,%rax,%rax
 1f9493a:	mov    %r9,0x40(%rsp)
 1f9493f:	vpcmpltub %zmm8,%zmm1,%k0
 1f94946:	kmovq  %k0,%rdx
 1f9494b:	kmovq  %k1,%rsi
 1f94950:	or     %rdx,%rax
 1f94953:	andn   %rbx,%rsi,%rbx
 1f94958:	and    0xb8(%rsp),%rbx
 1f94960:	and    %rsi,%r9
 1f94963:	and    %rax,%r9
 1f94966:	mov    %r9,0xc0(%rsp)
 1f9496e:	and    %rax,%rbx
 1f94971:	and    %r11,%rbx
 1f94974:	je     1f94b20 <node_contexts_window_loop+0xce0>
 1f9497a:	mov    (%rdi),%rax
 1f9497d:	mov    0x2c0(%rdi),%rcx
 1f94984:	mov    0x108(%rsp),%r13
 1f9498c:	xor    %r14d,%r14d
 1f9498f:	vmovdqa64 %zmm5,0x4c0(%rsp)
 1f94997:	vmovdqa64 %zmm2,0x500(%rsp)
 1f9499f:	kmovq  %k6,0x50(%rsp)
 1f949a6:	vmovdqa64 %zmm9,0x240(%rsp)
 1f949ae:	vmovdqa64 %zmm24,0x540(%rsp)
 1f949b6:	vmovdqa64 %zmm23,0x280(%rsp)
 1f949be:	vmovdqa64 %zmm22,0x2c0(%rsp)
 1f949c6:	vmovdqa64 %zmm21,0x300(%rsp)
 1f949ce:	vmovdqa64 %zmm20,0x580(%rsp)
 1f949d6:	kmovq  %k4,0x58(%rsp)
 1f949dd:	vmovdqa64 %zmm19,0x5c0(%rsp)
 1f949e5:	vmovdqa64 %zmm18,0x340(%rsp)
 1f949ed:	vmovdqa64 %zmm17,0x400(%rsp)
 1f949f5:	vmovdqa64 %zmm16,0x440(%rsp)
 1f949fd:	vmovdqa64 %zmm14,0x480(%rsp)
 1f94a05:	vmovdqa64 %zmm13,0x200(%rsp)
 1f94a0d:	vmovdqa64 %zmm12,0x380(%rsp)
 1f94a15:	mov    %rax,0x140(%rsp)
 1f94a1d:	mov    %rcx,0x3c0(%rsp)
 1f94a25:	mov    0x140(%rsp),%rdi
 1f94a2d:	mov    0x3c0(%rsp),%rsi
 1f94a35:	xor    %r15d,%r15d
 1f94a38:	tzcnt  %rbx,%r15
 1f94a3d:	lea    (%r8,%r15,1),%edx
 1f94a41:	vzeroupper
 1f94a44:	call   1f96477 <node_contexts_converted>
 1f94a49:	mov    0x18(%rsp),%r8
 1f94a4e:	movzbl %al,%eax
 1f94a51:	inc    %r13
 1f94a54:	shlx   %r15,%rax,%rax
 1f94a59:	or     %rax,%r14
 1f94a5c:	blsr   %rbx,%rbx
 1f94a61:	jne    1f94a25 <node_contexts_window_loop+0xbe5>
 1f94a63:	vbroadcasti32x4 -0x19ccb0d(%rip),%zmm8        # 5c7f60 <.LCPI44_39>
 1f94a6d:	vmovdqa64 0x680(%rsp),%zmm10
 1f94a75:	vmovdqa64 0x640(%rsp),%zmm11
 1f94a7d:	vmovdqa64 0x380(%rsp),%zmm12
 1f94a85:	vmovdqa64 0x200(%rsp),%zmm13
 1f94a8d:	vmovdqa64 0x480(%rsp),%zmm14
 1f94a95:	vmovdqa64 0x600(%rsp),%zmm15
 1f94a9d:	vmovdqa64 0x440(%rsp),%zmm16
 1f94aa5:	vmovdqa64 0x400(%rsp),%zmm17
 1f94aad:	vmovdqa64 0x340(%rsp),%zmm18
 1f94ab5:	vmovdqa64 0x5c0(%rsp),%zmm19
 1f94abd:	vmovdqa64 0x580(%rsp),%zmm20
 1f94ac5:	vmovdqa64 0x300(%rsp),%zmm21
 1f94acd:	vmovdqa64 0x2c0(%rsp),%zmm22
 1f94ad5:	vmovdqa64 0x280(%rsp),%zmm23
 1f94add:	vmovdqa64 0x540(%rsp),%zmm24
 1f94ae5:	vmovdqa64 0x240(%rsp),%zmm9
 1f94aed:	vmovdqa64 0x500(%rsp),%zmm2
 1f94af5:	vmovdqa64 0x4c0(%rsp),%zmm5
 1f94afd:	or     %r14,0xc0(%rsp)
 1f94b05:	mov    0x38(%rsp),%r10
 1f94b0a:	kmovq  0x58(%rsp),%k4
 1f94b11:	kmovq  0x50(%rsp),%k6
 1f94b18:	mov    %r13,0x108(%rsp)
 1f94b20:	cmpb   $0x0,0x27(%rsp)
 1f94b25:	mov    %r12,0xc8(%rsp)
 1f94b2d:	jne    1f95b51 <node_contexts_window_loop+0x1d11>
 1f94b33:	vbroadcasti32x4 -0x19ccb4d(%rip),%zmm3        # 5c7ff0 <.LCPI44_50>
 1f94b3d:	vbroadcasti32x4 -0x19ccb97(%rip),%zmm0        # 5c7fb0 <.LCPI44_45>
 1f94b47:	kmovq  0x130(%rsp),%k2
 1f94b51:	vbroadcasti32x4 -0x19ccb5b(%rip),%zmm4        # 5c8000 <.LCPI44_51>
 1f94b5b:	vbroadcasti32x4 -0x19ccb55(%rip),%zmm6        # 5c8010 <.LCPI44_52>
 1f94b65:	vbroadcasti32x4 -0x19ccbdf(%rip),%zmm7        # 5c7f90 <.LCPI44_43>
 1f94b6f:	kmovq  0x138(%rsp),%k3
 1f94b79:	vptestnmb %zmm16,%zmm16,%k3{%k3}
 1f94b7f:	vpandq %zmm3,%zmm24,%zmm1
 1f94b85:	vptestmb %zmm0,%zmm19,%k1
 1f94b8b:	vbroadcasti32x4 -0x19ccb75(%rip),%zmm24        # 5c8020 <.LCPI44_53>
 1f94b95:	vptestnmb %zmm1,%zmm1,%k0
 1f94b9b:	kmovq  %k0,%rax
 1f94ba0:	kandq  %k2,%k1,%k0
 1f94ba5:	kmovq  0xb0(%rsp),%k2
 1f94baf:	kmovq  %k0,%r13
 1f94bb4:	vptestmb %zmm0,%zmm11,%k0
 1f94bba:	mov    %rax,0x340(%rsp)
 1f94bc2:	kmovq  %k0,%rax
 1f94bc7:	vpcmpeqb %zmm3,%zmm15,%k0
 1f94bcd:	vpandq %zmm3,%zmm22,%zmm3
 1f94bd3:	mov    %rax,0x3c0(%rsp)
 1f94bdb:	kmovq  %k0,%rax
 1f94be0:	vpcmpeqb %zmm4,%zmm15,%k0
 1f94be6:	vporq  %zmm1,%zmm3,%zmm1
 1f94bec:	mov    %rax,0x480(%rsp)
 1f94bf4:	kmovq  %k0,%rax
 1f94bf9:	vpcmpeqb %zmm6,%zmm15,%k0
 1f94bff:	kmovq  %k0,%r12
 1f94c04:	korq   %k2,%k6,%k0
 1f94c09:	vpcmpeqb %zmm7,%zmm9,%k2{%k4}
 1f94c0f:	mov    %rax,0x300(%rsp)
 1f94c17:	kmovq  %k6,%rax
 1f94c1c:	kmovq  %k4,%k6
 1f94c21:	vbroadcasti32x4 -0x19ccbfb(%rip),%zmm9        # 5c8030 <.LCPI44_54>
 1f94c2b:	korq   %k2,%k0,%k0
 1f94c30:	mov    %rax,0x240(%rsp)
 1f94c38:	vptestnmb %zmm2,%zmm2,%k2
 1f94c3e:	vpandd -0x19c3c90(%rip){1to16},%zmm23,%zmm2        # 5d0fb8 <.LCPI44_55>
 1f94c48:	kmovq  %k0,%rax
 1f94c4d:	vpcmpeqb %zmm7,%zmm15,%k0{%k4}
 1f94c53:	kmovq  %k2,%r14
 1f94c58:	kmovq  0x88(%rsp),%k2
 1f94c62:	vbroadcasti32x4 -0x19ccc2c(%rip),%zmm7        # 5c8040 <.LCPI44_56>
 1f94c6c:	kmovq  %k0,%r8
 1f94c71:	kmovq  0x70(%rsp),%k0
 1f94c78:	mov    %rax,0x2c0(%rsp)
 1f94c80:	and    %r8,%r14
 1f94c83:	mov    0xd8(%rsp),%r8
 1f94c8b:	korq   %k3,%k0,%k0
 1f94c90:	kmovq  %k0,%rax
 1f94c95:	kandq  %k2,%k4,%k0
 1f94c9a:	vpcmpeqb -0x1add724(%rip),%zmm2,%k4        # 4b7580 <abi_test_hex.digits+0xc200>
 1f94ca4:	vpcmpeqb %zmm24,%zmm15,%k2
 1f94caa:	kmovq  %k0,%rcx
 1f94caf:	vptestnmb %zmm5,%zmm5,%k0
 1f94cb5:	vpandq %zmm7,%zmm23,%zmm0
 1f94cbb:	mov    %rax,0xb0(%rsp)
 1f94cc3:	kmovq  %k2,0x1b0(%rsp)
 1f94ccd:	vbroadcasti32x4 -0x19ccc87(%rip),%zmm5        # 5c8050 <.LCPI44_57>
 1f94cd7:	vpandq %zmm7,%zmm20,%zmm2
 1f94cdd:	kmovq  %k0,%rdx
 1f94ce2:	vpcmpeqb %zmm24,%zmm0,%k0
 1f94ce8:	vpcmpeqb %zmm6,%zmm0,%k5
 1f94cee:	and    0x300(%rsp),%rdx
 1f94cf6:	kmovq  %k0,0x5c0(%rsp)
 1f94d00:	kxorq  %k0,%k4,%k0
 1f94d05:	kmovq  %k4,0x58(%rsp)
 1f94d0c:	kmovq  %k0,%rax
 1f94d11:	vpcmpeqb %zmm9,%zmm0,%k0
 1f94d17:	mov    %rax,0x380(%rsp)
 1f94d1f:	kmovq  %k0,%rax
 1f94d24:	kmovq  0x60(%rsp),%k0
 1f94d2b:	mov    %rax,0x140(%rsp)
 1f94d33:	kandq  %k2,%k0,%k7
 1f94d38:	vpcmpeqb %zmm5,%zmm0,%k0
 1f94d3e:	kxorq  %k2,%k7,%k2
 1f94d43:	kmovq  %k7,0x580(%rsp)
 1f94d4d:	kmovq  %k2,%rax
 1f94d52:	vpcmpeqb %zmm4,%zmm21,%k2
 1f94d58:	vbroadcasti32x4 -0x19ccd02(%rip),%zmm4        # 5c8060 <.LCPI44_58>
 1f94d62:	kmovq  %k2,%rsi
 1f94d67:	vptestnmb -0x1addbb1(%rip),%zmm20,%k2        # 4b71c0 <abi_test_hex.digits+0xbe40>
 1f94d71:	mov    %rsi,0x300(%rsp)
 1f94d79:	vpcmpeqb %zmm4,%zmm2,%k1{%k1}
 1f94d7f:	vpaddb -0x1add749(%rip),%zmm21,%zmm2        # 4b7640 <abi_test_hex.digits+0xc2c0>
 1f94d89:	korq   %k1,%k2,%k1
 1f94d8e:	kmovq  0xa8(%rsp),%k2
 1f94d98:	kmovq  %k1,%r9
 1f94d9d:	mov    %r9,0x1a8(%rsp)
 1f94da5:	kandq  %k5,%k2,%k1
 1f94daa:	kmovq  %k2,%r15
 1f94daf:	kmovq  %k1,%r11
 1f94db4:	kandq  %k0,%k2,%k1
 1f94db9:	kmovq  0x88(%rsp),%k2
 1f94dc3:	mov    %r15,0x4c0(%rsp)
 1f94dcb:	korq   %k4,%k1,%k1
 1f94dd0:	kmovq  %k1,%rdi
 1f94dd5:	vpcmpltub %zmm8,%zmm2,%k1{%k7}
 1f94ddc:	mov    %rdi,0x280(%rsp)
 1f94de4:	kmovq  %k1,%rdi
 1f94de9:	vptestnmb %zmm1,%zmm1,%k1
 1f94def:	mov    %rdi,0x60(%rsp)
 1f94df4:	kmovq  %k1,%rdi
 1f94df9:	vpcmpeqb %zmm5,%zmm15,%k1
 1f94dff:	kmovq  %k1,%r10
 1f94e04:	mov    %rdi,0x400(%rsp)
 1f94e0c:	kmovq  %k3,%rdi
 1f94e11:	korq   %k6,%k3,%k3
 1f94e16:	vptestnmb %zmm3,%zmm3,%k1
 1f94e1c:	kandq  %k1,%k3,%k3
 1f94e21:	mov    %r10,0x440(%rsp)
 1f94e29:	or     %rdi,0x80(%rsp)
 1f94e31:	mov    0x78(%rsp),%rdi
 1f94e36:	kmovq  %k3,%r10
 1f94e3b:	vpcmpeqb %zmm9,%zmm15,%k3
 1f94e41:	mov    %r10,0x200(%rsp)
 1f94e49:	kmovq  %k3,%r10
 1f94e4e:	vpcmpeqb %zmm4,%zmm0,%k3
 1f94e54:	kmovq  %k3,%rbx
 1f94e59:	vptestmb -0x1add863(%rip),%zmm10,%k3        # 4b7600 <abi_test_hex.digits+0xc280>
 1f94e63:	mov    %r10,0xa8(%rsp)
 1f94e6b:	mov    %rbx,0x198(%rsp)
 1f94e73:	mov    0x28(%rsp),%rbx
 1f94e78:	and    %rdi,%rax
 1f94e7b:	and    %rdi,%r14
 1f94e7e:	mov    %r14,0x28(%rsp)
 1f94e83:	and    %r13,%rbx
 1f94e86:	andn   %rcx,%r8,%r13
 1f94e8b:	andn   0x340(%rsp),%rsi,%r8
 1f94e95:	mov    0x110(%rsp),%rsi
 1f94e9d:	and    0x480(%rsp),%r13
 1f94ea5:	mov    %r12,0x340(%rsp)
 1f94ead:	korq   %k2,%k3,%k3
 1f94eb2:	kmovq  0xa0(%rsp),%k2
 1f94ebc:	shl    $0x3f,%rsi
 1f94ec0:	korq   %k2,%k3,%k3
 1f94ec5:	kmovq  0x70(%rsp),%k2
 1f94ecc:	knotq  %k3,%k3
 1f94ed1:	kmovq  %k3,%r10
 1f94ed6:	mov    %r10,0xa0(%rsp)
 1f94ede:	mov    %rdi,%r10
 1f94ee1:	and    %r9,%r10
 1f94ee4:	mov    %r10,%r9
 1f94ee7:	and    %r12,%r9
 1f94eea:	and    0x440(%rsp),%r10
 1f94ef2:	korq   %k6,%k2,%k3
 1f94ef7:	mov    %r9,0x88(%rsp)
 1f94eff:	kmovq  %k3,%rcx
 1f94f04:	and    %rcx,%rdx
 1f94f07:	kmovq  %k1,%rcx
 1f94f0c:	and    %rcx,%r8
 1f94f0f:	mov    0xd0(%rsp),%rcx
 1f94f17:	mov    %rdx,0xd8(%rsp)
 1f94f1f:	kmovq  %k5,%rdx
 1f94f24:	andn   0x2c0(%rsp),%rcx,%rcx
 1f94f2e:	andn   %rdx,%r15,%rdx
 1f94f33:	or     0x380(%rsp),%rdx
 1f94f3b:	and    %r10,0x200(%rsp)
 1f94f43:	mov    %rcx,0x1a0(%rsp)
 1f94f4b:	lea    (%rax,%r9,2),%rcx
 1f94f4f:	andn   %rax,%rcx,%rcx
 1f94f54:	or     %r9,%rax
 1f94f57:	and    %rax,%rdx
 1f94f5a:	and    %rax,%r11
 1f94f5d:	mov    %rax,0x2c0(%rsp)
 1f94f65:	mov    0x3c0(%rsp),%rax
 1f94f6d:	mov    %rcx,0x540(%rsp)
 1f94f75:	or     %r9,%rcx
 1f94f78:	and    0x280(%rsp),%rcx
 1f94f80:	kmovq  %k5,0x280(%rsp)
 1f94f8a:	and    %rdx,%rsi
 1f94f8d:	or     %r11,%rsi
 1f94f90:	and    %rax,%r13
 1f94f93:	and    0x240(%rsp),%rax
 1f94f9b:	or     %rcx,%rsi
 1f94f9e:	mov    %r10,0x240(%rsp)
 1f94fa6:	mov    %rsi,%rcx
 1f94fa9:	shr    $1,%rcx
 1f94fac:	and    %rdi,%r13
 1f94faf:	and    %rdx,%rcx
 1f94fb2:	mov    %r13,0xd0(%rsp)
 1f94fba:	or     %rsi,%rcx
 1f94fbd:	mov    %rdx,%rsi
 1f94fc0:	shr    $1,%rsi
 1f94fc3:	mov    %rcx,%r12
 1f94fc6:	and    %rdx,%rsi
 1f94fc9:	shr    $0x2,%r12
 1f94fcd:	mov    %rax,0x3c0(%rsp)
 1f94fd5:	mov    0x98(%rsp),%rax
 1f94fdd:	and    %rsi,%r12
 1f94fe0:	mov    %rsi,%r11
 1f94fe3:	shr    $0x2,%r11
 1f94fe7:	or     0xe0(%rsp),%rax
 1f94fef:	or     %rcx,%r12
 1f94ff2:	kmovq  %k0,%rcx
 1f94ff7:	vpcmpeqb %zmm8,%zmm0,%k0
 1f94ffd:	and    %rsi,%r11
 1f95000:	andn   %rcx,%r15,%rcx
 1f95005:	kmovq  %k0,%rdx
 1f9500a:	or     %r12,0x60(%rsp)
 1f9500f:	mov    %r12,0x110(%rsp)
 1f95017:	or     %r11,%r12
 1f9501a:	kmovq  %k0,0x500(%rsp)
 1f95024:	mov    %r11,0x50(%rsp)
 1f95029:	or     %rdx,%rcx
 1f9502c:	mov    0x40(%rsp),%rdx
 1f95031:	and    0xa8(%rsp),%rdx
 1f95039:	and    %rax,%rcx
 1f9503c:	andn   %r9,%r12,%rax
 1f95041:	and    %rax,%r8
 1f95044:	mov    %rax,0x70(%rsp)
 1f95049:	mov    %r14,%rax
 1f9504c:	andn   0x140(%rsp),%r15,%r14
 1f95056:	and    %rbx,%rax
 1f95059:	mov    %r8,0x98(%rsp)
 1f95061:	mov    %rbx,%r8
 1f95064:	and    %rdx,%rcx
 1f95067:	mov    %rdx,0x40(%rsp)
 1f9506c:	je     1f950e0 <node_contexts_window_loop+0x12a0>
 1f9506e:	mov    0x30(%rsp),%rdx
 1f95073:	mov    0x90(%rsp),%rbx
 1f9507b:	mov    0x18(%rsp),%r10
 1f95080:	kmovq  0x120(%rsp),%k7
 1f9508a:	mov    0xb88(%rdx),%rsi
 1f95091:	xor    %edx,%edx
 1f95093:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f950a0:	xor    %edi,%edi
 1f950a2:	tzcnt  %rcx,%rdi
 1f950a7:	lea    (%r10,%rdi,1),%r9d
 1f950ab:	movzwl 0x6f654(%rbx,%r9,2),%r11d
 1f950b4:	add    %r9d,%r11d
 1f950b7:	xor    %r9d,%r9d
 1f950ba:	cmpb   $0x0,(%rsi,%r11,1)
 1f950bf:	sete   %r9b
 1f950c3:	shlx   %rdi,%r9,%rdi
 1f950c8:	or     %rdi,%rdx
 1f950cb:	blsr   %rcx,%rcx
 1f950d0:	jne    1f950a0 <node_contexts_window_loop+0x1260>
 1f950d2:	jmp    1f950f1 <node_contexts_window_loop+0x12b1>
 1f950d4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f950e0:	mov    0x18(%rsp),%r10
 1f950e5:	kmovq  0x120(%rsp),%k7
 1f950ef:	xor    %edx,%edx
 1f950f1:	vbroadcasti32x4 -0x19cd16b(%rip),%zmm1        # 5c7f90 <.LCPI44_43>
 1f950fb:	kmovq  0x1b0(%rsp),%k0
 1f95105:	mov    0x198(%rsp),%r9
 1f9510d:	vpsllw $0x7,%zmm17,%zmm0
 1f95114:	mov    0x1a0(%rsp),%r13
 1f9511c:	vpcmpeqb %zmm8,%zmm15,%k5
 1f95122:	andn   0x28(%rsp),%r8,%r12
 1f95129:	mov    0x1a8(%rsp),%rsi
 1f95131:	vpmovb2m %zmm0,%k4
 1f95137:	and    0xf0(%rsp),%r13
 1f9513f:	kmovq  %k5,0xe0(%rsp)
 1f95149:	kandq  %k0,%k1,%k0
 1f9514e:	vpcmpeqb -0x1addd18(%rip),%zmm15,%k1        # 4b7440 <abi_test_hex.digits+0xc0c0>
 1f95158:	and    %r9,0xa0(%rsp)
 1f95160:	or     %rsi,0x80(%rsp)
 1f95168:	vptestmb %zmm1,%zmm19,%k2
 1f9516e:	kmovq  %k2,%rdi
 1f95173:	vpcmpltub -0x1addf3e(%rip),%zmm16,%k2        # 4b7240 <abi_test_hex.digits+0xbec0>
 1f9517e:	andn   %rax,%rdi,%r9
 1f95183:	and    %rdi,%rax
 1f95186:	kmovq  %k0,%rdi
 1f9518b:	vptestmb -0x1ade095(%rip),%zmm11,%k0{%k1}        # 4b7100 <abi_test_hex.digits+0xbd80>
 1f95195:	kmovq  0xf8(%rsp),%k1
 1f9519f:	mov    %r9,0xf0(%rsp)
 1f951a7:	mov    0x1b8(%rsp),%r9
 1f951af:	vmovdqu8 -0x1ade1b9(%rip),%zmm0{%k1}{z}        # 4b7000 <abi_test_hex.digits+0xbc80>
 1f951b9:	or     %r9,%r14
 1f951bc:	korq   %k4,%k2,%k2
 1f951c1:	vptestmb %zmm1,%zmm11,%k4
 1f951c7:	mov    %r14,0x28(%rsp)
 1f951cc:	mov    0x78(%rsp),%r14
 1f951d1:	kmovq  %k4,%r15
 1f951d6:	vpcmpeqb -0x1adde20(%rip),%zmm15,%k4        # 4b73c0 <abi_test_hex.digits+0xc040>
 1f951e0:	kmovq  %k0,%rbx
 1f951e5:	kandq  %k2,%k5,%k2
 1f951ea:	andn   %rbx,%r9,%r8
 1f951ef:	mov    %r15,0x78(%rsp)
 1f951f4:	mov    %r8,0xf8(%rsp)
 1f951fc:	mov    0xc8(%rsp),%r8
 1f95204:	andn   0x6c0(%rsp),%r8,%rbx
 1f9520e:	mov    0x60(%rsp),%r8
 1f95213:	andn   0x38(%rsp),%rbx,%r9
 1f9521a:	mov    0x4c0(%rsp),%rbx
 1f95222:	and    %r14,0xb0(%rsp)
 1f9522a:	and    %r14,0xd8(%rsp)
 1f95232:	and    %r14,%rdi
 1f95235:	korq   %k2,%k4,%k2
 1f9523a:	and    %r8,0x400(%rsp)
 1f95242:	mov    0x140(%rsp),%r8
 1f9524a:	kmovq  %k2,%rcx
 1f9524f:	vpcmpeqb -0x1ade119(%rip),%zmm15,%k2{%k3}        # 4b7140 <abi_test_hex.digits+0xbdc0>
 1f95259:	and    0xa8(%rsp),%r8
 1f95261:	and    %rbx,0x3c0(%rsp)
 1f95269:	mov    %r9,0x38(%rsp)
 1f9526e:	mov    0x30(%rsp),%r9
 1f95273:	and    %r14,%rcx
 1f95276:	and    %rbx,%r8
 1f95279:	mov    0xd0(%rsp),%rbx
 1f95281:	kmovq  %k2,%rsi
 1f95286:	vpcmpeqb -0x1adddd0(%rip),%zmm15,%k2{%k6}        # 4b74c0 <abi_test_hex.digits+0xc140>
 1f95290:	and    %r14,%rsi
 1f95293:	and    %r15,%rbx
 1f95296:	mov    0x98(%rsp),%r15
 1f9529e:	or     0x200(%rsp),%r15
 1f952a6:	kmovq  %k2,%r11
 1f952ab:	mov    %r15,0x98(%rsp)
 1f952b3:	and    %r14,%r11
 1f952b6:	or     %rdx,%r8
 1f952b9:	mov    0xbc0(%r9),%rdx
 1f952c0:	not    %r14
 1f952c3:	mov    %r8,0x140(%rsp)
 1f952cb:	vmovdqu64 %zmm0,(%rdx,%r10,1)
 1f952d2:	je     1f952fb <node_contexts_window_loop+0x14bb>
 1f952d4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f952e0:	xor    %r15d,%r15d
 1f952e3:	tzcnt  %r8,%r15
 1f952e8:	add    0xbc0(%r9),%r15
 1f952ef:	blsr   %r8,%r8
 1f952f4:	movb   $0x4,(%r10,%r15,1)
 1f952f9:	jne    1f952e0 <node_contexts_window_loop+0x14a0>
 1f952fb:	mov    0x1c0(%rsp),%r15
 1f95303:	kmovq  0xe0(%rsp),%k1
 1f9530d:	movabs $0x7fffffffffffffff,%rdx
 1f95317:	or     %rbx,%r13
 1f9531a:	or     %r14,0x28(%rsp)
 1f9531f:	mov    0x40(%rsp),%r14
 1f95324:	mov    0x3c0(%rsp),%r8
 1f9532c:	vmovdqa64 0x780(%rsp),%zmm1
 1f95334:	vbroadcasti32x4 -0x19cd38e(%rip),%zmm2        # 5c7fb0 <.LCPI44_45>
 1f9533e:	kmovq  0x130(%rsp),%k3
 1f95348:	inc    %rdx
 1f9534b:	or     %rsi,%r13
 1f9534e:	and    %rdx,0x380(%rsp)
 1f95356:	or     %r15,0xb0(%rsp)
 1f9535e:	mov    0x80(%rsp),%r15
 1f95366:	kmovq  %k1,%rdx
 1f9536b:	or     %r14,%rcx
 1f9536e:	and    %r8,0xa0(%rsp)
 1f95376:	vptestmb %zmm18,%zmm18,%k1
 1f9537c:	mov    %rcx,%r8
 1f9537f:	or     %rax,%r8
 1f95382:	vmovdqu8 -0x1ade38c(%rip),%zmm0{%k1}{z}        # 4b7000 <abi_test_hex.digits+0xbc80>
 1f9538c:	vpermt2b %zmm13,%zmm14,%zmm1
 1f95392:	andn   %rdx,%r15,%rdx
 1f95397:	mov    %r12,%r15
 1f9539a:	or     %r15,%rsi
 1f9539d:	mov    %rdx,0x80(%rsp)
 1f953a5:	mov    %r12,%rdx
 1f953a8:	mov    0xf0(%rsp),%r12
 1f953b0:	mov    %rsi,%rbx
 1f953b3:	or     0xd0(%rsp),%rsi
 1f953bb:	or     %r11,%rdx
 1f953be:	or     %rdi,%r11
 1f953c1:	or     %rdi,%rbx
 1f953c4:	or     %rax,%r11
 1f953c7:	or     %rbx,%r8
 1f953ca:	vpcmpeqb -0x1ade394(%rip),%zmm1,%k0{%k7}        # 4b7040 <abi_test_hex.digits+0xbcc0>
 1f953d4:	or     %r12,%rcx
 1f953d7:	or     %r12,%rdx
 1f953da:	or     %rsi,%rcx
 1f953dd:	mov    0xd8(%rsp),%rsi
 1f953e5:	or     %r13,%rdx
 1f953e8:	or     %rax,%rcx
 1f953eb:	mov    0xc8(%rsp),%rax
 1f953f3:	or     %r15,%rsi
 1f953f6:	or     %r12,%rsi
 1f953f9:	or     %rax,%rcx
 1f953fc:	or     %rsi,%r11
 1f953ff:	mov    0xc0(%rsp),%rsi
 1f95407:	kmovq  %rcx,%k5
 1f9540c:	mov    0xf8(%rsp),%rcx
 1f95414:	or     %rax,%r11
 1f95417:	kmovq  %k0,%rax
 1f9541c:	or     %rsi,%rdx
 1f9541f:	or     %rsi,%r8
 1f95422:	or     %rsi,%r11
 1f95425:	mov    0x38(%rsp),%rsi
 1f9542a:	kmovq  %rcx,%k1
 1f9542f:	kmovq  %k3,%rcx
 1f95434:	kmovq  %rdx,%k6
 1f95439:	kmovq  %r8,%k2
 1f9543e:	kmovq  %r11,%k4
 1f95443:	mov    0x60(%rsp),%rdx
 1f95448:	mov    %r10,%r11
 1f9544b:	vmovdqu8 -0x1ade455(%rip),%zmm3{%k6}{z}        # 4b7000 <abi_test_hex.digits+0xbc80>
 1f95455:	andn   %rsi,%rcx,%rcx
 1f9545a:	kmovq  %rcx,%k3
 1f9545f:	mov    0x6c0(%rsp),%rcx
 1f95467:	or     %rax,%rdx
 1f9546a:	not    %rdx
 1f9546d:	vporq  %zmm2,%zmm3,%zmm1
 1f95473:	vmovdqu8 %zmm1,%zmm3{%k5}
 1f95479:	vporq  %zmm8,%zmm3,%zmm1
 1f9547f:	and    %rsi,%rcx
 1f95482:	vmovdqu8 %zmm1,%zmm3{%k2}
 1f95488:	vpord  -0x19c44d6(%rip){1to16},%zmm3,%zmm1        # 5d0fbc <.LCPI44_59>
 1f95492:	kmovq  %rcx,%k6
 1f95497:	mov    0x140(%rsp),%rcx
 1f9549f:	kmovq  %rcx,%k5
 1f954a4:	mov    0x200(%rsp),%rcx
 1f954ac:	vmovdqu8 %zmm1,%zmm3{%k4}
 1f954b2:	vmovdqu8 -0x1adde3c(%rip),%zmm3{%k1}        # 4b7680 <abi_test_hex.digits+0xc300>
 1f954bc:	kmovq  %rsi,%k1
 1f954c1:	vbroadcasti32x4 -0x19cd45b(%rip),%zmm1        # 5c8070 <.LCPI44_60>
 1f954cb:	mov    0x98(%rsp),%rsi
 1f954d3:	kmovq  %rcx,%k2
 1f954d8:	or     %r14,%rcx
 1f954db:	kmovq  %rcx,%k4
 1f954e0:	mov    0x400(%rsp),%rcx
 1f954e8:	vmovdqu8 -0x1adde32(%rip),%zmm3{%k1}        # 4b76c0 <abi_test_hex.digits+0xc340>
 1f954f2:	kmovq  %rcx,%k1
 1f954f7:	vpblendmb -0x1ade341(%rip),%zmm1,%zmm1{%k5}        # 4b71c0 <abi_test_hex.digits+0xbe40>
 1f95501:	mov    0x100(%rsp),%rax
 1f95509:	mov    0xbb0(%r9),%rdi
 1f95510:	vmovdqu8 -0x1adde1a(%rip),%zmm3{%k1}        # 4b7700 <abi_test_hex.digits+0xc380>
 1f9551a:	kmovq  %rsi,%k1
 1f9551f:	vmovdqu8 -0x1addda9(%rip),%zmm1{%k2}        # 4b7780 <abi_test_hex.digits+0xc400>
 1f95529:	vmovdqu8 -0x1ade5b3(%rip),%zmm3{%k1}        # 4b6f80 <abi_test_hex.digits+0xbc00>
 1f95533:	kmovq  0x128(%rsp),%k1
 1f9553d:	vmovdqa64 %zmm3,%zmm4
 1f95543:	vpaddb %zmm8,%zmm3,%zmm4{%k3}
 1f95549:	vmovdqa64 %zmm3,0x140(%rsp)
 1f95551:	vpaddb %zmm2,%zmm4,%zmm4{%k6}
 1f95557:	vmovdqu8 %zmm1,%zmm4{%k4}
 1f9555d:	vpermi2b %zmm12,%zmm4,%zmm14{%k7}{z}
 1f95563:	vmovdqa64 %zmm4,0x3c0(%rsp)
 1f9556b:	vmovdqu8 0x800(%rsp),%zmm14{%k1}
 1f95573:	kmovq  %rdx,%k1
 1f95578:	mov    0xb8(%rsp),%rdx
 1f95580:	and    %rdx,%rcx
 1f95583:	and    %rdx,%rsi
 1f95586:	mov    %rcx,0x200(%rsp)
 1f9558e:	mov    %rsi,0x60(%rsp)
 1f95593:	vpaddw %zmm14,%zmm14,%zmm1
 1f95599:	vporq  %zmm0,%zmm1,%zmm0
 1f9559f:	vpermb 0x80(%rax),%zmm0,%zmm0
 1f955a6:	vmovdqu64 %zmm3,(%rdi,%r10,1)
 1f955ad:	mov    0xbb8(%r9),%rax
 1f955b4:	vmovdqu64 %zmm4,(%rax,%r10,1)
 1f955bb:	mov    0xbc8(%r9),%rax
 1f955c2:	vmovdqa64 %zmm0,0x6c0(%rsp)
 1f955ca:	vpandd -0x19c4614(%rip){1to16},%zmm0,%zmm0        # 5d0fc0 <.LCPI44_61>
 1f955d4:	vmovdqu8 %zmm0,%zmm0{%k1}{z}
 1f955da:	vmovdqu64 %zmm0,(%rax,%r10,1)
 1f955e1:	test   %rsi,%rsi
 1f955e4:	je     1f95720 <node_contexts_window_loop+0x18e0>
 1f955ea:	mov    %rsi,%r14
 1f955ed:	mov    0xbc8(%r9),%r13
 1f955f4:	mov    0x2c0(%r9),%r15
 1f955fb:	mov    0x90(%rsp),%rsi
 1f95603:	lea    -0x19b5cfa(%rip),%r8        # 5df910 <switch.table.tier1_burs_check_function.51216+0xda18>
 1f9560a:	xor    %r12d,%r12d
 1f9560d:	jmp    1f95643 <node_contexts_window_loop+0x1803>
 1f9560f:	nop
 1f95610:	mov    $0x50,%ecx
 1f95615:	movzwl 0x6b554(%rsi,%rdx,2),%edi
 1f9561d:	mov    $0x1,%eax
 1f95622:	cmp    0x6d5d4(%rsi,%rdx,2),%di
 1f9562a:	jne    1f956bf <node_contexts_window_loop+0x187f>
 1f95630:	shlx   %rbx,%rax,%rax
 1f95635:	or     %rax,%r12
 1f95638:	blsr   %r14,%r14
 1f9563d:	je     1f9572b <node_contexts_window_loop+0x18eb>
 1f95643:	xor    %ebx,%ebx
 1f95645:	tzcnt  %r14,%rbx
 1f9564a:	mov    %r11d,%edx
 1f9564d:	or     %rbx,%rdx
 1f95650:	cmpb   $0x0,0x196ac(%rsi,%rdx,1)
 1f95658:	mov    %rdx,%rax
 1f9565b:	je     1f95667 <node_contexts_window_loop+0x1827>
 1f9565d:	movzwl 0x6f654(%rsi,%rdx,2),%eax
 1f95665:	add    %edx,%eax
 1f95667:	movzbl 0x0(%r13,%rdx,1),%ecx
 1f9566d:	dec    %ecx
 1f9566f:	cmp    $0x3,%ecx
 1f95672:	ja     1f956b8 <node_contexts_window_loop+0x1878>
 1f95674:	movslq (%r8,%rcx,4),%rcx
 1f95678:	shl    $0x6,%rax
 1f9567c:	add    %r15,%rax
 1f9567f:	add    %r8,%rcx
 1f95682:	jmp    *%rcx
 1f95684:	xor    %ecx,%ecx
 1f95686:	cmpb   $0x0,0x1a72c(%rsi,%rdx,1)
 1f9568e:	setne  %cl
 1f95691:	mov    0x20(%rax,%rcx,4),%ecx
 1f95695:	jmp    1f95615 <node_contexts_window_loop+0x17d5>
 1f9569a:	nopw   0x0(%rax,%rax,1)
 1f956a0:	mov    %rdx,%rax
 1f956a3:	shl    $0x6,%rax
 1f956a7:	mov    0x38(%r15,%rax,1),%ecx
 1f956ac:	jmp    1f95615 <node_contexts_window_loop+0x17d5>
 1f956b1:	mov    (%rax),%ecx
 1f956b3:	jmp    1f95615 <node_contexts_window_loop+0x17d5>
 1f956b8:	xor    %ecx,%ecx
 1f956ba:	jmp    1f95615 <node_contexts_window_loop+0x17d5>
 1f956bf:	mov    0x30(%rsp),%rdi
 1f956c4:	vzeroupper
 1f956c7:	call   1f964c1 <node_contexts_sinks>
 1f956cc:	vmovdqa64 0x600(%rsp),%zmm15
 1f956d4:	vmovdqa64 0x640(%rsp),%zmm11
 1f956dc:	vmovdqa64 0x680(%rsp),%zmm10
 1f956e4:	vbroadcasti32x4 -0x19cd78e(%rip),%zmm8        # 5c7f60 <.LCPI44_39>
 1f956ee:	mov    0x18(%rsp),%r11
 1f956f3:	mov    0x90(%rsp),%rsi
 1f956fb:	lea    -0x19b5df2(%rip),%r8        # 5df910 <switch.table.tier1_burs_check_function.51216+0xda18>
 1f95702:	movzbl %al,%eax
 1f95705:	shlx   %rbx,%rax,%rax
 1f9570a:	or     %rax,%r12
 1f9570d:	blsr   %r14,%r14
 1f95712:	jne    1f95643 <node_contexts_window_loop+0x1803>
 1f95718:	jmp    1f9572b <node_contexts_window_loop+0x18eb>
 1f9571a:	nopw   0x0(%rax,%rax,1)
 1f95720:	mov    0x90(%rsp),%rsi
 1f95728:	xor    %r12d,%r12d
 1f9572b:	kmovq  0x58(%rsp),%k0
 1f95732:	kmovq  0x580(%rsp),%k1
 1f9573c:	mov    0x540(%rsp),%r13
 1f95744:	mov    0x28(%rsp),%rdi
 1f95749:	mov    0x380(%rsp),%rbx
 1f95751:	mov    0x88(%rsp),%r15
 1f95759:	mov    0x200(%rsp),%r8
 1f95761:	mov    0x480(%rsp),%r9
 1f95769:	mov    0xb0(%rsp),%r10
 1f95771:	mov    0x4c(%rsp),%edx
 1f95775:	mov    $0x0,%r14d
 1f9577b:	and    0xa8(%rsp),%rdi
 1f95783:	and    0x2c0(%rsp),%rbx
 1f9578b:	xor    0x340(%rsp),%r15
 1f95793:	kmovq  %k1,%rcx
 1f95798:	kmovq  %k0,%rax
 1f9579d:	kmovq  0x5c0(%rsp),%k0
 1f957a7:	kmovq  0x500(%rsp),%k1
 1f957b1:	and    %r9,%r10
 1f957b4:	and    %rax,%r13
 1f957b7:	mov    0x70(%rsp),%rax
 1f957bc:	mov    %rdi,0x28(%rsp)
 1f957c1:	mov    0xa0(%rsp),%rdi
 1f957c9:	and    %r8,%rcx
 1f957cc:	and    0x300(%rsp),%rax
 1f957d4:	korq   %k1,%k0,%k0
 1f957d9:	kmovq  0x280(%rsp),%k1
 1f957e3:	and    %rdi,0x78(%rsp)
 1f957e8:	mov    %rax,0x70(%rsp)
 1f957ed:	korq   %k1,%k0,%k0
 1f957f2:	kmovq  %k0,%rax
 1f957f7:	and    %rax,0x80(%rsp)
 1f957ff:	mov    $0xffffffffffffffff,%rax
 1f95806:	sub    %r11d,%edx
 1f95809:	jbe    1f95823 <node_contexts_window_loop+0x19e3>
 1f9580b:	lea    0x40(%r11),%eax
 1f9580f:	cmp    %eax,0x4c(%rsp)
 1f95813:	mov    $0xffffffffffffffff,%rax
 1f9581a:	shlx   %rdx,%rax,%rax
 1f9581f:	cmovae %r14,%rax
 1f95823:	vmovdqa64 0x9c0(%rsp),%zmm6
 1f9582b:	vpcmpeqb -0x1ade575(%rip),%zmm15,%k0        # 4b72c0 <abi_test_hex.digits+0xbf40>
 1f95835:	kmovq  0x1d0(%rsp),%k1
 1f9583f:	vpandd -0x19c4885(%rip){1to16},%zmm11,%zmm5        # 5d0fc4 <.LCPI44_62>
 1f95849:	vpcmpeqb -0x1ade413(%rip),%zmm15,%k2        # 4b7440 <abi_test_hex.digits+0xc0c0>
 1f95853:	kmovq  0xe0(%rsp),%k4
 1f9585d:	vmovq  %r8,%xmm0
 1f95862:	mov    0x240(%rsp),%r8
 1f9586a:	or     %r10,%r15
 1f9586d:	vmovq  %rcx,%xmm1
 1f95872:	mov    0x38(%rsp),%rdx
 1f95877:	mov    0x1c8(%rsp),%rcx
 1f9587f:	vpmovb2m %zmm10,%k3
 1f95885:	vmovq  0x40(%rsp),%xmm2
 1f9588b:	mov    0xb8(%rsp),%r10
 1f95893:	xor    0x440(%rsp),%r8
 1f9589b:	vmovq  %rcx,%xmm4
 1f958a0:	vmovq  %rdx,%xmm3
 1f958a5:	andn   %rcx,%rdx,%rcx
 1f958aa:	andn   %rdi,%r9,%rdx
 1f958af:	or     %r8,%r15
 1f958b2:	or     0x28(%rsp),%r15
 1f958b7:	popcnt %r12,%r8
 1f958bc:	mov    %r8,0x40(%rsp)
 1f958c1:	vpcmpeqb -0x1ade94b(%rip),%zmm6,%k4{%k4}        # 4b6f80 <abi_test_hex.digits+0xbc00>
 1f958cb:	korq   %k1,%k0,%k0
 1f958d0:	kmovq  0x1d8(%rsp),%k1
 1f958da:	vptestnmb %zmm5,%zmm5,%k2{%k2}
 1f958e0:	vmovdqa64 0x6c0(%rsp),%zmm6
 1f958e8:	or     %rbx,%r15
 1f958eb:	mov    $0xffffffffffffffff,%rbx
 1f958f2:	or     %r13,%r15
 1f958f5:	or     0x70(%rsp),%r15
 1f958fa:	mov    0x30(%rsp),%r13
 1f958ff:	kandq  %k1,%k0,%k0
 1f95904:	vptestnmb %zmm15,%zmm15,%k1
 1f9590a:	korq   %k4,%k1,%k1
 1f9590f:	korq   %k3,%k1,%k1
 1f95914:	or     %rcx,%r15
 1f95917:	popcnt 0x60(%rsp),%rcx
 1f9591e:	korq   %k0,%k1,%k1
 1f95923:	korq   %k2,%k1,%k1
 1f95928:	kmovq  %k1,%rdi
 1f9592d:	vpmovb2m %zmm6,%k1
 1f95933:	or     %rdx,%rdi
 1f95936:	mov    0x80(%rsp),%rdx
 1f9593e:	mov    %rcx,0x28(%rsp)
 1f95943:	kmovq  %k1,%rcx
 1f95948:	or     %rdx,%r15
 1f9594b:	vmovq  %rdx,%xmm5
 1f95950:	mov    0x78(%rsp),%rdx
 1f95955:	or     0x50(%rsp),%r15
 1f9595a:	andn   %rcx,%rdx,%rcx
 1f9595f:	mov    0x4c(%rsp),%edx
 1f95963:	or     %rdi,%r15
 1f95966:	and    %r10,%r15
 1f95969:	or     %rcx,%r9
 1f9596c:	mov    %r15,0x88(%rsp)
 1f95974:	andn   %r10,%r9,%rdi
 1f95979:	movabs $0x7fffffffffffffff,%r15
 1f95983:	je     1f93f60 <node_contexts_window_loop+0x120>
 1f95989:	nopl   0x0(%rax)
 1f95990:	xor    %r8d,%r8d
 1f95993:	tzcnt  %rdi,%r8
 1f95998:	lea    (%r11,%r8,1),%r9d
 1f9599c:	sub    0x651b8(%rsi,%r9,4),%r9d
 1f959a4:	mov    0x90(%rsp),%rsi
 1f959ac:	lea    0x1(%r9),%r9d
 1f959b0:	cmovb  %r14d,%r9d
 1f959b4:	mov    %r9d,%r10d
 1f959b7:	sub    %r11d,%r10d
 1f959ba:	cmp    %edx,%r9d
 1f959bd:	mov    %edx,%r11d
 1f959c0:	cmovb  %r9d,%r11d
 1f959c4:	cmp    0x18(%rsp),%r9d
 1f959c9:	shlx   %r10,%rbx,%r9
 1f959ce:	cmovb  %r11d,%edx
 1f959d2:	mov    0x18(%rsp),%r11
 1f959d7:	cmovbe %r15,%r9
 1f959db:	bzhi   %r8,%r9,%r8
 1f959e0:	or     %r8,%rax
 1f959e3:	blsr   %rdi,%rdi
 1f959e8:	jne    1f95990 <node_contexts_window_loop+0x1b50>
 1f959ea:	jmp    1f93f60 <node_contexts_window_loop+0x120>
 1f959ef:	test   %r13,%r13
 1f959f2:	je     1f95a61 <node_contexts_window_loop+0x1c21>
 1f959f4:	mov    0x30(%rsp),%r8
 1f959f9:	mov    %r13,%r9
 1f959fc:	mov    0xbb8(%r8),%r8
 1f95a03:	mov    %r8,0x40(%rsp)
 1f95a08:	mov    0x18(%rsp),%r11
 1f95a0d:	xor    %r10d,%r10d
 1f95a10:	tzcnt  %r9,%r10
 1f95a15:	mov    0x100(%rsp),%r8
 1f95a1d:	add    %r10d,%r11d
 1f95a20:	movzwl 0x6f654(%rsi,%r11,2),%ebx
 1f95a29:	add    %r11d,%ebx
 1f95a2c:	movzbl 0x2c(%rsi,%rbx,1),%r11d
 1f95a32:	and    $0x7f,%r11d
 1f95a36:	blsr   %r9,%r9
 1f95a3b:	movzbl (%r8,%r11,1),%r11d
 1f95a40:	mov    0x40(%rsp),%r8
 1f95a45:	mov    %r11b,0x7c0(%rsp,%r10,1)
 1f95a4d:	movzbl (%r8,%rbx,1),%r11d
 1f95a52:	mov    %r11b,0x800(%rsp,%r10,1)
 1f95a5a:	mov    0x18(%rsp),%r11
 1f95a5f:	jne    1f95a08 <node_contexts_window_loop+0x1bc8>
 1f95a61:	kmovq  %k2,%r8
 1f95a66:	mov    %r8,%r9
 1f95a69:	test   %r8,%r8
 1f95a6c:	je     1f95ae8 <node_contexts_window_loop+0x1ca8>
 1f95a6e:	mov    0x18(%rsp),%r11
 1f95a73:	xor    %r10d,%r10d
 1f95a76:	tzcnt  %r9,%r10
 1f95a7b:	add    %r10d,%r11d
 1f95a7e:	movzwl 0x6b554(%rsi,%r11,2),%ebx
 1f95a87:	sub    %ebx,%r11d
 1f95a8a:	movzbl 0x2c(%rsi,%r11,1),%ebx
 1f95a90:	and    $0x7f,%bl
 1f95a93:	blsr   %r9,%r9
 1f95a98:	mov    %bl,0x840(%rsp,%r10,1)
 1f95aa0:	movzbl (%rax,%r11,1),%ebx
 1f95aa5:	mov    %bl,0x880(%rsp,%r10,1)
 1f95aad:	movzbl (%rcx,%r11,1),%ebx
 1f95ab2:	mov    %bl,0x8c0(%rsp,%r10,1)
 1f95aba:	movzbl (%rdx,%r11,1),%ebx
 1f95abf:	mov    %bl,0x900(%rsp,%r10,1)
 1f95ac7:	movzbl (%r14,%r11,1),%ebx
 1f95acc:	mov    %bl,0x940(%rsp,%r10,1)
 1f95ad4:	movzbl (%rdi,%r11,1),%r11d
 1f95ad9:	mov    %r11b,0x980(%rsp,%r10,1)
 1f95ae1:	mov    0x18(%rsp),%r11
 1f95ae6:	jne    1f95a6e <node_contexts_window_loop+0x1c2e>
 1f95ae8:	kmovq  0x128(%rsp),%k3
 1f95af2:	vmovdqu8 0x840(%rsp),%zmm21{%k2}
 1f95afa:	vmovdqu8 0x880(%rsp),%zmm25{%k2}
 1f95b02:	vmovdqu8 0x8c0(%rsp),%zmm22{%k2}
 1f95b0a:	vmovdqu8 0x900(%rsp),%zmm3{%k2}
 1f95b12:	vmovdqu8 0x940(%rsp),%zmm19{%k2}
 1f95b1a:	vmovdqu8 0x980(%rsp),%zmm20{%k2}
 1f95b22:	popcnt %r13,%rax
 1f95b27:	add    0xe8(%rsp),%rax
 1f95b2f:	or     %r8,0x28(%rsp)
 1f95b34:	popcnt %r8,%rcx
 1f95b39:	vmovdqu8 0x7c0(%rsp),%zmm23{%k3}
 1f95b41:	add    %rcx,%rax
 1f95b44:	mov    %rax,0xe8(%rsp)
 1f95b4c:	jmp    1f94357 <node_contexts_window_loop+0x517>
 1f95b51:	test   %r10,%r10
 1f95b54:	je     1f95d58 <node_contexts_window_loop+0x1f18>
 1f95b5a:	mov    0x30(%rsp),%rax
 1f95b5f:	xor    %r14d,%r14d
 1f95b62:	mov    %r10,%r15
 1f95b65:	mov    (%rax),%rax
 1f95b68:	mov    0x8(%rax),%rdi
 1f95b6c:	movzbl 0x14a(%rdi),%ebx
 1f95b73:	xor    %r13d,%r13d
 1f95b76:	tzcnt  %r15,%r13
 1f95b7b:	test   %bl,%bl
 1f95b7d:	jne    1f95b95 <node_contexts_window_loop+0x1d55>
 1f95b7f:	xor    %ecx,%ecx
 1f95b81:	shlx   %r13,%rcx,%rax
 1f95b86:	or     %rax,%r14
 1f95b89:	blsr   %r15,%r15
 1f95b8e:	jne    1f95b73 <node_contexts_window_loop+0x1d33>
 1f95b90:	jmp    1f95d49 <node_contexts_window_loop+0x1f09>
 1f95b95:	mov    0x90(%rsp),%rdx
 1f95b9d:	mov    0x30(%rsp),%rax
 1f95ba2:	lea    (%r8,%r13,1),%ecx
 1f95ba6:	vmovdqa64 %zmm5,0x4c0(%rsp)
 1f95bae:	vmovdqa64 %zmm2,0x500(%rsp)
 1f95bb6:	kmovq  %k6,0x50(%rsp)
 1f95bbd:	vmovdqa64 %zmm9,0x240(%rsp)
 1f95bc5:	vmovdqa64 %zmm24,0x540(%rsp)
 1f95bcd:	vmovdqa64 %zmm23,0x280(%rsp)
 1f95bd5:	vmovdqa64 %zmm22,0x2c0(%rsp)
 1f95bdd:	vmovdqa64 %zmm21,0x300(%rsp)
 1f95be5:	vmovdqa64 %zmm20,0x580(%rsp)
 1f95bed:	kmovq  %k4,0x58(%rsp)
 1f95bf4:	vmovdqa64 %zmm19,0x5c0(%rsp)
 1f95bfc:	vmovdqa64 %zmm18,0x340(%rsp)
 1f95c04:	vmovdqa64 %zmm17,0x400(%rsp)
 1f95c0c:	vmovdqa64 %zmm16,0x440(%rsp)
 1f95c14:	vmovdqa64 %zmm14,0x480(%rsp)
 1f95c1c:	vmovdqa64 %zmm13,0x200(%rsp)
 1f95c24:	vmovdqa64 %zmm12,0x380(%rsp)
 1f95c2c:	mov    %rdi,0x140(%rsp)
 1f95c34:	movzwl 0x6b554(%rdx,%rcx,2),%edx
 1f95c3c:	mov    0x2c0(%rax),%rax
 1f95c43:	sub    %edx,%ecx
 1f95c45:	shl    $0x6,%rcx
 1f95c49:	mov    (%rax,%rcx,1),%esi
 1f95c4c:	vzeroupper
 1f95c4f:	call   1f35e90 <type_object_qualifiers_slow>
 1f95c54:	and    $0xffffff,%eax
 1f95c59:	lea    -0x110(%rax),%ecx
 1f95c5f:	cmp    $0x2,%ecx
 1f95c62:	ja     1f95c7a <node_contexts_window_loop+0x1e3a>
 1f95c64:	lea    -0x1ac5ff6(%rip),%rdx        # 4cfc75 <check_lower_segment_override.segments>
 1f95c6b:	xor    %ecx,%ecx
 1f95c6d:	testb  $0x3,-0x110(%rax,%rdx,1)
 1f95c75:	setne  %cl
 1f95c78:	jmp    1f95c7c <node_contexts_window_loop+0x1e3c>
 1f95c7a:	xor    %ecx,%ecx
 1f95c7c:	vbroadcasti32x4 -0x19cdd26(%rip),%zmm8        # 5c7f60 <.LCPI44_39>
 1f95c86:	vmovdqa64 0x680(%rsp),%zmm10
 1f95c8e:	vmovdqa64 0x640(%rsp),%zmm11
 1f95c96:	vmovdqa64 0x380(%rsp),%zmm12
 1f95c9e:	vmovdqa64 0x200(%rsp),%zmm13
 1f95ca6:	vmovdqa64 0x480(%rsp),%zmm14
 1f95cae:	vmovdqa64 0x600(%rsp),%zmm15
 1f95cb6:	vmovdqa64 0x440(%rsp),%zmm16
 1f95cbe:	vmovdqa64 0x400(%rsp),%zmm17
 1f95cc6:	vmovdqa64 0x340(%rsp),%zmm18
 1f95cce:	vmovdqa64 0x5c0(%rsp),%zmm19
 1f95cd6:	vmovdqa64 0x580(%rsp),%zmm20
 1f95cde:	vmovdqa64 0x300(%rsp),%zmm21
 1f95ce6:	vmovdqa64 0x2c0(%rsp),%zmm22
 1f95cee:	vmovdqa64 0x280(%rsp),%zmm23
 1f95cf6:	vmovdqa64 0x540(%rsp),%zmm24
 1f95cfe:	vmovdqa64 0x240(%rsp),%zmm9
 1f95d06:	vmovdqa64 0x500(%rsp),%zmm2
 1f95d0e:	vmovdqa64 0x4c0(%rsp),%zmm5
 1f95d16:	mov    0x18(%rsp),%r8
 1f95d1b:	mov    0x38(%rsp),%r10
 1f95d20:	kmovq  0x58(%rsp),%k4
 1f95d27:	kmovq  0x50(%rsp),%k6
 1f95d2e:	mov    0x140(%rsp),%rdi
 1f95d36:	shlx   %r13,%rcx,%rax
 1f95d3b:	or     %rax,%r14
 1f95d3e:	blsr   %r15,%r15
 1f95d43:	jne    1f95b73 <node_contexts_window_loop+0x1d33>
 1f95d49:	andn   %r10,%r14,%r10
 1f95d4e:	mov    %r10,0x38(%rsp)
 1f95d53:	jmp    1f94b33 <node_contexts_window_loop+0xcf3>
 1f95d58:	movq   $0x0,0x38(%rsp)
 1f95d61:	jmp    1f94b33 <node_contexts_window_loop+0xcf3>
 1f95d66:	vmovq  0xe8(%rsp),%xmm0
 1f95d6f:	mov    0x190(%rsp),%rcx
 1f95d77:	mov    0x68(%rsp),%rax
 1f95d7c:	mov    0x118(%rsp),%rdx
 1f95d84:	vmovq  %r15,%xmm1
 1f95d89:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f95d8d:	vmovq  %rdx,%xmm1
 1f95d92:	vmovq  %rax,%xmm2
 1f95d97:	vpunpcklqdq %xmm1,%xmm2,%xmm1
 1f95d9b:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f95da1:	vmovq  %r8,%xmm1
 1f95da6:	vinserti64x4 $0x1,%ymm4,%zmm0,%zmm0
 1f95dad:	vpaddq (%rcx),%zmm0,%zmm0
 1f95db3:	vmovdqu64 %zmm0,(%rcx)
 1f95db9:	vmovq  %r9,%xmm0
 1f95dbe:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f95dc2:	vinserti128 $0x1,%xmm3,%ymm0,%ymm0
 1f95dc8:	vpaddq 0x40(%rcx),%ymm0,%ymm0
 1f95dcd:	vmovdqu %ymm0,0x40(%rcx)
 1f95dd2:	lea    -0x28(%rbp),%rsp
 1f95dd6:	pop    %rbx
 1f95dd7:	pop    %r12
 1f95dd9:	pop    %r13
 1f95ddb:	pop    %r14
 1f95ddd:	pop    %r15
 1f95ddf:	pop    %rbp
 1f95de0:	vzeroupper
 1f95de3:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
