
results/cast90d/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f93e40 <node_contexts_window_loop>:
 1f93e40:	push   %rbp
 1f93e41:	mov    %rsp,%rbp
 1f93e44:	push   %r15
 1f93e46:	push   %r14
 1f93e48:	push   %r13
 1f93e4a:	push   %r12
 1f93e4c:	push   %rbx
 1f93e4d:	and    $0xffffffffffffffc0,%rsp
 1f93e51:	sub    $0xa00,%rsp
 1f93e58:	mov    (%rdi),%rax
 1f93e5b:	mov    0xb40(%rdi),%r11
 1f93e62:	add    $0x3f,%edx
 1f93e65:	vpxor  %xmm0,%xmm0,%xmm0
 1f93e69:	mov    0x8(%rax),%rax
 1f93e6d:	movzbl 0x14a(%rax),%eax
 1f93e74:	vmovdqa64 %zmm0,0x900(%rsp)
 1f93e7c:	vmovdqa64 %zmm0,0x8c0(%rsp)
 1f93e84:	vmovdqa64 %zmm0,0x880(%rsp)
 1f93e8c:	vmovdqa64 %zmm0,0x840(%rsp)
 1f93e94:	vmovdqa64 %zmm0,0x800(%rsp)
 1f93e9c:	vmovdqa64 %zmm0,0x7c0(%rsp)
 1f93ea4:	vmovdqa64 %zmm0,0x780(%rsp)
 1f93eac:	vmovdqa64 %zmm0,0x740(%rsp)
 1f93eb4:	mov    %al,0x1f(%rsp)
 1f93eb8:	cmp    $0x40,%edx
 1f93ebb:	jae    1f93ed2 <node_contexts_window_loop+0x92>
 1f93ebd:	xor    %esi,%esi
 1f93ebf:	xor    %edx,%edx
 1f93ec1:	xor    %eax,%eax
 1f93ec3:	xor    %r8d,%r8d
 1f93ec6:	xor    %r10d,%r10d
 1f93ec9:	vpxor  %xmm3,%xmm3,%xmm3
 1f93ecd:	jmp    1f95c15 <node_contexts_window_loop+0x1dd5>
 1f93ed2:	vbroadcasti32x4 -0x19cbf7c(%rip),%zmm8        # 5c7f60 <.LCPI44_39>
 1f93edc:	shr    $0x6,%edx
 1f93edf:	mov    $0xffffffff,%ebx
 1f93ee4:	mov    %rcx,0x118(%rsp)
 1f93eec:	vpxor  %xmm3,%xmm3,%xmm3
 1f93ef0:	vpxor  %xmm13,%xmm13,%xmm13
 1f93ef5:	xor    %r9d,%r9d
 1f93ef8:	xor    %r10d,%r10d
 1f93efb:	xor    %r8d,%r8d
 1f93efe:	xor    %eax,%eax
 1f93f00:	movq   $0x0,0x58(%rsp)
 1f93f09:	xor    %r15d,%r15d
 1f93f0c:	vpxor  %xmm12,%xmm12,%xmm12
 1f93f11:	movq   $0x0,0xc8(%rsp)
 1f93f1d:	movq   $0x0,0xf0(%rsp)
 1f93f29:	vmovdqa64 %zmm0,0x6c0(%rsp)
 1f93f31:	mov    %rdi,0x50(%rsp)
 1f93f36:	mov    %rsi,0x68(%rsp)
 1f93f3b:	mov    %r11,0xd8(%rsp)
 1f93f43:	jmp    1f9404e <node_contexts_window_loop+0x20e>
 1f93f48:	nopl   0x0(%rax,%rax,1)
 1f93f50:	andn   0x88(%rsp),%rax,%rax
 1f93f5a:	vmovdqa64 0x180(%rsp),%zmm4
 1f93f62:	mov    0x158(%rsp),%rcx
 1f93f6a:	or     0x78(%rsp),%r12
 1f93f6f:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f93f73:	vpunpcklqdq %xmm2,%xmm3,%xmm1
 1f93f77:	vmovdqa64 0x980(%rsp),%zmm3
 1f93f7f:	vmovdqa64 0x700(%rsp),%zmm13
 1f93f87:	vmovdqa64 0x680(%rsp),%zmm12
 1f93f8f:	mov    0x168(%rsp),%r10
 1f93f97:	mov    0xe0(%rsp),%r15
 1f93f9f:	mov    0xd8(%rsp),%r11
 1f93fa7:	add    0x10(%rsp),%r10
 1f93fac:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f93fb2:	vpopcntq %ymm0,%ymm0
 1f93fb8:	and    %rdi,%rax
 1f93fbb:	mov    0x50(%rsp),%rdi
 1f93fc0:	mov    %ecx,%r8d
 1f93fc3:	shl    $0x6,%r8
 1f93fc7:	vptestnmb %zmm4,%zmm4,%k1
 1f93fcd:	vpxor  %xmm4,%xmm4,%xmm4
 1f93fd1:	vpaddq %ymm3,%ymm0,%ymm3
 1f93fd5:	kmovq  %k1,%r9
 1f93fda:	kmovq  0x108(%rsp),%k1
 1f93fe4:	mov    0xbe8(%rdi),%rdx
 1f93feb:	and    %rax,%r9
 1f93fee:	kandq  %k1,%k0,%k0
 1f93ff3:	vpcmpgtb %zmm9,%zmm4,%k1{%k1}
 1f93ff9:	mov    %rax,(%rdx,%r8,1)
 1f93ffd:	mov    %r9,0x8(%rdx,%r8,1)
 1f94002:	mov    0x80(%rsp),%r9
 1f9400a:	mov    0x170(%rsp),%rax
 1f94012:	mov    %r12,0x10(%rdx,%r8,1)
 1f94017:	kmovq  %k0,0x18(%rdx,%r8,1)
 1f9401e:	kmovq  %k1,0x20(%rdx,%r8,1)
 1f94025:	mov    0x160(%rsp),%r8
 1f9402d:	mov    0x178(%rsp),%rdx
 1f94035:	add    0x8(%rsp),%rax
 1f9403a:	add    0x20(%rsp),%r8
 1f9403f:	and    $0x1,%r9d
 1f94043:	dec    %rdx
 1f94046:	test   %ecx,%ecx
 1f94048:	je     1f95bee <node_contexts_window_loop+0x1dae>
 1f9404e:	mov    %r9,0x80(%rsp)
 1f94056:	lea    -0x1(%rdx),%r9d
 1f9405a:	mov    %r10,0x168(%rsp)
 1f94062:	mov    %r8,0x160(%rsp)
 1f9406a:	vpbroadcastq -0x19c5afc(%rip),%zmm1        # 5ce578 <.LCPI44_0>
 1f94074:	mov    0xba8(%rdi),%r14
 1f9407b:	vmovdqa64 %zmm3,0x980(%rsp)
 1f94083:	vmovdqa64 -0x1add20d(%rip),%zmm5        # 4b6e80 <abi_test_hex.digits+0xbb00>
 1f9408d:	vmovdqu64 (%r11),%zmm4
 1f94093:	vmovdqa64 0x6c0(%rsp),%zmm0
 1f9409b:	mov    %ebx,0xec(%rsp)
 1f940a2:	vmovdqa64 -0x1add1ac(%rip),%zmm6        # 4b6f00 <abi_test_hex.digits+0xbb80>
 1f940ac:	mov    %rax,0x170(%rsp)
 1f940b4:	mov    %rdx,0x178(%rsp)
 1f940bc:	mov    0xb88(%rdi),%rax
 1f940c3:	mov    0xb90(%rdi),%rcx
 1f940ca:	mov    0xb98(%rdi),%rdx
 1f940d1:	mov    0xba0(%rdi),%r13
 1f940d8:	mov    %r9,%r10
 1f940db:	shl    $0x6,%r10
 1f940df:	test   %r9d,%r9d
 1f940e2:	mov    %r9,0x158(%rsp)
 1f940ea:	lea    -0x40(%r10),%r8d
 1f940ee:	vpandq 0x2c(%rsi,%r10,1),%zmm1,%zmm7
 1f940f9:	mov    %r10,0x10(%rsp)
 1f940fe:	cmove  %r9d,%r8d
 1f94102:	shl    $0x7,%r9
 1f94106:	vmovdqu64 0x6f654(%rsi,%r9,1),%zmm1
 1f94111:	vmovdqu64 0x6f694(%rsi,%r9,1),%zmm2
 1f9411c:	vmovdqu64 0x6b594(%rsi,%r9,1),%zmm3
 1f94127:	vmovdqu64 (%r14,%r10,1),%zmm11
 1f9412e:	vmovdqu64 (%rdx,%r10,1),%zmm10
 1f94135:	vmovdqu64 (%rcx,%r8,1),%zmm23
 1f9413c:	vmovdqu64 (%rax,%r10,1),%zmm15
 1f94143:	vmovdqu64 (%rcx,%r10,1),%zmm16
 1f9414a:	vmovdqu64 0x0(%r13,%r10,1),%zmm9
 1f94152:	vmovdqu64 (%r14,%r8,1),%zmm18
 1f94159:	vpermt2b 0x40(%r11),%zmm7,%zmm4
 1f94160:	vmovdqa64 %zmm7,0x700(%rsp)
 1f94168:	vpmovuswb %zmm1,%ymm1
 1f9416e:	vpmovuswb %zmm2,%ymm2
 1f94174:	vpmovuswb %zmm3,%ymm3
 1f9417a:	vmovdqa64 %zmm23,%zmm20
 1f94180:	vmovdqa64 %zmm10,0x940(%rsp)
 1f94188:	vinserti64x4 $0x1,%ymm2,%zmm1,%zmm1
 1f9418f:	vmovdqu64 0x196ac(%rsi,%r10,1),%zmm2
 1f9419a:	vpaddb -0x1add2e4(%rip),%zmm1,%zmm14        # 4b6ec0 <abi_test_hex.digits+0xbb40>
 1f941a4:	vmovdqa64 %zmm4,%zmm22
 1f941aa:	vmovdqa64 %zmm4,0x6c0(%rsp)
 1f941b2:	vptestmb %zmm2,%zmm2,%k0
 1f941b8:	vpandd -0x19c3212(%rip){1to16},%zmm11,%zmm2        # 5d0fb0 <.LCPI44_40>
 1f941c2:	kmovq  %k0,%r11
 1f941c7:	vptestmb %zmm2,%zmm2,%k4
 1f941cd:	vmovdqu64 0x6b554(%rsi,%r9,1),%zmm2
 1f941d8:	kandq  %k4,%k0,%k2
 1f941dd:	vpcmpleub %zmm5,%zmm1,%k0
 1f941e4:	kmovq  %k4,0x108(%rsp)
 1f941ee:	kmovq  %k0,%rbx
 1f941f3:	and    %r11,%rbx
 1f941f6:	kmovq  %rbx,%k1
 1f941fb:	mov    %rbx,0x78(%rsp)
 1f94200:	vpermt2b %zmm0,%zmm14,%zmm22{%k1}{z}
 1f94206:	vmovdqu64 0x6d5d4(%rsi,%r9,1),%zmm0
 1f94211:	kmovq  %k1,0x150(%rsp)
 1f9421b:	vpmovuswb %zmm2,%ymm2
 1f94221:	vinserti64x4 $0x1,%ymm3,%zmm2,%zmm3
 1f94228:	vmovdqu64 0x6d614(%rsi,%r9,1),%zmm2
 1f94233:	vpmovuswb %zmm0,%ymm0
 1f94239:	kmovq  %k4,%r9
 1f9423e:	vptestmb %zmm3,%zmm3,%k0
 1f94244:	vpsubb %zmm3,%zmm6,%zmm21
 1f9424a:	mov    %r9,0x88(%rsp)
 1f94252:	kandq  %k0,%k4,%k3
 1f94257:	vpcmpnleub %zmm5,%zmm1,%k4{%k2}
 1f9425e:	vbroadcasti32x4 -0x19cc2f8(%rip),%zmm5        # 5c7f70 <.LCPI44_41>
 1f94268:	vmovdqu64 0x0(%r13,%r8,1),%zmm1
 1f94270:	kmovq  %k0,%r12
 1f94275:	vpcmpnltub %zmm3,%zmm6,%k0
 1f9427c:	vpandq 0x2c(%rsi,%r8,1),%zmm5,%zmm19
 1f94287:	kmovq  %k0,%r11
 1f9428c:	vpcmpltub %zmm3,%zmm6,%k2{%k3}
 1f94293:	kmovq  %k4,0xf8(%rsp)
 1f9429d:	and    %r12,%r11
 1f942a0:	kortestq %k4,%k2
 1f942a5:	kmovq  %r11,%k3
 1f942aa:	mov    %r11,0x20(%rsp)
 1f942af:	vpermt2b %zmm16,%zmm21,%zmm20{%k3}{z}
 1f942b5:	vpermt2b %zmm11,%zmm21,%zmm18{%k3}{z}
 1f942bb:	vpmovuswb %zmm2,%ymm2
 1f942c1:	vpermt2b %zmm7,%zmm21,%zmm19{%k3}{z}
 1f942c7:	vinserti64x4 $0x1,%ymm2,%zmm0,%zmm0
 1f942ce:	vpcmpltub -0x1add399(%rip),%zmm0,%k1        # 4b6f40 <abi_test_hex.digits+0xbbc0>
 1f942d9:	vmovdqu64 (%rdx,%r8,1),%zmm2
 1f942e0:	vpsubb %zmm0,%zmm6,%zmm4
 1f942e6:	vptestmb %zmm0,%zmm0,%k5{%k1}
 1f942ec:	vmovdqu64 (%rax,%r8,1),%zmm0
 1f942f3:	vmovdqa64 %zmm2,%zmm3
 1f942f9:	vpermt2b %zmm10,%zmm21,%zmm3{%k3}{z}
 1f942ff:	vpermt2b %zmm10,%zmm4,%zmm2
 1f94305:	kmovq  %k4,%r8
 1f9430a:	mov    %r8,0x30(%rsp)
 1f9430f:	vpermt2b %zmm16,%zmm4,%zmm23{%k5}{z}
 1f94315:	vmovdqa64 %zmm0,%zmm25
 1f9431b:	vpermt2b %zmm15,%zmm21,%zmm25{%k3}{z}
 1f94321:	vpermi2b %zmm9,%zmm1,%zmm21{%k3}{z}
 1f94327:	vpermt2b %zmm15,%zmm4,%zmm0
 1f9432d:	vpermt2b %zmm9,%zmm4,%zmm1
 1f94333:	jne    1f95a64 <node_contexts_window_loop+0x1c24>
 1f94339:	mov    0x10(%rsp),%r14
 1f9433e:	vbroadcasti32x4 -0x19cc3c8(%rip),%zmm5        # 5c7f80 <.LCPI44_42>
 1f94348:	vbroadcasti32x4 -0x19cc3c2(%rip),%zmm6        # 5c7f90 <.LCPI44_43>
 1f94352:	vpxor  %xmm4,%xmm4,%xmm4
 1f94356:	vbroadcasti32x4 -0x19cc3c0(%rip),%zmm7        # 5c7fa0 <.LCPI44_44>
 1f94360:	vmovdqa64 0x6c0(%rsp),%zmm26
 1f94368:	mov    %r15,0xe0(%rsp)
 1f94370:	vmovdqa64 %zmm9,0x640(%rsp)
 1f94378:	vmovdqa64 %zmm11,0x600(%rsp)
 1f94380:	vpandq -0x19c5e0a(%rip){1to8},%zmm26,%zmm10        # 5ce580 <.LCPI44_20>
 1f9438a:	vmovdqu64 0x1a72c(%rsi,%r14,1),%zmm17
 1f94395:	vpandq %zmm5,%zmm3,%zmm3
 1f9439b:	vpandq %zmm5,%zmm2,%zmm2
 1f943a1:	vbroadcasti32x4 -0x19cc3fb(%rip),%zmm5        # 5c7fb0 <.LCPI44_45>
 1f943ab:	vpcmpeqb %zmm6,%zmm3,%k0
 1f943b1:	vbroadcasti32x4 -0x19cc3fb(%rip),%zmm3        # 5c7fc0 <.LCPI44_46>
 1f943bb:	vmovdqa64 %zmm10,0x5c0(%rsp)
 1f943c3:	kmovq  %k0,%rax
 1f943c8:	vpcmpeqb %zmm6,%zmm2,%k0{%k5}
 1f943ce:	vpandd -0x19c3424(%rip){1to16},%zmm9,%zmm2        # 5d0fb4 <.LCPI44_47>
 1f943d8:	and    0x20(%rsp),%rax
 1f943dd:	vpcmpeqb -0x1add3e7(%rip),%zmm2,%k3        # 4b7000 <abi_test_hex.digits+0xbc80>
 1f943e7:	vptestnmb %zmm17,%zmm17,%k2
 1f943ed:	vpcmpgtb %zmm22,%zmm4,%k4{%k2}
 1f943f3:	kmovq  %k2,0x40(%rsp)
 1f943fa:	vptestmb %zmm6,%zmm20,%k2
 1f94400:	kmovq  %k2,%rdx
 1f94405:	vptestmb %zmm6,%zmm23,%k2
 1f9440b:	kmovq  %k4,%r13
 1f94410:	kmovq  %k4,0x130(%rsp)
 1f9441a:	korq   %k0,%k2,%k1
 1f9441f:	vptestmb -0x1add229(%rip),%zmm16,%k0        # 4b7200 <abi_test_hex.digits+0xbe80>
 1f94429:	or     %rax,%rdx
 1f9442c:	mov    %r13,0x120(%rsp)
 1f94434:	vpandq %zmm3,%zmm9,%zmm24
 1f9443a:	vpcmpeqb -0x1add184(%rip),%zmm24,%k7        # 4b72c0 <abi_test_hex.digits+0xbf40>
 1f94444:	vpandq %zmm3,%zmm1,%zmm1
 1f9444a:	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
 1f94451:	mov    %rdx,0x680(%rsp)
 1f94459:	vptestnmb %zmm2,%zmm2,%k2
 1f9445f:	vbroadcasti32x4 -0x19cc499(%rip),%zmm2        # 5c7fd0 <.LCPI44_48>
 1f94469:	vpaddb %zmm3,%zmm15,%zmm27
 1f9446f:	vpaddb %zmm3,%zmm0,%zmm0
 1f94475:	kmovq  %k3,0x580(%rsp)
 1f9447f:	kmovq  %k0,%rcx
 1f94484:	vptestmb %zmm7,%zmm16,%k0
 1f9448a:	korq   %k4,%k0,%k6
 1f9448f:	mov    %rcx,0x540(%rsp)
 1f94497:	kmovq  %k2,%rcx
 1f9449c:	vptestmb %zmm24,%zmm24,%k2
 1f944a2:	kandq  %k7,%k6,%k0
 1f944a7:	kmovq  %k2,%rsi
 1f944ac:	vpcmpltub %zmm6,%zmm27,%k2
 1f944b3:	mov    %rcx,0x28(%rsp)
 1f944b8:	kmovq  %k6,0x48(%rsp)
 1f944bf:	kmovq  %k0,%rdi
 1f944c4:	vptestmb %zmm2,%zmm16,%k0{%k3}
 1f944ca:	kmovq  %k2,0x98(%rsp)
 1f944d4:	vptestmb %zmm2,%zmm26,%k2{%k2}
 1f944da:	vpcmpltub %zmm5,%zmm27,%k3
 1f944e1:	vpandq %zmm2,%zmm20,%zmm2
 1f944e7:	andn   0x28(%rsp),%r13,%rax
 1f944ee:	kmovq  %k3,0xb8(%rsp)
 1f944f8:	kmovq  %k0,%r8
 1f944fd:	vpcmpeqb %zmm7,%zmm1,%k0{%k5}
 1f94503:	kmovq  %k2,0x140(%rsp)
 1f9450d:	vpcmpltub %zmm5,%zmm0,%k5{%k5}
 1f94514:	vbroadcasti32x4 -0x19cc53e(%rip),%zmm0        # 5c7fe0 <.LCPI44_49>
 1f9451e:	or     %rax,%rdi
 1f94521:	vpandq %zmm8,%zmm11,%zmm5
 1f94527:	kmovq  %k0,0x148(%rsp)
 1f94531:	kandq  %k0,%k2,%k0
 1f94536:	vptestnmb %zmm19,%zmm19,%k2
 1f9453c:	andn   %r8,%r13,%r8
 1f94541:	mov    0x50(%rsp),%r13
 1f94546:	and    %rsi,%rdi
 1f94549:	or     0x540(%rsp),%r8
 1f94551:	kmovq  %k3,%rsi
 1f94556:	knotq  %k0,%k0
 1f9455b:	kmovq  %k2,0x100(%rsp)
 1f94565:	vpcmpgtb %zmm18,%zmm4,%k2{%k2}
 1f9456b:	kmovq  %k0,%r9
 1f94570:	vpcmpeqb -0x1add33a(%rip),%zmm10,%k0{%k3}        # 4b7240 <abi_test_hex.digits+0xbec0>
 1f9457a:	mov    0xbd0(%r13),%rax
 1f94581:	mov    %r8,0xc0(%rsp)
 1f94589:	kmovq  %k0,%r15
 1f9458e:	vptestmb %zmm2,%zmm2,%k0
 1f94594:	vmovdqu64 %zmm10,(%rax,%r14,1)
 1f9459b:	korq   %k2,%k0,%k0
 1f945a0:	vpcmpeqb %zmm7,%zmm10,%k2
 1f945a6:	and    %r9,%r15
 1f945a9:	kmovq  %k6,%r9
 1f945ae:	knotq  %k0,%k0
 1f945b3:	kmovq  %k2,0x8(%rsp)
 1f945ba:	mov    %r9,0xa0(%rsp)
 1f945c2:	kmovq  %k0,%r10
 1f945c7:	vptestmb -0x1adcfd1(%rip),%zmm26,%k0        # 4b7600 <abi_test_hex.digits+0xc280>
 1f945d1:	kmovq  %k0,0xb0(%rsp)
 1f945db:	korq   %k5,%k0,%k0
 1f945e0:	kmovq  %k0,%rcx
 1f945e5:	vpcmpeqb %zmm0,%zmm10,%k0
 1f945eb:	korq   %k0,%k2,%k0
 1f945f0:	or     %rdx,%rcx
 1f945f3:	kmovq  %k0,%r11
 1f945f8:	vpcmpneqb %zmm0,%zmm10,%k0
 1f945ff:	and    %r10,%rcx
 1f94602:	mov    %rsi,%r10
 1f94605:	vpsllw $0x7,%zmm11,%zmm0
 1f9460c:	kmovq  %k0,%r12
 1f94611:	vptestmb %zmm5,%zmm5,%k0
 1f94617:	korq   %k0,%k1,%k0
 1f9461c:	or     %r10,%r12
 1f9461f:	or     %r9,%r12
 1f94622:	knotq  %k0,%k0
 1f94627:	and    0x88(%rsp),%r12
 1f9462f:	kmovq  %k0,%rbx
 1f94634:	vpmovb2m %zmm0,%k0
 1f9463a:	kmovq  %k0,%rax
 1f9463f:	and    %r11,%rbx
 1f94642:	kmovq  %k0,0xa8(%rsp)
 1f9464c:	andn   %rdi,%rax,%rsi
 1f94651:	mov    %r8,%rdi
 1f94654:	not    %rdi
 1f94657:	mov    %rax,0x128(%rsp)
 1f9465f:	andn   %rdi,%rsi,%rax
 1f94664:	mov    %rsi,0xd0(%rsp)
 1f9466c:	and    %rax,%r12
 1f9466f:	and    %rax,%r15
 1f94672:	mov    %rax,0x60(%rsp)
 1f94677:	and    %r15,%rcx
 1f9467a:	and    %rbx,%r12
 1f9467d:	mov    %r15,0x138(%rsp)
 1f94685:	or     %rcx,%r12
 1f94688:	mov    %rcx,0x70(%rsp)
 1f9468d:	and    %rdx,%r12
 1f94690:	je     1f948b0 <node_contexts_window_loop+0xa70>
 1f94696:	mov    0x58(%rsp),%r8
 1f9469b:	mov    0x10(%rsp),%r11
 1f946a0:	mov    %r12,%rbx
 1f946a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f946b0:	mov    0x2c0(%r13),%rax
 1f946b7:	xor    %r14d,%r14d
 1f946ba:	tzcnt  %rbx,%r14
 1f946bf:	mov    0x60(%r13),%edx
 1f946c3:	lea    (%r14,%r11,1),%r15
 1f946c7:	mov    %r15,%rcx
 1f946ca:	shl    $0x6,%rcx
 1f946ce:	mov    0x20(%rax,%rcx,1),%esi
 1f946d2:	mov    0x20(%r13),%rcx
 1f946d6:	mov    %esi,%eax
 1f946d8:	shr    $0x3,%eax
 1f946db:	cmp    %edx,%eax
 1f946dd:	cmovae %edx,%eax
 1f946e0:	shl    $0x6,%rax
 1f946e4:	testb  $0x4,0x34(%rcx,%rax,1)
 1f946e9:	je     1f9471b <node_contexts_window_loop+0x8db>
 1f946eb:	mov    0x38(%rcx,%rax,1),%eax
 1f946ef:	mov    0xbe0(%r13),%rcx
 1f946f6:	mov    %rax,(%rcx,%r15,8)
 1f946fa:	xor    %ecx,%ecx
 1f946fc:	test   %rax,%rax
 1f946ff:	sete   %cl
 1f94702:	inc    %r8
 1f94705:	shlx   %r14,%rcx,%rax
 1f9470a:	andn   %r12,%rax,%r12
 1f9470f:	blsr   %rbx,%rbx
 1f94714:	jne    1f946b0 <node_contexts_window_loop+0x870>
 1f94716:	jmp    1f948bd <node_contexts_window_loop+0xa7d>
 1f9471b:	mov    %r13,%rdi
 1f9471e:	mov    %r8,0x58(%rsp)
 1f94723:	vmovdqa64 %zmm12,0x180(%rsp)
 1f9472b:	vmovdqa64 %zmm13,0x300(%rsp)
 1f94733:	vmovdqa64 %zmm14,0x2c0(%rsp)
 1f9473b:	vmovdqa64 %zmm15,0x280(%rsp)
 1f94743:	vmovdqa64 %zmm16,0x240(%rsp)
 1f9474b:	vmovdqa64 %zmm17,0x200(%rsp)
 1f94753:	vmovdqa64 %zmm18,0x500(%rsp)
 1f9475b:	vmovdqa64 %zmm19,0x4c0(%rsp)
 1f94763:	vmovdqa64 %zmm20,0x480(%rsp)
 1f9476b:	vmovdqa64 %zmm21,0x440(%rsp)
 1f94773:	vmovdqa64 %zmm22,0x400(%rsp)
 1f9477b:	vmovdqa64 %zmm23,0x3c0(%rsp)
 1f94783:	vmovdqa64 %zmm24,0x380(%rsp)
 1f9478b:	kmovq  %k7,0x38(%rsp)
 1f94792:	vmovdqa64 %zmm25,0x540(%rsp)
 1f9479a:	vmovdqa64 %zmm2,0x340(%rsp)
 1f947a2:	vmovdqa64 %zmm5,0x1c0(%rsp)
 1f947aa:	kmovq  %k1,0x28(%rsp)
 1f947b1:	kmovq  %k5,0x90(%rsp)
 1f947bb:	mov    %r10,0x110(%rsp)
 1f947c3:	vzeroupper
 1f947c6:	call   1f963c0 <node_contexts_stride_asked>
 1f947cb:	vmovdqa64 0x1c0(%rsp),%zmm5
 1f947d3:	vmovdqa64 0x340(%rsp),%zmm2
 1f947db:	vmovdqa64 0x540(%rsp),%zmm25
 1f947e3:	vmovdqa64 0x380(%rsp),%zmm24
 1f947eb:	vmovdqa64 0x3c0(%rsp),%zmm23
 1f947f3:	vmovdqa64 0x400(%rsp),%zmm22
 1f947fb:	vmovdqa64 0x440(%rsp),%zmm21
 1f94803:	vmovdqa64 0x480(%rsp),%zmm20
 1f9480b:	vmovdqa64 0x4c0(%rsp),%zmm19
 1f94813:	vmovdqa64 0x500(%rsp),%zmm18
 1f9481b:	vmovdqa64 0x200(%rsp),%zmm17
 1f94823:	vmovdqa64 0x240(%rsp),%zmm16
 1f9482b:	vmovdqa64 0x280(%rsp),%zmm15
 1f94833:	vmovdqa64 0x5c0(%rsp),%zmm10
 1f9483b:	vmovdqa64 0x2c0(%rsp),%zmm14
 1f94843:	vmovdqa64 0x300(%rsp),%zmm13
 1f9484b:	vmovdqa64 0x180(%rsp),%zmm12
 1f94853:	vmovdqa64 0x600(%rsp),%zmm11
 1f9485b:	vmovdqa64 0x640(%rsp),%zmm9
 1f94863:	vbroadcasti32x4 -0x19cc90d(%rip),%zmm8        # 5c7f60 <.LCPI44_39>
 1f9486d:	mov    0x110(%rsp),%r10
 1f94875:	kmovq  0x90(%rsp),%k5
 1f9487f:	kmovq  0x28(%rsp),%k1
 1f94886:	kmovq  0x38(%rsp),%k7
 1f9488d:	mov    0x10(%rsp),%r11
 1f94892:	mov    0x58(%rsp),%r8
 1f94897:	incq   0xf0(%rsp)
 1f9489f:	jmp    1f946ef <node_contexts_window_loop+0x8af>
 1f948a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f948b0:	mov    0x58(%rsp),%r8
 1f948b5:	mov    0x10(%rsp),%r11
 1f948ba:	xor    %r12d,%r12d
 1f948bd:	vpternlogd $0xff,%zmm0,%zmm0,%zmm0
 1f948c4:	kmovq  %k1,%rax
 1f948c9:	vpaddb -0x1add4d3(%rip),%zmm10,%zmm1        # 4b7400 <abi_test_hex.digits+0xc080>
 1f948d3:	kmovq  0x8(%rsp),%k0
 1f948da:	or     0x680(%rsp),%rax
 1f948e2:	mov    0x60(%rsp),%r9
 1f948e7:	mov    %r8,0x58(%rsp)
 1f948ec:	vpaddb %zmm0,%zmm25,%zmm0
 1f948f2:	vpcmpltub -0x1add7bd(%rip),%zmm0,%k1{%k5}        # 4b7140 <abi_test_hex.digits+0xbdc0>
 1f948fd:	kmovq  %k0,%rcx
 1f94902:	mov    %r9,%r8
 1f94905:	and    %r10,%r8
 1f94908:	andn   %rcx,%rax,%rax
 1f9490d:	mov    %r8,0x540(%rsp)
 1f94915:	vpcmpltub %zmm8,%zmm1,%k0
 1f9491c:	kmovq  %k0,%rdx
 1f94921:	kmovq  %k1,%rsi
 1f94926:	or     %rdx,%rax
 1f94929:	andn   %r10,%rsi,%rbx
 1f9492e:	and    0x88(%rsp),%rbx
 1f94936:	and    %rsi,%r8
 1f94939:	and    %rax,%r8
 1f9493c:	mov    %r8,0x90(%rsp)
 1f94944:	and    %rax,%rbx
 1f94947:	and    %r9,%rbx
 1f9494a:	je     1f95010 <node_contexts_window_loop+0x11d0>
 1f94950:	mov    0x0(%r13),%rax
 1f94954:	mov    0x2c0(%r13),%rcx
 1f9495b:	mov    0xe0(%rsp),%r13
 1f94963:	xor    %r14d,%r14d
 1f94966:	vmovdqa64 %zmm5,0x1c0(%rsp)
 1f9496e:	vmovdqa64 %zmm2,0x340(%rsp)
 1f94976:	kmovq  %k7,0x38(%rsp)
 1f9497d:	vmovdqa64 %zmm24,0x380(%rsp)
 1f94985:	vmovdqa64 %zmm23,0x3c0(%rsp)
 1f9498d:	vmovdqa64 %zmm22,0x400(%rsp)
 1f94995:	vmovdqa64 %zmm21,0x440(%rsp)
 1f9499d:	vmovdqa64 %zmm20,0x480(%rsp)
 1f949a5:	vmovdqa64 %zmm19,0x4c0(%rsp)
 1f949ad:	vmovdqa64 %zmm18,0x500(%rsp)
 1f949b5:	vmovdqa64 %zmm17,0x200(%rsp)
 1f949bd:	vmovdqa64 %zmm16,0x240(%rsp)
 1f949c5:	vmovdqa64 %zmm15,0x280(%rsp)
 1f949cd:	vmovdqa64 %zmm14,0x2c0(%rsp)
 1f949d5:	vmovdqa64 %zmm13,0x300(%rsp)
 1f949dd:	vmovdqa64 %zmm12,0x180(%rsp)
 1f949e5:	mov    %rax,0x8(%rsp)
 1f949ea:	mov    %rcx,0x28(%rsp)
 1f949ef:	mov    0x8(%rsp),%rdi
 1f949f4:	mov    0x28(%rsp),%rsi
 1f949f9:	xor    %r15d,%r15d
 1f949fc:	tzcnt  %rbx,%r15
 1f94a01:	lea    (%r11,%r15,1),%edx
 1f94a05:	vzeroupper
 1f94a08:	call   1f962f7 <node_contexts_converted>
 1f94a0d:	mov    0x10(%rsp),%r11
 1f94a12:	movzbl %al,%eax
 1f94a15:	inc    %r13
 1f94a18:	shlx   %r15,%rax,%rax
 1f94a1d:	or     %rax,%r14
 1f94a20:	blsr   %rbx,%rbx
 1f94a25:	jne    1f949ef <node_contexts_window_loop+0xbaf>
 1f94a27:	vbroadcasti32x4 -0x19ccad1(%rip),%zmm8        # 5c7f60 <.LCPI44_39>
 1f94a31:	vmovdqa64 0x640(%rsp),%zmm9
 1f94a39:	vmovdqa64 0x600(%rsp),%zmm11
 1f94a41:	vmovdqa64 0x180(%rsp),%zmm12
 1f94a49:	vmovdqa64 0x300(%rsp),%zmm13
 1f94a51:	vmovdqa64 0x2c0(%rsp),%zmm14
 1f94a59:	vmovdqa64 0x5c0(%rsp),%zmm10
 1f94a61:	vmovdqa64 0x280(%rsp),%zmm15
 1f94a69:	vmovdqa64 0x240(%rsp),%zmm16
 1f94a71:	vmovdqa64 0x200(%rsp),%zmm17
 1f94a79:	vmovdqa64 0x500(%rsp),%zmm18
 1f94a81:	vmovdqa64 0x4c0(%rsp),%zmm19
 1f94a89:	vmovdqa64 0x480(%rsp),%zmm20
 1f94a91:	vmovdqa64 0x440(%rsp),%zmm21
 1f94a99:	vmovdqa64 0x400(%rsp),%zmm22
 1f94aa1:	vmovdqa64 0x3c0(%rsp),%zmm23
 1f94aa9:	vmovdqa64 0x380(%rsp),%zmm24
 1f94ab1:	vmovdqa64 0x340(%rsp),%zmm2
 1f94ab9:	vmovdqa64 0x1c0(%rsp),%zmm5
 1f94ac1:	mov    %r13,0xe0(%rsp)
 1f94ac9:	or     %r14,0x90(%rsp)
 1f94ad1:	mov    0x80(%rsp),%rax
 1f94ad9:	mov    0x50(%rsp),%r13
 1f94ade:	kmovq  0x38(%rsp),%k7
 1f94ae5:	cmpb   $0x0,0x1f(%rsp)
 1f94aea:	mov    0x20(%rsp),%rdx
 1f94aef:	jne    1f95028 <node_contexts_window_loop+0x11e8>
 1f94af5:	mov    %rdx,%rdi
 1f94af8:	vbroadcasti32x4 -0x19ccb12(%rip),%zmm3        # 5c7ff0 <.LCPI44_50>
 1f94b02:	vbroadcasti32x4 -0x19ccb6c(%rip),%zmm1        # 5c7fa0 <.LCPI44_44>
 1f94b0c:	kmovq  0x100(%rsp),%k2
 1f94b16:	vbroadcasti32x4 -0x19ccb20(%rip),%zmm4        # 5c8000 <.LCPI44_51>
 1f94b20:	vbroadcasti32x4 -0x19ccb1a(%rip),%zmm6        # 5c8010 <.LCPI44_52>
 1f94b2a:	kmovq  %k7,%r9
 1f94b2f:	vbroadcasti32x4 -0x19ccb19(%rip),%zmm7        # 5c8020 <.LCPI44_53>
 1f94b39:	kmovq  0x580(%rsp),%k3
 1f94b43:	kmovq  0x40(%rsp),%k5
 1f94b4a:	shl    $0x3f,%rax
 1f94b4e:	mov    %r9,0x28(%rsp)
 1f94b53:	vpandq %zmm3,%zmm23,%zmm0
 1f94b59:	vptestmb %zmm1,%zmm18,%k1
 1f94b5f:	vbroadcasti32x4 -0x19ccb39(%rip),%zmm23        # 5c8030 <.LCPI44_54>
 1f94b69:	vptestnmb %zmm0,%zmm0,%k0
 1f94b6f:	kmovq  %k0,%rcx
 1f94b74:	kandq  %k2,%k1,%k0
 1f94b79:	kmovq  0x98(%rsp),%k2
 1f94b83:	mov    %rcx,0x8(%rsp)
 1f94b88:	kmovq  %k0,%rcx
 1f94b8d:	vptestmb %zmm1,%zmm11,%k0
 1f94b93:	vbroadcasti32x4 -0x19ccc0d(%rip),%zmm1        # 5c7f90 <.LCPI44_43>
 1f94b9d:	kmovq  %k0,%rdx
 1f94ba2:	vpcmpeqb %zmm3,%zmm10,%k0
 1f94ba8:	and    %rcx,%rdi
 1f94bab:	mov    0xc0(%rsp),%rcx
 1f94bb3:	kmovq  %k0,%rsi
 1f94bb8:	vpcmpeqb %zmm4,%zmm10,%k0
 1f94bbe:	mov    %rdx,0x180(%rsp)
 1f94bc6:	mov    %rdi,0x20(%rsp)
 1f94bcb:	mov    %rsi,0x300(%rsp)
 1f94bd3:	kmovq  %k0,%rsi
 1f94bd8:	vpcmpeqb %zmm6,%zmm10,%k0
 1f94bde:	kmovq  %k0,%rdx
 1f94be3:	korq   %k2,%k7,%k0
 1f94be8:	kmovq  0xb8(%rsp),%k7
 1f94bf2:	mov    %rdx,0x2c0(%rsp)
 1f94bfa:	vpcmpeqb %zmm1,%zmm24,%k2{%k7}
 1f94c00:	korq   %k2,%k0,%k0
 1f94c05:	vptestnmb %zmm2,%zmm2,%k2
 1f94c0b:	vpandd -0x19c3c5d(%rip){1to16},%zmm22,%zmm2        # 5d0fb8 <.LCPI44_55>
 1f94c15:	vpcmpeqb -0x1add69f(%rip),%zmm2,%k4        # 4b7580 <abi_test_hex.digits+0xc200>
 1f94c1f:	kmovq  %k0,%r8
 1f94c24:	vpcmpeqb %zmm1,%zmm10,%k0{%k7}
 1f94c2a:	kmovq  %k2,%rbx
 1f94c2f:	kandq  %k3,%k7,%k2
 1f94c34:	vpandq %zmm7,%zmm22,%zmm1
 1f94c3a:	vpandq %zmm7,%zmm21,%zmm2
 1f94c40:	kmovq  %k0,%r11
 1f94c45:	vptestnmb %zmm5,%zmm5,%k0
 1f94c4b:	kmovq  %k2,%r10
 1f94c50:	vpcmpeqb %zmm23,%zmm1,%k2
 1f94c56:	vbroadcasti32x4 -0x19ccc20(%rip),%zmm5        # 5c8040 <.LCPI44_56>
 1f94c60:	andn   %r8,%rcx,%rcx
 1f94c65:	kmovq  %k0,%r9
 1f94c6a:	mov    %rcx,0x580(%rsp)
 1f94c72:	mov    0xa0(%rsp),%rcx
 1f94c7a:	and    %r11,%rbx
 1f94c7d:	mov    %rbx,0x1c0(%rsp)
 1f94c85:	mov    0x60(%rsp),%rbx
 1f94c8a:	and    %rsi,%r9
 1f94c8d:	andn   %r10,%rcx,%rdi
 1f94c92:	and    0x300(%rsp),%rdi
 1f94c9a:	kxorq  %k2,%k4,%k0
 1f94c9f:	vpcmpeqb %zmm23,%zmm10,%k2
 1f94ca5:	kmovq  %k4,0x500(%rsp)
 1f94caf:	kmovq  %k0,%rdx
 1f94cb4:	kmovq  0xb0(%rsp),%k0
 1f94cbe:	kmovq  %k2,0x340(%rsp)
 1f94cc8:	mov    %rdx,0xc0(%rsp)
 1f94cd0:	kandq  %k2,%k0,%k6
 1f94cd5:	kmovq  0x48(%rsp),%k0
 1f94cdc:	kxorq  %k2,%k6,%k2
 1f94ce1:	kmovq  %k6,0x4c0(%rsp)
 1f94ceb:	kmovq  %k2,%r15
 1f94cf0:	vpcmpeqb %zmm4,%zmm19,%k2
 1f94cf6:	vbroadcasti32x4 -0x19cccb0(%rip),%zmm4        # 5c8050 <.LCPI44_57>
 1f94d00:	kmovq  %k2,%r14
 1f94d05:	vptestnmb -0x1addb4f(%rip),%zmm21,%k2        # 4b71c0 <abi_test_hex.digits+0xbe40>
 1f94d0f:	and    %rbx,%r15
 1f94d12:	mov    %r14,0xb0(%rsp)
 1f94d1a:	kmovq  %k5,%r14
 1f94d1f:	vpcmpeqb %zmm4,%zmm2,%k1{%k1}
 1f94d25:	vpandq %zmm3,%zmm20,%zmm2
 1f94d2b:	korq   %k1,%k2,%k1
 1f94d30:	vptestmb -0x1add73a(%rip),%zmm9,%k2        # 4b7600 <abi_test_hex.digits+0xc280>
 1f94d3a:	vporq  %zmm0,%zmm2,%zmm0
 1f94d40:	kmovq  %k1,%r11
 1f94d45:	vpcmpeqb %zmm6,%zmm1,%k1
 1f94d4b:	kmovq  %k1,%rcx
 1f94d50:	kandq  %k1,%k5,%k1
 1f94d55:	and    %rbx,%r11
 1f94d58:	kmovq  %k1,%rsi
 1f94d5d:	andn   %rcx,%r14,%rcx
 1f94d62:	or     %rdx,%rcx
 1f94d65:	mov    0xb0(%rsp),%rdx
 1f94d6d:	korq   %k3,%k2,%k3
 1f94d72:	vpcmpeqb %zmm5,%zmm1,%k2
 1f94d78:	kandq  %k2,%k5,%k1
 1f94d7d:	korq   %k4,%k1,%k1
 1f94d82:	kmovq  0xa8(%rsp),%k4
 1f94d8c:	kmovq  %k1,%r8
 1f94d91:	korq   %k7,%k0,%k1
 1f94d96:	kmovq  %k1,%r10
 1f94d9b:	and    %r10,%r9
 1f94d9e:	mov    %r9,0xa0(%rsp)
 1f94da6:	mov    %r11,%r9
 1f94da9:	and    0x2c0(%rsp),%r9
 1f94db1:	korq   %k4,%k3,%k3
 1f94db6:	kmovq  0x108(%rsp),%k4
 1f94dc0:	knotq  %k3,%k3
 1f94dc5:	lea    (%r15,%r9,2),%r10
 1f94dc9:	vptestnmb %zmm15,%zmm15,%k5{%k4}
 1f94dcf:	andn   %r15,%r10,%r10
 1f94dd4:	or     %r9,%r15
 1f94dd7:	and    %r15,%rcx
 1f94dda:	mov    %r10,0x400(%rsp)
 1f94de2:	or     %r9,%r10
 1f94de5:	and    %r15,%rsi
 1f94de8:	mov    %r15,0x480(%rsp)
 1f94df0:	andn   0x8(%rsp),%rdx,%r15
 1f94df7:	and    %rcx,%rax
 1f94dfa:	and    %r10,%r8
 1f94dfd:	or     %rsi,%rax
 1f94e00:	or     %r8,%rax
 1f94e03:	mov    %rcx,%r8
 1f94e06:	shr    $1,%r8
 1f94e09:	korq   %k5,%k0,%k4
 1f94e0e:	korq   %k7,%k5,%k5
 1f94e13:	mov    %rax,%rsi
 1f94e16:	shr    $1,%rsi
 1f94e19:	and    %rcx,%r8
 1f94e1c:	and    %rcx,%rsi
 1f94e1f:	kmovq  %k2,%rcx
 1f94e24:	vpcmpeqb %zmm8,%zmm1,%k2
 1f94e2a:	mov    %r8,%r10
 1f94e2d:	shr    $0x2,%r10
 1f94e31:	or     %rax,%rsi
 1f94e34:	and    %r8,%r10
 1f94e37:	andn   %rcx,%r14,%rcx
 1f94e3c:	mov    %rsi,%rax
 1f94e3f:	shr    $0x2,%rax
 1f94e43:	mov    %r10,0x3c0(%rsp)
 1f94e4b:	and    %r8,%rax
 1f94e4e:	mov    0x78(%rsp),%r8
 1f94e53:	mov    %r9,0x78(%rsp)
 1f94e58:	or     %rsi,%rax
 1f94e5b:	kmovq  %k2,%rsi
 1f94e60:	vptestnmb %zmm2,%zmm2,%k2
 1f94e66:	vpaddb -0x1add830(%rip),%zmm19,%zmm2        # 4b7640 <abi_test_hex.digits+0xc2c0>
 1f94e70:	or     0x30(%rsp),%r8
 1f94e75:	kmovq  %k2,%rdx
 1f94e7a:	or     %rsi,%rcx
 1f94e7d:	kmovq  %k4,%rsi
 1f94e82:	kandq  %k2,%k5,%k5
 1f94e87:	mov    %rax,0x80(%rsp)
 1f94e8f:	and    %rdx,%r15
 1f94e92:	mov    0x180(%rsp),%rdx
 1f94e9a:	mov    %rsi,0x8(%rsp)
 1f94e9f:	and    %r8,%rcx
 1f94ea2:	and    %rdx,%rdi
 1f94ea5:	and    0x28(%rsp),%rdx
 1f94eaa:	vpcmpltub %zmm8,%zmm2,%k4{%k6}
 1f94eb1:	vbroadcasti32x4 -0x19cce5b(%rip),%zmm2        # 5c8060 <.LCPI44_58>
 1f94ebb:	and    %rbx,%rdi
 1f94ebe:	mov    %rdi,0x240(%rsp)
 1f94ec6:	kmovq  %k4,%rdi
 1f94ecb:	vpcmpeqb %zmm5,%zmm10,%k4
 1f94ed1:	kmovq  %k4,%rsi
 1f94ed6:	or     %rax,%rdi
 1f94ed9:	mov    %rdi,0x280(%rsp)
 1f94ee1:	kmovq  %k5,%rdi
 1f94ee6:	and    %rsi,%r11
 1f94ee9:	mov    %rsi,0x38(%rsp)
 1f94eee:	mov    %rdx,0x180(%rsp)
 1f94ef6:	mov    %rax,%rdx
 1f94ef9:	or     %r10,%rdx
 1f94efc:	and    %r11,%rdi
 1f94eff:	mov    %r11,0x440(%rsp)
 1f94f07:	andn   %r9,%rdx,%rdx
 1f94f0c:	mov    %rdi,0x200(%rsp)
 1f94f14:	and    %rdx,%r15
 1f94f17:	mov    %rdx,0x380(%rsp)
 1f94f1f:	mov    0x540(%rsp),%rdx
 1f94f27:	mov    %r15,0x98(%rsp)
 1f94f2f:	mov    0x1c0(%rsp),%r15
 1f94f37:	mov    %r14,0x1c0(%rsp)
 1f94f3f:	vpcmpeqb %zmm2,%zmm10,%k5
 1f94f45:	vpcmpeqb %zmm2,%zmm1,%k4
 1f94f4b:	kmovq  %k5,%r8
 1f94f50:	vptestnmb %zmm0,%zmm0,%k5
 1f94f56:	mov    %r8,0xa8(%rsp)
 1f94f5e:	and    %r8,%rdx
 1f94f61:	kmovq  %k4,%r8
 1f94f66:	vpcmpeqb %zmm4,%zmm1,%k4
 1f94f6c:	and    %rbx,%r15
 1f94f6f:	andn   %r8,%r14,%rdi
 1f94f74:	mov    %rdx,0x540(%rsp)
 1f94f7c:	mov    %r8,0x40(%rsp)
 1f94f81:	mov    %r15,%rsi
 1f94f84:	and    0x20(%rsp),%rsi
 1f94f89:	and    %rdx,%rcx
 1f94f8c:	kmovq  %k5,%rdx
 1f94f91:	mov    %rdi,0x28(%rsp)
 1f94f96:	kmovq  %k3,%rdi
 1f94f9b:	mov    %rdx,0x48(%rsp)
 1f94fa0:	kmovq  %k4,%rdx
 1f94fa5:	mov    %rdi,0x30(%rsp)
 1f94faa:	je     1f95200 <node_contexts_window_loop+0x13c0>
 1f94fb0:	mov    0xb88(%r13),%rdi
 1f94fb7:	mov    0x68(%rsp),%rax
 1f94fbc:	mov    0x10(%rsp),%r9
 1f94fc1:	xor    %r10d,%r10d
 1f94fc4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f94fd0:	xor    %r11d,%r11d
 1f94fd3:	tzcnt  %rcx,%r11
 1f94fd8:	lea    (%r9,%r11,1),%ebx
 1f94fdc:	movzwl 0x6f654(%rax,%rbx,2),%r14d
 1f94fe5:	add    %ebx,%r14d
 1f94fe8:	xor    %ebx,%ebx
 1f94fea:	cmpb   $0x0,(%rdi,%r14,1)
 1f94fef:	sete   %bl
 1f94ff2:	shlx   %r11,%rbx,%r11
 1f94ff7:	or     %r11,%r10
 1f94ffa:	blsr   %rcx,%rcx
 1f94fff:	jne    1f94fd0 <node_contexts_window_loop+0x1190>
 1f95001:	jmp    1f95208 <node_contexts_window_loop+0x13c8>
 1f95006:	cs nopw 0x0(%rax,%rax,1)
 1f95010:	mov    0x80(%rsp),%rax
 1f95018:	cmpb   $0x0,0x1f(%rsp)
 1f9501d:	mov    0x20(%rsp),%rdx
 1f95022:	je     1f94af5 <node_contexts_window_loop+0xcb5>
 1f95028:	mov    0x70(%rsp),%rcx
 1f9502d:	test   %rcx,%rcx
 1f95030:	je     1f95bdd <node_contexts_window_loop+0x1d9d>
 1f95036:	mov    0x0(%r13),%rax
 1f9503a:	xor    %r14d,%r14d
 1f9503d:	mov    %rcx,%r15
 1f95040:	mov    0x8(%rax),%rdi
 1f95044:	movzbl 0x14a(%rdi),%ebx
 1f9504b:	xor    %r13d,%r13d
 1f9504e:	tzcnt  %r15,%r13
 1f95053:	test   %bl,%bl
 1f95055:	jne    1f95072 <node_contexts_window_loop+0x1232>
 1f95057:	xor    %ecx,%ecx
 1f95059:	shlx   %r13,%rcx,%rax
 1f9505e:	or     %rax,%r14
 1f95061:	mov    0x70(%rsp),%rax
 1f95066:	blsr   %r15,%r15
 1f9506b:	jne    1f9504b <node_contexts_window_loop+0x120b>
 1f9506d:	jmp    1f95bbc <node_contexts_window_loop+0x1d7c>
 1f95072:	mov    0x68(%rsp),%rdx
 1f95077:	mov    0x50(%rsp),%rax
 1f9507c:	lea    (%r11,%r13,1),%ecx
 1f95080:	vmovdqa64 %zmm5,0x1c0(%rsp)
 1f95088:	vmovdqa64 %zmm2,0x340(%rsp)
 1f95090:	kmovq  %k7,0x38(%rsp)
 1f95097:	vmovdqa64 %zmm24,0x380(%rsp)
 1f9509f:	vmovdqa64 %zmm23,0x3c0(%rsp)
 1f950a7:	vmovdqa64 %zmm22,0x400(%rsp)
 1f950af:	vmovdqa64 %zmm21,0x440(%rsp)
 1f950b7:	vmovdqa64 %zmm20,0x480(%rsp)
 1f950bf:	vmovdqa64 %zmm19,0x4c0(%rsp)
 1f950c7:	vmovdqa64 %zmm18,0x500(%rsp)
 1f950cf:	vmovdqa64 %zmm17,0x200(%rsp)
 1f950d7:	vmovdqa64 %zmm16,0x240(%rsp)
 1f950df:	vmovdqa64 %zmm15,0x280(%rsp)
 1f950e7:	vmovdqa64 %zmm14,0x2c0(%rsp)
 1f950ef:	vmovdqa64 %zmm13,0x300(%rsp)
 1f950f7:	vmovdqa64 %zmm12,0x180(%rsp)
 1f950ff:	mov    %rdi,0x8(%rsp)
 1f95104:	movzwl 0x6b554(%rdx,%rcx,2),%edx
 1f9510c:	mov    0x2c0(%rax),%rax
 1f95113:	sub    %edx,%ecx
 1f95115:	shl    $0x6,%rcx
 1f95119:	mov    (%rax,%rcx,1),%esi
 1f9511c:	vzeroupper
 1f9511f:	call   1f35e90 <type_object_qualifiers_slow>
 1f95124:	and    $0xffffff,%eax
 1f95129:	lea    -0x110(%rax),%ecx
 1f9512f:	cmp    $0x2,%ecx
 1f95132:	ja     1f9514a <node_contexts_window_loop+0x130a>
 1f95134:	lea    -0x1ac54c6(%rip),%rdx        # 4cfc75 <check_lower_segment_override.segments>
 1f9513b:	xor    %ecx,%ecx
 1f9513d:	testb  $0x3,-0x110(%rax,%rdx,1)
 1f95145:	setne  %cl
 1f95148:	jmp    1f9514c <node_contexts_window_loop+0x130c>
 1f9514a:	xor    %ecx,%ecx
 1f9514c:	vbroadcasti32x4 -0x19cd1f6(%rip),%zmm8        # 5c7f60 <.LCPI44_39>
 1f95156:	vmovdqa64 0x640(%rsp),%zmm9
 1f9515e:	vmovdqa64 0x600(%rsp),%zmm11
 1f95166:	vmovdqa64 0x180(%rsp),%zmm12
 1f9516e:	vmovdqa64 0x300(%rsp),%zmm13
 1f95176:	vmovdqa64 0x2c0(%rsp),%zmm14
 1f9517e:	vmovdqa64 0x5c0(%rsp),%zmm10
 1f95186:	vmovdqa64 0x280(%rsp),%zmm15
 1f9518e:	vmovdqa64 0x240(%rsp),%zmm16
 1f95196:	vmovdqa64 0x200(%rsp),%zmm17
 1f9519e:	vmovdqa64 0x500(%rsp),%zmm18
 1f951a6:	vmovdqa64 0x4c0(%rsp),%zmm19
 1f951ae:	vmovdqa64 0x480(%rsp),%zmm20
 1f951b6:	vmovdqa64 0x440(%rsp),%zmm21
 1f951be:	vmovdqa64 0x400(%rsp),%zmm22
 1f951c6:	vmovdqa64 0x3c0(%rsp),%zmm23
 1f951ce:	vmovdqa64 0x380(%rsp),%zmm24
 1f951d6:	vmovdqa64 0x340(%rsp),%zmm2
 1f951de:	vmovdqa64 0x1c0(%rsp),%zmm5
 1f951e6:	mov    0x10(%rsp),%r11
 1f951eb:	kmovq  0x38(%rsp),%k7
 1f951f2:	mov    0x8(%rsp),%rdi
 1f951f7:	jmp    1f95059 <node_contexts_window_loop+0x1219>
 1f951fc:	nopl   0x0(%rax)
 1f95200:	mov    0x10(%rsp),%r9
 1f95205:	xor    %r10d,%r10d
 1f95208:	vbroadcasti32x4 -0x19cd282(%rip),%zmm1        # 5c7f90 <.LCPI44_43>
 1f95212:	vpcmpeqb -0x1ade0dc(%rip),%zmm10,%k1{%k1}        # 4b7140 <abi_test_hex.digits+0xbdc0>
 1f9521c:	vpcmpeqb -0x1adde66(%rip),%zmm10,%k0        # 4b73c0 <abi_test_hex.digits+0xc040>
 1f95226:	mov    0x48(%rsp),%rax
 1f9522b:	mov    0x580(%rsp),%rcx
 1f95233:	vpsllw $0x7,%zmm16,%zmm0
 1f9523a:	mov    0x20(%rsp),%r11
 1f9523f:	and    %rdx,0x30(%rsp)
 1f95244:	and    0x280(%rsp),%rax
 1f9524c:	and    0xd0(%rsp),%rcx
 1f95254:	vpmovb2m %zmm0,%k4
 1f9525a:	andn   %r15,%r11,%r14
 1f9525f:	mov    0x40(%rsp),%r11
 1f95264:	mov    %rax,0x48(%rsp)
 1f95269:	mov    0x60(%rsp),%rax
 1f9526e:	mov    %rcx,0x580(%rsp)
 1f95276:	and    0xa8(%rsp),%r11
 1f9527e:	vptestmb %zmm1,%zmm18,%k3
 1f95284:	kmovq  %k1,%rdi
 1f95289:	kmovq  0xb8(%rsp),%k1
 1f95293:	vpcmpeqb -0x1addddd(%rip),%zmm10,%k1{%k1}        # 4b74c0 <abi_test_hex.digits+0xc140>
 1f9529d:	kmovq  %k3,%rbx
 1f952a2:	vpcmpltub -0x1ade06d(%rip),%zmm15,%k3        # 4b7240 <abi_test_hex.digits+0xbec0>
 1f952ad:	andn   %rsi,%rbx,%r8
 1f952b2:	and    %rbx,%rsi
 1f952b5:	mov    %rax,%rbx
 1f952b8:	mov    %r8,0xd0(%rsp)
 1f952c0:	mov    0x1c0(%rsp),%r8
 1f952c8:	and    %rax,0x8(%rsp)
 1f952cd:	and    %rax,%rdi
 1f952d0:	and    %rax,0xa0(%rsp)
 1f952d8:	not    %rbx
 1f952db:	kmovq  %k1,%rcx
 1f952e0:	vpcmpeqb -0x1addeaa(%rip),%zmm10,%k1        # 4b7440 <abi_test_hex.digits+0xc0c0>
 1f952ea:	and    %r8,%r11
 1f952ed:	and    %r8,0x180(%rsp)
 1f952f5:	korq   %k4,%k3,%k3
 1f952fa:	vptestmb -0x1ade204(%rip),%zmm11,%k1{%k1}        # 4b7100 <abi_test_hex.digits+0xbd80>
 1f95304:	and    %rax,%rcx
 1f95307:	mov    %r11,%r8
 1f9530a:	mov    0x200(%rsp),%r11
 1f95312:	vpcmpeqb %zmm8,%zmm10,%k3{%k3}
 1f95318:	korq   %k3,%k0,%k3
 1f9531d:	kmovq  0x340(%rsp),%k0
 1f95327:	kmovq  %k3,%rdx
 1f9532c:	and    %rax,%rdx
 1f9532f:	or     %r11,0x98(%rsp)
 1f95337:	mov    %r9,%r11
 1f9533a:	mov    0x50(%rsp),%r9
 1f9533f:	kandq  %k0,%k2,%k0
 1f95344:	kmovq  %k0,%r13
 1f95349:	kmovq  %k1,%r15
 1f9534e:	kmovq  0x130(%rsp),%k1
 1f95358:	vptestmb %zmm1,%zmm11,%k0
 1f9535e:	and    %rax,%r13
 1f95361:	mov    0x120(%rsp),%rax
 1f95369:	vmovdqu8 -0x1ade373(%rip),%zmm0{%k1}{z}        # 4b7000 <abi_test_hex.digits+0xbc80>
 1f95373:	or     %rax,0x28(%rsp)
 1f95378:	andn   %r15,%rax,%rax
 1f9537d:	andn   0x680(%rsp),%r12,%r15
 1f95387:	andn   0x70(%rsp),%r15,%r15
 1f9538e:	mov    %rax,0xb8(%rsp)
 1f95396:	kmovq  %k0,%rax
 1f9539b:	mov    %rax,0x20(%rsp)
 1f953a0:	mov    %r15,0x60(%rsp)
 1f953a5:	mov    0x240(%rsp),%r15
 1f953ad:	and    %rax,%r15
 1f953b0:	or     %r10,%r8
 1f953b3:	mov    0xbc0(%r9),%r10
 1f953ba:	mov    %r8,0x40(%rsp)
 1f953bf:	vmovdqu64 %zmm0,(%r10,%r11,1)
 1f953c6:	mov    %r8,%r10
 1f953c9:	je     1f953ea <node_contexts_window_loop+0x15aa>
 1f953cb:	nopl   0x0(%rax,%rax,1)
 1f953d0:	xor    %eax,%eax
 1f953d2:	tzcnt  %r10,%rax
 1f953d7:	add    0xbc0(%r9),%rax
 1f953de:	blsr   %r10,%r10
 1f953e3:	movb   $0x4,(%r11,%rax,1)
 1f953e8:	jne    1f953d0 <node_contexts_window_loop+0x1590>
 1f953ea:	mov    0x8(%rsp),%rax
 1f953ef:	or     %rbx,0x28(%rsp)
 1f953f4:	mov    0x580(%rsp),%rbx
 1f953fc:	mov    0x180(%rsp),%r8
 1f95404:	movabs $0x7fffffffffffffff,%r10
 1f9540e:	vmovdqa64 0x700(%rsp),%zmm1
 1f95416:	vbroadcasti32x4 -0x19cd480(%rip),%zmm2        # 5c7fa0 <.LCPI44_44>
 1f95420:	kmovq  0x150(%rsp),%k7
 1f9542a:	kmovq  0x100(%rsp),%k3
 1f95434:	vptestmb %zmm17,%zmm17,%k1
 1f9543a:	or     0x128(%rsp),%rax
 1f95442:	inc    %r10
 1f95445:	vmovdqu8 -0x1ade44f(%rip),%zmm0{%k1}{z}        # 4b7000 <abi_test_hex.digits+0xbc80>
 1f9544f:	and    %r10,0xc0(%rsp)
 1f95457:	mov    %r14,%r10
 1f9545a:	or     %rcx,%r10
 1f9545d:	or     %r13,%rcx
 1f95460:	or     %rsi,%rcx
 1f95463:	or     %r15,%rbx
 1f95466:	and    %r8,0x30(%rsp)
 1f9546b:	mov    0xd0(%rsp),%r8
 1f95473:	mov    %rax,0x8(%rsp)
 1f95478:	mov    0x540(%rsp),%rax
 1f95480:	or     %rdi,%rbx
 1f95483:	or     %r14,%rdi
 1f95486:	mov    %rdi,%r15
 1f95489:	or     0x240(%rsp),%rdi
 1f95491:	or     %r13,%r15
 1f95494:	vpermt2b %zmm13,%zmm14,%zmm1
 1f9549a:	or     %r8,%r10
 1f9549d:	or     %rax,%rdx
 1f954a0:	or     %rbx,%r10
 1f954a3:	mov    %rdx,%rbx
 1f954a6:	or     %r8,%rdx
 1f954a9:	or     %rsi,%rbx
 1f954ac:	or     %rdi,%rdx
 1f954af:	mov    0xa0(%rsp),%rdi
 1f954b7:	or     %r15,%rbx
 1f954ba:	vpcmpeqb -0x1ade484(%rip),%zmm1,%k0{%k7}        # 4b7040 <abi_test_hex.digits+0xbcc0>
 1f954c4:	or     %rsi,%rdx
 1f954c7:	mov    0x60(%rsp),%rsi
 1f954cc:	or     %r12,%rdx
 1f954cf:	kmovq  %rdx,%k5
 1f954d4:	or     %r14,%rdi
 1f954d7:	or     %r8,%rdi
 1f954da:	or     %rdi,%rcx
 1f954dd:	mov    0x90(%rsp),%rdi
 1f954e5:	or     %r12,%rcx
 1f954e8:	kmovq  %k0,%rdx
 1f954ed:	or     %rdi,%r10
 1f954f0:	or     %rdi,%rbx
 1f954f3:	or     %rdi,%rcx
 1f954f6:	mov    0x280(%rsp),%rdi
 1f954fe:	kmovq  %r10,%k6
 1f95503:	kmovq  %rbx,%k2
 1f95508:	kmovq  %rcx,%k4
 1f9550d:	mov    0xb8(%rsp),%rcx
 1f95515:	vmovdqu8 -0x1ade51f(%rip),%zmm3{%k6}{z}        # 4b7000 <abi_test_hex.digits+0xbc80>
 1f9551f:	or     %rdx,%rdi
 1f95522:	mov    0x48(%rsp),%rdx
 1f95527:	kmovq  %rcx,%k1
 1f9552c:	kmovq  %k3,%rcx
 1f95531:	not    %rdi
 1f95534:	andn   %rsi,%rcx,%rcx
 1f95539:	kmovq  %rcx,%k3
 1f9553e:	mov    0x680(%rsp),%rcx
 1f95546:	vporq  %zmm2,%zmm3,%zmm1
 1f9554c:	vmovdqu8 %zmm1,%zmm3{%k5}
 1f95552:	vporq  %zmm8,%zmm3,%zmm1
 1f95558:	vmovdqu8 %zmm1,%zmm3{%k2}
 1f9555e:	vpord  -0x19c45ac(%rip){1to16},%zmm3,%zmm1        # 5d0fbc <.LCPI44_59>
 1f95568:	and    %rsi,%rcx
 1f9556b:	kmovq  %rcx,%k6
 1f95570:	mov    0x40(%rsp),%rcx
 1f95575:	kmovq  %rcx,%k5
 1f9557a:	mov    0x200(%rsp),%rcx
 1f95582:	vmovdqu8 %zmm1,%zmm3{%k4}
 1f95588:	vmovdqu8 -0x1addf12(%rip),%zmm3{%k1}        # 4b7680 <abi_test_hex.digits+0xc300>
 1f95592:	kmovq  %rsi,%k1
 1f95597:	vbroadcasti32x4 -0x19cd531(%rip),%zmm1        # 5c8070 <.LCPI44_60>
 1f955a1:	kmovq  %rcx,%k2
 1f955a6:	or     %rax,%rcx
 1f955a9:	kmovq  %rcx,%k4
 1f955ae:	mov    0x98(%rsp),%rcx
 1f955b6:	vmovdqu8 -0x1addf00(%rip),%zmm3{%k1}        # 4b76c0 <abi_test_hex.digits+0xc340>
 1f955c0:	kmovq  %rdx,%k1
 1f955c5:	vpblendmb -0x1ade40f(%rip),%zmm1,%zmm1{%k5}        # 4b71c0 <abi_test_hex.digits+0xbe40>
 1f955cf:	mov    0xd8(%rsp),%rax
 1f955d7:	mov    0x88(%rsp),%rsi
 1f955df:	and    %rsi,%rdx
 1f955e2:	mov    %rdx,0x40(%rsp)
 1f955e7:	vmovdqu8 -0x1addef1(%rip),%zmm3{%k1}        # 4b7700 <abi_test_hex.digits+0xc380>
 1f955f1:	kmovq  %rcx,%k1
 1f955f6:	vmovdqu8 -0x1adde80(%rip),%zmm1{%k2}        # 4b7780 <abi_test_hex.digits+0xc400>
 1f95600:	and    %rsi,%rcx
 1f95603:	mov    %rcx,0x48(%rsp)
 1f95608:	vmovdqu8 -0x1ade692(%rip),%zmm3{%k1}        # 4b6f80 <abi_test_hex.digits+0xbc00>
 1f95612:	kmovq  0xf8(%rsp),%k1
 1f9561c:	vmovdqa64 %zmm3,%zmm4
 1f95622:	vpaddb %zmm8,%zmm3,%zmm4{%k3}
 1f95628:	vmovdqa64 %zmm3,0x180(%rsp)
 1f95630:	vpaddb %zmm2,%zmm4,%zmm4{%k6}
 1f95636:	vmovdqu8 %zmm1,%zmm4{%k4}
 1f9563c:	vpermi2b %zmm12,%zmm4,%zmm14{%k7}{z}
 1f95642:	vmovdqa64 %zmm4,0x680(%rsp)
 1f9564a:	vmovdqu8 0x780(%rsp),%zmm14{%k1}
 1f95652:	kmovq  %rdi,%k1
 1f95657:	mov    0xbb0(%r9),%rdi
 1f9565e:	vpaddw %zmm14,%zmm14,%zmm1
 1f95664:	vporq  %zmm0,%zmm1,%zmm0
 1f9566a:	vpermb 0x80(%rax),%zmm0,%zmm0
 1f95671:	vmovdqu64 %zmm3,(%rdi,%r11,1)
 1f95678:	mov    0xbb8(%r9),%rax
 1f9567f:	vmovdqu64 %zmm4,(%rax,%r11,1)
 1f95686:	mov    0xbc8(%r9),%rax
 1f9568d:	vmovdqa64 %zmm0,0x580(%rsp)
 1f95695:	vpandd -0x19c46df(%rip){1to16},%zmm0,%zmm0        # 5d0fc0 <.LCPI44_61>
 1f9569f:	vmovdqu8 %zmm0,%zmm0{%k1}{z}
 1f956a5:	vmovdqu64 %zmm0,(%rax,%r11,1)
 1f956ac:	test   %rcx,%rcx
 1f956af:	je     1f957f0 <node_contexts_window_loop+0x19b0>
 1f956b5:	mov    0xbc8(%r9),%r13
 1f956bc:	mov    0x2c0(%r9),%r15
 1f956c3:	mov    0x68(%rsp),%rsi
 1f956c8:	mov    0x10(%rsp),%r9
 1f956cd:	lea    -0x19b5dc4(%rip),%r8        # 5df910 <switch.table.tier1_burs_check_function.51217+0xda18>
 1f956d4:	mov    %rcx,%r14
 1f956d7:	xor    %r12d,%r12d
 1f956da:	jmp    1f95713 <node_contexts_window_loop+0x18d3>
 1f956dc:	nopl   0x0(%rax)
 1f956e0:	mov    $0x50,%ecx
 1f956e5:	movzwl 0x6b554(%rsi,%rdx,2),%edi
 1f956ed:	mov    $0x1,%eax
 1f956f2:	cmp    0x6d5d4(%rsi,%rdx,2),%di
 1f956fa:	jne    1f9578f <node_contexts_window_loop+0x194f>
 1f95700:	shlx   %rbx,%rax,%rax
 1f95705:	or     %rax,%r12
 1f95708:	blsr   %r14,%r14
 1f9570d:	je     1f957fd <node_contexts_window_loop+0x19bd>
 1f95713:	xor    %ebx,%ebx
 1f95715:	tzcnt  %r14,%rbx
 1f9571a:	mov    %r9d,%edx
 1f9571d:	or     %rbx,%rdx
 1f95720:	cmpb   $0x0,0x196ac(%rsi,%rdx,1)
 1f95728:	mov    %rdx,%rax
 1f9572b:	je     1f95737 <node_contexts_window_loop+0x18f7>
 1f9572d:	movzwl 0x6f654(%rsi,%rdx,2),%eax
 1f95735:	add    %edx,%eax
 1f95737:	movzbl 0x0(%r13,%rdx,1),%ecx
 1f9573d:	dec    %ecx
 1f9573f:	cmp    $0x3,%ecx
 1f95742:	ja     1f95788 <node_contexts_window_loop+0x1948>
 1f95744:	movslq (%r8,%rcx,4),%rcx
 1f95748:	shl    $0x6,%rax
 1f9574c:	add    %r15,%rax
 1f9574f:	add    %r8,%rcx
 1f95752:	jmp    *%rcx
 1f95754:	xor    %ecx,%ecx
 1f95756:	cmpb   $0x0,0x1a72c(%rsi,%rdx,1)
 1f9575e:	setne  %cl
 1f95761:	mov    0x20(%rax,%rcx,4),%ecx
 1f95765:	jmp    1f956e5 <node_contexts_window_loop+0x18a5>
 1f9576a:	nopw   0x0(%rax,%rax,1)
 1f95770:	mov    %rdx,%rax
 1f95773:	shl    $0x6,%rax
 1f95777:	mov    0x38(%r15,%rax,1),%ecx
 1f9577c:	jmp    1f956e5 <node_contexts_window_loop+0x18a5>
 1f95781:	mov    (%rax),%ecx
 1f95783:	jmp    1f956e5 <node_contexts_window_loop+0x18a5>
 1f95788:	xor    %ecx,%ecx
 1f9578a:	jmp    1f956e5 <node_contexts_window_loop+0x18a5>
 1f9578f:	mov    0x50(%rsp),%rdi
 1f95794:	vzeroupper
 1f95797:	call   1f96341 <node_contexts_sinks>
 1f9579c:	vmovdqa64 0x5c0(%rsp),%zmm10
 1f957a4:	vmovdqa64 0x600(%rsp),%zmm11
 1f957ac:	vmovdqa64 0x640(%rsp),%zmm9
 1f957b4:	vbroadcasti32x4 -0x19cd85e(%rip),%zmm8        # 5c7f60 <.LCPI44_39>
 1f957be:	mov    0x10(%rsp),%r9
 1f957c3:	mov    0x68(%rsp),%rsi
 1f957c8:	lea    -0x19b5ebf(%rip),%r8        # 5df910 <switch.table.tier1_burs_check_function.51217+0xda18>
 1f957cf:	movzbl %al,%eax
 1f957d2:	shlx   %rbx,%rax,%rax
 1f957d7:	or     %rax,%r12
 1f957da:	blsr   %r14,%r14
 1f957df:	jne    1f95713 <node_contexts_window_loop+0x18d3>
 1f957e5:	jmp    1f957fd <node_contexts_window_loop+0x19bd>
 1f957e7:	nopw   0x0(%rax,%rax,1)
 1f957f0:	mov    0x68(%rsp),%rsi
 1f957f5:	mov    0x10(%rsp),%r9
 1f957fa:	xor    %r12d,%r12d
 1f957fd:	mov    0x300(%rsp),%r8
 1f95805:	mov    0xa8(%rsp),%r14
 1f9580d:	mov    0x20(%rsp),%rdx
 1f95812:	kmovq  0x500(%rsp),%k0
 1f9581c:	kmovq  0x4c0(%rsp),%k1
 1f95826:	mov    0xc0(%rsp),%r10
 1f9582e:	mov    0x78(%rsp),%r11
 1f95833:	mov    0x380(%rsp),%r13
 1f9583b:	mov    0x400(%rsp),%r15
 1f95843:	mov    0x40(%rsp),%rdi
 1f95848:	mov    0xec(%rsp),%ebx
 1f9584f:	and    0x30(%rsp),%rdx
 1f95854:	and    0x480(%rsp),%r10
 1f9585c:	xor    0x2c0(%rsp),%r11
 1f95864:	and    0xb0(%rsp),%r13
 1f9586c:	and    %r8,0x8(%rsp)
 1f95871:	and    %r14,0x28(%rsp)
 1f95876:	kmovq  %k1,%rcx
 1f9587b:	kmovq  %k0,%rax
 1f95880:	and    %rax,%r15
 1f95883:	mov    %rdx,0x20(%rsp)
 1f95888:	and    %rdi,%rcx
 1f9588b:	mov    %ebx,%edx
 1f9588d:	mov    $0xffffffffffffffff,%rax
 1f95894:	sub    %r9d,%edx
 1f95897:	jbe    1f958b4 <node_contexts_window_loop+0x1a74>
 1f95899:	lea    0x40(%r9),%eax
 1f9589d:	cmp    %eax,%ebx
 1f9589f:	mov    $0xffffffffffffffff,%rax
 1f958a6:	shlx   %rdx,%rax,%rax
 1f958ab:	mov    $0x0,%edx
 1f958b0:	cmovae %rdx,%rax
 1f958b4:	vmovdqa64 0x940(%rsp),%zmm5
 1f958bc:	vpcmpeqb -0x1ade606(%rip),%zmm10,%k0        # 4b72c0 <abi_test_hex.digits+0xbf40>
 1f958c6:	kmovq  0x140(%rsp),%k1
 1f958d0:	vpandd -0x19c4916(%rip){1to16},%zmm11,%zmm4        # 5d0fc4 <.LCPI44_62>
 1f958da:	vpcmpeqb -0x1ade4a4(%rip),%zmm10,%k2        # 4b7440 <abi_test_hex.digits+0xc0c0>
 1f958e4:	vpcmpeqb %zmm8,%zmm10,%k3
 1f958ea:	mov    0x440(%rsp),%r14
 1f958f2:	vmovq  %rcx,%xmm1
 1f958f7:	mov    0x60(%rsp),%rdx
 1f958fc:	mov    0x138(%rsp),%rcx
 1f95904:	or     0x8(%rsp),%r11
 1f95909:	vpmovb2m %zmm9,%k4
 1f9590f:	vmovq  %rdi,%xmm0
 1f95914:	xor    0x38(%rsp),%r14
 1f95919:	vmovq  %rcx,%xmm3
 1f9591e:	vmovq  %rdx,%xmm2
 1f95923:	andn   %rcx,%rdx,%rcx
 1f95928:	andn   0x30(%rsp),%r8,%rdx
 1f9592f:	or     %r14,%r11
 1f95932:	or     0x28(%rsp),%r11
 1f95937:	mov    $0xffffffffffffffff,%r14
 1f9593e:	vpcmpeqb -0x1ade9c8(%rip),%zmm5,%k3{%k3}        # 4b6f80 <abi_test_hex.digits+0xbc00>
 1f95948:	korq   %k1,%k0,%k0
 1f9594d:	kmovq  0x148(%rsp),%k1
 1f95957:	vptestnmb %zmm4,%zmm4,%k2{%k2}
 1f9595d:	vmovdqa64 0x580(%rsp),%zmm4
 1f95965:	or     %r10,%r11
 1f95968:	popcnt 0x48(%rsp),%r10
 1f9596f:	or     %r15,%r11
 1f95972:	mov    $0x0,%r15d
 1f95978:	kandq  %k1,%k0,%k0
 1f9597d:	vptestnmb %zmm10,%zmm10,%k1
 1f95983:	or     %r13,%r11
 1f95986:	mov    %r9,%r13
 1f95989:	or     %rcx,%r11
 1f9598c:	or     0x3c0(%rsp),%r11
 1f95994:	movabs $0x7fffffffffffffff,%rcx
 1f9599e:	korq   %k3,%k1,%k1
 1f959a3:	mov    %r10,0x10(%rsp)
 1f959a8:	mov    0x88(%rsp),%r10
 1f959b0:	korq   %k4,%k1,%k1
 1f959b5:	korq   %k0,%k1,%k1
 1f959ba:	korq   %k2,%k1,%k1
 1f959bf:	kmovq  %k1,%rdi
 1f959c4:	vpmovb2m %zmm4,%k1
 1f959ca:	or     %rdx,%rdi
 1f959cd:	popcnt 0x540(%rsp),%rdx
 1f959d7:	or     %rdi,%r11
 1f959da:	kmovq  %k1,%rdi
 1f959df:	and    %r10,%r11
 1f959e2:	mov    %r11,0x78(%rsp)
 1f959e7:	mov    %rdx,0x8(%rsp)
 1f959ec:	mov    0x20(%rsp),%rdx
 1f959f1:	andn   %rdi,%rdx,%rdi
 1f959f6:	popcnt %r12,%rdx
 1f959fb:	or     %rdi,%r8
 1f959fe:	mov    %rdx,0x20(%rsp)
 1f95a03:	andn   %r10,%r8,%r8
 1f95a08:	je     1f93f50 <node_contexts_window_loop+0x110>
 1f95a0e:	xchg   %ax,%ax
 1f95a10:	xor    %r9d,%r9d
 1f95a13:	tzcnt  %r8,%r9
 1f95a18:	mov    %ebx,%edx
 1f95a1a:	lea    0x0(%r13,%r9,1),%r10d
 1f95a1f:	sub    0x651b8(%rsi,%r10,4),%r10d
 1f95a27:	mov    0x68(%rsp),%rsi
 1f95a2c:	lea    0x1(%r10),%r10d
 1f95a30:	cmovb  %r15d,%r10d
 1f95a34:	mov    %r10d,%r11d
 1f95a37:	sub    %r13d,%r11d
 1f95a3a:	cmp    %ebx,%r10d
 1f95a3d:	cmovb  %r10d,%edx
 1f95a41:	cmp    %r13d,%r10d
 1f95a44:	shlx   %r11,%r14,%r11
 1f95a49:	cmovbe %rcx,%r11
 1f95a4d:	cmovb  %edx,%ebx
 1f95a50:	bzhi   %r9,%r11,%r9
 1f95a55:	or     %r9,%rax
 1f95a58:	blsr   %r8,%r8
 1f95a5d:	jne    1f95a10 <node_contexts_window_loop+0x1bd0>
 1f95a5f:	jmp    1f93f50 <node_contexts_window_loop+0x110>
 1f95a64:	cmpq   $0x0,0x30(%rsp)
 1f95a6a:	mov    0x10(%rsp),%r12
 1f95a6f:	je     1f95ad2 <node_contexts_window_loop+0x1c92>
 1f95a71:	mov    0xbb8(%rdi),%r8
 1f95a78:	mov    0x30(%rsp),%r9
 1f95a7d:	mov    %r8,0x8(%rsp)
 1f95a82:	xor    %r10d,%r10d
 1f95a85:	tzcnt  %r9,%r10
 1f95a8a:	mov    0xd8(%rsp),%r8
 1f95a92:	lea    (%r12,%r10,1),%r11d
 1f95a96:	movzwl 0x6f654(%rsi,%r11,2),%ebx
 1f95a9f:	add    %r11d,%ebx
 1f95aa2:	movzbl 0x2c(%rsi,%rbx,1),%r11d
 1f95aa8:	and    $0x7f,%r11d
 1f95aac:	blsr   %r9,%r9
 1f95ab1:	movzbl (%r8,%r11,1),%r11d
 1f95ab6:	mov    0x8(%rsp),%r8
 1f95abb:	mov    %r11b,0x740(%rsp,%r10,1)
 1f95ac3:	movzbl (%r8,%rbx,1),%r11d
 1f95ac8:	mov    %r11b,0x780(%rsp,%r10,1)
 1f95ad0:	jne    1f95a82 <node_contexts_window_loop+0x1c42>
 1f95ad2:	kmovq  %k2,%r8
 1f95ad7:	mov    %r8,%r9
 1f95ada:	test   %r8,%r8
 1f95add:	je     1f95b51 <node_contexts_window_loop+0x1d11>
 1f95adf:	xor    %r10d,%r10d
 1f95ae2:	tzcnt  %r9,%r10
 1f95ae7:	lea    (%r12,%r10,1),%r11d
 1f95aeb:	movzwl 0x6b554(%rsi,%r11,2),%ebx
 1f95af4:	sub    %ebx,%r11d
 1f95af7:	movzbl 0x2c(%rsi,%r11,1),%ebx
 1f95afd:	and    $0x7f,%bl
 1f95b00:	blsr   %r9,%r9
 1f95b05:	mov    %bl,0x7c0(%rsp,%r10,1)
 1f95b0d:	movzbl (%rax,%r11,1),%ebx
 1f95b12:	mov    %bl,0x800(%rsp,%r10,1)
 1f95b1a:	movzbl (%rcx,%r11,1),%ebx
 1f95b1f:	mov    %bl,0x840(%rsp,%r10,1)
 1f95b27:	movzbl (%rdx,%r11,1),%ebx
 1f95b2c:	mov    %bl,0x880(%rsp,%r10,1)
 1f95b34:	movzbl (%r14,%r11,1),%ebx
 1f95b39:	mov    %bl,0x8c0(%rsp,%r10,1)
 1f95b41:	movzbl 0x0(%r13,%r11,1),%r11d
 1f95b47:	mov    %r11b,0x900(%rsp,%r10,1)
 1f95b4f:	jne    1f95adf <node_contexts_window_loop+0x1c9f>
 1f95b51:	kmovq  0xf8(%rsp),%k3
 1f95b5b:	vmovdqu8 0x7c0(%rsp),%zmm19{%k2}
 1f95b63:	vmovdqu8 0x800(%rsp),%zmm25{%k2}
 1f95b6b:	vmovdqu8 0x840(%rsp),%zmm20{%k2}
 1f95b73:	vmovdqu8 0x880(%rsp),%zmm3{%k2}
 1f95b7b:	vmovdqu8 0x8c0(%rsp),%zmm18{%k2}
 1f95b83:	vmovdqu8 0x900(%rsp),%zmm21{%k2}
 1f95b8b:	popcnt 0x30(%rsp),%rax
 1f95b92:	or     %r8,0x20(%rsp)
 1f95b97:	popcnt %r8,%rcx
 1f95b9c:	add    0xc8(%rsp),%rax
 1f95ba4:	vmovdqu8 0x740(%rsp),%zmm22{%k3}
 1f95bac:	add    %rcx,%rax
 1f95baf:	mov    %rax,0xc8(%rsp)
 1f95bb7:	jmp    1f94339 <node_contexts_window_loop+0x4f9>
 1f95bbc:	andn   %rax,%r14,%rax
 1f95bc1:	mov    0x50(%rsp),%r13
 1f95bc6:	mov    0x20(%rsp),%rdi
 1f95bcb:	mov    %rax,0x70(%rsp)
 1f95bd0:	mov    0x80(%rsp),%rax
 1f95bd8:	jmp    1f94af8 <node_contexts_window_loop+0xcb8>
 1f95bdd:	mov    %rdx,%rdi
 1f95be0:	movq   $0x0,0x70(%rsp)
 1f95be9:	jmp    1f94af8 <node_contexts_window_loop+0xcb8>
 1f95bee:	vmovq  0xc8(%rsp),%xmm0
 1f95bf7:	mov    0x118(%rsp),%rcx
 1f95bff:	mov    0x58(%rsp),%rdx
 1f95c04:	mov    0xf0(%rsp),%rsi
 1f95c0c:	vmovq  %r15,%xmm1
 1f95c11:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f95c15:	vmovq  %rsi,%xmm1
 1f95c1a:	vmovq  %rdx,%xmm2
 1f95c1f:	vpunpcklqdq %xmm1,%xmm2,%xmm1
 1f95c23:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f95c29:	vmovq  %r10,%xmm1
 1f95c2e:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm0
 1f95c35:	vpaddq (%rcx),%zmm0,%zmm0
 1f95c3b:	vmovdqu64 %zmm0,(%rcx)
 1f95c41:	vmovq  %r8,%xmm0
 1f95c46:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f95c4a:	vpaddq 0x40(%rcx),%xmm0,%xmm0
 1f95c4f:	vmovdqu %xmm0,0x40(%rcx)
 1f95c54:	add    %rax,0x50(%rcx)
 1f95c58:	lea    -0x28(%rbp),%rsp
 1f95c5c:	pop    %rbx
 1f95c5d:	pop    %r12
 1f95c5f:	pop    %r13
 1f95c61:	pop    %r14
 1f95c63:	pop    %r15
 1f95c65:	pop    %rbp
 1f95c66:	vzeroupper
 1f95c69:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
