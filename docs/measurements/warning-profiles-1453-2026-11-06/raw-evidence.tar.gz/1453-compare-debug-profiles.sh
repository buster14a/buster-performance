#!/usr/bin/env bash
set -euo pipefail
workdir="$HOME/buster-fast-bench/1453-codex-20261106-perf"
sqlite="$HOME/buster-fast-bench/1296-codex-20261105/corpus/sqlite"
export EXCLUSIVE_OWNER=codex-1453 EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1453 LC_ALL=C
cd "$workdir/repo"
for entry in debugbase:a581e20b8cd202196d8f2dcfff22ce7a5e09e9b6 debugfinal:1f88c53a59885e3ddb2a32d966561e412ed021de; do
  version="${entry%%:*}"; sha="${entry#*:}"
  git cat-file -e "$sha^{commit}" || git fetch origin "$sha"
  if [[ ! -d "$workdir/$version" ]]; then git worktree add --detach "$workdir/$version" "$sha"; fi
  export EXCLUSIVE_TITLE="PR 1453 $version debug-info build"
  "$HOME/buster-fast-bench/exclusive.sh" env BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=1 "$workdir/$version/build.sh" --jobs 4 > "$workdir/$version-build.log" 2>&1
  sha256sum "$workdir/$version/build/compiler" > "$workdir/$version.sha256"
done
for version in debugbase debugfinal; do
  export EXCLUSIVE_TITLE="PR 1453 $version instruction profile"
  "$HOME/buster-fast-bench/exclusive.sh" taskset -c 2 perf record -q -e instructions:u -c 50000 -o "$workdir/$version-profile.data" -- "$workdir/$version/build/compiler" -fsyntax-only -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$sqlite" "$sqlite/sqlite3.c" > "$workdir/$version-profile.out" 2> "$workdir/$version-profile.err"
  perf report --stdio -i "$workdir/$version-profile.data" --sort symbol --percent-limit 0.3 > "$workdir/$version-report.txt"
done
printf 'Profiles complete\n'
