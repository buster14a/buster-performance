#!/usr/bin/env bash
set -euo pipefail
workdir="$HOME/buster-fast-bench/1453-codex-20261106-perf"
sqlite="$HOME/buster-fast-bench/1296-codex-20261105/corpus/sqlite"
export EXCLUSIVE_OWNER=codex-1453 EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1453 LC_ALL=C
cd "$workdir/repo"
git fetch "$workdir/candidate8.bundle" HEAD
git worktree add --detach "$workdir/candidate8" FETCH_HEAD
export EXCLUSIVE_TITLE='PR 1453 suppressed conversion formatting candidate build'
"$HOME/buster-fast-bench/exclusive.sh" env BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0 "$workdir/candidate8/build.sh" --jobs 4 > "$workdir/candidate8-build.log" 2>&1
sha256sum "$workdir/candidate8/build/compiler" > "$workdir/candidate8.sha256"
for round in 1 2 3; do
  cp "$workdir/candidate8/build/compiler" "$workdir/compiler"
  export EXCLUSIVE_TITLE="PR 1453 suppressed conversion formatting candidate sample $round"
  "$HOME/buster-fast-bench/exclusive.sh" taskset -c 2 perf stat -x, -e instructions:u,cycles:u -o "$workdir/candidate8-$round.perf" -- "$workdir/compiler" -fsyntax-only -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$sqlite" "$sqlite/sqlite3.c" > "$workdir/candidate8-$round.out" 2> "$workdir/candidate8-$round.err"
done
