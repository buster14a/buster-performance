#!/bin/bash
set -euo pipefail
cd "$HOME/buster-fast-bench/3211-active-refinement";root=$PWD;until [[ -f results/pages8/.built ]];do sleep 2;done
out=$root/oracle-pages8;mkdir -p "$out";source "$HOME/buster-fast-bench/2850-pp-parser-window/corpora.sh"
clang=$(sed -n 's/.*toolchain: clang \([^ ]*\) (.*/\1/p' "$root/results/pages8/build.log"|head -1)
for tag in base pages8;do defs=();[[ $tag != pages8 ]] || defs=(-DPAGES_CANDIDATE)
 "$root/lock.sh" taskset -c 2 "$clang" -std=gnu17 -O1 -g0 -march=znver5 -fwrapv -funsigned-char "${defs[@]}" -I"$root/trees/$tag/src" pp-pages-dump.c -o "$out/$tag-oracle" >"$out/$tag.build" 2>&1
done
cd "$root/trees/base"
main_arguments="-march=znver5 -Isrc -fwrapv -funsigned-char --predefines $HOME/buster-fast-bench/2850-pp-parser-window/oracle/predefines.h src/buster/compiler/main.c"
for c in sqlite features shell main lua musl;do
 if [[ $c == features ]];then eval "args=($sqlite_arguments)";args=(-DSQLITE_ENABLE_FTS5 -DSQLITE_ENABLE_FTS3 -DSQLITE_ENABLE_SESSION -DSQLITE_ENABLE_PREUPDATE_HOOK -DSQLITE_ENABLE_GEOPOLY -DSQLITE_ENABLE_DBSTAT_VTAB "${args[@]}");
 elif [[ $c == shell ]];then args=("-I$sqlite" "$sqlite/shell.c");
 else key=${c}_arguments;eval "args=(${!key})";fi
 opts=();files=();for v in "${args[@]}";do if [[ $v == *.c ]];then files+=("$v");else opts+=("$v");fi;done
 for mode in base plain fused;do
  cc=$out/pages8-oracle;ctl=1;fused=1;case $mode in base)cc=$out/base-oracle;ctl=0;fused=0;;plain)fused=0;;esac
  p=$out/$c-$mode;st=0
  "$root/lock.sh" bash -c 'p=$1;shift;exec taskset -c 2 "$@" >"$p.data" 2>"$p.log"' _ "$p" env BUSTER_TEST_ACTIVE_REFINEMENT="$ctl" BUSTER_TEST_FUSED_HINT_PAGES="$fused" "$cc" "${opts[@]}" -- "${files[@]}" > "$p.lock" 2>&1 || st=$?
  echo "$st">"$p.status";sha256sum "$p.data" >"$p.sha";wc -c "$p.data">"$p.bytes"
  d=0;cmp "$out/$c-base.data" "$p.data" >"$p.diff" || d=1
  echo "$c $mode $st $d">>"$out/status"
  if [[ $mode != base && $d == 0 ]];then rm "$p.data";fi
 done
 if ! grep -Eq "^$c .* [1-9][0-9]*$" "$out/status";then rm "$out/$c-base.data";fi
done;date -u +%FT%TZ >"$out/done"
