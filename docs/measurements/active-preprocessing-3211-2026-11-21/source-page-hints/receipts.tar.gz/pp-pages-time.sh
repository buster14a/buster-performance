#!/bin/bash
set -euo pipefail
cd "$HOME/buster-fast-bench/3211-active-refinement";root=$PWD
until [[ -f results/pages8/.built && -f check-pages8/results ]] && grep -qx 'sqlite E 0 0 0' check-pages8/results;do sleep 2;done
out=$root/timing-pages8;mkdir -p "$out";source ./corpora.sh;eval "sql=($sqlite_arguments)"
features=(-DSQLITE_ENABLE_FTS5 -DSQLITE_ENABLE_FTS3 -DSQLITE_ENABLE_SESSION -DSQLITE_ENABLE_PREUPDATE_HOOK -DSQLITE_ENABLE_GEOPOLY -DSQLITE_ENABLE_DBSTAT_VTAB)
exec 9>"$HOME/buster-fast-bench/2850-codex-step2/our-timing.lock"
for r in {0..5};do for c in sqlite features shell all-active;do
 case $c in sqlite)args=("${sql[@]}");;features)args=("${features[@]}" "${sql[@]}");;shell)args=("-I$sqlite" "$sqlite/shell.c");;all-active)args=("$root/fixtures/all-active.c");;esac
 case $r in 0)arms=(base cursor off old fused);;1)arms=(cursor fused old off base);;2)arms=(off old fused base cursor);;3)arms=(old off cursor base fused);;4)arms=(fused base cursor off old);;5)arms=(base fused old off cursor);;esac
 flock -x 9
 for pos in {0..4};do arm=${arms[$pos]};label=pages8;active=1;pages=0;case $arm in base)label=base;active=0;;cursor)label=cursor7;;off)active=0;;fused)pages=1;;esac
 cc=$root/results/$label/compiler;p=$out/$r-$c-$pos-$arm
 "$root/lock.sh" bash -c 'p=$1;shift;exec taskset -c 2 perf stat -x ";" --no-big-num -e cycles:u,cycles:k,instructions:u,instructions:k,minor-faults,cpu-migrations -o "$p.perf" -- "$@" >"$p.out" 2>"$p.stages"' _ "$p" env BUSTER_TEST_ACTIVE_REFINEMENT="$active" BUSTER_TEST_FUSED_HINT_PAGES="$pages" BUSTER_HUGE_PAGES=1 "$cc" --lanes 1 --time-stages -c -o "$out/current.o" "${args[@]}" >"$p.stages.lock" 2>&1
 "$root/lock.sh" taskset -c 2 env -u BUSTER_HUGE_PAGES BUSTER_TEST_ACTIVE_REFINEMENT="$active" BUSTER_TEST_FUSED_HINT_PAGES="$pages" "$root/results/base/compiler" time-runs --runs 2 --warmups 1 --executable "$cc" --list --lanes 1 -c -o "$out/current.o" "${args[@]}" >"$p.wall" 2>"$p.wall.err"
 sha256sum "$out/current.o" |cut -d' ' -f1 >"$p.sha";cmp "$p.sha" "$root/check-cursor7/$c-object-0.object-sha"
 echo "$r $c $pos $arm" >>"$out/status"
 done;flock -u 9
done;done;rm -f "$out/current.o";date -u +%FT%TZ >"$out/done"
