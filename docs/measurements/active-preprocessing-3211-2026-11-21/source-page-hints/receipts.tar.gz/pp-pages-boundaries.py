from pathlib import Path
import sys
d=Path(sys.argv[1]);d.mkdir(parents=True,exist_ok=True)
for name,sep in [('lf',b'\n'),('crlf',b'\r\n'),('cr',b'\r')]:
 for off in (-1,0,1):
  for fine in (0,1):
   c=bytearray(b'#ifdef OPTIONAL\n'.replace(b'\n',sep))
   for k in range(1,79):
    desired=4096*k+off
    if k==40:c.extend(b'int after_gate;'+sep+b'#endif'+sep)
    c.extend((b'/*x*/'+sep)*((desired-len(c))//(5+len(sep))))
    c.extend(b' '*(desired-len(c)));c.extend(sep)
   c.extend(b'int final_value;'+sep)
   target=4096*81+(1 if fine else 0);c.extend(b' '*(target-len(c)))
   (d/f'{name}-{off:+d}-{fine}.c').write_bytes(c)
