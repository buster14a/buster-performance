#!/bin/bash
set -euo pipefail
cd "$HOME/buster-fast-bench/3211-active-refinement";root=$PWD;until [[ -x oracle-pages8/pages8-oracle && -x oracle-pages8/base-oracle ]];do sleep 2;done
out=$root/line-edges-pages8;mkdir -p "$out";python3 pp-pages-boundaries.py "$out/files"
for condition in excluded active;do flags=();[[ $condition != active ]] || flags=(-DOPTIONAL=1)
 for mode in parent old fused;do
  cc=$root/oracle-pages8/pages8-oracle;ctl=1;page=0;case $mode in parent)cc=$root/oracle-pages8/base-oracle;ctl=0;;fused)page=1;;esac
  p=$out/$condition-$mode
  "$root/lock.sh" bash -c 'p=$1;shift;exec taskset -c 2 "$@" >"$p.data" 2>"$p.log"' _ "$p" env BUSTER_TEST_ACTIVE_REFINEMENT="$ctl" BUSTER_TEST_FUSED_HINT_PAGES="$page" "$cc" "${flags[@]}" -- "$out"/files/*.c >"$p.lock" 2>&1
  cmp "$out/$condition-parent.data" "$p.data";sha256sum "$p.data">"$p.sha";wc -c "$p.data">"$p.bytes"
  test "$(grep -c '^page-witness ' "$p.log")" = 18
  if [[ $mode == fused ]];then test "$(grep -c ' fused=1 ' "$p.log")" = 6;fi
  [[ $mode == parent ]] || rm "$p.data";echo "$condition $mode">>"$out/status"
 done
 rm "$out/$condition-parent.data"
done;date -u +%FT%TZ >"$out/done"
