#!/bin/bash
set -euo pipefail
cd "$HOME/buster-fast-bench/3211-active-refinement";root=$PWD;source "$HOME/buster-fast-bench/2850-pp-parser-window/corpora.sh"
until [[ -f results/pages8/.built ]];do sleep 2;done
out=$root/objects-pages8;mkdir -p "$out";tmp=$(mktemp -d /dev/shm/buster2850-line-pages.XXXXXXXX);trap 'rm -rf -- "$tmp"' EXIT
base=$root/trees/base;main_arguments="-march=znver5 -I$base/src -fwrapv -funsigned-char --predefines $HOME/buster-fast-bench/2850-pp-parser-window/oracle/predefines.h $base/src/buster/compiler/main.c"
for c in main sqlite lua musl;do key=${c}_arguments;eval "args=(${!key})";size=1
 case $c in main|sqlite)args+=(-o "$tmp/unit.o");;lua)size=34;;musl)size=1336;;esac
 for warning in default extra;do flags=();[[ $warning != extra ]] || flags=(-Wall -Wextra)
  for arm in parent fused;do
   cc=$root/results/base/compiler;active=0;[[ $arm != fused ]] || { cc=$root/results/pages8/compiler;active=1; };p=$out/$c-$warning-$arm
   (cd "$tmp";rm -f -- ./*.o
    "$root/lock.sh" bash -c 'p=$1;shift;exec taskset -c 2 "$@" >"$p.out" 2>"$p.err"' _ "$p" env BUSTER_TEST_ACTIVE_REFINEMENT="$active" BUSTER_TEST_FUSED_HINT_PAGES=1 "$cc" --lanes 1 "${flags[@]}" -c "${args[@]}" >"$p.lock" 2>&1
    python3 "$HOME/buster-fast-bench/2850-codex-step2/full-chain-manifest.py" "$p.objects" "$size")
   for ext in out err objects;do cmp "$out/$c-$warning-parent.$ext" "$p.$ext";done
   echo "$c $warning $arm $size">>"$out/status"
  done
 done
done;date -u +%FT%TZ>"$out/done"
