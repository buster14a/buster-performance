[[vendor::ignored((return 3;), [return 4;])]] int h(void) {return 2;}
