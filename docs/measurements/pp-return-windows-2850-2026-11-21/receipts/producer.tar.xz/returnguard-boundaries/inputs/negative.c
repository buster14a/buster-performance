int b; int f(int x){return -2;return (2);return x+2;return 08.0;return 012;return 0x0;return 1u;return 2147483648;return 0b1;return __LINE__;}
