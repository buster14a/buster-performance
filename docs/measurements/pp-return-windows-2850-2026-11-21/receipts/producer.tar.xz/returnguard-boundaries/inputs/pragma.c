#pragma unknown return 11;
#define RET(x) return x;
int h(int x){RET(x) _Pragma("unknown return 11;") RET(13)}
