[[vendor::irrelevant(return 3;)]] int g(int n) {return n;}
