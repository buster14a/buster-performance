#define RET return
#define V 17
int global;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;int f(int x){ return 0; {RET V;} return x;}
#pragma unknown return 123 ;
int g(void){ RET global; return 2147483647; return 2147483648; return 01u; }
