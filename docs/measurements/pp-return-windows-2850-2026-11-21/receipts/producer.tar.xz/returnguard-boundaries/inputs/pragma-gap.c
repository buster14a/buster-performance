int g(void){return
#pragma unknown
9; return 3
#pragma unknown
;return 5;}
