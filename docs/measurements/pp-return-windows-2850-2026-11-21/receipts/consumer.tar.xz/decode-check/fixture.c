int f(void) { return 7; }
int h(int value) { return value; }
int main(void) { return f() - 7 + h(0); }
