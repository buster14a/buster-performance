// Direct controls for fragment counts that parser-created section markers would otherwise fill.
#define main probe_unused_compiler_main
#include "buster/compiler/main.c"
#undef main

int main(void)
{
    const uint32_t section_counts[] = {0, 257, 257, 4097};
    const uint32_t fragment_counts[] = {0, 0, 6, 6};
    for (uint32_t c = 0; c < BUSTER_ARRAY_LENGTH(section_counts); c += 1)
    {
        const uint32_t sections = section_counts[c];
        const uint32_t count = fragment_counts[c];
        AsmFragment fragments[7] = {0};
        if (count != 0)
        {
            const uint32_t ids[] = {sections - 1, BUSTER_LINK_CLASS_EH_FRAME, 1, sections - 1, 1, BUSTER_LINK_CLASS_EH_FRAME};
            for (uint32_t i = 0; i < count; i += 1)
            {
                fragments[i].section = ids[i];
            }
        }
        uint32_t words[4097 + 1 + 7];
        memset(words, 0xa5, sizeof(words));
        Arena arena = { .base = (uint8_t*)words, .capacity = (uint64_t)(count + sections + 2) * sizeof(uint32_t) };
        AsmParser parser = {
            .arena = &arena,
            .fragments = fragments,
            .capacity = BUSTER_ARRAY_LENGTH(fragments),
            .section = BUSTER_LINK_CLASS_EH_FRAME,
            .section_count = sections,
            .fragment_count = count,
        };
        asm_partition_fragments(&parser);
        if (parser.result.error != 0)
        {
            fprintf(stderr, "%s\n", parser.result.error);
            return 1;
        }
        if (sections > BUSTER_LINK_CLASS_EH_FRAME)
        {
            const uint32_t appended = asm_fragment(&parser, ASM_BYTES, 0);
            asm_partition_append(&parser, appended);
        }
    }
    return 0;
}
