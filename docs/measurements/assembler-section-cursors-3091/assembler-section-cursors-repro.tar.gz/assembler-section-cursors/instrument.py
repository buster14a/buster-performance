"""Insert private probes into a disposable copy of the two assembler functions."""
from pathlib import Path
import re
import sys

source = Path(sys.argv[1]) / "src/buster/compiler/assembler_sections.c"
contents = source.read_text()
start = contents.index("static void asm_partition_fragments(")
append = contents.index("static void asm_partition_append(", start)
end = contents.index("// Whether a section holds bytes", append)
partition = contents[start:append].replace("asm_partition_fragments", "trace_partition_implementation")
loops = re.compile(r"(        for \(uint32_t i = 0; i < (?:parser->)?(fragment_count|section_count); i \+= 1\)\n        \{)")
expected_bounds = ["fragment_count", "section_count", "fragment_count"]
if [m[1] for m in loops.findall(partition)] != expected_bounds:
    raise ValueError("unexpected partition loops")
counters = iter(["trace_histogram", "trace_prefix", "trace_scatter"])
partition = loops.sub(lambda m: m[1] + "\n            " + next(counters) + " += 1;", partition)
copy = "        memcpy(cursors, begin, parser->section_count * sizeof(uint32_t));"
if copy in partition:
    partition = partition.replace(copy, copy + "\n        trace_copy_words += parser->section_count;")
elif "memcpy" in partition or "cursors" in partition:
    raise ValueError("unexpected cursor copy")
declarations = "static uint32_t trace_histogram, trace_prefix, trace_scatter, trace_copy_words;\n"
append_body = contents[append:end].replace("static void asm_partition_append(", "static void trace_append_implementation(")
wrappers = Path(__file__).with_name("trace.inc").read_text()
source.write_text(contents[:start] + declarations + partition + append_body + wrappers + "\n" + contents[end:])
