// Private measurement wrapper in a disposable build of assembler_sections.c.
static void trace_ranges(const char* phase, const AsmParser* parser)
{
    if (parser->result.error == 0)
    {
        printf("%s sources", phase);
        for (uint32_t i = 0; i < parser->fragment_count; i += 1)
        {
            printf(" %u", parser->fragments[i].section);
        }
        printf("\n%s order", phase);
        for (uint32_t i = 0; i < parser->fragment_count; i += 1)
        {
            printf(" %u", parser->fragment_order[i]);
        }
        printf("\n%s boundaries", phase);
        for (uint32_t i = 0; i <= parser->section_count; i += 1)
        {
            printf(" %u", parser->fragment_begin[i]);
        }
        putchar('\n');
    }
}

static void asm_partition_fragments(AsmParser* parser)
{
    Arena* arena = parser->arena;
    const uint64_t entry = arena->length;
    const uint64_t capacity = arena->capacity;
    Scratch scratch = scratch_begin(arena);
    const uint64_t scratch_capacity = scratch.arena->capacity;
    const uint64_t saved_peak = scratch.arena->peak;
    scratch.arena->peak = scratch.length;
    trace_histogram = trace_prefix = trace_scatter = trace_copy_words = 0;

    const char* limit = getenv("PARTITION_LIMIT");
    const uint64_t padding = (-(uintptr_t)(arena->base + entry)) & (_Alignof(uint32_t) - 1);
    const uint64_t order_bytes = ((uint64_t)parser->fragment_count + 1) * sizeof(uint32_t);
    const uint64_t boundary_bytes = ((uint64_t)parser->section_count + 1) * sizeof(uint32_t);
    if (limit != 0 && strcmp(limit, "order") == 0)
    {
        arena->capacity = entry + padding + order_bytes - 1;
    }
    if (limit != 0 && strcmp(limit, "boundaries") == 0)
    {
        arena->capacity = entry + padding + order_bytes + boundary_bytes - 1;
    }
    if (limit != 0 && strcmp(limit, "scratch") == 0)
    {
        scratch.arena->capacity = scratch.length;
    }

    trace_partition_implementation(parser);
    const uint64_t peak_delta = scratch.arena->peak - scratch.length;
    fprintf(stderr, "S=%u F=%u histogram=%u prefix=%u scatter=%u copied_words=%u scratch_peak=%llu arena_delta=%llu\n",
            parser->section_count, parser->fragment_count, trace_histogram, trace_prefix, trace_scatter,
            trace_copy_words, (unsigned long long)peak_delta, (unsigned long long)(arena->length - entry));
    arena->capacity = capacity;
    scratch.arena->capacity = scratch_capacity;
    if (saved_peak > scratch.arena->peak)
    {
        scratch.arena->peak = saved_peak;
    }
    scratch_end(scratch);
    trace_ranges("partition", parser);
}

static void asm_partition_append(AsmParser* parser, uint32_t id)
{
    trace_append_implementation(parser, id);
    trace_ranges("append", parser);
}
