	.file	"program-switch.c"
	.text
	.p2align 4
	.globl	switch_weight
	.type	switch_weight, @function
switch_weight:
.LFB11:
	.cfi_startproc
	cmpl	$9, %edi
	ja	.L3
	movl	%edi, %edi
	movl	CSWTCH.2(,%rdi,4), %eax
	ret
	.p2align 4,,10
	.p2align 3
.L3:
	movl	$-1, %eax
	ret
	.cfi_endproc
.LFE11:
	.size	switch_weight, .-switch_weight
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"last"
	.text
	.p2align 4
	.globl	switch_name
	.type	switch_name, @function
switch_name:
.LFB12:
	.cfi_startproc
	andl	$7, %edi
	movl	$.LC0, %eax
	cmpl	$7, %edi
	je	.L5
	movq	CSWTCH.4(,%rdi,8), %rax
.L5:
	ret
	.cfi_endproc
.LFE12:
	.size	switch_name, .-switch_name
	.section	.text.unlikely,"ax",@progbits
.LCOLDB1:
	.text
.LHOTB1:
	.p2align 4
	.globl	switch_step
	.type	switch_step, @function
switch_step:
.LFB13:
	.cfi_startproc
	subl	$10, %esi
	cmpl	$6, %esi
	ja	.L19
	jmp	*.L12(,%rsi,8)
	.section	.rodata
	.align 8
	.align 4
.L12:
	.quad	.L18
	.quad	.L17
	.quad	.L16
	.quad	.L15
	.quad	.L14
	.quad	.L13
	.quad	.L11
	.text
	.p2align 4,,10
	.p2align 3
.L13:
	movq	%rdi, %rax
	sarq	%rax
	ret
	.p2align 4,,10
	.p2align 3
.L11:
	movq	%rdi, %rax
	negq	%rax
	ret
	.p2align 4,,10
	.p2align 3
.L18:
	leaq	(%rdi,%rdi,2), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L17:
	leaq	7(%rdi), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L16:
	leaq	-2(%rdi), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L15:
	movq	%rdi, %rax
	xorq	$85, %rax
	ret
	.p2align 4,,10
	.p2align 3
.L14:
	leaq	0(,%rdi,4), %rax
	ret
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	switch_step.cold, @function
switch_step.cold:
.LFSB13:
.L19:
	movq	%rdi, %rax
	ret
	.cfi_endproc
.LFE13:
	.text
	.size	switch_step, .-switch_step
	.section	.text.unlikely
	.size	switch_step.cold, .-switch_step.cold
.LCOLDE1:
	.text
.LHOTE1:
	.section	.rodata.str1.1
.LC2:
	.string	"switch: %ld %ld %u %s\n"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB14:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movl	$-1, %edx
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	xorl	%ebx, %ebx
	.p2align 4
	.p2align 3
.L21:
	movl	%edx, %edi
	leaq	(%rbx,%rbx,2), %rcx
	addl	$1, %edx
	call	switch_weight
	movslq	%eax, %rbx
	addq	%rcx, %rbx
	cmpl	$12, %edx
	jne	.L21
	movl	$9, %edx
	movl	$1, %ebp
	.p2align 4
	.p2align 3
.L22:
	movl	%edx, %esi
	movq	%rbp, %rdi
	addl	$1, %edx
	call	switch_step
	movq	%rax, %rbp
	cmpl	$18, %edx
	jne	.L22
	xorl	%esi, %esi
	xorl	%r12d, %r12d
	.p2align 4
	.p2align 3
.L25:
	movl	%esi, %edi
	call	switch_name
	movzbl	(%rax), %edx
	testb	%dl, %dl
	je	.L23
	.p2align 5
	.p2align 4
	.p2align 3
.L24:
	movl	%r12d, %ecx
	addq	$1, %rax
	sall	$5, %ecx
	subl	%r12d, %ecx
	leal	(%rdx,%rcx), %r12d
	movzbl	(%rax), %edx
	testb	%dl, %dl
	jne	.L24
.L23:
	addl	$1, %esi
	cmpl	$9, %esi
	jne	.L25
	movl	$5, %edi
	movq	%rbp, %rdx
	movl	%r12d, %ecx
	movq	%rbx, %rsi
	call	switch_name
	movl	$.LC2, %edi
	movq	%rax, %r8
	xorl	%eax, %eax
	call	printf
	cmpq	$4652591, %rbx
	popq	%rbx
	.cfi_def_cfa_offset 24
	setne	%al
	cmpq	$-186, %rbp
	popq	%rbp
	.cfi_def_cfa_offset 16
	setne	%dl
	orl	%edx, %eax
	cmpl	$-541135001, %r12d
	popq	%r12
	.cfi_def_cfa_offset 8
	setne	%dl
	orl	%edx, %eax
	movzbl	%al, %eax
	ret
	.cfi_endproc
.LFE14:
	.size	main, .-main
	.section	.rodata.str1.1
.LC3:
	.string	"three"
.LC4:
	.string	"first"
.LC5:
	.string	"five"
.LC6:
	.string	"third"
.LC7:
	.string	"zero"
.LC8:
	.string	"fifth"
.LC9:
	.string	"seven"
	.section	.rodata
	.align 32
	.type	CSWTCH.4, @object
	.size	CSWTCH.4, 56
CSWTCH.4:
	.quad	.LC3
	.quad	.LC4
	.quad	.LC5
	.quad	.LC6
	.quad	.LC7
	.quad	.LC8
	.quad	.LC9
	.align 32
	.type	CSWTCH.2, @object
	.size	CSWTCH.2, 40
CSWTCH.2:
	.long	17
	.long	23
	.long	5
	.long	91
	.long	44
	.long	8
	.long	63
	.long	12
	.long	-1
	.long	70
	.ident	"GCC: (GNU) 16.2.1 20260810"
	.section	.note.GNU-stack,"",@progbits
