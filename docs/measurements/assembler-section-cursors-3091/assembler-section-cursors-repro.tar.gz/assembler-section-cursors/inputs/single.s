.text
.byte 1,2,3
.byte 4
