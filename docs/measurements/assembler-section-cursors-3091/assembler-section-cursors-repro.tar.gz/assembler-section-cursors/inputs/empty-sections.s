.section .a,"a",@progbits
.section .b,"a",@progbits
.section .a,"a",@progbits
