.text
.globl f
.type f,@function
f:
.cfi_startproc
    nop
    .pushsection .data
    .byte 0x11
    .popsection
    ret
.cfi_endproc
.size f,.-f
.section .empty,"a",@progbits
.section .later,"a",@progbits
.quad f
.data
.byte 0x22
