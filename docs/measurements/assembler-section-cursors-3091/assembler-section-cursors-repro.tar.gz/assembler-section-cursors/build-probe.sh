#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
clang -O0 -march=native -DBUSTER_EXECUTABLE_UNIT -fwrapv -funsigned-char -fno-strict-aliasing \
    -ffunction-sections -fdata-sections -I"$1/src" "$here/private-probe.c" \
    -Wl,--gc-sections -pthread -lm -ldl -o "$2"
