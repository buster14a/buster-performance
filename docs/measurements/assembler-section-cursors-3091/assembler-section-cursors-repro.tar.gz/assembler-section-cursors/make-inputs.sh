#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$2"
input_dir=$(cd "$2" && pwd)
repo=$(realpath "$1")
for n in 256 1024; do
    awk -v n="$n" 'BEGIN {
        for (i=0; i<n; ++i) printf ".section .s%04d,\"a\",@progbits\n", i
        for (j=0; j<3; ++j) {
            printf ".section .s%04d,\"a\",@progbits\n.byte %d\n", n-1, 10+j
            printf ".section .s0000,\"a\",@progbits\n.byte %d\n", 40+j
        }
    }' > "$input_dir/sparse-$n.s"
done
(cd "$repo" && LC_ALL=C gcc -S -O2 -g0 -fcf-protection=none -march=x86-64 -fno-pie -o "$input_dir/gcc-switch.s" examples/assembler/program-switch.c)
