#!/usr/bin/env bash
set -euo pipefail
bin=$(realpath "$1")
inputs=$(realpath "$2")
mkdir -p "$3"
out=$(realpath "$3")
cd "$inputs"
for name in empty empty-sections single interleaved interleaved-cfi sparse-256 sparse-1024 gcc-switch; do
    "$bin" assemble -o "$out/$name.o" "$name.s" > "$out/$name.rows" 2> "$out/$name.counts"
done
