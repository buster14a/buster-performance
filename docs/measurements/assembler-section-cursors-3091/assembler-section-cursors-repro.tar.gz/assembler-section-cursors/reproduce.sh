#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 2 ]]; then
    echo "Usage: bash reproduce.sh /path/to/buster NEW_OUTPUT_DIRECTORY" >&2
    exit 2
fi
here=$(cd "$(dirname "$0")" && pwd)
repo=$(cd "$1" && pwd)
base=3741c264fb349e86359acfd1c732ee1c2eaa4052
[[ $(uname -sm) == "Linux x86_64" ]]
model=$(LC_ALL=C lscpu | awk -F: '/^Model name:/ {print $2}')
[[ -n $model && ${model^^} != *9700X* ]]
git -C "$repo" cat-file -e "$base^{commit}"
mkdir "$2"
out=$(cd "$2" && pwd)
tree=$out/tree
git -C "$repo" worktree add -q --detach "$tree" "$base"
clang -march=native -fsyntax-only -x c "$tree/src/buster/compiler/host_isa.h"

run=()
if [[ -n ${PARTITION_CORE_WRAPPER:-} ]]; then
    run=("$PARTITION_CORE_WRAPPER")
elif command -v cores >/dev/null; then
    run=(cores -n 1 --)
fi
export CORES_TITLE='Assembler section cursor reproduction' CORES_LINK='https://github.com/buster14a/buster/issues/3091'
export BUSTER_TOOLCHAIN=path BUSTER_HOST_ARCH=native BUSTER_DEBUG_INFO=0 BUSTER_ORACLE_CACHE=off
build() {
    (cd "$tree" && "${run[@]}" ./build.sh --config Debug --jobs 1)
}
for side in base head; do
    clean=$out/$side
    traced=$out/$side-traced
    mkdir "$clean" "$traced"
    if [[ $side == head ]]; then
        git -C "$tree" apply --check "$here/assembler-section-cursors.patch"
        git -C "$tree" apply "$here/assembler-section-cursors.patch"
    fi
    build > "$clean/build.log" 2>&1
    (cd "$tree" && BUSTER_COMPILER="$tree/build/compiler" "${run[@]}" ./build/compiler test-assembler --cross-check) > "$clean/test.log" 2>&1
    bash "$here/run-inputs.sh" "$tree/build/compiler" "$here/inputs" "$clean"

    cp "$tree/src/buster/compiler/assembler_sections.c" "$traced/sections.clean.c"
    python3 "$here/instrument.py" "$tree"
    build > "$traced/build.log" 2>&1
    bash "$here/run-inputs.sh" "$tree/build/compiler" "$here/inputs" "$traced"
    bash "$here/run-limits.sh" "$tree/build/compiler" "$here/inputs" "$traced"
    "${run[@]}" bash "$here/build-probe.sh" "$tree" "$traced/private-probe"
    "$traced/private-probe" > "$traced/private.rows" 2> "$traced/private.counts"
    cp "$traced/sections.clean.c" "$tree/src/buster/compiler/assembler_sections.c"
done

python3 "$here/verify.py" "$out" | tee "$out/comparison.txt"
as --64 -o "$out/gnu-cfi.o" "$here/inputs/interleaved-cfi.s"
for section in .text .data .later .eh_frame; do
    objcopy -O binary --only-section="$section" "$out/gnu-cfi.o" "$out/gnu-$section.bin"
    objcopy -O binary --only-section="$section" "$out/head/interleaved-cfi.o" "$out/head/$section.bin"
    cmp "$out/gnu-$section.bin" "$out/head/$section.bin"
done
readelf -W --debug-dump=frames "$out/gnu-cfi.o" > "$out/gnu.frames"
readelf -W --debug-dump=frames "$out/head/interleaved-cfi.o" > "$out/head/cfi.frames"
cmp "$out/gnu.frames" "$out/head/cfi.frames"
for side in base head; do
    grep -E '^assembler: [0-9]+ checks, 0 failures' "$out/$side/test.log"
done
