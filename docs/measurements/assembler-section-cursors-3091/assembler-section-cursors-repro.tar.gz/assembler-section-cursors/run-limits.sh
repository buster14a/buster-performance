#!/usr/bin/env bash
set -euo pipefail
bin=$(realpath "$1")
inputs=$(realpath "$2")
mkdir -p "$3"
out=$(realpath "$3")
cd "$inputs"
for limit in order boundaries scratch; do
    printf 'previous output\n' > "$out/limit-$limit.o"
    rc=0
    PARTITION_LIMIT=$limit "$bin" assemble -o "$out/limit-$limit.o" interleaved-cfi.s \
        > "$out/limit-$limit.rows" 2> "$out/limit-$limit.counts" || rc=$?
    printf '%s\n' "$rc" > "$out/limit-$limit.status"
done
