"""Check every fragment ID, section boundary, emitted byte and allocation control."""
from collections import Counter
from itertools import accumulate
from pathlib import Path
import hashlib
import sys

root = Path(sys.argv[1])
base, head = root / "base", root / "head"
bt, ht = root / "base-traced", root / "head-traced"
names = "empty empty-sections single interleaved interleaved-cfi sparse-256 sparse-1024 gcc-switch".split()


def counters(line):
    return {key: int(value) for key, value in (field.split("=") for field in line.split())}


def check_counts(before, after):
    s, f = before["S"], before["F"]
    for m in (before, after):
        assert m["S"] == m["prefix"] == s
        assert m["F"] == m["histogram"] == m["scatter"] == f
    assert before["arena_delta"] == after["arena_delta"]
    assert before["copied_words"] == s and after["copied_words"] == 0
    assert before["scratch_peak"] == s * 4 and after["scratch_peak"] == 0


def check_rows(original, changed):
    raw = original.read_bytes()
    assert raw == changed.read_bytes()
    lines = raw.decode().splitlines()
    assert lines and len(lines) % 3 == 0
    phases = []
    previous_source, previous_order = [], []
    for i in range(0, len(lines), 3):
        phase, label, *rest = lines[i].split()
        assert label == "sources"
        source = list(map(int, rest))
        phase2, label, *rest = lines[i+1].split()
        assert phase == phase2 and label == "order"
        order = list(map(int, rest))
        phase3, label, *rest = lines[i+2].split()
        assert phase == phase3 and label == "boundaries"
        bounds = list(map(int, rest))
        assert order == sorted(range(len(source)), key=source.__getitem__)
        counts = Counter(source)
        assert bounds == [0, *accumulate(counts[s] for s in range(len(bounds)-1))]
        assert bounds[-1] == len(source)
        if phase == "append":
            assert phases[-1] == "partition" and source[:-1] == previous_source
            assert [f for f in order if f != len(previous_source)] == previous_order
        previous_source, previous_order = source, order
        phases.append(phase)
    return phases


print("input  sections  fragments  base_scratch_B  head_scratch_B  object_B  SHA256")
for name in names:
    obj = (base / (name + ".o")).read_bytes()
    for directory in (head, bt, ht):
        assert (directory / (name + ".o")).read_bytes() == obj, name
    phases = check_rows(bt / (name + ".rows"), ht / (name + ".rows"))
    if name == "interleaved-cfi":
        assert phases == ["partition", "append"]
    b, h = [counters((d / (name + ".counts")).read_text()) for d in (bt, ht)]
    check_counts(b, h)
    print(name, b["S"], b["F"], b["scratch_peak"], h["scratch_peak"], len(obj), hashlib.sha256(obj).hexdigest())

assert check_rows(bt / "private.rows", ht / "private.rows") == ["partition", "partition", "append", "partition", "append", "partition", "append"]
before, after = [[counters(line) for line in (d / "private.counts").read_text().splitlines()] for d in (bt, ht)]
assert [(m["S"], m["F"]) for m in before] == [(0, 0), (257, 0), (257, 6), (4097, 6)]
assert len(before) == len(after)
for b, h in zip(before, after):
    check_counts(b, h)
    print("private", b["S"], b["F"], b["scratch_peak"], h["scratch_peak"])

for limit in ("order", "boundaries", "scratch"):
    filename = "limit-" + limit
    diagnostics = []
    for directory in (bt, ht):
        rc = int((directory / (filename + ".status")).read_text())
        obj = (directory / (filename + ".o")).read_bytes()
        if directory == ht and limit == "scratch":
            assert rc == 0 and obj == (head / "interleaved-cfi.o").read_bytes()
        else:
            assert rc == 1 and obj == b"previous output\n"
            diagnostic = (directory / (filename + ".counts")).read_text().splitlines()[1:]
            assert any("arena exhausted partitioning section fragments" in line for line in diagnostic)
            diagnostics.append(diagnostic)
    if len(diagnostics) == 2:
        assert diagnostics[0] == diagnostics[1]
    print("arena control passed", limit)
