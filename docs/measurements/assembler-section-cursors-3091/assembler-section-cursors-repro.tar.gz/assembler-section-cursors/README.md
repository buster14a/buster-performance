# Assembler fragment partition

The patch removes one temporary four-byte cursor for every assembler section. The permanent table keeps its zero first boundary. Slot `s + 1` starts with section `s`’s count and then holds its exclusive prefix. Each source fragment increments that slot after writing its ID. Even an empty section therefore ends with the correct boundary. The final slot holds the total fragment count. The extra entry in the order array is available for the post-layout CFI append.

Base `3741c264fb349e86359acfd1c732ee1c2eaa4052`. Local commit `4b6076537461499a89410ee792087c14a1cadba6`. The patch changes `asm_partition_fragments` in `assembler_sections.c` and its checks in `assembler_groups_test.c`.

## Reproduce

Run from the extracted directory on a verified non-9700X Linux x86-64 host meeting Buster’s AVX-512 requirements. Supply a Buster checkout containing the base commit and a new output directory.

```sh
bash reproduce.sh /path/to/buster /tmp/buster-section-cursors-repro
```

The script builds each revision in a disposable worktree, runs the normal assembler tests, and compares the objects from `compiler assemble`. It then rebuilds with private probes, compares the complete arrays at partition and after each CFI append, and forces allocation failures at the partition call. Its final GNU binutils check compares four section payloads and the decoded frames for `inputs/interleaved-cfi.s`. The host used for the recorded run was a Linux AMD Ryzen 9 7940HS with Clang 23.1.5, GCC 16.2.1, GNU binutils 2.47, CMake 4.5.0 and Ninja 1.13.2. Both builds used Debug, native ISA and one build job. The counters describe work and arena storage.

The recorded result can also be checked directly.

```sh
python3 verify.py observed
cmp observed/gnu.frames observed/head/cfi.frames
```

To apply only the code and tests in a checkout at the base commit, use `git am /absolute/path/to/assembler-section-cursors.patch`.

## Representative assembly

`inputs/interleaved-cfi.s` assembles a two-instruction function, emits a data byte inside its CFI procedure through a section push/pop, declares an empty section, relocates a reference to the function in a later section, and reopens data. Use the same relative input name for both invocations because the ELF object records it.

```sh
cd inputs
/path/to/base/compiler assemble -o /tmp/interleaved-base.o interleaved-cfi.s
/path/to/head/compiler assemble -o /tmp/interleaved-head.o interleaved-cfi.s
cmp /tmp/interleaved-base.o /tmp/interleaved-head.o
readelf -W --debug-dump=frames /tmp/interleaved-head.o
```

The object was 1,240 bytes with SHA-256 `ab67af19e4dbb60e35a5c7432261565c70fd3426a321991a02ce08c78f5524b3`. The partition sentinel was 15 before CFI and 16 after the append. The function bytes were `90 c3`, the data bytes were `11 22`, and the FDE covered both instructions. GNU as agreed on `.text`, `.data`, `.later`, `.eh_frame` and the decoded frame rows.

## Results

| Input | Section slots | Source fragments before CFI | Base cursor bytes | Head cursor bytes |
| --- | ---: | ---: | ---: | ---: |
| Empty source via the driver | 14 | 1 | 56 | 0 |
| Interleaved CFI example | 16 | 15 | 64 | 0 |
| 256 custom section declarations | 270 | 269 | 1,080 | 0 |
| 1,024 custom section declarations | 1,038 | 1,037 | 4,152 | 0 |
| GCC assembly for the switch program | 16 | 249 | 64 | 0 |
| Private empty partition | 0 | 0 | 0 | 0 |
| Private empty ranges | 257 | 0 | 1,028 | 0 |
| Private sparse ranges | 257 | 6 | 1,028 | 0 |
| Private sparse ranges | 4,097 | 6 | 16,388 | 0 |

Both revisions visited each fragment once to count and once to scatter, cleared the same boundary array, and visited every section once for the prefix. Base also copied one full column of section starts. Head removed that copy without adding a pass. The partition’s permanent arena deltas matched for every case, including alignment. The scratch column measures the temporary peak above the scratch arena’s entry length during this call. Whole-process RSS and elapsed-time speedup were outside the measurement.

All eight complete ELF files matched. Additional controls were two empty declared sections, one populated section, and interleaving without CFI. Each large source had six explicit byte emissions. Parser-created section markers explain the larger observed source-fragment count. The direct fixture isolates many empty sections with only six source fragments. Every source section ID, ordered fragment ID and boundary is in the `.rows` files. The verifier also reconstructs each partition independently by stable sorting the source IDs.

When the order allocation or the boundary allocation was one byte short, both revisions exited 1 with the same diagnostic at `interleaved-cfi.s:1:1` and preserved the existing output. With only cursor scratch exhausted, base gave that diagnostic and head emitted the ordinary object. The normal assembler cross-check passed 1,984,303 checks on base and 1,984,308 on head with seed 1 and 2,000 fuzz cases. The guide’s structural DCO audit found one signed commit and zero trailer findings.

The archive contains the eight exact input files, both clean and traced objects, order and boundary dumps, counts and test logs. To regenerate the two sparse inputs and GCC assembly from the checked-in C source, run `bash make-inputs.sh /path/to/buster /tmp/section-inputs` with the recorded GCC version.
