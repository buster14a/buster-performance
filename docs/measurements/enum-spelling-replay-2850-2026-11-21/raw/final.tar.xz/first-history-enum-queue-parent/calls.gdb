set pagination off
set confirm off
set debuginfod enabled off
set print frame-arguments none
set print thread-events off
break pp_history_record
commands
silent
printf "first history record\n"
bt 14
continue
end
break pp_preprocess_file
commands
silent
printf "preprocess file\n"
bt 4
continue
end
run
