struct S{union {int x; double y;};};struct {int x;} first,second;int main(void){return first==second;}
