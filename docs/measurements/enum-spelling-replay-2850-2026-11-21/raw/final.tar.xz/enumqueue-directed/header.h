#pragma GCC system_header
#pragma clang diagnostic warning "-Wenum-float-conversion"
int fn(int x){ return (int)(A+1.25); }
