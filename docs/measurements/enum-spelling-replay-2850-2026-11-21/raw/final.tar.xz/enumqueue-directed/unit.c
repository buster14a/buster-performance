enum E { A=1,B=2 }; enum F { C=3,D=4 }; enum { U=5 }; typedef enum { V=6 } Named;
#define MIX(x,y) ((x)+(y))
#pragma clang diagnostic warning "-Wenum-float-conversion"
int fn(int x){ return (int)(A+1.25); }
int broken(void){return (1+;
