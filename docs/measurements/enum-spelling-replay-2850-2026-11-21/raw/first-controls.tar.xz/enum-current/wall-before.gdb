exclusive.sh: waiting for the 9700X, held by: 2026-11-21T16:25:19+00:00 codex-2850: taskset -c 2 bash ordinary-compare-one.sh profile29f sqlite baseline pmu /home/david/buster-fast-bench/2850-codex-step2/results/ordinary-pair-profile29f-sqlite/pmu-4-2 /dev/shm/buster2850-multimode.YkPZe6BF
  title: Buster #2850 step 2
  link: https://github.com/buster14a/buster/issues/2850
Breakpoint 1 at 0x1115fa1: pp_history_record. (4 locations)
Breakpoint 2 at 0x102a9ed: pp_preprocess_file. (27 locations)
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/usr/lib/libthread_db.so.1".
preprocess file
#0  pp_preprocess_file (pp=..., main_path=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_preprocessor_impl.c:14141
#1  0x00000000017347b5 in pp_run (pp=..., main_path=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_preprocessor_impl.c:14564
#2  pp_run_input (pp=..., path=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_preprocessor_impl.c:14618
#3  0x00000000011e8ef5 in check_driver_unit (command=..., options=..., path=..., identifiers=..., pp=..., parser=..., arena=..., scratch=..., output_arena=..., lanes=..., stage_clock=..., pp_ticks=..., errors=..., kept=..., release=..., dependency=..., dependency_arena=..., deferred=..., fatal=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_checker_driver.c:12513
first history record
#0  pp_history_record (pp=..., report=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_preprocessor_impl.c:14253
#1  0x0000000001787437 in pp_history_ensure (pp=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_preprocessor_impl.c:14400
#2  0x000000000141f121 in check_driver_spelling_build (parser=..., pp=..., input=..., types=..., spell=..., scratch=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_check_warning_render.c:217
#3  0x000000000141df5d in check_driver_spelling_ready (parser=..., pp=..., input=..., types=..., spell=..., scratch=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_check_warning_render.c:551
#4  0x0000000001413c7b in check_driver_warning_type_at (parser=..., pp=..., input=..., types=..., spell=..., scratch=..., type=..., spelling=..., declaration=..., declared=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_check_warning_render.c:941
#5  0x0000000001406622 in check_driver_warning_type (parser=..., pp=..., input=..., types=..., spell=..., scratch=..., type=..., spelling=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_check_warning_render.c:1118
#6  check_common_enum_mix (parser=..., pp=..., input=..., types=..., spell=..., scratch=..., kind=..., question=..., omitted=..., left_coerced=..., right_coerced=..., left_spelling=..., right_spelling=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_check_common_warnings.c:5471
#7  0x000000000121cc67 in check_common_enum_arithmetic (parser=..., pp=..., input=..., stream=..., types=..., spell=..., scratch=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_check_common_warnings.c:5540
#8  0x00000000011f8889 in check_driver_common_warnings (parser=..., pp=..., input=..., stream=..., types=..., program=..., flushed=..., shifts=..., scratch=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_check_common_warnings.c:12862
#9  0x00000000011f09e3 in check_driver_unit (command=..., options=..., path=..., identifiers=..., pp=..., parser=..., arena=..., scratch=..., output_arena=..., lanes=..., stage_clock=..., pp_ticks=..., errors=..., kept=..., release=..., dependency=..., dependency_arena=..., deferred=..., fatal=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_checker_driver.c:13499
#10 0x00000000011def35 in check_driver_one_unit (run=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_checker_driver.c:13954
#11 check_driver_flow (argument=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_checker_driver.c:14049
#12 0x000000000106da2a in lane_session_run (session=..., capacity=..., cpus=..., entry=..., argument=..., flags=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/lane.c:3388
#13 0x00000000011e83be in check_driver_run (run=..., announced=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_checker_driver.c:14107
preprocess file
#0  pp_preprocess_file (pp=..., main_path=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_preprocessor_impl.c:14141
#1  0x00000000011161b9 in pp_history_record (pp=..., report=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_preprocessor_impl.c:14275
#2  0x0000000001787437 in pp_history_ensure (pp=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_preprocessor_impl.c:14400
#3  0x000000000141f121 in check_driver_spelling_build (parser=..., pp=..., input=..., types=..., spell=..., scratch=...) at /home/david/buster-fast-bench/2850-codex-step2/trees/constbaseb86/src/buster/compiler/c_check_warning_render.c:217
[Inferior 1 (process 3268655) exited normally]
