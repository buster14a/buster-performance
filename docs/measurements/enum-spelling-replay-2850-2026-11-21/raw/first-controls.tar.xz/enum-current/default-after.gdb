exclusive.sh: waiting for the 9700X, held by: 2026-11-21T16:25:15+00:00 codex-2850: taskset -c 2 env -u BUSTER_HUGE_PAGES /home/david/buster-fast-bench/2850-pp-parser-window/baseline/compiler time-runs --runs 2 --warmups 1 --executable /home/david/buster-fast-bench/2850-codex-step2/results/constbaseb86/compiler --list -Wall -c -o /home/david/buster-fast-bench/2850-pp-parser-window/tagplace-time/current.o -march=znver5 -Isrc -fwrapv -funsigned-char --predefines /home/david/buster-fast-bench/2850-pp-parser-window/oracle/predefines.h src/buster/compiler/main.c
  title: Buster #2850 PP to parser window
  link: https://github.com/buster14a/buster/issues/2850
Breakpoint 1 at 0x1115fa1: pp_history_record. (4 locations)
Breakpoint 2 at 0x102a9ed: pp_preprocess_file. (27 locations)
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/usr/lib/libthread_db.so.1".
preprocess file
#0  pp_preprocess_file (pp=..., main_path=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_impl.c:14141
#1  0x00000000017357b5 in pp_run (pp=..., main_path=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_impl.c:14564
#2  pp_run_input (pp=..., path=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_impl.c:14618
#3  0x00000000011e8ef5 in check_driver_unit (command=..., options=..., path=..., identifiers=..., pp=..., parser=..., arena=..., scratch=..., output_arena=..., lanes=..., stage_clock=..., pp_ticks=..., errors=..., kept=..., release=..., dependency=..., dependency_arena=..., deferred=..., fatal=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_checker_driver.c:12513
[Inferior 1 (process 3268527) exited normally]
