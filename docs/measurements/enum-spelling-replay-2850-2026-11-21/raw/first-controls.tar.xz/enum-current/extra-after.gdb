exclusive.sh: waiting for the 9700X, held by: 2026-11-21T16:25:28+00:00 codex-2850: taskset -c 2 bash ordinary-compare-one.sh profile29f musl candidate pmu /home/david/buster-fast-bench/2850-codex-step2/results/ordinary-pair-profile29f-musl/pmu-4-4 /dev/shm/buster2850-multimode.FxyofCI1
  title: Buster #2850 step 2
  link: https://github.com/buster14a/buster/issues/2850
Breakpoint 1 at 0x1115fa1: pp_history_record. (4 locations)
Breakpoint 2 at 0x102a9ed: pp_preprocess_file. (27 locations)
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/usr/lib/libthread_db.so.1".
preprocess file
#0  pp_preprocess_file (pp=..., main_path=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_impl.c:14141
#1  0x00000000017357b5 in pp_run (pp=..., main_path=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_impl.c:14564
#2  pp_run_input (pp=..., path=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_impl.c:14618
#3  0x00000000011e8ef5 in check_driver_unit (command=..., options=..., path=..., identifiers=..., pp=..., parser=..., arena=..., scratch=..., output_arena=..., lanes=..., stage_clock=..., pp_ticks=..., errors=..., kept=..., release=..., dependency=..., dependency_arena=..., deferred=..., fatal=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_checker_driver.c:12513
first history record
#0  pp_history_record (pp=..., report=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_impl.c:14253
#1  0x0000000001118320 in pp_history_ensure (pp=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_impl.c:14400
#2  pp_diagnose_output_arguments (pp=..., severity=..., token=..., position=..., phase=..., notes=..., note_count=..., format=..., arguments=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_history_impl.c:1018
#3  0x000000000176dbd1 in pp_diagnose_output_notes_phase (pp=..., severity=..., token=..., position=..., phase=..., notes=..., note_count=..., format=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_history_impl.c:1330
#4  0x0000000001689e3f in check_driver_warning_events_from (parser=..., pp=..., input=..., types=..., stream=..., view=..., repair=..., publication_end=..., scratch=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_check_warning_render.c:2991
#5  0x00000000011f0495 in check_driver_unit (command=..., options=..., path=..., identifiers=..., pp=..., parser=..., arena=..., scratch=..., output_arena=..., lanes=..., stage_clock=..., pp_ticks=..., errors=..., kept=..., release=..., dependency=..., dependency_arena=..., deferred=..., fatal=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_checker_driver.c:13454
#6  0x00000000011def35 in check_driver_one_unit (run=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_checker_driver.c:13954
#7  check_driver_flow (argument=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_checker_driver.c:14049
#8  0x000000000106da2a in lane_session_run (session=..., capacity=..., cpus=..., entry=..., argument=..., flags=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/lane.c:3388
#9  0x00000000011e83be in check_driver_run (run=..., announced=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_checker_driver.c:14107
#10 check_driver_command (count=..., arguments=..., executable=..., release=..., announced=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_checker_driver.c:15063
#11 0x000000000116d0e1 in run_check_command_mode (count=..., arguments=..., executable=..., release=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_checker_driver.c:15116
#12 0x0000000001026fea in main_source_command (argc=..., argv=..., advised=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/main.c:2598
#13 0x0000000001733eed in main_driver (argc=..., argv=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/main.c:2683
preprocess file
#0  pp_preprocess_file (pp=..., main_path=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_impl.c:14141
#1  0x00000000011161b9 in pp_history_record (pp=..., report=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_impl.c:14275
#2  0x0000000001118320 in pp_history_ensure (pp=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_impl.c:14400
#3  pp_diagnose_output_arguments (pp=..., severity=..., token=..., position=..., phase=..., notes=..., note_count=..., format=..., arguments=...) at /home/david/buster-fast-bench/2850-pp-parser-window/trees/enumprod/src/buster/compiler/c_preprocessor_history_impl.c:1018
In file included from src/buster/compiler/main.c:164:
src/buster/compiler/x86_64_disassembler.c:382:97: warning: comparison of integers of different signs: 'uint32_t' (aka 'unsigned int') and 'int' [-Wsign-compare]
  382 |                         if (admitted && (!(form->encoding & BUSTER_X86_ENCODING_DIGIT) || digit == (form->encoding & 7)))
      |                                                                                                 ^
In file included from src/buster/compiler/main.c:443:
src/buster/compiler/x86_semantics.c:3007:30: warning: comparison of integers of different signs: 'const uint32_t' (aka 'const unsigned int') and 'int' [-Wsign-compare]
 3007 |         if (logical && count >= 8 * effects->width)
      |                              ^
In file included from src/buster/compiler/main.c:449:
src/buster/compiler/assembler.c:2739:36: warning: comparison of integers of different signs: 'uint32_t' (aka 'unsigned int') and 'int' [-Wsign-compare]
 2739 |             for (uint32_t i = 0; i < instruction->request.count / 2; i += 1)
      |                                    ^
src/buster/compiler/assembler.c:4733:52: warning: unused parameter 'parser' [-Wunused-parameter]
 4733 | static int64_t asm_emit_address32(const AsmParser* parser, const X86Instruction* record, uint8_t* output)
      |                                                    ^
In file included from src/buster/compiler/main.c:468:
src/buster/compiler/x86_semantics_test.c:148:90: warning: unused parameter 'state' [-Wunused-parameter]
  148 | static __attribute__((naked, noinline)) void x86_semantics_test_enter(X86SemanticsState* state)
      |                                                                                          ^
5 warnings generated.
[Inferior 1 (process 3269050) exited normally]
