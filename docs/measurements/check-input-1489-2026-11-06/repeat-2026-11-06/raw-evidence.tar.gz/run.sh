#!/usr/bin/env bash
set -uo pipefail
root="$HOME/buster-fast-bench/1530-codex-repeat"
prior="$HOME/buster-fast-bench/1489-opencode"
workload="$HOME/buster-fast-bench/1340-droid/root"
repo="$HOME/buster-fast-bench/1340-droid/repo"
mkdir "$root" || exit 1
mkdir "$root/raw" "$root/objects" || exit 1
export EXCLUSIVE_OWNER=codex-1530-repeat EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1530 LC_ALL=C
bins=("$prior/pre1049/build/compiler" "$prior/rbase/build/compiler" "$prior/rhead/build/compiler")
names=(pre1049 rbase rhead)
expected=(8c0869bd6e2349fd49865d73541dcc2bcc5002b978ab3b3c410433bff11a0c38 306994c65597df3a51d49b13c7b692f2825689071b4d370c220bee5f3638eac0 731f2adc08f3669ec0a09f0e9cd80746d131a3ee2f753894345930f1ec6ed6b6)
cd "$workload" || exit 1
source "$repo/tools/microarch/workloads.sh"
corpus=corpus
{
 date -Is; uname -a; clang --version | head -1; perf --version
 sed -n '1,/^$/p' /proc/cpuinfo
 printf 'cpu2 governor='; cat /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
 printf 'cpu2 epp='; cat /sys/devices/system/cpu/cpu2/cpufreq/energy_performance_preference
 printf 'thp='; cat /sys/kernel/mm/transparent_hugepage/enabled
 printf 'base=6b3a7ebd150ab6b064eee79d9de42922f4f560c0\nhead=f9d76cdccffe720bc75343bb1a229e876f4110ab\npre1049=aca9e53aa981bb3f61d21cdd5a408ce5167a06f8\nLC_ALL=C\n'
} > "$root/host.txt" 2>&1
for i in 0 1 2; do printf '%s  %s\n' "${expected[i]}" "${bins[i]}"; done > "$root/expected-binaries.sha256"
sha256sum -c "$root/expected-binaries.sha256" > "$root/binaries-before.txt" || exit 1
sha256sum corpus/sqlite/sqlite3.c self-main.i corpus/provenance/gnu17-pinned-predefines.txt predefines-znver5.h "$repo/tools/microarch/workloads.sh" > "$root/inputs-before.sha256"
run_one() {
 local label="$1"; shift
 export EXCLUSIVE_TITLE="PR 1530 compliant repeat $label"
 local status=0
 "$HOME/buster-fast-bench/exclusive.sh" bash -c 'set -u; owner="$1"; out="$2"; err="$3"; shift 3; cat /var/lib/buster-9700x/owner > "$owner"; exec timeout 120s "$@" > "$out" 2> "$err"' \
   -- "$root/raw/$label.owner" "$root/raw/$label.stdout" "$root/raw/$label.stderr" "$@" 2> "$root/raw/$label.lock" || status=$?
 printf '%s\t%d\n' "$label" "$status" >> "$root/status.tsv"
 return "$status"
}
fail=0
for ((r=0;r<11;r++)); do
 for ((j=0;j<3;j++)); do
  idx=$(((j+r)%3)); label="sq-${names[idx]}-$r"; object="$root/objects/$label.o"
  run_one "$label" taskset -c 2 "${bins[idx]}" "${COMMON[@]}" "${SQLITE[@]}" -c -o "$object" --lanes 1 --time-stages || fail=1
  if [[ -f "$object" ]]; then sha256sum "$object" >> "$root/object-hashes.txt"; else fail=1; fi
 done
done
for ((r=0;r<5;r++)); do
 for ((j=0;j<3;j++)); do
  idx=$(((j+r)%3)); label="perf-${names[idx]}-$r"; object="$root/objects/$label.o"
  run_one "$label" taskset -c 2 perf stat -x, -e cycles:u,instructions:u,branches:u,branch-misses:u,task-clock -o "$root/raw/$label.csv" -- "${bins[idx]}" "${COMMON[@]}" "${SQLITE[@]}" -c -o "$object" --lanes 1 || fail=1
  if [[ -f "$object" ]]; then sha256sum "$object" >> "$root/object-hashes.txt"; else fail=1; fi
 done
done
for ((r=0;r<3;r++)); do
 for ((j=0;j<2;j++)); do
  idx=$((1+(j+r)%2)); label="self-${names[idx]}-$r"
  run_one "$label" taskset -c 2 "${bins[idx]}" "${SELF_OPTIONS[@]}" -fsyntax-only self-main.i --time-stages || fail=1
 done
done
sha256sum -c "$root/expected-binaries.sha256" > "$root/binaries-after.txt" || fail=1
sha256sum corpus/sqlite/sqlite3.c self-main.i corpus/provenance/gnu17-pinned-predefines.txt predefines-znver5.h "$repo/tools/microarch/workloads.sh" > "$root/inputs-after.sha256"
cmp "$root/inputs-before.sha256" "$root/inputs-after.sha256" || fail=1
printf '%d\n' "$fail" > "$root/failure"
exit "$fail"
