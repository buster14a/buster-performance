# Issue #1439: CI latency and hardware-window audit

Completed 2026-11-06 at approximately 09:00 UTC. Analysis cutoff: **2026-11-06 07:54 UTC**, matching ledger commit `affb8428e68e8defacbb0cfa4c5fe3993258b564`.

Attribution: **OpenAI / GPT-6 Astra Pro**, child agent task/thread identifier **`/root/latency_audit`**. Parent agent session: `01a1afff-6d1a-7609-84e2-3a5518fc904e`, [claim comment](https://github.com/buster14a/buster/issues/1439#issuecomment-6680768775). The orchestration interface exposes this canonical child identifier; it did not expose a separate child UUID.

## Findings

1. **All 26 admitted nightly hardware jobs acquired and released within 01:00–07:00 UTC (02:00–08:00 Europe/Madrid).** There are zero overlaps among these 26 intervals. First acquisition was 01:01:42.5629467 UTC; final release was 05:37:27.5701772 UTC. No job in this nightly set continued into the ordinary day.
2. **The comprehensive snapshot failed**, despite 125/125 native correctness commands passing. Its floors benchmark failed while calling libc; the coverage record correctly retained outcome `failed`.
3. **111 selected hardware dispatch attempts are not 111 host admissions.** The ledger has 25 successful admitted backlog runs, one admitted failed snapshot, and 85 deferred attempts. Historical workers enforced their old window; see the directly fetched early and late admission logs below.
4. **Latest-100 timing cannot measure PR or main-push latency at this cutoff.** All 100 runs are backlog dispatches: 25 successful hardware jobs and 75 skipped hardware jobs.
5. **A separate, fully checked PR cohort supports lower queue delay than November 5.** All 201 PR workflow job lists were inspected, regardless of workflow result. The 47 successful hardware jobs have queue median/p95 56/931 seconds and lock-wait median/p95 4/274 seconds.
6. **Main pushes do not supply an after-period hardware timing sample.** All 33 post-#1422 push records have `hardware=skip`; 17 outcomes are `deferred` and 16 `blocked-hosted`. Skipped GitHub job/check entries still exist; there was no corresponding hardware execution or successful hardware qualification.

These observations establish bounded overnight execution and immediate main-push hardware suppression. They do not establish a successful full contemporary-main snapshot, completed native coverage for every pending main state, or sustainable backlog capacity.

## Latest-100 report cohort

The workflow-specific runs endpoint was rejected by the connector. Equivalent run selection was reconstructed from the retained repository-run API pages:

- Query: `https://api.github.com/repos/buster14a/buster/actions/runs?per_page=100&page=P&created=%3C%3D2026-11-06T07%3A54%3A00Z`, pages 1 and 2.
- Filter exact path `.github/workflows/9700x.yml`, retain API descending order, select the first 100.
- Newest: [42175219140](https://github.com/buster14a/buster/actions/runs/42175219140), created 06:33:48 UTC.
- Oldest: [42144217065](https://github.com/buster14a/buster/actions/runs/42144217065), created 01:29:52 UTC.
- All 100 events are `workflow_dispatch`; all are nightly backlog runs.
- Every run's latest job list was fetched. No job pagination is missing.
- Exactly 25 hardware jobs concluded `success`; 75 concluded `skipped`.
- PR, main-push and full-snapshot groups have no samples. Their latency is **not zero**.

| Metric | n | Median (s) | p95 (s) |
| --- | ---: | ---: | ---: |
| queue | 25 | 1 | 2 |
| execution | 25 | 292 | 422 |
| runner-hook | 25 | 1 | 1 |
| lock-wait | 25 | 1 | 1 |
| lock-hold | 25 | 286 | 415 |
| setup-build | 25 | 49 | 50 |
| native-tests | 25 | 111 | 114 |
| benchmark-steps | 20 | 94 | 209 |
| host-occupation | 25 | 289 | 420 |

The snapshot predates the oldest run in this latest-100 cohort, and its failed hardware job would also be excluded by the success filter.

## Supplemental PR cohort after #1422

This cohort deliberately supplements, and is not substituted for, the latest-100 report.

The five retained API pages query PR workflows created from November 5 13:40 UTC through November 6 08:40 UTC. They contain 438 repository workflow runs across all workflow paths. Exactly 201 use `9700x.yml`. All 201 were actually created between **November 5 13:52:04 UTC and November 6 01:15:06 UTC**, so none lie after the stated analysis cutoff of November 6 07:54 UTC.

| Workflow conclusion | Workflows | Hardware success | Hardware skipped | Hardware cancelled |
| --- | ---: | ---: | ---: | ---: |
| success | 51 | 47 | 4 | 0 |
| failure | 101 | 0 | 101 | 0 |
| cancelled | 49 | 0 | 2 | 47 |
| Total | 201 | 47 | 107 | 47 |

Every one of the 201 latest-attempt job lists was read. The initial 51-successful-workflow selection was expanded to inspect all remaining 150 workflows; **no additional successful hardware job was found**. Thus the final selection follows `timings.sh`'s **successful hardware job** filter, independent of workflow conclusion. There are no read errors or missing job pages.

| Metric | n | Median (s) | p95 (s) |
| --- | ---: | ---: | ---: |
| queue | 47 | 56 | 931 |
| execution | 47 | 344 | 732 |
| runner-hook | 47 | 4 | 274 |
| lock-wait | 47 | 4 | 274 |
| lock-hold | 47 | 283 | 488 |
| setup-build | 0 | — | — |
| native-tests | 0 | — | — |
| benchmark-steps | 42 | 117.5 | 192 |
| host-occupation | 47 | 287 | 492 |

The complete-native step was skipped in these targeted PR hardware jobs, so the existing timing parser emits no `setup-build` or `native-tests` sample. This does not by itself establish absence of other correctness coverage. The benchmark metric only includes successful steps named with the prefixes used by the existing parser; it does not include every possible timing command.

Examples:

- [First successful PR hardware job in the cohort](https://github.com/buster14a/buster/actions/runs/42040791975/job/127297372943).
- [Most recent successful PR hardware job](https://github.com/buster14a/buster/actions/runs/42141370286/job/127652723785).
- [Longest execution, 1,194 seconds](https://github.com/buster14a/buster/actions/runs/42120777547/job/127577236152); its runner hook/lock wait was 1,132 seconds.

## Before/after interpretation

November 5 baseline: [issue #1207 comment 6662202415](https://github.com/buster14a/buster/issues/1207#issuecomment-6662202415). That comment says the scheduled report did not run and the same report script was executed read-only against the API at 15:35 UTC, sampling its then-latest 100 runs. November 4 baseline: [ci-timings run 41846130451](https://github.com/buster14a/buster/actions/runs/41846130451), [report job 126630090535](https://github.com/buster14a/buster/actions/runs/41846130451/job/126630090535). Its full fetched log is retained here.

| PR metric | November 4 median / p95, s | November 5 median / p95, s | Post-#1422 supplemental cohort median / p95, s |
| --- | ---: | ---: | ---: |
| Queue | 32.5 / 4314 (n=52) | 767 / 4158 (n=33) | 56 / 931 (n=47) |
| Execution | 346 / 517 (n=52) | not provided in cited comment | 344 / 732 (n=47) |
| Runner hook | 1 / 2 (n=52) | 45 / 195 (n=33) | 4 / 274 (n=47) |
| Lock wait | not measured | 45 / 195 (n=33) | 4 / 274 (n=47) |
| Lock hold | not measured | 259 / 512 (n=33) | 283 / 488 (n=47) |
| Host occupation | 342.5 / 514 (n=52) | not provided in cited comment | 287 / 492 (n=47) |

PR queue median is approximately 92.7% lower than November 5, and lock-wait median approximately 91.1% lower. However, November 4's queue median was lower still, PR lock-hold median rose from 259 to 283 seconds, and execution p95 rose from November 4's 517 to 732 seconds. Workload and observation windows differ. The evidence supports improved queue delay relative to the congested November 5 observation, not uniform execution improvement or an isolated causal effect of #1422.

The November 5 main-push sample was n=8, with queue median/p95 2783/4596 seconds, lock-wait 55/458, and lock-hold 257.5/461. The after-period has no admitted main-push hardware jobs. These jobs were deferred to later coverage; missing samples must not be called zero-latency completed coverage.

The November 5 snapshot held the lock for 1,189 seconds. The November 6 snapshot held it for 623.0809016 seconds but terminated on benchmark failure. This is not a successful full-snapshot speedup.

## All admitted nightly hook intervals

All timestamps below are UTC on November 6, 2026, copied from runner hook lines. The release timestamps are the actual lock-release lines, not workflow completion.

| Run / job URL | Job ID | Acquired UTC | Released UTC | Conclusion |
| --- | ---: | --- | --- | --- |
| [42140933052](https://github.com/buster14a/buster/actions/runs/42140933052/job/127640941460) | 127640941460 | 01:01:42.5629467 | 01:12:05.6438483 | failure |
| [42153799671](https://github.com/buster14a/buster/actions/runs/42153799671/job/127683311410) | 127683311410 | 03:00:54.7669115 | 03:03:32.9008423 | success |
| [42154301928](https://github.com/buster14a/buster/actions/runs/42154301928/job/127684802439) | 127684802439 | 03:05:19.7884192 | 03:12:10.0508046 | success |
| [42155141896](https://github.com/buster14a/buster/actions/runs/42155141896/job/127687502916) | 127687502916 | 03:13:12.8403301 | 03:20:03.4511736 | success |
| [42155973317](https://github.com/buster14a/buster/actions/runs/42155973317/job/127690184812) | 127690184812 | 03:21:08.2600620 | 03:25:58.4919168 | success |
| [42156629534](https://github.com/buster14a/buster/actions/runs/42156629534/job/127692318025) | 127692318025 | 03:27:30.7573490 | 03:31:33.3565945 | success |
| [42157110057](https://github.com/buster14a/buster/actions/runs/42157110057/job/127693856971) | 127693856971 | 03:32:15.8863042 | 03:36:12.0265650 | success |
| [42157597663](https://github.com/buster14a/buster/actions/runs/42157597663/job/127695426811) | 127695426811 | 03:37:01.9751869 | 03:40:40.7458356 | success |
| [42158060795](https://github.com/buster14a/buster/actions/runs/42158060795/job/127696950105) | 127696950105 | 03:41:53.8362199 | 03:45:57.5741232 | success |
| [42158677692](https://github.com/buster14a/buster/actions/runs/42158677692/job/127698936805) | 127698936805 | 03:48:14.6994257 | 03:52:30.4263711 | success |
| [42159297897](https://github.com/buster14a/buster/actions/runs/42159297897/job/127700965107) | 127700965107 | 03:54:37.6255652 | 04:00:28.1955615 | success |
| [42160064638](https://github.com/buster14a/buster/actions/runs/42160064638/job/127703454068) | 127703454068 | 04:02:35.1774523 | 04:06:39.9701363 | success |
| [42160710013](https://github.com/buster14a/buster/actions/runs/42160710013/job/127705528855) | 127705528855 | 04:08:55.8911223 | 04:11:35.3396554 | success |
| [42161209612](https://github.com/buster14a/buster/actions/runs/42161209612/job/127707155611) | 127707155611 | 04:13:47.7754589 | 04:18:48.5397328 | success |
| [42161842416](https://github.com/buster14a/buster/actions/runs/42161842416/job/127709210225) | 127709210225 | 04:20:09.1626683 | 04:22:49.2785129 | success |
| [42162328386](https://github.com/buster14a/buster/actions/runs/42162328386/job/127710786230) | 127710786230 | 04:24:59.3888779 | 04:30:43.5633137 | success |
| [42163113176](https://github.com/buster14a/buster/actions/runs/42163113176/job/127713315505) | 127713315505 | 04:32:54.7545136 | 04:39:49.9788504 | success |
| [42163901327](https://github.com/buster14a/buster/actions/runs/42163901327/job/127715891767) | 127715891767 | 04:41:07.5698097 | 04:47:18.3984389 | success |
| [42164668414](https://github.com/buster14a/buster/actions/runs/42164668414/job/127718317297) | 127718317297 | 04:48:53.4209386 | 04:52:21.0024095 | success |
| [42165128077](https://github.com/buster14a/buster/actions/runs/42165128077/job/127719798842) | 127719798842 | 04:53:42.3893976 | 04:58:44.0363137 | success |
| [42165719004](https://github.com/buster14a/buster/actions/runs/42165719004/job/127721720654) | 127721720654 | 05:00:05.6958417 | 05:02:46.9534296 | success |
| [42166210059](https://github.com/buster14a/buster/actions/runs/42166210059/job/127723288848) | 127723288848 | 05:04:56.2691196 | 05:09:50.1363206 | success |
| [42166860032](https://github.com/buster14a/buster/actions/runs/42166860032/job/127725330411) | 127725330411 | 05:11:15.1749606 | 05:16:00.8633789 | success |
| [42167522609](https://github.com/buster14a/buster/actions/runs/42167522609/job/127727440611) | 127727440611 | 05:17:41.9827465 | 05:20:24.0127499 | success |
| [42168000171](https://github.com/buster14a/buster/actions/runs/42168000171/job/127728988529) | 127728988529 | 05:22:24.6868503 | 05:29:59.0323261 | success |
| [42168931833](https://github.com/buster14a/buster/actions/runs/42168931833/job/127732056122) | 127732056122 | 05:32:05.4156487 | 05:37:27.5701772 | success |

Raw hold durations summed before any per-job rounding:

| Set | Count | Total lock hold, seconds |
| --- | ---: | ---: |
| Successful backlog | 25 | 7000.704353800 |
| Failed snapshot | 1 | 623.080901600 |
| All admitted nightly jobs | 26 | 7623.785255400 |

The all-nightly sum is 2 h 7 m 3.7852554 s. Do not treat it as complete host utilization: independent PR or agent work is outside this set. Per-job lock durations in the timing TSVs are rounded to integer seconds to match the existing report, so adding those rounded observations produces a slightly different total.

## Snapshot failure and historical-window evidence

[Snapshot hardware job](https://github.com/buster14a/buster/actions/runs/42140933052/job/127640941460), SHA `0eca996a660548aff827c8b1d08789c413d6eba1):

- Native correctness reported 125 passed, 0 failed, 0 skipped, 0 not started, in 154.4 seconds.
- `Benchmark the floors` failed at approximately 01:12:05 UTC with `the calls on libc.so.6 failed (Success)`, followed by exit code 1.
- Later benchmark steps skipped.
- [Coverage record job](https://github.com/buster14a/buster/actions/runs/42140933052/job/127645042489) records coverage `full`, outcome `failed`.

All 25 successful backlog native suites passed. Their inventories belong to historical revisions: 24 reported 118 commands and the final one 119. This does not establish a successful current-main full snapshot.

Historical-worker refusals inside the new 02:00–08:00 Madrid coordinator window:

- [Early admission log](https://github.com/buster14a/buster/actions/runs/42144585496/job/127652874723), 01:33:27 UTC / 02:33 Madrid: `hardware=skip (window) window: before 04:00 Europe/Madrid`.
- [Late admission log](https://github.com/buster14a/buster/actions/runs/42175219140/job/127752019048), 06:34:18 UTC / 07:34 Madrid: `hardware=skip (window) window: at or after 07:00 Europe/Madrid`.

Both runs have green workflow conclusions with skipped hardware jobs. The success of a dispatch is not evidence of a hardware completion.

## Main-push record check

The retained main-push inventory and pinned ledger contain 33 post-#1422 push records, all `hardware=skip`, `scope=targeted`: 17 `deferred`, 16 `blocked-hosted`. This audit read the ledger without modifying it.

The first and last push job lists were inspected directly:

- [42037894481](https://github.com/buster14a/buster/actions/runs/42037894481): native job 127304243517 and qualification job 127304246250 skipped.
- [42131306512](https://github.com/buster14a/buster/actions/runs/42131306512): native job 127641979641 and qualification job 127641980247 skipped.

Preserve the distinction between skipped hardware admission and final diagnostic outcome. The 16 hosted failures remain visible as `blocked-hosted`, rather than being relabelled `deferred`.

## Scheduled report status

A fresh read at approximately **09:00 UTC on November 6** returned all 35 scheduled repository runs. The newest scheduled run was created at 07:51:58 UTC. The latest `ci-timings.yml` scheduled run remained **November 4 run 41846130451, completed successfully**. There was no November 5 or November 6 scheduled timing run in that complete scheduled inventory.

The complete November 4–5 manual-dispatch inventory (35 runs) contained no timing run. The complete November 6 manual-dispatch inventory (111 runs across two retained pages, with a final refresh confirming the same total and newest run) also contained no timing run. No new November 6 timing-report artifact was available; the after-period tables above are explicitly a read-only reconstruction, not output of a newly executed CI timing workflow.

## Reproducibility and retained files

- `timings-latest100.tsv`: **220 headerless rows**, four fields `job_id<TAB>targeted<TAB>metric<TAB>integer_seconds`.
- `timings-pr-after1422.tsv`: **324 headerless rows**, the same format with group `pr`.
- These are direct inputs for the existing `tools/ci/timings.c` reader. Maintainers can feed each file to an approved build of that reader to reproduce the exact quantiles. No compiler or tests were invoked in this audit.
- `observations.tsv`: all 26 nightly and 47 PR jobs, with API creation/start/completion timestamps, exact hook timestamps, core wide-form metrics and exact job URLs.
- `metrics.json`: final aggregate numbers, complete cohort counts and hook totals.
- `run-inventory.json`: filtered latest-100, all 201 PR runs and the 26 nightly hardware jobs.
- `api/jobs/`: full raw job-list API bodies for all 201 PR runs, all 100 latest-window runs, the separate snapshot, and two representative main pushes: **304 files**.
- `job-*.json` and `job-*-hooks.log`: all **73** selected hardware job objects and extracted original hook/error/native-summary lines.
- `api/`: raw run-page API bodies, including the fixed cutoff, PR query, nightly dispatch inventory, main pushes and final timing-report status checks.
- `request-manifest.json`: exact request URLs, source-tool arguments where relevant, selection rules and artifact mapping.
- `ci-timings-2026-11-04.log`, `snapshot-record.log`, `snapshot-hardware-excerpt.log`, `evidence-0.log`, and `evidence-1.log`: retained report and diagnostic evidence.
- `pr-non-success-workflows.tsv`: explicit cross-check of all 150 non-success PR workflows.

Metrics follow the checked-in report's definitions: queue is job creation to start; execution start to completion; host occupation is `Verify benchmark host` start to job completion; lock wait is runner started-hook start to acquisition; lock hold acquisition to release. Lock durations are rounded to whole seconds. Median uses the midpoint of the two middle observations when even; p95 uses nearest rank `ceil(0.95*n)`.

No external writes or GitHub mutations were performed by this child audit. Temporary local analysis artifacts were written. No build or tests were run locally. The parent owns code changes, follow-up issues and publication.
