;
#define L [
L L __clang__::unused ]] int x;
