;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
#define N 1
int f(int,int); int g(void){return f(3,N);} [[maybe_unused]] int a;
