;
#define N 1
[[maybe_unused]] int a; int f(int,int); int g(void){return f(3,N);}
