;
[[gnu::unused, __clang__::unused]] int x;
