#!/usr/bin/env bash
set -euo pipefail
root="$HOME/buster-fast-bench/1530-current-codex"
workload="$HOME/buster-fast-bench/1340-droid/root"
workload_repo="$HOME/buster-fast-bench/1340-droid/repo"
base=ee089fe78414054d04e5350c48a783e9e2f05af8
head=e94fd0d2bcada50d237ac14206a32cf2b68dc1ff
mkdir "$root" "$root/raw" "$root/objects"
export EXCLUSIVE_OWNER=codex-1530-current EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1530 LC_ALL=C
cd "$root"
git clone --no-checkout https://github.com/buster14a/buster.git repository
git -C repository fetch origin refs/heads/main:refs/remotes/origin/main refs/pull/1530/head:refs/remotes/origin/pr-1530
[[ $(git -C repository rev-parse origin/main) == "$base" && $(git -C repository rev-parse origin/pr-1530) == "$head" ]]
git -C repository worktree add --detach "$root/base" "$base"
git -C repository worktree add --detach "$root/integrated" "$base"
git -C integrated -c user.name='Codex experiment' -c user.email='codex-experiment@localhost' merge --no-commit --no-ff "$head"
printf 'base=%s\nhead=%s\nintegration_tree=%s\nbuild=Clang Release BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0\ncpu=2\n' "$base" "$head" "$(git -C integrated write-tree)" > identities.txt
git -C integrated diff --cached --stat > integration-stat.txt
for variant in base integrated; do
 export EXCLUSIVE_TITLE="PR 1530 current $variant compiler build"
 (cd "$root/$variant" && BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0 "$HOME/buster-fast-bench/exclusive.sh" ./build.sh --jobs 4) > "$root/build-$variant.log" 2>&1
 sha256sum "$root/$variant/build/compiler" >> "$root/binaries.sha256"
done
cd "$workload"
source "$workload_repo/tools/microarch/workloads.sh"
corpus=corpus
{ date -Is; uname -a; clang --version | head -1; perf --version; sed -n '1,/^$/p' /proc/cpuinfo; printf 'cpu2 governor='; cat /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor; } > "$root/host.txt"
sha256sum corpus/sqlite/sqlite3.c self-main.i corpus/provenance/gnu17-pinned-predefines.txt predefines-znver5.h "$workload_repo/tools/microarch/workloads.sh" > "$root/inputs-before.sha256"
bins=("$root/base/build/compiler" "$root/integrated/build/compiler")
names=(base integrated)
run_one() {
 local label="$1"; shift
 export EXCLUSIVE_TITLE="PR 1530 repaired-base $label"
 local status=0
 "$HOME/buster-fast-bench/exclusive.sh" bash -c 'set -u; owner="$1"; out="$2"; err="$3"; shift 3; cat /var/lib/buster-9700x/owner > "$owner"; exec timeout 120s "$@" > "$out" 2> "$err"' -- "$root/raw/$label.owner" "$root/raw/$label.stdout" "$root/raw/$label.stderr" "$@" 2> "$root/raw/$label.lock" || status=$?
 printf '%s\t%d\n' "$label" "$status" >> "$root/status.tsv"
 return "$status"
}
for ((r=0;r<11;r++)); do
 for ((j=0;j<2;j++)); do
  idx=$(((j+r)%2)); label="sq-${names[idx]}-$r"; object="$root/objects/$label.o"
  run_one "$label" taskset -c 2 "${bins[idx]}" "${COMMON[@]}" "${SQLITE[@]}" -c -o "$object" --lanes 1 --time-stages
  sha256sum "$object" >> "$root/object-hashes.txt"
 done
done
for ((r=0;r<5;r++)); do
 for ((j=0;j<2;j++)); do
  idx=$(((j+r)%2)); label="perf-${names[idx]}-$r"; object="$root/objects/$label.o"
  run_one "$label" taskset -c 2 perf stat -x, -e cycles:u,instructions:u,branches:u,branch-misses:u,task-clock -o "$root/raw/$label.csv" -- "${bins[idx]}" "${COMMON[@]}" "${SQLITE[@]}" -c -o "$object" --lanes 1
  sha256sum "$object" >> "$root/object-hashes.txt"
 done
done
for ((r=0;r<3;r++)); do
 for ((j=0;j<2;j++)); do
  idx=$(((j+r)%2)); label="self-${names[idx]}-$r"
  run_one "$label" taskset -c 2 "${bins[idx]}" "${SELF_OPTIONS[@]}" -fsyntax-only self-main.i --time-stages
 done
done
sha256sum -c "$root/binaries.sha256" > "$root/binaries-after.txt"
sha256sum corpus/sqlite/sqlite3.c self-main.i corpus/provenance/gnu17-pinned-predefines.txt predefines-znver5.h "$workload_repo/tools/microarch/workloads.sh" > "$root/inputs-after.sha256"
cmp "$root/inputs-before.sha256" "$root/inputs-after.sha256"
git ls-remote https://github.com/buster14a/buster.git refs/heads/main refs/pull/1530/head > "$root/refs-after.txt"
printf 'done\n' > "$root/complete.txt"
