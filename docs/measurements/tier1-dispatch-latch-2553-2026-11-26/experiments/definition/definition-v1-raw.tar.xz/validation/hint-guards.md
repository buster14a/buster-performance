# Late definition hint eligibility and protected-page checks

These focused checks exercise the vector `tier1_cfg_definition_hints` helper and its interaction with allocation constraints. They supplement the separate positive CFG fixture in `definition-body-fixture.c`; they do not establish a runtime performance improvement.

## Source and results

The test includes the normal allocator and test utilities from compiler commit `8e4d32879e17b7d9548cad54257a2f8461328366`. The only production source override is the experimental definition-only `tier1_cfg.c` in this directory, SHA256 `308189ce8354270996464799b6210a6aa605f6aaa242eb02462e31ccbfbd9a5f`. It does not include the earlier dispatcher-latch candidate or the corridor experiment.

| Run | Checks | Failures | Log |
| --- | ---: | ---: | --- |
| Clang O3 | 111 | 0 | `hint-guards-O3.log` |
| Clang O1, AddressSanitizer and UndefinedBehaviorSanitizer | 111 | 0 | `hint-guards-sanitize.log` |

Both executions returned zero. The sanitizer run emitted no diagnostics. Leak detection was disabled because this environment's process tracing prevents LeakSanitizer from operating; address and undefined-behavior instrumentation remained enabled.

The sources are original C test code under Apache-2.0 WITH LLVM-exception, retaining the repository copyright and license notices. No tracked compiler file was changed by this validation.

## Coverage

`definition-hints-tests.c` contains fifteen explicit rows: an ordinary eligible late definition; an existing operand hint; an existing exit-interval hint; a tie with both hint columns; a phi; a recipe; a definition with no earlier range; an empty slice; a first range spanning the definition; a definition inside a later range rather than at its opening; a gap at the definition; touching half-open ranges; a defining range in the middle of a slice; a seventeen-range slice with the definition at range twelve; and a definition after the last range. The expected changes are specified for these named cases, rather than computed by a scalar implementation of the helper.

Each case runs once with a single value. The recipe case also runs with the optional recipe column absent. Two mixed batches run at each of 0, 1, 2, 15, 16, 17, 31, 32, and 33 values. One ends in a valid longer search, and the other ends in an empty slice. The mixed batches contain searches of different depths and exercise lane ordinals beyond the first vector.

All eight columns read or written by the helper are separate mappings ending directly at a protected page: definitions, phi flags, recipe flags, offsets, starts, ends, value hints, and interval hints. A zero-length column points at the inaccessible page itself. Consequently, the empty last slice also tests that a gather at the end of the pieces array stays masked. The test compares the entire two output columns, including unaffected rows. There are 34 guarded batches, with three checks each: mappings succeeded, value hints match, and interval hints match.

Three additional allocation cases use the same late value with disjoint legal register masks in its body and defining ranges, once per GPR, vector, and mask class. The helper still records the earlier convention. The allocation must pass the existing independent verifier and put both ranges in their respective legal registers. These nine checks establish that the new hint remains a preference and cannot override a hard register constraint.

## Reproduction

The commands below were run from the clean base checkout on an AVX-512 host using the repository's cached Clang 23.1.4 toolchain. The driver includes the normal compiler unity fragments and the new test include. The source override selects the experimental helper without modifying the checkout.

```sh
cd /workspace/scratch/dfc32981403d/buster-base

/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang \
  -march=native -std=gnu17 -fwrapv -funsigned-char -fno-strict-aliasing \
  -O3 -Wall -Werror -Wno-unused-function -Isrc -Isrc/buster/compiler \
  '-DBUSTER_CFG_SOURCE="/workspace/scratch/dfc32981403d/validation/lua-definition-2553/tier1_cfg.c"' \
  /workspace/scratch/dfc32981403d/validation/lua-definition-2553/cfg-hint-guards.c \
  -o /dev/shm/buster-2553-model-vector/cfg-definition-hint-guards-O3 -lpthread -lm

/dev/shm/buster-2553-model-vector/cfg-definition-hint-guards-O3 \
  > /workspace/scratch/dfc32981403d/validation/lua-definition-2553/hint-guards-O3.log 2>&1

/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang \
  -march=native -std=gnu17 -fwrapv -funsigned-char -fno-strict-aliasing \
  -O1 -fsanitize=address,undefined -fno-omit-frame-pointer \
  -Wall -Werror -Wno-unused-function -Isrc -Isrc/buster/compiler \
  '-DBUSTER_CFG_SOURCE="/workspace/scratch/dfc32981403d/validation/lua-definition-2553/tier1_cfg.c"' \
  /workspace/scratch/dfc32981403d/validation/lua-definition-2553/cfg-hint-guards.c \
  -o /dev/shm/buster-2553-model-vector/cfg-definition-hint-guards-sanitize -lpthread -lm

ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
  /dev/shm/buster-2553-model-vector/cfg-definition-hint-guards-sanitize \
  > /workspace/scratch/dfc32981403d/validation/lua-definition-2553/hint-guards-sanitize.log 2>&1
```

For integration, the test include's entry point is `tier1_cfg_test_definition_hint_guards(Tier1CfgTestTally*, Arena*)`. It uses the existing test guard allocator and allocation verifier and needs no new runtime dependency. The positive CFG fixture and full CFG suite have separate evidence records maintained by the other agent.
