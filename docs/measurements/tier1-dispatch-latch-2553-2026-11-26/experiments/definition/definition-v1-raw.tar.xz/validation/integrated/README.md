# Integrated late-definition convention validation

This record covers the integrated production CFG source and tests for the definition-only candidate. It records one full O3 CFG suite and one focused ASan/UBSan run. It does not establish a generated-program performance improvement.

## Source identity

The driver includes `src/buster/compiler/tier1_cfg.c` and `src/buster/compiler/tier1_cfg_test.c` directly from the production checkout, without a source override or copied test implementation.

| File | SHA256 |
| --- | --- |
| `src/buster/compiler/tier1_cfg.c` | `308189ce8354270996464799b6210a6aa605f6aaa242eb02462e31ccbfbd9a5f` |
| `src/buster/compiler/tier1_cfg_test.c` | `e2ac8c2ede46eb80fffcace03f1f546782c9c06ccb2236f4c440782dcd049aa5` |

Both hashes were checked before compilation and after the runs. `integrated-source.patch` reconstructs these two files from base compiler commit `8e4d32879e17b7d9548cad54257a2f8461328366`. The other compiler sources used by the driver are unchanged from that base. `checkout-head.txt` records the checkout's HEAD at validation time; the source above was present as working-tree changes at that point.

The earlier majority-operand latch patch and the later corridor experiment are absent. The production implementation is byte-identical to the previously measured frozen definition-only source. The integrated tests combine `definition-body-fixture.c` and `definition-hints-tests.c`, with array formatting normalized to repository style.

The standalone driver is original C code under Apache-2.0 WITH LLVM-exception and retains the repository copyright notice. Compiler source and tests in the patch retain their own notices.

## Results

| Run | Checks | Failures | Exit status |
| --- | ---: | ---: | ---: |
| Full CFG suite, O3, seed 140, count 2000, oracle every 16 | 107,668 | 0 | 0 |
| Positive CFG fixture plus helper guards, O1, ASan + UBSan | 159 | 0 | 0 |

The full suite made 1,881 allocations and 188 expected constraint refusals. All 1,881 allocations were proved by the allocation certificate; 168 were also checked by the slow oracle. The sparse/dense liveness comparison covered 2,069 cases, and 2,003 sparse live lists agreed with the independent walk. The complete existing mutant and structural-check counters remain in `full-O3.log`.

The focused sanitizer run includes 48 checks from the positive CFG fixture and 111 from the hint-priority, protected-page, tail, and register-constraint tests. Its CFG allocation passed both the certificate and the slow oracle. The run emitted no sanitizer diagnostics. AddressSanitizer and UndefinedBehaviorSanitizer were enabled; leak detection was disabled because LeakSanitizer cannot operate under the environment's process tracing.

No further test runs were performed as part of this integrated validation. Raw logs and saved process exit statuses are included. `SHA256SUMS` covers the record and can be checked from this directory; `source-SHA256SUMS` can be checked from the compiler checkout.

## Exact commands

The build used the repository's cached Clang 23.1.4 toolchain on the local AVX-512 host. Both compiler invocations returned zero with no diagnostics. The two independent builds and then the two independent runs were launched concurrently.

```sh
cd /workspace/scratch/dfc32981403d/buster

sha256sum src/buster/compiler/tier1_cfg.c src/buster/compiler/tier1_cfg_test.c

/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang \
  -march=native -std=gnu17 -fwrapv -funsigned-char -fno-strict-aliasing \
  -O3 -Wall -Werror -Wno-unused-function -Isrc -Isrc/buster/compiler \
  /workspace/scratch/dfc32981403d/validation/lua-definition-2553/integrated-validation/cfg-integrated-validation.c \
  -o /dev/shm/buster-2553-model-vector/cfg-definition-integrated-O3 -lpthread -lm

/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang \
  -march=native -std=gnu17 -fwrapv -funsigned-char -fno-strict-aliasing \
  -O1 -fsanitize=address,undefined -fno-omit-frame-pointer -DBUSTER_CFG_FOCUSED_ONLY \
  -Wall -Werror -Wno-unused-function -Isrc -Isrc/buster/compiler \
  /workspace/scratch/dfc32981403d/validation/lua-definition-2553/integrated-validation/cfg-integrated-validation.c \
  -o /dev/shm/buster-2553-model-vector/cfg-definition-integrated-sanitize -lpthread -lm

/dev/shm/buster-2553-model-vector/cfg-definition-integrated-O3 \
  --seed 140 --count 2000 --oracle-every 16 \
  > /workspace/scratch/dfc32981403d/validation/lua-definition-2553/integrated-validation/full-O3.log 2>&1
cfg_status=$?
printf '%s\n' "$cfg_status" > /workspace/scratch/dfc32981403d/validation/lua-definition-2553/integrated-validation/full-O3.status
cat /workspace/scratch/dfc32981403d/validation/lua-definition-2553/integrated-validation/full-O3.log
exit "$cfg_status"
```

The sanitizer run used a separate shell invocation:

```sh
cd /workspace/scratch/dfc32981403d/buster

ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
  /dev/shm/buster-2553-model-vector/cfg-definition-integrated-sanitize \
  > /workspace/scratch/dfc32981403d/validation/lua-definition-2553/integrated-validation/focused-sanitize.log 2>&1
cfg_status=$?
printf '%s\n' "$cfg_status" > /workspace/scratch/dfc32981403d/validation/lua-definition-2553/integrated-validation/focused-sanitize.status
cat /workspace/scratch/dfc32981403d/validation/lua-definition-2553/integrated-validation/focused-sanitize.log
exit "$cfg_status"
```

To reconstruct the validated files in an isolated checkout, check out the base commit named above and apply `integrated-source.patch`. Build this driver with that checkout's `src` and `src/buster/compiler` include paths. The binaries require the host AVX-512 features used by the compiler.
