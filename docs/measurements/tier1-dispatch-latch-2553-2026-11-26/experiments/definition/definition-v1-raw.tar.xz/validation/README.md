# Issue 2553: late nonphi definition conventions

Exploratory and validation record, 2026-11-26. The candidate is based only on compiler main `8e4d32879e17b7d9548cad54257a2f8461328366`. It does not include the superseded `d3d8ad3` latch-majority rule or the rejected corridor prototype. No native hardware measurement or acceptance is claimed.

## Frozen candidate

- `tier1_cfg.c`: SHA256 `308189ce8354270996464799b6210a6aa605f6aaa242eb02462e31ccbfbd9a5f`
- `definition-hints.patch`: SHA256 `dac68a83e6697b1186b822ddb8bcb75c47651caa42d880864f7b5424b91bd438`
- Positive integration fixture `definition-body-fixture.c`: SHA256 `55843e093ef0385f52b6af0a7eff4d9f76ccec0fdb74c089cde62171b8ca904b`
- Scalar exploration retained as `tier1_cfg-scalar.c` and `definition-hints-scalar.patch`; it is not a second production path.

The new helper runs after existing operand/phi hints and dying-operand tie hints. A nonphi, nonrecipe value whose first interval lies entirely before its definition takes that first interval's opening as the defining interval's hint, only when no existing hint names a value or interval. The defining interval must start exactly at the definition. Existing register constraints, register avoidance, fixed uses, claims, and guarded recipe eviction remain responsible for assignment.

The implementation evaluates sixteen value rows together, performs masked parallel upper-bound searches for their defining intervals, and gathers/scatters only eligible rows. Interval slices are disjoint by value, so every scatter destination is distinct. The search is bounded by the interval-count cap and has logarithmic rounds. All first-range and defining-range accesses are masked, including empty slices and the final partial vector.

## Actual Lua evidence

Baseline Lua 5.4.8 was compiled with the already pinned workload command, including `-Dluai_makeseed(L)=0x2768u`, with the baseline instrumented compiler. Both the captured executable and the tagged executable have SHA256 `2cbe020165695789c6e3f6e02b355f23443b3c24024dac101b3e186f55415a76`.

Capture directory: `/dev/shm/buster-2553-captures/lua-base`.

The `luaV_execute` input snapshot is `lua-p6-f0-b1257-v3506.cfgsnap`, SHA256 `f83abbed43248ce2082c5a9a68a3064c696df061044043f0467643d0b78f4ed5`. A baseline replay reproduces its captured allocation fingerprint `ef2a5e3876a6e20f` and passes the allocation certificate.

The dispatcher is block 1256, with 78 predecessors and 83 successors. Its first handler in layout is block 1. It is itself a multiway join, so the preceding corridor prototype does not model it as a single-successor latch.

The largest remaining repair sequence is edge 1078 to 1256. Baseline per-instruction Callgrind counts across the five existing scripts show 6,371,026 executions of each instruction in two three-move swaps:

- `base` and `k` cross r14 and r15.
- `pc` and the decoded instruction cross rbx and r13.

The first sequence begins at executable address `0x44f63`; the second at `0x44f6c`. Another edge, 853 to 1256, performs the pc/instruction swap 3,514,118 times, starting at `0x43735`.

`k` is nonphi value 3034, defined at position 23875 in late block 1074. Its first handler range holds r14, but its baseline definition has no hint while an unused frame-address recipe occupies r14. The baseline therefore defines k in r15. The new hint invokes the allocator's existing recipe-yielding rule and defines k in r14.

Only the defining hints for Lua values 3032 (`cl`) and 3034 (`k`) change. The hot edge becomes one four-move cycle instead of two three-move swaps. Baseline edge weights therefore predict 12,742,052 fewer instructions on this edge. This is a prediction from identical control-flow input and allocation moves, not yet an emitted-program dynamic result. All other Lua edge move lists are identical; spill slots and fragment counts are unchanged.

The remaining pc/instruction conflict is a different mechanism: the incremented pc is defined while the old pc is still needed by the subsequent instruction load. No instruction-order, call-mask, or call-pool changes are included here.

## Replay outcomes

All five real inputs passed the allocation certificate. The vector candidate's allocation fingerprints exactly match the scalar exploration, including intervals, fragments, spill ownership, edge/split moves and current-slot facts.

| Input | Baseline fragments | Candidate fragments | Spill slots, both | Baseline moves | Candidate moves | Candidate fingerprint |
|---|---:|---:|---:|---:|---:|---|
| Lua, 1257 blocks | 10546 | 10546 | 40 | 577 | 575 | `628b63303053c54b` |
| SQLite f0, 3591 blocks | 70774 | 70775 | 214 | 2385 | 2382 | `72d59ec7c997b17f` |
| SQLite f1, 2080 blocks | 16105 | 16109 | 117 | 899 | 881 | `e306ec9885efa2ec` |
| SQLite f2, 1161 blocks | 10263 | 10267 | 89 | 453 | 444 | `e16d7a0ddab2a998` |
| SQLite f3, 1910 blocks | 7890 | 7892 | 44 | 361 | 356 | `0e8729b8423cadaf` |

Every additional SQLite fragment concerns a constant recipe. There are no added register-to-spill transitions:

| Input | Values | Additional transitions |
|---|---|---|
| f0 | 4594 | One recipe eviction, later recomputed on its outgoing edge |
| f1 | 858, 3178 | Two recipe eviction/recomputation pairs |
| f2 | 2233, 2687 | Two recipe eviction/recomputation pairs |
| f3 | 58 | One recipe eviction/recomputation pair |

The Vdbe changes are localized to inner-loop edges 1952 to 1872 and 2832 to 2829. The original main dispatch-latch convention at blocks 3543 through 3545 is unchanged. The candidate should therefore be described as an evidence-backed definition-convention improvement; it does not independently demonstrate resolution of the original SQLite latch mismatch.

## Validation

The clean baseline CFG suite passes under both scalar and vector versions with identical summaries:

- 107,509 checks, zero failures, seed 140 and 2,000 generated cases.
- 1,880 successful allocations and allocation certificates; 167 also checked by the slow oracle.
- 2,068 dense/sparse allocation comparisons; 2,003 sparse-live-list comparisons.
- Existing constrained-register, fixed-sequence, argument-avoidance, dominator reuse, slot sharing, current-slot and mutant checks pass.

The positive fixture uses five blocks and two values. A recipe is defined at entry, and a later block defines a nonphi loop value. The hot body lies earlier in layout; only a cold branch reads the recipe. The body takes r0, while an unhinted late definition would take r1 because the unused recipe holds r0. A restricted two-register value pool inside a larger class pool exercises the same constrained scan as Lua's callee-register preference.

- Candidate: 48 checks, zero failures; definition and body both use r0, with no repair on the hot edge.
- Baseline control: semantic and certificate checks pass, while exactly the two intended quality assertions fail; definition r1, body r0, one hot-edge repair.

The final fixture differs from the tested logic only in removal of diagnostic printing and one-entry-per-line array formatting. Root is integrating the fixture with separate vector tail, guard-page and rejection coverage for one final combined run.

## Reproduction components

`cfg-replay-vector` includes the repository allocator and certificate implementation directly through `../cfg-snapshot/cfg-replay.c`; `cfg-full-vector` includes the unchanged baseline CFG test suite through `cfg-full.c`. Build flags are `-march=native -std=gnu17 -fwrapv -funsigned-char -fno-strict-aliasing`, with `-O3` for replay and `-O2` for the test driver. LLVM is the repository's pinned 23.1.4 toolchain. The exact snapshot command and compiler arguments are saved in the Lua capture directory.

Logs: `lua-vector.log`, `sqlite-f0-vector.log` through `sqlite-f3-vector.log`, `cfg-full-vector.log`, and the baseline/candidate positive controls. Detailed replay dumps retain interval hints and all fragment and edge locations for independent comparison.

## Rebuilt compiler input and allocation parity

The hosted-built definition candidate generated new workload binaries and five fresh snapshots in `/dev/shm/buster-2553-definition-counts`. The frozen vector replay executable independently replayed every snapshot with `--require-match`; all five matched the captured allocation fingerprint and passed the allocation certificate.

Each fresh snapshot has the same length as its baseline counterpart and differs only at byte offsets 48 through 55, the header's `allocation_hash` field. Every other byte is identical. This checks the complete scalar input, all column descriptors and payloads, including allowed registers, definition constraints, clobber positions/count/masks, fixed ranges, and borrowed dominator analysis. All five text dump headers retain `preference=3`. The preferred allocation problem therefore did not change between the baseline and definition candidate.

The captured hashes are exactly the five previously predicted candidate hashes in the replay table. Machine-record counts change as follows: Vdbe 18,015 to 18,012; the other three captured SQLite functions 10,907 to 10,892, 7,714 to 7,707, and 12,103 to 12,100; Lua 7,119 to 7,117. These are static emitted records, not dynamic instruction counts.

The independent checks are recorded in `actual-input-parity.json` and `lua-actual-vector.log` / `sqlite-f0-actual-vector.log` through `sqlite-f3-actual-vector.log`.
