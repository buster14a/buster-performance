# Integrated v2 definition-hint validation

This record covers one full O3 CFG suite and one combined ASan/UBSan run against the integrated production v2 candidate. The v1 record remains unchanged in its original directory. These correctness and regression checks do not establish a generated-program performance improvement.

## Source identity

The driver includes the production `tier1_cfg.c` and `tier1_cfg_test.c` directly from the checkout, without source overrides or copied test implementations.

| File | SHA256 |
| --- | --- |
| `src/buster/compiler/tier1_cfg.c` | `f87810acea8273edb0ae97ee3f0419eaaf9e4e7ef527a393a6dabde28de59c64` |
| `src/buster/compiler/tier1_cfg_test.c` | `b258d20a4a310bd653cb411e817b8df20d543c95e686ca583016a85d1b5535fe` |

Both hashes matched before compilation and after execution. `integrated-source.patch` records these two files relative to base compiler commit `8e4d32879e17b7d9548cad54257a2f8461328366`. The other compiler sources included by the driver are unchanged from that base. `checkout-head.txt` records HEAD when the files were captured; the validated source included working-tree changes at that point.

The implementation is byte-identical to the frozen v2 source. It preserves final physical-register hints, including those propagated through ties, and runs the new definition/body hint after argument avoidance. The integrated tests contain the original positive body-convention fixture, the new tied call-argument fixture, and the extended protected-page tests. The earlier majority-operand latch and corridor experiments are absent.

The standalone C driver is original code under Apache-2.0 WITH LLVM-exception and retains the repository copyright notice. The compiler source and tests in the patch retain their notices.

## Results

| Run | Checks | Failures | Exit status |
| --- | ---: | ---: | ---: |
| Full CFG suite, O3, seed 140, count 2000, oracle every 16 | 107,778 | 0 | 0 |
| All three focused test sets, O1, ASan + UBSan | 269 | 0 | 0 |

The full suite made 1,882 allocations and 188 expected constraint refusals. All 1,882 allocations were proved by the allocation certificate; 169 were also checked by the slow oracle. There were 2,070 sparse/dense liveness comparisons and 2,003 sparse live lists agreeing with the independent walk. The complete existing mutation, structural, and allocation counters are in `full-O3.log`.

The focused sanitizer run comprises 48 checks from the original body-convention fixture, 56 from the tied call-argument regression, and 165 from the hint-priority, exact-column, vector-tail, and hard-register-mask tests. Both CFG fixtures passed the allocation certificate and slow oracle. The sanitizer run emitted no diagnostics. AddressSanitizer and UndefinedBehaviorSanitizer were enabled; LeakSanitizer was disabled because it cannot operate under this environment's process tracing.

Exactly these two executions were performed for integrated v2 validation. A previously started scratch sanitizer build completed but its executable was not run; the production-based combined run recorded here is the sanitizer result. Earlier scratch O3 results, including the three expected v1 regression failures, are documented in the parent directory.

## Exact commands

The builds used the repository's cached Clang 23.1.4 toolchain on the local AVX-512 host. Both compiler invocations returned zero without diagnostics. The two independent builds and then the two independent runs were launched concurrently.

```sh
cd /workspace/scratch/dfc32981403d/buster

sha256sum src/buster/compiler/tier1_cfg.c src/buster/compiler/tier1_cfg_test.c

/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang \
  -march=native -std=gnu17 -fwrapv -funsigned-char -fno-strict-aliasing \
  -O3 -Wall -Werror -Wno-unused-function -Isrc -Isrc/buster/compiler \
  /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/integrated-validation/cfg-integrated-validation.c \
  -o /dev/shm/buster-2553-model-vector/cfg-definition-v2-integrated-O3 -lpthread -lm

/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang \
  -march=native -std=gnu17 -fwrapv -funsigned-char -fno-strict-aliasing \
  -O1 -fsanitize=address,undefined -fno-omit-frame-pointer -DBUSTER_CFG_FOCUSED_ONLY \
  -Wall -Werror -Wno-unused-function -Isrc -Isrc/buster/compiler \
  /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/integrated-validation/cfg-integrated-validation.c \
  -o /dev/shm/buster-2553-model-vector/cfg-definition-v2-integrated-sanitize -lpthread -lm

/dev/shm/buster-2553-model-vector/cfg-definition-v2-integrated-O3 \
  --seed 140 --count 2000 --oracle-every 16 \
  > /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/integrated-validation/full-O3.log 2>&1
cfg_status=$?
printf '%s\n' "$cfg_status" > /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/integrated-validation/full-O3.status
cat /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/integrated-validation/full-O3.log
exit "$cfg_status"
```

The sanitizer run used a separate shell invocation:

```sh
cd /workspace/scratch/dfc32981403d/buster

ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
  /dev/shm/buster-2553-model-vector/cfg-definition-v2-integrated-sanitize \
  > /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/integrated-validation/focused-sanitize.log 2>&1
cfg_status=$?
printf '%s\n' "$cfg_status" > /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/integrated-validation/focused-sanitize.status
cat /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/integrated-validation/focused-sanitize.log
exit "$cfg_status"
```

To reconstruct the validated files, check out the base commit in an isolated checkout and apply `integrated-source.patch`. Build this driver with that checkout's `src` and `src/buster/compiler` include paths. `source-SHA256SUMS` checks the two production files from the compiler checkout. `SHA256SUMS` checks this evidence directory.
