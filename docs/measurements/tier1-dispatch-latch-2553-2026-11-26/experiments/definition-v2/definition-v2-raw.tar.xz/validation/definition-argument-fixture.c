// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See the buster repository's LICENSE and LICENSING.md.

// The late definition 3 chooses the earlier loop body 1 or call block 4. The body's first range takes r0.
// Block 4's add-like result is tied to the dying root and is read as the call's r1 argument. Another argument lives
// in r2 but is read in r0. The call's r1 hint and avoidance of r0 must reach the root through the tie before a new
// definition/body hint is considered: otherwise the root takes r0, the tie follows it, and the call needs an extra
// argument move. The defining root range spans 3 and 4, so it is both laid after its body and the tie chain's root.
static void tier1_cfg_test_definition_argument(Tier1CfgTestTally* tally, Arena* output, Arena* scratch)
{
    static Tier1CfgTestBuilder builder;
    memset(&builder, 0, sizeof(builder));
    builder.block_count = 5;
    const uint32_t instructions[] = {
        1,
        2,
        1,
        2,
        3,
    };
    for (uint32_t b = 0; b < builder.block_count; b += 1)
    {
        builder.instructions[b] = instructions[b];
    }
    builder.registers[BUSTER_TIER1_ALLOCATE_GPR] = 7;
    builder.scratch[BUSTER_TIER1_ALLOCATE_GPR] = 11;
    builder.use_registers = true;
    const uint32_t edges[][2] = {
        { 0, 3 },
        { 3, 1 },
        { 3, 4 },
        { 1, 1 },
        { 1, 2 },
        { 4, 2 },
    };
    for (uint32_t e = 0; e < BUSTER_ARRAY_LENGTH(edges); e += 1)
    {
        tier1_cfg_test_edge(&builder, edges[e][0], edges[e][1]);
    }
    const uint32_t other = tier1_cfg_test_value(&builder, 0, 0, BUSTER_TIER1_ALLOCATE_GPR, 1u << 2);
    const uint32_t root = tier1_cfg_test_value(&builder, 3, 0, BUSTER_TIER1_ALLOCATE_GPR, 7);
    const uint32_t argument = tier1_cfg_test_value(&builder, 4, 1, BUSTER_TIER1_ALLOCATE_GPR, 7);
    tier1_cfg_test_definition_use(&builder, other);
    tier1_cfg_test_definition_use(&builder, root);
    tier1_cfg_test_definition_use(&builder, argument);
    tier1_cfg_test_use(&builder, root, 1, 0, true);
    tier1_cfg_test_use(&builder, root, 1, 1, true);
    tier1_cfg_test_use(&builder, root, 4, 1, true);
    tier1_cfg_test_use(&builder, other, 4, 2, true);
    builder.use_register[builder.use_count - 1] = 0;
    tier1_cfg_test_use(&builder, argument, 4, 2, true);
    builder.use_register[builder.use_count - 1] = 1;
    const uint64_t saved = output->length;
    Tier1CfgInput input = { 0 };
    bool built = tier1_cfg_test_build(&builder, output, &input);
    uint32_t* ties = built ? arena_push_array(output, 2 * (uint64_t)input.value_count + 1, sizeof(uint32_t), _Alignof(uint32_t)) : 0;
    built = built && ties != 0;
    for (uint32_t k = 0; ties != 0 && k < 2 * input.value_count; k += 1)
    {
        ties[k] = k == 2 * argument ? root : BUSTER_TIER1_CFG_NONE;
    }
    input.ties = ties;
    tier1_cfg_test_expect(tally, built, "a late definition's tied call argument: built");
    if (built)
    {
        const uint64_t mark = output->length;
        Tier1CfgAllocation result = { 0 };
        const Tier1CfgError error = tier1_cfg_allocate(&input, output, scratch, &result);
        Tier1CfgCheck check;
        const bool allocated = error == TIER1_CFG_OK && tier1_cfg_verify(&input, &result, scratch, &check);
        tier1_cfg_test_expect(tally, allocated, "a late definition's tied call argument: allocated");
        const uint32_t call = input.block_starts[4] + 2 * 2;
        const uint32_t root_interval = allocated ? tier1_cfg_interval_oracle(&result, root, input.definitions[root]) : BUSTER_TIER1_CFG_NONE;
        const uint32_t argument_interval = allocated ? tier1_cfg_interval_oracle(&result, argument, call) : BUSTER_TIER1_CFG_NONE;
        const bool intervals = root_interval != BUSTER_TIER1_CFG_NONE && argument_interval != BUSTER_TIER1_CFG_NONE;
        tier1_cfg_test_expect(tally, intervals && result.value_interval_offsets[root] < root_interval &&
                             result.intervals.starts[root_interval] == input.definitions[root] && result.intervals.ends[root_interval] == input.definitions[argument] &&
                             result.intervals.hint_values[argument_interval] == root && result.intervals.hint_intervals[argument_interval] == (root_interval | BUSTER_TIER1_ALLOCATE_HINT_EXIT),
                             "a late definition's earlier body and merged dying root reach the tied result");
        tier1_cfg_test_expect(tally, intervals && result.intervals.register_hints != 0 &&
                             result.intervals.register_hints[root_interval] == 1 && result.intervals.register_hints[argument_interval] == 1,
                             "a late definition retains the call-register hint propagated through its tied result");
        tier1_cfg_test_expect(tally, intervals && result.intervals.avoided_registers != 0 &&
                             result.intervals.avoided_registers[root_interval] == 1 && result.intervals.avoided_registers[argument_interval] == 1,
                             "a late definition and its tied result avoid the other argument's register");
        uint32_t body_register = BUSTER_TIER1_CFG_NONE;
        uint32_t root_register = BUSTER_TIER1_CFG_NONE;
        uint32_t argument_register = BUSTER_TIER1_CFG_NONE;
        uint8_t body_kind = UINT8_MAX;
        uint8_t root_kind = UINT8_MAX;
        uint8_t argument_kind = UINT8_MAX;
        const bool found = allocated && tier1_cfg_location(&result, root, input.block_starts[1], &body_register, &body_kind) &&
                           tier1_cfg_location(&result, root, input.definitions[root], &root_register, &root_kind) &&
                           tier1_cfg_location(&result, argument, call, &argument_register, &argument_kind);
        tier1_cfg_test_expect(tally, found && body_kind == BUSTER_TIER1_ALLOCATE_REGISTER && root_kind == BUSTER_TIER1_ALLOCATE_REGISTER &&
                             argument_kind == BUSTER_TIER1_ALLOCATE_REGISTER && body_register == 0 && root_register == 1 && argument_register == 1,
                             "a late definition's call convention takes priority over its earlier body's register");
        arena_pop_to(output, mark);
        tier1_cfg_test_case(tally, &input, output, scratch, "a late definition's tied call argument", true, 0, 0, true);
    }
    arena_pop_to(output, saved);
}
