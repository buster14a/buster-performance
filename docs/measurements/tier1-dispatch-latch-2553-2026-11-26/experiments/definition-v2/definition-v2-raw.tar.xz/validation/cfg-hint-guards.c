// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See the buster repository's LICENSE and LICENSING.md.
#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BUSTER_ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))
#include "buster/compiler/lane.c"
#include "buster/compiler/dataflow.c"
#include "buster/compiler/dominators.c"
#include "buster/compiler/dominators_export.c"
#include "buster/compiler/dominators_test.c"
#include "buster/compiler/tier1_allocate.c"
#include "buster/compiler/tier1_certificate.c"
#include "buster/compiler/tier1_certificate_interval.c"
#include "buster/compiler/tier1_certificate_oracle.c"
#include BUSTER_CFG_SOURCE
#include "buster/compiler/tier1_certificate_cfg.c"
#include "buster/compiler/tier1_cfg_test.c"
#include "definition-hints-tests.c"
int main(void)
{
    Arena output = arena_reserve(BUSTER_TIER1_CFG_TEST_ARENA);
    Tier1CfgTestTally tally = { 0 };
    tier1_cfg_test_definition_hint_guards(&tally, &output);
    printf("checks=%" PRIu64 " failures=%" PRIu64 "\n", tally.checks, tally.failures);
    arena_release(&output);
    return tally.failures != 0;
}
