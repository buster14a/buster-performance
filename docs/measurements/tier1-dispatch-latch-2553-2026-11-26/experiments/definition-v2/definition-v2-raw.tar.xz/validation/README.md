# Definition-hint call-argument precedence regression

The v2 candidate preserves the final physical register hints, including hints propagated backward through two-address ties. Its definition/body hint runs after argument avoidance. This record contains focused helper tests and the CFG regression that exposed the precedence failure in v1. The separate `integrated-validation` directory records the full suite and combined sanitizer run against the integrated production files.

## Sources

All scratch drivers include the compiler's normal allocator, CFG test utilities, verifier, certificate checker, and slow oracle from base commit `8e4d32879e17b7d9548cad54257a2f8461328366`. The only implementation override is the named experimental CFG source.

| Version | CFG source SHA256 |
| --- | --- |
| v1 | `308189ce8354270996464799b6210a6aa605f6aaa242eb02462e31ccbfbd9a5f` |
| v2 | `f87810acea8273edb0ae97ee3f0419eaaf9e4e7ef527a393a6dabde28de59c64` |

The files are original C tests under Apache-2.0 WITH LLVM-exception, retaining the repository copyright and license notices. The v1 evidence remains in its original directory.

## Focused results

| Test | Version | Checks | Failures | Exit status |
| --- | --- | ---: | ---: | ---: |
| Exact-column helper guards and priority cases | v2 | 165 | 0 | 0 |
| Tied call-argument CFG regression | v1 | 56 | 3 | 1 |
| Tied call-argument CFG regression | v2 | 56 | 0 | 0 |

The three v1 failures are the intended regression assertions: the call's register hint did not reach the late root through its tied result; the other argument's register was not recorded as avoided; and the root/result allocation followed the body's register instead of the call's. Both versions passed semantic verification, the allocation certificate, and the slow oracle for this fixture. The regression concerns allocation quality and precedence.

### Guard and priority cases

The existing fifteen helper cases are retained. Four more cover physical register hint zero, another physical hint, a hint only on an earlier body piece, and a definition in the final piece of a three-piece slice. `UINT8_MAX` means no physical hint and permits the new convention; valid physical hints preserve the existing call convention. The absent physical-hint column is also exercised.

All nine accessed columns end directly at protected pages. The additional byte column has exactly `pieces->count` bytes, with no padding. Singleton cases cover total piece counts 0, 1, 2, and 3. Mixed batches at 0, 1, 2, 3, 15, 16, 17, 31, 32, and 33 values exercise full and partial vectors, divergent searches, a final definition reading the last hint byte, and an empty final slice. Hard register constraints remain independently checked through allocation in all three register classes.

### CFG regression

The five-block fixture has a late definition in layout block 3 that chooses earlier loop body 1 or call block 4. The body range takes r0. The root's defining range continues into block 4 and dies at an add-like tied result; the call reads that result in r1. A second argument is held in r2 but is read by the call in r0.

The existing call-argument pass must propagate r1 and avoidance of r0 backward from the tied result to the root. The new definition/body hint must preserve that result. The test checks the actual range geometry, propagated columns, and allocated locations, then runs the existing semantic, certificate, oracle, dense/sparse, and mutation checks through `tier1_cfg_test_case`.

## Commands

All focused O3 builds used the following toolchain and flags from the base checkout. `cfg-hint-guards.c` ran against v2; `cfg-argument-fixture.c` ran once against v1 and once against v2.

```sh
cd /workspace/scratch/dfc32981403d/buster-base

/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang \
  -march=native -std=gnu17 -fwrapv -funsigned-char -fno-strict-aliasing \
  -O3 -Wall -Werror -Wno-unused-function -Isrc -Isrc/buster/compiler \
  '-DBUSTER_CFG_SOURCE="/workspace/scratch/dfc32981403d/validation/lua-definition-2553/tier1_cfg-v2.c"' \
  /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/cfg-hint-guards.c \
  -o /dev/shm/buster-2553-model-vector/cfg-definition-v2-guards-O3 -lpthread -lm

/dev/shm/buster-2553-model-vector/cfg-definition-v2-guards-O3 \
  > /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/hint-guards-O3.log 2>&1

/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang \
  -march=native -std=gnu17 -fwrapv -funsigned-char -fno-strict-aliasing \
  -O3 -Wall -Werror -Wno-unused-function -Isrc -Isrc/buster/compiler \
  '-DBUSTER_CFG_SOURCE="/workspace/scratch/dfc32981403d/validation/lua-definition-2553/tier1_cfg.c"' \
  /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/cfg-argument-fixture.c \
  -o /dev/shm/buster-2553-model-vector/cfg-definition-v1-argument-O3 -lpthread -lm

/dev/shm/buster-2553-model-vector/cfg-definition-v1-argument-O3 \
  > /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/argument-v1-O3.log 2>&1
# Expected exit status: 1, with exactly the three precedence assertions failing.

/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang \
  -march=native -std=gnu17 -fwrapv -funsigned-char -fno-strict-aliasing \
  -O3 -Wall -Werror -Wno-unused-function -Isrc -Isrc/buster/compiler \
  '-DBUSTER_CFG_SOURCE="/workspace/scratch/dfc32981403d/validation/lua-definition-2553/tier1_cfg-v2.c"' \
  /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/cfg-argument-fixture.c \
  -o /dev/shm/buster-2553-model-vector/cfg-definition-v2-argument-O3 -lpthread -lm

/dev/shm/buster-2553-model-vector/cfg-definition-v2-argument-O3 \
  > /workspace/scratch/dfc32981403d/validation/lua-definition-v2-2553/argument-v2-O3.log 2>&1
```

The raw logs are retained in this directory. The production source, integrated test hashes, exact full-suite and sanitizer commands, source patch, and their logs are recorded in `integrated-validation/README.md`.
