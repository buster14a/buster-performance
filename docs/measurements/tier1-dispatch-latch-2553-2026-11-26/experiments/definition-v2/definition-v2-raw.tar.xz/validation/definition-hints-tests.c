// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See the buster repository's LICENSE and LICENSING.md.

// Explicit rows exercise eligibility and hint priority, including searches of different depths in one vector.
// Every input and output column ends at an inaccessible page. Empty rows may name the first inaccessible element;
// inactive lanes must not read it, and scattering a partial vector must not write beyond the last defining piece.
static void tier1_cfg_test_definition_hint_rows(Tier1CfgTestTally* tally, uint32_t count, uint32_t shape, bool mixed, bool recipes, bool with_registers)
{
    uint32_t definitions[33] = { 0 };
    uint8_t phis[33] = { 0 };
    uint8_t remat[33] = { 0 };
    uint32_t offsets[34] = { 0 };
    uint32_t starts[33 * 17] = { 0 };
    uint32_t ends[33 * 17] = { 0 };
    uint32_t hints[33 * 17];
    uint32_t intervals[33 * 17];
    uint32_t expected_hints[33 * 17];
    uint32_t expected_intervals[33 * 17];
    uint8_t register_hints[33 * 17];
    uint32_t pieces_count = 0;
    for (uint32_t v = 0; v < count; v += 1)
    {
        const uint32_t kind = mixed ? (v + shape) % 19 : shape;
        // The final definition touches the final register-hint byte, or an empty slice points beyond that byte.
        // Both occur in a partial vector at 17/33, while preceding rows exercise searches of different depths.
        const uint32_t row = mixed && v + 1 == count ? (shape == 0 ? 18 : 7) : kind;
        const uint32_t first = pieces_count;
        uint32_t length = 2;
        uint32_t changed = BUSTER_TIER1_CFG_NONE;
        definitions[v] = 10;
        offsets[v] = first;
        starts[first] = 2;
        ends[first] = 4;
        starts[first + 1] = 10;
        ends[first + 1] = 12;
        switch (row)
        {
            case 0: // An ordinary late definition follows the earlier body range.
                changed = first + 1;
                break;
            case 1: // An operand hint already chooses the definition's value convention.
            case 2: // An interval-only hint already chooses a predecessor's exit convention.
            case 3: // A tie supplies both the operand and its closing interval.
                break;
            case 4: // Phi conventions are set by the predecessor/continuation rules.
                phis[v] = 1;
                break;
            case 5: // A recipe keeps its existing treatment; an absent optional column means ordinary values.
                remat[v] = 1;
                changed = recipes ? BUSTER_TIER1_CFG_NONE : first + 1;
                break;
            case 6: // There is no earlier body range to follow.
                length = 1;
                starts[first] = 10;
                ends[first] = 12;
                break;
            case 7: // The value has no ranges, including when first is the end of the guarded allocation.
                length = 0;
                break;
            case 8: // The first range itself contains the definition.
                ends[first] = 12;
                starts[first + 1] = 14;
                ends[first + 1] = 16;
                break;
            case 9: // A range containing, but not opening at, the definition has an established entry convention.
                starts[first + 1] = 8;
                break;
            case 10: // A hole at the definition must not name the next range.
                starts[first + 1] = 12;
                ends[first + 1] = 14;
                break;
            case 11: // Touching half-open ranges still have a completed earlier body convention.
                ends[first] = 10;
                changed = first + 1;
                break;
            case 12: // The definition is in the middle of its slice, with later ranges left untouched.
                length = 3;
                starts[first + 2] = 20;
                ends[first + 2] = 22;
                changed = first + 1;
                break;
            case 13: // A longer slice requires more search steps than the neighboring two-range rows.
                length = 17;
                definitions[v] = 24;
                for (uint32_t r = 0; r < length; r += 1)
                {
                    starts[first + r] = 2 * r;
                    ends[first + r] = 2 * r + 1;
                }
                changed = first + 12;
                break;
            case 14: // No range reaches the definition, even though the first one precedes it.
                starts[first + 1] = 6;
                ends[first + 1] = 8;
                break;
            case 15: // Physical register zero is a real call-argument hint, not an absent hint.
            case 16: // Other physical call-argument registers retain the same precedence.
                changed = with_registers ? BUSTER_TIER1_CFG_NONE : first + 1;
                break;
            case 17: // A body range's physical hint does not choose the later defining range's register.
                changed = first + 1;
                break;
            case 18: // A definition at the third piece reads exactly the last of three register-hint bytes.
                length = 3;
                definitions[v] = 20;
                starts[first + 2] = 20;
                ends[first + 2] = 22;
                changed = first + 2;
                break;
        }
        for (uint32_t r = 0; r < length; r += 1)
        {
            hints[first + r] = BUSTER_TIER1_CFG_NONE;
            intervals[first + r] = BUSTER_TIER1_CFG_NONE;
            register_hints[first + r] = UINT8_MAX;
        }
        if (row == 1 || row == 3)
        {
            hints[first + 1] = v;
        }
        if (row == 2 || row == 3)
        {
            intervals[first + 1] = first | BUSTER_TIER1_ALLOCATE_HINT_EXIT;
        }
        if (row == 15 || row == 16)
        {
            register_hints[first + 1] = row == 15 ? 0 : 3;
        }
        if (row == 17)
        {
            register_hints[first] = 0;
        }
        for (uint32_t r = 0; r < length; r += 1)
        {
            expected_hints[first + r] = hints[first + r];
            expected_intervals[first + r] = intervals[first + r];
        }
        if (changed != BUSTER_TIER1_CFG_NONE)
        {
            expected_hints[changed] = v;
            expected_intervals[changed] = first;
        }
        pieces_count += length;
    }
    offsets[count] = pieces_count;
    DominatorTestGuard guards[] = {
        dominator_test_guard(definitions, count * sizeof(*definitions)),
        dominator_test_guard(phis, count * sizeof(*phis)),
        dominator_test_guard(remat, count * sizeof(*remat)),
        dominator_test_guard(offsets, (count + 1) * sizeof(*offsets)),
        dominator_test_guard(starts, pieces_count * sizeof(*starts)),
        dominator_test_guard(ends, pieces_count * sizeof(*ends)),
        dominator_test_guard(hints, pieces_count * sizeof(*hints)),
        dominator_test_guard(intervals, pieces_count * sizeof(*intervals)),
        dominator_test_guard(register_hints, pieces_count * sizeof(*register_hints)),
    };
    bool guarded = true;
    for (uint32_t g = 0; g < BUSTER_ARRAY_LENGTH(guards); g += 1)
    {
        guarded = guarded && guards[g].mapping != 0;
    }
    char label[160];
    snprintf(label, sizeof(label), "definition hint guard setup: values=%u shape=%u mixed=%u recipes=%u registers=%u", count, shape, mixed, recipes, with_registers);
    tier1_cfg_test_expect(tally, guarded, label);
    if (guarded)
    {
        const Tier1CfgInput input = {
            .definitions = guards[0].data,
            .rematerializable = recipes ? guards[2].data : 0,
            .value_count = count,
        };
        Tier1CfgPieces pieces = {
            .starts = guards[4].data,
            .ends = guards[5].data,
            .hints = guards[6].data,
            .hint_intervals = guards[7].data,
            .count = pieces_count,
        };
        tier1_cfg_definition_hints(&input, guards[1].data, guards[3].data, with_registers ? guards[8].data : 0, &pieces);
        snprintf(label, sizeof(label), "definition value hint eligibility and priority: values=%u shape=%u mixed=%u recipes=%u registers=%u", count, shape, mixed, recipes, with_registers);
        tier1_cfg_test_expect(tally, pieces_count == 0 || memcmp(pieces.hints, expected_hints, pieces_count * sizeof(*expected_hints)) == 0, label);
        snprintf(label, sizeof(label), "definition interval hint eligibility and priority: values=%u shape=%u mixed=%u recipes=%u registers=%u", count, shape, mixed, recipes, with_registers);
        tier1_cfg_test_expect(tally, pieces_count == 0 || memcmp(pieces.hint_intervals, expected_intervals, pieces_count * sizeof(*expected_intervals)) == 0, label);
    }
    for (uint32_t g = 0; g < BUSTER_ARRAY_LENGTH(guards); g += 1)
    {
        if (guards[g].mapping != 0)
        {
            munmap(guards[g].mapping, guards[g].mapping_bytes);
        }
    }
}

// The convention is a preference. A different legal register set at the definition remains a hard constraint,
// regardless of the earlier range's register. Exercise all classes through allocation and its independent verifier.
static void tier1_cfg_test_definition_hint_constraints(Tier1CfgTestTally* tally, Arena* output)
{
    for (uint32_t c = 0; c < BUSTER_TIER1_ALLOCATE_CLASSES; c += 1)
    {
        const uint8_t first_register = c == BUSTER_TIER1_ALLOCATE_MASK ? 1 : 0;
        const uint8_t definition_register = first_register + 1;
        uint32_t starts[] = { 2, 10 };
        uint32_t ends[] = { 4, 12 };
        const uint32_t definitions[] = { 10 };
        const uint8_t phis[] = { 0 };
        const uint32_t offsets[] = { 0, 2 };
        const uint32_t values[] = { 0, 0 };
        const uint32_t allowed[] = { 1u << first_register, 1u << definition_register };
        const uint8_t classes[] = { c, c };
        const uint8_t flags[] = { BUSTER_TIER1_ALLOCATE_REQUIRED, BUSTER_TIER1_ALLOCATE_REQUIRED };
        uint32_t hints[] = { BUSTER_TIER1_CFG_NONE, BUSTER_TIER1_CFG_NONE };
        uint32_t intervals[] = { BUSTER_TIER1_CFG_NONE, BUSTER_TIER1_CFG_NONE };
        const Tier1CfgInput input = {
            .definitions = definitions,
            .value_count = 1,
        };
        Tier1CfgPieces pieces = {
            .starts = starts,
            .ends = ends,
            .hints = hints,
            .hint_intervals = intervals,
            .count = 2,
        };
        tier1_cfg_definition_hints(&input, phis, offsets, 0, &pieces);
        tier1_cfg_test_expect(tally, hints[1] == 0 && intervals[1] == 0, "a late definition keeps an earlier convention as a preference with different masks");
        Tier1AllocationInput intervals_input = {
            .starts = starts,
            .ends = ends,
            .values = values,
            .allowed_registers = allowed,
            .classes = classes,
            .flags = flags,
            .hint_values = hints,
            .hint_intervals = intervals,
            .count = 2,
            .value_count = 1,
            .position_count = 12,
        };
        intervals_input.registers[c] = 7u << first_register;
        const uint64_t saved = output->length;
        Tier1Allocation result = { 0 };
        const Tier1AllocationError error = tier1_allocate(&intervals_input, output, &result);
        const bool allocated = error == TIER1_ALLOCATION_OK && tier1_allocation_verify(&intervals_input, &result);
        tier1_cfg_test_expect(tally, allocated, "a late definition's incompatible range masks allocate and verify");
        Tier1AllocationLocation body = { 0 };
        Tier1AllocationLocation definition = { 0 };
        const bool found = allocated && tier1_allocation_location(&intervals_input, &result, 0, 2, &body) &&
                           tier1_allocation_location(&intervals_input, &result, 1, 10, &definition);
        tier1_cfg_test_expect(tally, found && body.kind == BUSTER_TIER1_ALLOCATE_REGISTER && body.reg == first_register &&
                             definition.kind == BUSTER_TIER1_ALLOCATE_REGISTER && definition.reg == definition_register,
                             "a late definition's hard register mask wins over its earlier body hint");
        arena_pop_to(output, saved);
    }
}

static void tier1_cfg_test_definition_hint_guards(Tier1CfgTestTally* tally, Arena* output)
{
    for (uint32_t shape = 0; shape < 19; shape += 1)
    {
        tier1_cfg_test_definition_hint_rows(tally, 1, shape, false, true, true);
    }
    tier1_cfg_test_definition_hint_rows(tally, 1, 5, false, false, true);
    tier1_cfg_test_definition_hint_rows(tally, 1, 15, false, true, false);
    tier1_cfg_test_definition_hint_rows(tally, 1, 16, false, true, false);
    const uint32_t counts[] = { 0, 1, 2, 3, 15, 16, 17, 31, 32, 33 };
    for (uint32_t k = 0; k < BUSTER_ARRAY_LENGTH(counts); k += 1)
    {
        tier1_cfg_test_definition_hint_rows(tally, counts[k], 0, true, true, true);
        tier1_cfg_test_definition_hint_rows(tally, counts[k], 1, true, false, true);
        tier1_cfg_test_definition_hint_rows(tally, counts[k], 0, true, true, false);
    }
    tier1_cfg_test_definition_hint_constraints(tally, output);
}
