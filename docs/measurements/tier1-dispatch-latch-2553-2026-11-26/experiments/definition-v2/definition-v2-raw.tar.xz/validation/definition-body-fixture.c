// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See the buster repository's LICENSE and LICENSING.md.

// A late definition before a loop in control flow, after it in layout. Entry 0 defines a recipe and enters 3;
// 3 defines a loop value and chooses the hot body 1 or cold block 4, which alone reads the recipe. The body loops
// or exits at 2. The loop value's first range takes r0 while the recipe is not live there. At its later definition,
// the recipe's entry convention holds r0, so an unhinted definition takes r1 and the hot edge repairs it every time.
// Following the earlier body convention lets the existing recipe-yielding rule give the definition r0 instead.
static void tier1_cfg_test_definition_body(Tier1CfgTestTally* tally, Arena* output, Arena* scratch)
{
    static Tier1CfgTestBuilder builder;
    memset(&builder, 0, sizeof(builder));
    builder.block_count = 5;
    const uint32_t instructions[] = {
        1,
        2,
        1,
        2,
        2,
    };
    for (uint32_t b = 0; b < builder.block_count; b += 1)
    {
        builder.instructions[b] = instructions[b];
    }
    // A restricted value pool selects the allocator's recipe-aware scan, as Lua's callee-register preference does.
    builder.registers[0] = 7;
    builder.scratch[0] = 11;
    const uint32_t edges[][2] = {
        { 0, 3 },
        { 3, 1 },
        { 3, 4 },
        { 1, 1 },
        { 1, 2 },
        { 4, 2 },
    };
    for (uint32_t e = 0; e < BUSTER_ARRAY_LENGTH(edges); e += 1)
    {
        tier1_cfg_test_edge(&builder, edges[e][0], edges[e][1]);
    }
    const uint32_t recipe = tier1_cfg_test_value(&builder, 0, 0, 0, 3);
    const uint32_t value = tier1_cfg_test_value(&builder, 3, 0, 0, 3);
    builder.remat[recipe] = 1;
    tier1_cfg_test_definition_use(&builder, recipe);
    tier1_cfg_test_definition_use(&builder, value);
    tier1_cfg_test_use(&builder, value, 1, 0, true);
    tier1_cfg_test_use(&builder, value, 1, 1, true);
    tier1_cfg_test_use(&builder, recipe, 4, 1, true);
    const uint64_t saved = output->length;
    Tier1CfgInput input = { 0 };
    const bool built = tier1_cfg_test_build(&builder, output, &input);
    tier1_cfg_test_expect(tally, built, "a late definition's body convention: built");
    if (built)
    {
        const uint64_t mark = output->length;
        Tier1CfgAllocation result = { 0 };
        const Tier1CfgError error = tier1_cfg_allocate(&input, output, scratch, &result);
        Tier1CfgCheck check;
        const bool allocated = error == TIER1_CFG_OK && tier1_cfg_verify(&input, &result, scratch, &check);
        tier1_cfg_test_expect(tally, allocated, "a late definition's body convention: allocated");
        uint32_t at_definition = BUSTER_TIER1_CFG_NONE;
        uint32_t at_body = BUSTER_TIER1_CFG_NONE;
        uint8_t definition_kind = UINT8_MAX;
        uint8_t body_kind = UINT8_MAX;
        const bool found = allocated && tier1_cfg_location(&result, value, input.definitions[value], &at_definition, &definition_kind) &&
                           tier1_cfg_location(&result, value, input.block_starts[1], &at_body, &body_kind);
        tier1_cfg_test_expect(tally, found && definition_kind == BUSTER_TIER1_ALLOCATE_REGISTER && body_kind == BUSTER_TIER1_ALLOCATE_REGISTER && at_definition == at_body,
                             "a late definition takes its body's register from an unused recipe");
        tier1_cfg_test_expect(tally, allocated && tier1_cfg_test_edge_moves(&input, &result, 3, 1) == 0,
                             "a late definition's hot edge needs no repair");
        arena_pop_to(output, mark);
        tier1_cfg_test_case(tally, &input, output, scratch, "a late definition's body convention", true, 0, 0, true);
    }
    arena_pop_to(output, saved);
}
