# Actual v2 compiler snapshots: independent replay

All five fresh snapshots emitted by the hosted v2 compiler replay successfully with `--require-match`. Allocation and certificate status are zero in every case. Their hashes also equal the predictions previously obtained by applying the frozen v2 allocator to baseline inputs.

The production allocator and frozen `validation/lua-definition-2553/tier1_cfg-v2.c` are byte-identical, SHA256 `f87810acea8273edb0ae97ee3f0419eaaf9e4e7ef527a393a6dabde28de59c64`. The existing O3 replay binary was compiled from that frozen source. No production files were modified for this independent review.

## Results

| Snapshot | Allocation hash | Prediction and capture match | Input-column parity |
| --- | --- | --- | --- |
| inputs-p13-f0-b3591-v8108.cfgsnap | `2aa861ee0480fdbb` | yes | exact |
| inputs-p13-f1-b2080-v5192.cfgsnap | `f61abfe04d9bb442` | yes | exact |
| inputs-p13-f2-b1161-v2741.cfgsnap | `df6216f467f63cd3` | yes | exact |
| inputs-p13-f3-b1910-v4020.cfgsnap | `c7ea7cf07dff2423` | yes | exact |
| inputs-p14-f0-b1257-v3506.cfgsnap | `628b63303053c54b` | yes | exact |

Each snapshot has the same byte length as its baseline counterpart. The only differing bytes are offsets 48–55, the snapshot header’s `allocation_hash` field. Every byte of the actual CFG inputs is unchanged: definitions, uses and their preferred registers, allowed masks, fixed constraints, clobber positions and masks, sequences, recipes, ties, graph and phi columns, and dominators. This is stronger than comparing selected counts. The diagnostic emitter headers retain `preference=3` for all five functions.

`actual-input-parity.json` records source paths, full snapshot SHA256 values, exact differing offsets, prediction hashes, exit statuses and complete replay output. The individual logs retain the allocator/certificate counts.

## Reproduction

Use the existing O3 reader, or rebuild `validation/lua-definition-2553/cfg-replay-hints.c` with `BUSTER_CFG_SOURCE` naming the frozen v2 source and the baseline source include path, as recorded in the parent evidence. These commands reproduce the five capture/hash/certificate checks:

```sh
/workspace/scratch/dfc32981403d/validation/lua-definition-2553/cfg-replay-v2 \
  /dev/shm/buster-2553-definition-v2-counts/inputs-p13-f0-b3591-v8108.cfgsnap --require-match
/workspace/scratch/dfc32981403d/validation/lua-definition-2553/cfg-replay-v2 \
  /dev/shm/buster-2553-definition-v2-counts/inputs-p13-f1-b2080-v5192.cfgsnap --require-match
/workspace/scratch/dfc32981403d/validation/lua-definition-2553/cfg-replay-v2 \
  /dev/shm/buster-2553-definition-v2-counts/inputs-p13-f2-b1161-v2741.cfgsnap --require-match
/workspace/scratch/dfc32981403d/validation/lua-definition-2553/cfg-replay-v2 \
  /dev/shm/buster-2553-definition-v2-counts/inputs-p13-f3-b1910-v4020.cfgsnap --require-match
/workspace/scratch/dfc32981403d/validation/lua-definition-2553/cfg-replay-v2 \
  /dev/shm/buster-2553-definition-v2-counts/inputs-p14-f0-b1257-v3506.cfgsnap --require-match
```

For exact input parity, compare each fresh snapshot with the `baseline_input` path in the JSON and exclude only bytes 48 through 55; lengths and every remaining byte must agree.

## Final source and scope review

The production diff relative to `8e4d32879e17b7d9548cad54257a2f8461328366` contains one new allocator helper and its invocation, two focused CFG regressions, guarded helper/constraint tests, and documentation. No discarded majority/corridor heuristic or call mask/pool change remains.

The helper writes only unhinted defining intervals of nonphi, nonrecipe values whose disjoint earlier range has already closed. It preserves final physical-register hints by running after argument propagation. Its masked upper-bound search is bounded by the existing interval limit; scatter destinations belong to disjoint value slices. The byte-column windows stay inside exact allocations, including columns shorter than four bytes. Hard register constraints still belong to the existing allocator. No correctness, aliasing or memory-safety blocker was identified in the final source or integrated tests.

The reviewed production test file has SHA256 `b258d20a4a310bd653cb411e817b8df20d543c95e686ca583016a85d1b5535fe`. The integrated suite is separately recorded in `../integrated-validation/README.md`: 107,778 full-suite checks and 269 focused ASan/UBSan checks, all passing. Those runs were not repeated here.

The documentation accurately limits the change to late nonphi definitions and explicitly states that SQLite’s main dispatch latch is unchanged. At review time the measurement link still pinned the earlier v1/static record at commit `44f2a6d2e238c93a0d99d2e8f9644b289ded20fc`; it must be repinned to the final v2 evidence before publication. The completed v2 generated-program measurement is recorded separately by the measurement owner; it reports SQLite instructions decreasing by 979,244 and confirms Btree returns exactly to baseline. This independent replay review did not rerun Callgrind. The remaining per-function instruction tradeoffs and the unchanged main latch should remain explicit in the final PR and measurement record.
