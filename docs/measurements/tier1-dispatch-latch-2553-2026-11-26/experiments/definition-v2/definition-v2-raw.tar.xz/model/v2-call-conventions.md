# Definition hints v2: preserve call argument conventions

This measurement candidate is based on buster main `8e4d32879e17b7d9548cad54257a2f8461328366`. It contains only the late nonphi, nonrecipe definition hint plus the v2 call-argument precedence guard. The discarded latch/corridor proposals and call mask/pool policy are unchanged from main.

## Frozen source

- `tier1_cfg-v2.c`: SHA256 `f87810acea8273edb0ae97ee3f0419eaaf9e4e7ef527a393a6dabde28de59c64`.
- `definition-hints-v2.patch`: SHA256 `8d87718046ee258b1a8705873547ba0f3dbad9a333bef9f82330e2010e06dbc3`.
- `cfg-replay-v2` is an O3 standalone replay built with that source and the existing snapshot/certificate driver. `cfg-replay-hints.c` adds final physical-register hints, avoided masks and ties to the textual dump only.

## Why v1 needed refinement

The first definition candidate placed a value/interval hint before `tier1_cfg_argument_avoidance`. That existing phase propagates a dying call argument's register preference and the other arguments' avoided registers backward along eligible two-address ties. Its root must have no existing value/interval hint. A new body hint could therefore prevent an existing argument convention from reaching the root definition.

The actual `sqlite3BtreeIndexMoveto` capture gives a concrete case. Snapshot `/dev/shm/buster-2553-call-hints/base/inputs-p6-f61-b93-v370.cfgsnap` has 93 blocks, 370 values, and 665 emitted machine records in the baseline tagged program. Defining value v243's interval I426 is [2119,2159); its earlier body convention is I424. An add-one value v248 starts at 2159, ties to v243, and dies as the RSI call argument at 2162.

| State | Root value hint | Root physical hint | Root avoided mask | Root/result register |
|---|---|---|---|---|
| Baseline | none | RSI (6), propagated | 0x484 | R8 |
| v1 | v243 / I424 | none (255) | 0 | RDX |
| v2 | none | RSI (6), propagated | 0x484 | R8 |

RDX was also the destination for another argument held in RSI. Baseline call setup used `RSI -> RDX; R8 -> RSI`; v1 used `RSI -> R11; RDX -> RSI; R11 -> RDX`. This added one instruction on a call executed 1,037,030 times. It did not change call saves or caller/callee register masks.

V2 runs the new definition helper once, after existing argument avoidance/propagation is complete, and skips a defining interval with a physical register hint other than UINT8_MAX. Existing value and named interval hints retain their earlier guards. This covers both direct arguments and roots reached through existing ties, without predicting or duplicating tie propagation.

## Exact byte-column access

The optional physical-register column has one byte per interval. The vector helper gathers a 32-bit window beginning at `min(own, count - 4)` when `count >= 4`; all four bytes are inside the exact column. It shifts the requested byte into the low 8 bits. For `count < 4` it performs one masked byte load and broadcasts the word, then shifts each lane's byte. It reads no padding and uses no new scalar loop or temporary column. All other eligibility and defining-range searches remain masked 16-value operations. Interval count is capped by the existing allocator at 2^20.

## Real replay results

All six replays completed with allocation status 0 and certificate status 0. The five large snapshots came from the actual v1 instrumented compiler; their inputs were previously shown byte-identical to baseline apart from the stored allocation hash. No call clobber or preferred problem data was changed.

| Input | Baseline moves | v1 moves | v2 moves | v2 fragments | Spill slots | v2 allocation hash |
|---|---:|---:|---:|---:|---:|---|
| Lua luaV_execute |577|575|575|10546|40|628b63303053c54b|
| SQLite f0 / sqlite3VdbeExec |2385|2382|2383|70775|214|2aa861ee0480fdbb|
| SQLite f1 |899|881|888|16109|117|f61abfe04d9bb442|
| SQLite f2 |453|444|446|10265|89|df6216f467f63cd3|
| SQLite f3 |361|356|359|7890|44|c7ea7cf07dff2423|
| sqlite3BtreeIndexMoveto |34|34|34|562|3|4adeaee6301ad982|

Lua's complete allocation fingerprint equals v1. Btree's fingerprint and complete diagnostic dump equal baseline, including register hints and avoided masks. The v1 dynamic benefit observed under stable argv[0] was 12,742,604 fewer whole-program Lua instructions (12,742,052 in luaV_execute), all removed edge-register moves. V2 emitted-program dynamic measurements are still required; replay parity predicts the same Lua benefit and elimination of the identified Btree regression.

In Vdbe, v2 retains the edge 1952->1872 repair reduction. It restores the baseline edge 2832->2829 move for v6638 because that definition's call convention takes precedence. The main dispatch latch is unchanged.

There are no added register-to-spill transitions in the five large CFGs. Extra fragments concern only existing constant recipes: f0 I54727 gains one eviction fragment; f1 I7161/I11721 and f2 I9851 gain eviction/recompute pairs; f3 and Lua gain no fragments. `v2-fragment-audit.json` retains the exact fragment ranges and kinds. `v2-replay-results.json` retains full replay output and paths.

## Test state

The independent v2 guard suite passes 165 checks at O3, including exact 0/1/2/3-byte columns, physical register 0, absent column, UINT8_MAX, and final-byte gathers across partial vector batches. A focused end-to-end tie-propagation regression and sanitizer run are being completed separately. The full baseline suite had already passed 107,509 checks with v1; v2 integration must be checked before promotion.
