#!/usr/bin/env bash
# Scratch-only process glue around the pinned workload programs and gap.c.
set -euo pipefail
out=$(realpath "$1")
task=$(cd -- "$(dirname -- "$0")/.." && pwd)
inputs=${INPUTS:-$task/inputs-2553}
oracle=${ORACLE:-$task/outputs-2553/oracle}
gap=${GAP:-$inputs/gap}
valgrind=${VALGRIND:-$task/valgrind-2553/usr/bin/valgrind}
export VALGRIND_LIB=${VALGRIND_LIB:-$task/valgrind-2553/usr/libexec/valgrind}
debug=${VALGRIND_DEBUG:-$task/valgrind-2553/usr/lib/debug}
export LC_ALL=C
options=(--shrink-memory --reprepare --stats --journal wal --size 5 --heap 40000000 64 --testset mix1)
valgrind_options=(--tool=callgrind --dump-instr=yes "--extra-debuginfo-path=$debug")
run=$(mktemp -d /dev/shm/sqlite-2553.XXXXXX)
trap 'rm -rf -- "$run"' EXIT
mkdir "$run/tmp"
cd "$run"
SQLITE_TMPDIR="$run/tmp" "$out/speedtest1" "${options[@]}" --verify verify.db > "$out/speedtest1.out" 2>&1
rg 'Verification Hash:' "$out/speedtest1.out" > "$out/speedtest1.verify"
rg 'Verification Hash:' "$oracle/speedtest1.out" > "$out/oracle.verify"
cmp "$out/oracle.verify" "$out/speedtest1.verify"
rm -f verify.db verify.db-wal verify.db-shm
SQLITE_TMPDIR="$run/tmp" "$valgrind" "${valgrind_options[@]}" "--callgrind-out-file=$out/speedtest1.cg" "$out/speedtest1" "${options[@]}" count.db > "$out/speedtest1.callgrind.out" 2> "$out/speedtest1.callgrind.log"
cd "$inputs/scripts"
for name in arithmetic calls tables strings closures; do
    "$out/lua" "$name.lua" > "$out/$name.native.out"
    cmp "$oracle/$name.out" "$out/$name.native.out"
    "$valgrind" "${valgrind_options[@]}" "--callgrind-out-file=$out/$name.cg" "$out/lua" "$name.lua" > "$out/$name.out" 2> "$out/$name.callgrind.log"
    cmp "$oracle/$name.out" "$out/$name.out"
done
cd "$out"
objdump -d --no-show-raw-insn speedtest1 > speedtest1.dis
objdump -d --no-show-raw-insn lua > lua.dis
for name in speedtest1 arithmetic calls tables strings closures; do
    binary=lua
    if [ "$name" = speedtest1 ]; then binary=speedtest1; fi
    kinds=()
    if [ -s "$binary.kinds" ]; then kinds+=("$binary.kinds"); fi
    "$gap" count "$binary.dis" "$name.cg" '???' 0x108000 "${kinds[@]}" > "$name.tsv" 2> "$name.gaperr"
    # Preserve unmatched counts for review: Callgrind's ??? also holds anonymous external stubs.
    gzip -f "$name.cg"
done
{
    cat speedtest1.verify
    for name in speedtest1 arithmetic calls tables strings closures; do
        awk -F '\t' -v name="$name" '$1 !~ /^#/ { mapped += $4 } $1 == "#total" { total = $2 } $1 == "#check" { printf "%s\t%s\t%s\n", name, $2, $3 } END { printf "%s\tprogram_instructions\t%.0f\n%s\tanonymous_object_total\t%s\n", name, mapped, name, total }' "$name.tsv"
    done
} > counts.txt
cat counts.txt
