# Temporary CFG input snapshots and replay for issue 2553

This directory contains measurement support for diagnosing the dispatcher latch convention. It changes no tracked compiler source. The writer is a separate patch applied after the existing temporary emission-tag patch. The reader includes the compiler's own allocator and CFG certificate implementation directly.

The source layouts are those at compiler base `8e4d32879e17b7d9548cad54257a2f8461328366` and initial candidate `d3d8ad3bc7373a58e62b3eb3ecb32a0001c61167`. A snapshot is for Linux/x86-64 with the same C structure layout, integer representation and compiler source interface. It is bounded temporary trusted data, not a portable or hostile-input interchange format.

## Writer patch

Apply `snapshot-after-tags.patch` after `kinds-main-8e4d3287.patch`. Its SHA-256 is:

```text
3b452cf9c9040e3acf1aaa15889e43d8b26ae96b7687062b6fa367a79bd3fe24
```

The patch adds `src/buster/compiler/tier1_cfg_snapshot.c` and includes it only under `BUSTER_TIER1_MEASURE_KINDS` at the existing emission dump. Set an existing output-directory prefix and the existing minimum block threshold:

```sh
mkdir -p /tmp/cfg-snapshots
BUSTER_TIER1_CFG_SNAPSHOT=/tmp/cfg-snapshots/sqlite \
BUSTER_TIER1_DUMP_BLOCKS=1000 \
    /path/to/instrumented/buster /the/original/compiler/arguments
```

`BUSTER_TIER1_DUMP_FILE` is not required for snapshot capture. The filenames contain the prefix, process ID, process-local serial, block count and value count, for example `sqlite-p123-f0-b5000-v30000.cfgsnap`. Exclusive file creation prevents overwriting an existing snapshot. A reused prefix and PID can cause a collision; use a fresh output directory for each run. Success or failure is reported on stderr. Capture happens after successful function emission.

The format records every scalar of `Tier1CfgInput` and `Dominators`, plus 31 input pointer columns and 16 dominator pointer columns in an explicit table of owner, field offset, element width, count and nullness. Raw pointers are zeroed in the serialized structures. This preserves fixed intervals, optional use columns, edge copies, slot widths, ties, sequences, clobbers, and the complete borrowed dominator analysis, including its optional frontier and loop data. Dominators are not recomputed on replay. Present zero-length columns remain distinguishable from null columns.

One emitter detail requires reconstruction: when `tier1_emit_cfg_one_call` adopts a preferred allocation, it updates the final input's allowed register sets and general registers, while the adopted clobbers remain in `cfg.intervals`. The writer takes those clobber positions, count and register masks from the assigned intervals into its private snapshot input. It does not change the emitter's input. Without that step, replay could allocate a different problem.

The header also stores a fingerprint of interval boundaries/value IDs, allocated fragments, spill ownership, resolved edge/split moves, and current-slot assertions. It excludes arena addresses, padding and unused array capacity. The reader's `--require-match` flag makes a mismatch fail; omit the flag when intentionally testing a changed allocator and inspect the reported difference.

## Build and run the reader

`cfg-replay.c` and `tier1_cfg_snapshot.c` must be in the same directory. From the compiler checkout whose allocator is being tested:

```sh
CLANG=/home/agent/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
SUPPORT=/workspace/scratch/dfc32981403d/validation/cfg-snapshot
"$CLANG" -march=native -std=gnu17 -fwrapv -funsigned-char \
    -fno-strict-aliasing -O3 -Wall -Werror -Wno-unused-function \
    -Isrc "$SUPPORT/cfg-replay.c" -o "$SUPPORT/cfg-replay-O3" -lpthread -lm
"$SUPPORT/cfg-replay-O3" /path/to/input.cfgsnap \
    --require-match --dump /path/to/replay.dump
```

The executable validates the magic, version, ABI sizes, endianness marker, table schema, count bounds, zeroed pointers, payload size, file length and CSR-style offset bounds. It restores all arrays, runs `tier1_cfg_allocate`, prints allocation counts and the captured/replayed fingerprints, and runs `tier1_certificate_cfg_check`. The text dump includes blocks, predecessor-ordered phi operands, value definitions/constraints/uses, every interval's value/exit/alternate/continuation hints, fragment locations, and resolved edge moves. It has no source IR node mapping because that is outside `Tier1CfgInput`.

The reader reserves separate virtual arenas: 8 GiB for snapshot columns and 4 GiB each for output and scratch. Physical pages are committed by the project's arena as needed. It does not invoke the compiler's parser, selector, emission, assembly or linker.

`BUSTER_CFG_SOURCE` can name a temporary alternative `tier1_cfg.c` at build time, using the same macro pattern as `cfg-validation.c` in the validation evidence record. Alternatively, compile this driver from another compiler checkout with that checkout's `-Isrc`.

## Concrete local round-trip checks

`writer-check.c` uses the existing 8-block/5-value dispatch-latch regression and its existing checkers. Its first captured case is the tie/no-majority control because that is first in the existing focused driver's order; it is a serialization and replay check, not a base-versus-candidate improvement test. Build it from candidate `d3d8ad3`:

```sh
"$CLANG" -march=native -std=gnu17 -fwrapv -funsigned-char \
    -fno-strict-aliasing -O0 -Wall -Werror -Wno-unused-function \
    -Isrc -DBUSTER_CFG_FOCUSED_ONLY "$SUPPORT/writer-check.c" \
    -o "$SUPPORT/writer-check" -lpthread -lm
mkdir -p /tmp/cfg-roundtrip
BUSTER_TIER1_CFG_SNAPSHOT=/tmp/cfg-roundtrip/input "$SUPPORT/writer-check"
for snapshot in /tmp/cfg-roundtrip/*.cfgsnap; do
    "$SUPPORT/cfg-replay-O3" "$snapshot" --require-match --dump "$snapshot.dump" || exit
done
```

Four captures and replays passed:

| Capture | Nonzero extra input | Captured/replayed fingerprint | Certificate |
| --- | --- | --- | --- |
| Original fixture | No supplied dominators | `b008b84355bb051f` | status 0 |
| Original fixture with supplied analysis | Complete dominator tree/frontier/loop arrays | `b008b84355bb051f` | status 0 |
| Optional columns | Fixed interval, clobber, sequence and all sequence columns; ties, use registers, edge copies, slot widths; supplied dominators | `d9b2ee0c69d059de` | status 0 |
| Actual one-call order | Preferred wider register sets and one clobber adopted via `tier1_cfg_order_prepare`/`tier1_cfg_order_run`; emitter-style stale final clobbers | `7a9e413f544549dd` | status 0 |

The last case reported `status=0 preferred=0 taken=1 actual_clobbers=1`. The existing focused suite reported 304 checks and zero failures. These checks establish small-fixture round-trip behavior, including preferred clobber recovery. Actual SQLite snapshot parity remains a separate required check before using a replay to explain that workload.

The same reader was also compiled at `-O3` from the base checkout into `cfg-replay-base-O3`. The unmodified tie-control snapshot and the same-SSA-operand probe below reproduce their captured fingerprints and pass the certificate with both base and initial candidate, which is expected because the initial candidate does not improve those cases.

## Scratch same-SSA-operand probe

`cfg-same-up.c`, `tier1_cfg_same_up_test.c` and `same-up-experiment.patch` are an uncommitted experiment, separate from the writer patch. The dispatch-latch fixture's cold operand also names the loop-carried value, while its cold block still displaces that value's register. The driver runs the two predecessor orderings with the positive convention assertions. The recipe remains as local pressure but is no longer a latch operand, so its location is checked at its definition rather than at the latch boundary.

Build with the additional compiler-directory include for the temporary test copy's nested includes:

```sh
cp src/buster/compiler/tier1_cfg_test.c "$SUPPORT/tier1_cfg_same_up_test.c"
patch "$SUPPORT/tier1_cfg_same_up_test.c" "$SUPPORT/same-up-experiment.patch"
"$CLANG" -march=native -std=gnu17 -fwrapv -funsigned-char \
    -fno-strict-aliasing -O0 -Wall -Werror -Wno-unused-function \
    -Isrc -Isrc/buster/compiler "$SUPPORT/cfg-same-up.c" \
    -o "$SUPPORT/cfg-same-up" -lpthread -lm
BUSTER_TIER1_CFG_SNAPSHOT=/tmp/cfg-roundtrip/same-up "$SUPPORT/cfg-same-up"
```

At `d3d8ad3`, this probe reported 112 checks and four expected failures: the latch-convention and zero-hot-edge-moves assertions in each predecessor row order. The semantic verifier and certificate checks passed. The hot carried interval was `I4=[8,32)` in register 0, the cold carried interval `I5=[32,40)` in register 1, and the latch phi `I3=[40,48)` used exit hint `0x80000005` and register 1. Each of the three hot incoming edges moved register 0 to 1; the latch-to-header edge moved it back to 0. Removing only the candidate's `operand != up` guard would still leave its helper selecting the nearest matching cold predecessor.

### Header with a separate later dispatcher

`cfg-same-up-two-hop.c` and `same-up-two-hop-experiment.patch` extend the same experiment to nine blocks. The patch is relative to the original candidate test file, not to the preceding experiment. Copy the original to `tier1_cfg_same_up_two_hop_test.c`, apply this patch to that copy, and compile the driver with the same flags. Header block 6 has a default edge back to latch 5 and a forward edge to dispatcher 7; dispatcher 7 branches to handlers 1, 2 and 3 or exit 8. The latch's fifth operand, from header 6, is also the unchanged carried value. The test retains the cold range boundary and adds an assertion that the default edge moves nothing.

At `d3d8ad3`, this variant reported 114 checks and four expected convention failures, with its semantic verifier and certificates passing. Both latch and header chose register 1; each handler still used register 0. There were three register 1-to-0 moves from the dispatcher to handlers, three register 0-to-1 moves from handlers to the latch, the cold block's required displacement, and one entry-to-header move. The latch/header/default edges were already move-free. This exercises a distinction that the direct header-as-dispatcher fixture does not.

This experiment exposes a limitation of the initial candidate. It does not establish the exact shape or remedy for the actual SQLite allocation, and it makes no claim that issue 2553 is solved. No benchmark hardware was accessed or queued for these local checks.
