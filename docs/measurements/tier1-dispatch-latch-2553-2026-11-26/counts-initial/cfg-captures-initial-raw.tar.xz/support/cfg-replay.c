// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// Copyright (c) 2026 David Gonzalez Martin. See the buster repository's LICENSE and LICENSING.md.
//
// Temporary #2553 allocator replay. Build against the chosen compiler checkout, with tier1_cfg_snapshot.c beside
// this file. The snapshot is a bounded same-ABI trusted-data format; it is not a portable or hostile-file decoder.

#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUSTER_ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))
#include "buster/compiler/lane.c"
#include "buster/compiler/dataflow.c"
#include "buster/compiler/dominators.c"
#include "buster/compiler/tier1_allocate.c"
#include "buster/compiler/tier1_certificate.c"
#include "buster/compiler/tier1_certificate_interval.c"
#ifndef BUSTER_CFG_SOURCE
#define BUSTER_CFG_SOURCE "buster/compiler/tier1_cfg.c"
#endif
#include BUSTER_CFG_SOURCE
#include "buster/compiler/tier1_certificate_cfg.c"
#include "tier1_cfg_snapshot.c"

static bool cfg_replay_offsets(const uint32_t* offsets, uint32_t count, uint32_t limit)
{
    bool okay = offsets != NULL && offsets[0] == 0 && offsets[count] == limit;
    for (uint32_t i = 0; okay && i < count; i += 1)
    {
        okay = offsets[i] <= offsets[i + 1] && offsets[i + 1] <= limit;
    }
    return okay;
}

static bool cfg_replay_read(const char* path, Arena* arena, Tier1CfgSnapshotHeader* header)
{
    const uint64_t saved = arena->length;
    FILE* file = fopen(path, "rb");
    bool okay = file != NULL && fread(header, sizeof(*header), 1, file) == 1;
    okay = okay && memcmp(header->magic, "BCFG2553", 8) == 0 && header->version == BUSTER_CFG_SNAPSHOT_VERSION && header->endian == 0x01020304u;
    okay = okay && header->header_size == sizeof(*header) && header->input_size == sizeof(Tier1CfgInput) && header->dominators_size == sizeof(Dominators) && header->column_size == sizeof(Tier1CfgSnapshotColumn);
    okay = okay && header->column_count <= BUSTER_CFG_SNAPSHOT_COLUMNS && header->payload_bytes <= BUSTER_CFG_SNAPSHOT_LIMIT && header->has_dominators <= 1 && header->input.dominators == NULL;
    okay = okay && header->dominators.row_words <= BUSTER_CFG_SNAPSHOT_LIMIT / sizeof(uint64_t) && header->dominators.loop_count <= header->dominators.block_count;
    Tier1CfgSnapshotColumn columns[BUSTER_CFG_SNAPSHOT_COLUMNS] = { 0 };
    Tier1CfgSnapshotColumn expected[BUSTER_CFG_SNAPSHOT_COLUMNS] = { 0 };
    uint32_t count = 0;
    if (okay)
    {
        count = tier1_cfg_snapshot_schema(header, expected);
        okay = count == header->column_count && fread(columns, sizeof(columns[0]), count, file) == count;
    }
    uint64_t bytes = 0;
    for (uint32_t i = 0; okay && i < count; i += 1)
    {
        const Tier1CfgSnapshotColumn* c = &columns[i];
        const Tier1CfgSnapshotColumn* e = &expected[i];
        okay = c->owner == e->owner && c->offset == e->offset && c->width == e->width && c->count == e->count && c->present <= 1;
        okay = okay && c->count <= BUSTER_CFG_SNAPSHOT_LIMIT / c->width;
        if (okay)
        {
            const uint64_t size = c->present ? c->count * c->width : 0;
            okay = bytes <= BUSTER_CFG_SNAPSHOT_LIMIT - size;
            bytes += size;
            const uint8_t* owner = c->owner == 0 ? (const uint8_t*)&header->input : (const uint8_t*)&header->dominators;
            uintptr_t pointer = 0;
            memcpy(&pointer, owner + c->offset, sizeof(pointer));
            okay = okay && pointer == 0 && (c->owner == 0 || header->has_dominators != 0 || c->present == 0);
        }
    }
    okay = okay && bytes == header->payload_bytes;
    struct stat info = { 0 };
    if (okay)
    {
        const uint64_t total = sizeof(*header) + (uint64_t)count * sizeof(columns[0]) + bytes;
        okay = fstat(fileno(file), &info) == 0 && info.st_size >= 0 && (uint64_t)info.st_size == total;
    }
    for (uint32_t i = 0; okay && i < count; i += 1)
    {
        const Tier1CfgSnapshotColumn* c = &columns[i];
        if (c->present)
        {
            const uint64_t size = c->count * c->width;
            void* payload = arena_push(arena, size != 0 ? size : 1, 64);
            okay = payload != NULL && (size == 0 || fread(payload, 1, size, file) == size);
            uint8_t* owner = c->owner == 0 ? (uint8_t*)&header->input : (uint8_t*)&header->dominators;
            memcpy(owner + c->offset, &payload, sizeof(payload));
        }
    }
    if (file != NULL)
    {
        okay = fclose(file) == 0 && okay;
    }
    if (okay)
    {
        Tier1CfgInput* n = &header->input;
        n->dominators = header->has_dominators != 0 ? &header->dominators : NULL;
        okay = n->block_count != 0 && n->phi_count <= n->value_count;
        okay = okay && cfg_replay_offsets(n->successor_offsets, n->block_count, n->edge_count) && cfg_replay_offsets(n->predecessor_offsets, n->block_count, n->edge_count);
        okay = okay && cfg_replay_offsets(n->phi_offsets, n->block_count, n->phi_count) && cfg_replay_offsets(n->phi_operand_offsets, n->phi_count, header->phi_operand_count);
        okay = okay && (n->value_count == 0 || cfg_replay_offsets(n->use_offsets, n->value_count, n->use_count));
    }
    if (!okay)
    {
        arena_pop_to(arena, saved);
    }
    return okay;
}

static bool cfg_replay_dump(const char* path, const Tier1CfgInput* in, const Tier1CfgAllocation* cfg)
{
    FILE* out = fopen(path, "w");
    bool okay = out != NULL;
    if (okay)
    {
        fprintf(out, "DUMP replay blocks=%u values=%u intervals=%u uses=%u phis=%u positions=%u\n", in->block_count, in->value_count, cfg->intervals.count, in->use_count, in->phi_count, in->position_count);
        for (uint32_t b = 0; b < in->block_count; b += 1)
        {
            fprintf(out, "B %u [%u,%u) preds", b, in->block_starts[b], in->block_starts[b + 1]);
            for (uint32_t p = in->predecessor_offsets[b]; p < in->predecessor_offsets[b + 1]; p += 1)
            {
                fprintf(out, " %u", in->predecessors[p]);
            }
            fprintf(out, " succs");
            for (uint32_t e = in->successor_offsets[b]; e < in->successor_offsets[b + 1]; e += 1)
            {
                fprintf(out, " %u", in->successors[e]);
            }
            fprintf(out, " phis");
            for (uint32_t k = in->phi_offsets[b]; k < in->phi_offsets[b + 1]; k += 1)
            {
                fprintf(out, " v%u(", in->phi_values[k]);
                for (uint32_t o = in->phi_operand_offsets[k]; o < in->phi_operand_offsets[k + 1]; o += 1)
                {
                    fprintf(out, "%s%d", o == in->phi_operand_offsets[k] ? "" : ",", (int)in->phi_operands[o]);
                }
                fprintf(out, ")");
            }
            fprintf(out, "\n");
        }
        for (uint32_t v = 0; v < in->value_count; v += 1)
        {
            fprintf(out, "V v%u class=%u def=%u allowed=%x definition_registers=%x remat=%u uses=%u spill=%d\n", v, in->classes[v], in->definitions[v], in->allowed_registers[v], in->definition_registers != NULL ? in->definition_registers[v] : 0, in->rematerializable != NULL ? in->rematerializable[v] : 0, in->use_offsets[v + 1] - in->use_offsets[v], (int)cfg->allocation.spill_ids[v]);
            for (uint32_t u = in->use_offsets[v]; u < in->use_offsets[v + 1]; u += 1)
            {
                fprintf(out, " U %u required=%u register=%u\n", in->use_positions[u], in->use_required != NULL ? in->use_required[u] : 0, in->use_registers != NULL ? in->use_registers[u] : UINT8_MAX);
            }
            for (uint32_t i = cfg->value_interval_offsets[v]; i < cfg->value_interval_offsets[v + 1]; i += 1)
            {
                fprintf(out, " I %u [%u,%u) hint_value=%d hint_interval=%08x alternate=%d continuation=%d", i, cfg->intervals.starts[i], cfg->intervals.ends[i], cfg->intervals.hint_values != NULL ? (int)cfg->intervals.hint_values[i] : -1, cfg->intervals.hint_intervals != NULL ? cfg->intervals.hint_intervals[i] : UINT32_MAX, cfg->intervals.alternate_intervals != NULL ? (int)cfg->intervals.alternate_intervals[i] : -1, cfg->intervals.continuation_intervals != NULL ? (int)cfg->intervals.continuation_intervals[i] : -1);
                for (uint32_t f = cfg->allocation.fragment_offsets[i]; f < cfg->allocation.fragment_offsets[i + 1]; f += 1)
                {
                    fprintf(out, " F%u[%u,%u):kind%u:r%u", f, cfg->allocation.starts[f], cfg->allocation.ends[f], cfg->allocation.kinds[f], cfg->allocation.registers[f]);
                }
                fprintf(out, "\n");
            }
        }
        for (uint32_t b = 0; b < in->block_count; b += 1)
        {
            for (uint32_t e = in->successor_offsets[b]; e < in->successor_offsets[b + 1]; e += 1)
            {
                if (cfg->edge_move_offsets[e] != cfg->edge_move_offsets[e + 1])
                {
                    fprintf(out, "E %u->%u place=%u", b, in->successors[e], cfg->edge_placements[e]);
                    for (uint32_t m = cfg->edge_move_offsets[e]; m < cfg->edge_move_offsets[e + 1]; m += 1)
                    {
                        fprintf(out, " v%u:%d>%d", cfg->move_values[m], (int)cfg->move_sources[m], (int)cfg->move_destinations[m]);
                    }
                    fprintf(out, "\n");
                }
            }
        }
        okay = !ferror(out);
        okay = fclose(out) == 0 && okay;
    }
    return okay;
}

int main(int argc, char** argv)
{
    const char* path = argc >= 2 ? argv[1] : NULL;
    const char* dump = NULL;
    bool require_match = false;
    bool arguments = path != NULL;
    for (int a = 2; arguments && a < argc; a += 1)
    {
        if (strcmp(argv[a], "--require-match") == 0)
        {
            require_match = true;
        }
        else if (strcmp(argv[a], "--dump") == 0 && a + 1 < argc)
        {
            dump = argv[++a];
        }
        else
        {
            arguments = false;
        }
    }
    Arena storage = arena_reserve(BUSTER_CFG_SNAPSHOT_LIMIT);
    Arena output = arena_reserve(4ull << 30);
    Arena scratch = arena_reserve(4ull << 30);
    Tier1CfgSnapshotHeader header = { 0 };
    Tier1CfgAllocation cfg = { 0 };
    bool okay = arguments && storage.base != NULL && output.base != NULL && scratch.base != NULL && cfg_replay_read(path, &storage, &header);
    if (okay)
    {
        const Tier1CfgInput* input = &header.input;
        printf("snapshot version=%u blocks=%u edges=%u values=%u uses=%u phis=%u positions=%u fixed=%u clobbers=%u sequences=%u dominators=%u bytes=%" PRIu64 "\n", header.version, input->block_count, input->edge_count, input->value_count, input->use_count, input->phi_count, input->position_count, input->fixed.count, input->clobber_count, input->sequence_count, header.has_dominators, header.payload_bytes);
        const Tier1CfgError error = tier1_cfg_allocate(input, &output, &scratch, &cfg);
        printf("allocate status=%u intervals=%u fragments=%u spills=%u moves=%u split_edges=%u retained_bytes=%" PRIu64 " scratch_bytes=%" PRIu64 "\n", error, cfg.intervals.count, cfg.allocation.fragment_count, cfg.allocation.spill_count, cfg.move_count, cfg.split_edges, cfg.retained_bytes, cfg.scratch_bytes);
        okay = error == TIER1_CFG_OK;
        if (okay)
        {
            const uint64_t hash = tier1_cfg_snapshot_allocation_hash(input, &cfg);
            printf("allocation_hash=%016" PRIx64 " captured_hash=%016" PRIx64 " match=%s\n", hash, header.allocation_hash, hash == header.allocation_hash ? "yes" : "no");
            Tier1CertReport report = { 0 };
            Tier1CertCfgStats stats = { 0 };
            const Tier1CertError certified = tier1_certificate_cfg_check(input, &cfg, &output, &scratch, &report, &stats);
            printf("certificate status=%u block=%u edge=%u instruction=%u facts=%" PRIu64 " transitions=%" PRIu64 " edge_moves=%" PRIu64 " split_moves=%" PRIu64 "\n", certified, report.block, report.edge, report.instruction, stats.facts, stats.transitions, stats.edge_moves, stats.split_moves);
            okay = certified == TIER1_CERT_OK && (!require_match || hash == header.allocation_hash);
            const bool dumped = dump == NULL || cfg_replay_dump(dump, input, &cfg);
            okay = dumped && okay;
        }
    }
    else
    {
        fprintf(stderr, "cfg-replay: invalid arguments, snapshot format, or memory capacity\nusage: cfg-replay SNAPSHOT [--require-match] [--dump PATH]\n");
    }
    arena_release(&scratch);
    arena_release(&output);
    arena_release(&storage);
    return okay ? 0 : 1;
}
