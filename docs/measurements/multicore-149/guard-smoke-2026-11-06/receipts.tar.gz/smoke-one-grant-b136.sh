#!/bin/sh
if ! mkdir "$HOME/buster-fast-bench/149-merge-2dc-codex/smoke-one-grant-b136-used" 2>/dev/null; then
    echo "smoke intentionally refuses a second grant" >&2
    exit 99
fi
exec "$HOME/buster-fast-bench/exclusive.sh" "$@"
