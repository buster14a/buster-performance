#!/usr/bin/env bash
set -euo pipefail
mode="$1"
root="$(cd "$(dirname "$0")/.." && pwd)"
workspace="$(cd "$root/.." && pwd)"
out="$root/local-smoke"
mapfile -t cpus < <(python3 - <<'PY'
import os
from pathlib import Path
seen=set()
for cpu in sorted(os.sched_getaffinity(0)):
    base=Path(f'/sys/devices/system/cpu/cpu{cpu}/topology')
    key=((base/'physical_package_id').read_text().strip(), (base/'core_id').read_text().strip())
    if key not in seen:
        print(cpu); seen.add(key)
        if len(seen)==4: break
PY
)
test "${#cpus[@]}" -eq 4
export SOURCE_DATE_EPOCH=0 LC_ALL=C LANG=C TZ=UTC
unset MAKEFLAGS MFLAGS CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH LIBRARY_PATH COMPILER_PATH GCC_EXEC_PREFIX BUSTER_CLANG_RESOURCE_DIR
if [[ "$mode" = control ]]; then
  compiler="$workspace/buster-wait-control/build/compiler"
  unset BUSTER_WAIT_TRACE
  printf '%s\n' "${cpus[0]}" > "$out/control-cpus.txt"
  exec "$compiler" --lanes 1 --lane-cpus "${cpus[0]}" --worker-budget=4 -w -c "$out/input.c" -o "$out/control.o"
elif [[ "$mode" = diagnostic ]]; then
  compiler="$workspace/buster-wait-frozen/build/compiler"
  export BUSTER_WAIT_TRACE=1
  printf -v list '%s,%s,%s,%s' "${cpus[@]}"
  printf '%s\n' "$list" > "$out/diagnostic-cpus.txt"
  exec "$compiler" --lanes 4 --lane-cpus "$list" --worker-budget=4 --time-stages -w -c "$out/input.c" -o "$out/diagnostic.o"
else
  exit 2
fi
