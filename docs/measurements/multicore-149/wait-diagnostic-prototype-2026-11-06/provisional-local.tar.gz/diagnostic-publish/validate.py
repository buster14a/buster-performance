from pathlib import Path
import hashlib
import re
p=Path(__file__).resolve().parent
cpus=[int(x) for x in (p/'diagnostic-cpus.txt').read_text().strip().split(',')]
assert len(cpus)==4 and len(set(cpus))==4, cpus
raw=(p/'diagnostic.stderr').read_text().splitlines()
def fields(line):
    parts=line.split('\t')
    out={}
    for item in parts[1:]:
        k,sep,v=item.partition('=')
        assert sep and k not in out, line
        out[k]=v
    return out
pins={}; lanes={}; metrics={}; calibrations={}
for line in raw:
    tag=line.split('\t',1)[0]
    if tag not in ('lane-pin','wait-diagnostic','wait-diagnostic-metric','wait-diagnostic-calibration'): continue
    f=fields(line)
    lane=int(f['index'] if tag=='lane-pin' else f['lane'])
    assert 0<=lane<4, line
    if tag=='lane-pin':
        assert lane not in pins and int(f['expected'])==cpus[lane] and int(f['observed'])==cpus[lane] and f['status']=='0', line
        pins[lane]=f
    elif tag=='wait-diagnostic':
        assert lane not in lanes and int(f['expected-cpu'])==cpus[lane] and int(f['observed-cpu'])==cpus[lane] and f['cpu-status']=='0', line
        assert f['scope']=='start-through-flow' and f['end-policy']=='forced-join' and int(f['tid'])>0, line
        lanes[lane]=f
    elif tag=='wait-diagnostic-calibration':
        assert lane not in calibrations and f['pairs']=='1000' and f['failures']=='0', line
        assert 0<=int(f['min-ns'])<=int(f['max-ns'])<=int(f['total-ns']),line
        calibrations[lane]=f
    else:
        key=(lane,f['kind'],f['outcome'])
        assert key not in metrics, line
        calls=int(f['calls']); errors=int(f['clock-errors']); bins=[int(x) for x in f['buckets'].split(',')]
        assert len(bins)==8 and 0<=errors<=calls and sum(bins)==calls-errors, line
        assert 0<=int(f['max-ns'])<=int(f['elapsed-ns']),line
        metrics[key]=f
kinds={'initial-spin','mwaitx','fallback-spin','barrier-futex','other-futex'}
outcomes={'completed','eagain','eintr','other'}
assert len(pins)==len(lanes)==len(calibrations)==4
assert len(metrics)==4*len(kinds)*len(outcomes)
assert set(metrics)=={(lane,kind,outcome) for lane in range(4) for kind in kinds for outcome in outcomes}
a=(p/'control.o').read_bytes(); b=(p/'diagnostic.o').read_bytes()
assert a==b and a
print('four unique pinned lanes, 80 complete metric rows and four clock calibrations verified')
print('object equality sha256='+hashlib.sha256(a).hexdigest())
print('local provisional diagnostic only; no performance or CPU-residence inference')
