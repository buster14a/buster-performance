# Strict publication-copy refusal, attempt 1

This was an unsuccessful publication preparation attempt, not a compiler measurement or a qualification run. The copy-only recipe `derive-public-v1.sh` stopped with status 1 at the first selected file refused by the unchanged strict sanitizer `6299873eb353b157084d552858ac1227c20936cddb630054b3e8f499c4837997`.

The refused original was `failures/interrupted-2026-11-06/sqlite/warmup-0.lock.stderr`, SHA-256 `e023e40adbc3ecd1a56b53c5e7ebbb69e071a29807821d9376582b0d61bcfcff`. It consists of two LF-terminated metadata lines: a shared-lock waiting-holder notice and its title, with no closing link. It contains no actual own grant, metric, status or output record. The sanitizer correctly refused this incomplete block before creating an output file. No parser rule was relaxed.

The original files and full native-record manifests remained untouched. The unaccepted `public-attempt1` scratch directory remains private and is never used as archive input. Its 5721-file SHA-256 manifest, the exact v1 recipe, first refusal log and status are retained here; the duplicated scratch payload is not published.

After this refusal, root and an independent reviewer inspected the complete selected-file catalog. They approved separate whole-file omission markers for exactly 72 metadata-only paths, each bound to its original SHA-256, byte length, line count and final-LF state. Those explicit exceptions are distinct from the strict sanitizer's complete-block removals. The final public mapping identifies which rule produced each derivative. This failed attempt remains preparation history and contributes no measurement evidence.
