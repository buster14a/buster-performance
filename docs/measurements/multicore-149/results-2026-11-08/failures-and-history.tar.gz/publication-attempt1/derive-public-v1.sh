#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Copy-only publication transform; never modify the raw source tree.
set -euo pipefail
raw=$(realpath "$1")
public=$2
sanitizer=$(realpath "$3")
test -d "$raw"
test ! -e "$public"
test -z "$(find "$raw" -type l -print -quit)"
test -z "$(find "$raw" ! -type f ! -type d -print -quit)"
for reserved in SHA256SUMS INVENTORY.txt SANITIZATION.tsv
do
    for scope in timing waits audits failures
    do
        test ! -e "$raw/$scope/$reserved"
    done
done
mkdir -p "$public"
public=$(realpath "$public")
cp -a "$raw/." "$public/"
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
for scope in timing waits audits failures
do
    printf 'archive-member\toriginal-sha256\tpublic-sha256\tremoved-blocks\treason\n' > "$public/$scope/SANITIZATION.tsv"
done
find "$raw" -type f -print0 | LC_ALL=C sort -z > "$scratch/files"
while IFS= read -r -d '' original
do
    relative=${original#"$raw/"}
    case "$relative" in
        *$'\n'*|*$'\t'*|/*|../*|*/../*) exit 1 ;;
    esac
    scope=${relative%%/*}
    member=${relative#*/}
    destination="$public/$relative"
    original_hash=$(sha256sum "$original" | cut -d' ' -f1)
    blocks=0
    reason=byte-identical-copy
    case "$original" in
        *.log|*.stderr)
            if LC_ALL=C grep -a -q '^exclusive.sh: waiting for the 9700X, held by: ' "$original"
            then
                candidate="$destination.public-copy"
                test ! -e "$candidate"
                if "$sanitizer" "$original" "$candidate" 2> "$scratch/filter.status"
                then
                    grep -qx 'sanitized-blocks=[0-9][0-9]*' "$scratch/filter.status"
                    blocks=$(cut -d= -f2 "$scratch/filter.status")
                    mv "$candidate" "$destination"
                    if test "$blocks" != 0
                    then
                        reason=unrelated-waiting-holder-blocks-omitted
                    fi
                else
                    rm -f "$candidate"
                    printf 'PUBLICATION-STOPPED unaccepted-log-shape=%s original-sha256=%s\n' "$relative" "$original_hash" >&2
                    exit 1
                fi
            fi
            ;;
    esac
    public_hash=$(sha256sum "$destination" | cut -d' ' -f1)
    if test "$reason" = byte-identical-copy
    then
        test "$original_hash" = "$public_hash"
    fi
    printf '%s\t%s\t%s\t%s\t%s\n' "$member" "$original_hash" "$public_hash" "$blocks" "$reason" >> "$public/$scope/SANITIZATION.tsv"
done < "$scratch/files"
printf 'publication-copy-status=complete\n'
