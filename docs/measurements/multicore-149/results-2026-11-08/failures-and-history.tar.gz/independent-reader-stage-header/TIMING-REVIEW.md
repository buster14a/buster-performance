# Independent timing-record review

This review qualifies the integrity of the three closed timing cases produced by performance tools `21df57f8d3da84fa2ea94512f2674facdaa1547c` for compiler `2dc50258e8b33393474b64032a5cbe9f17c63def`. It is not parent-issue acceptance or evidence for a later compiler revision.

The final independent C reader is source `83c5a3f53041b6303f409068003bf6edde908d8cdb8b7fd85b1dc16bdf3c3ea4`, binary `e7446aebf92bf9eec1dc9da7136477bf983e46b778bf58caf753c6beaf383897`. Each case passed the complete 82-record audit, a positive copied fixture and thirteen deliberate corruptions requiring exit 1 and the intended diagnostic. All original files were hashed before, after and after copied-fixture controls, with identical manifests:

| Case | Original files | Object files per sample | Full original manifest SHA-256 |
|---|---:|---:|---|
| SQLite | 1,500 | 1 | `4bfaeee165f677f979fea2a0296b890ddda8a1f4ba609ea5870e033905365fd8` |
| Synthetic | 2,011 | 512 | `99375315b1b389d07d0f8ac2c5101d6ca5a97ac76ae8dabe832416c5e8463e7f` |
| Musl | 2,808 | 1,309 | `652aeb3831494e0df06e64e8d6d98ae075caeb4a6fa4d95e83f9ad0b836c9e73` |

Across all cases the review independently checked 246 samples, 1,822 retained reference objects, 149,404 object-digest rows, 4,602 input-manifest entries and 4,497 local non-object snapshot files. Shared source, compiler, runner, lock, policy and environment identities agree. All 789 overlapping input paths have the same hashes. The 82 records in each case comprise one reference, nine warmups, 63 ordinary timed samples and nine stage diagnostics. The ninth slot is the separate one-lane CPU2 control.

The raw records establish zero child/guard/wrapper status, no interruption, clean descendants, the expected lane/CPU requests and receipts, stable identities and inputs, and object hashes equal to the reference. Guard bounds were checked independently, including child wall time no greater than guard time, guard time no greater than wrapper time, and guard time at most 255 seconds. All known stage rows and the exact stage header were counted; stage totals and every summary row were recomputed. Retained reference bytes were SHA-256 checked. Successful non-reference objects had already been deleted after the audited runner's full-byte comparisons; this independent review cannot repeat those deleted-object comparisons.

The initial SQLite reader attempt failed closed because the original independent reader tried to parse the legitimate `time-stage` header's `ms` label as a number. This was a reader defect, not a campaign protocol failure. The initial source and failed receipt remain in `tools/` and `sqlite/`. The reviewed v4 correction recognizes the exact seven-field header and requires exactly one header per diagnostic. It relaxes no count, identity, numeric, guard or policy check. Three of the thirteen copied-fixture controls specifically reject a malformed, missing or duplicated header.

The captured policy is mixed: CPU2 reports performance governor and performance EPP; the other selected CPUs report powersave and balance_performance. The CPU2 `siblings=2` value is the CPU list containing CPU2, not a claim of two hardware threads. Other selected CPUs list sibling pairs. The snapshots do not establish continuous residency, utilization or actual frequency. Stage-derived serial bounds describe the instrumented stage records, not an unperturbed serial fraction or a causal speed claim.

The interrupted earlier campaign remains separate and unused; its partial records were not substituted into these cases. The separately instrumented ordinary wait observations require their own final raw-record review.

Agent: OpenAI Codex, model OpenAI GPT-6 (exact runtime variant not exposed), root session `01a1b81e-6ae2-7022-84e9-95739850f990`, task `/root/identity_validation`.
