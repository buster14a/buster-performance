#!/bin/sh
set -eu
retained=/home/david/buster-fast-bench/149-merge-2dc-codex
date -u '+audit-time=%Y-%m-%dT%H:%M:%SZ'
printf 'lock-owner\n'
cat /var/lib/buster-9700x/owner
for tree in compiler diagnostic-2dc performance
do
    printf 'source=%s\n' "$tree"
    git -C "$retained/$tree" rev-parse HEAD 'HEAD^{tree}'
    git -C "$retained/$tree" status --porcelain=v1 --untracked-files=all
    git -C "$retained/$tree" ls-files -v | awk 'substr($0,1,2) != "H " { print; bad=1 } END { exit bad }'
done
printf 'applied-diagnostic-diff\n'
git -C "$retained/diagnostic-2dc" diff --binary | sha256sum
sha256sum "$retained/compiler/build/compiler" "$retained/diagnostic-2dc/build/compiler" "$retained/tools/runner-440012ed" "$retained/tools/prepare" "$retained/performance/docs/measurements/multicore-149/runner.c" "$retained/performance/docs/measurements/multicore-149/runner_test.c" "$retained/performance/docs/measurements/multicore-149/wait-diagnostic-merged-2026-11-06/validate-wait.py" /home/david/buster-fast-bench/exclusive.sh
for campaign_case in sqlite synth musl
do
    printf 'case=%s\n' "$campaign_case"
    wc -l "$retained/cases/$campaign_case/outputs.txt" "$retained/cases/$campaign_case/sources.sha256"
    sha256sum "$retained/cases/$campaign_case/args.txt" "$retained/cases/$campaign_case/outputs.txt" "$retained/cases/$campaign_case/sources.sha256" "$retained/cases/$campaign_case/provenance.txt"
    sha256sum --check --strict --status "$retained/cases/$campaign_case/sources.sha256"
    printf 'case-input-audit=passed\n'
done
printf 'partial-reference-object\n'
(cd "$retained/campaign-21df-20261106/sqlite/reference" && sha256sum --check --strict --status objects.sha256)
cat "$retained/campaign-21df-20261106/sqlite/case-status.txt"
printf 'audit-status=passed\n'
