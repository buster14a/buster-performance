#!/bin/sh
set -eu
campaign_root=/home/david/buster-fast-bench/149-codex-01a1b81e-20261107
toolchain=/home/david/.cache/buster/benchpress-clang/efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378/bin/clang
"$toolchain" --version
sha256sum "$toolchain"
"$toolchain" -std=c17 -O2 -Wall -Wextra -Werror -fno-strict-aliasing "$campaign_root/tools-source/docs/measurements/multicore-149/wait-observe.c" -o "$campaign_root/tools/wait-observe"
sha256sum "$campaign_root/tools/wait-observe"
