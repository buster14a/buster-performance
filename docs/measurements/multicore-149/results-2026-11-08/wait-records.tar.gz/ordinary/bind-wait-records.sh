#!/bin/bash
set -euo pipefail
cd /home/david/buster-fast-bench/149-codex-01a1b81e-20261107
test "$(cat wait-controller.status)" = wait-status=completed
{
    for campaign_case in sqlite synth musl
    do
        for lane_count in 1 2 3 4 5 6 7 8
        do
            observation="wait-$campaign_case-$lane_count"
            test "$(cat "$observation-controller.status")" = 0
            find "$observation" -type f -print0
            printf '%s\0' "$observation-controller.log" "$observation-controller.status"
        done
    done
    printf '%s\0' independent-timing-review.txt wait-controller.sh ordinary-wait-24-commands.txt wait-controller.log wait-controller.status wait-controller-start.txt wait-controller.pid provenance.txt build-wait-launcher.sh build-wait-launcher.log build-wait-launcher.status
} | LC_ALL=C sort -zu | xargs -0 sha256sum > ordinary-wait-records.before.sha256
sha256sum ordinary-wait-records.before.sha256
wc -l ordinary-wait-records.before.sha256
