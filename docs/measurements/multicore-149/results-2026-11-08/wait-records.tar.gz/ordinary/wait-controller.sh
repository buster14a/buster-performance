#!/bin/sh
set -u
campaign_root=/home/david/buster-fast-bench/149-codex-01a1b81e-20261107
retained=/home/david/buster-fast-bench/149-merge-2dc-codex
export PATH=/usr/local/bin:/usr/bin:/bin
unset CORES BUSTER_HUGE_PAGES LD_PRELOAD LD_LIBRARY_PATH BUSTER_9700X_HELD
test "$(cat "$campaign_root/timing-controller.status")" = timing-status=completed || exit 1
test -s "$campaign_root/independent-timing-review.txt" || exit 1
grep -qx 'schema=multicore-149-ordinary-wait-admission-v1' "$campaign_root/independent-timing-review.txt" || exit 1
grep -qx 'admission-status=admitted' "$campaign_root/independent-timing-review.txt" || exit 1
grep -qx 'observation-count=24' "$campaign_root/independent-timing-review.txt" || exit 1
grep -qx 'harness-commit=21df57f8d3da84fa2ea94512f2674facdaa1547c' "$campaign_root/independent-timing-review.txt" || exit 1
export EXCLUSIVE_OWNER=codex-01a1b81e-perf270-waits
export EXCLUSIVE_TITLE='Astra PR takeover: separate pinned wait observations'
export EXCLUSIVE_LINK=https://github.com/buster14a/buster-performance/pull/270
for campaign_case in sqlite synth musl
do
    for lane_count in 1 2 3 4 5 6 7 8
    do
        observation="$campaign_root/wait-$campaign_case-$lane_count"
        "$campaign_root/tools/wait-observe" --qualified "$campaign_root/timing-$campaign_case" --output "$observation" --control-source "$retained/compiler" --diagnostic-source "$retained/diagnostic-2dc" --lock /home/david/buster-fast-bench/exclusive.sh --validator "$campaign_root/tools-source/docs/measurements/multicore-149/wait-diagnostic-merged-2026-11-06/validate-wait.py" --lanes "$lane_count" > "$observation-controller.log" 2>&1
        observation_result=$?
        printf '%s\n' "$observation_result" > "$observation-controller.status"
        date -u "+case=$campaign_case lanes=$lane_count result=$observation_result at=%Y-%m-%dT%H:%M:%SZ"
        if test "$observation_result" != 0
        then
            printf 'wait-status=failed\n' > "$campaign_root/wait-controller.status"
            exit "$observation_result"
        fi
    done
done
printf 'wait-status=completed\n' > "$campaign_root/wait-controller.status"
