#!/bin/sh
set -u
campaign_root=/home/david/buster-fast-bench/149-codex-01a1b81e-20261107
retained=/home/david/buster-fast-bench/149-merge-2dc-codex
export PATH=/usr/local/bin:/usr/bin:/bin
unset CORES BUSTER_HUGE_PAGES LD_PRELOAD LD_LIBRARY_PATH BUSTER_9700X_HELD
export EXCLUSIVE_OWNER=codex-01a1b81e-perf270-smoke
export EXCLUSIVE_TITLE='Astra PR takeover: separate pinned wait smoke'
export EXCLUSIVE_LINK=https://github.com/buster14a/buster-performance/pull/270
date -u '+smoke-start=%Y-%m-%dT%H:%M:%SZ'
"$campaign_root/tools/wait-observe" --smoke --qualified "$retained/campaign-21df-20261106/sqlite" --output "$campaign_root/wait-smoke-sqlite-4" --control-source "$retained/compiler" --diagnostic-source "$retained/diagnostic-2dc" --lock /home/david/buster-fast-bench/exclusive.sh --validator "$campaign_root/tools-source/docs/measurements/multicore-149/wait-diagnostic-merged-2026-11-06/validate-wait.py" --lanes 4
smoke_result=$?
printf '%s\n' "$smoke_result" > "$campaign_root/smoke-controller.status"
date -u '+smoke-end=%Y-%m-%dT%H:%M:%SZ'
exit "$smoke_result"
