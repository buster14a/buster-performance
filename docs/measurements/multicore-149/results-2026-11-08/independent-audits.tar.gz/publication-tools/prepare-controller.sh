#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# One admitted publication-only attempt. No native compiler measurement or build.
set -euo pipefail
task_root=/home/david/Documents/Codex/2026-11-07/tak-2
publication="$task_root/work/perf270-publication"
raw="$publication/raw"
public="$publication/public-attempt2"
package="$publication/package"
test "$(sha256sum "$publication/derive-public-v2.proposed.sh" | cut -d' ' -f1)" = 1bbc26b208daba32b81a6d8637a2021c4ba5a6a57be8269e827ac83905622764
test "$(sha256sum "$publication/build-archives.sh" | cut -d' ' -f1)" = 23c465e78527261bc7dcddb8d285df0773cc46292bbc29c357ba025238733ca2
test ! -e "$public"
test ! -e "$publication/raw-before.sha256"
bind_raw() {
    (
        cd "$raw"
        find . -type f -printf '%P\0' | LC_ALL=C sort -z | xargs -0 sha256sum
    )
}
bind_raw > "$publication/raw-before.sha256"
set +e
bash "$publication/derive-public-v2.proposed.sh" "$raw" "$public" \
    "$task_root/work/perf270-resume/sanitize_queue" \
    "$publication/queue-omission-allowlist.tsv" > "$publication/derive-attempt2.log" 2>&1
result=$?
set -e
printf '%s\n' "$result" > "$publication/derive-attempt2.status"
bind_raw > "$publication/raw-after-derive.sha256"
cmp "$publication/raw-before.sha256" "$publication/raw-after-derive.sha256"
test "$result" -eq 0
set +e
bash "$publication/build-archives.sh" "$public" "$package" > "$publication/archive-build.log" 2>&1
result=$?
set -e
printf '%s\n' "$result" > "$publication/archive-build.status"
bind_raw > "$publication/raw-after-archives.sha256"
cmp "$publication/raw-before.sha256" "$publication/raw-after-archives.sha256"
test "$result" -eq 0
set +e
sh "$package/review.sh" > "$publication/package-review.log" 2>&1
result=$?
set -e
printf '%s\n' "$result" > "$publication/package-review.status"
test "$result" -eq 0
printf 'publication-preparation-status=complete\n'
