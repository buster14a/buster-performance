# Queue-file exception catalog review

This is an independent source/content review, not permission to resume publication preparation. Root reviews the complete catalog and the exact subsequent allowlist/recipe before use. The strict sanitizer `6299873eb353b157084d552858ac1227c20936cddb630054b3e8f499c4837997` remains unchanged.

All 131 source-file SHA-256 values in queue-shape catalog `9e429dfcec5602e3be3b507c3829411a017fd8c466019827d4d5cf54b172e933` independently match the raw staging files. It records 59 strict passes and 72 refusals. The separate 72-file rejection catalog `b7d7076a3468618ff54e49504b757e539ae22e7152e53e326abe36426d239951` contains exactly the same refused paths, original hashes and line counts. Every refusal has a final LF and no own-record line.

The refusal files comprise three files containing exactly one waiting-holder line; sixty-two files containing exactly a waiting-holder line and its title; and seven files of 31, 24, 25, 25, 9, 30 and 30 lines containing the printed multiline command/argument fragments of other Benchpress holders. All 72 are ASCII text. The one- and two-line shapes were independently checked across their entire files. Every byte of all seven multiline files was read: their content belongs to the unrelated combined-80fe build/test or #1719 diagnostic holder commands, with optional final title text. Shell source such as `status=$?` belongs to the printed other-holder command, not an observed #149 process status. No file contains this campaign's own guard, metric, status, compiler-output or other substantive receipt outside that unrelated holder metadata. The one classifier `UNCLASSIFIED` row ends with the other holder's command rather than a title; the byte-level review resolves it as unrelated holder metadata too.

A whole-file omission marker is suitable only for the exact reviewed paths, original SHA-256 values and line counts, with raw originals preserved and a distinct public-derivative reason. This is not a general EOF rule or permission to scan past malformed blocks. Any changed hash, path, line count, or substantive record requires rejection and further review. The first strict-refusal attempt and its nonpublishable partial derivative staging must remain disclosed separately from native campaign failures.

The accompanying `queue-catalog-originals.sha256` is the independently reconstructed 131-file original hash list. The seven multiline refusal files are `timing/records/timing-sqlite/{diagnostic-0,diagnostic-3,diagnostic-4,diagnostic-5,run-005-0,run-005-2,run-005-7}.lock.stderr` within the raw staging root. Their individual hashes and line counts are in the immutable reviewed catalog.

No sanitizer, compiler, corpus or measurement process was executed for this review. No raw file or public package was edited.

Agent: OpenAI Codex, model OpenAI GPT-6 (exact runtime variant not exposed), root session `01a1b81e-6ae2-7022-84e9-95739850f990`, task `/root/identity_validation`.
