# Proposed append-only publication on performance PR #270

Preparation only. Do not stage, commit or push until all 24 ordinary wait observations and their independent evidence review pass.

Add one dated directory, `docs/measurements/multicore-149/results-2026-11-08/`. Preserve every existing Astra-authored file, historical archive and source commit. Keep the original campaign launcher, runner and diagnostic implementation at their reviewed locations; link exact commits rather than copy them into the result directory.

Proposed tracked additions (nine files):

| File | Contents |
| --- | --- |
| `README.md` | Pinned compiler/tools/inputs; three eight-point curves and separate CPU-2 controls; variability, serial lower/model bounds; actual power/placement/wait policy; timing and diagnostic scope; audit results, failures and limits; exact verification commands. |
| `SHA256SUMS` | Checksums of the README, four archives and three reproducibility sources/scripts. |
| `timing-records.tar.gz` | All three closed cases' exact public-copy manifests, 246 sample/status/guard/window/identity/policy/environment/placement/object-hash records, 27 stage reports, summaries, controller commands/statuses, source/build/preparation provenance. |
| `wait-records.tar.gz` | The separate nonqualifying smoke plus all 24 admitted ordinary observation records: raw traces, validators, PID/status/placement/stages, before/after source/binary/policy/environment identities, object hashes, own-lock and guard receipts, commands/statuses and actual admission record. |
| `independent-audits.tar.gz` | Immutable original record manifests (including hashes of omitted reference objects), full independent audit outputs and source/tool hashes, positive-copy and exact negative-control commands/results, cross-case checks and final wait review. Preserve each reviewed reader version identifier. |
| `failures-and-history.tar.gz` | Initial failed sparse-index operator audit and corrected retry receipts; initial reader-format failure and correction/regressions; the historical interrupted 6 November attempt's original non-object records and provenance, explicitly excluded from the new 246 samples. Any new actual failure is retained here and in its case records. |
| `record_review.c` | Exact final independently reviewed C record reader source, retaining its notices and source identity. |
| `record_mutate.c` | Exact independently reviewed corruption-fixture helper, retaining its notices and source identity. |
| `review.sh` | Exact small build/invocation driver and verification instructions; no binaries, copied corpus or duplicated full corrupted case trees. |

Each archive contains its own `SHA256SUMS` and a relative member inventory. Keep complete original raw manifests and every raw source/log/status byte unchanged in the isolated host directory and audit workspace; verify those hashes again after packaging. Candidate object cleanup performed by the reviewed launcher is documented; reference objects remain on the host through final review.

Follow the established `guard-smoke-2026-11-06` and `merged-native-qualification-2026-11-06` archive convention. Inspect publication copies for unrelated lock-holder details and host-specific paths. If sanitization is needed, retain raw originals unchanged and explicitly distinguish their immutable manifests from the public-copy manifest: the README must state that public files are sanitized derivatives and that original embedded hashes/path-bearing commands are historical bindings, not hashes of the derivatives. Never silently rewrite originals or call sanitized copies byte-identical raw evidence.

Do not include compiler, runner, launcher, reader or mutator executables; any object files; third-party source/header archives; frozen corpus contents; build trees; caches; or fourteen duplicated positive/negative full-case trees. Preserve changed negative-control text files plus mutation command/source, expected and observed outcomes and original manifest binding, which suffice to reconstruct them from the one original case record. For corruption of an omitted reference object, retain the exact byte-offset/value mutation recipe and before/after hashes instead of the object file.

Before publication: confirm archive inventories against the approved membership; verify internal and outer hashes; compare the untouched host originals against all three accepted original manifests; independently inspect the public package and every exclusion/disclosure. Packaging verification does not replace reference-object rehash or native measurement qualification. The 1–10 ms histogram bucket cannot count waits above 1.5 ms exactly; perturbed intervals do not prove residency/frequency effects; worker TIDs are not independently corroborated.
