# Frozen publication preparation checkpoint

Prepared for root plus independent package review. No commit, push, body append or readiness change has been made. The exact performance checkout remains at reviewed head `21df57f8d3da84fa2ea94512f2674facdaa1547c`; all original Astra material remains untouched. Proposed append-only destination: `docs/measurements/multicore-149/results-2026-11-08/`.

Package: `/home/david/Documents/Codex/2026-11-07/tak-2/work/perf270-publication/package`.

Exactly ten files, 13,282,171 bytes. `PACKAGE-INVENTORY.tsv` and `PACKAGE-FILES.sha256` beside this checkpoint bind every file, including the outer manifest. Full-package manifest SHA-256: `b9070cef4a14a5b9c138dbfe044e044bab289e0aed49374339a4d1d43b3efe8a`. Outer `SHA256SUMS` SHA-256: `93e30b971f77b90cd51fc057919903a00791913b46a4de087fd223fba800293c`.

| Archive | Regular members | SHA-256 |
|---|---:|---|
| timing-records.tar.gz | 4538 | `7006ce99afe189d546451fac35c6bd32a2db4d64d1ec5303a9864ce18f383c00` |
| wait-records.tar.gz | 867 | `b67ec346768266583a8448fc674e012ed458adabef85d53be47b9fcd323c15b8` |
| independent-audits.tar.gz | 229 | `25dbb3c0284c98442b394922da7bc93e149d33c486cc40ab717cc23200610f51` |
| failures-and-history.tar.gz | 117 | `6c399e089a01bd5b0d5131b7896f185db9e0eb8c43a0164cdd7bb0908962c87d` |

The four derivative ledgers cover 5739 staged originals: 5608 byte-identical copies, 59 strict single-block removals and 72 exact whole-file metadata-only exceptions (32,499 original bytes / 301 original lines). Each scope adds its generated ledger, inventory and internal manifest; all 5751 archive members are regular files. The exact final timing reader, wait reader and unchanged mutator are separate outer files with hashes `83c5a3f5…`, `286f1669…`, `9b13ba3a…`.

The one admitted fresh copy attempt, archive assembly and public review all exited zero. Logs/status files are preserved beside this checkpoint. Before-copy, after-copy and after-archive complete raw-tree manifests are byte-identical, each SHA-256 `7cfd11a5539ef4e40a5a5027a430d8ea2d37a4c21a32e659ed6d93884bc83c6a`. The embedded staged-original manifest binds all 5738 other input files and has SHA-256 `862447b03c2471b58c25a6b8ae7006237da0e232d5820f627beef962c2a6a380`.

The first refused public-copy attempt, its exact recipe/log/status and 5721-file scratch manifest remain retained separately; its payload was never used as archive input. The rejected initial sanitizer source was never built or applied. The final strict sanitizer and pinned qualified binary are unchanged. No native compiler process or new measurement was run for packaging.

Review commands (publication checks only):

```sh
cd /home/david/Documents/Codex/2026-11-07/tak-2/work/perf270-publication/package
sha256sum --check --strict ../PACKAGE-FILES.sha256
sh review.sh
cd ..
cmp raw-before.sha256 raw-after-derive.sha256
cmp raw-before.sha256 raw-after-archives.sha256
git -C ../perf270-resume/performance rev-parse HEAD
git -C ../perf270-resume/performance status --short
```

The proposed PR-body addition is `proposed-body-append.md` beside this checkpoint, SHA-256 `2afcc1d76f7384c86f244f9680b4c2b235571592ae5aef7581eb429eb6e8968a`. Preserve the existing body verbatim, append the reviewed addition, and replace its `RECORD_COMMIT` placeholder only after separately authorized publication yields the actual commit. Independent actual-package review and root decision are pending; record qualification does not grant parent-issue acceptance or merge authority.
