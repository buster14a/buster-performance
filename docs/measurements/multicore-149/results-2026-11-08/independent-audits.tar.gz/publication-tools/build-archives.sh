#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Package an already reviewed public derivative tree. Never transform originals.
set -euo pipefail
public=$(realpath "$1")
package=$(realpath "$2")
test -d "$public"
test -d "$package"
test -z "$(find "$public" -type l -print -quit)"
test -z "$(find "$public" ! -type f ! -type d -print -quit)"
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
for scope in timing waits audits failures
do
    case "$scope" in
        timing) archive=timing-records.tar.gz ;;
        waits) archive=wait-records.tar.gz ;;
        audits) archive=independent-audits.tar.gz ;;
        failures) archive=failures-and-history.tar.gz ;;
    esac
    test ! -e "$package/$archive"
    test ! -e "$public/$scope/SHA256SUMS"
    test ! -e "$public/$scope/INVENTORY.txt"
    (
        cd "$public/$scope"
        find . -type f -printf '%P\0' | LC_ALL=C sort -z > "$scratch/payload"
        printf 'bytes\tarchive-member\n' > "$scratch/inventory"
        while IFS= read -r -d '' member
        do
            case "$member" in
                ''|/*|../*|*/../*|*$'\n'*|*$'\t'*|*.o|*.a|*.so|*.zst|*/.git/*|*/__pycache__/*) exit 1 ;;
            esac
            printf '%s\t%s\n' "$(wc -c < "$member")" "$member" >> "$scratch/inventory"
        done < "$scratch/payload"
        # Inventory lists the payload, including its derivative map, but not itself
        # or SHA256SUMS. The manifest covers the inventory and all payload bytes.
        cp "$scratch/inventory" INVENTORY.txt
        find . -type f ! -path ./SHA256SUMS -printf '%P\0' | LC_ALL=C sort -z > "$scratch/manifest-members"
        xargs -0 sha256sum < "$scratch/manifest-members" > SHA256SUMS
        sha256sum --check --strict SHA256SUMS > "$scratch/check-$scope.log"
        find . -type f -printf '%P\0' | LC_ALL=C sort -z > "$scratch/archive-members"
        # No directory/link/device entries. Headers have fixed mtime, uid/gid and
        # mode; gzip carries no source filename or timestamp. Payload is unchanged.
        tar --format=gnu --no-recursion --null --files-from="$scratch/archive-members" \
            --mtime=@0 --owner=0 --group=0 --numeric-owner --mode=0644 -cf - |
            gzip -n -9 > "$package/$archive"
    )
done
(
    cd "$package"
    test "$(find . -maxdepth 1 -type f | wc -l)" = 9
    sha256sum README.md timing-records.tar.gz wait-records.tar.gz \
        independent-audits.tar.gz failures-and-history.tar.gz record_review.c \
        wait_record_review.c record_mutate.c review.sh > SHA256SUMS
)
printf 'archive-build-status=complete\n'
