#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Metadata-only catalog. Never transform or print holder command contents.
set -euo pipefail
inspection=$1
raw=$(realpath "$2")
printf 'archive-path\toriginal-sha256\tbytes\tlines\tfinal-LF\tcomplete-line-shape\town-record-lines\tprotected-literal-lines\tmetadata-shape\n'
while IFS=$'\t' read -r source digest result ignored
do
    test "$result" = REJECTED || continue
    source=$(realpath "$source")
    relative=${source#"$raw/"}
    test "$relative" != "$source"
    test "$(sha256sum "$source" | cut -d' ' -f1)" = "$digest"
    size=$(wc -c < "$source")
    count=$(awk 'END { print NR }' "$source")
    last=$(tail -c 1 "$source" | od -An -t x1 | tr -d ' \n')
    lf=no
    test "$last" != 0a || lf=yes
    shape=$(awk '{ if ($0 ~ /^exclusive.sh: waiting for the 9700X, held by: /) s="W"; else if ($0 ~ /^  title: /) s="T"; else if ($0 ~ /^  link: /) s="L"; else if ($0 ~ /^  pull request: /) s="P"; else if ($0 ~ /^lock-guard/) s="G"; else if ($0 ~ /^(case-status|parent-issue-status|observation-status|wait-status|time-stage|time-process|wait-diagnostic|INDEPENDENT)/) s="S"; else s="O"; printf "%s%s", NR == 1 ? "" : ",", s }' "$source")
    own=$(awk '/^lock-guard|^(case-status|parent-issue-status|observation-status|wait-status|time-stage|time-process|wait-diagnostic|INDEPENDENT)|^[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]T.* (multicore-149|codex-01a1b81e-perf270)/ { n++ } END { print n+0 }' "$source")
    literal=$(awk '/lock-guard|case-status|parent-issue-status|observation-status|wait-status|time-stage|time-process|wait-diagnostic|INDEPENDENT|multicore-149/ { n++ } END { print n+0 }' "$source")
    kind=UNCLASSIFIED-REQUIRES-REVIEW
    case "$shape" in
        W) kind=EOF-waiting-holder-only ;;
        W,T) kind=EOF-waiting-holder-and-title-only ;;
        W,O*,T,L|W,O*,T,L,P) kind=multiline-holder-command-with-title-link ;;
        W,O*,T) kind=multiline-holder-command-with-title-EOF ;;
    esac
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$relative" "$digest" "$size" "$count" "$lf" "$shape" "$own" "$literal" "$kind"
done < <(tail -n +2 "$inspection")
