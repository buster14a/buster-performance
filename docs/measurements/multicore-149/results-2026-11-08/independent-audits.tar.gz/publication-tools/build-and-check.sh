#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
set -euo pipefail
cd "$(dirname -- "$0")"
export LC_ALL=C LANG=C TZ=UTC
unset CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH LIBRARY_PATH COMPILER_PATH GCC_EXEC_PREFIX LD_PRELOAD LD_LIBRARY_PATH MAKEFLAGS MFLAGS
source_identity() {
    sha256sum sanitize_queue.c build-and-check.sh sanitize_queue-fixtures/*
}
finish() {
    qualification_result=$?
    trap - EXIT
    set +e
    source_identity > input-identities.after.sha256
    identity_result=$?
    cmp input-identities.before.sha256 input-identities.after.sha256
    compare_result=$?
    if test "$qualification_result" = 0 && { test "$identity_result" != 0 || test "$compare_result" != 0; }
    then
        qualification_result=1
    fi
    printf 'source-fixture-identity-after-status=%s compare-status=%s\n' "$identity_result" "$compare_result"
    printf 'qualification-exit=%s\n' "$qualification_result"
    date -u '+qualification-end=%Y-%m-%dT%H:%M:%SZ'
    exit "$qualification_result"
}
source_identity > input-identities.before.sha256
trap finish EXIT
set -x
date -u '+qualification-start=%Y-%m-%dT%H:%M:%SZ'
cat /var/lib/buster-9700x/owner
printf '%s\n' '6299873eb353b157084d552858ac1227c20936cddb630054b3e8f499c4837997  sanitize_queue.c' | sha256sum --check --strict
printf '%s\n' '32bee0b85c99421865fa73f9d9365442dd44ba67e223635c1fdcdc3be4de6ccb  sanitize_queue-fixtures/SHA256SUMS' | sha256sum --check --strict
(cd sanitize_queue-fixtures && sha256sum --check --strict SHA256SUMS)
clang_tool=/home/david/.cache/buster/benchpress-clang/efdd1dbd089b99bfcfcde7b8eb1236163f2e88df5a981cca4f783ec9cb5e0378/bin/clang
"$clang_tool" --version > toolchain-version.txt
cat toolchain-version.txt
sha256sum "$clang_tool" > toolchain.sha256
cat toolchain.sha256
printf '%s  %s\n' c336d48383874cffaab0dc4c5c359456d871f21380b746520dde5c7f4c125a67 "$clang_tool" | sha256sum --check --strict
"$clang_tool" -std=c17 -O2 -g0 -Wall -Wextra -Werror sanitize_queue.c -o sanitize_queue
sha256sum sanitize_queue > binary.sha256
cat binary.sha256
mkdir outputs
negative_fixture() {
    fixture_name=$1
    set +e
    ./sanitize_queue "sanitize_queue-fixtures/$fixture_name.input" "outputs/$fixture_name.output" > "outputs/$fixture_name.stdout" 2> "outputs/$fixture_name.stderr"
    fixture_result=$?
    set -e
    printf 'fixture=%s observed-exit=%s expected-exit=1\n' "$fixture_name" "$fixture_result"
    test "$fixture_result" = 1
    test ! -e "outputs/$fixture_name.output"
    test ! -L "outputs/$fixture_name.output"
    test ! -s "outputs/$fixture_name.stdout"
    test ! -s "outputs/$fixture_name.stderr"
    printf 'fixture=%s negative=PASS output-absent=1 stdout-empty=1 stderr-empty=1\n' "$fixture_name"
}
negative_fixture malformed-nested
negative_fixture malformed-own-guard
negative_fixture unicode-c1
set +e
./sanitize_queue sanitize_queue-fixtures/strict-ci-block.input outputs/strict-ci-block.output > outputs/strict-ci-block.stdout 2> outputs/strict-ci-block.stderr
fixture_result=$?
set -e
printf 'fixture=strict-ci-block observed-exit=%s expected-exit=0\n' "$fixture_result"
test "$fixture_result" = 0
test ! -s outputs/strict-ci-block.stdout
printf 'sanitized-blocks=1\n' | cmp - outputs/strict-ci-block.stderr
cmp sanitize_queue-fixtures/strict-ci-block.expected outputs/strict-ci-block.output
printf 'fixture=strict-ci-block positive=PASS exact-output=1 stdout-empty=1 stderr-count=1\n'
set +e
./sanitize_queue sanitize_queue-fixtures/empty-holder.input outputs/empty-holder.output > outputs/empty-holder.stdout 2> outputs/empty-holder.stderr
fixture_result=$?
set -e
printf 'fixture=empty-holder observed-exit=%s expected-exit=0\n' "$fixture_result"
test "$fixture_result" = 0
test ! -s outputs/empty-holder.stdout
printf 'sanitized-blocks=0\n' | cmp - outputs/empty-holder.stderr
cmp sanitize_queue-fixtures/empty-holder.input outputs/empty-holder.output
printf 'fixture=empty-holder positive=PASS exact-output=1 stdout-empty=1 stderr-count=0\n'
printf 'sanitizer-qualification=PASS build=1 fixtures=5 negative=3 positive=2\n'
