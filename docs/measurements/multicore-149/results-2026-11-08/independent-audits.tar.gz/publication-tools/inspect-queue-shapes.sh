#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Scratch-only inspection after a fail-closed publication-copy rejection.
set -euo pipefail
list=$1
sanitizer=$(realpath "$2")
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
printf 'source\toriginal-sha256\tresult\tline-count\tfirst-line-shapes\n'
index=0
while IFS= read -r source
do
    index=$((index + 1))
    digest=$(sha256sum "$source" | cut -d' ' -f1)
    if "$sanitizer" "$source" "$scratch/copy-$index" > "$scratch/stdout" 2> "$scratch/stderr"
    then
        result=$(cat "$scratch/stderr")
    else
        result=REJECTED
    fi
    count=$(wc -l < "$source")
    shape=$(awk 'NR <= 12 { if ($0 ~ /^exclusive.sh: waiting for the 9700X, held by: /) s="W"; else if ($0 ~ /^  title: /) s="T"; else if ($0 ~ /^  link: /) s="L"; else if ($0 ~ /^  pull request: /) s="P"; else if ($0 ~ /^lock-guard/) s="G"; else if ($0 ~ /^(case-status|observation-status|wait-status|time-stage|wait-diagnostic|INDEPENDENT)/) s="S"; else s="O"; printf "%s%s", NR == 1 ? "" : ",", s }' "$source")
    printf '%s\t%s\t%s\t%s\t%s\n' "$source" "$digest" "$result" "$count" "$shape"
done < "$list"
