#!/usr/bin/env bash
set -u
qualification_root=/home/david/buster-fast-bench/149-codex-01a1b81e-20261107/package-tools/sanitizer-6299873e-controls-20261108
export EXCLUSIVE_OWNER=codex-01a1b81e-sanitizer-control
export EXCLUSIVE_TITLE='PR270 publication sanitizer: one build and five controls'
export EXCLUSIVE_LINK=https://github.com/buster14a/buster-performance/pull/270
/home/david/buster-fast-bench/exclusive.sh timeout --signal=TERM --kill-after=5s 55s bash "$qualification_root/build-and-check.sh" > "$qualification_root/qualification.log" 2>&1
qualification_result=$?
printf '%s\n' "$qualification_result" > "$qualification_root/qualification.status"
exit "$qualification_result"
