#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# PROPOSED copy-only publication recipe: never execute before independent approval.
# Strict sanitizer source629 / qualified binary89df remains unchanged. Public
# native rebuilds may produce another binary and require explicit equivalent
# qualification; this pinned execution/replay scope is the retained originals.
#
# Whole-file exceptions are ONLY the exact72 individually reviewed metadata-only
# holder files catalogued in queue-rejections.tsv (SHA b7d7076a3468618ff54e49504b757e539ae22e7152e53e326abe36426d239951).
# Their fixed six-column allowlist binds every canonical path, original digest,
# byte count, LF-line count, final-LF state and reviewed reason. All72 rows are
# checked against raw regular, nonlinked files BEFORE the public directory is
# created. Expected totals are32499 original bytes /301 original LF lines.
# No shape inference, fallback or relaxed sanitizer is used for exceptions.
# All other selected logs retain v1's strict filtering and stop on any rejection.
set -euo pipefail
test "$#" -eq 4
readonly allowlist_sha256=a550db37df0f0b09df1ff1ec947fe9417e95c20af1f8b09046cb2f7fb959eac2
readonly sanitizer_sha256=89df4da47ed1772d8834be01b69c6bcf664b81b55c53bdef543319fae6a66017
readonly omission_marker='[publication: exact reviewed metadata-only shared-lock holder file omitted; original identity and removed line count are recorded in SANITIZATION.tsv]'
raw=$(realpath -- "$1")
public_argument=$2
sanitizer=$(realpath -- "$3")
allowlist=$(realpath -- "$4")
test -d "$raw"
test -f "$sanitizer" && test -x "$sanitizer" && test ! -L "$sanitizer"
test -f "$allowlist" && test ! -L "$allowlist"
test ! -e "$public_argument" && test ! -L "$public_argument"
public=$(realpath -m -- "$public_argument")
test ! -e "$public" && test ! -L "$public"
test -d "$(dirname -- "$public")"
case "$public/" in "$raw/"|"$raw/"*) exit 1 ;; esac
case "$raw/" in "$public/"*) exit 1 ;; esac
test "$(sha256sum -- "$allowlist" | cut -d' ' -f1)" = "$allowlist_sha256"
test "$(sha256sum -- "$sanitizer" | cut -d' ' -f1)" = "$sanitizer_sha256"
test -z "$(find "$raw" -type l -print -quit)"
test -z "$(find "$raw" ! -type f ! -type d -print -quit)"
for scope in timing waits audits failures
do
    test -d "$raw/$scope"
    for reserved in SHA256SUMS INVENTORY.txt SANITIZATION.tsv
    do
        test ! -e "$raw/$scope/$reserved" && test ! -L "$raw/$scope/$reserved"
    done
done

canonical_relative() {
    local value=$1
    [[ "$value" =~ ^(timing|waits|audits|failures)/[A-Za-z0-9._/-]+$ ]]
    case "/$value/" in *'/./'*|*'/../'*|*'//'*) return 1 ;; esac
}

final_lf() {
    local filename=$1
    local last_byte
    last_byte=$(tail -c 1 -- "$filename" | od -An -tu1 | tr -d '[:space:]')
    if test "$last_byte" = 10
    then
        printf 'yes\n'
    else
        printf 'no\n'
    fi
}

validate_exception() {
    local relative=$1 expected_hash=$2 expected_bytes=$3 expected_lines=$4 expected_lf=$5
    local original="$raw/$relative"
    canonical_relative "$relative"
    case "$relative" in *.log|*.stderr) ;; *) return 1 ;; esac
    test -f "$original" && test ! -L "$original"
    test "$(stat -c '%h' -- "$original")" = 1
    test "$(realpath -- "$original")" = "$original"
    test "$(sha256sum -- "$original" | cut -d' ' -f1)" = "$expected_hash"
    test "$(stat -c '%s' -- "$original")" = "$expected_bytes"
    test "$(LC_ALL=C wc -l < "$original" | tr -d '[:space:]')" = "$expected_lines"
    test "$(final_lf "$original")" = "$expected_lf"
}

# Fixed-hash input plus structural checks: precisely six nonempty fields, exact
# header, final LF,72 unique canonical file paths and reviewed reasons only.
test "$(tail -c 1 -- "$allowlist" | od -An -tu1 | tr -d '[:space:]')" = 10
LC_ALL=C awk -F '\t' 'NF != 6 || /\r/ { exit 1 }' "$allowlist"
declare -A omission_hash omission_bytes omission_lines omission_lf omission_reason
rows=0
total_bytes=0
total_lines=0
exec 3< "$allowlist"
IFS= read -r header <&3
test "$header" = $'archive-path\toriginal-sha256\tbytes\tlines\tfinal-LF\treason'
while IFS=$'\t' read -r relative expected_hash expected_bytes expected_lines expected_lf reason <&3
do
    canonical_relative "$relative"
    [[ "$expected_hash" =~ ^[0-9a-f]{64}$ ]]
    [[ "$expected_bytes" =~ ^[1-9][0-9]{0,7}$ ]]
    [[ "$expected_lines" =~ ^[1-9][0-9]{0,7}$ ]]
    test "$expected_bytes" -le 16777216
    test "$expected_lines" -le "$expected_bytes"
    case "$expected_lf" in yes|no) ;; *) exit 1 ;; esac
    case "$reason" in
        reviewed-exact-EOF-holder-and-title-only|reviewed-exact-EOF-holder-only|reviewed-exact-multiline-holder-command-only) ;;
        *) exit 1 ;;
    esac
    test "${omission_hash[$relative]+present}" != present
    validate_exception "$relative" "$expected_hash" "$expected_bytes" "$expected_lines" "$expected_lf"
    omission_hash[$relative]=$expected_hash
    omission_bytes[$relative]=$expected_bytes
    omission_lines[$relative]=$expected_lines
    omission_lf[$relative]=$expected_lf
    omission_reason[$relative]=$reason
    rows=$((rows + 1))
    total_bytes=$((total_bytes + expected_bytes))
    total_lines=$((total_lines + expected_lines))
done
exec 3<&-
test "$rows" -eq 72
test "${#omission_hash[@]}" -eq 72
test "$total_bytes" -eq 32499
test "$total_lines" -eq 301
test "$(sha256sum -- "$allowlist" | cut -d' ' -f1)" = "$allowlist_sha256"

# Finish all preflight checks before creating public. The temporary list is
# outside raw/public; canonical member names exclude traversal and TSV escapes.
scratch=$(mktemp -d /tmp/perf270-public-copy.XXXXXXXX)
trap 'rm -rf "$scratch"' EXIT
find "$raw" -type f -print0 | LC_ALL=C sort -z > "$scratch/files"
while IFS= read -r -d '' original
do
    relative=${original#"$raw/"}
    canonical_relative "$relative"
done < "$scratch/files"
mkdir -- "$public"
cp -a -- "$raw/." "$public/"
for scope in timing waits audits failures
do
    printf 'archive-member\toriginal-sha256\tpublic-sha256\tremoved-blocks\texception-original-bytes\texception-original-lines\ttransform\treason\n' > "$public/$scope/SANITIZATION.tsv"
done
applied=0
applied_bytes=0
applied_lines=0
while IFS= read -r -d '' original
do
    relative=${original#"$raw/"}
    scope=${relative%%/*}
    member=${relative#*/}
    destination="$public/$relative"
    original_hash=$(sha256sum -- "$original" | cut -d' ' -f1)
    blocks=0
    exception_bytes=0
    exception_lines=0
    transform=byte-identical-copy
    reason=byte-identical-copy
    if test "${omission_hash[$relative]+present}" = present
    then
        # This is an explicit root-reviewed whole-file exception, NOT a claim
        # that a malformed/incomplete holder contained any removable blocks.
        validate_exception "$relative" "${omission_hash[$relative]}" "${omission_bytes[$relative]}" "${omission_lines[$relative]}" "${omission_lf[$relative]}"
        test "$original_hash" = "${omission_hash[$relative]}"
        candidate="$destination.public-copy"
        test ! -e "$candidate" && test ! -L "$candidate"
        (set -o noclobber; printf '%s\n' "$omission_marker" > "$candidate")
        mv -- "$candidate" "$destination"
        exception_bytes=${omission_bytes[$relative]}
        exception_lines=${omission_lines[$relative]}
        transform=reviewed-whole-file-exception
        reason=${omission_reason[$relative]}
        applied=$((applied + 1))
        applied_bytes=$((applied_bytes + exception_bytes))
        applied_lines=$((applied_lines + exception_lines))
    else
        case "$original" in
            *.log|*.stderr)
                if LC_ALL=C grep -a -q '^exclusive.sh: waiting for the 9700X, held by: ' "$original"
                then
                    candidate="$destination.public-copy"
                    test ! -e "$candidate" && test ! -L "$candidate"
                    if "$sanitizer" "$original" "$candidate" 2> "$scratch/filter.status"
                    then
                        grep -qx 'sanitized-blocks=[0-9][0-9]*' "$scratch/filter.status"
                        blocks=$(cut -d= -f2 "$scratch/filter.status")
                        mv -- "$candidate" "$destination"
                        if test "$blocks" != 0
                        then
                            transform=strict-holder-block-filter
                            reason=unrelated-waiting-holder-blocks-omitted
                        fi
                    else
                        rm -f -- "$candidate"
                        printf 'PUBLICATION-STOPPED unaccepted-log-shape=%s original-sha256=%s\n' "$relative" "$original_hash" >&2
                        exit 1
                    fi
                fi
                ;;
        esac
    fi
    public_hash=$(sha256sum -- "$destination" | cut -d' ' -f1)
    if test "$reason" = byte-identical-copy
    then
        test "$original_hash" = "$public_hash"
    fi
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$member" "$original_hash" "$public_hash" "$blocks" "$exception_bytes" "$exception_lines" "$transform" "$reason" >> "$public/$scope/SANITIZATION.tsv"
done < "$scratch/files"
test "$applied" -eq 72
test "$applied_bytes" -eq 32499
test "$applied_lines" -eq 301
printf 'reviewed-whole-file-exceptions=%s original-bytes=%s original-lines=%s\n' "$applied" "$applied_bytes" "$applied_lines"
printf 'publication-copy-status=complete\n'
