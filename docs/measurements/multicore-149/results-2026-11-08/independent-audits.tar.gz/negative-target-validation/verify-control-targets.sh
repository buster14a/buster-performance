#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Reconstruct text artifacts only in a new scratch tree; never run a native control.
set -euo pipefail
export LC_ALL=C
workspace=/home/david/Documents/Codex/2026-11-07/tak-2
snapshot=$workspace/work/perf270-control-targets-v2
review=$workspace/work/perf270-public-package-review
test "$(sha256sum "$snapshot/TARGETS.tsv" | cut -d' ' -f1)" = abda359717e363c16cc8082a01e8b2c7bf7c9be696c7ade9276154a71de62869
test "$(sha256sum "$snapshot/SHA256SUMS" | cut -d' ' -f1)" = 9487c63aee3b38b24711693fadcef254a3c46d934107c1a11661bf89473f8706
(cd "$snapshot" && sha256sum --check --strict --status SHA256SUMS)
test ! -e "$review/control-patch-replay"
mkdir "$review/control-patch-replay"
rows=0; changed=0; directories=0; arguments=0; headers=0
while IFS=$'\t' read -r family label control type target before_source after_source archive member before_hash after_hash retained patch auxiliary log_source log_hash log_member driver driver_hash detail
do
    test "$family" = family && continue
    case "$archive" in timing-records.tar.gz) scope=timing ;; wait-records.tar.gz) scope=waits ;; *) exit 1 ;; esac
    original=$review/extracted/$scope/$member
    test "$(sha256sum "$review/extracted/audits/$log_member" | cut -d' ' -f1)" = "$log_hash"
    case "$family" in timing) retained_driver=$snapshot/tools/negative-tests-v3.sh ;; wait) retained_driver=$snapshot/tools/wait-negative-tests.sh ;; *) exit 1 ;; esac
    test "$(sha256sum "$retained_driver" | cut -d' ' -f1)" = "$driver_hash"
    case "$type" in
        changed-text)
            test -f "$original" && test ! -L "$original"
            test "$(sha256sum "$original" | cut -d' ' -f1)" = "$before_hash"
            test "$(sha256sum "$snapshot/$retained" | cut -d' ' -f1)" = "$after_hash"
            replay=$review/control-patch-replay/$family-$label-$control.txt
            patch --batch --fuzz=0 --output "$replay" "$original" "$snapshot/$patch" > "$review/control-patch-replay/$family-$label-$control.log"
            cmp "$replay" "$snapshot/$retained"
            test "$(sha256sum "$replay" | cut -d' ' -f1)" = "$after_hash"
            changed=$((changed+1))
            case "$control" in stage-header-*) headers=$((headers+1)) ;; esac ;;
        directory-only)
            test "$family" = timing && test "$control" = extra-record && test "$target" = extra-sample
            test ! -e "$original" && test ! -L "$original"
            test "$before_hash" = NA && test "$after_hash" = NA && test "$retained" = NA && test "$patch" = NA
            grep -Fx 'before=absent' "$snapshot/$auxiliary" > /dev/null
            grep -Fx 'after=empty-directory' "$snapshot/$auxiliary" > /dev/null
            grep -Fx 'operation=mkdir extra-sample' "$snapshot/$auxiliary" > /dev/null
            directories=$((directories+1)) ;;
        argument-only)
            test "$family" = wait && test "$control" = wrong-owner
            test "$before_hash" = "$after_hash"
            test "$(sha256sum "$original" | cut -d' ' -f1)" = "$before_hash"
            cmp "$snapshot/auxiliary/wait/sqlite-8/original-compiler.pid" "$review/extracted/waits/ordinary/wait-sqlite-8/sample/compiler.pid"
            pid=$(cat "$snapshot/auxiliary/wait/sqlite-8/original-compiler.pid")
            grep -Fx "captured-compiler-pid=$pid" "$snapshot/$auxiliary" > /dev/null
            grep -Fx "tested-pid-argument=$((pid+1))" "$snapshot/$auxiliary" > /dev/null
            arguments=$((arguments+1)) ;;
        *) exit 1 ;;
    esac
    rows=$((rows+1))
done < "$snapshot/TARGETS.tsv"
test "$rows" -eq 52 && test "$changed" -eq 48 && test "$directories" -eq 3 && test "$arguments" -eq 1 && test "$headers" -eq 9
(cd "$snapshot" && sha256sum --check --strict --status SHA256SUMS)
printf 'negative-target-reconstruction=PASS controls=52 original-public-before-hashes=48 patches-applied=48 exact-after-texts=48 directory-only=3 argument-only=1 header-controls-within-timing39=9 log-bindings=52 driver-bindings=52 native-controls-rerun=0 object-byte-targets=0\n'
