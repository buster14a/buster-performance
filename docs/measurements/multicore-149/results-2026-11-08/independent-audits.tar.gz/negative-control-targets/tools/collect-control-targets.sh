#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Later read-only snapshot of already completed immutable copied fixtures.
# No fixture mutation, reader/control execution, compiler process or object-byte copy.
set -euo pipefail
export LC_ALL=C TZ=UTC
review=/home/david/buster-fast-bench/149-codex-01a1b81e-independent-review
campaign=/home/david/buster-fast-bench/149-codex-01a1b81e-20261107
out=$review/public-control-targets-v2-20261108
test ! -e "$out"
test "$(sha256sum "$review/negative-tests-v3.sh" | cut -d' ' -f1)" = 126b508052e5c9bbeff2c2f10f52640437168d7aee557dbd8fcb0653926d6280
test "$(sha256sum "$review/wait-negative-tests.sh" | cut -d' ' -f1)" = 4fa10aa04e776cb166b94725986deb8641dceccdf6fa1c100beaa67e5d98488d
test "$(sha256sum "$review/fixture.c" | cut -d' ' -f1)" = 9b13ba3a372da3259a03bd2c0d7d041bf808c5012660cbb2ee7555292a2dac89
mkdir "$out"
trap 'result=$?; printf "%s\n" "$result" > "$out/collection.status"' EXIT
mkdir "$out/tools" "$out/targets" "$out/patches" "$out/auxiliary"
cp -- "$review/collect-control-targets.sh" "$review/negative-tests-v3.sh" "$review/wait-negative-tests.sh" "$review/fixture.c" "$out/tools/"
date -u '+collection-time-utc=%Y-%m-%dT%H:%M:%SZ' > "$out/COLLECTION.txt"
printf 'scope=later read-only snapshot of completed retained fixtures; not a native control rerun or a contemporaneous target-hash receipt\n' >> "$out/COLLECTION.txt"
printf 'family\tcase\tcontrol\ttype\ttarget\tbefore-source\tafter-source\toriginal-archive\toriginal-member\tbefore-sha256\tafter-sha256\tretained-after\tpatch\tauxiliary\tcontrol-log-source\tcontrol-log-sha256\tcontrol-log-public-member\tdriver-source\tdriver-sha256\tdetail\n' > "$out/TARGETS.tsv"
rows=0
changed=0
structural=0
arguments_only=0
headers=0

regular() {
    test -f "$1" && test ! -L "$1"
    test "$(stat -c '%h' "$1")" = 1
    test "$(realpath "$1")" = "$1"
}
digest() { sha256sum -- "$1" | cut -d' ' -f1; }
marker() { test "$(cat "$1/INDEPENDENT-REVIEW-FIXTURE")" = independent-review-copy; }
emit() { local IFS=$'\t'; printf '%s\n' "$*" >> "$out/TARGETS.tsv"; rows=$((rows+1)); }

record_text() {
    local family=$1 label=$2 control=$3 target=$4 before=$5 after=$6 original=$7 archive=$8 member=$9
    local log=${10} log_member=${11} driver=${12} detail=${13}
    regular "$before"; regular "$after"; regular "$original"; regular "$log"; regular "$driver"
    cmp -- "$before" "$original"
    local before_hash after_hash after_file patch_file diff_status
    before_hash=$(digest "$before"); after_hash=$(digest "$after")
    test "$before_hash" != "$after_hash"
    after_file=targets/$family/$label/$control.after.txt
    patch_file=patches/$family/$label/$control.patch
    mkdir -p "$out/$(dirname "$after_file")" "$out/$(dirname "$patch_file")"
    cp -- "$after" "$out/$after_file"
    test "$(digest "$out/$after_file")" = "$after_hash"
    set +e
    diff -u --label "original/$target" --label "corrupted/$target" "$before" "$after" > "$out/$patch_file"
    diff_status=$?
    set -e
    test "$diff_status" = 1
    emit "$family" "$label" "$control" changed-text "$target" "$before" "$after" "$archive" "$member" "$before_hash" "$after_hash" "$after_file" "$patch_file" NA "$log" "$(digest "$log")" "$log_member" "$driver" "$(digest "$driver")" "$detail"
    changed=$((changed+1))
    case "$control" in stage-header-*) headers=$((headers+1)) ;; esac
}

timing_driver=$review/negative-tests-v3.sh
for label in sqlite synth musl
do
    set_root=$review/fixtures-$label-v4-attempt1
    base=$set_root/positive
    marker "$base"
    for control in count lanes cpu status object-hash guard stage stage-header-malformed stage-header-missing stage-header-duplicate summary policy extra-record
    do
        copy=$set_root/$control
        marker "$copy"
        log=$set_root/$control.log
        log_member=evidence/$label/fixtures-$label-v4-attempt1/$control.log
        case "$control" in
            count|lanes|status) target=reference/sample.tsv ;;
            cpu) target=reference/argv.txt ;;
            object-hash) target=warmup-0/objects.sha256 ;;
            guard) target=reference.lock.stdout ;;
            stage|stage-header-*) target=diagnostic-0/stderr.txt ;;
            summary) target=summary.tsv ;;
            policy) target=warmup-0/host-policy.after.txt ;;
            extra-record)
                test ! -e "$base/extra-sample"
                test ! -e "$campaign/timing-$label/extra-sample"
                test -d "$copy/extra-sample" && test ! -L "$copy/extra-sample"
                test -z "$(find "$copy/extra-sample" -mindepth 1 -print -quit)"
                regular "$log"
                auxiliary=auxiliary/timing/$label/extra-record.txt
                mkdir -p "$out/$(dirname "$auxiliary")"
                printf 'type=directory-only\nrelative-path=extra-sample\nbefore=absent\nafter=empty-directory\noperation=mkdir extra-sample\nobservation-time=collection time, after the completed original control\n' > "$out/$auxiliary"
                emit timing "$label" "$control" directory-only extra-sample "$base/extra-sample" "$copy/extra-sample" timing-records.tar.gz "records/timing-$label/extra-sample" NA NA NA NA "$auxiliary" "$log" "$(digest "$log")" "$log_member" "$timing_driver" "$(digest "$timing_driver")" 'empty-directory creation; no target file or object bytes'
                structural=$((structural+1))
                continue ;;
        esac
        detail='exact retained corrupted text target; original before bytes equal the archived original target'
        if test "$control" = object-hash
        then
            detail='ASCII SHA256 receipt byte0 flip only; no binary object was corrupted or copied'
            auxiliary=auxiliary/timing/$label/object-hash-ascii.txt
            mkdir -p "$out/$(dirname "$auxiliary")"
            printf 'type=textual-digest-receipt\npath=warmup-0/objects.sha256\nbyte-offset=0\nbefore-byte-hex=%s\nafter-byte-hex=%s\nobject-bytes=not-read-or-copied\n' "$(od -An -tx1 -N1 "$base/$target" | tr -d '[:space:]')" "$(od -An -tx1 -N1 "$copy/$target" | tr -d '[:space:]')" > "$out/$auxiliary"
        fi
        record_text timing "$label" "$control" "$target" "$base/$target" "$copy/$target" "$campaign/timing-$label/$target" timing-records.tar.gz "records/timing-$label/$target" "$log" "$log_member" "$timing_driver" "$detail"
    done
done

set_root=$review/wait-trace-fixtures-attempt1
base=$set_root/positive
marker "$base"
wait_driver=$review/wait-negative-tests.sh
pid_file=$campaign/wait-sqlite-8/sample/compiler.pid
regular "$pid_file"
pid=$(cat "$pid_file")
[[ "$pid" =~ ^[1-9][0-9]*$ ]]
test "$pid" -lt 2147483647
mkdir -p "$out/auxiliary/wait/sqlite-8"
cp -- "$pid_file" "$out/auxiliary/wait/sqlite-8/original-compiler.pid"
for control in missing-metric duplicate-metric unknown-kind wrong-owner duplicate-tid wrong-cpu clock-error bucket-count max-bucket elapsed-bound unsigned-format calibration impossible-outcome
do
    copy=$set_root/$control
    marker "$copy"
    log=$set_root/$control.log
    log_member=evidence/waits/wait-trace-fixtures-attempt1/$control.log
    if test "$control" = wrong-owner
    then
        regular "$base/trace"; regular "$copy/trace"; regular "$log"
        cmp "$base/trace" "$copy/trace"
        cmp "$base/trace" "$campaign/wait-sqlite-8/sample/stderr.txt"
        auxiliary=auxiliary/wait/sqlite-8/wrong-owner.txt
        printf 'type=argument-only\ntrace-bytes=unchanged\ncaptured-compiler-pid=%s\ntested-pid-argument=%s\nreconstruction=exact reviewed driver computes expected_pid=pid+1\noriginal-pid-receipt-sha256=%s\n' "$pid" "$((pid+1))" "$(digest "$pid_file")" > "$out/$auxiliary"
        emit wait sqlite-8 "$control" argument-only trace "$base/trace" "$copy/trace" wait-records.tar.gz ordinary/wait-sqlite-8/sample/stderr.txt "$(digest "$base/trace")" "$(digest "$copy/trace")" NA NA "$auxiliary" "$log" "$(digest "$log")" "$log_member" "$wait_driver" "$(digest "$wait_driver")" 'PID argument changed according to reviewed driver; trace file unchanged'
        arguments_only=$((arguments_only+1))
    else
        record_text wait sqlite-8 "$control" trace "$base/trace" "$copy/trace" "$campaign/wait-sqlite-8/sample/stderr.txt" wait-records.tar.gz ordinary/wait-sqlite-8/sample/stderr.txt "$log" "$log_member" "$wait_driver" 'exact retained corrupted trace; max-bucket name exercises general max/elapsed gate'
    fi
done
test "$rows" -eq 52 && test "$changed" -eq 48 && test "$structural" -eq 3 && test "$arguments_only" -eq 1 && test "$headers" -eq 9
printf 'collection=PASS controls=%s changed-texts=%s directory-only=%s argument-only=%s header-controls-within-timing39=%s\n' "$rows" "$changed" "$structural" "$arguments_only" "$headers" >> "$out/COLLECTION.txt"
printf 'object-byte-targets=0; timing object-hash controls mutate only text digest receipt byte0\ntransport=none included; no fair-queue holder output is part of this snapshot\n' >> "$out/COLLECTION.txt"
printf '0\n' > "$out/collection.status"
(cd "$out" && find . -type f ! -path ./SHA256SUMS -printf '%P\0' | sort -z | xargs -0 sha256sum) > "$out/SHA256SUMS"
cat "$out/COLLECTION.txt"
sha256sum "$out/TARGETS.tsv" "$out/SHA256SUMS"
