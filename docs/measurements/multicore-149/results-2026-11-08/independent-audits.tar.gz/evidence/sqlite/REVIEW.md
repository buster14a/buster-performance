# SQLite compilation timing records: independent review

**Record-integrity qualification: PASS.** Scope is the closed SQLite timing
case at `~/buster-fast-bench/149-codex-01a1b81e-20261107/timing-sqlite`, using
performance tools `21df57f8d3da84fa2ea94512f2674facdaa1547c` and compiler
`2dc50258e8b33393474b64032a5cbe9f17c63def`. This is not parent-issue acceptance,
current-main validation, or permission to start ordinary wait observations.
Root accepted this limited qualification; synth/musl and cross-case review
remain outstanding.

## Full-record audit

`sqlite-audit-attempt2-v4.log` and its status 0 record the independent audit:

- Exactly 82 expected samples: reference 1, warm-ups 9, normal measurements 63,
  stage diagnostics 9; all statuses/interruption fields, object counts,
  verification flags and placement/argv records pass.
- All per-grant guards and wrapper windows pass, including descendant cleanup
  and sample wall <= guard <= wrapper. Maximum guard: 291800079 ns.
- All nine raw diagnostic teams/pins, 30 required stage rows and stage tables
  pass; all nine summary rows are recomputed from the 63 normal measurements.
- Source/compiler/tool identities, 792 supplied input hashes, prepared-manifest
  pins, host policy and environment stability pass. The normal compiler SHA256
  is `51b54dd02986a28f294c0d5b2539e93739acb8962851127316da7953d4f8b09b`.
- All 82 object-hash receipts equal the retained reference. The actual reference
  object is independently rehashed; successful other objects were fully
  compared then deleted by the reviewed runner, so this audit does not claim
  a second independent byte comparison of those deleted files.

Primary one-lane median is 139.785250 ms; eight lanes 131.518821 ms
(1.062853582x). The separate CPU-2 one-lane control is 140.329778 ms. These are
descriptive observations at this compiler/artifact placement. The stage-based
serial lower-bound fraction 0.872145977 comes from instrumented diagnostic 0,
not an independently established unperturbed serial fraction. Normal worker
placement relies on the pinned driver's fail-closed pinning; diagnostic pins
show startup placement, not utilization or residency.

## Immutable binding and local snapshot

All three full 1500-file manifests, including the retained reference object,
are identical before the audit, after it, and after all copied-fixture tests:

`4bfaeee165f677f979fea2a0296b890ddda8a1f4ba609ea5870e033905365fd8`.

The local owner snapshot at `work/perf270-resume/observed/timing-sqlite`
independently matches all 1499 non-object entries exactly. Its sole omission is
`reference/sqlite3.o`, retained on Benchpress and rehashed as
`7a9b89275df8613cedc83c3463553109b6bbf9364c622fc1a846eff20c8860fb`.

## Reader correction and controls

Attempt 1 is preserved in `sqlite-audit-attempt1.log` (status 1). Reader source
`3e9b8684...` incorrectly attempted to parse the legitimate stage-table header's
literal `ms` as a measurement. This was my reader bug, not a protocol failure.
The frozen runner identifies known stage names before parsing values.

Reader v4 adds exact seven-field header recognition and requires one header per
diagnostic. No original numeric, identity, sample-count, pin, policy, guard,
object or summary checks were relaxed. Root and a second reviewer checked the
minimal change against the raw diagnostic and frozen runner before the locked
build/audit.

`sqlite-fixtures-attempt1.log`, status 0, records one passing positive copy and
13 deliberately corrupted fresh copies, each returning status 1 with its
expected diagnostic: original count/lane/CPU/status/hash/guard/stage/summary/
policy/extra-record controls, plus malformed, missing and duplicate headers.
The missing-header control relabels the copied header's record tag as an
unrelated log, leaving zero recognized headers. The unchanged C mutator requires
the explicit copy marker, checks real paths, rejects symlinks and writes by
temporary replacement. All full copied fixtures, including objects, remain at
`~/buster-fast-bench/149-codex-01a1b81e-independent-review/fixtures-sqlite-v4-attempt1`.
The original case was not edited.

## Tool identities and execution

- Reader v4 source: `83c5a3f53041b6303f409068003bf6edde908d8cdb8b7fd85b1dc16bdf3c3ea4`.
- Reader v4 binary: `e7446aebf92bf9eec1dc9da7136477bf983e46b778bf58caf753c6beaf383897`.
- Audit wrapper: `6d04cd6cd8ddb20e97e91630ec7ddf6804249093994479ab15e4c54c5040a856`.
- Guarded fixture source: `9b13ba3a372da3259a03bd2c0d7d041bf808c5012660cbb2ee7555292a2dac89`.
- Fixture binary: `27803dad664f3a6ec3c682c10693259c11f658cce143a01f6b8f1557c1010696`.
- Negative wrapper v3: `126b508052e5c9bbeff2c2f10f52640437168d7aee557dbd8fcb0653926d6280`.

Build command used pinned Clang 23.1.4 with
`-std=c17 -O2 -Wall -Wextra -Werror -fno-strict-aliasing review-v4.c -lm -o review-v4`.
Build, actual audit and fixture validation each received their own exclusive
Benchpress grant with bounded timeouts. Actual audit started 2026-11-08
01:27:59 UTC; controls ran 01:35:56–01:35:57 UTC. Source/helper copies and the
exact frozen runner parser excerpt are in sibling `tools/`.

Original compiler/tool binaries and objects remain outside the compiler
repository. Initial reader sources/receipts and the rg-to-grep shell adjustment
are retained. No GitHub acceptance post or normal-wait admission file was made.
