#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Same copied-record controls as SQLite, with cohort identities pinned.
set -euo pipefail
cd "$HOME/buster-fast-bench/149-codex-01a1b81e-independent-review"
label=$1
objects=$2
inputs=$3
case "$label:$objects:$inputs" in synth:512:1301|musl:1309:2509) ;; *) exit 2 ;; esac
record="$HOME/buster-fast-bench/149-codex-01a1b81e-20261107/timing-$label"
printf 'fixture-validation-start=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
test "$(cat "$label-audit-attempt1-v4.status")" = 0
sha256sum review-v4.c review-v4 fixture.c fixture negative-tests-v3.sh
bash negative-tests-v3.sh "$record" "$objects" "$inputs" "fixtures-$label-v4-attempt1"
(
    cd "$record"
    find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum
) > "$label-record-v4.post-fixtures.sha256"
cmp "$label-record-v4.after.sha256" "$label-record-v4.post-fixtures.sha256"
sha256sum "$label-record-v4.post-fixtures.sha256"
printf 'fixture-validation-end=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
printf 'closed-original-records-unchanged=PASS\n'
