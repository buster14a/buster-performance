#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Bind immutable ordinary waits and already accepted timing records before/after a read-only review.
set -euo pipefail
cd "$(dirname -- "$0")"
review_root=$PWD
campaign=$(realpath "$1")
printf 'review-time-utc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
sha256sum wait-review.c wait-review wait-review-once.sh wait-negative-tests.sh fixture.c fixture
test "$(sha256sum "$campaign/ordinary-wait-records.before.sha256" | cut -d' ' -f1)" = 3b5637689dc6bbc6e6081e0c3eb942e2197044a83ff7c48827226c38523a570d
test "$(wc -l < "$campaign/ordinary-wait-records.before.sha256")" -eq 827
manifest() {
    (
        cd "$campaign"
        for label in sqlite synth musl
        do
            for lane in 1 2 3 4 5 6 7 8
            do
                record="wait-$label-$lane"
                test -d "$record"
                test -z "$(find "$record" -type l -print -quit)"
                find "$record" -type f -print0
                printf '%s\0' "$record-controller.log" "$record-controller.status"
            done
        done
        printf '%s\0' independent-timing-review.txt wait-controller.sh ordinary-wait-24-commands.txt wait-controller.log wait-controller.status wait-controller-start.txt wait-controller.pid provenance.txt build-wait-launcher.sh build-wait-launcher.log build-wait-launcher.status
    ) | LC_ALL=C sort -zu | (cd "$campaign" && xargs -0 sha256sum)
}
timing_binding() {
    for label in sqlite synth musl
    do
        case "$label" in
            sqlite) wanted=4bfaeee165f677f979fea2a0296b890ddda8a1f4ba609ea5870e033905365fd8 ;;
            synth) wanted=99375315b1b389d07d0f8ac2c5101d6ca5a97ac76ae8dabe832416c5e8463e7f ;;
            musl) wanted=652aeb3831494e0df06e64e8d6d98ae075caeb4a6fa4d95e83f9ad0b836c9e73 ;;
        esac
        test "$(sha256sum "$label-record-v4.after.sha256" | cut -d' ' -f1)" = "$wanted"
        (cd "$campaign/timing-$label" && sha256sum --check --strict --status "$review_root/$label-record-v4.after.sha256")
        printf 'accepted-timing-original=%s unchanged-manifest=%s\n' "$label" "$wanted"
    done
}
manifest > wait-records.independent-before.sha256
cmp "$campaign/ordinary-wait-records.before.sha256" wait-records.independent-before.sha256
timing_binding
./wait-review "$campaign"
manifest > wait-records.independent-after.sha256
cmp wait-records.independent-before.sha256 wait-records.independent-after.sha256
timing_binding
printf 'full-wait-record-manifest='
sha256sum wait-records.independent-after.sha256
printf 'full-wait-record-files='
wc -l < wait-records.independent-after.sha256
printf 'ordinary-wait-review=PASS immutable-827-file-records=identical accepted-timing-records=unchanged\n'
