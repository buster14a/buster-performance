#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Run approved copied-trace controls, then bind the untouched originals again.
set -euo pipefail
cd "$(dirname -- "$0")"
review_root=$PWD
campaign=/home/david/buster-fast-bench/149-codex-01a1b81e-20261107
sha256sum wait-review.c wait-review wait-negative-tests.sh wait-controls-and-bind.sh fixture.c fixture
./wait-negative-tests.sh "$campaign/wait-sqlite-8" wait-trace-fixtures-attempt1
test "$(sha256sum "$campaign/ordinary-wait-records.before.sha256" | cut -d' ' -f1)" = 3b5637689dc6bbc6e6081e0c3eb942e2197044a83ff7c48827226c38523a570d
(
    cd "$campaign"
    cut -c67- ordinary-wait-records.before.sha256 | tr '\n' '\0' | xargs -0 sha256sum
) > wait-records.independent-post-controls.sha256
cmp wait-records.independent-before.sha256 wait-records.independent-post-controls.sha256
printf 'post-controls-full-wait-manifest='
sha256sum wait-records.independent-post-controls.sha256
for label in sqlite synth musl
do
    (cd "$campaign/timing-$label" && sha256sum --check --strict --status "$review_root/$label-record-v4.after.sha256")
    printf 'post-controls-accepted-timing-original=%s unchanged=PASS\n' "$label"
done
awk -F= '
  $1=="guard-monotonic-ns" { if ($2>guard) {guard=$2; guardfile=FILENAME} }
  $1=="wrapper-wall-ns-including-wait" { if ($2>wrapper) {wrapper=$2; wrapperfile=FILENAME} }
  END {
    printf "maximum-guard-ns=%.0f record=%s\n", guard, guardfile;
    printf "maximum-wrapper-ns-including-queue=%.0f record=%s\n", wrapper, wrapperfile;
    print "limits=active-guard255seconds;queue-inclusive-wrapper1200seconds;observed-wrapper-is-not-active-lock-duration";
  }' "$campaign"/wait-{sqlite,synth,musl}-{1,2,3,4,5,6,7,8}/observation-status.txt
printf 'post-controls-binding=PASS originals=unchanged\n'
