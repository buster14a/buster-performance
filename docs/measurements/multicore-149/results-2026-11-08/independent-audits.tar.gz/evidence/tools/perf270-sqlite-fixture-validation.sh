#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
set -euo pipefail
cd "$HOME/buster-fast-bench/149-codex-01a1b81e-independent-review"
record="$HOME/buster-fast-bench/149-codex-01a1b81e-20261107/timing-sqlite"
printf 'fixture-validation-start=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
test "$(cat sqlite-audit-attempt2-v4.status)" = 0
sha256sum review-v4.c review-v4 fixture.c fixture negative-tests-v3.sh
bash negative-tests-v3.sh "$record" 1 792 fixtures-sqlite-v4-attempt1
(
    cd "$record"
    find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum
) > sqlite-record-v4.post-fixtures.sha256
cmp sqlite-record-v4.after.sha256 sqlite-record-v4.post-fixtures.sha256
sha256sum sqlite-record-v4.post-fixtures.sha256
printf 'fixture-validation-end=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
printf 'closed-original-records-unchanged=PASS\n'
