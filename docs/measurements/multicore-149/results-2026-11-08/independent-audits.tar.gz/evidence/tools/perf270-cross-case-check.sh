#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Read-only cross-case comparison of already closed/audited local snapshots.
# No compiler, measurement, original-record write, or wait admission.
set -euo pipefail
cd "$1"
evidence="$PWD/work/perf270-independent-review-evidence"
observed="$PWD/work/perf270-resume/observed"
scratch="$evidence/cross-case"
mkdir "$scratch"
sha256sum work/perf270-review-independent-v4.c work/perf270-review-negative-tests-v3.sh work/perf270-cross-case-check.sh
for label in sqlite synth musl
do
    case "$label" in
        sqlite) audit=sqlite-audit-attempt2-v4; objects=1; inputs=792 ;;
        synth) audit=synth-audit-attempt1-v4; objects=512; inputs=1301 ;;
        musl) audit=musl-audit-attempt1-v4; objects=1309; inputs=2509 ;;
    esac
    case_root="$observed/timing-$label"
    receipt_root="$evidence/$label"
    test "$(cat "$receipt_root/$audit.status")" = 0
    test "$(cat "$receipt_root/$label-fixtures-attempt1.status")" = 0
    test "$(grep -c '^mutation=.*reader-exit=1 expected-check=PASS$' "$receipt_root/$label-fixtures-attempt1.log")" -eq 13
    grep -Fx 'positive-copy=PASS' "$receipt_root/$label-fixtures-attempt1.log" > /dev/null
    grep -Fx 'independent-reader-fixtures=PASS positive=1 rejected-corruptions=13' "$receipt_root/$label-fixtures-attempt1.log" > /dev/null
    grep -F 'e7446aebf92bf9eec1dc9da7136477bf983e46b778bf58caf753c6beaf383897  review-v4' "$receipt_root/$audit.log" > /dev/null
    cmp "$receipt_root/$label-record-v4.before.sha256" "$receipt_root/$label-record-v4.after.sha256"
    cmp "$receipt_root/$label-record-v4.after.sha256" "$receipt_root/$label-record-v4.post-fixtures.sha256"
    awk '$2 !~ /[.]o$/ { print }' "$receipt_root/$label-record-v4.after.sha256" > "$scratch/$label-nonobjects.expected.sha256"
    (cd "$case_root" && find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum) > "$scratch/$label-nonobjects.actual.sha256"
    cmp "$scratch/$label-nonobjects.expected.sha256" "$scratch/$label-nonobjects.actual.sha256"
    test "$(wc -l < "$scratch/$label-nonobjects.actual.sha256")" -eq 1499
    awk '$2 ~ /[.]o$/ {
      if (index($2, "./reference/") != 1 || index(substr($2,13), "/") != 0) exit 1;
      print substr($2,13)
    }' "$receipt_root/$label-record-v4.after.sha256" | LC_ALL=C sort > "$scratch/$label-reference-objects.txt"
    LC_ALL=C sort "$case_root/case/outputs.txt" > "$scratch/$label-required-objects.txt"
    cmp "$scratch/$label-reference-objects.txt" "$scratch/$label-required-objects.txt"
    test "$(wc -l < "$scratch/$label-reference-objects.txt")" -eq "$objects"
    test "$(wc -l < "$case_root/case/sources.sha256")" -eq "$inputs"
    awk 'NR <= 6 || NR >= 11' "$case_root/identity.before.txt" > "$scratch/$label-common-identity.txt"
    cmp "$observed/timing-sqlite/host-policy.before.txt" "$case_root/host-policy.before.txt"
    cmp "$observed/timing-sqlite/host-policy.before.txt" "$case_root/host-policy.after.txt"
    cmp "$observed/timing-sqlite/environment.txt" "$case_root/environment.txt"
    cmp "$observed/timing-sqlite/environment.txt" "$case_root/environment.after.txt"
    cmp "$scratch/sqlite-common-identity.txt" "$scratch/$label-common-identity.txt"
    printf 'cross-case=%s object-count=%s input-hashes=%s local-nonobject-files=1499 qualified-controls=13\n' "$label" "$objects" "$inputs"
    sha256sum "$receipt_root/$label-record-v4.after.sha256" "$case_root/host-policy.before.txt" "$case_root/environment.txt"
done
awk '
  {
    h=substr($0,1,64); p=substr($0,67);
    if (length(h)!=64 || h ~ /[^0-9a-f]/ || substr($0,65,2)!="  " || substr(p,1,1)!="/") { bad=1; next }
    if ((p SUBSEP FILENAME) in fileSeen) { bad=1; next }
    fileSeen[p SUBSEP FILENAME]=1;
    if (p in hash && hash[p]!=h) { print "shared-input-hash-mismatch=" p; bad=1 }
    if (!(p in hash)) unique++;
    hash[p]=h; occurrences[p]++; records++;
  }
  END {
    if (bad || records!=4602) exit 1;
    for (p in occurrences) if (occurrences[p]>1) shared++;
    printf "input-union=PASS manifest-records=%d unique-paths=%d shared-paths=%d all-overlap-hashes-identical\n", records, unique, shared;
  }' "$observed/timing-sqlite/case/sources.sha256" "$observed/timing-synth/case/sources.sha256" "$observed/timing-musl/case/sources.sha256"
printf 'captured-policy-excerpts:\n'
grep -E '^(hostname|model)=|governor=|energy_performance_preference=|transparent_hugepage' "$observed/timing-sqlite/host-policy.before.txt"
printf 'cross-case-integrity=PASS samples=246 normal=189 warmup=27 diagnostic=27 reference=3 reference-objects=1822 object-digest-entries=149404\n'
printf 'boundary=record-integrity-only;no-parent-issue-or-normal-wait-admission\n'
