#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
# Trace-only corruptions of explicit copies using the unchanged guarded C mutator.
set -euo pipefail
cd "$(dirname -- "$0")"
record=$(realpath "$1")
set_name=$2
mkdir "$set_name"
base="$PWD/$set_name/positive"
mkdir "$base"
cp "$record/sample/stderr.txt" "$base/trace"
printf 'independent-review-copy\n' > "$base/INDEPENDENT-REVIEW-FIXTURE"
pid=$(cat "$record/sample/compiler.pid")
./wait-review --trace "$base/trace" 8 "$pid" > "$set_name/positive.log" 2>&1
printf 'positive-trace-copy=PASS\n'
metric=$'wait-diagnostic-metric\tlane=0\tkind=initial-spin\toutcome=completed\t'
calibration=$'wait-diagnostic-calibration\tlane=0\t'
for mutation in missing-metric duplicate-metric unknown-kind wrong-owner duplicate-tid wrong-cpu clock-error bucket-count max-bucket elapsed-bound unsigned-format calibration impossible-outcome
do
    copy="$PWD/$set_name/$mutation"
    cp -a --reflink=auto "$base" "$copy"
    expected_pid=$pid
    case "$mutation" in
        missing-metric)
            ./fixture "$copy" prefix-field trace "$metric" 0 removed-metric
            wanted='metric total/owner PID' ;;
        duplicate-metric)
            row=$(grep -F "$metric" "$copy/trace")
            ./fixture "$copy" append trace "$row"$'\n'
            wanted='metric identity/uniqueness' ;;
        unknown-kind)
            ./fixture "$copy" prefix-field trace "$metric" 2 kind=unknown
            wanted='metric identity/uniqueness' ;;
        wrong-owner)
            expected_pid=$((pid + 1))
            wanted='metric total/owner PID' ;;
        duplicate-tid)
            ./fixture "$copy" prefix-field trace $'wait-diagnostic\tlane=1\t' 2 "tid=$pid"
            wanted='duplicate worker TID' ;;
        wrong-cpu)
            ./fixture "$copy" prefix-field trace $'lane-pin\tindex=0\t' 3 observed=7
            wanted='pin CPU/status/uniqueness' ;;
        clock-error)
            ./fixture "$copy" prefix-field trace "$metric" 5 clock-errors=1
            wanted='metric count/clock/elapsed bounds' ;;
        bucket-count)
            ./fixture "$copy" prefix-field trace "$metric" 8 buckets=0,0,0,0,0,0,0,0
            wanted='metric count/clock/elapsed bounds' ;;
        max-bucket)
            ./fixture "$copy" prefix-field trace "$metric" 7 max-ns=0
            wanted='metric count/clock/elapsed bounds' ;;
        elapsed-bound)
            ./fixture "$copy" prefix-field trace "$metric" 6 elapsed-ns=0
            wanted='metric count/clock/elapsed bounds' ;;
        unsigned-format)
            ./fixture "$copy" prefix-field trace "$metric" 4 calls=01
            wanted='noncanonical integer' ;;
        calibration)
            ./fixture "$copy" prefix-field trace "$calibration" 3 failures=1
            wanted='calibration identity/count' ;;
        impossible-outcome)
            # Exchange completed/eagain labels to preserve all20 unique metric keys.
            ./fixture "$copy" prefix-field trace "$metric" 3 outcome=temporary
            ./fixture "$copy" prefix-field trace $'wait-diagnostic-metric\tlane=0\tkind=initial-spin\toutcome=eagain\t' 3 outcome=completed
            ./fixture "$copy" prefix-field trace $'wait-diagnostic-metric\tlane=0\tkind=initial-spin\toutcome=temporary\t' 3 outcome=eagain
            wanted='impossible spin/MWAITX outcome' ;;
    esac
    if ./wait-review --trace "$copy/trace" 8 "$expected_pid" > "$set_name/$mutation.log" 2>&1
    then status=0
    else status=$?
    fi
    test "$status" = 1
    grep -F "$wanted" "$set_name/$mutation.log" > /dev/null
    printf 'mutation=%s reader-exit=1 expected-check=PASS\n' "$mutation"
done
printf 'independent-wait-trace-controls=PASS positive=1 rejected-corruptions=13\n'
