#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
set -euo pipefail
cd "$(dirname -- "$0")"
label=$1
record=$(realpath "$2")
objects=$3
inputs=$4
printf 'review-time-utc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
printf 'review-case=%s\n' "$record"
sha256sum review-v4.c review-v4 fixture.c fixture negative-tests-v3.sh audit-once-v4.sh
test "$(cat "$record-controller.status")" = 0
sha256sum "$record-controller.log" "$record-controller.status"
manifest() { (cd "$record" && find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum); }
manifest > "$label-record-v4.before.sha256"
./review-v4 "$record" "$objects" "$inputs"
manifest > "$label-record-v4.after.sha256"
cmp "$label-record-v4.before.sha256" "$label-record-v4.after.sha256"
printf 'complete-record-manifest='
sha256sum "$label-record-v4.after.sha256"
printf 'complete-record-files='
wc -l < "$label-record-v4.after.sha256"
printf 'case-review-recorded=PASS immutable-record-before-after=identical\n'
