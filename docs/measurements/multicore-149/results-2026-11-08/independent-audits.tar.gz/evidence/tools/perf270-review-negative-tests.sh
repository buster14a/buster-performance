#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname -- "$0")"
record=$(realpath "$1")
expected_objects=$2
expected_inputs=$3
review=./review-v3
fixture_set=${4:-fixtures}
mkdir "$fixture_set"
base="$PWD/$fixture_set/positive"
cp -a --reflink=auto "$record" "$base"
printf 'independent-review-copy\n' > "$base/INDEPENDENT-REVIEW-FIXTURE"
./fixture "$base" rebase "$record" > "$fixture_set/positive-rebase.log"
"$review" "$base" "$expected_objects" "$expected_inputs" > "$fixture_set/positive.log" 2>&1
printf 'positive-copy=PASS\n'

for mutation in count lanes cpu status object-hash guard stage summary policy extra-record
do
    copy="$PWD/$fixture_set/$mutation"
    cp -a --reflink=auto "$base" "$copy"
    ./fixture "$copy" rebase "$base" > "$fixture_set/$mutation-rebase.log"
    case "$mutation" in
        count)
            ./fixture "$copy" field reference/sample.tsv 1 13 "$((expected_objects + 1))"
            wanted='[reference]: sample lanes/status/count/verified'
            ;;
        lanes)
            ./fixture "$copy" field reference/sample.tsv 1 0 2
            wanted='[reference]: sample lanes/status/count/verified'
            ;;
        cpu)
            ./fixture "$copy" field reference/argv.txt 4 0 7
            wanted='[reference]: ordered lane CPU argument'
            ;;
        status)
            ./fixture "$copy" field reference/sample.tsv 1 11 256
            wanted='[reference]: sample lanes/status/count/verified'
            ;;
        object-hash)
            ./fixture "$copy" flip warmup-0/objects.sha256
            wanted="[warmup-0]: changed receipt: $copy/warmup-0/objects.sha256"
            ;;
        guard)
            ./fixture "$copy" field reference.lock.stdout 0 3 monotonic-ns=1
            wanted='[reference]: guard clock/duration/order bound'
            ;;
        stage)
            ./fixture "$copy" prefix-field diagnostic-0/stderr.txt $'time-stage\ttotal\t' 2 0
            wanted='[diagnostic-0]: raw stage totals/wall bound'
            ;;
        summary)
            ./fixture "$copy" field summary.tsv 1 4 0
            wanted='[summary]: numeric mismatch:'
            ;;
        policy)
            ./fixture "$copy" append warmup-0/host-policy.after.txt $'deliberate-policy-change=1\n'
            wanted="[warmup-0]: changed receipt: $copy/warmup-0/host-policy.after.txt"
            ;;
        extra-record)
            mkdir "$copy/extra-sample"
            wanted='[case final]: extra/missing sample directories or per-grant receipts'
            ;;
    esac
    if "$review" "$copy" "$expected_objects" "$expected_inputs" > "$fixture_set/$mutation.log" 2>&1
    then
        status=0
    else
        status=$?
    fi
    test "$status" = 1
    rg -F "$wanted" "$fixture_set/$mutation.log" > /dev/null
    printf 'mutation=%s reader-exit=%s expected-check=PASS\n' "$mutation" "$status"
done
printf 'independent-reader-fixtures=PASS positive=1 rejected-corruptions=10\n'
