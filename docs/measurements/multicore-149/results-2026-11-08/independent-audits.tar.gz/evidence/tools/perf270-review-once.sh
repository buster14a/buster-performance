#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname -- "$0")"
label=$1
record=$(realpath "$2")
objects=$3
inputs=$4
printf 'review-time-utc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
printf 'review-case=%s\n' "$record"
sha256sum review-v3.c review-v3 fixture.c fixture negative-tests.sh
test "$(cat "$record-controller.status")" = 0
sha256sum "$record-controller.log" "$record-controller.status"
./review-v3 "$record" "$objects" "$inputs"
(
    cd "$record"
    find . -type f -print0 | sort -z | xargs -0 sha256sum
) > "$label-record.sha256"
printf 'complete-record-manifest='
sha256sum "$label-record.sha256"
printf 'complete-record-files='
wc -l < "$label-record.sha256"
printf 'case-review-recorded=PASS\n'
