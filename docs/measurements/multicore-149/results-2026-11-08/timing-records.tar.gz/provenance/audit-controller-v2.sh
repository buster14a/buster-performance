#!/bin/sh
set -u
audit_root=/home/david/buster-fast-bench/149-codex-01a1b81e-20261107
export EXCLUSIVE_OWNER=codex-01a1b81e-perf270-audit
export EXCLUSIVE_TITLE='Astra PR takeover: retained multicore identity audit'
export EXCLUSIVE_LINK=https://github.com/buster14a/buster-performance/pull/270
/home/david/buster-fast-bench/exclusive.sh timeout 60 sh "$audit_root/audit-retained-v2.sh" > "$audit_root/audit-v2.log" 2>&1
audit_result=$?
printf '%s\n' "$audit_result" > "$audit_root/audit-v2.status"
exit "$audit_result"
