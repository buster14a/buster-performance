#!/bin/sh
set -u
campaign_root=/home/david/buster-fast-bench/149-codex-01a1b81e-20261107
retained=/home/david/buster-fast-bench/149-merge-2dc-codex
export PATH=/usr/local/bin:/usr/bin:/bin
unset CORES BUSTER_HUGE_PAGES LD_PRELOAD LD_LIBRARY_PATH BUSTER_9700X_HELD
test "$(cat "$campaign_root/smoke-controller.status")" = 0 || exit 1
for campaign_case in sqlite synth musl
do
    date -u "+case=$campaign_case start=%Y-%m-%dT%H:%M:%SZ"
    "$campaign_root/tools/runner" --case "$retained/cases/$campaign_case" --output "$campaign_root/timing-$campaign_case" --compiler "$retained/compiler/build/compiler" --compiler-source "$retained/compiler" --lock /home/david/buster-fast-bench/exclusive.sh --runs 7 --cpus 0,1,2,3,4,5,6,7 > "$campaign_root/timing-$campaign_case-controller.log" 2>&1
    case_result=$?
    printf '%s\n' "$case_result" > "$campaign_root/timing-$campaign_case-controller.status"
    date -u "+case=$campaign_case end=%Y-%m-%dT%H:%M:%SZ result=$case_result"
    if test "$case_result" != 0
    then
        printf 'timing-status=failed\n' > "$campaign_root/timing-controller.status"
        exit "$case_result"
    fi
done
printf 'timing-status=completed\n' > "$campaign_root/timing-controller.status"
