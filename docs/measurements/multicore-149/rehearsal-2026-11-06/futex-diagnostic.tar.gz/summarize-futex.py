#!/usr/bin/env python3
from pathlib import Path
import re
p = Path.home() / 'buster-fast-bench/149-codex-01a1b0e1/diagnostic-sqlite-d944-no-clang-flag'
print('Diagnostic only: strace -ff -ttt -T -e futex; perturbed, no MWAITX timing or cycle-frequency evidence')
for f in sorted(p.glob('futex.*')):
    counts = {'ok': [], 'eagain': [], 'other': []}
    for line in f.read_text().splitlines():
        if 'FUTEX_WAIT' not in line:
            continue
        m = re.search(r'= (-?\d+)(?: (E[A-Z0-9]+))?.*<([0-9.]+)>$', line)
        if not m:
            counts['other'].append(None)
            continue
        n, err, t = m.groups()
        kind = 'ok' if n == '0' else 'eagain' if err == 'EAGAIN' else 'other'
        counts[kind].append(float(t))
    times = counts['ok']
    print(f'tid={f.name.removeprefix("futex.")} successful_waits={len(times)} eagain={len(counts["eagain"])} other_or_unparsed={len(counts["other"])} max_success_wait_ms={max(times, default=0)*1000:.3f} total_success_wait_ms={sum(times)*1000:.3f}')
