#!/usr/bin/env bash
set -uo pipefail
campaign="$HOME/buster-fast-bench/149-codex-01a1b0e1"
compiler="$campaign/compiler/build/compiler"
case_dir="$campaign/cases/sqlite"
diag="$campaign/diagnostic-sqlite-d944-no-clang-flag"
mkdir "$diag" || exit 1
mkdir "$diag/reference" "$diag/traced" || exit 1
mapfile -t args < <(awk '$0 != "--no-default-config"' "$case_dir/args.txt")
printf "%s\n" "${args[@]}" > "$diag/rehearsal-args.txt"
export EXCLUSIVE_OWNER=codex-149 EXCLUSIVE_TITLE='Multicore SQLite futex diagnostic' EXCLUSIVE_LINK=https://github.com/buster14a/buster-performance/pull/270
lock="$HOME/buster-fast-bench/exclusive.sh"
unset MAKEFLAGS MFLAGS CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH LIBRARY_PATH COMPILER_PATH GCC_EXEC_PREFIX BUSTER_CLANG_RESOURCE_DIR
export LC_ALL=C LANG=C TZ=UTC SOURCE_DATE_EPOCH=0
(cd "$campaign/compiler" && sha256sum --check "$campaign/native-inputs.sha256") > "$diag/input-identity-before.txt" 2>&1
sha256sum --check --strict --status "$case_dir/sources.sha256" || exit 1
printf '%q ' taskset -c 0-7 "$compiler" --lanes 1 --worker-budget=8 "${args[@]}" > "$diag/reference-command.txt"
printf '\n' >> "$diag/reference-command.txt"
status=0
(cd "$diag/reference" && timeout 300s "$lock" taskset -c 0-7 "$compiler" --lanes 1 --worker-budget=8 "${args[@]}") > "$diag/reference.stdout" 2> "$diag/reference.stderr" || status=$?
printf '%s\n' "$status" > "$diag/reference.status"
if test "$status" != 0; then exit "$status"; fi
printf '%q ' taskset -c 0-7 strace -ff -ttt -T -e trace=futex -o "$diag/futex" "$compiler" --lanes 8 --worker-budget=8 "${args[@]}" > "$diag/trace-command.txt"
printf '\n' >> "$diag/trace-command.txt"
status=0
(cd "$diag/traced" && timeout 300s "$lock" taskset -c 0-7 strace -ff -ttt -T -e trace=futex -o "$diag/futex" "$compiler" --lanes 8 --worker-budget=8 "${args[@]}") > "$diag/trace.stdout" 2> "$diag/trace.stderr" || status=$?
printf '%s\n' "$status" > "$diag/trace.status"
if test "$status" != 0; then exit "$status"; fi
sha256sum "$diag/reference/sqlite3.o" "$diag/traced/sqlite3.o" > "$diag/objects.sha256"
cmp "$diag/reference/sqlite3.o" "$diag/traced/sqlite3.o" > "$diag/objects.cmp" 2>&1 || exit 1
(cd "$campaign/compiler" && sha256sum --check "$campaign/native-inputs.sha256") > "$diag/input-identity-after.txt" 2>&1
sha256sum --check --strict --status "$case_dir/sources.sha256" || exit 1
printf 'diagnostic-complete, perturbed, d944-only, filtered Clang-only flag, no performance result\n' > "$diag/status.txt"
