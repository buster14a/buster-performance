#!/usr/bin/env bash
set -uo pipefail
campaign="$HOME/buster-fast-bench/149-codex-01a1b0e1"
cd "$campaign/compiler" || exit 1
mapfile -t tool_paths < "$campaign/github-path"
source "$campaign/github-env"
export PATH="${tool_paths[1]}:${tool_paths[0]}:$PATH" BUSTER_CLANG_RESOURCE_DIR LD_LIBRARY_PATH
export BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0 BUSTER_CI_CACHE="$HOME/.cache/buster/ci" BUSTER_ORACLE_CACHE=use
export BUSTER_COMPILER="$campaign/compiler/build/compiler" BUSTER_PPF_PRAGMA_ORACLE="$campaign/oracle" BUSTER_CORPUS="$campaign/corpus"
export EXCLUSIVE_OWNER=codex-149 EXCLUSIVE_TITLE='Multicore acceptance native qualification' EXCLUSIVE_LINK=https://github.com/buster14a/buster-performance/pull/270
lock="$HOME/buster-fast-bench/exclusive.sh"
git rev-parse HEAD > "$campaign/native-source-before.txt"
git status --porcelain=v1 >> "$campaign/native-source-before.txt"
sha256sum "$BUSTER_COMPILER" "$BUSTER_PPF_PRAGMA_ORACLE" tools/ci/correctness.tests tools/ci/correctness.costs > "$campaign/native-inputs.sha256"
failures=0
for shard in 1 2 3 4; do
  status=0
  timeout 540s "$lock" taskset -c 0-7 "$BUSTER_COMPILER" parallel --github --jobs 8 --timeout 480 --shard "$shard/4" --costs tools/ci/correctness.costs < tools/ci/correctness.tests > "$campaign/native-shard-$shard.log" 2>&1 || status=$?
  printf '%s\n' "$status" > "$campaign/native-shard-$shard.status"
  if test "$status" -ne 0; then failures=$((failures+1)); fi
done
git rev-parse HEAD > "$campaign/native-source-after.txt"
git status --porcelain=v1 >> "$campaign/native-source-after.txt"
sha256sum --check "$campaign/native-inputs.sha256" > "$campaign/native-inputs.verify" 2>&1 || failures=$((failures+1))
cmp "$campaign/native-source-before.txt" "$campaign/native-source-after.txt" || failures=$((failures+1))
printf '%s\n' "$failures" > "$campaign/native-failures.txt"
printf 'done\n' > "$campaign/native-done"
