#!/usr/bin/env bash
set -uo pipefail
campaign="$HOME/buster-fast-bench/149-codex-01a1b0e1"
cd "$campaign/compiler" || exit 1
mapfile -t tool_paths < "$campaign/github-path"
source "$campaign/github-env"
export PATH="${tool_paths[1]}:${tool_paths[0]}:$PATH" BUSTER_CLANG_RESOURCE_DIR LD_LIBRARY_PATH
export BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0 BUSTER_CI_CACHE="$HOME/.cache/buster/ci" BUSTER_ORACLE_CACHE=use
export BUSTER_COMPILER="$campaign/compiler/build/compiler" BUSTER_PPF_PRAGMA_ORACLE="$campaign/oracle" BUSTER_CORPUS="$campaign/corpus"
export EXCLUSIVE_OWNER=codex-149 EXCLUSIVE_TITLE='Multicore acceptance native qualification' EXCLUSIVE_LINK=https://github.com/buster14a/buster-performance/pull/270
lock="$HOME/buster-fast-bench/exclusive.sh"
mkdir -p "$campaign/individual"
for test_file in "$campaign"/sections/*.test; do
  id="$(basename "$test_file" .test)"
  status=0
  timeout 540s "$lock" taskset -c 0-7 "$BUSTER_COMPILER" parallel --github --jobs 8 --timeout 480 < "$test_file" > "$campaign/individual/$id.log" 2>&1 || status=$?
  printf '%s\n' "$status" > "$campaign/individual/$id.status"
done
sha256sum --check "$campaign/native-inputs.sha256" > "$campaign/individual-inputs.verify" 2>&1
printf 'done\n' > "$campaign/individual-done"
