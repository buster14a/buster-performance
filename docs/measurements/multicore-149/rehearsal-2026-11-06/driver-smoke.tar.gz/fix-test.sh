#!/usr/bin/env bash
set -euo pipefail
campaign="$HOME/buster-fast-bench/149-codex-01a1b0e1"
mapfile -t tool_paths < "$campaign/github-path"
source "$campaign/github-env"
export PATH="${tool_paths[1]}:${tool_paths[0]}:$PATH" BUSTER_CLANG_RESOURCE_DIR LD_LIBRARY_PATH
export EXCLUSIVE_OWNER=codex-149 EXCLUSIVE_TITLE='Multicore campaign compiler argument fix' EXCLUSIVE_LINK=https://github.com/buster14a/buster-performance/pull/270
lock="$HOME/buster-fast-bench/exclusive.sh"
run() {
  local name="$1"; shift
  local status=0
  timeout 540s "$lock" "$@" > "$campaign/$name.log" 2>&1 || status=$?
  printf '%s\n' "$status" > "$campaign/$name.status"
  return "$status"
}
sha256sum "$campaign/fix-source/prepare.c" > "$campaign/fix-source.sha256"
run fix-build-plain clang -std=c17 -O2 -Wall -Wextra -Werror -fno-strict-aliasing "$campaign/fix-source/prepare.c" -o "$campaign/tools/prepare-fixed"
run fix-build-sanitize clang -std=c17 -O1 -g -Wall -Wextra -Werror -fno-strict-aliasing -fno-omit-frame-pointer -fno-optimize-sibling-calls -fsanitize=address,undefined -fno-sanitize-recover=all "$campaign/fix-source/prepare.c" -o "$campaign/tools/prepare-fixed-san"
run fix-self-test-plain "$campaign/tools/prepare-fixed" --self-test --corpus "$campaign/corpus"
run fix-self-test-sanitize env ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 "$campaign/tools/prepare-fixed-san" --self-test --corpus "$campaign/corpus"
run fix-prepare "$campaign/tools/prepare-fixed" --corpus "$campaign/corpus" --synth "$campaign/synth" --output "$campaign/cases-fixed"
sha256sum "$campaign/tools/prepare-fixed" "$campaign/tools/prepare-fixed-san" > "$campaign/fix-binaries.sha256"
unset MAKEFLAGS MFLAGS CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH LIBRARY_PATH COMPILER_PATH GCC_EXEC_PREFIX BUSTER_CLANG_RESOURCE_DIR
export LC_ALL=C LANG=C TZ=UTC SOURCE_DATE_EPOCH=0
for name in sqlite synth musl; do
  mkdir "$campaign/fix-smoke-$name"
  mapfile -t arguments < "$campaign/cases-fixed/$name/args.txt"
  printf '%q ' taskset -c 0-7 "$campaign/compiler/build/compiler" --lanes 1 --worker-budget=8 "${arguments[@]}" > "$campaign/fix-smoke-$name.command"
  printf '\n' >> "$campaign/fix-smoke-$name.command"
  status=0
  (cd "$campaign/fix-smoke-$name" && timeout 480s "$lock" taskset -c 0-7 "$campaign/compiler/build/compiler" --lanes 1 --worker-budget=8 "${arguments[@]}") > "$campaign/fix-smoke-$name.log" 2>&1 || status=$?
  printf '%s\n' "$status" > "$campaign/fix-smoke-$name.status"
  if test "$status" -ne 0; then exit "$status"; fi
  (cd "$campaign/fix-smoke-$name" && while IFS= read -r file; do test -s "$file" || exit 1; done < "$campaign/cases-fixed/$name/outputs.txt")
  printf 'all-expected-objects-present\n' > "$campaign/fix-smoke-$name.objects"
done
(cd "$campaign/compiler" && sha256sum --check "$campaign/native-inputs.sha256") > "$campaign/fix-inputs.verify"
printf 'all-smokes-pass; diagnostic only, no acceptance\n' > "$campaign/fix-done"
