#!/usr/bin/env bash
set -euo pipefail
campaign="$HOME/buster-fast-bench/149-merge-2dc-codex"
cd "$campaign/compiler"
old="$HOME/buster-fast-bench/149-codex-01a1b0e1"
mapfile -t tool_paths < "$old/github-path"
source "$old/github-env"
export PATH="${tool_paths[1]}:${tool_paths[0]}:$PATH" BUSTER_CLANG_RESOURCE_DIR LD_LIBRARY_PATH
export BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0 BUSTER_CI_CACHE="$HOME/.cache/buster/ci" BUSTER_ORACLE_CACHE=check XDG_CACHE_HOME="$campaign/cache"
export EXCLUSIVE_OWNER=codex-149-merge EXCLUSIVE_TITLE='149 merged compiler native qualification' EXCLUSIVE_LINK=https://github.com/buster14a/buster-performance/pull/270
lock="$HOME/buster-fast-bench/exclusive.sh"
run() {
 local name="$1"; shift
 local result=0
 timeout 660 "$lock" bash -c 'head -1 /var/lib/buster-9700x/owner; exec "$@"' _ "$@" > "$campaign/$name.log" 2>&1 || result=$?
 printf '%s\n' "$result" > "$campaign/$name.status"
 return "$result"
}
test "$(git rev-parse HEAD)" = 2dc50258e8b33393474b64032a5cbe9f17c63def
test -z "$(git status --porcelain=v1)"
mkdir -p "$campaign/cache"
run clang-manifest bash tools/ci/tree-manifest.sh check "${tool_paths[0]%/bin}"
clang --version > "$campaign/clang.txt"
test "$(clang -dumpversion)" = 23.1.4
sha256sum "$(command -v clang)" > "$campaign/clang.sha256"
run vector bash -c 'clang -march=znver5 -Isrc -dM -E -include src/buster/compiler/host_isa.h -x c /dev/null | grep "^#define BUSTER_HOST_VECTOR 1$"'
run build taskset -c 0-7 ./build.sh --config Release
compiler="$(./build.sh print-output --config Release)"
test build/compiler -ef "$compiler"
sha256sum "$compiler" > "$campaign/compiler.sha256"
run predefines bash -c 'clang -dM -E -march=znver5 -fwrapv -funsigned-char -x c /dev/null > build/predefines.h'
run oracle bash -c 'flags=$(llvm-config --cxxflags --ldflags); read -r -a args <<< "${flags//$'"'"'\n'"'"'/ }"; exec taskset -c 0-7 clang++ -O2 -Wall -Werror tools/preprocessor_pragma_oracle.cpp "${args[@]}" -lclang-cpp -o "$1/oracle"' _ "$campaign"
"$campaign/oracle" --version > "$campaign/oracle-version.txt"
run fetch-corpus bash tools/ci/fetch-corpus.sh "$campaign/corpus"
run fetch-c-testsuite bash tools/ci/fetch-c-testsuite.sh build/c-testsuite
run parse taskset -c 0-7 "$compiler" parse -fsyntax-only -march=znver5 -Isrc -fwrapv -funsigned-char --predefines build/predefines.h src/buster/compiler/main.c
sha256sum "$compiler" "$campaign/oracle" tools/ci/correctness.tests tools/ci/correctness.costs build/predefines.h > "$campaign/inputs.sha256"
git rev-parse HEAD > "$campaign/source-before.txt"
git status --porcelain=v1 >> "$campaign/source-before.txt"
printf 'ok\n' > "$campaign/setup-done"
