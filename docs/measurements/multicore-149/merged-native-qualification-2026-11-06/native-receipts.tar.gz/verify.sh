#!/usr/bin/env bash
set -euo pipefail
campaign="$HOME/buster-fast-bench/149-merge-2dc-codex"
cd "$campaign/compiler"
old="$HOME/buster-fast-bench/149-codex-01a1b0e1"
mapfile -t tool_paths < "$old/github-path"
export EXCLUSIVE_OWNER=codex-149-merge EXCLUSIVE_TITLE='149 native qualification final identity audit' EXCLUSIVE_LINK=https://github.com/buster14a/buster-performance/pull/270
lock="$HOME/buster-fast-bench/exclusive.sh"
run() { local name="$1"; shift; local status=0; timeout 660 "$lock" bash -c 'head -1 /var/lib/buster-9700x/owner; exec "$@"' _ "$@" > "$campaign/$name-final.log" 2>&1 || status=$?; printf '%s\n' "$status" > "$campaign/$name-final.status"; return "$status"; }
run clang-manifest bash tools/ci/tree-manifest.sh check "${tool_paths[0]%/bin}"
sha256sum --check "$campaign/clang.sha256" > "$campaign/clang-final.verify"
sha256sum --check "$campaign/inputs.sha256" > "$campaign/inputs-final.verify"
root="$campaign/corpus"
printf '%s  %s\n' 391e729af6587355050881752558e790299cfe638c7dc7803bd028a8535ebcbd "$root/MANIFESTS.sha256" 8e6e646951cbd08c07bbc76ff46d6796a83a58e9b1c4959278b60193718cd10c "$root/manifests/headers.sha256" e307b836448ef20e603a617a4b5023831c72ff5f307f614c50f4f8833088717c "$root/manifests/headers-bundle.sha256" 9179b7ad7db7366d12a214b562e478ac703e7ec0376f38f4516756bcf7ee0047 "$root/manifests/sqlite.sha256" bf593a94954f3ed9431dd12e60233ec0229f7226a1fc270a701614a20f86baeb "$root/manifests/libc.sha256" 89dbe35f0324cf08d0cb9cf31ecf15092fc20783a9e470e80e5f41b1d48251d3 "$root/manifests/musl-generated.sha256" | sha256sum --check > "$campaign/corpus-manifests-final.verify"
(cd "$root/headers/usr" && sha256sum --check --status "$root/manifests/headers.sha256")
for entry in headers:headers-bundle libc:libc sqlite:sqlite musl-generated:musl-generated; do
 directory="$root/${entry%:*}"; manifest="$root/manifests/${entry#*:}.sha256"
 (cd "$directory" && sha256sum --check --status "$manifest")
 test "$(find "$directory" -type f -printf '.\n' | wc -l)" -eq "$(wc -l < "$manifest")"
 test -z "$(find "$directory" ! -type d ! -type f -print -quit)"
done
test "$(git -C build/c-testsuite rev-parse HEAD)" = 5c7275656d751de0e68b2d340a95b5681858ed07
test -z "$(git -C build/c-testsuite status --porcelain=v1)"
printf 'passed\n' > "$campaign/final-identity-done"
