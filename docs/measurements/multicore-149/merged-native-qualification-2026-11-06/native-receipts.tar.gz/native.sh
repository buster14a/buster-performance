#!/usr/bin/env bash
set -uo pipefail
campaign="$HOME/buster-fast-bench/149-merge-2dc-codex"
cd "$campaign/compiler" || exit 1
old="$HOME/buster-fast-bench/149-codex-01a1b0e1"
mapfile -t tool_paths < "$old/github-path"
source "$old/github-env"
export PATH="${tool_paths[1]}:${tool_paths[0]}:$PATH" BUSTER_CLANG_RESOURCE_DIR LD_LIBRARY_PATH
export BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0 BUSTER_CI_CACHE="$HOME/.cache/buster/ci" BUSTER_ORACLE_CACHE=check XDG_CACHE_HOME="$campaign/cache"
export BUSTER_COMPILER="$campaign/compiler/build/compiler" BUSTER_PPF_PRAGMA_ORACLE="$campaign/oracle" BUSTER_CORPUS="$campaign/corpus"
export EXCLUSIVE_OWNER=codex-149-merge EXCLUSIVE_LINK=https://github.com/buster14a/buster-performance/pull/270
unset CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH MAKEFLAGS
lock="$HOME/buster-fast-bench/exclusive.sh"
mkdir -p "$campaign/sections" "$campaign/results"
python3 - "$campaign/sections" <<'PY'
import pathlib,sys
out=pathlib.Path(sys.argv[1]); text=pathlib.Path('tools/ci/correctness.tests').read_text(); lines=text.splitlines(keepends=True); sections=[]
for line in lines:
 if line.startswith('== '): sections.append([])
 if sections: sections[-1].append(line)
assert len(sections)==126, len(sections)
for i, lines in enumerate(sections,1): (out/f'{i:03}.test').write_text(''.join(lines))
print(f'{len(sections)} named correctness commands')
PY
sha256sum --check "$campaign/inputs.sha256" > "$campaign/inputs-before.verify" 2>&1 || exit 1
printf 'id\texit\tsummary\n' > "$campaign/results.tsv"
for test_file in "$campaign"/sections/*.test; do
 id="$(basename "$test_file" .test)"
 export EXCLUSIVE_TITLE="149 merged native correctness section $id"
 status=0
 timeout 660 "$lock" bash -c 'head -1 /var/lib/buster-9700x/owner; exec taskset -c 0-7 "$BUSTER_COMPILER" parallel --github --jobs 8 --timeout 480' < "$test_file" > "$campaign/results/$id.log" 2>&1 || status=$?
 printf '%s\n' "$status" > "$campaign/results/$id.status"
 summary="$(grep '^parallel: ' "$campaign/results/$id.log" | tail -1 || true)"
 printf '%s\t%s\t%s\n' "$id" "$status" "$summary" >> "$campaign/results.tsv"
done
sha256sum --check "$campaign/inputs.sha256" > "$campaign/inputs-after.verify" 2>&1
printf '%s\n' "$?" > "$campaign/inputs-after.status"
git rev-parse HEAD > "$campaign/source-after.txt"
git status --porcelain=v1 >> "$campaign/source-after.txt"
cmp "$campaign/source-before.txt" "$campaign/source-after.txt" > "$campaign/source-compare.log" 2>&1
printf '%s\n' "$?" > "$campaign/source-compare.status"
printf 'done\n' > "$campaign/native-done"
