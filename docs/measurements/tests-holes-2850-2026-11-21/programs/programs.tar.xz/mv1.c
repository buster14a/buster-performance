static __attribute__((target("default"))) int f(void) { return 0; }
static __attribute__((target("avx2"))) int f(void) { return 1; }
int g(void) { return f(); }
