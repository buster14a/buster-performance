__attribute__((cpu_specific(generic))) int scaled(int n) { return n + 1; }
__attribute__((cpu_specific(haswell))) int scaled(int n) { return n * 3; }
__attribute__((cpu_dispatch(generic, haswell))) int scaled(int n);
int (*keep)(int) = scaled;
int caller(int n) { int (*p)(int) = scaled; return scaled(n) + p(n); }
