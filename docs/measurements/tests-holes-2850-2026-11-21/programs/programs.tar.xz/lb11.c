#pragma redefine_extname original renamed
int original = 9;
int other asm("chosen") = 13;
int f(void) { return original + other; }
