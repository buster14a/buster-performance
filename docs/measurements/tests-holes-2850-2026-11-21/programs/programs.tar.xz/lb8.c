#pragma redefine_extname original renamed
int original = 9;
int f(void) { return original; }
