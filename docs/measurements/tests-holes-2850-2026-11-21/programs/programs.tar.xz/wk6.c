static int h(void) { return 1; }
int f(void) { int h(void) __attribute__((weak)); return h(); }
