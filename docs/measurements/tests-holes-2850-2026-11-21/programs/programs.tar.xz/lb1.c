int x = 1;
extern int x asm("b");
int f(void) { return x; }
