int g(void) { return 1; }
int g(void) asm("b");
int f(void) { return g(); }
