enum A { A0, A1 };
int ga[8];
int f(long a, int* p, int* e, enum A ea)
{
    int x = 0;
    x = p < &ga[1];
    return x;
}
