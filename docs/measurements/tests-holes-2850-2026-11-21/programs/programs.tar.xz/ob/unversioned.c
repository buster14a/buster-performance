__attribute__((target("default"))) int versioned(int n) { return n; }
__attribute__((target("avx2"))) int versioned(int n) { return n + 1; }
int plain(int n);
int calls(int n) { return plain(n); }
