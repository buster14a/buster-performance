int g(int);
struct S {
#pragma redefine_extname g renamed_g
    int a; };
int uses(void) { return g(1); }
