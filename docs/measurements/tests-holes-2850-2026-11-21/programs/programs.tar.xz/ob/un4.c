int g(int);
int uses(int a) { return g(1
#pragma redefine_extname g renamed_g
 + a); }
