int declared(void) __attribute__((weak));
int declared(void) { return 1; }
int first(void) { return declared(); }
static int hidden(void) { return 1; }
int early(void) { return hidden(); }
int second(void) { int hidden(void) __attribute__((weak)); return hidden(); }
int late(void) { return hidden(); }
static int missing(void) __attribute__((weakref("target")));
int third(void) { return missing(); }
static int data __attribute__((weakref("external_data")));
int fourth(void) { return data; }
extern int plain_weak(void) __attribute__((weak));
int fifth(void) { return plain_weak ? plain_weak() : 0; }
