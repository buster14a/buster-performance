struct L { int first; int list[4]; };
void rel(int* p);
struct L whole(struct L* q, int n)
{
    int c __attribute__((cleanup(rel))) = n;
    return *q;
}
