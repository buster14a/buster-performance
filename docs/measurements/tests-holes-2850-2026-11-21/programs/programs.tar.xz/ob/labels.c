typedef unsigned long size_t;
void* memmove(void* destination, const void* source, size_t count) asm("moved");
void* memcpy(void* destination, const void* source, size_t count) { char* to = destination; const char* from = source; while (count--) *to++ = *from++; return destination; }
void* memcpy(void* destination, const void* source, size_t count) asm("ignored_copy");
int object = 1;
extern int object asm("ignored_object");
int tentative;
extern int tentative asm("kept_tentative");
extern int twice asm("same");
extern int twice asm("same");
int twice = 3;
int uses(char* to, const char* from, int n)
{
    register long kept asm("r10") = n;
    memcpy(to, from, 8);
    memmove(to, from, 8);
    return object + tentative + twice + (int)kept;
}
