struct L { int first; int list[4]; };
void rel(int* p);
struct L named(int n)
{
    int c __attribute__((cleanup(rel))) = n;
    struct L r;
    r.first = n;
    return r;
}
