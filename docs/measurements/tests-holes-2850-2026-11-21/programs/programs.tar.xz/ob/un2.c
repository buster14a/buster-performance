typedef unsigned long size_t;
void* memmove(void* destination, const void* source, size_t count) asm("moved");
int g(int);
#define g g
#pragma redefine_extname g renamed_g
int uses(char* to, const char* from)
{
    memmove(to, from, 8);
    return g(1);
}
