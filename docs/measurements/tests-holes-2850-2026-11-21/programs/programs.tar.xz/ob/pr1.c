typedef unsigned long size_t;
void* memcpy(void* destination, const void* source, size_t count);
#pragma redefine_extname memcpy renamed_copy
int after(char* to, const char* from) { memcpy(to, from, 8); return 2; }
