int file_scope __attribute__((nonnull)) = 5;
int other = 6;
int f(int n)
{
    static int sl asm("sl1") = 3;
    static int plain_static = 4;
    return sl + n + file_scope + other + plain_static;
}
