typedef unsigned long size_t;
void* memcpy(void* destination, const void* source, size_t count);
void* memmove(void* destination, const void* source, size_t count);
int plain(int n);
extern int other asm("other_name");
int before(char* to, const char* from) { memcpy(to, from, 8); return plain(1); }
#pragma redefine_extname memcpy renamed_copy
int after(char* to, const char* from) { memcpy(to, from, 8); memmove(to, from, 8); return plain(2) + other; }
extern int data;
#pragma redefine_extname data renamed_data
int read(void) { return data; }
