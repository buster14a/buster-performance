int __attribute__((overloadable)) chosen(int n);
int __attribute__((overloadable)) chosen(long n);
int plain(int n);
int before(int n) { return plain(n); }
int calls(int n) { return chosen(n); }
int after(int n) { return plain(n) + n; }
int none(int n) { (void)n; return n + 1; }
