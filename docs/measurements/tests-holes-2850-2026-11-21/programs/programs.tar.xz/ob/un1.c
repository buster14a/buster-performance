typedef unsigned long size_t;
void* memmove(void* destination, const void* source, size_t count) asm("moved");
int g(int);
int uses(char* to, const char* from)
{
    if (to)
    {
#pragma redefine_extname g renamed_g
        memmove(to, from, 8);
    }
    return g(1);
}
