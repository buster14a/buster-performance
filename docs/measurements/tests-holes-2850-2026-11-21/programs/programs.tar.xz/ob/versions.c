__attribute__((target("default"))) int versioned(int n) { return n; }
__attribute__((target("avx2"))) int versioned(int n) { return n + 1; }
int plain(int n);
int calls(int n) { int a = versioned(n); int b = plain(n); return a + b; }
int (*address(void))(int) { return versioned; }
int unused(int n) { return n * 2; }
