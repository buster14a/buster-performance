static int target(int n) { return n * 2; }
static int reference(int) __attribute__((weakref("target")));
int f(int n) { return reference(n); }
