static int data __attribute__((weakref("external_data")));
int f(void) { return data; }
