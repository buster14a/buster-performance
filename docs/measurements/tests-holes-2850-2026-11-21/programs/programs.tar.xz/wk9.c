int kept_out(void) __attribute__((weak));
int f(void) { return kept_out(); }
