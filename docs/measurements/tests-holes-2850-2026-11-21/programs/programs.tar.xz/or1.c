enum color { RED, GREEN };
int ga[8];
int one(int a);
struct pair { int first; int list[4]; };
int f(long a, int* p, struct pair* q, int (*fp)(int), int* e)
{
    int local = 0;
    enum color hue = RED;
    local = (a < p);
    local = (p >= a);
    local = (p <= 1);
    local = (ga > a);
    if (a < p) local = 1;
    local = (one < a);
    local = (p < 0);
    local = (p < e);
    local = (ga < p);
    local = (p == a);
    local = (int)ga;
    local = (char)q->list;
    local = (short)"x";
    local = (short)one;
    local = (unsigned char)*fp;
    hue = (enum color)ga;
    local = (int)p;
    local = (long)ga != 0;
    a = (long)ga;
    a = (long)one;
    return local + (int)hue;
}
