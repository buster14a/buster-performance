enum E { A, B };
void f(void) { enum E e3 = (enum { V1 })0; (void)e3; }
