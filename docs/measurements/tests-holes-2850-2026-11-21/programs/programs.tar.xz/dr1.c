void f(int n)
{
    int a __attribute__((nonnull)) = n;
    int b __attribute__((unknown_attr_xyz)) = n + 1;
    int c __attribute__((cold)) = n + 2;
    (void)a; (void)b; (void)c;
}
