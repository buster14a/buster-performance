extern int weak_data __attribute__((weak));
int f(void) { return &weak_data ? weak_data : 0; }
