int original_function(void);
#pragma redefine_extname original_function renamed_function
int original_function(void) { return 10; }
int f(void) { return original_function(); }
