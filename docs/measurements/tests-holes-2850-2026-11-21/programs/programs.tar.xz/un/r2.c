int old(int);
int old(int) __attribute__((deprecated));
int old(int);
int h(int x) { return old(x); }
