int g(int);
int f(int n) { int y; if (n) y = 1; return g(y); }
