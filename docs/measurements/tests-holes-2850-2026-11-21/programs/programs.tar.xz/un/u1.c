void g(void);
__attribute__((interrupt)) void h(void *p) { g(); }
