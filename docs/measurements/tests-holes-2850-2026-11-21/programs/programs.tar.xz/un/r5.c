void *al(unsigned long);
void *al(unsigned long) __attribute__((alloc_size(1)));
void *al(unsigned long);
int old(int);
int h(int x) { int old(int) __attribute__((deprecated)); return x; }
int k(int x) { return old(x); }
