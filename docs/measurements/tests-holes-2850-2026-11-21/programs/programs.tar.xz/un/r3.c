int must(int);
int must(int) __attribute__((warn_unused_result));
int must(int);
void h(int x) { must(x); }
