int f(int n) { int y; y++; return y; }
