int pf(const char *, ...);
int pf(const char *, ...) __attribute__((format(printf, 1, 2)));
int pf(const char *, ...);
void h(int x) { pf("%s", x); }
