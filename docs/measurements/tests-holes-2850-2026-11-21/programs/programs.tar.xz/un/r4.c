int g;
extern int g __attribute__((deprecated));
extern int g;
int h(void) { return g; }
