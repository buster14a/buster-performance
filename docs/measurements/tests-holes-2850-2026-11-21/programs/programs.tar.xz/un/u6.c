int *p;
void f(void) { (void)*p; }
int __attribute__((noderef)) *q;
