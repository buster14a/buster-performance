int f(void) { int y; return y + 1; }
