int f(void) { int x = x; return x; }
