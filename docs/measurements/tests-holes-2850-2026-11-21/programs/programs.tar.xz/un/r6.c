int snt(int, ...);
int snt(int, ...) __attribute__((sentinel));
int snt(int, ...);
void h(int x) { snt(x, 1); }
