void f8(int y) __attribute__((diagnose_if(y == 3, "decl", "warning")));
void h(void) { f8(3); }
