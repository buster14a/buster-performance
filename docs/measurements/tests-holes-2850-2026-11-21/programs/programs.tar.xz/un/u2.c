void g(void);
__attribute__((no_caller_saved_registers)) void h(void) { g(); }
