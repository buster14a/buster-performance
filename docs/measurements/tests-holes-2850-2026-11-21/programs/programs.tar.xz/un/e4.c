void f(int n) { int set; set = n; }
