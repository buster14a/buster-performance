typedef int __attribute__((noderef)) Scalar;
Scalar *p;
void f(void) { (void)*p; }
