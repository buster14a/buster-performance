static int missing(void) __attribute__((weakref("target")));
int f(void) { return missing(); }
