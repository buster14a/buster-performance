int kept_out(void) __attribute__((weak));
int kept_out(void) { return 1; }
int f(void) { return kept_out(); }
