void *memcpy(void *, const void *, unsigned long);
#pragma redefine_extname memcpy my_memcpy
int other asm("chosen") = 13;
void f(char *a, const char *b) { memcpy(a, b, 8); }
