#pragma redefine_extname original renamed
int original(void);
int f(void) { return original(); }
