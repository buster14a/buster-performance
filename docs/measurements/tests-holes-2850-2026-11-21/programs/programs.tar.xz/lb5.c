extern int weak_missing(void);
#pragma weak weak_missing
int f(void) { return weak_missing ? weak_missing() : -1; }
