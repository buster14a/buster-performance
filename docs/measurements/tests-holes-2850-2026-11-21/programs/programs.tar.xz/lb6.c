void *memcpy(void *, const void *, unsigned long);
#pragma redefine_extname memcpy my_memcpy
void f(char *a, const char *b) { memcpy(a, b, 8); }
