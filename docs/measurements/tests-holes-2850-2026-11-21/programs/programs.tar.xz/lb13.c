#pragma redefine_extname memcpy my_memcpy
void *memcpy(void *, const void *, unsigned long);
int other asm("chosen") = 13;
void f(char *a, const char *b) { memcpy(a, b, 8); }
