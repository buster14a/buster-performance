extern int weak_only(void) __attribute__((weak));
int f(void) { return weak_only(); }
