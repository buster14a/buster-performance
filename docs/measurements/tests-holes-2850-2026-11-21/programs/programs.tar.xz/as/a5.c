__seg_gs int count;
int f(void) { return count; }
