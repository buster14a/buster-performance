int f(int __attribute__((address_space(258))) *p) { return *p; }
