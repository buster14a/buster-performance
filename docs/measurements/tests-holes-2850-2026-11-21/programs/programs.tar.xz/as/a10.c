int f(long x) { return *(__seg_gs int *)x; }
