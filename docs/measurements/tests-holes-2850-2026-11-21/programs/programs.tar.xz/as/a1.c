int f(__seg_gs int *p) { return *p; }
