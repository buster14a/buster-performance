struct S { int a, b; };
void f(__seg_fs struct S *s, int v) { s->b = v; }
