void f(__seg_gs int *p) { *p += 2; }
