int f(int __attribute__((address_space(1))) *p) { return *p; }
