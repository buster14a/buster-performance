void f(__seg_fs int *p, int v) { *p = v; }
