int __attribute__((overloadable)) f(int);
int __attribute__((overloadable)) f(long);
int h(int);
int before(int a) { return h(a); }
int g(int a) { return f(a) + h(a); }
int after(int a) { return h(a); }
