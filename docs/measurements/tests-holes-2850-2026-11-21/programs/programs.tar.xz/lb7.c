void *memcpy(void *, const void *, unsigned long) asm("my_memcpy");
void f(char *a, const char *b) { memcpy(a, b, 8); }
