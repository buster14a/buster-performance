int g(void);
void f(void)
{
    int unused = g() + 1;
    int d asm("d1") = 2;
    (void)d;
}
