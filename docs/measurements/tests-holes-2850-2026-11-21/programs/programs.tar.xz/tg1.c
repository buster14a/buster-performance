__attribute__((target("avx2"))) static int kernel(int n) { return n * 3; }
int caller(int n) { return n; }
