__attribute__((target_clones("avx2", "default"))) int tc(int n) { return n * 3; }
int caller(int n) { int (*p)(int) = tc; return tc(n) + p(n); }
