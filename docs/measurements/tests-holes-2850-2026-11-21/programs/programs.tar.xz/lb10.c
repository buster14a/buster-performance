int original = 9;
#pragma redefine_extname original renamed
int f(void) { return original; }
