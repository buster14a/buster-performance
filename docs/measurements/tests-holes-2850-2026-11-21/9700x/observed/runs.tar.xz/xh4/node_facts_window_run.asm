
results/xh4/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f7d4d0 <node_facts_window_run>:
 1f7d4d0:	push   %rbp
 1f7d4d1:	push   %r15
 1f7d4d3:	push   %r14
 1f7d4d5:	push   %r13
 1f7d4d7:	push   %r12
 1f7d4d9:	push   %rbx
 1f7d4da:	sub    $0xd08,%rsp
 1f7d4e1:	mov    0x940(%rdi),%r14
 1f7d4e8:	mov    0x8(%rsi),%r15d
 1f7d4ec:	mov    %rsi,%r13
 1f7d4ef:	test   %r15,%r15
 1f7d4f2:	je     1f7d6b7 <node_facts_window_run+0x1e7>
 1f7d4f8:	mov    %r15d,%eax
 1f7d4fb:	and    $0x7,%eax
 1f7d4fe:	cmp    $0x8,%r15d
 1f7d502:	jae    1f7d50b <node_facts_window_run+0x3b>
 1f7d504:	xor    %ecx,%ecx
 1f7d506:	jmp    1f7dabf <node_facts_window_run+0x5ef>
 1f7d50b:	mov    %r15d,%edx
 1f7d50e:	and    $0xfffffff8,%edx
 1f7d511:	xor    %ecx,%ecx
 1f7d513:	jmp    1f7d53b <node_facts_window_run+0x6b>
 1f7d515:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7d520:	xor    %esi,%esi
 1f7d522:	mov    0x9c0(%rdi),%r8
 1f7d529:	mov    %sil,0x7(%r8,%rcx,1)
 1f7d52e:	add    $0x8,%rcx
 1f7d532:	cmp    %rcx,%rdx
 1f7d535:	je     1f7d6ae <node_facts_window_run+0x1de>
 1f7d53b:	mov    0x9b8(%rdi),%rsi
 1f7d542:	cmpb   $0x0,(%rsi,%rcx,1)
 1f7d546:	je     1f7d560 <node_facts_window_run+0x90>
 1f7d548:	movzbl 0x69454(%r13,%rcx,1),%esi
 1f7d551:	jmp    1f7d562 <node_facts_window_run+0x92>
 1f7d553:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7d560:	xor    %esi,%esi
 1f7d562:	mov    0x9c0(%rdi),%r8
 1f7d569:	mov    %sil,(%r8,%rcx,1)
 1f7d56d:	mov    0x9b8(%rdi),%rsi
 1f7d574:	cmpb   $0x0,0x1(%rsi,%rcx,1)
 1f7d579:	je     1f7d590 <node_facts_window_run+0xc0>
 1f7d57b:	movzbl 0x69455(%r13,%rcx,1),%esi
 1f7d584:	jmp    1f7d592 <node_facts_window_run+0xc2>
 1f7d586:	cs nopw 0x0(%rax,%rax,1)
 1f7d590:	xor    %esi,%esi
 1f7d592:	mov    0x9c0(%rdi),%r8
 1f7d599:	mov    %sil,0x1(%r8,%rcx,1)
 1f7d59e:	mov    0x9b8(%rdi),%rsi
 1f7d5a5:	cmpb   $0x0,0x2(%rsi,%rcx,1)
 1f7d5aa:	je     1f7d5c0 <node_facts_window_run+0xf0>
 1f7d5ac:	movzbl 0x69456(%r13,%rcx,1),%esi
 1f7d5b5:	jmp    1f7d5c2 <node_facts_window_run+0xf2>
 1f7d5b7:	nopw   0x0(%rax,%rax,1)
 1f7d5c0:	xor    %esi,%esi
 1f7d5c2:	mov    0x9c0(%rdi),%r8
 1f7d5c9:	mov    %sil,0x2(%r8,%rcx,1)
 1f7d5ce:	mov    0x9b8(%rdi),%rsi
 1f7d5d5:	cmpb   $0x0,0x3(%rsi,%rcx,1)
 1f7d5da:	je     1f7d5f0 <node_facts_window_run+0x120>
 1f7d5dc:	movzbl 0x69457(%r13,%rcx,1),%esi
 1f7d5e5:	jmp    1f7d5f2 <node_facts_window_run+0x122>
 1f7d5e7:	nopw   0x0(%rax,%rax,1)
 1f7d5f0:	xor    %esi,%esi
 1f7d5f2:	mov    0x9c0(%rdi),%r8
 1f7d5f9:	mov    %sil,0x3(%r8,%rcx,1)
 1f7d5fe:	mov    0x9b8(%rdi),%rsi
 1f7d605:	cmpb   $0x0,0x4(%rsi,%rcx,1)
 1f7d60a:	je     1f7d620 <node_facts_window_run+0x150>
 1f7d60c:	movzbl 0x69458(%r13,%rcx,1),%esi
 1f7d615:	jmp    1f7d622 <node_facts_window_run+0x152>
 1f7d617:	nopw   0x0(%rax,%rax,1)
 1f7d620:	xor    %esi,%esi
 1f7d622:	mov    0x9c0(%rdi),%r8
 1f7d629:	mov    %sil,0x4(%r8,%rcx,1)
 1f7d62e:	mov    0x9b8(%rdi),%rsi
 1f7d635:	cmpb   $0x0,0x5(%rsi,%rcx,1)
 1f7d63a:	je     1f7d650 <node_facts_window_run+0x180>
 1f7d63c:	movzbl 0x69459(%r13,%rcx,1),%esi
 1f7d645:	jmp    1f7d652 <node_facts_window_run+0x182>
 1f7d647:	nopw   0x0(%rax,%rax,1)
 1f7d650:	xor    %esi,%esi
 1f7d652:	mov    0x9c0(%rdi),%r8
 1f7d659:	mov    %sil,0x5(%r8,%rcx,1)
 1f7d65e:	mov    0x9b8(%rdi),%rsi
 1f7d665:	cmpb   $0x0,0x6(%rsi,%rcx,1)
 1f7d66a:	je     1f7d680 <node_facts_window_run+0x1b0>
 1f7d66c:	movzbl 0x6945a(%r13,%rcx,1),%esi
 1f7d675:	jmp    1f7d682 <node_facts_window_run+0x1b2>
 1f7d677:	nopw   0x0(%rax,%rax,1)
 1f7d680:	xor    %esi,%esi
 1f7d682:	mov    0x9c0(%rdi),%r8
 1f7d689:	mov    %sil,0x6(%r8,%rcx,1)
 1f7d68e:	mov    0x9b8(%rdi),%rsi
 1f7d695:	cmpb   $0x0,0x7(%rsi,%rcx,1)
 1f7d69a:	je     1f7d520 <node_facts_window_run+0x50>
 1f7d6a0:	movzbl 0x6945b(%r13,%rcx,1),%esi
 1f7d6a9:	jmp    1f7d522 <node_facts_window_run+0x52>
 1f7d6ae:	test   %rax,%rax
 1f7d6b1:	jne    1f7dabf <node_facts_window_run+0x5ef>
 1f7d6b7:	vpbroadcastq %r13,%ymm0
 1f7d6bd:	vpaddq -0x19bbea5(%rip),%ymm0,%ymm0        # 5c1820 <.LCPI3_0>
 1f7d6c5:	vmovups 0x1f0(%rdi),%zmm1
 1f7d6cf:	mov    0x9c0(%rdi),%rax
 1f7d6d6:	mov    0x9c8(%rdi),%rdx
 1f7d6dd:	mov    0x69250(%r13),%r8d
 1f7d6e4:	lea    0x2c(%r13),%r11
 1f7d6e8:	lea    0x6a4d4(%r13),%rcx
 1f7d6ef:	lea    0x79854(%r13),%rsi
 1f7d6f6:	lea    0x73754(%r13),%r9
 1f7d6fd:	mov    0x230(%rdi),%r10
 1f7d704:	vmovdqu 0x240(%rdi),%xmm3
 1f7d70c:	vmovq  0x258(%rdi),%xmm2
 1f7d714:	mov    %r11,0x1f0(%rdi)
 1f7d71b:	mov    %rax,0x1f8(%rdi)
 1f7d722:	mov    %rcx,0x200(%rdi)
 1f7d729:	mov    %rdx,0x208(%rdi)
 1f7d730:	mov    $0x1,%edx
 1f7d735:	vmovdqu %ymm0,0x210(%rdi)
 1f7d73d:	mov    %rsi,0x230(%rdi)
 1f7d744:	mov    %r9,0x240(%rdi)
 1f7d74b:	mov    %r8d,0x258(%rdi)
 1f7d752:	vmovups %zmm1,0x8b0(%rsp)
 1f7d75d:	mov    %r10,0x6b8(%rsp)
 1f7d765:	vmovdqa %xmm3,0x880(%rsp)
 1f7d76e:	vmovdqa %xmm2,0x870(%rsp)
 1f7d777:	mov    %r11,0xd0(%rsp)
 1f7d77f:	xor    %esi,%esi
 1f7d781:	mov    %rdi,0x8(%rsp)
 1f7d786:	vmovups 0x9d0(%rdi),%zmm0
 1f7d790:	vmovups 0x268(%rdi),%zmm1
 1f7d79a:	vmovups %zmm0,0x268(%rdi)
 1f7d7a4:	vmovups %zmm1,0x9d0(%rdi)
 1f7d7ae:	vmovdqu 0xa10(%rdi),%xmm0
 1f7d7b6:	vmovdqu 0x2a8(%rdi),%xmm1
 1f7d7be:	vmovdqu %xmm0,0x2a8(%rdi)
 1f7d7c6:	vmovdqu %xmm1,0xa10(%rdi)
 1f7d7ce:	mov    0xa20(%rdi),%rcx
 1f7d7d5:	mov    0x2b8(%rdi),%rax
 1f7d7dc:	mov    %rcx,0x2b8(%rdi)
 1f7d7e3:	lea    0xa28(%rdi),%rcx
 1f7d7ea:	mov    %rax,0xa20(%rdi)
 1f7d7f1:	movl   $0x0,0xa28(%rdi)
 1f7d7fb:	mov    %r15d,0xa2c(%rdi)
 1f7d802:	mov    %rcx,0x248(%rdi)
 1f7d809:	movl   $0x0,0x25c(%rdi)
 1f7d813:	vzeroupper
 1f7d816:	call   1f7bbe0 <node_facts_given>
 1f7d81b:	mov    0x8(%rsp),%rax
 1f7d820:	mov    0x8(%rsp),%rdi
 1f7d825:	xor    %esi,%esi
 1f7d827:	xor    %edx,%edx
 1f7d829:	xor    %ecx,%ecx
 1f7d82b:	mov    0xe0(%rax),%rbx
 1f7d832:	call   1f7be00 <node_facts_window>
 1f7d837:	mov    0x8(%rsp),%rax
 1f7d83c:	mov    0x8(%rsp),%rdi
 1f7d841:	xor    %esi,%esi
 1f7d843:	mov    0xe0(%rax),%rax
 1f7d84a:	sub    %rbx,%rax
 1f7d84d:	add    %rax,0xa30(%r14)
 1f7d854:	call   1f7ca50 <node_facts_lists_same>
 1f7d859:	mov    0x8(%rsp),%rdi
 1f7d85e:	test   %al,%al
 1f7d860:	jne    1f7d8b5 <node_facts_window_run+0x3e5>
 1f7d862:	incq   0xa00(%r14)
 1f7d869:	mov    0x940(%rdi),%rax
 1f7d870:	mov    0x11e0(%rax),%ecx
 1f7d876:	cmp    $0xf,%rcx
 1f7d87a:	ja     1f7d8b5 <node_facts_window_run+0x3e5>
 1f7d87c:	mov    0x422c(%r13),%edx
 1f7d883:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7d88a:	mov    0x1f0(%rdi),%rcx
 1f7d891:	mov    0x11e0(%rax),%edx
 1f7d897:	movzbl (%rcx),%ecx
 1f7d89a:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7d8a1:	mov    0x11e0(%rax),%ecx
 1f7d8a7:	movb   $0x2,0x11d0(%rax,%rcx,1)
 1f7d8af:	incl   0x11e0(%rax)
 1f7d8b5:	mov    %r15,0xc8(%rsp)
 1f7d8bd:	mov    %r13,0x28(%rsp)
 1f7d8c2:	test   %r15d,%r15d
 1f7d8c5:	je     1f7db97 <node_facts_window_run+0x6c7>
 1f7d8cb:	mov    $0x1a,%r15d
 1f7d8d1:	mov    $0xcc,%ebp
 1f7d8d6:	mov    $0x102,%r12d
 1f7d8dc:	mov    $0x8c,%r13d
 1f7d8e2:	xor    %ebx,%ebx
 1f7d8e4:	jmp    1f7d905 <node_facts_window_run+0x435>
 1f7d8e6:	cs nopw 0x0(%rax,%rax,1)
 1f7d8f0:	inc    %rbx
 1f7d8f3:	add    $0x40,%r15
 1f7d8f7:	cmp    %rbx,0xc8(%rsp)
 1f7d8ff:	je     1f7dad0 <node_facts_window_run+0x600>
 1f7d905:	mov    0x1f8(%rdi),%rax
 1f7d90c:	movzbl (%rax,%rbx,1),%eax
 1f7d910:	cmp    $0x7,%eax
 1f7d913:	ja     1f7d8f0 <node_facts_window_run+0x420>
 1f7d915:	bt     %eax,%ebp
 1f7d918:	jae    1f7d8f0 <node_facts_window_run+0x420>
 1f7d91a:	mov    %eax,%ecx
 1f7d91c:	mov    0x2c0(%rdi),%rsi
 1f7d923:	and    $0xfe,%cl
 1f7d926:	cmp    $0x2,%cl
 1f7d929:	sete   %cl
 1f7d92c:	cmp    $0x7,%eax
 1f7d92f:	sete   %dl
 1f7d932:	or     %cl,%dl
 1f7d934:	movzbl -0x1(%rsi,%r15,1),%ecx
 1f7d93a:	movzbl %dl,%edx
 1f7d93d:	add    %rdx,0x9f0(%r14)
 1f7d944:	cmp    $0x7,%eax
 1f7d947:	ja     1f7da83 <node_facts_window_run+0x5b3>
 1f7d94d:	bt     %eax,%r13d
 1f7d951:	mov    $0x0,%edx
 1f7d956:	jae    1f7d964 <node_facts_window_run+0x494>
 1f7d958:	lea    -0x1(%rcx),%esi
 1f7d95b:	xor    %edx,%edx
 1f7d95d:	cmp    $0x2,%sil
 1f7d961:	setb   %dl
 1f7d964:	add    %rdx,0x9f8(%r14)
 1f7d96b:	xor    %edx,%edx
 1f7d96d:	cmp    $0x7,%eax
 1f7d970:	ja     1f7d986 <node_facts_window_run+0x4b6>
 1f7d972:	bt     %eax,%r13d
 1f7d976:	jae    1f7d986 <node_facts_window_run+0x4b6>
 1f7d978:	mov    0x1f0(%rdi),%rax
 1f7d97f:	cmpb   $0x22,(%rax,%rbx,1)
 1f7d983:	sete   %dl
 1f7d986:	dec    %cl
 1f7d988:	vmovd  %edx,%xmm0
 1f7d98c:	cmp    $0x2,%cl
 1f7d98f:	setb   %al
 1f7d992:	and    %dl,%al
 1f7d994:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f7d99a:	vpmovzxbq %xmm0,%xmm0
 1f7d99f:	vptestmq -0x19af4a1(%rip){1to2},%xmm0,%k0        # 5ce508 <.LCPI3_1>
 1f7d9a9:	vmovdqu 0xa10(%r14),%xmm0
 1f7d9b2:	vpmovm2q %k0,%xmm1
 1f7d9b8:	vpsubq %xmm1,%xmm0,%xmm0
 1f7d9bc:	vmovdqu %xmm0,0xa10(%r14)
 1f7d9c5:	cmp    $0x1,%al
 1f7d9c7:	jne    1f7da00 <node_facts_window_run+0x530>
 1f7d9c9:	mov    0x2c0(%rdi),%rax
 1f7d9d0:	movzwl (%rax,%r15,1),%eax
 1f7d9d5:	bt     $0x1,%eax
 1f7d9d9:	adcq   $0x0,0xa20(%r14)
 1f7d9e1:	mov    0x2c0(%rdi),%rax
 1f7d9e8:	movzwl (%rax,%r15,1),%eax
 1f7d9ed:	bextr  %r12d,%eax,%eax
 1f7d9f2:	jmp    1f7da02 <node_facts_window_run+0x532>
 1f7d9f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7da00:	xor    %eax,%eax
 1f7da02:	add    %rax,0xa28(%r14)
 1f7da09:	xor    %esi,%esi
 1f7da0b:	mov    %ebx,%edx
 1f7da0d:	xor    %ecx,%ecx
 1f7da0f:	call   1f7d070 <node_facts_same>
 1f7da14:	mov    0x8(%rsp),%rdi
 1f7da19:	test   %al,%al
 1f7da1b:	jne    1f7d8f0 <node_facts_window_run+0x420>
 1f7da21:	incq   0xa00(%r14)
 1f7da28:	mov    0x940(%rdi),%rax
 1f7da2f:	mov    0x11e0(%rax),%ecx
 1f7da35:	cmp    $0xf,%rcx
 1f7da39:	ja     1f7d8f0 <node_facts_window_run+0x420>
 1f7da3f:	mov    0x28(%rsp),%rdx
 1f7da44:	mov    0x422c(%rdx,%rbx,4),%edx
 1f7da4b:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7da52:	mov    0x1f0(%rdi),%rcx
 1f7da59:	mov    0x11e0(%rax),%edx
 1f7da5f:	movzbl (%rcx,%rbx,1),%ecx
 1f7da63:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7da6a:	mov    0x11e0(%rax),%ecx
 1f7da70:	movb   $0x5,0x11d0(%rax,%rcx,1)
 1f7da78:	incl   0x11e0(%rax)
 1f7da7e:	jmp    1f7d8f0 <node_facts_window_run+0x420>
 1f7da83:	xor    %edx,%edx
 1f7da85:	add    %rdx,0x9f8(%r14)
 1f7da8c:	xor    %edx,%edx
 1f7da8e:	cmp    $0x7,%eax
 1f7da91:	jbe    1f7d972 <node_facts_window_run+0x4a2>
 1f7da97:	jmp    1f7d986 <node_facts_window_run+0x4b6>
 1f7da9c:	nopl   0x0(%rax)
 1f7daa0:	movzbl 0x69454(%r13,%rcx,1),%edx
 1f7daa9:	mov    0x9c0(%rdi),%rsi
 1f7dab0:	mov    %dl,(%rsi,%rcx,1)
 1f7dab3:	inc    %rcx
 1f7dab6:	dec    %rax
 1f7dab9:	je     1f7d6b7 <node_facts_window_run+0x1e7>
 1f7dabf:	mov    0x9b8(%rdi),%rdx
 1f7dac6:	cmpb   $0x0,(%rdx,%rcx,1)
 1f7daca:	jne    1f7daa0 <node_facts_window_run+0x5d0>
 1f7dacc:	xor    %edx,%edx
 1f7dace:	jmp    1f7daa9 <node_facts_window_run+0x5d9>
 1f7dad0:	mov    $0x3,%edx
 1f7dad5:	xor    %esi,%esi
 1f7dad7:	xor    %ebx,%ebx
 1f7dad9:	call   1f7bbe0 <node_facts_given>
 1f7dade:	mov    0x8(%rsp),%rdi
 1f7dae3:	xor    %esi,%esi
 1f7dae5:	xor    %edx,%edx
 1f7dae7:	xor    %ecx,%ecx
 1f7dae9:	call   1f7be00 <node_facts_window>
 1f7daee:	mov    0x8(%rsp),%rdi
 1f7daf3:	mov    0xc8(%rsp),%r15
 1f7dafb:	mov    0x28(%rsp),%r13
 1f7db00:	jmp    1f7db1c <node_facts_window_run+0x64c>
 1f7db02:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7db10:	inc    %rbx
 1f7db13:	cmp    %rbx,%r15
 1f7db16:	je     1f7dbb8 <node_facts_window_run+0x6e8>
 1f7db1c:	mov    0x1f8(%rdi),%rax
 1f7db23:	testb  $0x2,(%rax,%rbx,1)
 1f7db27:	je     1f7db10 <node_facts_window_run+0x640>
 1f7db29:	xor    %esi,%esi
 1f7db2b:	mov    %ebx,%edx
 1f7db2d:	xor    %ecx,%ecx
 1f7db2f:	call   1f7d070 <node_facts_same>
 1f7db34:	mov    0x8(%rsp),%rdi
 1f7db39:	test   %al,%al
 1f7db3b:	jne    1f7db10 <node_facts_window_run+0x640>
 1f7db3d:	incq   0xa00(%r14)
 1f7db44:	mov    0x940(%rdi),%rax
 1f7db4b:	mov    0x11e0(%rax),%ecx
 1f7db51:	cmp    $0xf,%rcx
 1f7db55:	ja     1f7db10 <node_facts_window_run+0x640>
 1f7db57:	mov    0x422c(%r13,%rbx,4),%edx
 1f7db5f:	mov    %edx,0x1180(%rax,%rcx,4)
 1f7db66:	mov    0x1f0(%rdi),%rcx
 1f7db6d:	mov    0x11e0(%rax),%edx
 1f7db73:	movzbl (%rcx,%rbx,1),%ecx
 1f7db77:	mov    %cl,0x11c0(%rax,%rdx,1)
 1f7db7e:	mov    0x11e0(%rax),%ecx
 1f7db84:	movb   $0x1,0x11d0(%rax,%rcx,1)
 1f7db8c:	incl   0x11e0(%rax)
 1f7db92:	jmp    1f7db10 <node_facts_window_run+0x640>
 1f7db97:	mov    $0x3,%edx
 1f7db9c:	xor    %esi,%esi
 1f7db9e:	call   1f7bbe0 <node_facts_given>
 1f7dba3:	mov    0x8(%rsp),%rdi
 1f7dba8:	xor    %esi,%esi
 1f7dbaa:	xor    %edx,%edx
 1f7dbac:	xor    %ecx,%ecx
 1f7dbae:	call   1f7be00 <node_facts_window>
 1f7dbb3:	mov    0x8(%rsp),%rdi
 1f7dbb8:	xor    %esi,%esi
 1f7dbba:	xor    %edx,%edx
 1f7dbbc:	call   1f7bbe0 <node_facts_given>
 1f7dbc1:	mov    0x8(%rsp),%rax
 1f7dbc6:	xor    %esi,%esi
 1f7dbc8:	xor    %ecx,%ecx
 1f7dbca:	mov    0xd0(%rax),%r15
 1f7dbd1:	rdtsc
 1f7dbd3:	mov    0x8(%rsp),%rdi
 1f7dbd8:	mov    %rdx,%rbx
 1f7dbdb:	shl    $0x20,%rbx
 1f7dbdf:	xor    %edx,%edx
 1f7dbe1:	or     %rax,%rbx
 1f7dbe4:	call   1f7be00 <node_facts_window>
 1f7dbe9:	mov    0x8(%rsp),%r11
 1f7dbee:	rdtsc
 1f7dbf0:	shl    $0x20,%rdx
 1f7dbf4:	or     %rax,%rdx
 1f7dbf7:	sub    %rbx,%rdx
 1f7dbfa:	add    %rdx,0xa08(%r14)
 1f7dc01:	mov    0xd0(%r11),%rax
 1f7dc08:	sub    %r15,%rax
 1f7dc0b:	mov    0xc8(%rsp),%r15
 1f7dc13:	add    %rax,0xa38(%r14)
 1f7dc1a:	mov    0x950(%r11),%rdi
 1f7dc21:	test   %rdi,%rdi
 1f7dc24:	je     1f84e50 <node_facts_window_run+0x7980>
 1f7dc2a:	mov    0xc68(%rdi),%rax
 1f7dc31:	mov    0xbd0(%rdi),%rsi
 1f7dc38:	lea    0x757d4(%r13),%r12
 1f7dc3f:	mov    %rax,0x68(%rsp)
 1f7dc44:	mov    (%r11),%rax
 1f7dc47:	mov    %rax,0x80(%rsp)
 1f7dc4f:	mov    0x948(%r11),%rax
 1f7dc56:	mov    %rax,0xc0(%rsp)
 1f7dc5e:	mov    0x8(%rax),%rax
 1f7dc62:	mov    0x78(%rax),%eax
 1f7dc65:	mov    %eax,0xb8(%rsp)
 1f7dc6c:	movzbl 0xc90(%rdi),%eax
 1f7dc73:	mov    %al,0x88(%rsp)
 1f7dc7a:	rdtsc
 1f7dc7c:	mov    0x8(%r13),%r8d
 1f7dc80:	mov    0x2c0(%r11),%r9
 1f7dc87:	mov    %rax,0xf0(%rsp)
 1f7dc8f:	lea    0x3f(%r8),%eax
 1f7dc93:	mov    %rdx,0xe8(%rsp)
 1f7dc9b:	mov    %rsi,0x38(%rsp)
 1f7dca0:	mov    %rdi,0x18(%rsp)
 1f7dca5:	mov    %r12,0x30(%rsp)
 1f7dcaa:	mov    %r8,0x150(%rsp)
 1f7dcb2:	mov    %r9,0x20(%rsp)
 1f7dcb7:	and    $0xffffffc0,%eax
 1f7dcba:	cmpq   $0x0,0xc20(%r11)
 1f7dcc2:	je     1f7e998 <node_facts_window_run+0x14c8>
 1f7dcc8:	cmpb   $0x1,0xd58(%r11)
 1f7dcd0:	jne    1f7f3f2 <node_facts_window_run+0x1f22>
 1f7dcd6:	test   %eax,%eax
 1f7dcd8:	je     1f808f7 <node_facts_window_run+0x3427>
 1f7dcde:	vpbroadcastd -0x19acdb4(%rip),%zmm14        # 5d0f34 <.LCPI3_5>
 1f7dce8:	vpbroadcastb -0x1ac6fb1(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7dcf1:	vpbroadcastb -0x1ac6fba(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7dcfb:	vpbroadcastd -0x19acdc9(%rip),%zmm17        # 5d0f3c <.LCPI3_11>
 1f7dd05:	vpbroadcastd -0x19acdcb(%rip),%zmm18        # 5d0f44 <.LCPI3_13>
 1f7dd0f:	mov    (%r11),%rcx
 1f7dd12:	lea    0x69454(%r13),%r10
 1f7dd19:	lea    0x422c(%r13),%rdx
 1f7dd20:	mov    %eax,%r15d
 1f7dd23:	xor    %ebx,%ebx
 1f7dd25:	mov    %rcx,0x90(%rsp)
 1f7dd2d:	mov    %r10,0xb0(%rsp)
 1f7dd35:	mov    %rdx,0x98(%rsp)
 1f7dd3d:	movq   $0x0,0x40(%rsp)
 1f7dd46:	movq   $0x0,0x110(%rsp)
 1f7dd52:	movq   $0x0,0x10(%rsp)
 1f7dd5b:	mov    %r15,0xa8(%rsp)
 1f7dd63:	jmp    1f7de36 <node_facts_window_run+0x966>
 1f7dd68:	nopl   0x0(%rax,%rax,1)
 1f7dd70:	vpxor  %xmm1,%xmm1,%xmm1
 1f7dd74:	vpxor  %xmm0,%xmm0,%xmm0
 1f7dd78:	vpxor  %xmm5,%xmm5,%xmm5
 1f7dd7c:	vpxor  %xmm4,%xmm4,%xmm4
 1f7dd80:	vpxor  %xmm3,%xmm3,%xmm3
 1f7dd84:	vpxor  %xmm7,%xmm7,%xmm7
 1f7dd88:	vpxor  %xmm8,%xmm8,%xmm8
 1f7dd8d:	vpxor  %xmm9,%xmm9,%xmm9
 1f7dd92:	vpxor  %xmm2,%xmm2,%xmm2
 1f7dd96:	vpxord %xmm20,%xmm20,%xmm20
 1f7dd9c:	mov    0xc10(%rdi),%rax
 1f7dda3:	vmovdqu64 %xmm20,(%rax,%rbx,1)
 1f7ddaa:	mov    0xc18(%rdi),%rax
 1f7ddb1:	vmovdqu %xmm2,(%rax,%rbx,1)
 1f7ddb6:	mov    0xb88(%r11),%rax
 1f7ddbd:	vmovdqu %xmm9,(%rax,%rbx,1)
 1f7ddc2:	mov    0xb90(%r11),%rax
 1f7ddc9:	vmovdqu %xmm8,(%rax,%rbx,1)
 1f7ddce:	mov    0xb98(%r11),%rax
 1f7ddd5:	vmovdqu %xmm7,(%rax,%rbx,1)
 1f7ddda:	mov    0xba0(%r11),%rax
 1f7dde1:	vmovdqu %xmm3,(%rax,%rbx,1)
 1f7dde6:	mov    0xba8(%r11),%rax
 1f7dded:	vmovdqu %xmm4,(%rax,%rbx,1)
 1f7ddf2:	mov    0xc28(%r11),%rax
 1f7ddf9:	vmovdqu64 %zmm5,(%rax,%rbx,4)
 1f7de00:	mov    0xcd8(%r11),%rax
 1f7de07:	vmovdqu64 %zmm0,(%rax,%rbx,8)
 1f7de0e:	mov    0xcd8(%r11),%rax
 1f7de15:	vmovdqu64 %zmm1,0x40(%rax,%rbx,8)
 1f7de1d:	mov    0xd60(%r11),%rax
 1f7de24:	vmovdqu %xmm6,(%rax,%rbx,1)
 1f7de29:	add    $0x10,%rbx
 1f7de2d:	cmp    %r15,%rbx
 1f7de30:	jae    1f80915 <node_facts_window_run+0x3445>
 1f7de36:	vpxor  %xmm6,%xmm6,%xmm6
 1f7de3a:	cmp    %r8,%rbx
 1f7de3d:	jae    1f7dd70 <node_facts_window_run+0x8a0>
 1f7de43:	mov    %r8d,%eax
 1f7de46:	sub    %ebx,%eax
 1f7de48:	mov    $0x10,%ecx
 1f7de4d:	mov    $0xffffffff,%edx
 1f7de52:	mov    %rbx,%rbp
 1f7de55:	vpxor  %xmm12,%xmm12,%xmm12
 1f7de5a:	cmp    $0x10,%eax
 1f7de5d:	cmovae %ecx,%eax
 1f7de60:	mov    0x9b8(%r11),%rcx
 1f7de67:	shl    $0x6,%rbp
 1f7de6b:	shlx   %eax,%edx,%eax
 1f7de70:	vmovdqu (%r9,%rbp,1),%ymm4
 1f7de76:	vmovdqu64 0x40(%r9,%rbp,1),%ymm26
 1f7de7e:	vmovdqu64 0x80(%r9,%rbp,1),%ymm27
 1f7de86:	vmovdqu64 0xc0(%r9,%rbp,1),%ymm28
 1f7de8e:	vmovdqu 0x100(%r9,%rbp,1),%ymm5
 1f7de98:	vmovdqu 0x140(%r9,%rbp,1),%ymm6
 1f7dea2:	vmovdqu64 0x180(%r9,%rbp,1),%ymm24
 1f7deaa:	vmovdqu64 0x1c0(%r9,%rbp,1),%ymm25
 1f7deb2:	vmovdqu 0x200(%r9,%rbp,1),%ymm7
 1f7debc:	vmovdqu 0x240(%r9,%rbp,1),%ymm13
 1f7dec6:	vmovdqu64 0x280(%r9,%rbp,1),%ymm22
 1f7dece:	vmovdqu64 0x2c0(%r9,%rbp,1),%ymm23
 1f7ded6:	vmovdqu 0x300(%r9,%rbp,1),%ymm11
 1f7dee0:	vmovdqu64 0x340(%r9,%rbp,1),%ymm19
 1f7dee8:	vmovdqu64 0x380(%r9,%rbp,1),%ymm20
 1f7def0:	vmovdqu64 0x3c0(%r9,%rbp,1),%ymm21
 1f7def8:	not    %eax
 1f7defa:	kmovd  %eax,%k1
 1f7defe:	mov    0xc48(%rdi),%rax
 1f7df05:	vmovdqu8 (%rcx,%rbx,1),%xmm0{%k1}{z}
 1f7df0c:	mov    0xb0(%rsp),%rcx
 1f7df14:	vmovdqu8 (%rcx,%rbx,1),%xmm10{%k1}{z}
 1f7df1b:	vptestmb %xmm0,%xmm0,%k6
 1f7df21:	vpcmpeqb -0x19b621b(%rip),%xmm10,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7df2b:	vmovdqu32 (%r12,%rbx,4),%zmm0{%k7}{z}
 1f7df32:	kmovq  %k7,%k1
 1f7df37:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7df3e:	vptestnmd %zmm17,%zmm12,%k0
 1f7df44:	ktestw %k0,%k7
 1f7df48:	jne    1f7e688 <node_facts_window_run+0x11b8>
 1f7df4e:	vpmovsxbd -0x19acfdf(%rip),%xmm3        # 5d0f78 <.LCPI3_74>
 1f7df57:	vmovdqa64 -0x1ac7821(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7df61:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7df68:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7df6f:	vptestmd -0x19ad039(%rip){1to16},%zmm12,%k0        # 5d0f40 <.LCPI3_12>
 1f7df79:	vmovdqa64 %zmm0,%zmm2
 1f7df7f:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7df85:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7df8b:	vmovdqa64 %zmm3,%zmm9
 1f7df91:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7df97:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7df9d:	kmovd  %k0,%r13d
 1f7dfa1:	vptestmd %zmm18,%zmm12,%k0
 1f7dfa7:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7dfad:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7dfb4:	vmovdqu64 %zmm1,0x230(%rsp)
 1f7dfbf:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7dfc6:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7dfca:	vmovdqa64 %zmm1,%zmm4
 1f7dfd0:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7dfd6:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7dfdc:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7dfe2:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7dfe8:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7dfef:	vmovdqu %ymm3,0x1f0(%rsp)
 1f7dff8:	vinserti64x4 $0x1,%ymm13,%zmm7,%zmm3
 1f7dfff:	vpunpcklqdq %ymm13,%ymm7,%ymm7
 1f7e004:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm13
 1f7e00b:	vmovdqa64 %zmm3,%zmm6
 1f7e011:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7e017:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7e01d:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7e023:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7e029:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7e02f:	vmovdqa64 %zmm13,%zmm7
 1f7e035:	vmovdqu64 %zmm5,0x270(%rsp)
 1f7e040:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7e047:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7e04d:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7e054:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7e05b:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7e061:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7e068:	vpermt2d %zmm5,%zmm9,%zmm13
 1f7e06e:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7e074:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7e07a:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7e081:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7e088:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7e08f:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7e096:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm21{%k6}{z}
 1f7e09d:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7e0a4:	vpsrld $0x19,%zmm19,%zmm0
 1f7e0ab:	vpandd -0x19ad185(%rip){1to16},%zmm0,%zmm0        # 5d0f30 <.LCPI3_4>
 1f7e0b5:	vpsrld $0x18,%zmm19,%zmm1
 1f7e0bc:	vpsrld $0x1a,%zmm19,%zmm7
 1f7e0c3:	vpternlogd $0xec,%zmm14,%zmm0,%zmm1
 1f7e0ca:	vpandd -0x19ad158(%rip){1to16},%zmm19,%zmm0        # 5d0f7c <.LCPI3_75>
 1f7e0d4:	vpmovdb %zmm1,%xmm20
 1f7e0da:	vpsrld $0xc,%zmm21,%zmm1
 1f7e0e1:	vpmovdb %zmm1,%xmm24
 1f7e0e7:	vpcmpeqd -0x19ad1b9(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f38 <.LCPI3_7>
 1f7e0f1:	vporq  %xmm15,%xmm20,%xmm0
 1f7e0f7:	vmovdqu8 %xmm0,%xmm20{%k1}
 1f7e0fd:	vpcmpeqb %xmm15,%xmm10,%k1{%k6}
 1f7e103:	vpternlogq $0xf8,%xmm16,%xmm24,%xmm20
 1f7e10a:	kmovd  %k1,%eax
 1f7e10e:	kmovw  %k1,0x50(%rsp)
 1f7e114:	korw   %k0,%k1,%k1
 1f7e118:	kmovw  %k1,0x1b0(%rsp)
 1f7e121:	test   %ax,%ax
 1f7e124:	je     1f7e2e2 <node_facts_window_run+0xe12>
 1f7e12a:	vmovdqu64 %zmm4,0x6c0(%rsp)
 1f7e132:	vmovdqu %ymm5,0x5d0(%rsp)
 1f7e13b:	vmovdqu64 %zmm7,0x4b0(%rsp)
 1f7e146:	vmovdqa64 %xmm24,0x610(%rsp)
 1f7e14e:	vmovdqu64 %zmm23,0x650(%rsp)
 1f7e159:	vmovdqu64 %zmm22,0x570(%rsp)
 1f7e164:	vmovdqu64 %zmm19,0x3f0(%rsp)
 1f7e16f:	vmovdqu64 %zmm13,0x4f0(%rsp)
 1f7e17a:	vmovdqu64 %zmm21,0x430(%rsp)
 1f7e185:	vmovdqu64 %zmm12,0x530(%rsp)
 1f7e190:	vmovdqa64 %xmm20,0x2b0(%rsp)
 1f7e198:	kmovw  %k7,0x3b0(%rsp)
 1f7e1a1:	mov    %rbp,0x370(%rsp)
 1f7e1a9:	kmovd  %k6,0x2f0(%rsp)
 1f7e1b3:	movzwl %ax,%r14d
 1f7e1b7:	movzwl %r13w,%r13d
 1f7e1bb:	xor    %ebp,%ebp
 1f7e1bd:	mov    0x98(%rsp),%rax
 1f7e1c5:	lea    (%rax,%rbx,4),%r15
 1f7e1c9:	nopl   0x0(%rax)
 1f7e1d0:	xor    %r12d,%r12d
 1f7e1d3:	tzcnt  %r14d,%r12d
 1f7e1d8:	xor    %edx,%edx
 1f7e1da:	mov    (%r15,%r12,4),%esi
 1f7e1de:	vzeroupper
 1f7e1e1:	call   1f93a70 <node_tests_window_line>
 1f7e1e6:	mov    0x18(%rsp),%rdi
 1f7e1eb:	mov    $0x1,%ecx
 1f7e1f0:	test   $0x2,%al
 1f7e1f2:	shlx   %r12d,%ecx,%eax
 1f7e1f7:	cmove  %ebp,%eax
 1f7e1fa:	or     %eax,%r13d
 1f7e1fd:	blsr   %r14d,%r14d
 1f7e202:	jne    1f7e1d0 <node_facts_window_run+0xd00>
 1f7e204:	vpbroadcastd -0x19ad2da(%rip),%zmm14        # 5d0f34 <.LCPI3_5>
 1f7e20e:	vpbroadcastb -0x1ac74d7(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e217:	vpbroadcastb -0x1ac74e0(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e221:	vpbroadcastd -0x19ad2ef(%rip),%zmm17        # 5d0f3c <.LCPI3_11>
 1f7e22b:	vpbroadcastd -0x19ad2f1(%rip),%zmm18        # 5d0f44 <.LCPI3_13>
 1f7e235:	vmovdqa64 0x2b0(%rsp),%xmm20
 1f7e23d:	vmovdqu64 0x530(%rsp),%zmm12
 1f7e248:	vmovdqu64 0x430(%rsp),%zmm21
 1f7e253:	vmovdqu64 0x4f0(%rsp),%zmm13
 1f7e25e:	vmovdqu64 0x3f0(%rsp),%zmm19
 1f7e269:	vmovdqu64 0x570(%rsp),%zmm22
 1f7e274:	vmovdqu64 0x650(%rsp),%zmm23
 1f7e27f:	vmovdqa64 0x610(%rsp),%xmm24
 1f7e287:	vmovdqu64 0x4b0(%rsp),%zmm7
 1f7e292:	vmovdqu 0x5d0(%rsp),%ymm5
 1f7e29b:	vmovdqu64 0x6c0(%rsp),%zmm4
 1f7e2a3:	mov    0x8(%rsp),%r11
 1f7e2a8:	mov    0x38(%rsp),%rsi
 1f7e2ad:	mov    0x30(%rsp),%r12
 1f7e2b2:	mov    0x150(%rsp),%r8
 1f7e2ba:	mov    0x20(%rsp),%r9
 1f7e2bf:	mov    0xa8(%rsp),%r15
 1f7e2c7:	kmovd  0x2f0(%rsp),%k6
 1f7e2d1:	mov    0x370(%rsp),%rbp
 1f7e2d9:	kmovw  0x3b0(%rsp),%k7
 1f7e2e2:	vpsrld $0x2,%zmm21,%zmm0
 1f7e2e9:	vpandd -0x19ad3ab(%rip){1to16},%zmm0,%zmm2        # 5d0f48 <.LCPI3_14>
 1f7e2f3:	vpbroadcastd -0x19ad3b1(%rip),%zmm0        # 5d0f4c <.LCPI3_15>
 1f7e2fd:	vptestmd -0x19ad3b7(%rip){1to16},%zmm21,%k3        # 5d0f50 <.LCPI3_16>
 1f7e307:	vmovdqu64 0x270(%rsp),%zmm1
 1f7e312:	vptestnmd %zmm4,%zmm4,%k1
 1f7e318:	vpbroadcastd -0x19ad3c6(%rip),%zmm6        # 5d0f5c <.LCPI3_21>
 1f7e322:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7e329:	kmovd  %r13d,%k4
 1f7e32e:	vpsrld $0x10,%zmm21,%zmm10
 1f7e335:	vpbroadcastb -0x1ac75fc(%rip),%xmm8        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7e33e:	vpbroadcastb -0x1ac7604(%rip),%xmm9        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7e347:	kmovw  %k1,%eax
 1f7e34b:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7e351:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7e358:	vmovdqu64 0x230(%rsp),%zmm0
 1f7e363:	korw   %k1,%k3,%k3
 1f7e367:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7e36e:	vpandd -0x19ad3f8(%rip){1to16},%zmm19,%zmm5        # 5d0f80 <.LCPI3_78>
 1f7e378:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7e37e:	vpbroadcastb -0x1ac7643(%rip),%xmm7        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7e387:	vinserti64x4 $0x1,0x1f0(%rsp),%zmm0,%zmm0
 1f7e393:	kmovw  %k0,%ecx
 1f7e397:	korw   %k2,%k3,%k2
 1f7e39b:	vpaddd -0x19ad44d(%rip){1to16},%zmm5,%zmm5        # 5d0f58 <.LCPI3_20>
 1f7e3a5:	andn   %ecx,%eax,%eax
 1f7e3aa:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7e3b0:	kmovd  %eax,%k3
 1f7e3b4:	shr    $0x8,%eax
 1f7e3b7:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7e3bd:	kmovd  %eax,%k3
 1f7e3c1:	vmovdqu8 %xmm15,%xmm4{%k2}{z}
 1f7e3c7:	vpcmpltud %zmm6,%zmm5,%k2
 1f7e3ce:	vpslld $0x1f,%zmm5,%zmm5
 1f7e3d5:	vpxor  %xmm6,%xmm6,%xmm6
 1f7e3d9:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7e3df:	vptestmd -0x19ad495(%rip){1to16},%zmm23,%k3        # 5d0f54 <.LCPI3_17>
 1f7e3e9:	vpandd %zmm18,%zmm23,%zmm3
 1f7e3ef:	vptestnmd %zmm3,%zmm3,%k0
 1f7e3f5:	kandd  %k6,%k0,%k0
 1f7e3fa:	korw   %k3,%k4,%k3
 1f7e3fe:	kandd  %k2,%k0,%k4
 1f7e403:	vpcmpeqd %zmm17,%zmm2,%k2{%k4}
 1f7e409:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7e40f:	vmovdqu8 -0x19b66d9(%rip),%xmm2{%k4}        # 5c7d40 <.LCPI3_25>
 1f7e419:	knotw  %k2,%k0
 1f7e41d:	kandd  %k0,%k4,%k5
 1f7e422:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7e428:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7e42f:	vpaddd %zmm5,%zmm10,%zmm11
 1f7e435:	vpbroadcastb -0x1ac76f9(%rip),%xmm5        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7e43e:	vmovdqu8 -0x19b66f8(%rip),%xmm2{%k4}        # 5c7d50 <.LCPI3_26>
 1f7e448:	vptestnmd %zmm11,%zmm11,%k4
 1f7e44e:	vpblendmb -0x19b66e8(%rip),%xmm5,%xmm5{%k4}        # 5c7d70 <.LCPI3_28>
 1f7e458:	vpcmpnleud -0x19ad503(%rip){1to16},%zmm11,%k4        # 5d0f60 <.LCPI3_22>
 1f7e463:	cmpb   $0x0,0xc90(%rdi)
 1f7e46a:	vmovdqu8 -0x19b66f4(%rip),%xmm5{%k4}        # 5c7d80 <.LCPI3_29>
 1f7e474:	vpcmpnleud -0x19ad51b(%rip){1to16},%zmm11,%k4        # 5d0f64 <.LCPI3_23>
 1f7e47f:	vmovdqu8 -0x19b66f9(%rip),%xmm5{%k4}        # 5c7d90 <.LCPI3_30>
 1f7e489:	vptestmd %zmm3,%zmm3,%k4
 1f7e48f:	vpor   %xmm4,%xmm8,%xmm3
 1f7e493:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7e499:	kmovw  0x1b0(%rsp),%k4
 1f7e4a2:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7e4a8:	vpor   %xmm2,%xmm4,%xmm2
 1f7e4ac:	vpord  -0x19ad532(%rip){1to4},%xmm2,%xmm3        # 5d0f84 <.LCPI3_81>
 1f7e4b6:	vpbroadcastb -0x1ac7779(%rip),%xmm5        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7e4bf:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7e4c5:	vpor   %xmm5,%xmm2,%xmm3
 1f7e4c9:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7e4cf:	vpmovdb %zmm21,%xmm3
 1f7e4d5:	kmovw  0x50(%rsp),%k3
 1f7e4db:	vpor   %xmm3,%xmm9,%xmm4
 1f7e4df:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7e4e5:	vptestmd -0x19ad587(%rip){1to16},%zmm12,%k3{%k7}        # 5d0f68 <.LCPI3_32>
 1f7e4ef:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7e4f5:	vpor   %xmm5,%xmm4,%xmm6
 1f7e4f9:	vpsrld $0xb,%zmm23,%zmm7
 1f7e500:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7e506:	vpandd -0x19ad588(%rip){1to4},%xmm24,%xmm4        # 5d0f88 <.LCPI3_83>
 1f7e510:	vptestmd -0x19ad5ae(%rip){1to16},%zmm23,%k1        # 5d0f6c <.LCPI3_33>
 1f7e51a:	vpmovdb %zmm7,%xmm7
 1f7e520:	vpand  %xmm7,%xmm8,%xmm7
 1f7e524:	vporq  %xmm16,%xmm4,%xmm5
 1f7e52a:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7e530:	vpmovdb %zmm23,%xmm5
 1f7e536:	vgf2p8affineqb $0x0,-0x19affe9(%rip){1to2},%xmm5,%xmm5        # 5ce558 <.LCPI3_84>
 1f7e541:	vpternlogq $0xf8,%xmm9,%xmm5,%xmm4
 1f7e548:	vpmovdb %zmm19,%xmm9
 1f7e54e:	vpor   %xmm4,%xmm15,%xmm5
 1f7e552:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7e558:	vinserti32x4 $0x3,%xmm13,%zmm22,%zmm5{%k6}{z}
 1f7e55f:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7e566:	vpsrld $0x8,%zmm19,%zmm13
 1f7e56d:	vpsrld $0x10,%zmm19,%zmm6
 1f7e574:	vpmovdb %zmm6,%xmm7
 1f7e57a:	vpmovdb %zmm13,%xmm8
 1f7e580:	vpmovdb %zmm12,%xmm6
 1f7e586:	je     1f7e67e <node_facts_window_run+0x11ae>
 1f7e58c:	vmovdqa64 -0x1ac7d96(%rip),%zmm19        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7e596:	vptestmd %zmm10,%zmm10,%k1{%k2}
 1f7e59c:	add    %r9,%rbp
 1f7e59f:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e5a4:	vpxor  %xmm13,%xmm13,%xmm13
 1f7e5a9:	vpcmpneqd -0x19ad644(%rip){1to16},%zmm10,%k0{%k1}        # 5d0f70 <.LCPI3_38>
 1f7e5b4:	vmovdqa %xmm7,%xmm10
 1f7e5b8:	vpternlogq $0xfe,%xmm9,%xmm3,%xmm10
 1f7e5bf:	kmovq  %k1,%k2
 1f7e5c4:	kmovw  %k1,%eax
 1f7e5c8:	popcnt %eax,%ecx
 1f7e5cc:	vpgatherdd 0x10(%rbp,%zmm19,1),%zmm12{%k2}
 1f7e5d4:	kmovq  %k1,%k2
 1f7e5d9:	vpcmpnleud -0x19ad670(%rip){1to16},%zmm12,%k3        # 5d0f74 <.LCPI3_39>
 1f7e5e4:	vpgatherdd 0x14(%rbp,%zmm19,1),%zmm13{%k2}
 1f7e5ec:	add    %rcx,0x110(%rsp)
 1f7e5f4:	mov    0x10(%rsp),%r10
 1f7e5f9:	vpcmpeqd %zmm11,%zmm12,%k2
 1f7e5ff:	vmovdqa64 %xmm20,%xmm11
 1f7e605:	vpternlogq $0xfe,%xmm8,%xmm10,%xmm11
 1f7e60c:	vptestnmd %zmm13,%zmm13,%k2{%k2}
 1f7e612:	vptestmd %zmm13,%zmm13,%k4
 1f7e618:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm11
 1f7e61f:	korw   %k4,%k3,%k3
 1f7e623:	kandw  %k2,%k0,%k2
 1f7e627:	knotw  %k0,%k0
 1f7e62b:	kandd  %k1,%k0,%k0
 1f7e630:	kandw  %k0,%k3,%k0
 1f7e634:	korw   %k0,%k2,%k2
 1f7e638:	vptestnmd %zmm14,%zmm21,%k0{%k2}
 1f7e63e:	kandw  %k0,%k1,%k0
 1f7e642:	knotd  %k6,%k1
 1f7e647:	kmovd  %k0,%ecx
 1f7e64b:	vptestmb %xmm11,%xmm11,%k0{%k1}
 1f7e651:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7e657:	andn   %eax,%ecx,%eax
 1f7e65c:	popcnt %eax,%eax
 1f7e660:	kmovw  %k0,%ecx
 1f7e664:	popcnt %ecx,%ecx
 1f7e668:	kmovw  %k1,%edx
 1f7e66c:	popcnt %edx,%edx
 1f7e670:	add    %rdx,%r10
 1f7e673:	add    %rax,%r10
 1f7e676:	add    %rcx,%r10
 1f7e679:	mov    %r10,0x10(%rsp)
 1f7e67e:	mov    0x28(%rsp),%r13
 1f7e683:	jmp    1f7dd9c <node_facts_window_run+0x8cc>
 1f7e688:	kandw  %k0,%k7,%k0
 1f7e68c:	vmovdqa %xmm10,0x270(%rsp)
 1f7e695:	vmovdqu64 %zmm11,0x370(%rsp)
 1f7e6a0:	vmovdqu64 %ymm19,0x2b0(%rsp)
 1f7e6ab:	vmovdqu64 %zmm20,0x530(%rsp)
 1f7e6b6:	vmovdqu64 %ymm21,0x430(%rsp)
 1f7e6c1:	vmovdqu64 %zmm7,0x4f0(%rsp)
 1f7e6cc:	vmovdqu %ymm13,0x3f0(%rsp)
 1f7e6d5:	vmovdqu64 %zmm22,0x570(%rsp)
 1f7e6e0:	vmovdqu64 %ymm23,0x650(%rsp)
 1f7e6eb:	vmovdqu64 %zmm5,0x610(%rsp)
 1f7e6f6:	vmovdqu %ymm6,0x4b0(%rsp)
 1f7e6ff:	vmovdqu64 %zmm24,0x5d0(%rsp)
 1f7e70a:	vmovdqu64 %ymm25,0x6c0(%rsp)
 1f7e712:	vmovdqu64 %zmm4,0x780(%rsp)
 1f7e71a:	vmovdqu64 %ymm26,0x490(%rsp)
 1f7e725:	vmovdqu64 %zmm27,0x740(%rsp)
 1f7e72d:	vmovdqu64 %ymm28,0x470(%rsp)
 1f7e738:	vmovdqu64 %zmm0,0x820(%rsp)
 1f7e743:	kmovd  %k6,0x2f0(%rsp)
 1f7e74d:	kmovw  %k7,0x3b0(%rsp)
 1f7e756:	kmovd  %k0,%eax
 1f7e75a:	movzwl %ax,%eax
 1f7e75d:	jmp    1f7e90b <node_facts_window_run+0x143b>
 1f7e762:	mov    0x40(%rsp),%rsi
 1f7e767:	mov    (%r12,%r13,4),%r9d
 1f7e76b:	mov    0xc48(%rdi),%rdx
 1f7e772:	shl    $0x6,%rax
 1f7e776:	mov    %r8b,0x1f0(%rsp)
 1f7e77e:	mov    0x20(%r11),%rcx
 1f7e782:	cmpb   $0x1,(%rdx,%r9,1)
 1f7e787:	mov    %r9,0x230(%rsp)
 1f7e78f:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7e794:	adc    $0x0,%rsi
 1f7e798:	and    $0x1,%edx
 1f7e79b:	mov    %rsi,0x40(%rsp)
 1f7e7a0:	mov    0x98(%rsp),%r14
 1f7e7a8:	mov    (%r14,%r13,4),%esi
 1f7e7ac:	vzeroupper
 1f7e7af:	call   1f93a70 <node_tests_window_line>
 1f7e7b4:	mov    %al,0x1b0(%rsp)
 1f7e7bb:	mov    (%r14,%r13,4),%esi
 1f7e7bf:	mov    0x18(%rsp),%rdi
 1f7e7c4:	call   1f93bc0 <node_tests_window_returns>
 1f7e7c9:	mov    0x18(%rsp),%rdi
 1f7e7ce:	or     0x1f0(%rsp),%al
 1f7e7d5:	mov    0x230(%rsp),%rdx
 1f7e7dd:	vpbroadcastd -0x19ad8b3(%rip),%zmm14        # 5d0f34 <.LCPI3_5>
 1f7e7e7:	vpbroadcastb -0x1ac7ab0(%rip),%xmm15        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e7f0:	vpbroadcastb -0x1ac7ab9(%rip),%xmm16        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e7fa:	vpbroadcastd -0x19ad8c8(%rip),%zmm17        # 5d0f3c <.LCPI3_11>
 1f7e804:	vpbroadcastd -0x19ad8ca(%rip),%zmm18        # 5d0f44 <.LCPI3_13>
 1f7e80e:	vmovdqa 0x270(%rsp),%xmm10
 1f7e817:	vmovdqu64 0x370(%rsp),%zmm11
 1f7e822:	vmovdqu64 0x2b0(%rsp),%ymm19
 1f7e82d:	vmovdqu64 0x530(%rsp),%zmm20
 1f7e838:	vmovdqu64 0x430(%rsp),%ymm21
 1f7e843:	vmovdqu64 0x4f0(%rsp),%zmm7
 1f7e84e:	vmovdqu 0x3f0(%rsp),%ymm13
 1f7e857:	vmovdqu64 0x570(%rsp),%zmm22
 1f7e862:	vmovdqu64 0x650(%rsp),%ymm23
 1f7e86d:	vmovdqu64 0x610(%rsp),%zmm5
 1f7e878:	vmovdqu 0x4b0(%rsp),%ymm6
 1f7e881:	vmovdqu64 0x5d0(%rsp),%zmm24
 1f7e88c:	vmovdqu64 0x6c0(%rsp),%ymm25
 1f7e894:	vmovdqu64 0x780(%rsp),%zmm4
 1f7e89c:	vmovdqu64 0x490(%rsp),%ymm26
 1f7e8a7:	vmovdqu64 0x740(%rsp),%zmm27
 1f7e8af:	vmovdqu64 0x470(%rsp),%ymm28
 1f7e8ba:	vmovdqu64 0x820(%rsp),%zmm0
 1f7e8c5:	mov    0x8(%rsp),%r11
 1f7e8ca:	mov    0x38(%rsp),%rsi
 1f7e8cf:	mov    0x150(%rsp),%r8
 1f7e8d7:	mov    0x20(%rsp),%r9
 1f7e8dc:	kmovd  0x2f0(%rsp),%k6
 1f7e8e6:	kmovw  0x3b0(%rsp),%k7
 1f7e8ef:	or     0x1b0(%rsp),%al
 1f7e8f6:	mov    0xc48(%rdi),%rcx
 1f7e8fd:	mov    %al,(%rcx,%rdx,1)
 1f7e900:	mov    0x50(%rsp),%eax
 1f7e904:	blsr   %eax,%eax
 1f7e909:	je     1f7e97b <node_facts_window_run+0x14ab>
 1f7e90b:	tzcnt  %eax,%r13d
 1f7e910:	mov    %eax,0x50(%rsp)
 1f7e914:	mov    0x60(%r11),%edx
 1f7e918:	mov    $0x1,%r8b
 1f7e91b:	add    %rbx,%r13
 1f7e91e:	mov    %r13,%rcx
 1f7e921:	shl    $0x6,%rcx
 1f7e925:	mov    (%r9,%rcx,1),%eax
 1f7e929:	mov    0xc(%r9,%rcx,1),%ecx
 1f7e92e:	shr    $0x3,%eax
 1f7e931:	cmp    %edx,%eax
 1f7e933:	cmovae %edx,%eax
 1f7e936:	test   %rcx,%rcx
 1f7e939:	je     1f7e762 <node_facts_window_run+0x1292>
 1f7e93f:	mov    0x90(%rsp),%rdx
 1f7e947:	mov    0x40(%rsp),%rsi
 1f7e94c:	cmp    0x3b8(%rdx),%ecx
 1f7e952:	jae    1f7e767 <node_facts_window_run+0x1297>
 1f7e958:	mov    0x90(%rsp),%rdx
 1f7e960:	mov    0x3a8(%rdx),%rdx
 1f7e967:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7e96b:	setne  %r8b
 1f7e96f:	shl    $0x5,%r8b
 1f7e973:	inc    %r8b
 1f7e976:	jmp    1f7e767 <node_facts_window_run+0x1297>
 1f7e97b:	mov    0xc48(%rdi),%rax
 1f7e982:	kmovq  %k7,%k1
 1f7e987:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e98c:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7e993:	jmp    1f7df4e <node_facts_window_run+0xa7e>
 1f7e998:	cmpq   $0x0,0xb40(%r11)
 1f7e9a0:	je     1f800a2 <node_facts_window_run+0x2bd2>
 1f7e9a6:	test   %eax,%eax
 1f7e9a8:	je     1f808f7 <node_facts_window_run+0x3427>
 1f7e9ae:	vpbroadcastd -0x19ada84(%rip),%zmm10        # 5d0f34 <.LCPI3_5>
 1f7e9b8:	vpbroadcastb -0x1ac7c81(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7e9c1:	vpbroadcastb -0x1ac7c89(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7e9ca:	vpbroadcastd -0x19ada98(%rip),%zmm13        # 5d0f3c <.LCPI3_11>
 1f7e9d4:	vpbroadcastd -0x19ada9a(%rip),%zmm14        # 5d0f44 <.LCPI3_13>
 1f7e9de:	mov    (%r11),%rcx
 1f7e9e1:	lea    0x69454(%r13),%r10
 1f7e9e8:	lea    0x422c(%r13),%rdx
 1f7e9ef:	mov    %eax,%r15d
 1f7e9f2:	xor    %r14d,%r14d
 1f7e9f5:	mov    %rcx,0x5d0(%rsp)
 1f7e9fd:	mov    %r10,0x650(%rsp)
 1f7ea05:	mov    %rdx,0x610(%rsp)
 1f7ea0d:	movq   $0x0,0x40(%rsp)
 1f7ea16:	movq   $0x0,0x110(%rsp)
 1f7ea22:	movq   $0x0,0x10(%rsp)
 1f7ea2b:	mov    %r15,0x4b0(%rsp)
 1f7ea33:	jmp    1f7eac3 <node_facts_window_run+0x15f3>
 1f7ea38:	nopl   0x0(%rax,%rax,1)
 1f7ea40:	vpxor  %xmm1,%xmm1,%xmm1
 1f7ea44:	vpxor  %xmm3,%xmm3,%xmm3
 1f7ea48:	vpxor  %xmm4,%xmm4,%xmm4
 1f7ea4c:	vpxor  %xmm5,%xmm5,%xmm5
 1f7ea50:	vpxor  %xmm0,%xmm0,%xmm0
 1f7ea54:	vpxord %xmm16,%xmm16,%xmm16
 1f7ea5a:	mov    0xc10(%rdi),%rax
 1f7ea61:	vmovdqu64 %xmm16,(%rax,%r14,1)
 1f7ea68:	mov    0xc18(%rdi),%rax
 1f7ea6f:	vmovdqu %xmm0,(%rax,%r14,1)
 1f7ea75:	mov    0xb88(%r11),%rax
 1f7ea7c:	vmovdqu %xmm5,(%rax,%r14,1)
 1f7ea82:	mov    0xb90(%r11),%rax
 1f7ea89:	vmovdqu %xmm4,(%rax,%r14,1)
 1f7ea8f:	mov    0xb98(%r11),%rax
 1f7ea96:	vmovdqu %xmm3,(%rax,%r14,1)
 1f7ea9c:	mov    0xba0(%r11),%rax
 1f7eaa3:	vmovdqu %xmm1,(%rax,%r14,1)
 1f7eaa9:	mov    0xba8(%r11),%rax
 1f7eab0:	vmovdqu %xmm2,(%rax,%r14,1)
 1f7eab6:	add    $0x10,%r14
 1f7eaba:	cmp    %r15,%r14
 1f7eabd:	jae    1f80915 <node_facts_window_run+0x3445>
 1f7eac3:	vpxor  %xmm2,%xmm2,%xmm2
 1f7eac7:	cmp    %r8,%r14
 1f7eaca:	jae    1f7ea40 <node_facts_window_run+0x1570>
 1f7ead0:	mov    %r8d,%eax
 1f7ead3:	sub    %r14d,%eax
 1f7ead6:	mov    $0x10,%ecx
 1f7eadb:	mov    $0xffffffff,%edx
 1f7eae0:	mov    %r14,%rbp
 1f7eae3:	vpxord %xmm18,%xmm18,%xmm18
 1f7eae9:	cmp    $0x10,%eax
 1f7eaec:	cmovae %ecx,%eax
 1f7eaef:	mov    0x9b8(%r11),%rcx
 1f7eaf6:	shl    $0x6,%rbp
 1f7eafa:	shlx   %eax,%edx,%eax
 1f7eaff:	vmovdqu (%r9,%rbp,1),%ymm0
 1f7eb05:	vmovdqu 0x180(%r9,%rbp,1),%ymm3
 1f7eb0f:	vmovdqu 0x80(%r9,%rbp,1),%ymm1
 1f7eb19:	vmovdqu 0x100(%r9,%rbp,1),%ymm2
 1f7eb23:	not    %eax
 1f7eb25:	vinserti64x4 $0x1,0x40(%r9,%rbp,1),%zmm0,%zmm6
 1f7eb2e:	vmovdqu 0x200(%r9,%rbp,1),%ymm0
 1f7eb38:	vinserti64x4 $0x1,0x1c0(%r9,%rbp,1),%zmm3,%zmm7
 1f7eb41:	vinserti64x4 $0x1,0xc0(%r9,%rbp,1),%zmm1,%zmm1
 1f7eb4a:	vinserti64x4 $0x1,0x140(%r9,%rbp,1),%zmm2,%zmm2
 1f7eb53:	kmovd  %eax,%k1
 1f7eb57:	vinserti64x4 $0x1,0x240(%r9,%rbp,1),%zmm0,%zmm3
 1f7eb60:	vmovdqu 0x280(%r9,%rbp,1),%ymm0
 1f7eb6a:	mov    0xc48(%rdi),%rax
 1f7eb71:	vinserti64x4 $0x1,0x2c0(%r9,%rbp,1),%zmm0,%zmm9
 1f7eb7a:	vmovdqu 0x300(%r9,%rbp,1),%ymm0
 1f7eb84:	vmovdqu8 (%rcx,%r14,1),%xmm4{%k1}{z}
 1f7eb8b:	mov    0x650(%rsp),%rcx
 1f7eb93:	vinserti64x4 $0x1,0x340(%r9,%rbp,1),%zmm0,%zmm8
 1f7eb9c:	vmovdqu 0x380(%r9,%rbp,1),%ymm0
 1f7eba6:	vinserti64x4 $0x1,0x3c0(%r9,%rbp,1),%zmm0,%zmm15
 1f7ebaf:	vmovdqu8 (%rcx,%r14,1),%xmm5{%k1}{z}
 1f7ebb6:	vptestmb %xmm4,%xmm4,%k6
 1f7ebbc:	vpcmpeqb -0x19b6eb6(%rip),%xmm5,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7ebc6:	vmovdqu32 (%r12,%r14,4),%zmm0{%k7}{z}
 1f7ebcd:	kmovq  %k7,%k1
 1f7ebd2:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7ebd9:	vptestnmd %zmm13,%zmm18,%k0
 1f7ebdf:	ktestw %k0,%k7
 1f7ebe3:	jne    1f7f1ae <node_facts_window_run+0x1cde>
 1f7ebe9:	vmovdqa64 -0x1ac84b3(%rip),%zmm0        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7ebf3:	vptestmd -0x19adcbd(%rip){1to16},%zmm18,%k0        # 5d0f40 <.LCPI3_12>
 1f7ebfd:	kmovd  %k6,%edx
 1f7ec01:	vpermt2d %zmm1,%zmm0,%zmm6
 1f7ec07:	vpermt2d %zmm7,%zmm0,%zmm2
 1f7ec0d:	vpermt2d %zmm9,%zmm0,%zmm3
 1f7ec13:	vpermt2d %zmm15,%zmm0,%zmm8
 1f7ec19:	kmovd  %k0,%r13d
 1f7ec1d:	vptestmd %zmm14,%zmm18,%k0
 1f7ec23:	vshufi64x2 $0x44,%zmm2,%zmm6,%zmm0
 1f7ec2a:	vshufi64x2 $0x44,%zmm8,%zmm3,%zmm1
 1f7ec31:	vshufi64x2 $0xee,%zmm2,%zmm6,%zmm2
 1f7ec38:	vshufi64x2 $0xee,%zmm8,%zmm3,%zmm3
 1f7ec3f:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm15{%k6}{z}
 1f7ec46:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7ec4d:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm17{%k6}{z}
 1f7ec54:	vshufi64x2 $0x88,%zmm3,%zmm2,%zmm7
 1f7ec5b:	vpsrld $0x19,%zmm15,%zmm0
 1f7ec62:	vpandd -0x19add3c(%rip){1to16},%zmm0,%zmm0        # 5d0f30 <.LCPI3_4>
 1f7ec6c:	vpsrld $0x18,%zmm15,%zmm1
 1f7ec73:	vpsrld $0x1a,%zmm15,%zmm6
 1f7ec7a:	vpternlogd $0xec,%zmm10,%zmm0,%zmm1
 1f7ec81:	vpandd -0x19add0f(%rip){1to16},%zmm15,%zmm0        # 5d0f7c <.LCPI3_75>
 1f7ec8b:	vpmovdb %zmm1,%xmm16
 1f7ec91:	vpsrld $0xc,%zmm17,%zmm1
 1f7ec98:	vpmovdb %zmm1,%xmm20
 1f7ec9e:	vpcmpeqd -0x19add70(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f38 <.LCPI3_7>
 1f7eca8:	vporq  %xmm11,%xmm16,%xmm0
 1f7ecae:	vmovdqu8 %xmm0,%xmm16{%k1}
 1f7ecb4:	vpcmpeqb %xmm11,%xmm5,%k1{%k6}
 1f7ecba:	vpternlogq $0xf8,%xmm12,%xmm20,%xmm16
 1f7ecc1:	kmovd  %k1,%eax
 1f7ecc5:	kmovw  %k1,0x50(%rsp)
 1f7eccb:	korw   %k0,%k1,%k1
 1f7eccf:	kmovw  %k1,0x230(%rsp)
 1f7ecd8:	test   %ax,%ax
 1f7ecdb:	je     1f7ee6e <node_facts_window_run+0x199e>
 1f7ece1:	vmovdqu64 %zmm7,0x570(%rsp)
 1f7ecec:	vmovdqu64 %zmm6,0x3f0(%rsp)
 1f7ecf7:	vmovdqa64 %xmm20,0x4f0(%rsp)
 1f7ecff:	vmovdqu64 %zmm19,0x430(%rsp)
 1f7ed0a:	vmovdqu64 %zmm18,0x530(%rsp)
 1f7ed15:	vmovdqu64 %zmm15,0x2b0(%rsp)
 1f7ed20:	vmovdqa %xmm4,0x270(%rsp)
 1f7ed29:	vmovdqu64 %zmm17,0x370(%rsp)
 1f7ed34:	mov    %edx,0x3b0(%rsp)
 1f7ed3b:	vmovdqa64 %xmm16,0x2f0(%rsp)
 1f7ed43:	kmovw  %k7,0x1f0(%rsp)
 1f7ed4c:	kmovw  %k6,0x1b0(%rsp)
 1f7ed55:	movzwl %ax,%ebx
 1f7ed58:	movzwl %r13w,%r13d
 1f7ed5c:	mov    0x610(%rsp),%rax
 1f7ed64:	lea    (%rax,%r14,4),%r15
 1f7ed68:	nopl   0x0(%rax,%rax,1)
 1f7ed70:	xor    %r12d,%r12d
 1f7ed73:	tzcnt  %ebx,%r12d
 1f7ed78:	xor    %edx,%edx
 1f7ed7a:	mov    (%r15,%r12,4),%esi
 1f7ed7e:	vzeroupper
 1f7ed81:	call   1f93a70 <node_tests_window_line>
 1f7ed86:	mov    0x18(%rsp),%rdi
 1f7ed8b:	mov    $0x1,%edx
 1f7ed90:	xor    %ecx,%ecx
 1f7ed92:	test   $0x2,%al
 1f7ed94:	shlx   %r12d,%edx,%eax
 1f7ed99:	cmove  %ecx,%eax
 1f7ed9c:	or     %eax,%r13d
 1f7ed9f:	blsr   %ebx,%ebx
 1f7eda4:	jne    1f7ed70 <node_facts_window_run+0x18a0>
 1f7eda6:	vpbroadcastd -0x19ade7c(%rip),%zmm10        # 5d0f34 <.LCPI3_5>
 1f7edb0:	vpbroadcastb -0x1ac8079(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7edb9:	vpbroadcastb -0x1ac8081(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7edc2:	vpbroadcastd -0x19ade90(%rip),%zmm13        # 5d0f3c <.LCPI3_11>
 1f7edcc:	vpbroadcastd -0x19ade92(%rip),%zmm14        # 5d0f44 <.LCPI3_13>
 1f7edd6:	vmovdqa64 0x2f0(%rsp),%xmm16
 1f7edde:	vmovdqu64 0x370(%rsp),%zmm17
 1f7ede9:	vmovdqa 0x270(%rsp),%xmm4
 1f7edf2:	vmovdqu64 0x2b0(%rsp),%zmm15
 1f7edfd:	vmovdqu64 0x530(%rsp),%zmm18
 1f7ee08:	vmovdqu64 0x430(%rsp),%zmm19
 1f7ee13:	vmovdqa64 0x4f0(%rsp),%xmm20
 1f7ee1b:	vmovdqu64 0x3f0(%rsp),%zmm6
 1f7ee26:	vmovdqu64 0x570(%rsp),%zmm7
 1f7ee31:	mov    0x8(%rsp),%r11
 1f7ee36:	mov    0x38(%rsp),%rsi
 1f7ee3b:	mov    0x30(%rsp),%r12
 1f7ee40:	mov    0x150(%rsp),%r8
 1f7ee48:	mov    0x20(%rsp),%r9
 1f7ee4d:	mov    0x4b0(%rsp),%r15
 1f7ee55:	kmovw  0x1b0(%rsp),%k6
 1f7ee5e:	kmovw  0x1f0(%rsp),%k7
 1f7ee67:	mov    0x3b0(%rsp),%edx
 1f7ee6e:	vpsrld $0x2,%zmm17,%zmm0
 1f7ee75:	vpandd -0x19adf37(%rip){1to16},%zmm0,%zmm0        # 5d0f48 <.LCPI3_14>
 1f7ee7f:	vptestmd -0x19adf39(%rip){1to16},%zmm17,%k2        # 5d0f50 <.LCPI3_16>
 1f7ee89:	vpandd -0x19adf13(%rip){1to16},%zmm15,%zmm3        # 5d0f80 <.LCPI3_78>
 1f7ee93:	vptestnmb %xmm4,%xmm4,%k0
 1f7ee99:	vpbroadcastd -0x19adf47(%rip),%zmm4        # 5d0f5c <.LCPI3_21>
 1f7eea3:	vptestmd -0x19adf59(%rip){1to16},%zmm19,%k3        # 5d0f54 <.LCPI3_17>
 1f7eead:	vpandd %zmm14,%zmm19,%zmm1
 1f7eeb3:	vpbroadcastb -0x1ac8178(%rip),%xmm8        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7eebc:	vpbroadcastb -0x1ac8183(%rip),%xmm5        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7eec5:	vpbroadcastb -0x1ac818b(%rip),%xmm9        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7eece:	vpcmpneqd -0x19adf8d(%rip){1to16},%zmm0,%k1        # 5d0f4c <.LCPI3_15>
 1f7eed9:	vpaddd -0x19adf8b(%rip){1to16},%zmm3,%zmm3        # 5d0f58 <.LCPI3_20>
 1f7eee3:	vpcmpeqd %zmm4,%zmm6,%k5{%k6}
 1f7eee9:	vpsrld $0x10,%zmm17,%zmm6
 1f7eef0:	korw   %k1,%k2,%k1
 1f7eef4:	vptestnmd %zmm7,%zmm7,%k2
 1f7eefa:	korw   %k2,%k0,%k2
 1f7eefe:	vptestnmd %zmm1,%zmm1,%k0
 1f7ef04:	korw   %k1,%k2,%k1
 1f7ef08:	kmovd  %k0,%eax
 1f7ef0c:	vpcmpltud %zmm4,%zmm3,%k0
 1f7ef13:	vpslld $0x1f,%zmm3,%zmm3
 1f7ef1a:	vpxor  %xmm4,%xmm4,%xmm4
 1f7ef1e:	vptestmd %zmm0,%zmm0,%k1{%k1}
 1f7ef24:	kmovd  %k0,%ecx
 1f7ef28:	and    %eax,%ecx
 1f7ef2a:	mov    %edx,%eax
 1f7ef2c:	and    %ecx,%eax
 1f7ef2e:	kmovd  %eax,%k4
 1f7ef32:	vmovdqu8 %xmm11,%xmm2{%k1}{z}
 1f7ef38:	kmovd  %r13d,%k1
 1f7ef3d:	korw   %k3,%k1,%k3
 1f7ef41:	vpcmpeqd %zmm13,%zmm0,%k1{%k4}
 1f7ef47:	vmovdqu8 %xmm8,%xmm0{%k5}{z}
 1f7ef4d:	vmovdqu8 -0x19b7217(%rip),%xmm0{%k4}        # 5c7d40 <.LCPI3_25>
 1f7ef57:	knotw  %k1,%k0
 1f7ef5b:	kmovd  %k0,%ecx
 1f7ef5f:	and    %eax,%ecx
 1f7ef61:	kmovd  %ecx,%k4
 1f7ef65:	vpcmpgtd %zmm3,%zmm4,%k4{%k4}
 1f7ef6b:	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
 1f7ef72:	vpaddd %zmm3,%zmm6,%zmm7
 1f7ef78:	vpbroadcastb -0x1ac823c(%rip),%xmm3        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7ef81:	vmovdqu8 -0x19b723b(%rip),%xmm0{%k4}        # 5c7d50 <.LCPI3_26>
 1f7ef8b:	vptestnmd %zmm7,%zmm7,%k4
 1f7ef91:	vpblendmb -0x19b722b(%rip),%xmm3,%xmm3{%k4}        # 5c7d70 <.LCPI3_28>
 1f7ef9b:	vpcmpnleud -0x19ae046(%rip){1to16},%zmm7,%k4        # 5d0f60 <.LCPI3_22>
 1f7efa6:	cmpb   $0x0,0xc90(%rdi)
 1f7efad:	vmovdqu8 -0x19b7237(%rip),%xmm3{%k4}        # 5c7d80 <.LCPI3_29>
 1f7efb7:	vpcmpnleud -0x19ae05e(%rip){1to16},%zmm7,%k4        # 5d0f64 <.LCPI3_23>
 1f7efc2:	vmovdqu8 -0x19b723c(%rip),%xmm3{%k4}        # 5c7d90 <.LCPI3_30>
 1f7efcc:	vptestmd %zmm1,%zmm1,%k4
 1f7efd2:	vpor   %xmm5,%xmm2,%xmm1
 1f7efd6:	vmovdqu8 %xmm1,%xmm2{%k4}
 1f7efdc:	kmovw  0x230(%rsp),%k4
 1f7efe5:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f7efeb:	vpor   %xmm0,%xmm2,%xmm0
 1f7efef:	vpord  -0x19ae075(%rip){1to4},%xmm0,%xmm1        # 5d0f84 <.LCPI3_81>
 1f7eff9:	vpbroadcastb -0x1ac82bc(%rip),%xmm3        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7f002:	vmovdqu8 %xmm1,%xmm0{%k4}
 1f7f008:	vpor   %xmm3,%xmm0,%xmm1
 1f7f00c:	vmovdqu8 %xmm1,%xmm0{%k3}
 1f7f012:	vpmovdb %zmm17,%xmm1
 1f7f018:	kmovw  0x50(%rsp),%k3
 1f7f01e:	vpor   %xmm1,%xmm9,%xmm2
 1f7f022:	vmovdqu8 %xmm2,%xmm1{%k3}
 1f7f028:	vptestmd -0x19ae0ca(%rip){1to16},%zmm18,%k3{%k7}        # 5d0f68 <.LCPI3_32>
 1f7f032:	vmovdqu8 %xmm8,%xmm2{%k3}{z}
 1f7f038:	vpor   %xmm3,%xmm2,%xmm3
 1f7f03c:	vpsrld $0x8,%zmm15,%zmm8
 1f7f043:	vmovdqu8 %xmm2,%xmm3{%k2}
 1f7f049:	vpandd -0x19ae0cb(%rip){1to4},%xmm20,%xmm2        # 5d0f88 <.LCPI3_83>
 1f7f053:	vptestmd -0x19ae0f1(%rip){1to16},%zmm19,%k2        # 5d0f6c <.LCPI3_33>
 1f7f05d:	vpor   %xmm2,%xmm12,%xmm4
 1f7f061:	vmovdqu8 %xmm4,%xmm2{%k6}
 1f7f067:	vpmovdb %zmm19,%xmm4
 1f7f06d:	vgf2p8affineqb $0x0,-0x19b0b20(%rip){1to2},%xmm4,%xmm4        # 5ce558 <.LCPI3_84>
 1f7f078:	vpternlogq $0xf8,%xmm9,%xmm4,%xmm2
 1f7f07f:	vpor   %xmm2,%xmm11,%xmm4
 1f7f083:	vmovdqu8 %xmm4,%xmm2{%k2}
 1f7f089:	vpsrld $0xb,%zmm19,%zmm4
 1f7f090:	vpmovdb %zmm4,%xmm4
 1f7f096:	vpand  %xmm5,%xmm4,%xmm4
 1f7f09a:	vpmovdb %zmm15,%xmm5
 1f7f0a0:	vpternlogq $0xfe,%xmm4,%xmm3,%xmm2
 1f7f0a7:	vpsrld $0x10,%zmm15,%zmm3
 1f7f0ae:	vpmovdb %zmm8,%xmm4
 1f7f0b4:	vpmovdb %zmm3,%xmm3
 1f7f0ba:	je     1f7f1a4 <node_facts_window_run+0x1cd4>
 1f7f0c0:	vmovdqa64 -0x1ac88ca(%rip),%zmm15        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7f0ca:	vptestmd %zmm6,%zmm6,%k1{%k1}
 1f7f0d0:	add    %r9,%rbp
 1f7f0d3:	vpxor  %xmm8,%xmm8,%xmm8
 1f7f0d8:	vpxor  %xmm9,%xmm9,%xmm9
 1f7f0dd:	vpcmpneqd -0x19ae178(%rip){1to16},%zmm6,%k0{%k1}        # 5d0f70 <.LCPI3_38>
 1f7f0e8:	vmovdqa %xmm3,%xmm6
 1f7f0ec:	vpternlogq $0xfe,%xmm5,%xmm1,%xmm6
 1f7f0f3:	kmovq  %k1,%k2
 1f7f0f8:	kmovw  %k1,%eax
 1f7f0fc:	popcnt %eax,%ecx
 1f7f100:	vpgatherdd 0x10(%rbp,%zmm15,1),%zmm8{%k2}
 1f7f108:	kmovq  %k1,%k2
 1f7f10d:	vpcmpnleud -0x19ae1a4(%rip){1to16},%zmm8,%k3        # 5d0f74 <.LCPI3_39>
 1f7f118:	vpgatherdd 0x14(%rbp,%zmm15,1),%zmm9{%k2}
 1f7f120:	add    %rcx,0x110(%rsp)
 1f7f128:	mov    0x10(%rsp),%r10
 1f7f12d:	vpcmpeqd %zmm7,%zmm8,%k2
 1f7f133:	vmovdqa64 %xmm16,%xmm7
 1f7f139:	vpternlogq $0xfe,%xmm4,%xmm6,%xmm7
 1f7f140:	vptestnmd %zmm9,%zmm9,%k2{%k2}
 1f7f146:	vptestmd %zmm9,%zmm9,%k4
 1f7f14c:	vpternlogq $0xfe,%xmm2,%xmm0,%xmm7
 1f7f153:	korw   %k4,%k3,%k3
 1f7f157:	kandw  %k2,%k0,%k2
 1f7f15b:	knotw  %k0,%k0
 1f7f15f:	kandd  %k1,%k0,%k0
 1f7f164:	kandw  %k0,%k3,%k0
 1f7f168:	korw   %k0,%k2,%k2
 1f7f16c:	vptestnmd %zmm10,%zmm17,%k0{%k2}
 1f7f172:	kandw  %k0,%k1,%k0
 1f7f176:	kmovd  %k0,%ecx
 1f7f17a:	vptestmb %xmm7,%xmm7,%k0
 1f7f180:	andn   %eax,%ecx,%eax
 1f7f185:	kmovd  %k0,%ecx
 1f7f189:	andn   %ecx,%edx,%ecx
 1f7f18e:	popcnt %eax,%eax
 1f7f192:	movzwl %cx,%ecx
 1f7f195:	popcnt %ecx,%ecx
 1f7f199:	add    %rcx,%r10
 1f7f19c:	add    %rax,%r10
 1f7f19f:	mov    %r10,0x10(%rsp)
 1f7f1a4:	mov    0x28(%rsp),%r13
 1f7f1a9:	jmp    1f7ea5a <node_facts_window_run+0x158a>
 1f7f1ae:	kandw  %k0,%k7,%k0
 1f7f1b2:	vmovdqa %xmm5,0x230(%rsp)
 1f7f1bb:	vmovdqu64 %zmm6,0x2f0(%rsp)
 1f7f1c6:	vmovdqu64 %zmm2,0x3b0(%rsp)
 1f7f1d1:	vmovdqu64 %zmm3,0x370(%rsp)
 1f7f1dc:	vmovdqu64 %zmm1,0x2b0(%rsp)
 1f7f1e7:	vmovdqu64 %zmm7,0x530(%rsp)
 1f7f1f2:	vmovdqu64 %zmm8,0x430(%rsp)
 1f7f1fd:	vmovdqu64 %zmm9,0x4f0(%rsp)
 1f7f208:	vmovdqu64 %zmm15,0x3f0(%rsp)
 1f7f213:	vmovdqu64 %zmm0,0x570(%rsp)
 1f7f21e:	kmovw  %k6,0x1b0(%rsp)
 1f7f227:	kmovw  %k7,0x1f0(%rsp)
 1f7f230:	vmovdqa %xmm4,0x270(%rsp)
 1f7f239:	kmovd  %k0,%eax
 1f7f23d:	movzwl %ax,%r13d
 1f7f241:	jmp    1f7f36f <node_facts_window_run+0x1e9f>
 1f7f246:	mov    (%r12,%rax,4),%r9d
 1f7f24a:	mov    0xc48(%rdi),%rsi
 1f7f251:	shl    $0x6,%rcx
 1f7f255:	mov    0x20(%r11),%rdx
 1f7f259:	cmpb   $0x1,(%rsi,%r9,1)
 1f7f25e:	mov    %r9,0x50(%rsp)
 1f7f263:	movzbl 0x30(%rdx,%rcx,1),%edx
 1f7f268:	adcq   $0x0,0x40(%rsp)
 1f7f26e:	and    $0x1,%edx
 1f7f271:	mov    0x610(%rsp),%rsi
 1f7f279:	mov    (%rsi,%rax,4),%esi
 1f7f27c:	vzeroupper
 1f7f27f:	call   1f93a70 <node_tests_window_line>
 1f7f284:	mov    0x18(%rsp),%rdi
 1f7f289:	vpbroadcastd -0x19ae35f(%rip),%zmm10        # 5d0f34 <.LCPI3_5>
 1f7f293:	vpbroadcastb -0x1ac855c(%rip),%xmm11        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f29c:	vpbroadcastb -0x1ac8564(%rip),%xmm12        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f2a5:	vpbroadcastd -0x19ae373(%rip),%zmm13        # 5d0f3c <.LCPI3_11>
 1f7f2af:	vpbroadcastd -0x19ae375(%rip),%zmm14        # 5d0f44 <.LCPI3_13>
 1f7f2b9:	vmovdqa 0x270(%rsp),%xmm4
 1f7f2c2:	vmovdqa 0x230(%rsp),%xmm5
 1f7f2cb:	vmovdqu64 0x2f0(%rsp),%zmm6
 1f7f2d6:	vmovdqu64 0x3b0(%rsp),%zmm2
 1f7f2e1:	vmovdqu64 0x370(%rsp),%zmm3
 1f7f2ec:	vmovdqu64 0x2b0(%rsp),%zmm1
 1f7f2f7:	vmovdqu64 0x530(%rsp),%zmm7
 1f7f302:	vmovdqu64 0x430(%rsp),%zmm8
 1f7f30d:	vmovdqu64 0x4f0(%rsp),%zmm9
 1f7f318:	vmovdqu64 0x3f0(%rsp),%zmm15
 1f7f323:	vmovdqu64 0x570(%rsp),%zmm0
 1f7f32e:	mov    0x8(%rsp),%r11
 1f7f333:	mov    0x50(%rsp),%rdx
 1f7f338:	mov    0x38(%rsp),%rsi
 1f7f33d:	mov    0x150(%rsp),%r8
 1f7f345:	mov    0x20(%rsp),%r9
 1f7f34a:	kmovw  0x1b0(%rsp),%k6
 1f7f353:	kmovw  0x1f0(%rsp),%k7
 1f7f35c:	or     %bl,%al
 1f7f35e:	blsr   %r13d,%r13d
 1f7f363:	mov    0xc48(%rdi),%rcx
 1f7f36a:	mov    %al,(%rcx,%rdx,1)
 1f7f36d:	je     1f7f3d4 <node_facts_window_run+0x1f04>
 1f7f36f:	xor    %eax,%eax
 1f7f371:	tzcnt  %r13d,%eax
 1f7f376:	mov    0x60(%r11),%esi
 1f7f37a:	mov    $0x1,%bl
 1f7f37c:	add    %r14,%rax
 1f7f37f:	mov    %rax,%rdx
 1f7f382:	shl    $0x6,%rdx
 1f7f386:	mov    (%r9,%rdx,1),%ecx
 1f7f38a:	mov    0xc(%r9,%rdx,1),%edx
 1f7f38f:	shr    $0x3,%ecx
 1f7f392:	cmp    %esi,%ecx
 1f7f394:	cmovae %esi,%ecx
 1f7f397:	test   %rdx,%rdx
 1f7f39a:	je     1f7f246 <node_facts_window_run+0x1d76>
 1f7f3a0:	mov    0x5d0(%rsp),%rsi
 1f7f3a8:	cmp    0x3b8(%rsi),%edx
 1f7f3ae:	jae    1f7f246 <node_facts_window_run+0x1d76>
 1f7f3b4:	mov    0x5d0(%rsp),%rsi
 1f7f3bc:	mov    0x3a8(%rsi),%rsi
 1f7f3c3:	cmpl   $0x0,(%rsi,%rdx,4)
 1f7f3c7:	setne  %bl
 1f7f3ca:	shl    $0x5,%bl
 1f7f3cd:	inc    %bl
 1f7f3cf:	jmp    1f7f246 <node_facts_window_run+0x1d76>
 1f7f3d4:	mov    0xc48(%rdi),%rax
 1f7f3db:	kmovq  %k7,%k1
 1f7f3e0:	vpxord %xmm18,%xmm18,%xmm18
 1f7f3e6:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7f3ed:	jmp    1f7ebe9 <node_facts_window_run+0x1719>
 1f7f3f2:	test   %eax,%eax
 1f7f3f4:	je     1f808f7 <node_facts_window_run+0x3427>
 1f7f3fa:	vpbroadcastd -0x19ae4d0(%rip),%zmm13        # 5d0f34 <.LCPI3_5>
 1f7f404:	vpbroadcastb -0x1ac86cd(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f40d:	vpbroadcastb -0x1ac86d5(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f416:	vpbroadcastd -0x19ae4e4(%rip),%zmm16        # 5d0f3c <.LCPI3_11>
 1f7f420:	vpbroadcastd -0x19ae4e6(%rip),%zmm17        # 5d0f44 <.LCPI3_13>
 1f7f42a:	mov    (%r11),%rcx
 1f7f42d:	lea    0x69454(%r13),%r10
 1f7f434:	lea    0x422c(%r13),%rdx
 1f7f43b:	mov    %eax,%r14d
 1f7f43e:	xor    %r15d,%r15d
 1f7f441:	mov    %rcx,0x90(%rsp)
 1f7f449:	mov    %r10,0xb0(%rsp)
 1f7f451:	mov    %rdx,0x98(%rsp)
 1f7f459:	movq   $0x0,0x40(%rsp)
 1f7f462:	movq   $0x0,0x110(%rsp)
 1f7f46e:	movq   $0x0,0x10(%rsp)
 1f7f477:	mov    %r14,0xa8(%rsp)
 1f7f47f:	jmp    1f7f54b <node_facts_window_run+0x207b>
 1f7f484:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7f490:	vpxor  %xmm1,%xmm1,%xmm1
 1f7f494:	vpxor  %xmm0,%xmm0,%xmm0
 1f7f498:	vpxor  %xmm5,%xmm5,%xmm5
 1f7f49c:	vpxor  %xmm3,%xmm3,%xmm3
 1f7f4a0:	vpxor  %xmm6,%xmm6,%xmm6
 1f7f4a4:	vpxor  %xmm7,%xmm7,%xmm7
 1f7f4a8:	vpxor  %xmm8,%xmm8,%xmm8
 1f7f4ad:	vpxor  %xmm2,%xmm2,%xmm2
 1f7f4b1:	vpxord %xmm19,%xmm19,%xmm19
 1f7f4b7:	mov    0xc10(%rdi),%rax
 1f7f4be:	vmovdqu64 %xmm19,(%rax,%r15,1)
 1f7f4c5:	mov    0xc18(%rdi),%rax
 1f7f4cc:	vmovdqu %xmm2,(%rax,%r15,1)
 1f7f4d2:	mov    0xb88(%r11),%rax
 1f7f4d9:	vmovdqu %xmm8,(%rax,%r15,1)
 1f7f4df:	mov    0xb90(%r11),%rax
 1f7f4e6:	vmovdqu %xmm7,(%rax,%r15,1)
 1f7f4ec:	mov    0xb98(%r11),%rax
 1f7f4f3:	vmovdqu %xmm6,(%rax,%r15,1)
 1f7f4f9:	mov    0xba0(%r11),%rax
 1f7f500:	vmovdqu %xmm3,(%rax,%r15,1)
 1f7f506:	mov    0xba8(%r11),%rax
 1f7f50d:	vmovdqu %xmm4,(%rax,%r15,1)
 1f7f513:	mov    0xc28(%r11),%rax
 1f7f51a:	vmovdqu64 %zmm5,(%rax,%r15,4)
 1f7f521:	mov    0xcd8(%r11),%rax
 1f7f528:	vmovdqu64 %zmm0,(%rax,%r15,8)
 1f7f52f:	mov    0xcd8(%r11),%rax
 1f7f536:	vmovdqu64 %zmm1,0x40(%rax,%r15,8)
 1f7f53e:	add    $0x10,%r15
 1f7f542:	cmp    %r14,%r15
 1f7f545:	jae    1f80915 <node_facts_window_run+0x3445>
 1f7f54b:	vpxor  %xmm4,%xmm4,%xmm4
 1f7f54f:	cmp    %r8,%r15
 1f7f552:	jae    1f7f490 <node_facts_window_run+0x1fc0>
 1f7f558:	mov    %r8d,%eax
 1f7f55b:	sub    %r15d,%eax
 1f7f55e:	mov    $0x10,%ecx
 1f7f563:	mov    $0xffffffff,%edx
 1f7f568:	mov    %r15,%rbp
 1f7f56b:	vpxor  %xmm12,%xmm12,%xmm12
 1f7f570:	cmp    $0x10,%eax
 1f7f573:	cmovae %ecx,%eax
 1f7f576:	mov    0x9b8(%r11),%rcx
 1f7f57d:	shl    $0x6,%rbp
 1f7f581:	shlx   %eax,%edx,%eax
 1f7f586:	vmovdqu (%r9,%rbp,1),%ymm4
 1f7f58c:	vmovdqu64 0x40(%r9,%rbp,1),%ymm26
 1f7f594:	vmovdqu64 0x80(%r9,%rbp,1),%ymm27
 1f7f59c:	vmovdqu64 0xc0(%r9,%rbp,1),%ymm28
 1f7f5a4:	vmovdqu 0x100(%r9,%rbp,1),%ymm5
 1f7f5ae:	vmovdqu 0x140(%r9,%rbp,1),%ymm6
 1f7f5b8:	vmovdqu64 0x180(%r9,%rbp,1),%ymm24
 1f7f5c0:	vmovdqu64 0x1c0(%r9,%rbp,1),%ymm25
 1f7f5c8:	vmovdqu 0x200(%r9,%rbp,1),%ymm7
 1f7f5d2:	vmovdqu64 0x240(%r9,%rbp,1),%ymm18
 1f7f5da:	vmovdqu64 0x280(%r9,%rbp,1),%ymm22
 1f7f5e2:	vmovdqu64 0x2c0(%r9,%rbp,1),%ymm23
 1f7f5ea:	vmovdqu 0x300(%r9,%rbp,1),%ymm11
 1f7f5f4:	vmovdqu64 0x340(%r9,%rbp,1),%ymm19
 1f7f5fc:	vmovdqu64 0x380(%r9,%rbp,1),%ymm20
 1f7f604:	vmovdqu64 0x3c0(%r9,%rbp,1),%ymm21
 1f7f60c:	not    %eax
 1f7f60e:	kmovd  %eax,%k1
 1f7f612:	mov    0xc48(%rdi),%rax
 1f7f619:	vmovdqu8 (%rcx,%r15,1),%xmm0{%k1}{z}
 1f7f620:	mov    0xb0(%rsp),%rcx
 1f7f628:	vmovdqu8 (%rcx,%r15,1),%xmm10{%k1}{z}
 1f7f62f:	vptestmb %xmm0,%xmm0,%k6
 1f7f635:	vpcmpeqb -0x19b792f(%rip),%xmm10,%k7{%k6}        # 5c7d10 <.LCPI3_10>
 1f7f63f:	vmovdqu32 (%r12,%r15,4),%zmm0{%k7}{z}
 1f7f646:	kmovq  %k7,%k1
 1f7f64b:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7f652:	vptestnmd %zmm16,%zmm12,%k0
 1f7f658:	ktestw %k0,%k7
 1f7f65c:	jne    1f7fd8f <node_facts_window_run+0x28bf>
 1f7f662:	vpmovsxbd -0x19ae6f3(%rip),%xmm3        # 5d0f78 <.LCPI3_74>
 1f7f66b:	vmovdqa64 -0x1ac8f35(%rip),%zmm8        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f7f675:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7f67c:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7f683:	vptestmd -0x19ae74d(%rip){1to16},%zmm12,%k0        # 5d0f40 <.LCPI3_12>
 1f7f68d:	vmovdqa64 %zmm0,%zmm2
 1f7f693:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7f699:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7f69f:	vmovdqa64 %zmm3,%zmm9
 1f7f6a5:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7f6ab:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7f6b1:	kmovd  %k0,%r13d
 1f7f6b5:	vptestmd %zmm17,%zmm12,%k0
 1f7f6bb:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7f6c1:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7f6c8:	vmovdqu64 %zmm1,0x230(%rsp)
 1f7f6d3:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7f6da:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7f6de:	vmovdqa64 %zmm1,%zmm4
 1f7f6e4:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7f6ea:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7f6f0:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7f6f6:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7f6fc:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7f703:	vmovdqu %ymm3,0x1f0(%rsp)
 1f7f70c:	vinserti64x4 $0x1,%ymm18,%zmm7,%zmm3
 1f7f713:	vpunpcklqdq %ymm18,%ymm7,%ymm7
 1f7f719:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm18
 1f7f720:	vmovdqa64 %zmm3,%zmm6
 1f7f726:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7f72c:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7f732:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7f738:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7f73e:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7f744:	vmovdqa64 %zmm18,%zmm7
 1f7f74a:	vmovdqu64 %zmm5,0x270(%rsp)
 1f7f755:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7f75c:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7f762:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7f769:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7f770:	vpermt2d %zmm5,%zmm9,%zmm18
 1f7f776:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7f77c:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7f783:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7f789:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7f78f:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7f796:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7f79d:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm21{%k6}{z}
 1f7f7a4:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7f7ab:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm20{%k6}{z}
 1f7f7b2:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7f7b9:	vpsrld $0x19,%zmm21,%zmm0
 1f7f7c0:	vpandd -0x19ae89a(%rip){1to16},%zmm0,%zmm0        # 5d0f30 <.LCPI3_4>
 1f7f7ca:	vpsrld $0x18,%zmm21,%zmm1
 1f7f7d1:	vpsrld $0x1a,%zmm21,%zmm7
 1f7f7d8:	vpternlogd $0xec,%zmm13,%zmm0,%zmm1
 1f7f7df:	vpandd -0x19ae86d(%rip){1to16},%zmm21,%zmm0        # 5d0f7c <.LCPI3_75>
 1f7f7e9:	vpmovdb %zmm1,%xmm19
 1f7f7ef:	vpsrld $0xc,%zmm20,%zmm1
 1f7f7f6:	vpmovdb %zmm1,%xmm24
 1f7f7fc:	vpcmpeqd -0x19ae8ce(%rip){1to16},%zmm0,%k1{%k6}        # 5d0f38 <.LCPI3_7>
 1f7f806:	vporq  %xmm14,%xmm19,%xmm0
 1f7f80c:	vmovdqu8 %xmm0,%xmm19{%k1}
 1f7f812:	vpcmpeqb %xmm14,%xmm10,%k1{%k6}
 1f7f818:	vpternlogq $0xf8,%xmm15,%xmm24,%xmm19
 1f7f81f:	kmovd  %k1,%eax
 1f7f823:	kmovw  %k1,0x50(%rsp)
 1f7f829:	korw   %k0,%k1,%k1
 1f7f82d:	kmovw  %k1,0x1b0(%rsp)
 1f7f836:	test   %ax,%ax
 1f7f839:	je     1f7f9f1 <node_facts_window_run+0x2521>
 1f7f83f:	vmovdqu64 %zmm4,0x6c0(%rsp)
 1f7f847:	vmovdqu %ymm5,0x5d0(%rsp)
 1f7f850:	vmovdqu64 %zmm7,0x4b0(%rsp)
 1f7f85b:	vmovdqa64 %xmm24,0x610(%rsp)
 1f7f863:	vmovdqu64 %zmm23,0x650(%rsp)
 1f7f86e:	vmovdqu64 %zmm22,0x570(%rsp)
 1f7f879:	vmovdqu64 %zmm21,0x3f0(%rsp)
 1f7f884:	vmovdqu64 %zmm18,0x4f0(%rsp)
 1f7f88f:	vmovdqu64 %zmm20,0x430(%rsp)
 1f7f89a:	vmovdqu64 %zmm12,0x530(%rsp)
 1f7f8a5:	vmovdqa64 %xmm19,0x2b0(%rsp)
 1f7f8ad:	kmovw  %k7,0x3b0(%rsp)
 1f7f8b6:	mov    %rbp,0x370(%rsp)
 1f7f8be:	kmovd  %k6,0x2f0(%rsp)
 1f7f8c8:	movzwl %ax,%r14d
 1f7f8cc:	movzwl %r13w,%r13d
 1f7f8d0:	xor    %ebp,%ebp
 1f7f8d2:	mov    0x98(%rsp),%rax
 1f7f8da:	lea    (%rax,%r15,4),%rbx
 1f7f8de:	xchg   %ax,%ax
 1f7f8e0:	xor    %r12d,%r12d
 1f7f8e3:	tzcnt  %r14d,%r12d
 1f7f8e8:	xor    %edx,%edx
 1f7f8ea:	mov    (%rbx,%r12,4),%esi
 1f7f8ee:	vzeroupper
 1f7f8f1:	call   1f93a70 <node_tests_window_line>
 1f7f8f6:	mov    0x18(%rsp),%rdi
 1f7f8fb:	mov    $0x1,%ecx
 1f7f900:	test   $0x2,%al
 1f7f902:	shlx   %r12d,%ecx,%eax
 1f7f907:	cmove  %ebp,%eax
 1f7f90a:	or     %eax,%r13d
 1f7f90d:	blsr   %r14d,%r14d
 1f7f912:	jne    1f7f8e0 <node_facts_window_run+0x2410>
 1f7f914:	vpbroadcastd -0x19ae9ea(%rip),%zmm13        # 5d0f34 <.LCPI3_5>
 1f7f91e:	vpbroadcastb -0x1ac8be7(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7f927:	vpbroadcastb -0x1ac8bef(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7f930:	vpbroadcastd -0x19ae9fe(%rip),%zmm16        # 5d0f3c <.LCPI3_11>
 1f7f93a:	vpbroadcastd -0x19aea00(%rip),%zmm17        # 5d0f44 <.LCPI3_13>
 1f7f944:	vmovdqa64 0x2b0(%rsp),%xmm19
 1f7f94c:	vmovdqu64 0x530(%rsp),%zmm12
 1f7f957:	vmovdqu64 0x430(%rsp),%zmm20
 1f7f962:	vmovdqu64 0x4f0(%rsp),%zmm18
 1f7f96d:	vmovdqu64 0x3f0(%rsp),%zmm21
 1f7f978:	vmovdqu64 0x570(%rsp),%zmm22
 1f7f983:	vmovdqu64 0x650(%rsp),%zmm23
 1f7f98e:	vmovdqa64 0x610(%rsp),%xmm24
 1f7f996:	vmovdqu64 0x4b0(%rsp),%zmm7
 1f7f9a1:	vmovdqu 0x5d0(%rsp),%ymm5
 1f7f9aa:	vmovdqu64 0x6c0(%rsp),%zmm4
 1f7f9b2:	mov    0x8(%rsp),%r11
 1f7f9b7:	mov    0x38(%rsp),%rsi
 1f7f9bc:	mov    0x30(%rsp),%r12
 1f7f9c1:	mov    0x150(%rsp),%r8
 1f7f9c9:	mov    0x20(%rsp),%r9
 1f7f9ce:	mov    0xa8(%rsp),%r14
 1f7f9d6:	kmovd  0x2f0(%rsp),%k6
 1f7f9e0:	mov    0x370(%rsp),%rbp
 1f7f9e8:	kmovw  0x3b0(%rsp),%k7
 1f7f9f1:	vpsrld $0x2,%zmm20,%zmm0
 1f7f9f8:	vpandd -0x19aeaba(%rip){1to16},%zmm0,%zmm2        # 5d0f48 <.LCPI3_14>
 1f7fa02:	vpbroadcastd -0x19aeac0(%rip),%zmm0        # 5d0f4c <.LCPI3_15>
 1f7fa0c:	vptestmd -0x19aeac6(%rip){1to16},%zmm20,%k3        # 5d0f50 <.LCPI3_16>
 1f7fa16:	vmovdqu64 0x270(%rsp),%zmm1
 1f7fa21:	vptestnmd %zmm4,%zmm4,%k1
 1f7fa27:	vpbroadcastd -0x19aead5(%rip),%zmm6        # 5d0f5c <.LCPI3_21>
 1f7fa31:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7fa38:	kmovd  %r13d,%k4
 1f7fa3d:	vpsrld $0x10,%zmm20,%zmm9
 1f7fa44:	vpbroadcastb -0x1ac8d0b(%rip),%xmm8        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f7fa4d:	vpbroadcastb -0x1ac8d13(%rip),%xmm11        # 4b6d43 <abi_test_hex.digits+0xb9c3>
 1f7fa56:	kmovw  %k1,%eax
 1f7fa5a:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7fa60:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7fa67:	vmovdqu64 0x230(%rsp),%zmm0
 1f7fa72:	korw   %k1,%k3,%k3
 1f7fa76:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7fa7d:	vpandd -0x19aeb07(%rip){1to16},%zmm21,%zmm5        # 5d0f80 <.LCPI3_78>
 1f7fa87:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7fa8d:	vpbroadcastb -0x1ac8d52(%rip),%xmm7        # 4b6d44 <abi_test_hex.digits+0xb9c4>
 1f7fa96:	vinserti64x4 $0x1,0x1f0(%rsp),%zmm0,%zmm0
 1f7faa2:	kmovw  %k0,%ecx
 1f7faa6:	korw   %k2,%k3,%k2
 1f7faaa:	vpaddd -0x19aeb5c(%rip){1to16},%zmm5,%zmm5        # 5d0f58 <.LCPI3_20>
 1f7fab4:	andn   %ecx,%eax,%eax
 1f7fab9:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7fabf:	kmovd  %eax,%k3
 1f7fac3:	shr    $0x8,%eax
 1f7fac6:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7facc:	kmovd  %eax,%k3
 1f7fad0:	vmovdqu8 %xmm14,%xmm4{%k2}{z}
 1f7fad6:	vpcmpltud %zmm6,%zmm5,%k2
 1f7fadd:	vpslld $0x1f,%zmm5,%zmm5
 1f7fae4:	vpxor  %xmm6,%xmm6,%xmm6
 1f7fae8:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7faee:	vptestmd -0x19aeba4(%rip){1to16},%zmm23,%k3        # 5d0f54 <.LCPI3_17>
 1f7faf8:	vpandd %zmm17,%zmm23,%zmm3
 1f7fafe:	vptestnmd %zmm3,%zmm3,%k0
 1f7fb04:	kandd  %k6,%k0,%k0
 1f7fb09:	korw   %k3,%k4,%k3
 1f7fb0d:	kandd  %k2,%k0,%k4
 1f7fb12:	vpcmpeqd %zmm16,%zmm2,%k2{%k4}
 1f7fb18:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7fb1e:	vmovdqu8 -0x19b7de8(%rip),%xmm2{%k4}        # 5c7d40 <.LCPI3_25>
 1f7fb28:	knotw  %k2,%k0
 1f7fb2c:	kandd  %k0,%k4,%k5
 1f7fb31:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7fb37:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7fb3e:	vpaddd %zmm5,%zmm9,%zmm10
 1f7fb44:	vpbroadcastb -0x1ac8e08(%rip),%xmm5        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f7fb4d:	vmovdqu8 -0x19b7e07(%rip),%xmm2{%k4}        # 5c7d50 <.LCPI3_26>
 1f7fb57:	vptestnmd %zmm10,%zmm10,%k4
 1f7fb5d:	vpblendmb -0x19b7df7(%rip),%xmm5,%xmm5{%k4}        # 5c7d70 <.LCPI3_28>
 1f7fb67:	vpcmpnleud -0x19aec12(%rip){1to16},%zmm10,%k4        # 5d0f60 <.LCPI3_22>
 1f7fb72:	cmpb   $0x0,0xc90(%rdi)
 1f7fb79:	vmovdqu8 -0x19b7e03(%rip),%xmm5{%k4}        # 5c7d80 <.LCPI3_29>
 1f7fb83:	vpcmpnleud -0x19aec2a(%rip){1to16},%zmm10,%k4        # 5d0f64 <.LCPI3_23>
 1f7fb8e:	vmovdqu8 -0x19b7e08(%rip),%xmm5{%k4}        # 5c7d90 <.LCPI3_30>
 1f7fb98:	vptestmd %zmm3,%zmm3,%k4
 1f7fb9e:	vpor   %xmm4,%xmm8,%xmm3
 1f7fba2:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7fba8:	kmovw  0x1b0(%rsp),%k4
 1f7fbb1:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7fbb7:	vpor   %xmm2,%xmm4,%xmm2
 1f7fbbb:	vpord  -0x19aec41(%rip){1to4},%xmm2,%xmm3        # 5d0f84 <.LCPI3_81>
 1f7fbc5:	vpbroadcastb -0x1ac8e88(%rip),%xmm5        # 4b6d46 <abi_test_hex.digits+0xb9c6>
 1f7fbce:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7fbd4:	vpor   %xmm5,%xmm2,%xmm3
 1f7fbd8:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7fbde:	vpmovdb %zmm20,%xmm3
 1f7fbe4:	kmovw  0x50(%rsp),%k3
 1f7fbea:	vpor   %xmm3,%xmm11,%xmm4
 1f7fbee:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7fbf4:	vptestmd -0x19aec96(%rip){1to16},%zmm12,%k3{%k7}        # 5d0f68 <.LCPI3_32>
 1f7fbfe:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7fc04:	vpor   %xmm5,%xmm4,%xmm6
 1f7fc08:	vpsrld $0xb,%zmm23,%zmm7
 1f7fc0f:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7fc15:	vpandd -0x19aec97(%rip){1to4},%xmm24,%xmm4        # 5d0f88 <.LCPI3_83>
 1f7fc1f:	vptestmd -0x19aecbd(%rip){1to16},%zmm23,%k1        # 5d0f6c <.LCPI3_33>
 1f7fc29:	vpmovdb %zmm7,%xmm7
 1f7fc2f:	vpand  %xmm7,%xmm8,%xmm7
 1f7fc33:	vpmovdb %zmm21,%xmm8
 1f7fc39:	vpor   %xmm4,%xmm15,%xmm5
 1f7fc3d:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7fc43:	vpmovdb %zmm23,%xmm5
 1f7fc49:	vgf2p8affineqb $0x0,-0x19b16fc(%rip){1to2},%xmm5,%xmm5        # 5ce558 <.LCPI3_84>
 1f7fc54:	vpternlogq $0xf8,%xmm11,%xmm5,%xmm4
 1f7fc5b:	vpsrld $0x8,%zmm21,%zmm11
 1f7fc62:	vpor   %xmm4,%xmm14,%xmm5
 1f7fc66:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7fc6c:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7fc73:	vpsrld $0x10,%zmm21,%zmm6
 1f7fc7a:	vpmovdb %zmm11,%xmm7
 1f7fc80:	vinserti32x4 $0x3,%xmm18,%zmm22,%zmm5{%k6}{z}
 1f7fc87:	vpmovdb %zmm6,%xmm6
 1f7fc8d:	je     1f7fd85 <node_facts_window_run+0x28b5>
 1f7fc93:	vmovdqa64 -0x1ac949d(%rip),%zmm18        # 4b6800 <abi_test_hex.digits+0xb480>
 1f7fc9d:	vptestmd %zmm9,%zmm9,%k1{%k2}
 1f7fca3:	add    %r9,%rbp
 1f7fca6:	vpxor  %xmm11,%xmm11,%xmm11
 1f7fcab:	vpxor  %xmm12,%xmm12,%xmm12
 1f7fcb0:	vpcmpneqd -0x19aed4b(%rip){1to16},%zmm9,%k0{%k1}        # 5d0f70 <.LCPI3_38>
 1f7fcbb:	vmovdqa %xmm6,%xmm9
 1f7fcbf:	vpternlogq $0xfe,%xmm8,%xmm3,%xmm9
 1f7fcc6:	kmovq  %k1,%k2
 1f7fccb:	kmovw  %k1,%eax
 1f7fccf:	popcnt %eax,%ecx
 1f7fcd3:	vpgatherdd 0x10(%rbp,%zmm18,1),%zmm11{%k2}
 1f7fcdb:	kmovq  %k1,%k2
 1f7fce0:	vpcmpnleud -0x19aed77(%rip){1to16},%zmm11,%k3        # 5d0f74 <.LCPI3_39>
 1f7fceb:	vpgatherdd 0x14(%rbp,%zmm18,1),%zmm12{%k2}
 1f7fcf3:	add    %rcx,0x110(%rsp)
 1f7fcfb:	mov    0x10(%rsp),%r10
 1f7fd00:	vpcmpeqd %zmm10,%zmm11,%k2
 1f7fd06:	vmovdqa64 %xmm19,%xmm10
 1f7fd0c:	vpternlogq $0xfe,%xmm7,%xmm9,%xmm10
 1f7fd13:	vptestnmd %zmm12,%zmm12,%k2{%k2}
 1f7fd19:	vptestmd %zmm12,%zmm12,%k4
 1f7fd1f:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm10
 1f7fd26:	korw   %k4,%k3,%k3
 1f7fd2a:	kandw  %k2,%k0,%k2
 1f7fd2e:	knotw  %k0,%k0
 1f7fd32:	kandd  %k1,%k0,%k0
 1f7fd37:	kandw  %k0,%k3,%k0
 1f7fd3b:	korw   %k0,%k2,%k2
 1f7fd3f:	vptestnmd %zmm13,%zmm20,%k0{%k2}
 1f7fd45:	kandw  %k0,%k1,%k0
 1f7fd49:	knotd  %k6,%k1
 1f7fd4e:	kmovd  %k0,%ecx
 1f7fd52:	vptestmb %xmm10,%xmm10,%k0{%k1}
 1f7fd58:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7fd5e:	andn   %eax,%ecx,%eax
 1f7fd63:	popcnt %eax,%eax
 1f7fd67:	kmovw  %k0,%ecx
 1f7fd6b:	popcnt %ecx,%ecx
 1f7fd6f:	kmovw  %k1,%edx
 1f7fd73:	popcnt %edx,%edx
 1f7fd77:	add    %rdx,%r10
 1f7fd7a:	add    %rax,%r10
 1f7fd7d:	add    %rcx,%r10
 1f7fd80:	mov    %r10,0x10(%rsp)
 1f7fd85:	mov    0x28(%rsp),%r13
 1f7fd8a:	jmp    1f7f4b7 <node_facts_window_run+0x1fe7>
 1f7fd8f:	kandw  %k0,%k7,%k0
 1f7fd93:	vmovdqa %xmm10,0x270(%rsp)
 1f7fd9c:	vmovdqu64 %zmm11,0x370(%rsp)
 1f7fda7:	vmovdqu64 %ymm19,0x2b0(%rsp)
 1f7fdb2:	vmovdqu64 %zmm20,0x530(%rsp)
 1f7fdbd:	vmovdqu64 %ymm21,0x430(%rsp)
 1f7fdc8:	vmovdqu64 %zmm7,0x4f0(%rsp)
 1f7fdd3:	vmovdqu64 %ymm18,0x3f0(%rsp)
 1f7fdde:	vmovdqu64 %zmm22,0x570(%rsp)
 1f7fde9:	vmovdqu64 %ymm23,0x650(%rsp)
 1f7fdf4:	vmovdqu64 %zmm5,0x610(%rsp)
 1f7fdff:	vmovdqu %ymm6,0x4b0(%rsp)
 1f7fe08:	vmovdqu64 %zmm24,0x5d0(%rsp)
 1f7fe13:	vmovdqu64 %ymm25,0x6c0(%rsp)
 1f7fe1b:	vmovdqu64 %zmm4,0x780(%rsp)
 1f7fe23:	vmovdqu64 %ymm26,0x490(%rsp)
 1f7fe2e:	vmovdqu64 %zmm27,0x740(%rsp)
 1f7fe36:	vmovdqu64 %ymm28,0x470(%rsp)
 1f7fe41:	vmovdqu64 %zmm0,0x820(%rsp)
 1f7fe4c:	kmovd  %k6,0x2f0(%rsp)
 1f7fe56:	kmovw  %k7,0x3b0(%rsp)
 1f7fe5f:	kmovd  %k0,%eax
 1f7fe63:	movzwl %ax,%eax
 1f7fe66:	jmp    1f80015 <node_facts_window_run+0x2b45>
 1f7fe6b:	mov    0x40(%rsp),%rsi
 1f7fe70:	mov    (%r12,%r13,4),%r9d
 1f7fe74:	mov    0xc48(%rdi),%rdx
 1f7fe7b:	shl    $0x6,%rax
 1f7fe7f:	mov    %r8b,0x1f0(%rsp)
 1f7fe87:	mov    0x20(%r11),%rcx
 1f7fe8b:	cmpb   $0x1,(%rdx,%r9,1)
 1f7fe90:	mov    %r9,0x230(%rsp)
 1f7fe98:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7fe9d:	adc    $0x0,%rsi
 1f7fea1:	and    $0x1,%edx
 1f7fea4:	mov    %rsi,0x40(%rsp)
 1f7fea9:	mov    0x98(%rsp),%rbx
 1f7feb1:	mov    (%rbx,%r13,4),%esi
 1f7feb5:	vzeroupper
 1f7feb8:	call   1f93a70 <node_tests_window_line>
 1f7febd:	mov    %al,0x1b0(%rsp)
 1f7fec4:	mov    (%rbx,%r13,4),%esi
 1f7fec8:	mov    0x18(%rsp),%rdi
 1f7fecd:	call   1f93bc0 <node_tests_window_returns>
 1f7fed2:	mov    0x18(%rsp),%rdi
 1f7fed7:	or     0x1f0(%rsp),%al
 1f7fede:	mov    0x230(%rsp),%rdx
 1f7fee6:	vpbroadcastd -0x19aefbc(%rip),%zmm13        # 5d0f34 <.LCPI3_5>
 1f7fef0:	vpbroadcastb -0x1ac91b9(%rip),%xmm14        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f7fef9:	vpbroadcastb -0x1ac91c1(%rip),%xmm15        # 4b6d41 <abi_test_hex.digits+0xb9c1>
 1f7ff02:	vpbroadcastd -0x19aefd0(%rip),%zmm16        # 5d0f3c <.LCPI3_11>
 1f7ff0c:	vpbroadcastd -0x19aefd2(%rip),%zmm17        # 5d0f44 <.LCPI3_13>
 1f7ff16:	vmovdqa 0x270(%rsp),%xmm10
 1f7ff1f:	vmovdqu64 0x370(%rsp),%zmm11
 1f7ff2a:	vmovdqu64 0x2b0(%rsp),%ymm19
 1f7ff35:	vmovdqu64 0x530(%rsp),%zmm20
 1f7ff40:	vmovdqu64 0x430(%rsp),%ymm21
 1f7ff4b:	vmovdqu64 0x4f0(%rsp),%zmm7
 1f7ff56:	vmovdqu64 0x3f0(%rsp),%ymm18
 1f7ff61:	vmovdqu64 0x570(%rsp),%zmm22
 1f7ff6c:	vmovdqu64 0x650(%rsp),%ymm23
 1f7ff77:	vmovdqu64 0x610(%rsp),%zmm5
 1f7ff82:	vmovdqu 0x4b0(%rsp),%ymm6
 1f7ff8b:	vmovdqu64 0x5d0(%rsp),%zmm24
 1f7ff96:	vmovdqu64 0x6c0(%rsp),%ymm25
 1f7ff9e:	vmovdqu64 0x780(%rsp),%zmm4
 1f7ffa6:	vmovdqu64 0x490(%rsp),%ymm26
 1f7ffb1:	vmovdqu64 0x740(%rsp),%zmm27
 1f7ffb9:	vmovdqu64 0x470(%rsp),%ymm28
 1f7ffc4:	vmovdqu64 0x820(%rsp),%zmm0
 1f7ffcf:	mov    0x8(%rsp),%r11
 1f7ffd4:	mov    0x38(%rsp),%rsi
 1f7ffd9:	mov    0x150(%rsp),%r8
 1f7ffe1:	mov    0x20(%rsp),%r9
 1f7ffe6:	kmovd  0x2f0(%rsp),%k6
 1f7fff0:	kmovw  0x3b0(%rsp),%k7
 1f7fff9:	or     0x1b0(%rsp),%al
 1f80000:	mov    0xc48(%rdi),%rcx
 1f80007:	mov    %al,(%rcx,%rdx,1)
 1f8000a:	mov    0x50(%rsp),%eax
 1f8000e:	blsr   %eax,%eax
 1f80013:	je     1f80085 <node_facts_window_run+0x2bb5>
 1f80015:	tzcnt  %eax,%r13d
 1f8001a:	mov    %eax,0x50(%rsp)
 1f8001e:	mov    0x60(%r11),%edx
 1f80022:	mov    $0x1,%r8b
 1f80025:	add    %r15,%r13
 1f80028:	mov    %r13,%rcx
 1f8002b:	shl    $0x6,%rcx
 1f8002f:	mov    (%r9,%rcx,1),%eax
 1f80033:	mov    0xc(%r9,%rcx,1),%ecx
 1f80038:	shr    $0x3,%eax
 1f8003b:	cmp    %edx,%eax
 1f8003d:	cmovae %edx,%eax
 1f80040:	test   %rcx,%rcx
 1f80043:	je     1f7fe6b <node_facts_window_run+0x299b>
 1f80049:	mov    0x90(%rsp),%rdx
 1f80051:	mov    0x40(%rsp),%rsi
 1f80056:	cmp    0x3b8(%rdx),%ecx
 1f8005c:	jae    1f7fe70 <node_facts_window_run+0x29a0>
 1f80062:	mov    0x90(%rsp),%rdx
 1f8006a:	mov    0x3a8(%rdx),%rdx
 1f80071:	cmpl   $0x0,(%rdx,%rcx,4)
 1f80075:	setne  %r8b
 1f80079:	shl    $0x5,%r8b
 1f8007d:	inc    %r8b
 1f80080:	jmp    1f7fe70 <node_facts_window_run+0x29a0>
 1f80085:	mov    0xc48(%rdi),%rax
 1f8008c:	kmovq  %k7,%k1
 1f80091:	vpxor  %xmm12,%xmm12,%xmm12
 1f80096:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f8009d:	jmp    1f7f662 <node_facts_window_run+0x2192>
 1f800a2:	test   %eax,%eax
 1f800a4:	je     1f808f7 <node_facts_window_run+0x3427>
 1f800aa:	vpbroadcastd -0x19af180(%rip),%zmm6        # 5d0f34 <.LCPI3_5>
 1f800b4:	vpbroadcastb -0x1ac937b(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f800bd:	vpbroadcastd -0x19af18b(%rip),%zmm8        # 5d0f3c <.LCPI3_11>
 1f800c7:	vpbroadcastd -0x19af18d(%rip),%zmm9        # 5d0f44 <.LCPI3_13>
 1f800d1:	lea    0x69454(%r13),%rcx
 1f800d8:	lea    0x422c(%r13),%r14
 1f800df:	mov    %eax,%r10d
 1f800e2:	xor    %r15d,%r15d
 1f800e5:	mov    %rcx,0x530(%rsp)
 1f800ed:	movq   $0x0,0x40(%rsp)
 1f800f6:	movq   $0x0,0x110(%rsp)
 1f80102:	movq   $0x0,0x10(%rsp)
 1f8010b:	mov    %r10,0x430(%rsp)
 1f80113:	mov    %r14,0x4f0(%rsp)
 1f8011b:	jmp    1f8014c <node_facts_window_run+0x2c7c>
 1f8011d:	nopl   (%rax)
 1f80120:	vpxor  %xmm11,%xmm11,%xmm11
 1f80125:	mov    0xc10(%rdi),%rax
 1f8012c:	vmovdqu %xmm11,(%rax,%r15,1)
 1f80132:	mov    0xc18(%rdi),%rax
 1f80139:	vmovdqu %xmm0,(%rax,%r15,1)
 1f8013f:	add    $0x10,%r15
 1f80143:	cmp    %r10,%r15
 1f80146:	jae    1f80915 <node_facts_window_run+0x3445>
 1f8014c:	vpxor  %xmm0,%xmm0,%xmm0
 1f80150:	cmp    %r8,%r15
 1f80153:	jae    1f80120 <node_facts_window_run+0x2c50>
 1f80155:	mov    %r8d,%eax
 1f80158:	sub    %r15d,%eax
 1f8015b:	mov    $0x10,%ecx
 1f80160:	mov    $0xffffffff,%edx
 1f80165:	mov    %r15,%rbp
 1f80168:	cmp    $0x10,%eax
 1f8016b:	cmovae %ecx,%eax
 1f8016e:	mov    0x9b8(%r11),%rcx
 1f80175:	shl    $0x6,%rbp
 1f80179:	shlx   %eax,%edx,%eax
 1f8017e:	vmovdqu 0x100(%r9,%rbp,1),%ymm2
 1f80188:	vmovdqu 0x180(%r9,%rbp,1),%ymm3
 1f80192:	vmovdqu (%r9,%rbp,1),%ymm0
 1f80198:	vmovdqu 0x80(%r9,%rbp,1),%ymm1
 1f801a2:	not    %eax
 1f801a4:	vinserti64x4 $0x1,0x140(%r9,%rbp,1),%zmm2,%zmm5
 1f801ad:	vinserti64x4 $0x1,0x1c0(%r9,%rbp,1),%zmm3,%zmm2
 1f801b6:	vinserti64x4 $0x1,0x40(%r9,%rbp,1),%zmm0,%zmm4
 1f801bf:	vmovdqu 0x200(%r9,%rbp,1),%ymm0
 1f801c9:	vinserti64x4 $0x1,0xc0(%r9,%rbp,1),%zmm1,%zmm12
 1f801d2:	kmovd  %eax,%k1
 1f801d6:	vinserti64x4 $0x1,0x240(%r9,%rbp,1),%zmm0,%zmm11
 1f801df:	vmovdqu 0x280(%r9,%rbp,1),%ymm0
 1f801e9:	mov    0xc48(%rdi),%rax
 1f801f0:	vinserti64x4 $0x1,0x2c0(%r9,%rbp,1),%zmm0,%zmm14
 1f801f9:	vmovdqu 0x300(%r9,%rbp,1),%ymm0
 1f80203:	vmovdqu8 (%rcx,%r15,1),%xmm10{%k1}{z}
 1f8020a:	mov    0x530(%rsp),%rcx
 1f80212:	vinserti64x4 $0x1,0x340(%r9,%rbp,1),%zmm0,%zmm13
 1f8021b:	vmovdqu 0x380(%r9,%rbp,1),%ymm0
 1f80225:	vinserti64x4 $0x1,0x3c0(%r9,%rbp,1),%zmm0,%zmm15
 1f8022e:	vmovdqu8 (%rcx,%r15,1),%xmm3{%k1}{z}
 1f80235:	vptestmb %xmm10,%xmm10,%k2
 1f8023b:	vpxor  %xmm0,%xmm0,%xmm0
 1f8023f:	vpcmpeqb %xmm7,%xmm3,%k3{%k2}
 1f80245:	vmovdqu32 (%r12,%r15,4),%zmm1{%k3}{z}
 1f8024c:	kmovq  %k3,%k1
 1f80251:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f80258:	vptestnmd %zmm8,%zmm0,%k0
 1f8025e:	ktestw %k0,%k3
 1f80262:	jne    1f80707 <node_facts_window_run+0x3237>
 1f80268:	vmovdqa64 -0x1ac9b32(%rip),%zmm1        # 4b6740 <abi_test_hex.digits+0xb3c0>
 1f80272:	kmovd  %k2,%edx
 1f80276:	vpermt2d %zmm12,%zmm1,%zmm4
 1f8027c:	vpermt2d %zmm2,%zmm1,%zmm5
 1f80282:	vpermt2d %zmm14,%zmm1,%zmm11
 1f80288:	vpermt2d %zmm15,%zmm1,%zmm13
 1f8028e:	vshufi64x2 $0x44,%zmm13,%zmm11,%zmm2
 1f80295:	vshufi64x2 $0x44,%zmm5,%zmm4,%zmm1
 1f8029c:	vshufi64x2 $0xee,%zmm5,%zmm4,%zmm14
 1f802a3:	vshufi64x2 $0xee,%zmm13,%zmm11,%zmm13
 1f802aa:	vshufi32x4 $0x88,%zmm2,%zmm1,%zmm4{%k2}{z}
 1f802b1:	vshufi32x4 $0xdd,%zmm2,%zmm1,%zmm5{%k2}{z}
 1f802b8:	vshufi32x4 $0xdd,%zmm13,%zmm14,%zmm12{%k2}{z}
 1f802bf:	vpsrld $0x19,%zmm4,%zmm1
 1f802c6:	vpandd -0x19af3a0(%rip){1to16},%zmm1,%zmm1        # 5d0f30 <.LCPI3_4>
 1f802d0:	vpsrld $0x18,%zmm4,%zmm2
 1f802d7:	vpternlogd $0xec,%zmm6,%zmm1,%zmm2
 1f802de:	vpandd -0x19af36c(%rip){1to16},%zmm4,%zmm1        # 5d0f7c <.LCPI3_75>
 1f802e8:	vpmovdb %zmm2,%xmm11
 1f802ee:	vpbroadcastb -0x1ac95b7(%rip),%xmm2        # 4b6d40 <abi_test_hex.digits+0xb9c0>
 1f802f7:	vpcmpeqd -0x19af3c9(%rip){1to16},%zmm1,%k1{%k2}        # 5d0f38 <.LCPI3_7>
 1f80301:	vpor   %xmm2,%xmm11,%xmm1
 1f80305:	vpcmpeqb %xmm2,%xmm3,%k0{%k2}
 1f8030b:	kmovd  %k0,%eax
 1f8030f:	vmovdqu8 %xmm1,%xmm11{%k1}
 1f80315:	vptestmd %zmm9,%zmm0,%k1
 1f8031b:	korw   %k1,%k0,%k5
 1f8031f:	vptestmd -0x19af3e9(%rip){1to16},%zmm0,%k0        # 5d0f40 <.LCPI3_12>
 1f80329:	kmovd  %k0,%r13d
 1f8032d:	test   %ax,%ax
 1f80330:	je     1f8047f <node_facts_window_run+0x2faf>
 1f80336:	lea    (%r14,%r15,4),%r14
 1f8033a:	movzwl %r13w,%r13d
 1f8033e:	movzwl %ax,%ebx
 1f80341:	vmovdqu64 %zmm13,0x2b0(%rsp)
 1f8034c:	vmovdqu64 %zmm14,0x370(%rsp)
 1f80357:	vmovdqu64 %zmm5,0x3b0(%rsp)
 1f80362:	vmovdqu64 %zmm4,0x2f0(%rsp)
 1f8036d:	kmovw  %k5,0x270(%rsp)
 1f80376:	vmovdqu64 %zmm12,0x1f0(%rsp)
 1f80381:	mov    %edx,0x1b0(%rsp)
 1f80388:	vmovdqa %xmm11,0x230(%rsp)
 1f80391:	vmovdqa %xmm10,0x50(%rsp)
 1f80397:	nopw   0x0(%rax,%rax,1)
 1f803a0:	xor    %r12d,%r12d
 1f803a3:	tzcnt  %ebx,%r12d
 1f803a8:	xor    %edx,%edx
 1f803aa:	mov    (%r14,%r12,4),%esi
 1f803ae:	vzeroupper
 1f803b1:	call   1f93a70 <node_tests_window_line>
 1f803b6:	mov    0x18(%rsp),%rdi
 1f803bb:	mov    $0x1,%edx
 1f803c0:	xor    %ecx,%ecx
 1f803c2:	test   $0x2,%al
 1f803c4:	shlx   %r12d,%edx,%eax
 1f803c9:	cmove  %ecx,%eax
 1f803cc:	or     %eax,%r13d
 1f803cf:	blsr   %ebx,%ebx
 1f803d4:	jne    1f803a0 <node_facts_window_run+0x2ed0>
 1f803d6:	vpbroadcastd -0x19af4ac(%rip),%zmm6        # 5d0f34 <.LCPI3_5>
 1f803e0:	vpbroadcastb -0x1ac96a7(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f803e9:	vpbroadcastd -0x19af4b7(%rip),%zmm8        # 5d0f3c <.LCPI3_11>
 1f803f3:	vpbroadcastd -0x19af4b9(%rip),%zmm9        # 5d0f44 <.LCPI3_13>
 1f803fd:	vmovdqa 0x50(%rsp),%xmm10
 1f80403:	vmovdqa 0x230(%rsp),%xmm11
 1f8040c:	vmovdqu64 0x1f0(%rsp),%zmm12
 1f80417:	vmovdqu64 0x2f0(%rsp),%zmm4
 1f80422:	vmovdqu64 0x3b0(%rsp),%zmm5
 1f8042d:	vmovdqu64 0x370(%rsp),%zmm14
 1f80438:	vmovdqu64 0x2b0(%rsp),%zmm13
 1f80443:	mov    0x8(%rsp),%r11
 1f80448:	mov    0x38(%rsp),%rsi
 1f8044d:	mov    0x30(%rsp),%r12
 1f80452:	mov    0x150(%rsp),%r8
 1f8045a:	mov    0x20(%rsp),%r9
 1f8045f:	mov    0x4f0(%rsp),%r14
 1f80467:	mov    0x430(%rsp),%r10
 1f8046f:	mov    0x1b0(%rsp),%edx
 1f80476:	kmovw  0x270(%rsp),%k5
 1f8047f:	vpsrld $0x2,%zmm12,%zmm2
 1f80486:	vpandd -0x19af548(%rip){1to16},%zmm2,%zmm2        # 5d0f48 <.LCPI3_14>
 1f80490:	vptestmd -0x19af54a(%rip){1to16},%zmm12,%k2        # 5d0f50 <.LCPI3_16>
 1f8049a:	vshufi64x2 $0x88,%zmm13,%zmm14,%zmm0
 1f804a1:	vptestnmb %xmm10,%xmm10,%k0
 1f804a7:	vpsrld $0x1a,%zmm4,%zmm1
 1f804ae:	vpandd -0x19af538(%rip){1to16},%zmm4,%zmm4        # 5d0f80 <.LCPI3_78>
 1f804b8:	kmovd  %r13d,%k3
 1f804bd:	vpcmpneqd -0x19af57c(%rip){1to16},%zmm2,%k1        # 5d0f4c <.LCPI3_15>
 1f804c8:	vpaddd -0x19af57a(%rip){1to16},%zmm4,%zmm4        # 5d0f58 <.LCPI3_20>
 1f804d2:	korw   %k1,%k2,%k1
 1f804d6:	vptestnmd %zmm0,%zmm0,%k2
 1f804dc:	vpandd %zmm9,%zmm5,%zmm0
 1f804e2:	korw   %k2,%k0,%k0
 1f804e6:	vptestmd -0x19af59c(%rip){1to16},%zmm5,%k2        # 5d0f54 <.LCPI3_17>
 1f804f0:	vpbroadcastd -0x19af59e(%rip),%zmm5        # 5d0f5c <.LCPI3_21>
 1f804fa:	korw   %k1,%k0,%k1
 1f804fe:	vptestnmd %zmm0,%zmm0,%k0
 1f80504:	kmovd  %k0,%eax
 1f80508:	vptestmd %zmm2,%zmm2,%k1{%k1}
 1f8050e:	vmovdqu8 -0x19b8828(%rip),%xmm3{%k1}{z}        # 5c7cf0 <.LCPI3_8>
 1f80518:	vpcmpeqd %zmm5,%zmm1,%k4
 1f8051e:	vpcmpltud %zmm5,%zmm4,%k0
 1f80525:	korw   %k2,%k3,%k1
 1f80529:	vpslld $0x1f,%zmm4,%zmm1
 1f80530:	vpbroadcastb -0x1ac97f4(%rip),%xmm4        # 4b6d45 <abi_test_hex.digits+0xb9c5>
 1f80539:	vptestmb %xmm10,%xmm10,%k4{%k4}
 1f8053f:	kmovd  %k0,%ecx
 1f80543:	and    %eax,%ecx
 1f80545:	mov    %edx,%eax
 1f80547:	and    %ecx,%eax
 1f80549:	vmovdqu8 -0x19b8823(%rip),%xmm5{%k4}{z}        # 5c7d30 <.LCPI3_24>
 1f80553:	kmovd  %eax,%k3
 1f80557:	vpcmpeqd %zmm8,%zmm2,%k2{%k3}
 1f8055d:	vpxor  %xmm2,%xmm2,%xmm2
 1f80561:	knotw  %k2,%k0
 1f80565:	kmovd  %k0,%ecx
 1f80569:	and    %eax,%ecx
 1f8056b:	vmovdqu8 -0x19b8835(%rip),%xmm5{%k3}        # 5c7d40 <.LCPI3_25>
 1f80575:	kmovd  %ecx,%k3
 1f80579:	vpcmpgtd %zmm1,%zmm2,%k3{%k3}
 1f8057f:	vpsrld $0x10,%zmm12,%zmm1
 1f80586:	vpternlogd $0xff,%zmm2,%zmm2,%zmm2
 1f8058d:	vpaddd %zmm2,%zmm1,%zmm2
 1f80593:	vmovdqu8 -0x19b884d(%rip),%xmm5{%k3}        # 5c7d50 <.LCPI3_26>
 1f8059d:	vptestnmd %zmm2,%zmm2,%k3
 1f805a3:	vpblendmb -0x19b883d(%rip),%xmm4,%xmm4{%k3}        # 5c7d70 <.LCPI3_28>
 1f805ad:	vpcmpnleud -0x19af658(%rip){1to16},%zmm2,%k3        # 5d0f60 <.LCPI3_22>
 1f805b8:	cmpb   $0x0,0xc90(%rdi)
 1f805bf:	vmovdqu8 -0x19b8849(%rip),%xmm4{%k3}        # 5c7d80 <.LCPI3_29>
 1f805c9:	vpcmpnleud -0x19af670(%rip){1to16},%zmm2,%k3        # 5d0f64 <.LCPI3_23>
 1f805d4:	vmovdqu8 -0x19b884e(%rip),%xmm4{%k3}        # 5c7d90 <.LCPI3_30>
 1f805de:	vptestmd %zmm0,%zmm0,%k3
 1f805e4:	vpor   %xmm7,%xmm3,%xmm0
 1f805e8:	vmovdqu8 %xmm0,%xmm3{%k3}
 1f805ee:	vmovdqu8 %xmm4,%xmm5{%k2}
 1f805f4:	vpor   %xmm5,%xmm3,%xmm0
 1f805f8:	vpord  -0x19af67e(%rip){1to4},%xmm0,%xmm3        # 5d0f84 <.LCPI3_81>
 1f80602:	vmovdqu8 %xmm3,%xmm0{%k5}
 1f80608:	vpord  -0x19af686(%rip){1to4},%xmm0,%xmm3        # 5d0f8c <.LCPI3_85>
 1f80612:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f80618:	vpsrld $0xc,%zmm12,%zmm3
 1f8061f:	vpmovdb %zmm3,%xmm3
 1f80625:	vpternlogd $0xf8,-0x19af6a0(%rip){1to4},%xmm3,%xmm11        # 5d0f90 <.LCPI3_86>
 1f80630:	je     1f806fd <node_facts_window_run+0x322d>
 1f80636:	vmovdqa64 -0x1ac9e40(%rip),%zmm5        # 4b6800 <abi_test_hex.digits+0xb480>
 1f80640:	vptestmd %zmm1,%zmm1,%k1{%k2}
 1f80646:	add    %r9,%rbp
 1f80649:	vpxor  %xmm3,%xmm3,%xmm3
 1f8064d:	vpxor  %xmm4,%xmm4,%xmm4
 1f80651:	vpcmpneqd -0x19af6ec(%rip){1to16},%zmm1,%k0{%k1}        # 5d0f70 <.LCPI3_38>
 1f8065c:	vpor   %xmm0,%xmm11,%xmm1
 1f80660:	kmovq  %k1,%k2
 1f80665:	kmovw  %k1,%eax
 1f80669:	popcnt %eax,%ecx
 1f8066d:	vpgatherdd 0x10(%rbp,%zmm5,1),%zmm3{%k2}
 1f80675:	kmovq  %k1,%k2
 1f8067a:	vpcmpnleud -0x19af711(%rip){1to16},%zmm3,%k3        # 5d0f74 <.LCPI3_39>
 1f80685:	vpgatherdd 0x14(%rbp,%zmm5,1),%zmm4{%k2}
 1f8068d:	add    %rcx,0x110(%rsp)
 1f80695:	mov    0x10(%rsp),%rbx
 1f8069a:	vpcmpeqd %zmm2,%zmm3,%k2
 1f806a0:	vptestnmd %zmm4,%zmm4,%k2{%k2}
 1f806a6:	vptestmd %zmm4,%zmm4,%k4
 1f806ac:	korw   %k4,%k3,%k3
 1f806b0:	kandw  %k2,%k0,%k2
 1f806b4:	knotw  %k0,%k0
 1f806b8:	kandd  %k1,%k0,%k0
 1f806bd:	kandw  %k0,%k3,%k0
 1f806c1:	korw   %k0,%k2,%k2
 1f806c5:	vptestnmd %zmm6,%zmm12,%k0{%k2}
 1f806cb:	kandw  %k0,%k1,%k0
 1f806cf:	kmovd  %k0,%ecx
 1f806d3:	vptestmb %xmm1,%xmm1,%k0
 1f806d9:	andn   %eax,%ecx,%eax
 1f806de:	kmovd  %k0,%ecx
 1f806e2:	andn   %ecx,%edx,%ecx
 1f806e7:	popcnt %eax,%eax
 1f806eb:	movzwl %cx,%ecx
 1f806ee:	add    %rax,%rbx
 1f806f1:	popcnt %ecx,%ecx
 1f806f5:	add    %rcx,%rbx
 1f806f8:	mov    %rbx,0x10(%rsp)
 1f806fd:	mov    0x28(%rsp),%r13
 1f80702:	jmp    1f80125 <node_facts_window_run+0x2c55>
 1f80707:	vmovdqu64 %zmm1,0x4b0(%rsp)
 1f80712:	vmovdqu64 %zmm15,0x650(%rsp)
 1f8071d:	vmovdqu64 %zmm14,0x570(%rsp)
 1f80728:	vmovdqu64 %zmm13,0x3f0(%rsp)
 1f80733:	vmovdqu64 %zmm2,0x2b0(%rsp)
 1f8073e:	vmovdqu64 %zmm12,0x370(%rsp)
 1f80749:	vmovdqu64 %zmm11,0x3b0(%rsp)
 1f80754:	vmovdqa %xmm3,0x2f0(%rsp)
 1f8075d:	vmovdqu64 %zmm5,0x270(%rsp)
 1f80768:	kmovw  %k2,0x1f0(%rsp)
 1f80771:	vmovdqu64 %zmm4,0x1b0(%rsp)
 1f8077c:	vmovdqa %xmm10,0x50(%rsp)
 1f80782:	kmovw  %k3,0x610(%rsp)
 1f8078b:	kandw  %k0,%k3,%k0
 1f8078f:	mov    0x40(%rsp),%rbx
 1f80794:	kmovd  %k0,%eax
 1f80798:	movzwl %ax,%r13d
 1f8079c:	xor    %eax,%eax
 1f8079e:	tzcnt  %r13d,%eax
 1f807a3:	mov    0x60(%r11),%edx
 1f807a7:	mov    0x20(%r11),%rcx
 1f807ab:	add    %r15,%rax
 1f807ae:	mov    (%r12,%rax,4),%r8d
 1f807b2:	mov    (%r14,%rax,4),%esi
 1f807b6:	shl    $0x6,%rax
 1f807ba:	mov    (%r9,%rax,1),%eax
 1f807be:	mov    %r8,0x230(%rsp)
 1f807c6:	shr    $0x3,%eax
 1f807c9:	cmp    %edx,%eax
 1f807cb:	cmovae %edx,%eax
 1f807ce:	shl    $0x6,%rax
 1f807d2:	mov    0x30(%rcx,%rax,1),%edx
 1f807d6:	mov    0xc48(%rdi),%rax
 1f807dd:	cmpb   $0x1,(%rax,%r8,1)
 1f807e2:	adc    $0x0,%rbx
 1f807e6:	and    $0x1,%edx
 1f807e9:	vzeroupper
 1f807ec:	call   1f93a70 <node_tests_window_line>
 1f807f1:	mov    0x18(%rsp),%rdi
 1f807f6:	mov    0x20(%rsp),%r9
 1f807fb:	mov    0x8(%rsp),%r11
 1f80800:	mov    0x230(%rsp),%rdx
 1f80808:	or     $0x1,%al
 1f8080a:	blsr   %r13d,%r13d
 1f8080f:	mov    0xc48(%rdi),%rcx
 1f80816:	mov    %al,(%rcx,%rdx,1)
 1f80819:	jne    1f8079c <node_facts_window_run+0x32cc>
 1f8081b:	mov    %rbx,0x40(%rsp)
 1f80820:	mov    0xc48(%rdi),%rax
 1f80827:	vpbroadcastd -0x19af8fd(%rip),%zmm6        # 5d0f34 <.LCPI3_5>
 1f80831:	vpbroadcastb -0x1ac9af8(%rip),%xmm7        # 4b6d42 <abi_test_hex.digits+0xb9c2>
 1f8083a:	vpbroadcastd -0x19af908(%rip),%zmm8        # 5d0f3c <.LCPI3_11>
 1f80844:	vpbroadcastd -0x19af90a(%rip),%zmm9        # 5d0f44 <.LCPI3_13>
 1f8084e:	vpxor  %xmm0,%xmm0,%xmm0
 1f80852:	vmovdqu64 0x4b0(%rsp),%zmm1
 1f8085d:	kmovw  0x610(%rsp),%k1
 1f80866:	vmovdqa 0x50(%rsp),%xmm10
 1f8086c:	vmovdqu64 0x1b0(%rsp),%zmm4
 1f80877:	vmovdqu64 0x270(%rsp),%zmm5
 1f80882:	vmovdqa 0x2f0(%rsp),%xmm3
 1f8088b:	vmovdqu64 0x3b0(%rsp),%zmm11
 1f80896:	vmovdqu64 0x370(%rsp),%zmm12
 1f808a1:	vmovdqu64 0x2b0(%rsp),%zmm2
 1f808ac:	vmovdqu64 0x3f0(%rsp),%zmm13
 1f808b7:	vmovdqu64 0x570(%rsp),%zmm14
 1f808c2:	vmovdqu64 0x650(%rsp),%zmm15
 1f808cd:	mov    0x38(%rsp),%rsi
 1f808d2:	mov    0x150(%rsp),%r8
 1f808da:	mov    0x430(%rsp),%r10
 1f808e2:	kmovw  0x1f0(%rsp),%k2
 1f808eb:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f808f2:	jmp    1f80268 <node_facts_window_run+0x2d98>
 1f808f7:	movq   $0x0,0x40(%rsp)
 1f80900:	movq   $0x0,0x110(%rsp)
 1f8090c:	movq   $0x0,0x10(%rsp)
 1f80915:	mov    0x40(%rsp),%rax
 1f8091a:	mov    0x110(%rsp),%rcx
 1f80922:	add    %rax,0xa90(%rsi)
 1f80929:	mov    0xbd0(%rdi),%rax
 1f80930:	add    %rcx,0x868(%rax)
 1f80937:	mov    0x10(%rsp),%rcx
 1f8093c:	mov    0xbd0(%rdi),%rax
 1f80943:	add    %rcx,0x870(%rax)
 1f8094a:	rdtsc
 1f8094c:	mov    0x8(%r13),%esi
 1f80950:	cmpq   $0x0,0xc20(%r11)
 1f80958:	mov    %rsi,0x20(%rsp)
 1f8095d:	mov    %rax,0x780(%rsp)
 1f80965:	mov    %rdx,0x490(%rsp)
 1f8096d:	je     1f8117f <node_facts_window_run+0x3caf>
 1f80973:	cmpb   $0x1,0xd58(%r11)
 1f8097b:	jne    1f8117f <node_facts_window_run+0x3caf>
 1f80981:	mov    0xbd0(%rdi),%rcx
 1f80988:	cmpq   $0x0,0x1a0(%rcx)
 1f80990:	sete   %cl
 1f80993:	test   %rsi,%rsi
 1f80996:	je     1f81895 <node_facts_window_run+0x43c5>
 1f8099c:	vpbroadcastb %ecx,%zmm1
 1f809a2:	vgf2p8affineqb $0x0,-0x19b244d(%rip){1to8},%zmm1,%zmm1        # 5ce560 <.LCPI3_87>
 1f809ad:	vmovdqu64 0x388(%rdi),%zmm0
 1f809b7:	vbroadcasti32x4 -0x19b8bb1(%rip),%zmm2        # 5c7e10 <.LCPI3_88>
 1f809c1:	vpbroadcastq -0x19b24bb(%rip),%zmm3        # 5ce510 <.LCPI3_42>
 1f809cb:	vpbroadcastq -0x19b24bd(%rip),%zmm4        # 5ce518 <.LCPI3_43>
 1f809d5:	vmovdqa64 -0x1aca11f(%rip),%zmm6        # 4b68c0 <abi_test_hex.digits+0xb540>
 1f809df:	vbroadcasti32x4 -0x19b8bc9(%rip),%zmm7        # 5c7e20 <.LCPI3_89>
 1f809e9:	vbroadcasti32x4 -0x19b8bc3(%rip),%zmm16        # 5c7e30 <.LCPI3_90>
 1f809f3:	vbroadcasti32x4 -0x19b8bbd(%rip),%zmm17        # 5c7e40 <.LCPI3_91>
 1f809fd:	vbroadcasti32x4 -0x19b8ce7(%rip),%zmm21        # 5c7d20 <.LCPI3_18>
 1f80a07:	vbroadcasti32x4 -0x19b8bc1(%rip),%zmm24        # 5c7e50 <.LCPI3_92>
 1f80a11:	movzbl 0x5c8(%rdi),%r10d
 1f80a19:	mov    %r11,%rcx
 1f80a1c:	mov    0xd78(%rcx),%rbx
 1f80a23:	mov    0xd60(%r11),%r11
 1f80a2a:	xor    %r14d,%r14d
 1f80a2d:	vpxord %xmm25,%xmm25,%xmm25
 1f80a33:	vpxor  %xmm9,%xmm9,%xmm9
 1f80a38:	vpxor  %xmm14,%xmm14,%xmm14
 1f80a3d:	vpxor  %xmm8,%xmm8,%xmm8
 1f80a42:	mov    %rdi,%rax
 1f80a45:	xor    %r9d,%r9d
 1f80a48:	xor    %ecx,%ecx
 1f80a4a:	xor    %edx,%edx
 1f80a4c:	xor    %esi,%esi
 1f80a4e:	xor    %r8d,%r8d
 1f80a51:	vpxord %xmm29,%xmm29,%xmm29
 1f80a57:	neg    %r10
 1f80a5a:	vmovdqu64 %zmm0,0x150(%rsp)
 1f80a65:	movq   $0x0,0x30(%rsp)
 1f80a6e:	xchg   %ax,%ax
 1f80a70:	mov    0xc10(%rax),%rdi
 1f80a77:	vmovdqu64 0x2c(%r13,%r14,1),%zmm11
 1f80a82:	vmovdqa64 %zmm9,%zmm20
 1f80a88:	vmovdqu64 0x108(%rax),%zmm9
 1f80a92:	vmovdqu64 0x308(%rax),%zmm12
 1f80a9c:	vmovdqu64 0x88(%rax),%zmm15
 1f80aa6:	vmovdqu64 0x188(%rax),%zmm23
 1f80ab0:	vmovdqu64 0x208(%rax),%zmm31
 1f80aba:	vmovdqu64 0x288(%rax),%zmm22
 1f80ac4:	vmovdqu64 0x448(%rax),%zmm0
 1f80ace:	vmovdqu64 0x4c8(%rax),%zmm10
 1f80ad8:	vmovdqa64 %zmm29,%zmm5
 1f80ade:	vmovdqa64 %zmm25,%zmm29
 1f80ae4:	vmovdqu64 0x3c8(%rax),%zmm25
 1f80aee:	vmovdqu64 (%rdi,%r14,1),%zmm18
 1f80af5:	mov    0xc18(%rax),%rdi
 1f80afc:	vpermt2b 0x148(%rax),%zmm11,%zmm9
 1f80b06:	vpandq %zmm2,%zmm11,%zmm13
 1f80b0c:	vpermt2b 0x348(%rax),%zmm11,%zmm12
 1f80b16:	vpermt2b 0xc8(%rax),%zmm11,%zmm15
 1f80b20:	vpermt2b 0x1c8(%rax),%zmm11,%zmm23
 1f80b2a:	vpermt2b 0x248(%rax),%zmm11,%zmm31
 1f80b34:	vpermt2b 0x2c8(%rax),%zmm11,%zmm22
 1f80b3e:	vpermt2b 0x408(%rax),%zmm11,%zmm25
 1f80b48:	vpermt2b 0x488(%rax),%zmm11,%zmm0
 1f80b52:	vpermt2b 0x508(%rax),%zmm11,%zmm10
 1f80b5c:	vmovdqu64 (%rdi,%r14,1),%zmm30
 1f80b63:	mov    0xc20(%rax),%rdi
 1f80b6a:	vpsrlw $0x2,%zmm18,%zmm26
 1f80b71:	vpsrlw $0x3,%zmm18,%zmm11
 1f80b78:	vpternlogq $0xf8,%zmm3,%zmm30,%zmm9
 1f80b7f:	vpternlogq $0xf8,%zmm4,%zmm26,%zmm9
 1f80b86:	vpternlogq $0xf8,-0x19b2671(%rip){1to8},%zmm11,%zmm9        # 5ce520 <.LCPI3_44>
 1f80b91:	vmovdqu64 %zmm9,(%rdi,%r14,1)
 1f80b98:	vmovdqu64 0x6b554(%r13,%r14,2),%zmm11
 1f80ba3:	vmovdqu64 0x6b594(%r13,%r14,2),%zmm19
 1f80bae:	vmovdqu64 0x6d614(%r13,%r14,2),%zmm27
 1f80bb9:	vpmovuswb %zmm11,%ymm11
 1f80bbf:	vpmovuswb %zmm19,%ymm19
 1f80bc5:	vpmovuswb %zmm27,%ymm27
 1f80bcb:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm11
 1f80bd2:	vptestmb %zmm11,%zmm11,%k1
 1f80bd8:	vpcmpnltub %zmm11,%zmm6,%k0
 1f80bdf:	vpsubb %zmm11,%zmm6,%zmm19
 1f80be5:	vpcmpltub %zmm11,%zmm6,%k3{%k1}
 1f80bec:	vmovdqu64 0x6d5d4(%r13,%r14,2),%zmm11
 1f80bf7:	kmovq  %k1,%rdi
 1f80bfc:	kmovq  %k0,%r12
 1f80c01:	and    %rdi,%r12
 1f80c04:	mov    0xc28(%rax),%rdi
 1f80c0b:	kmovq  %r12,%k1
 1f80c10:	vpermt2b %zmm25,%zmm19,%zmm29{%k1}{z}
 1f80c16:	knotq  %k1,%k5
 1f80c1b:	vpmovuswb %zmm11,%ymm11
 1f80c21:	vptestmb %zmm0,%zmm29,%k4
 1f80c27:	kmovq  %k4,%r15
 1f80c2c:	vinserti64x4 $0x1,%ymm27,%zmm11,%zmm28
 1f80c33:	vmovdqa64 %zmm20,%zmm11
 1f80c39:	vpermt2b %zmm9,%zmm19,%zmm11{%k1}{z}
 1f80c3f:	vptestmb %zmm28,%zmm28,%k2
 1f80c45:	vpsubb %zmm28,%zmm6,%zmm27
 1f80c4b:	vpcmpltub %zmm28,%zmm6,%k0{%k2}
 1f80c52:	vpcmpnltub %zmm28,%zmm6,%k2{%k2}
 1f80c59:	vpermt2b %zmm9,%zmm27,%zmm20{%k2}{z}
 1f80c5f:	vporq  %zmm11,%zmm20,%zmm28
 1f80c65:	vmovdqu64 %zmm28,(%rdi,%r14,1)
 1f80c6c:	mov    %r14,%rdi
 1f80c6f:	shr    $0x3,%rdi
 1f80c73:	kortestq %k3,%k0
 1f80c78:	vpandq (%r11,%r14,1),%zmm1,%zmm29
 1f80c7f:	vpermt2b %zmm29,%zmm19,%zmm5
 1f80c85:	vptestnmb %zmm5,%zmm5,%k4
 1f80c8b:	korq   %k4,%k5,%k4
 1f80c90:	vpcmpeqb %zmm7,%zmm13,%k4{%k4}
 1f80c96:	kmovq  %k4,(%rbx,%rdi,1)
 1f80c9c:	jne    1f80f9a <node_facts_window_run+0x3aca>
 1f80ca2:	vpsrlw $0x2,%zmm15,%zmm0
 1f80ca9:	vpaddw %zmm18,%zmm18,%zmm5
 1f80caf:	vpermi2b %zmm30,%zmm14,%zmm27{%k2}{z}
 1f80cb5:	mov    0x18(%rsp),%rax
 1f80cba:	vptestmb %zmm21,%zmm15,%k0
 1f80cc0:	vpcmpeqb -0x1aca1ca(%rip),%zmm13,%k6        # 4b6b00 <abi_test_hex.digits+0xb780>
 1f80cca:	vpandq %zmm4,%zmm0,%zmm0
 1f80cd0:	vpternlogq $0xf8,%zmm3,%zmm15,%zmm0
 1f80cd7:	vpternlogq $0xf8,-0x19b27ba(%rip){1to8},%zmm5,%zmm0        # 5ce528 <.LCPI3_47>
 1f80ce2:	vpternlogq $0xf8,-0x19b27bd(%rip){1to8},%zmm26,%zmm0        # 5ce530 <.LCPI3_48>
 1f80ced:	vpandq %zmm23,%zmm18,%zmm26
 1f80cf3:	vpsllw $0x3,%zmm30,%zmm23
 1f80cfa:	vpaddw %zmm26,%zmm26,%zmm5
 1f80d00:	vpsllw $0x4,%zmm30,%zmm26
 1f80d07:	vpternlogq $0xf8,-0x19b27da(%rip){1to8},%zmm5,%zmm0        # 5ce538 <.LCPI3_49>
 1f80d12:	mov    0xc30(%rax),%rdi
 1f80d19:	vpternlogq $0xf8,-0x19b27e4(%rip){1to8},%zmm23,%zmm0        # 5ce540 <.LCPI3_50>
 1f80d24:	vpternlogq $0xf8,-0x19b27e7(%rip){1to8},%zmm26,%zmm0        # 5ce548 <.LCPI3_51>
 1f80d2f:	vmovdqa64 %zmm14,%zmm26
 1f80d35:	vpermt2b %zmm30,%zmm19,%zmm26{%k1}{z}
 1f80d3b:	vpandq %zmm16,%zmm27,%zmm14
 1f80d41:	vpcmpeqb %zmm17,%zmm14,%k4
 1f80d47:	vpandq %zmm22,%zmm28,%zmm14
 1f80d4d:	vpcmpeqb -0x1aca417(%rip),%zmm14,%k2        # 4b6940 <abi_test_hex.digits+0xb5c0>
 1f80d57:	vpsrlw $0x3,%zmm26,%zmm23
 1f80d5e:	vpandq %zmm16,%zmm26,%zmm5
 1f80d64:	vpternlogq $0xe4,-0x19b281f(%rip){1to8},%zmm27,%zmm23        # 5ce550 <.LCPI3_52>
 1f80d6f:	vpcmpeqb %zmm17,%zmm5,%k3
 1f80d75:	vpermb 0x150(%rsp),%zmm23,%zmm5
 1f80d80:	kmovq  %k0,0x10(%rsp)
 1f80d87:	vpcmpeqb %zmm7,%zmm13,%k0
 1f80d8d:	kmovq  %k0,%r13
 1f80d92:	vptestmb -0x1aca35c(%rip),%zmm18,%k0        # 4b6a40 <abi_test_hex.digits+0xb6c0>
 1f80d9c:	korq   %k4,%k3,%k3
 1f80da1:	vpcmpeqb -0x1aca3ab(%rip),%zmm13,%k3{%k3}        # 4b6a00 <abi_test_hex.digits+0xb680>
 1f80dab:	vptestmb %zmm14,%zmm14,%k4
 1f80db1:	vmovdqu64 %zmm0,(%rdi,%r14,1)
 1f80db8:	vpandd -0x19afe3e(%rip){1to16},%zmm26,%zmm0        # 5d0f84 <.LCPI3_81>
 1f80dc2:	and    %r10,%r13
 1f80dc5:	vptestnmb %zmm31,%zmm31,%k2{%k2}
 1f80dcb:	vpternlogq $0xe0,%zmm2,%zmm30,%zmm5
 1f80dd2:	vptestmb %zmm12,%zmm5,%k5{%k2}
 1f80dd8:	vpandq %zmm21,%zmm18,%zmm5
 1f80dde:	kmovq  %k0,%rbp
 1f80de3:	knotq  %k3,%k3
 1f80de8:	vpternlogq $0xfe,%zmm0,%zmm14,%zmm5
 1f80def:	and    %rbp,%r13
 1f80df2:	vpsllw $0x7,%zmm18,%zmm0
 1f80df9:	vptestnmb %zmm5,%zmm5,%k7
 1f80dff:	vpmovb2m %zmm0,%k2
 1f80e05:	vmovdqa64 %zmm31,%zmm0
 1f80e0b:	vpternlogd $0xf8,-0x19afe82(%rip){1to16},%zmm14,%zmm0        # 5d0f94 <.LCPI3_93>
 1f80e16:	kmovq  %k7,%rbp
 1f80e1b:	vptestmb -0x1aca2e5(%rip),%zmm18,%k7{%k4}        # 4b6b40 <abi_test_hex.digits+0xb7c0>
 1f80e25:	and    %r13,%rbp
 1f80e28:	mov    %r9d,%r13d
 1f80e2b:	and    %r12,%rbp
 1f80e2e:	kmovq  %k5,%rdi
 1f80e33:	vptestmb %zmm24,%zmm11,%k5
 1f80e39:	vptestmb -0x1aca283(%rip),%zmm12,%k5{%k5}        # 4b6bc0 <abi_test_hex.digits+0xb840>
 1f80e43:	mov    0xc40(%rax),%r12
 1f80e4a:	kmovq  %rbp,%k0
 1f80e4f:	vpmovm2b %k0,%zmm13
 1f80e55:	vpermt2b %zmm13,%zmm19,%zmm8
 1f80e5b:	vptestmb %zmm8,%zmm8,%k0{%k1}
 1f80e61:	vpbroadcastw %r14d,%zmm8
 1f80e67:	vporq  -0x1aca231(%rip),%zmm8,%zmm5        # 4b6c40 <abi_test_hex.digits+0xb8c0>
 1f80e71:	kandq  %k7,%k6,%k1
 1f80e76:	kandq  %k2,%k6,%k6
 1f80e7b:	vptestmb %zmm10,%zmm28,%k7
 1f80e81:	vptestmb %zmm24,%zmm20,%k5{%k5}
 1f80e87:	kandq  %k0,%k6,%k6
 1f80e8c:	vptestnmb %zmm0,%zmm0,%k5{%k5}
 1f80e92:	vporq  -0x1aca21c(%rip),%zmm8,%zmm0        # 4b6c80 <abi_test_hex.digits+0xb900>
 1f80e9c:	vmovdqa64 %zmm13,%zmm8
 1f80ea2:	vpcompressw %zmm5,%zmm5{%k6}{z}
 1f80ea8:	kandq  %k5,%k4,%k4
 1f80ead:	korq   %k1,%k4,%k0
 1f80eb2:	vmovdqu64 %zmm5,(%r12,%r13,2)
 1f80eb9:	kmovd  %k6,%r12d
 1f80ebd:	kshiftrq $0x20,%k6,%k6
 1f80ec3:	kmovq  %k3,%r13
 1f80ec8:	kmovq  0x10(%rsp),%k3
 1f80ecf:	popcnt %r12d,%r12d
 1f80ed4:	vpcompressw %zmm0,%zmm0{%k6}{z}
 1f80eda:	and    %rdi,%r13
 1f80edd:	kmovq  %k7,%rdi
 1f80ee2:	add    %r9d,%r12d
 1f80ee5:	mov    0xc40(%rax),%r9
 1f80eec:	or     %r15,%rdi
 1f80eef:	vmovdqu64 %zmm0,(%r9,%r12,2)
 1f80ef6:	kmovq  %k0,%r9
 1f80efb:	vporq  %zmm31,%zmm14,%zmm0
 1f80f01:	vmovdqa64 %zmm30,%zmm14
 1f80f07:	mov    0xc38(%rax),%r15
 1f80f0e:	or     %rbp,%r9
 1f80f11:	vptestmb %zmm0,%zmm0,%k0
 1f80f17:	or     %r13,%r9
 1f80f1a:	mov    %rdi,0x8(%r15,%r14,1)
 1f80f1f:	kmovq  %k0,%rdi
 1f80f24:	korq   %k2,%k3,%k0
 1f80f29:	mov    %r9,(%r15,%r14,1)
 1f80f2d:	andn   %rdi,%r9,%rdi
 1f80f32:	mov    %rdi,0x10(%r15,%r14,1)
 1f80f37:	kmovq  %k0,%rdi
 1f80f3c:	kmovq  %k3,0x18(%r15,%r14,1)
 1f80f43:	or     %rbp,%rdi
 1f80f46:	mov    %rdi,0x20(%r15,%r14,1)
 1f80f4b:	kmovd  %k6,%edi
 1f80f4f:	popcnt %rbp,%r15
 1f80f54:	add    $0x40,%r14
 1f80f58:	popcnt %edi,%r9d
 1f80f5d:	add    %r15,%rdx
 1f80f60:	kmovq  %k4,%r15
 1f80f65:	add    %r12d,%r9d
 1f80f68:	popcnt %r13,%r12
 1f80f6d:	mov    0x28(%rsp),%r13
 1f80f72:	add    %r12,%rcx
 1f80f75:	kmovq  %k1,%r12
 1f80f7a:	popcnt %r12,%rdi
 1f80f7f:	add    %rdi,%rsi
 1f80f82:	popcnt %r15,%rdi
 1f80f87:	add    %rdi,%r8
 1f80f8a:	cmp    0x20(%rsp),%r14
 1f80f8f:	jb     1f80a70 <node_facts_window_run+0x35a0>
 1f80f95:	jmp    1f818aa <node_facts_window_run+0x43da>
 1f80f9a:	kmovq  %k3,%rax
 1f80f9f:	mov    %rax,%rdi
 1f80fa2:	mov    %rax,0x270(%rsp)
 1f80faa:	test   %rax,%rax
 1f80fad:	je     1f810df <node_facts_window_run+0x3c0f>
 1f80fb3:	xor    %eax,%eax
 1f80fb5:	tzcnt  %rdi,%rax
 1f80fba:	mov    %rdi,0x10(%rsp)
 1f80fbf:	lea    (%rax,%r14,1),%rbp
 1f80fc3:	mov    %rax,0x110(%rsp)
 1f80fcb:	mov    %rbp,0x50(%rsp)
 1f80fd0:	mov    %ebp,%edi
 1f80fd2:	mov    0x28(%rsp),%rax
 1f80fd7:	movzwl 0x6b554(%rax,%rdi,2),%r13d
 1f80fe0:	sub    %r13d,%ebp
 1f80fe3:	mov    0x18(%rsp),%r13
 1f80fe8:	mov    0xc20(%r13),%r13
 1f80fef:	mov    %r13,0x230(%rsp)
 1f80ff7:	mov    0x18(%rsp),%r13
 1f80ffc:	mov    0xc28(%r13),%rax
 1f81003:	mov    %rax,0x1b0(%rsp)
 1f8100b:	mov    0x230(%rsp),%r13
 1f81013:	mov    0x1b0(%rsp),%rax
 1f8101b:	movzbl 0x0(%r13,%rbp,1),%r13d
 1f81021:	or     %r13b,(%rax,%rdi,1)
 1f81025:	mov    0x28(%rsp),%r13
 1f8102a:	movzbl 0x2c(%r13,%rdi,1),%edi
 1f81030:	and    $0x7f,%edi
 1f81033:	mov    %rdi,0x230(%rsp)
 1f8103b:	movzbl 0x2c(%r13,%rbp,1),%edi
 1f81041:	mov    0x18(%rsp),%rax
 1f81046:	and    $0x7f,%edi
 1f81049:	mov    %rdi,0x1b0(%rsp)
 1f81051:	movzbl 0x3c8(%rax,%rdi,1),%edi
 1f81059:	mov    %dil,0x1f0(%rsp)
 1f81061:	mov    0x230(%rsp),%r13
 1f81069:	movzbl 0x1f0(%rsp),%edi
 1f81071:	test   %dil,0x448(%rax,%r13,1)
 1f81079:	mov    0x110(%rsp),%rax
 1f81081:	mov    $0x0,%edi
 1f81086:	setne  %dil
 1f8108a:	shlx   %rax,%rdi,%rdi
 1f8108f:	mov    0x50(%rsp),%rax
 1f81094:	or     %rdi,%r15
 1f81097:	cmp    %eax,0x20(%rsp)
 1f8109b:	mov    0x18(%rsp),%rax
 1f810a0:	seta   %dil
 1f810a4:	cmpq   $0x22,0x1b0(%rsp)
 1f810ad:	mov    0xc38(%rax),%rax
 1f810b4:	sete   %r13b
 1f810b8:	and    %dil,%r13b
 1f810bb:	movzbl %r13b,%edi
 1f810bf:	shlx   %rbp,%rdi,%rdi
 1f810c4:	and    $0xffffffc0,%ebp
 1f810c7:	not    %rdi
 1f810ca:	and    %rdi,0x20(%rax,%rbp,1)
 1f810cf:	mov    0x10(%rsp),%rdi
 1f810d4:	blsr   %rdi,%rdi
 1f810d9:	jne    1f80fb3 <node_facts_window_run+0x3ae3>
 1f810df:	kmovq  %k0,%rax
 1f810e4:	mov    %rax,%r13
 1f810e7:	mov    %rax,0x50(%rsp)
 1f810ec:	test   %rax,%rax
 1f810ef:	je     1f81149 <node_facts_window_run+0x3c79>
 1f810f1:	xor    %ebp,%ebp
 1f810f3:	tzcnt  %r13,%rbp
 1f810f8:	or     %r14,%rbp
 1f810fb:	mov    %ebp,%eax
 1f810fd:	mov    %rax,0x10(%rsp)
 1f81102:	mov    0x28(%rsp),%rdi
 1f81107:	movzwl 0x6d5d4(%rdi,%rax,2),%edi
 1f8110f:	mov    0x18(%rsp),%rax
 1f81114:	sub    %edi,%ebp
 1f81116:	mov    0xc20(%rax),%rdi
 1f8111d:	mov    0xc28(%rax),%rax
 1f81124:	mov    %rax,0x110(%rsp)
 1f8112c:	movzbl (%rdi,%rbp,1),%edi
 1f81130:	mov    0x10(%rsp),%rax
 1f81135:	mov    0x110(%rsp),%rbp
 1f8113d:	or     %dil,0x0(%rbp,%rax,1)
 1f81142:	blsr   %r13,%r13
 1f81147:	jne    1f810f1 <node_facts_window_run+0x3c21>
 1f81149:	mov    0x18(%rsp),%rax
 1f8114e:	popcnt 0x270(%rsp),%r13
 1f81158:	popcnt 0x50(%rsp),%rdi
 1f8115f:	add    0x30(%rsp),%r13
 1f81164:	mov    0xc28(%rax),%rax
 1f8116b:	add    %rdi,%r13
 1f8116e:	mov    %r13,0x30(%rsp)
 1f81173:	vmovdqu64 (%rax,%r14,1),%zmm28
 1f8117a:	jmp    1f80ca2 <node_facts_window_run+0x37d2>
 1f8117f:	test   %rsi,%rsi
 1f81182:	je     1f81895 <node_facts_window_run+0x43c5>
 1f81188:	vmovdqu64 0x388(%rdi),%zmm0
 1f81192:	vbroadcasti32x4 -0x19b938c(%rip),%zmm1        # 5c7e10 <.LCPI3_88>
 1f8119c:	vpbroadcastq -0x19b2c96(%rip),%zmm2        # 5ce510 <.LCPI3_42>
 1f811a6:	vpbroadcastq -0x19b2c98(%rip),%zmm3        # 5ce518 <.LCPI3_43>
 1f811b0:	vmovdqa64 -0x1aca8fa(%rip),%zmm5        # 4b68c0 <abi_test_hex.digits+0xb540>
 1f811ba:	vbroadcasti32x4 -0x19b9394(%rip),%zmm14        # 5c7e30 <.LCPI3_90>
 1f811c4:	vbroadcasti32x4 -0x19b938e(%rip),%zmm15        # 5c7e40 <.LCPI3_91>
 1f811ce:	vbroadcasti32x4 -0x19b94b8(%rip),%zmm20        # 5c7d20 <.LCPI3_18>
 1f811d8:	vbroadcasti32x4 -0x19b9392(%rip),%zmm23        # 5c7e50 <.LCPI3_92>
 1f811e2:	vmovdqa64 -0x1aca5ac(%rip),%zmm27        # 4b6c40 <abi_test_hex.digits+0xb8c0>
 1f811ec:	vmovdqa64 -0x1aca576(%rip),%zmm28        # 4b6c80 <abi_test_hex.digits+0xb900>
 1f811f6:	movzbl 0x5c8(%rdi),%r10d
 1f811fe:	mov    %rdi,%rax
 1f81201:	xor    %r9d,%r9d
 1f81204:	vpxord %xmm24,%xmm24,%xmm24
 1f8120a:	vpxor  %xmm8,%xmm8,%xmm8
 1f8120f:	xor    %r11d,%r11d
 1f81212:	vpxor  %xmm11,%xmm11,%xmm11
 1f81217:	vpxord %xmm31,%xmm31,%xmm31
 1f8121d:	movq   $0x0,0x30(%rsp)
 1f81226:	xor    %ecx,%ecx
 1f81228:	xor    %edx,%edx
 1f8122a:	xor    %esi,%esi
 1f8122c:	xor    %r8d,%r8d
 1f8122f:	neg    %r10
 1f81232:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81240:	vmovdqu64 0x2c(%r13,%r11,1),%zmm6
 1f8124b:	mov    0xc10(%rax),%rdi
 1f81252:	mov    0xc18(%rax),%rbx
 1f81259:	vmovdqa64 %zmm8,%zmm16
 1f8125f:	vmovdqu64 0x108(%rax),%zmm8
 1f81269:	vmovdqu64 0x308(%rax),%zmm7
 1f81273:	vmovdqu64 0x88(%rax),%zmm10
 1f8127d:	vmovdqu64 0x188(%rax),%zmm18
 1f81287:	vmovdqu64 0x208(%rax),%zmm30
 1f81291:	vmovdqu64 0x288(%rax),%zmm17
 1f8129b:	vmovdqu64 0x448(%rax),%zmm26
 1f812a5:	vmovdqu64 0x4c8(%rax),%zmm4
 1f812af:	vmovdqa64 %zmm24,%zmm25
 1f812b5:	vmovdqu64 0x3c8(%rax),%zmm24
 1f812bf:	vmovdqu64 (%rdi,%r11,1),%zmm12
 1f812c6:	vmovdqu64 (%rbx,%r11,1),%zmm29
 1f812cd:	mov    0xc20(%rax),%rdi
 1f812d4:	vpermt2b 0x148(%rax),%zmm6,%zmm8
 1f812de:	vpandq %zmm1,%zmm6,%zmm9
 1f812e4:	vpermt2b 0x348(%rax),%zmm6,%zmm7
 1f812ee:	vpermt2b 0xc8(%rax),%zmm6,%zmm10
 1f812f8:	vpermt2b 0x1c8(%rax),%zmm6,%zmm18
 1f81302:	vpermt2b 0x248(%rax),%zmm6,%zmm30
 1f8130c:	vpermt2b 0x2c8(%rax),%zmm6,%zmm17
 1f81316:	vpermt2b 0x408(%rax),%zmm6,%zmm24
 1f81320:	vpermt2b 0x488(%rax),%zmm6,%zmm26
 1f8132a:	vpermt2b 0x508(%rax),%zmm6,%zmm4
 1f81334:	vpsrlw $0x2,%zmm12,%zmm19
 1f8133b:	vpsrlw $0x3,%zmm12,%zmm6
 1f81342:	vpternlogq $0xf8,%zmm2,%zmm29,%zmm8
 1f81349:	vpternlogq $0xf8,%zmm3,%zmm19,%zmm8
 1f81350:	vpternlogq $0xf8,-0x19b2e3b(%rip){1to8},%zmm6,%zmm8        # 5ce520 <.LCPI3_44>
 1f8135b:	vmovdqu64 %zmm8,(%rdi,%r11,1)
 1f81362:	vmovdqu64 0x6b554(%r13,%r11,2),%zmm6
 1f8136d:	vmovdqu64 0x6b594(%r13,%r11,2),%zmm13
 1f81378:	vmovdqu64 0x6d614(%r13,%r11,2),%zmm21
 1f81383:	vpmovuswb %zmm6,%ymm6
 1f81389:	vpmovuswb %zmm13,%ymm13
 1f8138f:	vpmovuswb %zmm21,%ymm21
 1f81395:	vinserti64x4 $0x1,%ymm13,%zmm6,%zmm6
 1f8139c:	vptestmb %zmm6,%zmm6,%k1
 1f813a2:	vpcmpnltub %zmm6,%zmm5,%k0
 1f813a9:	vpsubb %zmm6,%zmm5,%zmm13
 1f813af:	vpcmpltub %zmm6,%zmm5,%k3{%k1}
 1f813b6:	vmovdqu64 0x6d5d4(%r13,%r11,2),%zmm6
 1f813c1:	kmovq  %k1,%rdi
 1f813c6:	kmovq  %k0,%r14
 1f813cb:	and    %rdi,%r14
 1f813ce:	mov    0xc28(%rax),%rdi
 1f813d5:	kmovq  %r14,%k1
 1f813da:	vpermt2b %zmm24,%zmm13,%zmm25{%k1}{z}
 1f813e0:	vpmovuswb %zmm6,%ymm6
 1f813e6:	vptestmb %zmm26,%zmm25,%k4
 1f813ec:	kmovq  %k4,%rbx
 1f813f1:	vinserti64x4 $0x1,%ymm21,%zmm6,%zmm22
 1f813f8:	vmovdqa64 %zmm16,%zmm6
 1f813fe:	vpermt2b %zmm8,%zmm13,%zmm6{%k1}{z}
 1f81404:	vptestmb %zmm22,%zmm22,%k2
 1f8140a:	vpsubb %zmm22,%zmm5,%zmm21
 1f81410:	vpcmpltub %zmm22,%zmm5,%k0{%k2}
 1f81417:	vpcmpnltub %zmm22,%zmm5,%k2{%k2}
 1f8141e:	vpermt2b %zmm8,%zmm21,%zmm16{%k2}{z}
 1f81424:	kortestq %k3,%k0
 1f81429:	vporq  %zmm6,%zmm16,%zmm22
 1f8142f:	vmovdqu64 %zmm22,(%rdi,%r11,1)
 1f81436:	jne    1f8172a <node_facts_window_run+0x425a>
 1f8143c:	vpsrlw $0x2,%zmm10,%zmm25
 1f81443:	vpaddw %zmm12,%zmm12,%zmm26
 1f81449:	vpandq %zmm18,%zmm12,%zmm18
 1f8144f:	mov    0x18(%rsp),%rax
 1f81454:	vpermi2b %zmm29,%zmm11,%zmm21{%k2}{z}
 1f8145a:	vpcmpeqb -0x1aca964(%rip),%zmm9,%k6        # 4b6b00 <abi_test_hex.digits+0xb780>
 1f81464:	vptestmb %zmm20,%zmm10,%k0
 1f8146a:	vpandq %zmm3,%zmm25,%zmm25
 1f81470:	vpaddw %zmm18,%zmm18,%zmm18
 1f81476:	kmovq  %k0,0x10(%rsp)
 1f8147d:	vpternlogq $0xf8,%zmm2,%zmm10,%zmm25
 1f81484:	vpternlogq $0xf8,-0x19b2f67(%rip){1to8},%zmm26,%zmm25        # 5ce528 <.LCPI3_47>
 1f8148f:	vpsllw $0x3,%zmm29,%zmm26
 1f81496:	vpsllw $0x7,%zmm12,%zmm10
 1f8149d:	vpternlogq $0xf8,-0x19b2f78(%rip){1to8},%zmm19,%zmm25        # 5ce530 <.LCPI3_48>
 1f814a8:	vpsllw $0x4,%zmm29,%zmm19
 1f814af:	vpternlogq $0xf8,-0x19b2f82(%rip){1to8},%zmm18,%zmm25        # 5ce538 <.LCPI3_49>
 1f814ba:	vpandq %zmm20,%zmm12,%zmm18
 1f814c0:	vpternlogq $0xf8,-0x19b2f8b(%rip){1to8},%zmm26,%zmm25        # 5ce540 <.LCPI3_50>
 1f814cb:	vmovdqa64 %zmm11,%zmm26
 1f814d1:	vpermt2b %zmm29,%zmm13,%zmm26{%k1}{z}
 1f814d7:	mov    0xc30(%rax),%rdi
 1f814de:	vpternlogq $0xf8,-0x19b2fa1(%rip){1to8},%zmm19,%zmm25        # 5ce548 <.LCPI3_51>
 1f814e9:	vpandq %zmm14,%zmm21,%zmm19
 1f814ef:	vpcmpeqb %zmm15,%zmm19,%k4
 1f814f5:	vpandq %zmm14,%zmm26,%zmm11
 1f814fb:	vpcmpeqb %zmm15,%zmm11,%k3
 1f81501:	vmovdqa64 %zmm29,%zmm11
 1f81507:	korq   %k4,%k3,%k3
 1f8150c:	vpcmpeqb -0x1acac16(%rip),%zmm9,%k4        # 4b6900 <abi_test_hex.digits+0xb580>
 1f81516:	vpcmpeqb -0x1acab20(%rip),%zmm9,%k3{%k3}        # 4b6a00 <abi_test_hex.digits+0xb680>
 1f81520:	vmovdqu64 %zmm25,(%rdi,%r11,1)
 1f81527:	vpsrlw $0x3,%zmm26,%zmm25
 1f8152e:	vpternlogq $0xe4,-0x19b2fe9(%rip){1to8},%zmm21,%zmm25        # 5ce550 <.LCPI3_52>
 1f81539:	vpandq %zmm17,%zmm22,%zmm21
 1f8153f:	vpcmpeqb -0x1acac09(%rip),%zmm21,%k2        # 4b6940 <abi_test_hex.digits+0xb5c0>
 1f81549:	vpandd -0x19b05cf(%rip){1to16},%zmm26,%zmm17        # 5d0f84 <.LCPI3_81>
 1f81553:	kmovq  %k4,%r12
 1f81558:	vptestmb -0x1acab22(%rip),%zmm12,%k4        # 4b6a40 <abi_test_hex.digits+0xb6c0>
 1f81562:	knotq  %k3,%k3
 1f81567:	and    %r10,%r12
 1f8156a:	vpermb %zmm0,%zmm25,%zmm19
 1f81570:	vptestnmb %zmm30,%zmm30,%k2{%k2}
 1f81576:	vpternlogq $0xfe,%zmm17,%zmm21,%zmm18
 1f8157d:	vptestnmb %zmm18,%zmm18,%k7
 1f81583:	vpternlogq $0xe0,%zmm1,%zmm29,%zmm19
 1f8158a:	vptestmb %zmm7,%zmm19,%k5{%k2}
 1f81590:	kmovq  %k4,%r15
 1f81595:	vptestmb %zmm21,%zmm21,%k4
 1f8159b:	vpmovb2m %zmm10,%k2
 1f815a1:	and    %r15,%r12
 1f815a4:	kmovq  %k7,%r15
 1f815a9:	vptestmb -0x1acaa73(%rip),%zmm12,%k7{%k4}        # 4b6b40 <abi_test_hex.digits+0xb7c0>
 1f815b3:	and    %r12,%r15
 1f815b6:	mov    %r9d,%r12d
 1f815b9:	and    %r14,%r15
 1f815bc:	mov    0xc40(%rax),%r14
 1f815c3:	kmovq  %k5,%rdi
 1f815c8:	kmovq  %r15,%k5
 1f815cd:	vpmovm2b %k5,%zmm9
 1f815d3:	vptestmb %zmm23,%zmm6,%k5
 1f815d9:	vptestmb -0x1acaa23(%rip),%zmm7,%k5{%k5}        # 4b6bc0 <abi_test_hex.digits+0xb840>
 1f815e3:	vpermt2b %zmm9,%zmm13,%zmm31
 1f815e9:	vmovdqa64 %zmm30,%zmm6
 1f815ef:	vpternlogd $0xf8,-0x19b0666(%rip){1to16},%zmm21,%zmm6        # 5d0f94 <.LCPI3_93>
 1f815fa:	vptestmb %zmm31,%zmm31,%k0{%k1}
 1f81600:	kandq  %k7,%k6,%k1
 1f81605:	kandq  %k2,%k6,%k6
 1f8160a:	vptestmb %zmm4,%zmm22,%k7
 1f81610:	vpbroadcastw %r11d,%zmm4
 1f81616:	vmovdqa64 %zmm9,%zmm31
 1f8161c:	vporq  %zmm27,%zmm4,%zmm7
 1f81622:	vporq  %zmm28,%zmm4,%zmm4
 1f81628:	vptestmb %zmm23,%zmm16,%k5{%k5}
 1f8162e:	kandq  %k0,%k6,%k6
 1f81633:	kmovd  %k6,%ebp
 1f81637:	vptestnmb %zmm6,%zmm6,%k5{%k5}
 1f8163d:	vpxor  %xmm6,%xmm6,%xmm6
 1f81641:	vpcompressw %zmm7,%zmm6{%k6}{z}
 1f81647:	kshiftrq $0x20,%k6,%k6
 1f8164d:	vpcompressw %zmm4,%zmm4{%k6}{z}
 1f81653:	vmovdqu64 %zmm6,(%r14,%r12,2)
 1f8165a:	popcnt %ebp,%r14d
 1f8165f:	kmovq  %k3,%r12
 1f81664:	kmovq  0x10(%rsp),%k3
 1f8166b:	kandq  %k5,%k4,%k4
 1f81670:	kmovd  %k6,%ebp
 1f81674:	add    %r9d,%r14d
 1f81677:	mov    0xc40(%rax),%r9
 1f8167e:	and    %rdi,%r12
 1f81681:	kmovq  %k7,%rdi
 1f81686:	korq   %k1,%k4,%k0
 1f8168b:	or     %rbx,%rdi
 1f8168e:	vmovdqu64 %zmm4,(%r9,%r14,2)
 1f81695:	kmovq  %k0,%r9
 1f8169a:	vporq  %zmm30,%zmm21,%zmm4
 1f816a0:	mov    0xc38(%rax),%rbx
 1f816a7:	or     %r15,%r9
 1f816aa:	vptestmb %zmm4,%zmm4,%k0
 1f816b0:	or     %r12,%r9
 1f816b3:	mov    %rdi,0x8(%rbx,%r11,1)
 1f816b8:	kmovq  %k0,%rdi
 1f816bd:	korq   %k2,%k3,%k0
 1f816c2:	mov    %r9,(%rbx,%r11,1)
 1f816c6:	andn   %rdi,%r9,%rdi
 1f816cb:	kmovq  %k0,%r9
 1f816d0:	or     %r15,%r9
 1f816d3:	mov    %rdi,0x10(%rbx,%r11,1)
 1f816d8:	kmovq  %k3,0x18(%rbx,%r11,1)
 1f816df:	mov    %r9,0x20(%rbx,%r11,1)
 1f816e4:	popcnt %ebp,%r9d
 1f816e9:	popcnt %r15,%rbx
 1f816ee:	add    $0x40,%r11
 1f816f2:	add    %r14d,%r9d
 1f816f5:	popcnt %r12,%r14
 1f816fa:	add    %rbx,%rdx
 1f816fd:	kmovq  %k4,%rbx
 1f81702:	add    %r14,%rcx
 1f81705:	kmovq  %k1,%r14
 1f8170a:	popcnt %r14,%rdi
 1f8170f:	add    %rdi,%rsi
 1f81712:	popcnt %rbx,%rdi
 1f81717:	add    %rdi,%r8
 1f8171a:	cmp    0x20(%rsp),%r11
 1f8171f:	jb     1f81240 <node_facts_window_run+0x3d70>
 1f81725:	jmp    1f818aa <node_facts_window_run+0x43da>
 1f8172a:	kmovq  %k3,%rax
 1f8172f:	mov    %r13,%r15
 1f81732:	mov    %rax,0x50(%rsp)
 1f81737:	mov    %rax,%rdi
 1f8173a:	test   %rax,%rax
 1f8173d:	mov    0x18(%rsp),%rax
 1f81742:	je     1f81815 <node_facts_window_run+0x4345>
 1f81748:	mov    %rdi,0x10(%rsp)
 1f8174d:	tzcnt  %rdi,%rdi
 1f81752:	mov    0xc28(%rax),%r13
 1f81759:	lea    (%rdi,%r11,1),%r12
 1f8175d:	mov    %rdi,0x150(%rsp)
 1f81765:	mov    %r12d,%edi
 1f81768:	movzwl 0x6b554(%r15,%rdi,2),%ebp
 1f81771:	mov    %r12,0x110(%rsp)
 1f81779:	sub    %ebp,%r12d
 1f8177c:	mov    0xc20(%rax),%rbp
 1f81783:	movzbl 0x0(%rbp,%r12,1),%ebp
 1f81789:	or     %bpl,0x0(%r13,%rdi,1)
 1f8178e:	movzbl 0x2c(%r15,%r12,1),%r13d
 1f81794:	movzbl 0x2c(%r15,%rdi,1),%edi
 1f8179a:	xor    %r15d,%r15d
 1f8179d:	and    $0x7f,%r13d
 1f817a1:	and    $0x7f,%edi
 1f817a4:	movzbl 0x3c8(%rax,%r13,1),%ebp
 1f817ad:	test   %bpl,0x448(%rax,%rdi,1)
 1f817b5:	mov    0x150(%rsp),%rdi
 1f817bd:	setne  %r15b
 1f817c1:	shlx   %rdi,%r15,%rdi
 1f817c6:	mov    0xc38(%rax),%r15
 1f817cd:	or     %rdi,%rbx
 1f817d0:	mov    0x110(%rsp),%rdi
 1f817d8:	cmp    %edi,0x20(%rsp)
 1f817dc:	seta   %dil
 1f817e0:	cmp    $0x22,%r13
 1f817e4:	sete   %bpl
 1f817e8:	and    %dil,%bpl
 1f817eb:	movzbl %bpl,%edi
 1f817ef:	shlx   %r12,%rdi,%rdi
 1f817f4:	and    $0xffffffc0,%r12d
 1f817f8:	not    %rdi
 1f817fb:	and    %rdi,0x20(%r15,%r12,1)
 1f81800:	mov    0x10(%rsp),%rdi
 1f81805:	mov    0x28(%rsp),%r15
 1f8180a:	blsr   %rdi,%rdi
 1f8180f:	jne    1f81748 <node_facts_window_run+0x4278>
 1f81815:	kmovq  %k0,%rdi
 1f8181a:	mov    %rdi,%r12
 1f8181d:	mov    %rdi,0x10(%rsp)
 1f81822:	test   %rdi,%rdi
 1f81825:	je     1f81862 <node_facts_window_run+0x4392>
 1f81827:	mov    0x28(%rsp),%r15
 1f8182c:	xor    %edi,%edi
 1f8182e:	tzcnt  %r12,%rdi
 1f81833:	or     %r11,%rdi
 1f81836:	mov    %edi,%r13d
 1f81839:	movzwl 0x6d5d4(%r15,%r13,2),%ebp
 1f81842:	mov    0xc28(%rax),%r15
 1f81849:	sub    %ebp,%edi
 1f8184b:	mov    0xc20(%rax),%rbp
 1f81852:	movzbl 0x0(%rbp,%rdi,1),%edi
 1f81857:	or     %dil,(%r15,%r13,1)
 1f8185b:	blsr   %r12,%r12
 1f81860:	jne    1f81827 <node_facts_window_run+0x4357>
 1f81862:	popcnt 0x50(%rsp),%rdi
 1f81869:	mov    0xc28(%rax),%rax
 1f81870:	popcnt 0x10(%rsp),%r15
 1f81877:	add    0x30(%rsp),%rdi
 1f8187c:	vmovdqu64 (%rax,%r11,1),%zmm22
 1f81883:	add    %r15,%rdi
 1f81886:	mov    %rdi,0x30(%rsp)
 1f8188b:	mov    0x28(%rsp),%r13
 1f81890:	jmp    1f8143c <node_facts_window_run+0x3f6c>
 1f81895:	movq   $0x0,0x30(%rsp)
 1f8189e:	xor    %ecx,%ecx
 1f818a0:	xor    %edx,%edx
 1f818a2:	xor    %esi,%esi
 1f818a4:	xor    %r8d,%r8d
 1f818a7:	xor    %r9d,%r9d
 1f818aa:	mov    0x38(%rsp),%rdi
 1f818af:	mov    0x30(%rsp),%rax
 1f818b4:	movq   $0x0,0x2b0(%rsp)
 1f818c0:	add    %rax,0xa88(%rdi)
 1f818c7:	add    %rcx,0x7e8(%rdi)
 1f818ce:	add    %rdx,0x800(%rdi)
 1f818d5:	add    %rsi,0x838(%rdi)
 1f818dc:	add    %r8,0x850(%rdi)
 1f818e3:	test   %r9d,%r9d
 1f818e6:	je     1f819bf <node_facts_window_run+0x44ef>
 1f818ec:	mov    %r9d,%r14d
 1f818ef:	mov    0x18(%rsp),%r9
 1f818f4:	mov    $0x8,%ebp
 1f818f9:	xor    %r12d,%r12d
 1f818fc:	xor    %r13d,%r13d
 1f818ff:	xor    %r15d,%r15d
 1f81902:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81910:	mov    0xc40(%r9),%rax
 1f81917:	mov    0x28(%rsp),%rsi
 1f8191c:	mov    0xc48(%r9),%rcx
 1f81923:	movzwl (%rax,%r13,2),%ebx
 1f81928:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f81930:	sub    %eax,%ebx
 1f81932:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f8193a:	mov    %ebx,%edx
 1f8193c:	sub    %eax,%edx
 1f8193e:	cmpb   $0x2,0x69454(%rsi,%rdx,1)
 1f81946:	mov    0x757d4(%rsi,%rdx,4),%eax
 1f8194d:	cmovne %r12,%rax
 1f81951:	movzbl (%rcx,%rax,1),%eax
 1f81955:	cmovne %ebp,%eax
 1f81958:	test   $0x8,%al
 1f8195a:	je     1f8196d <node_facts_window_run+0x449d>
 1f8195c:	movzbl %al,%eax
 1f8195f:	test   $0x10,%al
 1f81961:	jne    1f81991 <node_facts_window_run+0x44c1>
 1f81963:	inc    %r13
 1f81966:	cmp    %r13,%r14
 1f81969:	jne    1f81910 <node_facts_window_run+0x4440>
 1f8196b:	jmp    1f819b8 <node_facts_window_run+0x44e8>
 1f8196d:	mov    0x28(%rsp),%rsi
 1f81972:	mov    %r9,%rdi
 1f81975:	vzeroupper
 1f81978:	call   1f93d40 <node_tests_window_wants>
 1f8197d:	mov    0x18(%rsp),%r9
 1f81982:	mov    0x38(%rsp),%rdi
 1f81987:	movzbl %al,%eax
 1f8198a:	inc    %r15
 1f8198d:	test   $0x10,%al
 1f8198f:	je     1f81963 <node_facts_window_run+0x4493>
 1f81991:	mov    0xc38(%r9),%rdx
 1f81998:	mov    %ebx,%ecx
 1f8199a:	mov    $0xfffffffffffffffe,%rax
 1f819a1:	and    $0xffffffc0,%ebx
 1f819a4:	rol    %cl,%rax
 1f819a7:	and    %rax,0x20(%rdx,%rbx,1)
 1f819ac:	inc    %r13
 1f819af:	cmp    %r13,%r14
 1f819b2:	jne    1f81910 <node_facts_window_run+0x4440>
 1f819b8:	mov    0x28(%rsp),%r13
 1f819bd:	jmp    1f819ca <node_facts_window_run+0x44fa>
 1f819bf:	mov    0x18(%rsp),%r9
 1f819c4:	xor    %r14d,%r14d
 1f819c7:	xor    %r15d,%r15d
 1f819ca:	add    %r15,0x828(%rdi)
 1f819d1:	rdtsc
 1f819d3:	add    %r14,0x820(%rdi)
 1f819da:	mov    %rax,0x740(%rsp)
 1f819e2:	mov    %rdx,0x470(%rsp)
 1f819ea:	mov    0x8(%rsp),%rax
 1f819ef:	mov    0x68(%rsp),%rbp
 1f819f4:	mov    0x80(%rsp),%r12
 1f819fc:	cmpl   $0x0,0xa90(%rax)
 1f81a03:	je     1f828ea <node_facts_window_run+0x541a>
 1f81a09:	movzbl 0x88(%rsp),%eax
 1f81a11:	lea    0x42ec(%r13),%rdx
 1f81a18:	mov    $0xffffffffffffffff,%r14
 1f81a1f:	xor    %r8d,%r8d
 1f81a22:	xor    %r15d,%r15d
 1f81a25:	mov    %eax,0x6c0(%rsp)
 1f81a2c:	movzbl 0x40(%r9),%eax
 1f81a31:	shl    $0x1b,%rax
 1f81a35:	mov    %rax,0xb0(%rsp)
 1f81a3d:	mov    0xc0(%rsp),%rax
 1f81a45:	mov    (%rax),%rax
 1f81a48:	mov    0x6c8(%rax),%ecx
 1f81a4e:	mov    0x6e8(%rax),%eax
 1f81a54:	mov    %ecx,0x40(%rsp)
 1f81a58:	mov    %eax,0x820(%rsp)
 1f81a5f:	movzbl 0x3a(%r9),%eax
 1f81a64:	lea    0x422c(%r13),%rcx
 1f81a6b:	mov    %eax,0x98(%rsp)
 1f81a72:	movzbl 0x3c(%r9),%eax
 1f81a77:	mov    %eax,0xa8(%rsp)
 1f81a7e:	mov    0xb8(%rsp),%eax
 1f81a85:	mov    %rdx,0x70(%rsp)
 1f81a8a:	mov    %rcx,0x108(%rsp)
 1f81a92:	movl   $0x0,0x270(%rsp)
 1f81a9d:	movq   $0x0,0x2b0(%rsp)
 1f81aa9:	vpbroadcastd %eax,%zmm3
 1f81aaf:	jmp    1f81adb <node_facts_window_run+0x460b>
 1f81ab1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81ac0:	movb   $0x0,0x61(%rdx)
 1f81ac4:	mov    0x8(%rsp),%rax
 1f81ac9:	inc    %r15
 1f81acc:	mov    0xa90(%rax),%eax
 1f81ad2:	cmp    %rax,%r15
 1f81ad5:	jae    1f828ea <node_facts_window_run+0x541a>
 1f81adb:	mov    0x8(%rsp),%rax
 1f81ae0:	imul   $0x68,%r15,%rdx
 1f81ae4:	add    %rbp,%rdx
 1f81ae7:	mov    0xa88(%rax),%rax
 1f81aee:	cmpb   $0x0,(%rax,%r15,1)
 1f81af3:	je     1f81ac0 <node_facts_window_run+0x45f0>
 1f81af5:	mov    0x8(%rsp),%rax
 1f81afa:	mov    0xa50(%rax),%rax
 1f81b01:	mov    (%rax,%r15,4),%eax
 1f81b05:	cmp    0x20(%rdi),%eax
 1f81b08:	jae    1f81ac0 <node_facts_window_run+0x45f0>
 1f81b0a:	mov    0x18(%rdi),%rcx
 1f81b0e:	movzbl (%rcx,%rax,1),%eax
 1f81b12:	shr    $0x5,%al
 1f81b15:	and    $0x1,%al
 1f81b17:	mov    %al,0x61(%rdx)
 1f81b1a:	je     1f81ac4 <node_facts_window_run+0x45f4>
 1f81b1c:	mov    %rdx,0x2f0(%rsp)
 1f81b24:	mov    0xc30(%r9),%rcx
 1f81b2b:	mov    0x8(%rsp),%rax
 1f81b30:	mov    0xa70(%rax),%rax
 1f81b37:	mov    (%rax,%r15,4),%eax
 1f81b3b:	mov    0x651b8(%r13,%rax,4),%r12d
 1f81b43:	mov    %eax,%ebp
 1f81b45:	mov    %rax,0x570(%rsp)
 1f81b4d:	sub    %r12d,%ebp
 1f81b50:	inc    %ebp
 1f81b52:	mov    %ebp,%eax
 1f81b54:	mov    %rax,0x1f0(%rsp)
 1f81b5c:	test   %r12,%r12
 1f81b5f:	je     1f81b86 <node_facts_window_run+0x46b6>
 1f81b61:	lea    -0x1(%r12),%rdx
 1f81b66:	shr    $0x6,%rdx
 1f81b6a:	inc    %rdx
 1f81b6d:	mov    %edx,%eax
 1f81b6f:	and    $0x7,%eax
 1f81b72:	cmp    $0x1c1,%r12d
 1f81b79:	jae    1f81b8d <node_facts_window_run+0x46bd>
 1f81b7b:	vpxor  %xmm0,%xmm0,%xmm0
 1f81b7f:	xor    %esi,%esi
 1f81b81:	jmp    1f81cea <node_facts_window_run+0x481a>
 1f81b86:	xor    %eax,%eax
 1f81b88:	jmp    1f81d66 <node_facts_window_run+0x4896>
 1f81b8d:	mov    0x1f0(%rsp),%rsi
 1f81b95:	and    $0xfffffffffffffff8,%rdx
 1f81b99:	vpxor  %xmm0,%xmm0,%xmm0
 1f81b9d:	lea    0x1c0(%rcx,%rsi,1),%rdi
 1f81ba5:	xor    %esi,%esi
 1f81ba7:	nopw   0x0(%rax,%rax,1)
 1f81bb0:	lea    (%r12,%rsi,1),%r9
 1f81bb4:	mov    %r9d,%r8d
 1f81bb7:	sub    $0x40,%r9
 1f81bbb:	shlx   %r8,%r14,%r8
 1f81bc0:	not    %r8
 1f81bc3:	mov    %r8,%r10
 1f81bc6:	cmovae %r14,%r10
 1f81bca:	cmp    $0x40,%r9
 1f81bce:	shlx   %r9,%r14,%r9
 1f81bd3:	not    %r9
 1f81bd6:	kmovq  %r10,%k1
 1f81bdb:	cmovae %r14,%r9
 1f81bdf:	vmovdqu8 -0x1c0(%rdi),%zmm1{%k1}{z}
 1f81be6:	kmovq  %r9,%k1
 1f81beb:	lea    -0x80(%r12,%rsi,1),%r9
 1f81bf0:	vmovdqu8 -0x180(%rdi),%zmm2{%k1}{z}
 1f81bf7:	cmp    $0x40,%r9
 1f81bfb:	mov    %r8,%r9
 1f81bfe:	cmovae %r14,%r9
 1f81c02:	kmovq  %r9,%k1
 1f81c07:	lea    -0xc0(%r12,%rsi,1),%r9
 1f81c0f:	cmp    $0x40,%r9
 1f81c13:	mov    %r8,%r9
 1f81c16:	cmovae %r14,%r9
 1f81c1a:	vpternlogq $0xfe,%zmm1,%zmm0,%zmm2
 1f81c21:	vmovdqu8 -0x140(%rdi),%zmm0{%k1}{z}
 1f81c28:	kmovq  %r9,%k1
 1f81c2d:	lea    -0x100(%r12,%rsi,1),%r9
 1f81c35:	vmovdqu8 -0x100(%rdi),%zmm1{%k1}{z}
 1f81c3c:	cmp    $0x40,%r9
 1f81c40:	mov    %r8,%r9
 1f81c43:	cmovae %r14,%r9
 1f81c47:	kmovq  %r9,%k1
 1f81c4c:	lea    -0x140(%r12,%rsi,1),%r9
 1f81c54:	cmp    $0x40,%r9
 1f81c58:	mov    %r8,%r9
 1f81c5b:	cmovae %r14,%r9
 1f81c5f:	vpternlogq $0xfe,%zmm0,%zmm2,%zmm1
 1f81c66:	vmovdqu8 -0xc0(%rdi),%zmm0{%k1}{z}
 1f81c6d:	kmovq  %r9,%k1
 1f81c72:	lea    -0x180(%r12,%rsi,1),%r9
 1f81c7a:	vmovdqu8 -0x80(%rdi),%zmm2{%k1}{z}
 1f81c81:	cmp    $0x40,%r9
 1f81c85:	mov    %r8,%r9
 1f81c88:	cmovae %r14,%r9
 1f81c8c:	kmovq  %r9,%k1
 1f81c91:	lea    -0x1c0(%r12,%rsi,1),%r9
 1f81c99:	vmovdqu8 -0x40(%rdi),%zmm4{%k1}{z}
 1f81ca0:	cmp    $0x40,%r9
 1f81ca4:	cmovae %r14,%r8
 1f81ca8:	add    $0xfffffffffffffe00,%rsi
 1f81caf:	kmovq  %r8,%k1
 1f81cb4:	vpternlogq $0xfe,%zmm0,%zmm1,%zmm2
 1f81cbb:	vmovdqu8 (%rdi),%zmm0{%k1}{z}
 1f81cc1:	add    $0x200,%rdi
 1f81cc8:	add    $0xfffffffffffffff8,%rdx
 1f81ccc:	vpternlogq $0xfe,%zmm4,%zmm2,%zmm0
 1f81cd3:	jne    1f81bb0 <node_facts_window_run+0x46e0>
 1f81cd9:	test   %rax,%rax
 1f81cdc:	je     1f82809 <node_facts_window_run+0x5339>
 1f81ce2:	mov    0x18(%rsp),%r9
 1f81ce7:	neg    %rsi
 1f81cea:	mov    0x1f0(%rsp),%rdi
 1f81cf2:	lea    (%rcx,%rsi,1),%rdx
 1f81cf6:	shl    $0x6,%eax
 1f81cf9:	add    %rdi,%rdx
 1f81cfc:	mov    %r12,%rdi
 1f81cff:	sub    %rsi,%rdi
 1f81d02:	xor    %esi,%esi
 1f81d04:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81d10:	mov    %edi,%r8d
 1f81d13:	sub    $0x40,%rdi
 1f81d17:	shlx   %r8,%r14,%r8
 1f81d1c:	not    %r8
 1f81d1f:	cmovae %r14,%r8
 1f81d23:	kmovq  %r8,%k1
 1f81d28:	vmovdqu8 (%rdx,%rsi,1),%zmm1{%k1}{z}
 1f81d2f:	add    $0x40,%rsi
 1f81d33:	vporq  %zmm1,%zmm0,%zmm0
 1f81d39:	cmp    %rsi,%rax
 1f81d3c:	jne    1f81d10 <node_facts_window_run+0x4840>
 1f81d3e:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f81d45:	xor    %r8d,%r8d
 1f81d48:	vporq  %zmm1,%zmm0,%zmm0
 1f81d4e:	vextracti128 $0x1,%ymm0,%xmm1
 1f81d54:	vpor   %xmm1,%xmm0,%xmm0
 1f81d58:	vpshufd $0xee,%xmm0,%xmm1
 1f81d5d:	vpor   %xmm1,%xmm0,%xmm0
 1f81d61:	vmovq  %xmm0,%rax
 1f81d66:	mov    0x8(%rsp),%rsi
 1f81d6b:	mov    0xa58(%rsi),%rdx
 1f81d72:	mov    0xa68(%rsi),%rsi
 1f81d79:	mov    (%rdx,%r15,4),%edi
 1f81d7d:	mov    %rax,%rdx
 1f81d80:	shr    $0x20,%rdx
 1f81d84:	mov    (%rsi,%r15,4),%r10d
 1f81d88:	or     %rax,%rdx
 1f81d8b:	mov    %rdx,%rsi
 1f81d8e:	shr    $0x10,%rsi
 1f81d92:	or     %edx,%esi
 1f81d94:	mov    %esi,%eax
 1f81d96:	shr    $0x8,%eax
 1f81d99:	or     %esi,%eax
 1f81d9b:	mov    %edi,0x3b0(%rsp)
 1f81da2:	cmp    %r12d,%edi
 1f81da5:	jbe    1f81dab <node_facts_window_run+0x48db>
 1f81da7:	or     (%rcx,%r10,1),%al
 1f81dab:	movzbl %al,%esi
 1f81dae:	lea    0x0(,%rsi,8),%edx
 1f81db5:	lea    0x0(,%rsi,4),%ecx
 1f81dbc:	mov    %edx,%eax
 1f81dbe:	mov    %ecx,0x370(%rsp)
 1f81dc5:	and    $0x8,%eax
 1f81dc8:	and    $0x10,%ecx
 1f81dcb:	and    $0x40,%edx
 1f81dce:	or     %eax,%ecx
 1f81dd0:	mov    %esi,%eax
 1f81dd2:	and    $0x10,%eax
 1f81dd5:	lea    (%rcx,%rax,2),%eax
 1f81dd8:	or     %eax,%edx
 1f81dda:	mov    %esi,%eax
 1f81ddc:	and    $0x2,%eax
 1f81ddf:	mov    %rdx,0x1b0(%rsp)
 1f81de7:	mov    %rsi,0x650(%rsp)
 1f81def:	mov    %eax,0x610(%rsp)
 1f81df6:	mov    %r10,0x4b0(%rsp)
 1f81dfe:	je     1f81e17 <node_facts_window_run+0x4947>
 1f81e00:	cmpb   $0x1,0x26(%r9)
 1f81e05:	jne    1f81e17 <node_facts_window_run+0x4947>
 1f81e07:	movzbl 0x54(%r9),%eax
 1f81e0c:	shl    $0x11,%eax
 1f81e0f:	add    %rax,0x1b0(%rsp)
 1f81e17:	mov    0xc70(%r9),%rax
 1f81e1e:	mov    0x270(%rsp),%edx
 1f81e25:	mov    0xc78(%r9),%rcx
 1f81e2c:	mov    %ebp,%r11d
 1f81e2f:	mov    %r12d,%edi
 1f81e32:	shr    $0x6,%edi
 1f81e35:	and    $0x3f,%ebp
 1f81e38:	shr    $0x6,%r11d
 1f81e3c:	lea    (%rax,%rdx,8),%rsi
 1f81e40:	lea    (%rcx,%rdx,8),%r10
 1f81e44:	mov    %rsi,0x530(%rsp)
 1f81e4c:	mov    %r10,0x430(%rsp)
 1f81e54:	mov    %ebp,%r10d
 1f81e57:	xor    $0x3f,%r10d
 1f81e5b:	lea    0x1(%rdi),%rsi
 1f81e5f:	mov    %rbp,0x110(%rsp)
 1f81e67:	mov    %rdi,0x4f0(%rsp)
 1f81e6f:	mov    %r12,0x10(%rsp)
 1f81e74:	mov    %rsi,0x3f0(%rsp)
 1f81e7c:	cmp    $0x40,%r12d
 1f81e80:	jae    1f81e9e <node_facts_window_run+0x49ce>
 1f81e82:	mov    %r12,%r13
 1f81e85:	mov    $0xffffffff,%r14d
 1f81e8b:	xor    %esi,%esi
 1f81e8d:	movq   $0x0,0x20(%rsp)
 1f81e96:	xor    %r12d,%r12d
 1f81e99:	jmp    1f82122 <node_facts_window_run+0x4c52>
 1f81e9e:	shr    $1,%esi
 1f81ea0:	lea    0x8(%rax,%rdx,8),%rax
 1f81ea5:	lea    0x8(%rcx,%rdx,8),%rcx
 1f81eaa:	mov    %r15,0x5d0(%rsp)
 1f81eb2:	mov    %r11,0x90(%rsp)
 1f81eba:	shl    $0x6,%r11d
 1f81ebe:	mov    $0xffffffff,%r14d
 1f81ec4:	xor    %r9d,%r9d
 1f81ec7:	mov    %r12d,%r8d
 1f81eca:	xor    %ebp,%ebp
 1f81ecc:	shl    $0x7,%rsi
 1f81ed0:	mov    %rax,0x50(%rsp)
 1f81ed5:	mov    %r11,0x150(%rsp)
 1f81edd:	mov    %rcx,0x30(%rsp)
 1f81ee2:	mov    %rsi,0x230(%rsp)
 1f81eea:	xor    %esi,%esi
 1f81eec:	movq   $0x0,0x20(%rsp)
 1f81ef5:	data16 cs nopw 0x0(%rax,%rax,1)
 1f81f00:	mov    0x18(%rsp),%rdi
 1f81f05:	mov    %r8d,%r13d
 1f81f08:	sub    $0x40,%r13d
 1f81f0c:	mov    $0x40,%edx
 1f81f11:	mov    0x150(%rsp),%r11
 1f81f19:	mov    $0x0,%eax
 1f81f1e:	mov    0x50(%rsp),%r12
 1f81f23:	cmovb  %r8d,%edx
 1f81f27:	cmp    0x10(%rsp),%r9
 1f81f2c:	mov    0xc38(%rdi),%r15
 1f81f33:	cmovae %eax,%edx
 1f81f36:	mov    $0xffffffffffffffff,%rax
 1f81f3d:	add    %r11,%r15
 1f81f40:	cmp    $0x40,%edx
 1f81f43:	shlx   %rdx,%rax,%rdx
 1f81f48:	not    %rdx
 1f81f4b:	mov    0x58(%r9,%r15,1),%rbx
 1f81f50:	cmove  %rax,%rdx
 1f81f54:	mov    0x110(%rsp),%rax
 1f81f5c:	add    %rbx,%rbx
 1f81f5f:	shrx   %rax,0x18(%r9,%r15,1),%rcx
 1f81f66:	shlx   %r10,%rbx,%rbx
 1f81f6b:	or     %rcx,%rbx
 1f81f6e:	mov    0x48(%r9,%r15,1),%rcx
 1f81f73:	shrx   %rax,0x8(%r9,%r15,1),%r15
 1f81f7a:	and    %rdx,%rbx
 1f81f7d:	add    %rcx,%rcx
 1f81f80:	shlx   %r10,%rcx,%rcx
 1f81f85:	or     %r15,%rcx
 1f81f88:	and    %rdx,%rcx
 1f81f8b:	mov    %rcx,-0x8(%r12,%rsi,8)
 1f81f90:	mov    0xc38(%rdi),%rcx
 1f81f97:	mov    %r14d,%edi
 1f81f9a:	mov    %r11,%r14
 1f81f9d:	add    %r11,%rcx
 1f81fa0:	shrx   %rax,0x10(%r9,%rcx,1),%r11
 1f81fa7:	mov    0x50(%r9,%rcx,1),%rcx
 1f81fac:	add    %rcx,%rcx
 1f81faf:	shlx   %r10,%rcx,%r15
 1f81fb4:	mov    0x30(%rsp),%rcx
 1f81fb9:	or     %r11,%r15
 1f81fbc:	mov    %r9d,%r11d
 1f81fbf:	and    %rdx,%r15
 1f81fc2:	mov    0x20(%rsp),%rdx
 1f81fc7:	mov    %r15,-0x8(%rcx,%rsi,8)
 1f81fcc:	popcnt %rbx,%rcx
 1f81fd1:	add    %ecx,%edx
 1f81fd3:	lzcnt  %rbx,%rcx
 1f81fd8:	sub    %ecx,%r11d
 1f81fdb:	lea    0x40(%r9),%rcx
 1f81fdf:	add    $0x3f,%r11d
 1f81fe3:	test   %rbx,%rbx
 1f81fe6:	mov    %edi,%ebx
 1f81fe8:	mov    $0x40,%edi
 1f81fed:	cmovne %r11d,%ebx
 1f81ff1:	or     -0x8(%r12,%rsi,8),%rbp
 1f81ff6:	cmp    $0x40,%r13d
 1f81ffa:	mov    $0xffffffffffffffff,%r11
 1f82001:	cmovae %edi,%r13d
 1f82005:	cmp    0x10(%rsp),%rcx
 1f8200a:	mov    0x18(%rsp),%rdi
 1f8200f:	mov    $0x0,%ecx
 1f82014:	cmovae %ecx,%r13d
 1f82018:	mov    0xc38(%rdi),%rcx
 1f8201f:	add    %r14,%rcx
 1f82022:	shlx   %r13,%r11,%r14
 1f82027:	cmp    $0x40,%r13d
 1f8202b:	mov    0x98(%r9,%rcx,1),%r13
 1f82033:	not    %r14
 1f82036:	cmove  %r11,%r14
 1f8203a:	shrx   %rax,0x58(%r9,%rcx,1),%r11
 1f82041:	add    %r13,%r13
 1f82044:	shlx   %r10,%r13,%r13
 1f82049:	or     %r11,%r13
 1f8204c:	mov    0x88(%r9,%rcx,1),%r11
 1f82054:	shrx   %rax,0x48(%r9,%rcx,1),%rcx
 1f8205b:	and    %r14,%r13
 1f8205e:	add    %r11,%r11
 1f82061:	shlx   %r10,%r11,%r11
 1f82066:	or     %rcx,%r11
 1f82069:	and    %r14,%r11
 1f8206c:	mov    %r11,(%r12,%rsi,8)
 1f82070:	mov    0xc38(%rdi),%rcx
 1f82077:	add    0x150(%rsp),%rcx
 1f8207f:	shrx   %rax,0x50(%r9,%rcx,1),%r11
 1f82086:	mov    0x90(%r9,%rcx,1),%rcx
 1f8208e:	popcnt %r13,%rax
 1f82093:	add    %edx,%eax
 1f82095:	lzcnt  %r13,%rdx
 1f8209a:	mov    %rax,0x20(%rsp)
 1f8209f:	mov    0x30(%rsp),%rax
 1f820a4:	add    %rcx,%rcx
 1f820a7:	shlx   %r10,%rcx,%rcx
 1f820ac:	or     %r11,%rcx
 1f820af:	and    %r14,%rcx
 1f820b2:	mov    %r9d,%r14d
 1f820b5:	sub    %edx,%r14d
 1f820b8:	add    $0x7f,%r14d
 1f820bc:	test   %r13,%r13
 1f820bf:	mov    %rcx,(%rax,%rsi,8)
 1f820c3:	cmove  %ebx,%r14d
 1f820c7:	or     (%r12,%rsi,8),%rbp
 1f820cb:	add    $0x2,%rsi
 1f820cf:	sub    $0xffffffffffffff80,%r9
 1f820d3:	add    $0xffffff80,%r8d
 1f820d7:	or     %r15,%rbp
 1f820da:	or     %rcx,%rbp
 1f820dd:	cmp    %r9,0x230(%rsp)
 1f820e5:	jne    1f81f00 <node_facts_window_run+0x4a30>
 1f820eb:	mov    0x4f0(%rsp),%rcx
 1f820f3:	mov    0x18(%rsp),%r9
 1f820f8:	mov    0x5d0(%rsp),%r15
 1f82100:	mov    0x10(%rsp),%r13
 1f82105:	mov    0x90(%rsp),%r11
 1f8210d:	mov    $0x0,%r8d
 1f82113:	mov    %rbp,%r12
 1f82116:	inc    %rcx
 1f82119:	test   $0x1,%cl
 1f8211c:	je     1f82212 <node_facts_window_run+0x4d42>
 1f82122:	mov    %rsi,%rbx
 1f82125:	shl    $0x6,%rbx
 1f82129:	mov    %r13d,%ecx
 1f8212c:	mov    0xc38(%r9),%rdi
 1f82133:	mov    $0x40,%eax
 1f82138:	mov    $0xffffffffffffffff,%rdx
 1f8213f:	sub    %ebx,%ecx
 1f82141:	cmp    $0x40,%ecx
 1f82144:	cmovae %eax,%ecx
 1f82147:	cmp    %r13,%rbx
 1f8214a:	mov    0x110(%rsp),%rax
 1f82152:	cmovae %r8d,%ecx
 1f82156:	add    %rsi,%r11
 1f82159:	shl    $0x6,%r11
 1f8215d:	cmp    $0x40,%ecx
 1f82160:	shlx   %rcx,%rdx,%rcx
 1f82165:	mov    0x58(%rdi,%r11,1),%rbp
 1f8216a:	not    %rcx
 1f8216d:	cmove  %rdx,%rcx
 1f82171:	shrx   %rax,0x18(%rdi,%r11,1),%r8
 1f82178:	add    %rbp,%rbp
 1f8217b:	shlx   %r10,%rbp,%rdx
 1f82180:	mov    0x48(%rdi,%r11,1),%rbp
 1f82185:	shrx   %rax,0x8(%rdi,%r11,1),%rdi
 1f8218c:	or     %r8,%rdx
 1f8218f:	and    %rcx,%rdx
 1f82192:	add    %rbp,%rbp
 1f82195:	shlx   %r10,%rbp,%r8
 1f8219a:	mov    0x530(%rsp),%rbp
 1f821a2:	or     %rdi,%r8
 1f821a5:	and    %rcx,%r8
 1f821a8:	mov    %r8,0x0(%rbp,%rsi,8)
 1f821ad:	mov    0xc38(%r9),%rdi
 1f821b4:	shrx   %rax,0x10(%rdi,%r11,1),%r8
 1f821bb:	mov    0x20(%rsp),%rax
 1f821c0:	mov    0x50(%rdi,%r11,1),%rdi
 1f821c5:	mov    %eax,%r9d
 1f821c8:	popcnt %rdx,%rax
 1f821cd:	add    %rdi,%rdi
 1f821d0:	add    %r9d,%eax
 1f821d3:	shlx   %r10,%rdi,%rdi
 1f821d8:	mov    %rax,0x20(%rsp)
 1f821dd:	or     %r8,%rdi
 1f821e0:	mov    %r14d,%r8d
 1f821e3:	lea    0x3f(%rbx),%r14d
 1f821e7:	mov    0x430(%rsp),%rax
 1f821ef:	and    %rcx,%rdi
 1f821f2:	lzcnt  %rdx,%rcx
 1f821f7:	mov    0x18(%rsp),%r9
 1f821fc:	sub    %ecx,%r14d
 1f821ff:	test   %rdx,%rdx
 1f82202:	cmove  %r8d,%r14d
 1f82206:	mov    %rdi,(%rax,%rsi,8)
 1f8220a:	or     0x0(%rbp,%rsi,8),%r12
 1f8220f:	or     %rdi,%r12
 1f82212:	test   %r13d,%r13d
 1f82215:	je     1f82244 <node_facts_window_run+0x4d74>
 1f82217:	lea    -0x1(%r13),%rax
 1f8221b:	mov    $0xffffffff,%ebx
 1f82220:	shr    $0x4,%rax
 1f82224:	inc    %rax
 1f82227:	mov    %eax,%esi
 1f82229:	and    $0x3,%esi
 1f8222c:	cmp    $0x31,%r13d
 1f82230:	jae    1f8225e <node_facts_window_run+0x4d8e>
 1f82232:	vpxor  %xmm0,%xmm0,%xmm0
 1f82236:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f8223d:	xor    %ecx,%ecx
 1f8223f:	jmp    1f823a4 <node_facts_window_run+0x4ed4>
 1f82244:	mov    0x4b0(%rsp),%r10
 1f8224c:	mov    0x28(%rsp),%r13
 1f82251:	xor    %r11d,%r11d
 1f82254:	mov    $0xffffffff,%ecx
 1f82259:	jmp    1f82477 <node_facts_window_run+0x4fa7>
 1f8225e:	mov    %r15,0x5d0(%rsp)
 1f82266:	and    $0xfffffffffffffffc,%rax
 1f8226a:	lea    -0x30(%r13),%edi
 1f8226e:	lea    -0x20(%r13),%r8d
 1f82272:	lea    -0x10(%r13),%r9d
 1f82276:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f8227d:	mov    $0xffff,%r15d
 1f82283:	vpxor  %xmm0,%xmm0,%xmm0
 1f82287:	mov    0x70(%rsp),%rcx
 1f8228c:	mov    0x1f0(%rsp),%rdx
 1f82294:	lea    (%rcx,%rdx,4),%rdx
 1f82298:	xor    %ecx,%ecx
 1f8229a:	nopw   0x0(%rax,%rax,1)
 1f822a0:	lea    0x0(%r13,%rcx,1),%r10
 1f822a5:	shlx   %r10d,%ebx,%r11d
 1f822aa:	sub    $0x10,%r10
 1f822ae:	not    %r11d
 1f822b1:	cmovae %r15d,%r11d
 1f822b5:	cmp    $0x10,%r10
 1f822b9:	kmovd  %r11d,%k1
 1f822be:	lea    (%r9,%rcx,1),%r11d
 1f822c2:	vmovdqu32 -0xc0(%rdx),%zmm2{%k1}{z}
 1f822c9:	shlx   %r11d,%ebx,%r10d
 1f822ce:	lea    (%r8,%rcx,1),%r11d
 1f822d2:	not    %r10d
 1f822d5:	cmovae %r15d,%r10d
 1f822d9:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f822e0:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f822e6:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f822ec:	kmovd  %r10d,%k1
 1f822f1:	lea    -0x20(%r13,%rcx,1),%r10
 1f822f6:	vmovdqu32 -0x80(%rdx),%zmm2{%k1}{z}
 1f822fd:	cmp    $0x10,%r10
 1f82301:	shlx   %r11d,%ebx,%r10d
 1f82306:	lea    (%rdi,%rcx,1),%r11d
 1f8230a:	not    %r10d
 1f8230d:	cmovae %r15d,%r10d
 1f82311:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82318:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f8231e:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82324:	kmovd  %r10d,%k1
 1f82329:	lea    -0x30(%r13,%rcx,1),%r10
 1f8232e:	vmovdqu32 -0x40(%rdx),%zmm2{%k1}{z}
 1f82335:	cmp    $0x10,%r10
 1f82339:	shlx   %r11d,%ebx,%r10d
 1f8233e:	not    %r10d
 1f82341:	cmovae %r15d,%r10d
 1f82345:	add    $0xffffffffffffffc0,%rcx
 1f82349:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82350:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f82356:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f8235c:	kmovd  %r10d,%k1
 1f82361:	vmovdqu32 (%rdx),%zmm2{%k1}{z}
 1f82367:	add    $0x100,%rdx
 1f8236e:	add    $0xfffffffffffffffc,%rax
 1f82372:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82379:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f8237f:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82385:	jne    1f822a0 <node_facts_window_run+0x4dd0>
 1f8238b:	mov    0x18(%rsp),%r9
 1f82390:	mov    0x5d0(%rsp),%r15
 1f82398:	test   %rsi,%rsi
 1f8239b:	je     1f82813 <node_facts_window_run+0x5343>
 1f823a1:	neg    %rcx
 1f823a4:	mov    0x1f0(%rsp),%rax
 1f823ac:	mov    0x10(%rsp),%rdx
 1f823b1:	mov    0x4b0(%rsp),%r10
 1f823b9:	mov    0x28(%rsp),%r13
 1f823be:	mov    $0xffff,%r8d
 1f823c4:	shl    $0x4,%esi
 1f823c7:	lea    0x0(,%rax,4),%rax
 1f823cf:	sub    %rcx,%rdx
 1f823d2:	lea    (%rax,%rcx,4),%rax
 1f823d6:	add    0x108(%rsp),%rax
 1f823de:	xor    %ecx,%ecx
 1f823e0:	mov    %edx,%edi
 1f823e2:	sub    $0x10,%rdx
 1f823e6:	shlx   %edi,%ebx,%edi
 1f823eb:	not    %edi
 1f823ed:	cmovae %r8d,%edi
 1f823f1:	kmovd  %edi,%k1
 1f823f5:	vmovdqu32 (%rax,%rcx,4),%zmm2{%k1}{z}
 1f823fc:	add    $0x10,%rcx
 1f82400:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f82407:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f8240d:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f82413:	cmp    %rcx,%rsi
 1f82416:	jne    1f823e0 <node_facts_window_run+0x4f10>
 1f82418:	vextracti64x4 $0x1,%zmm1,%ymm2
 1f8241f:	vpminud %ymm2,%ymm1,%ymm1
 1f82424:	vextracti128 $0x1,%ymm1,%xmm2
 1f8242a:	vpminud %xmm2,%xmm1,%xmm1
 1f8242f:	vpshufd $0xee,%xmm1,%xmm2
 1f82434:	vpminud %xmm2,%xmm1,%xmm1
 1f82439:	vpshufd $0x55,%xmm1,%xmm2
 1f8243e:	vpminud %xmm2,%xmm1,%xmm1
 1f82443:	vmovd  %xmm1,%ecx
 1f82447:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f8244e:	vpmaxud %ymm1,%ymm0,%ymm0
 1f82453:	vextracti128 $0x1,%ymm0,%xmm1
 1f82459:	vpmaxud %xmm1,%xmm0,%xmm0
 1f8245e:	vpshufd $0xee,%xmm0,%xmm1
 1f82463:	vpmaxud %xmm1,%xmm0,%xmm0
 1f82468:	vpshufd $0x55,%xmm0,%xmm1
 1f8246d:	vpmaxud %xmm1,%xmm0,%xmm0
 1f82472:	vmovd  %xmm0,%r11d
 1f82477:	mov    0x370(%rsp),%eax
 1f8247e:	and    $0x100,%eax
 1f82483:	or     %rax,0x1b0(%rsp)
 1f8248b:	mov    0x3b0(%rsp),%eax
 1f82492:	mov    0x570(%rsp),%rbp
 1f8249a:	cmp    0x10(%rsp),%eax
 1f8249e:	mov    %r10d,%eax
 1f824a1:	cmovbe %ebp,%eax
 1f824a4:	mov    0x422c(%r13,%rax,4),%edx
 1f824ac:	mov    %rdx,0x150(%rsp)
 1f824b4:	ja     1f824bc <node_facts_window_run+0x4fec>
 1f824b6:	xor    %esi,%esi
 1f824b8:	xor    %edi,%edi
 1f824ba:	jmp    1f824de <node_facts_window_run+0x500e>
 1f824bc:	mov    0xc38(%r9),%rdi
 1f824c3:	mov    %r10d,%r8d
 1f824c6:	and    $0xffffffc0,%r8d
 1f824ca:	shrx   %r10,0x8(%rdi,%r8,1),%rsi
 1f824d1:	shrx   %r10,0x10(%rdi,%r8,1),%rdi
 1f824d8:	and    $0x1,%esi
 1f824db:	and    $0x1,%edi
 1f824de:	mov    0x4f0(%rsp),%r13
 1f824e6:	mov    0x10(%rsp),%r10
 1f824eb:	mov    0x530(%rsp),%rbx
 1f824f3:	mov    0x150(%rsp),%rdx
 1f824fb:	or     %rsi,%r12
 1f824fe:	or     %rdi,%r12
 1f82501:	shlx   %r10,%rsi,%r8
 1f82506:	shl    $0x3,%r13d
 1f8250a:	mov    %ecx,%esi
 1f8250c:	or     %r8,(%rbx,%r13,1)
 1f82510:	shlx   %r10,%rdi,%r8
 1f82515:	mov    0x430(%rsp),%r10
 1f8251d:	mov    0x2f0(%rsp),%rdi
 1f82525:	or     %r8,(%r10,%r13,1)
 1f82529:	cmp    %ecx,%edx
 1f8252b:	mov    %r11d,%r8d
 1f8252e:	cmovb  %edx,%esi
 1f82531:	cmp    %r11d,%edx
 1f82534:	cmova  %edx,%r8d
 1f82538:	cmp    0xb8(%rsp),%edx
 1f8253f:	cmovae %ecx,%esi
 1f82542:	mov    0x1b0(%rsp),%rcx
 1f8254a:	cmovae %r11d,%r8d
 1f8254e:	mov    %esi,%r11d
 1f82551:	mov    0x1f0(%rsp),%rsi
 1f82559:	mov    %rcx,(%rdi)
 1f8255c:	mov    %rbx,0x8(%rdi)
 1f82560:	mov    %r10,0x10(%rdi)
 1f82564:	mov    0x3f0(%rsp),%r10
 1f8256c:	mov    %r10d,0x18(%rdi)
 1f82570:	mov    0xc10(%r9),%rcx
 1f82577:	add    %rsi,%rcx
 1f8257a:	mov    %rcx,0x20(%rdi)
 1f8257e:	mov    0xc20(%r9),%rcx
 1f82585:	add    %rsi,%rcx
 1f82588:	mov    %rcx,0x28(%rdi)
 1f8258c:	mov    0x610(%rsp),%ecx
 1f82593:	mov    %r8d,0x30(%rsp)
 1f82598:	add    0xc28(%r9),%rsi
 1f8259f:	shl    $0x2,%ecx
 1f825a2:	mov    %rsi,0x30(%rdi)
 1f825a6:	mov    0x20(%rsp),%rsi
 1f825ab:	mov    %r11d,0x38(%rdi)
 1f825af:	mov    %r8d,0x3c(%rdi)
 1f825b3:	mov    $0x0,%r8d
 1f825b9:	mov    %esi,0x40(%rdi)
 1f825bc:	mov    0x370(%rsp),%esi
 1f825c3:	mov    %r14d,0x44(%rdi)
 1f825c7:	mov    %ecx,0x48(%rdi)
 1f825ca:	and    $0x80,%esi
 1f825d0:	cmpl   $0x0,0x40(%rsp)
 1f825d5:	mov    %esi,0x4c(%rdi)
 1f825d8:	je     1f82611 <node_facts_window_run+0x5141>
 1f825da:	cmp    0xb8(%rsp),%edx
 1f825e1:	mov    %edx,%ecx
 1f825e3:	cmovae %r8d,%ecx
 1f825e7:	jae    1f82611 <node_facts_window_run+0x5141>
 1f825e9:	mov    %r11d,%ebx
 1f825ec:	mov    0xc08(%r9),%r11
 1f825f3:	mov    %ecx,%esi
 1f825f5:	mov    $0x1,%edi
 1f825fa:	shr    $0x6,%ecx
 1f825fd:	mov    $0x6,%r13d
 1f82603:	shlx   %rsi,%rdi,%rsi
 1f82608:	and    (%r11,%rcx,8),%rsi
 1f8260c:	mov    %ebx,%r11d
 1f8260f:	jne    1f82637 <node_facts_window_run+0x5167>
 1f82611:	mov    0xd0(%rsp),%rcx
 1f82619:	movzbl (%rcx,%rax,1),%eax
 1f8261d:	and    $0x7f,%eax
 1f82620:	cmpl   $0x0,0x820(%rsp)
 1f82628:	movzbl 0x548(%r9,%rax,1),%r13d
 1f82631:	jne    1f82884 <node_facts_window_run+0x53b4>
 1f82637:	mov    0x10(%rsp),%rsi
 1f8263c:	mov    0xc38(%r9),%rdx
 1f82643:	mov    %ebp,%ecx
 1f82645:	mov    0x650(%rsp),%rdi
 1f8264d:	mov    $0x0,%ebx
 1f82652:	cmp    %esi,0x3b0(%rsp)
 1f82659:	setbe  %al
 1f8265c:	and    $0xffffffc0,%ecx
 1f8265f:	inc    %r14d
 1f82662:	and    $0x22,%edi
 1f82665:	shrx   %rbp,0x20(%rdx,%rcx,1),%rcx
 1f8266c:	mov    0x20(%rsp),%rbp
 1f82671:	xor    %esi,%r14d
 1f82674:	mov    0x98(%rsp),%esi
 1f8267b:	mov    %ebp,%edx
 1f8267d:	xor    $0x1,%edx
 1f82680:	cmp    $0x2,%r13d
 1f82684:	cmovne %r8d,%esi
 1f82688:	test   %edi,%edi
 1f8268a:	cmove  %edi,%esi
 1f8268d:	test   %r12,%r12
 1f82690:	setne  %dil
 1f82694:	or     %al,%dil
 1f82697:	or     %r14d,%edx
 1f8269a:	cmovne 0xa8(%rsp),%ebx
 1f826a2:	test   %ebp,%ebp
 1f826a4:	movzbl %dil,%eax
 1f826a8:	cmove  %ebp,%ebx
 1f826ab:	or     %eax,%ebx
 1f826ad:	xor    %eax,%eax
 1f826af:	test   %r13d,%r13d
 1f826b2:	sete   %al
 1f826b5:	or     %esi,%ebx
 1f826b7:	andn   %eax,%ecx,%eax
 1f826bc:	mov    $0x101,%ecx
 1f826c1:	or     %eax,%ebx
 1f826c3:	mov    0x8(%rsp),%rax
 1f826c8:	mov    %r13d,0x10(%rsp)
 1f826cd:	mov    0xb0(%rsp),%rdx
 1f826d5:	mov    0xa88(%rax),%rax
 1f826dc:	movzbl (%rax,%r15,1),%eax
 1f826e1:	bextr  %ecx,%eax,%eax
 1f826e6:	or     %eax,%ebx
 1f826e8:	xor    %eax,%eax
 1f826ea:	cmp    $0x6,%r13d
 1f826ee:	mov    0x28(%rsp),%r13
 1f826f3:	sete   %al
 1f826f6:	lea    (%rdx,%rax,4),%r14
 1f826fa:	or     0x1b0(%rsp),%r14
 1f82702:	cmpb   $0x1,0x3b(%r9)
 1f82707:	jne    1f82774 <node_facts_window_run+0x52a4>
 1f82709:	mov    0x68(%rsp),%rbp
 1f8270e:	mov    0x80(%rsp),%r12
 1f82716:	mov    0x38(%rsp),%rdi
 1f8271b:	test   %ebx,%ebx
 1f8271d:	jne    1f82786 <node_facts_window_run+0x52b6>
 1f8271f:	mov    0xc0(%rsp),%rax
 1f82727:	mov    0x150(%rsp),%rsi
 1f8272f:	mov    0x8(%rax),%rdx
 1f82733:	mov    0x78(%rdx),%eax
 1f82736:	cmp    %eax,%esi
 1f82738:	jae    1f82786 <node_facts_window_run+0x52b6>
 1f8273a:	mov    0x98(%rdx),%rcx
 1f82741:	movzbl (%rcx,%rsi,1),%esi
 1f82745:	cmp    $0x4a,%esi
 1f82748:	je     1f8276b <node_facts_window_run+0x529b>
 1f8274a:	cmp    $0x1e,%esi
 1f8274d:	jne    1f82786 <node_facts_window_run+0x52b6>
 1f8274f:	mov    0xa8(%rdx),%rdx
 1f82756:	mov    0x150(%rsp),%rsi
 1f8275e:	mov    (%rdx,%rsi,4),%edx
 1f82761:	cmp    %eax,%edx
 1f82763:	jae    1f82786 <node_facts_window_run+0x52b6>
 1f82765:	cmpb   $0x4a,(%rcx,%rdx,1)
 1f82769:	jne    1f82786 <node_facts_window_run+0x52b6>
 1f8276b:	or     $0x1000000,%r14
 1f82772:	jmp    1f82786 <node_facts_window_run+0x52b6>
 1f82774:	mov    0x68(%rsp),%rbp
 1f82779:	mov    0x80(%rsp),%r12
 1f82781:	mov    0x38(%rsp),%rdi
 1f82786:	cmpl   $0x0,0xc00(%r9)
 1f8278e:	mov    0x2f0(%rsp),%rdx
 1f82796:	mov    0x30(%rsp),%ecx
 1f8279a:	jne    1f82825 <node_facts_window_run+0x5355>
 1f827a0:	cmp    0xbe8(%r9),%r11d
 1f827a7:	ja     1f827b2 <node_facts_window_run+0x52e2>
 1f827a9:	cmp    0xbe4(%r9),%ecx
 1f827b0:	jae    1f82825 <node_facts_window_run+0x5355>
 1f827b2:	mov    0x10(%rsp),%eax
 1f827b6:	mov    %r14,0x50(%rdx)
 1f827ba:	add    0x270(%rsp),%r10d
 1f827c2:	mov    $0xffffffffffffffff,%r14
 1f827c9:	mov    %al,0x60(%rdx)
 1f827cc:	mov    %r11d,0x58(%rdx)
 1f827d0:	mov    %ecx,0x5c(%rdx)
 1f827d3:	mov    %bl,0x62(%rdx)
 1f827d6:	mov    0x2b0(%rsp),%rdx
 1f827de:	or     0x6c0(%rsp),%ebx
 1f827e5:	mov    0xc88(%r9),%rax
 1f827ec:	mov    %edx,%ecx
 1f827ee:	add    %ebx,%edx
 1f827f0:	mov    %rdx,0x2b0(%rsp)
 1f827f8:	mov    %r15d,(%rax,%rcx,4)
 1f827fc:	mov    %r10d,0x270(%rsp)
 1f82804:	jmp    1f81ac4 <node_facts_window_run+0x45f4>
 1f82809:	mov    0x18(%rsp),%r9
 1f8280e:	jmp    1f81d3e <node_facts_window_run+0x486e>
 1f82813:	mov    0x4b0(%rsp),%r10
 1f8281b:	mov    0x28(%rsp),%r13
 1f82820:	jmp    1f82418 <node_facts_window_run+0x4f48>
 1f82825:	mov    0x150(%rsp),%rsi
 1f8282d:	vmovdqu64 %zmm3,0x110(%rsp)
 1f82838:	mov    %r9,%rdi
 1f8283b:	mov    %r11d,%edx
 1f8283e:	mov    %r11d,0x20(%rsp)
 1f82843:	vzeroupper
 1f82846:	call   1f6a0d0 <node_census_reader_marks>
 1f8284b:	vmovdqu64 0x110(%rsp),%zmm3
 1f82856:	mov    0x20(%rsp),%r11d
 1f8285b:	mov    0x3f0(%rsp),%r10
 1f82863:	mov    0x2f0(%rsp),%rdx
 1f8286b:	mov    0x18(%rsp),%r9
 1f82870:	mov    0x38(%rsp),%rdi
 1f82875:	mov    0x30(%rsp),%ecx
 1f82879:	or     %rax,%r14
 1f8287c:	xor    %r8d,%r8d
 1f8287f:	jmp    1f827b2 <node_facts_window_run+0x52e2>
 1f82884:	cmp    $0x2,%r13d
 1f82888:	jne    1f82637 <node_facts_window_run+0x5167>
 1f8288e:	mov    0xc0(%rsp),%rax
 1f82896:	vmovdqu64 %zmm3,0x110(%rsp)
 1f828a1:	mov    %r11d,%ebx
 1f828a4:	mov    (%rax),%rax
 1f828a7:	mov    0x6e0(%rax),%rdi
 1f828ae:	mov    0x6e8(%rax),%esi
 1f828b4:	vzeroupper
 1f828b7:	call   1f69cb0 <node_census_cleans>
 1f828bc:	vmovdqu64 0x110(%rsp),%zmm3
 1f828c7:	mov    0x3f0(%rsp),%r10
 1f828cf:	mov    0x18(%rsp),%r9
 1f828d4:	movzbl %al,%eax
 1f828d7:	mov    %ebx,%r11d
 1f828da:	xor    %r8d,%r8d
 1f828dd:	lea    0x2(,%rax,4),%r13d
 1f828e5:	jmp    1f82637 <node_facts_window_run+0x5167>
 1f828ea:	rdtsc
 1f828ec:	mov    %rdx,0x20(%rsp)
 1f828f1:	mov    %rax,0x150(%rsp)
 1f828f9:	cmpb   $0x0,0x88(%rsp)
 1f82901:	je     1f82a91 <node_facts_window_run+0x55c1>
 1f82907:	mov    0x8(%rsp),%rax
 1f8290c:	cmpl   $0x0,0xa90(%rax)
 1f82913:	je     1f82a91 <node_facts_window_run+0x55c1>
 1f82919:	mov    $0xffffffffffffffff,%rdx
 1f82920:	xor    %esi,%esi
 1f82922:	jmp    1f82947 <node_facts_window_run+0x5477>
 1f82924:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82930:	mov    0x8(%rsp),%rax
 1f82935:	inc    %rsi
 1f82938:	mov    0xa90(%rax),%eax
 1f8293e:	cmp    %rax,%rsi
 1f82941:	jae    1f82a91 <node_facts_window_run+0x55c1>
 1f82947:	imul   $0x68,%rsi,%r10
 1f8294b:	cmpb   $0x0,0x61(%rbp,%r10,1)
 1f82951:	je     1f82930 <node_facts_window_run+0x5460>
 1f82953:	mov    0x8(%rsp),%rax
 1f82958:	add    %rbp,%r10
 1f8295b:	mov    $0x40,%ecx
 1f82960:	mov    0xa70(%rax),%r8
 1f82967:	mov    0xa68(%rax),%rdi
 1f8296e:	mov    (%rdi,%rsi,4),%eax
 1f82971:	mov    (%r8,%rsi,4),%r11d
 1f82975:	mov    0x10(%r10),%r8
 1f82979:	sub    0xc78(%r9),%r8
 1f82980:	add    0xc80(%r9),%r8
 1f82987:	mov    %rax,0x10(%rsp)
 1f8298c:	xor    %eax,%eax
 1f8298e:	mov    0x651b8(%r13,%r11,4),%edi
 1f82996:	cmpl   $0x0,0x18(%r10)
 1f8299b:	je     1f82a37 <node_facts_window_run+0x5567>
 1f829a1:	sub    %edi,%r11d
 1f829a4:	mov    %edi,%r13d
 1f829a7:	xor    %r15d,%r15d
 1f829aa:	xor    %r12d,%r12d
 1f829ad:	mov    %edi,%ebp
 1f829af:	inc    %r11d
 1f829b2:	mov    %r11d,%ebx
 1f829b5:	and    $0x3f,%r11d
 1f829b9:	and    $0xffffffc0,%ebx
 1f829bc:	mov    %r11d,%r14d
 1f829bf:	xor    $0x3f,%r14d
 1f829c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f829d0:	mov    0x18(%rsp),%r9
 1f829d5:	sub    $0x40,%ebp
 1f829d8:	cmovae %ecx,%r13d
 1f829dc:	cmp    %r15d,%edi
 1f829df:	cmovbe %eax,%r13d
 1f829e3:	mov    0xc38(%r9),%r9
 1f829ea:	add    %rbx,%r9
 1f829ed:	cmp    $0x40,%r13d
 1f829f1:	shlx   %r13,%rdx,%r13
 1f829f6:	shrx   %r11,(%r15,%r9,1),%rax
 1f829fc:	mov    0x40(%r15,%r9,1),%r9
 1f82a01:	not    %r13
 1f82a04:	cmove  %rdx,%r13
 1f82a08:	add    $0x40,%r15
 1f82a0c:	add    %r9,%r9
 1f82a0f:	shlx   %r14,%r9,%r9
 1f82a14:	or     %rax,%r9
 1f82a17:	and    %r13,%r9
 1f82a1a:	mov    %ebp,%r13d
 1f82a1d:	mov    %r9,(%r8,%r12,8)
 1f82a21:	mov    0x18(%rsp),%r9
 1f82a26:	inc    %r12
 1f82a29:	mov    0x18(%r10),%eax
 1f82a2d:	cmp    %rax,%r12
 1f82a30:	mov    $0x0,%eax
 1f82a35:	jb     1f829d0 <node_facts_window_run+0x5500>
 1f82a37:	mov    0x8(%rsp),%rax
 1f82a3c:	mov    0x28(%rsp),%r13
 1f82a41:	mov    0x68(%rsp),%rbp
 1f82a46:	mov    0x80(%rsp),%r12
 1f82a4e:	mov    0xa58(%rax),%r10
 1f82a55:	cmp    %edi,(%r10,%rsi,4)
 1f82a59:	jbe    1f82930 <node_facts_window_run+0x5460>
 1f82a5f:	mov    0x10(%rsp),%rcx
 1f82a64:	mov    0xc38(%r9),%rax
 1f82a6b:	mov    %ecx,%r9d
 1f82a6e:	and    $0xffffffc0,%r9d
 1f82a72:	shrx   %rcx,(%rax,%r9,1),%rax
 1f82a78:	mov    0x18(%rsp),%r9
 1f82a7d:	and    $0x1,%eax
 1f82a80:	shlx   %rdi,%rax,%rax
 1f82a85:	shr    $0x6,%edi
 1f82a88:	or     %rax,(%r8,%rdi,8)
 1f82a8c:	jmp    1f82930 <node_facts_window_run+0x5460>
 1f82a91:	shlq   $0x20,0xe8(%rsp)
 1f82a9a:	shlq   $0x20,0x490(%rsp)
 1f82aa3:	shlq   $0x20,0x470(%rsp)
 1f82aac:	shlq   $0x20,0x20(%rsp)
 1f82ab2:	lea    0x8f0(%rsp),%rdi
 1f82aba:	mov    $0x418,%edx
 1f82abf:	mov    %r12,%rsi
 1f82ac2:	vzeroupper
 1f82ac5:	call   355eaf0 <memcpy>
 1f82aca:	mov    0x2b0(%rsp),%rax
 1f82ad2:	movb   $0x0,0x5b(%r12)
 1f82ad8:	test   %eax,%eax
 1f82ada:	je     1f82dac <node_facts_window_run+0x58dc>
 1f82ae0:	mov    0x8(%rsp),%rdi
 1f82ae5:	mov    0x18(%rsp),%r9
 1f82aea:	mov    %eax,%eax
 1f82aec:	xor    %r15d,%r15d
 1f82aef:	mov    %rax,0x10(%rsp)
 1f82af4:	jmp    1f82b53 <node_facts_window_run+0x5683>
 1f82af6:	cs nopw 0x0(%rax,%rax,1)
 1f82b00:	movzbl 0x7c0(%rsp),%ecx
 1f82b08:	mov    0x8(%rsp),%rdi
 1f82b0d:	mov    0x18(%rsp),%r9
 1f82b12:	mov    0x68(%rsp),%rbp
 1f82b17:	xor    %edx,%edx
 1f82b19:	add    %rdx,0x8a0(%r8)
 1f82b20:	mov    %rax,0x50(%r12)
 1f82b25:	mov    %cl,0x60(%r12)
 1f82b2a:	mov    0x10(%rsp),%rcx
 1f82b2f:	inc    %r15
 1f82b32:	mov    0x634(%r9),%eax
 1f82b39:	mov    %eax,0x58(%r12)
 1f82b3e:	mov    0x638(%r9),%eax
 1f82b45:	mov    %eax,0x5c(%r12)
 1f82b4a:	cmp    %r15,%rcx
 1f82b4d:	je     1f82d4d <node_facts_window_run+0x587d>
 1f82b53:	mov    0xc88(%r9),%rax
 1f82b5a:	mov    0xa68(%rdi),%r8
 1f82b61:	mov    0xa70(%rdi),%rcx
 1f82b68:	mov    %r13,%r14
 1f82b6b:	mov    (%rax,%r15,4),%r12d
 1f82b6f:	mov    0xa58(%rdi),%rax
 1f82b76:	mov    (%r8,%r12,4),%ebp
 1f82b7a:	mov    (%rcx,%r12,4),%r13d
 1f82b7e:	mov    0xa48(%rdi),%r8
 1f82b85:	mov    0xa50(%rdi),%rcx
 1f82b8c:	mov    0x80(%rsp),%rdi
 1f82b94:	mov    (%rcx,%r12,4),%ebx
 1f82b98:	mov    (%r8,%r12,4),%esi
 1f82b9c:	mov    (%rax,%r12,4),%ecx
 1f82ba0:	mov    %ebx,%edx
 1f82ba2:	call   1f53190 <node_machine_type>
 1f82ba7:	mov    0x8(%rsp),%rax
 1f82bac:	mov    0xa58(%rax),%rax
 1f82bb3:	mov    (%rax,%r12,4),%eax
 1f82bb7:	cmp    0x651b8(%r14,%r13,4),%eax
 1f82bbf:	jbe    1f82bfc <node_facts_window_run+0x572c>
 1f82bc1:	inc    %r13d
 1f82bc4:	cmp    %r13d,%ebp
 1f82bc7:	je     1f82bfc <node_facts_window_run+0x572c>
 1f82bc9:	mov    0x18(%rsp),%rsi
 1f82bce:	mov    %r13d,%eax
 1f82bd1:	mov    0xc10(%rsi),%rdx
 1f82bd8:	mov    0xc28(%rsi),%rcx
 1f82bdf:	mov    0xc20(%rsi),%rsi
 1f82be6:	movzbl (%rdx,%rbp,1),%edi
 1f82bea:	mov    %dil,(%rdx,%rax,1)
 1f82bee:	movzbl (%rsi,%rbp,1),%edx
 1f82bf2:	mov    %dl,(%rsi,%rax,1)
 1f82bf5:	movzbl (%rcx,%rbp,1),%edx
 1f82bf9:	mov    %dl,(%rcx,%rax,1)
 1f82bfc:	mov    0x28(%rsp),%r13
 1f82c01:	xor    %r9d,%r9d
 1f82c04:	mov    0xc0(%rsp),%rdx
 1f82c0c:	mov    $0xffffffff,%r8d
 1f82c12:	mov    0x422c(%r13,%rbp,4),%ecx
 1f82c1a:	cmpb   $0x23,0x2c(%r13,%rbp,1)
 1f82c20:	jne    1f82c4d <node_facts_window_run+0x577d>
 1f82c22:	cmp    0xb8(%rsp),%ecx
 1f82c29:	jae    1f82c4d <node_facts_window_run+0x577d>
 1f82c2b:	mov    0x338(%rdx),%rax
 1f82c32:	mov    (%rdx),%rsi
 1f82c35:	mov    (%rax,%rcx,4),%r8d
 1f82c39:	cmp    0x764(%rsi),%r8d
 1f82c40:	jae    1f82c4d <node_facts_window_run+0x577d>
 1f82c42:	mov    0x1e8(%rdx),%rax
 1f82c49:	mov    (%rax,%r8,4),%r9d
 1f82c4d:	imul   $0x68,%r12,%r12
 1f82c51:	add    0x68(%rsp),%r12
 1f82c56:	cmpb   $0x0,0x88(%rsp)
 1f82c5e:	movb   $0x0,0x7c0(%rsp)
 1f82c66:	je     1f82c90 <node_facts_window_run+0x57c0>
 1f82c68:	mov    0x18(%rsp),%rdi
 1f82c6d:	mov    0x10(%r12),%rax
 1f82c72:	sub    0xc78(%rdi),%rax
 1f82c79:	add    0xc80(%rdi),%rax
 1f82c80:	jmp    1f82c97 <node_facts_window_run+0x57c7>
 1f82c82:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82c90:	mov    0x18(%rsp),%rdi
 1f82c95:	xor    %eax,%eax
 1f82c97:	movzbl 0x88(%rsp),%edx
 1f82c9f:	mov    %rax,0x5d0(%rdi)
 1f82ca6:	mov    0xd0(%rsp),%rax
 1f82cae:	mov    %ebx,%esi
 1f82cb0:	mov    %dl,0x5d8(%rdi)
 1f82cb6:	movzbl (%rax,%rbp,1),%edx
 1f82cba:	push   %r12
 1f82cbc:	lea    0x7c8(%rsp),%rax
 1f82cc4:	push   %rax
 1f82cc5:	call   1f54a70 <node_census_reader_expression>
 1f82cca:	add    $0x10,%rsp
 1f82cce:	cmpb   $0x1,0x62(%r12)
 1f82cd4:	mov    0x38(%rsp),%r8
 1f82cd9:	adcq   $0x0,0x898(%r8)
 1f82ce1:	cmpb   $0x0,0x62(%r12)
 1f82ce7:	jne    1f82b00 <node_facts_window_run+0x5630>
 1f82ced:	movzbl 0x7c0(%rsp),%ecx
 1f82cf5:	mov    0x8(%rsp),%rdi
 1f82cfa:	mov    0x68(%rsp),%rbp
 1f82cff:	mov    $0x1,%edx
 1f82d04:	cmp    0x50(%r12),%rax
 1f82d09:	jne    1f82d43 <node_facts_window_run+0x5873>
 1f82d0b:	mov    0x18(%rsp),%r9
 1f82d10:	cmp    0x60(%r12),%cl
 1f82d15:	jne    1f82b19 <node_facts_window_run+0x5649>
 1f82d1b:	mov    0x634(%r9),%esi
 1f82d22:	cmp    0x58(%r12),%esi
 1f82d27:	jne    1f82b19 <node_facts_window_run+0x5649>
 1f82d2d:	mov    0x638(%r9),%esi
 1f82d34:	xor    %edx,%edx
 1f82d36:	cmp    0x5c(%r12),%esi
 1f82d3b:	setne  %dl
 1f82d3e:	jmp    1f82b19 <node_facts_window_run+0x5649>
 1f82d43:	mov    0x18(%rsp),%r9
 1f82d48:	jmp    1f82b19 <node_facts_window_run+0x5649>
 1f82d4d:	rdtsc
 1f82d4f:	xor    %ebx,%ebx
 1f82d51:	mov    %rdi,%r15
 1f82d54:	mov    %r9,%r14
 1f82d57:	shl    $0x20,%rdx
 1f82d5b:	or     %rax,%rdx
 1f82d5e:	mov    %rdx,0x30(%rsp)
 1f82d63:	mov    0x80(%rsp),%r12
 1f82d6b:	nopl   0x0(%rax,%rax,1)
 1f82d70:	mov    0xc88(%r14),%rax
 1f82d77:	mov    0xa48(%r15),%rcx
 1f82d7e:	mov    0xa50(%r15),%rdx
 1f82d85:	mov    %r12,%rdi
 1f82d88:	mov    (%rax,%rbx,4),%eax
 1f82d8b:	mov    (%rcx,%rax,4),%esi
 1f82d8e:	mov    0xa58(%r15),%rcx
 1f82d95:	mov    (%rdx,%rax,4),%edx
 1f82d98:	mov    (%rcx,%rax,4),%ecx
 1f82d9b:	call   1f53190 <node_machine_type>
 1f82da0:	inc    %rbx
 1f82da3:	cmp    %rbx,0x10(%rsp)
 1f82da8:	jne    1f82d70 <node_facts_window_run+0x58a0>
 1f82daa:	jmp    1f82dba <node_facts_window_run+0x58ea>
 1f82dac:	rdtsc
 1f82dae:	shl    $0x20,%rdx
 1f82db2:	or     %rax,%rdx
 1f82db5:	mov    %rdx,0x30(%rsp)
 1f82dba:	mov    0xe8(%rsp),%rax
 1f82dc2:	lea    0x8f0(%rsp),%rsi
 1f82dca:	mov    %r12,%rdi
 1f82dcd:	or     %rax,0xf0(%rsp)
 1f82dd5:	mov    0x490(%rsp),%rax
 1f82ddd:	or     %rax,0x780(%rsp)
 1f82de5:	rdtsc
 1f82de7:	mov    0x470(%rsp),%rcx
 1f82def:	shl    $0x20,%rdx
 1f82df3:	or     %rcx,0x740(%rsp)
 1f82dfb:	mov    0x20(%rsp),%rcx
 1f82e00:	or     %rcx,0x150(%rsp)
 1f82e08:	or     %rax,%rdx
 1f82e0b:	mov    %rdx,0x110(%rsp)
 1f82e13:	mov    $0x418,%edx
 1f82e18:	call   355eaf0 <memcpy>
 1f82e1d:	mov    0x8(%rsp),%r11
 1f82e22:	cmpl   $0x0,0xa90(%r11)
 1f82e2a:	je     1f8309e <node_facts_window_run+0x5bce>
 1f82e30:	xorb   $0x1,0x88(%rsp)
 1f82e38:	add    $0x62,%rbp
 1f82e3c:	xor    %r14d,%r14d
 1f82e3f:	xor    %eax,%eax
 1f82e41:	mov    0x38(%rsp),%r8
 1f82e46:	mov    0x18(%rsp),%rdi
 1f82e4b:	jmp    1f82e6d <node_facts_window_run+0x599d>
 1f82e4d:	nopl   (%rax)
 1f82e50:	mov    %rax,%r15
 1f82e53:	mov    0xa90(%r11),%ecx
 1f82e5a:	inc    %r14
 1f82e5d:	add    $0x68,%rbp
 1f82e61:	mov    %r15,%rax
 1f82e64:	cmp    %rcx,%r14
 1f82e67:	jae    1f830a6 <node_facts_window_run+0x5bd6>
 1f82e6d:	cmpb   $0x0,-0x1(%rbp)
 1f82e71:	je     1f82e50 <node_facts_window_run+0x5980>
 1f82e73:	xor    %edx,%edx
 1f82e75:	cmpb   $0x0,0x0(%rbp)
 1f82e79:	mov    0xa70(%r11),%rcx
 1f82e80:	sete   %dl
 1f82e83:	mov    (%rcx,%r14,4),%ecx
 1f82e87:	add    %rdx,0x890(%r8)
 1f82e8e:	and    0x88(%rsp),%dl
 1f82e95:	movzbl %dl,%edx
 1f82e98:	add    %rdx,0x690(%r8)
 1f82e9f:	cmp    $0x1,%dl
 1f82ea2:	jne    1f82ec0 <node_facts_window_run+0x59f0>
 1f82ea4:	mov    0xa58(%r11),%rdx
 1f82eab:	mov    (%rdx,%r14,4),%edx
 1f82eaf:	jmp    1f82ec2 <node_facts_window_run+0x59f2>
 1f82eb1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82ec0:	xor    %edx,%edx
 1f82ec2:	add    %rdx,0x698(%r8)
 1f82ec9:	mov    0xa58(%r11),%rdx
 1f82ed0:	mov    (%rdx,%r14,4),%edx
 1f82ed4:	cmp    0x651b8(%r13,%rcx,4),%edx
 1f82edc:	jbe    1f82f00 <node_facts_window_run+0x5a30>
 1f82ede:	mov    0xa68(%r11),%rdx
 1f82ee5:	inc    %ecx
 1f82ee7:	xor    %r15d,%r15d
 1f82eea:	cmp    %ecx,(%rdx,%r14,4)
 1f82eee:	setne  %r15b
 1f82ef2:	jmp    1f82f03 <node_facts_window_run+0x5a33>
 1f82ef4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82f00:	xor    %r15d,%r15d
 1f82f03:	mov    0xa50(%r11),%rcx
 1f82f0a:	mov    0x240(%r8),%rdx
 1f82f11:	mov    (%rcx,%r14,4),%ebx
 1f82f15:	mov    (%rdx,%rbx,8),%r12
 1f82f19:	cmp    %r12,-0x12(%rbp)
 1f82f1d:	jne    1f82f50 <node_facts_window_run+0x5a80>
 1f82f1f:	mov    0x248(%r8),%rdx
 1f82f26:	movzbl -0x2(%rbp),%ecx
 1f82f2a:	cmp    (%rdx,%rbx,1),%cl
 1f82f2d:	jne    1f82f50 <node_facts_window_run+0x5a80>
 1f82f2f:	mov    0xc50(%rdi),%rdx
 1f82f36:	mov    -0xa(%rbp),%ecx
 1f82f39:	cmp    (%rdx,%rbx,4),%ecx
 1f82f3c:	jne    1f82f50 <node_facts_window_run+0x5a80>
 1f82f3e:	mov    0xc58(%rdi),%rdx
 1f82f45:	mov    -0x6(%rbp),%ecx
 1f82f48:	cmp    (%rdx,%rbx,4),%ecx
 1f82f4b:	sete   %cl
 1f82f4e:	jmp    1f82f52 <node_facts_window_run+0x5a82>
 1f82f50:	xor    %ecx,%ecx
 1f82f52:	incq   0xa50(%r8)
 1f82f59:	add    %rax,%r15
 1f82f5c:	mov    %ecx,%edx
 1f82f5e:	mov    0xa58(%r11),%rax
 1f82f65:	xor    $0x1,%dl
 1f82f68:	vmovd  (%rax,%r14,4),%xmm0
 1f82f6e:	movzbl %dl,%eax
 1f82f71:	vmovd  %eax,%xmm1
 1f82f75:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f82f79:	vpaddq 0xa58(%r8),%xmm0,%xmm0
 1f82f82:	vmovdqu %xmm0,0xa58(%r8)
 1f82f8b:	test   %cl,%cl
 1f82f8d:	jne    1f82e53 <node_facts_window_run+0x5983>
 1f82f93:	mov    0x12e4(%r8),%eax
 1f82f9a:	cmp    0x5004904(%rip),%eax        # 6f878a4 <node_census_list>
 1f82fa0:	jae    1f82e53 <node_facts_window_run+0x5983>
 1f82fa6:	inc    %eax
 1f82fa8:	xor    %esi,%esi
 1f82faa:	mov    %eax,0x12e4(%r8)
 1f82fb1:	mov    0xa68(%r11),%rcx
 1f82fb8:	mov    (%rdi),%rax
 1f82fbb:	mov    (%rcx,%r14,4),%ecx
 1f82fbf:	mov    0x18(%rax),%rax
 1f82fc3:	mov    0x422c(%r13,%rcx,4),%ecx
 1f82fcb:	cmp    0x78(%rax),%ecx
 1f82fce:	jae    1f83013 <node_facts_window_run+0x5b43>
 1f82fd0:	mov    0x68(%rax),%rax
 1f82fd4:	mov    0x8(%rdi),%rdi
 1f82fd8:	mov    (%rax,%rcx,4),%eax
 1f82fdb:	cmp    0x1538(%rdi),%eax
 1f82fe1:	jae    1f83013 <node_facts_window_run+0x5b43>
 1f82fe3:	mov    0x1530(%rdi),%rcx
 1f82fea:	test   %rcx,%rcx
 1f82fed:	je     1f83013 <node_facts_window_run+0x5b43>
 1f82fef:	mov    (%rcx,%rax,4),%esi
 1f82ff2:	lea    0x7c0(%rsp),%rdx
 1f82ffa:	lea    0x5b0(%rsp),%rcx
 1f83002:	call   111f9b0 <pp_presumed>
 1f83007:	mov    0x38(%rsp),%r8
 1f8300c:	mov    0x8(%rsp),%r11
 1f83011:	mov    %eax,%esi
 1f83013:	mov    0xa58(%r11),%rax
 1f8301a:	mov    -0x12(%rbp),%rcx
 1f8301e:	movzbl -0x2(%rbp),%r9d
 1f83023:	mov    -0x6(%rbp),%r10d
 1f83027:	mov    %rbp,%r11
 1f8302a:	mov    (%rax,%r14,4),%edx
 1f8302e:	mov    0x248(%r8),%rax
 1f83035:	movzbl (%rax,%rbx,1),%eax
 1f83039:	mov    %rax,0x10(%rsp)
 1f8303e:	mov    -0xa(%rbp),%eax
 1f83041:	mov    %rax,0x20(%rsp)
 1f83046:	mov    0x18(%rsp),%r13
 1f8304b:	mov    0xc50(%r13),%rax
 1f83052:	mov    0xc58(%r13),%rdi
 1f83059:	mov    (%rax,%rbx,4),%ebp
 1f8305c:	mov    (%rdi,%rbx,4),%ebx
 1f8305f:	sub    $0x8,%rsp
 1f83063:	lea    -0x196224a(%rip),%rdi        # 620e20 <.str.11115>
 1f8306a:	mov    %r12,%r8
 1f8306d:	xor    %eax,%eax
 1f8306f:	push   %rbx
 1f83070:	push   %rbp
 1f83071:	mov    %r11,%rbp
 1f83074:	push   %r10
 1f83076:	push   0x40(%rsp)
 1f8307a:	push   0x38(%rsp)
 1f8307e:	call   34ef210 <_IO_printf>
 1f83083:	mov    0x68(%rsp),%r8
 1f83088:	mov    0x38(%rsp),%r11
 1f8308d:	mov    %r13,%rdi
 1f83090:	add    $0x30,%rsp
 1f83094:	mov    0x28(%rsp),%r13
 1f83099:	jmp    1f82e53 <node_facts_window_run+0x5983>
 1f8309e:	mov    0x38(%rsp),%r8
 1f830a3:	xor    %r15d,%r15d
 1f830a6:	vpmovsxbq -0x1acc368(%rip),%xmm0        # 4b6d47 <abi_test_hex.digits+0xb9c7>
 1f830af:	vmovd  0x8(%r13),%xmm2
 1f830b5:	mov    0x30(%rsp),%rcx
 1f830ba:	mov    0x110(%rsp),%r9
 1f830c2:	mov    0x150(%rsp),%rdi
 1f830ca:	vmovq  %r15,%xmm1
 1f830cf:	xor    %eax,%eax
 1f830d1:	mov    0x780(%rsp),%rdx
 1f830d9:	mov    0x740(%rsp),%rsi
 1f830e1:	mov    0xc8(%rsp),%r15
 1f830e9:	sub    %rcx,%r9
 1f830ec:	sub    %rdi,%rcx
 1f830ef:	sub    %r9,%rcx
 1f830f2:	cmovae %rcx,%rax
 1f830f6:	mov    0xf0(%rsp),%rcx
 1f830fe:	sub    %rdx,%rsi
 1f83101:	vpinsrq $0x0,%r9,%xmm0,%xmm0
 1f83107:	vpunpcklqdq %xmm1,%xmm2,%xmm1
 1f8310b:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f83111:	vpaddq 0xa98(%r8),%ymm0,%ymm0
 1f8311a:	vmovq  %rsi,%xmm1
 1f8311f:	sub    %rcx,%rdi
 1f83122:	sub    %rcx,%rdx
 1f83125:	add    %rax,%rdi
 1f83128:	vmovq  %rdx,%xmm2
 1f8312d:	vmovdqu %ymm0,0xa98(%r8)
 1f83136:	vmovq  %rax,%xmm0
 1f8313b:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f8313f:	vmovq  %rdi,%xmm1
 1f83144:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f83148:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f8314e:	vpaddq 0xa68(%r8),%ymm0,%ymm0
 1f83157:	vmovdqu %ymm0,0xa68(%r8)
 1f83160:	cmpq   $0x0,0xb40(%r11)
 1f83168:	je     1f84e50 <node_facts_window_run+0x7980>
 1f8316e:	mov    0x940(%r11),%r12
 1f83175:	mov    0x8(%r13),%ebx
 1f83179:	rdtsc
 1f8317b:	lea    0x8f0(%rsp),%rcx
 1f83183:	vpxor  %xmm0,%xmm0,%xmm0
 1f83187:	vmovdqu64 %zmm0,0x910(%rsp)
 1f83192:	vmovdqu64 %zmm0,0x8f0(%rsp)
 1f8319d:	mov    %r11,%rdi
 1f831a0:	mov    %r13,%rsi
 1f831a3:	shl    $0x20,%rdx
 1f831a7:	or     %rax,%rdx
 1f831aa:	mov    %rdx,0x68(%rsp)
 1f831af:	mov    %ebx,%edx
 1f831b1:	vzeroupper
 1f831b4:	call   1f93e40 <node_contexts_window_loop>
 1f831b9:	vmovups 0x918(%rsp),%ymm0
 1f831c2:	vmovdqu 0x918(%rsp),%xmm1
 1f831cb:	mov    %r13,%rsi
 1f831ce:	vmovups %ymm0,0x230(%rsp)
 1f831d7:	vpbroadcastq 0x928(%rsp),%ymm0
 1f831e1:	mov    0x8(%rsp),%rax
 1f831e6:	vpsubq %xmm0,%xmm1,%xmm0
 1f831ea:	vpaddq 0x928(%rsp),%xmm0,%xmm0
 1f831f3:	vpblendd $0xc,%xmm0,%xmm1,%xmm0
 1f831f9:	vmovdqu %xmm0,0xc08(%rax)
 1f83201:	rdtsc
 1f83203:	shl    $0x20,%rdx
 1f83207:	or     %rax,%rdx
 1f8320a:	mov    %rdx,0x38(%rsp)
 1f8320f:	mov    %ebx,%edx
 1f83211:	mov    0x8(%rsp),%rdi
 1f83216:	vzeroupper
 1f83219:	call   1f95df0 <node_contexts_window_targets>
 1f8321e:	rdtsc
 1f83220:	mov    %r13,%rsi
 1f83223:	shl    $0x20,%rdx
 1f83227:	or     %rax,%rdx
 1f8322a:	mov    %rdx,0xd0(%rsp)
 1f83232:	mov    0x8(%rsp),%rdi
 1f83237:	call   1f96180 <node_contexts_window_part>
 1f8323c:	rdtsc
 1f8323e:	lea    0x7c0(%rsp),%rcx
 1f83246:	vpxor  %xmm0,%xmm0,%xmm0
 1f8324a:	vmovdqu64 %zmm0,0x7e0(%rsp)
 1f83255:	vmovdqu64 %zmm0,0x7c0(%rsp)
 1f8325d:	mov    %r13,%rsi
 1f83260:	shl    $0x20,%rdx
 1f83264:	or     %rax,%rdx
 1f83267:	mov    %rdx,0x80(%rsp)
 1f8326f:	mov    %ebx,%edx
 1f83271:	mov    0x8(%rsp),%rdi
 1f83276:	vzeroupper
 1f83279:	call   1f93e40 <node_contexts_window_loop>
 1f8327e:	rdtsc
 1f83280:	mov    %r13,%rsi
 1f83283:	shl    $0x20,%rdx
 1f83287:	or     %rax,%rdx
 1f8328a:	mov    %rdx,0xc0(%rsp)
 1f83292:	mov    %ebx,%edx
 1f83294:	mov    0x8(%rsp),%rdi
 1f83299:	call   1f95df0 <node_contexts_window_targets>
 1f8329e:	rdtsc
 1f832a0:	mov    %r13,%rsi
 1f832a3:	shl    $0x20,%rdx
 1f832a7:	or     %rax,%rdx
 1f832aa:	mov    %rdx,0xb8(%rsp)
 1f832b2:	mov    0x8(%rsp),%rdi
 1f832b7:	call   1f96180 <node_contexts_window_part>
 1f832bc:	mov    0x8(%rsp),%r11
 1f832c1:	rdtsc
 1f832c3:	shl    $0x20,%rdx
 1f832c7:	or     %rax,%rdx
 1f832ca:	cmpl   $0x0,0xa90(%r11)
 1f832d2:	mov    %rdx,0x1b0(%rsp)
 1f832da:	mov    %rbx,0x1f0(%rsp)
 1f832e2:	je     1f83836 <node_facts_window_run+0x6366>
 1f832e8:	vpbroadcastq -0x19b4de9(%rip),%xmm0        # 5ce508 <.LCPI3_1>
 1f832f1:	xor    %ebx,%ebx
 1f832f3:	xor    %edi,%edi
 1f832f5:	mov    %r12,0x150(%rsp)
 1f832fd:	jmp    1f83321 <node_facts_window_run+0x5e51>
 1f832ff:	mov    0x8(%rsp),%r11
 1f83304:	xor    %esi,%esi
 1f83306:	incq   0x12e8(%r12,%rsi,8)
 1f8330e:	mov    0xa90(%r11),%eax
 1f83315:	inc    %rdi
 1f83318:	cmp    %rax,%rdi
 1f8331b:	jae    1f83838 <node_facts_window_run+0x6368>
 1f83321:	mov    0xb80(%r11),%rax
 1f83328:	movzbl (%rax,%rdi,1),%r8d
 1f8332d:	test   %r8b,%r8b
 1f83330:	je     1f8330e <node_facts_window_run+0x5e3e>
 1f83332:	mov    0xa70(%r11),%rcx
 1f83339:	mov    0xa68(%r11),%rax
 1f83340:	mov    (%rcx,%rdi,4),%ecx
 1f83343:	mov    (%rax,%rdi,4),%ebp
 1f83346:	mov    0x651b8(%r13,%rcx,4),%esi
 1f8334e:	incq   0xab8(%r12)
 1f83356:	mov    0xa58(%r11),%rax
 1f8335d:	mov    (%rax,%rdi,4),%eax
 1f83360:	add    %rax,0xac0(%r12)
 1f83368:	cmp    $0x1,%r8b
 1f8336c:	jne    1f833c0 <node_facts_window_run+0x5ef0>
 1f8336e:	mov    0xa58(%r11),%rax
 1f83375:	mov    (%rax,%rdi,4),%r10d
 1f83379:	test   %r10d,%r10d
 1f8337c:	je     1f83304 <node_facts_window_run+0x5e34>
 1f8337e:	mov    0xbe8(%r11),%rax
 1f83385:	sub    %esi,%ecx
 1f83387:	xor    %r11d,%r11d
 1f8338a:	inc    %ecx
 1f8338c:	nopl   0x0(%rax)
 1f83390:	lea    (%rcx,%r11,1),%r9d
 1f83394:	cmp    %esi,%r11d
 1f83397:	cmovae %ebp,%r9d
 1f8339b:	mov    %r9d,%edx
 1f8339e:	shr    $0x3,%edx
 1f833a1:	and    $0xfffffff8,%edx
 1f833a4:	mov    0x10(%rax,%rdx,8),%r8
 1f833a9:	bt     %r9,%r8
 1f833ad:	jb     1f83442 <node_facts_window_run+0x5f72>
 1f833b3:	inc    %r11d
 1f833b6:	cmp    %r11d,%r10d
 1f833b9:	jne    1f83390 <node_facts_window_run+0x5ec0>
 1f833bb:	jmp    1f832ff <node_facts_window_run+0x5e2f>
 1f833c0:	mov    0xa58(%r11),%rcx
 1f833c7:	mov    0xb68(%r11),%rdx
 1f833ce:	cmp    $0x3,%r8b
 1f833d2:	sete   %al
 1f833d5:	mov    (%rcx,%rdi,4),%r9d
 1f833d9:	movzbl (%rdx,%rdi,1),%r10d
 1f833de:	test   %r9,%r9
 1f833e1:	sete   %cl
 1f833e4:	cmp    $0x2,%r10b
 1f833e8:	sete   %dl
 1f833eb:	or     %al,%dl
 1f833ed:	or     %cl,%dl
 1f833ef:	je     1f833f9 <node_facts_window_run+0x5f29>
 1f833f1:	xor    %r14d,%r14d
 1f833f4:	jmp    1f83747 <node_facts_window_run+0x6277>
 1f833f9:	mov    0xa70(%r11),%rdx
 1f83400:	mov    0xa68(%r11),%rax
 1f83407:	mov    %rbp,0x20(%rsp)
 1f8340c:	mov    %r13,%rcx
 1f8340f:	mov    0xbe8(%r11),%r12
 1f83416:	mov    %rbx,0x10(%rsp)
 1f8341b:	mov    (%rdx,%rdi,4),%edx
 1f8341e:	mov    (%rax,%rdi,4),%r13d
 1f83422:	mov    0xb48(%r11),%rax
 1f83429:	mov    0x651b8(%rcx,%rdx,4),%ebp
 1f83430:	sub    %ebp,%edx
 1f83432:	cmp    $0x1,%r9d
 1f83436:	jne    1f83492 <node_facts_window_run+0x5fc2>
 1f83438:	xor    %r14d,%r14d
 1f8343b:	xor    %ebx,%ebx
 1f8343d:	jmp    1f83697 <node_facts_window_run+0x61c7>
 1f83442:	mov    0x8(%rsp),%r11
 1f83447:	mov    %r9d,%esi
 1f8344a:	mov    0xbd0(%r11),%rcx
 1f83451:	movzbl (%rcx,%rsi,1),%ecx
 1f83455:	mov    $0x1,%esi
 1f8345a:	cmp    $0xd,%ecx
 1f8345d:	je     1f83306 <node_facts_window_run+0x5e36>
 1f83463:	lea    -0xf(%rcx),%r8d
 1f83467:	mov    $0x2,%esi
 1f8346c:	cmp    $0x2,%r8b
 1f83470:	jb     1f83306 <node_facts_window_run+0x5e36>
 1f83476:	cmp    $0xe,%ecx
 1f83479:	je     1f837f0 <node_facts_window_run+0x6320>
 1f8347f:	cmp    $0x11,%ecx
 1f83482:	jne    1f837fa <node_facts_window_run+0x632a>
 1f83488:	mov    $0x4,%esi
 1f8348d:	jmp    1f83306 <node_facts_window_run+0x5e36>
 1f83492:	mov    %r9d,%ecx
 1f83495:	and    $0xfffffffe,%ecx
 1f83498:	mov    %r10b,0x110(%rsp)
 1f834a0:	mov    %r8b,0x30(%rsp)
 1f834a5:	mov    %r9,0x88(%rsp)
 1f834ad:	xor    %r14d,%r14d
 1f834b0:	xor    %r15d,%r15d
 1f834b3:	mov    %ecx,0x18(%rsp)
 1f834b7:	mov    %rdx,0x50(%rsp)
 1f834bc:	add    $0x2,%edx
 1f834bf:	jmp    1f834ea <node_facts_window_run+0x601a>
 1f834c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f834d0:	xor    %r11d,%r11d
 1f834d3:	add    %r10,%r14
 1f834d6:	add    $0x2,%edx
 1f834d9:	inc    %r15d
 1f834dc:	add    %r11,%r14
 1f834df:	cmp    0x18(%rsp),%r15d
 1f834e4:	je     1f83635 <node_facts_window_run+0x6165>
 1f834ea:	mov    %r15d,%ebx
 1f834ed:	lea    -0x1(%rdx),%r15d
 1f834f1:	cmp    %ebp,%ebx
 1f834f3:	mov    $0x1,%r11d
 1f834f9:	mov    $0x1,%r10d
 1f834ff:	cmovae %r13d,%r15d
 1f83503:	mov    %r15d,%esi
 1f83506:	and    $0xffffffc0,%esi
 1f83509:	movzbl (%rax,%r15,1),%r8d
 1f8350e:	shrx   %r15,(%r12,%rsi,1),%rsi
 1f83514:	and    $0x1,%r8d
 1f83518:	mov    %esi,%r9d
 1f8351b:	and    $0x1,%r9d
 1f8351f:	cmp    %r8d,%r9d
 1f83522:	jne    1f83593 <node_facts_window_run+0x60c3>
 1f83524:	test   $0x1,%sil
 1f83528:	je     1f83590 <node_facts_window_run+0x60c0>
 1f8352a:	mov    0x8(%rsp),%rcx
 1f8352f:	mov    0xbb0(%rcx),%r8
 1f83536:	mov    0xb58(%rcx),%rsi
 1f8353d:	movzbl (%r8,%r15,1),%r8d
 1f83542:	cmp    (%rsi,%r15,1),%r8b
 1f83546:	jne    1f83593 <node_facts_window_run+0x60c3>
 1f83548:	mov    0x8(%rsp),%rcx
 1f8354d:	mov    0xbc0(%rcx),%r8
 1f83554:	mov    0xb50(%rcx),%rsi
 1f8355b:	movzbl (%r8,%r15,1),%r8d
 1f83560:	cmp    (%rsi,%r15,1),%r8b
 1f83564:	jne    1f83593 <node_facts_window_run+0x60c3>
 1f83566:	mov    0x8(%rsp),%rcx
 1f8356b:	xor    %r10d,%r10d
 1f8356e:	mov    0xbd8(%rcx),%r8
 1f83575:	mov    0xb60(%rcx),%rsi
 1f8357c:	mov    (%r8,%r15,4),%r8d
 1f83580:	cmp    (%rsi,%r15,4),%r8d
 1f83584:	setne  %r10b
 1f83588:	jmp    1f83593 <node_facts_window_run+0x60c3>
 1f8358a:	nopw   0x0(%rax,%rax,1)
 1f83590:	xor    %r10d,%r10d
 1f83593:	lea    0x1(%rbx),%r15d
 1f83597:	mov    %r13d,%esi
 1f8359a:	cmp    %ebp,%r15d
 1f8359d:	cmovb  %edx,%esi
 1f835a0:	mov    %esi,%r8d
 1f835a3:	and    $0xffffffc0,%r8d
 1f835a7:	movzbl (%rax,%rsi,1),%r9d
 1f835ac:	shrx   %rsi,(%r12,%r8,1),%r8
 1f835b2:	and    $0x1,%r9d
 1f835b6:	mov    %r8d,%ecx
 1f835b9:	and    $0x1,%ecx
 1f835bc:	cmp    %r9d,%ecx
 1f835bf:	jne    1f834d3 <node_facts_window_run+0x6003>
 1f835c5:	test   $0x1,%r8b
 1f835c9:	je     1f834d0 <node_facts_window_run+0x6000>
 1f835cf:	mov    0x8(%rsp),%r9
 1f835d4:	mov    0xbb0(%r9),%r8
 1f835db:	mov    0xb58(%r9),%rcx
 1f835e2:	movzbl (%r8,%rsi,1),%r8d
 1f835e7:	cmp    (%rcx,%rsi,1),%r8b
 1f835eb:	jne    1f834d3 <node_facts_window_run+0x6003>
 1f835f1:	mov    0xbc0(%r9),%r8
 1f835f8:	mov    0xb50(%r9),%rcx
 1f835ff:	movzbl (%r8,%rsi,1),%r8d
 1f83604:	cmp    (%rcx,%rsi,1),%r8b
 1f83608:	jne    1f834d3 <node_facts_window_run+0x6003>
 1f8360e:	mov    0x8(%rsp),%r8
 1f83613:	xor    %r11d,%r11d
 1f83616:	mov    0xb60(%r8),%rcx
 1f8361d:	mov    0xbd8(%r8),%r8
 1f83624:	mov    (%r8,%rsi,4),%r8d
 1f83628:	cmp    (%rcx,%rsi,4),%r8d
 1f8362c:	setne  %r11b
 1f83630:	jmp    1f834d3 <node_facts_window_run+0x6003>
 1f83635:	mov    0x88(%rsp),%r9
 1f8363d:	mov    0xc8(%rsp),%r15
 1f83645:	test   $0x1,%r9b
 1f83649:	jne    1f8367b <node_facts_window_run+0x61ab>
 1f8364b:	mov    0x8(%rsp),%r11
 1f83650:	mov    0x28(%rsp),%r13
 1f83655:	mov    0x150(%rsp),%r12
 1f8365d:	mov    0x10(%rsp),%rbx
 1f83662:	mov    0x20(%rsp),%rbp
 1f83667:	movzbl 0x30(%rsp),%r8d
 1f8366d:	movzbl 0x110(%rsp),%r10d
 1f83676:	jmp    1f83747 <node_facts_window_run+0x6277>
 1f8367b:	mov    0x8(%rsp),%r11
 1f83680:	movzbl 0x30(%rsp),%r8d
 1f83686:	movzbl 0x110(%rsp),%r10d
 1f8368f:	mov    0x50(%rsp),%rdx
 1f83694:	add    $0x2,%ebx
 1f83697:	inc    %edx
 1f83699:	add    %ebx,%edx
 1f8369b:	cmp    %ebp,%ebx
 1f8369d:	cmovb  %edx,%r13d
 1f836a1:	mov    %r13d,%ecx
 1f836a4:	and    $0xffffffc0,%ecx
 1f836a7:	movzbl (%rax,%r13,1),%edx
 1f836ac:	mov    $0x1,%eax
 1f836b1:	shrx   %r13,(%r12,%rcx,1),%rcx
 1f836b7:	and    $0x1,%edx
 1f836ba:	mov    %ecx,%esi
 1f836bc:	and    $0x1,%esi
 1f836bf:	cmp    %edx,%esi
 1f836c1:	jne    1f83729 <node_facts_window_run+0x6259>
 1f836c3:	mov    0x150(%rsp),%r12
 1f836cb:	mov    0x10(%rsp),%rbx
 1f836d0:	mov    0x20(%rsp),%rbp
 1f836d5:	test   $0x1,%cl
 1f836d8:	je     1f8373d <node_facts_window_run+0x626d>
 1f836da:	mov    0xbb0(%r11),%rdx
 1f836e1:	mov    0xb58(%r11),%rcx
 1f836e8:	movzbl (%rdx,%r13,1),%edx
 1f836ed:	cmp    (%rcx,%r13,1),%dl
 1f836f1:	jne    1f8373f <node_facts_window_run+0x626f>
 1f836f3:	mov    0xbc0(%r11),%rdx
 1f836fa:	mov    0xb50(%r11),%rcx
 1f83701:	movzbl (%rdx,%r13,1),%edx
 1f83706:	cmp    (%rcx,%r13,1),%dl
 1f8370a:	jne    1f8373f <node_facts_window_run+0x626f>
 1f8370c:	mov    0xbd8(%r11),%rax
 1f83713:	mov    0xb60(%r11),%rcx
 1f8371a:	mov    (%rax,%r13,4),%edx
 1f8371e:	xor    %eax,%eax
 1f83720:	cmp    (%rcx,%r13,4),%edx
 1f83724:	setne  %al
 1f83727:	jmp    1f8373f <node_facts_window_run+0x626f>
 1f83729:	mov    0x150(%rsp),%r12
 1f83731:	mov    0x10(%rsp),%rbx
 1f83736:	mov    0x20(%rsp),%rbp
 1f8373b:	jmp    1f8373f <node_facts_window_run+0x626f>
 1f8373d:	xor    %eax,%eax
 1f8373f:	mov    0x28(%rsp),%r13
 1f83744:	add    %rax,%r14
 1f83747:	cmp    $0x2,%r10b
 1f8374b:	sete   %al
 1f8374e:	cmp    $0x3,%r8b
 1f83752:	sete   %cl
 1f83755:	xor    %cl,%al
 1f83757:	test   %r14,%r14
 1f8375a:	vmovd  %ecx,%xmm1
 1f8375e:	setne  %dl
 1f83761:	incq   0xac8(%r12)
 1f83769:	add    %r9,%rbx
 1f8376c:	or     %al,%dl
 1f8376e:	vpinsrb $0x1,%edx,%xmm1,%xmm1
 1f83774:	vpmovzxbq %xmm1,%xmm1
 1f83779:	vptestmq %xmm0,%xmm1,%k0
 1f8377f:	vmovdqu 0xad8(%r12),%xmm1
 1f83789:	vpmovm2q %k0,%xmm2
 1f8378f:	vpsubq %xmm2,%xmm1,%xmm1
 1f83793:	vmovdqu %xmm1,0xad8(%r12)
 1f8379d:	add    %r14,0xae8(%r12)
 1f837a5:	mov    0xb78(%r11),%rax
 1f837ac:	mov    (%rax,%rdi,8),%rax
 1f837b0:	add    %rax,0xb30(%r12)
 1f837b8:	cmp    $0x1,%dl
 1f837bb:	jne    1f8330e <node_facts_window_run+0x5e3e>
 1f837c1:	mov    0x1368(%r12),%eax
 1f837c9:	cmp    $0xf,%rax
 1f837cd:	ja     1f8330e <node_facts_window_run+0x5e3e>
 1f837d3:	mov    0x422c(%r13,%rbp,4),%ecx
 1f837db:	mov    %ecx,0x1328(%r12,%rax,4)
 1f837e3:	incl   0x1368(%r12)
 1f837eb:	jmp    1f8330e <node_facts_window_run+0x5e3e>
 1f837f0:	mov    $0x3,%esi
 1f837f5:	jmp    1f83306 <node_facts_window_run+0x5e36>
 1f837fa:	mov    $0x1,%esi
 1f837ff:	shlx   %r9,%rsi,%r8
 1f83804:	mov    $0x5,%esi
 1f83809:	test   %r8,0x18(%rax,%rdx,8)
 1f8380e:	jne    1f83306 <node_facts_window_run+0x5e36>
 1f83814:	mov    $0x6,%esi
 1f83819:	test   %r8,0x20(%rax,%rdx,8)
 1f8381e:	jne    1f83306 <node_facts_window_run+0x5e36>
 1f83824:	xor    %eax,%eax
 1f83826:	cmp    $0x7,%ecx
 1f83829:	setne  %al
 1f8382c:	lea    0x2(%rax,%rax,4),%rsi
 1f83831:	jmp    1f83306 <node_facts_window_run+0x5e36>
 1f83836:	xor    %ebx,%ebx
 1f83838:	add    %rbx,0xad0(%r12)
 1f83840:	mov    0x80(%rsp),%rdx
 1f83848:	mov    0xd0(%rsp),%rsi
 1f83850:	mov    0x38(%rsp),%rcx
 1f83855:	vmovd  0x1f0(%rsp),%xmm4
 1f8385e:	vmovdqu 0xb78(%r12),%xmm0
 1f83868:	vmovq  0x910(%rsp),%xmm1
 1f83871:	vpaddq 0x938(%rsp),%xmm0,%xmm0
 1f8387a:	vmovdqu %xmm0,0xb78(%r12)
 1f83884:	mov    0x948(%rsp),%rax
 1f8388c:	add    %rax,0xb88(%r12)
 1f83894:	mov    %rdx,%rax
 1f83897:	sub    %rsi,%rax
 1f8389a:	sub    %rcx,%rsi
 1f8389d:	sub    0x68(%rsp),%rcx
 1f838a2:	vmovdqu64 0x8f0(%rsp),%zmm0
 1f838ad:	vmovq  %rax,%xmm2
 1f838b2:	vmovq  %rsi,%xmm3
 1f838b7:	mov    0x1b0(%rsp),%rsi
 1f838bf:	mov    0xc0(%rsp),%rax
 1f838c7:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f838cb:	vmovq  %rcx,%xmm3
 1f838d0:	mov    0xb8(%rsp),%rcx
 1f838d8:	vpunpcklqdq %xmm3,%xmm4,%xmm3
 1f838dc:	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
 1f838e2:	vshufi64x2 $0x44,%zmm2,%zmm0,%zmm0
 1f838e9:	vpaddq 0xaf0(%r12),%zmm0,%zmm0
 1f838f4:	sub    %rcx,%rsi
 1f838f7:	sub    %rax,%rcx
 1f838fa:	sub    %rdx,%rax
 1f838fd:	vmovq  %rsi,%xmm3
 1f83902:	vmovq  %rax,%xmm2
 1f83907:	vpunpcklqdq %xmm1,%xmm3,%xmm1
 1f8390b:	vmovdqu64 %zmm0,0xaf0(%r12)
 1f83916:	vmovq  %rcx,%xmm0
 1f8391b:	vpunpcklqdq %xmm0,%xmm2,%xmm0
 1f8391f:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f83925:	vinserti64x4 $0x1,0x230(%rsp),%zmm0,%zmm0
 1f83931:	vpaddq 0xb38(%r12),%zmm0,%zmm0
 1f8393c:	vmovdqu64 %zmm0,0xb38(%r12)
 1f83947:	cmpq   $0x0,0xc20(%r11)
 1f8394f:	je     1f84e50 <node_facts_window_run+0x7980>
 1f83955:	mov    0x8(%r13),%r15d
 1f83959:	mov    0x940(%r11),%r14
 1f83960:	vpxor  %xmm0,%xmm0,%xmm0
 1f83964:	vmovdqu %ymm0,0x8f0(%rsp)
 1f8396d:	movq   $0x0,0x910(%rsp)
 1f83979:	rdtsc
 1f8397b:	mov    %r11,%rdi
 1f8397e:	mov    %rdx,0x430(%rsp)
 1f83986:	lea    0x8f0(%rsp),%rdx
 1f8398e:	mov    %r15d,%esi
 1f83991:	mov    %rax,0x78(%rsp)
 1f83996:	vzeroupper
 1f83999:	call   1f96560 <node_rows_window_reads>
 1f8399e:	rdtsc
 1f839a0:	mov    %r13,%rsi
 1f839a3:	mov    %rdx,0x4f0(%rsp)
 1f839ab:	mov    %r15d,%edx
 1f839ae:	mov    %rax,0x338(%rsp)
 1f839b6:	mov    0x8(%rsp),%rdi
 1f839bb:	call   1f96c80 <node_rows_window_shapes>
 1f839c0:	mov    0x8(%rsp),%rdi
 1f839c5:	rdtsc
 1f839c7:	mov    0xc10(%rdi),%rcx
 1f839ce:	or     0xc08(%rdi),%rcx
 1f839d5:	mov    %rax,0x70(%rsp)
 1f839da:	mov    %rdx,0x3f0(%rsp)
 1f839e2:	je     1f839fc <node_facts_window_run+0x652c>
 1f839e4:	lea    0x8f0(%rsp),%rcx
 1f839ec:	mov    %r13,%rsi
 1f839ef:	mov    %r15d,%edx
 1f839f2:	call   1f970b0 <node_rows_window_updates>
 1f839f7:	mov    0x8(%rsp),%rdi
 1f839fc:	rdtsc
 1f839fe:	mov    %r13,%rsi
 1f83a01:	mov    %rdx,0x570(%rsp)
 1f83a09:	mov    %r15d,%edx
 1f83a0c:	mov    %rax,0x370(%rsp)
 1f83a14:	call   1f978c0 <node_rows_window_write>
 1f83a19:	mov    %eax,%ecx
 1f83a1b:	rdtsc
 1f83a1d:	mov    0x900(%rsp),%r8
 1f83a25:	mov    0x910(%rsp),%r9d
 1f83a2d:	vpxor  %xmm0,%xmm0,%xmm0
 1f83a31:	vmovdqu %xmm0,0x5bc(%rsp)
 1f83a3a:	vmovdqa %xmm0,0x5b0(%rsp)
 1f83a43:	movl   $0x0,0xfc(%rsp)
 1f83a4e:	movq   $0x0,0x368(%rsp)
 1f83a5a:	mov    %rax,0x3b0(%rsp)
 1f83a62:	mov    %rdx,0x650(%rsp)
 1f83a6a:	sub    $0x8,%rsp
 1f83a6e:	mov    0x10(%rsp),%rdi
 1f83a73:	lea    0x370(%rsp),%rax
 1f83a7b:	lea    0x104(%rsp),%r10
 1f83a83:	lea    0x5b8(%rsp),%r11
 1f83a8b:	mov    %r13,%rsi
 1f83a8e:	mov    %r15d,%edx
 1f83a91:	mov    %ecx,0x2f8(%rsp)
 1f83a98:	push   %rax
 1f83a99:	push   %r10
 1f83a9b:	push   %r11
 1f83a9d:	call   1f97ee0 <node_rows_window_values>
 1f83aa2:	add    $0x20,%rsp
 1f83aa6:	rdtsc
 1f83aa8:	mov    %r13,%rsi
 1f83aab:	mov    %rdx,0x610(%rsp)
 1f83ab3:	mov    %rax,0x2b0(%rsp)
 1f83abb:	mov    0x8(%rsp),%rdi
 1f83ac0:	call   1f98d80 <node_rows_window_part>
 1f83ac5:	mov    0x8(%rsp),%rdi
 1f83aca:	rdtsc
 1f83acc:	movl   $0x0,0xe0(%rsp)
 1f83ad7:	movq   $0x0,0xd8(%rsp)
 1f83ae3:	cmpb   $0x1,0xd58(%rdi)
 1f83aea:	mov    %rax,0x530(%rsp)
 1f83af2:	mov    %rdx,0x4b0(%rsp)
 1f83afa:	jne    1f83b14 <node_facts_window_run+0x6644>
 1f83afc:	lea    0xd8(%rsp),%rcx
 1f83b04:	mov    %r13,%rsi
 1f83b07:	mov    %r15d,%edx
 1f83b0a:	call   1f98e90 <node_rows_window_summary>
 1f83b0f:	mov    0x8(%rsp),%rdi
 1f83b14:	rdtsc
 1f83b16:	mov    0xdc0(%rdi),%ecx
 1f83b1c:	movl   $0x0,0xdc0(%rdi)
 1f83b26:	mov    0xa90(%rdi),%r12d
 1f83b2d:	cmpb   $0x0,0xdc4(%rdi)
 1f83b34:	mov    %rcx,0x340(%rsp)
 1f83b3c:	mov    %rax,0xa0(%rsp)
 1f83b44:	mov    %rdx,0x5d0(%rsp)
 1f83b4c:	je     1f83b7d <node_facts_window_run+0x66ad>
 1f83b4e:	mov    0xdcc(%rdi),%ecx
 1f83b54:	mov    $0x1,%esi
 1f83b59:	mov    %ecx,%ebx
 1f83b5b:	inc    %ecx
 1f83b5d:	and    $0x3,%ebx
 1f83b60:	mov    %ecx,0xdcc(%rdi)
 1f83b66:	mov    0xd8(%rsp),%ebp
 1f83b6d:	cmp    $0x2,%ebx
 1f83b70:	jne    1f84a75 <node_facts_window_run+0x75a5>
 1f83b76:	mov    $0x2,%ebx
 1f83b7b:	jmp    1f83b96 <node_facts_window_run+0x66c6>
 1f83b7d:	mov    0xd8(%rsp),%ebp
 1f83b84:	mov    $0xffffffff,%ebx
 1f83b89:	mov    %ebx,%eax
 1f83b8b:	xor    $0x3,%eax
 1f83b8e:	xor    %esi,%esi
 1f83b90:	or     %ebp,%eax
 1f83b92:	sete   %sil
 1f83b96:	cmpb   $0x1,0xd58(%rdi)
 1f83b9d:	mov    %esi,0x1a4(%rsp)
 1f83ba4:	mov    %r14,0x1b0(%rsp)
 1f83bac:	jne    1f83c6f <node_facts_window_run+0x679f>
 1f83bb2:	mov    0xd98(%rdi),%rsi
 1f83bb9:	mov    0xda8(%rdi),%rdi
 1f83bc0:	lea    (%r15,%r15,1),%rdx
 1f83bc4:	call   355eaf0 <memcpy>
 1f83bc9:	mov    0x8(%rsp),%rax
 1f83bce:	mov    0x8(%rsp),%rcx
 1f83bd3:	mov    %r12,%rdx
 1f83bd6:	mov    0xda0(%rax),%rsi
 1f83bdd:	mov    0xdb0(%rcx),%rdi
 1f83be4:	call   355eaf0 <memcpy>
 1f83be9:	mov    0x8(%rsp),%rax
 1f83bee:	mov    0x8(%rsp),%rcx
 1f83bf3:	mov    %ebp,%edx
 1f83bf5:	shl    $0x2,%rdx
 1f83bf9:	mov    0xd90(%rax),%rsi
 1f83c00:	mov    0xdb8(%rcx),%rdi
 1f83c07:	call   355eaf0 <memcpy>
 1f83c0c:	mov    0x8(%rsp),%rdi
 1f83c11:	xor    %eax,%eax
 1f83c13:	mov    %r15d,%ecx
 1f83c16:	sub    $0x1,%ecx
 1f83c19:	cmovb  %eax,%ecx
 1f83c1c:	test   %ebx,%ebx
 1f83c1e:	sete   %dl
 1f83c21:	cmp    $0x1,%ebx
 1f83c24:	sete   %sil
 1f83c28:	test   %r12d,%r12d
 1f83c2b:	sete   %r8b
 1f83c2f:	mov    0xda8(%rdi),%rax
 1f83c36:	and    %sil,%r8b
 1f83c39:	or     %dl,%r8b
 1f83c3c:	movzbl %r8b,%edx
 1f83c40:	xor    %dx,(%rax,%rcx,2)
 1f83c44:	test   %r12d,%r12d
 1f83c47:	mov    0xdb0(%rdi),%rax
 1f83c4e:	setne  %cl
 1f83c51:	and    %sil,%cl
 1f83c54:	xor    %cl,(%rax)
 1f83c56:	cmp    $0x3,%ebx
 1f83c59:	mov    0xdb8(%rdi),%rdx
 1f83c60:	sete   %al
 1f83c63:	test   %ebp,%ebp
 1f83c65:	setne  %cl
 1f83c68:	and    %al,%cl
 1f83c6a:	movzbl %cl,%eax
 1f83c6d:	xor    %eax,(%rdx)
 1f83c6f:	mov    %ebp,0x1a8(%rsp)
 1f83c76:	mov    %r12,0x690(%rsp)
 1f83c7e:	mov    0xca8(%rdi),%rsi
 1f83c85:	mov    0xcb8(%rdi),%rdi
 1f83c8c:	mov    0x2f0(%rsp),%ebx
 1f83c93:	mov    %ebx,%r14d
 1f83c96:	mov    %r14,%rdx
 1f83c99:	call   355eaf0 <memcpy>
 1f83c9e:	mov    0x8(%rsp),%rax
 1f83ca3:	mov    0x8(%rsp),%rcx
 1f83ca8:	mov    %r14,%rdx
 1f83cab:	mov    0xcb0(%rax),%rsi
 1f83cb2:	mov    0xcc0(%rcx),%rdi
 1f83cb9:	call   355eaf0 <memcpy>
 1f83cbe:	mov    0x8(%rsp),%rax
 1f83cc3:	mov    0x8(%rsp),%rcx
 1f83cc8:	lea    0x0(,%r14,8),%rdx
 1f83cd0:	mov    %r14,0x6a8(%rsp)
 1f83cd8:	mov    %rdx,0x698(%rsp)
 1f83ce0:	mov    0xcc8(%rax),%rsi
 1f83ce7:	mov    0xcd0(%rcx),%rdi
 1f83cee:	call   355eaf0 <memcpy>
 1f83cf3:	mov    0x8(%rsp),%rax
 1f83cf8:	mov    $0xffffffff,%edi
 1f83cfd:	movzbl 0xdd0(%rax),%ecx
 1f83d04:	mov    0x8(%rsp),%rax
 1f83d09:	mov    0xdd8(%rax),%edx
 1f83d0f:	imul   $0x4ec4ec4f,%rdx,%rax
 1f83d16:	shr    $0x22,%rax
 1f83d1a:	lea    (%rax,%rax,2),%esi
 1f83d1d:	lea    (%rax,%rsi,4),%eax
 1f83d20:	mov    %edx,%esi
 1f83d22:	sub    %eax,%esi
 1f83d24:	test   %ecx,%ecx
 1f83d26:	cmovne %esi,%edi
 1f83d29:	xor    %eax,%eax
 1f83d2b:	lea    -0x1(%rdi),%esi
 1f83d2e:	cmp    $0x3,%esi
 1f83d31:	mov    %r15d,%esi
 1f83d34:	cmovae %edi,%eax
 1f83d37:	test   %ebx,%ebx
 1f83d39:	cmovne %edi,%eax
 1f83d3c:	add    %edx,%ecx
 1f83d3e:	mov    0x8(%rsp),%rdx
 1f83d43:	mov    0x8(%rsp),%rdi
 1f83d48:	cmp    $0x1,%eax
 1f83d4b:	vpbroadcastd %eax,%xmm0
 1f83d51:	vpcmpeqd -0x19bbf69(%rip),%xmm0,%xmm1        # 5c7df0 <.LCPI3_68>
 1f83d59:	vpcmpeqd -0x19bbf61(%rip),%xmm0,%xmm0        # 5c7e00 <.LCPI3_69>
 1f83d61:	mov    %ecx,0xdd8(%rdx)
 1f83d67:	mov    0x8(%rsp),%rcx
 1f83d6c:	sete   %dl
 1f83d6f:	vpsrld $0x1f,%xmm1,%xmm1
 1f83d74:	vpsrld $0x1f,%xmm0,%xmm0
 1f83d79:	mov    0xcb8(%rcx),%rcx
 1f83d80:	xor    %dl,(%rcx)
 1f83d82:	mov    0x8(%rsp),%rcx
 1f83d87:	cmp    $0x2,%eax
 1f83d8a:	sete   %dl
 1f83d8d:	mov    0xcc0(%rcx),%rcx
 1f83d94:	xor    %dl,(%rcx)
 1f83d96:	xor    %ecx,%ecx
 1f83d98:	cmp    $0x3,%eax
 1f83d9b:	mov    0xcd0(%rdi),%rdx
 1f83da2:	sete   %cl
 1f83da5:	xor    %rcx,(%rdx)
 1f83da8:	mov    0xfc(%rsp),%ecx
 1f83daf:	vmovsd 0x5b0(%rsp),%xmm2
 1f83db8:	vmovups 0x5bc(%rsp),%xmm3
 1f83dc1:	mov    %rcx,0x350(%rsp)
 1f83dc9:	mov    0x368(%rsp),%rcx
 1f83dd1:	mov    %rcx,0x348(%rsp)
 1f83dd9:	mov    0x5b8(%rsp),%ecx
 1f83de0:	vmovups %ymm2,0x890(%rsp)
 1f83de9:	vshufps $0x24,%xmm3,%xmm2,%xmm2
 1f83dee:	mov    %rcx,0x6b0(%rsp)
 1f83df6:	vpinsrd $0x2,%ecx,%xmm2,%xmm2
 1f83dfc:	xor    %ecx,%ecx
 1f83dfe:	cmp    $0xc,%eax
 1f83e01:	vmovaps %xmm3,0x860(%rsp)
 1f83e0a:	sete   %cl
 1f83e0d:	xor    0x5c8(%rsp),%ecx
 1f83e14:	vpxor  %xmm1,%xmm2,%xmm1
 1f83e18:	xor    %ebx,%ebx
 1f83e1a:	test   %eax,%eax
 1f83e1c:	vmovdqa %xmm1,0x720(%rsp)
 1f83e25:	vshufps $0xe9,%xmm3,%xmm3,%xmm1
 1f83e2a:	sete   %bpl
 1f83e2e:	cmp    $0x4,%eax
 1f83e31:	vxorps %xmm0,%xmm1,%xmm0
 1f83e35:	sete   0x4f(%rsp)
 1f83e3a:	cmp    $0x5,%eax
 1f83e3d:	vmovlps %xmm0,0x730(%rsp)
 1f83e46:	vxorps %xmm0,%xmm0,%xmm0
 1f83e4a:	mov    %ecx,0x738(%rsp)
 1f83e51:	rdtsc
 1f83e53:	vmovups %ymm0,0x7c0(%rsp)
 1f83e5c:	movq   $0x0,0x7e0(%rsp)
 1f83e68:	mov    %rax,0x6c0(%rsp)
 1f83e70:	mov    %rdx,0xe8(%rsp)
 1f83e78:	sete   0x4e(%rsp)
 1f83e7d:	lea    0x7c0(%rsp),%rdx
 1f83e85:	mov    0x8(%rsp),%rdi
 1f83e8a:	vzeroupper
 1f83e8d:	call   1f96560 <node_rows_window_reads>
 1f83e92:	rdtsc
 1f83e94:	mov    %r13,%rsi
 1f83e97:	mov    %rdx,0x780(%rsp)
 1f83e9f:	mov    %r15d,%edx
 1f83ea2:	mov    %rax,0xb0(%rsp)
 1f83eaa:	mov    0x8(%rsp),%rdi
 1f83eaf:	call   1f96c80 <node_rows_window_shapes>
 1f83eb4:	mov    0x8(%rsp),%rdi
 1f83eb9:	rdtsc
 1f83ebb:	mov    0xc10(%rdi),%rcx
 1f83ec2:	or     0xc08(%rdi),%rcx
 1f83ec9:	mov    %rax,0x40(%rsp)
 1f83ece:	mov    %rdx,0x490(%rsp)
 1f83ed6:	je     1f83ef0 <node_facts_window_run+0x6a20>
 1f83ed8:	lea    0x7c0(%rsp),%rcx
 1f83ee0:	mov    %r13,%rsi
 1f83ee3:	mov    %r15d,%edx
 1f83ee6:	call   1f970b0 <node_rows_window_updates>
 1f83eeb:	mov    0x8(%rsp),%rdi
 1f83ef0:	rdtsc
 1f83ef2:	mov    %bpl,%bl
 1f83ef5:	mov    %r13,%rsi
 1f83ef8:	mov    %rax,0x98(%rsp)
 1f83f00:	mov    %rdx,0x740(%rsp)
 1f83f08:	mov    %r15d,%edx
 1f83f0b:	call   1f978c0 <node_rows_window_write>
 1f83f10:	mov    %eax,%ecx
 1f83f12:	rdtsc
 1f83f14:	mov    0x7d0(%rsp),%r8
 1f83f1c:	mov    0x7e0(%rsp),%r9d
 1f83f24:	vxorps %xmm0,%xmm0,%xmm0
 1f83f28:	vmovups %xmm0,0x70c(%rsp)
 1f83f31:	vmovaps %xmm0,0x700(%rsp)
 1f83f3a:	movl   $0x0,0xf8(%rsp)
 1f83f45:	movq   $0x0,0x360(%rsp)
 1f83f51:	mov    %rax,0xa8(%rsp)
 1f83f59:	mov    %rdx,0x470(%rsp)
 1f83f61:	sub    $0x8,%rsp
 1f83f65:	mov    0x10(%rsp),%rdi
 1f83f6a:	lea    0x368(%rsp),%rax
 1f83f72:	lea    0x708(%rsp),%r11
 1f83f7a:	lea    0x100(%rsp),%r10
 1f83f82:	mov    %r13,%rsi
 1f83f85:	mov    %r15d,%edx
 1f83f88:	mov    %ecx,0x1b4(%rsp)
 1f83f8f:	push   %rax
 1f83f90:	push   %r10
 1f83f92:	push   %r11
 1f83f94:	call   1f97ee0 <node_rows_window_values>
 1f83f99:	add    $0x20,%rsp
 1f83f9d:	rdtsc
 1f83f9f:	mov    %r13,%rsi
 1f83fa2:	mov    %rdx,0x820(%rsp)
 1f83faa:	mov    %rax,0x90(%rsp)
 1f83fb2:	mov    0x8(%rsp),%rdi
 1f83fb7:	call   1f98d80 <node_rows_window_part>
 1f83fbc:	mov    0x8(%rsp),%r11
 1f83fc1:	rdtsc
 1f83fc3:	movl   $0x0,0x198(%rsp)
 1f83fce:	movq   $0x0,0x190(%rsp)
 1f83fda:	cmpb   $0x1,0xd58(%r11)
 1f83fe2:	mov    %rax,0xf0(%rsp)
 1f83fea:	mov    %rdx,0x108(%rsp)
 1f83ff2:	jne    1f8400f <node_facts_window_run+0x6b3f>
 1f83ff4:	lea    0x190(%rsp),%rcx
 1f83ffc:	mov    %r11,%rdi
 1f83fff:	mov    %r13,%rsi
 1f84002:	mov    %r15d,%edx
 1f84005:	call   1f98e90 <node_rows_window_summary>
 1f8400a:	mov    0x8(%rsp),%r11
 1f8400f:	mov    %r15,0x358(%rsp)
 1f84017:	rdtsc
 1f84019:	mov    0xdc0(%r11),%ecx
 1f84020:	movl   $0x0,0xdc0(%r11)
 1f8402b:	mov    %rax,0x100(%rsp)
 1f84033:	mov    %rdx,0x6a0(%rsp)
 1f8403b:	xor    %ebx,0x2f0(%rsp)
 1f84042:	mov    %ecx,0x1a0(%rsp)
 1f84049:	cmpl   $0x0,0xa90(%r11)
 1f84051:	mov    0x1b0(%rsp),%rbp
 1f84059:	je     1f8492b <node_facts_window_run+0x745b>
 1f8405f:	vpbroadcastq -0x19b5b60(%rip),%xmm2        # 5ce508 <.LCPI3_1>
 1f84068:	xor    %r15d,%r15d
 1f8406b:	jmp    1f8408d <node_facts_window_run+0x6bbd>
 1f8406d:	mov    0x8(%rsp),%r11
 1f84072:	incq   0xbb8(%rbp,%rsi,8)
 1f8407a:	mov    0xa90(%r11),%eax
 1f84081:	inc    %r15
 1f84084:	cmp    %rax,%r15
 1f84087:	jae    1f8492b <node_facts_window_run+0x745b>
 1f8408d:	mov    0xd40(%r11),%rax
 1f84094:	movzbl (%rax,%r15,1),%eax
 1f84099:	test   %al,%al
 1f8409b:	je     1f8407a <node_facts_window_run+0x6baa>
 1f8409d:	mov    0xa70(%r11),%rdx
 1f840a4:	mov    0xa68(%r11),%rcx
 1f840ab:	mov    (%rdx,%r15,4),%edx
 1f840af:	mov    (%rcx,%r15,4),%r14d
 1f840b3:	mov    0x651b8(%r13,%rdx,4),%edi
 1f840bb:	incq   0xb90(%rbp)
 1f840c2:	mov    0xa58(%r11),%rcx
 1f840c9:	mov    (%rcx,%r15,4),%ecx
 1f840cd:	add    %rcx,0xb98(%rbp)
 1f840d4:	cmp    $0x1,%al
 1f840d6:	jne    1f84140 <node_facts_window_run+0x6c70>
 1f840d8:	mov    0xa58(%r11),%rax
 1f840df:	mov    $0x1,%esi
 1f840e4:	mov    (%rax,%r15,4),%r10d
 1f840e8:	test   %r10d,%r10d
 1f840eb:	je     1f84072 <node_facts_window_run+0x6ba2>
 1f840ed:	mov    0xbe8(%r11),%rax
 1f840f4:	sub    %edi,%edx
 1f840f6:	xor    %ecx,%ecx
 1f840f8:	xor    %r11d,%r11d
 1f840fb:	inc    %edx
 1f840fd:	nopl   (%rax)
 1f84100:	lea    (%rdx,%r11,1),%r9d
 1f84104:	cmp    %edi,%r11d
 1f84107:	cmovae %r14d,%r9d
 1f8410b:	mov    %r9d,%r8d
 1f8410e:	shr    $0x3,%r8d
 1f84112:	and    $0xfffffff8,%r8d
 1f84116:	mov    0x28(%rax,%r8,8),%rbx
 1f8411b:	bt     %r9,%rbx
 1f8411f:	jb     1f844a8 <node_facts_window_run+0x6fd8>
 1f84125:	inc    %r11d
 1f84128:	cmp    %r11d,%r10d
 1f8412b:	jne    1f84100 <node_facts_window_run+0x6c30>
 1f8412d:	jmp    1f8406d <node_facts_window_run+0x6b9d>
 1f84132:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f84140:	mov    0xa68(%r11),%rcx
 1f84147:	mov    0xa70(%r11),%rdx
 1f8414e:	mov    0xa58(%r11),%rax
 1f84155:	xor    %r9d,%r9d
 1f84158:	mov    (%rcx,%r15,4),%ecx
 1f8415c:	mov    %rcx,0x18(%rsp)
 1f84161:	mov    (%rdx,%r15,4),%ecx
 1f84165:	mov    0xc40(%r11),%rdx
 1f8416c:	mov    0x651b8(%r13,%rcx,4),%esi
 1f84174:	cmp    %esi,(%rax,%r15,4)
 1f84178:	jbe    1f84184 <node_facts_window_run+0x6cb4>
 1f8417a:	mov    0x18(%rsp),%rax
 1f8417f:	movzbl (%rdx,%rax,1),%r9d
 1f84184:	mov    0xc60(%r11),%r8
 1f8418b:	mov    0xc80(%r11),%r10
 1f84192:	mov    %ecx,%edi
 1f84194:	sub    %esi,%edi
 1f84196:	mov    %ecx,%esi
 1f84198:	shr    $0x3,%esi
 1f8419b:	mov    0x940(%r11),%rax
 1f841a2:	inc    %edi
 1f841a4:	movzbl (%r8,%rdi,1),%ebx
 1f841a9:	shr    $0x3,%edi
 1f841ac:	mov    (%r10,%rsi,4),%r12d
 1f841b0:	mov    0xa50(%r11),%rsi
 1f841b7:	mov    %r10,0x150(%rsp)
 1f841bf:	mov    %r8,0x20(%rsp)
 1f841c4:	add    (%r10,%rdi,4),%ebx
 1f841c8:	movzbl (%r8,%rcx,1),%edi
 1f841cd:	movzbl (%rdx,%rcx,1),%r10d
 1f841d2:	mov    %r12d,%ecx
 1f841d5:	mov    (%rsi,%r15,4),%esi
 1f841d9:	mov    %rbx,0x10(%rsp)
 1f841de:	sub    %ebx,%ecx
 1f841e0:	mov    0x130(%rax),%rbx
 1f841e7:	add    %edi,%ecx
 1f841e9:	add    %r10d,%ecx
 1f841ec:	add    %ecx,%r9d
 1f841ef:	mov    (%rbx,%rsi,4),%r8d
 1f841f3:	cmp    $0xffffffff,%r8d
 1f841f7:	je     1f8449d <node_facts_window_run+0x6fcd>
 1f841fd:	mov    %r12d,0x270(%rsp)
 1f84205:	mov    %r10,0x1f0(%rsp)
 1f8420d:	mov    %rdi,0x68(%rsp)
 1f84212:	mov    0xdd4(%r11),%r10d
 1f84219:	movzbl 0xdd0(%r11),%edi
 1f84221:	mov    $0x4,%edx
 1f84226:	mov    %r14,0xd0(%rsp)
 1f8422e:	mov    %r10d,%ebx
 1f84231:	and    $0x3,%ebx
 1f84234:	test   %edi,%edi
 1f84236:	mov    %r10d,0x80(%rsp)
 1f8423e:	cmove  %edx,%ebx
 1f84241:	test   $0x4,%r10b
 1f84245:	movabs $0x8000000000000000,%r10
 1f8424f:	mov    $0x1,%edx
 1f84254:	cmove  %rdx,%r10
 1f84258:	test   %r8d,%r8d
 1f8425b:	sete   %dl
 1f8425e:	mov    %r10,0x30(%rsp)
 1f84263:	mov    %edi,0xb8(%rsp)
 1f8426a:	mov    %r8d,0xc0(%rsp)
 1f84272:	mov    %r9,0x38(%rsp)
 1f84277:	and    %dil,%dl
 1f8427a:	cmp    $0x2,%ebx
 1f8427d:	sete   %dil
 1f84281:	or     %dl,%dil
 1f84284:	movzbl %dil,%edx
 1f84288:	add    %r8d,%edx
 1f8428b:	mov    0x110(%rax),%r8
 1f84292:	cmp    $0x3,%ebx
 1f84295:	sete   %dil
 1f84299:	cmpb   $0x0,(%r8,%rsi,1)
 1f8429e:	setne  %r8b
 1f842a2:	cmp    %edx,%r9d
 1f842a5:	setne  %r12b
 1f842a9:	xor    %r10d,%r10d
 1f842ac:	or     %r8b,%r12b
 1f842af:	jne    1f84606 <node_facts_window_run+0x7136>
 1f842b5:	test   %edx,%edx
 1f842b7:	je     1f84606 <node_facts_window_run+0x7136>
 1f842bd:	mov    0x128(%rax),%rdx
 1f842c4:	mov    0x140(%rax),%rbp
 1f842cb:	mov    %ecx,%ecx
 1f842cd:	mov    (%rdx,%rsi,4),%edx
 1f842d0:	mov    0x148(%rax),%rsi
 1f842d7:	add    %rdx,%rsi
 1f842da:	add    %rdx,%rbp
 1f842dd:	shl    $0x3,%rdx
 1f842e1:	add    0x150(%rax),%rdx
 1f842e8:	cmp    $0x1,%ebx
 1f842eb:	mov    %rsi,0x110(%rsp)
 1f842f3:	sete   %al
 1f842f6:	cmp    $0x3,%ebx
 1f842f9:	mov    %rdx,0x88(%rsp)
 1f84301:	sete   %dl
 1f84304:	mov    0x38(%rsp),%r8
 1f84309:	cmp    $0x2,%r8d
 1f8430d:	lea    -0x1(%r8),%r9d
 1f84311:	mov    %r8d,%r8d
 1f84314:	setae  %sil
 1f84318:	and    %al,%sil
 1f8431b:	mov    0x18(%rsp),%rax
 1f84320:	shr    $0x3,%eax
 1f84323:	mov    %rax,0x230(%rsp)
 1f8432b:	or     %dl,%sil
 1f8432e:	mov    0x8(%rsp),%rax
 1f84333:	mov    0xca8(%rax),%r11
 1f8433a:	test   %sil,%sil
 1f8433d:	je     1f8450e <node_facts_window_run+0x703e>
 1f84343:	mov    0x80(%rsp),%eax
 1f8434a:	xor    %esi,%esi
 1f8434c:	and    $0x8,%eax
 1f8434f:	shr    $0x3,%eax
 1f84352:	and    %al,%dil
 1f84355:	mov    $0x0,%edi
 1f8435a:	mov    0x10(%rsp),%rax
 1f8435f:	cmovne %r9,%rdi
 1f84363:	sub    0x270(%rsp),%eax
 1f8436a:	neg    %r9
 1f8436d:	xor    %r14d,%r14d
 1f84370:	sub    0x1f0(%rsp),%eax
 1f84377:	neg    %rdi
 1f8437a:	sub    0x68(%rsp),%eax
 1f8437e:	mov    %rax,0x68(%rsp)
 1f84383:	mov    $0x1,%eax
 1f84388:	mov    %r9,0x50(%rsp)
 1f8438d:	jmp    1f843af <node_facts_window_run+0x6edf>
 1f8438f:	nop
 1f84390:	mov    0x28(%rsp),%r13
 1f84395:	inc    %rsi
 1f84398:	cmp    %r8,%rax
 1f8439b:	mov    %r10d,%r14d
 1f8439e:	setae  %dl
 1f843a1:	inc    %rax
 1f843a4:	or     %r12b,%dl
 1f843a7:	test   %dl,%dl
 1f843a9:	jne    1f84606 <node_facts_window_run+0x7136>
 1f843af:	lea    -0x1(%rax),%rdx
 1f843b3:	cmp    %rcx,%rdx
 1f843b6:	jae    1f843d0 <node_facts_window_run+0x6f00>
 1f843b8:	mov    0x10(%rsp),%rdx
 1f843bd:	lea    (%rdx,%rsi,1),%r9d
 1f843c1:	mov    %esi,%edx
 1f843c3:	jmp    1f84404 <node_facts_window_run+0x6f34>
 1f843c5:	data16 cs nopw 0x0(%rax,%rax,1)
 1f843d0:	mov    0x18(%rsp),%rdx
 1f843d5:	mov    0x20(%rsp),%r9
 1f843da:	mov    0x150(%rsp),%r12
 1f843e2:	mov    0x230(%rsp),%r10
 1f843ea:	movzbl (%r9,%rdx,1),%r9d
 1f843ef:	mov    0x68(%rsp),%rdx
 1f843f4:	add    (%r12,%r10,4),%r9d
 1f843f8:	lea    (%rdx,%rax,1),%r10d
 1f843fc:	lea    -0x1(%rax),%edx
 1f843ff:	lea    -0x1(%r10,%r9,1),%r9d
 1f84404:	or     %ebx,%edx
 1f84406:	lea    (%rdi,%rax,1),%r10
 1f8440a:	mov    $0x0,%edx
 1f8440f:	mov    $0x1,%r12b
 1f84412:	mov    %r9d,%r9d
 1f84415:	sete   %r13b
 1f84419:	xor    -0x1(%rbp,%rax,1),%r13b
 1f8441e:	cmp    $0x1,%r10
 1f84422:	mov    $0x1,%r10b
 1f84425:	cmove  0x30(%rsp),%rdx
 1f8442b:	cmp    %r13b,(%r11,%r9,1)
 1f8442f:	jne    1f8446d <node_facts_window_run+0x6f9d>
 1f84431:	mov    0x50(%rsp),%r12
 1f84436:	cmp    $0x1,%ebx
 1f84439:	sete   %r13b
 1f8443d:	add    %rax,%r12
 1f84440:	cmp    $0x1,%r12
 1f84444:	sete   %r12b
 1f84448:	and    %r13b,%r12b
 1f8444b:	mov    0x110(%rsp),%r13
 1f84453:	xor    -0x1(%r13,%rax,1),%r12b
 1f84458:	mov    0x8(%rsp),%r13
 1f8445d:	mov    0xcb0(%r13),%r13
 1f84464:	cmp    %r12b,0x0(%r13,%r9,1)
 1f84469:	setne  %r12b
 1f8446d:	test   $0x1,%r14b
 1f84471:	jne    1f84390 <node_facts_window_run+0x6ec0>
 1f84477:	mov    0x88(%rsp),%r10
 1f8447f:	mov    0x8(%rsp),%r14
 1f84484:	xor    -0x8(%r10,%rax,8),%rdx
 1f84489:	mov    0xcc8(%r14),%r10
 1f84490:	cmp    %rdx,(%r10,%r9,8)
 1f84494:	setne  %r10b
 1f84498:	jmp    1f84390 <node_facts_window_run+0x6ec0>
 1f8449d:	xor    %r10d,%r10d
 1f844a0:	xor    %r12d,%r12d
 1f844a3:	jmp    1f8463d <node_facts_window_run+0x716d>
 1f844a8:	mov    0x8(%rsp),%r11
 1f844ad:	mov    %r9d,%edx
 1f844b0:	mov    0xbb0(%r11),%rsi
 1f844b7:	movzbl (%rsi,%rdx,1),%esi
 1f844bb:	and    $0x3f,%sil
 1f844bf:	cmp    $0x14,%sil
 1f844c3:	je     1f844d5 <node_facts_window_run+0x7005>
 1f844c5:	mov    0xc30(%r11),%rsi
 1f844cc:	xor    %ecx,%ecx
 1f844ce:	cmpb   $0x7f,(%rsi,%rdx,1)
 1f844d2:	setne  %cl
 1f844d5:	and    $0x3f,%r9d
 1f844d9:	mov    $0x1,%edx
 1f844de:	mov    $0x2,%esi
 1f844e3:	shlx   %r9,%rdx,%rdx
 1f844e8:	test   %rdx,0x30(%rax,%r8,8)
 1f844ed:	jne    1f84072 <node_facts_window_run+0x6ba2>
 1f844f3:	test   %rdx,0x38(%rax,%r8,8)
 1f844f8:	mov    $0x3,%eax
 1f844fd:	cmovne %rax,%rcx
 1f84501:	incq   0xbb8(%rbp,%rcx,8)
 1f84509:	jmp    1f8407a <node_facts_window_run+0x6baa>
 1f8450e:	mov    %r9,0x50(%rsp)
 1f84513:	xor    %esi,%esi
 1f84515:	xor    %edi,%edi
 1f84517:	mov    0x10(%rsp),%rax
 1f8451c:	sub    0x270(%rsp),%eax
 1f84523:	sub    0x1f0(%rsp),%eax
 1f8452a:	sub    0x68(%rsp),%eax
 1f8452e:	jmp    1f84548 <node_facts_window_run+0x7078>
 1f84530:	inc    %rsi
 1f84533:	mov    %r10d,%edi
 1f84536:	cmp    %r8,%rsi
 1f84539:	setae  %dl
 1f8453c:	or     %r12b,%dl
 1f8453f:	cmp    $0x1,%dl
 1f84542:	je     1f84606 <node_facts_window_run+0x7136>
 1f84548:	cmp    %rcx,%rsi
 1f8454b:	jae    1f84560 <node_facts_window_run+0x7090>
 1f8454d:	mov    0x10(%rsp),%rdx
 1f84552:	add    %esi,%edx
 1f84554:	jmp    1f84587 <node_facts_window_run+0x70b7>
 1f84556:	cs nopw 0x0(%rax,%rax,1)
 1f84560:	mov    0x18(%rsp),%rdx
 1f84565:	mov    0x20(%rsp),%r9
 1f8456a:	mov    0x230(%rsp),%r10
 1f84572:	movzbl (%r9,%rdx,1),%edx
 1f84577:	mov    0x150(%rsp),%r9
 1f8457f:	add    (%r9,%r10,4),%edx
 1f84583:	add    %eax,%edx
 1f84585:	add    %esi,%edx
 1f84587:	mov    %esi,%r9d
 1f8458a:	or     %ebx,%r9d
 1f8458d:	mov    $0x1,%r10b
 1f84590:	mov    $0x1,%r12b
 1f84593:	mov    %edx,%edx
 1f84595:	sete   %r9b
 1f84599:	xor    0x0(%rbp,%rsi,1),%r9b
 1f8459e:	cmp    %r9b,(%r11,%rdx,1)
 1f845a2:	jne    1f845d7 <node_facts_window_run+0x7107>
 1f845a4:	cmp    $0x1,%ebx
 1f845a7:	sete   %r9b
 1f845ab:	cmp    %rsi,0x50(%rsp)
 1f845b0:	sete   %r14b
 1f845b4:	and    %r9b,%r14b
 1f845b7:	mov    0x110(%rsp),%r9
 1f845bf:	xor    (%r9,%rsi,1),%r14b
 1f845c3:	mov    0x8(%rsp),%r9
 1f845c8:	mov    0xcb0(%r9),%r9
 1f845cf:	cmp    %r14b,(%r9,%rdx,1)
 1f845d3:	setne  %r12b
 1f845d7:	test   $0x1,%dil
 1f845db:	jne    1f84530 <node_facts_window_run+0x7060>
 1f845e1:	mov    0x88(%rsp),%rdi
 1f845e9:	mov    0x8(%rsp),%r9
 1f845ee:	mov    (%rdi,%rsi,8),%rdi
 1f845f2:	mov    0xcc8(%r9),%r9
 1f845f9:	cmp    %rdi,(%r9,%rdx,8)
 1f845fd:	setne  %r10b
 1f84601:	jmp    1f84530 <node_facts_window_run+0x7060>
 1f84606:	mov    0x80(%rsp),%eax
 1f8460d:	mov    0x8(%rsp),%r11
 1f84612:	mov    0x1b0(%rsp),%rbp
 1f8461a:	mov    0xd0(%rsp),%r14
 1f84622:	mov    0x38(%rsp),%r9
 1f84627:	mov    0xc0(%rsp),%r8d
 1f8462f:	add    0xb8(%rsp),%eax
 1f84636:	mov    %eax,0xdd4(%r11)
 1f8463d:	cmp    $0xffffffff,%r8d
 1f84641:	vmovd  %r9d,%xmm1
 1f84646:	mov    %r12d,%ecx
 1f84649:	sete   %al
 1f8464c:	incq   0xba0(%rbp)
 1f84653:	or     %r10b,%r12b
 1f84656:	xor    $0x1,%cl
 1f84659:	mov    0xa58(%r11),%rdx
 1f84660:	and    %r10b,%cl
 1f84663:	vmovd  (%rdx,%r15,4),%xmm0
 1f84669:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f8466d:	vpaddq 0xba8(%rbp),%xmm0,%xmm0
 1f84675:	vmovdqu %xmm0,0xba8(%rbp)
 1f8467d:	vmovd  %r12d,%xmm0
 1f84682:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f84688:	movzbl %cl,%eax
 1f8468b:	vpmovzxbq %xmm0,%xmm0
 1f84690:	vptestmq %xmm2,%xmm0,%k0
 1f84696:	vmovdqu 0xbd8(%rbp),%xmm0
 1f8469e:	vpmovm2q %k0,%xmm1
 1f846a4:	vpsubq %xmm1,%xmm0,%xmm0
 1f846a8:	vmovdqu %xmm0,0xbd8(%rbp)
 1f846b0:	add    %rax,0xcc0(%rbp)
 1f846b7:	mov    0xd48(%r11),%rax
 1f846be:	mov    (%rax,%r15,8),%rax
 1f846c2:	add    %rax,0xc48(%rbp)
 1f846c9:	test   $0x1,%r12b
 1f846cd:	je     1f846f9 <node_facts_window_run+0x7229>
 1f846cf:	mov    0x13ac(%rbp),%eax
 1f846d5:	cmp    $0xf,%rax
 1f846d9:	ja     1f8407a <node_facts_window_run+0x6baa>
 1f846df:	mov    0x422c(%r13,%r14,4),%ecx
 1f846e7:	mov    %ecx,0x136c(%rbp,%rax,4)
 1f846ee:	incl   0x13ac(%rbp)
 1f846f4:	jmp    1f8407a <node_facts_window_run+0x6baa>
 1f846f9:	cmpb   $0x1,0xd58(%r11)
 1f84701:	jne    1f8407a <node_facts_window_run+0x6baa>
 1f84707:	mov    0xda0(%r11),%rax
 1f8470e:	mov    $0x4,%r12d
 1f84714:	movzbl (%rax,%r15,1),%r14d
 1f84719:	incq   0xce8(%rbp)
 1f84720:	mov    0xa70(%r11),%rax
 1f84727:	mov    0xd98(%r11),%rcx
 1f8472e:	mov    (%rax,%r15,4),%eax
 1f84732:	lea    0x1(%rax),%edx
 1f84735:	movzwl -0x2(%rcx,%rdx,2),%ebp
 1f8473a:	sub    0x651b8(%r13,%rax,4),%edx
 1f84742:	cmpb   $0x1,0xdc4(%r11)
 1f8474a:	movzwl -0x2(%rcx,%rdx,2),%eax
 1f8474f:	jne    1f84762 <node_facts_window_run+0x7292>
 1f84751:	mov    0xdc8(%r11),%r12d
 1f84758:	and    $0x3,%r12d
 1f8475c:	je     1f84831 <node_facts_window_run+0x7361>
 1f84762:	cmp    $0x1,%r12d
 1f84766:	mov    $0xffffffff,%r8d
 1f8476c:	sete   %cl
 1f8476f:	cmp    %ax,%bp
 1f84772:	sete   %bl
 1f84775:	and    %cl,%bl
 1f84777:	mov    0x940(%r11),%r13
 1f8477e:	sub    %eax,%ebp
 1f84780:	cmpq   $0x0,0x168(%r13)
 1f84788:	je     1f848e8 <node_facts_window_run+0x7418>
 1f8478e:	mov    0xa50(%r11),%rcx
 1f84795:	mov    (%rcx,%r15,4),%edx
 1f84799:	cmp    0x20(%r13),%edx
 1f8479d:	jae    1f848e8 <node_facts_window_run+0x7418>
 1f847a3:	mov    0x188(%r13),%rdi
 1f847aa:	movzbl %bl,%esi
 1f847ad:	mov    %ebp,%r9d
 1f847b0:	lea    (%rsi,%rdi,1),%rcx
 1f847b4:	add    %r9,%rcx
 1f847b7:	cmp    0x190(%r13),%rcx
 1f847be:	ja     1f84855 <node_facts_window_run+0x7385>
 1f847c4:	cmp    $0xfffe,%ebp
 1f847ca:	ja     1f84855 <node_facts_window_run+0x7385>
 1f847d0:	shl    $0x2,%rdi
 1f847d4:	mov    %r8d,0x150(%rsp)
 1f847dc:	mov    %rsi,0x10(%rsp)
 1f847e1:	lea    0x0(,%rax,4),%esi
 1f847e8:	add    0x180(%r13),%rdi
 1f847ef:	add    0xd90(%r11),%rsi
 1f847f6:	mov    %rdx,0x18(%rsp)
 1f847fb:	lea    0x0(,%r9,4),%rdx
 1f84803:	mov    %rdi,0x20(%rsp)
 1f84808:	mov    %r9,0x30(%rsp)
 1f8480d:	call   355eaf0 <memcpy>
 1f84812:	test   %bl,%bl
 1f84814:	je     1f8485e <node_facts_window_run+0x738e>
 1f84816:	mov    0x150(%rsp),%eax
 1f8481d:	mov    0x20(%rsp),%rcx
 1f84822:	mov    0x30(%rsp),%rdx
 1f84827:	mov    0x18(%rsp),%rsi
 1f8482c:	mov    %eax,(%rcx,%rdx,4)
 1f8482f:	jmp    1f84874 <node_facts_window_run+0x73a4>
 1f84831:	xor    %r8d,%r8d
 1f84834:	mov    $0x1,%bl
 1f84836:	xor    %r12d,%r12d
 1f84839:	mov    0x940(%r11),%r13
 1f84840:	sub    %eax,%ebp
 1f84842:	cmpq   $0x0,0x168(%r13)
 1f8484a:	jne    1f8478e <node_facts_window_run+0x72be>
 1f84850:	jmp    1f848e8 <node_facts_window_run+0x7418>
 1f84855:	incq   0x198(%r13)
 1f8485c:	jmp    1f848d9 <node_facts_window_run+0x7409>
 1f8485e:	mov    0x20(%rsp),%rax
 1f84863:	mov    0x18(%rsp),%rsi
 1f84868:	cmp    $0x1,%r12d
 1f8486c:	jne    1f84874 <node_facts_window_run+0x73a4>
 1f8486e:	movl   $0x0,(%rax)
 1f84874:	mov    0x188(%r13),%eax
 1f8487b:	mov    0x168(%r13),%rcx
 1f84882:	mov    0x10(%rsp),%rdi
 1f84887:	mov    0x8(%rsp),%r11
 1f8488c:	mov    $0x1,%edx
 1f84891:	vpbroadcastq -0x19b6392(%rip),%xmm2        # 5ce508 <.LCPI3_1>
 1f8489a:	mov    %eax,(%rcx,%rsi,4)
 1f8489d:	add    %ebp,%edi
 1f8489f:	cmp    $0x3,%r12d
 1f848a3:	mov    0x170(%r13),%rax
 1f848aa:	sete   %cl
 1f848ad:	add    %cl,%cl
 1f848af:	cmp    $0x2,%r12d
 1f848b3:	movzbl %cl,%ecx
 1f848b6:	cmove  %edx,%ecx
 1f848b9:	mov    %di,(%rax,%rsi,2)
 1f848bd:	mov    0xda0(%r11),%rax
 1f848c4:	mov    0x178(%r13),%rdx
 1f848cb:	xor    (%rax,%r15,1),%cl
 1f848cf:	mov    %cl,(%rdx,%rsi,1)
 1f848d2:	add    %rdi,0x188(%r13)
 1f848d9:	movzbl 0xdc4(%r11),%eax
 1f848e1:	add    %eax,0xdc8(%r11)
 1f848e8:	vmovd  %ebp,%xmm1
 1f848ec:	mov    0x1b0(%rsp),%rbp
 1f848f4:	mov    $0x101,%eax
 1f848f9:	mov    0x28(%rsp),%r13
 1f848fe:	bextr  %eax,%r14d,%eax
 1f84903:	and    $0x1,%r14d
 1f84907:	vmovd  %eax,%xmm0
 1f8490b:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f8490f:	vpaddq 0xcf0(%rbp),%xmm0,%xmm0
 1f84917:	vmovdqu %xmm0,0xcf0(%rbp)
 1f8491f:	add    %r14,0xd00(%rbp)
 1f84926:	jmp    1f8407a <node_facts_window_run+0x6baa>
 1f8492b:	shlq   $0x20,0x430(%rsp)
 1f84934:	shlq   $0x20,0x4f0(%rsp)
 1f8493d:	shlq   $0x20,0x3f0(%rsp)
 1f84946:	shlq   $0x20,0x570(%rsp)
 1f8494f:	shlq   $0x20,0x650(%rsp)
 1f84958:	shlq   $0x20,0x610(%rsp)
 1f84961:	shlq   $0x20,0x4b0(%rsp)
 1f8496a:	shlq   $0x20,0x5d0(%rsp)
 1f84973:	shlq   $0x20,0xe8(%rsp)
 1f8497c:	shlq   $0x20,0x780(%rsp)
 1f84985:	shlq   $0x20,0x490(%rsp)
 1f8498e:	shlq   $0x20,0x740(%rsp)
 1f84997:	shlq   $0x20,0x470(%rsp)
 1f849a0:	shlq   $0x20,0x820(%rsp)
 1f849a9:	shlq   $0x20,0x108(%rsp)
 1f849b2:	mov    $0x1,%r8d
 1f849b8:	vmovd  0x358(%rsp),%xmm1
 1f849c1:	mov    0x6a8(%rsp),%rbx
 1f849c9:	mov    0x6a0(%rsp),%r12
 1f849d1:	mov    0x1ac(%rsp),%eax
 1f849d8:	vmovd  %ebx,%xmm0
 1f849dc:	shl    $0x20,%r12
 1f849e0:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f849e4:	vpaddq 0xbe8(%rbp),%xmm0,%xmm0
 1f849ec:	vmovdqu %xmm0,0xbe8(%rbp)
 1f849f4:	cmp    %eax,0x2f0(%rsp)
 1f849fb:	jne    1f84a49 <node_facts_window_run+0x7579>
 1f849fd:	mov    0xca8(%r11),%rsi
 1f84a04:	mov    0xcb8(%r11),%rdi
 1f84a0b:	mov    %rbx,%rdx
 1f84a0e:	mov    %r11,%r14
 1f84a11:	call   355eae0 <strlen+0x10>
 1f84a16:	mov    0xc8(%rsp),%r15
 1f84a1e:	mov    0x78(%rsp),%rsi
 1f84a23:	mov    0x338(%rsp),%r13
 1f84a2b:	test   %eax,%eax
 1f84a2d:	je     1f84a8b <node_facts_window_run+0x75bb>
 1f84a2f:	mov    %r14,%r11
 1f84a32:	mov    0x70(%rsp),%rax
 1f84a37:	mov    0xa0(%rsp),%rcx
 1f84a3f:	mov    0x100(%rsp),%r14
 1f84a47:	jmp    1f84ac6 <node_facts_window_run+0x75f6>
 1f84a49:	mov    0xc8(%rsp),%r15
 1f84a51:	mov    0x78(%rsp),%rsi
 1f84a56:	mov    0x338(%rsp),%r13
 1f84a5e:	mov    0x70(%rsp),%rax
 1f84a63:	mov    0xa0(%rsp),%rcx
 1f84a6b:	mov    0x100(%rsp),%r14
 1f84a73:	jmp    1f84acc <node_facts_window_run+0x75fc>
 1f84a75:	setb   %al
 1f84a78:	test   %r15d,%r15d
 1f84a7b:	sete   %cl
 1f84a7e:	test   %cl,%al
 1f84a80:	je     1f83b89 <node_facts_window_run+0x66b9>
 1f84a86:	jmp    1f83b96 <node_facts_window_run+0x66c6>
 1f84a8b:	mov    0xcb0(%r14),%rsi
 1f84a92:	mov    0xcc0(%r14),%rdi
 1f84a99:	mov    %rbx,%rdx
 1f84a9c:	call   355eae0 <strlen+0x10>
 1f84aa1:	test   %eax,%eax
 1f84aa3:	je     1f84f25 <node_facts_window_run+0x7a55>
 1f84aa9:	mov    %r14,%r11
 1f84aac:	mov    0x70(%rsp),%rax
 1f84ab1:	mov    0xa0(%rsp),%rcx
 1f84ab9:	mov    0x100(%rsp),%r14
 1f84ac1:	mov    0x78(%rsp),%rsi
 1f84ac6:	mov    $0x1,%r8d
 1f84acc:	mov    0x570(%rsp),%rdx
 1f84ad4:	or     0x430(%rsp),%rsi
 1f84adc:	or     0x4f0(%rsp),%r13
 1f84ae4:	or     0x3f0(%rsp),%rax
 1f84aec:	add    %r8,0xbf8(%rbp)
 1f84af3:	or     %r12,%r14
 1f84af6:	or     %rdx,0x370(%rsp)
 1f84afe:	mov    0x650(%rsp),%rdx
 1f84b06:	or     %rdx,0x3b0(%rsp)
 1f84b0e:	mov    0x610(%rsp),%rdx
 1f84b16:	or     %rdx,0x2b0(%rsp)
 1f84b1e:	mov    0x4b0(%rsp),%rdx
 1f84b26:	or     %rdx,0x530(%rsp)
 1f84b2e:	mov    0xe8(%rsp),%rdx
 1f84b36:	or     0x5d0(%rsp),%rcx
 1f84b3e:	or     %rdx,0x6c0(%rsp)
 1f84b46:	mov    0x780(%rsp),%rdx
 1f84b4e:	or     %rdx,0xb0(%rsp)
 1f84b56:	mov    0x490(%rsp),%rdx
 1f84b5e:	or     %rdx,0x40(%rsp)
 1f84b63:	mov    0x740(%rsp),%rdx
 1f84b6b:	or     %rdx,0x98(%rsp)
 1f84b73:	mov    0x470(%rsp),%rdx
 1f84b7b:	or     %rdx,0xa8(%rsp)
 1f84b83:	mov    0x820(%rsp),%rdx
 1f84b8b:	or     %rdx,0x90(%rsp)
 1f84b93:	mov    0x108(%rsp),%rdx
 1f84b9b:	or     %rdx,0xf0(%rsp)
 1f84ba3:	cmpb   $0x1,0xd58(%r11)
 1f84bab:	jne    1f84c40 <node_facts_window_run+0x7770>
 1f84bb1:	mov    0x1a4(%rsp),%edx
 1f84bb8:	mov    $0x1,%ebx
 1f84bbd:	xor    0x1a8(%rsp),%edx
 1f84bc4:	cmp    0x190(%rsp),%edx
 1f84bcb:	jne    1f84c49 <node_facts_window_run+0x7779>
 1f84bcd:	mov    0xdc(%rsp),%edx
 1f84bd4:	mov    %rax,0x70(%rsp)
 1f84bd9:	cmp    0x194(%rsp),%edx
 1f84be0:	jne    1f84c44 <node_facts_window_run+0x7774>
 1f84be2:	mov    0xe0(%rsp),%eax
 1f84be9:	cmp    0x198(%rsp),%eax
 1f84bf0:	jne    1f84c44 <node_facts_window_run+0x7774>
 1f84bf2:	mov    %rsi,0x78(%rsp)
 1f84bf7:	mov    %rcx,0xa0(%rsp)
 1f84bff:	mov    0xd98(%r11),%rsi
 1f84c06:	mov    0xda8(%r11),%rdi
 1f84c0d:	mov    %r11,%r12
 1f84c10:	mov    0x358(%rsp),%rax
 1f84c18:	lea    (%rax,%rax,1),%rdx
 1f84c1c:	call   355eae0 <strlen+0x10>
 1f84c21:	test   %eax,%eax
 1f84c23:	je     1f84ff6 <node_facts_window_run+0x7b26>
 1f84c29:	mov    0x70(%rsp),%rax
 1f84c2e:	mov    0xa0(%rsp),%rcx
 1f84c36:	mov    0x78(%rsp),%rsi
 1f84c3b:	mov    %r12,%r11
 1f84c3e:	jmp    1f84c49 <node_facts_window_run+0x7779>
 1f84c40:	xor    %ebx,%ebx
 1f84c42:	jmp    1f84c49 <node_facts_window_run+0x7779>
 1f84c44:	mov    0x70(%rsp),%rax
 1f84c49:	vmovd  0x340(%rsp),%xmm1
 1f84c52:	mov    0x530(%rsp),%rdx
 1f84c5a:	vmovd  %ebx,%xmm2
 1f84c5e:	mov    0xf0(%rsp),%rdi
 1f84c66:	vpmovzxdq 0x860(%rsp),%ymm7
 1f84c70:	vmovq  0x370(%rsp),%xmm4
 1f84c79:	vmovq  %r13,%xmm3
 1f84c7e:	vmovq  %rsi,%xmm5
 1f84c83:	mov    0x90(%rsp),%rsi
 1f84c8b:	mov    0xa8(%rsp),%r8
 1f84c93:	sub    %rdx,%rcx
 1f84c96:	sub    %rdi,%r14
 1f84c99:	vmovq  %rcx,%xmm0
 1f84c9e:	mov    0x2b0(%rsp),%rcx
 1f84ca6:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84caa:	vmovd  0xe0(%rsp),%xmm1
 1f84cb3:	sub    %rcx,%rdx
 1f84cb6:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f84cba:	vmovq  %rax,%xmm2
 1f84cbf:	mov    0x3b0(%rsp),%rax
 1f84cc7:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f84ccd:	vpaddq 0xd08(%rbp),%ymm0,%ymm0
 1f84cd5:	vmovd  0x350(%rsp),%xmm1
 1f84cde:	vpbroadcastq %rax,%ymm6
 1f84ce4:	sub    %rax,%rcx
 1f84ce7:	mov    %rsi,%rax
 1f84cea:	sub    %r8,%rax
 1f84ced:	vmovdqu %ymm0,0xd08(%rbp)
 1f84cf5:	add    %r14,0xd28(%rbp)
 1f84cfc:	vmovq  0x348(%rsp),%xmm0
 1f84d05:	vpaddq 0xc90(%rbp),%ymm7,%ymm7
 1f84d0d:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84d11:	vmovdqu %ymm7,0xc90(%rbp)
 1f84d19:	vpaddq 0xcb0(%rbp),%xmm0,%xmm0
 1f84d21:	vmovdqu %xmm0,0xcb0(%rbp)
 1f84d29:	vpunpcklqdq %xmm2,%xmm3,%xmm0
 1f84d2d:	vmovq  0x98(%rsp),%xmm2
 1f84d36:	vmovq  0x40(%rsp),%xmm3
 1f84d3c:	vinserti128 $0x1,%xmm4,%ymm0,%ymm0
 1f84d42:	vpbroadcastq %r8,%ymm4
 1f84d48:	vpblendd $0xc0,%ymm6,%ymm0,%ymm1
 1f84d4e:	vpermq $0x90,%ymm0,%ymm0
 1f84d54:	vpbroadcastq %rsi,%ymm6
 1f84d5a:	vpblendd $0x3,%ymm5,%ymm0,%ymm0
 1f84d60:	vpbroadcastq %rdi,%ymm5
 1f84d66:	vpsubq %ymm0,%ymm1,%ymm0
 1f84d6a:	vmovdqu 0x8f0(%rsp),%ymm1
 1f84d73:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f84d77:	vpblendd $0x30,%ymm4,%ymm2,%ymm3
 1f84d7d:	vpermq $0xd0,%ymm2,%ymm2
 1f84d83:	vmovdqa64 -0x1ace08d(%rip),%zmm4        # 4b6d00 <abi_test_hex.digits+0xb980>
 1f84d8d:	vpblendd $0xc0,%ymm5,%ymm3,%ymm3
 1f84d93:	vpmovzxdq 0x890(%rsp),%zmm5
 1f84d9e:	vinserti64x4 $0x1,%ymm0,%zmm1,%zmm0
 1f84da5:	vpaddq 0xc00(%rbp),%zmm0,%zmm0
 1f84dac:	vmovq  %rcx,%xmm1
 1f84db1:	vmovdqu64 %zmm0,0xc00(%rbp)
 1f84db8:	vmovq  %rax,%xmm0
 1f84dbd:	mov    0xb0(%rsp),%rax
 1f84dc5:	add    %rdx,0xc40(%rbp)
 1f84dcc:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f84dd0:	vpmovzxdq 0xd8(%rsp),%xmm1
 1f84dda:	vmovq  %rax,%xmm7
 1f84ddf:	sub    0x6c0(%rsp),%rax
 1f84de7:	vpblendd $0x3,%ymm7,%ymm2,%ymm2
 1f84ded:	vpblendd $0xc0,%ymm6,%ymm2,%ymm2
 1f84df3:	vmovdqa64 -0x1ace13d(%rip),%zmm6        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f84dfd:	vpsubq %ymm2,%ymm3,%ymm2
 1f84e01:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f84e07:	vpaddq 0xcc8(%rbp),%ymm0,%ymm0
 1f84e0f:	vmovq  %rax,%xmm8
 1f84e14:	mov    $0x80,%al
 1f84e16:	kmovd  %eax,%k1
 1f84e1a:	mov    0x6b0(%rsp),%rax
 1f84e22:	vpermi2q %zmm8,%zmm2,%zmm6
 1f84e28:	vmovdqu %ymm0,0xcc8(%rbp)
 1f84e30:	vpermi2q %zmm5,%zmm6,%zmm4
 1f84e36:	vpbroadcastq %rax,%zmm4{%k1}
 1f84e3c:	vpaddq 0xc50(%rbp),%zmm4,%zmm0
 1f84e46:	vmovdqu64 %zmm0,0xc50(%rbp)
 1f84e50:	vmovups 0x9d0(%r11),%zmm0
 1f84e5a:	vmovups 0x268(%r11),%zmm1
 1f84e64:	vmovups 0x8b0(%rsp),%zmm3
 1f84e6f:	vmovaps 0x880(%rsp),%xmm2
 1f84e78:	xor    %esi,%esi
 1f84e7a:	mov    %r15,%rdx
 1f84e7d:	vmovups %zmm0,0x268(%r11)
 1f84e87:	vmovups %zmm1,0x9d0(%r11)
 1f84e91:	vmovups 0xa10(%r11),%xmm0
 1f84e9a:	vmovups 0x2a8(%r11),%xmm1
 1f84ea3:	vmovups %xmm0,0x2a8(%r11)
 1f84eac:	vmovups %xmm1,0xa10(%r11)
 1f84eb5:	vmovaps 0x870(%rsp),%xmm1
 1f84ebe:	mov    0x2b8(%r11),%rax
 1f84ec5:	mov    0xa20(%r11),%rcx
 1f84ecc:	mov    %rcx,0x2b8(%r11)
 1f84ed3:	mov    %rax,0xa20(%r11)
 1f84eda:	mov    0x6b8(%rsp),%rax
 1f84ee2:	vmovups %zmm3,0x1f0(%r11)
 1f84eec:	mov    %rax,0x230(%r11)
 1f84ef3:	vmovups %xmm2,0x240(%r11)
 1f84efc:	vmovlps %xmm1,0x258(%r11)
 1f84f05:	mov    0x9b8(%r11),%rdi
 1f84f0c:	add    $0xd08,%rsp
 1f84f13:	pop    %rbx
 1f84f14:	pop    %r12
 1f84f16:	pop    %r13
 1f84f18:	pop    %r14
 1f84f1a:	pop    %r15
 1f84f1c:	pop    %rbp
 1f84f1d:	vzeroupper
 1f84f20:	jmp    355eb60 <memset>
 1f84f25:	mov    0xcc8(%r14),%rsi
 1f84f2c:	mov    0xcd0(%r14),%rdi
 1f84f33:	mov    0x698(%rsp),%rdx
 1f84f3b:	call   355eae0 <strlen+0x10>
 1f84f40:	mov    0x100(%rsp),%r14
 1f84f48:	test   %eax,%eax
 1f84f4a:	jne    1f8507b <node_facts_window_run+0x7bab>
 1f84f50:	movzbl 0x4f(%rsp),%ecx
 1f84f55:	xor    %eax,%eax
 1f84f57:	mov    $0x1,%r8d
 1f84f5d:	mov    %cl,%al
 1f84f5f:	xor    0x350(%rsp),%eax
 1f84f66:	mov    0xa0(%rsp),%rcx
 1f84f6e:	cmp    0xf8(%rsp),%eax
 1f84f75:	mov    0x70(%rsp),%rax
 1f84f7a:	jne    1f85092 <node_facts_window_run+0x7bc2>
 1f84f80:	movzbl 0x4e(%rsp),%esi
 1f84f85:	mov    0x8(%rsp),%r11
 1f84f8a:	xor    %edx,%edx
 1f84f8c:	mov    %sil,%dl
 1f84f8f:	xor    0x348(%rsp),%rdx
 1f84f97:	cmp    0x360(%rsp),%rdx
 1f84f9f:	jne    1f85071 <node_facts_window_run+0x7ba1>
 1f84fa5:	vmovdqu 0x72c(%rsp),%xmm1
 1f84fae:	vmovdqa 0x720(%rsp),%xmm0
 1f84fb7:	mov    0x78(%rsp),%rsi
 1f84fbc:	vpxor  0x700(%rsp),%xmm0,%xmm0
 1f84fc5:	vpternlogq $0xf6,0x70c(%rsp),%xmm1,%xmm0
 1f84fd1:	vptest %xmm0,%xmm0
 1f84fd6:	jne    1f84acc <node_facts_window_run+0x75fc>
 1f84fdc:	mov    0x1a0(%rsp),%edx
 1f84fe3:	xor    %r8d,%r8d
 1f84fe6:	cmp    %edx,0x340(%rsp)
 1f84fed:	setne  %r8b
 1f84ff1:	jmp    1f84acc <node_facts_window_run+0x75fc>
 1f84ff6:	mov    0xda0(%r12),%rsi
 1f84ffe:	mov    0xdb0(%r12),%rdi
 1f85006:	mov    0x690(%rsp),%rdx
 1f8500e:	call   355eae0 <strlen+0x10>
 1f85013:	mov    %r12,%r11
 1f85016:	mov    0xa0(%rsp),%rcx
 1f8501e:	mov    0x78(%rsp),%rsi
 1f85023:	test   %eax,%eax
 1f85025:	mov    0x70(%rsp),%rax
 1f8502a:	jne    1f84c49 <node_facts_window_run+0x7779>
 1f85030:	mov    0xd8(%rsp),%edx
 1f85037:	mov    0xd90(%r11),%rsi
 1f8503e:	mov    0xdb8(%r11),%rdi
 1f85045:	shl    $0x2,%rdx
 1f85049:	call   355eae0 <strlen+0x10>
 1f8504e:	xor    %ebx,%ebx
 1f85050:	test   %eax,%eax
 1f85052:	mov    0x78(%rsp),%rsi
 1f85057:	mov    0xa0(%rsp),%rcx
 1f8505f:	mov    0x8(%rsp),%r11
 1f85064:	mov    0x70(%rsp),%rax
 1f85069:	setne  %bl
 1f8506c:	jmp    1f84c49 <node_facts_window_run+0x7779>
 1f85071:	mov    0x78(%rsp),%rsi
 1f85076:	jmp    1f84acc <node_facts_window_run+0x75fc>
 1f8507b:	mov    0x8(%rsp),%r11
 1f85080:	mov    0x70(%rsp),%rax
 1f85085:	mov    0xa0(%rsp),%rcx
 1f8508d:	jmp    1f84ac1 <node_facts_window_run+0x75f1>
 1f85092:	mov    0x8(%rsp),%r11
 1f85097:	mov    0x78(%rsp),%rsi
 1f8509c:	jmp    1f84acc <node_facts_window_run+0x75fc>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
