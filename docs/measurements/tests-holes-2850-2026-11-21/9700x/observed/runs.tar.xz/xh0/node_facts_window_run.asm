
results/xh0/compiler:     file format elf64-x86-64


Disassembly of section .text.buster_start:

Disassembly of section .text.buster_checker:

Disassembly of section .text:

0000000001f7c550 <node_facts_window_run>:
 1f7c550:	push   %rbp
 1f7c551:	push   %r15
 1f7c553:	push   %r14
 1f7c555:	push   %r13
 1f7c557:	push   %r12
 1f7c559:	push   %rbx
 1f7c55a:	sub    $0xc98,%rsp
 1f7c561:	mov    0x938(%rdi),%r15
 1f7c568:	mov    0x8(%rsi),%r12d
 1f7c56c:	mov    %rsi,%r13
 1f7c56f:	test   %r12,%r12
 1f7c572:	je     1f7c737 <node_facts_window_run+0x1e7>
 1f7c578:	mov    %r12d,%eax
 1f7c57b:	and    $0x7,%eax
 1f7c57e:	cmp    $0x8,%r12d
 1f7c582:	jae    1f7c58b <node_facts_window_run+0x3b>
 1f7c584:	xor    %ecx,%ecx
 1f7c586:	jmp    1f7cb3f <node_facts_window_run+0x5ef>
 1f7c58b:	mov    %r12d,%edx
 1f7c58e:	and    $0xfffffff8,%edx
 1f7c591:	xor    %ecx,%ecx
 1f7c593:	jmp    1f7c5bb <node_facts_window_run+0x6b>
 1f7c595:	data16 cs nopw 0x0(%rax,%rax,1)
 1f7c5a0:	xor    %esi,%esi
 1f7c5a2:	mov    0x9b8(%rdi),%r8
 1f7c5a9:	mov    %sil,0x7(%r8,%rcx,1)
 1f7c5ae:	add    $0x8,%rcx
 1f7c5b2:	cmp    %rcx,%rdx
 1f7c5b5:	je     1f7c72e <node_facts_window_run+0x1de>
 1f7c5bb:	mov    0x9b0(%rdi),%rsi
 1f7c5c2:	cmpb   $0x0,(%rsi,%rcx,1)
 1f7c5c6:	je     1f7c5e0 <node_facts_window_run+0x90>
 1f7c5c8:	movzbl 0x69454(%r13,%rcx,1),%esi
 1f7c5d1:	jmp    1f7c5e2 <node_facts_window_run+0x92>
 1f7c5d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c5e0:	xor    %esi,%esi
 1f7c5e2:	mov    0x9b8(%rdi),%r8
 1f7c5e9:	mov    %sil,(%r8,%rcx,1)
 1f7c5ed:	mov    0x9b0(%rdi),%rsi
 1f7c5f4:	cmpb   $0x0,0x1(%rsi,%rcx,1)
 1f7c5f9:	je     1f7c610 <node_facts_window_run+0xc0>
 1f7c5fb:	movzbl 0x69455(%r13,%rcx,1),%esi
 1f7c604:	jmp    1f7c612 <node_facts_window_run+0xc2>
 1f7c606:	cs nopw 0x0(%rax,%rax,1)
 1f7c610:	xor    %esi,%esi
 1f7c612:	mov    0x9b8(%rdi),%r8
 1f7c619:	mov    %sil,0x1(%r8,%rcx,1)
 1f7c61e:	mov    0x9b0(%rdi),%rsi
 1f7c625:	cmpb   $0x0,0x2(%rsi,%rcx,1)
 1f7c62a:	je     1f7c640 <node_facts_window_run+0xf0>
 1f7c62c:	movzbl 0x69456(%r13,%rcx,1),%esi
 1f7c635:	jmp    1f7c642 <node_facts_window_run+0xf2>
 1f7c637:	nopw   0x0(%rax,%rax,1)
 1f7c640:	xor    %esi,%esi
 1f7c642:	mov    0x9b8(%rdi),%r8
 1f7c649:	mov    %sil,0x2(%r8,%rcx,1)
 1f7c64e:	mov    0x9b0(%rdi),%rsi
 1f7c655:	cmpb   $0x0,0x3(%rsi,%rcx,1)
 1f7c65a:	je     1f7c670 <node_facts_window_run+0x120>
 1f7c65c:	movzbl 0x69457(%r13,%rcx,1),%esi
 1f7c665:	jmp    1f7c672 <node_facts_window_run+0x122>
 1f7c667:	nopw   0x0(%rax,%rax,1)
 1f7c670:	xor    %esi,%esi
 1f7c672:	mov    0x9b8(%rdi),%r8
 1f7c679:	mov    %sil,0x3(%r8,%rcx,1)
 1f7c67e:	mov    0x9b0(%rdi),%rsi
 1f7c685:	cmpb   $0x0,0x4(%rsi,%rcx,1)
 1f7c68a:	je     1f7c6a0 <node_facts_window_run+0x150>
 1f7c68c:	movzbl 0x69458(%r13,%rcx,1),%esi
 1f7c695:	jmp    1f7c6a2 <node_facts_window_run+0x152>
 1f7c697:	nopw   0x0(%rax,%rax,1)
 1f7c6a0:	xor    %esi,%esi
 1f7c6a2:	mov    0x9b8(%rdi),%r8
 1f7c6a9:	mov    %sil,0x4(%r8,%rcx,1)
 1f7c6ae:	mov    0x9b0(%rdi),%rsi
 1f7c6b5:	cmpb   $0x0,0x5(%rsi,%rcx,1)
 1f7c6ba:	je     1f7c6d0 <node_facts_window_run+0x180>
 1f7c6bc:	movzbl 0x69459(%r13,%rcx,1),%esi
 1f7c6c5:	jmp    1f7c6d2 <node_facts_window_run+0x182>
 1f7c6c7:	nopw   0x0(%rax,%rax,1)
 1f7c6d0:	xor    %esi,%esi
 1f7c6d2:	mov    0x9b8(%rdi),%r8
 1f7c6d9:	mov    %sil,0x5(%r8,%rcx,1)
 1f7c6de:	mov    0x9b0(%rdi),%rsi
 1f7c6e5:	cmpb   $0x0,0x6(%rsi,%rcx,1)
 1f7c6ea:	je     1f7c700 <node_facts_window_run+0x1b0>
 1f7c6ec:	movzbl 0x6945a(%r13,%rcx,1),%esi
 1f7c6f5:	jmp    1f7c702 <node_facts_window_run+0x1b2>
 1f7c6f7:	nopw   0x0(%rax,%rax,1)
 1f7c700:	xor    %esi,%esi
 1f7c702:	mov    0x9b8(%rdi),%r8
 1f7c709:	mov    %sil,0x6(%r8,%rcx,1)
 1f7c70e:	mov    0x9b0(%rdi),%rsi
 1f7c715:	cmpb   $0x0,0x7(%rsi,%rcx,1)
 1f7c71a:	je     1f7c5a0 <node_facts_window_run+0x50>
 1f7c720:	movzbl 0x6945b(%r13,%rcx,1),%esi
 1f7c729:	jmp    1f7c5a2 <node_facts_window_run+0x52>
 1f7c72e:	test   %rax,%rax
 1f7c731:	jne    1f7cb3f <node_facts_window_run+0x5ef>
 1f7c737:	vpbroadcastq %r13,%ymm0
 1f7c73d:	vpaddq -0x19bd3e5(%rip),%ymm0,%ymm0        # 5bf360 <.LCPI3_0>
 1f7c745:	vmovups 0x1f0(%rdi),%zmm1
 1f7c74f:	mov    0x9b8(%rdi),%rax
 1f7c756:	mov    0x9c0(%rdi),%rdx
 1f7c75d:	mov    0x69250(%r13),%r8d
 1f7c764:	lea    0x2c(%r13),%r11
 1f7c768:	lea    0x6a4d4(%r13),%rcx
 1f7c76f:	lea    0x79854(%r13),%rsi
 1f7c776:	lea    0x73754(%r13),%r9
 1f7c77d:	mov    0x230(%rdi),%r10
 1f7c784:	vmovdqu 0x240(%rdi),%xmm3
 1f7c78c:	vmovq  0x258(%rdi),%xmm2
 1f7c794:	mov    %r11,0x1f0(%rdi)
 1f7c79b:	mov    %rax,0x1f8(%rdi)
 1f7c7a2:	mov    %rcx,0x200(%rdi)
 1f7c7a9:	mov    %rdx,0x208(%rdi)
 1f7c7b0:	mov    $0x1,%edx
 1f7c7b5:	vmovdqu %ymm0,0x210(%rdi)
 1f7c7bd:	mov    %rsi,0x230(%rdi)
 1f7c7c4:	mov    %r9,0x240(%rdi)
 1f7c7cb:	mov    %r8d,0x258(%rdi)
 1f7c7d2:	vmovups %zmm1,0x840(%rsp)
 1f7c7da:	mov    %r10,0x648(%rsp)
 1f7c7e2:	vmovdqa %xmm3,0x810(%rsp)
 1f7c7eb:	vmovdqa %xmm2,0x800(%rsp)
 1f7c7f4:	mov    %r11,0xe0(%rsp)
 1f7c7fc:	xor    %esi,%esi
 1f7c7fe:	mov    %rdi,0x8(%rsp)
 1f7c803:	vmovups 0x9c8(%rdi),%zmm0
 1f7c80d:	vmovups 0x268(%rdi),%zmm1
 1f7c817:	vmovups %zmm0,0x268(%rdi)
 1f7c821:	vmovups %zmm1,0x9c8(%rdi)
 1f7c82b:	vmovdqu 0xa08(%rdi),%xmm0
 1f7c833:	vmovdqu 0x2a8(%rdi),%xmm1
 1f7c83b:	vmovdqu %xmm0,0x2a8(%rdi)
 1f7c843:	vmovdqu %xmm1,0xa08(%rdi)
 1f7c84b:	mov    0xa18(%rdi),%rcx
 1f7c852:	mov    0x2b8(%rdi),%rax
 1f7c859:	mov    %rcx,0x2b8(%rdi)
 1f7c860:	lea    0xa20(%rdi),%rcx
 1f7c867:	mov    %rax,0xa18(%rdi)
 1f7c86e:	movl   $0x0,0xa20(%rdi)
 1f7c878:	mov    %r12d,0xa24(%rdi)
 1f7c87f:	mov    %rcx,0x248(%rdi)
 1f7c886:	movl   $0x0,0x25c(%rdi)
 1f7c890:	vzeroupper
 1f7c893:	call   1f7ac80 <node_facts_given>
 1f7c898:	mov    0x8(%rsp),%rax
 1f7c89d:	mov    0x8(%rsp),%rdi
 1f7c8a2:	xor    %esi,%esi
 1f7c8a4:	xor    %edx,%edx
 1f7c8a6:	xor    %ecx,%ecx
 1f7c8a8:	mov    0xe0(%rax),%rbx
 1f7c8af:	call   1f7ae80 <node_facts_window>
 1f7c8b4:	mov    0x8(%rsp),%rax
 1f7c8b9:	mov    0x8(%rsp),%rdi
 1f7c8be:	xor    %esi,%esi
 1f7c8c0:	mov    0xe0(%rax),%rax
 1f7c8c7:	sub    %rbx,%rax
 1f7c8ca:	add    %rax,0xa08(%r15)
 1f7c8d1:	call   1f7bad0 <node_facts_lists_same>
 1f7c8d6:	mov    0x8(%rsp),%rdi
 1f7c8db:	test   %al,%al
 1f7c8dd:	jne    1f7c932 <node_facts_window_run+0x3e2>
 1f7c8df:	incq   0x9d8(%r15)
 1f7c8e6:	mov    0x938(%rdi),%rax
 1f7c8ed:	mov    0x11b8(%rax),%ecx
 1f7c8f3:	cmp    $0xf,%rcx
 1f7c8f7:	ja     1f7c932 <node_facts_window_run+0x3e2>
 1f7c8f9:	mov    0x422c(%r13),%edx
 1f7c900:	mov    %edx,0x1158(%rax,%rcx,4)
 1f7c907:	mov    0x1f0(%rdi),%rcx
 1f7c90e:	mov    0x11b8(%rax),%edx
 1f7c914:	movzbl (%rcx),%ecx
 1f7c917:	mov    %cl,0x1198(%rax,%rdx,1)
 1f7c91e:	mov    0x11b8(%rax),%ecx
 1f7c924:	movb   $0x2,0x11a8(%rax,%rcx,1)
 1f7c92c:	incl   0x11b8(%rax)
 1f7c932:	mov    %r12,0x90(%rsp)
 1f7c93a:	mov    %r13,0x28(%rsp)
 1f7c93f:	test   %r12d,%r12d
 1f7c942:	je     1f7cc17 <node_facts_window_run+0x6c7>
 1f7c948:	mov    $0x1a,%r14d
 1f7c94e:	mov    $0xcc,%ebp
 1f7c953:	mov    $0x102,%r12d
 1f7c959:	mov    $0x8c,%r13d
 1f7c95f:	xor    %ebx,%ebx
 1f7c961:	jmp    1f7c985 <node_facts_window_run+0x435>
 1f7c963:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7c970:	inc    %rbx
 1f7c973:	add    $0x40,%r14
 1f7c977:	cmp    %rbx,0x90(%rsp)
 1f7c97f:	je     1f7cb50 <node_facts_window_run+0x600>
 1f7c985:	mov    0x1f8(%rdi),%rax
 1f7c98c:	movzbl (%rax,%rbx,1),%eax
 1f7c990:	cmp    $0x7,%eax
 1f7c993:	ja     1f7c970 <node_facts_window_run+0x420>
 1f7c995:	bt     %eax,%ebp
 1f7c998:	jae    1f7c970 <node_facts_window_run+0x420>
 1f7c99a:	mov    %eax,%ecx
 1f7c99c:	mov    0x2c0(%rdi),%rsi
 1f7c9a3:	and    $0xfe,%cl
 1f7c9a6:	cmp    $0x2,%cl
 1f7c9a9:	sete   %cl
 1f7c9ac:	cmp    $0x7,%eax
 1f7c9af:	sete   %dl
 1f7c9b2:	or     %cl,%dl
 1f7c9b4:	movzbl -0x1(%rsi,%r14,1),%ecx
 1f7c9ba:	movzbl %dl,%edx
 1f7c9bd:	add    %rdx,0x9c8(%r15)
 1f7c9c4:	cmp    $0x7,%eax
 1f7c9c7:	ja     1f7cb03 <node_facts_window_run+0x5b3>
 1f7c9cd:	bt     %eax,%r13d
 1f7c9d1:	mov    $0x0,%edx
 1f7c9d6:	jae    1f7c9e4 <node_facts_window_run+0x494>
 1f7c9d8:	lea    -0x1(%rcx),%esi
 1f7c9db:	xor    %edx,%edx
 1f7c9dd:	cmp    $0x2,%sil
 1f7c9e1:	setb   %dl
 1f7c9e4:	add    %rdx,0x9d0(%r15)
 1f7c9eb:	xor    %edx,%edx
 1f7c9ed:	cmp    $0x7,%eax
 1f7c9f0:	ja     1f7ca06 <node_facts_window_run+0x4b6>
 1f7c9f2:	bt     %eax,%r13d
 1f7c9f6:	jae    1f7ca06 <node_facts_window_run+0x4b6>
 1f7c9f8:	mov    0x1f0(%rdi),%rax
 1f7c9ff:	cmpb   $0x22,(%rax,%rbx,1)
 1f7ca03:	sete   %dl
 1f7ca06:	dec    %cl
 1f7ca08:	vmovd  %edx,%xmm0
 1f7ca0c:	cmp    $0x2,%cl
 1f7ca0f:	setb   %al
 1f7ca12:	and    %dl,%al
 1f7ca14:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f7ca1a:	vpmovzxbq %xmm0,%xmm0
 1f7ca1f:	vptestmq -0x19b0961(%rip){1to2},%xmm0,%k0        # 5cc0c8 <.LCPI3_1>
 1f7ca29:	vmovdqu 0x9e8(%r15),%xmm0
 1f7ca32:	vpmovm2q %k0,%xmm1
 1f7ca38:	vpsubq %xmm1,%xmm0,%xmm0
 1f7ca3c:	vmovdqu %xmm0,0x9e8(%r15)
 1f7ca45:	cmp    $0x1,%al
 1f7ca47:	jne    1f7ca80 <node_facts_window_run+0x530>
 1f7ca49:	mov    0x2c0(%rdi),%rax
 1f7ca50:	movzwl (%rax,%r14,1),%eax
 1f7ca55:	bt     $0x1,%eax
 1f7ca59:	adcq   $0x0,0x9f8(%r15)
 1f7ca61:	mov    0x2c0(%rdi),%rax
 1f7ca68:	movzwl (%rax,%r14,1),%eax
 1f7ca6d:	bextr  %r12d,%eax,%eax
 1f7ca72:	jmp    1f7ca82 <node_facts_window_run+0x532>
 1f7ca74:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7ca80:	xor    %eax,%eax
 1f7ca82:	add    %rax,0xa00(%r15)
 1f7ca89:	xor    %esi,%esi
 1f7ca8b:	mov    %ebx,%edx
 1f7ca8d:	xor    %ecx,%ecx
 1f7ca8f:	call   1f7c0f0 <node_facts_same>
 1f7ca94:	mov    0x8(%rsp),%rdi
 1f7ca99:	test   %al,%al
 1f7ca9b:	jne    1f7c970 <node_facts_window_run+0x420>
 1f7caa1:	incq   0x9d8(%r15)
 1f7caa8:	mov    0x938(%rdi),%rax
 1f7caaf:	mov    0x11b8(%rax),%ecx
 1f7cab5:	cmp    $0xf,%rcx
 1f7cab9:	ja     1f7c970 <node_facts_window_run+0x420>
 1f7cabf:	mov    0x28(%rsp),%rdx
 1f7cac4:	mov    0x422c(%rdx,%rbx,4),%edx
 1f7cacb:	mov    %edx,0x1158(%rax,%rcx,4)
 1f7cad2:	mov    0x1f0(%rdi),%rcx
 1f7cad9:	mov    0x11b8(%rax),%edx
 1f7cadf:	movzbl (%rcx,%rbx,1),%ecx
 1f7cae3:	mov    %cl,0x1198(%rax,%rdx,1)
 1f7caea:	mov    0x11b8(%rax),%ecx
 1f7caf0:	movb   $0x5,0x11a8(%rax,%rcx,1)
 1f7caf8:	incl   0x11b8(%rax)
 1f7cafe:	jmp    1f7c970 <node_facts_window_run+0x420>
 1f7cb03:	xor    %edx,%edx
 1f7cb05:	add    %rdx,0x9d0(%r15)
 1f7cb0c:	xor    %edx,%edx
 1f7cb0e:	cmp    $0x7,%eax
 1f7cb11:	jbe    1f7c9f2 <node_facts_window_run+0x4a2>
 1f7cb17:	jmp    1f7ca06 <node_facts_window_run+0x4b6>
 1f7cb1c:	nopl   0x0(%rax)
 1f7cb20:	movzbl 0x69454(%r13,%rcx,1),%edx
 1f7cb29:	mov    0x9b8(%rdi),%rsi
 1f7cb30:	mov    %dl,(%rsi,%rcx,1)
 1f7cb33:	inc    %rcx
 1f7cb36:	dec    %rax
 1f7cb39:	je     1f7c737 <node_facts_window_run+0x1e7>
 1f7cb3f:	mov    0x9b0(%rdi),%rdx
 1f7cb46:	cmpb   $0x0,(%rdx,%rcx,1)
 1f7cb4a:	jne    1f7cb20 <node_facts_window_run+0x5d0>
 1f7cb4c:	xor    %edx,%edx
 1f7cb4e:	jmp    1f7cb29 <node_facts_window_run+0x5d9>
 1f7cb50:	mov    $0x3,%edx
 1f7cb55:	xor    %esi,%esi
 1f7cb57:	xor    %ebx,%ebx
 1f7cb59:	call   1f7ac80 <node_facts_given>
 1f7cb5e:	mov    0x8(%rsp),%rdi
 1f7cb63:	xor    %esi,%esi
 1f7cb65:	xor    %edx,%edx
 1f7cb67:	xor    %ecx,%ecx
 1f7cb69:	call   1f7ae80 <node_facts_window>
 1f7cb6e:	mov    0x8(%rsp),%rdi
 1f7cb73:	mov    0x90(%rsp),%r12
 1f7cb7b:	mov    0x28(%rsp),%r13
 1f7cb80:	jmp    1f7cb9c <node_facts_window_run+0x64c>
 1f7cb82:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f7cb90:	inc    %rbx
 1f7cb93:	cmp    %rbx,%r12
 1f7cb96:	je     1f7cc38 <node_facts_window_run+0x6e8>
 1f7cb9c:	mov    0x1f8(%rdi),%rax
 1f7cba3:	testb  $0x2,(%rax,%rbx,1)
 1f7cba7:	je     1f7cb90 <node_facts_window_run+0x640>
 1f7cba9:	xor    %esi,%esi
 1f7cbab:	mov    %ebx,%edx
 1f7cbad:	xor    %ecx,%ecx
 1f7cbaf:	call   1f7c0f0 <node_facts_same>
 1f7cbb4:	mov    0x8(%rsp),%rdi
 1f7cbb9:	test   %al,%al
 1f7cbbb:	jne    1f7cb90 <node_facts_window_run+0x640>
 1f7cbbd:	incq   0x9d8(%r15)
 1f7cbc4:	mov    0x938(%rdi),%rax
 1f7cbcb:	mov    0x11b8(%rax),%ecx
 1f7cbd1:	cmp    $0xf,%rcx
 1f7cbd5:	ja     1f7cb90 <node_facts_window_run+0x640>
 1f7cbd7:	mov    0x422c(%r13,%rbx,4),%edx
 1f7cbdf:	mov    %edx,0x1158(%rax,%rcx,4)
 1f7cbe6:	mov    0x1f0(%rdi),%rcx
 1f7cbed:	mov    0x11b8(%rax),%edx
 1f7cbf3:	movzbl (%rcx,%rbx,1),%ecx
 1f7cbf7:	mov    %cl,0x1198(%rax,%rdx,1)
 1f7cbfe:	mov    0x11b8(%rax),%ecx
 1f7cc04:	movb   $0x1,0x11a8(%rax,%rcx,1)
 1f7cc0c:	incl   0x11b8(%rax)
 1f7cc12:	jmp    1f7cb90 <node_facts_window_run+0x640>
 1f7cc17:	mov    $0x3,%edx
 1f7cc1c:	xor    %esi,%esi
 1f7cc1e:	call   1f7ac80 <node_facts_given>
 1f7cc23:	mov    0x8(%rsp),%rdi
 1f7cc28:	xor    %esi,%esi
 1f7cc2a:	xor    %edx,%edx
 1f7cc2c:	xor    %ecx,%ecx
 1f7cc2e:	call   1f7ae80 <node_facts_window>
 1f7cc33:	mov    0x8(%rsp),%rdi
 1f7cc38:	xor    %esi,%esi
 1f7cc3a:	xor    %edx,%edx
 1f7cc3c:	call   1f7ac80 <node_facts_given>
 1f7cc41:	mov    0x8(%rsp),%rax
 1f7cc46:	xor    %esi,%esi
 1f7cc48:	xor    %ecx,%ecx
 1f7cc4a:	mov    0xd0(%rax),%r14
 1f7cc51:	rdtsc
 1f7cc53:	mov    0x8(%rsp),%rdi
 1f7cc58:	mov    %rdx,%rbx
 1f7cc5b:	shl    $0x20,%rbx
 1f7cc5f:	xor    %edx,%edx
 1f7cc61:	or     %rax,%rbx
 1f7cc64:	call   1f7ae80 <node_facts_window>
 1f7cc69:	mov    0x8(%rsp),%r11
 1f7cc6e:	rdtsc
 1f7cc70:	shl    $0x20,%rdx
 1f7cc74:	or     %rax,%rdx
 1f7cc77:	sub    %rbx,%rdx
 1f7cc7a:	add    %rdx,0x9e0(%r15)
 1f7cc81:	mov    0xd0(%r11),%rax
 1f7cc88:	sub    %r14,%rax
 1f7cc8b:	add    %rax,0xa10(%r15)
 1f7cc92:	mov    0x948(%r11),%rdi
 1f7cc99:	test   %rdi,%rdi
 1f7cc9c:	je     1f83b35 <node_facts_window_run+0x75e5>
 1f7cca2:	mov    0xc58(%rdi),%rax
 1f7cca9:	mov    0x940(%r11),%rdx
 1f7ccb0:	mov    (%r11),%r8
 1f7ccb3:	movzbl 0xc80(%rdi),%ecx
 1f7ccba:	mov    0xbc0(%rdi),%rsi
 1f7ccc1:	lea    0x757d4(%r13),%rbx
 1f7ccc8:	mov    %rax,0xa8(%rsp)
 1f7ccd0:	mov    0x8(%rdx),%rax
 1f7ccd4:	mov    %r8,0xd0(%rsp)
 1f7ccdc:	mov    %rdx,0xd8(%rsp)
 1f7cce4:	mov    0x78(%rax),%eax
 1f7cce7:	mov    %eax,0xc8(%rsp)
 1f7ccee:	mov    %cl,0x78(%rsp)
 1f7ccf2:	rdtsc
 1f7ccf4:	mov    0x8(%r13),%r8d
 1f7ccf8:	mov    0x2c0(%r11),%r9
 1f7ccff:	mov    %rsi,0x40(%rsp)
 1f7cd04:	mov    %rdi,0x18(%rsp)
 1f7cd09:	mov    %rbx,0x48(%rsp)
 1f7cd0e:	lea    0x3f(%r8),%ecx
 1f7cd12:	mov    %r8,0x120(%rsp)
 1f7cd1a:	mov    %r9,0x20(%rsp)
 1f7cd1f:	and    $0xffffffc0,%ecx
 1f7cd22:	cmpq   $0x0,0xc18(%r11)
 1f7cd2a:	mov    %rax,0x108(%rsp)
 1f7cd32:	mov    %rdx,0x100(%rsp)
 1f7cd3a:	je     1f7d9c4 <node_facts_window_run+0x1474>
 1f7cd40:	cmpb   $0x1,0xd50(%r11)
 1f7cd48:	jne    1f7e3b8 <node_facts_window_run+0x1e68>
 1f7cd4e:	test   %ecx,%ecx
 1f7cd50:	je     1f7f816 <node_facts_window_run+0x32c6>
 1f7cd56:	vpbroadcastd -0x19ae270(%rip),%zmm14        # 5ceaf0 <.LCPI3_5>
 1f7cd60:	vpbroadcastb -0x1ac60a9(%rip),%xmm15        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f7cd69:	vpbroadcastb -0x1ac60b2(%rip),%xmm16        # 4b6cc1 <abi_test_hex.digits+0xb941>
 1f7cd73:	vpbroadcastd -0x19ae285(%rip),%zmm17        # 5ceaf8 <.LCPI3_11>
 1f7cd7d:	vpbroadcastd -0x19ae287(%rip),%zmm18        # 5ceb00 <.LCPI3_13>
 1f7cd87:	mov    (%r11),%rax
 1f7cd8a:	lea    0x69454(%r13),%r10
 1f7cd91:	lea    0x422c(%r13),%rdx
 1f7cd98:	mov    %ecx,%r12d
 1f7cd9b:	xor    %ebp,%ebp
 1f7cd9d:	mov    %rax,0x98(%rsp)
 1f7cda5:	mov    %r10,0xc0(%rsp)
 1f7cdad:	mov    %rdx,0xa0(%rsp)
 1f7cdb5:	movq   $0x0,0x50(%rsp)
 1f7cdbe:	movq   $0x0,0x38(%rsp)
 1f7cdc7:	movq   $0x0,0x10(%rsp)
 1f7cdd0:	mov    %r12,0xb8(%rsp)
 1f7cdd8:	jmp    1f7cea6 <node_facts_window_run+0x956>
 1f7cddd:	nopl   (%rax)
 1f7cde0:	vpxor  %xmm1,%xmm1,%xmm1
 1f7cde4:	vpxor  %xmm0,%xmm0,%xmm0
 1f7cde8:	vpxor  %xmm5,%xmm5,%xmm5
 1f7cdec:	vpxor  %xmm4,%xmm4,%xmm4
 1f7cdf0:	vpxor  %xmm3,%xmm3,%xmm3
 1f7cdf4:	vpxor  %xmm7,%xmm7,%xmm7
 1f7cdf8:	vpxor  %xmm8,%xmm8,%xmm8
 1f7cdfd:	vpxor  %xmm9,%xmm9,%xmm9
 1f7ce02:	vpxor  %xmm2,%xmm2,%xmm2
 1f7ce06:	vpxord %xmm20,%xmm20,%xmm20
 1f7ce0c:	mov    0xc00(%rdi),%rax
 1f7ce13:	vmovdqu64 %xmm20,(%rax,%rbp,1)
 1f7ce1a:	mov    0xc08(%rdi),%rax
 1f7ce21:	vmovdqu %xmm2,(%rax,%rbp,1)
 1f7ce26:	mov    0xb80(%r11),%rax
 1f7ce2d:	vmovdqu %xmm9,(%rax,%rbp,1)
 1f7ce32:	mov    0xb88(%r11),%rax
 1f7ce39:	vmovdqu %xmm8,(%rax,%rbp,1)
 1f7ce3e:	mov    0xb90(%r11),%rax
 1f7ce45:	vmovdqu %xmm7,(%rax,%rbp,1)
 1f7ce4a:	mov    0xb98(%r11),%rax
 1f7ce51:	vmovdqu %xmm3,(%rax,%rbp,1)
 1f7ce56:	mov    0xba0(%r11),%rax
 1f7ce5d:	vmovdqu %xmm4,(%rax,%rbp,1)
 1f7ce62:	mov    0xc20(%r11),%rax
 1f7ce69:	vmovdqu64 %zmm5,(%rax,%rbp,4)
 1f7ce70:	mov    0xcd0(%r11),%rax
 1f7ce77:	vmovdqu64 %zmm0,(%rax,%rbp,8)
 1f7ce7e:	mov    0xcd0(%r11),%rax
 1f7ce85:	vmovdqu64 %zmm1,0x40(%rax,%rbp,8)
 1f7ce8d:	mov    0xd58(%r11),%rax
 1f7ce94:	vmovdqu %xmm6,(%rax,%rbp,1)
 1f7ce99:	add    $0x10,%rbp
 1f7ce9d:	cmp    %r12,%rbp
 1f7cea0:	jae    1f7f831 <node_facts_window_run+0x32e1>
 1f7cea6:	vpxor  %xmm6,%xmm6,%xmm6
 1f7ceaa:	cmp    %r8,%rbp
 1f7cead:	jae    1f7cde0 <node_facts_window_run+0x890>
 1f7ceb3:	mov    %r8d,%eax
 1f7ceb6:	sub    %ebp,%eax
 1f7ceb8:	mov    $0x10,%ecx
 1f7cebd:	mov    $0xffffffff,%edx
 1f7cec2:	vpxor  %xmm12,%xmm12,%xmm12
 1f7cec7:	cmp    $0x10,%eax
 1f7ceca:	cmovae %ecx,%eax
 1f7cecd:	mov    0x9b0(%r11),%rcx
 1f7ced4:	shlx   %eax,%edx,%eax
 1f7ced9:	mov    %rbp,%rdx
 1f7cedc:	shl    $0x6,%rdx
 1f7cee0:	not    %eax
 1f7cee2:	vmovdqu (%r9,%rdx,1),%ymm4
 1f7cee8:	vmovdqu64 0x40(%r9,%rdx,1),%ymm26
 1f7cef0:	vmovdqu64 0x80(%r9,%rdx,1),%ymm27
 1f7cef8:	vmovdqu64 0xc0(%r9,%rdx,1),%ymm28
 1f7cf00:	vmovdqu 0x100(%r9,%rdx,1),%ymm5
 1f7cf0a:	vmovdqu 0x140(%r9,%rdx,1),%ymm6
 1f7cf14:	vmovdqu64 0x180(%r9,%rdx,1),%ymm24
 1f7cf1c:	vmovdqu64 0x1c0(%r9,%rdx,1),%ymm25
 1f7cf24:	vmovdqu 0x200(%r9,%rdx,1),%ymm7
 1f7cf2e:	vmovdqu 0x240(%r9,%rdx,1),%ymm13
 1f7cf38:	vmovdqu64 0x280(%r9,%rdx,1),%ymm22
 1f7cf40:	vmovdqu64 0x2c0(%r9,%rdx,1),%ymm23
 1f7cf48:	vmovdqu 0x300(%r9,%rdx,1),%ymm11
 1f7cf52:	vmovdqu64 0x340(%r9,%rdx,1),%ymm19
 1f7cf5a:	vmovdqu64 0x380(%r9,%rdx,1),%ymm20
 1f7cf62:	vmovdqu64 0x3c0(%r9,%rdx,1),%ymm21
 1f7cf6a:	kmovd  %eax,%k1
 1f7cf6e:	mov    0xc38(%rdi),%rax
 1f7cf75:	vmovdqu8 (%rcx,%rbp,1),%xmm0{%k1}{z}
 1f7cf7c:	mov    0xc0(%rsp),%rcx
 1f7cf84:	vmovdqu8 (%rcx,%rbp,1),%xmm10{%k1}{z}
 1f7cf8b:	vptestmb %xmm0,%xmm0,%k6
 1f7cf91:	vpcmpeqb -0x19b76db(%rip),%xmm10,%k7{%k6}        # 5c58c0 <.LCPI3_10>
 1f7cf9b:	vmovdqu32 (%rbx,%rbp,4),%zmm0{%k7}{z}
 1f7cfa2:	kmovq  %k7,%k1
 1f7cfa7:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7cfae:	vptestnmd %zmm17,%zmm12,%k0
 1f7cfb4:	ktestw %k0,%k7
 1f7cfb8:	jne    1f7d6d0 <node_facts_window_run+0x1180>
 1f7cfbe:	vpmovsxbd -0x19ae493(%rip),%xmm3        # 5ceb34 <.LCPI3_71>
 1f7cfc7:	vmovdqa64 -0x1ac6851(%rip),%zmm8        # 4b6780 <abi_test_hex.digits+0xb400>
 1f7cfd1:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7cfd8:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7cfdf:	vptestmd -0x19ae4ed(%rip){1to16},%zmm12,%k0        # 5ceafc <.LCPI3_12>
 1f7cfe9:	vmovdqa64 %zmm0,%zmm2
 1f7cfef:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7cff5:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7cffb:	vmovdqa64 %zmm3,%zmm9
 1f7d001:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7d007:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7d00d:	kmovd  %k0,%r14d
 1f7d011:	vptestmd %zmm18,%zmm12,%k0
 1f7d017:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7d01d:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7d024:	vmovdqu64 %zmm1,0x1c0(%rsp)
 1f7d02c:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7d033:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7d037:	vmovdqa64 %zmm1,%zmm4
 1f7d03d:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7d043:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7d049:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7d04f:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7d055:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7d05c:	vmovdqu %ymm3,0x180(%rsp)
 1f7d065:	vinserti64x4 $0x1,%ymm13,%zmm7,%zmm3
 1f7d06c:	vpunpcklqdq %ymm13,%ymm7,%ymm7
 1f7d071:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm13
 1f7d078:	vmovdqa64 %zmm3,%zmm6
 1f7d07e:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7d084:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7d08a:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7d090:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7d096:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7d09c:	vmovdqa64 %zmm13,%zmm7
 1f7d0a2:	vmovdqu64 %zmm5,0x200(%rsp)
 1f7d0aa:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7d0b1:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7d0b7:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7d0be:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7d0c5:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7d0cb:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7d0d2:	vpermt2d %zmm5,%zmm9,%zmm13
 1f7d0d8:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7d0de:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7d0e4:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7d0eb:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7d0f2:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7d0f9:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7d100:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm21{%k6}{z}
 1f7d107:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7d10e:	vpsrld $0x19,%zmm19,%zmm0
 1f7d115:	vpandd -0x19ae633(%rip){1to16},%zmm0,%zmm0        # 5ceaec <.LCPI3_4>
 1f7d11f:	vpsrld $0x18,%zmm19,%zmm1
 1f7d126:	vpsrld $0x1a,%zmm19,%zmm7
 1f7d12d:	vpternlogd $0xec,%zmm14,%zmm0,%zmm1
 1f7d134:	vpandd -0x19ae606(%rip){1to16},%zmm19,%zmm0        # 5ceb38 <.LCPI3_72>
 1f7d13e:	vpmovdb %zmm1,%xmm20
 1f7d144:	vpsrld $0xc,%zmm21,%zmm1
 1f7d14b:	vpmovdb %zmm1,%xmm24
 1f7d151:	vpcmpeqd -0x19ae667(%rip){1to16},%zmm0,%k1{%k6}        # 5ceaf4 <.LCPI3_7>
 1f7d15b:	vporq  %xmm15,%xmm20,%xmm0
 1f7d161:	vmovdqu8 %xmm0,%xmm20{%k1}
 1f7d167:	vpcmpeqb %xmm15,%xmm10,%k1{%k6}
 1f7d16d:	vpternlogq $0xf8,%xmm16,%xmm24,%xmm20
 1f7d174:	kmovd  %k1,%eax
 1f7d178:	kmovw  %k1,0x60(%rsp)
 1f7d17e:	korw   %k0,%k1,%k1
 1f7d182:	kmovw  %k1,0x30(%rsp)
 1f7d188:	test   %ax,%ax
 1f7d18b:	je     1f7d33e <node_facts_window_run+0xdee>
 1f7d191:	vmovdqu64 %zmm4,0x650(%rsp)
 1f7d19c:	vmovdqu %ymm5,0x5a0(%rsp)
 1f7d1a5:	vmovdqu64 %zmm7,0x5e0(%rsp)
 1f7d1b0:	vmovdqa64 %xmm24,0x4e0(%rsp)
 1f7d1b8:	vmovdqu64 %zmm23,0x520(%rsp)
 1f7d1c3:	vmovdqu64 %zmm22,0x560(%rsp)
 1f7d1ce:	vmovdqu64 %zmm19,0x480(%rsp)
 1f7d1d6:	vmovdqu64 %zmm13,0x400(%rsp)
 1f7d1de:	vmovdqu64 %zmm21,0x280(%rsp)
 1f7d1e6:	vmovdqu64 %zmm12,0x2c0(%rsp)
 1f7d1ee:	vmovdqa64 %xmm20,0x300(%rsp)
 1f7d1f6:	kmovw  %k7,0x380(%rsp)
 1f7d1ff:	mov    %rdx,0x340(%rsp)
 1f7d207:	kmovd  %k6,0x3c0(%rsp)
 1f7d211:	movzwl %ax,%r13d
 1f7d215:	movzwl %r14w,%r14d
 1f7d219:	xor    %r15d,%r15d
 1f7d21c:	mov    0xa0(%rsp),%rax
 1f7d224:	lea    (%rax,%rbp,4),%r12
 1f7d228:	nopl   0x0(%rax,%rax,1)
 1f7d230:	xor    %ebx,%ebx
 1f7d232:	tzcnt  %r13d,%ebx
 1f7d237:	xor    %edx,%edx
 1f7d239:	mov    (%r12,%rbx,4),%esi
 1f7d23d:	vzeroupper
 1f7d240:	call   1f92730 <node_tests_window_line>
 1f7d245:	mov    0x18(%rsp),%rdi
 1f7d24a:	mov    $0x1,%ecx
 1f7d24f:	test   $0x2,%al
 1f7d251:	shlx   %ebx,%ecx,%eax
 1f7d256:	cmove  %r15d,%eax
 1f7d25a:	or     %eax,%r14d
 1f7d25d:	blsr   %r13d,%r13d
 1f7d262:	jne    1f7d230 <node_facts_window_run+0xce0>
 1f7d264:	vpbroadcastd -0x19ae77e(%rip),%zmm14        # 5ceaf0 <.LCPI3_5>
 1f7d26e:	vpbroadcastb -0x1ac65b7(%rip),%xmm15        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f7d277:	vpbroadcastb -0x1ac65c0(%rip),%xmm16        # 4b6cc1 <abi_test_hex.digits+0xb941>
 1f7d281:	vpbroadcastd -0x19ae793(%rip),%zmm17        # 5ceaf8 <.LCPI3_11>
 1f7d28b:	vpbroadcastd -0x19ae795(%rip),%zmm18        # 5ceb00 <.LCPI3_13>
 1f7d295:	vmovdqa64 0x300(%rsp),%xmm20
 1f7d29d:	vmovdqu64 0x2c0(%rsp),%zmm12
 1f7d2a5:	vmovdqu64 0x280(%rsp),%zmm21
 1f7d2ad:	vmovdqu64 0x400(%rsp),%zmm13
 1f7d2b5:	vmovdqu64 0x480(%rsp),%zmm19
 1f7d2bd:	vmovdqu64 0x560(%rsp),%zmm22
 1f7d2c8:	vmovdqu64 0x520(%rsp),%zmm23
 1f7d2d3:	vmovdqa64 0x4e0(%rsp),%xmm24
 1f7d2db:	vmovdqu64 0x5e0(%rsp),%zmm7
 1f7d2e6:	vmovdqu 0x5a0(%rsp),%ymm5
 1f7d2ef:	vmovdqu64 0x650(%rsp),%zmm4
 1f7d2fa:	mov    0x8(%rsp),%r11
 1f7d2ff:	mov    0x28(%rsp),%r13
 1f7d304:	mov    0x40(%rsp),%rsi
 1f7d309:	mov    0x48(%rsp),%rbx
 1f7d30e:	mov    0x120(%rsp),%r8
 1f7d316:	mov    0x20(%rsp),%r9
 1f7d31b:	mov    0xb8(%rsp),%r12
 1f7d323:	kmovd  0x3c0(%rsp),%k6
 1f7d32d:	mov    0x340(%rsp),%rdx
 1f7d335:	kmovw  0x380(%rsp),%k7
 1f7d33e:	vpsrld $0x2,%zmm21,%zmm0
 1f7d345:	vpandd -0x19ae84b(%rip){1to16},%zmm0,%zmm2        # 5ceb04 <.LCPI3_14>
 1f7d34f:	vpbroadcastd -0x19ae851(%rip),%zmm0        # 5ceb08 <.LCPI3_15>
 1f7d359:	vptestmd -0x19ae857(%rip){1to16},%zmm21,%k3        # 5ceb0c <.LCPI3_16>
 1f7d363:	vmovdqu64 0x200(%rsp),%zmm1
 1f7d36b:	vptestnmd %zmm4,%zmm4,%k1
 1f7d371:	vpbroadcastd -0x19ae863(%rip),%zmm6        # 5ceb18 <.LCPI3_21>
 1f7d37b:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7d382:	kmovd  %r14d,%k4
 1f7d387:	vpsrld $0x10,%zmm21,%zmm10
 1f7d38e:	vpbroadcastb -0x1ac66d5(%rip),%xmm8        # 4b6cc2 <abi_test_hex.digits+0xb942>
 1f7d397:	vpbroadcastb -0x1ac66dd(%rip),%xmm9        # 4b6cc3 <abi_test_hex.digits+0xb943>
 1f7d3a0:	kmovw  %k1,%eax
 1f7d3a4:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7d3aa:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7d3b1:	vmovdqu64 0x1c0(%rsp),%zmm0
 1f7d3b9:	korw   %k1,%k3,%k3
 1f7d3bd:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7d3c4:	vpandd -0x19ae892(%rip){1to16},%zmm19,%zmm5        # 5ceb3c <.LCPI3_75>
 1f7d3ce:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7d3d4:	vpbroadcastb -0x1ac6719(%rip),%xmm7        # 4b6cc4 <abi_test_hex.digits+0xb944>
 1f7d3dd:	vinserti64x4 $0x1,0x180(%rsp),%zmm0,%zmm0
 1f7d3e6:	kmovw  %k0,%ecx
 1f7d3ea:	korw   %k2,%k3,%k2
 1f7d3ee:	vpaddd -0x19ae8e4(%rip){1to16},%zmm5,%zmm5        # 5ceb14 <.LCPI3_20>
 1f7d3f8:	andn   %ecx,%eax,%eax
 1f7d3fd:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7d403:	kmovd  %eax,%k3
 1f7d407:	shr    $0x8,%eax
 1f7d40a:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7d410:	kmovd  %eax,%k3
 1f7d414:	vmovdqu8 %xmm15,%xmm4{%k2}{z}
 1f7d41a:	vpcmpltud %zmm6,%zmm5,%k2
 1f7d421:	vpslld $0x1f,%zmm5,%zmm5
 1f7d428:	vpxor  %xmm6,%xmm6,%xmm6
 1f7d42c:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7d432:	vptestmd -0x19ae92c(%rip){1to16},%zmm23,%k3        # 5ceb10 <.LCPI3_17>
 1f7d43c:	vpandd %zmm18,%zmm23,%zmm3
 1f7d442:	vptestnmd %zmm3,%zmm3,%k0
 1f7d448:	kandd  %k6,%k0,%k0
 1f7d44d:	korw   %k3,%k4,%k3
 1f7d451:	kandd  %k2,%k0,%k4
 1f7d456:	vpcmpeqd %zmm17,%zmm2,%k2{%k4}
 1f7d45c:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7d462:	vmovdqu8 -0x19b7b7c(%rip),%xmm2{%k4}        # 5c58f0 <.LCPI3_25>
 1f7d46c:	knotw  %k2,%k0
 1f7d470:	kandd  %k0,%k4,%k5
 1f7d475:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7d47b:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7d482:	vpaddd %zmm5,%zmm10,%zmm11
 1f7d488:	vpbroadcastb -0x1ac67cc(%rip),%xmm5        # 4b6cc5 <abi_test_hex.digits+0xb945>
 1f7d491:	vmovdqu8 -0x19b7b9b(%rip),%xmm2{%k4}        # 5c5900 <.LCPI3_26>
 1f7d49b:	vptestnmd %zmm11,%zmm11,%k4
 1f7d4a1:	vpblendmb -0x19b7b8b(%rip),%xmm5,%xmm5{%k4}        # 5c5920 <.LCPI3_28>
 1f7d4ab:	vpcmpnleud -0x19ae99a(%rip){1to16},%zmm11,%k4        # 5ceb1c <.LCPI3_22>
 1f7d4b6:	cmpb   $0x0,0xc80(%rdi)
 1f7d4bd:	vmovdqu8 -0x19b7b97(%rip),%xmm5{%k4}        # 5c5930 <.LCPI3_29>
 1f7d4c7:	vpcmpnleud -0x19ae9b2(%rip){1to16},%zmm11,%k4        # 5ceb20 <.LCPI3_23>
 1f7d4d2:	vmovdqu8 -0x19b7b9c(%rip),%xmm5{%k4}        # 5c5940 <.LCPI3_30>
 1f7d4dc:	vptestmd %zmm3,%zmm3,%k4
 1f7d4e2:	vpor   %xmm4,%xmm8,%xmm3
 1f7d4e6:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7d4ec:	kmovw  0x30(%rsp),%k4
 1f7d4f2:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7d4f8:	vpor   %xmm2,%xmm4,%xmm2
 1f7d4fc:	vpord  -0x19ae9c6(%rip){1to4},%xmm2,%xmm3        # 5ceb40 <.LCPI3_78>
 1f7d506:	vpbroadcastb -0x1ac6849(%rip),%xmm5        # 4b6cc6 <abi_test_hex.digits+0xb946>
 1f7d50f:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7d515:	vpor   %xmm5,%xmm2,%xmm3
 1f7d519:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7d51f:	vpmovdb %zmm21,%xmm3
 1f7d525:	kmovw  0x60(%rsp),%k3
 1f7d52b:	vpor   %xmm3,%xmm9,%xmm4
 1f7d52f:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7d535:	vptestmd -0x19aea1b(%rip){1to16},%zmm12,%k3{%k7}        # 5ceb24 <.LCPI3_32>
 1f7d53f:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7d545:	vpor   %xmm5,%xmm4,%xmm6
 1f7d549:	vpsrld $0xb,%zmm23,%zmm7
 1f7d550:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7d556:	vpandd -0x19aea1c(%rip){1to4},%xmm24,%xmm4        # 5ceb44 <.LCPI3_80>
 1f7d560:	vptestmd -0x19aea42(%rip){1to16},%zmm23,%k1        # 5ceb28 <.LCPI3_33>
 1f7d56a:	vpmovdb %zmm7,%xmm7
 1f7d570:	vpand  %xmm7,%xmm8,%xmm7
 1f7d574:	vporq  %xmm16,%xmm4,%xmm5
 1f7d57a:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7d580:	vpmovdb %zmm23,%xmm5
 1f7d586:	vgf2p8affineqb $0x0,-0x19b1479(%rip){1to2},%xmm5,%xmm5        # 5cc118 <.LCPI3_81>
 1f7d591:	vpternlogq $0xf8,%xmm9,%xmm5,%xmm4
 1f7d598:	vpmovdb %zmm19,%xmm9
 1f7d59e:	vpor   %xmm4,%xmm15,%xmm5
 1f7d5a2:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7d5a8:	vinserti32x4 $0x3,%xmm13,%zmm22,%zmm5{%k6}{z}
 1f7d5af:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7d5b6:	vpsrld $0x8,%zmm19,%zmm13
 1f7d5bd:	vpsrld $0x10,%zmm19,%zmm6
 1f7d5c4:	vpmovdb %zmm6,%xmm7
 1f7d5ca:	vpmovdb %zmm13,%xmm8
 1f7d5d0:	vpmovdb %zmm12,%xmm6
 1f7d5d6:	je     1f7ce0c <node_facts_window_run+0x8bc>
 1f7d5dc:	vmovdqa64 -0x1ac6da6(%rip),%zmm19        # 4b6840 <abi_test_hex.digits+0xb4c0>
 1f7d5e6:	vptestmd %zmm10,%zmm10,%k1{%k2}
 1f7d5ec:	add    %r9,%rdx
 1f7d5ef:	vpxor  %xmm12,%xmm12,%xmm12
 1f7d5f4:	vpxor  %xmm13,%xmm13,%xmm13
 1f7d5f9:	vpcmpneqd -0x19aead8(%rip){1to16},%zmm10,%k0{%k1}        # 5ceb2c <.LCPI3_38>
 1f7d604:	vmovdqa %xmm7,%xmm10
 1f7d608:	vpternlogq $0xfe,%xmm9,%xmm3,%xmm10
 1f7d60f:	kmovq  %k1,%k2
 1f7d614:	kmovw  %k1,%eax
 1f7d618:	popcnt %eax,%ecx
 1f7d61c:	vpgatherdd 0x10(%rdx,%zmm19,1),%zmm12{%k2}
 1f7d624:	kmovq  %k1,%k2
 1f7d629:	vpcmpnleud -0x19aeb04(%rip){1to16},%zmm12,%k3        # 5ceb30 <.LCPI3_39>
 1f7d634:	vpgatherdd 0x14(%rdx,%zmm19,1),%zmm13{%k2}
 1f7d63c:	add    %rcx,0x38(%rsp)
 1f7d641:	mov    0x10(%rsp),%r10
 1f7d646:	vpcmpeqd %zmm11,%zmm12,%k2
 1f7d64c:	vmovdqa64 %xmm20,%xmm11
 1f7d652:	vpternlogq $0xfe,%xmm8,%xmm10,%xmm11
 1f7d659:	vptestnmd %zmm13,%zmm13,%k2{%k2}
 1f7d65f:	vptestmd %zmm13,%zmm13,%k4
 1f7d665:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm11
 1f7d66c:	korw   %k4,%k3,%k3
 1f7d670:	kandw  %k2,%k0,%k2
 1f7d674:	knotw  %k0,%k0
 1f7d678:	kandd  %k1,%k0,%k0
 1f7d67d:	kandw  %k0,%k3,%k0
 1f7d681:	korw   %k0,%k2,%k2
 1f7d685:	vptestnmd %zmm14,%zmm21,%k0{%k2}
 1f7d68b:	kandw  %k0,%k1,%k0
 1f7d68f:	knotd  %k6,%k1
 1f7d694:	kmovd  %k0,%ecx
 1f7d698:	vptestmb %xmm11,%xmm11,%k0{%k1}
 1f7d69e:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7d6a4:	andn   %eax,%ecx,%eax
 1f7d6a9:	popcnt %eax,%eax
 1f7d6ad:	kmovw  %k0,%ecx
 1f7d6b1:	popcnt %ecx,%ecx
 1f7d6b5:	kmovw  %k1,%edx
 1f7d6b9:	popcnt %edx,%edx
 1f7d6bd:	add    %rdx,%r10
 1f7d6c0:	add    %rax,%r10
 1f7d6c3:	add    %rcx,%r10
 1f7d6c6:	mov    %r10,0x10(%rsp)
 1f7d6cb:	jmp    1f7ce0c <node_facts_window_run+0x8bc>
 1f7d6d0:	kandw  %k0,%k7,%k0
 1f7d6d4:	mov    %rdx,0x340(%rsp)
 1f7d6dc:	vmovdqa %xmm10,0x180(%rsp)
 1f7d6e5:	vmovdqu64 %zmm11,0x200(%rsp)
 1f7d6ed:	vmovdqu64 %ymm19,0x300(%rsp)
 1f7d6f5:	vmovdqu64 %zmm20,0x2c0(%rsp)
 1f7d6fd:	vmovdqu64 %ymm21,0x280(%rsp)
 1f7d705:	vmovdqu64 %zmm7,0x400(%rsp)
 1f7d70d:	vmovdqu %ymm13,0x480(%rsp)
 1f7d716:	vmovdqu64 %zmm22,0x560(%rsp)
 1f7d721:	vmovdqu64 %ymm23,0x520(%rsp)
 1f7d729:	vmovdqu64 %zmm5,0x4e0(%rsp)
 1f7d734:	vmovdqu %ymm6,0x5e0(%rsp)
 1f7d73d:	vmovdqu64 %zmm24,0x5a0(%rsp)
 1f7d748:	vmovdqu64 %ymm25,0x650(%rsp)
 1f7d753:	vmovdqu64 %zmm4,0x710(%rsp)
 1f7d75e:	vmovdqu64 %ymm26,0x460(%rsp)
 1f7d766:	vmovdqu64 %zmm27,0x6d0(%rsp)
 1f7d771:	vmovdqu64 %ymm28,0x440(%rsp)
 1f7d779:	vmovdqu64 %zmm0,0x7b0(%rsp)
 1f7d784:	kmovd  %k6,0x3c0(%rsp)
 1f7d78e:	kmovw  %k7,0x380(%rsp)
 1f7d797:	kmovd  %k0,%eax
 1f7d79b:	movzwl %ax,%r14d
 1f7d79f:	jmp    1f7d92e <node_facts_window_run+0x13de>
 1f7d7a4:	mov    0x50(%rsp),%rsi
 1f7d7a9:	mov    (%rbx,%r13,4),%r9d
 1f7d7ad:	mov    0xc38(%rdi),%rdx
 1f7d7b4:	shl    $0x6,%rax
 1f7d7b8:	mov    %r8b,0x30(%rsp)
 1f7d7bd:	mov    0x20(%r11),%rcx
 1f7d7c1:	cmpb   $0x1,(%rdx,%r9,1)
 1f7d7c6:	mov    %r9,0x60(%rsp)
 1f7d7cb:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7d7d0:	adc    $0x0,%rsi
 1f7d7d4:	and    $0x1,%edx
 1f7d7d7:	mov    %rsi,0x50(%rsp)
 1f7d7dc:	mov    0xa0(%rsp),%r15
 1f7d7e4:	mov    (%r15,%r13,4),%esi
 1f7d7e8:	vzeroupper
 1f7d7eb:	call   1f92730 <node_tests_window_line>
 1f7d7f0:	mov    %al,0x1c0(%rsp)
 1f7d7f7:	mov    (%r15,%r13,4),%esi
 1f7d7fb:	mov    0x18(%rsp),%rdi
 1f7d800:	call   1f92880 <node_tests_window_returns>
 1f7d805:	mov    0x18(%rsp),%rdi
 1f7d80a:	vpbroadcastd -0x19aed24(%rip),%zmm14        # 5ceaf0 <.LCPI3_5>
 1f7d814:	vpbroadcastb -0x1ac6b5d(%rip),%xmm15        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f7d81d:	vpbroadcastb -0x1ac6b66(%rip),%xmm16        # 4b6cc1 <abi_test_hex.digits+0xb941>
 1f7d827:	vpbroadcastd -0x19aed39(%rip),%zmm17        # 5ceaf8 <.LCPI3_11>
 1f7d831:	vpbroadcastd -0x19aed3b(%rip),%zmm18        # 5ceb00 <.LCPI3_13>
 1f7d83b:	vmovdqa 0x180(%rsp),%xmm10
 1f7d844:	vmovdqu64 0x200(%rsp),%zmm11
 1f7d84c:	vmovdqu64 0x300(%rsp),%ymm19
 1f7d854:	vmovdqu64 0x2c0(%rsp),%zmm20
 1f7d85c:	vmovdqu64 0x280(%rsp),%ymm21
 1f7d864:	vmovdqu64 0x400(%rsp),%zmm7
 1f7d86c:	vmovdqu 0x480(%rsp),%ymm13
 1f7d875:	vmovdqu64 0x560(%rsp),%zmm22
 1f7d880:	vmovdqu64 0x520(%rsp),%ymm23
 1f7d888:	vmovdqu64 0x4e0(%rsp),%zmm5
 1f7d893:	vmovdqu 0x5e0(%rsp),%ymm6
 1f7d89c:	vmovdqu64 0x5a0(%rsp),%zmm24
 1f7d8a7:	vmovdqu64 0x650(%rsp),%ymm25
 1f7d8b2:	vmovdqu64 0x710(%rsp),%zmm4
 1f7d8bd:	vmovdqu64 0x460(%rsp),%ymm26
 1f7d8c5:	vmovdqu64 0x6d0(%rsp),%zmm27
 1f7d8d0:	vmovdqu64 0x440(%rsp),%ymm28
 1f7d8d8:	vmovdqu64 0x7b0(%rsp),%zmm0
 1f7d8e3:	or     0x30(%rsp),%al
 1f7d8e7:	mov    0x8(%rsp),%r11
 1f7d8ec:	mov    0x60(%rsp),%rdx
 1f7d8f1:	mov    0x40(%rsp),%rsi
 1f7d8f6:	mov    0x120(%rsp),%r8
 1f7d8fe:	mov    0x20(%rsp),%r9
 1f7d903:	kmovd  0x3c0(%rsp),%k6
 1f7d90d:	kmovw  0x380(%rsp),%k7
 1f7d916:	or     0x1c0(%rsp),%al
 1f7d91d:	blsr   %r14d,%r14d
 1f7d922:	mov    0xc38(%rdi),%rcx
 1f7d929:	mov    %al,(%rcx,%rdx,1)
 1f7d92c:	je     1f7d99a <node_facts_window_run+0x144a>
 1f7d92e:	tzcnt  %r14d,%r13d
 1f7d933:	mov    0x60(%r11),%edx
 1f7d937:	mov    $0x1,%r8b
 1f7d93a:	add    %rbp,%r13
 1f7d93d:	mov    %r13,%rcx
 1f7d940:	shl    $0x6,%rcx
 1f7d944:	mov    (%r9,%rcx,1),%eax
 1f7d948:	mov    0xc(%r9,%rcx,1),%ecx
 1f7d94d:	shr    $0x3,%eax
 1f7d950:	cmp    %edx,%eax
 1f7d952:	cmovae %edx,%eax
 1f7d955:	test   %rcx,%rcx
 1f7d958:	je     1f7d7a4 <node_facts_window_run+0x1254>
 1f7d95e:	mov    0x98(%rsp),%rdx
 1f7d966:	mov    0x50(%rsp),%rsi
 1f7d96b:	cmp    0x3b8(%rdx),%ecx
 1f7d971:	jae    1f7d7a9 <node_facts_window_run+0x1259>
 1f7d977:	mov    0x98(%rsp),%rdx
 1f7d97f:	mov    0x3a8(%rdx),%rdx
 1f7d986:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7d98a:	setne  %r8b
 1f7d98e:	shl    $0x5,%r8b
 1f7d992:	inc    %r8b
 1f7d995:	jmp    1f7d7a9 <node_facts_window_run+0x1259>
 1f7d99a:	mov    0xc38(%rdi),%rax
 1f7d9a1:	kmovq  %k7,%k1
 1f7d9a6:	vpxor  %xmm12,%xmm12,%xmm12
 1f7d9ab:	mov    0x28(%rsp),%r13
 1f7d9b0:	mov    0x340(%rsp),%rdx
 1f7d9b8:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7d9bf:	jmp    1f7cfbe <node_facts_window_run+0xa6e>
 1f7d9c4:	cmpq   $0x0,0xb38(%r11)
 1f7d9cc:	je     1f7f018 <node_facts_window_run+0x2ac8>
 1f7d9d2:	test   %ecx,%ecx
 1f7d9d4:	je     1f7f816 <node_facts_window_run+0x32c6>
 1f7d9da:	vpbroadcastd -0x19aeef4(%rip),%zmm10        # 5ceaf0 <.LCPI3_5>
 1f7d9e4:	vpbroadcastb -0x1ac6d2d(%rip),%xmm11        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f7d9ed:	vpbroadcastb -0x1ac6d35(%rip),%xmm12        # 4b6cc1 <abi_test_hex.digits+0xb941>
 1f7d9f6:	vpbroadcastd -0x19aef08(%rip),%zmm13        # 5ceaf8 <.LCPI3_11>
 1f7da00:	vpbroadcastd -0x19aef0a(%rip),%zmm14        # 5ceb00 <.LCPI3_13>
 1f7da0a:	mov    (%r11),%rax
 1f7da0d:	lea    0x69454(%r13),%r10
 1f7da14:	lea    0x422c(%r13),%rdx
 1f7da1b:	mov    %ecx,%ebp
 1f7da1d:	xor    %r12d,%r12d
 1f7da20:	mov    %rax,0x5a0(%rsp)
 1f7da28:	mov    %r10,0x520(%rsp)
 1f7da30:	mov    %rdx,0x4e0(%rsp)
 1f7da38:	movq   $0x0,0x50(%rsp)
 1f7da41:	movq   $0x0,0x38(%rsp)
 1f7da4a:	movq   $0x0,0x10(%rsp)
 1f7da53:	mov    %rbp,0x5e0(%rsp)
 1f7da5b:	jmp    1f7dae3 <node_facts_window_run+0x1593>
 1f7da60:	vpxor  %xmm1,%xmm1,%xmm1
 1f7da64:	vpxor  %xmm3,%xmm3,%xmm3
 1f7da68:	vpxor  %xmm4,%xmm4,%xmm4
 1f7da6c:	vpxor  %xmm5,%xmm5,%xmm5
 1f7da70:	vpxor  %xmm0,%xmm0,%xmm0
 1f7da74:	vpxord %xmm16,%xmm16,%xmm16
 1f7da7a:	mov    0xc00(%rdi),%rax
 1f7da81:	vmovdqu64 %xmm16,(%rax,%r12,1)
 1f7da88:	mov    0xc08(%rdi),%rax
 1f7da8f:	vmovdqu %xmm0,(%rax,%r12,1)
 1f7da95:	mov    0xb80(%r11),%rax
 1f7da9c:	vmovdqu %xmm5,(%rax,%r12,1)
 1f7daa2:	mov    0xb88(%r11),%rax
 1f7daa9:	vmovdqu %xmm4,(%rax,%r12,1)
 1f7daaf:	mov    0xb90(%r11),%rax
 1f7dab6:	vmovdqu %xmm3,(%rax,%r12,1)
 1f7dabc:	mov    0xb98(%r11),%rax
 1f7dac3:	vmovdqu %xmm1,(%rax,%r12,1)
 1f7dac9:	mov    0xba0(%r11),%rax
 1f7dad0:	vmovdqu %xmm2,(%rax,%r12,1)
 1f7dad6:	add    $0x10,%r12
 1f7dada:	cmp    %rbp,%r12
 1f7dadd:	jae    1f7f831 <node_facts_window_run+0x32e1>
 1f7dae3:	vpxor  %xmm2,%xmm2,%xmm2
 1f7dae7:	cmp    %r8,%r12
 1f7daea:	jae    1f7da60 <node_facts_window_run+0x1510>
 1f7daf0:	mov    %r8d,%eax
 1f7daf3:	sub    %r12d,%eax
 1f7daf6:	mov    $0x10,%ecx
 1f7dafb:	mov    $0xffffffff,%edx
 1f7db00:	mov    %r12,%r15
 1f7db03:	vpxord %xmm18,%xmm18,%xmm18
 1f7db09:	cmp    $0x10,%eax
 1f7db0c:	cmovae %ecx,%eax
 1f7db0f:	mov    0x9b0(%r11),%rcx
 1f7db16:	shl    $0x6,%r15
 1f7db1a:	shlx   %eax,%edx,%eax
 1f7db1f:	vmovdqu (%r9,%r15,1),%ymm0
 1f7db25:	vmovdqu 0x180(%r9,%r15,1),%ymm3
 1f7db2f:	vmovdqu 0x80(%r9,%r15,1),%ymm1
 1f7db39:	vmovdqu 0x100(%r9,%r15,1),%ymm2
 1f7db43:	not    %eax
 1f7db45:	vinserti64x4 $0x1,0x40(%r9,%r15,1),%zmm0,%zmm6
 1f7db4e:	vmovdqu 0x200(%r9,%r15,1),%ymm0
 1f7db58:	vinserti64x4 $0x1,0x1c0(%r9,%r15,1),%zmm3,%zmm7
 1f7db61:	vinserti64x4 $0x1,0xc0(%r9,%r15,1),%zmm1,%zmm1
 1f7db6a:	vinserti64x4 $0x1,0x140(%r9,%r15,1),%zmm2,%zmm2
 1f7db73:	kmovd  %eax,%k1
 1f7db77:	vinserti64x4 $0x1,0x240(%r9,%r15,1),%zmm0,%zmm3
 1f7db80:	vmovdqu 0x280(%r9,%r15,1),%ymm0
 1f7db8a:	mov    0xc38(%rdi),%rax
 1f7db91:	vinserti64x4 $0x1,0x2c0(%r9,%r15,1),%zmm0,%zmm9
 1f7db9a:	vmovdqu 0x300(%r9,%r15,1),%ymm0
 1f7dba4:	vmovdqu8 (%rcx,%r12,1),%xmm4{%k1}{z}
 1f7dbab:	mov    0x520(%rsp),%rcx
 1f7dbb3:	vinserti64x4 $0x1,0x340(%r9,%r15,1),%zmm0,%zmm8
 1f7dbbc:	vmovdqu 0x380(%r9,%r15,1),%ymm0
 1f7dbc6:	vinserti64x4 $0x1,0x3c0(%r9,%r15,1),%zmm0,%zmm15
 1f7dbcf:	vmovdqu8 (%rcx,%r12,1),%xmm5{%k1}{z}
 1f7dbd6:	vptestmb %xmm4,%xmm4,%k6
 1f7dbdc:	vpcmpeqb -0x19b8326(%rip),%xmm5,%k7{%k6}        # 5c58c0 <.LCPI3_10>
 1f7dbe6:	vmovdqu32 (%rbx,%r12,4),%zmm0{%k7}{z}
 1f7dbed:	kmovq  %k7,%k1
 1f7dbf2:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7dbf9:	vptestnmd %zmm13,%zmm18,%k0
 1f7dbff:	ktestw %k0,%k7
 1f7dc03:	jne    1f7e1a8 <node_facts_window_run+0x1c58>
 1f7dc09:	vmovdqa64 -0x1ac7493(%rip),%zmm0        # 4b6780 <abi_test_hex.digits+0xb400>
 1f7dc13:	vptestmd -0x19af121(%rip){1to16},%zmm18,%k0        # 5ceafc <.LCPI3_12>
 1f7dc1d:	kmovd  %k6,%edx
 1f7dc21:	vpermt2d %zmm1,%zmm0,%zmm6
 1f7dc27:	vpermt2d %zmm7,%zmm0,%zmm2
 1f7dc2d:	vpermt2d %zmm9,%zmm0,%zmm3
 1f7dc33:	vpermt2d %zmm15,%zmm0,%zmm8
 1f7dc39:	kmovd  %k0,%r14d
 1f7dc3d:	vptestmd %zmm14,%zmm18,%k0
 1f7dc43:	vshufi64x2 $0x44,%zmm2,%zmm6,%zmm0
 1f7dc4a:	vshufi64x2 $0x44,%zmm8,%zmm3,%zmm1
 1f7dc51:	vshufi64x2 $0xee,%zmm2,%zmm6,%zmm2
 1f7dc58:	vshufi64x2 $0xee,%zmm8,%zmm3,%zmm3
 1f7dc5f:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm15{%k6}{z}
 1f7dc66:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm19{%k6}{z}
 1f7dc6d:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm17{%k6}{z}
 1f7dc74:	vshufi64x2 $0x88,%zmm3,%zmm2,%zmm7
 1f7dc7b:	vpsrld $0x19,%zmm15,%zmm0
 1f7dc82:	vpandd -0x19af1a0(%rip){1to16},%zmm0,%zmm0        # 5ceaec <.LCPI3_4>
 1f7dc8c:	vpsrld $0x18,%zmm15,%zmm1
 1f7dc93:	vpsrld $0x1a,%zmm15,%zmm6
 1f7dc9a:	vpternlogd $0xec,%zmm10,%zmm0,%zmm1
 1f7dca1:	vpandd -0x19af173(%rip){1to16},%zmm15,%zmm0        # 5ceb38 <.LCPI3_72>
 1f7dcab:	vpmovdb %zmm1,%xmm16
 1f7dcb1:	vpsrld $0xc,%zmm17,%zmm1
 1f7dcb8:	vpmovdb %zmm1,%xmm20
 1f7dcbe:	vpcmpeqd -0x19af1d4(%rip){1to16},%zmm0,%k1{%k6}        # 5ceaf4 <.LCPI3_7>
 1f7dcc8:	vporq  %xmm11,%xmm16,%xmm0
 1f7dcce:	vmovdqu8 %xmm0,%xmm16{%k1}
 1f7dcd4:	vpcmpeqb %xmm11,%xmm5,%k1{%k6}
 1f7dcda:	vpternlogq $0xf8,%xmm12,%xmm20,%xmm16
 1f7dce1:	kmovd  %k1,%eax
 1f7dce5:	kmovw  %k1,0x60(%rsp)
 1f7dceb:	korw   %k0,%k1,%k1
 1f7dcef:	kmovw  %k1,0x1c0(%rsp)
 1f7dcf8:	test   %ax,%ax
 1f7dcfb:	je     1f7de70 <node_facts_window_run+0x1920>
 1f7dd01:	vmovdqu64 %zmm7,0x560(%rsp)
 1f7dd0c:	vmovdqu64 %zmm6,0x480(%rsp)
 1f7dd14:	vmovdqa64 %xmm20,0x400(%rsp)
 1f7dd1c:	vmovdqu64 %zmm19,0x280(%rsp)
 1f7dd24:	vmovdqu64 %zmm18,0x2c0(%rsp)
 1f7dd2c:	vmovdqu64 %zmm15,0x300(%rsp)
 1f7dd34:	vmovdqa %xmm4,0x200(%rsp)
 1f7dd3d:	vmovdqu64 %zmm17,0x340(%rsp)
 1f7dd45:	mov    %edx,0x380(%rsp)
 1f7dd4c:	vmovdqa64 %xmm16,0x3c0(%rsp)
 1f7dd54:	kmovw  %k7,0x180(%rsp)
 1f7dd5d:	kmovw  %k6,0x30(%rsp)
 1f7dd63:	movzwl %ax,%r13d
 1f7dd67:	movzwl %r14w,%r14d
 1f7dd6b:	mov    0x4e0(%rsp),%rax
 1f7dd73:	lea    (%rax,%r12,4),%rbp
 1f7dd77:	nopw   0x0(%rax,%rax,1)
 1f7dd80:	xor    %ebx,%ebx
 1f7dd82:	tzcnt  %r13d,%ebx
 1f7dd87:	xor    %edx,%edx
 1f7dd89:	mov    0x0(%rbp,%rbx,4),%esi
 1f7dd8d:	vzeroupper
 1f7dd90:	call   1f92730 <node_tests_window_line>
 1f7dd95:	mov    0x18(%rsp),%rdi
 1f7dd9a:	mov    $0x1,%edx
 1f7dd9f:	xor    %ecx,%ecx
 1f7dda1:	test   $0x2,%al
 1f7dda3:	shlx   %ebx,%edx,%eax
 1f7dda8:	cmove  %ecx,%eax
 1f7ddab:	or     %eax,%r14d
 1f7ddae:	blsr   %r13d,%r13d
 1f7ddb3:	jne    1f7dd80 <node_facts_window_run+0x1830>
 1f7ddb5:	vpbroadcastd -0x19af2cf(%rip),%zmm10        # 5ceaf0 <.LCPI3_5>
 1f7ddbf:	vpbroadcastb -0x1ac7108(%rip),%xmm11        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f7ddc8:	vpbroadcastb -0x1ac7110(%rip),%xmm12        # 4b6cc1 <abi_test_hex.digits+0xb941>
 1f7ddd1:	vpbroadcastd -0x19af2e3(%rip),%zmm13        # 5ceaf8 <.LCPI3_11>
 1f7dddb:	vpbroadcastd -0x19af2e5(%rip),%zmm14        # 5ceb00 <.LCPI3_13>
 1f7dde5:	vmovdqa64 0x3c0(%rsp),%xmm16
 1f7dded:	vmovdqu64 0x340(%rsp),%zmm17
 1f7ddf5:	vmovdqa 0x200(%rsp),%xmm4
 1f7ddfe:	vmovdqu64 0x300(%rsp),%zmm15
 1f7de06:	vmovdqu64 0x2c0(%rsp),%zmm18
 1f7de0e:	vmovdqu64 0x280(%rsp),%zmm19
 1f7de16:	vmovdqa64 0x400(%rsp),%xmm20
 1f7de1e:	vmovdqu64 0x480(%rsp),%zmm6
 1f7de26:	vmovdqu64 0x560(%rsp),%zmm7
 1f7de31:	mov    0x8(%rsp),%r11
 1f7de36:	mov    0x28(%rsp),%r13
 1f7de3b:	mov    0x40(%rsp),%rsi
 1f7de40:	mov    0x48(%rsp),%rbx
 1f7de45:	mov    0x120(%rsp),%r8
 1f7de4d:	mov    0x20(%rsp),%r9
 1f7de52:	mov    0x5e0(%rsp),%rbp
 1f7de5a:	kmovw  0x30(%rsp),%k6
 1f7de60:	kmovw  0x180(%rsp),%k7
 1f7de69:	mov    0x380(%rsp),%edx
 1f7de70:	vpsrld $0x2,%zmm17,%zmm0
 1f7de77:	vpandd -0x19af37d(%rip){1to16},%zmm0,%zmm0        # 5ceb04 <.LCPI3_14>
 1f7de81:	vptestmd -0x19af37f(%rip){1to16},%zmm17,%k2        # 5ceb0c <.LCPI3_16>
 1f7de8b:	vpandd -0x19af359(%rip){1to16},%zmm15,%zmm3        # 5ceb3c <.LCPI3_75>
 1f7de95:	vptestnmb %xmm4,%xmm4,%k0
 1f7de9b:	vpbroadcastd -0x19af38d(%rip),%zmm4        # 5ceb18 <.LCPI3_21>
 1f7dea5:	vptestmd -0x19af39f(%rip){1to16},%zmm19,%k3        # 5ceb10 <.LCPI3_17>
 1f7deaf:	vpandd %zmm14,%zmm19,%zmm1
 1f7deb5:	vpbroadcastb -0x1ac71fa(%rip),%xmm8        # 4b6cc4 <abi_test_hex.digits+0xb944>
 1f7debe:	vpbroadcastb -0x1ac7205(%rip),%xmm5        # 4b6cc2 <abi_test_hex.digits+0xb942>
 1f7dec7:	vpbroadcastb -0x1ac720d(%rip),%xmm9        # 4b6cc3 <abi_test_hex.digits+0xb943>
 1f7ded0:	vpcmpneqd -0x19af3d3(%rip){1to16},%zmm0,%k1        # 5ceb08 <.LCPI3_15>
 1f7dedb:	vpaddd -0x19af3d1(%rip){1to16},%zmm3,%zmm3        # 5ceb14 <.LCPI3_20>
 1f7dee5:	vpcmpeqd %zmm4,%zmm6,%k5{%k6}
 1f7deeb:	vpsrld $0x10,%zmm17,%zmm6
 1f7def2:	korw   %k1,%k2,%k1
 1f7def6:	vptestnmd %zmm7,%zmm7,%k2
 1f7defc:	korw   %k2,%k0,%k2
 1f7df00:	vptestnmd %zmm1,%zmm1,%k0
 1f7df06:	korw   %k1,%k2,%k1
 1f7df0a:	kmovd  %k0,%eax
 1f7df0e:	vpcmpltud %zmm4,%zmm3,%k0
 1f7df15:	vpslld $0x1f,%zmm3,%zmm3
 1f7df1c:	vpxor  %xmm4,%xmm4,%xmm4
 1f7df20:	vptestmd %zmm0,%zmm0,%k1{%k1}
 1f7df26:	kmovd  %k0,%ecx
 1f7df2a:	and    %eax,%ecx
 1f7df2c:	mov    %edx,%eax
 1f7df2e:	and    %ecx,%eax
 1f7df30:	kmovd  %eax,%k4
 1f7df34:	vmovdqu8 %xmm11,%xmm2{%k1}{z}
 1f7df3a:	kmovd  %r14d,%k1
 1f7df3f:	korw   %k3,%k1,%k3
 1f7df43:	vpcmpeqd %zmm13,%zmm0,%k1{%k4}
 1f7df49:	vmovdqu8 %xmm8,%xmm0{%k5}{z}
 1f7df4f:	vmovdqu8 -0x19b8669(%rip),%xmm0{%k4}        # 5c58f0 <.LCPI3_25>
 1f7df59:	knotw  %k1,%k0
 1f7df5d:	kmovd  %k0,%ecx
 1f7df61:	and    %eax,%ecx
 1f7df63:	kmovd  %ecx,%k4
 1f7df67:	vpcmpgtd %zmm3,%zmm4,%k4{%k4}
 1f7df6d:	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
 1f7df74:	vpaddd %zmm3,%zmm6,%zmm7
 1f7df7a:	vpbroadcastb -0x1ac72be(%rip),%xmm3        # 4b6cc5 <abi_test_hex.digits+0xb945>
 1f7df83:	vmovdqu8 -0x19b868d(%rip),%xmm0{%k4}        # 5c5900 <.LCPI3_26>
 1f7df8d:	vptestnmd %zmm7,%zmm7,%k4
 1f7df93:	vpblendmb -0x19b867d(%rip),%xmm3,%xmm3{%k4}        # 5c5920 <.LCPI3_28>
 1f7df9d:	vpcmpnleud -0x19af48c(%rip){1to16},%zmm7,%k4        # 5ceb1c <.LCPI3_22>
 1f7dfa8:	cmpb   $0x0,0xc80(%rdi)
 1f7dfaf:	vmovdqu8 -0x19b8689(%rip),%xmm3{%k4}        # 5c5930 <.LCPI3_29>
 1f7dfb9:	vpcmpnleud -0x19af4a4(%rip){1to16},%zmm7,%k4        # 5ceb20 <.LCPI3_23>
 1f7dfc4:	vmovdqu8 -0x19b868e(%rip),%xmm3{%k4}        # 5c5940 <.LCPI3_30>
 1f7dfce:	vptestmd %zmm1,%zmm1,%k4
 1f7dfd4:	vpor   %xmm5,%xmm2,%xmm1
 1f7dfd8:	vmovdqu8 %xmm1,%xmm2{%k4}
 1f7dfde:	kmovw  0x1c0(%rsp),%k4
 1f7dfe7:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f7dfed:	vpor   %xmm0,%xmm2,%xmm0
 1f7dff1:	vpord  -0x19af4bb(%rip){1to4},%xmm0,%xmm1        # 5ceb40 <.LCPI3_78>
 1f7dffb:	vpbroadcastb -0x1ac733e(%rip),%xmm3        # 4b6cc6 <abi_test_hex.digits+0xb946>
 1f7e004:	vmovdqu8 %xmm1,%xmm0{%k4}
 1f7e00a:	vpor   %xmm3,%xmm0,%xmm1
 1f7e00e:	vmovdqu8 %xmm1,%xmm0{%k3}
 1f7e014:	vpmovdb %zmm17,%xmm1
 1f7e01a:	kmovw  0x60(%rsp),%k3
 1f7e020:	vpor   %xmm1,%xmm9,%xmm2
 1f7e024:	vmovdqu8 %xmm2,%xmm1{%k3}
 1f7e02a:	vptestmd -0x19af510(%rip){1to16},%zmm18,%k3{%k7}        # 5ceb24 <.LCPI3_32>
 1f7e034:	vmovdqu8 %xmm8,%xmm2{%k3}{z}
 1f7e03a:	vpor   %xmm3,%xmm2,%xmm3
 1f7e03e:	vpsrld $0x8,%zmm15,%zmm8
 1f7e045:	vmovdqu8 %xmm2,%xmm3{%k2}
 1f7e04b:	vpandd -0x19af511(%rip){1to4},%xmm20,%xmm2        # 5ceb44 <.LCPI3_80>
 1f7e055:	vptestmd -0x19af537(%rip){1to16},%zmm19,%k2        # 5ceb28 <.LCPI3_33>
 1f7e05f:	vpor   %xmm2,%xmm12,%xmm4
 1f7e063:	vmovdqu8 %xmm4,%xmm2{%k6}
 1f7e069:	vpmovdb %zmm19,%xmm4
 1f7e06f:	vgf2p8affineqb $0x0,-0x19b1f62(%rip){1to2},%xmm4,%xmm4        # 5cc118 <.LCPI3_81>
 1f7e07a:	vpternlogq $0xf8,%xmm9,%xmm4,%xmm2
 1f7e081:	vpor   %xmm2,%xmm11,%xmm4
 1f7e085:	vmovdqu8 %xmm4,%xmm2{%k2}
 1f7e08b:	vpsrld $0xb,%zmm19,%zmm4
 1f7e092:	vpmovdb %zmm4,%xmm4
 1f7e098:	vpand  %xmm5,%xmm4,%xmm4
 1f7e09c:	vpmovdb %zmm15,%xmm5
 1f7e0a2:	vpternlogq $0xfe,%xmm4,%xmm3,%xmm2
 1f7e0a9:	vpsrld $0x10,%zmm15,%zmm3
 1f7e0b0:	vpmovdb %zmm8,%xmm4
 1f7e0b6:	vpmovdb %zmm3,%xmm3
 1f7e0bc:	je     1f7da7a <node_facts_window_run+0x152a>
 1f7e0c2:	vmovdqa64 -0x1ac788c(%rip),%zmm15        # 4b6840 <abi_test_hex.digits+0xb4c0>
 1f7e0cc:	vptestmd %zmm6,%zmm6,%k1{%k1}
 1f7e0d2:	add    %r9,%r15
 1f7e0d5:	vpxor  %xmm8,%xmm8,%xmm8
 1f7e0da:	vpxor  %xmm9,%xmm9,%xmm9
 1f7e0df:	vpcmpneqd -0x19af5be(%rip){1to16},%zmm6,%k0{%k1}        # 5ceb2c <.LCPI3_38>
 1f7e0ea:	vmovdqa %xmm3,%xmm6
 1f7e0ee:	vpternlogq $0xfe,%xmm5,%xmm1,%xmm6
 1f7e0f5:	kmovq  %k1,%k2
 1f7e0fa:	kmovw  %k1,%eax
 1f7e0fe:	popcnt %eax,%ecx
 1f7e102:	vpgatherdd 0x10(%r15,%zmm15,1),%zmm8{%k2}
 1f7e10a:	kmovq  %k1,%k2
 1f7e10f:	vpcmpnleud -0x19af5ea(%rip){1to16},%zmm8,%k3        # 5ceb30 <.LCPI3_39>
 1f7e11a:	vpgatherdd 0x14(%r15,%zmm15,1),%zmm9{%k2}
 1f7e122:	add    %rcx,0x38(%rsp)
 1f7e127:	mov    0x10(%rsp),%r10
 1f7e12c:	vpcmpeqd %zmm7,%zmm8,%k2
 1f7e132:	vmovdqa64 %xmm16,%xmm7
 1f7e138:	vpternlogq $0xfe,%xmm4,%xmm6,%xmm7
 1f7e13f:	vptestnmd %zmm9,%zmm9,%k2{%k2}
 1f7e145:	vptestmd %zmm9,%zmm9,%k4
 1f7e14b:	vpternlogq $0xfe,%xmm2,%xmm0,%xmm7
 1f7e152:	korw   %k4,%k3,%k3
 1f7e156:	kandw  %k2,%k0,%k2
 1f7e15a:	knotw  %k0,%k0
 1f7e15e:	kandd  %k1,%k0,%k0
 1f7e163:	kandw  %k0,%k3,%k0
 1f7e167:	korw   %k0,%k2,%k2
 1f7e16b:	vptestnmd %zmm10,%zmm17,%k0{%k2}
 1f7e171:	kandw  %k0,%k1,%k0
 1f7e175:	kmovd  %k0,%ecx
 1f7e179:	vptestmb %xmm7,%xmm7,%k0
 1f7e17f:	andn   %eax,%ecx,%eax
 1f7e184:	kmovd  %k0,%ecx
 1f7e188:	andn   %ecx,%edx,%ecx
 1f7e18d:	popcnt %eax,%eax
 1f7e191:	movzwl %cx,%ecx
 1f7e194:	popcnt %ecx,%ecx
 1f7e198:	add    %rcx,%r10
 1f7e19b:	add    %rax,%r10
 1f7e19e:	mov    %r10,0x10(%rsp)
 1f7e1a3:	jmp    1f7da7a <node_facts_window_run+0x152a>
 1f7e1a8:	kandw  %k0,%k7,%k0
 1f7e1ac:	vmovdqa %xmm5,0x60(%rsp)
 1f7e1b2:	vmovdqu64 %zmm6,0x1c0(%rsp)
 1f7e1ba:	vmovdqu64 %zmm2,0x3c0(%rsp)
 1f7e1c2:	vmovdqu64 %zmm3,0x380(%rsp)
 1f7e1ca:	vmovdqu64 %zmm1,0x340(%rsp)
 1f7e1d2:	vmovdqu64 %zmm7,0x300(%rsp)
 1f7e1da:	vmovdqu64 %zmm8,0x2c0(%rsp)
 1f7e1e2:	vmovdqu64 %zmm9,0x280(%rsp)
 1f7e1ea:	vmovdqu64 %zmm15,0x400(%rsp)
 1f7e1f2:	vmovdqu64 %zmm0,0x480(%rsp)
 1f7e1fa:	kmovw  %k6,0x30(%rsp)
 1f7e200:	kmovw  %k7,0x180(%rsp)
 1f7e209:	vmovdqa %xmm4,0x200(%rsp)
 1f7e212:	kmovd  %k0,%eax
 1f7e216:	movzwl %ax,%r14d
 1f7e21a:	jmp    1f7e31a <node_facts_window_run+0x1dca>
 1f7e21f:	mov    0x48(%rsp),%r8
 1f7e224:	mov    (%r8,%rax,4),%ebx
 1f7e228:	mov    0xc38(%rdi),%rsi
 1f7e22f:	shl    $0x6,%rcx
 1f7e233:	mov    0x20(%r11),%rdx
 1f7e237:	cmpb   $0x1,(%rsi,%rbx,1)
 1f7e23b:	movzbl 0x30(%rdx,%rcx,1),%edx
 1f7e240:	adcq   $0x0,0x50(%rsp)
 1f7e246:	and    $0x1,%edx
 1f7e249:	mov    0x4e0(%rsp),%rsi
 1f7e251:	mov    (%rsi,%rax,4),%esi
 1f7e254:	vzeroupper
 1f7e257:	call   1f92730 <node_tests_window_line>
 1f7e25c:	mov    0x18(%rsp),%rdi
 1f7e261:	vpbroadcastd -0x19af77b(%rip),%zmm10        # 5ceaf0 <.LCPI3_5>
 1f7e26b:	vpbroadcastb -0x1ac75b4(%rip),%xmm11        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f7e274:	vpbroadcastb -0x1ac75bc(%rip),%xmm12        # 4b6cc1 <abi_test_hex.digits+0xb941>
 1f7e27d:	vpbroadcastd -0x19af78f(%rip),%zmm13        # 5ceaf8 <.LCPI3_11>
 1f7e287:	vpbroadcastd -0x19af791(%rip),%zmm14        # 5ceb00 <.LCPI3_13>
 1f7e291:	vmovdqa 0x200(%rsp),%xmm4
 1f7e29a:	vmovdqa 0x60(%rsp),%xmm5
 1f7e2a0:	vmovdqu64 0x1c0(%rsp),%zmm6
 1f7e2a8:	vmovdqu64 0x3c0(%rsp),%zmm2
 1f7e2b0:	vmovdqu64 0x380(%rsp),%zmm3
 1f7e2b8:	vmovdqu64 0x340(%rsp),%zmm1
 1f7e2c0:	vmovdqu64 0x300(%rsp),%zmm7
 1f7e2c8:	vmovdqu64 0x2c0(%rsp),%zmm8
 1f7e2d0:	vmovdqu64 0x280(%rsp),%zmm9
 1f7e2d8:	vmovdqu64 0x400(%rsp),%zmm15
 1f7e2e0:	vmovdqu64 0x480(%rsp),%zmm0
 1f7e2e8:	mov    0x8(%rsp),%r11
 1f7e2ed:	mov    0x40(%rsp),%rsi
 1f7e2f2:	mov    0x20(%rsp),%r9
 1f7e2f7:	kmovw  0x30(%rsp),%k6
 1f7e2fd:	kmovw  0x180(%rsp),%k7
 1f7e306:	or     %r13b,%al
 1f7e309:	blsr   %r14d,%r14d
 1f7e30e:	mov    0xc38(%rdi),%rcx
 1f7e315:	mov    %al,(%rcx,%rbx,1)
 1f7e318:	je     1f7e388 <node_facts_window_run+0x1e38>
 1f7e31a:	xor    %eax,%eax
 1f7e31c:	tzcnt  %r14d,%eax
 1f7e321:	mov    0x60(%r11),%esi
 1f7e325:	mov    $0x1,%r13b
 1f7e328:	add    %r12,%rax
 1f7e32b:	mov    %rax,%rdx
 1f7e32e:	shl    $0x6,%rdx
 1f7e332:	mov    (%r9,%rdx,1),%ecx
 1f7e336:	mov    0xc(%r9,%rdx,1),%edx
 1f7e33b:	shr    $0x3,%ecx
 1f7e33e:	cmp    %esi,%ecx
 1f7e340:	cmovae %esi,%ecx
 1f7e343:	test   %rdx,%rdx
 1f7e346:	je     1f7e21f <node_facts_window_run+0x1ccf>
 1f7e34c:	mov    0x5a0(%rsp),%rsi
 1f7e354:	mov    0x48(%rsp),%r8
 1f7e359:	cmp    0x3b8(%rsi),%edx
 1f7e35f:	jae    1f7e224 <node_facts_window_run+0x1cd4>
 1f7e365:	mov    0x5a0(%rsp),%rsi
 1f7e36d:	mov    0x3a8(%rsi),%rsi
 1f7e374:	cmpl   $0x0,(%rsi,%rdx,4)
 1f7e378:	setne  %r13b
 1f7e37c:	shl    $0x5,%r13b
 1f7e380:	inc    %r13b
 1f7e383:	jmp    1f7e224 <node_facts_window_run+0x1cd4>
 1f7e388:	mov    0xc38(%rdi),%rax
 1f7e38f:	kmovq  %k7,%k1
 1f7e394:	vpxord %xmm18,%xmm18,%xmm18
 1f7e39a:	mov    0x28(%rsp),%r13
 1f7e39f:	mov    0x48(%rsp),%rbx
 1f7e3a4:	mov    0x120(%rsp),%r8
 1f7e3ac:	vpgatherdd (%rax,%zmm0,1),%zmm18{%k1}
 1f7e3b3:	jmp    1f7dc09 <node_facts_window_run+0x16b9>
 1f7e3b8:	test   %ecx,%ecx
 1f7e3ba:	je     1f7f816 <node_facts_window_run+0x32c6>
 1f7e3c0:	vpbroadcastd -0x19af8da(%rip),%zmm13        # 5ceaf0 <.LCPI3_5>
 1f7e3ca:	vpbroadcastb -0x1ac7713(%rip),%xmm14        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f7e3d3:	vpbroadcastb -0x1ac771b(%rip),%xmm15        # 4b6cc1 <abi_test_hex.digits+0xb941>
 1f7e3dc:	vpbroadcastd -0x19af8ee(%rip),%zmm16        # 5ceaf8 <.LCPI3_11>
 1f7e3e6:	vpbroadcastd -0x19af8f0(%rip),%zmm17        # 5ceb00 <.LCPI3_13>
 1f7e3f0:	mov    (%r11),%rax
 1f7e3f3:	lea    0x69454(%r13),%r10
 1f7e3fa:	lea    0x422c(%r13),%rdx
 1f7e401:	mov    %ecx,%ebp
 1f7e403:	xor    %r12d,%r12d
 1f7e406:	mov    %rax,0x98(%rsp)
 1f7e40e:	mov    %r10,0xc0(%rsp)
 1f7e416:	mov    %rdx,0xa0(%rsp)
 1f7e41e:	movq   $0x0,0x50(%rsp)
 1f7e427:	movq   $0x0,0x38(%rsp)
 1f7e430:	movq   $0x0,0x10(%rsp)
 1f7e439:	mov    %rbp,0xb8(%rsp)
 1f7e441:	jmp    1f7e50b <node_facts_window_run+0x1fbb>
 1f7e446:	cs nopw 0x0(%rax,%rax,1)
 1f7e450:	vpxor  %xmm1,%xmm1,%xmm1
 1f7e454:	vpxor  %xmm0,%xmm0,%xmm0
 1f7e458:	vpxor  %xmm5,%xmm5,%xmm5
 1f7e45c:	vpxor  %xmm3,%xmm3,%xmm3
 1f7e460:	vpxor  %xmm6,%xmm6,%xmm6
 1f7e464:	vpxor  %xmm7,%xmm7,%xmm7
 1f7e468:	vpxor  %xmm8,%xmm8,%xmm8
 1f7e46d:	vpxor  %xmm2,%xmm2,%xmm2
 1f7e471:	vpxord %xmm19,%xmm19,%xmm19
 1f7e477:	mov    0xc00(%rdi),%rax
 1f7e47e:	vmovdqu64 %xmm19,(%rax,%r12,1)
 1f7e485:	mov    0xc08(%rdi),%rax
 1f7e48c:	vmovdqu %xmm2,(%rax,%r12,1)
 1f7e492:	mov    0xb80(%r11),%rax
 1f7e499:	vmovdqu %xmm8,(%rax,%r12,1)
 1f7e49f:	mov    0xb88(%r11),%rax
 1f7e4a6:	vmovdqu %xmm7,(%rax,%r12,1)
 1f7e4ac:	mov    0xb90(%r11),%rax
 1f7e4b3:	vmovdqu %xmm6,(%rax,%r12,1)
 1f7e4b9:	mov    0xb98(%r11),%rax
 1f7e4c0:	vmovdqu %xmm3,(%rax,%r12,1)
 1f7e4c6:	mov    0xba0(%r11),%rax
 1f7e4cd:	vmovdqu %xmm4,(%rax,%r12,1)
 1f7e4d3:	mov    0xc20(%r11),%rax
 1f7e4da:	vmovdqu64 %zmm5,(%rax,%r12,4)
 1f7e4e1:	mov    0xcd0(%r11),%rax
 1f7e4e8:	vmovdqu64 %zmm0,(%rax,%r12,8)
 1f7e4ef:	mov    0xcd0(%r11),%rax
 1f7e4f6:	vmovdqu64 %zmm1,0x40(%rax,%r12,8)
 1f7e4fe:	add    $0x10,%r12
 1f7e502:	cmp    %rbp,%r12
 1f7e505:	jae    1f7f831 <node_facts_window_run+0x32e1>
 1f7e50b:	vpxor  %xmm4,%xmm4,%xmm4
 1f7e50f:	cmp    %r8,%r12
 1f7e512:	jae    1f7e450 <node_facts_window_run+0x1f00>
 1f7e518:	mov    %r8d,%eax
 1f7e51b:	sub    %r12d,%eax
 1f7e51e:	mov    $0x10,%ecx
 1f7e523:	mov    $0xffffffff,%edx
 1f7e528:	vpxor  %xmm12,%xmm12,%xmm12
 1f7e52d:	cmp    $0x10,%eax
 1f7e530:	cmovae %ecx,%eax
 1f7e533:	mov    0x9b0(%r11),%rcx
 1f7e53a:	shlx   %eax,%edx,%eax
 1f7e53f:	mov    %r12,%rdx
 1f7e542:	shl    $0x6,%rdx
 1f7e546:	not    %eax
 1f7e548:	vmovdqu (%r9,%rdx,1),%ymm4
 1f7e54e:	vmovdqu64 0x40(%r9,%rdx,1),%ymm26
 1f7e556:	vmovdqu64 0x80(%r9,%rdx,1),%ymm27
 1f7e55e:	vmovdqu64 0xc0(%r9,%rdx,1),%ymm28
 1f7e566:	vmovdqu 0x100(%r9,%rdx,1),%ymm5
 1f7e570:	vmovdqu 0x140(%r9,%rdx,1),%ymm6
 1f7e57a:	vmovdqu64 0x180(%r9,%rdx,1),%ymm24
 1f7e582:	vmovdqu64 0x1c0(%r9,%rdx,1),%ymm25
 1f7e58a:	vmovdqu 0x200(%r9,%rdx,1),%ymm7
 1f7e594:	vmovdqu64 0x240(%r9,%rdx,1),%ymm18
 1f7e59c:	vmovdqu64 0x280(%r9,%rdx,1),%ymm22
 1f7e5a4:	vmovdqu64 0x2c0(%r9,%rdx,1),%ymm23
 1f7e5ac:	vmovdqu 0x300(%r9,%rdx,1),%ymm11
 1f7e5b6:	vmovdqu64 0x340(%r9,%rdx,1),%ymm19
 1f7e5be:	vmovdqu64 0x380(%r9,%rdx,1),%ymm20
 1f7e5c6:	vmovdqu64 0x3c0(%r9,%rdx,1),%ymm21
 1f7e5ce:	kmovd  %eax,%k1
 1f7e5d2:	mov    0xc38(%rdi),%rax
 1f7e5d9:	vmovdqu8 (%rcx,%r12,1),%xmm0{%k1}{z}
 1f7e5e0:	mov    0xc0(%rsp),%rcx
 1f7e5e8:	vmovdqu8 (%rcx,%r12,1),%xmm10{%k1}{z}
 1f7e5ef:	vptestmb %xmm0,%xmm0,%k6
 1f7e5f5:	vpcmpeqb -0x19b8d3f(%rip),%xmm10,%k7{%k6}        # 5c58c0 <.LCPI3_10>
 1f7e5ff:	vmovdqu32 (%rbx,%r12,4),%zmm0{%k7}{z}
 1f7e606:	kmovq  %k7,%k1
 1f7e60b:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7e612:	vptestnmd %zmm16,%zmm12,%k0
 1f7e618:	ktestw %k0,%k7
 1f7e61c:	jne    1f7ed27 <node_facts_window_run+0x27d7>
 1f7e622:	vpmovsxbd -0x19afaf7(%rip),%xmm3        # 5ceb34 <.LCPI3_71>
 1f7e62b:	vmovdqa64 -0x1ac7eb5(%rip),%zmm8        # 4b6780 <abi_test_hex.digits+0xb400>
 1f7e635:	vinserti64x4 $0x1,%ymm26,%zmm4,%zmm0
 1f7e63c:	vinserti64x4 $0x1,%ymm28,%zmm27,%zmm1
 1f7e643:	vptestmd -0x19afb51(%rip){1to16},%zmm12,%k0        # 5ceafc <.LCPI3_12>
 1f7e64d:	vmovdqa64 %zmm0,%zmm2
 1f7e653:	vpermt2d %zmm1,%zmm8,%zmm2
 1f7e659:	vpermt2d %zmm1,%zmm3,%zmm0
 1f7e65f:	vmovdqa64 %zmm3,%zmm9
 1f7e665:	vpunpcklqdq %ymm28,%ymm27,%ymm1
 1f7e66b:	vpunpcklqdq %ymm26,%ymm4,%ymm3
 1f7e671:	kmovd  %k0,%r14d
 1f7e675:	vptestmd %zmm17,%zmm12,%k0
 1f7e67b:	vperm2i128 $0x31,%ymm1,%ymm3,%ymm1
 1f7e681:	vinserti64x4 $0x1,%ymm25,%zmm24,%zmm3
 1f7e688:	vmovdqu64 %zmm1,0x1c0(%rsp)
 1f7e690:	vinserti64x4 $0x1,%ymm6,%zmm5,%zmm1
 1f7e697:	vpunpcklqdq %ymm6,%ymm5,%ymm5
 1f7e69b:	vmovdqa64 %zmm1,%zmm4
 1f7e6a1:	vpermt2d %zmm3,%zmm9,%zmm1
 1f7e6a7:	vpermt2d %zmm3,%zmm8,%zmm4
 1f7e6ad:	vpunpcklqdq %ymm25,%ymm24,%ymm3
 1f7e6b3:	vperm2i128 $0x31,%ymm3,%ymm5,%ymm3
 1f7e6b9:	vinserti64x4 $0x1,%ymm23,%zmm22,%zmm5
 1f7e6c0:	vmovdqu %ymm3,0x180(%rsp)
 1f7e6c9:	vinserti64x4 $0x1,%ymm18,%zmm7,%zmm3
 1f7e6d0:	vpunpcklqdq %ymm18,%ymm7,%ymm7
 1f7e6d6:	vinserti64x4 $0x1,%ymm19,%zmm11,%zmm18
 1f7e6dd:	vmovdqa64 %zmm3,%zmm6
 1f7e6e3:	vpermt2d %zmm5,%zmm8,%zmm6
 1f7e6e9:	vpermt2d %zmm5,%zmm9,%zmm3
 1f7e6ef:	vpunpcklqdq %ymm23,%ymm22,%ymm5
 1f7e6f5:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f7e6fb:	vperm2i128 $0x31,%ymm5,%ymm7,%ymm5
 1f7e701:	vmovdqa64 %zmm18,%zmm7
 1f7e707:	vmovdqu64 %zmm5,0x200(%rsp)
 1f7e70f:	vinserti64x4 $0x1,%ymm21,%zmm20,%zmm5
 1f7e716:	vpermt2d %zmm5,%zmm8,%zmm7
 1f7e71c:	vinserti64x4 $0x1,%ymm3,%zmm0,%zmm22
 1f7e723:	vshufi64x2 $0x44,%zmm4,%zmm2,%zmm0
 1f7e72a:	vpermt2d %zmm5,%zmm9,%zmm18
 1f7e730:	vpunpcklqdq %ymm21,%ymm20,%ymm5
 1f7e736:	vshufi64x2 $0xee,%zmm4,%zmm2,%zmm2
 1f7e73d:	vpunpcklqdq %ymm19,%ymm11,%ymm8
 1f7e743:	vperm2i128 $0x31,%ymm5,%ymm8,%ymm5
 1f7e749:	vshufi64x2 $0x44,%zmm7,%zmm6,%zmm1
 1f7e750:	vshufi64x2 $0xee,%zmm7,%zmm6,%zmm3
 1f7e757:	vshufi32x4 $0x88,%zmm1,%zmm0,%zmm21{%k6}{z}
 1f7e75e:	vshufi32x4 $0xdd,%zmm1,%zmm0,%zmm23{%k6}{z}
 1f7e765:	vshufi32x4 $0xdd,%zmm3,%zmm2,%zmm20{%k6}{z}
 1f7e76c:	vshufi32x4 $0x88,%zmm3,%zmm2,%zmm4{%k6}{z}
 1f7e773:	vpsrld $0x19,%zmm21,%zmm0
 1f7e77a:	vpandd -0x19afc98(%rip){1to16},%zmm0,%zmm0        # 5ceaec <.LCPI3_4>
 1f7e784:	vpsrld $0x18,%zmm21,%zmm1
 1f7e78b:	vpsrld $0x1a,%zmm21,%zmm7
 1f7e792:	vpternlogd $0xec,%zmm13,%zmm0,%zmm1
 1f7e799:	vpandd -0x19afc6b(%rip){1to16},%zmm21,%zmm0        # 5ceb38 <.LCPI3_72>
 1f7e7a3:	vpmovdb %zmm1,%xmm19
 1f7e7a9:	vpsrld $0xc,%zmm20,%zmm1
 1f7e7b0:	vpmovdb %zmm1,%xmm24
 1f7e7b6:	vpcmpeqd -0x19afccc(%rip){1to16},%zmm0,%k1{%k6}        # 5ceaf4 <.LCPI3_7>
 1f7e7c0:	vporq  %xmm14,%xmm19,%xmm0
 1f7e7c6:	vmovdqu8 %xmm0,%xmm19{%k1}
 1f7e7cc:	vpcmpeqb %xmm14,%xmm10,%k1{%k6}
 1f7e7d2:	vpternlogq $0xf8,%xmm15,%xmm24,%xmm19
 1f7e7d9:	kmovd  %k1,%eax
 1f7e7dd:	kmovw  %k1,0x60(%rsp)
 1f7e7e3:	korw   %k0,%k1,%k1
 1f7e7e7:	kmovw  %k1,0x30(%rsp)
 1f7e7ed:	test   %ax,%ax
 1f7e7f0:	je     1f7e99d <node_facts_window_run+0x244d>
 1f7e7f6:	vmovdqu64 %zmm4,0x650(%rsp)
 1f7e801:	vmovdqu %ymm5,0x5a0(%rsp)
 1f7e80a:	vmovdqu64 %zmm7,0x5e0(%rsp)
 1f7e815:	vmovdqa64 %xmm24,0x4e0(%rsp)
 1f7e81d:	vmovdqu64 %zmm23,0x520(%rsp)
 1f7e828:	vmovdqu64 %zmm22,0x560(%rsp)
 1f7e833:	vmovdqu64 %zmm21,0x480(%rsp)
 1f7e83b:	vmovdqu64 %zmm18,0x400(%rsp)
 1f7e843:	vmovdqu64 %zmm20,0x280(%rsp)
 1f7e84b:	vmovdqu64 %zmm12,0x2c0(%rsp)
 1f7e853:	vmovdqa64 %xmm19,0x300(%rsp)
 1f7e85b:	kmovw  %k7,0x380(%rsp)
 1f7e864:	mov    %rdx,0x340(%rsp)
 1f7e86c:	kmovd  %k6,0x3c0(%rsp)
 1f7e876:	movzwl %ax,%r13d
 1f7e87a:	movzwl %r14w,%r14d
 1f7e87e:	xor    %r15d,%r15d
 1f7e881:	mov    0xa0(%rsp),%rax
 1f7e889:	lea    (%rax,%r12,4),%rbp
 1f7e88d:	nopl   (%rax)
 1f7e890:	xor    %ebx,%ebx
 1f7e892:	tzcnt  %r13d,%ebx
 1f7e897:	xor    %edx,%edx
 1f7e899:	mov    0x0(%rbp,%rbx,4),%esi
 1f7e89d:	vzeroupper
 1f7e8a0:	call   1f92730 <node_tests_window_line>
 1f7e8a5:	mov    0x18(%rsp),%rdi
 1f7e8aa:	mov    $0x1,%ecx
 1f7e8af:	test   $0x2,%al
 1f7e8b1:	shlx   %ebx,%ecx,%eax
 1f7e8b6:	cmove  %r15d,%eax
 1f7e8ba:	or     %eax,%r14d
 1f7e8bd:	blsr   %r13d,%r13d
 1f7e8c2:	jne    1f7e890 <node_facts_window_run+0x2340>
 1f7e8c4:	vpbroadcastd -0x19afdde(%rip),%zmm13        # 5ceaf0 <.LCPI3_5>
 1f7e8ce:	vpbroadcastb -0x1ac7c17(%rip),%xmm14        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f7e8d7:	vpbroadcastb -0x1ac7c1f(%rip),%xmm15        # 4b6cc1 <abi_test_hex.digits+0xb941>
 1f7e8e0:	vpbroadcastd -0x19afdf2(%rip),%zmm16        # 5ceaf8 <.LCPI3_11>
 1f7e8ea:	vpbroadcastd -0x19afdf4(%rip),%zmm17        # 5ceb00 <.LCPI3_13>
 1f7e8f4:	vmovdqa64 0x300(%rsp),%xmm19
 1f7e8fc:	vmovdqu64 0x2c0(%rsp),%zmm12
 1f7e904:	vmovdqu64 0x280(%rsp),%zmm20
 1f7e90c:	vmovdqu64 0x400(%rsp),%zmm18
 1f7e914:	vmovdqu64 0x480(%rsp),%zmm21
 1f7e91c:	vmovdqu64 0x560(%rsp),%zmm22
 1f7e927:	vmovdqu64 0x520(%rsp),%zmm23
 1f7e932:	vmovdqa64 0x4e0(%rsp),%xmm24
 1f7e93a:	vmovdqu64 0x5e0(%rsp),%zmm7
 1f7e945:	vmovdqu 0x5a0(%rsp),%ymm5
 1f7e94e:	vmovdqu64 0x650(%rsp),%zmm4
 1f7e959:	mov    0x8(%rsp),%r11
 1f7e95e:	mov    0x28(%rsp),%r13
 1f7e963:	mov    0x40(%rsp),%rsi
 1f7e968:	mov    0x48(%rsp),%rbx
 1f7e96d:	mov    0x120(%rsp),%r8
 1f7e975:	mov    0x20(%rsp),%r9
 1f7e97a:	mov    0xb8(%rsp),%rbp
 1f7e982:	kmovd  0x3c0(%rsp),%k6
 1f7e98c:	mov    0x340(%rsp),%rdx
 1f7e994:	kmovw  0x380(%rsp),%k7
 1f7e99d:	vpsrld $0x2,%zmm20,%zmm0
 1f7e9a4:	vpandd -0x19afeaa(%rip){1to16},%zmm0,%zmm2        # 5ceb04 <.LCPI3_14>
 1f7e9ae:	vpbroadcastd -0x19afeb0(%rip),%zmm0        # 5ceb08 <.LCPI3_15>
 1f7e9b8:	vptestmd -0x19afeb6(%rip){1to16},%zmm20,%k3        # 5ceb0c <.LCPI3_16>
 1f7e9c2:	vmovdqu64 0x200(%rsp),%zmm1
 1f7e9ca:	vptestnmd %zmm4,%zmm4,%k1
 1f7e9d0:	vpbroadcastd -0x19afec2(%rip),%zmm6        # 5ceb18 <.LCPI3_21>
 1f7e9da:	vextracti64x4 $0x1,%zmm4,%ymm3
 1f7e9e1:	kmovd  %r14d,%k4
 1f7e9e6:	vpsrld $0x10,%zmm20,%zmm9
 1f7e9ed:	vpbroadcastb -0x1ac7d34(%rip),%xmm8        # 4b6cc2 <abi_test_hex.digits+0xb942>
 1f7e9f6:	vpbroadcastb -0x1ac7d3c(%rip),%xmm11        # 4b6cc3 <abi_test_hex.digits+0xb943>
 1f7e9ff:	kmovw  %k1,%eax
 1f7ea03:	vpcmpeqd %zmm0,%zmm2,%k0
 1f7ea09:	vpcmpneqd %zmm0,%zmm2,%k2
 1f7ea10:	vmovdqu64 0x1c0(%rsp),%zmm0
 1f7ea18:	korw   %k1,%k3,%k3
 1f7ea1c:	vinserti64x4 $0x1,%ymm5,%zmm1,%zmm1
 1f7ea23:	vpandd -0x19afef1(%rip){1to16},%zmm21,%zmm5        # 5ceb3c <.LCPI3_75>
 1f7ea2d:	vpcmpeqd %zmm6,%zmm7,%k5{%k6}
 1f7ea33:	vpbroadcastb -0x1ac7d78(%rip),%xmm7        # 4b6cc4 <abi_test_hex.digits+0xb944>
 1f7ea3c:	vinserti64x4 $0x1,0x180(%rsp),%zmm0,%zmm0
 1f7ea45:	kmovw  %k0,%ecx
 1f7ea49:	korw   %k2,%k3,%k2
 1f7ea4d:	vpaddd -0x19aff43(%rip){1to16},%zmm5,%zmm5        # 5ceb14 <.LCPI3_20>
 1f7ea57:	andn   %ecx,%eax,%eax
 1f7ea5c:	vptestmd %zmm2,%zmm2,%k2{%k2}
 1f7ea62:	kmovd  %eax,%k3
 1f7ea66:	shr    $0x8,%eax
 1f7ea69:	vpmovzxdq %ymm4,%zmm0{%k3}
 1f7ea6f:	kmovd  %eax,%k3
 1f7ea73:	vmovdqu8 %xmm14,%xmm4{%k2}{z}
 1f7ea79:	vpcmpltud %zmm6,%zmm5,%k2
 1f7ea80:	vpslld $0x1f,%zmm5,%zmm5
 1f7ea87:	vpxor  %xmm6,%xmm6,%xmm6
 1f7ea8b:	vpmovzxdq %ymm3,%zmm1{%k3}
 1f7ea91:	vptestmd -0x19aff8b(%rip){1to16},%zmm23,%k3        # 5ceb10 <.LCPI3_17>
 1f7ea9b:	vpandd %zmm17,%zmm23,%zmm3
 1f7eaa1:	vptestnmd %zmm3,%zmm3,%k0
 1f7eaa7:	kandd  %k6,%k0,%k0
 1f7eaac:	korw   %k3,%k4,%k3
 1f7eab0:	kandd  %k2,%k0,%k4
 1f7eab5:	vpcmpeqd %zmm16,%zmm2,%k2{%k4}
 1f7eabb:	vmovdqu8 %xmm7,%xmm2{%k5}{z}
 1f7eac1:	vmovdqu8 -0x19b91db(%rip),%xmm2{%k4}        # 5c58f0 <.LCPI3_25>
 1f7eacb:	knotw  %k2,%k0
 1f7eacf:	kandd  %k0,%k4,%k5
 1f7ead4:	vpcmpgtd %zmm5,%zmm6,%k4{%k5}
 1f7eada:	vpternlogd $0xff,%zmm5,%zmm5,%zmm5
 1f7eae1:	vpaddd %zmm5,%zmm9,%zmm10
 1f7eae7:	vpbroadcastb -0x1ac7e2b(%rip),%xmm5        # 4b6cc5 <abi_test_hex.digits+0xb945>
 1f7eaf0:	vmovdqu8 -0x19b91fa(%rip),%xmm2{%k4}        # 5c5900 <.LCPI3_26>
 1f7eafa:	vptestnmd %zmm10,%zmm10,%k4
 1f7eb00:	vpblendmb -0x19b91ea(%rip),%xmm5,%xmm5{%k4}        # 5c5920 <.LCPI3_28>
 1f7eb0a:	vpcmpnleud -0x19afff9(%rip){1to16},%zmm10,%k4        # 5ceb1c <.LCPI3_22>
 1f7eb15:	cmpb   $0x0,0xc80(%rdi)
 1f7eb1c:	vmovdqu8 -0x19b91f6(%rip),%xmm5{%k4}        # 5c5930 <.LCPI3_29>
 1f7eb26:	vpcmpnleud -0x19b0011(%rip){1to16},%zmm10,%k4        # 5ceb20 <.LCPI3_23>
 1f7eb31:	vmovdqu8 -0x19b91fb(%rip),%xmm5{%k4}        # 5c5940 <.LCPI3_30>
 1f7eb3b:	vptestmd %zmm3,%zmm3,%k4
 1f7eb41:	vpor   %xmm4,%xmm8,%xmm3
 1f7eb45:	vmovdqu8 %xmm3,%xmm4{%k4}
 1f7eb4b:	kmovw  0x30(%rsp),%k4
 1f7eb51:	vmovdqu8 %xmm5,%xmm2{%k2}
 1f7eb57:	vpor   %xmm2,%xmm4,%xmm2
 1f7eb5b:	vpord  -0x19b0025(%rip){1to4},%xmm2,%xmm3        # 5ceb40 <.LCPI3_78>
 1f7eb65:	vpbroadcastb -0x1ac7ea8(%rip),%xmm5        # 4b6cc6 <abi_test_hex.digits+0xb946>
 1f7eb6e:	vmovdqu8 %xmm3,%xmm2{%k4}
 1f7eb74:	vpor   %xmm5,%xmm2,%xmm3
 1f7eb78:	vmovdqu8 %xmm3,%xmm2{%k3}
 1f7eb7e:	vpmovdb %zmm20,%xmm3
 1f7eb84:	kmovw  0x60(%rsp),%k3
 1f7eb8a:	vpor   %xmm3,%xmm11,%xmm4
 1f7eb8e:	vmovdqu8 %xmm4,%xmm3{%k3}
 1f7eb94:	vptestmd -0x19b007a(%rip){1to16},%zmm12,%k3{%k7}        # 5ceb24 <.LCPI3_32>
 1f7eb9e:	vmovdqu8 %xmm7,%xmm4{%k3}{z}
 1f7eba4:	vpor   %xmm5,%xmm4,%xmm6
 1f7eba8:	vpsrld $0xb,%zmm23,%zmm7
 1f7ebaf:	vmovdqu8 %xmm4,%xmm6{%k1}
 1f7ebb5:	vpandd -0x19b007b(%rip){1to4},%xmm24,%xmm4        # 5ceb44 <.LCPI3_80>
 1f7ebbf:	vptestmd -0x19b00a1(%rip){1to16},%zmm23,%k1        # 5ceb28 <.LCPI3_33>
 1f7ebc9:	vpmovdb %zmm7,%xmm7
 1f7ebcf:	vpand  %xmm7,%xmm8,%xmm7
 1f7ebd3:	vpmovdb %zmm21,%xmm8
 1f7ebd9:	vpor   %xmm4,%xmm15,%xmm5
 1f7ebdd:	vmovdqu8 %xmm5,%xmm4{%k6}
 1f7ebe3:	vpmovdb %zmm23,%xmm5
 1f7ebe9:	vgf2p8affineqb $0x0,-0x19b2adc(%rip){1to2},%xmm5,%xmm5        # 5cc118 <.LCPI3_81>
 1f7ebf4:	vpternlogq $0xf8,%xmm11,%xmm5,%xmm4
 1f7ebfb:	vpsrld $0x8,%zmm21,%zmm11
 1f7ec02:	vpor   %xmm4,%xmm14,%xmm5
 1f7ec06:	vmovdqu8 %xmm5,%xmm4{%k1}
 1f7ec0c:	vpternlogq $0xfe,%xmm7,%xmm6,%xmm4
 1f7ec13:	vpsrld $0x10,%zmm21,%zmm6
 1f7ec1a:	vpmovdb %zmm11,%xmm7
 1f7ec20:	vinserti32x4 $0x3,%xmm18,%zmm22,%zmm5{%k6}{z}
 1f7ec27:	vpmovdb %zmm6,%xmm6
 1f7ec2d:	je     1f7e477 <node_facts_window_run+0x1f27>
 1f7ec33:	vmovdqa64 -0x1ac83fd(%rip),%zmm18        # 4b6840 <abi_test_hex.digits+0xb4c0>
 1f7ec3d:	vptestmd %zmm9,%zmm9,%k1{%k2}
 1f7ec43:	add    %r9,%rdx
 1f7ec46:	vpxor  %xmm11,%xmm11,%xmm11
 1f7ec4b:	vpxor  %xmm12,%xmm12,%xmm12
 1f7ec50:	vpcmpneqd -0x19b012f(%rip){1to16},%zmm9,%k0{%k1}        # 5ceb2c <.LCPI3_38>
 1f7ec5b:	vmovdqa %xmm6,%xmm9
 1f7ec5f:	vpternlogq $0xfe,%xmm8,%xmm3,%xmm9
 1f7ec66:	kmovq  %k1,%k2
 1f7ec6b:	kmovw  %k1,%eax
 1f7ec6f:	popcnt %eax,%ecx
 1f7ec73:	vpgatherdd 0x10(%rdx,%zmm18,1),%zmm11{%k2}
 1f7ec7b:	kmovq  %k1,%k2
 1f7ec80:	vpcmpnleud -0x19b015b(%rip){1to16},%zmm11,%k3        # 5ceb30 <.LCPI3_39>
 1f7ec8b:	vpgatherdd 0x14(%rdx,%zmm18,1),%zmm12{%k2}
 1f7ec93:	add    %rcx,0x38(%rsp)
 1f7ec98:	mov    0x10(%rsp),%r10
 1f7ec9d:	vpcmpeqd %zmm10,%zmm11,%k2
 1f7eca3:	vmovdqa64 %xmm19,%xmm10
 1f7eca9:	vpternlogq $0xfe,%xmm7,%xmm9,%xmm10
 1f7ecb0:	vptestnmd %zmm12,%zmm12,%k2{%k2}
 1f7ecb6:	vptestmd %zmm12,%zmm12,%k4
 1f7ecbc:	vpternlogq $0xfe,%xmm4,%xmm2,%xmm10
 1f7ecc3:	korw   %k4,%k3,%k3
 1f7ecc7:	kandw  %k2,%k0,%k2
 1f7eccb:	knotw  %k0,%k0
 1f7eccf:	kandd  %k1,%k0,%k0
 1f7ecd4:	kandw  %k0,%k3,%k0
 1f7ecd8:	korw   %k0,%k2,%k2
 1f7ecdc:	vptestnmd %zmm13,%zmm20,%k0{%k2}
 1f7ece2:	kandw  %k0,%k1,%k0
 1f7ece6:	knotd  %k6,%k1
 1f7eceb:	kmovd  %k0,%ecx
 1f7ecef:	vptestmb %xmm10,%xmm10,%k0{%k1}
 1f7ecf5:	vptestmd %zmm5,%zmm5,%k1{%k1}
 1f7ecfb:	andn   %eax,%ecx,%eax
 1f7ed00:	popcnt %eax,%eax
 1f7ed04:	kmovw  %k0,%ecx
 1f7ed08:	popcnt %ecx,%ecx
 1f7ed0c:	kmovw  %k1,%edx
 1f7ed10:	popcnt %edx,%edx
 1f7ed14:	add    %rdx,%r10
 1f7ed17:	add    %rax,%r10
 1f7ed1a:	add    %rcx,%r10
 1f7ed1d:	mov    %r10,0x10(%rsp)
 1f7ed22:	jmp    1f7e477 <node_facts_window_run+0x1f27>
 1f7ed27:	kandw  %k0,%k7,%k0
 1f7ed2b:	mov    %rdx,0x340(%rsp)
 1f7ed33:	vmovdqa %xmm10,0x180(%rsp)
 1f7ed3c:	vmovdqu64 %zmm11,0x200(%rsp)
 1f7ed44:	vmovdqu64 %ymm19,0x300(%rsp)
 1f7ed4c:	vmovdqu64 %zmm20,0x2c0(%rsp)
 1f7ed54:	vmovdqu64 %ymm21,0x280(%rsp)
 1f7ed5c:	vmovdqu64 %zmm7,0x400(%rsp)
 1f7ed64:	vmovdqu64 %ymm18,0x480(%rsp)
 1f7ed6c:	vmovdqu64 %zmm22,0x560(%rsp)
 1f7ed77:	vmovdqu64 %ymm23,0x520(%rsp)
 1f7ed7f:	vmovdqu64 %zmm5,0x4e0(%rsp)
 1f7ed8a:	vmovdqu %ymm6,0x5e0(%rsp)
 1f7ed93:	vmovdqu64 %zmm24,0x5a0(%rsp)
 1f7ed9e:	vmovdqu64 %ymm25,0x650(%rsp)
 1f7eda9:	vmovdqu64 %zmm4,0x710(%rsp)
 1f7edb4:	vmovdqu64 %ymm26,0x460(%rsp)
 1f7edbc:	vmovdqu64 %zmm27,0x6d0(%rsp)
 1f7edc7:	vmovdqu64 %ymm28,0x440(%rsp)
 1f7edcf:	vmovdqu64 %zmm0,0x7b0(%rsp)
 1f7edda:	kmovd  %k6,0x3c0(%rsp)
 1f7ede4:	kmovw  %k7,0x380(%rsp)
 1f7eded:	kmovd  %k0,%eax
 1f7edf1:	movzwl %ax,%r14d
 1f7edf5:	jmp    1f7ef82 <node_facts_window_run+0x2a32>
 1f7edfa:	mov    0x50(%rsp),%rsi
 1f7edff:	mov    (%rbx,%r13,4),%r9d
 1f7ee03:	mov    0xc38(%rdi),%rdx
 1f7ee0a:	shl    $0x6,%rax
 1f7ee0e:	mov    %r8b,0x30(%rsp)
 1f7ee13:	mov    0x20(%r11),%rcx
 1f7ee17:	cmpb   $0x1,(%rdx,%r9,1)
 1f7ee1c:	mov    %r9,0x60(%rsp)
 1f7ee21:	movzbl 0x30(%rcx,%rax,1),%edx
 1f7ee26:	adc    $0x0,%rsi
 1f7ee2a:	and    $0x1,%edx
 1f7ee2d:	mov    %rsi,0x50(%rsp)
 1f7ee32:	mov    0xa0(%rsp),%r15
 1f7ee3a:	mov    (%r15,%r13,4),%esi
 1f7ee3e:	vzeroupper
 1f7ee41:	call   1f92730 <node_tests_window_line>
 1f7ee46:	mov    %al,0x1c0(%rsp)
 1f7ee4d:	mov    (%r15,%r13,4),%esi
 1f7ee51:	mov    0x18(%rsp),%rdi
 1f7ee56:	call   1f92880 <node_tests_window_returns>
 1f7ee5b:	mov    0x18(%rsp),%rdi
 1f7ee60:	vpbroadcastd -0x19b037a(%rip),%zmm13        # 5ceaf0 <.LCPI3_5>
 1f7ee6a:	vpbroadcastb -0x1ac81b3(%rip),%xmm14        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f7ee73:	vpbroadcastb -0x1ac81bb(%rip),%xmm15        # 4b6cc1 <abi_test_hex.digits+0xb941>
 1f7ee7c:	vpbroadcastd -0x19b038e(%rip),%zmm16        # 5ceaf8 <.LCPI3_11>
 1f7ee86:	vpbroadcastd -0x19b0390(%rip),%zmm17        # 5ceb00 <.LCPI3_13>
 1f7ee90:	vmovdqa 0x180(%rsp),%xmm10
 1f7ee99:	vmovdqu64 0x200(%rsp),%zmm11
 1f7eea1:	vmovdqu64 0x300(%rsp),%ymm19
 1f7eea9:	vmovdqu64 0x2c0(%rsp),%zmm20
 1f7eeb1:	vmovdqu64 0x280(%rsp),%ymm21
 1f7eeb9:	vmovdqu64 0x400(%rsp),%zmm7
 1f7eec1:	vmovdqu64 0x480(%rsp),%ymm18
 1f7eec9:	vmovdqu64 0x560(%rsp),%zmm22
 1f7eed4:	vmovdqu64 0x520(%rsp),%ymm23
 1f7eedc:	vmovdqu64 0x4e0(%rsp),%zmm5
 1f7eee7:	vmovdqu 0x5e0(%rsp),%ymm6
 1f7eef0:	vmovdqu64 0x5a0(%rsp),%zmm24
 1f7eefb:	vmovdqu64 0x650(%rsp),%ymm25
 1f7ef06:	vmovdqu64 0x710(%rsp),%zmm4
 1f7ef11:	vmovdqu64 0x460(%rsp),%ymm26
 1f7ef19:	vmovdqu64 0x6d0(%rsp),%zmm27
 1f7ef24:	vmovdqu64 0x440(%rsp),%ymm28
 1f7ef2c:	vmovdqu64 0x7b0(%rsp),%zmm0
 1f7ef37:	or     0x30(%rsp),%al
 1f7ef3b:	mov    0x8(%rsp),%r11
 1f7ef40:	mov    0x60(%rsp),%rdx
 1f7ef45:	mov    0x40(%rsp),%rsi
 1f7ef4a:	mov    0x120(%rsp),%r8
 1f7ef52:	mov    0x20(%rsp),%r9
 1f7ef57:	kmovd  0x3c0(%rsp),%k6
 1f7ef61:	kmovw  0x380(%rsp),%k7
 1f7ef6a:	or     0x1c0(%rsp),%al
 1f7ef71:	blsr   %r14d,%r14d
 1f7ef76:	mov    0xc38(%rdi),%rcx
 1f7ef7d:	mov    %al,(%rcx,%rdx,1)
 1f7ef80:	je     1f7efee <node_facts_window_run+0x2a9e>
 1f7ef82:	tzcnt  %r14d,%r13d
 1f7ef87:	mov    0x60(%r11),%edx
 1f7ef8b:	mov    $0x1,%r8b
 1f7ef8e:	add    %r12,%r13
 1f7ef91:	mov    %r13,%rcx
 1f7ef94:	shl    $0x6,%rcx
 1f7ef98:	mov    (%r9,%rcx,1),%eax
 1f7ef9c:	mov    0xc(%r9,%rcx,1),%ecx
 1f7efa1:	shr    $0x3,%eax
 1f7efa4:	cmp    %edx,%eax
 1f7efa6:	cmovae %edx,%eax
 1f7efa9:	test   %rcx,%rcx
 1f7efac:	je     1f7edfa <node_facts_window_run+0x28aa>
 1f7efb2:	mov    0x98(%rsp),%rdx
 1f7efba:	mov    0x50(%rsp),%rsi
 1f7efbf:	cmp    0x3b8(%rdx),%ecx
 1f7efc5:	jae    1f7edff <node_facts_window_run+0x28af>
 1f7efcb:	mov    0x98(%rsp),%rdx
 1f7efd3:	mov    0x3a8(%rdx),%rdx
 1f7efda:	cmpl   $0x0,(%rdx,%rcx,4)
 1f7efde:	setne  %r8b
 1f7efe2:	shl    $0x5,%r8b
 1f7efe6:	inc    %r8b
 1f7efe9:	jmp    1f7edff <node_facts_window_run+0x28af>
 1f7efee:	mov    0xc38(%rdi),%rax
 1f7eff5:	kmovq  %k7,%k1
 1f7effa:	vpxor  %xmm12,%xmm12,%xmm12
 1f7efff:	mov    0x28(%rsp),%r13
 1f7f004:	mov    0x340(%rsp),%rdx
 1f7f00c:	vpgatherdd (%rax,%zmm0,1),%zmm12{%k1}
 1f7f013:	jmp    1f7e622 <node_facts_window_run+0x20d2>
 1f7f018:	test   %ecx,%ecx
 1f7f01a:	je     1f7f816 <node_facts_window_run+0x32c6>
 1f7f020:	vpbroadcastd -0x19b053a(%rip),%zmm6        # 5ceaf0 <.LCPI3_5>
 1f7f02a:	vpbroadcastb -0x1ac8371(%rip),%xmm7        # 4b6cc2 <abi_test_hex.digits+0xb942>
 1f7f033:	vpbroadcastd -0x19b0545(%rip),%zmm8        # 5ceaf8 <.LCPI3_11>
 1f7f03d:	vpbroadcastd -0x19b0547(%rip),%zmm9        # 5ceb00 <.LCPI3_13>
 1f7f047:	lea    0x69454(%r13),%rax
 1f7f04e:	lea    0x422c(%r13),%r10
 1f7f055:	mov    %ecx,%r12d
 1f7f058:	xor    %r15d,%r15d
 1f7f05b:	mov    %rax,0x2c0(%rsp)
 1f7f063:	movq   $0x0,0x50(%rsp)
 1f7f06c:	movq   $0x0,0x38(%rsp)
 1f7f075:	movq   $0x0,0x10(%rsp)
 1f7f07e:	mov    %r12,0x400(%rsp)
 1f7f086:	mov    %r10,0x280(%rsp)
 1f7f08e:	jmp    1f7f0bc <node_facts_window_run+0x2b6c>
 1f7f090:	vpxor  %xmm11,%xmm11,%xmm11
 1f7f095:	mov    0xc00(%rdi),%rax
 1f7f09c:	vmovdqu %xmm11,(%rax,%r15,1)
 1f7f0a2:	mov    0xc08(%rdi),%rax
 1f7f0a9:	vmovdqu %xmm0,(%rax,%r15,1)
 1f7f0af:	add    $0x10,%r15
 1f7f0b3:	cmp    %r12,%r15
 1f7f0b6:	jae    1f7f831 <node_facts_window_run+0x32e1>
 1f7f0bc:	vpxor  %xmm0,%xmm0,%xmm0
 1f7f0c0:	cmp    %r8,%r15
 1f7f0c3:	jae    1f7f090 <node_facts_window_run+0x2b40>
 1f7f0c5:	mov    %r8d,%eax
 1f7f0c8:	sub    %r15d,%eax
 1f7f0cb:	mov    $0x10,%ecx
 1f7f0d0:	mov    $0xffffffff,%edx
 1f7f0d5:	mov    %r15,%rbp
 1f7f0d8:	cmp    $0x10,%eax
 1f7f0db:	cmovae %ecx,%eax
 1f7f0de:	mov    0x9b0(%r11),%rcx
 1f7f0e5:	shl    $0x6,%rbp
 1f7f0e9:	shlx   %eax,%edx,%eax
 1f7f0ee:	vmovdqu 0x100(%r9,%rbp,1),%ymm2
 1f7f0f8:	vmovdqu 0x180(%r9,%rbp,1),%ymm3
 1f7f102:	vmovdqu (%r9,%rbp,1),%ymm0
 1f7f108:	vmovdqu 0x80(%r9,%rbp,1),%ymm1
 1f7f112:	not    %eax
 1f7f114:	vinserti64x4 $0x1,0x140(%r9,%rbp,1),%zmm2,%zmm5
 1f7f11d:	vinserti64x4 $0x1,0x1c0(%r9,%rbp,1),%zmm3,%zmm2
 1f7f126:	vinserti64x4 $0x1,0x40(%r9,%rbp,1),%zmm0,%zmm4
 1f7f12f:	vmovdqu 0x200(%r9,%rbp,1),%ymm0
 1f7f139:	vinserti64x4 $0x1,0xc0(%r9,%rbp,1),%zmm1,%zmm12
 1f7f142:	kmovd  %eax,%k1
 1f7f146:	vinserti64x4 $0x1,0x240(%r9,%rbp,1),%zmm0,%zmm11
 1f7f14f:	vmovdqu 0x280(%r9,%rbp,1),%ymm0
 1f7f159:	mov    0xc38(%rdi),%rax
 1f7f160:	vinserti64x4 $0x1,0x2c0(%r9,%rbp,1),%zmm0,%zmm14
 1f7f169:	vmovdqu 0x300(%r9,%rbp,1),%ymm0
 1f7f173:	vmovdqu8 (%rcx,%r15,1),%xmm10{%k1}{z}
 1f7f17a:	mov    0x2c0(%rsp),%rcx
 1f7f182:	vinserti64x4 $0x1,0x340(%r9,%rbp,1),%zmm0,%zmm13
 1f7f18b:	vmovdqu 0x380(%r9,%rbp,1),%ymm0
 1f7f195:	vinserti64x4 $0x1,0x3c0(%r9,%rbp,1),%zmm0,%zmm15
 1f7f19e:	vmovdqu8 (%rcx,%r15,1),%xmm3{%k1}{z}
 1f7f1a5:	vptestmb %xmm10,%xmm10,%k2
 1f7f1ab:	vpxor  %xmm0,%xmm0,%xmm0
 1f7f1af:	vpcmpeqb %xmm7,%xmm3,%k3{%k2}
 1f7f1b5:	vmovdqu32 (%rbx,%r15,4),%zmm1{%k3}{z}
 1f7f1bc:	kmovq  %k3,%k1
 1f7f1c1:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f7f1c8:	vptestnmd %zmm8,%zmm0,%k0
 1f7f1ce:	ktestw %k0,%k3
 1f7f1d2:	jne    1f7f651 <node_facts_window_run+0x3101>
 1f7f1d8:	vmovdqa64 -0x1ac8a62(%rip),%zmm1        # 4b6780 <abi_test_hex.digits+0xb400>
 1f7f1e2:	kmovd  %k2,%edx
 1f7f1e6:	vpermt2d %zmm12,%zmm1,%zmm4
 1f7f1ec:	vpermt2d %zmm2,%zmm1,%zmm5
 1f7f1f2:	vpermt2d %zmm14,%zmm1,%zmm11
 1f7f1f8:	vpermt2d %zmm15,%zmm1,%zmm13
 1f7f1fe:	vshufi64x2 $0x44,%zmm13,%zmm11,%zmm2
 1f7f205:	vshufi64x2 $0x44,%zmm5,%zmm4,%zmm1
 1f7f20c:	vshufi64x2 $0xee,%zmm5,%zmm4,%zmm14
 1f7f213:	vshufi64x2 $0xee,%zmm13,%zmm11,%zmm13
 1f7f21a:	vshufi32x4 $0x88,%zmm2,%zmm1,%zmm4{%k2}{z}
 1f7f221:	vshufi32x4 $0xdd,%zmm2,%zmm1,%zmm5{%k2}{z}
 1f7f228:	vshufi32x4 $0xdd,%zmm13,%zmm14,%zmm12{%k2}{z}
 1f7f22f:	vpsrld $0x19,%zmm4,%zmm1
 1f7f236:	vpandd -0x19b0754(%rip){1to16},%zmm1,%zmm1        # 5ceaec <.LCPI3_4>
 1f7f240:	vpsrld $0x18,%zmm4,%zmm2
 1f7f247:	vpternlogd $0xec,%zmm6,%zmm1,%zmm2
 1f7f24e:	vpandd -0x19b0720(%rip){1to16},%zmm4,%zmm1        # 5ceb38 <.LCPI3_72>
 1f7f258:	vpmovdb %zmm2,%xmm11
 1f7f25e:	vpbroadcastb -0x1ac85a7(%rip),%xmm2        # 4b6cc0 <abi_test_hex.digits+0xb940>
 1f7f267:	vpcmpeqd -0x19b077d(%rip){1to16},%zmm1,%k1{%k2}        # 5ceaf4 <.LCPI3_7>
 1f7f271:	vpor   %xmm2,%xmm11,%xmm1
 1f7f275:	vpcmpeqb %xmm2,%xmm3,%k0{%k2}
 1f7f27b:	kmovd  %k0,%eax
 1f7f27f:	vmovdqu8 %xmm1,%xmm11{%k1}
 1f7f285:	vptestmd %zmm9,%zmm0,%k1
 1f7f28b:	korw   %k1,%k0,%k5
 1f7f28f:	vptestmd -0x19b079d(%rip){1to16},%zmm0,%k0        # 5ceafc <.LCPI3_12>
 1f7f299:	kmovd  %k0,%r14d
 1f7f29d:	test   %ax,%ax
 1f7f2a0:	je     1f7f3d1 <node_facts_window_run+0x2e81>
 1f7f2a6:	lea    (%r10,%r15,4),%r12
 1f7f2aa:	movzwl %r14w,%r14d
 1f7f2ae:	movzwl %ax,%r13d
 1f7f2b2:	vmovdqu64 %zmm13,0x300(%rsp)
 1f7f2ba:	vmovdqu64 %zmm14,0x340(%rsp)
 1f7f2c2:	vmovdqu64 %zmm5,0x380(%rsp)
 1f7f2ca:	vmovdqu64 %zmm4,0x3c0(%rsp)
 1f7f2d2:	kmovw  %k5,0x200(%rsp)
 1f7f2db:	vmovdqu64 %zmm12,0x180(%rsp)
 1f7f2e3:	mov    %edx,0x30(%rsp)
 1f7f2e7:	vmovdqa %xmm11,0x1c0(%rsp)
 1f7f2f0:	vmovdqa %xmm10,0x60(%rsp)
 1f7f2f6:	cs nopw 0x0(%rax,%rax,1)
 1f7f300:	xor    %ebx,%ebx
 1f7f302:	tzcnt  %r13d,%ebx
 1f7f307:	xor    %edx,%edx
 1f7f309:	mov    (%r12,%rbx,4),%esi
 1f7f30d:	vzeroupper
 1f7f310:	call   1f92730 <node_tests_window_line>
 1f7f315:	mov    0x18(%rsp),%rdi
 1f7f31a:	mov    $0x1,%edx
 1f7f31f:	xor    %ecx,%ecx
 1f7f321:	test   $0x2,%al
 1f7f323:	shlx   %ebx,%edx,%eax
 1f7f328:	cmove  %ecx,%eax
 1f7f32b:	or     %eax,%r14d
 1f7f32e:	blsr   %r13d,%r13d
 1f7f333:	jne    1f7f300 <node_facts_window_run+0x2db0>
 1f7f335:	vpbroadcastd -0x19b084f(%rip),%zmm6        # 5ceaf0 <.LCPI3_5>
 1f7f33f:	vpbroadcastb -0x1ac8686(%rip),%xmm7        # 4b6cc2 <abi_test_hex.digits+0xb942>
 1f7f348:	vpbroadcastd -0x19b085a(%rip),%zmm8        # 5ceaf8 <.LCPI3_11>
 1f7f352:	vpbroadcastd -0x19b085c(%rip),%zmm9        # 5ceb00 <.LCPI3_13>
 1f7f35c:	vmovdqa 0x60(%rsp),%xmm10
 1f7f362:	vmovdqa 0x1c0(%rsp),%xmm11
 1f7f36b:	vmovdqu64 0x180(%rsp),%zmm12
 1f7f373:	vmovdqu64 0x3c0(%rsp),%zmm4
 1f7f37b:	vmovdqu64 0x380(%rsp),%zmm5
 1f7f383:	vmovdqu64 0x340(%rsp),%zmm14
 1f7f38b:	vmovdqu64 0x300(%rsp),%zmm13
 1f7f393:	mov    0x8(%rsp),%r11
 1f7f398:	mov    0x28(%rsp),%r13
 1f7f39d:	mov    0x40(%rsp),%rsi
 1f7f3a2:	mov    0x48(%rsp),%rbx
 1f7f3a7:	mov    0x120(%rsp),%r8
 1f7f3af:	mov    0x20(%rsp),%r9
 1f7f3b4:	mov    0x280(%rsp),%r10
 1f7f3bc:	mov    0x400(%rsp),%r12
 1f7f3c4:	mov    0x30(%rsp),%edx
 1f7f3c8:	kmovw  0x200(%rsp),%k5
 1f7f3d1:	vpsrld $0x2,%zmm12,%zmm2
 1f7f3d8:	vpandd -0x19b08de(%rip){1to16},%zmm2,%zmm2        # 5ceb04 <.LCPI3_14>
 1f7f3e2:	vptestmd -0x19b08e0(%rip){1to16},%zmm12,%k2        # 5ceb0c <.LCPI3_16>
 1f7f3ec:	vshufi64x2 $0x88,%zmm13,%zmm14,%zmm0
 1f7f3f3:	vptestnmb %xmm10,%xmm10,%k0
 1f7f3f9:	vpsrld $0x1a,%zmm4,%zmm1
 1f7f400:	vpandd -0x19b08ce(%rip){1to16},%zmm4,%zmm4        # 5ceb3c <.LCPI3_75>
 1f7f40a:	kmovd  %r14d,%k3
 1f7f40f:	vpcmpneqd -0x19b0912(%rip){1to16},%zmm2,%k1        # 5ceb08 <.LCPI3_15>
 1f7f41a:	vpaddd -0x19b0910(%rip){1to16},%zmm4,%zmm4        # 5ceb14 <.LCPI3_20>
 1f7f424:	korw   %k1,%k2,%k1
 1f7f428:	vptestnmd %zmm0,%zmm0,%k2
 1f7f42e:	vpandd %zmm9,%zmm5,%zmm0
 1f7f434:	korw   %k2,%k0,%k0
 1f7f438:	vptestmd -0x19b0932(%rip){1to16},%zmm5,%k2        # 5ceb10 <.LCPI3_17>
 1f7f442:	vpbroadcastd -0x19b0934(%rip),%zmm5        # 5ceb18 <.LCPI3_21>
 1f7f44c:	korw   %k1,%k0,%k1
 1f7f450:	vptestnmd %zmm0,%zmm0,%k0
 1f7f456:	kmovd  %k0,%eax
 1f7f45a:	vptestmd %zmm2,%zmm2,%k1{%k1}
 1f7f460:	vmovdqu8 -0x19b9bca(%rip),%xmm3{%k1}{z}        # 5c58a0 <.LCPI3_8>
 1f7f46a:	vpcmpeqd %zmm5,%zmm1,%k4
 1f7f470:	vpcmpltud %zmm5,%zmm4,%k0
 1f7f477:	korw   %k2,%k3,%k1
 1f7f47b:	vpslld $0x1f,%zmm4,%zmm1
 1f7f482:	vpbroadcastb -0x1ac87c6(%rip),%xmm4        # 4b6cc5 <abi_test_hex.digits+0xb945>
 1f7f48b:	vptestmb %xmm10,%xmm10,%k4{%k4}
 1f7f491:	kmovd  %k0,%ecx
 1f7f495:	and    %eax,%ecx
 1f7f497:	mov    %edx,%eax
 1f7f499:	and    %ecx,%eax
 1f7f49b:	vmovdqu8 -0x19b9bc5(%rip),%xmm5{%k4}{z}        # 5c58e0 <.LCPI3_24>
 1f7f4a5:	kmovd  %eax,%k3
 1f7f4a9:	vpcmpeqd %zmm8,%zmm2,%k2{%k3}
 1f7f4af:	vpxor  %xmm2,%xmm2,%xmm2
 1f7f4b3:	knotw  %k2,%k0
 1f7f4b7:	kmovd  %k0,%ecx
 1f7f4bb:	and    %eax,%ecx
 1f7f4bd:	vmovdqu8 -0x19b9bd7(%rip),%xmm5{%k3}        # 5c58f0 <.LCPI3_25>
 1f7f4c7:	kmovd  %ecx,%k3
 1f7f4cb:	vpcmpgtd %zmm1,%zmm2,%k3{%k3}
 1f7f4d1:	vpsrld $0x10,%zmm12,%zmm1
 1f7f4d8:	vpternlogd $0xff,%zmm2,%zmm2,%zmm2
 1f7f4df:	vpaddd %zmm2,%zmm1,%zmm2
 1f7f4e5:	vmovdqu8 -0x19b9bef(%rip),%xmm5{%k3}        # 5c5900 <.LCPI3_26>
 1f7f4ef:	vptestnmd %zmm2,%zmm2,%k3
 1f7f4f5:	vpblendmb -0x19b9bdf(%rip),%xmm4,%xmm4{%k3}        # 5c5920 <.LCPI3_28>
 1f7f4ff:	vpcmpnleud -0x19b09ee(%rip){1to16},%zmm2,%k3        # 5ceb1c <.LCPI3_22>
 1f7f50a:	cmpb   $0x0,0xc80(%rdi)
 1f7f511:	vmovdqu8 -0x19b9beb(%rip),%xmm4{%k3}        # 5c5930 <.LCPI3_29>
 1f7f51b:	vpcmpnleud -0x19b0a06(%rip){1to16},%zmm2,%k3        # 5ceb20 <.LCPI3_23>
 1f7f526:	vmovdqu8 -0x19b9bf0(%rip),%xmm4{%k3}        # 5c5940 <.LCPI3_30>
 1f7f530:	vptestmd %zmm0,%zmm0,%k3
 1f7f536:	vpor   %xmm7,%xmm3,%xmm0
 1f7f53a:	vmovdqu8 %xmm0,%xmm3{%k3}
 1f7f540:	vmovdqu8 %xmm4,%xmm5{%k2}
 1f7f546:	vpor   %xmm5,%xmm3,%xmm0
 1f7f54a:	vpord  -0x19b0a14(%rip){1to4},%xmm0,%xmm3        # 5ceb40 <.LCPI3_78>
 1f7f554:	vmovdqu8 %xmm3,%xmm0{%k5}
 1f7f55a:	vpord  -0x19b0a1c(%rip){1to4},%xmm0,%xmm3        # 5ceb48 <.LCPI3_82>
 1f7f564:	vmovdqu8 %xmm3,%xmm0{%k1}
 1f7f56a:	vpsrld $0xc,%zmm12,%zmm3
 1f7f571:	vpmovdb %zmm3,%xmm3
 1f7f577:	vpternlogd $0xf8,-0x19b0a36(%rip){1to4},%xmm3,%xmm11        # 5ceb4c <.LCPI3_83>
 1f7f582:	je     1f7f095 <node_facts_window_run+0x2b45>
 1f7f588:	vmovdqa64 -0x1ac8d52(%rip),%zmm5        # 4b6840 <abi_test_hex.digits+0xb4c0>
 1f7f592:	vptestmd %zmm1,%zmm1,%k1{%k2}
 1f7f598:	add    %r9,%rbp
 1f7f59b:	vpxor  %xmm3,%xmm3,%xmm3
 1f7f59f:	vpxor  %xmm4,%xmm4,%xmm4
 1f7f5a3:	vpcmpneqd -0x19b0a82(%rip){1to16},%zmm1,%k0{%k1}        # 5ceb2c <.LCPI3_38>
 1f7f5ae:	vpor   %xmm0,%xmm11,%xmm1
 1f7f5b2:	kmovq  %k1,%k2
 1f7f5b7:	kmovw  %k1,%eax
 1f7f5bb:	popcnt %eax,%ecx
 1f7f5bf:	vpgatherdd 0x10(%rbp,%zmm5,1),%zmm3{%k2}
 1f7f5c7:	kmovq  %k1,%k2
 1f7f5cc:	vpcmpnleud -0x19b0aa7(%rip){1to16},%zmm3,%k3        # 5ceb30 <.LCPI3_39>
 1f7f5d7:	vpgatherdd 0x14(%rbp,%zmm5,1),%zmm4{%k2}
 1f7f5df:	add    %rcx,0x38(%rsp)
 1f7f5e4:	mov    0x10(%rsp),%r14
 1f7f5e9:	vpcmpeqd %zmm2,%zmm3,%k2
 1f7f5ef:	vptestnmd %zmm4,%zmm4,%k2{%k2}
 1f7f5f5:	vptestmd %zmm4,%zmm4,%k4
 1f7f5fb:	korw   %k4,%k3,%k3
 1f7f5ff:	kandw  %k2,%k0,%k2
 1f7f603:	knotw  %k0,%k0
 1f7f607:	kandd  %k1,%k0,%k0
 1f7f60c:	kandw  %k0,%k3,%k0
 1f7f610:	korw   %k0,%k2,%k2
 1f7f614:	vptestnmd %zmm6,%zmm12,%k0{%k2}
 1f7f61a:	kandw  %k0,%k1,%k0
 1f7f61e:	kmovd  %k0,%ecx
 1f7f622:	vptestmb %xmm1,%xmm1,%k0
 1f7f628:	andn   %eax,%ecx,%eax
 1f7f62d:	kmovd  %k0,%ecx
 1f7f631:	andn   %ecx,%edx,%ecx
 1f7f636:	popcnt %eax,%eax
 1f7f63a:	movzwl %cx,%ecx
 1f7f63d:	add    %rax,%r14
 1f7f640:	popcnt %ecx,%ecx
 1f7f644:	add    %rcx,%r14
 1f7f647:	mov    %r14,0x10(%rsp)
 1f7f64c:	jmp    1f7f095 <node_facts_window_run+0x2b45>
 1f7f651:	vmovdqu64 %zmm1,0x4e0(%rsp)
 1f7f65c:	vmovdqu64 %zmm15,0x560(%rsp)
 1f7f667:	vmovdqu64 %zmm14,0x480(%rsp)
 1f7f66f:	vmovdqu64 %zmm13,0x300(%rsp)
 1f7f677:	vmovdqu64 %zmm2,0x340(%rsp)
 1f7f67f:	vmovdqu64 %zmm12,0x380(%rsp)
 1f7f687:	vmovdqu64 %zmm11,0x3c0(%rsp)
 1f7f68f:	vmovdqa %xmm3,0x200(%rsp)
 1f7f698:	vmovdqu64 %zmm5,0x180(%rsp)
 1f7f6a0:	kmovw  %k2,0x30(%rsp)
 1f7f6a6:	vmovdqu64 %zmm4,0x1c0(%rsp)
 1f7f6ae:	vmovdqa %xmm10,0x60(%rsp)
 1f7f6b4:	kmovw  %k3,0x520(%rsp)
 1f7f6bd:	kandw  %k0,%k3,%k0
 1f7f6c1:	mov    0x50(%rsp),%r12
 1f7f6c6:	kmovd  %k0,%eax
 1f7f6ca:	movzwl %ax,%r14d
 1f7f6ce:	mov    0x280(%rsp),%rcx
 1f7f6d6:	xor    %eax,%eax
 1f7f6d8:	tzcnt  %r14d,%eax
 1f7f6dd:	mov    0x60(%r11),%edx
 1f7f6e1:	add    %r15,%rax
 1f7f6e4:	mov    (%rbx,%rax,4),%r13d
 1f7f6e8:	mov    (%rcx,%rax,4),%esi
 1f7f6eb:	shl    $0x6,%rax
 1f7f6ef:	mov    0x20(%r11),%rcx
 1f7f6f3:	mov    (%r9,%rax,1),%eax
 1f7f6f7:	shr    $0x3,%eax
 1f7f6fa:	cmp    %edx,%eax
 1f7f6fc:	cmovae %edx,%eax
 1f7f6ff:	shl    $0x6,%rax
 1f7f703:	mov    0x30(%rcx,%rax,1),%edx
 1f7f707:	mov    0xc38(%rdi),%rax
 1f7f70e:	cmpb   $0x1,(%rax,%r13,1)
 1f7f713:	adc    $0x0,%r12
 1f7f717:	and    $0x1,%edx
 1f7f71a:	vzeroupper
 1f7f71d:	call   1f92730 <node_tests_window_line>
 1f7f722:	mov    0x18(%rsp),%rdi
 1f7f727:	mov    0x20(%rsp),%r9
 1f7f72c:	mov    0x8(%rsp),%r11
 1f7f731:	or     $0x1,%al
 1f7f733:	blsr   %r14d,%r14d
 1f7f738:	mov    0xc38(%rdi),%rcx
 1f7f73f:	mov    %al,(%rcx,%r13,1)
 1f7f743:	jne    1f7f6ce <node_facts_window_run+0x317e>
 1f7f745:	mov    %r12,0x50(%rsp)
 1f7f74a:	mov    0xc38(%rdi),%rax
 1f7f751:	vpbroadcastd -0x19b0c6b(%rip),%zmm6        # 5ceaf0 <.LCPI3_5>
 1f7f75b:	vpbroadcastb -0x1ac8aa2(%rip),%xmm7        # 4b6cc2 <abi_test_hex.digits+0xb942>
 1f7f764:	vpbroadcastd -0x19b0c76(%rip),%zmm8        # 5ceaf8 <.LCPI3_11>
 1f7f76e:	vpbroadcastd -0x19b0c78(%rip),%zmm9        # 5ceb00 <.LCPI3_13>
 1f7f778:	vpxor  %xmm0,%xmm0,%xmm0
 1f7f77c:	vmovdqu64 0x4e0(%rsp),%zmm1
 1f7f787:	kmovw  0x520(%rsp),%k1
 1f7f790:	vmovdqa 0x60(%rsp),%xmm10
 1f7f796:	vmovdqu64 0x1c0(%rsp),%zmm4
 1f7f79e:	vmovdqu64 0x180(%rsp),%zmm5
 1f7f7a6:	vmovdqa 0x200(%rsp),%xmm3
 1f7f7af:	vmovdqu64 0x3c0(%rsp),%zmm11
 1f7f7b7:	vmovdqu64 0x380(%rsp),%zmm12
 1f7f7bf:	vmovdqu64 0x340(%rsp),%zmm2
 1f7f7c7:	vmovdqu64 0x300(%rsp),%zmm13
 1f7f7cf:	vmovdqu64 0x480(%rsp),%zmm14
 1f7f7d7:	vmovdqu64 0x560(%rsp),%zmm15
 1f7f7e2:	mov    0x28(%rsp),%r13
 1f7f7e7:	mov    0x40(%rsp),%rsi
 1f7f7ec:	mov    0x120(%rsp),%r8
 1f7f7f4:	mov    0x280(%rsp),%r10
 1f7f7fc:	mov    0x400(%rsp),%r12
 1f7f804:	kmovw  0x30(%rsp),%k2
 1f7f80a:	vpgatherdd (%rax,%zmm1,1),%zmm0{%k1}
 1f7f811:	jmp    1f7f1d8 <node_facts_window_run+0x2c88>
 1f7f816:	movq   $0x0,0x50(%rsp)
 1f7f81f:	movq   $0x0,0x38(%rsp)
 1f7f828:	movq   $0x0,0x10(%rsp)
 1f7f831:	mov    0x50(%rsp),%rax
 1f7f836:	mov    0x38(%rsp),%rcx
 1f7f83b:	add    %rax,0xa68(%rsi)
 1f7f842:	mov    0xbc0(%rdi),%rax
 1f7f849:	add    %rcx,0x848(%rax)
 1f7f850:	mov    0x10(%rsp),%rcx
 1f7f855:	mov    0xbc0(%rdi),%rax
 1f7f85c:	add    %rcx,0x850(%rax)
 1f7f863:	rdtsc
 1f7f865:	mov    0x8(%r13),%esi
 1f7f869:	cmpq   $0x0,0xc18(%r11)
 1f7f871:	mov    %rax,0x710(%rsp)
 1f7f879:	mov    %rdx,0x460(%rsp)
 1f7f881:	je     1f7ffb4 <node_facts_window_run+0x3a64>
 1f7f887:	cmpb   $0x1,0xd50(%r11)
 1f7f88f:	jne    1f7ffb4 <node_facts_window_run+0x3a64>
 1f7f895:	mov    0xbc0(%rdi),%rcx
 1f7f89c:	cmpq   $0x0,0x1a0(%rcx)
 1f7f8a4:	sete   %cl
 1f7f8a7:	test   %rsi,%rsi
 1f7f8aa:	je     1f8062f <node_facts_window_run+0x40df>
 1f7f8b0:	vpbroadcastb %ecx,%zmm1
 1f7f8b6:	vgf2p8affineqb $0x0,-0x19b37a1(%rip){1to8},%zmm1,%zmm1        # 5cc120 <.LCPI3_84>
 1f7f8c1:	vmovdqu64 0x380(%rdi),%zmm0
 1f7f8c8:	vbroadcasti32x4 -0x19b9f12(%rip),%zmm2        # 5c59c0 <.LCPI3_85>
 1f7f8d2:	vpbroadcastq -0x19b380c(%rip),%zmm3        # 5cc0d0 <.LCPI3_42>
 1f7f8dc:	vpbroadcastq -0x19b380e(%rip),%zmm4        # 5cc0d8 <.LCPI3_43>
 1f7f8e6:	vmovdqa64 -0x1ac8ff0(%rip),%zmm6        # 4b6900 <abi_test_hex.digits+0xb580>
 1f7f8f0:	vbroadcasti32x4 -0x19b9f2a(%rip),%zmm7        # 5c59d0 <.LCPI3_86>
 1f7f8fa:	vbroadcasti32x4 -0x19b9f24(%rip),%zmm16        # 5c59e0 <.LCPI3_87>
 1f7f904:	vbroadcasti32x4 -0x19b9f1e(%rip),%zmm17        # 5c59f0 <.LCPI3_88>
 1f7f90e:	vbroadcasti32x4 -0x19ba048(%rip),%zmm21        # 5c58d0 <.LCPI3_18>
 1f7f918:	movzbl 0x5c0(%rdi),%r9d
 1f7f920:	mov    0xd58(%r11),%rcx
 1f7f927:	mov    0xd70(%r11),%r11
 1f7f92e:	mov    %rsi,%rax
 1f7f931:	mov    %rdi,%r10
 1f7f934:	xor    %ebx,%ebx
 1f7f936:	vpxord %xmm25,%xmm25,%xmm25
 1f7f93c:	vpxord %xmm26,%xmm26,%xmm26
 1f7f942:	vpxor  %xmm10,%xmm10,%xmm10
 1f7f947:	vpxord %xmm30,%xmm30,%xmm30
 1f7f94d:	vpxord %xmm22,%xmm22,%xmm22
 1f7f953:	xor    %r8d,%r8d
 1f7f956:	xor    %edx,%edx
 1f7f958:	xor    %esi,%esi
 1f7f95a:	neg    %r9
 1f7f95d:	mov    %rcx,0x10(%rsp)
 1f7f962:	xor    %ecx,%ecx
 1f7f964:	movq   $0x0,0x20(%rsp)
 1f7f96d:	nopl   (%rax)
 1f7f970:	vmovdqu64 0x2c(%r13,%rbx,1),%zmm8
 1f7f97b:	mov    0xc00(%r10),%rdi
 1f7f982:	vmovdqu64 0x300(%r10),%zmm14
 1f7f989:	vmovdqu64 0x80(%r10),%zmm5
 1f7f990:	vmovdqu64 0x180(%r10),%zmm13
 1f7f997:	vmovdqu64 0x200(%r10),%zmm28
 1f7f99e:	vmovdqu64 0x280(%r10),%zmm18
 1f7f9a5:	vmovdqu64 0x440(%r10),%zmm23
 1f7f9ac:	vmovdqu64 0x4c0(%r10),%zmm31
 1f7f9b3:	vmovdqa64 %zmm22,%zmm29
 1f7f9b9:	vmovdqa64 %zmm25,%zmm22
 1f7f9bf:	vmovdqu64 0x3c0(%r10),%zmm25
 1f7f9c6:	vmovdqa64 %zmm26,%zmm15
 1f7f9cc:	vmovdqu64 0x100(%r10),%zmm26
 1f7f9d3:	vpermt2b 0x340(%r10),%zmm8,%zmm14
 1f7f9da:	vpermt2b 0xc0(%r10),%zmm8,%zmm5
 1f7f9e1:	vpermt2b 0x140(%r10),%zmm8,%zmm26
 1f7f9e8:	vpermt2b 0x1c0(%r10),%zmm8,%zmm13
 1f7f9ef:	vpermt2b 0x240(%r10),%zmm8,%zmm28
 1f7f9f6:	vpermt2b 0x2c0(%r10),%zmm8,%zmm18
 1f7f9fd:	vpermt2b 0x400(%r10),%zmm8,%zmm25
 1f7fa04:	vpermt2b 0x480(%r10),%zmm8,%zmm23
 1f7fa0b:	vpermt2b 0x500(%r10),%zmm8,%zmm31
 1f7fa12:	vpandq %zmm2,%zmm8,%zmm11
 1f7fa18:	vmovdqu64 (%rdi,%rbx,1),%zmm8
 1f7fa1f:	mov    0xc08(%r10),%rdi
 1f7fa26:	vmovdqu64 (%rdi,%rbx,1),%zmm27
 1f7fa2d:	mov    0xc10(%r10),%rdi
 1f7fa34:	vpsrlw $0x2,%zmm8,%zmm19
 1f7fa3b:	vpsrlw $0x3,%zmm8,%zmm12
 1f7fa42:	vpternlogq $0xf8,%zmm3,%zmm27,%zmm26
 1f7fa49:	vpternlogq $0xf8,%zmm4,%zmm19,%zmm26
 1f7fa50:	vpternlogq $0xf8,-0x19b397b(%rip){1to8},%zmm12,%zmm26        # 5cc0e0 <.LCPI3_44>
 1f7fa5b:	vmovdqu64 %zmm26,(%rdi,%rbx,1)
 1f7fa62:	vmovdqu64 0x6b554(%r13,%rbx,2),%zmm12
 1f7fa6d:	vmovdqu64 0x6b594(%r13,%rbx,2),%zmm20
 1f7fa78:	vmovdqu64 0x6d614(%r13,%rbx,2),%zmm24
 1f7fa83:	vmovdqu64 0x6d5d4(%r13,%rbx,2),%zmm9
 1f7fa8e:	vpmovuswb %zmm12,%ymm12
 1f7fa94:	vpmovuswb %zmm20,%ymm20
 1f7fa9a:	vpmovuswb %zmm24,%ymm24
 1f7faa0:	vinserti64x4 $0x1,%ymm20,%zmm12,%zmm12
 1f7faa7:	vpmovuswb %zmm9,%ymm20
 1f7faad:	vmovdqa64 %zmm15,%zmm9
 1f7fab3:	vptestmb %zmm12,%zmm12,%k1
 1f7fab9:	vpcmpnltub %zmm12,%zmm6,%k0
 1f7fac0:	vpcmpltub %zmm12,%zmm6,%k3{%k1}
 1f7fac7:	vpsubb %zmm12,%zmm6,%zmm12
 1f7facd:	kmovq  %k0,%r12
 1f7fad2:	kmovq  %k1,%rdi
 1f7fad7:	vpermt2b %zmm26,%zmm12,%zmm9
 1f7fadd:	and    %rdi,%r12
 1f7fae0:	mov    0xc18(%r10),%rdi
 1f7fae7:	kmovq  %r12,%k1
 1f7faec:	vinserti64x4 $0x1,%ymm24,%zmm20,%zmm24
 1f7faf3:	vpermt2b %zmm25,%zmm12,%zmm22{%k1}{z}
 1f7faf9:	knotq  %k1,%k5
 1f7fafe:	vptestmb %zmm24,%zmm24,%k2
 1f7fb04:	vpsubb %zmm24,%zmm6,%zmm20
 1f7fb0a:	vpcmpltub %zmm24,%zmm6,%k0{%k2}
 1f7fb11:	vpcmpnltub %zmm24,%zmm6,%k2{%k2}
 1f7fb18:	vpermt2b %zmm26,%zmm20,%zmm15{%k2}{z}
 1f7fb1e:	vptestmb %zmm23,%zmm22,%k4
 1f7fb24:	kmovq  %k4,%r15
 1f7fb29:	vporq  %zmm9,%zmm15,%zmm9
 1f7fb2f:	vmovdqu8 %zmm9,%zmm15{%k1}
 1f7fb35:	vmovdqu64 %zmm15,(%rdi,%rbx,1)
 1f7fb3c:	mov    0x10(%rsp),%rdi
 1f7fb41:	vpandq (%rdi,%rbx,1),%zmm1,%zmm22
 1f7fb48:	mov    %rbx,%rdi
 1f7fb4b:	shr    $0x3,%rdi
 1f7fb4f:	kortestq %k3,%k0
 1f7fb54:	vpermt2b %zmm22,%zmm12,%zmm29
 1f7fb5a:	vptestnmb %zmm29,%zmm29,%k4
 1f7fb60:	korq   %k4,%k5,%k4
 1f7fb65:	vpcmpeqb %zmm7,%zmm11,%k4{%k4}
 1f7fb6b:	kmovq  %k4,(%r11,%rdi,1)
 1f7fb71:	jne    1f7fe14 <node_facts_window_run+0x38c4>
 1f7fb77:	vmovdqa64 %zmm10,%zmm9
 1f7fb7d:	vpermi2b %zmm27,%zmm10,%zmm20{%k2}{z}
 1f7fb83:	vpermt2b %zmm27,%zmm12,%zmm9{%k1}{z}
 1f7fb89:	vpandq %zmm18,%zmm15,%zmm24
 1f7fb8f:	vpcmpeqb -0x1ac9219(%rip),%zmm24,%k2        # 4b6980 <abi_test_hex.digits+0xb600>
 1f7fb99:	vpternlogq $0xe0,%zmm2,%zmm27,%zmm14
 1f7fba0:	vpsrlw $0x2,%zmm5,%zmm18
 1f7fba7:	vpandq %zmm13,%zmm8,%zmm13
 1f7fbad:	mov    0x18(%rsp),%r10
 1f7fbb2:	vpcmpeqb %zmm7,%zmm11,%k7
 1f7fbb8:	vpaddw %zmm13,%zmm13,%zmm13
 1f7fbbe:	vpsrlw $0x3,%zmm9,%zmm10
 1f7fbc5:	vpternlogq $0xe4,-0x19b3ac0(%rip){1to8},%zmm20,%zmm10        # 5cc110 <.LCPI3_52>
 1f7fbd0:	mov    0xc20(%r10),%rdi
 1f7fbd7:	vptestnmb %zmm28,%zmm28,%k2{%k2}
 1f7fbdd:	vpermb %zmm0,%zmm10,%zmm23
 1f7fbe3:	vmovdqa64 %zmm27,%zmm10
 1f7fbe9:	vptestmb %zmm23,%zmm14,%k0{%k2}
 1f7fbef:	vpandq %zmm4,%zmm18,%zmm14
 1f7fbf5:	vpaddw %zmm8,%zmm8,%zmm18
 1f7fbfb:	vptestmb %zmm21,%zmm5,%k2
 1f7fc01:	vpternlogq $0xf8,%zmm3,%zmm5,%zmm14
 1f7fc08:	vpternlogq $0xf8,-0x19b3b2b(%rip){1to8},%zmm18,%zmm14        # 5cc0e8 <.LCPI3_47>
 1f7fc13:	vpsllw $0x4,%zmm27,%zmm18
 1f7fc1a:	vpsllw $0x7,%zmm8,%zmm5
 1f7fc21:	vpternlogq $0xf8,-0x19b3b3c(%rip){1to8},%zmm19,%zmm14        # 5cc0f0 <.LCPI3_48>
 1f7fc2c:	vpsllw $0x3,%zmm27,%zmm19
 1f7fc33:	vpmovb2m %zmm5,%k3
 1f7fc39:	vpternlogq $0xf8,-0x19b3b4c(%rip){1to8},%zmm13,%zmm14        # 5cc0f8 <.LCPI3_49>
 1f7fc44:	vpandq %zmm16,%zmm9,%zmm13
 1f7fc4a:	vpandd -0x19b1114(%rip){1to16},%zmm9,%zmm9        # 5ceb40 <.LCPI3_78>
 1f7fc54:	vpternlogq $0xf8,-0x19b3b5f(%rip){1to8},%zmm19,%zmm14        # 5cc100 <.LCPI3_50>
 1f7fc5f:	vpcmpeqb %zmm17,%zmm13,%k4
 1f7fc65:	vpandq %zmm16,%zmm20,%zmm13
 1f7fc6b:	vpternlogq $0xf8,-0x19b3b6e(%rip){1to8},%zmm18,%zmm14        # 5cc108 <.LCPI3_51>
 1f7fc76:	vpcmpeqb %zmm17,%zmm13,%k5
 1f7fc7c:	vpandq %zmm21,%zmm8,%zmm13
 1f7fc82:	korq   %k5,%k4,%k4
 1f7fc87:	vpcmpeqb -0x1ac9251(%rip),%zmm11,%k5{%k4}        # 4b6a40 <abi_test_hex.digits+0xb6c0>
 1f7fc91:	vpcmpeqb -0x1ac915b(%rip),%zmm11,%k4        # 4b6b40 <abi_test_hex.digits+0xb7c0>
 1f7fc9b:	vpternlogq $0xfe,%zmm9,%zmm24,%zmm13
 1f7fca2:	vptestnmb %zmm13,%zmm13,%k6
 1f7fca8:	vmovdqu64 %zmm14,(%rdi,%rbx,1)
 1f7fcaf:	kmovq  %k7,%rdi
 1f7fcb4:	vptestmb -0x1ac923e(%rip),%zmm8,%k7        # 4b6a80 <abi_test_hex.digits+0xb700>
 1f7fcbe:	and    %r9,%rdi
 1f7fcc1:	knotq  %k5,%k5
 1f7fcc6:	kmovq  %k5,%r13
 1f7fccb:	kmovq  %k7,%r14
 1f7fcd0:	vptestmb %zmm24,%zmm24,%k7
 1f7fcd6:	and    %r14,%rdi
 1f7fcd9:	kmovq  %k6,%r14
 1f7fcde:	vptestmb -0x1ac9168(%rip),%zmm8,%k6{%k7}        # 4b6b80 <abi_test_hex.digits+0xb800>
 1f7fce8:	vpbroadcastw %ebx,%zmm8
 1f7fcee:	vporq  -0x1ac9138(%rip),%zmm8,%zmm9        # 4b6bc0 <abi_test_hex.digits+0xb840>
 1f7fcf8:	vporq  -0x1ac9102(%rip),%zmm8,%zmm8        # 4b6c00 <abi_test_hex.digits+0xb880>
 1f7fd02:	and    %rdi,%r14
 1f7fd05:	mov    0xc30(%r10),%rdi
 1f7fd0c:	and    %r12,%r14
 1f7fd0f:	mov    %r8d,%r12d
 1f7fd12:	kmovq  %r14,%k7
 1f7fd17:	vpmovm2b %k7,%zmm5
 1f7fd1d:	vpermt2b %zmm5,%zmm12,%zmm30
 1f7fd23:	kandq  %k3,%k4,%k7
 1f7fd28:	kandq  %k6,%k4,%k4
 1f7fd2d:	vptestmb %zmm30,%zmm30,%k1{%k1}
 1f7fd33:	kmovq  %k4,%rbp
 1f7fd38:	vmovdqa64 %zmm5,%zmm30
 1f7fd3e:	kandq  %k1,%k7,%k1
 1f7fd43:	vptestmb %zmm31,%zmm15,%k7
 1f7fd49:	vpcompressw %zmm9,%zmm9{%k1}{z}
 1f7fd4f:	vmovdqu64 %zmm9,(%rdi,%r12,2)
 1f7fd56:	kmovd  %k1,%edi
 1f7fd5a:	kshiftrq $0x20,%k1,%k1
 1f7fd60:	popcnt %edi,%r12d
 1f7fd65:	mov    0xc30(%r10),%rdi
 1f7fd6c:	vpcompressw %zmm8,%zmm8{%k1}{z}
 1f7fd72:	add    %r8d,%r12d
 1f7fd75:	mov    %r14,%r8
 1f7fd78:	or     %rbp,%r8
 1f7fd7b:	vmovdqu64 %zmm8,(%rdi,%r12,2)
 1f7fd82:	kmovq  %k0,%rdi
 1f7fd87:	vporq  %zmm28,%zmm24,%zmm8
 1f7fd8d:	and    %rdi,%r13
 1f7fd90:	kmovq  %k7,%rdi
 1f7fd95:	vptestmb %zmm8,%zmm8,%k0
 1f7fd9b:	or     %r15,%rdi
 1f7fd9e:	mov    0xc28(%r10),%r15
 1f7fda5:	or     %r13,%r8
 1f7fda8:	mov    %rdi,0x8(%r15,%rbx,1)
 1f7fdad:	kmovq  %k0,%rdi
 1f7fdb2:	korq   %k3,%k2,%k0
 1f7fdb7:	mov    %r8,(%r15,%rbx,1)
 1f7fdbb:	andn   %rdi,%r8,%rdi
 1f7fdc0:	mov    %rdi,0x10(%r15,%rbx,1)
 1f7fdc5:	kmovq  %k0,%rdi
 1f7fdca:	kmovq  %k2,0x18(%r15,%rbx,1)
 1f7fdd1:	or     %r14,%rdi
 1f7fdd4:	mov    %rdi,0x20(%r15,%rbx,1)
 1f7fdd9:	popcnt %r13,%r15
 1f7fdde:	mov    0x28(%rsp),%r13
 1f7fde3:	kmovd  %k1,%edi
 1f7fde7:	add    $0x40,%rbx
 1f7fdeb:	popcnt %edi,%r8d
 1f7fdf0:	popcnt %r14,%rdi
 1f7fdf5:	add    %r15,%rcx
 1f7fdf8:	add    %rdi,%rdx
 1f7fdfb:	popcnt %rbp,%rdi
 1f7fe00:	add    %r12d,%r8d
 1f7fe03:	add    %rdi,%rsi
 1f7fe06:	cmp    %rax,%rbx
 1f7fe09:	jb     1f7f970 <node_facts_window_run+0x3420>
 1f7fe0f:	jmp    1f80641 <node_facts_window_run+0x40f1>
 1f7fe14:	kmovq  %k3,%rdi
 1f7fe19:	mov    %rdi,%r14
 1f7fe1c:	mov    %rdi,0x180(%rsp)
 1f7fe24:	test   %rdi,%rdi
 1f7fe27:	je     1f7ff25 <node_facts_window_run+0x39d5>
 1f7fe2d:	xor    %edi,%edi
 1f7fe2f:	tzcnt  %r14,%rdi
 1f7fe34:	mov    %r14,0x120(%rsp)
 1f7fe3c:	lea    (%rdi,%rbx,1),%rbp
 1f7fe40:	mov    %rdi,0x48(%rsp)
 1f7fe45:	mov    %rbp,0x38(%rsp)
 1f7fe4a:	mov    %ebp,%r13d
 1f7fe4d:	mov    0x28(%rsp),%rdi
 1f7fe52:	mov    0x18(%rsp),%r14
 1f7fe57:	movzwl 0x6b554(%rdi,%r13,2),%r10d
 1f7fe60:	sub    %r10d,%ebp
 1f7fe63:	mov    0xc10(%r14),%r10
 1f7fe6a:	mov    0xc18(%r14),%r14
 1f7fe71:	mov    %r14,0x60(%rsp)
 1f7fe76:	movzbl (%r10,%rbp,1),%r14d
 1f7fe7b:	mov    0x60(%rsp),%r10
 1f7fe80:	or     %r14b,(%r10,%r13,1)
 1f7fe84:	mov    %rdi,%r10
 1f7fe87:	movzbl 0x2c(%rdi,%r13,1),%edi
 1f7fe8d:	and    $0x7f,%edi
 1f7fe90:	mov    %rdi,0x1c0(%rsp)
 1f7fe98:	movzbl 0x2c(%r10,%rbp,1),%edi
 1f7fe9e:	and    $0x7f,%edi
 1f7fea1:	mov    %rdi,0x30(%rsp)
 1f7fea6:	mov    0x18(%rsp),%r10
 1f7feab:	movzbl 0x3c0(%r10,%rdi,1),%r13d
 1f7feb4:	mov    %r13b,0x60(%rsp)
 1f7feb9:	xor    %r13d,%r13d
 1f7febc:	movzbl 0x60(%rsp),%edi
 1f7fec1:	mov    0x1c0(%rsp),%r14
 1f7fec9:	test   %dil,0x440(%r10,%r14,1)
 1f7fed1:	mov    0x48(%rsp),%rdi
 1f7fed6:	mov    0xc28(%r10),%r10
 1f7fedd:	setne  %r13b
 1f7fee1:	shlx   %rdi,%r13,%rdi
 1f7fee6:	or     %rdi,%r15
 1f7fee9:	cmp    0x38(%rsp),%eax
 1f7feed:	seta   %dil
 1f7fef1:	cmpq   $0x22,0x30(%rsp)
 1f7fef7:	sete   %r14b
 1f7fefb:	and    %dil,%r14b
 1f7fefe:	movzbl %r14b,%edi
 1f7ff02:	mov    0x120(%rsp),%r14
 1f7ff0a:	shlx   %rbp,%rdi,%rdi
 1f7ff0f:	and    $0xffffffc0,%ebp
 1f7ff12:	not    %rdi
 1f7ff15:	and    %rdi,0x20(%r10,%rbp,1)
 1f7ff1a:	blsr   %r14,%r14
 1f7ff1f:	jne    1f7fe2d <node_facts_window_run+0x38dd>
 1f7ff25:	kmovq  %k0,%rdi
 1f7ff2a:	mov    %rdi,%r14
 1f7ff2d:	mov    %rdi,0x120(%rsp)
 1f7ff35:	test   %rdi,%rdi
 1f7ff38:	je     1f7ff7b <node_facts_window_run+0x3a2b>
 1f7ff3a:	mov    0x28(%rsp),%rdi
 1f7ff3f:	xor    %r13d,%r13d
 1f7ff42:	tzcnt  %r14,%r13
 1f7ff47:	mov    0x18(%rsp),%r10
 1f7ff4c:	or     %rbx,%r13
 1f7ff4f:	mov    %r13d,%ebp
 1f7ff52:	movzwl 0x6d5d4(%rdi,%rbp,2),%edi
 1f7ff5a:	sub    %edi,%r13d
 1f7ff5d:	mov    0xc10(%r10),%rdi
 1f7ff64:	mov    0xc18(%r10),%r10
 1f7ff6b:	movzbl (%rdi,%r13,1),%edi
 1f7ff70:	or     %dil,(%r10,%rbp,1)
 1f7ff74:	blsr   %r14,%r14
 1f7ff79:	jne    1f7ff3a <node_facts_window_run+0x39ea>
 1f7ff7b:	popcnt 0x180(%rsp),%r14
 1f7ff85:	popcnt 0x120(%rsp),%rdi
 1f7ff8f:	mov    0x18(%rsp),%r10
 1f7ff94:	add    0x20(%rsp),%r14
 1f7ff99:	add    %rdi,%r14
 1f7ff9c:	mov    0xc18(%r10),%rdi
 1f7ffa3:	mov    %r14,0x20(%rsp)
 1f7ffa8:	vmovdqu64 (%rdi,%rbx,1),%zmm15
 1f7ffaf:	jmp    1f7fb77 <node_facts_window_run+0x3627>
 1f7ffb4:	test   %rsi,%rsi
 1f7ffb7:	je     1f8062f <node_facts_window_run+0x40df>
 1f7ffbd:	vmovdqu64 0x380(%rdi),%zmm0
 1f7ffc4:	vbroadcasti32x4 -0x19ba60e(%rip),%zmm1        # 5c59c0 <.LCPI3_85>
 1f7ffce:	vpbroadcastq -0x19b3f08(%rip),%zmm2        # 5cc0d0 <.LCPI3_42>
 1f7ffd8:	vpbroadcastq -0x19b3f0a(%rip),%zmm3        # 5cc0d8 <.LCPI3_43>
 1f7ffe2:	vmovdqa64 -0x1ac96ec(%rip),%zmm5        # 4b6900 <abi_test_hex.digits+0xb580>
 1f7ffec:	vbroadcasti32x4 -0x19ba616(%rip),%zmm14        # 5c59e0 <.LCPI3_87>
 1f7fff6:	vbroadcasti32x4 -0x19ba610(%rip),%zmm15        # 5c59f0 <.LCPI3_88>
 1f80000:	vbroadcasti32x4 -0x19ba73a(%rip),%zmm20        # 5c58d0 <.LCPI3_18>
 1f8000a:	vbroadcasti32x4 -0x19ba614(%rip),%zmm22        # 5c5a00 <.LCPI3_89>
 1f80014:	vmovdqa64 -0x1ac945e(%rip),%zmm23        # 4b6bc0 <abi_test_hex.digits+0xb840>
 1f8001e:	vmovdqa64 -0x1ac9428(%rip),%zmm24        # 4b6c00 <abi_test_hex.digits+0xb880>
 1f80028:	movzbl 0x5c0(%rdi),%r9d
 1f80030:	mov    %rsi,%rax
 1f80033:	xor    %r8d,%r8d
 1f80036:	vpxord %xmm17,%xmm17,%xmm17
 1f8003c:	vpxord %xmm21,%xmm21,%xmm21
 1f80042:	mov    %rdi,%rbp
 1f80045:	xor    %r10d,%r10d
 1f80048:	vpxor  %xmm6,%xmm6,%xmm6
 1f8004c:	vpxord %xmm28,%xmm28,%xmm28
 1f80052:	movq   $0x0,0x20(%rsp)
 1f8005b:	xor    %ecx,%ecx
 1f8005d:	xor    %edx,%edx
 1f8005f:	xor    %esi,%esi
 1f80061:	neg    %r9
 1f80064:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f80070:	vmovdqu64 0x2c(%r13,%r10,1),%zmm7
 1f8007b:	mov    0xc00(%rbp),%rdi
 1f80082:	mov    0xc08(%rbp),%r11
 1f80089:	vmovdqa64 %zmm21,%zmm11
 1f8008f:	vmovdqu64 0x100(%rbp),%zmm21
 1f80096:	vmovdqu64 0x300(%rbp),%zmm10
 1f8009d:	vmovdqu64 0x80(%rbp),%zmm30
 1f800a4:	vmovdqu64 0x180(%rbp),%zmm9
 1f800ab:	vmovdqu64 0x200(%rbp),%zmm27
 1f800b2:	vmovdqu64 0x280(%rbp),%zmm12
 1f800b9:	vmovdqu64 0x440(%rbp),%zmm18
 1f800c0:	vmovdqu64 0x4c0(%rbp),%zmm29
 1f800c7:	vmovdqa64 %zmm17,%zmm25
 1f800cd:	vmovdqu64 0x3c0(%rbp),%zmm17
 1f800d4:	vmovdqu64 (%rdi,%r10,1),%zmm31
 1f800db:	vmovdqu64 (%r11,%r10,1),%zmm26
 1f800e2:	mov    0xc10(%rbp),%rdi
 1f800e9:	vpermt2b 0x140(%rbp),%zmm7,%zmm21
 1f800f0:	vpermt2b 0x340(%rbp),%zmm7,%zmm10
 1f800f7:	vpermt2b 0xc0(%rbp),%zmm7,%zmm30
 1f800fe:	vpermt2b 0x1c0(%rbp),%zmm7,%zmm9
 1f80105:	vpermt2b 0x240(%rbp),%zmm7,%zmm27
 1f8010c:	vpermt2b 0x2c0(%rbp),%zmm7,%zmm12
 1f80113:	vpermt2b 0x400(%rbp),%zmm7,%zmm17
 1f8011a:	vpermt2b 0x480(%rbp),%zmm7,%zmm18
 1f80121:	vpandq %zmm1,%zmm7,%zmm4
 1f80127:	vpermt2b 0x500(%rbp),%zmm7,%zmm29
 1f8012e:	vpsrlw $0x2,%zmm31,%zmm13
 1f80135:	vpsrlw $0x3,%zmm31,%zmm7
 1f8013c:	vpternlogq $0xf8,%zmm2,%zmm26,%zmm21
 1f80143:	vpternlogq $0xf8,%zmm3,%zmm13,%zmm21
 1f8014a:	vpternlogq $0xf8,-0x19b4075(%rip){1to8},%zmm7,%zmm21        # 5cc0e0 <.LCPI3_44>
 1f80155:	vmovdqu64 %zmm21,(%rdi,%r10,1)
 1f8015c:	vmovdqu64 0x6b554(%r13,%r10,2),%zmm7
 1f80167:	vmovdqu64 0x6b594(%r13,%r10,2),%zmm16
 1f80172:	vmovdqu64 0x6d614(%r13,%r10,2),%zmm19
 1f8017d:	vmovdqu64 0x6d5d4(%r13,%r10,2),%zmm8
 1f80188:	vpmovuswb %zmm7,%ymm7
 1f8018e:	vpmovuswb %zmm16,%ymm16
 1f80194:	vpmovuswb %zmm19,%ymm19
 1f8019a:	vinserti64x4 $0x1,%ymm16,%zmm7,%zmm7
 1f801a1:	vpmovuswb %zmm8,%ymm16
 1f801a7:	vmovdqa64 %zmm11,%zmm8
 1f801ad:	vptestmb %zmm7,%zmm7,%k1
 1f801b3:	vpcmpnltub %zmm7,%zmm5,%k0
 1f801ba:	kmovq  %k1,%rdi
 1f801bf:	kmovq  %k0,%rbx
 1f801c4:	vpcmpltub %zmm7,%zmm5,%k3{%k1}
 1f801cb:	vpsubb %zmm7,%zmm5,%zmm7
 1f801d1:	and    %rdi,%rbx
 1f801d4:	vpermt2b %zmm21,%zmm7,%zmm8
 1f801da:	mov    0xc18(%rbp),%rdi
 1f801e1:	kmovq  %rbx,%k1
 1f801e6:	vinserti64x4 $0x1,%ymm19,%zmm16,%zmm19
 1f801ed:	vpermt2b %zmm17,%zmm7,%zmm25{%k1}{z}
 1f801f3:	vptestmb %zmm19,%zmm19,%k2
 1f801f9:	vpsubb %zmm19,%zmm5,%zmm16
 1f801ff:	vpcmpltub %zmm19,%zmm5,%k0{%k2}
 1f80206:	vpcmpnltub %zmm19,%zmm5,%k2{%k2}
 1f8020d:	vpermt2b %zmm21,%zmm16,%zmm11{%k2}{z}
 1f80213:	kortestq %k3,%k0
 1f80218:	vptestmb %zmm18,%zmm25,%k4
 1f8021e:	kmovq  %k4,%r11
 1f80223:	vporq  %zmm8,%zmm11,%zmm8
 1f80229:	vmovdqu8 %zmm8,%zmm11{%k1}
 1f8022f:	vmovdqu64 %zmm11,(%rdi,%r10,1)
 1f80236:	jne    1f804cb <node_facts_window_run+0x3f7b>
 1f8023c:	vmovdqa64 %zmm6,%zmm8
 1f80242:	vpermi2b %zmm26,%zmm6,%zmm16{%k2}{z}
 1f80248:	vpermt2b %zmm26,%zmm7,%zmm8{%k1}{z}
 1f8024e:	vpandq %zmm12,%zmm11,%zmm19
 1f80254:	vpcmpeqb -0x1ac98de(%rip),%zmm19,%k2        # 4b6980 <abi_test_hex.digits+0xb600>
 1f8025e:	vpternlogq $0xe0,%zmm1,%zmm26,%zmm10
 1f80265:	vpsrlw $0x2,%zmm30,%zmm12
 1f8026c:	vpandq %zmm9,%zmm31,%zmm9
 1f80272:	mov    0x18(%rsp),%rbp
 1f80277:	vpcmpeqb -0x1ac9941(%rip),%zmm4,%k7        # 4b6940 <abi_test_hex.digits+0xb5c0>
 1f80281:	vpaddw %zmm9,%zmm9,%zmm9
 1f80287:	vpsrlw $0x3,%zmm8,%zmm6
 1f8028e:	vpternlogq $0xe4,-0x19b4189(%rip){1to8},%zmm16,%zmm6        # 5cc110 <.LCPI3_52>
 1f80299:	mov    0xc20(%rbp),%rdi
 1f802a0:	vptestnmb %zmm27,%zmm27,%k2{%k2}
 1f802a6:	vpermb %zmm0,%zmm6,%zmm18
 1f802ac:	vporq  %zmm27,%zmm19,%zmm6
 1f802b2:	vptestmb %zmm18,%zmm10,%k0{%k2}
 1f802b8:	vpandq %zmm3,%zmm12,%zmm10
 1f802be:	vpaddw %zmm31,%zmm31,%zmm12
 1f802c4:	vptestmb %zmm20,%zmm30,%k2
 1f802ca:	vpternlogq $0xf8,%zmm2,%zmm30,%zmm10
 1f802d1:	vpternlogq $0xf8,-0x19b41f4(%rip){1to8},%zmm12,%zmm10        # 5cc0e8 <.LCPI3_47>
 1f802dc:	vpsllw $0x4,%zmm26,%zmm12
 1f802e3:	vpternlogq $0xf8,-0x19b41fe(%rip){1to8},%zmm13,%zmm10        # 5cc0f0 <.LCPI3_48>
 1f802ee:	vpsllw $0x3,%zmm26,%zmm13
 1f802f5:	vpternlogq $0xf8,-0x19b4208(%rip){1to8},%zmm9,%zmm10        # 5cc0f8 <.LCPI3_49>
 1f80300:	vpandq %zmm14,%zmm8,%zmm9
 1f80306:	vpandd -0x19b17d0(%rip){1to16},%zmm8,%zmm8        # 5ceb40 <.LCPI3_78>
 1f80310:	vpternlogq $0xf8,-0x19b421b(%rip){1to8},%zmm13,%zmm10        # 5cc100 <.LCPI3_50>
 1f8031b:	vpcmpeqb %zmm15,%zmm9,%k4
 1f80321:	vpandq %zmm14,%zmm16,%zmm9
 1f80327:	vpternlogq $0xf8,-0x19b422a(%rip){1to8},%zmm12,%zmm10        # 5cc108 <.LCPI3_51>
 1f80332:	vpcmpeqb %zmm15,%zmm9,%k5
 1f80338:	vpandq %zmm20,%zmm31,%zmm9
 1f8033e:	korq   %k5,%k4,%k4
 1f80343:	vpcmpeqb -0x1ac990d(%rip),%zmm4,%k4{%k4}        # 4b6a40 <abi_test_hex.digits+0xb6c0>
 1f8034d:	vpcmpeqb -0x1ac9817(%rip),%zmm4,%k5        # 4b6b40 <abi_test_hex.digits+0xb7c0>
 1f80357:	vpternlogq $0xfe,%zmm8,%zmm19,%zmm9
 1f8035e:	vpsllw $0x7,%zmm31,%zmm8
 1f80365:	vptestnmb %zmm9,%zmm9,%k6
 1f8036b:	vpmovb2m %zmm8,%k3
 1f80371:	vmovdqu64 %zmm10,(%rdi,%r10,1)
 1f80378:	kmovq  %k7,%rdi
 1f8037d:	vptestmb -0x1ac9907(%rip),%zmm31,%k7        # 4b6a80 <abi_test_hex.digits+0xb700>
 1f80387:	and    %r9,%rdi
 1f8038a:	knotq  %k4,%k4
 1f8038f:	kmovq  %k4,%r15
 1f80394:	kmovq  %k7,%r14
 1f80399:	vptestmb %zmm19,%zmm19,%k7
 1f8039f:	and    %r14,%rdi
 1f803a2:	kmovq  %k6,%r14
 1f803a7:	vptestmb %zmm22,%zmm31,%k6{%k7}
 1f803ad:	and    %rdi,%r14
 1f803b0:	mov    0xc30(%rbp),%rdi
 1f803b7:	and    %rbx,%r14
 1f803ba:	mov    %r8d,%ebx
 1f803bd:	kmovq  %r14,%k7
 1f803c2:	vpmovm2b %k7,%zmm4
 1f803c8:	vpermt2b %zmm4,%zmm7,%zmm28
 1f803ce:	vpbroadcastw %r10d,%zmm7
 1f803d4:	kandq  %k3,%k5,%k7
 1f803d9:	vporq  %zmm23,%zmm7,%zmm8
 1f803df:	vporq  %zmm24,%zmm7,%zmm7
 1f803e5:	kandq  %k6,%k5,%k4
 1f803ea:	kmovq  %k4,%r12
 1f803ef:	vptestmb %zmm28,%zmm28,%k1{%k1}
 1f803f5:	vmovdqa64 %zmm4,%zmm28
 1f803fb:	kandq  %k1,%k7,%k1
 1f80400:	vptestmb %zmm29,%zmm11,%k7
 1f80406:	vpcompressw %zmm8,%zmm8{%k1}{z}
 1f8040c:	vmovdqu64 %zmm8,(%rdi,%rbx,2)
 1f80413:	kmovd  %k1,%edi
 1f80417:	kshiftrq $0x20,%k1,%k1
 1f8041d:	popcnt %edi,%ebx
 1f80421:	mov    0xc30(%rbp),%rdi
 1f80428:	vpcompressw %zmm7,%zmm7{%k1}{z}
 1f8042e:	add    %r8d,%ebx
 1f80431:	mov    %r14,%r8
 1f80434:	or     %r12,%r8
 1f80437:	vmovdqu64 %zmm7,(%rdi,%rbx,2)
 1f8043e:	kmovq  %k0,%rdi
 1f80443:	vptestmb %zmm6,%zmm6,%k0
 1f80449:	vmovdqa64 %zmm26,%zmm6
 1f8044f:	and    %rdi,%r15
 1f80452:	kmovq  %k7,%rdi
 1f80457:	or     %r11,%rdi
 1f8045a:	mov    0xc28(%rbp),%r11
 1f80461:	or     %r15,%r8
 1f80464:	mov    %rdi,0x8(%r11,%r10,1)
 1f80469:	kmovq  %k0,%rdi
 1f8046e:	korq   %k3,%k2,%k0
 1f80473:	mov    %r8,(%r11,%r10,1)
 1f80477:	andn   %rdi,%r8,%rdi
 1f8047c:	mov    %rdi,0x10(%r11,%r10,1)
 1f80481:	kmovq  %k0,%rdi
 1f80486:	kmovq  %k2,0x18(%r11,%r10,1)
 1f8048d:	or     %r14,%rdi
 1f80490:	mov    %rdi,0x20(%r11,%r10,1)
 1f80495:	kmovd  %k1,%edi
 1f80499:	popcnt %r15,%r11
 1f8049e:	add    $0x40,%r10
 1f804a2:	popcnt %edi,%r8d
 1f804a7:	add    %r11,%rcx
 1f804aa:	popcnt %r12,%r11
 1f804af:	add    %ebx,%r8d
 1f804b2:	popcnt %r14,%rbx
 1f804b7:	add    %r11,%rsi
 1f804ba:	add    %rbx,%rdx
 1f804bd:	cmp    %rax,%r10
 1f804c0:	jb     1f80070 <node_facts_window_run+0x3b20>
 1f804c6:	jmp    1f80641 <node_facts_window_run+0x40f1>
 1f804cb:	kmovq  %k3,%rdi
 1f804d0:	mov    %rdi,%r14
 1f804d3:	mov    %rdi,0x38(%rsp)
 1f804d8:	test   %rdi,%rdi
 1f804db:	je     1f805a8 <node_facts_window_run+0x4058>
 1f804e1:	xor    %edi,%edi
 1f804e3:	tzcnt  %r14,%rdi
 1f804e8:	mov    %r14,0x10(%rsp)
 1f804ed:	lea    (%rdi,%r10,1),%r12
 1f804f1:	mov    %rdi,0x120(%rsp)
 1f804f9:	mov    %r12,0x48(%rsp)
 1f804fe:	mov    %r12d,%ebp
 1f80501:	mov    0x28(%rsp),%r15
 1f80506:	mov    0x18(%rsp),%r13
 1f8050b:	movzwl 0x6b554(%r15,%rbp,2),%r14d
 1f80514:	mov    0xc18(%r13),%rdi
 1f8051b:	sub    %r14d,%r12d
 1f8051e:	mov    0xc10(%r13),%r14
 1f80525:	movzbl (%r14,%r12,1),%r14d
 1f8052a:	or     %r14b,(%rdi,%rbp,1)
 1f8052e:	movzbl 0x2c(%r15,%r12,1),%r14d
 1f80534:	movzbl 0x2c(%r15,%rbp,1),%edi
 1f8053a:	xor    %r15d,%r15d
 1f8053d:	and    $0x7f,%r14d
 1f80541:	and    $0x7f,%edi
 1f80544:	movzbl 0x3c0(%r13,%r14,1),%ebp
 1f8054d:	test   %bpl,0x440(%r13,%rdi,1)
 1f80555:	mov    0x120(%rsp),%rdi
 1f8055d:	setne  %r15b
 1f80561:	shlx   %rdi,%r15,%rdi
 1f80566:	or     %rdi,%r11
 1f80569:	cmp    0x48(%rsp),%eax
 1f8056d:	seta   %dil
 1f80571:	cmp    $0x22,%r14
 1f80575:	mov    0xc28(%r13),%r14
 1f8057c:	sete   %bpl
 1f80580:	and    %dil,%bpl
 1f80583:	movzbl %bpl,%edi
 1f80587:	shlx   %r12,%rdi,%rdi
 1f8058c:	and    $0xffffffc0,%r12d
 1f80590:	not    %rdi
 1f80593:	and    %rdi,0x20(%r14,%r12,1)
 1f80598:	mov    0x10(%rsp),%r14
 1f8059d:	blsr   %r14,%r14
 1f805a2:	jne    1f804e1 <node_facts_window_run+0x3f91>
 1f805a8:	kmovq  %k0,%rdi
 1f805ad:	mov    %rdi,%r15
 1f805b0:	test   %rdi,%rdi
 1f805b3:	je     1f805f9 <node_facts_window_run+0x40a9>
 1f805b5:	mov    0x28(%rsp),%r13
 1f805ba:	xor    %r14d,%r14d
 1f805bd:	tzcnt  %r15,%r14
 1f805c2:	or     %r10,%r14
 1f805c5:	mov    %r14d,%r12d
 1f805c8:	movzwl 0x6d5d4(%r13,%r12,2),%ebp
 1f805d1:	sub    %ebp,%r14d
 1f805d4:	mov    0x18(%rsp),%rbp
 1f805d9:	mov    0xc10(%rbp),%r13
 1f805e0:	mov    0xc18(%rbp),%rbp
 1f805e7:	movzbl 0x0(%r13,%r14,1),%r14d
 1f805ed:	or     %r14b,0x0(%rbp,%r12,1)
 1f805f2:	blsr   %r15,%r15
 1f805f7:	jne    1f805b5 <node_facts_window_run+0x4065>
 1f805f9:	popcnt 0x38(%rsp),%r14
 1f80600:	mov    0x18(%rsp),%r15
 1f80605:	popcnt %rdi,%rdi
 1f8060a:	add    0x20(%rsp),%r14
 1f8060f:	add    %rdi,%r14
 1f80612:	mov    0xc18(%r15),%rdi
 1f80619:	mov    %r14,0x20(%rsp)
 1f8061e:	mov    0x28(%rsp),%r13
 1f80623:	vmovdqu64 (%rdi,%r10,1),%zmm11
 1f8062a:	jmp    1f8023c <node_facts_window_run+0x3cec>
 1f8062f:	movq   $0x0,0x20(%rsp)
 1f80638:	xor    %ecx,%ecx
 1f8063a:	xor    %edx,%edx
 1f8063c:	xor    %esi,%esi
 1f8063e:	xor    %r8d,%r8d
 1f80641:	mov    0x40(%rsp),%r9
 1f80646:	mov    0x20(%rsp),%rax
 1f8064b:	movq   $0x0,0x2c0(%rsp)
 1f80657:	add    %rax,0xa60(%r9)
 1f8065e:	add    %rcx,0x7e0(%r9)
 1f80665:	add    %rdx,0x7f8(%r9)
 1f8066c:	add    %rsi,0x830(%r9)
 1f80673:	test   %r8d,%r8d
 1f80676:	je     1f80751 <node_facts_window_run+0x4201>
 1f8067c:	mov    0x8(%rsp),%r11
 1f80681:	mov    0x18(%rsp),%rdi
 1f80686:	mov    $0x8,%ebp
 1f8068b:	mov    %r8d,%r14d
 1f8068e:	xor    %r12d,%r12d
 1f80691:	xor    %r13d,%r13d
 1f80694:	xor    %r15d,%r15d
 1f80697:	nopw   0x0(%rax,%rax,1)
 1f806a0:	mov    0xc30(%rdi),%rax
 1f806a7:	mov    0x28(%rsp),%rsi
 1f806ac:	mov    0xc38(%rdi),%rcx
 1f806b3:	movzwl (%rax,%r13,2),%ebx
 1f806b8:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f806c0:	sub    %eax,%ebx
 1f806c2:	movzwl 0x6b554(%rsi,%rbx,2),%eax
 1f806ca:	mov    %ebx,%edx
 1f806cc:	sub    %eax,%edx
 1f806ce:	cmpb   $0x2,0x69454(%rsi,%rdx,1)
 1f806d6:	mov    0x757d4(%rsi,%rdx,4),%eax
 1f806dd:	cmovne %r12,%rax
 1f806e1:	movzbl (%rcx,%rax,1),%eax
 1f806e5:	cmovne %ebp,%eax
 1f806e8:	test   $0x8,%al
 1f806ea:	je     1f806fd <node_facts_window_run+0x41ad>
 1f806ec:	movzbl %al,%eax
 1f806ef:	test   $0x10,%al
 1f806f1:	jne    1f80723 <node_facts_window_run+0x41d3>
 1f806f3:	inc    %r13
 1f806f6:	cmp    %r13,%r14
 1f806f9:	jne    1f806a0 <node_facts_window_run+0x4150>
 1f806fb:	jmp    1f8074a <node_facts_window_run+0x41fa>
 1f806fd:	mov    0x28(%rsp),%rsi
 1f80702:	vzeroupper
 1f80705:	call   1f92a00 <node_tests_window_wants>
 1f8070a:	mov    0x18(%rsp),%rdi
 1f8070f:	mov    0x40(%rsp),%r9
 1f80714:	mov    0x8(%rsp),%r11
 1f80719:	movzbl %al,%eax
 1f8071c:	inc    %r15
 1f8071f:	test   $0x10,%al
 1f80721:	je     1f806f3 <node_facts_window_run+0x41a3>
 1f80723:	mov    0xc28(%rdi),%rdx
 1f8072a:	mov    %ebx,%ecx
 1f8072c:	mov    $0xfffffffffffffffe,%rax
 1f80733:	and    $0xffffffc0,%ebx
 1f80736:	rol    %cl,%rax
 1f80739:	and    %rax,0x20(%rdx,%rbx,1)
 1f8073e:	inc    %r13
 1f80741:	cmp    %r13,%r14
 1f80744:	jne    1f806a0 <node_facts_window_run+0x4150>
 1f8074a:	mov    0x28(%rsp),%r13
 1f8074f:	jmp    1f80761 <node_facts_window_run+0x4211>
 1f80751:	mov    0x8(%rsp),%r11
 1f80756:	mov    0x18(%rsp),%rdi
 1f8075b:	xor    %r14d,%r14d
 1f8075e:	xor    %r15d,%r15d
 1f80761:	add    %r15,0x820(%r9)
 1f80768:	rdtsc
 1f8076a:	add    %r14,0x818(%r9)
 1f80771:	cmpl   $0x0,0xa88(%r11)
 1f80779:	mov    %rax,0x6d0(%rsp)
 1f80781:	mov    %rdx,0x440(%rsp)
 1f80789:	mov    0xa8(%rsp),%rbp
 1f80791:	je     1f815ba <node_facts_window_run+0x506a>
 1f80797:	movzbl 0x78(%rsp),%eax
 1f8079c:	lea    0x42ec(%r13),%rdx
 1f807a3:	lea    0x422c(%r13),%rcx
 1f807aa:	mov    $0xffffffffffffffff,%rbx
 1f807b1:	xor    %r12d,%r12d
 1f807b4:	xor    %r14d,%r14d
 1f807b7:	mov    %eax,0xc0(%rsp)
 1f807be:	movzbl 0x3f(%rdi),%eax
 1f807c2:	shl    $0x1b,%rax
 1f807c6:	mov    %rax,0x50(%rsp)
 1f807cb:	mov    0xd8(%rsp),%rax
 1f807d3:	mov    (%rax),%rax
 1f807d6:	mov    0x6b8(%rax),%eax
 1f807dc:	mov    %eax,0xa0(%rsp)
 1f807e3:	movzbl 0x39(%rdi),%eax
 1f807e7:	mov    %eax,0xb8(%rsp)
 1f807ee:	movzbl 0x3b(%rdi),%eax
 1f807f2:	mov    %eax,0x98(%rsp)
 1f807f9:	mov    0xc8(%rsp),%eax
 1f80800:	mov    %rdx,0xe8(%rsp)
 1f80808:	mov    %rcx,0x7b0(%rsp)
 1f80810:	movq   $0x0,0x2c0(%rsp)
 1f8081c:	vpbroadcastd %eax,%zmm3
 1f80822:	jmp    1f80847 <node_facts_window_run+0x42f7>
 1f80824:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f80830:	movb   $0x0,0x61(%rdx)
 1f80834:	mov    0xa88(%r11),%eax
 1f8083b:	inc    %r12
 1f8083e:	cmp    %rax,%r12
 1f80841:	jae    1f815ba <node_facts_window_run+0x506a>
 1f80847:	mov    0xa80(%r11),%rax
 1f8084e:	imul   $0x68,%r12,%rdx
 1f80852:	add    %rbp,%rdx
 1f80855:	cmpb   $0x0,(%rax,%r12,1)
 1f8085a:	je     1f80830 <node_facts_window_run+0x42e0>
 1f8085c:	mov    0xa48(%r11),%rax
 1f80863:	mov    (%rax,%r12,4),%eax
 1f80867:	cmp    0x20(%r9),%eax
 1f8086b:	jae    1f80830 <node_facts_window_run+0x42e0>
 1f8086d:	mov    0x18(%r9),%rcx
 1f80871:	movzbl (%rcx,%rax,1),%eax
 1f80875:	shr    $0x5,%al
 1f80878:	and    $0x1,%al
 1f8087a:	mov    %al,0x61(%rdx)
 1f8087d:	je     1f80834 <node_facts_window_run+0x42e4>
 1f8087f:	mov    0xa68(%r11),%rax
 1f80886:	mov    %rdi,%r10
 1f80889:	mov    (%rax,%r12,4),%ebp
 1f8088d:	mov    0xc20(%rdi),%rax
 1f80894:	mov    0x651b8(%r13,%rbp,4),%r8d
 1f8089c:	mov    %ebp,%ecx
 1f8089e:	sub    %r8d,%ecx
 1f808a1:	inc    %ecx
 1f808a3:	mov    %rcx,%r15
 1f808a6:	mov    %ecx,%ecx
 1f808a8:	mov    %rcx,0x180(%rsp)
 1f808b0:	mov    %rdx,0x3c0(%rsp)
 1f808b8:	mov    %r8,0x20(%rsp)
 1f808bd:	test   %r8,%r8
 1f808c0:	je     1f808e6 <node_facts_window_run+0x4396>
 1f808c2:	lea    -0x1(%r8),%rsi
 1f808c6:	shr    $0x6,%rsi
 1f808ca:	inc    %rsi
 1f808cd:	mov    %esi,%edx
 1f808cf:	and    $0x7,%edx
 1f808d2:	cmp    $0x1c1,%r8d
 1f808d9:	jae    1f808ed <node_facts_window_run+0x439d>
 1f808db:	vpxor  %xmm0,%xmm0,%xmm0
 1f808df:	xor    %edi,%edi
 1f808e1:	jmp    1f80a50 <node_facts_window_run+0x4500>
 1f808e6:	xor    %ecx,%ecx
 1f808e8:	jmp    1f80ac8 <node_facts_window_run+0x4578>
 1f808ed:	mov    0x180(%rsp),%rcx
 1f808f5:	mov    %r8,%r13
 1f808f8:	and    $0xfffffffffffffff8,%rsi
 1f808fc:	vpxor  %xmm0,%xmm0,%xmm0
 1f80900:	xor    %edi,%edi
 1f80902:	lea    0x1c0(%rax,%rcx,1),%r8
 1f8090a:	nopw   0x0(%rax,%rax,1)
 1f80910:	lea    0x0(%r13,%rdi,1),%r9
 1f80915:	mov    %r9d,%ecx
 1f80918:	sub    $0x40,%r9
 1f8091c:	shlx   %rcx,%rbx,%rcx
 1f80921:	not    %rcx
 1f80924:	mov    %rcx,%r11
 1f80927:	cmovae %rbx,%r11
 1f8092b:	cmp    $0x40,%r9
 1f8092f:	shlx   %r9,%rbx,%r9
 1f80934:	not    %r9
 1f80937:	kmovq  %r11,%k1
 1f8093c:	cmovae %rbx,%r9
 1f80940:	vmovdqu8 -0x1c0(%r8),%zmm1{%k1}{z}
 1f80947:	kmovq  %r9,%k1
 1f8094c:	lea    -0x80(%r13,%rdi,1),%r9
 1f80951:	vmovdqu8 -0x180(%r8),%zmm2{%k1}{z}
 1f80958:	cmp    $0x40,%r9
 1f8095c:	mov    %rcx,%r9
 1f8095f:	cmovae %rbx,%r9
 1f80963:	kmovq  %r9,%k1
 1f80968:	lea    -0xc0(%r13,%rdi,1),%r9
 1f80970:	cmp    $0x40,%r9
 1f80974:	mov    %rcx,%r9
 1f80977:	cmovae %rbx,%r9
 1f8097b:	vpternlogq $0xfe,%zmm1,%zmm0,%zmm2
 1f80982:	vmovdqu8 -0x140(%r8),%zmm0{%k1}{z}
 1f80989:	kmovq  %r9,%k1
 1f8098e:	lea    -0x100(%r13,%rdi,1),%r9
 1f80996:	vmovdqu8 -0x100(%r8),%zmm1{%k1}{z}
 1f8099d:	cmp    $0x40,%r9
 1f809a1:	mov    %rcx,%r9
 1f809a4:	cmovae %rbx,%r9
 1f809a8:	kmovq  %r9,%k1
 1f809ad:	lea    -0x140(%r13,%rdi,1),%r9
 1f809b5:	cmp    $0x40,%r9
 1f809b9:	mov    %rcx,%r9
 1f809bc:	cmovae %rbx,%r9
 1f809c0:	vpternlogq $0xfe,%zmm0,%zmm2,%zmm1
 1f809c7:	vmovdqu8 -0xc0(%r8),%zmm0{%k1}{z}
 1f809ce:	kmovq  %r9,%k1
 1f809d3:	lea    -0x180(%r13,%rdi,1),%r9
 1f809db:	vmovdqu8 -0x80(%r8),%zmm2{%k1}{z}
 1f809e2:	cmp    $0x40,%r9
 1f809e6:	mov    %rcx,%r9
 1f809e9:	cmovae %rbx,%r9
 1f809ed:	kmovq  %r9,%k1
 1f809f2:	lea    -0x1c0(%r13,%rdi,1),%r9
 1f809fa:	vmovdqu8 -0x40(%r8),%zmm4{%k1}{z}
 1f80a01:	cmp    $0x40,%r9
 1f80a05:	cmovae %rbx,%rcx
 1f80a09:	add    $0xfffffffffffffe00,%rdi
 1f80a10:	kmovq  %rcx,%k1
 1f80a15:	vpternlogq $0xfe,%zmm0,%zmm1,%zmm2
 1f80a1c:	vmovdqu8 (%r8),%zmm0{%k1}{z}
 1f80a22:	add    $0x200,%r8
 1f80a29:	add    $0xfffffffffffffff8,%rsi
 1f80a2d:	vpternlogq $0xfe,%zmm4,%zmm2,%zmm0
 1f80a34:	jne    1f80910 <node_facts_window_run+0x43c0>
 1f80a3a:	test   %rdx,%rdx
 1f80a3d:	je     1f81563 <node_facts_window_run+0x5013>
 1f80a43:	mov    0x8(%rsp),%r11
 1f80a48:	mov    0x20(%rsp),%r8
 1f80a4d:	neg    %rdi
 1f80a50:	mov    0x180(%rsp),%rsi
 1f80a58:	lea    (%rax,%rdi,1),%rcx
 1f80a5c:	shl    $0x6,%edx
 1f80a5f:	add    %rsi,%rcx
 1f80a62:	mov    %r8,%rsi
 1f80a65:	sub    %rdi,%rsi
 1f80a68:	xor    %edi,%edi
 1f80a6a:	nopw   0x0(%rax,%rax,1)
 1f80a70:	mov    %esi,%r8d
 1f80a73:	sub    $0x40,%rsi
 1f80a77:	shlx   %r8,%rbx,%r8
 1f80a7c:	not    %r8
 1f80a7f:	cmovae %rbx,%r8
 1f80a83:	kmovq  %r8,%k1
 1f80a88:	vmovdqu8 (%rcx,%rdi,1),%zmm1{%k1}{z}
 1f80a8f:	add    $0x40,%rdi
 1f80a93:	vporq  %zmm1,%zmm0,%zmm0
 1f80a99:	cmp    %rdi,%rdx
 1f80a9c:	jne    1f80a70 <node_facts_window_run+0x4520>
 1f80a9e:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f80aa5:	mov    0x20(%rsp),%r8
 1f80aaa:	vporq  %zmm1,%zmm0,%zmm0
 1f80ab0:	vextracti128 $0x1,%ymm0,%xmm1
 1f80ab6:	vpor   %xmm1,%xmm0,%xmm0
 1f80aba:	vpshufd $0xee,%xmm0,%xmm1
 1f80abf:	vpor   %xmm1,%xmm0,%xmm0
 1f80ac3:	vmovq  %xmm0,%rcx
 1f80ac8:	mov    0xa50(%r11),%rdx
 1f80acf:	mov    0xa60(%r11),%rsi
 1f80ad6:	mov    (%rdx,%r12,4),%edi
 1f80ada:	mov    %rcx,%rdx
 1f80add:	shr    $0x20,%rdx
 1f80ae1:	mov    (%rsi,%r12,4),%r9d
 1f80ae5:	or     %rcx,%rdx
 1f80ae8:	mov    %rdx,%rsi
 1f80aeb:	shr    $0x10,%rsi
 1f80aef:	or     %edx,%esi
 1f80af1:	mov    %esi,%ecx
 1f80af3:	shr    $0x8,%ecx
 1f80af6:	or     %esi,%ecx
 1f80af8:	mov    %edi,0x340(%rsp)
 1f80aff:	cmp    %r8d,%edi
 1f80b02:	jbe    1f80b08 <node_facts_window_run+0x45b8>
 1f80b04:	or     (%rax,%r9,1),%cl
 1f80b08:	movzbl %cl,%edx
 1f80b0b:	mov    %r15,%r11
 1f80b0e:	mov    %r10,%rsi
 1f80b11:	lea    0x0(,%rdx,8),%r15d
 1f80b19:	lea    0x0(,%rdx,4),%ecx
 1f80b20:	mov    %r15d,%eax
 1f80b23:	mov    %ecx,0x300(%rsp)
 1f80b2a:	and    $0x8,%eax
 1f80b2d:	and    $0x10,%ecx
 1f80b30:	and    $0x40,%r15d
 1f80b34:	mov    %rdx,0x520(%rsp)
 1f80b3c:	or     %eax,%ecx
 1f80b3e:	mov    %edx,%eax
 1f80b40:	and    $0x10,%eax
 1f80b43:	lea    (%rcx,%rax,2),%eax
 1f80b46:	mov    %edx,%ecx
 1f80b48:	or     %eax,%r15d
 1f80b4b:	and    $0x2,%ecx
 1f80b4e:	mov    %ecx,0x4e0(%rsp)
 1f80b55:	je     1f80b67 <node_facts_window_run+0x4617>
 1f80b57:	cmpb   $0x1,0x25(%rsi)
 1f80b5b:	jne    1f80b67 <node_facts_window_run+0x4617>
 1f80b5d:	movzbl 0x4c(%rsi),%eax
 1f80b61:	shl    $0x11,%eax
 1f80b64:	or     %rax,%r15
 1f80b67:	mov    0xc60(%r10),%rcx
 1f80b6e:	mov    0xc68(%r10),%rax
 1f80b75:	mov    %r14d,%edx
 1f80b78:	mov    %r9,0x5e0(%rsp)
 1f80b80:	mov    %r14d,0x560(%rsp)
 1f80b88:	mov    %r11d,%r9d
 1f80b8b:	mov    %r8d,%edi
 1f80b8e:	shr    $0x6,%edi
 1f80b91:	and    $0x3f,%r11d
 1f80b95:	shr    $0x6,%r9d
 1f80b99:	lea    (%rcx,%rdx,8),%rsi
 1f80b9d:	mov    %rsi,0x280(%rsp)
 1f80ba5:	lea    (%rax,%rdx,8),%rsi
 1f80ba9:	mov    %rsi,0x400(%rsp)
 1f80bb1:	mov    %r11d,%esi
 1f80bb4:	mov    %r11,0x48(%rsp)
 1f80bb9:	mov    %rdi,0x480(%rsp)
 1f80bc1:	xor    $0x3f,%esi
 1f80bc4:	inc    %rdi
 1f80bc7:	mov    %rbp,0x200(%rsp)
 1f80bcf:	mov    %rdi,0x380(%rsp)
 1f80bd7:	mov    %r15,0x30(%rsp)
 1f80bdc:	mov    %r9,0x5a0(%rsp)
 1f80be4:	cmp    $0x40,%r8d
 1f80be8:	jae    1f80c08 <node_facts_window_run+0x46b8>
 1f80bea:	mov    %r8,%r13
 1f80bed:	mov    $0xffffffff,%ecx
 1f80bf2:	xor    %r8d,%r8d
 1f80bf5:	xor    %eax,%eax
 1f80bf7:	xor    %r11d,%r11d
 1f80bfa:	mov    $0x40,%r9d
 1f80c00:	mov    %r10,%rdi
 1f80c03:	jmp    1f80e7a <node_facts_window_run+0x492a>
 1f80c08:	lea    0x8(%rcx,%rdx,8),%rcx
 1f80c0d:	shr    $1,%edi
 1f80c0f:	lea    0x8(%rax,%rdx,8),%rax
 1f80c14:	mov    %r12,0x650(%rsp)
 1f80c1c:	shl    $0x6,%r9d
 1f80c20:	mov    %r8d,%edx
 1f80c23:	xor    %r14d,%r14d
 1f80c26:	xor    %r8d,%r8d
 1f80c29:	xor    %ebx,%ebx
 1f80c2b:	shl    $0x7,%rdi
 1f80c2f:	mov    %rcx,0x60(%rsp)
 1f80c34:	mov    $0xffffffff,%ecx
 1f80c39:	mov    %r9,0x38(%rsp)
 1f80c3e:	mov    %rax,0x120(%rsp)
 1f80c46:	mov    %rdi,0x1c0(%rsp)
 1f80c4e:	xor    %eax,%eax
 1f80c50:	mov    %r10,%rdi
 1f80c53:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f80c60:	mov    %edx,%r13d
 1f80c63:	mov    %edx,0x10(%rsp)
 1f80c67:	sub    $0x40,%r13d
 1f80c6b:	mov    $0x40,%edx
 1f80c70:	mov    0xc28(%rdi),%r12
 1f80c77:	mov    $0x0,%r9d
 1f80c7d:	mov    %rax,%r15
 1f80c80:	mov    %rdi,%rax
 1f80c83:	cmovb  0x10(%rsp),%edx
 1f80c88:	cmp    0x20(%rsp),%r14
 1f80c8d:	mov    0x38(%rsp),%r10
 1f80c92:	mov    0x48(%rsp),%r11
 1f80c97:	cmovae %r9d,%edx
 1f80c9b:	mov    $0xffffffffffffffff,%r9
 1f80ca2:	add    %r10,%r12
 1f80ca5:	shlx   %rdx,%r9,%rdi
 1f80caa:	cmp    $0x40,%edx
 1f80cad:	mov    0x58(%r14,%r12,1),%rdx
 1f80cb2:	shrx   %r11,0x18(%r14,%r12,1),%rbp
 1f80cb9:	not    %rdi
 1f80cbc:	cmove  %r9,%rdi
 1f80cc0:	mov    0x48(%r14,%r12,1),%r9
 1f80cc5:	shrx   %r11,0x8(%r14,%r12,1),%r12
 1f80ccc:	add    %rdx,%rdx
 1f80ccf:	shlx   %rsi,%rdx,%rdx
 1f80cd4:	add    %r9,%r9
 1f80cd7:	or     %rbp,%rdx
 1f80cda:	shlx   %rsi,%r9,%rbp
 1f80cdf:	mov    0x60(%rsp),%r9
 1f80ce4:	and    %rdi,%rdx
 1f80ce7:	or     %r12,%rbp
 1f80cea:	and    %rdi,%rbp
 1f80ced:	mov    %rbp,-0x8(%r9,%r8,8)
 1f80cf2:	mov    0xc28(%rax),%r12
 1f80cf9:	mov    0x120(%rsp),%rax
 1f80d01:	add    %r10,%r12
 1f80d04:	shrx   %r11,0x10(%r14,%r12,1),%rbp
 1f80d0b:	mov    0x50(%r14,%r12,1),%r12
 1f80d10:	add    %r12,%r12
 1f80d13:	shlx   %rsi,%r12,%r12
 1f80d18:	or     %rbp,%r12
 1f80d1b:	popcnt %rdx,%rbp
 1f80d20:	and    %rdi,%r12
 1f80d23:	mov    %r15d,%edi
 1f80d26:	mov    0x18(%rsp),%r15
 1f80d2b:	add    %ebp,%edi
 1f80d2d:	mov    %r14d,%ebp
 1f80d30:	mov    %r12,-0x8(%rax,%r8,8)
 1f80d35:	lzcnt  %rdx,%rax
 1f80d3a:	sub    %eax,%ebp
 1f80d3c:	lea    0x40(%r14),%rax
 1f80d40:	add    $0x3f,%ebp
 1f80d43:	test   %rdx,%rdx
 1f80d46:	mov    %ecx,%edx
 1f80d48:	mov    $0x40,%ecx
 1f80d4d:	cmovne %ebp,%edx
 1f80d50:	or     -0x8(%r9,%r8,8),%rbx
 1f80d55:	cmp    $0x40,%r13d
 1f80d59:	mov    $0xffffffffffffffff,%rbp
 1f80d60:	cmovae %ecx,%r13d
 1f80d64:	cmp    0x20(%rsp),%rax
 1f80d69:	mov    0xc28(%r15),%rcx
 1f80d70:	mov    $0x0,%eax
 1f80d75:	cmovae %eax,%r13d
 1f80d79:	add    %r10,%rcx
 1f80d7c:	shlx   %r13,%rbp,%rax
 1f80d81:	cmp    $0x40,%r13d
 1f80d85:	mov    0x98(%r14,%rcx,1),%r13
 1f80d8d:	not    %rax
 1f80d90:	cmove  %rbp,%rax
 1f80d94:	shrx   %r11,0x58(%r14,%rcx,1),%rbp
 1f80d9b:	add    %r13,%r13
 1f80d9e:	shlx   %rsi,%r13,%r13
 1f80da3:	or     %rbp,%r13
 1f80da6:	mov    0x88(%r14,%rcx,1),%rbp
 1f80dae:	shrx   %r11,0x48(%r14,%rcx,1),%rcx
 1f80db5:	and    %rax,%r13
 1f80db8:	add    %rbp,%rbp
 1f80dbb:	shlx   %rsi,%rbp,%rbp
 1f80dc0:	or     %rcx,%rbp
 1f80dc3:	and    %rax,%rbp
 1f80dc6:	mov    %rbp,(%r9,%r8,8)
 1f80dca:	mov    0xc28(%r15),%rcx
 1f80dd1:	add    %r10,%rcx
 1f80dd4:	shrx   %r11,0x50(%r14,%rcx,1),%rbp
 1f80ddb:	mov    0x90(%r14,%rcx,1),%rcx
 1f80de3:	add    %rcx,%rcx
 1f80de6:	shlx   %rsi,%rcx,%r10
 1f80deb:	mov    %r14d,%ecx
 1f80dee:	or     %rbp,%r10
 1f80df1:	and    %rax,%r10
 1f80df4:	popcnt %r13,%rax
 1f80df9:	add    %edi,%eax
 1f80dfb:	lzcnt  %r13,%rdi
 1f80e00:	sub    %edi,%ecx
 1f80e02:	mov    0x18(%rsp),%rdi
 1f80e07:	add    $0x7f,%ecx
 1f80e0a:	test   %r13,%r13
 1f80e0d:	cmove  %edx,%ecx
 1f80e10:	mov    0x120(%rsp),%rdx
 1f80e18:	sub    $0xffffffffffffff80,%r14
 1f80e1c:	mov    %r10,(%rdx,%r8,8)
 1f80e20:	mov    0x10(%rsp),%edx
 1f80e24:	or     (%r9,%r8,8),%rbx
 1f80e28:	add    $0x2,%r8
 1f80e2c:	add    $0xffffff80,%edx
 1f80e2f:	or     %r12,%rbx
 1f80e32:	or     %r10,%rbx
 1f80e35:	cmp    %r14,0x1c0(%rsp)
 1f80e3d:	jne    1f80c60 <node_facts_window_run+0x4710>
 1f80e43:	mov    0x480(%rsp),%rdx
 1f80e4b:	mov    0x650(%rsp),%r12
 1f80e53:	mov    0x200(%rsp),%rbp
 1f80e5b:	mov    0x30(%rsp),%r15
 1f80e60:	mov    0x20(%rsp),%r13
 1f80e65:	mov    $0x40,%r9d
 1f80e6b:	mov    %rbx,%r11
 1f80e6e:	inc    %rdx
 1f80e71:	test   $0x1,%dl
 1f80e74:	je     1f80f7b <node_facts_window_run+0x4a2b>
 1f80e7a:	mov    %r8,%rdx
 1f80e7d:	shl    $0x6,%rdx
 1f80e81:	mov    0xc28(%rdi),%rbx
 1f80e88:	mov    %rdi,%r10
 1f80e8b:	mov    %r13d,%edi
 1f80e8e:	sub    %edx,%edi
 1f80e90:	mov    %rdx,0x10(%rsp)
 1f80e95:	cmp    $0x40,%edi
 1f80e98:	mov    0x48(%rsp),%rbp
 1f80e9d:	cmovae %r9d,%edi
 1f80ea1:	cmp    %r13,%rdx
 1f80ea4:	mov    0x5a0(%rsp),%rdx
 1f80eac:	mov    $0x0,%r9d
 1f80eb2:	cmovae %r9d,%edi
 1f80eb6:	mov    $0xffffffffffffffff,%r9
 1f80ebd:	add    %r8,%rdx
 1f80ec0:	shl    $0x6,%rdx
 1f80ec4:	cmp    $0x40,%edi
 1f80ec7:	shlx   %rdi,%r9,%rdi
 1f80ecc:	mov    0x58(%rbx,%rdx,1),%r13
 1f80ed1:	not    %rdi
 1f80ed4:	shrx   %rbp,0x18(%rbx,%rdx,1),%r14
 1f80edb:	cmove  %r9,%rdi
 1f80edf:	add    %r13,%r13
 1f80ee2:	shlx   %rsi,%r13,%r9
 1f80ee7:	mov    0x48(%rbx,%rdx,1),%r13
 1f80eec:	shrx   %rbp,0x8(%rbx,%rdx,1),%rbx
 1f80ef3:	or     %r14,%r9
 1f80ef6:	and    %rdi,%r9
 1f80ef9:	add    %r13,%r13
 1f80efc:	shlx   %rsi,%r13,%r14
 1f80f01:	mov    0x280(%rsp),%r13
 1f80f09:	or     %rbx,%r14
 1f80f0c:	and    %rdi,%r14
 1f80f0f:	mov    %r14,0x0(%r13,%r8,8)
 1f80f14:	mov    0xc28(%r10),%rbx
 1f80f1b:	shrx   %rbp,0x10(%rbx,%rdx,1),%r10
 1f80f22:	mov    0x50(%rbx,%rdx,1),%rbx
 1f80f27:	mov    %ecx,%edx
 1f80f29:	mov    %eax,%ecx
 1f80f2b:	popcnt %r9,%rax
 1f80f30:	mov    0x200(%rsp),%rbp
 1f80f38:	add    %ecx,%eax
 1f80f3a:	mov    0x10(%rsp),%rcx
 1f80f3f:	add    %rbx,%rbx
 1f80f42:	shlx   %rsi,%rbx,%rsi
 1f80f47:	add    $0x3f,%ecx
 1f80f4a:	or     %r10,%rsi
 1f80f4d:	and    %rdi,%rsi
 1f80f50:	lzcnt  %r9,%rdi
 1f80f55:	sub    %edi,%ecx
 1f80f57:	test   %r9,%r9
 1f80f5a:	mov    0x18(%rsp),%rdi
 1f80f5f:	cmove  %edx,%ecx
 1f80f62:	mov    0x400(%rsp),%rdx
 1f80f6a:	mov    %rsi,(%rdx,%r8,8)
 1f80f6e:	or     0x0(%r13,%r8,8),%r11
 1f80f73:	mov    0x20(%rsp),%r13
 1f80f78:	or     %rsi,%r11
 1f80f7b:	mov    %rdi,%r10
 1f80f7e:	test   %r13d,%r13d
 1f80f81:	je     1f80fb2 <node_facts_window_run+0x4a62>
 1f80f83:	lea    -0x1(%r13),%rdi
 1f80f87:	mov    $0xffffffff,%r15d
 1f80f8d:	shr    $0x4,%rdi
 1f80f91:	inc    %rdi
 1f80f94:	mov    %edi,%esi
 1f80f96:	and    $0x3,%esi
 1f80f99:	cmp    $0x31,%r13d
 1f80f9d:	jae    1f80fc5 <node_facts_window_run+0x4a75>
 1f80f9f:	vpxor  %xmm0,%xmm0,%xmm0
 1f80fa3:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f80faa:	xor    %r8d,%r8d
 1f80fad:	jmp    1f81114 <node_facts_window_run+0x4bc4>
 1f80fb2:	mov    0x28(%rsp),%r14
 1f80fb7:	xor    %r9d,%r9d
 1f80fba:	mov    $0xffffffff,%r8d
 1f80fc0:	jmp    1f811f0 <node_facts_window_run+0x4ca0>
 1f80fc5:	mov    %r12,0x650(%rsp)
 1f80fcd:	and    $0xfffffffffffffffc,%rdi
 1f80fd1:	lea    -0x30(%r13),%r10d
 1f80fd5:	lea    -0x20(%r13),%ebx
 1f80fd9:	lea    -0x10(%r13),%r14d
 1f80fdd:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
 1f80fe4:	mov    $0xffff,%r12d
 1f80fea:	vpxor  %xmm0,%xmm0,%xmm0
 1f80fee:	mov    0xe8(%rsp),%rdx
 1f80ff6:	mov    0x180(%rsp),%r8
 1f80ffe:	lea    (%rdx,%r8,4),%r9
 1f81002:	xor    %r8d,%r8d
 1f81005:	data16 cs nopw 0x0(%rax,%rax,1)
 1f81010:	lea    0x0(%r13,%r8,1),%rdx
 1f81015:	shlx   %edx,%r15d,%ebp
 1f8101a:	sub    $0x10,%rdx
 1f8101e:	not    %ebp
 1f81020:	cmovae %r12d,%ebp
 1f81024:	cmp    $0x10,%rdx
 1f81028:	kmovd  %ebp,%k1
 1f8102c:	lea    (%r14,%r8,1),%ebp
 1f81030:	vmovdqu32 -0xc0(%r9),%zmm2{%k1}{z}
 1f81037:	shlx   %ebp,%r15d,%edx
 1f8103c:	lea    (%rbx,%r8,1),%ebp
 1f81040:	not    %edx
 1f81042:	cmovae %r12d,%edx
 1f81046:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f8104d:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f81053:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f81059:	kmovd  %edx,%k1
 1f8105d:	lea    -0x20(%r13,%r8,1),%rdx
 1f81062:	vmovdqu32 -0x80(%r9),%zmm2{%k1}{z}
 1f81069:	cmp    $0x10,%rdx
 1f8106d:	shlx   %ebp,%r15d,%edx
 1f81072:	lea    (%r10,%r8,1),%ebp
 1f81076:	not    %edx
 1f81078:	cmovae %r12d,%edx
 1f8107c:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f81083:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f81089:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f8108f:	kmovd  %edx,%k1
 1f81093:	lea    -0x30(%r13,%r8,1),%rdx
 1f81098:	vmovdqu32 -0x40(%r9),%zmm2{%k1}{z}
 1f8109f:	cmp    $0x10,%rdx
 1f810a3:	shlx   %ebp,%r15d,%edx
 1f810a8:	not    %edx
 1f810aa:	cmovae %r12d,%edx
 1f810ae:	add    $0xffffffffffffffc0,%r8
 1f810b2:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f810b9:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f810bf:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f810c5:	kmovd  %edx,%k1
 1f810c9:	vmovdqu32 (%r9),%zmm2{%k1}{z}
 1f810cf:	add    $0x100,%r9
 1f810d6:	add    $0xfffffffffffffffc,%rdi
 1f810da:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f810e1:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f810e7:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f810ed:	jne    1f81010 <node_facts_window_run+0x4ac0>
 1f810f3:	mov    0x18(%rsp),%r10
 1f810f8:	mov    0x650(%rsp),%r12
 1f81100:	test   %rsi,%rsi
 1f81103:	je     1f8156d <node_facts_window_run+0x501d>
 1f81109:	mov    0x200(%rsp),%rbp
 1f81111:	neg    %r8
 1f81114:	mov    $0xffff,%ebx
 1f81119:	mov    0x180(%rsp),%rdx
 1f81121:	mov    0x20(%rsp),%rdi
 1f81126:	mov    0x28(%rsp),%r14
 1f8112b:	shl    $0x4,%esi
 1f8112e:	lea    0x0(,%rdx,4),%rdx
 1f81136:	sub    %r8,%rdi
 1f81139:	lea    (%rdx,%r8,4),%rdx
 1f8113d:	add    0x7b0(%rsp),%rdx
 1f81145:	xor    %r8d,%r8d
 1f81148:	nopl   0x0(%rax,%rax,1)
 1f81150:	mov    %edi,%r9d
 1f81153:	sub    $0x10,%rdi
 1f81157:	shlx   %r9d,%r15d,%r9d
 1f8115c:	not    %r9d
 1f8115f:	cmovae %ebx,%r9d
 1f81163:	kmovd  %r9d,%k1
 1f81168:	vmovdqu32 (%rdx,%r8,4),%zmm2{%k1}{z}
 1f8116f:	add    $0x10,%r8
 1f81173:	vpcmpltud %zmm3,%zmm2,%k1{%k1}
 1f8117a:	vpminud %zmm2,%zmm1,%zmm1{%k1}
 1f81180:	vpmaxud %zmm2,%zmm0,%zmm0{%k1}
 1f81186:	cmp    %r8,%rsi
 1f81189:	jne    1f81150 <node_facts_window_run+0x4c00>
 1f8118b:	vextracti64x4 $0x1,%zmm1,%ymm2
 1f81192:	mov    0x30(%rsp),%r15
 1f81197:	vpminud %ymm2,%ymm1,%ymm1
 1f8119c:	vextracti128 $0x1,%ymm1,%xmm2
 1f811a2:	vpminud %xmm2,%xmm1,%xmm1
 1f811a7:	vpshufd $0xee,%xmm1,%xmm2
 1f811ac:	vpminud %xmm2,%xmm1,%xmm1
 1f811b1:	vpshufd $0x55,%xmm1,%xmm2
 1f811b6:	vpminud %xmm2,%xmm1,%xmm1
 1f811bb:	vmovd  %xmm1,%r8d
 1f811c0:	vextracti64x4 $0x1,%zmm0,%ymm1
 1f811c7:	vpmaxud %ymm1,%ymm0,%ymm0
 1f811cc:	vextracti128 $0x1,%ymm0,%xmm1
 1f811d2:	vpmaxud %xmm1,%xmm0,%xmm0
 1f811d7:	vpshufd $0xee,%xmm0,%xmm1
 1f811dc:	vpmaxud %xmm1,%xmm0,%xmm0
 1f811e1:	vpshufd $0x55,%xmm0,%xmm1
 1f811e6:	vpmaxud %xmm1,%xmm0,%xmm0
 1f811eb:	vmovd  %xmm0,%r9d
 1f811f0:	mov    0x300(%rsp),%edx
 1f811f7:	and    $0x100,%edx
 1f811fd:	mov    0x340(%rsp),%esi
 1f81204:	or     %rdx,%r15
 1f81207:	mov    0x5e0(%rsp),%rdx
 1f8120f:	cmp    0x20(%rsp),%esi
 1f81213:	mov    %r15,0x30(%rsp)
 1f81218:	mov    %edx,%edi
 1f8121a:	cmovbe %ebp,%edi
 1f8121d:	mov    0x422c(%r14,%rdi,4),%esi
 1f81225:	ja     1f81231 <node_facts_window_run+0x4ce1>
 1f81227:	mov    %r10,%r14
 1f8122a:	xor    %edx,%edx
 1f8122c:	xor    %r10d,%r10d
 1f8122f:	jmp    1f81259 <node_facts_window_run+0x4d09>
 1f81231:	mov    %r10,%r14
 1f81234:	mov    0xc28(%r10),%r10
 1f8123b:	mov    %rdx,%r15
 1f8123e:	mov    %r15d,%ebx
 1f81241:	and    $0xffffffc0,%ebx
 1f81244:	shrx   %rdx,0x8(%r10,%rbx,1),%rdx
 1f8124b:	shrx   %r15,0x10(%r10,%rbx,1),%r10
 1f81252:	and    $0x1,%edx
 1f81255:	and    $0x1,%r10d
 1f81259:	mov    0x480(%rsp),%rbp
 1f81261:	mov    0x20(%rsp),%r15
 1f81266:	mov    0x280(%rsp),%r13
 1f8126e:	or     %rdx,%r11
 1f81271:	or     %r10,%r11
 1f81274:	shlx   %r15,%rdx,%rbx
 1f81279:	shl    $0x3,%ebp
 1f8127c:	mov    %r9d,%edx
 1f8127f:	or     %rbx,0x0(%r13,%rbp,1)
 1f81284:	shlx   %r15,%r10,%rbx
 1f81289:	mov    0x400(%rsp),%r15
 1f81291:	or     %rbx,(%r15,%rbp,1)
 1f81295:	cmp    %r8d,%esi
 1f81298:	mov    %r8d,%ebx
 1f8129b:	mov    0x30(%rsp),%rbp
 1f812a0:	cmovb  %esi,%ebx
 1f812a3:	cmp    %r9d,%esi
 1f812a6:	cmova  %esi,%edx
 1f812a9:	cmp    0xc8(%rsp),%esi
 1f812b0:	cmovae %r9d,%edx
 1f812b4:	cmovae %r8d,%ebx
 1f812b8:	mov    0x3c0(%rsp),%r8
 1f812c0:	mov    0x180(%rsp),%r9
 1f812c8:	mov    %edx,%r10d
 1f812cb:	mov    0x380(%rsp),%rdx
 1f812d3:	mov    %rbp,(%r8)
 1f812d6:	mov    %r13,0x8(%r8)
 1f812da:	mov    %r15,0x10(%r8)
 1f812de:	mov    %edx,0x18(%r8)
 1f812e2:	mov    0xc00(%r14),%rdx
 1f812e9:	add    %r9,%rdx
 1f812ec:	mov    %rdx,0x20(%r8)
 1f812f0:	mov    0xc10(%r14),%rdx
 1f812f7:	add    %r9,%rdx
 1f812fa:	mov    %rdx,0x28(%r8)
 1f812fe:	mov    0x4e0(%rsp),%edx
 1f81305:	mov    %r10d,0x10(%rsp)
 1f8130a:	add    0xc18(%r14),%r9
 1f81311:	shl    $0x2,%edx
 1f81314:	mov    %r9,0x30(%r8)
 1f81318:	mov    0x300(%rsp),%r9d
 1f81320:	mov    %ebx,0x38(%r8)
 1f81324:	mov    %r10d,0x3c(%r8)
 1f81328:	mov    $0x0,%r10d
 1f8132e:	mov    %eax,0x40(%r8)
 1f81332:	mov    %ecx,0x44(%r8)
 1f81336:	mov    %edx,0x48(%r8)
 1f8133a:	and    $0x80,%r9d
 1f81341:	cmpl   $0x0,0xa0(%rsp)
 1f81349:	mov    %r9d,0x4c(%r8)
 1f8134d:	je     1f81382 <node_facts_window_run+0x4e32>
 1f8134f:	cmp    0xc8(%rsp),%esi
 1f81356:	mov    %esi,%edx
 1f81358:	cmovae %r10d,%edx
 1f8135c:	jae    1f81382 <node_facts_window_run+0x4e32>
 1f8135e:	mov    0xbf8(%r14),%r8
 1f81365:	mov    %edx,%r9d
 1f81368:	mov    $0x1,%r15d
 1f8136e:	shr    $0x6,%edx
 1f81371:	mov    $0x6,%r13d
 1f81377:	shlx   %r9,%r15,%r9
 1f8137c:	and    (%r8,%rdx,8),%r9
 1f81380:	jne    1f8139a <node_facts_window_run+0x4e4a>
 1f81382:	mov    0xe0(%rsp),%rdx
 1f8138a:	movzbl (%rdx,%rdi,1),%edx
 1f8138e:	and    $0x7f,%edx
 1f81391:	movzbl 0x540(%r14,%rdx,1),%r13d
 1f8139a:	mov    0x20(%rsp),%r9
 1f8139f:	mov    %rbp,%r15
 1f813a2:	mov    0x200(%rsp),%rbp
 1f813aa:	mov    0xc28(%r14),%r8
 1f813b1:	mov    0x520(%rsp),%r14
 1f813b9:	cmp    %r9d,0x340(%rsp)
 1f813c1:	mov    %ebp,%edi
 1f813c3:	setbe  %dl
 1f813c6:	inc    %ecx
 1f813c8:	and    $0xffffffc0,%edi
 1f813cb:	and    $0x22,%r14d
 1f813cf:	xor    %r9d,%ecx
 1f813d2:	mov    0xb8(%rsp),%r9d
 1f813da:	shrx   %rbp,0x20(%r8,%rdi,1),%rdi
 1f813e1:	mov    %eax,%r8d
 1f813e4:	xor    $0x1,%r8d
 1f813e8:	cmp    $0x2,%r13d
 1f813ec:	mov    $0x0,%ebp
 1f813f1:	cmovne %r10d,%r9d
 1f813f5:	test   %r14d,%r14d
 1f813f8:	cmove  %r14d,%r9d
 1f813fc:	test   %r11,%r11
 1f813ff:	mov    0x8(%rsp),%r11
 1f81404:	setne  %r10b
 1f81408:	or     %dl,%r10b
 1f8140b:	or     %ecx,%r8d
 1f8140e:	mov    0x18(%rsp),%rcx
 1f81413:	cmovne 0x98(%rsp),%ebp
 1f8141b:	test   %eax,%eax
 1f8141d:	mov    %r13d,0x20(%rsp)
 1f81422:	mov    0x50(%rsp),%rdx
 1f81427:	cmove  %eax,%ebp
 1f8142a:	movzbl %r10b,%eax
 1f8142e:	or     %eax,%ebp
 1f81430:	xor    %eax,%eax
 1f81432:	test   %r13d,%r13d
 1f81435:	sete   %al
 1f81438:	or     %r9d,%ebp
 1f8143b:	andn   %eax,%edi,%eax
 1f81440:	mov    %rcx,%rdi
 1f81443:	mov    $0x101,%ecx
 1f81448:	or     %eax,%ebp
 1f8144a:	mov    0xa80(%r11),%rax
 1f81451:	movzbl (%rax,%r12,1),%eax
 1f81456:	bextr  %ecx,%eax,%eax
 1f8145b:	or     %eax,%ebp
 1f8145d:	xor    %eax,%eax
 1f8145f:	cmp    $0x6,%r13d
 1f81463:	mov    0x28(%rsp),%r13
 1f81468:	sete   %al
 1f8146b:	lea    (%rdx,%rax,4),%r14
 1f8146f:	or     %r15,%r14
 1f81472:	cmpb   $0x1,0x3a(%rdi)
 1f81476:	jne    1f814cc <node_facts_window_run+0x4f7c>
 1f81478:	mov    0x40(%rsp),%r9
 1f8147d:	test   %ebp,%ebp
 1f8147f:	jne    1f814d1 <node_facts_window_run+0x4f81>
 1f81481:	mov    0xd8(%rsp),%rax
 1f81489:	mov    0x8(%rax),%rdx
 1f8148d:	mov    0x78(%rdx),%eax
 1f81490:	cmp    %eax,%esi
 1f81492:	jae    1f814d1 <node_facts_window_run+0x4f81>
 1f81494:	mov    0x98(%rdx),%rcx
 1f8149b:	mov    %rdi,%r8
 1f8149e:	movzbl (%rcx,%rsi,1),%edi
 1f814a2:	cmp    $0x4a,%edi
 1f814a5:	je     1f814c0 <node_facts_window_run+0x4f70>
 1f814a7:	cmp    $0x1e,%edi
 1f814aa:	jne    1f814c7 <node_facts_window_run+0x4f77>
 1f814ac:	mov    0xa8(%rdx),%rdx
 1f814b3:	mov    (%rdx,%rsi,4),%edx
 1f814b6:	cmp    %eax,%edx
 1f814b8:	jae    1f814c7 <node_facts_window_run+0x4f77>
 1f814ba:	cmpb   $0x4a,(%rcx,%rdx,1)
 1f814be:	jne    1f814c7 <node_facts_window_run+0x4f77>
 1f814c0:	or     $0x1000000,%r14
 1f814c7:	mov    %r8,%rdi
 1f814ca:	jmp    1f814d1 <node_facts_window_run+0x4f81>
 1f814cc:	mov    0x40(%rsp),%r9
 1f814d1:	cmpl   $0x0,0xbf0(%rdi)
 1f814d8:	jne    1f8157f <node_facts_window_run+0x502f>
 1f814de:	cmp    0xbd8(%rdi),%ebx
 1f814e4:	ja     1f814f6 <node_facts_window_run+0x4fa6>
 1f814e6:	mov    0x10(%rsp),%eax
 1f814ea:	cmp    0xbd4(%rdi),%eax
 1f814f0:	jae    1f8157f <node_facts_window_run+0x502f>
 1f814f6:	mov    0x3c0(%rsp),%rax
 1f814fe:	mov    0x20(%rsp),%ecx
 1f81502:	mov    0x10(%rsp),%edx
 1f81506:	mov    0x380(%rsp),%rsi
 1f8150e:	add    0x560(%rsp),%esi
 1f81515:	mov    %r14,0x50(%rax)
 1f81519:	mov    %cl,0x60(%rax)
 1f8151c:	mov    %ebx,0x58(%rax)
 1f8151f:	mov    %edx,0x5c(%rax)
 1f81522:	mov    %bpl,0x62(%rax)
 1f81526:	mov    0x2c0(%rsp),%rdx
 1f8152e:	or     0xc0(%rsp),%ebp
 1f81535:	mov    $0xffffffffffffffff,%rbx
 1f8153c:	mov    0xc78(%rdi),%rax
 1f81543:	mov    %esi,%r14d
 1f81546:	mov    %edx,%ecx
 1f81548:	add    %ebp,%edx
 1f8154a:	mov    %rdx,0x2c0(%rsp)
 1f81552:	mov    %r12d,(%rax,%rcx,4)
 1f81556:	mov    0xa8(%rsp),%rbp
 1f8155e:	jmp    1f80834 <node_facts_window_run+0x42e4>
 1f81563:	mov    0x8(%rsp),%r11
 1f81568:	jmp    1f80a9e <node_facts_window_run+0x454e>
 1f8156d:	mov    0x200(%rsp),%rbp
 1f81575:	mov    0x28(%rsp),%r14
 1f8157a:	jmp    1f8118b <node_facts_window_run+0x4c3b>
 1f8157f:	mov    0x10(%rsp),%ecx
 1f81583:	mov    %ebx,%edx
 1f81585:	vmovdqu64 %zmm3,0x120(%rsp)
 1f81590:	vzeroupper
 1f81593:	call   1f69550 <node_census_reader_marks>
 1f81598:	vmovdqu64 0x120(%rsp),%zmm3
 1f815a3:	mov    0x18(%rsp),%rdi
 1f815a8:	mov    0x40(%rsp),%r9
 1f815ad:	mov    0x8(%rsp),%r11
 1f815b2:	or     %rax,%r14
 1f815b5:	jmp    1f814f6 <node_facts_window_run+0x4fa6>
 1f815ba:	rdtsc
 1f815bc:	mov    %rdx,0x48(%rsp)
 1f815c1:	mov    %rax,0x120(%rsp)
 1f815c9:	cmpb   $0x0,0x78(%rsp)
 1f815ce:	je     1f81748 <node_facts_window_run+0x51f8>
 1f815d4:	cmpl   $0x0,0xa88(%r11)
 1f815dc:	je     1f81748 <node_facts_window_run+0x51f8>
 1f815e2:	mov    $0xffffffffffffffff,%rdx
 1f815e9:	xor    %r9d,%r9d
 1f815ec:	xor    %ecx,%ecx
 1f815ee:	jmp    1f81603 <node_facts_window_run+0x50b3>
 1f815f0:	mov    0xa88(%r11),%eax
 1f815f7:	inc    %rcx
 1f815fa:	cmp    %rax,%rcx
 1f815fd:	jae    1f81748 <node_facts_window_run+0x51f8>
 1f81603:	imul   $0x68,%rcx,%r10
 1f81607:	cmpb   $0x0,0x61(%rbp,%r10,1)
 1f8160d:	je     1f815f0 <node_facts_window_run+0x50a0>
 1f8160f:	mov    0xa60(%r11),%rdi
 1f81616:	mov    0xa68(%r11),%r8
 1f8161d:	add    %rbp,%r10
 1f81620:	mov    $0x40,%esi
 1f81625:	mov    (%rdi,%rcx,4),%eax
 1f81628:	mov    (%r8,%rcx,4),%r11d
 1f8162c:	mov    0x10(%r10),%r8
 1f81630:	mov    %rax,0x20(%rsp)
 1f81635:	mov    %rcx,0x10(%rsp)
 1f8163a:	mov    0x651b8(%r13,%r11,4),%edi
 1f81642:	mov    0x18(%rsp),%rcx
 1f81647:	sub    0xc68(%rcx),%r8
 1f8164e:	add    0xc70(%rcx),%r8
 1f81655:	cmpl   $0x0,0x18(%r10)
 1f8165a:	je     1f816eb <node_facts_window_run+0x519b>
 1f81660:	sub    %edi,%r11d
 1f81663:	mov    %edi,%r13d
 1f81666:	xor    %r15d,%r15d
 1f81669:	xor    %r12d,%r12d
 1f8166c:	mov    %edi,%ebp
 1f8166e:	inc    %r11d
 1f81671:	mov    %r11d,%ebx
 1f81674:	and    $0x3f,%r11d
 1f81678:	and    $0xffffffc0,%ebx
 1f8167b:	mov    %r11d,%r14d
 1f8167e:	xor    $0x3f,%r14d
 1f81682:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81690:	sub    $0x40,%ebp
 1f81693:	cmovae %esi,%r13d
 1f81697:	cmp    %r15d,%edi
 1f8169a:	cmovbe %r9d,%r13d
 1f8169e:	mov    0xc28(%rcx),%r9
 1f816a5:	add    %rbx,%r9
 1f816a8:	cmp    $0x40,%r13d
 1f816ac:	shlx   %r13,%rdx,%r13
 1f816b1:	shrx   %r11,(%r15,%r9,1),%rax
 1f816b7:	mov    0x40(%r15,%r9,1),%r9
 1f816bc:	not    %r13
 1f816bf:	cmove  %rdx,%r13
 1f816c3:	add    $0x40,%r15
 1f816c7:	add    %r9,%r9
 1f816ca:	shlx   %r14,%r9,%r9
 1f816cf:	or     %rax,%r9
 1f816d2:	and    %r13,%r9
 1f816d5:	mov    %ebp,%r13d
 1f816d8:	mov    %r9,(%r8,%r12,8)
 1f816dc:	inc    %r12
 1f816df:	xor    %r9d,%r9d
 1f816e2:	mov    0x18(%r10),%eax
 1f816e6:	cmp    %rax,%r12
 1f816e9:	jb     1f81690 <node_facts_window_run+0x5140>
 1f816eb:	mov    0x8(%rsp),%r11
 1f816f0:	mov    0x10(%rsp),%rcx
 1f816f5:	mov    0x28(%rsp),%r13
 1f816fa:	mov    0xa8(%rsp),%rbp
 1f81702:	mov    0xa50(%r11),%r10
 1f81709:	cmp    %edi,(%r10,%rcx,4)
 1f8170d:	jbe    1f815f0 <node_facts_window_run+0x50a0>
 1f81713:	mov    0x18(%rsp),%rax
 1f81718:	mov    0x20(%rsp),%rsi
 1f8171d:	mov    0xc28(%rax),%rax
 1f81724:	mov    %esi,%r9d
 1f81727:	and    $0xffffffc0,%r9d
 1f8172b:	shrx   %rsi,(%rax,%r9,1),%rax
 1f81731:	xor    %r9d,%r9d
 1f81734:	and    $0x1,%eax
 1f81737:	shlx   %rdi,%rax,%rax
 1f8173c:	shr    $0x6,%edi
 1f8173f:	or     %rax,(%r8,%rdi,8)
 1f81743:	jmp    1f815f0 <node_facts_window_run+0x50a0>
 1f81748:	shlq   $0x20,0x100(%rsp)
 1f81751:	shlq   $0x20,0x460(%rsp)
 1f8175a:	shlq   $0x20,0x440(%rsp)
 1f81763:	shlq   $0x20,0x48(%rsp)
 1f81769:	lea    0x880(%rsp),%rdi
 1f81771:	mov    $0x418,%edx
 1f81776:	mov    0xd0(%rsp),%rbx
 1f8177e:	mov    %rbx,%rsi
 1f81781:	vzeroupper
 1f81784:	call   355bd30 <memcpy>
 1f81789:	mov    0x2c0(%rsp),%rax
 1f81791:	movb   $0x0,0x59(%rbx)
 1f81795:	test   %eax,%eax
 1f81797:	je     1f81a44 <node_facts_window_run+0x54f4>
 1f8179d:	mov    0x8(%rsp),%rdi
 1f817a2:	mov    0x18(%rsp),%r9
 1f817a7:	mov    %eax,%eax
 1f817a9:	xor    %r12d,%r12d
 1f817ac:	mov    %rax,0x10(%rsp)
 1f817b1:	jmp    1f81807 <node_facts_window_run+0x52b7>
 1f817b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f817c0:	movzbl 0x750(%rsp),%ecx
 1f817c8:	mov    0x8(%rsp),%rdi
 1f817cd:	mov    0x18(%rsp),%r9
 1f817d2:	xor    %edx,%edx
 1f817d4:	add    %rdx,0x880(%r8)
 1f817db:	mov    %rax,0x50(%rbp)
 1f817df:	mov    %cl,0x60(%rbp)
 1f817e2:	mov    0x10(%rsp),%rcx
 1f817e7:	inc    %r12
 1f817ea:	mov    0x624(%r9),%eax
 1f817f1:	mov    %eax,0x58(%rbp)
 1f817f4:	mov    0x628(%r9),%eax
 1f817fb:	mov    %eax,0x5c(%rbp)
 1f817fe:	cmp    %r12,%rcx
 1f81801:	je     1f819d5 <node_facts_window_run+0x5485>
 1f81807:	mov    0xc78(%r9),%rax
 1f8180e:	mov    0xa60(%rdi),%r8
 1f81815:	mov    0xa68(%rdi),%rcx
 1f8181c:	mov    %r13,%r15
 1f8181f:	mov    (%rax,%r12,4),%ebp
 1f81823:	mov    0xa50(%rdi),%rax
 1f8182a:	mov    (%r8,%rbp,4),%r14d
 1f8182e:	mov    (%rcx,%rbp,4),%r13d
 1f81832:	mov    0xa40(%rdi),%r8
 1f81839:	mov    0xa48(%rdi),%rcx
 1f81840:	mov    0xd0(%rsp),%rdi
 1f81848:	mov    (%rcx,%rbp,4),%ebx
 1f8184b:	mov    (%r8,%rbp,4),%esi
 1f8184f:	mov    (%rax,%rbp,4),%ecx
 1f81852:	mov    %ebx,%edx
 1f81854:	call   1f52a90 <node_machine_type>
 1f81859:	mov    0x8(%rsp),%rax
 1f8185e:	mov    0x18(%rsp),%rdi
 1f81863:	mov    0xa50(%rax),%rax
 1f8186a:	mov    (%rax,%rbp,4),%eax
 1f8186d:	cmp    0x651b8(%r15,%r13,4),%eax
 1f81875:	jbe    1f818b0 <node_facts_window_run+0x5360>
 1f81877:	inc    %r13d
 1f8187a:	cmp    %r13d,%r14d
 1f8187d:	je     1f818b0 <node_facts_window_run+0x5360>
 1f8187f:	mov    0xc00(%rdi),%rdx
 1f81886:	mov    0xc10(%rdi),%rsi
 1f8188d:	mov    %r13d,%eax
 1f81890:	mov    0xc18(%rdi),%rcx
 1f81897:	movzbl (%rdx,%r14,1),%r8d
 1f8189c:	mov    %r8b,(%rdx,%rax,1)
 1f818a0:	movzbl (%rsi,%r14,1),%edx
 1f818a5:	mov    %dl,(%rsi,%rax,1)
 1f818a8:	movzbl (%rcx,%r14,1),%edx
 1f818ad:	mov    %dl,(%rcx,%rax,1)
 1f818b0:	mov    0x28(%rsp),%r13
 1f818b5:	xor    %r9d,%r9d
 1f818b8:	mov    $0xffffffff,%r8d
 1f818be:	mov    0x422c(%r13,%r14,4),%ecx
 1f818c6:	cmpb   $0x23,0x2c(%r13,%r14,1)
 1f818cc:	jne    1f81901 <node_facts_window_run+0x53b1>
 1f818ce:	cmp    0xc8(%rsp),%ecx
 1f818d5:	jae    1f81901 <node_facts_window_run+0x53b1>
 1f818d7:	mov    0xd8(%rsp),%rdx
 1f818df:	mov    0x338(%rdx),%rax
 1f818e6:	mov    (%rdx),%rsi
 1f818e9:	mov    (%rax,%rcx,4),%r8d
 1f818ed:	cmp    0x754(%rsi),%r8d
 1f818f4:	jae    1f81901 <node_facts_window_run+0x53b1>
 1f818f6:	mov    0x1e8(%rdx),%rax
 1f818fd:	mov    (%rax,%r8,4),%r9d
 1f81901:	imul   $0x68,%rbp,%rbp
 1f81905:	add    0xa8(%rsp),%rbp
 1f8190d:	cmpb   $0x0,0x78(%rsp)
 1f81912:	movb   $0x0,0x750(%rsp)
 1f8191a:	je     1f81930 <node_facts_window_run+0x53e0>
 1f8191c:	mov    0x10(%rbp),%rax
 1f81920:	sub    0xc68(%rdi),%rax
 1f81927:	add    0xc70(%rdi),%rax
 1f8192e:	jmp    1f81932 <node_facts_window_run+0x53e2>
 1f81930:	xor    %eax,%eax
 1f81932:	movzbl 0x78(%rsp),%edx
 1f81937:	mov    %rax,0x5c8(%rdi)
 1f8193e:	mov    0xe0(%rsp),%rax
 1f81946:	mov    %ebx,%esi
 1f81948:	mov    %dl,0x5d0(%rdi)
 1f8194e:	movzbl (%rax,%r14,1),%edx
 1f81953:	push   %rbp
 1f81954:	lea    0x758(%rsp),%rax
 1f8195c:	push   %rax
 1f8195d:	call   1f54330 <node_census_reader_expression>
 1f81962:	add    $0x10,%rsp
 1f81966:	cmpb   $0x1,0x62(%rbp)
 1f8196a:	mov    0x40(%rsp),%r8
 1f8196f:	adcq   $0x0,0x878(%r8)
 1f81977:	cmpb   $0x0,0x62(%rbp)
 1f8197b:	jne    1f817c0 <node_facts_window_run+0x5270>
 1f81981:	movzbl 0x750(%rsp),%ecx
 1f81989:	mov    0x8(%rsp),%rdi
 1f8198e:	mov    $0x1,%edx
 1f81993:	cmp    0x50(%rbp),%rax
 1f81997:	jne    1f819cb <node_facts_window_run+0x547b>
 1f81999:	mov    0x18(%rsp),%r9
 1f8199e:	cmp    0x60(%rbp),%cl
 1f819a1:	jne    1f817d4 <node_facts_window_run+0x5284>
 1f819a7:	mov    0x624(%r9),%esi
 1f819ae:	cmp    0x58(%rbp),%esi
 1f819b1:	jne    1f817d4 <node_facts_window_run+0x5284>
 1f819b7:	mov    0x628(%r9),%esi
 1f819be:	xor    %edx,%edx
 1f819c0:	cmp    0x5c(%rbp),%esi
 1f819c3:	setne  %dl
 1f819c6:	jmp    1f817d4 <node_facts_window_run+0x5284>
 1f819cb:	mov    0x18(%rsp),%r9
 1f819d0:	jmp    1f817d4 <node_facts_window_run+0x5284>
 1f819d5:	rdtsc
 1f819d7:	xor    %ebx,%ebx
 1f819d9:	mov    %rdi,%r14
 1f819dc:	mov    %r9,%r15
 1f819df:	shl    $0x20,%rdx
 1f819e3:	or     %rax,%rdx
 1f819e6:	mov    %rdx,0x38(%rsp)
 1f819eb:	mov    0x90(%rsp),%r12
 1f819f3:	mov    0xd0(%rsp),%rbp
 1f819fb:	nopl   0x0(%rax,%rax,1)
 1f81a00:	mov    0xc78(%r15),%rax
 1f81a07:	mov    0xa40(%r14),%rcx
 1f81a0e:	mov    0xa48(%r14),%rdx
 1f81a15:	mov    %rbp,%rdi
 1f81a18:	mov    (%rax,%rbx,4),%eax
 1f81a1b:	mov    (%rcx,%rax,4),%esi
 1f81a1e:	mov    0xa50(%r14),%rcx
 1f81a25:	mov    (%rdx,%rax,4),%edx
 1f81a28:	mov    (%rcx,%rax,4),%ecx
 1f81a2b:	call   1f52a90 <node_machine_type>
 1f81a30:	inc    %rbx
 1f81a33:	cmp    %rbx,0x10(%rsp)
 1f81a38:	jne    1f81a00 <node_facts_window_run+0x54b0>
 1f81a3a:	mov    0xa8(%rsp),%rbp
 1f81a42:	jmp    1f81a5a <node_facts_window_run+0x550a>
 1f81a44:	rdtsc
 1f81a46:	shl    $0x20,%rdx
 1f81a4a:	or     %rax,%rdx
 1f81a4d:	mov    %rdx,0x38(%rsp)
 1f81a52:	mov    0x90(%rsp),%r12
 1f81a5a:	mov    0x100(%rsp),%rax
 1f81a62:	lea    0x880(%rsp),%rsi
 1f81a6a:	or     %rax,0x108(%rsp)
 1f81a72:	mov    0x460(%rsp),%rax
 1f81a7a:	or     %rax,0x710(%rsp)
 1f81a82:	rdtsc
 1f81a84:	mov    0x440(%rsp),%rcx
 1f81a8c:	shl    $0x20,%rdx
 1f81a90:	or     %rcx,0x6d0(%rsp)
 1f81a98:	mov    0x48(%rsp),%rcx
 1f81a9d:	or     %rcx,0x120(%rsp)
 1f81aa5:	or     %rax,%rdx
 1f81aa8:	mov    %rdx,0x48(%rsp)
 1f81aad:	mov    $0x418,%edx
 1f81ab2:	mov    0xd0(%rsp),%rdi
 1f81aba:	call   355bd30 <memcpy>
 1f81abf:	mov    0x8(%rsp),%r11
 1f81ac4:	cmpl   $0x0,0xa88(%r11)
 1f81acc:	je     1f81d6a <node_facts_window_run+0x581a>
 1f81ad2:	xorb   $0x1,0x78(%rsp)
 1f81ad7:	add    $0x62,%rbp
 1f81adb:	xor    %r15d,%r15d
 1f81ade:	xor    %eax,%eax
 1f81ae0:	mov    0x40(%rsp),%r8
 1f81ae5:	mov    0x18(%rsp),%rdi
 1f81aea:	jmp    1f81b12 <node_facts_window_run+0x55c2>
 1f81aec:	nopl   0x0(%rax)
 1f81af0:	mov    0x90(%rsp),%r12
 1f81af8:	mov    0xa88(%r11),%ecx
 1f81aff:	inc    %r15
 1f81b02:	add    $0x68,%rbp
 1f81b06:	mov    %rbx,%rax
 1f81b09:	cmp    %rcx,%r15
 1f81b0c:	jae    1f81d71 <node_facts_window_run+0x5821>
 1f81b12:	cmpb   $0x0,-0x1(%rbp)
 1f81b16:	je     1f81b60 <node_facts_window_run+0x5610>
 1f81b18:	xor    %edx,%edx
 1f81b1a:	cmpb   $0x0,0x0(%rbp)
 1f81b1e:	mov    0xa68(%r11),%rcx
 1f81b25:	sete   %dl
 1f81b28:	mov    (%rcx,%r15,4),%ecx
 1f81b2c:	add    %rdx,0x870(%r8)
 1f81b33:	and    0x78(%rsp),%dl
 1f81b37:	movzbl %dl,%edx
 1f81b3a:	add    %rdx,0x688(%r8)
 1f81b41:	cmp    $0x1,%dl
 1f81b44:	jne    1f81b70 <node_facts_window_run+0x5620>
 1f81b46:	mov    0xa50(%r11),%rdx
 1f81b4d:	mov    (%rdx,%r15,4),%edx
 1f81b51:	jmp    1f81b72 <node_facts_window_run+0x5622>
 1f81b53:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81b60:	mov    %rax,%rbx
 1f81b63:	jmp    1f81af8 <node_facts_window_run+0x55a8>
 1f81b65:	data16 cs nopw 0x0(%rax,%rax,1)
 1f81b70:	xor    %edx,%edx
 1f81b72:	add    %rdx,0x690(%r8)
 1f81b79:	mov    0xa50(%r11),%rdx
 1f81b80:	mov    (%rdx,%r15,4),%edx
 1f81b84:	cmp    0x651b8(%r13,%rcx,4),%edx
 1f81b8c:	jbe    1f81bb0 <node_facts_window_run+0x5660>
 1f81b8e:	mov    0xa60(%r11),%rdx
 1f81b95:	inc    %ecx
 1f81b97:	xor    %ebx,%ebx
 1f81b99:	cmp    %ecx,(%rdx,%r15,4)
 1f81b9d:	setne  %bl
 1f81ba0:	jmp    1f81bb2 <node_facts_window_run+0x5662>
 1f81ba2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81bb0:	xor    %ebx,%ebx
 1f81bb2:	mov    0xa48(%r11),%rcx
 1f81bb9:	mov    0x240(%r8),%rdx
 1f81bc0:	mov    (%rcx,%r15,4),%r14d
 1f81bc4:	mov    (%rdx,%r14,8),%r12
 1f81bc8:	cmp    %r12,-0x12(%rbp)
 1f81bcc:	jne    1f81c10 <node_facts_window_run+0x56c0>
 1f81bce:	mov    0x248(%r8),%rdx
 1f81bd5:	movzbl -0x2(%rbp),%ecx
 1f81bd9:	cmp    (%rdx,%r14,1),%cl
 1f81bdd:	jne    1f81c10 <node_facts_window_run+0x56c0>
 1f81bdf:	mov    0xc40(%rdi),%rdx
 1f81be6:	mov    -0xa(%rbp),%ecx
 1f81be9:	cmp    (%rdx,%r14,4),%ecx
 1f81bed:	jne    1f81c10 <node_facts_window_run+0x56c0>
 1f81bef:	mov    0xc48(%rdi),%rdx
 1f81bf6:	mov    -0x6(%rbp),%ecx
 1f81bf9:	cmp    (%rdx,%r14,4),%ecx
 1f81bfd:	sete   %cl
 1f81c00:	jmp    1f81c12 <node_facts_window_run+0x56c2>
 1f81c02:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f81c10:	xor    %ecx,%ecx
 1f81c12:	incq   0xa28(%r8)
 1f81c19:	add    %rax,%rbx
 1f81c1c:	mov    %ecx,%edx
 1f81c1e:	mov    0xa50(%r11),%rax
 1f81c25:	xor    $0x1,%dl
 1f81c28:	vmovd  (%rax,%r15,4),%xmm0
 1f81c2e:	movzbl %dl,%eax
 1f81c31:	vmovd  %eax,%xmm1
 1f81c35:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f81c39:	vpaddq 0xa30(%r8),%xmm0,%xmm0
 1f81c42:	vmovdqu %xmm0,0xa30(%r8)
 1f81c4b:	test   %cl,%cl
 1f81c4d:	jne    1f81af0 <node_facts_window_run+0x55a0>
 1f81c53:	mov    0x12bc(%r8),%eax
 1f81c5a:	cmp    0x5003c44(%rip),%eax        # 6f858a4 <node_census_list>
 1f81c60:	jae    1f81af0 <node_facts_window_run+0x55a0>
 1f81c66:	inc    %eax
 1f81c68:	xor    %esi,%esi
 1f81c6a:	mov    %eax,0x12bc(%r8)
 1f81c71:	mov    0xa60(%r11),%rcx
 1f81c78:	mov    (%rdi),%rax
 1f81c7b:	mov    (%rcx,%r15,4),%ecx
 1f81c7f:	mov    0x18(%rax),%rax
 1f81c83:	mov    0x422c(%r13,%rcx,4),%ecx
 1f81c8b:	cmp    0x78(%rax),%ecx
 1f81c8e:	jae    1f81cd3 <node_facts_window_run+0x5783>
 1f81c90:	mov    0x68(%rax),%rax
 1f81c94:	mov    0x8(%rdi),%rdi
 1f81c98:	mov    (%rax,%rcx,4),%eax
 1f81c9b:	cmp    0x1538(%rdi),%eax
 1f81ca1:	jae    1f81cd3 <node_facts_window_run+0x5783>
 1f81ca3:	mov    0x1530(%rdi),%rcx
 1f81caa:	test   %rcx,%rcx
 1f81cad:	je     1f81cd3 <node_facts_window_run+0x5783>
 1f81caf:	mov    (%rcx,%rax,4),%esi
 1f81cb2:	lea    0x750(%rsp),%rdx
 1f81cba:	lea    0x4c0(%rsp),%rcx
 1f81cc2:	call   111f9b0 <pp_presumed>
 1f81cc7:	mov    0x40(%rsp),%r8
 1f81ccc:	mov    0x8(%rsp),%r11
 1f81cd1:	mov    %eax,%esi
 1f81cd3:	mov    0xa50(%r11),%rax
 1f81cda:	mov    -0x12(%rbp),%rcx
 1f81cde:	movzbl -0x2(%rbp),%r9d
 1f81ce3:	mov    -0x6(%rbp),%r10d
 1f81ce7:	mov    %rbp,%r11
 1f81cea:	mov    (%rax,%r15,4),%edx
 1f81cee:	mov    0x248(%r8),%rax
 1f81cf5:	movzbl (%rax,%r14,1),%eax
 1f81cfa:	mov    %rax,0x10(%rsp)
 1f81cff:	mov    -0xa(%rbp),%eax
 1f81d02:	mov    %rax,0x20(%rsp)
 1f81d07:	mov    0x18(%rsp),%r13
 1f81d0c:	mov    0xc40(%r13),%rax
 1f81d13:	mov    0xc48(%r13),%rdi
 1f81d1a:	mov    (%rax,%r14,4),%ebp
 1f81d1e:	mov    (%rdi,%r14,4),%r14d
 1f81d22:	sub    $0x8,%rsp
 1f81d26:	lea    -0x19633e9(%rip),%rdi        # 61e944 <.str.11115>
 1f81d2d:	mov    %r12,%r8
 1f81d30:	xor    %eax,%eax
 1f81d32:	push   %r14
 1f81d34:	push   %rbp
 1f81d35:	mov    %r11,%rbp
 1f81d38:	push   %r10
 1f81d3a:	push   0x40(%rsp)
 1f81d3e:	push   0x38(%rsp)
 1f81d42:	call   34ec450 <_IO_printf>
 1f81d47:	mov    0x70(%rsp),%r8
 1f81d4c:	mov    0x38(%rsp),%r11
 1f81d51:	mov    %r13,%rdi
 1f81d54:	add    $0x30,%rsp
 1f81d58:	mov    0x90(%rsp),%r12
 1f81d60:	mov    0x28(%rsp),%r13
 1f81d65:	jmp    1f81af8 <node_facts_window_run+0x55a8>
 1f81d6a:	mov    0x40(%rsp),%r8
 1f81d6f:	xor    %ebx,%ebx
 1f81d71:	vpmovsxbq -0x1acb0b3(%rip),%xmm0        # 4b6cc7 <abi_test_hex.digits+0xb947>
 1f81d7a:	vmovd  0x8(%r13),%xmm2
 1f81d80:	mov    0x38(%rsp),%rcx
 1f81d85:	mov    0x48(%rsp),%r9
 1f81d8a:	mov    0x120(%rsp),%rdi
 1f81d92:	vmovq  %rbx,%xmm1
 1f81d97:	xor    %eax,%eax
 1f81d99:	mov    0x710(%rsp),%rdx
 1f81da1:	mov    0x6d0(%rsp),%rsi
 1f81da9:	sub    %rcx,%r9
 1f81dac:	sub    %rdi,%rcx
 1f81daf:	sub    %r9,%rcx
 1f81db2:	cmovae %rcx,%rax
 1f81db6:	mov    0x108(%rsp),%rcx
 1f81dbe:	sub    %rdx,%rsi
 1f81dc1:	vpinsrq $0x0,%r9,%xmm0,%xmm0
 1f81dc7:	vpunpcklqdq %xmm1,%xmm2,%xmm1
 1f81dcb:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f81dd1:	vpaddq 0xa70(%r8),%ymm0,%ymm0
 1f81dda:	vmovq  %rsi,%xmm1
 1f81ddf:	sub    %rcx,%rdi
 1f81de2:	sub    %rcx,%rdx
 1f81de5:	add    %rax,%rdi
 1f81de8:	vmovq  %rdx,%xmm2
 1f81ded:	vmovdqu %ymm0,0xa70(%r8)
 1f81df6:	vmovq  %rax,%xmm0
 1f81dfb:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f81dff:	vmovq  %rdi,%xmm1
 1f81e04:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f81e08:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f81e0e:	vpaddq 0xa40(%r8),%ymm0,%ymm0
 1f81e17:	vmovdqu %ymm0,0xa40(%r8)
 1f81e20:	cmpq   $0x0,0xb38(%r11)
 1f81e28:	je     1f83b35 <node_facts_window_run+0x75e5>
 1f81e2e:	mov    0x938(%r11),%r15
 1f81e35:	mov    0x8(%r13),%ebx
 1f81e39:	rdtsc
 1f81e3b:	lea    0x880(%rsp),%rcx
 1f81e43:	vpxor  %xmm0,%xmm0,%xmm0
 1f81e47:	vmovdqu64 %zmm0,0x8a0(%rsp)
 1f81e52:	vmovdqu64 %zmm0,0x880(%rsp)
 1f81e5a:	mov    %r11,%rdi
 1f81e5d:	mov    %r13,%rsi
 1f81e60:	shl    $0x20,%rdx
 1f81e64:	or     %rax,%rdx
 1f81e67:	mov    %rdx,0x40(%rsp)
 1f81e6c:	mov    %ebx,%edx
 1f81e6e:	vzeroupper
 1f81e71:	call   1f92b00 <node_contexts_window_loop>
 1f81e76:	vmovups 0x8a8(%rsp),%ymm0
 1f81e7f:	vmovdqu 0x8a8(%rsp),%xmm1
 1f81e88:	mov    %r13,%rsi
 1f81e8b:	vmovups %ymm0,0x1c0(%rsp)
 1f81e94:	vpbroadcastq 0x8b8(%rsp),%ymm0
 1f81e9e:	mov    0x8(%rsp),%rax
 1f81ea3:	vpsubq %xmm0,%xmm1,%xmm0
 1f81ea7:	vpaddq 0x8b8(%rsp),%xmm0,%xmm0
 1f81eb0:	vpblendd $0xc,%xmm0,%xmm1,%xmm0
 1f81eb6:	vmovdqu %xmm0,0xc00(%rax)
 1f81ebe:	rdtsc
 1f81ec0:	shl    $0x20,%rdx
 1f81ec4:	or     %rax,%rdx
 1f81ec7:	mov    %rdx,0xa8(%rsp)
 1f81ecf:	mov    %ebx,%edx
 1f81ed1:	mov    0x8(%rsp),%rdi
 1f81ed6:	vzeroupper
 1f81ed9:	call   1f94ab0 <node_contexts_window_targets>
 1f81ede:	rdtsc
 1f81ee0:	mov    %r13,%rsi
 1f81ee3:	shl    $0x20,%rdx
 1f81ee7:	or     %rax,%rdx
 1f81eea:	mov    %rdx,0xd0(%rsp)
 1f81ef2:	mov    0x8(%rsp),%rdi
 1f81ef7:	call   1f94e40 <node_contexts_window_part>
 1f81efc:	rdtsc
 1f81efe:	lea    0x750(%rsp),%rcx
 1f81f06:	vpxor  %xmm0,%xmm0,%xmm0
 1f81f0a:	vmovdqu64 %zmm0,0x770(%rsp)
 1f81f15:	vmovdqu64 %zmm0,0x750(%rsp)
 1f81f20:	mov    %r13,%rsi
 1f81f23:	shl    $0x20,%rdx
 1f81f27:	or     %rax,%rdx
 1f81f2a:	mov    %rdx,0xe0(%rsp)
 1f81f32:	mov    %ebx,%edx
 1f81f34:	mov    0x8(%rsp),%rdi
 1f81f39:	vzeroupper
 1f81f3c:	call   1f92b00 <node_contexts_window_loop>
 1f81f41:	rdtsc
 1f81f43:	mov    %r13,%rsi
 1f81f46:	shl    $0x20,%rdx
 1f81f4a:	or     %rax,%rdx
 1f81f4d:	mov    %rdx,0xc8(%rsp)
 1f81f55:	mov    %ebx,%edx
 1f81f57:	mov    0x8(%rsp),%rdi
 1f81f5c:	call   1f94ab0 <node_contexts_window_targets>
 1f81f61:	rdtsc
 1f81f63:	mov    %r13,%rsi
 1f81f66:	shl    $0x20,%rdx
 1f81f6a:	or     %rax,%rdx
 1f81f6d:	mov    %rdx,0xd8(%rsp)
 1f81f75:	mov    0x8(%rsp),%rdi
 1f81f7a:	call   1f94e40 <node_contexts_window_part>
 1f81f7f:	mov    0x8(%rsp),%r11
 1f81f84:	rdtsc
 1f81f86:	shl    $0x20,%rdx
 1f81f8a:	or     %rax,%rdx
 1f81f8d:	cmpl   $0x0,0xa88(%r11)
 1f81f95:	mov    %rdx,0x30(%rsp)
 1f81f9a:	mov    %rbx,0x180(%rsp)
 1f81fa2:	je     1f824ee <node_facts_window_run+0x5f9e>
 1f81fa8:	vpbroadcastq -0x19b5ee9(%rip),%xmm0        # 5cc0c8 <.LCPI3_1>
 1f81fb1:	xor    %ebx,%ebx
 1f81fb3:	xor    %edi,%edi
 1f81fb5:	mov    %r15,0x60(%rsp)
 1f81fba:	jmp    1f81fde <node_facts_window_run+0x5a8e>
 1f81fbc:	mov    0x8(%rsp),%r11
 1f81fc1:	xor    %esi,%esi
 1f81fc3:	incq   0x12c0(%r15,%rsi,8)
 1f81fcb:	mov    0xa88(%r11),%eax
 1f81fd2:	inc    %rdi
 1f81fd5:	cmp    %rax,%rdi
 1f81fd8:	jae    1f824f0 <node_facts_window_run+0x5fa0>
 1f81fde:	mov    0xb78(%r11),%rax
 1f81fe5:	movzbl (%rax,%rdi,1),%r9d
 1f81fea:	test   %r9b,%r9b
 1f81fed:	je     1f81fcb <node_facts_window_run+0x5a7b>
 1f81fef:	mov    0xa68(%r11),%rcx
 1f81ff6:	mov    0xa60(%r11),%rax
 1f81ffd:	mov    (%rcx,%rdi,4),%ecx
 1f82000:	mov    (%rax,%rdi,4),%r14d
 1f82004:	mov    0x651b8(%r13,%rcx,4),%esi
 1f8200c:	incq   0xa90(%r15)
 1f82013:	mov    0xa50(%r11),%rax
 1f8201a:	mov    (%rax,%rdi,4),%eax
 1f8201d:	add    %rax,0xa98(%r15)
 1f82024:	cmp    $0x1,%r9b
 1f82028:	jne    1f82080 <node_facts_window_run+0x5b30>
 1f8202a:	mov    0xa50(%r11),%rax
 1f82031:	mov    (%rax,%rdi,4),%r10d
 1f82035:	test   %r10d,%r10d
 1f82038:	je     1f81fc1 <node_facts_window_run+0x5a71>
 1f8203a:	mov    0xbe0(%r11),%rax
 1f82041:	sub    %esi,%ecx
 1f82043:	xor    %r11d,%r11d
 1f82046:	inc    %ecx
 1f82048:	nopl   0x0(%rax,%rax,1)
 1f82050:	lea    (%rcx,%r11,1),%r9d
 1f82054:	cmp    %esi,%r11d
 1f82057:	cmovae %r14d,%r9d
 1f8205b:	mov    %r9d,%edx
 1f8205e:	shr    $0x3,%edx
 1f82061:	and    $0xfffffff8,%edx
 1f82064:	mov    0x10(%rax,%rdx,8),%r8
 1f82069:	bt     %r9,%r8
 1f8206d:	jb     1f82107 <node_facts_window_run+0x5bb7>
 1f82073:	inc    %r11d
 1f82076:	cmp    %r11d,%r10d
 1f82079:	jne    1f82050 <node_facts_window_run+0x5b00>
 1f8207b:	jmp    1f81fbc <node_facts_window_run+0x5a6c>
 1f82080:	mov    0xa50(%r11),%rcx
 1f82087:	mov    0xb60(%r11),%rdx
 1f8208e:	cmp    $0x3,%r9b
 1f82092:	sete   %al
 1f82095:	mov    (%rcx,%rdi,4),%r10d
 1f82099:	movzbl (%rdx,%rdi,1),%r8d
 1f8209e:	test   %r10,%r10
 1f820a1:	sete   %cl
 1f820a4:	cmp    $0x2,%r8b
 1f820a8:	sete   %dl
 1f820ab:	or     %al,%dl
 1f820ad:	or     %cl,%dl
 1f820af:	je     1f820b8 <node_facts_window_run+0x5b68>
 1f820b1:	xor    %esi,%esi
 1f820b3:	jmp    1f82406 <node_facts_window_run+0x5eb6>
 1f820b8:	mov    0xa60(%r11),%rax
 1f820bf:	mov    %r14,0x20(%rsp)
 1f820c4:	mov    %rbx,0x10(%rsp)
 1f820c9:	mov    0xbe0(%r11),%rbp
 1f820d0:	mov    %r8b,0x120(%rsp)
 1f820d8:	mov    (%rax,%rdi,4),%r12d
 1f820dc:	mov    0xa68(%r11),%rax
 1f820e3:	mov    (%rax,%rdi,4),%eax
 1f820e6:	mov    0x651b8(%r13,%rax,4),%ebx
 1f820ee:	mov    0xb40(%r11),%r13
 1f820f5:	sub    %ebx,%eax
 1f820f7:	cmp    $0x1,%r10d
 1f820fb:	jne    1f82157 <node_facts_window_run+0x5c07>
 1f820fd:	xor    %esi,%esi
 1f820ff:	xor    %r14d,%r14d
 1f82102:	jmp    1f82340 <node_facts_window_run+0x5df0>
 1f82107:	mov    0x8(%rsp),%r11
 1f8210c:	mov    %r9d,%esi
 1f8210f:	mov    0xbc8(%r11),%rcx
 1f82116:	movzbl (%rcx,%rsi,1),%ecx
 1f8211a:	mov    $0x1,%esi
 1f8211f:	cmp    $0xd,%ecx
 1f82122:	je     1f81fc3 <node_facts_window_run+0x5a73>
 1f82128:	lea    -0xf(%rcx),%r8d
 1f8212c:	mov    $0x2,%esi
 1f82131:	cmp    $0x2,%r8b
 1f82135:	jb     1f81fc3 <node_facts_window_run+0x5a73>
 1f8213b:	cmp    $0xe,%ecx
 1f8213e:	je     1f824a8 <node_facts_window_run+0x5f58>
 1f82144:	cmp    $0x11,%ecx
 1f82147:	jne    1f824b2 <node_facts_window_run+0x5f62>
 1f8214d:	mov    $0x4,%esi
 1f82152:	jmp    1f81fc3 <node_facts_window_run+0x5a73>
 1f82157:	mov    %r10d,%ecx
 1f8215a:	and    $0xfffffffe,%ecx
 1f8215d:	lea    0x2(%rax),%edx
 1f82160:	mov    %r9b,0x78(%rsp)
 1f82165:	mov    %r10,0x48(%rsp)
 1f8216a:	xor    %esi,%esi
 1f8216c:	xor    %r15d,%r15d
 1f8216f:	mov    %ecx,0x18(%rsp)
 1f82173:	mov    %rax,0x38(%rsp)
 1f82178:	jmp    1f8219a <node_facts_window_run+0x5c4a>
 1f8217a:	nopw   0x0(%rax,%rax,1)
 1f82180:	xor    %r11d,%r11d
 1f82183:	add    %r10,%rsi
 1f82186:	add    $0x2,%edx
 1f82189:	inc    %r15d
 1f8218c:	add    %r11,%rsi
 1f8218f:	cmp    0x18(%rsp),%r15d
 1f82194:	je     1f822e7 <node_facts_window_run+0x5d97>
 1f8219a:	mov    %r15d,%r14d
 1f8219d:	lea    -0x1(%rdx),%r15d
 1f821a1:	cmp    %ebx,%r14d
 1f821a4:	mov    $0x1,%r11d
 1f821aa:	mov    $0x1,%r10d
 1f821b0:	cmovae %r12d,%r15d
 1f821b4:	mov    %r15d,%eax
 1f821b7:	and    $0xffffffc0,%eax
 1f821ba:	movzbl 0x0(%r13,%r15,1),%r8d
 1f821c0:	shrx   %r15,0x0(%rbp,%rax,1),%rax
 1f821c7:	and    $0x1,%r8d
 1f821cb:	mov    %eax,%r9d
 1f821ce:	and    $0x1,%r9d
 1f821d2:	cmp    %r8d,%r9d
 1f821d5:	jne    1f82243 <node_facts_window_run+0x5cf3>
 1f821d7:	test   $0x1,%al
 1f821d9:	je     1f82240 <node_facts_window_run+0x5cf0>
 1f821db:	mov    0x8(%rsp),%rcx
 1f821e0:	mov    0xba8(%rcx),%r8
 1f821e7:	mov    0xb50(%rcx),%rax
 1f821ee:	movzbl (%r8,%r15,1),%r8d
 1f821f3:	cmp    (%rax,%r15,1),%r8b
 1f821f7:	jne    1f82243 <node_facts_window_run+0x5cf3>
 1f821f9:	mov    0x8(%rsp),%rcx
 1f821fe:	mov    0xbb8(%rcx),%r8
 1f82205:	mov    0xb48(%rcx),%rax
 1f8220c:	movzbl (%r8,%r15,1),%r8d
 1f82211:	cmp    (%rax,%r15,1),%r8b
 1f82215:	jne    1f82243 <node_facts_window_run+0x5cf3>
 1f82217:	mov    0x8(%rsp),%rcx
 1f8221c:	xor    %r10d,%r10d
 1f8221f:	mov    0xbd0(%rcx),%r8
 1f82226:	mov    0xb58(%rcx),%rax
 1f8222d:	mov    (%r8,%r15,4),%r8d
 1f82231:	cmp    (%rax,%r15,4),%r8d
 1f82235:	setne  %r10b
 1f82239:	jmp    1f82243 <node_facts_window_run+0x5cf3>
 1f8223b:	nopl   0x0(%rax,%rax,1)
 1f82240:	xor    %r10d,%r10d
 1f82243:	lea    0x1(%r14),%r15d
 1f82247:	mov    %r12d,%eax
 1f8224a:	cmp    %ebx,%r15d
 1f8224d:	cmovb  %edx,%eax
 1f82250:	mov    %eax,%r8d
 1f82253:	and    $0xffffffc0,%r8d
 1f82257:	movzbl 0x0(%r13,%rax,1),%r9d
 1f8225d:	shrx   %rax,0x0(%rbp,%r8,1),%r8
 1f82264:	and    $0x1,%r9d
 1f82268:	mov    %r8d,%ecx
 1f8226b:	and    $0x1,%ecx
 1f8226e:	cmp    %r9d,%ecx
 1f82271:	jne    1f82183 <node_facts_window_run+0x5c33>
 1f82277:	test   $0x1,%r8b
 1f8227b:	je     1f82180 <node_facts_window_run+0x5c30>
 1f82281:	mov    0x8(%rsp),%r9
 1f82286:	mov    0xba8(%r9),%r8
 1f8228d:	mov    0xb50(%r9),%rcx
 1f82294:	movzbl (%r8,%rax,1),%r8d
 1f82299:	cmp    (%rcx,%rax,1),%r8b
 1f8229d:	jne    1f82183 <node_facts_window_run+0x5c33>
 1f822a3:	mov    0xbb8(%r9),%r8
 1f822aa:	mov    0xb48(%r9),%rcx
 1f822b1:	movzbl (%r8,%rax,1),%r8d
 1f822b6:	cmp    (%rcx,%rax,1),%r8b
 1f822ba:	jne    1f82183 <node_facts_window_run+0x5c33>
 1f822c0:	mov    0x8(%rsp),%r8
 1f822c5:	xor    %r11d,%r11d
 1f822c8:	mov    0xb58(%r8),%rcx
 1f822cf:	mov    0xbd0(%r8),%r8
 1f822d6:	mov    (%r8,%rax,4),%r8d
 1f822da:	cmp    (%rcx,%rax,4),%r8d
 1f822de:	setne  %r11b
 1f822e2:	jmp    1f82183 <node_facts_window_run+0x5c33>
 1f822e7:	mov    0x48(%rsp),%r10
 1f822ec:	test   $0x1,%r10b
 1f822f0:	jne    1f82327 <node_facts_window_run+0x5dd7>
 1f822f2:	mov    0x90(%rsp),%r12
 1f822fa:	mov    0x8(%rsp),%r11
 1f822ff:	mov    0x28(%rsp),%r13
 1f82304:	mov    0x60(%rsp),%r15
 1f82309:	mov    0x10(%rsp),%rbx
 1f8230e:	mov    0x20(%rsp),%r14
 1f82313:	movzbl 0x78(%rsp),%r9d
 1f82319:	movzbl 0x120(%rsp),%r8d
 1f82322:	jmp    1f82406 <node_facts_window_run+0x5eb6>
 1f82327:	mov    0x8(%rsp),%r11
 1f8232c:	mov    0x60(%rsp),%r15
 1f82331:	movzbl 0x78(%rsp),%r9d
 1f82337:	mov    0x38(%rsp),%rax
 1f8233c:	add    $0x2,%r14d
 1f82340:	inc    %eax
 1f82342:	add    %r14d,%eax
 1f82345:	cmp    %ebx,%r14d
 1f82348:	cmovb  %eax,%r12d
 1f8234c:	mov    %r12d,%eax
 1f8234f:	and    $0xffffffc0,%eax
 1f82352:	movzbl 0x0(%r13,%r12,1),%edx
 1f82358:	shrx   %r12,0x0(%rbp,%rax,1),%rcx
 1f8235f:	mov    $0x1,%eax
 1f82364:	and    $0x1,%edx
 1f82367:	mov    %ecx,%r8d
 1f8236a:	and    $0x1,%r8d
 1f8236e:	cmp    %edx,%r8d
 1f82371:	jne    1f823df <node_facts_window_run+0x5e8f>
 1f82373:	mov    0x28(%rsp),%r13
 1f82378:	mov    0x10(%rsp),%rbx
 1f8237d:	mov    0x20(%rsp),%r14
 1f82382:	movzbl 0x120(%rsp),%r8d
 1f8238b:	test   $0x1,%cl
 1f8238e:	je     1f823f9 <node_facts_window_run+0x5ea9>
 1f82390:	mov    0xba8(%r11),%rdx
 1f82397:	mov    0xb50(%r11),%rcx
 1f8239e:	movzbl (%rdx,%r12,1),%edx
 1f823a3:	cmp    (%rcx,%r12,1),%dl
 1f823a7:	jne    1f823fb <node_facts_window_run+0x5eab>
 1f823a9:	mov    0xbb8(%r11),%rdx
 1f823b0:	mov    0xb48(%r11),%rcx
 1f823b7:	movzbl (%rdx,%r12,1),%edx
 1f823bc:	cmp    (%rcx,%r12,1),%dl
 1f823c0:	jne    1f823fb <node_facts_window_run+0x5eab>
 1f823c2:	mov    0xbd0(%r11),%rax
 1f823c9:	mov    0xb58(%r11),%rcx
 1f823d0:	mov    (%rax,%r12,4),%edx
 1f823d4:	xor    %eax,%eax
 1f823d6:	cmp    (%rcx,%r12,4),%edx
 1f823da:	setne  %al
 1f823dd:	jmp    1f823fb <node_facts_window_run+0x5eab>
 1f823df:	mov    0x28(%rsp),%r13
 1f823e4:	mov    0x10(%rsp),%rbx
 1f823e9:	mov    0x20(%rsp),%r14
 1f823ee:	movzbl 0x120(%rsp),%r8d
 1f823f7:	jmp    1f823fb <node_facts_window_run+0x5eab>
 1f823f9:	xor    %eax,%eax
 1f823fb:	mov    0x90(%rsp),%r12
 1f82403:	add    %rax,%rsi
 1f82406:	cmp    $0x2,%r8b
 1f8240a:	sete   %al
 1f8240d:	cmp    $0x3,%r9b
 1f82411:	sete   %cl
 1f82414:	xor    %cl,%al
 1f82416:	test   %rsi,%rsi
 1f82419:	vmovd  %ecx,%xmm1
 1f8241d:	setne  %dl
 1f82420:	incq   0xaa0(%r15)
 1f82427:	add    %r10,%rbx
 1f8242a:	or     %al,%dl
 1f8242c:	vpinsrb $0x1,%edx,%xmm1,%xmm1
 1f82432:	vpmovzxbq %xmm1,%xmm1
 1f82437:	vptestmq %xmm0,%xmm1,%k0
 1f8243d:	vmovdqu 0xab0(%r15),%xmm1
 1f82446:	vpmovm2q %k0,%xmm2
 1f8244c:	vpsubq %xmm2,%xmm1,%xmm1
 1f82450:	vmovdqu %xmm1,0xab0(%r15)
 1f82459:	add    %rsi,0xac0(%r15)
 1f82460:	mov    0xb70(%r11),%rax
 1f82467:	mov    (%rax,%rdi,8),%rax
 1f8246b:	add    %rax,0xb08(%r15)
 1f82472:	cmp    $0x1,%dl
 1f82475:	jne    1f81fcb <node_facts_window_run+0x5a7b>
 1f8247b:	mov    0x1340(%r15),%eax
 1f82482:	cmp    $0xf,%rax
 1f82486:	ja     1f81fcb <node_facts_window_run+0x5a7b>
 1f8248c:	mov    0x422c(%r13,%r14,4),%ecx
 1f82494:	mov    %ecx,0x1300(%r15,%rax,4)
 1f8249c:	incl   0x1340(%r15)
 1f824a3:	jmp    1f81fcb <node_facts_window_run+0x5a7b>
 1f824a8:	mov    $0x3,%esi
 1f824ad:	jmp    1f81fc3 <node_facts_window_run+0x5a73>
 1f824b2:	mov    $0x1,%esi
 1f824b7:	shlx   %r9,%rsi,%r8
 1f824bc:	mov    $0x5,%esi
 1f824c1:	test   %r8,0x18(%rax,%rdx,8)
 1f824c6:	jne    1f81fc3 <node_facts_window_run+0x5a73>
 1f824cc:	mov    $0x6,%esi
 1f824d1:	test   %r8,0x20(%rax,%rdx,8)
 1f824d6:	jne    1f81fc3 <node_facts_window_run+0x5a73>
 1f824dc:	xor    %eax,%eax
 1f824de:	cmp    $0x7,%ecx
 1f824e1:	setne  %al
 1f824e4:	lea    0x2(%rax,%rax,4),%rsi
 1f824e9:	jmp    1f81fc3 <node_facts_window_run+0x5a73>
 1f824ee:	xor    %ebx,%ebx
 1f824f0:	add    %rbx,0xaa8(%r15)
 1f824f7:	mov    0xe0(%rsp),%rdx
 1f824ff:	mov    0xd0(%rsp),%rsi
 1f82507:	mov    0xa8(%rsp),%rcx
 1f8250f:	vmovd  0x180(%rsp),%xmm4
 1f82518:	vmovdqu 0xb50(%r15),%xmm0
 1f82521:	vmovq  0x8a0(%rsp),%xmm1
 1f8252a:	vpaddq 0x8c8(%rsp),%xmm0,%xmm0
 1f82533:	vmovdqu %xmm0,0xb50(%r15)
 1f8253c:	mov    0x8d8(%rsp),%rax
 1f82544:	add    %rax,0xb60(%r15)
 1f8254b:	mov    %rdx,%rax
 1f8254e:	sub    %rsi,%rax
 1f82551:	sub    %rcx,%rsi
 1f82554:	sub    0x40(%rsp),%rcx
 1f82559:	vmovdqu64 0x880(%rsp),%zmm0
 1f82561:	vmovq  %rax,%xmm2
 1f82566:	vmovq  %rsi,%xmm3
 1f8256b:	mov    0x30(%rsp),%rsi
 1f82570:	mov    0xc8(%rsp),%rax
 1f82578:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f8257c:	vmovq  %rcx,%xmm3
 1f82581:	mov    0xd8(%rsp),%rcx
 1f82589:	vpunpcklqdq %xmm3,%xmm4,%xmm3
 1f8258d:	vinserti128 $0x1,%xmm2,%ymm3,%ymm2
 1f82593:	vshufi64x2 $0x44,%zmm2,%zmm0,%zmm0
 1f8259a:	vpaddq 0xac8(%r15),%zmm0,%zmm0
 1f825a4:	sub    %rcx,%rsi
 1f825a7:	sub    %rax,%rcx
 1f825aa:	sub    %rdx,%rax
 1f825ad:	vmovq  %rsi,%xmm3
 1f825b2:	vmovq  %rax,%xmm2
 1f825b7:	vpunpcklqdq %xmm1,%xmm3,%xmm1
 1f825bb:	vmovdqu64 %zmm0,0xac8(%r15)
 1f825c5:	vmovq  %rcx,%xmm0
 1f825ca:	vpunpcklqdq %xmm0,%xmm2,%xmm0
 1f825ce:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f825d4:	vinserti64x4 $0x1,0x1c0(%rsp),%zmm0,%zmm0
 1f825dd:	vpaddq 0xb10(%r15),%zmm0,%zmm0
 1f825e7:	vmovdqu64 %zmm0,0xb10(%r15)
 1f825f1:	cmpq   $0x0,0xc18(%r11)
 1f825f9:	je     1f83b35 <node_facts_window_run+0x75e5>
 1f825ff:	mov    0x8(%r13),%ebp
 1f82603:	mov    0x938(%r11),%r14
 1f8260a:	vpxor  %xmm0,%xmm0,%xmm0
 1f8260e:	vmovdqu %ymm0,0x880(%rsp)
 1f82617:	movq   $0x0,0x8a0(%rsp)
 1f82623:	rdtsc
 1f82625:	mov    %r11,%rdi
 1f82628:	mov    %rdx,0x300(%rsp)
 1f82630:	lea    0x880(%rsp),%rdx
 1f82638:	mov    %ebp,%esi
 1f8263a:	mov    %rax,0x80(%rsp)
 1f82642:	vzeroupper
 1f82645:	call   1f95220 <node_rows_window_reads>
 1f8264a:	rdtsc
 1f8264c:	mov    %r13,%rsi
 1f8264f:	mov    %rdx,0x2c0(%rsp)
 1f82657:	mov    %ebp,%edx
 1f82659:	mov    %rax,0x248(%rsp)
 1f82661:	mov    0x8(%rsp),%rdi
 1f82666:	call   1f95940 <node_rows_window_shapes>
 1f8266b:	mov    0x8(%rsp),%rdi
 1f82670:	rdtsc
 1f82672:	mov    0xc08(%rdi),%rcx
 1f82679:	or     0xc00(%rdi),%rcx
 1f82680:	mov    %rax,0x88(%rsp)
 1f82688:	mov    %rdx,0x280(%rsp)
 1f82690:	je     1f826a9 <node_facts_window_run+0x6159>
 1f82692:	lea    0x880(%rsp),%rcx
 1f8269a:	mov    %r13,%rsi
 1f8269d:	mov    %ebp,%edx
 1f8269f:	call   1f95d70 <node_rows_window_updates>
 1f826a4:	mov    0x8(%rsp),%rdi
 1f826a9:	rdtsc
 1f826ab:	mov    %r13,%rsi
 1f826ae:	mov    %rdx,0x400(%rsp)
 1f826b6:	mov    %ebp,%edx
 1f826b8:	mov    %rax,0x3c0(%rsp)
 1f826c0:	call   1f96580 <node_rows_window_write>
 1f826c5:	mov    %eax,%r15d
 1f826c8:	rdtsc
 1f826ca:	mov    0x890(%rsp),%r8
 1f826d2:	mov    0x8a0(%rsp),%r9d
 1f826da:	vpxor  %xmm0,%xmm0,%xmm0
 1f826de:	vmovdqu %xmm0,0x4cc(%rsp)
 1f826e7:	vmovdqa %xmm0,0x4c0(%rsp)
 1f826f0:	movl   $0x0,0x114(%rsp)
 1f826fb:	movq   $0x0,0x278(%rsp)
 1f82707:	mov    %rax,0x200(%rsp)
 1f8270f:	mov    %rdx,0x480(%rsp)
 1f82717:	sub    $0x8,%rsp
 1f8271b:	mov    0x10(%rsp),%rdi
 1f82720:	lea    0x280(%rsp),%rax
 1f82728:	lea    0x11c(%rsp),%r10
 1f82730:	lea    0x4c8(%rsp),%r11
 1f82738:	mov    %r13,%rsi
 1f8273b:	mov    %ebp,%edx
 1f8273d:	mov    %r15d,%ecx
 1f82740:	push   %rax
 1f82741:	push   %r10
 1f82743:	push   %r11
 1f82745:	call   1f96ba0 <node_rows_window_values>
 1f8274a:	add    $0x20,%rsp
 1f8274e:	rdtsc
 1f82750:	mov    %r13,%rsi
 1f82753:	mov    %rdx,0x560(%rsp)
 1f8275b:	mov    %rax,0x380(%rsp)
 1f82763:	mov    0x8(%rsp),%rdi
 1f82768:	call   1f97a40 <node_rows_window_part>
 1f8276d:	mov    0x8(%rsp),%rdi
 1f82772:	rdtsc
 1f82774:	movl   $0x0,0xf8(%rsp)
 1f8277f:	movq   $0x0,0xf0(%rsp)
 1f8278b:	cmpb   $0x1,0xd50(%rdi)
 1f82792:	mov    %rax,0x340(%rsp)
 1f8279a:	mov    %rdx,0x520(%rsp)
 1f827a2:	jne    1f827bb <node_facts_window_run+0x626b>
 1f827a4:	lea    0xf0(%rsp),%rcx
 1f827ac:	mov    %r13,%rsi
 1f827af:	mov    %ebp,%edx
 1f827b1:	call   1f97b50 <node_rows_window_summary>
 1f827b6:	mov    0x8(%rsp),%rdi
 1f827bb:	rdtsc
 1f827bd:	mov    0xdb8(%rdi),%ecx
 1f827c3:	movl   $0x0,0xdb8(%rdi)
 1f827cd:	cmpb   $0x0,0xdbc(%rdi)
 1f827d4:	mov    %rcx,0x250(%rsp)
 1f827dc:	mov    0xa88(%rdi),%ecx
 1f827e2:	mov    %rcx,0x240(%rsp)
 1f827ea:	mov    %rax,0xb0(%rsp)
 1f827f2:	mov    %rdx,0x4e0(%rsp)
 1f827fa:	je     1f82832 <node_facts_window_run+0x62e2>
 1f827fc:	mov    0xdc4(%rdi),%ecx
 1f82802:	mov    $0x1,%esi
 1f82807:	mov    %ecx,%ebx
 1f82809:	inc    %ecx
 1f8280b:	and    $0x3,%ebx
 1f8280e:	mov    %ecx,0xdc4(%rdi)
 1f82814:	mov    0xf0(%rsp),%ecx
 1f8281b:	mov    %ecx,0xe8(%rsp)
 1f82822:	cmp    $0x2,%ebx
 1f82825:	jne    1f8373f <node_facts_window_run+0x71ef>
 1f8282b:	mov    $0x2,%ebx
 1f82830:	jmp    1f82857 <node_facts_window_run+0x6307>
 1f82832:	mov    0xf0(%rsp),%eax
 1f82839:	mov    $0xffffffff,%ebx
 1f8283e:	mov    %eax,0xe8(%rsp)
 1f82845:	mov    %ebx,%eax
 1f82847:	xor    $0x3,%eax
 1f8284a:	xor    %esi,%esi
 1f8284c:	or     0xe8(%rsp),%eax
 1f82853:	sete   %sil
 1f82857:	cmpb   $0x1,0xd50(%rdi)
 1f8285e:	mov    %esi,0x178(%rsp)
 1f82865:	mov    %r14,0x30(%rsp)
 1f8286a:	jne    1f8294f <node_facts_window_run+0x63ff>
 1f82870:	mov    0xd90(%rdi),%rsi
 1f82877:	mov    0xda0(%rdi),%rdi
 1f8287e:	lea    0x0(%rbp,%rbp,1),%rdx
 1f82883:	call   355bd30 <memcpy>
 1f82888:	mov    0x8(%rsp),%rax
 1f8288d:	mov    0x8(%rsp),%rcx
 1f82892:	mov    0x240(%rsp),%r14
 1f8289a:	mov    0xd98(%rax),%rsi
 1f828a1:	mov    0xda8(%rcx),%rdi
 1f828a8:	mov    %r14,%rdx
 1f828ab:	call   355bd30 <memcpy>
 1f828b0:	mov    0x8(%rsp),%rax
 1f828b5:	mov    0x8(%rsp),%rcx
 1f828ba:	mov    %r15d,0x5e0(%rsp)
 1f828c2:	mov    0xe8(%rsp),%r15d
 1f828ca:	mov    0xd88(%rax),%rsi
 1f828d1:	mov    0xdb0(%rcx),%rdi
 1f828d8:	mov    %r15d,%edx
 1f828db:	shl    $0x2,%rdx
 1f828df:	call   355bd30 <memcpy>
 1f828e4:	mov    0x8(%rsp),%rdi
 1f828e9:	xor    %eax,%eax
 1f828eb:	mov    %ebp,%ecx
 1f828ed:	sub    $0x1,%ecx
 1f828f0:	cmovb  %eax,%ecx
 1f828f3:	test   %ebx,%ebx
 1f828f5:	sete   %dl
 1f828f8:	cmp    $0x1,%ebx
 1f828fb:	sete   %sil
 1f828ff:	test   %r14d,%r14d
 1f82902:	sete   %r8b
 1f82906:	mov    0xda0(%rdi),%rax
 1f8290d:	and    %sil,%r8b
 1f82910:	or     %dl,%r8b
 1f82913:	movzbl %r8b,%edx
 1f82917:	xor    %dx,(%rax,%rcx,2)
 1f8291b:	test   %r14d,%r14d
 1f8291e:	mov    0xda8(%rdi),%rax
 1f82925:	setne  %cl
 1f82928:	and    %sil,%cl
 1f8292b:	xor    %cl,(%rax)
 1f8292d:	cmp    $0x3,%ebx
 1f82930:	mov    0xdb0(%rdi),%rdx
 1f82937:	sete   %al
 1f8293a:	test   %r15d,%r15d
 1f8293d:	mov    0x5e0(%rsp),%r15d
 1f82945:	setne  %cl
 1f82948:	and    %al,%cl
 1f8294a:	movzbl %cl,%eax
 1f8294d:	xor    %eax,(%rdx)
 1f8294f:	mov    0xca0(%rdi),%rsi
 1f82956:	mov    0xcb0(%rdi),%rdi
 1f8295d:	mov    %r15d,%ebx
 1f82960:	mov    %rbx,%rdx
 1f82963:	call   355bd30 <memcpy>
 1f82968:	mov    0x8(%rsp),%rax
 1f8296d:	mov    0x8(%rsp),%rcx
 1f82972:	mov    %rbx,%rdx
 1f82975:	mov    0xca8(%rax),%rsi
 1f8297c:	mov    0xcb8(%rcx),%rdi
 1f82983:	call   355bd30 <memcpy>
 1f82988:	mov    0x8(%rsp),%rax
 1f8298d:	mov    0x8(%rsp),%rcx
 1f82992:	lea    0x0(,%rbx,8),%rdx
 1f8299a:	mov    %rbx,0x638(%rsp)
 1f829a2:	mov    %rdx,0x628(%rsp)
 1f829aa:	mov    0xcc0(%rax),%rsi
 1f829b1:	mov    0xcc8(%rcx),%rdi
 1f829b8:	call   355bd30 <memcpy>
 1f829bd:	mov    0x8(%rsp),%rax
 1f829c2:	mov    $0xffffffff,%edi
 1f829c7:	mov    %rbp,%r14
 1f829ca:	movzbl 0xdc8(%rax),%ecx
 1f829d1:	mov    0x8(%rsp),%rax
 1f829d6:	mov    0xdd0(%rax),%edx
 1f829dc:	imul   $0x4ec4ec4f,%rdx,%rax
 1f829e3:	shr    $0x22,%rax
 1f829e7:	lea    (%rax,%rax,2),%esi
 1f829ea:	lea    (%rax,%rsi,4),%eax
 1f829ed:	mov    %edx,%esi
 1f829ef:	sub    %eax,%esi
 1f829f1:	test   %ecx,%ecx
 1f829f3:	cmovne %esi,%edi
 1f829f6:	xor    %eax,%eax
 1f829f8:	lea    -0x1(%rdi),%esi
 1f829fb:	cmp    $0x3,%esi
 1f829fe:	mov    %r14d,%esi
 1f82a01:	cmovae %edi,%eax
 1f82a04:	test   %r15d,%r15d
 1f82a07:	cmovne %edi,%eax
 1f82a0a:	add    %edx,%ecx
 1f82a0c:	mov    0x8(%rsp),%rdx
 1f82a11:	mov    0x8(%rsp),%rdi
 1f82a16:	cmp    $0x1,%eax
 1f82a19:	vpbroadcastd %eax,%xmm0
 1f82a1f:	vpcmpeqd -0x19bd087(%rip),%xmm0,%xmm1        # 5c59a0 <.LCPI3_65>
 1f82a27:	vpcmpeqd -0x19bd07f(%rip),%xmm0,%xmm0        # 5c59b0 <.LCPI3_66>
 1f82a2f:	mov    %ecx,0xdd0(%rdx)
 1f82a35:	mov    0x8(%rsp),%rcx
 1f82a3a:	sete   %dl
 1f82a3d:	vpsrld $0x1f,%xmm1,%xmm1
 1f82a42:	vpsrld $0x1f,%xmm0,%xmm0
 1f82a47:	mov    0xcb0(%rcx),%rcx
 1f82a4e:	xor    %dl,(%rcx)
 1f82a50:	mov    0x8(%rsp),%rcx
 1f82a55:	cmp    $0x2,%eax
 1f82a58:	sete   %dl
 1f82a5b:	mov    0xcb8(%rcx),%rcx
 1f82a62:	xor    %dl,(%rcx)
 1f82a64:	xor    %ecx,%ecx
 1f82a66:	cmp    $0x3,%eax
 1f82a69:	mov    0xcc8(%rdi),%rdx
 1f82a70:	sete   %cl
 1f82a73:	xor    %rcx,(%rdx)
 1f82a76:	mov    0x114(%rsp),%ecx
 1f82a7d:	vmovsd 0x4c0(%rsp),%xmm2
 1f82a86:	vmovups 0x4cc(%rsp),%xmm3
 1f82a8f:	mov    %rcx,0x260(%rsp)
 1f82a97:	mov    0x278(%rsp),%rcx
 1f82a9f:	mov    %rcx,0x258(%rsp)
 1f82aa7:	mov    0x4c8(%rsp),%ecx
 1f82aae:	vmovups %ymm2,0x820(%rsp)
 1f82ab7:	vshufps $0x24,%xmm3,%xmm2,%xmm2
 1f82abc:	mov    %rcx,0x640(%rsp)
 1f82ac4:	vpinsrd $0x2,%ecx,%xmm2,%xmm2
 1f82aca:	xor    %ecx,%ecx
 1f82acc:	cmp    $0xc,%eax
 1f82acf:	vmovaps %xmm3,0x7f0(%rsp)
 1f82ad8:	sete   %cl
 1f82adb:	xor    0x4d8(%rsp),%ecx
 1f82ae2:	vpxor  %xmm1,%xmm2,%xmm1
 1f82ae6:	xor    %ebx,%ebx
 1f82ae8:	test   %eax,%eax
 1f82aea:	vmovdqa %xmm1,0x6b0(%rsp)
 1f82af3:	vshufps $0xe9,%xmm3,%xmm3,%xmm1
 1f82af8:	sete   %bpl
 1f82afc:	cmp    $0x4,%eax
 1f82aff:	vxorps %xmm0,%xmm1,%xmm0
 1f82b03:	sete   0x5f(%rsp)
 1f82b08:	cmp    $0x5,%eax
 1f82b0b:	vmovlps %xmm0,0x6c0(%rsp)
 1f82b14:	vxorps %xmm0,%xmm0,%xmm0
 1f82b18:	mov    %ecx,0x6c8(%rsp)
 1f82b1f:	rdtsc
 1f82b21:	vmovups %ymm0,0x750(%rsp)
 1f82b2a:	movq   $0x0,0x770(%rsp)
 1f82b36:	mov    %rax,0x5a0(%rsp)
 1f82b3e:	mov    %rdx,0x108(%rsp)
 1f82b46:	sete   0x5e(%rsp)
 1f82b4b:	lea    0x750(%rsp),%rdx
 1f82b53:	mov    0x8(%rsp),%rdi
 1f82b58:	vzeroupper
 1f82b5b:	call   1f95220 <node_rows_window_reads>
 1f82b60:	rdtsc
 1f82b62:	mov    %r13,%rsi
 1f82b65:	mov    %rdx,0x100(%rsp)
 1f82b6d:	mov    %r14d,%edx
 1f82b70:	mov    %rax,0x650(%rsp)
 1f82b78:	mov    0x8(%rsp),%rdi
 1f82b7d:	call   1f95940 <node_rows_window_shapes>
 1f82b82:	mov    0x8(%rsp),%rdi
 1f82b87:	rdtsc
 1f82b89:	mov    0xc08(%rdi),%rcx
 1f82b90:	or     0xc00(%rdi),%rcx
 1f82b97:	mov    %rax,0xc0(%rsp)
 1f82b9f:	mov    %rdx,0x710(%rsp)
 1f82ba7:	je     1f82bc1 <node_facts_window_run+0x6671>
 1f82ba9:	lea    0x750(%rsp),%rcx
 1f82bb1:	mov    %r13,%rsi
 1f82bb4:	mov    %r14d,%edx
 1f82bb7:	call   1f95d70 <node_rows_window_updates>
 1f82bbc:	mov    0x8(%rsp),%rdi
 1f82bc1:	rdtsc
 1f82bc3:	mov    %bpl,%bl
 1f82bc6:	mov    %r13,%rsi
 1f82bc9:	mov    %rax,0x50(%rsp)
 1f82bce:	mov    %rdx,0x460(%rsp)
 1f82bd6:	mov    %r14d,%edx
 1f82bd9:	call   1f96580 <node_rows_window_write>
 1f82bde:	mov    %eax,%ecx
 1f82be0:	rdtsc
 1f82be2:	mov    0x760(%rsp),%r8
 1f82bea:	mov    0x770(%rsp),%r9d
 1f82bf2:	vxorps %xmm0,%xmm0,%xmm0
 1f82bf6:	vmovups %xmm0,0x69c(%rsp)
 1f82bff:	vmovaps %xmm0,0x690(%rsp)
 1f82c08:	movl   $0x0,0x110(%rsp)
 1f82c13:	movq   $0x0,0x270(%rsp)
 1f82c1f:	mov    %rax,0xa0(%rsp)
 1f82c27:	mov    %rdx,0x6d0(%rsp)
 1f82c2f:	sub    $0x8,%rsp
 1f82c33:	mov    0x10(%rsp),%rdi
 1f82c38:	lea    0x278(%rsp),%rax
 1f82c40:	lea    0x698(%rsp),%r11
 1f82c48:	lea    0x118(%rsp),%r10
 1f82c50:	mov    %r13,%rsi
 1f82c53:	mov    %r14d,%edx
 1f82c56:	mov    %ecx,0x184(%rsp)
 1f82c5d:	push   %rax
 1f82c5e:	push   %r10
 1f82c60:	push   %r11
 1f82c62:	call   1f96ba0 <node_rows_window_values>
 1f82c67:	add    $0x20,%rsp
 1f82c6b:	rdtsc
 1f82c6d:	mov    %r13,%rsi
 1f82c70:	mov    %rdx,0x440(%rsp)
 1f82c78:	mov    %rax,0xb8(%rsp)
 1f82c80:	mov    0x8(%rsp),%rdi
 1f82c85:	call   1f97a40 <node_rows_window_part>
 1f82c8a:	mov    0x8(%rsp),%r11
 1f82c8f:	rdtsc
 1f82c91:	movl   $0x0,0x170(%rsp)
 1f82c9c:	movq   $0x0,0x168(%rsp)
 1f82ca8:	cmpb   $0x1,0xd50(%r11)
 1f82cb0:	mov    %rax,0x98(%rsp)
 1f82cb8:	mov    %rdx,0x7b0(%rsp)
 1f82cc0:	jne    1f82cdd <node_facts_window_run+0x678d>
 1f82cc2:	lea    0x168(%rsp),%rcx
 1f82cca:	mov    %r11,%rdi
 1f82ccd:	mov    %r13,%rsi
 1f82cd0:	mov    %r14d,%edx
 1f82cd3:	call   1f97b50 <node_rows_window_summary>
 1f82cd8:	mov    0x8(%rsp),%r11
 1f82cdd:	mov    %r14,0x268(%rsp)
 1f82ce5:	rdtsc
 1f82ce7:	mov    0xdb8(%r11),%ecx
 1f82cee:	xor    %ebx,%r15d
 1f82cf1:	movl   $0x0,0xdb8(%r11)
 1f82cfc:	cmpl   $0x0,0xa88(%r11)
 1f82d04:	mov    %rax,0x118(%rsp)
 1f82d0c:	mov    %rdx,0x630(%rsp)
 1f82d14:	mov    %r15d,0x5e0(%rsp)
 1f82d1c:	mov    %ecx,0x174(%rsp)
 1f82d23:	mov    0x30(%rsp),%rbp
 1f82d28:	je     1f835f6 <node_facts_window_run+0x70a6>
 1f82d2e:	vpbroadcastq -0x19b6c6f(%rip),%xmm2        # 5cc0c8 <.LCPI3_1>
 1f82d37:	xor    %r15d,%r15d
 1f82d3a:	jmp    1f82d5c <node_facts_window_run+0x680c>
 1f82d3c:	mov    0x8(%rsp),%r11
 1f82d41:	incq   0xb90(%rbp,%rsi,8)
 1f82d49:	mov    0xa88(%r11),%eax
 1f82d50:	inc    %r15
 1f82d53:	cmp    %rax,%r15
 1f82d56:	jae    1f835f6 <node_facts_window_run+0x70a6>
 1f82d5c:	mov    0xd38(%r11),%rax
 1f82d63:	movzbl (%rax,%r15,1),%eax
 1f82d68:	test   %al,%al
 1f82d6a:	je     1f82d49 <node_facts_window_run+0x67f9>
 1f82d6c:	mov    0xa68(%r11),%rdx
 1f82d73:	mov    0xa60(%r11),%rcx
 1f82d7a:	mov    (%rdx,%r15,4),%edx
 1f82d7e:	mov    (%rcx,%r15,4),%r14d
 1f82d82:	mov    0x651b8(%r13,%rdx,4),%edi
 1f82d8a:	incq   0xb68(%rbp)
 1f82d91:	mov    0xa50(%r11),%rcx
 1f82d98:	mov    (%rcx,%r15,4),%ecx
 1f82d9c:	add    %rcx,0xb70(%rbp)
 1f82da3:	cmp    $0x1,%al
 1f82da5:	jne    1f82e10 <node_facts_window_run+0x68c0>
 1f82da7:	mov    0xa50(%r11),%rax
 1f82dae:	mov    $0x1,%esi
 1f82db3:	mov    (%rax,%r15,4),%r10d
 1f82db7:	test   %r10d,%r10d
 1f82dba:	je     1f82d41 <node_facts_window_run+0x67f1>
 1f82dbc:	mov    0xbe0(%r11),%rax
 1f82dc3:	sub    %edi,%edx
 1f82dc5:	xor    %ecx,%ecx
 1f82dc7:	xor    %r11d,%r11d
 1f82dca:	inc    %edx
 1f82dcc:	nopl   0x0(%rax)
 1f82dd0:	lea    (%rdx,%r11,1),%r9d
 1f82dd4:	cmp    %edi,%r11d
 1f82dd7:	cmovae %r14d,%r9d
 1f82ddb:	mov    %r9d,%r8d
 1f82dde:	shr    $0x3,%r8d
 1f82de2:	and    $0xfffffff8,%r8d
 1f82de6:	mov    0x28(%rax,%r8,8),%rbx
 1f82deb:	bt     %r9,%rbx
 1f82def:	jb     1f83161 <node_facts_window_run+0x6c11>
 1f82df5:	inc    %r11d
 1f82df8:	cmp    %r11d,%r10d
 1f82dfb:	jne    1f82dd0 <node_facts_window_run+0x6880>
 1f82dfd:	jmp    1f82d3c <node_facts_window_run+0x67ec>
 1f82e02:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f82e10:	mov    0xa60(%r11),%rcx
 1f82e17:	mov    0xa68(%r11),%rdx
 1f82e1e:	mov    0xa50(%r11),%rax
 1f82e25:	xor    %r9d,%r9d
 1f82e28:	mov    (%rcx,%r15,4),%ecx
 1f82e2c:	mov    %rcx,0x18(%rsp)
 1f82e31:	mov    (%rdx,%r15,4),%ecx
 1f82e35:	mov    0xc38(%r11),%rdx
 1f82e3c:	mov    0x651b8(%r13,%rcx,4),%esi
 1f82e44:	cmp    %esi,(%rax,%r15,4)
 1f82e48:	jbe    1f82e54 <node_facts_window_run+0x6904>
 1f82e4a:	mov    0x18(%rsp),%rax
 1f82e4f:	movzbl (%rdx,%rax,1),%r9d
 1f82e54:	mov    0xc58(%r11),%r8
 1f82e5b:	mov    0xc78(%r11),%r10
 1f82e62:	mov    %ecx,%edi
 1f82e64:	sub    %esi,%edi
 1f82e66:	mov    %ecx,%esi
 1f82e68:	shr    $0x3,%esi
 1f82e6b:	mov    %r14,0xd0(%rsp)
 1f82e73:	mov    0x938(%r11),%rax
 1f82e7a:	inc    %edi
 1f82e7c:	movzbl (%r8,%rdi,1),%ebx
 1f82e81:	shr    $0x3,%edi
 1f82e84:	mov    (%r10,%rsi,4),%r14d
 1f82e88:	mov    %r10,0x120(%rsp)
 1f82e90:	mov    %r8,0x20(%rsp)
 1f82e95:	add    (%r10,%rdi,4),%ebx
 1f82e99:	movzbl (%rdx,%rcx,1),%r10d
 1f82e9e:	movzbl (%r8,%rcx,1),%edi
 1f82ea3:	mov    0xa48(%r11),%rdx
 1f82eaa:	mov    %r14d,%esi
 1f82ead:	sub    %ebx,%esi
 1f82eaf:	mov    %rbx,0x10(%rsp)
 1f82eb4:	add    %edi,%esi
 1f82eb6:	add    %r10d,%esi
 1f82eb9:	mov    (%rdx,%r15,4),%ecx
 1f82ebd:	mov    0x130(%rax),%rdx
 1f82ec4:	add    %esi,%r9d
 1f82ec7:	mov    (%rdx,%rcx,4),%r8d
 1f82ecb:	cmp    $0xffffffff,%r8d
 1f82ecf:	je     1f83156 <node_facts_window_run+0x6c06>
 1f82ed5:	mov    %r14d,0x180(%rsp)
 1f82edd:	mov    %r10,0x40(%rsp)
 1f82ee2:	mov    %rdi,0x1c0(%rsp)
 1f82eea:	mov    0xdcc(%r11),%r10d
 1f82ef1:	movzbl 0xdc8(%r11),%edi
 1f82ef9:	mov    $0x4,%edx
 1f82efe:	mov    %r10d,%ebx
 1f82f01:	and    $0x3,%ebx
 1f82f04:	test   %edi,%edi
 1f82f06:	mov    %r10d,0xe0(%rsp)
 1f82f0e:	cmove  %edx,%ebx
 1f82f11:	test   $0x4,%r10b
 1f82f15:	movabs $0x8000000000000000,%r10
 1f82f1f:	mov    $0x1,%edx
 1f82f24:	cmove  %rdx,%r10
 1f82f28:	test   %r8d,%r8d
 1f82f2b:	sete   %dl
 1f82f2e:	mov    %r10,0x78(%rsp)
 1f82f33:	mov    %edi,0xd8(%rsp)
 1f82f3a:	mov    %r8d,0xc8(%rsp)
 1f82f42:	mov    %r9,0xa8(%rsp)
 1f82f4a:	and    %dil,%dl
 1f82f4d:	cmp    $0x2,%ebx
 1f82f50:	sete   %dil
 1f82f54:	or     %dl,%dil
 1f82f57:	movzbl %dil,%edx
 1f82f5b:	add    %r8d,%edx
 1f82f5e:	mov    0x110(%rax),%r8
 1f82f65:	cmp    $0x3,%ebx
 1f82f68:	sete   %dil
 1f82f6c:	cmpb   $0x0,(%r8,%rcx,1)
 1f82f71:	setne  %r8b
 1f82f75:	cmp    %edx,%r9d
 1f82f78:	setne  %r14b
 1f82f7c:	xor    %r13d,%r13d
 1f82f7f:	or     %r8b,%r14b
 1f82f82:	jne    1f832ba <node_facts_window_run+0x6d6a>
 1f82f88:	test   %edx,%edx
 1f82f8a:	je     1f832ba <node_facts_window_run+0x6d6a>
 1f82f90:	mov    0x128(%rax),%rdx
 1f82f97:	mov    0x140(%rax),%r12
 1f82f9e:	mov    %esi,%r11d
 1f82fa1:	mov    (%rdx,%rcx,4),%ecx
 1f82fa4:	mov    0x148(%rax),%rdx
 1f82fab:	add    %rcx,%rdx
 1f82fae:	add    %rcx,%r12
 1f82fb1:	shl    $0x3,%rcx
 1f82fb5:	add    0x150(%rax),%rcx
 1f82fbc:	cmp    $0x1,%ebx
 1f82fbf:	mov    %rdx,0x38(%rsp)
 1f82fc4:	sete   %al
 1f82fc7:	cmp    $0x3,%ebx
 1f82fca:	mov    %rcx,0x48(%rsp)
 1f82fcf:	sete   %cl
 1f82fd2:	mov    0xa8(%rsp),%r9
 1f82fda:	cmp    $0x2,%r9d
 1f82fde:	lea    -0x1(%r9),%ebp
 1f82fe2:	setae  %dl
 1f82fe5:	and    %al,%dl
 1f82fe7:	mov    0x18(%rsp),%rax
 1f82fec:	shr    $0x3,%eax
 1f82fef:	mov    %rax,0x60(%rsp)
 1f82ff4:	or     %cl,%dl
 1f82ff6:	mov    %r9d,%ecx
 1f82ff9:	mov    0x8(%rsp),%rax
 1f82ffe:	mov    0xca0(%rax),%r8
 1f83005:	test   %dl,%dl
 1f83007:	je     1f831c7 <node_facts_window_run+0x6c77>
 1f8300d:	mov    0xe0(%rsp),%eax
 1f83014:	xor    %esi,%esi
 1f83016:	and    $0x8,%eax
 1f83019:	shr    $0x3,%eax
 1f8301c:	and    %al,%dil
 1f8301f:	mov    $0x0,%edi
 1f83024:	mov    0x10(%rsp),%rax
 1f83029:	cmovne %rbp,%rdi
 1f8302d:	sub    0x180(%rsp),%eax
 1f83034:	neg    %rbp
 1f83037:	sub    0x40(%rsp),%eax
 1f8303b:	neg    %rdi
 1f8303e:	sub    0x1c0(%rsp),%eax
 1f83045:	mov    %rax,0x40(%rsp)
 1f8304a:	mov    $0x1,%eax
 1f8304f:	mov    %rbp,0x1c0(%rsp)
 1f83057:	xor    %ebp,%ebp
 1f83059:	jmp    1f8307a <node_facts_window_run+0x6b2a>
 1f8305b:	nopl   0x0(%rax,%rax,1)
 1f83060:	inc    %rsi
 1f83063:	cmp    %rcx,%rax
 1f83066:	mov    %r13d,%ebp
 1f83069:	setae  %dl
 1f8306c:	inc    %rax
 1f8306f:	or     %r14b,%dl
 1f83072:	test   %dl,%dl
 1f83074:	jne    1f832ba <node_facts_window_run+0x6d6a>
 1f8307a:	lea    -0x1(%rax),%rdx
 1f8307e:	cmp    %r11,%rdx
 1f83081:	jae    1f83090 <node_facts_window_run+0x6b40>
 1f83083:	mov    0x10(%rsp),%rdx
 1f83088:	lea    (%rdx,%rsi,1),%r9d
 1f8308c:	mov    %esi,%edx
 1f8308e:	jmp    1f830c1 <node_facts_window_run+0x6b71>
 1f83090:	mov    0x18(%rsp),%rdx
 1f83095:	mov    0x20(%rsp),%r9
 1f8309a:	mov    0x120(%rsp),%r14
 1f830a2:	mov    0x60(%rsp),%r10
 1f830a7:	movzbl (%r9,%rdx,1),%r9d
 1f830ac:	mov    0x40(%rsp),%rdx
 1f830b1:	add    (%r14,%r10,4),%r9d
 1f830b5:	lea    (%rdx,%rax,1),%r14d
 1f830b9:	lea    -0x1(%rax),%edx
 1f830bc:	lea    -0x1(%r14,%r9,1),%r9d
 1f830c1:	or     %ebx,%edx
 1f830c3:	lea    (%rdi,%rax,1),%r14
 1f830c7:	mov    $0x0,%edx
 1f830cc:	mov    $0x1,%r13b
 1f830cf:	mov    %r9d,%r9d
 1f830d2:	sete   %r10b
 1f830d6:	xor    -0x1(%r12,%rax,1),%r10b
 1f830db:	cmp    $0x1,%r14
 1f830df:	mov    $0x1,%r14b
 1f830e2:	cmove  0x78(%rsp),%rdx
 1f830e8:	cmp    %r10b,(%r8,%r9,1)
 1f830ec:	jne    1f83129 <node_facts_window_run+0x6bd9>
 1f830ee:	mov    0x1c0(%rsp),%r10
 1f830f6:	cmp    $0x1,%ebx
 1f830f9:	sete   %r14b
 1f830fd:	add    %rax,%r10
 1f83100:	cmp    $0x1,%r10
 1f83104:	sete   %r10b
 1f83108:	and    %r14b,%r10b
 1f8310b:	mov    0x38(%rsp),%r14
 1f83110:	xor    -0x1(%r14,%rax,1),%r10b
 1f83115:	mov    0x8(%rsp),%r14
 1f8311a:	mov    0xca8(%r14),%r14
 1f83121:	cmp    %r10b,(%r14,%r9,1)
 1f83125:	setne  %r14b
 1f83129:	test   $0x1,%bpl
 1f8312d:	jne    1f83060 <node_facts_window_run+0x6b10>
 1f83133:	mov    0x48(%rsp),%r10
 1f83138:	mov    0x8(%rsp),%rbp
 1f8313d:	xor    -0x8(%r10,%rax,8),%rdx
 1f83142:	mov    0xcc0(%rbp),%r10
 1f83149:	cmp    %rdx,(%r10,%r9,8)
 1f8314d:	setne  %r13b
 1f83151:	jmp    1f83060 <node_facts_window_run+0x6b10>
 1f83156:	xor    %r13d,%r13d
 1f83159:	xor    %r14d,%r14d
 1f8315c:	jmp    1f832f1 <node_facts_window_run+0x6da1>
 1f83161:	mov    0x8(%rsp),%r11
 1f83166:	mov    %r9d,%edx
 1f83169:	mov    0xba8(%r11),%rsi
 1f83170:	movzbl (%rsi,%rdx,1),%esi
 1f83174:	and    $0x3f,%sil
 1f83178:	cmp    $0x14,%sil
 1f8317c:	je     1f8318e <node_facts_window_run+0x6c3e>
 1f8317e:	mov    0xc28(%r11),%rsi
 1f83185:	xor    %ecx,%ecx
 1f83187:	cmpb   $0x7f,(%rsi,%rdx,1)
 1f8318b:	setne  %cl
 1f8318e:	and    $0x3f,%r9d
 1f83192:	mov    $0x1,%edx
 1f83197:	mov    $0x2,%esi
 1f8319c:	shlx   %r9,%rdx,%rdx
 1f831a1:	test   %rdx,0x30(%rax,%r8,8)
 1f831a6:	jne    1f82d41 <node_facts_window_run+0x67f1>
 1f831ac:	test   %rdx,0x38(%rax,%r8,8)
 1f831b1:	mov    $0x3,%eax
 1f831b6:	cmovne %rax,%rcx
 1f831ba:	incq   0xb90(%rbp,%rcx,8)
 1f831c2:	jmp    1f82d49 <node_facts_window_run+0x67f9>
 1f831c7:	mov    0x10(%rsp),%rax
 1f831cc:	sub    0x180(%rsp),%eax
 1f831d3:	xor    %esi,%esi
 1f831d5:	xor    %edi,%edi
 1f831d7:	sub    0x40(%rsp),%eax
 1f831db:	sub    0x1c0(%rsp),%eax
 1f831e2:	jmp    1f83208 <node_facts_window_run+0x6cb8>
 1f831e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1f831f0:	inc    %rsi
 1f831f3:	mov    %r13d,%edi
 1f831f6:	cmp    %rcx,%rsi
 1f831f9:	setae  %dl
 1f831fc:	or     %r14b,%dl
 1f831ff:	cmp    $0x1,%dl
 1f83202:	je     1f832ba <node_facts_window_run+0x6d6a>
 1f83208:	cmp    %r11,%rsi
 1f8320b:	jae    1f83220 <node_facts_window_run+0x6cd0>
 1f8320d:	mov    0x10(%rsp),%rdx
 1f83212:	add    %esi,%edx
 1f83214:	jmp    1f83244 <node_facts_window_run+0x6cf4>
 1f83216:	cs nopw 0x0(%rax,%rax,1)
 1f83220:	mov    0x18(%rsp),%rdx
 1f83225:	mov    0x20(%rsp),%r9
 1f8322a:	mov    0x60(%rsp),%r10
 1f8322f:	movzbl (%r9,%rdx,1),%edx
 1f83234:	mov    0x120(%rsp),%r9
 1f8323c:	add    (%r9,%r10,4),%edx
 1f83240:	add    %eax,%edx
 1f83242:	add    %esi,%edx
 1f83244:	mov    %esi,%r9d
 1f83247:	or     %ebx,%r9d
 1f8324a:	mov    $0x1,%r13b
 1f8324d:	mov    $0x1,%r14b
 1f83250:	mov    %edx,%edx
 1f83252:	sete   %r9b
 1f83256:	xor    (%r12,%rsi,1),%r9b
 1f8325a:	cmp    %r9b,(%r8,%rdx,1)
 1f8325e:	jne    1f8328e <node_facts_window_run+0x6d3e>
 1f83260:	cmp    $0x1,%ebx
 1f83263:	sete   %r9b
 1f83267:	cmp    %rsi,%rbp
 1f8326a:	sete   %r10b
 1f8326e:	and    %r9b,%r10b
 1f83271:	mov    0x38(%rsp),%r9
 1f83276:	xor    (%r9,%rsi,1),%r10b
 1f8327a:	mov    0x8(%rsp),%r9
 1f8327f:	mov    0xca8(%r9),%r9
 1f83286:	cmp    %r10b,(%r9,%rdx,1)
 1f8328a:	setne  %r14b
 1f8328e:	test   $0x1,%dil
 1f83292:	jne    1f831f0 <node_facts_window_run+0x6ca0>
 1f83298:	mov    0x48(%rsp),%rdi
 1f8329d:	mov    0x8(%rsp),%r9
 1f832a2:	mov    (%rdi,%rsi,8),%rdi
 1f832a6:	mov    0xcc0(%r9),%r9
 1f832ad:	cmp    %rdi,(%r9,%rdx,8)
 1f832b1:	setne  %r13b
 1f832b5:	jmp    1f831f0 <node_facts_window_run+0x6ca0>
 1f832ba:	mov    0xe0(%rsp),%eax
 1f832c1:	mov    0x8(%rsp),%r11
 1f832c6:	mov    0x90(%rsp),%r12
 1f832ce:	mov    0x30(%rsp),%rbp
 1f832d3:	mov    0xa8(%rsp),%r9
 1f832db:	mov    0xc8(%rsp),%r8d
 1f832e3:	add    0xd8(%rsp),%eax
 1f832ea:	mov    %eax,0xdcc(%r11)
 1f832f1:	cmp    $0xffffffff,%r8d
 1f832f5:	vmovd  %r9d,%xmm1
 1f832fa:	mov    %r14d,%ecx
 1f832fd:	sete   %al
 1f83300:	incq   0xb78(%rbp)
 1f83307:	or     %r13b,%r14b
 1f8330a:	xor    $0x1,%cl
 1f8330d:	mov    0xa50(%r11),%rdx
 1f83314:	and    %r13b,%cl
 1f83317:	vmovd  (%rdx,%r15,4),%xmm0
 1f8331d:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1f83321:	vpaddq 0xb80(%rbp),%xmm0,%xmm0
 1f83329:	vmovdqu %xmm0,0xb80(%rbp)
 1f83331:	vmovd  %r14d,%xmm0
 1f83336:	vpinsrb $0x1,%eax,%xmm0,%xmm0
 1f8333c:	movzbl %cl,%eax
 1f8333f:	vpmovzxbq %xmm0,%xmm0
 1f83344:	vptestmq %xmm2,%xmm0,%k0
 1f8334a:	vmovdqu 0xbb0(%rbp),%xmm0
 1f83352:	vpmovm2q %k0,%xmm1
 1f83358:	vpsubq %xmm1,%xmm0,%xmm0
 1f8335c:	vmovdqu %xmm0,0xbb0(%rbp)
 1f83364:	add    %rax,0xc98(%rbp)
 1f8336b:	mov    0xd40(%r11),%rax
 1f83372:	mov    (%rax,%r15,8),%rax
 1f83376:	add    %rax,0xc20(%rbp)
 1f8337d:	test   $0x1,%r14b
 1f83381:	je     1f833ba <node_facts_window_run+0x6e6a>
 1f83383:	mov    0x1384(%rbp),%eax
 1f83389:	mov    0x28(%rsp),%r13
 1f8338e:	cmp    $0xf,%rax
 1f83392:	ja     1f82d49 <node_facts_window_run+0x67f9>
 1f83398:	mov    0xd0(%rsp),%rcx
 1f833a0:	mov    0x422c(%r13,%rcx,4),%ecx
 1f833a8:	mov    %ecx,0x1344(%rbp,%rax,4)
 1f833af:	incl   0x1384(%rbp)
 1f833b5:	jmp    1f82d49 <node_facts_window_run+0x67f9>
 1f833ba:	cmpb   $0x1,0xd50(%r11)
 1f833c2:	mov    0x28(%rsp),%r13
 1f833c7:	jne    1f82d49 <node_facts_window_run+0x67f9>
 1f833cd:	mov    0xd98(%r11),%rax
 1f833d4:	mov    $0x4,%r12d
 1f833da:	movzbl (%rax,%r15,1),%r14d
 1f833df:	incq   0xcc0(%rbp)
 1f833e6:	mov    0xa68(%r11),%rax
 1f833ed:	mov    0xd90(%r11),%rcx
 1f833f4:	mov    (%rax,%r15,4),%eax
 1f833f8:	lea    0x1(%rax),%edx
 1f833fb:	movzwl -0x2(%rcx,%rdx,2),%ebp
 1f83400:	sub    0x651b8(%r13,%rax,4),%edx
 1f83408:	cmpb   $0x1,0xdbc(%r11)
 1f83410:	movzwl -0x2(%rcx,%rdx,2),%eax
 1f83415:	jne    1f83428 <node_facts_window_run+0x6ed8>
 1f83417:	mov    0xdc0(%r11),%r12d
 1f8341e:	and    $0x3,%r12d
 1f83422:	je     1f834f7 <node_facts_window_run+0x6fa7>
 1f83428:	cmp    $0x1,%r12d
 1f8342c:	mov    $0xffffffff,%r8d
 1f83432:	sete   %cl
 1f83435:	cmp    %ax,%bp
 1f83438:	sete   %bl
 1f8343b:	and    %cl,%bl
 1f8343d:	mov    0x938(%r11),%r13
 1f83444:	sub    %eax,%ebp
 1f83446:	cmpq   $0x0,0x168(%r13)
 1f8344e:	je     1f835ae <node_facts_window_run+0x705e>
 1f83454:	mov    0xa48(%r11),%rcx
 1f8345b:	mov    (%rcx,%r15,4),%edx
 1f8345f:	cmp    0x20(%r13),%edx
 1f83463:	jae    1f835ae <node_facts_window_run+0x705e>
 1f83469:	mov    0x188(%r13),%rdi
 1f83470:	movzbl %bl,%esi
 1f83473:	mov    %ebp,%r9d
 1f83476:	lea    (%rsi,%rdi,1),%rcx
 1f8347a:	add    %r9,%rcx
 1f8347d:	cmp    0x190(%r13),%rcx
 1f83484:	ja     1f8351b <node_facts_window_run+0x6fcb>
 1f8348a:	cmp    $0xfffe,%ebp
 1f83490:	ja     1f8351b <node_facts_window_run+0x6fcb>
 1f83496:	shl    $0x2,%rdi
 1f8349a:	mov    %r8d,0x120(%rsp)
 1f834a2:	mov    %rsi,0x10(%rsp)
 1f834a7:	lea    0x0(,%rax,4),%esi
 1f834ae:	add    0x180(%r13),%rdi
 1f834b5:	add    0xd88(%r11),%rsi
 1f834bc:	mov    %rdx,0x18(%rsp)
 1f834c1:	lea    0x0(,%r9,4),%rdx
 1f834c9:	mov    %rdi,0x20(%rsp)
 1f834ce:	mov    %r9,0x78(%rsp)
 1f834d3:	call   355bd30 <memcpy>
 1f834d8:	test   %bl,%bl
 1f834da:	je     1f83524 <node_facts_window_run+0x6fd4>
 1f834dc:	mov    0x120(%rsp),%eax
 1f834e3:	mov    0x20(%rsp),%rcx
 1f834e8:	mov    0x78(%rsp),%rdx
 1f834ed:	mov    0x18(%rsp),%rsi
 1f834f2:	mov    %eax,(%rcx,%rdx,4)
 1f834f5:	jmp    1f8353a <node_facts_window_run+0x6fea>
 1f834f7:	xor    %r8d,%r8d
 1f834fa:	mov    $0x1,%bl
 1f834fc:	xor    %r12d,%r12d
 1f834ff:	mov    0x938(%r11),%r13
 1f83506:	sub    %eax,%ebp
 1f83508:	cmpq   $0x0,0x168(%r13)
 1f83510:	jne    1f83454 <node_facts_window_run+0x6f04>
 1f83516:	jmp    1f835ae <node_facts_window_run+0x705e>
 1f8351b:	incq   0x198(%r13)
 1f83522:	jmp    1f8359f <node_facts_window_run+0x704f>
 1f83524:	mov    0x20(%rsp),%rax
 1f83529:	mov    0x18(%rsp),%rsi
 1f8352e:	cmp    $0x1,%r12d
 1f83532:	jne    1f8353a <node_facts_window_run+0x6fea>
 1f83534:	movl   $0x0,(%rax)
 1f8353a:	mov    0x188(%r13),%eax
 1f83541:	mov    0x168(%r13),%rcx
 1f83548:	mov    0x10(%rsp),%rdi
 1f8354d:	mov    0x8(%rsp),%r11
 1f83552:	mov    $0x1,%edx
 1f83557:	vpbroadcastq -0x19b7498(%rip),%xmm2        # 5cc0c8 <.LCPI3_1>
 1f83560:	mov    %eax,(%rcx,%rsi,4)
 1f83563:	add    %ebp,%edi
 1f83565:	cmp    $0x3,%r12d
 1f83569:	mov    0x170(%r13),%rax
 1f83570:	sete   %cl
 1f83573:	add    %cl,%cl
 1f83575:	cmp    $0x2,%r12d
 1f83579:	movzbl %cl,%ecx
 1f8357c:	cmove  %edx,%ecx
 1f8357f:	mov    %di,(%rax,%rsi,2)
 1f83583:	mov    0xd98(%r11),%rax
 1f8358a:	mov    0x178(%r13),%rdx
 1f83591:	xor    (%rax,%r15,1),%cl
 1f83595:	mov    %cl,(%rdx,%rsi,1)
 1f83598:	add    %rdi,0x188(%r13)
 1f8359f:	movzbl 0xdbc(%r11),%eax
 1f835a7:	add    %eax,0xdc0(%r11)
 1f835ae:	vmovd  %ebp,%xmm1
 1f835b2:	mov    0x30(%rsp),%rbp
 1f835b7:	mov    $0x101,%eax
 1f835bc:	mov    0x90(%rsp),%r12
 1f835c4:	mov    0x28(%rsp),%r13
 1f835c9:	bextr  %eax,%r14d,%eax
 1f835ce:	and    $0x1,%r14d
 1f835d2:	vmovd  %eax,%xmm0
 1f835d6:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f835da:	vpaddq 0xcc8(%rbp),%xmm0,%xmm0
 1f835e2:	vmovdqu %xmm0,0xcc8(%rbp)
 1f835ea:	add    %r14,0xcd8(%rbp)
 1f835f1:	jmp    1f82d49 <node_facts_window_run+0x67f9>
 1f835f6:	shlq   $0x20,0x300(%rsp)
 1f835ff:	shlq   $0x20,0x2c0(%rsp)
 1f83608:	shlq   $0x20,0x280(%rsp)
 1f83611:	shlq   $0x20,0x400(%rsp)
 1f8361a:	shlq   $0x20,0x480(%rsp)
 1f83623:	shlq   $0x20,0x560(%rsp)
 1f8362c:	shlq   $0x20,0x520(%rsp)
 1f83635:	shlq   $0x20,0x4e0(%rsp)
 1f8363e:	shlq   $0x20,0x108(%rsp)
 1f83647:	shlq   $0x20,0x100(%rsp)
 1f83650:	shlq   $0x20,0x710(%rsp)
 1f83659:	shlq   $0x20,0x460(%rsp)
 1f83662:	shlq   $0x20,0x6d0(%rsp)
 1f8366b:	shlq   $0x20,0x440(%rsp)
 1f83674:	shlq   $0x20,0x7b0(%rsp)
 1f8367d:	mov    $0x1,%r8d
 1f83683:	vmovd  0x268(%rsp),%xmm1
 1f8368c:	mov    0x638(%rsp),%rbx
 1f83694:	mov    0x630(%rsp),%r15
 1f8369c:	mov    0x17c(%rsp),%eax
 1f836a3:	vmovd  %ebx,%xmm0
 1f836a7:	shl    $0x20,%r15
 1f836ab:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f836af:	vpaddq 0xbc0(%rbp),%xmm0,%xmm0
 1f836b7:	vmovdqu %xmm0,0xbc0(%rbp)
 1f836bf:	cmp    %eax,0x5e0(%rsp)
 1f836c6:	jne    1f83715 <node_facts_window_run+0x71c5>
 1f836c8:	mov    0xca0(%r11),%rsi
 1f836cf:	mov    0xcb0(%r11),%rdi
 1f836d6:	mov    %rbx,%rdx
 1f836d9:	mov    %r11,%r14
 1f836dc:	call   355bd20 <strlen+0x10>
 1f836e1:	mov    0x80(%rsp),%rsi
 1f836e9:	mov    0x248(%rsp),%r13
 1f836f1:	test   %eax,%eax
 1f836f3:	je     1f83754 <node_facts_window_run+0x7204>
 1f836f5:	mov    %r14,%r11
 1f836f8:	mov    0x88(%rsp),%rax
 1f83700:	mov    0xb0(%rsp),%rcx
 1f83708:	mov    0x118(%rsp),%r14
 1f83710:	jmp    1f83795 <node_facts_window_run+0x7245>
 1f83715:	mov    0x80(%rsp),%rsi
 1f8371d:	mov    0x248(%rsp),%r13
 1f83725:	mov    0x88(%rsp),%rax
 1f8372d:	mov    0xb0(%rsp),%rcx
 1f83735:	mov    0x118(%rsp),%r14
 1f8373d:	jmp    1f8379b <node_facts_window_run+0x724b>
 1f8373f:	setb   %al
 1f83742:	test   %ebp,%ebp
 1f83744:	sete   %cl
 1f83747:	test   %cl,%al
 1f83749:	je     1f82845 <node_facts_window_run+0x62f5>
 1f8374f:	jmp    1f82857 <node_facts_window_run+0x6307>
 1f83754:	mov    0xca8(%r14),%rsi
 1f8375b:	mov    0xcb8(%r14),%rdi
 1f83762:	mov    %rbx,%rdx
 1f83765:	call   355bd20 <strlen+0x10>
 1f8376a:	test   %eax,%eax
 1f8376c:	je     1f83c07 <node_facts_window_run+0x76b7>
 1f83772:	mov    %r14,%r11
 1f83775:	mov    0x88(%rsp),%rax
 1f8377d:	mov    0xb0(%rsp),%rcx
 1f83785:	mov    0x118(%rsp),%r14
 1f8378d:	mov    0x80(%rsp),%rsi
 1f83795:	mov    $0x1,%r8d
 1f8379b:	mov    0x400(%rsp),%rdx
 1f837a3:	or     0x300(%rsp),%rsi
 1f837ab:	or     0x2c0(%rsp),%r13
 1f837b3:	or     0x280(%rsp),%rax
 1f837bb:	add    %r8,0xbd0(%rbp)
 1f837c2:	or     %r15,%r14
 1f837c5:	or     %rdx,0x3c0(%rsp)
 1f837cd:	mov    0x480(%rsp),%rdx
 1f837d5:	or     %rdx,0x200(%rsp)
 1f837dd:	mov    0x560(%rsp),%rdx
 1f837e5:	or     %rdx,0x380(%rsp)
 1f837ed:	mov    0x520(%rsp),%rdx
 1f837f5:	or     %rdx,0x340(%rsp)
 1f837fd:	mov    0x108(%rsp),%rdx
 1f83805:	or     0x4e0(%rsp),%rcx
 1f8380d:	or     %rdx,0x5a0(%rsp)
 1f83815:	mov    0x100(%rsp),%rdx
 1f8381d:	or     %rdx,0x650(%rsp)
 1f83825:	mov    0x710(%rsp),%rdx
 1f8382d:	or     %rdx,0xc0(%rsp)
 1f83835:	mov    0x460(%rsp),%rdx
 1f8383d:	or     %rdx,0x50(%rsp)
 1f83842:	mov    0x6d0(%rsp),%rdx
 1f8384a:	or     %rdx,0xa0(%rsp)
 1f83852:	mov    0x440(%rsp),%rdx
 1f8385a:	or     %rdx,0xb8(%rsp)
 1f83862:	mov    0x7b0(%rsp),%rdx
 1f8386a:	or     %rdx,0x98(%rsp)
 1f83872:	cmpb   $0x1,0xd50(%r11)
 1f8387a:	jne    1f8391f <node_facts_window_run+0x73cf>
 1f83880:	mov    0x178(%rsp),%edx
 1f83887:	mov    $0x1,%ebx
 1f8388c:	xor    0xe8(%rsp),%edx
 1f83893:	cmp    0x168(%rsp),%edx
 1f8389a:	jne    1f8392b <node_facts_window_run+0x73db>
 1f838a0:	mov    0xf4(%rsp),%edx
 1f838a7:	mov    %rax,0x88(%rsp)
 1f838af:	cmp    0x16c(%rsp),%edx
 1f838b6:	jne    1f83923 <node_facts_window_run+0x73d3>
 1f838b8:	mov    0xf8(%rsp),%eax
 1f838bf:	cmp    0x170(%rsp),%eax
 1f838c6:	jne    1f83923 <node_facts_window_run+0x73d3>
 1f838c8:	mov    %rsi,0x80(%rsp)
 1f838d0:	mov    %rcx,0xb0(%rsp)
 1f838d8:	mov    0xd90(%r11),%rsi
 1f838df:	mov    0xda0(%r11),%rdi
 1f838e6:	mov    %r11,%r15
 1f838e9:	mov    0x268(%rsp),%rax
 1f838f1:	lea    (%rax,%rax,1),%rdx
 1f838f5:	call   355bd20 <strlen+0x10>
 1f838fa:	test   %eax,%eax
 1f838fc:	je     1f83cde <node_facts_window_run+0x778e>
 1f83902:	mov    0x88(%rsp),%rax
 1f8390a:	mov    0xb0(%rsp),%rcx
 1f83912:	mov    0x80(%rsp),%rsi
 1f8391a:	mov    %r15,%r11
 1f8391d:	jmp    1f8392b <node_facts_window_run+0x73db>
 1f8391f:	xor    %ebx,%ebx
 1f83921:	jmp    1f8392b <node_facts_window_run+0x73db>
 1f83923:	mov    0x88(%rsp),%rax
 1f8392b:	vmovd  0x250(%rsp),%xmm1
 1f83934:	mov    0x340(%rsp),%rdx
 1f8393c:	vmovd  %ebx,%xmm2
 1f83940:	mov    0x98(%rsp),%rdi
 1f83948:	vpmovzxdq 0x7f0(%rsp),%ymm7
 1f83952:	vmovq  0x3c0(%rsp),%xmm4
 1f8395b:	vmovq  %r13,%xmm3
 1f83960:	vmovq  %rsi,%xmm5
 1f83965:	mov    0xb8(%rsp),%rsi
 1f8396d:	mov    0xa0(%rsp),%r8
 1f83975:	sub    %rdx,%rcx
 1f83978:	sub    %rdi,%r14
 1f8397b:	vmovq  %rcx,%xmm0
 1f83980:	mov    0x380(%rsp),%rcx
 1f83988:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f8398c:	vmovd  0xf8(%rsp),%xmm1
 1f83995:	sub    %rcx,%rdx
 1f83998:	vpunpcklqdq %xmm2,%xmm1,%xmm1
 1f8399c:	vmovq  %rax,%xmm2
 1f839a1:	mov    0x200(%rsp),%rax
 1f839a9:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
 1f839af:	vpaddq 0xce0(%rbp),%ymm0,%ymm0
 1f839b7:	vmovd  0x260(%rsp),%xmm1
 1f839c0:	vpbroadcastq %rax,%ymm6
 1f839c6:	sub    %rax,%rcx
 1f839c9:	mov    %rsi,%rax
 1f839cc:	sub    %r8,%rax
 1f839cf:	vmovdqu %ymm0,0xce0(%rbp)
 1f839d7:	add    %r14,0xd00(%rbp)
 1f839de:	vmovq  0x258(%rsp),%xmm0
 1f839e7:	vpaddq 0xc68(%rbp),%ymm7,%ymm7
 1f839ef:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f839f3:	vmovdqu %ymm7,0xc68(%rbp)
 1f839fb:	vpaddq 0xc88(%rbp),%xmm0,%xmm0
 1f83a03:	vmovdqu %xmm0,0xc88(%rbp)
 1f83a0b:	vpunpcklqdq %xmm2,%xmm3,%xmm0
 1f83a0f:	vmovq  0x50(%rsp),%xmm2
 1f83a15:	vmovq  0xc0(%rsp),%xmm3
 1f83a1e:	vinserti128 $0x1,%xmm4,%ymm0,%ymm0
 1f83a24:	vpbroadcastq %r8,%ymm4
 1f83a2a:	vpblendd $0xc0,%ymm6,%ymm0,%ymm1
 1f83a30:	vpermq $0x90,%ymm0,%ymm0
 1f83a36:	vpbroadcastq %rsi,%ymm6
 1f83a3c:	vpblendd $0x3,%ymm5,%ymm0,%ymm0
 1f83a42:	vpbroadcastq %rdi,%ymm5
 1f83a48:	vpsubq %ymm0,%ymm1,%ymm0
 1f83a4c:	vmovdqu 0x880(%rsp),%ymm1
 1f83a55:	vpunpcklqdq %xmm2,%xmm3,%xmm2
 1f83a59:	vpblendd $0x30,%ymm4,%ymm2,%ymm3
 1f83a5f:	vpermq $0xd0,%ymm2,%ymm2
 1f83a65:	vmovdqa64 -0x1accdef(%rip),%zmm4        # 4b6c80 <abi_test_hex.digits+0xb900>
 1f83a6f:	vpblendd $0xc0,%ymm5,%ymm3,%ymm3
 1f83a75:	vpmovzxdq 0x820(%rsp),%zmm5
 1f83a7d:	vinserti64x4 $0x1,%ymm0,%zmm1,%zmm0
 1f83a84:	vpaddq 0xbd8(%rbp),%zmm0,%zmm0
 1f83a8e:	vmovq  %rcx,%xmm1
 1f83a93:	vmovdqu64 %zmm0,0xbd8(%rbp)
 1f83a9d:	vmovq  %rax,%xmm0
 1f83aa2:	mov    0x650(%rsp),%rax
 1f83aaa:	add    %rdx,0xc18(%rbp)
 1f83ab1:	vpunpcklqdq %xmm0,%xmm1,%xmm0
 1f83ab5:	vpmovzxdq 0xf0(%rsp),%xmm1
 1f83abf:	vmovq  %rax,%xmm7
 1f83ac4:	sub    0x5a0(%rsp),%rax
 1f83acc:	vpblendd $0x3,%ymm7,%ymm2,%ymm2
 1f83ad2:	vpblendd $0xc0,%ymm6,%ymm2,%ymm2
 1f83ad8:	vmovdqa64 -0x1accea2(%rip),%zmm6        # 4b6c40 <abi_test_hex.digits+0xb8c0>
 1f83ae2:	vpsubq %ymm2,%ymm3,%ymm2
 1f83ae6:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
 1f83aec:	vpaddq 0xca0(%rbp),%ymm0,%ymm0
 1f83af4:	vmovq  %rax,%xmm8
 1f83af9:	mov    $0x80,%al
 1f83afb:	kmovd  %eax,%k1
 1f83aff:	mov    0x640(%rsp),%rax
 1f83b07:	vpermi2q %zmm8,%zmm2,%zmm6
 1f83b0d:	vmovdqu %ymm0,0xca0(%rbp)
 1f83b15:	vpermi2q %zmm5,%zmm6,%zmm4
 1f83b1b:	vpbroadcastq %rax,%zmm4{%k1}
 1f83b21:	vpaddq 0xc28(%rbp),%zmm4,%zmm0
 1f83b2b:	vmovdqu64 %zmm0,0xc28(%rbp)
 1f83b35:	vmovups 0x9c8(%r11),%zmm0
 1f83b3f:	vmovups 0x268(%r11),%zmm1
 1f83b49:	vmovups 0x840(%rsp),%zmm3
 1f83b51:	vmovaps 0x810(%rsp),%xmm2
 1f83b5a:	xor    %esi,%esi
 1f83b5c:	mov    %r12,%rdx
 1f83b5f:	vmovups %zmm0,0x268(%r11)
 1f83b69:	vmovups %zmm1,0x9c8(%r11)
 1f83b73:	vmovups 0xa08(%r11),%xmm0
 1f83b7c:	vmovups 0x2a8(%r11),%xmm1
 1f83b85:	vmovups %xmm0,0x2a8(%r11)
 1f83b8e:	vmovups %xmm1,0xa08(%r11)
 1f83b97:	vmovaps 0x800(%rsp),%xmm1
 1f83ba0:	mov    0x2b8(%r11),%rax
 1f83ba7:	mov    0xa18(%r11),%rcx
 1f83bae:	mov    %rcx,0x2b8(%r11)
 1f83bb5:	mov    %rax,0xa18(%r11)
 1f83bbc:	mov    0x648(%rsp),%rax
 1f83bc4:	vmovups %zmm3,0x1f0(%r11)
 1f83bce:	mov    %rax,0x230(%r11)
 1f83bd5:	vmovups %xmm2,0x240(%r11)
 1f83bde:	vmovlps %xmm1,0x258(%r11)
 1f83be7:	mov    0x9b0(%r11),%rdi
 1f83bee:	add    $0xc98,%rsp
 1f83bf5:	pop    %rbx
 1f83bf6:	pop    %r12
 1f83bf8:	pop    %r13
 1f83bfa:	pop    %r14
 1f83bfc:	pop    %r15
 1f83bfe:	pop    %rbp
 1f83bff:	vzeroupper
 1f83c02:	jmp    355bda0 <memset>
 1f83c07:	mov    0xcc0(%r14),%rsi
 1f83c0e:	mov    0xcc8(%r14),%rdi
 1f83c15:	mov    0x628(%rsp),%rdx
 1f83c1d:	call   355bd20 <strlen+0x10>
 1f83c22:	mov    0x118(%rsp),%r14
 1f83c2a:	test   %eax,%eax
 1f83c2c:	jne    1f83d70 <node_facts_window_run+0x7820>
 1f83c32:	movzbl 0x5f(%rsp),%ecx
 1f83c37:	xor    %eax,%eax
 1f83c39:	mov    $0x1,%r8d
 1f83c3f:	mov    %cl,%al
 1f83c41:	xor    0x260(%rsp),%eax
 1f83c48:	mov    0xb0(%rsp),%rcx
 1f83c50:	cmp    0x110(%rsp),%eax
 1f83c57:	mov    0x88(%rsp),%rax
 1f83c5f:	jne    1f83d8a <node_facts_window_run+0x783a>
 1f83c65:	movzbl 0x5e(%rsp),%esi
 1f83c6a:	mov    0x8(%rsp),%r11
 1f83c6f:	xor    %edx,%edx
 1f83c71:	mov    %sil,%dl
 1f83c74:	xor    0x258(%rsp),%rdx
 1f83c7c:	cmp    0x270(%rsp),%rdx
 1f83c84:	jne    1f83d63 <node_facts_window_run+0x7813>
 1f83c8a:	vmovdqu 0x6bc(%rsp),%xmm1
 1f83c93:	vmovdqa 0x6b0(%rsp),%xmm0
 1f83c9c:	mov    0x80(%rsp),%rsi
 1f83ca4:	vpxor  0x690(%rsp),%xmm0,%xmm0
 1f83cad:	vpternlogq $0xf6,0x69c(%rsp),%xmm1,%xmm0
 1f83cb9:	vptest %xmm0,%xmm0
 1f83cbe:	jne    1f8379b <node_facts_window_run+0x724b>
 1f83cc4:	mov    0x174(%rsp),%edx
 1f83ccb:	xor    %r8d,%r8d
 1f83cce:	cmp    %edx,0x250(%rsp)
 1f83cd5:	setne  %r8b
 1f83cd9:	jmp    1f8379b <node_facts_window_run+0x724b>
 1f83cde:	mov    0xd98(%r15),%rsi
 1f83ce5:	mov    0xda8(%r15),%rdi
 1f83cec:	mov    0x240(%rsp),%rdx
 1f83cf4:	call   355bd20 <strlen+0x10>
 1f83cf9:	mov    %r15,%r11
 1f83cfc:	mov    0xb0(%rsp),%rcx
 1f83d04:	mov    0x80(%rsp),%rsi
 1f83d0c:	test   %eax,%eax
 1f83d0e:	mov    0x88(%rsp),%rax
 1f83d16:	jne    1f8392b <node_facts_window_run+0x73db>
 1f83d1c:	mov    0xf0(%rsp),%edx
 1f83d23:	mov    0xd88(%r11),%rsi
 1f83d2a:	mov    0xdb0(%r11),%rdi
 1f83d31:	shl    $0x2,%rdx
 1f83d35:	call   355bd20 <strlen+0x10>
 1f83d3a:	xor    %ebx,%ebx
 1f83d3c:	test   %eax,%eax
 1f83d3e:	mov    0x80(%rsp),%rsi
 1f83d46:	mov    0xb0(%rsp),%rcx
 1f83d4e:	mov    0x8(%rsp),%r11
 1f83d53:	mov    0x88(%rsp),%rax
 1f83d5b:	setne  %bl
 1f83d5e:	jmp    1f8392b <node_facts_window_run+0x73db>
 1f83d63:	mov    0x80(%rsp),%rsi
 1f83d6b:	jmp    1f8379b <node_facts_window_run+0x724b>
 1f83d70:	mov    0x8(%rsp),%r11
 1f83d75:	mov    0x88(%rsp),%rax
 1f83d7d:	mov    0xb0(%rsp),%rcx
 1f83d85:	jmp    1f8378d <node_facts_window_run+0x723d>
 1f83d8a:	mov    0x8(%rsp),%r11
 1f83d8f:	mov    0x80(%rsp),%rsi
 1f83d97:	jmp    1f8379b <node_facts_window_run+0x724b>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .iplt:
