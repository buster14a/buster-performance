typedef long long v4 __attribute__((vector_size(32)));
v4 ext(v4);
int f(int n)
{
    v4 z = { n };
    return (int)ext(z)[0];
}
