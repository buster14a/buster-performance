struct B { unsigned f : 3; };
void f(struct B* b)
{
    b->f = 9;
}
