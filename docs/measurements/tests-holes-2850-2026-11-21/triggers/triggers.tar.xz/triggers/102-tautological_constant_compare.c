int f(_Bool b, unsigned u)
{
    return (b > 1) + (b == 2) + (u < 0);
}
