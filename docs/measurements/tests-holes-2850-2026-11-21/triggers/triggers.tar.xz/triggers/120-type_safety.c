static const int tag_long __attribute__((type_tag_for_datatype(magic, long))) = 42;
void take(void* buffer, int tag) __attribute__((pointer_with_type_tag(magic, 1, 2)));
void f(int* p)
{
    take(p, 42);
}
