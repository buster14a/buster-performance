int printf(const char*, ...);
void f(const char* s)
{
    printf(s);
}
