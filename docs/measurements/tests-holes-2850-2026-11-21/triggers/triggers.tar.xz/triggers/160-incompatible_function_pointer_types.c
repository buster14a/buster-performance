void g(int);
void f(void)
{
    void (*q)(long) = g;
    q = g;
    q(1);
}
