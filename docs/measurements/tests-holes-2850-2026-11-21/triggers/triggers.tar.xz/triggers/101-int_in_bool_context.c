int f(int a)
{
    if (a << 3) return 1;
    return a * 2 ? 3 : 4;
}
