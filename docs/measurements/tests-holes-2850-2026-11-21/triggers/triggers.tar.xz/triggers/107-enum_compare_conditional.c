enum A { A0, A1 };
enum B { B0, B1 };
int f(int c, enum A a, enum B b)
{
    return c ? a : b;
}
