int f(void)
{
    return 'abcd';
}
