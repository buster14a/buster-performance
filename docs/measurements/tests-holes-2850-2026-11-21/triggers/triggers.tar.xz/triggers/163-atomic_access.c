struct S { int x; };
_Atomic(struct S) a;
int f(void)
{
    return a.x;
}
