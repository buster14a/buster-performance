void f(unsigned* u, int* s)
{
    s = u;
    (void)s;
}
