int f(void)
{
    return 'ab';
}
