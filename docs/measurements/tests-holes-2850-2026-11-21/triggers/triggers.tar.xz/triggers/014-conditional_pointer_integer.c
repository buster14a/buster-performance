void* f(int c, int* p, long a)
{
    return c ? p : a;
}
