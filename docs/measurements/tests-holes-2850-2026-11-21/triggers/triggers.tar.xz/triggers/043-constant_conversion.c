int f(void)
{
    char c = 300;
    c = 400;
    return c;
}
