void g(int);
void f(int n)
{
    for (int i = 0, j = 0; i < n; j++) g(j);
}
