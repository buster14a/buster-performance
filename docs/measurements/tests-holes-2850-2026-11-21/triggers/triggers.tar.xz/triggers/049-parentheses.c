int f(int a, int b)
{
    if (a = b) return 1;
    return a & b == 2;
}
