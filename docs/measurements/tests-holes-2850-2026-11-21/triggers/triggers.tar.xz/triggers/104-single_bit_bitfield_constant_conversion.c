struct B { int f : 1; };
void f(struct B* b)
{
    b->f = 1;
}
