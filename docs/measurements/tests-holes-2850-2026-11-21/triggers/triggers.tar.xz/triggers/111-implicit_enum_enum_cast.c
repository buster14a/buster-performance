enum A { A0, A1 };
enum B { B0, B1 };
enum A f(enum B b)
{
    enum A a = b;
    a = b;
    return a;
}
