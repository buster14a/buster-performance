typedef char C16 __attribute__((vector_size(16)));
__attribute__((target("avx512bw,avx512vl"))) unsigned short f(C16 a)
{
    return __builtin_ia32_cmpb128_mask(a, a, 8, 65535);
}
