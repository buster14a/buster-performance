int f(int* p, long a)
{
    return p == a;
}
