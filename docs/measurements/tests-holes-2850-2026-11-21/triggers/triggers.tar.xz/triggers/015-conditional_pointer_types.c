void* f(int c, int* p, long* q)
{
    return c ? p : q;
}
