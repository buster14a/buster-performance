int f(void)
{
    int a[4];
    a[0] = 0;
    return a[5];
}
