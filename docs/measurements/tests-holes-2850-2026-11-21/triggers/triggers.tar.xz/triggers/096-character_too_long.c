int f(void)
{
    return 'abcde';
}
