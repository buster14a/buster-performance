int* f(void)
{
    int a = 0;
    return &a;
}
