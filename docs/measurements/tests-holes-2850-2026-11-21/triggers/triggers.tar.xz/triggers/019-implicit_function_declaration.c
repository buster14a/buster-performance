int f(void)
{
    return undeclared_function(1);
}
