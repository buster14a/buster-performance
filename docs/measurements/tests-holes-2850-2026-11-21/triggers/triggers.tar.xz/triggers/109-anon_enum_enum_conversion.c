enum A { A0, A1 };
enum B { B0, B1 };
enum { X0, X1 };
int f(enum B b)
{
    return X1 + b;
}
