int f(void)
{
    return printf("x");
}
