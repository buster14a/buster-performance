unsigned long f(void)
{
    int a[4];
    return sizeof(a + 1);
}
