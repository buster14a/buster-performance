int g(void) __attribute__((warn_unused_result));
void f(void)
{
    g();
}
