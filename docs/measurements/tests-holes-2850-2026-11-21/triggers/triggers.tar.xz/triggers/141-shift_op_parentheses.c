int f(int a, int b)
{
    return a << b + 1;
}
