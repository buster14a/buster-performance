enum A { A0, A1 };
enum B { B0, B1 };
double f(enum A a, double d)
{
    return a + d;
}
