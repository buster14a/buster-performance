int f(int a)
{
    return a / 0;
}
