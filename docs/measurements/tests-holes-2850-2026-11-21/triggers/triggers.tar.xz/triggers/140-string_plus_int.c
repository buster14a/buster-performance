const char* f(int i)
{
    return "abc" + i;
}
