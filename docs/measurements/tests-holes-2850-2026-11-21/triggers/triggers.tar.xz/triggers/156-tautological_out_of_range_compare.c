int f(unsigned char c, signed char s)
{
    return (c > 300) + (s > 127) + (c == -1);
}
