int printf(const char*, ...);
void f(void)
{
    printf("%d");
}
