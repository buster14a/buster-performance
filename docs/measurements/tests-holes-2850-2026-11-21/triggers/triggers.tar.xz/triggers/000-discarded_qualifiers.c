void f(const int* p)
{
    int* q;
    q = p;
    (void)q;
}
