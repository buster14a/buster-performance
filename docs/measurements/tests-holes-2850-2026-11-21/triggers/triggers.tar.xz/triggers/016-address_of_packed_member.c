struct __attribute__((packed)) P { char c; int i; };
int* f(struct P* p)
{
    return &p->i;
}
