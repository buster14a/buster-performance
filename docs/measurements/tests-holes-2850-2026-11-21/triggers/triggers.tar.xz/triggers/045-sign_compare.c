int f(int a, unsigned b)
{
    return a < b;
}
