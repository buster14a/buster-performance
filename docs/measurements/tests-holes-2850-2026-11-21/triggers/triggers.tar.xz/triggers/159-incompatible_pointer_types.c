long* f(int* p)
{
    long* q = p;
    q = p;
    return q;
}
