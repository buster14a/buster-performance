int g(a) int a; { return a; }
int f(void)
{
    return g(1, 2);
}
