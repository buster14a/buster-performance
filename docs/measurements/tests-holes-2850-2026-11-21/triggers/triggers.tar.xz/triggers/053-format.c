int printf(const char*, ...);
void f(int a)
{
    printf("%s", a);
}
