int f(void)
{
    return "\e"[0];
}
