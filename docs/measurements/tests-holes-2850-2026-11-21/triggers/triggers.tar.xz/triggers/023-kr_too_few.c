int g(a, b) int a; int b; { return a + b; }
int f(void)
{
    return g(1);
}
