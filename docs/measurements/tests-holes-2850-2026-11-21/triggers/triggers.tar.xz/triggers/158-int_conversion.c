int* f(long a)
{
    int* p = a;
    p = a;
    return p;
}
