enum A { A0, A1 };
enum B { B0, B1 };
void f(void)
{
    enum A a = 5;
    a = 7;
    (void)a;
}
