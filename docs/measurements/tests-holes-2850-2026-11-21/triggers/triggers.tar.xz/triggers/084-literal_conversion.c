int f(void)
{
    int a = 1.5;
    a = 2.5;
    return a;
}
