/home/david/Documents/Codex/2026-11-19/profile-and-improve-buster-compilation-speed/work/unsigned32-evidence/checks/znver5-default-clang.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <c_parameter_f>:
   0:	vcvtusi2ss xmm0,xmm15,edi
   6:	ret
   7:	nop

0000000000000008 <c_load_f>:
   8:	vcvtusi2ss xmm0,xmm15,DWORD PTR [rsi]
   e:	ret
   f:	nop

0000000000000010 <c_sum_f>:
  10:	add    edi,edx
  12:	vcvtusi2ss xmm0,xmm15,edi
  18:	ret
  19:	nop    DWORD PTR [rax+0x0]

0000000000000020 <c_xor_f>:
  20:	xor    edi,edx
  22:	vcvtusi2ss xmm0,xmm15,edi
  28:	ret
  29:	nop    DWORD PTR [rax+0x0]

0000000000000030 <c_dirtycall_f>:
  30:	push   rax
  31:	call   36 <c_dirtycall_f+0x6>
  36:	vcvtusi2ss xmm0,xmm15,eax
  3c:	pop    rax
  3d:	ret
  3e:	xchg   ax,ax

0000000000000040 <c_volatileload_f>:
  40:	vcvtusi2ss xmm0,xmm15,DWORD PTR [rsi]
  46:	ret
  47:	nop    WORD PTR [rax+rax*1+0x0]

0000000000000050 <c_aftercall_f>:
  50:	push   rbx
  51:	mov    ebx,DWORD PTR [rsi]
  53:	call   58 <c_aftercall_f+0x8>
  58:	vcvtusi2ss xmm0,xmm15,ebx
  5e:	pop    rbx
  5f:	ret

0000000000000060 <c_mixed_f>:
  60:	test   dl,0x1
  63:	jne    67 <c_mixed_f+0x7>
  65:	mov    edi,DWORD PTR [rsi]
  67:	vcvtusi2ss xmm0,xmm15,edi
  6d:	ret
  6e:	xchg   ax,ax

0000000000000070 <c_signedview_f>:
  70:	movsxd rax,DWORD PTR [rsi]
  73:	vcvtusi2ss xmm0,xmm15,eax
  79:	mov    QWORD PTR [rcx],rax
  7c:	ret
  7d:	nop    DWORD PTR [rax]

0000000000000080 <c_rotate_f>:
  80:	mov    ecx,edx
  82:	rol    edi,cl
  84:	vcvtusi2ss xmm0,xmm15,edi
  8a:	ret
  8b:	nop    DWORD PTR [rax+rax*1+0x0]

0000000000000090 <c_parameter_d>:
  90:	vcvtusi2sd xmm0,xmm15,edi
  96:	ret
  97:	nop

0000000000000098 <c_load_d>:
  98:	vcvtusi2sd xmm0,xmm15,DWORD PTR [rsi]
  9e:	ret
  9f:	nop

00000000000000a0 <c_sum_d>:
  a0:	add    edi,edx
  a2:	vcvtusi2sd xmm0,xmm15,edi
  a8:	ret
  a9:	nop    DWORD PTR [rax+0x0]

00000000000000b0 <c_xor_d>:
  b0:	xor    edi,edx
  b2:	vcvtusi2sd xmm0,xmm15,edi
  b8:	ret
  b9:	nop    DWORD PTR [rax+0x0]

00000000000000c0 <c_dirtycall_d>:
  c0:	push   rax
  c1:	call   c6 <c_dirtycall_d+0x6>
  c6:	vcvtusi2sd xmm0,xmm15,eax
  cc:	pop    rax
  cd:	ret
  ce:	xchg   ax,ax

00000000000000d0 <c_volatileload_d>:
  d0:	vcvtusi2sd xmm0,xmm15,DWORD PTR [rsi]
  d6:	ret
  d7:	nop    WORD PTR [rax+rax*1+0x0]

00000000000000e0 <c_aftercall_d>:
  e0:	push   rbx
  e1:	mov    ebx,DWORD PTR [rsi]
  e3:	call   e8 <c_aftercall_d+0x8>
  e8:	vcvtusi2sd xmm0,xmm15,ebx
  ee:	pop    rbx
  ef:	ret

00000000000000f0 <c_mixed_d>:
  f0:	test   dl,0x1
  f3:	jne    f7 <c_mixed_d+0x7>
  f5:	mov    edi,DWORD PTR [rsi]
  f7:	vcvtusi2sd xmm0,xmm15,edi
  fd:	ret
  fe:	xchg   ax,ax

0000000000000100 <c_signedview_d>:
 100:	movsxd rax,DWORD PTR [rsi]
 103:	vcvtusi2sd xmm0,xmm15,eax
 109:	mov    QWORD PTR [rcx],rax
 10c:	ret
 10d:	nop    DWORD PTR [rax]

0000000000000110 <c_rotate_d>:
 110:	mov    ecx,edx
 112:	rol    edi,cl
 114:	vcvtusi2sd xmm0,xmm15,edi
 11a:	ret
