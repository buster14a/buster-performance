/home/david/Documents/Codex/2026-11-19/profile-and-improve-buster-compilation-speed/work/unsigned32-evidence/checks/x86-64-v2-default-clang.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <c_parameter_f>:
   0:	mov    eax,edi
   2:	cvtsi2ss xmm0,rax
   7:	ret

0000000000000008 <c_load_f>:
   8:	mov    eax,DWORD PTR [rsi]
   a:	cvtsi2ss xmm0,rax
   f:	ret

0000000000000010 <c_sum_f>:
  10:	add    edi,edx
  12:	cvtsi2ss xmm0,rdi
  17:	ret

0000000000000018 <c_xor_f>:
  18:	xor    edi,edx
  1a:	cvtsi2ss xmm0,rdi
  1f:	ret

0000000000000020 <c_dirtycall_f>:
  20:	push   rax
  21:	call   26 <c_dirtycall_f+0x6>
  26:	mov    eax,eax
  28:	cvtsi2ss xmm0,rax
  2d:	pop    rax
  2e:	ret
  2f:	nop

0000000000000030 <c_volatileload_f>:
  30:	mov    eax,DWORD PTR [rsi]
  32:	cvtsi2ss xmm0,rax
  37:	ret
  38:	nop    DWORD PTR [rax+rax*1+0x0]

0000000000000040 <c_aftercall_f>:
  40:	push   rbx
  41:	mov    ebx,DWORD PTR [rsi]
  43:	call   48 <c_aftercall_f+0x8>
  48:	cvtsi2ss xmm0,rbx
  4d:	pop    rbx
  4e:	ret
  4f:	nop

0000000000000050 <c_mixed_f>:
  50:	test   dl,0x1
  53:	jne    57 <c_mixed_f+0x7>
  55:	mov    edi,DWORD PTR [rsi]
  57:	mov    eax,edi
  59:	cvtsi2ss xmm0,rax
  5e:	ret
  5f:	nop

0000000000000060 <c_signedview_f>:
  60:	movsxd rax,DWORD PTR [rsi]
  63:	mov    QWORD PTR [rcx],rax
  66:	mov    eax,eax
  68:	cvtsi2ss xmm0,rax
  6d:	ret
  6e:	xchg   ax,ax

0000000000000070 <c_rotate_f>:
  70:	mov    ecx,edx
  72:	rol    edi,cl
  74:	cvtsi2ss xmm0,rdi
  79:	ret
  7a:	nop    WORD PTR [rax+rax*1+0x0]

0000000000000080 <c_parameter_d>:
  80:	mov    eax,edi
  82:	cvtsi2sd xmm0,rax
  87:	ret

0000000000000088 <c_load_d>:
  88:	mov    eax,DWORD PTR [rsi]
  8a:	cvtsi2sd xmm0,rax
  8f:	ret

0000000000000090 <c_sum_d>:
  90:	add    edi,edx
  92:	cvtsi2sd xmm0,rdi
  97:	ret

0000000000000098 <c_xor_d>:
  98:	xor    edi,edx
  9a:	cvtsi2sd xmm0,rdi
  9f:	ret

00000000000000a0 <c_dirtycall_d>:
  a0:	push   rax
  a1:	call   a6 <c_dirtycall_d+0x6>
  a6:	mov    eax,eax
  a8:	cvtsi2sd xmm0,rax
  ad:	pop    rax
  ae:	ret
  af:	nop

00000000000000b0 <c_volatileload_d>:
  b0:	mov    eax,DWORD PTR [rsi]
  b2:	cvtsi2sd xmm0,rax
  b7:	ret
  b8:	nop    DWORD PTR [rax+rax*1+0x0]

00000000000000c0 <c_aftercall_d>:
  c0:	push   rbx
  c1:	mov    ebx,DWORD PTR [rsi]
  c3:	call   c8 <c_aftercall_d+0x8>
  c8:	cvtsi2sd xmm0,rbx
  cd:	pop    rbx
  ce:	ret
  cf:	nop

00000000000000d0 <c_mixed_d>:
  d0:	test   dl,0x1
  d3:	jne    d7 <c_mixed_d+0x7>
  d5:	mov    edi,DWORD PTR [rsi]
  d7:	mov    eax,edi
  d9:	cvtsi2sd xmm0,rax
  de:	ret
  df:	nop

00000000000000e0 <c_signedview_d>:
  e0:	movsxd rax,DWORD PTR [rsi]
  e3:	mov    QWORD PTR [rcx],rax
  e6:	mov    eax,eax
  e8:	cvtsi2sd xmm0,rax
  ed:	ret
  ee:	xchg   ax,ax

00000000000000f0 <c_rotate_d>:
  f0:	mov    ecx,edx
  f2:	rol    edi,cl
  f4:	cvtsi2sd xmm0,rdi
  f9:	ret
