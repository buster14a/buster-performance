/home/david/Documents/Codex/2026-11-19/profile-and-improve-buster-compilation-speed/work/unsigned32-evidence/checks/x86-64-v2-post-parent.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <c_parameter_f>:
   0:	xorps  xmm0,xmm0
   3:	mov    r11d,edi
   6:	cvtsi2ss xmm0,r11
   b:	ret
   c:	int3
   d:	int3
   e:	int3
   f:	int3

0000000000000010 <c_load_f>:
  10:	mov    eax,DWORD PTR [rsi]
  12:	xorps  xmm0,xmm0
  15:	mov    r11d,eax
  18:	cvtsi2ss xmm0,r11
  1d:	ret
  1e:	int3
  1f:	int3

0000000000000020 <c_sum_f>:
  20:	lea    eax,[rdi+rdx*1]
  23:	xorps  xmm0,xmm0
  26:	mov    r11d,eax
  29:	cvtsi2ss xmm0,r11
  2e:	ret
  2f:	int3

0000000000000030 <c_xor_f>:
  30:	xor    edi,edx
  32:	xorps  xmm0,xmm0
  35:	mov    r11d,edi
  38:	cvtsi2ss xmm0,r11
  3d:	ret
  3e:	int3
  3f:	int3

0000000000000040 <c_dirtycall_f>:
  40:	sub    rsp,0x8
  44:	call   49 <c_dirtycall_f+0x9>
  49:	xorps  xmm0,xmm0
  4c:	mov    r11d,eax
  4f:	cvtsi2ss xmm0,r11
  54:	add    rsp,0x8
  58:	ret
  59:	int3
  5a:	int3
  5b:	int3
  5c:	int3
  5d:	int3
  5e:	int3
  5f:	int3

0000000000000060 <c_volatileload_f>:
  60:	mov    eax,DWORD PTR [rsi]
  62:	xorps  xmm0,xmm0
  65:	mov    r11d,eax
  68:	cvtsi2ss xmm0,r11
  6d:	ret
  6e:	int3
  6f:	int3

0000000000000070 <c_aftercall_f>:
  70:	push   rbx
  71:	mov    ebx,DWORD PTR [rsi]
  73:	call   78 <c_aftercall_f+0x8>
  78:	xorps  xmm0,xmm0
  7b:	mov    r11d,ebx
  7e:	cvtsi2ss xmm0,r11
  83:	pop    rbx
  84:	ret
  85:	int3
  86:	int3
  87:	int3
  88:	int3
  89:	int3
  8a:	int3
  8b:	int3
  8c:	int3
  8d:	int3
  8e:	int3
  8f:	int3

0000000000000090 <c_mixed_f>:
  90:	and    edx,0x1
  93:	test   edx,edx
  95:	je     9c <c_mixed_f+0xc>
  97:	mov    rax,rdi
  9a:	jmp    9e <c_mixed_f+0xe>
  9c:	mov    eax,DWORD PTR [rsi]
  9e:	xorps  xmm0,xmm0
  a1:	mov    r11d,eax
  a4:	cvtsi2ss xmm0,r11
  a9:	ret
  aa:	int3
  ab:	int3
  ac:	int3
  ad:	int3
  ae:	int3
  af:	int3

00000000000000b0 <c_signedview_f>:
  b0:	movsxd rax,DWORD PTR [rsi]
  b3:	xorps  xmm0,xmm0
  b6:	mov    r11d,eax
  b9:	cvtsi2ss xmm0,r11
  be:	mov    rdx,rax
  c1:	mov    QWORD PTR [rcx],rdx
  c4:	ret
  c5:	int3
  c6:	int3
  c7:	int3
  c8:	int3
  c9:	int3
  ca:	int3
  cb:	int3
  cc:	int3
  cd:	int3
  ce:	int3
  cf:	int3

00000000000000d0 <c_rotate_f>:
  d0:	mov    eax,edx
  d2:	and    eax,0x1f
  d5:	mov    ecx,eax
  d7:	mov    rax,rdi
  da:	shl    eax,cl
  dc:	xor    ecx,ecx
  de:	sub    ecx,edx
  e0:	and    ecx,0x1f
  e3:	mov    rdx,rdi
  e6:	shr    edx,cl
  e8:	or     eax,edx
  ea:	xorps  xmm0,xmm0
  ed:	mov    r11d,eax
  f0:	cvtsi2ss xmm0,r11
  f5:	ret
  f6:	int3
  f7:	int3
  f8:	int3
  f9:	int3
  fa:	int3
  fb:	int3
  fc:	int3
  fd:	int3
  fe:	int3
  ff:	int3

0000000000000100 <c_parameter_d>:
 100:	xorps  xmm0,xmm0
 103:	mov    r11d,edi
 106:	cvtsi2sd xmm0,r11
 10b:	ret
 10c:	int3
 10d:	int3
 10e:	int3
 10f:	int3

0000000000000110 <c_load_d>:
 110:	mov    eax,DWORD PTR [rsi]
 112:	xorps  xmm0,xmm0
 115:	mov    r11d,eax
 118:	cvtsi2sd xmm0,r11
 11d:	ret
 11e:	int3
 11f:	int3

0000000000000120 <c_sum_d>:
 120:	lea    eax,[rdi+rdx*1]
 123:	xorps  xmm0,xmm0
 126:	mov    r11d,eax
 129:	cvtsi2sd xmm0,r11
 12e:	ret
 12f:	int3

0000000000000130 <c_xor_d>:
 130:	xor    edi,edx
 132:	xorps  xmm0,xmm0
 135:	mov    r11d,edi
 138:	cvtsi2sd xmm0,r11
 13d:	ret
 13e:	int3
 13f:	int3

0000000000000140 <c_dirtycall_d>:
 140:	sub    rsp,0x8
 144:	call   149 <c_dirtycall_d+0x9>
 149:	xorps  xmm0,xmm0
 14c:	mov    r11d,eax
 14f:	cvtsi2sd xmm0,r11
 154:	add    rsp,0x8
 158:	ret
 159:	int3
 15a:	int3
 15b:	int3
 15c:	int3
 15d:	int3
 15e:	int3
 15f:	int3

0000000000000160 <c_volatileload_d>:
 160:	mov    eax,DWORD PTR [rsi]
 162:	xorps  xmm0,xmm0
 165:	mov    r11d,eax
 168:	cvtsi2sd xmm0,r11
 16d:	ret
 16e:	int3
 16f:	int3

0000000000000170 <c_aftercall_d>:
 170:	push   rbx
 171:	mov    ebx,DWORD PTR [rsi]
 173:	call   178 <c_aftercall_d+0x8>
 178:	xorps  xmm0,xmm0
 17b:	mov    r11d,ebx
 17e:	cvtsi2sd xmm0,r11
 183:	pop    rbx
 184:	ret
 185:	int3
 186:	int3
 187:	int3
 188:	int3
 189:	int3
 18a:	int3
 18b:	int3
 18c:	int3
 18d:	int3
 18e:	int3
 18f:	int3

0000000000000190 <c_mixed_d>:
 190:	and    edx,0x1
 193:	test   edx,edx
 195:	je     19c <c_mixed_d+0xc>
 197:	mov    rax,rdi
 19a:	jmp    19e <c_mixed_d+0xe>
 19c:	mov    eax,DWORD PTR [rsi]
 19e:	xorps  xmm0,xmm0
 1a1:	mov    r11d,eax
 1a4:	cvtsi2sd xmm0,r11
 1a9:	ret
 1aa:	int3
 1ab:	int3
 1ac:	int3
 1ad:	int3
 1ae:	int3
 1af:	int3

00000000000001b0 <c_signedview_d>:
 1b0:	movsxd rax,DWORD PTR [rsi]
 1b3:	xorps  xmm0,xmm0
 1b6:	mov    r11d,eax
 1b9:	cvtsi2sd xmm0,r11
 1be:	mov    rdx,rax
 1c1:	mov    QWORD PTR [rcx],rdx
 1c4:	ret
 1c5:	int3
 1c6:	int3
 1c7:	int3
 1c8:	int3
 1c9:	int3
 1ca:	int3
 1cb:	int3
 1cc:	int3
 1cd:	int3
 1ce:	int3
 1cf:	int3

00000000000001d0 <c_rotate_d>:
 1d0:	mov    eax,edx
 1d2:	and    eax,0x1f
 1d5:	mov    ecx,eax
 1d7:	mov    rax,rdi
 1da:	shl    eax,cl
 1dc:	xor    ecx,ecx
 1de:	sub    ecx,edx
 1e0:	and    ecx,0x1f
 1e3:	mov    rdx,rdi
 1e6:	shr    edx,cl
 1e8:	or     eax,edx
 1ea:	xorps  xmm0,xmm0
 1ed:	mov    r11d,eax
 1f0:	cvtsi2sd xmm0,r11
 1f5:	ret
